"""Undo only our newly added duplicate mockturtle checkout, as requested."""
from pathlib import Path
import json
import os
import subprocess

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
PATH = 'tools/mockturtle-baseline'
ENV = dict(os.environ, GIT_LFS_SKIP_SMUDGE='1', GIT_TERMINAL_PROMPT='0')


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT, env=ENV)


before = git('ls-files', '--stage', '-z').split(b'\0')
assert git('-C', PATH, 'rev-parse', 'HEAD').decode().strip() == '1c9c3af6a423f650f654ccec340dae9b93995844'
assert not git('-C', PATH, '--no-optional-locks', 'status', '--porcelain=v1')
original_head = git('-C', 'tools/mockturtle', 'rev-parse', 'HEAD').decode().strip()
original_diff = git('-C', 'tools/mockturtle', 'diff', '--binary', 'HEAD')
(HERE / 'existing-mockturtle.before.patch').write_bytes(original_diff)
for argv in [['git', 'submodule', 'deinit', '-f', '--', PATH], ['git', 'rm', '-f', '--', PATH]]:
    with (HERE / 'remove-duplicate.log').open('ab') as log:
        subprocess.run(argv, cwd=ROOT, env=ENV, stdout=log, stderr=subprocess.STDOUT, check=True)
after = git('ls-files', '--stage', '-z').split(b'\0')
allowed = {b'.gitmodules', PATH.encode()}
def unrelated(rows):
    return [row for row in rows if row and row.split(b'\t', 1)[1] not in allowed]
assert unrelated(before) == unrelated(after)
assert git('-C', 'tools/mockturtle', 'diff', '--binary', 'HEAD') == original_diff
assert git('-C', 'tools/mockturtle', 'rev-parse', 'HEAD').decode().strip() == original_head
assert not (ROOT / PATH).exists()
(HERE / 'duplicate-removal.json').write_text(json.dumps({
    'removed_path': PATH, 'reuse': 'tools/mockturtle',
    'reused_current_commit': original_head,
    'existing_mockturtle_changes_preserved': True,
    'unrelated_staged_entries_preserved': True,
    'inactive_git_object_cache_retained': True,
    'source_algorithm_modified': False,
}, indent=2) + '\n')
print('Duplicate removed; original tools/mockturtle and its dirty work unchanged.')
