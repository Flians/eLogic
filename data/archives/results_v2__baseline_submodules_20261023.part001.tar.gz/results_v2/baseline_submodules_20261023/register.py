"""Register clean pinned upstream baseline sources; preserve unrelated index entries."""
import hashlib
import json
import os
from pathlib import Path
import subprocess

HERE = Path(__file__).resolve().parent
PLAN = json.loads((HERE / 'plan.json').read_text())
ROOT = Path(PLAN['root'])
ENV = dict(os.environ, GIT_LFS_SKIP_SMUDGE='1', GIT_TERMINAL_PROMPT='0')
commands = []


def run(args, cwd=ROOT):
    commands.append({'argv': args, 'cwd': str(cwd)})
    (HERE / 'commands.json').write_text(json.dumps(commands, indent=2) + '\n')
    with (HERE / 'registration.log').open('a') as log:
        result = subprocess.run(args, cwd=cwd, env=ENV, stdout=log, stderr=subprocess.STDOUT)
    if result.returncode:
        raise RuntimeError(f'command failed ({result.returncode}); see registration.log: {args}')


def output(args):
    return subprocess.check_output(args, cwd=ROOT, env=ENV)


assert hashlib.sha256((ROOT / '.gitmodules').read_bytes()).hexdigest() == PLAN['gitmodules_before_sha256']
assert output(['git', 'ls-files', '--stage', '-z']) == (HERE / 'index.before').read_bytes()
for entry in PLAN['entries']:
    assert not (ROOT / entry['path']).exists(), 'refuse to overwrite existing checkout'

resolved = []
for entry in PLAN['entries']:
    path = entry['path']
    if entry.get('local_seed'):
        run(['git', 'clone', '--no-checkout', '--no-hardlinks', entry['local_seed'], path])
        run(['git', '-C', path, 'remote', 'set-url', 'origin', entry['url']])
        commit = entry['commit']
    else:
        run(['git', 'clone', '--filter=blob:none', '--no-checkout', entry['url'], path])
        commit = output(['git', '-C', path, 'rev-parse', entry['commit_prefix'] + '^{commit}']).decode().strip()
        assert commit.startswith(entry['commit_prefix'])
    run(['git', '-C', path, '-c', 'core.autocrlf=false', 'checkout', '--detach', commit])
    run(['git', 'submodule', 'add', '--name', path, entry['url'], path])
    actual = output(['git', '-C', path, 'rev-parse', 'HEAD']).decode().strip()
    assert actual == commit
    assert not output(['git', '-C', path, '--no-optional-locks', 'status', '--porcelain=v1', '--untracked-files=no'])
    resolved.append(dict(entry, resolved_commit=actual, tracked_source_clean=True))
    print(path, actual, flush=True)

run(['git', 'submodule', 'absorbgitdirs', '--', *[e['path'] for e in PLAN['entries']]])
before = (HERE / 'index.before').read_bytes().split(b'\0')
after = output(['git', 'ls-files', '--stage', '-z'])
(HERE / 'index.after').write_bytes(after)
allowed = {b'.gitmodules', *[e['path'].encode() for e in PLAN['entries']]}


def unrelated(rows):
    return [row for row in rows if row and row.split(b'\t', 1)[1] not in allowed]


assert unrelated(before) == unrelated(after.split(b'\0')), 'unrelated staged entries changed'
for e in resolved:
    assert (ROOT / e['path'] / '.git').is_file()
    assert output(['git', '-C', e['path'], 'remote', 'get-url', 'origin']).decode().strip() == e['url']
    assert not output(['git', '-C', e['path'], '--no-optional-locks', 'status', '--porcelain=v1'])
result = {'entries': resolved, 'unrelated_staged_entries_unchanged': True,
          'existing_source_checkouts_modified': False, 'new_tracked_sources_clean': True,
          'build_or_binary_switch': False, 'commit_or_push': False,
          'LFS': 'smudge skipped during checkout; hydrate upstream LFS assets separately if required'}
(HERE / 'validation.json').write_text(json.dumps(result, indent=2) + '\n')
print('All five clean source submodules registered; unrelated index entries preserved.', flush=True)
