//! Isolated structural witness experiment. No rewrite saturation, no main mapper changes.
//! Resident state and cumulative import work are separate; old all-import budget is NOT claimed.
use std::{collections::{BTreeMap, BTreeSet, HashMap}, time::Instant};
use egg::{EGraph, Id};
use emapper::{egraph_sat::AigLang, techlib::{Cell, TechLib}, egraph_map::{Binding, Instance, OutputPin, MappedGraph, MapStats}};
use serde::Deserialize;

#[derive(Deserialize)]
struct Subject { inputs: Vec<String>, outputs: Vec<(usize,String)>, gates: Vec<(usize,usize,usize)> }
#[derive(Clone)]
struct Limits { nodes: usize, pool: usize, region: usize, seconds: f64 }
fn check_time(start: Instant, seconds: f64) -> Result<(),String> {
    if start.elapsed().as_secs_f64()>seconds {Err("one global construction/recovery deadline exceeded".into())} else {Ok(())}
}
fn graph(frontier: &BTreeSet<usize>, pis: usize) -> (EGraph<AigLang,()>,HashMap<usize,Id>) {
    let mut e=EGraph::default(); let mut ids=HashMap::new(); ids.insert(0,e.add(AigLang::Zero));
    for v in (1..=pis).chain(frontier.iter().copied()) {
        ids.entry(v).or_insert_with(||e.add(AigLang::Pi(v as u32)));
    }
    (e,ids)
}
fn build(s:&Subject, tech:&TechLib, limits:&Limits) -> Result<(MappedGraph,serde_json::Value),String> {
    let start=Instant::now();
    if limits.region==0 || !limits.seconds.is_finite() || limits.seconds<=0. {return Err("invalid limits".into())}
    // Immutable source description is input, never a reusable opaque mapped expression.
    // Each source AND is materialized in egg before committing its exact physical realization.
    let max=s.gates.iter().map(|x|x.0).chain(s.outputs.iter().map(|x|x.0/2)).max().unwrap_or(s.inputs.len());
    let mut uses=vec![0usize;max+1]; let mut demanded=vec![[false;2];max+1];
    for &(v,a,b) in &s.gates {
        if v<=s.inputs.len() || a/2>=v || b/2>=v {return Err("not a topological original AND stream".into())}
        for lit in [a,b] {uses[lit/2]+=1; demanded[lit/2][lit&1]=true;}
    }
    for &(lit,_) in &s.outputs {uses[lit/2]+=1; demanded[lit/2][lit&1]=true;}
    let unique: BTreeMap<_,usize>=tech.cells.iter().fold(BTreeMap::new(),|mut m,c| {*m.entry(c.name.clone()).or_default()+=1;m});
    let candidates=|n,tt|tech.cells.iter().filter(|c|c.vars.len()==n && c.tt[0]==tt && unique[&c.name]==1).collect::<Vec<_>>();
    let inv=candidates(1,1).into_iter().min_by(|a,b| {
        (a.pin_delay[&a.vars[0]],a.area,&a.name).partial_cmp(&(b.pin_delay[&b.vars[0]],b.area,&b.name)).unwrap()
    }).ok_or("no unique inverter")?;
    let pos=candidates(2,8); let neg=candidates(2,7);
    if pos.is_empty() || neg.is_empty() {return Err("missing exact AND/NAND primitive".into())}
    let mut instances=Vec::new(); let mut chosen=vec![None;2*(max+1)]; let mut constants=vec![None;chosen.len()];
    constants[0]=Some(false); constants[1]=Some(true);
    let mut arrival=vec![None;chosen.len()]; arrival[0]=Some(0.);arrival[1]=Some(0.);
    let committed=std::cell::Cell::new(0usize);
    let mut append=|cell:&Cell, inputs:Vec<usize>, target:usize, chosen:&mut Vec<Option<Binding>>, arrival:&mut Vec<Option<f64>>|->Result<(),String> {
        if instances.len()==limits.pool {return Err("global physical pool exhausted (committed instances never reset)".into())}
        let delay=inputs.iter().zip(&cell.vars).map(|(&x,p)|arrival[x].map(|d|d+f64::from(cell.pin_delay[p])).ok_or("missing physical boundary phase"))
            .collect::<Result<Vec<_>,_>>()?.into_iter().fold(0.,f64::max);
        let i=instances.len();committed.set(i+1);instances.push(Instance{cell:cell.name.clone(),area:cell.area,inputs,input_pins:cell.vars.clone(),outputs:vec![OutputPin{name:cell.out_pin.clone(),delays:cell.vars.iter().map(|p|cell.pin_delay[p]).collect(),function:cell.tt[0],targets:vec![target]}]});
        if chosen[target].is_some(){return Err("duplicate global producer".into())}
        chosen[target]=Some(Binding{instance:i,pin:0});arrival[target]=Some(delay);Ok(())
    };
    for v in 1..=s.inputs.len(){arrival[2*v]=Some(0.);if demanded[v][1]{append(inv,vec![2*v],2*v+1,&mut chosen,&mut arrival)?;}}
    let mut frontier=BTreeSet::new();let (mut e,mut ids)=graph(&frontier,s.inputs.len());
    let mut peak=e.total_size();let mut cumulative=e.total_size();let mut retired=0;let mut certificates=Vec::new();
    if peak>limits.nodes{return Err("global resident PI state exceeds node allowance".into())}
    for (index,&(v,a,b)) in s.gates.iter().enumerate() {
        check_time(start,limits.seconds)?;
        let x=*ids.get(&(a/2)).ok_or("retired boundary reused without certificate")?;
        let y=*ids.get(&(b/2)).ok_or("retired boundary reused without certificate")?;
        let phase=(a&1)|((b&1)<<1);
        let node=match phase {0=>AigLang::And([x,y]),p=>AigLang::Cell(match p {1=>"@egm_and_np",2=>"@egm_and_pn",_=>"@egm_and_nn"}.into(),vec![x,y])};
        let before=e.total_size();ids.insert(v,e.add(node));cumulative+=e.total_size()-before;
        peak=peak.max(e.total_size());if peak>limits.nodes{return Err("global resident egraph node allowance exceeded".into())}
        // Enumerate a bounded single structural cut. Match exact pin order and both producer phases.
        // Temporary variants also count against the one global physical pool.
        let mut best:Option<(f64,f64,&Cell,Vec<usize>,usize)>=None;
        let mut trials=0;
        for (ph,cs) in [(0,&pos),(1,&neg)] {for &cell in cs {for ins in [vec![a,b],vec![b,a]] {
            trials+=1;if committed.get()+trials>limits.pool{return Err("global proposed+committed pool exceeded".into())}
            let base=ins.iter().zip(&cell.vars).map(|(&x,p)|arrival[x].unwrap()+f64::from(cell.pin_delay[p])).fold(0.,f64::max);
            let delay=if demanded[v][1-ph] {base+f64::from(inv.pin_delay[&inv.vars[0]])}else{base};
            let area=f64::from(cell.area)+if demanded[v][1-ph]{f64::from(inv.area)}else{0.};
            if best.as_ref().is_none_or(|z|(delay,area,&cell.name,&ins,ph)<(z.0,z.1,&z.2.name,&z.3,z.4)){best=Some((delay,area,cell,ins,ph));}
        }}}
        let (_,_,cell,ins,ph)=best.ok_or("no matched producer")?;
        append(cell,ins,2*v+ph,&mut chosen,&mut arrival)?;
        if demanded[v][1-ph]{append(inv,vec![2*v+ph],2*v+1-ph,&mut chosen,&mut arrival)?;}
        for lit in [a,b]{uses[lit/2]-=1;if uses[lit/2]==0{frontier.remove(&(lit/2));}}
        if uses[v]>0{frontier.insert(v);}
        if (index+1)%limits.region==0 || index+1==s.gates.len() {
            // Every live crossing has a global, exact matched producer for every demanded phase.
            for &f in &frontier{for ph in 0..2{if demanded[f][ph] && arrival[2*f+ph].is_none(){return Err("uncertified crossing phase".into())}}}
            let old=e.total_size();let count=frontier.len()+s.inputs.len()+1;
            certificates.push(serde_json::json!({"processed":index+1,"old_enodes":old,"frontier":frontier.iter().copied().collect::<Vec<_>>(),"boundary_enodes":count,"physical_prefix_instances":committed.get()}));
            // Drop old graph before allocating the successor. There is never a second resident graph.
            drop(e);ids.clear();let next=graph(&frontier,s.inputs.len());e=next.0;ids=next.1;
            cumulative+=e.total_size();retired+=old;peak=peak.max(e.total_size());
            if peak>limits.nodes{return Err("global rebuilt boundary exceeds node allowance".into())}
        }
    }
    check_time(start,limits.seconds)?;
    // Global physical witness verification: topological drivers, exact library functions and aliases.
    let mut seen: BTreeSet<usize>=(0..2).chain((1..=s.inputs.len()).map(|v|2*v)).collect();
    let mut area=0.;for m in &instances {
        if !m.inputs.iter().all(|x|seen.contains(x)){return Err("stitch cycle/undriven phase".into())}
        for o in &m.outputs{for &x in &o.targets{if !seen.insert(x){return Err("stitch multiple drivers".into())}}}
        area+=f64::from(m.area);
    }
    let delay=s.outputs.iter().map(|x|arrival[x.0].ok_or("undriven PO")).collect::<Result<Vec<_>,_>>()?.into_iter().fold(0.,f64::max);
    check_time(start,limits.seconds)?;
    let elapsed=start.elapsed().as_secs_f64();
    let audit=serde_json::json!({"resident_peak_enodes":peak,"cumulative_materialized_enodes_including_rebuilt_boundaries":cumulative,"retired_enodes":retired,"original_ANDs_materialized":s.gates.len(),"regions":certificates,"global_pool_committed":instances.len(),"global_recovery_seconds":elapsed,"cuts_per_original_class":1,"saturation_iterations":0,"old_cumulative_import_budget_compliant":cumulative<=limits.nodes,"scope":"native primitive physical witness with actual egg materialization and certified retirement; resident bound differs from old cumulative/all-original-state scope; no saturation or optimized regional cuts; no same-budget superiority claim"});
    Ok((MappedGraph{instances,chosen,inputs:s.inputs.iter().enumerate().map(|(i,n)|(2*(i+1),(i+1)as u32,n.clone())).collect(),outputs:s.outputs.clone(),constants,area,delay,stats:MapStats::default()},audit))
}

fn main()->Result<(),Box<dyn std::error::Error>> {
    let args:Vec<_>=std::env::args().skip(1).collect();if args.len()!=4{return Err("genlib subject.json mapped.v audit.json".into())}
    let s:Subject=serde_json::from_slice(&std::fs::read(&args[1])?)?;let tech=TechLib::from_genlib(&args[0],4)?;
    let limits=Limits{nodes:20_000,pool:100_000,region:256,seconds:2.};
    let (g,a)=build(&s,&tech,&limits)?;g.write_verilog(std::fs::File::create(&args[2])?,"mapped")?;
    std::fs::write(&args[3],serde_json::to_vec_pretty(&a)?)?;println!("{}",serde_json::json!({"area":g.area,"delay":g.delay,"audit":a}));Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;
    fn library()->TechLib {
        let root=std::path::Path::new(env!("CARGO_MANIFEST_DIR")).parent().unwrap().parent().unwrap();
        TechLib::from_genlib(root.join("results_v2/flow_saturation_main_checkpoint_20261014/3in_sqrt_flow_sat/asap7_3in.genlib"),3).unwrap()
    }
    fn subject()->Subject {Subject{inputs:vec!["a[0]".into(),"b".into()],outputs:vec![(10,"p".into()),(11,"q".into()),(3,"neg_pi".into())],gates:vec![(3,2,5),(4,7,2),(5,6,9)]}}
    #[test] fn phases_shared_crossings_and_negative_pi_are_exact() {
        let s=subject();let (g,a)=build(&s,&library(),&Limits{nodes:20,pool:100,region:1,seconds:2.}).unwrap();
        assert_eq!(a["original_ANDs_materialized"],3);assert_eq!(a["regions"].as_array().unwrap().len(),3);
        for bits in 0..4 {
            let p:HashMap<u32,bool>=[(1,bits&1!=0),(2,bits&2!=0)].into_iter().collect();
            let mut v=vec![false;6];v[1]=p[&1];v[2]=p[&2];
            for &(n,x,y) in &s.gates{v[n]=(v[x/2]^(x&1!=0))&(v[y/2]^(y&1!=0));}
            let expected:Vec<_>=s.outputs.iter().map(|(x,_)|v[x/2]^(x&1!=0)).collect();
            assert_eq!(g.evaluate(&p).unwrap(),expected);
        }
    }
    #[test] fn globally_committed_pool_is_not_reset_by_retirement() {
        assert!(build(&subject(),&library(),&Limits{nodes:20,pool:3,region:1,seconds:2.}).is_err());
    }
    #[test] fn resident_bound_and_deadline_are_checked() {
        assert!(build(&subject(),&library(),&Limits{nodes:2,pool:100,region:1,seconds:2.}).is_err());
        assert!(build(&subject(),&library(),&Limits{nodes:20,pool:100,region:1,seconds:0.}).is_err());
    }
    #[test] fn cumulative_and_resident_budgets_are_not_conflated() {
        let s=Subject{inputs:vec!["a".into(),"b".into()],outputs:vec![(42,"z".into())],gates:(3..=21).map(|v|(v,2*(v-1),2)).collect()};
        let (_,a)=build(&s,&library(),&Limits{nodes:5,pool:200,region:1,seconds:2.}).unwrap();
        assert!(a["resident_peak_enodes"].as_u64().unwrap()<=5);
        assert_eq!(a["old_cumulative_import_budget_compliant"],false);
    }
}
