# Native retirement witness experiment

This isolated crate does not change the production mapper or baseline methods.
It is a constructive structural witness, not optimized regional saturation.

The input is the already shared, CEC-passed resyn2 AIG, converted to an explicit
topological AND stream without additional logic optimization. Each original live
AND is materialized in a real egg egraph with exact input phase attributes. Its
physical realization is matched against the unchanged library's exact AND/NAND
truth tables, with pin permutation and a globally shared inverter when the
other demanded output phase is needed. Choices use demanded-phase arrival,
then physical area, without exchanging timing for area.

After every 256 original ANDs, future raw-AIG uses and primary outputs identify
the crossing frontier. Every crossing's demanded phases must have committed
global physical producers. The old egraph is dropped before constructing the
next graph from frontier interface symbols and the original primary inputs.
Original node IDs and physical signal IDs are stable across all regions.
Final verification checks global driver uniqueness, topological dependencies,
and all output phases before returning the stitched physical witness.

There is one global 2-second construction/recovery deadline including mandatory
physical setup and final verification. Committed physical instances never reset
and consume the same 100,000 pool, together with temporary candidate proposals.
No saturation is performed (zero of sixteen permitted iterations); there is
one structural cut per original class. All simultaneously resident logical
state belongs to one 20,000-node ledger. No graph is built concurrently with
its predecessor. Input conversion, independent CEC, and common measurement are
outside the mapping recovery clock. The native process retains the external
60-second guard and the mapping-only policy remains 300 seconds.

**Budget limitation:** a resident-state limit is different from retaining every
original scalar function in one egraph. Cumulative node materialization and
rebuilt interface work are reported separately and are never reset. The runner
does not label an observation as compliant with the old cumulative-import
interpretation when that counter exceeds 20,000. No old-budget superiority,
optimized-cover claim, or production promotion follows from a positive CEC.
The final physical netlist is counted under the physical pool; retired logical
expressions are not cached as opaque formulas or reopened as free equivalents.

The full EPFL diagnostic uses one fixed primitive strategy in both inventories,
preserves failures, and does not select the best repeated run. Ordinary baseline
measurements are read from their frozen complete reports, not rerun or optimized.
The next algorithmic step is bounded regional cut matching and actual cover
selection, with explicit accounting of retained alternatives and safe sharing.
That step is not implemented here.
