"""Hardlink byte-identical immutable completed outputs, retaining every logical artifact."""
import datetime,hashlib,json,os,time
from pathlib import Path
P=Path(__file__).resolve().parent
state=json.loads((P/'storage_deduplication.json').read_text()) if (P/'storage_deduplication.json').exists() else {}
cache={};events=state.get('events',[]);saved=state.get('estimated_bytes_saved',0)
while True:
 seen={};count=0;batch_saved=0
 for row in sorted(P.glob('*/*/*/row.tsv')):
  for f in sorted(row.parent.glob('*.v*')):
   if f.suffix not in ['.v','.gz'] or not f.is_file():continue
   try:
    st=f.stat();key=(st.st_dev,st.st_ino,st.st_mtime_ns,st.st_size)
    h=cache.get(key)
    if h is None:h=hashlib.sha256(f.read_bytes()).hexdigest();cache[key]=h
    origin=seen.get(h)
    if origin is None or not origin.exists():seen[h]=f;continue
    other=origin.stat()
    if (st.st_dev,st.st_ino)==(other.st_dev,other.st_ino):continue
    # Only completed immutable V/gzip files are eligible. A racing history
    # archivist may remove a superseded V, but never modify its bytes.
    temp=f.with_name(f.name+'.dedup.tmp');os.link(origin,temp);temp.replace(f)
    assert hashlib.sha256(f.read_bytes()).hexdigest()==h
    events.append(dict(path=str(f.relative_to(P)),canonical_at_link=str(origin.relative_to(P)),sha256=h,bytes=st.st_size))
    count+=1;batch_saved+=st.st_size
   except FileNotFoundError:continue
 saved+=batch_saved
 if count:
  dest=P/'storage_deduplication.json';tmp=dest.with_suffix('.json.tmp');tmp.write_text(json.dumps(dict(protocol='Completed immutable Verilog outputs only; SHA256-identical bytes, atomic hardlink replacement; no logical artifacts removed.',last_updated=datetime.datetime.now().astimezone().isoformat(),logical_duplicates_linked=len(events),estimated_bytes_saved=saved,events=events),indent=2)+'\n');tmp.replace(dest)
  print(json.dumps(dict(linked=count,estimated_bytes_saved=batch_saved)),flush=True)
 if (P/'execution_status.json').exists() and 'Checkpoint-history archival complete' in Path('/tmp/epmapping-v27-history.log').read_text():break
 time.sleep(30)
print('Immutable-output storage deduplication complete',flush=True)
