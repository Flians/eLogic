# Three-part constrained-area experiments

Every selected implementation satisfies its own initial area/delay bounds and has CEC evidence; native optimizer completions and independently validated deadline selections are counted separately.
ABC raw area-mode outputs are preserved. The guarded comparison reverts an infeasible completed output to its native initial mapping; it is an external output-selection policy, not an internal mfs3 timing constraint. ABC timeouts are excluded from the ABC-completed paired subset; our native timeout selections remain included as independently validated netlists under the declared selection policy.

{
  "whole_window_synthesis": false,
  "engine_cec_outputs": 255,
  "baseline_cec_outputs": 16,
  "main_own_area": -7.459951842202848,
  "main_own_delay": -6.758717546038532,
  "main_one_area": -5.277772794265891,
  "main_one_delay": -4.622022661097069,
  "main_other_area": -3.9638802580666477,
  "main_other_delay": -2.2854586165615363,
  "main_area_wins": 16,
  "reference_area": -9.411942889609161,
  "reference_delay": -6.183907380551672,
  "reference_wins": 13,
  "mfs_ours_area": -6.100156801239892,
  "mfs_ours_delay": -5.520336641682567,
  "abc_completed": 13,
  "abc_timeouts": 3,
  "abc_feasible": 6,
  "abc_delay_violations": 7,
  "cut_oracle_times": {
    "secs_stage1": 590.852398294,
    "secs_stage2": 196.81855471799997,
    "secs_synth": 902.6638971049999,
    "secs_egg": 1103.003644808,
    "secs_care": 34.50702293199999,
    "secs_window": 0.0,
    "secs_chain": 0.055273802
  },
  "method_timeouts": 49,
  "selected_cec_outputs": 304,
  "phase_timed_full_runs": 13,
  "method_checkpoint_selections": 49,
  "full_main_ppa_equal": {
    "aes_core": true,
    "arbiter": true,
    "div": true,
    "ethernet": true,
    "iwls05_i2c": true,
    "mem_ctrl": false,
    "RISC": true,
    "sasc": true,
    "simple_spi": true,
    "spi": true,
    "sqrt": false,
    "systemcaes": true,
    "systemcdes": true,
    "tv80": true,
    "usb_funct": true,
    "usb_phy": true
  },
  "cofactor_activity": {
    "aes_core": {
      "cofactor_wins": 509,
      "secs_cofactor": 148.351615,
      "available": true
    },
    "arbiter": {
      "cofactor_wins": 0,
      "secs_cofactor": 2.695811226,
      "available": true
    },
    "div": {
      "cofactor_wins": 0,
      "secs_cofactor": 0.0,
      "available": false
    },
    "ethernet": {
      "cofactor_wins": 9365,
      "secs_cofactor": 60.68180317,
      "available": true
    },
    "iwls05_i2c": {
      "cofactor_wins": 57,
      "secs_cofactor": 7.229519565,
      "available": true
    },
    "mem_ctrl": {
      "cofactor_wins": 0,
      "secs_cofactor": 0.0,
      "available": false
    },
    "RISC": {
      "cofactor_wins": 4373,
      "secs_cofactor": 213.4196855,
      "available": true
    },
    "sasc": {
      "cofactor_wins": 62,
      "secs_cofactor": 2.480918671,
      "available": true
    },
    "simple_spi": {
      "cofactor_wins": 76,
      "secs_cofactor": 4.322272566,
      "available": true
    },
    "spi": {
      "cofactor_wins": 193,
      "secs_cofactor": 22.99943596,
      "available": true
    },
    "sqrt": {
      "cofactor_wins": 0,
      "secs_cofactor": 0.0,
      "available": false
    },
    "systemcaes": {
      "cofactor_wins": 1363,
      "secs_cofactor": 50.36230578,
      "available": true
    },
    "systemcdes": {
      "cofactor_wins": 129,
      "secs_cofactor": 37.85200449,
      "available": true
    },
    "tv80": {
      "cofactor_wins": 349,
      "secs_cofactor": 62.07008907,
      "available": true
    },
    "usb_funct": {
      "cofactor_wins": 751,
      "secs_cofactor": 51.53299595,
      "available": true
    },
    "usb_phy": {
      "cofactor_wins": 29,
      "secs_cofactor": 3.312714624,
      "available": true
    }
  },
  "cofactor_seconds": 674.23938219,
  "abc_raw_area": -3.575691302200082,
  "abc_guarded_area": -1.5940348664441888,
  "paired_ours_area": -7.1039748788783665,
  "abc_raw_delay": 11.018744353868293,
  "abc_guarded_delay": -0.14558063949823968,
  "paired_ours_delay": -6.710450890568751,
  "paired_area_wins": 7,
  "guarded_paired_area_wins": 11,
  "ablation": {
    "full": {
      "area": 0.0,
      "worse": 0,
      "better": 0,
      "own_area": -7.461638773317469,
      "own_delay": -6.761924383231299,
      "optimizer_seconds": 5917.7699039519985,
      "time_ratio": 1.0
    },
    "noSYN": {
      "area": 364.7899999999999,
      "worse": 16,
      "better": 0,
      "own_area": -3.8907587321278005,
      "own_delay": -5.562622799066543,
      "optimizer_seconds": 4332.467528371001,
      "time_ratio": 0.7321115215172015
    },
    "noEGG": {
      "area": -0.24999999999982947,
      "worse": 10,
      "better": 1,
      "own_area": -7.419505084676216,
      "own_delay": -6.857770723327022,
      "optimizer_seconds": 4802.556323393,
      "time_ratio": 0.8115483368465817
    },
    "noDB": {
      "area": -71.26000000000045,
      "worse": 5,
      "better": 8,
      "own_area": -7.821919016324392,
      "own_delay": -7.2587732758203725,
      "optimizer_seconds": 4931.412706582,
      "time_ratio": 0.8333228203564843
    },
    "noCARE": {
      "area": 1.97999999999994,
      "worse": 12,
      "better": 2,
      "own_area": -7.4343105007435835,
      "own_delay": -6.627848915677735,
      "optimizer_seconds": 5708.137724339,
      "time_ratio": 0.9645758143666582
    },
    "noCHAIN": {
      "area": 334.2600000000001,
      "worse": 2,
      "better": 1,
      "own_area": -3.716137741937482,
      "own_delay": -2.14261745302644,
      "optimizer_seconds": 5901.852616717,
      "time_ratio": 0.9973102558069437
    },
    "noSHARE": {
      "area": 334.7400000000001,
      "worse": 2,
      "better": 1,
      "own_area": -3.7135456805574685,
      "own_delay": -2.140865622345626,
      "optimizer_seconds": 5901.365731359,
      "time_ratio": 0.9972279806651415
    },
    "noNARROW": {
      "area": 2.4599999999995816,
      "worse": 6,
      "better": 0,
      "own_area": -7.449804125597774,
      "own_delay": -6.7561221098251645,
      "optimizer_seconds": 6335.634561147,
      "time_ratio": 1.0706118460124554
    },
    "noPHASE": {
      "area": 199.8299999999998,
      "worse": 14,
      "better": 1,
      "own_area": -5.1853484443674045,
      "own_delay": -6.548516935179661,
      "optimizer_seconds": 3930.0982065990006,
      "time_ratio": 0.6641181171938447
    },
    "noSHANNON": {
      "area": 145.38000000000028,
      "worse": 15,
      "better": 0,
      "own_area": -6.129887567337187,
      "own_delay": -6.948022665677006,
      "optimizer_seconds": 5506.593686614001,
      "time_ratio": 0.9305183837811257
    },
    "noDAVIO": {
      "area": 75.71999999999974,
      "worse": 13,
      "better": 0,
      "own_area": -6.347244156852993,
      "own_delay": -6.623812636792773,
      "optimizer_seconds": 5455.487149008,
      "time_ratio": 0.9218822694280024
    },
    "noREUSE": {
      "area": 186.26000000000002,
      "worse": 14,
      "better": 1,
      "own_area": -5.294880449037382,
      "own_delay": -7.0316386476083625,
      "optimizer_seconds": 4174.5191292009995,
      "time_ratio": 0.705420994218308
    },
    "noPRICE": {
      "area": 113.90999999999971,
      "worse": 14,
      "better": 1,
      "own_area": -6.034395822282691,
      "own_delay": -6.548825286210618,
      "optimizer_seconds": 3713.7350865899994,
      "time_ratio": 0.6275565199163788
    },
    "cache64K": {
      "area": 5.519999999999754,
      "worse": 3,
      "better": 0,
      "own_area": -7.440006185326757,
      "own_delay": -6.7561221098251645,
      "optimizer_seconds": 7077.9098011040005,
      "time_ratio": 1.1960434278421739
    },
    "noAIGREUSE": {
      "area": 0.8700000000001182,
      "worse": 1,
      "better": 1,
      "own_area": -7.456225753969079,
      "own_delay": -6.756965715357717,
      "optimizer_seconds": 6128.418768102001,
      "time_ratio": 1.0355959876049468
    },
    "noLIBSHARE": {
      "area": 5.629999999999882,
      "worse": 2,
      "better": 0,
      "own_area": -7.436135276517173,
      "own_delay": -6.753868944543355,
      "optimizer_seconds": 5998.3526275290005,
      "time_ratio": 1.0136170761764811
    }
  },
  "chain_activity": {
    "aes_core": {
      "chain_wins": 0,
      "secs_chain": 0.0,
      "available": true
    },
    "arbiter": {
      "chain_wins": 384,
      "secs_chain": 0.058317729,
      "available": true
    },
    "div": {
      "chain_wins": 0,
      "secs_chain": 0.0,
      "available": false
    },
    "ethernet": {
      "chain_wins": 0,
      "secs_chain": 0.0,
      "available": true
    },
    "iwls05_i2c": {
      "chain_wins": 0,
      "secs_chain": 0.0,
      "available": true
    },
    "mem_ctrl": {
      "chain_wins": 0,
      "secs_chain": 0.0,
      "available": false
    },
    "RISC": {
      "chain_wins": 0,
      "secs_chain": 0.0,
      "available": true
    },
    "sasc": {
      "chain_wins": 0,
      "secs_chain": 0.0,
      "available": true
    },
    "simple_spi": {
      "chain_wins": 0,
      "secs_chain": 0.0,
      "available": true
    },
    "spi": {
      "chain_wins": 0,
      "secs_chain": 0.0,
      "available": true
    },
    "sqrt": {
      "chain_wins": 0,
      "secs_chain": 0.0,
      "available": false
    },
    "systemcaes": {
      "chain_wins": 0,
      "secs_chain": 0.0,
      "available": true
    },
    "systemcdes": {
      "chain_wins": 0,
      "secs_chain": 0.0,
      "available": true
    },
    "tv80": {
      "chain_wins": 0,
      "secs_chain": 0.0,
      "available": true
    },
    "usb_funct": {
      "chain_wins": 0,
      "secs_chain": 0.0,
      "available": true
    },
    "usb_phy": {
      "chain_wins": 0,
      "secs_chain": 0.0,
      "available": true
    }
  }
}

## Per-design fully preprocessed results

| Design | A0 | D0 | A | D | dA % | dD % |
| --- | --- | --- | --- | --- | --- | --- |
| aes_core | 1029.98 | 410.72 | 995.55 | 407.28 | -3.34 | -0.84 |
| arbiter | 557.72 | 999.87 | 223.64 | 261.39 | -59.90 | -73.86 |
| div | 1184.5 | 53105.06 | 1183.07 | 53053.05 | -0.12 | -0.10 |
| ethernet | 2541.41 | 543.88 | 2531.03 | 543.56 | -0.41 | -0.06 |
| iwls05_i2c | 47.66 | 303.61 | 45.08 | 290.02 | -5.41 | -4.48 |
| mem_ctrl | 1895.4 | 1519.75 | 1820.14 | 1479.36 | -3.97 | -2.66 |
| RISC | 2927.19 | 1453.77 | 2804.17 | 1392.91 | -4.20 | -4.19 |
| sasc | 27.28 | 191.2 | 26.74 | 191.2 | -1.98 | +0.00 |
| simple_spi | 36.96 | 308.22 | 35.89 | 293.36 | -2.90 | -4.82 |
| spi | 149.43 | 500.98 | 144.5 | 461.16 | -3.30 | -7.95 |
| sqrt | 1157.38 | 88015.07 | 1138.80 | 87523.64 | -1.61 | -0.56 |
| systemcaes | 483.75 | 709.03 | 425.74 | 683.44 | -11.99 | -3.61 |
| systemcdes | 131.06 | 488.85 | 121.32 | 487.52 | -7.43 | -0.27 |
| tv80 | 340.61 | 846.12 | 328.16 | 833.94 | -3.66 | -1.44 |
| usb_funct | 646.23 | 668.08 | 620.41 | 664.77 | -4.00 | -0.50 |
| usb_phy | 22.54 | 163.29 | 21.38 | 158.68 | -5.15 | -2.82 |
