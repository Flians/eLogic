Three-part paired construction-reuse experiment (v27)

Read execution_complete.json for audited completion and build_ready.json for paper QA status. Absence of either means that stage is unfinished. RESULTS.txt and paired_results.tsv are generated only after the complete campaign passes audits.

Protocol:
- Sixteen original circuits. The original AIGs, ABC executable, preprocessing script, libraries and serialized initial mappings are checked against results_v20_three_parts_chain.
- Common-input comparison: direct area-oriented emap, identical <=6-input 40-entry sublibrary and byte-identical start for ABC mfs3 -a and one-round ePMapping.
- Preprocessed-input experiment: original repeated fraig/resyn2rs/fraig/compress2rs until AND count stops decreasing (20-pass cap), original 47-entry library, independent round caps 1 and 6.
- Ablations: all sixteen circuits, cap 6, sixteen arms. The three new controls are cache64K (65536 rather than 262144 entries per native cache), noAIGREUSE (disable exact pre-mapping AIG mapped/proof reuse), and noLIBSHARE (copy the cell library into transient mapped networks). noREUSE remains the separate existing-INV fanout ablation.
- Minimize area under the fixed original delay bound. Whole-window synthesis, unmap/remap exploration and SAT DC refinement are disabled. Statistical deferrals are all rechecked in original order; only strict area dominance prunes live pricing.
- All method and ABC post-mapping runs receive 1000 seconds. The outer 3600-second guard includes setup/validation and is not additional optimization time.
- Cold: private empty persistent e-graph pool per part/arm/circuit. Warm: same configuration after the corresponding cold pool is available. All native process caches restart. OS caches are not flushed. The warm cohort shares the newly run ABC batch after byte-identity checks.
- Up to eight single-worker native jobs per cohort, plus up to eight ABC jobs on the shared host. One cold and one warm observation per configuration; elapsed ratios are descriptive, not statistically controlled speedups.

Deadline output policy:
Raw SIGALRM return codes, logs and missing completion metrics remain unchanged. Periodic and round-end rebuilt snapshots are generated inside the method's 1000-second budget. After SIGALRM, independent CEC and serialized physical area/delay audits select the best saved output, or validate the initial mapping if unavailable. TO remains incomplete. ABC cannot export a partial interrupted output and uses its initial mapping on TO. Compared with historical campaigns that selected the initial mapping for every TO, part of the selected-output improvement can therefore come from preserving partial progress.

Evidence:
execution_plan.json / setup_audit.json: frozen configuration and initial checks.
cold/inputs and warm/inputs: archived executable, inputs and source dependencies.
row.tsv, log, experiment_env.txt: per-run raw evidence.
timeout_selection.json / checkpoint_selection.json / checkpoint_cec.log: separate deadline proof.
checkpoint_archive.json: original and gzip hashes for losslessly compressed superseded snapshots; current selections remain raw. No search evidence is discarded.
storage_deduplication.json: byte-identical completed Verilog/gzip artifacts share hardlink storage after SHA256 checks. Every logical path and byte is retained; running files are excluded.
verified_profiles.json -> cold/warm verified_metrics.json -> raw SHA256 chain.
paired_results.tsv: all 608 method attempts, separate cold/warm, including status and selected implementation.
construction_counters.tsv: final native build statistics for the four construction arms; interrupted counters remain blank.
reference_rounding_audit.json: uncertainty from reconstructing ASPDAC'25 final values from published rounded starts and changes; mapped starts differ and the comparison cannot isolate post-mapping gains.
publication_sources, paper_snapshot, delivery_manifest.json: scripts, visually approved paper and immutable delivery hashes, created on final delivery.

Reproduction:
bash scripts/experiments/reproduce_paper.sh
Use a fresh EPM_ROOT and optionally EPM_ORIGINAL_ROOT / EPM_JOBS. The script rebuilds and runs both cohorts, audits all selected outputs and generates a PDF for visual QA. It does not mark visual QA complete or deliver a paper automatically.
