"""Validate completed deadline selections during the long campaign; raw rows stay immutable."""
import json,sys,time,traceback
from pathlib import Path
P=Path(__file__).resolve().parent;ROOT=P.parent
sys.path.insert(0,str(ROOT/'scripts/experiments'))
from timeout_selection import prepare
while True:
 progress={};errors=[]
 for mode in ['cold','warm']:
  base=P/mode
  if not (base/'manifest.json').exists():continue
  progress[mode]={}
  for stage in ['tab_mfs3','tab_main','ablation']:
   files=list((base/stage).glob('*/row.tsv'));counts={'rows':len(files),'complete':0,'timeout':0,'errors':0}
   for f in files:
    fields=f.read_text().strip().split('\t')
    if len(fields)!=14:errors.append(str(f)+' incomplete raw row');continue
    rc=fields[-1];counts['complete' if rc=='0' else 'timeout' if rc=='142' else 'errors']+=1
    if rc not in ['0','142']:errors.append(str(f)+' raw failure '+rc)
   progress[mode][stage]=counts
  try:prepare(base)
  except Exception:
   errors.append(mode+' selection validation:\n'+traceback.format_exc())
 (P/'progress.json').write_text(json.dumps(dict(progress=progress,errors=errors),indent=2)+'\n')
 if errors:
  (P/'validation_errors.json').write_text(json.dumps(errors,indent=2)+'\n')
  raise RuntimeError(errors)
 done=P/'execution_status.json'
 if done.exists():
  assert all(v==0 for v in json.loads(done.read_text()).values());break
 time.sleep(30)
print('All available timeout selections independently validated')
