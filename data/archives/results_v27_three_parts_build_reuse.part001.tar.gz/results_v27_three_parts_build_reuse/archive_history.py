"""Losslessly compress committed, superseded checkpoints; never touch current selections."""
import gzip,hashlib,json,re,time
from pathlib import Path
P=Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
def archive():
 count=0;saved=0
 for meta in P.glob('*/*/*/epmapping_checkpoint.json'):
  record=json.loads(meta.read_text());match=re.fullmatch(r'checkpoint_(\d+)_(\d+)\.v',record['netlist'])
  if not match:continue
  pid,last=map(int,match.groups());wd=meta.parent
  target=wd/'checkpoint_archive.json';state=json.loads(target.read_text()) if target.exists() else {'format':1,'files':{}}
  changed=False
  for f in wd.glob(f'checkpoint_{pid}_*.v'):
   m=re.fullmatch(r'checkpoint_\d+_(\d+)\.v',f.name)
   if not m or int(m[1])>=last:continue # Latest manifest is an atomic commit; future files may still be writing.
   data=f.read_bytes();packed=gzip.compress(data,compresslevel=1,mtime=0)
   z=f.with_suffix('.v.gz');tmp=z.with_suffix('.gz.tmp');tmp.write_bytes(packed);tmp.replace(z)
   assert gzip.decompress(z.read_bytes())==data
   state['files'][f.name]={'original_sha256':sha(data),'original_bytes':len(data),'archive':z.name,'gzip_sha256':sha(packed)}
   # Archive metadata commits before removal; both representations recover exactly.
   out=target.with_suffix('.json.tmp');out.write_text(json.dumps(state,indent=2)+'\n');out.replace(target)
   f.unlink();count+=1;saved+=len(data)-len(packed);changed=True
 if count:print(json.dumps({'compressed':count,'bytes_saved':saved}),flush=True)
while True:
 archive()
 if (P/'execution_status.json').exists():break
 time.sleep(30)
print('Checkpoint-history archival complete')
