"""Freeze and run both paired cohorts; warm starts each job only after its cold provenance."""
import datetime,hashlib,json,subprocess,sys
from pathlib import Path
P=Path(__file__).resolve().parent;ROOT=P.parent
sys.path.insert(0,str(ROOT/'scripts/experiments'))
from run_three_parts import GOAL,ARMS,DESIGNS
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(ROOT/'build/epmapping/epmapping_check')==sha(ROOT/'research/build_reuse_20261016/shared/epmapping_check')
plan=dict(recorded_at=datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=8))).isoformat(),method='complete-coverage rechecks, strict dominance, exact-AIG mapped/proof reuse and immutable shared mapped library',cohorts=['cold','warm'],circuits=len(DESIGNS),parts=['mfs3','main','ablation'],main_caps=[1,6],mfs3_cap=1,ablation_cap=6,ablation_arms=list(ARMS),ablation_flags=ARMS,method_goal_flags=GOAL,post_timeout_seconds=1000,abc_timeout_seconds=1000,outer_process_guard_seconds=3600,workers_per_cohort=8,engine_workers=1,maximum_native_workers=16,independent_abc_workers=8,cold_policy='empty private e-graph pool per stage/arm/design',warm_policy='reuse only paired cold pool after its result/provenance; all native caches restart',baseline_policy='fresh 1000-second ABC batch shared by byte-identical warm cohort',baseline_scope='same <=6-input sublibrary and initial netlist for mfs3; original full library for main and ablation',original_archive='results_v20_three_parts_chain',expected_engine_runs=2*(64+16*len(ARMS)),expected_method_runs=2*(48+16*len(ARMS)),expected_fresh_abc_runs=16,timeout_selection='checkpoint',checkpoint_policy='independent CEC and serialized PPA guard of best saved output; TO remains incomplete, not completed',native_cache_entries=262144,capacity_ablation_entries=65536,engine_sha256=sha(ROOT/'build/epmapping/epmapping_check'))
file=P/'execution_plan.json'
if file.exists():
 old=json.loads(file.read_text());assert all(old[k]==v for k,v in plan.items() if k!='recorded_at')
else:file.write_text(json.dumps(plan,indent=2)+'\n')
procs=[]
for mode in ['cold','warm']:
 cmd=[sys.executable,str(ROOT/'scripts/experiments/run_three_parts.py'),'--root',str(P/mode),'--original-root',str(ROOT/'results_v20_three_parts_chain'),'--jobs','8','--timeout','3600','--abc-timeout','1000','--timeout-selection','checkpoint','--profile-cache-mode',mode,'--cache-root',str(P/'cache')]
 if mode=='warm':cmd+=['--abc-source',str(P/'cold')]
 log=(P/f'{mode}_execution.log').open('a')
 procs.append((mode,subprocess.Popen(cmd,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT),log))
results={}
for mode,q,log in procs:
 results[mode]=q.wait();log.close();print(mode,results[mode],flush=True)
(P/'execution_status.json').write_text(json.dumps(results,indent=2)+'\n')
assert all(v==0 for v in results.values()),results
