"""Build only after all timed jobs and the evidence workers have finished."""
import json,subprocess,sys,time
from pathlib import Path
P=Path(__file__).resolve().parent;ROOT=P.parent
while True:
 if (P/'validation_errors.json').exists():raise RuntimeError('Selection validation failed; inspect validation_errors.json')
 if (P/'execution_status.json').exists():
  assert all(v==0 for v in json.loads((P/'execution_status.json').read_text()).values())
  history=Path('/tmp/epmapping-v27-history.log').read_text()
  validation=Path('/tmp/epmapping-v27-validation-watch.log').read_text()
  if 'Checkpoint-history archival complete' in history and 'All available timeout selections independently validated' in validation:break
 time.sleep(30)
subprocess.run([sys.executable,str(ROOT/'scripts/experiments/finalize_build_campaign.py'),'--root',str(P)],cwd=ROOT,check=True)
