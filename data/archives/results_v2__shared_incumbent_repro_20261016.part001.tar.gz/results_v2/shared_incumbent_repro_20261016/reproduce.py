import json,subprocess,sys,copy
from pathlib import Path
R=Path('/home/flynn/workplace/MIGBalance');out=Path(__file__).resolve().parent
c=json.load(open(R/'results_v2/joint_batch_full_20261016/campaign.json'));j=next(x for x in c['jobs'] if x['k']==3 and x['bench']=='priority' and x['profile']=='protected_area');argv=copy.copy(j['argv']);argv[argv.index('--audit')+1]=str(out/'audit.json');argv[argv.index('--output')+1]=str(out/'case');assert not (out/'case').exists()
(out/'command.json').write_text(json.dumps(argv,indent=2)+'\n')
with (out/'run.log').open('w') as log:subprocess.run(argv,cwd=R,stdout=log,stderr=subprocess.STDOUT,check=True)
r=json.load(open(out/'case/report.json'))['results'][0];assert r['status']=='ok' and r['measured']['cec']==1
m=json.load(open(R/'results_v2/scored_main_full_report_20261015/all_rows.json'));old=next(x['row'] for x in m if x['k']==3 and x['bench']=='priority' and x['profile']=='protected_area')['measured'];new=r['measured'];print('REAL priority3:',{'old':old,'new':new},flush=True);assert abs(new['delay']-old['delay'])<1e-4
assert new['area']<=old['area']+1e-5,'Equal-delay shared-area incumbent regressed'
