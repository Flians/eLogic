"""Verify fresh fixed-flow invocations of original priority/max symptom, not old artifact relabeling."""
import argparse,hashlib,json
from pathlib import Path
R=Path('/home/flynn/workplace/MIGBalance');load=lambda p:json.loads(Path(p).read_text());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
p=argparse.ArgumentParser();p.add_argument('--campaign',required=True);a=p.parse_args();c=load(a.campaign);m={(x['k'],x['bench']):x['row'] for x in load(R/'results_v2/scored_main_full_report_20261015/all_rows.json') if x['profile']=='protected_area'};count=0
for j in c['jobs']:
 if j['profile']!='protected_area' or j['bench'] not in ['priority','max']:continue
 assert not j.get('adopted_from');assert sha(j['report'])==j['report_sha256'];r=load(j['report'])['results'][0];old=m[j['k'],j['bench']]
 assert r['status']=='ok' and r['measured']['cec']==1 and r['input_sha256']==old['input_sha256'] and r['preprocessing']['sha256']==old['preprocessing']['sha256'];assert r['native']['heuristic_secs']<=2
 for metric in ['area','delay']:assert r['measured'][metric]<=old['measured'][metric]+1e-5,(j['name'],metric,old['measured'],r['measured'])
 count+=1;print(j['name'],r['measured'],flush=True)
assert count>=4,'Incomplete priority/max verification';print('GREEN: original equal-delay shared-area regression absent in actual new-case runs')
