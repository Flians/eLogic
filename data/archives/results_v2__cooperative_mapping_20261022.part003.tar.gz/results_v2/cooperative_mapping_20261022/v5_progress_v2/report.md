# Online local proof memo: limited-scope verification

One frozen V5 configuration for every candidate design; no winner mixing. Same binary proof-memo switch for first2 controls. All mapping search shares600s; independentCEC excluded.

|Design|Memo off A/D/T|Memo on A/D/T|Search finished (on)|
|---|---|---|---|
|adder|87.10/2569.15/19.65|87.10/2569.15/20.29|True|
|bar|248.36/168.29/22.44|248.36/168.29/21.82|True|
|log2|missing|6386.77/4010.95/600.05|False|
|max|missing|224.75/2074.58/154.13|True|
|arbiter|missing|767.22/898.75/133.78|True|
|cavlc|missing|40.65/185.87/54.33|True|
|ctrl|missing|6.97/103.17/2.93|True|
|dec|missing|30.32/65.72/5.07|True|
|i2c|missing|71.94/165.79/49.13|True|
|int2float|missing|13.13/181.00/2.39|True|
|priority|missing|66.59/2045.58/15.00|True|
|router|missing|11.68/187.47/4.11|True|

Unique designs: 12; candidate optimized: 12. Repeats: {'adder': {'runs': 3, 'identical_AD': True}, 'bar': {'runs': 3, 'identical_AD': True}}.

## Log2 version history (all failures retained)

|Version/config|A|D|T|CEC|Search finished|
|---|---:|---:|---:|---|---|
|v2_epfl_control|6103.21|3852.82|600.11|1|False|
|v2_epfl_combined|4726.97|4059.30|600.11|1|False|
|v3_epfl_combined|4756.94|4059.30|600.10|1|False|
|v3_p0|6389.84|4027.23|600.10|1|False|
|v4_epfl|6386.77|4010.95|600.11|1|False|
|v5_epfl|6386.77|4010.95|600.05|1|False|

History rows are different named versions/configurations, not a single mapper selected per design. Same-binary full20 memo ablation and log2 repeats are unfinished. Every missing/failure row remains in all_scope.csv; all baseline gates use the full required scope. Old full-flow adder area87.06 remains below the online87.10 when that current result persists; preserving batch delay seeds is not full legacy shared-area recovery.

The proof memo belongs to one frozen logical/library epoch and append-only physical identities. Targets/evidence may grow. Every newly used binding needs full source proof; cached cut witnesses are checked for retention. Driver/cycle, full physical A/D and final independentCEC remain checked. Retention pins are materialized only on demand. This is not general deferred physical Instance materialization; resumable whole area-flow/shared-cover recovery is unfinished. No main/paper adoption.
