// Benchmark "/home/flynn/workplace/MIGBalance/results_v2/fixed_4in_esyn_20261012/c880/output_from_egg4/logic" written by ABC on Mon Oct 12 15:07:39 2026

module \/home/flynn/workplace/MIGBalance/results_v2/fixed_4in_esyn_20261012/c880/output_from_egg4/logic  ( 
    G16, G6, G17, G7, G18, G19, G4, G3, G2, G1, G5, G11, G23, G20, G21, G9,
    G10, G12, G15, G22, G32, G24, G25, G26, G27, G28, G29, G30, G31, G33,
    G41, G42, G43, G44, G45, G46, G47, G48, G49, G13, G14, G55, G59, G54,
    G60, G39, G40, G52, G53, G50, G51, G58, G35, G37, G36, G56, G57, G34,
    G38, G8,
    G855, G856, G857, G858, G859, G860, G861, G862, G863, G864, G865, G866,
    G867, G868, G869, G870, G871, G872, G873, G874, G875, G876, G877, G878,
    G879, G880  );
  input  G16, G6, G17, G7, G18, G19, G4, G3, G2, G1, G5, G11, G23, G20,
    G21, G9, G10, G12, G15, G22, G32, G24, G25, G26, G27, G28, G29, G30,
    G31, G33, G41, G42, G43, G44, G45, G46, G47, G48, G49, G13, G14, G55,
    G59, G54, G60, G39, G40, G52, G53, G50, G51, G58, G35, G37, G36, G56,
    G57, G34, G38, G8;
  output G855, G856, G857, G858, G859, G860, G861, G862, G863, G864, G865,
    G866, G867, G868, G869, G870, G871, G872, G873, G874, G875, G876, G877,
    G878, G879, G880;
  wire new_n87_, new_n88_, new_n89_, new_n90_, new_n91_, new_n92_, new_n93_,
    new_n94_, new_n95_, new_n96_, new_n97_, new_n98_, new_n99_, new_n100_,
    new_n101_, new_n102_, new_n103_, new_n104_, new_n105_, new_n110_,
    new_n111_, new_n113_, new_n120_, new_n122_, new_n124_, new_n125_,
    new_n128_, new_n129_, new_n130_, new_n131_, new_n132_, new_n133_,
    new_n134_, new_n135_, new_n137_, new_n138_, new_n139_, new_n140_,
    new_n141_, new_n142_, new_n143_, new_n144_, new_n146_, new_n147_,
    new_n148_, new_n149_, new_n150_, new_n151_, new_n152_, new_n153_,
    new_n154_, new_n155_, new_n156_, new_n157_, new_n158_, new_n159_,
    new_n160_, new_n161_, new_n162_, new_n163_, new_n164_, new_n165_,
    new_n166_, new_n167_, new_n168_, new_n169_, new_n171_, new_n172_,
    new_n173_, new_n174_, new_n175_, new_n176_, new_n177_, new_n178_,
    new_n179_, new_n180_, new_n181_, new_n182_, new_n183_, new_n184_,
    new_n185_, new_n186_, new_n187_, new_n188_, new_n189_, new_n190_,
    new_n191_, new_n193_, new_n194_, new_n195_, new_n196_, new_n197_,
    new_n198_, new_n199_, new_n200_, new_n202_, new_n203_, new_n204_,
    new_n205_, new_n206_, new_n207_, new_n208_, new_n209_, new_n211_,
    new_n212_, new_n213_, new_n214_, new_n215_, new_n216_, new_n217_,
    new_n218_, new_n219_, new_n220_, new_n221_, new_n222_, new_n223_,
    new_n224_, new_n225_, new_n226_, new_n227_, new_n228_, new_n229_,
    new_n230_, new_n231_, new_n232_, new_n233_, new_n234_, new_n235_,
    new_n236_, new_n237_, new_n238_, new_n239_, new_n241_, new_n242_,
    new_n243_, new_n244_, new_n245_, new_n246_, new_n248_, new_n249_,
    new_n250_, new_n251_, new_n252_, new_n253_, new_n255_, new_n256_,
    new_n257_, new_n258_, new_n259_, new_n260_, new_n261_, new_n263_,
    new_n264_, new_n265_, new_n266_, new_n267_, new_n268_, new_n269_;
  INVx1_ASAP7_75t_R    g000(.A(G16), .Y(new_n87_));
  INVx1_ASAP7_75t_R    g001(.A(G6), .Y(new_n88_));
  INVx1_ASAP7_75t_R    g002(.A(G17), .Y(new_n89_));
  INVx1_ASAP7_75t_R    g003(.A(G7), .Y(new_n90_));
  INVx1_ASAP7_75t_R    g004(.A(G4), .Y(new_n91_));
  INVx1_ASAP7_75t_R    g005(.A(G3), .Y(new_n92_));
  INVx1_ASAP7_75t_R    g006(.A(G1), .Y(new_n93_));
  INVx1_ASAP7_75t_R    g007(.A(G11), .Y(new_n94_));
  INVx1_ASAP7_75t_R    g008(.A(G10), .Y(new_n95_));
  INVx1_ASAP7_75t_R    g009(.A(G12), .Y(new_n96_));
  INVx1_ASAP7_75t_R    g010(.A(G32), .Y(new_n97_));
  INVx1_ASAP7_75t_R    g011(.A(G41), .Y(new_n98_));
  INVx1_ASAP7_75t_R    g012(.A(G44), .Y(new_n99_));
  INVx1_ASAP7_75t_R    g013(.A(G45), .Y(new_n100_));
  INVx1_ASAP7_75t_R    g014(.A(G48), .Y(new_n101_));
  INVx1_ASAP7_75t_R    g015(.A(G52), .Y(new_n102_));
  INVx1_ASAP7_75t_R    g016(.A(G51), .Y(new_n103_));
  INVx1_ASAP7_75t_R    g017(.A(G58), .Y(new_n104_));
  INVx1_ASAP7_75t_R    g018(.A(G8), .Y(new_n105_));
  OR3x1_ASAP7_75t_R    g019(.A(new_n87_), .B(new_n88_), .C(new_n105_), .Y(G855));
  OR3x1_ASAP7_75t_R    g020(.A(new_n88_), .B(new_n90_), .C(new_n89_), .Y(G856));
  OR3x1_ASAP7_75t_R    g021(.A(new_n88_), .B(new_n90_), .C(new_n105_), .Y(G857));
  NAND2x1_ASAP7_75t_R  g022(.A(G18), .B(G19), .Y(G858));
  NAND2x1_ASAP7_75t_R  g023(.A(G2), .B(G1), .Y(new_n110_));
  INVx1_ASAP7_75t_R    g024(.A(new_n110_), .Y(new_n111_));
  OR3x1_ASAP7_75t_R    g025(.A(new_n91_), .B(new_n92_), .C(new_n110_), .Y(G859));
  AND4x2_ASAP7_75t_R   g026(.A(G4), .B(G3), .C(G1), .D(G5), .Y(new_n113_));
  AND2x2_ASAP7_75t_R   g027(.A(G857), .B(new_n113_), .Y(G860));
  AND3x1_ASAP7_75t_R   g028(.A(G16), .B(G11), .C(G17), .Y(G861));
  AND3x1_ASAP7_75t_R   g029(.A(G7), .B(G11), .C(G17), .Y(G862));
  AND3x1_ASAP7_75t_R   g030(.A(G7), .B(G11), .C(G8), .Y(G863));
  OAI21x1_ASAP7_75t_R  g031(.A1(G20), .A2(G21), .B(G23), .Y(G864));
  AND4x2_ASAP7_75t_R   g032(.A(G6), .B(G7), .C(G8), .D(new_n113_), .Y(G865));
  AND3x1_ASAP7_75t_R   g033(.A(G1), .B(G5), .C(G9), .Y(new_n120_));
  INVx1_ASAP7_75t_R    g034(.A(new_n120_), .Y(G866));
  OR3x1_ASAP7_75t_R    g035(.A(new_n92_), .B(new_n95_), .C(new_n110_), .Y(new_n122_));
  OR3x1_ASAP7_75t_R    g036(.A(new_n88_), .B(new_n96_), .C(new_n122_), .Y(G867));
  OR3x1_ASAP7_75t_R    g037(.A(new_n94_), .B(new_n96_), .C(new_n122_), .Y(new_n124_));
  INVx1_ASAP7_75t_R    g038(.A(new_n124_), .Y(new_n125_));
  NAND2x1_ASAP7_75t_R  g039(.A(G15), .B(new_n125_), .Y(G868));
  OAI21x1_ASAP7_75t_R  g040(.A1(G20), .A2(G21), .B(G22), .Y(G869));
  XOR2x2_ASAP7_75t_R   g041(.A(G28), .B(G29), .Y(new_n128_));
  XNOR2x2_ASAP7_75t_R  g042(.A(G33), .B(new_n128_), .Y(new_n129_));
  XOR2x2_ASAP7_75t_R   g043(.A(G26), .B(G27), .Y(new_n130_));
  XNOR2x2_ASAP7_75t_R  g044(.A(new_n129_), .B(new_n130_), .Y(new_n131_));
  XOR2x2_ASAP7_75t_R   g045(.A(G30), .B(G31), .Y(new_n132_));
  XOR2x2_ASAP7_75t_R   g046(.A(G24), .B(G25), .Y(new_n133_));
  XNOR2x2_ASAP7_75t_R  g047(.A(new_n97_), .B(new_n133_), .Y(new_n134_));
  XNOR2x2_ASAP7_75t_R  g048(.A(new_n132_), .B(new_n134_), .Y(new_n135_));
  XOR2x2_ASAP7_75t_R   g049(.A(new_n131_), .B(new_n135_), .Y(G870));
  XNOR2x2_ASAP7_75t_R  g050(.A(G47), .B(G48), .Y(new_n137_));
  XNOR2x2_ASAP7_75t_R  g051(.A(new_n98_), .B(G42), .Y(new_n138_));
  XOR2x2_ASAP7_75t_R   g052(.A(new_n97_), .B(new_n138_), .Y(new_n139_));
  XNOR2x2_ASAP7_75t_R  g053(.A(new_n137_), .B(new_n139_), .Y(new_n140_));
  XNOR2x2_ASAP7_75t_R  g054(.A(new_n100_), .B(G46), .Y(new_n141_));
  XOR2x2_ASAP7_75t_R   g055(.A(G49), .B(new_n141_), .Y(new_n142_));
  XOR2x2_ASAP7_75t_R   g056(.A(G43), .B(new_n99_), .Y(new_n143_));
  XNOR2x2_ASAP7_75t_R  g057(.A(new_n142_), .B(new_n143_), .Y(new_n144_));
  XOR2x2_ASAP7_75t_R   g058(.A(new_n140_), .B(new_n144_), .Y(G871));
  AOI21x1_ASAP7_75t_R  g059(.A1(G11), .A2(G40), .B(G866), .Y(new_n146_));
  AO21x1_ASAP7_75t_R   g060(.A1(G4), .A2(new_n146_), .B(new_n93_), .Y(new_n147_));
  OR4x2_ASAP7_75t_R    g061(.A(new_n87_), .B(new_n88_), .C(new_n89_), .D(G866), .Y(new_n148_));
  OR3x1_ASAP7_75t_R    g062(.A(new_n95_), .B(G60), .C(new_n148_), .Y(new_n149_));
  INVx1_ASAP7_75t_R    g063(.A(new_n149_), .Y(new_n150_));
  OA211x2_ASAP7_75t_R  g064(.A1(new_n91_), .A2(new_n105_), .B(G11), .C(G40), .Y(new_n151_));
  OA21x2_ASAP7_75t_R   g065(.A1(G4), .A2(G8), .B(new_n151_), .Y(new_n152_));
  OR3x1_ASAP7_75t_R    g066(.A(new_n87_), .B(new_n94_), .C(new_n105_), .Y(new_n153_));
  AND4x2_ASAP7_75t_R   g067(.A(G4), .B(G9), .C(new_n111_), .D(new_n153_), .Y(new_n154_));
  AO21x1_ASAP7_75t_R   g068(.A1(new_n120_), .A2(new_n152_), .B(new_n154_), .Y(new_n155_));
  AO21x1_ASAP7_75t_R   g069(.A1(G31), .A2(new_n155_), .B(new_n150_), .Y(new_n156_));
  AO21x1_ASAP7_75t_R   g070(.A1(G39), .A2(new_n147_), .B(new_n156_), .Y(new_n157_));
  INVx1_ASAP7_75t_R    g071(.A(new_n157_), .Y(new_n158_));
  NOR2x1_ASAP7_75t_R   g072(.A(new_n101_), .B(new_n158_), .Y(new_n159_));
  INVx1_ASAP7_75t_R    g073(.A(new_n159_), .Y(new_n160_));
  AO21x1_ASAP7_75t_R   g074(.A1(new_n101_), .A2(new_n158_), .B(new_n159_), .Y(new_n161_));
  OA21x2_ASAP7_75t_R   g075(.A1(G48), .A2(new_n157_), .B(G58), .Y(new_n162_));
  AO21x1_ASAP7_75t_R   g076(.A1(new_n160_), .A2(new_n162_), .B(new_n103_), .Y(new_n163_));
  AO21x1_ASAP7_75t_R   g077(.A1(new_n104_), .A2(new_n161_), .B(new_n163_), .Y(new_n164_));
  AO22x1_ASAP7_75t_R   g078(.A1(G55), .A2(G59), .B1(G30), .B2(G50), .Y(new_n165_));
  AND4x2_ASAP7_75t_R   g079(.A(G13), .B(G8), .C(G14), .D(new_n125_), .Y(new_n166_));
  AO21x1_ASAP7_75t_R   g080(.A1(G48), .A2(new_n166_), .B(new_n165_), .Y(new_n167_));
  AO21x1_ASAP7_75t_R   g081(.A1(G48), .A2(G53), .B(G54), .Y(new_n168_));
  AOI21x1_ASAP7_75t_R  g082(.A1(new_n157_), .A2(new_n168_), .B(new_n167_), .Y(new_n169_));
  OA211x2_ASAP7_75t_R  g083(.A1(new_n102_), .A2(new_n161_), .B(new_n169_), .C(new_n164_), .Y(G872));
  AO21x1_ASAP7_75t_R   g084(.A1(G36), .A2(new_n147_), .B(new_n150_), .Y(new_n171_));
  AO21x1_ASAP7_75t_R   g085(.A1(G29), .A2(new_n155_), .B(new_n171_), .Y(new_n172_));
  NOR2x1_ASAP7_75t_R   g086(.A(G46), .B(new_n172_), .Y(new_n173_));
  AO21x1_ASAP7_75t_R   g087(.A1(G37), .A2(new_n147_), .B(new_n150_), .Y(new_n174_));
  AO21x1_ASAP7_75t_R   g088(.A1(G30), .A2(new_n155_), .B(new_n174_), .Y(new_n175_));
  NAND2x1_ASAP7_75t_R  g089(.A(G47), .B(new_n175_), .Y(new_n176_));
  NAND2x1_ASAP7_75t_R  g090(.A(G46), .B(new_n172_), .Y(new_n177_));
  NOR2x1_ASAP7_75t_R   g091(.A(G47), .B(new_n175_), .Y(new_n178_));
  AO21x1_ASAP7_75t_R   g092(.A1(G48), .A2(new_n157_), .B(new_n162_), .Y(new_n179_));
  INVx1_ASAP7_75t_R    g093(.A(new_n179_), .Y(new_n180_));
  OR3x1_ASAP7_75t_R    g094(.A(new_n173_), .B(new_n178_), .C(new_n180_), .Y(new_n181_));
  OA211x2_ASAP7_75t_R  g095(.A1(new_n173_), .A2(new_n176_), .B(new_n177_), .C(new_n181_), .Y(new_n182_));
  AO21x1_ASAP7_75t_R   g096(.A1(G35), .A2(new_n147_), .B(new_n150_), .Y(new_n183_));
  AO21x1_ASAP7_75t_R   g097(.A1(G28), .A2(new_n155_), .B(new_n183_), .Y(new_n184_));
  INVx1_ASAP7_75t_R    g098(.A(new_n184_), .Y(new_n185_));
  AO22x1_ASAP7_75t_R   g099(.A1(G45), .A2(new_n184_), .B1(new_n100_), .B2(new_n185_), .Y(new_n186_));
  OAI21x1_ASAP7_75t_R  g100(.A1(new_n182_), .A2(new_n186_), .B(G51), .Y(new_n187_));
  AO21x1_ASAP7_75t_R   g101(.A1(new_n182_), .A2(new_n186_), .B(new_n187_), .Y(new_n188_));
  AO21x1_ASAP7_75t_R   g102(.A1(G45), .A2(G53), .B(G54), .Y(new_n189_));
  AO22x1_ASAP7_75t_R   g103(.A1(G27), .A2(G50), .B1(G45), .B2(new_n166_), .Y(new_n190_));
  AOI21x1_ASAP7_75t_R  g104(.A1(new_n184_), .A2(new_n189_), .B(new_n190_), .Y(new_n191_));
  OA211x2_ASAP7_75t_R  g105(.A1(new_n102_), .A2(new_n186_), .B(new_n191_), .C(new_n188_), .Y(G873));
  AO21x1_ASAP7_75t_R   g106(.A1(G46), .A2(new_n172_), .B(new_n173_), .Y(new_n193_));
  AO22x1_ASAP7_75t_R   g107(.A1(G55), .A2(G56), .B1(G28), .B2(G50), .Y(new_n194_));
  AO21x1_ASAP7_75t_R   g108(.A1(G46), .A2(new_n166_), .B(new_n194_), .Y(new_n195_));
  AO21x1_ASAP7_75t_R   g109(.A1(G46), .A2(G53), .B(G54), .Y(new_n196_));
  AOI21x1_ASAP7_75t_R  g110(.A1(new_n172_), .A2(new_n196_), .B(new_n195_), .Y(new_n197_));
  OA21x2_ASAP7_75t_R   g111(.A1(new_n178_), .A2(new_n180_), .B(new_n176_), .Y(new_n198_));
  OAI21x1_ASAP7_75t_R  g112(.A1(new_n193_), .A2(new_n198_), .B(G51), .Y(new_n199_));
  AO21x1_ASAP7_75t_R   g113(.A1(new_n193_), .A2(new_n198_), .B(new_n199_), .Y(new_n200_));
  OA211x2_ASAP7_75t_R  g114(.A1(new_n102_), .A2(new_n193_), .B(new_n197_), .C(new_n200_), .Y(G874));
  AO21x1_ASAP7_75t_R   g115(.A1(G47), .A2(new_n175_), .B(new_n178_), .Y(new_n202_));
  INVx1_ASAP7_75t_R    g116(.A(new_n202_), .Y(new_n203_));
  AO21x1_ASAP7_75t_R   g117(.A1(new_n180_), .A2(new_n202_), .B(new_n103_), .Y(new_n204_));
  AO21x1_ASAP7_75t_R   g118(.A1(new_n179_), .A2(new_n203_), .B(new_n204_), .Y(new_n205_));
  AO21x1_ASAP7_75t_R   g119(.A1(G47), .A2(G53), .B(G54), .Y(new_n206_));
  AO22x1_ASAP7_75t_R   g120(.A1(G29), .A2(G50), .B1(G55), .B2(G57), .Y(new_n207_));
  AO21x1_ASAP7_75t_R   g121(.A1(G47), .A2(new_n166_), .B(new_n207_), .Y(new_n208_));
  AOI21x1_ASAP7_75t_R  g122(.A1(new_n175_), .A2(new_n206_), .B(new_n208_), .Y(new_n209_));
  OA211x2_ASAP7_75t_R  g123(.A1(new_n102_), .A2(new_n202_), .B(new_n209_), .C(new_n205_), .Y(G875));
  AND2x2_ASAP7_75t_R   g124(.A(G10), .B(new_n146_), .Y(new_n211_));
  OR3x1_ASAP7_75t_R    g125(.A(new_n91_), .B(G60), .C(new_n148_), .Y(new_n212_));
  INVx1_ASAP7_75t_R    g126(.A(new_n212_), .Y(new_n213_));
  AO21x1_ASAP7_75t_R   g127(.A1(G2), .A2(G34), .B(new_n213_), .Y(new_n214_));
  AO21x1_ASAP7_75t_R   g128(.A1(G35), .A2(new_n211_), .B(new_n214_), .Y(new_n215_));
  AO21x1_ASAP7_75t_R   g129(.A1(G24), .A2(new_n155_), .B(new_n215_), .Y(new_n216_));
  INVx1_ASAP7_75t_R    g130(.A(new_n216_), .Y(new_n217_));
  AO21x1_ASAP7_75t_R   g131(.A1(new_n100_), .A2(new_n185_), .B(new_n182_), .Y(new_n218_));
  OA21x2_ASAP7_75t_R   g132(.A1(new_n100_), .A2(new_n185_), .B(new_n218_), .Y(new_n219_));
  AO21x1_ASAP7_75t_R   g133(.A1(G34), .A2(G38), .B(new_n213_), .Y(new_n220_));
  AO21x1_ASAP7_75t_R   g134(.A1(G39), .A2(new_n211_), .B(new_n220_), .Y(new_n221_));
  AO21x1_ASAP7_75t_R   g135(.A1(G27), .A2(new_n155_), .B(new_n221_), .Y(new_n222_));
  INVx1_ASAP7_75t_R    g136(.A(new_n222_), .Y(new_n223_));
  AO21x1_ASAP7_75t_R   g137(.A1(new_n99_), .A2(new_n223_), .B(new_n219_), .Y(new_n224_));
  AO21x1_ASAP7_75t_R   g138(.A1(G4), .A2(G34), .B(new_n213_), .Y(new_n225_));
  AO21x1_ASAP7_75t_R   g139(.A1(G37), .A2(new_n211_), .B(new_n225_), .Y(new_n226_));
  AO21x1_ASAP7_75t_R   g140(.A1(G26), .A2(new_n155_), .B(new_n226_), .Y(new_n227_));
  NOR2x1_ASAP7_75t_R   g141(.A(G43), .B(new_n227_), .Y(new_n228_));
  AO21x1_ASAP7_75t_R   g142(.A1(G9), .A2(G34), .B(new_n213_), .Y(new_n229_));
  AO21x1_ASAP7_75t_R   g143(.A1(G36), .A2(new_n211_), .B(new_n229_), .Y(new_n230_));
  AO21x1_ASAP7_75t_R   g144(.A1(G25), .A2(new_n155_), .B(new_n230_), .Y(new_n231_));
  NOR2x1_ASAP7_75t_R   g145(.A(G42), .B(new_n231_), .Y(new_n232_));
  OR3x1_ASAP7_75t_R    g146(.A(new_n228_), .B(new_n232_), .C(new_n224_), .Y(new_n233_));
  NAND2x1_ASAP7_75t_R  g147(.A(G42), .B(new_n231_), .Y(new_n234_));
  NOR2x1_ASAP7_75t_R   g148(.A(new_n99_), .B(new_n223_), .Y(new_n235_));
  AO21x1_ASAP7_75t_R   g149(.A1(G43), .A2(new_n227_), .B(new_n235_), .Y(new_n236_));
  OAI21x1_ASAP7_75t_R  g150(.A1(G43), .A2(new_n227_), .B(new_n236_), .Y(new_n237_));
  OA211x2_ASAP7_75t_R  g151(.A1(new_n232_), .A2(new_n237_), .B(new_n234_), .C(new_n233_), .Y(new_n238_));
  AO21x1_ASAP7_75t_R   g152(.A1(new_n98_), .A2(new_n217_), .B(new_n238_), .Y(new_n239_));
  OA21x2_ASAP7_75t_R   g153(.A1(new_n98_), .A2(new_n217_), .B(new_n239_), .Y(G876));
  AO21x1_ASAP7_75t_R   g154(.A1(new_n99_), .A2(new_n223_), .B(new_n235_), .Y(new_n241_));
  OAI21x1_ASAP7_75t_R  g155(.A1(new_n219_), .A2(new_n241_), .B(G51), .Y(new_n242_));
  AO21x1_ASAP7_75t_R   g156(.A1(new_n219_), .A2(new_n241_), .B(new_n242_), .Y(new_n243_));
  AO22x1_ASAP7_75t_R   g157(.A1(G26), .A2(G50), .B1(G44), .B2(new_n166_), .Y(new_n244_));
  AO21x1_ASAP7_75t_R   g158(.A1(G44), .A2(G53), .B(G54), .Y(new_n245_));
  AOI21x1_ASAP7_75t_R  g159(.A1(new_n222_), .A2(new_n245_), .B(new_n244_), .Y(new_n246_));
  OA211x2_ASAP7_75t_R  g160(.A1(new_n102_), .A2(new_n241_), .B(new_n246_), .C(new_n243_), .Y(G877));
  AO22x1_ASAP7_75t_R   g161(.A1(G41), .A2(new_n216_), .B1(new_n98_), .B2(new_n217_), .Y(new_n248_));
  OAI21x1_ASAP7_75t_R  g162(.A1(new_n238_), .A2(new_n248_), .B(G51), .Y(new_n249_));
  AO21x1_ASAP7_75t_R   g163(.A1(new_n238_), .A2(new_n248_), .B(new_n249_), .Y(new_n250_));
  AO22x1_ASAP7_75t_R   g164(.A1(G41), .A2(new_n166_), .B1(G60), .B2(G50), .Y(new_n251_));
  AO21x1_ASAP7_75t_R   g165(.A1(G41), .A2(G53), .B(G54), .Y(new_n252_));
  AOI21x1_ASAP7_75t_R  g166(.A1(new_n216_), .A2(new_n252_), .B(new_n251_), .Y(new_n253_));
  OA211x2_ASAP7_75t_R  g167(.A1(new_n102_), .A2(new_n248_), .B(new_n253_), .C(new_n250_), .Y(G878));
  AO21x1_ASAP7_75t_R   g168(.A1(G42), .A2(new_n231_), .B(new_n232_), .Y(new_n255_));
  AO22x1_ASAP7_75t_R   g169(.A1(G42), .A2(new_n166_), .B1(G24), .B2(G50), .Y(new_n256_));
  AO21x1_ASAP7_75t_R   g170(.A1(G42), .A2(G53), .B(G54), .Y(new_n257_));
  AOI21x1_ASAP7_75t_R  g171(.A1(new_n231_), .A2(new_n257_), .B(new_n256_), .Y(new_n258_));
  OA21x2_ASAP7_75t_R   g172(.A1(new_n224_), .A2(new_n228_), .B(new_n237_), .Y(new_n259_));
  OAI21x1_ASAP7_75t_R  g173(.A1(new_n255_), .A2(new_n259_), .B(G51), .Y(new_n260_));
  AO21x1_ASAP7_75t_R   g174(.A1(new_n255_), .A2(new_n259_), .B(new_n260_), .Y(new_n261_));
  OA211x2_ASAP7_75t_R  g175(.A1(new_n102_), .A2(new_n255_), .B(new_n258_), .C(new_n261_), .Y(G879));
  AO21x1_ASAP7_75t_R   g176(.A1(G43), .A2(new_n227_), .B(new_n228_), .Y(new_n263_));
  AO21x1_ASAP7_75t_R   g177(.A1(G43), .A2(G53), .B(G54), .Y(new_n264_));
  AO22x1_ASAP7_75t_R   g178(.A1(G25), .A2(G50), .B1(G43), .B2(new_n166_), .Y(new_n265_));
  AOI21x1_ASAP7_75t_R  g179(.A1(new_n227_), .A2(new_n264_), .B(new_n265_), .Y(new_n266_));
  OA21x2_ASAP7_75t_R   g180(.A1(new_n99_), .A2(new_n223_), .B(new_n224_), .Y(new_n267_));
  OAI21x1_ASAP7_75t_R  g181(.A1(new_n263_), .A2(new_n267_), .B(G51), .Y(new_n268_));
  AO21x1_ASAP7_75t_R   g182(.A1(new_n263_), .A2(new_n267_), .B(new_n268_), .Y(new_n269_));
  OA211x2_ASAP7_75t_R  g183(.A1(new_n102_), .A2(new_n263_), .B(new_n266_), .C(new_n269_), .Y(G880));
endmodule


