// Benchmark "/home/flynn/workplace/MIGBalance/results_v2/fixed_4in_esyn_20261012/c499/output_from_egg5/logic" written by ABC on Mon Oct 12 15:07:00 2026

module \/home/flynn/workplace/MIGBalance/results_v2/fixed_4in_esyn_20261012/c499/output_from_egg5/logic  ( 
    G2, G6, G10, G34, G41, G25, G26, G27, G28, G29, G30, G31, G32, G4, G8,
    G12, G16, G36, G21, G22, G23, G24, G3, G7, G11, G15, G35, G17, G18,
    G19, G20, G1, G5, G9, G13, G33, G40, G39, G38, G37, G14,
    G481, G482, G480, G468, G469, G470, G471, G472, G473, G474, G475, G476,
    G477, G478, G479, G483, G484, G485, G486, G487, G488, G489, G490, G491,
    G492, G493, G494, G495, G496, G497, G498, G499  );
  input  G2, G6, G10, G34, G41, G25, G26, G27, G28, G29, G30, G31, G32,
    G4, G8, G12, G16, G36, G21, G22, G23, G24, G3, G7, G11, G15, G35, G17,
    G18, G19, G20, G1, G5, G9, G13, G33, G40, G39, G38, G37, G14;
  output G481, G482, G480, G468, G469, G470, G471, G472, G473, G474, G475,
    G476, G477, G478, G479, G483, G484, G485, G486, G487, G488, G489, G490,
    G491, G492, G493, G494, G495, G496, G497, G498, G499;
  wire new_n74_, new_n75_, new_n76_, new_n77_, new_n78_, new_n79_, new_n80_,
    new_n81_, new_n82_, new_n83_, new_n84_, new_n85_, new_n86_, new_n87_,
    new_n88_, new_n89_, new_n90_, new_n91_, new_n92_, new_n93_, new_n94_,
    new_n95_, new_n96_, new_n97_, new_n98_, new_n99_, new_n100_, new_n101_,
    new_n102_, new_n103_, new_n104_, new_n105_, new_n106_, new_n107_,
    new_n108_, new_n109_, new_n110_, new_n111_, new_n112_, new_n113_,
    new_n114_, new_n115_, new_n116_, new_n117_, new_n118_, new_n119_,
    new_n120_, new_n121_, new_n122_, new_n123_, new_n124_, new_n125_,
    new_n126_, new_n127_, new_n128_, new_n129_, new_n130_, new_n131_,
    new_n132_, new_n133_, new_n134_, new_n135_, new_n136_, new_n137_,
    new_n138_, new_n139_, new_n140_, new_n141_, new_n142_, new_n143_,
    new_n144_, new_n145_, new_n146_, new_n147_, new_n148_, new_n149_,
    new_n150_, new_n151_, new_n152_, new_n153_, new_n154_, new_n155_,
    new_n156_, new_n157_, new_n158_, new_n159_, new_n160_, new_n161_,
    new_n162_, new_n163_, new_n164_, new_n165_, new_n166_, new_n167_,
    new_n168_, new_n169_, new_n170_, new_n171_, new_n172_, new_n173_,
    new_n174_, new_n175_, new_n176_, new_n177_, new_n178_, new_n179_,
    new_n180_, new_n181_, new_n182_, new_n183_, new_n184_, new_n185_,
    new_n186_, new_n187_, new_n188_, new_n189_, new_n190_, new_n191_,
    new_n192_, new_n193_, new_n194_, new_n195_, new_n196_, new_n197_,
    new_n198_, new_n199_, new_n200_, new_n201_, new_n202_, new_n204_,
    new_n206_, new_n208_, new_n209_, new_n210_, new_n212_, new_n214_,
    new_n216_, new_n218_, new_n219_, new_n221_, new_n223_, new_n225_,
    new_n227_, new_n228_, new_n230_, new_n232_, new_n234_, new_n236_,
    new_n238_, new_n239_, new_n240_, new_n241_, new_n242_, new_n243_,
    new_n244_, new_n245_, new_n247_, new_n249_, new_n251_, new_n253_,
    new_n254_, new_n255_, new_n257_, new_n259_, new_n261_, new_n263_,
    new_n265_, new_n267_, new_n269_, new_n271_, new_n273_, new_n275_,
    new_n277_;
  INVx1_ASAP7_75t_R    g000(.A(G2), .Y(new_n74_));
  INVx1_ASAP7_75t_R    g001(.A(G6), .Y(new_n75_));
  INVx1_ASAP7_75t_R    g002(.A(G10), .Y(new_n76_));
  INVx1_ASAP7_75t_R    g003(.A(G25), .Y(new_n77_));
  INVx1_ASAP7_75t_R    g004(.A(G26), .Y(new_n78_));
  INVx1_ASAP7_75t_R    g005(.A(G27), .Y(new_n79_));
  INVx1_ASAP7_75t_R    g006(.A(G28), .Y(new_n80_));
  INVx1_ASAP7_75t_R    g007(.A(G29), .Y(new_n81_));
  INVx1_ASAP7_75t_R    g008(.A(G30), .Y(new_n82_));
  INVx1_ASAP7_75t_R    g009(.A(G31), .Y(new_n83_));
  INVx1_ASAP7_75t_R    g010(.A(G32), .Y(new_n84_));
  INVx1_ASAP7_75t_R    g011(.A(G4), .Y(new_n85_));
  INVx1_ASAP7_75t_R    g012(.A(G8), .Y(new_n86_));
  INVx1_ASAP7_75t_R    g013(.A(G12), .Y(new_n87_));
  INVx1_ASAP7_75t_R    g014(.A(G16), .Y(new_n88_));
  INVx1_ASAP7_75t_R    g015(.A(G21), .Y(new_n89_));
  INVx1_ASAP7_75t_R    g016(.A(G22), .Y(new_n90_));
  INVx1_ASAP7_75t_R    g017(.A(G23), .Y(new_n91_));
  INVx1_ASAP7_75t_R    g018(.A(G24), .Y(new_n92_));
  INVx1_ASAP7_75t_R    g019(.A(G3), .Y(new_n93_));
  INVx1_ASAP7_75t_R    g020(.A(G7), .Y(new_n94_));
  INVx1_ASAP7_75t_R    g021(.A(G11), .Y(new_n95_));
  INVx1_ASAP7_75t_R    g022(.A(G15), .Y(new_n96_));
  INVx1_ASAP7_75t_R    g023(.A(G17), .Y(new_n97_));
  INVx1_ASAP7_75t_R    g024(.A(G18), .Y(new_n98_));
  INVx1_ASAP7_75t_R    g025(.A(G19), .Y(new_n99_));
  INVx1_ASAP7_75t_R    g026(.A(G20), .Y(new_n100_));
  INVx1_ASAP7_75t_R    g027(.A(G1), .Y(new_n101_));
  INVx1_ASAP7_75t_R    g028(.A(G5), .Y(new_n102_));
  INVx1_ASAP7_75t_R    g029(.A(G9), .Y(new_n103_));
  INVx1_ASAP7_75t_R    g030(.A(G13), .Y(new_n104_));
  INVx1_ASAP7_75t_R    g031(.A(G14), .Y(new_n105_));
  AO22x1_ASAP7_75t_R   g032(.A1(new_n81_), .A2(new_n82_), .B1(G29), .B2(G30), .Y(new_n106_));
  AO22x1_ASAP7_75t_R   g033(.A1(new_n83_), .A2(G32), .B1(G31), .B2(new_n84_), .Y(new_n107_));
  XOR2x2_ASAP7_75t_R   g034(.A(new_n106_), .B(new_n107_), .Y(new_n108_));
  AO22x1_ASAP7_75t_R   g035(.A1(new_n74_), .A2(new_n75_), .B1(G2), .B2(G6), .Y(new_n109_));
  AO22x1_ASAP7_75t_R   g036(.A1(G10), .A2(new_n105_), .B1(new_n76_), .B2(G14), .Y(new_n110_));
  XOR2x2_ASAP7_75t_R   g037(.A(new_n109_), .B(new_n110_), .Y(new_n111_));
  XOR2x2_ASAP7_75t_R   g038(.A(new_n108_), .B(new_n111_), .Y(new_n112_));
  AO22x1_ASAP7_75t_R   g039(.A1(new_n79_), .A2(G28), .B1(G27), .B2(new_n80_), .Y(new_n113_));
  AO22x1_ASAP7_75t_R   g040(.A1(G25), .A2(G26), .B1(new_n77_), .B2(new_n78_), .Y(new_n114_));
  XOR2x2_ASAP7_75t_R   g041(.A(new_n113_), .B(new_n114_), .Y(new_n115_));
  AND2x2_ASAP7_75t_R   g042(.A(G34), .B(G41), .Y(new_n116_));
  XNOR2x2_ASAP7_75t_R  g043(.A(new_n115_), .B(new_n116_), .Y(new_n117_));
  XOR2x2_ASAP7_75t_R   g044(.A(new_n112_), .B(new_n117_), .Y(new_n118_));
  INVx1_ASAP7_75t_R    g045(.A(new_n118_), .Y(new_n119_));
  AOI22x1_ASAP7_75t_R  g046(.A1(G6), .A2(G5), .B1(new_n75_), .B2(new_n102_), .Y(new_n120_));
  AOI22x1_ASAP7_75t_R  g047(.A1(G8), .A2(new_n94_), .B1(new_n86_), .B2(G7), .Y(new_n121_));
  XNOR2x2_ASAP7_75t_R  g048(.A(new_n120_), .B(new_n121_), .Y(new_n122_));
  NAND2x1_ASAP7_75t_R  g049(.A(G41), .B(G37), .Y(new_n123_));
  XOR2x2_ASAP7_75t_R   g050(.A(new_n122_), .B(new_n123_), .Y(new_n124_));
  AO22x1_ASAP7_75t_R   g051(.A1(G4), .A2(new_n93_), .B1(new_n85_), .B2(G3), .Y(new_n125_));
  AO22x1_ASAP7_75t_R   g052(.A1(G2), .A2(G1), .B1(new_n74_), .B2(new_n101_), .Y(new_n126_));
  XOR2x2_ASAP7_75t_R   g053(.A(new_n125_), .B(new_n126_), .Y(new_n127_));
  AO22x1_ASAP7_75t_R   g054(.A1(new_n77_), .A2(G29), .B1(G25), .B2(new_n81_), .Y(new_n128_));
  AOI22x1_ASAP7_75t_R  g055(.A1(G21), .A2(G17), .B1(new_n89_), .B2(new_n97_), .Y(new_n129_));
  XNOR2x2_ASAP7_75t_R  g056(.A(new_n128_), .B(new_n129_), .Y(new_n130_));
  XOR2x2_ASAP7_75t_R   g057(.A(new_n127_), .B(new_n130_), .Y(new_n131_));
  XOR2x2_ASAP7_75t_R   g058(.A(new_n124_), .B(new_n131_), .Y(new_n132_));
  INVx1_ASAP7_75t_R    g059(.A(new_n132_), .Y(new_n133_));
  AOI22x1_ASAP7_75t_R  g060(.A1(new_n88_), .A2(G15), .B1(G16), .B2(new_n96_), .Y(new_n134_));
  AOI22x1_ASAP7_75t_R  g061(.A1(new_n104_), .A2(new_n105_), .B1(G13), .B2(G14), .Y(new_n135_));
  XNOR2x2_ASAP7_75t_R  g062(.A(new_n134_), .B(new_n135_), .Y(new_n136_));
  NAND2x1_ASAP7_75t_R  g063(.A(G41), .B(G38), .Y(new_n137_));
  XOR2x2_ASAP7_75t_R   g064(.A(new_n136_), .B(new_n137_), .Y(new_n138_));
  AO22x1_ASAP7_75t_R   g065(.A1(G10), .A2(G9), .B1(new_n76_), .B2(new_n103_), .Y(new_n139_));
  AO22x1_ASAP7_75t_R   g066(.A1(G12), .A2(new_n95_), .B1(new_n87_), .B2(G11), .Y(new_n140_));
  XOR2x2_ASAP7_75t_R   g067(.A(new_n139_), .B(new_n140_), .Y(new_n141_));
  AOI22x1_ASAP7_75t_R  g068(.A1(G22), .A2(G18), .B1(new_n90_), .B2(new_n98_), .Y(new_n142_));
  AO22x1_ASAP7_75t_R   g069(.A1(new_n78_), .A2(G30), .B1(G26), .B2(new_n82_), .Y(new_n143_));
  XOR2x2_ASAP7_75t_R   g070(.A(new_n142_), .B(new_n143_), .Y(new_n144_));
  XNOR2x2_ASAP7_75t_R  g071(.A(new_n141_), .B(new_n144_), .Y(new_n145_));
  XOR2x2_ASAP7_75t_R   g072(.A(new_n138_), .B(new_n145_), .Y(new_n146_));
  OR2x4_ASAP7_75t_R    g073(.A(new_n133_), .B(new_n146_), .Y(new_n147_));
  AO22x1_ASAP7_75t_R   g074(.A1(new_n91_), .A2(new_n99_), .B1(G23), .B2(G19), .Y(new_n148_));
  AO22x1_ASAP7_75t_R   g075(.A1(G27), .A2(new_n83_), .B1(new_n79_), .B2(G31), .Y(new_n149_));
  XNOR2x2_ASAP7_75t_R  g076(.A(new_n148_), .B(new_n149_), .Y(new_n150_));
  XNOR2x2_ASAP7_75t_R  g077(.A(new_n141_), .B(new_n150_), .Y(new_n151_));
  NAND2x1_ASAP7_75t_R  g078(.A(G41), .B(G39), .Y(new_n152_));
  XOR2x2_ASAP7_75t_R   g079(.A(new_n127_), .B(new_n152_), .Y(new_n153_));
  XOR2x2_ASAP7_75t_R   g080(.A(new_n151_), .B(new_n153_), .Y(new_n154_));
  INVx1_ASAP7_75t_R    g081(.A(new_n154_), .Y(new_n155_));
  AOI22x1_ASAP7_75t_R  g082(.A1(new_n80_), .A2(G32), .B1(G28), .B2(new_n84_), .Y(new_n156_));
  AOI22x1_ASAP7_75t_R  g083(.A1(new_n92_), .A2(new_n100_), .B1(G24), .B2(G20), .Y(new_n157_));
  XOR2x2_ASAP7_75t_R   g084(.A(new_n156_), .B(new_n157_), .Y(new_n158_));
  XNOR2x2_ASAP7_75t_R  g085(.A(new_n136_), .B(new_n158_), .Y(new_n159_));
  NAND2x1_ASAP7_75t_R  g086(.A(G41), .B(G40), .Y(new_n160_));
  XNOR2x2_ASAP7_75t_R  g087(.A(new_n122_), .B(new_n160_), .Y(new_n161_));
  XOR2x2_ASAP7_75t_R   g088(.A(new_n159_), .B(new_n161_), .Y(new_n162_));
  INVx1_ASAP7_75t_R    g089(.A(new_n162_), .Y(new_n163_));
  AOI22x1_ASAP7_75t_R  g090(.A1(G17), .A2(G18), .B1(new_n97_), .B2(new_n98_), .Y(new_n164_));
  AOI22x1_ASAP7_75t_R  g091(.A1(new_n99_), .A2(G20), .B1(G19), .B2(new_n100_), .Y(new_n165_));
  XOR2x2_ASAP7_75t_R   g092(.A(new_n164_), .B(new_n165_), .Y(new_n166_));
  AO22x1_ASAP7_75t_R   g093(.A1(G9), .A2(new_n104_), .B1(new_n103_), .B2(G13), .Y(new_n167_));
  AOI22x1_ASAP7_75t_R  g094(.A1(new_n101_), .A2(new_n102_), .B1(G1), .B2(G5), .Y(new_n168_));
  XNOR2x2_ASAP7_75t_R  g095(.A(new_n167_), .B(new_n168_), .Y(new_n169_));
  XOR2x2_ASAP7_75t_R   g096(.A(new_n166_), .B(new_n169_), .Y(new_n170_));
  AO22x1_ASAP7_75t_R   g097(.A1(G23), .A2(new_n92_), .B1(new_n91_), .B2(G24), .Y(new_n171_));
  AO22x1_ASAP7_75t_R   g098(.A1(G21), .A2(G22), .B1(new_n89_), .B2(new_n90_), .Y(new_n172_));
  XNOR2x2_ASAP7_75t_R  g099(.A(new_n171_), .B(new_n172_), .Y(new_n173_));
  NAND2x1_ASAP7_75t_R  g100(.A(G41), .B(G33), .Y(new_n174_));
  XOR2x2_ASAP7_75t_R   g101(.A(new_n173_), .B(new_n174_), .Y(new_n175_));
  XOR2x2_ASAP7_75t_R   g102(.A(new_n170_), .B(new_n175_), .Y(new_n176_));
  AND2x2_ASAP7_75t_R   g103(.A(G41), .B(G36), .Y(new_n177_));
  XNOR2x2_ASAP7_75t_R  g104(.A(new_n108_), .B(new_n177_), .Y(new_n178_));
  AO22x1_ASAP7_75t_R   g105(.A1(G4), .A2(G8), .B1(new_n85_), .B2(new_n86_), .Y(new_n179_));
  AO22x1_ASAP7_75t_R   g106(.A1(new_n87_), .A2(G16), .B1(G12), .B2(new_n88_), .Y(new_n180_));
  XOR2x2_ASAP7_75t_R   g107(.A(new_n179_), .B(new_n180_), .Y(new_n181_));
  XNOR2x2_ASAP7_75t_R  g108(.A(new_n173_), .B(new_n181_), .Y(new_n182_));
  XOR2x2_ASAP7_75t_R   g109(.A(new_n178_), .B(new_n182_), .Y(new_n183_));
  INVx1_ASAP7_75t_R    g110(.A(new_n183_), .Y(new_n184_));
  NAND2x1_ASAP7_75t_R  g111(.A(G41), .B(G35), .Y(new_n185_));
  XNOR2x2_ASAP7_75t_R  g112(.A(new_n115_), .B(new_n185_), .Y(new_n186_));
  AO22x1_ASAP7_75t_R   g113(.A1(G3), .A2(G7), .B1(new_n93_), .B2(new_n94_), .Y(new_n187_));
  AO22x1_ASAP7_75t_R   g114(.A1(G11), .A2(new_n96_), .B1(new_n95_), .B2(G15), .Y(new_n188_));
  XOR2x2_ASAP7_75t_R   g115(.A(new_n187_), .B(new_n188_), .Y(new_n189_));
  XNOR2x2_ASAP7_75t_R  g116(.A(new_n166_), .B(new_n189_), .Y(new_n190_));
  XOR2x2_ASAP7_75t_R   g117(.A(new_n186_), .B(new_n190_), .Y(new_n191_));
  INVx1_ASAP7_75t_R    g118(.A(new_n191_), .Y(new_n192_));
  NOR2x1_ASAP7_75t_R   g119(.A(new_n183_), .B(new_n191_), .Y(new_n193_));
  AOI21x1_ASAP7_75t_R  g120(.A1(new_n119_), .A2(new_n176_), .B(new_n193_), .Y(new_n194_));
  AO21x1_ASAP7_75t_R   g121(.A1(new_n183_), .A2(new_n191_), .B(new_n193_), .Y(new_n195_));
  OR2x4_ASAP7_75t_R    g122(.A(new_n118_), .B(new_n176_), .Y(new_n196_));
  NAND2x1_ASAP7_75t_R  g123(.A(new_n118_), .B(new_n176_), .Y(new_n197_));
  AND2x2_ASAP7_75t_R   g124(.A(new_n196_), .B(new_n197_), .Y(new_n198_));
  AO21x1_ASAP7_75t_R   g125(.A1(new_n195_), .A2(new_n198_), .B(new_n194_), .Y(new_n199_));
  OR2x4_ASAP7_75t_R    g126(.A(new_n163_), .B(new_n199_), .Y(new_n200_));
  OR3x1_ASAP7_75t_R    g127(.A(new_n147_), .B(new_n154_), .C(new_n200_), .Y(new_n201_));
  NOR2x1_ASAP7_75t_R   g128(.A(new_n119_), .B(new_n201_), .Y(new_n202_));
  XNOR2x2_ASAP7_75t_R  g129(.A(new_n105_), .B(new_n202_), .Y(G481));
  OR2x4_ASAP7_75t_R    g130(.A(new_n192_), .B(new_n201_), .Y(new_n204_));
  XNOR2x2_ASAP7_75t_R  g131(.A(G15), .B(new_n204_), .Y(G482));
  NOR2x1_ASAP7_75t_R   g132(.A(new_n176_), .B(new_n201_), .Y(new_n206_));
  XNOR2x2_ASAP7_75t_R  g133(.A(new_n104_), .B(new_n206_), .Y(G480));
  NAND2x1_ASAP7_75t_R  g134(.A(new_n133_), .B(new_n146_), .Y(new_n208_));
  OR2x4_ASAP7_75t_R    g135(.A(new_n162_), .B(new_n199_), .Y(new_n209_));
  OR4x2_ASAP7_75t_R    g136(.A(new_n155_), .B(new_n208_), .C(new_n209_), .D(new_n176_), .Y(new_n210_));
  XNOR2x2_ASAP7_75t_R  g137(.A(G1), .B(new_n210_), .Y(G468));
  OR4x2_ASAP7_75t_R    g138(.A(new_n155_), .B(new_n208_), .C(new_n209_), .D(new_n119_), .Y(new_n212_));
  XNOR2x2_ASAP7_75t_R  g139(.A(G2), .B(new_n212_), .Y(G469));
  OR4x2_ASAP7_75t_R    g140(.A(new_n155_), .B(new_n208_), .C(new_n209_), .D(new_n192_), .Y(new_n214_));
  XNOR2x2_ASAP7_75t_R  g141(.A(G3), .B(new_n214_), .Y(G470));
  OR4x2_ASAP7_75t_R    g142(.A(new_n155_), .B(new_n208_), .C(new_n209_), .D(new_n184_), .Y(new_n216_));
  XNOR2x2_ASAP7_75t_R  g143(.A(G4), .B(new_n216_), .Y(G471));
  OR3x1_ASAP7_75t_R    g144(.A(new_n154_), .B(new_n208_), .C(new_n200_), .Y(new_n218_));
  NOR2x1_ASAP7_75t_R   g145(.A(new_n176_), .B(new_n218_), .Y(new_n219_));
  XNOR2x2_ASAP7_75t_R  g146(.A(new_n102_), .B(new_n219_), .Y(G472));
  OR4x2_ASAP7_75t_R    g147(.A(new_n154_), .B(new_n208_), .C(new_n200_), .D(new_n119_), .Y(new_n221_));
  XNOR2x2_ASAP7_75t_R  g148(.A(G6), .B(new_n221_), .Y(G473));
  NOR2x1_ASAP7_75t_R   g149(.A(new_n192_), .B(new_n218_), .Y(new_n223_));
  XNOR2x2_ASAP7_75t_R  g150(.A(new_n94_), .B(new_n223_), .Y(G474));
  OR4x2_ASAP7_75t_R    g151(.A(new_n154_), .B(new_n208_), .C(new_n200_), .D(new_n184_), .Y(new_n225_));
  XNOR2x2_ASAP7_75t_R  g152(.A(G8), .B(new_n225_), .Y(G475));
  OR3x1_ASAP7_75t_R    g153(.A(new_n147_), .B(new_n155_), .C(new_n209_), .Y(new_n227_));
  NOR2x1_ASAP7_75t_R   g154(.A(new_n176_), .B(new_n227_), .Y(new_n228_));
  XNOR2x2_ASAP7_75t_R  g155(.A(new_n103_), .B(new_n228_), .Y(G476));
  OR4x2_ASAP7_75t_R    g156(.A(new_n147_), .B(new_n155_), .C(new_n209_), .D(new_n119_), .Y(new_n230_));
  XNOR2x2_ASAP7_75t_R  g157(.A(G10), .B(new_n230_), .Y(G477));
  NOR2x1_ASAP7_75t_R   g158(.A(new_n192_), .B(new_n227_), .Y(new_n232_));
  XNOR2x2_ASAP7_75t_R  g159(.A(new_n95_), .B(new_n232_), .Y(G478));
  NOR2x1_ASAP7_75t_R   g160(.A(new_n184_), .B(new_n227_), .Y(new_n234_));
  XNOR2x2_ASAP7_75t_R  g161(.A(new_n87_), .B(new_n234_), .Y(G479));
  NOR2x1_ASAP7_75t_R   g162(.A(new_n184_), .B(new_n201_), .Y(new_n236_));
  XNOR2x2_ASAP7_75t_R  g163(.A(new_n88_), .B(new_n236_), .Y(G483));
  AND2x2_ASAP7_75t_R   g164(.A(new_n147_), .B(new_n208_), .Y(new_n238_));
  NOR2x1_ASAP7_75t_R   g165(.A(new_n154_), .B(new_n162_), .Y(new_n239_));
  AO21x1_ASAP7_75t_R   g166(.A1(new_n154_), .A2(new_n162_), .B(new_n239_), .Y(new_n240_));
  AOI21x1_ASAP7_75t_R  g167(.A1(new_n132_), .A2(new_n146_), .B(new_n239_), .Y(new_n241_));
  AO21x1_ASAP7_75t_R   g168(.A1(new_n238_), .A2(new_n240_), .B(new_n241_), .Y(new_n242_));
  OR2x4_ASAP7_75t_R    g169(.A(new_n183_), .B(new_n242_), .Y(new_n243_));
  OR3x1_ASAP7_75t_R    g170(.A(new_n192_), .B(new_n196_), .C(new_n243_), .Y(new_n244_));
  NOR2x1_ASAP7_75t_R   g171(.A(new_n132_), .B(new_n244_), .Y(new_n245_));
  XNOR2x2_ASAP7_75t_R  g172(.A(new_n97_), .B(new_n245_), .Y(G484));
  NOR2x1_ASAP7_75t_R   g173(.A(new_n146_), .B(new_n244_), .Y(new_n247_));
  XNOR2x2_ASAP7_75t_R  g174(.A(new_n98_), .B(new_n247_), .Y(G485));
  OR4x2_ASAP7_75t_R    g175(.A(new_n192_), .B(new_n196_), .C(new_n243_), .D(new_n155_), .Y(new_n249_));
  XNOR2x2_ASAP7_75t_R  g176(.A(G19), .B(new_n249_), .Y(G486));
  OR4x2_ASAP7_75t_R    g177(.A(new_n192_), .B(new_n196_), .C(new_n243_), .D(new_n163_), .Y(new_n251_));
  XNOR2x2_ASAP7_75t_R  g178(.A(G20), .B(new_n251_), .Y(G487));
  OR2x4_ASAP7_75t_R    g179(.A(new_n184_), .B(new_n242_), .Y(new_n253_));
  OR3x1_ASAP7_75t_R    g180(.A(new_n191_), .B(new_n196_), .C(new_n253_), .Y(new_n254_));
  NOR2x1_ASAP7_75t_R   g181(.A(new_n132_), .B(new_n254_), .Y(new_n255_));
  XNOR2x2_ASAP7_75t_R  g182(.A(new_n89_), .B(new_n255_), .Y(G488));
  NOR2x1_ASAP7_75t_R   g183(.A(new_n146_), .B(new_n254_), .Y(new_n257_));
  XNOR2x2_ASAP7_75t_R  g184(.A(new_n90_), .B(new_n257_), .Y(G489));
  NOR2x1_ASAP7_75t_R   g185(.A(new_n155_), .B(new_n254_), .Y(new_n259_));
  XNOR2x2_ASAP7_75t_R  g186(.A(new_n91_), .B(new_n259_), .Y(G490));
  OR4x2_ASAP7_75t_R    g187(.A(new_n191_), .B(new_n196_), .C(new_n253_), .D(new_n163_), .Y(new_n261_));
  XNOR2x2_ASAP7_75t_R  g188(.A(G24), .B(new_n261_), .Y(G491));
  OR4x2_ASAP7_75t_R    g189(.A(new_n192_), .B(new_n197_), .C(new_n243_), .D(new_n132_), .Y(new_n263_));
  XNOR2x2_ASAP7_75t_R  g190(.A(G25), .B(new_n263_), .Y(G492));
  OR4x2_ASAP7_75t_R    g191(.A(new_n192_), .B(new_n197_), .C(new_n243_), .D(new_n146_), .Y(new_n265_));
  XNOR2x2_ASAP7_75t_R  g192(.A(G26), .B(new_n265_), .Y(G493));
  OR4x2_ASAP7_75t_R    g193(.A(new_n192_), .B(new_n197_), .C(new_n243_), .D(new_n155_), .Y(new_n267_));
  XNOR2x2_ASAP7_75t_R  g194(.A(G27), .B(new_n267_), .Y(G494));
  OR4x2_ASAP7_75t_R    g195(.A(new_n192_), .B(new_n197_), .C(new_n243_), .D(new_n163_), .Y(new_n269_));
  XNOR2x2_ASAP7_75t_R  g196(.A(G28), .B(new_n269_), .Y(G495));
  OR4x2_ASAP7_75t_R    g197(.A(new_n191_), .B(new_n197_), .C(new_n253_), .D(new_n132_), .Y(new_n271_));
  XNOR2x2_ASAP7_75t_R  g198(.A(G29), .B(new_n271_), .Y(G496));
  OR4x2_ASAP7_75t_R    g199(.A(new_n191_), .B(new_n197_), .C(new_n253_), .D(new_n146_), .Y(new_n273_));
  XNOR2x2_ASAP7_75t_R  g200(.A(G30), .B(new_n273_), .Y(G497));
  OR4x2_ASAP7_75t_R    g201(.A(new_n191_), .B(new_n197_), .C(new_n253_), .D(new_n155_), .Y(new_n275_));
  XNOR2x2_ASAP7_75t_R  g202(.A(G31), .B(new_n275_), .Y(G498));
  OR4x2_ASAP7_75t_R    g203(.A(new_n191_), .B(new_n197_), .C(new_n253_), .D(new_n163_), .Y(new_n277_));
  XNOR2x2_ASAP7_75t_R  g204(.A(G32), .B(new_n277_), .Y(G499));
endmodule


