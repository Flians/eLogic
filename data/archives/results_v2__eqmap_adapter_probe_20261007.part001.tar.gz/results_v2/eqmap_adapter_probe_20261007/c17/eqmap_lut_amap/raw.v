// Benchmark "/home/flynn/workplace/MIGBalance/results_v2/eqmap_adapter_probe_20261007/c17/eqmap_lut_amap/stage" written by ABC on Wed Oct  7 16:24:35 2026

module \/home/flynn/workplace/MIGBalance/results_v2/eqmap_adapter_probe_20261007/c17/eqmap_lut_amap/stage  ( 
    G1, G2, G3, G4, G5,
    G16, G17  );
  input  G1, G2, G3, G4, G5;
  output G16, G17;
  wire new_n8_, new_n9_, new_n10_, new_n11_, new_n12_, new_n13_, new_n15_;
  INVx1_ASAP7_75t_R   g0(.A(G4), .Y(new_n8_));
  INVx1_ASAP7_75t_R   g1(.A(G5), .Y(new_n9_));
  NOR2x1_ASAP7_75t_R  g2(.A(G3), .B(new_n8_), .Y(new_n10_));
  OA21x2_ASAP7_75t_R  g3(.A1(new_n8_), .A2(new_n10_), .B(G2), .Y(new_n11_));
  INVx1_ASAP7_75t_R   g4(.A(new_n11_), .Y(new_n12_));
  AND3x1_ASAP7_75t_R  g5(.A(G1), .B(G3), .C(new_n12_), .Y(new_n13_));
  OR2x4_ASAP7_75t_R   g6(.A(new_n11_), .B(new_n13_), .Y(G16));
  AOI21x1_ASAP7_75t_R g7(.A1(G2), .A2(new_n9_), .B(G5), .Y(new_n15_));
  AOI21x1_ASAP7_75t_R g8(.A1(G3), .A2(G4), .B(new_n15_), .Y(G17));
endmodule


