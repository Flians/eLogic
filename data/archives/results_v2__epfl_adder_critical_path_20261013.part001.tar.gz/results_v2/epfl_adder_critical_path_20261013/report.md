# Read-only critical-path composition

The common evaluator metrics are independently reconstructed exactly (float32 pin values, float64 path sums), using the same input, once-resyn2 subject and library. All existing observations have named-port CEC.

ABC map:128 path cells, delay2585.48;63 OAI21/63 AOI21 plusAND2 andXOR2. emap:129 path cells,delay2585.46. Phase-allocated eGraphMap:138 path cells,delay2849.22;43 OAI21/43 AOI21 plus22 AO21/28 OA21 andAND2/XOR2.

This characterizes selected covers, not proof that faster candidates are absent. Current atomic phase recovery requires a selected unary inverter; generalized producer/consumer polarity changes are a hypothesis for the AO/OA chain. Candidate retention and flow convergence need separate tests. No baseline algorithm or netlist was changed.
