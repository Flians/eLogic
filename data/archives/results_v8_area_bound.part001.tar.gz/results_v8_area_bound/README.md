# Area minimization under the initial output-delay bound

The goal is min A subject to D <= D0, where D0 is each design's initial
mapped worst output arrival. Area reduction is primary; delay breaks area ties.
Noncritical arrivals may increase within the fixed output budget. Timing-only
area growth is rejected. All runs disable whole-window synthesis.

The executable defaults to area_delay_bound when EPMAPPING_OBJECTIVE is absent.
The explicit bounded goal/flag supersedes an inherited path-objective flag.
The separate reusable C++ parameter defaults remain backward compatible.

Both phases use the same 16 direct-mapped inputs and 40-cell ASAP7 library.
The serialized starts are byte-identical across runs and equal the historical
ABC inputs. The one-round results exactly reproduce the previous area-first
with timing-slack control. The six-round phase uses early stopping; it is a
cap, not a convergence guarantee. All 32 runs pass CEC, raw-metric agreement
and per-design area/delay nonregression checks.

| Configuration | Mean area change (%) | Mean delay change (%) | Completed |
|---|---:|---:|---:|
| One round | -2.717 | -2.347 | 16/16 |
| Six-round cap | -3.283 | -3.228 | 16/16 |

Means average per-design percentages relative to each own start, not total-area
ratios. Feasibility is checked for every design, not merely for the average.
Area/delay comparisons retain the 1e-4 area and 1e-3 timing resolution.

The engine and algorithm sources are frozen in inputs/ and hashed in manifest.json.
The process cap is 1500 seconds in both phases. div with six rounds completes
in 1335 seconds; it must not be described as a 1000-second-cap experiment.
Historical ABC uses one optimization pass and a 1000-second cap. The ABC table
in search_report.md compares completed one-round outputs only. Timings are
observational on a shared host. No per-design best configuration is selected.

```sh
python3 scripts/experiments/explore_cut_only.py --root results_v8_area_bound --phase all --profiles bounded
python3 scripts/experiments/explore_cut_only.py --root results_v8_area_bound --phase converged --profiles bounded --rounds 6 --jobs 6
python3 scripts/experiments/report_cut_search.py --root results_v8_area_bound
MPLCONFIGDIR=/tmp/epm-mpl python3 scripts/experiments/plot_cut_search.py --root results_v8_area_bound --compare-rounds
```

Completed rows are reused only with an identical plan and frozen hashes. A fresh
root executes new runs and freezes the currently built engine. The v7 timing-first
archive is retained as a different objective and is not part of this headline.
