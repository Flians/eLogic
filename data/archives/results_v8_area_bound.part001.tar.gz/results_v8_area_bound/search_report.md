# Cut-only search exploration

All configurations keep whole-window synthesis off. One fixed configuration applies to every design. All/converged phases cover all sixteen designs; tuning/validation use six declared tuning and ten validation designs, and rounds covers the six exploration designs. Every admitted result passes CEC, raw-log agreement, paired serialized input equality and objective/budget checks. Bounded-area runs minimize area under the fixed initial output-delay budget. Historical path-objective runs allow area growth for critical timing improvement and guard the (delay, area) pair.

| Cohort | Configuration | Completed | Mean area change (%) | Mean delay change (%) |
|---|---|---:|---:|---:|
| all16 | bounded | 16/16 | -2.717 | -2.347 |
| converged16 | bounded | 16/16 | -3.283 | -3.228 |

Final mapped outputs versus ABC mfs3 on its 13 completed designs (same serialized start; ABC timeouts excluded):

| Configuration | Matched | Mean area difference (%) | Mean delay difference (%) | Smaller / faster / Pareto dominates |
|---|---:|---:|---:|---:|
| bounded | 13 | +1.505 | -10.736 | 3 / 10 / 3 |

Negative means smaller/faster. Means average per-design percentages. A larger area saving can consume some delay improvement even when final delay never exceeds the initial mapping. Pure lexicographic v5 runs are separate experiments. No per-design best-of selection is used.

Failures/timeouts: []
