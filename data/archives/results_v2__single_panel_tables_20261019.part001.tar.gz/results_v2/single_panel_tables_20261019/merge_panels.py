from pathlib import Path
import re
out=Path('results_v2/single_panel_tables_20261019');src=Path('epmapping_paper/DAC-eGraphMap-draft/main.tex');s=(out/'before.tex').read_text()
def merge(m):
 t=m.group();panels=re.findall(r'\\begin\{tabular\}.*?\\end\{tabular\}',t,re.S);assert len(panels)==2
 headers=[];rows=[]
 for p in panels:
  lines=p.splitlines();headers.append(next(l for l in lines if l.startswith('Design & ')));rows.append([l for l in lines if ' & ' in l and not l.startswith(('Design',' & '))])
 assert len(rows[0])==len(rows[1])==20
 h=headers[0].removesuffix('\\\\').strip()+' & '+headers[1].split(' & ',1)[1]
 lines=[r'\begin{tabular}{@{}l'+('rrr'*7)+r'@{}}\toprule',h,' '.join(r'\cmidrule(lr){'+str(2+3*i)+'-'+str(4+3*i)+'}' for i in range(7)),' & '+' & '.join(['A & D & T']*7)+r' \\ \midrule']
 for a,b in zip(*rows):
  assert a.split(' & ')[0]==b.split(' & ')[0];lines.append(a.removesuffix('\\\\').strip()+' & '+b.split(' & ',1)[1])
 lines.append(r'\bottomrule\end{tabular}');a=t.index(r'\begin{tabular}');b=t.rindex(r'\end{tabular}')+len(r'\end{tabular}');t=t[:a]+'\n'.join(lines)+t[b:];t=t.replace(r'\centering\small',r'\centering\fontsize{6.5}{8}\selectfont').replace(r'\tabcolsep}{3pt}',r'\tabcolsep}{0.8pt}').replace(r'\arraystretch}{0.95}',r'\arraystretch}{1.05}');return t
s=re.sub(r'\\begin\{table\*\}.*?\\end\{table\*\}',merge,s,flags=re.S);src.write_text(s)
