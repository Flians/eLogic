# Frozen cut-only search experiment

Whole-window synthesis is disabled in all 88 runs. All 88 outputs pass CEC.
Initial serialized mappings are byte-identical across profiles and equal the
archived ABC inputs. No per-design winner selection is used.

The engine and C++ sources are frozen in `inputs/`, and `manifest.json` records
their hashes, the library, database and all input AIG hashes. The six declared
exploration designs are aes_core, iwls05_i2c, spi, systemcdes, tv80, usb_phy.
The remaining ten designs form the validation cohort.

- `tuning/`: five configurations, one round, six designs (30 runs).
- `validation/`: control, gain, required and pareto_delay, one round, ten designs (40 runs).
- `rounds/`: control, gain and required, cap six rounds with early stopping, six exploration designs (18 runs).

`control` is strict area-first rewriting with structural-depth and local-delay
constraints. `gain` retains these constraints but ranks competing cuts by net
area change, accounting for their different removable MFFCs. `nodepth` only
adds depth relaxation to gain and is tested on the six exploration designs.
`required` adds depth relaxation and uses live backward required times under
the fixed initial output-delay budget. Its global guard rejects violating
rounds; accepted final delays never exceed the initial delay. `pareto_delay`
is delay-first with zero local and global area-growth allowance. It does not
outperform the area-first profiles overall and is retained as negative evidence.

`search_report.md` reports tuning, validation, all-sixteen and six-round means
separately. The six-round measurements must not be described as all-sixteen
results. Every mean is an average of per-design changes. The comparison with
ABC uses its thirteen CEC-verified completed outputs; its three timeouts are
excluded. Different parsed buffer counts do not alter byte-identical starts.

Reproduce with the frozen engine (resumable):

```sh
python3 scripts/experiments/explore_cut_only.py --root results_v6_cut_search --phase tuning --profiles control,gain,nodepth,required,pareto_delay
python3 scripts/experiments/explore_cut_only.py --root results_v6_cut_search --phase validation --profiles control,gain,required,pareto_delay
python3 scripts/experiments/explore_cut_only.py --root results_v6_cut_search --phase rounds --profiles control,gain,required --rounds 6 --jobs 4
python3 scripts/experiments/report_cut_search.py --root results_v6_cut_search
MPLCONFIGDIR=/tmp/epm-mpl python3 scripts/experiments/plot_cut_search.py --root results_v6_cut_search
```

A fresh output root executes new processes and freezes the currently built
engine. Completed runs under an existing root reuse its frozen engine/results
only with an identical phase plan and matching frozen hashes.
Times are observational on a shared host. The historical v4 main/ablation
results and the unbounded v5 lexicographic runs remain separate archives.
