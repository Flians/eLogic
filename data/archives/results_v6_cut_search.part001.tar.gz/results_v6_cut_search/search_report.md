# Cut-only search exploration

All configurations keep whole-window synthesis off. One fixed configuration applies to every design. All/converged phases cover all sixteen designs; tuning/validation use six declared tuning and ten validation designs, and rounds covers the six exploration designs. Every admitted result passes CEC, raw-log agreement, paired serialized input equality and objective/budget checks. Bounded-area runs minimize area under the fixed initial output-delay budget. Historical path-objective runs allow area growth for critical timing improvement and guard the (delay, area) pair.

| Cohort | Configuration | Completed | Mean area change (%) | Mean delay change (%) |
|---|---|---:|---:|---:|
| tuning | control | 6/6 | -1.893 | -2.722 |
| tuning | gain | 6/6 | -2.128 | -2.722 |
| tuning | nodepth | 6/6 | -2.129 | -2.722 |
| tuning | required | 6/6 | -2.880 | -2.180 |
| tuning | pareto_delay | 6/6 | -0.506 | -1.884 |
| validation | control | 10/10 | -1.803 | -2.946 |
| validation | gain | 10/10 | -2.103 | -3.319 |
| validation | required | 10/10 | -2.618 | -2.447 |
| validation | pareto_delay | 10/10 | -0.533 | -3.006 |
| rounds | control | 6/6 | -2.336 | -5.533 |
| rounds | gain | 6/6 | -2.444 | -5.480 |
| rounds | required | 6/6 | -3.763 | -3.180 |
| all16 | control | 16/16 | -1.837 | -2.862 |
| all16 | gain | 16/16 | -2.112 | -3.095 |
| all16 | required | 16/16 | -2.717 | -2.347 |
| all16 | pareto_delay | 16/16 | -0.523 | -2.585 |

Final mapped outputs versus ABC mfs3 on its 13 completed designs (same serialized start; ABC timeouts excluded):

| Configuration | Matched | Mean area difference (%) | Mean delay difference (%) | Smaller / faster / Pareto dominates |
|---|---:|---:|---:|---:|
| control | 13 | +2.301 | -11.257 | 1 / 10 / 1 |
| gain | 13 | +2.129 | -11.519 | 1 / 10 / 1 |
| required | 13 | +1.505 | -10.736 | 3 / 10 / 3 |
| pareto_delay | 13 | +3.323 | -10.981 | 0 / 10 / 0 |

Negative means smaller/faster. Means average per-design percentages. A larger area saving can consume some delay improvement even when final delay never exceeds the initial mapping. Pure lexicographic v5 runs are separate experiments. No per-design best-of selection is used.

Failures/timeouts: []
