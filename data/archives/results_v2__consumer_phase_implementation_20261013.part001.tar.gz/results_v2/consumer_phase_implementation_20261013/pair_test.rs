    #[test]
    fn consumer_pair_without_inv_preserves_shared_root_and_truth() {
        let m=vec![cell("AND",vec![0,2],4,8,10.),cell("OR",vec![4,6],8,14,10.),
            cell("NAND",vec![0,2],5,7,3.),cell("INV",vec![6],7,1,1.),cell("NAND",vec![5,7],8,7,3.)];
        let free=vec![true,false,true,false,false,false,true,false,false,false];
        let mut chosen=vec![None;10];chosen[4]=Some(Binding{instance:0,pin:0});chosen[8]=Some(Binding{instance:1,pin:0});
        let mut witness=chosen.clone();witness[5]=Some(Binding{instance:2,pin:0});witness[7]=Some(Binding{instance:3,pin:0});
        let ps=MapParams{objective:MapObjective::DelayArea,consumer_phase_recovery:true,..Default::default()};let mut stats=MapStats::default();
        recover_phases(&m,&mut chosen,&witness,&free,&[4,8],&ps,&mut stats,Instant::now()+std::time::Duration::from_secs(1)).unwrap();
        assert!(stats.phase_accepted>0);assert!(metrics(&m,&chosen,&free,&[4,8]).1<=10.0);assert_eq!(chosen[4].unwrap().instance,0);
        fn eval(s:usize,v:&[bool],chosen:&[Option<Binding>],m:&[Instance],free:&[bool])->bool{
            if free[s]{return v[s];}let b=chosen[s].unwrap();let p=&m[b.instance];let index=p.inputs.iter().enumerate().fold(0usize,|x,(i,&s)|x|((eval(s,v,chosen,m,free)as usize)<<i));(p.outputs[b.pin].function>>index)&1!=0
        }
        for a in 0..8{let mut v=vec![false;10];v[0]=a&1!=0;v[2]=a&2!=0;v[6]=a&4!=0;assert_eq!(eval(4,&v,&chosen,&m,&free),v[0]&&v[2]);assert_eq!(eval(8,&v,&chosen,&m,&free),(v[0]&&v[2])||v[6]);}
    }
