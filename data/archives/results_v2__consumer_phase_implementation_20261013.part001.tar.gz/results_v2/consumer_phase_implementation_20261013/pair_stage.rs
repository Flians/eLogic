    if ps.consumer_phase_recovery && Instant::now() < deadline {
        let (arrival, critical) = critical_arrivals(instances, chosen, free, roots);
        let estimate = |s: usize| -> Option<f64> {
            if free[s] { return Some(0.0); }
            arrival[s].or_else(|| witness[s].and_then(|b| {
                let m = &instances[b.instance];
                if m.inputs.iter().all(|&i| free[i]) {
                    Some(m.outputs[b.pin].delays.iter().copied().fold(0.0, f32::max) as f64)
                } else { None }
            }))
        };
        let mut targets: Vec<_> = (0..chosen.len()).filter(|&s| critical[s] && chosen[s].is_some()).collect();
        targets.sort_by(|&a,&b| arrival[b].unwrap_or(0.0).total_cmp(&arrival[a].unwrap_or(0.0)).then(a.cmp(&b)));
        let mut proposals = Vec::new();
        'collect: for t in targets {
            if Instant::now() >= deadline { break; }
            let old_consumer = chosen[t].unwrap(); let c = &instances[old_consumer.instance];
            let mut old_classes: Vec<_> = c.inputs.iter().map(|s| s >> 1).collect(); old_classes.sort();
            for &s in &c.inputs {
                let opposite = s ^ 1;
                if free[s] || chosen[s].is_none() || opposite >= chosen.len() { continue; }
                let old_producer = chosen[s].unwrap();
                for &q in &producers[opposite] {
                    let producer = &instances[q.instance];
                    if producer.inputs.contains(&t) || producer.inputs.contains(&s) || producer.inputs.contains(&opposite) { continue; }
                    let qtime = producer.inputs.iter().enumerate().filter(|(p,_)| producer.outputs[q.pin].has_arc(*p))
                        .map(|(p,&i)| estimate(i).unwrap_or(f64::INFINITY)+f64::from(producer.outputs[q.pin].delays[p])).fold(0.0,f64::max);
                    if !qtime.is_finite() { continue; }
                    for &d in &producers[t] {
                        if Instant::now() >= deadline { break 'collect; }
                        let consumer=&instances[d.instance];
                        if d.instance==old_consumer.instance || !consumer.inputs.contains(&opposite) { continue; }
                        let mut new_classes: Vec<_>=consumer.inputs.iter().map(|s|s>>1).collect();new_classes.sort();
                        if new_classes!=old_classes { continue; }
                        let time=consumer.inputs.iter().enumerate().filter(|(p,_)|consumer.outputs[d.pin].has_arc(*p))
                            .map(|(p,&i)|(if i==opposite{qtime}else{estimate(i).unwrap_or(f64::INFINITY)})+f64::from(consumer.outputs[d.pin].delays[p])).fold(0.0,f64::max);
                        let gain=time-arrival[t].unwrap_or(f64::INFINITY);
                        if gain>=-1e-6 || !gain.is_finite(){continue;}
                        let area=f64::from(producer.area+consumer.area-instances[old_producer.instance].area-c.area);
                        proposals.push((gain,area,s,t,old_producer,old_consumer,q,d));
                        if proposals.len()>=ps.refine_trials{break 'collect;}
                    }
                }
            }
        }
        proposals.sort_by(|a,b|a.0.total_cmp(&b.0).then(a.1.total_cmp(&b.1)).then(a.3.cmp(&b.3)).then(a.2.cmp(&b.2)));
        for (_,_,s,t,p,c,q,d) in proposals {
            if Instant::now()>=deadline || stats.phase_trials>=ps.refine_trials{break;}
            if chosen[s].is_none_or(|b|b.instance!=p.instance||b.pin!=p.pin)||chosen[t].is_none_or(|b|b.instance!=c.instance||b.pin!=c.pin){continue;}
            let mut trial=chosen.clone();trial[s^1]=Some(q);trial[t]=Some(d);stats.phase_trials+=1;
            if fill_from_witness(instances,&mut trial,witness,free,roots).is_err(){continue;}
            let score=metrics(instances,&trial,free,roots);
            if better_cover(score,best,ps){*chosen=trial;best=score;stats.phase_accepted+=1;stats.phase_final_delay=score.1;}
        }
    }
