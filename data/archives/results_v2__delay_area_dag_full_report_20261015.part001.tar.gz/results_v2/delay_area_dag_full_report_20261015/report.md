# Finite-frontier delay seed and required-time area flow

Isolated same-binary, same-candidate-pool delay-area experiment. Original baselines and production defaults unchanged. One global 2 s recovery window; 20,000 actual e-nodes, 16 cuts/class, 100,000 retained candidates, 16 SAT iterations. The retained cap does not bound transient generation RAM.

120 declared slots: 90 legal independent named-port CEC covers and 30 explicitly adopted historical pre-recovery import rejections. Sixteen successful same-version pilot slots were adopted, not rerun; 74 successful slots are new full-campaign runs. No design-specific configuration selection.

Versus same-binary legacy recovery, 30 eligible pairs: delay 2 better / 28 equal / 0 worse; area 24 better / 2 equal / 4 worse. All pool fingerprints match; no successful-run budget or artifact-hash violations. Five large input designs remain outside the import allowance.

| Inventory | Design | Control area | Candidate area | Control delay | Candidate delay | Status |
|---|---|---:|---:|---:|---:|---|
| 4in | sqrt | 3819.37 | 2735.82 | 69541.91 | 66924.64 | ok |
| 4in | bar | 304.64 | 282.77 | 188.34 | 188.34 | ok |
| 4in | sin | 712.58 | 456.61 | 2029.35 | 2029.35 | ok |
| 4in | max | 284.64 | 212.14 | 2098.34 | 2098.34 | ok |
| 3in | sqrt | 2921.30 | 2154.29 | 72496.92 | 68523.99 | ok |
| 3in | bar | 289.64 | 263.25 | 190.87 | 190.87 | ok |
| 3in | sin | 615.70 | 441.88 | 2095.27 | 2095.27 | ok |
| 3in | max | 284.77 | 242.40 | 2111.03 | 2111.03 | ok |
| 3in | div | — | — | — | — | failed |
| 3in | hyp | — | — | — | — | failed |
| 3in | log2 | — | — | — | — | failed |
| 3in | multiplier | — | — | — | — | failed |
| 3in | mem_ctrl | — | — | — | — | failed |
| 4in | div | — | — | — | — | failed |
| 4in | hyp | — | — | — | — | failed |
| 4in | log2 | — | — | — | — | failed |
| 4in | multiplier | — | — | — | — | failed |
| 4in | mem_ctrl | — | — | — | — | failed |
| 4in | adder | 83.75 | 83.19 | 2585.23 | 2585.23 | ok |
| 4in | square | 2939.11 | 1825.89 | 2772.82 | 2772.82 | ok |
| 4in | arbiter | 728.72 | 718.08 | 925.93 | 925.93 | ok |
| 4in | cavlc | 44.60 | 40.90 | 194.95 | 194.95 | ok |
| 4in | ctrl | 7.19 | 6.96 | 103.17 | 103.17 | ok |
| 4in | dec | 29.18 | 29.18 | 66.15 | 66.15 | ok |
| 4in | i2c | 80.69 | 73.54 | 165.79 | 165.79 | ok |
| 4in | int2float | 13.22 | 13.29 | 181.28 | 181.28 | ok |
| 4in | priority | 52.55 | 53.47 | 2047.24 | 2047.24 | ok |
| 4in | router | 13.07 | 12.54 | 199.00 | 199.00 | ok |
| 4in | voter | 1676.13 | 1313.00 | 758.00 | 758.00 | ok |
| 3in | adder | 72.55 | 76.27 | 2585.48 | 2585.48 | ok |
| 3in | square | 2577.69 | 1687.90 | 2707.68 | 2707.68 | ok |
| 3in | arbiter | 767.03 | 748.87 | 905.89 | 905.89 | ok |
| 3in | cavlc | 44.93 | 42.26 | 197.59 | 197.59 | ok |
| 3in | ctrl | 7.33 | 7.20 | 108.06 | 108.06 | ok |
| 3in | dec | 27.68 | 27.68 | 82.92 | 82.92 | ok |
| 3in | i2c | 82.87 | 75.35 | 166.78 | 166.78 | ok |
| 3in | int2float | 14.40 | 13.62 | 183.34 | 183.34 | ok |
| 3in | priority | 68.54 | 69.39 | 2062.18 | 2062.18 | ok |
| 3in | router | 13.75 | 13.48 | 216.40 | 216.40 | ok |
| 3in | voter | 1376.83 | 1033.99 | 817.57 | 817.57 | ok |

Four area regressions: 4in int2float +0.07, 4in priority +0.92, 3in adder +3.72, 3in priority +0.85. A reduced area-flow proxy is not globally minimum physical area. The frontier seed is a feasible acyclic starting cover, not a proof of globally optimal delay or lexicographic extraction.

The earlier scheduling pilot alone did not reliably improve delay. Truncated critical-first local proposals still left sqrt without trials; an earlier seed deadline weakened its starting cover. The finite-frontier seed reduces repeated propagation work and warm-starts the existing event-driven flow. The subsequent DAG area sweep uses dependent-pin required times and validates actual whole-cover metrics before accepting.

All 12 full-scope baseline gates for frontier/area-DAG profiles, both libraries, and DA/AD/Pareto are false. AD gates are post-hoc evaluations of DA-optimized covers. MtM remains unconnected. No promotion or SOTA claim.

Next: audit all repeated observations; protect sharing without weakening the validated delay incumbent; address structural candidate/phase gaps and the five cumulative-import failures in distinct fixed versions.
