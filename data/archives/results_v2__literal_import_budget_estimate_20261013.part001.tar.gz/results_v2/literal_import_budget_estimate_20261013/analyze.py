"""Conservative phase-edge storage estimate; no mapping/CEC/feasibility proof."""
import hashlib,json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT/'scripts/experiments'))
from analyze_epfl_structural_budget import read_binary_aig
p=ROOT/'results_v2/epfl_resyn2_subjects_20261012/report.json';c=json.loads(p.read_text());rows=[]
for r in c['results']:
 path=p.parent/(r['bench']+'.resyn2.aig');data=path.read_bytes();assert hashlib.sha256(data).hexdigest()==r['preprocessing']['sha256']
 inputs,roots,gates=read_binary_aig(data);live=set();stack=[x//2 for x in roots];negative_edges=0
 while stack:
  var=stack.pop()
  if var in gates and var not in live:
   live.add(var);stack.extend(x//2 for x in gates[var]);negative_edges+=sum(x&1 for x in gates[var])
 negative_outputs=len({x//2 for x in roots if x&1})
 upper=inputs+len(live)+1+negative_outputs
 rows.append({'bench':r['bench'],'prepared_sha256':r['preprocessing']['sha256'],'all_inputs_counted':inputs,'all_live_ands_counted':len(live),'constant_counted':1,'distinct_negative_output_enode_upper':negative_outputs,'internal_inverted_edges_encoded_in_operators':negative_edges,'compact_import_enode_upper':upper,'under20000_upper':upper<=20000,'rewrite_headroom_upper_estimate':20000-upper})
out=Path(__file__).parent;(out/'report.json').write_text(json.dumps({'subject_report_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'rows':rows,'limitation':'Storage estimate only, not actual imported enodes, SAT budget feasibility, legal cover, PPA, minimum size or impossibility proof. Every live AND and every PI represented; no per-region reset.'},indent=2))
for r in rows:print(r['bench'],r['compact_import_enode_upper'],r['under20000_upper'])
