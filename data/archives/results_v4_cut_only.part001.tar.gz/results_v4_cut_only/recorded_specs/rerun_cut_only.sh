#!/usr/bin/env bash
set -euo pipefail
cd /home/flynn/workplace/MIGBalance
export EPM_ROOT="$PWD/results_v4_cut_only" EPM_BIN="$PWD/results_v4_cut_only/inputs/epmapping_check"
export EPM_JOBS=8 RAYON_NUM_THREADS=1 EPM_TIMEOUT=1800 EPM_ROUNDS=6 EPM_DC_BUDGET=60 ABC=/usr/bin/abc
for stage in tab_mfs3 ablation validation; do
  echo "Starting $stage $(date -u +%FT%TZ)"
  xargs -P "$EPM_JOBS" -L 1 bash -c 'source scripts/experiments/common.sh; run_engine "$@"' _ < "$EPM_ROOT/$stage/rerun.specs" >> "$EPM_ROOT/$stage/summary.tsv"
  echo "Finished $stage $(date -u +%FT%TZ)"
done
