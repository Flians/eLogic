#!/usr/bin/env bash
set -euo pipefail
cd /home/flynn/workplace/MIGBalance
export EPM_ROOT="$PWD/results_v4_cut_only" EPM_BIN="$PWD/results_v4_cut_only/inputs/epmapping_check"
export EPM_JOBS=8 RAYON_NUM_THREADS=1 EPM_TIMEOUT=1800 EPM_ROUNDS=6 EPM_DC_BUDGET=60 ABC=/usr/bin/abc
xargs -P "$EPM_JOBS" -L 1 bash -c 'source scripts/experiments/common.sh; run_engine "$@"' _ < "$EPM_ROOT/corrected_noDB/rerun.specs" >> "$EPM_ROOT/corrected_noDB/summary.tsv"
