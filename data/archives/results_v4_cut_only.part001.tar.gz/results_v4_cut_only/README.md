# DATE paper: cut-only experiment archive

Every ePMapping run used by this paper disables whole-window synthesis
(`EPMAPPING_WINDOW_SYN=0`). Reconvergence-window simulation for cut care masks is
a separate operation and remains enabled outside the noCARE arm.

Unchanged cut-only main, funnel, search-budget and database measurements are
copied from `results_v3_audit/`. The eleven former noWINDOW ablation rows provide
the new full cut-only reference: their directory and summary-arm names change,
while raw logs, measurements and mapped netlists remain unchanged. This reuse is
recorded in `manifest.json`.

The four component-removal arms (44 runs), the common-input ePMapping comparison
(16 runs) and both cache settings on c7552/tv80 (four runs) are remeasured with
window synthesis disabled. New runs record `experiment_env.txt` alongside raw
logs and CEC-checked netlists. Their batch specs and launch script are archived.

ABC results, native baseline measurements and frozen input netlists are reused:
ABC itself has no ePMapping window-synthesis flag. The exporter checks that its
serialized inputs equal the ePMapping baselines before comparing results.

The frozen engine is byte-identical to the current build and its SHA256 is
recorded. New batches use at most eight concurrent designs and one Rust worker
per engine. Times are observational on the shared host.

The paper has five ablation arms: full, noSYN, noEGG, noCARE and noDB. A noWINDOW
arm would duplicate full and is omitted. `export_paper.py` rejects any recorded
window-synthesis activity or an enabling flag in a new run's environment record.
The earlier window-enabled archive is preserved as historical evidence.

The initial revision batch exposed an older harness bug: `env -u` was followed
by the default database assignment, so noDB still loaded the database. The
corrected driver appends an empty `EPMAPPING_SUPER` override after the defaults.
All eleven noDB designs are rerun in `corrected_noDB/`; the first-batch noDB
outputs are retained as superseded evidence and excluded from the final tables.
The exporter rejects noDB logs that load a supergate database.
