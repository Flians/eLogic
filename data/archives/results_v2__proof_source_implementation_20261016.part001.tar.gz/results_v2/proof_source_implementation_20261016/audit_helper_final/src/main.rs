// Read-only audit: include the exact frozen algorithm and graph representation.
#[path="/home/flynn/workplace/MIGBalance/results_v2/proof_source_implementation_20261016/frozen_source/emapper/src/aig_graph.rs"]mod aig_graph;
#[path="/home/flynn/workplace/MIGBalance/results_v2/proof_source_implementation_20261016/frozen_source/emapper/src/source_proof.rs"]mod source_proof;
use aig_graph::{Aig,AigNode};use std::collections::HashMap;use petgraph::{visit::{Topo,EdgeRef},Direction};
fn delta(mut n:u32,b:&mut Vec<u8>){while n>=128{b.push((n as u8)|128);n>>=7;}b.push(n as u8);}
fn write(a:&Aig,path:&str){
 let mut inputs:Vec<_>=a.node_indices().filter_map(|n|if let AigNode::Input(v)=a.node_type(n){Some((v,n))}else{None}).collect();inputs.sort();
 let mut outputs:Vec<_>=a.node_indices().filter_map(|n|if let AigNode::Output(v)=a.node_type(n){Some((v,n))}else{None}).collect();outputs.sort();
 let mut ids=HashMap::new();for n in a.node_indices(){if matches!(a.node_type(n),AigNode::Zero){ids.insert(n,0u32);}}
 for (p,(_,n)) in inputs.iter().enumerate(){ids.insert(*n,(p+1)as u32);}
 let mut gates=Vec::new();let mut topo=Topo::new(a.graph());
 while let Some(n)=topo.next(a.graph()){if !matches!(a.node_type(n),AigNode::And){continue;}
  let mut e=a.graph().edges_directed(n,Direction::Incoming);let x=e.next().unwrap();let y=e.next().unwrap();assert!(e.next().is_none());
  let mut x=ids[&x.source()]*2+u32::from(*x.weight());let mut y=ids[&y.source()]*2+u32::from(*y.weight());if x<y{std::mem::swap(&mut x,&mut y);}
  let id=(inputs.len()+gates.len()+1)as u32;assert!(x<id*2);ids.insert(n,id);gates.push((id*2,x,y));
 }
 let maximum=inputs.len()+gates.len();let mut b=format!("aig {} {} 0 {} {}\n",maximum,inputs.len(),outputs.len(),gates.len()).into_bytes();
 for (_,n) in &outputs{let e=a.graph().edges_directed(*n,Direction::Incoming).next().unwrap();b.extend(format!("{}\n",ids[&e.source()]*2+u32::from(*e.weight())).as_bytes());}
 for (l,x,y) in gates {delta(l-x,&mut b);delta(x-y,&mut b);}
 for (i,(v,_)) in inputs.iter().enumerate(){let name=a.symbol_input(*v).expect("all EPFL input names must survive");assert!(!name.contains(['\n','\r']));b.extend(format!("i{i} {name}\n").as_bytes());}
 for (i,(v,_)) in outputs.iter().enumerate(){let name=a.symbol_output(*v).expect("all EPFL output names must survive");assert!(!name.contains(['\n','\r']));b.extend(format!("o{i} {name}\n").as_bytes());}
 b.extend(b"c\nFrozen V17 source-proof replay audit; not used as a mapper input.\n");std::fs::write(path,b).unwrap();
}
fn main(){let args:Vec<_>=std::env::args().collect();assert!(args.len()==3 || (args.len()==4 && args[3]=="--post-cleanup"));let mut aig=Aig::from_aiger(&args[1]);aig.cleanup_graph();let mut compact=source_proof::compress(&aig);let before=compact.node_indices().filter(|&n|matches!(compact.node_type(n),AigNode::And)).count();if args.len()==4{compact.cleanup_graph();}let after=compact.node_indices().filter(|&n|matches!(compact.node_type(n),AigNode::And)).count();write(&compact,&args[2]);println!("{}",serde_json::json!({"post_cleanup":args.len()==4,"before_and":before,"after_and":after,"scope":"source replay only; not mapped PPA or mapper input"}));}
