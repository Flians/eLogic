# Complete-cover protection and bounded source groups, 2026-10-17

No main promotion or new PPA superiority claim. Original baselines and budgets are unchanged.

## V24 transaction seam from V19

The isolated native module now validates the complete selected cone, actual input/output phases and demanded joint pins, physical identity/pin delays, unique physical area, exact retained-cut support, newly added cut derivation, aggregate cut/pool allowances and the original caller deadline. Invalid proposals leave the incumbent unchanged. A new RED caught admission of an unproved unused cut; exact one-retained-cut substitution now rejects it. SDC certificates use existing fixed-graph Reachability cache masks; there is no conditional egg union or additional semantic query. Fourteen seam tests and130 egraph-related regressions pass,6ignored (including explicit read-only replay). The engine is compiled but NOT called by production candidate search. Caller generation must still provide library-legal cells and one active candidate bank; the seam is not an extra mapping/recovery budget.

Initial replay of34 historical V19 selected covers accepts29 and fails closed on5 without unconditional cut provenance: K4adder/ctrl andK3adder/cavlc/ctrl. These old snapshots lacked care masks. A reporting-only V19 capture exports already computed masks and gives8fresh original named-port CEC passes on adder/ctrl/cavlc/sin across both inventories. Exact fixed egraph node syntax, canonical aliases, roots, free/PI interface and cut-bank equality are checked before joining the5contexts for read-only replay. All34original selected covers then replay; all8fresh snapshots replay. Joined files are audit-only, NEVER official mapper inputs/offline advice or eligible candidates. This is no new34-case mapping/CEC, no mixed-version winner and no validation of omitted unselected100k physical pools.

The slowest selected-cover transaction audit takes1.770s of a2s passed deadline (serialization excluded). This leaves insufficient demonstrated room for old search plus live exchange. Do not add these costs after a full2s search. Preserve only already visited validated incumbents; reproducing an archived full-search V19 result within a reallocated deadline remains unproved.

## V25 source grouping, independent from V24

Existing exact source choices can require3/4same-rank consumers to change before a shared cone dies. A RED graph makes single/pair moves increase live count; a three-consumer transaction releases one node. The opt-in EGM_SOURCE_GROUPS reallocates the ORIGINAL16total root transactions across groups/pairs, with no added Boolean/proof queries or node allowance.98egraph-related tests pass with the flag both off/on,4ignored. The actual sidecars verify max_root_transactions<=16.

A16attempt fixed pilot yields4physical CEC (priority) and12actual import-node failures. All failed imports really stop at20000 incomplete. Four-input source estimates: div20366->20366, hyp106345->99143, mem_ctrl24872->24860. Three-input: div20537->20537, hyp111430->104047, mem_ctrl27914->27903. These are representation estimates, not minimum bounds/import success/physical PPA. K4priority area52.29->52.42 at identical2047.24 delay is retained as an adverse observation, not a stable algorithm effect (no source-plan sidecar there; deadline-sensitive recovery). K3priority area68.54/delay2062.18 unchanged. No source variant is promoted.

The first new runner failed AFTER one successful control mapping/CEC when serializing an accidentally created tuple key. Its full partial directory and failing runner are preserved as source_groups_pilot_interrupted_20261017 and runner_v1_failed.py. The corrected explicit v2matrix does not silently adopt/overwrite it. Total unique physical attempts this round:25,13CEC,12actualnodefailures across independent source and reporting-only versions. No combined algorithm is claimed.

## Remaining qualification

Live proposal generation, full eligible-pool provenance, protected mandatory/finite witness admission and incremental cut exchange under one inclusive2s recovery window remain to be connected. Full20x2library controlled PPA and alternating repetitions of THAT live engine have not been run. Keep main/defaults/bin8f6 unchanged until they qualify. Baselines retain240groups/520slots,372CEC,124reportedfailures and24unmeasured failures. Four common binaries freshly hash-match; prior13403-file complete audit is referenced, not rerun. Prior full20DA/ADposthoc/Pareto gates remain false.
