# Guarded joint recovery, fixed isolated V7

The full20/two-library study has80status slots:68fresh native/original named-port CEC passes and12explicit pre-import failed adoptions backed by6prior actual failures.64additional fresh alternating-order target attempts all pass CEC and actual global budgets. Unique fresh runs total132, not144. Main binary/source/defaults are unchanged.

Full34legal pairs: delay14better/20equal/0worse, area5better/19equal/10worse. All10larger-area results accompany a strict delay gain; no tied-delay area regression. Priority/max all targeted observations restore canonical main areas, including4in priority52.15 and max221.30. Canonical main is kept separately; no slower contemporary control erases its reference.

Unique full+fresh-repeat66legal pairs: {'delay': [22, 44, 0], 'area': [9, 41, 16]}. Actual20knodes/cuts16/retained100k/SAT16/one inclusive2s recovery and300s mapping guards unchanged. More generated transient candidates are not extra retained capacity or memory-cap evidence.

The original baseline240groups/520slots remain372CEC/124reportedfailures/24unmeasured.13403dependencies reaudited without drift, all six full20 DA/AD-posthoc/Pareto gates false; MtM not connected. Baseline algorithms/models/parameters unchanged.

Separate V8helper allocation sqrt pilot is not part of this full matrix. It closes both same-library emap delay gaps by admitting more original functions inside unused global capacity, but increases area; no full/repeated qualification or main integration. Div/hyp/mem_ctrl remain unsolved, no residency/cumulative-budget substitution.

A derivative CSV was found to reference historical V4 pairs; the erroneous derivative is retained as historical_v4_observations_misreferenced.csv and regenerated from the correct V7source reports. No experiment, source report, numeric acceptance rule or baseline result changed. Full actual experiment reports and checkers remain authoritative.
