import json,csv,hashlib
from pathlib import Path
R=Path('/home/flynn/workplace/MIGBalance');O=Path(__file__).parent
load=lambda p:json.loads(p.read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
f=load(R/'results_v2/guarded_joint_full_report_20261016/paired.json');rep=load(R/'results_v2/guarded_joint_repeats_report_20261016/paired.json')
unique=f+[p for p in rep if p['observation']!='full_r0'];assert len(unique)==72
eligible=[p for p in unique if all(p[a]['row']['status']=='ok' for a in ['control','candidate'])];assert len(eligible)==66
counts={}
for metric in ['delay','area']:
 vals=[p['candidate']['row']['measured'][metric]-p['control']['row']['measured'][metric] for p in eligible]
 counts[metric]=[sum(v<-1e-6 for v in vals),sum(abs(v)<=1e-6 for v in vals),sum(v>1e-6 for v in vals)]
# Repair derivative CSV pointing at historical V4; original retained explicitly.
wrong=O/'full_observations.csv'
if not (O/'historical_v4_observations_misreferenced.csv').exists():wrong.rename(O/'historical_v4_observations_misreferenced.csv')
for name,pairs in [('full_observations.csv',f),('unique_observations.csv',unique)]:
 with (O/name).open('w') as h:
  fields=['k','bench','observation','profile','status','area','delay','cec','report','report_sha256'];w=csv.DictWriter(h,fieldnames=fields);w.writeheader()
  for p in pairs:
   for side in ['control','candidate']:
    x=p[side];r=x['row'];m=r.get('measured',{});w.writerow(dict(k=p['k'],bench=p['bench'],observation=p['observation'],profile=x['profile'],status=r['status'],area=m.get('area'),delay=m.get('delay'),cec=m.get('cec'),report=x['report'],report_sha256=x['report_sha256']))
summary=dict(full_slots=80,full_fresh_native=68,full_adopted_failed_slots=12,adopted_source_actual_failures=6,fresh_repeat_native=64,fresh_total_native=132,fresh_total_direct_cec=132,unique_eligible_pairs=66,better_equal_worse=counts,production_qualified=False,reason='Strict-delay area costs remain; full previous-final-shared-cover guarantee across different pools not established; big three node failures remain. No promotion.',baseline_gate_passes=0,baseline_gate_count=6)
(O/'qualification.json').write_text(json.dumps(summary,indent=2)+'\n')
(O/'report.md').write_text('''# Guarded joint recovery, fixed isolated V7

The full20/two-library study has80status slots:68fresh native/original named-port CEC passes and12explicit pre-import failed adoptions backed by6prior actual failures.64additional fresh alternating-order target attempts all pass CEC and actual global budgets. Unique fresh runs total132, not144. Main binary/source/defaults are unchanged.

Full34legal pairs: delay14better/20equal/0worse, area5better/19equal/10worse. All10larger-area results accompany a strict delay gain; no tied-delay area regression. Priority/max all targeted observations restore canonical main areas, including4in priority52.15 and max221.30. Canonical main is kept separately; no slower contemporary control erases its reference.

Unique full+fresh-repeat66legal pairs: '''+str(counts)+'''. Actual20knodes/cuts16/retained100k/SAT16/one inclusive2s recovery and300s mapping guards unchanged. More generated transient candidates are not extra retained capacity or memory-cap evidence.

The original baseline240groups/520slots remain372CEC/124reportedfailures/24unmeasured.13403dependencies reaudited without drift, all six full20 DA/AD-posthoc/Pareto gates false; MtM not connected. Baseline algorithms/models/parameters unchanged.

Separate V8helper allocation sqrt pilot is not part of this full matrix. It closes both same-library emap delay gaps by admitting more original functions inside unused global capacity, but increases area; no full/repeated qualification or main integration. Div/hyp/mem_ctrl remain unsolved, no residency/cumulative-budget substitution.

A derivative CSV was found to reference historical V4 pairs; the erroneous derivative is retained as historical_v4_observations_misreferenced.csv and regenerated from the correct V7source reports. No experiment, source report, numeric acceptance rule or baseline result changed. Full actual experiment reports and checkers remain authoritative.
''')
print(summary)
