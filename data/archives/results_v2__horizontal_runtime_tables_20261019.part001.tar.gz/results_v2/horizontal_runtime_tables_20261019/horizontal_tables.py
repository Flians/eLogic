from pathlib import Path
import json,re
out=Path('results_v2/horizontal_runtime_tables_20261019');p=Path('epmapping_paper/DAC-eGraphMap-draft/main.tex');s=(out/'before.tex').read_text();r=json.loads(Path('results_v2/combined_runtime_tables_20261019/runtime_sources.json').read_text())['records'];labels={'abc_map_delay_resyn2':'ABC map','mockturtle_emap_delay_resyn2':'emap','eqmap_lut_amap':'EqMap','esyn_frozen_model_amap_bounded_dag':'E-Syn','emorphic_final_sa':'E-morphic','B':'B','X':'X'};methods=list(labels);tables=[]
for k in [3,4]:
 lines=[r'\begin{table*}[!t]\centering\small',r'\setlength{\tabcolsep}{3pt}',r'\renewcommand{\arraystretch}{0.95}',r'\caption{EPFL '+str(k)+r'-input inventory: area (A), unloaded block delay (D), and mapping runtime in seconds (T). $\leq$ denotes a conservative upper bound; -- denotes unavailable runtime. Fixed delay-oriented profiles; F/N retain failure/node-rejection status.}',r'\label{tab:epfl'+str(k)+r'area}\label{tab:epfl'+str(k)+r'delay}']
 for panel in [methods[:4],methods[4:]]:
  if panel!=methods[:4]:lines.append(r'\par\vspace{5pt}')
  lines.extend([r'\begin{tabular}{l'+('rrr'*len(panel))+r'}\toprule', 'Design & '+' & '.join(r'\multicolumn{3}{c}{'+labels[m]+'}' for m in panel)+r' \\', ' '.join(r'\cmidrule(lr){'+str(2+3*i)+'-'+str(4+3*i)+'}' for i in range(len(panel))), ' & '+' & '.join(['A & D & T']*len(panel))+r' \\ \midrule'])
  designs=list(dict.fromkeys(x['design'] for x in r if x['k']==k))
  for design in designs:
   cells=[]
   for m in panel:
    row=next(x for x in r if x['k']==k and x['design']==design and x['method']==m);cells.extend([row['area_cell'],row['delay_cell'],row['runtime_cell']])
   lines.append(design.replace('_',r'\_')+' & '+' & '.join(cells)+r' \\')
  lines.append(r'\bottomrule\end{tabular}')
 lines.append(r'\end{table*}');tables.append('\n'.join(lines))
s=re.sub(r'% BEGIN EPFL COMPLETE TABLES.*?% END EPFL COMPLETE TABLES','% BEGIN EPFL COMPLETE TABLES\n'+'\n\n'.join(tables)+'\n% END EPFL COMPLETE TABLES',s,flags=re.S) if False else s[:s.index('% BEGIN EPFL COMPLETE TABLES')]+'% BEGIN EPFL COMPLETE TABLES\n'+'\n\n'.join(tables)+'\n'+s[s.index('% END EPFL COMPLETE TABLES'):]
p.write_text(s)
