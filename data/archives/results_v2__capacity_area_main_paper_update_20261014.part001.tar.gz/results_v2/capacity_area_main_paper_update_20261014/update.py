from pathlib import Path
import json,shutil,re
root=Path('/home/flynn/workplace/MIGBalance');o=root/'results_v2/capacity_area_main_paper_update_20261014';p=root/'epmapping_paper/DAC-eGraphMap-draft/main.tex';s=(o/'before.tex').read_text()
def sub(a,b):
 global s
 assert a in s,a[:70]
 s=s.replace(a,b)
sub('''The bounded physical-alias profile produces 22 verified covers across 40
circuit/library cases; the remaining inputs exceed its node allowance.
Compared with a same-binary control, delay improves in nine valid pairs
and ties in thirteen, with nonuniform area costs.''','''The bounded capacity profile produces 30 verified covers across 40
circuit/library cases; five designs still exceed its node allowance.
Compared with the preceding wire profile, all 22 existing legal pairs
retain delay; area improves in eight, ties in thirteen and increases in one.''')
sub('''retains every PI and live AND; exact rewrites reserve node capacity.
Atomic producer/inverter replacement''','''retains every PI and live AND; exact rewrites reserve node capacity.
An optional structural-size rule uses phase bits on logical AND inputs
when ordinary import would exceed the allowance. Every live AND and PI
remains an actual counted node; no regional budget is reset. Masked
operators can change rewrite-pattern visibility.
Atomic producer/inverter replacement''')
sub('''final validation, with a 0.05-second return reserve. Generated transient
candidates are reported separately; the retained cap is not a RAM cap.
CBC is disabled. Tables use a complete root-release run. Paired controls
use the same executable with the retention, alias and reference options
disabled; no per-design profile selection is made.''','''final validation, with a 0.05-second return reserve, increased to 0.15
only for compact import within the same deadline. Generated transient
candidates are reported separately; the retained cap is not a RAM cap.
CBC is disabled. Tables use all 40 fresh root-release candidate runs
with structural capacity selection enabled. Controls are the archived
preceding wire version, verified against original source and binary
hashes; no per-design profile selection is made.''')
c=json.loads((root/'results_v2/capacity_area_main_checkpoint_20261014/campaign.json').read_text());data={}
for j in c['jobs']:
 if j['profile']=='adaptive_area':
  assert 'adopted_control_campaign' not in j
  data[j['k'],j['bench']]=json.loads(Path(j['report']).read_text())['results'][0]
assert len(data)==40
start=s.index('% BEGIN EPFL COMPLETE TABLES');end=s.index('% END EPFL COMPLETE TABLES');block=s[start:end];lines=[];checks=[];k=None;metric=None
for line in block.splitlines(keepends=True):
 m=re.search(r'label\{tab:epfl([34])(area|delay)\}',line)
 if m:k=int(m[1]);metric=m[2]
 name=line.split(' & ')[0].replace('\\_','_')
 if k and (k,name) in data and ' & ' in line:
  parts=line.strip().rstrip(chr(92)).strip().split(' & ');assert len(parts)==7
  r=data[k,name];v=f"{r['measured'][metric]:.2f}" if r['status']=='ok' else 'N';oldprefix=parts[:6];parts[-1]=v;newline=' & '.join(parts)+' '+chr(92)*2+'\n';assert newline.strip().rstrip(chr(92)).strip().split(' & ')[:6]==oldprefix
  checks.append({'k':k,'design':name,'metric':metric,'table':v,'measured':r.get('measured',{}).get(metric),'baseline_columns_unchanged':True});line=newline
 lines.append(line)
assert len(checks)==80;s=s[:start]+''.join(lines)+s[end:]
sub('''The fixed eGraphMap profile maps 22 of 40 circuit/inventory cases. Its 18 rejections
are the same nine designs in both inventories.''','''The fixed eGraphMap profile maps 30 of 40 circuit/inventory cases. Its ten
rejections are div, hyp, log2, multiplier and mem\\_ctrl in both inventories.
Compact import restores sqrt, square, arbiter and voter; this establishes
coverage, not superiority over failed controls or conventional mappings.''')
start=s.index('Early required-time area flow, inspired');end=s.index('Synthetic fixtures verify joint output',start)
s=s[:start]+'''Early required-time area flow with 20\\% of the remaining recovery
window gives 22 delay ties, seven area gains, eight ties and seven
regressions. Later 35\\% area reservations and cheaper proposal ordering
also regress valid pairs in complete studies, so neither becomes the
main profile. A 10\\% reservation with structural compact import gives
six area gains, nine ties and seven regressions over 22 legal pairs.

The adopted optional profile retains the original recovery ordering.
Truth-toggle pin-dependency checks and sorted, deduplicated physical-ID
area sums preserve numerical semantics while reducing metric overhead.
The root-binary comparison gives 22 delay ties, eight area gains,
thirteen ties and one regression. Capacity selection restores eight
additional covers within the original limits. Compact div still imports
40,989 nodes and hyp 211,714; these are representation counts, not
lower bounds over equivalent implementations. Recovered sqrt remains
much slower than conventional mappings. The staged deadline is checked
between atomic work; it is not a preemptive per-stage limit.

'''+s[end:]
start=s.index('Arrival-only retention regresses bar/dec;');end=s.index('\\section{Conclusion}',start)
s=s[:start]+'''Arrival-only retention regresses bar/dec; canonical cut-bank compression
raises max area. The preceding physical-wire alias study gives nine
lower delays and thirteen ties over 22 legal pairs, but five area costs
increase. Subsequent capacity and metric changes are evaluated as one
fixed profile, rather than selecting a winner per circuit.

For bar/max/sin in both inventories, the current root version retains
full-study r0 and two new alternating-order repetitions: 36 verified
covers, 18 delay ties, 15 area gains, two ties and one regression.
All six bar pairs save area, with different magnitudes. Three-input sin
increases area by 0.72 in r0 but decreases it in both new repetitions.
Its serialized e-graph, cuts and retained-pool fingerprint match the
control, as do initial metrics and delay seed; 481 versus 490 local
trials support investigating deadline sensitivity rather than inferring
missing candidates. These repetitions do not establish statistical
confidence. All full-suite baseline gates remain false. Industrial
multi-output, ODC and independent regional saturation remain unassessed;
public timing excludes load, slew and interconnect.

'''+s[end:]
p.write_text(s);(o/'table_verification.json').write_text(json.dumps({'verified_candidate_cells':len(checks),'baseline_columns_unchanged':True,'fixed_source_profile':'root7854b020;40 fresh candidate observations, no best-repeat selection','records':checks},indent=2)+'\n');shutil.copy2(p,o/'after.tex');shutil.copy2(Path(__file__),o/'update.py');print('updated80cells; original5baselinecolumns unchanged')
