# Compact representation, phase-aware pin bindings, and retention audit

This is an isolated research version. Main mapper source and baseline algorithms
are unchanged. Final source, library, native binary, harness and prepared-input
fingerprints are in `source_freeze.json`. No per-design winner selection is used.

## Proven audit

`correspondence_v2/*/stage_join.json` separates boundary correspondence, generation,
retention and selected bindings. Simulation only proposes correspondences;
incremental SAT proves both directions before any equality is used as a lemma.
All original-versus-imported outputs are proved (sqrt64, voter1, multiplier128).
The critical-path samples are stratified, not exhaustive. Missing correspondence
is not proof of inequivalence or proof that no useful candidate exists.

| Design | Sample | No proved complete boundary | Named binding absent | Removed before retained pool | Retained, unselected | Selected |
|---|---:|---:|---:|---:|---:|---:|
| sqrt |55|14|3|17|5|16|
| voter |27|0|8|11|7|1|
| multiplier |40|0|1|5|5|29|

The concrete matching gap includes 4/5 physical pins driven by only 2/3 logical
variables, using complementary phases of the same variable on multiple pins.
Physical arity and actual support are different; bijective pin permutations alone
miss these bindings. This is independent of increasing the cut size.

## Implemented factors

* Profile0: unchanged small-key research control.
* Profile1: suppress already-ready, same-target heap events that cannot win the
  existing total priority order. Not-yet-ready producers are never removed.
* Profile3: profile1 plus exact 4/5-input cell cofactors with two complementary
  pin pairs. Reuse existing cuts/signals, no new e-nodes or cut slots. Preserve
  actual named physical pins and timing arcs and use the common provenance,
  normalization, retention and recovery paths.

The pending queue has a 256-graph binding-by-binding oracle with asymmetric and
nondependent arcs, duplicate inputs, cycles, ties and zero delays. This does not
prove equal wall-clock-limited recovery outcomes. The heap can still contain
stale weaker events and is not a hard one-entry-per-signal representation.

The folded matcher has exhaustive truth and three independent named-port CEC
fixtures, including indexed input names. Its valid RED is `folded_valid_red.log`.
The earlier guard-failing fixture runs are preserved but do not count as valid
REDs. A batch-mode stale-index integration failure is also preserved; the fix
respects batch versus streaming insertion. Final regression: 242 passed,
6 ignored,16 filtered; the two explicitly enabled folded tests also passed.
The unrelated whole-library run was interrupted in a slow synthesis test and
must not be reported as a completed full-library suite.

## Resource policy and evidence

`full_epfl/campaign.json` is a finite 60-attempt same-binary study,20 designs and
3 profiles. The policy remains rho=1/2,47 single-output cells, ordinary K6 cuts
with16 slots per class,100000 native retained candidates, source-plus-native
global retained accounting,16 SAT iterations,2 seconds inclusive recovery,
300 seconds mapping-only and the existing60-second native guard. Retained
capacity is not a bound on generated temporary instances or total RAM.

`configuration_erratum.json` identifies an unused inherited descriptive field
in the new harness: actual `--import-helper-fill` is0 in every group. Actual
argv, report settings and native headers, rather than that unused field, are
the configuration evidence. Frozen source and historical attempts are unedited.

`report_progress.py` checks artifact hashes, native header flags, cumulative
node accounting, global retained accounting, actual cuts/pool/recovery and final
CEC. It distinguishes native optimization success from source-only coverage.
`selected_folded_audit.json` describes selected complementary-pair instances.
`selected_paths.py` independently reproduces public physical area and pin delay;
selected-path descriptions alone do not establish all timing causality.

## Next decisions

No merge is authorized by isolated positive cases. Bar equal-delay area regression
and Div native failure must be retained. Log2/Hyp source-only CEC is not native
optimization success. Full comparisons precede any merge; repetitions may be
deferred when the full configuration already fails the adoption gate.

The user subsequently requested reconsidering resource restrictions during
method exploration. Keep this frozen study as historical controlled evidence.
New loose diagnostics should vary time, node allowance and retained capacity
independently, with a real memory guard and complete resource accounting.
Do not treat arbitrary60/5/2-second windows or rho=1/2 as theoretical algorithm
requirements. More budget cannot by itself expose missing compact subfunctions.

Promising next factors are exact projected A/D dominance before materializing
folded patterns; allocation-free frontier dependency setup; and paid compact
subfunction reification for library patterns. None is implemented by the present
matcher or proved to solve Hyp. A flat primitive representation or per-region
budget resets must not be mislabeled as the same cumulative resource policy.
