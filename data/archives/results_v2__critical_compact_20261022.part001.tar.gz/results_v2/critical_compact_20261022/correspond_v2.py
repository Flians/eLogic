"""Offline named-pin critical-boundary correspondence; signatures propose, SAT certifies."""
import argparse
from collections import Counter, defaultdict, deque
import csv
import hashlib
import itertools
import json
from pathlib import Path
import sys
from pysat.solvers import Minisat22

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "scripts/experiments/campaigns"))
sys.path.insert(0, str(ROOT / "scripts/experiments"))
import audit_compound_boundaries as old
from library_rules_paths import analyze
from analyze_epfl_structural_budget import read_binary_aig
from prototypes.region_stitch import symbols
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()


def run(bench, limit):
    folder = HERE / "correspondence_v2" / bench
    folder.mkdir(parents=True, exist_ok=False)
    graphfile = HERE / "graph_runs" / bench / "graph.json"
    graph = json.loads(graphfile.read_text())
    baselines = list(csv.DictReader((ROOT / "results_v2/single_output_wide_20261021/full_library_baseline_A_D_T/baseline_A_D_T.csv").open()))
    row = next(r for r in baselines if r["bench"] == bench and r["method"] == "mockturtle_emap_delay_resyn2")
    assert row["qualification"] == "equivalent"
    origin = Path(row["observation_report"]).parent
    mapped = origin / f"{bench}.mockturtle_emap_delay_resyn2/mapped.json"
    libpath = origin / "library.json"
    # A uniquely scoped read-only view lets the public path reader find the selected netlist.
    view = folder / "view"; view.mkdir()
    (view / "mapped.json").symlink_to(mapped)
    (view / "library.json").symlink_to(libpath)
    path = analyze(view, {"area": float(row["A"]), "delay": float(row["D"])})
    (folder / "critical_path.json").write_text(json.dumps(path, indent=2))
    library = {c["name"]: c for c in json.loads(libpath.read_text())}
    modules = json.loads(mapped.read_text())["modules"]
    net = modules.get("mapped", next(iter(modules.values())))
    source = ROOT / f"results_v2/epfl_resyn2_subjects_20261012/{bench}.resyn2.aig"
    raw = source.read_bytes(); n, roots, gates = read_binary_aig(raw)
    names, _ = symbols(raw, n, roots, gates)
    dag = old.Dag(n)
    src = {0: 0, **{i: 2*i for i in range(1, n+1)}}
    for v, (a, b) in gates.items():
        src[v] = dag.AND(src[a//2] ^ (a&1), src[b//2] ^ (b&1))
    # Topological physical netlist reconstruction, not a quadratic repeated whole-netlist scan.
    bits = {"0": 0, "1": 1}
    for i, name in enumerate(names, 1):
        p = net["ports"][name]; assert p["direction"] == "input" and len(p["bits"]) == 1
        bits[p["bits"][0]] = 2*i
    users = defaultdict(list); wait = {}; ready = deque()
    for name, cell in net["cells"].items():
        model = library[cell["type"]]
        deps = {cell["connections"][p][0] for p in model["vars"]} - bits.keys()
        wait[name] = len(deps)
        if not deps: ready.append(name)
        for b in deps: users[b].append(name)
    physical = {}
    while ready:
        name = ready.popleft(); cell = net["cells"][name]; model = library[cell["type"]]
        args = [bits[cell["connections"][p][0]] for p in model["vars"]]
        tt = sum(word << (64*i) for i, word in enumerate(model["tt"]))
        value = dag.tt(tt, args); output = cell["connections"][model["out_pin"]][0]
        assert output not in bits; bits[output] = value
        physical[name] = (value, args, model)
        for user in users[output]:
            wait[user] -= 1
            if wait[user] == 0: ready.append(user)
    assert len(physical) == len(net["cells"])
    # Dense class IDs are explicitly serialized by the probe; raw egg IDs are never assumed dense.
    pi = {var: names.index(name)+1 for _, var, name in graph["inputs"]}
    eg = {}; pending = {r["class"]: r["alternatives"] for r in graph["nodes"]}
    while pending:
        changed = False
        for cid in sorted(list(pending)):
            for node in pending[cid]:
                if not all(a in eg for a in node.get("args", [])): continue
                op = node["op"]
                if op == "pi": v = 2*pi[node["var"]]
                elif op == "const": v = int(node["value"])
                elif op == "not": v = eg[node["args"][0]] ^ 1
                else: v = dag.tt(node["tt"], [eg[a] for a in node["args"]])
                eg[cid] = v; del pending[cid]; changed = True; break
        assert changed, "no finite diagnostic representative"
    source_index = defaultdict(list); class_index = defaultdict(list)
    for var, value in src.items():
        for p in [0, 1]: source_index[dag.val(value ^ p)].append((var*2+p, value^p))
    for cid, value in eg.items():
        for p in [0, 1]: class_index[dag.val(value ^ p)].append((cid, p, value^p))
    solver = Minisat22(); const = len(dag.values); solver.add_clause([-const])
    # -(lit//2), not Python's floor division of a negative odd literal.
    def cnf(lit):
        return (const if lit == 0 else -const) if lit < 2 else (-(lit//2) if lit&1 else lit//2)
    for v, (a, b) in dag.g.items():
        x, y = cnf(a), cnf(b); solver.add_clause([-x, -y, v]); solver.add_clause([x, -v]); solver.add_clause([y, -v])
    cache = {}; proofs = []
    def equal(a, b):
        if a == b: return True
        if a == b^1: return False
        key = tuple(sorted((a, b)))
        if key in cache and cache[key] != "unknown": return cache[key] == "equal"
        status = "equal"
        for assumptions in [[cnf(a), -cnf(b)], [-cnf(a), cnf(b)]]:
            solver.conf_budget(100)
            answer = solver.solve_limited(assumptions=assumptions)
            if answer is None: status = "unknown"; break
            if answer: status = "different"; break
        cache[key] = status; proofs.append(dict(left=a, right=b, status=status))
        if status == "equal":
            solver.add_clause([-cnf(a),cnf(b)]);solver.add_clause([cnf(a),-cnf(b)])
        return status == "equal"
    certified = 0
    # Prove inner equivalences first; every asserted lemma was separately UNSAT-certified.
    for value in sorted(set(eg.values()) | {v[0] for v in physical.values()}, key=lambda v:v//2):
        options=sorted(source_index.get(dag.val(value),[]),key=lambda p:(p[1]!=value,p[0]))
        for _,rhs in options:
            if equal(value,rhs):certified+=1;break
    print(bench,"certified sweep",certified,flush=True)
    correspondence = {}
    def endpoint(value):
        if value in correspondence: return correspondence[value]
        ss = source_index.get(dag.val(value), [])
        ss = sorted(ss, key=lambda p: (p[1] != value, p[0]))
        source_hits = next(([literal] for literal, rhs in ss if equal(value, rhs)), [])
        proposals = class_index.get(dag.val(value), [])
        classes = [[cid, p] for cid, p, rhs in proposals if equal(value, rhs)]
        out = dict(original_literals=source_hits, classes=classes,
                   signature_class_proposals=len(proposals),
                   rejected_or_unknown_proposals=len(proposals)-len(classes))
        correspondence[value] = out; return out
    root_checks = []
    for (signal, name), original in zip(graph["outputs"], roots):
        representative = eg[signal//2] ^ (signal&1)
        value = src[original//2] ^ (original&1)
        root_checks.append(dict(output=name, proved=equal(representative, value)))
    # Predetermined stratification along the reference critical path, plus first/last of each family.
    path_steps = path["path"]
    picks = {round(i*(len(path_steps)-1)/max(1, limit-1)) for i in range(min(limit, len(path_steps)))}
    families = defaultdict(list)
    for i, step in enumerate(path_steps): families[step["type"]].append(i)
    for positions in families.values(): picks.update([positions[0], positions[-1]])
    banks = defaultdict(list)
    for c in graph["cuts"]: banks[c["class"]].append(c)
    records, queries = [], []
    for pos in sorted(picks):
        step = path_steps[pos]; value, args, model = physical[step["cell"]]
        out = endpoint(value); ins = [endpoint(a) for a in args]
        label = f"path{pos}:{step['type']}"
        complete = bool(out["classes"] and all(p["classes"] for p in ins))
        matches = []; product_truncated = False
        if complete:
            alternatives = 1
            for p in ins: alternatives *= len(p["classes"])
            product_truncated = alternatives > 4096
            for combo in itertools.islice(itertools.product(*(p["classes"] for p in ins)), 4096):
                leaves = sorted({cid for cid, _ in combo})
                if len(leaves) > 6: continue
                tt = 0
                for assignment in range(1 << len(leaves)):
                    raw = sum((((assignment >> leaves.index(cid))&1)^phase) << k for k, (cid, phase) in enumerate(combo))
                    tt |= ((model["tt"][raw//64] >> (raw%64))&1) << assignment
                mask = (1 << (1 << len(leaves)))-1
                for cid, phase in out["classes"]:
                    for cut in banks[cid]:
                        if cut["leaves"] == leaves and cut["function"] == (tt ^ (mask if phase else 0)):
                            matches.append(dict(class_id=cid, phase=phase, leaves=leaves))
            canonical = graph["canonical"]
            queries.append(dict(label=label, cell=step["type"], output=model["out_pin"],
                                targets=sorted({canonical[c*2+p] for c,p in out["classes"]}),
                                pins={pin:sorted({canonical[c*2+p] for c,p in ep["classes"]}) for pin,ep in zip(model["vars"],ins)}))
        records.append(dict(position=pos,label=label,cell=step["type"],critical_input_pin=step["input_pin"],
                            output=out,inputs=ins,all_class_endpoints_proved=complete,
                            matching_retained_small_cut_count=len(matches),matching_cuts=matches[:16],
                            input_class_product_truncated=product_truncated,
                            missing_class_endpoint=not complete))
    solver.delete()
    (folder / "queries.json").write_text(json.dumps(dict(offline_diagnostic_only=True,queries=queries),indent=2))
    report = dict(bench=bench,offline_diagnostic_only=True,formal_PPA_result=False,
                  path_gates=len(path_steps),sampled_gates=len(records),sampling="uniform path positions plus first/last of each cell family",
                  root_checks=root_checks,certified_sweep_lemmas=certified,proofs=proofs,proof_conflicts_per_direction=100,
                  simulation_only_proposes_correspondence=True,unknown_not_accepted=True,
                  records=records,summary=dict(all_endpoints=sum(r["all_class_endpoints_proved"] for r in records),
                  with_small_cut=sum(r["matching_retained_small_cut_count"]>0 for r in records)),
                  hashes={str(p):sha(p) for p in [source,mapped,libpath,graphfile,Path(__file__)]})
    (folder / "report.json").write_text(json.dumps(report,indent=2))
    print(bench,report["summary"],"root proof",sum(r["proved"]for r in root_checks),"/",len(root_checks),flush=True)


if __name__ == "__main__":
    p=argparse.ArgumentParser();p.add_argument("--designs",nargs="+",default=["sqrt","voter","multiplier"]);p.add_argument("--samples",type=int,default=32);a=p.parse_args()
    for b in a.designs:run(b,a.samples)
