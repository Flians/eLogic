"""After experiments, reproduce public PPA and describe selected paths only."""
import argparse,json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'scripts/experiments/campaigns'))
from library_rules_paths import analyze
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--campaign',type=Path,required=True);ap.add_argument('--output',type=Path,required=True);a=ap.parse_args();a.output.mkdir(exist_ok=False)
    state=json.loads(a.campaign.read_text());summary=[]
    for j in state['jobs']:
        if not j.get('report'):continue
        report=Path(j['report']);row=json.loads(report.read_text())['results'][0]
        if row['status']!='ok':continue
        p=analyze(report.parent,row['measured']);(a.output/(j['name']+'.json')).write_text(json.dumps(p,indent=2)+'\n')
        summary.append(dict(job=j['name'],bench=j['bench'],profile=j['profile'],**{k:v for k,v in p.items()if k!='path'}))
    (a.output/'summary.json').write_text(json.dumps({'scope':'Selected netlist description, not proof of candidate absence or all causality','rows':summary},indent=2)+'\n')
if __name__=='__main__':main()
