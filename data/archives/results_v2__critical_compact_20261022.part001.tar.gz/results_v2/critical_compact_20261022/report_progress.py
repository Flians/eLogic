"""Read-only reconciliation; native success and source-only CEC remain distinct."""
import argparse
import csv
import hashlib
import json
from pathlib import Path

def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--campaign', type=Path, required=True)
    ap.add_argument('--output', type=Path, required=True)
    args = ap.parse_args()
    state = json.loads(args.campaign.read_text())
    args.output.mkdir(exist_ok=False)
    rows, budgets, observations = [], [], {}
    for job in state['jobs']:
        for path, digest in job['sha256'].items():
            assert sha(path) == digest, path
        profile = job['profile']
        if not job.get('report'):
            rows.append(dict(bench=job['bench'], profile=profile, status='unmeasured-failure'))
            continue
        row = json.loads(Path(job['report']).read_text())['results'][0]
        sc = row.get('scalability', {})
        policy = row.get('resource_policy', {})
        native = sc.get('optimizer_native', {})
        measured = row.get('measured', {})
        assert row['mapping_wall_secs'] <= 300
        if sc:
            assert sc['cumulative_accounted_enode_upper'] <= policy['node_limit']
            assert sc['source_plus_optimizer_retained_upper'] <= policy['global_retained_candidate_limit']
            assert not policy['refund_on_rebuild']
        for attempt in sc.get('attempts', []):
            text = Path(attempt['stderr_path']).read_text()
            for flag, value in [('EGM_PENDING_FRONTIER',profile & 1),('EGM_FOLDED_PIN_MATCH',(profile >> 1) & 1)]:
                assert f'configuration: {flag}={value}' in text, (job['name'],flag)
        if sc.get('optimizer_succeeded'):
            assert native['max_cuts_per_class'] <= 16
            assert native['instances'] <= 100000
            assert native['heuristic_secs'] <= 2
        if row['status'] == 'ok':
            assert measured['cec'] == 1
        value = dict(bench=job['bench'], profile=profile, status=row['status'],
            native_success=bool(sc.get('optimizer_succeeded')), selected=sc.get('selected'),
            area=measured.get('area'), delay=measured.get('delay'), mapping_secs=row['mapping_wall_secs'])
        rows.append(value)
        observations[(job['bench'],profile)] = value
        budgets.append(dict(job=job['name'],cumulative=sc.get('cumulative_accounted_enode_upper'),
            limit=policy.get('node_limit'), retained_upper=sc.get('source_plus_optimizer_retained_upper'),
            global_pool=policy.get('global_retained_candidate_limit'), native_pool=native.get('instances'),
            recovery_secs=native.get('heuristic_secs'), generated=native.get('generated_instances')))
    pairs = []
    for bench in state['configuration']['designs']:
        for a,b in [(0,1),(1,3)]:
            x,y = observations.get((bench,a)),observations.get((bench,b))
            if not x or not y: continue
            valid = x['status']==y['status']=='ok' and x['native_success'] and y['native_success']
            pairs.append(dict(bench=bench,control=a,candidate=b,native_pair=valid,
                delay_delta=y['delay']-x['delay'] if valid else None,
                area_delta=y['area']-x['area'] if valid else None))
    result = dict(completed_jobs=len(state['jobs']), expected_jobs=state['expected_jobs'],
        rows=rows, pairs=pairs, budgets=budgets,
        all_attempts_finished=len(state['jobs'])==state['expected_jobs'],
        campaign_sha256=sha(args.campaign), source_fingerprints=state['fingerprint'],
        no_main_or_baseline_changes=True,
        scope='No per-design winner selection; source-only rows excluded from native optimization comparisons')
    (args.output/'validation.json').write_text(json.dumps(result,indent=2)+'\n')
    fields=['bench','profile','status','native_success','selected','area','delay','mapping_secs']
    with (args.output/'A_D_T.csv').open('w') as out:
        writer=csv.DictWriter(out,fields);writer.writeheader();writer.writerows(rows)
    print(json.dumps({k:result[k] for k in ['completed_jobs','expected_jobs','all_attempts_finished']}))

if __name__=='__main__': main()
