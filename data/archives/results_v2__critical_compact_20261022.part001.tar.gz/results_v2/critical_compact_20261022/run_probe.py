"""Finite, sequential offline boundary diagnostic. Its timings are not PPA results."""
import argparse
import fcntl
import hashlib
import json
import os
from pathlib import Path
import resource
import signal
import subprocess
import time

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--designs", nargs="+", default=["sqrt", "voter", "multiplier"])
    ap.add_argument("--queries", action="store_true")
    args = ap.parse_args()
    locks = []
    for p in [ROOT / "results_v2/independent_components_20261019/global.lock",
              ROOT / "results_v2/epfl_original_baselines_resumed_checkpoint_20261013/runner.lock"]:
        f = p.open("a"); fcntl.flock(f, fcntl.LOCK_EX | fcntl.LOCK_NB); locks.append(f)
    cp = ROOT / "results_v2/search_resources_20261021/small_key_epfl/campaign.json"
    source = json.loads(cp.read_text())
    output = HERE / ("query_runs" if args.queries else "graph_runs")
    output.mkdir(exist_ok=True)
    checkpoint = output / "campaign.json"
    records = json.loads(checkpoint.read_text())["jobs"] if checkpoint.exists() else []
    for bench in args.designs:
        if any(j["bench"] == bench for j in records):
            continue
        j = next(j for j in source["jobs"] if j["bench"] == bench)
        report = json.loads(Path(j["report"]).read_text())["results"][0]
        attempt = report["scalability"]["attempts"][0]
        folder = output / bench
        folder.mkdir(exist_ok=False)
        argv = list(attempt["argv"])
        argv[0] = str(HERE / "source_probe/target/release/bench_rs_egraph_wide")
        argv[-1] = str(folder / "raw.v")
        env = {k: v for k, v in os.environ.items() if not k.startswith(("EGM_", "ESYN_"))}
        env.update(report["settings"])
        env.update(source["configuration"]["fixed_native_configuration"])
        env.pop("EGM_DIAG_PATH", None)
        env["EGM_POOL_DIAG_PATH"] = str(folder / "pool.json")
        env["EGM_RECOVERY_TRACE"] = str(folder / "recovery.json")
        if args.queries:
            env["EGM_BOUNDARY_QUERY_PATH"] = str(HERE / "correspondence_v2" / bench / "queries.json")
            env["EGM_BOUNDARY_AUDIT_PATH"] = str(folder / "graph.json")
            assert Path(env["EGM_BOUNDARY_QUERY_PATH"]).exists()
        else:
            env["EGM_BOUNDARY_AUDIT_PATH"] = str(folder / "graph.json")
            env["EGM_BOUNDARY_AUDIT_STOP"] = "1"
        (folder / "command.json").write_text(json.dumps(dict(argv=argv, environment={k: v for k, v in env.items() if k.startswith("EGM_")},
            offline_diagnostic_only=True, native_guard=60, source_report=j["report"], source_report_sha256=sha(j["report"]), binary_sha256=sha(argv[0])), indent=2))
        def limit():
            resource.setrlimit(resource.RLIMIT_AS, (16 * 1024**3, 16 * 1024**3))
        start = time.monotonic()
        with (folder / "stdout").open("w") as out, (folder / "stderr").open("w") as err:
            p = subprocess.Popen(argv, cwd=ROOT, env=env, stdout=out, stderr=err,
                                 preexec_fn=limit, start_new_session=True)
            timeout = False
            try:
                p.wait(timeout=60)
            except subprocess.TimeoutExpired:
                timeout = True; os.killpg(p.pid, signal.SIGKILL); p.wait()
        records.append(dict(bench=bench, exit_code=p.returncode, timeout=timeout,
                            wall=time.monotonic()-start, artifacts={str(p): sha(p) for p in folder.iterdir() if p.is_file()}))
        checkpoint.write_text(json.dumps(dict(offline_diagnostic_only=True, formal_mapping_results=False,
                                              source_campaign=str(cp), jobs=records), indent=2))
        print(bench, p.returncode, timeout, flush=True)


if __name__ == "__main__":
    main()
