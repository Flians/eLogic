module mapped(\a[0] , \b[0] , \result[0] );
  input \a[0] ;
  input \b[0] ;
  output \result[0] ;
  wire __egm_s1;
  wire __egm_s16;
  wire __egm_s5;
  INVx1_ASAP7_75t_R __egm_g0 (.A(\b[0] ), .Y(__egm_s1));
  INVx1_ASAP7_75t_R __egm_g81 (.A(\a[0] ), .Y(__egm_s5));
  AO22x1_ASAP7_75t_R __egm_g112 (.A1(\b[0] ), .A2(\a[0] ), .B1(__egm_s1), .B2(__egm_s5), .Y(__egm_s16));
  assign \result[0]  = __egm_s16;
endmodule
