module mapped(\a[0] , \b[0] , \c[0] , \result[0] );
  input \a[0] ;
  input \b[0] ;
  input \c[0] ;
  output \result[0] ;
  wire __egm_s24;
  wire __egm_s5;
  wire __egm_s9;
  INVx1_ASAP7_75t_R __egm_g17 (.A(\b[0] ), .Y(__egm_s5));
  INVx1_ASAP7_75t_R __egm_g98 (.A(\a[0] ), .Y(__egm_s9));
  OA221x2_ASAP7_75t_R __egm_g123 (.A1(\b[0] ), .A2(\a[0] ), .B1(__egm_s5), .B2(__egm_s9), .C(\c[0] ), .Y(__egm_s24));
  assign \result[0]  = __egm_s24;
endmodule
