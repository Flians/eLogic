module mapped(p0, p1, p2, p3, p4, o0, o1);
  input p0;
  input p1;
  input p2;
  input p3;
  input p4;
  output o0;
  output o1;
  wire __egm_s20;
  wire __egm_s24;
  wire __egm_s32;
  wire __egm_s9;
  INVx1_ASAP7_75t_R __egm_g2 (.A(p2), .Y(__egm_s9));
  AND2x2_ASAP7_75t_R __egm_g5 (.A(p1), .B(p0), .Y(__egm_s20));
  NOR2x1_ASAP7_75t_R __egm_g27 (.A(__egm_s9), .B(__egm_s20), .Y(__egm_s24));
  AND3x1_ASAP7_75t_R __egm_g98 (.B(p4), .C(p3), .A(__egm_s24), .Y(__egm_s32));
  assign o0 = __egm_s32;
  assign o1 = __egm_s20;
endmodule
