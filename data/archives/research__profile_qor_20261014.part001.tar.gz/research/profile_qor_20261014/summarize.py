"""Audit the main-cohort diagnostic; never overwrite published v23 artifacts."""
import argparse,csv,hashlib,json,re,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'scripts/experiments'))
from audit_mapped_ppa import audit
parser=argparse.ArgumentParser();parser.add_argument('--arm',choices=['progressive','phase'],default='phase');args=parser.parse_args()
REPORT=OUT/(args.arm+'_report');REPORT.mkdir(exist_ok=True)
LIB=ROOT/'results_v20_three_parts_chain/inputs/asap7.genlib' 
DESIGNS=['aes_core','arbiter','div','ethernet','iwls05_i2c','mem_ctrl','RISC','sasc','simple_spi','spi','sqrt','systemcaes','systemcdes','tv80','usb_funct','usb_phy']
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def readrun(p):
 log=(p/'log').read_text();a=audit(p/'epmapping_mapped.v',LIB);b=audit(p/'epmapping_baseline.v',LIB)
 assert 'cec=1' in log and 'window_synth windows=0 applied=0' in log and 'post_mapping_timeout=1000' in log,p
 assert a['delay']<=b['delay']+.001 and a['area']<=b['area']+.0001,p
 assert a['serialized_delay']<=b['serialized_delay']+.001,p
 return a,b,log
rows=[];proof=[];pending=[]
for d in DESIGNS:
 name='usb' if d=='usb_phy' else d
 c=OUT/'runs'/(args.arm+'_'+name);w=OUT/'runs'/('progressive_usb_warm' if args.arm=='progressive' and d=='usb_phy' else args.arm+'_warm_'+(name if args.arm=='phase' else d))
 if not all((p/'audit.json').exists() for p in (c,w)):pending.append(d);continue
 old=ROOT/'results_v20_three_parts_chain/tab_main'/('ae.'+d)
 prev=ROOT/'results_v23_three_parts_profiles/cold/tab_main'/('ae.'+d)
 a,b,cl=readrun(c);wa,wb,wl=readrun(w)
 assert (c/'epmapping_baseline.v').read_bytes()==(old/'epmapping_baseline.v').read_bytes()==(w/'epmapping_baseline.v').read_bytes(),d
 assert abs(a['area']-wa['area'])<1e-6 and abs(a['delay']-wa['delay'])<1e-6,d
 oa=audit(old/'epmapping_mapped.v',LIB);pa=audit(prev/'epmapping_mapped.v',LIB)
 manifests=[json.loads((p/'manifest.json').read_text()) for p in (c,w)]
 assert manifests[0]['binary_sha256']==manifests[1]['binary_sha256']==sha(c/'epmapping_check')==sha(w/'epmapping_check')
 for m in manifests:
  assert m['env']['EPMAPPING_POST_TIMEOUT']=='1000' and m['env']['EPMAPPING_WINDOW_SYN']=='0' and m['env']['MAP_EGG_PROFILE']=='1'
 def seconds(s):return float(re.search(r'epmapping timing .*optimizer=([\d.]+)',s)[1])
 def stats(s):return {k:int(v) for k,v in re.findall(r'(\w+)=(\d+)',re.search(r'egraph_profile (.*)',s)[1])}
 row=dict(design=d,initial_area=round(b['area'],2),initial_delay=round(b['delay'],2),old_area=round(oa['area'],2),old_delay=round(oa['delay'],2),v23_area=round(pa['area'],2),v23_delay=round(pa['delay'],2),fixed_area=round(a['area'],2),fixed_delay=round(a['delay'],2),cold_seconds=seconds(cl),warm_seconds=seconds(wl),cold_warm_netlist_identical=sha(c/'epmapping_mapped.v')==sha(w/'epmapping_mapped.v'))
 rows.append(row);proof.append(dict(**row,baseline_sha256=sha(c/'epmapping_baseline.v'),binary_sha256=sha(c/'epmapping_check'),cold_log_sha256=sha(c/'log'),warm_log_sha256=sha(w/'log'),cold_stats=stats(cl),warm_stats=stats(wl),independent_cold=a,independent_warm=wa))
if pending:print('Pending cold/warm pairs: '+', '.join(pending));sys.exit(2)
with (REPORT/'main_comparison.tsv').open('w') as f:
 writer=csv.DictWriter(f,fieldnames=list(rows[0]),delimiter='\t');writer.writeheader();writer.writerows(rows)
metrics={k:sum(r[k] for r in rows) for k in ['old_area','v23_area','fixed_area','cold_seconds','warm_seconds']}
metrics.update(area_wins_vs_v23=sum(r['fixed_area']<r['v23_area']-.0001 for r in rows),area_losses_vs_v23=sum(r['fixed_area']>r['v23_area']+.0001 for r in rows),area_wins_vs_old=sum(r['fixed_area']<r['old_area']-.0001 for r in rows),area_losses_vs_old=sum(r['fixed_area']>r['old_area']+.0001 for r in rows),area_wins_vs_initial=sum(r['fixed_area']<r['initial_area']-.0001 for r in rows),paired_netlists_identical=sum(r['cold_warm_netlist_identical'] for r in rows))
for arm in ['old','v23','fixed']:
 metrics[arm+'_mean_area_reduction_pct']=sum(100*(1-r[arm+'_area']/r['initial_area']) for r in rows)/len(rows)
 metrics[arm+'_mean_delay_reduction_pct']=sum(100*(1-r[arm+'_delay']/r['initial_delay']) for r in rows)/len(rows)
(REPORT/'verified_main.json').write_text(json.dumps(dict(scope=args.arm+': six-round main cohort only; not a replacement for the complete three-part campaign',metrics=metrics,runs=proof),indent=2)+'\n')
lines=['Main-cohort diagnostic: fixed original v20 inputs; six rounds; full library; fixed initial worst-output delay bound; whole-window synthesis OFF; post-mapping 1000 s.', 'Cold/warm optimizer times below are single observations with replacement tracing and concurrent jobs, not formal speedup measurements.', 'Published v23 paper/results remain unchanged. This diagnostic covers the 16-design main cohort only.','', 'design initial_A old_A v23_A fixed_A initial_D old_D v23_D fixed_D cold_s warm_s']
for r in rows:lines.append(' '.join(str(r[k]) for k in ['design','initial_area','old_area','v23_area','fixed_area','initial_delay','old_delay','v23_delay','fixed_delay','cold_seconds','warm_seconds']))
lines += ['',json.dumps(metrics,indent=2)]
(REPORT/'results.txt').write_text('\n'.join(lines)+'\n');print(json.dumps(metrics,indent=2))
