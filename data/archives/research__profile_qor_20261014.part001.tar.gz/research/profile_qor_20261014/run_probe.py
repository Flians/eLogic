import argparse, os, subprocess, json, shutil, hashlib, sys
from pathlib import Path
root=Path(__file__).resolve().parents[2]
p=argparse.ArgumentParser();p.add_argument('name');p.add_argument('--binary',default='build/epmapping/epmapping_check');p.add_argument('--profile',default='1');p.add_argument('--design',default='usb_phy');p.add_argument('--env',action='append',default=[]);args=p.parse_args()
wd=root/'research/profile_qor_20261014/runs'/args.name;wd.mkdir(parents=True,exist_ok=False)
env={k:v for k,v in os.environ.items() if not k.startswith(('EPMAPPING_','EPM_','MAP_EGG_'))}
for line in (root/'results_v24_usb_profile_diagnosis/runs/legacy.usb_phy/experiment_env.txt').read_text().splitlines():
 k,v=line.split('=',1);env[k]=v
env.update(MAP_EGG_PROFILE=args.profile,MAP_EGG_PROFILE_CACHE_DIR=str(wd/'cache'),EPMAPPING_REPLACEMENT_TRACE='1',ABC=str(root/'results_v20_three_parts_chain/inputs/abc'))
for x in args.env:k,v=x.split('=',1);env[k]=v
binary=root/args.binary;shutil.copy2(binary,wd/'epmapping_check')
cmd=[str(wd/'epmapping_check'),str(root/'results_v20_three_parts_chain/inputs/asap7.genlib'),str(root/f'results_v20_three_parts_chain/inputs/benchmarks/{args.design}.aig'),str(wd)]
(wd/'manifest.json').write_text(json.dumps(dict(cmd=cmd,env={k:v for k,v in env.items() if k.startswith(('EPMAPPING','MAP_EGG'))},binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest()),indent=2))
with (wd/'log').open('w') as f:q=subprocess.run(cmd,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=1100)
print(args.name,q.returncode,flush=True)
sys.path.insert(0,str(root/'scripts/experiments'));from audit_mapped_ppa import audit
base=audit(wd/'epmapping_baseline.v',cmd[1]);out=audit(wd/'epmapping_mapped.v',cmd[1]);assert out['delay']<=base['delay']+.001
assert (wd/'epmapping_baseline.v').read_bytes()==(root/f'results_v20_three_parts_chain/tab_main/ae.{args.design}/epmapping_baseline.v').read_bytes()
assert 'cec=1' in (wd/'log').read_text()
(wd/'audit.json').write_text(json.dumps(dict(base=base,out=out),indent=2));print(json.dumps(dict(name=args.name,area=out['area'],delay=out['delay'])),flush=True)
