// Benchmark "/home/flynn/workplace/MIGBalance/results_v2/fixed_all_esyn_20261012/c1908/output_from_egg12/logic" written by ABC on Mon Oct 12 15:04:33 2026

module \/home/flynn/workplace/MIGBalance/results_v2/fixed_all_esyn_20261012/c1908/output_from_egg12/logic  ( 
    G24, G33, G31, G30, G32, G8, G6, G3, G15, G10, G12, G19, G28, G9, G14,
    G16, G18, G11, G5, G2, G27, G7, G4, G20, G13, G1, G17, G26, G22, G25,
    G21, G29, G23,
    G1899, G1884, G1885, G1898, G1886, G1887, G1888, G1889, G1890, G1891,
    G1892, G1893, G1894, G1895, G1896, G1897, G1900, G1901, G1902, G1903,
    G1904, G1905, G1906, G1907, G1908  );
  input  G24, G33, G31, G30, G32, G8, G6, G3, G15, G10, G12, G19, G28,
    G9, G14, G16, G18, G11, G5, G2, G27, G7, G4, G20, G13, G1, G17, G26,
    G22, G25, G21, G29, G23;
  output G1899, G1884, G1885, G1898, G1886, G1887, G1888, G1889, G1890, G1891,
    G1892, G1893, G1894, G1895, G1896, G1897, G1900, G1901, G1902, G1903,
    G1904, G1905, G1906, G1907, G1908;
  wire new_n59_, new_n60_, new_n61_, new_n62_, new_n63_, new_n64_, new_n65_,
    new_n66_, new_n67_, new_n68_, new_n69_, new_n70_, new_n71_, new_n72_,
    new_n73_, new_n74_, new_n75_, new_n76_, new_n77_, new_n78_, new_n79_,
    new_n80_, new_n81_, new_n82_, new_n83_, new_n84_, new_n85_, new_n86_,
    new_n87_, new_n88_, new_n89_, new_n90_, new_n91_, new_n92_, new_n93_,
    new_n94_, new_n95_, new_n96_, new_n97_, new_n98_, new_n99_, new_n100_,
    new_n101_, new_n102_, new_n103_, new_n104_, new_n105_, new_n106_,
    new_n107_, new_n108_, new_n109_, new_n110_, new_n111_, new_n112_,
    new_n113_, new_n114_, new_n115_, new_n116_, new_n117_, new_n118_,
    new_n119_, new_n120_, new_n121_, new_n122_, new_n123_, new_n124_,
    new_n125_, new_n126_, new_n127_, new_n128_, new_n129_, new_n130_,
    new_n131_, new_n132_, new_n133_, new_n134_, new_n135_, new_n136_,
    new_n137_, new_n138_, new_n139_, new_n140_, new_n141_, new_n142_,
    new_n143_, new_n144_, new_n145_, new_n146_, new_n147_, new_n148_,
    new_n149_, new_n150_, new_n151_, new_n152_, new_n153_, new_n154_,
    new_n155_, new_n156_, new_n157_, new_n158_, new_n159_, new_n160_,
    new_n162_, new_n163_, new_n164_, new_n165_, new_n166_, new_n167_,
    new_n168_, new_n174_, new_n178_, new_n179_, new_n180_, new_n185_,
    new_n189_, new_n190_, new_n191_, new_n192_, new_n193_, new_n194_,
    new_n195_, new_n196_, new_n198_, new_n199_, new_n200_, new_n201_,
    new_n203_, new_n204_, new_n205_, new_n207_, new_n208_, new_n210_,
    new_n211_, new_n213_, new_n214_, new_n216_, new_n217_, new_n218_,
    new_n219_, new_n221_, new_n222_, new_n223_, new_n224_, new_n225_,
    new_n227_, new_n228_;
  INVx1_ASAP7_75t_R   g000(.A(G24), .Y(new_n59_));
  INVx1_ASAP7_75t_R   g001(.A(G33), .Y(new_n60_));
  INVx1_ASAP7_75t_R   g002(.A(G31), .Y(new_n61_));
  INVx1_ASAP7_75t_R   g003(.A(G32), .Y(new_n62_));
  INVx1_ASAP7_75t_R   g004(.A(G8), .Y(new_n63_));
  INVx1_ASAP7_75t_R   g005(.A(G3), .Y(new_n64_));
  INVx1_ASAP7_75t_R   g006(.A(G10), .Y(new_n65_));
  INVx1_ASAP7_75t_R   g007(.A(G28), .Y(new_n66_));
  INVx1_ASAP7_75t_R   g008(.A(G9), .Y(new_n67_));
  INVx1_ASAP7_75t_R   g009(.A(G16), .Y(new_n68_));
  INVx1_ASAP7_75t_R   g010(.A(G18), .Y(new_n69_));
  INVx1_ASAP7_75t_R   g011(.A(G11), .Y(new_n70_));
  INVx1_ASAP7_75t_R   g012(.A(G5), .Y(new_n71_));
  INVx1_ASAP7_75t_R   g013(.A(G27), .Y(new_n72_));
  INVx1_ASAP7_75t_R   g014(.A(G4), .Y(new_n73_));
  INVx1_ASAP7_75t_R   g015(.A(G13), .Y(new_n74_));
  INVx1_ASAP7_75t_R   g016(.A(G1), .Y(new_n75_));
  INVx1_ASAP7_75t_R   g017(.A(G26), .Y(new_n76_));
  INVx1_ASAP7_75t_R   g018(.A(G22), .Y(new_n77_));
  INVx1_ASAP7_75t_R   g019(.A(G21), .Y(new_n78_));
  INVx1_ASAP7_75t_R   g020(.A(G23), .Y(new_n79_));
  OAI21x1_ASAP7_75t_R g021(.A1(G31), .A2(G23), .B(G19), .Y(new_n80_));
  XNOR2x2_ASAP7_75t_R g022(.A(new_n65_), .B(G7), .Y(new_n81_));
  XOR2x2_ASAP7_75t_R  g023(.A(G9), .B(G14), .Y(new_n82_));
  XOR2x2_ASAP7_75t_R  g024(.A(G16), .B(new_n82_), .Y(new_n83_));
  XOR2x2_ASAP7_75t_R  g025(.A(new_n73_), .B(new_n83_), .Y(new_n84_));
  AND3x1_ASAP7_75t_R  g026(.A(new_n60_), .B(new_n79_), .C(G20), .Y(new_n85_));
  XNOR2x2_ASAP7_75t_R g027(.A(new_n74_), .B(new_n85_), .Y(new_n86_));
  XNOR2x2_ASAP7_75t_R g028(.A(new_n84_), .B(new_n86_), .Y(new_n87_));
  XNOR2x2_ASAP7_75t_R g029(.A(new_n81_), .B(new_n87_), .Y(new_n88_));
  NAND2x1_ASAP7_75t_R g030(.A(new_n61_), .B(new_n88_), .Y(new_n89_));
  XOR2x2_ASAP7_75t_R  g031(.A(new_n80_), .B(new_n89_), .Y(new_n90_));
  AND3x1_ASAP7_75t_R  g032(.A(new_n59_), .B(new_n60_), .C(G17), .Y(new_n91_));
  XNOR2x2_ASAP7_75t_R g033(.A(G6), .B(G7), .Y(new_n92_));
  XOR2x2_ASAP7_75t_R  g034(.A(G5), .B(new_n92_), .Y(new_n93_));
  XNOR2x2_ASAP7_75t_R g035(.A(new_n75_), .B(new_n93_), .Y(new_n94_));
  XOR2x2_ASAP7_75t_R  g036(.A(new_n91_), .B(new_n94_), .Y(new_n95_));
  XOR2x2_ASAP7_75t_R  g037(.A(G15), .B(new_n68_), .Y(new_n96_));
  XOR2x2_ASAP7_75t_R  g038(.A(G10), .B(new_n96_), .Y(new_n97_));
  XNOR2x2_ASAP7_75t_R g039(.A(new_n70_), .B(new_n97_), .Y(new_n98_));
  XNOR2x2_ASAP7_75t_R g040(.A(G12), .B(new_n74_), .Y(new_n99_));
  XOR2x2_ASAP7_75t_R  g041(.A(new_n98_), .B(new_n99_), .Y(new_n100_));
  INVx1_ASAP7_75t_R   g042(.A(new_n100_), .Y(new_n101_));
  XOR2x2_ASAP7_75t_R  g043(.A(new_n95_), .B(new_n100_), .Y(new_n102_));
  OR2x4_ASAP7_75t_R   g044(.A(G31), .B(new_n102_), .Y(new_n103_));
  XOR2x2_ASAP7_75t_R  g045(.A(new_n76_), .B(new_n103_), .Y(new_n104_));
  OR2x4_ASAP7_75t_R   g046(.A(new_n90_), .B(new_n104_), .Y(new_n105_));
  OAI21x1_ASAP7_75t_R g047(.A1(G24), .A2(G31), .B(G17), .Y(new_n106_));
  XOR2x2_ASAP7_75t_R  g048(.A(new_n63_), .B(G4), .Y(new_n107_));
  XNOR2x2_ASAP7_75t_R g049(.A(new_n64_), .B(G2), .Y(new_n108_));
  XNOR2x2_ASAP7_75t_R g050(.A(new_n75_), .B(new_n108_), .Y(new_n109_));
  XOR2x2_ASAP7_75t_R  g051(.A(new_n93_), .B(new_n109_), .Y(new_n110_));
  XOR2x2_ASAP7_75t_R  g052(.A(new_n107_), .B(new_n110_), .Y(new_n111_));
  NOR2x1_ASAP7_75t_R  g053(.A(G33), .B(new_n78_), .Y(new_n112_));
  XNOR2x2_ASAP7_75t_R g054(.A(new_n67_), .B(new_n112_), .Y(new_n113_));
  XOR2x2_ASAP7_75t_R  g055(.A(new_n97_), .B(new_n113_), .Y(new_n114_));
  XNOR2x2_ASAP7_75t_R g056(.A(new_n111_), .B(new_n114_), .Y(new_n115_));
  NOR2x1_ASAP7_75t_R  g057(.A(G31), .B(new_n115_), .Y(new_n116_));
  XNOR2x2_ASAP7_75t_R g058(.A(new_n106_), .B(new_n116_), .Y(new_n117_));
  AO21x1_ASAP7_75t_R  g059(.A1(new_n59_), .A2(new_n61_), .B(new_n69_), .Y(new_n118_));
  INVx1_ASAP7_75t_R   g060(.A(new_n118_), .Y(new_n119_));
  OR3x1_ASAP7_75t_R   g061(.A(new_n117_), .B(new_n118_), .C(new_n105_), .Y(new_n120_));
  OA21x2_ASAP7_75t_R  g062(.A1(G31), .A2(G23), .B(G20), .Y(new_n121_));
  INVx1_ASAP7_75t_R   g063(.A(new_n121_), .Y(new_n122_));
  XOR2x2_ASAP7_75t_R  g064(.A(G14), .B(new_n73_), .Y(new_n123_));
  NOR2x1_ASAP7_75t_R  g065(.A(G33), .B(new_n77_), .Y(new_n124_));
  XNOR2x2_ASAP7_75t_R g066(.A(new_n109_), .B(new_n124_), .Y(new_n125_));
  XOR2x2_ASAP7_75t_R  g067(.A(new_n123_), .B(new_n125_), .Y(new_n126_));
  XNOR2x2_ASAP7_75t_R g068(.A(new_n100_), .B(new_n126_), .Y(new_n127_));
  NAND2x1_ASAP7_75t_R g069(.A(new_n61_), .B(new_n127_), .Y(new_n128_));
  XNOR2x2_ASAP7_75t_R g070(.A(G25), .B(new_n128_), .Y(new_n129_));
  AO21x1_ASAP7_75t_R  g071(.A1(new_n121_), .A2(new_n129_), .B(new_n120_), .Y(new_n130_));
  AO21x1_ASAP7_75t_R  g072(.A1(G24), .A2(new_n79_), .B(G31), .Y(new_n131_));
  NOR2x1_ASAP7_75t_R  g073(.A(G33), .B(G30), .Y(new_n132_));
  OR3x1_ASAP7_75t_R   g074(.A(G33), .B(G30), .C(new_n131_), .Y(new_n133_));
  NAND2x1_ASAP7_75t_R g075(.A(new_n60_), .B(new_n62_), .Y(new_n134_));
  AO21x1_ASAP7_75t_R  g076(.A1(G24), .A2(new_n79_), .B(new_n134_), .Y(new_n135_));
  XNOR2x2_ASAP7_75t_R g077(.A(G8), .B(G6), .Y(new_n136_));
  XNOR2x2_ASAP7_75t_R g078(.A(new_n64_), .B(G12), .Y(new_n137_));
  XNOR2x2_ASAP7_75t_R g079(.A(new_n136_), .B(new_n137_), .Y(new_n138_));
  AND3x1_ASAP7_75t_R  g080(.A(new_n60_), .B(new_n79_), .C(G19), .Y(new_n139_));
  XOR2x2_ASAP7_75t_R  g081(.A(new_n138_), .B(new_n139_), .Y(new_n140_));
  XOR2x2_ASAP7_75t_R  g082(.A(G15), .B(G10), .Y(new_n141_));
  XOR2x2_ASAP7_75t_R  g083(.A(new_n140_), .B(new_n141_), .Y(new_n142_));
  INVx1_ASAP7_75t_R   g084(.A(new_n142_), .Y(new_n143_));
  NOR2x1_ASAP7_75t_R  g085(.A(G31), .B(new_n143_), .Y(new_n144_));
  XNOR2x2_ASAP7_75t_R g086(.A(new_n66_), .B(new_n144_), .Y(new_n145_));
  XNOR2x2_ASAP7_75t_R g087(.A(G15), .B(new_n70_), .Y(new_n146_));
  OR3x1_ASAP7_75t_R   g088(.A(G24), .B(G33), .C(new_n69_), .Y(new_n147_));
  XNOR2x2_ASAP7_75t_R g089(.A(new_n83_), .B(new_n147_), .Y(new_n148_));
  XNOR2x2_ASAP7_75t_R g090(.A(new_n63_), .B(new_n71_), .Y(new_n149_));
  XOR2x2_ASAP7_75t_R  g091(.A(G2), .B(new_n149_), .Y(new_n150_));
  XNOR2x2_ASAP7_75t_R g092(.A(new_n148_), .B(new_n150_), .Y(new_n151_));
  XOR2x2_ASAP7_75t_R  g093(.A(new_n146_), .B(new_n151_), .Y(new_n152_));
  INVx1_ASAP7_75t_R   g094(.A(new_n152_), .Y(new_n153_));
  NOR2x1_ASAP7_75t_R  g095(.A(G31), .B(new_n153_), .Y(new_n154_));
  INVx1_ASAP7_75t_R   g096(.A(new_n154_), .Y(new_n155_));
  AO21x1_ASAP7_75t_R  g097(.A1(G27), .A2(new_n155_), .B(new_n145_), .Y(new_n156_));
  AO21x1_ASAP7_75t_R  g098(.A1(new_n72_), .A2(new_n154_), .B(new_n156_), .Y(new_n157_));
  AO21x1_ASAP7_75t_R  g099(.A1(new_n133_), .A2(new_n135_), .B(new_n157_), .Y(new_n158_));
  NOR2x1_ASAP7_75t_R  g100(.A(new_n130_), .B(new_n158_), .Y(new_n159_));
  INVx1_ASAP7_75t_R   g101(.A(new_n159_), .Y(new_n160_));
  XOR2x2_ASAP7_75t_R  g102(.A(G14), .B(new_n160_), .Y(G1899));
  AO21x1_ASAP7_75t_R  g103(.A1(new_n117_), .A2(new_n119_), .B(new_n105_), .Y(new_n162_));
  AO21x1_ASAP7_75t_R  g104(.A1(new_n121_), .A2(new_n129_), .B(new_n162_), .Y(new_n163_));
  NOR2x1_ASAP7_75t_R  g105(.A(G33), .B(G29), .Y(new_n164_));
  OR3x1_ASAP7_75t_R   g106(.A(G33), .B(G29), .C(new_n131_), .Y(new_n165_));
  AO21x1_ASAP7_75t_R  g107(.A1(new_n135_), .A2(new_n165_), .B(new_n157_), .Y(new_n166_));
  NOR2x1_ASAP7_75t_R  g108(.A(new_n163_), .B(new_n166_), .Y(new_n167_));
  INVx1_ASAP7_75t_R   g109(.A(new_n167_), .Y(new_n168_));
  XOR2x2_ASAP7_75t_R  g110(.A(G1), .B(new_n168_), .Y(G1884));
  XOR2x2_ASAP7_75t_R  g111(.A(G2), .B(new_n168_), .Y(G1885));
  XOR2x2_ASAP7_75t_R  g112(.A(G13), .B(new_n160_), .Y(G1898));
  XOR2x2_ASAP7_75t_R  g113(.A(new_n64_), .B(new_n167_), .Y(G1886));
  XOR2x2_ASAP7_75t_R  g114(.A(new_n73_), .B(new_n167_), .Y(G1887));
  NOR2x1_ASAP7_75t_R  g115(.A(new_n158_), .B(new_n163_), .Y(new_n174_));
  XOR2x2_ASAP7_75t_R  g116(.A(new_n65_), .B(new_n174_), .Y(G1888));
  XNOR2x2_ASAP7_75t_R g117(.A(G15), .B(new_n174_), .Y(G1889));
  XOR2x2_ASAP7_75t_R  g118(.A(new_n68_), .B(new_n174_), .Y(G1890));
  OR3x1_ASAP7_75t_R   g119(.A(new_n122_), .B(new_n129_), .C(new_n162_), .Y(new_n178_));
  NOR2x1_ASAP7_75t_R  g120(.A(new_n166_), .B(new_n178_), .Y(new_n179_));
  INVx1_ASAP7_75t_R   g121(.A(new_n179_), .Y(new_n180_));
  XOR2x2_ASAP7_75t_R  g122(.A(new_n71_), .B(new_n179_), .Y(G1891));
  XOR2x2_ASAP7_75t_R  g123(.A(G6), .B(new_n180_), .Y(G1892));
  XOR2x2_ASAP7_75t_R  g124(.A(G7), .B(new_n180_), .Y(G1893));
  XOR2x2_ASAP7_75t_R  g125(.A(new_n63_), .B(new_n179_), .Y(G1894));
  OR2x4_ASAP7_75t_R   g126(.A(new_n158_), .B(new_n178_), .Y(new_n185_));
  XNOR2x2_ASAP7_75t_R g127(.A(new_n67_), .B(new_n185_), .Y(G1895));
  XOR2x2_ASAP7_75t_R  g128(.A(new_n70_), .B(new_n159_), .Y(G1896));
  XOR2x2_ASAP7_75t_R  g129(.A(G12), .B(new_n160_), .Y(G1897));
  OR3x1_ASAP7_75t_R   g130(.A(new_n119_), .B(new_n121_), .C(new_n117_), .Y(new_n189_));
  OR3x1_ASAP7_75t_R   g131(.A(new_n90_), .B(new_n104_), .C(new_n157_), .Y(new_n190_));
  OR3x1_ASAP7_75t_R   g132(.A(new_n129_), .B(new_n189_), .C(new_n190_), .Y(new_n191_));
  INVx1_ASAP7_75t_R   g133(.A(new_n191_), .Y(new_n192_));
  NOR2x1_ASAP7_75t_R  g134(.A(new_n167_), .B(new_n174_), .Y(new_n193_));
  AND2x2_ASAP7_75t_R  g135(.A(new_n130_), .B(new_n178_), .Y(new_n194_));
  OR3x1_ASAP7_75t_R   g136(.A(new_n135_), .B(new_n157_), .C(new_n194_), .Y(new_n195_));
  AOI21x1_ASAP7_75t_R g137(.A1(new_n193_), .A2(new_n195_), .B(new_n62_), .Y(new_n196_));
  OR3x1_ASAP7_75t_R   g138(.A(G33), .B(new_n192_), .C(new_n196_), .Y(G1900));
  NOR2x1_ASAP7_75t_R  g139(.A(G31), .B(new_n193_), .Y(new_n198_));
  INVx1_ASAP7_75t_R   g140(.A(new_n198_), .Y(new_n199_));
  OR3x1_ASAP7_75t_R   g141(.A(G31), .B(new_n193_), .C(new_n106_), .Y(new_n200_));
  OAI21x1_ASAP7_75t_R g142(.A1(new_n115_), .A2(new_n200_), .B(new_n134_), .Y(new_n201_));
  AOI21x1_ASAP7_75t_R g143(.A1(new_n115_), .A2(new_n200_), .B(new_n201_), .Y(G1901));
  AO21x1_ASAP7_75t_R  g144(.A1(G25), .A2(new_n198_), .B(new_n127_), .Y(new_n203_));
  AND3x1_ASAP7_75t_R  g145(.A(G25), .B(new_n198_), .C(new_n127_), .Y(new_n204_));
  INVx1_ASAP7_75t_R   g146(.A(new_n204_), .Y(new_n205_));
  AND3x1_ASAP7_75t_R  g147(.A(new_n134_), .B(new_n205_), .C(new_n203_), .Y(G1902));
  OR3x1_ASAP7_75t_R   g148(.A(new_n72_), .B(new_n199_), .C(new_n152_), .Y(new_n207_));
  AO21x1_ASAP7_75t_R  g149(.A1(G27), .A2(new_n198_), .B(new_n153_), .Y(new_n208_));
  AND3x1_ASAP7_75t_R  g150(.A(new_n134_), .B(new_n207_), .C(new_n208_), .Y(G1903));
  AO21x1_ASAP7_75t_R  g151(.A1(G28), .A2(new_n198_), .B(new_n143_), .Y(new_n210_));
  OR3x1_ASAP7_75t_R   g152(.A(new_n66_), .B(new_n199_), .C(new_n142_), .Y(new_n211_));
  AND3x1_ASAP7_75t_R  g153(.A(new_n134_), .B(new_n211_), .C(new_n210_), .Y(G1904));
  OR3x1_ASAP7_75t_R   g154(.A(G31), .B(new_n193_), .C(new_n80_), .Y(new_n213_));
  OAI21x1_ASAP7_75t_R g155(.A1(new_n88_), .A2(new_n213_), .B(new_n134_), .Y(new_n214_));
  AOI21x1_ASAP7_75t_R g156(.A1(new_n88_), .A2(new_n213_), .B(new_n214_), .Y(G1905));
  OA21x2_ASAP7_75t_R  g157(.A1(G33), .A2(G29), .B(new_n111_), .Y(new_n216_));
  NAND2x1_ASAP7_75t_R g158(.A(new_n60_), .B(new_n167_), .Y(new_n217_));
  XOR2x2_ASAP7_75t_R  g159(.A(new_n216_), .B(new_n217_), .Y(new_n218_));
  AO21x1_ASAP7_75t_R  g160(.A1(new_n60_), .A2(new_n78_), .B(new_n164_), .Y(new_n219_));
  XNOR2x2_ASAP7_75t_R g161(.A(new_n218_), .B(new_n219_), .Y(G1906));
  NAND2x1_ASAP7_75t_R g162(.A(new_n60_), .B(new_n174_), .Y(new_n221_));
  AOI21x1_ASAP7_75t_R g163(.A1(new_n82_), .A2(new_n101_), .B(new_n132_), .Y(new_n222_));
  OA21x2_ASAP7_75t_R  g164(.A1(new_n82_), .A2(new_n101_), .B(new_n222_), .Y(new_n223_));
  XOR2x2_ASAP7_75t_R  g165(.A(new_n221_), .B(new_n223_), .Y(new_n224_));
  AO21x1_ASAP7_75t_R  g166(.A1(new_n60_), .A2(new_n77_), .B(new_n132_), .Y(new_n225_));
  XNOR2x2_ASAP7_75t_R g167(.A(new_n224_), .B(new_n225_), .Y(G1907));
  OR3x1_ASAP7_75t_R   g168(.A(new_n76_), .B(new_n103_), .C(new_n193_), .Y(new_n227_));
  OAI21x1_ASAP7_75t_R g169(.A1(new_n76_), .A2(new_n199_), .B(new_n102_), .Y(new_n228_));
  AND3x1_ASAP7_75t_R  g170(.A(new_n134_), .B(new_n227_), .C(new_n228_), .Y(G1908));
endmodule


