// Benchmark "/home/flynn/workplace/MIGBalance/results_v2/fixed_all_esyn_20261012/c1908/output_from_egg29/logic" written by ABC on Mon Oct 12 15:04:41 2026

module \/home/flynn/workplace/MIGBalance/results_v2/fixed_all_esyn_20261012/c1908/output_from_egg29/logic  ( 
    G24, G33, G31, G30, G32, G8, G6, G3, G15, G10, G12, G19, G28, G9, G14,
    G16, G18, G11, G5, G2, G27, G7, G4, G20, G13, G1, G17, G26, G22, G25,
    G21, G29, G23,
    G1899, G1884, G1885, G1898, G1886, G1887, G1888, G1889, G1890, G1891,
    G1892, G1893, G1894, G1895, G1896, G1897, G1900, G1901, G1902, G1903,
    G1904, G1905, G1906, G1907, G1908  );
  input  G24, G33, G31, G30, G32, G8, G6, G3, G15, G10, G12, G19, G28,
    G9, G14, G16, G18, G11, G5, G2, G27, G7, G4, G20, G13, G1, G17, G26,
    G22, G25, G21, G29, G23;
  output G1899, G1884, G1885, G1898, G1886, G1887, G1888, G1889, G1890, G1891,
    G1892, G1893, G1894, G1895, G1896, G1897, G1900, G1901, G1902, G1903,
    G1904, G1905, G1906, G1907, G1908;
  wire new_n59_, new_n60_, new_n61_, new_n62_, new_n63_, new_n64_, new_n65_,
    new_n66_, new_n67_, new_n68_, new_n69_, new_n70_, new_n71_, new_n72_,
    new_n73_, new_n74_, new_n75_, new_n76_, new_n77_, new_n78_, new_n79_,
    new_n80_, new_n81_, new_n82_, new_n83_, new_n84_, new_n85_, new_n86_,
    new_n87_, new_n88_, new_n89_, new_n90_, new_n91_, new_n92_, new_n93_,
    new_n94_, new_n95_, new_n96_, new_n97_, new_n98_, new_n99_, new_n100_,
    new_n101_, new_n102_, new_n103_, new_n104_, new_n105_, new_n106_,
    new_n107_, new_n108_, new_n109_, new_n110_, new_n111_, new_n112_,
    new_n113_, new_n114_, new_n115_, new_n116_, new_n117_, new_n118_,
    new_n119_, new_n120_, new_n121_, new_n122_, new_n123_, new_n124_,
    new_n125_, new_n126_, new_n127_, new_n128_, new_n129_, new_n130_,
    new_n131_, new_n132_, new_n133_, new_n134_, new_n135_, new_n136_,
    new_n137_, new_n138_, new_n139_, new_n140_, new_n141_, new_n142_,
    new_n143_, new_n144_, new_n145_, new_n146_, new_n147_, new_n148_,
    new_n149_, new_n150_, new_n151_, new_n152_, new_n153_, new_n154_,
    new_n155_, new_n156_, new_n157_, new_n158_, new_n159_, new_n160_,
    new_n161_, new_n162_, new_n163_, new_n164_, new_n166_, new_n167_,
    new_n168_, new_n169_, new_n170_, new_n171_, new_n177_, new_n178_,
    new_n182_, new_n183_, new_n184_, new_n189_, new_n193_, new_n194_,
    new_n195_, new_n196_, new_n197_, new_n198_, new_n199_, new_n200_,
    new_n202_, new_n203_, new_n204_, new_n205_, new_n207_, new_n208_,
    new_n209_, new_n211_, new_n212_, new_n214_, new_n215_, new_n217_,
    new_n218_, new_n220_, new_n221_, new_n222_, new_n223_, new_n224_,
    new_n226_, new_n227_, new_n228_, new_n229_, new_n230_, new_n232_,
    new_n233_;
  INVx1_ASAP7_75t_R   g000(.A(G24), .Y(new_n59_));
  INVx1_ASAP7_75t_R   g001(.A(G33), .Y(new_n60_));
  INVx1_ASAP7_75t_R   g002(.A(G31), .Y(new_n61_));
  INVx1_ASAP7_75t_R   g003(.A(G32), .Y(new_n62_));
  INVx1_ASAP7_75t_R   g004(.A(G15), .Y(new_n63_));
  INVx1_ASAP7_75t_R   g005(.A(G10), .Y(new_n64_));
  INVx1_ASAP7_75t_R   g006(.A(G28), .Y(new_n65_));
  INVx1_ASAP7_75t_R   g007(.A(G14), .Y(new_n66_));
  INVx1_ASAP7_75t_R   g008(.A(G18), .Y(new_n67_));
  INVx1_ASAP7_75t_R   g009(.A(G5), .Y(new_n68_));
  INVx1_ASAP7_75t_R   g010(.A(G2), .Y(new_n69_));
  INVx1_ASAP7_75t_R   g011(.A(G27), .Y(new_n70_));
  INVx1_ASAP7_75t_R   g012(.A(G7), .Y(new_n71_));
  INVx1_ASAP7_75t_R   g013(.A(G4), .Y(new_n72_));
  INVx1_ASAP7_75t_R   g014(.A(G20), .Y(new_n73_));
  INVx1_ASAP7_75t_R   g015(.A(G13), .Y(new_n74_));
  INVx1_ASAP7_75t_R   g016(.A(G1), .Y(new_n75_));
  INVx1_ASAP7_75t_R   g017(.A(G17), .Y(new_n76_));
  INVx1_ASAP7_75t_R   g018(.A(G26), .Y(new_n77_));
  INVx1_ASAP7_75t_R   g019(.A(G22), .Y(new_n78_));
  INVx1_ASAP7_75t_R   g020(.A(G29), .Y(new_n79_));
  INVx1_ASAP7_75t_R   g021(.A(G23), .Y(new_n80_));
  NAND2x1_ASAP7_75t_R g022(.A(new_n60_), .B(new_n62_), .Y(new_n81_));
  AO21x1_ASAP7_75t_R  g023(.A1(G24), .A2(new_n80_), .B(new_n81_), .Y(new_n82_));
  NOR2x1_ASAP7_75t_R  g024(.A(G33), .B(G30), .Y(new_n83_));
  AO21x1_ASAP7_75t_R  g025(.A1(G24), .A2(new_n80_), .B(G31), .Y(new_n84_));
  OR3x1_ASAP7_75t_R   g026(.A(G33), .B(G30), .C(new_n84_), .Y(new_n85_));
  XOR2x2_ASAP7_75t_R  g027(.A(new_n63_), .B(new_n64_), .Y(new_n86_));
  XOR2x2_ASAP7_75t_R  g028(.A(G3), .B(G12), .Y(new_n87_));
  XNOR2x2_ASAP7_75t_R g029(.A(G8), .B(G6), .Y(new_n88_));
  XNOR2x2_ASAP7_75t_R g030(.A(new_n87_), .B(new_n88_), .Y(new_n89_));
  AND3x1_ASAP7_75t_R  g031(.A(new_n60_), .B(new_n80_), .C(G19), .Y(new_n90_));
  XOR2x2_ASAP7_75t_R  g032(.A(new_n89_), .B(new_n90_), .Y(new_n91_));
  XOR2x2_ASAP7_75t_R  g033(.A(new_n86_), .B(new_n91_), .Y(new_n92_));
  INVx1_ASAP7_75t_R   g034(.A(new_n92_), .Y(new_n93_));
  NOR2x1_ASAP7_75t_R  g035(.A(G31), .B(new_n93_), .Y(new_n94_));
  XNOR2x2_ASAP7_75t_R g036(.A(new_n65_), .B(new_n94_), .Y(new_n95_));
  XOR2x2_ASAP7_75t_R  g037(.A(new_n63_), .B(G11), .Y(new_n96_));
  OR3x1_ASAP7_75t_R   g038(.A(G24), .B(G33), .C(new_n67_), .Y(new_n97_));
  XOR2x2_ASAP7_75t_R  g039(.A(G9), .B(G14), .Y(new_n98_));
  XOR2x2_ASAP7_75t_R  g040(.A(G16), .B(new_n98_), .Y(new_n99_));
  XNOR2x2_ASAP7_75t_R g041(.A(new_n97_), .B(new_n99_), .Y(new_n100_));
  XOR2x2_ASAP7_75t_R  g042(.A(G8), .B(G5), .Y(new_n101_));
  XOR2x2_ASAP7_75t_R  g043(.A(new_n69_), .B(new_n101_), .Y(new_n102_));
  XOR2x2_ASAP7_75t_R  g044(.A(new_n100_), .B(new_n102_), .Y(new_n103_));
  XOR2x2_ASAP7_75t_R  g045(.A(new_n96_), .B(new_n103_), .Y(new_n104_));
  INVx1_ASAP7_75t_R   g046(.A(new_n104_), .Y(new_n105_));
  NOR2x1_ASAP7_75t_R  g047(.A(G31), .B(new_n105_), .Y(new_n106_));
  INVx1_ASAP7_75t_R   g048(.A(new_n106_), .Y(new_n107_));
  AO21x1_ASAP7_75t_R  g049(.A1(G27), .A2(new_n107_), .B(new_n95_), .Y(new_n108_));
  AO21x1_ASAP7_75t_R  g050(.A1(new_n70_), .A2(new_n106_), .B(new_n108_), .Y(new_n109_));
  AO21x1_ASAP7_75t_R  g051(.A1(new_n82_), .A2(new_n85_), .B(new_n109_), .Y(new_n110_));
  XOR2x2_ASAP7_75t_R  g052(.A(new_n63_), .B(G16), .Y(new_n111_));
  XOR2x2_ASAP7_75t_R  g053(.A(G10), .B(new_n111_), .Y(new_n112_));
  XNOR2x2_ASAP7_75t_R g054(.A(G11), .B(new_n112_), .Y(new_n113_));
  XOR2x2_ASAP7_75t_R  g055(.A(G12), .B(new_n74_), .Y(new_n114_));
  XOR2x2_ASAP7_75t_R  g056(.A(new_n113_), .B(new_n114_), .Y(new_n115_));
  INVx1_ASAP7_75t_R   g057(.A(new_n115_), .Y(new_n116_));
  XNOR2x2_ASAP7_75t_R g058(.A(new_n66_), .B(G4), .Y(new_n117_));
  XNOR2x2_ASAP7_75t_R g059(.A(G3), .B(new_n69_), .Y(new_n118_));
  XOR2x2_ASAP7_75t_R  g060(.A(new_n75_), .B(new_n118_), .Y(new_n119_));
  NOR2x1_ASAP7_75t_R  g061(.A(G33), .B(new_n78_), .Y(new_n120_));
  XNOR2x2_ASAP7_75t_R g062(.A(new_n119_), .B(new_n120_), .Y(new_n121_));
  XOR2x2_ASAP7_75t_R  g063(.A(new_n117_), .B(new_n121_), .Y(new_n122_));
  XNOR2x2_ASAP7_75t_R g064(.A(new_n115_), .B(new_n122_), .Y(new_n123_));
  NAND2x1_ASAP7_75t_R g065(.A(new_n61_), .B(new_n123_), .Y(new_n124_));
  XOR2x2_ASAP7_75t_R  g066(.A(G25), .B(new_n124_), .Y(new_n125_));
  INVx1_ASAP7_75t_R   g067(.A(new_n125_), .Y(new_n126_));
  AO21x1_ASAP7_75t_R  g068(.A1(new_n61_), .A2(new_n80_), .B(new_n73_), .Y(new_n127_));
  INVx1_ASAP7_75t_R   g069(.A(new_n127_), .Y(new_n128_));
  XNOR2x2_ASAP7_75t_R g070(.A(G6), .B(new_n71_), .Y(new_n129_));
  XNOR2x2_ASAP7_75t_R g071(.A(new_n68_), .B(new_n129_), .Y(new_n130_));
  XOR2x2_ASAP7_75t_R  g072(.A(new_n119_), .B(new_n130_), .Y(new_n131_));
  XOR2x2_ASAP7_75t_R  g073(.A(G8), .B(new_n72_), .Y(new_n132_));
  XNOR2x2_ASAP7_75t_R g074(.A(new_n131_), .B(new_n132_), .Y(new_n133_));
  NAND2x1_ASAP7_75t_R g075(.A(new_n60_), .B(G21), .Y(new_n134_));
  XNOR2x2_ASAP7_75t_R g076(.A(G9), .B(new_n134_), .Y(new_n135_));
  XNOR2x2_ASAP7_75t_R g077(.A(new_n112_), .B(new_n135_), .Y(new_n136_));
  XNOR2x2_ASAP7_75t_R g078(.A(new_n133_), .B(new_n136_), .Y(new_n137_));
  NOR2x1_ASAP7_75t_R  g079(.A(G31), .B(new_n137_), .Y(new_n138_));
  AO21x1_ASAP7_75t_R  g080(.A1(new_n59_), .A2(new_n61_), .B(new_n76_), .Y(new_n139_));
  XNOR2x2_ASAP7_75t_R g081(.A(new_n138_), .B(new_n139_), .Y(new_n140_));
  AO21x1_ASAP7_75t_R  g082(.A1(new_n59_), .A2(new_n61_), .B(new_n67_), .Y(new_n141_));
  INVx1_ASAP7_75t_R   g083(.A(new_n141_), .Y(new_n142_));
  OR3x1_ASAP7_75t_R   g084(.A(G24), .B(G33), .C(new_n76_), .Y(new_n143_));
  XOR2x2_ASAP7_75t_R  g085(.A(G1), .B(new_n130_), .Y(new_n144_));
  XNOR2x2_ASAP7_75t_R g086(.A(new_n143_), .B(new_n144_), .Y(new_n145_));
  XOR2x2_ASAP7_75t_R  g087(.A(new_n116_), .B(new_n145_), .Y(new_n146_));
  OR2x4_ASAP7_75t_R   g088(.A(G31), .B(new_n146_), .Y(new_n147_));
  XOR2x2_ASAP7_75t_R  g089(.A(new_n77_), .B(new_n147_), .Y(new_n148_));
  XNOR2x2_ASAP7_75t_R g090(.A(new_n72_), .B(new_n99_), .Y(new_n149_));
  OR3x1_ASAP7_75t_R   g091(.A(G33), .B(G23), .C(new_n73_), .Y(new_n150_));
  XOR2x2_ASAP7_75t_R  g092(.A(G13), .B(new_n150_), .Y(new_n151_));
  XNOR2x2_ASAP7_75t_R g093(.A(new_n149_), .B(new_n151_), .Y(new_n152_));
  XNOR2x2_ASAP7_75t_R g094(.A(new_n64_), .B(G7), .Y(new_n153_));
  XOR2x2_ASAP7_75t_R  g095(.A(new_n152_), .B(new_n153_), .Y(new_n154_));
  INVx1_ASAP7_75t_R   g096(.A(new_n154_), .Y(new_n155_));
  OA21x2_ASAP7_75t_R  g097(.A1(G31), .A2(G23), .B(G19), .Y(new_n156_));
  INVx1_ASAP7_75t_R   g098(.A(new_n156_), .Y(new_n157_));
  AND3x1_ASAP7_75t_R  g099(.A(new_n61_), .B(new_n155_), .C(new_n157_), .Y(new_n158_));
  OA21x2_ASAP7_75t_R  g100(.A1(G31), .A2(new_n154_), .B(new_n156_), .Y(new_n159_));
  OR3x1_ASAP7_75t_R   g101(.A(new_n158_), .B(new_n159_), .C(new_n148_), .Y(new_n160_));
  OR3x1_ASAP7_75t_R   g102(.A(new_n140_), .B(new_n141_), .C(new_n160_), .Y(new_n161_));
  AO21x1_ASAP7_75t_R  g103(.A1(new_n126_), .A2(new_n128_), .B(new_n161_), .Y(new_n162_));
  NOR2x1_ASAP7_75t_R  g104(.A(new_n110_), .B(new_n162_), .Y(new_n163_));
  INVx1_ASAP7_75t_R   g105(.A(new_n163_), .Y(new_n164_));
  XOR2x2_ASAP7_75t_R  g106(.A(new_n66_), .B(new_n163_), .Y(G1899));
  OR3x1_ASAP7_75t_R   g107(.A(G33), .B(G29), .C(new_n84_), .Y(new_n166_));
  AO21x1_ASAP7_75t_R  g108(.A1(new_n82_), .A2(new_n166_), .B(new_n109_), .Y(new_n167_));
  AO21x1_ASAP7_75t_R  g109(.A1(new_n140_), .A2(new_n142_), .B(new_n160_), .Y(new_n168_));
  AO21x1_ASAP7_75t_R  g110(.A1(new_n126_), .A2(new_n128_), .B(new_n168_), .Y(new_n169_));
  NOR2x1_ASAP7_75t_R  g111(.A(new_n167_), .B(new_n169_), .Y(new_n170_));
  INVx1_ASAP7_75t_R   g112(.A(new_n170_), .Y(new_n171_));
  XOR2x2_ASAP7_75t_R  g113(.A(new_n75_), .B(new_n170_), .Y(G1884));
  XOR2x2_ASAP7_75t_R  g114(.A(new_n69_), .B(new_n170_), .Y(G1885));
  XOR2x2_ASAP7_75t_R  g115(.A(new_n74_), .B(new_n163_), .Y(G1898));
  XOR2x2_ASAP7_75t_R  g116(.A(G3), .B(new_n171_), .Y(G1886));
  XOR2x2_ASAP7_75t_R  g117(.A(G4), .B(new_n171_), .Y(G1887));
  NOR2x1_ASAP7_75t_R  g118(.A(new_n110_), .B(new_n169_), .Y(new_n177_));
  INVx1_ASAP7_75t_R   g119(.A(new_n177_), .Y(new_n178_));
  XOR2x2_ASAP7_75t_R  g120(.A(G10), .B(new_n178_), .Y(G1888));
  XOR2x2_ASAP7_75t_R  g121(.A(G15), .B(new_n178_), .Y(G1889));
  XOR2x2_ASAP7_75t_R  g122(.A(G16), .B(new_n178_), .Y(G1890));
  OR3x1_ASAP7_75t_R   g123(.A(new_n126_), .B(new_n127_), .C(new_n168_), .Y(new_n182_));
  NOR2x1_ASAP7_75t_R  g124(.A(new_n167_), .B(new_n182_), .Y(new_n183_));
  INVx1_ASAP7_75t_R   g125(.A(new_n183_), .Y(new_n184_));
  XOR2x2_ASAP7_75t_R  g126(.A(new_n68_), .B(new_n183_), .Y(G1891));
  XOR2x2_ASAP7_75t_R  g127(.A(G6), .B(new_n184_), .Y(G1892));
  XOR2x2_ASAP7_75t_R  g128(.A(new_n71_), .B(new_n183_), .Y(G1893));
  XOR2x2_ASAP7_75t_R  g129(.A(G8), .B(new_n184_), .Y(G1894));
  NOR2x1_ASAP7_75t_R  g130(.A(new_n110_), .B(new_n182_), .Y(new_n189_));
  XNOR2x2_ASAP7_75t_R g131(.A(G9), .B(new_n189_), .Y(G1895));
  XOR2x2_ASAP7_75t_R  g132(.A(G11), .B(new_n164_), .Y(G1896));
  XOR2x2_ASAP7_75t_R  g133(.A(G12), .B(new_n164_), .Y(G1897));
  NOR2x1_ASAP7_75t_R  g134(.A(new_n170_), .B(new_n177_), .Y(new_n193_));
  AND2x2_ASAP7_75t_R  g135(.A(new_n162_), .B(new_n182_), .Y(new_n194_));
  OR3x1_ASAP7_75t_R   g136(.A(new_n82_), .B(new_n109_), .C(new_n194_), .Y(new_n195_));
  AOI21x1_ASAP7_75t_R g137(.A1(new_n193_), .A2(new_n195_), .B(new_n62_), .Y(new_n196_));
  NOR2x1_ASAP7_75t_R  g138(.A(new_n109_), .B(new_n160_), .Y(new_n197_));
  OR3x1_ASAP7_75t_R   g139(.A(new_n128_), .B(new_n142_), .C(new_n140_), .Y(new_n198_));
  INVx1_ASAP7_75t_R   g140(.A(new_n198_), .Y(new_n199_));
  AND3x1_ASAP7_75t_R  g141(.A(new_n125_), .B(new_n199_), .C(new_n197_), .Y(new_n200_));
  OR3x1_ASAP7_75t_R   g142(.A(G33), .B(new_n200_), .C(new_n196_), .Y(G1900));
  NOR2x1_ASAP7_75t_R  g143(.A(G31), .B(new_n193_), .Y(new_n202_));
  INVx1_ASAP7_75t_R   g144(.A(new_n202_), .Y(new_n203_));
  OR3x1_ASAP7_75t_R   g145(.A(G31), .B(new_n193_), .C(new_n139_), .Y(new_n204_));
  OAI21x1_ASAP7_75t_R g146(.A1(new_n137_), .A2(new_n204_), .B(new_n81_), .Y(new_n205_));
  AOI21x1_ASAP7_75t_R g147(.A1(new_n137_), .A2(new_n204_), .B(new_n205_), .Y(G1901));
  AND3x1_ASAP7_75t_R  g148(.A(G25), .B(new_n202_), .C(new_n123_), .Y(new_n207_));
  INVx1_ASAP7_75t_R   g149(.A(new_n207_), .Y(new_n208_));
  AO21x1_ASAP7_75t_R  g150(.A1(G25), .A2(new_n202_), .B(new_n123_), .Y(new_n209_));
  AND3x1_ASAP7_75t_R  g151(.A(new_n81_), .B(new_n208_), .C(new_n209_), .Y(G1902));
  AO21x1_ASAP7_75t_R  g152(.A1(G27), .A2(new_n202_), .B(new_n105_), .Y(new_n211_));
  OR3x1_ASAP7_75t_R   g153(.A(new_n70_), .B(new_n203_), .C(new_n104_), .Y(new_n212_));
  AND3x1_ASAP7_75t_R  g154(.A(new_n81_), .B(new_n212_), .C(new_n211_), .Y(G1903));
  AO21x1_ASAP7_75t_R  g155(.A1(G28), .A2(new_n202_), .B(new_n93_), .Y(new_n214_));
  OR3x1_ASAP7_75t_R   g156(.A(new_n65_), .B(new_n203_), .C(new_n92_), .Y(new_n215_));
  AND3x1_ASAP7_75t_R  g157(.A(new_n81_), .B(new_n215_), .C(new_n214_), .Y(G1904));
  AO21x1_ASAP7_75t_R  g158(.A1(new_n156_), .A2(new_n202_), .B(new_n154_), .Y(new_n217_));
  OR3x1_ASAP7_75t_R   g159(.A(new_n157_), .B(new_n203_), .C(new_n155_), .Y(new_n218_));
  AND3x1_ASAP7_75t_R  g160(.A(new_n81_), .B(new_n218_), .C(new_n217_), .Y(G1905));
  NOR2x1_ASAP7_75t_R  g161(.A(G33), .B(G21), .Y(new_n220_));
  AOI21x1_ASAP7_75t_R g162(.A1(new_n60_), .A2(new_n79_), .B(new_n220_), .Y(new_n221_));
  NOR2x1_ASAP7_75t_R  g163(.A(G33), .B(new_n171_), .Y(new_n222_));
  AO21x1_ASAP7_75t_R  g164(.A1(new_n60_), .A2(new_n79_), .B(new_n133_), .Y(new_n223_));
  XNOR2x2_ASAP7_75t_R g165(.A(new_n222_), .B(new_n223_), .Y(new_n224_));
  XNOR2x2_ASAP7_75t_R g166(.A(new_n221_), .B(new_n224_), .Y(G1906));
  AOI21x1_ASAP7_75t_R g167(.A1(new_n98_), .A2(new_n116_), .B(new_n83_), .Y(new_n226_));
  OA21x2_ASAP7_75t_R  g168(.A1(new_n98_), .A2(new_n116_), .B(new_n226_), .Y(new_n227_));
  NAND2x1_ASAP7_75t_R g169(.A(new_n60_), .B(new_n177_), .Y(new_n228_));
  XNOR2x2_ASAP7_75t_R g170(.A(new_n227_), .B(new_n228_), .Y(new_n229_));
  AOI21x1_ASAP7_75t_R g171(.A1(new_n60_), .A2(new_n78_), .B(new_n83_), .Y(new_n230_));
  XNOR2x2_ASAP7_75t_R g172(.A(new_n229_), .B(new_n230_), .Y(G1907));
  OR3x1_ASAP7_75t_R   g173(.A(new_n77_), .B(new_n147_), .C(new_n193_), .Y(new_n232_));
  OAI21x1_ASAP7_75t_R g174(.A1(new_n77_), .A2(new_n203_), .B(new_n146_), .Y(new_n233_));
  AND3x1_ASAP7_75t_R  g175(.A(new_n81_), .B(new_n232_), .C(new_n233_), .Y(G1908));
endmodule


