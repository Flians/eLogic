// Benchmark "/home/flynn/workplace/MIGBalance/results_v2/fixed_all_esyn_20261012/c1908/output_from_egg25/logic" written by ABC on Mon Oct 12 15:04:39 2026

module \/home/flynn/workplace/MIGBalance/results_v2/fixed_all_esyn_20261012/c1908/output_from_egg25/logic  ( 
    G24, G33, G31, G30, G32, G8, G6, G3, G15, G10, G12, G19, G28, G9, G14,
    G16, G18, G11, G5, G2, G27, G7, G4, G20, G13, G1, G17, G26, G22, G25,
    G21, G29, G23,
    G1899, G1884, G1885, G1898, G1886, G1887, G1888, G1889, G1890, G1891,
    G1892, G1893, G1894, G1895, G1896, G1897, G1900, G1901, G1902, G1903,
    G1904, G1905, G1906, G1907, G1908  );
  input  G24, G33, G31, G30, G32, G8, G6, G3, G15, G10, G12, G19, G28,
    G9, G14, G16, G18, G11, G5, G2, G27, G7, G4, G20, G13, G1, G17, G26,
    G22, G25, G21, G29, G23;
  output G1899, G1884, G1885, G1898, G1886, G1887, G1888, G1889, G1890, G1891,
    G1892, G1893, G1894, G1895, G1896, G1897, G1900, G1901, G1902, G1903,
    G1904, G1905, G1906, G1907, G1908;
  wire new_n59_, new_n60_, new_n61_, new_n62_, new_n63_, new_n64_, new_n65_,
    new_n66_, new_n67_, new_n68_, new_n69_, new_n70_, new_n71_, new_n72_,
    new_n73_, new_n74_, new_n75_, new_n76_, new_n77_, new_n78_, new_n79_,
    new_n80_, new_n81_, new_n82_, new_n83_, new_n84_, new_n85_, new_n86_,
    new_n87_, new_n88_, new_n89_, new_n90_, new_n91_, new_n92_, new_n93_,
    new_n94_, new_n95_, new_n96_, new_n97_, new_n98_, new_n99_, new_n100_,
    new_n101_, new_n102_, new_n103_, new_n104_, new_n105_, new_n106_,
    new_n107_, new_n108_, new_n109_, new_n110_, new_n111_, new_n112_,
    new_n113_, new_n114_, new_n115_, new_n116_, new_n117_, new_n118_,
    new_n119_, new_n120_, new_n121_, new_n122_, new_n123_, new_n124_,
    new_n125_, new_n126_, new_n127_, new_n128_, new_n129_, new_n130_,
    new_n131_, new_n132_, new_n133_, new_n134_, new_n135_, new_n136_,
    new_n137_, new_n138_, new_n139_, new_n140_, new_n141_, new_n142_,
    new_n143_, new_n144_, new_n145_, new_n146_, new_n147_, new_n148_,
    new_n149_, new_n150_, new_n151_, new_n152_, new_n153_, new_n154_,
    new_n156_, new_n157_, new_n158_, new_n159_, new_n160_, new_n161_,
    new_n162_, new_n163_, new_n169_, new_n170_, new_n174_, new_n175_,
    new_n176_, new_n181_, new_n185_, new_n186_, new_n187_, new_n188_,
    new_n189_, new_n190_, new_n191_, new_n192_, new_n194_, new_n195_,
    new_n196_, new_n197_, new_n199_, new_n200_, new_n201_, new_n203_,
    new_n204_, new_n206_, new_n207_, new_n209_, new_n210_, new_n212_,
    new_n213_, new_n214_, new_n215_, new_n217_, new_n218_, new_n219_,
    new_n220_, new_n221_, new_n223_, new_n224_;
  INVx1_ASAP7_75t_R   g000(.A(G24), .Y(new_n59_));
  INVx1_ASAP7_75t_R   g001(.A(G33), .Y(new_n60_));
  INVx1_ASAP7_75t_R   g002(.A(G31), .Y(new_n61_));
  INVx1_ASAP7_75t_R   g003(.A(G32), .Y(new_n62_));
  INVx1_ASAP7_75t_R   g004(.A(G8), .Y(new_n63_));
  INVx1_ASAP7_75t_R   g005(.A(G6), .Y(new_n64_));
  INVx1_ASAP7_75t_R   g006(.A(G15), .Y(new_n65_));
  INVx1_ASAP7_75t_R   g007(.A(G14), .Y(new_n66_));
  INVx1_ASAP7_75t_R   g008(.A(G5), .Y(new_n67_));
  INVx1_ASAP7_75t_R   g009(.A(G2), .Y(new_n68_));
  INVx1_ASAP7_75t_R   g010(.A(G27), .Y(new_n69_));
  INVx1_ASAP7_75t_R   g011(.A(G13), .Y(new_n70_));
  INVx1_ASAP7_75t_R   g012(.A(G17), .Y(new_n71_));
  INVx1_ASAP7_75t_R   g013(.A(G26), .Y(new_n72_));
  INVx1_ASAP7_75t_R   g014(.A(G22), .Y(new_n73_));
  INVx1_ASAP7_75t_R   g015(.A(G23), .Y(new_n74_));
  XOR2x2_ASAP7_75t_R  g016(.A(new_n63_), .B(G4), .Y(new_n75_));
  XNOR2x2_ASAP7_75t_R g017(.A(new_n64_), .B(G7), .Y(new_n76_));
  XNOR2x2_ASAP7_75t_R g018(.A(new_n67_), .B(new_n76_), .Y(new_n77_));
  XOR2x2_ASAP7_75t_R  g019(.A(G3), .B(new_n68_), .Y(new_n78_));
  XOR2x2_ASAP7_75t_R  g020(.A(G1), .B(new_n78_), .Y(new_n79_));
  XOR2x2_ASAP7_75t_R  g021(.A(new_n77_), .B(new_n79_), .Y(new_n80_));
  XNOR2x2_ASAP7_75t_R g022(.A(new_n75_), .B(new_n80_), .Y(new_n81_));
  XOR2x2_ASAP7_75t_R  g023(.A(new_n65_), .B(G16), .Y(new_n82_));
  XOR2x2_ASAP7_75t_R  g024(.A(G10), .B(new_n82_), .Y(new_n83_));
  NAND2x1_ASAP7_75t_R g025(.A(new_n60_), .B(G21), .Y(new_n84_));
  XNOR2x2_ASAP7_75t_R g026(.A(G9), .B(new_n84_), .Y(new_n85_));
  XNOR2x2_ASAP7_75t_R g027(.A(new_n83_), .B(new_n85_), .Y(new_n86_));
  XNOR2x2_ASAP7_75t_R g028(.A(new_n81_), .B(new_n86_), .Y(new_n87_));
  NOR2x1_ASAP7_75t_R  g029(.A(G31), .B(new_n87_), .Y(new_n88_));
  AO21x1_ASAP7_75t_R  g030(.A1(new_n59_), .A2(new_n61_), .B(new_n71_), .Y(new_n89_));
  XNOR2x2_ASAP7_75t_R g031(.A(new_n88_), .B(new_n89_), .Y(new_n90_));
  OA21x2_ASAP7_75t_R  g032(.A1(G24), .A2(G31), .B(G18), .Y(new_n91_));
  INVx1_ASAP7_75t_R   g033(.A(new_n91_), .Y(new_n92_));
  OR3x1_ASAP7_75t_R   g034(.A(G24), .B(G33), .C(new_n71_), .Y(new_n93_));
  XOR2x2_ASAP7_75t_R  g035(.A(G1), .B(new_n77_), .Y(new_n94_));
  XNOR2x2_ASAP7_75t_R g036(.A(new_n93_), .B(new_n94_), .Y(new_n95_));
  XOR2x2_ASAP7_75t_R  g037(.A(G11), .B(new_n83_), .Y(new_n96_));
  XNOR2x2_ASAP7_75t_R g038(.A(G12), .B(new_n70_), .Y(new_n97_));
  XOR2x2_ASAP7_75t_R  g039(.A(new_n96_), .B(new_n97_), .Y(new_n98_));
  INVx1_ASAP7_75t_R   g040(.A(new_n98_), .Y(new_n99_));
  XOR2x2_ASAP7_75t_R  g041(.A(new_n95_), .B(new_n99_), .Y(new_n100_));
  OR2x4_ASAP7_75t_R   g042(.A(G31), .B(new_n100_), .Y(new_n101_));
  XOR2x2_ASAP7_75t_R  g043(.A(new_n72_), .B(new_n101_), .Y(new_n102_));
  XOR2x2_ASAP7_75t_R  g044(.A(G9), .B(G14), .Y(new_n103_));
  XNOR2x2_ASAP7_75t_R g045(.A(G16), .B(new_n103_), .Y(new_n104_));
  XNOR2x2_ASAP7_75t_R g046(.A(G4), .B(new_n104_), .Y(new_n105_));
  AND3x1_ASAP7_75t_R  g047(.A(new_n60_), .B(new_n74_), .C(G20), .Y(new_n106_));
  XOR2x2_ASAP7_75t_R  g048(.A(new_n70_), .B(new_n106_), .Y(new_n107_));
  XNOR2x2_ASAP7_75t_R g049(.A(new_n105_), .B(new_n107_), .Y(new_n108_));
  XOR2x2_ASAP7_75t_R  g050(.A(G10), .B(G7), .Y(new_n109_));
  XNOR2x2_ASAP7_75t_R g051(.A(new_n108_), .B(new_n109_), .Y(new_n110_));
  NAND2x1_ASAP7_75t_R g052(.A(new_n61_), .B(new_n110_), .Y(new_n111_));
  OAI21x1_ASAP7_75t_R g053(.A1(G31), .A2(G23), .B(G19), .Y(new_n112_));
  XOR2x2_ASAP7_75t_R  g054(.A(new_n111_), .B(new_n112_), .Y(new_n113_));
  OR2x4_ASAP7_75t_R   g055(.A(new_n102_), .B(new_n113_), .Y(new_n114_));
  OR3x1_ASAP7_75t_R   g056(.A(new_n90_), .B(new_n92_), .C(new_n114_), .Y(new_n115_));
  OA21x2_ASAP7_75t_R  g057(.A1(G31), .A2(G23), .B(G20), .Y(new_n116_));
  INVx1_ASAP7_75t_R   g058(.A(new_n116_), .Y(new_n117_));
  XNOR2x2_ASAP7_75t_R g059(.A(new_n66_), .B(G4), .Y(new_n118_));
  NOR2x1_ASAP7_75t_R  g060(.A(G33), .B(new_n73_), .Y(new_n119_));
  XNOR2x2_ASAP7_75t_R g061(.A(new_n79_), .B(new_n119_), .Y(new_n120_));
  XOR2x2_ASAP7_75t_R  g062(.A(new_n118_), .B(new_n120_), .Y(new_n121_));
  XNOR2x2_ASAP7_75t_R g063(.A(new_n98_), .B(new_n121_), .Y(new_n122_));
  NAND2x1_ASAP7_75t_R g064(.A(new_n61_), .B(new_n122_), .Y(new_n123_));
  XNOR2x2_ASAP7_75t_R g065(.A(G25), .B(new_n123_), .Y(new_n124_));
  AO21x1_ASAP7_75t_R  g066(.A1(new_n116_), .A2(new_n124_), .B(new_n115_), .Y(new_n125_));
  NAND2x1_ASAP7_75t_R g067(.A(new_n60_), .B(new_n62_), .Y(new_n126_));
  AO21x1_ASAP7_75t_R  g068(.A1(G24), .A2(new_n74_), .B(new_n126_), .Y(new_n127_));
  NOR2x1_ASAP7_75t_R  g069(.A(G33), .B(G30), .Y(new_n128_));
  AO21x1_ASAP7_75t_R  g070(.A1(G24), .A2(new_n74_), .B(G31), .Y(new_n129_));
  OR3x1_ASAP7_75t_R   g071(.A(G33), .B(G30), .C(new_n129_), .Y(new_n130_));
  XNOR2x2_ASAP7_75t_R g072(.A(G15), .B(G10), .Y(new_n131_));
  XNOR2x2_ASAP7_75t_R g073(.A(G8), .B(G6), .Y(new_n132_));
  XOR2x2_ASAP7_75t_R  g074(.A(G3), .B(G12), .Y(new_n133_));
  XNOR2x2_ASAP7_75t_R g075(.A(new_n132_), .B(new_n133_), .Y(new_n134_));
  AND3x1_ASAP7_75t_R  g076(.A(new_n60_), .B(new_n74_), .C(G19), .Y(new_n135_));
  XNOR2x2_ASAP7_75t_R g077(.A(new_n134_), .B(new_n135_), .Y(new_n136_));
  XOR2x2_ASAP7_75t_R  g078(.A(new_n131_), .B(new_n136_), .Y(new_n137_));
  NAND2x1_ASAP7_75t_R g079(.A(new_n61_), .B(new_n137_), .Y(new_n138_));
  XNOR2x2_ASAP7_75t_R g080(.A(G28), .B(new_n138_), .Y(new_n139_));
  XOR2x2_ASAP7_75t_R  g081(.A(new_n65_), .B(G11), .Y(new_n140_));
  XNOR2x2_ASAP7_75t_R g082(.A(new_n63_), .B(new_n67_), .Y(new_n141_));
  XNOR2x2_ASAP7_75t_R g083(.A(G2), .B(new_n141_), .Y(new_n142_));
  AND3x1_ASAP7_75t_R  g084(.A(new_n59_), .B(new_n60_), .C(G18), .Y(new_n143_));
  XOR2x2_ASAP7_75t_R  g085(.A(new_n104_), .B(new_n143_), .Y(new_n144_));
  XOR2x2_ASAP7_75t_R  g086(.A(new_n142_), .B(new_n144_), .Y(new_n145_));
  XOR2x2_ASAP7_75t_R  g087(.A(new_n140_), .B(new_n145_), .Y(new_n146_));
  INVx1_ASAP7_75t_R   g088(.A(new_n146_), .Y(new_n147_));
  NOR2x1_ASAP7_75t_R  g089(.A(G31), .B(new_n147_), .Y(new_n148_));
  INVx1_ASAP7_75t_R   g090(.A(new_n148_), .Y(new_n149_));
  AO21x1_ASAP7_75t_R  g091(.A1(G27), .A2(new_n149_), .B(new_n139_), .Y(new_n150_));
  AO21x1_ASAP7_75t_R  g092(.A1(new_n69_), .A2(new_n148_), .B(new_n150_), .Y(new_n151_));
  AO21x1_ASAP7_75t_R  g093(.A1(new_n127_), .A2(new_n130_), .B(new_n151_), .Y(new_n152_));
  NOR2x1_ASAP7_75t_R  g094(.A(new_n125_), .B(new_n152_), .Y(new_n153_));
  INVx1_ASAP7_75t_R   g095(.A(new_n153_), .Y(new_n154_));
  XOR2x2_ASAP7_75t_R  g096(.A(new_n66_), .B(new_n153_), .Y(G1899));
  NOR2x1_ASAP7_75t_R  g097(.A(G33), .B(G29), .Y(new_n156_));
  INVx1_ASAP7_75t_R   g098(.A(new_n156_), .Y(new_n157_));
  OR3x1_ASAP7_75t_R   g099(.A(G33), .B(G29), .C(new_n129_), .Y(new_n158_));
  AO21x1_ASAP7_75t_R  g100(.A1(new_n127_), .A2(new_n158_), .B(new_n151_), .Y(new_n159_));
  AO21x1_ASAP7_75t_R  g101(.A1(new_n90_), .A2(new_n91_), .B(new_n114_), .Y(new_n160_));
  AO21x1_ASAP7_75t_R  g102(.A1(new_n116_), .A2(new_n124_), .B(new_n160_), .Y(new_n161_));
  NOR2x1_ASAP7_75t_R  g103(.A(new_n159_), .B(new_n161_), .Y(new_n162_));
  INVx1_ASAP7_75t_R   g104(.A(new_n162_), .Y(new_n163_));
  XOR2x2_ASAP7_75t_R  g105(.A(G1), .B(new_n163_), .Y(G1884));
  XOR2x2_ASAP7_75t_R  g106(.A(new_n68_), .B(new_n162_), .Y(G1885));
  XOR2x2_ASAP7_75t_R  g107(.A(new_n70_), .B(new_n153_), .Y(G1898));
  XOR2x2_ASAP7_75t_R  g108(.A(G3), .B(new_n163_), .Y(G1886));
  XOR2x2_ASAP7_75t_R  g109(.A(G4), .B(new_n163_), .Y(G1887));
  NOR2x1_ASAP7_75t_R  g110(.A(new_n152_), .B(new_n161_), .Y(new_n169_));
  INVx1_ASAP7_75t_R   g111(.A(new_n169_), .Y(new_n170_));
  XOR2x2_ASAP7_75t_R  g112(.A(G10), .B(new_n170_), .Y(G1888));
  XOR2x2_ASAP7_75t_R  g113(.A(G15), .B(new_n170_), .Y(G1889));
  XOR2x2_ASAP7_75t_R  g114(.A(G16), .B(new_n170_), .Y(G1890));
  OR3x1_ASAP7_75t_R   g115(.A(new_n117_), .B(new_n124_), .C(new_n160_), .Y(new_n174_));
  NOR2x1_ASAP7_75t_R  g116(.A(new_n159_), .B(new_n174_), .Y(new_n175_));
  INVx1_ASAP7_75t_R   g117(.A(new_n175_), .Y(new_n176_));
  XOR2x2_ASAP7_75t_R  g118(.A(new_n67_), .B(new_n175_), .Y(G1891));
  XOR2x2_ASAP7_75t_R  g119(.A(new_n64_), .B(new_n175_), .Y(G1892));
  XOR2x2_ASAP7_75t_R  g120(.A(G7), .B(new_n176_), .Y(G1893));
  XOR2x2_ASAP7_75t_R  g121(.A(G8), .B(new_n176_), .Y(G1894));
  NOR2x1_ASAP7_75t_R  g122(.A(new_n152_), .B(new_n174_), .Y(new_n181_));
  XNOR2x2_ASAP7_75t_R g123(.A(G9), .B(new_n181_), .Y(G1895));
  XOR2x2_ASAP7_75t_R  g124(.A(G11), .B(new_n154_), .Y(G1896));
  XOR2x2_ASAP7_75t_R  g125(.A(G12), .B(new_n154_), .Y(G1897));
  NOR2x1_ASAP7_75t_R  g126(.A(new_n162_), .B(new_n169_), .Y(new_n185_));
  AND2x2_ASAP7_75t_R  g127(.A(new_n125_), .B(new_n174_), .Y(new_n186_));
  OR3x1_ASAP7_75t_R   g128(.A(new_n127_), .B(new_n151_), .C(new_n186_), .Y(new_n187_));
  AOI21x1_ASAP7_75t_R g129(.A1(new_n185_), .A2(new_n187_), .B(new_n62_), .Y(new_n188_));
  OR3x1_ASAP7_75t_R   g130(.A(new_n91_), .B(new_n116_), .C(new_n90_), .Y(new_n189_));
  OR3x1_ASAP7_75t_R   g131(.A(new_n102_), .B(new_n113_), .C(new_n151_), .Y(new_n190_));
  OR3x1_ASAP7_75t_R   g132(.A(new_n124_), .B(new_n189_), .C(new_n190_), .Y(new_n191_));
  INVx1_ASAP7_75t_R   g133(.A(new_n191_), .Y(new_n192_));
  OR3x1_ASAP7_75t_R   g134(.A(G33), .B(new_n192_), .C(new_n188_), .Y(G1900));
  NOR2x1_ASAP7_75t_R  g135(.A(G31), .B(new_n185_), .Y(new_n194_));
  INVx1_ASAP7_75t_R   g136(.A(new_n194_), .Y(new_n195_));
  OR3x1_ASAP7_75t_R   g137(.A(G31), .B(new_n185_), .C(new_n89_), .Y(new_n196_));
  OAI21x1_ASAP7_75t_R g138(.A1(new_n87_), .A2(new_n196_), .B(new_n126_), .Y(new_n197_));
  AOI21x1_ASAP7_75t_R g139(.A1(new_n87_), .A2(new_n196_), .B(new_n197_), .Y(G1901));
  AND3x1_ASAP7_75t_R  g140(.A(G25), .B(new_n194_), .C(new_n122_), .Y(new_n199_));
  INVx1_ASAP7_75t_R   g141(.A(new_n199_), .Y(new_n200_));
  AO21x1_ASAP7_75t_R  g142(.A1(G25), .A2(new_n194_), .B(new_n122_), .Y(new_n201_));
  AND3x1_ASAP7_75t_R  g143(.A(new_n126_), .B(new_n200_), .C(new_n201_), .Y(G1902));
  OR3x1_ASAP7_75t_R   g144(.A(new_n69_), .B(new_n195_), .C(new_n146_), .Y(new_n203_));
  AO21x1_ASAP7_75t_R  g145(.A1(G27), .A2(new_n194_), .B(new_n147_), .Y(new_n204_));
  AND3x1_ASAP7_75t_R  g146(.A(new_n126_), .B(new_n203_), .C(new_n204_), .Y(G1903));
  NAND2x1_ASAP7_75t_R g147(.A(G28), .B(new_n194_), .Y(new_n206_));
  OAI21x1_ASAP7_75t_R g148(.A1(new_n137_), .A2(new_n206_), .B(new_n126_), .Y(new_n207_));
  AOI21x1_ASAP7_75t_R g149(.A1(new_n137_), .A2(new_n206_), .B(new_n207_), .Y(G1904));
  OR3x1_ASAP7_75t_R   g150(.A(G31), .B(new_n185_), .C(new_n112_), .Y(new_n209_));
  OAI21x1_ASAP7_75t_R g151(.A1(new_n110_), .A2(new_n209_), .B(new_n126_), .Y(new_n210_));
  AOI21x1_ASAP7_75t_R g152(.A1(new_n110_), .A2(new_n209_), .B(new_n210_), .Y(G1905));
  OR2x4_ASAP7_75t_R   g153(.A(new_n81_), .B(new_n156_), .Y(new_n212_));
  NOR2x1_ASAP7_75t_R  g154(.A(G33), .B(new_n163_), .Y(new_n213_));
  XNOR2x2_ASAP7_75t_R g155(.A(new_n212_), .B(new_n213_), .Y(new_n214_));
  OA21x2_ASAP7_75t_R  g156(.A1(G33), .A2(G21), .B(new_n157_), .Y(new_n215_));
  XNOR2x2_ASAP7_75t_R g157(.A(new_n214_), .B(new_n215_), .Y(G1906));
  AOI21x1_ASAP7_75t_R g158(.A1(new_n99_), .A2(new_n103_), .B(new_n128_), .Y(new_n217_));
  OA21x2_ASAP7_75t_R  g159(.A1(new_n99_), .A2(new_n103_), .B(new_n217_), .Y(new_n218_));
  NAND2x1_ASAP7_75t_R g160(.A(new_n60_), .B(new_n169_), .Y(new_n219_));
  XNOR2x2_ASAP7_75t_R g161(.A(new_n218_), .B(new_n219_), .Y(new_n220_));
  AOI21x1_ASAP7_75t_R g162(.A1(new_n60_), .A2(new_n73_), .B(new_n128_), .Y(new_n221_));
  XNOR2x2_ASAP7_75t_R g163(.A(new_n220_), .B(new_n221_), .Y(G1907));
  OR3x1_ASAP7_75t_R   g164(.A(new_n72_), .B(new_n101_), .C(new_n185_), .Y(new_n223_));
  OAI21x1_ASAP7_75t_R g165(.A1(new_n72_), .A2(new_n195_), .B(new_n100_), .Y(new_n224_));
  AND3x1_ASAP7_75t_R  g166(.A(new_n126_), .B(new_n223_), .C(new_n224_), .Y(G1908));
endmodule


