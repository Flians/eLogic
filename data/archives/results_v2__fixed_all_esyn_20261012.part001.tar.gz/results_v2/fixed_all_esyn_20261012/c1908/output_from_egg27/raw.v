// Benchmark "/home/flynn/workplace/MIGBalance/results_v2/fixed_all_esyn_20261012/c1908/output_from_egg27/logic" written by ABC on Mon Oct 12 15:04:40 2026

module \/home/flynn/workplace/MIGBalance/results_v2/fixed_all_esyn_20261012/c1908/output_from_egg27/logic  ( 
    G24, G33, G31, G30, G32, G8, G6, G3, G15, G10, G12, G19, G28, G9, G14,
    G16, G18, G11, G5, G2, G27, G7, G4, G20, G13, G1, G17, G26, G22, G25,
    G21, G29, G23,
    G1899, G1884, G1885, G1898, G1886, G1887, G1888, G1889, G1890, G1891,
    G1892, G1893, G1894, G1895, G1896, G1897, G1900, G1901, G1902, G1903,
    G1904, G1905, G1906, G1907, G1908  );
  input  G24, G33, G31, G30, G32, G8, G6, G3, G15, G10, G12, G19, G28,
    G9, G14, G16, G18, G11, G5, G2, G27, G7, G4, G20, G13, G1, G17, G26,
    G22, G25, G21, G29, G23;
  output G1899, G1884, G1885, G1898, G1886, G1887, G1888, G1889, G1890, G1891,
    G1892, G1893, G1894, G1895, G1896, G1897, G1900, G1901, G1902, G1903,
    G1904, G1905, G1906, G1907, G1908;
  wire new_n59_, new_n60_, new_n61_, new_n62_, new_n63_, new_n64_, new_n65_,
    new_n66_, new_n67_, new_n68_, new_n69_, new_n70_, new_n71_, new_n72_,
    new_n73_, new_n74_, new_n75_, new_n76_, new_n77_, new_n78_, new_n79_,
    new_n80_, new_n81_, new_n82_, new_n83_, new_n84_, new_n85_, new_n86_,
    new_n87_, new_n88_, new_n89_, new_n90_, new_n91_, new_n92_, new_n93_,
    new_n94_, new_n95_, new_n96_, new_n97_, new_n98_, new_n99_, new_n100_,
    new_n101_, new_n102_, new_n103_, new_n104_, new_n105_, new_n106_,
    new_n107_, new_n108_, new_n109_, new_n110_, new_n111_, new_n112_,
    new_n113_, new_n114_, new_n115_, new_n116_, new_n117_, new_n118_,
    new_n119_, new_n120_, new_n121_, new_n122_, new_n123_, new_n124_,
    new_n125_, new_n126_, new_n127_, new_n128_, new_n129_, new_n130_,
    new_n131_, new_n132_, new_n133_, new_n134_, new_n135_, new_n136_,
    new_n137_, new_n138_, new_n139_, new_n140_, new_n141_, new_n142_,
    new_n143_, new_n144_, new_n145_, new_n146_, new_n147_, new_n148_,
    new_n149_, new_n150_, new_n151_, new_n152_, new_n153_, new_n154_,
    new_n155_, new_n156_, new_n157_, new_n158_, new_n159_, new_n160_,
    new_n161_, new_n162_, new_n163_, new_n164_, new_n165_, new_n166_,
    new_n168_, new_n169_, new_n170_, new_n171_, new_n172_, new_n173_,
    new_n179_, new_n180_, new_n184_, new_n185_, new_n186_, new_n191_,
    new_n195_, new_n196_, new_n197_, new_n198_, new_n199_, new_n200_,
    new_n201_, new_n202_, new_n204_, new_n205_, new_n206_, new_n207_,
    new_n209_, new_n210_, new_n211_, new_n213_, new_n214_, new_n216_,
    new_n217_, new_n219_, new_n220_, new_n222_, new_n223_, new_n224_,
    new_n225_, new_n226_, new_n228_, new_n229_, new_n230_, new_n231_,
    new_n232_, new_n234_, new_n235_;
  INVx1_ASAP7_75t_R   g000(.A(G24), .Y(new_n59_));
  INVx1_ASAP7_75t_R   g001(.A(G33), .Y(new_n60_));
  INVx1_ASAP7_75t_R   g002(.A(G31), .Y(new_n61_));
  INVx1_ASAP7_75t_R   g003(.A(G32), .Y(new_n62_));
  INVx1_ASAP7_75t_R   g004(.A(G8), .Y(new_n63_));
  INVx1_ASAP7_75t_R   g005(.A(G6), .Y(new_n64_));
  INVx1_ASAP7_75t_R   g006(.A(G3), .Y(new_n65_));
  INVx1_ASAP7_75t_R   g007(.A(G15), .Y(new_n66_));
  INVx1_ASAP7_75t_R   g008(.A(G10), .Y(new_n67_));
  INVx1_ASAP7_75t_R   g009(.A(G28), .Y(new_n68_));
  INVx1_ASAP7_75t_R   g010(.A(G18), .Y(new_n69_));
  INVx1_ASAP7_75t_R   g011(.A(G11), .Y(new_n70_));
  INVx1_ASAP7_75t_R   g012(.A(G5), .Y(new_n71_));
  INVx1_ASAP7_75t_R   g013(.A(G2), .Y(new_n72_));
  INVx1_ASAP7_75t_R   g014(.A(G27), .Y(new_n73_));
  INVx1_ASAP7_75t_R   g015(.A(G4), .Y(new_n74_));
  INVx1_ASAP7_75t_R   g016(.A(G20), .Y(new_n75_));
  INVx1_ASAP7_75t_R   g017(.A(G13), .Y(new_n76_));
  INVx1_ASAP7_75t_R   g018(.A(G1), .Y(new_n77_));
  INVx1_ASAP7_75t_R   g019(.A(G17), .Y(new_n78_));
  INVx1_ASAP7_75t_R   g020(.A(G26), .Y(new_n79_));
  INVx1_ASAP7_75t_R   g021(.A(G22), .Y(new_n80_));
  INVx1_ASAP7_75t_R   g022(.A(G29), .Y(new_n81_));
  INVx1_ASAP7_75t_R   g023(.A(G23), .Y(new_n82_));
  XOR2x2_ASAP7_75t_R  g024(.A(new_n66_), .B(new_n67_), .Y(new_n83_));
  XNOR2x2_ASAP7_75t_R g025(.A(new_n65_), .B(G12), .Y(new_n84_));
  XNOR2x2_ASAP7_75t_R g026(.A(G8), .B(G6), .Y(new_n85_));
  XNOR2x2_ASAP7_75t_R g027(.A(new_n84_), .B(new_n85_), .Y(new_n86_));
  AND3x1_ASAP7_75t_R  g028(.A(new_n60_), .B(new_n82_), .C(G19), .Y(new_n87_));
  XOR2x2_ASAP7_75t_R  g029(.A(new_n86_), .B(new_n87_), .Y(new_n88_));
  XOR2x2_ASAP7_75t_R  g030(.A(new_n83_), .B(new_n88_), .Y(new_n89_));
  INVx1_ASAP7_75t_R   g031(.A(new_n89_), .Y(new_n90_));
  NOR2x1_ASAP7_75t_R  g032(.A(G31), .B(new_n90_), .Y(new_n91_));
  XNOR2x2_ASAP7_75t_R g033(.A(new_n68_), .B(new_n91_), .Y(new_n92_));
  XOR2x2_ASAP7_75t_R  g034(.A(new_n66_), .B(G11), .Y(new_n93_));
  XOR2x2_ASAP7_75t_R  g035(.A(new_n63_), .B(new_n71_), .Y(new_n94_));
  XOR2x2_ASAP7_75t_R  g036(.A(new_n72_), .B(new_n94_), .Y(new_n95_));
  OR3x1_ASAP7_75t_R   g037(.A(G24), .B(G33), .C(new_n69_), .Y(new_n96_));
  XOR2x2_ASAP7_75t_R  g038(.A(G9), .B(G14), .Y(new_n97_));
  XOR2x2_ASAP7_75t_R  g039(.A(G16), .B(new_n97_), .Y(new_n98_));
  XNOR2x2_ASAP7_75t_R g040(.A(new_n96_), .B(new_n98_), .Y(new_n99_));
  XOR2x2_ASAP7_75t_R  g041(.A(new_n95_), .B(new_n99_), .Y(new_n100_));
  XOR2x2_ASAP7_75t_R  g042(.A(new_n93_), .B(new_n100_), .Y(new_n101_));
  INVx1_ASAP7_75t_R   g043(.A(new_n101_), .Y(new_n102_));
  NOR2x1_ASAP7_75t_R  g044(.A(G31), .B(new_n102_), .Y(new_n103_));
  INVx1_ASAP7_75t_R   g045(.A(new_n103_), .Y(new_n104_));
  AO21x1_ASAP7_75t_R  g046(.A1(G27), .A2(new_n104_), .B(new_n92_), .Y(new_n105_));
  AO21x1_ASAP7_75t_R  g047(.A1(new_n73_), .A2(new_n103_), .B(new_n105_), .Y(new_n106_));
  NOR2x1_ASAP7_75t_R  g048(.A(G33), .B(G32), .Y(new_n107_));
  INVx1_ASAP7_75t_R   g049(.A(new_n107_), .Y(new_n108_));
  AO21x1_ASAP7_75t_R  g050(.A1(G24), .A2(new_n82_), .B(new_n108_), .Y(new_n109_));
  NOR2x1_ASAP7_75t_R  g051(.A(G33), .B(G30), .Y(new_n110_));
  AO21x1_ASAP7_75t_R  g052(.A1(G24), .A2(new_n82_), .B(G31), .Y(new_n111_));
  OR3x1_ASAP7_75t_R   g053(.A(G33), .B(G30), .C(new_n111_), .Y(new_n112_));
  AO21x1_ASAP7_75t_R  g054(.A1(new_n109_), .A2(new_n112_), .B(new_n106_), .Y(new_n113_));
  XOR2x2_ASAP7_75t_R  g055(.A(new_n66_), .B(G16), .Y(new_n114_));
  XOR2x2_ASAP7_75t_R  g056(.A(G10), .B(new_n114_), .Y(new_n115_));
  NAND2x1_ASAP7_75t_R g057(.A(new_n60_), .B(G21), .Y(new_n116_));
  XOR2x2_ASAP7_75t_R  g058(.A(G9), .B(new_n116_), .Y(new_n117_));
  XOR2x2_ASAP7_75t_R  g059(.A(new_n115_), .B(new_n117_), .Y(new_n118_));
  XNOR2x2_ASAP7_75t_R g060(.A(new_n64_), .B(G7), .Y(new_n119_));
  XNOR2x2_ASAP7_75t_R g061(.A(new_n71_), .B(new_n119_), .Y(new_n120_));
  XNOR2x2_ASAP7_75t_R g062(.A(new_n65_), .B(G2), .Y(new_n121_));
  XOR2x2_ASAP7_75t_R  g063(.A(new_n77_), .B(new_n121_), .Y(new_n122_));
  XNOR2x2_ASAP7_75t_R g064(.A(new_n120_), .B(new_n122_), .Y(new_n123_));
  XNOR2x2_ASAP7_75t_R g065(.A(new_n63_), .B(G4), .Y(new_n124_));
  XNOR2x2_ASAP7_75t_R g066(.A(new_n123_), .B(new_n124_), .Y(new_n125_));
  XOR2x2_ASAP7_75t_R  g067(.A(new_n118_), .B(new_n125_), .Y(new_n126_));
  NAND2x1_ASAP7_75t_R g068(.A(new_n61_), .B(new_n126_), .Y(new_n127_));
  AO21x1_ASAP7_75t_R  g069(.A1(new_n59_), .A2(new_n61_), .B(new_n78_), .Y(new_n128_));
  XOR2x2_ASAP7_75t_R  g070(.A(new_n127_), .B(new_n128_), .Y(new_n129_));
  AO21x1_ASAP7_75t_R  g071(.A1(new_n59_), .A2(new_n61_), .B(new_n69_), .Y(new_n130_));
  INVx1_ASAP7_75t_R   g072(.A(new_n130_), .Y(new_n131_));
  OR3x1_ASAP7_75t_R   g073(.A(G24), .B(G33), .C(new_n78_), .Y(new_n132_));
  XOR2x2_ASAP7_75t_R  g074(.A(G1), .B(new_n120_), .Y(new_n133_));
  XNOR2x2_ASAP7_75t_R g075(.A(new_n132_), .B(new_n133_), .Y(new_n134_));
  XOR2x2_ASAP7_75t_R  g076(.A(new_n70_), .B(new_n115_), .Y(new_n135_));
  XOR2x2_ASAP7_75t_R  g077(.A(G12), .B(new_n76_), .Y(new_n136_));
  XOR2x2_ASAP7_75t_R  g078(.A(new_n135_), .B(new_n136_), .Y(new_n137_));
  INVx1_ASAP7_75t_R   g079(.A(new_n137_), .Y(new_n138_));
  XOR2x2_ASAP7_75t_R  g080(.A(new_n134_), .B(new_n138_), .Y(new_n139_));
  OR2x4_ASAP7_75t_R   g081(.A(G31), .B(new_n139_), .Y(new_n140_));
  XOR2x2_ASAP7_75t_R  g082(.A(new_n79_), .B(new_n140_), .Y(new_n141_));
  XNOR2x2_ASAP7_75t_R g083(.A(new_n74_), .B(new_n98_), .Y(new_n142_));
  OR3x1_ASAP7_75t_R   g084(.A(G33), .B(G23), .C(new_n75_), .Y(new_n143_));
  XOR2x2_ASAP7_75t_R  g085(.A(G13), .B(new_n143_), .Y(new_n144_));
  XNOR2x2_ASAP7_75t_R g086(.A(new_n142_), .B(new_n144_), .Y(new_n145_));
  XNOR2x2_ASAP7_75t_R g087(.A(new_n67_), .B(G7), .Y(new_n146_));
  XOR2x2_ASAP7_75t_R  g088(.A(new_n145_), .B(new_n146_), .Y(new_n147_));
  INVx1_ASAP7_75t_R   g089(.A(new_n147_), .Y(new_n148_));
  OA21x2_ASAP7_75t_R  g090(.A1(G31), .A2(G23), .B(G19), .Y(new_n149_));
  INVx1_ASAP7_75t_R   g091(.A(new_n149_), .Y(new_n150_));
  AND3x1_ASAP7_75t_R  g092(.A(new_n61_), .B(new_n148_), .C(new_n150_), .Y(new_n151_));
  OA21x2_ASAP7_75t_R  g093(.A1(G31), .A2(new_n147_), .B(new_n149_), .Y(new_n152_));
  OR3x1_ASAP7_75t_R   g094(.A(new_n151_), .B(new_n152_), .C(new_n141_), .Y(new_n153_));
  OR3x1_ASAP7_75t_R   g095(.A(new_n129_), .B(new_n130_), .C(new_n153_), .Y(new_n154_));
  AO21x1_ASAP7_75t_R  g096(.A1(new_n61_), .A2(new_n82_), .B(new_n75_), .Y(new_n155_));
  INVx1_ASAP7_75t_R   g097(.A(new_n155_), .Y(new_n156_));
  XNOR2x2_ASAP7_75t_R g098(.A(G14), .B(new_n74_), .Y(new_n157_));
  NOR2x1_ASAP7_75t_R  g099(.A(G33), .B(new_n80_), .Y(new_n158_));
  XNOR2x2_ASAP7_75t_R g100(.A(new_n122_), .B(new_n158_), .Y(new_n159_));
  XOR2x2_ASAP7_75t_R  g101(.A(new_n157_), .B(new_n159_), .Y(new_n160_));
  XNOR2x2_ASAP7_75t_R g102(.A(new_n137_), .B(new_n160_), .Y(new_n161_));
  NAND2x1_ASAP7_75t_R g103(.A(new_n61_), .B(new_n161_), .Y(new_n162_));
  XNOR2x2_ASAP7_75t_R g104(.A(G25), .B(new_n162_), .Y(new_n163_));
  AO21x1_ASAP7_75t_R  g105(.A1(new_n156_), .A2(new_n163_), .B(new_n154_), .Y(new_n164_));
  NOR2x1_ASAP7_75t_R  g106(.A(new_n113_), .B(new_n164_), .Y(new_n165_));
  INVx1_ASAP7_75t_R   g107(.A(new_n165_), .Y(new_n166_));
  XOR2x2_ASAP7_75t_R  g108(.A(G14), .B(new_n166_), .Y(G1899));
  OR3x1_ASAP7_75t_R   g109(.A(G33), .B(G29), .C(new_n111_), .Y(new_n168_));
  AO21x1_ASAP7_75t_R  g110(.A1(new_n109_), .A2(new_n168_), .B(new_n106_), .Y(new_n169_));
  AO21x1_ASAP7_75t_R  g111(.A1(new_n129_), .A2(new_n131_), .B(new_n153_), .Y(new_n170_));
  AO21x1_ASAP7_75t_R  g112(.A1(new_n156_), .A2(new_n163_), .B(new_n170_), .Y(new_n171_));
  NOR2x1_ASAP7_75t_R  g113(.A(new_n169_), .B(new_n171_), .Y(new_n172_));
  INVx1_ASAP7_75t_R   g114(.A(new_n172_), .Y(new_n173_));
  XOR2x2_ASAP7_75t_R  g115(.A(new_n77_), .B(new_n172_), .Y(G1884));
  XOR2x2_ASAP7_75t_R  g116(.A(new_n72_), .B(new_n172_), .Y(G1885));
  XOR2x2_ASAP7_75t_R  g117(.A(new_n76_), .B(new_n165_), .Y(G1898));
  XOR2x2_ASAP7_75t_R  g118(.A(G3), .B(new_n173_), .Y(G1886));
  XOR2x2_ASAP7_75t_R  g119(.A(G4), .B(new_n173_), .Y(G1887));
  NOR2x1_ASAP7_75t_R  g120(.A(new_n113_), .B(new_n171_), .Y(new_n179_));
  INVx1_ASAP7_75t_R   g121(.A(new_n179_), .Y(new_n180_));
  XOR2x2_ASAP7_75t_R  g122(.A(G10), .B(new_n180_), .Y(G1888));
  XOR2x2_ASAP7_75t_R  g123(.A(G15), .B(new_n180_), .Y(G1889));
  XOR2x2_ASAP7_75t_R  g124(.A(G16), .B(new_n180_), .Y(G1890));
  OR3x1_ASAP7_75t_R   g125(.A(new_n155_), .B(new_n163_), .C(new_n170_), .Y(new_n184_));
  NOR2x1_ASAP7_75t_R  g126(.A(new_n169_), .B(new_n184_), .Y(new_n185_));
  INVx1_ASAP7_75t_R   g127(.A(new_n185_), .Y(new_n186_));
  XOR2x2_ASAP7_75t_R  g128(.A(new_n71_), .B(new_n185_), .Y(G1891));
  XOR2x2_ASAP7_75t_R  g129(.A(new_n64_), .B(new_n185_), .Y(G1892));
  XOR2x2_ASAP7_75t_R  g130(.A(G7), .B(new_n186_), .Y(G1893));
  XOR2x2_ASAP7_75t_R  g131(.A(G8), .B(new_n186_), .Y(G1894));
  NOR2x1_ASAP7_75t_R  g132(.A(new_n113_), .B(new_n184_), .Y(new_n191_));
  XNOR2x2_ASAP7_75t_R g133(.A(G9), .B(new_n191_), .Y(G1895));
  XOR2x2_ASAP7_75t_R  g134(.A(new_n70_), .B(new_n165_), .Y(G1896));
  XOR2x2_ASAP7_75t_R  g135(.A(G12), .B(new_n166_), .Y(G1897));
  OR3x1_ASAP7_75t_R   g136(.A(new_n131_), .B(new_n156_), .C(new_n129_), .Y(new_n195_));
  OR2x4_ASAP7_75t_R   g137(.A(new_n106_), .B(new_n153_), .Y(new_n196_));
  OR3x1_ASAP7_75t_R   g138(.A(new_n163_), .B(new_n195_), .C(new_n196_), .Y(new_n197_));
  INVx1_ASAP7_75t_R   g139(.A(new_n197_), .Y(new_n198_));
  NOR2x1_ASAP7_75t_R  g140(.A(new_n172_), .B(new_n179_), .Y(new_n199_));
  AND2x2_ASAP7_75t_R  g141(.A(new_n164_), .B(new_n184_), .Y(new_n200_));
  OR3x1_ASAP7_75t_R   g142(.A(new_n106_), .B(new_n109_), .C(new_n200_), .Y(new_n201_));
  AOI21x1_ASAP7_75t_R g143(.A1(new_n199_), .A2(new_n201_), .B(new_n62_), .Y(new_n202_));
  OR3x1_ASAP7_75t_R   g144(.A(G33), .B(new_n198_), .C(new_n202_), .Y(G1900));
  AO21x1_ASAP7_75t_R  g145(.A1(new_n173_), .A2(new_n180_), .B(G31), .Y(new_n204_));
  INVx1_ASAP7_75t_R   g146(.A(new_n204_), .Y(new_n205_));
  NOR2x1_ASAP7_75t_R  g147(.A(new_n128_), .B(new_n204_), .Y(new_n206_));
  AOI21x1_ASAP7_75t_R g148(.A1(new_n126_), .A2(new_n206_), .B(new_n107_), .Y(new_n207_));
  OA21x2_ASAP7_75t_R  g149(.A1(new_n126_), .A2(new_n206_), .B(new_n207_), .Y(G1901));
  AND3x1_ASAP7_75t_R  g150(.A(G25), .B(new_n205_), .C(new_n161_), .Y(new_n209_));
  INVx1_ASAP7_75t_R   g151(.A(new_n209_), .Y(new_n210_));
  AO21x1_ASAP7_75t_R  g152(.A1(G25), .A2(new_n205_), .B(new_n161_), .Y(new_n211_));
  AND3x1_ASAP7_75t_R  g153(.A(new_n108_), .B(new_n210_), .C(new_n211_), .Y(G1902));
  OR3x1_ASAP7_75t_R   g154(.A(new_n73_), .B(new_n204_), .C(new_n101_), .Y(new_n213_));
  AO21x1_ASAP7_75t_R  g155(.A1(G27), .A2(new_n205_), .B(new_n102_), .Y(new_n214_));
  AND3x1_ASAP7_75t_R  g156(.A(new_n108_), .B(new_n213_), .C(new_n214_), .Y(G1903));
  AO21x1_ASAP7_75t_R  g157(.A1(G28), .A2(new_n205_), .B(new_n90_), .Y(new_n216_));
  OR3x1_ASAP7_75t_R   g158(.A(new_n68_), .B(new_n204_), .C(new_n89_), .Y(new_n217_));
  AND3x1_ASAP7_75t_R  g159(.A(new_n108_), .B(new_n217_), .C(new_n216_), .Y(G1904));
  OR3x1_ASAP7_75t_R   g160(.A(new_n150_), .B(new_n204_), .C(new_n148_), .Y(new_n219_));
  AO21x1_ASAP7_75t_R  g161(.A1(new_n149_), .A2(new_n205_), .B(new_n147_), .Y(new_n220_));
  AND3x1_ASAP7_75t_R  g162(.A(new_n108_), .B(new_n219_), .C(new_n220_), .Y(G1905));
  NOR2x1_ASAP7_75t_R  g163(.A(G33), .B(G21), .Y(new_n222_));
  AOI21x1_ASAP7_75t_R g164(.A1(new_n60_), .A2(new_n81_), .B(new_n222_), .Y(new_n223_));
  AOI21x1_ASAP7_75t_R g165(.A1(new_n60_), .A2(new_n81_), .B(new_n125_), .Y(new_n224_));
  NAND2x1_ASAP7_75t_R g166(.A(new_n60_), .B(new_n172_), .Y(new_n225_));
  XNOR2x2_ASAP7_75t_R g167(.A(new_n224_), .B(new_n225_), .Y(new_n226_));
  XNOR2x2_ASAP7_75t_R g168(.A(new_n223_), .B(new_n226_), .Y(G1906));
  AOI21x1_ASAP7_75t_R g169(.A1(new_n97_), .A2(new_n138_), .B(new_n110_), .Y(new_n228_));
  OA21x2_ASAP7_75t_R  g170(.A1(new_n97_), .A2(new_n138_), .B(new_n228_), .Y(new_n229_));
  NAND2x1_ASAP7_75t_R g171(.A(new_n60_), .B(new_n179_), .Y(new_n230_));
  XNOR2x2_ASAP7_75t_R g172(.A(new_n229_), .B(new_n230_), .Y(new_n231_));
  AOI21x1_ASAP7_75t_R g173(.A1(new_n60_), .A2(new_n80_), .B(new_n110_), .Y(new_n232_));
  XNOR2x2_ASAP7_75t_R g174(.A(new_n231_), .B(new_n232_), .Y(G1907));
  OR3x1_ASAP7_75t_R   g175(.A(new_n79_), .B(new_n140_), .C(new_n199_), .Y(new_n234_));
  OAI21x1_ASAP7_75t_R g176(.A1(new_n79_), .A2(new_n204_), .B(new_n139_), .Y(new_n235_));
  AND3x1_ASAP7_75t_R  g177(.A(new_n108_), .B(new_n234_), .C(new_n235_), .Y(G1908));
endmodule


