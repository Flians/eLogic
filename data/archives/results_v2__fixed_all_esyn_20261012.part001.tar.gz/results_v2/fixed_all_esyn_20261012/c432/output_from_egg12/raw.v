// Benchmark "/home/flynn/workplace/MIGBalance/results_v2/fixed_all_esyn_20261012/c432/output_from_egg12/logic" written by ABC on Mon Oct 12 15:01:21 2026

module \/home/flynn/workplace/MIGBalance/results_v2/fixed_all_esyn_20261012/c432/output_from_egg12/logic  ( 
    G34, G28, G30, G24, G26, G20, G22, G16, G18, G12, G14, G8, G10, G4, G6,
    G1, G2, G35, G31, G27, G23, G19, G15, G11, G7, G3, G36, G33, G29, G25,
    G21, G17, G13, G9, G5, G32,
    G426, G427, G428, G429, G430, G431, G432  );
  input  G34, G28, G30, G24, G26, G20, G22, G16, G18, G12, G14, G8, G10,
    G4, G6, G1, G2, G35, G31, G27, G23, G19, G15, G11, G7, G3, G36, G33,
    G29, G25, G21, G17, G13, G9, G5, G32;
  output G426, G427, G428, G429, G430, G431, G432;
  wire new_n44_, new_n45_, new_n46_, new_n47_, new_n48_, new_n49_, new_n50_,
    new_n51_, new_n52_, new_n53_, new_n54_, new_n55_, new_n56_, new_n57_,
    new_n58_, new_n59_, new_n60_, new_n61_, new_n62_, new_n63_, new_n65_,
    new_n66_, new_n67_, new_n68_, new_n69_, new_n70_, new_n71_, new_n72_,
    new_n73_, new_n74_, new_n75_, new_n76_, new_n77_, new_n78_, new_n79_,
    new_n80_, new_n81_, new_n82_, new_n83_, new_n84_, new_n85_, new_n86_,
    new_n88_, new_n89_, new_n90_, new_n91_, new_n92_, new_n93_, new_n94_,
    new_n95_, new_n96_, new_n97_, new_n98_, new_n99_, new_n100_, new_n101_,
    new_n102_, new_n103_, new_n104_, new_n105_, new_n106_, new_n107_,
    new_n108_, new_n110_, new_n111_, new_n112_, new_n113_, new_n114_,
    new_n115_, new_n116_, new_n118_, new_n119_, new_n120_, new_n121_,
    new_n122_, new_n123_, new_n124_, new_n125_, new_n126_, new_n127_,
    new_n129_, new_n130_, new_n131_, new_n132_, new_n134_, new_n135_,
    new_n136_;
  INVx1_ASAP7_75t_R   g00(.A(G34), .Y(new_n44_));
  INVx1_ASAP7_75t_R   g01(.A(G28), .Y(new_n45_));
  INVx1_ASAP7_75t_R   g02(.A(G26), .Y(new_n46_));
  INVx1_ASAP7_75t_R   g03(.A(G22), .Y(new_n47_));
  INVx1_ASAP7_75t_R   g04(.A(G18), .Y(new_n48_));
  INVx1_ASAP7_75t_R   g05(.A(G12), .Y(new_n49_));
  INVx1_ASAP7_75t_R   g06(.A(G10), .Y(new_n50_));
  INVx1_ASAP7_75t_R   g07(.A(G4), .Y(new_n51_));
  INVx1_ASAP7_75t_R   g08(.A(G2), .Y(new_n52_));
  INVx1_ASAP7_75t_R   g09(.A(G15), .Y(new_n53_));
  NOR2x1_ASAP7_75t_R  g10(.A(G16), .B(new_n48_), .Y(new_n54_));
  NOR2x1_ASAP7_75t_R  g11(.A(G20), .B(new_n47_), .Y(new_n55_));
  AO21x1_ASAP7_75t_R  g12(.A1(new_n49_), .A2(G14), .B(new_n55_), .Y(new_n56_));
  NOR2x1_ASAP7_75t_R  g13(.A(G1), .B(new_n52_), .Y(new_n57_));
  AO21x1_ASAP7_75t_R  g14(.A1(new_n51_), .A2(G6), .B(new_n57_), .Y(new_n58_));
  OR2x4_ASAP7_75t_R   g15(.A(G24), .B(new_n46_), .Y(new_n59_));
  OAI21x1_ASAP7_75t_R g16(.A1(G8), .A2(new_n50_), .B(new_n59_), .Y(new_n60_));
  NOR2x1_ASAP7_75t_R  g17(.A(new_n44_), .B(G32), .Y(new_n61_));
  AO21x1_ASAP7_75t_R  g18(.A1(new_n45_), .A2(G30), .B(new_n61_), .Y(new_n62_));
  OR3x1_ASAP7_75t_R   g19(.A(new_n58_), .B(new_n60_), .C(new_n62_), .Y(new_n63_));
  OR3x1_ASAP7_75t_R   g20(.A(new_n54_), .B(new_n56_), .C(new_n63_), .Y(G426));
  INVx1_ASAP7_75t_R   g21(.A(G426), .Y(new_n65_));
  OAI21x1_ASAP7_75t_R g22(.A1(new_n45_), .A2(new_n65_), .B(G30), .Y(new_n66_));
  NOR2x1_ASAP7_75t_R  g23(.A(G31), .B(new_n66_), .Y(new_n67_));
  INVx1_ASAP7_75t_R   g24(.A(new_n67_), .Y(new_n68_));
  AO21x1_ASAP7_75t_R  g25(.A1(G8), .A2(G426), .B(new_n50_), .Y(new_n69_));
  XOR2x2_ASAP7_75t_R  g26(.A(new_n59_), .B(new_n65_), .Y(new_n70_));
  OR3x1_ASAP7_75t_R   g27(.A(new_n46_), .B(G27), .C(new_n70_), .Y(new_n71_));
  OAI21x1_ASAP7_75t_R g28(.A1(G11), .A2(new_n69_), .B(new_n71_), .Y(new_n72_));
  OA21x2_ASAP7_75t_R  g29(.A1(new_n49_), .A2(new_n65_), .B(G14), .Y(new_n73_));
  INVx1_ASAP7_75t_R   g30(.A(new_n73_), .Y(new_n74_));
  AO21x1_ASAP7_75t_R  g31(.A1(G20), .A2(G426), .B(new_n47_), .Y(new_n75_));
  NOR2x1_ASAP7_75t_R  g32(.A(G23), .B(new_n75_), .Y(new_n76_));
  AO21x1_ASAP7_75t_R  g33(.A1(new_n53_), .A2(new_n73_), .B(new_n76_), .Y(new_n77_));
  AO21x1_ASAP7_75t_R  g34(.A1(G32), .A2(G426), .B(new_n44_), .Y(new_n78_));
  OAI21x1_ASAP7_75t_R g35(.A1(new_n51_), .A2(new_n65_), .B(G6), .Y(new_n79_));
  OR2x4_ASAP7_75t_R   g36(.A(G7), .B(new_n79_), .Y(new_n80_));
  OAI21x1_ASAP7_75t_R g37(.A1(G35), .A2(new_n78_), .B(new_n80_), .Y(new_n81_));
  AO21x1_ASAP7_75t_R  g38(.A1(G16), .A2(G426), .B(new_n48_), .Y(new_n82_));
  AO21x1_ASAP7_75t_R  g39(.A1(G1), .A2(G426), .B(new_n52_), .Y(new_n83_));
  OR2x4_ASAP7_75t_R   g40(.A(G3), .B(new_n83_), .Y(new_n84_));
  OAI21x1_ASAP7_75t_R g41(.A1(G19), .A2(new_n82_), .B(new_n84_), .Y(new_n85_));
  OR3x1_ASAP7_75t_R   g42(.A(new_n81_), .B(new_n85_), .C(new_n77_), .Y(new_n86_));
  OR3x1_ASAP7_75t_R   g43(.A(new_n67_), .B(new_n72_), .C(new_n86_), .Y(G427));
  OR3x1_ASAP7_75t_R   g44(.A(new_n46_), .B(G29), .C(new_n70_), .Y(new_n88_));
  AOI21x1_ASAP7_75t_R g45(.A1(new_n71_), .A2(G427), .B(new_n88_), .Y(new_n89_));
  OAI21x1_ASAP7_75t_R g46(.A1(new_n71_), .A2(G427), .B(new_n89_), .Y(new_n90_));
  AO21x1_ASAP7_75t_R  g47(.A1(G11), .A2(G427), .B(new_n69_), .Y(new_n91_));
  OAI21x1_ASAP7_75t_R g48(.A1(G13), .A2(new_n91_), .B(new_n90_), .Y(new_n92_));
  AO21x1_ASAP7_75t_R  g49(.A1(G31), .A2(G427), .B(new_n66_), .Y(new_n93_));
  NOR2x1_ASAP7_75t_R  g50(.A(new_n68_), .B(G427), .Y(new_n94_));
  OR3x1_ASAP7_75t_R   g51(.A(G33), .B(new_n94_), .C(new_n93_), .Y(new_n95_));
  AO21x1_ASAP7_75t_R  g52(.A1(G35), .A2(G427), .B(new_n78_), .Y(new_n96_));
  OAI21x1_ASAP7_75t_R g53(.A1(G36), .A2(new_n96_), .B(new_n95_), .Y(new_n97_));
  AO21x1_ASAP7_75t_R  g54(.A1(G3), .A2(G427), .B(new_n83_), .Y(new_n98_));
  AO21x1_ASAP7_75t_R  g55(.A1(G7), .A2(G427), .B(new_n79_), .Y(new_n99_));
  OR2x4_ASAP7_75t_R   g56(.A(G9), .B(new_n99_), .Y(new_n100_));
  OAI21x1_ASAP7_75t_R g57(.A1(G5), .A2(new_n98_), .B(new_n100_), .Y(new_n101_));
  OR3x1_ASAP7_75t_R   g58(.A(new_n92_), .B(new_n97_), .C(new_n101_), .Y(new_n102_));
  AO21x1_ASAP7_75t_R  g59(.A1(G19), .A2(G427), .B(new_n82_), .Y(new_n103_));
  NOR2x1_ASAP7_75t_R  g60(.A(G21), .B(new_n103_), .Y(new_n104_));
  AO21x1_ASAP7_75t_R  g61(.A1(G15), .A2(G427), .B(new_n74_), .Y(new_n105_));
  AO21x1_ASAP7_75t_R  g62(.A1(G23), .A2(G427), .B(new_n75_), .Y(new_n106_));
  OR2x4_ASAP7_75t_R   g63(.A(G25), .B(new_n106_), .Y(new_n107_));
  OAI21x1_ASAP7_75t_R g64(.A1(G17), .A2(new_n105_), .B(new_n107_), .Y(new_n108_));
  OR3x1_ASAP7_75t_R   g65(.A(new_n104_), .B(new_n108_), .C(new_n102_), .Y(G428));
  AO21x1_ASAP7_75t_R  g66(.A1(G13), .A2(G428), .B(new_n91_), .Y(new_n110_));
  INVx1_ASAP7_75t_R   g67(.A(new_n110_), .Y(new_n111_));
  AOI21x1_ASAP7_75t_R g68(.A1(G9), .A2(G428), .B(new_n99_), .Y(new_n112_));
  AOI21x1_ASAP7_75t_R g69(.A1(G17), .A2(G428), .B(new_n105_), .Y(new_n113_));
  AOI21x1_ASAP7_75t_R g70(.A1(G21), .A2(G428), .B(new_n103_), .Y(new_n114_));
  NOR2x1_ASAP7_75t_R  g71(.A(new_n113_), .B(new_n114_), .Y(new_n115_));
  INVx1_ASAP7_75t_R   g72(.A(new_n115_), .Y(new_n116_));
  OR3x1_ASAP7_75t_R   g73(.A(new_n111_), .B(new_n112_), .C(new_n116_), .Y(G430));
  INVx1_ASAP7_75t_R   g74(.A(G430), .Y(new_n118_));
  AOI21x1_ASAP7_75t_R g75(.A1(G36), .A2(G428), .B(new_n96_), .Y(new_n119_));
  AO21x1_ASAP7_75t_R  g76(.A1(G24), .A2(G426), .B(new_n46_), .Y(new_n120_));
  AO21x1_ASAP7_75t_R  g77(.A1(G27), .A2(G427), .B(new_n120_), .Y(new_n121_));
  AOI21x1_ASAP7_75t_R g78(.A1(G29), .A2(G428), .B(new_n121_), .Y(new_n122_));
  NOR2x1_ASAP7_75t_R  g79(.A(new_n119_), .B(new_n122_), .Y(new_n123_));
  AO21x1_ASAP7_75t_R  g80(.A1(G25), .A2(G428), .B(new_n106_), .Y(new_n124_));
  AO21x1_ASAP7_75t_R  g81(.A1(G33), .A2(G428), .B(new_n93_), .Y(new_n125_));
  AND3x1_ASAP7_75t_R  g82(.A(new_n124_), .B(new_n125_), .C(new_n123_), .Y(new_n126_));
  AOI21x1_ASAP7_75t_R g83(.A1(G5), .A2(G428), .B(new_n98_), .Y(new_n127_));
  AOI21x1_ASAP7_75t_R g84(.A1(new_n118_), .A2(new_n126_), .B(new_n127_), .Y(G429));
  OR2x4_ASAP7_75t_R   g85(.A(new_n111_), .B(new_n113_), .Y(new_n129_));
  OR3x1_ASAP7_75t_R   g86(.A(new_n114_), .B(new_n124_), .C(new_n129_), .Y(new_n130_));
  INVx1_ASAP7_75t_R   g87(.A(new_n130_), .Y(new_n131_));
  OR3x1_ASAP7_75t_R   g88(.A(new_n111_), .B(new_n112_), .C(new_n131_), .Y(new_n132_));
  AO21x1_ASAP7_75t_R  g89(.A1(new_n115_), .A2(new_n122_), .B(new_n132_), .Y(G431));
  OR3x1_ASAP7_75t_R   g90(.A(new_n122_), .B(new_n125_), .C(new_n129_), .Y(new_n134_));
  INVx1_ASAP7_75t_R   g91(.A(new_n134_), .Y(new_n135_));
  AO21x1_ASAP7_75t_R  g92(.A1(new_n110_), .A2(new_n113_), .B(new_n112_), .Y(new_n136_));
  OR3x1_ASAP7_75t_R   g93(.A(new_n131_), .B(new_n136_), .C(new_n135_), .Y(G432));
endmodule


