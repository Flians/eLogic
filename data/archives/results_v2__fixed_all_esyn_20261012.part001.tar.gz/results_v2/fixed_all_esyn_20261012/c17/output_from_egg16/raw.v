// Benchmark "/home/flynn/workplace/MIGBalance/results_v2/fixed_all_esyn_20261012/c17/output_from_egg16/logic" written by ABC on Mon Oct 12 15:01:01 2026

module \/home/flynn/workplace/MIGBalance/results_v2/fixed_all_esyn_20261012/c17/output_from_egg16/logic  ( 
    G3, G2, G4, G5, G1,
    G16, G17  );
  input  G3, G2, G4, G5, G1;
  output G16, G17;
  wire new_n8_, new_n9_;
  NAND2x1_ASAP7_75t_R g0(.A(G3), .B(G4), .Y(new_n8_));
  AND2x2_ASAP7_75t_R  g1(.A(G2), .B(new_n8_), .Y(new_n9_));
  AO21x1_ASAP7_75t_R  g2(.A1(G3), .A2(G1), .B(new_n9_), .Y(G16));
  AO21x1_ASAP7_75t_R  g3(.A1(G5), .A2(new_n8_), .B(new_n9_), .Y(G17));
endmodule


