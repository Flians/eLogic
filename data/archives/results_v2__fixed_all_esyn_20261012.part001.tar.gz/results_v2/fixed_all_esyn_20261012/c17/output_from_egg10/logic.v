module mapped(G3,G2,G4,G5,G1,G16,G17);
input G3,G2,G4,G5,G1;
output G16,G17;
wire __esyn_n10,__esyn_n11,__esyn_n12,__esyn_n13,__esyn_n14,__esyn_n15,__esyn_n16,__esyn_n17,__esyn_n18,__esyn_n6,__esyn_n7,__esyn_n9;
assign __esyn_n10 = (G5 & __esyn_n9);
assign __esyn_n11 = (~__esyn_n10);
assign __esyn_n12 = (~__esyn_n16);
assign __esyn_n13 = (__esyn_n12 & __esyn_n11);
assign __esyn_n14 = (G3 & G1);
assign __esyn_n15 = (G3 & G4);
assign __esyn_n16 = (G2 & __esyn_n9);
assign __esyn_n17 = (~__esyn_n14);
assign __esyn_n18 = (__esyn_n12 & __esyn_n17);
assign __esyn_n6 = (~__esyn_n18);
assign __esyn_n7 = (~__esyn_n13);
assign __esyn_n9 = (~__esyn_n15);
assign G16 = __esyn_n6;
assign G17 = __esyn_n7;
endmodule
