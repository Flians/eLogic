// Benchmark "/home/flynn/workplace/MIGBalance/results_v2/fixed_all_esyn_20261012/c1355/output_from_egg19/logic" written by ABC on Mon Oct 12 15:03:52 2026

module \/home/flynn/workplace/MIGBalance/results_v2/fixed_all_esyn_20261012/c1355/output_from_egg19/logic  ( 
    G5, G9, G13, G33, G41, G17, G18, G19, G20, G21, G22, G23, G24, G4, G8,
    G12, G16, G36, G29, G30, G31, G32, G3, G7, G11, G15, G35, G25, G26,
    G27, G28, G2, G6, G10, G14, G34, G40, G39, G38, G37, G1,
    G1324, G1344, G1325, G1326, G1327, G1328, G1329, G1330, G1343, G1331,
    G1332, G1333, G1334, G1335, G1336, G1337, G1338, G1339, G1340, G1341,
    G1342, G1345, G1346, G1347, G1348, G1349, G1350, G1351, G1352, G1353,
    G1354, G1355  );
  input  G5, G9, G13, G33, G41, G17, G18, G19, G20, G21, G22, G23, G24,
    G4, G8, G12, G16, G36, G29, G30, G31, G32, G3, G7, G11, G15, G35, G25,
    G26, G27, G28, G2, G6, G10, G14, G34, G40, G39, G38, G37, G1;
  output G1324, G1344, G1325, G1326, G1327, G1328, G1329, G1330, G1343, G1331,
    G1332, G1333, G1334, G1335, G1336, G1337, G1338, G1339, G1340, G1341,
    G1342, G1345, G1346, G1347, G1348, G1349, G1350, G1351, G1352, G1353,
    G1354, G1355;
  wire new_n74_, new_n75_, new_n76_, new_n77_, new_n78_, new_n79_, new_n80_,
    new_n81_, new_n82_, new_n83_, new_n84_, new_n85_, new_n86_, new_n87_,
    new_n88_, new_n89_, new_n90_, new_n91_, new_n92_, new_n93_, new_n94_,
    new_n95_, new_n96_, new_n97_, new_n98_, new_n99_, new_n100_, new_n101_,
    new_n102_, new_n103_, new_n104_, new_n105_, new_n106_, new_n107_,
    new_n108_, new_n109_, new_n110_, new_n111_, new_n112_, new_n113_,
    new_n114_, new_n115_, new_n116_, new_n117_, new_n118_, new_n119_,
    new_n120_, new_n121_, new_n122_, new_n123_, new_n124_, new_n125_,
    new_n126_, new_n127_, new_n128_, new_n129_, new_n130_, new_n131_,
    new_n132_, new_n133_, new_n134_, new_n135_, new_n136_, new_n137_,
    new_n138_, new_n139_, new_n140_, new_n141_, new_n142_, new_n143_,
    new_n144_, new_n145_, new_n146_, new_n147_, new_n148_, new_n149_,
    new_n150_, new_n151_, new_n152_, new_n153_, new_n154_, new_n155_,
    new_n156_, new_n157_, new_n158_, new_n159_, new_n160_, new_n161_,
    new_n162_, new_n163_, new_n164_, new_n165_, new_n166_, new_n167_,
    new_n168_, new_n169_, new_n170_, new_n171_, new_n172_, new_n173_,
    new_n174_, new_n175_, new_n176_, new_n177_, new_n178_, new_n179_,
    new_n180_, new_n181_, new_n182_, new_n183_, new_n184_, new_n186_,
    new_n187_, new_n188_, new_n189_, new_n190_, new_n191_, new_n192_,
    new_n193_, new_n194_, new_n196_, new_n198_, new_n200_, new_n202_,
    new_n203_, new_n204_, new_n206_, new_n208_, new_n210_, new_n211_,
    new_n212_, new_n214_, new_n216_, new_n217_, new_n219_, new_n221_,
    new_n223_, new_n225_, new_n226_, new_n228_, new_n230_, new_n232_,
    new_n234_, new_n236_, new_n238_, new_n240_, new_n242_, new_n244_,
    new_n246_, new_n247_, new_n249_, new_n251_, new_n253_, new_n255_,
    new_n256_, new_n258_, new_n260_, new_n262_;
  INVx1_ASAP7_75t_R   g000(.A(G9), .Y(new_n74_));
  INVx1_ASAP7_75t_R   g001(.A(G13), .Y(new_n75_));
  INVx1_ASAP7_75t_R   g002(.A(G17), .Y(new_n76_));
  INVx1_ASAP7_75t_R   g003(.A(G22), .Y(new_n77_));
  INVx1_ASAP7_75t_R   g004(.A(G4), .Y(new_n78_));
  INVx1_ASAP7_75t_R   g005(.A(G29), .Y(new_n79_));
  INVx1_ASAP7_75t_R   g006(.A(G31), .Y(new_n80_));
  INVx1_ASAP7_75t_R   g007(.A(G32), .Y(new_n81_));
  INVx1_ASAP7_75t_R   g008(.A(G3), .Y(new_n82_));
  INVx1_ASAP7_75t_R   g009(.A(G7), .Y(new_n83_));
  INVx1_ASAP7_75t_R   g010(.A(G26), .Y(new_n84_));
  INVx1_ASAP7_75t_R   g011(.A(G28), .Y(new_n85_));
  INVx1_ASAP7_75t_R   g012(.A(G6), .Y(new_n86_));
  INVx1_ASAP7_75t_R   g013(.A(G1), .Y(new_n87_));
  XOR2x2_ASAP7_75t_R  g014(.A(G21), .B(new_n77_), .Y(new_n88_));
  XOR2x2_ASAP7_75t_R  g015(.A(G23), .B(G24), .Y(new_n89_));
  XOR2x2_ASAP7_75t_R  g016(.A(new_n88_), .B(new_n89_), .Y(new_n90_));
  XOR2x2_ASAP7_75t_R  g017(.A(G9), .B(G13), .Y(new_n91_));
  XNOR2x2_ASAP7_75t_R g018(.A(G5), .B(new_n87_), .Y(new_n92_));
  XNOR2x2_ASAP7_75t_R g019(.A(new_n91_), .B(new_n92_), .Y(new_n93_));
  XOR2x2_ASAP7_75t_R  g020(.A(new_n90_), .B(new_n93_), .Y(new_n94_));
  XOR2x2_ASAP7_75t_R  g021(.A(G19), .B(G20), .Y(new_n95_));
  XOR2x2_ASAP7_75t_R  g022(.A(new_n76_), .B(G18), .Y(new_n96_));
  XNOR2x2_ASAP7_75t_R g023(.A(new_n95_), .B(new_n96_), .Y(new_n97_));
  NAND2x1_ASAP7_75t_R g024(.A(G33), .B(G41), .Y(new_n98_));
  XOR2x2_ASAP7_75t_R  g025(.A(new_n97_), .B(new_n98_), .Y(new_n99_));
  XOR2x2_ASAP7_75t_R  g026(.A(new_n94_), .B(new_n99_), .Y(new_n100_));
  NAND2x1_ASAP7_75t_R g027(.A(G41), .B(G39), .Y(new_n101_));
  XOR2x2_ASAP7_75t_R  g028(.A(new_n78_), .B(new_n82_), .Y(new_n102_));
  XOR2x2_ASAP7_75t_R  g029(.A(G2), .B(new_n87_), .Y(new_n103_));
  XOR2x2_ASAP7_75t_R  g030(.A(new_n102_), .B(new_n103_), .Y(new_n104_));
  XOR2x2_ASAP7_75t_R  g031(.A(new_n101_), .B(new_n104_), .Y(new_n105_));
  XOR2x2_ASAP7_75t_R  g032(.A(G12), .B(G11), .Y(new_n106_));
  XOR2x2_ASAP7_75t_R  g033(.A(new_n74_), .B(G10), .Y(new_n107_));
  XOR2x2_ASAP7_75t_R  g034(.A(new_n106_), .B(new_n107_), .Y(new_n108_));
  XOR2x2_ASAP7_75t_R  g035(.A(G19), .B(G23), .Y(new_n109_));
  XOR2x2_ASAP7_75t_R  g036(.A(G31), .B(G27), .Y(new_n110_));
  XNOR2x2_ASAP7_75t_R g037(.A(new_n109_), .B(new_n110_), .Y(new_n111_));
  XNOR2x2_ASAP7_75t_R g038(.A(new_n108_), .B(new_n111_), .Y(new_n112_));
  XOR2x2_ASAP7_75t_R  g039(.A(new_n105_), .B(new_n112_), .Y(new_n113_));
  INVx1_ASAP7_75t_R   g040(.A(new_n113_), .Y(new_n114_));
  NAND2x1_ASAP7_75t_R g041(.A(G41), .B(G37), .Y(new_n115_));
  XOR2x2_ASAP7_75t_R  g042(.A(G8), .B(G7), .Y(new_n116_));
  XOR2x2_ASAP7_75t_R  g043(.A(G5), .B(new_n86_), .Y(new_n117_));
  XNOR2x2_ASAP7_75t_R g044(.A(new_n116_), .B(new_n117_), .Y(new_n118_));
  XOR2x2_ASAP7_75t_R  g045(.A(new_n115_), .B(new_n118_), .Y(new_n119_));
  XNOR2x2_ASAP7_75t_R g046(.A(G29), .B(G25), .Y(new_n120_));
  XOR2x2_ASAP7_75t_R  g047(.A(new_n76_), .B(G21), .Y(new_n121_));
  XNOR2x2_ASAP7_75t_R g048(.A(new_n120_), .B(new_n121_), .Y(new_n122_));
  XOR2x2_ASAP7_75t_R  g049(.A(new_n104_), .B(new_n122_), .Y(new_n123_));
  XOR2x2_ASAP7_75t_R  g050(.A(new_n119_), .B(new_n123_), .Y(new_n124_));
  XOR2x2_ASAP7_75t_R  g051(.A(G30), .B(G26), .Y(new_n125_));
  XNOR2x2_ASAP7_75t_R g052(.A(G18), .B(new_n77_), .Y(new_n126_));
  XOR2x2_ASAP7_75t_R  g053(.A(new_n125_), .B(new_n126_), .Y(new_n127_));
  XNOR2x2_ASAP7_75t_R g054(.A(new_n108_), .B(new_n127_), .Y(new_n128_));
  NAND2x1_ASAP7_75t_R g055(.A(G41), .B(G38), .Y(new_n129_));
  XOR2x2_ASAP7_75t_R  g056(.A(G16), .B(G15), .Y(new_n130_));
  XOR2x2_ASAP7_75t_R  g057(.A(new_n75_), .B(G14), .Y(new_n131_));
  XNOR2x2_ASAP7_75t_R g058(.A(new_n130_), .B(new_n131_), .Y(new_n132_));
  XOR2x2_ASAP7_75t_R  g059(.A(new_n129_), .B(new_n132_), .Y(new_n133_));
  XOR2x2_ASAP7_75t_R  g060(.A(new_n128_), .B(new_n133_), .Y(new_n134_));
  INVx1_ASAP7_75t_R   g061(.A(new_n134_), .Y(new_n135_));
  OR2x4_ASAP7_75t_R   g062(.A(new_n124_), .B(new_n135_), .Y(new_n136_));
  NAND2x1_ASAP7_75t_R g063(.A(G41), .B(G40), .Y(new_n137_));
  XOR2x2_ASAP7_75t_R  g064(.A(new_n118_), .B(new_n137_), .Y(new_n138_));
  XOR2x2_ASAP7_75t_R  g065(.A(G20), .B(G24), .Y(new_n139_));
  XNOR2x2_ASAP7_75t_R g066(.A(new_n81_), .B(new_n85_), .Y(new_n140_));
  XOR2x2_ASAP7_75t_R  g067(.A(new_n139_), .B(new_n140_), .Y(new_n141_));
  XOR2x2_ASAP7_75t_R  g068(.A(new_n132_), .B(new_n141_), .Y(new_n142_));
  XOR2x2_ASAP7_75t_R  g069(.A(new_n138_), .B(new_n142_), .Y(new_n143_));
  INVx1_ASAP7_75t_R   g070(.A(new_n143_), .Y(new_n144_));
  NAND2x1_ASAP7_75t_R g071(.A(G41), .B(G34), .Y(new_n145_));
  XOR2x2_ASAP7_75t_R  g072(.A(new_n80_), .B(new_n81_), .Y(new_n146_));
  XOR2x2_ASAP7_75t_R  g073(.A(new_n79_), .B(G30), .Y(new_n147_));
  XOR2x2_ASAP7_75t_R  g074(.A(new_n146_), .B(new_n147_), .Y(new_n148_));
  XOR2x2_ASAP7_75t_R  g075(.A(new_n145_), .B(new_n148_), .Y(new_n149_));
  XOR2x2_ASAP7_75t_R  g076(.A(G25), .B(new_n84_), .Y(new_n150_));
  XOR2x2_ASAP7_75t_R  g077(.A(G27), .B(G28), .Y(new_n151_));
  XNOR2x2_ASAP7_75t_R g078(.A(new_n150_), .B(new_n151_), .Y(new_n152_));
  XOR2x2_ASAP7_75t_R  g079(.A(G10), .B(G14), .Y(new_n153_));
  XNOR2x2_ASAP7_75t_R g080(.A(G2), .B(new_n86_), .Y(new_n154_));
  XOR2x2_ASAP7_75t_R  g081(.A(new_n153_), .B(new_n154_), .Y(new_n155_));
  XNOR2x2_ASAP7_75t_R g082(.A(new_n152_), .B(new_n155_), .Y(new_n156_));
  XOR2x2_ASAP7_75t_R  g083(.A(new_n149_), .B(new_n156_), .Y(new_n157_));
  INVx1_ASAP7_75t_R   g084(.A(new_n157_), .Y(new_n158_));
  OR2x4_ASAP7_75t_R   g085(.A(new_n100_), .B(new_n158_), .Y(new_n159_));
  NAND2x1_ASAP7_75t_R g086(.A(new_n100_), .B(new_n158_), .Y(new_n160_));
  AND2x2_ASAP7_75t_R  g087(.A(new_n159_), .B(new_n160_), .Y(new_n161_));
  NAND2x1_ASAP7_75t_R g088(.A(G41), .B(G36), .Y(new_n162_));
  XNOR2x2_ASAP7_75t_R g089(.A(new_n90_), .B(new_n162_), .Y(new_n163_));
  XOR2x2_ASAP7_75t_R  g090(.A(G12), .B(G16), .Y(new_n164_));
  XNOR2x2_ASAP7_75t_R g091(.A(new_n78_), .B(G8), .Y(new_n165_));
  XNOR2x2_ASAP7_75t_R g092(.A(new_n164_), .B(new_n165_), .Y(new_n166_));
  XOR2x2_ASAP7_75t_R  g093(.A(new_n148_), .B(new_n166_), .Y(new_n167_));
  XOR2x2_ASAP7_75t_R  g094(.A(new_n163_), .B(new_n167_), .Y(new_n168_));
  INVx1_ASAP7_75t_R   g095(.A(new_n168_), .Y(new_n169_));
  XNOR2x2_ASAP7_75t_R g096(.A(G11), .B(G15), .Y(new_n170_));
  XOR2x2_ASAP7_75t_R  g097(.A(G3), .B(new_n83_), .Y(new_n171_));
  XOR2x2_ASAP7_75t_R  g098(.A(new_n170_), .B(new_n171_), .Y(new_n172_));
  XNOR2x2_ASAP7_75t_R g099(.A(new_n152_), .B(new_n172_), .Y(new_n173_));
  NAND2x1_ASAP7_75t_R g100(.A(G41), .B(G35), .Y(new_n174_));
  XNOR2x2_ASAP7_75t_R g101(.A(new_n97_), .B(new_n174_), .Y(new_n175_));
  XOR2x2_ASAP7_75t_R  g102(.A(new_n173_), .B(new_n175_), .Y(new_n176_));
  INVx1_ASAP7_75t_R   g103(.A(new_n176_), .Y(new_n177_));
  NOR2x1_ASAP7_75t_R  g104(.A(new_n169_), .B(new_n177_), .Y(new_n178_));
  AO21x1_ASAP7_75t_R  g105(.A1(new_n169_), .A2(new_n177_), .B(new_n178_), .Y(new_n179_));
  AOI21x1_ASAP7_75t_R g106(.A1(new_n100_), .A2(new_n157_), .B(new_n178_), .Y(new_n180_));
  AO21x1_ASAP7_75t_R  g107(.A1(new_n161_), .A2(new_n179_), .B(new_n180_), .Y(new_n181_));
  OR2x4_ASAP7_75t_R   g108(.A(new_n143_), .B(new_n181_), .Y(new_n182_));
  OR3x1_ASAP7_75t_R   g109(.A(new_n113_), .B(new_n136_), .C(new_n182_), .Y(new_n183_));
  NOR2x1_ASAP7_75t_R  g110(.A(new_n100_), .B(new_n183_), .Y(new_n184_));
  XOR2x2_ASAP7_75t_R  g111(.A(new_n87_), .B(new_n184_), .Y(G1324));
  NAND2x1_ASAP7_75t_R g112(.A(new_n124_), .B(new_n135_), .Y(new_n186_));
  AND2x2_ASAP7_75t_R  g113(.A(new_n136_), .B(new_n186_), .Y(new_n187_));
  NOR2x1_ASAP7_75t_R  g114(.A(new_n114_), .B(new_n143_), .Y(new_n188_));
  AO21x1_ASAP7_75t_R  g115(.A1(new_n114_), .A2(new_n143_), .B(new_n188_), .Y(new_n189_));
  AOI21x1_ASAP7_75t_R g116(.A1(new_n124_), .A2(new_n134_), .B(new_n188_), .Y(new_n190_));
  AO21x1_ASAP7_75t_R  g117(.A1(new_n187_), .A2(new_n189_), .B(new_n190_), .Y(new_n191_));
  OR2x4_ASAP7_75t_R   g118(.A(new_n168_), .B(new_n191_), .Y(new_n192_));
  OR3x1_ASAP7_75t_R   g119(.A(new_n159_), .B(new_n177_), .C(new_n192_), .Y(new_n193_));
  OR2x4_ASAP7_75t_R   g120(.A(new_n124_), .B(new_n193_), .Y(new_n194_));
  XOR2x2_ASAP7_75t_R  g121(.A(G21), .B(new_n194_), .Y(G1344));
  OR2x4_ASAP7_75t_R   g122(.A(new_n157_), .B(new_n183_), .Y(new_n196_));
  XOR2x2_ASAP7_75t_R  g123(.A(G2), .B(new_n196_), .Y(G1325));
  NOR2x1_ASAP7_75t_R  g124(.A(new_n176_), .B(new_n183_), .Y(new_n198_));
  XOR2x2_ASAP7_75t_R  g125(.A(new_n82_), .B(new_n198_), .Y(G1326));
  NOR2x1_ASAP7_75t_R  g126(.A(new_n168_), .B(new_n183_), .Y(new_n200_));
  XOR2x2_ASAP7_75t_R  g127(.A(new_n78_), .B(new_n200_), .Y(G1327));
  OR2x4_ASAP7_75t_R   g128(.A(new_n144_), .B(new_n181_), .Y(new_n202_));
  OR3x1_ASAP7_75t_R   g129(.A(new_n114_), .B(new_n136_), .C(new_n202_), .Y(new_n203_));
  OR2x4_ASAP7_75t_R   g130(.A(new_n100_), .B(new_n203_), .Y(new_n204_));
  XOR2x2_ASAP7_75t_R  g131(.A(G5), .B(new_n204_), .Y(G1328));
  OR2x4_ASAP7_75t_R   g132(.A(new_n157_), .B(new_n203_), .Y(new_n206_));
  XOR2x2_ASAP7_75t_R  g133(.A(G6), .B(new_n206_), .Y(G1329));
  NOR2x1_ASAP7_75t_R  g134(.A(new_n176_), .B(new_n203_), .Y(new_n208_));
  XOR2x2_ASAP7_75t_R  g135(.A(new_n83_), .B(new_n208_), .Y(G1330));
  OR2x4_ASAP7_75t_R   g136(.A(new_n169_), .B(new_n191_), .Y(new_n210_));
  OR3x1_ASAP7_75t_R   g137(.A(new_n159_), .B(new_n176_), .C(new_n210_), .Y(new_n211_));
  OR2x4_ASAP7_75t_R   g138(.A(new_n144_), .B(new_n211_), .Y(new_n212_));
  XOR2x2_ASAP7_75t_R  g139(.A(G20), .B(new_n212_), .Y(G1343));
  OR2x4_ASAP7_75t_R   g140(.A(new_n168_), .B(new_n203_), .Y(new_n214_));
  XOR2x2_ASAP7_75t_R  g141(.A(G8), .B(new_n214_), .Y(G1331));
  OR3x1_ASAP7_75t_R   g142(.A(new_n113_), .B(new_n186_), .C(new_n182_), .Y(new_n216_));
  NOR2x1_ASAP7_75t_R  g143(.A(new_n100_), .B(new_n216_), .Y(new_n217_));
  XOR2x2_ASAP7_75t_R  g144(.A(new_n74_), .B(new_n217_), .Y(G1332));
  OR2x4_ASAP7_75t_R   g145(.A(new_n157_), .B(new_n216_), .Y(new_n219_));
  XOR2x2_ASAP7_75t_R  g146(.A(G10), .B(new_n219_), .Y(G1333));
  OR2x4_ASAP7_75t_R   g147(.A(new_n176_), .B(new_n216_), .Y(new_n221_));
  XOR2x2_ASAP7_75t_R  g148(.A(G11), .B(new_n221_), .Y(G1334));
  OR2x4_ASAP7_75t_R   g149(.A(new_n168_), .B(new_n216_), .Y(new_n223_));
  XOR2x2_ASAP7_75t_R  g150(.A(G12), .B(new_n223_), .Y(G1335));
  OR3x1_ASAP7_75t_R   g151(.A(new_n114_), .B(new_n186_), .C(new_n202_), .Y(new_n225_));
  NOR2x1_ASAP7_75t_R  g152(.A(new_n100_), .B(new_n225_), .Y(new_n226_));
  XOR2x2_ASAP7_75t_R  g153(.A(new_n75_), .B(new_n226_), .Y(G1336));
  NOR2x1_ASAP7_75t_R  g154(.A(new_n157_), .B(new_n225_), .Y(new_n228_));
  XNOR2x2_ASAP7_75t_R g155(.A(G14), .B(new_n228_), .Y(G1337));
  OR2x4_ASAP7_75t_R   g156(.A(new_n176_), .B(new_n225_), .Y(new_n230_));
  XOR2x2_ASAP7_75t_R  g157(.A(G15), .B(new_n230_), .Y(G1338));
  NOR2x1_ASAP7_75t_R  g158(.A(new_n168_), .B(new_n225_), .Y(new_n232_));
  XNOR2x2_ASAP7_75t_R g159(.A(G16), .B(new_n232_), .Y(G1339));
  NOR2x1_ASAP7_75t_R  g160(.A(new_n124_), .B(new_n211_), .Y(new_n234_));
  XOR2x2_ASAP7_75t_R  g161(.A(new_n76_), .B(new_n234_), .Y(G1340));
  OR2x4_ASAP7_75t_R   g162(.A(new_n134_), .B(new_n211_), .Y(new_n236_));
  XOR2x2_ASAP7_75t_R  g163(.A(G18), .B(new_n236_), .Y(G1341));
  OR2x4_ASAP7_75t_R   g164(.A(new_n113_), .B(new_n211_), .Y(new_n238_));
  XOR2x2_ASAP7_75t_R  g165(.A(G19), .B(new_n238_), .Y(G1342));
  NOR2x1_ASAP7_75t_R  g166(.A(new_n134_), .B(new_n193_), .Y(new_n240_));
  XOR2x2_ASAP7_75t_R  g167(.A(new_n77_), .B(new_n240_), .Y(G1345));
  OR2x4_ASAP7_75t_R   g168(.A(new_n113_), .B(new_n193_), .Y(new_n242_));
  XOR2x2_ASAP7_75t_R  g169(.A(G23), .B(new_n242_), .Y(G1346));
  OR2x4_ASAP7_75t_R   g170(.A(new_n144_), .B(new_n193_), .Y(new_n244_));
  XOR2x2_ASAP7_75t_R  g171(.A(G24), .B(new_n244_), .Y(G1347));
  OR3x1_ASAP7_75t_R   g172(.A(new_n160_), .B(new_n176_), .C(new_n210_), .Y(new_n246_));
  NOR2x1_ASAP7_75t_R  g173(.A(new_n124_), .B(new_n246_), .Y(new_n247_));
  XNOR2x2_ASAP7_75t_R g174(.A(G25), .B(new_n247_), .Y(G1348));
  NOR2x1_ASAP7_75t_R  g175(.A(new_n134_), .B(new_n246_), .Y(new_n249_));
  XOR2x2_ASAP7_75t_R  g176(.A(new_n84_), .B(new_n249_), .Y(G1349));
  OR2x4_ASAP7_75t_R   g177(.A(new_n113_), .B(new_n246_), .Y(new_n251_));
  XOR2x2_ASAP7_75t_R  g178(.A(G27), .B(new_n251_), .Y(G1350));
  NOR2x1_ASAP7_75t_R  g179(.A(new_n144_), .B(new_n246_), .Y(new_n253_));
  XOR2x2_ASAP7_75t_R  g180(.A(new_n85_), .B(new_n253_), .Y(G1351));
  OR3x1_ASAP7_75t_R   g181(.A(new_n160_), .B(new_n177_), .C(new_n192_), .Y(new_n255_));
  NOR2x1_ASAP7_75t_R  g182(.A(new_n124_), .B(new_n255_), .Y(new_n256_));
  XOR2x2_ASAP7_75t_R  g183(.A(new_n79_), .B(new_n256_), .Y(G1352));
  OR2x4_ASAP7_75t_R   g184(.A(new_n134_), .B(new_n255_), .Y(new_n258_));
  XOR2x2_ASAP7_75t_R  g185(.A(G30), .B(new_n258_), .Y(G1353));
  NOR2x1_ASAP7_75t_R  g186(.A(new_n113_), .B(new_n255_), .Y(new_n260_));
  XOR2x2_ASAP7_75t_R  g187(.A(new_n80_), .B(new_n260_), .Y(G1354));
  NOR2x1_ASAP7_75t_R  g188(.A(new_n144_), .B(new_n255_), .Y(new_n262_));
  XOR2x2_ASAP7_75t_R  g189(.A(new_n81_), .B(new_n262_), .Y(G1355));
endmodule


