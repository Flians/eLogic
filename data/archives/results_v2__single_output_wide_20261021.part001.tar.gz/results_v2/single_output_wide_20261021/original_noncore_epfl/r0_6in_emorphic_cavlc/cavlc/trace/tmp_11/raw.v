// Benchmark "/tmp/" written by ABC on Wed Oct 21 14:26:13 2026

module \/tmp/  ( 
    p0, p7, p1, p8, p3, p4, p6, p9, p5, p2,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10  );
  input  p0, p7, p1, p8, p3, p4, p6, p9, p5, p2;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10;
  wire new_n22_, new_n23_, new_n24_, new_n25_, new_n26_, new_n27_, new_n28_,
    new_n29_, new_n30_, new_n31_, new_n32_, new_n33_, new_n34_, new_n35_,
    new_n36_, new_n37_, new_n38_, new_n39_, new_n40_, new_n41_, new_n42_,
    new_n43_, new_n44_, new_n45_, new_n46_, new_n47_, new_n48_, new_n49_,
    new_n50_, new_n51_, new_n52_, new_n53_, new_n54_, new_n55_, new_n56_,
    new_n57_, new_n58_, new_n59_, new_n60_, new_n61_, new_n62_, new_n63_,
    new_n64_, new_n65_, new_n66_, new_n67_, new_n68_, new_n69_, new_n70_,
    new_n71_, new_n72_, new_n73_, new_n74_, new_n75_, new_n76_, new_n77_,
    new_n78_, new_n79_, new_n80_, new_n81_, new_n82_, new_n83_, new_n84_,
    new_n85_, new_n86_, new_n87_, new_n88_, new_n89_, new_n90_, new_n91_,
    new_n92_, new_n93_, new_n94_, new_n95_, new_n96_, new_n97_, new_n98_,
    new_n99_, new_n100_, new_n101_, new_n102_, new_n103_, new_n104_,
    new_n105_, new_n106_, new_n107_, new_n108_, new_n109_, new_n110_,
    new_n111_, new_n112_, new_n113_, new_n114_, new_n115_, new_n116_,
    new_n118_, new_n119_, new_n120_, new_n121_, new_n122_, new_n123_,
    new_n124_, new_n125_, new_n126_, new_n127_, new_n128_, new_n129_,
    new_n130_, new_n131_, new_n132_, new_n133_, new_n134_, new_n135_,
    new_n136_, new_n137_, new_n138_, new_n139_, new_n140_, new_n141_,
    new_n142_, new_n143_, new_n144_, new_n145_, new_n146_, new_n147_,
    new_n148_, new_n149_, new_n150_, new_n151_, new_n152_, new_n153_,
    new_n154_, new_n155_, new_n156_, new_n157_, new_n158_, new_n159_,
    new_n160_, new_n161_, new_n162_, new_n163_, new_n164_, new_n165_,
    new_n166_, new_n167_, new_n168_, new_n169_, new_n170_, new_n171_,
    new_n172_, new_n173_, new_n174_, new_n175_, new_n176_, new_n177_,
    new_n178_, new_n179_, new_n180_, new_n181_, new_n182_, new_n183_,
    new_n184_, new_n185_, new_n186_, new_n187_, new_n188_, new_n189_,
    new_n190_, new_n191_, new_n193_, new_n194_, new_n195_, new_n196_,
    new_n197_, new_n198_, new_n199_, new_n200_, new_n201_, new_n202_,
    new_n203_, new_n204_, new_n205_, new_n206_, new_n207_, new_n208_,
    new_n209_, new_n210_, new_n211_, new_n212_, new_n213_, new_n214_,
    new_n215_, new_n216_, new_n217_, new_n218_, new_n219_, new_n220_,
    new_n221_, new_n222_, new_n223_, new_n224_, new_n225_, new_n226_,
    new_n227_, new_n228_, new_n229_, new_n230_, new_n231_, new_n232_,
    new_n233_, new_n234_, new_n235_, new_n236_, new_n237_, new_n238_,
    new_n239_, new_n240_, new_n241_, new_n242_, new_n243_, new_n245_,
    new_n246_, new_n247_, new_n248_, new_n249_, new_n250_, new_n251_,
    new_n252_, new_n253_, new_n254_, new_n255_, new_n256_, new_n257_,
    new_n258_, new_n259_, new_n260_, new_n261_, new_n262_, new_n263_,
    new_n264_, new_n265_, new_n266_, new_n267_, new_n268_, new_n269_,
    new_n270_, new_n271_, new_n272_, new_n273_, new_n274_, new_n275_,
    new_n276_, new_n277_, new_n278_, new_n280_, new_n281_, new_n282_,
    new_n283_, new_n284_, new_n285_, new_n287_, new_n288_, new_n290_,
    new_n291_, new_n292_, new_n293_, new_n294_, new_n295_, new_n296_,
    new_n297_, new_n298_, new_n299_, new_n300_, new_n301_, new_n302_,
    new_n303_, new_n304_, new_n305_, new_n306_, new_n307_, new_n308_,
    new_n309_, new_n310_, new_n311_, new_n312_, new_n313_, new_n314_,
    new_n315_, new_n316_, new_n317_, new_n318_, new_n319_, new_n320_,
    new_n321_, new_n322_, new_n323_, new_n325_, new_n326_, new_n327_,
    new_n328_, new_n329_, new_n330_, new_n331_, new_n332_, new_n333_,
    new_n334_, new_n335_, new_n336_, new_n337_, new_n338_, new_n339_,
    new_n340_, new_n341_, new_n342_, new_n343_, new_n344_, new_n345_,
    new_n346_, new_n347_, new_n348_, new_n349_, new_n350_, new_n351_,
    new_n352_, new_n353_, new_n354_, new_n355_, new_n356_, new_n357_,
    new_n358_, new_n359_, new_n360_, new_n361_, new_n362_, new_n363_,
    new_n364_, new_n365_, new_n366_, new_n367_, new_n369_, new_n370_,
    new_n371_, new_n372_, new_n373_, new_n374_, new_n375_, new_n376_,
    new_n377_, new_n378_, new_n379_, new_n380_, new_n381_, new_n382_,
    new_n383_, new_n384_, new_n385_, new_n386_, new_n387_, new_n388_,
    new_n389_, new_n390_, new_n391_, new_n392_, new_n393_, new_n394_,
    new_n395_, new_n396_, new_n397_, new_n398_, new_n400_, new_n401_,
    new_n402_, new_n403_, new_n404_, new_n405_, new_n406_, new_n407_,
    new_n408_, new_n409_, new_n410_, new_n411_, new_n412_, new_n413_,
    new_n414_, new_n415_, new_n416_, new_n418_, new_n419_, new_n420_;
  NOR2x1_ASAP7_75t_R   g000(.A(p3), .B(p5), .Y(new_n22_));
  INVx1_ASAP7_75t_R    g001(.A(p0), .Y(new_n23_));
  NAND2x1_ASAP7_75t_R  g002(.A(p9), .B(new_n23_), .Y(new_n24_));
  NOR2x1_ASAP7_75t_R   g003(.A(p0), .B(p2), .Y(new_n25_));
  AO21x1_ASAP7_75t_R   g004(.A1(p2), .A2(new_n24_), .B(new_n25_), .Y(new_n26_));
  NOR2x1_ASAP7_75t_R   g005(.A(p1), .B(p2), .Y(new_n27_));
  NAND2x1_ASAP7_75t_R  g006(.A(p8), .B(new_n23_), .Y(new_n28_));
  NOR2x1_ASAP7_75t_R   g007(.A(new_n27_), .B(new_n28_), .Y(new_n29_));
  INVx1_ASAP7_75t_R    g008(.A(p9), .Y(new_n30_));
  NOR2x1_ASAP7_75t_R   g009(.A(p0), .B(new_n30_), .Y(new_n31_));
  INVx1_ASAP7_75t_R    g010(.A(p8), .Y(new_n32_));
  NAND2x1_ASAP7_75t_R  g011(.A(p1), .B(new_n32_), .Y(new_n33_));
  NAND2x1_ASAP7_75t_R  g012(.A(p4), .B(new_n30_), .Y(new_n34_));
  OAI22x1_ASAP7_75t_R  g013(.A1(new_n31_), .A2(new_n33_), .B1(new_n34_), .B2(p8), .Y(new_n35_));
  NOR2x1_ASAP7_75t_R   g014(.A(new_n29_), .B(new_n35_), .Y(new_n36_));
  INVx1_ASAP7_75t_R    g015(.A(p7), .Y(new_n37_));
  INVx1_ASAP7_75t_R    g016(.A(p6), .Y(new_n38_));
  NAND2x1_ASAP7_75t_R  g017(.A(new_n37_), .B(new_n38_), .Y(new_n39_));
  AO21x1_ASAP7_75t_R   g018(.A1(new_n26_), .A2(new_n36_), .B(new_n39_), .Y(new_n40_));
  NOR2x1_ASAP7_75t_R   g019(.A(p0), .B(p8), .Y(new_n41_));
  INVx1_ASAP7_75t_R    g020(.A(p1), .Y(new_n42_));
  NOR2x1_ASAP7_75t_R   g021(.A(p9), .B(new_n42_), .Y(new_n43_));
  INVx1_ASAP7_75t_R    g022(.A(p4), .Y(new_n44_));
  AO21x1_ASAP7_75t_R   g023(.A1(new_n32_), .A2(new_n44_), .B(p0), .Y(new_n45_));
  NOR2x1_ASAP7_75t_R   g024(.A(p1), .B(new_n30_), .Y(new_n46_));
  AO32x1_ASAP7_75t_R   g025(.A1(p6), .A2(new_n41_), .A3(new_n43_), .B1(new_n45_), .B2(new_n46_), .Y(new_n47_));
  NAND2x1_ASAP7_75t_R  g026(.A(p7), .B(new_n44_), .Y(new_n48_));
  NOR2x1_ASAP7_75t_R   g027(.A(p8), .B(p4), .Y(new_n49_));
  OAI21x1_ASAP7_75t_R  g028(.A1(new_n38_), .A2(new_n49_), .B(new_n46_), .Y(new_n50_));
  NOR2x1_ASAP7_75t_R   g029(.A(p8), .B(new_n23_), .Y(new_n51_));
  AO21x1_ASAP7_75t_R   g030(.A1(new_n38_), .A2(new_n51_), .B(p2), .Y(new_n52_));
  AOI21x1_ASAP7_75t_R  g031(.A1(new_n48_), .A2(new_n50_), .B(new_n52_), .Y(new_n53_));
  NAND2x1_ASAP7_75t_R  g032(.A(new_n47_), .B(new_n53_), .Y(new_n54_));
  NOR2x1_ASAP7_75t_R   g033(.A(p0), .B(new_n32_), .Y(new_n55_));
  NOR2x1_ASAP7_75t_R   g034(.A(p4), .B(p2), .Y(new_n56_));
  INVx1_ASAP7_75t_R    g035(.A(new_n56_), .Y(new_n57_));
  AND2x2_ASAP7_75t_R   g036(.A(p0), .B(p9), .Y(new_n58_));
  OR4x2_ASAP7_75t_R    g037(.A(new_n55_), .B(new_n57_), .C(new_n51_), .D(new_n58_), .Y(new_n59_));
  AND2x2_ASAP7_75t_R   g038(.A(p0), .B(p8), .Y(new_n60_));
  NOR2x1_ASAP7_75t_R   g039(.A(new_n41_), .B(new_n60_), .Y(new_n61_));
  NOR2x1_ASAP7_75t_R   g040(.A(p0), .B(p9), .Y(new_n62_));
  OR3x1_ASAP7_75t_R    g041(.A(new_n61_), .B(p6), .C(new_n62_), .Y(new_n63_));
  NOR2x1_ASAP7_75t_R   g042(.A(p7), .B(p1), .Y(new_n64_));
  INVx1_ASAP7_75t_R    g043(.A(new_n64_), .Y(new_n65_));
  AO21x1_ASAP7_75t_R   g044(.A1(new_n59_), .A2(new_n63_), .B(new_n65_), .Y(new_n66_));
  NAND3x1_ASAP7_75t_R  g045(.A(new_n40_), .B(new_n54_), .C(new_n66_), .Y(new_n67_));
  NOR2x1_ASAP7_75t_R   g046(.A(p7), .B(new_n44_), .Y(new_n68_));
  AND2x2_ASAP7_75t_R   g047(.A(p4), .B(p5), .Y(new_n69_));
  NOR2x1_ASAP7_75t_R   g048(.A(p8), .B(p5), .Y(new_n70_));
  AND2x2_ASAP7_75t_R   g049(.A(p7), .B(p3), .Y(new_n71_));
  OAI22x1_ASAP7_75t_R  g050(.A1(new_n68_), .A2(new_n69_), .B1(new_n70_), .B2(new_n71_), .Y(new_n72_));
  INVx1_ASAP7_75t_R    g051(.A(p3), .Y(new_n73_));
  AO21x1_ASAP7_75t_R   g052(.A1(p8), .A2(new_n73_), .B(new_n70_), .Y(new_n74_));
  OR3x1_ASAP7_75t_R    g053(.A(new_n74_), .B(p7), .C(new_n69_), .Y(new_n75_));
  NAND2x1_ASAP7_75t_R  g054(.A(new_n72_), .B(new_n75_), .Y(new_n76_));
  AND3x1_ASAP7_75t_R   g055(.A(new_n27_), .B(new_n23_), .C(new_n30_), .Y(new_n77_));
  AND3x1_ASAP7_75t_R   g056(.A(new_n76_), .B(new_n38_), .C(new_n77_), .Y(new_n78_));
  AOI21x1_ASAP7_75t_R  g057(.A1(new_n22_), .A2(new_n67_), .B(new_n78_), .Y(new_n79_));
  AO21x1_ASAP7_75t_R   g058(.A1(p8), .A2(new_n30_), .B(new_n23_), .Y(new_n80_));
  AO21x1_ASAP7_75t_R   g059(.A1(p9), .A2(new_n32_), .B(p1), .Y(new_n81_));
  INVx1_ASAP7_75t_R    g060(.A(new_n81_), .Y(new_n82_));
  OAI21x1_ASAP7_75t_R  g061(.A1(p2), .A2(new_n80_), .B(new_n82_), .Y(new_n83_));
  INVx1_ASAP7_75t_R    g062(.A(p5), .Y(new_n84_));
  NAND2x1_ASAP7_75t_R  g063(.A(p7), .B(p4), .Y(new_n85_));
  AOI21x1_ASAP7_75t_R  g064(.A1(new_n84_), .A2(new_n81_), .B(new_n85_), .Y(new_n86_));
  AO21x1_ASAP7_75t_R   g065(.A1(p8), .A2(new_n23_), .B(p4), .Y(new_n87_));
  AO21x1_ASAP7_75t_R   g066(.A1(new_n42_), .A2(new_n30_), .B(p4), .Y(new_n88_));
  NOR2x1_ASAP7_75t_R   g067(.A(p8), .B(new_n30_), .Y(new_n89_));
  NOR2x1_ASAP7_75t_R   g068(.A(p9), .B(new_n32_), .Y(new_n90_));
  NOR2x1_ASAP7_75t_R   g069(.A(new_n89_), .B(new_n90_), .Y(new_n91_));
  AND3x1_ASAP7_75t_R   g070(.A(p0), .B(p1), .C(p4), .Y(new_n92_));
  AO32x1_ASAP7_75t_R   g071(.A1(p5), .A2(new_n87_), .A3(new_n88_), .B1(new_n91_), .B2(new_n92_), .Y(new_n93_));
  AND2x2_ASAP7_75t_R   g072(.A(p7), .B(p2), .Y(new_n94_));
  NOR2x1_ASAP7_75t_R   g073(.A(p1), .B(p8), .Y(new_n95_));
  AND2x2_ASAP7_75t_R   g074(.A(p1), .B(p8), .Y(new_n96_));
  AO21x1_ASAP7_75t_R   g075(.A1(p0), .A2(new_n95_), .B(new_n96_), .Y(new_n97_));
  INVx1_ASAP7_75t_R    g076(.A(p2), .Y(new_n98_));
  AND3x1_ASAP7_75t_R   g077(.A(new_n30_), .B(new_n98_), .C(p5), .Y(new_n99_));
  NOR2x1_ASAP7_75t_R   g078(.A(p7), .B(p8), .Y(new_n100_));
  AO32x1_ASAP7_75t_R   g079(.A1(new_n97_), .A2(p7), .A3(new_n99_), .B1(new_n100_), .B2(new_n77_), .Y(new_n101_));
  AOI221x1_ASAP7_75t_R g080(.A1(new_n83_), .A2(new_n86_), .B1(new_n93_), .B2(new_n94_), .C(new_n101_), .Y(new_n102_));
  NAND2x1_ASAP7_75t_R  g081(.A(p2), .B(new_n84_), .Y(new_n103_));
  OA211x2_ASAP7_75t_R  g082(.A1(new_n42_), .A2(new_n98_), .B(new_n103_), .C(new_n41_), .Y(new_n104_));
  OAI21x1_ASAP7_75t_R  g083(.A1(new_n96_), .A2(new_n104_), .B(new_n37_), .Y(new_n105_));
  AND4x2_ASAP7_75t_R   g084(.A(new_n23_), .B(new_n32_), .C(p1), .D(p9), .Y(new_n106_));
  INVx1_ASAP7_75t_R    g085(.A(new_n41_), .Y(new_n107_));
  AND3x1_ASAP7_75t_R   g086(.A(new_n107_), .B(new_n24_), .C(new_n37_), .Y(new_n108_));
  OAI21x1_ASAP7_75t_R  g087(.A1(new_n106_), .A2(new_n108_), .B(p2), .Y(new_n109_));
  AND3x1_ASAP7_75t_R   g088(.A(new_n30_), .B(new_n98_), .C(p1), .Y(new_n110_));
  NOR2x1_ASAP7_75t_R   g089(.A(p7), .B(new_n23_), .Y(new_n111_));
  AOI22x1_ASAP7_75t_R  g090(.A1(new_n110_), .A2(new_n55_), .B1(new_n30_), .B2(new_n111_), .Y(new_n112_));
  AO31x2_ASAP7_75t_R   g091(.A1(new_n105_), .A2(new_n109_), .A3(new_n112_), .B(p4), .Y(new_n113_));
  NOR2x1_ASAP7_75t_R   g092(.A(p3), .B(p6), .Y(new_n114_));
  INVx1_ASAP7_75t_R    g093(.A(new_n114_), .Y(new_n115_));
  AO21x1_ASAP7_75t_R   g094(.A1(new_n102_), .A2(new_n113_), .B(new_n115_), .Y(new_n116_));
  NAND2x1_ASAP7_75t_R  g095(.A(new_n79_), .B(new_n116_), .Y(o0));
  NAND2x1_ASAP7_75t_R  g096(.A(new_n38_), .B(new_n98_), .Y(new_n118_));
  AND2x2_ASAP7_75t_R   g097(.A(p7), .B(p5), .Y(new_n119_));
  OR3x1_ASAP7_75t_R    g098(.A(new_n119_), .B(p1), .C(new_n30_), .Y(new_n120_));
  NAND2x1_ASAP7_75t_R  g099(.A(p8), .B(p5), .Y(new_n121_));
  OA21x2_ASAP7_75t_R   g100(.A1(new_n37_), .A2(p4), .B(new_n121_), .Y(new_n122_));
  OR4x2_ASAP7_75t_R    g101(.A(new_n32_), .B(new_n44_), .C(p7), .D(p1), .Y(new_n123_));
  OAI22x1_ASAP7_75t_R  g102(.A1(new_n120_), .A2(new_n122_), .B1(p9), .B2(new_n123_), .Y(new_n124_));
  AND2x2_ASAP7_75t_R   g103(.A(p7), .B(p1), .Y(new_n125_));
  AOI22x1_ASAP7_75t_R  g104(.A1(new_n124_), .A2(p0), .B1(new_n70_), .B2(new_n125_), .Y(new_n126_));
  NOR2x1_ASAP7_75t_R   g105(.A(new_n49_), .B(new_n119_), .Y(new_n127_));
  AO21x1_ASAP7_75t_R   g106(.A1(p7), .A2(new_n32_), .B(new_n42_), .Y(new_n128_));
  OR3x1_ASAP7_75t_R    g107(.A(p7), .B(p1), .C(p8), .Y(new_n129_));
  OAI22x1_ASAP7_75t_R  g108(.A1(new_n127_), .A2(new_n128_), .B1(new_n34_), .B2(new_n129_), .Y(new_n130_));
  NAND2x1_ASAP7_75t_R  g109(.A(p1), .B(new_n30_), .Y(new_n131_));
  AND3x1_ASAP7_75t_R   g110(.A(p7), .B(p8), .C(p9), .Y(new_n132_));
  INVx1_ASAP7_75t_R    g111(.A(new_n132_), .Y(new_n133_));
  NAND2x1_ASAP7_75t_R  g112(.A(p1), .B(p4), .Y(new_n134_));
  OAI22x1_ASAP7_75t_R  g113(.A1(new_n122_), .A2(new_n131_), .B1(new_n133_), .B2(new_n134_), .Y(new_n135_));
  OAI21x1_ASAP7_75t_R  g114(.A1(new_n130_), .A2(new_n135_), .B(new_n23_), .Y(new_n136_));
  NOR2x1_ASAP7_75t_R   g115(.A(p7), .B(p5), .Y(new_n137_));
  INVx1_ASAP7_75t_R    g116(.A(new_n137_), .Y(new_n138_));
  AO21x1_ASAP7_75t_R   g117(.A1(new_n48_), .A2(new_n138_), .B(p8), .Y(new_n139_));
  NAND2x1_ASAP7_75t_R  g118(.A(p5), .B(new_n30_), .Y(new_n140_));
  AND3x1_ASAP7_75t_R   g119(.A(new_n138_), .B(new_n140_), .C(new_n42_), .Y(new_n141_));
  OR3x1_ASAP7_75t_R    g120(.A(new_n139_), .B(new_n141_), .C(new_n23_), .Y(new_n142_));
  NAND3x1_ASAP7_75t_R  g121(.A(new_n126_), .B(new_n136_), .C(new_n142_), .Y(new_n143_));
  AND3x1_ASAP7_75t_R   g122(.A(p8), .B(p3), .C(p5), .Y(new_n144_));
  OA21x2_ASAP7_75t_R   g123(.A1(new_n71_), .A2(new_n68_), .B(new_n70_), .Y(new_n145_));
  AND3x1_ASAP7_75t_R   g124(.A(new_n23_), .B(new_n42_), .C(new_n30_), .Y(new_n146_));
  OA21x2_ASAP7_75t_R   g125(.A1(new_n144_), .A2(new_n145_), .B(new_n146_), .Y(new_n147_));
  AOI21x1_ASAP7_75t_R  g126(.A1(new_n73_), .A2(new_n143_), .B(new_n147_), .Y(new_n148_));
  NOR2x1_ASAP7_75t_R   g127(.A(p0), .B(new_n98_), .Y(new_n149_));
  AND2x2_ASAP7_75t_R   g128(.A(p0), .B(p4), .Y(new_n150_));
  AO21x1_ASAP7_75t_R   g129(.A1(new_n64_), .A2(new_n149_), .B(new_n150_), .Y(new_n151_));
  AND2x2_ASAP7_75t_R   g130(.A(p9), .B(p5), .Y(new_n152_));
  NAND2x1_ASAP7_75t_R  g131(.A(p0), .B(p1), .Y(new_n153_));
  INVx1_ASAP7_75t_R    g132(.A(new_n153_), .Y(new_n154_));
  INVx1_ASAP7_75t_R    g133(.A(new_n27_), .Y(new_n155_));
  OA211x2_ASAP7_75t_R  g134(.A1(p4), .A2(new_n154_), .B(new_n155_), .C(new_n57_), .Y(new_n156_));
  NOR2x1_ASAP7_75t_R   g135(.A(p7), .B(new_n98_), .Y(new_n157_));
  AO21x1_ASAP7_75t_R   g136(.A1(new_n92_), .A2(new_n157_), .B(new_n32_), .Y(new_n158_));
  AOI221x1_ASAP7_75t_R g137(.A1(new_n151_), .A2(new_n152_), .B1(new_n156_), .B2(p5), .C(new_n158_), .Y(new_n159_));
  AO21x1_ASAP7_75t_R   g138(.A1(p7), .A2(p2), .B(p1), .Y(new_n160_));
  NOR2x1_ASAP7_75t_R   g139(.A(p9), .B(p5), .Y(new_n161_));
  NOR2x1_ASAP7_75t_R   g140(.A(p7), .B(p2), .Y(new_n162_));
  NOR2x1_ASAP7_75t_R   g141(.A(p5), .B(new_n162_), .Y(new_n163_));
  AND3x1_ASAP7_75t_R   g142(.A(new_n163_), .B(new_n31_), .C(new_n48_), .Y(new_n164_));
  AOI21x1_ASAP7_75t_R  g143(.A1(new_n160_), .A2(new_n161_), .B(new_n164_), .Y(new_n165_));
  NOR2x1_ASAP7_75t_R   g144(.A(p0), .B(p5), .Y(new_n166_));
  AND3x1_ASAP7_75t_R   g145(.A(new_n64_), .B(new_n166_), .C(p4), .Y(new_n167_));
  NOR2x1_ASAP7_75t_R   g146(.A(p8), .B(new_n167_), .Y(new_n168_));
  NAND2x1_ASAP7_75t_R  g147(.A(new_n119_), .B(new_n149_), .Y(new_n169_));
  NOR2x1_ASAP7_75t_R   g148(.A(p1), .B(new_n98_), .Y(new_n170_));
  NAND2x1_ASAP7_75t_R  g149(.A(new_n23_), .B(new_n37_), .Y(new_n171_));
  NAND2x1_ASAP7_75t_R  g150(.A(new_n170_), .B(new_n171_), .Y(new_n172_));
  AO21x1_ASAP7_75t_R   g151(.A1(new_n169_), .A2(new_n172_), .B(p4), .Y(new_n173_));
  AO21x1_ASAP7_75t_R   g152(.A1(p7), .A2(new_n30_), .B(p4), .Y(new_n174_));
  OR4x2_ASAP7_75t_R    g153(.A(new_n174_), .B(p1), .C(new_n58_), .D(new_n166_), .Y(new_n175_));
  NAND2x1_ASAP7_75t_R  g154(.A(p7), .B(p9), .Y(new_n176_));
  NOR2x1_ASAP7_75t_R   g155(.A(p1), .B(new_n176_), .Y(new_n177_));
  NAND2x1_ASAP7_75t_R  g156(.A(p9), .B(new_n44_), .Y(new_n178_));
  NAND2x1_ASAP7_75t_R  g157(.A(new_n34_), .B(new_n178_), .Y(new_n179_));
  NOR2x1_ASAP7_75t_R   g158(.A(p5), .B(new_n23_), .Y(new_n180_));
  OAI21x1_ASAP7_75t_R  g159(.A1(new_n177_), .A2(new_n179_), .B(new_n180_), .Y(new_n181_));
  AND5x1_ASAP7_75t_R   g160(.A(new_n165_), .B(new_n168_), .C(new_n173_), .D(new_n175_), .E(new_n181_), .Y(new_n182_));
  NOR2x1_ASAP7_75t_R   g161(.A(p8), .B(new_n37_), .Y(new_n183_));
  NOR2x1_ASAP7_75t_R   g162(.A(p1), .B(new_n38_), .Y(new_n184_));
  AO32x1_ASAP7_75t_R   g163(.A1(new_n183_), .A2(new_n184_), .A3(p0), .B1(new_n41_), .B2(new_n43_), .Y(new_n185_));
  AO21x1_ASAP7_75t_R   g164(.A1(new_n23_), .A2(new_n30_), .B(new_n42_), .Y(new_n186_));
  NOR2x1_ASAP7_75t_R   g165(.A(p7), .B(new_n38_), .Y(new_n187_));
  OA211x2_ASAP7_75t_R  g166(.A1(new_n81_), .A2(new_n58_), .B(new_n186_), .C(new_n187_), .Y(new_n188_));
  AND3x1_ASAP7_75t_R   g167(.A(new_n56_), .B(new_n73_), .C(new_n84_), .Y(new_n189_));
  OAI21x1_ASAP7_75t_R  g168(.A1(new_n185_), .A2(new_n188_), .B(new_n189_), .Y(new_n190_));
  OA31x2_ASAP7_75t_R   g169(.A1(new_n115_), .A2(new_n159_), .A3(new_n182_), .B1(new_n190_), .Y(new_n191_));
  OAI21x1_ASAP7_75t_R  g170(.A1(new_n118_), .A2(new_n148_), .B(new_n191_), .Y(o1));
  AND2x2_ASAP7_75t_R   g171(.A(p7), .B(p9), .Y(new_n193_));
  OA211x2_ASAP7_75t_R  g172(.A1(new_n44_), .A2(new_n149_), .B(new_n42_), .C(new_n100_), .Y(new_n194_));
  AO32x1_ASAP7_75t_R   g173(.A1(new_n55_), .A2(new_n155_), .A3(new_n193_), .B1(new_n194_), .B2(p9), .Y(new_n195_));
  INVx1_ASAP7_75t_R    g174(.A(new_n100_), .Y(new_n196_));
  NAND2x1_ASAP7_75t_R  g175(.A(p7), .B(p8), .Y(new_n197_));
  OA211x2_ASAP7_75t_R  g176(.A1(new_n23_), .A2(new_n196_), .B(p1), .C(new_n197_), .Y(new_n198_));
  AND2x2_ASAP7_75t_R   g177(.A(p7), .B(p8), .Y(new_n199_));
  AO21x1_ASAP7_75t_R   g178(.A1(p9), .A2(new_n199_), .B(new_n100_), .Y(new_n200_));
  AO21x1_ASAP7_75t_R   g179(.A1(p1), .A2(new_n60_), .B(new_n150_), .Y(new_n201_));
  OA21x2_ASAP7_75t_R   g180(.A1(new_n44_), .A2(new_n200_), .B(new_n201_), .Y(new_n202_));
  OA21x2_ASAP7_75t_R   g181(.A1(new_n198_), .A2(new_n202_), .B(new_n98_), .Y(new_n203_));
  AND3x1_ASAP7_75t_R   g182(.A(new_n73_), .B(new_n38_), .C(new_n84_), .Y(new_n204_));
  OAI21x1_ASAP7_75t_R  g183(.A1(new_n195_), .A2(new_n203_), .B(new_n204_), .Y(new_n205_));
  NAND2x1_ASAP7_75t_R  g184(.A(p0), .B(new_n32_), .Y(new_n206_));
  AO221x2_ASAP7_75t_R  g185(.A1(new_n206_), .A2(new_n162_), .B1(p0), .B2(new_n183_), .C(new_n119_), .Y(new_n207_));
  AND3x1_ASAP7_75t_R   g186(.A(new_n114_), .B(new_n44_), .C(p9), .Y(new_n208_));
  OA21x2_ASAP7_75t_R   g187(.A1(new_n38_), .A2(new_n197_), .B(p9), .Y(new_n209_));
  OAI22x1_ASAP7_75t_R  g188(.A1(new_n209_), .A2(new_n80_), .B1(new_n24_), .B2(new_n196_), .Y(new_n210_));
  AO32x1_ASAP7_75t_R   g189(.A1(new_n207_), .A2(new_n28_), .A3(new_n208_), .B1(new_n189_), .B2(new_n210_), .Y(new_n211_));
  NAND2x1_ASAP7_75t_R  g190(.A(p2), .B(new_n42_), .Y(new_n212_));
  NAND2x1_ASAP7_75t_R  g191(.A(p4), .B(p2), .Y(new_n213_));
  AO21x1_ASAP7_75t_R   g192(.A1(p7), .A2(new_n42_), .B(new_n98_), .Y(new_n214_));
  AO32x1_ASAP7_75t_R   g193(.A1(p7), .A2(new_n212_), .A3(new_n213_), .B1(new_n214_), .B2(p4), .Y(new_n215_));
  NAND2x1_ASAP7_75t_R  g194(.A(new_n51_), .B(new_n215_), .Y(new_n216_));
  AO21x1_ASAP7_75t_R   g195(.A1(p1), .A2(new_n37_), .B(new_n23_), .Y(new_n217_));
  AO21x1_ASAP7_75t_R   g196(.A1(p1), .A2(p5), .B(new_n217_), .Y(new_n218_));
  AND2x2_ASAP7_75t_R   g197(.A(p4), .B(new_n160_), .Y(new_n219_));
  AO21x1_ASAP7_75t_R   g198(.A1(new_n55_), .A2(new_n157_), .B(new_n170_), .Y(new_n220_));
  AOI21x1_ASAP7_75t_R  g199(.A1(p7), .A2(new_n51_), .B(new_n70_), .Y(new_n221_));
  AOI22x1_ASAP7_75t_R  g200(.A1(new_n218_), .A2(new_n219_), .B1(new_n220_), .B2(new_n221_), .Y(new_n222_));
  AND3x1_ASAP7_75t_R   g201(.A(new_n100_), .B(new_n44_), .C(p5), .Y(new_n223_));
  NAND2x1_ASAP7_75t_R  g202(.A(p2), .B(new_n37_), .Y(new_n224_));
  NOR2x1_ASAP7_75t_R   g203(.A(p8), .B(new_n98_), .Y(new_n225_));
  AOI211x1_ASAP7_75t_R g204(.A1(new_n224_), .A2(new_n206_), .B(p5), .C(new_n225_), .Y(new_n226_));
  NAND2x1_ASAP7_75t_R  g205(.A(p5), .B(new_n37_), .Y(new_n227_));
  OR3x1_ASAP7_75t_R    g206(.A(new_n23_), .B(new_n32_), .C(p2), .Y(new_n228_));
  OAI21x1_ASAP7_75t_R  g207(.A1(new_n227_), .A2(new_n228_), .B(new_n73_), .Y(new_n229_));
  AOI211x1_ASAP7_75t_R g208(.A1(new_n25_), .A2(new_n223_), .B(new_n226_), .C(new_n229_), .Y(new_n230_));
  NAND3x1_ASAP7_75t_R  g209(.A(new_n216_), .B(new_n222_), .C(new_n230_), .Y(new_n231_));
  OR4x2_ASAP7_75t_R    g210(.A(new_n183_), .B(new_n73_), .C(p4), .D(new_n137_), .Y(new_n232_));
  NOR2x1_ASAP7_75t_R   g211(.A(p6), .B(p9), .Y(new_n233_));
  AO21x1_ASAP7_75t_R   g212(.A1(new_n23_), .A2(new_n27_), .B(new_n73_), .Y(new_n234_));
  AND3x1_ASAP7_75t_R   g213(.A(new_n232_), .B(new_n233_), .C(new_n234_), .Y(new_n235_));
  OA21x2_ASAP7_75t_R   g214(.A1(p7), .A2(p8), .B(p1), .Y(new_n236_));
  AO21x1_ASAP7_75t_R   g215(.A1(new_n197_), .A2(new_n236_), .B(new_n64_), .Y(new_n237_));
  NAND2x1_ASAP7_75t_R  g216(.A(p7), .B(new_n23_), .Y(new_n238_));
  NAND2x1_ASAP7_75t_R  g217(.A(p1), .B(new_n60_), .Y(new_n239_));
  AO21x1_ASAP7_75t_R   g218(.A1(new_n238_), .A2(new_n239_), .B(new_n84_), .Y(new_n240_));
  NAND2x1_ASAP7_75t_R  g219(.A(new_n237_), .B(new_n240_), .Y(new_n241_));
  AND3x1_ASAP7_75t_R   g220(.A(new_n241_), .B(p2), .C(new_n208_), .Y(new_n242_));
  AOI221x1_ASAP7_75t_R g221(.A1(new_n42_), .A2(new_n211_), .B1(new_n231_), .B2(new_n235_), .C(new_n242_), .Y(new_n243_));
  NAND2x1_ASAP7_75t_R  g222(.A(new_n205_), .B(new_n243_), .Y(o2));
  AO21x1_ASAP7_75t_R   g223(.A1(p5), .A2(new_n56_), .B(new_n167_), .Y(new_n245_));
  NAND2x1_ASAP7_75t_R  g224(.A(p1), .B(new_n98_), .Y(new_n246_));
  AO21x1_ASAP7_75t_R   g225(.A1(new_n85_), .A2(new_n246_), .B(new_n125_), .Y(new_n247_));
  OA21x2_ASAP7_75t_R   g226(.A1(new_n42_), .A2(new_n48_), .B(new_n247_), .Y(new_n248_));
  NOR2x1_ASAP7_75t_R   g227(.A(p4), .B(new_n98_), .Y(new_n249_));
  AO21x1_ASAP7_75t_R   g228(.A1(new_n84_), .A2(new_n224_), .B(new_n249_), .Y(new_n250_));
  AND3x1_ASAP7_75t_R   g229(.A(new_n250_), .B(new_n123_), .C(new_n212_), .Y(new_n251_));
  OAI21x1_ASAP7_75t_R  g230(.A1(p8), .A2(new_n248_), .B(new_n251_), .Y(new_n252_));
  NAND2x1_ASAP7_75t_R  g231(.A(p1), .B(p8), .Y(new_n253_));
  AO21x1_ASAP7_75t_R   g232(.A1(p7), .A2(new_n253_), .B(new_n103_), .Y(new_n254_));
  AO21x1_ASAP7_75t_R   g233(.A1(new_n42_), .A2(new_n98_), .B(new_n32_), .Y(new_n255_));
  NAND2x1_ASAP7_75t_R  g234(.A(p5), .B(new_n44_), .Y(new_n256_));
  AO21x1_ASAP7_75t_R   g235(.A1(new_n196_), .A2(new_n255_), .B(new_n256_), .Y(new_n257_));
  AOI21x1_ASAP7_75t_R  g236(.A1(new_n254_), .A2(new_n257_), .B(p0), .Y(new_n258_));
  AO21x1_ASAP7_75t_R   g237(.A1(p7), .A2(p4), .B(new_n60_), .Y(new_n259_));
  AO21x1_ASAP7_75t_R   g238(.A1(p8), .A2(p4), .B(p5), .Y(new_n260_));
  INVx1_ASAP7_75t_R    g239(.A(new_n260_), .Y(new_n261_));
  AND3x1_ASAP7_75t_R   g240(.A(new_n259_), .B(p2), .C(new_n261_), .Y(new_n262_));
  AND2x2_ASAP7_75t_R   g241(.A(p0), .B(p5), .Y(new_n263_));
  AO21x1_ASAP7_75t_R   g242(.A1(new_n37_), .A2(new_n84_), .B(new_n49_), .Y(new_n264_));
  AO32x1_ASAP7_75t_R   g243(.A1(p7), .A2(new_n49_), .A3(new_n263_), .B1(new_n264_), .B2(new_n170_), .Y(new_n265_));
  OR3x1_ASAP7_75t_R    g244(.A(new_n258_), .B(new_n262_), .C(new_n265_), .Y(new_n266_));
  AOI221x1_ASAP7_75t_R g245(.A1(new_n89_), .A2(new_n245_), .B1(new_n58_), .B2(new_n252_), .C(new_n266_), .Y(new_n267_));
  NOR2x1_ASAP7_75t_R   g246(.A(p4), .B(p5), .Y(new_n268_));
  NOR2x1_ASAP7_75t_R   g247(.A(p0), .B(p1), .Y(new_n269_));
  AND3x1_ASAP7_75t_R   g248(.A(new_n269_), .B(p3), .C(new_n98_), .Y(new_n270_));
  AO21x1_ASAP7_75t_R   g249(.A1(p7), .A2(p8), .B(p5), .Y(new_n271_));
  OA211x2_ASAP7_75t_R  g250(.A1(new_n69_), .A2(new_n268_), .B(new_n270_), .C(new_n271_), .Y(new_n272_));
  AO21x1_ASAP7_75t_R   g251(.A1(new_n37_), .A2(new_n263_), .B(new_n155_), .Y(new_n273_));
  OR3x1_ASAP7_75t_R    g252(.A(new_n225_), .B(p0), .C(p5), .Y(new_n274_));
  OAI21x1_ASAP7_75t_R  g253(.A1(new_n69_), .A2(new_n68_), .B(p0), .Y(new_n275_));
  OR3x1_ASAP7_75t_R    g254(.A(new_n260_), .B(p2), .C(new_n100_), .Y(new_n276_));
  AND5x1_ASAP7_75t_R   g255(.A(new_n73_), .B(new_n273_), .C(new_n274_), .D(new_n275_), .E(new_n276_), .Y(new_n277_));
  OAI21x1_ASAP7_75t_R  g256(.A1(new_n272_), .A2(new_n277_), .B(new_n233_), .Y(new_n278_));
  OAI21x1_ASAP7_75t_R  g257(.A1(new_n115_), .A2(new_n267_), .B(new_n278_), .Y(o3));
  OR3x1_ASAP7_75t_R    g258(.A(new_n62_), .B(new_n42_), .C(p3), .Y(new_n280_));
  NAND2x1_ASAP7_75t_R  g259(.A(p3), .B(new_n98_), .Y(new_n281_));
  NAND2x1_ASAP7_75t_R  g260(.A(p2), .B(new_n73_), .Y(new_n282_));
  INVx1_ASAP7_75t_R    g261(.A(new_n146_), .Y(new_n283_));
  AO21x1_ASAP7_75t_R   g262(.A1(new_n281_), .A2(new_n282_), .B(new_n283_), .Y(new_n284_));
  OR3x1_ASAP7_75t_R    g263(.A(new_n44_), .B(new_n84_), .C(p6), .Y(new_n285_));
  AOI21x1_ASAP7_75t_R  g264(.A1(new_n280_), .A2(new_n284_), .B(new_n285_), .Y(o4));
  AO21x1_ASAP7_75t_R   g265(.A1(new_n42_), .A2(new_n62_), .B(new_n282_), .Y(new_n287_));
  NAND2x1_ASAP7_75t_R  g266(.A(p3), .B(new_n77_), .Y(new_n288_));
  AOI21x1_ASAP7_75t_R  g267(.A1(new_n287_), .A2(new_n288_), .B(new_n285_), .Y(o5));
  AO21x1_ASAP7_75t_R   g268(.A1(p5), .A2(new_n37_), .B(p9), .Y(new_n290_));
  AO32x1_ASAP7_75t_R   g269(.A1(new_n290_), .A2(new_n85_), .A3(new_n95_), .B1(new_n90_), .B2(new_n125_), .Y(new_n291_));
  AO21x1_ASAP7_75t_R   g270(.A1(p1), .A2(new_n44_), .B(p5), .Y(new_n292_));
  AO32x1_ASAP7_75t_R   g271(.A1(new_n91_), .A2(new_n42_), .A3(p4), .B1(new_n90_), .B2(new_n292_), .Y(new_n293_));
  OA21x2_ASAP7_75t_R   g272(.A1(new_n132_), .A2(new_n236_), .B(new_n263_), .Y(new_n294_));
  AOI221x1_ASAP7_75t_R g273(.A1(new_n23_), .A2(new_n291_), .B1(new_n293_), .B2(new_n111_), .C(new_n294_), .Y(new_n295_));
  NAND2x1_ASAP7_75t_R  g274(.A(new_n37_), .B(new_n30_), .Y(new_n296_));
  AO32x1_ASAP7_75t_R   g275(.A1(new_n131_), .A2(p0), .A3(new_n37_), .B1(new_n46_), .B2(new_n119_), .Y(new_n297_));
  AO32x1_ASAP7_75t_R   g276(.A1(new_n296_), .A2(new_n51_), .A3(new_n178_), .B1(new_n297_), .B2(p8), .Y(new_n298_));
  NOR2x1_ASAP7_75t_R   g277(.A(p0), .B(new_n100_), .Y(new_n299_));
  OR3x1_ASAP7_75t_R    g278(.A(new_n299_), .B(new_n30_), .C(new_n51_), .Y(new_n300_));
  OA21x2_ASAP7_75t_R   g279(.A1(new_n161_), .A2(new_n154_), .B(new_n171_), .Y(new_n301_));
  NAND2x1_ASAP7_75t_R  g280(.A(new_n61_), .B(new_n301_), .Y(new_n302_));
  AOI21x1_ASAP7_75t_R  g281(.A1(new_n300_), .A2(new_n302_), .B(p4), .Y(new_n303_));
  OAI21x1_ASAP7_75t_R  g282(.A1(new_n298_), .A2(new_n303_), .B(p2), .Y(new_n304_));
  NAND2x1_ASAP7_75t_R  g283(.A(new_n295_), .B(new_n304_), .Y(new_n305_));
  NOR2x1_ASAP7_75t_R   g284(.A(p3), .B(p2), .Y(new_n306_));
  AO32x1_ASAP7_75t_R   g285(.A1(p1), .A2(p8), .A3(new_n30_), .B1(new_n100_), .B2(new_n23_), .Y(new_n307_));
  AOI22x1_ASAP7_75t_R  g286(.A1(new_n307_), .A2(p4), .B1(new_n150_), .B2(new_n132_), .Y(new_n308_));
  NOR2x1_ASAP7_75t_R   g287(.A(new_n37_), .B(new_n49_), .Y(new_n309_));
  AND5x1_ASAP7_75t_R   g288(.A(p7), .B(new_n153_), .C(new_n70_), .D(new_n134_), .E(p9), .Y(new_n310_));
  AOI21x1_ASAP7_75t_R  g289(.A1(new_n43_), .A2(new_n309_), .B(new_n310_), .Y(new_n311_));
  OA21x2_ASAP7_75t_R   g290(.A1(new_n64_), .A2(new_n125_), .B(p5), .Y(new_n312_));
  OAI21x1_ASAP7_75t_R  g291(.A1(new_n100_), .A2(new_n199_), .B(new_n312_), .Y(new_n313_));
  NAND3x1_ASAP7_75t_R  g292(.A(new_n308_), .B(new_n311_), .C(new_n313_), .Y(new_n314_));
  AO21x1_ASAP7_75t_R   g293(.A1(p3), .A2(new_n77_), .B(new_n69_), .Y(new_n315_));
  AOI21x1_ASAP7_75t_R  g294(.A1(new_n306_), .A2(new_n314_), .B(new_n315_), .Y(new_n316_));
  INVx1_ASAP7_75t_R    g295(.A(new_n299_), .Y(new_n317_));
  NOR2x1_ASAP7_75t_R   g296(.A(p0), .B(new_n42_), .Y(new_n318_));
  NAND2x1_ASAP7_75t_R  g297(.A(p7), .B(new_n38_), .Y(new_n319_));
  AO32x1_ASAP7_75t_R   g298(.A1(new_n318_), .A2(new_n319_), .A3(new_n197_), .B1(new_n42_), .B2(new_n51_), .Y(new_n320_));
  AO32x1_ASAP7_75t_R   g299(.A1(new_n184_), .A2(new_n200_), .A3(new_n317_), .B1(new_n320_), .B2(new_n30_), .Y(new_n321_));
  NAND2x1_ASAP7_75t_R  g300(.A(new_n189_), .B(new_n321_), .Y(new_n322_));
  OAI21x1_ASAP7_75t_R  g301(.A1(p6), .A2(new_n316_), .B(new_n322_), .Y(new_n323_));
  AOI21x1_ASAP7_75t_R  g302(.A1(new_n114_), .A2(new_n305_), .B(new_n323_), .Y(o6));
  AND3x1_ASAP7_75t_R   g303(.A(new_n193_), .B(p6), .C(new_n95_), .Y(new_n325_));
  AND3x1_ASAP7_75t_R   g304(.A(new_n196_), .B(new_n43_), .C(new_n197_), .Y(new_n326_));
  OA211x2_ASAP7_75t_R  g305(.A1(new_n325_), .A2(new_n326_), .B(new_n25_), .C(new_n268_), .Y(new_n327_));
  OA21x2_ASAP7_75t_R   g306(.A1(new_n38_), .A2(new_n327_), .B(new_n73_), .Y(new_n328_));
  NAND2x1_ASAP7_75t_R  g307(.A(p7), .B(new_n30_), .Y(new_n329_));
  OAI21x1_ASAP7_75t_R  g308(.A1(new_n103_), .A2(new_n329_), .B(new_n227_), .Y(new_n330_));
  AOI221x1_ASAP7_75t_R g309(.A1(p8), .A2(new_n30_), .B1(new_n121_), .B2(new_n37_), .C(new_n161_), .Y(new_n331_));
  AOI22x1_ASAP7_75t_R  g310(.A1(new_n330_), .A2(p8), .B1(new_n103_), .B2(new_n331_), .Y(new_n332_));
  NOR2x1_ASAP7_75t_R   g311(.A(p5), .B(new_n42_), .Y(new_n333_));
  AO21x1_ASAP7_75t_R   g312(.A1(p2), .A2(new_n197_), .B(new_n193_), .Y(new_n334_));
  AO32x1_ASAP7_75t_R   g313(.A1(new_n199_), .A2(p1), .A3(new_n98_), .B1(new_n70_), .B2(new_n162_), .Y(new_n335_));
  AOI21x1_ASAP7_75t_R  g314(.A1(new_n333_), .A2(new_n334_), .B(new_n335_), .Y(new_n336_));
  OAI21x1_ASAP7_75t_R  g315(.A1(p1), .A2(new_n332_), .B(new_n336_), .Y(new_n337_));
  NOR3x1_ASAP7_75t_R   g316(.A(new_n89_), .B(p1), .C(new_n271_), .Y(new_n338_));
  AOI21x1_ASAP7_75t_R  g317(.A1(new_n197_), .A2(new_n196_), .B(new_n140_), .Y(new_n339_));
  OAI21x1_ASAP7_75t_R  g318(.A1(new_n338_), .A2(new_n339_), .B(new_n149_), .Y(new_n340_));
  NOR3x1_ASAP7_75t_R   g319(.A(p7), .B(p1), .C(p9), .Y(new_n341_));
  AND3x1_ASAP7_75t_R   g320(.A(p7), .B(p9), .C(p5), .Y(new_n342_));
  OA21x2_ASAP7_75t_R   g321(.A1(new_n341_), .A2(new_n342_), .B(new_n32_), .Y(new_n343_));
  OA21x2_ASAP7_75t_R   g322(.A1(p5), .A2(new_n162_), .B(new_n236_), .Y(new_n344_));
  OAI21x1_ASAP7_75t_R  g323(.A1(new_n343_), .A2(new_n344_), .B(new_n23_), .Y(new_n345_));
  OR3x1_ASAP7_75t_R    g324(.A(new_n212_), .B(new_n227_), .C(p8), .Y(new_n346_));
  NAND3x1_ASAP7_75t_R  g325(.A(new_n340_), .B(new_n345_), .C(new_n346_), .Y(new_n347_));
  AOI21x1_ASAP7_75t_R  g326(.A1(p0), .A2(new_n337_), .B(new_n347_), .Y(new_n348_));
  OR3x1_ASAP7_75t_R    g327(.A(new_n96_), .B(new_n95_), .C(new_n176_), .Y(new_n349_));
  OR4x2_ASAP7_75t_R    g328(.A(new_n37_), .B(new_n44_), .C(p8), .D(p9), .Y(new_n350_));
  OR3x1_ASAP7_75t_R    g329(.A(new_n253_), .B(p7), .C(new_n44_), .Y(new_n351_));
  NAND2x1_ASAP7_75t_R  g330(.A(p0), .B(new_n98_), .Y(new_n352_));
  AO31x2_ASAP7_75t_R   g331(.A1(new_n349_), .A2(new_n350_), .A3(new_n351_), .B(new_n352_), .Y(new_n353_));
  AOI211x1_ASAP7_75t_R g332(.A1(p7), .A2(p8), .B(p1), .C(new_n213_), .Y(new_n354_));
  AOI21x1_ASAP7_75t_R  g333(.A1(new_n213_), .A2(new_n33_), .B(new_n296_), .Y(new_n355_));
  OAI21x1_ASAP7_75t_R  g334(.A1(new_n354_), .A2(new_n355_), .B(p0), .Y(new_n356_));
  NAND2x1_ASAP7_75t_R  g335(.A(p9), .B(p2), .Y(new_n357_));
  AOI211x1_ASAP7_75t_R g336(.A1(new_n42_), .A2(new_n357_), .B(p0), .C(new_n44_), .Y(new_n358_));
  AOI22x1_ASAP7_75t_R  g337(.A1(p7), .A2(p8), .B1(p1), .B2(p2), .Y(new_n359_));
  OAI21x1_ASAP7_75t_R  g338(.A1(p7), .A2(p8), .B(new_n359_), .Y(new_n360_));
  AND5x1_ASAP7_75t_R   g339(.A(p7), .B(p1), .C(p8), .D(p4), .E(p2), .Y(new_n361_));
  AOI221x1_ASAP7_75t_R g340(.A1(new_n106_), .A2(new_n157_), .B1(new_n358_), .B2(new_n360_), .C(new_n361_), .Y(new_n362_));
  NAND3x1_ASAP7_75t_R  g341(.A(new_n353_), .B(new_n356_), .C(new_n362_), .Y(new_n363_));
  AOI21x1_ASAP7_75t_R  g342(.A1(new_n84_), .A2(new_n363_), .B(new_n327_), .Y(new_n364_));
  OAI21x1_ASAP7_75t_R  g343(.A1(p4), .A2(new_n348_), .B(new_n364_), .Y(new_n365_));
  OR3x1_ASAP7_75t_R    g344(.A(new_n288_), .B(p4), .C(p6), .Y(new_n366_));
  NOR2x1_ASAP7_75t_R   g345(.A(p5), .B(new_n366_), .Y(new_n367_));
  AOI21x1_ASAP7_75t_R  g346(.A1(new_n328_), .A2(new_n365_), .B(new_n367_), .Y(o7));
  AND3x1_ASAP7_75t_R   g347(.A(new_n213_), .B(p0), .C(p1), .Y(new_n369_));
  OA211x2_ASAP7_75t_R  g348(.A1(p9), .A2(p2), .B(new_n42_), .C(p7), .Y(new_n370_));
  NOR2x1_ASAP7_75t_R   g349(.A(new_n150_), .B(new_n249_), .Y(new_n371_));
  AND3x1_ASAP7_75t_R   g350(.A(new_n31_), .B(p7), .C(new_n56_), .Y(new_n372_));
  AO221x2_ASAP7_75t_R  g351(.A1(new_n174_), .A2(new_n369_), .B1(new_n370_), .B2(new_n371_), .C(new_n372_), .Y(new_n373_));
  OAI21x1_ASAP7_75t_R  g352(.A1(new_n42_), .A2(p4), .B(new_n213_), .Y(new_n374_));
  AND2x2_ASAP7_75t_R   g353(.A(new_n94_), .B(new_n34_), .Y(new_n375_));
  AO32x1_ASAP7_75t_R   g354(.A1(new_n214_), .A2(new_n374_), .A3(p0), .B1(new_n375_), .B2(new_n269_), .Y(new_n376_));
  NOR2x1_ASAP7_75t_R   g355(.A(p5), .B(new_n32_), .Y(new_n377_));
  AOI22x1_ASAP7_75t_R  g356(.A1(new_n373_), .A2(new_n70_), .B1(new_n376_), .B2(new_n377_), .Y(new_n378_));
  OR3x1_ASAP7_75t_R    g357(.A(new_n107_), .B(p1), .C(new_n44_), .Y(new_n379_));
  AO21x1_ASAP7_75t_R   g358(.A1(new_n228_), .A2(new_n379_), .B(p9), .Y(new_n380_));
  NOR2x1_ASAP7_75t_R   g359(.A(p2), .B(new_n32_), .Y(new_n381_));
  OR5x1_ASAP7_75t_R    g360(.A(p1), .B(new_n249_), .C(new_n381_), .D(new_n41_), .E(new_n150_), .Y(new_n382_));
  NAND2x1_ASAP7_75t_R  g361(.A(new_n23_), .B(new_n44_), .Y(new_n383_));
  AO21x1_ASAP7_75t_R   g362(.A1(new_n383_), .A2(new_n61_), .B(new_n246_), .Y(new_n384_));
  AO31x2_ASAP7_75t_R   g363(.A1(new_n380_), .A2(new_n382_), .A3(new_n384_), .B(new_n138_), .Y(new_n385_));
  AO21x1_ASAP7_75t_R   g364(.A1(new_n23_), .A2(new_n196_), .B(new_n30_), .Y(new_n386_));
  NOR2x1_ASAP7_75t_R   g365(.A(p5), .B(new_n111_), .Y(new_n387_));
  NAND2x1_ASAP7_75t_R  g366(.A(new_n28_), .B(new_n329_), .Y(new_n388_));
  AO21x1_ASAP7_75t_R   g367(.A1(new_n206_), .A2(new_n388_), .B(new_n84_), .Y(new_n389_));
  INVx1_ASAP7_75t_R    g368(.A(new_n249_), .Y(new_n390_));
  AO221x2_ASAP7_75t_R  g369(.A1(new_n386_), .A2(new_n387_), .B1(new_n389_), .B2(new_n42_), .C(new_n390_), .Y(new_n391_));
  NAND3x1_ASAP7_75t_R  g370(.A(new_n378_), .B(new_n385_), .C(new_n391_), .Y(new_n392_));
  AND3x1_ASAP7_75t_R   g371(.A(new_n60_), .B(new_n30_), .C(new_n64_), .Y(new_n393_));
  OA211x2_ASAP7_75t_R  g372(.A1(new_n64_), .A2(new_n125_), .B(new_n32_), .C(new_n30_), .Y(new_n394_));
  AO32x1_ASAP7_75t_R   g373(.A1(new_n37_), .A2(new_n30_), .A3(new_n96_), .B1(new_n177_), .B2(new_n32_), .Y(new_n395_));
  OA21x2_ASAP7_75t_R   g374(.A1(new_n394_), .A2(new_n395_), .B(new_n23_), .Y(new_n396_));
  OAI21x1_ASAP7_75t_R  g375(.A1(new_n393_), .A2(new_n396_), .B(new_n189_), .Y(new_n397_));
  NAND2x1_ASAP7_75t_R  g376(.A(new_n366_), .B(new_n397_), .Y(new_n398_));
  AOI21x1_ASAP7_75t_R  g377(.A1(new_n114_), .A2(new_n392_), .B(new_n398_), .Y(o8));
  AO21x1_ASAP7_75t_R   g378(.A1(p7), .A2(p8), .B(p4), .Y(new_n400_));
  AND2x2_ASAP7_75t_R   g379(.A(p2), .B(new_n121_), .Y(new_n401_));
  OAI21x1_ASAP7_75t_R  g380(.A1(new_n329_), .A2(new_n261_), .B(new_n401_), .Y(new_n402_));
  OA21x2_ASAP7_75t_R   g381(.A1(new_n268_), .A2(new_n281_), .B(new_n42_), .Y(new_n403_));
  AO32x1_ASAP7_75t_R   g382(.A1(new_n98_), .A2(new_n236_), .A3(new_n400_), .B1(new_n402_), .B2(new_n403_), .Y(new_n404_));
  NAND2x1_ASAP7_75t_R  g383(.A(new_n23_), .B(new_n404_), .Y(new_n405_));
  OA21x2_ASAP7_75t_R   g384(.A1(p2), .A2(new_n49_), .B(new_n329_), .Y(new_n406_));
  OR3x1_ASAP7_75t_R    g385(.A(new_n406_), .B(p1), .C(new_n401_), .Y(new_n407_));
  OR3x1_ASAP7_75t_R    g386(.A(new_n42_), .B(new_n98_), .C(p5), .Y(new_n408_));
  OR3x1_ASAP7_75t_R    g387(.A(new_n261_), .B(p2), .C(new_n137_), .Y(new_n409_));
  OA21x2_ASAP7_75t_R   g388(.A1(new_n400_), .A2(new_n408_), .B(new_n409_), .Y(new_n410_));
  AO21x1_ASAP7_75t_R   g389(.A1(new_n407_), .A2(new_n410_), .B(new_n23_), .Y(new_n411_));
  AO21x1_ASAP7_75t_R   g390(.A1(new_n38_), .A2(new_n178_), .B(new_n299_), .Y(new_n412_));
  AO21x1_ASAP7_75t_R   g391(.A1(new_n38_), .A2(new_n408_), .B(new_n412_), .Y(new_n413_));
  OA21x2_ASAP7_75t_R   g392(.A1(new_n24_), .A2(new_n155_), .B(new_n234_), .Y(new_n414_));
  AO21x1_ASAP7_75t_R   g393(.A1(new_n44_), .A2(new_n246_), .B(new_n84_), .Y(new_n415_));
  OA21x2_ASAP7_75t_R   g394(.A1(new_n38_), .A2(new_n110_), .B(new_n415_), .Y(new_n416_));
  AND5x1_ASAP7_75t_R   g395(.A(new_n405_), .B(new_n411_), .C(new_n413_), .D(new_n414_), .E(new_n416_), .Y(o9));
  OR3x1_ASAP7_75t_R    g396(.A(new_n186_), .B(new_n55_), .C(new_n282_), .Y(new_n418_));
  AO21x1_ASAP7_75t_R   g397(.A1(p7), .A2(new_n80_), .B(new_n418_), .Y(new_n419_));
  OR3x1_ASAP7_75t_R    g398(.A(p4), .B(p6), .C(p5), .Y(new_n420_));
  AOI21x1_ASAP7_75t_R  g399(.A1(new_n288_), .A2(new_n419_), .B(new_n420_), .Y(o10));
endmodule


