// Benchmark "/tmp/" written by ABC on Wed Oct 21 14:26:16 2026

module \/tmp/  ( 
    p6, p5, p9, p1, p2, p0, p4, p8, p3, p7,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10  );
  input  p6, p5, p9, p1, p2, p0, p4, p8, p3, p7;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10;
  wire new_n22_, new_n23_, new_n24_, new_n25_, new_n26_, new_n27_, new_n28_,
    new_n29_, new_n30_, new_n31_, new_n32_, new_n33_, new_n34_, new_n35_,
    new_n36_, new_n37_, new_n38_, new_n39_, new_n40_, new_n41_, new_n42_,
    new_n43_, new_n44_, new_n45_, new_n46_, new_n47_, new_n48_, new_n49_,
    new_n50_, new_n51_, new_n52_, new_n53_, new_n54_, new_n55_, new_n56_,
    new_n57_, new_n58_, new_n59_, new_n60_, new_n61_, new_n62_, new_n63_,
    new_n64_, new_n65_, new_n66_, new_n67_, new_n68_, new_n69_, new_n70_,
    new_n71_, new_n72_, new_n73_, new_n74_, new_n75_, new_n76_, new_n77_,
    new_n78_, new_n79_, new_n80_, new_n81_, new_n82_, new_n83_, new_n84_,
    new_n85_, new_n86_, new_n87_, new_n88_, new_n89_, new_n90_, new_n91_,
    new_n92_, new_n93_, new_n94_, new_n95_, new_n96_, new_n97_, new_n98_,
    new_n99_, new_n100_, new_n101_, new_n102_, new_n103_, new_n104_,
    new_n105_, new_n106_, new_n107_, new_n108_, new_n109_, new_n110_,
    new_n111_, new_n112_, new_n113_, new_n114_, new_n115_, new_n116_,
    new_n118_, new_n119_, new_n120_, new_n121_, new_n122_, new_n123_,
    new_n124_, new_n125_, new_n126_, new_n127_, new_n128_, new_n129_,
    new_n130_, new_n131_, new_n132_, new_n133_, new_n134_, new_n135_,
    new_n136_, new_n137_, new_n138_, new_n139_, new_n140_, new_n141_,
    new_n142_, new_n143_, new_n144_, new_n145_, new_n146_, new_n147_,
    new_n148_, new_n149_, new_n150_, new_n151_, new_n152_, new_n153_,
    new_n154_, new_n155_, new_n156_, new_n157_, new_n158_, new_n159_,
    new_n160_, new_n161_, new_n162_, new_n163_, new_n164_, new_n165_,
    new_n166_, new_n167_, new_n168_, new_n169_, new_n170_, new_n171_,
    new_n172_, new_n173_, new_n174_, new_n175_, new_n176_, new_n177_,
    new_n178_, new_n179_, new_n180_, new_n181_, new_n182_, new_n183_,
    new_n184_, new_n185_, new_n186_, new_n187_, new_n188_, new_n189_,
    new_n190_, new_n192_, new_n193_, new_n194_, new_n195_, new_n196_,
    new_n197_, new_n198_, new_n199_, new_n200_, new_n201_, new_n202_,
    new_n203_, new_n204_, new_n205_, new_n206_, new_n207_, new_n208_,
    new_n209_, new_n210_, new_n211_, new_n212_, new_n213_, new_n214_,
    new_n215_, new_n216_, new_n217_, new_n218_, new_n219_, new_n220_,
    new_n221_, new_n222_, new_n223_, new_n224_, new_n225_, new_n226_,
    new_n227_, new_n228_, new_n229_, new_n230_, new_n231_, new_n232_,
    new_n233_, new_n234_, new_n235_, new_n236_, new_n237_, new_n238_,
    new_n239_, new_n240_, new_n241_, new_n242_, new_n244_, new_n245_,
    new_n246_, new_n247_, new_n248_, new_n249_, new_n250_, new_n251_,
    new_n252_, new_n253_, new_n254_, new_n255_, new_n256_, new_n257_,
    new_n258_, new_n259_, new_n260_, new_n261_, new_n262_, new_n263_,
    new_n264_, new_n265_, new_n266_, new_n267_, new_n268_, new_n269_,
    new_n270_, new_n271_, new_n272_, new_n273_, new_n274_, new_n275_,
    new_n277_, new_n278_, new_n279_, new_n280_, new_n281_, new_n282_,
    new_n284_, new_n285_, new_n287_, new_n288_, new_n289_, new_n290_,
    new_n291_, new_n292_, new_n293_, new_n294_, new_n295_, new_n296_,
    new_n297_, new_n298_, new_n299_, new_n300_, new_n301_, new_n302_,
    new_n303_, new_n304_, new_n305_, new_n306_, new_n307_, new_n308_,
    new_n309_, new_n310_, new_n311_, new_n312_, new_n313_, new_n314_,
    new_n315_, new_n316_, new_n317_, new_n318_, new_n319_, new_n320_,
    new_n321_, new_n322_, new_n324_, new_n325_, new_n326_, new_n327_,
    new_n328_, new_n329_, new_n330_, new_n331_, new_n332_, new_n333_,
    new_n334_, new_n335_, new_n336_, new_n337_, new_n338_, new_n339_,
    new_n340_, new_n341_, new_n342_, new_n343_, new_n344_, new_n345_,
    new_n346_, new_n347_, new_n348_, new_n349_, new_n350_, new_n351_,
    new_n352_, new_n353_, new_n354_, new_n355_, new_n356_, new_n357_,
    new_n358_, new_n359_, new_n360_, new_n361_, new_n362_, new_n363_,
    new_n364_, new_n365_, new_n367_, new_n368_, new_n369_, new_n370_,
    new_n371_, new_n372_, new_n373_, new_n374_, new_n375_, new_n376_,
    new_n377_, new_n378_, new_n379_, new_n380_, new_n381_, new_n382_,
    new_n383_, new_n384_, new_n385_, new_n386_, new_n387_, new_n388_,
    new_n389_, new_n390_, new_n391_, new_n392_, new_n393_, new_n394_,
    new_n395_, new_n396_, new_n397_, new_n399_, new_n400_, new_n401_,
    new_n402_, new_n403_, new_n404_, new_n405_, new_n406_, new_n407_,
    new_n408_, new_n409_, new_n410_, new_n411_, new_n412_, new_n413_,
    new_n414_, new_n415_, new_n416_, new_n417_, new_n419_, new_n420_,
    new_n421_;
  NOR2x1_ASAP7_75t_R   g000(.A(p5), .B(p3), .Y(new_n22_));
  INVx1_ASAP7_75t_R    g001(.A(p4), .Y(new_n23_));
  NAND2x1_ASAP7_75t_R  g002(.A(p7), .B(new_n23_), .Y(new_n24_));
  NOR2x1_ASAP7_75t_R   g003(.A(p4), .B(p8), .Y(new_n25_));
  INVx1_ASAP7_75t_R    g004(.A(new_n25_), .Y(new_n26_));
  INVx1_ASAP7_75t_R    g005(.A(p1), .Y(new_n27_));
  NAND2x1_ASAP7_75t_R  g006(.A(p9), .B(new_n27_), .Y(new_n28_));
  AO21x1_ASAP7_75t_R   g007(.A1(p6), .A2(new_n26_), .B(new_n28_), .Y(new_n29_));
  INVx1_ASAP7_75t_R    g008(.A(p6), .Y(new_n30_));
  INVx1_ASAP7_75t_R    g009(.A(p0), .Y(new_n31_));
  NOR2x1_ASAP7_75t_R   g010(.A(p8), .B(new_n31_), .Y(new_n32_));
  AO21x1_ASAP7_75t_R   g011(.A1(new_n30_), .A2(new_n32_), .B(p2), .Y(new_n33_));
  AOI21x1_ASAP7_75t_R  g012(.A1(new_n24_), .A2(new_n29_), .B(new_n33_), .Y(new_n34_));
  NOR2x1_ASAP7_75t_R   g013(.A(p0), .B(p8), .Y(new_n35_));
  NOR2x1_ASAP7_75t_R   g014(.A(p9), .B(new_n27_), .Y(new_n36_));
  NAND2x1_ASAP7_75t_R  g015(.A(new_n35_), .B(new_n36_), .Y(new_n37_));
  AO21x1_ASAP7_75t_R   g016(.A1(new_n31_), .A2(new_n26_), .B(new_n28_), .Y(new_n38_));
  OAI21x1_ASAP7_75t_R  g017(.A1(new_n30_), .A2(new_n37_), .B(new_n38_), .Y(new_n39_));
  NAND2x1_ASAP7_75t_R  g018(.A(p9), .B(p0), .Y(new_n40_));
  INVx1_ASAP7_75t_R    g019(.A(p8), .Y(new_n41_));
  NAND2x1_ASAP7_75t_R  g020(.A(p0), .B(new_n41_), .Y(new_n42_));
  NAND2x1_ASAP7_75t_R  g021(.A(new_n40_), .B(new_n42_), .Y(new_n43_));
  NOR2x1_ASAP7_75t_R   g022(.A(p2), .B(p4), .Y(new_n44_));
  NAND2x1_ASAP7_75t_R  g023(.A(p8), .B(new_n31_), .Y(new_n45_));
  NAND2x1_ASAP7_75t_R  g024(.A(new_n44_), .B(new_n45_), .Y(new_n46_));
  AND2x2_ASAP7_75t_R   g025(.A(p0), .B(p8), .Y(new_n47_));
  NOR2x1_ASAP7_75t_R   g026(.A(new_n35_), .B(new_n47_), .Y(new_n48_));
  INVx1_ASAP7_75t_R    g027(.A(p9), .Y(new_n49_));
  AO21x1_ASAP7_75t_R   g028(.A1(new_n49_), .A2(new_n31_), .B(p6), .Y(new_n50_));
  OAI22x1_ASAP7_75t_R  g029(.A1(new_n43_), .A2(new_n46_), .B1(new_n48_), .B2(new_n50_), .Y(new_n51_));
  NOR2x1_ASAP7_75t_R   g030(.A(p1), .B(p7), .Y(new_n52_));
  AOI22x1_ASAP7_75t_R  g031(.A1(new_n34_), .A2(new_n39_), .B1(new_n51_), .B2(new_n52_), .Y(new_n53_));
  NAND2x1_ASAP7_75t_R  g032(.A(p1), .B(p0), .Y(new_n54_));
  AO21x1_ASAP7_75t_R   g033(.A1(new_n27_), .A2(new_n23_), .B(p9), .Y(new_n55_));
  AO21x1_ASAP7_75t_R   g034(.A1(new_n54_), .A2(new_n55_), .B(p8), .Y(new_n56_));
  INVx1_ASAP7_75t_R    g035(.A(p2), .Y(new_n57_));
  NAND2x1_ASAP7_75t_R  g036(.A(p9), .B(new_n31_), .Y(new_n58_));
  NOR2x1_ASAP7_75t_R   g037(.A(p1), .B(p2), .Y(new_n59_));
  OR3x1_ASAP7_75t_R    g038(.A(new_n59_), .B(p0), .C(new_n41_), .Y(new_n60_));
  NAND2x1_ASAP7_75t_R  g039(.A(p0), .B(new_n57_), .Y(new_n61_));
  OA211x2_ASAP7_75t_R  g040(.A1(new_n57_), .A2(new_n58_), .B(new_n60_), .C(new_n61_), .Y(new_n62_));
  INVx1_ASAP7_75t_R    g041(.A(p7), .Y(new_n63_));
  NAND2x1_ASAP7_75t_R  g042(.A(new_n30_), .B(new_n63_), .Y(new_n64_));
  AO21x1_ASAP7_75t_R   g043(.A1(new_n56_), .A2(new_n62_), .B(new_n64_), .Y(new_n65_));
  NAND2x1_ASAP7_75t_R  g044(.A(new_n53_), .B(new_n65_), .Y(new_n66_));
  NAND2x1_ASAP7_75t_R  g045(.A(p5), .B(p4), .Y(new_n67_));
  INVx1_ASAP7_75t_R    g046(.A(new_n67_), .Y(new_n68_));
  NOR2x1_ASAP7_75t_R   g047(.A(p7), .B(new_n23_), .Y(new_n69_));
  NOR2x1_ASAP7_75t_R   g048(.A(p5), .B(p8), .Y(new_n70_));
  AND2x2_ASAP7_75t_R   g049(.A(p3), .B(p7), .Y(new_n71_));
  OAI22x1_ASAP7_75t_R  g050(.A1(new_n68_), .A2(new_n69_), .B1(new_n70_), .B2(new_n71_), .Y(new_n72_));
  INVx1_ASAP7_75t_R    g051(.A(p3), .Y(new_n73_));
  AO21x1_ASAP7_75t_R   g052(.A1(p8), .A2(new_n73_), .B(new_n70_), .Y(new_n74_));
  OR3x1_ASAP7_75t_R    g053(.A(new_n74_), .B(p7), .C(new_n68_), .Y(new_n75_));
  NOR2x1_ASAP7_75t_R   g054(.A(p9), .B(p0), .Y(new_n76_));
  NAND2x1_ASAP7_75t_R  g055(.A(new_n59_), .B(new_n76_), .Y(new_n77_));
  AOI211x1_ASAP7_75t_R g056(.A1(new_n72_), .A2(new_n75_), .B(p6), .C(new_n77_), .Y(new_n78_));
  AOI21x1_ASAP7_75t_R  g057(.A1(new_n22_), .A2(new_n66_), .B(new_n78_), .Y(new_n79_));
  NAND2x1_ASAP7_75t_R  g058(.A(p5), .B(p2), .Y(new_n80_));
  NAND2x1_ASAP7_75t_R  g059(.A(new_n49_), .B(new_n27_), .Y(new_n81_));
  OA21x2_ASAP7_75t_R   g060(.A1(new_n45_), .A2(new_n81_), .B(new_n23_), .Y(new_n82_));
  NOR2x1_ASAP7_75t_R   g061(.A(p8), .B(new_n49_), .Y(new_n83_));
  NOR2x1_ASAP7_75t_R   g062(.A(p9), .B(new_n41_), .Y(new_n84_));
  NAND2x1_ASAP7_75t_R  g063(.A(p2), .B(p4), .Y(new_n85_));
  OR4x2_ASAP7_75t_R    g064(.A(new_n83_), .B(new_n84_), .C(new_n54_), .D(new_n85_), .Y(new_n86_));
  OA21x2_ASAP7_75t_R   g065(.A1(new_n80_), .A2(new_n82_), .B(new_n86_), .Y(new_n87_));
  INVx1_ASAP7_75t_R    g066(.A(p5), .Y(new_n88_));
  AO21x1_ASAP7_75t_R   g067(.A1(p9), .A2(new_n41_), .B(p1), .Y(new_n89_));
  AOI21x1_ASAP7_75t_R  g068(.A1(new_n88_), .A2(new_n89_), .B(new_n23_), .Y(new_n90_));
  AO21x1_ASAP7_75t_R   g069(.A1(new_n57_), .A2(new_n43_), .B(new_n89_), .Y(new_n91_));
  AND2x2_ASAP7_75t_R   g070(.A(p1), .B(p8), .Y(new_n92_));
  AND3x1_ASAP7_75t_R   g071(.A(new_n27_), .B(new_n41_), .C(p0), .Y(new_n93_));
  NOR2x1_ASAP7_75t_R   g072(.A(p9), .B(p2), .Y(new_n94_));
  OA211x2_ASAP7_75t_R  g073(.A1(new_n92_), .A2(new_n93_), .B(p5), .C(new_n94_), .Y(new_n95_));
  AOI21x1_ASAP7_75t_R  g074(.A1(new_n90_), .A2(new_n91_), .B(new_n95_), .Y(new_n96_));
  AO21x1_ASAP7_75t_R   g075(.A1(new_n87_), .A2(new_n96_), .B(new_n63_), .Y(new_n97_));
  NAND2x1_ASAP7_75t_R  g076(.A(p2), .B(new_n88_), .Y(new_n98_));
  NAND2x1_ASAP7_75t_R  g077(.A(p1), .B(p2), .Y(new_n99_));
  AO32x1_ASAP7_75t_R   g078(.A1(new_n98_), .A2(new_n35_), .A3(new_n99_), .B1(p1), .B2(p8), .Y(new_n100_));
  INVx1_ASAP7_75t_R    g079(.A(new_n35_), .Y(new_n101_));
  NOR2x1_ASAP7_75t_R   g080(.A(p7), .B(new_n57_), .Y(new_n102_));
  NOR2x1_ASAP7_75t_R   g081(.A(p7), .B(new_n31_), .Y(new_n103_));
  AO32x1_ASAP7_75t_R   g082(.A1(new_n101_), .A2(new_n102_), .A3(new_n58_), .B1(new_n49_), .B2(new_n103_), .Y(new_n104_));
  NOR2x1_ASAP7_75t_R   g083(.A(p0), .B(new_n41_), .Y(new_n105_));
  NOR2x1_ASAP7_75t_R   g084(.A(p2), .B(new_n27_), .Y(new_n106_));
  AND3x1_ASAP7_75t_R   g085(.A(new_n31_), .B(p9), .C(p2), .Y(new_n107_));
  NOR2x1_ASAP7_75t_R   g086(.A(p8), .B(new_n27_), .Y(new_n108_));
  AO32x1_ASAP7_75t_R   g087(.A1(new_n49_), .A2(new_n105_), .A3(new_n106_), .B1(new_n107_), .B2(new_n108_), .Y(new_n109_));
  AOI211x1_ASAP7_75t_R g088(.A1(new_n63_), .A2(new_n100_), .B(new_n104_), .C(new_n109_), .Y(new_n110_));
  NOR2x1_ASAP7_75t_R   g089(.A(p8), .B(p7), .Y(new_n111_));
  INVx1_ASAP7_75t_R    g090(.A(new_n111_), .Y(new_n112_));
  OA22x2_ASAP7_75t_R   g091(.A1(new_n110_), .A2(p4), .B1(new_n112_), .B2(new_n77_), .Y(new_n113_));
  NOR2x1_ASAP7_75t_R   g092(.A(p6), .B(p3), .Y(new_n114_));
  INVx1_ASAP7_75t_R    g093(.A(new_n114_), .Y(new_n115_));
  AO21x1_ASAP7_75t_R   g094(.A1(new_n97_), .A2(new_n113_), .B(new_n115_), .Y(new_n116_));
  NAND2x1_ASAP7_75t_R  g095(.A(new_n79_), .B(new_n116_), .Y(o0));
  NAND2x1_ASAP7_75t_R  g096(.A(new_n30_), .B(new_n57_), .Y(new_n118_));
  NAND2x1_ASAP7_75t_R  g097(.A(p5), .B(p8), .Y(new_n119_));
  AND2x2_ASAP7_75t_R   g098(.A(new_n119_), .B(new_n24_), .Y(new_n120_));
  AO21x1_ASAP7_75t_R   g099(.A1(p5), .A2(p7), .B(new_n28_), .Y(new_n121_));
  INVx1_ASAP7_75t_R    g100(.A(new_n52_), .Y(new_n122_));
  NAND2x1_ASAP7_75t_R  g101(.A(p4), .B(p8), .Y(new_n123_));
  OR3x1_ASAP7_75t_R    g102(.A(new_n122_), .B(p9), .C(new_n123_), .Y(new_n124_));
  OAI21x1_ASAP7_75t_R  g103(.A1(new_n120_), .A2(new_n121_), .B(new_n124_), .Y(new_n125_));
  OR3x1_ASAP7_75t_R    g104(.A(new_n27_), .B(new_n63_), .C(p4), .Y(new_n126_));
  NOR2x1_ASAP7_75t_R   g105(.A(p9), .B(new_n63_), .Y(new_n127_));
  NOR2x1_ASAP7_75t_R   g106(.A(p4), .B(new_n88_), .Y(new_n128_));
  NOR2x1_ASAP7_75t_R   g107(.A(p5), .B(p7), .Y(new_n129_));
  AOI21x1_ASAP7_75t_R  g108(.A1(new_n127_), .A2(new_n128_), .B(new_n129_), .Y(new_n130_));
  NAND2x1_ASAP7_75t_R  g109(.A(new_n126_), .B(new_n130_), .Y(new_n131_));
  AOI22x1_ASAP7_75t_R  g110(.A1(new_n125_), .A2(p0), .B1(new_n32_), .B2(new_n131_), .Y(new_n132_));
  NOR2x1_ASAP7_75t_R   g111(.A(p1), .B(new_n23_), .Y(new_n133_));
  AND2x2_ASAP7_75t_R   g112(.A(p1), .B(p4), .Y(new_n134_));
  AND3x1_ASAP7_75t_R   g113(.A(p9), .B(p8), .C(p7), .Y(new_n135_));
  AO32x1_ASAP7_75t_R   g114(.A1(new_n133_), .A2(new_n49_), .A3(new_n111_), .B1(new_n134_), .B2(new_n135_), .Y(new_n136_));
  NAND2x1_ASAP7_75t_R  g115(.A(p1), .B(p7), .Y(new_n137_));
  INVx1_ASAP7_75t_R    g116(.A(new_n137_), .Y(new_n138_));
  AOI22x1_ASAP7_75t_R  g117(.A1(new_n136_), .A2(new_n31_), .B1(new_n70_), .B2(new_n138_), .Y(new_n139_));
  AND2x2_ASAP7_75t_R   g118(.A(p8), .B(p7), .Y(new_n140_));
  AND3x1_ASAP7_75t_R   g119(.A(new_n23_), .B(new_n41_), .C(new_n63_), .Y(new_n141_));
  AO21x1_ASAP7_75t_R   g120(.A1(p5), .A2(new_n140_), .B(new_n141_), .Y(new_n142_));
  NOR2x1_ASAP7_75t_R   g121(.A(p9), .B(new_n120_), .Y(new_n143_));
  NOR2x1_ASAP7_75t_R   g122(.A(p0), .B(new_n27_), .Y(new_n144_));
  OAI21x1_ASAP7_75t_R  g123(.A1(new_n142_), .A2(new_n143_), .B(new_n144_), .Y(new_n145_));
  NAND3x1_ASAP7_75t_R  g124(.A(new_n132_), .B(new_n139_), .C(new_n145_), .Y(new_n146_));
  INVx1_ASAP7_75t_R    g125(.A(new_n119_), .Y(new_n147_));
  OA21x2_ASAP7_75t_R   g126(.A1(new_n71_), .A2(new_n69_), .B(new_n70_), .Y(new_n148_));
  AO21x1_ASAP7_75t_R   g127(.A1(p3), .A2(new_n147_), .B(new_n148_), .Y(new_n149_));
  AND3x1_ASAP7_75t_R   g128(.A(new_n49_), .B(new_n27_), .C(new_n31_), .Y(new_n150_));
  AOI22x1_ASAP7_75t_R  g129(.A1(new_n146_), .A2(new_n73_), .B1(new_n149_), .B2(new_n150_), .Y(new_n151_));
  NAND2x1_ASAP7_75t_R  g130(.A(new_n57_), .B(new_n63_), .Y(new_n152_));
  AND3x1_ASAP7_75t_R   g131(.A(new_n152_), .B(new_n24_), .C(p9), .Y(new_n153_));
  AND3x1_ASAP7_75t_R   g132(.A(new_n52_), .B(new_n31_), .C(p4), .Y(new_n154_));
  AOI21x1_ASAP7_75t_R  g133(.A1(new_n31_), .A2(new_n153_), .B(new_n154_), .Y(new_n155_));
  NAND2x1_ASAP7_75t_R  g134(.A(p9), .B(p7), .Y(new_n156_));
  NOR2x1_ASAP7_75t_R   g135(.A(p1), .B(new_n156_), .Y(new_n157_));
  INVx1_ASAP7_75t_R    g136(.A(new_n157_), .Y(new_n158_));
  OR3x1_ASAP7_75t_R    g137(.A(new_n59_), .B(new_n52_), .C(p9), .Y(new_n159_));
  OA21x2_ASAP7_75t_R   g138(.A1(new_n31_), .A2(new_n158_), .B(new_n159_), .Y(new_n160_));
  NAND2x1_ASAP7_75t_R  g139(.A(p4), .B(new_n49_), .Y(new_n161_));
  NAND2x1_ASAP7_75t_R  g140(.A(p9), .B(new_n23_), .Y(new_n162_));
  AO21x1_ASAP7_75t_R   g141(.A1(new_n161_), .A2(new_n162_), .B(new_n31_), .Y(new_n163_));
  AO31x2_ASAP7_75t_R   g142(.A1(new_n155_), .A2(new_n160_), .A3(new_n163_), .B(p5), .Y(new_n164_));
  NAND2x1_ASAP7_75t_R  g143(.A(p2), .B(new_n27_), .Y(new_n165_));
  OA21x2_ASAP7_75t_R   g144(.A1(p0), .A2(new_n80_), .B(new_n165_), .Y(new_n166_));
  NOR2x1_ASAP7_75t_R   g145(.A(p0), .B(p7), .Y(new_n167_));
  OR3x1_ASAP7_75t_R    g146(.A(new_n166_), .B(p4), .C(new_n167_), .Y(new_n168_));
  INVx1_ASAP7_75t_R    g147(.A(new_n40_), .Y(new_n169_));
  NOR2x1_ASAP7_75t_R   g148(.A(p5), .B(p0), .Y(new_n170_));
  OR5x1_ASAP7_75t_R    g149(.A(p1), .B(new_n169_), .C(new_n127_), .D(p4), .E(new_n170_), .Y(new_n171_));
  AND3x1_ASAP7_75t_R   g150(.A(new_n168_), .B(new_n41_), .C(new_n171_), .Y(new_n172_));
  AO32x1_ASAP7_75t_R   g151(.A1(new_n167_), .A2(new_n27_), .A3(p2), .B1(p0), .B2(p4), .Y(new_n173_));
  AND2x2_ASAP7_75t_R   g152(.A(p5), .B(p9), .Y(new_n174_));
  AND2x2_ASAP7_75t_R   g153(.A(p1), .B(p0), .Y(new_n175_));
  INVx1_ASAP7_75t_R    g154(.A(new_n80_), .Y(new_n176_));
  AO21x1_ASAP7_75t_R   g155(.A1(new_n175_), .A2(new_n176_), .B(new_n68_), .Y(new_n177_));
  INVx1_ASAP7_75t_R    g156(.A(new_n59_), .Y(new_n178_));
  AND3x1_ASAP7_75t_R   g157(.A(p1), .B(p0), .C(p4), .Y(new_n179_));
  AO21x1_ASAP7_75t_R   g158(.A1(new_n179_), .A2(new_n102_), .B(new_n41_), .Y(new_n180_));
  AOI221x1_ASAP7_75t_R g159(.A1(new_n173_), .A2(new_n174_), .B1(new_n177_), .B2(new_n178_), .C(new_n180_), .Y(new_n181_));
  AOI21x1_ASAP7_75t_R  g160(.A1(new_n164_), .A2(new_n172_), .B(new_n181_), .Y(new_n182_));
  NAND2x1_ASAP7_75t_R  g161(.A(new_n44_), .B(new_n22_), .Y(new_n183_));
  OA211x2_ASAP7_75t_R  g162(.A1(new_n27_), .A2(new_n76_), .B(new_n63_), .C(p6), .Y(new_n184_));
  OAI21x1_ASAP7_75t_R  g163(.A1(new_n89_), .A2(new_n169_), .B(new_n184_), .Y(new_n185_));
  NAND2x1_ASAP7_75t_R  g164(.A(p7), .B(new_n27_), .Y(new_n186_));
  OR3x1_ASAP7_75t_R    g165(.A(new_n42_), .B(new_n186_), .C(new_n30_), .Y(new_n187_));
  AND3x1_ASAP7_75t_R   g166(.A(new_n185_), .B(new_n37_), .C(new_n187_), .Y(new_n188_));
  NOR2x1_ASAP7_75t_R   g167(.A(new_n183_), .B(new_n188_), .Y(new_n189_));
  AOI21x1_ASAP7_75t_R  g168(.A1(new_n114_), .A2(new_n182_), .B(new_n189_), .Y(new_n190_));
  OAI21x1_ASAP7_75t_R  g169(.A1(new_n118_), .A2(new_n151_), .B(new_n190_), .Y(o1));
  NAND2x1_ASAP7_75t_R  g170(.A(p8), .B(p7), .Y(new_n192_));
  NAND2x1_ASAP7_75t_R  g171(.A(p1), .B(p8), .Y(new_n193_));
  NAND2x1_ASAP7_75t_R  g172(.A(new_n193_), .B(new_n137_), .Y(new_n194_));
  AO21x1_ASAP7_75t_R   g173(.A1(new_n192_), .A2(new_n194_), .B(new_n52_), .Y(new_n195_));
  AOI22x1_ASAP7_75t_R  g174(.A1(new_n47_), .A2(p1), .B1(new_n31_), .B2(p7), .Y(new_n196_));
  OA22x2_ASAP7_75t_R   g175(.A1(new_n195_), .A2(new_n57_), .B1(new_n80_), .B2(new_n196_), .Y(new_n197_));
  AO21x1_ASAP7_75t_R   g176(.A1(p8), .A2(new_n31_), .B(new_n88_), .Y(new_n198_));
  AO21x1_ASAP7_75t_R   g177(.A1(new_n42_), .A2(new_n198_), .B(new_n63_), .Y(new_n199_));
  OR3x1_ASAP7_75t_R    g178(.A(new_n48_), .B(p2), .C(p7), .Y(new_n200_));
  AO21x1_ASAP7_75t_R   g179(.A1(new_n199_), .A2(new_n200_), .B(p1), .Y(new_n201_));
  AO21x1_ASAP7_75t_R   g180(.A1(new_n197_), .A2(new_n201_), .B(new_n162_), .Y(new_n202_));
  OA21x2_ASAP7_75t_R   g181(.A1(new_n57_), .A2(new_n58_), .B(new_n162_), .Y(new_n203_));
  OR3x1_ASAP7_75t_R    g182(.A(p1), .B(p8), .C(p7), .Y(new_n204_));
  OA22x2_ASAP7_75t_R   g183(.A1(new_n203_), .A2(new_n204_), .B1(new_n60_), .B2(new_n156_), .Y(new_n205_));
  NAND2x1_ASAP7_75t_R  g184(.A(p1), .B(new_n192_), .Y(new_n206_));
  AO21x1_ASAP7_75t_R   g185(.A1(new_n101_), .A2(new_n111_), .B(new_n206_), .Y(new_n207_));
  NOR2x1_ASAP7_75t_R   g186(.A(new_n111_), .B(new_n135_), .Y(new_n208_));
  AO21x1_ASAP7_75t_R   g187(.A1(new_n23_), .A2(new_n193_), .B(new_n31_), .Y(new_n209_));
  AO21x1_ASAP7_75t_R   g188(.A1(p4), .A2(new_n208_), .B(new_n209_), .Y(new_n210_));
  AO21x1_ASAP7_75t_R   g189(.A1(new_n207_), .A2(new_n210_), .B(p2), .Y(new_n211_));
  AO21x1_ASAP7_75t_R   g190(.A1(new_n205_), .A2(new_n211_), .B(p5), .Y(new_n212_));
  AO21x1_ASAP7_75t_R   g191(.A1(new_n202_), .A2(new_n212_), .B(p3), .Y(new_n213_));
  NOR2x1_ASAP7_75t_R   g192(.A(p7), .B(new_n88_), .Y(new_n214_));
  OA21x2_ASAP7_75t_R   g193(.A1(new_n140_), .A2(new_n214_), .B(new_n23_), .Y(new_n215_));
  AO21x1_ASAP7_75t_R   g194(.A1(new_n31_), .A2(new_n59_), .B(new_n73_), .Y(new_n216_));
  NAND2x1_ASAP7_75t_R  g195(.A(new_n49_), .B(new_n216_), .Y(new_n217_));
  AO21x1_ASAP7_75t_R   g196(.A1(p3), .A2(new_n215_), .B(new_n217_), .Y(new_n218_));
  AO21x1_ASAP7_75t_R   g197(.A1(p2), .A2(new_n186_), .B(new_n23_), .Y(new_n219_));
  INVx1_ASAP7_75t_R    g198(.A(new_n85_), .Y(new_n220_));
  NOR2x1_ASAP7_75t_R   g199(.A(p1), .B(new_n57_), .Y(new_n221_));
  OR3x1_ASAP7_75t_R    g200(.A(new_n220_), .B(new_n221_), .C(new_n63_), .Y(new_n222_));
  AO21x1_ASAP7_75t_R   g201(.A1(new_n219_), .A2(new_n222_), .B(new_n42_), .Y(new_n223_));
  NAND2x1_ASAP7_75t_R  g202(.A(p2), .B(new_n63_), .Y(new_n224_));
  AO21x1_ASAP7_75t_R   g203(.A1(p2), .A2(new_n41_), .B(p5), .Y(new_n225_));
  AO21x1_ASAP7_75t_R   g204(.A1(new_n42_), .A2(new_n224_), .B(new_n225_), .Y(new_n226_));
  AND2x2_ASAP7_75t_R   g205(.A(new_n73_), .B(new_n226_), .Y(new_n227_));
  NAND2x1_ASAP7_75t_R  g206(.A(new_n105_), .B(new_n102_), .Y(new_n228_));
  AO221x2_ASAP7_75t_R  g207(.A1(p7), .A2(new_n32_), .B1(new_n228_), .B2(new_n165_), .C(new_n70_), .Y(new_n229_));
  AND2x2_ASAP7_75t_R   g208(.A(p5), .B(p1), .Y(new_n230_));
  AO21x1_ASAP7_75t_R   g209(.A1(p1), .A2(new_n63_), .B(new_n31_), .Y(new_n231_));
  AND3x1_ASAP7_75t_R   g210(.A(new_n178_), .B(new_n122_), .C(p4), .Y(new_n232_));
  OAI21x1_ASAP7_75t_R  g211(.A1(new_n230_), .A2(new_n231_), .B(new_n232_), .Y(new_n233_));
  NAND2x1_ASAP7_75t_R  g212(.A(new_n35_), .B(new_n44_), .Y(new_n234_));
  OR3x1_ASAP7_75t_R    g213(.A(new_n31_), .B(new_n41_), .C(p2), .Y(new_n235_));
  NAND2x1_ASAP7_75t_R  g214(.A(p5), .B(new_n63_), .Y(new_n236_));
  AO21x1_ASAP7_75t_R   g215(.A1(new_n234_), .A2(new_n235_), .B(new_n236_), .Y(new_n237_));
  AND5x1_ASAP7_75t_R   g216(.A(new_n223_), .B(new_n227_), .C(new_n229_), .D(new_n233_), .E(new_n237_), .Y(new_n238_));
  AO21x1_ASAP7_75t_R   g217(.A1(p6), .A2(new_n140_), .B(new_n49_), .Y(new_n239_));
  AOI22x1_ASAP7_75t_R  g218(.A1(new_n239_), .A2(new_n43_), .B1(new_n83_), .B2(new_n167_), .Y(new_n240_));
  OR3x1_ASAP7_75t_R    g219(.A(new_n240_), .B(p1), .C(new_n183_), .Y(new_n241_));
  OA31x2_ASAP7_75t_R   g220(.A1(p6), .A2(new_n218_), .A3(new_n238_), .B1(new_n241_), .Y(new_n242_));
  OAI21x1_ASAP7_75t_R  g221(.A1(p6), .A2(new_n213_), .B(new_n242_), .Y(o2));
  NOR2x1_ASAP7_75t_R   g222(.A(p5), .B(p4), .Y(new_n244_));
  AO21x1_ASAP7_75t_R   g223(.A1(p8), .A2(p7), .B(p4), .Y(new_n245_));
  AND3x1_ASAP7_75t_R   g224(.A(new_n245_), .B(new_n31_), .C(new_n59_), .Y(new_n246_));
  OA211x2_ASAP7_75t_R  g225(.A1(new_n68_), .A2(new_n244_), .B(new_n246_), .C(p3), .Y(new_n247_));
  AND3x1_ASAP7_75t_R   g226(.A(new_n134_), .B(new_n140_), .C(new_n88_), .Y(new_n248_));
  AOI211x1_ASAP7_75t_R g227(.A1(new_n57_), .A2(new_n236_), .B(new_n68_), .C(new_n69_), .Y(new_n249_));
  OA21x2_ASAP7_75t_R   g228(.A1(new_n248_), .A2(new_n249_), .B(p0), .Y(new_n250_));
  AO32x1_ASAP7_75t_R   g229(.A1(new_n225_), .A2(new_n31_), .A3(new_n178_), .B1(new_n23_), .B2(new_n230_), .Y(new_n251_));
  AO21x1_ASAP7_75t_R   g230(.A1(new_n175_), .A2(new_n141_), .B(new_n251_), .Y(new_n252_));
  OA21x2_ASAP7_75t_R   g231(.A1(new_n250_), .A2(new_n252_), .B(new_n73_), .Y(new_n253_));
  OAI21x1_ASAP7_75t_R  g232(.A1(new_n247_), .A2(new_n253_), .B(new_n49_), .Y(new_n254_));
  AO21x1_ASAP7_75t_R   g233(.A1(p8), .A2(new_n178_), .B(new_n111_), .Y(new_n255_));
  INVx1_ASAP7_75t_R    g234(.A(new_n98_), .Y(new_n256_));
  OA21x2_ASAP7_75t_R   g235(.A1(new_n63_), .A2(new_n92_), .B(new_n256_), .Y(new_n257_));
  AO21x1_ASAP7_75t_R   g236(.A1(new_n128_), .A2(new_n255_), .B(new_n257_), .Y(new_n258_));
  NAND2x1_ASAP7_75t_R  g237(.A(p4), .B(p7), .Y(new_n259_));
  NAND2x1_ASAP7_75t_R  g238(.A(p1), .B(new_n57_), .Y(new_n260_));
  AO21x1_ASAP7_75t_R   g239(.A1(new_n259_), .A2(new_n260_), .B(new_n138_), .Y(new_n261_));
  AOI21x1_ASAP7_75t_R  g240(.A1(new_n126_), .A2(new_n261_), .B(p8), .Y(new_n262_));
  AND3x1_ASAP7_75t_R   g241(.A(new_n52_), .B(p4), .C(p8), .Y(new_n263_));
  NOR2x1_ASAP7_75t_R   g242(.A(p4), .B(new_n57_), .Y(new_n264_));
  INVx1_ASAP7_75t_R    g243(.A(new_n264_), .Y(new_n265_));
  OA21x2_ASAP7_75t_R   g244(.A1(p5), .A2(new_n102_), .B(new_n265_), .Y(new_n266_));
  OR4x2_ASAP7_75t_R    g245(.A(new_n262_), .B(new_n221_), .C(new_n263_), .D(new_n266_), .Y(new_n267_));
  AND3x1_ASAP7_75t_R   g246(.A(new_n83_), .B(new_n80_), .C(new_n67_), .Y(new_n268_));
  OA21x2_ASAP7_75t_R   g247(.A1(p5), .A2(new_n154_), .B(new_n268_), .Y(new_n269_));
  AO21x1_ASAP7_75t_R   g248(.A1(p4), .A2(p7), .B(new_n47_), .Y(new_n270_));
  AND3x1_ASAP7_75t_R   g249(.A(new_n270_), .B(new_n256_), .C(new_n123_), .Y(new_n271_));
  AND3x1_ASAP7_75t_R   g250(.A(new_n32_), .B(new_n128_), .C(p7), .Y(new_n272_));
  OA21x2_ASAP7_75t_R   g251(.A1(new_n25_), .A2(new_n129_), .B(new_n221_), .Y(new_n273_));
  OR4x2_ASAP7_75t_R    g252(.A(new_n269_), .B(new_n271_), .C(new_n272_), .D(new_n273_), .Y(new_n274_));
  AOI221x1_ASAP7_75t_R g253(.A1(new_n31_), .A2(new_n258_), .B1(new_n267_), .B2(new_n169_), .C(new_n274_), .Y(new_n275_));
  OAI22x1_ASAP7_75t_R  g254(.A1(new_n254_), .A2(p6), .B1(new_n275_), .B2(new_n115_), .Y(o3));
  OR3x1_ASAP7_75t_R    g255(.A(new_n76_), .B(new_n27_), .C(p3), .Y(new_n277_));
  NAND2x1_ASAP7_75t_R  g256(.A(p3), .B(new_n57_), .Y(new_n278_));
  NAND2x1_ASAP7_75t_R  g257(.A(p2), .B(new_n73_), .Y(new_n279_));
  INVx1_ASAP7_75t_R    g258(.A(new_n150_), .Y(new_n280_));
  AO21x1_ASAP7_75t_R   g259(.A1(new_n278_), .A2(new_n279_), .B(new_n280_), .Y(new_n281_));
  OR3x1_ASAP7_75t_R    g260(.A(new_n88_), .B(new_n23_), .C(p6), .Y(new_n282_));
  AOI21x1_ASAP7_75t_R  g261(.A1(new_n277_), .A2(new_n281_), .B(new_n282_), .Y(o4));
  AO21x1_ASAP7_75t_R   g262(.A1(new_n27_), .A2(new_n76_), .B(new_n279_), .Y(new_n284_));
  OR3x1_ASAP7_75t_R    g263(.A(new_n81_), .B(new_n278_), .C(p0), .Y(new_n285_));
  AOI21x1_ASAP7_75t_R  g264(.A1(new_n284_), .A2(new_n285_), .B(new_n282_), .Y(o5));
  AND2x2_ASAP7_75t_R   g265(.A(p9), .B(p7), .Y(new_n287_));
  INVx1_ASAP7_75t_R    g266(.A(new_n134_), .Y(new_n288_));
  AO32x1_ASAP7_75t_R   g267(.A1(new_n288_), .A2(new_n54_), .A3(new_n70_), .B1(p4), .B2(new_n47_), .Y(new_n289_));
  AND2x2_ASAP7_75t_R   g268(.A(new_n287_), .B(new_n289_), .Y(new_n290_));
  OA21x2_ASAP7_75t_R   g269(.A1(new_n111_), .A2(new_n140_), .B(p5), .Y(new_n291_));
  OA21x2_ASAP7_75t_R   g270(.A1(new_n52_), .A2(new_n138_), .B(new_n291_), .Y(new_n292_));
  AO32x1_ASAP7_75t_R   g271(.A1(new_n31_), .A2(p4), .A3(new_n111_), .B1(new_n84_), .B2(new_n134_), .Y(new_n293_));
  AND3x1_ASAP7_75t_R   g272(.A(new_n26_), .B(new_n36_), .C(p7), .Y(new_n294_));
  OR3x1_ASAP7_75t_R    g273(.A(new_n292_), .B(new_n293_), .C(new_n294_), .Y(new_n295_));
  OAI21x1_ASAP7_75t_R  g274(.A1(new_n290_), .A2(new_n295_), .B(new_n57_), .Y(new_n296_));
  AO21x1_ASAP7_75t_R   g275(.A1(p5), .A2(new_n63_), .B(p9), .Y(new_n297_));
  NOR2x1_ASAP7_75t_R   g276(.A(p1), .B(p8), .Y(new_n298_));
  AO32x1_ASAP7_75t_R   g277(.A1(new_n297_), .A2(new_n298_), .A3(new_n259_), .B1(new_n84_), .B2(new_n138_), .Y(new_n299_));
  NOR2x1_ASAP7_75t_R   g278(.A(new_n83_), .B(new_n84_), .Y(new_n300_));
  AO21x1_ASAP7_75t_R   g279(.A1(p1), .A2(new_n23_), .B(p5), .Y(new_n301_));
  AO32x1_ASAP7_75t_R   g280(.A1(new_n300_), .A2(new_n27_), .A3(p4), .B1(new_n84_), .B2(new_n301_), .Y(new_n302_));
  OA211x2_ASAP7_75t_R  g281(.A1(new_n135_), .A2(new_n194_), .B(p5), .C(p0), .Y(new_n303_));
  AOI221x1_ASAP7_75t_R g282(.A1(new_n31_), .A2(new_n299_), .B1(new_n302_), .B2(new_n103_), .C(new_n303_), .Y(new_n304_));
  NAND2x1_ASAP7_75t_R  g283(.A(new_n49_), .B(new_n63_), .Y(new_n305_));
  NAND2x1_ASAP7_75t_R  g284(.A(p1), .B(new_n49_), .Y(new_n306_));
  AO32x1_ASAP7_75t_R   g285(.A1(new_n27_), .A2(p7), .A3(new_n174_), .B1(new_n103_), .B2(new_n306_), .Y(new_n307_));
  AO32x1_ASAP7_75t_R   g286(.A1(new_n32_), .A2(new_n162_), .A3(new_n305_), .B1(new_n307_), .B2(p8), .Y(new_n308_));
  AO21x1_ASAP7_75t_R   g287(.A1(new_n41_), .A2(new_n63_), .B(p0), .Y(new_n309_));
  NOR2x1_ASAP7_75t_R   g288(.A(p5), .B(p9), .Y(new_n310_));
  OA22x2_ASAP7_75t_R   g289(.A1(new_n175_), .A2(new_n310_), .B1(p0), .B2(p7), .Y(new_n311_));
  AO32x1_ASAP7_75t_R   g290(.A1(p9), .A2(new_n42_), .A3(new_n309_), .B1(new_n311_), .B2(new_n48_), .Y(new_n312_));
  AOI22x1_ASAP7_75t_R  g291(.A1(new_n308_), .A2(p2), .B1(new_n312_), .B2(new_n264_), .Y(new_n313_));
  NAND3x1_ASAP7_75t_R  g292(.A(new_n296_), .B(new_n304_), .C(new_n313_), .Y(new_n314_));
  AO21x1_ASAP7_75t_R   g293(.A1(p6), .A2(new_n41_), .B(new_n63_), .Y(new_n315_));
  AOI21x1_ASAP7_75t_R  g294(.A1(new_n144_), .A2(new_n315_), .B(new_n93_), .Y(new_n316_));
  INVx1_ASAP7_75t_R    g295(.A(new_n309_), .Y(new_n317_));
  OR4x2_ASAP7_75t_R    g296(.A(new_n208_), .B(new_n30_), .C(p1), .D(new_n317_), .Y(new_n318_));
  OA21x2_ASAP7_75t_R   g297(.A1(p9), .A2(new_n316_), .B(new_n318_), .Y(new_n319_));
  OR3x1_ASAP7_75t_R    g298(.A(new_n77_), .B(p6), .C(new_n73_), .Y(new_n320_));
  AND2x2_ASAP7_75t_R   g299(.A(new_n282_), .B(new_n320_), .Y(new_n321_));
  OAI21x1_ASAP7_75t_R  g300(.A1(new_n183_), .A2(new_n319_), .B(new_n321_), .Y(new_n322_));
  AOI21x1_ASAP7_75t_R  g301(.A1(new_n114_), .A2(new_n314_), .B(new_n322_), .Y(o6));
  NOR2x1_ASAP7_75t_R   g302(.A(p8), .B(new_n30_), .Y(new_n324_));
  AO32x1_ASAP7_75t_R   g303(.A1(new_n112_), .A2(new_n36_), .A3(new_n192_), .B1(new_n157_), .B2(new_n324_), .Y(new_n325_));
  AND3x1_ASAP7_75t_R   g304(.A(new_n325_), .B(new_n44_), .C(new_n170_), .Y(new_n326_));
  OA21x2_ASAP7_75t_R   g305(.A1(new_n30_), .A2(new_n326_), .B(new_n73_), .Y(new_n327_));
  INVx1_ASAP7_75t_R    g306(.A(new_n204_), .Y(new_n328_));
  NAND2x1_ASAP7_75t_R  g307(.A(p7), .B(new_n49_), .Y(new_n329_));
  OAI21x1_ASAP7_75t_R  g308(.A1(new_n98_), .A2(new_n329_), .B(new_n236_), .Y(new_n330_));
  AOI221x1_ASAP7_75t_R g309(.A1(new_n49_), .A2(p8), .B1(new_n119_), .B2(new_n63_), .C(new_n310_), .Y(new_n331_));
  AOI22x1_ASAP7_75t_R  g310(.A1(new_n330_), .A2(p8), .B1(new_n98_), .B2(new_n331_), .Y(new_n332_));
  AO21x1_ASAP7_75t_R   g311(.A1(p2), .A2(new_n192_), .B(new_n287_), .Y(new_n333_));
  NOR2x1_ASAP7_75t_R   g312(.A(p5), .B(new_n27_), .Y(new_n334_));
  AND3x1_ASAP7_75t_R   g313(.A(new_n70_), .B(new_n57_), .C(new_n63_), .Y(new_n335_));
  AOI221x1_ASAP7_75t_R g314(.A1(new_n106_), .A2(new_n140_), .B1(new_n333_), .B2(new_n334_), .C(new_n335_), .Y(new_n336_));
  OAI21x1_ASAP7_75t_R  g315(.A1(p1), .A2(new_n332_), .B(new_n336_), .Y(new_n337_));
  AO22x1_ASAP7_75t_R   g316(.A1(new_n49_), .A2(new_n52_), .B1(p5), .B2(new_n287_), .Y(new_n338_));
  AO21x1_ASAP7_75t_R   g317(.A1(new_n57_), .A2(new_n63_), .B(p5), .Y(new_n339_));
  AOI22x1_ASAP7_75t_R  g318(.A1(new_n338_), .A2(new_n41_), .B1(new_n339_), .B2(new_n194_), .Y(new_n340_));
  AO21x1_ASAP7_75t_R   g319(.A1(p8), .A2(p7), .B(p5), .Y(new_n341_));
  NOR2x1_ASAP7_75t_R   g320(.A(new_n341_), .B(new_n89_), .Y(new_n342_));
  OA211x2_ASAP7_75t_R  g321(.A1(new_n111_), .A2(new_n140_), .B(p5), .C(new_n49_), .Y(new_n343_));
  OAI21x1_ASAP7_75t_R  g322(.A1(new_n342_), .A2(new_n343_), .B(p2), .Y(new_n344_));
  AOI21x1_ASAP7_75t_R  g323(.A1(new_n340_), .A2(new_n344_), .B(p0), .Y(new_n345_));
  AOI221x1_ASAP7_75t_R g324(.A1(new_n176_), .A2(new_n328_), .B1(new_n337_), .B2(p0), .C(new_n345_), .Y(new_n346_));
  NAND3x1_ASAP7_75t_R  g325(.A(new_n112_), .B(new_n99_), .C(new_n192_), .Y(new_n347_));
  NOR2x1_ASAP7_75t_R   g326(.A(p0), .B(new_n23_), .Y(new_n348_));
  AND3x1_ASAP7_75t_R   g327(.A(new_n178_), .B(new_n81_), .C(new_n348_), .Y(new_n349_));
  AND3x1_ASAP7_75t_R   g328(.A(new_n107_), .B(p1), .C(new_n111_), .Y(new_n350_));
  AND3x1_ASAP7_75t_R   g329(.A(new_n134_), .B(new_n140_), .C(p2), .Y(new_n351_));
  AOI211x1_ASAP7_75t_R g330(.A1(new_n347_), .A2(new_n349_), .B(new_n350_), .C(new_n351_), .Y(new_n352_));
  OR3x1_ASAP7_75t_R    g331(.A(new_n92_), .B(new_n298_), .C(new_n156_), .Y(new_n353_));
  OR4x2_ASAP7_75t_R    g332(.A(new_n23_), .B(new_n63_), .C(p9), .D(p8), .Y(new_n354_));
  OR3x1_ASAP7_75t_R    g333(.A(new_n193_), .B(new_n23_), .C(p7), .Y(new_n355_));
  AO31x2_ASAP7_75t_R   g334(.A1(new_n353_), .A2(new_n354_), .A3(new_n355_), .B(new_n61_), .Y(new_n356_));
  AND3x1_ASAP7_75t_R   g335(.A(new_n133_), .B(p2), .C(new_n192_), .Y(new_n357_));
  NOR2x1_ASAP7_75t_R   g336(.A(p9), .B(p7), .Y(new_n358_));
  OA21x2_ASAP7_75t_R   g337(.A1(new_n108_), .A2(new_n220_), .B(new_n358_), .Y(new_n359_));
  OAI21x1_ASAP7_75t_R  g338(.A1(new_n357_), .A2(new_n359_), .B(p0), .Y(new_n360_));
  NAND3x1_ASAP7_75t_R  g339(.A(new_n352_), .B(new_n356_), .C(new_n360_), .Y(new_n361_));
  AOI21x1_ASAP7_75t_R  g340(.A1(new_n88_), .A2(new_n361_), .B(new_n326_), .Y(new_n362_));
  OAI21x1_ASAP7_75t_R  g341(.A1(p4), .A2(new_n346_), .B(new_n362_), .Y(new_n363_));
  OR3x1_ASAP7_75t_R    g342(.A(new_n285_), .B(p6), .C(p4), .Y(new_n364_));
  NOR2x1_ASAP7_75t_R   g343(.A(p5), .B(new_n364_), .Y(new_n365_));
  AOI21x1_ASAP7_75t_R  g344(.A1(new_n327_), .A2(new_n363_), .B(new_n365_), .Y(o7));
  AO21x1_ASAP7_75t_R   g345(.A1(p0), .A2(p4), .B(new_n264_), .Y(new_n367_));
  OR3x1_ASAP7_75t_R    g346(.A(new_n367_), .B(new_n94_), .C(new_n186_), .Y(new_n368_));
  OA211x2_ASAP7_75t_R  g347(.A1(p4), .A2(new_n127_), .B(new_n175_), .C(new_n85_), .Y(new_n369_));
  NOR2x1_ASAP7_75t_R   g348(.A(p8), .B(new_n369_), .Y(new_n370_));
  OR5x1_ASAP7_75t_R    g349(.A(new_n49_), .B(new_n63_), .C(p2), .D(p0), .E(p4), .Y(new_n371_));
  NAND3x1_ASAP7_75t_R  g350(.A(new_n368_), .B(new_n370_), .C(new_n371_), .Y(new_n372_));
  AND3x1_ASAP7_75t_R   g351(.A(new_n161_), .B(new_n31_), .C(p7), .Y(new_n373_));
  AO21x1_ASAP7_75t_R   g352(.A1(p1), .A2(new_n23_), .B(new_n220_), .Y(new_n374_));
  AND3x1_ASAP7_75t_R   g353(.A(new_n224_), .B(p0), .C(new_n99_), .Y(new_n375_));
  AO221x2_ASAP7_75t_R  g354(.A1(new_n373_), .A2(new_n221_), .B1(new_n374_), .B2(new_n375_), .C(new_n41_), .Y(new_n376_));
  NAND3x1_ASAP7_75t_R  g355(.A(new_n372_), .B(new_n88_), .C(new_n376_), .Y(new_n377_));
  NAND2x1_ASAP7_75t_R  g356(.A(p9), .B(new_n309_), .Y(new_n378_));
  NOR2x1_ASAP7_75t_R   g357(.A(p5), .B(new_n103_), .Y(new_n379_));
  AO21x1_ASAP7_75t_R   g358(.A1(new_n42_), .A2(new_n127_), .B(new_n198_), .Y(new_n380_));
  AO221x2_ASAP7_75t_R  g359(.A1(new_n378_), .A2(new_n379_), .B1(new_n380_), .B2(new_n27_), .C(new_n265_), .Y(new_n381_));
  NAND2x1_ASAP7_75t_R  g360(.A(new_n35_), .B(new_n133_), .Y(new_n382_));
  AOI21x1_ASAP7_75t_R  g361(.A1(new_n235_), .A2(new_n382_), .B(p9), .Y(new_n383_));
  NAND2x1_ASAP7_75t_R  g362(.A(new_n31_), .B(new_n23_), .Y(new_n384_));
  AO21x1_ASAP7_75t_R   g363(.A1(new_n384_), .A2(new_n48_), .B(new_n260_), .Y(new_n385_));
  AO21x1_ASAP7_75t_R   g364(.A1(p8), .A2(new_n57_), .B(p1), .Y(new_n386_));
  OR3x1_ASAP7_75t_R    g365(.A(new_n367_), .B(new_n35_), .C(new_n386_), .Y(new_n387_));
  NAND2x1_ASAP7_75t_R  g366(.A(new_n385_), .B(new_n387_), .Y(new_n388_));
  OAI21x1_ASAP7_75t_R  g367(.A1(new_n383_), .A2(new_n388_), .B(new_n129_), .Y(new_n389_));
  NAND3x1_ASAP7_75t_R  g368(.A(new_n377_), .B(new_n381_), .C(new_n389_), .Y(new_n390_));
  NAND2x1_ASAP7_75t_R  g369(.A(new_n358_), .B(new_n92_), .Y(new_n391_));
  AO21x1_ASAP7_75t_R   g370(.A1(new_n137_), .A2(new_n122_), .B(p9), .Y(new_n392_));
  AO21x1_ASAP7_75t_R   g371(.A1(new_n158_), .A2(new_n392_), .B(p8), .Y(new_n393_));
  NAND2x1_ASAP7_75t_R  g372(.A(new_n391_), .B(new_n393_), .Y(new_n394_));
  AND3x1_ASAP7_75t_R   g373(.A(new_n47_), .B(new_n49_), .C(new_n52_), .Y(new_n395_));
  AOI21x1_ASAP7_75t_R  g374(.A1(new_n31_), .A2(new_n394_), .B(new_n395_), .Y(new_n396_));
  OAI21x1_ASAP7_75t_R  g375(.A1(new_n183_), .A2(new_n396_), .B(new_n364_), .Y(new_n397_));
  AOI21x1_ASAP7_75t_R  g376(.A1(new_n114_), .A2(new_n390_), .B(new_n397_), .Y(o8));
  AO21x1_ASAP7_75t_R   g377(.A1(new_n88_), .A2(new_n23_), .B(new_n70_), .Y(new_n399_));
  NAND2x1_ASAP7_75t_R  g378(.A(p2), .B(new_n119_), .Y(new_n400_));
  INVx1_ASAP7_75t_R    g379(.A(new_n400_), .Y(new_n401_));
  OAI21x1_ASAP7_75t_R  g380(.A1(new_n329_), .A2(new_n399_), .B(new_n401_), .Y(new_n402_));
  OA21x2_ASAP7_75t_R   g381(.A1(new_n244_), .A2(new_n278_), .B(new_n27_), .Y(new_n403_));
  AO32x1_ASAP7_75t_R   g382(.A1(new_n112_), .A2(new_n106_), .A3(new_n245_), .B1(new_n402_), .B2(new_n403_), .Y(new_n404_));
  NAND2x1_ASAP7_75t_R  g383(.A(new_n31_), .B(new_n404_), .Y(new_n405_));
  OR3x1_ASAP7_75t_R    g384(.A(new_n162_), .B(p5), .C(new_n99_), .Y(new_n406_));
  AO21x1_ASAP7_75t_R   g385(.A1(new_n30_), .A2(new_n406_), .B(new_n317_), .Y(new_n407_));
  AO21x1_ASAP7_75t_R   g386(.A1(new_n23_), .A2(new_n260_), .B(new_n88_), .Y(new_n408_));
  OR3x1_ASAP7_75t_R    g387(.A(new_n58_), .B(p1), .C(p2), .Y(new_n409_));
  AO21x1_ASAP7_75t_R   g388(.A1(new_n49_), .A2(new_n106_), .B(new_n30_), .Y(new_n410_));
  AND5x1_ASAP7_75t_R   g389(.A(new_n407_), .B(new_n216_), .C(new_n408_), .D(new_n409_), .E(new_n410_), .Y(new_n411_));
  AO21x1_ASAP7_75t_R   g390(.A1(new_n88_), .A2(new_n63_), .B(p2), .Y(new_n412_));
  OR3x1_ASAP7_75t_R    g391(.A(new_n245_), .B(p5), .C(new_n99_), .Y(new_n413_));
  OA21x2_ASAP7_75t_R   g392(.A1(new_n399_), .A2(new_n412_), .B(new_n413_), .Y(new_n414_));
  OA21x2_ASAP7_75t_R   g393(.A1(p2), .A2(new_n25_), .B(new_n329_), .Y(new_n415_));
  OR3x1_ASAP7_75t_R    g394(.A(new_n415_), .B(p1), .C(new_n401_), .Y(new_n416_));
  AO21x1_ASAP7_75t_R   g395(.A1(new_n414_), .A2(new_n416_), .B(new_n31_), .Y(new_n417_));
  AND3x1_ASAP7_75t_R   g396(.A(new_n405_), .B(new_n411_), .C(new_n417_), .Y(o9));
  AND3x1_ASAP7_75t_R   g397(.A(new_n42_), .B(p7), .C(new_n40_), .Y(new_n419_));
  OR5x1_ASAP7_75t_R    g398(.A(new_n27_), .B(new_n419_), .C(new_n105_), .D(new_n76_), .E(new_n279_), .Y(new_n420_));
  NAND2x1_ASAP7_75t_R  g399(.A(new_n285_), .B(new_n420_), .Y(new_n421_));
  AND3x1_ASAP7_75t_R   g400(.A(new_n421_), .B(new_n30_), .C(new_n244_), .Y(o10));
endmodule


