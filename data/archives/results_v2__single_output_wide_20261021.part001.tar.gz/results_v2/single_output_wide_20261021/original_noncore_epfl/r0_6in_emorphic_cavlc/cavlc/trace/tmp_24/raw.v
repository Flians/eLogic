// Benchmark "/tmp/" written by ABC on Wed Oct 21 14:26:16 2026

module \/tmp/  ( 
    p0, p5, p6, p3, p4, p9, p7, p8, p2, p1,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10  );
  input  p0, p5, p6, p3, p4, p9, p7, p8, p2, p1;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10;
  wire new_n22_, new_n23_, new_n24_, new_n25_, new_n26_, new_n27_, new_n28_,
    new_n29_, new_n30_, new_n31_, new_n32_, new_n33_, new_n34_, new_n35_,
    new_n36_, new_n37_, new_n38_, new_n39_, new_n40_, new_n41_, new_n42_,
    new_n43_, new_n44_, new_n45_, new_n46_, new_n47_, new_n48_, new_n49_,
    new_n50_, new_n51_, new_n52_, new_n53_, new_n54_, new_n55_, new_n56_,
    new_n57_, new_n58_, new_n59_, new_n60_, new_n61_, new_n62_, new_n63_,
    new_n64_, new_n65_, new_n66_, new_n67_, new_n68_, new_n69_, new_n70_,
    new_n71_, new_n72_, new_n73_, new_n74_, new_n75_, new_n76_, new_n77_,
    new_n78_, new_n79_, new_n80_, new_n81_, new_n82_, new_n83_, new_n84_,
    new_n85_, new_n86_, new_n87_, new_n88_, new_n89_, new_n90_, new_n91_,
    new_n92_, new_n93_, new_n94_, new_n95_, new_n96_, new_n97_, new_n98_,
    new_n99_, new_n100_, new_n101_, new_n102_, new_n103_, new_n104_,
    new_n105_, new_n106_, new_n107_, new_n108_, new_n109_, new_n110_,
    new_n111_, new_n112_, new_n114_, new_n115_, new_n116_, new_n117_,
    new_n118_, new_n119_, new_n120_, new_n121_, new_n122_, new_n123_,
    new_n124_, new_n125_, new_n126_, new_n127_, new_n128_, new_n129_,
    new_n130_, new_n131_, new_n132_, new_n133_, new_n134_, new_n135_,
    new_n136_, new_n137_, new_n138_, new_n139_, new_n140_, new_n141_,
    new_n142_, new_n143_, new_n144_, new_n145_, new_n146_, new_n147_,
    new_n148_, new_n149_, new_n150_, new_n151_, new_n152_, new_n153_,
    new_n154_, new_n155_, new_n156_, new_n157_, new_n158_, new_n159_,
    new_n160_, new_n161_, new_n162_, new_n163_, new_n164_, new_n165_,
    new_n166_, new_n167_, new_n168_, new_n169_, new_n170_, new_n171_,
    new_n172_, new_n173_, new_n174_, new_n175_, new_n176_, new_n177_,
    new_n178_, new_n179_, new_n180_, new_n181_, new_n182_, new_n183_,
    new_n184_, new_n185_, new_n187_, new_n188_, new_n189_, new_n190_,
    new_n191_, new_n192_, new_n193_, new_n194_, new_n195_, new_n196_,
    new_n197_, new_n198_, new_n199_, new_n200_, new_n201_, new_n202_,
    new_n203_, new_n204_, new_n205_, new_n206_, new_n207_, new_n208_,
    new_n209_, new_n210_, new_n211_, new_n212_, new_n213_, new_n214_,
    new_n215_, new_n216_, new_n217_, new_n218_, new_n219_, new_n220_,
    new_n221_, new_n222_, new_n223_, new_n224_, new_n225_, new_n226_,
    new_n227_, new_n228_, new_n229_, new_n230_, new_n231_, new_n232_,
    new_n233_, new_n234_, new_n236_, new_n237_, new_n238_, new_n239_,
    new_n240_, new_n241_, new_n242_, new_n243_, new_n244_, new_n245_,
    new_n246_, new_n247_, new_n248_, new_n249_, new_n250_, new_n251_,
    new_n252_, new_n253_, new_n254_, new_n255_, new_n256_, new_n257_,
    new_n258_, new_n259_, new_n260_, new_n261_, new_n262_, new_n263_,
    new_n264_, new_n265_, new_n266_, new_n267_, new_n268_, new_n269_,
    new_n270_, new_n271_, new_n272_, new_n274_, new_n275_, new_n276_,
    new_n277_, new_n278_, new_n279_, new_n281_, new_n282_, new_n283_,
    new_n285_, new_n286_, new_n287_, new_n288_, new_n289_, new_n290_,
    new_n291_, new_n292_, new_n293_, new_n294_, new_n295_, new_n296_,
    new_n297_, new_n298_, new_n299_, new_n300_, new_n301_, new_n302_,
    new_n303_, new_n304_, new_n305_, new_n306_, new_n307_, new_n308_,
    new_n309_, new_n310_, new_n311_, new_n312_, new_n313_, new_n314_,
    new_n315_, new_n316_, new_n317_, new_n318_, new_n319_, new_n320_,
    new_n321_, new_n322_, new_n324_, new_n325_, new_n326_, new_n327_,
    new_n328_, new_n329_, new_n330_, new_n331_, new_n332_, new_n333_,
    new_n334_, new_n335_, new_n336_, new_n337_, new_n338_, new_n339_,
    new_n340_, new_n341_, new_n342_, new_n343_, new_n344_, new_n345_,
    new_n346_, new_n347_, new_n348_, new_n349_, new_n350_, new_n351_,
    new_n352_, new_n353_, new_n354_, new_n355_, new_n356_, new_n357_,
    new_n358_, new_n359_, new_n360_, new_n361_, new_n362_, new_n363_,
    new_n364_, new_n365_, new_n366_, new_n368_, new_n369_, new_n370_,
    new_n371_, new_n372_, new_n373_, new_n374_, new_n375_, new_n376_,
    new_n377_, new_n378_, new_n379_, new_n380_, new_n381_, new_n382_,
    new_n383_, new_n384_, new_n385_, new_n386_, new_n387_, new_n388_,
    new_n389_, new_n390_, new_n391_, new_n392_, new_n393_, new_n394_,
    new_n395_, new_n396_, new_n397_, new_n398_, new_n399_, new_n400_,
    new_n402_, new_n403_, new_n404_, new_n405_, new_n406_, new_n407_,
    new_n408_, new_n409_, new_n410_, new_n411_, new_n412_, new_n413_,
    new_n414_, new_n415_, new_n416_, new_n417_, new_n418_, new_n419_,
    new_n421_, new_n422_;
  INVx1_ASAP7_75t_R    g000(.A(p8), .Y(new_n22_));
  NAND2x1_ASAP7_75t_R  g001(.A(p0), .B(new_n22_), .Y(new_n23_));
  INVx1_ASAP7_75t_R    g002(.A(p4), .Y(new_n24_));
  INVx1_ASAP7_75t_R    g003(.A(p6), .Y(new_n25_));
  AO21x1_ASAP7_75t_R   g004(.A1(new_n24_), .A2(new_n22_), .B(new_n25_), .Y(new_n26_));
  INVx1_ASAP7_75t_R    g005(.A(p1), .Y(new_n27_));
  AO32x1_ASAP7_75t_R   g006(.A1(new_n26_), .A2(p9), .A3(new_n27_), .B1(new_n24_), .B2(p7), .Y(new_n28_));
  OAI21x1_ASAP7_75t_R  g007(.A1(p6), .A2(new_n23_), .B(new_n28_), .Y(new_n29_));
  INVx1_ASAP7_75t_R    g008(.A(p2), .Y(new_n30_));
  AO21x1_ASAP7_75t_R   g009(.A1(new_n24_), .A2(new_n22_), .B(p0), .Y(new_n31_));
  NOR2x1_ASAP7_75t_R   g010(.A(p0), .B(p8), .Y(new_n32_));
  INVx1_ASAP7_75t_R    g011(.A(p9), .Y(new_n33_));
  AND3x1_ASAP7_75t_R   g012(.A(new_n32_), .B(new_n33_), .C(p1), .Y(new_n34_));
  AO32x1_ASAP7_75t_R   g013(.A1(p9), .A2(new_n31_), .A3(new_n27_), .B1(new_n34_), .B2(p6), .Y(new_n35_));
  NAND2x1_ASAP7_75t_R  g014(.A(new_n30_), .B(new_n35_), .Y(new_n36_));
  XNOR2x2_ASAP7_75t_R  g015(.A(p0), .B(p8), .Y(new_n37_));
  NOR2x1_ASAP7_75t_R   g016(.A(p0), .B(p9), .Y(new_n38_));
  INVx1_ASAP7_75t_R    g017(.A(new_n38_), .Y(new_n39_));
  AND3x1_ASAP7_75t_R   g018(.A(new_n37_), .B(new_n25_), .C(new_n39_), .Y(new_n40_));
  INVx1_ASAP7_75t_R    g019(.A(p0), .Y(new_n41_));
  NOR2x1_ASAP7_75t_R   g020(.A(p9), .B(new_n22_), .Y(new_n42_));
  NAND2x1_ASAP7_75t_R  g021(.A(p8), .B(new_n41_), .Y(new_n43_));
  NOR2x1_ASAP7_75t_R   g022(.A(p4), .B(p2), .Y(new_n44_));
  OA211x2_ASAP7_75t_R  g023(.A1(new_n41_), .A2(new_n42_), .B(new_n43_), .C(new_n44_), .Y(new_n45_));
  NOR2x1_ASAP7_75t_R   g024(.A(p7), .B(p1), .Y(new_n46_));
  OAI21x1_ASAP7_75t_R  g025(.A1(new_n40_), .A2(new_n45_), .B(new_n46_), .Y(new_n47_));
  OAI21x1_ASAP7_75t_R  g026(.A1(new_n29_), .A2(new_n36_), .B(new_n47_), .Y(new_n48_));
  AND2x2_ASAP7_75t_R   g027(.A(p0), .B(p1), .Y(new_n49_));
  OA21x2_ASAP7_75t_R   g028(.A1(p4), .A2(p1), .B(new_n33_), .Y(new_n50_));
  OA21x2_ASAP7_75t_R   g029(.A1(new_n49_), .A2(new_n50_), .B(new_n22_), .Y(new_n51_));
  NOR2x1_ASAP7_75t_R   g030(.A(p0), .B(new_n33_), .Y(new_n52_));
  NOR2x1_ASAP7_75t_R   g031(.A(p2), .B(new_n41_), .Y(new_n53_));
  AO21x1_ASAP7_75t_R   g032(.A1(p2), .A2(new_n52_), .B(new_n53_), .Y(new_n54_));
  NOR2x1_ASAP7_75t_R   g033(.A(p2), .B(p1), .Y(new_n55_));
  NOR2x1_ASAP7_75t_R   g034(.A(new_n55_), .B(new_n43_), .Y(new_n56_));
  OR3x1_ASAP7_75t_R    g035(.A(new_n51_), .B(new_n54_), .C(new_n56_), .Y(new_n57_));
  INVx1_ASAP7_75t_R    g036(.A(p7), .Y(new_n58_));
  AND3x1_ASAP7_75t_R   g037(.A(new_n57_), .B(new_n25_), .C(new_n58_), .Y(new_n59_));
  NOR2x1_ASAP7_75t_R   g038(.A(p5), .B(p3), .Y(new_n60_));
  OAI21x1_ASAP7_75t_R  g039(.A1(new_n48_), .A2(new_n59_), .B(new_n60_), .Y(new_n61_));
  AND2x2_ASAP7_75t_R   g040(.A(p8), .B(p1), .Y(new_n62_));
  NOR2x1_ASAP7_75t_R   g041(.A(p0), .B(p2), .Y(new_n63_));
  NAND2x1_ASAP7_75t_R  g042(.A(p0), .B(new_n58_), .Y(new_n64_));
  INVx1_ASAP7_75t_R    g043(.A(new_n64_), .Y(new_n65_));
  AO21x1_ASAP7_75t_R   g044(.A1(new_n62_), .A2(new_n63_), .B(new_n65_), .Y(new_n66_));
  NOR2x1_ASAP7_75t_R   g045(.A(p8), .B(new_n27_), .Y(new_n67_));
  AO21x1_ASAP7_75t_R   g046(.A1(p8), .A2(new_n33_), .B(p0), .Y(new_n68_));
  NOR2x1_ASAP7_75t_R   g047(.A(p7), .B(new_n30_), .Y(new_n69_));
  AO32x1_ASAP7_75t_R   g048(.A1(p2), .A2(new_n67_), .A3(new_n52_), .B1(new_n68_), .B2(new_n69_), .Y(new_n70_));
  AOI21x1_ASAP7_75t_R  g049(.A1(new_n33_), .A2(new_n66_), .B(new_n70_), .Y(new_n71_));
  NOR2x1_ASAP7_75t_R   g050(.A(p4), .B(p7), .Y(new_n72_));
  AND2x2_ASAP7_75t_R   g051(.A(p2), .B(p1), .Y(new_n73_));
  INVx1_ASAP7_75t_R    g052(.A(new_n73_), .Y(new_n74_));
  INVx1_ASAP7_75t_R    g053(.A(p5), .Y(new_n75_));
  NAND2x1_ASAP7_75t_R  g054(.A(p2), .B(new_n75_), .Y(new_n76_));
  AO32x1_ASAP7_75t_R   g055(.A1(new_n74_), .A2(new_n32_), .A3(new_n76_), .B1(p8), .B2(p1), .Y(new_n77_));
  NOR2x1_ASAP7_75t_R   g056(.A(p7), .B(p8), .Y(new_n78_));
  AND3x1_ASAP7_75t_R   g057(.A(new_n78_), .B(new_n38_), .C(new_n55_), .Y(new_n79_));
  AOI21x1_ASAP7_75t_R  g058(.A1(new_n72_), .A2(new_n77_), .B(new_n79_), .Y(new_n80_));
  OAI21x1_ASAP7_75t_R  g059(.A1(p4), .A2(new_n71_), .B(new_n80_), .Y(new_n81_));
  NAND2x1_ASAP7_75t_R  g060(.A(p5), .B(p2), .Y(new_n82_));
  NAND2x1_ASAP7_75t_R  g061(.A(new_n33_), .B(new_n27_), .Y(new_n83_));
  OA21x2_ASAP7_75t_R   g062(.A1(new_n43_), .A2(new_n83_), .B(new_n24_), .Y(new_n84_));
  NOR2x1_ASAP7_75t_R   g063(.A(p8), .B(new_n33_), .Y(new_n85_));
  NAND2x1_ASAP7_75t_R  g064(.A(p0), .B(p1), .Y(new_n86_));
  NAND2x1_ASAP7_75t_R  g065(.A(p4), .B(p2), .Y(new_n87_));
  OR4x2_ASAP7_75t_R    g066(.A(new_n85_), .B(new_n42_), .C(new_n86_), .D(new_n87_), .Y(new_n88_));
  OA21x2_ASAP7_75t_R   g067(.A1(new_n82_), .A2(new_n84_), .B(new_n88_), .Y(new_n89_));
  AO21x1_ASAP7_75t_R   g068(.A1(p9), .A2(new_n22_), .B(p1), .Y(new_n90_));
  AO21x1_ASAP7_75t_R   g069(.A1(new_n75_), .A2(new_n90_), .B(new_n24_), .Y(new_n91_));
  INVx1_ASAP7_75t_R    g070(.A(new_n42_), .Y(new_n92_));
  AOI21x1_ASAP7_75t_R  g071(.A1(new_n53_), .A2(new_n92_), .B(new_n90_), .Y(new_n93_));
  INVx1_ASAP7_75t_R    g072(.A(new_n62_), .Y(new_n94_));
  OR3x1_ASAP7_75t_R    g073(.A(new_n41_), .B(p8), .C(p1), .Y(new_n95_));
  OR3x1_ASAP7_75t_R    g074(.A(new_n75_), .B(p9), .C(p2), .Y(new_n96_));
  AO21x1_ASAP7_75t_R   g075(.A1(new_n94_), .A2(new_n95_), .B(new_n96_), .Y(new_n97_));
  OA21x2_ASAP7_75t_R   g076(.A1(new_n91_), .A2(new_n93_), .B(new_n97_), .Y(new_n98_));
  AOI21x1_ASAP7_75t_R  g077(.A1(new_n89_), .A2(new_n98_), .B(new_n58_), .Y(new_n99_));
  NOR2x1_ASAP7_75t_R   g078(.A(p6), .B(p3), .Y(new_n100_));
  OAI21x1_ASAP7_75t_R  g079(.A1(new_n81_), .A2(new_n99_), .B(new_n100_), .Y(new_n101_));
  NOR2x1_ASAP7_75t_R   g080(.A(p7), .B(new_n24_), .Y(new_n102_));
  AND2x2_ASAP7_75t_R   g081(.A(p5), .B(p4), .Y(new_n103_));
  NOR2x1_ASAP7_75t_R   g082(.A(p5), .B(p8), .Y(new_n104_));
  AND2x2_ASAP7_75t_R   g083(.A(p3), .B(p7), .Y(new_n105_));
  OAI22x1_ASAP7_75t_R  g084(.A1(new_n102_), .A2(new_n103_), .B1(new_n104_), .B2(new_n105_), .Y(new_n106_));
  INVx1_ASAP7_75t_R    g085(.A(p3), .Y(new_n107_));
  AO21x1_ASAP7_75t_R   g086(.A1(new_n107_), .A2(p8), .B(new_n104_), .Y(new_n108_));
  OR3x1_ASAP7_75t_R    g087(.A(new_n108_), .B(p7), .C(new_n103_), .Y(new_n109_));
  INVx1_ASAP7_75t_R    g088(.A(new_n55_), .Y(new_n110_));
  OR3x1_ASAP7_75t_R    g089(.A(new_n39_), .B(new_n110_), .C(p6), .Y(new_n111_));
  AO21x1_ASAP7_75t_R   g090(.A1(new_n106_), .A2(new_n109_), .B(new_n111_), .Y(new_n112_));
  NAND3x1_ASAP7_75t_R  g091(.A(new_n61_), .B(new_n101_), .C(new_n112_), .Y(o0));
  AND2x2_ASAP7_75t_R   g092(.A(p5), .B(p7), .Y(new_n114_));
  OR3x1_ASAP7_75t_R    g093(.A(new_n114_), .B(new_n33_), .C(p1), .Y(new_n115_));
  NAND2x1_ASAP7_75t_R  g094(.A(p5), .B(p8), .Y(new_n116_));
  OA21x2_ASAP7_75t_R   g095(.A1(p4), .A2(new_n58_), .B(new_n116_), .Y(new_n117_));
  OR3x1_ASAP7_75t_R    g096(.A(new_n24_), .B(p7), .C(p1), .Y(new_n118_));
  OAI22x1_ASAP7_75t_R  g097(.A1(new_n115_), .A2(new_n117_), .B1(new_n92_), .B2(new_n118_), .Y(new_n119_));
  OR5x1_ASAP7_75t_R    g098(.A(new_n24_), .B(p9), .C(p7), .D(p8), .E(p1), .Y(new_n120_));
  NAND2x1_ASAP7_75t_R  g099(.A(p7), .B(p8), .Y(new_n121_));
  NAND2x1_ASAP7_75t_R  g100(.A(p4), .B(p1), .Y(new_n122_));
  OR3x1_ASAP7_75t_R    g101(.A(new_n121_), .B(new_n122_), .C(new_n33_), .Y(new_n123_));
  AOI21x1_ASAP7_75t_R  g102(.A1(new_n120_), .A2(new_n123_), .B(p0), .Y(new_n124_));
  AOI21x1_ASAP7_75t_R  g103(.A1(p0), .A2(new_n119_), .B(new_n124_), .Y(new_n125_));
  NOR2x1_ASAP7_75t_R   g104(.A(p4), .B(new_n75_), .Y(new_n126_));
  NOR2x1_ASAP7_75t_R   g105(.A(p9), .B(new_n58_), .Y(new_n127_));
  NAND2x1_ASAP7_75t_R  g106(.A(new_n126_), .B(new_n127_), .Y(new_n128_));
  NOR2x1_ASAP7_75t_R   g107(.A(p5), .B(p7), .Y(new_n129_));
  INVx1_ASAP7_75t_R    g108(.A(new_n129_), .Y(new_n130_));
  OR3x1_ASAP7_75t_R    g109(.A(new_n58_), .B(new_n27_), .C(p4), .Y(new_n131_));
  AND2x2_ASAP7_75t_R   g110(.A(new_n130_), .B(new_n131_), .Y(new_n132_));
  AO21x1_ASAP7_75t_R   g111(.A1(new_n128_), .A2(new_n132_), .B(new_n23_), .Y(new_n133_));
  AND2x2_ASAP7_75t_R   g112(.A(p5), .B(p8), .Y(new_n134_));
  NOR2x1_ASAP7_75t_R   g113(.A(new_n72_), .B(new_n134_), .Y(new_n135_));
  NOR2x1_ASAP7_75t_R   g114(.A(p7), .B(new_n22_), .Y(new_n136_));
  OAI22x1_ASAP7_75t_R  g115(.A1(new_n117_), .A2(p9), .B1(new_n135_), .B2(new_n136_), .Y(new_n137_));
  NOR2x1_ASAP7_75t_R   g116(.A(p0), .B(new_n27_), .Y(new_n138_));
  AND2x2_ASAP7_75t_R   g117(.A(p7), .B(p1), .Y(new_n139_));
  AOI22x1_ASAP7_75t_R  g118(.A1(new_n137_), .A2(new_n138_), .B1(new_n104_), .B2(new_n139_), .Y(new_n140_));
  NAND3x1_ASAP7_75t_R  g119(.A(new_n125_), .B(new_n133_), .C(new_n140_), .Y(new_n141_));
  OA21x2_ASAP7_75t_R   g120(.A1(new_n105_), .A2(new_n102_), .B(new_n104_), .Y(new_n142_));
  AO21x1_ASAP7_75t_R   g121(.A1(p3), .A2(new_n134_), .B(new_n142_), .Y(new_n143_));
  AND3x1_ASAP7_75t_R   g122(.A(new_n41_), .B(new_n33_), .C(new_n27_), .Y(new_n144_));
  AOI22x1_ASAP7_75t_R  g123(.A1(new_n141_), .A2(new_n107_), .B1(new_n143_), .B2(new_n144_), .Y(new_n145_));
  NAND2x1_ASAP7_75t_R  g124(.A(new_n25_), .B(new_n30_), .Y(new_n146_));
  NOR2x1_ASAP7_75t_R   g125(.A(p0), .B(p7), .Y(new_n147_));
  NOR2x1_ASAP7_75t_R   g126(.A(p4), .B(new_n147_), .Y(new_n148_));
  NAND2x1_ASAP7_75t_R  g127(.A(p2), .B(new_n27_), .Y(new_n149_));
  OAI21x1_ASAP7_75t_R  g128(.A1(p0), .A2(new_n82_), .B(new_n149_), .Y(new_n150_));
  AOI21x1_ASAP7_75t_R  g129(.A1(new_n148_), .A2(new_n150_), .B(p8), .Y(new_n151_));
  NOR2x1_ASAP7_75t_R   g130(.A(p4), .B(new_n58_), .Y(new_n152_));
  NOR2x1_ASAP7_75t_R   g131(.A(p7), .B(p2), .Y(new_n153_));
  OR5x1_ASAP7_75t_R    g132(.A(p0), .B(new_n152_), .C(p5), .D(new_n33_), .E(new_n153_), .Y(new_n154_));
  AND2x2_ASAP7_75t_R   g133(.A(p0), .B(p9), .Y(new_n155_));
  NOR2x1_ASAP7_75t_R   g134(.A(p0), .B(p5), .Y(new_n156_));
  OR5x1_ASAP7_75t_R    g135(.A(p4), .B(new_n127_), .C(p1), .D(new_n155_), .E(new_n156_), .Y(new_n157_));
  AND3x1_ASAP7_75t_R   g136(.A(new_n151_), .B(new_n154_), .C(new_n157_), .Y(new_n158_));
  AO21x1_ASAP7_75t_R   g137(.A1(p7), .A2(p2), .B(p1), .Y(new_n159_));
  AO32x1_ASAP7_75t_R   g138(.A1(new_n41_), .A2(p4), .A3(new_n46_), .B1(new_n159_), .B2(new_n33_), .Y(new_n160_));
  AND3x1_ASAP7_75t_R   g139(.A(new_n27_), .B(p9), .C(p7), .Y(new_n161_));
  NAND2x1_ASAP7_75t_R  g140(.A(p4), .B(new_n33_), .Y(new_n162_));
  NAND2x1_ASAP7_75t_R  g141(.A(p9), .B(new_n24_), .Y(new_n163_));
  NAND2x1_ASAP7_75t_R  g142(.A(new_n162_), .B(new_n163_), .Y(new_n164_));
  OA21x2_ASAP7_75t_R   g143(.A1(new_n161_), .A2(new_n164_), .B(p0), .Y(new_n165_));
  OAI21x1_ASAP7_75t_R  g144(.A1(new_n160_), .A2(new_n165_), .B(new_n75_), .Y(new_n166_));
  AOI22x1_ASAP7_75t_R  g145(.A1(new_n24_), .A2(new_n86_), .B1(new_n122_), .B2(new_n30_), .Y(new_n167_));
  NOR2x1_ASAP7_75t_R   g146(.A(p0), .B(new_n30_), .Y(new_n168_));
  AND2x2_ASAP7_75t_R   g147(.A(p0), .B(p4), .Y(new_n169_));
  AO21x1_ASAP7_75t_R   g148(.A1(new_n46_), .A2(new_n168_), .B(new_n169_), .Y(new_n170_));
  AND2x2_ASAP7_75t_R   g149(.A(p5), .B(p9), .Y(new_n171_));
  AND3x1_ASAP7_75t_R   g150(.A(p0), .B(p4), .C(p1), .Y(new_n172_));
  AO21x1_ASAP7_75t_R   g151(.A1(new_n172_), .A2(new_n69_), .B(new_n22_), .Y(new_n173_));
  AOI221x1_ASAP7_75t_R g152(.A1(p5), .A2(new_n167_), .B1(new_n170_), .B2(new_n171_), .C(new_n173_), .Y(new_n174_));
  AOI21x1_ASAP7_75t_R  g153(.A1(new_n158_), .A2(new_n166_), .B(new_n174_), .Y(new_n175_));
  AND3x1_ASAP7_75t_R   g154(.A(new_n44_), .B(new_n75_), .C(new_n107_), .Y(new_n176_));
  NOR2x1_ASAP7_75t_R   g155(.A(new_n155_), .B(new_n90_), .Y(new_n177_));
  NOR2x1_ASAP7_75t_R   g156(.A(new_n27_), .B(new_n38_), .Y(new_n178_));
  OR3x1_ASAP7_75t_R    g157(.A(new_n178_), .B(new_n25_), .C(p7), .Y(new_n179_));
  NOR2x1_ASAP7_75t_R   g158(.A(new_n177_), .B(new_n179_), .Y(new_n180_));
  NOR2x1_ASAP7_75t_R   g159(.A(p8), .B(new_n41_), .Y(new_n181_));
  NOR2x1_ASAP7_75t_R   g160(.A(p1), .B(new_n58_), .Y(new_n182_));
  AND3x1_ASAP7_75t_R   g161(.A(new_n181_), .B(new_n182_), .C(p6), .Y(new_n183_));
  OR3x1_ASAP7_75t_R    g162(.A(new_n180_), .B(new_n34_), .C(new_n183_), .Y(new_n184_));
  AOI22x1_ASAP7_75t_R  g163(.A1(new_n175_), .A2(new_n100_), .B1(new_n176_), .B2(new_n184_), .Y(new_n185_));
  OAI21x1_ASAP7_75t_R  g164(.A1(new_n145_), .A2(new_n146_), .B(new_n185_), .Y(o1));
  NAND2x1_ASAP7_75t_R  g165(.A(p2), .B(new_n58_), .Y(new_n187_));
  NAND2x1_ASAP7_75t_R  g166(.A(p0), .B(p7), .Y(new_n188_));
  AO21x1_ASAP7_75t_R   g167(.A1(p5), .A2(p1), .B(new_n188_), .Y(new_n189_));
  AO32x1_ASAP7_75t_R   g168(.A1(new_n181_), .A2(new_n187_), .A3(new_n74_), .B1(new_n189_), .B2(new_n159_), .Y(new_n190_));
  NAND2x1_ASAP7_75t_R  g169(.A(p5), .B(new_n58_), .Y(new_n191_));
  INVx1_ASAP7_75t_R    g170(.A(new_n191_), .Y(new_n192_));
  AND2x2_ASAP7_75t_R   g171(.A(p0), .B(p8), .Y(new_n193_));
  AO32x1_ASAP7_75t_R   g172(.A1(new_n24_), .A2(new_n22_), .A3(new_n63_), .B1(new_n193_), .B2(new_n30_), .Y(new_n194_));
  AOI22x1_ASAP7_75t_R  g173(.A1(new_n190_), .A2(p4), .B1(new_n192_), .B2(new_n194_), .Y(new_n195_));
  AND3x1_ASAP7_75t_R   g174(.A(new_n149_), .B(p7), .C(new_n87_), .Y(new_n196_));
  NOR2x1_ASAP7_75t_R   g175(.A(p1), .B(new_n30_), .Y(new_n197_));
  AO21x1_ASAP7_75t_R   g176(.A1(new_n136_), .A2(new_n168_), .B(new_n197_), .Y(new_n198_));
  AO21x1_ASAP7_75t_R   g177(.A1(p5), .A2(new_n188_), .B(p8), .Y(new_n199_));
  AO21x1_ASAP7_75t_R   g178(.A1(p2), .A2(new_n22_), .B(p5), .Y(new_n200_));
  AO21x1_ASAP7_75t_R   g179(.A1(new_n23_), .A2(new_n187_), .B(new_n200_), .Y(new_n201_));
  NAND2x1_ASAP7_75t_R  g180(.A(new_n107_), .B(new_n201_), .Y(new_n202_));
  AOI221x1_ASAP7_75t_R g181(.A1(new_n181_), .A2(new_n196_), .B1(new_n198_), .B2(new_n199_), .C(new_n202_), .Y(new_n203_));
  AO21x1_ASAP7_75t_R   g182(.A1(new_n121_), .A2(new_n191_), .B(p4), .Y(new_n204_));
  AO21x1_ASAP7_75t_R   g183(.A1(new_n41_), .A2(new_n55_), .B(new_n107_), .Y(new_n205_));
  AND3x1_ASAP7_75t_R   g184(.A(new_n205_), .B(new_n25_), .C(new_n33_), .Y(new_n206_));
  OAI21x1_ASAP7_75t_R  g185(.A1(new_n107_), .A2(new_n204_), .B(new_n206_), .Y(new_n207_));
  AOI21x1_ASAP7_75t_R  g186(.A1(new_n195_), .A2(new_n203_), .B(new_n207_), .Y(new_n208_));
  AND3x1_ASAP7_75t_R   g187(.A(p0), .B(p8), .C(p1), .Y(new_n209_));
  NOR2x1_ASAP7_75t_R   g188(.A(p0), .B(new_n58_), .Y(new_n210_));
  OA21x2_ASAP7_75t_R   g189(.A1(new_n209_), .A2(new_n210_), .B(p5), .Y(new_n211_));
  INVx1_ASAP7_75t_R    g190(.A(new_n78_), .Y(new_n212_));
  NAND2x1_ASAP7_75t_R  g191(.A(new_n121_), .B(new_n212_), .Y(new_n213_));
  AO21x1_ASAP7_75t_R   g192(.A1(p1), .A2(new_n213_), .B(new_n182_), .Y(new_n214_));
  AND3x1_ASAP7_75t_R   g193(.A(new_n100_), .B(new_n24_), .C(p9), .Y(new_n215_));
  OA211x2_ASAP7_75t_R  g194(.A1(new_n211_), .A2(new_n214_), .B(p2), .C(new_n215_), .Y(new_n216_));
  AO21x1_ASAP7_75t_R   g195(.A1(p2), .A2(new_n41_), .B(new_n24_), .Y(new_n217_));
  AND2x2_ASAP7_75t_R   g196(.A(p9), .B(p7), .Y(new_n218_));
  AO32x1_ASAP7_75t_R   g197(.A1(new_n85_), .A2(new_n46_), .A3(new_n217_), .B1(new_n56_), .B2(new_n218_), .Y(new_n219_));
  OA21x2_ASAP7_75t_R   g198(.A1(p7), .A2(p8), .B(p1), .Y(new_n220_));
  OAI21x1_ASAP7_75t_R  g199(.A1(new_n220_), .A2(new_n138_), .B(new_n121_), .Y(new_n221_));
  AND2x2_ASAP7_75t_R   g200(.A(p7), .B(p8), .Y(new_n222_));
  AO21x1_ASAP7_75t_R   g201(.A1(p9), .A2(new_n222_), .B(new_n78_), .Y(new_n223_));
  OAI22x1_ASAP7_75t_R  g202(.A1(new_n223_), .A2(new_n24_), .B1(new_n169_), .B2(new_n209_), .Y(new_n224_));
  AOI21x1_ASAP7_75t_R  g203(.A1(new_n221_), .A2(new_n224_), .B(p2), .Y(new_n225_));
  AND3x1_ASAP7_75t_R   g204(.A(new_n75_), .B(new_n25_), .C(new_n107_), .Y(new_n226_));
  OA21x2_ASAP7_75t_R   g205(.A1(new_n219_), .A2(new_n225_), .B(new_n226_), .Y(new_n227_));
  AND2x2_ASAP7_75t_R   g206(.A(new_n114_), .B(new_n43_), .Y(new_n228_));
  AO22x1_ASAP7_75t_R   g207(.A1(p7), .A2(new_n181_), .B1(new_n153_), .B2(new_n37_), .Y(new_n229_));
  OAI21x1_ASAP7_75t_R  g208(.A1(new_n228_), .A2(new_n229_), .B(new_n215_), .Y(new_n230_));
  AO21x1_ASAP7_75t_R   g209(.A1(p6), .A2(new_n222_), .B(new_n33_), .Y(new_n231_));
  AO32x1_ASAP7_75t_R   g210(.A1(new_n231_), .A2(p0), .A3(new_n92_), .B1(new_n52_), .B2(new_n78_), .Y(new_n232_));
  NAND2x1_ASAP7_75t_R  g211(.A(new_n176_), .B(new_n232_), .Y(new_n233_));
  AOI21x1_ASAP7_75t_R  g212(.A1(new_n230_), .A2(new_n233_), .B(p1), .Y(new_n234_));
  OR4x2_ASAP7_75t_R    g213(.A(new_n208_), .B(new_n216_), .C(new_n227_), .D(new_n234_), .Y(o2));
  INVx1_ASAP7_75t_R    g214(.A(new_n100_), .Y(new_n236_));
  NAND2x1_ASAP7_75t_R  g215(.A(p4), .B(new_n27_), .Y(new_n237_));
  INVx1_ASAP7_75t_R    g216(.A(new_n237_), .Y(new_n238_));
  NAND2x1_ASAP7_75t_R  g217(.A(p2), .B(new_n24_), .Y(new_n239_));
  OA21x2_ASAP7_75t_R   g218(.A1(p5), .A2(new_n69_), .B(new_n239_), .Y(new_n240_));
  AO21x1_ASAP7_75t_R   g219(.A1(new_n238_), .A2(new_n136_), .B(new_n240_), .Y(new_n241_));
  NOR2x1_ASAP7_75t_R   g220(.A(p2), .B(new_n27_), .Y(new_n242_));
  AND2x2_ASAP7_75t_R   g221(.A(p4), .B(p7), .Y(new_n243_));
  OAI22x1_ASAP7_75t_R  g222(.A1(new_n242_), .A2(new_n243_), .B1(new_n58_), .B2(new_n27_), .Y(new_n244_));
  AOI21x1_ASAP7_75t_R  g223(.A1(new_n131_), .A2(new_n244_), .B(p8), .Y(new_n245_));
  OR3x1_ASAP7_75t_R    g224(.A(new_n241_), .B(new_n197_), .C(new_n245_), .Y(new_n246_));
  NOR2x1_ASAP7_75t_R   g225(.A(new_n22_), .B(new_n55_), .Y(new_n247_));
  OAI21x1_ASAP7_75t_R  g226(.A1(new_n78_), .A2(new_n247_), .B(new_n126_), .Y(new_n248_));
  AO21x1_ASAP7_75t_R   g227(.A1(p7), .A2(new_n94_), .B(new_n76_), .Y(new_n249_));
  AOI21x1_ASAP7_75t_R  g228(.A1(new_n248_), .A2(new_n249_), .B(p0), .Y(new_n250_));
  NOR2x1_ASAP7_75t_R   g229(.A(p5), .B(p4), .Y(new_n251_));
  OA21x2_ASAP7_75t_R   g230(.A1(new_n193_), .A2(new_n243_), .B(p2), .Y(new_n252_));
  OA21x2_ASAP7_75t_R   g231(.A1(new_n104_), .A2(new_n251_), .B(new_n252_), .Y(new_n253_));
  AO32x1_ASAP7_75t_R   g232(.A1(new_n46_), .A2(new_n156_), .A3(p4), .B1(p5), .B2(new_n44_), .Y(new_n254_));
  AND2x2_ASAP7_75t_R   g233(.A(new_n85_), .B(new_n254_), .Y(new_n255_));
  AND3x1_ASAP7_75t_R   g234(.A(new_n181_), .B(new_n126_), .C(p7), .Y(new_n256_));
  NOR2x1_ASAP7_75t_R   g235(.A(p4), .B(p8), .Y(new_n257_));
  OA21x2_ASAP7_75t_R   g236(.A1(new_n257_), .A2(new_n129_), .B(new_n197_), .Y(new_n258_));
  OR5x1_ASAP7_75t_R    g237(.A(new_n250_), .B(new_n253_), .C(new_n255_), .D(new_n256_), .E(new_n258_), .Y(new_n259_));
  AOI21x1_ASAP7_75t_R  g238(.A1(new_n155_), .A2(new_n246_), .B(new_n259_), .Y(new_n260_));
  AND5x1_ASAP7_75t_R   g239(.A(new_n75_), .B(p4), .C(p7), .D(p8), .E(p1), .Y(new_n261_));
  AO21x1_ASAP7_75t_R   g240(.A1(p7), .A2(new_n75_), .B(new_n24_), .Y(new_n262_));
  AO21x1_ASAP7_75t_R   g241(.A1(p5), .A2(new_n58_), .B(p2), .Y(new_n263_));
  AO32x1_ASAP7_75t_R   g242(.A1(new_n24_), .A2(p1), .A3(new_n78_), .B1(new_n262_), .B2(new_n263_), .Y(new_n264_));
  OA21x2_ASAP7_75t_R   g243(.A1(new_n261_), .A2(new_n264_), .B(p0), .Y(new_n265_));
  AND3x1_ASAP7_75t_R   g244(.A(new_n200_), .B(new_n41_), .C(new_n110_), .Y(new_n266_));
  AND3x1_ASAP7_75t_R   g245(.A(new_n24_), .B(p5), .C(p1), .Y(new_n267_));
  OR3x1_ASAP7_75t_R    g246(.A(new_n266_), .B(p3), .C(new_n267_), .Y(new_n268_));
  AO21x1_ASAP7_75t_R   g247(.A1(new_n251_), .A2(new_n222_), .B(new_n103_), .Y(new_n269_));
  AND3x1_ASAP7_75t_R   g248(.A(new_n269_), .B(new_n41_), .C(new_n55_), .Y(new_n270_));
  OA211x2_ASAP7_75t_R  g249(.A1(new_n107_), .A2(new_n270_), .B(new_n25_), .C(new_n33_), .Y(new_n271_));
  OAI21x1_ASAP7_75t_R  g250(.A1(new_n265_), .A2(new_n268_), .B(new_n271_), .Y(new_n272_));
  OAI21x1_ASAP7_75t_R  g251(.A1(new_n236_), .A2(new_n260_), .B(new_n272_), .Y(o3));
  OR3x1_ASAP7_75t_R    g252(.A(new_n38_), .B(p3), .C(new_n27_), .Y(new_n274_));
  NAND2x1_ASAP7_75t_R  g253(.A(p3), .B(new_n30_), .Y(new_n275_));
  NAND2x1_ASAP7_75t_R  g254(.A(p2), .B(new_n107_), .Y(new_n276_));
  INVx1_ASAP7_75t_R    g255(.A(new_n144_), .Y(new_n277_));
  AO21x1_ASAP7_75t_R   g256(.A1(new_n275_), .A2(new_n276_), .B(new_n277_), .Y(new_n278_));
  OR3x1_ASAP7_75t_R    g257(.A(new_n75_), .B(new_n24_), .C(p6), .Y(new_n279_));
  AOI21x1_ASAP7_75t_R  g258(.A1(new_n274_), .A2(new_n278_), .B(new_n279_), .Y(o4));
  AO21x1_ASAP7_75t_R   g259(.A1(new_n27_), .A2(new_n38_), .B(new_n276_), .Y(new_n281_));
  AND3x1_ASAP7_75t_R   g260(.A(new_n38_), .B(new_n55_), .C(p3), .Y(new_n282_));
  INVx1_ASAP7_75t_R    g261(.A(new_n282_), .Y(new_n283_));
  AOI21x1_ASAP7_75t_R  g262(.A1(new_n281_), .A2(new_n283_), .B(new_n279_), .Y(o5));
  NOR2x1_ASAP7_75t_R   g263(.A(p9), .B(new_n27_), .Y(new_n285_));
  NOR2x1_ASAP7_75t_R   g264(.A(new_n64_), .B(new_n285_), .Y(new_n286_));
  NAND2x1_ASAP7_75t_R  g265(.A(new_n33_), .B(new_n58_), .Y(new_n287_));
  AND3x1_ASAP7_75t_R   g266(.A(new_n181_), .B(new_n287_), .C(new_n163_), .Y(new_n288_));
  AOI221x1_ASAP7_75t_R g267(.A1(p8), .A2(new_n286_), .B1(new_n134_), .B2(new_n161_), .C(new_n288_), .Y(new_n289_));
  NAND2x1_ASAP7_75t_R  g268(.A(new_n22_), .B(new_n27_), .Y(new_n290_));
  NOR2x1_ASAP7_75t_R   g269(.A(p5), .B(p9), .Y(new_n291_));
  OR5x1_ASAP7_75t_R    g270(.A(p0), .B(new_n290_), .C(new_n127_), .D(new_n291_), .E(new_n243_), .Y(new_n292_));
  OAI21x1_ASAP7_75t_R  g271(.A1(new_n30_), .A2(new_n289_), .B(new_n292_), .Y(new_n293_));
  NOR2x1_ASAP7_75t_R   g272(.A(p0), .B(new_n78_), .Y(new_n294_));
  OR3x1_ASAP7_75t_R    g273(.A(new_n294_), .B(new_n33_), .C(new_n181_), .Y(new_n295_));
  NOR2x1_ASAP7_75t_R   g274(.A(new_n291_), .B(new_n49_), .Y(new_n296_));
  OR3x1_ASAP7_75t_R    g275(.A(new_n296_), .B(new_n37_), .C(new_n147_), .Y(new_n297_));
  AOI21x1_ASAP7_75t_R  g276(.A1(new_n295_), .A2(new_n297_), .B(new_n239_), .Y(new_n298_));
  NOR2x1_ASAP7_75t_R   g277(.A(new_n85_), .B(new_n42_), .Y(new_n299_));
  AO21x1_ASAP7_75t_R   g278(.A1(p1), .A2(new_n24_), .B(p5), .Y(new_n300_));
  AOI22x1_ASAP7_75t_R  g279(.A1(new_n299_), .A2(new_n238_), .B1(new_n42_), .B2(new_n300_), .Y(new_n301_));
  AND2x2_ASAP7_75t_R   g280(.A(p0), .B(p5), .Y(new_n302_));
  AO21x1_ASAP7_75t_R   g281(.A1(p8), .A2(new_n218_), .B(new_n220_), .Y(new_n303_));
  AND3x1_ASAP7_75t_R   g282(.A(new_n42_), .B(new_n210_), .C(p1), .Y(new_n304_));
  AOI21x1_ASAP7_75t_R  g283(.A1(new_n302_), .A2(new_n303_), .B(new_n304_), .Y(new_n305_));
  OAI21x1_ASAP7_75t_R  g284(.A1(new_n64_), .A2(new_n301_), .B(new_n305_), .Y(new_n306_));
  OR3x1_ASAP7_75t_R    g285(.A(new_n293_), .B(new_n298_), .C(new_n306_), .Y(new_n307_));
  NOR2x1_ASAP7_75t_R   g286(.A(p8), .B(new_n25_), .Y(new_n308_));
  OAI21x1_ASAP7_75t_R  g287(.A1(new_n58_), .A2(new_n308_), .B(new_n138_), .Y(new_n309_));
  AOI21x1_ASAP7_75t_R  g288(.A1(new_n95_), .A2(new_n309_), .B(p9), .Y(new_n310_));
  OA211x2_ASAP7_75t_R  g289(.A1(p0), .A2(new_n78_), .B(new_n27_), .C(p6), .Y(new_n311_));
  AND2x2_ASAP7_75t_R   g290(.A(new_n223_), .B(new_n311_), .Y(new_n312_));
  OAI21x1_ASAP7_75t_R  g291(.A1(new_n310_), .A2(new_n312_), .B(new_n251_), .Y(new_n313_));
  INVx1_ASAP7_75t_R    g292(.A(new_n257_), .Y(new_n314_));
  AO32x1_ASAP7_75t_R   g293(.A1(new_n86_), .A2(new_n104_), .A3(new_n122_), .B1(new_n193_), .B2(p4), .Y(new_n315_));
  AO32x1_ASAP7_75t_R   g294(.A1(p7), .A2(new_n314_), .A3(new_n285_), .B1(new_n315_), .B2(new_n218_), .Y(new_n316_));
  OR2x4_ASAP7_75t_R    g295(.A(new_n46_), .B(new_n139_), .Y(new_n317_));
  AO32x1_ASAP7_75t_R   g296(.A1(new_n33_), .A2(p8), .A3(p1), .B1(new_n78_), .B2(new_n41_), .Y(new_n318_));
  AO32x1_ASAP7_75t_R   g297(.A1(new_n317_), .A2(p5), .A3(new_n213_), .B1(p4), .B2(new_n318_), .Y(new_n319_));
  OAI21x1_ASAP7_75t_R  g298(.A1(new_n316_), .A2(new_n319_), .B(new_n25_), .Y(new_n320_));
  AOI21x1_ASAP7_75t_R  g299(.A1(new_n313_), .A2(new_n320_), .B(p2), .Y(new_n321_));
  OA21x2_ASAP7_75t_R   g300(.A1(new_n103_), .A2(new_n282_), .B(new_n25_), .Y(new_n322_));
  AOI221x1_ASAP7_75t_R g301(.A1(new_n100_), .A2(new_n307_), .B1(new_n321_), .B2(new_n107_), .C(new_n322_), .Y(o6));
  AO32x1_ASAP7_75t_R   g302(.A1(new_n212_), .A2(new_n285_), .A3(new_n121_), .B1(new_n161_), .B2(new_n308_), .Y(new_n324_));
  NAND3x1_ASAP7_75t_R  g303(.A(new_n324_), .B(new_n24_), .C(new_n63_), .Y(new_n325_));
  INVx1_ASAP7_75t_R    g304(.A(new_n325_), .Y(new_n326_));
  AO21x1_ASAP7_75t_R   g305(.A1(new_n60_), .A2(new_n326_), .B(new_n100_), .Y(new_n327_));
  NAND2x1_ASAP7_75t_R  g306(.A(p7), .B(new_n33_), .Y(new_n328_));
  OAI21x1_ASAP7_75t_R  g307(.A1(new_n76_), .A2(new_n328_), .B(new_n191_), .Y(new_n329_));
  AOI221x1_ASAP7_75t_R g308(.A1(new_n33_), .A2(p8), .B1(new_n116_), .B2(new_n58_), .C(new_n291_), .Y(new_n330_));
  AOI22x1_ASAP7_75t_R  g309(.A1(new_n329_), .A2(p8), .B1(new_n76_), .B2(new_n330_), .Y(new_n331_));
  NOR2x1_ASAP7_75t_R   g310(.A(p5), .B(new_n27_), .Y(new_n332_));
  AO21x1_ASAP7_75t_R   g311(.A1(p2), .A2(new_n121_), .B(new_n218_), .Y(new_n333_));
  AO32x1_ASAP7_75t_R   g312(.A1(new_n222_), .A2(new_n30_), .A3(p1), .B1(new_n153_), .B2(new_n104_), .Y(new_n334_));
  AOI21x1_ASAP7_75t_R  g313(.A1(new_n332_), .A2(new_n333_), .B(new_n334_), .Y(new_n335_));
  OAI21x1_ASAP7_75t_R  g314(.A1(p1), .A2(new_n331_), .B(new_n335_), .Y(new_n336_));
  AO21x1_ASAP7_75t_R   g315(.A1(p7), .A2(p8), .B(p5), .Y(new_n337_));
  NOR3x1_ASAP7_75t_R   g316(.A(new_n85_), .B(p1), .C(new_n337_), .Y(new_n338_));
  NAND2x1_ASAP7_75t_R  g317(.A(p5), .B(new_n33_), .Y(new_n339_));
  AOI21x1_ASAP7_75t_R  g318(.A1(new_n121_), .A2(new_n212_), .B(new_n339_), .Y(new_n340_));
  OAI21x1_ASAP7_75t_R  g319(.A1(new_n338_), .A2(new_n340_), .B(new_n168_), .Y(new_n341_));
  NOR3x1_ASAP7_75t_R   g320(.A(p9), .B(p7), .C(p1), .Y(new_n342_));
  AND3x1_ASAP7_75t_R   g321(.A(p5), .B(p9), .C(p7), .Y(new_n343_));
  OA21x2_ASAP7_75t_R   g322(.A1(new_n342_), .A2(new_n343_), .B(new_n22_), .Y(new_n344_));
  OA21x2_ASAP7_75t_R   g323(.A1(p5), .A2(new_n153_), .B(new_n220_), .Y(new_n345_));
  OAI21x1_ASAP7_75t_R  g324(.A1(new_n344_), .A2(new_n345_), .B(new_n41_), .Y(new_n346_));
  OR3x1_ASAP7_75t_R    g325(.A(new_n290_), .B(p7), .C(new_n82_), .Y(new_n347_));
  NAND3x1_ASAP7_75t_R  g326(.A(new_n341_), .B(new_n346_), .C(new_n347_), .Y(new_n348_));
  AOI21x1_ASAP7_75t_R  g327(.A1(p0), .A2(new_n336_), .B(new_n348_), .Y(new_n349_));
  OR3x1_ASAP7_75t_R    g328(.A(new_n73_), .B(new_n222_), .C(new_n78_), .Y(new_n350_));
  NOR2x1_ASAP7_75t_R   g329(.A(p0), .B(new_n24_), .Y(new_n351_));
  AND3x1_ASAP7_75t_R   g330(.A(new_n110_), .B(new_n83_), .C(new_n351_), .Y(new_n352_));
  OA21x2_ASAP7_75t_R   g331(.A1(p8), .A2(new_n27_), .B(new_n87_), .Y(new_n353_));
  NAND2x1_ASAP7_75t_R  g332(.A(p2), .B(new_n121_), .Y(new_n354_));
  OAI22x1_ASAP7_75t_R  g333(.A1(new_n353_), .A2(new_n287_), .B1(new_n237_), .B2(new_n354_), .Y(new_n355_));
  AND3x1_ASAP7_75t_R   g334(.A(p8), .B(p2), .C(p1), .Y(new_n356_));
  AO32x1_ASAP7_75t_R   g335(.A1(new_n67_), .A2(new_n52_), .A3(new_n69_), .B1(new_n243_), .B2(new_n356_), .Y(new_n357_));
  AOI221x1_ASAP7_75t_R g336(.A1(new_n350_), .A2(new_n352_), .B1(new_n355_), .B2(p0), .C(new_n357_), .Y(new_n358_));
  AND3x1_ASAP7_75t_R   g337(.A(new_n94_), .B(new_n290_), .C(new_n218_), .Y(new_n359_));
  NOR2x1_ASAP7_75t_R   g338(.A(p9), .B(new_n24_), .Y(new_n360_));
  AO32x1_ASAP7_75t_R   g339(.A1(new_n360_), .A2(p7), .A3(new_n22_), .B1(new_n102_), .B2(new_n62_), .Y(new_n361_));
  OAI21x1_ASAP7_75t_R  g340(.A1(new_n359_), .A2(new_n361_), .B(new_n53_), .Y(new_n362_));
  AO31x2_ASAP7_75t_R   g341(.A1(new_n358_), .A2(new_n362_), .A3(new_n325_), .B(p5), .Y(new_n363_));
  OAI21x1_ASAP7_75t_R  g342(.A1(p4), .A2(new_n349_), .B(new_n363_), .Y(new_n364_));
  AND3x1_ASAP7_75t_R   g343(.A(new_n282_), .B(new_n25_), .C(new_n24_), .Y(new_n365_));
  AND2x2_ASAP7_75t_R   g344(.A(new_n75_), .B(new_n365_), .Y(new_n366_));
  AOI21x1_ASAP7_75t_R  g345(.A1(new_n327_), .A2(new_n364_), .B(new_n366_), .Y(o7));
  OR3x1_ASAP7_75t_R    g346(.A(new_n41_), .B(new_n22_), .C(p2), .Y(new_n368_));
  OR3x1_ASAP7_75t_R    g347(.A(new_n237_), .B(p0), .C(p8), .Y(new_n369_));
  AO21x1_ASAP7_75t_R   g348(.A1(new_n368_), .A2(new_n369_), .B(p9), .Y(new_n370_));
  OA21x2_ASAP7_75t_R   g349(.A1(new_n41_), .A2(new_n24_), .B(new_n239_), .Y(new_n371_));
  AOI21x1_ASAP7_75t_R  g350(.A1(new_n149_), .A2(new_n290_), .B(new_n32_), .Y(new_n372_));
  AO32x1_ASAP7_75t_R   g351(.A1(new_n24_), .A2(p1), .A3(new_n63_), .B1(new_n37_), .B2(new_n242_), .Y(new_n373_));
  AOI21x1_ASAP7_75t_R  g352(.A1(new_n371_), .A2(new_n372_), .B(new_n373_), .Y(new_n374_));
  AOI21x1_ASAP7_75t_R  g353(.A1(new_n370_), .A2(new_n374_), .B(new_n130_), .Y(new_n375_));
  AO21x1_ASAP7_75t_R   g354(.A1(new_n41_), .A2(new_n212_), .B(new_n33_), .Y(new_n376_));
  AND2x2_ASAP7_75t_R   g355(.A(new_n75_), .B(new_n64_), .Y(new_n377_));
  AO21x1_ASAP7_75t_R   g356(.A1(p8), .A2(new_n41_), .B(new_n75_), .Y(new_n378_));
  AO21x1_ASAP7_75t_R   g357(.A1(new_n23_), .A2(new_n127_), .B(new_n378_), .Y(new_n379_));
  AOI221x1_ASAP7_75t_R g358(.A1(new_n376_), .A2(new_n377_), .B1(new_n379_), .B2(new_n27_), .C(new_n239_), .Y(new_n380_));
  OA21x2_ASAP7_75t_R   g359(.A1(p9), .A2(p2), .B(new_n182_), .Y(new_n381_));
  AND3x1_ASAP7_75t_R   g360(.A(new_n218_), .B(new_n24_), .C(new_n63_), .Y(new_n382_));
  OA211x2_ASAP7_75t_R  g361(.A1(p4), .A2(new_n127_), .B(new_n49_), .C(new_n87_), .Y(new_n383_));
  AOI211x1_ASAP7_75t_R g362(.A1(new_n371_), .A2(new_n381_), .B(new_n382_), .C(new_n383_), .Y(new_n384_));
  INVx1_ASAP7_75t_R    g363(.A(new_n104_), .Y(new_n385_));
  OAI21x1_ASAP7_75t_R  g364(.A1(p4), .A2(new_n27_), .B(new_n87_), .Y(new_n386_));
  AND3x1_ASAP7_75t_R   g365(.A(new_n74_), .B(p0), .C(new_n187_), .Y(new_n387_));
  AND3x1_ASAP7_75t_R   g366(.A(new_n197_), .B(new_n210_), .C(new_n162_), .Y(new_n388_));
  AOI21x1_ASAP7_75t_R  g367(.A1(new_n386_), .A2(new_n387_), .B(new_n388_), .Y(new_n389_));
  NAND2x1_ASAP7_75t_R  g368(.A(p8), .B(new_n75_), .Y(new_n390_));
  OAI22x1_ASAP7_75t_R  g369(.A1(new_n384_), .A2(new_n385_), .B1(new_n389_), .B2(new_n390_), .Y(new_n391_));
  OR3x1_ASAP7_75t_R    g370(.A(new_n375_), .B(new_n380_), .C(new_n391_), .Y(new_n392_));
  INVx1_ASAP7_75t_R    g371(.A(new_n365_), .Y(new_n393_));
  AND3x1_ASAP7_75t_R   g372(.A(new_n193_), .B(new_n33_), .C(new_n46_), .Y(new_n394_));
  NAND3x1_ASAP7_75t_R  g373(.A(new_n317_), .B(new_n33_), .C(new_n22_), .Y(new_n395_));
  NAND2x1_ASAP7_75t_R  g374(.A(new_n22_), .B(new_n161_), .Y(new_n396_));
  OA21x2_ASAP7_75t_R   g375(.A1(new_n94_), .A2(new_n287_), .B(new_n396_), .Y(new_n397_));
  AOI21x1_ASAP7_75t_R  g376(.A1(new_n395_), .A2(new_n397_), .B(p0), .Y(new_n398_));
  OAI21x1_ASAP7_75t_R  g377(.A1(new_n394_), .A2(new_n398_), .B(new_n176_), .Y(new_n399_));
  NAND2x1_ASAP7_75t_R  g378(.A(new_n393_), .B(new_n399_), .Y(new_n400_));
  AOI21x1_ASAP7_75t_R  g379(.A1(new_n100_), .A2(new_n392_), .B(new_n400_), .Y(o8));
  OR3x1_ASAP7_75t_R    g380(.A(new_n76_), .B(new_n163_), .C(new_n27_), .Y(new_n402_));
  AO21x1_ASAP7_75t_R   g381(.A1(new_n25_), .A2(new_n402_), .B(new_n294_), .Y(new_n403_));
  AO21x1_ASAP7_75t_R   g382(.A1(new_n33_), .A2(new_n242_), .B(new_n25_), .Y(new_n404_));
  OAI21x1_ASAP7_75t_R  g383(.A1(p4), .A2(new_n242_), .B(p5), .Y(new_n405_));
  OR3x1_ASAP7_75t_R    g384(.A(new_n110_), .B(p0), .C(new_n33_), .Y(new_n406_));
  AND5x1_ASAP7_75t_R   g385(.A(new_n403_), .B(new_n205_), .C(new_n404_), .D(new_n405_), .E(new_n406_), .Y(new_n407_));
  OR5x1_ASAP7_75t_R    g386(.A(p2), .B(new_n72_), .C(new_n78_), .D(new_n257_), .E(new_n27_), .Y(new_n408_));
  OA21x2_ASAP7_75t_R   g387(.A1(new_n251_), .A2(new_n275_), .B(new_n27_), .Y(new_n409_));
  AO21x1_ASAP7_75t_R   g388(.A1(p4), .A2(p8), .B(p5), .Y(new_n410_));
  AO221x2_ASAP7_75t_R  g389(.A1(p5), .A2(p8), .B1(new_n127_), .B2(new_n410_), .C(new_n30_), .Y(new_n411_));
  NAND2x1_ASAP7_75t_R  g390(.A(new_n409_), .B(new_n411_), .Y(new_n412_));
  AO21x1_ASAP7_75t_R   g391(.A1(new_n408_), .A2(new_n412_), .B(p0), .Y(new_n413_));
  AND3x1_ASAP7_75t_R   g392(.A(new_n73_), .B(new_n121_), .C(new_n251_), .Y(new_n414_));
  AND3x1_ASAP7_75t_R   g393(.A(new_n130_), .B(new_n30_), .C(new_n410_), .Y(new_n415_));
  NOR2x1_ASAP7_75t_R   g394(.A(new_n414_), .B(new_n415_), .Y(new_n416_));
  AO21x1_ASAP7_75t_R   g395(.A1(new_n24_), .A2(new_n22_), .B(p2), .Y(new_n417_));
  AO221x2_ASAP7_75t_R  g396(.A1(p2), .A2(new_n116_), .B1(new_n417_), .B2(new_n328_), .C(p1), .Y(new_n418_));
  AO21x1_ASAP7_75t_R   g397(.A1(new_n416_), .A2(new_n418_), .B(new_n41_), .Y(new_n419_));
  AND3x1_ASAP7_75t_R   g398(.A(new_n407_), .B(new_n413_), .C(new_n419_), .Y(o9));
  OR3x1_ASAP7_75t_R    g399(.A(new_n181_), .B(new_n58_), .C(new_n155_), .Y(new_n421_));
  AND5x1_ASAP7_75t_R   g400(.A(new_n25_), .B(new_n43_), .C(new_n107_), .D(p2), .E(new_n251_), .Y(new_n422_));
  AO32x1_ASAP7_75t_R   g401(.A1(new_n178_), .A2(new_n421_), .A3(new_n422_), .B1(new_n365_), .B2(new_n75_), .Y(o10));
endmodule


