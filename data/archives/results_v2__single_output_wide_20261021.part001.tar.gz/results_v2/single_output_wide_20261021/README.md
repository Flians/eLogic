# Full single-output library experiment (isolated, not promoted)

Initial current-main prototype is sealed at12/40; do not continue its matrix. Source audit found that its old main base does not implement the frontend-requested force-compact kernel option. Actual native import-policy records are authoritative. The following old command is retained for provenance only; a separate source_kernels followup preserves the validated K6 kernel base. See source_policy_audit.json.

Small cuts retain the existing <=6-input enumeration. The seven 7–9-input ASAP7 cells bypass the permutation index and use signed structural matching against their expressions and exact actual-support AND/OR decompositions. This is a bounded, incomplete matcher, not exhaustive wide-cut or NPN enumeration. Physical pin order, dependent arcs, deduplication, export, and binding evidence carry the wide function. Unused formal pins are tied to zero; reduced truth tables use actual support.

`implementation.json`, `base_hashes.json`, `implementation.patch`, and `source_freeze.json` record source and protocol. The source is copied from the current main files, not relabelled from the earlier K6 kernel prototypes. Production and baseline source files remain unchanged. The common metric code is unchanged; the isolated evaluator only widens the library loader. `regression-final2.log`: 194 passed, 5 ignored. `wide_cell_cec/report.json`: all seven real wide-cell fixtures passed exhaustive assignments and independent named-port CEC.

The EPFL matrix has 40 planned cases (20 designs x off/on, one binary and full47 library). rho=1/2 is uniform, not the heterogeneous historical schedule. Full mapping=300s; the existing native60s guard, global2s recovery, cumulative B+ceil(B/2) enode admission, cuts16/class, SAT16 iterations, and 100000 retained native candidates remain. Wide matches add no enodes and enter the common physical-pool cap. Generated transient candidates are not a resident memory cap.

Continue finite, sequential batches (do not overlap other campaigns):

```sh
python3 scripts/experiments/campaigns/run_wide_cells_campaign.py --kind mapper --mode wide-cells --output results_v2/single_output_wide_20261021/epfl_campaign --subjects results_v2/epfl_resyn2_subjects_20261012/report.json --frontend-root /home/flynn/workplace/MIGBalance --research-root results_v2/single_output_wide_20261021/source --native results_v2/single_output_wide_20261021/source/target/release/bench_rs_egraph_wide --template results_v2/single_output_k6_20261020/resume_recovery/representation_template.json --verification-cache results_v2/single_output_k6_20261020/verification_cache.json --max-jobs 4
```

New full-library original baselines (fresh cohort, not adopted from K6):

```sh
python3 scripts/experiments/campaigns/run_wide_original_baselines.py --kind baseline --mode wide-cells --output results_v2/single_output_wide_20261021/original_baselines --subjects results_v2/epfl_resyn2_subjects_20261012/report.json --frontend-root /home/flynn/workplace/MIGBalance --research-root results_v2/single_output_wide_20261021/source_kernels --max-jobs 2
```

The original per-tool K6 settings/search/model/author algorithms remain unchanged. Only the provided library range and common model loader are widened. Author tools may internally restrict supported cells or fail; preserve these outcomes and native logs rather than modifying them. The legacy filename `asap7_6in.genlib` records the existing driver K, not the new library range: its contents and library.json are47-cell full-library input. Confirm identical library hashes before comparison.

Do not relabel the completed restricted40-cell baseline120 as full47-cell results. `report_wide_cells.py` preserves all20 designs, missing/failed observations, A/D/T, CEC, and source-only versus optimized outcomes. Confirmation and repetitions are required before main/paper promotion. Initial adder/bar cases have zero admitted wide candidates and no A/D gain; the bounded matcher exhausted its work allowance. Div returned only the protected primitive source after native timeout. These are limitations, not successful optimizations.

## Validated-kernel full scope (complete first round)

`kernel_epfl_campaign` has40/40 cases, fresh independent named-port CEC40/40. See `kernel_full40_report/A_D_T.csv`, `kernel_full40_summary.json`, and `kernel_implementation.json`. Wide off/on both use the f865 kernel base and a uniform rho1/2. Native optimization succeeds on16/15 designs, respectively; primitive fallback is not optimization success. Raw D comparison:1 better,18 equal,1 worse. The multiplier gain is unconfirmed by repetitions; sin native timeout and sqrt area regression preclude promotion. The first main-source12 cases are never mixed into this study.

An exact name-filtered seed index is now isolated in `source_index_filter`. Tests:232 passed/5 ignored/3 unrelated legacy synthesizer tests filtered, with the initial interrupted broad log retained. The complete candidate/evidence oracle preserves order and pin/timing/function/target data; unrelated small cells cannot collide with a new wide cell because the physical key includes the cell name. Targeted sin/sqrt timing checks precede any next full-scope matrix. Production mapper and paper remain unchanged.
