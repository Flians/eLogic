# Isolated fixed-bound actual-area recovery

Not a production promotion. Same prepared EPFL AIGs and inventories as the
previous regional cuts prototype. One global import, candidate pool and two-second
construction/recovery/final-validation window. Strict legacy cumulative import
eligibility is reported separately from resident usage; retirement does not
solve multiplier's cumulative overrun.

Retains the best-delay plan plus one minimum-cell-area proposal per phase.
At each region boundary, proposal dependencies are committed in the same global
pool. Proposals, pending dependencies and prefix cells are checked against
100000; no per-region allowance reset. All exact-cut matching and input phases
are unchanged. Recovery starts only after complete-cover validation and freezes
that cover's delay. Required times use dependent pin delays and a descending
arrival order (positive-delay libraries only). Trials recompute global unique
physical area and delay, reject cycles, and atomically restore the old binding
unless area strictly falls and the fixed delay bound holds. A 0.15-second return
reserve and previous-trial cost estimate remain inside the two-second window.
A running trial cannot be preempted: a global overrun is a failure, never a proof
of budget compliance. No global optimality claim.

This protects the regional incumbent, not the production mapper's result. Added
proposal construction may change budget availability and full-suite outcomes.
No per-design selection between production, V2, V3 or V4 is permitted. V3 failed
target attempts are preserved separately. Six unit tests cover truth tables,
indexed phases, region boundaries, constants and deadline/cycle/bound rejection.
