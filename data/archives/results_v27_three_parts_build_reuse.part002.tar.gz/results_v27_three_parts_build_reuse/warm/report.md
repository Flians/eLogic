# Three-part constrained-area experiments

Every selected implementation satisfies its own initial area/delay bounds and has CEC evidence; native optimizer completions and independently validated deadline selections are counted separately.
ABC raw area-mode outputs are preserved. The guarded comparison reverts an infeasible completed output to its native initial mapping; it is an external output-selection policy, not an internal mfs3 timing constraint. ABC timeouts are excluded from the ABC-completed paired subset; our native timeout selections remain included as independently validated netlists under the declared selection policy.

{
  "whole_window_synthesis": false,
  "engine_cec_outputs": 257,
  "baseline_cec_outputs": 16,
  "main_own_area": -7.469263562419483,
  "main_own_delay": -6.8598032509242035,
  "main_one_area": -5.276638767412135,
  "main_one_delay": -4.622022661097069,
  "main_other_area": -3.973812759631058,
  "main_other_delay": -2.393283368439586,
  "main_area_wins": 16,
  "reference_area": -9.421740479530966,
  "reference_delay": -6.290960876708059,
  "reference_wins": 13,
  "mfs_ours_area": -6.095774201145257,
  "mfs_ours_delay": -5.520336641682567,
  "abc_completed": 13,
  "abc_timeouts": 3,
  "abc_feasible": 6,
  "abc_delay_violations": 7,
  "cut_oracle_times": {
    "secs_stage1": 586.2545153130002,
    "secs_stage2": 195.37581366,
    "secs_synth": 892.8627118360001,
    "secs_egg": 145.81067783700001,
    "secs_care": 33.799817676,
    "secs_window": 0.0,
    "secs_chain": 0.057353603
  },
  "method_timeouts": 47,
  "selected_cec_outputs": 304,
  "phase_timed_full_runs": 13,
  "method_checkpoint_selections": 47,
  "full_main_ppa_equal": {
    "aes_core": true,
    "arbiter": true,
    "div": true,
    "ethernet": true,
    "iwls05_i2c": true,
    "mem_ctrl": false,
    "RISC": true,
    "sasc": true,
    "simple_spi": true,
    "spi": true,
    "sqrt": false,
    "systemcaes": true,
    "systemcdes": true,
    "tv80": true,
    "usb_funct": true,
    "usb_phy": true
  },
  "cofactor_activity": {
    "aes_core": {
      "cofactor_wins": 509,
      "secs_cofactor": 147.7243683,
      "available": true
    },
    "arbiter": {
      "cofactor_wins": 0,
      "secs_cofactor": 2.500710073,
      "available": true
    },
    "div": {
      "cofactor_wins": 0,
      "secs_cofactor": 0.0,
      "available": false
    },
    "ethernet": {
      "cofactor_wins": 9365,
      "secs_cofactor": 57.71806766,
      "available": true
    },
    "iwls05_i2c": {
      "cofactor_wins": 57,
      "secs_cofactor": 6.945210787,
      "available": true
    },
    "mem_ctrl": {
      "cofactor_wins": 0,
      "secs_cofactor": 0.0,
      "available": false
    },
    "RISC": {
      "cofactor_wins": 4373,
      "secs_cofactor": 209.7177564,
      "available": true
    },
    "sasc": {
      "cofactor_wins": 62,
      "secs_cofactor": 2.456309262,
      "available": true
    },
    "simple_spi": {
      "cofactor_wins": 76,
      "secs_cofactor": 4.275124338,
      "available": true
    },
    "spi": {
      "cofactor_wins": 193,
      "secs_cofactor": 22.37510948,
      "available": true
    },
    "sqrt": {
      "cofactor_wins": 0,
      "secs_cofactor": 0.0,
      "available": false
    },
    "systemcaes": {
      "cofactor_wins": 1363,
      "secs_cofactor": 49.49604068,
      "available": true
    },
    "systemcdes": {
      "cofactor_wins": 129,
      "secs_cofactor": 36.4136869,
      "available": true
    },
    "tv80": {
      "cofactor_wins": 349,
      "secs_cofactor": 61.10798847,
      "available": true
    },
    "usb_funct": {
      "cofactor_wins": 751,
      "secs_cofactor": 51.17988442,
      "available": true
    },
    "usb_phy": {
      "cofactor_wins": 29,
      "secs_cofactor": 3.294506684,
      "available": true
    }
  },
  "cofactor_seconds": 667.3685645320002,
  "abc_raw_area": -3.575691302200082,
  "abc_guarded_area": -1.5940348664441888,
  "paired_ours_area": -7.1039748788783665,
  "abc_raw_delay": 11.018744353868293,
  "abc_guarded_delay": -0.14558063949823968,
  "paired_ours_delay": -6.710450890568751,
  "paired_area_wins": 7,
  "guarded_paired_area_wins": 11,
  "ablation": {
    "full": {
      "area": 0.0,
      "worse": 0,
      "better": 0,
      "own_area": -7.461022865285473,
      "own_delay": -6.857207814710836,
      "optimizer_seconds": 4940.389268346999,
      "time_ratio": 1.0
    },
    "noSYN": {
      "area": 365.63000000000005,
      "worse": 16,
      "better": 0,
      "own_area": -3.891128086285673,
      "own_delay": -5.566112344130611,
      "optimizer_seconds": 3190.573935859,
      "time_ratio": 0.6458142795145637
    },
    "noEGG": {
      "area": 1.6100000000002979,
      "worse": 9,
      "better": 2,
      "own_area": -7.414374963194939,
      "own_delay": -6.855076426477774,
      "optimizer_seconds": 4778.551298278,
      "time_ratio": 0.9672418586312839
    },
    "noDB": {
      "area": -71.73000000000025,
      "worse": 5,
      "better": 8,
      "own_area": -7.826469506985993,
      "own_delay": -7.228854612271354,
      "optimizer_seconds": 3931.7467870360006,
      "time_ratio": 0.7958374479166336
    },
    "noCARE": {
      "area": 1.8200000000000855,
      "worse": 12,
      "better": 2,
      "own_area": -7.434537586462854,
      "own_delay": -6.71244470270942,
      "optimizer_seconds": 4734.392681858001,
      "time_ratio": 0.9583035717835403
    },
    "noCHAIN": {
      "area": 333.0300000000003,
      "worse": 1,
      "better": 2,
      "own_area": -3.7224793918228505,
      "own_delay": -2.2419513272312974,
      "optimizer_seconds": 4913.895070342,
      "time_ratio": 0.9946372246060148
    },
    "noSHARE": {
      "area": 334.6500000000002,
      "worse": 2,
      "better": 1,
      "own_area": -3.7137522113740444,
      "own_delay": -2.2411077216987443,
      "optimizer_seconds": 4922.812051704999,
      "time_ratio": 0.9964421393361416
    },
    "noNARROW": {
      "area": 2.4999999999997726,
      "worse": 6,
      "better": 0,
      "own_area": -7.449434800043028,
      "own_delay": -6.855679667315168,
      "optimizer_seconds": 5334.309525977001,
      "time_ratio": 1.07973465980785
    },
    "noPHASE": {
      "area": 200.4999999999999,
      "worse": 14,
      "better": 1,
      "own_area": -5.186139834047683,
      "own_delay": -6.548516935179661,
      "optimizer_seconds": 2836.2695918809995,
      "time_ratio": 0.5740984035515049
    },
    "noSHANNON": {
      "area": 143.05000000000035,
      "worse": 14,
      "better": 1,
      "own_area": -6.143094533069589,
      "own_delay": -6.950618101890372,
      "optimizer_seconds": 4574.8129102540015,
      "time_ratio": 0.9260025195918791
    },
    "noDAVIO": {
      "area": 75.94999999999976,
      "worse": 12,
      "better": 1,
      "own_area": -6.350916243808012,
      "own_delay": -6.630626100668902,
      "optimizer_seconds": 4205.295976447001,
      "time_ratio": 0.8512074146444835
    },
    "noREUSE": {
      "area": 186.90000000000012,
      "worse": 14,
      "better": 1,
      "own_area": -5.295770762427696,
      "own_delay": -7.0316386476083625,
      "optimizer_seconds": 3056.829730913,
      "time_ratio": 0.6187426870384612
    },
    "noPRICE": {
      "area": 114.45999999999967,
      "worse": 14,
      "better": 1,
      "own_area": -6.03558290680311,
      "own_delay": -6.548825286210618,
      "optimizer_seconds": 2720.7796107890003,
      "time_ratio": 0.5507217069353209
    },
    "cache64K": {
      "area": 1.900000000000091,
      "worse": 1,
      "better": 1,
      "own_area": -7.457280902031908,
      "own_delay": -6.758717546038532,
      "optimizer_seconds": 6580.505277753999,
      "time_ratio": 1.3319811294861315
    },
    "noAIGREUSE": {
      "area": -1.3899999999998727,
      "worse": 0,
      "better": 2,
      "own_area": -7.468129535565727,
      "own_delay": -6.8598032509242035,
      "optimizer_seconds": 5221.092975498,
      "time_ratio": 1.056818135556537
    },
    "noLIBSHARE": {
      "area": 0.5499999999999545,
      "worse": 1,
      "better": 1,
      "own_area": -7.460576000002849,
      "own_delay": -6.756965715357717,
      "optimizer_seconds": 5018.406995695001,
      "time_ratio": 1.015791817832627
    }
  },
  "chain_activity": {
    "aes_core": {
      "chain_wins": 0,
      "secs_chain": 0.0,
      "available": true
    },
    "arbiter": {
      "chain_wins": 384,
      "secs_chain": 0.055561211,
      "available": true
    },
    "div": {
      "chain_wins": 0,
      "secs_chain": 0.0,
      "available": false
    },
    "ethernet": {
      "chain_wins": 0,
      "secs_chain": 0.0,
      "available": true
    },
    "iwls05_i2c": {
      "chain_wins": 0,
      "secs_chain": 0.0,
      "available": true
    },
    "mem_ctrl": {
      "chain_wins": 0,
      "secs_chain": 0.0,
      "available": false
    },
    "RISC": {
      "chain_wins": 0,
      "secs_chain": 0.0,
      "available": true
    },
    "sasc": {
      "chain_wins": 0,
      "secs_chain": 0.0,
      "available": true
    },
    "simple_spi": {
      "chain_wins": 0,
      "secs_chain": 0.0,
      "available": true
    },
    "spi": {
      "chain_wins": 0,
      "secs_chain": 0.0,
      "available": true
    },
    "sqrt": {
      "chain_wins": 0,
      "secs_chain": 0.0,
      "available": false
    },
    "systemcaes": {
      "chain_wins": 0,
      "secs_chain": 0.0,
      "available": true
    },
    "systemcdes": {
      "chain_wins": 0,
      "secs_chain": 0.0,
      "available": true
    },
    "tv80": {
      "chain_wins": 0,
      "secs_chain": 0.0,
      "available": true
    },
    "usb_funct": {
      "chain_wins": 0,
      "secs_chain": 0.0,
      "available": true
    },
    "usb_phy": {
      "chain_wins": 0,
      "secs_chain": 0.0,
      "available": true
    }
  }
}

## Per-design fully preprocessed results

| Design | A0 | D0 | A | D | dA % | dD % |
| --- | --- | --- | --- | --- | --- | --- |
| aes_core | 1029.98 | 410.72 | 995.55 | 407.28 | -3.34 | -0.84 |
| arbiter | 557.72 | 999.87 | 223.64 | 261.39 | -59.90 | -73.86 |
| div | 1184.5 | 53105.06 | 1183.07 | 53053.05 | -0.12 | -0.10 |
| ethernet | 2541.41 | 543.88 | 2531.03 | 543.56 | -0.41 | -0.06 |
| iwls05_i2c | 47.66 | 303.61 | 45.08 | 290.02 | -5.41 | -4.48 |
| mem_ctrl | 1895.4 | 1519.75 | 1817.66 | 1454.78 | -4.10 | -4.28 |
| RISC | 2927.19 | 1453.77 | 2804.17 | 1392.91 | -4.20 | -4.19 |
| sasc | 27.28 | 191.2 | 26.74 | 191.2 | -1.98 | +0.00 |
| simple_spi | 36.96 | 308.22 | 35.89 | 293.36 | -2.90 | -4.82 |
| spi | 149.43 | 500.98 | 144.5 | 461.16 | -3.30 | -7.95 |
| sqrt | 1157.38 | 88015.07 | 1138.59 | 87523.64 | -1.62 | -0.56 |
| systemcaes | 483.75 | 709.03 | 425.74 | 683.44 | -11.99 | -3.61 |
| systemcdes | 131.06 | 488.85 | 121.32 | 487.52 | -7.43 | -0.27 |
| tv80 | 340.61 | 846.12 | 328.16 | 833.94 | -3.66 | -1.44 |
| usb_funct | 646.23 | 668.08 | 620.41 | 664.77 | -4.00 | -0.50 |
| usb_phy | 22.54 | 163.29 | 21.38 | 158.68 | -5.15 | -2.82 |
