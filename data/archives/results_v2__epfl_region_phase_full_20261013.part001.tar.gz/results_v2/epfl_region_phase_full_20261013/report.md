# Region and atomic phase recovery

All 20 EPFL designs remain in this report, including budget failures. Inputs reuse the one verified resyn2 AIG. The comparison is against the same native binary with experimental options disabled, not a claim of baseline dominance.

Attempted jobs: 160/160. Verified pairs: 44; delay better/equal/worse: 9/26/9.

|Library|Objective|Design|Control area|Control delay|Candidate area|Candidate delay|Status|
|---|---|---|---:|---:|---:|---:|---|
|3|area-delay|adder|65.01|3701.61|62.88|3944.30|ok/ok|
|3|area-delay|bar|221.79|252.49|220.03|252.49|ok/ok|
|3|area-delay|div|—|—|—|—|failed/failed|
|3|area-delay|hyp|—|—|—|—|failed/failed|
|3|area-delay|log2|—|—|—|—|failed/failed|
|3|area-delay|max|284.52|3373.74|292.27|3303.60|ok/ok|
|3|area-delay|multiplier|—|—|—|—|failed/failed|
|3|area-delay|sin|525.24|3271.53|570.20|3138.50|ok/ok|
|3|area-delay|sqrt|—|—|—|—|failed/failed|
|3|area-delay|square|—|—|—|—|failed/failed|
|3|area-delay|arbiter|—|—|—|—|failed/failed|
|3|area-delay|cavlc|39.73|262.80|39.79|262.80|ok/ok|
|3|area-delay|ctrl|7.05|134.48|7.05|134.48|ok/ok|
|3|area-delay|dec|27.59|91.66|27.59|91.66|ok/ok|
|3|area-delay|i2c|73.35|244.72|73.35|244.72|ok/ok|
|3|area-delay|int2float|13.21|235.71|13.26|235.71|ok/ok|
|3|area-delay|mem_ctrl|—|—|—|—|failed/failed|
|3|area-delay|priority|49.51|2679.51|49.56|2744.19|ok/ok|
|3|area-delay|router|11.41|327.51|11.44|340.73|ok/ok|
|3|area-delay|voter|—|—|—|—|failed/failed|
|3|delay-area|adder|76.83|3016.20|76.25|2849.22|ok/ok|
|3|delay-area|bar|298.45|191.85|295.43|191.85|ok/ok|
|3|delay-area|div|—|—|—|—|failed/failed|
|3|delay-area|hyp|—|—|—|—|failed/failed|
|3|delay-area|log2|—|—|—|—|failed/failed|
|3|delay-area|max|294.52|2735.12|279.84|2587.75|ok/ok|
|3|delay-area|multiplier|—|—|—|—|failed/failed|
|3|delay-area|sin|667.48|2806.05|717.38|2776.23|ok/ok|
|3|delay-area|sqrt|—|—|—|—|failed/failed|
|3|delay-area|square|—|—|—|—|failed/failed|
|3|delay-area|arbiter|—|—|—|—|failed/failed|
|3|delay-area|cavlc|46.52|197.59|46.59|197.59|ok/ok|
|3|delay-area|ctrl|7.76|108.06|7.78|108.06|ok/ok|
|3|delay-area|dec|27.68|82.92|27.68|82.92|ok/ok|
|3|delay-area|i2c|83.88|166.78|83.95|166.78|ok/ok|
|3|delay-area|int2float|14.47|183.34|14.47|183.34|ok/ok|
|3|delay-area|mem_ctrl|—|—|—|—|failed/failed|
|3|delay-area|priority|70.72|2062.18|70.89|2062.18|ok/ok|
|3|delay-area|router|13.94|216.40|13.94|216.40|ok/ok|
|3|delay-area|voter|—|—|—|—|failed/failed|
|4|area-delay|adder|61.80|4132.12|61.85|4124.03|ok/ok|
|4|area-delay|bar|232.72|264.75|273.96|284.38|ok/ok|
|4|area-delay|div|—|—|—|—|failed/failed|
|4|area-delay|hyp|—|—|—|—|failed/failed|
|4|area-delay|log2|—|—|—|—|failed/failed|
|4|area-delay|max|254.62|3492.88|307.42|3540.43|ok/ok|
|4|area-delay|multiplier|—|—|—|—|failed/failed|
|4|area-delay|sin|512.13|3032.55|553.00|3063.43|ok/ok|
|4|area-delay|sqrt|—|—|—|—|failed/failed|
|4|area-delay|square|—|—|—|—|failed/failed|
|4|area-delay|arbiter|—|—|—|—|failed/failed|
|4|area-delay|cavlc|39.03|257.29|39.11|257.29|ok/ok|
|4|area-delay|ctrl|6.90|127.29|6.90|127.29|ok/ok|
|4|area-delay|dec|27.41|91.20|27.41|91.20|ok/ok|
|4|area-delay|i2c|73.01|246.32|72.62|223.12|ok/ok|
|4|area-delay|int2float|12.83|234.41|12.86|234.41|ok/ok|
|4|area-delay|mem_ctrl|—|—|—|—|failed/failed|
|4|area-delay|priority|50.10|2931.86|50.64|2907.17|ok/ok|
|4|area-delay|router|10.39|329.95|10.38|309.69|ok/ok|
|4|area-delay|voter|—|—|—|—|failed/failed|
|4|delay-area|adder|82.22|3550.84|83.36|3561.91|ok/ok|
|4|delay-area|bar|325.28|191.11|322.35|191.11|ok/ok|
|4|delay-area|div|—|—|—|—|failed/failed|
|4|delay-area|hyp|—|—|—|—|failed/failed|
|4|delay-area|log2|—|—|—|—|failed/failed|
|4|delay-area|max|269.86|3090.61|323.77|3102.43|ok/ok|
|4|delay-area|multiplier|—|—|—|—|failed/failed|
|4|delay-area|sin|703.93|2640.42|733.75|2689.54|ok/ok|
|4|delay-area|sqrt|—|—|—|—|failed/failed|
|4|delay-area|square|—|—|—|—|failed/failed|
|4|delay-area|arbiter|—|—|—|—|failed/failed|
|4|delay-area|cavlc|45.72|194.95|45.83|194.95|ok/ok|
|4|delay-area|ctrl|7.56|103.17|7.56|103.17|ok/ok|
|4|delay-area|dec|29.54|66.15|29.54|66.15|ok/ok|
|4|delay-area|i2c|82.77|176.27|82.09|176.27|ok/ok|
|4|delay-area|int2float|14.08|182.22|14.14|182.22|ok/ok|
|4|delay-area|mem_ctrl|—|—|—|—|failed/failed|
|4|delay-area|priority|61.04|2047.24|59.98|2047.24|ok/ok|
|4|delay-area|router|13.55|199.00|13.55|199.00|ok/ok|
|4|delay-area|voter|—|—|—|—|failed/failed|

Failed cases retain command logs and reports in the checkpoint campaign. Node limits are global; regions do not receive separate budgets. Area increases and all delay regressions remain reported.
