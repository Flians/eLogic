#!/usr/bin/env python3
"""Explicit adoption of identical actual component runs, preserving reports/failures."""
import argparse,copy,hashlib,json
from pathlib import Path
from run_epfl_baselines import EPFL
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--donor',type=Path,required=True);ap.add_argument('--output',type=Path,required=True);ap.add_argument('--components',action='store_true');ap.add_argument('--module-controller',action='store_true');a=ap.parse_args();d=json.loads(a.donor.read_text());assert d['status']=='attempted' and len(d['jobs'])==d['expected_jobs'];assert not a.output.exists()
 for p,h in d['fingerprint'].items():assert sha(p)==h,p
 factors={'legacy_control':[0,0],'protected_area':[0,1]}
 if a.components:factors={k:[0,1] for k in ['protected_area','single_structure','no_input_phase','canonical_pins','no_sdc','no_actual_area','no_phase_recovery']}
 if a.module_controller:
  assert a.components
  raise RuntimeError('Clean component native V28 differs from V27 guard: mapped outputs cannot be adopted across binary versions; run fresh full component matrix.')
  factors={k:[0,0] for k in [*factors,'no_timing_area_module']}
 if a.module_controller:
  jobs=[dict(copy.deepcopy(j),profile='protected_area',original_profile='legacy_control',name=f"{j['k']}in_{j['bench']}_protected_area") for j in d['jobs'] if j['profile']=='legacy_control']
 else:jobs=[copy.deepcopy(j) for j in d['jobs'] if j['profile'] in factors]
 # Only identical protected_area observations enter a component study. No source,
 # binary, model, input, cell library or effective native setting changes.
 if a.components:assert all(j['profile']=='protected_area' for j in jobs)
 for j in jobs:
  for k in ['report','audit','pool','candidates','trace','pool_frontier','pool_guard','helper_allocation']:
   if k in j:assert sha(j[k])==j[k+'_sha256']
  r=json.loads(Path(j['report']).read_text())['results'][0];s=r['settings'];assert s['EGM_REFRESH_AREA_TIMING']=='0';assert s['EGM_TAIL_SHARED_AREA']==str(factors[j['profile']][1])
  assert all(s[k]=='0' for k in ['EGM_SINGLE_STRUCTURE_CUTS','EGM_NO_INPUT_PHASE_MATCHES','EGM_CANONICAL_PIN_MATCHING','EGM_NO_ACTUAL_AREA_TAIL']);assert s['EGM_DC_SUPPORT']=='4' and s['EGM_PHASE_RECOVERY']=='1'
  j.update(adopted_from=str(a.donor.resolve()),adopted_campaign_sha256=sha(a.donor),adoption_basis='Exact same source/binary/driver/harness/input/library and effective native parameters. Only requested full-scope/profile bookkeeping differs; physical attempt counted once.')
 c=copy.deepcopy(d);c.update(jobs=jobs,factors=factors,fixed_profiles={k:copy.deepcopy(d['fixed_profiles']['protected_area']) for k in factors},expected_jobs=40*len(factors),designs=EPFL,components=a.components,status='checkpointed',reverse_order=False,adoption={'donor':str(a.donor.resolve()),'sha256':sha(a.donor),'count':len(jobs),'same_fingerprint':True,'no_duplicate_observation_count':True})
 if a.module_controller:
  old=Path(__file__).with_name('run_single_output_components.py').resolve();new=Path(__file__).with_name('run_single_output_component_module.py').resolve()
  assert c['fingerprint'].pop(str(old))==sha(old)
  c['fingerprint'][str(new)]=sha(new)
  c['adoption']['same_fingerprint']=False
  c['adoption']['reference_profile_map']={'legacy_control':'protected_area'}
  c['adoption']['uniform_tail_setting']=0
  c['adoption']['only_changed_dependency']={'old_controller':str(old),'old_sha256':sha(old),'new_controller':str(new),'new_sha256':sha(new),'reason':'Component controller adds a required-time area module profile and fixes every factor tail-off. Adopted legacy_control renamed own full-method protected_area reference explicitly (not a baseline rename); actual native argv/effective parameters and every actual native/driver/input/library/evaluator dependency unchanged; algorithm source/binary identical.'}
 a.output.mkdir();(a.output/'campaign.json').write_text(json.dumps(c,indent=2)+'\n');print('adopted',len(jobs),'/',c['expected_jobs'])
if __name__=='__main__':main()
