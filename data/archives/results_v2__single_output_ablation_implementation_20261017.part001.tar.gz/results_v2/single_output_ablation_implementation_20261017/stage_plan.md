# V27 staged qualification

Baseline algorithms/main8f6 unchanged. New isolated source from V26; hold existing tail flow trajectory and switch to a better validated deferred cover only afterwards; alter actual-area policy only on actual activation. One existing flow, original inclusive2s/cumulative20k/cut16/pool100k/SAT16/native60/mapping300. Not a guarantee of historical unvisited covers.

1. Red symptom: V26 equal-D losses ctrl/int2float/priority/router (5 library-design pairs), historical assertion captured separately.
2. Pilot sqrt/sin/max/int2float/priority and full EPFL two libraries, followed by alternating-order repeats.
3. Separate component ablations: cross-structure cut construction; input phase; physical pin permutation; SDC (dc_support0 vs4); shared-area recovery. No iteration0-as-cuts-only proxy; do not conflate pin cut retention with pin permutation or phase alias normalization with phase matching. Genuine independent switches must be implemented/qualified before component claims.
4. Promote only after same-library full-scope source/budget/CEC and repeated adverse-case checks; retain every failure and area/delay regression.
