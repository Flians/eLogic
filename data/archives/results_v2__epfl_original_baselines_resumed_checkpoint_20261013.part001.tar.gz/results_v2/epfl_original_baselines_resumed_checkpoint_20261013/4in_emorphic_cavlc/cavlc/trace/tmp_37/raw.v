// Benchmark "/tmp/" written by ABC on Tue Oct 13 18:50:26 2026

module \/tmp/  ( 
    p4, p0, p3, p5, p8, p9, p1, p7, p6, p2,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10  );
  input  p4, p0, p3, p5, p8, p9, p1, p7, p6, p2;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10;
  wire new_n22_, new_n23_, new_n24_, new_n25_, new_n26_, new_n27_, new_n28_,
    new_n29_, new_n30_, new_n31_, new_n32_, new_n33_, new_n34_, new_n35_,
    new_n36_, new_n37_, new_n38_, new_n39_, new_n40_, new_n41_, new_n42_,
    new_n43_, new_n44_, new_n45_, new_n46_, new_n47_, new_n48_, new_n49_,
    new_n50_, new_n51_, new_n52_, new_n53_, new_n54_, new_n55_, new_n56_,
    new_n57_, new_n58_, new_n59_, new_n60_, new_n61_, new_n62_, new_n63_,
    new_n64_, new_n65_, new_n66_, new_n67_, new_n68_, new_n69_, new_n70_,
    new_n71_, new_n72_, new_n73_, new_n74_, new_n75_, new_n76_, new_n77_,
    new_n78_, new_n79_, new_n80_, new_n81_, new_n82_, new_n83_, new_n84_,
    new_n85_, new_n86_, new_n87_, new_n88_, new_n89_, new_n90_, new_n91_,
    new_n92_, new_n93_, new_n94_, new_n95_, new_n96_, new_n97_, new_n98_,
    new_n99_, new_n100_, new_n101_, new_n102_, new_n103_, new_n104_,
    new_n105_, new_n106_, new_n107_, new_n108_, new_n109_, new_n110_,
    new_n111_, new_n112_, new_n113_, new_n114_, new_n116_, new_n117_,
    new_n118_, new_n119_, new_n120_, new_n121_, new_n122_, new_n123_,
    new_n124_, new_n125_, new_n126_, new_n127_, new_n128_, new_n129_,
    new_n130_, new_n131_, new_n132_, new_n133_, new_n134_, new_n135_,
    new_n136_, new_n137_, new_n138_, new_n139_, new_n140_, new_n141_,
    new_n142_, new_n143_, new_n144_, new_n145_, new_n146_, new_n147_,
    new_n148_, new_n149_, new_n150_, new_n151_, new_n152_, new_n153_,
    new_n154_, new_n155_, new_n156_, new_n157_, new_n158_, new_n159_,
    new_n160_, new_n161_, new_n162_, new_n163_, new_n164_, new_n165_,
    new_n166_, new_n167_, new_n168_, new_n169_, new_n170_, new_n171_,
    new_n172_, new_n173_, new_n174_, new_n175_, new_n176_, new_n177_,
    new_n178_, new_n179_, new_n180_, new_n181_, new_n182_, new_n183_,
    new_n184_, new_n185_, new_n186_, new_n187_, new_n189_, new_n190_,
    new_n191_, new_n192_, new_n193_, new_n194_, new_n195_, new_n196_,
    new_n197_, new_n198_, new_n199_, new_n200_, new_n201_, new_n202_,
    new_n203_, new_n204_, new_n205_, new_n206_, new_n207_, new_n208_,
    new_n209_, new_n210_, new_n211_, new_n212_, new_n213_, new_n214_,
    new_n215_, new_n216_, new_n217_, new_n218_, new_n219_, new_n220_,
    new_n221_, new_n222_, new_n223_, new_n224_, new_n225_, new_n226_,
    new_n227_, new_n228_, new_n229_, new_n230_, new_n231_, new_n232_,
    new_n233_, new_n234_, new_n235_, new_n236_, new_n237_, new_n238_,
    new_n239_, new_n240_, new_n241_, new_n242_, new_n243_, new_n244_,
    new_n246_, new_n247_, new_n248_, new_n249_, new_n250_, new_n251_,
    new_n252_, new_n253_, new_n254_, new_n255_, new_n256_, new_n257_,
    new_n258_, new_n259_, new_n260_, new_n261_, new_n262_, new_n263_,
    new_n264_, new_n265_, new_n266_, new_n267_, new_n268_, new_n269_,
    new_n270_, new_n271_, new_n272_, new_n273_, new_n274_, new_n275_,
    new_n276_, new_n277_, new_n278_, new_n279_, new_n280_, new_n281_,
    new_n282_, new_n283_, new_n285_, new_n286_, new_n287_, new_n288_,
    new_n289_, new_n291_, new_n292_, new_n294_, new_n295_, new_n296_,
    new_n297_, new_n298_, new_n299_, new_n300_, new_n301_, new_n302_,
    new_n303_, new_n304_, new_n305_, new_n306_, new_n307_, new_n308_,
    new_n309_, new_n310_, new_n311_, new_n312_, new_n313_, new_n314_,
    new_n315_, new_n316_, new_n317_, new_n318_, new_n319_, new_n320_,
    new_n321_, new_n322_, new_n323_, new_n324_, new_n325_, new_n326_,
    new_n327_, new_n328_, new_n329_, new_n330_, new_n331_, new_n332_,
    new_n333_, new_n334_, new_n335_, new_n336_, new_n337_, new_n338_,
    new_n339_, new_n341_, new_n342_, new_n343_, new_n344_, new_n345_,
    new_n346_, new_n347_, new_n348_, new_n349_, new_n350_, new_n351_,
    new_n352_, new_n353_, new_n354_, new_n355_, new_n356_, new_n357_,
    new_n358_, new_n359_, new_n360_, new_n361_, new_n362_, new_n363_,
    new_n364_, new_n365_, new_n366_, new_n367_, new_n368_, new_n369_,
    new_n370_, new_n371_, new_n372_, new_n373_, new_n374_, new_n375_,
    new_n376_, new_n377_, new_n378_, new_n379_, new_n380_, new_n381_,
    new_n382_, new_n383_, new_n384_, new_n385_, new_n386_, new_n387_,
    new_n388_, new_n389_, new_n390_, new_n391_, new_n393_, new_n394_,
    new_n395_, new_n396_, new_n397_, new_n398_, new_n399_, new_n400_,
    new_n401_, new_n402_, new_n403_, new_n404_, new_n405_, new_n406_,
    new_n407_, new_n408_, new_n409_, new_n410_, new_n411_, new_n412_,
    new_n413_, new_n414_, new_n415_, new_n416_, new_n417_, new_n418_,
    new_n419_, new_n421_, new_n422_, new_n423_, new_n424_, new_n425_,
    new_n426_, new_n427_, new_n428_, new_n429_, new_n430_, new_n431_,
    new_n432_, new_n433_, new_n434_, new_n435_, new_n436_, new_n437_,
    new_n438_, new_n440_, new_n441_, new_n442_;
  NOR2x1_ASAP7_75t_R   g000(.A(p3), .B(p6), .Y(new_n22_));
  INVx1_ASAP7_75t_R    g001(.A(new_n22_), .Y(new_n23_));
  NOR2x1_ASAP7_75t_R   g002(.A(p1), .B(p2), .Y(new_n24_));
  AND2x2_ASAP7_75t_R   g003(.A(p1), .B(p2), .Y(new_n25_));
  NOR2x1_ASAP7_75t_R   g004(.A(new_n24_), .B(new_n25_), .Y(new_n26_));
  INVx1_ASAP7_75t_R    g005(.A(p9), .Y(new_n27_));
  NOR2x1_ASAP7_75t_R   g006(.A(p8), .B(new_n27_), .Y(new_n28_));
  INVx1_ASAP7_75t_R    g007(.A(p8), .Y(new_n29_));
  NOR2x1_ASAP7_75t_R   g008(.A(p9), .B(new_n29_), .Y(new_n30_));
  NAND2x1_ASAP7_75t_R  g009(.A(p4), .B(p0), .Y(new_n31_));
  OR3x1_ASAP7_75t_R    g010(.A(new_n28_), .B(new_n30_), .C(new_n31_), .Y(new_n32_));
  NAND2x1_ASAP7_75t_R  g011(.A(p9), .B(new_n29_), .Y(new_n33_));
  NAND2x1_ASAP7_75t_R  g012(.A(p4), .B(p5), .Y(new_n34_));
  AO21x1_ASAP7_75t_R   g013(.A1(new_n24_), .A2(new_n33_), .B(new_n34_), .Y(new_n35_));
  OA21x2_ASAP7_75t_R   g014(.A1(new_n26_), .A2(new_n32_), .B(new_n35_), .Y(new_n36_));
  NOR2x1_ASAP7_75t_R   g015(.A(p0), .B(new_n29_), .Y(new_n37_));
  INVx1_ASAP7_75t_R    g016(.A(p2), .Y(new_n38_));
  NOR2x1_ASAP7_75t_R   g017(.A(p1), .B(new_n38_), .Y(new_n39_));
  NAND2x1_ASAP7_75t_R  g018(.A(new_n37_), .B(new_n39_), .Y(new_n40_));
  NAND2x1_ASAP7_75t_R  g019(.A(p8), .B(p1), .Y(new_n41_));
  NOR2x1_ASAP7_75t_R   g020(.A(p8), .B(p1), .Y(new_n42_));
  NAND2x1_ASAP7_75t_R  g021(.A(p0), .B(new_n42_), .Y(new_n43_));
  AO21x1_ASAP7_75t_R   g022(.A1(new_n41_), .A2(new_n43_), .B(p2), .Y(new_n44_));
  NAND2x1_ASAP7_75t_R  g023(.A(p5), .B(new_n27_), .Y(new_n45_));
  AO21x1_ASAP7_75t_R   g024(.A1(new_n40_), .A2(new_n44_), .B(new_n45_), .Y(new_n46_));
  NAND2x1_ASAP7_75t_R  g025(.A(new_n36_), .B(new_n46_), .Y(new_n47_));
  NOR2x1_ASAP7_75t_R   g026(.A(p0), .B(p8), .Y(new_n48_));
  NOR2x1_ASAP7_75t_R   g027(.A(p9), .B(p7), .Y(new_n49_));
  AND3x1_ASAP7_75t_R   g028(.A(new_n48_), .B(new_n49_), .C(new_n24_), .Y(new_n50_));
  OR3x1_ASAP7_75t_R    g029(.A(new_n29_), .B(new_n38_), .C(p7), .Y(new_n51_));
  NOR2x1_ASAP7_75t_R   g030(.A(p0), .B(p2), .Y(new_n52_));
  INVx1_ASAP7_75t_R    g031(.A(new_n52_), .Y(new_n53_));
  INVx1_ASAP7_75t_R    g032(.A(p7), .Y(new_n54_));
  NAND2x1_ASAP7_75t_R  g033(.A(p0), .B(new_n54_), .Y(new_n55_));
  OA21x2_ASAP7_75t_R   g034(.A1(new_n41_), .A2(new_n53_), .B(new_n55_), .Y(new_n56_));
  AO21x1_ASAP7_75t_R   g035(.A1(new_n51_), .A2(new_n56_), .B(p9), .Y(new_n57_));
  INVx1_ASAP7_75t_R    g036(.A(p5), .Y(new_n58_));
  NAND2x1_ASAP7_75t_R  g037(.A(p2), .B(new_n58_), .Y(new_n59_));
  NAND2x1_ASAP7_75t_R  g038(.A(p1), .B(p2), .Y(new_n60_));
  INVx1_ASAP7_75t_R    g039(.A(p0), .Y(new_n61_));
  AND3x1_ASAP7_75t_R   g040(.A(new_n60_), .B(new_n61_), .C(new_n29_), .Y(new_n62_));
  INVx1_ASAP7_75t_R    g041(.A(new_n41_), .Y(new_n63_));
  AO21x1_ASAP7_75t_R   g042(.A1(new_n59_), .A2(new_n62_), .B(new_n63_), .Y(new_n64_));
  NAND2x1_ASAP7_75t_R  g043(.A(p1), .B(new_n61_), .Y(new_n65_));
  OAI21x1_ASAP7_75t_R  g044(.A1(new_n65_), .A2(new_n33_), .B(new_n55_), .Y(new_n66_));
  AOI22x1_ASAP7_75t_R  g045(.A1(new_n64_), .A2(new_n54_), .B1(p2), .B2(new_n66_), .Y(new_n67_));
  AOI21x1_ASAP7_75t_R  g046(.A1(new_n57_), .A2(new_n67_), .B(p4), .Y(new_n68_));
  AOI211x1_ASAP7_75t_R g047(.A1(p7), .A2(new_n47_), .B(new_n50_), .C(new_n68_), .Y(new_n69_));
  NAND2x1_ASAP7_75t_R  g048(.A(p0), .B(p1), .Y(new_n70_));
  INVx1_ASAP7_75t_R    g049(.A(p4), .Y(new_n71_));
  INVx1_ASAP7_75t_R    g050(.A(p1), .Y(new_n72_));
  AO21x1_ASAP7_75t_R   g051(.A1(new_n71_), .A2(new_n72_), .B(p9), .Y(new_n73_));
  AO21x1_ASAP7_75t_R   g052(.A1(new_n70_), .A2(new_n73_), .B(p8), .Y(new_n74_));
  OR3x1_ASAP7_75t_R    g053(.A(new_n24_), .B(p0), .C(new_n29_), .Y(new_n75_));
  NAND2x1_ASAP7_75t_R  g054(.A(p0), .B(new_n38_), .Y(new_n76_));
  NAND3x1_ASAP7_75t_R  g055(.A(new_n61_), .B(p9), .C(p2), .Y(new_n77_));
  AND3x1_ASAP7_75t_R   g056(.A(new_n75_), .B(new_n76_), .C(new_n77_), .Y(new_n78_));
  INVx1_ASAP7_75t_R    g057(.A(p6), .Y(new_n79_));
  NAND2x1_ASAP7_75t_R  g058(.A(new_n54_), .B(new_n79_), .Y(new_n80_));
  AO21x1_ASAP7_75t_R   g059(.A1(new_n74_), .A2(new_n78_), .B(new_n80_), .Y(new_n81_));
  NOR2x1_ASAP7_75t_R   g060(.A(p0), .B(p9), .Y(new_n82_));
  AND3x1_ASAP7_75t_R   g061(.A(new_n82_), .B(new_n29_), .C(p1), .Y(new_n83_));
  AND2x2_ASAP7_75t_R   g062(.A(p6), .B(new_n83_), .Y(new_n84_));
  NOR2x1_ASAP7_75t_R   g063(.A(p1), .B(new_n27_), .Y(new_n85_));
  NAND2x1_ASAP7_75t_R  g064(.A(p4), .B(new_n61_), .Y(new_n86_));
  OA211x2_ASAP7_75t_R  g065(.A1(p0), .A2(new_n29_), .B(new_n85_), .C(new_n86_), .Y(new_n87_));
  NAND2x1_ASAP7_75t_R  g066(.A(p7), .B(new_n71_), .Y(new_n88_));
  NOR2x1_ASAP7_75t_R   g067(.A(p4), .B(p8), .Y(new_n89_));
  OAI21x1_ASAP7_75t_R  g068(.A1(new_n79_), .A2(new_n89_), .B(new_n85_), .Y(new_n90_));
  NOR2x1_ASAP7_75t_R   g069(.A(p8), .B(new_n61_), .Y(new_n91_));
  AO21x1_ASAP7_75t_R   g070(.A1(new_n79_), .A2(new_n91_), .B(p2), .Y(new_n92_));
  AOI21x1_ASAP7_75t_R  g071(.A1(new_n88_), .A2(new_n90_), .B(new_n92_), .Y(new_n93_));
  OAI21x1_ASAP7_75t_R  g072(.A1(new_n84_), .A2(new_n87_), .B(new_n93_), .Y(new_n94_));
  INVx1_ASAP7_75t_R    g073(.A(new_n82_), .Y(new_n95_));
  NOR2x1_ASAP7_75t_R   g074(.A(p4), .B(p2), .Y(new_n96_));
  NAND2x1_ASAP7_75t_R  g075(.A(p8), .B(p9), .Y(new_n97_));
  AOI22x1_ASAP7_75t_R  g076(.A1(new_n95_), .A2(new_n79_), .B1(new_n96_), .B2(new_n97_), .Y(new_n98_));
  XOR2x2_ASAP7_75t_R   g077(.A(p0), .B(p8), .Y(new_n99_));
  NOR2x1_ASAP7_75t_R   g078(.A(p1), .B(p7), .Y(new_n100_));
  INVx1_ASAP7_75t_R    g079(.A(new_n100_), .Y(new_n101_));
  OR3x1_ASAP7_75t_R    g080(.A(new_n98_), .B(new_n99_), .C(new_n101_), .Y(new_n102_));
  NAND3x1_ASAP7_75t_R  g081(.A(new_n81_), .B(new_n94_), .C(new_n102_), .Y(new_n103_));
  NOR2x1_ASAP7_75t_R   g082(.A(p3), .B(p5), .Y(new_n104_));
  NOR2x1_ASAP7_75t_R   g083(.A(p5), .B(p8), .Y(new_n105_));
  NOR2x1_ASAP7_75t_R   g084(.A(p7), .B(new_n105_), .Y(new_n106_));
  OA21x2_ASAP7_75t_R   g085(.A1(p3), .A2(new_n29_), .B(new_n34_), .Y(new_n107_));
  AO21x1_ASAP7_75t_R   g086(.A1(p3), .A2(p7), .B(new_n105_), .Y(new_n108_));
  OA211x2_ASAP7_75t_R  g087(.A1(p5), .A2(new_n54_), .B(new_n108_), .C(p4), .Y(new_n109_));
  AO21x1_ASAP7_75t_R   g088(.A1(new_n106_), .A2(new_n107_), .B(new_n109_), .Y(new_n110_));
  OR3x1_ASAP7_75t_R    g089(.A(p0), .B(p1), .C(p2), .Y(new_n111_));
  OR3x1_ASAP7_75t_R    g090(.A(new_n111_), .B(p9), .C(p6), .Y(new_n112_));
  INVx1_ASAP7_75t_R    g091(.A(new_n112_), .Y(new_n113_));
  AOI22x1_ASAP7_75t_R  g092(.A1(new_n103_), .A2(new_n104_), .B1(new_n110_), .B2(new_n113_), .Y(new_n114_));
  OAI21x1_ASAP7_75t_R  g093(.A1(new_n23_), .A2(new_n69_), .B(new_n114_), .Y(o0));
  AO21x1_ASAP7_75t_R   g094(.A1(p7), .A2(new_n27_), .B(p4), .Y(new_n116_));
  AND2x2_ASAP7_75t_R   g095(.A(p0), .B(p9), .Y(new_n117_));
  NOR2x1_ASAP7_75t_R   g096(.A(p0), .B(p5), .Y(new_n118_));
  OR3x1_ASAP7_75t_R    g097(.A(new_n117_), .B(p1), .C(new_n118_), .Y(new_n119_));
  OR4x2_ASAP7_75t_R    g098(.A(new_n24_), .B(new_n100_), .C(p5), .D(p9), .Y(new_n120_));
  OAI21x1_ASAP7_75t_R  g099(.A1(new_n116_), .A2(new_n119_), .B(new_n120_), .Y(new_n121_));
  NOR2x1_ASAP7_75t_R   g100(.A(p9), .B(new_n71_), .Y(new_n122_));
  NOR2x1_ASAP7_75t_R   g101(.A(p4), .B(new_n27_), .Y(new_n123_));
  NAND2x1_ASAP7_75t_R  g102(.A(p9), .B(p7), .Y(new_n124_));
  NOR2x1_ASAP7_75t_R   g103(.A(p1), .B(new_n124_), .Y(new_n125_));
  NOR2x1_ASAP7_75t_R   g104(.A(p5), .B(new_n61_), .Y(new_n126_));
  OA31x2_ASAP7_75t_R   g105(.A1(new_n122_), .A2(new_n123_), .A3(new_n125_), .B1(new_n126_), .Y(new_n127_));
  NOR2x1_ASAP7_75t_R   g106(.A(p7), .B(p2), .Y(new_n128_));
  OR3x1_ASAP7_75t_R    g107(.A(new_n128_), .B(p0), .C(p5), .Y(new_n129_));
  AO21x1_ASAP7_75t_R   g108(.A1(p7), .A2(new_n71_), .B(new_n27_), .Y(new_n130_));
  NAND2x1_ASAP7_75t_R  g109(.A(new_n100_), .B(new_n118_), .Y(new_n131_));
  OAI22x1_ASAP7_75t_R  g110(.A1(new_n129_), .A2(new_n130_), .B1(new_n71_), .B2(new_n131_), .Y(new_n132_));
  AO21x1_ASAP7_75t_R   g111(.A1(p5), .A2(new_n61_), .B(new_n72_), .Y(new_n133_));
  NAND2x1_ASAP7_75t_R  g112(.A(new_n61_), .B(new_n54_), .Y(new_n134_));
  NOR2x1_ASAP7_75t_R   g113(.A(p4), .B(new_n38_), .Y(new_n135_));
  AO31x2_ASAP7_75t_R   g114(.A1(new_n133_), .A2(new_n134_), .A3(new_n135_), .B(p8), .Y(new_n136_));
  OR4x2_ASAP7_75t_R    g115(.A(new_n121_), .B(new_n127_), .C(new_n132_), .D(new_n136_), .Y(new_n137_));
  NOR2x1_ASAP7_75t_R   g116(.A(new_n101_), .B(new_n77_), .Y(new_n138_));
  NAND2x1_ASAP7_75t_R  g117(.A(p0), .B(p9), .Y(new_n139_));
  AO21x1_ASAP7_75t_R   g118(.A1(new_n139_), .A2(new_n24_), .B(new_n71_), .Y(new_n140_));
  OAI21x1_ASAP7_75t_R  g119(.A1(new_n38_), .A2(new_n70_), .B(new_n140_), .Y(new_n141_));
  OAI21x1_ASAP7_75t_R  g120(.A1(new_n138_), .A2(new_n141_), .B(p5), .Y(new_n142_));
  NAND2x1_ASAP7_75t_R  g121(.A(p2), .B(new_n54_), .Y(new_n143_));
  OR3x1_ASAP7_75t_R    g122(.A(new_n143_), .B(new_n71_), .C(new_n70_), .Y(new_n144_));
  NAND3x1_ASAP7_75t_R  g123(.A(new_n142_), .B(p8), .C(new_n144_), .Y(new_n145_));
  OR4x2_ASAP7_75t_R    g124(.A(p8), .B(p9), .C(p1), .D(p7), .Y(new_n146_));
  NAND2x1_ASAP7_75t_R  g125(.A(p1), .B(p7), .Y(new_n147_));
  OR3x1_ASAP7_75t_R    g126(.A(new_n147_), .B(new_n29_), .C(new_n27_), .Y(new_n148_));
  AO21x1_ASAP7_75t_R   g127(.A1(new_n146_), .A2(new_n148_), .B(new_n71_), .Y(new_n149_));
  NAND2x1_ASAP7_75t_R  g128(.A(p1), .B(new_n27_), .Y(new_n150_));
  NAND2x1_ASAP7_75t_R  g129(.A(p5), .B(p8), .Y(new_n151_));
  OA21x2_ASAP7_75t_R   g130(.A1(p4), .A2(new_n54_), .B(new_n151_), .Y(new_n152_));
  NOR2x1_ASAP7_75t_R   g131(.A(p8), .B(p7), .Y(new_n153_));
  NOR2x1_ASAP7_75t_R   g132(.A(p4), .B(new_n72_), .Y(new_n154_));
  NAND2x1_ASAP7_75t_R  g133(.A(new_n153_), .B(new_n154_), .Y(new_n155_));
  OR3x1_ASAP7_75t_R    g134(.A(new_n41_), .B(new_n58_), .C(new_n54_), .Y(new_n156_));
  OA211x2_ASAP7_75t_R  g135(.A1(new_n150_), .A2(new_n152_), .B(new_n155_), .C(new_n156_), .Y(new_n157_));
  AOI21x1_ASAP7_75t_R  g136(.A1(new_n149_), .A2(new_n157_), .B(new_n53_), .Y(new_n158_));
  NOR2x1_ASAP7_75t_R   g137(.A(p5), .B(p7), .Y(new_n159_));
  AND3x1_ASAP7_75t_R   g138(.A(new_n71_), .B(p1), .C(p7), .Y(new_n160_));
  NOR2x1_ASAP7_75t_R   g139(.A(new_n159_), .B(new_n160_), .Y(new_n161_));
  OR3x1_ASAP7_75t_R    g140(.A(new_n88_), .B(new_n58_), .C(p9), .Y(new_n162_));
  NAND2x1_ASAP7_75t_R  g141(.A(p0), .B(new_n29_), .Y(new_n163_));
  AO21x1_ASAP7_75t_R   g142(.A1(new_n161_), .A2(new_n162_), .B(new_n163_), .Y(new_n164_));
  NAND2x1_ASAP7_75t_R  g143(.A(p5), .B(p7), .Y(new_n165_));
  NAND2x1_ASAP7_75t_R  g144(.A(new_n165_), .B(new_n85_), .Y(new_n166_));
  NAND2x1_ASAP7_75t_R  g145(.A(p8), .B(new_n27_), .Y(new_n167_));
  NAND2x1_ASAP7_75t_R  g146(.A(p4), .B(new_n100_), .Y(new_n168_));
  OAI22x1_ASAP7_75t_R  g147(.A1(new_n166_), .A2(new_n152_), .B1(new_n167_), .B2(new_n168_), .Y(new_n169_));
  AND2x2_ASAP7_75t_R   g148(.A(p1), .B(p7), .Y(new_n170_));
  AOI22x1_ASAP7_75t_R  g149(.A1(new_n169_), .A2(p0), .B1(new_n105_), .B2(new_n170_), .Y(new_n171_));
  AOI21x1_ASAP7_75t_R  g150(.A1(new_n164_), .A2(new_n171_), .B(p2), .Y(new_n172_));
  AOI211x1_ASAP7_75t_R g151(.A1(new_n137_), .A2(new_n145_), .B(new_n158_), .C(new_n172_), .Y(new_n173_));
  INVx1_ASAP7_75t_R    g152(.A(p3), .Y(new_n174_));
  NAND2x1_ASAP7_75t_R  g153(.A(p4), .B(new_n54_), .Y(new_n175_));
  OA21x2_ASAP7_75t_R   g154(.A1(new_n174_), .A2(new_n54_), .B(new_n175_), .Y(new_n176_));
  INVx1_ASAP7_75t_R    g155(.A(new_n105_), .Y(new_n177_));
  OA22x2_ASAP7_75t_R   g156(.A1(new_n176_), .A2(new_n177_), .B1(new_n174_), .B2(new_n151_), .Y(new_n178_));
  AO21x1_ASAP7_75t_R   g157(.A1(p9), .A2(new_n29_), .B(p1), .Y(new_n179_));
  OA211x2_ASAP7_75t_R  g158(.A1(new_n49_), .A2(new_n100_), .B(new_n70_), .C(p6), .Y(new_n180_));
  OAI21x1_ASAP7_75t_R  g159(.A1(new_n117_), .A2(new_n179_), .B(new_n180_), .Y(new_n181_));
  NOR2x1_ASAP7_75t_R   g160(.A(p1), .B(new_n54_), .Y(new_n182_));
  AND3x1_ASAP7_75t_R   g161(.A(new_n91_), .B(new_n182_), .C(p6), .Y(new_n183_));
  NOR2x1_ASAP7_75t_R   g162(.A(new_n83_), .B(new_n183_), .Y(new_n184_));
  NAND2x1_ASAP7_75t_R  g163(.A(new_n96_), .B(new_n104_), .Y(new_n185_));
  AO21x1_ASAP7_75t_R   g164(.A1(new_n181_), .A2(new_n184_), .B(new_n185_), .Y(new_n186_));
  OA21x2_ASAP7_75t_R   g165(.A1(new_n112_), .A2(new_n178_), .B(new_n186_), .Y(new_n187_));
  OAI21x1_ASAP7_75t_R  g166(.A1(new_n23_), .A2(new_n173_), .B(new_n187_), .Y(o1));
  AO21x1_ASAP7_75t_R   g167(.A1(p2), .A2(new_n72_), .B(new_n54_), .Y(new_n189_));
  NAND2x1_ASAP7_75t_R  g168(.A(p4), .B(p2), .Y(new_n190_));
  OAI21x1_ASAP7_75t_R  g169(.A1(new_n190_), .A2(new_n182_), .B(new_n91_), .Y(new_n191_));
  AO21x1_ASAP7_75t_R   g170(.A1(new_n71_), .A2(new_n189_), .B(new_n191_), .Y(new_n192_));
  NAND2x1_ASAP7_75t_R  g171(.A(p5), .B(p1), .Y(new_n193_));
  AND3x1_ASAP7_75t_R   g172(.A(new_n193_), .B(p0), .C(p7), .Y(new_n194_));
  OR4x2_ASAP7_75t_R    g173(.A(new_n194_), .B(new_n71_), .C(new_n24_), .D(new_n100_), .Y(new_n195_));
  AO21x1_ASAP7_75t_R   g174(.A1(p2), .A2(new_n29_), .B(p5), .Y(new_n196_));
  AO21x1_ASAP7_75t_R   g175(.A1(new_n143_), .A2(new_n163_), .B(new_n196_), .Y(new_n197_));
  INVx1_ASAP7_75t_R    g176(.A(new_n153_), .Y(new_n198_));
  NAND2x1_ASAP7_75t_R  g177(.A(p5), .B(new_n71_), .Y(new_n199_));
  OR3x1_ASAP7_75t_R    g178(.A(new_n53_), .B(new_n198_), .C(new_n199_), .Y(new_n200_));
  AND4x2_ASAP7_75t_R   g179(.A(new_n192_), .B(new_n195_), .C(new_n197_), .D(new_n200_), .Y(new_n201_));
  NOR2x1_ASAP7_75t_R   g180(.A(p7), .B(new_n58_), .Y(new_n202_));
  AND3x1_ASAP7_75t_R   g181(.A(new_n38_), .B(p0), .C(p8), .Y(new_n203_));
  AO21x1_ASAP7_75t_R   g182(.A1(new_n202_), .A2(new_n203_), .B(p3), .Y(new_n204_));
  NOR2x1_ASAP7_75t_R   g183(.A(p7), .B(new_n38_), .Y(new_n205_));
  AO21x1_ASAP7_75t_R   g184(.A1(new_n205_), .A2(new_n37_), .B(new_n39_), .Y(new_n206_));
  OR3x1_ASAP7_75t_R    g185(.A(new_n61_), .B(new_n54_), .C(p8), .Y(new_n207_));
  AND3x1_ASAP7_75t_R   g186(.A(new_n206_), .B(new_n177_), .C(new_n207_), .Y(new_n208_));
  NOR2x1_ASAP7_75t_R   g187(.A(new_n204_), .B(new_n208_), .Y(new_n209_));
  AND2x2_ASAP7_75t_R   g188(.A(p8), .B(p7), .Y(new_n210_));
  OA21x2_ASAP7_75t_R   g189(.A1(new_n210_), .A2(new_n202_), .B(new_n71_), .Y(new_n211_));
  AO21x1_ASAP7_75t_R   g190(.A1(p3), .A2(new_n111_), .B(p9), .Y(new_n212_));
  AO21x1_ASAP7_75t_R   g191(.A1(p3), .A2(new_n211_), .B(new_n212_), .Y(new_n213_));
  AO211x2_ASAP7_75t_R  g192(.A1(new_n201_), .A2(new_n209_), .B(p6), .C(new_n213_), .Y(new_n214_));
  NOR2x1_ASAP7_75t_R   g193(.A(new_n124_), .B(new_n75_), .Y(new_n215_));
  NOR2x1_ASAP7_75t_R   g194(.A(p0), .B(new_n38_), .Y(new_n216_));
  OA211x2_ASAP7_75t_R  g195(.A1(new_n71_), .A2(new_n216_), .B(new_n28_), .C(new_n100_), .Y(new_n217_));
  NOR2x1_ASAP7_75t_R   g196(.A(new_n215_), .B(new_n217_), .Y(new_n218_));
  NAND2x1_ASAP7_75t_R  g197(.A(p8), .B(p7), .Y(new_n219_));
  OA211x2_ASAP7_75t_R  g198(.A1(p8), .A2(new_n55_), .B(p1), .C(new_n219_), .Y(new_n220_));
  AND2x2_ASAP7_75t_R   g199(.A(p0), .B(p1), .Y(new_n221_));
  NAND2x1_ASAP7_75t_R  g200(.A(p8), .B(new_n221_), .Y(new_n222_));
  NAND2x1_ASAP7_75t_R  g201(.A(p9), .B(new_n210_), .Y(new_n223_));
  NOR2x1_ASAP7_75t_R   g202(.A(new_n71_), .B(new_n153_), .Y(new_n224_));
  AOI22x1_ASAP7_75t_R  g203(.A1(new_n31_), .A2(new_n222_), .B1(new_n223_), .B2(new_n224_), .Y(new_n225_));
  OAI21x1_ASAP7_75t_R  g204(.A1(new_n220_), .A2(new_n225_), .B(new_n38_), .Y(new_n226_));
  INVx1_ASAP7_75t_R    g205(.A(new_n104_), .Y(new_n227_));
  AOI21x1_ASAP7_75t_R  g206(.A1(new_n218_), .A2(new_n226_), .B(new_n227_), .Y(new_n228_));
  OR3x1_ASAP7_75t_R    g207(.A(new_n99_), .B(p7), .C(p2), .Y(new_n229_));
  AO21x1_ASAP7_75t_R   g208(.A1(p8), .A2(new_n61_), .B(new_n58_), .Y(new_n230_));
  AO21x1_ASAP7_75t_R   g209(.A1(new_n163_), .A2(new_n230_), .B(new_n54_), .Y(new_n231_));
  AO21x1_ASAP7_75t_R   g210(.A1(new_n229_), .A2(new_n231_), .B(p1), .Y(new_n232_));
  NAND2x1_ASAP7_75t_R  g211(.A(new_n41_), .B(new_n147_), .Y(new_n233_));
  AO21x1_ASAP7_75t_R   g212(.A1(new_n219_), .A2(new_n233_), .B(new_n100_), .Y(new_n234_));
  NAND2x1_ASAP7_75t_R  g213(.A(p7), .B(new_n61_), .Y(new_n235_));
  AO21x1_ASAP7_75t_R   g214(.A1(new_n235_), .A2(new_n222_), .B(new_n58_), .Y(new_n236_));
  AO21x1_ASAP7_75t_R   g215(.A1(new_n234_), .A2(new_n236_), .B(new_n38_), .Y(new_n237_));
  OR3x1_ASAP7_75t_R    g216(.A(new_n27_), .B(p4), .C(p3), .Y(new_n238_));
  AOI21x1_ASAP7_75t_R  g217(.A1(new_n232_), .A2(new_n237_), .B(new_n238_), .Y(new_n239_));
  OAI21x1_ASAP7_75t_R  g218(.A1(new_n228_), .A2(new_n239_), .B(new_n79_), .Y(new_n240_));
  OR3x1_ASAP7_75t_R    g219(.A(p0), .B(p8), .C(p7), .Y(new_n241_));
  OA211x2_ASAP7_75t_R  g220(.A1(new_n27_), .A2(new_n241_), .B(new_n163_), .C(new_n139_), .Y(new_n242_));
  OA211x2_ASAP7_75t_R  g221(.A1(new_n79_), .A2(new_n219_), .B(new_n241_), .C(p9), .Y(new_n243_));
  OR4x2_ASAP7_75t_R    g222(.A(new_n242_), .B(new_n243_), .C(p1), .D(new_n185_), .Y(new_n244_));
  NAND3x1_ASAP7_75t_R  g223(.A(new_n214_), .B(new_n240_), .C(new_n244_), .Y(o2));
  NAND2x1_ASAP7_75t_R  g224(.A(p4), .B(p7), .Y(new_n246_));
  NAND2x1_ASAP7_75t_R  g225(.A(p1), .B(new_n38_), .Y(new_n247_));
  NAND2x1_ASAP7_75t_R  g226(.A(new_n246_), .B(new_n247_), .Y(new_n248_));
  AO21x1_ASAP7_75t_R   g227(.A1(new_n147_), .A2(new_n248_), .B(new_n160_), .Y(new_n249_));
  INVx1_ASAP7_75t_R    g228(.A(new_n96_), .Y(new_n250_));
  OAI22x1_ASAP7_75t_R  g229(.A1(new_n131_), .A2(new_n71_), .B1(new_n58_), .B2(new_n250_), .Y(new_n251_));
  AO21x1_ASAP7_75t_R   g230(.A1(p0), .A2(new_n249_), .B(new_n251_), .Y(new_n252_));
  AND2x2_ASAP7_75t_R   g231(.A(p4), .B(p8), .Y(new_n253_));
  AO21x1_ASAP7_75t_R   g232(.A1(new_n100_), .A2(new_n253_), .B(new_n39_), .Y(new_n254_));
  INVx1_ASAP7_75t_R    g233(.A(new_n135_), .Y(new_n255_));
  OA21x2_ASAP7_75t_R   g234(.A1(p5), .A2(new_n205_), .B(new_n255_), .Y(new_n256_));
  OA21x2_ASAP7_75t_R   g235(.A1(new_n254_), .A2(new_n256_), .B(new_n117_), .Y(new_n257_));
  AOI21x1_ASAP7_75t_R  g236(.A1(new_n42_), .A2(new_n135_), .B(new_n159_), .Y(new_n258_));
  AO21x1_ASAP7_75t_R   g237(.A1(p0), .A2(p1), .B(new_n38_), .Y(new_n259_));
  AO21x1_ASAP7_75t_R   g238(.A1(new_n241_), .A2(new_n207_), .B(new_n199_), .Y(new_n260_));
  OA21x2_ASAP7_75t_R   g239(.A1(new_n258_), .A2(new_n259_), .B(new_n260_), .Y(new_n261_));
  OR3x1_ASAP7_75t_R    g240(.A(new_n72_), .B(new_n38_), .C(p5), .Y(new_n262_));
  AO21x1_ASAP7_75t_R   g241(.A1(new_n199_), .A2(new_n262_), .B(new_n75_), .Y(new_n263_));
  OA21x2_ASAP7_75t_R   g242(.A1(new_n61_), .A2(new_n29_), .B(new_n246_), .Y(new_n264_));
  OR3x1_ASAP7_75t_R    g243(.A(new_n264_), .B(new_n59_), .C(new_n253_), .Y(new_n265_));
  NAND3x1_ASAP7_75t_R  g244(.A(new_n261_), .B(new_n263_), .C(new_n265_), .Y(new_n266_));
  AOI211x1_ASAP7_75t_R g245(.A1(new_n28_), .A2(new_n252_), .B(new_n257_), .C(new_n266_), .Y(new_n267_));
  NAND2x1_ASAP7_75t_R  g246(.A(new_n27_), .B(new_n79_), .Y(new_n268_));
  NOR2x1_ASAP7_75t_R   g247(.A(p5), .B(new_n72_), .Y(new_n269_));
  AND3x1_ASAP7_75t_R   g248(.A(p4), .B(p8), .C(p7), .Y(new_n270_));
  OA211x2_ASAP7_75t_R  g249(.A1(p2), .A2(new_n202_), .B(new_n175_), .C(new_n34_), .Y(new_n271_));
  AOI21x1_ASAP7_75t_R  g250(.A1(new_n269_), .A2(new_n270_), .B(new_n271_), .Y(new_n272_));
  AOI21x1_ASAP7_75t_R  g251(.A1(new_n155_), .A2(new_n272_), .B(new_n61_), .Y(new_n273_));
  NOR2x1_ASAP7_75t_R   g252(.A(p0), .B(new_n24_), .Y(new_n274_));
  NOR2x1_ASAP7_75t_R   g253(.A(p4), .B(new_n193_), .Y(new_n275_));
  AO21x1_ASAP7_75t_R   g254(.A1(new_n274_), .A2(new_n196_), .B(new_n275_), .Y(new_n276_));
  INVx1_ASAP7_75t_R    g255(.A(new_n34_), .Y(new_n277_));
  NOR2x1_ASAP7_75t_R   g256(.A(p4), .B(p5), .Y(new_n278_));
  AND3x1_ASAP7_75t_R   g257(.A(new_n24_), .B(new_n61_), .C(p3), .Y(new_n279_));
  AO21x1_ASAP7_75t_R   g258(.A1(p8), .A2(p7), .B(p4), .Y(new_n280_));
  OA211x2_ASAP7_75t_R  g259(.A1(new_n277_), .A2(new_n278_), .B(new_n279_), .C(new_n280_), .Y(new_n281_));
  AO21x1_ASAP7_75t_R   g260(.A1(new_n174_), .A2(new_n276_), .B(new_n281_), .Y(new_n282_));
  AOI21x1_ASAP7_75t_R  g261(.A1(new_n174_), .A2(new_n273_), .B(new_n282_), .Y(new_n283_));
  OAI22x1_ASAP7_75t_R  g262(.A1(new_n267_), .A2(new_n23_), .B1(new_n268_), .B2(new_n283_), .Y(o3));
  AND3x1_ASAP7_75t_R   g263(.A(new_n95_), .B(new_n174_), .C(p1), .Y(new_n285_));
  NOR2x1_ASAP7_75t_R   g264(.A(p2), .B(new_n174_), .Y(new_n286_));
  NOR2x1_ASAP7_75t_R   g265(.A(p3), .B(new_n38_), .Y(new_n287_));
  NOR2x1_ASAP7_75t_R   g266(.A(p9), .B(p1), .Y(new_n288_));
  OA211x2_ASAP7_75t_R  g267(.A1(new_n286_), .A2(new_n287_), .B(new_n61_), .C(new_n288_), .Y(new_n289_));
  OA211x2_ASAP7_75t_R  g268(.A1(new_n285_), .A2(new_n289_), .B(new_n79_), .C(new_n277_), .Y(o4));
  AND3x1_ASAP7_75t_R   g269(.A(new_n24_), .B(new_n82_), .C(p3), .Y(new_n291_));
  OA21x2_ASAP7_75t_R   g270(.A1(p1), .A2(new_n95_), .B(new_n287_), .Y(new_n292_));
  OA211x2_ASAP7_75t_R  g271(.A1(new_n291_), .A2(new_n292_), .B(new_n79_), .C(new_n277_), .Y(o5));
  AO21x1_ASAP7_75t_R   g272(.A1(p5), .A2(new_n54_), .B(p9), .Y(new_n294_));
  AND3x1_ASAP7_75t_R   g273(.A(new_n294_), .B(new_n42_), .C(new_n246_), .Y(new_n295_));
  AND3x1_ASAP7_75t_R   g274(.A(new_n223_), .B(new_n41_), .C(new_n147_), .Y(new_n296_));
  NAND2x1_ASAP7_75t_R  g275(.A(p0), .B(p5), .Y(new_n297_));
  OR3x1_ASAP7_75t_R    g276(.A(new_n29_), .B(new_n72_), .C(p9), .Y(new_n298_));
  OAI22x1_ASAP7_75t_R  g277(.A1(new_n296_), .A2(new_n297_), .B1(new_n235_), .B2(new_n298_), .Y(new_n299_));
  AND3x1_ASAP7_75t_R   g278(.A(new_n33_), .B(p4), .C(new_n72_), .Y(new_n300_));
  OR3x1_ASAP7_75t_R    g279(.A(new_n154_), .B(new_n167_), .C(p5), .Y(new_n301_));
  NOR2x1_ASAP7_75t_R   g280(.A(p7), .B(new_n61_), .Y(new_n302_));
  OA211x2_ASAP7_75t_R  g281(.A1(new_n30_), .A2(new_n300_), .B(new_n301_), .C(new_n302_), .Y(new_n303_));
  AOI211x1_ASAP7_75t_R g282(.A1(new_n61_), .A2(new_n295_), .B(new_n299_), .C(new_n303_), .Y(new_n304_));
  OR3x1_ASAP7_75t_R    g283(.A(new_n123_), .B(new_n163_), .C(new_n49_), .Y(new_n305_));
  OR3x1_ASAP7_75t_R    g284(.A(new_n165_), .B(new_n27_), .C(p1), .Y(new_n306_));
  NAND2x1_ASAP7_75t_R  g285(.A(new_n150_), .B(new_n302_), .Y(new_n307_));
  AO21x1_ASAP7_75t_R   g286(.A1(new_n306_), .A2(new_n307_), .B(new_n29_), .Y(new_n308_));
  AO21x1_ASAP7_75t_R   g287(.A1(new_n305_), .A2(new_n308_), .B(new_n38_), .Y(new_n309_));
  NOR2x1_ASAP7_75t_R   g288(.A(p5), .B(p9), .Y(new_n310_));
  OA211x2_ASAP7_75t_R  g289(.A1(new_n221_), .A2(new_n310_), .B(new_n99_), .C(new_n134_), .Y(new_n311_));
  AO21x1_ASAP7_75t_R   g290(.A1(new_n61_), .A2(new_n198_), .B(new_n27_), .Y(new_n312_));
  NOR2x1_ASAP7_75t_R   g291(.A(new_n91_), .B(new_n312_), .Y(new_n313_));
  OAI21x1_ASAP7_75t_R  g292(.A1(new_n311_), .A2(new_n313_), .B(new_n135_), .Y(new_n314_));
  NAND3x1_ASAP7_75t_R  g293(.A(new_n304_), .B(new_n309_), .C(new_n314_), .Y(new_n315_));
  INVx1_ASAP7_75t_R    g294(.A(new_n185_), .Y(new_n316_));
  NOR2x1_ASAP7_75t_R   g295(.A(p8), .B(new_n79_), .Y(new_n317_));
  NOR2x1_ASAP7_75t_R   g296(.A(new_n54_), .B(new_n317_), .Y(new_n318_));
  OA21x2_ASAP7_75t_R   g297(.A1(new_n65_), .A2(new_n318_), .B(new_n43_), .Y(new_n319_));
  AND2x2_ASAP7_75t_R   g298(.A(new_n198_), .B(new_n223_), .Y(new_n320_));
  NOR2x1_ASAP7_75t_R   g299(.A(p0), .B(new_n153_), .Y(new_n321_));
  OR3x1_ASAP7_75t_R    g300(.A(new_n321_), .B(p1), .C(new_n79_), .Y(new_n322_));
  OAI22x1_ASAP7_75t_R  g301(.A1(new_n319_), .A2(p9), .B1(new_n320_), .B2(new_n322_), .Y(new_n323_));
  NOR2x1_ASAP7_75t_R   g302(.A(new_n174_), .B(new_n112_), .Y(new_n324_));
  AO21x1_ASAP7_75t_R   g303(.A1(new_n79_), .A2(new_n277_), .B(new_n324_), .Y(new_n325_));
  AOI21x1_ASAP7_75t_R  g304(.A1(new_n316_), .A2(new_n323_), .B(new_n325_), .Y(new_n326_));
  AO21x1_ASAP7_75t_R   g305(.A1(new_n241_), .A2(new_n298_), .B(new_n71_), .Y(new_n327_));
  NOR2x1_ASAP7_75t_R   g306(.A(new_n153_), .B(new_n210_), .Y(new_n328_));
  NOR2x1_ASAP7_75t_R   g307(.A(new_n100_), .B(new_n170_), .Y(new_n329_));
  OR3x1_ASAP7_75t_R    g308(.A(new_n328_), .B(new_n329_), .C(new_n58_), .Y(new_n330_));
  AND2x2_ASAP7_75t_R   g309(.A(new_n327_), .B(new_n330_), .Y(new_n331_));
  OA21x2_ASAP7_75t_R   g310(.A1(new_n71_), .A2(new_n72_), .B(new_n105_), .Y(new_n332_));
  AOI22x1_ASAP7_75t_R  g311(.A1(new_n332_), .A2(new_n70_), .B1(p0), .B2(new_n253_), .Y(new_n333_));
  OR3x1_ASAP7_75t_R    g312(.A(new_n89_), .B(p9), .C(new_n72_), .Y(new_n334_));
  AO21x1_ASAP7_75t_R   g313(.A1(new_n27_), .A2(new_n334_), .B(new_n54_), .Y(new_n335_));
  AO21x1_ASAP7_75t_R   g314(.A1(new_n333_), .A2(new_n334_), .B(new_n335_), .Y(new_n336_));
  OR3x1_ASAP7_75t_R    g315(.A(p3), .B(p6), .C(p2), .Y(new_n337_));
  AO21x1_ASAP7_75t_R   g316(.A1(new_n331_), .A2(new_n336_), .B(new_n337_), .Y(new_n338_));
  NAND2x1_ASAP7_75t_R  g317(.A(new_n326_), .B(new_n338_), .Y(new_n339_));
  AOI21x1_ASAP7_75t_R  g318(.A1(new_n22_), .A2(new_n315_), .B(new_n339_), .Y(o6));
  OR3x1_ASAP7_75t_R    g319(.A(new_n41_), .B(new_n71_), .C(p7), .Y(new_n341_));
  INVx1_ASAP7_75t_R    g320(.A(new_n341_), .Y(new_n342_));
  NAND2x1_ASAP7_75t_R  g321(.A(p9), .B(new_n41_), .Y(new_n343_));
  NAND2x1_ASAP7_75t_R  g322(.A(new_n29_), .B(new_n27_), .Y(new_n344_));
  OAI22x1_ASAP7_75t_R  g323(.A1(new_n343_), .A2(new_n42_), .B1(new_n71_), .B2(new_n344_), .Y(new_n345_));
  AOI21x1_ASAP7_75t_R  g324(.A1(new_n54_), .A2(new_n341_), .B(p2), .Y(new_n346_));
  OAI21x1_ASAP7_75t_R  g325(.A1(new_n342_), .A2(new_n345_), .B(new_n346_), .Y(new_n347_));
  OR3x1_ASAP7_75t_R    g326(.A(new_n25_), .B(new_n210_), .C(new_n153_), .Y(new_n348_));
  NOR3x1_ASAP7_75t_R   g327(.A(new_n86_), .B(new_n24_), .C(new_n288_), .Y(new_n349_));
  NAND2x1_ASAP7_75t_R  g328(.A(p1), .B(new_n153_), .Y(new_n350_));
  AND3x1_ASAP7_75t_R   g329(.A(p1), .B(p7), .C(p2), .Y(new_n351_));
  NAND2x1_ASAP7_75t_R  g330(.A(new_n253_), .B(new_n351_), .Y(new_n352_));
  OAI21x1_ASAP7_75t_R  g331(.A1(new_n77_), .A2(new_n350_), .B(new_n352_), .Y(new_n353_));
  NAND3x1_ASAP7_75t_R  g332(.A(new_n100_), .B(p4), .C(p2), .Y(new_n354_));
  NOR2x1_ASAP7_75t_R   g333(.A(new_n49_), .B(new_n42_), .Y(new_n355_));
  OA21x2_ASAP7_75t_R   g334(.A1(p8), .A2(new_n72_), .B(new_n190_), .Y(new_n356_));
  AOI21x1_ASAP7_75t_R  g335(.A1(new_n354_), .A2(new_n355_), .B(new_n356_), .Y(new_n357_));
  AOI211x1_ASAP7_75t_R g336(.A1(new_n348_), .A2(new_n349_), .B(new_n353_), .C(new_n357_), .Y(new_n358_));
  NAND2x1_ASAP7_75t_R  g337(.A(p9), .B(p2), .Y(new_n359_));
  NOR2x1_ASAP7_75t_R   g338(.A(p0), .B(new_n359_), .Y(new_n360_));
  NOR3x1_ASAP7_75t_R   g339(.A(new_n72_), .B(p8), .C(p7), .Y(new_n361_));
  AOI22x1_ASAP7_75t_R  g340(.A1(new_n360_), .A2(new_n361_), .B1(new_n253_), .B2(new_n351_), .Y(new_n362_));
  AO22x1_ASAP7_75t_R   g341(.A1(p8), .A2(p7), .B1(p1), .B2(p2), .Y(new_n363_));
  AOI21x1_ASAP7_75t_R  g342(.A1(new_n72_), .A2(new_n359_), .B(new_n71_), .Y(new_n364_));
  OAI21x1_ASAP7_75t_R  g343(.A1(new_n153_), .A2(new_n363_), .B(new_n364_), .Y(new_n365_));
  AO31x2_ASAP7_75t_R   g344(.A1(new_n362_), .A2(new_n61_), .A3(new_n365_), .B(p5), .Y(new_n366_));
  AOI21x1_ASAP7_75t_R  g345(.A1(new_n347_), .A2(new_n358_), .B(new_n366_), .Y(new_n367_));
  NOR2x1_ASAP7_75t_R   g346(.A(new_n71_), .B(new_n367_), .Y(new_n368_));
  AOI211x1_ASAP7_75t_R g347(.A1(new_n54_), .A2(new_n151_), .B(new_n310_), .C(new_n30_), .Y(new_n369_));
  NAND2x1_ASAP7_75t_R  g348(.A(p7), .B(new_n27_), .Y(new_n370_));
  NAND2x1_ASAP7_75t_R  g349(.A(p5), .B(new_n54_), .Y(new_n371_));
  OAI21x1_ASAP7_75t_R  g350(.A1(new_n59_), .A2(new_n370_), .B(new_n371_), .Y(new_n372_));
  AOI22x1_ASAP7_75t_R  g351(.A1(new_n369_), .A2(new_n59_), .B1(new_n372_), .B2(p8), .Y(new_n373_));
  OAI21x1_ASAP7_75t_R  g352(.A1(new_n38_), .A2(new_n210_), .B(new_n124_), .Y(new_n374_));
  AND3x1_ASAP7_75t_R   g353(.A(new_n105_), .B(new_n54_), .C(new_n38_), .Y(new_n375_));
  NOR2x1_ASAP7_75t_R   g354(.A(new_n219_), .B(new_n247_), .Y(new_n376_));
  AOI211x1_ASAP7_75t_R g355(.A1(new_n269_), .A2(new_n374_), .B(new_n375_), .C(new_n376_), .Y(new_n377_));
  OAI21x1_ASAP7_75t_R  g356(.A1(p1), .A2(new_n373_), .B(new_n377_), .Y(new_n378_));
  AO21x1_ASAP7_75t_R   g357(.A1(p8), .A2(p7), .B(p5), .Y(new_n379_));
  OAI22x1_ASAP7_75t_R  g358(.A1(new_n328_), .A2(new_n45_), .B1(new_n179_), .B2(new_n379_), .Y(new_n380_));
  NAND2x1_ASAP7_75t_R  g359(.A(new_n216_), .B(new_n380_), .Y(new_n381_));
  OAI21x1_ASAP7_75t_R  g360(.A1(p5), .A2(new_n128_), .B(new_n233_), .Y(new_n382_));
  OR3x1_ASAP7_75t_R    g361(.A(new_n124_), .B(new_n58_), .C(p8), .Y(new_n383_));
  AO31x2_ASAP7_75t_R   g362(.A1(new_n382_), .A2(new_n383_), .A3(new_n146_), .B(p0), .Y(new_n384_));
  OR4x2_ASAP7_75t_R    g363(.A(new_n101_), .B(new_n58_), .C(p8), .D(new_n38_), .Y(new_n385_));
  NAND3x1_ASAP7_75t_R  g364(.A(new_n381_), .B(new_n384_), .C(new_n385_), .Y(new_n386_));
  AOI211x1_ASAP7_75t_R g365(.A1(p0), .A2(new_n378_), .B(new_n386_), .C(new_n367_), .Y(new_n387_));
  INVx1_ASAP7_75t_R    g366(.A(new_n150_), .Y(new_n388_));
  AO22x1_ASAP7_75t_R   g367(.A1(new_n125_), .A2(new_n317_), .B1(new_n328_), .B2(new_n388_), .Y(new_n389_));
  AND3x1_ASAP7_75t_R   g368(.A(new_n389_), .B(new_n174_), .C(new_n52_), .Y(new_n390_));
  OAI21x1_ASAP7_75t_R  g369(.A1(new_n324_), .A2(new_n390_), .B(new_n278_), .Y(new_n391_));
  OA31x2_ASAP7_75t_R   g370(.A1(new_n23_), .A2(new_n368_), .A3(new_n387_), .B1(new_n391_), .Y(o7));
  AO21x1_ASAP7_75t_R   g371(.A1(p4), .A2(p2), .B(new_n154_), .Y(new_n393_));
  AND3x1_ASAP7_75t_R   g372(.A(new_n143_), .B(p0), .C(new_n60_), .Y(new_n394_));
  OA211x2_ASAP7_75t_R  g373(.A1(new_n71_), .A2(p9), .B(new_n216_), .C(new_n182_), .Y(new_n395_));
  AO211x2_ASAP7_75t_R  g374(.A1(new_n393_), .A2(new_n394_), .B(new_n29_), .C(new_n395_), .Y(new_n396_));
  AO21x1_ASAP7_75t_R   g375(.A1(p4), .A2(new_n61_), .B(new_n96_), .Y(new_n397_));
  OA21x2_ASAP7_75t_R   g376(.A1(p9), .A2(p2), .B(new_n182_), .Y(new_n398_));
  AOI21x1_ASAP7_75t_R  g377(.A1(new_n397_), .A2(new_n398_), .B(p8), .Y(new_n399_));
  AND3x1_ASAP7_75t_R   g378(.A(new_n123_), .B(p7), .C(new_n52_), .Y(new_n400_));
  AND3x1_ASAP7_75t_R   g379(.A(new_n116_), .B(new_n221_), .C(new_n190_), .Y(new_n401_));
  NOR2x1_ASAP7_75t_R   g380(.A(new_n400_), .B(new_n401_), .Y(new_n402_));
  AOI21x1_ASAP7_75t_R  g381(.A1(new_n399_), .A2(new_n402_), .B(p5), .Y(new_n403_));
  OAI22x1_ASAP7_75t_R  g382(.A1(new_n99_), .A2(new_n247_), .B1(new_n65_), .B2(new_n250_), .Y(new_n404_));
  AO21x1_ASAP7_75t_R   g383(.A1(p8), .A2(new_n38_), .B(p1), .Y(new_n405_));
  AOI211x1_ASAP7_75t_R g384(.A1(new_n86_), .A2(new_n250_), .B(new_n48_), .C(new_n405_), .Y(new_n406_));
  AND3x1_ASAP7_75t_R   g385(.A(new_n42_), .B(p4), .C(new_n61_), .Y(new_n407_));
  OA21x2_ASAP7_75t_R   g386(.A1(new_n203_), .A2(new_n407_), .B(new_n27_), .Y(new_n408_));
  OA31x2_ASAP7_75t_R   g387(.A1(new_n404_), .A2(new_n406_), .A3(new_n408_), .B1(new_n159_), .Y(new_n409_));
  INVx1_ASAP7_75t_R    g388(.A(new_n370_), .Y(new_n410_));
  AO21x1_ASAP7_75t_R   g389(.A1(new_n163_), .A2(new_n410_), .B(new_n230_), .Y(new_n411_));
  AND3x1_ASAP7_75t_R   g390(.A(new_n312_), .B(new_n58_), .C(new_n55_), .Y(new_n412_));
  AOI211x1_ASAP7_75t_R g391(.A1(new_n72_), .A2(new_n411_), .B(new_n255_), .C(new_n412_), .Y(new_n413_));
  AOI211x1_ASAP7_75t_R g392(.A1(new_n396_), .A2(new_n403_), .B(new_n409_), .C(new_n413_), .Y(new_n414_));
  AO21x1_ASAP7_75t_R   g393(.A1(new_n41_), .A2(new_n124_), .B(new_n355_), .Y(new_n415_));
  OAI21x1_ASAP7_75t_R  g394(.A1(new_n344_), .A2(new_n329_), .B(new_n415_), .Y(new_n416_));
  AND3x1_ASAP7_75t_R   g395(.A(new_n302_), .B(p8), .C(new_n288_), .Y(new_n417_));
  AO21x1_ASAP7_75t_R   g396(.A1(new_n61_), .A2(new_n416_), .B(new_n417_), .Y(new_n418_));
  AOI22x1_ASAP7_75t_R  g397(.A1(new_n418_), .A2(new_n316_), .B1(new_n71_), .B2(new_n324_), .Y(new_n419_));
  OA21x2_ASAP7_75t_R   g398(.A1(new_n23_), .A2(new_n414_), .B(new_n419_), .Y(o8));
  AND2x2_ASAP7_75t_R   g399(.A(p2), .B(new_n151_), .Y(new_n421_));
  OR3x1_ASAP7_75t_R    g400(.A(new_n370_), .B(new_n105_), .C(new_n278_), .Y(new_n422_));
  AND3x1_ASAP7_75t_R   g401(.A(new_n233_), .B(new_n38_), .C(new_n280_), .Y(new_n423_));
  INVx1_ASAP7_75t_R    g402(.A(new_n286_), .Y(new_n424_));
  OA21x2_ASAP7_75t_R   g403(.A1(new_n278_), .A2(new_n424_), .B(new_n72_), .Y(new_n425_));
  OAI21x1_ASAP7_75t_R  g404(.A1(new_n423_), .A2(new_n425_), .B(new_n61_), .Y(new_n426_));
  AO21x1_ASAP7_75t_R   g405(.A1(new_n421_), .A2(new_n422_), .B(new_n426_), .Y(new_n427_));
  OR3x1_ASAP7_75t_R    g406(.A(new_n262_), .B(p4), .C(new_n27_), .Y(new_n428_));
  AO21x1_ASAP7_75t_R   g407(.A1(new_n79_), .A2(new_n428_), .B(new_n321_), .Y(new_n429_));
  AOI22x1_ASAP7_75t_R  g408(.A1(new_n247_), .A2(p6), .B1(p3), .B2(new_n111_), .Y(new_n430_));
  AO21x1_ASAP7_75t_R   g409(.A1(new_n79_), .A2(new_n111_), .B(new_n27_), .Y(new_n431_));
  OA211x2_ASAP7_75t_R  g410(.A1(new_n193_), .A2(new_n135_), .B(new_n431_), .C(new_n34_), .Y(new_n432_));
  AND3x1_ASAP7_75t_R   g411(.A(new_n429_), .B(new_n430_), .C(new_n432_), .Y(new_n433_));
  OR4x2_ASAP7_75t_R    g412(.A(new_n105_), .B(new_n159_), .C(new_n278_), .D(p2), .Y(new_n434_));
  OA21x2_ASAP7_75t_R   g413(.A1(new_n280_), .A2(new_n262_), .B(new_n434_), .Y(new_n435_));
  OA21x2_ASAP7_75t_R   g414(.A1(p2), .A2(new_n89_), .B(new_n370_), .Y(new_n436_));
  OR3x1_ASAP7_75t_R    g415(.A(new_n436_), .B(p1), .C(new_n421_), .Y(new_n437_));
  AO21x1_ASAP7_75t_R   g416(.A1(new_n435_), .A2(new_n437_), .B(new_n61_), .Y(new_n438_));
  AND3x1_ASAP7_75t_R   g417(.A(new_n427_), .B(new_n433_), .C(new_n438_), .Y(o9));
  AO21x1_ASAP7_75t_R   g418(.A1(p0), .A2(new_n167_), .B(new_n54_), .Y(new_n440_));
  OA211x2_ASAP7_75t_R  g419(.A1(p0), .A2(new_n28_), .B(new_n174_), .C(new_n25_), .Y(new_n441_));
  AO21x1_ASAP7_75t_R   g420(.A1(new_n440_), .A2(new_n441_), .B(new_n291_), .Y(new_n442_));
  AND3x1_ASAP7_75t_R   g421(.A(new_n442_), .B(new_n79_), .C(new_n278_), .Y(o10));
endmodule


