// Benchmark "/tmp/" written by ABC on Tue Oct 13 18:50:23 2026

module \/tmp/  ( 
    p3, p8, p6, p5, p9, p7, p2, p4, p1, p0,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10  );
  input  p3, p8, p6, p5, p9, p7, p2, p4, p1, p0;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10;
  wire new_n22_, new_n23_, new_n24_, new_n25_, new_n26_, new_n27_, new_n28_,
    new_n29_, new_n30_, new_n31_, new_n32_, new_n33_, new_n34_, new_n35_,
    new_n36_, new_n37_, new_n38_, new_n39_, new_n40_, new_n41_, new_n42_,
    new_n43_, new_n44_, new_n45_, new_n46_, new_n47_, new_n48_, new_n49_,
    new_n50_, new_n51_, new_n52_, new_n53_, new_n54_, new_n55_, new_n56_,
    new_n57_, new_n58_, new_n59_, new_n60_, new_n61_, new_n62_, new_n63_,
    new_n64_, new_n65_, new_n66_, new_n67_, new_n68_, new_n69_, new_n70_,
    new_n71_, new_n72_, new_n73_, new_n74_, new_n75_, new_n76_, new_n77_,
    new_n78_, new_n79_, new_n80_, new_n81_, new_n82_, new_n83_, new_n84_,
    new_n85_, new_n86_, new_n87_, new_n88_, new_n89_, new_n90_, new_n91_,
    new_n92_, new_n93_, new_n94_, new_n95_, new_n96_, new_n97_, new_n98_,
    new_n99_, new_n100_, new_n101_, new_n102_, new_n103_, new_n104_,
    new_n105_, new_n106_, new_n107_, new_n108_, new_n109_, new_n110_,
    new_n111_, new_n112_, new_n113_, new_n114_, new_n115_, new_n116_,
    new_n118_, new_n119_, new_n120_, new_n121_, new_n122_, new_n123_,
    new_n124_, new_n125_, new_n126_, new_n127_, new_n128_, new_n129_,
    new_n130_, new_n131_, new_n132_, new_n133_, new_n134_, new_n135_,
    new_n136_, new_n137_, new_n138_, new_n139_, new_n140_, new_n141_,
    new_n142_, new_n143_, new_n144_, new_n145_, new_n146_, new_n147_,
    new_n148_, new_n149_, new_n150_, new_n151_, new_n152_, new_n153_,
    new_n154_, new_n155_, new_n156_, new_n157_, new_n158_, new_n159_,
    new_n160_, new_n161_, new_n162_, new_n163_, new_n164_, new_n165_,
    new_n166_, new_n167_, new_n168_, new_n169_, new_n170_, new_n171_,
    new_n172_, new_n173_, new_n174_, new_n175_, new_n176_, new_n177_,
    new_n178_, new_n179_, new_n180_, new_n181_, new_n182_, new_n183_,
    new_n184_, new_n185_, new_n187_, new_n188_, new_n189_, new_n190_,
    new_n191_, new_n192_, new_n193_, new_n194_, new_n195_, new_n196_,
    new_n197_, new_n198_, new_n199_, new_n200_, new_n201_, new_n202_,
    new_n203_, new_n204_, new_n205_, new_n206_, new_n207_, new_n208_,
    new_n209_, new_n210_, new_n211_, new_n212_, new_n213_, new_n214_,
    new_n215_, new_n216_, new_n217_, new_n218_, new_n219_, new_n220_,
    new_n221_, new_n222_, new_n223_, new_n224_, new_n225_, new_n226_,
    new_n227_, new_n228_, new_n229_, new_n230_, new_n231_, new_n232_,
    new_n233_, new_n234_, new_n235_, new_n236_, new_n237_, new_n238_,
    new_n239_, new_n240_, new_n241_, new_n242_, new_n243_, new_n244_,
    new_n245_, new_n246_, new_n247_, new_n248_, new_n249_, new_n250_,
    new_n252_, new_n253_, new_n254_, new_n255_, new_n256_, new_n257_,
    new_n258_, new_n259_, new_n260_, new_n261_, new_n262_, new_n263_,
    new_n264_, new_n265_, new_n266_, new_n267_, new_n268_, new_n269_,
    new_n270_, new_n271_, new_n272_, new_n273_, new_n274_, new_n275_,
    new_n276_, new_n277_, new_n278_, new_n279_, new_n280_, new_n281_,
    new_n282_, new_n283_, new_n284_, new_n285_, new_n286_, new_n287_,
    new_n288_, new_n289_, new_n291_, new_n292_, new_n293_, new_n294_,
    new_n295_, new_n297_, new_n298_, new_n300_, new_n301_, new_n302_,
    new_n303_, new_n304_, new_n305_, new_n306_, new_n307_, new_n308_,
    new_n309_, new_n310_, new_n311_, new_n312_, new_n313_, new_n314_,
    new_n315_, new_n316_, new_n317_, new_n318_, new_n319_, new_n320_,
    new_n321_, new_n322_, new_n323_, new_n324_, new_n325_, new_n326_,
    new_n327_, new_n328_, new_n329_, new_n330_, new_n331_, new_n332_,
    new_n333_, new_n334_, new_n335_, new_n336_, new_n337_, new_n338_,
    new_n339_, new_n340_, new_n341_, new_n342_, new_n344_, new_n345_,
    new_n346_, new_n347_, new_n348_, new_n349_, new_n350_, new_n351_,
    new_n352_, new_n353_, new_n354_, new_n355_, new_n356_, new_n357_,
    new_n358_, new_n359_, new_n360_, new_n361_, new_n362_, new_n363_,
    new_n364_, new_n365_, new_n366_, new_n367_, new_n368_, new_n369_,
    new_n370_, new_n371_, new_n372_, new_n373_, new_n374_, new_n375_,
    new_n376_, new_n377_, new_n378_, new_n379_, new_n380_, new_n381_,
    new_n382_, new_n383_, new_n384_, new_n385_, new_n386_, new_n387_,
    new_n388_, new_n389_, new_n390_, new_n391_, new_n392_, new_n394_,
    new_n395_, new_n396_, new_n397_, new_n398_, new_n399_, new_n400_,
    new_n401_, new_n402_, new_n403_, new_n404_, new_n405_, new_n406_,
    new_n407_, new_n408_, new_n409_, new_n410_, new_n411_, new_n412_,
    new_n413_, new_n414_, new_n415_, new_n416_, new_n417_, new_n418_,
    new_n419_, new_n420_, new_n421_, new_n422_, new_n423_, new_n424_,
    new_n425_, new_n426_, new_n428_, new_n429_, new_n430_, new_n431_,
    new_n432_, new_n433_, new_n434_, new_n435_, new_n436_, new_n437_,
    new_n438_, new_n439_, new_n440_, new_n441_, new_n442_, new_n443_,
    new_n444_, new_n445_, new_n447_, new_n448_;
  NOR2x1_ASAP7_75t_R   g000(.A(p3), .B(p6), .Y(new_n22_));
  INVx1_ASAP7_75t_R    g001(.A(new_n22_), .Y(new_n23_));
  INVx1_ASAP7_75t_R    g002(.A(p4), .Y(new_n24_));
  AND2x2_ASAP7_75t_R   g003(.A(p8), .B(p1), .Y(new_n25_));
  INVx1_ASAP7_75t_R    g004(.A(p5), .Y(new_n26_));
  NAND2x1_ASAP7_75t_R  g005(.A(p2), .B(new_n26_), .Y(new_n27_));
  NAND2x1_ASAP7_75t_R  g006(.A(p2), .B(p1), .Y(new_n28_));
  NOR2x1_ASAP7_75t_R   g007(.A(p8), .B(p0), .Y(new_n29_));
  AND3x1_ASAP7_75t_R   g008(.A(new_n27_), .B(new_n28_), .C(new_n29_), .Y(new_n30_));
  INVx1_ASAP7_75t_R    g009(.A(p7), .Y(new_n31_));
  OAI21x1_ASAP7_75t_R  g010(.A1(new_n25_), .A2(new_n30_), .B(new_n31_), .Y(new_n32_));
  INVx1_ASAP7_75t_R    g011(.A(p0), .Y(new_n33_));
  NOR2x1_ASAP7_75t_R   g012(.A(p7), .B(new_n33_), .Y(new_n34_));
  INVx1_ASAP7_75t_R    g013(.A(new_n34_), .Y(new_n35_));
  INVx1_ASAP7_75t_R    g014(.A(p1), .Y(new_n36_));
  NOR2x1_ASAP7_75t_R   g015(.A(p0), .B(new_n36_), .Y(new_n37_));
  INVx1_ASAP7_75t_R    g016(.A(p9), .Y(new_n38_));
  NOR2x1_ASAP7_75t_R   g017(.A(p8), .B(new_n38_), .Y(new_n39_));
  NAND2x1_ASAP7_75t_R  g018(.A(new_n37_), .B(new_n39_), .Y(new_n40_));
  INVx1_ASAP7_75t_R    g019(.A(p2), .Y(new_n41_));
  AO21x1_ASAP7_75t_R   g020(.A1(new_n35_), .A2(new_n40_), .B(new_n41_), .Y(new_n42_));
  NOR2x1_ASAP7_75t_R   g021(.A(p2), .B(p0), .Y(new_n43_));
  NAND2x1_ASAP7_75t_R  g022(.A(new_n43_), .B(new_n25_), .Y(new_n44_));
  INVx1_ASAP7_75t_R    g023(.A(p8), .Y(new_n45_));
  OR3x1_ASAP7_75t_R    g024(.A(new_n45_), .B(new_n41_), .C(p7), .Y(new_n46_));
  AO31x2_ASAP7_75t_R   g025(.A1(new_n35_), .A2(new_n44_), .A3(new_n46_), .B(p9), .Y(new_n47_));
  NAND3x1_ASAP7_75t_R  g026(.A(new_n32_), .B(new_n42_), .C(new_n47_), .Y(new_n48_));
  NOR2x1_ASAP7_75t_R   g027(.A(p7), .B(p2), .Y(new_n49_));
  NOR2x1_ASAP7_75t_R   g028(.A(p9), .B(p0), .Y(new_n50_));
  NOR2x1_ASAP7_75t_R   g029(.A(p8), .B(p1), .Y(new_n51_));
  AND3x1_ASAP7_75t_R   g030(.A(new_n49_), .B(new_n50_), .C(new_n51_), .Y(new_n52_));
  NAND2x1_ASAP7_75t_R  g031(.A(p8), .B(p5), .Y(new_n53_));
  OR3x1_ASAP7_75t_R    g032(.A(p9), .B(p1), .C(p0), .Y(new_n54_));
  NAND2x1_ASAP7_75t_R  g033(.A(p5), .B(p4), .Y(new_n55_));
  OAI21x1_ASAP7_75t_R  g034(.A1(new_n53_), .A2(new_n54_), .B(new_n55_), .Y(new_n56_));
  AO21x1_ASAP7_75t_R   g035(.A1(p8), .A2(new_n38_), .B(new_n33_), .Y(new_n57_));
  NAND2x1_ASAP7_75t_R  g036(.A(p4), .B(p1), .Y(new_n58_));
  NOR3x1_ASAP7_75t_R   g037(.A(new_n57_), .B(new_n39_), .C(new_n58_), .Y(new_n59_));
  OAI21x1_ASAP7_75t_R  g038(.A1(new_n56_), .A2(new_n59_), .B(p2), .Y(new_n60_));
  OA21x2_ASAP7_75t_R   g039(.A1(p8), .A2(new_n38_), .B(new_n36_), .Y(new_n61_));
  OAI21x1_ASAP7_75t_R  g040(.A1(p2), .A2(new_n57_), .B(new_n61_), .Y(new_n62_));
  NAND2x1_ASAP7_75t_R  g041(.A(p9), .B(new_n45_), .Y(new_n63_));
  NOR2x1_ASAP7_75t_R   g042(.A(p1), .B(new_n24_), .Y(new_n64_));
  INVx1_ASAP7_75t_R    g043(.A(new_n55_), .Y(new_n65_));
  AO21x1_ASAP7_75t_R   g044(.A1(new_n63_), .A2(new_n64_), .B(new_n65_), .Y(new_n66_));
  AO21x1_ASAP7_75t_R   g045(.A1(p0), .A2(new_n51_), .B(new_n25_), .Y(new_n67_));
  AND3x1_ASAP7_75t_R   g046(.A(new_n38_), .B(new_n41_), .C(p5), .Y(new_n68_));
  AOI22x1_ASAP7_75t_R  g047(.A1(new_n62_), .A2(new_n66_), .B1(new_n67_), .B2(new_n68_), .Y(new_n69_));
  AOI21x1_ASAP7_75t_R  g048(.A1(new_n60_), .A2(new_n69_), .B(new_n31_), .Y(new_n70_));
  AOI211x1_ASAP7_75t_R g049(.A1(new_n24_), .A2(new_n48_), .B(new_n52_), .C(new_n70_), .Y(new_n71_));
  NOR2x1_ASAP7_75t_R   g050(.A(p3), .B(p5), .Y(new_n72_));
  NOR2x1_ASAP7_75t_R   g051(.A(p0), .B(new_n45_), .Y(new_n73_));
  NOR2x1_ASAP7_75t_R   g052(.A(p2), .B(p1), .Y(new_n74_));
  INVx1_ASAP7_75t_R    g053(.A(new_n74_), .Y(new_n75_));
  NOR2x1_ASAP7_75t_R   g054(.A(p2), .B(new_n33_), .Y(new_n76_));
  NAND2x1_ASAP7_75t_R  g055(.A(p9), .B(p2), .Y(new_n77_));
  NOR2x1_ASAP7_75t_R   g056(.A(p0), .B(new_n77_), .Y(new_n78_));
  AOI211x1_ASAP7_75t_R g057(.A1(new_n73_), .A2(new_n75_), .B(new_n76_), .C(new_n78_), .Y(new_n79_));
  NAND2x1_ASAP7_75t_R  g058(.A(p1), .B(p0), .Y(new_n80_));
  AO21x1_ASAP7_75t_R   g059(.A1(new_n24_), .A2(new_n36_), .B(p9), .Y(new_n81_));
  AO21x1_ASAP7_75t_R   g060(.A1(new_n80_), .A2(new_n81_), .B(p8), .Y(new_n82_));
  AO21x1_ASAP7_75t_R   g061(.A1(new_n79_), .A2(new_n82_), .B(p6), .Y(new_n83_));
  NOR2x1_ASAP7_75t_R   g062(.A(p1), .B(new_n38_), .Y(new_n84_));
  AO21x1_ASAP7_75t_R   g063(.A1(new_n45_), .A2(new_n24_), .B(p0), .Y(new_n85_));
  AND3x1_ASAP7_75t_R   g064(.A(new_n50_), .B(new_n45_), .C(p1), .Y(new_n86_));
  AO22x1_ASAP7_75t_R   g065(.A1(new_n84_), .A2(new_n85_), .B1(p6), .B2(new_n86_), .Y(new_n87_));
  NAND2x1_ASAP7_75t_R  g066(.A(p7), .B(new_n24_), .Y(new_n88_));
  INVx1_ASAP7_75t_R    g067(.A(p6), .Y(new_n89_));
  NOR2x1_ASAP7_75t_R   g068(.A(p8), .B(p4), .Y(new_n90_));
  OAI21x1_ASAP7_75t_R  g069(.A1(new_n89_), .A2(new_n90_), .B(new_n84_), .Y(new_n91_));
  NAND2x1_ASAP7_75t_R  g070(.A(p0), .B(new_n45_), .Y(new_n92_));
  OAI21x1_ASAP7_75t_R  g071(.A1(p6), .A2(new_n92_), .B(new_n41_), .Y(new_n93_));
  AOI21x1_ASAP7_75t_R  g072(.A1(new_n88_), .A2(new_n91_), .B(new_n93_), .Y(new_n94_));
  NAND2x1_ASAP7_75t_R  g073(.A(p9), .B(p0), .Y(new_n95_));
  NOR2x1_ASAP7_75t_R   g074(.A(p2), .B(p4), .Y(new_n96_));
  NAND2x1_ASAP7_75t_R  g075(.A(new_n95_), .B(new_n96_), .Y(new_n97_));
  AO21x1_ASAP7_75t_R   g076(.A1(new_n38_), .A2(new_n33_), .B(p6), .Y(new_n98_));
  XOR2x2_ASAP7_75t_R   g077(.A(p8), .B(p0), .Y(new_n99_));
  NOR2x1_ASAP7_75t_R   g078(.A(p7), .B(p1), .Y(new_n100_));
  INVx1_ASAP7_75t_R    g079(.A(new_n100_), .Y(new_n101_));
  AOI211x1_ASAP7_75t_R g080(.A1(new_n97_), .A2(new_n98_), .B(new_n99_), .C(new_n101_), .Y(new_n102_));
  AOI21x1_ASAP7_75t_R  g081(.A1(new_n87_), .A2(new_n94_), .B(new_n102_), .Y(new_n103_));
  OAI21x1_ASAP7_75t_R  g082(.A1(p7), .A2(new_n83_), .B(new_n103_), .Y(new_n104_));
  NAND2x1_ASAP7_75t_R  g083(.A(p3), .B(p8), .Y(new_n105_));
  OAI21x1_ASAP7_75t_R  g084(.A1(p8), .A2(new_n26_), .B(new_n105_), .Y(new_n106_));
  AND3x1_ASAP7_75t_R   g085(.A(new_n106_), .B(new_n31_), .C(new_n55_), .Y(new_n107_));
  NOR2x1_ASAP7_75t_R   g086(.A(p7), .B(new_n24_), .Y(new_n108_));
  NOR2x1_ASAP7_75t_R   g087(.A(p8), .B(p5), .Y(new_n109_));
  AO21x1_ASAP7_75t_R   g088(.A1(p3), .A2(p7), .B(new_n109_), .Y(new_n110_));
  OA21x2_ASAP7_75t_R   g089(.A1(new_n65_), .A2(new_n108_), .B(new_n110_), .Y(new_n111_));
  NOR2x1_ASAP7_75t_R   g090(.A(p1), .B(p0), .Y(new_n112_));
  NOR2x1_ASAP7_75t_R   g091(.A(p6), .B(p9), .Y(new_n113_));
  AND3x1_ASAP7_75t_R   g092(.A(new_n112_), .B(new_n113_), .C(new_n41_), .Y(new_n114_));
  OA21x2_ASAP7_75t_R   g093(.A1(new_n107_), .A2(new_n111_), .B(new_n114_), .Y(new_n115_));
  AOI21x1_ASAP7_75t_R  g094(.A1(new_n72_), .A2(new_n104_), .B(new_n115_), .Y(new_n116_));
  OAI21x1_ASAP7_75t_R  g095(.A1(new_n23_), .A2(new_n71_), .B(new_n116_), .Y(o0));
  NOR2x1_ASAP7_75t_R   g096(.A(new_n95_), .B(new_n55_), .Y(new_n118_));
  AND3x1_ASAP7_75t_R   g097(.A(p2), .B(p1), .C(p0), .Y(new_n119_));
  OA22x2_ASAP7_75t_R   g098(.A1(new_n118_), .A2(new_n119_), .B1(p5), .B2(new_n108_), .Y(new_n120_));
  AND3x1_ASAP7_75t_R   g099(.A(new_n78_), .B(p5), .C(new_n100_), .Y(new_n121_));
  AO21x1_ASAP7_75t_R   g100(.A1(new_n65_), .A2(new_n75_), .B(new_n45_), .Y(new_n122_));
  OR3x1_ASAP7_75t_R    g101(.A(new_n120_), .B(new_n121_), .C(new_n122_), .Y(new_n123_));
  AO21x1_ASAP7_75t_R   g102(.A1(p5), .A2(new_n33_), .B(new_n36_), .Y(new_n124_));
  NAND2x1_ASAP7_75t_R  g103(.A(new_n31_), .B(new_n33_), .Y(new_n125_));
  NOR2x1_ASAP7_75t_R   g104(.A(p4), .B(new_n41_), .Y(new_n126_));
  AO31x2_ASAP7_75t_R   g105(.A1(new_n124_), .A2(new_n125_), .A3(new_n126_), .B(p8), .Y(new_n127_));
  NAND2x1_ASAP7_75t_R  g106(.A(p4), .B(new_n100_), .Y(new_n128_));
  AO21x1_ASAP7_75t_R   g107(.A1(new_n31_), .A2(new_n41_), .B(new_n38_), .Y(new_n129_));
  NOR2x1_ASAP7_75t_R   g108(.A(p5), .B(p0), .Y(new_n130_));
  OAI21x1_ASAP7_75t_R  g109(.A1(new_n31_), .A2(p4), .B(new_n130_), .Y(new_n131_));
  AOI21x1_ASAP7_75t_R  g110(.A1(new_n128_), .A2(new_n129_), .B(new_n131_), .Y(new_n132_));
  XNOR2x2_ASAP7_75t_R  g111(.A(p9), .B(p4), .Y(new_n133_));
  OR3x1_ASAP7_75t_R    g112(.A(new_n38_), .B(new_n31_), .C(p1), .Y(new_n134_));
  NAND2x1_ASAP7_75t_R  g113(.A(p0), .B(new_n26_), .Y(new_n135_));
  AOI21x1_ASAP7_75t_R  g114(.A1(new_n133_), .A2(new_n134_), .B(new_n135_), .Y(new_n136_));
  AO21x1_ASAP7_75t_R   g115(.A1(p7), .A2(new_n38_), .B(p4), .Y(new_n137_));
  AOI21x1_ASAP7_75t_R  g116(.A1(p9), .A2(p0), .B(p1), .Y(new_n138_));
  OAI21x1_ASAP7_75t_R  g117(.A1(p5), .A2(p0), .B(new_n138_), .Y(new_n139_));
  NOR2x1_ASAP7_75t_R   g118(.A(p5), .B(p9), .Y(new_n140_));
  AO21x1_ASAP7_75t_R   g119(.A1(p7), .A2(p2), .B(p1), .Y(new_n141_));
  NAND2x1_ASAP7_75t_R  g120(.A(new_n140_), .B(new_n141_), .Y(new_n142_));
  OAI21x1_ASAP7_75t_R  g121(.A1(new_n137_), .A2(new_n139_), .B(new_n142_), .Y(new_n143_));
  OR4x2_ASAP7_75t_R    g122(.A(new_n127_), .B(new_n132_), .C(new_n136_), .D(new_n143_), .Y(new_n144_));
  NOR2x1_ASAP7_75t_R   g123(.A(p9), .B(p7), .Y(new_n145_));
  NAND2x1_ASAP7_75t_R  g124(.A(new_n51_), .B(new_n145_), .Y(new_n146_));
  NAND2x1_ASAP7_75t_R  g125(.A(p8), .B(p1), .Y(new_n147_));
  OR3x1_ASAP7_75t_R    g126(.A(new_n147_), .B(new_n38_), .C(new_n31_), .Y(new_n148_));
  AO21x1_ASAP7_75t_R   g127(.A1(new_n146_), .A2(new_n148_), .B(new_n24_), .Y(new_n149_));
  AO21x1_ASAP7_75t_R   g128(.A1(new_n53_), .A2(new_n88_), .B(p9), .Y(new_n150_));
  AND3x1_ASAP7_75t_R   g129(.A(p8), .B(p5), .C(p7), .Y(new_n151_));
  AND3x1_ASAP7_75t_R   g130(.A(new_n45_), .B(new_n31_), .C(new_n24_), .Y(new_n152_));
  NOR2x1_ASAP7_75t_R   g131(.A(new_n151_), .B(new_n152_), .Y(new_n153_));
  AO21x1_ASAP7_75t_R   g132(.A1(new_n150_), .A2(new_n153_), .B(new_n36_), .Y(new_n154_));
  INVx1_ASAP7_75t_R    g133(.A(new_n43_), .Y(new_n155_));
  AOI21x1_ASAP7_75t_R  g134(.A1(new_n149_), .A2(new_n154_), .B(new_n155_), .Y(new_n156_));
  NOR2x1_ASAP7_75t_R   g135(.A(p5), .B(p7), .Y(new_n157_));
  AOI211x1_ASAP7_75t_R g136(.A1(p5), .A2(new_n38_), .B(p1), .C(new_n157_), .Y(new_n158_));
  NOR2x1_ASAP7_75t_R   g137(.A(p4), .B(new_n31_), .Y(new_n159_));
  OAI21x1_ASAP7_75t_R  g138(.A1(new_n157_), .A2(new_n159_), .B(new_n45_), .Y(new_n160_));
  AND2x2_ASAP7_75t_R   g139(.A(p7), .B(p1), .Y(new_n161_));
  NAND2x1_ASAP7_75t_R  g140(.A(new_n109_), .B(new_n161_), .Y(new_n162_));
  OA31x2_ASAP7_75t_R   g141(.A1(new_n33_), .A2(new_n158_), .A3(new_n160_), .B1(new_n162_), .Y(new_n163_));
  AND2x2_ASAP7_75t_R   g142(.A(p8), .B(p4), .Y(new_n164_));
  NAND3x1_ASAP7_75t_R  g143(.A(new_n164_), .B(new_n38_), .C(new_n100_), .Y(new_n165_));
  INVx1_ASAP7_75t_R    g144(.A(new_n53_), .Y(new_n166_));
  NAND2x1_ASAP7_75t_R  g145(.A(p5), .B(p7), .Y(new_n167_));
  AND3x1_ASAP7_75t_R   g146(.A(new_n167_), .B(p9), .C(new_n36_), .Y(new_n168_));
  OAI21x1_ASAP7_75t_R  g147(.A1(new_n166_), .A2(new_n159_), .B(new_n168_), .Y(new_n169_));
  AO21x1_ASAP7_75t_R   g148(.A1(new_n165_), .A2(new_n169_), .B(new_n33_), .Y(new_n170_));
  AOI21x1_ASAP7_75t_R  g149(.A1(new_n163_), .A2(new_n170_), .B(p2), .Y(new_n171_));
  AOI211x1_ASAP7_75t_R g150(.A1(new_n123_), .A2(new_n144_), .B(new_n156_), .C(new_n171_), .Y(new_n172_));
  NAND2x1_ASAP7_75t_R  g151(.A(new_n138_), .B(new_n63_), .Y(new_n173_));
  OA21x2_ASAP7_75t_R   g152(.A1(new_n100_), .A2(new_n145_), .B(new_n80_), .Y(new_n174_));
  AND3x1_ASAP7_75t_R   g153(.A(new_n173_), .B(new_n174_), .C(p6), .Y(new_n175_));
  NOR2x1_ASAP7_75t_R   g154(.A(p8), .B(new_n33_), .Y(new_n176_));
  NOR2x1_ASAP7_75t_R   g155(.A(p1), .B(new_n31_), .Y(new_n177_));
  AND3x1_ASAP7_75t_R   g156(.A(new_n176_), .B(new_n177_), .C(p6), .Y(new_n178_));
  OR3x1_ASAP7_75t_R    g157(.A(new_n175_), .B(new_n86_), .C(new_n178_), .Y(new_n179_));
  INVx1_ASAP7_75t_R    g158(.A(p3), .Y(new_n180_));
  AND3x1_ASAP7_75t_R   g159(.A(new_n96_), .B(new_n180_), .C(new_n26_), .Y(new_n181_));
  AO21x1_ASAP7_75t_R   g160(.A1(p3), .A2(p7), .B(new_n108_), .Y(new_n182_));
  AND3x1_ASAP7_75t_R   g161(.A(p3), .B(p8), .C(p5), .Y(new_n183_));
  AO21x1_ASAP7_75t_R   g162(.A1(new_n109_), .A2(new_n182_), .B(new_n183_), .Y(new_n184_));
  AOI22x1_ASAP7_75t_R  g163(.A1(new_n179_), .A2(new_n181_), .B1(new_n114_), .B2(new_n184_), .Y(new_n185_));
  OAI21x1_ASAP7_75t_R  g164(.A1(new_n23_), .A2(new_n172_), .B(new_n185_), .Y(o1));
  NAND2x1_ASAP7_75t_R  g165(.A(p8), .B(p7), .Y(new_n187_));
  OA21x2_ASAP7_75t_R   g166(.A1(p8), .A2(p7), .B(p1), .Y(new_n188_));
  AO21x1_ASAP7_75t_R   g167(.A1(new_n187_), .A2(new_n188_), .B(new_n100_), .Y(new_n189_));
  AND3x1_ASAP7_75t_R   g168(.A(p8), .B(p1), .C(p0), .Y(new_n190_));
  NOR2x1_ASAP7_75t_R   g169(.A(p0), .B(new_n31_), .Y(new_n191_));
  OAI21x1_ASAP7_75t_R  g170(.A1(new_n190_), .A2(new_n191_), .B(p5), .Y(new_n192_));
  AO21x1_ASAP7_75t_R   g171(.A1(new_n189_), .A2(new_n192_), .B(new_n41_), .Y(new_n193_));
  INVx1_ASAP7_75t_R    g172(.A(new_n49_), .Y(new_n194_));
  NOR2x1_ASAP7_75t_R   g173(.A(new_n194_), .B(new_n99_), .Y(new_n195_));
  OR3x1_ASAP7_75t_R    g174(.A(new_n31_), .B(new_n33_), .C(p8), .Y(new_n196_));
  OAI21x1_ASAP7_75t_R  g175(.A1(new_n73_), .A2(new_n167_), .B(new_n196_), .Y(new_n197_));
  OAI21x1_ASAP7_75t_R  g176(.A1(new_n195_), .A2(new_n197_), .B(new_n36_), .Y(new_n198_));
  OR3x1_ASAP7_75t_R    g177(.A(new_n38_), .B(p3), .C(p4), .Y(new_n199_));
  AOI21x1_ASAP7_75t_R  g178(.A1(new_n193_), .A2(new_n198_), .B(new_n199_), .Y(new_n200_));
  NAND2x1_ASAP7_75t_R  g179(.A(p9), .B(p7), .Y(new_n201_));
  INVx1_ASAP7_75t_R    g180(.A(new_n201_), .Y(new_n202_));
  AND3x1_ASAP7_75t_R   g181(.A(new_n75_), .B(new_n202_), .C(new_n73_), .Y(new_n203_));
  NOR2x1_ASAP7_75t_R   g182(.A(p0), .B(new_n41_), .Y(new_n204_));
  OA211x2_ASAP7_75t_R  g183(.A1(new_n24_), .A2(new_n204_), .B(new_n39_), .C(new_n100_), .Y(new_n205_));
  NOR2x1_ASAP7_75t_R   g184(.A(new_n203_), .B(new_n205_), .Y(new_n206_));
  NOR2x1_ASAP7_75t_R   g185(.A(p8), .B(p7), .Y(new_n207_));
  INVx1_ASAP7_75t_R    g186(.A(new_n207_), .Y(new_n208_));
  OA211x2_ASAP7_75t_R  g187(.A1(new_n33_), .A2(new_n208_), .B(p1), .C(new_n187_), .Y(new_n209_));
  AND3x1_ASAP7_75t_R   g188(.A(p8), .B(p9), .C(p7), .Y(new_n210_));
  NOR2x1_ASAP7_75t_R   g189(.A(new_n207_), .B(new_n210_), .Y(new_n211_));
  AO21x1_ASAP7_75t_R   g190(.A1(new_n24_), .A2(new_n147_), .B(new_n33_), .Y(new_n212_));
  AOI21x1_ASAP7_75t_R  g191(.A1(p4), .A2(new_n211_), .B(new_n212_), .Y(new_n213_));
  OAI21x1_ASAP7_75t_R  g192(.A1(new_n209_), .A2(new_n213_), .B(new_n41_), .Y(new_n214_));
  INVx1_ASAP7_75t_R    g193(.A(new_n72_), .Y(new_n215_));
  AOI21x1_ASAP7_75t_R  g194(.A1(new_n206_), .A2(new_n214_), .B(new_n215_), .Y(new_n216_));
  OAI21x1_ASAP7_75t_R  g195(.A1(new_n200_), .A2(new_n216_), .B(new_n89_), .Y(new_n217_));
  NOR2x1_ASAP7_75t_R   g196(.A(p7), .B(new_n41_), .Y(new_n218_));
  NOR2x1_ASAP7_75t_R   g197(.A(p1), .B(new_n41_), .Y(new_n219_));
  AO21x1_ASAP7_75t_R   g198(.A1(new_n73_), .A2(new_n218_), .B(new_n219_), .Y(new_n220_));
  INVx1_ASAP7_75t_R    g199(.A(new_n196_), .Y(new_n221_));
  NOR2x1_ASAP7_75t_R   g200(.A(new_n109_), .B(new_n221_), .Y(new_n222_));
  NOR2x1_ASAP7_75t_R   g201(.A(p7), .B(new_n26_), .Y(new_n223_));
  NAND2x1_ASAP7_75t_R  g202(.A(p8), .B(p0), .Y(new_n224_));
  NOR2x1_ASAP7_75t_R   g203(.A(p2), .B(new_n224_), .Y(new_n225_));
  AO21x1_ASAP7_75t_R   g204(.A1(new_n223_), .A2(new_n225_), .B(p3), .Y(new_n226_));
  AOI21x1_ASAP7_75t_R  g205(.A1(new_n220_), .A2(new_n222_), .B(new_n226_), .Y(new_n227_));
  OAI21x1_ASAP7_75t_R  g206(.A1(new_n31_), .A2(new_n219_), .B(new_n24_), .Y(new_n228_));
  NAND2x1_ASAP7_75t_R  g207(.A(p2), .B(p4), .Y(new_n229_));
  OA21x2_ASAP7_75t_R   g208(.A1(new_n229_), .A2(new_n177_), .B(new_n176_), .Y(new_n230_));
  OR3x1_ASAP7_75t_R    g209(.A(new_n31_), .B(new_n33_), .C(p5), .Y(new_n231_));
  OA21x2_ASAP7_75t_R   g210(.A1(p1), .A2(new_n33_), .B(p4), .Y(new_n232_));
  AND3x1_ASAP7_75t_R   g211(.A(new_n231_), .B(new_n232_), .C(new_n141_), .Y(new_n233_));
  NOR2x1_ASAP7_75t_R   g212(.A(p4), .B(new_n26_), .Y(new_n234_));
  NAND2x1_ASAP7_75t_R  g213(.A(new_n207_), .B(new_n234_), .Y(new_n235_));
  AOI22x1_ASAP7_75t_R  g214(.A1(new_n45_), .A2(p0), .B1(new_n31_), .B2(p2), .Y(new_n236_));
  AO21x1_ASAP7_75t_R   g215(.A1(p2), .A2(new_n45_), .B(p5), .Y(new_n237_));
  OAI22x1_ASAP7_75t_R  g216(.A1(new_n235_), .A2(new_n155_), .B1(new_n236_), .B2(new_n237_), .Y(new_n238_));
  AOI211x1_ASAP7_75t_R g217(.A1(new_n228_), .A2(new_n230_), .B(new_n233_), .C(new_n238_), .Y(new_n239_));
  AND2x2_ASAP7_75t_R   g218(.A(p8), .B(p7), .Y(new_n240_));
  OA211x2_ASAP7_75t_R  g219(.A1(new_n240_), .A2(new_n223_), .B(p3), .C(new_n24_), .Y(new_n241_));
  OA21x2_ASAP7_75t_R   g220(.A1(p0), .A2(new_n75_), .B(p3), .Y(new_n242_));
  OR3x1_ASAP7_75t_R    g221(.A(new_n241_), .B(p9), .C(new_n242_), .Y(new_n243_));
  AO211x2_ASAP7_75t_R  g222(.A1(new_n227_), .A2(new_n239_), .B(p6), .C(new_n243_), .Y(new_n244_));
  OA21x2_ASAP7_75t_R   g223(.A1(new_n89_), .A2(new_n187_), .B(p9), .Y(new_n245_));
  OR3x1_ASAP7_75t_R    g224(.A(new_n63_), .B(p7), .C(p0), .Y(new_n246_));
  OA21x2_ASAP7_75t_R   g225(.A1(new_n57_), .A2(new_n245_), .B(new_n246_), .Y(new_n247_));
  NOR2x1_ASAP7_75t_R   g226(.A(p5), .B(p4), .Y(new_n248_));
  INVx1_ASAP7_75t_R    g227(.A(new_n248_), .Y(new_n249_));
  OR4x2_ASAP7_75t_R    g228(.A(new_n247_), .B(p3), .C(new_n75_), .D(new_n249_), .Y(new_n250_));
  NAND3x1_ASAP7_75t_R  g229(.A(new_n217_), .B(new_n244_), .C(new_n250_), .Y(o2));
  OR3x1_ASAP7_75t_R    g230(.A(new_n31_), .B(new_n36_), .C(p4), .Y(new_n252_));
  NAND2x1_ASAP7_75t_R  g231(.A(p7), .B(p4), .Y(new_n253_));
  NAND2x1_ASAP7_75t_R  g232(.A(p1), .B(new_n41_), .Y(new_n254_));
  AO21x1_ASAP7_75t_R   g233(.A1(new_n253_), .A2(new_n254_), .B(new_n161_), .Y(new_n255_));
  AO21x1_ASAP7_75t_R   g234(.A1(new_n252_), .A2(new_n255_), .B(new_n92_), .Y(new_n256_));
  AO21x1_ASAP7_75t_R   g235(.A1(new_n100_), .A2(new_n164_), .B(new_n219_), .Y(new_n257_));
  NAND2x1_ASAP7_75t_R  g236(.A(p2), .B(new_n24_), .Y(new_n258_));
  OA21x2_ASAP7_75t_R   g237(.A1(p5), .A2(new_n218_), .B(new_n258_), .Y(new_n259_));
  OAI21x1_ASAP7_75t_R  g238(.A1(new_n257_), .A2(new_n259_), .B(p0), .Y(new_n260_));
  AND3x1_ASAP7_75t_R   g239(.A(new_n29_), .B(p4), .C(new_n36_), .Y(new_n261_));
  AND3x1_ASAP7_75t_R   g240(.A(new_n96_), .B(new_n45_), .C(p5), .Y(new_n262_));
  AOI21x1_ASAP7_75t_R  g241(.A1(new_n157_), .A2(new_n261_), .B(new_n262_), .Y(new_n263_));
  NAND3x1_ASAP7_75t_R  g242(.A(new_n256_), .B(new_n260_), .C(new_n263_), .Y(new_n264_));
  OAI21x1_ASAP7_75t_R  g243(.A1(p7), .A2(new_n27_), .B(new_n235_), .Y(new_n265_));
  NOR2x1_ASAP7_75t_R   g244(.A(p5), .B(new_n28_), .Y(new_n266_));
  AO21x1_ASAP7_75t_R   g245(.A1(new_n75_), .A2(new_n234_), .B(new_n266_), .Y(new_n267_));
  AOI22x1_ASAP7_75t_R  g246(.A1(new_n265_), .A2(new_n33_), .B1(new_n73_), .B2(new_n267_), .Y(new_n268_));
  OR3x1_ASAP7_75t_R    g247(.A(new_n196_), .B(new_n26_), .C(p4), .Y(new_n269_));
  OAI21x1_ASAP7_75t_R  g248(.A1(new_n90_), .A2(new_n157_), .B(new_n36_), .Y(new_n270_));
  AO21x1_ASAP7_75t_R   g249(.A1(p8), .A2(p4), .B(p5), .Y(new_n271_));
  AO21x1_ASAP7_75t_R   g250(.A1(new_n224_), .A2(new_n253_), .B(new_n271_), .Y(new_n272_));
  AO21x1_ASAP7_75t_R   g251(.A1(new_n270_), .A2(new_n272_), .B(new_n41_), .Y(new_n273_));
  NAND3x1_ASAP7_75t_R  g252(.A(new_n268_), .B(new_n269_), .C(new_n273_), .Y(new_n274_));
  AOI21x1_ASAP7_75t_R  g253(.A1(p9), .A2(new_n264_), .B(new_n274_), .Y(new_n275_));
  INVx1_ASAP7_75t_R    g254(.A(new_n253_), .Y(new_n276_));
  NOR2x1_ASAP7_75t_R   g255(.A(p5), .B(new_n45_), .Y(new_n277_));
  AND3x1_ASAP7_75t_R   g256(.A(new_n276_), .B(new_n277_), .C(p1), .Y(new_n278_));
  AO21x1_ASAP7_75t_R   g257(.A1(p5), .A2(new_n31_), .B(p2), .Y(new_n279_));
  AO21x1_ASAP7_75t_R   g258(.A1(p7), .A2(new_n26_), .B(new_n24_), .Y(new_n280_));
  AO22x1_ASAP7_75t_R   g259(.A1(new_n279_), .A2(new_n280_), .B1(p1), .B2(new_n152_), .Y(new_n281_));
  OA211x2_ASAP7_75t_R  g260(.A1(new_n278_), .A2(new_n281_), .B(new_n180_), .C(p0), .Y(new_n282_));
  NOR2x1_ASAP7_75t_R   g261(.A(p0), .B(new_n74_), .Y(new_n283_));
  AO22x1_ASAP7_75t_R   g262(.A1(p1), .A2(new_n234_), .B1(new_n283_), .B2(new_n237_), .Y(new_n284_));
  AND3x1_ASAP7_75t_R   g263(.A(new_n112_), .B(p3), .C(new_n41_), .Y(new_n285_));
  AO21x1_ASAP7_75t_R   g264(.A1(p8), .A2(p7), .B(p4), .Y(new_n286_));
  OA211x2_ASAP7_75t_R  g265(.A1(new_n65_), .A2(new_n248_), .B(new_n285_), .C(new_n286_), .Y(new_n287_));
  AO21x1_ASAP7_75t_R   g266(.A1(new_n180_), .A2(new_n284_), .B(new_n287_), .Y(new_n288_));
  OAI21x1_ASAP7_75t_R  g267(.A1(new_n282_), .A2(new_n288_), .B(new_n113_), .Y(new_n289_));
  OAI21x1_ASAP7_75t_R  g268(.A1(new_n23_), .A2(new_n275_), .B(new_n289_), .Y(o3));
  OA211x2_ASAP7_75t_R  g269(.A1(p9), .A2(p0), .B(new_n180_), .C(p1), .Y(new_n291_));
  NOR2x1_ASAP7_75t_R   g270(.A(p2), .B(new_n180_), .Y(new_n292_));
  NOR2x1_ASAP7_75t_R   g271(.A(p3), .B(new_n41_), .Y(new_n293_));
  OA211x2_ASAP7_75t_R  g272(.A1(new_n292_), .A2(new_n293_), .B(new_n36_), .C(new_n50_), .Y(new_n294_));
  NOR2x1_ASAP7_75t_R   g273(.A(p6), .B(new_n55_), .Y(new_n295_));
  OA21x2_ASAP7_75t_R   g274(.A1(new_n291_), .A2(new_n294_), .B(new_n295_), .Y(o4));
  AND3x1_ASAP7_75t_R   g275(.A(new_n50_), .B(new_n74_), .C(p3), .Y(new_n297_));
  AO21x1_ASAP7_75t_R   g276(.A1(new_n54_), .A2(new_n293_), .B(new_n297_), .Y(new_n298_));
  AND2x2_ASAP7_75t_R   g277(.A(new_n295_), .B(new_n298_), .Y(o5));
  AO21x1_ASAP7_75t_R   g278(.A1(new_n45_), .A2(new_n31_), .B(p0), .Y(new_n300_));
  NAND2x1_ASAP7_75t_R  g279(.A(p9), .B(new_n300_), .Y(new_n301_));
  INVx1_ASAP7_75t_R    g280(.A(new_n99_), .Y(new_n302_));
  NOR2x1_ASAP7_75t_R   g281(.A(p8), .B(new_n36_), .Y(new_n303_));
  AOI21x1_ASAP7_75t_R  g282(.A1(new_n140_), .A2(new_n125_), .B(new_n303_), .Y(new_n304_));
  OAI22x1_ASAP7_75t_R  g283(.A1(new_n301_), .A2(new_n176_), .B1(new_n302_), .B2(new_n304_), .Y(new_n305_));
  NOR2x1_ASAP7_75t_R   g284(.A(p9), .B(new_n36_), .Y(new_n306_));
  OR4x2_ASAP7_75t_R    g285(.A(new_n306_), .B(new_n45_), .C(p7), .D(new_n33_), .Y(new_n307_));
  NOR2x1_ASAP7_75t_R   g286(.A(p1), .B(new_n201_), .Y(new_n308_));
  AOI21x1_ASAP7_75t_R  g287(.A1(new_n166_), .A2(new_n308_), .B(new_n41_), .Y(new_n309_));
  NOR2x1_ASAP7_75t_R   g288(.A(p4), .B(new_n38_), .Y(new_n310_));
  OR3x1_ASAP7_75t_R    g289(.A(new_n310_), .B(new_n92_), .C(new_n145_), .Y(new_n311_));
  NAND3x1_ASAP7_75t_R  g290(.A(new_n307_), .B(new_n309_), .C(new_n311_), .Y(new_n312_));
  AOI21x1_ASAP7_75t_R  g291(.A1(new_n24_), .A2(new_n305_), .B(new_n312_), .Y(new_n313_));
  INVx1_ASAP7_75t_R    g292(.A(new_n286_), .Y(new_n314_));
  OR4x2_ASAP7_75t_R    g293(.A(new_n314_), .B(p9), .C(new_n36_), .D(new_n207_), .Y(new_n315_));
  NOR2x1_ASAP7_75t_R   g294(.A(new_n207_), .B(new_n240_), .Y(new_n316_));
  NOR2x1_ASAP7_75t_R   g295(.A(new_n100_), .B(new_n161_), .Y(new_n317_));
  OR3x1_ASAP7_75t_R    g296(.A(new_n316_), .B(new_n317_), .C(new_n26_), .Y(new_n318_));
  AOI21x1_ASAP7_75t_R  g297(.A1(new_n29_), .A2(new_n108_), .B(p2), .Y(new_n319_));
  AND3x1_ASAP7_75t_R   g298(.A(new_n58_), .B(new_n109_), .C(new_n80_), .Y(new_n320_));
  AND2x2_ASAP7_75t_R   g299(.A(p4), .B(p0), .Y(new_n321_));
  AOI22x1_ASAP7_75t_R  g300(.A1(new_n320_), .A2(new_n202_), .B1(new_n321_), .B2(new_n210_), .Y(new_n322_));
  AND4x2_ASAP7_75t_R   g301(.A(new_n315_), .B(new_n318_), .C(new_n319_), .D(new_n322_), .Y(new_n323_));
  AND3x1_ASAP7_75t_R   g302(.A(new_n25_), .B(new_n38_), .C(p7), .Y(new_n324_));
  AO21x1_ASAP7_75t_R   g303(.A1(p5), .A2(new_n31_), .B(p9), .Y(new_n325_));
  AND3x1_ASAP7_75t_R   g304(.A(new_n325_), .B(new_n51_), .C(new_n253_), .Y(new_n326_));
  OA21x2_ASAP7_75t_R   g305(.A1(new_n324_), .A2(new_n326_), .B(new_n33_), .Y(new_n327_));
  MAJx2_ASAP7_75t_R    g306(.A(new_n64_), .B(p8), .C(new_n38_), .Y(new_n328_));
  NOR2x1_ASAP7_75t_R   g307(.A(p4), .B(new_n36_), .Y(new_n329_));
  OR3x1_ASAP7_75t_R    g308(.A(new_n45_), .B(p5), .C(p9), .Y(new_n330_));
  OA21x2_ASAP7_75t_R   g309(.A1(new_n329_), .A2(new_n330_), .B(new_n34_), .Y(new_n331_));
  OA211x2_ASAP7_75t_R  g310(.A1(new_n210_), .A2(new_n188_), .B(p5), .C(p0), .Y(new_n332_));
  AO21x1_ASAP7_75t_R   g311(.A1(new_n328_), .A2(new_n331_), .B(new_n332_), .Y(new_n333_));
  NOR2x1_ASAP7_75t_R   g312(.A(new_n327_), .B(new_n333_), .Y(new_n334_));
  OAI21x1_ASAP7_75t_R  g313(.A1(new_n313_), .A2(new_n323_), .B(new_n334_), .Y(new_n335_));
  INVx1_ASAP7_75t_R    g314(.A(new_n211_), .Y(new_n336_));
  AND3x1_ASAP7_75t_R   g315(.A(new_n300_), .B(p6), .C(new_n36_), .Y(new_n337_));
  AO21x1_ASAP7_75t_R   g316(.A1(p6), .A2(new_n45_), .B(new_n31_), .Y(new_n338_));
  AO22x1_ASAP7_75t_R   g317(.A1(p0), .A2(new_n51_), .B1(new_n37_), .B2(new_n338_), .Y(new_n339_));
  AO22x1_ASAP7_75t_R   g318(.A1(new_n336_), .A2(new_n337_), .B1(new_n38_), .B2(new_n339_), .Y(new_n340_));
  AO21x1_ASAP7_75t_R   g319(.A1(new_n113_), .A2(new_n285_), .B(new_n295_), .Y(new_n341_));
  AO21x1_ASAP7_75t_R   g320(.A1(new_n181_), .A2(new_n340_), .B(new_n341_), .Y(new_n342_));
  AOI21x1_ASAP7_75t_R  g321(.A1(new_n22_), .A2(new_n335_), .B(new_n342_), .Y(o6));
  NAND2x1_ASAP7_75t_R  g322(.A(new_n43_), .B(new_n248_), .Y(new_n344_));
  NOR2x1_ASAP7_75t_R   g323(.A(p8), .B(new_n89_), .Y(new_n345_));
  AOI22x1_ASAP7_75t_R  g324(.A1(new_n316_), .A2(new_n306_), .B1(new_n308_), .B2(new_n345_), .Y(new_n346_));
  NOR2x1_ASAP7_75t_R   g325(.A(new_n344_), .B(new_n346_), .Y(new_n347_));
  OA21x2_ASAP7_75t_R   g326(.A1(new_n89_), .A2(new_n347_), .B(new_n180_), .Y(new_n348_));
  INVx1_ASAP7_75t_R    g327(.A(new_n135_), .Y(new_n349_));
  OR3x1_ASAP7_75t_R    g328(.A(new_n100_), .B(new_n207_), .C(p2), .Y(new_n350_));
  OA21x2_ASAP7_75t_R   g329(.A1(p8), .A2(p1), .B(p9), .Y(new_n351_));
  NOR3x1_ASAP7_75t_R   g330(.A(new_n24_), .B(p8), .C(p9), .Y(new_n352_));
  AOI211x1_ASAP7_75t_R g331(.A1(new_n147_), .A2(new_n351_), .B(new_n108_), .C(new_n352_), .Y(new_n353_));
  NOR3x1_ASAP7_75t_R   g332(.A(new_n229_), .B(p7), .C(p1), .Y(new_n354_));
  OAI22x1_ASAP7_75t_R  g333(.A1(p8), .A2(p1), .B1(p9), .B2(p7), .Y(new_n355_));
  AND2x2_ASAP7_75t_R   g334(.A(p2), .B(p4), .Y(new_n356_));
  OAI22x1_ASAP7_75t_R  g335(.A1(new_n354_), .A2(new_n355_), .B1(new_n303_), .B2(new_n356_), .Y(new_n357_));
  OAI21x1_ASAP7_75t_R  g336(.A1(new_n350_), .A2(new_n353_), .B(new_n357_), .Y(new_n358_));
  AND3x1_ASAP7_75t_R   g337(.A(new_n45_), .B(new_n31_), .C(p1), .Y(new_n359_));
  AND3x1_ASAP7_75t_R   g338(.A(p8), .B(p2), .C(p1), .Y(new_n360_));
  AOI22x1_ASAP7_75t_R  g339(.A1(new_n359_), .A2(new_n78_), .B1(new_n276_), .B2(new_n360_), .Y(new_n361_));
  AOI22x1_ASAP7_75t_R  g340(.A1(p8), .A2(p7), .B1(p2), .B2(p1), .Y(new_n362_));
  OAI21x1_ASAP7_75t_R  g341(.A1(p8), .A2(p7), .B(new_n362_), .Y(new_n363_));
  AOI21x1_ASAP7_75t_R  g342(.A1(new_n36_), .A2(new_n77_), .B(new_n24_), .Y(new_n364_));
  NAND3x1_ASAP7_75t_R  g343(.A(new_n363_), .B(new_n364_), .C(new_n33_), .Y(new_n365_));
  AOI21x1_ASAP7_75t_R  g344(.A1(new_n361_), .A2(new_n365_), .B(p5), .Y(new_n366_));
  AOI211x1_ASAP7_75t_R g345(.A1(new_n349_), .A2(new_n358_), .B(new_n366_), .C(new_n347_), .Y(new_n367_));
  NAND2x1_ASAP7_75t_R  g346(.A(p1), .B(new_n26_), .Y(new_n368_));
  OA21x2_ASAP7_75t_R   g347(.A1(new_n41_), .A2(new_n240_), .B(new_n201_), .Y(new_n369_));
  INVx1_ASAP7_75t_R    g348(.A(new_n254_), .Y(new_n370_));
  AOI22x1_ASAP7_75t_R  g349(.A1(new_n370_), .A2(new_n240_), .B1(new_n49_), .B2(new_n109_), .Y(new_n371_));
  OAI21x1_ASAP7_75t_R  g350(.A1(new_n368_), .A2(new_n369_), .B(new_n371_), .Y(new_n372_));
  AO21x1_ASAP7_75t_R   g351(.A1(p5), .A2(new_n45_), .B(p9), .Y(new_n373_));
  AO21x1_ASAP7_75t_R   g352(.A1(p8), .A2(p5), .B(p7), .Y(new_n374_));
  NAND3x1_ASAP7_75t_R  g353(.A(new_n373_), .B(new_n27_), .C(new_n374_), .Y(new_n375_));
  AND4x2_ASAP7_75t_R   g354(.A(new_n26_), .B(new_n38_), .C(p7), .D(p2), .Y(new_n376_));
  OAI21x1_ASAP7_75t_R  g355(.A1(new_n223_), .A2(new_n376_), .B(p8), .Y(new_n377_));
  AOI21x1_ASAP7_75t_R  g356(.A1(new_n375_), .A2(new_n377_), .B(p1), .Y(new_n378_));
  NOR2x1_ASAP7_75t_R   g357(.A(p4), .B(new_n33_), .Y(new_n379_));
  OAI21x1_ASAP7_75t_R  g358(.A1(new_n372_), .A2(new_n378_), .B(new_n379_), .Y(new_n380_));
  AO21x1_ASAP7_75t_R   g359(.A1(p8), .A2(p7), .B(p5), .Y(new_n381_));
  NOR3x1_ASAP7_75t_R   g360(.A(new_n39_), .B(p1), .C(new_n381_), .Y(new_n382_));
  NAND2x1_ASAP7_75t_R  g361(.A(p5), .B(new_n38_), .Y(new_n383_));
  AOI21x1_ASAP7_75t_R  g362(.A1(new_n187_), .A2(new_n208_), .B(new_n383_), .Y(new_n384_));
  OAI21x1_ASAP7_75t_R  g363(.A1(new_n382_), .A2(new_n384_), .B(new_n204_), .Y(new_n385_));
  OAI21x1_ASAP7_75t_R  g364(.A1(p5), .A2(new_n49_), .B(new_n188_), .Y(new_n386_));
  OR3x1_ASAP7_75t_R    g365(.A(new_n201_), .B(p8), .C(new_n26_), .Y(new_n387_));
  AO31x2_ASAP7_75t_R   g366(.A1(new_n386_), .A2(new_n387_), .A3(new_n146_), .B(p0), .Y(new_n388_));
  OR4x2_ASAP7_75t_R    g367(.A(new_n101_), .B(p8), .C(new_n26_), .D(new_n41_), .Y(new_n389_));
  AO31x2_ASAP7_75t_R   g368(.A1(new_n385_), .A2(new_n388_), .A3(new_n389_), .B(p4), .Y(new_n390_));
  NAND3x1_ASAP7_75t_R  g369(.A(new_n367_), .B(new_n380_), .C(new_n390_), .Y(new_n391_));
  AND3x1_ASAP7_75t_R   g370(.A(new_n297_), .B(new_n89_), .C(new_n248_), .Y(new_n392_));
  AOI21x1_ASAP7_75t_R  g371(.A1(new_n348_), .A2(new_n391_), .B(new_n392_), .Y(o7));
  AO21x1_ASAP7_75t_R   g372(.A1(new_n24_), .A2(p1), .B(new_n356_), .Y(new_n394_));
  OA211x2_ASAP7_75t_R  g373(.A1(p7), .A2(new_n41_), .B(new_n28_), .C(p0), .Y(new_n395_));
  OA21x2_ASAP7_75t_R   g374(.A1(p9), .A2(new_n24_), .B(new_n204_), .Y(new_n396_));
  AO22x1_ASAP7_75t_R   g375(.A1(new_n394_), .A2(new_n395_), .B1(new_n177_), .B2(new_n396_), .Y(new_n397_));
  AO21x1_ASAP7_75t_R   g376(.A1(p2), .A2(new_n24_), .B(new_n321_), .Y(new_n398_));
  OAI21x1_ASAP7_75t_R  g377(.A1(p9), .A2(p2), .B(new_n177_), .Y(new_n399_));
  AND3x1_ASAP7_75t_R   g378(.A(new_n229_), .B(p1), .C(p0), .Y(new_n400_));
  AND3x1_ASAP7_75t_R   g379(.A(new_n41_), .B(new_n24_), .C(p9), .Y(new_n401_));
  AOI22x1_ASAP7_75t_R  g380(.A1(new_n400_), .A2(new_n137_), .B1(new_n191_), .B2(new_n401_), .Y(new_n402_));
  OAI21x1_ASAP7_75t_R  g381(.A1(new_n398_), .A2(new_n399_), .B(new_n402_), .Y(new_n403_));
  AOI22x1_ASAP7_75t_R  g382(.A1(new_n397_), .A2(new_n277_), .B1(new_n403_), .B2(new_n109_), .Y(new_n404_));
  AO21x1_ASAP7_75t_R   g383(.A1(p8), .A2(new_n41_), .B(p1), .Y(new_n405_));
  OR3x1_ASAP7_75t_R    g384(.A(new_n398_), .B(new_n29_), .C(new_n405_), .Y(new_n406_));
  OAI21x1_ASAP7_75t_R  g385(.A1(new_n225_), .A2(new_n261_), .B(new_n38_), .Y(new_n407_));
  AOI22x1_ASAP7_75t_R  g386(.A1(new_n302_), .A2(new_n370_), .B1(new_n43_), .B2(new_n329_), .Y(new_n408_));
  INVx1_ASAP7_75t_R    g387(.A(new_n157_), .Y(new_n409_));
  AO31x2_ASAP7_75t_R   g388(.A1(new_n406_), .A2(new_n407_), .A3(new_n408_), .B(new_n409_), .Y(new_n410_));
  NOR2x1_ASAP7_75t_R   g389(.A(p9), .B(new_n31_), .Y(new_n411_));
  AO21x1_ASAP7_75t_R   g390(.A1(new_n92_), .A2(new_n411_), .B(new_n26_), .Y(new_n412_));
  NOR2x1_ASAP7_75t_R   g391(.A(new_n73_), .B(new_n412_), .Y(new_n413_));
  NOR2x1_ASAP7_75t_R   g392(.A(p5), .B(new_n34_), .Y(new_n414_));
  AOI21x1_ASAP7_75t_R  g393(.A1(new_n414_), .A2(new_n301_), .B(new_n258_), .Y(new_n415_));
  OAI21x1_ASAP7_75t_R  g394(.A1(p1), .A2(new_n413_), .B(new_n415_), .Y(new_n416_));
  NAND3x1_ASAP7_75t_R  g395(.A(new_n404_), .B(new_n410_), .C(new_n416_), .Y(new_n417_));
  INVx1_ASAP7_75t_R    g396(.A(new_n181_), .Y(new_n418_));
  OR3x1_ASAP7_75t_R    g397(.A(p9), .B(p7), .C(p1), .Y(new_n419_));
  NOR2x1_ASAP7_75t_R   g398(.A(new_n224_), .B(new_n419_), .Y(new_n420_));
  OA211x2_ASAP7_75t_R  g399(.A1(new_n100_), .A2(new_n161_), .B(new_n45_), .C(new_n38_), .Y(new_n421_));
  OA21x2_ASAP7_75t_R   g400(.A1(new_n25_), .A2(new_n202_), .B(new_n355_), .Y(new_n422_));
  OA21x2_ASAP7_75t_R   g401(.A1(new_n421_), .A2(new_n422_), .B(new_n33_), .Y(new_n423_));
  NOR2x1_ASAP7_75t_R   g402(.A(new_n420_), .B(new_n423_), .Y(new_n424_));
  NAND3x1_ASAP7_75t_R  g403(.A(new_n114_), .B(p3), .C(new_n24_), .Y(new_n425_));
  OAI21x1_ASAP7_75t_R  g404(.A1(new_n418_), .A2(new_n424_), .B(new_n425_), .Y(new_n426_));
  AOI21x1_ASAP7_75t_R  g405(.A1(new_n22_), .A2(new_n417_), .B(new_n426_), .Y(o8));
  AO21x1_ASAP7_75t_R   g406(.A1(new_n310_), .A2(new_n266_), .B(p6), .Y(new_n428_));
  OA211x2_ASAP7_75t_R  g407(.A1(p4), .A2(p1), .B(new_n258_), .C(p5), .Y(new_n429_));
  AND3x1_ASAP7_75t_R   g408(.A(new_n43_), .B(p9), .C(new_n36_), .Y(new_n430_));
  OA21x2_ASAP7_75t_R   g409(.A1(p9), .A2(new_n254_), .B(p6), .Y(new_n431_));
  OR4x2_ASAP7_75t_R    g410(.A(new_n429_), .B(new_n242_), .C(new_n430_), .D(new_n431_), .Y(new_n432_));
  AOI21x1_ASAP7_75t_R  g411(.A1(new_n300_), .A2(new_n428_), .B(new_n432_), .Y(new_n433_));
  AND3x1_ASAP7_75t_R   g412(.A(new_n188_), .B(new_n41_), .C(new_n286_), .Y(new_n434_));
  INVx1_ASAP7_75t_R    g413(.A(new_n292_), .Y(new_n435_));
  NAND2x1_ASAP7_75t_R  g414(.A(p2), .B(new_n53_), .Y(new_n436_));
  AO21x1_ASAP7_75t_R   g415(.A1(new_n411_), .A2(new_n271_), .B(new_n436_), .Y(new_n437_));
  OA211x2_ASAP7_75t_R  g416(.A1(new_n248_), .A2(new_n435_), .B(new_n437_), .C(new_n36_), .Y(new_n438_));
  OAI21x1_ASAP7_75t_R  g417(.A1(new_n434_), .A2(new_n438_), .B(new_n33_), .Y(new_n439_));
  AND3x1_ASAP7_75t_R   g418(.A(new_n249_), .B(new_n41_), .C(new_n381_), .Y(new_n440_));
  AOI21x1_ASAP7_75t_R  g419(.A1(new_n314_), .A2(new_n266_), .B(new_n440_), .Y(new_n441_));
  NOR2x1_ASAP7_75t_R   g420(.A(p2), .B(new_n90_), .Y(new_n442_));
  OA21x2_ASAP7_75t_R   g421(.A1(new_n411_), .A2(new_n442_), .B(new_n36_), .Y(new_n443_));
  NAND2x1_ASAP7_75t_R  g422(.A(new_n436_), .B(new_n443_), .Y(new_n444_));
  AO21x1_ASAP7_75t_R   g423(.A1(new_n441_), .A2(new_n444_), .B(new_n33_), .Y(new_n445_));
  AND3x1_ASAP7_75t_R   g424(.A(new_n433_), .B(new_n439_), .C(new_n445_), .Y(o9));
  OR4x2_ASAP7_75t_R    g425(.A(new_n73_), .B(p3), .C(new_n28_), .D(new_n50_), .Y(new_n447_));
  AOI21x1_ASAP7_75t_R  g426(.A1(p7), .A2(new_n57_), .B(new_n447_), .Y(new_n448_));
  OA211x2_ASAP7_75t_R  g427(.A1(new_n297_), .A2(new_n448_), .B(new_n89_), .C(new_n248_), .Y(o10));
endmodule


