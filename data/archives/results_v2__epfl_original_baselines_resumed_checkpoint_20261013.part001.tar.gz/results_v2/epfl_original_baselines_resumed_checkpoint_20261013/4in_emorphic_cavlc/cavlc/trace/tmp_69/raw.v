// Benchmark "/tmp/" written by ABC on Tue Oct 13 18:50:31 2026

module \/tmp/  ( 
    p3, p4, p5, p0, p1, p2, p9, p7, p6, p8,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10  );
  input  p3, p4, p5, p0, p1, p2, p9, p7, p6, p8;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10;
  wire new_n22_, new_n23_, new_n24_, new_n25_, new_n26_, new_n27_, new_n28_,
    new_n29_, new_n30_, new_n31_, new_n32_, new_n33_, new_n34_, new_n35_,
    new_n36_, new_n37_, new_n38_, new_n39_, new_n40_, new_n41_, new_n42_,
    new_n43_, new_n44_, new_n45_, new_n46_, new_n47_, new_n48_, new_n49_,
    new_n50_, new_n51_, new_n52_, new_n53_, new_n54_, new_n55_, new_n56_,
    new_n57_, new_n58_, new_n59_, new_n60_, new_n61_, new_n62_, new_n63_,
    new_n64_, new_n65_, new_n66_, new_n67_, new_n68_, new_n69_, new_n70_,
    new_n71_, new_n72_, new_n73_, new_n74_, new_n75_, new_n76_, new_n77_,
    new_n78_, new_n79_, new_n80_, new_n81_, new_n82_, new_n83_, new_n84_,
    new_n85_, new_n86_, new_n87_, new_n88_, new_n89_, new_n90_, new_n91_,
    new_n92_, new_n93_, new_n94_, new_n95_, new_n96_, new_n97_, new_n98_,
    new_n99_, new_n100_, new_n101_, new_n102_, new_n103_, new_n104_,
    new_n105_, new_n106_, new_n107_, new_n108_, new_n109_, new_n110_,
    new_n111_, new_n112_, new_n113_, new_n114_, new_n115_, new_n116_,
    new_n117_, new_n118_, new_n119_, new_n120_, new_n121_, new_n122_,
    new_n123_, new_n124_, new_n126_, new_n127_, new_n128_, new_n129_,
    new_n130_, new_n131_, new_n132_, new_n133_, new_n134_, new_n135_,
    new_n136_, new_n137_, new_n138_, new_n139_, new_n140_, new_n141_,
    new_n142_, new_n143_, new_n144_, new_n145_, new_n146_, new_n147_,
    new_n148_, new_n149_, new_n150_, new_n151_, new_n152_, new_n153_,
    new_n154_, new_n155_, new_n156_, new_n157_, new_n158_, new_n159_,
    new_n160_, new_n161_, new_n162_, new_n163_, new_n164_, new_n165_,
    new_n166_, new_n167_, new_n168_, new_n169_, new_n170_, new_n171_,
    new_n172_, new_n173_, new_n174_, new_n175_, new_n176_, new_n177_,
    new_n178_, new_n179_, new_n180_, new_n181_, new_n182_, new_n183_,
    new_n184_, new_n185_, new_n186_, new_n187_, new_n188_, new_n189_,
    new_n191_, new_n192_, new_n193_, new_n194_, new_n195_, new_n196_,
    new_n197_, new_n198_, new_n199_, new_n200_, new_n201_, new_n202_,
    new_n203_, new_n204_, new_n205_, new_n206_, new_n207_, new_n208_,
    new_n209_, new_n210_, new_n211_, new_n212_, new_n213_, new_n214_,
    new_n215_, new_n216_, new_n217_, new_n218_, new_n219_, new_n220_,
    new_n221_, new_n222_, new_n223_, new_n224_, new_n225_, new_n226_,
    new_n227_, new_n228_, new_n229_, new_n230_, new_n231_, new_n232_,
    new_n233_, new_n234_, new_n235_, new_n236_, new_n237_, new_n238_,
    new_n239_, new_n240_, new_n241_, new_n242_, new_n244_, new_n245_,
    new_n246_, new_n247_, new_n248_, new_n249_, new_n250_, new_n251_,
    new_n252_, new_n253_, new_n254_, new_n255_, new_n256_, new_n257_,
    new_n258_, new_n259_, new_n260_, new_n261_, new_n262_, new_n263_,
    new_n264_, new_n265_, new_n266_, new_n267_, new_n268_, new_n269_,
    new_n270_, new_n271_, new_n272_, new_n273_, new_n274_, new_n275_,
    new_n276_, new_n277_, new_n278_, new_n279_, new_n280_, new_n281_,
    new_n282_, new_n284_, new_n285_, new_n286_, new_n287_, new_n288_,
    new_n290_, new_n291_, new_n292_, new_n294_, new_n295_, new_n296_,
    new_n297_, new_n298_, new_n299_, new_n300_, new_n301_, new_n302_,
    new_n303_, new_n304_, new_n305_, new_n306_, new_n307_, new_n308_,
    new_n309_, new_n310_, new_n311_, new_n312_, new_n313_, new_n314_,
    new_n315_, new_n316_, new_n317_, new_n318_, new_n319_, new_n320_,
    new_n321_, new_n322_, new_n323_, new_n324_, new_n325_, new_n326_,
    new_n327_, new_n328_, new_n329_, new_n330_, new_n331_, new_n332_,
    new_n333_, new_n334_, new_n336_, new_n337_, new_n338_, new_n339_,
    new_n340_, new_n341_, new_n342_, new_n343_, new_n344_, new_n345_,
    new_n346_, new_n347_, new_n348_, new_n349_, new_n350_, new_n351_,
    new_n352_, new_n353_, new_n354_, new_n355_, new_n356_, new_n357_,
    new_n358_, new_n359_, new_n360_, new_n361_, new_n362_, new_n363_,
    new_n364_, new_n365_, new_n366_, new_n367_, new_n368_, new_n369_,
    new_n370_, new_n371_, new_n372_, new_n373_, new_n374_, new_n375_,
    new_n376_, new_n377_, new_n378_, new_n379_, new_n380_, new_n381_,
    new_n382_, new_n383_, new_n384_, new_n385_, new_n386_, new_n388_,
    new_n389_, new_n390_, new_n391_, new_n392_, new_n393_, new_n394_,
    new_n395_, new_n396_, new_n397_, new_n398_, new_n399_, new_n400_,
    new_n401_, new_n402_, new_n403_, new_n404_, new_n405_, new_n406_,
    new_n407_, new_n408_, new_n409_, new_n410_, new_n411_, new_n412_,
    new_n413_, new_n414_, new_n415_, new_n416_, new_n417_, new_n419_,
    new_n420_, new_n421_, new_n422_, new_n423_, new_n424_, new_n425_,
    new_n426_, new_n427_, new_n428_, new_n429_, new_n430_, new_n431_,
    new_n432_, new_n433_, new_n434_, new_n435_, new_n436_, new_n437_,
    new_n438_, new_n440_, new_n441_, new_n442_;
  NOR2x1_ASAP7_75t_R   g000(.A(p3), .B(p6), .Y(new_n22_));
  INVx1_ASAP7_75t_R    g001(.A(new_n22_), .Y(new_n23_));
  INVx1_ASAP7_75t_R    g002(.A(p4), .Y(new_n24_));
  INVx1_ASAP7_75t_R    g003(.A(p0), .Y(new_n25_));
  NOR2x1_ASAP7_75t_R   g004(.A(p7), .B(new_n25_), .Y(new_n26_));
  INVx1_ASAP7_75t_R    g005(.A(p1), .Y(new_n27_));
  NOR2x1_ASAP7_75t_R   g006(.A(p0), .B(new_n27_), .Y(new_n28_));
  INVx1_ASAP7_75t_R    g007(.A(p8), .Y(new_n29_));
  AND3x1_ASAP7_75t_R   g008(.A(new_n28_), .B(p9), .C(new_n29_), .Y(new_n30_));
  OA21x2_ASAP7_75t_R   g009(.A1(new_n26_), .A2(new_n30_), .B(p2), .Y(new_n31_));
  INVx1_ASAP7_75t_R    g010(.A(p2), .Y(new_n32_));
  OR3x1_ASAP7_75t_R    g011(.A(new_n32_), .B(new_n29_), .C(p7), .Y(new_n33_));
  AND2x2_ASAP7_75t_R   g012(.A(p1), .B(p8), .Y(new_n34_));
  NOR2x1_ASAP7_75t_R   g013(.A(p0), .B(p2), .Y(new_n35_));
  AOI21x1_ASAP7_75t_R  g014(.A1(new_n34_), .A2(new_n35_), .B(new_n26_), .Y(new_n36_));
  AOI21x1_ASAP7_75t_R  g015(.A1(new_n33_), .A2(new_n36_), .B(p9), .Y(new_n37_));
  NAND2x1_ASAP7_75t_R  g016(.A(p1), .B(p8), .Y(new_n38_));
  NOR2x1_ASAP7_75t_R   g017(.A(p0), .B(p8), .Y(new_n39_));
  INVx1_ASAP7_75t_R    g018(.A(new_n39_), .Y(new_n40_));
  NOR2x1_ASAP7_75t_R   g019(.A(p5), .B(new_n32_), .Y(new_n41_));
  AND2x2_ASAP7_75t_R   g020(.A(p1), .B(p2), .Y(new_n42_));
  OR3x1_ASAP7_75t_R    g021(.A(new_n40_), .B(new_n41_), .C(new_n42_), .Y(new_n43_));
  AOI21x1_ASAP7_75t_R  g022(.A1(new_n38_), .A2(new_n43_), .B(p7), .Y(new_n44_));
  OR3x1_ASAP7_75t_R    g023(.A(new_n31_), .B(new_n37_), .C(new_n44_), .Y(new_n45_));
  INVx1_ASAP7_75t_R    g024(.A(p9), .Y(new_n46_));
  NAND2x1_ASAP7_75t_R  g025(.A(new_n32_), .B(new_n46_), .Y(new_n47_));
  OR3x1_ASAP7_75t_R    g026(.A(p0), .B(p7), .C(p8), .Y(new_n48_));
  NOR3x1_ASAP7_75t_R   g027(.A(new_n47_), .B(p1), .C(new_n48_), .Y(new_n49_));
  INVx1_ASAP7_75t_R    g028(.A(p5), .Y(new_n50_));
  AO21x1_ASAP7_75t_R   g029(.A1(p9), .A2(new_n29_), .B(p1), .Y(new_n51_));
  AOI21x1_ASAP7_75t_R  g030(.A1(new_n50_), .A2(new_n51_), .B(new_n24_), .Y(new_n52_));
  NAND2x1_ASAP7_75t_R  g031(.A(p8), .B(new_n46_), .Y(new_n53_));
  NOR2x1_ASAP7_75t_R   g032(.A(p2), .B(new_n25_), .Y(new_n54_));
  AO21x1_ASAP7_75t_R   g033(.A1(new_n53_), .A2(new_n54_), .B(new_n51_), .Y(new_n55_));
  AND3x1_ASAP7_75t_R   g034(.A(new_n27_), .B(new_n29_), .C(p0), .Y(new_n56_));
  AND3x1_ASAP7_75t_R   g035(.A(new_n32_), .B(new_n46_), .C(p5), .Y(new_n57_));
  OA21x2_ASAP7_75t_R   g036(.A1(new_n34_), .A2(new_n56_), .B(new_n57_), .Y(new_n58_));
  AOI21x1_ASAP7_75t_R  g037(.A1(new_n52_), .A2(new_n55_), .B(new_n58_), .Y(new_n59_));
  NAND2x1_ASAP7_75t_R  g038(.A(p5), .B(p8), .Y(new_n60_));
  OR3x1_ASAP7_75t_R    g039(.A(p0), .B(p1), .C(p9), .Y(new_n61_));
  AND2x2_ASAP7_75t_R   g040(.A(p4), .B(p5), .Y(new_n62_));
  INVx1_ASAP7_75t_R    g041(.A(new_n62_), .Y(new_n63_));
  OAI21x1_ASAP7_75t_R  g042(.A1(new_n60_), .A2(new_n61_), .B(new_n63_), .Y(new_n64_));
  NAND2x1_ASAP7_75t_R  g043(.A(p9), .B(new_n29_), .Y(new_n65_));
  INVx1_ASAP7_75t_R    g044(.A(new_n65_), .Y(new_n66_));
  AO21x1_ASAP7_75t_R   g045(.A1(p8), .A2(new_n46_), .B(new_n25_), .Y(new_n67_));
  NAND2x1_ASAP7_75t_R  g046(.A(p4), .B(p1), .Y(new_n68_));
  NOR3x1_ASAP7_75t_R   g047(.A(new_n66_), .B(new_n67_), .C(new_n68_), .Y(new_n69_));
  OAI21x1_ASAP7_75t_R  g048(.A1(new_n64_), .A2(new_n69_), .B(p2), .Y(new_n70_));
  INVx1_ASAP7_75t_R    g049(.A(p7), .Y(new_n71_));
  AOI21x1_ASAP7_75t_R  g050(.A1(new_n59_), .A2(new_n70_), .B(new_n71_), .Y(new_n72_));
  AOI211x1_ASAP7_75t_R g051(.A1(new_n24_), .A2(new_n45_), .B(new_n49_), .C(new_n72_), .Y(new_n73_));
  NOR2x1_ASAP7_75t_R   g052(.A(p3), .B(p5), .Y(new_n74_));
  NAND2x1_ASAP7_75t_R  g053(.A(p7), .B(new_n24_), .Y(new_n75_));
  INVx1_ASAP7_75t_R    g054(.A(p6), .Y(new_n76_));
  NOR2x1_ASAP7_75t_R   g055(.A(p4), .B(p8), .Y(new_n77_));
  NOR2x1_ASAP7_75t_R   g056(.A(p1), .B(new_n46_), .Y(new_n78_));
  OAI21x1_ASAP7_75t_R  g057(.A1(new_n76_), .A2(new_n77_), .B(new_n78_), .Y(new_n79_));
  NOR2x1_ASAP7_75t_R   g058(.A(p8), .B(new_n25_), .Y(new_n80_));
  AO21x1_ASAP7_75t_R   g059(.A1(new_n76_), .A2(new_n80_), .B(p2), .Y(new_n81_));
  AOI21x1_ASAP7_75t_R  g060(.A1(new_n75_), .A2(new_n79_), .B(new_n81_), .Y(new_n82_));
  NOR2x1_ASAP7_75t_R   g061(.A(p0), .B(p9), .Y(new_n83_));
  AND3x1_ASAP7_75t_R   g062(.A(new_n83_), .B(p1), .C(new_n29_), .Y(new_n84_));
  NAND2x1_ASAP7_75t_R  g063(.A(p8), .B(new_n25_), .Y(new_n85_));
  NAND2x1_ASAP7_75t_R  g064(.A(p4), .B(new_n25_), .Y(new_n86_));
  AND3x1_ASAP7_75t_R   g065(.A(new_n85_), .B(new_n78_), .C(new_n86_), .Y(new_n87_));
  AO21x1_ASAP7_75t_R   g066(.A1(p6), .A2(new_n84_), .B(new_n87_), .Y(new_n88_));
  NAND2x1_ASAP7_75t_R  g067(.A(new_n82_), .B(new_n88_), .Y(new_n89_));
  NOR2x1_ASAP7_75t_R   g068(.A(p1), .B(p2), .Y(new_n90_));
  NOR2x1_ASAP7_75t_R   g069(.A(new_n90_), .B(new_n85_), .Y(new_n91_));
  AND3x1_ASAP7_75t_R   g070(.A(new_n25_), .B(p2), .C(p9), .Y(new_n92_));
  OR3x1_ASAP7_75t_R    g071(.A(new_n91_), .B(new_n54_), .C(new_n92_), .Y(new_n93_));
  NAND2x1_ASAP7_75t_R  g072(.A(p4), .B(new_n46_), .Y(new_n94_));
  INVx1_ASAP7_75t_R    g073(.A(new_n94_), .Y(new_n95_));
  AND2x2_ASAP7_75t_R   g074(.A(p0), .B(p1), .Y(new_n96_));
  AO21x1_ASAP7_75t_R   g075(.A1(p1), .A2(new_n46_), .B(new_n96_), .Y(new_n97_));
  OA21x2_ASAP7_75t_R   g076(.A1(new_n95_), .A2(new_n97_), .B(new_n29_), .Y(new_n98_));
  NOR2x1_ASAP7_75t_R   g077(.A(p7), .B(p6), .Y(new_n99_));
  OAI21x1_ASAP7_75t_R  g078(.A1(new_n93_), .A2(new_n98_), .B(new_n99_), .Y(new_n100_));
  NAND2x1_ASAP7_75t_R  g079(.A(p0), .B(p8), .Y(new_n101_));
  NAND2x1_ASAP7_75t_R  g080(.A(new_n101_), .B(new_n40_), .Y(new_n102_));
  INVx1_ASAP7_75t_R    g081(.A(new_n102_), .Y(new_n103_));
  INVx1_ASAP7_75t_R    g082(.A(new_n83_), .Y(new_n104_));
  NOR2x1_ASAP7_75t_R   g083(.A(p4), .B(p2), .Y(new_n105_));
  NAND2x1_ASAP7_75t_R  g084(.A(p9), .B(p8), .Y(new_n106_));
  AOI22x1_ASAP7_75t_R  g085(.A1(new_n104_), .A2(new_n76_), .B1(new_n105_), .B2(new_n106_), .Y(new_n107_));
  NOR2x1_ASAP7_75t_R   g086(.A(p1), .B(p7), .Y(new_n108_));
  INVx1_ASAP7_75t_R    g087(.A(new_n108_), .Y(new_n109_));
  OR3x1_ASAP7_75t_R    g088(.A(new_n103_), .B(new_n107_), .C(new_n109_), .Y(new_n110_));
  NAND3x1_ASAP7_75t_R  g089(.A(new_n89_), .B(new_n100_), .C(new_n110_), .Y(new_n111_));
  NAND2x1_ASAP7_75t_R  g090(.A(p5), .B(new_n24_), .Y(new_n112_));
  NAND2x1_ASAP7_75t_R  g091(.A(p8), .B(new_n50_), .Y(new_n113_));
  INVx1_ASAP7_75t_R    g092(.A(p3), .Y(new_n114_));
  AO21x1_ASAP7_75t_R   g093(.A1(p8), .A2(new_n114_), .B(p7), .Y(new_n115_));
  AO21x1_ASAP7_75t_R   g094(.A1(new_n112_), .A2(new_n113_), .B(new_n115_), .Y(new_n116_));
  NOR2x1_ASAP7_75t_R   g095(.A(p5), .B(p8), .Y(new_n117_));
  AO21x1_ASAP7_75t_R   g096(.A1(p3), .A2(p7), .B(new_n117_), .Y(new_n118_));
  AO21x1_ASAP7_75t_R   g097(.A1(p4), .A2(new_n71_), .B(new_n62_), .Y(new_n119_));
  NAND2x1_ASAP7_75t_R  g098(.A(new_n118_), .B(new_n119_), .Y(new_n120_));
  OR3x1_ASAP7_75t_R    g099(.A(p0), .B(p1), .C(p2), .Y(new_n121_));
  OR3x1_ASAP7_75t_R    g100(.A(new_n121_), .B(p9), .C(p6), .Y(new_n122_));
  AOI21x1_ASAP7_75t_R  g101(.A1(new_n116_), .A2(new_n120_), .B(new_n122_), .Y(new_n123_));
  AOI21x1_ASAP7_75t_R  g102(.A1(new_n74_), .A2(new_n111_), .B(new_n123_), .Y(new_n124_));
  OAI21x1_ASAP7_75t_R  g103(.A1(new_n23_), .A2(new_n73_), .B(new_n124_), .Y(o0));
  AND2x2_ASAP7_75t_R   g104(.A(p5), .B(p7), .Y(new_n126_));
  OR3x1_ASAP7_75t_R    g105(.A(new_n126_), .B(p1), .C(new_n46_), .Y(new_n127_));
  OA21x2_ASAP7_75t_R   g106(.A1(p4), .A2(new_n71_), .B(new_n60_), .Y(new_n128_));
  NAND2x1_ASAP7_75t_R  g107(.A(p4), .B(new_n108_), .Y(new_n129_));
  OAI22x1_ASAP7_75t_R  g108(.A1(new_n127_), .A2(new_n128_), .B1(new_n53_), .B2(new_n129_), .Y(new_n130_));
  AND3x1_ASAP7_75t_R   g109(.A(new_n117_), .B(p1), .C(p7), .Y(new_n131_));
  AOI21x1_ASAP7_75t_R  g110(.A1(p0), .A2(new_n130_), .B(new_n131_), .Y(new_n132_));
  AND2x2_ASAP7_75t_R   g111(.A(p7), .B(p8), .Y(new_n133_));
  AOI22x1_ASAP7_75t_R  g112(.A1(new_n133_), .A2(p5), .B1(new_n71_), .B2(new_n77_), .Y(new_n134_));
  OAI21x1_ASAP7_75t_R  g113(.A1(p9), .A2(new_n128_), .B(new_n134_), .Y(new_n135_));
  NAND2x1_ASAP7_75t_R  g114(.A(new_n46_), .B(new_n71_), .Y(new_n136_));
  NOR2x1_ASAP7_75t_R   g115(.A(p1), .B(p8), .Y(new_n137_));
  AND2x2_ASAP7_75t_R   g116(.A(p9), .B(p7), .Y(new_n138_));
  NOR2x1_ASAP7_75t_R   g117(.A(new_n137_), .B(new_n138_), .Y(new_n139_));
  AOI211x1_ASAP7_75t_R g118(.A1(new_n38_), .A2(new_n136_), .B(new_n86_), .C(new_n139_), .Y(new_n140_));
  AOI21x1_ASAP7_75t_R  g119(.A1(new_n28_), .A2(new_n135_), .B(new_n140_), .Y(new_n141_));
  NAND2x1_ASAP7_75t_R  g120(.A(new_n50_), .B(new_n71_), .Y(new_n142_));
  AO21x1_ASAP7_75t_R   g121(.A1(new_n75_), .A2(new_n142_), .B(p8), .Y(new_n143_));
  NAND2x1_ASAP7_75t_R  g122(.A(p5), .B(new_n46_), .Y(new_n144_));
  AND3x1_ASAP7_75t_R   g123(.A(new_n142_), .B(new_n144_), .C(new_n27_), .Y(new_n145_));
  OR3x1_ASAP7_75t_R    g124(.A(new_n143_), .B(new_n145_), .C(new_n25_), .Y(new_n146_));
  NAND3x1_ASAP7_75t_R  g125(.A(new_n132_), .B(new_n141_), .C(new_n146_), .Y(new_n147_));
  AO21x1_ASAP7_75t_R   g126(.A1(p7), .A2(new_n46_), .B(p4), .Y(new_n148_));
  AND2x2_ASAP7_75t_R   g127(.A(p0), .B(p9), .Y(new_n149_));
  NOR2x1_ASAP7_75t_R   g128(.A(p5), .B(p0), .Y(new_n150_));
  OR3x1_ASAP7_75t_R    g129(.A(new_n149_), .B(p1), .C(new_n150_), .Y(new_n151_));
  OR4x2_ASAP7_75t_R    g130(.A(new_n90_), .B(new_n108_), .C(p5), .D(p9), .Y(new_n152_));
  OAI21x1_ASAP7_75t_R  g131(.A1(new_n148_), .A2(new_n151_), .B(new_n152_), .Y(new_n153_));
  OA21x2_ASAP7_75t_R   g132(.A1(p2), .A2(p7), .B(new_n150_), .Y(new_n154_));
  AND3x1_ASAP7_75t_R   g133(.A(new_n108_), .B(new_n150_), .C(p4), .Y(new_n155_));
  AO31x2_ASAP7_75t_R   g134(.A1(new_n154_), .A2(p9), .A3(new_n75_), .B(new_n155_), .Y(new_n156_));
  NOR2x1_ASAP7_75t_R   g135(.A(p0), .B(p7), .Y(new_n157_));
  OR3x1_ASAP7_75t_R    g136(.A(new_n157_), .B(p4), .C(new_n32_), .Y(new_n158_));
  AO21x1_ASAP7_75t_R   g137(.A1(new_n50_), .A2(p1), .B(new_n96_), .Y(new_n159_));
  OAI21x1_ASAP7_75t_R  g138(.A1(new_n158_), .A2(new_n159_), .B(new_n29_), .Y(new_n160_));
  NOR3x1_ASAP7_75t_R   g139(.A(new_n153_), .B(new_n156_), .C(new_n160_), .Y(new_n161_));
  OR3x1_ASAP7_75t_R    g140(.A(new_n46_), .B(new_n71_), .C(p1), .Y(new_n162_));
  NAND2x1_ASAP7_75t_R  g141(.A(p9), .B(new_n24_), .Y(new_n163_));
  AND3x1_ASAP7_75t_R   g142(.A(new_n162_), .B(new_n94_), .C(new_n163_), .Y(new_n164_));
  OR3x1_ASAP7_75t_R    g143(.A(new_n164_), .B(p5), .C(new_n25_), .Y(new_n165_));
  NOR2x1_ASAP7_75t_R   g144(.A(p7), .B(new_n32_), .Y(new_n166_));
  AND3x1_ASAP7_75t_R   g145(.A(new_n166_), .B(p4), .C(new_n96_), .Y(new_n167_));
  NOR2x1_ASAP7_75t_R   g146(.A(new_n29_), .B(new_n167_), .Y(new_n168_));
  NAND2x1_ASAP7_75t_R  g147(.A(new_n108_), .B(new_n92_), .Y(new_n169_));
  OR3x1_ASAP7_75t_R    g148(.A(new_n24_), .B(new_n25_), .C(new_n46_), .Y(new_n170_));
  NAND2x1_ASAP7_75t_R  g149(.A(p0), .B(new_n42_), .Y(new_n171_));
  AO21x1_ASAP7_75t_R   g150(.A1(new_n27_), .A2(new_n32_), .B(new_n24_), .Y(new_n172_));
  AND3x1_ASAP7_75t_R   g151(.A(new_n170_), .B(new_n171_), .C(new_n172_), .Y(new_n173_));
  AO21x1_ASAP7_75t_R   g152(.A1(new_n169_), .A2(new_n173_), .B(new_n50_), .Y(new_n174_));
  AOI22x1_ASAP7_75t_R  g153(.A1(new_n161_), .A2(new_n165_), .B1(new_n168_), .B2(new_n174_), .Y(new_n175_));
  AOI21x1_ASAP7_75t_R  g154(.A1(new_n32_), .A2(new_n147_), .B(new_n175_), .Y(new_n176_));
  NOR2x1_ASAP7_75t_R   g155(.A(p7), .B(new_n24_), .Y(new_n177_));
  AO21x1_ASAP7_75t_R   g156(.A1(p3), .A2(p7), .B(new_n177_), .Y(new_n178_));
  NAND2x1_ASAP7_75t_R  g157(.A(new_n117_), .B(new_n178_), .Y(new_n179_));
  OA21x2_ASAP7_75t_R   g158(.A1(new_n114_), .A2(new_n60_), .B(new_n179_), .Y(new_n180_));
  NOR2x1_ASAP7_75t_R   g159(.A(p1), .B(new_n71_), .Y(new_n181_));
  AND3x1_ASAP7_75t_R   g160(.A(new_n80_), .B(new_n181_), .C(p6), .Y(new_n182_));
  NOR2x1_ASAP7_75t_R   g161(.A(new_n84_), .B(new_n182_), .Y(new_n183_));
  NOR2x1_ASAP7_75t_R   g162(.A(new_n149_), .B(new_n51_), .Y(new_n184_));
  AO21x1_ASAP7_75t_R   g163(.A1(p1), .A2(p9), .B(p7), .Y(new_n185_));
  OR4x2_ASAP7_75t_R    g164(.A(new_n184_), .B(new_n76_), .C(new_n96_), .D(new_n185_), .Y(new_n186_));
  NAND2x1_ASAP7_75t_R  g165(.A(new_n105_), .B(new_n74_), .Y(new_n187_));
  AO21x1_ASAP7_75t_R   g166(.A1(new_n183_), .A2(new_n186_), .B(new_n187_), .Y(new_n188_));
  OA21x2_ASAP7_75t_R   g167(.A1(new_n122_), .A2(new_n180_), .B(new_n188_), .Y(new_n189_));
  OAI21x1_ASAP7_75t_R  g168(.A1(new_n23_), .A2(new_n176_), .B(new_n189_), .Y(o1));
  AOI22x1_ASAP7_75t_R  g169(.A1(new_n80_), .A2(p7), .B1(new_n85_), .B2(new_n126_), .Y(new_n191_));
  NOR2x1_ASAP7_75t_R   g170(.A(p2), .B(p7), .Y(new_n192_));
  NAND2x1_ASAP7_75t_R  g171(.A(new_n192_), .B(new_n102_), .Y(new_n193_));
  AO21x1_ASAP7_75t_R   g172(.A1(new_n191_), .A2(new_n193_), .B(p1), .Y(new_n194_));
  AO21x1_ASAP7_75t_R   g173(.A1(new_n25_), .A2(new_n71_), .B(new_n50_), .Y(new_n195_));
  AO21x1_ASAP7_75t_R   g174(.A1(p0), .A2(new_n38_), .B(new_n195_), .Y(new_n196_));
  NOR2x1_ASAP7_75t_R   g175(.A(p8), .B(new_n27_), .Y(new_n197_));
  XOR2x2_ASAP7_75t_R   g176(.A(new_n197_), .B(new_n71_), .Y(new_n198_));
  AO21x1_ASAP7_75t_R   g177(.A1(new_n196_), .A2(new_n198_), .B(new_n32_), .Y(new_n199_));
  OR3x1_ASAP7_75t_R    g178(.A(new_n46_), .B(p3), .C(p4), .Y(new_n200_));
  AOI21x1_ASAP7_75t_R  g179(.A1(new_n194_), .A2(new_n199_), .B(new_n200_), .Y(new_n201_));
  NOR2x1_ASAP7_75t_R   g180(.A(p0), .B(new_n32_), .Y(new_n202_));
  NOR2x1_ASAP7_75t_R   g181(.A(p7), .B(p8), .Y(new_n203_));
  OA211x2_ASAP7_75t_R  g182(.A1(new_n24_), .A2(new_n202_), .B(new_n78_), .C(new_n203_), .Y(new_n204_));
  AOI21x1_ASAP7_75t_R  g183(.A1(new_n91_), .A2(new_n138_), .B(new_n204_), .Y(new_n205_));
  NAND2x1_ASAP7_75t_R  g184(.A(p7), .B(p8), .Y(new_n206_));
  NAND2x1_ASAP7_75t_R  g185(.A(p1), .B(new_n206_), .Y(new_n207_));
  AO21x1_ASAP7_75t_R   g186(.A1(new_n40_), .A2(new_n203_), .B(new_n207_), .Y(new_n208_));
  NAND2x1_ASAP7_75t_R  g187(.A(p9), .B(new_n133_), .Y(new_n209_));
  NOR2x1_ASAP7_75t_R   g188(.A(new_n24_), .B(new_n203_), .Y(new_n210_));
  AO21x1_ASAP7_75t_R   g189(.A1(new_n24_), .A2(new_n38_), .B(new_n25_), .Y(new_n211_));
  AO21x1_ASAP7_75t_R   g190(.A1(new_n209_), .A2(new_n210_), .B(new_n211_), .Y(new_n212_));
  AO21x1_ASAP7_75t_R   g191(.A1(new_n208_), .A2(new_n212_), .B(p2), .Y(new_n213_));
  INVx1_ASAP7_75t_R    g192(.A(new_n74_), .Y(new_n214_));
  AOI21x1_ASAP7_75t_R  g193(.A1(new_n205_), .A2(new_n213_), .B(new_n214_), .Y(new_n215_));
  OAI21x1_ASAP7_75t_R  g194(.A1(new_n201_), .A2(new_n215_), .B(new_n76_), .Y(new_n216_));
  OA21x2_ASAP7_75t_R   g195(.A1(new_n76_), .A2(new_n206_), .B(p9), .Y(new_n217_));
  OA22x2_ASAP7_75t_R   g196(.A1(new_n217_), .A2(new_n67_), .B1(new_n46_), .B2(new_n48_), .Y(new_n218_));
  OR3x1_ASAP7_75t_R    g197(.A(new_n218_), .B(p1), .C(new_n187_), .Y(new_n219_));
  AND3x1_ASAP7_75t_R   g198(.A(new_n203_), .B(new_n24_), .C(p5), .Y(new_n220_));
  NAND2x1_ASAP7_75t_R  g199(.A(p5), .B(p1), .Y(new_n221_));
  AND3x1_ASAP7_75t_R   g200(.A(new_n221_), .B(p0), .C(p7), .Y(new_n222_));
  NOR3x1_ASAP7_75t_R   g201(.A(new_n222_), .B(new_n108_), .C(new_n172_), .Y(new_n223_));
  NAND2x1_ASAP7_75t_R  g202(.A(p2), .B(new_n29_), .Y(new_n224_));
  OA211x2_ASAP7_75t_R  g203(.A1(new_n80_), .A2(new_n166_), .B(new_n224_), .C(new_n50_), .Y(new_n225_));
  AOI211x1_ASAP7_75t_R g204(.A1(new_n35_), .A2(new_n220_), .B(new_n223_), .C(new_n225_), .Y(new_n226_));
  AOI21x1_ASAP7_75t_R  g205(.A1(p7), .A2(new_n80_), .B(new_n117_), .Y(new_n227_));
  NAND2x1_ASAP7_75t_R  g206(.A(p2), .B(new_n27_), .Y(new_n228_));
  OAI21x1_ASAP7_75t_R  g207(.A1(p0), .A2(new_n33_), .B(new_n228_), .Y(new_n229_));
  NAND2x1_ASAP7_75t_R  g208(.A(p5), .B(new_n71_), .Y(new_n230_));
  OR3x1_ASAP7_75t_R    g209(.A(new_n25_), .B(new_n29_), .C(p2), .Y(new_n231_));
  OAI21x1_ASAP7_75t_R  g210(.A1(new_n230_), .A2(new_n231_), .B(new_n114_), .Y(new_n232_));
  AOI21x1_ASAP7_75t_R  g211(.A1(new_n227_), .A2(new_n229_), .B(new_n232_), .Y(new_n233_));
  AO21x1_ASAP7_75t_R   g212(.A1(p7), .A2(new_n228_), .B(p4), .Y(new_n234_));
  NAND2x1_ASAP7_75t_R  g213(.A(p4), .B(p2), .Y(new_n235_));
  OA21x2_ASAP7_75t_R   g214(.A1(new_n235_), .A2(new_n181_), .B(new_n80_), .Y(new_n236_));
  NAND2x1_ASAP7_75t_R  g215(.A(new_n234_), .B(new_n236_), .Y(new_n237_));
  NAND3x1_ASAP7_75t_R  g216(.A(new_n226_), .B(new_n233_), .C(new_n237_), .Y(new_n238_));
  AO21x1_ASAP7_75t_R   g217(.A1(new_n206_), .A2(new_n230_), .B(p4), .Y(new_n239_));
  AO21x1_ASAP7_75t_R   g218(.A1(new_n25_), .A2(new_n90_), .B(new_n114_), .Y(new_n240_));
  OA211x2_ASAP7_75t_R  g219(.A1(new_n114_), .A2(new_n239_), .B(new_n46_), .C(new_n240_), .Y(new_n241_));
  NAND3x1_ASAP7_75t_R  g220(.A(new_n238_), .B(new_n76_), .C(new_n241_), .Y(new_n242_));
  NAND3x1_ASAP7_75t_R  g221(.A(new_n216_), .B(new_n219_), .C(new_n242_), .Y(o2));
  NOR2x1_ASAP7_75t_R   g222(.A(p4), .B(new_n27_), .Y(new_n244_));
  NAND2x1_ASAP7_75t_R  g223(.A(p1), .B(p7), .Y(new_n245_));
  NAND2x1_ASAP7_75t_R  g224(.A(p4), .B(p7), .Y(new_n246_));
  NAND2x1_ASAP7_75t_R  g225(.A(p1), .B(new_n32_), .Y(new_n247_));
  NAND2x1_ASAP7_75t_R  g226(.A(new_n246_), .B(new_n247_), .Y(new_n248_));
  AO22x1_ASAP7_75t_R   g227(.A1(p7), .A2(new_n244_), .B1(new_n245_), .B2(new_n248_), .Y(new_n249_));
  AO21x1_ASAP7_75t_R   g228(.A1(p5), .A2(new_n105_), .B(new_n155_), .Y(new_n250_));
  AO21x1_ASAP7_75t_R   g229(.A1(p0), .A2(new_n249_), .B(new_n250_), .Y(new_n251_));
  AND3x1_ASAP7_75t_R   g230(.A(new_n108_), .B(p4), .C(p8), .Y(new_n252_));
  NOR2x1_ASAP7_75t_R   g231(.A(p4), .B(new_n32_), .Y(new_n253_));
  NOR2x1_ASAP7_75t_R   g232(.A(p5), .B(new_n166_), .Y(new_n254_));
  OAI21x1_ASAP7_75t_R  g233(.A1(new_n253_), .A2(new_n254_), .B(new_n228_), .Y(new_n255_));
  OA21x2_ASAP7_75t_R   g234(.A1(new_n252_), .A2(new_n255_), .B(new_n149_), .Y(new_n256_));
  AO21x1_ASAP7_75t_R   g235(.A1(new_n71_), .A2(new_n41_), .B(new_n220_), .Y(new_n257_));
  OR3x1_ASAP7_75t_R    g236(.A(new_n27_), .B(new_n32_), .C(p5), .Y(new_n258_));
  NAND2x1_ASAP7_75t_R  g237(.A(new_n112_), .B(new_n258_), .Y(new_n259_));
  AOI22x1_ASAP7_75t_R  g238(.A1(new_n257_), .A2(new_n25_), .B1(new_n91_), .B2(new_n259_), .Y(new_n260_));
  AO21x1_ASAP7_75t_R   g239(.A1(p4), .A2(p8), .B(p5), .Y(new_n261_));
  AO21x1_ASAP7_75t_R   g240(.A1(new_n101_), .A2(new_n246_), .B(new_n261_), .Y(new_n262_));
  NAND2x1_ASAP7_75t_R  g241(.A(p0), .B(new_n29_), .Y(new_n263_));
  OR3x1_ASAP7_75t_R    g242(.A(new_n263_), .B(new_n112_), .C(new_n71_), .Y(new_n264_));
  INVx1_ASAP7_75t_R    g243(.A(new_n77_), .Y(new_n265_));
  AO21x1_ASAP7_75t_R   g244(.A1(new_n142_), .A2(new_n265_), .B(new_n228_), .Y(new_n266_));
  OA211x2_ASAP7_75t_R  g245(.A1(new_n32_), .A2(new_n262_), .B(new_n264_), .C(new_n266_), .Y(new_n267_));
  NAND2x1_ASAP7_75t_R  g246(.A(new_n260_), .B(new_n267_), .Y(new_n268_));
  AOI211x1_ASAP7_75t_R g247(.A1(new_n66_), .A2(new_n251_), .B(new_n256_), .C(new_n268_), .Y(new_n269_));
  AND2x2_ASAP7_75t_R   g248(.A(new_n32_), .B(new_n230_), .Y(new_n270_));
  OR3x1_ASAP7_75t_R    g249(.A(new_n265_), .B(new_n27_), .C(p7), .Y(new_n271_));
  OR3x1_ASAP7_75t_R    g250(.A(new_n113_), .B(new_n27_), .C(new_n246_), .Y(new_n272_));
  OA211x2_ASAP7_75t_R  g251(.A1(new_n119_), .A2(new_n270_), .B(new_n271_), .C(new_n272_), .Y(new_n273_));
  AO21x1_ASAP7_75t_R   g252(.A1(new_n27_), .A2(new_n32_), .B(p0), .Y(new_n274_));
  AO21x1_ASAP7_75t_R   g253(.A1(new_n50_), .A2(new_n224_), .B(new_n274_), .Y(new_n275_));
  OA21x2_ASAP7_75t_R   g254(.A1(p4), .A2(new_n221_), .B(new_n275_), .Y(new_n276_));
  OAI21x1_ASAP7_75t_R  g255(.A1(new_n25_), .A2(new_n273_), .B(new_n276_), .Y(new_n277_));
  AND3x1_ASAP7_75t_R   g256(.A(new_n114_), .B(new_n46_), .C(new_n76_), .Y(new_n278_));
  NOR2x1_ASAP7_75t_R   g257(.A(p4), .B(p5), .Y(new_n279_));
  AO21x1_ASAP7_75t_R   g258(.A1(new_n279_), .A2(new_n133_), .B(new_n62_), .Y(new_n280_));
  NOR2x1_ASAP7_75t_R   g259(.A(new_n114_), .B(new_n122_), .Y(new_n281_));
  AOI22x1_ASAP7_75t_R  g260(.A1(new_n277_), .A2(new_n278_), .B1(new_n280_), .B2(new_n281_), .Y(new_n282_));
  OAI21x1_ASAP7_75t_R  g261(.A1(new_n23_), .A2(new_n269_), .B(new_n282_), .Y(o3));
  AND3x1_ASAP7_75t_R   g262(.A(new_n104_), .B(new_n114_), .C(p1), .Y(new_n284_));
  NOR2x1_ASAP7_75t_R   g263(.A(p2), .B(new_n114_), .Y(new_n285_));
  NOR2x1_ASAP7_75t_R   g264(.A(p3), .B(new_n32_), .Y(new_n286_));
  INVx1_ASAP7_75t_R    g265(.A(new_n61_), .Y(new_n287_));
  OA21x2_ASAP7_75t_R   g266(.A1(new_n285_), .A2(new_n286_), .B(new_n287_), .Y(new_n288_));
  OA211x2_ASAP7_75t_R  g267(.A1(new_n284_), .A2(new_n288_), .B(new_n76_), .C(new_n62_), .Y(o4));
  NAND2x1_ASAP7_75t_R  g268(.A(new_n61_), .B(new_n286_), .Y(new_n290_));
  OR3x1_ASAP7_75t_R    g269(.A(new_n61_), .B(new_n114_), .C(p2), .Y(new_n291_));
  OR3x1_ASAP7_75t_R    g270(.A(new_n24_), .B(new_n50_), .C(p6), .Y(new_n292_));
  AOI21x1_ASAP7_75t_R  g271(.A1(new_n290_), .A2(new_n291_), .B(new_n292_), .Y(o5));
  OA21x2_ASAP7_75t_R   g272(.A1(new_n27_), .A2(new_n53_), .B(new_n48_), .Y(new_n294_));
  OR3x1_ASAP7_75t_R    g273(.A(new_n77_), .B(new_n245_), .C(p9), .Y(new_n295_));
  OA21x2_ASAP7_75t_R   g274(.A1(new_n24_), .A2(new_n294_), .B(new_n295_), .Y(new_n296_));
  AND3x1_ASAP7_75t_R   g275(.A(p4), .B(p0), .C(p8), .Y(new_n297_));
  OA211x2_ASAP7_75t_R  g276(.A1(new_n25_), .A2(new_n27_), .B(new_n117_), .C(new_n68_), .Y(new_n298_));
  OAI21x1_ASAP7_75t_R  g277(.A1(new_n297_), .A2(new_n298_), .B(new_n138_), .Y(new_n299_));
  NAND2x1_ASAP7_75t_R  g278(.A(new_n245_), .B(new_n109_), .Y(new_n300_));
  NOR2x1_ASAP7_75t_R   g279(.A(new_n203_), .B(new_n133_), .Y(new_n301_));
  NOR2x1_ASAP7_75t_R   g280(.A(new_n50_), .B(new_n301_), .Y(new_n302_));
  NAND2x1_ASAP7_75t_R  g281(.A(new_n300_), .B(new_n302_), .Y(new_n303_));
  AO31x2_ASAP7_75t_R   g282(.A1(new_n296_), .A2(new_n299_), .A3(new_n303_), .B(p2), .Y(new_n304_));
  NOR2x1_ASAP7_75t_R   g283(.A(p5), .B(p9), .Y(new_n305_));
  INVx1_ASAP7_75t_R    g284(.A(new_n157_), .Y(new_n306_));
  AO21x1_ASAP7_75t_R   g285(.A1(new_n305_), .A2(new_n306_), .B(new_n197_), .Y(new_n307_));
  AO21x1_ASAP7_75t_R   g286(.A1(new_n71_), .A2(new_n29_), .B(p0), .Y(new_n308_));
  AND3x1_ASAP7_75t_R   g287(.A(new_n308_), .B(p9), .C(new_n263_), .Y(new_n309_));
  AO21x1_ASAP7_75t_R   g288(.A1(new_n307_), .A2(new_n103_), .B(new_n309_), .Y(new_n310_));
  NAND2x1_ASAP7_75t_R  g289(.A(p1), .B(new_n46_), .Y(new_n311_));
  AO22x1_ASAP7_75t_R   g290(.A1(new_n126_), .A2(new_n78_), .B1(new_n26_), .B2(new_n311_), .Y(new_n312_));
  AND3x1_ASAP7_75t_R   g291(.A(new_n80_), .B(new_n136_), .C(new_n163_), .Y(new_n313_));
  AO21x1_ASAP7_75t_R   g292(.A1(p8), .A2(new_n312_), .B(new_n313_), .Y(new_n314_));
  AOI22x1_ASAP7_75t_R  g293(.A1(new_n310_), .A2(new_n253_), .B1(p2), .B2(new_n314_), .Y(new_n315_));
  NOR2x1_ASAP7_75t_R   g294(.A(p9), .B(new_n27_), .Y(new_n316_));
  AO21x1_ASAP7_75t_R   g295(.A1(p5), .A2(new_n71_), .B(p9), .Y(new_n317_));
  AND3x1_ASAP7_75t_R   g296(.A(new_n317_), .B(new_n137_), .C(new_n246_), .Y(new_n318_));
  AO21x1_ASAP7_75t_R   g297(.A1(new_n316_), .A2(new_n133_), .B(new_n318_), .Y(new_n319_));
  OAI21x1_ASAP7_75t_R  g298(.A1(new_n24_), .A2(new_n51_), .B(new_n53_), .Y(new_n320_));
  OR3x1_ASAP7_75t_R    g299(.A(new_n244_), .B(new_n53_), .C(p5), .Y(new_n321_));
  AND3x1_ASAP7_75t_R   g300(.A(new_n320_), .B(new_n71_), .C(new_n321_), .Y(new_n322_));
  OA21x2_ASAP7_75t_R   g301(.A1(p7), .A2(p8), .B(p1), .Y(new_n323_));
  AO21x1_ASAP7_75t_R   g302(.A1(p9), .A2(new_n133_), .B(new_n323_), .Y(new_n324_));
  AO21x1_ASAP7_75t_R   g303(.A1(p5), .A2(new_n324_), .B(new_n25_), .Y(new_n325_));
  OAI22x1_ASAP7_75t_R  g304(.A1(new_n319_), .A2(p0), .B1(new_n322_), .B2(new_n325_), .Y(new_n326_));
  NAND3x1_ASAP7_75t_R  g305(.A(new_n304_), .B(new_n315_), .C(new_n326_), .Y(new_n327_));
  AO21x1_ASAP7_75t_R   g306(.A1(p6), .A2(new_n29_), .B(new_n71_), .Y(new_n328_));
  AO21x1_ASAP7_75t_R   g307(.A1(new_n28_), .A2(new_n328_), .B(new_n56_), .Y(new_n329_));
  AND3x1_ASAP7_75t_R   g308(.A(new_n308_), .B(new_n27_), .C(p6), .Y(new_n330_));
  AO21x1_ASAP7_75t_R   g309(.A1(p9), .A2(new_n133_), .B(new_n203_), .Y(new_n331_));
  AOI22x1_ASAP7_75t_R  g310(.A1(new_n329_), .A2(new_n46_), .B1(new_n330_), .B2(new_n331_), .Y(new_n332_));
  OA21x2_ASAP7_75t_R   g311(.A1(new_n114_), .A2(new_n122_), .B(new_n292_), .Y(new_n333_));
  OAI21x1_ASAP7_75t_R  g312(.A1(new_n187_), .A2(new_n332_), .B(new_n333_), .Y(new_n334_));
  AOI21x1_ASAP7_75t_R  g313(.A1(new_n22_), .A2(new_n327_), .B(new_n334_), .Y(o6));
  AND3x1_ASAP7_75t_R   g314(.A(new_n24_), .B(new_n25_), .C(new_n32_), .Y(new_n336_));
  AND3x1_ASAP7_75t_R   g315(.A(new_n27_), .B(p9), .C(p7), .Y(new_n337_));
  NOR2x1_ASAP7_75t_R   g316(.A(p8), .B(new_n76_), .Y(new_n338_));
  AO22x1_ASAP7_75t_R   g317(.A1(new_n337_), .A2(new_n338_), .B1(new_n316_), .B2(new_n301_), .Y(new_n339_));
  AND2x2_ASAP7_75t_R   g318(.A(new_n336_), .B(new_n339_), .Y(new_n340_));
  AO21x1_ASAP7_75t_R   g319(.A1(new_n74_), .A2(new_n340_), .B(new_n22_), .Y(new_n341_));
  NAND2x1_ASAP7_75t_R  g320(.A(p2), .B(new_n50_), .Y(new_n342_));
  NAND2x1_ASAP7_75t_R  g321(.A(p7), .B(new_n46_), .Y(new_n343_));
  OAI21x1_ASAP7_75t_R  g322(.A1(new_n342_), .A2(new_n343_), .B(new_n230_), .Y(new_n344_));
  AOI21x1_ASAP7_75t_R  g323(.A1(p5), .A2(p8), .B(p7), .Y(new_n345_));
  AOI211x1_ASAP7_75t_R g324(.A1(new_n46_), .A2(p8), .B(new_n305_), .C(new_n345_), .Y(new_n346_));
  AOI22x1_ASAP7_75t_R  g325(.A1(new_n344_), .A2(p8), .B1(new_n342_), .B2(new_n346_), .Y(new_n347_));
  NAND3x1_ASAP7_75t_R  g326(.A(new_n42_), .B(new_n50_), .C(new_n206_), .Y(new_n348_));
  OR3x1_ASAP7_75t_R    g327(.A(new_n245_), .B(p5), .C(new_n46_), .Y(new_n349_));
  OR3x1_ASAP7_75t_R    g328(.A(new_n206_), .B(new_n27_), .C(p2), .Y(new_n350_));
  NAND2x1_ASAP7_75t_R  g329(.A(new_n117_), .B(new_n192_), .Y(new_n351_));
  AND4x2_ASAP7_75t_R   g330(.A(new_n348_), .B(new_n349_), .C(new_n350_), .D(new_n351_), .Y(new_n352_));
  OAI21x1_ASAP7_75t_R  g331(.A1(p1), .A2(new_n347_), .B(new_n352_), .Y(new_n353_));
  AO21x1_ASAP7_75t_R   g332(.A1(p7), .A2(p8), .B(p5), .Y(new_n354_));
  AOI211x1_ASAP7_75t_R g333(.A1(p9), .A2(new_n29_), .B(p1), .C(new_n354_), .Y(new_n355_));
  INVx1_ASAP7_75t_R    g334(.A(new_n203_), .Y(new_n356_));
  AOI21x1_ASAP7_75t_R  g335(.A1(new_n206_), .A2(new_n356_), .B(new_n144_), .Y(new_n357_));
  OAI21x1_ASAP7_75t_R  g336(.A1(new_n355_), .A2(new_n357_), .B(new_n202_), .Y(new_n358_));
  NOR3x1_ASAP7_75t_R   g337(.A(p1), .B(p9), .C(p7), .Y(new_n359_));
  AND3x1_ASAP7_75t_R   g338(.A(p5), .B(p9), .C(p7), .Y(new_n360_));
  OA21x2_ASAP7_75t_R   g339(.A1(new_n359_), .A2(new_n360_), .B(new_n29_), .Y(new_n361_));
  OA21x2_ASAP7_75t_R   g340(.A1(p5), .A2(new_n192_), .B(new_n323_), .Y(new_n362_));
  OAI21x1_ASAP7_75t_R  g341(.A1(new_n361_), .A2(new_n362_), .B(new_n25_), .Y(new_n363_));
  OR3x1_ASAP7_75t_R    g342(.A(new_n109_), .B(new_n224_), .C(new_n50_), .Y(new_n364_));
  NAND3x1_ASAP7_75t_R  g343(.A(new_n358_), .B(new_n363_), .C(new_n364_), .Y(new_n365_));
  AOI21x1_ASAP7_75t_R  g344(.A1(p0), .A2(new_n353_), .B(new_n365_), .Y(new_n366_));
  OR3x1_ASAP7_75t_R    g345(.A(new_n42_), .B(new_n133_), .C(new_n203_), .Y(new_n367_));
  AO21x1_ASAP7_75t_R   g346(.A1(new_n27_), .A2(new_n46_), .B(new_n90_), .Y(new_n368_));
  OR3x1_ASAP7_75t_R    g347(.A(new_n38_), .B(new_n235_), .C(new_n71_), .Y(new_n369_));
  OAI21x1_ASAP7_75t_R  g348(.A1(new_n86_), .A2(new_n368_), .B(new_n369_), .Y(new_n370_));
  AOI22x1_ASAP7_75t_R  g349(.A1(new_n339_), .A2(new_n336_), .B1(new_n367_), .B2(new_n370_), .Y(new_n371_));
  INVx1_ASAP7_75t_R    g350(.A(new_n235_), .Y(new_n372_));
  OA21x2_ASAP7_75t_R   g351(.A1(new_n197_), .A2(new_n372_), .B(p0), .Y(new_n373_));
  AO21x1_ASAP7_75t_R   g352(.A1(new_n46_), .A2(new_n71_), .B(new_n137_), .Y(new_n374_));
  AO21x1_ASAP7_75t_R   g353(.A1(new_n108_), .A2(new_n372_), .B(new_n374_), .Y(new_n375_));
  AND3x1_ASAP7_75t_R   g354(.A(new_n92_), .B(p1), .C(new_n203_), .Y(new_n376_));
  AOI21x1_ASAP7_75t_R  g355(.A1(new_n373_), .A2(new_n375_), .B(new_n376_), .Y(new_n377_));
  INVx1_ASAP7_75t_R    g356(.A(new_n137_), .Y(new_n378_));
  AND3x1_ASAP7_75t_R   g357(.A(new_n378_), .B(p9), .C(new_n38_), .Y(new_n379_));
  NOR2x1_ASAP7_75t_R   g358(.A(p9), .B(p8), .Y(new_n380_));
  AO21x1_ASAP7_75t_R   g359(.A1(p4), .A2(new_n380_), .B(new_n177_), .Y(new_n381_));
  AND3x1_ASAP7_75t_R   g360(.A(new_n109_), .B(new_n356_), .C(new_n54_), .Y(new_n382_));
  OAI21x1_ASAP7_75t_R  g361(.A1(new_n379_), .A2(new_n381_), .B(new_n382_), .Y(new_n383_));
  AO31x2_ASAP7_75t_R   g362(.A1(new_n371_), .A2(new_n377_), .A3(new_n383_), .B(p5), .Y(new_n384_));
  OAI21x1_ASAP7_75t_R  g363(.A1(p4), .A2(new_n366_), .B(new_n384_), .Y(new_n385_));
  AND2x2_ASAP7_75t_R   g364(.A(new_n279_), .B(new_n281_), .Y(new_n386_));
  AOI21x1_ASAP7_75t_R  g365(.A1(new_n341_), .A2(new_n385_), .B(new_n386_), .Y(o7));
  AO21x1_ASAP7_75t_R   g366(.A1(p4), .A2(new_n25_), .B(new_n105_), .Y(new_n388_));
  AND3x1_ASAP7_75t_R   g367(.A(new_n388_), .B(new_n47_), .C(new_n181_), .Y(new_n389_));
  AND3x1_ASAP7_75t_R   g368(.A(new_n138_), .B(new_n24_), .C(new_n35_), .Y(new_n390_));
  AND3x1_ASAP7_75t_R   g369(.A(new_n148_), .B(new_n96_), .C(new_n235_), .Y(new_n391_));
  OR3x1_ASAP7_75t_R    g370(.A(new_n389_), .B(new_n390_), .C(new_n391_), .Y(new_n392_));
  AO21x1_ASAP7_75t_R   g371(.A1(p4), .A2(p2), .B(new_n244_), .Y(new_n393_));
  OA21x2_ASAP7_75t_R   g372(.A1(new_n32_), .A2(new_n181_), .B(p0), .Y(new_n394_));
  AND3x1_ASAP7_75t_R   g373(.A(new_n202_), .B(new_n181_), .C(new_n94_), .Y(new_n395_));
  AO21x1_ASAP7_75t_R   g374(.A1(new_n393_), .A2(new_n394_), .B(new_n395_), .Y(new_n396_));
  INVx1_ASAP7_75t_R    g375(.A(new_n113_), .Y(new_n397_));
  AOI22x1_ASAP7_75t_R  g376(.A1(new_n392_), .A2(new_n117_), .B1(new_n396_), .B2(new_n397_), .Y(new_n398_));
  NAND2x1_ASAP7_75t_R  g377(.A(new_n40_), .B(new_n388_), .Y(new_n399_));
  AO21x1_ASAP7_75t_R   g378(.A1(new_n378_), .A2(new_n228_), .B(new_n399_), .Y(new_n400_));
  OR3x1_ASAP7_75t_R    g379(.A(new_n86_), .B(p1), .C(p8), .Y(new_n401_));
  AO21x1_ASAP7_75t_R   g380(.A1(new_n231_), .A2(new_n401_), .B(p9), .Y(new_n402_));
  INVx1_ASAP7_75t_R    g381(.A(new_n247_), .Y(new_n403_));
  AOI22x1_ASAP7_75t_R  g382(.A1(new_n102_), .A2(new_n403_), .B1(new_n28_), .B2(new_n105_), .Y(new_n404_));
  AO31x2_ASAP7_75t_R   g383(.A1(new_n400_), .A2(new_n402_), .A3(new_n404_), .B(new_n142_), .Y(new_n405_));
  OA211x2_ASAP7_75t_R  g384(.A1(new_n80_), .A2(new_n343_), .B(new_n85_), .C(p5), .Y(new_n406_));
  AO21x1_ASAP7_75t_R   g385(.A1(p9), .A2(new_n308_), .B(new_n26_), .Y(new_n407_));
  OA21x2_ASAP7_75t_R   g386(.A1(p5), .A2(new_n407_), .B(new_n253_), .Y(new_n408_));
  OAI21x1_ASAP7_75t_R  g387(.A1(p1), .A2(new_n406_), .B(new_n408_), .Y(new_n409_));
  NAND3x1_ASAP7_75t_R  g388(.A(new_n398_), .B(new_n405_), .C(new_n409_), .Y(new_n410_));
  OR3x1_ASAP7_75t_R    g389(.A(new_n122_), .B(new_n114_), .C(p4), .Y(new_n411_));
  OR3x1_ASAP7_75t_R    g390(.A(new_n109_), .B(p9), .C(new_n101_), .Y(new_n412_));
  AO21x1_ASAP7_75t_R   g391(.A1(p9), .A2(p7), .B(new_n34_), .Y(new_n413_));
  AO22x1_ASAP7_75t_R   g392(.A1(new_n380_), .A2(new_n300_), .B1(new_n374_), .B2(new_n413_), .Y(new_n414_));
  NAND2x1_ASAP7_75t_R  g393(.A(new_n25_), .B(new_n414_), .Y(new_n415_));
  AO21x1_ASAP7_75t_R   g394(.A1(new_n412_), .A2(new_n415_), .B(new_n187_), .Y(new_n416_));
  NAND2x1_ASAP7_75t_R  g395(.A(new_n411_), .B(new_n416_), .Y(new_n417_));
  AOI21x1_ASAP7_75t_R  g396(.A1(new_n22_), .A2(new_n410_), .B(new_n417_), .Y(o8));
  INVx1_ASAP7_75t_R    g397(.A(new_n285_), .Y(new_n419_));
  OA21x2_ASAP7_75t_R   g398(.A1(new_n279_), .A2(new_n419_), .B(new_n27_), .Y(new_n420_));
  AND3x1_ASAP7_75t_R   g399(.A(new_n261_), .B(new_n46_), .C(p7), .Y(new_n421_));
  AO21x1_ASAP7_75t_R   g400(.A1(new_n342_), .A2(new_n224_), .B(new_n421_), .Y(new_n422_));
  AO21x1_ASAP7_75t_R   g401(.A1(p7), .A2(p8), .B(p4), .Y(new_n423_));
  AND3x1_ASAP7_75t_R   g402(.A(new_n323_), .B(new_n32_), .C(new_n423_), .Y(new_n424_));
  AOI21x1_ASAP7_75t_R  g403(.A1(new_n420_), .A2(new_n422_), .B(new_n424_), .Y(new_n425_));
  AO21x1_ASAP7_75t_R   g404(.A1(new_n76_), .A2(new_n121_), .B(new_n46_), .Y(new_n426_));
  OA211x2_ASAP7_75t_R  g405(.A1(new_n253_), .A2(new_n221_), .B(new_n426_), .C(new_n63_), .Y(new_n427_));
  OAI21x1_ASAP7_75t_R  g406(.A1(new_n163_), .A2(new_n258_), .B(new_n76_), .Y(new_n428_));
  NAND2x1_ASAP7_75t_R  g407(.A(new_n308_), .B(new_n428_), .Y(new_n429_));
  OA21x2_ASAP7_75t_R   g408(.A1(new_n76_), .A2(new_n403_), .B(new_n240_), .Y(new_n430_));
  AND3x1_ASAP7_75t_R   g409(.A(new_n427_), .B(new_n429_), .C(new_n430_), .Y(new_n431_));
  AO21x1_ASAP7_75t_R   g410(.A1(new_n24_), .A2(new_n29_), .B(p2), .Y(new_n432_));
  AO21x1_ASAP7_75t_R   g411(.A1(p2), .A2(new_n60_), .B(p1), .Y(new_n433_));
  AO21x1_ASAP7_75t_R   g412(.A1(new_n343_), .A2(new_n432_), .B(new_n433_), .Y(new_n434_));
  AND3x1_ASAP7_75t_R   g413(.A(new_n142_), .B(new_n32_), .C(new_n261_), .Y(new_n435_));
  NOR2x1_ASAP7_75t_R   g414(.A(new_n423_), .B(new_n258_), .Y(new_n436_));
  NOR2x1_ASAP7_75t_R   g415(.A(new_n435_), .B(new_n436_), .Y(new_n437_));
  AO21x1_ASAP7_75t_R   g416(.A1(new_n434_), .A2(new_n437_), .B(new_n25_), .Y(new_n438_));
  OA211x2_ASAP7_75t_R  g417(.A1(p0), .A2(new_n425_), .B(new_n431_), .C(new_n438_), .Y(o9));
  AO21x1_ASAP7_75t_R   g418(.A1(p0), .A2(new_n53_), .B(new_n71_), .Y(new_n440_));
  AND3x1_ASAP7_75t_R   g419(.A(new_n284_), .B(new_n440_), .C(new_n85_), .Y(new_n441_));
  AO22x1_ASAP7_75t_R   g420(.A1(new_n287_), .A2(new_n285_), .B1(p2), .B2(new_n441_), .Y(new_n442_));
  AND3x1_ASAP7_75t_R   g421(.A(new_n442_), .B(new_n76_), .C(new_n279_), .Y(o10));
endmodule


