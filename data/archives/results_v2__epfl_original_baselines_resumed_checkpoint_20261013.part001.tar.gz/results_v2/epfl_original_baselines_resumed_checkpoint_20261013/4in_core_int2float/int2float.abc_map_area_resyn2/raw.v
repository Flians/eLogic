// Benchmark "/home/flynn/workplace/MIGBalance/results_v2/epfl_original_baselines_resumed_checkpoint_20261013/4in_core_int2float/int2float.resyn2" written by ABC on Tue Oct 13 18:58:19 2026

module \/home/flynn/workplace/MIGBalance/results_v2/epfl_original_baselines_resumed_checkpoint_20261013/4in_core_int2float/int2float.resyn2  ( 
    \B[0] , \B[1] , \B[2] , \B[3] , \B[4] , \B[5] , \B[6] , \B[7] , \B[8] ,
    \B[9] , \B[10] ,
    \M[0] , \M[1] , \M[2] , \M[3] , \E[0] , \E[1] , \E[2]   );
  input  \B[0] , \B[1] , \B[2] , \B[3] , \B[4] , \B[5] , \B[6] , \B[7] ,
    \B[8] , \B[9] , \B[10] ;
  output \M[0] , \M[1] , \M[2] , \M[3] , \E[0] , \E[1] , \E[2] ;
  wire new_n19_, new_n20_, new_n21_, new_n22_, new_n23_, new_n24_, new_n25_,
    new_n26_, new_n27_, new_n28_, new_n29_, new_n30_, new_n31_, new_n32_,
    new_n33_, new_n34_, new_n35_, new_n36_, new_n37_, new_n38_, new_n39_,
    new_n40_, new_n41_, new_n42_, new_n43_, new_n44_, new_n45_, new_n46_,
    new_n47_, new_n48_, new_n49_, new_n50_, new_n51_, new_n52_, new_n53_,
    new_n54_, new_n55_, new_n57_, new_n58_, new_n59_, new_n60_, new_n61_,
    new_n62_, new_n63_, new_n64_, new_n65_, new_n66_, new_n67_, new_n68_,
    new_n69_, new_n70_, new_n71_, new_n72_, new_n73_, new_n74_, new_n75_,
    new_n76_, new_n77_, new_n78_, new_n79_, new_n80_, new_n81_, new_n82_,
    new_n83_, new_n84_, new_n85_, new_n86_, new_n87_, new_n88_, new_n89_,
    new_n90_, new_n92_, new_n93_, new_n94_, new_n95_, new_n96_, new_n97_,
    new_n98_, new_n99_, new_n100_, new_n101_, new_n102_, new_n103_,
    new_n104_, new_n105_, new_n106_, new_n107_, new_n108_, new_n109_,
    new_n110_, new_n111_, new_n112_, new_n113_, new_n114_, new_n115_,
    new_n116_, new_n117_, new_n118_, new_n119_, new_n120_, new_n122_,
    new_n123_, new_n124_, new_n125_, new_n126_, new_n127_, new_n129_,
    new_n130_, new_n131_, new_n132_, new_n133_, new_n134_, new_n135_,
    new_n136_, new_n137_, new_n138_, new_n139_, new_n140_, new_n141_,
    new_n143_, new_n144_, new_n145_, new_n146_, new_n147_, new_n148_,
    new_n149_;
  INVx1_ASAP7_75t_R    g000(.A(\B[10] ), .Y(new_n19_));
  INVx1_ASAP7_75t_R    g001(.A(\B[9] ), .Y(new_n20_));
  INVx1_ASAP7_75t_R    g002(.A(\B[5] ), .Y(new_n21_));
  INVx1_ASAP7_75t_R    g003(.A(\B[4] ), .Y(new_n22_));
  AND2x2_ASAP7_75t_R   g004(.A(\B[1] ), .B(\B[4] ), .Y(new_n23_));
  AO21x1_ASAP7_75t_R   g005(.A1(new_n22_), .A2(\B[8] ), .B(new_n23_), .Y(new_n24_));
  NAND2x1_ASAP7_75t_R  g006(.A(\B[0] ), .B(new_n24_), .Y(new_n25_));
  INVx1_ASAP7_75t_R    g007(.A(\B[6] ), .Y(new_n26_));
  INVx1_ASAP7_75t_R    g008(.A(\B[7] ), .Y(new_n27_));
  OA211x2_ASAP7_75t_R  g009(.A1(new_n23_), .A2(\B[0] ), .B(new_n26_), .C(new_n27_), .Y(new_n28_));
  AO22x1_ASAP7_75t_R   g010(.A1(new_n25_), .A2(new_n28_), .B1(\B[4] ), .B2(\B[8] ), .Y(new_n29_));
  INVx1_ASAP7_75t_R    g011(.A(\B[8] ), .Y(new_n30_));
  INVx1_ASAP7_75t_R    g012(.A(\B[2] ), .Y(new_n31_));
  AND4x2_ASAP7_75t_R   g013(.A(new_n31_), .B(new_n27_), .C(\B[1] ), .D(\B[5] ), .Y(new_n32_));
  AO21x1_ASAP7_75t_R   g014(.A1(new_n22_), .A2(\B[7] ), .B(new_n32_), .Y(new_n33_));
  INVx1_ASAP7_75t_R    g015(.A(\B[3] ), .Y(new_n34_));
  AND3x1_ASAP7_75t_R   g016(.A(new_n34_), .B(\B[4] ), .C(\B[7] ), .Y(new_n35_));
  AO21x1_ASAP7_75t_R   g017(.A1(new_n33_), .A2(\B[3] ), .B(new_n35_), .Y(new_n36_));
  AND3x1_ASAP7_75t_R   g018(.A(new_n22_), .B(\B[5] ), .C(\B[8] ), .Y(new_n37_));
  AO21x1_ASAP7_75t_R   g019(.A1(new_n36_), .A2(new_n30_), .B(new_n37_), .Y(new_n38_));
  AO21x1_ASAP7_75t_R   g020(.A1(new_n21_), .A2(new_n29_), .B(new_n38_), .Y(new_n39_));
  OR3x1_ASAP7_75t_R    g021(.A(new_n26_), .B(new_n20_), .C(\B[5] ), .Y(new_n40_));
  OA211x2_ASAP7_75t_R  g022(.A1(\B[4] ), .A2(new_n27_), .B(new_n31_), .C(\B[1] ), .Y(new_n41_));
  AO21x1_ASAP7_75t_R   g023(.A1(new_n34_), .A2(new_n30_), .B(new_n22_), .Y(new_n42_));
  INVx1_ASAP7_75t_R    g024(.A(\B[1] ), .Y(new_n43_));
  AND4x2_ASAP7_75t_R   g025(.A(new_n43_), .B(new_n27_), .C(new_n30_), .D(\B[2] ), .Y(new_n44_));
  AOI211x1_ASAP7_75t_R g026(.A1(new_n41_), .A2(new_n42_), .B(\B[9] ), .C(new_n44_), .Y(new_n45_));
  OR3x1_ASAP7_75t_R    g027(.A(new_n45_), .B(new_n21_), .C(\B[6] ), .Y(new_n46_));
  NAND2x1_ASAP7_75t_R  g028(.A(new_n40_), .B(new_n46_), .Y(new_n47_));
  AO21x1_ASAP7_75t_R   g029(.A1(new_n39_), .A2(new_n20_), .B(new_n47_), .Y(new_n48_));
  AND2x2_ASAP7_75t_R   g030(.A(new_n26_), .B(\B[7] ), .Y(new_n49_));
  XOR2x2_ASAP7_75t_R   g031(.A(\B[2] ), .B(\B[3] ), .Y(new_n50_));
  NOR2x1_ASAP7_75t_R   g032(.A(\B[8] ), .B(\B[9] ), .Y(new_n51_));
  AOI21x1_ASAP7_75t_R  g033(.A1(new_n51_), .A2(new_n50_), .B(\B[10] ), .Y(new_n52_));
  NAND2x1_ASAP7_75t_R  g034(.A(\B[8] ), .B(\B[10] ), .Y(new_n53_));
  OAI22x1_ASAP7_75t_R  g035(.A1(new_n20_), .A2(new_n53_), .B1(new_n52_), .B2(\B[7] ), .Y(new_n54_));
  AO22x1_ASAP7_75t_R   g036(.A1(new_n54_), .A2(\B[6] ), .B1(\B[10] ), .B2(new_n49_), .Y(new_n55_));
  AO21x1_ASAP7_75t_R   g037(.A1(new_n48_), .A2(new_n19_), .B(new_n55_), .Y(\M[0] ));
  INVx1_ASAP7_75t_R    g038(.A(\B[0] ), .Y(new_n57_));
  AO21x1_ASAP7_75t_R   g039(.A1(\B[1] ), .A2(\B[2] ), .B(new_n57_), .Y(new_n58_));
  OA211x2_ASAP7_75t_R  g040(.A1(\B[0] ), .A2(new_n31_), .B(new_n27_), .C(\B[4] ), .Y(new_n59_));
  NOR2x1_ASAP7_75t_R   g041(.A(\B[4] ), .B(\B[9] ), .Y(new_n60_));
  AO21x1_ASAP7_75t_R   g042(.A1(new_n31_), .A2(new_n27_), .B(new_n60_), .Y(new_n61_));
  AO22x1_ASAP7_75t_R   g043(.A1(new_n61_), .A2(new_n43_), .B1(\B[8] ), .B2(new_n20_), .Y(new_n62_));
  AO21x1_ASAP7_75t_R   g044(.A1(new_n58_), .A2(new_n59_), .B(new_n62_), .Y(new_n63_));
  AND2x2_ASAP7_75t_R   g045(.A(\B[3] ), .B(\B[4] ), .Y(new_n64_));
  INVx1_ASAP7_75t_R    g046(.A(new_n64_), .Y(new_n65_));
  AND3x1_ASAP7_75t_R   g047(.A(new_n65_), .B(\B[7] ), .C(new_n51_), .Y(new_n66_));
  AO21x1_ASAP7_75t_R   g048(.A1(new_n27_), .A2(\B[9] ), .B(new_n66_), .Y(new_n67_));
  AOI21x1_ASAP7_75t_R  g049(.A1(new_n26_), .A2(new_n63_), .B(new_n67_), .Y(new_n68_));
  AND2x2_ASAP7_75t_R   g050(.A(\B[1] ), .B(\B[2] ), .Y(new_n69_));
  NOR2x1_ASAP7_75t_R   g051(.A(\B[4] ), .B(\B[6] ), .Y(new_n70_));
  AND3x1_ASAP7_75t_R   g052(.A(new_n70_), .B(new_n27_), .C(new_n69_), .Y(new_n71_));
  OA211x2_ASAP7_75t_R  g053(.A1(\B[7] ), .A2(new_n69_), .B(new_n51_), .C(\B[4] ), .Y(new_n72_));
  OAI21x1_ASAP7_75t_R  g054(.A1(new_n71_), .A2(new_n72_), .B(\B[3] ), .Y(new_n73_));
  AND2x2_ASAP7_75t_R   g055(.A(new_n27_), .B(\B[9] ), .Y(new_n74_));
  OR4x2_ASAP7_75t_R    g056(.A(new_n74_), .B(new_n26_), .C(new_n51_), .D(new_n60_), .Y(new_n75_));
  AO21x1_ASAP7_75t_R   g057(.A1(new_n73_), .A2(new_n75_), .B(new_n21_), .Y(new_n76_));
  AND3x1_ASAP7_75t_R   g058(.A(new_n22_), .B(new_n20_), .C(\B[8] ), .Y(new_n77_));
  OAI21x1_ASAP7_75t_R  g059(.A1(new_n74_), .A2(new_n77_), .B(new_n26_), .Y(new_n78_));
  OA211x2_ASAP7_75t_R  g060(.A1(new_n68_), .A2(\B[5] ), .B(new_n76_), .C(new_n78_), .Y(new_n79_));
  OR4x2_ASAP7_75t_R    g061(.A(new_n53_), .B(new_n26_), .C(new_n27_), .D(\B[9] ), .Y(new_n80_));
  AND3x1_ASAP7_75t_R   g062(.A(new_n22_), .B(new_n20_), .C(\B[6] ), .Y(new_n81_));
  AND3x1_ASAP7_75t_R   g063(.A(new_n43_), .B(new_n26_), .C(\B[5] ), .Y(new_n82_));
  OAI21x1_ASAP7_75t_R  g064(.A1(new_n81_), .A2(new_n82_), .B(new_n34_), .Y(new_n83_));
  AND2x2_ASAP7_75t_R   g065(.A(new_n34_), .B(\B[5] ), .Y(new_n84_));
  AO21x1_ASAP7_75t_R   g066(.A1(new_n26_), .A2(new_n84_), .B(new_n81_), .Y(new_n85_));
  AND4x2_ASAP7_75t_R   g067(.A(new_n64_), .B(\B[2] ), .C(\B[6] ), .D(new_n20_), .Y(new_n86_));
  AOI21x1_ASAP7_75t_R  g068(.A1(new_n31_), .A2(new_n85_), .B(new_n86_), .Y(new_n87_));
  AO21x1_ASAP7_75t_R   g069(.A1(new_n87_), .A2(new_n83_), .B(\B[7] ), .Y(new_n88_));
  AO21x1_ASAP7_75t_R   g070(.A1(\B[6] ), .A2(\B[7] ), .B(\B[8] ), .Y(new_n89_));
  AO21x1_ASAP7_75t_R   g071(.A1(new_n88_), .A2(new_n19_), .B(new_n89_), .Y(new_n90_));
  OA211x2_ASAP7_75t_R  g072(.A1(new_n79_), .A2(\B[10] ), .B(new_n80_), .C(new_n90_), .Y(\M[1] ));
  AND2x2_ASAP7_75t_R   g073(.A(new_n22_), .B(\B[5] ), .Y(new_n92_));
  AND4x2_ASAP7_75t_R   g074(.A(new_n34_), .B(new_n26_), .C(\B[0] ), .D(\B[4] ), .Y(new_n93_));
  AO21x1_ASAP7_75t_R   g075(.A1(\B[3] ), .A2(new_n92_), .B(new_n93_), .Y(new_n94_));
  OA21x2_ASAP7_75t_R   g076(.A1(new_n57_), .A2(new_n43_), .B(new_n64_), .Y(new_n95_));
  OA21x2_ASAP7_75t_R   g077(.A1(new_n95_), .A2(new_n70_), .B(new_n21_), .Y(new_n96_));
  AO21x1_ASAP7_75t_R   g078(.A1(new_n94_), .A2(\B[1] ), .B(new_n96_), .Y(new_n97_));
  AND3x1_ASAP7_75t_R   g079(.A(new_n31_), .B(new_n26_), .C(\B[3] ), .Y(new_n98_));
  OA21x2_ASAP7_75t_R   g080(.A1(new_n98_), .A2(new_n84_), .B(\B[4] ), .Y(new_n99_));
  AO21x1_ASAP7_75t_R   g081(.A1(new_n97_), .A2(\B[2] ), .B(new_n99_), .Y(new_n100_));
  AND2x2_ASAP7_75t_R   g082(.A(\B[5] ), .B(\B[6] ), .Y(new_n101_));
  AND3x1_ASAP7_75t_R   g083(.A(new_n21_), .B(\B[2] ), .C(\B[6] ), .Y(new_n102_));
  OA21x2_ASAP7_75t_R   g084(.A1(new_n82_), .A2(new_n102_), .B(new_n64_), .Y(new_n103_));
  AO21x1_ASAP7_75t_R   g085(.A1(new_n65_), .A2(new_n101_), .B(new_n103_), .Y(new_n104_));
  AO21x1_ASAP7_75t_R   g086(.A1(new_n100_), .A2(new_n27_), .B(new_n104_), .Y(new_n105_));
  AND2x2_ASAP7_75t_R   g087(.A(\B[4] ), .B(\B[5] ), .Y(new_n106_));
  AND2x2_ASAP7_75t_R   g088(.A(\B[6] ), .B(\B[7] ), .Y(new_n107_));
  OA21x2_ASAP7_75t_R   g089(.A1(new_n22_), .A2(new_n21_), .B(new_n107_), .Y(new_n108_));
  AND3x1_ASAP7_75t_R   g090(.A(new_n31_), .B(new_n27_), .C(\B[6] ), .Y(new_n109_));
  AO21x1_ASAP7_75t_R   g091(.A1(\B[3] ), .A2(new_n49_), .B(new_n109_), .Y(new_n110_));
  AO21x1_ASAP7_75t_R   g092(.A1(new_n110_), .A2(new_n106_), .B(new_n108_), .Y(new_n111_));
  AO21x1_ASAP7_75t_R   g093(.A1(new_n105_), .A2(new_n30_), .B(new_n111_), .Y(new_n112_));
  AND3x1_ASAP7_75t_R   g094(.A(new_n106_), .B(\B[6] ), .C(new_n27_), .Y(new_n113_));
  OA21x2_ASAP7_75t_R   g095(.A1(new_n113_), .A2(new_n49_), .B(\B[8] ), .Y(new_n114_));
  AO21x1_ASAP7_75t_R   g096(.A1(new_n112_), .A2(new_n20_), .B(new_n114_), .Y(new_n115_));
  AND3x1_ASAP7_75t_R   g097(.A(new_n30_), .B(\B[5] ), .C(\B[9] ), .Y(new_n116_));
  AO21x1_ASAP7_75t_R   g098(.A1(\B[8] ), .A2(\B[10] ), .B(new_n116_), .Y(new_n117_));
  NAND2x1_ASAP7_75t_R  g099(.A(\B[5] ), .B(\B[7] ), .Y(new_n118_));
  AO21x1_ASAP7_75t_R   g100(.A1(new_n118_), .A2(\B[8] ), .B(\B[10] ), .Y(new_n119_));
  AO22x1_ASAP7_75t_R   g101(.A1(new_n117_), .A2(new_n107_), .B1(\B[9] ), .B2(new_n119_), .Y(new_n120_));
  AO21x1_ASAP7_75t_R   g102(.A1(new_n115_), .A2(new_n19_), .B(new_n120_), .Y(\M[2] ));
  AND3x1_ASAP7_75t_R   g103(.A(\B[5] ), .B(\B[6] ), .C(\B[7] ), .Y(new_n122_));
  AND3x1_ASAP7_75t_R   g104(.A(new_n31_), .B(\B[4] ), .C(\B[8] ), .Y(new_n123_));
  AND3x1_ASAP7_75t_R   g105(.A(new_n22_), .B(new_n27_), .C(new_n30_), .Y(new_n124_));
  AND3x1_ASAP7_75t_R   g106(.A(new_n124_), .B(new_n21_), .C(new_n26_), .Y(new_n125_));
  AOI21x1_ASAP7_75t_R  g107(.A1(new_n122_), .A2(new_n123_), .B(new_n125_), .Y(new_n126_));
  NAND2x1_ASAP7_75t_R  g108(.A(new_n20_), .B(new_n19_), .Y(new_n127_));
  OR3x1_ASAP7_75t_R    g109(.A(new_n126_), .B(\B[3] ), .C(new_n127_), .Y(\M[3] ));
  AO21x1_ASAP7_75t_R   g110(.A1(new_n69_), .A2(new_n27_), .B(new_n101_), .Y(new_n129_));
  NOR2x1_ASAP7_75t_R   g111(.A(\B[5] ), .B(\B[7] ), .Y(new_n130_));
  AO21x1_ASAP7_75t_R   g112(.A1(new_n129_), .A2(\B[3] ), .B(new_n130_), .Y(new_n131_));
  AOI22x1_ASAP7_75t_R  g113(.A1(\B[6] ), .A2(new_n27_), .B1(new_n131_), .B2(\B[4] ), .Y(new_n132_));
  AND4x2_ASAP7_75t_R   g114(.A(new_n21_), .B(new_n26_), .C(\B[0] ), .D(\B[1] ), .Y(new_n133_));
  OA211x2_ASAP7_75t_R  g115(.A1(new_n113_), .A2(new_n133_), .B(\B[2] ), .C(\B[3] ), .Y(new_n134_));
  OA21x2_ASAP7_75t_R   g116(.A1(new_n132_), .A2(new_n134_), .B(new_n30_), .Y(new_n135_));
  AND3x1_ASAP7_75t_R   g117(.A(new_n101_), .B(\B[7] ), .C(\B[8] ), .Y(new_n136_));
  INVx1_ASAP7_75t_R    g118(.A(new_n136_), .Y(new_n137_));
  AND2x2_ASAP7_75t_R   g119(.A(\B[3] ), .B(\B[8] ), .Y(new_n138_));
  AO21x1_ASAP7_75t_R   g120(.A1(\B[2] ), .A2(new_n34_), .B(new_n138_), .Y(new_n139_));
  AND3x1_ASAP7_75t_R   g121(.A(new_n107_), .B(new_n106_), .C(new_n20_), .Y(new_n140_));
  AO22x1_ASAP7_75t_R   g122(.A1(new_n137_), .A2(\B[9] ), .B1(new_n139_), .B2(new_n140_), .Y(new_n141_));
  OAI21x1_ASAP7_75t_R  g123(.A1(new_n141_), .A2(new_n135_), .B(new_n19_), .Y(\E[0] ));
  AND4x2_ASAP7_75t_R   g124(.A(new_n30_), .B(\B[0] ), .C(\B[1] ), .D(\B[3] ), .Y(new_n143_));
  AO21x1_ASAP7_75t_R   g125(.A1(new_n143_), .A2(new_n130_), .B(new_n136_), .Y(new_n144_));
  AO22x1_ASAP7_75t_R   g126(.A1(new_n144_), .A2(\B[2] ), .B1(new_n122_), .B2(new_n138_), .Y(new_n145_));
  AND3x1_ASAP7_75t_R   g127(.A(new_n64_), .B(new_n101_), .C(\B[2] ), .Y(new_n146_));
  INVx1_ASAP7_75t_R    g128(.A(new_n146_), .Y(new_n147_));
  OA211x2_ASAP7_75t_R  g129(.A1(\B[5] ), .A2(\B[6] ), .B(new_n27_), .C(new_n30_), .Y(new_n148_));
  AO21x1_ASAP7_75t_R   g130(.A1(new_n147_), .A2(new_n148_), .B(new_n127_), .Y(new_n149_));
  AO21x1_ASAP7_75t_R   g131(.A1(new_n145_), .A2(\B[4] ), .B(new_n149_), .Y(\E[1] ));
  OR4x2_ASAP7_75t_R    g132(.A(new_n146_), .B(\B[7] ), .C(\B[8] ), .D(new_n127_), .Y(\E[2] ));
endmodule


