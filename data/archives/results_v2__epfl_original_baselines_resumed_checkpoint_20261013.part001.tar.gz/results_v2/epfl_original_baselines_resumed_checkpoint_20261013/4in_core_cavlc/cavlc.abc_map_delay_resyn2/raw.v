// Benchmark "/home/flynn/workplace/MIGBalance/results_v2/epfl_original_baselines_resumed_checkpoint_20261013/4in_core_cavlc/cavlc.resyn2" written by ABC on Tue Oct 13 18:47:33 2026

module \/home/flynn/workplace/MIGBalance/results_v2/epfl_original_baselines_resumed_checkpoint_20261013/4in_core_cavlc/cavlc.resyn2  ( 
    \totalcoeffs[0] , \totalcoeffs[1] , \totalcoeffs[2] , \totalcoeffs[3] ,
    \totalcoeffs[4] , \ctable[0] , \ctable[1] , \ctable[2] ,
    \trailingones[0] , \trailingones[1] ,
    \coeff_token[0] , \coeff_token[1] , \coeff_token[2] , \coeff_token[3] ,
    \coeff_token[4] , \coeff_token[5] , \ctoken_len[0] , \ctoken_len[1] ,
    \ctoken_len[2] , \ctoken_len[3] , \ctoken_len[4]   );
  input  \totalcoeffs[0] , \totalcoeffs[1] , \totalcoeffs[2] ,
    \totalcoeffs[3] , \totalcoeffs[4] , \ctable[0] , \ctable[1] ,
    \ctable[2] , \trailingones[0] , \trailingones[1] ;
  output \coeff_token[0] , \coeff_token[1] , \coeff_token[2] ,
    \coeff_token[3] , \coeff_token[4] , \coeff_token[5] , \ctoken_len[0] ,
    \ctoken_len[1] , \ctoken_len[2] , \ctoken_len[3] , \ctoken_len[4] ;
  wire new_n22_, new_n23_, new_n24_, new_n25_, new_n26_, new_n27_, new_n28_,
    new_n29_, new_n30_, new_n31_, new_n32_, new_n33_, new_n34_, new_n35_,
    new_n36_, new_n37_, new_n38_, new_n39_, new_n40_, new_n41_, new_n42_,
    new_n43_, new_n44_, new_n45_, new_n46_, new_n47_, new_n48_, new_n49_,
    new_n50_, new_n51_, new_n52_, new_n53_, new_n54_, new_n55_, new_n56_,
    new_n57_, new_n58_, new_n59_, new_n60_, new_n61_, new_n62_, new_n63_,
    new_n64_, new_n65_, new_n66_, new_n67_, new_n68_, new_n69_, new_n70_,
    new_n71_, new_n72_, new_n73_, new_n74_, new_n75_, new_n76_, new_n77_,
    new_n78_, new_n79_, new_n80_, new_n81_, new_n82_, new_n83_, new_n84_,
    new_n85_, new_n86_, new_n87_, new_n88_, new_n89_, new_n90_, new_n91_,
    new_n92_, new_n93_, new_n94_, new_n95_, new_n96_, new_n97_, new_n98_,
    new_n99_, new_n100_, new_n101_, new_n102_, new_n103_, new_n104_,
    new_n106_, new_n107_, new_n108_, new_n109_, new_n110_, new_n111_,
    new_n112_, new_n113_, new_n114_, new_n115_, new_n116_, new_n117_,
    new_n118_, new_n119_, new_n120_, new_n121_, new_n122_, new_n123_,
    new_n124_, new_n125_, new_n126_, new_n127_, new_n128_, new_n129_,
    new_n130_, new_n131_, new_n132_, new_n133_, new_n134_, new_n135_,
    new_n136_, new_n137_, new_n138_, new_n139_, new_n140_, new_n141_,
    new_n142_, new_n143_, new_n144_, new_n145_, new_n146_, new_n147_,
    new_n148_, new_n149_, new_n150_, new_n151_, new_n152_, new_n153_,
    new_n154_, new_n155_, new_n156_, new_n157_, new_n158_, new_n159_,
    new_n160_, new_n161_, new_n162_, new_n163_, new_n164_, new_n165_,
    new_n166_, new_n167_, new_n168_, new_n169_, new_n170_, new_n171_,
    new_n172_, new_n173_, new_n174_, new_n175_, new_n177_, new_n178_,
    new_n179_, new_n180_, new_n181_, new_n182_, new_n183_, new_n184_,
    new_n185_, new_n186_, new_n187_, new_n188_, new_n189_, new_n190_,
    new_n191_, new_n192_, new_n193_, new_n194_, new_n195_, new_n196_,
    new_n197_, new_n198_, new_n199_, new_n200_, new_n201_, new_n202_,
    new_n203_, new_n204_, new_n205_, new_n206_, new_n207_, new_n208_,
    new_n209_, new_n210_, new_n211_, new_n212_, new_n213_, new_n214_,
    new_n215_, new_n216_, new_n217_, new_n218_, new_n219_, new_n220_,
    new_n221_, new_n222_, new_n223_, new_n224_, new_n225_, new_n226_,
    new_n227_, new_n228_, new_n229_, new_n230_, new_n232_, new_n233_,
    new_n234_, new_n235_, new_n236_, new_n237_, new_n238_, new_n239_,
    new_n240_, new_n241_, new_n242_, new_n243_, new_n244_, new_n245_,
    new_n246_, new_n247_, new_n248_, new_n249_, new_n250_, new_n251_,
    new_n252_, new_n253_, new_n254_, new_n255_, new_n256_, new_n257_,
    new_n258_, new_n259_, new_n260_, new_n261_, new_n262_, new_n263_,
    new_n264_, new_n265_, new_n266_, new_n267_, new_n268_, new_n269_,
    new_n270_, new_n271_, new_n272_, new_n273_, new_n274_, new_n276_,
    new_n277_, new_n278_, new_n279_, new_n280_, new_n282_, new_n283_,
    new_n285_, new_n286_, new_n287_, new_n288_, new_n289_, new_n290_,
    new_n291_, new_n292_, new_n293_, new_n294_, new_n295_, new_n296_,
    new_n297_, new_n298_, new_n299_, new_n300_, new_n301_, new_n302_,
    new_n303_, new_n304_, new_n305_, new_n306_, new_n307_, new_n308_,
    new_n309_, new_n310_, new_n311_, new_n312_, new_n313_, new_n314_,
    new_n315_, new_n316_, new_n317_, new_n318_, new_n319_, new_n320_,
    new_n321_, new_n322_, new_n323_, new_n324_, new_n325_, new_n326_,
    new_n327_, new_n328_, new_n330_, new_n331_, new_n332_, new_n333_,
    new_n334_, new_n335_, new_n336_, new_n337_, new_n338_, new_n339_,
    new_n340_, new_n341_, new_n342_, new_n343_, new_n344_, new_n345_,
    new_n346_, new_n347_, new_n348_, new_n349_, new_n350_, new_n351_,
    new_n352_, new_n353_, new_n354_, new_n355_, new_n356_, new_n357_,
    new_n358_, new_n359_, new_n360_, new_n361_, new_n362_, new_n363_,
    new_n364_, new_n365_, new_n366_, new_n367_, new_n368_, new_n369_,
    new_n370_, new_n371_, new_n372_, new_n373_, new_n374_, new_n375_,
    new_n376_, new_n377_, new_n379_, new_n380_, new_n381_, new_n382_,
    new_n383_, new_n384_, new_n385_, new_n386_, new_n387_, new_n388_,
    new_n389_, new_n390_, new_n391_, new_n392_, new_n393_, new_n394_,
    new_n395_, new_n396_, new_n397_, new_n398_, new_n399_, new_n400_,
    new_n401_, new_n402_, new_n403_, new_n404_, new_n405_, new_n406_,
    new_n407_, new_n408_, new_n409_, new_n411_, new_n412_, new_n413_,
    new_n414_, new_n415_, new_n416_, new_n417_, new_n418_, new_n419_,
    new_n420_, new_n421_, new_n422_, new_n423_, new_n424_, new_n425_,
    new_n426_, new_n427_, new_n428_, new_n429_, new_n430_, new_n432_,
    new_n433_, new_n434_;
  INVx1_ASAP7_75t_R    g000(.A(\totalcoeffs[4] ), .Y(new_n22_));
  INVx1_ASAP7_75t_R    g001(.A(\totalcoeffs[1] ), .Y(new_n23_));
  INVx1_ASAP7_75t_R    g002(.A(\ctable[2] ), .Y(new_n24_));
  INVx1_ASAP7_75t_R    g003(.A(\trailingones[0] ), .Y(new_n25_));
  OR3x1_ASAP7_75t_R    g004(.A(new_n24_), .B(new_n25_), .C(\ctable[0] ), .Y(new_n26_));
  NAND2x1_ASAP7_75t_R  g005(.A(\trailingones[1] ), .B(new_n24_), .Y(new_n27_));
  AO21x1_ASAP7_75t_R   g006(.A1(new_n26_), .A2(new_n27_), .B(new_n23_), .Y(new_n28_));
  NOR2x1_ASAP7_75t_R   g007(.A(\ctable[0] ), .B(\trailingones[1] ), .Y(new_n29_));
  INVx1_ASAP7_75t_R    g008(.A(new_n29_), .Y(new_n30_));
  AO21x1_ASAP7_75t_R   g009(.A1(\totalcoeffs[1] ), .A2(new_n24_), .B(new_n30_), .Y(new_n31_));
  INVx1_ASAP7_75t_R    g010(.A(\totalcoeffs[2] ), .Y(new_n32_));
  NAND2x1_ASAP7_75t_R  g011(.A(\totalcoeffs[0] ), .B(new_n32_), .Y(new_n33_));
  AO21x1_ASAP7_75t_R   g012(.A1(new_n28_), .A2(new_n31_), .B(new_n33_), .Y(new_n34_));
  NOR2x1_ASAP7_75t_R   g013(.A(\totalcoeffs[0] ), .B(\totalcoeffs[1] ), .Y(new_n35_));
  INVx1_ASAP7_75t_R    g014(.A(new_n35_), .Y(new_n36_));
  INVx1_ASAP7_75t_R    g015(.A(\trailingones[1] ), .Y(new_n37_));
  NAND2x1_ASAP7_75t_R  g016(.A(\totalcoeffs[2] ), .B(new_n37_), .Y(new_n38_));
  OR3x1_ASAP7_75t_R    g017(.A(new_n26_), .B(new_n36_), .C(new_n38_), .Y(new_n39_));
  AO21x1_ASAP7_75t_R   g018(.A1(new_n34_), .A2(new_n39_), .B(\totalcoeffs[3] ), .Y(new_n40_));
  OA21x2_ASAP7_75t_R   g019(.A1(new_n37_), .A2(\totalcoeffs[0] ), .B(\totalcoeffs[1] ), .Y(new_n41_));
  AND2x2_ASAP7_75t_R   g020(.A(new_n23_), .B(\trailingones[1] ), .Y(new_n42_));
  OR4x2_ASAP7_75t_R    g021(.A(new_n42_), .B(new_n41_), .C(\totalcoeffs[3] ), .D(\ctable[0] ), .Y(new_n43_));
  INVx1_ASAP7_75t_R    g022(.A(\totalcoeffs[0] ), .Y(new_n44_));
  OA21x2_ASAP7_75t_R   g023(.A1(new_n44_), .A2(\trailingones[1] ), .B(new_n23_), .Y(new_n45_));
  AND2x2_ASAP7_75t_R   g024(.A(new_n37_), .B(\totalcoeffs[1] ), .Y(new_n46_));
  OR3x1_ASAP7_75t_R    g025(.A(new_n46_), .B(\ctable[2] ), .C(new_n45_), .Y(new_n47_));
  AO21x1_ASAP7_75t_R   g026(.A1(new_n43_), .A2(new_n47_), .B(\totalcoeffs[2] ), .Y(new_n48_));
  NAND2x1_ASAP7_75t_R  g027(.A(\totalcoeffs[1] ), .B(\totalcoeffs[2] ), .Y(new_n49_));
  INVx1_ASAP7_75t_R    g028(.A(\ctable[0] ), .Y(new_n50_));
  AO21x1_ASAP7_75t_R   g029(.A1(new_n32_), .A2(new_n50_), .B(\totalcoeffs[0] ), .Y(new_n51_));
  AO21x1_ASAP7_75t_R   g030(.A1(new_n51_), .A2(new_n49_), .B(\trailingones[1] ), .Y(new_n52_));
  INVx1_ASAP7_75t_R    g031(.A(\totalcoeffs[3] ), .Y(new_n53_));
  AO21x1_ASAP7_75t_R   g032(.A1(new_n32_), .A2(new_n53_), .B(new_n37_), .Y(new_n54_));
  NAND2x1_ASAP7_75t_R  g033(.A(\totalcoeffs[0] ), .B(\totalcoeffs[3] ), .Y(new_n55_));
  AO21x1_ASAP7_75t_R   g034(.A1(new_n54_), .A2(new_n55_), .B(\totalcoeffs[1] ), .Y(new_n56_));
  OA21x2_ASAP7_75t_R   g035(.A1(new_n23_), .A2(\totalcoeffs[3] ), .B(new_n56_), .Y(new_n57_));
  AO21x1_ASAP7_75t_R   g036(.A1(new_n57_), .A2(new_n52_), .B(\ctable[2] ), .Y(new_n58_));
  AO21x1_ASAP7_75t_R   g037(.A1(new_n58_), .A2(new_n48_), .B(\trailingones[0] ), .Y(new_n59_));
  AO21x1_ASAP7_75t_R   g038(.A1(new_n59_), .A2(new_n40_), .B(\ctable[1] ), .Y(new_n60_));
  INVx1_ASAP7_75t_R    g039(.A(\ctable[1] ), .Y(new_n61_));
  NOR2x1_ASAP7_75t_R   g040(.A(\totalcoeffs[0] ), .B(\totalcoeffs[2] ), .Y(new_n62_));
  AOI21x1_ASAP7_75t_R  g041(.A1(new_n62_), .A2(new_n42_), .B(\ctable[0] ), .Y(new_n63_));
  NAND2x1_ASAP7_75t_R  g042(.A(\trailingones[1] ), .B(new_n44_), .Y(new_n64_));
  NAND2x1_ASAP7_75t_R  g043(.A(\totalcoeffs[0] ), .B(new_n37_), .Y(new_n65_));
  NAND2x1_ASAP7_75t_R  g044(.A(new_n64_), .B(new_n65_), .Y(new_n66_));
  OR3x1_ASAP7_75t_R    g045(.A(new_n23_), .B(new_n32_), .C(new_n50_), .Y(new_n67_));
  OA22x2_ASAP7_75t_R   g046(.A1(new_n61_), .A2(new_n63_), .B1(new_n66_), .B2(new_n67_), .Y(new_n68_));
  AO21x1_ASAP7_75t_R   g047(.A1(new_n64_), .A2(new_n23_), .B(\trailingones[0] ), .Y(new_n69_));
  NAND2x1_ASAP7_75t_R  g048(.A(\totalcoeffs[2] ), .B(new_n23_), .Y(new_n70_));
  OA21x2_ASAP7_75t_R   g049(.A1(new_n65_), .A2(new_n70_), .B(new_n69_), .Y(new_n71_));
  OA22x2_ASAP7_75t_R   g050(.A1(\ctable[0] ), .A2(new_n71_), .B1(new_n68_), .B2(new_n25_), .Y(new_n72_));
  AO21x1_ASAP7_75t_R   g051(.A1(new_n37_), .A2(\totalcoeffs[0] ), .B(\totalcoeffs[2] ), .Y(new_n73_));
  INVx1_ASAP7_75t_R    g052(.A(new_n73_), .Y(new_n74_));
  NAND2x1_ASAP7_75t_R  g053(.A(new_n53_), .B(new_n41_), .Y(new_n75_));
  AO21x1_ASAP7_75t_R   g054(.A1(new_n73_), .A2(new_n61_), .B(new_n50_), .Y(new_n76_));
  AO21x1_ASAP7_75t_R   g055(.A1(new_n75_), .A2(new_n74_), .B(new_n76_), .Y(new_n77_));
  AND2x2_ASAP7_75t_R   g056(.A(\totalcoeffs[2] ), .B(\trailingones[1] ), .Y(new_n78_));
  INVx1_ASAP7_75t_R    g057(.A(new_n78_), .Y(new_n79_));
  OR3x1_ASAP7_75t_R    g058(.A(new_n23_), .B(\totalcoeffs[2] ), .C(\trailingones[1] ), .Y(new_n80_));
  OR3x1_ASAP7_75t_R    g059(.A(new_n61_), .B(\totalcoeffs[0] ), .C(\totalcoeffs[3] ), .Y(new_n81_));
  AO21x1_ASAP7_75t_R   g060(.A1(new_n80_), .A2(new_n79_), .B(new_n81_), .Y(new_n82_));
  AO21x1_ASAP7_75t_R   g061(.A1(new_n77_), .A2(new_n82_), .B(new_n25_), .Y(new_n83_));
  NOR2x1_ASAP7_75t_R   g062(.A(\totalcoeffs[2] ), .B(\totalcoeffs[3] ), .Y(new_n84_));
  AND3x1_ASAP7_75t_R   g063(.A(new_n23_), .B(new_n25_), .C(new_n37_), .Y(new_n85_));
  AND3x1_ASAP7_75t_R   g064(.A(new_n85_), .B(new_n44_), .C(new_n84_), .Y(new_n86_));
  AND2x2_ASAP7_75t_R   g065(.A(new_n53_), .B(\totalcoeffs[2] ), .Y(new_n87_));
  AO22x1_ASAP7_75t_R   g066(.A1(\totalcoeffs[1] ), .A2(new_n25_), .B1(new_n42_), .B2(new_n87_), .Y(new_n88_));
  NOR2x1_ASAP7_75t_R   g067(.A(\totalcoeffs[1] ), .B(\trailingones[1] ), .Y(new_n89_));
  AO21x1_ASAP7_75t_R   g068(.A1(new_n32_), .A2(\ctable[1] ), .B(new_n53_), .Y(new_n90_));
  AO21x1_ASAP7_75t_R   g069(.A1(new_n90_), .A2(new_n89_), .B(new_n78_), .Y(new_n91_));
  AO22x1_ASAP7_75t_R   g070(.A1(new_n88_), .A2(new_n44_), .B1(new_n25_), .B2(new_n91_), .Y(new_n92_));
  AOI21x1_ASAP7_75t_R  g071(.A1(new_n50_), .A2(new_n92_), .B(new_n86_), .Y(new_n93_));
  OA211x2_ASAP7_75t_R  g072(.A1(new_n53_), .A2(new_n72_), .B(new_n93_), .C(new_n83_), .Y(new_n94_));
  OAI21x1_ASAP7_75t_R  g073(.A1(\ctable[2] ), .A2(new_n94_), .B(new_n60_), .Y(new_n95_));
  OA21x2_ASAP7_75t_R   g074(.A1(new_n25_), .A2(\ctable[1] ), .B(\ctable[0] ), .Y(new_n96_));
  AND2x2_ASAP7_75t_R   g075(.A(\totalcoeffs[4] ), .B(\trailingones[0] ), .Y(new_n97_));
  NOR2x1_ASAP7_75t_R   g076(.A(\ctable[1] ), .B(\trailingones[1] ), .Y(new_n98_));
  OA21x2_ASAP7_75t_R   g077(.A1(new_n97_), .A2(new_n98_), .B(new_n96_), .Y(new_n99_));
  NAND2x1_ASAP7_75t_R  g078(.A(\ctable[1] ), .B(new_n37_), .Y(new_n100_));
  OAI21x1_ASAP7_75t_R  g079(.A1(new_n22_), .A2(new_n37_), .B(new_n100_), .Y(new_n101_));
  OA211x2_ASAP7_75t_R  g080(.A1(new_n50_), .A2(new_n61_), .B(new_n101_), .C(new_n25_), .Y(new_n102_));
  AND4x2_ASAP7_75t_R   g081(.A(new_n62_), .B(new_n23_), .C(new_n53_), .D(new_n24_), .Y(new_n103_));
  OA21x2_ASAP7_75t_R   g082(.A1(new_n102_), .A2(new_n99_), .B(new_n103_), .Y(new_n104_));
  AO21x1_ASAP7_75t_R   g083(.A1(new_n95_), .A2(new_n22_), .B(new_n104_), .Y(\coeff_token[0] ));
  AND2x2_ASAP7_75t_R   g084(.A(new_n44_), .B(\ctable[0] ), .Y(new_n106_));
  AND2x2_ASAP7_75t_R   g085(.A(new_n25_), .B(\trailingones[1] ), .Y(new_n107_));
  AND2x2_ASAP7_75t_R   g086(.A(\ctable[1] ), .B(\trailingones[1] ), .Y(new_n108_));
  AO21x1_ASAP7_75t_R   g087(.A1(new_n50_), .A2(\trailingones[0] ), .B(new_n108_), .Y(new_n109_));
  AND2x2_ASAP7_75t_R   g088(.A(\ctable[1] ), .B(\trailingones[0] ), .Y(new_n110_));
  NOR2x1_ASAP7_75t_R   g089(.A(new_n44_), .B(new_n110_), .Y(new_n111_));
  AO22x1_ASAP7_75t_R   g090(.A1(new_n111_), .A2(new_n109_), .B1(new_n106_), .B2(new_n107_), .Y(new_n112_));
  AND2x2_ASAP7_75t_R   g091(.A(new_n50_), .B(\trailingones[0] ), .Y(new_n113_));
  AO21x1_ASAP7_75t_R   g092(.A1(new_n44_), .A2(\ctable[1] ), .B(\totalcoeffs[2] ), .Y(new_n114_));
  AO22x1_ASAP7_75t_R   g093(.A1(new_n113_), .A2(new_n114_), .B1(new_n61_), .B2(new_n25_), .Y(new_n115_));
  AO22x1_ASAP7_75t_R   g094(.A1(new_n112_), .A2(new_n32_), .B1(new_n37_), .B2(new_n115_), .Y(new_n116_));
  AND4x2_ASAP7_75t_R   g095(.A(new_n61_), .B(new_n37_), .C(\totalcoeffs[2] ), .D(\trailingones[0] ), .Y(new_n117_));
  NOR2x1_ASAP7_75t_R   g096(.A(\totalcoeffs[2] ), .B(\trailingones[0] ), .Y(new_n118_));
  AND3x1_ASAP7_75t_R   g097(.A(new_n118_), .B(new_n44_), .C(new_n37_), .Y(new_n119_));
  AND3x1_ASAP7_75t_R   g098(.A(\totalcoeffs[0] ), .B(\trailingones[0] ), .C(\trailingones[1] ), .Y(new_n120_));
  AND2x2_ASAP7_75t_R   g099(.A(new_n120_), .B(\totalcoeffs[2] ), .Y(new_n121_));
  OA21x2_ASAP7_75t_R   g100(.A1(new_n119_), .A2(new_n121_), .B(\ctable[0] ), .Y(new_n122_));
  OA21x2_ASAP7_75t_R   g101(.A1(new_n113_), .A2(new_n108_), .B(new_n44_), .Y(new_n123_));
  AO22x1_ASAP7_75t_R   g102(.A1(new_n29_), .A2(new_n25_), .B1(\trailingones[1] ), .B2(new_n110_), .Y(new_n124_));
  OA21x2_ASAP7_75t_R   g103(.A1(new_n123_), .A2(new_n124_), .B(\totalcoeffs[2] ), .Y(new_n125_));
  OA21x2_ASAP7_75t_R   g104(.A1(new_n125_), .A2(new_n122_), .B(new_n23_), .Y(new_n126_));
  AOI211x1_ASAP7_75t_R g105(.A1(\totalcoeffs[1] ), .A2(new_n116_), .B(new_n126_), .C(new_n117_), .Y(new_n127_));
  AND3x1_ASAP7_75t_R   g106(.A(new_n44_), .B(new_n23_), .C(new_n32_), .Y(new_n128_));
  AO21x1_ASAP7_75t_R   g107(.A1(\ctable[0] ), .A2(new_n25_), .B(new_n97_), .Y(new_n129_));
  AO22x1_ASAP7_75t_R   g108(.A1(new_n129_), .A2(new_n98_), .B1(\totalcoeffs[4] ), .B2(new_n108_), .Y(new_n130_));
  NAND2x1_ASAP7_75t_R  g109(.A(new_n128_), .B(new_n130_), .Y(new_n131_));
  OAI21x1_ASAP7_75t_R  g110(.A1(\totalcoeffs[4] ), .A2(new_n127_), .B(new_n131_), .Y(new_n132_));
  AND3x1_ASAP7_75t_R   g111(.A(new_n32_), .B(new_n25_), .C(\ctable[0] ), .Y(new_n133_));
  NAND2x1_ASAP7_75t_R  g112(.A(\trailingones[0] ), .B(new_n50_), .Y(new_n134_));
  NOR2x1_ASAP7_75t_R   g113(.A(\totalcoeffs[3] ), .B(\trailingones[0] ), .Y(new_n135_));
  INVx1_ASAP7_75t_R    g114(.A(new_n135_), .Y(new_n136_));
  AND3x1_ASAP7_75t_R   g115(.A(new_n136_), .B(\totalcoeffs[0] ), .C(new_n134_), .Y(new_n137_));
  OA21x2_ASAP7_75t_R   g116(.A1(new_n137_), .A2(new_n133_), .B(new_n23_), .Y(new_n138_));
  AO21x1_ASAP7_75t_R   g117(.A1(\totalcoeffs[3] ), .A2(\trailingones[0] ), .B(\totalcoeffs[2] ), .Y(new_n139_));
  AND2x2_ASAP7_75t_R   g118(.A(new_n139_), .B(new_n44_), .Y(new_n140_));
  AND3x1_ASAP7_75t_R   g119(.A(new_n32_), .B(\totalcoeffs[0] ), .C(\trailingones[0] ), .Y(new_n141_));
  NAND2x1_ASAP7_75t_R  g120(.A(\ctable[0] ), .B(new_n44_), .Y(new_n142_));
  NAND2x1_ASAP7_75t_R  g121(.A(\totalcoeffs[0] ), .B(new_n50_), .Y(new_n143_));
  NAND2x1_ASAP7_75t_R  g122(.A(new_n142_), .B(new_n143_), .Y(new_n144_));
  OA21x2_ASAP7_75t_R   g123(.A1(new_n144_), .A2(new_n141_), .B(\totalcoeffs[1] ), .Y(new_n145_));
  OA31x2_ASAP7_75t_R   g124(.A1(new_n140_), .A2(new_n138_), .A3(new_n145_), .B1(new_n61_), .Y(new_n146_));
  NOR2x1_ASAP7_75t_R   g125(.A(\totalcoeffs[1] ), .B(\trailingones[0] ), .Y(new_n147_));
  NAND2x1_ASAP7_75t_R  g126(.A(\trailingones[0] ), .B(new_n23_), .Y(new_n148_));
  OAI22x1_ASAP7_75t_R  g127(.A1(\totalcoeffs[2] ), .A2(new_n147_), .B1(new_n148_), .B2(new_n61_), .Y(new_n149_));
  NAND2x1_ASAP7_75t_R  g128(.A(\trailingones[0] ), .B(new_n44_), .Y(new_n150_));
  NAND2x1_ASAP7_75t_R  g129(.A(\totalcoeffs[0] ), .B(\totalcoeffs[1] ), .Y(new_n151_));
  OA21x2_ASAP7_75t_R   g130(.A1(\totalcoeffs[1] ), .A2(\ctable[1] ), .B(new_n151_), .Y(new_n152_));
  AND3x1_ASAP7_75t_R   g131(.A(new_n152_), .B(new_n32_), .C(new_n150_), .Y(new_n153_));
  AO21x1_ASAP7_75t_R   g132(.A1(\totalcoeffs[3] ), .A2(new_n149_), .B(new_n153_), .Y(new_n154_));
  AO21x1_ASAP7_75t_R   g133(.A1(new_n154_), .A2(new_n50_), .B(\trailingones[1] ), .Y(new_n155_));
  NAND2x1_ASAP7_75t_R  g134(.A(\totalcoeffs[1] ), .B(\ctable[0] ), .Y(new_n156_));
  OR4x2_ASAP7_75t_R    g135(.A(new_n53_), .B(\totalcoeffs[1] ), .C(\totalcoeffs[2] ), .D(\trailingones[0] ), .Y(new_n157_));
  AO21x1_ASAP7_75t_R   g136(.A1(new_n157_), .A2(new_n156_), .B(new_n44_), .Y(new_n158_));
  OR3x1_ASAP7_75t_R    g137(.A(new_n23_), .B(new_n32_), .C(new_n53_), .Y(new_n159_));
  AO21x1_ASAP7_75t_R   g138(.A1(new_n159_), .A2(new_n50_), .B(new_n84_), .Y(new_n160_));
  AO21x1_ASAP7_75t_R   g139(.A1(new_n158_), .A2(new_n160_), .B(new_n61_), .Y(new_n161_));
  NAND2x1_ASAP7_75t_R  g140(.A(\ctable[0] ), .B(new_n25_), .Y(new_n162_));
  OA21x2_ASAP7_75t_R   g141(.A1(new_n159_), .A2(new_n162_), .B(\trailingones[1] ), .Y(new_n163_));
  NAND2x1_ASAP7_75t_R  g142(.A(new_n163_), .B(new_n161_), .Y(new_n164_));
  OA211x2_ASAP7_75t_R  g143(.A1(new_n146_), .A2(new_n155_), .B(new_n164_), .C(new_n22_), .Y(new_n165_));
  AOI21x1_ASAP7_75t_R  g144(.A1(new_n53_), .A2(new_n132_), .B(new_n165_), .Y(new_n166_));
  OR3x1_ASAP7_75t_R    g145(.A(new_n38_), .B(\totalcoeffs[0] ), .C(\totalcoeffs[1] ), .Y(new_n167_));
  NAND2x1_ASAP7_75t_R  g146(.A(\totalcoeffs[1] ), .B(new_n37_), .Y(new_n168_));
  OR3x1_ASAP7_75t_R    g147(.A(new_n168_), .B(\totalcoeffs[2] ), .C(new_n25_), .Y(new_n169_));
  AO21x1_ASAP7_75t_R   g148(.A1(new_n36_), .A2(\totalcoeffs[2] ), .B(\trailingones[0] ), .Y(new_n170_));
  AO21x1_ASAP7_75t_R   g149(.A1(new_n74_), .A2(new_n151_), .B(new_n170_), .Y(new_n171_));
  AO21x1_ASAP7_75t_R   g150(.A1(new_n171_), .A2(new_n169_), .B(new_n24_), .Y(new_n172_));
  AND3x1_ASAP7_75t_R   g151(.A(new_n53_), .B(new_n50_), .C(new_n61_), .Y(new_n173_));
  NAND2x1_ASAP7_75t_R  g152(.A(new_n22_), .B(new_n173_), .Y(new_n174_));
  AO21x1_ASAP7_75t_R   g153(.A1(new_n172_), .A2(new_n167_), .B(new_n174_), .Y(new_n175_));
  OAI21x1_ASAP7_75t_R  g154(.A1(\ctable[2] ), .A2(new_n166_), .B(new_n175_), .Y(\coeff_token[1] ));
  INVx1_ASAP7_75t_R    g155(.A(new_n143_), .Y(new_n177_));
  XOR2x2_ASAP7_75t_R   g156(.A(\trailingones[0] ), .B(\trailingones[1] ), .Y(new_n178_));
  OAI21x1_ASAP7_75t_R  g157(.A1(new_n89_), .A2(new_n178_), .B(\totalcoeffs[2] ), .Y(new_n179_));
  INVx1_ASAP7_75t_R    g158(.A(new_n120_), .Y(new_n180_));
  NOR2x1_ASAP7_75t_R   g159(.A(\trailingones[0] ), .B(\trailingones[1] ), .Y(new_n181_));
  INVx1_ASAP7_75t_R    g160(.A(new_n181_), .Y(new_n182_));
  AND3x1_ASAP7_75t_R   g161(.A(new_n180_), .B(\ctable[0] ), .C(new_n182_), .Y(new_n183_));
  AO21x1_ASAP7_75t_R   g162(.A1(new_n79_), .A2(new_n50_), .B(new_n23_), .Y(new_n184_));
  OA21x2_ASAP7_75t_R   g163(.A1(new_n183_), .A2(new_n184_), .B(new_n179_), .Y(new_n185_));
  OA21x2_ASAP7_75t_R   g164(.A1(new_n53_), .A2(\totalcoeffs[1] ), .B(\ctable[0] ), .Y(new_n186_));
  OR3x1_ASAP7_75t_R    g165(.A(new_n182_), .B(\totalcoeffs[2] ), .C(new_n186_), .Y(new_n187_));
  OA21x2_ASAP7_75t_R   g166(.A1(new_n54_), .A2(new_n148_), .B(new_n187_), .Y(new_n188_));
  OAI22x1_ASAP7_75t_R  g167(.A1(new_n188_), .A2(new_n44_), .B1(new_n185_), .B2(\totalcoeffs[3] ), .Y(new_n189_));
  AO21x1_ASAP7_75t_R   g168(.A1(new_n23_), .A2(\trailingones[1] ), .B(new_n61_), .Y(new_n190_));
  NAND2x1_ASAP7_75t_R  g169(.A(new_n190_), .B(new_n168_), .Y(new_n191_));
  AND2x2_ASAP7_75t_R   g170(.A(\totalcoeffs[1] ), .B(\trailingones[1] ), .Y(new_n192_));
  OR2x4_ASAP7_75t_R    g171(.A(new_n192_), .B(new_n89_), .Y(new_n193_));
  AO22x1_ASAP7_75t_R   g172(.A1(new_n191_), .A2(\trailingones[0] ), .B1(new_n135_), .B2(new_n193_), .Y(new_n194_));
  INVx1_ASAP7_75t_R    g173(.A(new_n192_), .Y(new_n195_));
  OAI21x1_ASAP7_75t_R  g174(.A1(new_n32_), .A2(new_n195_), .B(new_n148_), .Y(new_n196_));
  AO22x1_ASAP7_75t_R   g175(.A1(new_n38_), .A2(\trailingones[0] ), .B1(\totalcoeffs[2] ), .B2(new_n181_), .Y(new_n197_));
  AO21x1_ASAP7_75t_R   g176(.A1(\ctable[1] ), .A2(new_n196_), .B(new_n197_), .Y(new_n198_));
  AO22x1_ASAP7_75t_R   g177(.A1(new_n194_), .A2(new_n32_), .B1(new_n198_), .B2(\totalcoeffs[3] ), .Y(new_n199_));
  AO22x1_ASAP7_75t_R   g178(.A1(new_n189_), .A2(new_n61_), .B1(new_n177_), .B2(new_n199_), .Y(new_n200_));
  OA21x2_ASAP7_75t_R   g179(.A1(new_n25_), .A2(\totalcoeffs[2] ), .B(\totalcoeffs[3] ), .Y(new_n201_));
  OA21x2_ASAP7_75t_R   g180(.A1(new_n32_), .A2(\ctable[0] ), .B(\totalcoeffs[3] ), .Y(new_n202_));
  OAI22x1_ASAP7_75t_R  g181(.A1(new_n201_), .A2(new_n50_), .B1(new_n202_), .B2(new_n25_), .Y(new_n203_));
  OR3x1_ASAP7_75t_R    g182(.A(new_n61_), .B(\totalcoeffs[3] ), .C(\ctable[0] ), .Y(new_n204_));
  INVx1_ASAP7_75t_R    g183(.A(new_n204_), .Y(new_n205_));
  AO22x1_ASAP7_75t_R   g184(.A1(new_n203_), .A2(\totalcoeffs[1] ), .B1(new_n147_), .B2(new_n205_), .Y(new_n206_));
  AO21x1_ASAP7_75t_R   g185(.A1(\totalcoeffs[1] ), .A2(\trailingones[0] ), .B(new_n61_), .Y(new_n207_));
  AO21x1_ASAP7_75t_R   g186(.A1(new_n207_), .A2(new_n37_), .B(\totalcoeffs[2] ), .Y(new_n208_));
  OR3x1_ASAP7_75t_R    g187(.A(new_n37_), .B(\totalcoeffs[1] ), .C(\trailingones[0] ), .Y(new_n209_));
  AOI21x1_ASAP7_75t_R  g188(.A1(new_n209_), .A2(new_n208_), .B(new_n53_), .Y(new_n210_));
  OA21x2_ASAP7_75t_R   g189(.A1(new_n25_), .A2(\ctable[1] ), .B(\totalcoeffs[2] ), .Y(new_n211_));
  OA211x2_ASAP7_75t_R  g190(.A1(new_n211_), .A2(new_n23_), .B(\ctable[0] ), .C(new_n139_), .Y(new_n212_));
  AO21x1_ASAP7_75t_R   g191(.A1(\totalcoeffs[3] ), .A2(new_n25_), .B(new_n46_), .Y(new_n213_));
  OA211x2_ASAP7_75t_R  g192(.A1(new_n53_), .A2(\trailingones[1] ), .B(new_n213_), .C(new_n61_), .Y(new_n214_));
  NAND2x1_ASAP7_75t_R  g193(.A(\ctable[1] ), .B(new_n25_), .Y(new_n215_));
  OR3x1_ASAP7_75t_R    g194(.A(new_n23_), .B(new_n37_), .C(\totalcoeffs[3] ), .Y(new_n216_));
  OAI21x1_ASAP7_75t_R  g195(.A1(new_n215_), .A2(new_n216_), .B(new_n22_), .Y(new_n217_));
  OR4x2_ASAP7_75t_R    g196(.A(new_n214_), .B(new_n210_), .C(new_n212_), .D(new_n217_), .Y(new_n218_));
  AO21x1_ASAP7_75t_R   g197(.A1(new_n37_), .A2(new_n206_), .B(new_n218_), .Y(new_n219_));
  AND2x2_ASAP7_75t_R   g198(.A(\trailingones[0] ), .B(\trailingones[1] ), .Y(new_n220_));
  AO21x1_ASAP7_75t_R   g199(.A1(\ctable[1] ), .A2(new_n25_), .B(new_n220_), .Y(new_n221_));
  OR3x1_ASAP7_75t_R    g200(.A(\totalcoeffs[1] ), .B(\totalcoeffs[2] ), .C(\totalcoeffs[3] ), .Y(new_n222_));
  AO21x1_ASAP7_75t_R   g201(.A1(new_n221_), .A2(new_n50_), .B(new_n222_), .Y(new_n223_));
  AOI21x1_ASAP7_75t_R  g202(.A1(\totalcoeffs[4] ), .A2(new_n223_), .B(\totalcoeffs[0] ), .Y(new_n224_));
  AO22x1_ASAP7_75t_R   g203(.A1(new_n219_), .A2(new_n224_), .B1(new_n22_), .B2(new_n200_), .Y(new_n225_));
  INVx1_ASAP7_75t_R    g204(.A(new_n65_), .Y(new_n226_));
  AO21x1_ASAP7_75t_R   g205(.A1(new_n220_), .A2(\ctable[2] ), .B(new_n44_), .Y(new_n227_));
  AO22x1_ASAP7_75t_R   g206(.A1(new_n226_), .A2(new_n147_), .B1(new_n41_), .B2(new_n227_), .Y(new_n228_));
  NOR2x1_ASAP7_75t_R   g207(.A(\ctable[0] ), .B(\ctable[1] ), .Y(new_n229_));
  AND3x1_ASAP7_75t_R   g208(.A(new_n84_), .B(new_n229_), .C(new_n22_), .Y(new_n230_));
  AO22x1_ASAP7_75t_R   g209(.A1(new_n225_), .A2(new_n24_), .B1(new_n228_), .B2(new_n230_), .Y(\coeff_token[2] ));
  OR3x1_ASAP7_75t_R    g210(.A(\ctable[0] ), .B(\trailingones[0] ), .C(\trailingones[1] ), .Y(new_n232_));
  AND3x1_ASAP7_75t_R   g211(.A(\ctable[0] ), .B(\trailingones[0] ), .C(\trailingones[1] ), .Y(new_n233_));
  NAND2x1_ASAP7_75t_R  g212(.A(new_n61_), .B(new_n233_), .Y(new_n234_));
  AO21x1_ASAP7_75t_R   g213(.A1(new_n234_), .A2(new_n232_), .B(new_n32_), .Y(new_n235_));
  AO21x1_ASAP7_75t_R   g214(.A1(new_n215_), .A2(new_n53_), .B(new_n96_), .Y(new_n236_));
  AO21x1_ASAP7_75t_R   g215(.A1(new_n235_), .A2(new_n236_), .B(new_n23_), .Y(new_n237_));
  NAND2x1_ASAP7_75t_R  g216(.A(\ctable[1] ), .B(new_n50_), .Y(new_n238_));
  OA22x2_ASAP7_75t_R   g217(.A1(new_n53_), .A2(\trailingones[1] ), .B1(new_n84_), .B2(new_n61_), .Y(new_n239_));
  OA22x2_ASAP7_75t_R   g218(.A1(new_n32_), .A2(new_n238_), .B1(new_n239_), .B2(\totalcoeffs[1] ), .Y(new_n240_));
  AOI21x1_ASAP7_75t_R  g219(.A1(new_n240_), .A2(new_n237_), .B(\totalcoeffs[4] ), .Y(new_n241_));
  AND2x2_ASAP7_75t_R   g220(.A(\ctable[0] ), .B(\ctable[1] ), .Y(new_n242_));
  NOR2x1_ASAP7_75t_R   g221(.A(\ctable[0] ), .B(new_n220_), .Y(new_n243_));
  INVx1_ASAP7_75t_R    g222(.A(new_n243_), .Y(new_n244_));
  AND2x2_ASAP7_75t_R   g223(.A(new_n53_), .B(\totalcoeffs[4] ), .Y(new_n245_));
  AND3x1_ASAP7_75t_R   g224(.A(new_n245_), .B(new_n23_), .C(new_n32_), .Y(new_n246_));
  OA211x2_ASAP7_75t_R  g225(.A1(new_n242_), .A2(new_n229_), .B(new_n246_), .C(new_n244_), .Y(new_n247_));
  OA21x2_ASAP7_75t_R   g226(.A1(new_n241_), .A2(new_n247_), .B(new_n44_), .Y(new_n248_));
  AO21x1_ASAP7_75t_R   g227(.A1(new_n136_), .A2(new_n134_), .B(new_n32_), .Y(new_n249_));
  OR3x1_ASAP7_75t_R    g228(.A(new_n50_), .B(new_n25_), .C(\totalcoeffs[2] ), .Y(new_n250_));
  AO21x1_ASAP7_75t_R   g229(.A1(new_n249_), .A2(new_n250_), .B(\trailingones[1] ), .Y(new_n251_));
  AO21x1_ASAP7_75t_R   g230(.A1(new_n107_), .A2(\ctable[0] ), .B(\totalcoeffs[3] ), .Y(new_n252_));
  AO21x1_ASAP7_75t_R   g231(.A1(new_n25_), .A2(\totalcoeffs[3] ), .B(\ctable[1] ), .Y(new_n253_));
  NAND2x1_ASAP7_75t_R  g232(.A(\totalcoeffs[3] ), .B(new_n50_), .Y(new_n254_));
  AOI22x1_ASAP7_75t_R  g233(.A1(new_n253_), .A2(new_n254_), .B1(new_n252_), .B2(new_n32_), .Y(new_n255_));
  AO21x1_ASAP7_75t_R   g234(.A1(new_n251_), .A2(new_n255_), .B(new_n23_), .Y(new_n256_));
  AND3x1_ASAP7_75t_R   g235(.A(new_n133_), .B(new_n23_), .C(new_n61_), .Y(new_n257_));
  OAI21x1_ASAP7_75t_R  g236(.A1(new_n205_), .A2(new_n257_), .B(new_n37_), .Y(new_n258_));
  AO21x1_ASAP7_75t_R   g237(.A1(new_n256_), .A2(new_n258_), .B(new_n44_), .Y(new_n259_));
  OR3x1_ASAP7_75t_R    g238(.A(new_n32_), .B(new_n53_), .C(\ctable[1] ), .Y(new_n260_));
  OA21x2_ASAP7_75t_R   g239(.A1(new_n84_), .A2(new_n238_), .B(new_n260_), .Y(new_n261_));
  NAND2x1_ASAP7_75t_R  g240(.A(\totalcoeffs[3] ), .B(new_n61_), .Y(new_n262_));
  AND3x1_ASAP7_75t_R   g241(.A(new_n50_), .B(new_n37_), .C(\ctable[1] ), .Y(new_n263_));
  INVx1_ASAP7_75t_R    g242(.A(new_n263_), .Y(new_n264_));
  AO21x1_ASAP7_75t_R   g243(.A1(new_n264_), .A2(new_n262_), .B(\trailingones[0] ), .Y(new_n265_));
  OA21x2_ASAP7_75t_R   g244(.A1(new_n37_), .A2(new_n261_), .B(new_n265_), .Y(new_n266_));
  AND2x2_ASAP7_75t_R   g245(.A(\totalcoeffs[1] ), .B(\trailingones[0] ), .Y(new_n267_));
  OA21x2_ASAP7_75t_R   g246(.A1(\ctable[1] ), .A2(\trailingones[0] ), .B(new_n30_), .Y(new_n268_));
  AO21x1_ASAP7_75t_R   g247(.A1(\ctable[0] ), .A2(\trailingones[1] ), .B(\ctable[1] ), .Y(new_n269_));
  OA21x2_ASAP7_75t_R   g248(.A1(new_n50_), .A2(new_n25_), .B(new_n195_), .Y(new_n270_));
  OAI22x1_ASAP7_75t_R  g249(.A1(new_n270_), .A2(new_n269_), .B1(new_n268_), .B2(\totalcoeffs[2] ), .Y(new_n271_));
  AOI22x1_ASAP7_75t_R  g250(.A1(new_n267_), .A2(new_n263_), .B1(new_n271_), .B2(\totalcoeffs[3] ), .Y(new_n272_));
  OA21x2_ASAP7_75t_R   g251(.A1(\totalcoeffs[1] ), .A2(new_n266_), .B(new_n272_), .Y(new_n273_));
  AOI21x1_ASAP7_75t_R  g252(.A1(new_n273_), .A2(new_n259_), .B(\totalcoeffs[4] ), .Y(new_n274_));
  OA21x2_ASAP7_75t_R   g253(.A1(new_n274_), .A2(new_n248_), .B(new_n24_), .Y(\coeff_token[3] ));
  AND3x1_ASAP7_75t_R   g254(.A(new_n36_), .B(\totalcoeffs[2] ), .C(new_n22_), .Y(new_n276_));
  INVx1_ASAP7_75t_R    g255(.A(new_n128_), .Y(new_n277_));
  INVx1_ASAP7_75t_R    g256(.A(new_n245_), .Y(new_n278_));
  NAND2x1_ASAP7_75t_R  g257(.A(\totalcoeffs[3] ), .B(new_n22_), .Y(new_n279_));
  AOI21x1_ASAP7_75t_R  g258(.A1(new_n278_), .A2(new_n279_), .B(new_n277_), .Y(new_n280_));
  OA211x2_ASAP7_75t_R  g259(.A1(new_n280_), .A2(new_n276_), .B(new_n24_), .C(new_n242_), .Y(\coeff_token[4] ));
  NOR2x1_ASAP7_75t_R   g260(.A(new_n279_), .B(new_n128_), .Y(new_n282_));
  AND3x1_ASAP7_75t_R   g261(.A(new_n245_), .B(new_n32_), .C(new_n35_), .Y(new_n283_));
  OA211x2_ASAP7_75t_R  g262(.A1(new_n282_), .A2(new_n283_), .B(new_n24_), .C(new_n242_), .Y(\coeff_token[5] ));
  AND3x1_ASAP7_75t_R   g263(.A(new_n44_), .B(new_n23_), .C(\totalcoeffs[4] ), .Y(new_n285_));
  AO21x1_ASAP7_75t_R   g264(.A1(new_n285_), .A2(new_n84_), .B(new_n242_), .Y(new_n286_));
  INVx1_ASAP7_75t_R    g265(.A(new_n229_), .Y(new_n287_));
  OA21x2_ASAP7_75t_R   g266(.A1(new_n24_), .A2(\trailingones[1] ), .B(\trailingones[0] ), .Y(new_n288_));
  OA21x2_ASAP7_75t_R   g267(.A1(new_n288_), .A2(new_n70_), .B(new_n80_), .Y(new_n289_));
  OA21x2_ASAP7_75t_R   g268(.A1(new_n180_), .A2(new_n23_), .B(new_n182_), .Y(new_n290_));
  OR3x1_ASAP7_75t_R    g269(.A(new_n290_), .B(\totalcoeffs[2] ), .C(new_n24_), .Y(new_n291_));
  OA21x2_ASAP7_75t_R   g270(.A1(\totalcoeffs[0] ), .A2(new_n289_), .B(new_n291_), .Y(new_n292_));
  AO21x1_ASAP7_75t_R   g271(.A1(new_n23_), .A2(new_n50_), .B(new_n32_), .Y(new_n293_));
  AO22x1_ASAP7_75t_R   g272(.A1(new_n293_), .A2(new_n98_), .B1(\ctable[0] ), .B2(new_n192_), .Y(new_n294_));
  AND2x2_ASAP7_75t_R   g273(.A(new_n44_), .B(\totalcoeffs[2] ), .Y(new_n295_));
  AO22x1_ASAP7_75t_R   g274(.A1(new_n294_), .A2(\totalcoeffs[0] ), .B1(new_n30_), .B2(new_n295_), .Y(new_n296_));
  INVx1_ASAP7_75t_R    g275(.A(new_n178_), .Y(new_n297_));
  AND2x2_ASAP7_75t_R   g276(.A(\totalcoeffs[2] ), .B(\trailingones[0] ), .Y(new_n298_));
  OA211x2_ASAP7_75t_R  g277(.A1(new_n118_), .A2(new_n298_), .B(new_n297_), .C(\ctable[1] ), .Y(new_n299_));
  AND3x1_ASAP7_75t_R   g278(.A(new_n44_), .B(\totalcoeffs[2] ), .C(\trailingones[1] ), .Y(new_n300_));
  OA21x2_ASAP7_75t_R   g279(.A1(new_n85_), .A2(new_n300_), .B(\ctable[0] ), .Y(new_n301_));
  AOI211x1_ASAP7_75t_R g280(.A1(new_n296_), .A2(\trailingones[0] ), .B(new_n299_), .C(new_n301_), .Y(new_n302_));
  OAI22x1_ASAP7_75t_R  g281(.A1(new_n302_), .A2(\ctable[2] ), .B1(new_n292_), .B2(new_n287_), .Y(new_n303_));
  NAND2x1_ASAP7_75t_R  g282(.A(new_n44_), .B(new_n61_), .Y(new_n304_));
  OA21x2_ASAP7_75t_R   g283(.A1(new_n304_), .A2(new_n147_), .B(new_n49_), .Y(new_n305_));
  AO21x1_ASAP7_75t_R   g284(.A1(new_n25_), .A2(new_n37_), .B(\totalcoeffs[1] ), .Y(new_n306_));
  NAND2x1_ASAP7_75t_R  g285(.A(\totalcoeffs[0] ), .B(new_n306_), .Y(new_n307_));
  OA22x2_ASAP7_75t_R   g286(.A1(new_n307_), .A2(new_n46_), .B1(new_n305_), .B2(new_n193_), .Y(new_n308_));
  OR3x1_ASAP7_75t_R    g287(.A(new_n295_), .B(new_n23_), .C(\trailingones[0] ), .Y(new_n309_));
  OR4x2_ASAP7_75t_R    g288(.A(new_n44_), .B(new_n61_), .C(new_n25_), .D(\totalcoeffs[2] ), .Y(new_n310_));
  AO21x1_ASAP7_75t_R   g289(.A1(new_n309_), .A2(new_n310_), .B(new_n37_), .Y(new_n311_));
  AO21x1_ASAP7_75t_R   g290(.A1(\totalcoeffs[0] ), .A2(new_n50_), .B(new_n168_), .Y(new_n312_));
  AO21x1_ASAP7_75t_R   g291(.A1(new_n44_), .A2(new_n25_), .B(new_n312_), .Y(new_n313_));
  OA211x2_ASAP7_75t_R  g292(.A1(\ctable[0] ), .A2(new_n308_), .B(new_n311_), .C(new_n313_), .Y(new_n314_));
  OR3x1_ASAP7_75t_R    g293(.A(new_n64_), .B(new_n32_), .C(new_n25_), .Y(new_n315_));
  NOR2x1_ASAP7_75t_R   g294(.A(\totalcoeffs[2] ), .B(\trailingones[1] ), .Y(new_n316_));
  OAI21x1_ASAP7_75t_R  g295(.A1(new_n50_), .A2(new_n25_), .B(new_n316_), .Y(new_n317_));
  AO21x1_ASAP7_75t_R   g296(.A1(new_n44_), .A2(new_n215_), .B(new_n317_), .Y(new_n318_));
  AOI21x1_ASAP7_75t_R  g297(.A1(new_n318_), .A2(new_n315_), .B(\totalcoeffs[1] ), .Y(new_n319_));
  NAND2x1_ASAP7_75t_R  g298(.A(\ctable[0] ), .B(new_n32_), .Y(new_n320_));
  OA21x2_ASAP7_75t_R   g299(.A1(new_n32_), .A2(\ctable[0] ), .B(new_n61_), .Y(new_n321_));
  OA22x2_ASAP7_75t_R   g300(.A1(new_n64_), .A2(new_n321_), .B1(new_n66_), .B2(new_n320_), .Y(new_n322_));
  OA21x2_ASAP7_75t_R   g301(.A1(\trailingones[0] ), .A2(\trailingones[1] ), .B(\totalcoeffs[2] ), .Y(new_n323_));
  OAI21x1_ASAP7_75t_R  g302(.A1(new_n323_), .A2(new_n120_), .B(\ctable[1] ), .Y(new_n324_));
  OAI21x1_ASAP7_75t_R  g303(.A1(\trailingones[0] ), .A2(new_n322_), .B(new_n324_), .Y(new_n325_));
  AOI21x1_ASAP7_75t_R  g304(.A1(\totalcoeffs[1] ), .A2(new_n325_), .B(new_n319_), .Y(new_n326_));
  OAI21x1_ASAP7_75t_R  g305(.A1(new_n53_), .A2(new_n314_), .B(new_n326_), .Y(new_n327_));
  AO22x1_ASAP7_75t_R   g306(.A1(new_n327_), .A2(new_n24_), .B1(new_n53_), .B2(new_n303_), .Y(new_n328_));
  AOI22x1_ASAP7_75t_R  g307(.A1(new_n24_), .A2(new_n286_), .B1(new_n328_), .B2(new_n22_), .Y(\ctoken_len[0] ));
  NAND2x1_ASAP7_75t_R  g308(.A(\totalcoeffs[0] ), .B(\trailingones[0] ), .Y(new_n330_));
  AO21x1_ASAP7_75t_R   g309(.A1(\trailingones[0] ), .A2(\trailingones[1] ), .B(new_n53_), .Y(new_n331_));
  AOI21x1_ASAP7_75t_R  g310(.A1(new_n330_), .A2(new_n331_), .B(\ctable[1] ), .Y(new_n332_));
  AND3x1_ASAP7_75t_R   g311(.A(new_n53_), .B(\trailingones[0] ), .C(\trailingones[1] ), .Y(new_n333_));
  OAI21x1_ASAP7_75t_R  g312(.A1(new_n333_), .A2(new_n332_), .B(\totalcoeffs[2] ), .Y(new_n334_));
  NAND2x1_ASAP7_75t_R  g313(.A(new_n98_), .B(new_n135_), .Y(new_n335_));
  OAI21x1_ASAP7_75t_R  g314(.A1(new_n150_), .A2(new_n262_), .B(new_n215_), .Y(new_n336_));
  AOI21x1_ASAP7_75t_R  g315(.A1(\ctable[1] ), .A2(\trailingones[1] ), .B(\trailingones[0] ), .Y(new_n337_));
  OAI21x1_ASAP7_75t_R  g316(.A1(\ctable[1] ), .A2(new_n53_), .B(\totalcoeffs[0] ), .Y(new_n338_));
  AOI21x1_ASAP7_75t_R  g317(.A1(new_n338_), .A2(new_n100_), .B(new_n337_), .Y(new_n339_));
  AOI21x1_ASAP7_75t_R  g318(.A1(\trailingones[1] ), .A2(new_n336_), .B(new_n339_), .Y(new_n340_));
  OA211x2_ASAP7_75t_R  g319(.A1(new_n340_), .A2(\totalcoeffs[2] ), .B(new_n334_), .C(new_n335_), .Y(new_n341_));
  NAND2x1_ASAP7_75t_R  g320(.A(\ctable[1] ), .B(new_n44_), .Y(new_n342_));
  AO21x1_ASAP7_75t_R   g321(.A1(\trailingones[0] ), .A2(\trailingones[1] ), .B(\ctable[1] ), .Y(new_n343_));
  OAI22x1_ASAP7_75t_R  g322(.A1(new_n73_), .A2(new_n343_), .B1(new_n342_), .B2(new_n178_), .Y(new_n344_));
  NAND3x1_ASAP7_75t_R  g323(.A(\totalcoeffs[0] ), .B(\trailingones[0] ), .C(\ctable[1] ), .Y(new_n345_));
  OR3x1_ASAP7_75t_R    g324(.A(\totalcoeffs[0] ), .B(\totalcoeffs[2] ), .C(\trailingones[0] ), .Y(new_n346_));
  AOI21x1_ASAP7_75t_R  g325(.A1(new_n345_), .A2(new_n346_), .B(\trailingones[1] ), .Y(new_n347_));
  OA21x2_ASAP7_75t_R   g326(.A1(new_n135_), .A2(\ctable[1] ), .B(new_n323_), .Y(new_n348_));
  AO211x2_ASAP7_75t_R  g327(.A1(\totalcoeffs[3] ), .A2(new_n344_), .B(new_n347_), .C(new_n348_), .Y(new_n349_));
  AND4x2_ASAP7_75t_R   g328(.A(new_n118_), .B(\totalcoeffs[3] ), .C(\ctable[1] ), .D(new_n37_), .Y(new_n350_));
  AOI21x1_ASAP7_75t_R  g329(.A1(new_n23_), .A2(new_n349_), .B(new_n350_), .Y(new_n351_));
  OAI21x1_ASAP7_75t_R  g330(.A1(new_n23_), .A2(new_n341_), .B(new_n351_), .Y(new_n352_));
  AO21x1_ASAP7_75t_R   g331(.A1(\totalcoeffs[2] ), .A2(\trailingones[1] ), .B(new_n44_), .Y(new_n353_));
  OAI22x1_ASAP7_75t_R  g332(.A1(new_n353_), .A2(new_n316_), .B1(new_n142_), .B2(\trailingones[1] ), .Y(new_n354_));
  AND3x1_ASAP7_75t_R   g333(.A(new_n78_), .B(\ctable[0] ), .C(new_n25_), .Y(new_n355_));
  AOI21x1_ASAP7_75t_R  g334(.A1(\trailingones[0] ), .A2(new_n354_), .B(new_n355_), .Y(new_n356_));
  AND2x2_ASAP7_75t_R   g335(.A(\totalcoeffs[3] ), .B(\ctable[0] ), .Y(new_n357_));
  AOI22x1_ASAP7_75t_R  g336(.A1(\totalcoeffs[3] ), .A2(\ctable[0] ), .B1(new_n37_), .B2(\totalcoeffs[2] ), .Y(new_n358_));
  OAI22x1_ASAP7_75t_R  g337(.A1(new_n358_), .A2(\totalcoeffs[0] ), .B1(new_n320_), .B2(new_n53_), .Y(new_n359_));
  AOI22x1_ASAP7_75t_R  g338(.A1(new_n316_), .A2(new_n357_), .B1(new_n359_), .B2(new_n25_), .Y(new_n360_));
  OAI21x1_ASAP7_75t_R  g339(.A1(\totalcoeffs[3] ), .A2(new_n356_), .B(new_n360_), .Y(new_n361_));
  AND2x2_ASAP7_75t_R   g340(.A(\totalcoeffs[2] ), .B(\totalcoeffs[3] ), .Y(new_n362_));
  OR3x1_ASAP7_75t_R    g341(.A(new_n32_), .B(\trailingones[0] ), .C(\trailingones[1] ), .Y(new_n363_));
  OA21x2_ASAP7_75t_R   g342(.A1(new_n32_), .A2(new_n53_), .B(new_n178_), .Y(new_n364_));
  AO21x1_ASAP7_75t_R   g343(.A1(new_n55_), .A2(new_n32_), .B(new_n50_), .Y(new_n365_));
  OAI22x1_ASAP7_75t_R  g344(.A1(new_n55_), .A2(new_n363_), .B1(new_n364_), .B2(new_n365_), .Y(new_n366_));
  AO22x1_ASAP7_75t_R   g345(.A1(new_n366_), .A2(new_n23_), .B1(new_n233_), .B2(new_n362_), .Y(new_n367_));
  AO21x1_ASAP7_75t_R   g346(.A1(\totalcoeffs[1] ), .A2(new_n361_), .B(new_n367_), .Y(new_n368_));
  AOI22x1_ASAP7_75t_R  g347(.A1(new_n61_), .A2(new_n368_), .B1(new_n352_), .B2(new_n50_), .Y(new_n369_));
  NAND2x1_ASAP7_75t_R  g348(.A(new_n178_), .B(new_n295_), .Y(new_n370_));
  OR4x2_ASAP7_75t_R    g349(.A(new_n33_), .B(new_n24_), .C(new_n25_), .D(\trailingones[1] ), .Y(new_n371_));
  NAND2x1_ASAP7_75t_R  g350(.A(new_n23_), .B(new_n53_), .Y(new_n372_));
  OR3x1_ASAP7_75t_R    g351(.A(new_n372_), .B(\ctable[0] ), .C(\ctable[1] ), .Y(new_n373_));
  AO21x1_ASAP7_75t_R   g352(.A1(new_n371_), .A2(new_n370_), .B(new_n373_), .Y(new_n374_));
  OAI21x1_ASAP7_75t_R  g353(.A1(\ctable[2] ), .A2(new_n369_), .B(new_n374_), .Y(new_n375_));
  AND3x1_ASAP7_75t_R   g354(.A(new_n283_), .B(new_n50_), .C(new_n24_), .Y(new_n376_));
  AND2x2_ASAP7_75t_R   g355(.A(new_n376_), .B(new_n61_), .Y(new_n377_));
  AOI21x1_ASAP7_75t_R  g356(.A1(new_n22_), .A2(new_n375_), .B(new_n377_), .Y(\ctoken_len[1] ));
  OAI21x1_ASAP7_75t_R  g357(.A1(new_n53_), .A2(\ctable[0] ), .B(new_n156_), .Y(new_n379_));
  AO21x1_ASAP7_75t_R   g358(.A1(new_n23_), .A2(new_n37_), .B(\totalcoeffs[2] ), .Y(new_n380_));
  AOI211x1_ASAP7_75t_R g359(.A1(new_n53_), .A2(\trailingones[1] ), .B(new_n379_), .C(new_n380_), .Y(new_n381_));
  OR4x2_ASAP7_75t_R    g360(.A(new_n50_), .B(\totalcoeffs[1] ), .C(\totalcoeffs[2] ), .D(\trailingones[1] ), .Y(new_n382_));
  AOI21x1_ASAP7_75t_R  g361(.A1(new_n216_), .A2(new_n382_), .B(\totalcoeffs[0] ), .Y(new_n383_));
  NOR2x1_ASAP7_75t_R   g362(.A(\totalcoeffs[1] ), .B(\ctable[0] ), .Y(new_n384_));
  OA21x2_ASAP7_75t_R   g363(.A1(new_n193_), .A2(new_n384_), .B(new_n87_), .Y(new_n385_));
  OA31x2_ASAP7_75t_R   g364(.A1(new_n381_), .A2(new_n385_), .A3(new_n383_), .B1(new_n25_), .Y(new_n386_));
  AO21x1_ASAP7_75t_R   g365(.A1(new_n44_), .A2(new_n53_), .B(\totalcoeffs[2] ), .Y(new_n387_));
  OA22x2_ASAP7_75t_R   g366(.A1(new_n372_), .A2(new_n143_), .B1(new_n379_), .B2(new_n387_), .Y(new_n388_));
  AO21x1_ASAP7_75t_R   g367(.A1(\totalcoeffs[3] ), .A2(\ctable[0] ), .B(new_n49_), .Y(new_n389_));
  AO21x1_ASAP7_75t_R   g368(.A1(new_n50_), .A2(new_n150_), .B(new_n389_), .Y(new_n390_));
  OAI21x1_ASAP7_75t_R  g369(.A1(new_n25_), .A2(new_n388_), .B(new_n390_), .Y(new_n391_));
  AOI21x1_ASAP7_75t_R  g370(.A1(\totalcoeffs[2] ), .A2(new_n50_), .B(new_n357_), .Y(new_n392_));
  OR3x1_ASAP7_75t_R    g371(.A(new_n392_), .B(new_n23_), .C(new_n201_), .Y(new_n393_));
  NAND2x1_ASAP7_75t_R  g372(.A(\trailingones[0] ), .B(new_n32_), .Y(new_n394_));
  OR4x2_ASAP7_75t_R    g373(.A(new_n106_), .B(new_n394_), .C(\totalcoeffs[1] ), .D(new_n53_), .Y(new_n395_));
  AOI21x1_ASAP7_75t_R  g374(.A1(new_n395_), .A2(new_n393_), .B(new_n37_), .Y(new_n396_));
  AOI211x1_ASAP7_75t_R g375(.A1(new_n37_), .A2(new_n391_), .B(new_n386_), .C(new_n396_), .Y(new_n397_));
  OA21x2_ASAP7_75t_R   g376(.A1(new_n23_), .A2(\trailingones[0] ), .B(new_n61_), .Y(new_n398_));
  INVx1_ASAP7_75t_R    g377(.A(new_n150_), .Y(new_n399_));
  AO21x1_ASAP7_75t_R   g378(.A1(new_n399_), .A2(new_n168_), .B(new_n190_), .Y(new_n400_));
  AO21x1_ASAP7_75t_R   g379(.A1(new_n400_), .A2(new_n32_), .B(new_n254_), .Y(new_n401_));
  AO21x1_ASAP7_75t_R   g380(.A1(new_n307_), .A2(new_n398_), .B(new_n401_), .Y(new_n402_));
  OAI21x1_ASAP7_75t_R  g381(.A1(\ctable[1] ), .A2(new_n397_), .B(new_n402_), .Y(new_n403_));
  OA21x2_ASAP7_75t_R   g382(.A1(new_n118_), .A2(new_n298_), .B(new_n44_), .Y(new_n404_));
  OA21x2_ASAP7_75t_R   g383(.A1(new_n404_), .A2(new_n141_), .B(new_n37_), .Y(new_n405_));
  AO21x1_ASAP7_75t_R   g384(.A1(new_n25_), .A2(new_n300_), .B(new_n405_), .Y(new_n406_));
  AND3x1_ASAP7_75t_R   g385(.A(new_n118_), .B(new_n44_), .C(new_n192_), .Y(new_n407_));
  AO21x1_ASAP7_75t_R   g386(.A1(new_n406_), .A2(new_n23_), .B(new_n407_), .Y(new_n408_));
  AO22x1_ASAP7_75t_R   g387(.A1(new_n403_), .A2(new_n24_), .B1(new_n173_), .B2(new_n408_), .Y(new_n409_));
  AOI21x1_ASAP7_75t_R  g388(.A1(new_n22_), .A2(new_n409_), .B(new_n376_), .Y(\ctoken_len[2] ));
  AO21x1_ASAP7_75t_R   g389(.A1(\ctable[1] ), .A2(\trailingones[1] ), .B(new_n53_), .Y(new_n411_));
  AO21x1_ASAP7_75t_R   g390(.A1(new_n399_), .A2(new_n269_), .B(new_n411_), .Y(new_n412_));
  OA21x2_ASAP7_75t_R   g391(.A1(new_n278_), .A2(new_n229_), .B(new_n32_), .Y(new_n413_));
  AND3x1_ASAP7_75t_R   g392(.A(new_n244_), .B(new_n87_), .C(new_n182_), .Y(new_n414_));
  AO21x1_ASAP7_75t_R   g393(.A1(new_n412_), .A2(new_n413_), .B(new_n414_), .Y(new_n415_));
  AO21x1_ASAP7_75t_R   g394(.A1(new_n50_), .A2(new_n37_), .B(\totalcoeffs[3] ), .Y(new_n416_));
  NAND2x1_ASAP7_75t_R  g395(.A(new_n411_), .B(new_n399_), .Y(new_n417_));
  AOI21x1_ASAP7_75t_R  g396(.A1(new_n416_), .A2(new_n417_), .B(\totalcoeffs[2] ), .Y(new_n418_));
  INVx1_ASAP7_75t_R    g397(.A(new_n260_), .Y(new_n419_));
  OA21x2_ASAP7_75t_R   g398(.A1(new_n233_), .A2(\ctable[1] ), .B(new_n53_), .Y(new_n420_));
  AO21x1_ASAP7_75t_R   g399(.A1(new_n419_), .A2(new_n243_), .B(new_n420_), .Y(new_n421_));
  OA21x2_ASAP7_75t_R   g400(.A1(new_n418_), .A2(new_n421_), .B(\totalcoeffs[1] ), .Y(new_n422_));
  AO21x1_ASAP7_75t_R   g401(.A1(new_n419_), .A2(new_n177_), .B(\ctable[2] ), .Y(new_n423_));
  AND2x2_ASAP7_75t_R   g402(.A(new_n423_), .B(new_n306_), .Y(new_n424_));
  INVx1_ASAP7_75t_R    g403(.A(new_n222_), .Y(new_n425_));
  OA21x2_ASAP7_75t_R   g404(.A1(new_n425_), .A2(\ctable[2] ), .B(\totalcoeffs[0] ), .Y(new_n426_));
  AO21x1_ASAP7_75t_R   g405(.A1(new_n53_), .A2(\totalcoeffs[2] ), .B(\ctable[0] ), .Y(new_n427_));
  OAI22x1_ASAP7_75t_R  g406(.A1(new_n24_), .A2(new_n87_), .B1(new_n425_), .B2(new_n22_), .Y(new_n428_));
  AO21x1_ASAP7_75t_R   g407(.A1(\ctable[1] ), .A2(new_n427_), .B(new_n428_), .Y(new_n429_));
  OR4x2_ASAP7_75t_R    g408(.A(new_n422_), .B(new_n424_), .C(new_n426_), .D(new_n429_), .Y(new_n430_));
  AOI21x1_ASAP7_75t_R  g409(.A1(new_n23_), .A2(new_n415_), .B(new_n430_), .Y(\ctoken_len[3] ));
  INVx1_ASAP7_75t_R    g410(.A(new_n41_), .Y(new_n432_));
  OR3x1_ASAP7_75t_R    g411(.A(new_n279_), .B(new_n45_), .C(new_n32_), .Y(new_n433_));
  AOI21x1_ASAP7_75t_R  g412(.A1(\trailingones[0] ), .A2(new_n432_), .B(new_n433_), .Y(new_n434_));
  OA211x2_ASAP7_75t_R  g413(.A1(new_n434_), .A2(new_n283_), .B(new_n24_), .C(new_n229_), .Y(\ctoken_len[4] ));
endmodule


