// Benchmark "/tmp/" written by ABC on Tue Oct 13 18:52:00 2026

module \/tmp/  ( 
    p0, p5, p3, p4, p1, p6, p2,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25  );
  input  p0, p5, p3, p4, p1, p6, p2;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25;
  wire new_n34_, new_n35_, new_n36_, new_n37_, new_n39_, new_n40_, new_n41_,
    new_n42_, new_n43_, new_n44_, new_n45_, new_n46_, new_n48_, new_n49_,
    new_n50_, new_n51_, new_n52_, new_n53_, new_n54_, new_n56_, new_n57_,
    new_n59_, new_n60_, new_n61_, new_n62_, new_n63_, new_n64_, new_n65_,
    new_n66_, new_n67_, new_n68_, new_n69_, new_n71_, new_n73_, new_n74_,
    new_n76_, new_n77_, new_n79_, new_n82_, new_n83_, new_n84_, new_n85_,
    new_n88_, new_n89_, new_n93_, new_n95_, new_n100_, new_n101_,
    new_n103_, new_n104_;
  AND2x2_ASAP7_75t_R   g00(.A(p3), .B(p2), .Y(new_n34_));
  OR3x1_ASAP7_75t_R    g01(.A(p0), .B(p1), .C(p6), .Y(new_n35_));
  NOR2x1_ASAP7_75t_R   g02(.A(p3), .B(p2), .Y(new_n36_));
  AND3x1_ASAP7_75t_R   g03(.A(new_n36_), .B(p0), .C(p1), .Y(new_n37_));
  AO21x1_ASAP7_75t_R   g04(.A1(new_n34_), .A2(new_n35_), .B(new_n37_), .Y(o0));
  INVx1_ASAP7_75t_R    g05(.A(p2), .Y(new_n39_));
  NAND2x1_ASAP7_75t_R  g06(.A(p3), .B(new_n39_), .Y(new_n40_));
  INVx1_ASAP7_75t_R    g07(.A(p0), .Y(new_n41_));
  NOR2x1_ASAP7_75t_R   g08(.A(p1), .B(new_n41_), .Y(new_n42_));
  INVx1_ASAP7_75t_R    g09(.A(p1), .Y(new_n43_));
  AND3x1_ASAP7_75t_R   g10(.A(new_n41_), .B(new_n43_), .C(p6), .Y(new_n44_));
  OAI21x1_ASAP7_75t_R  g11(.A1(p3), .A2(p2), .B(p1), .Y(new_n45_));
  OAI21x1_ASAP7_75t_R  g12(.A1(p0), .A2(new_n34_), .B(new_n45_), .Y(new_n46_));
  AOI211x1_ASAP7_75t_R g13(.A1(new_n40_), .A2(new_n42_), .B(new_n44_), .C(new_n46_), .Y(o1));
  NOR2x1_ASAP7_75t_R   g14(.A(p3), .B(new_n39_), .Y(new_n48_));
  NOR2x1_ASAP7_75t_R   g15(.A(new_n41_), .B(new_n48_), .Y(new_n49_));
  INVx1_ASAP7_75t_R    g16(.A(p3), .Y(new_n50_));
  OR3x1_ASAP7_75t_R    g17(.A(new_n50_), .B(p6), .C(p2), .Y(new_n51_));
  INVx1_ASAP7_75t_R    g18(.A(new_n42_), .Y(new_n52_));
  NOR2x1_ASAP7_75t_R   g19(.A(p1), .B(p6), .Y(new_n53_));
  NAND2x1_ASAP7_75t_R  g20(.A(new_n53_), .B(new_n34_), .Y(new_n54_));
  AOI22x1_ASAP7_75t_R  g21(.A1(new_n49_), .A2(new_n51_), .B1(new_n52_), .B2(new_n54_), .Y(o2));
  NOR2x1_ASAP7_75t_R   g22(.A(p0), .B(p1), .Y(new_n56_));
  NAND2x1_ASAP7_75t_R  g23(.A(p2), .B(new_n56_), .Y(new_n57_));
  AOI22x1_ASAP7_75t_R  g24(.A1(new_n57_), .A2(new_n40_), .B1(p6), .B2(new_n34_), .Y(o3));
  NAND2x1_ASAP7_75t_R  g25(.A(p3), .B(p2), .Y(new_n59_));
  NAND2x1_ASAP7_75t_R  g26(.A(p0), .B(p4), .Y(new_n60_));
  OA31x2_ASAP7_75t_R   g27(.A1(p6), .A2(new_n59_), .A3(new_n60_), .B1(new_n43_), .Y(new_n61_));
  INVx1_ASAP7_75t_R    g28(.A(p5), .Y(new_n62_));
  AOI21x1_ASAP7_75t_R  g29(.A1(p3), .A2(new_n62_), .B(new_n39_), .Y(new_n63_));
  INVx1_ASAP7_75t_R    g30(.A(p4), .Y(new_n64_));
  NAND3x1_ASAP7_75t_R  g31(.A(new_n64_), .B(p5), .C(p3), .Y(new_n65_));
  AND2x2_ASAP7_75t_R   g32(.A(p0), .B(p6), .Y(new_n66_));
  NAND3x1_ASAP7_75t_R  g33(.A(new_n63_), .B(new_n65_), .C(new_n66_), .Y(new_n67_));
  INVx1_ASAP7_75t_R    g34(.A(p6), .Y(new_n68_));
  OA21x2_ASAP7_75t_R   g35(.A1(new_n68_), .A2(new_n40_), .B(p1), .Y(new_n69_));
  AOI21x1_ASAP7_75t_R  g36(.A1(new_n61_), .A2(new_n67_), .B(new_n69_), .Y(o4));
  AO21x1_ASAP7_75t_R   g37(.A1(p3), .A2(new_n39_), .B(new_n43_), .Y(new_n71_));
  OA211x2_ASAP7_75t_R  g38(.A1(p1), .A2(new_n63_), .B(new_n71_), .C(p0), .Y(o5));
  AO21x1_ASAP7_75t_R   g39(.A1(new_n50_), .A2(new_n39_), .B(p1), .Y(new_n73_));
  OR3x1_ASAP7_75t_R    g40(.A(new_n53_), .B(new_n56_), .C(new_n59_), .Y(new_n74_));
  OAI21x1_ASAP7_75t_R  g41(.A1(new_n34_), .A2(new_n73_), .B(new_n74_), .Y(o6));
  AND3x1_ASAP7_75t_R   g42(.A(new_n34_), .B(new_n68_), .C(new_n56_), .Y(new_n76_));
  AND3x1_ASAP7_75t_R   g43(.A(new_n34_), .B(p1), .C(p6), .Y(new_n77_));
  OR3x1_ASAP7_75t_R    g44(.A(new_n76_), .B(new_n77_), .C(new_n37_), .Y(o7));
  OAI21x1_ASAP7_75t_R  g45(.A1(new_n45_), .A2(new_n34_), .B(p0), .Y(new_n79_));
  AOI21x1_ASAP7_75t_R  g46(.A1(new_n42_), .A2(new_n51_), .B(new_n79_), .Y(o8));
  AOI21x1_ASAP7_75t_R  g47(.A1(new_n42_), .A2(new_n51_), .B(new_n46_), .Y(o9));
  NOR2x1_ASAP7_75t_R   g48(.A(p2), .B(new_n50_), .Y(new_n82_));
  NAND2x1_ASAP7_75t_R  g49(.A(p0), .B(new_n68_), .Y(new_n83_));
  NOR2x1_ASAP7_75t_R   g50(.A(p1), .B(p2), .Y(new_n84_));
  AOI21x1_ASAP7_75t_R  g51(.A1(p3), .A2(new_n56_), .B(new_n84_), .Y(new_n85_));
  AO22x1_ASAP7_75t_R   g52(.A1(new_n82_), .A2(new_n83_), .B1(new_n71_), .B2(new_n85_), .Y(o10));
  AND3x1_ASAP7_75t_R   g53(.A(new_n36_), .B(new_n53_), .C(new_n41_), .Y(o11));
  OA21x2_ASAP7_75t_R   g54(.A1(p2), .A2(new_n41_), .B(new_n50_), .Y(new_n88_));
  AND3x1_ASAP7_75t_R   g55(.A(new_n41_), .B(new_n68_), .C(new_n39_), .Y(new_n89_));
  OAI22x1_ASAP7_75t_R  g56(.A1(new_n88_), .A2(new_n43_), .B1(new_n89_), .B2(new_n73_), .Y(o12));
  AND3x1_ASAP7_75t_R   g57(.A(new_n36_), .B(p1), .C(p6), .Y(o13));
  AND3x1_ASAP7_75t_R   g58(.A(new_n36_), .B(p1), .C(new_n68_), .Y(o14));
  NOR2x1_ASAP7_75t_R   g59(.A(p0), .B(p6), .Y(new_n93_));
  AND3x1_ASAP7_75t_R   g60(.A(new_n48_), .B(p1), .C(new_n93_), .Y(o15));
  AND3x1_ASAP7_75t_R   g61(.A(new_n50_), .B(p1), .C(p2), .Y(new_n95_));
  AND3x1_ASAP7_75t_R   g62(.A(new_n95_), .B(new_n41_), .C(p6), .Y(o16));
  AND3x1_ASAP7_75t_R   g63(.A(new_n48_), .B(p1), .C(new_n66_), .Y(o17));
  AND3x1_ASAP7_75t_R   g64(.A(new_n95_), .B(p0), .C(new_n68_), .Y(o18));
  AND3x1_ASAP7_75t_R   g65(.A(new_n50_), .B(new_n39_), .C(p1), .Y(o19));
  AO21x1_ASAP7_75t_R   g66(.A1(p3), .A2(new_n60_), .B(new_n39_), .Y(new_n100_));
  OA21x2_ASAP7_75t_R   g67(.A1(new_n59_), .A2(new_n66_), .B(p1), .Y(new_n101_));
  AOI211x1_ASAP7_75t_R g68(.A1(new_n43_), .A2(new_n100_), .B(new_n53_), .C(new_n101_), .Y(o20));
  OR3x1_ASAP7_75t_R    g69(.A(new_n39_), .B(p0), .C(p3), .Y(new_n103_));
  OR3x1_ASAP7_75t_R    g70(.A(new_n59_), .B(new_n60_), .C(p5), .Y(new_n104_));
  AOI211x1_ASAP7_75t_R g71(.A1(new_n103_), .A2(new_n104_), .B(p1), .C(new_n68_), .Y(o21));
  AOI21x1_ASAP7_75t_R  g72(.A1(new_n43_), .A2(new_n67_), .B(new_n101_), .Y(o22));
  assign               o23 = 1'b1;
  OA211x2_ASAP7_75t_R  g73(.A1(new_n93_), .A2(new_n66_), .B(p3), .C(new_n84_), .Y(o24));
  AND3x1_ASAP7_75t_R   g74(.A(new_n82_), .B(p6), .C(new_n56_), .Y(o25));
endmodule


