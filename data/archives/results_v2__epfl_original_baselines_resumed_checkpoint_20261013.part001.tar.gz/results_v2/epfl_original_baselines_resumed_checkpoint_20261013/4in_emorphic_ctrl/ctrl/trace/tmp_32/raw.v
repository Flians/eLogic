// Benchmark "/tmp/" written by ABC on Tue Oct 13 18:51:59 2026

module \/tmp/  ( 
    p5, p0, p6, p1, p4, p2, p3,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25  );
  input  p5, p0, p6, p1, p4, p2, p3;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25;
  wire new_n34_, new_n35_, new_n36_, new_n37_, new_n38_, new_n39_, new_n41_,
    new_n42_, new_n43_, new_n44_, new_n45_, new_n46_, new_n47_, new_n48_,
    new_n49_, new_n51_, new_n52_, new_n53_, new_n54_, new_n55_, new_n57_,
    new_n59_, new_n60_, new_n61_, new_n62_, new_n63_, new_n64_, new_n65_,
    new_n66_, new_n67_, new_n69_, new_n71_, new_n72_, new_n74_, new_n75_,
    new_n76_, new_n78_, new_n79_, new_n81_, new_n83_, new_n84_, new_n85_,
    new_n86_, new_n89_, new_n90_, new_n91_, new_n95_, new_n99_, new_n102_,
    new_n103_, new_n104_, new_n105_, new_n106_, new_n108_, new_n109_,
    new_n110_;
  NOR2x1_ASAP7_75t_R   g00(.A(p2), .B(p3), .Y(new_n34_));
  AND3x1_ASAP7_75t_R   g01(.A(new_n34_), .B(p0), .C(p1), .Y(new_n35_));
  NAND2x1_ASAP7_75t_R  g02(.A(p2), .B(p3), .Y(new_n36_));
  INVx1_ASAP7_75t_R    g03(.A(new_n36_), .Y(new_n37_));
  NOR2x1_ASAP7_75t_R   g04(.A(p0), .B(p1), .Y(new_n38_));
  INVx1_ASAP7_75t_R    g05(.A(new_n38_), .Y(new_n39_));
  OA22x2_ASAP7_75t_R   g06(.A1(new_n35_), .A2(new_n37_), .B1(p6), .B2(new_n39_), .Y(o0));
  INVx1_ASAP7_75t_R    g07(.A(p2), .Y(new_n41_));
  INVx1_ASAP7_75t_R    g08(.A(p3), .Y(new_n42_));
  OR3x1_ASAP7_75t_R    g09(.A(new_n41_), .B(new_n42_), .C(p6), .Y(new_n43_));
  INVx1_ASAP7_75t_R    g10(.A(p1), .Y(new_n44_));
  OAI21x1_ASAP7_75t_R  g11(.A1(p2), .A2(p3), .B(p1), .Y(new_n45_));
  OAI21x1_ASAP7_75t_R  g12(.A1(p0), .A2(new_n44_), .B(new_n45_), .Y(new_n46_));
  NAND2x1_ASAP7_75t_R  g13(.A(p0), .B(new_n44_), .Y(new_n47_));
  NOR2x1_ASAP7_75t_R   g14(.A(p2), .B(new_n42_), .Y(new_n48_));
  NOR2x1_ASAP7_75t_R   g15(.A(new_n47_), .B(new_n48_), .Y(new_n49_));
  AOI211x1_ASAP7_75t_R g16(.A1(new_n38_), .A2(new_n43_), .B(new_n46_), .C(new_n49_), .Y(o1));
  INVx1_ASAP7_75t_R    g17(.A(p0), .Y(new_n51_));
  NOR2x1_ASAP7_75t_R   g18(.A(p3), .B(new_n41_), .Y(new_n52_));
  NOR2x1_ASAP7_75t_R   g19(.A(new_n51_), .B(new_n52_), .Y(new_n53_));
  OR3x1_ASAP7_75t_R    g20(.A(new_n42_), .B(p6), .C(p2), .Y(new_n54_));
  OR3x1_ASAP7_75t_R    g21(.A(new_n36_), .B(p6), .C(p1), .Y(new_n55_));
  AOI22x1_ASAP7_75t_R  g22(.A1(new_n53_), .A2(new_n54_), .B1(new_n47_), .B2(new_n55_), .Y(o2));
  AO21x1_ASAP7_75t_R   g23(.A1(p2), .A2(new_n39_), .B(new_n34_), .Y(new_n57_));
  AOI21x1_ASAP7_75t_R  g24(.A1(p6), .A2(new_n37_), .B(new_n57_), .Y(o3));
  NAND2x1_ASAP7_75t_R  g25(.A(p0), .B(p4), .Y(new_n59_));
  OA31x2_ASAP7_75t_R   g26(.A1(p6), .A2(new_n36_), .A3(new_n59_), .B1(new_n44_), .Y(new_n60_));
  INVx1_ASAP7_75t_R    g27(.A(p5), .Y(new_n61_));
  AOI21x1_ASAP7_75t_R  g28(.A1(p3), .A2(new_n61_), .B(new_n41_), .Y(new_n62_));
  INVx1_ASAP7_75t_R    g29(.A(p4), .Y(new_n63_));
  NAND3x1_ASAP7_75t_R  g30(.A(new_n63_), .B(p5), .C(p3), .Y(new_n64_));
  AND2x2_ASAP7_75t_R   g31(.A(p0), .B(p6), .Y(new_n65_));
  NAND3x1_ASAP7_75t_R  g32(.A(new_n62_), .B(new_n64_), .C(new_n65_), .Y(new_n66_));
  AOI21x1_ASAP7_75t_R  g33(.A1(p6), .A2(new_n48_), .B(new_n44_), .Y(new_n67_));
  AOI21x1_ASAP7_75t_R  g34(.A1(new_n60_), .A2(new_n66_), .B(new_n67_), .Y(o4));
  AO21x1_ASAP7_75t_R   g35(.A1(p3), .A2(new_n41_), .B(new_n44_), .Y(new_n69_));
  OA211x2_ASAP7_75t_R  g36(.A1(p1), .A2(new_n62_), .B(new_n69_), .C(p0), .Y(o5));
  AO21x1_ASAP7_75t_R   g37(.A1(new_n41_), .A2(new_n42_), .B(p1), .Y(new_n71_));
  OAI21x1_ASAP7_75t_R  g38(.A1(p1), .A2(new_n65_), .B(new_n37_), .Y(new_n72_));
  OAI21x1_ASAP7_75t_R  g39(.A1(new_n37_), .A2(new_n71_), .B(new_n72_), .Y(o6));
  INVx1_ASAP7_75t_R    g40(.A(p6), .Y(new_n74_));
  AND2x2_ASAP7_75t_R   g41(.A(p6), .B(p1), .Y(new_n75_));
  AO21x1_ASAP7_75t_R   g42(.A1(new_n74_), .A2(new_n38_), .B(new_n75_), .Y(new_n76_));
  AO21x1_ASAP7_75t_R   g43(.A1(new_n37_), .A2(new_n76_), .B(new_n35_), .Y(o7));
  INVx1_ASAP7_75t_R    g44(.A(new_n47_), .Y(new_n78_));
  OAI21x1_ASAP7_75t_R  g45(.A1(new_n45_), .A2(new_n37_), .B(p0), .Y(new_n79_));
  AOI21x1_ASAP7_75t_R  g46(.A1(new_n78_), .A2(new_n54_), .B(new_n79_), .Y(o8));
  AND2x2_ASAP7_75t_R   g47(.A(new_n51_), .B(new_n36_), .Y(new_n81_));
  AOI211x1_ASAP7_75t_R g48(.A1(new_n54_), .A2(new_n78_), .B(new_n46_), .C(new_n81_), .Y(o9));
  OAI21x1_ASAP7_75t_R  g49(.A1(new_n51_), .A2(p6), .B(new_n48_), .Y(new_n83_));
  NAND2x1_ASAP7_75t_R  g50(.A(p0), .B(p2), .Y(new_n84_));
  OA211x2_ASAP7_75t_R  g51(.A1(new_n41_), .A2(p3), .B(new_n84_), .C(new_n44_), .Y(new_n85_));
  INVx1_ASAP7_75t_R    g52(.A(new_n69_), .Y(new_n86_));
  AOI21x1_ASAP7_75t_R  g53(.A1(new_n83_), .A2(new_n85_), .B(new_n86_), .Y(o10));
  AND3x1_ASAP7_75t_R   g54(.A(new_n38_), .B(new_n34_), .C(new_n74_), .Y(o11));
  AND3x1_ASAP7_75t_R   g55(.A(new_n51_), .B(new_n74_), .C(new_n41_), .Y(new_n89_));
  NOR2x1_ASAP7_75t_R   g56(.A(p0), .B(p3), .Y(new_n90_));
  OR3x1_ASAP7_75t_R    g57(.A(new_n52_), .B(new_n44_), .C(new_n90_), .Y(new_n91_));
  OAI21x1_ASAP7_75t_R  g58(.A1(new_n71_), .A2(new_n89_), .B(new_n91_), .Y(o12));
  AND3x1_ASAP7_75t_R   g59(.A(new_n34_), .B(p6), .C(p1), .Y(o13));
  AND3x1_ASAP7_75t_R   g60(.A(new_n34_), .B(new_n74_), .C(p1), .Y(o14));
  NOR2x1_ASAP7_75t_R   g61(.A(p0), .B(p6), .Y(new_n95_));
  AND3x1_ASAP7_75t_R   g62(.A(new_n52_), .B(p1), .C(new_n95_), .Y(o15));
  AND3x1_ASAP7_75t_R   g63(.A(new_n52_), .B(new_n51_), .C(new_n75_), .Y(o16));
  AND3x1_ASAP7_75t_R   g64(.A(new_n52_), .B(p1), .C(new_n65_), .Y(o17));
  OR3x1_ASAP7_75t_R    g65(.A(new_n44_), .B(p6), .C(p3), .Y(new_n99_));
  NOR2x1_ASAP7_75t_R   g66(.A(new_n84_), .B(new_n99_), .Y(o18));
  AND3x1_ASAP7_75t_R   g67(.A(new_n41_), .B(new_n42_), .C(p1), .Y(o19));
  AND3x1_ASAP7_75t_R   g68(.A(p0), .B(p6), .C(p2), .Y(new_n102_));
  OAI21x1_ASAP7_75t_R  g69(.A1(p4), .A2(new_n42_), .B(new_n102_), .Y(new_n103_));
  AND2x2_ASAP7_75t_R   g70(.A(p6), .B(p2), .Y(new_n104_));
  AOI21x1_ASAP7_75t_R  g71(.A1(new_n90_), .A2(new_n104_), .B(p1), .Y(new_n105_));
  OA21x2_ASAP7_75t_R   g72(.A1(new_n36_), .A2(new_n65_), .B(p1), .Y(new_n106_));
  AOI21x1_ASAP7_75t_R  g73(.A1(new_n103_), .A2(new_n105_), .B(new_n106_), .Y(o20));
  NAND2x1_ASAP7_75t_R  g74(.A(p2), .B(new_n90_), .Y(new_n108_));
  OR4x2_ASAP7_75t_R    g75(.A(new_n84_), .B(p5), .C(new_n63_), .D(new_n42_), .Y(new_n109_));
  NAND2x1_ASAP7_75t_R  g76(.A(p6), .B(new_n44_), .Y(new_n110_));
  AOI21x1_ASAP7_75t_R  g77(.A1(new_n108_), .A2(new_n109_), .B(new_n110_), .Y(o21));
  AOI21x1_ASAP7_75t_R  g78(.A1(new_n44_), .A2(new_n66_), .B(new_n106_), .Y(o22));
  assign               o23 = 1'b1;
  OA211x2_ASAP7_75t_R  g79(.A1(new_n65_), .A2(new_n95_), .B(new_n48_), .C(new_n44_), .Y(o24));
  AND3x1_ASAP7_75t_R   g80(.A(new_n48_), .B(p6), .C(new_n38_), .Y(o25));
endmodule


