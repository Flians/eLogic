// Benchmark "/tmp/" written by ABC on Tue Oct 13 18:52:02 2026

module \/tmp/  ( 
    p2, p5, p3, p6, p0, p1, p4,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25  );
  input  p2, p5, p3, p6, p0, p1, p4;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25;
  wire new_n34_, new_n35_, new_n36_, new_n37_, new_n38_, new_n39_, new_n41_,
    new_n43_, new_n44_, new_n45_, new_n46_, new_n47_, new_n48_, new_n49_,
    new_n51_, new_n52_, new_n53_, new_n54_, new_n56_, new_n57_, new_n58_,
    new_n60_, new_n61_, new_n62_, new_n63_, new_n64_, new_n65_, new_n66_,
    new_n67_, new_n68_, new_n69_, new_n71_, new_n73_, new_n74_, new_n76_,
    new_n77_, new_n79_, new_n80_, new_n83_, new_n84_, new_n85_, new_n87_,
    new_n89_, new_n90_, new_n91_, new_n92_, new_n97_, new_n100_, new_n102_,
    new_n103_, new_n105_, new_n106_;
  INVx1_ASAP7_75t_R    g00(.A(p1), .Y(new_n34_));
  NOR2x1_ASAP7_75t_R   g01(.A(p6), .B(p0), .Y(new_n35_));
  NAND2x1_ASAP7_75t_R  g02(.A(p2), .B(p3), .Y(new_n36_));
  AO21x1_ASAP7_75t_R   g03(.A1(new_n34_), .A2(new_n35_), .B(new_n36_), .Y(new_n37_));
  INVx1_ASAP7_75t_R    g04(.A(p2), .Y(new_n38_));
  INVx1_ASAP7_75t_R    g05(.A(p3), .Y(new_n39_));
  AND3x1_ASAP7_75t_R   g06(.A(new_n38_), .B(new_n39_), .C(p1), .Y(o19));
  NAND2x1_ASAP7_75t_R  g07(.A(p0), .B(o19), .Y(new_n41_));
  NAND2x1_ASAP7_75t_R  g08(.A(new_n37_), .B(new_n41_), .Y(o0));
  NAND2x1_ASAP7_75t_R  g09(.A(p3), .B(new_n38_), .Y(new_n43_));
  INVx1_ASAP7_75t_R    g10(.A(p0), .Y(new_n44_));
  NOR2x1_ASAP7_75t_R   g11(.A(p1), .B(new_n44_), .Y(new_n45_));
  AND3x1_ASAP7_75t_R   g12(.A(new_n44_), .B(new_n34_), .C(p6), .Y(new_n46_));
  OAI21x1_ASAP7_75t_R  g13(.A1(p2), .A2(p3), .B(p1), .Y(new_n47_));
  AO21x1_ASAP7_75t_R   g14(.A1(p2), .A2(p3), .B(p0), .Y(new_n48_));
  NAND2x1_ASAP7_75t_R  g15(.A(new_n47_), .B(new_n48_), .Y(new_n49_));
  AOI211x1_ASAP7_75t_R g16(.A1(new_n43_), .A2(new_n45_), .B(new_n46_), .C(new_n49_), .Y(o1));
  INVx1_ASAP7_75t_R    g17(.A(p6), .Y(new_n51_));
  AND3x1_ASAP7_75t_R   g18(.A(new_n38_), .B(new_n51_), .C(p3), .Y(new_n52_));
  AO21x1_ASAP7_75t_R   g19(.A1(p2), .A2(new_n39_), .B(new_n44_), .Y(new_n53_));
  OA21x2_ASAP7_75t_R   g20(.A1(p0), .A2(new_n51_), .B(new_n34_), .Y(new_n54_));
  OA211x2_ASAP7_75t_R  g21(.A1(new_n52_), .A2(new_n53_), .B(new_n54_), .C(new_n48_), .Y(o2));
  NOR2x1_ASAP7_75t_R   g22(.A(p0), .B(p1), .Y(new_n56_));
  NAND2x1_ASAP7_75t_R  g23(.A(p2), .B(new_n56_), .Y(new_n57_));
  INVx1_ASAP7_75t_R    g24(.A(new_n36_), .Y(new_n58_));
  AOI22x1_ASAP7_75t_R  g25(.A1(new_n57_), .A2(new_n43_), .B1(p6), .B2(new_n58_), .Y(o3));
  NAND2x1_ASAP7_75t_R  g26(.A(p0), .B(p4), .Y(new_n60_));
  OA31x2_ASAP7_75t_R   g27(.A1(p6), .A2(new_n36_), .A3(new_n60_), .B1(new_n34_), .Y(new_n61_));
  INVx1_ASAP7_75t_R    g28(.A(p5), .Y(new_n62_));
  AOI21x1_ASAP7_75t_R  g29(.A1(p3), .A2(new_n62_), .B(new_n38_), .Y(new_n63_));
  INVx1_ASAP7_75t_R    g30(.A(p4), .Y(new_n64_));
  NAND3x1_ASAP7_75t_R  g31(.A(new_n64_), .B(p5), .C(p3), .Y(new_n65_));
  AND2x2_ASAP7_75t_R   g32(.A(p6), .B(p0), .Y(new_n66_));
  NAND3x1_ASAP7_75t_R  g33(.A(new_n63_), .B(new_n65_), .C(new_n66_), .Y(new_n67_));
  NOR2x1_ASAP7_75t_R   g34(.A(p6), .B(new_n34_), .Y(new_n68_));
  AO21x1_ASAP7_75t_R   g35(.A1(p1), .A2(new_n43_), .B(new_n68_), .Y(new_n69_));
  AOI21x1_ASAP7_75t_R  g36(.A1(new_n61_), .A2(new_n67_), .B(new_n69_), .Y(o4));
  AO21x1_ASAP7_75t_R   g37(.A1(p3), .A2(new_n38_), .B(new_n34_), .Y(new_n71_));
  OA211x2_ASAP7_75t_R  g38(.A1(p1), .A2(new_n63_), .B(new_n71_), .C(p0), .Y(o5));
  NOR2x1_ASAP7_75t_R   g39(.A(new_n36_), .B(new_n66_), .Y(new_n73_));
  AO21x1_ASAP7_75t_R   g40(.A1(new_n38_), .A2(new_n39_), .B(p1), .Y(new_n74_));
  AOI22x1_ASAP7_75t_R  g41(.A1(new_n73_), .A2(new_n34_), .B1(new_n36_), .B2(new_n74_), .Y(o6));
  AO21x1_ASAP7_75t_R   g42(.A1(p6), .A2(new_n34_), .B(new_n36_), .Y(new_n76_));
  OA21x2_ASAP7_75t_R   g43(.A1(p0), .A2(p1), .B(new_n51_), .Y(new_n77_));
  OAI21x1_ASAP7_75t_R  g44(.A1(new_n76_), .A2(new_n77_), .B(new_n41_), .Y(o7));
  INVx1_ASAP7_75t_R    g45(.A(new_n52_), .Y(new_n79_));
  OAI21x1_ASAP7_75t_R  g46(.A1(new_n47_), .A2(new_n58_), .B(p0), .Y(new_n80_));
  AOI21x1_ASAP7_75t_R  g47(.A1(new_n45_), .A2(new_n79_), .B(new_n80_), .Y(o8));
  AOI21x1_ASAP7_75t_R  g48(.A1(new_n45_), .A2(new_n79_), .B(new_n49_), .Y(o9));
  NOR2x1_ASAP7_75t_R   g49(.A(p2), .B(new_n39_), .Y(new_n83_));
  OAI21x1_ASAP7_75t_R  g50(.A1(p6), .A2(new_n44_), .B(new_n83_), .Y(new_n84_));
  AO22x1_ASAP7_75t_R   g51(.A1(new_n38_), .A2(new_n34_), .B1(p3), .B2(new_n56_), .Y(new_n85_));
  AOI22x1_ASAP7_75t_R  g52(.A1(new_n84_), .A2(new_n85_), .B1(p1), .B2(new_n43_), .Y(o10));
  NOR2x1_ASAP7_75t_R   g53(.A(p2), .B(p3), .Y(new_n87_));
  AND3x1_ASAP7_75t_R   g54(.A(new_n35_), .B(new_n87_), .C(new_n34_), .Y(o11));
  AND3x1_ASAP7_75t_R   g55(.A(new_n38_), .B(new_n51_), .C(new_n44_), .Y(new_n89_));
  NOR2x1_ASAP7_75t_R   g56(.A(p3), .B(new_n38_), .Y(new_n90_));
  NOR2x1_ASAP7_75t_R   g57(.A(p3), .B(p0), .Y(new_n91_));
  OR3x1_ASAP7_75t_R    g58(.A(new_n90_), .B(new_n34_), .C(new_n91_), .Y(new_n92_));
  OAI21x1_ASAP7_75t_R  g59(.A1(new_n74_), .A2(new_n89_), .B(new_n92_), .Y(o12));
  AND3x1_ASAP7_75t_R   g60(.A(new_n87_), .B(p6), .C(p1), .Y(o13));
  AND3x1_ASAP7_75t_R   g61(.A(new_n87_), .B(new_n51_), .C(p1), .Y(o14));
  AND3x1_ASAP7_75t_R   g62(.A(new_n90_), .B(p1), .C(new_n35_), .Y(o15));
  AND2x2_ASAP7_75t_R   g63(.A(p6), .B(p1), .Y(new_n97_));
  AND3x1_ASAP7_75t_R   g64(.A(new_n90_), .B(new_n44_), .C(new_n97_), .Y(o16));
  AND3x1_ASAP7_75t_R   g65(.A(new_n90_), .B(p1), .C(new_n66_), .Y(o17));
  AND2x2_ASAP7_75t_R   g66(.A(p2), .B(p0), .Y(new_n100_));
  AND3x1_ASAP7_75t_R   g67(.A(new_n68_), .B(new_n39_), .C(new_n100_), .Y(o18));
  OA21x2_ASAP7_75t_R   g68(.A1(new_n36_), .A2(new_n66_), .B(p1), .Y(new_n102_));
  AOI211x1_ASAP7_75t_R g69(.A1(p4), .A2(new_n100_), .B(p1), .C(new_n90_), .Y(new_n103_));
  AOI211x1_ASAP7_75t_R g70(.A1(new_n51_), .A2(new_n34_), .B(new_n102_), .C(new_n103_), .Y(o20));
  NAND2x1_ASAP7_75t_R  g71(.A(p2), .B(new_n91_), .Y(new_n105_));
  OR3x1_ASAP7_75t_R    g72(.A(new_n36_), .B(new_n60_), .C(p5), .Y(new_n106_));
  AOI211x1_ASAP7_75t_R g73(.A1(new_n105_), .A2(new_n106_), .B(new_n51_), .C(p1), .Y(o21));
  AOI21x1_ASAP7_75t_R  g74(.A1(new_n34_), .A2(new_n67_), .B(new_n102_), .Y(o22));
  assign               o23 = 1'b1;
  OA211x2_ASAP7_75t_R  g75(.A1(p6), .A2(new_n44_), .B(new_n54_), .C(new_n83_), .Y(o24));
  AND3x1_ASAP7_75t_R   g76(.A(new_n83_), .B(p6), .C(new_n56_), .Y(o25));
endmodule


