// Benchmark "/tmp/" written by ABC on Tue Oct 13 18:51:57 2026

module \/tmp/  ( 
    p5, p0, p4, p6, p2, p1, p3,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25  );
  input  p5, p0, p4, p6, p2, p1, p3;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25;
  wire new_n34_, new_n35_, new_n36_, new_n37_, new_n38_, new_n39_, new_n40_,
    new_n42_, new_n43_, new_n44_, new_n45_, new_n46_, new_n47_, new_n48_,
    new_n50_, new_n51_, new_n52_, new_n53_, new_n55_, new_n56_, new_n58_,
    new_n59_, new_n60_, new_n61_, new_n62_, new_n63_, new_n64_, new_n65_,
    new_n66_, new_n67_, new_n69_, new_n70_, new_n72_, new_n73_, new_n74_,
    new_n75_, new_n77_, new_n78_, new_n79_, new_n81_, new_n82_, new_n84_,
    new_n85_, new_n87_, new_n88_, new_n89_, new_n92_, new_n93_, new_n94_,
    new_n99_, new_n104_, new_n105_, new_n106_, new_n108_, new_n109_,
    new_n110_, new_n111_;
  INVx1_ASAP7_75t_R    g00(.A(p6), .Y(new_n34_));
  NOR2x1_ASAP7_75t_R   g01(.A(p0), .B(p1), .Y(new_n35_));
  NAND2x1_ASAP7_75t_R  g02(.A(p2), .B(p3), .Y(new_n36_));
  AO21x1_ASAP7_75t_R   g03(.A1(new_n34_), .A2(new_n35_), .B(new_n36_), .Y(new_n37_));
  INVx1_ASAP7_75t_R    g04(.A(p0), .Y(new_n38_));
  INVx1_ASAP7_75t_R    g05(.A(p1), .Y(new_n39_));
  OR4x2_ASAP7_75t_R    g06(.A(new_n38_), .B(new_n39_), .C(p2), .D(p3), .Y(new_n40_));
  NAND2x1_ASAP7_75t_R  g07(.A(new_n37_), .B(new_n40_), .Y(o0));
  INVx1_ASAP7_75t_R    g08(.A(p2), .Y(new_n42_));
  INVx1_ASAP7_75t_R    g09(.A(p3), .Y(new_n43_));
  OR3x1_ASAP7_75t_R    g10(.A(new_n42_), .B(new_n43_), .C(p6), .Y(new_n44_));
  OA31x2_ASAP7_75t_R   g11(.A1(p2), .A2(p3), .A3(new_n38_), .B1(p1), .Y(new_n45_));
  NAND2x1_ASAP7_75t_R  g12(.A(p0), .B(new_n39_), .Y(new_n46_));
  NOR2x1_ASAP7_75t_R   g13(.A(p2), .B(new_n43_), .Y(new_n47_));
  NOR2x1_ASAP7_75t_R   g14(.A(new_n46_), .B(new_n47_), .Y(new_n48_));
  AOI211x1_ASAP7_75t_R g15(.A1(new_n35_), .A2(new_n44_), .B(new_n45_), .C(new_n48_), .Y(o1));
  NOR2x1_ASAP7_75t_R   g16(.A(p3), .B(new_n42_), .Y(new_n50_));
  NOR2x1_ASAP7_75t_R   g17(.A(new_n38_), .B(new_n50_), .Y(new_n51_));
  OR3x1_ASAP7_75t_R    g18(.A(new_n43_), .B(p6), .C(p2), .Y(new_n52_));
  OR3x1_ASAP7_75t_R    g19(.A(new_n36_), .B(p6), .C(p1), .Y(new_n53_));
  AOI22x1_ASAP7_75t_R  g20(.A1(new_n51_), .A2(new_n52_), .B1(new_n46_), .B2(new_n53_), .Y(o2));
  AND2x2_ASAP7_75t_R   g21(.A(p6), .B(p2), .Y(new_n55_));
  NOR2x1_ASAP7_75t_R   g22(.A(new_n43_), .B(new_n55_), .Y(new_n56_));
  OA22x2_ASAP7_75t_R   g23(.A1(new_n56_), .A2(new_n50_), .B1(new_n42_), .B2(new_n35_), .Y(o3));
  AND3x1_ASAP7_75t_R   g24(.A(p4), .B(p2), .C(p3), .Y(new_n58_));
  NOR2x1_ASAP7_75t_R   g25(.A(p6), .B(new_n38_), .Y(new_n59_));
  AOI21x1_ASAP7_75t_R  g26(.A1(new_n58_), .A2(new_n59_), .B(p1), .Y(new_n60_));
  INVx1_ASAP7_75t_R    g27(.A(p5), .Y(new_n61_));
  NAND2x1_ASAP7_75t_R  g28(.A(p3), .B(new_n61_), .Y(new_n62_));
  INVx1_ASAP7_75t_R    g29(.A(p4), .Y(new_n63_));
  NAND2x1_ASAP7_75t_R  g30(.A(p3), .B(new_n63_), .Y(new_n64_));
  AND3x1_ASAP7_75t_R   g31(.A(p0), .B(p6), .C(p2), .Y(new_n65_));
  NAND3x1_ASAP7_75t_R  g32(.A(new_n62_), .B(new_n64_), .C(new_n65_), .Y(new_n66_));
  AOI21x1_ASAP7_75t_R  g33(.A1(p6), .A2(new_n47_), .B(new_n39_), .Y(new_n67_));
  AOI21x1_ASAP7_75t_R  g34(.A1(new_n60_), .A2(new_n66_), .B(new_n67_), .Y(o4));
  AO21x1_ASAP7_75t_R   g35(.A1(p3), .A2(new_n61_), .B(new_n42_), .Y(new_n69_));
  NOR2x1_ASAP7_75t_R   g36(.A(new_n39_), .B(new_n47_), .Y(new_n70_));
  AOI211x1_ASAP7_75t_R g37(.A1(new_n39_), .A2(new_n69_), .B(new_n38_), .C(new_n70_), .Y(o5));
  AND2x2_ASAP7_75t_R   g38(.A(p0), .B(p6), .Y(new_n72_));
  NOR2x1_ASAP7_75t_R   g39(.A(new_n36_), .B(new_n72_), .Y(new_n73_));
  NOR2x1_ASAP7_75t_R   g40(.A(p2), .B(p3), .Y(new_n74_));
  AO21x1_ASAP7_75t_R   g41(.A1(p1), .A2(new_n36_), .B(new_n74_), .Y(new_n75_));
  AOI21x1_ASAP7_75t_R  g42(.A1(new_n39_), .A2(new_n73_), .B(new_n75_), .Y(o6));
  OR4x2_ASAP7_75t_R    g43(.A(new_n36_), .B(p0), .C(p6), .D(p1), .Y(new_n77_));
  AND2x2_ASAP7_75t_R   g44(.A(p1), .B(p3), .Y(new_n78_));
  NAND2x1_ASAP7_75t_R  g45(.A(new_n78_), .B(new_n55_), .Y(new_n79_));
  NAND3x1_ASAP7_75t_R  g46(.A(new_n77_), .B(new_n40_), .C(new_n79_), .Y(o7));
  AND2x2_ASAP7_75t_R   g47(.A(p2), .B(p3), .Y(new_n81_));
  NOR3x1_ASAP7_75t_R   g48(.A(new_n81_), .B(new_n39_), .C(new_n74_), .Y(new_n82_));
  AOI211x1_ASAP7_75t_R g49(.A1(new_n39_), .A2(new_n52_), .B(new_n38_), .C(new_n82_), .Y(o8));
  INVx1_ASAP7_75t_R    g50(.A(new_n46_), .Y(new_n84_));
  AND3x1_ASAP7_75t_R   g51(.A(new_n36_), .B(new_n38_), .C(new_n39_), .Y(new_n85_));
  AOI211x1_ASAP7_75t_R g52(.A1(new_n52_), .A2(new_n84_), .B(new_n45_), .C(new_n85_), .Y(o9));
  NOR2x1_ASAP7_75t_R   g53(.A(p2), .B(p1), .Y(new_n87_));
  AO21x1_ASAP7_75t_R   g54(.A1(p3), .A2(new_n35_), .B(new_n87_), .Y(new_n88_));
  INVx1_ASAP7_75t_R    g55(.A(new_n47_), .Y(new_n89_));
  OAI22x1_ASAP7_75t_R  g56(.A1(new_n70_), .A2(new_n88_), .B1(new_n89_), .B2(new_n59_), .Y(o10));
  AND3x1_ASAP7_75t_R   g57(.A(new_n74_), .B(new_n35_), .C(new_n34_), .Y(o11));
  AO21x1_ASAP7_75t_R   g58(.A1(p0), .A2(new_n42_), .B(new_n39_), .Y(new_n92_));
  NOR2x1_ASAP7_75t_R   g59(.A(p0), .B(p6), .Y(new_n93_));
  OAI21x1_ASAP7_75t_R  g60(.A1(new_n43_), .A2(new_n93_), .B(new_n87_), .Y(new_n94_));
  AO21x1_ASAP7_75t_R   g61(.A1(new_n92_), .A2(new_n94_), .B(new_n78_), .Y(o12));
  AND3x1_ASAP7_75t_R   g62(.A(new_n74_), .B(p6), .C(p1), .Y(o13));
  AND3x1_ASAP7_75t_R   g63(.A(new_n74_), .B(new_n34_), .C(p1), .Y(o14));
  AND3x1_ASAP7_75t_R   g64(.A(new_n50_), .B(p1), .C(new_n93_), .Y(o15));
  NOR2x1_ASAP7_75t_R   g65(.A(p0), .B(p3), .Y(new_n99_));
  AND3x1_ASAP7_75t_R   g66(.A(new_n55_), .B(p1), .C(new_n99_), .Y(o16));
  AND3x1_ASAP7_75t_R   g67(.A(new_n65_), .B(p1), .C(new_n43_), .Y(o17));
  AND3x1_ASAP7_75t_R   g68(.A(new_n50_), .B(new_n59_), .C(p1), .Y(o18));
  AND3x1_ASAP7_75t_R   g69(.A(new_n42_), .B(new_n43_), .C(p1), .Y(o19));
  NAND2x1_ASAP7_75t_R  g70(.A(new_n65_), .B(new_n64_), .Y(new_n104_));
  AOI21x1_ASAP7_75t_R  g71(.A1(new_n99_), .A2(new_n55_), .B(p1), .Y(new_n105_));
  OA21x2_ASAP7_75t_R   g72(.A1(new_n36_), .A2(new_n72_), .B(p1), .Y(new_n106_));
  AOI21x1_ASAP7_75t_R  g73(.A1(new_n104_), .A2(new_n105_), .B(new_n106_), .Y(o20));
  NAND2x1_ASAP7_75t_R  g74(.A(p2), .B(new_n99_), .Y(new_n108_));
  NAND2x1_ASAP7_75t_R  g75(.A(p0), .B(p4), .Y(new_n109_));
  OR4x2_ASAP7_75t_R    g76(.A(new_n109_), .B(p5), .C(new_n42_), .D(new_n43_), .Y(new_n110_));
  NAND2x1_ASAP7_75t_R  g77(.A(p6), .B(new_n39_), .Y(new_n111_));
  AOI21x1_ASAP7_75t_R  g78(.A1(new_n108_), .A2(new_n110_), .B(new_n111_), .Y(o21));
  AOI21x1_ASAP7_75t_R  g79(.A1(new_n39_), .A2(new_n66_), .B(new_n106_), .Y(o22));
  assign               o23 = 1'b1;
  OA211x2_ASAP7_75t_R  g80(.A1(new_n93_), .A2(new_n72_), .B(p3), .C(new_n87_), .Y(o24));
  AND3x1_ASAP7_75t_R   g81(.A(new_n47_), .B(p6), .C(new_n35_), .Y(o25));
endmodule


