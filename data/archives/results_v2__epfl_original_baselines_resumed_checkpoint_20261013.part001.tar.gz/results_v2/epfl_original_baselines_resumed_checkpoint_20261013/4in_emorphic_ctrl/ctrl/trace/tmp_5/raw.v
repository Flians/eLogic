// Benchmark "/tmp/" written by ABC on Tue Oct 13 18:51:57 2026

module \/tmp/  ( 
    p0, p3, p6, p4, p2, p1, p5,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25  );
  input  p0, p3, p6, p4, p2, p1, p5;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25;
  wire new_n34_, new_n35_, new_n36_, new_n37_, new_n38_, new_n39_, new_n41_,
    new_n42_, new_n43_, new_n44_, new_n45_, new_n46_, new_n47_, new_n48_,
    new_n50_, new_n51_, new_n52_, new_n53_, new_n55_, new_n56_, new_n58_,
    new_n59_, new_n60_, new_n61_, new_n62_, new_n63_, new_n64_, new_n65_,
    new_n67_, new_n68_, new_n69_, new_n71_, new_n72_, new_n73_, new_n74_,
    new_n76_, new_n77_, new_n79_, new_n80_, new_n82_, new_n84_, new_n85_,
    new_n86_, new_n87_, new_n90_, new_n91_, new_n92_, new_n96_, new_n100_,
    new_n103_, new_n104_, new_n105_, new_n107_, new_n108_;
  INVx1_ASAP7_75t_R    g00(.A(p0), .Y(new_n34_));
  INVx1_ASAP7_75t_R    g01(.A(p1), .Y(new_n35_));
  OR4x2_ASAP7_75t_R    g02(.A(new_n34_), .B(new_n35_), .C(p3), .D(p2), .Y(new_n36_));
  NAND2x1_ASAP7_75t_R  g03(.A(p3), .B(p2), .Y(new_n37_));
  INVx1_ASAP7_75t_R    g04(.A(p6), .Y(new_n38_));
  NOR2x1_ASAP7_75t_R   g05(.A(p0), .B(p1), .Y(new_n39_));
  AOI22x1_ASAP7_75t_R  g06(.A1(new_n36_), .A2(new_n37_), .B1(new_n38_), .B2(new_n39_), .Y(o0));
  INVx1_ASAP7_75t_R    g07(.A(p3), .Y(new_n41_));
  INVx1_ASAP7_75t_R    g08(.A(p2), .Y(new_n42_));
  OR3x1_ASAP7_75t_R    g09(.A(new_n41_), .B(new_n42_), .C(p6), .Y(new_n43_));
  NOR2x1_ASAP7_75t_R   g10(.A(p3), .B(p2), .Y(new_n44_));
  AOI21x1_ASAP7_75t_R  g11(.A1(p0), .A2(new_n44_), .B(new_n35_), .Y(new_n45_));
  NAND2x1_ASAP7_75t_R  g12(.A(p0), .B(new_n35_), .Y(new_n46_));
  NOR2x1_ASAP7_75t_R   g13(.A(p2), .B(new_n41_), .Y(new_n47_));
  NOR2x1_ASAP7_75t_R   g14(.A(new_n46_), .B(new_n47_), .Y(new_n48_));
  AOI211x1_ASAP7_75t_R g15(.A1(new_n39_), .A2(new_n43_), .B(new_n45_), .C(new_n48_), .Y(o1));
  NOR2x1_ASAP7_75t_R   g16(.A(p3), .B(new_n42_), .Y(new_n50_));
  NOR2x1_ASAP7_75t_R   g17(.A(new_n34_), .B(new_n50_), .Y(new_n51_));
  OR3x1_ASAP7_75t_R    g18(.A(new_n41_), .B(p6), .C(p2), .Y(new_n52_));
  OR3x1_ASAP7_75t_R    g19(.A(new_n37_), .B(p6), .C(p1), .Y(new_n53_));
  AOI22x1_ASAP7_75t_R  g20(.A1(new_n51_), .A2(new_n52_), .B1(new_n46_), .B2(new_n53_), .Y(o2));
  AND2x2_ASAP7_75t_R   g21(.A(p6), .B(p2), .Y(new_n55_));
  AOI21x1_ASAP7_75t_R  g22(.A1(p3), .A2(new_n55_), .B(new_n44_), .Y(new_n56_));
  OA21x2_ASAP7_75t_R   g23(.A1(new_n42_), .A2(new_n39_), .B(new_n56_), .Y(o3));
  NAND2x1_ASAP7_75t_R  g24(.A(p0), .B(p4), .Y(new_n58_));
  OA31x2_ASAP7_75t_R   g25(.A1(p6), .A2(new_n37_), .A3(new_n58_), .B1(new_n35_), .Y(new_n59_));
  AND3x1_ASAP7_75t_R   g26(.A(p0), .B(p6), .C(p2), .Y(new_n60_));
  INVx1_ASAP7_75t_R    g27(.A(p4), .Y(new_n61_));
  INVx1_ASAP7_75t_R    g28(.A(p5), .Y(new_n62_));
  OAI21x1_ASAP7_75t_R  g29(.A1(new_n61_), .A2(new_n62_), .B(p3), .Y(new_n63_));
  NAND2x1_ASAP7_75t_R  g30(.A(new_n60_), .B(new_n63_), .Y(new_n64_));
  AOI21x1_ASAP7_75t_R  g31(.A1(p6), .A2(new_n47_), .B(new_n35_), .Y(new_n65_));
  AOI21x1_ASAP7_75t_R  g32(.A1(new_n59_), .A2(new_n64_), .B(new_n65_), .Y(o4));
  AND3x1_ASAP7_75t_R   g33(.A(new_n42_), .B(p0), .C(p3), .Y(new_n67_));
  NOR2x1_ASAP7_75t_R   g34(.A(p1), .B(new_n34_), .Y(new_n68_));
  AO21x1_ASAP7_75t_R   g35(.A1(p2), .A2(p5), .B(p1), .Y(new_n69_));
  OA22x2_ASAP7_75t_R   g36(.A1(new_n67_), .A2(new_n68_), .B1(new_n50_), .B2(new_n69_), .Y(o5));
  INVx1_ASAP7_75t_R    g37(.A(new_n37_), .Y(new_n71_));
  AO21x1_ASAP7_75t_R   g38(.A1(new_n41_), .A2(new_n42_), .B(p1), .Y(new_n72_));
  AND2x2_ASAP7_75t_R   g39(.A(p0), .B(p6), .Y(new_n73_));
  OAI21x1_ASAP7_75t_R  g40(.A1(p1), .A2(new_n73_), .B(new_n71_), .Y(new_n74_));
  OAI21x1_ASAP7_75t_R  g41(.A1(new_n71_), .A2(new_n72_), .B(new_n74_), .Y(o6));
  OR4x2_ASAP7_75t_R    g42(.A(new_n37_), .B(p0), .C(p6), .D(p1), .Y(new_n76_));
  OR3x1_ASAP7_75t_R    g43(.A(new_n37_), .B(new_n38_), .C(new_n35_), .Y(new_n77_));
  NAND3x1_ASAP7_75t_R  g44(.A(new_n76_), .B(new_n36_), .C(new_n77_), .Y(o7));
  AO21x1_ASAP7_75t_R   g45(.A1(p1), .A2(new_n37_), .B(new_n34_), .Y(new_n79_));
  NAND2x1_ASAP7_75t_R  g46(.A(p0), .B(new_n44_), .Y(new_n80_));
  AOI22x1_ASAP7_75t_R  g47(.A1(new_n79_), .A2(new_n80_), .B1(new_n68_), .B2(new_n52_), .Y(o8));
  AND2x2_ASAP7_75t_R   g48(.A(new_n34_), .B(new_n37_), .Y(new_n82_));
  AOI211x1_ASAP7_75t_R g49(.A1(new_n68_), .A2(new_n52_), .B(new_n45_), .C(new_n82_), .Y(o9));
  NAND2x1_ASAP7_75t_R  g50(.A(p0), .B(new_n38_), .Y(new_n84_));
  AO21x1_ASAP7_75t_R   g51(.A1(p3), .A2(new_n42_), .B(new_n35_), .Y(new_n85_));
  NOR2x1_ASAP7_75t_R   g52(.A(p2), .B(p1), .Y(new_n86_));
  AOI21x1_ASAP7_75t_R  g53(.A1(p3), .A2(new_n39_), .B(new_n86_), .Y(new_n87_));
  AO22x1_ASAP7_75t_R   g54(.A1(new_n47_), .A2(new_n84_), .B1(new_n85_), .B2(new_n87_), .Y(o10));
  AND3x1_ASAP7_75t_R   g55(.A(new_n39_), .B(new_n44_), .C(new_n38_), .Y(o11));
  AND3x1_ASAP7_75t_R   g56(.A(new_n34_), .B(new_n38_), .C(new_n42_), .Y(new_n90_));
  AO21x1_ASAP7_75t_R   g57(.A1(p2), .A2(new_n41_), .B(new_n35_), .Y(new_n91_));
  NOR2x1_ASAP7_75t_R   g58(.A(p0), .B(p3), .Y(new_n92_));
  OAI22x1_ASAP7_75t_R  g59(.A1(new_n90_), .A2(new_n72_), .B1(new_n91_), .B2(new_n92_), .Y(o12));
  AND3x1_ASAP7_75t_R   g60(.A(new_n44_), .B(p6), .C(p1), .Y(o13));
  AND3x1_ASAP7_75t_R   g61(.A(new_n44_), .B(new_n38_), .C(p1), .Y(o14));
  NOR2x1_ASAP7_75t_R   g62(.A(p0), .B(p6), .Y(new_n96_));
  AND3x1_ASAP7_75t_R   g63(.A(new_n50_), .B(p1), .C(new_n96_), .Y(o15));
  AND3x1_ASAP7_75t_R   g64(.A(new_n55_), .B(p1), .C(new_n92_), .Y(o16));
  AND3x1_ASAP7_75t_R   g65(.A(new_n50_), .B(p1), .C(new_n73_), .Y(o17));
  AND2x2_ASAP7_75t_R   g66(.A(p0), .B(p1), .Y(new_n100_));
  AND3x1_ASAP7_75t_R   g67(.A(new_n50_), .B(new_n38_), .C(new_n100_), .Y(o18));
  AND3x1_ASAP7_75t_R   g68(.A(new_n41_), .B(new_n42_), .C(p1), .Y(o19));
  OAI21x1_ASAP7_75t_R  g69(.A1(new_n41_), .A2(p4), .B(new_n60_), .Y(new_n103_));
  AOI21x1_ASAP7_75t_R  g70(.A1(new_n92_), .A2(new_n55_), .B(p1), .Y(new_n104_));
  OA21x2_ASAP7_75t_R   g71(.A1(new_n37_), .A2(new_n73_), .B(p1), .Y(new_n105_));
  AOI21x1_ASAP7_75t_R  g72(.A1(new_n103_), .A2(new_n104_), .B(new_n105_), .Y(o20));
  NOR3x1_ASAP7_75t_R   g73(.A(new_n58_), .B(new_n41_), .C(p5), .Y(new_n107_));
  NOR2x1_ASAP7_75t_R   g74(.A(p1), .B(new_n38_), .Y(new_n108_));
  OA211x2_ASAP7_75t_R  g75(.A1(new_n92_), .A2(new_n107_), .B(p2), .C(new_n108_), .Y(o21));
  AOI21x1_ASAP7_75t_R  g76(.A1(new_n35_), .A2(new_n64_), .B(new_n105_), .Y(o22));
  assign               o23 = 1'b1;
  OA211x2_ASAP7_75t_R  g77(.A1(new_n96_), .A2(new_n73_), .B(p3), .C(new_n86_), .Y(o24));
  AND3x1_ASAP7_75t_R   g78(.A(new_n47_), .B(p6), .C(new_n39_), .Y(o25));
endmodule


