// Benchmark "/tmp/" written by ABC on Tue Oct 13 18:51:59 2026

module \/tmp/  ( 
    p1, p6, p4, p2, p0, p3, p5,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25  );
  input  p1, p6, p4, p2, p0, p3, p5;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25;
  wire new_n34_, new_n35_, new_n36_, new_n37_, new_n38_, new_n41_, new_n42_,
    new_n43_, new_n44_, new_n45_, new_n46_, new_n47_, new_n48_, new_n50_,
    new_n51_, new_n52_, new_n53_, new_n54_, new_n56_, new_n57_, new_n58_,
    new_n60_, new_n61_, new_n62_, new_n63_, new_n64_, new_n65_, new_n66_,
    new_n67_, new_n68_, new_n69_, new_n70_, new_n72_, new_n74_, new_n75_,
    new_n76_, new_n78_, new_n79_, new_n81_, new_n83_, new_n84_, new_n86_,
    new_n87_, new_n90_, new_n91_, new_n96_, new_n100_, new_n101_,
    new_n103_, new_n104_, new_n106_, new_n107_, new_n108_, new_n111_;
  NAND2x1_ASAP7_75t_R  g00(.A(p2), .B(p3), .Y(new_n34_));
  INVx1_ASAP7_75t_R    g01(.A(new_n34_), .Y(new_n35_));
  OR3x1_ASAP7_75t_R    g02(.A(p1), .B(p6), .C(p0), .Y(new_n36_));
  INVx1_ASAP7_75t_R    g03(.A(p2), .Y(new_n37_));
  INVx1_ASAP7_75t_R    g04(.A(p3), .Y(new_n38_));
  AND3x1_ASAP7_75t_R   g05(.A(new_n37_), .B(new_n38_), .C(p1), .Y(o19));
  AO22x1_ASAP7_75t_R   g06(.A1(new_n35_), .A2(new_n36_), .B1(p0), .B2(o19), .Y(o0));
  NOR2x1_ASAP7_75t_R   g07(.A(p1), .B(p0), .Y(new_n41_));
  OR3x1_ASAP7_75t_R    g08(.A(new_n37_), .B(new_n38_), .C(p6), .Y(new_n42_));
  NOR2x1_ASAP7_75t_R   g09(.A(p2), .B(p3), .Y(new_n43_));
  INVx1_ASAP7_75t_R    g10(.A(p1), .Y(new_n44_));
  AOI21x1_ASAP7_75t_R  g11(.A1(p0), .A2(new_n43_), .B(new_n44_), .Y(new_n45_));
  NAND2x1_ASAP7_75t_R  g12(.A(p0), .B(new_n44_), .Y(new_n46_));
  NOR2x1_ASAP7_75t_R   g13(.A(p2), .B(new_n38_), .Y(new_n47_));
  NOR2x1_ASAP7_75t_R   g14(.A(new_n46_), .B(new_n47_), .Y(new_n48_));
  AOI211x1_ASAP7_75t_R g15(.A1(new_n41_), .A2(new_n42_), .B(new_n45_), .C(new_n48_), .Y(o1));
  INVx1_ASAP7_75t_R    g16(.A(p0), .Y(new_n50_));
  NOR2x1_ASAP7_75t_R   g17(.A(p3), .B(new_n37_), .Y(new_n51_));
  NOR2x1_ASAP7_75t_R   g18(.A(new_n50_), .B(new_n51_), .Y(new_n52_));
  OR3x1_ASAP7_75t_R    g19(.A(new_n38_), .B(p6), .C(p2), .Y(new_n53_));
  OR3x1_ASAP7_75t_R    g20(.A(new_n34_), .B(p1), .C(p6), .Y(new_n54_));
  AOI22x1_ASAP7_75t_R  g21(.A1(new_n52_), .A2(new_n53_), .B1(new_n46_), .B2(new_n54_), .Y(o2));
  INVx1_ASAP7_75t_R    g22(.A(p6), .Y(new_n56_));
  AO21x1_ASAP7_75t_R   g23(.A1(new_n44_), .A2(new_n50_), .B(new_n37_), .Y(new_n57_));
  INVx1_ASAP7_75t_R    g24(.A(new_n43_), .Y(new_n58_));
  OA211x2_ASAP7_75t_R  g25(.A1(new_n56_), .A2(new_n34_), .B(new_n57_), .C(new_n58_), .Y(o3));
  NAND2x1_ASAP7_75t_R  g26(.A(p4), .B(p0), .Y(new_n60_));
  OA31x2_ASAP7_75t_R   g27(.A1(p6), .A2(new_n34_), .A3(new_n60_), .B1(new_n44_), .Y(new_n61_));
  INVx1_ASAP7_75t_R    g28(.A(p5), .Y(new_n62_));
  AOI21x1_ASAP7_75t_R  g29(.A1(p3), .A2(new_n62_), .B(new_n37_), .Y(new_n63_));
  INVx1_ASAP7_75t_R    g30(.A(p4), .Y(new_n64_));
  NAND3x1_ASAP7_75t_R  g31(.A(new_n64_), .B(p3), .C(p5), .Y(new_n65_));
  AND2x2_ASAP7_75t_R   g32(.A(p6), .B(p0), .Y(new_n66_));
  NAND3x1_ASAP7_75t_R  g33(.A(new_n63_), .B(new_n65_), .C(new_n66_), .Y(new_n67_));
  NAND2x1_ASAP7_75t_R  g34(.A(p3), .B(new_n37_), .Y(new_n68_));
  NOR2x1_ASAP7_75t_R   g35(.A(p6), .B(new_n44_), .Y(new_n69_));
  AO21x1_ASAP7_75t_R   g36(.A1(p1), .A2(new_n68_), .B(new_n69_), .Y(new_n70_));
  AOI21x1_ASAP7_75t_R  g37(.A1(new_n61_), .A2(new_n67_), .B(new_n70_), .Y(o4));
  AO21x1_ASAP7_75t_R   g38(.A1(p3), .A2(new_n37_), .B(new_n44_), .Y(new_n72_));
  OA211x2_ASAP7_75t_R  g39(.A1(p1), .A2(new_n63_), .B(new_n72_), .C(p0), .Y(o5));
  AO21x1_ASAP7_75t_R   g40(.A1(new_n37_), .A2(new_n38_), .B(p1), .Y(new_n74_));
  NOR2x1_ASAP7_75t_R   g41(.A(p1), .B(p6), .Y(new_n75_));
  OR3x1_ASAP7_75t_R    g42(.A(new_n41_), .B(new_n75_), .C(new_n34_), .Y(new_n76_));
  OAI21x1_ASAP7_75t_R  g43(.A1(new_n35_), .A2(new_n74_), .B(new_n76_), .Y(o6));
  NAND2x1_ASAP7_75t_R  g44(.A(p1), .B(p6), .Y(new_n78_));
  AOI21x1_ASAP7_75t_R  g45(.A1(new_n78_), .A2(new_n36_), .B(new_n34_), .Y(new_n79_));
  AO21x1_ASAP7_75t_R   g46(.A1(p0), .A2(o19), .B(new_n79_), .Y(o7));
  NOR3x1_ASAP7_75t_R   g47(.A(new_n35_), .B(new_n44_), .C(new_n43_), .Y(new_n81_));
  AOI211x1_ASAP7_75t_R g48(.A1(new_n44_), .A2(new_n53_), .B(new_n50_), .C(new_n81_), .Y(o8));
  INVx1_ASAP7_75t_R    g49(.A(new_n46_), .Y(new_n83_));
  AND3x1_ASAP7_75t_R   g50(.A(new_n34_), .B(new_n44_), .C(new_n50_), .Y(new_n84_));
  AOI211x1_ASAP7_75t_R g51(.A1(new_n53_), .A2(new_n83_), .B(new_n45_), .C(new_n84_), .Y(o9));
  AOI22x1_ASAP7_75t_R  g52(.A1(new_n41_), .A2(p3), .B1(new_n44_), .B2(new_n37_), .Y(new_n86_));
  OA211x2_ASAP7_75t_R  g53(.A1(p6), .A2(new_n50_), .B(new_n37_), .C(p3), .Y(new_n87_));
  AO21x1_ASAP7_75t_R   g54(.A1(new_n72_), .A2(new_n86_), .B(new_n87_), .Y(o10));
  AND3x1_ASAP7_75t_R   g55(.A(new_n43_), .B(new_n41_), .C(new_n56_), .Y(o11));
  OA21x2_ASAP7_75t_R   g56(.A1(p2), .A2(new_n50_), .B(new_n38_), .Y(new_n90_));
  AND3x1_ASAP7_75t_R   g57(.A(new_n56_), .B(new_n37_), .C(new_n50_), .Y(new_n91_));
  OAI22x1_ASAP7_75t_R  g58(.A1(new_n90_), .A2(new_n44_), .B1(new_n91_), .B2(new_n74_), .Y(o12));
  AND3x1_ASAP7_75t_R   g59(.A(new_n43_), .B(p1), .C(p6), .Y(o13));
  AND3x1_ASAP7_75t_R   g60(.A(new_n43_), .B(p1), .C(new_n56_), .Y(o14));
  AND3x1_ASAP7_75t_R   g61(.A(new_n51_), .B(new_n69_), .C(new_n50_), .Y(o15));
  NOR2x1_ASAP7_75t_R   g62(.A(p0), .B(new_n56_), .Y(new_n96_));
  AND3x1_ASAP7_75t_R   g63(.A(new_n51_), .B(new_n96_), .C(p1), .Y(o16));
  AND3x1_ASAP7_75t_R   g64(.A(new_n51_), .B(p1), .C(new_n66_), .Y(o17));
  AND3x1_ASAP7_75t_R   g65(.A(new_n51_), .B(new_n69_), .C(p0), .Y(o18));
  AO21x1_ASAP7_75t_R   g66(.A1(p3), .A2(new_n60_), .B(new_n37_), .Y(new_n100_));
  OA21x2_ASAP7_75t_R   g67(.A1(new_n34_), .A2(new_n66_), .B(p1), .Y(new_n101_));
  AOI211x1_ASAP7_75t_R g68(.A1(new_n44_), .A2(new_n100_), .B(new_n75_), .C(new_n101_), .Y(o20));
  OR3x1_ASAP7_75t_R    g69(.A(new_n37_), .B(p0), .C(p3), .Y(new_n103_));
  OR3x1_ASAP7_75t_R    g70(.A(new_n34_), .B(new_n60_), .C(p5), .Y(new_n104_));
  AOI211x1_ASAP7_75t_R g71(.A1(new_n103_), .A2(new_n104_), .B(p1), .C(new_n56_), .Y(o21));
  NAND2x1_ASAP7_75t_R  g72(.A(p3), .B(p5), .Y(new_n106_));
  OAI21x1_ASAP7_75t_R  g73(.A1(p4), .A2(new_n106_), .B(new_n66_), .Y(new_n107_));
  NOR2x1_ASAP7_75t_R   g74(.A(p1), .B(new_n63_), .Y(new_n108_));
  AOI211x1_ASAP7_75t_R g75(.A1(new_n44_), .A2(new_n107_), .B(new_n101_), .C(new_n108_), .Y(o22));
  assign               o23 = 1'b1;
  NOR2x1_ASAP7_75t_R   g76(.A(p1), .B(new_n96_), .Y(new_n111_));
  AND2x2_ASAP7_75t_R   g77(.A(new_n111_), .B(new_n87_), .Y(o24));
  AND3x1_ASAP7_75t_R   g78(.A(new_n47_), .B(new_n96_), .C(new_n44_), .Y(o25));
endmodule


