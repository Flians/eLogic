// Benchmark "/tmp/" written by ABC on Tue Oct 13 18:51:59 2026

module \/tmp/  ( 
    p2, p3, p4, p0, p5, p1, p6,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25  );
  input  p2, p3, p4, p0, p5, p1, p6;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25;
  wire new_n34_, new_n35_, new_n36_, new_n37_, new_n38_, new_n39_, new_n41_,
    new_n43_, new_n44_, new_n45_, new_n46_, new_n47_, new_n48_, new_n49_,
    new_n51_, new_n52_, new_n53_, new_n54_, new_n55_, new_n57_, new_n58_,
    new_n60_, new_n61_, new_n62_, new_n63_, new_n64_, new_n65_, new_n66_,
    new_n67_, new_n68_, new_n69_, new_n70_, new_n72_, new_n74_, new_n75_,
    new_n77_, new_n78_, new_n79_, new_n81_, new_n84_, new_n85_, new_n86_,
    new_n88_, new_n90_, new_n91_, new_n92_, new_n97_, new_n101_, new_n102_,
    new_n103_, new_n104_, new_n105_, new_n107_, new_n111_;
  INVx1_ASAP7_75t_R    g00(.A(p1), .Y(new_n34_));
  NOR2x1_ASAP7_75t_R   g01(.A(p0), .B(p6), .Y(new_n35_));
  NAND2x1_ASAP7_75t_R  g02(.A(p2), .B(p3), .Y(new_n36_));
  AO21x1_ASAP7_75t_R   g03(.A1(new_n34_), .A2(new_n35_), .B(new_n36_), .Y(new_n37_));
  INVx1_ASAP7_75t_R    g04(.A(p2), .Y(new_n38_));
  INVx1_ASAP7_75t_R    g05(.A(p3), .Y(new_n39_));
  AND3x1_ASAP7_75t_R   g06(.A(new_n38_), .B(new_n39_), .C(p1), .Y(o19));
  NAND2x1_ASAP7_75t_R  g07(.A(p0), .B(o19), .Y(new_n41_));
  NAND2x1_ASAP7_75t_R  g08(.A(new_n37_), .B(new_n41_), .Y(o0));
  NAND2x1_ASAP7_75t_R  g09(.A(p3), .B(new_n38_), .Y(new_n43_));
  INVx1_ASAP7_75t_R    g10(.A(p0), .Y(new_n44_));
  NOR2x1_ASAP7_75t_R   g11(.A(p1), .B(new_n44_), .Y(new_n45_));
  AND3x1_ASAP7_75t_R   g12(.A(new_n44_), .B(new_n34_), .C(p6), .Y(new_n46_));
  INVx1_ASAP7_75t_R    g13(.A(new_n36_), .Y(new_n47_));
  OAI21x1_ASAP7_75t_R  g14(.A1(p2), .A2(p3), .B(p1), .Y(new_n48_));
  OAI21x1_ASAP7_75t_R  g15(.A1(p0), .A2(new_n47_), .B(new_n48_), .Y(new_n49_));
  AOI211x1_ASAP7_75t_R g16(.A1(new_n43_), .A2(new_n45_), .B(new_n46_), .C(new_n49_), .Y(o1));
  NOR2x1_ASAP7_75t_R   g17(.A(p3), .B(new_n38_), .Y(new_n51_));
  NOR2x1_ASAP7_75t_R   g18(.A(new_n44_), .B(new_n51_), .Y(new_n52_));
  OR3x1_ASAP7_75t_R    g19(.A(new_n39_), .B(p2), .C(p6), .Y(new_n53_));
  INVx1_ASAP7_75t_R    g20(.A(new_n45_), .Y(new_n54_));
  OR3x1_ASAP7_75t_R    g21(.A(new_n36_), .B(p1), .C(p6), .Y(new_n55_));
  AOI22x1_ASAP7_75t_R  g22(.A1(new_n52_), .A2(new_n53_), .B1(new_n54_), .B2(new_n55_), .Y(o2));
  NOR2x1_ASAP7_75t_R   g23(.A(p0), .B(p1), .Y(new_n57_));
  NAND2x1_ASAP7_75t_R  g24(.A(p2), .B(new_n57_), .Y(new_n58_));
  AOI22x1_ASAP7_75t_R  g25(.A1(new_n58_), .A2(new_n43_), .B1(p6), .B2(new_n47_), .Y(o3));
  AND3x1_ASAP7_75t_R   g26(.A(p3), .B(p4), .C(p0), .Y(new_n60_));
  NOR2x1_ASAP7_75t_R   g27(.A(p6), .B(new_n38_), .Y(new_n61_));
  AOI21x1_ASAP7_75t_R  g28(.A1(new_n60_), .A2(new_n61_), .B(p1), .Y(new_n62_));
  INVx1_ASAP7_75t_R    g29(.A(p5), .Y(new_n63_));
  AOI21x1_ASAP7_75t_R  g30(.A1(p3), .A2(new_n63_), .B(new_n38_), .Y(new_n64_));
  INVx1_ASAP7_75t_R    g31(.A(p4), .Y(new_n65_));
  NAND3x1_ASAP7_75t_R  g32(.A(new_n65_), .B(p3), .C(p5), .Y(new_n66_));
  AND2x2_ASAP7_75t_R   g33(.A(p0), .B(p6), .Y(new_n67_));
  NAND3x1_ASAP7_75t_R  g34(.A(new_n64_), .B(new_n66_), .C(new_n67_), .Y(new_n68_));
  NOR2x1_ASAP7_75t_R   g35(.A(p6), .B(new_n34_), .Y(new_n69_));
  AO21x1_ASAP7_75t_R   g36(.A1(p1), .A2(new_n43_), .B(new_n69_), .Y(new_n70_));
  AOI21x1_ASAP7_75t_R  g37(.A1(new_n62_), .A2(new_n68_), .B(new_n70_), .Y(o4));
  AO21x1_ASAP7_75t_R   g38(.A1(p3), .A2(new_n38_), .B(new_n34_), .Y(new_n72_));
  OA211x2_ASAP7_75t_R  g39(.A1(p1), .A2(new_n64_), .B(new_n72_), .C(p0), .Y(o5));
  AO21x1_ASAP7_75t_R   g40(.A1(new_n38_), .A2(new_n39_), .B(p1), .Y(new_n74_));
  OAI21x1_ASAP7_75t_R  g41(.A1(p1), .A2(new_n67_), .B(new_n47_), .Y(new_n75_));
  OAI21x1_ASAP7_75t_R  g42(.A1(new_n47_), .A2(new_n74_), .B(new_n75_), .Y(o6));
  INVx1_ASAP7_75t_R    g43(.A(p6), .Y(new_n77_));
  OR3x1_ASAP7_75t_R    g44(.A(p0), .B(p1), .C(p6), .Y(new_n78_));
  OA21x2_ASAP7_75t_R   g45(.A1(new_n34_), .A2(new_n77_), .B(new_n78_), .Y(new_n79_));
  OAI21x1_ASAP7_75t_R  g46(.A1(new_n36_), .A2(new_n79_), .B(new_n41_), .Y(o7));
  OAI21x1_ASAP7_75t_R  g47(.A1(new_n48_), .A2(new_n47_), .B(p0), .Y(new_n81_));
  AOI21x1_ASAP7_75t_R  g48(.A1(new_n45_), .A2(new_n53_), .B(new_n81_), .Y(o8));
  AOI21x1_ASAP7_75t_R  g49(.A1(new_n45_), .A2(new_n53_), .B(new_n49_), .Y(o9));
  NOR2x1_ASAP7_75t_R   g50(.A(p2), .B(new_n39_), .Y(new_n84_));
  OAI21x1_ASAP7_75t_R  g51(.A1(new_n44_), .A2(p6), .B(new_n84_), .Y(new_n85_));
  AO22x1_ASAP7_75t_R   g52(.A1(new_n38_), .A2(new_n34_), .B1(p3), .B2(new_n57_), .Y(new_n86_));
  AOI22x1_ASAP7_75t_R  g53(.A1(new_n85_), .A2(new_n86_), .B1(p1), .B2(new_n43_), .Y(o10));
  NOR2x1_ASAP7_75t_R   g54(.A(p2), .B(p3), .Y(new_n88_));
  AND3x1_ASAP7_75t_R   g55(.A(new_n35_), .B(new_n88_), .C(new_n34_), .Y(o11));
  AND3x1_ASAP7_75t_R   g56(.A(new_n38_), .B(new_n44_), .C(new_n77_), .Y(new_n90_));
  NOR2x1_ASAP7_75t_R   g57(.A(p3), .B(p0), .Y(new_n91_));
  OR3x1_ASAP7_75t_R    g58(.A(new_n51_), .B(new_n34_), .C(new_n91_), .Y(new_n92_));
  OAI21x1_ASAP7_75t_R  g59(.A1(new_n74_), .A2(new_n90_), .B(new_n92_), .Y(o12));
  AND3x1_ASAP7_75t_R   g60(.A(new_n88_), .B(p1), .C(p6), .Y(o13));
  AND3x1_ASAP7_75t_R   g61(.A(new_n88_), .B(p1), .C(new_n77_), .Y(o14));
  AND3x1_ASAP7_75t_R   g62(.A(new_n69_), .B(p2), .C(new_n91_), .Y(o15));
  NAND2x1_ASAP7_75t_R  g63(.A(p2), .B(new_n91_), .Y(new_n97_));
  NOR3x1_ASAP7_75t_R   g64(.A(new_n97_), .B(new_n34_), .C(new_n77_), .Y(o16));
  AND3x1_ASAP7_75t_R   g65(.A(new_n51_), .B(p1), .C(new_n67_), .Y(o17));
  AND3x1_ASAP7_75t_R   g66(.A(new_n51_), .B(new_n69_), .C(p0), .Y(o18));
  AND3x1_ASAP7_75t_R   g67(.A(p2), .B(p0), .C(p6), .Y(new_n101_));
  OAI21x1_ASAP7_75t_R  g68(.A1(new_n39_), .A2(p4), .B(new_n101_), .Y(new_n102_));
  AND2x2_ASAP7_75t_R   g69(.A(p2), .B(p6), .Y(new_n103_));
  AOI21x1_ASAP7_75t_R  g70(.A1(new_n91_), .A2(new_n103_), .B(p1), .Y(new_n104_));
  OA21x2_ASAP7_75t_R   g71(.A1(new_n36_), .A2(new_n67_), .B(p1), .Y(new_n105_));
  AOI21x1_ASAP7_75t_R  g72(.A1(new_n102_), .A2(new_n104_), .B(new_n105_), .Y(o20));
  NAND3x1_ASAP7_75t_R  g73(.A(new_n60_), .B(p2), .C(new_n63_), .Y(new_n107_));
  AOI211x1_ASAP7_75t_R g74(.A1(new_n97_), .A2(new_n107_), .B(p1), .C(new_n77_), .Y(o21));
  AOI21x1_ASAP7_75t_R  g75(.A1(new_n34_), .A2(new_n68_), .B(new_n105_), .Y(o22));
  assign               o23 = 1'b1;
  AO21x1_ASAP7_75t_R   g76(.A1(p6), .A2(new_n44_), .B(p1), .Y(new_n111_));
  NOR2x1_ASAP7_75t_R   g77(.A(new_n111_), .B(new_n85_), .Y(o24));
  AND3x1_ASAP7_75t_R   g78(.A(new_n84_), .B(p6), .C(new_n57_), .Y(o25));
endmodule


