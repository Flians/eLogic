// Benchmark "/tmp/" written by ABC on Tue Oct 13 18:52:01 2026

module \/tmp/  ( 
    p6, p0, p1, p3, p4, p2, p5,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25  );
  input  p6, p0, p1, p3, p4, p2, p5;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25;
  wire new_n34_, new_n35_, new_n36_, new_n37_, new_n38_, new_n39_, new_n41_,
    new_n43_, new_n44_, new_n45_, new_n46_, new_n47_, new_n48_, new_n49_,
    new_n51_, new_n52_, new_n53_, new_n54_, new_n55_, new_n57_, new_n58_,
    new_n60_, new_n61_, new_n62_, new_n63_, new_n64_, new_n65_, new_n66_,
    new_n67_, new_n68_, new_n69_, new_n71_, new_n73_, new_n74_, new_n76_,
    new_n77_, new_n79_, new_n82_, new_n83_, new_n84_, new_n85_, new_n87_,
    new_n89_, new_n90_, new_n94_, new_n96_, new_n100_, new_n101_,
    new_n103_, new_n104_;
  INVx1_ASAP7_75t_R    g00(.A(p0), .Y(new_n34_));
  NOR2x1_ASAP7_75t_R   g01(.A(p6), .B(p1), .Y(new_n35_));
  NAND2x1_ASAP7_75t_R  g02(.A(p3), .B(p2), .Y(new_n36_));
  AO21x1_ASAP7_75t_R   g03(.A1(new_n34_), .A2(new_n35_), .B(new_n36_), .Y(new_n37_));
  INVx1_ASAP7_75t_R    g04(.A(p3), .Y(new_n38_));
  INVx1_ASAP7_75t_R    g05(.A(p2), .Y(new_n39_));
  AND3x1_ASAP7_75t_R   g06(.A(new_n38_), .B(new_n39_), .C(p1), .Y(o19));
  NAND2x1_ASAP7_75t_R  g07(.A(p0), .B(o19), .Y(new_n41_));
  NAND2x1_ASAP7_75t_R  g08(.A(new_n37_), .B(new_n41_), .Y(o0));
  NAND2x1_ASAP7_75t_R  g09(.A(p3), .B(new_n39_), .Y(new_n43_));
  NOR2x1_ASAP7_75t_R   g10(.A(p1), .B(new_n34_), .Y(new_n44_));
  INVx1_ASAP7_75t_R    g11(.A(p1), .Y(new_n45_));
  AND3x1_ASAP7_75t_R   g12(.A(new_n34_), .B(new_n45_), .C(p6), .Y(new_n46_));
  INVx1_ASAP7_75t_R    g13(.A(new_n36_), .Y(new_n47_));
  OAI21x1_ASAP7_75t_R  g14(.A1(p3), .A2(p2), .B(p1), .Y(new_n48_));
  OAI21x1_ASAP7_75t_R  g15(.A1(p0), .A2(new_n47_), .B(new_n48_), .Y(new_n49_));
  AOI211x1_ASAP7_75t_R g16(.A1(new_n43_), .A2(new_n44_), .B(new_n46_), .C(new_n49_), .Y(o1));
  NOR2x1_ASAP7_75t_R   g17(.A(p3), .B(new_n39_), .Y(new_n51_));
  NOR2x1_ASAP7_75t_R   g18(.A(new_n34_), .B(new_n51_), .Y(new_n52_));
  OR3x1_ASAP7_75t_R    g19(.A(new_n38_), .B(p6), .C(p2), .Y(new_n53_));
  INVx1_ASAP7_75t_R    g20(.A(new_n44_), .Y(new_n54_));
  OR3x1_ASAP7_75t_R    g21(.A(new_n36_), .B(p6), .C(p1), .Y(new_n55_));
  AOI22x1_ASAP7_75t_R  g22(.A1(new_n52_), .A2(new_n53_), .B1(new_n54_), .B2(new_n55_), .Y(o2));
  NOR2x1_ASAP7_75t_R   g23(.A(p0), .B(p1), .Y(new_n57_));
  NAND2x1_ASAP7_75t_R  g24(.A(p2), .B(new_n57_), .Y(new_n58_));
  AOI22x1_ASAP7_75t_R  g25(.A1(new_n58_), .A2(new_n43_), .B1(p6), .B2(new_n47_), .Y(o3));
  NAND2x1_ASAP7_75t_R  g26(.A(p0), .B(p4), .Y(new_n60_));
  OA31x2_ASAP7_75t_R   g27(.A1(p6), .A2(new_n36_), .A3(new_n60_), .B1(new_n45_), .Y(new_n61_));
  INVx1_ASAP7_75t_R    g28(.A(p5), .Y(new_n62_));
  AOI21x1_ASAP7_75t_R  g29(.A1(p3), .A2(new_n62_), .B(new_n39_), .Y(new_n63_));
  INVx1_ASAP7_75t_R    g30(.A(p4), .Y(new_n64_));
  NAND3x1_ASAP7_75t_R  g31(.A(new_n64_), .B(p3), .C(p5), .Y(new_n65_));
  AND2x2_ASAP7_75t_R   g32(.A(p6), .B(p0), .Y(new_n66_));
  NAND3x1_ASAP7_75t_R  g33(.A(new_n63_), .B(new_n65_), .C(new_n66_), .Y(new_n67_));
  INVx1_ASAP7_75t_R    g34(.A(p6), .Y(new_n68_));
  OA21x2_ASAP7_75t_R   g35(.A1(new_n68_), .A2(new_n43_), .B(p1), .Y(new_n69_));
  AOI21x1_ASAP7_75t_R  g36(.A1(new_n61_), .A2(new_n67_), .B(new_n69_), .Y(o4));
  AO21x1_ASAP7_75t_R   g37(.A1(p3), .A2(new_n39_), .B(new_n45_), .Y(new_n71_));
  OA211x2_ASAP7_75t_R  g38(.A1(p1), .A2(new_n63_), .B(new_n71_), .C(p0), .Y(o5));
  AO21x1_ASAP7_75t_R   g39(.A1(new_n38_), .A2(new_n39_), .B(p1), .Y(new_n73_));
  OR3x1_ASAP7_75t_R    g40(.A(new_n35_), .B(new_n57_), .C(new_n36_), .Y(new_n74_));
  OAI21x1_ASAP7_75t_R  g41(.A1(new_n47_), .A2(new_n73_), .B(new_n74_), .Y(o6));
  OR3x1_ASAP7_75t_R    g42(.A(p6), .B(p0), .C(p1), .Y(new_n76_));
  OA21x2_ASAP7_75t_R   g43(.A1(new_n68_), .A2(new_n45_), .B(new_n76_), .Y(new_n77_));
  OAI21x1_ASAP7_75t_R  g44(.A1(new_n36_), .A2(new_n77_), .B(new_n41_), .Y(o7));
  OAI21x1_ASAP7_75t_R  g45(.A1(new_n48_), .A2(new_n47_), .B(p0), .Y(new_n79_));
  AOI21x1_ASAP7_75t_R  g46(.A1(new_n44_), .A2(new_n53_), .B(new_n79_), .Y(o8));
  AOI21x1_ASAP7_75t_R  g47(.A1(new_n44_), .A2(new_n53_), .B(new_n49_), .Y(o9));
  NOR2x1_ASAP7_75t_R   g48(.A(p2), .B(new_n38_), .Y(new_n82_));
  NAND2x1_ASAP7_75t_R  g49(.A(p0), .B(new_n68_), .Y(new_n83_));
  NOR2x1_ASAP7_75t_R   g50(.A(p1), .B(p2), .Y(new_n84_));
  AOI21x1_ASAP7_75t_R  g51(.A1(p3), .A2(new_n57_), .B(new_n84_), .Y(new_n85_));
  AO22x1_ASAP7_75t_R   g52(.A1(new_n82_), .A2(new_n83_), .B1(new_n71_), .B2(new_n85_), .Y(o10));
  NOR2x1_ASAP7_75t_R   g53(.A(p3), .B(p2), .Y(new_n87_));
  AND3x1_ASAP7_75t_R   g54(.A(new_n35_), .B(new_n87_), .C(new_n34_), .Y(o11));
  OA21x2_ASAP7_75t_R   g55(.A1(p2), .A2(new_n34_), .B(new_n38_), .Y(new_n89_));
  AND3x1_ASAP7_75t_R   g56(.A(new_n68_), .B(new_n34_), .C(new_n39_), .Y(new_n90_));
  OAI22x1_ASAP7_75t_R  g57(.A1(new_n89_), .A2(new_n45_), .B1(new_n90_), .B2(new_n73_), .Y(o12));
  AND3x1_ASAP7_75t_R   g58(.A(new_n87_), .B(p6), .C(p1), .Y(o13));
  AND3x1_ASAP7_75t_R   g59(.A(new_n87_), .B(new_n68_), .C(p1), .Y(o14));
  NOR2x1_ASAP7_75t_R   g60(.A(p6), .B(p0), .Y(new_n94_));
  AND3x1_ASAP7_75t_R   g61(.A(new_n51_), .B(p1), .C(new_n94_), .Y(o15));
  AND3x1_ASAP7_75t_R   g62(.A(new_n38_), .B(p1), .C(p2), .Y(new_n96_));
  AND3x1_ASAP7_75t_R   g63(.A(new_n96_), .B(p6), .C(new_n34_), .Y(o16));
  AND3x1_ASAP7_75t_R   g64(.A(new_n51_), .B(p1), .C(new_n66_), .Y(o17));
  AND3x1_ASAP7_75t_R   g65(.A(new_n96_), .B(new_n68_), .C(p0), .Y(o18));
  AO21x1_ASAP7_75t_R   g66(.A1(p3), .A2(new_n60_), .B(new_n39_), .Y(new_n100_));
  OA21x2_ASAP7_75t_R   g67(.A1(new_n36_), .A2(new_n66_), .B(p1), .Y(new_n101_));
  AOI211x1_ASAP7_75t_R g68(.A1(new_n45_), .A2(new_n100_), .B(new_n35_), .C(new_n101_), .Y(o20));
  OR3x1_ASAP7_75t_R    g69(.A(new_n39_), .B(p0), .C(p3), .Y(new_n103_));
  OR3x1_ASAP7_75t_R    g70(.A(new_n36_), .B(new_n60_), .C(p5), .Y(new_n104_));
  AOI211x1_ASAP7_75t_R g71(.A1(new_n103_), .A2(new_n104_), .B(new_n68_), .C(p1), .Y(o21));
  AOI21x1_ASAP7_75t_R  g72(.A1(new_n45_), .A2(new_n67_), .B(new_n101_), .Y(o22));
  assign               o23 = 1'b1;
  OA211x2_ASAP7_75t_R  g73(.A1(new_n94_), .A2(new_n66_), .B(p3), .C(new_n84_), .Y(o24));
  AND3x1_ASAP7_75t_R   g74(.A(new_n82_), .B(p6), .C(new_n57_), .Y(o25));
endmodule


