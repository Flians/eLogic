// Benchmark "/tmp/" written by ABC on Tue Oct 13 18:51:59 2026

module \/tmp/  ( 
    p5, p6, p0, p4, p1, p2, p3,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25  );
  input  p5, p6, p0, p4, p1, p2, p3;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25;
  wire new_n34_, new_n35_, new_n36_, new_n37_, new_n39_, new_n40_, new_n41_,
    new_n42_, new_n43_, new_n44_, new_n45_, new_n46_, new_n47_, new_n48_,
    new_n50_, new_n51_, new_n52_, new_n53_, new_n54_, new_n55_, new_n57_,
    new_n59_, new_n60_, new_n61_, new_n62_, new_n63_, new_n64_, new_n65_,
    new_n66_, new_n67_, new_n68_, new_n70_, new_n72_, new_n73_, new_n75_,
    new_n76_, new_n77_, new_n79_, new_n80_, new_n82_, new_n84_, new_n85_,
    new_n86_, new_n87_, new_n90_, new_n91_, new_n95_, new_n97_, new_n100_,
    new_n103_, new_n104_, new_n105_, new_n107_, new_n108_, new_n109_;
  AND2x2_ASAP7_75t_R   g00(.A(p2), .B(p3), .Y(new_n34_));
  OR3x1_ASAP7_75t_R    g01(.A(p6), .B(p0), .C(p1), .Y(new_n35_));
  NOR2x1_ASAP7_75t_R   g02(.A(p2), .B(p3), .Y(new_n36_));
  AND3x1_ASAP7_75t_R   g03(.A(new_n36_), .B(p0), .C(p1), .Y(new_n37_));
  AO21x1_ASAP7_75t_R   g04(.A1(new_n34_), .A2(new_n35_), .B(new_n37_), .Y(o0));
  INVx1_ASAP7_75t_R    g05(.A(p2), .Y(new_n39_));
  INVx1_ASAP7_75t_R    g06(.A(p3), .Y(new_n40_));
  OR3x1_ASAP7_75t_R    g07(.A(new_n39_), .B(new_n40_), .C(p6), .Y(new_n41_));
  NOR2x1_ASAP7_75t_R   g08(.A(p0), .B(p1), .Y(new_n42_));
  INVx1_ASAP7_75t_R    g09(.A(p1), .Y(new_n43_));
  OAI21x1_ASAP7_75t_R  g10(.A1(p2), .A2(p3), .B(p1), .Y(new_n44_));
  OAI21x1_ASAP7_75t_R  g11(.A1(p0), .A2(new_n43_), .B(new_n44_), .Y(new_n45_));
  NAND2x1_ASAP7_75t_R  g12(.A(p0), .B(new_n43_), .Y(new_n46_));
  NOR2x1_ASAP7_75t_R   g13(.A(p2), .B(new_n40_), .Y(new_n47_));
  NOR2x1_ASAP7_75t_R   g14(.A(new_n46_), .B(new_n47_), .Y(new_n48_));
  AOI211x1_ASAP7_75t_R g15(.A1(new_n41_), .A2(new_n42_), .B(new_n45_), .C(new_n48_), .Y(o1));
  INVx1_ASAP7_75t_R    g16(.A(p0), .Y(new_n50_));
  NOR2x1_ASAP7_75t_R   g17(.A(p3), .B(new_n39_), .Y(new_n51_));
  NOR2x1_ASAP7_75t_R   g18(.A(new_n50_), .B(new_n51_), .Y(new_n52_));
  OR3x1_ASAP7_75t_R    g19(.A(new_n40_), .B(p6), .C(p2), .Y(new_n53_));
  NOR2x1_ASAP7_75t_R   g20(.A(p6), .B(p1), .Y(new_n54_));
  NAND2x1_ASAP7_75t_R  g21(.A(new_n54_), .B(new_n34_), .Y(new_n55_));
  AOI22x1_ASAP7_75t_R  g22(.A1(new_n52_), .A2(new_n53_), .B1(new_n46_), .B2(new_n55_), .Y(o2));
  AOI21x1_ASAP7_75t_R  g23(.A1(p6), .A2(new_n34_), .B(new_n36_), .Y(new_n57_));
  OA21x2_ASAP7_75t_R   g24(.A1(new_n39_), .A2(new_n42_), .B(new_n57_), .Y(o3));
  NAND2x1_ASAP7_75t_R  g25(.A(p2), .B(p3), .Y(new_n59_));
  NAND2x1_ASAP7_75t_R  g26(.A(p0), .B(p4), .Y(new_n60_));
  OA31x2_ASAP7_75t_R   g27(.A1(p6), .A2(new_n59_), .A3(new_n60_), .B1(new_n43_), .Y(new_n61_));
  INVx1_ASAP7_75t_R    g28(.A(p5), .Y(new_n62_));
  AOI21x1_ASAP7_75t_R  g29(.A1(p3), .A2(new_n62_), .B(new_n39_), .Y(new_n63_));
  INVx1_ASAP7_75t_R    g30(.A(p4), .Y(new_n64_));
  NAND3x1_ASAP7_75t_R  g31(.A(new_n64_), .B(p5), .C(p3), .Y(new_n65_));
  AND2x2_ASAP7_75t_R   g32(.A(p6), .B(p0), .Y(new_n66_));
  NAND3x1_ASAP7_75t_R  g33(.A(new_n63_), .B(new_n65_), .C(new_n66_), .Y(new_n67_));
  AOI21x1_ASAP7_75t_R  g34(.A1(p6), .A2(new_n47_), .B(new_n43_), .Y(new_n68_));
  AOI21x1_ASAP7_75t_R  g35(.A1(new_n61_), .A2(new_n67_), .B(new_n68_), .Y(o4));
  AO21x1_ASAP7_75t_R   g36(.A1(p3), .A2(new_n39_), .B(new_n43_), .Y(new_n70_));
  OA211x2_ASAP7_75t_R  g37(.A1(p1), .A2(new_n63_), .B(new_n70_), .C(p0), .Y(o5));
  AO21x1_ASAP7_75t_R   g38(.A1(new_n39_), .A2(new_n40_), .B(p1), .Y(new_n72_));
  OR3x1_ASAP7_75t_R    g39(.A(new_n54_), .B(new_n42_), .C(new_n59_), .Y(new_n73_));
  OAI21x1_ASAP7_75t_R  g40(.A1(new_n34_), .A2(new_n72_), .B(new_n73_), .Y(o6));
  AND3x1_ASAP7_75t_R   g41(.A(new_n34_), .B(p6), .C(p1), .Y(new_n75_));
  INVx1_ASAP7_75t_R    g42(.A(p6), .Y(new_n76_));
  AND3x1_ASAP7_75t_R   g43(.A(new_n34_), .B(new_n76_), .C(new_n42_), .Y(new_n77_));
  OR3x1_ASAP7_75t_R    g44(.A(new_n75_), .B(new_n77_), .C(new_n37_), .Y(o7));
  INVx1_ASAP7_75t_R    g45(.A(new_n46_), .Y(new_n79_));
  OAI21x1_ASAP7_75t_R  g46(.A1(new_n44_), .A2(new_n34_), .B(p0), .Y(new_n80_));
  AOI21x1_ASAP7_75t_R  g47(.A1(new_n53_), .A2(new_n79_), .B(new_n80_), .Y(o8));
  AND2x2_ASAP7_75t_R   g48(.A(new_n50_), .B(new_n59_), .Y(new_n82_));
  AOI211x1_ASAP7_75t_R g49(.A1(new_n53_), .A2(new_n79_), .B(new_n45_), .C(new_n82_), .Y(o9));
  OAI21x1_ASAP7_75t_R  g50(.A1(p6), .A2(new_n50_), .B(new_n47_), .Y(new_n84_));
  NAND2x1_ASAP7_75t_R  g51(.A(p0), .B(p2), .Y(new_n85_));
  OA211x2_ASAP7_75t_R  g52(.A1(new_n39_), .A2(p3), .B(new_n85_), .C(new_n43_), .Y(new_n86_));
  INVx1_ASAP7_75t_R    g53(.A(new_n70_), .Y(new_n87_));
  AOI21x1_ASAP7_75t_R  g54(.A1(new_n84_), .A2(new_n86_), .B(new_n87_), .Y(o10));
  AND3x1_ASAP7_75t_R   g55(.A(new_n36_), .B(new_n54_), .C(new_n50_), .Y(o11));
  OA21x2_ASAP7_75t_R   g56(.A1(p2), .A2(new_n50_), .B(new_n40_), .Y(new_n90_));
  AND3x1_ASAP7_75t_R   g57(.A(new_n76_), .B(new_n50_), .C(new_n39_), .Y(new_n91_));
  OAI22x1_ASAP7_75t_R  g58(.A1(new_n90_), .A2(new_n43_), .B1(new_n91_), .B2(new_n72_), .Y(o12));
  AND3x1_ASAP7_75t_R   g59(.A(new_n36_), .B(p6), .C(p1), .Y(o13));
  AND3x1_ASAP7_75t_R   g60(.A(new_n36_), .B(new_n76_), .C(p1), .Y(o14));
  NOR2x1_ASAP7_75t_R   g61(.A(p6), .B(p0), .Y(new_n95_));
  AND3x1_ASAP7_75t_R   g62(.A(new_n51_), .B(p1), .C(new_n95_), .Y(o15));
  AND2x2_ASAP7_75t_R   g63(.A(p6), .B(p1), .Y(new_n97_));
  AND3x1_ASAP7_75t_R   g64(.A(new_n51_), .B(new_n50_), .C(new_n97_), .Y(o16));
  AND3x1_ASAP7_75t_R   g65(.A(new_n51_), .B(p1), .C(new_n66_), .Y(o17));
  OR3x1_ASAP7_75t_R    g66(.A(new_n43_), .B(p6), .C(p3), .Y(new_n100_));
  NOR2x1_ASAP7_75t_R   g67(.A(new_n85_), .B(new_n100_), .Y(o18));
  AND3x1_ASAP7_75t_R   g68(.A(new_n39_), .B(new_n40_), .C(p1), .Y(o19));
  OA21x2_ASAP7_75t_R   g69(.A1(p3), .A2(new_n39_), .B(new_n43_), .Y(new_n103_));
  OR3x1_ASAP7_75t_R    g70(.A(new_n50_), .B(new_n64_), .C(new_n39_), .Y(new_n104_));
  OA21x2_ASAP7_75t_R   g71(.A1(new_n59_), .A2(new_n66_), .B(p1), .Y(new_n105_));
  AOI211x1_ASAP7_75t_R g72(.A1(new_n103_), .A2(new_n104_), .B(new_n54_), .C(new_n105_), .Y(o20));
  OR3x1_ASAP7_75t_R    g73(.A(new_n39_), .B(p0), .C(p3), .Y(new_n107_));
  OR4x2_ASAP7_75t_R    g74(.A(new_n85_), .B(p5), .C(new_n64_), .D(new_n40_), .Y(new_n108_));
  NAND2x1_ASAP7_75t_R  g75(.A(p6), .B(new_n43_), .Y(new_n109_));
  AOI21x1_ASAP7_75t_R  g76(.A1(new_n107_), .A2(new_n108_), .B(new_n109_), .Y(o21));
  AOI21x1_ASAP7_75t_R  g77(.A1(new_n43_), .A2(new_n67_), .B(new_n105_), .Y(o22));
  assign               o23 = 1'b1;
  OA211x2_ASAP7_75t_R  g78(.A1(new_n95_), .A2(new_n66_), .B(new_n47_), .C(new_n43_), .Y(o24));
  AND3x1_ASAP7_75t_R   g79(.A(new_n47_), .B(p6), .C(new_n42_), .Y(o25));
endmodule


