// Benchmark "/tmp/" written by ABC on Tue Oct 13 18:51:57 2026

module \/tmp/  ( 
    p5, p2, p3, p6, p0, p1, p4,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25  );
  input  p5, p2, p3, p6, p0, p1, p4;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25;
  wire new_n34_, new_n35_, new_n36_, new_n37_, new_n38_, new_n39_, new_n41_,
    new_n42_, new_n43_, new_n44_, new_n45_, new_n46_, new_n47_, new_n48_,
    new_n50_, new_n51_, new_n52_, new_n53_, new_n55_, new_n56_, new_n57_,
    new_n59_, new_n60_, new_n61_, new_n62_, new_n63_, new_n64_, new_n65_,
    new_n66_, new_n68_, new_n69_, new_n71_, new_n72_, new_n73_, new_n75_,
    new_n76_, new_n77_, new_n79_, new_n81_, new_n82_, new_n84_, new_n85_,
    new_n86_, new_n87_, new_n90_, new_n91_, new_n96_, new_n101_, new_n102_,
    new_n103_, new_n104_, new_n105_, new_n107_, new_n108_;
  INVx1_ASAP7_75t_R    g00(.A(p1), .Y(new_n34_));
  NOR2x1_ASAP7_75t_R   g01(.A(p6), .B(p0), .Y(new_n35_));
  NAND2x1_ASAP7_75t_R  g02(.A(p2), .B(p3), .Y(new_n36_));
  AO21x1_ASAP7_75t_R   g03(.A1(new_n34_), .A2(new_n35_), .B(new_n36_), .Y(new_n37_));
  INVx1_ASAP7_75t_R    g04(.A(p0), .Y(new_n38_));
  OR4x2_ASAP7_75t_R    g05(.A(new_n38_), .B(new_n34_), .C(p2), .D(p3), .Y(new_n39_));
  NAND2x1_ASAP7_75t_R  g06(.A(new_n37_), .B(new_n39_), .Y(o0));
  INVx1_ASAP7_75t_R    g07(.A(p2), .Y(new_n41_));
  INVx1_ASAP7_75t_R    g08(.A(p3), .Y(new_n42_));
  OR3x1_ASAP7_75t_R    g09(.A(new_n41_), .B(new_n42_), .C(p6), .Y(new_n43_));
  NOR2x1_ASAP7_75t_R   g10(.A(p0), .B(p1), .Y(new_n44_));
  OA31x2_ASAP7_75t_R   g11(.A1(p2), .A2(p3), .A3(new_n38_), .B1(p1), .Y(new_n45_));
  NAND2x1_ASAP7_75t_R  g12(.A(p0), .B(new_n34_), .Y(new_n46_));
  NOR2x1_ASAP7_75t_R   g13(.A(p2), .B(new_n42_), .Y(new_n47_));
  NOR2x1_ASAP7_75t_R   g14(.A(new_n46_), .B(new_n47_), .Y(new_n48_));
  AOI211x1_ASAP7_75t_R g15(.A1(new_n43_), .A2(new_n44_), .B(new_n45_), .C(new_n48_), .Y(o1));
  NOR2x1_ASAP7_75t_R   g16(.A(p3), .B(new_n41_), .Y(new_n50_));
  NOR2x1_ASAP7_75t_R   g17(.A(new_n38_), .B(new_n50_), .Y(new_n51_));
  OR3x1_ASAP7_75t_R    g18(.A(new_n42_), .B(p2), .C(p6), .Y(new_n52_));
  OR3x1_ASAP7_75t_R    g19(.A(new_n36_), .B(p6), .C(p1), .Y(new_n53_));
  AOI22x1_ASAP7_75t_R  g20(.A1(new_n51_), .A2(new_n52_), .B1(new_n46_), .B2(new_n53_), .Y(o2));
  AND2x2_ASAP7_75t_R   g21(.A(p2), .B(p3), .Y(new_n55_));
  NOR2x1_ASAP7_75t_R   g22(.A(p2), .B(p3), .Y(new_n56_));
  NOR2x1_ASAP7_75t_R   g23(.A(new_n41_), .B(new_n44_), .Y(new_n57_));
  AOI211x1_ASAP7_75t_R g24(.A1(p6), .A2(new_n55_), .B(new_n56_), .C(new_n57_), .Y(o3));
  NAND2x1_ASAP7_75t_R  g25(.A(p0), .B(p4), .Y(new_n59_));
  OA31x2_ASAP7_75t_R   g26(.A1(p6), .A2(new_n36_), .A3(new_n59_), .B1(new_n34_), .Y(new_n60_));
  AND3x1_ASAP7_75t_R   g27(.A(p2), .B(p6), .C(p0), .Y(new_n61_));
  INVx1_ASAP7_75t_R    g28(.A(p5), .Y(new_n62_));
  INVx1_ASAP7_75t_R    g29(.A(p4), .Y(new_n63_));
  OAI21x1_ASAP7_75t_R  g30(.A1(new_n62_), .A2(new_n63_), .B(p3), .Y(new_n64_));
  NAND2x1_ASAP7_75t_R  g31(.A(new_n61_), .B(new_n64_), .Y(new_n65_));
  AOI21x1_ASAP7_75t_R  g32(.A1(p6), .A2(new_n47_), .B(new_n34_), .Y(new_n66_));
  AOI21x1_ASAP7_75t_R  g33(.A1(new_n60_), .A2(new_n65_), .B(new_n66_), .Y(o4));
  AO21x1_ASAP7_75t_R   g34(.A1(p3), .A2(new_n62_), .B(new_n41_), .Y(new_n68_));
  NOR2x1_ASAP7_75t_R   g35(.A(new_n34_), .B(new_n47_), .Y(new_n69_));
  AOI211x1_ASAP7_75t_R g36(.A1(new_n34_), .A2(new_n68_), .B(new_n38_), .C(new_n69_), .Y(o5));
  AND2x2_ASAP7_75t_R   g37(.A(p6), .B(p0), .Y(new_n71_));
  NOR2x1_ASAP7_75t_R   g38(.A(p1), .B(new_n71_), .Y(new_n72_));
  AO21x1_ASAP7_75t_R   g39(.A1(p1), .A2(new_n36_), .B(new_n56_), .Y(new_n73_));
  AOI21x1_ASAP7_75t_R  g40(.A1(new_n55_), .A2(new_n72_), .B(new_n73_), .Y(o6));
  OR4x2_ASAP7_75t_R    g41(.A(new_n36_), .B(p6), .C(p0), .D(p1), .Y(new_n75_));
  INVx1_ASAP7_75t_R    g42(.A(p6), .Y(new_n76_));
  OR3x1_ASAP7_75t_R    g43(.A(new_n36_), .B(new_n76_), .C(new_n34_), .Y(new_n77_));
  NAND3x1_ASAP7_75t_R  g44(.A(new_n75_), .B(new_n39_), .C(new_n77_), .Y(o7));
  NOR3x1_ASAP7_75t_R   g45(.A(new_n55_), .B(new_n34_), .C(new_n56_), .Y(new_n79_));
  AOI211x1_ASAP7_75t_R g46(.A1(new_n34_), .A2(new_n52_), .B(new_n38_), .C(new_n79_), .Y(o8));
  NOR2x1_ASAP7_75t_R   g47(.A(p1), .B(new_n38_), .Y(new_n81_));
  AND3x1_ASAP7_75t_R   g48(.A(new_n36_), .B(new_n38_), .C(new_n34_), .Y(new_n82_));
  AOI211x1_ASAP7_75t_R g49(.A1(new_n81_), .A2(new_n52_), .B(new_n45_), .C(new_n82_), .Y(o9));
  NOR2x1_ASAP7_75t_R   g50(.A(p2), .B(p1), .Y(new_n84_));
  AO21x1_ASAP7_75t_R   g51(.A1(p3), .A2(new_n44_), .B(new_n84_), .Y(new_n85_));
  INVx1_ASAP7_75t_R    g52(.A(new_n47_), .Y(new_n86_));
  NOR2x1_ASAP7_75t_R   g53(.A(p6), .B(new_n38_), .Y(new_n87_));
  OAI22x1_ASAP7_75t_R  g54(.A1(new_n69_), .A2(new_n85_), .B1(new_n86_), .B2(new_n87_), .Y(o10));
  AND3x1_ASAP7_75t_R   g55(.A(new_n56_), .B(new_n35_), .C(new_n34_), .Y(o11));
  AO21x1_ASAP7_75t_R   g56(.A1(p0), .A2(new_n41_), .B(new_n34_), .Y(new_n90_));
  OAI21x1_ASAP7_75t_R  g57(.A1(new_n42_), .A2(new_n35_), .B(new_n84_), .Y(new_n91_));
  AO22x1_ASAP7_75t_R   g58(.A1(p3), .A2(p1), .B1(new_n90_), .B2(new_n91_), .Y(o12));
  AND3x1_ASAP7_75t_R   g59(.A(new_n56_), .B(p6), .C(p1), .Y(o13));
  AND3x1_ASAP7_75t_R   g60(.A(new_n56_), .B(new_n76_), .C(p1), .Y(o14));
  AND3x1_ASAP7_75t_R   g61(.A(new_n50_), .B(p1), .C(new_n35_), .Y(o15));
  NOR2x1_ASAP7_75t_R   g62(.A(p0), .B(new_n76_), .Y(new_n96_));
  AND3x1_ASAP7_75t_R   g63(.A(new_n50_), .B(new_n96_), .C(p1), .Y(o16));
  AND3x1_ASAP7_75t_R   g64(.A(new_n50_), .B(p1), .C(new_n71_), .Y(o17));
  AND3x1_ASAP7_75t_R   g65(.A(new_n50_), .B(new_n87_), .C(p1), .Y(o18));
  AND3x1_ASAP7_75t_R   g66(.A(new_n41_), .B(new_n42_), .C(p1), .Y(o19));
  OAI21x1_ASAP7_75t_R  g67(.A1(new_n42_), .A2(p4), .B(new_n61_), .Y(new_n101_));
  NOR2x1_ASAP7_75t_R   g68(.A(p3), .B(p0), .Y(new_n102_));
  AND2x2_ASAP7_75t_R   g69(.A(p2), .B(p6), .Y(new_n103_));
  AOI21x1_ASAP7_75t_R  g70(.A1(new_n102_), .A2(new_n103_), .B(p1), .Y(new_n104_));
  OA21x2_ASAP7_75t_R   g71(.A1(new_n36_), .A2(new_n71_), .B(p1), .Y(new_n105_));
  AOI21x1_ASAP7_75t_R  g72(.A1(new_n101_), .A2(new_n104_), .B(new_n105_), .Y(o20));
  NOR3x1_ASAP7_75t_R   g73(.A(new_n59_), .B(p5), .C(new_n42_), .Y(new_n107_));
  NOR2x1_ASAP7_75t_R   g74(.A(p1), .B(new_n76_), .Y(new_n108_));
  OA211x2_ASAP7_75t_R  g75(.A1(new_n102_), .A2(new_n107_), .B(p2), .C(new_n108_), .Y(o21));
  AOI21x1_ASAP7_75t_R  g76(.A1(new_n34_), .A2(new_n65_), .B(new_n105_), .Y(o22));
  assign               o23 = 1'b1;
  OA211x2_ASAP7_75t_R  g77(.A1(new_n35_), .A2(new_n71_), .B(p3), .C(new_n84_), .Y(o24));
  AND3x1_ASAP7_75t_R   g78(.A(new_n96_), .B(p3), .C(new_n84_), .Y(o25));
endmodule


