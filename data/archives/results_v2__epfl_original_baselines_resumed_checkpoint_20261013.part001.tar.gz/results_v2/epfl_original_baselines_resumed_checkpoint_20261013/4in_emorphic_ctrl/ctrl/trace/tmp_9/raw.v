// Benchmark "/tmp/" written by ABC on Tue Oct 13 18:51:57 2026

module \/tmp/  ( 
    p1, p3, p2, p4, p0, p6, p5,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25  );
  input  p1, p3, p2, p4, p0, p6, p5;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25;
  wire new_n34_, new_n35_, new_n36_, new_n37_, new_n38_, new_n39_, new_n40_,
    new_n42_, new_n43_, new_n44_, new_n45_, new_n46_, new_n47_, new_n48_,
    new_n49_, new_n51_, new_n52_, new_n53_, new_n54_, new_n55_, new_n57_,
    new_n59_, new_n60_, new_n61_, new_n62_, new_n63_, new_n64_, new_n65_,
    new_n66_, new_n67_, new_n69_, new_n71_, new_n72_, new_n73_, new_n74_,
    new_n76_, new_n77_, new_n79_, new_n80_, new_n81_, new_n82_, new_n84_,
    new_n86_, new_n87_, new_n88_, new_n89_, new_n92_, new_n93_, new_n94_,
    new_n98_, new_n100_, new_n105_, new_n106_, new_n108_, new_n112_;
  NOR2x1_ASAP7_75t_R   g00(.A(p3), .B(p2), .Y(new_n34_));
  AND2x2_ASAP7_75t_R   g01(.A(p1), .B(p0), .Y(new_n35_));
  NAND2x1_ASAP7_75t_R  g02(.A(new_n34_), .B(new_n35_), .Y(new_n36_));
  INVx1_ASAP7_75t_R    g03(.A(p6), .Y(new_n37_));
  NOR2x1_ASAP7_75t_R   g04(.A(p1), .B(p0), .Y(new_n38_));
  NAND2x1_ASAP7_75t_R  g05(.A(p3), .B(p2), .Y(new_n39_));
  AO21x1_ASAP7_75t_R   g06(.A1(new_n37_), .A2(new_n38_), .B(new_n39_), .Y(new_n40_));
  NAND2x1_ASAP7_75t_R  g07(.A(new_n36_), .B(new_n40_), .Y(o0));
  INVx1_ASAP7_75t_R    g08(.A(p3), .Y(new_n42_));
  INVx1_ASAP7_75t_R    g09(.A(p2), .Y(new_n43_));
  OR3x1_ASAP7_75t_R    g10(.A(new_n42_), .B(new_n43_), .C(p6), .Y(new_n44_));
  INVx1_ASAP7_75t_R    g11(.A(p1), .Y(new_n45_));
  AOI21x1_ASAP7_75t_R  g12(.A1(p0), .A2(new_n34_), .B(new_n45_), .Y(new_n46_));
  NAND2x1_ASAP7_75t_R  g13(.A(p0), .B(new_n45_), .Y(new_n47_));
  NOR2x1_ASAP7_75t_R   g14(.A(p2), .B(new_n42_), .Y(new_n48_));
  NOR2x1_ASAP7_75t_R   g15(.A(new_n47_), .B(new_n48_), .Y(new_n49_));
  AOI211x1_ASAP7_75t_R g16(.A1(new_n38_), .A2(new_n44_), .B(new_n46_), .C(new_n49_), .Y(o1));
  INVx1_ASAP7_75t_R    g17(.A(p0), .Y(new_n51_));
  NOR2x1_ASAP7_75t_R   g18(.A(p3), .B(new_n43_), .Y(new_n52_));
  NOR2x1_ASAP7_75t_R   g19(.A(new_n51_), .B(new_n52_), .Y(new_n53_));
  OR3x1_ASAP7_75t_R    g20(.A(new_n42_), .B(p2), .C(p6), .Y(new_n54_));
  OR3x1_ASAP7_75t_R    g21(.A(new_n39_), .B(p1), .C(p6), .Y(new_n55_));
  AOI22x1_ASAP7_75t_R  g22(.A1(new_n53_), .A2(new_n54_), .B1(new_n47_), .B2(new_n55_), .Y(o2));
  AND3x1_ASAP7_75t_R   g23(.A(new_n45_), .B(new_n51_), .C(p2), .Y(new_n57_));
  OA22x2_ASAP7_75t_R   g24(.A1(new_n57_), .A2(new_n48_), .B1(new_n37_), .B2(new_n39_), .Y(o3));
  NAND2x1_ASAP7_75t_R  g25(.A(p4), .B(p0), .Y(new_n59_));
  OA31x2_ASAP7_75t_R   g26(.A1(p6), .A2(new_n39_), .A3(new_n59_), .B1(new_n45_), .Y(new_n60_));
  INVx1_ASAP7_75t_R    g27(.A(p5), .Y(new_n61_));
  NAND2x1_ASAP7_75t_R  g28(.A(p3), .B(new_n61_), .Y(new_n62_));
  INVx1_ASAP7_75t_R    g29(.A(p4), .Y(new_n63_));
  NAND2x1_ASAP7_75t_R  g30(.A(p3), .B(new_n63_), .Y(new_n64_));
  AND3x1_ASAP7_75t_R   g31(.A(p2), .B(p0), .C(p6), .Y(new_n65_));
  NAND3x1_ASAP7_75t_R  g32(.A(new_n62_), .B(new_n64_), .C(new_n65_), .Y(new_n66_));
  AOI21x1_ASAP7_75t_R  g33(.A1(p6), .A2(new_n48_), .B(new_n45_), .Y(new_n67_));
  AOI21x1_ASAP7_75t_R  g34(.A1(new_n60_), .A2(new_n66_), .B(new_n67_), .Y(o4));
  AND3x1_ASAP7_75t_R   g35(.A(new_n45_), .B(p2), .C(p0), .Y(new_n69_));
  AO22x1_ASAP7_75t_R   g36(.A1(new_n35_), .A2(new_n48_), .B1(new_n62_), .B2(new_n69_), .Y(o5));
  AO21x1_ASAP7_75t_R   g37(.A1(new_n42_), .A2(new_n43_), .B(p1), .Y(new_n71_));
  AND2x2_ASAP7_75t_R   g38(.A(p0), .B(p6), .Y(new_n72_));
  INVx1_ASAP7_75t_R    g39(.A(new_n72_), .Y(new_n73_));
  NOR2x1_ASAP7_75t_R   g40(.A(p1), .B(new_n39_), .Y(new_n74_));
  AOI22x1_ASAP7_75t_R  g41(.A1(new_n71_), .A2(new_n39_), .B1(new_n73_), .B2(new_n74_), .Y(o6));
  OR4x2_ASAP7_75t_R    g42(.A(new_n39_), .B(p1), .C(p0), .D(p6), .Y(new_n76_));
  OR3x1_ASAP7_75t_R    g43(.A(new_n39_), .B(new_n45_), .C(new_n37_), .Y(new_n77_));
  NAND3x1_ASAP7_75t_R  g44(.A(new_n76_), .B(new_n36_), .C(new_n77_), .Y(o7));
  AND3x1_ASAP7_75t_R   g45(.A(p3), .B(p2), .C(p0), .Y(new_n79_));
  NOR2x1_ASAP7_75t_R   g46(.A(p1), .B(new_n51_), .Y(new_n80_));
  NOR2x1_ASAP7_75t_R   g47(.A(new_n79_), .B(new_n80_), .Y(new_n81_));
  NAND2x1_ASAP7_75t_R  g48(.A(p0), .B(new_n34_), .Y(new_n82_));
  AOI22x1_ASAP7_75t_R  g49(.A1(new_n81_), .A2(new_n82_), .B1(new_n80_), .B2(new_n54_), .Y(o8));
  AND2x2_ASAP7_75t_R   g50(.A(new_n51_), .B(new_n39_), .Y(new_n84_));
  AOI211x1_ASAP7_75t_R g51(.A1(new_n80_), .A2(new_n54_), .B(new_n46_), .C(new_n84_), .Y(o9));
  NOR2x1_ASAP7_75t_R   g52(.A(p1), .B(p2), .Y(new_n86_));
  AO21x1_ASAP7_75t_R   g53(.A1(p3), .A2(new_n38_), .B(new_n86_), .Y(new_n87_));
  NOR2x1_ASAP7_75t_R   g54(.A(new_n45_), .B(new_n48_), .Y(new_n88_));
  OAI21x1_ASAP7_75t_R  g55(.A1(new_n51_), .A2(p6), .B(new_n48_), .Y(new_n89_));
  OAI21x1_ASAP7_75t_R  g56(.A1(new_n87_), .A2(new_n88_), .B(new_n89_), .Y(o10));
  AND3x1_ASAP7_75t_R   g57(.A(new_n38_), .B(new_n34_), .C(new_n37_), .Y(o11));
  AND3x1_ASAP7_75t_R   g58(.A(new_n43_), .B(new_n51_), .C(new_n37_), .Y(new_n92_));
  AO21x1_ASAP7_75t_R   g59(.A1(p2), .A2(new_n42_), .B(new_n45_), .Y(new_n93_));
  NOR2x1_ASAP7_75t_R   g60(.A(p3), .B(p0), .Y(new_n94_));
  OAI22x1_ASAP7_75t_R  g61(.A1(new_n92_), .A2(new_n71_), .B1(new_n93_), .B2(new_n94_), .Y(o12));
  AND3x1_ASAP7_75t_R   g62(.A(new_n34_), .B(p1), .C(p6), .Y(o13));
  AND3x1_ASAP7_75t_R   g63(.A(new_n34_), .B(p1), .C(new_n37_), .Y(o14));
  AND3x1_ASAP7_75t_R   g64(.A(new_n42_), .B(new_n51_), .C(p2), .Y(new_n98_));
  AND3x1_ASAP7_75t_R   g65(.A(new_n98_), .B(p1), .C(new_n37_), .Y(o15));
  AND2x2_ASAP7_75t_R   g66(.A(p2), .B(p6), .Y(new_n100_));
  AND3x1_ASAP7_75t_R   g67(.A(new_n100_), .B(p1), .C(new_n94_), .Y(o16));
  AND3x1_ASAP7_75t_R   g68(.A(new_n52_), .B(p1), .C(new_n72_), .Y(o17));
  AND3x1_ASAP7_75t_R   g69(.A(new_n52_), .B(new_n37_), .C(new_n35_), .Y(o18));
  AND3x1_ASAP7_75t_R   g70(.A(new_n42_), .B(new_n43_), .C(p1), .Y(o19));
  AOI22x1_ASAP7_75t_R  g71(.A1(new_n64_), .A2(new_n65_), .B1(new_n94_), .B2(new_n100_), .Y(new_n105_));
  OA21x2_ASAP7_75t_R   g72(.A1(new_n39_), .A2(new_n72_), .B(p1), .Y(new_n106_));
  AOI21x1_ASAP7_75t_R  g73(.A1(new_n45_), .A2(new_n105_), .B(new_n106_), .Y(o20));
  NOR3x1_ASAP7_75t_R   g74(.A(new_n39_), .B(new_n59_), .C(p5), .Y(new_n108_));
  OA211x2_ASAP7_75t_R  g75(.A1(new_n98_), .A2(new_n108_), .B(new_n45_), .C(p6), .Y(o21));
  AOI21x1_ASAP7_75t_R  g76(.A1(new_n45_), .A2(new_n66_), .B(new_n106_), .Y(o22));
  assign               o23 = 1'b1;
  NOR2x1_ASAP7_75t_R   g77(.A(p0), .B(p6), .Y(new_n112_));
  OA211x2_ASAP7_75t_R  g78(.A1(new_n112_), .A2(new_n72_), .B(p3), .C(new_n86_), .Y(o24));
  AND3x1_ASAP7_75t_R   g79(.A(new_n48_), .B(p6), .C(new_n38_), .Y(o25));
endmodule


