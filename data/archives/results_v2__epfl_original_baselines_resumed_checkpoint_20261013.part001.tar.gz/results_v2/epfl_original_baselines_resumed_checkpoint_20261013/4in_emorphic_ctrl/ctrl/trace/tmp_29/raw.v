// Benchmark "/tmp/" written by ABC on Tue Oct 13 18:51:59 2026

module \/tmp/  ( 
    p0, p3, p2, p4, p1, p5, p6,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25  );
  input  p0, p3, p2, p4, p1, p5, p6;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25;
  wire new_n34_, new_n35_, new_n36_, new_n37_, new_n38_, new_n39_, new_n41_,
    new_n43_, new_n44_, new_n45_, new_n46_, new_n47_, new_n48_, new_n50_,
    new_n51_, new_n52_, new_n53_, new_n54_, new_n55_, new_n57_, new_n58_,
    new_n59_, new_n61_, new_n62_, new_n63_, new_n64_, new_n65_, new_n66_,
    new_n67_, new_n68_, new_n69_, new_n70_, new_n72_, new_n74_, new_n75_,
    new_n77_, new_n79_, new_n82_, new_n83_, new_n84_, new_n85_, new_n87_,
    new_n89_, new_n90_, new_n95_, new_n99_, new_n100_, new_n102_,
    new_n103_;
  INVx1_ASAP7_75t_R    g00(.A(p1), .Y(new_n34_));
  NOR2x1_ASAP7_75t_R   g01(.A(p0), .B(p6), .Y(new_n35_));
  NAND2x1_ASAP7_75t_R  g02(.A(p3), .B(p2), .Y(new_n36_));
  AO21x1_ASAP7_75t_R   g03(.A1(new_n34_), .A2(new_n35_), .B(new_n36_), .Y(new_n37_));
  INVx1_ASAP7_75t_R    g04(.A(p3), .Y(new_n38_));
  INVx1_ASAP7_75t_R    g05(.A(p2), .Y(new_n39_));
  AND3x1_ASAP7_75t_R   g06(.A(new_n38_), .B(new_n39_), .C(p1), .Y(o19));
  NAND2x1_ASAP7_75t_R  g07(.A(p0), .B(o19), .Y(new_n41_));
  NAND2x1_ASAP7_75t_R  g08(.A(new_n37_), .B(new_n41_), .Y(o0));
  INVx1_ASAP7_75t_R    g09(.A(p0), .Y(new_n43_));
  OR3x1_ASAP7_75t_R    g10(.A(new_n43_), .B(new_n38_), .C(p2), .Y(new_n44_));
  NOR2x1_ASAP7_75t_R   g11(.A(p1), .B(new_n35_), .Y(new_n45_));
  INVx1_ASAP7_75t_R    g12(.A(new_n36_), .Y(new_n46_));
  OAI21x1_ASAP7_75t_R  g13(.A1(p3), .A2(p2), .B(p1), .Y(new_n47_));
  OAI21x1_ASAP7_75t_R  g14(.A1(p0), .A2(new_n46_), .B(new_n47_), .Y(new_n48_));
  AOI21x1_ASAP7_75t_R  g15(.A1(new_n44_), .A2(new_n45_), .B(new_n48_), .Y(o1));
  NOR2x1_ASAP7_75t_R   g16(.A(p3), .B(new_n39_), .Y(new_n50_));
  NOR2x1_ASAP7_75t_R   g17(.A(new_n43_), .B(new_n50_), .Y(new_n51_));
  OR3x1_ASAP7_75t_R    g18(.A(new_n38_), .B(p2), .C(p6), .Y(new_n52_));
  NOR2x1_ASAP7_75t_R   g19(.A(p1), .B(new_n43_), .Y(new_n53_));
  INVx1_ASAP7_75t_R    g20(.A(new_n53_), .Y(new_n54_));
  OR3x1_ASAP7_75t_R    g21(.A(new_n36_), .B(p1), .C(p6), .Y(new_n55_));
  AOI22x1_ASAP7_75t_R  g22(.A1(new_n51_), .A2(new_n52_), .B1(new_n54_), .B2(new_n55_), .Y(o2));
  NOR2x1_ASAP7_75t_R   g23(.A(p0), .B(p1), .Y(new_n57_));
  NAND2x1_ASAP7_75t_R  g24(.A(p2), .B(new_n57_), .Y(new_n58_));
  NAND2x1_ASAP7_75t_R  g25(.A(p3), .B(new_n39_), .Y(new_n59_));
  AOI22x1_ASAP7_75t_R  g26(.A1(new_n58_), .A2(new_n59_), .B1(p6), .B2(new_n46_), .Y(o3));
  NAND2x1_ASAP7_75t_R  g27(.A(p0), .B(p4), .Y(new_n61_));
  OA31x2_ASAP7_75t_R   g28(.A1(p6), .A2(new_n36_), .A3(new_n61_), .B1(new_n34_), .Y(new_n62_));
  INVx1_ASAP7_75t_R    g29(.A(p5), .Y(new_n63_));
  AOI21x1_ASAP7_75t_R  g30(.A1(p3), .A2(new_n63_), .B(new_n39_), .Y(new_n64_));
  INVx1_ASAP7_75t_R    g31(.A(p4), .Y(new_n65_));
  NAND3x1_ASAP7_75t_R  g32(.A(new_n65_), .B(p3), .C(p5), .Y(new_n66_));
  AND2x2_ASAP7_75t_R   g33(.A(p0), .B(p6), .Y(new_n67_));
  NAND3x1_ASAP7_75t_R  g34(.A(new_n64_), .B(new_n66_), .C(new_n67_), .Y(new_n68_));
  INVx1_ASAP7_75t_R    g35(.A(p6), .Y(new_n69_));
  OA21x2_ASAP7_75t_R   g36(.A1(new_n69_), .A2(new_n59_), .B(p1), .Y(new_n70_));
  AOI21x1_ASAP7_75t_R  g37(.A1(new_n62_), .A2(new_n68_), .B(new_n70_), .Y(o4));
  AO21x1_ASAP7_75t_R   g38(.A1(p3), .A2(new_n39_), .B(new_n34_), .Y(new_n72_));
  OA211x2_ASAP7_75t_R  g39(.A1(p1), .A2(new_n64_), .B(new_n72_), .C(p0), .Y(o5));
  NOR2x1_ASAP7_75t_R   g40(.A(new_n36_), .B(new_n67_), .Y(new_n74_));
  AO21x1_ASAP7_75t_R   g41(.A1(new_n38_), .A2(new_n39_), .B(p1), .Y(new_n75_));
  AOI22x1_ASAP7_75t_R  g42(.A1(new_n74_), .A2(new_n34_), .B1(new_n36_), .B2(new_n75_), .Y(o6));
  AO21x1_ASAP7_75t_R   g43(.A1(p1), .A2(new_n69_), .B(new_n36_), .Y(new_n77_));
  OAI21x1_ASAP7_75t_R  g44(.A1(new_n45_), .A2(new_n77_), .B(new_n41_), .Y(o7));
  OAI21x1_ASAP7_75t_R  g45(.A1(new_n47_), .A2(new_n46_), .B(p0), .Y(new_n79_));
  AOI21x1_ASAP7_75t_R  g46(.A1(new_n53_), .A2(new_n52_), .B(new_n79_), .Y(o8));
  AOI21x1_ASAP7_75t_R  g47(.A1(new_n53_), .A2(new_n52_), .B(new_n48_), .Y(o9));
  NOR2x1_ASAP7_75t_R   g48(.A(p2), .B(new_n38_), .Y(new_n82_));
  NAND2x1_ASAP7_75t_R  g49(.A(p0), .B(new_n69_), .Y(new_n83_));
  NOR2x1_ASAP7_75t_R   g50(.A(p2), .B(p1), .Y(new_n84_));
  AOI21x1_ASAP7_75t_R  g51(.A1(p3), .A2(new_n57_), .B(new_n84_), .Y(new_n85_));
  AO22x1_ASAP7_75t_R   g52(.A1(new_n82_), .A2(new_n83_), .B1(new_n72_), .B2(new_n85_), .Y(o10));
  NOR2x1_ASAP7_75t_R   g53(.A(p3), .B(p2), .Y(new_n87_));
  AND3x1_ASAP7_75t_R   g54(.A(new_n87_), .B(new_n35_), .C(new_n34_), .Y(o11));
  OA21x2_ASAP7_75t_R   g55(.A1(p2), .A2(new_n43_), .B(new_n38_), .Y(new_n89_));
  AND3x1_ASAP7_75t_R   g56(.A(new_n43_), .B(new_n39_), .C(new_n69_), .Y(new_n90_));
  OAI22x1_ASAP7_75t_R  g57(.A1(new_n89_), .A2(new_n34_), .B1(new_n90_), .B2(new_n75_), .Y(o12));
  AND3x1_ASAP7_75t_R   g58(.A(new_n87_), .B(p1), .C(p6), .Y(o13));
  AND3x1_ASAP7_75t_R   g59(.A(new_n87_), .B(p1), .C(new_n69_), .Y(o14));
  AND3x1_ASAP7_75t_R   g60(.A(new_n50_), .B(p1), .C(new_n35_), .Y(o15));
  AND3x1_ASAP7_75t_R   g61(.A(new_n38_), .B(p2), .C(p1), .Y(new_n95_));
  AND3x1_ASAP7_75t_R   g62(.A(new_n95_), .B(new_n43_), .C(p6), .Y(o16));
  AND3x1_ASAP7_75t_R   g63(.A(new_n50_), .B(p1), .C(new_n67_), .Y(o17));
  AND3x1_ASAP7_75t_R   g64(.A(new_n95_), .B(p0), .C(new_n69_), .Y(o18));
  AO21x1_ASAP7_75t_R   g65(.A1(p3), .A2(new_n61_), .B(new_n69_), .Y(new_n99_));
  OA21x2_ASAP7_75t_R   g66(.A1(new_n36_), .A2(new_n67_), .B(p1), .Y(new_n100_));
  AOI211x1_ASAP7_75t_R g67(.A1(new_n34_), .A2(new_n99_), .B(new_n84_), .C(new_n100_), .Y(o20));
  OR3x1_ASAP7_75t_R    g68(.A(new_n39_), .B(p0), .C(p3), .Y(new_n102_));
  OR3x1_ASAP7_75t_R    g69(.A(new_n36_), .B(new_n61_), .C(p5), .Y(new_n103_));
  AOI211x1_ASAP7_75t_R g70(.A1(new_n102_), .A2(new_n103_), .B(p1), .C(new_n69_), .Y(o21));
  AOI21x1_ASAP7_75t_R  g71(.A1(new_n34_), .A2(new_n68_), .B(new_n100_), .Y(o22));
  assign               o23 = 1'b1;
  OA211x2_ASAP7_75t_R  g72(.A1(new_n35_), .A2(new_n67_), .B(p3), .C(new_n84_), .Y(o24));
  AND3x1_ASAP7_75t_R   g73(.A(new_n82_), .B(p6), .C(new_n57_), .Y(o25));
endmodule


