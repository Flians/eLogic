// Benchmark "/tmp/" written by ABC on Tue Oct 13 18:51:59 2026

module \/tmp/  ( 
    p1, p6, p2, p3, p5, p4, p0,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25  );
  input  p1, p6, p2, p3, p5, p4, p0;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25;
  wire new_n34_, new_n35_, new_n36_, new_n37_, new_n38_, new_n39_, new_n41_,
    new_n43_, new_n44_, new_n45_, new_n46_, new_n47_, new_n48_, new_n49_,
    new_n51_, new_n52_, new_n53_, new_n54_, new_n55_, new_n56_, new_n58_,
    new_n59_, new_n61_, new_n62_, new_n63_, new_n64_, new_n65_, new_n66_,
    new_n67_, new_n68_, new_n69_, new_n70_, new_n71_, new_n72_, new_n73_,
    new_n75_, new_n77_, new_n78_, new_n80_, new_n82_, new_n85_, new_n86_,
    new_n89_, new_n90_, new_n91_, new_n96_, new_n99_, new_n101_, new_n102_,
    new_n104_, new_n105_, new_n106_, new_n110_;
  INVx1_ASAP7_75t_R    g00(.A(p6), .Y(new_n34_));
  NOR2x1_ASAP7_75t_R   g01(.A(p1), .B(p0), .Y(new_n35_));
  NAND2x1_ASAP7_75t_R  g02(.A(p2), .B(p3), .Y(new_n36_));
  AO21x1_ASAP7_75t_R   g03(.A1(new_n34_), .A2(new_n35_), .B(new_n36_), .Y(new_n37_));
  INVx1_ASAP7_75t_R    g04(.A(p2), .Y(new_n38_));
  INVx1_ASAP7_75t_R    g05(.A(p3), .Y(new_n39_));
  AND3x1_ASAP7_75t_R   g06(.A(new_n38_), .B(new_n39_), .C(p1), .Y(o19));
  NAND2x1_ASAP7_75t_R  g07(.A(p0), .B(o19), .Y(new_n41_));
  NAND2x1_ASAP7_75t_R  g08(.A(new_n37_), .B(new_n41_), .Y(o0));
  INVx1_ASAP7_75t_R    g09(.A(p0), .Y(new_n43_));
  OR3x1_ASAP7_75t_R    g10(.A(new_n39_), .B(new_n43_), .C(p2), .Y(new_n44_));
  NOR2x1_ASAP7_75t_R   g11(.A(p6), .B(p0), .Y(new_n45_));
  NOR2x1_ASAP7_75t_R   g12(.A(p1), .B(new_n45_), .Y(new_n46_));
  INVx1_ASAP7_75t_R    g13(.A(new_n36_), .Y(new_n47_));
  OAI21x1_ASAP7_75t_R  g14(.A1(p2), .A2(p3), .B(p1), .Y(new_n48_));
  OAI21x1_ASAP7_75t_R  g15(.A1(p0), .A2(new_n47_), .B(new_n48_), .Y(new_n49_));
  AOI21x1_ASAP7_75t_R  g16(.A1(new_n44_), .A2(new_n46_), .B(new_n49_), .Y(o1));
  NOR2x1_ASAP7_75t_R   g17(.A(p3), .B(new_n38_), .Y(new_n51_));
  NOR2x1_ASAP7_75t_R   g18(.A(new_n43_), .B(new_n51_), .Y(new_n52_));
  OR3x1_ASAP7_75t_R    g19(.A(new_n39_), .B(p6), .C(p2), .Y(new_n53_));
  NOR2x1_ASAP7_75t_R   g20(.A(p1), .B(new_n43_), .Y(new_n54_));
  INVx1_ASAP7_75t_R    g21(.A(new_n54_), .Y(new_n55_));
  OR3x1_ASAP7_75t_R    g22(.A(new_n36_), .B(p1), .C(p6), .Y(new_n56_));
  AOI22x1_ASAP7_75t_R  g23(.A1(new_n52_), .A2(new_n53_), .B1(new_n55_), .B2(new_n56_), .Y(o2));
  NOR2x1_ASAP7_75t_R   g24(.A(p2), .B(p3), .Y(new_n58_));
  NOR2x1_ASAP7_75t_R   g25(.A(new_n38_), .B(new_n35_), .Y(new_n59_));
  AOI211x1_ASAP7_75t_R g26(.A1(p6), .A2(new_n47_), .B(new_n58_), .C(new_n59_), .Y(o3));
  AND3x1_ASAP7_75t_R   g27(.A(p3), .B(p4), .C(p0), .Y(new_n61_));
  NOR2x1_ASAP7_75t_R   g28(.A(p6), .B(new_n38_), .Y(new_n62_));
  AOI21x1_ASAP7_75t_R  g29(.A1(new_n61_), .A2(new_n62_), .B(p1), .Y(new_n63_));
  INVx1_ASAP7_75t_R    g30(.A(p5), .Y(new_n64_));
  AOI21x1_ASAP7_75t_R  g31(.A1(p3), .A2(new_n64_), .B(new_n38_), .Y(new_n65_));
  INVx1_ASAP7_75t_R    g32(.A(p4), .Y(new_n66_));
  NAND3x1_ASAP7_75t_R  g33(.A(new_n66_), .B(p3), .C(p5), .Y(new_n67_));
  AND2x2_ASAP7_75t_R   g34(.A(p6), .B(p0), .Y(new_n68_));
  NAND3x1_ASAP7_75t_R  g35(.A(new_n65_), .B(new_n67_), .C(new_n68_), .Y(new_n69_));
  NAND2x1_ASAP7_75t_R  g36(.A(p3), .B(new_n38_), .Y(new_n70_));
  INVx1_ASAP7_75t_R    g37(.A(p1), .Y(new_n71_));
  NOR2x1_ASAP7_75t_R   g38(.A(p6), .B(new_n71_), .Y(new_n72_));
  AO21x1_ASAP7_75t_R   g39(.A1(p1), .A2(new_n70_), .B(new_n72_), .Y(new_n73_));
  AOI21x1_ASAP7_75t_R  g40(.A1(new_n63_), .A2(new_n69_), .B(new_n73_), .Y(o4));
  NOR2x1_ASAP7_75t_R   g41(.A(p1), .B(new_n65_), .Y(new_n75_));
  AOI21x1_ASAP7_75t_R  g42(.A1(new_n44_), .A2(new_n55_), .B(new_n75_), .Y(o5));
  NOR2x1_ASAP7_75t_R   g43(.A(new_n36_), .B(new_n68_), .Y(new_n77_));
  AO21x1_ASAP7_75t_R   g44(.A1(new_n38_), .A2(new_n39_), .B(p1), .Y(new_n78_));
  AOI22x1_ASAP7_75t_R  g45(.A1(new_n77_), .A2(new_n71_), .B1(new_n36_), .B2(new_n78_), .Y(o6));
  AO21x1_ASAP7_75t_R   g46(.A1(p1), .A2(new_n34_), .B(new_n36_), .Y(new_n80_));
  OAI21x1_ASAP7_75t_R  g47(.A1(new_n46_), .A2(new_n80_), .B(new_n41_), .Y(o7));
  OAI21x1_ASAP7_75t_R  g48(.A1(new_n48_), .A2(new_n47_), .B(p0), .Y(new_n82_));
  AOI21x1_ASAP7_75t_R  g49(.A1(new_n54_), .A2(new_n53_), .B(new_n82_), .Y(o8));
  AOI21x1_ASAP7_75t_R  g50(.A1(new_n54_), .A2(new_n53_), .B(new_n49_), .Y(o9));
  AO21x1_ASAP7_75t_R   g51(.A1(p3), .A2(new_n43_), .B(new_n38_), .Y(new_n85_));
  AND3x1_ASAP7_75t_R   g52(.A(new_n71_), .B(new_n34_), .C(p0), .Y(new_n86_));
  OAI22x1_ASAP7_75t_R  g53(.A1(new_n85_), .A2(p1), .B1(new_n86_), .B2(new_n70_), .Y(o10));
  AND3x1_ASAP7_75t_R   g54(.A(new_n35_), .B(new_n58_), .C(new_n34_), .Y(o11));
  AND3x1_ASAP7_75t_R   g55(.A(new_n34_), .B(new_n38_), .C(new_n43_), .Y(new_n89_));
  NOR2x1_ASAP7_75t_R   g56(.A(p3), .B(p0), .Y(new_n90_));
  OR3x1_ASAP7_75t_R    g57(.A(new_n51_), .B(new_n71_), .C(new_n90_), .Y(new_n91_));
  OAI21x1_ASAP7_75t_R  g58(.A1(new_n78_), .A2(new_n89_), .B(new_n91_), .Y(o12));
  AND3x1_ASAP7_75t_R   g59(.A(new_n58_), .B(p1), .C(p6), .Y(o13));
  AND3x1_ASAP7_75t_R   g60(.A(new_n58_), .B(p1), .C(new_n34_), .Y(o14));
  AND3x1_ASAP7_75t_R   g61(.A(new_n51_), .B(p1), .C(new_n45_), .Y(o15));
  NOR2x1_ASAP7_75t_R   g62(.A(p0), .B(new_n34_), .Y(new_n96_));
  AND3x1_ASAP7_75t_R   g63(.A(new_n51_), .B(new_n96_), .C(p1), .Y(o16));
  AND3x1_ASAP7_75t_R   g64(.A(new_n51_), .B(p1), .C(new_n68_), .Y(o17));
  AND2x2_ASAP7_75t_R   g65(.A(p2), .B(p0), .Y(new_n99_));
  AND3x1_ASAP7_75t_R   g66(.A(new_n72_), .B(new_n39_), .C(new_n99_), .Y(o18));
  OA21x2_ASAP7_75t_R   g67(.A1(new_n36_), .A2(new_n68_), .B(p1), .Y(new_n101_));
  AOI211x1_ASAP7_75t_R g68(.A1(p4), .A2(new_n99_), .B(p1), .C(new_n51_), .Y(new_n102_));
  AOI211x1_ASAP7_75t_R g69(.A1(new_n71_), .A2(new_n34_), .B(new_n101_), .C(new_n102_), .Y(o20));
  AND2x2_ASAP7_75t_R   g70(.A(p3), .B(p4), .Y(new_n104_));
  AND3x1_ASAP7_75t_R   g71(.A(new_n104_), .B(new_n64_), .C(p0), .Y(new_n105_));
  AND3x1_ASAP7_75t_R   g72(.A(new_n71_), .B(p6), .C(p2), .Y(new_n106_));
  OA21x2_ASAP7_75t_R   g73(.A1(new_n90_), .A2(new_n105_), .B(new_n106_), .Y(o21));
  AOI21x1_ASAP7_75t_R  g74(.A1(new_n71_), .A2(new_n69_), .B(new_n101_), .Y(o22));
  assign               o23 = 1'b1;
  NOR2x1_ASAP7_75t_R   g75(.A(p2), .B(new_n39_), .Y(new_n110_));
  OA211x2_ASAP7_75t_R  g76(.A1(new_n45_), .A2(new_n68_), .B(new_n110_), .C(new_n71_), .Y(o24));
  AND3x1_ASAP7_75t_R   g77(.A(new_n110_), .B(new_n96_), .C(new_n71_), .Y(o25));
endmodule


