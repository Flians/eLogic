// Benchmark "/tmp/" written by ABC on Tue Oct 13 18:51:57 2026

module \/tmp/  ( 
    p5, p6, p3, p1, p0, p4, p2,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25  );
  input  p5, p6, p3, p1, p0, p4, p2;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25;
  wire new_n34_, new_n35_, new_n36_, new_n37_, new_n38_, new_n39_, new_n41_,
    new_n42_, new_n43_, new_n44_, new_n45_, new_n46_, new_n47_, new_n49_,
    new_n50_, new_n51_, new_n52_, new_n53_, new_n54_, new_n56_, new_n58_,
    new_n59_, new_n60_, new_n61_, new_n62_, new_n63_, new_n64_, new_n65_,
    new_n66_, new_n68_, new_n69_, new_n70_, new_n72_, new_n73_, new_n74_,
    new_n75_, new_n77_, new_n78_, new_n79_, new_n81_, new_n84_, new_n85_,
    new_n86_, new_n89_, new_n90_, new_n91_, new_n96_, new_n97_, new_n102_,
    new_n103_, new_n104_, new_n106_, new_n107_, new_n109_, new_n110_;
  INVx1_ASAP7_75t_R    g00(.A(p1), .Y(new_n34_));
  INVx1_ASAP7_75t_R    g01(.A(p0), .Y(new_n35_));
  OR4x2_ASAP7_75t_R    g02(.A(new_n34_), .B(new_n35_), .C(p3), .D(p2), .Y(new_n36_));
  NAND2x1_ASAP7_75t_R  g03(.A(p3), .B(p2), .Y(new_n37_));
  INVx1_ASAP7_75t_R    g04(.A(p6), .Y(new_n38_));
  NOR2x1_ASAP7_75t_R   g05(.A(p1), .B(p0), .Y(new_n39_));
  AOI22x1_ASAP7_75t_R  g06(.A1(new_n36_), .A2(new_n37_), .B1(new_n38_), .B2(new_n39_), .Y(o0));
  NOR2x1_ASAP7_75t_R   g07(.A(p1), .B(new_n35_), .Y(new_n41_));
  INVx1_ASAP7_75t_R    g08(.A(p2), .Y(new_n42_));
  NAND2x1_ASAP7_75t_R  g09(.A(p3), .B(new_n42_), .Y(new_n43_));
  AND3x1_ASAP7_75t_R   g10(.A(new_n34_), .B(new_n35_), .C(p6), .Y(new_n44_));
  AND2x2_ASAP7_75t_R   g11(.A(p3), .B(p2), .Y(new_n45_));
  OAI21x1_ASAP7_75t_R  g12(.A1(p3), .A2(p2), .B(p1), .Y(new_n46_));
  OAI21x1_ASAP7_75t_R  g13(.A1(p0), .A2(new_n45_), .B(new_n46_), .Y(new_n47_));
  AOI211x1_ASAP7_75t_R g14(.A1(new_n41_), .A2(new_n43_), .B(new_n44_), .C(new_n47_), .Y(o1));
  NOR2x1_ASAP7_75t_R   g15(.A(p3), .B(new_n42_), .Y(new_n49_));
  NOR2x1_ASAP7_75t_R   g16(.A(new_n35_), .B(new_n49_), .Y(new_n50_));
  INVx1_ASAP7_75t_R    g17(.A(p3), .Y(new_n51_));
  OR3x1_ASAP7_75t_R    g18(.A(new_n51_), .B(p6), .C(p2), .Y(new_n52_));
  INVx1_ASAP7_75t_R    g19(.A(new_n41_), .Y(new_n53_));
  OR3x1_ASAP7_75t_R    g20(.A(new_n37_), .B(p6), .C(p1), .Y(new_n54_));
  AOI22x1_ASAP7_75t_R  g21(.A1(new_n50_), .A2(new_n52_), .B1(new_n53_), .B2(new_n54_), .Y(o2));
  NAND2x1_ASAP7_75t_R  g22(.A(p2), .B(new_n39_), .Y(new_n56_));
  AOI22x1_ASAP7_75t_R  g23(.A1(new_n56_), .A2(new_n43_), .B1(p6), .B2(new_n45_), .Y(o3));
  NAND2x1_ASAP7_75t_R  g24(.A(p0), .B(p4), .Y(new_n58_));
  OA31x2_ASAP7_75t_R   g25(.A1(p6), .A2(new_n37_), .A3(new_n58_), .B1(new_n34_), .Y(new_n59_));
  AND3x1_ASAP7_75t_R   g26(.A(p6), .B(p0), .C(p2), .Y(new_n60_));
  INVx1_ASAP7_75t_R    g27(.A(p5), .Y(new_n61_));
  INVx1_ASAP7_75t_R    g28(.A(p4), .Y(new_n62_));
  OAI21x1_ASAP7_75t_R  g29(.A1(new_n61_), .A2(new_n62_), .B(p3), .Y(new_n63_));
  NAND2x1_ASAP7_75t_R  g30(.A(new_n60_), .B(new_n63_), .Y(new_n64_));
  NOR2x1_ASAP7_75t_R   g31(.A(p2), .B(new_n51_), .Y(new_n65_));
  AOI21x1_ASAP7_75t_R  g32(.A1(p6), .A2(new_n65_), .B(new_n34_), .Y(new_n66_));
  AOI21x1_ASAP7_75t_R  g33(.A1(new_n59_), .A2(new_n64_), .B(new_n66_), .Y(o4));
  NOR2x1_ASAP7_75t_R   g34(.A(new_n34_), .B(new_n65_), .Y(new_n68_));
  AO21x1_ASAP7_75t_R   g35(.A1(p5), .A2(p2), .B(p1), .Y(new_n69_));
  NOR2x1_ASAP7_75t_R   g36(.A(new_n69_), .B(new_n49_), .Y(new_n70_));
  NOR3x1_ASAP7_75t_R   g37(.A(new_n68_), .B(new_n70_), .C(new_n35_), .Y(o5));
  AND2x2_ASAP7_75t_R   g38(.A(p6), .B(p0), .Y(new_n72_));
  NOR2x1_ASAP7_75t_R   g39(.A(new_n37_), .B(new_n72_), .Y(new_n73_));
  NOR2x1_ASAP7_75t_R   g40(.A(p3), .B(p2), .Y(new_n74_));
  AO21x1_ASAP7_75t_R   g41(.A1(p1), .A2(new_n37_), .B(new_n74_), .Y(new_n75_));
  AOI21x1_ASAP7_75t_R  g42(.A1(new_n34_), .A2(new_n73_), .B(new_n75_), .Y(o6));
  AO21x1_ASAP7_75t_R   g43(.A1(new_n38_), .A2(p1), .B(new_n37_), .Y(new_n77_));
  NAND2x1_ASAP7_75t_R  g44(.A(p6), .B(new_n34_), .Y(new_n78_));
  OAI21x1_ASAP7_75t_R  g45(.A1(p6), .A2(new_n35_), .B(new_n78_), .Y(new_n79_));
  OAI21x1_ASAP7_75t_R  g46(.A1(new_n77_), .A2(new_n79_), .B(new_n36_), .Y(o7));
  NOR2x1_ASAP7_75t_R   g47(.A(new_n46_), .B(new_n45_), .Y(new_n81_));
  AOI211x1_ASAP7_75t_R g48(.A1(new_n34_), .A2(new_n52_), .B(new_n35_), .C(new_n81_), .Y(o8));
  AOI21x1_ASAP7_75t_R  g49(.A1(new_n41_), .A2(new_n52_), .B(new_n47_), .Y(o9));
  NOR2x1_ASAP7_75t_R   g50(.A(p1), .B(p2), .Y(new_n84_));
  AO21x1_ASAP7_75t_R   g51(.A1(p3), .A2(new_n39_), .B(new_n84_), .Y(new_n85_));
  NOR2x1_ASAP7_75t_R   g52(.A(p6), .B(new_n35_), .Y(new_n86_));
  OAI22x1_ASAP7_75t_R  g53(.A1(new_n68_), .A2(new_n85_), .B1(new_n43_), .B2(new_n86_), .Y(o10));
  AND3x1_ASAP7_75t_R   g54(.A(new_n39_), .B(new_n74_), .C(new_n38_), .Y(o11));
  NOR2x1_ASAP7_75t_R   g55(.A(p6), .B(p0), .Y(new_n89_));
  OA21x2_ASAP7_75t_R   g56(.A1(new_n51_), .A2(new_n89_), .B(new_n84_), .Y(new_n90_));
  OA211x2_ASAP7_75t_R  g57(.A1(new_n35_), .A2(p2), .B(new_n51_), .C(p1), .Y(new_n91_));
  NOR2x1_ASAP7_75t_R   g58(.A(new_n90_), .B(new_n91_), .Y(o12));
  AND3x1_ASAP7_75t_R   g59(.A(new_n74_), .B(p6), .C(p1), .Y(o13));
  AND3x1_ASAP7_75t_R   g60(.A(new_n74_), .B(new_n38_), .C(p1), .Y(o14));
  AND3x1_ASAP7_75t_R   g61(.A(new_n49_), .B(p1), .C(new_n89_), .Y(o15));
  AND2x2_ASAP7_75t_R   g62(.A(p6), .B(p2), .Y(new_n96_));
  NOR2x1_ASAP7_75t_R   g63(.A(p3), .B(p0), .Y(new_n97_));
  AND3x1_ASAP7_75t_R   g64(.A(new_n96_), .B(p1), .C(new_n97_), .Y(o16));
  AND3x1_ASAP7_75t_R   g65(.A(new_n60_), .B(new_n51_), .C(p1), .Y(o17));
  AND3x1_ASAP7_75t_R   g66(.A(new_n49_), .B(new_n86_), .C(p1), .Y(o18));
  AND3x1_ASAP7_75t_R   g67(.A(new_n51_), .B(new_n42_), .C(p1), .Y(o19));
  OAI21x1_ASAP7_75t_R  g68(.A1(new_n51_), .A2(p4), .B(new_n60_), .Y(new_n102_));
  AOI21x1_ASAP7_75t_R  g69(.A1(new_n97_), .A2(new_n96_), .B(p1), .Y(new_n103_));
  OA21x2_ASAP7_75t_R   g70(.A1(new_n37_), .A2(new_n72_), .B(p1), .Y(new_n104_));
  AOI21x1_ASAP7_75t_R  g71(.A1(new_n102_), .A2(new_n103_), .B(new_n104_), .Y(o20));
  NAND2x1_ASAP7_75t_R  g72(.A(p2), .B(new_n97_), .Y(new_n106_));
  OR3x1_ASAP7_75t_R    g73(.A(new_n37_), .B(new_n58_), .C(p5), .Y(new_n107_));
  AOI21x1_ASAP7_75t_R  g74(.A1(new_n106_), .A2(new_n107_), .B(new_n78_), .Y(o21));
  NAND2x1_ASAP7_75t_R  g75(.A(p5), .B(p3), .Y(new_n109_));
  OAI21x1_ASAP7_75t_R  g76(.A1(p4), .A2(new_n109_), .B(new_n72_), .Y(new_n110_));
  AOI211x1_ASAP7_75t_R g77(.A1(new_n34_), .A2(new_n110_), .B(new_n70_), .C(new_n104_), .Y(o22));
  assign               o23 = 1'b1;
  OA211x2_ASAP7_75t_R  g78(.A1(new_n89_), .A2(new_n72_), .B(p3), .C(new_n84_), .Y(o24));
  AND3x1_ASAP7_75t_R   g79(.A(new_n65_), .B(p6), .C(new_n39_), .Y(o25));
endmodule


