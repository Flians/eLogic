// Benchmark "/tmp/" written by ABC on Tue Oct 13 18:51:57 2026

module \/tmp/  ( 
    p0, p2, p1, p6, p3, p5, p4,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25  );
  input  p0, p2, p1, p6, p3, p5, p4;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25;
  wire new_n34_, new_n35_, new_n36_, new_n37_, new_n39_, new_n40_, new_n41_,
    new_n42_, new_n43_, new_n44_, new_n45_, new_n47_, new_n48_, new_n49_,
    new_n50_, new_n51_, new_n52_, new_n53_, new_n55_, new_n56_, new_n58_,
    new_n59_, new_n60_, new_n61_, new_n62_, new_n63_, new_n64_, new_n65_,
    new_n67_, new_n68_, new_n70_, new_n71_, new_n72_, new_n74_, new_n76_,
    new_n78_, new_n80_, new_n81_, new_n82_, new_n83_, new_n85_, new_n87_,
    new_n88_, new_n89_, new_n94_, new_n95_, new_n100_, new_n101_,
    new_n102_, new_n104_, new_n105_, new_n106_;
  AND2x2_ASAP7_75t_R   g00(.A(p2), .B(p3), .Y(new_n34_));
  OR3x1_ASAP7_75t_R    g01(.A(p0), .B(p1), .C(p6), .Y(new_n35_));
  NOR2x1_ASAP7_75t_R   g02(.A(p2), .B(p3), .Y(new_n36_));
  AND3x1_ASAP7_75t_R   g03(.A(new_n36_), .B(p0), .C(p1), .Y(new_n37_));
  AO21x1_ASAP7_75t_R   g04(.A1(new_n34_), .A2(new_n35_), .B(new_n37_), .Y(o0));
  NOR2x1_ASAP7_75t_R   g05(.A(p0), .B(p1), .Y(new_n39_));
  INVx1_ASAP7_75t_R    g06(.A(p1), .Y(new_n40_));
  OAI22x1_ASAP7_75t_R  g07(.A1(new_n34_), .A2(p0), .B1(new_n40_), .B2(new_n36_), .Y(new_n41_));
  NAND2x1_ASAP7_75t_R  g08(.A(p0), .B(new_n40_), .Y(new_n42_));
  INVx1_ASAP7_75t_R    g09(.A(p3), .Y(new_n43_));
  NOR2x1_ASAP7_75t_R   g10(.A(p2), .B(new_n43_), .Y(new_n44_));
  NOR2x1_ASAP7_75t_R   g11(.A(new_n42_), .B(new_n44_), .Y(new_n45_));
  AOI211x1_ASAP7_75t_R g12(.A1(p6), .A2(new_n39_), .B(new_n41_), .C(new_n45_), .Y(o1));
  INVx1_ASAP7_75t_R    g13(.A(p0), .Y(new_n47_));
  INVx1_ASAP7_75t_R    g14(.A(p2), .Y(new_n48_));
  NOR2x1_ASAP7_75t_R   g15(.A(p3), .B(new_n48_), .Y(new_n49_));
  NOR2x1_ASAP7_75t_R   g16(.A(new_n47_), .B(new_n49_), .Y(new_n50_));
  OR3x1_ASAP7_75t_R    g17(.A(new_n43_), .B(p2), .C(p6), .Y(new_n51_));
  NAND2x1_ASAP7_75t_R  g18(.A(p2), .B(p3), .Y(new_n52_));
  OR3x1_ASAP7_75t_R    g19(.A(new_n52_), .B(p1), .C(p6), .Y(new_n53_));
  AOI22x1_ASAP7_75t_R  g20(.A1(new_n50_), .A2(new_n51_), .B1(new_n42_), .B2(new_n53_), .Y(o2));
  AND3x1_ASAP7_75t_R   g21(.A(new_n47_), .B(new_n40_), .C(p2), .Y(new_n55_));
  INVx1_ASAP7_75t_R    g22(.A(p6), .Y(new_n56_));
  OA22x2_ASAP7_75t_R   g23(.A1(new_n55_), .A2(new_n44_), .B1(new_n56_), .B2(new_n52_), .Y(o3));
  NAND2x1_ASAP7_75t_R  g24(.A(p0), .B(p4), .Y(new_n58_));
  OA31x2_ASAP7_75t_R   g25(.A1(p6), .A2(new_n52_), .A3(new_n58_), .B1(new_n40_), .Y(new_n59_));
  AND3x1_ASAP7_75t_R   g26(.A(p0), .B(p2), .C(p6), .Y(new_n60_));
  INVx1_ASAP7_75t_R    g27(.A(p5), .Y(new_n61_));
  INVx1_ASAP7_75t_R    g28(.A(p4), .Y(new_n62_));
  OAI21x1_ASAP7_75t_R  g29(.A1(new_n61_), .A2(new_n62_), .B(p3), .Y(new_n63_));
  NAND2x1_ASAP7_75t_R  g30(.A(new_n60_), .B(new_n63_), .Y(new_n64_));
  AOI21x1_ASAP7_75t_R  g31(.A1(p6), .A2(new_n44_), .B(new_n40_), .Y(new_n65_));
  AOI21x1_ASAP7_75t_R  g32(.A1(new_n59_), .A2(new_n64_), .B(new_n65_), .Y(o4));
  AO21x1_ASAP7_75t_R   g33(.A1(p3), .A2(new_n61_), .B(new_n48_), .Y(new_n67_));
  NOR2x1_ASAP7_75t_R   g34(.A(new_n40_), .B(new_n44_), .Y(new_n68_));
  AOI211x1_ASAP7_75t_R g35(.A1(new_n40_), .A2(new_n67_), .B(new_n47_), .C(new_n68_), .Y(o5));
  AND2x2_ASAP7_75t_R   g36(.A(p0), .B(p6), .Y(new_n70_));
  NOR2x1_ASAP7_75t_R   g37(.A(new_n52_), .B(new_n70_), .Y(new_n71_));
  AO21x1_ASAP7_75t_R   g38(.A1(p1), .A2(new_n52_), .B(new_n36_), .Y(new_n72_));
  AOI21x1_ASAP7_75t_R  g39(.A1(new_n40_), .A2(new_n71_), .B(new_n72_), .Y(o6));
  OAI21x1_ASAP7_75t_R  g40(.A1(new_n40_), .A2(new_n56_), .B(new_n35_), .Y(new_n74_));
  AO21x1_ASAP7_75t_R   g41(.A1(new_n34_), .A2(new_n74_), .B(new_n37_), .Y(o7));
  NOR3x1_ASAP7_75t_R   g42(.A(new_n34_), .B(new_n40_), .C(new_n36_), .Y(new_n76_));
  AOI211x1_ASAP7_75t_R g43(.A1(new_n40_), .A2(new_n51_), .B(new_n47_), .C(new_n76_), .Y(o8));
  INVx1_ASAP7_75t_R    g44(.A(new_n42_), .Y(new_n78_));
  AOI21x1_ASAP7_75t_R  g45(.A1(new_n51_), .A2(new_n78_), .B(new_n41_), .Y(o9));
  NOR2x1_ASAP7_75t_R   g46(.A(p2), .B(p1), .Y(new_n80_));
  AO21x1_ASAP7_75t_R   g47(.A1(p3), .A2(new_n39_), .B(new_n80_), .Y(new_n81_));
  NAND2x1_ASAP7_75t_R  g48(.A(p3), .B(new_n48_), .Y(new_n82_));
  NOR2x1_ASAP7_75t_R   g49(.A(p6), .B(new_n47_), .Y(new_n83_));
  OAI22x1_ASAP7_75t_R  g50(.A1(new_n68_), .A2(new_n81_), .B1(new_n82_), .B2(new_n83_), .Y(o10));
  NOR2x1_ASAP7_75t_R   g51(.A(p0), .B(p6), .Y(new_n85_));
  AND3x1_ASAP7_75t_R   g52(.A(new_n36_), .B(new_n85_), .C(new_n40_), .Y(o11));
  AO21x1_ASAP7_75t_R   g53(.A1(new_n47_), .A2(new_n56_), .B(new_n43_), .Y(new_n87_));
  NAND2x1_ASAP7_75t_R  g54(.A(p0), .B(new_n48_), .Y(new_n88_));
  NOR2x1_ASAP7_75t_R   g55(.A(p3), .B(new_n40_), .Y(new_n89_));
  AOI22x1_ASAP7_75t_R  g56(.A1(new_n87_), .A2(new_n80_), .B1(new_n88_), .B2(new_n89_), .Y(o12));
  AND3x1_ASAP7_75t_R   g57(.A(new_n36_), .B(p1), .C(p6), .Y(o13));
  AND3x1_ASAP7_75t_R   g58(.A(new_n36_), .B(p1), .C(new_n56_), .Y(o14));
  AND3x1_ASAP7_75t_R   g59(.A(new_n49_), .B(p1), .C(new_n85_), .Y(o15));
  AND2x2_ASAP7_75t_R   g60(.A(p2), .B(p6), .Y(new_n94_));
  NOR2x1_ASAP7_75t_R   g61(.A(p0), .B(p3), .Y(new_n95_));
  AND3x1_ASAP7_75t_R   g62(.A(new_n94_), .B(p1), .C(new_n95_), .Y(o16));
  AND3x1_ASAP7_75t_R   g63(.A(new_n49_), .B(p1), .C(new_n70_), .Y(o17));
  AND3x1_ASAP7_75t_R   g64(.A(new_n49_), .B(new_n83_), .C(p1), .Y(o18));
  AND3x1_ASAP7_75t_R   g65(.A(new_n48_), .B(new_n43_), .C(p1), .Y(o19));
  OAI21x1_ASAP7_75t_R  g66(.A1(new_n43_), .A2(p4), .B(new_n60_), .Y(new_n100_));
  AOI21x1_ASAP7_75t_R  g67(.A1(new_n95_), .A2(new_n94_), .B(p1), .Y(new_n101_));
  OA21x2_ASAP7_75t_R   g68(.A1(new_n52_), .A2(new_n70_), .B(p1), .Y(new_n102_));
  AOI21x1_ASAP7_75t_R  g69(.A1(new_n100_), .A2(new_n101_), .B(new_n102_), .Y(o20));
  NAND2x1_ASAP7_75t_R  g70(.A(p2), .B(new_n95_), .Y(new_n104_));
  OR3x1_ASAP7_75t_R    g71(.A(new_n52_), .B(new_n58_), .C(p5), .Y(new_n105_));
  NAND2x1_ASAP7_75t_R  g72(.A(p6), .B(new_n40_), .Y(new_n106_));
  AOI21x1_ASAP7_75t_R  g73(.A1(new_n104_), .A2(new_n105_), .B(new_n106_), .Y(o21));
  AOI21x1_ASAP7_75t_R  g74(.A1(new_n40_), .A2(new_n64_), .B(new_n102_), .Y(o22));
  assign               o23 = 1'b1;
  OA211x2_ASAP7_75t_R  g75(.A1(new_n85_), .A2(new_n70_), .B(p3), .C(new_n80_), .Y(o24));
  AND3x1_ASAP7_75t_R   g76(.A(new_n44_), .B(p6), .C(new_n39_), .Y(o25));
endmodule


