// Benchmark "/tmp/" written by ABC on Tue Oct 13 18:52:03 2026

module \/tmp/  ( 
    p3, p6, p2, p0, p5, p4, p1,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25  );
  input  p3, p6, p2, p0, p5, p4, p1;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25;
  wire new_n34_, new_n35_, new_n36_, new_n37_, new_n38_, new_n39_, new_n41_,
    new_n43_, new_n44_, new_n45_, new_n46_, new_n47_, new_n48_, new_n49_,
    new_n51_, new_n52_, new_n53_, new_n54_, new_n55_, new_n57_, new_n58_,
    new_n60_, new_n61_, new_n62_, new_n63_, new_n64_, new_n65_, new_n66_,
    new_n67_, new_n68_, new_n69_, new_n70_, new_n72_, new_n74_, new_n75_,
    new_n77_, new_n78_, new_n79_, new_n80_, new_n82_, new_n85_, new_n86_,
    new_n87_, new_n88_, new_n90_, new_n92_, new_n93_, new_n94_, new_n98_,
    new_n100_, new_n104_, new_n105_, new_n106_, new_n107_, new_n108_,
    new_n110_, new_n111_, new_n112_;
  INVx1_ASAP7_75t_R    g00(.A(p0), .Y(new_n34_));
  NOR2x1_ASAP7_75t_R   g01(.A(p6), .B(p1), .Y(new_n35_));
  NAND2x1_ASAP7_75t_R  g02(.A(p3), .B(p2), .Y(new_n36_));
  AO21x1_ASAP7_75t_R   g03(.A1(new_n34_), .A2(new_n35_), .B(new_n36_), .Y(new_n37_));
  INVx1_ASAP7_75t_R    g04(.A(p3), .Y(new_n38_));
  INVx1_ASAP7_75t_R    g05(.A(p2), .Y(new_n39_));
  AND3x1_ASAP7_75t_R   g06(.A(new_n38_), .B(new_n39_), .C(p1), .Y(o19));
  NAND2x1_ASAP7_75t_R  g07(.A(p0), .B(o19), .Y(new_n41_));
  NAND2x1_ASAP7_75t_R  g08(.A(new_n37_), .B(new_n41_), .Y(o0));
  NAND2x1_ASAP7_75t_R  g09(.A(p3), .B(new_n39_), .Y(new_n43_));
  NOR2x1_ASAP7_75t_R   g10(.A(p1), .B(new_n34_), .Y(new_n44_));
  INVx1_ASAP7_75t_R    g11(.A(p1), .Y(new_n45_));
  AND3x1_ASAP7_75t_R   g12(.A(new_n34_), .B(new_n45_), .C(p6), .Y(new_n46_));
  INVx1_ASAP7_75t_R    g13(.A(new_n36_), .Y(new_n47_));
  OAI21x1_ASAP7_75t_R  g14(.A1(p3), .A2(p2), .B(p1), .Y(new_n48_));
  OAI21x1_ASAP7_75t_R  g15(.A1(p0), .A2(new_n47_), .B(new_n48_), .Y(new_n49_));
  AOI211x1_ASAP7_75t_R g16(.A1(new_n43_), .A2(new_n44_), .B(new_n46_), .C(new_n49_), .Y(o1));
  NOR2x1_ASAP7_75t_R   g17(.A(p3), .B(new_n39_), .Y(new_n51_));
  NOR2x1_ASAP7_75t_R   g18(.A(new_n34_), .B(new_n51_), .Y(new_n52_));
  OR3x1_ASAP7_75t_R    g19(.A(new_n38_), .B(p6), .C(p2), .Y(new_n53_));
  INVx1_ASAP7_75t_R    g20(.A(new_n44_), .Y(new_n54_));
  OR3x1_ASAP7_75t_R    g21(.A(new_n36_), .B(p6), .C(p1), .Y(new_n55_));
  AOI22x1_ASAP7_75t_R  g22(.A1(new_n52_), .A2(new_n53_), .B1(new_n54_), .B2(new_n55_), .Y(o2));
  NOR2x1_ASAP7_75t_R   g23(.A(p0), .B(p1), .Y(new_n57_));
  NAND2x1_ASAP7_75t_R  g24(.A(p2), .B(new_n57_), .Y(new_n58_));
  AOI22x1_ASAP7_75t_R  g25(.A1(new_n58_), .A2(new_n43_), .B1(p6), .B2(new_n47_), .Y(o3));
  AND3x1_ASAP7_75t_R   g26(.A(p3), .B(p0), .C(p4), .Y(new_n60_));
  NOR2x1_ASAP7_75t_R   g27(.A(p6), .B(new_n39_), .Y(new_n61_));
  AOI21x1_ASAP7_75t_R  g28(.A1(new_n60_), .A2(new_n61_), .B(p1), .Y(new_n62_));
  INVx1_ASAP7_75t_R    g29(.A(p5), .Y(new_n63_));
  AOI21x1_ASAP7_75t_R  g30(.A1(p3), .A2(new_n63_), .B(new_n39_), .Y(new_n64_));
  INVx1_ASAP7_75t_R    g31(.A(p4), .Y(new_n65_));
  NAND3x1_ASAP7_75t_R  g32(.A(new_n65_), .B(p3), .C(p5), .Y(new_n66_));
  AND2x2_ASAP7_75t_R   g33(.A(p6), .B(p0), .Y(new_n67_));
  NAND3x1_ASAP7_75t_R  g34(.A(new_n64_), .B(new_n66_), .C(new_n67_), .Y(new_n68_));
  NOR2x1_ASAP7_75t_R   g35(.A(p6), .B(new_n45_), .Y(new_n69_));
  AO21x1_ASAP7_75t_R   g36(.A1(p1), .A2(new_n43_), .B(new_n69_), .Y(new_n70_));
  AOI21x1_ASAP7_75t_R  g37(.A1(new_n62_), .A2(new_n68_), .B(new_n70_), .Y(o4));
  AO21x1_ASAP7_75t_R   g38(.A1(p3), .A2(new_n39_), .B(new_n45_), .Y(new_n72_));
  OA211x2_ASAP7_75t_R  g39(.A1(p1), .A2(new_n64_), .B(new_n72_), .C(p0), .Y(o5));
  AO21x1_ASAP7_75t_R   g40(.A1(new_n38_), .A2(new_n39_), .B(p1), .Y(new_n74_));
  OR3x1_ASAP7_75t_R    g41(.A(new_n35_), .B(new_n57_), .C(new_n36_), .Y(new_n75_));
  OAI21x1_ASAP7_75t_R  g42(.A1(new_n47_), .A2(new_n74_), .B(new_n75_), .Y(o6));
  INVx1_ASAP7_75t_R    g43(.A(p6), .Y(new_n77_));
  AO21x1_ASAP7_75t_R   g44(.A1(new_n77_), .A2(p1), .B(new_n36_), .Y(new_n78_));
  NAND2x1_ASAP7_75t_R  g45(.A(p6), .B(new_n45_), .Y(new_n79_));
  OAI21x1_ASAP7_75t_R  g46(.A1(p6), .A2(new_n34_), .B(new_n79_), .Y(new_n80_));
  OAI21x1_ASAP7_75t_R  g47(.A1(new_n78_), .A2(new_n80_), .B(new_n41_), .Y(o7));
  OAI21x1_ASAP7_75t_R  g48(.A1(new_n48_), .A2(new_n47_), .B(p0), .Y(new_n82_));
  AOI21x1_ASAP7_75t_R  g49(.A1(new_n44_), .A2(new_n53_), .B(new_n82_), .Y(o8));
  AOI21x1_ASAP7_75t_R  g50(.A1(new_n44_), .A2(new_n53_), .B(new_n49_), .Y(o9));
  NOR2x1_ASAP7_75t_R   g51(.A(p2), .B(new_n38_), .Y(new_n85_));
  NAND2x1_ASAP7_75t_R  g52(.A(p0), .B(new_n77_), .Y(new_n86_));
  NOR2x1_ASAP7_75t_R   g53(.A(p2), .B(p1), .Y(new_n87_));
  AOI21x1_ASAP7_75t_R  g54(.A1(p3), .A2(new_n57_), .B(new_n87_), .Y(new_n88_));
  AO22x1_ASAP7_75t_R   g55(.A1(new_n85_), .A2(new_n86_), .B1(new_n72_), .B2(new_n88_), .Y(o10));
  NOR2x1_ASAP7_75t_R   g56(.A(p3), .B(p2), .Y(new_n90_));
  AND3x1_ASAP7_75t_R   g57(.A(new_n35_), .B(new_n90_), .C(new_n34_), .Y(o11));
  AND3x1_ASAP7_75t_R   g58(.A(new_n77_), .B(new_n39_), .C(new_n34_), .Y(new_n92_));
  NOR2x1_ASAP7_75t_R   g59(.A(p3), .B(p0), .Y(new_n93_));
  OR3x1_ASAP7_75t_R    g60(.A(new_n51_), .B(new_n45_), .C(new_n93_), .Y(new_n94_));
  OAI21x1_ASAP7_75t_R  g61(.A1(new_n74_), .A2(new_n92_), .B(new_n94_), .Y(o12));
  AND3x1_ASAP7_75t_R   g62(.A(new_n90_), .B(p6), .C(p1), .Y(o13));
  AND3x1_ASAP7_75t_R   g63(.A(new_n90_), .B(new_n77_), .C(p1), .Y(o14));
  NOR2x1_ASAP7_75t_R   g64(.A(p6), .B(p0), .Y(new_n98_));
  AND3x1_ASAP7_75t_R   g65(.A(new_n51_), .B(p1), .C(new_n98_), .Y(o15));
  AND2x2_ASAP7_75t_R   g66(.A(p6), .B(p1), .Y(new_n100_));
  AND3x1_ASAP7_75t_R   g67(.A(new_n51_), .B(new_n34_), .C(new_n100_), .Y(o16));
  AND3x1_ASAP7_75t_R   g68(.A(new_n51_), .B(p1), .C(new_n67_), .Y(o17));
  AND3x1_ASAP7_75t_R   g69(.A(new_n51_), .B(new_n69_), .C(p0), .Y(o18));
  AND3x1_ASAP7_75t_R   g70(.A(p6), .B(p2), .C(p0), .Y(new_n104_));
  OAI21x1_ASAP7_75t_R  g71(.A1(new_n38_), .A2(p4), .B(new_n104_), .Y(new_n105_));
  AND2x2_ASAP7_75t_R   g72(.A(p6), .B(p2), .Y(new_n106_));
  AOI21x1_ASAP7_75t_R  g73(.A1(new_n93_), .A2(new_n106_), .B(p1), .Y(new_n107_));
  OA21x2_ASAP7_75t_R   g74(.A1(new_n36_), .A2(new_n67_), .B(p1), .Y(new_n108_));
  AOI21x1_ASAP7_75t_R  g75(.A1(new_n105_), .A2(new_n107_), .B(new_n108_), .Y(o20));
  AND3x1_ASAP7_75t_R   g76(.A(new_n38_), .B(new_n34_), .C(p2), .Y(new_n110_));
  AND3x1_ASAP7_75t_R   g77(.A(new_n60_), .B(p2), .C(new_n63_), .Y(new_n111_));
  INVx1_ASAP7_75t_R    g78(.A(new_n79_), .Y(new_n112_));
  OA21x2_ASAP7_75t_R   g79(.A1(new_n110_), .A2(new_n111_), .B(new_n112_), .Y(o21));
  AOI21x1_ASAP7_75t_R  g80(.A1(new_n45_), .A2(new_n68_), .B(new_n108_), .Y(o22));
  assign               o23 = 1'b1;
  OA211x2_ASAP7_75t_R  g81(.A1(new_n98_), .A2(new_n67_), .B(p3), .C(new_n87_), .Y(o24));
  AND3x1_ASAP7_75t_R   g82(.A(new_n112_), .B(new_n34_), .C(new_n85_), .Y(o25));
endmodule


