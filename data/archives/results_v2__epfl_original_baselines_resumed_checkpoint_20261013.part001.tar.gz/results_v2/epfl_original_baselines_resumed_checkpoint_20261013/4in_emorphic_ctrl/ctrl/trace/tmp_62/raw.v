// Benchmark "/tmp/" written by ABC on Tue Oct 13 18:52:02 2026

module \/tmp/  ( 
    p1, p0, p4, p2, p3, p5, p6,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25  );
  input  p1, p0, p4, p2, p3, p5, p6;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25;
  wire new_n34_, new_n35_, new_n36_, new_n37_, new_n38_, new_n39_, new_n41_,
    new_n43_, new_n44_, new_n45_, new_n46_, new_n47_, new_n48_, new_n49_,
    new_n51_, new_n52_, new_n53_, new_n54_, new_n55_, new_n57_, new_n58_,
    new_n60_, new_n61_, new_n62_, new_n63_, new_n64_, new_n65_, new_n66_,
    new_n67_, new_n68_, new_n69_, new_n71_, new_n72_, new_n74_, new_n75_,
    new_n76_, new_n78_, new_n79_, new_n81_, new_n82_, new_n83_, new_n85_,
    new_n87_, new_n88_, new_n89_, new_n92_, new_n93_, new_n94_, new_n98_,
    new_n100_, new_n104_, new_n105_, new_n106_, new_n108_, new_n110_;
  INVx1_ASAP7_75t_R    g00(.A(p6), .Y(new_n34_));
  NOR2x1_ASAP7_75t_R   g01(.A(p1), .B(p0), .Y(new_n35_));
  NAND2x1_ASAP7_75t_R  g02(.A(p2), .B(p3), .Y(new_n36_));
  AO21x1_ASAP7_75t_R   g03(.A1(new_n34_), .A2(new_n35_), .B(new_n36_), .Y(new_n37_));
  INVx1_ASAP7_75t_R    g04(.A(p2), .Y(new_n38_));
  INVx1_ASAP7_75t_R    g05(.A(p3), .Y(new_n39_));
  AND3x1_ASAP7_75t_R   g06(.A(new_n38_), .B(new_n39_), .C(p1), .Y(o19));
  NAND2x1_ASAP7_75t_R  g07(.A(p0), .B(o19), .Y(new_n41_));
  NAND2x1_ASAP7_75t_R  g08(.A(new_n37_), .B(new_n41_), .Y(o0));
  OR3x1_ASAP7_75t_R    g09(.A(new_n38_), .B(new_n39_), .C(p6), .Y(new_n43_));
  NOR2x1_ASAP7_75t_R   g10(.A(p2), .B(p3), .Y(new_n44_));
  INVx1_ASAP7_75t_R    g11(.A(p1), .Y(new_n45_));
  AOI21x1_ASAP7_75t_R  g12(.A1(p0), .A2(new_n44_), .B(new_n45_), .Y(new_n46_));
  NAND2x1_ASAP7_75t_R  g13(.A(p0), .B(new_n45_), .Y(new_n47_));
  NOR2x1_ASAP7_75t_R   g14(.A(p2), .B(new_n39_), .Y(new_n48_));
  NOR2x1_ASAP7_75t_R   g15(.A(new_n47_), .B(new_n48_), .Y(new_n49_));
  AOI211x1_ASAP7_75t_R g16(.A1(new_n35_), .A2(new_n43_), .B(new_n46_), .C(new_n49_), .Y(o1));
  INVx1_ASAP7_75t_R    g17(.A(p0), .Y(new_n51_));
  NOR2x1_ASAP7_75t_R   g18(.A(p3), .B(new_n38_), .Y(new_n52_));
  NOR2x1_ASAP7_75t_R   g19(.A(new_n51_), .B(new_n52_), .Y(new_n53_));
  OR3x1_ASAP7_75t_R    g20(.A(new_n39_), .B(p2), .C(p6), .Y(new_n54_));
  OR3x1_ASAP7_75t_R    g21(.A(new_n36_), .B(p1), .C(p6), .Y(new_n55_));
  AOI22x1_ASAP7_75t_R  g22(.A1(new_n53_), .A2(new_n54_), .B1(new_n47_), .B2(new_n55_), .Y(o2));
  AO21x1_ASAP7_75t_R   g23(.A1(new_n45_), .A2(new_n51_), .B(new_n38_), .Y(new_n57_));
  INVx1_ASAP7_75t_R    g24(.A(new_n44_), .Y(new_n58_));
  OA211x2_ASAP7_75t_R  g25(.A1(new_n34_), .A2(new_n36_), .B(new_n57_), .C(new_n58_), .Y(o3));
  NAND2x1_ASAP7_75t_R  g26(.A(p0), .B(p4), .Y(new_n60_));
  OA31x2_ASAP7_75t_R   g27(.A1(p6), .A2(new_n36_), .A3(new_n60_), .B1(new_n45_), .Y(new_n61_));
  INVx1_ASAP7_75t_R    g28(.A(p5), .Y(new_n62_));
  AOI21x1_ASAP7_75t_R  g29(.A1(p3), .A2(new_n62_), .B(new_n38_), .Y(new_n63_));
  INVx1_ASAP7_75t_R    g30(.A(p4), .Y(new_n64_));
  NAND3x1_ASAP7_75t_R  g31(.A(new_n64_), .B(p3), .C(p5), .Y(new_n65_));
  NAND2x1_ASAP7_75t_R  g32(.A(p0), .B(p6), .Y(new_n66_));
  INVx1_ASAP7_75t_R    g33(.A(new_n66_), .Y(new_n67_));
  NAND3x1_ASAP7_75t_R  g34(.A(new_n63_), .B(new_n65_), .C(new_n67_), .Y(new_n68_));
  AOI21x1_ASAP7_75t_R  g35(.A1(p6), .A2(new_n48_), .B(new_n45_), .Y(new_n69_));
  AOI21x1_ASAP7_75t_R  g36(.A1(new_n61_), .A2(new_n68_), .B(new_n69_), .Y(o4));
  NOR2x1_ASAP7_75t_R   g37(.A(new_n45_), .B(new_n48_), .Y(new_n71_));
  OAI21x1_ASAP7_75t_R  g38(.A1(p1), .A2(new_n63_), .B(p0), .Y(new_n72_));
  NOR2x1_ASAP7_75t_R   g39(.A(new_n71_), .B(new_n72_), .Y(o5));
  AND2x2_ASAP7_75t_R   g40(.A(p2), .B(p3), .Y(new_n74_));
  AO21x1_ASAP7_75t_R   g41(.A1(new_n38_), .A2(new_n39_), .B(p1), .Y(new_n75_));
  AO21x1_ASAP7_75t_R   g42(.A1(new_n45_), .A2(new_n66_), .B(new_n36_), .Y(new_n76_));
  OAI21x1_ASAP7_75t_R  g43(.A1(new_n74_), .A2(new_n75_), .B(new_n76_), .Y(o6));
  OR3x1_ASAP7_75t_R    g44(.A(p1), .B(p0), .C(p6), .Y(new_n78_));
  OA21x2_ASAP7_75t_R   g45(.A1(new_n45_), .A2(new_n34_), .B(new_n78_), .Y(new_n79_));
  OAI21x1_ASAP7_75t_R  g46(.A1(new_n36_), .A2(new_n79_), .B(new_n41_), .Y(o7));
  INVx1_ASAP7_75t_R    g47(.A(new_n47_), .Y(new_n81_));
  AO21x1_ASAP7_75t_R   g48(.A1(p1), .A2(new_n36_), .B(new_n51_), .Y(new_n82_));
  NAND2x1_ASAP7_75t_R  g49(.A(p0), .B(new_n44_), .Y(new_n83_));
  AOI22x1_ASAP7_75t_R  g50(.A1(new_n81_), .A2(new_n54_), .B1(new_n82_), .B2(new_n83_), .Y(o8));
  AND2x2_ASAP7_75t_R   g51(.A(new_n51_), .B(new_n36_), .Y(new_n85_));
  AOI211x1_ASAP7_75t_R g52(.A1(new_n54_), .A2(new_n81_), .B(new_n46_), .C(new_n85_), .Y(o9));
  NOR2x1_ASAP7_75t_R   g53(.A(p1), .B(p2), .Y(new_n87_));
  AO21x1_ASAP7_75t_R   g54(.A1(p3), .A2(new_n35_), .B(new_n87_), .Y(new_n88_));
  OAI21x1_ASAP7_75t_R  g55(.A1(new_n51_), .A2(p6), .B(new_n48_), .Y(new_n89_));
  AOI21x1_ASAP7_75t_R  g56(.A1(new_n88_), .A2(new_n89_), .B(new_n71_), .Y(o10));
  AND3x1_ASAP7_75t_R   g57(.A(new_n35_), .B(new_n44_), .C(new_n34_), .Y(o11));
  AND3x1_ASAP7_75t_R   g58(.A(new_n51_), .B(new_n38_), .C(new_n34_), .Y(new_n92_));
  NOR2x1_ASAP7_75t_R   g59(.A(p0), .B(p3), .Y(new_n93_));
  OR3x1_ASAP7_75t_R    g60(.A(new_n52_), .B(new_n45_), .C(new_n93_), .Y(new_n94_));
  OAI21x1_ASAP7_75t_R  g61(.A1(new_n75_), .A2(new_n92_), .B(new_n94_), .Y(o12));
  AND3x1_ASAP7_75t_R   g62(.A(new_n44_), .B(p1), .C(p6), .Y(o13));
  AND3x1_ASAP7_75t_R   g63(.A(new_n44_), .B(p1), .C(new_n34_), .Y(o14));
  NOR2x1_ASAP7_75t_R   g64(.A(p0), .B(p6), .Y(new_n98_));
  AND3x1_ASAP7_75t_R   g65(.A(new_n52_), .B(p1), .C(new_n98_), .Y(o15));
  AND3x1_ASAP7_75t_R   g66(.A(new_n39_), .B(p1), .C(p2), .Y(new_n100_));
  AND3x1_ASAP7_75t_R   g67(.A(new_n100_), .B(new_n51_), .C(p6), .Y(o16));
  AND3x1_ASAP7_75t_R   g68(.A(new_n67_), .B(new_n52_), .C(p1), .Y(o17));
  AND3x1_ASAP7_75t_R   g69(.A(new_n100_), .B(p0), .C(new_n34_), .Y(o18));
  NAND2x1_ASAP7_75t_R  g70(.A(p3), .B(new_n60_), .Y(new_n104_));
  AND3x1_ASAP7_75t_R   g71(.A(new_n45_), .B(p2), .C(p6), .Y(new_n105_));
  AND3x1_ASAP7_75t_R   g72(.A(new_n74_), .B(p1), .C(new_n66_), .Y(new_n106_));
  AO21x1_ASAP7_75t_R   g73(.A1(new_n104_), .A2(new_n105_), .B(new_n106_), .Y(o20));
  AO21x1_ASAP7_75t_R   g74(.A1(p3), .A2(new_n62_), .B(new_n93_), .Y(new_n108_));
  AND3x1_ASAP7_75t_R   g75(.A(new_n108_), .B(new_n104_), .C(new_n105_), .Y(o21));
  AOI211x1_ASAP7_75t_R g76(.A1(p3), .A2(new_n62_), .B(new_n38_), .C(new_n66_), .Y(new_n110_));
  AO31x2_ASAP7_75t_R   g77(.A1(new_n45_), .A2(new_n65_), .A3(new_n110_), .B(new_n106_), .Y(o22));
  assign               o23 = 1'b1;
  OA211x2_ASAP7_75t_R  g78(.A1(new_n98_), .A2(new_n67_), .B(p3), .C(new_n87_), .Y(o24));
  AND3x1_ASAP7_75t_R   g79(.A(new_n48_), .B(p6), .C(new_n35_), .Y(o25));
endmodule


