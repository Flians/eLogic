// Benchmark "/tmp/" written by ABC on Tue Oct 13 18:51:59 2026

module \/tmp/  ( 
    p1, p5, p3, p6, p0, p4, p2,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25  );
  input  p1, p5, p3, p6, p0, p4, p2;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25;
  wire new_n34_, new_n35_, new_n36_, new_n37_, new_n38_, new_n40_, new_n41_,
    new_n42_, new_n43_, new_n44_, new_n45_, new_n46_, new_n47_, new_n49_,
    new_n50_, new_n51_, new_n52_, new_n53_, new_n54_, new_n55_, new_n57_,
    new_n59_, new_n60_, new_n61_, new_n62_, new_n63_, new_n64_, new_n65_,
    new_n66_, new_n67_, new_n68_, new_n69_, new_n70_, new_n72_, new_n73_,
    new_n74_, new_n76_, new_n77_, new_n79_, new_n80_, new_n82_, new_n85_,
    new_n86_, new_n87_, new_n88_, new_n91_, new_n92_, new_n96_, new_n98_,
    new_n103_, new_n104_, new_n105_, new_n107_, new_n108_, new_n110_;
  NOR2x1_ASAP7_75t_R   g00(.A(p3), .B(p2), .Y(new_n34_));
  AND3x1_ASAP7_75t_R   g01(.A(new_n34_), .B(p1), .C(p0), .Y(new_n35_));
  AND2x2_ASAP7_75t_R   g02(.A(p3), .B(p2), .Y(new_n36_));
  NOR2x1_ASAP7_75t_R   g03(.A(p1), .B(p0), .Y(new_n37_));
  INVx1_ASAP7_75t_R    g04(.A(new_n37_), .Y(new_n38_));
  OA22x2_ASAP7_75t_R   g05(.A1(new_n35_), .A2(new_n36_), .B1(p6), .B2(new_n38_), .Y(o0));
  INVx1_ASAP7_75t_R    g06(.A(p2), .Y(new_n40_));
  NAND2x1_ASAP7_75t_R  g07(.A(p3), .B(new_n40_), .Y(new_n41_));
  INVx1_ASAP7_75t_R    g08(.A(p0), .Y(new_n42_));
  NOR2x1_ASAP7_75t_R   g09(.A(p1), .B(new_n42_), .Y(new_n43_));
  INVx1_ASAP7_75t_R    g10(.A(p1), .Y(new_n44_));
  AND3x1_ASAP7_75t_R   g11(.A(new_n44_), .B(new_n42_), .C(p6), .Y(new_n45_));
  OAI21x1_ASAP7_75t_R  g12(.A1(p3), .A2(p2), .B(p1), .Y(new_n46_));
  OAI21x1_ASAP7_75t_R  g13(.A1(p0), .A2(new_n36_), .B(new_n46_), .Y(new_n47_));
  AOI211x1_ASAP7_75t_R g14(.A1(new_n41_), .A2(new_n43_), .B(new_n45_), .C(new_n47_), .Y(o1));
  NOR2x1_ASAP7_75t_R   g15(.A(p3), .B(new_n40_), .Y(new_n49_));
  NOR2x1_ASAP7_75t_R   g16(.A(new_n42_), .B(new_n49_), .Y(new_n50_));
  INVx1_ASAP7_75t_R    g17(.A(p3), .Y(new_n51_));
  OR3x1_ASAP7_75t_R    g18(.A(new_n51_), .B(p6), .C(p2), .Y(new_n52_));
  INVx1_ASAP7_75t_R    g19(.A(new_n43_), .Y(new_n53_));
  NAND2x1_ASAP7_75t_R  g20(.A(p3), .B(p2), .Y(new_n54_));
  OR3x1_ASAP7_75t_R    g21(.A(new_n54_), .B(p1), .C(p6), .Y(new_n55_));
  AOI22x1_ASAP7_75t_R  g22(.A1(new_n50_), .A2(new_n52_), .B1(new_n53_), .B2(new_n55_), .Y(o2));
  AO21x1_ASAP7_75t_R   g23(.A1(p2), .A2(new_n38_), .B(new_n34_), .Y(new_n57_));
  AOI21x1_ASAP7_75t_R  g24(.A1(p6), .A2(new_n36_), .B(new_n57_), .Y(o3));
  AND3x1_ASAP7_75t_R   g25(.A(p3), .B(p0), .C(p4), .Y(new_n59_));
  NOR2x1_ASAP7_75t_R   g26(.A(p6), .B(new_n40_), .Y(new_n60_));
  AOI21x1_ASAP7_75t_R  g27(.A1(new_n59_), .A2(new_n60_), .B(p1), .Y(new_n61_));
  INVx1_ASAP7_75t_R    g28(.A(p5), .Y(new_n62_));
  AOI21x1_ASAP7_75t_R  g29(.A1(p3), .A2(new_n62_), .B(new_n40_), .Y(new_n63_));
  INVx1_ASAP7_75t_R    g30(.A(p4), .Y(new_n64_));
  NAND3x1_ASAP7_75t_R  g31(.A(new_n64_), .B(p5), .C(p3), .Y(new_n65_));
  NAND2x1_ASAP7_75t_R  g32(.A(p6), .B(p0), .Y(new_n66_));
  INVx1_ASAP7_75t_R    g33(.A(new_n66_), .Y(new_n67_));
  NAND3x1_ASAP7_75t_R  g34(.A(new_n63_), .B(new_n65_), .C(new_n67_), .Y(new_n68_));
  INVx1_ASAP7_75t_R    g35(.A(p6), .Y(new_n69_));
  OA21x2_ASAP7_75t_R   g36(.A1(new_n69_), .A2(new_n41_), .B(p1), .Y(new_n70_));
  AOI21x1_ASAP7_75t_R  g37(.A1(new_n61_), .A2(new_n68_), .B(new_n70_), .Y(o4));
  NOR2x1_ASAP7_75t_R   g38(.A(p2), .B(new_n51_), .Y(new_n72_));
  NOR2x1_ASAP7_75t_R   g39(.A(new_n44_), .B(new_n72_), .Y(new_n73_));
  OAI21x1_ASAP7_75t_R  g40(.A1(p1), .A2(new_n63_), .B(p0), .Y(new_n74_));
  NOR2x1_ASAP7_75t_R   g41(.A(new_n73_), .B(new_n74_), .Y(o5));
  AO21x1_ASAP7_75t_R   g42(.A1(new_n51_), .A2(new_n40_), .B(p1), .Y(new_n76_));
  AO21x1_ASAP7_75t_R   g43(.A1(new_n44_), .A2(new_n66_), .B(new_n54_), .Y(new_n77_));
  OAI21x1_ASAP7_75t_R  g44(.A1(new_n36_), .A2(new_n76_), .B(new_n77_), .Y(o6));
  AND3x1_ASAP7_75t_R   g45(.A(new_n36_), .B(p1), .C(p6), .Y(new_n79_));
  AND3x1_ASAP7_75t_R   g46(.A(new_n36_), .B(new_n69_), .C(new_n37_), .Y(new_n80_));
  OR3x1_ASAP7_75t_R    g47(.A(new_n79_), .B(new_n80_), .C(new_n35_), .Y(o7));
  OAI21x1_ASAP7_75t_R  g48(.A1(new_n46_), .A2(new_n36_), .B(p0), .Y(new_n82_));
  AOI21x1_ASAP7_75t_R  g49(.A1(new_n43_), .A2(new_n52_), .B(new_n82_), .Y(o8));
  AOI21x1_ASAP7_75t_R  g50(.A1(new_n43_), .A2(new_n52_), .B(new_n47_), .Y(o9));
  OAI21x1_ASAP7_75t_R  g51(.A1(p6), .A2(new_n42_), .B(new_n72_), .Y(new_n85_));
  NAND2x1_ASAP7_75t_R  g52(.A(p2), .B(new_n51_), .Y(new_n86_));
  NAND2x1_ASAP7_75t_R  g53(.A(p0), .B(p2), .Y(new_n87_));
  AND3x1_ASAP7_75t_R   g54(.A(new_n86_), .B(new_n44_), .C(new_n87_), .Y(new_n88_));
  AOI21x1_ASAP7_75t_R  g55(.A1(new_n85_), .A2(new_n88_), .B(new_n73_), .Y(o10));
  AND3x1_ASAP7_75t_R   g56(.A(new_n37_), .B(new_n34_), .C(new_n69_), .Y(o11));
  OA21x2_ASAP7_75t_R   g57(.A1(p2), .A2(new_n42_), .B(new_n51_), .Y(new_n91_));
  AND3x1_ASAP7_75t_R   g58(.A(new_n69_), .B(new_n42_), .C(new_n40_), .Y(new_n92_));
  OAI22x1_ASAP7_75t_R  g59(.A1(new_n91_), .A2(new_n44_), .B1(new_n92_), .B2(new_n76_), .Y(o12));
  AND3x1_ASAP7_75t_R   g60(.A(new_n34_), .B(p1), .C(p6), .Y(o13));
  AND3x1_ASAP7_75t_R   g61(.A(new_n34_), .B(p1), .C(new_n69_), .Y(o14));
  NOR2x1_ASAP7_75t_R   g62(.A(p6), .B(p0), .Y(new_n96_));
  AND3x1_ASAP7_75t_R   g63(.A(new_n49_), .B(p1), .C(new_n96_), .Y(o15));
  AND3x1_ASAP7_75t_R   g64(.A(new_n51_), .B(p1), .C(p2), .Y(new_n98_));
  AND3x1_ASAP7_75t_R   g65(.A(new_n98_), .B(p6), .C(new_n42_), .Y(o16));
  AND3x1_ASAP7_75t_R   g66(.A(new_n67_), .B(new_n49_), .C(p1), .Y(o17));
  AND3x1_ASAP7_75t_R   g67(.A(new_n98_), .B(new_n69_), .C(p0), .Y(o18));
  AND3x1_ASAP7_75t_R   g68(.A(new_n51_), .B(new_n40_), .C(p1), .Y(o19));
  NOR2x1_ASAP7_75t_R   g69(.A(p1), .B(new_n69_), .Y(new_n103_));
  OAI21x1_ASAP7_75t_R  g70(.A1(new_n64_), .A2(new_n87_), .B(new_n86_), .Y(new_n104_));
  AND3x1_ASAP7_75t_R   g71(.A(new_n36_), .B(p1), .C(new_n66_), .Y(new_n105_));
  AO21x1_ASAP7_75t_R   g72(.A1(new_n103_), .A2(new_n104_), .B(new_n105_), .Y(o20));
  AND3x1_ASAP7_75t_R   g73(.A(new_n51_), .B(new_n42_), .C(p2), .Y(new_n107_));
  AND3x1_ASAP7_75t_R   g74(.A(new_n59_), .B(new_n62_), .C(p2), .Y(new_n108_));
  OA21x2_ASAP7_75t_R   g75(.A1(new_n107_), .A2(new_n108_), .B(new_n103_), .Y(o21));
  AOI211x1_ASAP7_75t_R g76(.A1(p3), .A2(new_n62_), .B(new_n40_), .C(new_n66_), .Y(new_n110_));
  AO31x2_ASAP7_75t_R   g77(.A1(new_n44_), .A2(new_n65_), .A3(new_n110_), .B(new_n105_), .Y(o22));
  assign               o23 = 1'b1;
  OA211x2_ASAP7_75t_R  g78(.A1(new_n96_), .A2(new_n67_), .B(new_n72_), .C(new_n44_), .Y(o24));
  AND3x1_ASAP7_75t_R   g79(.A(new_n72_), .B(p6), .C(new_n37_), .Y(o25));
endmodule


