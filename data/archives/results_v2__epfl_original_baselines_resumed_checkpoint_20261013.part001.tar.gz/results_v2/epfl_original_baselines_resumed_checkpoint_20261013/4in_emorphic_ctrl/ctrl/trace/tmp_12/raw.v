// Benchmark "/tmp/" written by ABC on Tue Oct 13 18:51:58 2026

module \/tmp/  ( 
    p0, p2, p3, p4, p1, p6, p5,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25  );
  input  p0, p2, p3, p4, p1, p6, p5;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25;
  wire new_n34_, new_n35_, new_n36_, new_n37_, new_n38_, new_n41_, new_n42_,
    new_n43_, new_n44_, new_n45_, new_n46_, new_n47_, new_n49_, new_n50_,
    new_n51_, new_n52_, new_n53_, new_n55_, new_n56_, new_n58_, new_n59_,
    new_n60_, new_n61_, new_n62_, new_n63_, new_n64_, new_n65_, new_n66_,
    new_n67_, new_n69_, new_n71_, new_n72_, new_n74_, new_n75_, new_n77_,
    new_n80_, new_n81_, new_n82_, new_n83_, new_n85_, new_n87_, new_n88_,
    new_n92_, new_n94_, new_n98_, new_n99_, new_n101_;
  NAND2x1_ASAP7_75t_R  g00(.A(p2), .B(p3), .Y(new_n34_));
  INVx1_ASAP7_75t_R    g01(.A(new_n34_), .Y(new_n35_));
  OR3x1_ASAP7_75t_R    g02(.A(p0), .B(p1), .C(p6), .Y(new_n36_));
  INVx1_ASAP7_75t_R    g03(.A(p2), .Y(new_n37_));
  INVx1_ASAP7_75t_R    g04(.A(p3), .Y(new_n38_));
  AND3x1_ASAP7_75t_R   g05(.A(new_n37_), .B(new_n38_), .C(p1), .Y(o19));
  AO22x1_ASAP7_75t_R   g06(.A1(new_n35_), .A2(new_n36_), .B1(p0), .B2(o19), .Y(o0));
  NAND2x1_ASAP7_75t_R  g07(.A(p3), .B(new_n37_), .Y(new_n41_));
  INVx1_ASAP7_75t_R    g08(.A(p0), .Y(new_n42_));
  NOR2x1_ASAP7_75t_R   g09(.A(p1), .B(new_n42_), .Y(new_n43_));
  INVx1_ASAP7_75t_R    g10(.A(p1), .Y(new_n44_));
  AND3x1_ASAP7_75t_R   g11(.A(new_n42_), .B(new_n44_), .C(p6), .Y(new_n45_));
  OAI21x1_ASAP7_75t_R  g12(.A1(p2), .A2(p3), .B(p1), .Y(new_n46_));
  OAI21x1_ASAP7_75t_R  g13(.A1(p0), .A2(new_n35_), .B(new_n46_), .Y(new_n47_));
  AOI211x1_ASAP7_75t_R g14(.A1(new_n41_), .A2(new_n43_), .B(new_n45_), .C(new_n47_), .Y(o1));
  NOR2x1_ASAP7_75t_R   g15(.A(p3), .B(new_n37_), .Y(new_n49_));
  NOR2x1_ASAP7_75t_R   g16(.A(new_n42_), .B(new_n49_), .Y(new_n50_));
  OR3x1_ASAP7_75t_R    g17(.A(new_n38_), .B(p2), .C(p6), .Y(new_n51_));
  INVx1_ASAP7_75t_R    g18(.A(new_n43_), .Y(new_n52_));
  OR3x1_ASAP7_75t_R    g19(.A(new_n34_), .B(p1), .C(p6), .Y(new_n53_));
  AOI22x1_ASAP7_75t_R  g20(.A1(new_n50_), .A2(new_n51_), .B1(new_n52_), .B2(new_n53_), .Y(o2));
  NOR2x1_ASAP7_75t_R   g21(.A(p0), .B(p1), .Y(new_n55_));
  NAND2x1_ASAP7_75t_R  g22(.A(p2), .B(new_n55_), .Y(new_n56_));
  AOI22x1_ASAP7_75t_R  g23(.A1(new_n56_), .A2(new_n41_), .B1(p6), .B2(new_n35_), .Y(o3));
  NAND2x1_ASAP7_75t_R  g24(.A(p0), .B(p4), .Y(new_n58_));
  OA31x2_ASAP7_75t_R   g25(.A1(p6), .A2(new_n34_), .A3(new_n58_), .B1(new_n44_), .Y(new_n59_));
  INVx1_ASAP7_75t_R    g26(.A(p5), .Y(new_n60_));
  AOI21x1_ASAP7_75t_R  g27(.A1(p3), .A2(new_n60_), .B(new_n37_), .Y(new_n61_));
  INVx1_ASAP7_75t_R    g28(.A(p4), .Y(new_n62_));
  NAND3x1_ASAP7_75t_R  g29(.A(new_n62_), .B(p3), .C(p5), .Y(new_n63_));
  AND2x2_ASAP7_75t_R   g30(.A(p0), .B(p6), .Y(new_n64_));
  NAND3x1_ASAP7_75t_R  g31(.A(new_n61_), .B(new_n63_), .C(new_n64_), .Y(new_n65_));
  INVx1_ASAP7_75t_R    g32(.A(p6), .Y(new_n66_));
  OA21x2_ASAP7_75t_R   g33(.A1(new_n66_), .A2(new_n41_), .B(p1), .Y(new_n67_));
  AOI21x1_ASAP7_75t_R  g34(.A1(new_n59_), .A2(new_n65_), .B(new_n67_), .Y(o4));
  AO21x1_ASAP7_75t_R   g35(.A1(p3), .A2(new_n37_), .B(new_n44_), .Y(new_n69_));
  OA211x2_ASAP7_75t_R  g36(.A1(p1), .A2(new_n61_), .B(new_n69_), .C(p0), .Y(o5));
  NOR2x1_ASAP7_75t_R   g37(.A(new_n34_), .B(new_n64_), .Y(new_n71_));
  AO21x1_ASAP7_75t_R   g38(.A1(new_n37_), .A2(new_n38_), .B(p1), .Y(new_n72_));
  AOI22x1_ASAP7_75t_R  g39(.A1(new_n71_), .A2(new_n44_), .B1(new_n34_), .B2(new_n72_), .Y(o6));
  NAND2x1_ASAP7_75t_R  g40(.A(p1), .B(p6), .Y(new_n74_));
  AOI21x1_ASAP7_75t_R  g41(.A1(new_n74_), .A2(new_n36_), .B(new_n34_), .Y(new_n75_));
  AO21x1_ASAP7_75t_R   g42(.A1(p0), .A2(o19), .B(new_n75_), .Y(o7));
  OAI21x1_ASAP7_75t_R  g43(.A1(new_n46_), .A2(new_n35_), .B(p0), .Y(new_n77_));
  AOI21x1_ASAP7_75t_R  g44(.A1(new_n43_), .A2(new_n51_), .B(new_n77_), .Y(o8));
  AOI21x1_ASAP7_75t_R  g45(.A1(new_n43_), .A2(new_n51_), .B(new_n47_), .Y(o9));
  INVx1_ASAP7_75t_R    g46(.A(new_n69_), .Y(new_n80_));
  NOR2x1_ASAP7_75t_R   g47(.A(p2), .B(p1), .Y(new_n81_));
  AO21x1_ASAP7_75t_R   g48(.A1(p3), .A2(new_n55_), .B(new_n81_), .Y(new_n82_));
  NOR2x1_ASAP7_75t_R   g49(.A(p6), .B(new_n42_), .Y(new_n83_));
  OAI22x1_ASAP7_75t_R  g50(.A1(new_n80_), .A2(new_n82_), .B1(new_n41_), .B2(new_n83_), .Y(o10));
  NOR2x1_ASAP7_75t_R   g51(.A(p2), .B(p3), .Y(new_n85_));
  AND3x1_ASAP7_75t_R   g52(.A(new_n85_), .B(new_n55_), .C(new_n66_), .Y(o11));
  OA21x2_ASAP7_75t_R   g53(.A1(p2), .A2(new_n42_), .B(new_n38_), .Y(new_n87_));
  AND3x1_ASAP7_75t_R   g54(.A(new_n42_), .B(new_n37_), .C(new_n66_), .Y(new_n88_));
  OAI22x1_ASAP7_75t_R  g55(.A1(new_n87_), .A2(new_n44_), .B1(new_n88_), .B2(new_n72_), .Y(o12));
  AND3x1_ASAP7_75t_R   g56(.A(new_n85_), .B(p1), .C(p6), .Y(o13));
  AND3x1_ASAP7_75t_R   g57(.A(new_n85_), .B(p1), .C(new_n66_), .Y(o14));
  NOR2x1_ASAP7_75t_R   g58(.A(p0), .B(p6), .Y(new_n92_));
  AND3x1_ASAP7_75t_R   g59(.A(new_n49_), .B(p1), .C(new_n92_), .Y(o15));
  OR3x1_ASAP7_75t_R    g60(.A(new_n37_), .B(p0), .C(p3), .Y(new_n94_));
  NOR2x1_ASAP7_75t_R   g61(.A(new_n74_), .B(new_n94_), .Y(o16));
  AND3x1_ASAP7_75t_R   g62(.A(new_n49_), .B(p1), .C(new_n64_), .Y(o17));
  AND3x1_ASAP7_75t_R   g63(.A(new_n49_), .B(new_n83_), .C(p1), .Y(o18));
  AO21x1_ASAP7_75t_R   g64(.A1(p3), .A2(new_n58_), .B(new_n66_), .Y(new_n98_));
  OA21x2_ASAP7_75t_R   g65(.A1(new_n34_), .A2(new_n64_), .B(p1), .Y(new_n99_));
  AOI211x1_ASAP7_75t_R g66(.A1(new_n44_), .A2(new_n98_), .B(new_n81_), .C(new_n99_), .Y(o20));
  OR3x1_ASAP7_75t_R    g67(.A(new_n34_), .B(new_n58_), .C(p5), .Y(new_n101_));
  AOI211x1_ASAP7_75t_R g68(.A1(new_n94_), .A2(new_n101_), .B(p1), .C(new_n66_), .Y(o21));
  AOI21x1_ASAP7_75t_R  g69(.A1(new_n44_), .A2(new_n65_), .B(new_n99_), .Y(o22));
  assign               o23 = 1'b1;
  OA211x2_ASAP7_75t_R  g70(.A1(new_n92_), .A2(new_n64_), .B(p3), .C(new_n81_), .Y(o24));
  AND3x1_ASAP7_75t_R   g71(.A(new_n45_), .B(new_n37_), .C(p3), .Y(o25));
endmodule


