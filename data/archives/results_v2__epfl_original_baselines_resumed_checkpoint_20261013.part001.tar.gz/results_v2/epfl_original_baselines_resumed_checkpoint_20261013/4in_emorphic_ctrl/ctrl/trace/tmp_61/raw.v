// Benchmark "/tmp/" written by ABC on Tue Oct 13 18:52:02 2026

module \/tmp/  ( 
    p0, p4, p5, p1, p3, p2, p6,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25  );
  input  p0, p4, p5, p1, p3, p2, p6;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25;
  wire new_n34_, new_n35_, new_n36_, new_n37_, new_n39_, new_n40_, new_n41_,
    new_n42_, new_n43_, new_n44_, new_n45_, new_n46_, new_n47_, new_n49_,
    new_n50_, new_n51_, new_n52_, new_n53_, new_n54_, new_n56_, new_n57_,
    new_n59_, new_n60_, new_n61_, new_n62_, new_n63_, new_n64_, new_n65_,
    new_n66_, new_n67_, new_n68_, new_n69_, new_n71_, new_n72_, new_n74_,
    new_n75_, new_n77_, new_n78_, new_n80_, new_n81_, new_n82_, new_n84_,
    new_n86_, new_n87_, new_n88_, new_n90_, new_n92_, new_n93_, new_n94_,
    new_n99_, new_n104_, new_n105_, new_n106_, new_n108_, new_n110_;
  AND2x2_ASAP7_75t_R   g00(.A(p3), .B(p2), .Y(new_n34_));
  OR3x1_ASAP7_75t_R    g01(.A(p0), .B(p1), .C(p6), .Y(new_n35_));
  NOR2x1_ASAP7_75t_R   g02(.A(p3), .B(p2), .Y(new_n36_));
  AND3x1_ASAP7_75t_R   g03(.A(new_n36_), .B(p0), .C(p1), .Y(new_n37_));
  AO21x1_ASAP7_75t_R   g04(.A1(new_n34_), .A2(new_n35_), .B(new_n37_), .Y(o0));
  INVx1_ASAP7_75t_R    g05(.A(p3), .Y(new_n39_));
  INVx1_ASAP7_75t_R    g06(.A(p2), .Y(new_n40_));
  OR3x1_ASAP7_75t_R    g07(.A(new_n39_), .B(new_n40_), .C(p6), .Y(new_n41_));
  NOR2x1_ASAP7_75t_R   g08(.A(p0), .B(p1), .Y(new_n42_));
  INVx1_ASAP7_75t_R    g09(.A(p1), .Y(new_n43_));
  AOI21x1_ASAP7_75t_R  g10(.A1(p0), .A2(new_n36_), .B(new_n43_), .Y(new_n44_));
  NAND2x1_ASAP7_75t_R  g11(.A(p0), .B(new_n43_), .Y(new_n45_));
  NOR2x1_ASAP7_75t_R   g12(.A(p2), .B(new_n39_), .Y(new_n46_));
  NOR2x1_ASAP7_75t_R   g13(.A(new_n45_), .B(new_n46_), .Y(new_n47_));
  AOI211x1_ASAP7_75t_R g14(.A1(new_n41_), .A2(new_n42_), .B(new_n44_), .C(new_n47_), .Y(o1));
  INVx1_ASAP7_75t_R    g15(.A(p0), .Y(new_n49_));
  NOR2x1_ASAP7_75t_R   g16(.A(p3), .B(new_n40_), .Y(new_n50_));
  NOR2x1_ASAP7_75t_R   g17(.A(new_n49_), .B(new_n50_), .Y(new_n51_));
  OR3x1_ASAP7_75t_R    g18(.A(new_n39_), .B(p2), .C(p6), .Y(new_n52_));
  NAND2x1_ASAP7_75t_R  g19(.A(p3), .B(p2), .Y(new_n53_));
  OR3x1_ASAP7_75t_R    g20(.A(new_n53_), .B(p1), .C(p6), .Y(new_n54_));
  AOI22x1_ASAP7_75t_R  g21(.A1(new_n51_), .A2(new_n52_), .B1(new_n45_), .B2(new_n54_), .Y(o2));
  NAND2x1_ASAP7_75t_R  g22(.A(p2), .B(new_n42_), .Y(new_n56_));
  NAND2x1_ASAP7_75t_R  g23(.A(p3), .B(new_n40_), .Y(new_n57_));
  AOI22x1_ASAP7_75t_R  g24(.A1(new_n56_), .A2(new_n57_), .B1(p6), .B2(new_n34_), .Y(o3));
  NAND2x1_ASAP7_75t_R  g25(.A(p0), .B(p4), .Y(new_n59_));
  OA31x2_ASAP7_75t_R   g26(.A1(p6), .A2(new_n53_), .A3(new_n59_), .B1(new_n43_), .Y(new_n60_));
  INVx1_ASAP7_75t_R    g27(.A(p5), .Y(new_n61_));
  AOI21x1_ASAP7_75t_R  g28(.A1(p3), .A2(new_n61_), .B(new_n40_), .Y(new_n62_));
  INVx1_ASAP7_75t_R    g29(.A(p4), .Y(new_n63_));
  NAND3x1_ASAP7_75t_R  g30(.A(new_n63_), .B(p5), .C(p3), .Y(new_n64_));
  NAND2x1_ASAP7_75t_R  g31(.A(p0), .B(p6), .Y(new_n65_));
  INVx1_ASAP7_75t_R    g32(.A(new_n65_), .Y(new_n66_));
  NAND3x1_ASAP7_75t_R  g33(.A(new_n62_), .B(new_n64_), .C(new_n66_), .Y(new_n67_));
  INVx1_ASAP7_75t_R    g34(.A(p6), .Y(new_n68_));
  OA21x2_ASAP7_75t_R   g35(.A1(new_n68_), .A2(new_n57_), .B(p1), .Y(new_n69_));
  AOI21x1_ASAP7_75t_R  g36(.A1(new_n60_), .A2(new_n67_), .B(new_n69_), .Y(o4));
  NOR2x1_ASAP7_75t_R   g37(.A(new_n43_), .B(new_n46_), .Y(new_n71_));
  OAI21x1_ASAP7_75t_R  g38(.A1(p1), .A2(new_n62_), .B(p0), .Y(new_n72_));
  NOR2x1_ASAP7_75t_R   g39(.A(new_n71_), .B(new_n72_), .Y(o5));
  AO21x1_ASAP7_75t_R   g40(.A1(new_n39_), .A2(new_n40_), .B(p1), .Y(new_n74_));
  AO21x1_ASAP7_75t_R   g41(.A1(new_n43_), .A2(new_n65_), .B(new_n53_), .Y(new_n75_));
  OAI21x1_ASAP7_75t_R  g42(.A1(new_n34_), .A2(new_n74_), .B(new_n75_), .Y(o6));
  AND3x1_ASAP7_75t_R   g43(.A(new_n34_), .B(new_n68_), .C(new_n42_), .Y(new_n77_));
  AND3x1_ASAP7_75t_R   g44(.A(new_n34_), .B(p1), .C(p6), .Y(new_n78_));
  OR3x1_ASAP7_75t_R    g45(.A(new_n77_), .B(new_n78_), .C(new_n37_), .Y(o7));
  INVx1_ASAP7_75t_R    g46(.A(new_n45_), .Y(new_n80_));
  AO21x1_ASAP7_75t_R   g47(.A1(p1), .A2(new_n53_), .B(new_n49_), .Y(new_n81_));
  NAND2x1_ASAP7_75t_R  g48(.A(p0), .B(new_n36_), .Y(new_n82_));
  AOI22x1_ASAP7_75t_R  g49(.A1(new_n80_), .A2(new_n52_), .B1(new_n81_), .B2(new_n82_), .Y(o8));
  AND2x2_ASAP7_75t_R   g50(.A(new_n49_), .B(new_n53_), .Y(new_n84_));
  AOI211x1_ASAP7_75t_R g51(.A1(new_n52_), .A2(new_n80_), .B(new_n44_), .C(new_n84_), .Y(o9));
  NOR2x1_ASAP7_75t_R   g52(.A(p1), .B(p2), .Y(new_n86_));
  AO21x1_ASAP7_75t_R   g53(.A1(p3), .A2(new_n42_), .B(new_n86_), .Y(new_n87_));
  OAI21x1_ASAP7_75t_R  g54(.A1(new_n49_), .A2(p6), .B(new_n46_), .Y(new_n88_));
  AOI21x1_ASAP7_75t_R  g55(.A1(new_n87_), .A2(new_n88_), .B(new_n71_), .Y(o10));
  NOR2x1_ASAP7_75t_R   g56(.A(p0), .B(p6), .Y(new_n90_));
  AND3x1_ASAP7_75t_R   g57(.A(new_n36_), .B(new_n90_), .C(new_n43_), .Y(o11));
  AND3x1_ASAP7_75t_R   g58(.A(new_n49_), .B(new_n40_), .C(new_n68_), .Y(new_n92_));
  NOR2x1_ASAP7_75t_R   g59(.A(p0), .B(p3), .Y(new_n93_));
  OR3x1_ASAP7_75t_R    g60(.A(new_n50_), .B(new_n43_), .C(new_n93_), .Y(new_n94_));
  OAI21x1_ASAP7_75t_R  g61(.A1(new_n74_), .A2(new_n92_), .B(new_n94_), .Y(o12));
  AND3x1_ASAP7_75t_R   g62(.A(new_n36_), .B(p1), .C(p6), .Y(o13));
  AND3x1_ASAP7_75t_R   g63(.A(new_n36_), .B(p1), .C(new_n68_), .Y(o14));
  AND3x1_ASAP7_75t_R   g64(.A(new_n50_), .B(p1), .C(new_n90_), .Y(o15));
  AND3x1_ASAP7_75t_R   g65(.A(new_n39_), .B(p1), .C(p2), .Y(new_n99_));
  AND3x1_ASAP7_75t_R   g66(.A(new_n99_), .B(new_n49_), .C(p6), .Y(o16));
  AND3x1_ASAP7_75t_R   g67(.A(new_n66_), .B(new_n50_), .C(p1), .Y(o17));
  AND3x1_ASAP7_75t_R   g68(.A(new_n99_), .B(p0), .C(new_n68_), .Y(o18));
  AND3x1_ASAP7_75t_R   g69(.A(new_n39_), .B(new_n40_), .C(p1), .Y(o19));
  NAND2x1_ASAP7_75t_R  g70(.A(p3), .B(new_n59_), .Y(new_n104_));
  AND3x1_ASAP7_75t_R   g71(.A(new_n43_), .B(p2), .C(p6), .Y(new_n105_));
  AND3x1_ASAP7_75t_R   g72(.A(new_n34_), .B(p1), .C(new_n65_), .Y(new_n106_));
  AO21x1_ASAP7_75t_R   g73(.A1(new_n104_), .A2(new_n105_), .B(new_n106_), .Y(o20));
  AO21x1_ASAP7_75t_R   g74(.A1(new_n61_), .A2(p3), .B(new_n93_), .Y(new_n108_));
  AND3x1_ASAP7_75t_R   g75(.A(new_n108_), .B(new_n104_), .C(new_n105_), .Y(o21));
  AOI211x1_ASAP7_75t_R g76(.A1(p3), .A2(new_n61_), .B(new_n40_), .C(new_n65_), .Y(new_n110_));
  AO31x2_ASAP7_75t_R   g77(.A1(new_n43_), .A2(new_n64_), .A3(new_n110_), .B(new_n106_), .Y(o22));
  assign               o23 = 1'b1;
  OA211x2_ASAP7_75t_R  g78(.A1(new_n90_), .A2(new_n66_), .B(p3), .C(new_n86_), .Y(o24));
  AND3x1_ASAP7_75t_R   g79(.A(new_n46_), .B(p6), .C(new_n42_), .Y(o25));
endmodule


