// Benchmark "/tmp/" written by ABC on Tue Oct 13 18:51:57 2026

module \/tmp/  ( 
    p2, p1, p4, p6, p5, p0, p3,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25  );
  input  p2, p1, p4, p6, p5, p0, p3;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25;
  wire new_n34_, new_n35_, new_n36_, new_n37_, new_n38_, new_n39_, new_n41_,
    new_n42_, new_n43_, new_n44_, new_n45_, new_n46_, new_n47_, new_n48_,
    new_n49_, new_n51_, new_n52_, new_n53_, new_n54_, new_n55_, new_n56_,
    new_n58_, new_n60_, new_n61_, new_n62_, new_n63_, new_n64_, new_n65_,
    new_n66_, new_n67_, new_n68_, new_n69_, new_n71_, new_n72_, new_n74_,
    new_n75_, new_n76_, new_n78_, new_n79_, new_n81_, new_n82_, new_n85_,
    new_n86_, new_n89_, new_n90_, new_n91_, new_n92_, new_n96_, new_n98_,
    new_n103_, new_n104_, new_n105_, new_n107_, new_n108_, new_n109_,
    new_n113_;
  NOR2x1_ASAP7_75t_R   g00(.A(p2), .B(p3), .Y(new_n34_));
  AND2x2_ASAP7_75t_R   g01(.A(p1), .B(p0), .Y(new_n35_));
  NAND2x1_ASAP7_75t_R  g02(.A(new_n34_), .B(new_n35_), .Y(new_n36_));
  NAND2x1_ASAP7_75t_R  g03(.A(p2), .B(p3), .Y(new_n37_));
  INVx1_ASAP7_75t_R    g04(.A(p6), .Y(new_n38_));
  NOR2x1_ASAP7_75t_R   g05(.A(p1), .B(p0), .Y(new_n39_));
  AOI22x1_ASAP7_75t_R  g06(.A1(new_n36_), .A2(new_n37_), .B1(new_n38_), .B2(new_n39_), .Y(o0));
  INVx1_ASAP7_75t_R    g07(.A(p0), .Y(new_n41_));
  NOR2x1_ASAP7_75t_R   g08(.A(p1), .B(new_n41_), .Y(new_n42_));
  INVx1_ASAP7_75t_R    g09(.A(p3), .Y(new_n43_));
  NOR2x1_ASAP7_75t_R   g10(.A(p2), .B(new_n43_), .Y(new_n44_));
  INVx1_ASAP7_75t_R    g11(.A(new_n44_), .Y(new_n45_));
  AND2x2_ASAP7_75t_R   g12(.A(p2), .B(p3), .Y(new_n46_));
  INVx1_ASAP7_75t_R    g13(.A(p1), .Y(new_n47_));
  OAI22x1_ASAP7_75t_R  g14(.A1(new_n46_), .A2(p0), .B1(new_n47_), .B2(new_n34_), .Y(new_n48_));
  AND3x1_ASAP7_75t_R   g15(.A(new_n47_), .B(new_n41_), .C(p6), .Y(new_n49_));
  AOI211x1_ASAP7_75t_R g16(.A1(new_n42_), .A2(new_n45_), .B(new_n48_), .C(new_n49_), .Y(o1));
  INVx1_ASAP7_75t_R    g17(.A(p2), .Y(new_n51_));
  NOR2x1_ASAP7_75t_R   g18(.A(p3), .B(new_n51_), .Y(new_n52_));
  NOR2x1_ASAP7_75t_R   g19(.A(new_n41_), .B(new_n52_), .Y(new_n53_));
  OR3x1_ASAP7_75t_R    g20(.A(new_n43_), .B(p2), .C(p6), .Y(new_n54_));
  INVx1_ASAP7_75t_R    g21(.A(new_n42_), .Y(new_n55_));
  OR3x1_ASAP7_75t_R    g22(.A(new_n37_), .B(p1), .C(p6), .Y(new_n56_));
  AOI22x1_ASAP7_75t_R  g23(.A1(new_n53_), .A2(new_n54_), .B1(new_n55_), .B2(new_n56_), .Y(o2));
  NOR2x1_ASAP7_75t_R   g24(.A(new_n51_), .B(new_n39_), .Y(new_n58_));
  AOI211x1_ASAP7_75t_R g25(.A1(p6), .A2(new_n46_), .B(new_n34_), .C(new_n58_), .Y(o3));
  AND3x1_ASAP7_75t_R   g26(.A(p2), .B(p4), .C(p3), .Y(new_n60_));
  NOR2x1_ASAP7_75t_R   g27(.A(p6), .B(new_n41_), .Y(new_n61_));
  AOI21x1_ASAP7_75t_R  g28(.A1(new_n60_), .A2(new_n61_), .B(p1), .Y(new_n62_));
  INVx1_ASAP7_75t_R    g29(.A(p5), .Y(new_n63_));
  NAND2x1_ASAP7_75t_R  g30(.A(p3), .B(new_n63_), .Y(new_n64_));
  INVx1_ASAP7_75t_R    g31(.A(p4), .Y(new_n65_));
  NAND2x1_ASAP7_75t_R  g32(.A(p3), .B(new_n65_), .Y(new_n66_));
  AND3x1_ASAP7_75t_R   g33(.A(p2), .B(p6), .C(p0), .Y(new_n67_));
  NAND3x1_ASAP7_75t_R  g34(.A(new_n64_), .B(new_n66_), .C(new_n67_), .Y(new_n68_));
  AOI21x1_ASAP7_75t_R  g35(.A1(p6), .A2(new_n44_), .B(new_n47_), .Y(new_n69_));
  AOI21x1_ASAP7_75t_R  g36(.A1(new_n62_), .A2(new_n68_), .B(new_n69_), .Y(o4));
  AO21x1_ASAP7_75t_R   g37(.A1(p3), .A2(new_n63_), .B(new_n51_), .Y(new_n71_));
  NOR2x1_ASAP7_75t_R   g38(.A(new_n47_), .B(new_n44_), .Y(new_n72_));
  AOI211x1_ASAP7_75t_R g39(.A1(new_n47_), .A2(new_n71_), .B(new_n41_), .C(new_n72_), .Y(o5));
  AND2x2_ASAP7_75t_R   g40(.A(p6), .B(p0), .Y(new_n74_));
  NOR2x1_ASAP7_75t_R   g41(.A(p1), .B(new_n74_), .Y(new_n75_));
  OR3x1_ASAP7_75t_R    g42(.A(new_n46_), .B(p1), .C(new_n34_), .Y(new_n76_));
  OAI21x1_ASAP7_75t_R  g43(.A1(new_n37_), .A2(new_n75_), .B(new_n76_), .Y(o6));
  XOR2x2_ASAP7_75t_R   g44(.A(p1), .B(p6), .Y(new_n78_));
  AO21x1_ASAP7_75t_R   g45(.A1(new_n47_), .A2(p0), .B(new_n37_), .Y(new_n79_));
  OAI21x1_ASAP7_75t_R  g46(.A1(new_n78_), .A2(new_n79_), .B(new_n36_), .Y(o7));
  AO21x1_ASAP7_75t_R   g47(.A1(p1), .A2(new_n37_), .B(new_n41_), .Y(new_n81_));
  NAND2x1_ASAP7_75t_R  g48(.A(p0), .B(new_n34_), .Y(new_n82_));
  AOI22x1_ASAP7_75t_R  g49(.A1(new_n81_), .A2(new_n82_), .B1(new_n42_), .B2(new_n54_), .Y(o8));
  AOI21x1_ASAP7_75t_R  g50(.A1(new_n42_), .A2(new_n54_), .B(new_n48_), .Y(o9));
  NOR2x1_ASAP7_75t_R   g51(.A(p2), .B(p1), .Y(new_n85_));
  AO21x1_ASAP7_75t_R   g52(.A1(p3), .A2(new_n39_), .B(new_n85_), .Y(new_n86_));
  OAI22x1_ASAP7_75t_R  g53(.A1(new_n72_), .A2(new_n86_), .B1(new_n45_), .B2(new_n61_), .Y(o10));
  AND3x1_ASAP7_75t_R   g54(.A(new_n39_), .B(new_n34_), .C(new_n38_), .Y(o11));
  AND3x1_ASAP7_75t_R   g55(.A(new_n51_), .B(new_n38_), .C(new_n41_), .Y(new_n89_));
  AO21x1_ASAP7_75t_R   g56(.A1(new_n51_), .A2(new_n43_), .B(p1), .Y(new_n90_));
  AO21x1_ASAP7_75t_R   g57(.A1(p2), .A2(new_n43_), .B(new_n47_), .Y(new_n91_));
  NOR2x1_ASAP7_75t_R   g58(.A(p0), .B(p3), .Y(new_n92_));
  OAI22x1_ASAP7_75t_R  g59(.A1(new_n89_), .A2(new_n90_), .B1(new_n91_), .B2(new_n92_), .Y(o12));
  AND3x1_ASAP7_75t_R   g60(.A(new_n34_), .B(p1), .C(p6), .Y(o13));
  AND3x1_ASAP7_75t_R   g61(.A(new_n34_), .B(p1), .C(new_n38_), .Y(o14));
  AND3x1_ASAP7_75t_R   g62(.A(new_n41_), .B(new_n43_), .C(p2), .Y(new_n96_));
  AND3x1_ASAP7_75t_R   g63(.A(new_n96_), .B(p1), .C(new_n38_), .Y(o15));
  AND2x2_ASAP7_75t_R   g64(.A(p2), .B(p6), .Y(new_n98_));
  AND3x1_ASAP7_75t_R   g65(.A(new_n98_), .B(p1), .C(new_n92_), .Y(o16));
  AND3x1_ASAP7_75t_R   g66(.A(new_n52_), .B(p1), .C(new_n74_), .Y(o17));
  AND3x1_ASAP7_75t_R   g67(.A(new_n52_), .B(new_n38_), .C(new_n35_), .Y(o18));
  AND3x1_ASAP7_75t_R   g68(.A(new_n51_), .B(new_n43_), .C(p1), .Y(o19));
  NAND2x1_ASAP7_75t_R  g69(.A(new_n67_), .B(new_n66_), .Y(new_n103_));
  AOI21x1_ASAP7_75t_R  g70(.A1(new_n92_), .A2(new_n98_), .B(p1), .Y(new_n104_));
  OA21x2_ASAP7_75t_R   g71(.A1(new_n37_), .A2(new_n74_), .B(p1), .Y(new_n105_));
  AOI21x1_ASAP7_75t_R  g72(.A1(new_n103_), .A2(new_n104_), .B(new_n105_), .Y(o20));
  OR4x2_ASAP7_75t_R    g73(.A(new_n37_), .B(new_n65_), .C(p5), .D(new_n41_), .Y(new_n107_));
  INVx1_ASAP7_75t_R    g74(.A(new_n96_), .Y(new_n108_));
  NAND2x1_ASAP7_75t_R  g75(.A(p6), .B(new_n47_), .Y(new_n109_));
  AOI21x1_ASAP7_75t_R  g76(.A1(new_n107_), .A2(new_n108_), .B(new_n109_), .Y(o21));
  AOI21x1_ASAP7_75t_R  g77(.A1(new_n47_), .A2(new_n68_), .B(new_n105_), .Y(o22));
  assign               o23 = 1'b1;
  NOR2x1_ASAP7_75t_R   g78(.A(p6), .B(p0), .Y(new_n113_));
  OA211x2_ASAP7_75t_R  g79(.A1(new_n113_), .A2(new_n74_), .B(p3), .C(new_n85_), .Y(o24));
  AND3x1_ASAP7_75t_R   g80(.A(new_n44_), .B(p6), .C(new_n39_), .Y(o25));
endmodule


