// Benchmark "/tmp/" written by ABC on Tue Oct 13 18:52:00 2026

module \/tmp/  ( 
    p0, p2, p4, p3, p5, p6, p1,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25  );
  input  p0, p2, p4, p3, p5, p6, p1;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25;
  wire new_n34_, new_n35_, new_n36_, new_n37_, new_n39_, new_n40_, new_n41_,
    new_n42_, new_n43_, new_n44_, new_n45_, new_n46_, new_n47_, new_n49_,
    new_n50_, new_n51_, new_n52_, new_n53_, new_n54_, new_n56_, new_n58_,
    new_n59_, new_n60_, new_n61_, new_n62_, new_n63_, new_n64_, new_n65_,
    new_n66_, new_n67_, new_n68_, new_n70_, new_n71_, new_n73_, new_n74_,
    new_n76_, new_n77_, new_n79_, new_n81_, new_n82_, new_n84_, new_n85_,
    new_n86_, new_n89_, new_n90_, new_n94_, new_n96_, new_n101_, new_n102_,
    new_n103_, new_n105_, new_n106_, new_n108_;
  AND2x2_ASAP7_75t_R   g00(.A(p2), .B(p3), .Y(new_n34_));
  NOR2x1_ASAP7_75t_R   g01(.A(p2), .B(p3), .Y(new_n35_));
  AND3x1_ASAP7_75t_R   g02(.A(new_n35_), .B(p0), .C(p1), .Y(new_n36_));
  OR3x1_ASAP7_75t_R    g03(.A(p0), .B(p6), .C(p1), .Y(new_n37_));
  OA21x2_ASAP7_75t_R   g04(.A1(new_n34_), .A2(new_n36_), .B(new_n37_), .Y(o0));
  NOR2x1_ASAP7_75t_R   g05(.A(p0), .B(p1), .Y(new_n39_));
  INVx1_ASAP7_75t_R    g06(.A(p2), .Y(new_n40_));
  INVx1_ASAP7_75t_R    g07(.A(p3), .Y(new_n41_));
  OR3x1_ASAP7_75t_R    g08(.A(new_n40_), .B(new_n41_), .C(p6), .Y(new_n42_));
  INVx1_ASAP7_75t_R    g09(.A(p1), .Y(new_n43_));
  AOI21x1_ASAP7_75t_R  g10(.A1(p0), .A2(new_n35_), .B(new_n43_), .Y(new_n44_));
  NAND2x1_ASAP7_75t_R  g11(.A(p0), .B(new_n43_), .Y(new_n45_));
  NOR2x1_ASAP7_75t_R   g12(.A(p2), .B(new_n41_), .Y(new_n46_));
  NOR2x1_ASAP7_75t_R   g13(.A(new_n45_), .B(new_n46_), .Y(new_n47_));
  AOI211x1_ASAP7_75t_R g14(.A1(new_n39_), .A2(new_n42_), .B(new_n44_), .C(new_n47_), .Y(o1));
  INVx1_ASAP7_75t_R    g15(.A(p0), .Y(new_n49_));
  NOR2x1_ASAP7_75t_R   g16(.A(p3), .B(new_n40_), .Y(new_n50_));
  NOR2x1_ASAP7_75t_R   g17(.A(new_n49_), .B(new_n50_), .Y(new_n51_));
  OR3x1_ASAP7_75t_R    g18(.A(new_n41_), .B(p2), .C(p6), .Y(new_n52_));
  NAND2x1_ASAP7_75t_R  g19(.A(p2), .B(p3), .Y(new_n53_));
  OR3x1_ASAP7_75t_R    g20(.A(new_n53_), .B(p6), .C(p1), .Y(new_n54_));
  AOI22x1_ASAP7_75t_R  g21(.A1(new_n51_), .A2(new_n52_), .B1(new_n45_), .B2(new_n54_), .Y(o2));
  AOI21x1_ASAP7_75t_R  g22(.A1(p6), .A2(new_n34_), .B(new_n35_), .Y(new_n56_));
  OA21x2_ASAP7_75t_R   g23(.A1(new_n40_), .A2(new_n39_), .B(new_n56_), .Y(o3));
  NAND2x1_ASAP7_75t_R  g24(.A(p0), .B(p4), .Y(new_n58_));
  OA31x2_ASAP7_75t_R   g25(.A1(p6), .A2(new_n53_), .A3(new_n58_), .B1(new_n43_), .Y(new_n59_));
  INVx1_ASAP7_75t_R    g26(.A(p5), .Y(new_n60_));
  AOI21x1_ASAP7_75t_R  g27(.A1(p3), .A2(new_n60_), .B(new_n40_), .Y(new_n61_));
  INVx1_ASAP7_75t_R    g28(.A(p4), .Y(new_n62_));
  NAND3x1_ASAP7_75t_R  g29(.A(new_n62_), .B(p3), .C(p5), .Y(new_n63_));
  AND2x2_ASAP7_75t_R   g30(.A(p0), .B(p6), .Y(new_n64_));
  NAND3x1_ASAP7_75t_R  g31(.A(new_n61_), .B(new_n63_), .C(new_n64_), .Y(new_n65_));
  NAND2x1_ASAP7_75t_R  g32(.A(p3), .B(new_n40_), .Y(new_n66_));
  NOR2x1_ASAP7_75t_R   g33(.A(p6), .B(new_n43_), .Y(new_n67_));
  AO21x1_ASAP7_75t_R   g34(.A1(p1), .A2(new_n66_), .B(new_n67_), .Y(new_n68_));
  AOI21x1_ASAP7_75t_R  g35(.A1(new_n59_), .A2(new_n65_), .B(new_n68_), .Y(o4));
  AO21x1_ASAP7_75t_R   g36(.A1(p2), .A2(p5), .B(p1), .Y(new_n70_));
  NOR2x1_ASAP7_75t_R   g37(.A(new_n70_), .B(new_n50_), .Y(new_n71_));
  AOI211x1_ASAP7_75t_R g38(.A1(p1), .A2(new_n66_), .B(new_n49_), .C(new_n71_), .Y(o5));
  NOR2x1_ASAP7_75t_R   g39(.A(p1), .B(new_n35_), .Y(new_n73_));
  OA21x2_ASAP7_75t_R   g40(.A1(p1), .A2(new_n64_), .B(new_n34_), .Y(new_n74_));
  AO21x1_ASAP7_75t_R   g41(.A1(new_n53_), .A2(new_n73_), .B(new_n74_), .Y(o6));
  AND3x1_ASAP7_75t_R   g42(.A(new_n34_), .B(p6), .C(p1), .Y(new_n76_));
  NOR2x1_ASAP7_75t_R   g43(.A(new_n53_), .B(new_n37_), .Y(new_n77_));
  OR3x1_ASAP7_75t_R    g44(.A(new_n76_), .B(new_n36_), .C(new_n77_), .Y(o7));
  NOR3x1_ASAP7_75t_R   g45(.A(new_n34_), .B(new_n43_), .C(new_n35_), .Y(new_n79_));
  AOI211x1_ASAP7_75t_R g46(.A1(new_n43_), .A2(new_n52_), .B(new_n49_), .C(new_n79_), .Y(o8));
  INVx1_ASAP7_75t_R    g47(.A(new_n45_), .Y(new_n81_));
  AND3x1_ASAP7_75t_R   g48(.A(new_n53_), .B(new_n49_), .C(new_n43_), .Y(new_n82_));
  AOI211x1_ASAP7_75t_R g49(.A1(new_n52_), .A2(new_n81_), .B(new_n44_), .C(new_n82_), .Y(o9));
  AO21x1_ASAP7_75t_R   g50(.A1(p3), .A2(new_n49_), .B(new_n40_), .Y(new_n84_));
  INVx1_ASAP7_75t_R    g51(.A(p6), .Y(new_n85_));
  AND3x1_ASAP7_75t_R   g52(.A(new_n85_), .B(new_n43_), .C(p0), .Y(new_n86_));
  OAI22x1_ASAP7_75t_R  g53(.A1(new_n84_), .A2(p1), .B1(new_n86_), .B2(new_n66_), .Y(o10));
  AND3x1_ASAP7_75t_R   g54(.A(new_n39_), .B(new_n35_), .C(new_n85_), .Y(o11));
  OR3x1_ASAP7_75t_R    g55(.A(p0), .B(p2), .C(p6), .Y(new_n89_));
  AO21x1_ASAP7_75t_R   g56(.A1(p0), .A2(new_n40_), .B(p3), .Y(new_n90_));
  AO22x1_ASAP7_75t_R   g57(.A1(new_n89_), .A2(new_n73_), .B1(p1), .B2(new_n90_), .Y(o12));
  AND3x1_ASAP7_75t_R   g58(.A(new_n35_), .B(p6), .C(p1), .Y(o13));
  AND3x1_ASAP7_75t_R   g59(.A(new_n35_), .B(new_n85_), .C(p1), .Y(o14));
  NOR2x1_ASAP7_75t_R   g60(.A(p0), .B(p6), .Y(new_n94_));
  AND3x1_ASAP7_75t_R   g61(.A(new_n50_), .B(p1), .C(new_n94_), .Y(o15));
  NOR2x1_ASAP7_75t_R   g62(.A(p0), .B(new_n85_), .Y(new_n96_));
  AND3x1_ASAP7_75t_R   g63(.A(new_n50_), .B(new_n96_), .C(p1), .Y(o16));
  AND3x1_ASAP7_75t_R   g64(.A(new_n50_), .B(p1), .C(new_n64_), .Y(o17));
  AND3x1_ASAP7_75t_R   g65(.A(new_n50_), .B(new_n67_), .C(p0), .Y(o18));
  AND3x1_ASAP7_75t_R   g66(.A(new_n40_), .B(new_n41_), .C(p1), .Y(o19));
  AND2x2_ASAP7_75t_R   g67(.A(p3), .B(new_n58_), .Y(new_n101_));
  OR3x1_ASAP7_75t_R    g68(.A(new_n40_), .B(new_n85_), .C(p1), .Y(new_n102_));
  OR3x1_ASAP7_75t_R    g69(.A(new_n64_), .B(new_n43_), .C(new_n53_), .Y(new_n103_));
  OAI21x1_ASAP7_75t_R  g70(.A1(new_n101_), .A2(new_n102_), .B(new_n103_), .Y(o20));
  NAND2x1_ASAP7_75t_R  g71(.A(p3), .B(new_n60_), .Y(new_n105_));
  NAND2x1_ASAP7_75t_R  g72(.A(new_n49_), .B(new_n41_), .Y(new_n106_));
  AOI211x1_ASAP7_75t_R g73(.A1(new_n105_), .A2(new_n106_), .B(new_n102_), .C(new_n101_), .Y(o21));
  NAND3x1_ASAP7_75t_R  g74(.A(new_n63_), .B(new_n43_), .C(new_n64_), .Y(new_n108_));
  AOI21x1_ASAP7_75t_R  g75(.A1(new_n103_), .A2(new_n108_), .B(new_n71_), .Y(o22));
  assign               o23 = 1'b1;
  OA211x2_ASAP7_75t_R  g76(.A1(new_n64_), .A2(new_n94_), .B(new_n46_), .C(new_n43_), .Y(o24));
  AND3x1_ASAP7_75t_R   g77(.A(new_n46_), .B(new_n96_), .C(new_n43_), .Y(o25));
endmodule


