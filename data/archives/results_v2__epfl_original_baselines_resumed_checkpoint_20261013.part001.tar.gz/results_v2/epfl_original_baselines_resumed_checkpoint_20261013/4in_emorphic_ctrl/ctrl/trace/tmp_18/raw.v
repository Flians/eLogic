// Benchmark "/tmp/" written by ABC on Tue Oct 13 18:51:58 2026

module \/tmp/  ( 
    p3, p0, p1, p2, p5, p6, p4,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25  );
  input  p3, p0, p1, p2, p5, p6, p4;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25;
  wire new_n34_, new_n35_, new_n36_, new_n37_, new_n38_, new_n39_, new_n41_,
    new_n43_, new_n44_, new_n45_, new_n46_, new_n47_, new_n48_, new_n50_,
    new_n51_, new_n52_, new_n53_, new_n54_, new_n55_, new_n57_, new_n58_,
    new_n59_, new_n61_, new_n62_, new_n63_, new_n64_, new_n65_, new_n66_,
    new_n67_, new_n68_, new_n69_, new_n70_, new_n71_, new_n73_, new_n74_,
    new_n76_, new_n77_, new_n79_, new_n81_, new_n84_, new_n85_, new_n86_,
    new_n87_, new_n89_, new_n91_, new_n92_, new_n93_, new_n98_, new_n102_,
    new_n103_, new_n104_, new_n105_, new_n106_, new_n108_, new_n109_,
    new_n110_;
  INVx1_ASAP7_75t_R    g00(.A(p0), .Y(new_n34_));
  NOR2x1_ASAP7_75t_R   g01(.A(p1), .B(p6), .Y(new_n35_));
  NAND2x1_ASAP7_75t_R  g02(.A(p3), .B(p2), .Y(new_n36_));
  AO21x1_ASAP7_75t_R   g03(.A1(new_n34_), .A2(new_n35_), .B(new_n36_), .Y(new_n37_));
  INVx1_ASAP7_75t_R    g04(.A(p3), .Y(new_n38_));
  INVx1_ASAP7_75t_R    g05(.A(p2), .Y(new_n39_));
  AND3x1_ASAP7_75t_R   g06(.A(new_n38_), .B(new_n39_), .C(p1), .Y(o19));
  NAND2x1_ASAP7_75t_R  g07(.A(p0), .B(o19), .Y(new_n41_));
  NAND2x1_ASAP7_75t_R  g08(.A(new_n37_), .B(new_n41_), .Y(o0));
  OR3x1_ASAP7_75t_R    g09(.A(new_n38_), .B(new_n34_), .C(p2), .Y(new_n43_));
  NOR2x1_ASAP7_75t_R   g10(.A(p0), .B(p6), .Y(new_n44_));
  NOR2x1_ASAP7_75t_R   g11(.A(p1), .B(new_n44_), .Y(new_n45_));
  INVx1_ASAP7_75t_R    g12(.A(new_n36_), .Y(new_n46_));
  OAI21x1_ASAP7_75t_R  g13(.A1(p3), .A2(p2), .B(p1), .Y(new_n47_));
  OAI21x1_ASAP7_75t_R  g14(.A1(p0), .A2(new_n46_), .B(new_n47_), .Y(new_n48_));
  AOI21x1_ASAP7_75t_R  g15(.A1(new_n43_), .A2(new_n45_), .B(new_n48_), .Y(o1));
  NOR2x1_ASAP7_75t_R   g16(.A(p3), .B(new_n39_), .Y(new_n50_));
  NOR2x1_ASAP7_75t_R   g17(.A(new_n34_), .B(new_n50_), .Y(new_n51_));
  OR3x1_ASAP7_75t_R    g18(.A(new_n38_), .B(p2), .C(p6), .Y(new_n52_));
  NOR2x1_ASAP7_75t_R   g19(.A(p1), .B(new_n34_), .Y(new_n53_));
  INVx1_ASAP7_75t_R    g20(.A(new_n53_), .Y(new_n54_));
  OR3x1_ASAP7_75t_R    g21(.A(new_n36_), .B(p1), .C(p6), .Y(new_n55_));
  AOI22x1_ASAP7_75t_R  g22(.A1(new_n51_), .A2(new_n52_), .B1(new_n54_), .B2(new_n55_), .Y(o2));
  NOR2x1_ASAP7_75t_R   g23(.A(p0), .B(p1), .Y(new_n57_));
  NAND2x1_ASAP7_75t_R  g24(.A(p2), .B(new_n57_), .Y(new_n58_));
  NAND2x1_ASAP7_75t_R  g25(.A(p3), .B(new_n39_), .Y(new_n59_));
  AOI22x1_ASAP7_75t_R  g26(.A1(new_n58_), .A2(new_n59_), .B1(p6), .B2(new_n46_), .Y(o3));
  AND3x1_ASAP7_75t_R   g27(.A(p3), .B(p0), .C(p4), .Y(new_n61_));
  NOR2x1_ASAP7_75t_R   g28(.A(p6), .B(new_n39_), .Y(new_n62_));
  AOI21x1_ASAP7_75t_R  g29(.A1(new_n61_), .A2(new_n62_), .B(p1), .Y(new_n63_));
  INVx1_ASAP7_75t_R    g30(.A(p5), .Y(new_n64_));
  AOI21x1_ASAP7_75t_R  g31(.A1(p3), .A2(new_n64_), .B(new_n39_), .Y(new_n65_));
  INVx1_ASAP7_75t_R    g32(.A(p4), .Y(new_n66_));
  NAND3x1_ASAP7_75t_R  g33(.A(new_n66_), .B(p3), .C(p5), .Y(new_n67_));
  AND2x2_ASAP7_75t_R   g34(.A(p0), .B(p6), .Y(new_n68_));
  NAND3x1_ASAP7_75t_R  g35(.A(new_n65_), .B(new_n67_), .C(new_n68_), .Y(new_n69_));
  INVx1_ASAP7_75t_R    g36(.A(p6), .Y(new_n70_));
  OA21x2_ASAP7_75t_R   g37(.A1(new_n70_), .A2(new_n59_), .B(p1), .Y(new_n71_));
  AOI21x1_ASAP7_75t_R  g38(.A1(new_n63_), .A2(new_n69_), .B(new_n71_), .Y(o4));
  INVx1_ASAP7_75t_R    g39(.A(p1), .Y(new_n73_));
  AO21x1_ASAP7_75t_R   g40(.A1(p3), .A2(new_n39_), .B(new_n73_), .Y(new_n74_));
  OA211x2_ASAP7_75t_R  g41(.A1(p1), .A2(new_n65_), .B(new_n74_), .C(p0), .Y(o5));
  AO21x1_ASAP7_75t_R   g42(.A1(new_n38_), .A2(new_n39_), .B(p1), .Y(new_n76_));
  OR3x1_ASAP7_75t_R    g43(.A(new_n35_), .B(new_n57_), .C(new_n36_), .Y(new_n77_));
  OAI21x1_ASAP7_75t_R  g44(.A1(new_n46_), .A2(new_n76_), .B(new_n77_), .Y(o6));
  AO21x1_ASAP7_75t_R   g45(.A1(p1), .A2(new_n70_), .B(new_n36_), .Y(new_n79_));
  OAI21x1_ASAP7_75t_R  g46(.A1(new_n45_), .A2(new_n79_), .B(new_n41_), .Y(o7));
  OAI21x1_ASAP7_75t_R  g47(.A1(new_n47_), .A2(new_n46_), .B(p0), .Y(new_n81_));
  AOI21x1_ASAP7_75t_R  g48(.A1(new_n53_), .A2(new_n52_), .B(new_n81_), .Y(o8));
  AOI21x1_ASAP7_75t_R  g49(.A1(new_n53_), .A2(new_n52_), .B(new_n48_), .Y(o9));
  NOR2x1_ASAP7_75t_R   g50(.A(p2), .B(new_n38_), .Y(new_n84_));
  NAND2x1_ASAP7_75t_R  g51(.A(p0), .B(new_n70_), .Y(new_n85_));
  NOR2x1_ASAP7_75t_R   g52(.A(p1), .B(p2), .Y(new_n86_));
  AOI21x1_ASAP7_75t_R  g53(.A1(p3), .A2(new_n57_), .B(new_n86_), .Y(new_n87_));
  AO22x1_ASAP7_75t_R   g54(.A1(new_n84_), .A2(new_n85_), .B1(new_n74_), .B2(new_n87_), .Y(o10));
  NOR2x1_ASAP7_75t_R   g55(.A(p3), .B(p2), .Y(new_n89_));
  AND3x1_ASAP7_75t_R   g56(.A(new_n89_), .B(new_n35_), .C(new_n34_), .Y(o11));
  AND3x1_ASAP7_75t_R   g57(.A(new_n34_), .B(new_n39_), .C(new_n70_), .Y(new_n91_));
  NOR2x1_ASAP7_75t_R   g58(.A(p3), .B(p0), .Y(new_n92_));
  OR3x1_ASAP7_75t_R    g59(.A(new_n50_), .B(new_n73_), .C(new_n92_), .Y(new_n93_));
  OAI21x1_ASAP7_75t_R  g60(.A1(new_n76_), .A2(new_n91_), .B(new_n93_), .Y(o12));
  AND3x1_ASAP7_75t_R   g61(.A(new_n89_), .B(p1), .C(p6), .Y(o13));
  AND3x1_ASAP7_75t_R   g62(.A(new_n89_), .B(p1), .C(new_n70_), .Y(o14));
  AND3x1_ASAP7_75t_R   g63(.A(new_n50_), .B(p1), .C(new_n44_), .Y(o15));
  AND3x1_ASAP7_75t_R   g64(.A(new_n38_), .B(p1), .C(p2), .Y(new_n98_));
  AND3x1_ASAP7_75t_R   g65(.A(new_n98_), .B(new_n34_), .C(p6), .Y(o16));
  AND3x1_ASAP7_75t_R   g66(.A(new_n50_), .B(p1), .C(new_n68_), .Y(o17));
  AND3x1_ASAP7_75t_R   g67(.A(new_n98_), .B(p0), .C(new_n70_), .Y(o18));
  AND3x1_ASAP7_75t_R   g68(.A(p0), .B(p2), .C(p6), .Y(new_n102_));
  OAI21x1_ASAP7_75t_R  g69(.A1(new_n38_), .A2(p4), .B(new_n102_), .Y(new_n103_));
  AND2x2_ASAP7_75t_R   g70(.A(p2), .B(p6), .Y(new_n104_));
  AOI21x1_ASAP7_75t_R  g71(.A1(new_n92_), .A2(new_n104_), .B(p1), .Y(new_n105_));
  OA21x2_ASAP7_75t_R   g72(.A1(new_n36_), .A2(new_n68_), .B(p1), .Y(new_n106_));
  AOI21x1_ASAP7_75t_R  g73(.A1(new_n103_), .A2(new_n105_), .B(new_n106_), .Y(o20));
  AND3x1_ASAP7_75t_R   g74(.A(new_n38_), .B(new_n34_), .C(p2), .Y(new_n108_));
  AND3x1_ASAP7_75t_R   g75(.A(new_n61_), .B(p2), .C(new_n64_), .Y(new_n109_));
  NOR2x1_ASAP7_75t_R   g76(.A(p1), .B(new_n70_), .Y(new_n110_));
  OA21x2_ASAP7_75t_R   g77(.A1(new_n108_), .A2(new_n109_), .B(new_n110_), .Y(o21));
  AOI21x1_ASAP7_75t_R  g78(.A1(new_n73_), .A2(new_n69_), .B(new_n106_), .Y(o22));
  assign               o23 = 1'b1;
  OA211x2_ASAP7_75t_R  g79(.A1(new_n44_), .A2(new_n68_), .B(p3), .C(new_n86_), .Y(o24));
  AND3x1_ASAP7_75t_R   g80(.A(new_n84_), .B(p6), .C(new_n57_), .Y(o25));
endmodule


