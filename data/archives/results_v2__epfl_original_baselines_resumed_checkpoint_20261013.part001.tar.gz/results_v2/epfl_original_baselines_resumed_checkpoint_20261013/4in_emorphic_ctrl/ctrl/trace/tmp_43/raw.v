// Benchmark "/tmp/" written by ABC on Tue Oct 13 18:52:00 2026

module \/tmp/  ( 
    p3, p1, p0, p2, p4, p5, p6,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25  );
  input  p3, p1, p0, p2, p4, p5, p6;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25;
  wire new_n34_, new_n35_, new_n36_, new_n37_, new_n38_, new_n39_, new_n41_,
    new_n43_, new_n44_, new_n45_, new_n46_, new_n47_, new_n48_, new_n49_,
    new_n50_, new_n52_, new_n53_, new_n54_, new_n55_, new_n56_, new_n58_,
    new_n60_, new_n61_, new_n62_, new_n63_, new_n64_, new_n65_, new_n66_,
    new_n67_, new_n68_, new_n69_, new_n71_, new_n73_, new_n74_, new_n75_,
    new_n77_, new_n78_, new_n79_, new_n81_, new_n84_, new_n85_, new_n86_,
    new_n88_, new_n90_, new_n91_, new_n92_, new_n97_, new_n101_, new_n102_,
    new_n103_, new_n105_, new_n106_, new_n107_;
  INVx1_ASAP7_75t_R    g00(.A(p6), .Y(new_n34_));
  NOR2x1_ASAP7_75t_R   g01(.A(p1), .B(p0), .Y(new_n35_));
  NAND2x1_ASAP7_75t_R  g02(.A(p3), .B(p2), .Y(new_n36_));
  AO21x1_ASAP7_75t_R   g03(.A1(new_n34_), .A2(new_n35_), .B(new_n36_), .Y(new_n37_));
  INVx1_ASAP7_75t_R    g04(.A(p3), .Y(new_n38_));
  INVx1_ASAP7_75t_R    g05(.A(p2), .Y(new_n39_));
  AND3x1_ASAP7_75t_R   g06(.A(new_n38_), .B(new_n39_), .C(p1), .Y(o19));
  NAND2x1_ASAP7_75t_R  g07(.A(p0), .B(o19), .Y(new_n41_));
  NAND2x1_ASAP7_75t_R  g08(.A(new_n37_), .B(new_n41_), .Y(o0));
  NAND2x1_ASAP7_75t_R  g09(.A(p3), .B(new_n39_), .Y(new_n43_));
  INVx1_ASAP7_75t_R    g10(.A(p0), .Y(new_n44_));
  NOR2x1_ASAP7_75t_R   g11(.A(p1), .B(new_n44_), .Y(new_n45_));
  INVx1_ASAP7_75t_R    g12(.A(p1), .Y(new_n46_));
  AND3x1_ASAP7_75t_R   g13(.A(new_n46_), .B(new_n44_), .C(p6), .Y(new_n47_));
  INVx1_ASAP7_75t_R    g14(.A(new_n36_), .Y(new_n48_));
  OAI21x1_ASAP7_75t_R  g15(.A1(p3), .A2(p2), .B(p1), .Y(new_n49_));
  OAI21x1_ASAP7_75t_R  g16(.A1(p0), .A2(new_n48_), .B(new_n49_), .Y(new_n50_));
  AOI211x1_ASAP7_75t_R g17(.A1(new_n43_), .A2(new_n45_), .B(new_n47_), .C(new_n50_), .Y(o1));
  NOR2x1_ASAP7_75t_R   g18(.A(p3), .B(new_n39_), .Y(new_n52_));
  NOR2x1_ASAP7_75t_R   g19(.A(new_n44_), .B(new_n52_), .Y(new_n53_));
  OR3x1_ASAP7_75t_R    g20(.A(new_n38_), .B(p2), .C(p6), .Y(new_n54_));
  INVx1_ASAP7_75t_R    g21(.A(new_n45_), .Y(new_n55_));
  OR3x1_ASAP7_75t_R    g22(.A(new_n36_), .B(p1), .C(p6), .Y(new_n56_));
  AOI22x1_ASAP7_75t_R  g23(.A1(new_n53_), .A2(new_n54_), .B1(new_n55_), .B2(new_n56_), .Y(o2));
  NAND2x1_ASAP7_75t_R  g24(.A(p2), .B(new_n35_), .Y(new_n58_));
  AOI22x1_ASAP7_75t_R  g25(.A1(new_n58_), .A2(new_n43_), .B1(p6), .B2(new_n48_), .Y(o3));
  AND3x1_ASAP7_75t_R   g26(.A(p3), .B(p0), .C(p4), .Y(new_n60_));
  NOR2x1_ASAP7_75t_R   g27(.A(p6), .B(new_n39_), .Y(new_n61_));
  AOI21x1_ASAP7_75t_R  g28(.A1(new_n60_), .A2(new_n61_), .B(p1), .Y(new_n62_));
  INVx1_ASAP7_75t_R    g29(.A(p5), .Y(new_n63_));
  AOI21x1_ASAP7_75t_R  g30(.A1(p3), .A2(new_n63_), .B(new_n39_), .Y(new_n64_));
  INVx1_ASAP7_75t_R    g31(.A(p4), .Y(new_n65_));
  NAND3x1_ASAP7_75t_R  g32(.A(new_n65_), .B(p3), .C(p5), .Y(new_n66_));
  AND2x2_ASAP7_75t_R   g33(.A(p0), .B(p6), .Y(new_n67_));
  NAND3x1_ASAP7_75t_R  g34(.A(new_n64_), .B(new_n66_), .C(new_n67_), .Y(new_n68_));
  OA21x2_ASAP7_75t_R   g35(.A1(new_n34_), .A2(new_n43_), .B(p1), .Y(new_n69_));
  AOI21x1_ASAP7_75t_R  g36(.A1(new_n62_), .A2(new_n68_), .B(new_n69_), .Y(o4));
  AO21x1_ASAP7_75t_R   g37(.A1(p3), .A2(new_n39_), .B(new_n46_), .Y(new_n71_));
  OA211x2_ASAP7_75t_R  g38(.A1(p1), .A2(new_n64_), .B(new_n71_), .C(p0), .Y(o5));
  AO21x1_ASAP7_75t_R   g39(.A1(new_n38_), .A2(new_n39_), .B(p1), .Y(new_n73_));
  NOR2x1_ASAP7_75t_R   g40(.A(p1), .B(p6), .Y(new_n74_));
  OR3x1_ASAP7_75t_R    g41(.A(new_n35_), .B(new_n74_), .C(new_n36_), .Y(new_n75_));
  OAI21x1_ASAP7_75t_R  g42(.A1(new_n48_), .A2(new_n73_), .B(new_n75_), .Y(o6));
  NOR2x1_ASAP7_75t_R   g43(.A(p0), .B(p6), .Y(new_n77_));
  NOR2x1_ASAP7_75t_R   g44(.A(p1), .B(new_n77_), .Y(new_n78_));
  AO21x1_ASAP7_75t_R   g45(.A1(p1), .A2(new_n34_), .B(new_n36_), .Y(new_n79_));
  OAI21x1_ASAP7_75t_R  g46(.A1(new_n78_), .A2(new_n79_), .B(new_n41_), .Y(o7));
  OAI21x1_ASAP7_75t_R  g47(.A1(new_n49_), .A2(new_n48_), .B(p0), .Y(new_n81_));
  AOI21x1_ASAP7_75t_R  g48(.A1(new_n45_), .A2(new_n54_), .B(new_n81_), .Y(o8));
  AOI21x1_ASAP7_75t_R  g49(.A1(new_n45_), .A2(new_n54_), .B(new_n50_), .Y(o9));
  NOR2x1_ASAP7_75t_R   g50(.A(p2), .B(new_n38_), .Y(new_n84_));
  NAND2x1_ASAP7_75t_R  g51(.A(p0), .B(new_n34_), .Y(new_n85_));
  AOI22x1_ASAP7_75t_R  g52(.A1(new_n35_), .A2(p3), .B1(new_n46_), .B2(new_n39_), .Y(new_n86_));
  AO22x1_ASAP7_75t_R   g53(.A1(new_n84_), .A2(new_n85_), .B1(new_n71_), .B2(new_n86_), .Y(o10));
  NOR2x1_ASAP7_75t_R   g54(.A(p3), .B(p2), .Y(new_n88_));
  AND3x1_ASAP7_75t_R   g55(.A(new_n35_), .B(new_n88_), .C(new_n34_), .Y(o11));
  AND3x1_ASAP7_75t_R   g56(.A(new_n44_), .B(new_n39_), .C(new_n34_), .Y(new_n90_));
  NOR2x1_ASAP7_75t_R   g57(.A(p3), .B(p0), .Y(new_n91_));
  OR3x1_ASAP7_75t_R    g58(.A(new_n52_), .B(new_n46_), .C(new_n91_), .Y(new_n92_));
  OAI21x1_ASAP7_75t_R  g59(.A1(new_n73_), .A2(new_n90_), .B(new_n92_), .Y(o12));
  AND3x1_ASAP7_75t_R   g60(.A(new_n88_), .B(p1), .C(p6), .Y(o13));
  AND3x1_ASAP7_75t_R   g61(.A(new_n88_), .B(p1), .C(new_n34_), .Y(o14));
  AND3x1_ASAP7_75t_R   g62(.A(new_n52_), .B(p1), .C(new_n77_), .Y(o15));
  AND3x1_ASAP7_75t_R   g63(.A(new_n38_), .B(p1), .C(p2), .Y(new_n97_));
  AND3x1_ASAP7_75t_R   g64(.A(new_n97_), .B(new_n44_), .C(p6), .Y(o16));
  AND3x1_ASAP7_75t_R   g65(.A(new_n52_), .B(p1), .C(new_n67_), .Y(o17));
  AND3x1_ASAP7_75t_R   g66(.A(new_n97_), .B(p0), .C(new_n34_), .Y(o18));
  AND2x2_ASAP7_75t_R   g67(.A(p0), .B(p2), .Y(new_n101_));
  AOI22x1_ASAP7_75t_R  g68(.A1(new_n101_), .A2(p4), .B1(new_n38_), .B2(p2), .Y(new_n102_));
  OA21x2_ASAP7_75t_R   g69(.A1(new_n36_), .A2(new_n67_), .B(p1), .Y(new_n103_));
  AOI211x1_ASAP7_75t_R g70(.A1(new_n46_), .A2(new_n102_), .B(new_n74_), .C(new_n103_), .Y(o20));
  AND3x1_ASAP7_75t_R   g71(.A(new_n38_), .B(new_n44_), .C(p2), .Y(new_n105_));
  AND3x1_ASAP7_75t_R   g72(.A(new_n60_), .B(p2), .C(new_n63_), .Y(new_n106_));
  NOR2x1_ASAP7_75t_R   g73(.A(p1), .B(new_n34_), .Y(new_n107_));
  OA21x2_ASAP7_75t_R   g74(.A1(new_n105_), .A2(new_n106_), .B(new_n107_), .Y(o21));
  AOI21x1_ASAP7_75t_R  g75(.A1(new_n46_), .A2(new_n68_), .B(new_n103_), .Y(o22));
  assign               o23 = 1'b1;
  OA211x2_ASAP7_75t_R  g76(.A1(new_n77_), .A2(new_n67_), .B(new_n84_), .C(new_n46_), .Y(o24));
  AND3x1_ASAP7_75t_R   g77(.A(new_n84_), .B(p6), .C(new_n35_), .Y(o25));
endmodule


