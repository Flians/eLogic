// Benchmark "/home/flynn/workplace/MIGBalance/results_v2/epfl_original_baselines_resumed_checkpoint_20261013/4in_core_router/router.resyn2" written by ABC on Tue Oct 13 19:19:56 2026

module \/home/flynn/workplace/MIGBalance/results_v2/epfl_original_baselines_resumed_checkpoint_20261013/4in_core_router/router.resyn2  ( 
    \dest_x[0] , \dest_x[1] , \dest_x[2] , \dest_x[3] , \dest_x[4] ,
    \dest_x[5] , \dest_x[6] , \dest_x[7] , \dest_x[8] , \dest_x[9] ,
    \dest_x[10] , \dest_x[11] , \dest_x[12] , \dest_x[13] , \dest_x[14] ,
    \dest_x[15] , \dest_x[16] , \dest_x[17] , \dest_x[18] , \dest_x[19] ,
    \dest_x[20] , \dest_x[21] , \dest_x[22] , \dest_x[23] , \dest_x[24] ,
    \dest_x[25] , \dest_x[26] , \dest_x[27] , \dest_x[28] , \dest_x[29] ,
    \dest_y[0] , \dest_y[1] , \dest_y[2] , \dest_y[3] , \dest_y[4] ,
    \dest_y[5] , \dest_y[6] , \dest_y[7] , \dest_y[8] , \dest_y[9] ,
    \dest_y[10] , \dest_y[11] , \dest_y[12] , \dest_y[13] , \dest_y[14] ,
    \dest_y[15] , \dest_y[16] , \dest_y[17] , \dest_y[18] , \dest_y[19] ,
    \dest_y[20] , \dest_y[21] , \dest_y[22] , \dest_y[23] , \dest_y[24] ,
    \dest_y[25] , \dest_y[26] , \dest_y[27] , \dest_y[28] , \dest_y[29] ,
    \outport[0] , \outport[1] , \outport[2] , \outport[3] , \outport[4] ,
    \outport[5] , \outport[6] , \outport[7] , \outport[8] , \outport[9] ,
    \outport[10] , \outport[11] , \outport[12] , \outport[13] ,
    \outport[14] , \outport[15] , \outport[16] , \outport[17] ,
    \outport[18] , \outport[19] , \outport[20] , \outport[21] ,
    \outport[22] , \outport[23] , \outport[24] , \outport[25] ,
    \outport[26] , \outport[27] , \outport[28] , \outport[29]   );
  input  \dest_x[0] , \dest_x[1] , \dest_x[2] , \dest_x[3] , \dest_x[4] ,
    \dest_x[5] , \dest_x[6] , \dest_x[7] , \dest_x[8] , \dest_x[9] ,
    \dest_x[10] , \dest_x[11] , \dest_x[12] , \dest_x[13] , \dest_x[14] ,
    \dest_x[15] , \dest_x[16] , \dest_x[17] , \dest_x[18] , \dest_x[19] ,
    \dest_x[20] , \dest_x[21] , \dest_x[22] , \dest_x[23] , \dest_x[24] ,
    \dest_x[25] , \dest_x[26] , \dest_x[27] , \dest_x[28] , \dest_x[29] ,
    \dest_y[0] , \dest_y[1] , \dest_y[2] , \dest_y[3] , \dest_y[4] ,
    \dest_y[5] , \dest_y[6] , \dest_y[7] , \dest_y[8] , \dest_y[9] ,
    \dest_y[10] , \dest_y[11] , \dest_y[12] , \dest_y[13] , \dest_y[14] ,
    \dest_y[15] , \dest_y[16] , \dest_y[17] , \dest_y[18] , \dest_y[19] ,
    \dest_y[20] , \dest_y[21] , \dest_y[22] , \dest_y[23] , \dest_y[24] ,
    \dest_y[25] , \dest_y[26] , \dest_y[27] , \dest_y[28] , \dest_y[29] ;
  output \outport[0] , \outport[1] , \outport[2] , \outport[3] , \outport[4] ,
    \outport[5] , \outport[6] , \outport[7] , \outport[8] , \outport[9] ,
    \outport[10] , \outport[11] , \outport[12] , \outport[13] ,
    \outport[14] , \outport[15] , \outport[16] , \outport[17] ,
    \outport[18] , \outport[19] , \outport[20] , \outport[21] ,
    \outport[22] , \outport[23] , \outport[24] , \outport[25] ,
    \outport[26] , \outport[27] , \outport[28] , \outport[29] ;
  wire new_n91_, new_n92_, new_n93_, new_n94_, new_n95_, new_n96_, new_n97_,
    new_n98_, new_n99_, new_n100_, new_n101_, new_n102_, new_n103_,
    new_n104_, new_n105_, new_n106_, new_n107_, new_n108_, new_n109_,
    new_n110_, new_n111_, new_n112_, new_n113_, new_n114_, new_n115_,
    new_n116_, new_n117_, new_n118_, new_n119_, new_n120_, new_n121_,
    new_n122_, new_n123_, new_n124_, new_n125_, new_n126_, new_n127_,
    new_n128_, new_n129_, new_n130_, new_n131_, new_n132_, new_n133_,
    new_n134_, new_n135_, new_n136_, new_n137_, new_n138_, new_n139_,
    new_n140_, new_n141_, new_n142_, new_n143_, new_n144_, new_n145_,
    new_n146_, new_n147_, new_n148_, new_n150_, new_n151_, new_n152_,
    new_n153_, new_n154_, new_n155_, new_n156_, new_n157_, new_n158_,
    new_n159_, new_n160_, new_n161_, new_n162_, new_n163_, new_n164_,
    new_n165_, new_n166_, new_n167_, new_n168_, new_n169_, new_n170_,
    new_n171_, new_n172_, new_n173_, new_n174_, new_n175_, new_n176_,
    new_n177_, new_n178_, new_n179_, new_n180_, new_n181_, new_n182_,
    new_n183_, new_n184_, new_n185_, new_n186_, new_n187_, new_n188_,
    new_n189_, new_n190_, new_n191_, new_n192_, new_n193_, new_n194_,
    new_n195_, new_n196_, new_n197_, new_n198_, new_n199_, new_n200_,
    new_n201_, new_n202_, new_n203_, new_n204_, new_n205_, new_n206_,
    new_n207_, new_n208_, new_n210_;
  AND3x1_ASAP7_75t_R   g000(.A(\dest_x[27] ), .B(\dest_x[28] ), .C(\dest_x[29] ), .Y(new_n91_));
  INVx1_ASAP7_75t_R    g001(.A(\dest_x[23] ), .Y(new_n92_));
  INVx1_ASAP7_75t_R    g002(.A(\dest_x[19] ), .Y(new_n93_));
  INVx1_ASAP7_75t_R    g003(.A(\dest_x[20] ), .Y(new_n94_));
  INVx1_ASAP7_75t_R    g004(.A(\dest_x[18] ), .Y(new_n95_));
  INVx1_ASAP7_75t_R    g005(.A(\dest_x[14] ), .Y(new_n96_));
  INVx1_ASAP7_75t_R    g006(.A(\dest_x[12] ), .Y(new_n97_));
  INVx1_ASAP7_75t_R    g007(.A(\dest_x[13] ), .Y(new_n98_));
  INVx1_ASAP7_75t_R    g008(.A(\dest_x[9] ), .Y(new_n99_));
  INVx1_ASAP7_75t_R    g009(.A(\dest_x[10] ), .Y(new_n100_));
  INVx1_ASAP7_75t_R    g010(.A(\dest_x[11] ), .Y(new_n101_));
  AO21x1_ASAP7_75t_R   g011(.A1(new_n99_), .A2(new_n100_), .B(new_n101_), .Y(new_n102_));
  AND3x1_ASAP7_75t_R   g012(.A(new_n102_), .B(new_n97_), .C(new_n98_), .Y(new_n103_));
  NOR2x1_ASAP7_75t_R   g013(.A(new_n96_), .B(new_n103_), .Y(new_n104_));
  AND2x2_ASAP7_75t_R   g014(.A(new_n104_), .B(\dest_x[15] ), .Y(new_n105_));
  OAI21x1_ASAP7_75t_R  g015(.A1(\dest_x[16] ), .A2(new_n105_), .B(\dest_x[17] ), .Y(new_n106_));
  AND2x2_ASAP7_75t_R   g016(.A(new_n106_), .B(new_n95_), .Y(new_n107_));
  OR3x1_ASAP7_75t_R    g017(.A(new_n107_), .B(new_n93_), .C(new_n94_), .Y(new_n108_));
  NOR2x1_ASAP7_75t_R   g018(.A(\dest_x[21] ), .B(\dest_x[22] ), .Y(new_n109_));
  AO21x1_ASAP7_75t_R   g019(.A1(new_n108_), .A2(new_n109_), .B(new_n92_), .Y(new_n110_));
  INVx1_ASAP7_75t_R    g020(.A(new_n110_), .Y(new_n111_));
  AND3x1_ASAP7_75t_R   g021(.A(new_n111_), .B(\dest_x[24] ), .C(\dest_x[25] ), .Y(new_n112_));
  OA21x2_ASAP7_75t_R   g022(.A1(new_n112_), .A2(\dest_x[26] ), .B(new_n91_), .Y(new_n113_));
  XOR2x2_ASAP7_75t_R   g023(.A(new_n104_), .B(\dest_x[15] ), .Y(new_n114_));
  OR4x2_ASAP7_75t_R    g024(.A(new_n97_), .B(\dest_x[9] ), .C(\dest_x[10] ), .D(\dest_x[11] ), .Y(new_n115_));
  OA21x2_ASAP7_75t_R   g025(.A1(\dest_x[12] ), .A2(new_n102_), .B(new_n115_), .Y(new_n116_));
  OR4x2_ASAP7_75t_R    g026(.A(new_n92_), .B(\dest_x[1] ), .C(\dest_x[2] ), .D(\dest_x[22] ), .Y(new_n117_));
  OR3x1_ASAP7_75t_R    g027(.A(new_n117_), .B(new_n94_), .C(\dest_x[21] ), .Y(new_n118_));
  NAND2x1_ASAP7_75t_R  g028(.A(\dest_x[9] ), .B(new_n100_), .Y(new_n119_));
  OR4x2_ASAP7_75t_R    g029(.A(\dest_x[3] ), .B(\dest_x[4] ), .C(\dest_x[5] ), .D(\dest_x[6] ), .Y(new_n120_));
  OR4x2_ASAP7_75t_R    g030(.A(new_n119_), .B(\dest_x[7] ), .C(\dest_x[8] ), .D(new_n120_), .Y(new_n121_));
  INVx1_ASAP7_75t_R    g031(.A(\dest_x[24] ), .Y(new_n122_));
  INVx1_ASAP7_75t_R    g032(.A(\dest_x[25] ), .Y(new_n123_));
  OR4x2_ASAP7_75t_R    g033(.A(new_n96_), .B(new_n93_), .C(\dest_x[13] ), .D(\dest_x[18] ), .Y(new_n124_));
  OR4x2_ASAP7_75t_R    g034(.A(new_n124_), .B(new_n122_), .C(new_n123_), .D(\dest_x[26] ), .Y(new_n125_));
  OR4x2_ASAP7_75t_R    g035(.A(new_n125_), .B(new_n116_), .C(new_n118_), .D(new_n121_), .Y(new_n126_));
  AO21x1_ASAP7_75t_R   g036(.A1(new_n105_), .A2(\dest_x[16] ), .B(new_n126_), .Y(new_n127_));
  OR3x1_ASAP7_75t_R    g037(.A(new_n127_), .B(new_n106_), .C(new_n114_), .Y(new_n128_));
  AND2x2_ASAP7_75t_R   g038(.A(new_n113_), .B(new_n128_), .Y(new_n129_));
  INVx1_ASAP7_75t_R    g039(.A(new_n129_), .Y(new_n130_));
  NAND2x1_ASAP7_75t_R  g040(.A(new_n122_), .B(new_n110_), .Y(new_n131_));
  OR3x1_ASAP7_75t_R    g041(.A(new_n105_), .B(\dest_x[16] ), .C(\dest_x[17] ), .Y(new_n132_));
  INVx1_ASAP7_75t_R    g042(.A(\dest_x[26] ), .Y(new_n133_));
  AND3x1_ASAP7_75t_R   g043(.A(new_n133_), .B(\dest_x[19] ), .C(\dest_x[25] ), .Y(new_n134_));
  INVx1_ASAP7_75t_R    g044(.A(\dest_x[16] ), .Y(new_n135_));
  AND4x2_ASAP7_75t_R   g045(.A(new_n97_), .B(new_n98_), .C(new_n135_), .D(\dest_x[15] ), .Y(new_n136_));
  AND3x1_ASAP7_75t_R   g046(.A(new_n136_), .B(new_n91_), .C(new_n134_), .Y(new_n137_));
  AND4x2_ASAP7_75t_R   g047(.A(new_n99_), .B(new_n100_), .C(\dest_x[0] ), .D(\dest_x[1] ), .Y(new_n138_));
  INVx1_ASAP7_75t_R    g048(.A(\dest_x[21] ), .Y(new_n139_));
  INVx1_ASAP7_75t_R    g049(.A(\dest_x[22] ), .Y(new_n140_));
  AND4x2_ASAP7_75t_R   g050(.A(new_n139_), .B(new_n140_), .C(\dest_x[20] ), .D(\dest_x[23] ), .Y(new_n141_));
  AND4x2_ASAP7_75t_R   g051(.A(\dest_x[6] ), .B(\dest_x[7] ), .C(\dest_x[8] ), .D(\dest_x[11] ), .Y(new_n142_));
  AND4x2_ASAP7_75t_R   g052(.A(\dest_x[2] ), .B(\dest_x[3] ), .C(\dest_x[4] ), .D(\dest_x[5] ), .Y(new_n143_));
  AND4x2_ASAP7_75t_R   g053(.A(new_n138_), .B(new_n141_), .C(new_n142_), .D(new_n143_), .Y(new_n144_));
  XOR2x2_ASAP7_75t_R   g054(.A(new_n103_), .B(new_n96_), .Y(new_n145_));
  AND4x2_ASAP7_75t_R   g055(.A(new_n132_), .B(new_n137_), .C(new_n144_), .D(new_n145_), .Y(new_n146_));
  OA211x2_ASAP7_75t_R  g056(.A1(new_n110_), .A2(new_n122_), .B(new_n107_), .C(new_n146_), .Y(new_n147_));
  AO21x1_ASAP7_75t_R   g057(.A1(new_n131_), .A2(new_n147_), .B(new_n113_), .Y(new_n148_));
  NAND2x1_ASAP7_75t_R  g058(.A(new_n148_), .B(new_n130_), .Y(\outport[0] ));
  INVx1_ASAP7_75t_R    g059(.A(\dest_y[26] ), .Y(new_n150_));
  NAND3x1_ASAP7_75t_R  g060(.A(\dest_y[27] ), .B(\dest_y[29] ), .C(\dest_y[28] ), .Y(new_n151_));
  INVx1_ASAP7_75t_R    g061(.A(\dest_y[19] ), .Y(new_n152_));
  INVx1_ASAP7_75t_R    g062(.A(\dest_y[20] ), .Y(new_n153_));
  NOR2x1_ASAP7_75t_R   g063(.A(\dest_y[9] ), .B(\dest_y[10] ), .Y(new_n154_));
  INVx1_ASAP7_75t_R    g064(.A(new_n154_), .Y(new_n155_));
  AO21x1_ASAP7_75t_R   g065(.A1(new_n155_), .A2(\dest_y[11] ), .B(\dest_y[12] ), .Y(new_n156_));
  OA21x2_ASAP7_75t_R   g066(.A1(new_n156_), .A2(\dest_y[13] ), .B(\dest_y[14] ), .Y(new_n157_));
  AO21x1_ASAP7_75t_R   g067(.A1(new_n157_), .A2(\dest_y[15] ), .B(\dest_y[16] ), .Y(new_n158_));
  AND2x2_ASAP7_75t_R   g068(.A(new_n158_), .B(\dest_y[17] ), .Y(new_n159_));
  NOR2x1_ASAP7_75t_R   g069(.A(\dest_y[18] ), .B(new_n159_), .Y(new_n160_));
  OR3x1_ASAP7_75t_R    g070(.A(new_n160_), .B(new_n152_), .C(new_n153_), .Y(new_n161_));
  INVx1_ASAP7_75t_R    g071(.A(new_n161_), .Y(new_n162_));
  OR3x1_ASAP7_75t_R    g072(.A(new_n162_), .B(\dest_y[21] ), .C(\dest_y[22] ), .Y(new_n163_));
  AND2x2_ASAP7_75t_R   g073(.A(\dest_y[24] ), .B(\dest_y[25] ), .Y(new_n164_));
  NAND3x1_ASAP7_75t_R  g074(.A(new_n163_), .B(new_n164_), .C(\dest_y[23] ), .Y(new_n165_));
  AO21x1_ASAP7_75t_R   g075(.A1(new_n165_), .A2(new_n150_), .B(new_n151_), .Y(new_n166_));
  OA21x2_ASAP7_75t_R   g076(.A1(\dest_x[0] ), .A2(\dest_y[21] ), .B(new_n166_), .Y(new_n167_));
  INVx1_ASAP7_75t_R    g077(.A(\dest_y[22] ), .Y(new_n168_));
  OA21x2_ASAP7_75t_R   g078(.A1(new_n168_), .A2(\dest_y[23] ), .B(new_n162_), .Y(new_n169_));
  AND2x2_ASAP7_75t_R   g079(.A(new_n168_), .B(\dest_y[23] ), .Y(new_n170_));
  NOR2x1_ASAP7_75t_R   g080(.A(new_n170_), .B(new_n162_), .Y(new_n171_));
  AOI21x1_ASAP7_75t_R  g081(.A1(new_n152_), .A2(new_n159_), .B(new_n160_), .Y(new_n172_));
  INVx1_ASAP7_75t_R    g082(.A(\dest_y[15] ), .Y(new_n173_));
  AND3x1_ASAP7_75t_R   g083(.A(new_n155_), .B(\dest_y[11] ), .C(\dest_y[12] ), .Y(new_n174_));
  AOI21x1_ASAP7_75t_R  g084(.A1(\dest_y[13] ), .A2(new_n174_), .B(\dest_y[14] ), .Y(new_n175_));
  INVx1_ASAP7_75t_R    g085(.A(new_n164_), .Y(new_n176_));
  NAND2x1_ASAP7_75t_R  g086(.A(\dest_y[0] ), .B(\dest_y[1] ), .Y(new_n177_));
  INVx1_ASAP7_75t_R    g087(.A(\dest_y[18] ), .Y(new_n178_));
  AO21x1_ASAP7_75t_R   g088(.A1(new_n178_), .A2(new_n152_), .B(new_n155_), .Y(new_n179_));
  AND4x2_ASAP7_75t_R   g089(.A(\dest_y[6] ), .B(\dest_y[7] ), .C(\dest_y[8] ), .D(\dest_y[11] ), .Y(new_n180_));
  AND4x2_ASAP7_75t_R   g090(.A(\dest_y[2] ), .B(\dest_y[3] ), .C(\dest_y[4] ), .D(\dest_y[5] ), .Y(new_n181_));
  NAND2x1_ASAP7_75t_R  g091(.A(new_n180_), .B(new_n181_), .Y(new_n182_));
  INVx1_ASAP7_75t_R    g092(.A(\dest_y[17] ), .Y(new_n183_));
  OR4x2_ASAP7_75t_R    g093(.A(new_n183_), .B(new_n153_), .C(\dest_y[16] ), .D(\dest_y[26] ), .Y(new_n184_));
  OR3x1_ASAP7_75t_R    g094(.A(new_n182_), .B(new_n151_), .C(new_n184_), .Y(new_n185_));
  OR4x2_ASAP7_75t_R    g095(.A(new_n185_), .B(new_n176_), .C(new_n177_), .D(new_n179_), .Y(new_n186_));
  OR4x2_ASAP7_75t_R    g096(.A(new_n186_), .B(new_n173_), .C(new_n157_), .D(new_n175_), .Y(new_n187_));
  OR4x2_ASAP7_75t_R    g097(.A(new_n171_), .B(new_n169_), .C(new_n172_), .D(new_n187_), .Y(new_n188_));
  NOR2x1_ASAP7_75t_R   g098(.A(new_n178_), .B(new_n158_), .Y(new_n189_));
  NOR2x1_ASAP7_75t_R   g099(.A(\dest_y[16] ), .B(\dest_y[21] ), .Y(new_n190_));
  AND3x1_ASAP7_75t_R   g100(.A(new_n190_), .B(new_n150_), .C(\dest_y[27] ), .Y(new_n191_));
  INVx1_ASAP7_75t_R    g101(.A(\dest_y[13] ), .Y(new_n192_));
  AND4x2_ASAP7_75t_R   g102(.A(new_n192_), .B(\dest_y[11] ), .C(\dest_y[14] ), .D(\dest_y[15] ), .Y(new_n193_));
  INVx1_ASAP7_75t_R    g103(.A(\dest_y[10] ), .Y(new_n194_));
  NOR2x1_ASAP7_75t_R   g104(.A(\dest_y[7] ), .B(\dest_y[8] ), .Y(new_n195_));
  AND3x1_ASAP7_75t_R   g105(.A(new_n195_), .B(\dest_y[9] ), .C(new_n194_), .Y(new_n196_));
  AND3x1_ASAP7_75t_R   g106(.A(new_n191_), .B(new_n196_), .C(new_n193_), .Y(new_n197_));
  INVx1_ASAP7_75t_R    g107(.A(new_n174_), .Y(new_n198_));
  AND2x2_ASAP7_75t_R   g108(.A(\dest_y[19] ), .B(\dest_y[20] ), .Y(new_n199_));
  OA211x2_ASAP7_75t_R  g109(.A1(new_n183_), .A2(new_n178_), .B(new_n170_), .C(new_n199_), .Y(new_n200_));
  OR4x2_ASAP7_75t_R    g110(.A(\dest_y[3] ), .B(\dest_y[4] ), .C(\dest_y[5] ), .D(\dest_y[6] ), .Y(new_n201_));
  OR3x1_ASAP7_75t_R    g111(.A(new_n176_), .B(\dest_y[1] ), .C(\dest_y[2] ), .Y(new_n202_));
  NOR2x1_ASAP7_75t_R   g112(.A(new_n201_), .B(new_n202_), .Y(new_n203_));
  AND4x2_ASAP7_75t_R   g113(.A(new_n203_), .B(new_n156_), .C(new_n198_), .D(new_n200_), .Y(new_n204_));
  OA211x2_ASAP7_75t_R  g114(.A1(new_n189_), .A2(new_n159_), .B(new_n197_), .C(new_n204_), .Y(new_n205_));
  NOR2x1_ASAP7_75t_R   g115(.A(\dest_x[0] ), .B(\dest_y[0] ), .Y(new_n206_));
  AO21x1_ASAP7_75t_R   g116(.A1(new_n205_), .A2(new_n206_), .B(new_n166_), .Y(new_n207_));
  OAI21x1_ASAP7_75t_R  g117(.A1(new_n188_), .A2(new_n167_), .B(new_n207_), .Y(new_n208_));
  AOI21x1_ASAP7_75t_R  g118(.A1(new_n148_), .A2(new_n208_), .B(new_n129_), .Y(\outport[1] ));
  NAND2x1_ASAP7_75t_R  g119(.A(\dest_x[0] ), .B(\dest_y[0] ), .Y(new_n210_));
  AOI211x1_ASAP7_75t_R g120(.A1(new_n205_), .A2(new_n210_), .B(\outport[0] ), .C(new_n166_), .Y(\outport[2] ));
  assign               \outport[3]  = 1'b0;
  assign               \outport[4]  = 1'b0;
  assign               \outport[5]  = 1'b0;
  assign               \outport[6]  = 1'b0;
  assign               \outport[7]  = 1'b0;
  assign               \outport[8]  = 1'b0;
  assign               \outport[9]  = 1'b0;
  assign               \outport[10]  = 1'b0;
  assign               \outport[11]  = 1'b0;
  assign               \outport[12]  = 1'b0;
  assign               \outport[13]  = 1'b0;
  assign               \outport[14]  = 1'b0;
  assign               \outport[15]  = 1'b0;
  assign               \outport[16]  = 1'b0;
  assign               \outport[17]  = 1'b0;
  assign               \outport[18]  = 1'b0;
  assign               \outport[19]  = 1'b0;
  assign               \outport[20]  = 1'b0;
  assign               \outport[21]  = 1'b0;
  assign               \outport[22]  = 1'b0;
  assign               \outport[23]  = 1'b0;
  assign               \outport[24]  = 1'b0;
  assign               \outport[25]  = 1'b0;
  assign               \outport[26]  = 1'b0;
  assign               \outport[27]  = 1'b0;
  assign               \outport[28]  = 1'b0;
  assign               \outport[29]  = 1'b0;
endmodule


