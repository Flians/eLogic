// Benchmark "/home/flynn/workplace/MIGBalance/results_v2/epfl_original_baselines_resumed_checkpoint_20261013/4in_core_ctrl/ctrl.resyn2" written by ABC on Tue Oct 13 18:51:01 2026

module \/home/flynn/workplace/MIGBalance/results_v2/epfl_original_baselines_resumed_checkpoint_20261013/4in_core_ctrl/ctrl.resyn2  ( 
    \opcode[0] , \opcode[1] , \opcode[2] , \opcode[3] , \opcode[4] ,
    \op_ext[0] , \op_ext[1] ,
    \sel_reg_dst[0] , \sel_reg_dst[1] , \sel_alu_opB[0] , \sel_alu_opB[1] ,
    \alu_op[0] , \alu_op[1] , \alu_op[2] , \alu_op_ext[0] ,
    \alu_op_ext[1] , \alu_op_ext[2] , \alu_op_ext[3] , halt, reg_write,
    sel_pc_opA, sel_pc_opB, beqz, bnez, bgez, bltz, jump, Cin, invA, invB,
    sign, mem_write, sel_wb  );
  input  \opcode[0] , \opcode[1] , \opcode[2] , \opcode[3] , \opcode[4] ,
    \op_ext[0] , \op_ext[1] ;
  output \sel_reg_dst[0] , \sel_reg_dst[1] , \sel_alu_opB[0] ,
    \sel_alu_opB[1] , \alu_op[0] , \alu_op[1] , \alu_op[2] ,
    \alu_op_ext[0] , \alu_op_ext[1] , \alu_op_ext[2] , \alu_op_ext[3] ,
    halt, reg_write, sel_pc_opA, sel_pc_opB, beqz, bnez, bgez, bltz, jump,
    Cin, invA, invB, sign, mem_write, sel_wb;
  wire new_n34_, new_n35_, new_n36_, new_n37_, new_n38_, new_n39_, new_n40_,
    new_n42_, new_n43_, new_n44_, new_n45_, new_n46_, new_n47_, new_n48_,
    new_n49_, new_n50_, new_n51_, new_n53_, new_n54_, new_n56_, new_n57_,
    new_n58_, new_n59_, new_n60_, new_n62_, new_n63_, new_n64_, new_n65_,
    new_n66_, new_n67_, new_n68_, new_n69_, new_n71_, new_n73_, new_n74_,
    new_n75_, new_n77_, new_n79_, new_n81_, new_n83_, new_n84_, new_n85_,
    new_n88_, new_n89_, new_n90_, new_n94_, new_n97_, new_n101_, new_n102_,
    new_n103_, new_n104_, new_n106_, new_n108_;
  AND2x2_ASAP7_75t_R   g00(.A(\opcode[3] ), .B(\opcode[4] ), .Y(new_n34_));
  NOR2x1_ASAP7_75t_R   g01(.A(\opcode[0] ), .B(\opcode[1] ), .Y(new_n35_));
  INVx1_ASAP7_75t_R    g02(.A(new_n35_), .Y(new_n36_));
  INVx1_ASAP7_75t_R    g03(.A(\opcode[3] ), .Y(new_n37_));
  INVx1_ASAP7_75t_R    g04(.A(\opcode[4] ), .Y(new_n38_));
  AND3x1_ASAP7_75t_R   g05(.A(new_n37_), .B(new_n38_), .C(\opcode[1] ), .Y(new_n39_));
  OA21x2_ASAP7_75t_R   g06(.A1(new_n39_), .A2(new_n34_), .B(\opcode[2] ), .Y(new_n40_));
  AO21x1_ASAP7_75t_R   g07(.A1(new_n34_), .A2(new_n36_), .B(new_n40_), .Y(\sel_reg_dst[0] ));
  INVx1_ASAP7_75t_R    g08(.A(\opcode[1] ), .Y(new_n42_));
  AND2x2_ASAP7_75t_R   g09(.A(new_n37_), .B(\opcode[4] ), .Y(new_n43_));
  INVx1_ASAP7_75t_R    g10(.A(\opcode[0] ), .Y(new_n44_));
  AND3x1_ASAP7_75t_R   g11(.A(new_n44_), .B(\opcode[3] ), .C(\opcode[4] ), .Y(new_n45_));
  NOR2x1_ASAP7_75t_R   g12(.A(\opcode[1] ), .B(new_n45_), .Y(new_n46_));
  INVx1_ASAP7_75t_R    g13(.A(new_n46_), .Y(new_n47_));
  OA21x2_ASAP7_75t_R   g14(.A1(new_n42_), .A2(new_n43_), .B(new_n47_), .Y(new_n48_));
  INVx1_ASAP7_75t_R    g15(.A(\opcode[2] ), .Y(new_n49_));
  NOR2x1_ASAP7_75t_R   g16(.A(new_n49_), .B(new_n39_), .Y(new_n50_));
  INVx1_ASAP7_75t_R    g17(.A(new_n50_), .Y(new_n51_));
  OA21x2_ASAP7_75t_R   g18(.A1(new_n48_), .A2(\opcode[2] ), .B(new_n51_), .Y(\sel_reg_dst[1] ));
  AO21x1_ASAP7_75t_R   g19(.A1(new_n43_), .A2(new_n44_), .B(new_n42_), .Y(new_n53_));
  AO21x1_ASAP7_75t_R   g20(.A1(\opcode[3] ), .A2(new_n38_), .B(new_n53_), .Y(new_n54_));
  AND3x1_ASAP7_75t_R   g21(.A(new_n54_), .B(new_n49_), .C(new_n47_), .Y(\sel_alu_opB[0] ));
  INVx1_ASAP7_75t_R    g22(.A(new_n34_), .Y(new_n56_));
  NOR2x1_ASAP7_75t_R   g23(.A(\opcode[3] ), .B(\opcode[4] ), .Y(new_n57_));
  INVx1_ASAP7_75t_R    g24(.A(new_n57_), .Y(new_n58_));
  NOR2x1_ASAP7_75t_R   g25(.A(\opcode[1] ), .B(\opcode[2] ), .Y(new_n59_));
  OA21x2_ASAP7_75t_R   g26(.A1(new_n59_), .A2(new_n37_), .B(new_n58_), .Y(new_n60_));
  OA21x2_ASAP7_75t_R   g27(.A1(new_n44_), .A2(new_n56_), .B(new_n60_), .Y(\sel_alu_opB[1] ));
  INVx1_ASAP7_75t_R    g28(.A(\op_ext[1] ), .Y(new_n62_));
  AO21x1_ASAP7_75t_R   g29(.A1(new_n62_), .A2(\opcode[4] ), .B(new_n37_), .Y(new_n63_));
  NOR2x1_ASAP7_75t_R   g30(.A(\op_ext[0] ), .B(new_n38_), .Y(new_n64_));
  AO21x1_ASAP7_75t_R   g31(.A1(new_n64_), .A2(\op_ext[1] ), .B(new_n63_), .Y(new_n65_));
  NOR2x1_ASAP7_75t_R   g32(.A(new_n44_), .B(new_n65_), .Y(new_n66_));
  AO21x1_ASAP7_75t_R   g33(.A1(\op_ext[0] ), .A2(new_n45_), .B(new_n66_), .Y(new_n67_));
  AO21x1_ASAP7_75t_R   g34(.A1(new_n67_), .A2(\opcode[1] ), .B(\opcode[2] ), .Y(new_n68_));
  AO21x1_ASAP7_75t_R   g35(.A1(new_n37_), .A2(\opcode[4] ), .B(new_n49_), .Y(new_n69_));
  OA211x2_ASAP7_75t_R  g36(.A1(\opcode[0] ), .A2(new_n49_), .B(new_n68_), .C(new_n69_), .Y(\alu_op[0] ));
  INVx1_ASAP7_75t_R    g37(.A(new_n63_), .Y(new_n71_));
  OA211x2_ASAP7_75t_R  g38(.A1(new_n71_), .A2(\opcode[2] ), .B(\opcode[1] ), .C(new_n69_), .Y(\alu_op[1] ));
  AND2x2_ASAP7_75t_R   g39(.A(\opcode[0] ), .B(\opcode[1] ), .Y(new_n73_));
  OR3x1_ASAP7_75t_R    g40(.A(new_n56_), .B(new_n73_), .C(\opcode[2] ), .Y(new_n74_));
  AO21x1_ASAP7_75t_R   g41(.A1(\opcode[3] ), .A2(\opcode[4] ), .B(new_n49_), .Y(new_n75_));
  AND3x1_ASAP7_75t_R   g42(.A(new_n74_), .B(new_n58_), .C(new_n75_), .Y(\alu_op[2] ));
  AO21x1_ASAP7_75t_R   g43(.A1(\opcode[0] ), .A2(new_n34_), .B(new_n39_), .Y(new_n77_));
  AO22x1_ASAP7_75t_R   g44(.A1(new_n77_), .A2(\opcode[2] ), .B1(new_n45_), .B2(new_n59_), .Y(\alu_op_ext[0] ));
  OA21x2_ASAP7_75t_R   g45(.A1(new_n75_), .A2(new_n57_), .B(\opcode[1] ), .Y(new_n79_));
  OA21x2_ASAP7_75t_R   g46(.A1(new_n53_), .A2(\opcode[2] ), .B(new_n79_), .Y(\alu_op_ext[1] ));
  OR3x1_ASAP7_75t_R    g47(.A(new_n34_), .B(\opcode[1] ), .C(\opcode[2] ), .Y(new_n81_));
  OA211x2_ASAP7_75t_R  g48(.A1(new_n53_), .A2(\opcode[2] ), .B(new_n51_), .C(new_n81_), .Y(\alu_op_ext[2] ));
  OA21x2_ASAP7_75t_R   g49(.A1(new_n38_), .A2(\opcode[1] ), .B(\opcode[3] ), .Y(new_n83_));
  OA21x2_ASAP7_75t_R   g50(.A1(\opcode[0] ), .A2(new_n42_), .B(new_n43_), .Y(new_n84_));
  OR3x1_ASAP7_75t_R    g51(.A(new_n84_), .B(\opcode[2] ), .C(new_n83_), .Y(new_n85_));
  AND2x2_ASAP7_75t_R   g52(.A(new_n85_), .B(new_n69_), .Y(\alu_op_ext[3] ));
  AND3x1_ASAP7_75t_R   g53(.A(new_n57_), .B(new_n59_), .C(new_n44_), .Y(halt));
  NOR2x1_ASAP7_75t_R   g54(.A(new_n38_), .B(new_n35_), .Y(new_n88_));
  OA21x2_ASAP7_75t_R   g55(.A1(new_n88_), .A2(\opcode[3] ), .B(new_n49_), .Y(new_n89_));
  AO21x1_ASAP7_75t_R   g56(.A1(new_n37_), .A2(\opcode[1] ), .B(\opcode[4] ), .Y(new_n90_));
  AO21x1_ASAP7_75t_R   g57(.A1(\opcode[2] ), .A2(new_n90_), .B(new_n89_), .Y(reg_write));
  AND3x1_ASAP7_75t_R   g58(.A(new_n57_), .B(\opcode[0] ), .C(\opcode[2] ), .Y(sel_pc_opA));
  AND3x1_ASAP7_75t_R   g59(.A(new_n57_), .B(new_n44_), .C(\opcode[2] ), .Y(sel_pc_opB));
  AND3x1_ASAP7_75t_R   g60(.A(new_n42_), .B(new_n38_), .C(\opcode[3] ), .Y(new_n94_));
  AND3x1_ASAP7_75t_R   g61(.A(new_n94_), .B(new_n44_), .C(\opcode[2] ), .Y(beqz));
  AND3x1_ASAP7_75t_R   g62(.A(new_n94_), .B(\opcode[0] ), .C(\opcode[2] ), .Y(bnez));
  AND3x1_ASAP7_75t_R   g63(.A(new_n38_), .B(\opcode[2] ), .C(\opcode[3] ), .Y(new_n97_));
  AND2x2_ASAP7_75t_R   g64(.A(new_n97_), .B(new_n73_), .Y(bgez));
  AND3x1_ASAP7_75t_R   g65(.A(new_n97_), .B(new_n44_), .C(\opcode[1] ), .Y(bltz));
  AND3x1_ASAP7_75t_R   g66(.A(new_n37_), .B(new_n38_), .C(\opcode[2] ), .Y(jump));
  OA21x2_ASAP7_75t_R   g67(.A1(new_n56_), .A2(new_n73_), .B(\opcode[2] ), .Y(new_n101_));
  INVx1_ASAP7_75t_R    g68(.A(new_n101_), .Y(new_n102_));
  OA211x2_ASAP7_75t_R  g69(.A1(new_n38_), .A2(\op_ext[0] ), .B(new_n73_), .C(\opcode[3] ), .Y(new_n103_));
  AO21x1_ASAP7_75t_R   g70(.A1(new_n94_), .A2(\opcode[0] ), .B(\opcode[2] ), .Y(new_n104_));
  OA21x2_ASAP7_75t_R   g71(.A1(new_n104_), .A2(new_n103_), .B(new_n102_), .Y(Cin));
  AND4x2_ASAP7_75t_R   g72(.A(new_n34_), .B(\opcode[1] ), .C(\op_ext[0] ), .D(new_n62_), .Y(new_n106_));
  OA211x2_ASAP7_75t_R  g73(.A1(new_n106_), .A2(new_n94_), .B(\opcode[0] ), .C(new_n49_), .Y(invA));
  OR3x1_ASAP7_75t_R    g74(.A(new_n65_), .B(new_n44_), .C(new_n42_), .Y(new_n108_));
  AOI21x1_ASAP7_75t_R  g75(.A1(new_n49_), .A2(new_n108_), .B(new_n101_), .Y(invB));
  OA211x2_ASAP7_75t_R  g76(.A1(new_n35_), .A2(new_n73_), .B(new_n43_), .C(new_n49_), .Y(mem_write));
  AND4x2_ASAP7_75t_R   g77(.A(new_n43_), .B(\opcode[0] ), .C(new_n42_), .D(new_n49_), .Y(sel_wb));
  assign               sign = 1'b1;
endmodule


