"""Finish deadline selections and incremental audits without altering raw runs."""
from pathlib import Path
import datetime,json,subprocess,sys,time
root=Path(__file__).resolve().parent;project=root.parent
sys.path.insert(0,str(project/'scripts/experiments'))
from timeout_selection import prepare
while True:
    for mode in ['cold','warm']:
        if (root/mode/'manifest.json').exists():prepare(root/mode)
        log=root/(mode+'_execution.log')
        if log.exists() and 'Traceback (most recent call last)' in log.read_text():raise RuntimeError(mode+' runner failed')
    q=subprocess.run([sys.executable,str(root/'check_progress.py')],cwd=project,capture_output=True,text=True)
    assert q.returncode==0,q.stdout+q.stderr
    print(datetime.datetime.now().astimezone().isoformat(),q.stdout.strip(),flush=True)
    ready=all(len(list((root/m/s).glob('*/row.tsv')))==n for m in ['cold','warm'] for s,n in [('tab_mfs3',32),('tab_main',32),('ablation',208)])
    if ready and all((root/m/'tab_mfs3/abc_results.json').exists() for m in ['cold','warm']):
        (root/'execution_complete.json').write_text(json.dumps(dict(complete=True,engine_rows=544,method_rows=512,at=datetime.datetime.now().astimezone().isoformat()),indent=2)+'\n')
        break
    time.sleep(30)
print('All three parts and both cache modes executed; full publication audit is now required.',flush=True)
