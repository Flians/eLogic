# Three-part constrained-area experiments

Every selected implementation satisfies its own initial area/delay bounds and has CEC evidence; native optimizer completions and deadline initial-netlist selections are counted separately.
ABC raw area-mode outputs are preserved. The guarded comparison reverts an infeasible completed output to its native initial mapping; it is an external output-selection policy, not an internal mfs3 timing constraint. ABC timeouts are excluded from the ABC-completed paired subset; our native timeout selections remain included as independently validated initial mappings.

{
  "whole_window_synthesis": false,
  "engine_cec_outputs": 164,
  "baseline_cec_outputs": 16,
  "main_own_area": -6.3570701694186855,
  "main_own_delay": -6.202957794056517,
  "main_one_area": -4.956580895609985,
  "main_one_delay": -4.371260236787843,
  "main_other_area": -2.787473140430207,
  "main_other_delay": -1.692648214447387,
  "main_area_wins": 9,
  "reference_area": -8.341798450405156,
  "reference_delay": -5.588344280838474,
  "reference_wins": 13,
  "mfs_ours_area": -5.338288414424468,
  "mfs_ours_delay": -5.209439009066429,
  "abc_completed": 13,
  "abc_timeouts": 3,
  "abc_feasible": 6,
  "abc_delay_violations": 7,
  "cut_oracle_times": {
    "secs_stage1": 112.63334634899999,
    "secs_stage2": 47.917740184,
    "secs_synth": 1838.4910758970002,
    "secs_egg": 293.980173331,
    "secs_care": 7.376044898000001,
    "secs_window": 0.0,
    "secs_chain": 0.055019575
  },
  "method_timeouts": 92,
  "selected_cec_outputs": 256,
  "phase_timed_full_runs": 9,
  "full_main_ppa_equal": {
    "aes_core": true,
    "arbiter": true,
    "div": true,
    "ethernet": true,
    "iwls05_i2c": true,
    "mem_ctrl": true,
    "RISC": true,
    "sasc": true,
    "simple_spi": true,
    "spi": true,
    "sqrt": true,
    "systemcaes": true,
    "systemcdes": true,
    "tv80": true,
    "usb_funct": true,
    "usb_phy": true
  },
  "cofactor_activity": {
    "aes_core": {
      "cofactor_wins": 0,
      "secs_cofactor": 0.0,
      "available": false
    },
    "arbiter": {
      "cofactor_wins": 0,
      "secs_cofactor": 59.49929218,
      "available": true
    },
    "div": {
      "cofactor_wins": 0,
      "secs_cofactor": 0.0,
      "available": false
    },
    "ethernet": {
      "cofactor_wins": 0,
      "secs_cofactor": 0.0,
      "available": false
    },
    "iwls05_i2c": {
      "cofactor_wins": 57,
      "secs_cofactor": 20.11193463,
      "available": true
    },
    "mem_ctrl": {
      "cofactor_wins": 0,
      "secs_cofactor": 0.0,
      "available": false
    },
    "RISC": {
      "cofactor_wins": 0,
      "secs_cofactor": 0.0,
      "available": false
    },
    "sasc": {
      "cofactor_wins": 62,
      "secs_cofactor": 4.120787315,
      "available": true
    },
    "simple_spi": {
      "cofactor_wins": 76,
      "secs_cofactor": 7.803798366,
      "available": true
    },
    "spi": {
      "cofactor_wins": 193,
      "secs_cofactor": 252.9931158,
      "available": true
    },
    "sqrt": {
      "cofactor_wins": 0,
      "secs_cofactor": 0.0,
      "available": false
    },
    "systemcaes": {
      "cofactor_wins": 1363,
      "secs_cofactor": 631.6162114,
      "available": true
    },
    "systemcdes": {
      "cofactor_wins": 129,
      "secs_cofactor": 142.5370863,
      "available": true
    },
    "tv80": {
      "cofactor_wins": 349,
      "secs_cofactor": 646.154705,
      "available": true
    },
    "usb_funct": {
      "cofactor_wins": 0,
      "secs_cofactor": 0.0,
      "available": false
    },
    "usb_phy": {
      "cofactor_wins": 29,
      "secs_cofactor": 4.745386586,
      "available": true
    }
  },
  "cofactor_seconds": 1759.0433031930002,
  "abc_raw_area": -3.575691302200082,
  "abc_guarded_area": -1.5940348664441888,
  "paired_ours_area": -6.570201125445499,
  "abc_raw_delay": 11.018744353868293,
  "abc_guarded_delay": -0.14558063949823968,
  "paired_ours_delay": -6.411617241927913,
  "paired_area_wins": 5,
  "guarded_paired_area_wins": 11,
  "ablation": {
    "full": {
      "area": 0.0,
      "worse": 0,
      "better": 0,
      "own_area": -6.3570701694186855,
      "own_delay": -6.202957794056517,
      "optimizer_seconds": 9390.140511065,
      "time_ratio": 1.0
    },
    "noSYN": {
      "area": 76.34999999999994,
      "worse": 9,
      "better": 5,
      "own_area": -3.887249049288666,
      "own_delay": -5.550897612375254,
      "optimizer_seconds": 4226.313281631001,
      "time_ratio": 0.4500798765099273
    },
    "noEGG": {
      "area": -24.970000000000084,
      "worse": 4,
      "better": 1,
      "own_area": -6.5614425446491,
      "own_delay": -6.233923396978323,
      "optimizer_seconds": 9068.471496023001,
      "time_ratio": 0.9657439614814118
    },
    "noDB": {
      "area": -23.360000000000134,
      "worse": 3,
      "better": 4,
      "own_area": -6.583380231219225,
      "own_delay": -6.15970646565018,
      "optimizer_seconds": 8293.041097559,
      "time_ratio": 0.8831647500680936
    },
    "noCARE": {
      "area": 2.539999999999999,
      "worse": 6,
      "better": 1,
      "own_area": -6.31171923964282,
      "own_delay": -6.022890671055698,
      "optimizer_seconds": 9302.1298928,
      "time_ratio": 0.9906273374545044
    },
    "noCHAIN": {
      "area": 334.08000000000004,
      "worse": 1,
      "better": 0,
      "own_area": -2.613256069153319,
      "own_delay": -1.5868577010444251,
      "optimizer_seconds": 9351.714599803001,
      "time_ratio": 0.9959078449127872
    },
    "noSHARE": {
      "area": 334.08000000000004,
      "worse": 1,
      "better": 0,
      "own_area": -2.613256069153319,
      "own_delay": -1.5868577010444251,
      "optimizer_seconds": 9354.172877141998,
      "time_ratio": 0.9961696383690299
    },
    "noNARROW": {
      "area": 0.009999999999990905,
      "worse": 1,
      "better": 0,
      "own_area": -6.356940970452277,
      "own_delay": -6.202957794056517,
      "optimizer_seconds": 9583.224971006,
      "time_ratio": 1.0205624675917764
    },
    "noPHASE": {
      "area": 54.78999999999999,
      "worse": 8,
      "better": 1,
      "own_area": -4.517315363389163,
      "own_delay": -5.650528461162872,
      "optimizer_seconds": 8955.202670039002,
      "time_ratio": 0.9536814342113962
    },
    "noSHANNON": {
      "area": 4.999999999999936,
      "worse": 8,
      "better": 1,
      "own_area": -5.554487349564964,
      "own_delay": -6.361674600666689,
      "optimizer_seconds": 8633.458704834,
      "time_ratio": 0.9194174138992539
    },
    "noDAVIO": {
      "area": -12.039999999999903,
      "worse": 7,
      "better": 3,
      "own_area": -5.773316810088235,
      "own_delay": -6.307189376657966,
      "optimizer_seconds": 7013.8087764580005,
      "time_ratio": 0.7469333145966436
    },
    "noREUSE": {
      "area": 52.549999999999976,
      "worse": 8,
      "better": 1,
      "own_area": -4.592517473085871,
      "own_delay": -6.133295120758008,
      "optimizer_seconds": 9130.89518636,
      "time_ratio": 0.9723917523492311
    },
    "noPRICE": {
      "area": 35.959999999999916,
      "worse": 8,
      "better": 1,
      "own_area": -5.1784446412611445,
      "own_delay": -5.650528461162872,
      "optimizer_seconds": 8720.634718767,
      "time_ratio": 0.9287011955242759
    }
  },
  "chain_activity": {
    "aes_core": {
      "chain_wins": 0,
      "secs_chain": 0.0,
      "available": false
    },
    "arbiter": {
      "chain_wins": 384,
      "secs_chain": 0.06495854,
      "available": true
    },
    "div": {
      "chain_wins": 0,
      "secs_chain": 0.0,
      "available": false
    },
    "ethernet": {
      "chain_wins": 0,
      "secs_chain": 0.0,
      "available": false
    },
    "iwls05_i2c": {
      "chain_wins": 0,
      "secs_chain": 0.0,
      "available": true
    },
    "mem_ctrl": {
      "chain_wins": 0,
      "secs_chain": 0.0,
      "available": false
    },
    "RISC": {
      "chain_wins": 0,
      "secs_chain": 0.0,
      "available": false
    },
    "sasc": {
      "chain_wins": 0,
      "secs_chain": 0.0,
      "available": true
    },
    "simple_spi": {
      "chain_wins": 0,
      "secs_chain": 0.0,
      "available": true
    },
    "spi": {
      "chain_wins": 0,
      "secs_chain": 0.0,
      "available": true
    },
    "sqrt": {
      "chain_wins": 0,
      "secs_chain": 0.0,
      "available": false
    },
    "systemcaes": {
      "chain_wins": 0,
      "secs_chain": 0.0,
      "available": true
    },
    "systemcdes": {
      "chain_wins": 0,
      "secs_chain": 0.0,
      "available": true
    },
    "tv80": {
      "chain_wins": 0,
      "secs_chain": 0.0,
      "available": true
    },
    "usb_funct": {
      "chain_wins": 0,
      "secs_chain": 0.0,
      "available": false
    },
    "usb_phy": {
      "chain_wins": 0,
      "secs_chain": 0.0,
      "available": true
    }
  }
}

## Per-design fully preprocessed results

| Design | A0 | D0 | A | D | dA % | dD % |
| --- | --- | --- | --- | --- | --- | --- |
| aes_core | 1029.98 | 410.72 | 1029.98 | 410.72 | +0.00 | +0.00 |
| arbiter | 557.72 | 999.87 | 223.64 | 261.39 | -59.90 | -73.86 |
| div | 1184.5 | 53105.06 | 1184.50 | 53105.06 | +0.00 | +0.00 |
| ethernet | 2541.41 | 543.88 | 2541.41 | 543.88 | +0.00 | +0.00 |
| iwls05_i2c | 47.66 | 303.61 | 45.08 | 290.02 | -5.41 | -4.48 |
| mem_ctrl | 1895.4 | 1519.75 | 1895.40 | 1519.75 | +0.00 | +0.00 |
| RISC | 2927.19 | 1453.77 | 2927.19 | 1453.77 | +0.00 | +0.00 |
| sasc | 27.28 | 191.2 | 26.74 | 191.2 | -1.98 | +0.00 |
| simple_spi | 36.96 | 308.22 | 35.89 | 293.36 | -2.90 | -4.82 |
| spi | 149.43 | 500.98 | 144.5 | 461.16 | -3.30 | -7.95 |
| sqrt | 1157.38 | 88015.07 | 1157.38 | 88015.07 | +0.00 | +0.00 |
| systemcaes | 483.75 | 709.03 | 425.74 | 683.44 | -11.99 | -3.61 |
| systemcdes | 131.06 | 488.85 | 121.32 | 487.52 | -7.43 | -0.27 |
| tv80 | 340.61 | 846.12 | 328.16 | 833.94 | -3.66 | -1.44 |
| usb_funct | 646.23 | 668.08 | 646.23 | 668.08 | +0.00 | +0.00 |
| usb_phy | 22.54 | 163.29 | 21.38 | 158.68 | -5.15 | -2.82 |
