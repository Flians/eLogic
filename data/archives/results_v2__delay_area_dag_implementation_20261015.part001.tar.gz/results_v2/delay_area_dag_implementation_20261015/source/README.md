# Fixed-required-time DAG area flow — isolated experimental version

Builds on the finite frontier version, in the same graph/pool/recovery deadline.
When explicitly enabled for delay-area, it replaces the third structural-ref
flow seed with a constrained topological area-flow sweep. The first two seeds
remain. Required times are propagated from a validated PO cover using dependent
pin delays. The repaired full witness supplies a physical topological order;
only already-driven inputs can be selected. Every finite required bound must
hold. Area-flow labels use observed physical references and are proxies.

A trial is committed only after pruning and actual whole-cover area/delay
validation shows objective improvement. Timeout, invalid full-witness overlay,
cycle or missing feasible candidate preserves the previous incumbent. The sweep
uses 35% of the remaining recovery window, not an additional budget. It is not
preemptive; the original strict global final check still rejects an overrun.
Every input/output binding comes from the unchanged retained pool. No additional
resyn2, original-node exemption, graph import or per-region allowance reset.

Release tests: 69 relevant tests passed, three existing ignored. New tests show
slack can reduce actual area without slowing the critical output, expired sweeps
produce no replacement, and later dependencies cannot introduce cycles. The
full-suite and repeat reports, not these small tests, determine promotion.
