//! Technology mapping directly on a saturated e-graph.
//!
//! Precise equalities stay in egg. SDC is a reachable-image check on a fixed boundary and only
//! admits external physical matches; it never unions conditionally equal expressions. CBC selects
//! instances and output bindings separately, paying once for a cell with any number of live pins.
use std::collections::{BTreeMap, BTreeSet, HashMap, HashSet};
use std::io::Write;
use std::time::Instant;

use coin_cbc::{Col, Model, Sense};
use egg::Language;
use egg::{Id, Runner};

use crate::aig_graph::Aig;
use crate::egraph_sat::{
    cheapest_nodes, cheapest_nodes_queued, import_aig, rules, AigLang, SatParams,
};
use crate::techlib::{Cell, Expr, TechLib};
use crate::tt9::tt9_from_u64;
#[path = "egraph_regions.rs"]
mod regions;

/// Whole-cover objective. Lexicographic modes never trade the primary metric
/// for the secondary metric; Weighted retains the legacy scalar objective.
#[derive(Clone, Copy, Debug, Default, Eq, PartialEq)]
pub enum MapObjective {
    #[default]
    Weighted,
    AreaDelay,
    DelayArea,
}

impl MapObjective {
    fn key(self, value: (f64, f64), weight: f64) -> (f64, f64) {
        match self {
            Self::AreaDelay => value,
            Self::DelayArea => (value.1, value.0),
            Self::Weighted => (
                if weight == 0.0 {
                    value.0
                } else {
                    value.0 + weight * value.1
                },
                value.1,
            ),
        }
    }
}

#[derive(Clone, Debug)]
pub struct MapParams {
    pub saturation: SatParams,
    pub max_inputs: usize,
    pub cuts_per_class: usize,
    pub cut_rounds: usize,
    /// Bound on optional physical candidates. Exact fallback candidates may exceed this budget.
    pub max_instances: usize,
    pub multioutput: bool,
    /// Also accumulate bounded boundary partners for three or more independent outputs.
    pub multioutput_cumulative: bool,
    /// Zero disables SDC. Exact PI-support enumeration is bounded by this many variables.
    pub dc_support: usize,
    pub dc_cone: usize,
    pub time_limit_secs: f64,
    pub delay_weight: f64,
    pub objective: MapObjective,
    pub max_delay: Option<f64>,
    pub refine_rounds: usize,
    pub refine_trials: usize,
    /// 0: original equalities, 1: OR factoring, 2: also associative alternatives (larger graphs).
    pub boolean_rules: u8,
    /// Explore faster equal-area flow choices; can change DAG sharing, so opt-in.
    pub flow_delay_ties: bool,
    /// Additional area-flow seed using the finite witness's physical fanouts.
    pub structural_refs: bool,
    /// Event-driven flow relaxation under the same recovery deadline; opt-in.
    pub flow_worklist: bool,
    /// Keep the normal incumbent, then try worklist recovery before the same deadline.
    pub flow_compare: bool,
    /// Rank local recovery by critical-path improvement before area; opt-in.
    pub critical_recovery: bool,
    /// Rank bounded optional cuts by earliest structural boundary depth; opt-in.
    pub cut_depth_priority: bool,
    /// Reserve this many optional slots for depth ranking, keeping the total cap.
    pub cut_depth_quota: usize,
    /// Exact-library timing cut ranking and bounded original-class reassociation; opt-in.
    pub library_timing: bool,
    /// Spend only remaining recovery time on required-time-aware area recovery.
    pub slack_flow: bool,
    /// Reserve an early required-time area-flow stage; independent opt-in.
    pub early_slack_flow: bool,
    /// Rank capped producers by witness input arrival and dependent pin delay.
    pub timing_cap: bool,
    /// Reject actual pool, node and recovery overruns; diagnostic opt-in.
    pub strict_budgets: bool,
    /// Global eclass regions for physical matching; zero preserves legacy ordering.
    pub region_classes: usize,
    /// Joint opposite-phase recovery under the existing shared recovery deadline.
    pub phase_recovery: bool,
    /// Maximum fraction of the remaining global recovery window for phase trials.
    pub phase_time_fraction: f64,
    pub recover_live_refs: bool,
    pub recover_cones: bool,
    /// Independent wall-clock budget for heuristic cover recovery, including warm starts.
    pub refine_time_secs: f64,
}

impl Default for MapParams {
    fn default() -> Self {
        Self {
            saturation: SatParams::default(),
            max_inputs: 6,
            cuts_per_class: 32,
            cut_rounds: 32,
            max_instances: 100_000,
            multioutput: true,
            multioutput_cumulative: true,
            dc_support: 0,
            dc_cone: 1024,
            time_limit_secs: 30.0,
            delay_weight: 0.0,
            objective: MapObjective::Weighted,
            max_delay: None,
            refine_rounds: 4,
            refine_trials: 2000,
            boolean_rules: 0,
            flow_delay_ties: false,
            structural_refs: false,
            flow_worklist: false,
            flow_compare: false,
            critical_recovery: false,
            cut_depth_priority: false,
            cut_depth_quota: 0,
            library_timing: false,
            slack_flow: false,
            early_slack_flow: false,
            timing_cap: false,
            strict_budgets: false,
            region_classes: 0,
            phase_recovery: false,
            phase_time_fraction: 1.0,
            recover_live_refs: true,
            recover_cones: true,
            refine_time_secs: 2.0,
        }
    }
}

/// A signal is `2 * dense_eclass + complemented_phase`.
#[derive(Clone, Debug)]
pub struct OutputPin {
    pub name: String,
    pub delays: Vec<f32>,
    /// Function of the *physical*, already phased inputs in Instance::inputs order.
    pub function: u64,
    pub targets: Vec<usize>,
}

impl OutputPin {
    fn has_arc(&self, input: usize) -> bool {
        (0..1usize << self.delays.len())
            .any(|a| ((self.function >> a) ^ (self.function >> (a ^ (1 << input)))) & 1 != 0)
    }
}

#[derive(Clone, Debug)]
pub struct Instance {
    pub cell: String,
    pub area: f32,
    pub inputs: Vec<usize>,
    pub input_pins: Vec<String>,
    pub outputs: Vec<OutputPin>,
}

#[derive(Clone, Copy, Debug)]
pub struct Binding {
    pub instance: usize,
    pub pin: usize,
}

#[derive(Clone, Debug, Default)]
pub struct MapStats {
    pub regions: usize,
    pub cross_region_boundaries: usize,
    pub phase_trials: usize,
    pub phase_accepted: usize,
    pub phase_secs: f64,
    pub saturation_budget_skips: usize,
    pub imported_enodes: usize,
    pub phase_initial_delay: f64,
    pub phase_final_delay: f64,
    pub eclasses: usize,
    pub enodes: usize,
    pub cuts: usize,
    pub max_cuts_per_class: usize,
    pub instances: usize,
    pub generated_instances: usize,
    pub instance_budget_pruned: usize,
    pub bindings: usize,
    pub dc_boundaries: usize,
    pub dc_with_unreachable: usize,
    pub dc_skipped: usize,
    pub dc_bindings: usize,
    pub cut_limit_hit: bool,
    /// Final-round optional boundaries replacing the legacy ranking on the same pool.
    pub cut_depth_swaps: usize,
    pub instance_limit_hit: bool,
    pub selected_multioutput: usize,
    pub selected_joint_multioutput: usize,
    pub used_fallback: bool,
    /// Optimal only within the bounded generated candidate set.
    pub proven_optimal: bool,
    pub solver_status: String,
    pub saturation_stop: String,
    pub build_secs: f64,
    pub solve_secs: f64,
    pub initial_area: f64,
    pub initial_delay: f64,
    /// Fastest complete seed seen, not a lower bound or optimality certificate.
    pub seed_delay: f64,
    pub heuristic_area: f64,
    pub heuristic_secs: f64,
    pub refinement_trials: usize,
    pub flow_compare_attempted: bool,
    pub flow_compare_accepted: bool,
    pub refinement_accepted: usize,
    pub slack_attempts: usize,
    pub slack_valid: usize,
    pub slack_accepted: usize,
    pub slack_local_scored: usize,
    pub slack_local_trials: usize,
    pub slack_local_accepted: usize,
}

pub struct MappedGraph {
    pub instances: Vec<Instance>,
    pub chosen: Vec<Option<Binding>>,
    pub inputs: Vec<(usize, u32, String)>,
    pub outputs: Vec<(usize, String)>,
    pub constants: Vec<Option<bool>>,
    pub area: f64,
    pub delay: f64,
    pub stats: MapStats,
}

#[derive(Clone, Debug, Eq, PartialEq, Ord, PartialOrd, Hash)]
struct Cut {
    leaves: Vec<usize>,
    function: u64,
}

fn mask(k: usize) -> u64 {
    if k == 6 {
        u64::MAX
    } else {
        (1u64 << (1usize << k)) - 1
    }
}

fn expand(function: u64, from: &[usize], to: &[usize]) -> u64 {
    let positions: Vec<_> = from.iter().map(|x| to.binary_search(x).unwrap()).collect();
    let mut result = 0;
    for a in 0..1usize << to.len() {
        let old = positions
            .iter()
            .enumerate()
            .fold(0, |v, (i, p)| v | (((a >> p) & 1) << i));
        result |= ((function >> old) & 1) << a;
    }
    result
}

fn reduce(mut cut: Cut) -> Cut {
    let k = cut.leaves.len();
    let essential: Vec<_> = (0..k)
        .filter(|&i| {
            (0..1usize << k)
                .any(|a| ((cut.function >> a) ^ (cut.function >> (a ^ (1 << i)))) & 1 != 0)
        })
        .collect();
    if essential.len() < k {
        let mut tt = 0;
        for a in 0..1usize << essential.len() {
            let old = essential
                .iter()
                .enumerate()
                .fold(0, |v, (i, p)| v | (((a >> i) & 1) << p));
            tt |= ((cut.function >> old) & 1) << a;
        }
        cut.leaves = essential.iter().map(|&i| cut.leaves[i]).collect();
        cut.function = tt;
    }
    cut
}

// Optional is ordered by the legacy key. Keep budget-quota of those cuts,
// then fill only the remaining slots in depth order. Overlap never wastes slots.
fn mixed_optional_cuts(
    optional: &[Cut],
    depth: &[usize],
    budget: usize,
    quota: usize,
) -> BTreeSet<Cut> {
    let mut selected: BTreeSet<_> = optional
        .iter()
        .take(budget.saturating_sub(quota.min(budget)))
        .cloned()
        .collect();
    if quota == 0 {
        return selected;
    }
    let mut ranked: Vec<_> = optional.iter().enumerate().collect();
    ranked.sort_by_key(|(rank, cut)| {
        (
            cut.leaves
                .iter()
                .map(|&leaf| depth[leaf])
                .max()
                .unwrap_or(0),
            *rank,
        )
    });
    for (_, cut) in ranked {
        if selected.len() >= budget {
            break;
        }
        selected.insert(cut.clone());
    }
    selected
}

struct BoundedAssociativity {
    original_classes: usize,
    nodes: usize,
    per_class: usize,
}
impl egg::Applier<AigLang, ()> for BoundedAssociativity {
    fn apply_one(
        &self,
        graph: &mut egg::EGraph<AigLang, ()>,
        eclass: Id,
        subst: &egg::Subst,
        _ast: Option<&egg::PatternAst<AigLang>>,
        _rule: egg::Symbol,
    ) -> Vec<Id> {
        if usize::from(eclass) >= self.original_classes
            || graph[eclass].nodes.len() >= self.per_class
            || graph.total_size().saturating_add(2) > self.nodes
        {
            return Vec::new();
        }
        let a = subst["?a".parse().unwrap()];
        let b = subst["?b".parse().unwrap()];
        let c = subst["?c".parse().unwrap()];
        let bc = graph.add(AigLang::And([b, c]));
        let root = graph.add(AigLang::And([a, bc]));
        if graph.union(eclass, root) {
            vec![eclass]
        } else {
            Vec::new()
        }
    }
}

fn enumerate(
    nodes: &[Vec<AigLang>],
    ids: &HashMap<Id, usize>,
    graph: &egg::EGraph<AigLang, ()>,
    tech: &TechLib,
    ps: &MapParams,
    stats: &mut MapStats,
) -> Vec<BTreeSet<Cut>> {
    let index = |id: Id| ids[&graph.find(id)];
    let mut cuts: Vec<BTreeSet<Cut>> = (0..nodes.len())
        .map(|c| {
            BTreeSet::from([Cut {
                leaves: vec![c],
                function: 2,
            }])
        })
        .collect();
    // Always retain local enode realizations, even when the optional cut/round budget is tiny.
    for (c, enodes) in nodes.iter().enumerate() {
        for node in enodes {
            let cut = match node {
                AigLang::Zero => Cut {
                    leaves: vec![],
                    function: 0,
                },
                AigLang::One => Cut {
                    leaves: vec![],
                    function: 1,
                },
                AigLang::Not(a) => Cut {
                    leaves: vec![index(*a)],
                    function: 1,
                },
                AigLang::And([a, b]) => {
                    let leaves: Vec<_> = [index(*a), index(*b)]
                        .into_iter()
                        .collect::<BTreeSet<_>>()
                        .into_iter()
                        .collect();
                    Cut {
                        function: if leaves.len() == 1 { 2 } else { 8 },
                        leaves,
                    }
                }
                _ => continue,
            };
            if !cut.leaves.contains(&c) {
                cuts[c].insert(cut);
            }
        }
    }
    let mandatory = cuts.clone();
    let is_primary: Vec<_> = nodes
        .iter()
        .map(|ns| {
            ns.iter()
                .any(|n| matches!(n, AigLang::Pi(_) | AigLang::Zero | AigLang::One))
        })
        .collect();
    // Structural depth is a ranking heuristic, not a technology-delay bound.
    // Only finite enode witnesses participate; exact structural cuts stay mandatory.
    let mut boundary_depth = vec![usize::MAX; nodes.len()];
    if ps.cut_depth_priority
        || ps.cut_depth_quota > 0
        || (ps.library_timing && ps.objective == MapObjective::DelayArea)
    {
        for _ in 0..nodes.len() {
            let mut changed = false;
            for (c, enodes) in nodes.iter().enumerate() {
                for node in enodes {
                    let d = match node {
                        AigLang::Pi(_) | AigLang::Zero | AigLang::One => 0,
                        AigLang::Not(a) => boundary_depth[index(*a)].saturating_add(1),
                        AigLang::And([a, b]) => boundary_depth[index(*a)]
                            .max(boundary_depth[index(*b)])
                            .saturating_add(1),
                        _ => usize::MAX,
                    };
                    if d < boundary_depth[c] {
                        boundary_depth[c] = d;
                        changed = true;
                    }
                }
            }
            if !changed {
                break;
            }
        }
    }
    let mut stable = false;
    for _ in 0..ps.cut_rounds {
        let old = cuts.clone();
        let mut changed = false;
        stats.cut_depth_swaps = 0;
        for (c, enodes) in nodes.iter().enumerate() {
            let mut pending = BTreeSet::new();
            for node in enodes {
                match node {
                    AigLang::Zero => {
                        pending.insert(Cut {
                            leaves: vec![],
                            function: 0,
                        });
                    }
                    AigLang::One => {
                        pending.insert(Cut {
                            leaves: vec![],
                            function: 1,
                        });
                    }
                    AigLang::Not(a) => {
                        for cut in &old[index(*a)] {
                            pending.insert(Cut {
                                leaves: cut.leaves.clone(),
                                function: cut.function ^ mask(cut.leaves.len()),
                            });
                        }
                    }
                    AigLang::And([a, b]) => {
                        for x in &old[index(*a)] {
                            for y in &old[index(*b)] {
                                let leaves: Vec<_> = x
                                    .leaves
                                    .iter()
                                    .chain(&y.leaves)
                                    .copied()
                                    .collect::<BTreeSet<_>>()
                                    .into_iter()
                                    .collect();
                                if leaves.len() <= ps.max_inputs {
                                    let tt = expand(x.function, &x.leaves, &leaves)
                                        & expand(y.function, &y.leaves, &leaves);
                                    pending.insert(reduce(Cut {
                                        leaves,
                                        function: tt,
                                    }));
                                }
                            }
                        }
                    }
                    _ => {}
                }
            }
            // Reserving structural cuts guarantees a finite fallback. Rank optional cuts by a
            // fixed key so newly discovered PI boundaries can displace early shallow internal cuts.
            pending.extend(cuts[c].iter().cloned());
            let mut optional: Vec<_> = pending
                .into_iter()
                .filter(|cut| !cut.leaves.contains(&c) && !mandatory[c].contains(cut))
                .collect();
            let budget = ps.cuts_per_class.saturating_sub(mandatory[c].len());
            stats.cut_limit_hit |= optional.len() > budget;
            let legacy_key = |cut: &Cut| {
                let internal = cut.leaves.iter().filter(|&&leaf| !is_primary[leaf]).count();
                (
                    cut.leaves.len() + internal,
                    internal,
                    cut.leaves.len(),
                    cut.clone(),
                )
            };
            optional.sort_by_key(&legacy_key);
            let legacy: BTreeSet<_> = optional.iter().take(budget).cloned().collect();
            let mut next = mandatory[c].clone();
            let quota = if ps.cut_depth_priority {
                budget
            } else {
                ps.cut_depth_quota.min(budget)
            };
            let selected = if ps.library_timing && ps.objective == MapObjective::DelayArea {
                let unit = tech.and2_delay.iter().copied().fold(0.0, f32::max) as f64;
                let score = |cut: &Cut| {
                    let k = cut.leaves.len();
                    if k == 0 {
                        return 0.0;
                    }
                    (0..2)
                        .flat_map(|phase| {
                            tech.candidates(
                                k as u8,
                                tt9_from_u64(cut.function ^ if phase == 1 { mask(k) } else { 0 }),
                            )
                            .into_iter()
                            .flatten()
                            .filter(|v| !v.out_neg)
                        })
                        .map(|v| {
                            cut.leaves
                                .iter()
                                .enumerate()
                                .map(|(p, &leaf)| {
                                    boundary_depth[leaf] as f64 * unit
                                        + f64::from(v.pin_delay[p])
                                        + if v.neg_mask & (1 << p) != 0 {
                                            f64::from(tech.inv_delay)
                                        } else {
                                            0.0
                                        }
                                })
                                .fold(0.0, f64::max)
                        })
                        .fold(f64::INFINITY, f64::min)
                };
                optional.sort_by(|a, b| {
                    score(a)
                        .total_cmp(&score(b))
                        .then(legacy_key(a).cmp(&legacy_key(b)))
                });
                optional.iter().take(budget).cloned().collect()
            } else {
                mixed_optional_cuts(&optional, &boundary_depth, budget, quota)
            };
            stats.cut_depth_swaps += selected.difference(&legacy).count();
            next.extend(selected);
            changed |= next != cuts[c];
            cuts[c] = next;
        }
        if !changed {
            stable = true;
            break;
        }
    }
    stats.cut_limit_hit |= !stable;
    stats.cuts = cuts.iter().map(BTreeSet::len).sum();
    cuts
}

/// Finite representatives are used only to prove boundary reachability, never to choose the cover.
struct Reachability {
    nodes: Vec<AigLang>,
    ids: HashMap<Id, usize>,
    cache: HashMap<Vec<usize>, Option<u64>>,
}

impl Reachability {
    fn care(&mut self, leaves: &[usize], ps: &MapParams, stats: &mut MapStats) -> u64 {
        let full = mask(leaves.len());
        if ps.dc_support == 0 {
            return full;
        }
        if let Some(care) = self.cache.get(leaves) {
            return care.unwrap_or(full);
        }
        let mut cone = BTreeSet::new();
        let mut vars = BTreeSet::new();
        let mut stack = leaves.to_vec();
        while let Some(c) = stack.pop() {
            if !cone.insert(c) {
                continue;
            }
            match self.nodes[c] {
                AigLang::Pi(v) => {
                    vars.insert(v);
                }
                AigLang::Not(a) => stack.push(self.ids[&a]),
                AigLang::And([a, b]) => {
                    stack.push(self.ids[&a]);
                    stack.push(self.ids[&b]);
                }
                _ => {}
            }
            if cone.len() > ps.dc_cone || vars.len() > ps.dc_support {
                self.cache.insert(leaves.to_vec(), None);
                stats.dc_skipped += 1;
                return full;
            }
        }
        let vars: Vec<_> = vars.into_iter().collect();
        let mut care = 0;
        for assignment in 0..1usize << vars.len() {
            let mut memo = vec![None; self.nodes.len()];
            let mut tuple = 0;
            for (i, &c) in leaves.iter().enumerate() {
                tuple |= usize::from(self.eval(c, &vars, assignment, &mut memo)) << i;
            }
            care |= 1u64 << tuple;
            if care == full {
                break;
            }
        }
        stats.dc_boundaries += 1;
        stats.dc_with_unreachable += usize::from(care != full);
        self.cache.insert(leaves.to_vec(), Some(care));
        care
    }

    fn eval(&self, c: usize, vars: &[u32], a: usize, memo: &mut [Option<bool>]) -> bool {
        if let Some(v) = memo[c] {
            return v;
        }
        let v = match self.nodes[c] {
            AigLang::Zero => false,
            AigLang::One => true,
            AigLang::Pi(v) => (a >> vars.binary_search(&v).unwrap()) & 1 != 0,
            AigLang::Not(x) => !self.eval(self.ids[&x], vars, a, memo),
            AigLang::And([x, y]) => {
                self.eval(self.ids[&x], vars, a, memo) & self.eval(self.ids[&y], vars, a, memo)
            }
            AigLang::Cell(_, _) => unreachable!("precise logical saturation contains no cells"),
        };
        memo[c] = Some(v);
        v
    }
}

fn permutations(n: usize) -> Vec<Vec<usize>> {
    fn visit(n: usize, p: &mut Vec<usize>, out: &mut Vec<Vec<usize>>) {
        if p.len() == n {
            out.push(p.clone());
            return;
        }
        for i in 0..n {
            if !p.contains(&i) {
                p.push(i);
                visit(n, p, out);
                p.pop();
            }
        }
    }
    let mut out = Vec::new();
    visit(n, &mut Vec::new(), &mut out);
    out
}

fn physical_function(cell: &Cell, pins: &[String]) -> u64 {
    let positions: Vec<_> = cell
        .vars
        .iter()
        .map(|p| pins.iter().position(|x| x == p).unwrap())
        .collect();
    let mut tt = 0;
    for a in 0..1usize << pins.len() {
        let original = positions
            .iter()
            .enumerate()
            .fold(0, |v, (i, p)| v | (((a >> p) & 1) << i));
        tt |= ((cell.tt[0] >> original) & 1) << a;
    }
    tt
}

fn input_phase(tt: u64, n: usize, phase: usize) -> u64 {
    let mut out = 0;
    for a in 0..1usize << n {
        out |= ((tt >> (a ^ phase)) & 1) << a;
    }
    out
}

fn subsets(n: usize, k: usize) -> Vec<Vec<usize>> {
    (0..1usize << n)
        .filter(|bits| bits.count_ones() as usize == k)
        .map(|bits| (0..n).filter(|i| bits & (1 << i) != 0).collect())
        .collect()
}

type InstanceKey = (String, Vec<usize>, Vec<(String, u64, Vec<u32>)>);

fn instance_key(instance: &Instance) -> InstanceKey {
    let mut order: Vec<_> = (0..instance.inputs.len()).collect();
    order.sort_by_key(|&i| instance.inputs[i]);
    let inputs = order.iter().map(|&i| instance.inputs[i]).collect();
    let outputs = instance
        .outputs
        .iter()
        .map(|o| {
            let mut function = 0;
            for a in 0..1usize << order.len() {
                let old = order
                    .iter()
                    .enumerate()
                    .fold(0, |v, (i, p)| v | (((a >> i) & 1) << p));
                function |= ((o.function >> old) & 1) << a;
            }
            let delays = order.iter().map(|&i| o.delays[i].to_bits()).collect();
            (o.name.clone(), function, delays)
        })
        .collect();
    (instance.cell.clone(), inputs, outputs)
}

fn insert_instance(
    instances: &mut Vec<Instance>,
    index: &mut HashMap<InstanceKey, usize>,
    mut instance: Instance,
) {
    // Collapse pin symmetries only when every output function AND timing arc is preserved.
    let key = instance_key(&instance);
    if let Some(&old) = index.get(&key) {
        for (output, new) in instances[old].outputs.iter_mut().zip(&mut instance.outputs) {
            output.targets.extend(new.targets.iter().copied());
            output.targets.sort_unstable();
            output.targets.dedup();
        }
    } else {
        index.insert(key, instances.len());
        instances.push(instance);
    }
}

#[derive(Clone, Copy)]
struct Target {
    signal: usize,
    function: u64,
}

fn targets_for(tt: u64, targets: &[Target], care: u64, stats: &mut MapStats) -> Vec<usize> {
    targets
        .iter()
        .filter_map(|target| {
            if (tt ^ target.function) & care == 0 {
                stats.dc_bindings += usize::from(tt != target.function);
                Some(target.signal)
            } else {
                None
            }
        })
        .collect::<BTreeSet<_>>()
        .into_iter()
        .collect()
}

fn generate(
    cuts: &[BTreeSet<Cut>],
    free: &[bool],
    constants: &[Option<bool>],
    tech: &TechLib,
    ps: &MapParams,
    reach: &mut Reachability,
    stats: &mut MapStats,
) -> Vec<Instance> {
    let mut boundaries: BTreeMap<Vec<usize>, Vec<Target>> = BTreeMap::new();
    for (c, alternatives) in cuts.iter().enumerate() {
        for cut in alternatives {
            if cut.leaves == [c] {
                continue;
            }
            for phase in 0..2 {
                let s = c * 2 + phase;
                if free[s] {
                    continue;
                }
                boundaries
                    .entry(cut.leaves.clone())
                    .or_default()
                    .push(Target {
                        signal: s,
                        function: cut.function
                            ^ if phase == 1 {
                                mask(cut.leaves.len())
                            } else {
                                0
                            },
                    });
            }
        }
    }
    let mut groups: BTreeMap<&str, Vec<&Cell>> = BTreeMap::new();
    for cell in &tech.cells {
        groups.entry(&cell.name).or_default().push(cell);
    }
    let multi_names: HashSet<_> = groups
        .iter()
        .filter(|(_, cells)| cells.len() > 1)
        .map(|(&name, _)| name)
        .collect();
    // Boundary unions let outputs with different supports share a complete physical pin set.
    if ps.multioutput && !multi_names.is_empty() {
        let union_limit = groups
            .values()
            .filter(|cells| cells.len() > 1)
            .map(|cells| {
                cells
                    .iter()
                    .flat_map(|c| &c.vars)
                    .collect::<HashSet<_>>()
                    .len()
            })
            .max()
            .unwrap_or(0)
            .min(ps.max_inputs);
        let originals: Vec<_> = boundaries
            .keys()
            .filter(|b| !b.is_empty())
            .cloned()
            .collect();
        let mut by_leaf: HashMap<usize, Vec<usize>> = HashMap::new();
        for (i, b) in originals.iter().enumerate() {
            for &leaf in b {
                let bucket = by_leaf.entry(leaf).or_default();
                if bucket.len() < 64 {
                    bucket.push(i);
                }
            }
        }
        let mut unions = BTreeSet::new();
        for (i, b) in originals.iter().enumerate() {
            // Shared-leaf pairing alone misses cells whose output supports are disjoint.
            // A bounded neighboring-boundary window adds such candidates without quadratic
            // enumeration. This is deliberately incomplete under a candidate budget.
            let shared = b
                .iter()
                .flat_map(|l| by_leaf[l].iter().copied())
                .collect::<BTreeSet<_>>()
                .into_iter()
                .take(16);
            let neighbors = (i + 1..originals.len().min(i + 17)).into_iter();
            let partners: BTreeSet<_> = shared.chain(neighbors).collect();
            let mut accumulated = b.clone();
            for partner in partners {
                let union: Vec<_> = b
                    .iter()
                    .chain(&originals[partner])
                    .copied()
                    .collect::<BTreeSet<_>>()
                    .into_iter()
                    .collect();
                if union.len() <= union_limit && !boundaries.contains_key(&union) {
                    unions.insert(union);
                }
                // Pairwise unions cannot cover three or more independent output supports.
                // Also accumulate the same bounded partner window, retaining intermediate
                // boundaries. Oversized partners are skipped, not allowed to poison the prefix.
                let combined: Vec<_> = accumulated
                    .iter()
                    .chain(&originals[partner])
                    .copied()
                    .collect::<BTreeSet<_>>()
                    .into_iter()
                    .collect();
                if ps.multioutput_cumulative
                    && combined.len() <= union_limit
                    && combined != accumulated
                {
                    accumulated = combined;
                    if !boundaries.contains_key(&accumulated) {
                        unions.insert(accumulated.clone());
                    }
                }
            }
            if unions.len() >= ps.max_instances {
                break;
            }
        }
        for b in unions {
            boundaries.entry(b).or_default();
        }
        let source = boundaries.clone();
        for (boundary, targets) in &mut boundaries {
            for subset in 0..1usize << boundary.len() {
                let small: Vec<_> = boundary
                    .iter()
                    .enumerate()
                    .filter(|(i, _)| subset & (1 << i) != 0)
                    .map(|(_, &c)| c)
                    .collect();
                if small == *boundary {
                    continue;
                }
                if let Some(existing) = source.get(&small) {
                    targets.extend(
                        existing
                            .iter()
                            .filter(|t| !boundary.contains(&(t.signal / 2)))
                            .map(|t| Target {
                                signal: t.signal,
                                function: expand(t.function, &small, boundary),
                            }),
                    );
                }
            }
        }
    }
    let ordered_boundaries =
        regions::ordered_boundaries(&boundaries, cuts.len(), ps.region_classes, stats);
    let mut instances = Vec::new();
    // Baseline cells first. Optional DC/multi-output variants cannot exhaust the fallback budget.
    for &(boundary, targets) in &ordered_boundaries {
        let k = boundary.len();
        if k == 0 {
            continue;
        }
        let mut seen = HashSet::new();
        for target in targets {
            if let Some(variants) = tech.candidates(k as u8, tt9_from_u64(target.function)) {
                for v in variants {
                    if v.out_neg || multi_names.contains(v.cell_name.as_str()) {
                        continue;
                    }
                    let key = (v.cell_name.clone(), v.pin_names.clone(), v.neg_mask);
                    if !seen.insert(key) {
                        continue;
                    }
                    let cell = tech
                        .cells
                        .iter()
                        .find(|c| c.name == v.cell_name && c.out_pin == v.out_pin)
                        .unwrap();
                    let physical = physical_function(cell, &v.pin_names);
                    let actual = input_phase(physical, k, usize::from(v.neg_mask));
                    let inputs: Vec<_> = boundary
                        .iter()
                        .enumerate()
                        .map(|(i, c)| c * 2 + usize::from((v.neg_mask >> i) & 1))
                        .collect();
                    let matched: Vec<_> = targets
                        .iter()
                        .filter(|t| t.function == actual && !inputs.contains(&t.signal))
                        .map(|t| t.signal)
                        .collect::<BTreeSet<_>>()
                        .into_iter()
                        .collect();
                    if !matched.is_empty() {
                        instances.push(Instance {
                            cell: v.cell_name.clone(),
                            area: v.area,
                            inputs,
                            input_pins: v.pin_names.clone(),
                            outputs: vec![OutputPin {
                                name: v.out_pin.clone(),
                                delays: v.pin_delay.clone(),
                                function: physical,
                                targets: matched,
                            }],
                        });
                    }
                }
            }
        }
    }
    if let Some(inv) = &tech.inv_variant {
        for c in 0..cuts.len() {
            for phase in 0..2 {
                if free[c * 2 + phase] {
                    continue;
                }
                instances.push(Instance {
                    cell: inv.cell_name.clone(),
                    area: inv.area,
                    inputs: vec![c * 2 + (1 - phase)],
                    input_pins: inv.pin_names.clone(),
                    outputs: vec![OutputPin {
                        name: inv.out_pin.clone(),
                        delays: inv.pin_delay.clone(),
                        function: 1,
                        targets: vec![c * 2 + phase],
                    }],
                });
            }
        }
    }
    // Cells with no inputs can realize a class whose precise expression is constant.
    for cell in tech
        .cells
        .iter()
        .filter(|c| c.vars.is_empty() && !multi_names.contains(c.name.as_str()))
    {
        let value = cell.tt[0] & 1 != 0;
        let targets = cuts
            .iter()
            .enumerate()
            .flat_map(|(c, cs)| {
                (0..2).filter_map(move |phase| {
                    if !free[c * 2 + phase]
                        && constants[c * 2 + phase].is_none()
                        && cs.iter().any(|cut| {
                            cut.leaves.is_empty()
                                && ((cut.function & 1 != 0) ^ (phase == 1)) == value
                        })
                    {
                        Some(c * 2 + phase)
                    } else {
                        None
                    }
                })
            })
            .collect();
        instances.push(Instance {
            cell: cell.name.clone(),
            area: cell.area,
            inputs: vec![],
            input_pins: vec![],
            outputs: vec![OutputPin {
                name: cell.out_pin.clone(),
                delays: vec![],
                function: u64::from(value),
                targets,
            }],
        });
    }
    let mut index = HashMap::new();
    let base = std::mem::take(&mut instances);
    for instance in base {
        insert_instance(&mut instances, &mut index, instance);
    }
    let base_count = instances.len();
    stats.instance_limit_hit |= base_count > ps.max_instances;
    for &(boundary, targets) in &ordered_boundaries {
        let k = boundary.len();
        if k == 0 {
            continue;
        }
        let care = reach.care(boundary, ps, stats);
        for (&name, cells) in &groups {
            let multi = cells.len() > 1;
            if (multi && !ps.multioutput) || (!multi && care == mask(k)) {
                continue;
            }
            let pins: Vec<_> = cells
                .iter()
                .flat_map(|c| c.vars.iter().cloned())
                .collect::<BTreeSet<_>>()
                .into_iter()
                .collect();
            let n = pins.len();
            if n > k {
                continue;
            }
            // Reject inconsistent descriptions rather than charging one of two different areas.
            if cells.iter().any(|c| (c.area - cells[0].area).abs() > 1e-6) {
                continue;
            }
            for selection in subsets(k, n) {
                let selected: Vec<_> = selection.iter().map(|&i| boundary[i]).collect();
                for perm in permutations(n) {
                    let input_pins: Vec<_> = perm.iter().map(|&i| pins[i].clone()).collect();
                    let physical: Vec<_> = cells
                        .iter()
                        .map(|c| physical_function(c, &input_pins))
                        .collect();
                    for phase in 0..1usize << n {
                        let inputs: Vec<_> = selected
                            .iter()
                            .enumerate()
                            .map(|(i, c)| c * 2 + ((phase >> i) & 1))
                            .collect();
                        let outputs: Vec<_> = cells
                            .iter()
                            .zip(&physical)
                            .map(|(cell, &function)| {
                                let actual =
                                    expand(input_phase(function, n, phase), &selected, boundary);
                                let mut matched = targets_for(actual, targets, care, stats);
                                matched.retain(|s| !inputs.contains(s));
                                OutputPin {
                                    name: cell.out_pin.clone(),
                                    function,
                                    targets: matched,
                                    delays: input_pins
                                        .iter()
                                        .map(|p| cell.pin_delay.get(p).copied().unwrap_or(0.0))
                                        .collect(),
                                }
                            })
                            .collect();
                        if outputs.iter().any(|o| !o.targets.is_empty()) {
                            let instance = Instance {
                                cell: name.into(),
                                area: cells[0].area,
                                inputs,
                                input_pins: input_pins.clone(),
                                outputs,
                            };
                            let key = instance_key(&instance);
                            if !index.contains_key(&key)
                                && instances.len() >= ps.max_instances.max(base_count)
                            {
                                stats.instance_limit_hit = true;
                                return instances;
                            }
                            insert_instance(&mut instances, &mut index, instance);
                        }
                    }
                }
            }
        }
    }
    instances
}

fn finite_choices(instances: &[Instance], free: &[bool]) -> Vec<Option<Binding>> {
    let mut available = free.to_vec();
    let mut chosen = vec![None; free.len()];
    let mut order: Vec<_> = (0..instances.len()).collect();
    order.sort_by(|&a, &b| instances[a].area.total_cmp(&instances[b].area));
    loop {
        let mut changed = false;
        for &i in &order {
            let m = &instances[i];
            if !m.inputs.iter().all(|&s| available[s]) {
                continue;
            }
            for (pin, output) in m.outputs.iter().enumerate() {
                for &s in &output.targets {
                    if !available[s] {
                        chosen[s] = Some(Binding { instance: i, pin });
                        available[s] = true;
                        changed = true;
                    }
                }
            }
        }
        if !changed {
            break;
        }
    }
    chosen
}

fn finite_choices_queued(instances: &[Instance], free: &[bool]) -> Vec<Option<Binding>> {
    let mut available = free.to_vec();
    let mut chosen = vec![None; free.len()];
    let mut order: Vec<_> = (0..instances.len()).collect();
    order.sort_by(|&a, &b| instances[a].area.total_cmp(&instances[b].area));
    let mut rank = vec![0; instances.len()];
    for (r, &i) in order.iter().enumerate() {
        rank[i] = r;
    }
    let mut users = vec![Vec::new(); free.len()];
    let mut remaining = vec![0; instances.len()];
    let mut current = BTreeSet::new();
    let mut next = BTreeSet::new();
    for (i, m) in instances.iter().enumerate() {
        for input in m.inputs.iter().copied().collect::<BTreeSet<_>>() {
            if !available[input] {
                users[input].push(i);
                remaining[i] += 1;
            }
        }
        if remaining[i] == 0 {
            current.insert(rank[i]);
        }
    }
    loop {
        while let Some(r) = current.pop_first() {
            let i = order[r];
            for (pin, output) in instances[i].outputs.iter().enumerate() {
                for &signal in &output.targets {
                    if available[signal] {
                        continue;
                    }
                    available[signal] = true;
                    chosen[signal] = Some(Binding { instance: i, pin });
                    for &consumer in &users[signal] {
                        remaining[consumer] -= 1;
                        if remaining[consumer] == 0 {
                            if rank[consumer] > r {
                                current.insert(rank[consumer]);
                            } else {
                                next.insert(rank[consumer]);
                            }
                        }
                    }
                }
            }
        }
        if next.is_empty() {
            break;
        }
        std::mem::swap(&mut current, &mut next);
    }
    chosen
}

#[cfg(test)]
fn fallback(
    instances: &[Instance],
    free: &[bool],
    roots: &[usize],
) -> Result<Vec<Option<Binding>>, String> {
    let mut chosen = finite_choices(instances, free);
    prune(instances, &mut chosen, free, roots)?;
    Ok(chosen)
}

fn fill_from_witness(
    instances: &[Instance],
    chosen: &mut [Option<Binding>],
    witness: &[Option<Binding>],
    free: &[bool],
    roots: &[usize],
) -> Result<(), String> {
    let mut seen = vec![false; free.len()];
    let mut stack = roots.to_vec();
    while let Some(s) = stack.pop() {
        if free[s] || seen[s] {
            continue;
        }
        seen[s] = true;
        let binding = chosen[s]
            .or(witness[s])
            .ok_or_else(|| format!("unrealizable dependency {s}"))?;
        chosen[s] = Some(binding);
        stack.extend(instances[binding.instance].inputs.iter().copied());
    }
    prune(instances, chosen, free, roots)
}

fn better_cover(candidate: (f64, f64), current: (f64, f64), ps: &MapParams) -> bool {
    let feasible = |delay| ps.max_delay.is_none_or(|limit| delay <= limit + 1e-6);
    match (feasible(candidate.1), feasible(current.1)) {
        (true, false) => true,
        (false, true) => false,
        (false, false) => candidate.1 < current.1 - 1e-6,
        (true, true) => {
            let a = ps.objective.key(candidate, ps.delay_weight);
            let b = ps.objective.key(current, ps.delay_weight);
            a.0 < b.0 - 1e-6 || ((a.0 - b.0).abs() <= 1e-6 && a.1 < b.1 - 1e-6)
        }
    }
}

/// Estimate reclaimable physical area when producers of the listed signals are replaced.
/// Shared inputs and other live pins keep their physical instance alive. Sparse counters avoid
/// copying the entire graph for every ranked proposal. New-input repair is evaluated separately.
fn reclaimable_area(
    targets: &[usize],
    instances: &[Instance],
    chosen: &[Option<Binding>],
    free: &[bool],
    signal_refs: &[usize],
    output_users: &[usize],
) -> f64 {
    let mut refs = HashMap::new();
    let mut users = HashMap::new();
    let mut released = HashSet::new();
    let mut pending = targets.to_vec();
    let mut area = 0.0;
    while let Some(s) = pending.pop() {
        if free[s] || !released.insert(s) {
            continue;
        }
        let Some(binding) = chosen[s] else { continue };
        let i = binding.instance;
        let count = users.entry(i).or_insert(output_users[i]);
        *count -= 1;
        if *count != 0 {
            continue;
        }
        area += f64::from(instances[i].area);
        for &input in instances[i].inputs.iter().collect::<BTreeSet<_>>() {
            let count = refs.entry(input).or_insert(signal_refs[input]);
            *count -= 1;
            if *count == 0 {
                pending.push(input);
            }
        }
    }
    area
}

/// Relax positive tree/flow costs over all e-class alternatives. Depth breaks zero-cost ties;
/// the resulting graph is validated before it can become either an incumbent or a repair witness.
fn flow_choices(
    instances: &[Instance],
    free: &[bool],
    refs: &[f64],
    weight: f64,
    divide_inputs: bool,
    delay_ties: bool,
    objective: MapObjective,
    deadline: Instant,
) -> (Vec<Option<Binding>>, Vec<f64>) {
    let mut costs = vec![f64::INFINITY; free.len()];
    let mut arrival = vec![f64::INFINITY; free.len()];
    let mut depth = vec![usize::MAX; free.len()];
    let mut chosen = vec![None; free.len()];
    for (s, &yes) in free.iter().enumerate() {
        if yes {
            costs[s] = 0.0;
            arrival[s] = 0.0;
            depth[s] = 0;
        }
    }
    for _ in 0..32 {
        let mut changed = false;
        for (i, m) in instances.iter().enumerate() {
            if !m.inputs.iter().all(|&s| costs[s].is_finite()) {
                continue;
            }
            let input_cost: f64 = m
                .inputs
                .iter()
                .copied()
                .collect::<BTreeSet<_>>()
                .into_iter()
                .map(|s| costs[s])
                .sum();
            let level = m
                .inputs
                .iter()
                .map(|&s| depth[s])
                .max()
                .unwrap_or(0)
                .saturating_add(1);
            for (pin, output) in m.outputs.iter().enumerate() {
                let time = m
                    .inputs
                    .iter()
                    .enumerate()
                    .filter(|(p, _)| output.has_arc(*p))
                    .map(|(p, &s)| arrival[s] + f64::from(output.delays[p]))
                    .fold(0.0, f64::max);
                for &s in &output.targets {
                    if free[s] || m.inputs.contains(&s) {
                        continue;
                    }
                    let area = if divide_inputs {
                        (f64::from(m.area) + input_cost) / refs[s]
                    } else {
                        f64::from(m.area) / refs[s] + input_cost
                    };
                    let score = area + weight * time;
                    let old = if weight == 0.0 {
                        costs[s]
                    } else {
                        costs[s] + weight * arrival[s]
                    };
                    // Equal area-flow covers still differ in arrival. Prefer the faster
                    // realization before depth, even in pure area mode; otherwise candidate
                    // insertion order can lock in a slower pin with exactly the same cost.
                    let tied = (score - old).abs() <= 1e-9;
                    let better_tie = if delay_ties {
                        time < arrival[s] - 1e-9
                            || ((time - arrival[s]).abs() <= 1e-9 && level < depth[s])
                    } else {
                        level < depth[s]
                    };
                    let prefer = if objective == MapObjective::Weighted {
                        score < old - 1e-9 || (tied && better_tie)
                    } else {
                        let a = objective.key((area, time), weight);
                        let b = objective.key((costs[s], arrival[s]), weight);
                        a.0 < b.0 - 1e-9
                            || ((a.0 - b.0).abs() <= 1e-9
                                && (a.1 < b.1 - 1e-9
                                    || ((a.1 - b.1).abs() <= 1e-9 && level < depth[s])))
                    };
                    if prefer {
                        costs[s] = area;
                        arrival[s] = time;
                        depth[s] = level;
                        chosen[s] = Some(Binding { instance: i, pin });
                        changed = true;
                    }
                }
            }
            if Instant::now() >= deadline {
                return (chosen, costs);
            }
        }
        if !changed {
            break;
        }
    }
    (chosen, costs)
}

fn flow_choices_worklist(
    instances: &[Instance],
    free: &[bool],
    refs: &[f64],
    weight: f64,
    divide_inputs: bool,
    delay_ties: bool,
    objective: MapObjective,
    deadline: Instant,
) -> (Vec<Option<Binding>>, Vec<f64>) {
    flow_choices_worklist_impl(
        instances,
        free,
        refs,
        weight,
        divide_inputs,
        delay_ties,
        objective,
        deadline,
        None,
        None,
    )
}

fn flow_choices_worklist_impl(
    instances: &[Instance],
    free: &[bool],
    refs: &[f64],
    weight: f64,
    divide_inputs: bool,
    delay_ties: bool,
    objective: MapObjective,
    deadline: Instant,
    required: Option<&[f64]>,
    seed: Option<&[Option<Binding>]>,
) -> (Vec<Option<Binding>>, Vec<f64>) {
    let mut costs = vec![f64::INFINITY; free.len()];
    let mut arrival = vec![f64::INFINITY; free.len()];
    let mut depth = vec![usize::MAX; free.len()];
    let mut chosen = vec![None; free.len()];
    for (s, &yes) in free.iter().enumerate() {
        if yes {
            costs[s] = 0.0;
            arrival[s] = 0.0;
            depth[s] = 0;
        }
    }
    if let Some(seed) = seed {
        fn init(
            s: usize,
            instances: &[Instance],
            free: &[bool],
            seed: &[Option<Binding>],
            refs: &[f64],
            costs: &mut [f64],
            arrival: &mut [f64],
            depth: &mut [usize],
        ) {
            if free[s] || costs[s].is_finite() {
                return;
            }
            let Some(b) = seed[s] else {
                return;
            };
            let m = &instances[b.instance];
            for &input in &m.inputs {
                init(input, instances, free, seed, refs, costs, arrival, depth);
            }
            costs[s] = (f64::from(m.area)
                + m.inputs
                    .iter()
                    .copied()
                    .collect::<BTreeSet<_>>()
                    .into_iter()
                    .map(|i| costs[i])
                    .sum::<f64>())
                / refs[s].max(1.0);
            arrival[s] = m
                .inputs
                .iter()
                .enumerate()
                .filter(|(p, _)| m.outputs[b.pin].has_arc(*p))
                .map(|(p, &i)| arrival[i] + f64::from(m.outputs[b.pin].delays[p]))
                .fold(0.0, f64::max);
            depth[s] = m
                .inputs
                .iter()
                .map(|&i| depth[i])
                .max()
                .unwrap_or(0)
                .saturating_add(1);
        }
        for s in 0..free.len() {
            init(
                s,
                instances,
                free,
                seed,
                refs,
                &mut costs,
                &mut arrival,
                &mut depth,
            );
        }
        chosen.clone_from_slice(seed);
    }
    // A changed signal wakes precisely its physical consumers. Unlike a fixed
    // number of full sweeps, this can settle arbitrarily deep finite cones.
    let mut consumers = vec![Vec::new(); free.len()];
    for (i, m) in instances.iter().enumerate() {
        for &input in &m.inputs {
            consumers[input].push(i);
        }
    }
    let mut queue: std::collections::VecDeque<_> = (0..instances.len()).collect();
    let mut pending = vec![true; instances.len()];
    while let Some(i) = queue.pop_front() {
        if Instant::now() >= deadline {
            break;
        }
        pending[i] = false;
        let m = &instances[i];
        if !m.inputs.iter().all(|&s| costs[s].is_finite()) {
            continue;
        }
        let input_cost: f64 = m
            .inputs
            .iter()
            .copied()
            .collect::<BTreeSet<_>>()
            .into_iter()
            .map(|s| costs[s])
            .sum();
        let level = m
            .inputs
            .iter()
            .map(|&s| depth[s])
            .max()
            .unwrap_or(0)
            .saturating_add(1);
        for (pin, output) in m.outputs.iter().enumerate() {
            let time = m
                .inputs
                .iter()
                .enumerate()
                .filter(|(p, _)| output.has_arc(*p))
                .map(|(p, &s)| arrival[s] + f64::from(output.delays[p]))
                .fold(0.0, f64::max);
            for &s in &output.targets {
                if free[s] || m.inputs.contains(&s) || required.is_some_and(|r| time > r[s] + 1e-6)
                {
                    continue;
                }
                let area = if divide_inputs {
                    (f64::from(m.area) + input_cost) / refs[s]
                } else {
                    f64::from(m.area) / refs[s] + input_cost
                };
                let score = area + weight * time;
                let old = if weight == 0.0 {
                    costs[s]
                } else {
                    costs[s] + weight * arrival[s]
                };
                // Equal area-flow covers still differ in arrival. Prefer the faster
                // realization before depth, even in pure area mode; otherwise candidate
                // insertion order can lock in a slower pin with exactly the same cost.
                let tied = (score - old).abs() <= 1e-9;
                let better_tie = if delay_ties {
                    time < arrival[s] - 1e-9
                        || ((time - arrival[s]).abs() <= 1e-9 && level < depth[s])
                } else {
                    level < depth[s]
                };
                let prefer = if objective == MapObjective::Weighted {
                    score < old - 1e-9 || (tied && better_tie)
                } else {
                    let a = objective.key((area, time), weight);
                    let b = objective.key((costs[s], arrival[s]), weight);
                    a.0 < b.0 - 1e-9
                        || ((a.0 - b.0).abs() <= 1e-9
                            && (a.1 < b.1 - 1e-9
                                || ((a.1 - b.1).abs() <= 1e-9 && level < depth[s])))
                };
                if prefer
                    && !(required.is_some()
                        && introduces_cycle(s, &m.inputs, &chosen, instances, free))
                {
                    costs[s] = area;
                    arrival[s] = time;
                    depth[s] = level;
                    chosen[s] = Some(Binding { instance: i, pin });
                    for &consumer in &consumers[s] {
                        if !pending[consumer] {
                            pending[consumer] = true;
                            queue.push_back(consumer);
                        }
                    }
                }
            }
        }
        if Instant::now() >= deadline {
            return (chosen, costs);
        }
    }
    (chosen, costs)
}

fn physical_refs(instances: &[Instance], chosen: &[Option<Binding>], roots: &[usize]) -> Vec<f64> {
    let mut refs = vec![0.0f64; chosen.len()];
    for &s in roots.iter().collect::<BTreeSet<_>>() {
        refs[s] += 1.0;
    }
    let live: BTreeSet<_> = chosen.iter().flatten().map(|b| b.instance).collect();
    for i in live {
        for &s in instances[i].inputs.iter().collect::<BTreeSet<_>>() {
            refs[s] += 1.0;
        }
    }
    for count in &mut refs {
        *count = count.max(1.0);
    }
    refs
}

fn heuristic_cover(
    instances: &[Instance],
    free: &[bool],
    roots: &[usize],
    ps: &MapParams,
    stats: &mut MapStats,
) -> Result<Vec<Option<Binding>>, String> {
    let start = Instant::now();
    let deadline = start + std::time::Duration::from_secs_f64(ps.refine_time_secs);
    // Reserve time within the original budget for final incumbent accounting.
    let search_deadline = if ps.strict_budgets {
        deadline - std::time::Duration::from_secs_f64(ps.refine_time_secs.min(0.05))
    } else {
        deadline
    };
    let mut chosen = heuristic_cover_until(instances, free, roots, ps, stats, search_deadline)?;
    if ps.flow_compare && !ps.flow_worklist && ps.refine_rounds > 0 && Instant::now() < deadline {
        stats.flow_compare_attempted = true;
        let mut alternative_params = ps.clone();
        alternative_params.flow_worklist = true;
        let mut alternative_stats = MapStats::default();
        if let Ok(alternative) = heuristic_cover_until(
            instances,
            free,
            roots,
            &alternative_params,
            &mut alternative_stats,
            deadline,
        ) {
            if better_cover(
                metrics(instances, &alternative, free, roots),
                metrics(instances, &chosen, free, roots),
                ps,
            ) {
                chosen = alternative;
                stats.flow_compare_accepted = true;
            }
        }
        stats.refinement_trials += alternative_stats.refinement_trials;
        stats.refinement_accepted += alternative_stats.refinement_accepted;
    }
    stats.heuristic_area = metrics(instances, &chosen, free, roots).0;
    stats.heuristic_secs = start.elapsed().as_secs_f64();
    if ps.strict_budgets && Instant::now() > deadline {
        return Err(format!(
            "budget: recovery {:.6}s exceeds {:.6}s including setup and final validation",
            stats.heuristic_secs, ps.refine_time_secs
        ));
    }
    Ok(chosen)
}

fn heuristic_cover_until(
    instances: &[Instance],
    free: &[bool],
    roots: &[usize],
    ps: &MapParams,
    stats: &mut MapStats,
    deadline: Instant,
) -> Result<Vec<Option<Binding>>, String> {
    let start = Instant::now();
    let mut witness = if ps.strict_budgets {
        finite_choices_queued(instances, free)
    } else {
        finite_choices(instances, free)
    };
    let mut chosen = witness.clone();
    prune(instances, &mut chosen, free, roots)?;
    let mut best = metrics(instances, &chosen, free, roots);
    stats.initial_area = best.0;
    stats.initial_delay = best.1;
    stats.seed_delay = best.1;
    if ps.refine_rounds == 0
        || ps.refine_time_secs == 0.0
        || (ps.strict_budgets && Instant::now() >= deadline)
    {
        stats.heuristic_area = best.0;
        stats.heuristic_secs = start.elapsed().as_secs_f64();
        return Ok(chosen);
    }
    let mut refs = vec![1.0; free.len()];
    let mut edges = HashSet::new();
    for m in instances {
        for output in &m.outputs {
            for &s in &output.targets {
                for &input in &m.inputs {
                    edges.insert((input, s));
                }
            }
        }
    }
    for (input, _) in edges {
        refs[input] += 1.0;
    }
    let mut tree_cost = vec![0.0; free.len()];
    let mut seeds = vec![(vec![1.0; free.len()], false), (refs, false)];
    if ps.structural_refs {
        seeds.push((physical_refs(instances, &chosen, roots), true));
    }
    for (divisor, divide_inputs) in seeds {
        if Instant::now() >= deadline {
            break;
        }
        let flow = if ps.flow_worklist {
            flow_choices_worklist
        } else {
            flow_choices
        };
        let (candidate, costs) = flow(
            instances,
            free,
            &divisor,
            if ps.objective == MapObjective::Weighted {
                ps.delay_weight
            } else {
                0.0
            },
            divide_inputs,
            ps.flow_delay_ties,
            // Area-flow ties can change physical sharing. Keep the legacy seed for
            // area-first; complete-cover acceptance still breaks area ties by delay.
            if ps.objective == MapObjective::AreaDelay {
                MapObjective::Weighted
            } else {
                ps.objective
            },
            deadline,
        );
        // A cycle in an unused alternative must not reject an otherwise valid PO cover.
        let mut cover = candidate.clone();
        if fill_from_witness(instances, &mut cover, &witness, free, roots).is_ok() {
            let value = metrics(instances, &cover, free, roots);
            stats.seed_delay = stats.seed_delay.min(value.1);
            if better_cover(value, best, ps) {
                chosen = cover;
                best = value;
            }
        }
        // The repair witness needs the stricter all-signal check because later replacements can
        // introduce dependencies outside the current PO cone. Keep the old witness if this fails.
        let mut full = witness.clone();
        for (s, b) in candidate.iter().enumerate() {
            if b.is_some() {
                full[s] = *b;
            }
        }
        let all: Vec<_> = full
            .iter()
            .enumerate()
            .filter(|(_, b)| b.is_some())
            .map(|(s, _)| s)
            .collect();
        if prune(instances, &mut full, free, &all).is_err() {
            continue;
        }
        witness = full;
        tree_cost = costs;
    }
    if ps.early_slack_flow && ps.objective == MapObjective::DelayArea {
        // Use the validated delay seed as a timing reference. The stage gets
        // 20% of the remaining window, leaving phase/local recovery the rest.
        // Atomic work completes between deadline checks; final global budget
        // validation remains authoritative. Actual whole-cover (D,A) accepts.
        let stage_start = Instant::now();
        let stage_deadline = stage_start + deadline.saturating_duration_since(stage_start).mul_f64(0.20);
        for _ in 0..ps.refine_rounds {
            if Instant::now() >= stage_deadline { break; }
            let required = required_times(instances, &chosen, free, roots, best.1);
            let refs = physical_refs(instances, &chosen, roots);
            let (mut trial, _) = flow_choices_worklist_impl(
                instances, free, &refs, 0.0, true, true,
                MapObjective::AreaDelay, stage_deadline,
                Some(&required), Some(&chosen),
            );
            stats.slack_attempts += 1;
            if fill_from_witness(instances, &mut trial, &witness, free, roots).is_err() { break; }
            stats.slack_valid += 1;
            let value = metrics(instances, &trial, free, roots);
            if !better_cover(value, best, ps) { break; }
            chosen = trial; best = value;
            stats.refinement_accepted += 1;
            stats.slack_accepted += 1;
        }
    }
    if ps.phase_recovery {
        let phase_start = Instant::now();
        let phase_deadline = regions::phase_deadline(phase_start, deadline, ps.phase_time_fraction);
        regions::recover_phases(
            instances,
            &mut chosen,
            &witness,
            free,
            roots,
            ps,
            stats,
            phase_deadline,
        )?;
        stats.phase_secs = phase_start.elapsed().as_secs_f64();
        best = metrics(instances, &chosen, free, roots);
    }
    for cone_phase in [false, true] {
        if cone_phase && !ps.recover_cones {
            continue;
        }
        // Preserve the original local recovery first; the cone-ranked pass can only improve it.
        for _ in 0..if cone_phase { 1 } else { ps.refine_rounds } {
            if Instant::now() >= deadline {
                break;
            }
            let mut output_users = vec![0; instances.len()];
            let mut signal_refs = vec![0; free.len()];
            if cone_phase {
                for b in chosen.iter().flatten() {
                    output_users[b.instance] += 1;
                }
                for &s in roots.iter().collect::<BTreeSet<_>>() {
                    signal_refs[s] += 1;
                }
                for (i, m) in instances.iter().enumerate() {
                    if output_users[i] > 0 {
                        for &s in m.inputs.iter().collect::<BTreeSet<_>>() {
                            signal_refs[s] += 1;
                        }
                    }
                }
            }
            let timing = if ps.critical_recovery
                && (ps.objective == MapObjective::DelayArea
                    || ps.max_delay.is_some_and(|limit| best.1 > limit + 1e-6))
            {
                Some(critical_arrivals(instances, &chosen, free, roots))
            } else {
                None
            };
            let mut proposals: Vec<_> = instances
                .iter()
                .enumerate()
                .filter_map(|(i, m)| {
                    if cone_phase && Instant::now() >= deadline {
                        return None;
                    }
                    let affected: BTreeSet<_> = m
                        .outputs
                        .iter()
                        .flat_map(|o| &o.targets)
                        .filter_map(|&s| chosen[s].map(|b| b.instance))
                        .collect();
                    if affected.is_empty() {
                        return None;
                    }
                    let removed: f64 = if cone_phase {
                        let targets: Vec<_> = m
                            .outputs
                            .iter()
                            .flat_map(|o| &o.targets)
                            .filter(|&&s| chosen[s].is_some_and(|b| b.instance != i))
                            .copied()
                            .collect();
                        reclaimable_area(
                            &targets,
                            instances,
                            &chosen,
                            free,
                            &signal_refs,
                            &output_users,
                        )
                    } else {
                        affected
                            .into_iter()
                            .map(|old| f64::from(instances[old].area))
                            .sum()
                    };
                    let added: f64 = m
                        .inputs
                        .iter()
                        .filter(|&&s| !free[s] && chosen[s].is_none())
                        .map(|&s| tree_cost[s])
                        .sum();
                    let timing_gain = timing.as_ref().map_or(0.0, |(arrival, critical)| {
                        critical_gain(m, &chosen, arrival, critical)
                    });
                    Some((timing_gain, f64::from(m.area) + added - removed, i))
                })
                .collect();
            proposals.sort_by(|a, b| {
                a.0.total_cmp(&b.0)
                    .then(a.1.total_cmp(&b.1))
                    .then(a.2.cmp(&b.2))
            });
            let mut improved = false;
            let before_trials = stats.refinement_trials;
            'proposals: for (_, _, i) in proposals.into_iter().take(ps.refine_trials) {
                if Instant::now() >= deadline {
                    break;
                }
                let m = &instances[i];
                let modes: Vec<_> = std::iter::once(None)
                    .chain(
                        (0..m.outputs.len())
                            .filter(|_| m.outputs.len() > 1)
                            .map(Some),
                    )
                    .collect();
                for mode in modes {
                    if Instant::now() >= deadline
                        || stats.refinement_trials - before_trials >= ps.refine_trials
                    {
                        break 'proposals;
                    }
                    let mut trial = chosen.clone();
                    let mut changed = false;
                    for (pin, output) in m.outputs.iter().enumerate() {
                        if mode.is_some_and(|p| p != pin) {
                            continue;
                        }
                        for &s in &output.targets {
                            if chosen[s].is_some()
                                && !chosen[s].is_some_and(|b| b.instance == i && b.pin == pin)
                            {
                                trial[s] = Some(Binding { instance: i, pin });
                                changed = true;
                            }
                        }
                    }
                    if !changed {
                        continue;
                    }
                    stats.refinement_trials += 1;
                    if fill_from_witness(instances, &mut trial, &witness, free, roots).is_err() {
                        continue;
                    }
                    let value = metrics(instances, &trial, free, roots);
                    if better_cover(value, best, ps) {
                        chosen = trial;
                        best = value;
                        improved = true;
                        stats.refinement_accepted += 1;
                    }
                }
            }
            if !improved {
                break;
            }
        }
    }
    // Re-estimate fanouts from the physical incumbent, rather than all alternative candidates.
    // Divide the entire cone flow by its observed reference count. Keep the previous cover unless
    // the rebuilt finite DAG improves the actual objective (including a hard delay constraint).
    for _ in 0..if ps.recover_live_refs {
        ps.refine_rounds
    } else {
        0
    } {
        if Instant::now() >= deadline {
            break;
        }
        let live_refs = physical_refs(instances, &chosen, roots);
        let flow = if ps.flow_worklist {
            flow_choices_worklist
        } else {
            flow_choices
        };
        let (mut candidate, _) = flow(
            instances,
            free,
            &live_refs,
            if ps.objective == MapObjective::Weighted {
                ps.delay_weight
            } else {
                0.0
            },
            true,
            ps.flow_delay_ties,
            // Area-flow ties can change physical sharing. Keep the legacy seed for
            // area-first; complete-cover acceptance still breaks area ties by delay.
            if ps.objective == MapObjective::AreaDelay {
                MapObjective::Weighted
            } else {
                ps.objective
            },
            deadline,
        );
        if fill_from_witness(instances, &mut candidate, &witness, free, roots).is_err() {
            break;
        }
        let value = metrics(instances, &candidate, free, roots);
        if !better_cover(value, best, ps) {
            break;
        }
        chosen = candidate;
        best = value;
        stats.refinement_accepted += 1;
    }
    if ps.objective == MapObjective::DelayArea && ps.slack_flow {
        for _ in 0..ps.refine_rounds {
            if Instant::now() >= deadline {
                break;
            }
            let required = required_times(instances, &chosen, free, roots, best.1);
            let refs = physical_refs(instances, &chosen, roots);
            let (mut trial, _) = flow_choices_worklist_impl(
                instances,
                free,
                &refs,
                0.0,
                true,
                true,
                MapObjective::AreaDelay,
                deadline,
                Some(&required),
                Some(&chosen),
            );
            stats.slack_attempts += 1;
            if fill_from_witness(instances, &mut trial, &witness, free, roots).is_err() {
                break;
            }
            stats.slack_valid += 1;
            let value = metrics(instances, &trial, free, roots);
            if !better_cover(value, best, ps) {
                break;
            }
            chosen = trial;
            best = value;
            stats.refinement_accepted += 1;
            stats.slack_accepted += 1;
        }
        // Try timing-feasible physical substitutions before global area flow.
        // Candidate timing is only a filter; actual complete-cover metrics decide.
        for _ in 0..ps.refine_rounds {
            if Instant::now() >= deadline {
                break;
            }
            let (mut arrival, _) = critical_arrivals(instances, &chosen, free, roots);
            let witness_roots: Vec<_> = witness
                .iter()
                .enumerate()
                .filter_map(|(s, b)| b.map(|_| s))
                .collect();
            let (witness_arrival, _) = critical_arrivals(instances, &witness, free, &witness_roots);
            for s in 0..arrival.len() {
                if arrival[s].is_none() {
                    arrival[s] = witness_arrival[s];
                }
            }
            let required = required_times(instances, &chosen, free, roots, best.1);
            let mut proposals = Vec::new();
            for (i, m) in instances.iter().enumerate() {
                if Instant::now() >= deadline {
                    break;
                }
                if m.inputs.iter().any(|&input| arrival[input].is_none()) {
                    continue;
                }
                let feasible = m.outputs.iter().any(|o| {
                    let time = m
                        .inputs
                        .iter()
                        .enumerate()
                        .filter(|(p, _)| o.has_arc(*p))
                        .map(|(p, &input)| arrival[input].unwrap() + f64::from(o.delays[p]))
                        .fold(0.0, f64::max);
                    o.targets.iter().any(|&s| {
                        chosen[s].is_some_and(|b| b.instance != i) && time <= required[s] + 1e-6
                    })
                });
                if !feasible {
                    continue;
                }
                stats.slack_local_scored += 1;
                let mut trial = chosen.clone();
                for (pin, o) in m.outputs.iter().enumerate() {
                    for &target in &o.targets {
                        if chosen[target].is_some() {
                            trial[target] = Some(Binding { instance: i, pin });
                        }
                    }
                }
                if fill_from_witness(instances, &mut trial, &witness, free, roots).is_err() {
                    continue;
                }
                let value = metrics(instances, &trial, free, roots);
                if value.0 < best.0 - 1e-6 {
                    proposals.push((value.0, i));
                }
            }
            proposals.sort_by(|a, b| a.0.total_cmp(&b.0).then(a.1.cmp(&b.1)));
            let mut improved = false;
            for (_, i) in proposals.into_iter().take(ps.refine_trials) {
                if Instant::now() >= deadline {
                    break;
                }
                stats.slack_local_trials += 1;
                stats.refinement_trials += 1;
                let m = &instances[i];
                let mut trial = chosen.clone();
                for (pin, o) in m.outputs.iter().enumerate() {
                    for &target in &o.targets {
                        if chosen[target].is_some() {
                            trial[target] = Some(Binding { instance: i, pin });
                        }
                    }
                }
                if fill_from_witness(instances, &mut trial, &witness, free, roots).is_err() {
                    continue;
                }
                let value = metrics(instances, &trial, free, roots);
                if better_cover(value, best, ps) {
                    chosen = trial;
                    best = value;
                    improved = true;
                    stats.refinement_accepted += 1;
                    stats.slack_local_accepted += 1;
                }
            }
            if !improved {
                break;
            }
        }
    }
    stats.heuristic_area = best.0;
    stats.heuristic_secs = start.elapsed().as_secs_f64();
    Ok(chosen)
}

// Preserve every finite witness binding, then allocate extra producers in
// rounds across target signals. This avoids spending the whole hard cap on
// cheap gate types or early classes. All accepted covers still require a DAG.
fn introduces_cycle(
    target: usize,
    inputs: &[usize],
    chosen: &[Option<Binding>],
    instances: &[Instance],
    free: &[bool],
) -> bool {
    let mut stack = inputs.to_vec();
    let mut seen = HashSet::new();
    while let Some(s) = stack.pop() {
        if s == target {
            return true;
        }
        if free[s] || !seen.insert(s) {
            continue;
        }
        if let Some(b) = chosen[s] {
            stack.extend(instances[b.instance].inputs.iter().copied());
        }
    }
    false
}

fn required_times(
    instances: &[Instance],
    chosen: &[Option<Binding>],
    free: &[bool],
    roots: &[usize],
    delay: f64,
) -> Vec<f64> {
    fn visit(
        s: usize,
        instances: &[Instance],
        chosen: &[Option<Binding>],
        free: &[bool],
        seen: &mut [bool],
        order: &mut Vec<usize>,
    ) {
        if free[s] || seen[s] {
            return;
        }
        seen[s] = true;
        let b = chosen[s].expect("validated cover");
        for &input in &instances[b.instance].inputs {
            visit(input, instances, chosen, free, seen, order);
        }
        order.push(s);
    }
    let mut order = Vec::new();
    let mut seen = vec![false; free.len()];
    for &s in roots {
        visit(s, instances, chosen, free, &mut seen, &mut order);
    }
    let mut required = vec![f64::INFINITY; free.len()];
    for &s in roots {
        required[s] = delay;
    }
    for s in order.into_iter().rev() {
        let b = chosen[s].expect("validated cover");
        let m = &instances[b.instance];
        for (p, &input) in m.inputs.iter().enumerate() {
            if m.outputs[b.pin].has_arc(p) {
                required[input] =
                    required[input].min(required[s] - f64::from(m.outputs[b.pin].delays[p]));
            }
        }
    }
    required
}

fn cap_instances(
    instances: &mut Vec<Instance>,
    free: &[bool],
    roots: &[usize],
    budget: usize,
    timing_cap: bool,
) -> Result<usize, String> {
    cap_instances_impl(instances, free, roots, budget, timing_cap, false)
}

fn cap_instances_impl(
    instances: &mut Vec<Instance>,
    free: &[bool],
    roots: &[usize],
    budget: usize,
    timing_cap: bool,
    queued_witness: bool,
) -> Result<usize, String> {
    if instances.len() <= budget {
        return Ok(0);
    }
    let witness = if queued_witness {
        finite_choices_queued(instances, free)
    } else {
        finite_choices(instances, free)
    };
    let mut check = witness.clone();
    prune(instances, &mut check, free, roots)?;
    let mut keep: BTreeSet<usize> = witness.iter().flatten().map(|b| b.instance).collect();
    if keep.len() > budget {
        return Err(format!(
            "instance budget {budget} below finite witness {}",
            keep.len()
        ));
    }
    let mut producers = vec![Vec::new(); free.len()];
    for (i, m) in instances.iter().enumerate() {
        for o in &m.outputs {
            for &s in &o.targets {
                producers[s].push(i);
            }
        }
    }
    let witness_roots: Vec<_> = witness
        .iter()
        .enumerate()
        .filter_map(|(s, b)| b.map(|_| s))
        .collect();
    let arrival = if timing_cap {
        critical_arrivals(instances, &witness, free, &witness_roots).0
    } else {
        vec![None; free.len()]
    };
    let key = |i: usize, target: usize| {
        let m = &instances[i];
        let time = if timing_cap {
            m.outputs
                .iter()
                .filter(|o| o.targets.contains(&target))
                .map(|o| {
                    m.inputs
                        .iter()
                        .enumerate()
                        .filter(|(p, _)| o.has_arc(*p))
                        .map(|(p, &s)| arrival[s].unwrap_or(f64::INFINITY) + f64::from(o.delays[p]))
                        .fold(0.0, f64::max)
                })
                .fold(f64::INFINITY, f64::min)
        } else {
            m.outputs
                .iter()
                .flat_map(|o| o.delays.iter())
                .copied()
                .fold(0.0, f32::max) as f64
        };
        (time, m.area, i)
    };
    for (target, bucket) in producers.iter_mut().enumerate() {
        bucket.sort_by(|&a, &b| {
            let x = key(a, target);
            let y = key(b, target);
            x.0.total_cmp(&y.0)
                .then(x.1.total_cmp(&y.1))
                .then(x.2.cmp(&y.2))
        });
        bucket.dedup();
    }
    let mut positions = vec![0; free.len()];
    loop {
        let before = keep.len();
        for (s, bucket) in producers.iter().enumerate() {
            while positions[s] < bucket.len() && keep.contains(&bucket[positions[s]]) {
                positions[s] += 1;
            }
            if keep.len() >= budget {
                break;
            }
            if positions[s] < bucket.len() {
                keep.insert(bucket[positions[s]]);
                positions[s] += 1;
            }
        }
        if keep.len() >= budget || keep.len() == before {
            break;
        }
    }
    let original = instances.len();
    let mut i = 0;
    instances.retain(|_| {
        let yes = keep.contains(&i);
        i += 1;
        yes
    });
    Ok(original - instances.len())
}

fn retain_possible_cone(instances: &mut Vec<Instance>, free: &[bool], roots: &[usize]) {
    let mut producers: Vec<Vec<usize>> = vec![Vec::new(); free.len()];
    for (i, m) in instances.iter().enumerate() {
        for output in &m.outputs {
            for &s in &output.targets {
                producers[s].push(i);
            }
        }
    }
    let mut needed = vec![false; free.len()];
    let mut used = vec![false; instances.len()];
    let mut stack = roots.to_vec();
    while let Some(s) = stack.pop() {
        if free[s] || needed[s] {
            continue;
        }
        needed[s] = true;
        for &i in &producers[s] {
            if !used[i] {
                used[i] = true;
                stack.extend(instances[i].inputs.iter().copied());
            }
        }
    }
    for m in instances.iter_mut() {
        for output in &mut m.outputs {
            output.targets.retain(|&s| needed[s]);
        }
    }
    instances.retain(|m| m.outputs.iter().any(|o| !o.targets.is_empty()));
}

fn prune(
    instances: &[Instance],
    chosen: &mut [Option<Binding>],
    free: &[bool],
    roots: &[usize],
) -> Result<(), String> {
    fn visit(
        s: usize,
        instances: &[Instance],
        chosen: &[Option<Binding>],
        free: &[bool],
        state: &mut [u8],
    ) -> Result<(), String> {
        if free[s] || state[s] == 2 {
            return Ok(());
        }
        if state[s] == 1 {
            return Err(format!("cycle through signal {s}"));
        }
        state[s] = 1;
        let b = chosen[s].ok_or_else(|| format!("undriven signal {s}"))?;
        let m = &instances[b.instance];
        if !m.outputs[b.pin].targets.contains(&s) {
            return Err(format!("invalid binding for signal {s}"));
        }
        for &input in &m.inputs {
            visit(input, instances, chosen, free, state)?;
        }
        state[s] = 2;
        Ok(())
    }
    let mut state = vec![0; free.len()];
    for &root in roots {
        visit(root, instances, chosen, free, &mut state)?;
    }
    for (s, choice) in chosen.iter_mut().enumerate() {
        if state[s] != 2 {
            *choice = None;
        }
    }
    Ok(())
}

// The cover is a validated DAG. Mark all timing arcs on any worst-delay path,
// including ties and demanded pins of a multioutput instance. Absent inputs have
// no predicted arrival and are left to the original area ordering.
fn critical_arrivals(
    instances: &[Instance],
    chosen: &[Option<Binding>],
    free: &[bool],
    roots: &[usize],
) -> (Vec<Option<f64>>, Vec<bool>) {
    fn visit(
        s: usize,
        instances: &[Instance],
        chosen: &[Option<Binding>],
        free: &[bool],
        cache: &mut [Option<f64>],
    ) -> f64 {
        if let Some(v) = cache[s] {
            return v;
        }
        let v = if free[s] {
            0.0
        } else {
            let b = chosen[s].expect("validated cover");
            let m = &instances[b.instance];
            m.inputs
                .iter()
                .enumerate()
                .filter(|(p, _)| m.outputs[b.pin].has_arc(*p))
                .map(|(p, &input)| {
                    visit(input, instances, chosen, free, cache)
                        + f64::from(m.outputs[b.pin].delays[p])
                })
                .fold(0.0, f64::max)
        };
        cache[s] = Some(v);
        v
    }
    let mut arrival = vec![None; free.len()];
    for (s, &is_free) in free.iter().enumerate() {
        if is_free {
            arrival[s] = Some(0.0);
        }
    }
    let worst = roots
        .iter()
        .map(|&s| visit(s, instances, chosen, free, &mut arrival))
        .fold(0.0, f64::max);
    let mut critical = vec![false; free.len()];
    let mut stack: Vec<_> = roots
        .iter()
        .copied()
        .filter(|&s| arrival[s].is_some_and(|t| (t - worst).abs() <= 1e-6))
        .collect();
    while let Some(s) = stack.pop() {
        if critical[s] {
            continue;
        }
        critical[s] = true;
        if free[s] {
            continue;
        }
        let b = chosen[s].expect("validated cover");
        let m = &instances[b.instance];
        for (p, &input) in m.inputs.iter().enumerate() {
            if m.outputs[b.pin].has_arc(p)
                && arrival[input].is_some_and(|t| {
                    (t + f64::from(m.outputs[b.pin].delays[p]) - arrival[s].unwrap()).abs() <= 1e-6
                })
            {
                stack.push(input);
            }
        }
    }
    (arrival, critical)
}

fn critical_gain(
    m: &Instance,
    chosen: &[Option<Binding>],
    arrival: &[Option<f64>],
    critical: &[bool],
) -> f64 {
    m.outputs
        .iter()
        .filter_map(|output| {
            let mut predicted: f64 = 0.0;
            for (p, &input) in m.inputs.iter().enumerate() {
                if output.has_arc(p) {
                    predicted = predicted.max(arrival[input]? + f64::from(output.delays[p]));
                }
            }
            output
                .targets
                .iter()
                .filter(|&&s| critical[s] && chosen[s].is_some())
                .filter_map(|&s| arrival[s].map(|old| (predicted - old).min(0.0)))
                .min_by(f64::total_cmp)
        })
        .min_by(f64::total_cmp)
        .unwrap_or(0.0)
}

fn metrics(
    instances: &[Instance],
    chosen: &[Option<Binding>],
    free: &[bool],
    roots: &[usize],
) -> (f64, f64) {
    fn arrival(
        s: usize,
        instances: &[Instance],
        chosen: &[Option<Binding>],
        free: &[bool],
        cache: &mut [Option<f64>],
    ) -> f64 {
        if free[s] {
            return 0.0;
        }
        if let Some(v) = cache[s] {
            return v;
        }
        let b = chosen[s].expect("cover was validated");
        let m = &instances[b.instance];
        let value = m
            .inputs
            .iter()
            .zip(&m.outputs[b.pin].delays)
            .enumerate()
            .filter(|(i, _)| m.outputs[b.pin].has_arc(*i))
            .map(|(_, (&input, &delay))| {
                arrival(input, instances, chosen, free, cache) + f64::from(delay)
            })
            .fold(0.0, f64::max);
        cache[s] = Some(value);
        value
    }
    let live: BTreeSet<_> = chosen.iter().flatten().map(|b| b.instance).collect();
    let area = live.into_iter().map(|i| f64::from(instances[i].area)).sum();
    let mut cache = vec![None; free.len()];
    let delay = roots
        .iter()
        .map(|&s| arrival(s, instances, chosen, free, &mut cache))
        .fold(0.0, f64::max);
    (area, delay)
}

fn extract(
    instances: &[Instance],
    free: &[bool],
    roots: &[usize],
    ps: &MapParams,
    stats: &mut MapStats,
) -> Result<Vec<Option<Binding>>, String> {
    let seed = heuristic_cover(instances, free, roots, ps, stats)?;
    let seed_metrics = metrics(instances, &seed, free, roots);
    let feasible_delay = |delay: f64| ps.max_delay.is_none_or(|limit| delay <= limit + 1e-6);
    if ps.time_limit_secs <= 0.0 {
        if !feasible_delay(seed_metrics.1) {
            return Err("fallback exceeds the requested delay bound".into());
        }
        stats.used_fallback = true;
        stats.solver_status = "heuristic-only".into();
        return Ok(seed);
    }
    let n = free.len();
    let mut model = Model::default();
    model.set_obj_sense(Sense::Minimize);
    model.set_parameter("log", "0");
    model.set_parameter("seconds", &ps.time_limit_secs.to_string());
    let x: Vec<_> = instances
        .iter()
        .map(|m| {
            let col = model.add_binary();
            model.set_obj_coeff(
                col,
                if ps.objective == MapObjective::DelayArea {
                    0.0
                } else {
                    f64::from(m.area)
                },
            );
            col
        })
        .collect();
    let mut bindings: Vec<(usize, Binding, Col)> = Vec::new();
    let mut producers: Vec<Vec<Col>> = vec![Vec::new(); n];
    for (i, m) in instances.iter().enumerate() {
        let row = model.add_row();
        model.set_row_upper(row, 0.0);
        model.set_weight(row, x[i], 1.0);
        for (pin, output) in m.outputs.iter().enumerate() {
            for &s in &output.targets {
                let z = model.add_binary();
                bindings.push((s, Binding { instance: i, pin }, z));
                producers[s].push(z);
                model.set_weight(row, z, -1.0); // x implies at least one used output binding
                let activation = model.add_row();
                model.set_row_upper(activation, 0.0);
                model.set_weight(activation, z, 1.0);
                model.set_weight(activation, x[i], -1.0);
            }
        }
    }
    for (s, prod) in producers.iter().enumerate() {
        let row = model.add_row();
        model.set_row_upper(row, if free[s] { 0.0 } else { 1.0 });
        if roots.contains(&s) && !free[s] {
            model.set_row_lower(row, 1.0);
        }
        for &z in prod {
            model.set_weight(row, z, 1.0);
        }
    }
    for (i, m) in instances.iter().enumerate() {
        for &s in &m.inputs {
            if free[s] {
                continue;
            }
            let row = model.add_row();
            model.set_row_upper(row, 0.0);
            model.set_weight(row, x[i], 1.0);
            for &z in &producers[s] {
                model.set_weight(row, z, -1.0);
            }
        }
    }
    // Each used pin, including secondary pins, must be above all its physical input signals.
    let big_level = n as f64 + 1.0;
    let level: Vec<_> = free
        .iter()
        .map(|&is_free| {
            let col = model.add_col();
            model.set_col_lower(col, 0.0);
            model.set_col_upper(col, if is_free { 0.0 } else { big_level });
            col
        })
        .collect();
    let timed =
        ps.objective != MapObjective::Weighted || ps.delay_weight > 0.0 || ps.max_delay.is_some();
    let max_arc = instances
        .iter()
        .flat_map(|m| &m.outputs)
        .flat_map(|o| &o.delays)
        .copied()
        .fold(0.0f32, f32::max);
    let big_time = f64::from(max_arc) * big_level + 1.0;
    let arrivals: Vec<_> = if timed {
        free.iter()
            .map(|&is_free| {
                let col = model.add_col();
                model.set_col_lower(col, 0.0);
                model.set_col_upper(col, if is_free { 0.0 } else { big_time });
                col
            })
            .collect()
    } else {
        Vec::new()
    };
    for &(s, b, z) in &bindings {
        let m = &instances[b.instance];
        for (input_index, &input) in m.inputs.iter().enumerate() {
            let row = model.add_row();
            model.set_row_lower(row, 1.0 - big_level);
            model.set_weight(row, level[s], 1.0);
            model.set_weight(row, level[input], -1.0);
            model.set_weight(row, z, -big_level);
            if timed && m.outputs[b.pin].has_arc(input_index) {
                let row = model.add_row();
                model.set_row_lower(
                    row,
                    f64::from(m.outputs[b.pin].delays[input_index]) - big_time,
                );
                model.set_weight(row, arrivals[s], 1.0);
                model.set_weight(row, arrivals[input], -1.0);
                model.set_weight(row, z, -big_time);
            }
        }
    }
    let worst = if timed {
        let worst = model.add_col();
        model.set_col_lower(worst, 0.0);
        model.set_col_upper(worst, ps.max_delay.unwrap_or(big_time).min(big_time));
        model.set_obj_coeff(
            worst,
            match ps.objective {
                MapObjective::DelayArea => 1.0,
                MapObjective::AreaDelay => 0.0,
                MapObjective::Weighted => ps.delay_weight,
            },
        );
        for &root in roots {
            let row = model.add_row();
            model.set_row_lower(row, 0.0);
            model.set_weight(row, worst, 1.0);
            model.set_weight(row, arrivals[root], -1.0);
        }
        Some(worst)
    } else {
        None
    };
    // Supply feasible binary assignments; CBC completes continuous level/arrival columns.
    if feasible_delay(seed_metrics.1) {
        if let Some(worst) = worst {
            // A zero initial worst-arrival gives CBC an incorrect warm-start objective
            // in delay-first mode even though the supplied binary cover has nonzero delay.
            model.set_col_initial_solution(worst, seed_metrics.1);
        }
        let selected: HashSet<_> = seed.iter().flatten().map(|b| b.instance).collect();
        for (i, &col) in x.iter().enumerate() {
            model.set_col_initial_solution(col, f64::from(selected.contains(&i)));
        }
        for &(s, b, col) in &bindings {
            let yes = seed[s].is_some_and(|old| old.instance == b.instance && old.pin == b.pin);
            model.set_col_initial_solution(col, f64::from(yes));
        }
    }
    // With lexicographic objectives and tightened arrival bounds, the installed CBC
    // can return fractional LP columns after a continuous warm start. Solve these
    // phases without that warm start; retain the independently checked seed in Rust.
    if ps.objective != MapObjective::Weighted {
        model.remove_initial_solution();
    }
    let start = Instant::now();
    let decode = |solution: &coin_cbc::Solution| -> Option<Vec<Option<Binding>>> {
        let integral = x
            .iter()
            .chain(bindings.iter().map(|(_, _, z)| z))
            .all(|&col| {
                let v = solution.col(col);
                v.is_finite() && (v.abs() < 1e-6 || (v - 1.0).abs() < 1e-6)
            });
        if !integral {
            return None;
        }
        let mut chosen = vec![None; n];
        for &(s, b, col) in &bindings {
            if solution.col(col) > 0.5 {
                if chosen[s].is_some() || solution.col(x[b.instance]) <= 0.5 || free[s] {
                    return None;
                }
                chosen[s] = Some(b);
            }
        }
        if prune(instances, &mut chosen, free, roots).is_err() {
            return None;
        }
        if !feasible_delay(metrics(instances, &chosen, free, roots).1) {
            return None;
        }
        Some(chosen)
    };
    let solution = model.solve();
    stats.solver_status = format!("{:?}", solution.raw().status());
    let mut result = decode(&solution);
    let mut proven = solution.raw().is_proven_optimal();
    if ps.objective != MapObjective::Weighted {
        if let Some(first) = &result {
            // Sequential optimization, not an epsilon-weight approximation. Preserve the
            // best known primary value; only two proven solves certify lexicographic optimality.
            let value = metrics(instances, first, free, roots);
            let remaining = ps.time_limit_secs - start.elapsed().as_secs_f64();
            if remaining > 0.01 {
                for (i, &col) in x.iter().enumerate() {
                    model.set_obj_coeff(
                        col,
                        if ps.objective == MapObjective::DelayArea {
                            f64::from(instances[i].area)
                        } else {
                            0.0
                        },
                    );
                }
                let worst = worst.expect("lexicographic timing variable");
                if ps.objective == MapObjective::AreaDelay {
                    let row = model.add_row();
                    model.set_row_upper(row, value.0 + 1e-7);
                    for (i, &col) in x.iter().enumerate() {
                        model.set_weight(row, col, f64::from(instances[i].area));
                    }
                    model.set_obj_coeff(worst, 1.0);
                } else {
                    model.set_col_upper(
                        worst,
                        (value.1 + 1e-7).min(ps.max_delay.unwrap_or(big_time)),
                    );
                    model.set_obj_coeff(worst, 0.0);
                }
                // Do not carry CBC's continuous first-stage warm start into a changed
                // objective/bound: the installed libcbc can expose the LP relaxation as the
                // returned column solution. The validated first cover remains our fallback.
                model.remove_initial_solution();
                model.set_parameter("seconds", &remaining.to_string());
                let second = model.solve();
                stats.solver_status = format!(
                    "primary={:?}, secondary={:?}",
                    solution.raw().status(),
                    second.raw().status()
                );
                let secondary_proven = second.raw().is_proven_optimal();
                if let Some(cover) = decode(&second) {
                    let after = metrics(instances, &cover, free, roots);
                    if better_cover(after, value, ps) || !better_cover(value, after, ps) {
                        result = Some(cover);
                        proven &= secondary_proven;
                    } else {
                        proven = false;
                    }
                } else {
                    proven = false;
                }
            } else {
                proven = false;
            }
        }
    }
    stats.solve_secs = start.elapsed().as_secs_f64();
    if let Some(chosen) = result {
        let value = metrics(instances, &chosen, free, roots);
        if !feasible_delay(seed_metrics.1) || !better_cover(seed_metrics, value, ps) {
            stats.proven_optimal = proven;
            return Ok(chosen);
        }
    }
    if !feasible_delay(seed_metrics.1) {
        return Err(format!(
            "{}: no valid cover within delay bound",
            stats.solver_status
        ));
    }
    stats.used_fallback = true;
    Ok(seed)
}

/// Saturate, match and extract without first collapsing the e-graph to one AIG.
pub fn map(aig: &Aig, tech: &TechLib, ps: &MapParams) -> Result<MappedGraph, String> {
    if !(2..=6).contains(&ps.max_inputs)
        || ps.dc_support > 20
        || ps.cuts_per_class == 0
        || ps.max_instances == 0
        || ps.boolean_rules > 2
        || !ps.time_limit_secs.is_finite()
        || !ps.phase_time_fraction.is_finite()
        || !(0.0..=1.0).contains(&ps.phase_time_fraction)
        || !ps.refine_time_secs.is_finite()
        || !(0.0..=3600.0).contains(&ps.refine_time_secs)
        || !ps.delay_weight.is_finite()
        || ps.delay_weight < 0.0
        || ps.max_delay.is_some_and(|v| !v.is_finite() || v < 0.0)
    {
        return Err("invalid mapping budgets, input limit, or timing objective".into());
    }
    let mut library_pins: HashMap<&str, (f32, HashSet<&str>)> = HashMap::new();
    for cell in &tech.cells {
        if !cell.area.is_finite()
            || cell.area < 0.0
            || cell.pin_delay.values().any(|v| !v.is_finite() || *v < 0.0)
        {
            return Err(format!("invalid area/delay in {}", cell.name));
        }
        let group = library_pins
            .entry(&cell.name)
            .or_insert((cell.area, HashSet::new()));
        if (group.0 - cell.area).abs() > 1e-6 || !group.1.insert(&cell.out_pin) {
            return Err(format!(
                "inconsistent area or duplicate output pin in {}",
                cell.name
            ));
        }
    }
    let start = Instant::now();
    let (graph, roots) = if ps.region_classes > 0 {
        regions::import_demanded(aig)
    } else {
        import_aig(aig)
    }
    .ok_or("cannot import AIG")?;
    if ps.strict_budgets && graph.total_number_of_nodes() > ps.saturation.node_limit {
        return Err(format!(
            "budget: imported graph {} exceeds node allowance {}",
            graph.total_number_of_nodes(),
            ps.saturation.node_limit
        ));
    }
    let imported_enodes = graph.total_number_of_nodes();
    let mut runner = Runner::<AigLang, (), ()>::default()
        .with_egraph(graph)
        .with_iter_limit(ps.saturation.iter_limit)
        .with_node_limit(ps.saturation.node_limit);
    runner.roots = roots.iter().map(|(_, id)| *id).collect();
    let mut equalities = rules(ps.saturation.use_factoring, ps.saturation.use_absorption);
    if ps.boolean_rules >= 1 {
        // (a & b) | (a & c) = a & (b | c), expressed entirely in AIG operators.
        equalities.push(egg::rewrite!("or-factor";
            "(~ (& (~ (& ?a ?b)) (~ (& ?a ?c))))" => "(& ?a (~ (& (~ ?b) (~ ?c))))"));
    }
    if ps.boolean_rules >= 2 {
        equalities.push(egg::rewrite!("and-associate";
            "(& (& ?a ?b) ?c)" => "(& ?a (& ?b ?c))"));
    }
    if ps.library_timing && ps.objective == MapObjective::DelayArea {
        let pattern: egg::Pattern<AigLang> = "(& (& ?a ?b) ?c)".parse().unwrap();
        equalities.push(
            egg::Rewrite::new(
                "bounded-delay-associate",
                pattern,
                BoundedAssociativity {
                    original_classes: runner.egraph.total_size(),
                    nodes: ps.saturation.node_limit,
                    per_class: ps.cuts_per_class,
                },
            )
            .unwrap(),
        );
    }
    let skipped = if ps.strict_budgets && ps.region_classes > 0 {
        Some(regions::reserve_rewrites(
            &mut equalities,
            ps.saturation.node_limit,
        ))
    } else {
        None
    };
    let runner = runner.run(&equalities);
    let graph = &runner.egraph;
    if ps.strict_budgets && graph.total_number_of_nodes() > ps.saturation.node_limit {
        return Err(format!(
            "budget: saturated graph {} exceeds node allowance {}",
            graph.total_number_of_nodes(),
            ps.saturation.node_limit
        ));
    }
    let mut classes: Vec<_> = graph.classes().map(|c| c.id).collect();
    classes.sort_by_key(|&id| usize::from(id));
    let ids: HashMap<_, _> = classes.iter().enumerate().map(|(i, &id)| (id, i)).collect();
    let nodes: Vec<_> = classes.iter().map(|&id| graph[id].nodes.clone()).collect();
    let mut stats = MapStats {
        imported_enodes,
        saturation_budget_skips: skipped
            .as_ref()
            .map_or(0, |s| s.load(std::sync::atomic::Ordering::Relaxed)),
        eclasses: classes.len(),
        enodes: graph.total_number_of_nodes(),
        saturation_stop: format!("{:?}", runner.stop_reason),
        ..Default::default()
    };
    let witnesses = if ps.strict_budgets {
        cheapest_nodes_queued(graph)
    } else {
        cheapest_nodes(graph)
    };
    let representatives: Vec<_> = classes
        .iter()
        .map(|&id| {
            witnesses
                .get(&id)
                .cloned()
                .map(|node| node.map_children(|child| graph.find(child)))
                .ok_or_else(|| format!("no finite reachability witness for eclass {id}"))
        })
        .collect::<Result<_, _>>()?;
    let mut reach = Reachability {
        nodes: representatives,
        ids: ids.clone(),
        cache: HashMap::new(),
    };
    let n = classes.len() * 2;
    let mut constants = vec![None; n];
    let mut free = vec![false; n];
    let mut inputs = Vec::new();
    for (c, enodes) in nodes.iter().enumerate() {
        for node in enodes {
            match node {
                AigLang::Zero | AigLang::One => {
                    let value = matches!(node, AigLang::One);
                    for phase in 0..2 {
                        constants[c * 2 + phase] = Some(value ^ (phase == 1));
                        free[c * 2 + phase] = true;
                    }
                }
                AigLang::Pi(var) => {
                    free[c * 2] = true;
                    let name = aig
                        .symbol_input(*var)
                        .cloned()
                        .unwrap_or_else(|| format!("$i{var}"));
                    inputs.push((c * 2, *var, name));
                }
                _ => {}
            }
        }
    }
    inputs.sort_by_key(|(_, var, _)| *var);
    let outputs: Vec<_> = roots
        .iter()
        .map(|&(pos, root)| {
            (
                ids[&graph.find(root)] * 2,
                aig.symbol_output(pos)
                    .cloned()
                    .unwrap_or_else(|| format!("$o{pos}")),
            )
        })
        .collect();
    let required: Vec<_> = outputs.iter().map(|(s, _)| *s).collect();
    let cuts = enumerate(&nodes, &ids, graph, tech, ps, &mut stats);
    stats.max_cuts_per_class = cuts.iter().map(|c| c.len()).max().unwrap_or(0);
    if ps.strict_budgets && stats.max_cuts_per_class > ps.cuts_per_class {
        return Err(format!(
            "budget: mandatory cuts {} exceed per-class allowance {}",
            stats.max_cuts_per_class, ps.cuts_per_class
        ));
    }
    let mut instances = generate(&cuts, &free, &constants, tech, ps, &mut reach, &mut stats);
    retain_possible_cone(&mut instances, &free, &required);
    stats.generated_instances = instances.len();
    if ps.library_timing || ps.strict_budgets {
        stats.instance_budget_pruned = cap_instances_impl(
            &mut instances,
            &free,
            &required,
            ps.max_instances,
            ps.timing_cap,
            ps.strict_budgets,
        )?;
        stats.instance_limit_hit |= stats.instance_budget_pruned > 0;
    }

    stats.instances = instances.len();
    stats.bindings = instances
        .iter()
        .flat_map(|m| &m.outputs)
        .map(|o| o.targets.len())
        .sum();
    stats.build_secs = start.elapsed().as_secs_f64();
    let chosen = extract(&instances, &free, &required, ps, &mut stats)?;
    let (area, delay) = metrics(&instances, &chosen, &free, &required);
    if let Ok(path) = std::env::var("EGM_DIAG_PATH") {
        let (arrival, critical) = critical_arrivals(&instances, &chosen, &free, &required);
        let cut_rows: Vec<_> = cuts
            .iter()
            .enumerate()
            .flat_map(|(c, cs)| {
                cs.iter().map(move |cut| {
                    let k = cut.leaves.len();
                    let names: BTreeSet<_> = (0..2)
                        .flat_map(|phase| {
                            tech.candidates(
                                k as u8,
                                tt9_from_u64(cut.function ^ if phase == 1 { mask(k) } else { 0 }),
                            )
                            .into_iter()
                            .flatten()
                            .filter(|v| !v.out_neg)
                            .map(|v| v.cell_name.clone())
                        })
                        .collect();
                    serde_json::json!({"class":c,"leaves":cut.leaves,"function":cut.function,
                              "direct_cells":names,"trivial":cut.leaves==[c]})
                })
            })
            .collect();
        let critical_rows: Vec<_> = critical.iter().enumerate().filter(|(_, yes)| **yes)
            .map(|(s,_)| {
                let producers: Vec<_> = instances.iter().enumerate().flat_map(|(i,m)|
                    m.outputs.iter().enumerate().filter(move |(_,o)| o.targets.contains(&s))
                    .map(move |(pin,o)| serde_json::json!({"instance":i,"pin":pin,"cell":m.cell,
                        "inputs":m.inputs,"delays":o.delays,"function":o.function,"area":m.area}))).collect();
                serde_json::json!({"signal":s,"arrival":arrival[s],"selected":chosen[s].map(|b| (b.instance,b.pin)),"producers":producers})
            }).collect();
        std::fs::write(path, serde_json::to_vec(&serde_json::json!({"cuts":cut_rows,"roots":required,
            "critical_signals":critical_rows,"arrivals":arrival,"free":free,"area":area,"delay":delay,"slack_local_scored":stats.slack_local_scored,"slack_local_trials":stats.slack_local_trials,"slack_local_accepted":stats.slack_local_accepted,"slack_attempts":stats.slack_attempts,"slack_valid":stats.slack_valid,"slack_accepted":stats.slack_accepted,"timing_model":"block pin; unloaded"})).map_err(|e|e.to_string())?).map_err(|e|e.to_string())?;
    }

    let live: BTreeSet<_> = chosen.iter().flatten().map(|b| b.instance).collect();
    for i in live {
        if instances[i].outputs.len() > 1 {
            stats.selected_multioutput += 1;
            let pins: HashSet<_> = chosen
                .iter()
                .flatten()
                .filter(|b| b.instance == i)
                .map(|b| b.pin)
                .collect();
            stats.selected_joint_multioutput += usize::from(pins.len() > 1);
        }
    }
    Ok(MappedGraph {
        instances,
        chosen,
        inputs,
        outputs,
        constants,
        area,
        delay,
        stats,
    })
}

fn identifier(name: &str) -> String {
    let valid = name.bytes().enumerate().all(|(i, b)| {
        b.is_ascii_alphabetic() || b == b'_' || (i > 0 && (b.is_ascii_digit() || b == b'$'))
    });
    let keyword = matches!(
        name,
        "module"
            | "endmodule"
            | "input"
            | "output"
            | "wire"
            | "assign"
            | "reg"
            | "always"
            | "and"
            | "or"
            | "not"
            | "buf"
            | "xor"
            | "nand"
            | "nor"
    );
    if !name.is_empty() && valid && !keyword {
        name.into()
    } else {
        format!("\\{name} ")
    }
}

/// Functional library models preserve all outputs and their common physical input namespace.
/// ABC's single-output genlib reader is insufficient for verifying grouped multi-output cells.
pub fn write_library_verilog<W: Write>(tech: &TechLib, mut w: W) -> std::io::Result<()> {
    fn expression(expr: &Expr) -> String {
        match expr {
            Expr::Const(v) => format!("1'b{}", u8::from(*v)),
            Expr::Var(v) if v == "CONST0" => "1'b0".into(),
            Expr::Var(v) if v == "CONST1" => "1'b1".into(),
            Expr::Var(v) => identifier(v),
            Expr::Not(a) => format!("~({})", expression(a)),
            Expr::And(a, b) => format!("({}) & ({})", expression(a), expression(b)),
            Expr::Or(a, b) => format!("({}) | ({})", expression(a), expression(b)),
        }
    }
    let mut groups: BTreeMap<&str, Vec<&Cell>> = BTreeMap::new();
    for cell in &tech.cells {
        groups.entry(&cell.name).or_default().push(cell);
    }
    for (name, cells) in groups {
        let pins: BTreeSet<_> = cells.iter().flat_map(|c| &c.vars).collect();
        let ports: Vec<_> = pins
            .iter()
            .map(|p| identifier(p))
            .chain(cells.iter().map(|c| identifier(&c.out_pin)))
            .collect();
        writeln!(w, "module {}({});", identifier(name), ports.join(", "))?;
        for pin in &pins {
            writeln!(w, "  input {};", identifier(pin))?;
        }
        for cell in &cells {
            writeln!(w, "  output {};", identifier(&cell.out_pin))?;
        }
        for cell in &cells {
            writeln!(
                w,
                "  assign {} = {};",
                identifier(&cell.out_pin),
                expression(&cell.expr)
            )?;
        }
        writeln!(w, "endmodule")?;
    }
    Ok(())
}

/// Flatten explicit cell models with Yosys and prove equivalence against the original AIG in ABC.
/// An unavailable tool, failed synthesis, or unknown checker outcome is an error, never success.
pub fn verify_with_models(
    tech: &TechLib,
    golden: &std::path::Path,
    netlist: &std::path::Path,
) -> Result<bool, String> {
    let mut models = Vec::new();
    write_library_verilog(tech, &mut models).map_err(|e| e.to_string())?;
    verify_with_verilog_models(
        &String::from_utf8(models).map_err(|e| e.to_string())?,
        golden,
        netlist,
    )
}

/// Check a netlist against a golden AIG using explicit functional Verilog models.
/// This also supports parameterized LUT models for cross-target baseline adapters.
pub fn verify_with_verilog_models(
    model_source: &str,
    golden: &std::path::Path,
    netlist: &std::path::Path,
) -> Result<bool, String> {
    use std::process::Command;
    use std::time::{SystemTime, UNIX_EPOCH};
    fn quoted(path: &std::path::Path) -> String {
        format!(
            "\"{}\"",
            path.to_string_lossy()
                .replace('\\', "\\\\")
                .replace('"', "\\\"")
        )
    }
    fn token(name: &str) -> String {
        name.trim_end().to_string()
    }
    let stamp = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map_err(|e| e.to_string())?
        .as_nanos();
    let directory = std::env::temp_dir().join(format!("egm_cec_{}_{stamp}", std::process::id()));
    std::fs::create_dir(&directory).map_err(|e| e.to_string())?;
    let result = (|| {
        let models = directory.join("cells.v");
        let implementation = directory.join("implementation.aig");
        let normalized_golden = directory.join("golden.aig");
        std::fs::write(&models, model_source).map_err(|e| e.to_string())?;
        let mapped = std::fs::canonicalize(netlist).map_err(|e| e.to_string())?;
        let golden = std::fs::canonicalize(golden).map_err(|e| e.to_string())?;
        let original = Aig::from_aiger(golden.to_str().ok_or("invalid golden path")?);
        let mut source_renames = String::new();
        let mut mapped_renames = String::new();
        for node in original.node_indices() {
            let (name, fallback, canonical) = match original.node_type(node) {
                crate::aig_graph::AigNode::Input(var) => (
                    original.symbol_input(var),
                    format!("$i{var}"),
                    format!("cec_{stamp}_i{var}"),
                ),
                crate::aig_graph::AigNode::Output(pos) => (
                    original.symbol_output(pos),
                    format!("$o{pos}"),
                    format!("cec_{stamp}_o{pos}"),
                ),
                _ => continue,
            };
            let name = name.unwrap_or(&fallback);
            // rename keeps quote characters. Restrict data tokens so a source symbol cannot
            // become a Yosys script delimiter; unsupported names fail verification explicitly.
            if !name
                .chars()
                .all(|c| c.is_ascii_alphanumeric() || "_$[].:/-".contains(c))
            {
                return Err("unsupported port identifier in Yosys verification".into());
            }
            // AIGER's unnamed ports are Yosys private identifiers; Verilog ports are public.
            let source_name = if name.starts_with('$') {
                name.clone()
            } else {
                identifier(name)
            };
            source_renames.push_str(&format!("rename {} {canonical}; ", token(&source_name)));
            mapped_renames.push_str(&format!(
                "rename {} {canonical}; ",
                token(&identifier(name))
            ));
        }
        let yosys = std::env::var("EGM_YOSYS").unwrap_or_else(|_| "yosys".into());
        // Canonical public names survive AIGER export even for originally unnamed ports. CEC then
        // matches by name, so Yosys port reordering cannot create spurious functional mismatches.
        let script = format!(
            "read_aiger -module_name golden {}; cd golden; {source_renames}cd ..; write_aiger -symbols {}; design -reset; read_verilog {} {}; hierarchy -check -top mapped; cd mapped; {mapped_renames}cd ..; proc; flatten; techmap; opt; aigmap; write_aiger -symbols {}",
            quoted(&golden),
            quoted(&normalized_golden),
            quoted(&models),
            quoted(&mapped),
            quoted(&implementation)
        );
        // Preserve the exact Yosys command text while avoiding OS per-argument
        // limits for circuits with thousands of named ports.
        let synthesis_script = directory.join("cec.ys");
        std::fs::write(&synthesis_script, &script).map_err(|e| e.to_string())?;
        let synthesis = Command::new(yosys)
            .args(["-Q", "-T", "-s"])
            .arg(&synthesis_script)
            .output()
            .map_err(|e| format!("cannot run Yosys: {e}"))?;
        if !synthesis.status.success() || !implementation.is_file() {
            return Err(format!(
                "Yosys failed: {}",
                String::from_utf8_lossy(&synthesis.stderr)
            ));
        }
        let abc = std::env::var("BENCH_RS_EMAP_ABC").unwrap_or_else(|_| "abc".into());
        let script = format!(
            "cec {} {}",
            quoted(&normalized_golden),
            quoted(&implementation)
        );
        let check = Command::new(abc)
            .args(["-c", &script])
            .output()
            .map_err(|e| format!("cannot run ABC: {e}"))?;
        let output = format!(
            "{}{}",
            String::from_utf8_lossy(&check.stdout),
            String::from_utf8_lossy(&check.stderr)
        );
        if output.contains("Networks are NOT EQUIVALENT")
            || output
                .to_lowercase()
                .contains("networks are not equivalent")
        {
            return Ok(false);
        }
        if check.status.success() && output.to_lowercase().contains("networks are equivalent") {
            return Ok(true);
        }
        Err(format!("ABC produced no equivalence result: {output}"))
    })();
    let _ = std::fs::remove_dir_all(directory);
    result
}

impl MappedGraph {
    /// Evaluate the actual selected physical netlist, useful for exhaustive small-circuit checks.
    pub fn evaluate(&self, inputs: &HashMap<u32, bool>) -> Result<Vec<bool>, String> {
        fn eval(
            s: usize,
            graph: &MappedGraph,
            values: &mut [Option<bool>],
            active: &mut [bool],
        ) -> Result<bool, String> {
            if let Some(value) = values[s] {
                return Ok(value);
            }
            if active[s] {
                return Err("cycle in selected netlist".into());
            }
            active[s] = true;
            let binding = graph.chosen[s].ok_or_else(|| format!("undriven signal {s}"))?;
            let m = &graph.instances[binding.instance];
            let mut assignment = 0;
            for (i, &input) in m.inputs.iter().enumerate() {
                assignment |= usize::from(eval(input, graph, values, active)?) << i;
            }
            let value = (m.outputs[binding.pin].function >> assignment) & 1 != 0;
            values[s] = Some(value);
            active[s] = false;
            Ok(value)
        }
        let mut values = self.constants.clone();
        for &(s, var, _) in &self.inputs {
            values[s] = Some(
                *inputs
                    .get(&var)
                    .ok_or_else(|| format!("missing input {var}"))?,
            );
        }
        let mut active = vec![false; values.len()];
        self.outputs
            .iter()
            .map(|(s, _)| eval(*s, self, &mut values, &mut active))
            .collect()
    }

    /// Unused physical outputs are explicitly left open. Equivalent bound signals share one net.
    pub fn write_verilog<W: Write>(&self, mut w: W, module: &str) -> std::io::Result<()> {
        let ports: Vec<_> = self
            .inputs
            .iter()
            .map(|(_, _, name)| identifier(name))
            .chain(self.outputs.iter().map(|(_, name)| identifier(name)))
            .collect();
        if ports.iter().collect::<HashSet<_>>().len() != ports.len()
            || self
                .inputs
                .iter()
                .map(|(_, _, n)| n)
                .chain(self.outputs.iter().map(|(_, n)| n))
                .any(|n| n.is_empty() || n.chars().any(char::is_whitespace))
        {
            return Err(std::io::Error::new(
                std::io::ErrorKind::InvalidInput,
                "duplicate or unrepresentable Verilog port names",
            ));
        }
        let mut prefix = "__egm_".to_string();
        while ports.iter().any(|name| name.starts_with(&prefix)) {
            prefix.push('_');
        }
        let signal_name = |s| format!("{prefix}s{s}");
        writeln!(w, "module {}({});", identifier(module), ports.join(", "))?;
        for (_, _, name) in &self.inputs {
            writeln!(w, "  input {};", identifier(name))?;
        }
        for (_, name) in &self.outputs {
            writeln!(w, "  output {};", identifier(name))?;
        }
        let mut nets: Vec<_> = (0..self.chosen.len()).map(&signal_name).collect();
        for (s, value) in self.constants.iter().enumerate() {
            if let Some(value) = value {
                nets[s] = format!("1'b{}", u8::from(*value));
            }
        }
        for &(s, _, ref name) in &self.inputs {
            nets[s] = identifier(name);
        }
        let mut bound: BTreeMap<(usize, usize), Vec<usize>> = BTreeMap::new();
        for (s, b) in self.chosen.iter().enumerate() {
            if let Some(b) = b {
                bound.entry((b.instance, b.pin)).or_default().push(s);
            }
        }
        let mut wires = BTreeSet::new();
        for signals in bound.values() {
            let net = signal_name(signals[0]);
            wires.insert(net.clone());
            for &s in signals {
                nets[s] = net.clone();
            }
        }
        for wire in wires {
            writeln!(w, "  wire {wire};")?;
        }
        let live: BTreeSet<_> = bound.keys().map(|(i, _)| *i).collect();
        for i in live {
            let m = &self.instances[i];
            let mut conns: Vec<_> = m
                .input_pins
                .iter()
                .zip(&m.inputs)
                .map(|(pin, &s)| format!(".{}({})", identifier(pin), nets[s]))
                .collect();
            for (pin, output) in m.outputs.iter().enumerate() {
                let net = bound
                    .get(&(i, pin))
                    .map(|signals| nets[signals[0]].as_str())
                    .unwrap_or("");
                conns.push(format!(".{}({net})", identifier(&output.name)));
            }
            writeln!(
                w,
                "  {} {prefix}g{i} ({});",
                identifier(&m.cell),
                conns.join(", ")
            )?;
        }
        for (s, name) in &self.outputs {
            writeln!(w, "  assign {} = {};", identifier(name), nets[*s])?;
        }
        writeln!(w, "endmodule")
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::aig_graph::AigNode;
    use petgraph::graph::NodeIndex;
    use std::sync::atomic::{AtomicUsize, Ordering};

    const BASIC: &str = "GATE INV 0.2 Y=!A;\nPIN A INV 1 99 0.2 0 0.2 0\n\
        GATE AND 1 Y=A*B;\nPIN A NONINV 1 99 1 0 1 0\nPIN B NONINV 1 99 1 0 1 0\n\
        GATE BUF 0.1 Y=A;\nPIN A NONINV 1 99 0.1 0 0.1 0\n";

    fn library(extra: &str) -> TechLib {
        static NEXT: AtomicUsize = AtomicUsize::new(0);
        let path = std::env::temp_dir().join(format!(
            "egm_test_{}_{}.genlib",
            std::process::id(),
            NEXT.fetch_add(1, Ordering::Relaxed)
        ));
        std::fs::write(&path, format!("{BASIC}{extra}")).unwrap();
        let library = TechLib::from_genlib(&path, 6).unwrap();
        std::fs::remove_file(path).unwrap();
        library
    }

    type Sig = (NodeIndex, bool);
    fn inv(s: Sig) -> Sig {
        (s.0, !s.1)
    }
    fn input(aig: &mut Aig, var: u32) -> Sig {
        (aig.add_node(AigNode::Input(var)), false)
    }
    fn and(aig: &mut Aig, a: Sig, b: Sig) -> Sig {
        let node = aig.add_node(AigNode::And);
        aig.add_edge(a.0, node, a.1);
        aig.add_edge(b.0, node, b.1);
        (node, false)
    }
    fn or(aig: &mut Aig, a: Sig, b: Sig) -> Sig {
        inv(and(aig, inv(a), inv(b)))
    }
    fn xor(aig: &mut Aig, a: Sig, b: Sig) -> Sig {
        let x = and(aig, a, inv(b));
        let y = and(aig, inv(a), b);
        or(aig, x, y)
    }
    fn output(aig: &mut Aig, s: Sig, pos: u32) {
        let node = aig.add_node(AigNode::Output(pos));
        aig.add_edge(s.0, node, s.1);
    }
    fn graph() -> Aig {
        let mut g = Aig::default();
        g.add_node(AigNode::Zero);
        g
    }
    fn params() -> MapParams {
        MapParams {
            time_limit_secs: 5.0,
            ..Default::default()
        }
    }
    fn assert_function(g: &MappedGraph, n: usize, f: impl Fn(usize) -> Vec<bool>) {
        for a in 0..1usize << n {
            let inputs = (0..n)
                .map(|i| ((i + 1) as u32, (a >> i) & 1 != 0))
                .collect();
            assert_eq!(g.evaluate(&inputs).unwrap(), f(a), "assignment {a}");
        }
    }

    #[test]
    fn or_factoring_exposes_a_smaller_two_input_cover() {
        let lib = library("");
        let mut aig = graph();
        let a = input(&mut aig, 1);
        let b = input(&mut aig, 2);
        let c = input(&mut aig, 3);
        let ab = and(&mut aig, a, b);
        let ac = and(&mut aig, a, c);
        let root = or(&mut aig, ab, ac);
        output(&mut aig, root, 0);
        let mut ps = MapParams {
            max_inputs: 2,
            time_limit_secs: 0.0,
            ..Default::default()
        };
        let original = map(&aig, &lib, &ps).unwrap();
        ps.boolean_rules = 1;
        let factored = map(&aig, &lib, &ps).unwrap();
        assert!(factored.area < original.area - 0.5);
        assert_function(&factored, 3, |a| vec![a & 1 != 0 && a & 6 != 0]);
        ps.boolean_rules = 2;
        let associative = map(&aig, &lib, &ps).unwrap();
        assert_function(&associative, 3, |a| vec![a & 1 != 0 && a & 6 != 0]);
    }

    #[test]
    fn three_disjoint_output_supports_need_a_cumulative_boundary() {
        let lib = library(
            "GATE TRIPLE 0.4 Y=!A;\nPIN A INV 1 99 1 0 1 0\n\
             GATE TRIPLE 0.4 Z=!B;\nPIN B INV 1 99 2 0 2 0\n\
             GATE TRIPLE 0.4 W=!C;\nPIN C INV 1 99 3 0 3 0\n",
        );
        let mut aig = graph();
        for i in 1..=3 {
            let a = input(&mut aig, i);
            output(&mut aig, inv(a), i - 1);
        }
        let pair_only = map(
            &aig,
            &lib,
            &MapParams {
                max_inputs: 3,
                multioutput_cumulative: false,
                time_limit_secs: 0.0,
                ..params()
            },
        )
        .unwrap();
        assert_function(&pair_only, 3, |a| vec![a & 1 == 0, a & 2 == 0, a & 4 == 0]);
        assert!((pair_only.area - 0.6).abs() < 1e-6);
        for time_limit_secs in [0.0, 5.0] {
            let mapped = map(
                &aig,
                &lib,
                &MapParams {
                    max_inputs: 3,
                    time_limit_secs,
                    ..params()
                },
            )
            .unwrap();
            assert_function(&mapped, 3, |a| vec![a & 1 == 0, a & 2 == 0, a & 4 == 0]);
            assert!((mapped.area - 0.4).abs() < 1e-6, "area {}", mapped.area);
            assert_eq!(mapped.stats.selected_joint_multioutput, 1);
            assert!((mapped.delay - 3.0).abs() < 1e-6);
        }
    }

    #[test]
    fn disjoint_output_supports_share_one_physical_cell() {
        let lib = library(
            "GATE DUAL 1.5 Y=A*B;\nPIN A NONINV 1 99 1 0 1 0\nPIN B NONINV 1 99 1 0 1 0\n\
             GATE DUAL 1.5 Z=C*D;\nPIN C NONINV 1 99 2 0 2 0\nPIN D NONINV 1 99 2 0 2 0\n",
        );
        let mut aig = graph();
        let a = input(&mut aig, 1);
        let b = input(&mut aig, 2);
        let c = input(&mut aig, 3);
        let d = input(&mut aig, 4);
        let ab = and(&mut aig, a, b);
        let cd = and(&mut aig, c, d);
        output(&mut aig, ab, 0);
        output(&mut aig, cd, 1);
        for time_limit_secs in [0.0, 5.0] {
            let mapped = map(
                &aig,
                &lib,
                &MapParams {
                    max_inputs: 4,
                    time_limit_secs,
                    ..params()
                },
            )
            .unwrap();
            assert_function(&mapped, 4, |a| vec![a & 3 == 3, a & 12 == 12]);
            assert!((mapped.area - 1.5).abs() < 1e-6, "area {}", mapped.area);
            assert_eq!(mapped.stats.selected_joint_multioutput, 1);
            assert!((mapped.delay - 2.0).abs() < 1e-6);
        }
    }

    #[test]
    fn full_adder_is_one_instance_with_distinct_output_delays() {
        let lib = library(
            "GATE FA 2 S=A*!B*!C+!A*B*!C+!A*!B*C+A*B*C;\n\
            PIN A UNKNOWN 1 99 3 0 3 0\nPIN B UNKNOWN 1 99 3 0 3 0\nPIN C UNKNOWN 1 99 3 0 3 0\n\
            GATE FA 2 CO=A*B+A*C+B*C;\n\
            PIN A UNKNOWN 1 99 7 0 7 0\nPIN B UNKNOWN 1 99 7 0 7 0\nPIN C UNKNOWN 1 99 7 0 7 0\n",
        );
        let mut aig = graph();
        let a = input(&mut aig, 1);
        let b = input(&mut aig, 2);
        let c = input(&mut aig, 3);
        let ab = xor(&mut aig, a, b);
        let sum = xor(&mut aig, ab, c);
        let x = and(&mut aig, a, b);
        let y = and(&mut aig, a, c);
        let z = and(&mut aig, b, c);
        let xy = or(&mut aig, x, y);
        let carry = or(&mut aig, xy, z);
        output(&mut aig, sum, 0);
        output(&mut aig, carry, 1);
        let mapped = map(&aig, &lib, &params()).unwrap();
        assert_function(&mapped, 3, |a| {
            vec![a.count_ones() % 2 == 1, a.count_ones() >= 2]
        });
        assert!(
            (mapped.area - 2.0).abs() < 1e-6,
            "area {}, stats {:?}, FA candidates {}",
            mapped.area,
            mapped.stats,
            mapped.instances.iter().filter(|m| m.cell == "FA").count()
        );
        assert!((mapped.delay - 7.0).abs() < 1e-6, "delay {}", mapped.delay);
        assert_eq!(mapped.stats.selected_joint_multioutput, 1);
        let mut netlist = Vec::new();
        mapped.write_verilog(&mut netlist, "test").unwrap();
        let text = String::from_utf8(netlist).unwrap();
        assert_eq!(text.matches("FA __egm_g").count(), 1);
        assert!(text.contains(".S(") && text.contains(".CO("));
    }

    #[test]
    fn multioutput_unifies_different_supports_and_can_leave_pins_open() {
        let lib = library(
            "GATE PAIR 0.5 Y=A*B;\nPIN A NONINV 1 99 1 0 1 0\nPIN B NONINV 1 99 1 0 1 0\n\
            GATE PAIR 0.5 Z=A;\nPIN A NONINV 1 99 2 0 2 0\n",
        );
        let mut aig = graph();
        let a = input(&mut aig, 1);
        let b = input(&mut aig, 2);
        let ab = and(&mut aig, a, b);
        output(&mut aig, ab, 0);
        let mapped = map(&aig, &lib, &params()).unwrap();
        assert_function(&mapped, 2, |a| vec![a == 3]);
        assert!((mapped.area - 0.5).abs() < 1e-6);
        assert_eq!(mapped.stats.selected_multioutput, 1);
        assert_eq!(mapped.stats.selected_joint_multioutput, 0);
        let mut netlist = Vec::new();
        mapped.write_verilog(&mut netlist, "test").unwrap();
        let text = String::from_utf8(netlist).unwrap();
        assert!(text.contains(".A(") && text.contains(".B(") && text.contains(".Z()"));
    }

    #[test]
    fn sdc_removes_an_input_without_global_union() {
        let lib = library("");
        let mut aig = graph();
        let a = input(&mut aig, 1);
        let b = input(&mut aig, 2);
        let c = input(&mut aig, 3);
        let ab = and(&mut aig, a, b);
        let all = and(&mut aig, ab, c);
        let any_ab = or(&mut aig, a, b);
        let any = or(&mut aig, any_ab, c);
        let root = and(&mut aig, all, any);
        output(&mut aig, root, 0);
        // k=2 blocks the exact three-PI realization; correlated internal leaves enable BUF.
        let ps = MapParams {
            max_inputs: 2,
            dc_support: 3,
            ..params()
        };
        let precise = map(
            &aig,
            &lib,
            &MapParams {
                dc_support: 0,
                ..ps.clone()
            },
        )
        .unwrap();
        let mapped = map(&aig, &lib, &ps).unwrap();
        assert_function(&mapped, 3, |a| vec![a == 7]);
        assert!(mapped.stats.dc_with_unreachable > 0 && mapped.stats.dc_bindings > 0);
        assert!(
            mapped.area < precise.area - 1e-5,
            "SDC {} vs exact {}",
            mapped.area,
            precise.area
        );
        assert_eq!(mapped.stats.eclasses, precise.stats.eclasses);
        assert_eq!(mapped.stats.enodes, precise.stats.enodes);
    }

    #[test]
    fn dc_budget_exhaustion_is_conservative_and_zero_solve_budget_has_valid_cover() {
        let mut aig = graph();
        let a = input(&mut aig, 1);
        let b = input(&mut aig, 2);
        let ab = and(&mut aig, a, b);
        output(&mut aig, ab, 0);
        output(&mut aig, inv(ab), 1);
        let ps = MapParams {
            time_limit_secs: 0.0,
            dc_support: 1,
            cut_rounds: 0,
            cuts_per_class: 1,
            ..params()
        };
        let mapped = map(&aig, &library(""), &ps).unwrap();
        assert_function(&mapped, 2, |a| vec![a == 3, a != 3]);
        assert!(mapped.stats.used_fallback && mapped.stats.dc_skipped > 0);
    }

    #[test]
    fn physical_pin_bindings_can_share_a_net_but_cycles_are_rejected() {
        let instance = Instance {
            cell: "PAIR".into(),
            area: 1.0,
            inputs: vec![0],
            input_pins: vec!["A".into()],
            outputs: vec![OutputPin {
                name: "Y".into(),
                delays: vec![1.0],
                function: 2,
                targets: vec![1, 2],
            }],
        };
        let mut stats = MapStats::default();
        let chosen = extract(
            &[instance.clone()],
            &[true, false, false],
            &[1, 2],
            &params(),
            &mut stats,
        )
        .unwrap();
        let graph = MappedGraph {
            instances: vec![instance],
            chosen,
            inputs: vec![(0, 1, "a".into())],
            outputs: vec![(1, "y".into()), (2, "z".into())],
            constants: vec![None; 3],
            area: 1.0,
            delay: 1.0,
            stats,
        };
        let mut text = Vec::new();
        graph.write_verilog(&mut text, "test").unwrap();
        let text = String::from_utf8(text).unwrap();
        assert!(text.contains("assign y = __egm_s1;") && text.contains("assign z = __egm_s1;"));
        let cycle = Instance {
            cell: "BAD".into(),
            area: 0.0,
            inputs: vec![1],
            input_pins: vec!["A".into()],
            outputs: vec![OutputPin {
                name: "Y".into(),
                delays: vec![0.0],
                function: 2,
                targets: vec![1],
            }],
        };
        assert!(extract(
            &[cycle],
            &[true, false],
            &[1],
            &params(),
            &mut MapStats::default()
        )
        .is_err());
    }

    #[test]
    fn hard_delay_bound_applies_to_secondary_pin_and_never_returns_bad_fallback() {
        let instances = vec![Instance {
            cell: "PAIR".into(),
            area: 1.0,
            inputs: vec![0],
            input_pins: vec!["A".into()],
            outputs: vec![
                OutputPin {
                    name: "FAST".into(),
                    delays: vec![1.0],
                    function: 2,
                    targets: vec![1],
                },
                OutputPin {
                    name: "SLOW".into(),
                    delays: vec![8.0],
                    function: 2,
                    targets: vec![2],
                },
            ],
        }];
        let ps = MapParams {
            max_delay: Some(4.0),
            ..params()
        };
        assert!(extract(
            &instances,
            &[true, false, false],
            &[1, 2],
            &ps,
            &mut MapStats::default()
        )
        .is_err());
    }

    #[test]
    fn constants_and_duplicate_primary_outputs_remain_driven() {
        let mut aig = graph();
        let a = input(&mut aig, 1);
        let zero = (NodeIndex::new(0), false);
        output(&mut aig, a, 0);
        output(&mut aig, a, 1);
        output(&mut aig, zero, 2);
        output(&mut aig, inv(zero), 3);
        let mapped = map(&aig, &library(""), &params()).unwrap();
        assert_function(&mapped, 1, |a| vec![a != 0, a != 0, false, true]);
        assert_eq!(mapped.area, 0.0);
    }

    fn heuristic_instance(
        name: &str,
        area: f32,
        input: usize,
        outputs: &[(usize, f32)],
    ) -> Instance {
        Instance {
            cell: name.into(),
            area,
            inputs: vec![input],
            input_pins: vec!["A".into()],
            outputs: outputs
                .iter()
                .enumerate()
                .map(|(i, &(signal, delay))| OutputPin {
                    name: format!("Y{i}"),
                    delays: vec![delay],
                    function: 2,
                    targets: vec![signal],
                })
                .collect(),
        }
    }

    #[test]
    fn shared_deadline_recovery_keeps_joint_pin_area_accounting() {
        let instances = vec![Instance {
            cell: "AND_OR".into(),
            area: 2.0,
            inputs: vec![0, 1],
            input_pins: vec!["A".into(), "B".into()],
            outputs: vec![
                OutputPin {
                    name: "AND".into(),
                    delays: vec![1.0, 1.0],
                    function: 0b1000,
                    targets: vec![2],
                },
                OutputPin {
                    name: "OR".into(),
                    delays: vec![2.0, 3.0],
                    function: 0b1110,
                    targets: vec![3],
                },
            ],
        }];
        let mut stats = MapStats::default();
        let chosen = heuristic_cover(
            &instances,
            &[true, true, false, false],
            &[2, 3],
            &MapParams {
                flow_compare: true,
                objective: MapObjective::AreaDelay,
                ..params()
            },
            &mut stats,
        )
        .unwrap();
        assert!(stats.flow_compare_attempted);
        assert_eq!(chosen[2].unwrap().instance, chosen[3].unwrap().instance);
        assert_eq!(
            metrics(&instances, &chosen, &[true, true, false, false], &[2, 3]),
            (2.0, 3.0)
        );
    }

    #[test]
    fn seeded_slack_flow_rejects_cheap_reconvergent_cycle() {
        let instances = vec![
            heuristic_instance("ONE", 3.0, 0, &[(1, 1.0)]),
            heuristic_instance("TWO", 3.0, 0, &[(2, 1.0)]),
            heuristic_instance("CRITICAL", 1.0, 0, &[(3, 10.0)]),
            heuristic_instance("LOOP1", 0.1, 2, &[(1, 1.0)]),
            heuristic_instance("LOOP2", 0.1, 1, &[(2, 1.0)]),
        ];
        let seed = vec![
            None,
            Some(Binding {
                instance: 0,
                pin: 0,
            }),
            Some(Binding {
                instance: 1,
                pin: 0,
            }),
            Some(Binding {
                instance: 2,
                pin: 0,
            }),
        ];
        let free = [true, false, false, false];
        let roots = [1, 2, 3];
        let required = required_times(&instances, &seed, &free, &roots, 10.0);
        let (mut trial, _) = flow_choices_worklist_impl(
            &instances,
            &free,
            &[8.0; 4],
            0.0,
            true,
            true,
            MapObjective::AreaDelay,
            Instant::now() + std::time::Duration::from_secs(1),
            Some(&required),
            Some(&seed),
        );
        prune(&instances, &mut trial, &free, &roots).unwrap();
        let value = metrics(&instances, &trial, &free, &roots);
        assert!(value.0 < 7.0 && value.1 <= 10.0);
    }

    #[test]
    fn required_time_flow_can_slow_noncritical_root_without_changing_delay() {
        let instances = vec![
            heuristic_instance("CRITICAL", 1.0, 0, &[(1, 10.0)]),
            heuristic_instance("FAST", 3.0, 0, &[(2, 1.0)]),
            heuristic_instance("CHEAP", 1.0, 0, &[(2, 5.0)]),
        ];
        let free = [true, false, false];
        let roots = [1, 2];
        let mut chosen = vec![
            None,
            Some(Binding {
                instance: 0,
                pin: 0,
            }),
            Some(Binding {
                instance: 1,
                pin: 0,
            }),
        ];
        let required = required_times(&instances, &chosen, &free, &roots, 10.0);
        assert_eq!(required[1], 10.0);
        assert_eq!(required[2], 10.0);
        let (mut trial, _) = flow_choices_worklist_impl(
            &instances,
            &free,
            &[1.0; 3],
            0.0,
            true,
            true,
            MapObjective::AreaDelay,
            Instant::now() + std::time::Duration::from_secs(1),
            Some(&required),
            Some(&chosen),
        );
        fill_from_witness(&instances, &mut trial, &chosen, &free, &roots).unwrap();
        assert_eq!(metrics(&instances, &chosen, &free, &roots), (4.0, 10.0));
        assert_eq!(metrics(&instances, &trial, &free, &roots), (2.0, 10.0));
        chosen = trial;
        assert_eq!(chosen[2].unwrap().instance, 2);
    }

    #[test]
    fn regional_import_keeps_unused_ports_and_demanded_complements() {
        let mut aig = graph();
        let a = input(&mut aig, 1);
        let b = input(&mut aig, 2);
        let _unused = input(&mut aig, 3);
        let ab = and(&mut aig, a, b);
        output(&mut aig, ab, 0);
        output(&mut aig, inv(ab), 1);
        output(&mut aig, inv(a), 2);
        let (old, _) = import_aig(&aig).unwrap();
        let (new, _) = regions::import_demanded(&aig).unwrap();
        assert!(new.total_number_of_nodes() < old.total_number_of_nodes());
        let ps = MapParams {
            region_classes: 2,
            phase_recovery: true,
            strict_budgets: true,
            time_limit_secs: 0.,
            ..Default::default()
        };
        let mapped = map(&aig, &library(""), &ps).unwrap();
        assert_eq!(mapped.inputs.len(), 3);
        assert!(mapped.stats.regions > 1);
        assert!(mapped.stats.enodes <= ps.saturation.node_limit);
        assert!(mapped.stats.instances <= ps.max_instances);
        assert_function(&mapped, 3, |bits| {
            let a = bits & 1 != 0;
            let b = bits & 2 != 0;
            vec![a && b, !(a && b), !a]
        });
        let mut exact_floor = ps.clone();
        exact_floor.saturation.node_limit = new.total_number_of_nodes();
        let bounded = map(&aig, &library(""), &exact_floor).unwrap();
        assert!(bounded.stats.enodes <= exact_floor.saturation.node_limit);
        assert!(bounded.stats.saturation_budget_skips > 0);
        let mut small = ps.clone();
        small.saturation.node_limit = 1;
        assert!(map(&aig, &library(""), &small)
            .err()
            .unwrap()
            .contains("imported graph"));
    }

    #[test]
    fn strict_budget_rejects_imported_floor_and_zero_recovery_time() {
        let mut aig = graph();
        let a = input(&mut aig, 1);
        let b = input(&mut aig, 2);
        let ab = and(&mut aig, a, b);
        output(&mut aig, ab, 0);
        let mut ps = params();
        ps.strict_budgets = true;
        ps.saturation.node_limit = 1;
        assert!(map(&aig, &library(""), &ps)
            .err()
            .unwrap()
            .contains("imported graph"));
        ps.saturation.node_limit = 20000;
        ps.refine_time_secs = 0.0;
        assert!(map(&aig, &library(""), &ps)
            .err()
            .unwrap()
            .contains("recovery"));
    }

    #[test]
    fn dependency_witness_matches_legacy_round_order() {
        for seed in 0..128u64 {
            let mut state = seed + 1;
            let mut random = || {
                state = state.wrapping_mul(6364136223846793005).wrapping_add(1);
                (state >> 32) as usize
            };
            let mut instances = Vec::new();
            for _ in 0..36 {
                let area = (random() % 5) as f32;
                let a = random() % 8;
                let b = random() % 8;
                let target = 1 + random() % 7;
                let mut m = heuristic_instance("TEST", area, a, &[(target, 1.0)]);
                m.inputs = vec![a, b, a];
                instances.push(m);
            }
            let free = [true, false, false, false, false, false, false, false];
            let mut available = free.to_vec();
            let mut old = vec![None; free.len()];
            let mut order: Vec<_> = (0..instances.len()).collect();
            order.sort_by(|&a, &b| instances[a].area.total_cmp(&instances[b].area));
            loop {
                let mut changed = false;
                for &i in &order {
                    if !instances[i].inputs.iter().all(|&s| available[s]) {
                        continue;
                    }
                    for (pin, o) in instances[i].outputs.iter().enumerate() {
                        for &s in &o.targets {
                            if !available[s] {
                                available[s] = true;
                                old[s] = Some(Binding { instance: i, pin });
                                changed = true;
                            }
                        }
                    }
                }
                if !changed {
                    break;
                }
            }
            let keys = |xs: Vec<Option<Binding>>| {
                xs.into_iter()
                    .map(|b| b.map(|x| (x.instance, x.pin)))
                    .collect::<Vec<_>>()
            };
            assert_eq!(
                keys(finite_choices_queued(&instances, &free)),
                keys(old),
                "seed {seed}"
            );
        }
    }

    #[test]
    fn timing_cap_retains_early_boundary_over_fast_cell_on_late_input() {
        let original = vec![
            heuristic_instance("LATE", 1.0, 0, &[(1, 10.0)]),
            heuristic_instance("WITNESS", 1.0, 1, &[(2, 20.0)]),
            heuristic_instance("FAST_LATE", 2.0, 1, &[(2, 1.0)]),
            heuristic_instance("EARLY", 2.0, 0, &[(2, 5.0)]),
        ];
        let mut timed = original.clone();
        cap_instances(&mut timed, &[true, false, false], &[2], 3, true).unwrap();
        assert!(timed.iter().any(|m| m.cell == "EARLY"));
        assert!(!timed.iter().any(|m| m.cell == "FAST_LATE"));
        let mut static_rank = original;
        cap_instances(&mut static_rank, &[true, false, false], &[2], 3, false).unwrap();
        assert!(static_rank.iter().any(|m| m.cell == "FAST_LATE"));
        let witness = fallback(&timed, &[true, false, false], &[2]).unwrap();
        assert_eq!(
            metrics(&timed, &witness, &[true, false, false], &[2]),
            (2.0, 30.0)
        );
    }

    #[test]
    fn hard_instance_cap_preserves_witness_and_rejects_insufficient_budget() {
        let mut instances = vec![
            heuristic_instance("CHEAP1", 1.0, 0, &[(1, 5.0)]),
            heuristic_instance("CHEAP2", 1.0, 1, &[(2, 5.0)]),
            heuristic_instance("FAST1", 2.0, 0, &[(1, 1.0)]),
            heuristic_instance("FAST2", 2.0, 1, &[(2, 1.0)]),
            heuristic_instance("OTHER1", 3.0, 0, &[(1, 2.0)]),
            heuristic_instance("OTHER2", 3.0, 1, &[(2, 2.0)]),
        ];
        let original = instances.clone();
        assert_eq!(
            cap_instances(&mut instances, &[true, false, false], &[2], 4, false).unwrap(),
            2
        );
        assert_eq!(instances.len(), 4);
        let witness = fallback(&instances, &[true, false, false], &[2]).unwrap();
        assert_eq!(
            metrics(&instances, &witness, &[true, false, false], &[2]),
            (2.0, 10.0)
        );
        let mut too_small = original;
        assert!(cap_instances(&mut too_small, &[true, false, false], &[2], 1, false).is_err());
        assert_eq!(too_small.len(), 6);
    }

    #[test]
    fn library_timing_bounded_reassociation_preserves_function() {
        let mut aig = graph();
        let a = input(&mut aig, 1);
        let b = input(&mut aig, 2);
        let c = input(&mut aig, 3);
        let ab = and(&mut aig, a, b);
        let abc = and(&mut aig, ab, c);
        output(&mut aig, abc, 0);
        let mapped = map(
            &aig,
            &library(""),
            &MapParams {
                library_timing: true,
                objective: MapObjective::DelayArea,
                max_instances: 200,
                saturation: SatParams {
                    node_limit: 64,
                    ..Default::default()
                },
                ..params()
            },
        )
        .unwrap();
        assert_function(&mapped, 3, |a| vec![a == 7]);
        assert!(mapped.stats.instances <= 200);
        assert!(mapped.stats.enodes <= 64);
    }

    #[test]
    fn mixed_cut_quota_keeps_legacy_prefix_without_increasing_cap() {
        let optional: Vec<_> = (0..4)
            .map(|i| Cut {
                leaves: vec![i],
                function: 2,
            })
            .collect();
        let depth = [4, 3, 2, 1];
        assert_eq!(
            mixed_optional_cuts(&optional, &depth, 3, 0),
            optional[..3].iter().cloned().collect()
        );
        assert_eq!(
            mixed_optional_cuts(&optional, &depth, 3, 1),
            [
                optional[0].clone(),
                optional[1].clone(),
                optional[3].clone()
            ]
            .into_iter()
            .collect()
        );
        assert_eq!(
            mixed_optional_cuts(&optional, &depth, 3, 99),
            optional[1..].iter().cloned().collect()
        );
        assert!(mixed_optional_cuts(&optional, &depth, 0, 99).is_empty());
        assert_eq!(mixed_optional_cuts(&optional, &[0, 0, 1, 2], 3, 2).len(), 3);
    }

    #[test]
    fn depth_ranked_tiny_cut_budget_retains_finite_equivalent_cover() {
        let mut aig = graph();
        let a = input(&mut aig, 1);
        let b = input(&mut aig, 2);
        let c = input(&mut aig, 3);
        let ab = and(&mut aig, a, b);
        let abc = and(&mut aig, ab, c);
        output(&mut aig, abc, 0);
        let mapped = map(
            &aig,
            &library(""),
            &MapParams {
                cut_depth_priority: true,
                cuts_per_class: 1,
                cut_rounds: 2,
                time_limit_secs: 0.0,
                ..params()
            },
        )
        .unwrap();
        assert_function(&mapped, 3, |a| vec![a == 7]);
        assert!(mapped.area.is_finite() && mapped.delay.is_finite());
        assert!(mapped.stats.cut_limit_hit);
    }

    #[test]
    fn critical_paths_include_ties_and_ignore_nondependent_pin_arcs() {
        let mut joint = heuristic_instance("JOINT", 2.0, 0, &[(2, 5.0), (3, 5.0)]);
        joint.inputs = vec![0, 1];
        joint.input_pins = vec!["A".into(), "B".into()];
        // Both functions depend only on A; a large B delay is irrelevant.
        for o in &mut joint.outputs {
            o.function = 0b1010;
            o.delays = vec![5.0, 99.0];
        }
        let instances = vec![joint];
        let chosen = vec![
            None,
            None,
            Some(Binding {
                instance: 0,
                pin: 0,
            }),
            Some(Binding {
                instance: 0,
                pin: 1,
            }),
        ];
        let (arrival, critical) =
            critical_arrivals(&instances, &chosen, &[true, true, false, false], &[2, 3]);
        assert_eq!(arrival[2], Some(5.0));
        assert_eq!(arrival[3], Some(5.0));
        assert_eq!(critical, vec![true, false, true, true]);
        let faster = heuristic_instance("FAST", 3.0, 0, &[(2, 1.0)]);
        assert_eq!(critical_gain(&faster, &chosen, &arrival, &critical), -4.0);
        let disconnected = heuristic_instance("OTHER", 0.1, 0, &[(1, 0.1)]);
        assert_eq!(
            critical_gain(&disconnected, &chosen, &arrival, &critical),
            0.0
        );
    }

    #[test]
    fn flow_comparison_preserves_incumbent_and_zero_budget_skips_second_stage() {
        let instances = vec![
            heuristic_instance("SLOW", 1.0, 0, &[(1, 5.0)]),
            heuristic_instance("FAST", 3.0, 0, &[(1, 1.0)]),
        ];
        for objective in [MapObjective::AreaDelay, MapObjective::DelayArea] {
            let ps = MapParams {
                objective,
                time_limit_secs: 0.0,
                ..params()
            };
            let original = heuristic_cover(
                &instances,
                &[true, false],
                &[1],
                &ps,
                &mut MapStats::default(),
            )
            .unwrap();
            let mut stats = MapStats::default();
            let combined = heuristic_cover(
                &instances,
                &[true, false],
                &[1],
                &MapParams {
                    flow_compare: true,
                    ..ps.clone()
                },
                &mut stats,
            )
            .unwrap();
            assert!(stats.flow_compare_attempted);
            assert_eq!(
                metrics(&instances, &combined, &[true, false], &[1]),
                metrics(&instances, &original, &[true, false], &[1])
            );
            let mut stats = MapStats::default();
            heuristic_cover(
                &instances,
                &[true, false],
                &[1],
                &MapParams {
                    flow_compare: true,
                    refine_time_secs: 0.0,
                    ..ps
                },
                &mut stats,
            )
            .unwrap();
            assert!(!stats.flow_compare_attempted);
        }
    }

    #[test]
    fn expired_shared_deadline_does_not_restart_recovery() {
        let instances = vec![
            heuristic_instance("SLOW", 1.0, 0, &[(1, 5.0)]),
            heuristic_instance("FAST", 3.0, 0, &[(1, 1.0)]),
        ];
        let mut stats = MapStats::default();
        heuristic_cover_until(
            &instances,
            &[true, false],
            &[1],
            &MapParams {
                objective: MapObjective::DelayArea,
                flow_worklist: true,
                ..params()
            },
            &mut stats,
            Instant::now(),
        )
        .unwrap();
        assert_eq!(stats.refinement_trials, 0);
    }

    #[test]
    fn worklist_reaches_deep_reverse_ordered_cones_and_keeps_timing_objective() {
        let mut instances = Vec::new();
        for s in (1..=80).rev() {
            instances.push(heuristic_instance("FAST", 2.0, s - 1, &[(s, 1.0)]));
            instances.push(heuristic_instance("SLOW", 1.0, s - 1, &[(s, 3.0)]));
        }
        let mut free = vec![false; 81];
        free[0] = true;
        let refs = vec![1.0; 81];
        let deadline = Instant::now() + std::time::Duration::from_secs(2);
        let (sweeps, _) = flow_choices(
            &instances,
            &free,
            &refs,
            0.0,
            false,
            false,
            MapObjective::DelayArea,
            deadline,
        );
        assert!(sweeps[80].is_none());
        for (objective, expected) in [
            (MapObjective::AreaDelay, (80.0, 240.0)),
            (MapObjective::DelayArea, (160.0, 80.0)),
        ] {
            let (mut chosen, _) = flow_choices_worklist(
                &instances, &free, &refs, 0.0, false, false, objective, deadline,
            );
            assert!(chosen[80].is_some());
            prune(&instances, &mut chosen, &free, &[80]).unwrap();
            assert_eq!(metrics(&instances, &chosen, &free, &[80]), expected);
        }
    }

    #[test]
    fn lexicographic_objectives_choose_primary_then_secondary_with_and_without_cbc() {
        let instances = vec![
            heuristic_instance("SLOW_CHEAP", 1.0, 0, &[(1, 8.0)]),
            heuristic_instance("FAST_EXPENSIVE", 4.0, 0, &[(1, 2.0)]),
            heuristic_instance("FAST_CHEAPER", 3.0, 0, &[(1, 2.0)]),
        ];
        for time_limit_secs in [0.0, 5.0] {
            for (objective, expected, max_delay) in [
                (MapObjective::AreaDelay, (1.0, 8.0), None),
                (MapObjective::DelayArea, (3.0, 2.0), None),
                (MapObjective::AreaDelay, (3.0, 2.0), Some(4.0)),
            ] {
                let ps = MapParams {
                    objective,
                    time_limit_secs,
                    max_delay,
                    ..params()
                };
                let mut stats = MapStats::default();
                let chosen = extract(&instances, &[true, false], &[1], &ps, &mut stats).unwrap();
                assert_eq!(metrics(&instances, &chosen, &[true, false], &[1]), expected);
                if time_limit_secs > 0.0 {
                    assert!(stats.proven_optimal, "{:?}", stats);
                }
            }
        }
        let delay_first = MapParams {
            objective: MapObjective::DelayArea,
            ..params()
        };
        assert!(better_cover((1e9, 1.0), (1.0, 1.001), &delay_first));
        assert!(!better_cover((0.001, 1.001), (1.0, 1.0), &delay_first));
    }

    #[test]
    fn equal_area_flow_prefers_faster_pin_independent_of_candidate_order() {
        for reversed in [false, true] {
            let mut instances = vec![
                heuristic_instance("SLOW", 1.0, 0, &[(1, 8.0)]),
                heuristic_instance("FAST", 1.0, 0, &[(1, 2.0)]),
            ];
            if reversed {
                instances.reverse();
            }
            let (chosen, _) = flow_choices(
                &instances,
                &[true, false],
                &[1.0, 1.0],
                0.0,
                false,
                true,
                MapObjective::Weighted,
                Instant::now() + std::time::Duration::from_secs(1),
            );
            assert_eq!(instances[chosen[1].unwrap().instance].cell, "FAST");
        }
    }

    #[test]
    fn physical_refs_count_shared_cell_inputs_once_and_each_physical_consumer() {
        let instances = vec![
            heuristic_instance("PAIR", 1.0, 0, &[(1, 1.0), (2, 1.0)]),
            heuristic_instance("A", 1.0, 1, &[(3, 1.0)]),
            heuristic_instance("B", 1.0, 1, &[(4, 1.0)]),
        ];
        let chosen = vec![
            None,
            Some(Binding {
                instance: 0,
                pin: 0,
            }),
            Some(Binding {
                instance: 0,
                pin: 1,
            }),
            Some(Binding {
                instance: 1,
                pin: 0,
            }),
            Some(Binding {
                instance: 2,
                pin: 0,
            }),
        ];
        let refs = physical_refs(&instances, &chosen, &[2, 3, 4, 4]);
        assert_eq!(refs, vec![1.0, 2.0, 1.0, 1.0, 1.0]);
    }

    #[test]
    fn cone_reclaim_counts_shared_multioutput_cell_only_after_both_outputs_die() {
        let instances = vec![
            heuristic_instance("PAIR", 4.0, 0, &[(1, 1.0), (2, 1.0)]),
            heuristic_instance("A", 1.0, 1, &[(3, 1.0)]),
            heuristic_instance("B", 1.0, 2, &[(4, 1.0)]),
        ];
        let chosen = vec![
            None,
            Some(Binding {
                instance: 0,
                pin: 0,
            }),
            Some(Binding {
                instance: 0,
                pin: 1,
            }),
            Some(Binding {
                instance: 1,
                pin: 0,
            }),
            Some(Binding {
                instance: 2,
                pin: 0,
            }),
        ];
        let free = [true, false, false, false, false];
        let refs = [1, 1, 1, 1, 1];
        let users = [2, 1, 1];
        assert_eq!(
            reclaimable_area(&[3], &instances, &chosen, &free, &refs, &users),
            1.0
        );
        assert_eq!(
            reclaimable_area(&[3, 4], &instances, &chosen, &free, &refs, &users),
            6.0
        );
        assert_eq!(
            reclaimable_area(&[3, 3, 4], &instances, &chosen, &free, &refs, &users),
            6.0
        );
    }

    #[test]
    fn flow_warm_start_finds_joint_sharing_that_independent_tree_cost_misses() {
        let instances = vec![
            heuristic_instance("SHARED", 4.0, 0, &[(1, 1.0)]),
            heuristic_instance("DIRECT_A", 4.0, 0, &[(2, 1.0)]),
            heuristic_instance("REUSE_A", 1.0, 1, &[(2, 1.0)]),
            heuristic_instance("DIRECT_B", 4.0, 0, &[(3, 1.0)]),
            heuristic_instance("REUSE_B", 1.0, 1, &[(3, 1.0)]),
        ];
        let free = [true, false, false, false];
        let roots = [2, 3];
        let initial = fallback(&instances, &free, &roots).unwrap();
        assert_eq!(metrics(&instances, &initial, &free, &roots).0, 8.0);
        let mut stats = MapStats::default();
        let ps = MapParams {
            time_limit_secs: 0.0,
            structural_refs: true,
            ..params()
        };
        let recovered = extract(&instances, &free, &roots, &ps, &mut stats).unwrap();
        assert_eq!(metrics(&instances, &recovered, &free, &roots).0, 6.0);
        assert_eq!(stats.initial_area, 8.0);
        assert_eq!(stats.heuristic_area, 6.0);
    }

    #[test]
    fn exact_recovery_changes_multiple_outputs_as_one_physical_instance() {
        let instances = vec![
            heuristic_instance("A", 3.0, 0, &[(1, 1.0)]),
            heuristic_instance("B", 3.0, 0, &[(2, 1.0)]),
            heuristic_instance("BOTH", 4.0, 0, &[(1, 1.0), (2, 1.0)]),
        ];
        let mut stats = MapStats::default();
        let ps = MapParams {
            time_limit_secs: 0.0,
            ..params()
        };
        let recovered =
            extract(&instances, &[true, false, false], &[1, 2], &ps, &mut stats).unwrap();
        assert_eq!(stats.initial_area, 6.0);
        assert_eq!(stats.heuristic_area, 4.0);
        assert!(stats.refinement_accepted > 0);
        assert_eq!(
            recovered[1].unwrap().instance,
            recovered[2].unwrap().instance
        );
    }

    #[test]
    fn recovery_can_use_only_the_fast_pin_under_a_hard_delay_limit() {
        let instances = vec![
            heuristic_instance("A", 3.0, 0, &[(1, 1.0)]),
            heuristic_instance("B", 3.0, 0, &[(2, 1.0)]),
            heuristic_instance("PAIR", 0.5, 0, &[(1, 1.0), (2, 8.0)]),
        ];
        let mut stats = MapStats::default();
        let ps = MapParams {
            max_delay: Some(4.0),
            time_limit_secs: 0.0,
            ..params()
        };
        // The old first-feasible cover picks both pins and violates the bound. Recovery must find
        // a mixed cover rather than return that infeasible seed or insist on using both pins.
        let recovered =
            extract(&instances, &[true, false, false], &[1, 2], &ps, &mut stats).unwrap();
        let (area, delay) = metrics(&instances, &recovered, &[true, false, false], &[1, 2]);
        assert_eq!(area, 3.5);
        assert_eq!(delay, 1.0);
    }

    #[test]
    fn disabled_recovery_preserves_the_original_finite_cover() {
        let instances = vec![heuristic_instance("BUF", 1.0, 0, &[(1, 1.0)])];
        let ps = MapParams {
            refine_time_secs: 0.0,
            time_limit_secs: 0.0,
            ..params()
        };
        let mut stats = MapStats::default();
        let recovered = extract(&instances, &[true, false], &[1], &ps, &mut stats).unwrap();
        assert_eq!(metrics(&instances, &recovered, &[true, false], &[1]).0, 1.0);
        assert_eq!(stats.refinement_trials, 0);
    }

    #[test]
    fn three_output_cell_and_pin_symmetry_preserve_all_outputs() {
        let lib = library(
            "GATE THREE 0.5 Y=A*B;\nPIN A NONINV 1 99 1 0 1 0\nPIN B NONINV 1 99 1 0 1 0\n\
            GATE THREE 0.5 Z=A+B;\nPIN A NONINV 1 99 2 0 2 0\nPIN B NONINV 1 99 2 0 2 0\n\
            GATE THREE 0.5 W=A*!B+!A*B;\nPIN A UNKNOWN 1 99 3 0 3 0\nPIN B UNKNOWN 1 99 3 0 3 0\n",
        );
        let mut aig = graph();
        let a = input(&mut aig, 1);
        let b = input(&mut aig, 2);
        let x = and(&mut aig, a, b);
        let y = or(&mut aig, a, b);
        let z = xor(&mut aig, a, b);
        output(&mut aig, x, 0);
        output(&mut aig, y, 1);
        output(&mut aig, z, 2);
        let mapped = map(&aig, &lib, &params()).unwrap();
        assert_function(&mapped, 2, |a| vec![a == 3, a != 0, a == 1 || a == 2]);
        assert!((mapped.area - 0.5).abs() < 1e-6);
        let used: HashSet<_> = mapped
            .chosen
            .iter()
            .flatten()
            .map(|b| (b.instance, b.pin))
            .collect();
        assert_eq!(used.len(), 3);
    }

    #[test]
    #[ignore = "requires Yosys and ABC executables"]
    fn emitted_multioutput_netlist_passes_cec_and_corrupted_netlist_fails() {
        let root = std::path::Path::new(env!("CARGO_MANIFEST_DIR")).join("tests/fixtures");
        let library = TechLib::from_genlib(root.join("egraph_map.genlib"), 6).unwrap();
        let golden = root.join("full_adder.aag");
        let aig = Aig::from_aiger(golden.to_str().unwrap());
        let mapped = map(&aig, &library, &params()).unwrap();
        let path = std::env::temp_dir().join(format!("egm_verify_test_{}.v", std::process::id()));
        mapped
            .write_verilog(std::fs::File::create(&path).unwrap(), "mapped")
            .unwrap();
        assert!(verify_with_models(&library, &golden, &path).unwrap());
        let text = std::fs::read_to_string(&path).unwrap();
        let corrupted = text
            .lines()
            .map(|line| {
                if line.contains("assign sum =") {
                    "  assign sum = 1'b0;"
                } else {
                    line
                }
            })
            .collect::<Vec<_>>()
            .join("\n");
        std::fs::write(&path, corrupted).unwrap();
        assert!(!verify_with_models(&library, &golden, &path).unwrap());
        let unnamed = path.with_extension("aag");
        let source = std::fs::read_to_string(&golden).unwrap();
        let source = source
            .lines()
            .filter(|line| {
                line.starts_with("aag ") || line.as_bytes().first().is_some_and(u8::is_ascii_digit)
            })
            .collect::<Vec<_>>()
            .join("\n");
        std::fs::write(&unnamed, format!("{source}\n")).unwrap();
        let anonymous = Aig::from_aiger(unnamed.to_str().unwrap());
        let anonymous = map(&anonymous, &library, &params()).unwrap();
        anonymous
            .write_verilog(std::fs::File::create(&path).unwrap(), "mapped")
            .unwrap();
        assert!(verify_with_models(&library, &unnamed, &path).unwrap());
        std::fs::remove_file(unnamed).unwrap();
        std::fs::remove_file(path).unwrap();
    }

    #[test]
    #[ignore = "requires Yosys and ABC executables"]
    fn named_port_cec_handles_large_scripts_and_rejects_wrong_indexed_output() {
        let n=1200usize;
        let directory=std::env::temp_dir().join(format!("egm_largeports_test_{}",std::process::id()));
        std::fs::create_dir_all(&directory).unwrap();
        let golden=directory.join("golden.aag");let mapped=directory.join("mapped.v");
        let mut aag=format!("aag {n} {n} 0 {n} 0\n");
        for v in 1..=n {aag.push_str(&format!("{}\n",2*v));}
        for v in 1..=n {aag.push_str(&format!("{}\n",2*v+1));}
        for i in 0..n {aag.push_str(&format!("i{i} a[{i}]\n"));}
        for i in 0..n {aag.push_str(&format!("o{i} y[{i}]\n"));}
        std::fs::write(&golden,aag).unwrap();
        let ports=(0..n).flat_map(|i|[format!("\\a[{i}] "),format!("\\y[{i}] ")]).collect::<Vec<_>>();
        let mut text=format!("module mapped({});\n",ports.join(","));
        for i in 0..n {text.push_str(&format!("input \\a[{i}] ; output \\y[{i}] ; assign \\y[{i}] = ~\\a[{i}] ;\n"));}
        text.push_str("endmodule\n");std::fs::write(&mapped,&text).unwrap();
        assert!(verify_with_verilog_models("",&golden,&mapped).unwrap());
        let broken=text.replace("assign \\y[0] = ~\\a[0] ;","assign \\y[0] = ~\\a[1] ;");
        assert_ne!(text,broken);std::fs::write(&mapped,broken).unwrap();
        assert!(!verify_with_verilog_models("",&golden,&mapped).unwrap());
        std::fs::remove_dir_all(directory).unwrap();
    }

    #[test]
    fn extraction_uses_sharing_exposed_by_an_alternative_egraph_realization() {
        let mut aig = graph();
        let a = input(&mut aig, 1);
        let b = input(&mut aig, 2);
        let c = input(&mut aig, 3);
        let ab = and(&mut aig, a, b);
        let ac = and(&mut aig, a, c);
        let root = and(&mut aig, ab, ac);
        let bc = and(&mut aig, b, c);
        output(&mut aig, root, 0);
        output(&mut aig, bc, 1);
        let lib = library("");
        let mut no_factor = params();
        no_factor.saturation.use_factoring = false;
        let original = map(&aig, &lib, &no_factor).unwrap();
        let factored = map(&aig, &lib, &params()).unwrap();
        assert_function(&factored, 3, |a| vec![a == 7, a & 6 == 6]);
        assert!((factored.area - 2.0).abs() < 1e-6);
        assert!(factored.area < original.area - 1e-6);
    }

    #[test]
    fn simultaneous_sdc_and_multioutput_matches_preserve_all_primary_input_assignments() {
        let lib = library(
            "GATE PAIR 0.9 Y=A*B;\nPIN A NONINV 1 99 1 0 1 0\nPIN B NONINV 1 99 1 0 1 0\n\
            GATE PAIR 0.9 Z=!(A*B);\nPIN A INV 1 99 2 0 2 0\nPIN B INV 1 99 2 0 2 0\n",
        );
        let mut seed = 12345u64;
        for case in 0..3 {
            let mut aig = graph();
            let mut signals = Vec::new();
            for i in 0..4 {
                let s = input(&mut aig, i + 1);
                let mut tt = 0u16;
                for a in 0..16 {
                    tt |= (((a >> i) & 1) as u16) << a;
                }
                signals.push((s, tt));
            }
            for _ in 0..8 {
                seed = seed.wrapping_mul(6364136223846793005).wrapping_add(1);
                let (a, ta) = signals[(seed >> 16) as usize % signals.len()];
                seed = seed.wrapping_mul(6364136223846793005).wrapping_add(1);
                let (mut b, mut tb) = signals[(seed >> 16) as usize % signals.len()];
                if seed & 1 != 0 {
                    b = inv(b);
                    tb = !tb;
                }
                signals.push((and(&mut aig, a, b), ta & tb));
            }
            let expected: Vec<_> = signals.iter().rev().take(3).map(|(_, tt)| *tt).collect();
            for (pos, &(s, _)) in signals.iter().rev().take(3).enumerate() {
                output(&mut aig, s, pos as u32);
            }
            let ps = MapParams {
                max_inputs: 3,
                dc_support: 4,
                time_limit_secs: if case == 0 { 3.0 } else { 0.0 },
                ..params()
            };
            let precise = map(
                &aig,
                &lib,
                &MapParams {
                    dc_support: 0,
                    ..ps.clone()
                },
            )
            .unwrap();
            assert_function(&precise, 4, |a| {
                expected.iter().map(|tt| (tt >> a) & 1 != 0).collect()
            });
            let (rebuilt, _) = crate::egraph_sat::restructure(
                &aig,
                &SatParams {
                    require_improvement: false,
                    ..Default::default()
                },
            )
            .unwrap();
            let rebuilt_cover = map(
                &rebuilt,
                &lib,
                &MapParams {
                    dc_support: 0,
                    time_limit_secs: 0.0,
                    ..ps.clone()
                },
            )
            .unwrap();
            assert_function(&rebuilt_cover, 4, |a| {
                expected.iter().map(|tt| (tt >> a) & 1 != 0).collect()
            });
            let mapped = map(&aig, &lib, &ps).unwrap();
            assert_function(&mapped, 4, |a| {
                expected.iter().map(|tt| (tt >> a) & 1 != 0).collect()
            });
        }
    }
}
