// Benchmark "/home/flynn/workplace/MIGBalance/tools/mockturtle/experiments/benchmarks/c17" written by ABC on Wed Oct  7 15:25:03 2026

module \/home/flynn/workplace/MIGBalance/tools/mockturtle/experiments/benchmarks/c17  ( 
    pi0, pi1, pi2, pi3, pi4,
    po0, po1  );
  input  pi0, pi1, pi2, pi3, pi4;
  output po0, po1;
  wire new_n8_, new_n9_, new_n10_, new_n11_;
  INVx1_ASAP7_75t_R   g0(.A(pi2), .Y(new_n8_));
  NAND2x1_ASAP7_75t_R g1(.A(pi0), .B(pi1), .Y(new_n9_));
  AND2x2_ASAP7_75t_R  g2(.A(pi1), .B(pi3), .Y(new_n10_));
  NAND2x1_ASAP7_75t_R g3(.A(pi1), .B(pi3), .Y(new_n11_));
  OAI21x1_ASAP7_75t_R g4(.A1(new_n8_), .A2(new_n10_), .B(new_n9_), .Y(po0));
  OA21x2_ASAP7_75t_R  g5(.A1(pi2), .A2(pi4), .B(new_n11_), .Y(po1));
endmodule


