// Benchmark "/home/flynn/workplace/MIGBalance/tools/mockturtle/experiments/benchmarks/c17" written by ABC on Wed Oct  7 15:25:03 2026

module \/home/flynn/workplace/MIGBalance/tools/mockturtle/experiments/benchmarks/c17  ( 
    G1, G3, G2, G4, G5,
    G16, G17  );
  input  G1, G3, G2, G4, G5;
  output G16, G17;
  wire new_n8_, new_n9_;
  AND2x2_ASAP7_75t_R  g0(.A(G1), .B(G3), .Y(new_n8_));
  NAND2x1_ASAP7_75t_R g1(.A(G3), .B(G4), .Y(new_n9_));
  AO21x1_ASAP7_75t_R  g2(.A1(new_n9_), .A2(G2), .B(new_n8_), .Y(G16));
  OA21x2_ASAP7_75t_R  g3(.A1(G2), .A2(G5), .B(new_n9_), .Y(G17));
endmodule


