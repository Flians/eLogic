// Benchmark "/home/flynn/workplace/MIGBalance/results_v2/fixed_4in_area_20261012/c432.resyn2" written by ABC on Mon Oct 12 15:01:44 2026

module \/home/flynn/workplace/MIGBalance/results_v2/fixed_4in_area_20261012/c432.resyn2  ( 
    G32, G34, G28, G30, G24, G26, G20, G22, G16, G18, G12, G14, G8, G10,
    G4, G6, G1, G2, G35, G31, G27, G23, G19, G15, G11, G7, G3, G36, G33,
    G29, G25, G21, G17, G13, G9, G5,
    G426, G427, G428, G429, G430, G431, G432  );
  input  G32, G34, G28, G30, G24, G26, G20, G22, G16, G18, G12, G14, G8,
    G10, G4, G6, G1, G2, G35, G31, G27, G23, G19, G15, G11, G7, G3, G36,
    G33, G29, G25, G21, G17, G13, G9, G5;
  output G426, G427, G428, G429, G430, G431, G432;
  wire new_n44_, new_n45_, new_n46_, new_n47_, new_n48_, new_n49_, new_n50_,
    new_n51_, new_n52_, new_n53_, new_n54_, new_n55_, new_n56_, new_n57_,
    new_n58_, new_n59_, new_n61_, new_n62_, new_n63_, new_n64_, new_n65_,
    new_n66_, new_n67_, new_n68_, new_n69_, new_n70_, new_n71_, new_n72_,
    new_n73_, new_n74_, new_n75_, new_n76_, new_n77_, new_n78_, new_n79_,
    new_n80_, new_n81_, new_n82_, new_n83_, new_n84_, new_n85_, new_n86_,
    new_n87_, new_n89_, new_n90_, new_n91_, new_n92_, new_n93_, new_n94_,
    new_n95_, new_n96_, new_n97_, new_n98_, new_n99_, new_n100_, new_n101_,
    new_n102_, new_n103_, new_n104_, new_n105_, new_n106_, new_n107_,
    new_n108_, new_n109_, new_n110_, new_n111_, new_n112_, new_n113_,
    new_n114_, new_n115_, new_n117_, new_n118_, new_n119_, new_n120_,
    new_n121_, new_n122_, new_n123_, new_n124_, new_n125_, new_n126_,
    new_n127_, new_n128_, new_n129_, new_n130_, new_n131_, new_n132_,
    new_n133_, new_n134_, new_n137_, new_n138_, new_n139_, new_n141_,
    new_n142_, new_n143_;
  INVx1_ASAP7_75t_R    g000(.A(G18), .Y(new_n44_));
  INVx1_ASAP7_75t_R    g001(.A(G20), .Y(new_n45_));
  INVx1_ASAP7_75t_R    g002(.A(G12), .Y(new_n46_));
  AOI22x1_ASAP7_75t_R  g003(.A1(new_n45_), .A2(G22), .B1(new_n46_), .B2(G14), .Y(new_n47_));
  OA21x2_ASAP7_75t_R   g004(.A1(G16), .A2(new_n44_), .B(new_n47_), .Y(new_n48_));
  INVx1_ASAP7_75t_R    g005(.A(G32), .Y(new_n49_));
  INVx1_ASAP7_75t_R    g006(.A(G28), .Y(new_n50_));
  AOI22x1_ASAP7_75t_R  g007(.A1(new_n49_), .A2(G34), .B1(new_n50_), .B2(G30), .Y(new_n51_));
  INVx1_ASAP7_75t_R    g008(.A(G10), .Y(new_n52_));
  INVx1_ASAP7_75t_R    g009(.A(G24), .Y(new_n53_));
  NAND2x1_ASAP7_75t_R  g010(.A(G26), .B(new_n53_), .Y(new_n54_));
  INVx1_ASAP7_75t_R    g011(.A(G4), .Y(new_n55_));
  INVx1_ASAP7_75t_R    g012(.A(G1), .Y(new_n56_));
  AOI22x1_ASAP7_75t_R  g013(.A1(new_n55_), .A2(G6), .B1(new_n56_), .B2(G2), .Y(new_n57_));
  OA211x2_ASAP7_75t_R  g014(.A1(G8), .A2(new_n52_), .B(new_n57_), .C(new_n54_), .Y(new_n58_));
  AND3x1_ASAP7_75t_R   g015(.A(new_n58_), .B(new_n48_), .C(new_n51_), .Y(new_n59_));
  INVx1_ASAP7_75t_R    g016(.A(new_n59_), .Y(G426));
  INVx1_ASAP7_75t_R    g017(.A(G11), .Y(new_n61_));
  INVx1_ASAP7_75t_R    g018(.A(G31), .Y(new_n62_));
  OA21x2_ASAP7_75t_R   g019(.A1(new_n59_), .A2(new_n50_), .B(G30), .Y(new_n63_));
  AND2x2_ASAP7_75t_R   g020(.A(new_n63_), .B(new_n62_), .Y(new_n64_));
  INVx1_ASAP7_75t_R    g021(.A(G27), .Y(new_n65_));
  XNOR2x2_ASAP7_75t_R  g022(.A(new_n54_), .B(new_n59_), .Y(new_n66_));
  AND3x1_ASAP7_75t_R   g023(.A(new_n66_), .B(G26), .C(new_n65_), .Y(new_n67_));
  AOI21x1_ASAP7_75t_R  g024(.A1(G8), .A2(G426), .B(new_n52_), .Y(new_n68_));
  AOI211x1_ASAP7_75t_R g025(.A1(new_n61_), .A2(new_n68_), .B(new_n67_), .C(new_n64_), .Y(new_n69_));
  INVx1_ASAP7_75t_R    g026(.A(G23), .Y(new_n70_));
  INVx1_ASAP7_75t_R    g027(.A(G15), .Y(new_n71_));
  OA21x2_ASAP7_75t_R   g028(.A1(new_n59_), .A2(new_n45_), .B(G22), .Y(new_n72_));
  OA21x2_ASAP7_75t_R   g029(.A1(new_n59_), .A2(new_n46_), .B(G14), .Y(new_n73_));
  AOI22x1_ASAP7_75t_R  g030(.A1(new_n72_), .A2(new_n70_), .B1(new_n73_), .B2(new_n71_), .Y(new_n74_));
  INVx1_ASAP7_75t_R    g031(.A(G19), .Y(new_n75_));
  INVx1_ASAP7_75t_R    g032(.A(G3), .Y(new_n76_));
  AO21x1_ASAP7_75t_R   g033(.A1(G426), .A2(G16), .B(new_n44_), .Y(new_n77_));
  INVx1_ASAP7_75t_R    g034(.A(new_n77_), .Y(new_n78_));
  OA21x2_ASAP7_75t_R   g035(.A1(new_n59_), .A2(new_n56_), .B(G2), .Y(new_n79_));
  AO22x1_ASAP7_75t_R   g036(.A1(new_n78_), .A2(new_n75_), .B1(new_n79_), .B2(new_n76_), .Y(new_n80_));
  INVx1_ASAP7_75t_R    g037(.A(G35), .Y(new_n81_));
  INVx1_ASAP7_75t_R    g038(.A(G7), .Y(new_n82_));
  OA21x2_ASAP7_75t_R   g039(.A1(new_n59_), .A2(new_n49_), .B(G34), .Y(new_n83_));
  OA21x2_ASAP7_75t_R   g040(.A1(new_n59_), .A2(new_n55_), .B(G6), .Y(new_n84_));
  AO22x1_ASAP7_75t_R   g041(.A1(new_n83_), .A2(new_n81_), .B1(new_n84_), .B2(new_n82_), .Y(new_n85_));
  NOR2x1_ASAP7_75t_R   g042(.A(new_n85_), .B(new_n80_), .Y(new_n86_));
  AND3x1_ASAP7_75t_R   g043(.A(new_n86_), .B(new_n69_), .C(new_n74_), .Y(new_n87_));
  INVx1_ASAP7_75t_R    g044(.A(new_n87_), .Y(G427));
  INVx1_ASAP7_75t_R    g045(.A(G21), .Y(new_n89_));
  OA21x2_ASAP7_75t_R   g046(.A1(new_n87_), .A2(new_n75_), .B(new_n78_), .Y(new_n90_));
  INVx1_ASAP7_75t_R    g047(.A(G25), .Y(new_n91_));
  INVx1_ASAP7_75t_R    g048(.A(G17), .Y(new_n92_));
  OA21x2_ASAP7_75t_R   g049(.A1(new_n87_), .A2(new_n70_), .B(new_n72_), .Y(new_n93_));
  OA21x2_ASAP7_75t_R   g050(.A1(new_n87_), .A2(new_n71_), .B(new_n73_), .Y(new_n94_));
  AO22x1_ASAP7_75t_R   g051(.A1(new_n93_), .A2(new_n91_), .B1(new_n94_), .B2(new_n92_), .Y(new_n95_));
  AOI21x1_ASAP7_75t_R  g052(.A1(new_n89_), .A2(new_n90_), .B(new_n95_), .Y(new_n96_));
  INVx1_ASAP7_75t_R    g053(.A(G9), .Y(new_n97_));
  INVx1_ASAP7_75t_R    g054(.A(G5), .Y(new_n98_));
  OA21x2_ASAP7_75t_R   g055(.A1(new_n87_), .A2(new_n82_), .B(new_n84_), .Y(new_n99_));
  OA21x2_ASAP7_75t_R   g056(.A1(new_n87_), .A2(new_n76_), .B(new_n79_), .Y(new_n100_));
  AOI22x1_ASAP7_75t_R  g057(.A1(new_n99_), .A2(new_n97_), .B1(new_n100_), .B2(new_n98_), .Y(new_n101_));
  INVx1_ASAP7_75t_R    g058(.A(G36), .Y(new_n102_));
  OA21x2_ASAP7_75t_R   g059(.A1(new_n87_), .A2(new_n62_), .B(new_n63_), .Y(new_n103_));
  AOI21x1_ASAP7_75t_R  g060(.A1(new_n64_), .A2(new_n87_), .B(G33), .Y(new_n104_));
  OA21x2_ASAP7_75t_R   g061(.A1(new_n87_), .A2(new_n81_), .B(new_n83_), .Y(new_n105_));
  AOI22x1_ASAP7_75t_R  g062(.A1(new_n105_), .A2(new_n102_), .B1(new_n103_), .B2(new_n104_), .Y(new_n106_));
  INVx1_ASAP7_75t_R    g063(.A(G13), .Y(new_n107_));
  OA21x2_ASAP7_75t_R   g064(.A1(new_n87_), .A2(new_n61_), .B(new_n68_), .Y(new_n108_));
  NAND2x1_ASAP7_75t_R  g065(.A(new_n107_), .B(new_n108_), .Y(new_n109_));
  INVx1_ASAP7_75t_R    g066(.A(G29), .Y(new_n110_));
  AND3x1_ASAP7_75t_R   g067(.A(new_n66_), .B(G26), .C(new_n110_), .Y(new_n111_));
  OAI21x1_ASAP7_75t_R  g068(.A1(new_n67_), .A2(new_n87_), .B(new_n111_), .Y(new_n112_));
  AO21x1_ASAP7_75t_R   g069(.A1(new_n67_), .A2(new_n87_), .B(new_n112_), .Y(new_n113_));
  AND4x2_ASAP7_75t_R   g070(.A(new_n101_), .B(new_n106_), .C(new_n109_), .D(new_n113_), .Y(new_n114_));
  AND2x2_ASAP7_75t_R   g071(.A(new_n114_), .B(new_n96_), .Y(new_n115_));
  INVx1_ASAP7_75t_R    g072(.A(new_n115_), .Y(G428));
  OA21x2_ASAP7_75t_R   g073(.A1(new_n115_), .A2(new_n98_), .B(new_n100_), .Y(new_n117_));
  OAI21x1_ASAP7_75t_R  g074(.A1(new_n89_), .A2(new_n115_), .B(new_n90_), .Y(new_n118_));
  OA21x2_ASAP7_75t_R   g075(.A1(new_n115_), .A2(new_n92_), .B(new_n94_), .Y(new_n119_));
  INVx1_ASAP7_75t_R    g076(.A(new_n119_), .Y(new_n120_));
  NAND2x1_ASAP7_75t_R  g077(.A(new_n118_), .B(new_n120_), .Y(new_n121_));
  OA21x2_ASAP7_75t_R   g078(.A1(new_n115_), .A2(new_n107_), .B(new_n108_), .Y(new_n122_));
  OA21x2_ASAP7_75t_R   g079(.A1(new_n115_), .A2(new_n97_), .B(new_n99_), .Y(new_n123_));
  OR2x4_ASAP7_75t_R    g080(.A(new_n122_), .B(new_n123_), .Y(new_n124_));
  NOR2x1_ASAP7_75t_R   g081(.A(new_n124_), .B(new_n121_), .Y(new_n125_));
  OAI21x1_ASAP7_75t_R  g082(.A1(new_n102_), .A2(new_n115_), .B(new_n105_), .Y(new_n126_));
  OAI21x1_ASAP7_75t_R  g083(.A1(new_n53_), .A2(new_n59_), .B(G26), .Y(new_n127_));
  AO21x1_ASAP7_75t_R   g084(.A1(G427), .A2(G27), .B(new_n127_), .Y(new_n128_));
  AO21x1_ASAP7_75t_R   g085(.A1(G428), .A2(G29), .B(new_n128_), .Y(new_n129_));
  OA21x2_ASAP7_75t_R   g086(.A1(new_n115_), .A2(new_n91_), .B(new_n93_), .Y(new_n130_));
  INVx1_ASAP7_75t_R    g087(.A(G33), .Y(new_n131_));
  OA21x2_ASAP7_75t_R   g088(.A1(new_n115_), .A2(new_n131_), .B(new_n103_), .Y(new_n132_));
  NOR2x1_ASAP7_75t_R   g089(.A(new_n130_), .B(new_n132_), .Y(new_n133_));
  AND3x1_ASAP7_75t_R   g090(.A(new_n133_), .B(new_n126_), .C(new_n129_), .Y(new_n134_));
  AOI21x1_ASAP7_75t_R  g091(.A1(new_n134_), .A2(new_n125_), .B(new_n117_), .Y(G429));
  INVx1_ASAP7_75t_R    g092(.A(new_n125_), .Y(G430));
  NOR2x1_ASAP7_75t_R   g093(.A(new_n129_), .B(new_n121_), .Y(new_n137_));
  NOR2x1_ASAP7_75t_R   g094(.A(new_n119_), .B(new_n122_), .Y(new_n138_));
  AND3x1_ASAP7_75t_R   g095(.A(new_n138_), .B(new_n118_), .C(new_n130_), .Y(new_n139_));
  OR3x1_ASAP7_75t_R    g096(.A(new_n137_), .B(new_n124_), .C(new_n139_), .Y(G431));
  AND3x1_ASAP7_75t_R   g097(.A(new_n138_), .B(new_n129_), .C(new_n132_), .Y(new_n141_));
  INVx1_ASAP7_75t_R    g098(.A(new_n122_), .Y(new_n142_));
  AO21x1_ASAP7_75t_R   g099(.A1(new_n142_), .A2(new_n119_), .B(new_n123_), .Y(new_n143_));
  OR3x1_ASAP7_75t_R    g100(.A(new_n139_), .B(new_n141_), .C(new_n143_), .Y(G432));
endmodule


