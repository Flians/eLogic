// Benchmark "/home/flynn/workplace/MIGBalance/results_v2/fixed_4in_area_20261012/c880.resyn2" written by ABC on Mon Oct 12 15:02:14 2026

module \/home/flynn/workplace/MIGBalance/results_v2/fixed_4in_area_20261012/c880.resyn2  ( 
    G8, G16, G6, G17, G7, G18, G19, G4, G3, G2, G1, G5, G11, G23, G20, G21,
    G9, G10, G12, G15, G22, G32, G24, G25, G26, G27, G28, G29, G30, G31,
    G33, G41, G42, G43, G44, G45, G46, G47, G48, G49, G13, G14, G55, G59,
    G54, G60, G39, G40, G52, G53, G50, G51, G58, G35, G37, G36, G56, G57,
    G34, G38,
    G855, G856, G857, G858, G859, G860, G861, G862, G863, G864, G865, G866,
    G867, G868, G869, G870, G871, G872, G873, G874, G875, G876, G877, G878,
    G879, G880  );
  input  G8, G16, G6, G17, G7, G18, G19, G4, G3, G2, G1, G5, G11, G23,
    G20, G21, G9, G10, G12, G15, G22, G32, G24, G25, G26, G27, G28, G29,
    G30, G31, G33, G41, G42, G43, G44, G45, G46, G47, G48, G49, G13, G14,
    G55, G59, G54, G60, G39, G40, G52, G53, G50, G51, G58, G35, G37, G36,
    G56, G57, G34, G38;
  output G855, G856, G857, G858, G859, G860, G861, G862, G863, G864, G865,
    G866, G867, G868, G869, G870, G871, G872, G873, G874, G875, G876, G877,
    G878, G879, G880;
  wire new_n109_, new_n112_, new_n119_, new_n121_, new_n123_, new_n124_,
    new_n127_, new_n128_, new_n129_, new_n130_, new_n131_, new_n132_,
    new_n133_, new_n134_, new_n136_, new_n137_, new_n138_, new_n139_,
    new_n140_, new_n141_, new_n142_, new_n143_, new_n145_, new_n146_,
    new_n147_, new_n148_, new_n149_, new_n150_, new_n151_, new_n152_,
    new_n153_, new_n154_, new_n155_, new_n156_, new_n158_, new_n160_,
    new_n161_, new_n162_, new_n163_, new_n164_, new_n165_, new_n166_,
    new_n167_, new_n168_, new_n170_, new_n171_, new_n172_, new_n174_,
    new_n175_, new_n177_, new_n178_, new_n179_, new_n180_, new_n181_,
    new_n182_, new_n183_, new_n184_, new_n185_, new_n186_, new_n187_,
    new_n188_, new_n189_, new_n190_, new_n191_, new_n193_, new_n194_,
    new_n195_, new_n196_, new_n197_, new_n198_, new_n199_, new_n200_,
    new_n202_, new_n204_, new_n205_, new_n206_, new_n207_, new_n208_,
    new_n209_, new_n211_, new_n212_, new_n213_, new_n214_, new_n215_,
    new_n216_, new_n218_, new_n219_, new_n220_, new_n223_, new_n224_,
    new_n225_, new_n226_, new_n227_, new_n228_, new_n229_, new_n230_,
    new_n231_, new_n232_, new_n233_, new_n234_, new_n235_, new_n236_,
    new_n237_, new_n238_, new_n240_, new_n241_, new_n242_, new_n243_,
    new_n244_, new_n245_, new_n247_, new_n248_, new_n249_, new_n250_,
    new_n251_, new_n252_, new_n254_, new_n255_, new_n256_, new_n257_,
    new_n258_, new_n259_, new_n260_, new_n262_, new_n263_, new_n264_,
    new_n265_, new_n266_, new_n267_, new_n268_, new_n270_, new_n271_,
    new_n272_, new_n273_, new_n274_, new_n275_, new_n276_, new_n277_,
    new_n278_, new_n279_, new_n280_, new_n281_, new_n282_, new_n283_,
    new_n284_, new_n285_, new_n286_, new_n287_, new_n289_, new_n290_,
    new_n291_, new_n292_, new_n293_, new_n294_, new_n295_, new_n296_;
  OR3x1_ASAP7_75t_R    g000(.A(new_n271_), .B(new_n272_), .C(new_n270_), .Y(G855));
  OR3x1_ASAP7_75t_R    g001(.A(new_n272_), .B(new_n274_), .C(new_n273_), .Y(G856));
  OR3x1_ASAP7_75t_R    g002(.A(new_n272_), .B(new_n274_), .C(new_n270_), .Y(G857));
  NAND2x1_ASAP7_75t_R  g003(.A(G18), .B(G19), .Y(G858));
  NAND2x1_ASAP7_75t_R  g004(.A(G2), .B(G1), .Y(new_n109_));
  OR3x1_ASAP7_75t_R    g005(.A(new_n275_), .B(new_n276_), .C(new_n109_), .Y(G859));
  AND4x2_ASAP7_75t_R   g006(.A(G4), .B(G3), .C(G1), .D(G5), .Y(new_n112_));
  AND2x2_ASAP7_75t_R   g007(.A(G857), .B(new_n112_), .Y(G860));
  AND3x1_ASAP7_75t_R   g008(.A(G16), .B(G11), .C(G17), .Y(G861));
  AND3x1_ASAP7_75t_R   g009(.A(G7), .B(G11), .C(G17), .Y(G862));
  AND3x1_ASAP7_75t_R   g010(.A(G7), .B(G11), .C(G8), .Y(G863));
  OAI21x1_ASAP7_75t_R  g011(.A1(G20), .A2(G21), .B(G23), .Y(G864));
  AND4x2_ASAP7_75t_R   g012(.A(G6), .B(G7), .C(G8), .D(new_n112_), .Y(G865));
  AND3x1_ASAP7_75t_R   g013(.A(G1), .B(G5), .C(G9), .Y(new_n119_));
  OR3x1_ASAP7_75t_R    g014(.A(new_n276_), .B(new_n279_), .C(new_n109_), .Y(new_n121_));
  OR3x1_ASAP7_75t_R    g015(.A(new_n272_), .B(new_n280_), .C(new_n121_), .Y(G867));
  OR3x1_ASAP7_75t_R    g016(.A(new_n278_), .B(new_n280_), .C(new_n121_), .Y(new_n123_));
  INVx1_ASAP7_75t_R    g017(.A(new_n123_), .Y(new_n124_));
  NAND2x1_ASAP7_75t_R  g018(.A(G15), .B(new_n124_), .Y(G868));
  OAI21x1_ASAP7_75t_R  g019(.A1(G20), .A2(G21), .B(G22), .Y(G869));
  XOR2x2_ASAP7_75t_R   g020(.A(G24), .B(G25), .Y(new_n127_));
  XOR2x2_ASAP7_75t_R   g021(.A(G32), .B(new_n127_), .Y(new_n128_));
  XOR2x2_ASAP7_75t_R   g022(.A(G30), .B(G31), .Y(new_n129_));
  XNOR2x2_ASAP7_75t_R  g023(.A(new_n128_), .B(new_n129_), .Y(new_n130_));
  XOR2x2_ASAP7_75t_R   g024(.A(G28), .B(G29), .Y(new_n131_));
  XOR2x2_ASAP7_75t_R   g025(.A(G33), .B(new_n131_), .Y(new_n132_));
  XNOR2x2_ASAP7_75t_R  g026(.A(G26), .B(G27), .Y(new_n133_));
  XNOR2x2_ASAP7_75t_R  g027(.A(new_n132_), .B(new_n133_), .Y(new_n134_));
  XOR2x2_ASAP7_75t_R   g028(.A(new_n130_), .B(new_n134_), .Y(G870));
  XNOR2x2_ASAP7_75t_R  g029(.A(new_n281_), .B(G42), .Y(new_n136_));
  XOR2x2_ASAP7_75t_R   g030(.A(G32), .B(new_n136_), .Y(new_n137_));
  XOR2x2_ASAP7_75t_R   g031(.A(G47), .B(G48), .Y(new_n138_));
  XNOR2x2_ASAP7_75t_R  g032(.A(new_n137_), .B(new_n138_), .Y(new_n139_));
  XOR2x2_ASAP7_75t_R   g033(.A(G45), .B(G46), .Y(new_n140_));
  XOR2x2_ASAP7_75t_R   g034(.A(G49), .B(new_n140_), .Y(new_n141_));
  XOR2x2_ASAP7_75t_R   g035(.A(G43), .B(new_n282_), .Y(new_n142_));
  XNOR2x2_ASAP7_75t_R  g036(.A(new_n141_), .B(new_n142_), .Y(new_n143_));
  XOR2x2_ASAP7_75t_R   g037(.A(new_n139_), .B(new_n143_), .Y(G871));
  AOI21x1_ASAP7_75t_R  g038(.A1(G11), .A2(G40), .B(G866), .Y(new_n145_));
  AO21x1_ASAP7_75t_R   g039(.A1(G4), .A2(new_n145_), .B(new_n277_), .Y(new_n146_));
  OA211x2_ASAP7_75t_R  g040(.A1(new_n270_), .A2(new_n275_), .B(G11), .C(G40), .Y(new_n147_));
  OA21x2_ASAP7_75t_R   g041(.A1(G8), .A2(G4), .B(new_n147_), .Y(new_n148_));
  OR3x1_ASAP7_75t_R    g042(.A(new_n271_), .B(new_n278_), .C(new_n270_), .Y(new_n149_));
  AND4x2_ASAP7_75t_R   g043(.A(G4), .B(G9), .C(new_n287_), .D(new_n149_), .Y(new_n150_));
  AO21x1_ASAP7_75t_R   g044(.A1(new_n119_), .A2(new_n148_), .B(new_n150_), .Y(new_n151_));
  OR4x2_ASAP7_75t_R    g045(.A(new_n271_), .B(new_n272_), .C(new_n273_), .D(G866), .Y(new_n152_));
  OR3x1_ASAP7_75t_R    g046(.A(new_n279_), .B(G60), .C(new_n152_), .Y(new_n153_));
  INVx1_ASAP7_75t_R    g047(.A(new_n153_), .Y(new_n154_));
  AO21x1_ASAP7_75t_R   g048(.A1(G31), .A2(new_n151_), .B(new_n154_), .Y(new_n155_));
  AO21x1_ASAP7_75t_R   g049(.A1(G39), .A2(new_n146_), .B(new_n155_), .Y(new_n156_));
  NOR2x1_ASAP7_75t_R   g050(.A(new_n283_), .B(new_n289_), .Y(new_n158_));
  AO21x1_ASAP7_75t_R   g051(.A1(new_n283_), .A2(new_n289_), .B(new_n158_), .Y(new_n160_));
  OA21x2_ASAP7_75t_R   g052(.A1(G48), .A2(new_n156_), .B(G58), .Y(new_n161_));
  AO21x1_ASAP7_75t_R   g053(.A1(new_n290_), .A2(new_n161_), .B(new_n285_), .Y(new_n162_));
  AO21x1_ASAP7_75t_R   g054(.A1(new_n286_), .A2(new_n160_), .B(new_n162_), .Y(new_n163_));
  AO21x1_ASAP7_75t_R   g055(.A1(G48), .A2(G53), .B(G54), .Y(new_n164_));
  AND4x2_ASAP7_75t_R   g056(.A(G8), .B(G13), .C(G14), .D(new_n124_), .Y(new_n165_));
  AO22x1_ASAP7_75t_R   g057(.A1(G55), .A2(G59), .B1(G30), .B2(G50), .Y(new_n166_));
  AO21x1_ASAP7_75t_R   g058(.A1(G48), .A2(new_n165_), .B(new_n166_), .Y(new_n167_));
  AOI21x1_ASAP7_75t_R  g059(.A1(new_n156_), .A2(new_n164_), .B(new_n167_), .Y(new_n168_));
  OA211x2_ASAP7_75t_R  g060(.A1(new_n284_), .A2(new_n160_), .B(new_n168_), .C(new_n163_), .Y(G872));
  AO21x1_ASAP7_75t_R   g061(.A1(G35), .A2(new_n146_), .B(new_n154_), .Y(new_n170_));
  AO21x1_ASAP7_75t_R   g062(.A1(G28), .A2(new_n151_), .B(new_n170_), .Y(new_n171_));
  NOR2x1_ASAP7_75t_R   g063(.A(G45), .B(new_n171_), .Y(new_n172_));
  AO21x1_ASAP7_75t_R   g064(.A1(G45), .A2(new_n171_), .B(new_n172_), .Y(new_n174_));
  AO21x1_ASAP7_75t_R   g065(.A1(G48), .A2(new_n156_), .B(new_n161_), .Y(new_n175_));
  AO21x1_ASAP7_75t_R   g066(.A1(G36), .A2(new_n146_), .B(new_n154_), .Y(new_n177_));
  AO21x1_ASAP7_75t_R   g067(.A1(G29), .A2(new_n151_), .B(new_n177_), .Y(new_n178_));
  NOR2x1_ASAP7_75t_R   g068(.A(G46), .B(new_n178_), .Y(new_n179_));
  AO21x1_ASAP7_75t_R   g069(.A1(G37), .A2(new_n146_), .B(new_n154_), .Y(new_n180_));
  AO21x1_ASAP7_75t_R   g070(.A1(G30), .A2(new_n151_), .B(new_n180_), .Y(new_n181_));
  NOR2x1_ASAP7_75t_R   g071(.A(G47), .B(new_n181_), .Y(new_n182_));
  OR3x1_ASAP7_75t_R    g072(.A(new_n179_), .B(new_n182_), .C(new_n291_), .Y(new_n183_));
  NAND2x1_ASAP7_75t_R  g073(.A(G46), .B(new_n178_), .Y(new_n184_));
  NAND2x1_ASAP7_75t_R  g074(.A(G47), .B(new_n181_), .Y(new_n185_));
  OA211x2_ASAP7_75t_R  g075(.A1(new_n179_), .A2(new_n185_), .B(new_n184_), .C(new_n183_), .Y(new_n186_));
  OAI21x1_ASAP7_75t_R  g076(.A1(new_n174_), .A2(new_n186_), .B(G51), .Y(new_n187_));
  AO21x1_ASAP7_75t_R   g077(.A1(new_n174_), .A2(new_n186_), .B(new_n187_), .Y(new_n188_));
  AO21x1_ASAP7_75t_R   g078(.A1(G45), .A2(G53), .B(G54), .Y(new_n189_));
  AO22x1_ASAP7_75t_R   g079(.A1(G45), .A2(new_n165_), .B1(G27), .B2(G50), .Y(new_n190_));
  AOI21x1_ASAP7_75t_R  g080(.A1(new_n171_), .A2(new_n189_), .B(new_n190_), .Y(new_n191_));
  OA211x2_ASAP7_75t_R  g081(.A1(new_n284_), .A2(new_n174_), .B(new_n191_), .C(new_n188_), .Y(G873));
  AO21x1_ASAP7_75t_R   g082(.A1(G46), .A2(new_n178_), .B(new_n179_), .Y(new_n193_));
  OA21x2_ASAP7_75t_R   g083(.A1(new_n291_), .A2(new_n182_), .B(new_n185_), .Y(new_n194_));
  OAI21x1_ASAP7_75t_R  g084(.A1(new_n193_), .A2(new_n194_), .B(G51), .Y(new_n195_));
  AO21x1_ASAP7_75t_R   g085(.A1(new_n193_), .A2(new_n194_), .B(new_n195_), .Y(new_n196_));
  AO21x1_ASAP7_75t_R   g086(.A1(G46), .A2(G53), .B(G54), .Y(new_n197_));
  AO22x1_ASAP7_75t_R   g087(.A1(G55), .A2(G56), .B1(G28), .B2(G50), .Y(new_n198_));
  AO21x1_ASAP7_75t_R   g088(.A1(G46), .A2(new_n165_), .B(new_n198_), .Y(new_n199_));
  AOI21x1_ASAP7_75t_R  g089(.A1(new_n178_), .A2(new_n197_), .B(new_n199_), .Y(new_n200_));
  OA211x2_ASAP7_75t_R  g090(.A1(new_n284_), .A2(new_n193_), .B(new_n200_), .C(new_n196_), .Y(G874));
  AO21x1_ASAP7_75t_R   g091(.A1(G47), .A2(new_n181_), .B(new_n182_), .Y(new_n202_));
  AO21x1_ASAP7_75t_R   g092(.A1(new_n291_), .A2(new_n202_), .B(new_n285_), .Y(new_n204_));
  AO21x1_ASAP7_75t_R   g093(.A1(new_n175_), .A2(new_n292_), .B(new_n204_), .Y(new_n205_));
  AO21x1_ASAP7_75t_R   g094(.A1(G47), .A2(G53), .B(G54), .Y(new_n206_));
  AO22x1_ASAP7_75t_R   g095(.A1(G55), .A2(G57), .B1(G29), .B2(G50), .Y(new_n207_));
  AO21x1_ASAP7_75t_R   g096(.A1(G47), .A2(new_n165_), .B(new_n207_), .Y(new_n208_));
  AOI21x1_ASAP7_75t_R  g097(.A1(new_n181_), .A2(new_n206_), .B(new_n208_), .Y(new_n209_));
  OA211x2_ASAP7_75t_R  g098(.A1(new_n284_), .A2(new_n202_), .B(new_n209_), .C(new_n205_), .Y(G875));
  AND2x2_ASAP7_75t_R   g099(.A(G10), .B(new_n145_), .Y(new_n211_));
  OR3x1_ASAP7_75t_R    g100(.A(new_n275_), .B(G60), .C(new_n152_), .Y(new_n212_));
  INVx1_ASAP7_75t_R    g101(.A(new_n212_), .Y(new_n213_));
  AO21x1_ASAP7_75t_R   g102(.A1(G2), .A2(G34), .B(new_n213_), .Y(new_n214_));
  AO21x1_ASAP7_75t_R   g103(.A1(G35), .A2(new_n211_), .B(new_n214_), .Y(new_n215_));
  AO21x1_ASAP7_75t_R   g104(.A1(G24), .A2(new_n151_), .B(new_n215_), .Y(new_n216_));
  AO21x1_ASAP7_75t_R   g105(.A1(G34), .A2(G38), .B(new_n213_), .Y(new_n218_));
  AO21x1_ASAP7_75t_R   g106(.A1(G39), .A2(new_n211_), .B(new_n218_), .Y(new_n219_));
  AO21x1_ASAP7_75t_R   g107(.A1(G27), .A2(new_n151_), .B(new_n219_), .Y(new_n220_));
  AO21x1_ASAP7_75t_R   g108(.A1(new_n282_), .A2(new_n294_), .B(new_n296_), .Y(new_n223_));
  AO21x1_ASAP7_75t_R   g109(.A1(G4), .A2(G34), .B(new_n213_), .Y(new_n224_));
  AO21x1_ASAP7_75t_R   g110(.A1(G37), .A2(new_n211_), .B(new_n224_), .Y(new_n225_));
  AO21x1_ASAP7_75t_R   g111(.A1(G26), .A2(new_n151_), .B(new_n225_), .Y(new_n226_));
  NOR2x1_ASAP7_75t_R   g112(.A(G43), .B(new_n226_), .Y(new_n227_));
  AO21x1_ASAP7_75t_R   g113(.A1(G9), .A2(G34), .B(new_n213_), .Y(new_n228_));
  AO21x1_ASAP7_75t_R   g114(.A1(G36), .A2(new_n211_), .B(new_n228_), .Y(new_n229_));
  AO21x1_ASAP7_75t_R   g115(.A1(G25), .A2(new_n151_), .B(new_n229_), .Y(new_n230_));
  NOR2x1_ASAP7_75t_R   g116(.A(G42), .B(new_n230_), .Y(new_n231_));
  OR3x1_ASAP7_75t_R    g117(.A(new_n227_), .B(new_n231_), .C(new_n223_), .Y(new_n232_));
  NAND2x1_ASAP7_75t_R  g118(.A(G42), .B(new_n230_), .Y(new_n233_));
  NOR2x1_ASAP7_75t_R   g119(.A(new_n282_), .B(new_n294_), .Y(new_n234_));
  AO21x1_ASAP7_75t_R   g120(.A1(G43), .A2(new_n226_), .B(new_n234_), .Y(new_n235_));
  OAI21x1_ASAP7_75t_R  g121(.A1(G43), .A2(new_n226_), .B(new_n235_), .Y(new_n236_));
  OA211x2_ASAP7_75t_R  g122(.A1(new_n231_), .A2(new_n236_), .B(new_n233_), .C(new_n232_), .Y(new_n237_));
  AO21x1_ASAP7_75t_R   g123(.A1(new_n281_), .A2(new_n293_), .B(new_n237_), .Y(new_n238_));
  OA21x2_ASAP7_75t_R   g124(.A1(new_n281_), .A2(new_n293_), .B(new_n238_), .Y(G876));
  AO21x1_ASAP7_75t_R   g125(.A1(new_n282_), .A2(new_n294_), .B(new_n234_), .Y(new_n240_));
  OAI21x1_ASAP7_75t_R  g126(.A1(new_n296_), .A2(new_n240_), .B(G51), .Y(new_n241_));
  AO21x1_ASAP7_75t_R   g127(.A1(new_n296_), .A2(new_n240_), .B(new_n241_), .Y(new_n242_));
  AO21x1_ASAP7_75t_R   g128(.A1(G44), .A2(G53), .B(G54), .Y(new_n243_));
  AO22x1_ASAP7_75t_R   g129(.A1(G44), .A2(new_n165_), .B1(G26), .B2(G50), .Y(new_n244_));
  AOI21x1_ASAP7_75t_R  g130(.A1(new_n220_), .A2(new_n243_), .B(new_n244_), .Y(new_n245_));
  OA211x2_ASAP7_75t_R  g131(.A1(new_n284_), .A2(new_n240_), .B(new_n245_), .C(new_n242_), .Y(G877));
  AO22x1_ASAP7_75t_R   g132(.A1(G41), .A2(new_n216_), .B1(new_n281_), .B2(new_n293_), .Y(new_n247_));
  OAI21x1_ASAP7_75t_R  g133(.A1(new_n237_), .A2(new_n247_), .B(G51), .Y(new_n248_));
  AO21x1_ASAP7_75t_R   g134(.A1(new_n237_), .A2(new_n247_), .B(new_n248_), .Y(new_n249_));
  AO21x1_ASAP7_75t_R   g135(.A1(G41), .A2(G53), .B(G54), .Y(new_n250_));
  AO22x1_ASAP7_75t_R   g136(.A1(G41), .A2(new_n165_), .B1(G60), .B2(G50), .Y(new_n251_));
  AOI21x1_ASAP7_75t_R  g137(.A1(new_n216_), .A2(new_n250_), .B(new_n251_), .Y(new_n252_));
  OA211x2_ASAP7_75t_R  g138(.A1(new_n284_), .A2(new_n247_), .B(new_n252_), .C(new_n249_), .Y(G878));
  AO21x1_ASAP7_75t_R   g139(.A1(G42), .A2(new_n230_), .B(new_n231_), .Y(new_n254_));
  OA21x2_ASAP7_75t_R   g140(.A1(new_n223_), .A2(new_n227_), .B(new_n236_), .Y(new_n255_));
  OAI21x1_ASAP7_75t_R  g141(.A1(new_n254_), .A2(new_n255_), .B(G51), .Y(new_n256_));
  AO21x1_ASAP7_75t_R   g142(.A1(new_n254_), .A2(new_n255_), .B(new_n256_), .Y(new_n257_));
  AO21x1_ASAP7_75t_R   g143(.A1(G42), .A2(G53), .B(G54), .Y(new_n258_));
  AO22x1_ASAP7_75t_R   g144(.A1(G42), .A2(new_n165_), .B1(G24), .B2(G50), .Y(new_n259_));
  AOI21x1_ASAP7_75t_R  g145(.A1(new_n230_), .A2(new_n258_), .B(new_n259_), .Y(new_n260_));
  OA211x2_ASAP7_75t_R  g146(.A1(new_n284_), .A2(new_n254_), .B(new_n260_), .C(new_n257_), .Y(G879));
  AO21x1_ASAP7_75t_R   g147(.A1(G43), .A2(new_n226_), .B(new_n227_), .Y(new_n262_));
  OA21x2_ASAP7_75t_R   g148(.A1(new_n282_), .A2(new_n294_), .B(new_n223_), .Y(new_n263_));
  OAI21x1_ASAP7_75t_R  g149(.A1(new_n262_), .A2(new_n263_), .B(G51), .Y(new_n264_));
  AO21x1_ASAP7_75t_R   g150(.A1(new_n262_), .A2(new_n263_), .B(new_n264_), .Y(new_n265_));
  AO21x1_ASAP7_75t_R   g151(.A1(G43), .A2(G53), .B(G54), .Y(new_n266_));
  AO22x1_ASAP7_75t_R   g152(.A1(G43), .A2(new_n165_), .B1(G25), .B2(G50), .Y(new_n267_));
  AOI21x1_ASAP7_75t_R  g153(.A1(new_n226_), .A2(new_n266_), .B(new_n267_), .Y(new_n268_));
  OA211x2_ASAP7_75t_R  g154(.A1(new_n284_), .A2(new_n262_), .B(new_n268_), .C(new_n265_), .Y(G880));
  INVx1_ASAP7_75t_R    g155(.A(G8), .Y(new_n270_));
  INVx1_ASAP7_75t_R    g156(.A(G16), .Y(new_n271_));
  INVx1_ASAP7_75t_R    g157(.A(G6), .Y(new_n272_));
  INVx1_ASAP7_75t_R    g158(.A(G17), .Y(new_n273_));
  INVx1_ASAP7_75t_R    g159(.A(G7), .Y(new_n274_));
  INVx1_ASAP7_75t_R    g160(.A(G4), .Y(new_n275_));
  INVx1_ASAP7_75t_R    g161(.A(G3), .Y(new_n276_));
  INVx1_ASAP7_75t_R    g162(.A(G1), .Y(new_n277_));
  INVx1_ASAP7_75t_R    g163(.A(G11), .Y(new_n278_));
  INVx1_ASAP7_75t_R    g164(.A(G10), .Y(new_n279_));
  INVx1_ASAP7_75t_R    g165(.A(G12), .Y(new_n280_));
  INVx1_ASAP7_75t_R    g166(.A(G41), .Y(new_n281_));
  INVx1_ASAP7_75t_R    g167(.A(G44), .Y(new_n282_));
  INVx1_ASAP7_75t_R    g168(.A(G48), .Y(new_n283_));
  INVx1_ASAP7_75t_R    g169(.A(G52), .Y(new_n284_));
  INVx1_ASAP7_75t_R    g170(.A(G51), .Y(new_n285_));
  INVx1_ASAP7_75t_R    g171(.A(G58), .Y(new_n286_));
  INVx1_ASAP7_75t_R    g172(.A(new_n109_), .Y(new_n287_));
  INVx1_ASAP7_75t_R    g173(.A(new_n119_), .Y(G866));
  INVx1_ASAP7_75t_R    g174(.A(new_n156_), .Y(new_n289_));
  INVx1_ASAP7_75t_R    g175(.A(new_n158_), .Y(new_n290_));
  INVx1_ASAP7_75t_R    g176(.A(new_n175_), .Y(new_n291_));
  INVx1_ASAP7_75t_R    g177(.A(new_n202_), .Y(new_n292_));
  INVx1_ASAP7_75t_R    g178(.A(new_n216_), .Y(new_n293_));
  INVx1_ASAP7_75t_R    g179(.A(new_n220_), .Y(new_n294_));
  NAND2x1_ASAP7_75t_R  g180(.A(G45), .B(new_n171_), .Y(new_n295_));
  AO21x1_ASAP7_75t_R   g181(.A1(new_n295_), .A2(new_n186_), .B(new_n172_), .Y(new_n296_));
endmodule


