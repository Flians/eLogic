// Benchmark "/home/flynn/workplace/MIGBalance/results_v2/fixed_4in_area_20261012/c432.resyn2" written by ABC on Mon Oct 12 15:01:46 2026

module \/home/flynn/workplace/MIGBalance/results_v2/fixed_4in_area_20261012/c432.resyn2  ( 
    G32, G34, G28, G30, G24, G26, G20, G22, G16, G18, G12, G14, G8, G10,
    G4, G6, G1, G2, G35, G31, G27, G23, G19, G15, G11, G7, G3, G36, G33,
    G29, G25, G21, G17, G13, G9, G5,
    G426, G427, G428, G429, G430, G431, G432  );
  input  G32, G34, G28, G30, G24, G26, G20, G22, G16, G18, G12, G14, G8,
    G10, G4, G6, G1, G2, G35, G31, G27, G23, G19, G15, G11, G7, G3, G36,
    G33, G29, G25, G21, G17, G13, G9, G5;
  output G426, G427, G428, G429, G430, G431, G432;
  wire new_n53_, new_n54_, new_n55_, new_n56_, new_n58_, new_n59_, new_n60_,
    new_n62_, new_n63_, new_n65_, new_n66_, new_n67_, new_n68_, new_n69_,
    new_n70_, new_n71_, new_n72_, new_n73_, new_n74_, new_n75_, new_n76_,
    new_n77_, new_n79_, new_n80_, new_n81_, new_n82_, new_n83_, new_n84_,
    new_n85_, new_n86_, new_n87_, new_n89_, new_n90_, new_n91_, new_n93_,
    new_n94_, new_n95_, new_n96_, new_n97_, new_n99_, new_n100_, new_n101_,
    new_n102_, new_n104_, new_n108_, new_n109_, new_n110_, new_n112_,
    new_n113_, new_n114_, new_n116_, new_n117_, new_n118_, new_n119_,
    new_n120_, new_n122_, new_n123_, new_n124_, new_n126_, new_n127_,
    new_n128_, new_n129_, new_n130_, new_n131_, new_n132_, new_n133_,
    new_n134_, new_n136_, new_n137_, new_n138_, new_n139_, new_n140_,
    new_n141_, new_n142_;
  NOR2x1_ASAP7_75t_R   g00(.A(G16), .B(new_n130_), .Y(new_n53_));
  OAI22x1_ASAP7_75t_R  g01(.A1(G20), .A2(new_n129_), .B1(G12), .B2(new_n131_), .Y(new_n54_));
  OAI22x1_ASAP7_75t_R  g02(.A1(G32), .A2(new_n126_), .B1(G28), .B2(new_n127_), .Y(new_n55_));
  OR2x4_ASAP7_75t_R    g03(.A(G24), .B(new_n128_), .Y(new_n56_));
  OA22x2_ASAP7_75t_R   g04(.A1(G1), .A2(new_n134_), .B1(G4), .B2(new_n133_), .Y(new_n58_));
  OA211x2_ASAP7_75t_R  g05(.A1(G8), .A2(new_n132_), .B(new_n56_), .C(new_n58_), .Y(new_n59_));
  INVx1_ASAP7_75t_R    g06(.A(new_n59_), .Y(new_n60_));
  OR4x2_ASAP7_75t_R    g07(.A(new_n53_), .B(new_n54_), .C(new_n55_), .D(new_n60_), .Y(G426));
  AO21x1_ASAP7_75t_R   g08(.A1(G28), .A2(G426), .B(new_n127_), .Y(new_n62_));
  OR2x4_ASAP7_75t_R    g09(.A(G31), .B(new_n62_), .Y(new_n63_));
  OR3x1_ASAP7_75t_R    g10(.A(new_n128_), .B(G27), .C(new_n136_), .Y(new_n65_));
  AO21x1_ASAP7_75t_R   g11(.A1(G8), .A2(G426), .B(new_n132_), .Y(new_n66_));
  OA211x2_ASAP7_75t_R  g12(.A1(G11), .A2(new_n66_), .B(new_n65_), .C(new_n63_), .Y(new_n67_));
  AO21x1_ASAP7_75t_R   g13(.A1(G20), .A2(G426), .B(new_n129_), .Y(new_n68_));
  AO21x1_ASAP7_75t_R   g14(.A1(G12), .A2(G426), .B(new_n131_), .Y(new_n69_));
  OA22x2_ASAP7_75t_R   g15(.A1(G23), .A2(new_n68_), .B1(G15), .B2(new_n69_), .Y(new_n70_));
  AO21x1_ASAP7_75t_R   g16(.A1(G16), .A2(G426), .B(new_n130_), .Y(new_n71_));
  AO21x1_ASAP7_75t_R   g17(.A1(G1), .A2(G426), .B(new_n134_), .Y(new_n72_));
  OA22x2_ASAP7_75t_R   g18(.A1(G19), .A2(new_n71_), .B1(G3), .B2(new_n72_), .Y(new_n73_));
  AO21x1_ASAP7_75t_R   g19(.A1(G32), .A2(G426), .B(new_n126_), .Y(new_n74_));
  AO21x1_ASAP7_75t_R   g20(.A1(G4), .A2(G426), .B(new_n133_), .Y(new_n75_));
  OA22x2_ASAP7_75t_R   g21(.A1(G35), .A2(new_n74_), .B1(G7), .B2(new_n75_), .Y(new_n76_));
  AND4x2_ASAP7_75t_R   g22(.A(new_n73_), .B(new_n76_), .C(new_n70_), .D(new_n67_), .Y(new_n77_));
  INVx1_ASAP7_75t_R    g23(.A(new_n77_), .Y(G427));
  AO21x1_ASAP7_75t_R   g24(.A1(G19), .A2(G427), .B(new_n71_), .Y(new_n79_));
  NOR2x1_ASAP7_75t_R   g25(.A(G21), .B(new_n79_), .Y(new_n80_));
  AO21x1_ASAP7_75t_R   g26(.A1(G23), .A2(G427), .B(new_n68_), .Y(new_n81_));
  AO21x1_ASAP7_75t_R   g27(.A1(G15), .A2(G427), .B(new_n69_), .Y(new_n82_));
  OAI22x1_ASAP7_75t_R  g28(.A1(G25), .A2(new_n81_), .B1(G17), .B2(new_n82_), .Y(new_n83_));
  AO21x1_ASAP7_75t_R   g29(.A1(G7), .A2(G427), .B(new_n75_), .Y(new_n84_));
  AO21x1_ASAP7_75t_R   g30(.A1(G3), .A2(G427), .B(new_n72_), .Y(new_n85_));
  OAI22x1_ASAP7_75t_R  g31(.A1(G9), .A2(new_n84_), .B1(G5), .B2(new_n85_), .Y(new_n86_));
  AO21x1_ASAP7_75t_R   g32(.A1(G31), .A2(G427), .B(new_n62_), .Y(new_n87_));
  OR3x1_ASAP7_75t_R    g33(.A(G33), .B(new_n137_), .C(new_n87_), .Y(new_n89_));
  AO21x1_ASAP7_75t_R   g34(.A1(G35), .A2(G427), .B(new_n74_), .Y(new_n90_));
  AO21x1_ASAP7_75t_R   g35(.A1(G11), .A2(G427), .B(new_n66_), .Y(new_n91_));
  OR3x1_ASAP7_75t_R    g36(.A(new_n128_), .B(G29), .C(new_n136_), .Y(new_n93_));
  AO21x1_ASAP7_75t_R   g37(.A1(new_n65_), .A2(G427), .B(new_n93_), .Y(new_n94_));
  OA22x2_ASAP7_75t_R   g38(.A1(G13), .A2(new_n91_), .B1(new_n138_), .B2(new_n94_), .Y(new_n95_));
  OA211x2_ASAP7_75t_R  g39(.A1(G36), .A2(new_n90_), .B(new_n89_), .C(new_n95_), .Y(new_n96_));
  INVx1_ASAP7_75t_R    g40(.A(new_n96_), .Y(new_n97_));
  OR4x2_ASAP7_75t_R    g41(.A(new_n80_), .B(new_n83_), .C(new_n86_), .D(new_n97_), .Y(G428));
  AOI21x1_ASAP7_75t_R  g42(.A1(G5), .A2(G428), .B(new_n85_), .Y(new_n99_));
  AOI21x1_ASAP7_75t_R  g43(.A1(G21), .A2(G428), .B(new_n79_), .Y(new_n100_));
  AOI21x1_ASAP7_75t_R  g44(.A1(G17), .A2(G428), .B(new_n82_), .Y(new_n101_));
  AO21x1_ASAP7_75t_R   g45(.A1(G13), .A2(G428), .B(new_n91_), .Y(new_n102_));
  AOI21x1_ASAP7_75t_R  g46(.A1(G9), .A2(G428), .B(new_n84_), .Y(new_n104_));
  OR4x2_ASAP7_75t_R    g47(.A(new_n100_), .B(new_n101_), .C(new_n139_), .D(new_n104_), .Y(G430));
  AO21x1_ASAP7_75t_R   g48(.A1(G24), .A2(G426), .B(new_n128_), .Y(new_n108_));
  AO21x1_ASAP7_75t_R   g49(.A1(G27), .A2(G427), .B(new_n108_), .Y(new_n109_));
  AO21x1_ASAP7_75t_R   g50(.A1(G29), .A2(G428), .B(new_n109_), .Y(new_n110_));
  AO21x1_ASAP7_75t_R   g51(.A1(G25), .A2(G428), .B(new_n81_), .Y(new_n112_));
  AO21x1_ASAP7_75t_R   g52(.A1(G33), .A2(G428), .B(new_n87_), .Y(new_n113_));
  AND4x2_ASAP7_75t_R   g53(.A(new_n141_), .B(new_n110_), .C(new_n112_), .D(new_n113_), .Y(new_n114_));
  AOI21x1_ASAP7_75t_R  g54(.A1(new_n140_), .A2(new_n114_), .B(new_n99_), .Y(G429));
  OR3x1_ASAP7_75t_R    g55(.A(new_n100_), .B(new_n101_), .C(new_n110_), .Y(new_n116_));
  INVx1_ASAP7_75t_R    g56(.A(new_n116_), .Y(new_n117_));
  OR2x4_ASAP7_75t_R    g57(.A(new_n101_), .B(new_n139_), .Y(new_n118_));
  OR3x1_ASAP7_75t_R    g58(.A(new_n100_), .B(new_n112_), .C(new_n118_), .Y(new_n119_));
  INVx1_ASAP7_75t_R    g59(.A(new_n119_), .Y(new_n120_));
  OR4x2_ASAP7_75t_R    g60(.A(new_n139_), .B(new_n104_), .C(new_n120_), .D(new_n117_), .Y(G431));
  OR3x1_ASAP7_75t_R    g61(.A(new_n142_), .B(new_n113_), .C(new_n118_), .Y(new_n122_));
  INVx1_ASAP7_75t_R    g62(.A(new_n122_), .Y(new_n123_));
  AO21x1_ASAP7_75t_R   g63(.A1(new_n101_), .A2(new_n102_), .B(new_n104_), .Y(new_n124_));
  OR3x1_ASAP7_75t_R    g64(.A(new_n120_), .B(new_n124_), .C(new_n123_), .Y(G432));
  INVx1_ASAP7_75t_R    g65(.A(G34), .Y(new_n126_));
  INVx1_ASAP7_75t_R    g66(.A(G30), .Y(new_n127_));
  INVx1_ASAP7_75t_R    g67(.A(G26), .Y(new_n128_));
  INVx1_ASAP7_75t_R    g68(.A(G22), .Y(new_n129_));
  INVx1_ASAP7_75t_R    g69(.A(G18), .Y(new_n130_));
  INVx1_ASAP7_75t_R    g70(.A(G14), .Y(new_n131_));
  INVx1_ASAP7_75t_R    g71(.A(G10), .Y(new_n132_));
  INVx1_ASAP7_75t_R    g72(.A(G6), .Y(new_n133_));
  INVx1_ASAP7_75t_R    g73(.A(G2), .Y(new_n134_));
  AND2x2_ASAP7_75t_R   g74(.A(G24), .B(G426), .Y(new_n136_));
  assign               new_n137_ = 1'b0;
  assign               new_n138_ = 1'b0;
  INVx1_ASAP7_75t_R    g75(.A(new_n102_), .Y(new_n139_));
  INVx1_ASAP7_75t_R    g76(.A(G430), .Y(new_n140_));
  INVx1_ASAP7_75t_R    g77(.A(G34), .Y(new_n141_));
  INVx1_ASAP7_75t_R    g78(.A(new_n110_), .Y(new_n142_));
endmodule


