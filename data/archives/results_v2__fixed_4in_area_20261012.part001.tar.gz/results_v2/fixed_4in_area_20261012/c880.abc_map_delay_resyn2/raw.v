// Benchmark "/home/flynn/workplace/MIGBalance/results_v2/fixed_4in_area_20261012/c880.resyn2" written by ABC on Mon Oct 12 15:02:11 2026

module \/home/flynn/workplace/MIGBalance/results_v2/fixed_4in_area_20261012/c880.resyn2  ( 
    G8, G16, G6, G17, G7, G18, G19, G4, G3, G2, G1, G5, G11, G23, G20, G21,
    G9, G10, G12, G15, G22, G32, G24, G25, G26, G27, G28, G29, G30, G31,
    G33, G41, G42, G43, G44, G45, G46, G47, G48, G49, G13, G14, G55, G59,
    G54, G60, G39, G40, G52, G53, G50, G51, G58, G35, G37, G36, G56, G57,
    G34, G38,
    G855, G856, G857, G858, G859, G860, G861, G862, G863, G864, G865, G866,
    G867, G868, G869, G870, G871, G872, G873, G874, G875, G876, G877, G878,
    G879, G880  );
  input  G8, G16, G6, G17, G7, G18, G19, G4, G3, G2, G1, G5, G11, G23,
    G20, G21, G9, G10, G12, G15, G22, G32, G24, G25, G26, G27, G28, G29,
    G30, G31, G33, G41, G42, G43, G44, G45, G46, G47, G48, G49, G13, G14,
    G55, G59, G54, G60, G39, G40, G52, G53, G50, G51, G58, G35, G37, G36,
    G56, G57, G34, G38;
  output G855, G856, G857, G858, G859, G860, G861, G862, G863, G864, G865,
    G866, G867, G868, G869, G870, G871, G872, G873, G874, G875, G876, G877,
    G878, G879, G880;
  wire new_n87_, new_n88_, new_n89_, new_n91_, new_n92_, new_n96_, new_n98_,
    new_n105_, new_n107_, new_n109_, new_n112_, new_n113_, new_n114_,
    new_n115_, new_n116_, new_n117_, new_n118_, new_n119_, new_n121_,
    new_n122_, new_n123_, new_n124_, new_n125_, new_n126_, new_n127_,
    new_n128_, new_n130_, new_n131_, new_n132_, new_n133_, new_n134_,
    new_n135_, new_n136_, new_n137_, new_n138_, new_n139_, new_n140_,
    new_n141_, new_n142_, new_n143_, new_n144_, new_n145_, new_n146_,
    new_n147_, new_n148_, new_n149_, new_n150_, new_n151_, new_n152_,
    new_n153_, new_n154_, new_n155_, new_n156_, new_n157_, new_n158_,
    new_n159_, new_n160_, new_n161_, new_n162_, new_n163_, new_n164_,
    new_n165_, new_n166_, new_n168_, new_n169_, new_n170_, new_n171_,
    new_n172_, new_n173_, new_n174_, new_n175_, new_n176_, new_n177_,
    new_n178_, new_n179_, new_n180_, new_n181_, new_n182_, new_n183_,
    new_n184_, new_n185_, new_n186_, new_n187_, new_n188_, new_n189_,
    new_n190_, new_n191_, new_n192_, new_n193_, new_n194_, new_n195_,
    new_n196_, new_n197_, new_n198_, new_n199_, new_n201_, new_n202_,
    new_n203_, new_n204_, new_n205_, new_n206_, new_n207_, new_n208_,
    new_n209_, new_n210_, new_n211_, new_n213_, new_n214_, new_n215_,
    new_n216_, new_n217_, new_n218_, new_n219_, new_n220_, new_n221_,
    new_n223_, new_n224_, new_n225_, new_n226_, new_n227_, new_n228_,
    new_n229_, new_n230_, new_n231_, new_n232_, new_n233_, new_n234_,
    new_n235_, new_n236_, new_n237_, new_n238_, new_n239_, new_n240_,
    new_n241_, new_n242_, new_n243_, new_n244_, new_n245_, new_n246_,
    new_n247_, new_n248_, new_n249_, new_n250_, new_n251_, new_n252_,
    new_n253_, new_n254_, new_n255_, new_n256_, new_n257_, new_n258_,
    new_n259_, new_n260_, new_n261_, new_n263_, new_n264_, new_n265_,
    new_n266_, new_n267_, new_n268_, new_n269_, new_n270_, new_n271_,
    new_n272_, new_n273_, new_n275_, new_n276_, new_n277_, new_n278_,
    new_n279_, new_n280_, new_n281_, new_n282_, new_n283_, new_n284_,
    new_n285_, new_n286_, new_n288_, new_n289_, new_n290_, new_n291_,
    new_n292_, new_n293_, new_n294_, new_n295_, new_n296_, new_n297_,
    new_n298_, new_n299_, new_n300_, new_n302_, new_n303_, new_n304_,
    new_n305_, new_n306_, new_n307_, new_n308_, new_n309_;
  INVx1_ASAP7_75t_R    g000(.A(G8), .Y(new_n87_));
  INVx1_ASAP7_75t_R    g001(.A(G16), .Y(new_n88_));
  INVx1_ASAP7_75t_R    g002(.A(G6), .Y(new_n89_));
  OR3x1_ASAP7_75t_R    g003(.A(new_n87_), .B(new_n88_), .C(new_n89_), .Y(G855));
  INVx1_ASAP7_75t_R    g004(.A(G17), .Y(new_n91_));
  INVx1_ASAP7_75t_R    g005(.A(G7), .Y(new_n92_));
  OR3x1_ASAP7_75t_R    g006(.A(new_n89_), .B(new_n91_), .C(new_n92_), .Y(G856));
  OR3x1_ASAP7_75t_R    g007(.A(new_n87_), .B(new_n89_), .C(new_n92_), .Y(G857));
  NAND2x1_ASAP7_75t_R  g008(.A(G18), .B(G19), .Y(G858));
  AND4x2_ASAP7_75t_R   g009(.A(G4), .B(G3), .C(G2), .D(G1), .Y(new_n96_));
  INVx1_ASAP7_75t_R    g010(.A(new_n96_), .Y(G859));
  AND4x2_ASAP7_75t_R   g011(.A(G4), .B(G3), .C(G1), .D(G5), .Y(new_n98_));
  AND2x2_ASAP7_75t_R   g012(.A(G857), .B(new_n98_), .Y(G860));
  AND3x1_ASAP7_75t_R   g013(.A(G16), .B(G17), .C(G11), .Y(G861));
  AND3x1_ASAP7_75t_R   g014(.A(G17), .B(G7), .C(G11), .Y(G862));
  AND3x1_ASAP7_75t_R   g015(.A(G8), .B(G7), .C(G11), .Y(G863));
  OAI21x1_ASAP7_75t_R  g016(.A1(G20), .A2(G21), .B(G23), .Y(G864));
  AND4x2_ASAP7_75t_R   g017(.A(new_n98_), .B(G8), .C(G6), .D(G7), .Y(G865));
  AND3x1_ASAP7_75t_R   g018(.A(G1), .B(G5), .C(G9), .Y(new_n105_));
  INVx1_ASAP7_75t_R    g019(.A(new_n105_), .Y(G866));
  AND4x2_ASAP7_75t_R   g020(.A(G3), .B(G2), .C(G1), .D(G10), .Y(new_n107_));
  NAND3x1_ASAP7_75t_R  g021(.A(new_n107_), .B(G12), .C(G6), .Y(G867));
  AND3x1_ASAP7_75t_R   g022(.A(new_n107_), .B(G11), .C(G12), .Y(new_n109_));
  NAND2x1_ASAP7_75t_R  g023(.A(G15), .B(new_n109_), .Y(G868));
  OAI21x1_ASAP7_75t_R  g024(.A1(G20), .A2(G21), .B(G22), .Y(G869));
  XOR2x2_ASAP7_75t_R   g025(.A(G24), .B(G25), .Y(new_n112_));
  XOR2x2_ASAP7_75t_R   g026(.A(new_n112_), .B(G32), .Y(new_n113_));
  XOR2x2_ASAP7_75t_R   g027(.A(G30), .B(G31), .Y(new_n114_));
  XOR2x2_ASAP7_75t_R   g028(.A(new_n113_), .B(new_n114_), .Y(new_n115_));
  XOR2x2_ASAP7_75t_R   g029(.A(G28), .B(G29), .Y(new_n116_));
  XOR2x2_ASAP7_75t_R   g030(.A(new_n116_), .B(G33), .Y(new_n117_));
  XNOR2x2_ASAP7_75t_R  g031(.A(G26), .B(G27), .Y(new_n118_));
  XOR2x2_ASAP7_75t_R   g032(.A(new_n117_), .B(new_n118_), .Y(new_n119_));
  XOR2x2_ASAP7_75t_R   g033(.A(new_n115_), .B(new_n119_), .Y(G870));
  XOR2x2_ASAP7_75t_R   g034(.A(G41), .B(G42), .Y(new_n121_));
  XOR2x2_ASAP7_75t_R   g035(.A(new_n121_), .B(G32), .Y(new_n122_));
  XOR2x2_ASAP7_75t_R   g036(.A(G47), .B(G48), .Y(new_n123_));
  XOR2x2_ASAP7_75t_R   g037(.A(new_n122_), .B(new_n123_), .Y(new_n124_));
  XOR2x2_ASAP7_75t_R   g038(.A(G45), .B(G46), .Y(new_n125_));
  XOR2x2_ASAP7_75t_R   g039(.A(new_n125_), .B(G49), .Y(new_n126_));
  XNOR2x2_ASAP7_75t_R  g040(.A(G43), .B(G44), .Y(new_n127_));
  XOR2x2_ASAP7_75t_R   g041(.A(new_n126_), .B(new_n127_), .Y(new_n128_));
  XOR2x2_ASAP7_75t_R   g042(.A(new_n124_), .B(new_n128_), .Y(G871));
  INVx1_ASAP7_75t_R    g043(.A(G58), .Y(new_n130_));
  INVx1_ASAP7_75t_R    g044(.A(G48), .Y(new_n131_));
  INVx1_ASAP7_75t_R    g045(.A(G1), .Y(new_n132_));
  NAND2x1_ASAP7_75t_R  g046(.A(G11), .B(G40), .Y(new_n133_));
  AO31x2_ASAP7_75t_R   g047(.A1(G4), .A2(new_n105_), .A3(new_n133_), .B(new_n132_), .Y(new_n134_));
  NAND2x1_ASAP7_75t_R  g048(.A(G39), .B(new_n134_), .Y(new_n135_));
  AND2x2_ASAP7_75t_R   g049(.A(G11), .B(G40), .Y(new_n136_));
  OR2x4_ASAP7_75t_R    g050(.A(G8), .B(G4), .Y(new_n137_));
  NAND2x1_ASAP7_75t_R  g051(.A(G8), .B(G4), .Y(new_n138_));
  AND4x2_ASAP7_75t_R   g052(.A(new_n105_), .B(new_n136_), .C(new_n137_), .D(new_n138_), .Y(new_n139_));
  NAND2x1_ASAP7_75t_R  g053(.A(G16), .B(G11), .Y(new_n140_));
  AND4x2_ASAP7_75t_R   g054(.A(G4), .B(G2), .C(G1), .D(G9), .Y(new_n141_));
  OA21x2_ASAP7_75t_R   g055(.A1(new_n87_), .A2(new_n140_), .B(new_n141_), .Y(new_n142_));
  OAI21x1_ASAP7_75t_R  g056(.A1(new_n142_), .A2(new_n139_), .B(G31), .Y(new_n143_));
  AND3x1_ASAP7_75t_R   g057(.A(G16), .B(G6), .C(G17), .Y(new_n144_));
  AND2x2_ASAP7_75t_R   g058(.A(new_n105_), .B(new_n144_), .Y(new_n145_));
  INVx1_ASAP7_75t_R    g059(.A(G60), .Y(new_n146_));
  AND2x2_ASAP7_75t_R   g060(.A(new_n146_), .B(G10), .Y(new_n147_));
  NAND2x1_ASAP7_75t_R  g061(.A(new_n147_), .B(new_n145_), .Y(new_n148_));
  AO31x2_ASAP7_75t_R   g062(.A1(new_n135_), .A2(new_n143_), .A3(new_n148_), .B(new_n131_), .Y(new_n149_));
  INVx1_ASAP7_75t_R    g063(.A(new_n149_), .Y(new_n150_));
  AND4x2_ASAP7_75t_R   g064(.A(new_n143_), .B(new_n131_), .C(new_n135_), .D(new_n148_), .Y(new_n151_));
  OA21x2_ASAP7_75t_R   g065(.A1(new_n150_), .A2(new_n151_), .B(new_n130_), .Y(new_n152_));
  INVx1_ASAP7_75t_R    g066(.A(G31), .Y(new_n153_));
  AND3x1_ASAP7_75t_R   g067(.A(new_n137_), .B(new_n136_), .C(new_n138_), .Y(new_n154_));
  AOI21x1_ASAP7_75t_R  g068(.A1(new_n105_), .A2(new_n154_), .B(new_n142_), .Y(new_n155_));
  OA21x2_ASAP7_75t_R   g069(.A1(new_n155_), .A2(new_n153_), .B(new_n148_), .Y(new_n156_));
  AO31x2_ASAP7_75t_R   g070(.A1(new_n131_), .A2(new_n156_), .A3(new_n135_), .B(new_n130_), .Y(new_n157_));
  OAI21x1_ASAP7_75t_R  g071(.A1(new_n150_), .A2(new_n157_), .B(G51), .Y(new_n158_));
  INVx1_ASAP7_75t_R    g072(.A(G52), .Y(new_n159_));
  OR3x1_ASAP7_75t_R    g073(.A(new_n150_), .B(new_n159_), .C(new_n151_), .Y(new_n160_));
  NAND2x1_ASAP7_75t_R  g074(.A(new_n135_), .B(new_n156_), .Y(new_n161_));
  AO21x1_ASAP7_75t_R   g075(.A1(G48), .A2(G53), .B(G54), .Y(new_n162_));
  AND4x2_ASAP7_75t_R   g076(.A(new_n109_), .B(G8), .C(G13), .D(G14), .Y(new_n163_));
  AO22x1_ASAP7_75t_R   g077(.A1(G30), .A2(G50), .B1(G55), .B2(G59), .Y(new_n164_));
  AO21x1_ASAP7_75t_R   g078(.A1(new_n163_), .A2(G48), .B(new_n164_), .Y(new_n165_));
  AOI21x1_ASAP7_75t_R  g079(.A1(new_n162_), .A2(new_n161_), .B(new_n165_), .Y(new_n166_));
  OA211x2_ASAP7_75t_R  g080(.A1(new_n152_), .A2(new_n158_), .B(new_n160_), .C(new_n166_), .Y(G872));
  INVx1_ASAP7_75t_R    g081(.A(G28), .Y(new_n168_));
  INVx1_ASAP7_75t_R    g082(.A(G35), .Y(new_n169_));
  INVx1_ASAP7_75t_R    g083(.A(new_n134_), .Y(new_n170_));
  OA21x2_ASAP7_75t_R   g084(.A1(new_n170_), .A2(new_n169_), .B(new_n148_), .Y(new_n171_));
  OAI21x1_ASAP7_75t_R  g085(.A1(new_n168_), .A2(new_n155_), .B(new_n171_), .Y(new_n172_));
  OR2x4_ASAP7_75t_R    g086(.A(G45), .B(new_n172_), .Y(new_n173_));
  NAND2x1_ASAP7_75t_R  g087(.A(G45), .B(new_n172_), .Y(new_n174_));
  NAND2x1_ASAP7_75t_R  g088(.A(new_n174_), .B(new_n173_), .Y(new_n175_));
  OAI21x1_ASAP7_75t_R  g089(.A1(new_n130_), .A2(new_n151_), .B(new_n149_), .Y(new_n176_));
  INVx1_ASAP7_75t_R    g090(.A(G29), .Y(new_n177_));
  AOI22x1_ASAP7_75t_R  g091(.A1(new_n145_), .A2(new_n147_), .B1(new_n134_), .B2(G36), .Y(new_n178_));
  OAI21x1_ASAP7_75t_R  g092(.A1(new_n177_), .A2(new_n155_), .B(new_n178_), .Y(new_n179_));
  INVx1_ASAP7_75t_R    g093(.A(G30), .Y(new_n180_));
  AOI22x1_ASAP7_75t_R  g094(.A1(new_n145_), .A2(new_n147_), .B1(new_n134_), .B2(G37), .Y(new_n181_));
  OAI21x1_ASAP7_75t_R  g095(.A1(new_n180_), .A2(new_n155_), .B(new_n181_), .Y(new_n182_));
  OA22x2_ASAP7_75t_R   g096(.A1(new_n179_), .A2(G46), .B1(new_n182_), .B2(G47), .Y(new_n183_));
  INVx1_ASAP7_75t_R    g097(.A(G46), .Y(new_n184_));
  OA211x2_ASAP7_75t_R  g098(.A1(new_n177_), .A2(new_n155_), .B(new_n178_), .C(new_n184_), .Y(new_n185_));
  OA21x2_ASAP7_75t_R   g099(.A1(new_n139_), .A2(new_n142_), .B(G29), .Y(new_n186_));
  AO22x1_ASAP7_75t_R   g100(.A1(new_n134_), .A2(G36), .B1(new_n145_), .B2(new_n147_), .Y(new_n187_));
  OAI21x1_ASAP7_75t_R  g101(.A1(new_n187_), .A2(new_n186_), .B(G46), .Y(new_n188_));
  INVx1_ASAP7_75t_R    g102(.A(G47), .Y(new_n189_));
  OAI21x1_ASAP7_75t_R  g103(.A1(new_n142_), .A2(new_n139_), .B(G30), .Y(new_n190_));
  AO21x1_ASAP7_75t_R   g104(.A1(new_n190_), .A2(new_n181_), .B(new_n189_), .Y(new_n191_));
  OAI21x1_ASAP7_75t_R  g105(.A1(new_n191_), .A2(new_n185_), .B(new_n188_), .Y(new_n192_));
  AOI21x1_ASAP7_75t_R  g106(.A1(new_n183_), .A2(new_n176_), .B(new_n192_), .Y(new_n193_));
  OAI21x1_ASAP7_75t_R  g107(.A1(new_n193_), .A2(new_n175_), .B(G51), .Y(new_n194_));
  AO21x1_ASAP7_75t_R   g108(.A1(new_n175_), .A2(new_n193_), .B(new_n194_), .Y(new_n195_));
  AO21x1_ASAP7_75t_R   g109(.A1(G45), .A2(G53), .B(G54), .Y(new_n196_));
  AO22x1_ASAP7_75t_R   g110(.A1(new_n163_), .A2(G45), .B1(G27), .B2(G50), .Y(new_n197_));
  AOI21x1_ASAP7_75t_R  g111(.A1(new_n196_), .A2(new_n172_), .B(new_n197_), .Y(new_n198_));
  OA21x2_ASAP7_75t_R   g112(.A1(new_n175_), .A2(new_n159_), .B(new_n198_), .Y(new_n199_));
  AND2x2_ASAP7_75t_R   g113(.A(new_n195_), .B(new_n199_), .Y(G873));
  XOR2x2_ASAP7_75t_R   g114(.A(new_n179_), .B(new_n184_), .Y(new_n201_));
  INVx1_ASAP7_75t_R    g115(.A(new_n176_), .Y(new_n202_));
  AND3x1_ASAP7_75t_R   g116(.A(new_n190_), .B(new_n189_), .C(new_n181_), .Y(new_n203_));
  OA21x2_ASAP7_75t_R   g117(.A1(new_n202_), .A2(new_n203_), .B(new_n191_), .Y(new_n204_));
  OAI21x1_ASAP7_75t_R  g118(.A1(new_n201_), .A2(new_n204_), .B(G51), .Y(new_n205_));
  AO21x1_ASAP7_75t_R   g119(.A1(new_n201_), .A2(new_n204_), .B(new_n205_), .Y(new_n206_));
  AO21x1_ASAP7_75t_R   g120(.A1(G46), .A2(G53), .B(G54), .Y(new_n207_));
  AO22x1_ASAP7_75t_R   g121(.A1(G28), .A2(G50), .B1(G55), .B2(G56), .Y(new_n208_));
  AO21x1_ASAP7_75t_R   g122(.A1(new_n163_), .A2(G46), .B(new_n208_), .Y(new_n209_));
  AOI21x1_ASAP7_75t_R  g123(.A1(new_n179_), .A2(new_n207_), .B(new_n209_), .Y(new_n210_));
  OA21x2_ASAP7_75t_R   g124(.A1(new_n201_), .A2(new_n159_), .B(new_n210_), .Y(new_n211_));
  AND2x2_ASAP7_75t_R   g125(.A(new_n206_), .B(new_n211_), .Y(G874));
  INVx1_ASAP7_75t_R    g126(.A(new_n191_), .Y(new_n213_));
  NOR2x1_ASAP7_75t_R   g127(.A(new_n203_), .B(new_n213_), .Y(new_n214_));
  NAND2x1_ASAP7_75t_R  g128(.A(new_n176_), .B(new_n214_), .Y(new_n215_));
  OA21x2_ASAP7_75t_R   g129(.A1(new_n214_), .A2(new_n176_), .B(G51), .Y(new_n216_));
  AO21x1_ASAP7_75t_R   g130(.A1(G47), .A2(G53), .B(G54), .Y(new_n217_));
  AO22x1_ASAP7_75t_R   g131(.A1(G29), .A2(G50), .B1(G55), .B2(G57), .Y(new_n218_));
  AO21x1_ASAP7_75t_R   g132(.A1(new_n163_), .A2(G47), .B(new_n218_), .Y(new_n219_));
  AO21x1_ASAP7_75t_R   g133(.A1(new_n182_), .A2(new_n217_), .B(new_n219_), .Y(new_n220_));
  AO21x1_ASAP7_75t_R   g134(.A1(new_n214_), .A2(G52), .B(new_n220_), .Y(new_n221_));
  AOI21x1_ASAP7_75t_R  g135(.A1(new_n216_), .A2(new_n215_), .B(new_n221_), .Y(G875));
  INVx1_ASAP7_75t_R    g136(.A(G41), .Y(new_n223_));
  AO21x1_ASAP7_75t_R   g137(.A1(new_n154_), .A2(new_n105_), .B(new_n142_), .Y(new_n224_));
  NAND2x1_ASAP7_75t_R  g138(.A(G24), .B(new_n224_), .Y(new_n225_));
  AND3x1_ASAP7_75t_R   g139(.A(new_n105_), .B(G10), .C(new_n133_), .Y(new_n226_));
  INVx1_ASAP7_75t_R    g140(.A(new_n226_), .Y(new_n227_));
  INVx1_ASAP7_75t_R    g141(.A(G2), .Y(new_n228_));
  INVx1_ASAP7_75t_R    g142(.A(G34), .Y(new_n229_));
  AND2x2_ASAP7_75t_R   g143(.A(new_n146_), .B(G4), .Y(new_n230_));
  NAND2x1_ASAP7_75t_R  g144(.A(new_n230_), .B(new_n145_), .Y(new_n231_));
  OA21x2_ASAP7_75t_R   g145(.A1(new_n228_), .A2(new_n229_), .B(new_n231_), .Y(new_n232_));
  OA211x2_ASAP7_75t_R  g146(.A1(new_n169_), .A2(new_n227_), .B(new_n225_), .C(new_n232_), .Y(new_n233_));
  INVx1_ASAP7_75t_R    g147(.A(G44), .Y(new_n234_));
  NAND2x1_ASAP7_75t_R  g148(.A(G27), .B(new_n224_), .Y(new_n235_));
  INVx1_ASAP7_75t_R    g149(.A(G38), .Y(new_n236_));
  NAND2x1_ASAP7_75t_R  g150(.A(G39), .B(new_n226_), .Y(new_n237_));
  OA211x2_ASAP7_75t_R  g151(.A1(new_n229_), .A2(new_n236_), .B(new_n237_), .C(new_n231_), .Y(new_n238_));
  AND3x1_ASAP7_75t_R   g152(.A(new_n238_), .B(new_n234_), .C(new_n235_), .Y(new_n239_));
  OAI22x1_ASAP7_75t_R  g153(.A1(new_n179_), .A2(G46), .B1(new_n182_), .B2(G47), .Y(new_n240_));
  AOI21x1_ASAP7_75t_R  g154(.A1(new_n149_), .A2(new_n157_), .B(new_n240_), .Y(new_n241_));
  OAI21x1_ASAP7_75t_R  g155(.A1(new_n192_), .A2(new_n241_), .B(new_n173_), .Y(new_n242_));
  AOI21x1_ASAP7_75t_R  g156(.A1(new_n174_), .A2(new_n242_), .B(new_n239_), .Y(new_n243_));
  INVx1_ASAP7_75t_R    g157(.A(G43), .Y(new_n244_));
  AND2x2_ASAP7_75t_R   g158(.A(new_n226_), .B(G37), .Y(new_n245_));
  AO22x1_ASAP7_75t_R   g159(.A1(new_n145_), .A2(new_n230_), .B1(G4), .B2(G34), .Y(new_n246_));
  AOI211x1_ASAP7_75t_R g160(.A1(new_n224_), .A2(G26), .B(new_n245_), .C(new_n246_), .Y(new_n247_));
  NAND2x1_ASAP7_75t_R  g161(.A(new_n244_), .B(new_n247_), .Y(new_n248_));
  INVx1_ASAP7_75t_R    g162(.A(G36), .Y(new_n249_));
  INVx1_ASAP7_75t_R    g163(.A(G9), .Y(new_n250_));
  OA21x2_ASAP7_75t_R   g164(.A1(new_n250_), .A2(new_n229_), .B(new_n231_), .Y(new_n251_));
  OAI21x1_ASAP7_75t_R  g165(.A1(new_n249_), .A2(new_n227_), .B(new_n251_), .Y(new_n252_));
  AO211x2_ASAP7_75t_R  g166(.A1(G25), .A2(new_n224_), .B(G42), .C(new_n252_), .Y(new_n253_));
  AND2x2_ASAP7_75t_R   g167(.A(new_n253_), .B(new_n248_), .Y(new_n254_));
  AND2x2_ASAP7_75t_R   g168(.A(new_n224_), .B(G25), .Y(new_n255_));
  OA21x2_ASAP7_75t_R   g169(.A1(new_n252_), .A2(new_n255_), .B(G42), .Y(new_n256_));
  OA21x2_ASAP7_75t_R   g170(.A1(new_n229_), .A2(new_n236_), .B(new_n231_), .Y(new_n257_));
  AO31x2_ASAP7_75t_R   g171(.A1(new_n237_), .A2(new_n235_), .A3(new_n257_), .B(new_n234_), .Y(new_n258_));
  OAI21x1_ASAP7_75t_R  g172(.A1(new_n244_), .A2(new_n247_), .B(new_n258_), .Y(new_n259_));
  AO31x2_ASAP7_75t_R   g173(.A1(new_n248_), .A2(new_n259_), .A3(new_n253_), .B(new_n256_), .Y(new_n260_));
  AOI21x1_ASAP7_75t_R  g174(.A1(new_n254_), .A2(new_n243_), .B(new_n260_), .Y(new_n261_));
  MAJx2_ASAP7_75t_R    g175(.A(new_n261_), .B(new_n223_), .C(new_n233_), .Y(G876));
  NOR2x1_ASAP7_75t_R   g176(.A(G45), .B(new_n172_), .Y(new_n263_));
  OA21x2_ASAP7_75t_R   g177(.A1(new_n193_), .A2(new_n263_), .B(new_n174_), .Y(new_n264_));
  INVx1_ASAP7_75t_R    g178(.A(new_n239_), .Y(new_n265_));
  NAND2x1_ASAP7_75t_R  g179(.A(new_n258_), .B(new_n265_), .Y(new_n266_));
  AND2x2_ASAP7_75t_R   g180(.A(new_n266_), .B(new_n264_), .Y(new_n267_));
  OAI21x1_ASAP7_75t_R  g181(.A1(new_n264_), .A2(new_n266_), .B(G51), .Y(new_n268_));
  NAND2x1_ASAP7_75t_R  g182(.A(new_n235_), .B(new_n238_), .Y(new_n269_));
  AO21x1_ASAP7_75t_R   g183(.A1(G44), .A2(G53), .B(G54), .Y(new_n270_));
  AO22x1_ASAP7_75t_R   g184(.A1(new_n163_), .A2(G44), .B1(G26), .B2(G50), .Y(new_n271_));
  AOI21x1_ASAP7_75t_R  g185(.A1(new_n270_), .A2(new_n269_), .B(new_n271_), .Y(new_n272_));
  OA21x2_ASAP7_75t_R   g186(.A1(new_n266_), .A2(new_n159_), .B(new_n272_), .Y(new_n273_));
  OA21x2_ASAP7_75t_R   g187(.A1(new_n267_), .A2(new_n268_), .B(new_n273_), .Y(G877));
  XOR2x2_ASAP7_75t_R   g188(.A(new_n233_), .B(new_n223_), .Y(new_n275_));
  AO211x2_ASAP7_75t_R  g189(.A1(new_n254_), .A2(new_n243_), .B(new_n260_), .C(new_n275_), .Y(new_n276_));
  INVx1_ASAP7_75t_R    g190(.A(G51), .Y(new_n277_));
  OAI21x1_ASAP7_75t_R  g191(.A1(new_n263_), .A2(new_n193_), .B(new_n174_), .Y(new_n278_));
  AO31x2_ASAP7_75t_R   g192(.A1(new_n265_), .A2(new_n278_), .A3(new_n254_), .B(new_n260_), .Y(new_n279_));
  AOI21x1_ASAP7_75t_R  g193(.A1(new_n275_), .A2(new_n279_), .B(new_n277_), .Y(new_n280_));
  INVx1_ASAP7_75t_R    g194(.A(G54), .Y(new_n281_));
  INVx1_ASAP7_75t_R    g195(.A(G53), .Y(new_n282_));
  OA21x2_ASAP7_75t_R   g196(.A1(new_n223_), .A2(new_n282_), .B(new_n281_), .Y(new_n283_));
  AOI22x1_ASAP7_75t_R  g197(.A1(G60), .A2(G50), .B1(new_n163_), .B2(G41), .Y(new_n284_));
  OAI21x1_ASAP7_75t_R  g198(.A1(new_n283_), .A2(new_n233_), .B(new_n284_), .Y(new_n285_));
  AO21x1_ASAP7_75t_R   g199(.A1(new_n275_), .A2(G52), .B(new_n285_), .Y(new_n286_));
  AOI21x1_ASAP7_75t_R  g200(.A1(new_n276_), .A2(new_n280_), .B(new_n286_), .Y(G878));
  AND2x2_ASAP7_75t_R   g201(.A(new_n259_), .B(new_n248_), .Y(new_n288_));
  INVx1_ASAP7_75t_R    g202(.A(G42), .Y(new_n289_));
  NAND2x1_ASAP7_75t_R  g203(.A(G25), .B(new_n224_), .Y(new_n290_));
  NAND2x1_ASAP7_75t_R  g204(.A(G36), .B(new_n226_), .Y(new_n291_));
  AND3x1_ASAP7_75t_R   g205(.A(new_n290_), .B(new_n291_), .C(new_n251_), .Y(new_n292_));
  XOR2x2_ASAP7_75t_R   g206(.A(new_n292_), .B(new_n289_), .Y(new_n293_));
  AO211x2_ASAP7_75t_R  g207(.A1(new_n248_), .A2(new_n243_), .B(new_n288_), .C(new_n293_), .Y(new_n294_));
  AO31x2_ASAP7_75t_R   g208(.A1(new_n265_), .A2(new_n278_), .A3(new_n248_), .B(new_n288_), .Y(new_n295_));
  AOI21x1_ASAP7_75t_R  g209(.A1(new_n293_), .A2(new_n295_), .B(new_n277_), .Y(new_n296_));
  OA21x2_ASAP7_75t_R   g210(.A1(new_n289_), .A2(new_n282_), .B(new_n281_), .Y(new_n297_));
  AOI22x1_ASAP7_75t_R  g211(.A1(G24), .A2(G50), .B1(new_n163_), .B2(G42), .Y(new_n298_));
  OAI21x1_ASAP7_75t_R  g212(.A1(new_n297_), .A2(new_n292_), .B(new_n298_), .Y(new_n299_));
  AO21x1_ASAP7_75t_R   g213(.A1(new_n293_), .A2(G52), .B(new_n299_), .Y(new_n300_));
  AOI21x1_ASAP7_75t_R  g214(.A1(new_n294_), .A2(new_n296_), .B(new_n300_), .Y(G879));
  XOR2x2_ASAP7_75t_R   g215(.A(new_n247_), .B(G43), .Y(new_n302_));
  OA211x2_ASAP7_75t_R  g216(.A1(new_n264_), .A2(new_n239_), .B(new_n258_), .C(new_n302_), .Y(new_n303_));
  AO21x1_ASAP7_75t_R   g217(.A1(new_n242_), .A2(new_n174_), .B(new_n239_), .Y(new_n304_));
  AOI21x1_ASAP7_75t_R  g218(.A1(new_n258_), .A2(new_n304_), .B(new_n302_), .Y(new_n305_));
  OA21x2_ASAP7_75t_R   g219(.A1(new_n244_), .A2(new_n282_), .B(new_n281_), .Y(new_n306_));
  AOI22x1_ASAP7_75t_R  g220(.A1(G25), .A2(G50), .B1(new_n163_), .B2(G43), .Y(new_n307_));
  OA21x2_ASAP7_75t_R   g221(.A1(new_n247_), .A2(new_n306_), .B(new_n307_), .Y(new_n308_));
  OA21x2_ASAP7_75t_R   g222(.A1(new_n302_), .A2(new_n159_), .B(new_n308_), .Y(new_n309_));
  OA31x2_ASAP7_75t_R   g223(.A1(new_n277_), .A2(new_n305_), .A3(new_n303_), .B1(new_n309_), .Y(G880));
endmodule


