// Benchmark "/home/flynn/workplace/MIGBalance/results_v2/fixed_4in_area_20261012/c432.resyn2" written by ABC on Mon Oct 12 15:01:44 2026

module \/home/flynn/workplace/MIGBalance/results_v2/fixed_4in_area_20261012/c432.resyn2  ( 
    G32, G34, G28, G30, G24, G26, G20, G22, G16, G18, G12, G14, G8, G10,
    G4, G6, G1, G2, G35, G31, G27, G23, G19, G15, G11, G7, G3, G36, G33,
    G29, G25, G21, G17, G13, G9, G5,
    G426, G427, G428, G429, G430, G431, G432  );
  input  G32, G34, G28, G30, G24, G26, G20, G22, G16, G18, G12, G14, G8,
    G10, G4, G6, G1, G2, G35, G31, G27, G23, G19, G15, G11, G7, G3, G36,
    G33, G29, G25, G21, G17, G13, G9, G5;
  output G426, G427, G428, G429, G430, G431, G432;
  wire new_n44_, new_n45_, new_n46_, new_n47_, new_n48_, new_n49_, new_n50_,
    new_n51_, new_n52_, new_n53_, new_n54_, new_n55_, new_n56_, new_n57_,
    new_n58_, new_n59_, new_n60_, new_n62_, new_n63_, new_n64_, new_n65_,
    new_n66_, new_n67_, new_n68_, new_n69_, new_n70_, new_n71_, new_n72_,
    new_n73_, new_n74_, new_n75_, new_n76_, new_n77_, new_n78_, new_n79_,
    new_n80_, new_n81_, new_n82_, new_n83_, new_n84_, new_n85_, new_n86_,
    new_n87_, new_n88_, new_n89_, new_n90_, new_n91_, new_n92_, new_n93_,
    new_n94_, new_n96_, new_n97_, new_n98_, new_n99_, new_n100_, new_n101_,
    new_n102_, new_n103_, new_n104_, new_n105_, new_n106_, new_n107_,
    new_n108_, new_n109_, new_n110_, new_n111_, new_n112_, new_n113_,
    new_n114_, new_n115_, new_n116_, new_n117_, new_n118_, new_n119_,
    new_n121_, new_n122_, new_n123_, new_n124_, new_n125_, new_n126_,
    new_n127_, new_n128_, new_n129_, new_n130_, new_n131_, new_n132_,
    new_n133_, new_n134_, new_n135_, new_n136_, new_n137_, new_n138_,
    new_n139_, new_n140_, new_n141_, new_n144_, new_n145_, new_n146_,
    new_n147_, new_n148_, new_n150_, new_n151_, new_n152_, new_n153_;
  INVx1_ASAP7_75t_R    g000(.A(G18), .Y(new_n44_));
  INVx1_ASAP7_75t_R    g001(.A(G20), .Y(new_n45_));
  INVx1_ASAP7_75t_R    g002(.A(G12), .Y(new_n46_));
  AOI22x1_ASAP7_75t_R  g003(.A1(new_n45_), .A2(G22), .B1(new_n46_), .B2(G14), .Y(new_n47_));
  OAI21x1_ASAP7_75t_R  g004(.A1(G16), .A2(new_n44_), .B(new_n47_), .Y(new_n48_));
  INVx1_ASAP7_75t_R    g005(.A(G32), .Y(new_n49_));
  INVx1_ASAP7_75t_R    g006(.A(G28), .Y(new_n50_));
  AOI22x1_ASAP7_75t_R  g007(.A1(new_n49_), .A2(G34), .B1(new_n50_), .B2(G30), .Y(new_n51_));
  INVx1_ASAP7_75t_R    g008(.A(new_n51_), .Y(new_n52_));
  INVx1_ASAP7_75t_R    g009(.A(G24), .Y(new_n53_));
  INVx1_ASAP7_75t_R    g010(.A(G8), .Y(new_n54_));
  AOI22x1_ASAP7_75t_R  g011(.A1(new_n53_), .A2(G26), .B1(new_n54_), .B2(G10), .Y(new_n55_));
  INVx1_ASAP7_75t_R    g012(.A(new_n55_), .Y(new_n56_));
  INVx1_ASAP7_75t_R    g013(.A(G4), .Y(new_n57_));
  INVx1_ASAP7_75t_R    g014(.A(G1), .Y(new_n58_));
  AOI22x1_ASAP7_75t_R  g015(.A1(new_n57_), .A2(G6), .B1(new_n58_), .B2(G2), .Y(new_n59_));
  INVx1_ASAP7_75t_R    g016(.A(new_n59_), .Y(new_n60_));
  OR4x2_ASAP7_75t_R    g017(.A(new_n48_), .B(new_n52_), .C(new_n56_), .D(new_n60_), .Y(G426));
  INVx1_ASAP7_75t_R    g018(.A(G11), .Y(new_n62_));
  INVx1_ASAP7_75t_R    g019(.A(G31), .Y(new_n63_));
  OA21x2_ASAP7_75t_R   g020(.A1(G16), .A2(new_n44_), .B(new_n47_), .Y(new_n64_));
  AND2x2_ASAP7_75t_R   g021(.A(new_n55_), .B(new_n59_), .Y(new_n65_));
  AO31x2_ASAP7_75t_R   g022(.A1(new_n64_), .A2(new_n65_), .A3(new_n51_), .B(new_n50_), .Y(new_n66_));
  AND3x1_ASAP7_75t_R   g023(.A(new_n66_), .B(G30), .C(new_n63_), .Y(new_n67_));
  NAND2x1_ASAP7_75t_R  g024(.A(G26), .B(new_n53_), .Y(new_n68_));
  AND4x2_ASAP7_75t_R   g025(.A(new_n65_), .B(new_n64_), .C(new_n51_), .D(new_n68_), .Y(new_n69_));
  AND3x1_ASAP7_75t_R   g026(.A(new_n51_), .B(new_n55_), .C(new_n59_), .Y(new_n70_));
  AOI21x1_ASAP7_75t_R  g027(.A1(new_n64_), .A2(new_n70_), .B(new_n68_), .Y(new_n71_));
  INVx1_ASAP7_75t_R    g028(.A(G27), .Y(new_n72_));
  AND2x2_ASAP7_75t_R   g029(.A(new_n72_), .B(G26), .Y(new_n73_));
  OA21x2_ASAP7_75t_R   g030(.A1(new_n69_), .A2(new_n71_), .B(new_n73_), .Y(new_n74_));
  INVx1_ASAP7_75t_R    g031(.A(G10), .Y(new_n75_));
  AOI21x1_ASAP7_75t_R  g032(.A1(G8), .A2(G426), .B(new_n75_), .Y(new_n76_));
  AOI211x1_ASAP7_75t_R g033(.A1(new_n76_), .A2(new_n62_), .B(new_n74_), .C(new_n67_), .Y(new_n77_));
  INVx1_ASAP7_75t_R    g034(.A(G23), .Y(new_n78_));
  INVx1_ASAP7_75t_R    g035(.A(G15), .Y(new_n79_));
  AND3x1_ASAP7_75t_R   g036(.A(new_n65_), .B(new_n64_), .C(new_n51_), .Y(new_n80_));
  OA21x2_ASAP7_75t_R   g037(.A1(new_n80_), .A2(new_n45_), .B(G22), .Y(new_n81_));
  OA21x2_ASAP7_75t_R   g038(.A1(new_n80_), .A2(new_n46_), .B(G14), .Y(new_n82_));
  AOI22x1_ASAP7_75t_R  g039(.A1(new_n81_), .A2(new_n78_), .B1(new_n82_), .B2(new_n79_), .Y(new_n83_));
  INVx1_ASAP7_75t_R    g040(.A(G19), .Y(new_n84_));
  INVx1_ASAP7_75t_R    g041(.A(G3), .Y(new_n85_));
  AOI21x1_ASAP7_75t_R  g042(.A1(G16), .A2(G426), .B(new_n44_), .Y(new_n86_));
  OA21x2_ASAP7_75t_R   g043(.A1(new_n80_), .A2(new_n58_), .B(G2), .Y(new_n87_));
  AOI22x1_ASAP7_75t_R  g044(.A1(new_n86_), .A2(new_n84_), .B1(new_n87_), .B2(new_n85_), .Y(new_n88_));
  INVx1_ASAP7_75t_R    g045(.A(G35), .Y(new_n89_));
  INVx1_ASAP7_75t_R    g046(.A(G7), .Y(new_n90_));
  OA21x2_ASAP7_75t_R   g047(.A1(new_n80_), .A2(new_n49_), .B(G34), .Y(new_n91_));
  OA21x2_ASAP7_75t_R   g048(.A1(new_n80_), .A2(new_n57_), .B(G6), .Y(new_n92_));
  AOI22x1_ASAP7_75t_R  g049(.A1(new_n91_), .A2(new_n89_), .B1(new_n92_), .B2(new_n90_), .Y(new_n93_));
  AND4x2_ASAP7_75t_R   g050(.A(new_n77_), .B(new_n83_), .C(new_n88_), .D(new_n93_), .Y(new_n94_));
  INVx1_ASAP7_75t_R    g051(.A(new_n94_), .Y(G427));
  INVx1_ASAP7_75t_R    g052(.A(G25), .Y(new_n96_));
  INVx1_ASAP7_75t_R    g053(.A(G21), .Y(new_n97_));
  OA211x2_ASAP7_75t_R  g054(.A1(new_n94_), .A2(new_n84_), .B(new_n97_), .C(new_n86_), .Y(new_n98_));
  OA21x2_ASAP7_75t_R   g055(.A1(new_n94_), .A2(new_n78_), .B(new_n81_), .Y(new_n99_));
  INVx1_ASAP7_75t_R    g056(.A(G17), .Y(new_n100_));
  OA211x2_ASAP7_75t_R  g057(.A1(new_n94_), .A2(new_n79_), .B(new_n100_), .C(new_n82_), .Y(new_n101_));
  AOI211x1_ASAP7_75t_R g058(.A1(new_n99_), .A2(new_n96_), .B(new_n98_), .C(new_n101_), .Y(new_n102_));
  INVx1_ASAP7_75t_R    g059(.A(G9), .Y(new_n103_));
  INVx1_ASAP7_75t_R    g060(.A(G5), .Y(new_n104_));
  OA21x2_ASAP7_75t_R   g061(.A1(new_n94_), .A2(new_n90_), .B(new_n92_), .Y(new_n105_));
  OA21x2_ASAP7_75t_R   g062(.A1(new_n94_), .A2(new_n85_), .B(new_n87_), .Y(new_n106_));
  AOI22x1_ASAP7_75t_R  g063(.A1(new_n105_), .A2(new_n103_), .B1(new_n106_), .B2(new_n104_), .Y(new_n107_));
  AND2x2_ASAP7_75t_R   g064(.A(new_n66_), .B(G30), .Y(new_n108_));
  OAI21x1_ASAP7_75t_R  g065(.A1(new_n63_), .A2(new_n94_), .B(new_n108_), .Y(new_n109_));
  AO21x1_ASAP7_75t_R   g066(.A1(new_n94_), .A2(new_n67_), .B(G33), .Y(new_n110_));
  OAI21x1_ASAP7_75t_R  g067(.A1(new_n89_), .A2(new_n94_), .B(new_n91_), .Y(new_n111_));
  OA22x2_ASAP7_75t_R   g068(.A1(G36), .A2(new_n111_), .B1(new_n110_), .B2(new_n109_), .Y(new_n112_));
  OAI21x1_ASAP7_75t_R  g069(.A1(new_n62_), .A2(new_n94_), .B(new_n76_), .Y(new_n113_));
  AND2x2_ASAP7_75t_R   g070(.A(new_n94_), .B(new_n74_), .Y(new_n114_));
  INVx1_ASAP7_75t_R    g071(.A(G29), .Y(new_n115_));
  OA211x2_ASAP7_75t_R  g072(.A1(new_n69_), .A2(new_n71_), .B(G26), .C(new_n115_), .Y(new_n116_));
  OAI21x1_ASAP7_75t_R  g073(.A1(new_n74_), .A2(new_n94_), .B(new_n116_), .Y(new_n117_));
  OA22x2_ASAP7_75t_R   g074(.A1(G13), .A2(new_n113_), .B1(new_n114_), .B2(new_n117_), .Y(new_n118_));
  AND4x2_ASAP7_75t_R   g075(.A(new_n102_), .B(new_n107_), .C(new_n112_), .D(new_n118_), .Y(new_n119_));
  INVx1_ASAP7_75t_R    g076(.A(new_n119_), .Y(G428));
  OA21x2_ASAP7_75t_R   g077(.A1(new_n119_), .A2(new_n104_), .B(new_n106_), .Y(new_n121_));
  OA21x2_ASAP7_75t_R   g078(.A1(new_n94_), .A2(new_n84_), .B(new_n86_), .Y(new_n122_));
  OAI21x1_ASAP7_75t_R  g079(.A1(new_n97_), .A2(new_n119_), .B(new_n122_), .Y(new_n123_));
  OA21x2_ASAP7_75t_R   g080(.A1(new_n94_), .A2(new_n79_), .B(new_n82_), .Y(new_n124_));
  OAI21x1_ASAP7_75t_R  g081(.A1(new_n100_), .A2(new_n119_), .B(new_n124_), .Y(new_n125_));
  INVx1_ASAP7_75t_R    g082(.A(G13), .Y(new_n126_));
  INVx1_ASAP7_75t_R    g083(.A(new_n113_), .Y(new_n127_));
  OAI21x1_ASAP7_75t_R  g084(.A1(new_n126_), .A2(new_n119_), .B(new_n127_), .Y(new_n128_));
  OAI21x1_ASAP7_75t_R  g085(.A1(new_n103_), .A2(new_n119_), .B(new_n105_), .Y(new_n129_));
  AND4x2_ASAP7_75t_R   g086(.A(new_n123_), .B(new_n125_), .C(new_n128_), .D(new_n129_), .Y(new_n130_));
  INVx1_ASAP7_75t_R    g087(.A(G36), .Y(new_n131_));
  INVx1_ASAP7_75t_R    g088(.A(new_n111_), .Y(new_n132_));
  OAI21x1_ASAP7_75t_R  g089(.A1(new_n131_), .A2(new_n119_), .B(new_n132_), .Y(new_n133_));
  OA21x2_ASAP7_75t_R   g090(.A1(new_n80_), .A2(new_n53_), .B(G26), .Y(new_n134_));
  OA21x2_ASAP7_75t_R   g091(.A1(new_n94_), .A2(new_n72_), .B(new_n134_), .Y(new_n135_));
  OAI21x1_ASAP7_75t_R  g092(.A1(new_n115_), .A2(new_n119_), .B(new_n135_), .Y(new_n136_));
  OAI21x1_ASAP7_75t_R  g093(.A1(new_n96_), .A2(new_n119_), .B(new_n99_), .Y(new_n137_));
  INVx1_ASAP7_75t_R    g094(.A(G33), .Y(new_n138_));
  INVx1_ASAP7_75t_R    g095(.A(new_n109_), .Y(new_n139_));
  OAI21x1_ASAP7_75t_R  g096(.A1(new_n138_), .A2(new_n119_), .B(new_n139_), .Y(new_n140_));
  AND4x2_ASAP7_75t_R   g097(.A(new_n133_), .B(new_n136_), .C(new_n137_), .D(new_n140_), .Y(new_n141_));
  AOI21x1_ASAP7_75t_R  g098(.A1(new_n130_), .A2(new_n141_), .B(new_n121_), .Y(G429));
  INVx1_ASAP7_75t_R    g099(.A(new_n130_), .Y(G430));
  AND2x2_ASAP7_75t_R   g100(.A(new_n123_), .B(new_n125_), .Y(new_n144_));
  NAND2x1_ASAP7_75t_R  g101(.A(new_n128_), .B(new_n129_), .Y(new_n145_));
  OA21x2_ASAP7_75t_R   g102(.A1(new_n119_), .A2(new_n115_), .B(new_n135_), .Y(new_n146_));
  OA21x2_ASAP7_75t_R   g103(.A1(new_n119_), .A2(new_n96_), .B(new_n99_), .Y(new_n147_));
  AND4x2_ASAP7_75t_R   g104(.A(new_n147_), .B(new_n123_), .C(new_n125_), .D(new_n128_), .Y(new_n148_));
  AO211x2_ASAP7_75t_R  g105(.A1(new_n144_), .A2(new_n146_), .B(new_n145_), .C(new_n148_), .Y(G431));
  AND2x2_ASAP7_75t_R   g106(.A(new_n125_), .B(new_n128_), .Y(new_n150_));
  NOR2x1_ASAP7_75t_R   g107(.A(new_n140_), .B(new_n146_), .Y(new_n151_));
  OA21x2_ASAP7_75t_R   g108(.A1(new_n119_), .A2(new_n126_), .B(new_n127_), .Y(new_n152_));
  OAI21x1_ASAP7_75t_R  g109(.A1(new_n125_), .A2(new_n152_), .B(new_n129_), .Y(new_n153_));
  AO211x2_ASAP7_75t_R  g110(.A1(new_n150_), .A2(new_n151_), .B(new_n153_), .C(new_n148_), .Y(G432));
endmodule


