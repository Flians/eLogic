// Benchmark "/home/flynn/workplace/MIGBalance/results_v2/fixed_4in_area_20261012/c880.resyn2" written by ABC on Mon Oct 12 15:02:12 2026

module \/home/flynn/workplace/MIGBalance/results_v2/fixed_4in_area_20261012/c880.resyn2  ( 
    G8, G16, G6, G17, G7, G18, G19, G4, G3, G2, G1, G5, G11, G23, G20, G21,
    G9, G10, G12, G15, G22, G32, G24, G25, G26, G27, G28, G29, G30, G31,
    G33, G41, G42, G43, G44, G45, G46, G47, G48, G49, G13, G14, G55, G59,
    G54, G60, G39, G40, G52, G53, G50, G51, G58, G35, G37, G36, G56, G57,
    G34, G38,
    G855, G856, G857, G858, G859, G860, G861, G862, G863, G864, G865, G866,
    G867, G868, G869, G870, G871, G872, G873, G874, G875, G876, G877, G878,
    G879, G880  );
  input  G8, G16, G6, G17, G7, G18, G19, G4, G3, G2, G1, G5, G11, G23,
    G20, G21, G9, G10, G12, G15, G22, G32, G24, G25, G26, G27, G28, G29,
    G30, G31, G33, G41, G42, G43, G44, G45, G46, G47, G48, G49, G13, G14,
    G55, G59, G54, G60, G39, G40, G52, G53, G50, G51, G58, G35, G37, G36,
    G56, G57, G34, G38;
  output G855, G856, G857, G858, G859, G860, G861, G862, G863, G864, G865,
    G866, G867, G868, G869, G870, G871, G872, G873, G874, G875, G876, G877,
    G878, G879, G880;
  wire new_n87_, new_n88_, new_n89_, new_n91_, new_n92_, new_n96_, new_n97_,
    new_n98_, new_n99_, new_n101_, new_n108_, new_n110_, new_n112_,
    new_n115_, new_n116_, new_n117_, new_n118_, new_n119_, new_n120_,
    new_n121_, new_n122_, new_n124_, new_n125_, new_n126_, new_n127_,
    new_n128_, new_n129_, new_n130_, new_n131_, new_n133_, new_n134_,
    new_n135_, new_n136_, new_n137_, new_n138_, new_n139_, new_n140_,
    new_n141_, new_n142_, new_n143_, new_n144_, new_n145_, new_n146_,
    new_n147_, new_n148_, new_n149_, new_n150_, new_n151_, new_n152_,
    new_n153_, new_n154_, new_n155_, new_n156_, new_n157_, new_n158_,
    new_n159_, new_n160_, new_n161_, new_n162_, new_n163_, new_n164_,
    new_n165_, new_n166_, new_n167_, new_n169_, new_n170_, new_n171_,
    new_n172_, new_n173_, new_n174_, new_n175_, new_n176_, new_n177_,
    new_n178_, new_n179_, new_n180_, new_n181_, new_n182_, new_n183_,
    new_n184_, new_n185_, new_n186_, new_n187_, new_n188_, new_n189_,
    new_n190_, new_n192_, new_n193_, new_n194_, new_n195_, new_n196_,
    new_n197_, new_n198_, new_n199_, new_n201_, new_n202_, new_n203_,
    new_n204_, new_n205_, new_n206_, new_n207_, new_n208_, new_n209_,
    new_n210_, new_n212_, new_n213_, new_n214_, new_n215_, new_n216_,
    new_n217_, new_n218_, new_n219_, new_n220_, new_n221_, new_n222_,
    new_n223_, new_n224_, new_n225_, new_n226_, new_n227_, new_n228_,
    new_n229_, new_n230_, new_n231_, new_n232_, new_n233_, new_n234_,
    new_n235_, new_n236_, new_n237_, new_n238_, new_n239_, new_n240_,
    new_n241_, new_n242_, new_n243_, new_n244_, new_n245_, new_n246_,
    new_n247_, new_n248_, new_n249_, new_n251_, new_n252_, new_n253_,
    new_n254_, new_n255_, new_n256_, new_n257_, new_n259_, new_n260_,
    new_n261_, new_n262_, new_n263_, new_n264_, new_n265_, new_n267_,
    new_n268_, new_n269_, new_n270_, new_n271_, new_n272_, new_n273_,
    new_n274_, new_n275_, new_n277_, new_n278_, new_n279_, new_n280_,
    new_n281_, new_n282_, new_n283_, new_n284_;
  INVx1_ASAP7_75t_R    g000(.A(G8), .Y(new_n87_));
  INVx1_ASAP7_75t_R    g001(.A(G16), .Y(new_n88_));
  INVx1_ASAP7_75t_R    g002(.A(G6), .Y(new_n89_));
  OR3x1_ASAP7_75t_R    g003(.A(new_n87_), .B(new_n88_), .C(new_n89_), .Y(G855));
  INVx1_ASAP7_75t_R    g004(.A(G17), .Y(new_n91_));
  INVx1_ASAP7_75t_R    g005(.A(G7), .Y(new_n92_));
  OR3x1_ASAP7_75t_R    g006(.A(new_n89_), .B(new_n91_), .C(new_n92_), .Y(G856));
  OR3x1_ASAP7_75t_R    g007(.A(new_n87_), .B(new_n89_), .C(new_n92_), .Y(G857));
  NAND2x1_ASAP7_75t_R  g008(.A(G18), .B(G19), .Y(G858));
  INVx1_ASAP7_75t_R    g009(.A(G4), .Y(new_n96_));
  INVx1_ASAP7_75t_R    g010(.A(G3), .Y(new_n97_));
  INVx1_ASAP7_75t_R    g011(.A(G2), .Y(new_n98_));
  INVx1_ASAP7_75t_R    g012(.A(G1), .Y(new_n99_));
  OR4x2_ASAP7_75t_R    g013(.A(new_n96_), .B(new_n97_), .C(new_n98_), .D(new_n99_), .Y(G859));
  AND4x2_ASAP7_75t_R   g014(.A(G4), .B(G3), .C(G1), .D(G5), .Y(new_n101_));
  AND2x2_ASAP7_75t_R   g015(.A(G857), .B(new_n101_), .Y(G860));
  AND3x1_ASAP7_75t_R   g016(.A(G16), .B(G17), .C(G11), .Y(G861));
  AND3x1_ASAP7_75t_R   g017(.A(G17), .B(G7), .C(G11), .Y(G862));
  AND3x1_ASAP7_75t_R   g018(.A(G8), .B(G7), .C(G11), .Y(G863));
  OAI21x1_ASAP7_75t_R  g019(.A1(G20), .A2(G21), .B(G23), .Y(G864));
  AND4x2_ASAP7_75t_R   g020(.A(new_n101_), .B(G8), .C(G6), .D(G7), .Y(G865));
  AND3x1_ASAP7_75t_R   g021(.A(G1), .B(G5), .C(G9), .Y(new_n108_));
  INVx1_ASAP7_75t_R    g022(.A(new_n108_), .Y(G866));
  AND4x2_ASAP7_75t_R   g023(.A(G3), .B(G2), .C(G1), .D(G10), .Y(new_n110_));
  NAND3x1_ASAP7_75t_R  g024(.A(new_n110_), .B(G12), .C(G6), .Y(G867));
  AND3x1_ASAP7_75t_R   g025(.A(new_n110_), .B(G11), .C(G12), .Y(new_n112_));
  NAND2x1_ASAP7_75t_R  g026(.A(G15), .B(new_n112_), .Y(G868));
  OAI21x1_ASAP7_75t_R  g027(.A1(G20), .A2(G21), .B(G22), .Y(G869));
  XOR2x2_ASAP7_75t_R   g028(.A(G24), .B(G25), .Y(new_n115_));
  XOR2x2_ASAP7_75t_R   g029(.A(new_n115_), .B(G32), .Y(new_n116_));
  XOR2x2_ASAP7_75t_R   g030(.A(G30), .B(G31), .Y(new_n117_));
  XOR2x2_ASAP7_75t_R   g031(.A(new_n116_), .B(new_n117_), .Y(new_n118_));
  XOR2x2_ASAP7_75t_R   g032(.A(G28), .B(G29), .Y(new_n119_));
  XOR2x2_ASAP7_75t_R   g033(.A(new_n119_), .B(G33), .Y(new_n120_));
  XNOR2x2_ASAP7_75t_R  g034(.A(G26), .B(G27), .Y(new_n121_));
  XOR2x2_ASAP7_75t_R   g035(.A(new_n120_), .B(new_n121_), .Y(new_n122_));
  XOR2x2_ASAP7_75t_R   g036(.A(new_n118_), .B(new_n122_), .Y(G870));
  XOR2x2_ASAP7_75t_R   g037(.A(G41), .B(G42), .Y(new_n124_));
  XOR2x2_ASAP7_75t_R   g038(.A(new_n124_), .B(G32), .Y(new_n125_));
  XOR2x2_ASAP7_75t_R   g039(.A(G47), .B(G48), .Y(new_n126_));
  XOR2x2_ASAP7_75t_R   g040(.A(new_n125_), .B(new_n126_), .Y(new_n127_));
  XOR2x2_ASAP7_75t_R   g041(.A(G45), .B(G46), .Y(new_n128_));
  XOR2x2_ASAP7_75t_R   g042(.A(new_n128_), .B(G49), .Y(new_n129_));
  XNOR2x2_ASAP7_75t_R  g043(.A(G43), .B(G44), .Y(new_n130_));
  XOR2x2_ASAP7_75t_R   g044(.A(new_n129_), .B(new_n130_), .Y(new_n131_));
  XOR2x2_ASAP7_75t_R   g045(.A(new_n127_), .B(new_n131_), .Y(G871));
  INVx1_ASAP7_75t_R    g046(.A(G58), .Y(new_n133_));
  INVx1_ASAP7_75t_R    g047(.A(G48), .Y(new_n134_));
  AND2x2_ASAP7_75t_R   g048(.A(G11), .B(G40), .Y(new_n135_));
  INVx1_ASAP7_75t_R    g049(.A(new_n135_), .Y(new_n136_));
  AND2x2_ASAP7_75t_R   g050(.A(new_n136_), .B(new_n108_), .Y(new_n137_));
  AO21x1_ASAP7_75t_R   g051(.A1(new_n137_), .A2(G4), .B(new_n99_), .Y(new_n138_));
  OA21x2_ASAP7_75t_R   g052(.A1(new_n87_), .A2(new_n96_), .B(new_n135_), .Y(new_n139_));
  OA211x2_ASAP7_75t_R  g053(.A1(G8), .A2(G4), .B(new_n139_), .C(new_n108_), .Y(new_n140_));
  AND3x1_ASAP7_75t_R   g054(.A(G8), .B(G16), .C(G11), .Y(new_n141_));
  INVx1_ASAP7_75t_R    g055(.A(G9), .Y(new_n142_));
  OR4x2_ASAP7_75t_R    g056(.A(new_n96_), .B(new_n98_), .C(new_n99_), .D(new_n142_), .Y(new_n143_));
  NOR2x1_ASAP7_75t_R   g057(.A(new_n141_), .B(new_n143_), .Y(new_n144_));
  NOR2x1_ASAP7_75t_R   g058(.A(new_n140_), .B(new_n144_), .Y(new_n145_));
  INVx1_ASAP7_75t_R    g059(.A(new_n145_), .Y(new_n146_));
  INVx1_ASAP7_75t_R    g060(.A(G60), .Y(new_n147_));
  AND4x2_ASAP7_75t_R   g061(.A(new_n108_), .B(G16), .C(G6), .D(G17), .Y(new_n148_));
  AND3x1_ASAP7_75t_R   g062(.A(new_n148_), .B(G10), .C(new_n147_), .Y(new_n149_));
  AO21x1_ASAP7_75t_R   g063(.A1(new_n146_), .A2(G31), .B(new_n149_), .Y(new_n150_));
  AOI21x1_ASAP7_75t_R  g064(.A1(G39), .A2(new_n138_), .B(new_n150_), .Y(new_n151_));
  NOR2x1_ASAP7_75t_R   g065(.A(new_n134_), .B(new_n151_), .Y(new_n152_));
  AND2x2_ASAP7_75t_R   g066(.A(new_n151_), .B(new_n134_), .Y(new_n153_));
  OA21x2_ASAP7_75t_R   g067(.A1(new_n152_), .A2(new_n153_), .B(new_n133_), .Y(new_n154_));
  INVx1_ASAP7_75t_R    g068(.A(G51), .Y(new_n155_));
  INVx1_ASAP7_75t_R    g069(.A(new_n152_), .Y(new_n156_));
  NOR2x1_ASAP7_75t_R   g070(.A(new_n133_), .B(new_n153_), .Y(new_n157_));
  AO21x1_ASAP7_75t_R   g071(.A1(new_n157_), .A2(new_n156_), .B(new_n155_), .Y(new_n158_));
  INVx1_ASAP7_75t_R    g072(.A(G52), .Y(new_n159_));
  OR3x1_ASAP7_75t_R    g073(.A(new_n152_), .B(new_n153_), .C(new_n159_), .Y(new_n160_));
  INVx1_ASAP7_75t_R    g074(.A(G54), .Y(new_n161_));
  INVx1_ASAP7_75t_R    g075(.A(G53), .Y(new_n162_));
  OA21x2_ASAP7_75t_R   g076(.A1(new_n134_), .A2(new_n162_), .B(new_n161_), .Y(new_n163_));
  AND4x2_ASAP7_75t_R   g077(.A(new_n112_), .B(G8), .C(G13), .D(G14), .Y(new_n164_));
  AO22x1_ASAP7_75t_R   g078(.A1(G30), .A2(G50), .B1(G55), .B2(G59), .Y(new_n165_));
  AOI21x1_ASAP7_75t_R  g079(.A1(G48), .A2(new_n164_), .B(new_n165_), .Y(new_n166_));
  OA21x2_ASAP7_75t_R   g080(.A1(new_n151_), .A2(new_n163_), .B(new_n166_), .Y(new_n167_));
  OA211x2_ASAP7_75t_R  g081(.A1(new_n158_), .A2(new_n154_), .B(new_n160_), .C(new_n167_), .Y(G872));
  AO21x1_ASAP7_75t_R   g082(.A1(new_n138_), .A2(G35), .B(new_n149_), .Y(new_n169_));
  AO21x1_ASAP7_75t_R   g083(.A1(new_n146_), .A2(G28), .B(new_n169_), .Y(new_n170_));
  NOR2x1_ASAP7_75t_R   g084(.A(G45), .B(new_n170_), .Y(new_n171_));
  INVx1_ASAP7_75t_R    g085(.A(new_n171_), .Y(new_n172_));
  NAND2x1_ASAP7_75t_R  g086(.A(G45), .B(new_n170_), .Y(new_n173_));
  NAND2x1_ASAP7_75t_R  g087(.A(new_n173_), .B(new_n172_), .Y(new_n174_));
  AO21x1_ASAP7_75t_R   g088(.A1(new_n138_), .A2(G36), .B(new_n149_), .Y(new_n175_));
  AO21x1_ASAP7_75t_R   g089(.A1(new_n146_), .A2(G29), .B(new_n175_), .Y(new_n176_));
  NOR2x1_ASAP7_75t_R   g090(.A(G46), .B(new_n176_), .Y(new_n177_));
  NOR2x1_ASAP7_75t_R   g091(.A(new_n152_), .B(new_n157_), .Y(new_n178_));
  AO21x1_ASAP7_75t_R   g092(.A1(new_n138_), .A2(G37), .B(new_n149_), .Y(new_n179_));
  AO21x1_ASAP7_75t_R   g093(.A1(new_n146_), .A2(G30), .B(new_n179_), .Y(new_n180_));
  NOR2x1_ASAP7_75t_R   g094(.A(G47), .B(new_n180_), .Y(new_n181_));
  OR3x1_ASAP7_75t_R    g095(.A(new_n178_), .B(new_n177_), .C(new_n181_), .Y(new_n182_));
  NAND2x1_ASAP7_75t_R  g096(.A(G46), .B(new_n176_), .Y(new_n183_));
  NAND2x1_ASAP7_75t_R  g097(.A(G47), .B(new_n180_), .Y(new_n184_));
  OA211x2_ASAP7_75t_R  g098(.A1(new_n177_), .A2(new_n184_), .B(new_n182_), .C(new_n183_), .Y(new_n185_));
  OAI21x1_ASAP7_75t_R  g099(.A1(new_n174_), .A2(new_n185_), .B(G51), .Y(new_n186_));
  AO21x1_ASAP7_75t_R   g100(.A1(new_n174_), .A2(new_n185_), .B(new_n186_), .Y(new_n187_));
  AO21x1_ASAP7_75t_R   g101(.A1(G45), .A2(G53), .B(G54), .Y(new_n188_));
  AO22x1_ASAP7_75t_R   g102(.A1(new_n164_), .A2(G45), .B1(G27), .B2(G50), .Y(new_n189_));
  AOI21x1_ASAP7_75t_R  g103(.A1(new_n188_), .A2(new_n170_), .B(new_n189_), .Y(new_n190_));
  OA211x2_ASAP7_75t_R  g104(.A1(new_n159_), .A2(new_n174_), .B(new_n187_), .C(new_n190_), .Y(G873));
  XNOR2x2_ASAP7_75t_R  g105(.A(G46), .B(new_n176_), .Y(new_n192_));
  OA21x2_ASAP7_75t_R   g106(.A1(new_n178_), .A2(new_n181_), .B(new_n184_), .Y(new_n193_));
  OAI21x1_ASAP7_75t_R  g107(.A1(new_n192_), .A2(new_n193_), .B(G51), .Y(new_n194_));
  AO21x1_ASAP7_75t_R   g108(.A1(new_n192_), .A2(new_n193_), .B(new_n194_), .Y(new_n195_));
  AO21x1_ASAP7_75t_R   g109(.A1(G46), .A2(G53), .B(G54), .Y(new_n196_));
  AO22x1_ASAP7_75t_R   g110(.A1(G28), .A2(G50), .B1(G55), .B2(G56), .Y(new_n197_));
  AO21x1_ASAP7_75t_R   g111(.A1(new_n164_), .A2(G46), .B(new_n197_), .Y(new_n198_));
  AOI21x1_ASAP7_75t_R  g112(.A1(new_n196_), .A2(new_n176_), .B(new_n198_), .Y(new_n199_));
  OA211x2_ASAP7_75t_R  g113(.A1(new_n159_), .A2(new_n192_), .B(new_n195_), .C(new_n199_), .Y(G874));
  INVx1_ASAP7_75t_R    g114(.A(new_n178_), .Y(new_n201_));
  INVx1_ASAP7_75t_R    g115(.A(new_n181_), .Y(new_n202_));
  AND2x2_ASAP7_75t_R   g116(.A(new_n202_), .B(new_n184_), .Y(new_n203_));
  NAND2x1_ASAP7_75t_R  g117(.A(new_n203_), .B(new_n201_), .Y(new_n204_));
  OA21x2_ASAP7_75t_R   g118(.A1(new_n201_), .A2(new_n203_), .B(G51), .Y(new_n205_));
  AO21x1_ASAP7_75t_R   g119(.A1(G47), .A2(G53), .B(G54), .Y(new_n206_));
  AO22x1_ASAP7_75t_R   g120(.A1(G29), .A2(G50), .B1(G55), .B2(G57), .Y(new_n207_));
  AO21x1_ASAP7_75t_R   g121(.A1(new_n164_), .A2(G47), .B(new_n207_), .Y(new_n208_));
  AO21x1_ASAP7_75t_R   g122(.A1(new_n180_), .A2(new_n206_), .B(new_n208_), .Y(new_n209_));
  AO21x1_ASAP7_75t_R   g123(.A1(new_n203_), .A2(G52), .B(new_n209_), .Y(new_n210_));
  AOI21x1_ASAP7_75t_R  g124(.A1(new_n205_), .A2(new_n204_), .B(new_n210_), .Y(G875));
  INVx1_ASAP7_75t_R    g125(.A(G41), .Y(new_n212_));
  INVx1_ASAP7_75t_R    g126(.A(G24), .Y(new_n213_));
  AND3x1_ASAP7_75t_R   g127(.A(new_n136_), .B(G10), .C(new_n108_), .Y(new_n214_));
  NAND2x1_ASAP7_75t_R  g128(.A(G35), .B(new_n214_), .Y(new_n215_));
  INVx1_ASAP7_75t_R    g129(.A(G34), .Y(new_n216_));
  NAND3x1_ASAP7_75t_R  g130(.A(new_n148_), .B(new_n147_), .C(G4), .Y(new_n217_));
  OA21x2_ASAP7_75t_R   g131(.A1(new_n98_), .A2(new_n216_), .B(new_n217_), .Y(new_n218_));
  OA211x2_ASAP7_75t_R  g132(.A1(new_n213_), .A2(new_n145_), .B(new_n218_), .C(new_n215_), .Y(new_n219_));
  INVx1_ASAP7_75t_R    g133(.A(G27), .Y(new_n220_));
  INVx1_ASAP7_75t_R    g134(.A(G38), .Y(new_n221_));
  NAND2x1_ASAP7_75t_R  g135(.A(G39), .B(new_n214_), .Y(new_n222_));
  OA211x2_ASAP7_75t_R  g136(.A1(new_n216_), .A2(new_n221_), .B(new_n222_), .C(new_n217_), .Y(new_n223_));
  OA21x2_ASAP7_75t_R   g137(.A1(new_n220_), .A2(new_n145_), .B(new_n223_), .Y(new_n224_));
  INVx1_ASAP7_75t_R    g138(.A(new_n224_), .Y(new_n225_));
  OR2x4_ASAP7_75t_R    g139(.A(G44), .B(new_n225_), .Y(new_n226_));
  OA21x2_ASAP7_75t_R   g140(.A1(new_n185_), .A2(new_n171_), .B(new_n173_), .Y(new_n227_));
  INVx1_ASAP7_75t_R    g141(.A(new_n227_), .Y(new_n228_));
  AND2x2_ASAP7_75t_R   g142(.A(new_n228_), .B(new_n226_), .Y(new_n229_));
  INVx1_ASAP7_75t_R    g143(.A(G43), .Y(new_n230_));
  INVx1_ASAP7_75t_R    g144(.A(G26), .Y(new_n231_));
  NAND2x1_ASAP7_75t_R  g145(.A(G37), .B(new_n214_), .Y(new_n232_));
  OA21x2_ASAP7_75t_R   g146(.A1(new_n96_), .A2(new_n216_), .B(new_n217_), .Y(new_n233_));
  OA211x2_ASAP7_75t_R  g147(.A1(new_n231_), .A2(new_n145_), .B(new_n233_), .C(new_n232_), .Y(new_n234_));
  NAND2x1_ASAP7_75t_R  g148(.A(new_n230_), .B(new_n234_), .Y(new_n235_));
  INVx1_ASAP7_75t_R    g149(.A(G42), .Y(new_n236_));
  INVx1_ASAP7_75t_R    g150(.A(G25), .Y(new_n237_));
  NAND2x1_ASAP7_75t_R  g151(.A(G36), .B(new_n214_), .Y(new_n238_));
  OA21x2_ASAP7_75t_R   g152(.A1(new_n142_), .A2(new_n216_), .B(new_n217_), .Y(new_n239_));
  OA211x2_ASAP7_75t_R  g153(.A1(new_n237_), .A2(new_n145_), .B(new_n239_), .C(new_n238_), .Y(new_n240_));
  NAND2x1_ASAP7_75t_R  g154(.A(new_n236_), .B(new_n240_), .Y(new_n241_));
  AND2x2_ASAP7_75t_R   g155(.A(new_n235_), .B(new_n241_), .Y(new_n242_));
  NOR2x1_ASAP7_75t_R   g156(.A(new_n236_), .B(new_n240_), .Y(new_n243_));
  NOR2x1_ASAP7_75t_R   g157(.A(new_n230_), .B(new_n234_), .Y(new_n244_));
  AND2x2_ASAP7_75t_R   g158(.A(new_n225_), .B(G44), .Y(new_n245_));
  OA21x2_ASAP7_75t_R   g159(.A1(new_n245_), .A2(new_n244_), .B(new_n235_), .Y(new_n246_));
  AO21x1_ASAP7_75t_R   g160(.A1(new_n246_), .A2(new_n241_), .B(new_n243_), .Y(new_n247_));
  AO21x1_ASAP7_75t_R   g161(.A1(new_n229_), .A2(new_n242_), .B(new_n247_), .Y(new_n248_));
  INVx1_ASAP7_75t_R    g162(.A(new_n248_), .Y(new_n249_));
  MAJx2_ASAP7_75t_R    g163(.A(new_n249_), .B(new_n212_), .C(new_n219_), .Y(G876));
  INVx1_ASAP7_75t_R    g164(.A(new_n245_), .Y(new_n251_));
  NAND2x1_ASAP7_75t_R  g165(.A(new_n226_), .B(new_n251_), .Y(new_n252_));
  OAI21x1_ASAP7_75t_R  g166(.A1(new_n252_), .A2(new_n227_), .B(G51), .Y(new_n253_));
  AO21x1_ASAP7_75t_R   g167(.A1(new_n227_), .A2(new_n252_), .B(new_n253_), .Y(new_n254_));
  AO21x1_ASAP7_75t_R   g168(.A1(G44), .A2(G53), .B(G54), .Y(new_n255_));
  AO22x1_ASAP7_75t_R   g169(.A1(new_n164_), .A2(G44), .B1(G26), .B2(G50), .Y(new_n256_));
  AOI21x1_ASAP7_75t_R  g170(.A1(new_n255_), .A2(new_n225_), .B(new_n256_), .Y(new_n257_));
  OA211x2_ASAP7_75t_R  g171(.A1(new_n159_), .A2(new_n252_), .B(new_n254_), .C(new_n257_), .Y(G877));
  XOR2x2_ASAP7_75t_R   g172(.A(new_n219_), .B(new_n212_), .Y(new_n259_));
  NOR2x1_ASAP7_75t_R   g173(.A(new_n259_), .B(new_n248_), .Y(new_n260_));
  AO21x1_ASAP7_75t_R   g174(.A1(new_n248_), .A2(new_n259_), .B(new_n155_), .Y(new_n261_));
  NAND2x1_ASAP7_75t_R  g175(.A(G52), .B(new_n259_), .Y(new_n262_));
  OA21x2_ASAP7_75t_R   g176(.A1(new_n212_), .A2(new_n162_), .B(new_n161_), .Y(new_n263_));
  AOI22x1_ASAP7_75t_R  g177(.A1(G60), .A2(G50), .B1(new_n164_), .B2(G41), .Y(new_n264_));
  OA21x2_ASAP7_75t_R   g178(.A1(new_n219_), .A2(new_n263_), .B(new_n264_), .Y(new_n265_));
  OA211x2_ASAP7_75t_R  g179(.A1(new_n260_), .A2(new_n261_), .B(new_n262_), .C(new_n265_), .Y(G878));
  INVx1_ASAP7_75t_R    g180(.A(new_n243_), .Y(new_n267_));
  AND2x2_ASAP7_75t_R   g181(.A(new_n267_), .B(new_n241_), .Y(new_n268_));
  AO21x1_ASAP7_75t_R   g182(.A1(new_n229_), .A2(new_n235_), .B(new_n246_), .Y(new_n269_));
  NOR2x1_ASAP7_75t_R   g183(.A(new_n268_), .B(new_n269_), .Y(new_n270_));
  AO21x1_ASAP7_75t_R   g184(.A1(new_n269_), .A2(new_n268_), .B(new_n155_), .Y(new_n271_));
  NAND2x1_ASAP7_75t_R  g185(.A(G52), .B(new_n268_), .Y(new_n272_));
  OA21x2_ASAP7_75t_R   g186(.A1(new_n236_), .A2(new_n162_), .B(new_n161_), .Y(new_n273_));
  AOI22x1_ASAP7_75t_R  g187(.A1(G24), .A2(G50), .B1(new_n164_), .B2(G42), .Y(new_n274_));
  OA21x2_ASAP7_75t_R   g188(.A1(new_n240_), .A2(new_n273_), .B(new_n274_), .Y(new_n275_));
  OA211x2_ASAP7_75t_R  g189(.A1(new_n270_), .A2(new_n271_), .B(new_n272_), .C(new_n275_), .Y(G879));
  INVx1_ASAP7_75t_R    g190(.A(new_n244_), .Y(new_n277_));
  NAND2x1_ASAP7_75t_R  g191(.A(new_n235_), .B(new_n277_), .Y(new_n278_));
  NOR2x1_ASAP7_75t_R   g192(.A(new_n245_), .B(new_n229_), .Y(new_n279_));
  OAI21x1_ASAP7_75t_R  g193(.A1(new_n278_), .A2(new_n279_), .B(G51), .Y(new_n280_));
  AO21x1_ASAP7_75t_R   g194(.A1(new_n278_), .A2(new_n279_), .B(new_n280_), .Y(new_n281_));
  OA21x2_ASAP7_75t_R   g195(.A1(new_n230_), .A2(new_n162_), .B(new_n161_), .Y(new_n282_));
  AOI22x1_ASAP7_75t_R  g196(.A1(G25), .A2(G50), .B1(new_n164_), .B2(G43), .Y(new_n283_));
  OA21x2_ASAP7_75t_R   g197(.A1(new_n234_), .A2(new_n282_), .B(new_n283_), .Y(new_n284_));
  OA211x2_ASAP7_75t_R  g198(.A1(new_n159_), .A2(new_n278_), .B(new_n281_), .C(new_n284_), .Y(G880));
endmodule


