//! A complete physical-cover transaction. No candidate generation or extra recovery clock.
//! Kept separate from live proposal search until generation provenance is qualified.
use super::*;

#[derive(Clone)]
pub(super) struct State {
    pub cuts: Vec<BTreeSet<Cut>>,
    pub instances: Vec<Instance>,
    pub chosen: Vec<Option<Binding>>,
}

fn check_clock(deadline: Instant) -> Result<(), String> {
    if Instant::now() >= deadline { Err("exchange: original global deadline".into()) } else { Ok(()) }
}

// A truth key over canonical positive variables. Both tied inputs and constants are
// substituted before support reduction; output phase is part of the equation.
fn truth_key(inputs: &[usize], tt: u64, target: usize, aliases: &[usize], constants: &[Option<bool>]) -> Result<(usize, Cut), String> {
    if inputs.len() > 6 || target >= aliases.len() || inputs.iter().any(|&s| s >= aliases.len()) {
        return Err("exchange: invalid truth boundary".into());
    }
    let target = aliases[target];
    let mapped: Vec<_> = inputs.iter().map(|&s| aliases[s]).collect();
    if target >= aliases.len() || mapped.iter().any(|&s| s >= constants.len()) {
        return Err("exchange: invalid canonical boundary".into());
    }
    let leaves: Vec<_> = mapped.iter().filter(|&&s| constants[s].is_none()).map(|s| s / 2).collect::<BTreeSet<_>>().into_iter().collect();
    let mut function = 0;
    for a in 0..1usize << leaves.len() {
        let mut physical = 0;
        for (i, &s) in mapped.iter().enumerate() {
            let value = constants[s].unwrap_or_else(|| (((a >> leaves.binary_search(&(s / 2)).unwrap()) & 1) != 0) ^ (s & 1 != 0));
            physical |= usize::from(value) << i;
        }
        let value = ((tt >> physical) & 1) ^ (target & 1) as u64;
        function |= value << a;
    }
    Ok((target / 2, reduce(Cut { leaves, function })))
}

fn cut_index(cuts: &[BTreeSet<Cut>], aliases: &[usize], constants: &[Option<bool>], deadline: Instant) -> Result<BTreeMap<(usize,Cut),Vec<(usize,Cut)>>,String> {
    let mut index: BTreeMap<_,Vec<_>> = BTreeMap::new();
    for (class, bank) in cuts.iter().enumerate() {
        check_clock(deadline)?;
        for cut in bank {
            let inputs: Vec<_> = cut.leaves.iter().map(|c| c * 2).collect();
            let key = truth_key(&inputs, cut.function, class * 2, aliases, constants)?;
            index.entry(key).or_default().push((class,cut.clone()));
        }
    }
    Ok(index)
}

fn checked_cover(instances: &[Instance], cover: &[Option<Binding>], free: &[bool], roots: &[usize]) -> Result<Vec<Option<Binding>>,String> {
    if cover.len() != free.len() || roots.iter().any(|&s|s>=free.len()) { return Err("exchange: invalid cover shape".into()); }
    for b in cover.iter().flatten() {
        let m=instances.get(b.instance).ok_or("exchange: invalid physical ID")?;
        let o=m.outputs.get(b.pin).ok_or("exchange: invalid output pin")?;
        if m.inputs.len()>6 || m.inputs.len()!=o.delays.len() || m.inputs.len()!=m.input_pins.len() || !m.area.is_finite() || m.area<0.0 || o.delays.iter().any(|d|!d.is_finite() || *d<0.0) || m.inputs.iter().any(|&s|s>=free.len()) || o.targets.iter().any(|&s|s>=free.len()) { return Err("exchange: invalid physical boundary".into()); }
    }
    let mut out=cover.to_vec();
    prune(instances,&mut out,free,roots)?;
    let value=metrics(instances,&out,free,roots);
    if !value.0.is_finite() || !value.1.is_finite() {return Err("exchange: nonfinite cover metrics".into());}
    Ok(out)
}

// The masks below may ONLY come from this map's already evaluated fixed-graph
// Reachability cache. Reading a certificate issues no new semantic query and
// never unions conditional equalities into egg.
fn care_support(m:&Instance,pin:usize,target:usize,class:usize,cut:&Cut,care:u64,aliases:&[usize],constants:&[Option<bool>])->bool{
 if aliases[class*2]/2!=aliases[target]/2 || cut.leaves.len()>6 || care==0 || care & !super::mask(cut.leaves.len())!=0 {return false;}
 let mut witnessed=false;
 for a in 0..1usize<<cut.leaves.len(){
  if (care>>a)&1==0 {continue;}
  let mut values=BTreeMap::new();let mut consistent=true;
  for(i,&c)in cut.leaves.iter().enumerate(){let s=aliases[c*2];let value=((a>>i)&1!=0)^(s&1!=0);if constants[s].is_some_and(|v|v!=((a>>i)&1!=0)){consistent=false;break;}if values.insert(s/2,value).is_some_and(|old|old!=value){consistent=false;break;}}
  if !consistent {continue;}
  witnessed=true;
  let mut physical=0;
  for(i,&raw)in m.inputs.iter().enumerate(){let s=aliases[raw];let value=if let Some(v)=constants[s]{v}else{let Some(&v)=values.get(&(s/2))else{return false;};v^(s&1!=0)};physical|=usize::from(value)<<i;}
  let actual=((m.outputs[pin].function>>physical)&1)^((aliases[target]&1)as u64);
  let expected=((cut.function>>a)&1)^((aliases[class*2]&1)as u64);
  if actual!=expected{return false;}
 }
 witnessed
}
fn conditional_support(m:&Instance,pin:usize,target:usize,cuts:&[BTreeSet<Cut>],care:&HashMap<Vec<usize>,Option<u64>>,aliases:&[usize],constants:&[Option<bool>],deadline:Instant)->Result<Option<(usize,Cut)>,String>{
 for(class,bank)in cuts.iter().enumerate(){
  check_clock(deadline)?;
  if aliases[class*2]/2!=aliases[target]/2 {continue;}
  for cut in bank {if let Some(Some(mask))=care.get(&cut.leaves){if *mask!=super::mask(cut.leaves.len()) && care_support(m,pin,target,class,cut,*mask,aliases,constants){return Ok(Some((class,cut.clone())));}}}
 }
 Ok(None)
}

fn same_physical(a:&Instance,b:&Instance)->bool {
    a.cell==b.cell && a.inputs==b.inputs && a.input_pins==b.input_pins && a.outputs.len()==b.outputs.len() && a.outputs.iter().zip(&b.outputs).all(|(a,b)|a.name==b.name && a.function==b.function) && a.area.to_bits()==b.area.to_bits() && a.outputs.iter().zip(&b.outputs).all(|(a,b)|a.delays.iter().map(|x|x.to_bits()).eq(b.delays.iter().map(|x|x.to_bits())))
}

// A newly admitted equality needs an exact derivation, even when unused by
// the incumbent. This first seam supports one retained-cut substitution only.
// Other rewrite/SDC derivations must supply a separate validated certificate.
fn derivable(cut:&Cut, class:usize, old:&[BTreeSet<Cut>], max_inputs:usize, deadline:Instant)->Result<bool,String>{
    for parent in &old[class] {
        for (position,&leaf) in parent.leaves.iter().enumerate() {
            check_clock(deadline)?;
            let Some(children)=old.get(leaf) else {return Err("exchange: invalid source cut leaf".into())};
            for child in children {
                if child.leaves.contains(&leaf){continue;}
                let leaves:Vec<_>=parent.leaves.iter().enumerate().filter_map(|(i,&s)|(i!=position).then_some(s)).chain(child.leaves.iter().copied()).collect::<BTreeSet<_>>().into_iter().collect();
                if leaves.len()>max_inputs{continue;}
                let mut function=0;
                for a in 0..1usize<<leaves.len(){
                    let child_a=child.leaves.iter().enumerate().fold(0,|v,(i,s)|v|(((a>>leaves.binary_search(s).unwrap())&1)<<i));
                    let value=((child.function>>child_a)&1) as usize;
                    let parent_a=parent.leaves.iter().enumerate().fold(0,|v,(i,s)|v|((if i==position{value}else{(a>>leaves.binary_search(s).unwrap())&1})<<i));
                    function|=((parent.function>>parent_a)&1)<<a;
                }
                if reduce(Cut{leaves,function})==*cut{return Ok(true);}
            }
        }
    }
    Ok(false)
}

/// Commit only after old physical bindings, their actual cut support, and the
/// proposed whole cover have all survived validation. No mutation on any error.
/// `deadline` MUST come from the caller's one inclusive recovery window.
/// SDC-only provenance deliberately fails closed: unconditional truth is not a
/// substitute for an unavailable reachable-image proof.
#[allow(dead_code)]
pub(super) fn commit(old:&mut State, proposal:State, aliases:&[usize], constants:&[Option<bool>], free:&[bool], roots:&[usize], ps:&MapParams, deadline:Instant)->Result<(f64,f64),String> {
 commit_with_care(old,proposal,aliases,constants,free,roots,ps,deadline,&HashMap::new())
}
#[allow(dead_code)]
pub(super) fn commit_with_care(old:&mut State, mut proposal:State, aliases:&[usize], constants:&[Option<bool>], free:&[bool], roots:&[usize], ps:&MapParams, deadline:Instant,care:&HashMap<Vec<usize>,Option<u64>>)->Result<(f64,f64),String> {
    check_clock(deadline)?;
    if aliases.len()!=free.len() || constants.len()!=free.len() || aliases.iter().any(|&s|s>=aliases.len() || aliases[s]!=s) {return Err("exchange: invalid fixed canonical interface".into());}
    if old.cuts.len()!=proposal.cuts.len() || proposal.cuts.len()*2!=free.len() || proposal.cuts.iter().any(|c|c.len()>ps.cuts_per_class || c.iter().any(|c|c.leaves.len()>ps.max_inputs)) || proposal.instances.len()>ps.max_instances {return Err("exchange: aggregate active cut/pool budget".into());}
    for (class,bank) in proposal.cuts.iter().enumerate(){
        for cut in bank.difference(&old.cuts[class]){
            if !derivable(cut,class,&old.cuts,ps.max_inputs,deadline)? {return Err("exchange: missing exact cut derivation".into());}
        }
    }
    let checked=checked_cover(&old.instances,&old.chosen,free,roots)?;
    let old_value=metrics(&old.instances,&checked,free,roots);
    let old_index=cut_index(&old.cuts,aliases,constants,deadline)?;
    let new_index=cut_index(&proposal.cuts,aliases,constants,deadline)?;
    let mut old_replay=vec![None;free.len()];
    let mut remap=BTreeMap::new();
    for (s,b) in checked.iter().enumerate().filter_map(|(s,b)|b.map(|b|(s,b))) {
        check_clock(deadline)?;
        let m=&old.instances[b.instance];
        let key=truth_key(&m.inputs,m.outputs[b.pin].function,s,aliases,constants)?;
        let support=if let Some(keys)=old_index.get(&key){keys.clone()}else{conditional_support(m,b.pin,s,&old.cuts,care,aliases,constants,deadline)?.into_iter().collect()};
        if support.is_empty(){return Err(format!("exchange: incumbent has no cut/care provenance: signal={s} cell={} inputs={:?} key={key:?}",m.cell,m.inputs));}
        if !support.iter().any(|(c,k)|proposal.cuts[*c].contains(k)) {return Err("exchange: selected input-cone/phase/care cut was evicted".into());}
        let i=if let Some(&i)=remap.get(&b.instance){i}else{
            let i=proposal.instances.iter().position(|n|same_physical(m,n)).ok_or("exchange: shared physical instance was evicted")?;
            remap.insert(b.instance,i);i
        };
        if !proposal.instances[i].outputs[b.pin].targets.contains(&s) {return Err("exchange: demanded joint pin/phase binding was evicted".into());}
        old_replay[s]=Some(Binding{instance:i,pin:b.pin});
    }
    // Every admitted binding needs exact live-bank support. A cached output
    // whose last cut disappeared may not remain as a hidden eligible candidate.
    for m in &proposal.instances {
        check_clock(deadline)?;
        for (pin,o) in m.outputs.iter().enumerate() {for &s in &o.targets {
            if !new_index.contains_key(&truth_key(&m.inputs,o.function,s,aliases,constants)?) && conditional_support(m,pin,s,&proposal.cuts,care,aliases,constants,deadline)?.is_none() {return Err("exchange: uncharged or unsupported eligible binding".into());}
        }}
    }
    let replay=checked_cover(&proposal.instances,&old_replay,free,roots)?;
    let replay_value=metrics(&proposal.instances,&replay,free,roots);
    // Physical order can change f64 area summation at roundoff scale. Preserve
    // old ordering in callers where bitwise identity is required.
    if (replay_value.0-old_value.0).abs()>1e-8 || replay_value.1!=old_value.1 {return Err("exchange: incumbent replay changed actual metrics".into());}
    let candidate=checked_cover(&proposal.instances,&proposal.chosen,free,roots)?;
    let value=metrics(&proposal.instances,&candidate,free,roots);
    if value.1>old_value.1 || (value.1==old_value.1 && value.0>old_value.0) {return Err("exchange: whole-cover (D,A) regression".into());}
    if ps.max_delay.is_some_and(|d|value.1>d) {return Err("exchange: fixed timing bound".into());}
    check_clock(deadline)?;
    proposal.chosen=candidate;
    *old=proposal;
    Ok(value)
}

#[cfg(test)] mod tests {
 use super::*;
 fn fixture()->(State,Vec<usize>,Vec<Option<bool>>,Vec<bool>,Vec<usize>,MapParams){
  let mut cuts=vec![BTreeSet::new();3];for (c,bank) in cuts.iter_mut().enumerate(){bank.insert(Cut{leaves:vec![c],function:2});}cuts[1].insert(Cut{leaves:vec![0],function:2});cuts[2].insert(Cut{leaves:vec![0],function:2});
  let output=|name:&str,s|OutputPin{name:name.into(),function:2,delays:vec![1.],targets:vec![s]};
  let m=Instance{cell:"DUAL".into(),area:1.5,inputs:vec![0],input_pins:vec!["A".into()],outputs:vec![output("Y",2),output("Z",4)]};
  let mut chosen=vec![None;6];chosen[2]=Some(Binding{instance:0,pin:0});chosen[4]=Some(Binding{instance:0,pin:1});
  let ps=MapParams{max_inputs:4,cuts_per_class:2,max_instances:2,objective:MapObjective::DelayArea,..Default::default()};
  (State{cuts,instances:vec![m],chosen},(0..6).collect(),vec![None;6],vec![true,true,false,false,false,false],vec![2,4],ps)
 }
 fn run(old:&mut State,new:State)->Result<(f64,f64),String>{let (_,a,c,f,r,p)=fixture();commit(old,new,&a,&c,&f,&r,&p,Instant::now()+std::time::Duration::from_secs(2))}
 #[test]fn evicting_one_selected_joint_pin_is_atomic_rejection(){let(mut old,..)=fixture();let mut new=old.clone();new.instances[0].outputs[1].targets.clear();assert!(run(&mut old,new).is_err());assert_eq!(old.instances[0].outputs[1].targets,vec![4]);}
 #[test]fn evicting_selected_cone_cut_is_rejected(){let(mut old,..)=fixture();let mut new=old.clone();new.cuts[2].remove(&Cut{leaves:vec![0],function:2});assert!(run(&mut old,new).is_err());assert_eq!(old.cuts[2].len(),2);}
 #[test]fn same_delay_more_area_is_rejected(){let(mut old,..)=fixture();let mut new=old.clone();let mut m=new.instances[0].clone();m.area=2.;new.instances.push(m);for b in new.chosen.iter_mut().flatten(){b.instance=1;}assert!(run(&mut old,new).is_err());assert_eq!(old.instances.len(),1);}
 #[test]fn safe_unused_cut_retirement_preserves_whole_shared_cover(){let(mut old,..)=fixture();let redundant=Cut{leaves:vec![0,1],function:10};old.cuts[2].insert(redundant.clone());let mut new=old.clone();new.cuts[2].remove(&redundant);assert_eq!(run(&mut old,new).unwrap(),(1.5,1.));assert_eq!(old.cuts[2].len(),2);}
 #[test]fn lower_area_same_delay_commits_without_double_charge(){let(mut old,..)=fixture();let mut new=old.clone();let mut m=new.instances[0].clone();m.area=1.;new.instances.push(m);for b in new.chosen.iter_mut().flatten(){b.instance=1;}assert_eq!(run(&mut old,new).unwrap(),(1.,1.));}
 #[test]fn eligible_union_cannot_hide_extra_pool(){let(mut old,..)=fixture();let mut new=old.clone();new.instances.push(new.instances[0].clone());new.instances.push(new.instances[0].clone());assert!(run(&mut old,new).is_err());}
 #[test]fn new_unrepresented_binding_is_rejected(){let(mut old,..)=fixture();let mut new=old.clone();let mut m=new.instances[0].clone();m.outputs[0].function=1;new.instances.push(m);assert!(run(&mut old,new).is_err());}
 #[test]fn reverse_phase_truth_and_tied_inputs_are_exact(){let a:Vec<_>=(0..8).collect();let c=vec![None;8];assert_eq!(truth_key(&[1,0],6,3,&a,&c).unwrap(),(1,Cut{leaves:vec![],function:0}));assert_eq!(truth_key(&[1],1,2,&a,&c).unwrap(),(1,Cut{leaves:vec![0],function:2}));}
 #[test]fn unproved_new_cut_cannot_be_admitted_even_if_unused(){let(mut old,..)=fixture();let mut new=old.clone();new.cuts[2].remove(&Cut{leaves:vec![2],function:2});new.cuts[2].insert(Cut{leaves:vec![],function:0});assert!(run(&mut old,new).is_err(),"an unused fabricated equality can generate wrong gates later");}
 #[test]fn conditional_joint_cover_retains_fixed_boundary_certificate(){
  let(mut old,a,c,_,_,p)=fixture();old.cuts[2].clear();old.cuts[2].insert(Cut{leaves:vec![0,1],function:8});old.cuts[2].insert(Cut{leaves:vec![2],function:2});
  old.instances[0].outputs.truncate(1);let mut or=old.instances[0].clone();or.cell="OR".into();or.inputs=vec![0,2];or.input_pins=vec!["A".into(),"B".into()];or.outputs[0].function=14;or.outputs[0].delays=vec![1.,1.];or.outputs[0].targets=vec![4];old.instances.push(or);old.chosen[4]=Some(Binding{instance:1,pin:0});
  let f=vec![true,false,false,false,false,false];let r=vec![4];let care=HashMap::from([(vec![0,1],Some(9))]);
  assert!(commit(&mut old.clone(),old.clone(),&a,&c,&f,&r,&p,Instant::now()+std::time::Duration::from_secs(2)).is_err());
  let new=old.clone();assert!(commit_with_care(&mut old,new,&a,&c,&f,&r,&p,Instant::now()+std::time::Duration::from_secs(2),&care).is_ok());
  let mut bad=old.clone();bad.cuts[2].remove(&Cut{leaves:vec![0,1],function:8});assert!(commit_with_care(&mut old,bad,&a,&c,&f,&r,&p,Instant::now()+std::time::Duration::from_secs(2),&care).is_err());
 }
 #[test]fn cut_substitution_is_an_exact_new_equality(){let(mut old,..)=fixture();old.cuts[2].clear();old.cuts[2].insert(Cut{leaves:vec![1],function:2});assert!(derivable(&Cut{leaves:vec![0],function:2},2,&old.cuts,4,Instant::now()+std::time::Duration::from_secs(2)).unwrap());assert!(!derivable(&Cut{leaves:vec![],function:0},2,&old.cuts,4,Instant::now()+std::time::Duration::from_secs(2)).unwrap());}
 #[test]fn old_deadline_is_not_reset(){let(mut old,a,c,f,r,p)=fixture();let new=old.clone();assert!(commit(&mut old,new,&a,&c,&f,&r,&p,Instant::now()).is_err());}
 #[test]fn cyclic_candidate_is_rejected_with_incumbent_untouched(){let(mut old,..)=fixture();let mut new=old.clone();let mut m=new.instances[0].clone();m.inputs=vec![2];new.instances.push(m);new.chosen[2]=Some(Binding{instance:1,pin:0});assert!(run(&mut old,new).is_err());assert_eq!(old.chosen[2].unwrap().instance,0);}
 #[test]fn invalid_physical_id_is_error_not_panic(){let(mut old,..)=fixture();let mut new=old.clone();new.chosen[2]=Some(Binding{instance:99,pin:0});assert!(run(&mut old,new).is_err());}
}

#[cfg(test)] mod observed_replay {
 use super::*;
 #[test] #[ignore="explicit read-only frozen-cover replay; not live mapped PPA"]
 fn replay_frozen_covers(){
  let list:Vec<serde_json::Value>=serde_json::from_slice(&std::fs::read(std::env::var("EGM_REPLAY_LIST").unwrap()).unwrap()).unwrap();let mut rows=Vec::new();
  for item in list {
   let d:serde_json::Value=serde_json::from_slice(&std::fs::read(item["path"].as_str().unwrap()).unwrap()).unwrap();
   let aliases:Vec<usize>=serde_json::from_value(d["canonical_signals"].clone()).unwrap();let free:Vec<bool>=serde_json::from_value(d["free"].clone()).unwrap();let roots:Vec<usize>=serde_json::from_value(d["roots"].clone()).unwrap();
   let mut constants=vec![None;free.len()];for c in d["egraph_nodes"].as_array().unwrap(){if c["nodes"].as_str().unwrap()=="[Zero]"{let s=aliases[c["class"].as_u64().unwrap() as usize*2];constants[s]=Some(false);constants[s^1]=Some(true);}}
   let mut cuts=vec![BTreeSet::new();free.len()/2];for c in d["cuts"].as_array().unwrap(){cuts[c["class"].as_u64().unwrap() as usize].insert(Cut{leaves:serde_json::from_value(c["leaves"].clone()).unwrap(),function:c["function"].as_u64().unwrap()});}
   let mut instances=Vec::new();let mut chosen=vec![None;free.len()];for m in d["selected_instances"].as_array().unwrap(){let i=instances.len();let mut outputs=Vec::new();for o in m["outputs"].as_array().unwrap(){let targets:Vec<usize>=serde_json::from_value(o["selected_targets"].clone()).unwrap();let pin=outputs.len();assert_eq!(o["pin"].as_u64().unwrap() as usize,pin);for &s in &targets{chosen[s]=Some(Binding{instance:i,pin});}outputs.push(OutputPin{name:o["name"].as_str().unwrap().into(),function:o["function"].as_u64().unwrap(),delays:serde_json::from_value(o["delays"].clone()).unwrap(),targets});}instances.push(Instance{cell:m["cell"].as_str().unwrap().into(),area:m["area"].as_f64().unwrap() as f32,inputs:serde_json::from_value(m["inputs"].clone()).unwrap(),input_pins:serde_json::from_value(m["input_pins"].clone()).unwrap(),outputs});}
   let mut care=HashMap::new();if let Some(cs)=d["care_boundaries"].as_array(){for c in cs{care.insert(serde_json::from_value(c["leaves"].clone()).unwrap(),Some(c["care"].as_u64().unwrap()));}}
   let mut old=State{cuts,instances,chosen};let ps=MapParams{max_inputs:item["k"].as_u64().unwrap() as usize,cuts_per_class:16,max_instances:100000,..Default::default()};let start=Instant::now();let result=commit_with_care(&mut old.clone(),old.clone(),&aliases,&constants,&free,&roots,&ps,start+std::time::Duration::from_secs(2),&care);let original=(d["area"].as_f64().unwrap(),d["delay"].as_f64().unwrap());let actual=metrics(&old.instances,&old.chosen,&free,&roots);
   // Old reconstruction must independently calibrate before using the seam result.
   assert!((actual.0-original.0).abs()<1e-7 && (actual.1-original.1).abs()<1e-9,"physical snapshot calibration {}: reconstructed {:?}, recorded {:?}",item["name"],actual,original);
   rows.push(serde_json::json!({"name":item["name"],"result":result,"seconds":start.elapsed().as_secs_f64(),"area":actual.0,"delay":actual.1,"instances":old.instances.len(),"scope":"read-only selected-cover replay; excludes omitted unselected pool; no mapping run/CEC count"}));
  }
  std::fs::write(std::env::var("EGM_REPLAY_OUTPUT").unwrap(),serde_json::to_vec_pretty(&rows).unwrap()).unwrap();
  assert!(rows.iter().all(|r|r["result"].get("Ok").is_some()),"at least one actual cover is not replay-qualified; see output");
 }
}
