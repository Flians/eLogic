// Benchmark "/home/flynn/workplace/MIGBalance/results_v2/fixed_all_eqmap_20261012/c880/eqmap_lut_amap/stage" written by ABC on Mon Oct 12 15:01:25 2026

module \/home/flynn/workplace/MIGBalance/results_v2/fixed_all_eqmap_20261012/c880/eqmap_lut_amap/stage  ( 
    G1, G10, G11, G12, G13, G14, G15, G16, G17, G18, G19, G2, G20, G21,
    G22, G23, G24, G25, G26, G27, G28, G29, G3, G30, G31, G32, G33, G34,
    G35, G36, G37, G38, G39, G4, G40, G41, G42, G43, G44, G45, G46, G47,
    G48, G49, G5, G50, G51, G52, G53, G54, G55, G56, G57, G58, G59, G6,
    G60, G7, G8, G9,
    G855, G856, G857, G858, G859, G860, G861, G862, G863, G864, G865, G866,
    G867, G868, G869, G870, G871, G872, G873, G874, G875, G876, G877, G878,
    G879, G880  );
  input  G1, G10, G11, G12, G13, G14, G15, G16, G17, G18, G19, G2, G20,
    G21, G22, G23, G24, G25, G26, G27, G28, G29, G3, G30, G31, G32, G33,
    G34, G35, G36, G37, G38, G39, G4, G40, G41, G42, G43, G44, G45, G46,
    G47, G48, G49, G5, G50, G51, G52, G53, G54, G55, G56, G57, G58, G59,
    G6, G60, G7, G8, G9;
  output G855, G856, G857, G858, G859, G860, G861, G862, G863, G864, G865,
    G866, G867, G868, G869, G870, G871, G872, G873, G874, G875, G876, G877,
    G878, G879, G880;
  wire new_n87_, new_n88_, new_n89_, new_n90_, new_n91_, new_n92_, new_n93_,
    new_n94_, new_n95_, new_n96_, new_n97_, new_n98_, new_n99_, new_n100_,
    new_n101_, new_n102_, new_n103_, new_n104_, new_n105_, new_n106_,
    new_n107_, new_n108_, new_n109_, new_n110_, new_n111_, new_n112_,
    new_n113_, new_n114_, new_n115_, new_n116_, new_n117_, new_n118_,
    new_n119_, new_n120_, new_n121_, new_n122_, new_n123_, new_n124_,
    new_n125_, new_n126_, new_n127_, new_n128_, new_n129_, new_n130_,
    new_n131_, new_n132_, new_n134_, new_n136_, new_n138_, new_n140_,
    new_n141_, new_n143_, new_n144_, new_n149_, new_n151_, new_n152_,
    new_n154_, new_n156_, new_n157_, new_n158_, new_n159_, new_n161_,
    new_n162_, new_n163_, new_n164_, new_n167_, new_n168_, new_n169_,
    new_n170_, new_n171_, new_n172_, new_n173_, new_n174_, new_n175_,
    new_n176_, new_n177_, new_n178_, new_n179_, new_n180_, new_n181_,
    new_n182_, new_n183_, new_n184_, new_n185_, new_n186_, new_n187_,
    new_n188_, new_n189_, new_n190_, new_n192_, new_n193_, new_n194_,
    new_n195_, new_n196_, new_n197_, new_n198_, new_n199_, new_n200_,
    new_n201_, new_n202_, new_n203_, new_n204_, new_n205_, new_n206_,
    new_n207_, new_n208_, new_n209_, new_n210_, new_n211_, new_n212_,
    new_n213_, new_n214_, new_n215_, new_n216_, new_n217_, new_n218_,
    new_n219_, new_n220_, new_n221_, new_n222_, new_n223_, new_n225_,
    new_n226_, new_n227_, new_n228_, new_n229_, new_n230_, new_n231_,
    new_n232_, new_n233_, new_n234_, new_n235_, new_n236_, new_n237_,
    new_n238_, new_n239_, new_n240_, new_n241_, new_n242_, new_n243_,
    new_n244_, new_n245_, new_n246_, new_n247_, new_n248_, new_n249_,
    new_n250_, new_n251_, new_n252_, new_n253_, new_n254_, new_n255_,
    new_n256_, new_n257_, new_n258_, new_n259_, new_n260_, new_n261_,
    new_n262_, new_n263_, new_n264_, new_n265_, new_n266_, new_n267_,
    new_n268_, new_n269_, new_n270_, new_n271_, new_n272_, new_n273_,
    new_n274_, new_n275_, new_n276_, new_n277_, new_n278_, new_n280_,
    new_n281_, new_n282_, new_n283_, new_n284_, new_n285_, new_n286_,
    new_n287_, new_n288_, new_n289_, new_n290_, new_n291_, new_n292_,
    new_n293_, new_n294_, new_n295_, new_n296_, new_n297_, new_n298_,
    new_n299_, new_n300_, new_n301_, new_n302_, new_n303_, new_n304_,
    new_n305_, new_n306_, new_n307_, new_n308_, new_n309_, new_n310_,
    new_n311_, new_n312_, new_n313_, new_n314_, new_n315_, new_n316_,
    new_n317_, new_n318_, new_n319_, new_n320_, new_n321_, new_n322_,
    new_n323_, new_n324_, new_n325_, new_n326_, new_n327_, new_n328_,
    new_n329_, new_n330_, new_n331_, new_n332_, new_n333_, new_n334_,
    new_n335_, new_n336_, new_n337_, new_n338_, new_n339_, new_n340_,
    new_n341_, new_n342_, new_n343_, new_n344_, new_n345_, new_n346_,
    new_n347_, new_n348_, new_n349_, new_n350_, new_n351_, new_n352_,
    new_n353_, new_n355_, new_n356_, new_n357_, new_n358_, new_n359_,
    new_n360_, new_n361_, new_n362_, new_n363_, new_n364_, new_n365_,
    new_n366_, new_n367_, new_n368_, new_n369_, new_n370_, new_n371_,
    new_n372_, new_n373_, new_n374_, new_n375_, new_n376_, new_n377_,
    new_n378_, new_n380_, new_n381_, new_n382_, new_n383_, new_n384_,
    new_n385_, new_n386_, new_n387_, new_n388_, new_n389_, new_n390_,
    new_n391_, new_n392_, new_n393_, new_n394_, new_n395_, new_n396_,
    new_n397_, new_n398_, new_n400_, new_n401_, new_n402_, new_n403_,
    new_n404_, new_n405_, new_n406_, new_n407_, new_n408_, new_n409_,
    new_n410_, new_n411_, new_n412_, new_n413_, new_n414_, new_n415_,
    new_n416_, new_n417_, new_n418_, new_n419_, new_n420_, new_n421_,
    new_n422_, new_n423_, new_n424_, new_n425_, new_n426_, new_n427_,
    new_n428_, new_n429_, new_n430_, new_n431_, new_n432_, new_n433_,
    new_n434_, new_n435_, new_n436_, new_n437_, new_n438_, new_n439_,
    new_n440_, new_n441_, new_n442_, new_n443_, new_n444_, new_n445_,
    new_n446_, new_n447_, new_n448_, new_n449_, new_n450_, new_n451_,
    new_n452_, new_n453_, new_n454_, new_n455_, new_n456_, new_n457_,
    new_n458_, new_n459_, new_n460_, new_n461_, new_n462_, new_n463_,
    new_n464_, new_n465_, new_n466_, new_n467_, new_n468_, new_n469_,
    new_n470_, new_n471_, new_n472_, new_n473_, new_n474_, new_n475_,
    new_n476_, new_n477_, new_n478_, new_n479_, new_n480_, new_n481_,
    new_n482_, new_n483_, new_n484_, new_n485_, new_n486_, new_n487_,
    new_n488_, new_n489_, new_n490_, new_n491_, new_n493_, new_n494_,
    new_n495_, new_n496_, new_n497_, new_n498_, new_n499_, new_n500_,
    new_n501_, new_n502_, new_n503_, new_n504_, new_n505_, new_n506_,
    new_n507_, new_n508_, new_n509_, new_n510_, new_n511_, new_n512_,
    new_n513_, new_n515_, new_n516_, new_n517_, new_n518_, new_n519_,
    new_n520_, new_n521_, new_n522_, new_n523_, new_n524_, new_n525_,
    new_n526_, new_n527_, new_n528_, new_n529_, new_n530_, new_n531_,
    new_n532_, new_n533_, new_n534_, new_n535_, new_n536_, new_n537_,
    new_n538_, new_n539_, new_n540_, new_n541_, new_n542_, new_n543_,
    new_n544_, new_n545_, new_n546_, new_n547_, new_n548_, new_n549_,
    new_n551_, new_n552_, new_n553_, new_n554_, new_n555_, new_n556_,
    new_n557_, new_n558_, new_n559_, new_n560_, new_n561_, new_n562_,
    new_n563_, new_n564_, new_n565_, new_n566_, new_n567_, new_n568_,
    new_n569_, new_n570_, new_n571_, new_n572_, new_n573_, new_n574_,
    new_n575_, new_n576_, new_n578_, new_n579_, new_n580_, new_n581_,
    new_n582_, new_n583_, new_n584_, new_n585_, new_n586_, new_n587_,
    new_n588_, new_n589_, new_n590_, new_n591_, new_n592_, new_n593_,
    new_n594_, new_n595_, new_n596_, new_n597_, new_n598_, new_n599_;
  INVx1_ASAP7_75t_R   g000(.A(G1), .Y(new_n87_));
  INVx1_ASAP7_75t_R   g001(.A(G10), .Y(new_n88_));
  INVx1_ASAP7_75t_R   g002(.A(G11), .Y(new_n89_));
  INVx1_ASAP7_75t_R   g003(.A(G12), .Y(new_n90_));
  INVx1_ASAP7_75t_R   g004(.A(G16), .Y(new_n91_));
  INVx1_ASAP7_75t_R   g005(.A(G17), .Y(new_n92_));
  INVx1_ASAP7_75t_R   g006(.A(G18), .Y(new_n93_));
  INVx1_ASAP7_75t_R   g007(.A(G2), .Y(new_n94_));
  INVx1_ASAP7_75t_R   g008(.A(G22), .Y(new_n95_));
  INVx1_ASAP7_75t_R   g009(.A(G23), .Y(new_n96_));
  INVx1_ASAP7_75t_R   g010(.A(G24), .Y(new_n97_));
  INVx1_ASAP7_75t_R   g011(.A(G25), .Y(new_n98_));
  INVx1_ASAP7_75t_R   g012(.A(G26), .Y(new_n99_));
  INVx1_ASAP7_75t_R   g013(.A(G27), .Y(new_n100_));
  INVx1_ASAP7_75t_R   g014(.A(G28), .Y(new_n101_));
  INVx1_ASAP7_75t_R   g015(.A(G29), .Y(new_n102_));
  INVx1_ASAP7_75t_R   g016(.A(G3), .Y(new_n103_));
  INVx1_ASAP7_75t_R   g017(.A(G30), .Y(new_n104_));
  INVx1_ASAP7_75t_R   g018(.A(G31), .Y(new_n105_));
  INVx1_ASAP7_75t_R   g019(.A(G34), .Y(new_n106_));
  INVx1_ASAP7_75t_R   g020(.A(G35), .Y(new_n107_));
  INVx1_ASAP7_75t_R   g021(.A(G37), .Y(new_n108_));
  INVx1_ASAP7_75t_R   g022(.A(G39), .Y(new_n109_));
  INVx1_ASAP7_75t_R   g023(.A(G4), .Y(new_n110_));
  INVx1_ASAP7_75t_R   g024(.A(G40), .Y(new_n111_));
  INVx1_ASAP7_75t_R   g025(.A(G41), .Y(new_n112_));
  INVx1_ASAP7_75t_R   g026(.A(G42), .Y(new_n113_));
  INVx1_ASAP7_75t_R   g027(.A(G43), .Y(new_n114_));
  INVx1_ASAP7_75t_R   g028(.A(G44), .Y(new_n115_));
  INVx1_ASAP7_75t_R   g029(.A(G45), .Y(new_n116_));
  INVx1_ASAP7_75t_R   g030(.A(G46), .Y(new_n117_));
  INVx1_ASAP7_75t_R   g031(.A(G47), .Y(new_n118_));
  INVx1_ASAP7_75t_R   g032(.A(G48), .Y(new_n119_));
  INVx1_ASAP7_75t_R   g033(.A(G5), .Y(new_n120_));
  INVx1_ASAP7_75t_R   g034(.A(G50), .Y(new_n121_));
  INVx1_ASAP7_75t_R   g035(.A(G51), .Y(new_n122_));
  INVx1_ASAP7_75t_R   g036(.A(G52), .Y(new_n123_));
  INVx1_ASAP7_75t_R   g037(.A(G54), .Y(new_n124_));
  INVx1_ASAP7_75t_R   g038(.A(G55), .Y(new_n125_));
  INVx1_ASAP7_75t_R   g039(.A(G57), .Y(new_n126_));
  INVx1_ASAP7_75t_R   g040(.A(G58), .Y(new_n127_));
  INVx1_ASAP7_75t_R   g041(.A(G6), .Y(new_n128_));
  INVx1_ASAP7_75t_R   g042(.A(G7), .Y(new_n129_));
  INVx1_ASAP7_75t_R   g043(.A(G8), .Y(new_n130_));
  INVx1_ASAP7_75t_R   g044(.A(G9), .Y(new_n131_));
  AO21x1_ASAP7_75t_R  g045(.A1(G16), .A2(new_n128_), .B(new_n91_), .Y(new_n132_));
  AO21x1_ASAP7_75t_R  g046(.A1(G8), .A2(new_n132_), .B(new_n130_), .Y(G855));
  AO21x1_ASAP7_75t_R  g047(.A1(G17), .A2(new_n129_), .B(new_n92_), .Y(new_n134_));
  AO21x1_ASAP7_75t_R  g048(.A1(G6), .A2(new_n134_), .B(new_n128_), .Y(G856));
  AO21x1_ASAP7_75t_R  g049(.A1(G6), .A2(new_n129_), .B(new_n128_), .Y(new_n136_));
  AO21x1_ASAP7_75t_R  g050(.A1(G8), .A2(new_n136_), .B(new_n130_), .Y(G857));
  INVx1_ASAP7_75t_R   g051(.A(G857), .Y(new_n138_));
  OAI21x1_ASAP7_75t_R g052(.A1(new_n93_), .A2(G19), .B(G18), .Y(G858));
  AO21x1_ASAP7_75t_R  g053(.A1(G1), .A2(new_n110_), .B(new_n87_), .Y(new_n140_));
  AO21x1_ASAP7_75t_R  g054(.A1(G2), .A2(new_n140_), .B(new_n94_), .Y(new_n141_));
  AO21x1_ASAP7_75t_R  g055(.A1(G3), .A2(new_n141_), .B(new_n103_), .Y(G859));
  OR3x1_ASAP7_75t_R   g056(.A(new_n110_), .B(new_n138_), .C(new_n120_), .Y(new_n143_));
  OR3x1_ASAP7_75t_R   g057(.A(new_n87_), .B(new_n143_), .C(new_n103_), .Y(new_n144_));
  INVx1_ASAP7_75t_R   g058(.A(new_n144_), .Y(G860));
  AND3x1_ASAP7_75t_R  g059(.A(G16), .B(G17), .C(G11), .Y(G861));
  AND3x1_ASAP7_75t_R  g060(.A(G17), .B(G7), .C(G11), .Y(G862));
  AND3x1_ASAP7_75t_R  g061(.A(G11), .B(G7), .C(G8), .Y(G863));
  NOR2x1_ASAP7_75t_R  g062(.A(G20), .B(G21), .Y(new_n149_));
  AO21x1_ASAP7_75t_R  g063(.A1(G23), .A2(new_n149_), .B(new_n96_), .Y(G864));
  OR3x1_ASAP7_75t_R   g064(.A(new_n110_), .B(new_n120_), .C(new_n87_), .Y(new_n151_));
  OR3x1_ASAP7_75t_R   g065(.A(new_n103_), .B(new_n151_), .C(G857), .Y(new_n152_));
  INVx1_ASAP7_75t_R   g066(.A(new_n152_), .Y(G865));
  AO21x1_ASAP7_75t_R  g067(.A1(G5), .A2(new_n131_), .B(new_n120_), .Y(new_n154_));
  AO21x1_ASAP7_75t_R  g068(.A1(G1), .A2(new_n154_), .B(new_n87_), .Y(G866));
  AO21x1_ASAP7_75t_R  g069(.A1(G1), .A2(new_n128_), .B(new_n87_), .Y(new_n156_));
  AO21x1_ASAP7_75t_R  g070(.A1(G10), .A2(new_n156_), .B(new_n88_), .Y(new_n157_));
  AO21x1_ASAP7_75t_R  g071(.A1(G2), .A2(new_n157_), .B(new_n94_), .Y(new_n158_));
  AO21x1_ASAP7_75t_R  g072(.A1(G3), .A2(new_n158_), .B(new_n103_), .Y(new_n159_));
  AO21x1_ASAP7_75t_R  g073(.A1(G12), .A2(new_n159_), .B(new_n90_), .Y(G867));
  OR3x1_ASAP7_75t_R   g074(.A(new_n87_), .B(new_n89_), .C(new_n88_), .Y(new_n161_));
  NOR2x1_ASAP7_75t_R  g075(.A(new_n94_), .B(new_n161_), .Y(new_n162_));
  AND3x1_ASAP7_75t_R  g076(.A(G3), .B(new_n162_), .C(G12), .Y(new_n163_));
  INVx1_ASAP7_75t_R   g077(.A(new_n163_), .Y(new_n164_));
  OAI21x1_ASAP7_75t_R g078(.A1(G15), .A2(new_n164_), .B(new_n163_), .Y(G868));
  AO21x1_ASAP7_75t_R  g079(.A1(G22), .A2(new_n149_), .B(new_n95_), .Y(G869));
  XNOR2x2_ASAP7_75t_R g080(.A(G30), .B(new_n105_), .Y(new_n167_));
  XOR2x2_ASAP7_75t_R  g081(.A(new_n104_), .B(new_n105_), .Y(new_n168_));
  NOR2x1_ASAP7_75t_R  g082(.A(G27), .B(new_n168_), .Y(new_n169_));
  AO21x1_ASAP7_75t_R  g083(.A1(G27), .A2(new_n167_), .B(new_n169_), .Y(new_n170_));
  NOR2x1_ASAP7_75t_R  g084(.A(new_n100_), .B(new_n168_), .Y(new_n171_));
  AO21x1_ASAP7_75t_R  g085(.A1(new_n100_), .A2(new_n167_), .B(new_n171_), .Y(new_n172_));
  AND2x2_ASAP7_75t_R  g086(.A(new_n99_), .B(new_n172_), .Y(new_n173_));
  AO21x1_ASAP7_75t_R  g087(.A1(G26), .A2(new_n170_), .B(new_n173_), .Y(new_n174_));
  XOR2x2_ASAP7_75t_R  g088(.A(G33), .B(new_n174_), .Y(new_n175_));
  XOR2x2_ASAP7_75t_R  g089(.A(G33), .B(new_n174_), .Y(new_n176_));
  NOR2x1_ASAP7_75t_R  g090(.A(G29), .B(new_n176_), .Y(new_n177_));
  AO21x1_ASAP7_75t_R  g091(.A1(G29), .A2(new_n175_), .B(new_n177_), .Y(new_n178_));
  NOR2x1_ASAP7_75t_R  g092(.A(new_n102_), .B(new_n176_), .Y(new_n179_));
  AO21x1_ASAP7_75t_R  g093(.A1(new_n102_), .A2(new_n175_), .B(new_n179_), .Y(new_n180_));
  AND2x2_ASAP7_75t_R  g094(.A(new_n101_), .B(new_n180_), .Y(new_n181_));
  AO21x1_ASAP7_75t_R  g095(.A1(G28), .A2(new_n178_), .B(new_n181_), .Y(new_n182_));
  XOR2x2_ASAP7_75t_R  g096(.A(G24), .B(new_n182_), .Y(new_n183_));
  NOR2x1_ASAP7_75t_R  g097(.A(new_n98_), .B(new_n183_), .Y(new_n184_));
  XNOR2x2_ASAP7_75t_R g098(.A(new_n97_), .B(new_n182_), .Y(new_n185_));
  AO21x1_ASAP7_75t_R  g099(.A1(new_n98_), .A2(new_n185_), .B(new_n184_), .Y(new_n186_));
  NAND2x1_ASAP7_75t_R g100(.A(G32), .B(new_n186_), .Y(new_n187_));
  NAND2x1_ASAP7_75t_R g101(.A(G25), .B(new_n185_), .Y(new_n188_));
  OA21x2_ASAP7_75t_R  g102(.A1(G25), .A2(new_n183_), .B(new_n188_), .Y(new_n189_));
  OR2x4_ASAP7_75t_R   g103(.A(G32), .B(new_n189_), .Y(new_n190_));
  NAND2x1_ASAP7_75t_R g104(.A(new_n187_), .B(new_n190_), .Y(G870));
  XOR2x2_ASAP7_75t_R  g105(.A(new_n118_), .B(new_n119_), .Y(new_n192_));
  NOR2x1_ASAP7_75t_R  g106(.A(new_n117_), .B(new_n192_), .Y(new_n193_));
  XNOR2x2_ASAP7_75t_R g107(.A(new_n118_), .B(G48), .Y(new_n194_));
  AO21x1_ASAP7_75t_R  g108(.A1(new_n117_), .A2(new_n194_), .B(new_n193_), .Y(new_n195_));
  INVx1_ASAP7_75t_R   g109(.A(new_n195_), .Y(new_n196_));
  NOR2x1_ASAP7_75t_R  g110(.A(G46), .B(new_n192_), .Y(new_n197_));
  AO21x1_ASAP7_75t_R  g111(.A1(G46), .A2(new_n194_), .B(new_n197_), .Y(new_n198_));
  INVx1_ASAP7_75t_R   g112(.A(new_n198_), .Y(new_n199_));
  NOR2x1_ASAP7_75t_R  g113(.A(G49), .B(new_n199_), .Y(new_n200_));
  AO21x1_ASAP7_75t_R  g114(.A1(G49), .A2(new_n195_), .B(new_n200_), .Y(new_n201_));
  NOR2x1_ASAP7_75t_R  g115(.A(G49), .B(new_n196_), .Y(new_n202_));
  AO21x1_ASAP7_75t_R  g116(.A1(G49), .A2(new_n198_), .B(new_n202_), .Y(new_n203_));
  AND2x2_ASAP7_75t_R  g117(.A(new_n114_), .B(new_n203_), .Y(new_n204_));
  AO21x1_ASAP7_75t_R  g118(.A1(G43), .A2(new_n201_), .B(new_n204_), .Y(new_n205_));
  AND2x2_ASAP7_75t_R  g119(.A(new_n114_), .B(new_n201_), .Y(new_n206_));
  AOI21x1_ASAP7_75t_R g120(.A1(G43), .A2(new_n203_), .B(new_n206_), .Y(new_n207_));
  NOR2x1_ASAP7_75t_R  g121(.A(G44), .B(new_n207_), .Y(new_n208_));
  AO21x1_ASAP7_75t_R  g122(.A1(G44), .A2(new_n205_), .B(new_n208_), .Y(new_n209_));
  XOR2x2_ASAP7_75t_R  g123(.A(G41), .B(new_n209_), .Y(new_n210_));
  NOR2x1_ASAP7_75t_R  g124(.A(new_n113_), .B(new_n210_), .Y(new_n211_));
  XNOR2x2_ASAP7_75t_R g125(.A(new_n112_), .B(new_n209_), .Y(new_n212_));
  AO21x1_ASAP7_75t_R  g126(.A1(new_n113_), .A2(new_n212_), .B(new_n211_), .Y(new_n213_));
  INVx1_ASAP7_75t_R   g127(.A(new_n213_), .Y(new_n214_));
  NOR2x1_ASAP7_75t_R  g128(.A(G42), .B(new_n210_), .Y(new_n215_));
  AO21x1_ASAP7_75t_R  g129(.A1(G42), .A2(new_n212_), .B(new_n215_), .Y(new_n216_));
  INVx1_ASAP7_75t_R   g130(.A(new_n216_), .Y(new_n217_));
  NOR2x1_ASAP7_75t_R  g131(.A(G32), .B(new_n217_), .Y(new_n218_));
  AO21x1_ASAP7_75t_R  g132(.A1(G32), .A2(new_n213_), .B(new_n218_), .Y(new_n219_));
  NAND2x1_ASAP7_75t_R g133(.A(G45), .B(new_n219_), .Y(new_n220_));
  NAND2x1_ASAP7_75t_R g134(.A(G32), .B(new_n216_), .Y(new_n221_));
  OA21x2_ASAP7_75t_R  g135(.A1(G32), .A2(new_n214_), .B(new_n221_), .Y(new_n222_));
  OR2x4_ASAP7_75t_R   g136(.A(G45), .B(new_n222_), .Y(new_n223_));
  NAND2x1_ASAP7_75t_R g137(.A(new_n220_), .B(new_n223_), .Y(G871));
  OAI21x1_ASAP7_75t_R g138(.A1(new_n125_), .A2(G59), .B(G55), .Y(new_n225_));
  AND3x1_ASAP7_75t_R  g139(.A(new_n104_), .B(new_n225_), .C(G50), .Y(new_n226_));
  AOI21x1_ASAP7_75t_R g140(.A1(new_n121_), .A2(new_n225_), .B(new_n226_), .Y(new_n227_));
  OR3x1_ASAP7_75t_R   g141(.A(G60), .B(G866), .C(new_n92_), .Y(new_n228_));
  OR3x1_ASAP7_75t_R   g142(.A(new_n128_), .B(new_n228_), .C(new_n91_), .Y(new_n229_));
  NOR2x1_ASAP7_75t_R  g143(.A(new_n88_), .B(new_n229_), .Y(new_n230_));
  INVx1_ASAP7_75t_R   g144(.A(new_n230_), .Y(new_n231_));
  AO21x1_ASAP7_75t_R  g145(.A1(G11), .A2(new_n111_), .B(new_n89_), .Y(new_n232_));
  NAND2x1_ASAP7_75t_R g146(.A(G1), .B(new_n232_), .Y(new_n233_));
  AOI21x1_ASAP7_75t_R g147(.A1(G1), .A2(new_n233_), .B(G866), .Y(new_n234_));
  AO21x1_ASAP7_75t_R  g148(.A1(new_n87_), .A2(G866), .B(new_n234_), .Y(new_n235_));
  NAND2x1_ASAP7_75t_R g149(.A(G4), .B(new_n235_), .Y(new_n236_));
  OA21x2_ASAP7_75t_R  g150(.A1(G1), .A2(G4), .B(new_n236_), .Y(new_n237_));
  NOR2x1_ASAP7_75t_R  g151(.A(new_n109_), .B(new_n237_), .Y(new_n238_));
  XOR2x2_ASAP7_75t_R  g152(.A(G4), .B(new_n130_), .Y(new_n239_));
  OR3x1_ASAP7_75t_R   g153(.A(new_n111_), .B(new_n239_), .C(new_n89_), .Y(new_n240_));
  AO21x1_ASAP7_75t_R  g154(.A1(G11), .A2(new_n91_), .B(new_n89_), .Y(new_n241_));
  AOI21x1_ASAP7_75t_R g155(.A1(G8), .A2(new_n241_), .B(new_n130_), .Y(new_n242_));
  OR3x1_ASAP7_75t_R   g156(.A(new_n110_), .B(new_n242_), .C(new_n131_), .Y(new_n243_));
  AND3x1_ASAP7_75t_R  g157(.A(new_n240_), .B(new_n243_), .C(G9), .Y(new_n244_));
  AO21x1_ASAP7_75t_R  g158(.A1(new_n131_), .A2(new_n243_), .B(new_n244_), .Y(new_n245_));
  AND2x2_ASAP7_75t_R  g159(.A(new_n120_), .B(new_n243_), .Y(new_n246_));
  AO21x1_ASAP7_75t_R  g160(.A1(G5), .A2(new_n245_), .B(new_n246_), .Y(new_n247_));
  AO21x1_ASAP7_75t_R  g161(.A1(G1), .A2(new_n247_), .B(new_n87_), .Y(new_n248_));
  NAND2x1_ASAP7_75t_R g162(.A(G9), .B(new_n240_), .Y(new_n249_));
  AO21x1_ASAP7_75t_R  g163(.A1(G9), .A2(new_n249_), .B(new_n120_), .Y(new_n250_));
  AO21x1_ASAP7_75t_R  g164(.A1(G5), .A2(new_n250_), .B(new_n87_), .Y(new_n251_));
  AOI21x1_ASAP7_75t_R g165(.A1(G1), .A2(new_n251_), .B(G2), .Y(new_n252_));
  AO21x1_ASAP7_75t_R  g166(.A1(G2), .A2(new_n248_), .B(new_n252_), .Y(new_n253_));
  INVx1_ASAP7_75t_R   g167(.A(new_n253_), .Y(new_n254_));
  OA21x2_ASAP7_75t_R  g168(.A1(G31), .A2(new_n253_), .B(new_n254_), .Y(new_n255_));
  OR3x1_ASAP7_75t_R   g169(.A(new_n238_), .B(new_n255_), .C(new_n230_), .Y(new_n256_));
  INVx1_ASAP7_75t_R   g170(.A(new_n256_), .Y(new_n257_));
  AND2x2_ASAP7_75t_R  g171(.A(G13), .B(new_n163_), .Y(new_n258_));
  AND3x1_ASAP7_75t_R  g172(.A(G8), .B(new_n258_), .C(G14), .Y(new_n259_));
  INVx1_ASAP7_75t_R   g173(.A(new_n259_), .Y(new_n260_));
  OR3x1_ASAP7_75t_R   g174(.A(G52), .B(new_n259_), .C(new_n256_), .Y(new_n261_));
  OR3x1_ASAP7_75t_R   g175(.A(G53), .B(new_n259_), .C(new_n257_), .Y(new_n262_));
  AOI21x1_ASAP7_75t_R g176(.A1(new_n261_), .A2(new_n262_), .B(new_n119_), .Y(new_n263_));
  AO21x1_ASAP7_75t_R  g177(.A1(new_n123_), .A2(new_n256_), .B(new_n257_), .Y(new_n264_));
  AOI21x1_ASAP7_75t_R g178(.A1(new_n119_), .A2(new_n264_), .B(new_n263_), .Y(new_n265_));
  AO21x1_ASAP7_75t_R  g179(.A1(new_n122_), .A2(new_n127_), .B(G58), .Y(new_n266_));
  AO21x1_ASAP7_75t_R  g180(.A1(new_n122_), .A2(G58), .B(new_n127_), .Y(new_n267_));
  AND2x2_ASAP7_75t_R  g181(.A(new_n119_), .B(new_n267_), .Y(new_n268_));
  AO21x1_ASAP7_75t_R  g182(.A1(G48), .A2(new_n266_), .B(new_n268_), .Y(new_n269_));
  NAND2x1_ASAP7_75t_R g183(.A(new_n257_), .B(new_n269_), .Y(new_n270_));
  AND3x1_ASAP7_75t_R  g184(.A(new_n122_), .B(new_n124_), .C(G58), .Y(new_n271_));
  AO21x1_ASAP7_75t_R  g185(.A1(new_n124_), .A2(new_n127_), .B(new_n271_), .Y(new_n272_));
  AND3x1_ASAP7_75t_R  g186(.A(new_n122_), .B(new_n124_), .C(new_n127_), .Y(new_n273_));
  AO21x1_ASAP7_75t_R  g187(.A1(new_n124_), .A2(G58), .B(new_n273_), .Y(new_n274_));
  AND2x2_ASAP7_75t_R  g188(.A(new_n119_), .B(new_n274_), .Y(new_n275_));
  AOI21x1_ASAP7_75t_R g189(.A1(G48), .A2(new_n272_), .B(new_n275_), .Y(new_n276_));
  OA21x2_ASAP7_75t_R  g190(.A1(new_n257_), .A2(new_n276_), .B(new_n270_), .Y(new_n277_));
  OR3x1_ASAP7_75t_R   g191(.A(new_n227_), .B(new_n265_), .C(new_n277_), .Y(new_n278_));
  INVx1_ASAP7_75t_R   g192(.A(new_n278_), .Y(G872));
  AO21x1_ASAP7_75t_R  g193(.A1(new_n110_), .A2(new_n111_), .B(G40), .Y(new_n280_));
  NAND2x1_ASAP7_75t_R g194(.A(G9), .B(new_n280_), .Y(new_n281_));
  AO21x1_ASAP7_75t_R  g195(.A1(G9), .A2(new_n281_), .B(new_n120_), .Y(new_n282_));
  AO21x1_ASAP7_75t_R  g196(.A1(G5), .A2(new_n282_), .B(new_n89_), .Y(new_n283_));
  AO21x1_ASAP7_75t_R  g197(.A1(new_n110_), .A2(G9), .B(new_n131_), .Y(new_n284_));
  AOI21x1_ASAP7_75t_R g198(.A1(G5), .A2(new_n284_), .B(new_n120_), .Y(new_n285_));
  OA21x2_ASAP7_75t_R  g199(.A1(G11), .A2(new_n285_), .B(new_n283_), .Y(new_n286_));
  NOR2x1_ASAP7_75t_R  g200(.A(new_n87_), .B(new_n286_), .Y(new_n287_));
  INVx1_ASAP7_75t_R   g201(.A(new_n287_), .Y(new_n288_));
  NOR2x1_ASAP7_75t_R  g202(.A(new_n254_), .B(new_n288_), .Y(new_n289_));
  NOR2x1_ASAP7_75t_R  g203(.A(G28), .B(new_n288_), .Y(new_n290_));
  AO21x1_ASAP7_75t_R  g204(.A1(G28), .A2(new_n289_), .B(new_n290_), .Y(new_n291_));
  NAND2x1_ASAP7_75t_R g205(.A(G35), .B(new_n291_), .Y(new_n292_));
  OA21x2_ASAP7_75t_R  g206(.A1(new_n101_), .A2(new_n254_), .B(G28), .Y(new_n293_));
  OA21x2_ASAP7_75t_R  g207(.A1(G35), .A2(new_n293_), .B(new_n292_), .Y(new_n294_));
  NOR2x1_ASAP7_75t_R  g208(.A(new_n230_), .B(new_n294_), .Y(new_n295_));
  INVx1_ASAP7_75t_R   g209(.A(new_n295_), .Y(new_n296_));
  NOR2x1_ASAP7_75t_R  g210(.A(G45), .B(new_n296_), .Y(new_n297_));
  NOR2x1_ASAP7_75t_R  g211(.A(new_n259_), .B(new_n296_), .Y(new_n298_));
  AO21x1_ASAP7_75t_R  g212(.A1(new_n259_), .A2(new_n297_), .B(new_n298_), .Y(new_n299_));
  NAND2x1_ASAP7_75t_R g213(.A(G54), .B(new_n299_), .Y(new_n300_));
  NAND2x1_ASAP7_75t_R g214(.A(new_n116_), .B(new_n259_), .Y(new_n301_));
  OAI21x1_ASAP7_75t_R g215(.A1(G53), .A2(new_n295_), .B(new_n296_), .Y(new_n302_));
  AOI21x1_ASAP7_75t_R g216(.A1(G45), .A2(new_n302_), .B(new_n116_), .Y(new_n303_));
  OA21x2_ASAP7_75t_R  g217(.A1(new_n259_), .A2(new_n303_), .B(new_n301_), .Y(new_n304_));
  OA21x2_ASAP7_75t_R  g218(.A1(G54), .A2(new_n304_), .B(new_n300_), .Y(new_n305_));
  AO21x1_ASAP7_75t_R  g219(.A1(G27), .A2(G50), .B(new_n305_), .Y(new_n306_));
  AO21x1_ASAP7_75t_R  g220(.A1(new_n119_), .A2(G58), .B(G48), .Y(new_n307_));
  NAND2x1_ASAP7_75t_R g221(.A(G31), .B(new_n254_), .Y(new_n308_));
  OR3x1_ASAP7_75t_R   g222(.A(new_n105_), .B(new_n253_), .C(G58), .Y(new_n309_));
  AO21x1_ASAP7_75t_R  g223(.A1(new_n127_), .A2(new_n309_), .B(new_n119_), .Y(new_n310_));
  OR3x1_ASAP7_75t_R   g224(.A(new_n127_), .B(new_n308_), .C(G48), .Y(new_n311_));
  AOI21x1_ASAP7_75t_R g225(.A1(new_n310_), .A2(new_n311_), .B(new_n238_), .Y(new_n312_));
  AOI21x1_ASAP7_75t_R g226(.A1(new_n238_), .A2(new_n307_), .B(new_n312_), .Y(new_n313_));
  NOR2x1_ASAP7_75t_R  g227(.A(new_n230_), .B(new_n313_), .Y(new_n314_));
  AO21x1_ASAP7_75t_R  g228(.A1(new_n230_), .A2(new_n307_), .B(new_n314_), .Y(new_n315_));
  INVx1_ASAP7_75t_R   g229(.A(new_n315_), .Y(new_n316_));
  NOR2x1_ASAP7_75t_R  g230(.A(G30), .B(new_n288_), .Y(new_n317_));
  AO21x1_ASAP7_75t_R  g231(.A1(G30), .A2(new_n289_), .B(new_n317_), .Y(new_n318_));
  NAND2x1_ASAP7_75t_R g232(.A(G37), .B(new_n318_), .Y(new_n319_));
  OA21x2_ASAP7_75t_R  g233(.A1(new_n104_), .A2(new_n254_), .B(G30), .Y(new_n320_));
  OA21x2_ASAP7_75t_R  g234(.A1(G37), .A2(new_n320_), .B(new_n319_), .Y(new_n321_));
  NOR2x1_ASAP7_75t_R  g235(.A(new_n230_), .B(new_n321_), .Y(new_n322_));
  INVx1_ASAP7_75t_R   g236(.A(new_n322_), .Y(new_n323_));
  NOR2x1_ASAP7_75t_R  g237(.A(G29), .B(new_n288_), .Y(new_n324_));
  AO21x1_ASAP7_75t_R  g238(.A1(G29), .A2(new_n289_), .B(new_n324_), .Y(new_n325_));
  NAND2x1_ASAP7_75t_R g239(.A(G36), .B(new_n325_), .Y(new_n326_));
  OA21x2_ASAP7_75t_R  g240(.A1(new_n102_), .A2(new_n254_), .B(G29), .Y(new_n327_));
  OA21x2_ASAP7_75t_R  g241(.A1(G36), .A2(new_n327_), .B(new_n326_), .Y(new_n328_));
  NOR2x1_ASAP7_75t_R  g242(.A(new_n230_), .B(new_n328_), .Y(new_n329_));
  INVx1_ASAP7_75t_R   g243(.A(new_n329_), .Y(new_n330_));
  NOR2x1_ASAP7_75t_R  g244(.A(new_n323_), .B(new_n330_), .Y(new_n331_));
  AND3x1_ASAP7_75t_R  g245(.A(new_n316_), .B(new_n331_), .C(G47), .Y(new_n332_));
  NOR2x1_ASAP7_75t_R  g246(.A(new_n315_), .B(new_n330_), .Y(new_n333_));
  AO21x1_ASAP7_75t_R  g247(.A1(new_n315_), .A2(new_n331_), .B(new_n333_), .Y(new_n334_));
  AO21x1_ASAP7_75t_R  g248(.A1(new_n118_), .A2(new_n334_), .B(new_n332_), .Y(new_n335_));
  AO21x1_ASAP7_75t_R  g249(.A1(new_n323_), .A2(new_n329_), .B(new_n322_), .Y(new_n336_));
  AND2x2_ASAP7_75t_R  g250(.A(new_n316_), .B(new_n336_), .Y(new_n337_));
  AO21x1_ASAP7_75t_R  g251(.A1(new_n315_), .A2(new_n329_), .B(new_n337_), .Y(new_n338_));
  NAND2x1_ASAP7_75t_R g252(.A(G47), .B(new_n338_), .Y(new_n339_));
  AOI21x1_ASAP7_75t_R g253(.A1(new_n315_), .A2(new_n336_), .B(new_n316_), .Y(new_n340_));
  OA21x2_ASAP7_75t_R  g254(.A1(G47), .A2(new_n340_), .B(new_n339_), .Y(new_n341_));
  NOR2x1_ASAP7_75t_R  g255(.A(G46), .B(new_n341_), .Y(new_n342_));
  AO21x1_ASAP7_75t_R  g256(.A1(G46), .A2(new_n335_), .B(new_n342_), .Y(new_n343_));
  INVx1_ASAP7_75t_R   g257(.A(new_n343_), .Y(new_n344_));
  AND3x1_ASAP7_75t_R  g258(.A(new_n122_), .B(new_n123_), .C(new_n343_), .Y(new_n345_));
  AO21x1_ASAP7_75t_R  g259(.A1(new_n123_), .A2(new_n344_), .B(new_n345_), .Y(new_n346_));
  AO21x1_ASAP7_75t_R  g260(.A1(new_n122_), .A2(new_n344_), .B(new_n343_), .Y(new_n347_));
  AND2x2_ASAP7_75t_R  g261(.A(new_n296_), .B(new_n347_), .Y(new_n348_));
  AO21x1_ASAP7_75t_R  g262(.A1(new_n295_), .A2(new_n346_), .B(new_n348_), .Y(new_n349_));
  NAND2x1_ASAP7_75t_R g263(.A(G45), .B(new_n349_), .Y(new_n350_));
  AND2x2_ASAP7_75t_R  g264(.A(new_n296_), .B(new_n346_), .Y(new_n351_));
  AOI21x1_ASAP7_75t_R g265(.A1(new_n295_), .A2(new_n347_), .B(new_n351_), .Y(new_n352_));
  OA21x2_ASAP7_75t_R  g266(.A1(G45), .A2(new_n352_), .B(new_n350_), .Y(new_n353_));
  NOR2x1_ASAP7_75t_R  g267(.A(new_n306_), .B(new_n353_), .Y(G873));
  OR3x1_ASAP7_75t_R   g268(.A(G52), .B(new_n259_), .C(new_n330_), .Y(new_n355_));
  OR2x4_ASAP7_75t_R   g269(.A(G53), .B(G54), .Y(new_n356_));
  OR3x1_ASAP7_75t_R   g270(.A(new_n259_), .B(new_n356_), .C(new_n329_), .Y(new_n357_));
  AO21x1_ASAP7_75t_R  g271(.A1(new_n355_), .A2(new_n357_), .B(new_n117_), .Y(new_n358_));
  OR3x1_ASAP7_75t_R   g272(.A(G52), .B(G54), .C(new_n329_), .Y(new_n359_));
  AO21x1_ASAP7_75t_R  g273(.A1(new_n330_), .A2(new_n359_), .B(G46), .Y(new_n360_));
  AND3x1_ASAP7_75t_R  g274(.A(new_n316_), .B(new_n322_), .C(G47), .Y(new_n361_));
  AO21x1_ASAP7_75t_R  g275(.A1(new_n315_), .A2(new_n322_), .B(new_n316_), .Y(new_n362_));
  AO21x1_ASAP7_75t_R  g276(.A1(new_n118_), .A2(new_n362_), .B(new_n361_), .Y(new_n363_));
  AO21x1_ASAP7_75t_R  g277(.A1(new_n316_), .A2(new_n323_), .B(new_n315_), .Y(new_n364_));
  AND3x1_ASAP7_75t_R  g278(.A(new_n315_), .B(new_n323_), .C(new_n118_), .Y(new_n365_));
  AO21x1_ASAP7_75t_R  g279(.A1(G47), .A2(new_n364_), .B(new_n365_), .Y(new_n366_));
  AND2x2_ASAP7_75t_R  g280(.A(new_n330_), .B(new_n366_), .Y(new_n367_));
  AO21x1_ASAP7_75t_R  g281(.A1(new_n329_), .A2(new_n363_), .B(new_n367_), .Y(new_n368_));
  AND2x2_ASAP7_75t_R  g282(.A(new_n330_), .B(new_n363_), .Y(new_n369_));
  AOI21x1_ASAP7_75t_R g283(.A1(new_n329_), .A2(new_n366_), .B(new_n369_), .Y(new_n370_));
  NOR2x1_ASAP7_75t_R  g284(.A(G46), .B(new_n370_), .Y(new_n371_));
  AO21x1_ASAP7_75t_R  g285(.A1(G46), .A2(new_n368_), .B(new_n371_), .Y(new_n372_));
  OR3x1_ASAP7_75t_R   g286(.A(G28), .B(G56), .C(new_n125_), .Y(new_n373_));
  OAI21x1_ASAP7_75t_R g287(.A1(G28), .A2(G55), .B(new_n373_), .Y(new_n374_));
  NAND2x1_ASAP7_75t_R g288(.A(G50), .B(new_n374_), .Y(new_n375_));
  OA21x2_ASAP7_75t_R  g289(.A1(new_n125_), .A2(G56), .B(G55), .Y(new_n376_));
  OA21x2_ASAP7_75t_R  g290(.A1(G50), .A2(new_n376_), .B(new_n375_), .Y(new_n377_));
  AO21x1_ASAP7_75t_R  g291(.A1(G51), .A2(new_n372_), .B(new_n377_), .Y(new_n378_));
  AOI21x1_ASAP7_75t_R g292(.A1(new_n358_), .A2(new_n360_), .B(new_n378_), .Y(G874));
  AO21x1_ASAP7_75t_R  g293(.A1(new_n125_), .A2(G57), .B(new_n126_), .Y(new_n380_));
  AND3x1_ASAP7_75t_R  g294(.A(new_n102_), .B(new_n380_), .C(G50), .Y(new_n381_));
  AO21x1_ASAP7_75t_R  g295(.A1(new_n121_), .A2(new_n380_), .B(new_n381_), .Y(new_n382_));
  AND3x1_ASAP7_75t_R  g296(.A(new_n260_), .B(new_n382_), .C(G47), .Y(new_n383_));
  AOI21x1_ASAP7_75t_R g297(.A1(new_n118_), .A2(new_n382_), .B(new_n383_), .Y(new_n384_));
  NOR2x1_ASAP7_75t_R  g298(.A(new_n322_), .B(new_n356_), .Y(new_n385_));
  AO21x1_ASAP7_75t_R  g299(.A1(new_n123_), .A2(new_n322_), .B(new_n385_), .Y(new_n386_));
  OR3x1_ASAP7_75t_R   g300(.A(G52), .B(G54), .C(new_n322_), .Y(new_n387_));
  AOI21x1_ASAP7_75t_R g301(.A1(new_n323_), .A2(new_n387_), .B(G47), .Y(new_n388_));
  AOI21x1_ASAP7_75t_R g302(.A1(G47), .A2(new_n386_), .B(new_n388_), .Y(new_n389_));
  AO21x1_ASAP7_75t_R  g303(.A1(new_n122_), .A2(new_n323_), .B(new_n322_), .Y(new_n390_));
  AO21x1_ASAP7_75t_R  g304(.A1(new_n122_), .A2(new_n322_), .B(new_n323_), .Y(new_n391_));
  AND2x2_ASAP7_75t_R  g305(.A(new_n316_), .B(new_n391_), .Y(new_n392_));
  AO21x1_ASAP7_75t_R  g306(.A1(new_n315_), .A2(new_n390_), .B(new_n392_), .Y(new_n393_));
  NAND2x1_ASAP7_75t_R g307(.A(G47), .B(new_n393_), .Y(new_n394_));
  AND2x2_ASAP7_75t_R  g308(.A(new_n316_), .B(new_n390_), .Y(new_n395_));
  AOI21x1_ASAP7_75t_R g309(.A1(new_n315_), .A2(new_n391_), .B(new_n395_), .Y(new_n396_));
  OA21x2_ASAP7_75t_R  g310(.A1(G47), .A2(new_n396_), .B(new_n394_), .Y(new_n397_));
  OR3x1_ASAP7_75t_R   g311(.A(new_n384_), .B(new_n389_), .C(new_n397_), .Y(new_n398_));
  INVx1_ASAP7_75t_R   g312(.A(new_n398_), .Y(G875));
  NOR2x1_ASAP7_75t_R  g313(.A(new_n110_), .B(new_n229_), .Y(new_n400_));
  INVx1_ASAP7_75t_R   g314(.A(new_n400_), .Y(new_n401_));
  AND3x1_ASAP7_75t_R  g315(.A(new_n111_), .B(G9), .C(G5), .Y(new_n402_));
  AND3x1_ASAP7_75t_R  g316(.A(G5), .B(G9), .C(new_n89_), .Y(new_n403_));
  AOI21x1_ASAP7_75t_R g317(.A1(G11), .A2(new_n402_), .B(new_n403_), .Y(new_n404_));
  OR3x1_ASAP7_75t_R   g318(.A(new_n87_), .B(new_n404_), .C(new_n88_), .Y(new_n405_));
  INVx1_ASAP7_75t_R   g319(.A(new_n405_), .Y(new_n406_));
  OAI21x1_ASAP7_75t_R g320(.A1(G36), .A2(new_n405_), .B(new_n406_), .Y(new_n407_));
  AND3x1_ASAP7_75t_R  g321(.A(new_n106_), .B(new_n407_), .C(G9), .Y(new_n408_));
  AO21x1_ASAP7_75t_R  g322(.A1(new_n131_), .A2(new_n407_), .B(new_n408_), .Y(new_n409_));
  AND3x1_ASAP7_75t_R  g323(.A(new_n253_), .B(new_n409_), .C(G25), .Y(new_n410_));
  AO21x1_ASAP7_75t_R  g324(.A1(new_n98_), .A2(new_n409_), .B(new_n410_), .Y(new_n411_));
  INVx1_ASAP7_75t_R   g325(.A(new_n411_), .Y(new_n412_));
  AO21x1_ASAP7_75t_R  g326(.A1(new_n107_), .A2(new_n406_), .B(new_n405_), .Y(new_n413_));
  AND3x1_ASAP7_75t_R  g327(.A(new_n106_), .B(new_n413_), .C(G2), .Y(new_n414_));
  AOI21x1_ASAP7_75t_R g328(.A1(new_n94_), .A2(new_n413_), .B(new_n414_), .Y(new_n415_));
  NOR2x1_ASAP7_75t_R  g329(.A(new_n400_), .B(new_n415_), .Y(new_n416_));
  AO21x1_ASAP7_75t_R  g330(.A1(new_n97_), .A2(new_n254_), .B(new_n253_), .Y(new_n417_));
  NAND2x1_ASAP7_75t_R g331(.A(new_n416_), .B(new_n417_), .Y(new_n418_));
  INVx1_ASAP7_75t_R   g332(.A(new_n418_), .Y(new_n419_));
  AO21x1_ASAP7_75t_R  g333(.A1(new_n322_), .A2(new_n330_), .B(new_n323_), .Y(new_n420_));
  AO21x1_ASAP7_75t_R  g334(.A1(new_n316_), .A2(new_n420_), .B(new_n315_), .Y(new_n421_));
  NAND2x1_ASAP7_75t_R g335(.A(new_n315_), .B(new_n420_), .Y(new_n422_));
  OA21x2_ASAP7_75t_R  g336(.A1(new_n315_), .A2(new_n329_), .B(new_n422_), .Y(new_n423_));
  NOR2x1_ASAP7_75t_R  g337(.A(G47), .B(new_n423_), .Y(new_n424_));
  AO21x1_ASAP7_75t_R  g338(.A1(G47), .A2(new_n421_), .B(new_n424_), .Y(new_n425_));
  NAND2x1_ASAP7_75t_R g339(.A(G46), .B(new_n425_), .Y(new_n426_));
  AND3x1_ASAP7_75t_R  g340(.A(new_n323_), .B(new_n330_), .C(new_n316_), .Y(new_n427_));
  AO21x1_ASAP7_75t_R  g341(.A1(new_n315_), .A2(new_n330_), .B(new_n427_), .Y(new_n428_));
  NAND2x1_ASAP7_75t_R g342(.A(G47), .B(new_n428_), .Y(new_n429_));
  OR3x1_ASAP7_75t_R   g343(.A(new_n322_), .B(new_n329_), .C(new_n316_), .Y(new_n430_));
  OA21x2_ASAP7_75t_R  g344(.A1(G47), .A2(new_n430_), .B(new_n429_), .Y(new_n431_));
  OA21x2_ASAP7_75t_R  g345(.A1(G46), .A2(new_n431_), .B(new_n426_), .Y(new_n432_));
  NOR2x1_ASAP7_75t_R  g346(.A(new_n297_), .B(new_n432_), .Y(new_n433_));
  OAI21x1_ASAP7_75t_R g347(.A1(new_n106_), .A2(G38), .B(G34), .Y(new_n434_));
  AND3x1_ASAP7_75t_R  g348(.A(new_n109_), .B(new_n434_), .C(new_n406_), .Y(new_n435_));
  AO21x1_ASAP7_75t_R  g349(.A1(new_n405_), .A2(new_n434_), .B(new_n435_), .Y(new_n436_));
  AND3x1_ASAP7_75t_R  g350(.A(new_n253_), .B(new_n436_), .C(G27), .Y(new_n437_));
  AOI21x1_ASAP7_75t_R g351(.A1(new_n100_), .A2(new_n436_), .B(new_n437_), .Y(new_n438_));
  NOR2x1_ASAP7_75t_R  g352(.A(new_n400_), .B(new_n438_), .Y(new_n439_));
  INVx1_ASAP7_75t_R   g353(.A(new_n439_), .Y(new_n440_));
  AO21x1_ASAP7_75t_R  g354(.A1(G37), .A2(new_n405_), .B(new_n108_), .Y(new_n441_));
  AND3x1_ASAP7_75t_R  g355(.A(new_n106_), .B(new_n441_), .C(G4), .Y(new_n442_));
  AO21x1_ASAP7_75t_R  g356(.A1(new_n110_), .A2(new_n441_), .B(new_n442_), .Y(new_n443_));
  AND3x1_ASAP7_75t_R  g357(.A(new_n253_), .B(new_n443_), .C(G26), .Y(new_n444_));
  AO21x1_ASAP7_75t_R  g358(.A1(new_n99_), .A2(new_n443_), .B(new_n444_), .Y(new_n445_));
  INVx1_ASAP7_75t_R   g359(.A(new_n445_), .Y(new_n446_));
  NOR2x1_ASAP7_75t_R  g360(.A(new_n400_), .B(new_n446_), .Y(new_n447_));
  INVx1_ASAP7_75t_R   g361(.A(new_n447_), .Y(new_n448_));
  AO21x1_ASAP7_75t_R  g362(.A1(new_n439_), .A2(new_n448_), .B(new_n440_), .Y(new_n449_));
  AO21x1_ASAP7_75t_R  g363(.A1(new_n115_), .A2(new_n449_), .B(G44), .Y(new_n450_));
  AND3x1_ASAP7_75t_R  g364(.A(new_n440_), .B(new_n448_), .C(new_n115_), .Y(new_n451_));
  AO21x1_ASAP7_75t_R  g365(.A1(G44), .A2(new_n448_), .B(new_n451_), .Y(new_n452_));
  AND2x2_ASAP7_75t_R  g366(.A(new_n114_), .B(new_n452_), .Y(new_n453_));
  AO21x1_ASAP7_75t_R  g367(.A1(G43), .A2(new_n450_), .B(new_n453_), .Y(new_n454_));
  OR3x1_ASAP7_75t_R   g368(.A(new_n107_), .B(new_n287_), .C(new_n230_), .Y(new_n455_));
  AOI21x1_ASAP7_75t_R g369(.A1(new_n231_), .A2(new_n455_), .B(new_n254_), .Y(new_n456_));
  AO21x1_ASAP7_75t_R  g370(.A1(new_n101_), .A2(new_n288_), .B(G28), .Y(new_n457_));
  NOR2x1_ASAP7_75t_R  g371(.A(new_n101_), .B(G35), .Y(new_n458_));
  AO21x1_ASAP7_75t_R  g372(.A1(G35), .A2(new_n457_), .B(new_n458_), .Y(new_n459_));
  AO21x1_ASAP7_75t_R  g373(.A1(new_n231_), .A2(new_n459_), .B(new_n230_), .Y(new_n460_));
  AOI21x1_ASAP7_75t_R g374(.A1(new_n254_), .A2(new_n460_), .B(new_n456_), .Y(new_n461_));
  NOR2x1_ASAP7_75t_R  g375(.A(new_n116_), .B(new_n461_), .Y(new_n462_));
  NAND2x1_ASAP7_75t_R g376(.A(new_n454_), .B(new_n462_), .Y(new_n463_));
  NOR2x1_ASAP7_75t_R  g377(.A(G44), .B(new_n447_), .Y(new_n464_));
  AO21x1_ASAP7_75t_R  g378(.A1(G44), .A2(new_n449_), .B(new_n464_), .Y(new_n465_));
  NAND2x1_ASAP7_75t_R g379(.A(G43), .B(new_n465_), .Y(new_n466_));
  OR3x1_ASAP7_75t_R   g380(.A(new_n439_), .B(new_n447_), .C(new_n115_), .Y(new_n467_));
  OA21x2_ASAP7_75t_R  g381(.A1(G43), .A2(new_n467_), .B(new_n466_), .Y(new_n468_));
  OA21x2_ASAP7_75t_R  g382(.A1(new_n462_), .A2(new_n468_), .B(new_n463_), .Y(new_n469_));
  NOR2x1_ASAP7_75t_R  g383(.A(new_n433_), .B(new_n469_), .Y(new_n470_));
  AO21x1_ASAP7_75t_R  g384(.A1(new_n433_), .A2(new_n454_), .B(new_n470_), .Y(new_n471_));
  INVx1_ASAP7_75t_R   g385(.A(new_n471_), .Y(new_n472_));
  NOR2x1_ASAP7_75t_R  g386(.A(new_n418_), .B(new_n471_), .Y(new_n473_));
  AND3x1_ASAP7_75t_R  g387(.A(new_n411_), .B(new_n473_), .C(new_n401_), .Y(new_n474_));
  NAND2x1_ASAP7_75t_R g388(.A(new_n400_), .B(new_n419_), .Y(new_n475_));
  AO21x1_ASAP7_75t_R  g389(.A1(new_n418_), .A2(new_n472_), .B(new_n419_), .Y(new_n476_));
  NAND2x1_ASAP7_75t_R g390(.A(new_n411_), .B(new_n476_), .Y(new_n477_));
  OA21x2_ASAP7_75t_R  g391(.A1(new_n411_), .A2(new_n418_), .B(new_n477_), .Y(new_n478_));
  OA21x2_ASAP7_75t_R  g392(.A1(new_n400_), .A2(new_n478_), .B(new_n475_), .Y(new_n479_));
  NOR2x1_ASAP7_75t_R  g393(.A(G41), .B(new_n479_), .Y(new_n480_));
  AO21x1_ASAP7_75t_R  g394(.A1(G41), .A2(new_n474_), .B(new_n480_), .Y(new_n481_));
  AND3x1_ASAP7_75t_R  g395(.A(new_n419_), .B(new_n472_), .C(new_n412_), .Y(new_n482_));
  AO21x1_ASAP7_75t_R  g396(.A1(new_n411_), .A2(new_n419_), .B(new_n482_), .Y(new_n483_));
  AND2x2_ASAP7_75t_R  g397(.A(new_n401_), .B(new_n483_), .Y(new_n484_));
  AO21x1_ASAP7_75t_R  g398(.A1(new_n400_), .A2(new_n473_), .B(new_n484_), .Y(new_n485_));
  NAND2x1_ASAP7_75t_R g399(.A(G41), .B(new_n485_), .Y(new_n486_));
  NAND2x1_ASAP7_75t_R g400(.A(new_n400_), .B(new_n476_), .Y(new_n487_));
  AOI21x1_ASAP7_75t_R g401(.A1(new_n412_), .A2(new_n476_), .B(new_n411_), .Y(new_n488_));
  OA21x2_ASAP7_75t_R  g402(.A1(new_n400_), .A2(new_n488_), .B(new_n487_), .Y(new_n489_));
  OA21x2_ASAP7_75t_R  g403(.A1(G41), .A2(new_n489_), .B(new_n486_), .Y(new_n490_));
  NOR2x1_ASAP7_75t_R  g404(.A(G42), .B(new_n490_), .Y(new_n491_));
  AO21x1_ASAP7_75t_R  g405(.A1(G42), .A2(new_n481_), .B(new_n491_), .Y(G876));
  OR3x1_ASAP7_75t_R   g406(.A(G52), .B(new_n259_), .C(new_n440_), .Y(new_n493_));
  OR3x1_ASAP7_75t_R   g407(.A(G53), .B(new_n259_), .C(new_n439_), .Y(new_n494_));
  AOI21x1_ASAP7_75t_R g408(.A1(new_n493_), .A2(new_n494_), .B(new_n115_), .Y(new_n495_));
  AO21x1_ASAP7_75t_R  g409(.A1(new_n123_), .A2(new_n440_), .B(new_n439_), .Y(new_n496_));
  AOI21x1_ASAP7_75t_R g410(.A1(new_n115_), .A2(new_n496_), .B(new_n495_), .Y(new_n497_));
  AO21x1_ASAP7_75t_R  g411(.A1(G26), .A2(G50), .B(new_n497_), .Y(new_n498_));
  NOR2x1_ASAP7_75t_R  g412(.A(new_n433_), .B(new_n462_), .Y(new_n499_));
  INVx1_ASAP7_75t_R   g413(.A(new_n499_), .Y(new_n500_));
  AO21x1_ASAP7_75t_R  g414(.A1(new_n122_), .A2(new_n499_), .B(new_n500_), .Y(new_n501_));
  AND2x2_ASAP7_75t_R  g415(.A(G44), .B(new_n501_), .Y(new_n502_));
  AO21x1_ASAP7_75t_R  g416(.A1(new_n122_), .A2(new_n500_), .B(new_n499_), .Y(new_n503_));
  NAND2x1_ASAP7_75t_R g417(.A(new_n115_), .B(new_n503_), .Y(new_n504_));
  INVx1_ASAP7_75t_R   g418(.A(new_n504_), .Y(new_n505_));
  OA21x2_ASAP7_75t_R  g419(.A1(new_n502_), .A2(new_n505_), .B(new_n439_), .Y(new_n506_));
  AND3x1_ASAP7_75t_R  g420(.A(new_n122_), .B(new_n124_), .C(new_n500_), .Y(new_n507_));
  AO21x1_ASAP7_75t_R  g421(.A1(new_n124_), .A2(new_n499_), .B(new_n507_), .Y(new_n508_));
  AND3x1_ASAP7_75t_R  g422(.A(new_n122_), .B(new_n124_), .C(new_n499_), .Y(new_n509_));
  AO21x1_ASAP7_75t_R  g423(.A1(new_n124_), .A2(new_n500_), .B(new_n509_), .Y(new_n510_));
  AND2x2_ASAP7_75t_R  g424(.A(new_n115_), .B(new_n510_), .Y(new_n511_));
  AO21x1_ASAP7_75t_R  g425(.A1(G44), .A2(new_n508_), .B(new_n511_), .Y(new_n512_));
  AOI21x1_ASAP7_75t_R g426(.A1(new_n440_), .A2(new_n512_), .B(new_n506_), .Y(new_n513_));
  NOR2x1_ASAP7_75t_R  g427(.A(new_n498_), .B(new_n513_), .Y(G877));
  OAI21x1_ASAP7_75t_R g428(.A1(new_n121_), .A2(G60), .B(G50), .Y(new_n515_));
  AND3x1_ASAP7_75t_R  g429(.A(new_n260_), .B(new_n515_), .C(G41), .Y(new_n516_));
  AOI21x1_ASAP7_75t_R g430(.A1(new_n112_), .A2(new_n515_), .B(new_n516_), .Y(new_n517_));
  AO21x1_ASAP7_75t_R  g431(.A1(G54), .A2(new_n417_), .B(new_n124_), .Y(new_n518_));
  NAND2x1_ASAP7_75t_R g432(.A(new_n416_), .B(new_n518_), .Y(new_n519_));
  OA21x2_ASAP7_75t_R  g433(.A1(G54), .A2(new_n416_), .B(new_n519_), .Y(new_n520_));
  NOR2x1_ASAP7_75t_R  g434(.A(G53), .B(new_n419_), .Y(new_n521_));
  AO21x1_ASAP7_75t_R  g435(.A1(new_n123_), .A2(new_n419_), .B(new_n521_), .Y(new_n522_));
  NAND2x1_ASAP7_75t_R g436(.A(G41), .B(new_n522_), .Y(new_n523_));
  OA21x2_ASAP7_75t_R  g437(.A1(G52), .A2(new_n419_), .B(new_n418_), .Y(new_n524_));
  OA21x2_ASAP7_75t_R  g438(.A1(G41), .A2(new_n524_), .B(new_n523_), .Y(new_n525_));
  OR3x1_ASAP7_75t_R   g439(.A(new_n517_), .B(new_n520_), .C(new_n525_), .Y(new_n526_));
  AND3x1_ASAP7_75t_R  g440(.A(new_n97_), .B(new_n416_), .C(new_n254_), .Y(new_n527_));
  AO21x1_ASAP7_75t_R  g441(.A1(new_n253_), .A2(new_n416_), .B(new_n527_), .Y(new_n528_));
  NOR2x1_ASAP7_75t_R  g442(.A(new_n254_), .B(new_n416_), .Y(new_n529_));
  OA21x2_ASAP7_75t_R  g443(.A1(G24), .A2(new_n416_), .B(new_n97_), .Y(new_n530_));
  NOR2x1_ASAP7_75t_R  g444(.A(new_n253_), .B(new_n530_), .Y(new_n531_));
  OA21x2_ASAP7_75t_R  g445(.A1(new_n529_), .A2(new_n531_), .B(new_n112_), .Y(new_n532_));
  AO21x1_ASAP7_75t_R  g446(.A1(G41), .A2(new_n528_), .B(new_n532_), .Y(new_n533_));
  NOR2x1_ASAP7_75t_R  g447(.A(new_n400_), .B(new_n412_), .Y(new_n534_));
  INVx1_ASAP7_75t_R   g448(.A(new_n534_), .Y(new_n535_));
  AO21x1_ASAP7_75t_R  g449(.A1(new_n122_), .A2(new_n472_), .B(new_n471_), .Y(new_n536_));
  NOR2x1_ASAP7_75t_R  g450(.A(G42), .B(G51), .Y(new_n537_));
  AO21x1_ASAP7_75t_R  g451(.A1(G42), .A2(new_n536_), .B(new_n537_), .Y(new_n538_));
  AO21x1_ASAP7_75t_R  g452(.A1(new_n113_), .A2(new_n536_), .B(G42), .Y(new_n539_));
  AND2x2_ASAP7_75t_R  g453(.A(new_n535_), .B(new_n539_), .Y(new_n540_));
  AO21x1_ASAP7_75t_R  g454(.A1(new_n534_), .A2(new_n538_), .B(new_n540_), .Y(new_n541_));
  NAND2x1_ASAP7_75t_R g455(.A(new_n533_), .B(new_n541_), .Y(new_n542_));
  AO21x1_ASAP7_75t_R  g456(.A1(new_n122_), .A2(new_n471_), .B(new_n472_), .Y(new_n543_));
  AO21x1_ASAP7_75t_R  g457(.A1(G42), .A2(new_n543_), .B(new_n113_), .Y(new_n544_));
  AND2x2_ASAP7_75t_R  g458(.A(new_n113_), .B(new_n543_), .Y(new_n545_));
  AO21x1_ASAP7_75t_R  g459(.A1(G42), .A2(new_n122_), .B(new_n545_), .Y(new_n546_));
  AND2x2_ASAP7_75t_R  g460(.A(new_n535_), .B(new_n546_), .Y(new_n547_));
  AOI21x1_ASAP7_75t_R g461(.A1(new_n534_), .A2(new_n544_), .B(new_n547_), .Y(new_n548_));
  OA21x2_ASAP7_75t_R  g462(.A1(new_n533_), .A2(new_n548_), .B(new_n542_), .Y(new_n549_));
  NOR2x1_ASAP7_75t_R  g463(.A(new_n526_), .B(new_n549_), .Y(G878));
  AO21x1_ASAP7_75t_R  g464(.A1(new_n97_), .A2(G50), .B(new_n121_), .Y(new_n551_));
  INVx1_ASAP7_75t_R   g465(.A(new_n551_), .Y(new_n552_));
  OR3x1_ASAP7_75t_R   g466(.A(new_n259_), .B(new_n552_), .C(new_n113_), .Y(new_n553_));
  NAND2x1_ASAP7_75t_R g467(.A(new_n113_), .B(new_n551_), .Y(new_n554_));
  NOR2x1_ASAP7_75t_R  g468(.A(new_n356_), .B(new_n534_), .Y(new_n555_));
  AO21x1_ASAP7_75t_R  g469(.A1(new_n123_), .A2(new_n534_), .B(new_n555_), .Y(new_n556_));
  OR3x1_ASAP7_75t_R   g470(.A(G52), .B(G54), .C(new_n534_), .Y(new_n557_));
  AOI21x1_ASAP7_75t_R g471(.A1(new_n535_), .A2(new_n557_), .B(G42), .Y(new_n558_));
  AOI21x1_ASAP7_75t_R g472(.A1(G42), .A2(new_n556_), .B(new_n558_), .Y(new_n559_));
  AO21x1_ASAP7_75t_R  g473(.A1(new_n553_), .A2(new_n554_), .B(new_n559_), .Y(new_n560_));
  NOR2x1_ASAP7_75t_R  g474(.A(new_n471_), .B(new_n560_), .Y(new_n561_));
  NOR2x1_ASAP7_75t_R  g475(.A(G51), .B(new_n560_), .Y(new_n562_));
  AO21x1_ASAP7_75t_R  g476(.A1(G51), .A2(new_n561_), .B(new_n562_), .Y(new_n563_));
  NOR2x1_ASAP7_75t_R  g477(.A(new_n472_), .B(new_n560_), .Y(new_n564_));
  AND2x2_ASAP7_75t_R  g478(.A(new_n412_), .B(new_n561_), .Y(new_n565_));
  AO21x1_ASAP7_75t_R  g479(.A1(new_n411_), .A2(new_n564_), .B(new_n565_), .Y(new_n566_));
  AOI21x1_ASAP7_75t_R g480(.A1(G51), .A2(new_n566_), .B(new_n562_), .Y(new_n567_));
  NOR2x1_ASAP7_75t_R  g481(.A(new_n400_), .B(new_n567_), .Y(new_n568_));
  AO21x1_ASAP7_75t_R  g482(.A1(new_n400_), .A2(new_n563_), .B(new_n568_), .Y(new_n569_));
  AO21x1_ASAP7_75t_R  g483(.A1(G51), .A2(new_n564_), .B(new_n562_), .Y(new_n570_));
  NAND2x1_ASAP7_75t_R g484(.A(new_n400_), .B(new_n570_), .Y(new_n571_));
  AND2x2_ASAP7_75t_R  g485(.A(new_n412_), .B(new_n564_), .Y(new_n572_));
  AO21x1_ASAP7_75t_R  g486(.A1(new_n411_), .A2(new_n561_), .B(new_n572_), .Y(new_n573_));
  AOI21x1_ASAP7_75t_R g487(.A1(G51), .A2(new_n573_), .B(new_n562_), .Y(new_n574_));
  OA21x2_ASAP7_75t_R  g488(.A1(new_n400_), .A2(new_n574_), .B(new_n571_), .Y(new_n575_));
  NOR2x1_ASAP7_75t_R  g489(.A(G42), .B(new_n575_), .Y(new_n576_));
  AO21x1_ASAP7_75t_R  g490(.A1(G42), .A2(new_n569_), .B(new_n576_), .Y(G879));
  AO21x1_ASAP7_75t_R  g491(.A1(G25), .A2(new_n121_), .B(new_n98_), .Y(new_n578_));
  AND3x1_ASAP7_75t_R  g492(.A(new_n260_), .B(new_n578_), .C(G43), .Y(new_n579_));
  AOI21x1_ASAP7_75t_R g493(.A1(new_n114_), .A2(new_n578_), .B(new_n579_), .Y(new_n580_));
  NOR2x1_ASAP7_75t_R  g494(.A(new_n356_), .B(new_n447_), .Y(new_n581_));
  AO21x1_ASAP7_75t_R  g495(.A1(new_n123_), .A2(new_n447_), .B(new_n581_), .Y(new_n582_));
  OR3x1_ASAP7_75t_R   g496(.A(G52), .B(G54), .C(new_n447_), .Y(new_n583_));
  AOI21x1_ASAP7_75t_R g497(.A1(new_n448_), .A2(new_n583_), .B(G43), .Y(new_n584_));
  AOI21x1_ASAP7_75t_R g498(.A1(G43), .A2(new_n582_), .B(new_n584_), .Y(new_n585_));
  OA21x2_ASAP7_75t_R  g499(.A1(new_n401_), .A2(new_n446_), .B(new_n445_), .Y(new_n586_));
  NOR2x1_ASAP7_75t_R  g500(.A(G43), .B(new_n586_), .Y(new_n587_));
  AO21x1_ASAP7_75t_R  g501(.A1(G43), .A2(new_n447_), .B(new_n587_), .Y(new_n588_));
  AO21x1_ASAP7_75t_R  g502(.A1(new_n115_), .A2(new_n122_), .B(new_n502_), .Y(new_n589_));
  AO21x1_ASAP7_75t_R  g503(.A1(new_n115_), .A2(new_n501_), .B(G44), .Y(new_n590_));
  AND2x2_ASAP7_75t_R  g504(.A(new_n440_), .B(new_n590_), .Y(new_n591_));
  AO21x1_ASAP7_75t_R  g505(.A1(new_n439_), .A2(new_n589_), .B(new_n591_), .Y(new_n592_));
  NAND2x1_ASAP7_75t_R g506(.A(new_n588_), .B(new_n592_), .Y(new_n593_));
  NAND2x1_ASAP7_75t_R g507(.A(G44), .B(new_n503_), .Y(new_n594_));
  AO21x1_ASAP7_75t_R  g508(.A1(G44), .A2(new_n594_), .B(new_n440_), .Y(new_n595_));
  OA21x2_ASAP7_75t_R  g509(.A1(new_n115_), .A2(G51), .B(new_n504_), .Y(new_n596_));
  OA21x2_ASAP7_75t_R  g510(.A1(new_n439_), .A2(new_n596_), .B(new_n595_), .Y(new_n597_));
  OA21x2_ASAP7_75t_R  g511(.A1(new_n588_), .A2(new_n597_), .B(new_n593_), .Y(new_n598_));
  OR3x1_ASAP7_75t_R   g512(.A(new_n580_), .B(new_n585_), .C(new_n598_), .Y(new_n599_));
  INVx1_ASAP7_75t_R   g513(.A(new_n599_), .Y(G880));
endmodule


