// Benchmark "/home/flynn/workplace/MIGBalance/results_v2/fixed_all_eqmap_20261012/c17/lut_stage_amap/stage" written by ABC on Mon Oct 12 15:00:56 2026

module \/home/flynn/workplace/MIGBalance/results_v2/fixed_all_eqmap_20261012/c17/lut_stage_amap/stage  ( 
    G1, G2, G3, G4, G5,
    G16, G17  );
  input  G1, G2, G3, G4, G5;
  output G16, G17;
  wire new_n8_, new_n9_, new_n10_, new_n11_, new_n12_, new_n13_, new_n14_,
    new_n16_, new_n17_;
  INVx1_ASAP7_75t_R   g00(.A(G1), .Y(new_n8_));
  INVx1_ASAP7_75t_R   g01(.A(G2), .Y(new_n9_));
  INVx1_ASAP7_75t_R   g02(.A(G3), .Y(new_n10_));
  INVx1_ASAP7_75t_R   g03(.A(G4), .Y(new_n11_));
  AO21x1_ASAP7_75t_R  g04(.A1(new_n8_), .A2(new_n11_), .B(G1), .Y(new_n12_));
  AO21x1_ASAP7_75t_R  g05(.A1(G3), .A2(new_n12_), .B(new_n10_), .Y(new_n13_));
  AND3x1_ASAP7_75t_R  g06(.A(G1), .B(G3), .C(new_n9_), .Y(new_n14_));
  AO21x1_ASAP7_75t_R  g07(.A1(G2), .A2(new_n13_), .B(new_n14_), .Y(G16));
  AO21x1_ASAP7_75t_R  g08(.A1(G3), .A2(new_n11_), .B(new_n10_), .Y(new_n16_));
  AND3x1_ASAP7_75t_R  g09(.A(G5), .B(new_n16_), .C(new_n9_), .Y(new_n17_));
  AO21x1_ASAP7_75t_R  g10(.A1(G2), .A2(new_n16_), .B(new_n17_), .Y(G17));
endmodule


