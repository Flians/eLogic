// Benchmark "/home/flynn/workplace/MIGBalance/results_v2/fixed_all_eqmap_20261012/c1355/subject" written by ABC on Mon Oct 12 15:01:26 2026

module \/home/flynn/workplace/MIGBalance/results_v2/fixed_all_eqmap_20261012/c1355/subject  ( 
    G1, G5, G9, G13, G33, G41, G17, G18, G19, G20, G21, G22, G23, G24, G4,
    G8, G12, G16, G36, G29, G30, G31, G32, G3, G7, G11, G15, G35, G25, G26,
    G27, G28, G2, G6, G10, G14, G34, G40, G39, G38, G37,
    G1324, G1344, G1325, G1326, G1327, G1328, G1329, G1330, G1343, G1331,
    G1332, G1333, G1334, G1335, G1336, G1337, G1338, G1339, G1340, G1341,
    G1342, G1345, G1346, G1347, G1348, G1349, G1350, G1351, G1352, G1353,
    G1354, G1355  );
  input  G1, G5, G9, G13, G33, G41, G17, G18, G19, G20, G21, G22, G23,
    G24, G4, G8, G12, G16, G36, G29, G30, G31, G32, G3, G7, G11, G15, G35,
    G25, G26, G27, G28, G2, G6, G10, G14, G34, G40, G39, G38, G37;
  output G1324, G1344, G1325, G1326, G1327, G1328, G1329, G1330, G1343, G1331,
    G1332, G1333, G1334, G1335, G1336, G1337, G1338, G1339, G1340, G1341,
    G1342, G1345, G1346, G1347, G1348, G1349, G1350, G1351, G1352, G1353,
    G1354, G1355;
  wire new_n74_, new_n75_, new_n76_, new_n77_, new_n78_, new_n79_, new_n80_,
    new_n81_, new_n82_, new_n83_, new_n84_, new_n85_, new_n86_, new_n87_,
    new_n88_, new_n89_, new_n90_, new_n91_, new_n92_, new_n93_, new_n94_,
    new_n95_, new_n96_, new_n97_, new_n98_, new_n99_, new_n100_, new_n101_,
    new_n102_, new_n103_, new_n104_, new_n105_, new_n106_, new_n107_,
    new_n108_, new_n109_, new_n110_, new_n111_, new_n112_, new_n113_,
    new_n114_, new_n115_, new_n116_, new_n117_, new_n118_, new_n119_,
    new_n120_, new_n121_, new_n122_, new_n123_, new_n124_, new_n125_,
    new_n126_, new_n127_, new_n128_, new_n129_, new_n130_, new_n131_,
    new_n132_, new_n133_, new_n134_, new_n135_, new_n136_, new_n137_,
    new_n138_, new_n139_, new_n140_, new_n141_, new_n142_, new_n143_,
    new_n144_, new_n145_, new_n146_, new_n147_, new_n148_, new_n149_,
    new_n150_, new_n151_, new_n152_, new_n153_, new_n154_, new_n155_,
    new_n156_, new_n157_, new_n158_, new_n159_, new_n160_, new_n161_,
    new_n162_, new_n163_, new_n164_, new_n165_, new_n166_, new_n167_,
    new_n168_, new_n169_, new_n170_, new_n171_, new_n172_, new_n173_,
    new_n174_, new_n175_, new_n176_, new_n177_, new_n178_, new_n179_,
    new_n180_, new_n181_, new_n182_, new_n183_, new_n184_, new_n186_,
    new_n187_, new_n188_, new_n189_, new_n190_, new_n191_, new_n192_,
    new_n193_, new_n194_, new_n196_, new_n198_, new_n200_, new_n202_,
    new_n203_, new_n204_, new_n206_, new_n208_, new_n210_, new_n211_,
    new_n212_, new_n214_, new_n216_, new_n217_, new_n219_, new_n221_,
    new_n223_, new_n225_, new_n226_, new_n228_, new_n230_, new_n232_,
    new_n234_, new_n236_, new_n238_, new_n240_, new_n242_, new_n244_,
    new_n246_, new_n247_, new_n249_, new_n251_, new_n253_, new_n255_,
    new_n256_, new_n258_, new_n260_, new_n262_;
  INVx1_ASAP7_75t_R   g000(.A(G1), .Y(new_n74_));
  INVx1_ASAP7_75t_R   g001(.A(G5), .Y(new_n75_));
  INVx1_ASAP7_75t_R   g002(.A(G9), .Y(new_n76_));
  INVx1_ASAP7_75t_R   g003(.A(G13), .Y(new_n77_));
  INVx1_ASAP7_75t_R   g004(.A(G17), .Y(new_n78_));
  INVx1_ASAP7_75t_R   g005(.A(G18), .Y(new_n79_));
  INVx1_ASAP7_75t_R   g006(.A(G19), .Y(new_n80_));
  INVx1_ASAP7_75t_R   g007(.A(G20), .Y(new_n81_));
  INVx1_ASAP7_75t_R   g008(.A(G21), .Y(new_n82_));
  INVx1_ASAP7_75t_R   g009(.A(G4), .Y(new_n83_));
  INVx1_ASAP7_75t_R   g010(.A(G29), .Y(new_n84_));
  INVx1_ASAP7_75t_R   g011(.A(G3), .Y(new_n85_));
  INVx1_ASAP7_75t_R   g012(.A(G25), .Y(new_n86_));
  INVx1_ASAP7_75t_R   g013(.A(G2), .Y(new_n87_));
  XNOR2x2_ASAP7_75t_R g014(.A(G19), .B(G20), .Y(new_n88_));
  XNOR2x2_ASAP7_75t_R g015(.A(new_n78_), .B(G18), .Y(new_n89_));
  XNOR2x2_ASAP7_75t_R g016(.A(new_n88_), .B(new_n89_), .Y(new_n90_));
  NAND2x1_ASAP7_75t_R g017(.A(G33), .B(G41), .Y(new_n91_));
  XNOR2x2_ASAP7_75t_R g018(.A(new_n90_), .B(new_n91_), .Y(new_n92_));
  XNOR2x2_ASAP7_75t_R g019(.A(G23), .B(G24), .Y(new_n93_));
  XNOR2x2_ASAP7_75t_R g020(.A(new_n82_), .B(G22), .Y(new_n94_));
  XNOR2x2_ASAP7_75t_R g021(.A(new_n93_), .B(new_n94_), .Y(new_n95_));
  XNOR2x2_ASAP7_75t_R g022(.A(G9), .B(G13), .Y(new_n96_));
  XOR2x2_ASAP7_75t_R  g023(.A(new_n74_), .B(G5), .Y(new_n97_));
  XOR2x2_ASAP7_75t_R  g024(.A(new_n96_), .B(new_n97_), .Y(new_n98_));
  XNOR2x2_ASAP7_75t_R g025(.A(new_n95_), .B(new_n98_), .Y(new_n99_));
  XOR2x2_ASAP7_75t_R  g026(.A(new_n92_), .B(new_n99_), .Y(new_n100_));
  NAND2x1_ASAP7_75t_R g027(.A(G41), .B(G36), .Y(new_n101_));
  XNOR2x2_ASAP7_75t_R g028(.A(new_n95_), .B(new_n101_), .Y(new_n102_));
  XNOR2x2_ASAP7_75t_R g029(.A(G31), .B(G32), .Y(new_n103_));
  XNOR2x2_ASAP7_75t_R g030(.A(new_n84_), .B(G30), .Y(new_n104_));
  XNOR2x2_ASAP7_75t_R g031(.A(new_n103_), .B(new_n104_), .Y(new_n105_));
  XNOR2x2_ASAP7_75t_R g032(.A(G12), .B(G16), .Y(new_n106_));
  XOR2x2_ASAP7_75t_R  g033(.A(new_n83_), .B(G8), .Y(new_n107_));
  XOR2x2_ASAP7_75t_R  g034(.A(new_n106_), .B(new_n107_), .Y(new_n108_));
  XNOR2x2_ASAP7_75t_R g035(.A(new_n105_), .B(new_n108_), .Y(new_n109_));
  XOR2x2_ASAP7_75t_R  g036(.A(new_n102_), .B(new_n109_), .Y(new_n110_));
  INVx1_ASAP7_75t_R   g037(.A(new_n110_), .Y(new_n111_));
  NAND2x1_ASAP7_75t_R g038(.A(G41), .B(G35), .Y(new_n112_));
  XNOR2x2_ASAP7_75t_R g039(.A(new_n90_), .B(new_n112_), .Y(new_n113_));
  XNOR2x2_ASAP7_75t_R g040(.A(G27), .B(G28), .Y(new_n114_));
  XNOR2x2_ASAP7_75t_R g041(.A(new_n86_), .B(G26), .Y(new_n115_));
  XNOR2x2_ASAP7_75t_R g042(.A(new_n114_), .B(new_n115_), .Y(new_n116_));
  XNOR2x2_ASAP7_75t_R g043(.A(G11), .B(G15), .Y(new_n117_));
  XOR2x2_ASAP7_75t_R  g044(.A(new_n85_), .B(G7), .Y(new_n118_));
  XOR2x2_ASAP7_75t_R  g045(.A(new_n117_), .B(new_n118_), .Y(new_n119_));
  XNOR2x2_ASAP7_75t_R g046(.A(new_n116_), .B(new_n119_), .Y(new_n120_));
  XOR2x2_ASAP7_75t_R  g047(.A(new_n113_), .B(new_n120_), .Y(new_n121_));
  INVx1_ASAP7_75t_R   g048(.A(new_n121_), .Y(new_n122_));
  NOR2x1_ASAP7_75t_R  g049(.A(new_n111_), .B(new_n122_), .Y(new_n123_));
  AO21x1_ASAP7_75t_R  g050(.A1(new_n111_), .A2(new_n122_), .B(new_n123_), .Y(new_n124_));
  NAND2x1_ASAP7_75t_R g051(.A(G41), .B(G34), .Y(new_n125_));
  XNOR2x2_ASAP7_75t_R g052(.A(new_n105_), .B(new_n125_), .Y(new_n126_));
  XNOR2x2_ASAP7_75t_R g053(.A(G10), .B(G14), .Y(new_n127_));
  XOR2x2_ASAP7_75t_R  g054(.A(new_n87_), .B(G6), .Y(new_n128_));
  XOR2x2_ASAP7_75t_R  g055(.A(new_n127_), .B(new_n128_), .Y(new_n129_));
  XNOR2x2_ASAP7_75t_R g056(.A(new_n116_), .B(new_n129_), .Y(new_n130_));
  XOR2x2_ASAP7_75t_R  g057(.A(new_n126_), .B(new_n130_), .Y(new_n131_));
  INVx1_ASAP7_75t_R   g058(.A(new_n131_), .Y(new_n132_));
  OR2x4_ASAP7_75t_R   g059(.A(new_n100_), .B(new_n132_), .Y(new_n133_));
  NAND2x1_ASAP7_75t_R g060(.A(new_n100_), .B(new_n132_), .Y(new_n134_));
  AND2x2_ASAP7_75t_R  g061(.A(new_n133_), .B(new_n134_), .Y(new_n135_));
  AOI21x1_ASAP7_75t_R g062(.A1(new_n100_), .A2(new_n131_), .B(new_n123_), .Y(new_n136_));
  AO21x1_ASAP7_75t_R  g063(.A1(new_n124_), .A2(new_n135_), .B(new_n136_), .Y(new_n137_));
  NAND2x1_ASAP7_75t_R g064(.A(G41), .B(G40), .Y(new_n138_));
  XNOR2x2_ASAP7_75t_R g065(.A(G8), .B(G7), .Y(new_n139_));
  XNOR2x2_ASAP7_75t_R g066(.A(new_n75_), .B(G6), .Y(new_n140_));
  XNOR2x2_ASAP7_75t_R g067(.A(new_n139_), .B(new_n140_), .Y(new_n141_));
  XNOR2x2_ASAP7_75t_R g068(.A(new_n138_), .B(new_n141_), .Y(new_n142_));
  XNOR2x2_ASAP7_75t_R g069(.A(G32), .B(G28), .Y(new_n143_));
  XNOR2x2_ASAP7_75t_R g070(.A(new_n81_), .B(G24), .Y(new_n144_));
  XNOR2x2_ASAP7_75t_R g071(.A(new_n143_), .B(new_n144_), .Y(new_n145_));
  XNOR2x2_ASAP7_75t_R g072(.A(G16), .B(G15), .Y(new_n146_));
  XNOR2x2_ASAP7_75t_R g073(.A(new_n77_), .B(G14), .Y(new_n147_));
  XOR2x2_ASAP7_75t_R  g074(.A(new_n146_), .B(new_n147_), .Y(new_n148_));
  XNOR2x2_ASAP7_75t_R g075(.A(new_n145_), .B(new_n148_), .Y(new_n149_));
  XOR2x2_ASAP7_75t_R  g076(.A(new_n142_), .B(new_n149_), .Y(new_n150_));
  INVx1_ASAP7_75t_R   g077(.A(new_n150_), .Y(new_n151_));
  OR2x4_ASAP7_75t_R   g078(.A(new_n137_), .B(new_n150_), .Y(new_n152_));
  NAND2x1_ASAP7_75t_R g079(.A(G41), .B(G38), .Y(new_n153_));
  XOR2x2_ASAP7_75t_R  g080(.A(new_n148_), .B(new_n153_), .Y(new_n154_));
  XNOR2x2_ASAP7_75t_R g081(.A(G12), .B(G11), .Y(new_n155_));
  XNOR2x2_ASAP7_75t_R g082(.A(new_n76_), .B(G10), .Y(new_n156_));
  XNOR2x2_ASAP7_75t_R g083(.A(new_n155_), .B(new_n156_), .Y(new_n157_));
  XNOR2x2_ASAP7_75t_R g084(.A(G30), .B(G26), .Y(new_n158_));
  XOR2x2_ASAP7_75t_R  g085(.A(new_n79_), .B(G22), .Y(new_n159_));
  XOR2x2_ASAP7_75t_R  g086(.A(new_n158_), .B(new_n159_), .Y(new_n160_));
  XNOR2x2_ASAP7_75t_R g087(.A(new_n157_), .B(new_n160_), .Y(new_n161_));
  XOR2x2_ASAP7_75t_R  g088(.A(new_n154_), .B(new_n161_), .Y(new_n162_));
  INVx1_ASAP7_75t_R   g089(.A(new_n162_), .Y(new_n163_));
  NAND2x1_ASAP7_75t_R g090(.A(G41), .B(G37), .Y(new_n164_));
  XNOR2x2_ASAP7_75t_R g091(.A(new_n141_), .B(new_n164_), .Y(new_n165_));
  XNOR2x2_ASAP7_75t_R g092(.A(G4), .B(G3), .Y(new_n166_));
  XNOR2x2_ASAP7_75t_R g093(.A(new_n74_), .B(G2), .Y(new_n167_));
  XNOR2x2_ASAP7_75t_R g094(.A(new_n166_), .B(new_n167_), .Y(new_n168_));
  XNOR2x2_ASAP7_75t_R g095(.A(G29), .B(G25), .Y(new_n169_));
  XOR2x2_ASAP7_75t_R  g096(.A(new_n78_), .B(G21), .Y(new_n170_));
  XOR2x2_ASAP7_75t_R  g097(.A(new_n169_), .B(new_n170_), .Y(new_n171_));
  XNOR2x2_ASAP7_75t_R g098(.A(new_n168_), .B(new_n171_), .Y(new_n172_));
  XOR2x2_ASAP7_75t_R  g099(.A(new_n165_), .B(new_n172_), .Y(new_n173_));
  OR2x4_ASAP7_75t_R   g100(.A(new_n163_), .B(new_n173_), .Y(new_n174_));
  NAND2x1_ASAP7_75t_R g101(.A(G41), .B(G39), .Y(new_n175_));
  XNOR2x2_ASAP7_75t_R g102(.A(new_n168_), .B(new_n175_), .Y(new_n176_));
  XNOR2x2_ASAP7_75t_R g103(.A(G31), .B(G27), .Y(new_n177_));
  XOR2x2_ASAP7_75t_R  g104(.A(new_n80_), .B(G23), .Y(new_n178_));
  XOR2x2_ASAP7_75t_R  g105(.A(new_n177_), .B(new_n178_), .Y(new_n179_));
  XNOR2x2_ASAP7_75t_R g106(.A(new_n157_), .B(new_n179_), .Y(new_n180_));
  XOR2x2_ASAP7_75t_R  g107(.A(new_n176_), .B(new_n180_), .Y(new_n181_));
  INVx1_ASAP7_75t_R   g108(.A(new_n181_), .Y(new_n182_));
  OR3x1_ASAP7_75t_R   g109(.A(new_n174_), .B(new_n181_), .C(new_n152_), .Y(new_n183_));
  NOR2x1_ASAP7_75t_R  g110(.A(new_n100_), .B(new_n183_), .Y(new_n184_));
  XOR2x2_ASAP7_75t_R  g111(.A(new_n74_), .B(new_n184_), .Y(G1324));
  NOR2x1_ASAP7_75t_R  g112(.A(new_n150_), .B(new_n182_), .Y(new_n186_));
  AO21x1_ASAP7_75t_R  g113(.A1(new_n150_), .A2(new_n182_), .B(new_n186_), .Y(new_n187_));
  NAND2x1_ASAP7_75t_R g114(.A(new_n163_), .B(new_n173_), .Y(new_n188_));
  AND2x2_ASAP7_75t_R  g115(.A(new_n174_), .B(new_n188_), .Y(new_n189_));
  AOI21x1_ASAP7_75t_R g116(.A1(new_n162_), .A2(new_n173_), .B(new_n186_), .Y(new_n190_));
  AO21x1_ASAP7_75t_R  g117(.A1(new_n187_), .A2(new_n189_), .B(new_n190_), .Y(new_n191_));
  OR2x4_ASAP7_75t_R   g118(.A(new_n110_), .B(new_n191_), .Y(new_n192_));
  OR3x1_ASAP7_75t_R   g119(.A(new_n122_), .B(new_n133_), .C(new_n192_), .Y(new_n193_));
  NOR2x1_ASAP7_75t_R  g120(.A(new_n173_), .B(new_n193_), .Y(new_n194_));
  XOR2x2_ASAP7_75t_R  g121(.A(new_n82_), .B(new_n194_), .Y(G1344));
  NOR2x1_ASAP7_75t_R  g122(.A(new_n131_), .B(new_n183_), .Y(new_n196_));
  XOR2x2_ASAP7_75t_R  g123(.A(new_n87_), .B(new_n196_), .Y(G1325));
  NOR2x1_ASAP7_75t_R  g124(.A(new_n121_), .B(new_n183_), .Y(new_n198_));
  XOR2x2_ASAP7_75t_R  g125(.A(new_n85_), .B(new_n198_), .Y(G1326));
  NOR2x1_ASAP7_75t_R  g126(.A(new_n110_), .B(new_n183_), .Y(new_n200_));
  XOR2x2_ASAP7_75t_R  g127(.A(new_n83_), .B(new_n200_), .Y(G1327));
  OR2x4_ASAP7_75t_R   g128(.A(new_n137_), .B(new_n151_), .Y(new_n202_));
  OR3x1_ASAP7_75t_R   g129(.A(new_n174_), .B(new_n182_), .C(new_n202_), .Y(new_n203_));
  NOR2x1_ASAP7_75t_R  g130(.A(new_n100_), .B(new_n203_), .Y(new_n204_));
  XOR2x2_ASAP7_75t_R  g131(.A(new_n75_), .B(new_n204_), .Y(G1328));
  NOR2x1_ASAP7_75t_R  g132(.A(new_n131_), .B(new_n203_), .Y(new_n206_));
  XNOR2x2_ASAP7_75t_R g133(.A(G6), .B(new_n206_), .Y(G1329));
  NOR2x1_ASAP7_75t_R  g134(.A(new_n121_), .B(new_n203_), .Y(new_n208_));
  XNOR2x2_ASAP7_75t_R g135(.A(G7), .B(new_n208_), .Y(G1330));
  OR2x4_ASAP7_75t_R   g136(.A(new_n111_), .B(new_n191_), .Y(new_n210_));
  OR3x1_ASAP7_75t_R   g137(.A(new_n121_), .B(new_n133_), .C(new_n210_), .Y(new_n211_));
  NOR2x1_ASAP7_75t_R  g138(.A(new_n151_), .B(new_n211_), .Y(new_n212_));
  XOR2x2_ASAP7_75t_R  g139(.A(new_n81_), .B(new_n212_), .Y(G1343));
  NOR2x1_ASAP7_75t_R  g140(.A(new_n110_), .B(new_n203_), .Y(new_n214_));
  XNOR2x2_ASAP7_75t_R g141(.A(G8), .B(new_n214_), .Y(G1331));
  OR3x1_ASAP7_75t_R   g142(.A(new_n181_), .B(new_n188_), .C(new_n152_), .Y(new_n216_));
  NOR2x1_ASAP7_75t_R  g143(.A(new_n100_), .B(new_n216_), .Y(new_n217_));
  XOR2x2_ASAP7_75t_R  g144(.A(new_n76_), .B(new_n217_), .Y(G1332));
  NOR2x1_ASAP7_75t_R  g145(.A(new_n131_), .B(new_n216_), .Y(new_n219_));
  XNOR2x2_ASAP7_75t_R g146(.A(G10), .B(new_n219_), .Y(G1333));
  NOR2x1_ASAP7_75t_R  g147(.A(new_n121_), .B(new_n216_), .Y(new_n221_));
  XNOR2x2_ASAP7_75t_R g148(.A(G11), .B(new_n221_), .Y(G1334));
  NOR2x1_ASAP7_75t_R  g149(.A(new_n110_), .B(new_n216_), .Y(new_n223_));
  XNOR2x2_ASAP7_75t_R g150(.A(G12), .B(new_n223_), .Y(G1335));
  OR3x1_ASAP7_75t_R   g151(.A(new_n182_), .B(new_n188_), .C(new_n202_), .Y(new_n225_));
  NOR2x1_ASAP7_75t_R  g152(.A(new_n100_), .B(new_n225_), .Y(new_n226_));
  XOR2x2_ASAP7_75t_R  g153(.A(new_n77_), .B(new_n226_), .Y(G1336));
  NOR2x1_ASAP7_75t_R  g154(.A(new_n131_), .B(new_n225_), .Y(new_n228_));
  XNOR2x2_ASAP7_75t_R g155(.A(G14), .B(new_n228_), .Y(G1337));
  NOR2x1_ASAP7_75t_R  g156(.A(new_n121_), .B(new_n225_), .Y(new_n230_));
  XNOR2x2_ASAP7_75t_R g157(.A(G15), .B(new_n230_), .Y(G1338));
  NOR2x1_ASAP7_75t_R  g158(.A(new_n110_), .B(new_n225_), .Y(new_n232_));
  XNOR2x2_ASAP7_75t_R g159(.A(G16), .B(new_n232_), .Y(G1339));
  NOR2x1_ASAP7_75t_R  g160(.A(new_n173_), .B(new_n211_), .Y(new_n234_));
  XOR2x2_ASAP7_75t_R  g161(.A(new_n78_), .B(new_n234_), .Y(G1340));
  NOR2x1_ASAP7_75t_R  g162(.A(new_n162_), .B(new_n211_), .Y(new_n236_));
  XOR2x2_ASAP7_75t_R  g163(.A(new_n79_), .B(new_n236_), .Y(G1341));
  NOR2x1_ASAP7_75t_R  g164(.A(new_n181_), .B(new_n211_), .Y(new_n238_));
  XOR2x2_ASAP7_75t_R  g165(.A(new_n80_), .B(new_n238_), .Y(G1342));
  NOR2x1_ASAP7_75t_R  g166(.A(new_n162_), .B(new_n193_), .Y(new_n240_));
  XNOR2x2_ASAP7_75t_R g167(.A(G22), .B(new_n240_), .Y(G1345));
  NOR2x1_ASAP7_75t_R  g168(.A(new_n181_), .B(new_n193_), .Y(new_n242_));
  XNOR2x2_ASAP7_75t_R g169(.A(G23), .B(new_n242_), .Y(G1346));
  NOR2x1_ASAP7_75t_R  g170(.A(new_n151_), .B(new_n193_), .Y(new_n244_));
  XNOR2x2_ASAP7_75t_R g171(.A(G24), .B(new_n244_), .Y(G1347));
  OR3x1_ASAP7_75t_R   g172(.A(new_n121_), .B(new_n134_), .C(new_n210_), .Y(new_n246_));
  NOR2x1_ASAP7_75t_R  g173(.A(new_n173_), .B(new_n246_), .Y(new_n247_));
  XOR2x2_ASAP7_75t_R  g174(.A(new_n86_), .B(new_n247_), .Y(G1348));
  NOR2x1_ASAP7_75t_R  g175(.A(new_n162_), .B(new_n246_), .Y(new_n249_));
  XNOR2x2_ASAP7_75t_R g176(.A(G26), .B(new_n249_), .Y(G1349));
  NOR2x1_ASAP7_75t_R  g177(.A(new_n181_), .B(new_n246_), .Y(new_n251_));
  XNOR2x2_ASAP7_75t_R g178(.A(G27), .B(new_n251_), .Y(G1350));
  NOR2x1_ASAP7_75t_R  g179(.A(new_n151_), .B(new_n246_), .Y(new_n253_));
  XNOR2x2_ASAP7_75t_R g180(.A(G28), .B(new_n253_), .Y(G1351));
  OR3x1_ASAP7_75t_R   g181(.A(new_n122_), .B(new_n134_), .C(new_n192_), .Y(new_n255_));
  NOR2x1_ASAP7_75t_R  g182(.A(new_n173_), .B(new_n255_), .Y(new_n256_));
  XOR2x2_ASAP7_75t_R  g183(.A(new_n84_), .B(new_n256_), .Y(G1352));
  NOR2x1_ASAP7_75t_R  g184(.A(new_n162_), .B(new_n255_), .Y(new_n258_));
  XNOR2x2_ASAP7_75t_R g185(.A(G30), .B(new_n258_), .Y(G1353));
  NOR2x1_ASAP7_75t_R  g186(.A(new_n181_), .B(new_n255_), .Y(new_n260_));
  XNOR2x2_ASAP7_75t_R g187(.A(G31), .B(new_n260_), .Y(G1354));
  NOR2x1_ASAP7_75t_R  g188(.A(new_n151_), .B(new_n255_), .Y(new_n262_));
  XNOR2x2_ASAP7_75t_R g189(.A(G32), .B(new_n262_), .Y(G1355));
endmodule


