module mapped(G1, G3, G2, G4, G5, G16, G17);
  input G1;
  input G3;
  input G2;
  input G4;
  input G5;
  output G16;
  output G17;
  wire __egm_s17;
  wire __egm_s30;
  wire __egm_s36;
  wire __egm_s42;
  OA21x2_ASAP7_75t_R __egm_g13 (.A1(G5), .A2(G2), .B(__egm_s17), .Y(__egm_s30));
  NAND2x1_ASAP7_75t_R __egm_g88 (.A(G4), .B(G3), .Y(__egm_s17));
  AO21x1_ASAP7_75t_R __egm_g120 (.A2(G2), .A1(__egm_s17), .B(__egm_s36), .Y(__egm_s42));
  AND2x2_ASAP7_75t_R __egm_g188 (.A(G3), .B(G1), .Y(__egm_s36));
  assign G16 = __egm_s42;
  assign G17 = __egm_s30;
endmodule
