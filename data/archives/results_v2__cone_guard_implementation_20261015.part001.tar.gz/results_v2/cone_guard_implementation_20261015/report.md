# Exact bounded-cone import: full EPFL and prespecified repetitions

This is an isolated experimental version, not a production promotion. Baseline author algorithms/models/parameters, both libraries, once-resyn2 input hashes and all failures are unchanged. The production mapper remains SHA256 `76655d8ba89ba4a80382be6c7ca570e7941d3f1501250d574dc061eef3c31aa6`.

The fixed representation policy keeps original import when it fits 90% of the node allowance. Otherwise it contracts exact XOR patterns and single-use two-AND cones into bounded logical operators. TT3 truth tables and every child are stored in actual counted e-nodes. Up to 2048 source helper functions are materialized, chosen by deterministic structural slack; atomic helper groups must fit the same 90% initial capacity. Certificates authorize physical matching only through actual imported class IDs. Source cuts and matches consume the ordinary cut/pool banks. No large external Boolean function, resident/cumulative substitution, regional reset or conditional union is used. The actual e-node unit is more expressive than an expanded AND, so this is **not an unchanged expanded-AIG work-unit comparison**. Source AND counts remain reported. Old prototype occurrence-counter semantics are preserved in `../cone_import_implementation_20261015/counter_semantics.json`; actual total enodes are authoritative.

The failed 80%-trigger full study remains in `tt3_helpers_full_20261015`: 3in square delay2707.68->2723.04. The new90% rule follows one resource threshold for every design/library; it also forgoes the earlier favorable4in square result. No per-design winners are selected.

## Complete fixed-profile study

`cone_guard_full_20261015` has80 fresh attempts:20designs x2libraries xprotected current control/candidate.64direct original-input named-port CEC successes,16explicit node failures. Candidate34/40 legal covers versus control30/40; log2 and multiplier newly pass in both libraries.30old-legal pairs: D2better/28equal/0worse; A2better/27equal/1worse. All successful actual node/cut/pool/recovery/mapping limits and recorded hashes pass. The one raw regression is4in adder area83.75->84.49; its import is inactive and pool unchanged. It is **not removed or repaired with repeat values**. Thus the strict full-study self gate remains false.

| sqrt | Control area | Candidate area | Control delay | Candidate delay | Delay vs original emap |
|---|---:|---:|---:|---:|---:|
|3in|2159.11|1814.66|68523.99|63951.92|+6.43%|
|4in|2743.80|2188.56|66924.64|57161.09|+21.50%|

Area improves15.95%/20.24%, delay6.67%/14.59%. These are first full-run values, not selected best repeats. New covers: log2 A/D2164.42/5141.39 and2304.13/4835.23; multiplier1993.29/2930.93 and2087.12/2954.30. They do not establish all-baseline superiority.

## Repetition accounting

Seven fixed targets(log2,multiplier,sqrt,square,adder,priority,int2float), both libraries, two additional alternating-order repetitions:56status slots =48fresh native attempts +8explicitly adopted unchanged pre-import control failures. The adopted failures have matching source/input/library/settings and actual immutable budget-log proofs; they are not new mapping runs or successes. Combined with the80full attempts there are **128unique native attempts:112directCEC,16native node failures**. The136status slots include the8failure reobservations. The repeat report's84-observation view includes28full-run target slots; it is not84new runs or a second full20 repeat.

All six sqrt pairs reproduce exactly the above metrics. All12candidate log2/multiplier observations pass CEC and retain identical metrics per design/library. Square and int2float match controls; priority has one additional area gain. The target view has30old-legal pairs: D6better/24equal/0worse; A7better/22equal/1worse, retaining the original full-run adder regression. Four fresh4in adder repetitions all give83.75, but the original84.49 is retained. No best-repeat replacement. Few repeats do not establish statistical confidence or independence from load.

The adder trace in `cone_guard_adder_diagnosis_20261015` has identical discrete pre-tail choices. Variation appears only after the late shared-area stage. Wall-clock truncation is a supported hypothesis, not proof of the exact interrupted operation. A validated in-process incumbent is protected; it cannot guarantee another process's outcome under every deadline schedule. The false self gate prevents production promotion in this round.

## Remaining failures and delay evidence

Candidate imports:div28644,hyp143890,mem_ctrl29791, all>20000 and with zero optional helpers. Neither a later phase pass nor cap tuning can repair these import rejections. This is a limitation of the present representation, not a lower bound or infeasibility proof for other exact representations.

Eight independent saved-netlist path reconstructions match public all-instance area and unloaded dependent-pin delay. sqrt3 path cells3214->2999, original emap2951; sqrt4 path cells2872->2613, emap2077. Candidate4in path has512AO31 versus1742in emap. These are descriptions of selected paths, which may have different endpoints, not causal proof. Candidate final-critical signals with finite before/after estimates have zero loss of the **single best common-area-witness arrival estimate** at the100kcap; that does not prove retention of every useful producer, globally feasible delay optimality or absence of candidate loss. The remaining gap needs cut/boundary/phase-chain correspondence, not an unsupported claim that all AO31 loss is solved.

## Baselines, budgets, and next work

13403actual baseline dependency/native tracked files rechecked with zero drift; all original240groups/520status slots retained(372CEC/124reported failures/24unmeasured failures). All six full-scope gates(two libraries xdelay-area/area-delay/Pareto) remain false. AD is a posthoc check of this DA profile, not fresh AD optimization. MtM remains unconnected. Mapping300s excludes prep/conversion/CEC/metrics; native process60s/EqMap90s and native search parameters are unchanged. EqMap initial nested LUT mapping has a conservative enclosing-Yosys time bound, not exact runtime.

Actual successful-map limits:20kglobalenodes,16cuts/class,100kretainedinstances,16SATiterations, one2sordinaryrecovery including witness/setup/alternatives/finalvalidation. Transient generation is separate; retainedcap is notRAMcap. Stage checks are nonpreemptive; actual overrun is failure. All commands/settings/hashes and negative versions retained.

Next: instrument and preserve validated shared-area progress during late flow, with a real reconvergent regression fixture; do not loosen gates or rerun until a lucky success. Audit original emap/ABC AO31 chains against exact admitted source boundaries/cuts/phase partners; use signatures only as prefilters and exact proof for any claimed function correspondence. For the three remaining imports, investigate bounded exact shared-cone representations before recovery, charging every actual function and keeping expanded source counts explicit. Any changed source/configuration requires a new full matrix and repetitions. Defaults and production Rust/CLI remain unchanged.
