"""Run only after all native timing experiments have finished."""
import hashlib,json,os,subprocess,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];P=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'scripts/experiments'))
from audit_mapped_ppa import audit
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
subprocess.run([sys.executable,str(P/'report.py')],check=True)
rows=json.loads((P/'verified_results.json').read_text())
assert len(rows)==14 and sum(r['arm']=='recheck' for r in rows)==6
for r in rows:
    wd=P/'runs'/f"{r['version']}.{r['arm']}.{r['mode']}.{r['design']}"
    a=audit(wd/'epmapping_mapped.v',ROOT/'results_v20_three_parts_chain/inputs/asap7.genlib')
    assert abs(a['area']-r['area'])<.0001 and abs(a['delay']-r['delay'])<.001
    assert r['optimizer_seconds']<1000
    if r['arm']=='recheck':
        if r['mode']=='warm':
            assert r['counters']['profile']['builds']==0 and r['counters']['profile']['disk_hits']>0
        for key in ['cuts','builds','hits','replacements']:
            assert r['counters']['cofactor'][key]>=0
for name in ['epmapping.hpp','main.cpp','operator_policy.hpp','bounded_cache.hpp']:
    assert sha(P/'recheck'/name)==sha(ROOT/'epmapping'/name),name
assert sha(P/'recheck/epmapping_check')==sha(ROOT/'build/epmapping/epmapping_check')
env={k:v for k,v in os.environ.items() if not k.startswith(('EPMAPPING_','MAP_EGG_'))}
env['ABC']=str(ROOT/'results_v20_three_parts_chain/inputs/abc')
test=ROOT/'scripts/experiments/tests/test_area_delay_bound.py'
q=subprocess.run([sys.executable,str(test)],env=env,capture_output=True,text=True,timeout=90)
(P/'bounded_goal_validation.log').write_text(q.stdout+q.stderr)
assert q.returncode==0,q.stdout+q.stderr
flags=json.loads((ROOT/'research/usb_candidate_generation_20261015/validated_env.json').read_text())
flags.update(EPMAPPING_OPERATOR_POLICY='3',EPMAPPING_SYN_CACHE='65536',EPMAPPING_CHECKPOINT='1')
(P/'pilot_env.json').write_text(json.dumps(flags,indent=2)+'\n')
(P/'final_validation.json').write_text(json.dumps({'complete_runs':len(rows),'new_cold_warm_runs':6,'same_session_controls':8,'cec_all':True,'independent_ppa_reaudit_all':True,'same_original_initial_netlists':True,'same_full_search_final_netlists_new_runs':True,'same_full_cofactor_build_hit_cut_replacement_counts':True,'strictly_dominated_covers_reconcile_exactly':True,'default_bounded_goal_regression':'pass','native_sources_and_binary_match_frozen_experiment':True},indent=2)+'\n')
files={str(f.relative_to(P)):{'sha256':sha(f),'bytes':f.stat().st_size} for f in sorted(P.rglob('*')) if f.is_file() and f.name!='delivery_manifest.json' and '__pycache__' not in f.parts}
(P/'delivery_manifest.json').write_text(json.dumps({'files':files},indent=2)+'\n')
print(json.dumps({'files_hashed':len(files),'new_runs':6,'controls':8,'status':'pass'}))
