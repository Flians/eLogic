"""Audit frozen trigger pilots and compare immutable prior full/adaptive controls."""
import hashlib,json,re
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
P=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
rows=[]
for f in sorted((P/'runs').glob('*/result.json')):
    r=json.loads(f.read_text());m=json.loads((f.parent/'manifest.json').read_text())
    assert r['binary_sha256']==sha(Path(m['command'][0]))
    assert r['log_sha256']==sha(f.parent/'log')
    assert r['baseline_sha256']==sha(f.parent/'epmapping_baseline.v')
    assert r['netlist_sha256']==sha(f.parent/'epmapping_mapped.v')
    assert r['status']=='complete' and r['cec']==1
    assert r['delay']<=r['initial_delay']+.001
    assert m['env']['EPMAPPING_WINDOW_SYN']=='0'
    assert m['env']['EPMAPPING_POST_TIMEOUT']=='1000'
    for fn,h in m['input_sha256'].items():
        assert sha(ROOT/'results_v20_three_parts_chain/inputs'/fn)==h
    records=[dict(re.findall(r'(\w+)=([^\s]+)',s)) for s in (f.parent/'log').read_text().splitlines() if 'operator_policy source=' in s]
    for k in ['deferred','rechecked','dominated','skipped']:
        r[k]=sum(int(x.get(k,0)) for x in records)
    r['operator_totals']={}
    for record in records:
        dest=r['operator_totals'].setdefault(record['source'],{})
        for key in ['seconds','build_seconds','deferred','rechecked','dominated','build_requests','cache_hits','committed']:
            dest[key]=dest.get(key,0)+float(record.get(key,0))
    if r['arm']=='recheck':
        assert r['skipped']==0 and r['deferred']==r['rechecked']
        for name,version in [('full','anytime.cache64'),('adaptive','policy_v2.adaptive')]:
            b=json.loads((ROOT/'research/runtime_budget_20261015/runs'/f"{version}.{r['mode']}.{r['design']}"/'result.json').read_text())
            r['prior_'+name]={k:b[k] for k in ['area','delay','optimizer_seconds','netlist_sha256']}
            r['prior_'+name]['runtime_change_percent']=100*(r['optimizer_seconds']/b['optimizer_seconds']-1)
            r['prior_'+name]['same_netlist']=r['netlist_sha256']==b['netlist_sha256']
        assert r['prior_full']['same_netlist'], (r['design'],r['mode'],'full-search sequence changed')
        reference=json.loads((ROOT/'research/runtime_budget_20261015/runs'/f"anytime.cache64.{r['mode']}.{r['design']}"/'result.json').read_text())
        for key in ['cuts','builds','hits','replacements']:
            assert r['counters']['cofactor'][key]==reference['counters']['cofactor'][key], (r['design'],key)
        assert r['counters']['cofactor']['covers']+r['dominated']==reference['counters']['cofactor']['covers']
    rows.append(r)
(P/'verified_results.json').write_text(json.dumps(rows,indent=2)+'\n')
lines=['# Structural triggers and mandatory recheck: three-circuit pilot','',
'Original AIGs and initial mapped netlists are unchanged. Objective: minimize area under original D0; full library, six rounds, no window synthesis, post-mapping deadline 1000 s. All completed outputs independently audited for area/delay and CEC. Cold and warm use separate process-local native caches; only the persistent e-graph pool carries over.','',
'Runtime observations use one trial per arm/mode on a shared host. Archived controls are identified below; matching netlist hashes establish quality preservation on these inputs, not a universal proof of all future search trajectories.','',
'| Circuit | Cache | Prior adaptive A / D | New A / D | Prior adaptive s | New s | vs prior full time |',
'|---|---|---:|---:|---:|---:|---:|']
for r in rows:
    if r['arm']!='recheck':continue
    b=r['prior_adaptive']
    lines.append(f"| {r['design']} | {r['mode']} | {b['area']:.2f} / {b['delay']:.2f} | {r['area']:.2f} / {r['delay']:.2f} | {b['optimizer_seconds']:.3f} | {r['optimizer_seconds']:.3f} | {r['prior_full']['runtime_change_percent']:+.2f}% |")
lines+=['','Mode 3 refines diagnostic buckets using required-time slack, availability of an external opposite phase, and support/affine/unate/mixed Boolean classes, in addition to leaf count, cone size and care status. Features are memoized once per live cut. Existing cofactor support/difference signatures remain.','',
'A statistical zero-return decision is treated as a request for recheck, not evidence of dominance. Every such request is rebuilt in its original position before root commitment (no reordering and no permanent statistical skips). This restores candidate coverage; it does not save mapping work by itself.','',
'After mapping, the root-reachable non-inverter physical cell area is cached as a lower bound. Inverters, external retained cells and phase costs are omitted. For area-first cuts, only a bound more than 0.001 above a feasible incumbent area suppresses contextual materialization/estimation. Without a feasible incumbent the original cone area is used. Equal-area candidates remain eligible for timing and depth ties; delay-first cuts bypass this rule. General external gate hashing is absent in this netlist implementation.','',
'Fresh SOP/DSD and cofactor covers already receive live phase-aware pricing during finalization. Mode 3 reuses that price during same-cut comparison, before any netlist mutation, rather than running the identical symbolic materialization twice. Price failure rejects the candidate. The structure cache still never stores a context-dependent final price.','',
'| Circuit | Cache | Statistical deferrals | Rechecked | Strictly dominated evaluations | Permanent skips |','|---|---|---:|---:|---:|---:|']
for r in rows:
    if r['arm']=='recheck':lines.append(f"| {r['design']} | {r['mode']} | {r['deferred']} | {r['rechecked']} | {r['dominated']} | {r['skipped']} |")
lines+=['','Warm-run operator costs (new mode; generation plus contextual evaluation, not isolated causal contributions):','','| Circuit | Operator | Build s | Total s | Dominated evaluations |','|---|---|---:|---:|---:|']
for r in rows:
    if r['arm']=='recheck' and r['mode']=='warm':
        for name,c in r['operator_totals'].items():
            lines.append(f"| {r['design']} | {name} | {c['build_seconds']:.3f} | {c['seconds']:.3f} | {int(c['dominated'])} |")
controls=[r for r in rows if r['arm'] in ['full','adaptive']]
if controls:
    lines+=['','Same-session controls (sequential, private cold pools):','','| Circuit | Cache | Full s | Old adaptive s | New s | New vs full |','|---|---|---:|---:|---:|---:|']
    for r in rows:
        if r['arm']!='recheck':continue
        c={x['arm']:x for x in controls if x['design']==r['design'] and x['mode']==r['mode']}
        if len(c)!=2:continue
        assert c['full']['netlist_sha256']==r['netlist_sha256']
        lines.append(f"| {r['design']} | {r['mode']} | {c['full']['optimizer_seconds']:.3f} | {c['adaptive']['optimizer_seconds']:.3f} | {r['optimizer_seconds']:.3f} | {100*(r['optimizer_seconds']/c['full']['optimizer_seconds']-1):+.2f}% |")
lines+=['','This is an opt-in pilot (`EPMAPPING_OPERATOR_POLICY=3`); default remains 0. Paper and published full-campaign data are untouched. No claim of isolated causal area credit is made from operator counters.']
(P/'RESULTS.md').write_text('\n'.join(lines)+'\n')
print(json.dumps({'verified_runs':len(rows),'recheck_runs':sum(x['arm']=='recheck' for x in rows)}))
