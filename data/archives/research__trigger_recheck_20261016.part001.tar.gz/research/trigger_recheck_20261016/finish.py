from pathlib import Path
import json,subprocess,sys,time
P=Path(__file__).resolve().parent
while True:
    f=P/'verified_results.json'
    if f.exists() and len(json.loads(f.read_text()))==14:break
    time.sleep(5)
subprocess.run([sys.executable,str(P/'cleanup_build.py')],check=True)
subprocess.run([sys.executable,str(P/'finalize.py')],check=True)
