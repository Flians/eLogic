"""Queue same-host controls after the three-circuit experiment, never concurrently."""
from pathlib import Path
import subprocess,sys,time
P=Path(__file__).resolve().parent
while not (P/'results.json').exists():
    time.sleep(5)
subprocess.run([sys.executable,str(P/'run_pilot.py'),'--version','recheck','--arms','full','adaptive','--designs','usb_phy','arbiter'],check=True)
subprocess.run([sys.executable,str(P/'report.py')],check=True)
