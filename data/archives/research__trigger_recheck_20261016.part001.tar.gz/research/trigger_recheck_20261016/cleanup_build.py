"""Remove a dangling-else warning after timings, requiring identical machine code."""
import difflib,hashlib,shutil,subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];P=Path(__file__).resolve().parent
with (P/'cleanup_build.log').open('w') as log:
    subprocess.run(['cmake','--build','build','--target','epmapping_check','-j2'],cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,check=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(ROOT/'build/epmapping/epmapping_check')==sha(P/'recheck/epmapping_check'),'cleanup unexpectedly changed executable'
shutil.copy2(P/'recheck/epmapping.hpp',P/'recheck/epmapping.hpp.measured')
shutil.copy2(ROOT/'epmapping/epmapping.hpp',P/'recheck/epmapping.hpp')
a=(ROOT/'research/runtime_budget_20261015/policy_v2/epmapping.hpp').read_text().splitlines(keepends=True)
b=(ROOT/'epmapping/epmapping.hpp').read_text().splitlines(keepends=True)
(P/'epmapping.hpp.diff').write_text(''.join(difflib.unified_diff(a,b,fromfile='policy_v2/epmapping.hpp',tofile='recheck/epmapping.hpp')))
(P/'SOURCE_REPRODUCTION.txt').write_text('The initially measured header is preserved as recheck/epmapping.hpp.measured. The current header adds explicit braces to remove a dangling-else warning without changing line count or semantics. cleanup_build.py rebuilt from current sources and verified that the executable SHA256 is byte-identical to all measured recheck runs. recheck/epmapping.hpp contains the reproduced current source.\n')
print('Explicit braces remove warning; rebuilt executable is byte-identical to all measured runs. Original measured header retained.')
