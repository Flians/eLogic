"""Serial, frozen-input runtime/quality probes; published campaigns are untouched."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[2]
P = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'scripts/experiments'))
from audit_mapped_ppa import audit
from recover_checkpoint import recover

ap = argparse.ArgumentParser()
ap.add_argument('--designs', nargs='+', default=['usb_phy', 'arbiter', 'tv80'])
ap.add_argument('--arms', nargs='+', default=['recheck'])
ap.add_argument('--modes', nargs='+', default=['cold', 'warm'])
ap.add_argument('--rounds', type=int, default=6)
ap.add_argument('--version', default='recheck', choices=['recheck'])
a = ap.parse_args()
inputs = ROOT / 'results_v20_three_parts_chain/inputs'
reference = ROOT / 'results_v26_three_parts_cofactor_shared/cold/tab_main'
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
goal = json.loads((ROOT / 'research/usb_candidate_generation_20261015/validated_env.json').read_text())
source_binary = ROOT / 'build/epmapping/epmapping_check'
binary = P / a.version / 'epmapping_check'
if not binary.exists():
    binary.parent.mkdir(exist_ok=True)
    shutil.copy2(source_binary, binary)
    for f in ['epmapping.hpp', 'main.cpp', 'bounded_cache.hpp', 'operator_policy.hpp']:
        shutil.copy2(ROOT / 'epmapping' / f, binary.parent / f)

for design in a.designs:
    for arm in a.arms:
        assert arm in ['old', 'exact', 'pivot1', 'pivot2', 'pivot3', 'cache64', 'profile', 'adaptive', 'recheck', 'full'], arm
        for mode in a.modes:
            prefix = '' if a.version == 'candidate' else a.version + '.'
            if a.rounds!=6:prefix+=f'r{a.rounds}.'
            wd = P / 'runs' / f'{prefix}{arm}.{mode}.{design}'
            chosen_binary = ROOT / 'research/runtime_budget_20261015/anytime/epmapping_check' if arm == 'full' else ROOT / 'research/runtime_budget_20261015/policy_v2/epmapping_check' if arm == 'adaptive' else binary
            env = {k: v for k, v in os.environ.items() if not k.startswith(('EPMAPPING_', 'MAP_EGG_'))}
            env.update(goal)
            cache = P / 'cache' / f'{prefix}{arm}.{design}'
            env.update(ABC=str(inputs / 'abc'), RAYON_NUM_THREADS='1',
                       EPMAPPING_ROUNDS=str(a.rounds),
                       EPMAPPING_SUPER=str(inputs / 'database.super'),
                       EPMAPPING_CHECKPOINT='1', MAP_EGG_PROFILE_CACHE_DIR=str(cache),
                       EPMAPPING_COFAC_PIVOTS=arm[5:] if arm.startswith('pivot') else '0')
            if arm in ['cache64','full']: env['EPMAPPING_SYN_CACHE'] = '65536'
            if arm in ['profile','adaptive','recheck']:
                env.update(EPMAPPING_SYN_CACHE='65536',EPMAPPING_OPERATOR_POLICY='1' if arm=='profile' else '3' if arm=='recheck' else '2')
            if (wd / 'result.json').exists():
                prior = json.loads((wd / 'result.json').read_text())
                assert prior['binary_sha256'] == sha(chosen_binary)
                print(json.dumps(prior), flush=True)
                continue
            assert not wd.exists(), f'incomplete run requires inspection: {wd}'
            if mode == 'cold': assert not cache.exists(), 'cold cache must be empty'
            else: assert cache.exists(), 'warm requires the corresponding cold pool'
            wd.mkdir(parents=True)
            library, benchmark = inputs / 'asap7.genlib', inputs / 'benchmarks' / f'{design}.aig'
            cmd = [str(chosen_binary), str(library), str(benchmark), str(wd)]
            manifest = dict(command=cmd, env={k: v for k, v in env.items() if k.startswith(('EPMAPPING_', 'MAP_EGG_'))},
                            binary_sha256=sha(chosen_binary), input_sha256={str(x.relative_to(inputs)): sha(x)
                            for x in [library, benchmark, inputs / 'abc', inputs / 'database.super']})
            (wd / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
            with (wd / 'log').open('w') as log:
                q = subprocess.run(cmd, cwd=ROOT, env=env, stdout=log, stderr=subprocess.STDOUT, timeout=3600)
            text = (wd / 'log').read_text()
            assert (wd / 'epmapping_baseline.v').read_bytes() == (reference / f'ae.{design}' / 'epmapping_baseline.v').read_bytes()
            initial = audit(wd / 'epmapping_baseline.v', library)
            if q.returncode == 0:
                assert '[i] cec=1' in text and 'window_synth windows=0 applied=0' in text
                netlist = wd / 'epmapping_mapped.v'
                out = audit(netlist, library)
                status, selection = 'complete', 'optimized'
                seconds = float(re.search(r'epmapping timing .*optimizer=([\d.]+)', text)[1])
            else:
                assert q.returncode == -14, (q.returncode, text[-4000:])
                status, seconds = 'timeout', 1000.
                if (wd / 'epmapping_checkpoint.json').exists():
                    recovered = recover(wd, library, benchmark, inputs / 'abc', q.returncode)
                    selection = recovered['selection']
                    netlist = wd / recovered['checkpoint']['netlist']
                else:
                    selection = 'initial'
                    netlist = wd / 'epmapping_baseline.v'
                    # Old initial fallback needs its own equivalence certificate too.
                    proof = subprocess.run([str(inputs / 'abc'), '-c',
                        f"read_genlib '{library}'; read -m '{netlist}'; cec -n '{benchmark}'"],
                        capture_output=True, text=True, timeout=300)
                    (wd / 'initial_cec.log').write_text(proof.stdout + proof.stderr)
                    assert proof.returncode == 0 and 'Networks are equivalent' in proof.stdout
                out = audit(netlist, library)
            assert out['area'] <= initial['area'] + .0001 and out['delay'] <= initial['delay'] + .001
            counters = {}
            for label, pattern in [('cofactor', r'epmapping cofactor (.*)'), ('profile', r'egraph_profile (.*)')]:
                hit = re.search(pattern, text)
                if hit: counters[label] = {k: float(v) for k, v in re.findall(r'(\w+)=([\d.]+)', hit[1])}
            hit = re.search(r'cofactor_duplicates=(\d+)', text)
            if hit: counters['duplicates'] = int(hit[1])
            row = dict(version=a.version, rounds=a.rounds, design=design, arm=arm, mode=mode, status=status, selection=selection,
                       area=round(out['area'], 5), delay=round(out['delay'], 5),
                       initial_area=round(initial['area'], 5), initial_delay=round(initial['delay'], 5),
                       optimizer_seconds=seconds, counters=counters, cec=1,
                       binary_sha256=sha(chosen_binary), baseline_sha256=sha(wd / 'epmapping_baseline.v'),
                       netlist_sha256=sha(netlist), log_sha256=sha(wd / 'log'))
            (wd / 'result.json').write_text(json.dumps(row, indent=2) + '\n')
            print(json.dumps(row), flush=True)
rows = [json.loads(p.read_text()) for p in sorted((P / 'runs').glob('*/result.json'))]
(P / 'results.json').write_text(json.dumps(rows, indent=2) + '\n')
