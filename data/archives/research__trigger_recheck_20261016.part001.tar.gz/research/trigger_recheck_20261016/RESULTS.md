# Structural triggers and mandatory recheck: three-circuit pilot

Original AIGs and initial mapped netlists are unchanged. Objective: minimize area under original D0; full library, six rounds, no window synthesis, post-mapping deadline 1000 s. All completed outputs independently audited for area/delay and CEC. Cold and warm use separate process-local native caches; only the persistent e-graph pool carries over.

Runtime observations use one trial per arm/mode on a shared host. Archived controls are identified below; matching netlist hashes establish quality preservation on these inputs, not a universal proof of all future search trajectories.

| Circuit | Cache | Prior adaptive A / D | New A / D | Prior adaptive s | New s | vs prior full time |
|---|---|---:|---:|---:|---:|---:|
| arbiter | cold | 223.64 / 261.39 | 223.64 / 261.39 | 31.215 | 21.749 | -30.14% |
| tv80 | cold | 328.40 / 833.94 | 328.16 / 833.94 | 421.843 | 449.478 | -8.45% |
| usb_phy | cold | 21.38 / 158.68 | 21.38 / 158.68 | 11.028 | 11.844 | -3.65% |
| arbiter | warm | 223.64 / 261.39 | 223.64 / 261.39 | 32.247 | 20.730 | -32.45% |
| tv80 | warm | 328.40 / 833.94 | 328.16 / 833.94 | 330.814 | 359.433 | -9.47% |
| usb_phy | warm | 21.38 / 158.68 | 21.38 / 158.68 | 3.826 | 4.612 | -12.25% |

Mode 3 refines diagnostic buckets using required-time slack, availability of an external opposite phase, and support/affine/unate/mixed Boolean classes, in addition to leaf count, cone size and care status. Features are memoized once per live cut. Existing cofactor support/difference signatures remain.

A statistical zero-return decision is treated as a request for recheck, not evidence of dominance. Every such request is rebuilt in its original position before root commitment (no reordering and no permanent statistical skips). This restores candidate coverage; it does not save mapping work by itself.

After mapping, the root-reachable non-inverter physical cell area is cached as a lower bound. Inverters, external retained cells and phase costs are omitted. For area-first cuts, only a bound more than 0.001 above a feasible incumbent area suppresses contextual materialization/estimation. Without a feasible incumbent the original cone area is used. Equal-area candidates remain eligible for timing and depth ties; delay-first cuts bypass this rule. General external gate hashing is absent in this netlist implementation.

Fresh SOP/DSD and cofactor covers already receive live phase-aware pricing during finalization. Mode 3 reuses that price during same-cut comparison, before any netlist mutation, rather than running the identical symbolic materialization twice. Price failure rejects the candidate. The structure cache still never stores a context-dependent final price.

| Circuit | Cache | Statistical deferrals | Rechecked | Strictly dominated evaluations | Permanent skips |
|---|---|---:|---:|---:|---:|
| arbiter | cold | 1366 | 1366 | 852737 | 0 |
| tv80 | cold | 275282 | 275282 | 830336 | 0 |
| usb_phy | cold | 2072 | 2072 | 13726 | 0 |
| arbiter | warm | 1366 | 1366 | 852737 | 0 |
| tv80 | warm | 275215 | 275215 | 830336 | 0 |
| usb_phy | warm | 2072 | 2072 | 13726 | 0 |

Warm-run operator costs (new mode; generation plus contextual evaluation, not isolated causal contributions):

| Circuit | Operator | Build s | Total s | Dominated evaluations |
|---|---|---:|---:|---:|
| arbiter | SOP_DSD | 0.104 | 5.114 | 0 |
| arbiter | Shannon | 0.372 | 0.742 | 357025 |
| arbiter | Davio_pos | 0.639 | 0.862 | 263081 |
| arbiter | Davio_neg | 0.658 | 0.889 | 232631 |
| arbiter | egraph | 0.000 | 0.792 | 0 |
| tv80 | SOP_DSD | 4.167 | 14.788 | 0 |
| tv80 | Shannon | 69.142 | 72.735 | 353499 |
| tv80 | Davio_pos | 100.018 | 103.019 | 249362 |
| tv80 | Davio_neg | 102.708 | 105.694 | 227475 |
| tv80 | egraph | 0.000 | 2.718 | 0 |
| usb_phy | SOP_DSD | 0.222 | 0.349 | 0 |
| usb_phy | Shannon | 0.804 | 0.854 | 6198 |
| usb_phy | Davio_pos | 1.205 | 1.245 | 3642 |
| usb_phy | Davio_neg | 1.358 | 1.397 | 3886 |
| usb_phy | egraph | 0.000 | 0.089 | 0 |

Same-session controls (sequential, private cold pools):

| Circuit | Cache | Full s | Old adaptive s | New s | New vs full |
|---|---|---:|---:|---:|---:|
| arbiter | cold | 32.216 | 31.011 | 21.749 | -32.49% |
| usb_phy | cold | 11.905 | 10.322 | 11.844 | -0.51% |
| arbiter | warm | 31.649 | 30.371 | 20.730 | -34.50% |
| usb_phy | warm | 4.801 | 3.484 | 4.612 | -3.94% |

This is an opt-in pilot (`EPMAPPING_OPERATOR_POLICY=3`); default remains 0. Paper and published full-campaign data are untouched. No claim of isolated causal area credit is made from operator counters.
