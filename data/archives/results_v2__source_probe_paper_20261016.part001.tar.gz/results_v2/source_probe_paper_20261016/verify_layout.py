from pathlib import Path
import re,hashlib,json,shutil
from PIL import Image,ImageChops
R=Path('/home/flynn/workplace/MIGBalance');O=Path(__file__).parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();s=(R/'epmapping_paper/DAC-eGraphMap-draft/main.tex').read_text();old=(O/'before.tex').read_text();pat=r'\\begin\{table\*\}.*?\\end\{table\*\}';a=re.findall(pat,s,re.S);b=re.findall(pat,old,re.S);assert len(a)==len(b)==4 and a==b
pages=[p for p in (O/'paper.txt').read_text().split('\f') if p.strip()];assert len(pages)==7;headings=[i+1 for i,p in enumerate(pages) if any(re.sub(r'\s+','',line).upper()=='REFERENCES' for line in p.splitlines())];assert headings==[7]
assert s.split('\\begin{document}')[0]==old.split('\\begin{document}')[0]
log=(O/'main.log').read_text();assert 'Overfull' not in log and 'LaTeX Warning:' not in log
unchanged=[];changed=[]
for i in range(1,8):
 same=ImageChops.difference(Image.open(O/f'page-{i}.png'),Image.open(R/f'results_v2/guarded_joint_paper_20261016/page-{i}.png')).getbbox() is None
 (unchanged if same else changed).append(i)
assert changed==[6];assert json.loads((R/'results_v2/guarded_joint_paper_20261016/paper_qa.json').read_text())['visually_checked_pages']==list(range(1,8))
for dest in [R/'epmapping_paper/DAC-eGraphMap-draft/main.pdf',R/'output/pdf/DAC-eGraphMap-draft.pdf']:shutil.copy2(O/'main.pdf',dest)
for suffix in ['aux','out','log']:shutil.copy2(O/('main.'+suffix),R/'epmapping_paper/DAC-eGraphMap-draft'/('main.'+suffix))
result=dict(body_pages=6,reference_pages=1,reference_heading_pages=headings,primary_tables_byte_identical=True,table_hashes=[hashlib.sha256(x.encode()).hexdigest() for x in a],preamble_font_and_margins_unchanged=True,overfull=False,latex_warning=False,underfull_lines=[l for l in log.splitlines() if 'Underfull' in l],visual_check_pending=False,visually_rechecked_changed_pages=[6],pixel_identical_to_previous_all7_visual_qa=unchanged,visual_findings='Changed page6 visually inspected: readable standard text/tables, no clipping, overlap or broken layout. Other6pages pixel-identical to previously inspected pages. Rejected8page version retained; prose shortened without font/margin changes.',source_sha256=sha(R/'epmapping_paper/DAC-eGraphMap-draft/main.tex'),pdf_sha256=sha(O/'main.pdf'),page_sha256={f'page-{i}.png':sha(O/f'page-{i}.png') for i in range(1,8)},production_promoted=False,published_pdf_sha256=sha(R/'output/pdf/DAC-eGraphMap-draft.pdf'))
(O/'paper_qa.json').write_text(json.dumps(result,indent=2)+'\n');print('6+1, tables byte-identical, page6 visually reviewed;other6pixel-identical;published')
