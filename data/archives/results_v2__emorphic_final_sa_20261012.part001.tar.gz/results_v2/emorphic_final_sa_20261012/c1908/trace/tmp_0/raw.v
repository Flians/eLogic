// Benchmark "/tmp/" written by ABC on Mon Oct 12 14:41:02 2026

module \/tmp/  ( 
    p6, p16, p1, p17, p10, p14, p2, p15, p5, p32, p26, p3, p9, p0, p8, p28,
    p20, p12, p29, p30, p23, p18, p22, p7, p24, p27, p21, p19, p11, p4,
    p13, p31, p25,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24  );
  input  p6, p16, p1, p17, p10, p14, p2, p15, p5, p32, p26, p3, p9, p0,
    p8, p28, p20, p12, p29, p30, p23, p18, p22, p7, p24, p27, p21, p19,
    p11, p4, p13, p31, p25;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24;
  wire new_n59_, new_n60_, new_n61_, new_n62_, new_n63_, new_n64_, new_n65_,
    new_n66_, new_n67_, new_n68_, new_n69_, new_n70_, new_n71_, new_n72_,
    new_n73_, new_n74_, new_n75_, new_n76_, new_n77_, new_n78_, new_n79_,
    new_n80_, new_n81_, new_n82_, new_n83_, new_n84_, new_n85_, new_n86_,
    new_n87_, new_n88_, new_n89_, new_n90_, new_n91_, new_n92_, new_n93_,
    new_n94_, new_n95_, new_n96_, new_n97_, new_n98_, new_n99_, new_n100_,
    new_n101_, new_n102_, new_n103_, new_n104_, new_n105_, new_n106_,
    new_n107_, new_n108_, new_n109_, new_n110_, new_n111_, new_n112_,
    new_n113_, new_n114_, new_n115_, new_n116_, new_n117_, new_n118_,
    new_n119_, new_n120_, new_n121_, new_n122_, new_n123_, new_n124_,
    new_n125_, new_n126_, new_n127_, new_n128_, new_n129_, new_n130_,
    new_n131_, new_n132_, new_n133_, new_n134_, new_n135_, new_n136_,
    new_n137_, new_n138_, new_n139_, new_n140_, new_n141_, new_n142_,
    new_n143_, new_n144_, new_n145_, new_n146_, new_n147_, new_n148_,
    new_n149_, new_n150_, new_n151_, new_n152_, new_n153_, new_n154_,
    new_n155_, new_n156_, new_n157_, new_n158_, new_n159_, new_n160_,
    new_n161_, new_n162_, new_n163_, new_n164_, new_n165_, new_n166_,
    new_n167_, new_n168_, new_n169_, new_n170_, new_n171_, new_n172_,
    new_n173_, new_n174_, new_n175_, new_n176_, new_n177_, new_n178_,
    new_n179_, new_n180_, new_n181_, new_n182_, new_n183_, new_n184_,
    new_n185_, new_n186_, new_n187_, new_n188_, new_n189_, new_n190_,
    new_n191_, new_n192_, new_n193_, new_n194_, new_n195_, new_n196_,
    new_n197_, new_n198_, new_n199_, new_n200_, new_n201_, new_n202_,
    new_n203_, new_n204_, new_n205_, new_n206_, new_n207_, new_n208_,
    new_n209_, new_n210_, new_n211_, new_n212_, new_n213_, new_n214_,
    new_n215_, new_n216_, new_n217_, new_n218_, new_n219_, new_n220_,
    new_n221_, new_n222_, new_n223_, new_n224_, new_n225_, new_n226_,
    new_n227_, new_n228_, new_n229_, new_n230_, new_n231_, new_n232_,
    new_n233_, new_n234_, new_n235_, new_n236_, new_n237_, new_n238_,
    new_n239_, new_n240_, new_n241_, new_n242_, new_n243_, new_n244_,
    new_n245_, new_n246_, new_n247_, new_n248_, new_n249_, new_n250_,
    new_n251_, new_n252_, new_n253_, new_n254_, new_n255_, new_n256_,
    new_n257_, new_n258_, new_n259_, new_n260_, new_n261_, new_n262_,
    new_n263_, new_n264_, new_n265_, new_n266_, new_n267_, new_n268_,
    new_n269_, new_n270_, new_n271_, new_n272_, new_n273_, new_n274_,
    new_n275_, new_n276_, new_n277_, new_n278_, new_n279_, new_n281_,
    new_n282_, new_n283_, new_n284_, new_n285_, new_n286_, new_n287_,
    new_n288_, new_n289_, new_n290_, new_n291_, new_n292_, new_n294_,
    new_n295_, new_n297_, new_n298_, new_n299_, new_n300_, new_n301_,
    new_n303_, new_n304_, new_n306_, new_n307_, new_n309_, new_n310_,
    new_n311_, new_n312_, new_n314_, new_n315_, new_n316_, new_n318_,
    new_n319_, new_n321_, new_n322_, new_n323_, new_n324_, new_n325_,
    new_n327_, new_n328_, new_n330_, new_n333_, new_n335_, new_n336_,
    new_n337_, new_n338_, new_n340_, new_n341_, new_n342_, new_n344_,
    new_n345_, new_n346_, new_n347_, new_n348_, new_n349_, new_n350_,
    new_n351_, new_n352_, new_n353_, new_n354_, new_n355_, new_n356_,
    new_n357_, new_n358_, new_n359_, new_n360_, new_n361_, new_n362_,
    new_n363_, new_n365_, new_n366_, new_n367_, new_n368_, new_n369_,
    new_n370_, new_n371_, new_n372_, new_n373_, new_n374_, new_n375_,
    new_n376_, new_n378_, new_n379_, new_n380_, new_n381_, new_n382_,
    new_n383_, new_n385_, new_n386_, new_n388_, new_n389_, new_n390_,
    new_n391_, new_n392_, new_n394_, new_n395_, new_n396_, new_n397_,
    new_n399_, new_n400_, new_n401_, new_n402_, new_n403_, new_n405_,
    new_n406_, new_n407_, new_n408_, new_n409_, new_n410_, new_n412_;
  NOR2x1_ASAP7_75t_R  g000(.A(p2), .B(p0), .Y(new_n59_));
  INVx1_ASAP7_75t_R   g001(.A(new_n59_), .Y(new_n60_));
  AND3x1_ASAP7_75t_R  g002(.A(new_n60_), .B(p16), .C(p26), .Y(new_n61_));
  INVx1_ASAP7_75t_R   g003(.A(p25), .Y(new_n62_));
  NOR2x1_ASAP7_75t_R  g004(.A(p19), .B(new_n62_), .Y(new_n63_));
  INVx1_ASAP7_75t_R   g005(.A(p19), .Y(new_n64_));
  NOR2x1_ASAP7_75t_R  g006(.A(p25), .B(new_n64_), .Y(new_n65_));
  OAI21x1_ASAP7_75t_R g007(.A1(new_n63_), .A2(new_n65_), .B(p7), .Y(new_n66_));
  NAND2x1_ASAP7_75t_R g008(.A(p25), .B(new_n64_), .Y(new_n67_));
  NAND2x1_ASAP7_75t_R g009(.A(p19), .B(new_n62_), .Y(new_n68_));
  INVx1_ASAP7_75t_R   g010(.A(p7), .Y(new_n69_));
  NAND3x1_ASAP7_75t_R g011(.A(new_n67_), .B(new_n68_), .C(new_n69_), .Y(new_n70_));
  AOI21x1_ASAP7_75t_R g012(.A1(new_n66_), .A2(new_n70_), .B(p22), .Y(new_n71_));
  OAI21x1_ASAP7_75t_R g013(.A1(p25), .A2(new_n64_), .B(new_n69_), .Y(new_n72_));
  NOR2x1_ASAP7_75t_R  g014(.A(new_n63_), .B(new_n72_), .Y(new_n73_));
  AOI21x1_ASAP7_75t_R g015(.A1(new_n67_), .A2(new_n68_), .B(new_n69_), .Y(new_n74_));
  INVx1_ASAP7_75t_R   g016(.A(p22), .Y(new_n75_));
  NOR3x1_ASAP7_75t_R  g017(.A(new_n73_), .B(new_n74_), .C(new_n75_), .Y(new_n76_));
  XNOR2x2_ASAP7_75t_R g018(.A(p6), .B(p21), .Y(new_n77_));
  XOR2x2_ASAP7_75t_R  g019(.A(p5), .B(p18), .Y(new_n78_));
  XOR2x2_ASAP7_75t_R  g020(.A(new_n77_), .B(new_n78_), .Y(new_n79_));
  OAI21x1_ASAP7_75t_R g021(.A1(new_n71_), .A2(new_n76_), .B(new_n79_), .Y(new_n80_));
  NAND3x1_ASAP7_75t_R g022(.A(new_n70_), .B(new_n66_), .C(p22), .Y(new_n81_));
  NOR2x1_ASAP7_75t_R  g023(.A(new_n71_), .B(new_n79_), .Y(new_n82_));
  INVx1_ASAP7_75t_R   g024(.A(p1), .Y(new_n83_));
  NAND3x1_ASAP7_75t_R g025(.A(new_n83_), .B(p30), .C(p13), .Y(new_n84_));
  INVx1_ASAP7_75t_R   g026(.A(p30), .Y(new_n85_));
  INVx1_ASAP7_75t_R   g027(.A(p13), .Y(new_n86_));
  OAI21x1_ASAP7_75t_R g028(.A1(p1), .A2(new_n85_), .B(new_n86_), .Y(new_n87_));
  NAND2x1_ASAP7_75t_R g029(.A(new_n84_), .B(new_n87_), .Y(new_n88_));
  AND2x2_ASAP7_75t_R  g030(.A(p9), .B(p8), .Y(new_n89_));
  INVx1_ASAP7_75t_R   g031(.A(p15), .Y(new_n90_));
  NOR2x1_ASAP7_75t_R  g032(.A(p9), .B(p8), .Y(new_n91_));
  OR3x1_ASAP7_75t_R   g033(.A(new_n89_), .B(new_n90_), .C(new_n91_), .Y(new_n92_));
  OAI21x1_ASAP7_75t_R g034(.A1(new_n91_), .A2(new_n89_), .B(new_n90_), .Y(new_n93_));
  NAND3x1_ASAP7_75t_R g035(.A(new_n88_), .B(new_n92_), .C(new_n93_), .Y(new_n94_));
  NAND2x1_ASAP7_75t_R g036(.A(new_n83_), .B(new_n86_), .Y(new_n95_));
  OAI21x1_ASAP7_75t_R g037(.A1(p1), .A2(new_n85_), .B(p13), .Y(new_n96_));
  OAI21x1_ASAP7_75t_R g038(.A1(new_n85_), .A2(new_n95_), .B(new_n96_), .Y(new_n97_));
  OAI21x1_ASAP7_75t_R g039(.A1(new_n91_), .A2(new_n89_), .B(p15), .Y(new_n98_));
  OR3x1_ASAP7_75t_R   g040(.A(new_n89_), .B(p15), .C(new_n91_), .Y(new_n99_));
  NAND3x1_ASAP7_75t_R g041(.A(new_n97_), .B(new_n98_), .C(new_n99_), .Y(new_n100_));
  AOI21x1_ASAP7_75t_R g042(.A1(new_n94_), .A2(new_n100_), .B(p2), .Y(new_n101_));
  AOI21x1_ASAP7_75t_R g043(.A1(new_n81_), .A2(new_n82_), .B(new_n101_), .Y(new_n102_));
  AOI21x1_ASAP7_75t_R g044(.A1(p6), .A2(p21), .B(p18), .Y(new_n103_));
  OAI21x1_ASAP7_75t_R g045(.A1(p6), .A2(p21), .B(new_n103_), .Y(new_n104_));
  NOR2x1_ASAP7_75t_R  g046(.A(p6), .B(p21), .Y(new_n105_));
  AND2x2_ASAP7_75t_R  g047(.A(p6), .B(p21), .Y(new_n106_));
  OAI21x1_ASAP7_75t_R g048(.A1(new_n105_), .A2(new_n106_), .B(p18), .Y(new_n107_));
  XNOR2x2_ASAP7_75t_R g049(.A(p5), .B(p22), .Y(new_n108_));
  AOI21x1_ASAP7_75t_R g050(.A1(new_n104_), .A2(new_n107_), .B(new_n108_), .Y(new_n109_));
  AND3x1_ASAP7_75t_R  g051(.A(new_n107_), .B(new_n104_), .C(new_n108_), .Y(new_n110_));
  NAND2x1_ASAP7_75t_R g052(.A(new_n66_), .B(new_n70_), .Y(new_n111_));
  OAI21x1_ASAP7_75t_R g053(.A1(new_n109_), .A2(new_n110_), .B(new_n111_), .Y(new_n112_));
  NOR2x1_ASAP7_75t_R  g054(.A(new_n74_), .B(new_n73_), .Y(new_n113_));
  AO21x1_ASAP7_75t_R  g055(.A1(new_n104_), .A2(new_n107_), .B(new_n108_), .Y(new_n114_));
  NAND3x1_ASAP7_75t_R g056(.A(new_n107_), .B(new_n104_), .C(new_n108_), .Y(new_n115_));
  NAND3x1_ASAP7_75t_R g057(.A(new_n113_), .B(new_n114_), .C(new_n115_), .Y(new_n116_));
  AOI21x1_ASAP7_75t_R g058(.A1(new_n98_), .A2(new_n99_), .B(new_n97_), .Y(new_n117_));
  AOI21x1_ASAP7_75t_R g059(.A1(new_n93_), .A2(new_n92_), .B(new_n88_), .Y(new_n118_));
  NOR3x1_ASAP7_75t_R  g060(.A(new_n117_), .B(new_n118_), .C(p2), .Y(new_n119_));
  AOI21x1_ASAP7_75t_R g061(.A1(new_n112_), .A2(new_n116_), .B(new_n119_), .Y(new_n120_));
  AOI21x1_ASAP7_75t_R g062(.A1(new_n80_), .A2(new_n102_), .B(new_n120_), .Y(new_n121_));
  NAND2x1_ASAP7_75t_R g063(.A(new_n61_), .B(new_n121_), .Y(new_n122_));
  AOI21x1_ASAP7_75t_R g064(.A1(new_n115_), .A2(new_n114_), .B(new_n113_), .Y(new_n123_));
  AND3x1_ASAP7_75t_R  g065(.A(new_n113_), .B(new_n114_), .C(new_n115_), .Y(new_n124_));
  OR3x1_ASAP7_75t_R   g066(.A(new_n117_), .B(new_n118_), .C(p2), .Y(new_n125_));
  OAI21x1_ASAP7_75t_R g067(.A1(new_n123_), .A2(new_n124_), .B(new_n125_), .Y(new_n126_));
  XOR2x2_ASAP7_75t_R  g068(.A(p6), .B(p21), .Y(new_n127_));
  XOR2x2_ASAP7_75t_R  g069(.A(new_n127_), .B(new_n78_), .Y(new_n128_));
  OAI21x1_ASAP7_75t_R g070(.A1(new_n74_), .A2(new_n73_), .B(new_n75_), .Y(new_n129_));
  NAND3x1_ASAP7_75t_R g071(.A(new_n128_), .B(new_n81_), .C(new_n129_), .Y(new_n130_));
  INVx1_ASAP7_75t_R   g072(.A(p2), .Y(new_n131_));
  OAI21x1_ASAP7_75t_R g073(.A1(new_n118_), .A2(new_n117_), .B(new_n131_), .Y(new_n132_));
  NAND3x1_ASAP7_75t_R g074(.A(new_n130_), .B(new_n80_), .C(new_n132_), .Y(new_n133_));
  INVx1_ASAP7_75t_R   g075(.A(p26), .Y(new_n134_));
  AND3x1_ASAP7_75t_R  g076(.A(new_n60_), .B(p16), .C(new_n134_), .Y(new_n135_));
  INVx1_ASAP7_75t_R   g077(.A(new_n135_), .Y(new_n136_));
  AO21x1_ASAP7_75t_R  g078(.A1(new_n126_), .A2(new_n133_), .B(new_n136_), .Y(new_n137_));
  OA21x2_ASAP7_75t_R  g079(.A1(p2), .A2(p32), .B(p11), .Y(new_n138_));
  XOR2x2_ASAP7_75t_R  g080(.A(p14), .B(p13), .Y(new_n139_));
  NAND2x1_ASAP7_75t_R g081(.A(p15), .B(new_n139_), .Y(new_n140_));
  NAND2x1_ASAP7_75t_R g082(.A(p14), .B(p13), .Y(new_n141_));
  INVx1_ASAP7_75t_R   g083(.A(p14), .Y(new_n142_));
  NAND2x1_ASAP7_75t_R g084(.A(new_n142_), .B(new_n86_), .Y(new_n143_));
  AO21x1_ASAP7_75t_R  g085(.A1(new_n141_), .A2(new_n143_), .B(p15), .Y(new_n144_));
  XOR2x2_ASAP7_75t_R  g086(.A(p9), .B(p22), .Y(new_n145_));
  AO21x1_ASAP7_75t_R  g087(.A1(new_n140_), .A2(new_n144_), .B(new_n145_), .Y(new_n146_));
  AND3x1_ASAP7_75t_R  g088(.A(new_n143_), .B(p15), .C(new_n141_), .Y(new_n147_));
  NOR2x1_ASAP7_75t_R  g089(.A(p15), .B(new_n139_), .Y(new_n148_));
  INVx1_ASAP7_75t_R   g090(.A(new_n145_), .Y(new_n149_));
  OR3x1_ASAP7_75t_R   g091(.A(new_n147_), .B(new_n148_), .C(new_n149_), .Y(new_n150_));
  XOR2x2_ASAP7_75t_R  g092(.A(p24), .B(p21), .Y(new_n151_));
  NOR2x1_ASAP7_75t_R  g093(.A(p1), .B(p32), .Y(new_n152_));
  NAND2x1_ASAP7_75t_R g094(.A(p23), .B(new_n152_), .Y(new_n153_));
  XOR2x2_ASAP7_75t_R  g095(.A(new_n151_), .B(new_n153_), .Y(new_n154_));
  AO21x1_ASAP7_75t_R  g096(.A1(new_n146_), .A2(new_n150_), .B(new_n154_), .Y(new_n155_));
  NAND3x1_ASAP7_75t_R g097(.A(new_n150_), .B(new_n146_), .C(new_n154_), .Y(new_n156_));
  NAND3x1_ASAP7_75t_R g098(.A(new_n155_), .B(new_n131_), .C(new_n156_), .Y(new_n157_));
  NOR2x1_ASAP7_75t_R  g099(.A(p2), .B(new_n138_), .Y(new_n158_));
  AND3x1_ASAP7_75t_R  g100(.A(new_n155_), .B(new_n156_), .C(new_n158_), .Y(new_n159_));
  AOI21x1_ASAP7_75t_R g101(.A1(new_n138_), .A2(new_n157_), .B(new_n159_), .Y(new_n160_));
  NOR2x1_ASAP7_75t_R  g102(.A(p17), .B(p10), .Y(new_n161_));
  AND2x2_ASAP7_75t_R  g103(.A(p17), .B(p10), .Y(new_n162_));
  OAI21x1_ASAP7_75t_R g104(.A1(new_n161_), .A2(new_n162_), .B(p24), .Y(new_n163_));
  OR3x1_ASAP7_75t_R   g105(.A(new_n162_), .B(p24), .C(new_n161_), .Y(new_n164_));
  NAND2x1_ASAP7_75t_R g106(.A(new_n163_), .B(new_n164_), .Y(new_n165_));
  NAND2x1_ASAP7_75t_R g107(.A(new_n98_), .B(new_n99_), .Y(new_n166_));
  NAND2x1_ASAP7_75t_R g108(.A(new_n165_), .B(new_n166_), .Y(new_n167_));
  NAND2x1_ASAP7_75t_R g109(.A(new_n93_), .B(new_n92_), .Y(new_n168_));
  AND2x2_ASAP7_75t_R  g110(.A(new_n163_), .B(new_n164_), .Y(new_n169_));
  NAND2x1_ASAP7_75t_R g111(.A(new_n168_), .B(new_n169_), .Y(new_n170_));
  INVx1_ASAP7_75t_R   g112(.A(new_n104_), .Y(new_n171_));
  INVx1_ASAP7_75t_R   g113(.A(p18), .Y(new_n172_));
  NOR2x1_ASAP7_75t_R  g114(.A(new_n172_), .B(new_n127_), .Y(new_n173_));
  NOR2x1_ASAP7_75t_R  g115(.A(p1), .B(p0), .Y(new_n174_));
  NOR2x1_ASAP7_75t_R  g116(.A(p25), .B(new_n134_), .Y(new_n175_));
  AOI21x1_ASAP7_75t_R g117(.A1(p26), .A2(new_n174_), .B(new_n62_), .Y(new_n176_));
  AOI21x1_ASAP7_75t_R g118(.A1(new_n174_), .A2(new_n175_), .B(new_n176_), .Y(new_n177_));
  OAI21x1_ASAP7_75t_R g119(.A1(new_n171_), .A2(new_n173_), .B(new_n177_), .Y(new_n178_));
  NAND3x1_ASAP7_75t_R g120(.A(new_n174_), .B(p26), .C(new_n62_), .Y(new_n179_));
  AO21x1_ASAP7_75t_R  g121(.A1(p26), .A2(new_n174_), .B(new_n62_), .Y(new_n180_));
  NAND2x1_ASAP7_75t_R g122(.A(new_n179_), .B(new_n180_), .Y(new_n181_));
  NAND3x1_ASAP7_75t_R g123(.A(new_n181_), .B(new_n107_), .C(new_n104_), .Y(new_n182_));
  NAND2x1_ASAP7_75t_R g124(.A(new_n178_), .B(new_n182_), .Y(new_n183_));
  AOI21x1_ASAP7_75t_R g125(.A1(new_n167_), .A2(new_n170_), .B(new_n183_), .Y(new_n184_));
  NAND2x1_ASAP7_75t_R g126(.A(new_n168_), .B(new_n165_), .Y(new_n185_));
  NAND2x1_ASAP7_75t_R g127(.A(new_n166_), .B(new_n169_), .Y(new_n186_));
  AOI21x1_ASAP7_75t_R g128(.A1(new_n107_), .A2(new_n104_), .B(new_n181_), .Y(new_n187_));
  NOR3x1_ASAP7_75t_R  g129(.A(new_n177_), .B(new_n173_), .C(new_n171_), .Y(new_n188_));
  NOR2x1_ASAP7_75t_R  g130(.A(new_n187_), .B(new_n188_), .Y(new_n189_));
  AOI21x1_ASAP7_75t_R g131(.A1(new_n185_), .A2(new_n186_), .B(new_n189_), .Y(new_n190_));
  INVx1_ASAP7_75t_R   g132(.A(p27), .Y(new_n191_));
  NOR2x1_ASAP7_75t_R  g133(.A(p2), .B(new_n191_), .Y(new_n192_));
  OAI21x1_ASAP7_75t_R g134(.A1(new_n184_), .A2(new_n190_), .B(new_n192_), .Y(new_n193_));
  AND3x1_ASAP7_75t_R  g135(.A(new_n165_), .B(new_n92_), .C(new_n93_), .Y(new_n194_));
  NOR2x1_ASAP7_75t_R  g136(.A(new_n165_), .B(new_n166_), .Y(new_n195_));
  OAI21x1_ASAP7_75t_R g137(.A1(new_n194_), .A2(new_n195_), .B(new_n189_), .Y(new_n196_));
  AND3x1_ASAP7_75t_R  g138(.A(new_n165_), .B(new_n98_), .C(new_n99_), .Y(new_n197_));
  NOR2x1_ASAP7_75t_R  g139(.A(new_n168_), .B(new_n165_), .Y(new_n198_));
  OAI21x1_ASAP7_75t_R g140(.A1(new_n197_), .A2(new_n198_), .B(new_n183_), .Y(new_n199_));
  NAND3x1_ASAP7_75t_R g141(.A(new_n196_), .B(new_n199_), .C(new_n191_), .Y(new_n200_));
  NAND2x1_ASAP7_75t_R g142(.A(p2), .B(new_n191_), .Y(new_n201_));
  NAND3x1_ASAP7_75t_R g143(.A(new_n193_), .B(new_n200_), .C(new_n201_), .Y(new_n202_));
  NAND2x1_ASAP7_75t_R g144(.A(new_n160_), .B(new_n202_), .Y(new_n203_));
  AO21x1_ASAP7_75t_R  g145(.A1(new_n122_), .A2(new_n137_), .B(new_n203_), .Y(new_n204_));
  XOR2x2_ASAP7_75t_R  g146(.A(new_n78_), .B(p19), .Y(new_n205_));
  NAND2x1_ASAP7_75t_R g147(.A(new_n140_), .B(new_n144_), .Y(new_n206_));
  NAND2x1_ASAP7_75t_R g148(.A(new_n205_), .B(new_n206_), .Y(new_n207_));
  XOR2x2_ASAP7_75t_R  g149(.A(new_n78_), .B(new_n64_), .Y(new_n208_));
  NOR2x1_ASAP7_75t_R  g150(.A(new_n148_), .B(new_n147_), .Y(new_n209_));
  NAND2x1_ASAP7_75t_R g151(.A(new_n208_), .B(new_n209_), .Y(new_n210_));
  XOR2x2_ASAP7_75t_R  g152(.A(p17), .B(p8), .Y(new_n211_));
  NAND2x1_ASAP7_75t_R g153(.A(p16), .B(new_n174_), .Y(new_n212_));
  XOR2x2_ASAP7_75t_R  g154(.A(new_n211_), .B(new_n212_), .Y(new_n213_));
  INVx1_ASAP7_75t_R   g155(.A(new_n213_), .Y(new_n214_));
  AO21x1_ASAP7_75t_R  g156(.A1(new_n207_), .A2(new_n210_), .B(new_n214_), .Y(new_n215_));
  NOR2x1_ASAP7_75t_R  g157(.A(p2), .B(new_n215_), .Y(new_n216_));
  NAND2x1_ASAP7_75t_R g158(.A(new_n208_), .B(new_n206_), .Y(new_n217_));
  NAND2x1_ASAP7_75t_R g159(.A(new_n205_), .B(new_n209_), .Y(new_n218_));
  AO21x1_ASAP7_75t_R  g160(.A1(new_n217_), .A2(new_n218_), .B(new_n213_), .Y(new_n219_));
  INVx1_ASAP7_75t_R   g161(.A(p20), .Y(new_n220_));
  OAI21x1_ASAP7_75t_R g162(.A1(p2), .A2(new_n219_), .B(new_n220_), .Y(new_n221_));
  NOR2x1_ASAP7_75t_R  g163(.A(p2), .B(new_n220_), .Y(new_n222_));
  INVx1_ASAP7_75t_R   g164(.A(new_n222_), .Y(new_n223_));
  AO21x1_ASAP7_75t_R  g165(.A1(new_n215_), .A2(new_n219_), .B(new_n223_), .Y(new_n224_));
  OAI21x1_ASAP7_75t_R g166(.A1(new_n216_), .A2(new_n221_), .B(new_n224_), .Y(new_n225_));
  XOR2x2_ASAP7_75t_R  g167(.A(p5), .B(p7), .Y(new_n226_));
  XOR2x2_ASAP7_75t_R  g168(.A(new_n226_), .B(p6), .Y(new_n227_));
  NOR2x1_ASAP7_75t_R  g169(.A(new_n91_), .B(new_n89_), .Y(new_n228_));
  INVx1_ASAP7_75t_R   g170(.A(p10), .Y(new_n229_));
  XOR2x2_ASAP7_75t_R  g171(.A(new_n228_), .B(new_n229_), .Y(new_n230_));
  NAND2x1_ASAP7_75t_R g172(.A(new_n227_), .B(new_n230_), .Y(new_n231_));
  INVx1_ASAP7_75t_R   g173(.A(p6), .Y(new_n232_));
  XOR2x2_ASAP7_75t_R  g174(.A(new_n226_), .B(new_n232_), .Y(new_n233_));
  XOR2x2_ASAP7_75t_R  g175(.A(new_n228_), .B(p10), .Y(new_n234_));
  NAND2x1_ASAP7_75t_R g176(.A(new_n233_), .B(new_n234_), .Y(new_n235_));
  AO21x1_ASAP7_75t_R  g177(.A1(p11), .A2(new_n152_), .B(p2), .Y(new_n236_));
  AOI21x1_ASAP7_75t_R g178(.A1(new_n231_), .A2(new_n235_), .B(new_n236_), .Y(new_n237_));
  NOR2x1_ASAP7_75t_R  g179(.A(new_n233_), .B(new_n234_), .Y(new_n238_));
  NOR2x1_ASAP7_75t_R  g180(.A(new_n227_), .B(new_n230_), .Y(new_n239_));
  NAND3x1_ASAP7_75t_R g181(.A(new_n152_), .B(new_n131_), .C(p11), .Y(new_n240_));
  NOR3x1_ASAP7_75t_R  g182(.A(new_n238_), .B(new_n239_), .C(new_n240_), .Y(new_n241_));
  INVx1_ASAP7_75t_R   g183(.A(p12), .Y(new_n242_));
  OAI21x1_ASAP7_75t_R g184(.A1(new_n237_), .A2(new_n241_), .B(new_n242_), .Y(new_n243_));
  INVx1_ASAP7_75t_R   g185(.A(new_n240_), .Y(new_n244_));
  NAND3x1_ASAP7_75t_R g186(.A(new_n235_), .B(new_n231_), .C(new_n244_), .Y(new_n245_));
  INVx1_ASAP7_75t_R   g187(.A(new_n236_), .Y(new_n246_));
  OAI21x1_ASAP7_75t_R g188(.A1(new_n239_), .A2(new_n238_), .B(new_n246_), .Y(new_n247_));
  NAND3x1_ASAP7_75t_R g189(.A(new_n245_), .B(new_n247_), .C(p12), .Y(new_n248_));
  INVx1_ASAP7_75t_R   g190(.A(p4), .Y(new_n249_));
  NOR2x1_ASAP7_75t_R  g191(.A(p2), .B(p3), .Y(new_n250_));
  INVx1_ASAP7_75t_R   g192(.A(p32), .Y(new_n251_));
  AO21x1_ASAP7_75t_R  g193(.A1(p0), .A2(new_n251_), .B(p1), .Y(new_n252_));
  INVx1_ASAP7_75t_R   g194(.A(new_n252_), .Y(new_n253_));
  OA21x2_ASAP7_75t_R  g195(.A1(new_n249_), .A2(new_n250_), .B(new_n253_), .Y(new_n254_));
  AND3x1_ASAP7_75t_R  g196(.A(new_n243_), .B(new_n248_), .C(new_n254_), .Y(new_n255_));
  NAND2x1_ASAP7_75t_R g197(.A(new_n225_), .B(new_n255_), .Y(new_n256_));
  NAND2x1_ASAP7_75t_R g198(.A(new_n185_), .B(new_n186_), .Y(new_n257_));
  AND2x2_ASAP7_75t_R  g199(.A(p28), .B(new_n83_), .Y(new_n258_));
  XOR2x2_ASAP7_75t_R  g200(.A(p14), .B(p22), .Y(new_n259_));
  XOR2x2_ASAP7_75t_R  g201(.A(new_n258_), .B(new_n259_), .Y(new_n260_));
  XOR2x2_ASAP7_75t_R  g202(.A(new_n260_), .B(new_n113_), .Y(new_n261_));
  NAND2x1_ASAP7_75t_R g203(.A(new_n257_), .B(new_n261_), .Y(new_n262_));
  NAND2x1_ASAP7_75t_R g204(.A(new_n167_), .B(new_n170_), .Y(new_n263_));
  XOR2x2_ASAP7_75t_R  g205(.A(new_n260_), .B(new_n111_), .Y(new_n264_));
  AOI21x1_ASAP7_75t_R g206(.A1(new_n263_), .A2(new_n264_), .B(p2), .Y(new_n265_));
  AOI21x1_ASAP7_75t_R g207(.A1(new_n262_), .A2(new_n265_), .B(p29), .Y(new_n266_));
  NOR2x1_ASAP7_75t_R  g208(.A(new_n257_), .B(new_n261_), .Y(new_n267_));
  AND2x2_ASAP7_75t_R  g209(.A(p29), .B(new_n131_), .Y(new_n268_));
  OAI21x1_ASAP7_75t_R g210(.A1(new_n263_), .A2(new_n264_), .B(new_n268_), .Y(new_n269_));
  INVx1_ASAP7_75t_R   g211(.A(p23), .Y(new_n270_));
  AO21x1_ASAP7_75t_R  g212(.A1(new_n131_), .A2(new_n251_), .B(new_n270_), .Y(new_n271_));
  INVx1_ASAP7_75t_R   g213(.A(new_n271_), .Y(new_n272_));
  OAI21x1_ASAP7_75t_R g214(.A1(new_n267_), .A2(new_n269_), .B(new_n272_), .Y(new_n273_));
  NOR2x1_ASAP7_75t_R  g215(.A(new_n266_), .B(new_n273_), .Y(new_n274_));
  OR3x1_ASAP7_75t_R   g216(.A(new_n256_), .B(new_n142_), .C(new_n274_), .Y(new_n275_));
  NOR2x1_ASAP7_75t_R  g217(.A(new_n267_), .B(new_n269_), .Y(new_n276_));
  OR3x1_ASAP7_75t_R   g218(.A(new_n266_), .B(new_n271_), .C(new_n276_), .Y(new_n277_));
  NAND3x1_ASAP7_75t_R g219(.A(new_n277_), .B(new_n225_), .C(new_n255_), .Y(new_n278_));
  OAI21x1_ASAP7_75t_R g220(.A1(new_n278_), .A2(new_n204_), .B(new_n142_), .Y(new_n279_));
  OAI21x1_ASAP7_75t_R g221(.A1(new_n204_), .A2(new_n275_), .B(new_n279_), .Y(o0));
  NAND3x1_ASAP7_75t_R g222(.A(new_n133_), .B(new_n126_), .C(new_n136_), .Y(new_n281_));
  OAI21x1_ASAP7_75t_R g223(.A1(new_n61_), .A2(new_n121_), .B(new_n281_), .Y(new_n282_));
  NAND3x1_ASAP7_75t_R g224(.A(new_n202_), .B(new_n160_), .C(new_n282_), .Y(new_n283_));
  INVx1_ASAP7_75t_R   g225(.A(new_n283_), .Y(new_n284_));
  INVx1_ASAP7_75t_R   g226(.A(p31), .Y(new_n285_));
  AO21x1_ASAP7_75t_R  g227(.A1(new_n131_), .A2(new_n285_), .B(new_n249_), .Y(new_n286_));
  AND2x2_ASAP7_75t_R  g228(.A(new_n286_), .B(new_n253_), .Y(new_n287_));
  AND3x1_ASAP7_75t_R  g229(.A(new_n243_), .B(new_n248_), .C(new_n287_), .Y(new_n288_));
  NAND2x1_ASAP7_75t_R g230(.A(new_n225_), .B(new_n288_), .Y(new_n289_));
  NOR2x1_ASAP7_75t_R  g231(.A(new_n274_), .B(new_n289_), .Y(new_n290_));
  AOI21x1_ASAP7_75t_R g232(.A1(new_n284_), .A2(new_n290_), .B(new_n62_), .Y(new_n291_));
  AND3x1_ASAP7_75t_R  g233(.A(new_n290_), .B(new_n62_), .C(new_n284_), .Y(new_n292_));
  NOR2x1_ASAP7_75t_R  g234(.A(new_n291_), .B(new_n292_), .Y(o1));
  AOI21x1_ASAP7_75t_R g235(.A1(new_n284_), .A2(new_n290_), .B(new_n64_), .Y(new_n294_));
  AND3x1_ASAP7_75t_R  g236(.A(new_n290_), .B(new_n64_), .C(new_n284_), .Y(new_n295_));
  NOR2x1_ASAP7_75t_R  g237(.A(new_n294_), .B(new_n295_), .Y(o2));
  AND2x2_ASAP7_75t_R  g238(.A(p24), .B(new_n225_), .Y(new_n297_));
  AND2x2_ASAP7_75t_R  g239(.A(new_n255_), .B(new_n277_), .Y(new_n298_));
  NAND2x1_ASAP7_75t_R g240(.A(new_n297_), .B(new_n298_), .Y(new_n299_));
  INVx1_ASAP7_75t_R   g241(.A(p24), .Y(new_n300_));
  OAI21x1_ASAP7_75t_R g242(.A1(new_n278_), .A2(new_n204_), .B(new_n300_), .Y(new_n301_));
  OAI21x1_ASAP7_75t_R g243(.A1(new_n204_), .A2(new_n299_), .B(new_n301_), .Y(o3));
  AOI21x1_ASAP7_75t_R g244(.A1(new_n284_), .A2(new_n290_), .B(new_n69_), .Y(new_n303_));
  AND3x1_ASAP7_75t_R  g245(.A(new_n290_), .B(new_n69_), .C(new_n284_), .Y(new_n304_));
  NOR2x1_ASAP7_75t_R  g246(.A(new_n303_), .B(new_n304_), .Y(o4));
  AOI21x1_ASAP7_75t_R g247(.A1(new_n284_), .A2(new_n290_), .B(new_n75_), .Y(new_n306_));
  AND3x1_ASAP7_75t_R  g248(.A(new_n290_), .B(new_n75_), .C(new_n284_), .Y(new_n307_));
  NOR2x1_ASAP7_75t_R  g249(.A(new_n306_), .B(new_n307_), .Y(o5));
  AND2x2_ASAP7_75t_R  g250(.A(p9), .B(new_n225_), .Y(new_n309_));
  NAND2x1_ASAP7_75t_R g251(.A(new_n309_), .B(new_n298_), .Y(new_n310_));
  NOR2x1_ASAP7_75t_R  g252(.A(new_n274_), .B(new_n256_), .Y(new_n311_));
  AO21x1_ASAP7_75t_R  g253(.A1(new_n284_), .A2(new_n311_), .B(p9), .Y(new_n312_));
  OAI21x1_ASAP7_75t_R g254(.A1(new_n283_), .A2(new_n310_), .B(new_n312_), .Y(o6));
  AND2x2_ASAP7_75t_R  g255(.A(p8), .B(new_n225_), .Y(new_n314_));
  NAND2x1_ASAP7_75t_R g256(.A(new_n314_), .B(new_n298_), .Y(new_n315_));
  AO21x1_ASAP7_75t_R  g257(.A1(new_n284_), .A2(new_n311_), .B(p8), .Y(new_n316_));
  OAI21x1_ASAP7_75t_R g258(.A1(new_n283_), .A2(new_n315_), .B(new_n316_), .Y(o7));
  OR3x1_ASAP7_75t_R   g259(.A(new_n256_), .B(new_n90_), .C(new_n274_), .Y(new_n318_));
  AO21x1_ASAP7_75t_R  g260(.A1(new_n284_), .A2(new_n311_), .B(p15), .Y(new_n319_));
  OAI21x1_ASAP7_75t_R g261(.A1(new_n283_), .A2(new_n318_), .B(new_n319_), .Y(o8));
  OAI21x1_ASAP7_75t_R g262(.A1(new_n276_), .A2(new_n266_), .B(new_n272_), .Y(new_n321_));
  OR3x1_ASAP7_75t_R   g263(.A(new_n289_), .B(new_n283_), .C(new_n321_), .Y(new_n322_));
  INVx1_ASAP7_75t_R   g264(.A(new_n321_), .Y(new_n323_));
  AND3x1_ASAP7_75t_R  g265(.A(new_n288_), .B(new_n172_), .C(new_n225_), .Y(new_n324_));
  AND3x1_ASAP7_75t_R  g266(.A(new_n284_), .B(new_n323_), .C(new_n324_), .Y(new_n325_));
  AOI21x1_ASAP7_75t_R g267(.A1(p18), .A2(new_n322_), .B(new_n325_), .Y(o9));
  AND3x1_ASAP7_75t_R  g268(.A(new_n288_), .B(new_n232_), .C(new_n225_), .Y(new_n327_));
  AND3x1_ASAP7_75t_R  g269(.A(new_n284_), .B(new_n323_), .C(new_n327_), .Y(new_n328_));
  AOI21x1_ASAP7_75t_R g270(.A1(p6), .A2(new_n322_), .B(new_n328_), .Y(o10));
  NOR3x1_ASAP7_75t_R  g271(.A(new_n289_), .B(new_n283_), .C(new_n321_), .Y(new_n330_));
  XNOR2x2_ASAP7_75t_R g272(.A(p21), .B(new_n330_), .Y(o11));
  XNOR2x2_ASAP7_75t_R g273(.A(p5), .B(new_n330_), .Y(o12));
  NOR3x1_ASAP7_75t_R  g274(.A(new_n256_), .B(new_n283_), .C(new_n321_), .Y(new_n333_));
  XOR2x2_ASAP7_75t_R  g275(.A(new_n333_), .B(new_n86_), .Y(o13));
  AND2x2_ASAP7_75t_R  g276(.A(p17), .B(new_n225_), .Y(new_n335_));
  NAND2x1_ASAP7_75t_R g277(.A(new_n335_), .B(new_n298_), .Y(new_n336_));
  INVx1_ASAP7_75t_R   g278(.A(p17), .Y(new_n337_));
  OAI21x1_ASAP7_75t_R g279(.A1(new_n278_), .A2(new_n204_), .B(new_n337_), .Y(new_n338_));
  OAI21x1_ASAP7_75t_R g280(.A1(new_n204_), .A2(new_n336_), .B(new_n338_), .Y(o14));
  AND2x2_ASAP7_75t_R  g281(.A(p10), .B(new_n225_), .Y(new_n340_));
  NAND2x1_ASAP7_75t_R g282(.A(new_n340_), .B(new_n298_), .Y(new_n341_));
  OAI21x1_ASAP7_75t_R g283(.A1(new_n278_), .A2(new_n204_), .B(new_n229_), .Y(new_n342_));
  OAI21x1_ASAP7_75t_R g284(.A1(new_n204_), .A2(new_n341_), .B(new_n342_), .Y(o15));
  OAI21x1_ASAP7_75t_R g285(.A1(new_n266_), .A2(new_n273_), .B(new_n225_), .Y(new_n344_));
  NOR2x1_ASAP7_75t_R  g286(.A(new_n287_), .B(new_n254_), .Y(new_n345_));
  INVx1_ASAP7_75t_R   g287(.A(new_n345_), .Y(new_n346_));
  NAND3x1_ASAP7_75t_R g288(.A(new_n243_), .B(new_n248_), .C(new_n346_), .Y(new_n347_));
  NOR3x1_ASAP7_75t_R  g289(.A(new_n283_), .B(new_n344_), .C(new_n347_), .Y(new_n348_));
  INVx1_ASAP7_75t_R   g290(.A(new_n348_), .Y(new_n349_));
  NOR2x1_ASAP7_75t_R  g291(.A(new_n276_), .B(new_n266_), .Y(new_n350_));
  NOR2x1_ASAP7_75t_R  g292(.A(new_n134_), .B(new_n59_), .Y(new_n351_));
  INVx1_ASAP7_75t_R   g293(.A(new_n351_), .Y(new_n352_));
  NOR2x1_ASAP7_75t_R  g294(.A(new_n352_), .B(new_n121_), .Y(new_n353_));
  OA21x2_ASAP7_75t_R  g295(.A1(new_n119_), .A2(new_n80_), .B(new_n352_), .Y(new_n354_));
  NOR2x1_ASAP7_75t_R  g296(.A(new_n118_), .B(new_n117_), .Y(new_n355_));
  AO21x1_ASAP7_75t_R  g297(.A1(new_n131_), .A2(new_n355_), .B(new_n130_), .Y(new_n356_));
  AND3x1_ASAP7_75t_R  g298(.A(new_n354_), .B(new_n356_), .C(new_n133_), .Y(new_n357_));
  NOR3x1_ASAP7_75t_R  g299(.A(new_n350_), .B(new_n353_), .C(new_n357_), .Y(new_n358_));
  AOI21x1_ASAP7_75t_R g300(.A1(p16), .A2(new_n60_), .B(new_n272_), .Y(new_n359_));
  AND3x1_ASAP7_75t_R  g301(.A(new_n243_), .B(new_n248_), .C(new_n359_), .Y(new_n360_));
  NAND2x1_ASAP7_75t_R g302(.A(new_n225_), .B(new_n360_), .Y(new_n361_));
  NOR2x1_ASAP7_75t_R  g303(.A(new_n203_), .B(new_n361_), .Y(new_n362_));
  AOI21x1_ASAP7_75t_R g304(.A1(new_n358_), .A2(new_n362_), .B(p1), .Y(new_n363_));
  OAI21x1_ASAP7_75t_R g305(.A1(new_n249_), .A2(new_n349_), .B(new_n363_), .Y(o16));
  NAND2x1_ASAP7_75t_R g306(.A(new_n112_), .B(new_n116_), .Y(new_n365_));
  XOR2x2_ASAP7_75t_R  g307(.A(new_n365_), .B(new_n355_), .Y(new_n366_));
  AO21x1_ASAP7_75t_R  g308(.A1(new_n83_), .A2(new_n249_), .B(new_n366_), .Y(new_n367_));
  AND3x1_ASAP7_75t_R  g309(.A(new_n131_), .B(p26), .C(p0), .Y(new_n368_));
  NAND2x1_ASAP7_75t_R g310(.A(new_n368_), .B(new_n348_), .Y(new_n369_));
  OA21x2_ASAP7_75t_R  g311(.A1(new_n216_), .A2(new_n221_), .B(new_n224_), .Y(new_n370_));
  OR3x1_ASAP7_75t_R   g312(.A(new_n274_), .B(new_n370_), .C(new_n347_), .Y(new_n371_));
  NOR2x1_ASAP7_75t_R  g313(.A(p1), .B(p4), .Y(new_n372_));
  INVx1_ASAP7_75t_R   g314(.A(new_n372_), .Y(new_n373_));
  INVx1_ASAP7_75t_R   g315(.A(new_n368_), .Y(new_n374_));
  AO21x1_ASAP7_75t_R  g316(.A1(new_n373_), .A2(new_n366_), .B(new_n374_), .Y(new_n375_));
  NOR3x1_ASAP7_75t_R  g317(.A(new_n371_), .B(new_n283_), .C(new_n375_), .Y(new_n376_));
  AOI21x1_ASAP7_75t_R g318(.A1(new_n367_), .A2(new_n369_), .B(new_n376_), .Y(o17));
  AO21x1_ASAP7_75t_R  g319(.A1(new_n83_), .A2(new_n249_), .B(new_n276_), .Y(new_n378_));
  OAI21x1_ASAP7_75t_R g320(.A1(new_n283_), .A2(new_n371_), .B(new_n373_), .Y(new_n379_));
  INVx1_ASAP7_75t_R   g321(.A(new_n267_), .Y(new_n380_));
  NAND2x1_ASAP7_75t_R g322(.A(new_n262_), .B(new_n380_), .Y(new_n381_));
  INVx1_ASAP7_75t_R   g323(.A(new_n381_), .Y(new_n382_));
  AOI21x1_ASAP7_75t_R g324(.A1(new_n268_), .A2(new_n348_), .B(new_n382_), .Y(new_n383_));
  AOI21x1_ASAP7_75t_R g325(.A1(new_n378_), .A2(new_n379_), .B(new_n383_), .Y(o18));
  NAND2x1_ASAP7_75t_R g326(.A(new_n215_), .B(new_n219_), .Y(new_n385_));
  AO21x1_ASAP7_75t_R  g327(.A1(new_n223_), .A2(new_n385_), .B(new_n372_), .Y(new_n386_));
  AOI21x1_ASAP7_75t_R g328(.A1(new_n385_), .A2(new_n349_), .B(new_n386_), .Y(o19));
  NAND2x1_ASAP7_75t_R g329(.A(new_n235_), .B(new_n231_), .Y(new_n388_));
  AND3x1_ASAP7_75t_R  g330(.A(new_n83_), .B(new_n251_), .C(p11), .Y(new_n389_));
  XOR2x2_ASAP7_75t_R  g331(.A(new_n388_), .B(new_n389_), .Y(new_n390_));
  NAND2x1_ASAP7_75t_R g332(.A(p12), .B(new_n131_), .Y(new_n391_));
  AO21x1_ASAP7_75t_R  g333(.A1(new_n391_), .A2(new_n390_), .B(new_n372_), .Y(new_n392_));
  AOI21x1_ASAP7_75t_R g334(.A1(new_n390_), .A2(new_n349_), .B(new_n392_), .Y(o20));
  AND2x2_ASAP7_75t_R  g335(.A(new_n156_), .B(new_n155_), .Y(new_n394_));
  INVx1_ASAP7_75t_R   g336(.A(p11), .Y(new_n395_));
  OR3x1_ASAP7_75t_R   g337(.A(new_n251_), .B(new_n395_), .C(p2), .Y(new_n396_));
  AO21x1_ASAP7_75t_R  g338(.A1(new_n396_), .A2(new_n394_), .B(new_n372_), .Y(new_n397_));
  AOI21x1_ASAP7_75t_R g339(.A1(new_n394_), .A2(new_n349_), .B(new_n397_), .Y(o21));
  OAI21x1_ASAP7_75t_R g340(.A1(p1), .A2(p30), .B(new_n365_), .Y(new_n399_));
  OR3x1_ASAP7_75t_R   g341(.A(new_n365_), .B(p1), .C(p30), .Y(new_n400_));
  NOR2x1_ASAP7_75t_R  g342(.A(p1), .B(p31), .Y(new_n401_));
  AOI21x1_ASAP7_75t_R g343(.A1(new_n399_), .A2(new_n400_), .B(new_n401_), .Y(new_n402_));
  NOR3x1_ASAP7_75t_R  g344(.A(new_n289_), .B(new_n283_), .C(new_n274_), .Y(new_n403_));
  XNOR2x2_ASAP7_75t_R g345(.A(new_n402_), .B(new_n403_), .Y(o22));
  NOR2x1_ASAP7_75t_R  g346(.A(p1), .B(p28), .Y(new_n405_));
  XOR2x2_ASAP7_75t_R  g347(.A(new_n139_), .B(new_n405_), .Y(new_n406_));
  XOR2x2_ASAP7_75t_R  g348(.A(new_n263_), .B(new_n406_), .Y(new_n407_));
  OAI21x1_ASAP7_75t_R g349(.A1(p1), .A2(p3), .B(new_n407_), .Y(new_n408_));
  OAI21x1_ASAP7_75t_R g350(.A1(new_n283_), .A2(new_n278_), .B(new_n408_), .Y(new_n409_));
  OR3x1_ASAP7_75t_R   g351(.A(new_n278_), .B(new_n283_), .C(new_n408_), .Y(new_n410_));
  NAND2x1_ASAP7_75t_R g352(.A(new_n409_), .B(new_n410_), .Y(o23));
  AO21x1_ASAP7_75t_R  g353(.A1(new_n199_), .A2(new_n196_), .B(new_n372_), .Y(new_n412_));
  NOR2x1_ASAP7_75t_R  g354(.A(new_n412_), .B(new_n348_), .Y(o24));
endmodule


