// Benchmark "/tmp/" written by ABC on Mon Oct 12 14:40:46 2026

module \/tmp/  ( 
    p3, p1, p2, p0, p4,
    o0, o1  );
  input  p3, p1, p2, p0, p4;
  output o0, o1;
  wire new_n8_, new_n9_, new_n10_, new_n12_;
  INVx1_ASAP7_75t_R   g0(.A(p1), .Y(new_n8_));
  AND2x2_ASAP7_75t_R  g1(.A(p2), .B(p0), .Y(new_n9_));
  NAND2x1_ASAP7_75t_R g2(.A(p0), .B(p4), .Y(new_n10_));
  OAI21x1_ASAP7_75t_R g3(.A1(new_n8_), .A2(new_n9_), .B(new_n10_), .Y(o0));
  INVx1_ASAP7_75t_R   g4(.A(p3), .Y(new_n12_));
  AOI21x1_ASAP7_75t_R g5(.A1(new_n12_), .A2(new_n8_), .B(new_n9_), .Y(o1));
endmodule


