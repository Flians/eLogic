// Benchmark "/tmp/" written by ABC on Mon Oct 12 14:40:52 2026

module \/tmp/  ( 
    p26, p7, p22, p31, p20, p33, p17, p35, p27, p21, p32, p1, p12, p29,
    p28, p5, p25, p14, p3, p16, p6, p24, p23, p8, p34, p11, p18, p13, p10,
    p30, p19, p0, p4, p15, p9, p2,
    o0, o1, o2, o4, o3, o5, o6  );
  input  p26, p7, p22, p31, p20, p33, p17, p35, p27, p21, p32, p1, p12,
    p29, p28, p5, p25, p14, p3, p16, p6, p24, p23, p8, p34, p11, p18, p13,
    p10, p30, p19, p0, p4, p15, p9, p2;
  output o0, o1, o2, o4, o3, o5, o6;
  wire new_n44_, new_n45_, new_n46_, new_n47_, new_n48_, new_n49_, new_n50_,
    new_n51_, new_n52_, new_n53_, new_n54_, new_n55_, new_n56_, new_n57_,
    new_n58_, new_n59_, new_n60_, new_n61_, new_n62_, new_n63_, new_n64_,
    new_n65_, new_n67_, new_n68_, new_n69_, new_n70_, new_n71_, new_n72_,
    new_n73_, new_n74_, new_n75_, new_n76_, new_n77_, new_n78_, new_n79_,
    new_n80_, new_n81_, new_n82_, new_n83_, new_n84_, new_n85_, new_n86_,
    new_n87_, new_n88_, new_n89_, new_n90_, new_n91_, new_n92_, new_n93_,
    new_n94_, new_n95_, new_n96_, new_n97_, new_n98_, new_n99_, new_n100_,
    new_n101_, new_n102_, new_n103_, new_n104_, new_n105_, new_n106_,
    new_n107_, new_n108_, new_n109_, new_n110_, new_n111_, new_n112_,
    new_n113_, new_n114_, new_n115_, new_n116_, new_n117_, new_n118_,
    new_n119_, new_n120_, new_n121_, new_n122_, new_n123_, new_n124_,
    new_n126_, new_n127_, new_n128_, new_n129_, new_n130_, new_n131_,
    new_n132_, new_n133_, new_n134_, new_n135_, new_n136_, new_n137_,
    new_n138_, new_n139_, new_n140_, new_n141_, new_n142_, new_n143_,
    new_n144_, new_n145_, new_n146_, new_n147_, new_n148_, new_n149_,
    new_n150_, new_n151_, new_n152_, new_n153_, new_n154_, new_n155_,
    new_n156_, new_n157_, new_n158_, new_n159_, new_n160_, new_n161_,
    new_n162_, new_n163_, new_n164_, new_n165_, new_n166_, new_n167_,
    new_n168_, new_n169_, new_n170_, new_n171_, new_n172_, new_n173_,
    new_n174_, new_n175_, new_n176_, new_n177_, new_n178_, new_n179_,
    new_n180_, new_n181_, new_n182_, new_n183_, new_n184_, new_n185_,
    new_n186_, new_n187_, new_n188_, new_n189_, new_n190_, new_n191_,
    new_n193_, new_n194_, new_n195_, new_n196_, new_n197_, new_n198_,
    new_n199_, new_n200_, new_n201_, new_n202_, new_n203_, new_n204_,
    new_n205_, new_n206_, new_n207_, new_n208_, new_n209_, new_n210_,
    new_n211_, new_n212_, new_n213_, new_n214_, new_n215_, new_n216_,
    new_n217_, new_n218_, new_n219_, new_n220_, new_n221_, new_n222_,
    new_n223_, new_n224_, new_n225_, new_n226_, new_n227_, new_n228_,
    new_n229_, new_n230_, new_n231_, new_n232_, new_n233_, new_n234_,
    new_n235_, new_n236_, new_n237_, new_n238_, new_n239_, new_n240_,
    new_n241_, new_n242_, new_n243_, new_n244_, new_n246_, new_n247_,
    new_n248_, new_n249_, new_n250_, new_n251_, new_n252_, new_n253_,
    new_n254_, new_n255_, new_n256_, new_n257_, new_n258_, new_n259_,
    new_n260_, new_n261_, new_n262_, new_n263_, new_n264_, new_n265_,
    new_n266_, new_n267_, new_n269_, new_n270_, new_n271_, new_n272_,
    new_n273_, new_n274_, new_n275_, new_n276_, new_n277_, new_n278_,
    new_n279_, new_n280_, new_n282_, new_n283_, new_n284_, new_n285_,
    new_n286_, new_n287_, new_n288_, new_n289_, new_n290_, new_n291_,
    new_n292_, new_n293_;
  INVx1_ASAP7_75t_R   g000(.A(p8), .Y(new_n44_));
  INVx1_ASAP7_75t_R   g001(.A(p9), .Y(new_n45_));
  NAND2x1_ASAP7_75t_R g002(.A(p10), .B(new_n45_), .Y(new_n46_));
  OAI21x1_ASAP7_75t_R g003(.A1(p7), .A2(new_n44_), .B(new_n46_), .Y(new_n47_));
  INVx1_ASAP7_75t_R   g004(.A(p5), .Y(new_n48_));
  NAND2x1_ASAP7_75t_R g005(.A(p6), .B(new_n48_), .Y(new_n49_));
  INVx1_ASAP7_75t_R   g006(.A(p11), .Y(new_n50_));
  NAND2x1_ASAP7_75t_R g007(.A(p12), .B(new_n50_), .Y(new_n51_));
  NAND2x1_ASAP7_75t_R g008(.A(new_n49_), .B(new_n51_), .Y(new_n52_));
  NOR2x1_ASAP7_75t_R  g009(.A(new_n47_), .B(new_n52_), .Y(new_n53_));
  INVx1_ASAP7_75t_R   g010(.A(p16), .Y(new_n54_));
  NOR2x1_ASAP7_75t_R  g011(.A(p15), .B(new_n54_), .Y(new_n55_));
  INVx1_ASAP7_75t_R   g012(.A(p14), .Y(new_n56_));
  NOR2x1_ASAP7_75t_R  g013(.A(p13), .B(new_n56_), .Y(new_n57_));
  NOR2x1_ASAP7_75t_R  g014(.A(new_n55_), .B(new_n57_), .Y(new_n58_));
  INVx1_ASAP7_75t_R   g015(.A(p3), .Y(new_n59_));
  NAND2x1_ASAP7_75t_R g016(.A(p4), .B(new_n59_), .Y(new_n60_));
  INVx1_ASAP7_75t_R   g017(.A(p35), .Y(new_n61_));
  NAND2x1_ASAP7_75t_R g018(.A(p0), .B(new_n61_), .Y(new_n62_));
  INVx1_ASAP7_75t_R   g019(.A(p1), .Y(new_n63_));
  NAND2x1_ASAP7_75t_R g020(.A(p2), .B(new_n63_), .Y(new_n64_));
  AND3x1_ASAP7_75t_R  g021(.A(new_n60_), .B(new_n62_), .C(new_n64_), .Y(new_n65_));
  NAND3x1_ASAP7_75t_R g022(.A(new_n53_), .B(new_n58_), .C(new_n65_), .Y(o0));
  INVx1_ASAP7_75t_R   g023(.A(p15), .Y(new_n67_));
  NAND2x1_ASAP7_75t_R g024(.A(p16), .B(new_n67_), .Y(new_n68_));
  OAI21x1_ASAP7_75t_R g025(.A1(new_n56_), .A2(p13), .B(new_n68_), .Y(new_n69_));
  NAND2x1_ASAP7_75t_R g026(.A(new_n62_), .B(new_n64_), .Y(new_n70_));
  NOR2x1_ASAP7_75t_R  g027(.A(new_n69_), .B(new_n70_), .Y(new_n71_));
  INVx1_ASAP7_75t_R   g028(.A(p4), .Y(new_n72_));
  NOR2x1_ASAP7_75t_R  g029(.A(p3), .B(new_n72_), .Y(new_n73_));
  AOI21x1_ASAP7_75t_R g030(.A1(new_n53_), .A2(new_n71_), .B(new_n73_), .Y(new_n74_));
  NOR2x1_ASAP7_75t_R  g031(.A(p19), .B(new_n72_), .Y(new_n75_));
  INVx1_ASAP7_75t_R   g032(.A(new_n75_), .Y(new_n76_));
  NAND3x1_ASAP7_75t_R g033(.A(new_n60_), .B(new_n62_), .C(new_n64_), .Y(new_n77_));
  NOR3x1_ASAP7_75t_R  g034(.A(new_n77_), .B(new_n47_), .C(new_n52_), .Y(new_n78_));
  INVx1_ASAP7_75t_R   g035(.A(p13), .Y(new_n79_));
  AND3x1_ASAP7_75t_R  g036(.A(new_n79_), .B(p14), .C(p15), .Y(new_n80_));
  OR3x1_ASAP7_75t_R   g037(.A(new_n80_), .B(p25), .C(new_n54_), .Y(new_n81_));
  INVx1_ASAP7_75t_R   g038(.A(new_n81_), .Y(new_n82_));
  OAI21x1_ASAP7_75t_R g039(.A1(new_n55_), .A2(new_n78_), .B(new_n82_), .Y(new_n83_));
  OAI21x1_ASAP7_75t_R g040(.A1(new_n74_), .A2(new_n76_), .B(new_n83_), .Y(new_n84_));
  NAND2x1_ASAP7_75t_R g041(.A(new_n60_), .B(new_n64_), .Y(new_n85_));
  NOR2x1_ASAP7_75t_R  g042(.A(new_n69_), .B(new_n85_), .Y(new_n86_));
  NAND2x1_ASAP7_75t_R g043(.A(new_n53_), .B(new_n86_), .Y(new_n87_));
  INVx1_ASAP7_75t_R   g044(.A(p0), .Y(new_n88_));
  NOR2x1_ASAP7_75t_R  g045(.A(p17), .B(new_n88_), .Y(new_n89_));
  INVx1_ASAP7_75t_R   g046(.A(new_n89_), .Y(new_n90_));
  AOI21x1_ASAP7_75t_R g047(.A1(new_n62_), .A2(new_n87_), .B(new_n90_), .Y(new_n91_));
  NOR2x1_ASAP7_75t_R  g048(.A(p24), .B(new_n56_), .Y(new_n92_));
  INVx1_ASAP7_75t_R   g049(.A(new_n92_), .Y(new_n93_));
  NAND2x1_ASAP7_75t_R g050(.A(new_n68_), .B(new_n60_), .Y(new_n94_));
  NOR2x1_ASAP7_75t_R  g051(.A(new_n70_), .B(new_n94_), .Y(new_n95_));
  AOI21x1_ASAP7_75t_R g052(.A1(new_n53_), .A2(new_n95_), .B(new_n57_), .Y(new_n96_));
  NOR2x1_ASAP7_75t_R  g053(.A(new_n93_), .B(new_n96_), .Y(new_n97_));
  NOR3x1_ASAP7_75t_R  g054(.A(new_n84_), .B(new_n91_), .C(new_n97_), .Y(new_n98_));
  NOR2x1_ASAP7_75t_R  g055(.A(new_n44_), .B(new_n77_), .Y(new_n99_));
  INVx1_ASAP7_75t_R   g056(.A(p6), .Y(new_n100_));
  NOR2x1_ASAP7_75t_R  g057(.A(p5), .B(new_n100_), .Y(new_n101_));
  AOI21x1_ASAP7_75t_R g058(.A1(p12), .A2(new_n50_), .B(new_n101_), .Y(new_n102_));
  NOR2x1_ASAP7_75t_R  g059(.A(p7), .B(new_n44_), .Y(new_n103_));
  INVx1_ASAP7_75t_R   g060(.A(p10), .Y(new_n104_));
  NOR2x1_ASAP7_75t_R  g061(.A(p9), .B(new_n104_), .Y(new_n105_));
  NOR2x1_ASAP7_75t_R  g062(.A(new_n103_), .B(new_n105_), .Y(new_n106_));
  AND3x1_ASAP7_75t_R  g063(.A(new_n58_), .B(new_n102_), .C(new_n106_), .Y(new_n107_));
  AO21x1_ASAP7_75t_R  g064(.A1(new_n99_), .A2(new_n107_), .B(new_n103_), .Y(new_n108_));
  NOR2x1_ASAP7_75t_R  g065(.A(p7), .B(new_n77_), .Y(new_n109_));
  AOI21x1_ASAP7_75t_R g066(.A1(new_n109_), .A2(new_n107_), .B(p21), .Y(new_n110_));
  NOR2x1_ASAP7_75t_R  g067(.A(p22), .B(new_n104_), .Y(new_n111_));
  INVx1_ASAP7_75t_R   g068(.A(new_n111_), .Y(new_n112_));
  AOI21x1_ASAP7_75t_R g069(.A1(p9), .A2(o0), .B(new_n112_), .Y(new_n113_));
  AOI21x1_ASAP7_75t_R g070(.A1(new_n108_), .A2(new_n110_), .B(new_n113_), .Y(new_n114_));
  NOR2x1_ASAP7_75t_R  g071(.A(new_n100_), .B(new_n73_), .Y(new_n115_));
  NAND3x1_ASAP7_75t_R g072(.A(new_n53_), .B(new_n71_), .C(new_n115_), .Y(new_n116_));
  AOI21x1_ASAP7_75t_R g073(.A1(new_n49_), .A2(new_n116_), .B(p20), .Y(new_n117_));
  INVx1_ASAP7_75t_R   g074(.A(p2), .Y(new_n118_));
  OR2x4_ASAP7_75t_R   g075(.A(p18), .B(new_n118_), .Y(new_n119_));
  AOI21x1_ASAP7_75t_R g076(.A1(p1), .A2(o0), .B(new_n119_), .Y(new_n120_));
  INVx1_ASAP7_75t_R   g077(.A(p23), .Y(new_n121_));
  NAND2x1_ASAP7_75t_R g078(.A(p12), .B(new_n121_), .Y(new_n122_));
  AOI21x1_ASAP7_75t_R g079(.A1(p11), .A2(o0), .B(new_n122_), .Y(new_n123_));
  NOR3x1_ASAP7_75t_R  g080(.A(new_n117_), .B(new_n120_), .C(new_n123_), .Y(new_n124_));
  NAND3x1_ASAP7_75t_R g081(.A(new_n98_), .B(new_n114_), .C(new_n124_), .Y(o1));
  AO21x1_ASAP7_75t_R  g082(.A1(new_n49_), .A2(new_n116_), .B(p29), .Y(new_n126_));
  INVx1_ASAP7_75t_R   g083(.A(new_n126_), .Y(new_n127_));
  NOR2x1_ASAP7_75t_R  g084(.A(new_n120_), .B(new_n123_), .Y(new_n128_));
  INVx1_ASAP7_75t_R   g085(.A(new_n128_), .Y(new_n129_));
  NOR2x1_ASAP7_75t_R  g086(.A(new_n91_), .B(new_n97_), .Y(new_n130_));
  OA21x2_ASAP7_75t_R  g087(.A1(new_n74_), .A2(new_n76_), .B(new_n83_), .Y(new_n131_));
  NAND3x1_ASAP7_75t_R g088(.A(new_n114_), .B(new_n130_), .C(new_n131_), .Y(new_n132_));
  OAI21x1_ASAP7_75t_R g089(.A1(new_n129_), .A2(new_n132_), .B(p20), .Y(new_n133_));
  NAND2x1_ASAP7_75t_R g090(.A(new_n106_), .B(new_n102_), .Y(new_n134_));
  AOI21x1_ASAP7_75t_R g091(.A1(new_n63_), .A2(p2), .B(new_n73_), .Y(new_n135_));
  NAND2x1_ASAP7_75t_R g092(.A(new_n58_), .B(new_n135_), .Y(new_n136_));
  OAI21x1_ASAP7_75t_R g093(.A1(new_n134_), .A2(new_n136_), .B(new_n62_), .Y(new_n137_));
  NAND2x1_ASAP7_75t_R g094(.A(new_n89_), .B(new_n137_), .Y(new_n138_));
  OAI21x1_ASAP7_75t_R g095(.A1(new_n93_), .A2(new_n96_), .B(new_n138_), .Y(new_n139_));
  OA21x2_ASAP7_75t_R  g096(.A1(new_n84_), .A2(new_n139_), .B(p17), .Y(new_n140_));
  OAI21x1_ASAP7_75t_R g097(.A1(new_n120_), .A2(new_n123_), .B(p17), .Y(new_n141_));
  NAND2x1_ASAP7_75t_R g098(.A(p17), .B(new_n117_), .Y(new_n142_));
  NAND2x1_ASAP7_75t_R g099(.A(p0), .B(new_n137_), .Y(new_n143_));
  NOR2x1_ASAP7_75t_R  g100(.A(p26), .B(new_n143_), .Y(new_n144_));
  NAND3x1_ASAP7_75t_R g101(.A(new_n141_), .B(new_n142_), .C(new_n144_), .Y(new_n145_));
  INVx1_ASAP7_75t_R   g102(.A(p17), .Y(new_n146_));
  NOR2x1_ASAP7_75t_R  g103(.A(new_n146_), .B(new_n114_), .Y(new_n147_));
  NOR3x1_ASAP7_75t_R  g104(.A(new_n140_), .B(new_n145_), .C(new_n147_), .Y(new_n148_));
  AOI21x1_ASAP7_75t_R g105(.A1(new_n127_), .A2(new_n133_), .B(new_n148_), .Y(new_n149_));
  AOI21x1_ASAP7_75t_R g106(.A1(new_n99_), .A2(new_n107_), .B(new_n103_), .Y(new_n150_));
  NOR2x1_ASAP7_75t_R  g107(.A(p30), .B(new_n150_), .Y(new_n151_));
  INVx1_ASAP7_75t_R   g108(.A(new_n151_), .Y(new_n152_));
  AOI21x1_ASAP7_75t_R g109(.A1(p21), .A2(o1), .B(new_n152_), .Y(new_n153_));
  INVx1_ASAP7_75t_R   g110(.A(p32), .Y(new_n154_));
  NAND2x1_ASAP7_75t_R g111(.A(p12), .B(new_n58_), .Y(new_n155_));
  OR3x1_ASAP7_75t_R   g112(.A(new_n77_), .B(new_n47_), .C(new_n52_), .Y(new_n156_));
  OAI21x1_ASAP7_75t_R g113(.A1(new_n155_), .A2(new_n156_), .B(new_n51_), .Y(new_n157_));
  INVx1_ASAP7_75t_R   g114(.A(p33), .Y(new_n158_));
  NAND2x1_ASAP7_75t_R g115(.A(p14), .B(new_n158_), .Y(new_n159_));
  NOR2x1_ASAP7_75t_R  g116(.A(new_n159_), .B(new_n96_), .Y(new_n160_));
  AOI21x1_ASAP7_75t_R g117(.A1(new_n154_), .A2(new_n157_), .B(new_n160_), .Y(new_n161_));
  INVx1_ASAP7_75t_R   g118(.A(p27), .Y(new_n162_));
  OR3x1_ASAP7_75t_R   g119(.A(new_n55_), .B(new_n57_), .C(new_n118_), .Y(new_n163_));
  OAI21x1_ASAP7_75t_R g120(.A1(new_n163_), .A2(new_n156_), .B(new_n64_), .Y(new_n164_));
  NOR2x1_ASAP7_75t_R  g121(.A(p28), .B(new_n72_), .Y(new_n165_));
  INVx1_ASAP7_75t_R   g122(.A(new_n165_), .Y(new_n166_));
  NOR2x1_ASAP7_75t_R  g123(.A(new_n166_), .B(new_n74_), .Y(new_n167_));
  AOI21x1_ASAP7_75t_R g124(.A1(new_n162_), .A2(new_n164_), .B(new_n167_), .Y(new_n168_));
  INVx1_ASAP7_75t_R   g125(.A(p31), .Y(new_n169_));
  NOR2x1_ASAP7_75t_R  g126(.A(new_n104_), .B(new_n77_), .Y(new_n170_));
  AO21x1_ASAP7_75t_R  g127(.A1(new_n170_), .A2(new_n107_), .B(new_n105_), .Y(new_n171_));
  AO21x1_ASAP7_75t_R  g128(.A1(p15), .A2(new_n57_), .B(new_n54_), .Y(new_n172_));
  NOR2x1_ASAP7_75t_R  g129(.A(p34), .B(new_n172_), .Y(new_n173_));
  OA21x2_ASAP7_75t_R  g130(.A1(new_n55_), .A2(new_n78_), .B(new_n173_), .Y(new_n174_));
  AOI21x1_ASAP7_75t_R g131(.A1(new_n169_), .A2(new_n171_), .B(new_n174_), .Y(new_n175_));
  AND3x1_ASAP7_75t_R  g132(.A(new_n161_), .B(new_n168_), .C(new_n175_), .Y(new_n176_));
  OA21x2_ASAP7_75t_R  g133(.A1(new_n155_), .A2(new_n156_), .B(new_n51_), .Y(new_n177_));
  NAND2x1_ASAP7_75t_R g134(.A(new_n154_), .B(new_n121_), .Y(new_n178_));
  INVx1_ASAP7_75t_R   g135(.A(p25), .Y(new_n179_));
  NAND2x1_ASAP7_75t_R g136(.A(new_n179_), .B(new_n174_), .Y(new_n180_));
  OAI21x1_ASAP7_75t_R g137(.A1(new_n177_), .A2(new_n178_), .B(new_n180_), .Y(new_n181_));
  OR3x1_ASAP7_75t_R   g138(.A(new_n72_), .B(p28), .C(p19), .Y(new_n182_));
  NOR2x1_ASAP7_75t_R  g139(.A(new_n182_), .B(new_n74_), .Y(new_n183_));
  AO21x1_ASAP7_75t_R  g140(.A1(new_n158_), .A2(new_n97_), .B(new_n183_), .Y(new_n184_));
  AO21x1_ASAP7_75t_R  g141(.A1(p1), .A2(o0), .B(new_n119_), .Y(new_n185_));
  OR3x1_ASAP7_75t_R   g142(.A(new_n104_), .B(p22), .C(p31), .Y(new_n186_));
  AO21x1_ASAP7_75t_R  g143(.A1(new_n46_), .A2(o0), .B(new_n186_), .Y(new_n187_));
  OAI21x1_ASAP7_75t_R g144(.A1(p27), .A2(new_n185_), .B(new_n187_), .Y(new_n188_));
  NOR3x1_ASAP7_75t_R  g145(.A(new_n181_), .B(new_n184_), .C(new_n188_), .Y(new_n189_));
  OAI21x1_ASAP7_75t_R g146(.A1(new_n176_), .A2(o1), .B(new_n189_), .Y(new_n190_));
  NOR2x1_ASAP7_75t_R  g147(.A(new_n153_), .B(new_n190_), .Y(new_n191_));
  NAND2x1_ASAP7_75t_R g148(.A(new_n149_), .B(new_n191_), .Y(o2));
  AO21x1_ASAP7_75t_R  g149(.A1(new_n109_), .A2(new_n107_), .B(p21), .Y(new_n193_));
  NOR3x1_ASAP7_75t_R  g150(.A(new_n134_), .B(new_n69_), .C(new_n77_), .Y(new_n194_));
  OAI21x1_ASAP7_75t_R g151(.A1(new_n45_), .A2(new_n194_), .B(new_n111_), .Y(new_n195_));
  OAI21x1_ASAP7_75t_R g152(.A1(new_n150_), .A2(new_n193_), .B(new_n195_), .Y(new_n196_));
  NOR3x1_ASAP7_75t_R  g153(.A(new_n196_), .B(new_n84_), .C(new_n139_), .Y(new_n197_));
  NAND3x1_ASAP7_75t_R g154(.A(new_n197_), .B(new_n124_), .C(new_n151_), .Y(new_n198_));
  AO21x1_ASAP7_75t_R  g155(.A1(new_n49_), .A2(new_n116_), .B(p20), .Y(new_n199_));
  NAND3x1_ASAP7_75t_R g156(.A(new_n128_), .B(new_n171_), .C(new_n199_), .Y(new_n200_));
  OAI21x1_ASAP7_75t_R g157(.A1(new_n200_), .A2(new_n132_), .B(new_n195_), .Y(new_n201_));
  INVx1_ASAP7_75t_R   g158(.A(p21), .Y(new_n202_));
  AND2x2_ASAP7_75t_R  g159(.A(new_n202_), .B(new_n151_), .Y(new_n203_));
  INVx1_ASAP7_75t_R   g160(.A(new_n203_), .Y(new_n204_));
  AND3x1_ASAP7_75t_R  g161(.A(new_n198_), .B(new_n201_), .C(new_n204_), .Y(new_n205_));
  OA21x2_ASAP7_75t_R  g162(.A1(new_n176_), .A2(o1), .B(new_n189_), .Y(new_n206_));
  NAND3x1_ASAP7_75t_R g163(.A(new_n205_), .B(new_n149_), .C(new_n206_), .Y(new_n207_));
  NAND3x1_ASAP7_75t_R g164(.A(new_n161_), .B(new_n168_), .C(new_n175_), .Y(new_n208_));
  NAND3x1_ASAP7_75t_R g165(.A(new_n197_), .B(new_n208_), .C(new_n124_), .Y(new_n209_));
  AOI21x1_ASAP7_75t_R g166(.A1(p21), .A2(new_n117_), .B(new_n150_), .Y(new_n210_));
  OAI21x1_ASAP7_75t_R g167(.A1(new_n202_), .A2(new_n128_), .B(new_n210_), .Y(new_n211_));
  AOI21x1_ASAP7_75t_R g168(.A1(p21), .A2(new_n132_), .B(new_n211_), .Y(new_n212_));
  AND3x1_ASAP7_75t_R  g169(.A(new_n209_), .B(new_n212_), .C(new_n189_), .Y(new_n213_));
  OA21x2_ASAP7_75t_R  g170(.A1(new_n200_), .A2(new_n132_), .B(new_n195_), .Y(new_n214_));
  AO21x1_ASAP7_75t_R  g171(.A1(p21), .A2(o1), .B(new_n152_), .Y(new_n215_));
  OAI21x1_ASAP7_75t_R g172(.A1(p31), .A2(new_n214_), .B(new_n215_), .Y(new_n216_));
  AOI21x1_ASAP7_75t_R g173(.A1(new_n149_), .A2(new_n213_), .B(new_n216_), .Y(new_n217_));
  NAND2x1_ASAP7_75t_R g174(.A(new_n207_), .B(new_n217_), .Y(new_n218_));
  AND2x2_ASAP7_75t_R  g175(.A(p24), .B(o1), .Y(new_n219_));
  OR2x4_ASAP7_75t_R   g176(.A(new_n56_), .B(new_n96_), .Y(new_n220_));
  OR3x1_ASAP7_75t_R   g177(.A(new_n219_), .B(new_n153_), .C(new_n220_), .Y(new_n221_));
  NAND2x1_ASAP7_75t_R g178(.A(new_n206_), .B(new_n149_), .Y(new_n222_));
  OR3x1_ASAP7_75t_R   g179(.A(new_n219_), .B(new_n96_), .C(new_n159_), .Y(new_n223_));
  OAI21x1_ASAP7_75t_R g180(.A1(new_n221_), .A2(new_n222_), .B(new_n223_), .Y(new_n224_));
  INVx1_ASAP7_75t_R   g181(.A(p20), .Y(new_n225_));
  AOI21x1_ASAP7_75t_R g182(.A1(new_n128_), .A2(new_n197_), .B(new_n225_), .Y(new_n226_));
  AND3x1_ASAP7_75t_R  g183(.A(new_n141_), .B(new_n144_), .C(new_n142_), .Y(new_n227_));
  NAND2x1_ASAP7_75t_R g184(.A(p17), .B(new_n196_), .Y(new_n228_));
  AO21x1_ASAP7_75t_R  g185(.A1(new_n131_), .A2(new_n130_), .B(new_n146_), .Y(new_n229_));
  NAND3x1_ASAP7_75t_R g186(.A(new_n227_), .B(new_n228_), .C(new_n229_), .Y(new_n230_));
  OAI21x1_ASAP7_75t_R g187(.A1(new_n126_), .A2(new_n226_), .B(new_n230_), .Y(new_n231_));
  INVx1_ASAP7_75t_R   g188(.A(new_n123_), .Y(new_n232_));
  NAND2x1_ASAP7_75t_R g189(.A(new_n49_), .B(new_n116_), .Y(new_n233_));
  AOI21x1_ASAP7_75t_R g190(.A1(new_n225_), .A2(new_n233_), .B(new_n177_), .Y(new_n234_));
  AND3x1_ASAP7_75t_R  g191(.A(new_n234_), .B(new_n185_), .C(new_n232_), .Y(new_n235_));
  NAND2x1_ASAP7_75t_R g192(.A(new_n197_), .B(new_n235_), .Y(new_n236_));
  AOI21x1_ASAP7_75t_R g193(.A1(new_n232_), .A2(new_n236_), .B(new_n203_), .Y(new_n237_));
  NAND3x1_ASAP7_75t_R g194(.A(new_n237_), .B(new_n206_), .C(new_n198_), .Y(new_n238_));
  NAND2x1_ASAP7_75t_R g195(.A(new_n128_), .B(new_n234_), .Y(new_n239_));
  OAI21x1_ASAP7_75t_R g196(.A1(new_n239_), .A2(new_n132_), .B(new_n232_), .Y(new_n240_));
  AND2x2_ASAP7_75t_R  g197(.A(new_n154_), .B(new_n240_), .Y(new_n241_));
  INVx1_ASAP7_75t_R   g198(.A(new_n241_), .Y(new_n242_));
  OAI21x1_ASAP7_75t_R g199(.A1(new_n231_), .A2(new_n238_), .B(new_n242_), .Y(new_n243_));
  NOR3x1_ASAP7_75t_R  g200(.A(new_n218_), .B(new_n224_), .C(new_n243_), .Y(new_n244_));
  INVx1_ASAP7_75t_R   g201(.A(new_n244_), .Y(o4));
  OR2x4_ASAP7_75t_R   g202(.A(new_n72_), .B(new_n74_), .Y(new_n246_));
  AOI21x1_ASAP7_75t_R g203(.A1(p19), .A2(o1), .B(new_n246_), .Y(new_n247_));
  AND3x1_ASAP7_75t_R  g204(.A(new_n206_), .B(new_n215_), .C(new_n247_), .Y(new_n248_));
  INVx1_ASAP7_75t_R   g205(.A(p28), .Y(new_n249_));
  AND2x2_ASAP7_75t_R  g206(.A(new_n249_), .B(new_n247_), .Y(new_n250_));
  AO21x1_ASAP7_75t_R  g207(.A1(new_n149_), .A2(new_n248_), .B(new_n250_), .Y(new_n251_));
  INVx1_ASAP7_75t_R   g208(.A(new_n164_), .Y(new_n252_));
  AO21x1_ASAP7_75t_R  g209(.A1(p18), .A2(o1), .B(new_n252_), .Y(new_n253_));
  AO21x1_ASAP7_75t_R  g210(.A1(p17), .A2(o1), .B(new_n143_), .Y(new_n254_));
  AO21x1_ASAP7_75t_R  g211(.A1(new_n253_), .A2(new_n254_), .B(new_n153_), .Y(new_n255_));
  OA21x2_ASAP7_75t_R  g212(.A1(p27), .A2(new_n253_), .B(new_n230_), .Y(new_n256_));
  OAI21x1_ASAP7_75t_R g213(.A1(new_n255_), .A2(new_n222_), .B(new_n256_), .Y(new_n257_));
  AO21x1_ASAP7_75t_R  g214(.A1(new_n114_), .A2(new_n98_), .B(new_n225_), .Y(new_n258_));
  OA21x2_ASAP7_75t_R  g215(.A1(new_n225_), .A2(new_n128_), .B(new_n233_), .Y(new_n259_));
  AND3x1_ASAP7_75t_R  g216(.A(new_n258_), .B(new_n204_), .C(new_n259_), .Y(new_n260_));
  NAND3x1_ASAP7_75t_R g217(.A(new_n260_), .B(new_n206_), .C(new_n198_), .Y(new_n261_));
  NAND2x1_ASAP7_75t_R g218(.A(new_n127_), .B(new_n133_), .Y(new_n262_));
  OAI21x1_ASAP7_75t_R g219(.A1(new_n231_), .A2(new_n261_), .B(new_n262_), .Y(new_n263_));
  NOR3x1_ASAP7_75t_R  g220(.A(new_n251_), .B(new_n257_), .C(new_n263_), .Y(new_n264_));
  AO21x1_ASAP7_75t_R  g221(.A1(new_n68_), .A2(new_n156_), .B(new_n172_), .Y(new_n265_));
  AO21x1_ASAP7_75t_R  g222(.A1(p25), .A2(o1), .B(new_n265_), .Y(new_n266_));
  AOI21x1_ASAP7_75t_R g223(.A1(p34), .A2(o2), .B(new_n266_), .Y(new_n267_));
  AOI21x1_ASAP7_75t_R g224(.A1(new_n264_), .A2(new_n244_), .B(new_n267_), .Y(o3));
  NAND3x1_ASAP7_75t_R g225(.A(new_n209_), .B(new_n212_), .C(new_n189_), .Y(new_n269_));
  AOI21x1_ASAP7_75t_R g226(.A1(new_n169_), .A2(new_n201_), .B(new_n153_), .Y(new_n270_));
  OAI21x1_ASAP7_75t_R g227(.A1(new_n231_), .A2(new_n269_), .B(new_n270_), .Y(new_n271_));
  NAND3x1_ASAP7_75t_R g228(.A(new_n198_), .B(new_n201_), .C(new_n204_), .Y(new_n272_));
  NOR3x1_ASAP7_75t_R  g229(.A(new_n231_), .B(new_n272_), .C(new_n190_), .Y(new_n273_));
  NOR2x1_ASAP7_75t_R  g230(.A(new_n271_), .B(new_n273_), .Y(new_n274_));
  NAND3x1_ASAP7_75t_R g231(.A(new_n198_), .B(new_n240_), .C(new_n204_), .Y(new_n275_));
  NOR3x1_ASAP7_75t_R  g232(.A(new_n231_), .B(new_n275_), .C(new_n190_), .Y(new_n276_));
  NOR2x1_ASAP7_75t_R  g233(.A(new_n241_), .B(new_n276_), .Y(new_n277_));
  NAND3x1_ASAP7_75t_R g234(.A(new_n274_), .B(new_n277_), .C(new_n263_), .Y(new_n278_));
  NOR2x1_ASAP7_75t_R  g235(.A(new_n224_), .B(new_n243_), .Y(new_n279_));
  NAND2x1_ASAP7_75t_R g236(.A(new_n251_), .B(new_n274_), .Y(new_n280_));
  NAND3x1_ASAP7_75t_R g237(.A(new_n278_), .B(new_n279_), .C(new_n280_), .Y(o5));
  AO21x1_ASAP7_75t_R  g238(.A1(new_n154_), .A2(new_n240_), .B(new_n253_), .Y(new_n282_));
  NOR3x1_ASAP7_75t_R  g239(.A(new_n276_), .B(new_n250_), .C(new_n282_), .Y(new_n283_));
  OA21x2_ASAP7_75t_R  g240(.A1(new_n202_), .A2(new_n128_), .B(new_n210_), .Y(new_n284_));
  OAI21x1_ASAP7_75t_R g241(.A1(new_n202_), .A2(new_n197_), .B(new_n284_), .Y(new_n285_));
  OAI21x1_ASAP7_75t_R g242(.A1(p30), .A2(new_n285_), .B(new_n247_), .Y(new_n286_));
  NOR3x1_ASAP7_75t_R  g243(.A(new_n286_), .B(new_n231_), .C(new_n190_), .Y(new_n287_));
  AOI21x1_ASAP7_75t_R g244(.A1(new_n149_), .A2(new_n191_), .B(new_n162_), .Y(new_n288_));
  NOR2x1_ASAP7_75t_R  g245(.A(new_n287_), .B(new_n288_), .Y(new_n289_));
  AOI21x1_ASAP7_75t_R g246(.A1(new_n169_), .A2(new_n201_), .B(new_n273_), .Y(new_n290_));
  NAND3x1_ASAP7_75t_R g247(.A(new_n283_), .B(new_n289_), .C(new_n290_), .Y(new_n291_));
  OAI21x1_ASAP7_75t_R g248(.A1(p31), .A2(new_n214_), .B(new_n207_), .Y(new_n292_));
  AOI21x1_ASAP7_75t_R g249(.A1(new_n292_), .A2(new_n277_), .B(new_n224_), .Y(new_n293_));
  NAND3x1_ASAP7_75t_R g250(.A(new_n291_), .B(new_n278_), .C(new_n293_), .Y(o6));
endmodule


