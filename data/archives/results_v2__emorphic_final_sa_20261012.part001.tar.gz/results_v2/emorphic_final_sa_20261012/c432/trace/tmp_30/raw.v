// Benchmark "/tmp/" written by ABC on Mon Oct 12 14:40:54 2026

module \/tmp/  ( 
    p4, p11, p22, p13, p14, p19, p21, p20, p15, p32, p6, p33, p3, p1, p35,
    p27, p30, p29, p23, p28, p18, p12, p2, p26, p17, p9, p0, p34, p8, p10,
    p31, p16, p7, p5, p24, p25,
    o0, o1, o2, o4, o3, o5, o6  );
  input  p4, p11, p22, p13, p14, p19, p21, p20, p15, p32, p6, p33, p3,
    p1, p35, p27, p30, p29, p23, p28, p18, p12, p2, p26, p17, p9, p0, p34,
    p8, p10, p31, p16, p7, p5, p24, p25;
  output o0, o1, o2, o4, o3, o5, o6;
  wire new_n44_, new_n45_, new_n46_, new_n47_, new_n48_, new_n49_, new_n50_,
    new_n51_, new_n52_, new_n53_, new_n54_, new_n55_, new_n56_, new_n57_,
    new_n58_, new_n59_, new_n60_, new_n61_, new_n62_, new_n63_, new_n64_,
    new_n66_, new_n67_, new_n68_, new_n69_, new_n70_, new_n71_, new_n72_,
    new_n73_, new_n74_, new_n75_, new_n76_, new_n77_, new_n78_, new_n79_,
    new_n80_, new_n81_, new_n82_, new_n83_, new_n84_, new_n85_, new_n86_,
    new_n87_, new_n88_, new_n89_, new_n90_, new_n91_, new_n92_, new_n93_,
    new_n94_, new_n95_, new_n96_, new_n97_, new_n98_, new_n99_, new_n100_,
    new_n101_, new_n102_, new_n103_, new_n104_, new_n105_, new_n106_,
    new_n107_, new_n108_, new_n109_, new_n110_, new_n111_, new_n112_,
    new_n113_, new_n114_, new_n115_, new_n116_, new_n117_, new_n118_,
    new_n119_, new_n120_, new_n121_, new_n122_, new_n123_, new_n124_,
    new_n125_, new_n126_, new_n127_, new_n129_, new_n130_, new_n131_,
    new_n132_, new_n133_, new_n134_, new_n135_, new_n136_, new_n137_,
    new_n138_, new_n139_, new_n140_, new_n141_, new_n142_, new_n143_,
    new_n144_, new_n145_, new_n146_, new_n147_, new_n148_, new_n149_,
    new_n150_, new_n151_, new_n152_, new_n153_, new_n154_, new_n155_,
    new_n156_, new_n157_, new_n158_, new_n159_, new_n160_, new_n161_,
    new_n162_, new_n163_, new_n164_, new_n165_, new_n166_, new_n167_,
    new_n168_, new_n169_, new_n170_, new_n171_, new_n172_, new_n173_,
    new_n174_, new_n175_, new_n176_, new_n177_, new_n178_, new_n179_,
    new_n180_, new_n181_, new_n182_, new_n183_, new_n184_, new_n185_,
    new_n186_, new_n187_, new_n188_, new_n189_, new_n190_, new_n191_,
    new_n192_, new_n193_, new_n194_, new_n196_, new_n197_, new_n198_,
    new_n199_, new_n200_, new_n201_, new_n202_, new_n203_, new_n204_,
    new_n205_, new_n206_, new_n207_, new_n208_, new_n209_, new_n210_,
    new_n211_, new_n212_, new_n213_, new_n214_, new_n215_, new_n216_,
    new_n217_, new_n218_, new_n219_, new_n220_, new_n221_, new_n222_,
    new_n223_, new_n224_, new_n225_, new_n226_, new_n227_, new_n228_,
    new_n229_, new_n230_, new_n231_, new_n232_, new_n233_, new_n234_,
    new_n235_, new_n236_, new_n237_, new_n238_, new_n239_, new_n240_,
    new_n241_, new_n242_, new_n243_, new_n244_, new_n245_, new_n246_,
    new_n247_, new_n248_, new_n249_, new_n250_, new_n251_, new_n252_,
    new_n253_, new_n254_, new_n255_, new_n256_, new_n257_, new_n258_,
    new_n259_, new_n260_, new_n261_, new_n262_, new_n263_, new_n264_,
    new_n265_, new_n267_, new_n268_, new_n269_, new_n270_, new_n271_,
    new_n272_, new_n273_, new_n274_, new_n275_, new_n276_, new_n277_,
    new_n278_, new_n279_, new_n280_, new_n281_, new_n282_, new_n283_,
    new_n284_, new_n285_, new_n286_, new_n288_, new_n289_, new_n290_,
    new_n291_, new_n292_, new_n293_, new_n294_, new_n295_, new_n296_,
    new_n297_, new_n298_, new_n300_, new_n301_, new_n302_, new_n303_,
    new_n304_, new_n305_, new_n306_, new_n307_, new_n308_, new_n309_,
    new_n310_;
  INVx1_ASAP7_75t_R   g000(.A(p8), .Y(new_n44_));
  INVx1_ASAP7_75t_R   g001(.A(p9), .Y(new_n45_));
  NAND2x1_ASAP7_75t_R g002(.A(p10), .B(new_n45_), .Y(new_n46_));
  OAI21x1_ASAP7_75t_R g003(.A1(new_n44_), .A2(p7), .B(new_n46_), .Y(new_n47_));
  INVx1_ASAP7_75t_R   g004(.A(p12), .Y(new_n48_));
  INVx1_ASAP7_75t_R   g005(.A(p5), .Y(new_n49_));
  NAND2x1_ASAP7_75t_R g006(.A(p6), .B(new_n49_), .Y(new_n50_));
  OAI21x1_ASAP7_75t_R g007(.A1(p11), .A2(new_n48_), .B(new_n50_), .Y(new_n51_));
  NOR2x1_ASAP7_75t_R  g008(.A(new_n47_), .B(new_n51_), .Y(new_n52_));
  INVx1_ASAP7_75t_R   g009(.A(p14), .Y(new_n53_));
  NOR2x1_ASAP7_75t_R  g010(.A(p13), .B(new_n53_), .Y(new_n54_));
  INVx1_ASAP7_75t_R   g011(.A(p16), .Y(new_n55_));
  NOR2x1_ASAP7_75t_R  g012(.A(p15), .B(new_n55_), .Y(new_n56_));
  NOR2x1_ASAP7_75t_R  g013(.A(new_n54_), .B(new_n56_), .Y(new_n57_));
  INVx1_ASAP7_75t_R   g014(.A(p35), .Y(new_n58_));
  NAND2x1_ASAP7_75t_R g015(.A(p0), .B(new_n58_), .Y(new_n59_));
  INVx1_ASAP7_75t_R   g016(.A(p3), .Y(new_n60_));
  NAND2x1_ASAP7_75t_R g017(.A(p4), .B(new_n60_), .Y(new_n61_));
  INVx1_ASAP7_75t_R   g018(.A(p1), .Y(new_n62_));
  NAND2x1_ASAP7_75t_R g019(.A(p2), .B(new_n62_), .Y(new_n63_));
  AND3x1_ASAP7_75t_R  g020(.A(new_n59_), .B(new_n61_), .C(new_n63_), .Y(new_n64_));
  NAND3x1_ASAP7_75t_R g021(.A(new_n52_), .B(new_n57_), .C(new_n64_), .Y(o0));
  INVx1_ASAP7_75t_R   g022(.A(p20), .Y(new_n66_));
  NAND2x1_ASAP7_75t_R g023(.A(p6), .B(new_n66_), .Y(new_n67_));
  AO21x1_ASAP7_75t_R  g024(.A1(new_n50_), .A2(o0), .B(new_n67_), .Y(new_n68_));
  NOR2x1_ASAP7_75t_R  g025(.A(p11), .B(new_n48_), .Y(new_n69_));
  INVx1_ASAP7_75t_R   g026(.A(new_n69_), .Y(new_n70_));
  INVx1_ASAP7_75t_R   g027(.A(p13), .Y(new_n71_));
  NAND2x1_ASAP7_75t_R g028(.A(p14), .B(new_n71_), .Y(new_n72_));
  INVx1_ASAP7_75t_R   g029(.A(p15), .Y(new_n73_));
  NAND2x1_ASAP7_75t_R g030(.A(p16), .B(new_n73_), .Y(new_n74_));
  AND3x1_ASAP7_75t_R  g031(.A(new_n72_), .B(new_n74_), .C(p12), .Y(new_n75_));
  NAND3x1_ASAP7_75t_R g032(.A(new_n52_), .B(new_n64_), .C(new_n75_), .Y(new_n76_));
  AO21x1_ASAP7_75t_R  g033(.A1(new_n70_), .A2(new_n76_), .B(p23), .Y(new_n77_));
  INVx1_ASAP7_75t_R   g034(.A(p18), .Y(new_n78_));
  INVx1_ASAP7_75t_R   g035(.A(p4), .Y(new_n79_));
  NOR2x1_ASAP7_75t_R  g036(.A(p3), .B(new_n79_), .Y(new_n80_));
  INVx1_ASAP7_75t_R   g037(.A(p2), .Y(new_n81_));
  NOR2x1_ASAP7_75t_R  g038(.A(p1), .B(new_n81_), .Y(new_n82_));
  NOR2x1_ASAP7_75t_R  g039(.A(new_n80_), .B(new_n82_), .Y(new_n83_));
  NAND3x1_ASAP7_75t_R g040(.A(new_n57_), .B(new_n83_), .C(new_n59_), .Y(new_n84_));
  NOR2x1_ASAP7_75t_R  g041(.A(p7), .B(new_n44_), .Y(new_n85_));
  AOI21x1_ASAP7_75t_R g042(.A1(new_n45_), .A2(p10), .B(new_n85_), .Y(new_n86_));
  AOI21x1_ASAP7_75t_R g043(.A1(p6), .A2(new_n49_), .B(new_n69_), .Y(new_n87_));
  NAND3x1_ASAP7_75t_R g044(.A(new_n86_), .B(new_n87_), .C(p2), .Y(new_n88_));
  OAI21x1_ASAP7_75t_R g045(.A1(new_n84_), .A2(new_n88_), .B(new_n63_), .Y(new_n89_));
  NAND2x1_ASAP7_75t_R g046(.A(new_n78_), .B(new_n89_), .Y(new_n90_));
  AND3x1_ASAP7_75t_R  g047(.A(new_n68_), .B(new_n77_), .C(new_n90_), .Y(new_n91_));
  AOI21x1_ASAP7_75t_R g048(.A1(new_n64_), .A2(new_n52_), .B(new_n56_), .Y(new_n92_));
  INVx1_ASAP7_75t_R   g049(.A(p25), .Y(new_n93_));
  AO21x1_ASAP7_75t_R  g050(.A1(p16), .A2(new_n72_), .B(new_n56_), .Y(new_n94_));
  NAND2x1_ASAP7_75t_R g051(.A(new_n93_), .B(new_n94_), .Y(new_n95_));
  NAND2x1_ASAP7_75t_R g052(.A(new_n72_), .B(new_n74_), .Y(new_n96_));
  NOR3x1_ASAP7_75t_R  g053(.A(new_n96_), .B(new_n47_), .C(new_n51_), .Y(new_n97_));
  NAND2x1_ASAP7_75t_R g054(.A(new_n59_), .B(new_n63_), .Y(new_n98_));
  INVx1_ASAP7_75t_R   g055(.A(p19), .Y(new_n99_));
  NAND2x1_ASAP7_75t_R g056(.A(p4), .B(new_n99_), .Y(new_n100_));
  AOI21x1_ASAP7_75t_R g057(.A1(new_n61_), .A2(new_n98_), .B(new_n100_), .Y(new_n101_));
  OAI21x1_ASAP7_75t_R g058(.A1(new_n80_), .A2(new_n97_), .B(new_n101_), .Y(new_n102_));
  OAI21x1_ASAP7_75t_R g059(.A1(new_n92_), .A2(new_n95_), .B(new_n102_), .Y(new_n103_));
  NAND2x1_ASAP7_75t_R g060(.A(new_n61_), .B(new_n63_), .Y(new_n104_));
  NOR2x1_ASAP7_75t_R  g061(.A(new_n96_), .B(new_n104_), .Y(new_n105_));
  NAND2x1_ASAP7_75t_R g062(.A(new_n52_), .B(new_n105_), .Y(new_n106_));
  INVx1_ASAP7_75t_R   g063(.A(p0), .Y(new_n107_));
  NOR2x1_ASAP7_75t_R  g064(.A(p17), .B(new_n107_), .Y(new_n108_));
  INVx1_ASAP7_75t_R   g065(.A(new_n108_), .Y(new_n109_));
  AOI21x1_ASAP7_75t_R g066(.A1(new_n59_), .A2(new_n106_), .B(new_n109_), .Y(new_n110_));
  NOR2x1_ASAP7_75t_R  g067(.A(p24), .B(new_n53_), .Y(new_n111_));
  INVx1_ASAP7_75t_R   g068(.A(new_n111_), .Y(new_n112_));
  NAND2x1_ASAP7_75t_R g069(.A(new_n74_), .B(new_n59_), .Y(new_n113_));
  NOR2x1_ASAP7_75t_R  g070(.A(new_n104_), .B(new_n113_), .Y(new_n114_));
  AOI21x1_ASAP7_75t_R g071(.A1(new_n52_), .A2(new_n114_), .B(new_n54_), .Y(new_n115_));
  NOR2x1_ASAP7_75t_R  g072(.A(new_n112_), .B(new_n115_), .Y(new_n116_));
  NOR3x1_ASAP7_75t_R  g073(.A(new_n103_), .B(new_n110_), .C(new_n116_), .Y(new_n117_));
  NAND3x1_ASAP7_75t_R g074(.A(new_n86_), .B(new_n87_), .C(new_n57_), .Y(new_n118_));
  NAND2x1_ASAP7_75t_R g075(.A(p8), .B(new_n64_), .Y(new_n119_));
  INVx1_ASAP7_75t_R   g076(.A(new_n85_), .Y(new_n120_));
  OAI21x1_ASAP7_75t_R g077(.A1(new_n118_), .A2(new_n119_), .B(new_n120_), .Y(new_n121_));
  NOR3x1_ASAP7_75t_R  g078(.A(new_n98_), .B(p7), .C(new_n80_), .Y(new_n122_));
  AOI21x1_ASAP7_75t_R g079(.A1(new_n122_), .A2(new_n97_), .B(p21), .Y(new_n123_));
  INVx1_ASAP7_75t_R   g080(.A(p10), .Y(new_n124_));
  OR2x4_ASAP7_75t_R   g081(.A(p22), .B(new_n124_), .Y(new_n125_));
  AOI21x1_ASAP7_75t_R g082(.A1(new_n46_), .A2(o0), .B(new_n125_), .Y(new_n126_));
  AOI21x1_ASAP7_75t_R g083(.A1(new_n121_), .A2(new_n123_), .B(new_n126_), .Y(new_n127_));
  NAND3x1_ASAP7_75t_R g084(.A(new_n91_), .B(new_n117_), .C(new_n127_), .Y(o1));
  NAND2x1_ASAP7_75t_R g085(.A(p2), .B(new_n78_), .Y(new_n129_));
  AOI21x1_ASAP7_75t_R g086(.A1(new_n63_), .A2(o0), .B(new_n129_), .Y(new_n130_));
  AOI21x1_ASAP7_75t_R g087(.A1(new_n70_), .A2(new_n76_), .B(p23), .Y(new_n131_));
  NAND2x1_ASAP7_75t_R g088(.A(p6), .B(new_n64_), .Y(new_n132_));
  OA21x2_ASAP7_75t_R  g089(.A1(new_n118_), .A2(new_n132_), .B(new_n50_), .Y(new_n133_));
  NOR3x1_ASAP7_75t_R  g090(.A(new_n130_), .B(new_n131_), .C(new_n133_), .Y(new_n134_));
  NAND3x1_ASAP7_75t_R g091(.A(new_n117_), .B(new_n134_), .C(new_n127_), .Y(new_n135_));
  AOI21x1_ASAP7_75t_R g092(.A1(new_n68_), .A2(new_n135_), .B(p29), .Y(new_n136_));
  INVx1_ASAP7_75t_R   g093(.A(p17), .Y(new_n137_));
  AOI21x1_ASAP7_75t_R g094(.A1(new_n127_), .A2(new_n117_), .B(new_n137_), .Y(new_n138_));
  NAND2x1_ASAP7_75t_R g095(.A(new_n57_), .B(new_n83_), .Y(new_n139_));
  NAND2x1_ASAP7_75t_R g096(.A(new_n86_), .B(new_n87_), .Y(new_n140_));
  OAI21x1_ASAP7_75t_R g097(.A1(new_n139_), .A2(new_n140_), .B(new_n59_), .Y(new_n141_));
  NAND2x1_ASAP7_75t_R g098(.A(p0), .B(new_n141_), .Y(new_n142_));
  NOR2x1_ASAP7_75t_R  g099(.A(p26), .B(new_n142_), .Y(new_n143_));
  INVx1_ASAP7_75t_R   g100(.A(new_n143_), .Y(new_n144_));
  NOR2x1_ASAP7_75t_R  g101(.A(new_n130_), .B(new_n131_), .Y(new_n145_));
  AOI21x1_ASAP7_75t_R g102(.A1(new_n68_), .A2(new_n145_), .B(new_n137_), .Y(new_n146_));
  NOR3x1_ASAP7_75t_R  g103(.A(new_n138_), .B(new_n144_), .C(new_n146_), .Y(new_n147_));
  NOR2x1_ASAP7_75t_R  g104(.A(new_n136_), .B(new_n147_), .Y(new_n148_));
  INVx1_ASAP7_75t_R   g105(.A(p21), .Y(new_n149_));
  AOI21x1_ASAP7_75t_R g106(.A1(new_n127_), .A2(new_n117_), .B(new_n149_), .Y(new_n150_));
  INVx1_ASAP7_75t_R   g107(.A(new_n121_), .Y(new_n151_));
  NOR2x1_ASAP7_75t_R  g108(.A(p30), .B(new_n151_), .Y(new_n152_));
  INVx1_ASAP7_75t_R   g109(.A(new_n152_), .Y(new_n153_));
  AOI21x1_ASAP7_75t_R g110(.A1(new_n68_), .A2(new_n145_), .B(new_n149_), .Y(new_n154_));
  NOR3x1_ASAP7_75t_R  g111(.A(new_n150_), .B(new_n153_), .C(new_n154_), .Y(new_n155_));
  INVx1_ASAP7_75t_R   g112(.A(p27), .Y(new_n156_));
  NAND2x1_ASAP7_75t_R g113(.A(p2), .B(new_n156_), .Y(new_n157_));
  AOI21x1_ASAP7_75t_R g114(.A1(new_n63_), .A2(o0), .B(new_n157_), .Y(new_n158_));
  INVx1_ASAP7_75t_R   g115(.A(p31), .Y(new_n159_));
  NAND2x1_ASAP7_75t_R g116(.A(p10), .B(new_n159_), .Y(new_n160_));
  AOI21x1_ASAP7_75t_R g117(.A1(new_n46_), .A2(o0), .B(new_n160_), .Y(new_n161_));
  NOR2x1_ASAP7_75t_R  g118(.A(new_n158_), .B(new_n161_), .Y(new_n162_));
  NOR2x1_ASAP7_75t_R  g119(.A(p32), .B(new_n48_), .Y(new_n163_));
  NAND2x1_ASAP7_75t_R g120(.A(p11), .B(o0), .Y(new_n164_));
  NOR2x1_ASAP7_75t_R  g121(.A(p28), .B(new_n79_), .Y(new_n165_));
  INVx1_ASAP7_75t_R   g122(.A(new_n165_), .Y(new_n166_));
  NOR2x1_ASAP7_75t_R  g123(.A(new_n96_), .B(new_n98_), .Y(new_n167_));
  AOI21x1_ASAP7_75t_R g124(.A1(new_n52_), .A2(new_n167_), .B(new_n80_), .Y(new_n168_));
  NOR2x1_ASAP7_75t_R  g125(.A(new_n166_), .B(new_n168_), .Y(new_n169_));
  AOI21x1_ASAP7_75t_R g126(.A1(new_n163_), .A2(new_n164_), .B(new_n169_), .Y(new_n170_));
  NOR2x1_ASAP7_75t_R  g127(.A(p35), .B(new_n107_), .Y(new_n171_));
  NOR2x1_ASAP7_75t_R  g128(.A(new_n56_), .B(new_n171_), .Y(new_n172_));
  NAND2x1_ASAP7_75t_R g129(.A(new_n83_), .B(new_n172_), .Y(new_n173_));
  OAI21x1_ASAP7_75t_R g130(.A1(new_n173_), .A2(new_n140_), .B(new_n72_), .Y(new_n174_));
  NOR2x1_ASAP7_75t_R  g131(.A(p33), .B(new_n53_), .Y(new_n175_));
  INVx1_ASAP7_75t_R   g132(.A(p34), .Y(new_n176_));
  NAND2x1_ASAP7_75t_R g133(.A(new_n176_), .B(new_n94_), .Y(new_n177_));
  NOR2x1_ASAP7_75t_R  g134(.A(new_n177_), .B(new_n92_), .Y(new_n178_));
  AOI21x1_ASAP7_75t_R g135(.A1(new_n174_), .A2(new_n175_), .B(new_n178_), .Y(new_n179_));
  AND3x1_ASAP7_75t_R  g136(.A(new_n162_), .B(new_n170_), .C(new_n179_), .Y(new_n180_));
  INVx1_ASAP7_75t_R   g137(.A(p32), .Y(new_n181_));
  AO21x1_ASAP7_75t_R  g138(.A1(new_n64_), .A2(new_n52_), .B(new_n56_), .Y(new_n182_));
  INVx1_ASAP7_75t_R   g139(.A(new_n95_), .Y(new_n183_));
  AND3x1_ASAP7_75t_R  g140(.A(new_n182_), .B(new_n176_), .C(new_n183_), .Y(new_n184_));
  AOI21x1_ASAP7_75t_R g141(.A1(new_n181_), .A2(new_n131_), .B(new_n184_), .Y(new_n185_));
  INVx1_ASAP7_75t_R   g142(.A(p33), .Y(new_n186_));
  AND3x1_ASAP7_75t_R  g143(.A(new_n174_), .B(new_n186_), .C(new_n111_), .Y(new_n187_));
  AOI21x1_ASAP7_75t_R g144(.A1(new_n99_), .A2(new_n169_), .B(new_n187_), .Y(new_n188_));
  OR3x1_ASAP7_75t_R   g145(.A(new_n124_), .B(p22), .C(p31), .Y(new_n189_));
  AOI21x1_ASAP7_75t_R g146(.A1(new_n46_), .A2(o0), .B(new_n189_), .Y(new_n190_));
  AOI21x1_ASAP7_75t_R g147(.A1(new_n78_), .A2(new_n158_), .B(new_n190_), .Y(new_n191_));
  AND3x1_ASAP7_75t_R  g148(.A(new_n185_), .B(new_n188_), .C(new_n191_), .Y(new_n192_));
  OAI21x1_ASAP7_75t_R g149(.A1(new_n180_), .A2(o1), .B(new_n192_), .Y(new_n193_));
  NOR2x1_ASAP7_75t_R  g150(.A(new_n155_), .B(new_n193_), .Y(new_n194_));
  NAND2x1_ASAP7_75t_R g151(.A(new_n148_), .B(new_n194_), .Y(o2));
  NAND3x1_ASAP7_75t_R g152(.A(new_n162_), .B(new_n170_), .C(new_n179_), .Y(new_n196_));
  NAND3x1_ASAP7_75t_R g153(.A(new_n68_), .B(new_n77_), .C(new_n90_), .Y(new_n197_));
  OR3x1_ASAP7_75t_R   g154(.A(new_n171_), .B(new_n80_), .C(new_n82_), .Y(new_n198_));
  OR3x1_ASAP7_75t_R   g155(.A(new_n54_), .B(new_n56_), .C(new_n44_), .Y(new_n199_));
  NOR3x1_ASAP7_75t_R  g156(.A(new_n140_), .B(new_n198_), .C(new_n199_), .Y(new_n200_));
  OAI21x1_ASAP7_75t_R g157(.A1(new_n85_), .A2(new_n200_), .B(new_n123_), .Y(new_n201_));
  NAND2x1_ASAP7_75t_R g158(.A(new_n108_), .B(new_n141_), .Y(new_n202_));
  NAND2x1_ASAP7_75t_R g159(.A(new_n111_), .B(new_n174_), .Y(new_n203_));
  NAND3x1_ASAP7_75t_R g160(.A(new_n201_), .B(new_n202_), .C(new_n203_), .Y(new_n204_));
  AO21x1_ASAP7_75t_R  g161(.A1(new_n46_), .A2(o0), .B(new_n125_), .Y(new_n205_));
  AO21x1_ASAP7_75t_R  g162(.A1(new_n61_), .A2(new_n98_), .B(new_n100_), .Y(new_n206_));
  AOI21x1_ASAP7_75t_R g163(.A1(new_n61_), .A2(new_n118_), .B(new_n206_), .Y(new_n207_));
  AOI21x1_ASAP7_75t_R g164(.A1(new_n182_), .A2(new_n183_), .B(new_n207_), .Y(new_n208_));
  NAND2x1_ASAP7_75t_R g165(.A(new_n205_), .B(new_n208_), .Y(new_n209_));
  NOR3x1_ASAP7_75t_R  g166(.A(new_n197_), .B(new_n204_), .C(new_n209_), .Y(new_n210_));
  NAND3x1_ASAP7_75t_R g167(.A(new_n185_), .B(new_n188_), .C(new_n191_), .Y(new_n211_));
  AOI21x1_ASAP7_75t_R g168(.A1(new_n196_), .A2(new_n210_), .B(new_n211_), .Y(new_n212_));
  OAI21x1_ASAP7_75t_R g169(.A1(new_n209_), .A2(new_n204_), .B(p17), .Y(new_n213_));
  NAND2x1_ASAP7_75t_R g170(.A(p17), .B(new_n197_), .Y(new_n214_));
  NAND3x1_ASAP7_75t_R g171(.A(new_n213_), .B(new_n214_), .C(new_n143_), .Y(new_n215_));
  OAI21x1_ASAP7_75t_R g172(.A1(new_n209_), .A2(new_n204_), .B(p20), .Y(new_n216_));
  NAND2x1_ASAP7_75t_R g173(.A(new_n90_), .B(new_n77_), .Y(new_n217_));
  AOI21x1_ASAP7_75t_R g174(.A1(p20), .A2(new_n217_), .B(new_n133_), .Y(new_n218_));
  INVx1_ASAP7_75t_R   g175(.A(p29), .Y(new_n219_));
  NAND3x1_ASAP7_75t_R g176(.A(new_n216_), .B(new_n218_), .C(new_n219_), .Y(new_n220_));
  NAND3x1_ASAP7_75t_R g177(.A(new_n212_), .B(new_n215_), .C(new_n220_), .Y(new_n221_));
  OAI21x1_ASAP7_75t_R g178(.A1(p20), .A2(new_n133_), .B(new_n102_), .Y(new_n222_));
  NOR3x1_ASAP7_75t_R  g179(.A(new_n222_), .B(new_n126_), .C(new_n130_), .Y(new_n223_));
  OAI21x1_ASAP7_75t_R g180(.A1(new_n112_), .A2(new_n115_), .B(new_n202_), .Y(new_n224_));
  AND2x2_ASAP7_75t_R  g181(.A(new_n123_), .B(new_n121_), .Y(new_n225_));
  AND3x1_ASAP7_75t_R  g182(.A(new_n83_), .B(p12), .C(new_n59_), .Y(new_n226_));
  AOI21x1_ASAP7_75t_R g183(.A1(new_n97_), .A2(new_n226_), .B(new_n69_), .Y(new_n227_));
  NAND3x1_ASAP7_75t_R g184(.A(new_n64_), .B(new_n86_), .C(new_n87_), .Y(new_n228_));
  AO21x1_ASAP7_75t_R  g185(.A1(new_n74_), .A2(new_n228_), .B(new_n95_), .Y(new_n229_));
  OAI21x1_ASAP7_75t_R g186(.A1(p23), .A2(new_n227_), .B(new_n229_), .Y(new_n230_));
  NOR3x1_ASAP7_75t_R  g187(.A(new_n224_), .B(new_n225_), .C(new_n230_), .Y(new_n231_));
  AOI21x1_ASAP7_75t_R g188(.A1(new_n223_), .A2(new_n231_), .B(new_n149_), .Y(new_n232_));
  AOI21x1_ASAP7_75t_R g189(.A1(p9), .A2(o0), .B(new_n124_), .Y(new_n233_));
  NAND3x1_ASAP7_75t_R g190(.A(new_n145_), .B(new_n68_), .C(new_n233_), .Y(new_n234_));
  NAND2x1_ASAP7_75t_R g191(.A(new_n127_), .B(new_n117_), .Y(new_n235_));
  OAI21x1_ASAP7_75t_R g192(.A1(new_n234_), .A2(new_n235_), .B(new_n205_), .Y(new_n236_));
  OAI21x1_ASAP7_75t_R g193(.A1(new_n153_), .A2(new_n232_), .B(new_n236_), .Y(new_n237_));
  AOI21x1_ASAP7_75t_R g194(.A1(new_n50_), .A2(o0), .B(new_n67_), .Y(new_n238_));
  AOI21x1_ASAP7_75t_R g195(.A1(p21), .A2(new_n238_), .B(new_n151_), .Y(new_n239_));
  OAI21x1_ASAP7_75t_R g196(.A1(new_n130_), .A2(new_n131_), .B(p21), .Y(new_n240_));
  NAND2x1_ASAP7_75t_R g197(.A(new_n239_), .B(new_n240_), .Y(new_n241_));
  NOR2x1_ASAP7_75t_R  g198(.A(new_n110_), .B(new_n116_), .Y(new_n242_));
  AOI21x1_ASAP7_75t_R g199(.A1(new_n208_), .A2(new_n242_), .B(new_n149_), .Y(new_n243_));
  AOI21x1_ASAP7_75t_R g200(.A1(new_n201_), .A2(new_n205_), .B(new_n149_), .Y(new_n244_));
  NOR3x1_ASAP7_75t_R  g201(.A(new_n241_), .B(new_n243_), .C(new_n244_), .Y(new_n245_));
  NAND3x1_ASAP7_75t_R g202(.A(new_n196_), .B(new_n231_), .C(new_n223_), .Y(new_n246_));
  AND3x1_ASAP7_75t_R  g203(.A(new_n245_), .B(new_n246_), .C(new_n192_), .Y(new_n247_));
  NOR2x1_ASAP7_75t_R  g204(.A(new_n209_), .B(new_n204_), .Y(new_n248_));
  AND3x1_ASAP7_75t_R  g205(.A(new_n145_), .B(new_n68_), .C(new_n233_), .Y(new_n249_));
  AOI21x1_ASAP7_75t_R g206(.A1(new_n248_), .A2(new_n249_), .B(new_n126_), .Y(new_n250_));
  OAI21x1_ASAP7_75t_R g207(.A1(new_n149_), .A2(new_n210_), .B(new_n152_), .Y(new_n251_));
  OAI21x1_ASAP7_75t_R g208(.A1(p31), .A2(new_n250_), .B(new_n251_), .Y(new_n252_));
  AOI21x1_ASAP7_75t_R g209(.A1(new_n247_), .A2(new_n148_), .B(new_n252_), .Y(new_n253_));
  OAI21x1_ASAP7_75t_R g210(.A1(new_n221_), .A2(new_n237_), .B(new_n253_), .Y(new_n254_));
  NAND2x1_ASAP7_75t_R g211(.A(p14), .B(new_n174_), .Y(new_n255_));
  OR3x1_ASAP7_75t_R   g212(.A(new_n235_), .B(new_n197_), .C(new_n255_), .Y(new_n256_));
  AO21x1_ASAP7_75t_R  g213(.A1(new_n203_), .A2(new_n256_), .B(new_n155_), .Y(new_n257_));
  AND2x2_ASAP7_75t_R  g214(.A(new_n175_), .B(new_n174_), .Y(new_n258_));
  AOI21x1_ASAP7_75t_R g215(.A1(new_n258_), .A2(new_n210_), .B(new_n187_), .Y(new_n259_));
  OAI21x1_ASAP7_75t_R g216(.A1(new_n221_), .A2(new_n257_), .B(new_n259_), .Y(new_n260_));
  AOI21x1_ASAP7_75t_R g217(.A1(p23), .A2(o1), .B(new_n227_), .Y(new_n261_));
  NAND2x1_ASAP7_75t_R g218(.A(new_n251_), .B(new_n261_), .Y(new_n262_));
  NAND2x1_ASAP7_75t_R g219(.A(new_n181_), .B(new_n261_), .Y(new_n263_));
  OAI21x1_ASAP7_75t_R g220(.A1(new_n262_), .A2(new_n221_), .B(new_n263_), .Y(new_n264_));
  NOR3x1_ASAP7_75t_R  g221(.A(new_n254_), .B(new_n260_), .C(new_n264_), .Y(new_n265_));
  INVx1_ASAP7_75t_R   g222(.A(new_n265_), .Y(o4));
  NOR2x1_ASAP7_75t_R  g223(.A(new_n142_), .B(o1), .Y(new_n267_));
  NAND3x1_ASAP7_75t_R g224(.A(new_n231_), .B(new_n223_), .C(new_n89_), .Y(new_n268_));
  NAND3x1_ASAP7_75t_R g225(.A(new_n268_), .B(new_n202_), .C(new_n90_), .Y(new_n269_));
  OAI21x1_ASAP7_75t_R g226(.A1(new_n267_), .A2(new_n269_), .B(new_n251_), .Y(new_n270_));
  AOI21x1_ASAP7_75t_R g227(.A1(new_n89_), .A2(new_n210_), .B(new_n130_), .Y(new_n271_));
  OA21x2_ASAP7_75t_R  g228(.A1(p27), .A2(new_n271_), .B(new_n215_), .Y(new_n272_));
  OAI21x1_ASAP7_75t_R g229(.A1(new_n221_), .A2(new_n270_), .B(new_n272_), .Y(new_n273_));
  AOI21x1_ASAP7_75t_R g230(.A1(new_n127_), .A2(new_n117_), .B(new_n99_), .Y(new_n274_));
  OR2x4_ASAP7_75t_R   g231(.A(new_n79_), .B(new_n168_), .Y(new_n275_));
  AOI21x1_ASAP7_75t_R g232(.A1(new_n68_), .A2(new_n145_), .B(new_n99_), .Y(new_n276_));
  NOR3x1_ASAP7_75t_R  g233(.A(new_n274_), .B(new_n275_), .C(new_n276_), .Y(new_n277_));
  OAI21x1_ASAP7_75t_R g234(.A1(new_n153_), .A2(new_n232_), .B(new_n277_), .Y(new_n278_));
  OAI21x1_ASAP7_75t_R g235(.A1(new_n99_), .A2(new_n210_), .B(new_n169_), .Y(new_n279_));
  OAI21x1_ASAP7_75t_R g236(.A1(new_n278_), .A2(new_n221_), .B(new_n279_), .Y(new_n280_));
  AO21x1_ASAP7_75t_R  g237(.A1(new_n68_), .A2(new_n135_), .B(new_n155_), .Y(new_n281_));
  OAI21x1_ASAP7_75t_R g238(.A1(new_n221_), .A2(new_n281_), .B(new_n220_), .Y(new_n282_));
  NOR3x1_ASAP7_75t_R  g239(.A(new_n273_), .B(new_n280_), .C(new_n282_), .Y(new_n283_));
  NAND2x1_ASAP7_75t_R g240(.A(new_n94_), .B(new_n182_), .Y(new_n284_));
  AO21x1_ASAP7_75t_R  g241(.A1(p25), .A2(o1), .B(new_n284_), .Y(new_n285_));
  AOI21x1_ASAP7_75t_R g242(.A1(p34), .A2(o2), .B(new_n285_), .Y(new_n286_));
  AOI21x1_ASAP7_75t_R g243(.A1(new_n283_), .A2(new_n265_), .B(new_n286_), .Y(o3));
  NAND3x1_ASAP7_75t_R g244(.A(new_n245_), .B(new_n246_), .C(new_n192_), .Y(new_n288_));
  AOI21x1_ASAP7_75t_R g245(.A1(new_n223_), .A2(new_n231_), .B(new_n137_), .Y(new_n289_));
  OAI21x1_ASAP7_75t_R g246(.A1(new_n144_), .A2(new_n289_), .B(new_n220_), .Y(new_n290_));
  AOI21x1_ASAP7_75t_R g247(.A1(new_n159_), .A2(new_n236_), .B(new_n155_), .Y(new_n291_));
  OAI21x1_ASAP7_75t_R g248(.A1(new_n288_), .A2(new_n290_), .B(new_n291_), .Y(new_n292_));
  NOR3x1_ASAP7_75t_R  g249(.A(new_n290_), .B(new_n237_), .C(new_n193_), .Y(new_n293_));
  NOR2x1_ASAP7_75t_R  g250(.A(new_n292_), .B(new_n293_), .Y(new_n294_));
  OA21x2_ASAP7_75t_R  g251(.A1(new_n262_), .A2(new_n221_), .B(new_n263_), .Y(new_n295_));
  NAND3x1_ASAP7_75t_R g252(.A(new_n294_), .B(new_n295_), .C(new_n282_), .Y(new_n296_));
  NAND2x1_ASAP7_75t_R g253(.A(new_n280_), .B(new_n294_), .Y(new_n297_));
  NOR2x1_ASAP7_75t_R  g254(.A(new_n264_), .B(new_n260_), .Y(new_n298_));
  NAND3x1_ASAP7_75t_R g255(.A(new_n296_), .B(new_n297_), .C(new_n298_), .Y(o5));
  NOR3x1_ASAP7_75t_R  g256(.A(new_n278_), .B(new_n290_), .C(new_n193_), .Y(new_n300_));
  NAND2x1_ASAP7_75t_R g257(.A(new_n159_), .B(new_n236_), .Y(new_n301_));
  NAND2x1_ASAP7_75t_R g258(.A(new_n279_), .B(new_n301_), .Y(new_n302_));
  NOR3x1_ASAP7_75t_R  g259(.A(new_n300_), .B(new_n293_), .C(new_n302_), .Y(new_n303_));
  AOI21x1_ASAP7_75t_R g260(.A1(new_n148_), .A2(new_n194_), .B(new_n156_), .Y(new_n304_));
  AOI21x1_ASAP7_75t_R g261(.A1(new_n181_), .A2(new_n261_), .B(new_n271_), .Y(new_n305_));
  OAI21x1_ASAP7_75t_R g262(.A1(new_n262_), .A2(new_n221_), .B(new_n305_), .Y(new_n306_));
  NOR2x1_ASAP7_75t_R  g263(.A(new_n304_), .B(new_n306_), .Y(new_n307_));
  NAND2x1_ASAP7_75t_R g264(.A(new_n303_), .B(new_n307_), .Y(new_n308_));
  OAI21x1_ASAP7_75t_R g265(.A1(new_n237_), .A2(new_n221_), .B(new_n301_), .Y(new_n309_));
  AOI21x1_ASAP7_75t_R g266(.A1(new_n309_), .A2(new_n295_), .B(new_n260_), .Y(new_n310_));
  NAND3x1_ASAP7_75t_R g267(.A(new_n308_), .B(new_n296_), .C(new_n310_), .Y(o6));
endmodule


