// Benchmark "/tmp/" written by ABC on Mon Oct 12 14:40:51 2026

module \/tmp/  ( 
    p13, p29, p18, p28, p21, p6, p19, p25, p26, p4, p8, p22, p15, p34, p3,
    p2, p11, p14, p35, p24, p23, p30, p27, p0, p16, p31, p33, p1, p20, p9,
    p10, p32, p12, p7, p17, p5,
    o0, o1, o2, o4, o3, o5, o6  );
  input  p13, p29, p18, p28, p21, p6, p19, p25, p26, p4, p8, p22, p15,
    p34, p3, p2, p11, p14, p35, p24, p23, p30, p27, p0, p16, p31, p33, p1,
    p20, p9, p10, p32, p12, p7, p17, p5;
  output o0, o1, o2, o4, o3, o5, o6;
  wire new_n44_, new_n45_, new_n46_, new_n47_, new_n48_, new_n49_, new_n50_,
    new_n51_, new_n52_, new_n53_, new_n54_, new_n55_, new_n56_, new_n57_,
    new_n58_, new_n59_, new_n60_, new_n61_, new_n62_, new_n63_, new_n64_,
    new_n65_, new_n67_, new_n68_, new_n69_, new_n70_, new_n71_, new_n72_,
    new_n73_, new_n74_, new_n75_, new_n76_, new_n77_, new_n78_, new_n79_,
    new_n80_, new_n81_, new_n82_, new_n83_, new_n84_, new_n85_, new_n86_,
    new_n87_, new_n88_, new_n89_, new_n90_, new_n91_, new_n92_, new_n93_,
    new_n94_, new_n95_, new_n96_, new_n97_, new_n98_, new_n99_, new_n100_,
    new_n101_, new_n102_, new_n103_, new_n104_, new_n105_, new_n106_,
    new_n107_, new_n108_, new_n109_, new_n110_, new_n111_, new_n112_,
    new_n113_, new_n114_, new_n115_, new_n116_, new_n117_, new_n118_,
    new_n119_, new_n120_, new_n121_, new_n122_, new_n123_, new_n124_,
    new_n125_, new_n126_, new_n127_, new_n129_, new_n130_, new_n131_,
    new_n132_, new_n133_, new_n134_, new_n135_, new_n136_, new_n137_,
    new_n138_, new_n139_, new_n140_, new_n141_, new_n142_, new_n143_,
    new_n144_, new_n145_, new_n146_, new_n147_, new_n148_, new_n149_,
    new_n150_, new_n151_, new_n152_, new_n153_, new_n154_, new_n155_,
    new_n156_, new_n157_, new_n158_, new_n159_, new_n160_, new_n161_,
    new_n162_, new_n163_, new_n164_, new_n165_, new_n166_, new_n167_,
    new_n168_, new_n169_, new_n170_, new_n171_, new_n172_, new_n173_,
    new_n174_, new_n175_, new_n176_, new_n177_, new_n178_, new_n179_,
    new_n180_, new_n181_, new_n182_, new_n183_, new_n184_, new_n185_,
    new_n186_, new_n187_, new_n188_, new_n189_, new_n190_, new_n191_,
    new_n192_, new_n193_, new_n194_, new_n195_, new_n196_, new_n197_,
    new_n198_, new_n199_, new_n200_, new_n201_, new_n202_, new_n203_,
    new_n204_, new_n206_, new_n207_, new_n208_, new_n209_, new_n210_,
    new_n211_, new_n212_, new_n213_, new_n214_, new_n215_, new_n216_,
    new_n217_, new_n218_, new_n219_, new_n220_, new_n221_, new_n222_,
    new_n223_, new_n224_, new_n225_, new_n226_, new_n227_, new_n228_,
    new_n229_, new_n230_, new_n231_, new_n232_, new_n233_, new_n234_,
    new_n235_, new_n236_, new_n237_, new_n238_, new_n239_, new_n240_,
    new_n241_, new_n242_, new_n243_, new_n245_, new_n246_, new_n247_,
    new_n248_, new_n249_, new_n250_, new_n251_, new_n252_, new_n253_,
    new_n254_, new_n255_, new_n256_, new_n257_, new_n258_, new_n259_,
    new_n260_, new_n261_, new_n262_, new_n263_, new_n265_, new_n266_,
    new_n267_, new_n268_, new_n269_, new_n270_, new_n271_, new_n272_,
    new_n273_, new_n274_, new_n275_, new_n276_, new_n277_, new_n278_,
    new_n279_, new_n280_, new_n281_, new_n282_, new_n283_, new_n284_,
    new_n285_, new_n286_, new_n287_, new_n288_, new_n289_, new_n290_,
    new_n291_, new_n292_, new_n293_, new_n294_, new_n295_, new_n296_,
    new_n297_, new_n298_, new_n299_, new_n301_, new_n302_, new_n303_,
    new_n304_, new_n305_, new_n306_, new_n307_, new_n308_, new_n309_;
  INVx1_ASAP7_75t_R   g000(.A(p4), .Y(new_n44_));
  NOR2x1_ASAP7_75t_R  g001(.A(p3), .B(new_n44_), .Y(new_n45_));
  INVx1_ASAP7_75t_R   g002(.A(p0), .Y(new_n46_));
  NOR2x1_ASAP7_75t_R  g003(.A(p35), .B(new_n46_), .Y(new_n47_));
  INVx1_ASAP7_75t_R   g004(.A(p2), .Y(new_n48_));
  NOR2x1_ASAP7_75t_R  g005(.A(p1), .B(new_n48_), .Y(new_n49_));
  OR3x1_ASAP7_75t_R   g006(.A(new_n45_), .B(new_n47_), .C(new_n49_), .Y(new_n50_));
  INVx1_ASAP7_75t_R   g007(.A(p11), .Y(new_n51_));
  NAND2x1_ASAP7_75t_R g008(.A(p12), .B(new_n51_), .Y(new_n52_));
  INVx1_ASAP7_75t_R   g009(.A(p5), .Y(new_n53_));
  NAND2x1_ASAP7_75t_R g010(.A(p6), .B(new_n53_), .Y(new_n54_));
  INVx1_ASAP7_75t_R   g011(.A(p7), .Y(new_n55_));
  NAND2x1_ASAP7_75t_R g012(.A(p8), .B(new_n55_), .Y(new_n56_));
  NAND3x1_ASAP7_75t_R g013(.A(new_n52_), .B(new_n54_), .C(new_n56_), .Y(new_n57_));
  INVx1_ASAP7_75t_R   g014(.A(p15), .Y(new_n58_));
  NAND2x1_ASAP7_75t_R g015(.A(p16), .B(new_n58_), .Y(new_n59_));
  INVx1_ASAP7_75t_R   g016(.A(p13), .Y(new_n60_));
  NAND2x1_ASAP7_75t_R g017(.A(p14), .B(new_n60_), .Y(new_n61_));
  INVx1_ASAP7_75t_R   g018(.A(p9), .Y(new_n62_));
  NAND2x1_ASAP7_75t_R g019(.A(p10), .B(new_n62_), .Y(new_n63_));
  NAND3x1_ASAP7_75t_R g020(.A(new_n59_), .B(new_n61_), .C(new_n63_), .Y(new_n64_));
  NOR3x1_ASAP7_75t_R  g021(.A(new_n50_), .B(new_n57_), .C(new_n64_), .Y(new_n65_));
  INVx1_ASAP7_75t_R   g022(.A(new_n65_), .Y(o0));
  INVx1_ASAP7_75t_R   g023(.A(p1), .Y(new_n67_));
  NAND2x1_ASAP7_75t_R g024(.A(p2), .B(new_n67_), .Y(new_n68_));
  NAND2x1_ASAP7_75t_R g025(.A(new_n52_), .B(new_n54_), .Y(new_n69_));
  NAND2x1_ASAP7_75t_R g026(.A(new_n56_), .B(new_n63_), .Y(new_n70_));
  NOR2x1_ASAP7_75t_R  g027(.A(new_n69_), .B(new_n70_), .Y(new_n71_));
  INVx1_ASAP7_75t_R   g028(.A(p35), .Y(new_n72_));
  NAND2x1_ASAP7_75t_R g029(.A(p0), .B(new_n72_), .Y(new_n73_));
  OAI21x1_ASAP7_75t_R g030(.A1(new_n48_), .A2(p1), .B(new_n73_), .Y(new_n74_));
  INVx1_ASAP7_75t_R   g031(.A(p3), .Y(new_n75_));
  NAND2x1_ASAP7_75t_R g032(.A(p4), .B(new_n75_), .Y(new_n76_));
  NAND2x1_ASAP7_75t_R g033(.A(new_n59_), .B(new_n76_), .Y(new_n77_));
  NOR2x1_ASAP7_75t_R  g034(.A(new_n74_), .B(new_n77_), .Y(new_n78_));
  INVx1_ASAP7_75t_R   g035(.A(p14), .Y(new_n79_));
  NOR2x1_ASAP7_75t_R  g036(.A(p13), .B(new_n79_), .Y(new_n80_));
  NOR2x1_ASAP7_75t_R  g037(.A(new_n48_), .B(new_n80_), .Y(new_n81_));
  NAND3x1_ASAP7_75t_R g038(.A(new_n71_), .B(new_n78_), .C(new_n81_), .Y(new_n82_));
  AOI21x1_ASAP7_75t_R g039(.A1(new_n68_), .A2(new_n82_), .B(p18), .Y(new_n83_));
  INVx1_ASAP7_75t_R   g040(.A(p20), .Y(new_n84_));
  AND2x2_ASAP7_75t_R  g041(.A(p6), .B(new_n84_), .Y(new_n85_));
  OA21x2_ASAP7_75t_R  g042(.A1(new_n53_), .A2(new_n65_), .B(new_n85_), .Y(new_n86_));
  INVx1_ASAP7_75t_R   g043(.A(p12), .Y(new_n87_));
  NOR2x1_ASAP7_75t_R  g044(.A(p11), .B(new_n87_), .Y(new_n88_));
  NOR2x1_ASAP7_75t_R  g045(.A(p23), .B(new_n87_), .Y(new_n89_));
  OA21x2_ASAP7_75t_R  g046(.A1(new_n88_), .A2(new_n65_), .B(new_n89_), .Y(new_n90_));
  NOR3x1_ASAP7_75t_R  g047(.A(new_n83_), .B(new_n86_), .C(new_n90_), .Y(new_n91_));
  NOR2x1_ASAP7_75t_R  g048(.A(new_n57_), .B(new_n64_), .Y(new_n92_));
  NOR2x1_ASAP7_75t_R  g049(.A(new_n47_), .B(new_n49_), .Y(new_n93_));
  AND3x1_ASAP7_75t_R  g050(.A(new_n93_), .B(new_n55_), .C(new_n76_), .Y(new_n94_));
  AOI21x1_ASAP7_75t_R g051(.A1(new_n92_), .A2(new_n94_), .B(p21), .Y(new_n95_));
  INVx1_ASAP7_75t_R   g052(.A(p8), .Y(new_n96_));
  NOR2x1_ASAP7_75t_R  g053(.A(new_n96_), .B(new_n80_), .Y(new_n97_));
  INVx1_ASAP7_75t_R   g054(.A(new_n97_), .Y(new_n98_));
  NAND2x1_ASAP7_75t_R g055(.A(new_n78_), .B(new_n71_), .Y(new_n99_));
  OAI21x1_ASAP7_75t_R g056(.A1(new_n98_), .A2(new_n99_), .B(new_n56_), .Y(new_n100_));
  INVx1_ASAP7_75t_R   g057(.A(p10), .Y(new_n101_));
  NOR2x1_ASAP7_75t_R  g058(.A(p9), .B(new_n101_), .Y(new_n102_));
  NOR2x1_ASAP7_75t_R  g059(.A(p22), .B(new_n101_), .Y(new_n103_));
  OA21x2_ASAP7_75t_R  g060(.A1(new_n102_), .A2(new_n65_), .B(new_n103_), .Y(new_n104_));
  AOI21x1_ASAP7_75t_R g061(.A1(new_n95_), .A2(new_n100_), .B(new_n104_), .Y(new_n105_));
  NOR2x1_ASAP7_75t_R  g062(.A(p24), .B(new_n79_), .Y(new_n106_));
  INVx1_ASAP7_75t_R   g063(.A(new_n106_), .Y(new_n107_));
  AOI21x1_ASAP7_75t_R g064(.A1(new_n78_), .A2(new_n71_), .B(new_n80_), .Y(new_n108_));
  NAND2x1_ASAP7_75t_R g065(.A(new_n76_), .B(new_n68_), .Y(new_n109_));
  INVx1_ASAP7_75t_R   g066(.A(p17), .Y(new_n110_));
  NAND2x1_ASAP7_75t_R g067(.A(p0), .B(new_n110_), .Y(new_n111_));
  AOI21x1_ASAP7_75t_R g068(.A1(new_n73_), .A2(new_n109_), .B(new_n111_), .Y(new_n112_));
  OAI21x1_ASAP7_75t_R g069(.A1(new_n57_), .A2(new_n64_), .B(new_n73_), .Y(new_n113_));
  NAND2x1_ASAP7_75t_R g070(.A(new_n112_), .B(new_n113_), .Y(new_n114_));
  OAI21x1_ASAP7_75t_R g071(.A1(new_n107_), .A2(new_n108_), .B(new_n114_), .Y(new_n115_));
  AND3x1_ASAP7_75t_R  g072(.A(new_n76_), .B(new_n73_), .C(new_n68_), .Y(new_n116_));
  INVx1_ASAP7_75t_R   g073(.A(p16), .Y(new_n117_));
  NOR2x1_ASAP7_75t_R  g074(.A(p15), .B(new_n117_), .Y(new_n118_));
  AOI21x1_ASAP7_75t_R g075(.A1(new_n116_), .A2(new_n71_), .B(new_n118_), .Y(new_n119_));
  AO21x1_ASAP7_75t_R  g076(.A1(p15), .A2(new_n80_), .B(new_n117_), .Y(new_n120_));
  NOR2x1_ASAP7_75t_R  g077(.A(p25), .B(new_n120_), .Y(new_n121_));
  INVx1_ASAP7_75t_R   g078(.A(new_n121_), .Y(new_n122_));
  NOR2x1_ASAP7_75t_R  g079(.A(p19), .B(new_n44_), .Y(new_n123_));
  OA21x2_ASAP7_75t_R  g080(.A1(new_n45_), .A2(new_n93_), .B(new_n123_), .Y(new_n124_));
  OAI21x1_ASAP7_75t_R g081(.A1(new_n45_), .A2(new_n92_), .B(new_n124_), .Y(new_n125_));
  OAI21x1_ASAP7_75t_R g082(.A1(new_n119_), .A2(new_n122_), .B(new_n125_), .Y(new_n126_));
  NOR2x1_ASAP7_75t_R  g083(.A(new_n115_), .B(new_n126_), .Y(new_n127_));
  NAND3x1_ASAP7_75t_R g084(.A(new_n91_), .B(new_n105_), .C(new_n127_), .Y(o1));
  OR2x4_ASAP7_75t_R   g085(.A(p30), .B(new_n96_), .Y(new_n129_));
  AO21x1_ASAP7_75t_R  g086(.A1(p7), .A2(o0), .B(new_n129_), .Y(new_n130_));
  AOI21x1_ASAP7_75t_R g087(.A1(p21), .A2(o1), .B(new_n130_), .Y(new_n131_));
  AO21x1_ASAP7_75t_R  g088(.A1(new_n78_), .A2(new_n71_), .B(new_n80_), .Y(new_n132_));
  NOR2x1_ASAP7_75t_R  g089(.A(p33), .B(new_n79_), .Y(new_n133_));
  NOR2x1_ASAP7_75t_R  g090(.A(p31), .B(new_n101_), .Y(new_n134_));
  OA21x2_ASAP7_75t_R  g091(.A1(new_n102_), .A2(new_n65_), .B(new_n134_), .Y(new_n135_));
  AOI21x1_ASAP7_75t_R g092(.A1(new_n132_), .A2(new_n133_), .B(new_n135_), .Y(new_n136_));
  INVx1_ASAP7_75t_R   g093(.A(p27), .Y(new_n137_));
  NAND2x1_ASAP7_75t_R g094(.A(new_n68_), .B(new_n82_), .Y(new_n138_));
  AO21x1_ASAP7_75t_R  g095(.A1(new_n73_), .A2(new_n68_), .B(new_n45_), .Y(new_n139_));
  INVx1_ASAP7_75t_R   g096(.A(p28), .Y(new_n140_));
  AND3x1_ASAP7_75t_R  g097(.A(new_n139_), .B(new_n140_), .C(p4), .Y(new_n141_));
  OA21x2_ASAP7_75t_R  g098(.A1(new_n45_), .A2(new_n92_), .B(new_n141_), .Y(new_n142_));
  AOI21x1_ASAP7_75t_R g099(.A1(new_n137_), .A2(new_n138_), .B(new_n142_), .Y(new_n143_));
  AOI21x1_ASAP7_75t_R g100(.A1(p6), .A2(new_n53_), .B(new_n88_), .Y(new_n144_));
  NOR2x1_ASAP7_75t_R  g101(.A(p7), .B(new_n96_), .Y(new_n145_));
  NOR2x1_ASAP7_75t_R  g102(.A(new_n145_), .B(new_n102_), .Y(new_n146_));
  AND3x1_ASAP7_75t_R  g103(.A(new_n116_), .B(new_n144_), .C(new_n146_), .Y(new_n147_));
  NOR2x1_ASAP7_75t_R  g104(.A(p34), .B(new_n120_), .Y(new_n148_));
  OAI21x1_ASAP7_75t_R g105(.A1(new_n118_), .A2(new_n147_), .B(new_n148_), .Y(new_n149_));
  NOR2x1_ASAP7_75t_R  g106(.A(p32), .B(new_n87_), .Y(new_n150_));
  OAI21x1_ASAP7_75t_R g107(.A1(new_n88_), .A2(new_n65_), .B(new_n150_), .Y(new_n151_));
  AND2x2_ASAP7_75t_R  g108(.A(new_n149_), .B(new_n151_), .Y(new_n152_));
  NAND3x1_ASAP7_75t_R g109(.A(new_n136_), .B(new_n143_), .C(new_n152_), .Y(new_n153_));
  AND3x1_ASAP7_75t_R  g110(.A(new_n71_), .B(new_n78_), .C(new_n81_), .Y(new_n154_));
  INVx1_ASAP7_75t_R   g111(.A(p18), .Y(new_n155_));
  OAI21x1_ASAP7_75t_R g112(.A1(new_n49_), .A2(new_n154_), .B(new_n155_), .Y(new_n156_));
  OAI21x1_ASAP7_75t_R g113(.A1(new_n53_), .A2(new_n65_), .B(new_n85_), .Y(new_n157_));
  OAI21x1_ASAP7_75t_R g114(.A1(new_n88_), .A2(new_n65_), .B(new_n89_), .Y(new_n158_));
  NAND3x1_ASAP7_75t_R g115(.A(new_n156_), .B(new_n157_), .C(new_n158_), .Y(new_n159_));
  NOR2x1_ASAP7_75t_R  g116(.A(new_n118_), .B(new_n80_), .Y(new_n160_));
  NAND3x1_ASAP7_75t_R g117(.A(new_n160_), .B(new_n144_), .C(new_n146_), .Y(new_n161_));
  AO21x1_ASAP7_75t_R  g118(.A1(new_n73_), .A2(new_n109_), .B(new_n111_), .Y(new_n162_));
  AOI21x1_ASAP7_75t_R g119(.A1(new_n73_), .A2(new_n161_), .B(new_n162_), .Y(new_n163_));
  AOI21x1_ASAP7_75t_R g120(.A1(new_n106_), .A2(new_n132_), .B(new_n163_), .Y(new_n164_));
  AO21x1_ASAP7_75t_R  g121(.A1(new_n116_), .A2(new_n71_), .B(new_n118_), .Y(new_n165_));
  NAND2x1_ASAP7_75t_R g122(.A(new_n123_), .B(new_n139_), .Y(new_n166_));
  AOI21x1_ASAP7_75t_R g123(.A1(new_n76_), .A2(new_n161_), .B(new_n166_), .Y(new_n167_));
  AOI21x1_ASAP7_75t_R g124(.A1(new_n121_), .A2(new_n165_), .B(new_n167_), .Y(new_n168_));
  NAND2x1_ASAP7_75t_R g125(.A(new_n164_), .B(new_n168_), .Y(new_n169_));
  INVx1_ASAP7_75t_R   g126(.A(new_n95_), .Y(new_n170_));
  NAND2x1_ASAP7_75t_R g127(.A(new_n146_), .B(new_n144_), .Y(new_n171_));
  NAND3x1_ASAP7_75t_R g128(.A(new_n93_), .B(new_n59_), .C(new_n76_), .Y(new_n172_));
  NOR2x1_ASAP7_75t_R  g129(.A(new_n171_), .B(new_n172_), .Y(new_n173_));
  AOI21x1_ASAP7_75t_R g130(.A1(new_n97_), .A2(new_n173_), .B(new_n145_), .Y(new_n174_));
  OAI21x1_ASAP7_75t_R g131(.A1(new_n102_), .A2(new_n65_), .B(new_n103_), .Y(new_n175_));
  OAI21x1_ASAP7_75t_R g132(.A1(new_n170_), .A2(new_n174_), .B(new_n175_), .Y(new_n176_));
  NOR3x1_ASAP7_75t_R  g133(.A(new_n159_), .B(new_n169_), .C(new_n176_), .Y(new_n177_));
  OR3x1_ASAP7_75t_R   g134(.A(new_n108_), .B(p33), .C(new_n107_), .Y(new_n178_));
  OAI21x1_ASAP7_75t_R g135(.A1(p28), .A2(new_n125_), .B(new_n178_), .Y(new_n179_));
  AND3x1_ASAP7_75t_R  g136(.A(new_n155_), .B(new_n137_), .C(p2), .Y(new_n180_));
  OAI21x1_ASAP7_75t_R g137(.A1(new_n67_), .A2(new_n65_), .B(new_n180_), .Y(new_n181_));
  OAI21x1_ASAP7_75t_R g138(.A1(p25), .A2(new_n149_), .B(new_n181_), .Y(new_n182_));
  INVx1_ASAP7_75t_R   g139(.A(p22), .Y(new_n183_));
  INVx1_ASAP7_75t_R   g140(.A(p31), .Y(new_n184_));
  AND3x1_ASAP7_75t_R  g141(.A(new_n183_), .B(new_n184_), .C(p10), .Y(new_n185_));
  OAI21x1_ASAP7_75t_R g142(.A1(new_n102_), .A2(new_n65_), .B(new_n185_), .Y(new_n186_));
  OAI21x1_ASAP7_75t_R g143(.A1(p23), .A2(new_n151_), .B(new_n186_), .Y(new_n187_));
  OR3x1_ASAP7_75t_R   g144(.A(new_n179_), .B(new_n182_), .C(new_n187_), .Y(new_n188_));
  AOI21x1_ASAP7_75t_R g145(.A1(new_n153_), .A2(new_n177_), .B(new_n188_), .Y(new_n189_));
  NAND2x1_ASAP7_75t_R g146(.A(new_n158_), .B(new_n156_), .Y(new_n190_));
  INVx1_ASAP7_75t_R   g147(.A(p29), .Y(new_n191_));
  OA21x2_ASAP7_75t_R  g148(.A1(new_n53_), .A2(new_n65_), .B(p6), .Y(new_n192_));
  NAND2x1_ASAP7_75t_R g149(.A(new_n191_), .B(new_n192_), .Y(new_n193_));
  AOI21x1_ASAP7_75t_R g150(.A1(p20), .A2(new_n190_), .B(new_n193_), .Y(new_n194_));
  AO21x1_ASAP7_75t_R  g151(.A1(new_n105_), .A2(new_n127_), .B(new_n84_), .Y(new_n195_));
  NAND2x1_ASAP7_75t_R g152(.A(new_n194_), .B(new_n195_), .Y(new_n196_));
  AO21x1_ASAP7_75t_R  g153(.A1(new_n105_), .A2(new_n127_), .B(new_n110_), .Y(new_n197_));
  OR3x1_ASAP7_75t_R   g154(.A(new_n109_), .B(new_n118_), .C(new_n80_), .Y(new_n198_));
  OA21x2_ASAP7_75t_R  g155(.A1(new_n171_), .A2(new_n198_), .B(new_n73_), .Y(new_n199_));
  OR3x1_ASAP7_75t_R   g156(.A(new_n199_), .B(p26), .C(new_n46_), .Y(new_n200_));
  AOI21x1_ASAP7_75t_R g157(.A1(p17), .A2(new_n159_), .B(new_n200_), .Y(new_n201_));
  NAND2x1_ASAP7_75t_R g158(.A(new_n197_), .B(new_n201_), .Y(new_n202_));
  NAND3x1_ASAP7_75t_R g159(.A(new_n189_), .B(new_n196_), .C(new_n202_), .Y(new_n203_));
  NOR2x1_ASAP7_75t_R  g160(.A(new_n131_), .B(new_n203_), .Y(new_n204_));
  INVx1_ASAP7_75t_R   g161(.A(new_n204_), .Y(o2));
  AO21x1_ASAP7_75t_R  g162(.A1(p11), .A2(o0), .B(new_n87_), .Y(new_n206_));
  OR3x1_ASAP7_75t_R   g163(.A(new_n206_), .B(new_n86_), .C(new_n83_), .Y(new_n207_));
  NAND2x1_ASAP7_75t_R g164(.A(new_n105_), .B(new_n127_), .Y(new_n208_));
  OA21x2_ASAP7_75t_R  g165(.A1(new_n207_), .A2(new_n208_), .B(new_n158_), .Y(new_n209_));
  AO21x1_ASAP7_75t_R  g166(.A1(p13), .A2(new_n99_), .B(new_n79_), .Y(new_n210_));
  AO21x1_ASAP7_75t_R  g167(.A1(p24), .A2(o1), .B(new_n210_), .Y(new_n211_));
  NAND2x1_ASAP7_75t_R g168(.A(new_n209_), .B(new_n211_), .Y(new_n212_));
  AOI21x1_ASAP7_75t_R g169(.A1(new_n105_), .A2(new_n127_), .B(new_n84_), .Y(new_n213_));
  NOR2x1_ASAP7_75t_R  g170(.A(new_n90_), .B(new_n83_), .Y(new_n214_));
  NOR2x1_ASAP7_75t_R  g171(.A(new_n84_), .B(new_n214_), .Y(new_n215_));
  NOR3x1_ASAP7_75t_R  g172(.A(new_n213_), .B(new_n193_), .C(new_n215_), .Y(new_n216_));
  AOI21x1_ASAP7_75t_R g173(.A1(new_n197_), .A2(new_n201_), .B(new_n216_), .Y(new_n217_));
  AND3x1_ASAP7_75t_R  g174(.A(new_n136_), .B(new_n143_), .C(new_n152_), .Y(new_n218_));
  NOR3x1_ASAP7_75t_R  g175(.A(new_n179_), .B(new_n182_), .C(new_n187_), .Y(new_n219_));
  OAI21x1_ASAP7_75t_R g176(.A1(new_n218_), .A2(o1), .B(new_n219_), .Y(new_n220_));
  NOR2x1_ASAP7_75t_R  g177(.A(new_n131_), .B(new_n220_), .Y(new_n221_));
  AND3x1_ASAP7_75t_R  g178(.A(new_n212_), .B(new_n217_), .C(new_n221_), .Y(new_n222_));
  OAI21x1_ASAP7_75t_R g179(.A1(new_n183_), .A2(new_n177_), .B(new_n135_), .Y(new_n223_));
  AO21x1_ASAP7_75t_R  g180(.A1(p21), .A2(o1), .B(new_n130_), .Y(new_n224_));
  NAND2x1_ASAP7_75t_R g181(.A(new_n223_), .B(new_n224_), .Y(new_n225_));
  NAND2x1_ASAP7_75t_R g182(.A(new_n133_), .B(new_n132_), .Y(new_n226_));
  OA21x2_ASAP7_75t_R  g183(.A1(new_n226_), .A2(o1), .B(new_n178_), .Y(new_n227_));
  OAI21x1_ASAP7_75t_R g184(.A1(p32), .A2(new_n209_), .B(new_n227_), .Y(new_n228_));
  NOR2x1_ASAP7_75t_R  g185(.A(new_n225_), .B(new_n228_), .Y(new_n229_));
  NOR2x1_ASAP7_75t_R  g186(.A(new_n176_), .B(new_n169_), .Y(new_n230_));
  NOR2x1_ASAP7_75t_R  g187(.A(new_n102_), .B(new_n65_), .Y(new_n231_));
  NOR2x1_ASAP7_75t_R  g188(.A(new_n101_), .B(new_n231_), .Y(new_n232_));
  AND3x1_ASAP7_75t_R  g189(.A(new_n214_), .B(new_n157_), .C(new_n232_), .Y(new_n233_));
  AOI21x1_ASAP7_75t_R g190(.A1(new_n230_), .A2(new_n233_), .B(new_n104_), .Y(new_n234_));
  NOR2x1_ASAP7_75t_R  g191(.A(new_n234_), .B(new_n131_), .Y(new_n235_));
  NAND3x1_ASAP7_75t_R g192(.A(new_n235_), .B(new_n217_), .C(new_n189_), .Y(new_n236_));
  INVx1_ASAP7_75t_R   g193(.A(p21), .Y(new_n237_));
  OA21x2_ASAP7_75t_R  g194(.A1(new_n237_), .A2(new_n157_), .B(new_n100_), .Y(new_n238_));
  OAI21x1_ASAP7_75t_R g195(.A1(new_n237_), .A2(new_n214_), .B(new_n238_), .Y(new_n239_));
  AOI21x1_ASAP7_75t_R g196(.A1(p21), .A2(new_n208_), .B(new_n239_), .Y(new_n240_));
  NAND3x1_ASAP7_75t_R g197(.A(new_n217_), .B(new_n240_), .C(new_n189_), .Y(new_n241_));
  NAND3x1_ASAP7_75t_R g198(.A(new_n229_), .B(new_n236_), .C(new_n241_), .Y(new_n242_));
  NOR2x1_ASAP7_75t_R  g199(.A(new_n222_), .B(new_n242_), .Y(new_n243_));
  INVx1_ASAP7_75t_R   g200(.A(new_n243_), .Y(o4));
  AND3x1_ASAP7_75t_R  g201(.A(new_n214_), .B(new_n157_), .C(new_n138_), .Y(new_n245_));
  AOI21x1_ASAP7_75t_R g202(.A1(new_n230_), .A2(new_n245_), .B(new_n83_), .Y(new_n246_));
  INVx1_ASAP7_75t_R   g203(.A(new_n142_), .Y(new_n247_));
  AO21x1_ASAP7_75t_R  g204(.A1(p19), .A2(o1), .B(new_n247_), .Y(new_n248_));
  OA21x2_ASAP7_75t_R  g205(.A1(p27), .A2(new_n246_), .B(new_n248_), .Y(new_n249_));
  OAI21x1_ASAP7_75t_R g206(.A1(new_n84_), .A2(new_n177_), .B(new_n192_), .Y(new_n250_));
  OR3x1_ASAP7_75t_R   g207(.A(new_n250_), .B(new_n220_), .C(new_n131_), .Y(new_n251_));
  NAND3x1_ASAP7_75t_R g208(.A(new_n249_), .B(new_n251_), .C(new_n217_), .Y(new_n252_));
  NAND2x1_ASAP7_75t_R g209(.A(new_n114_), .B(new_n246_), .Y(new_n253_));
  AND3x1_ASAP7_75t_R  g210(.A(new_n71_), .B(new_n160_), .C(new_n93_), .Y(new_n254_));
  OA21x2_ASAP7_75t_R  g211(.A1(new_n75_), .A2(new_n254_), .B(p4), .Y(new_n255_));
  AO21x1_ASAP7_75t_R  g212(.A1(new_n255_), .A2(new_n177_), .B(new_n167_), .Y(new_n256_));
  NOR3x1_ASAP7_75t_R  g213(.A(o1), .B(new_n46_), .C(new_n199_), .Y(new_n257_));
  NOR3x1_ASAP7_75t_R  g214(.A(new_n253_), .B(new_n256_), .C(new_n257_), .Y(new_n258_));
  NOR3x1_ASAP7_75t_R  g215(.A(new_n258_), .B(new_n131_), .C(new_n203_), .Y(new_n259_));
  NOR2x1_ASAP7_75t_R  g216(.A(new_n252_), .B(new_n259_), .Y(new_n260_));
  OR2x4_ASAP7_75t_R   g217(.A(new_n120_), .B(new_n119_), .Y(new_n261_));
  AO21x1_ASAP7_75t_R  g218(.A1(p25), .A2(o1), .B(new_n261_), .Y(new_n262_));
  AOI21x1_ASAP7_75t_R g219(.A1(p34), .A2(o2), .B(new_n262_), .Y(new_n263_));
  AOI21x1_ASAP7_75t_R g220(.A1(new_n260_), .A2(new_n243_), .B(new_n263_), .Y(o3));
  AND3x1_ASAP7_75t_R  g221(.A(new_n189_), .B(new_n196_), .C(new_n202_), .Y(new_n265_));
  OA21x2_ASAP7_75t_R  g222(.A1(new_n176_), .A2(new_n169_), .B(p17), .Y(new_n266_));
  AO21x1_ASAP7_75t_R  g223(.A1(p17), .A2(new_n159_), .B(new_n200_), .Y(new_n267_));
  OAI21x1_ASAP7_75t_R g224(.A1(new_n266_), .A2(new_n267_), .B(new_n196_), .Y(new_n268_));
  AO21x1_ASAP7_75t_R  g225(.A1(new_n61_), .A2(new_n99_), .B(new_n107_), .Y(new_n269_));
  OAI21x1_ASAP7_75t_R g226(.A1(new_n118_), .A2(new_n147_), .B(new_n121_), .Y(new_n270_));
  NAND3x1_ASAP7_75t_R g227(.A(new_n269_), .B(new_n270_), .C(new_n114_), .Y(new_n271_));
  NOR2x1_ASAP7_75t_R  g228(.A(new_n271_), .B(new_n176_), .Y(new_n272_));
  NAND2x1_ASAP7_75t_R g229(.A(new_n157_), .B(new_n158_), .Y(new_n273_));
  NOR3x1_ASAP7_75t_R  g230(.A(new_n273_), .B(new_n83_), .C(new_n167_), .Y(new_n274_));
  NAND3x1_ASAP7_75t_R g231(.A(new_n153_), .B(new_n272_), .C(new_n274_), .Y(new_n275_));
  NAND3x1_ASAP7_75t_R g232(.A(new_n275_), .B(new_n240_), .C(new_n219_), .Y(new_n276_));
  AO21x1_ASAP7_75t_R  g233(.A1(p9), .A2(o0), .B(new_n101_), .Y(new_n277_));
  AOI21x1_ASAP7_75t_R g234(.A1(p22), .A2(o1), .B(new_n277_), .Y(new_n278_));
  AOI21x1_ASAP7_75t_R g235(.A1(new_n184_), .A2(new_n278_), .B(new_n131_), .Y(new_n279_));
  OAI21x1_ASAP7_75t_R g236(.A1(new_n268_), .A2(new_n276_), .B(new_n279_), .Y(new_n280_));
  AOI21x1_ASAP7_75t_R g237(.A1(new_n265_), .A2(new_n235_), .B(new_n280_), .Y(new_n281_));
  NOR2x1_ASAP7_75t_R  g238(.A(p32), .B(new_n209_), .Y(new_n282_));
  INVx1_ASAP7_75t_R   g239(.A(new_n130_), .Y(new_n283_));
  NAND3x1_ASAP7_75t_R g240(.A(new_n272_), .B(new_n274_), .C(new_n283_), .Y(new_n284_));
  OAI21x1_ASAP7_75t_R g241(.A1(new_n207_), .A2(new_n208_), .B(new_n158_), .Y(new_n285_));
  NAND2x1_ASAP7_75t_R g242(.A(new_n237_), .B(new_n283_), .Y(new_n286_));
  NAND3x1_ASAP7_75t_R g243(.A(new_n284_), .B(new_n285_), .C(new_n286_), .Y(new_n287_));
  NOR3x1_ASAP7_75t_R  g244(.A(new_n287_), .B(new_n268_), .C(new_n220_), .Y(new_n288_));
  NOR2x1_ASAP7_75t_R  g245(.A(new_n282_), .B(new_n288_), .Y(new_n289_));
  OAI21x1_ASAP7_75t_R g246(.A1(new_n268_), .A2(new_n251_), .B(new_n196_), .Y(new_n290_));
  NAND3x1_ASAP7_75t_R g247(.A(new_n281_), .B(new_n289_), .C(new_n290_), .Y(new_n291_));
  NOR2x1_ASAP7_75t_R  g248(.A(new_n131_), .B(new_n211_), .Y(new_n292_));
  INVx1_ASAP7_75t_R   g249(.A(new_n227_), .Y(new_n293_));
  AO21x1_ASAP7_75t_R  g250(.A1(new_n292_), .A2(new_n265_), .B(new_n293_), .Y(new_n294_));
  NOR3x1_ASAP7_75t_R  g251(.A(new_n294_), .B(new_n282_), .C(new_n288_), .Y(new_n295_));
  AND3x1_ASAP7_75t_R  g252(.A(new_n272_), .B(new_n274_), .C(new_n255_), .Y(new_n296_));
  OAI21x1_ASAP7_75t_R g253(.A1(new_n167_), .A2(new_n296_), .B(new_n224_), .Y(new_n297_));
  OAI21x1_ASAP7_75t_R g254(.A1(new_n297_), .A2(new_n203_), .B(new_n248_), .Y(new_n298_));
  NAND2x1_ASAP7_75t_R g255(.A(new_n298_), .B(new_n281_), .Y(new_n299_));
  NAND3x1_ASAP7_75t_R g256(.A(new_n291_), .B(new_n295_), .C(new_n299_), .Y(o5));
  AOI21x1_ASAP7_75t_R g257(.A1(new_n217_), .A2(new_n221_), .B(new_n137_), .Y(new_n301_));
  INVx1_ASAP7_75t_R   g258(.A(p32), .Y(new_n302_));
  AO21x1_ASAP7_75t_R  g259(.A1(new_n302_), .A2(new_n285_), .B(new_n246_), .Y(new_n303_));
  NOR3x1_ASAP7_75t_R  g260(.A(new_n301_), .B(new_n288_), .C(new_n303_), .Y(new_n304_));
  NAND2x1_ASAP7_75t_R g261(.A(new_n278_), .B(new_n224_), .Y(new_n305_));
  OAI21x1_ASAP7_75t_R g262(.A1(new_n305_), .A2(new_n203_), .B(new_n223_), .Y(new_n306_));
  NOR2x1_ASAP7_75t_R  g263(.A(new_n298_), .B(new_n306_), .Y(new_n307_));
  NAND2x1_ASAP7_75t_R g264(.A(new_n304_), .B(new_n307_), .Y(new_n308_));
  AOI21x1_ASAP7_75t_R g265(.A1(new_n306_), .A2(new_n289_), .B(new_n294_), .Y(new_n309_));
  NAND3x1_ASAP7_75t_R g266(.A(new_n308_), .B(new_n291_), .C(new_n309_), .Y(o6));
endmodule


