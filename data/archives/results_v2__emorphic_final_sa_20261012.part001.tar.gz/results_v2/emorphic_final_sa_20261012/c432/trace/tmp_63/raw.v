// Benchmark "/tmp/" written by ABC on Mon Oct 12 14:40:57 2026

module \/tmp/  ( 
    p12, p4, p16, p21, p15, p19, p35, p26, p29, p17, p2, p22, p11, p8, p28,
    p23, p5, p13, p24, p31, p27, p7, p20, p10, p3, p25, p14, p32, p34, p6,
    p1, p9, p18, p33, p0, p30,
    o0, o1, o2, o4, o3, o5, o6  );
  input  p12, p4, p16, p21, p15, p19, p35, p26, p29, p17, p2, p22, p11,
    p8, p28, p23, p5, p13, p24, p31, p27, p7, p20, p10, p3, p25, p14, p32,
    p34, p6, p1, p9, p18, p33, p0, p30;
  output o0, o1, o2, o4, o3, o5, o6;
  wire new_n44_, new_n45_, new_n46_, new_n47_, new_n48_, new_n49_, new_n50_,
    new_n51_, new_n52_, new_n53_, new_n54_, new_n55_, new_n56_, new_n57_,
    new_n58_, new_n59_, new_n60_, new_n61_, new_n62_, new_n63_, new_n64_,
    new_n66_, new_n67_, new_n68_, new_n69_, new_n70_, new_n71_, new_n72_,
    new_n73_, new_n74_, new_n75_, new_n76_, new_n77_, new_n78_, new_n79_,
    new_n80_, new_n81_, new_n82_, new_n83_, new_n84_, new_n85_, new_n86_,
    new_n87_, new_n88_, new_n89_, new_n90_, new_n91_, new_n92_, new_n93_,
    new_n94_, new_n95_, new_n96_, new_n97_, new_n98_, new_n99_, new_n100_,
    new_n101_, new_n102_, new_n103_, new_n104_, new_n105_, new_n106_,
    new_n107_, new_n108_, new_n109_, new_n110_, new_n111_, new_n112_,
    new_n113_, new_n114_, new_n115_, new_n116_, new_n117_, new_n118_,
    new_n119_, new_n120_, new_n121_, new_n122_, new_n123_, new_n124_,
    new_n125_, new_n126_, new_n127_, new_n128_, new_n129_, new_n131_,
    new_n132_, new_n133_, new_n134_, new_n135_, new_n136_, new_n137_,
    new_n138_, new_n139_, new_n140_, new_n141_, new_n142_, new_n143_,
    new_n144_, new_n145_, new_n146_, new_n147_, new_n148_, new_n149_,
    new_n150_, new_n151_, new_n152_, new_n153_, new_n154_, new_n155_,
    new_n156_, new_n157_, new_n158_, new_n159_, new_n160_, new_n161_,
    new_n162_, new_n163_, new_n164_, new_n165_, new_n166_, new_n167_,
    new_n168_, new_n169_, new_n170_, new_n171_, new_n172_, new_n173_,
    new_n174_, new_n175_, new_n176_, new_n177_, new_n178_, new_n179_,
    new_n180_, new_n181_, new_n182_, new_n183_, new_n184_, new_n185_,
    new_n186_, new_n187_, new_n188_, new_n189_, new_n190_, new_n191_,
    new_n192_, new_n193_, new_n194_, new_n195_, new_n197_, new_n198_,
    new_n199_, new_n200_, new_n201_, new_n202_, new_n203_, new_n204_,
    new_n205_, new_n206_, new_n207_, new_n208_, new_n209_, new_n210_,
    new_n211_, new_n212_, new_n213_, new_n214_, new_n215_, new_n216_,
    new_n217_, new_n218_, new_n219_, new_n220_, new_n221_, new_n222_,
    new_n223_, new_n224_, new_n225_, new_n226_, new_n227_, new_n228_,
    new_n229_, new_n230_, new_n231_, new_n232_, new_n233_, new_n234_,
    new_n235_, new_n236_, new_n237_, new_n238_, new_n239_, new_n240_,
    new_n241_, new_n242_, new_n243_, new_n244_, new_n245_, new_n246_,
    new_n247_, new_n248_, new_n249_, new_n250_, new_n251_, new_n252_,
    new_n253_, new_n254_, new_n255_, new_n256_, new_n257_, new_n258_,
    new_n259_, new_n260_, new_n261_, new_n262_, new_n263_, new_n264_,
    new_n265_, new_n266_, new_n267_, new_n269_, new_n270_, new_n271_,
    new_n272_, new_n273_, new_n274_, new_n275_, new_n276_, new_n277_,
    new_n278_, new_n279_, new_n280_, new_n281_, new_n282_, new_n283_,
    new_n284_, new_n285_, new_n286_, new_n287_, new_n288_, new_n290_,
    new_n291_, new_n292_, new_n293_, new_n294_, new_n295_, new_n296_,
    new_n297_, new_n298_, new_n299_, new_n300_, new_n302_, new_n303_,
    new_n304_, new_n305_, new_n306_, new_n307_, new_n308_, new_n309_,
    new_n310_, new_n311_, new_n312_;
  INVx1_ASAP7_75t_R   g000(.A(p8), .Y(new_n44_));
  INVx1_ASAP7_75t_R   g001(.A(p9), .Y(new_n45_));
  NAND2x1_ASAP7_75t_R g002(.A(p10), .B(new_n45_), .Y(new_n46_));
  OAI21x1_ASAP7_75t_R g003(.A1(new_n44_), .A2(p7), .B(new_n46_), .Y(new_n47_));
  INVx1_ASAP7_75t_R   g004(.A(p12), .Y(new_n48_));
  INVx1_ASAP7_75t_R   g005(.A(p5), .Y(new_n49_));
  NAND2x1_ASAP7_75t_R g006(.A(p6), .B(new_n49_), .Y(new_n50_));
  OAI21x1_ASAP7_75t_R g007(.A1(new_n48_), .A2(p11), .B(new_n50_), .Y(new_n51_));
  NOR2x1_ASAP7_75t_R  g008(.A(new_n47_), .B(new_n51_), .Y(new_n52_));
  INVx1_ASAP7_75t_R   g009(.A(p14), .Y(new_n53_));
  NOR2x1_ASAP7_75t_R  g010(.A(p13), .B(new_n53_), .Y(new_n54_));
  INVx1_ASAP7_75t_R   g011(.A(p16), .Y(new_n55_));
  NOR2x1_ASAP7_75t_R  g012(.A(p15), .B(new_n55_), .Y(new_n56_));
  NOR2x1_ASAP7_75t_R  g013(.A(new_n54_), .B(new_n56_), .Y(new_n57_));
  INVx1_ASAP7_75t_R   g014(.A(p35), .Y(new_n58_));
  NAND2x1_ASAP7_75t_R g015(.A(p0), .B(new_n58_), .Y(new_n59_));
  INVx1_ASAP7_75t_R   g016(.A(p3), .Y(new_n60_));
  NAND2x1_ASAP7_75t_R g017(.A(p4), .B(new_n60_), .Y(new_n61_));
  INVx1_ASAP7_75t_R   g018(.A(p1), .Y(new_n62_));
  NAND2x1_ASAP7_75t_R g019(.A(p2), .B(new_n62_), .Y(new_n63_));
  AND3x1_ASAP7_75t_R  g020(.A(new_n59_), .B(new_n61_), .C(new_n63_), .Y(new_n64_));
  NAND3x1_ASAP7_75t_R g021(.A(new_n52_), .B(new_n57_), .C(new_n64_), .Y(o0));
  INVx1_ASAP7_75t_R   g022(.A(p20), .Y(new_n66_));
  NAND2x1_ASAP7_75t_R g023(.A(p6), .B(new_n66_), .Y(new_n67_));
  AO21x1_ASAP7_75t_R  g024(.A1(new_n50_), .A2(o0), .B(new_n67_), .Y(new_n68_));
  NOR2x1_ASAP7_75t_R  g025(.A(p11), .B(new_n48_), .Y(new_n69_));
  INVx1_ASAP7_75t_R   g026(.A(new_n69_), .Y(new_n70_));
  INVx1_ASAP7_75t_R   g027(.A(p13), .Y(new_n71_));
  NAND2x1_ASAP7_75t_R g028(.A(p14), .B(new_n71_), .Y(new_n72_));
  INVx1_ASAP7_75t_R   g029(.A(p15), .Y(new_n73_));
  NAND2x1_ASAP7_75t_R g030(.A(p16), .B(new_n73_), .Y(new_n74_));
  AND3x1_ASAP7_75t_R  g031(.A(new_n72_), .B(new_n74_), .C(p12), .Y(new_n75_));
  NAND3x1_ASAP7_75t_R g032(.A(new_n52_), .B(new_n64_), .C(new_n75_), .Y(new_n76_));
  AO21x1_ASAP7_75t_R  g033(.A1(new_n70_), .A2(new_n76_), .B(p23), .Y(new_n77_));
  INVx1_ASAP7_75t_R   g034(.A(p18), .Y(new_n78_));
  INVx1_ASAP7_75t_R   g035(.A(p0), .Y(new_n79_));
  NOR2x1_ASAP7_75t_R  g036(.A(p35), .B(new_n79_), .Y(new_n80_));
  INVx1_ASAP7_75t_R   g037(.A(p2), .Y(new_n81_));
  NOR2x1_ASAP7_75t_R  g038(.A(p1), .B(new_n81_), .Y(new_n82_));
  NOR2x1_ASAP7_75t_R  g039(.A(new_n80_), .B(new_n82_), .Y(new_n83_));
  NAND3x1_ASAP7_75t_R g040(.A(new_n57_), .B(new_n83_), .C(new_n61_), .Y(new_n84_));
  AOI21x1_ASAP7_75t_R g041(.A1(new_n49_), .A2(p6), .B(new_n69_), .Y(new_n85_));
  NOR2x1_ASAP7_75t_R  g042(.A(p7), .B(new_n44_), .Y(new_n86_));
  INVx1_ASAP7_75t_R   g043(.A(p10), .Y(new_n87_));
  NOR2x1_ASAP7_75t_R  g044(.A(p9), .B(new_n87_), .Y(new_n88_));
  NOR2x1_ASAP7_75t_R  g045(.A(new_n86_), .B(new_n88_), .Y(new_n89_));
  NAND3x1_ASAP7_75t_R g046(.A(new_n85_), .B(new_n89_), .C(p2), .Y(new_n90_));
  OAI21x1_ASAP7_75t_R g047(.A1(new_n84_), .A2(new_n90_), .B(new_n63_), .Y(new_n91_));
  NAND2x1_ASAP7_75t_R g048(.A(new_n78_), .B(new_n91_), .Y(new_n92_));
  AND3x1_ASAP7_75t_R  g049(.A(new_n68_), .B(new_n77_), .C(new_n92_), .Y(new_n93_));
  AOI21x1_ASAP7_75t_R g050(.A1(new_n64_), .A2(new_n52_), .B(new_n56_), .Y(new_n94_));
  AO21x1_ASAP7_75t_R  g051(.A1(p15), .A2(new_n54_), .B(new_n55_), .Y(new_n95_));
  NOR2x1_ASAP7_75t_R  g052(.A(p25), .B(new_n95_), .Y(new_n96_));
  INVx1_ASAP7_75t_R   g053(.A(new_n96_), .Y(new_n97_));
  INVx1_ASAP7_75t_R   g054(.A(p4), .Y(new_n98_));
  NOR2x1_ASAP7_75t_R  g055(.A(p3), .B(new_n98_), .Y(new_n99_));
  NAND2x1_ASAP7_75t_R g056(.A(new_n72_), .B(new_n74_), .Y(new_n100_));
  NOR3x1_ASAP7_75t_R  g057(.A(new_n100_), .B(new_n47_), .C(new_n51_), .Y(new_n101_));
  NAND2x1_ASAP7_75t_R g058(.A(new_n59_), .B(new_n63_), .Y(new_n102_));
  INVx1_ASAP7_75t_R   g059(.A(p19), .Y(new_n103_));
  NAND2x1_ASAP7_75t_R g060(.A(p4), .B(new_n103_), .Y(new_n104_));
  AOI21x1_ASAP7_75t_R g061(.A1(new_n61_), .A2(new_n102_), .B(new_n104_), .Y(new_n105_));
  OAI21x1_ASAP7_75t_R g062(.A1(new_n99_), .A2(new_n101_), .B(new_n105_), .Y(new_n106_));
  OAI21x1_ASAP7_75t_R g063(.A1(new_n94_), .A2(new_n97_), .B(new_n106_), .Y(new_n107_));
  NAND2x1_ASAP7_75t_R g064(.A(new_n61_), .B(new_n63_), .Y(new_n108_));
  NOR2x1_ASAP7_75t_R  g065(.A(new_n100_), .B(new_n108_), .Y(new_n109_));
  NAND2x1_ASAP7_75t_R g066(.A(new_n52_), .B(new_n109_), .Y(new_n110_));
  NOR2x1_ASAP7_75t_R  g067(.A(p17), .B(new_n79_), .Y(new_n111_));
  INVx1_ASAP7_75t_R   g068(.A(new_n111_), .Y(new_n112_));
  AOI21x1_ASAP7_75t_R g069(.A1(new_n59_), .A2(new_n110_), .B(new_n112_), .Y(new_n113_));
  NOR2x1_ASAP7_75t_R  g070(.A(p24), .B(new_n53_), .Y(new_n114_));
  INVx1_ASAP7_75t_R   g071(.A(new_n114_), .Y(new_n115_));
  NAND2x1_ASAP7_75t_R g072(.A(new_n74_), .B(new_n59_), .Y(new_n116_));
  NOR2x1_ASAP7_75t_R  g073(.A(new_n108_), .B(new_n116_), .Y(new_n117_));
  AOI21x1_ASAP7_75t_R g074(.A1(new_n52_), .A2(new_n117_), .B(new_n54_), .Y(new_n118_));
  NOR2x1_ASAP7_75t_R  g075(.A(new_n115_), .B(new_n118_), .Y(new_n119_));
  NOR3x1_ASAP7_75t_R  g076(.A(new_n107_), .B(new_n113_), .C(new_n119_), .Y(new_n120_));
  NAND3x1_ASAP7_75t_R g077(.A(new_n57_), .B(new_n85_), .C(new_n89_), .Y(new_n121_));
  NAND2x1_ASAP7_75t_R g078(.A(p8), .B(new_n64_), .Y(new_n122_));
  INVx1_ASAP7_75t_R   g079(.A(new_n86_), .Y(new_n123_));
  OAI21x1_ASAP7_75t_R g080(.A1(new_n121_), .A2(new_n122_), .B(new_n123_), .Y(new_n124_));
  NOR3x1_ASAP7_75t_R  g081(.A(new_n102_), .B(p7), .C(new_n99_), .Y(new_n125_));
  AOI21x1_ASAP7_75t_R g082(.A1(new_n125_), .A2(new_n101_), .B(p21), .Y(new_n126_));
  OR2x4_ASAP7_75t_R   g083(.A(p22), .B(new_n87_), .Y(new_n127_));
  AOI21x1_ASAP7_75t_R g084(.A1(new_n46_), .A2(o0), .B(new_n127_), .Y(new_n128_));
  AOI21x1_ASAP7_75t_R g085(.A1(new_n124_), .A2(new_n126_), .B(new_n128_), .Y(new_n129_));
  NAND3x1_ASAP7_75t_R g086(.A(new_n93_), .B(new_n120_), .C(new_n129_), .Y(o1));
  AOI21x1_ASAP7_75t_R g087(.A1(new_n70_), .A2(new_n76_), .B(p23), .Y(new_n131_));
  NAND2x1_ASAP7_75t_R g088(.A(p2), .B(new_n78_), .Y(new_n132_));
  AOI21x1_ASAP7_75t_R g089(.A1(new_n63_), .A2(o0), .B(new_n132_), .Y(new_n133_));
  NAND2x1_ASAP7_75t_R g090(.A(p6), .B(new_n64_), .Y(new_n134_));
  OA21x2_ASAP7_75t_R  g091(.A1(new_n121_), .A2(new_n134_), .B(new_n50_), .Y(new_n135_));
  NOR3x1_ASAP7_75t_R  g092(.A(new_n131_), .B(new_n133_), .C(new_n135_), .Y(new_n136_));
  NAND3x1_ASAP7_75t_R g093(.A(new_n120_), .B(new_n136_), .C(new_n129_), .Y(new_n137_));
  AOI21x1_ASAP7_75t_R g094(.A1(new_n68_), .A2(new_n137_), .B(p29), .Y(new_n138_));
  INVx1_ASAP7_75t_R   g095(.A(p17), .Y(new_n139_));
  AOI21x1_ASAP7_75t_R g096(.A1(new_n129_), .A2(new_n120_), .B(new_n139_), .Y(new_n140_));
  NAND2x1_ASAP7_75t_R g097(.A(new_n89_), .B(new_n85_), .Y(new_n141_));
  NOR2x1_ASAP7_75t_R  g098(.A(new_n99_), .B(new_n82_), .Y(new_n142_));
  NAND2x1_ASAP7_75t_R g099(.A(new_n57_), .B(new_n142_), .Y(new_n143_));
  OAI21x1_ASAP7_75t_R g100(.A1(new_n141_), .A2(new_n143_), .B(new_n59_), .Y(new_n144_));
  NAND2x1_ASAP7_75t_R g101(.A(p0), .B(new_n144_), .Y(new_n145_));
  NOR2x1_ASAP7_75t_R  g102(.A(p26), .B(new_n145_), .Y(new_n146_));
  INVx1_ASAP7_75t_R   g103(.A(new_n146_), .Y(new_n147_));
  NOR2x1_ASAP7_75t_R  g104(.A(new_n131_), .B(new_n133_), .Y(new_n148_));
  AOI21x1_ASAP7_75t_R g105(.A1(new_n68_), .A2(new_n148_), .B(new_n139_), .Y(new_n149_));
  NOR3x1_ASAP7_75t_R  g106(.A(new_n140_), .B(new_n147_), .C(new_n149_), .Y(new_n150_));
  NOR2x1_ASAP7_75t_R  g107(.A(new_n138_), .B(new_n150_), .Y(new_n151_));
  INVx1_ASAP7_75t_R   g108(.A(p21), .Y(new_n152_));
  AOI21x1_ASAP7_75t_R g109(.A1(new_n129_), .A2(new_n120_), .B(new_n152_), .Y(new_n153_));
  INVx1_ASAP7_75t_R   g110(.A(p7), .Y(new_n154_));
  INVx1_ASAP7_75t_R   g111(.A(o0), .Y(new_n155_));
  NOR2x1_ASAP7_75t_R  g112(.A(p30), .B(new_n44_), .Y(new_n156_));
  OA21x2_ASAP7_75t_R  g113(.A1(new_n154_), .A2(new_n155_), .B(new_n156_), .Y(new_n157_));
  INVx1_ASAP7_75t_R   g114(.A(new_n157_), .Y(new_n158_));
  AOI21x1_ASAP7_75t_R g115(.A1(new_n68_), .A2(new_n148_), .B(new_n152_), .Y(new_n159_));
  NOR3x1_ASAP7_75t_R  g116(.A(new_n153_), .B(new_n158_), .C(new_n159_), .Y(new_n160_));
  INVx1_ASAP7_75t_R   g117(.A(p31), .Y(new_n161_));
  NAND2x1_ASAP7_75t_R g118(.A(p10), .B(new_n161_), .Y(new_n162_));
  AOI21x1_ASAP7_75t_R g119(.A1(new_n46_), .A2(o0), .B(new_n162_), .Y(new_n163_));
  INVx1_ASAP7_75t_R   g120(.A(p32), .Y(new_n164_));
  NAND2x1_ASAP7_75t_R g121(.A(p12), .B(new_n164_), .Y(new_n165_));
  AOI21x1_ASAP7_75t_R g122(.A1(p11), .A2(o0), .B(new_n165_), .Y(new_n166_));
  NOR2x1_ASAP7_75t_R  g123(.A(new_n163_), .B(new_n166_), .Y(new_n167_));
  INVx1_ASAP7_75t_R   g124(.A(p27), .Y(new_n168_));
  OR2x4_ASAP7_75t_R   g125(.A(p28), .B(new_n98_), .Y(new_n169_));
  NOR2x1_ASAP7_75t_R  g126(.A(new_n100_), .B(new_n102_), .Y(new_n170_));
  AOI21x1_ASAP7_75t_R g127(.A1(new_n52_), .A2(new_n170_), .B(new_n99_), .Y(new_n171_));
  NOR2x1_ASAP7_75t_R  g128(.A(new_n169_), .B(new_n171_), .Y(new_n172_));
  AOI21x1_ASAP7_75t_R g129(.A1(new_n168_), .A2(new_n91_), .B(new_n172_), .Y(new_n173_));
  NOR2x1_ASAP7_75t_R  g130(.A(new_n56_), .B(new_n80_), .Y(new_n174_));
  NAND2x1_ASAP7_75t_R g131(.A(new_n142_), .B(new_n174_), .Y(new_n175_));
  OAI21x1_ASAP7_75t_R g132(.A1(new_n141_), .A2(new_n175_), .B(new_n72_), .Y(new_n176_));
  NOR2x1_ASAP7_75t_R  g133(.A(p33), .B(new_n53_), .Y(new_n177_));
  INVx1_ASAP7_75t_R   g134(.A(p34), .Y(new_n178_));
  INVx1_ASAP7_75t_R   g135(.A(new_n95_), .Y(new_n179_));
  NAND2x1_ASAP7_75t_R g136(.A(new_n178_), .B(new_n179_), .Y(new_n180_));
  NOR2x1_ASAP7_75t_R  g137(.A(new_n180_), .B(new_n94_), .Y(new_n181_));
  AOI21x1_ASAP7_75t_R g138(.A1(new_n176_), .A2(new_n177_), .B(new_n181_), .Y(new_n182_));
  AND3x1_ASAP7_75t_R  g139(.A(new_n167_), .B(new_n173_), .C(new_n182_), .Y(new_n183_));
  AO21x1_ASAP7_75t_R  g140(.A1(new_n64_), .A2(new_n52_), .B(new_n56_), .Y(new_n184_));
  AND3x1_ASAP7_75t_R  g141(.A(new_n184_), .B(new_n178_), .C(new_n96_), .Y(new_n185_));
  AOI21x1_ASAP7_75t_R g142(.A1(new_n164_), .A2(new_n131_), .B(new_n185_), .Y(new_n186_));
  OR3x1_ASAP7_75t_R   g143(.A(new_n87_), .B(p22), .C(p31), .Y(new_n187_));
  AOI21x1_ASAP7_75t_R g144(.A1(new_n46_), .A2(o0), .B(new_n187_), .Y(new_n188_));
  AOI21x1_ASAP7_75t_R g145(.A1(new_n168_), .A2(new_n133_), .B(new_n188_), .Y(new_n189_));
  INVx1_ASAP7_75t_R   g146(.A(p33), .Y(new_n190_));
  NOR2x1_ASAP7_75t_R  g147(.A(p28), .B(new_n106_), .Y(new_n191_));
  AOI21x1_ASAP7_75t_R g148(.A1(new_n190_), .A2(new_n119_), .B(new_n191_), .Y(new_n192_));
  AND3x1_ASAP7_75t_R  g149(.A(new_n186_), .B(new_n189_), .C(new_n192_), .Y(new_n193_));
  OAI21x1_ASAP7_75t_R g150(.A1(new_n183_), .A2(o1), .B(new_n193_), .Y(new_n194_));
  NOR2x1_ASAP7_75t_R  g151(.A(new_n160_), .B(new_n194_), .Y(new_n195_));
  NAND2x1_ASAP7_75t_R g152(.A(new_n151_), .B(new_n195_), .Y(o2));
  NAND3x1_ASAP7_75t_R g153(.A(new_n167_), .B(new_n173_), .C(new_n182_), .Y(new_n197_));
  NAND3x1_ASAP7_75t_R g154(.A(new_n68_), .B(new_n77_), .C(new_n92_), .Y(new_n198_));
  OR3x1_ASAP7_75t_R   g155(.A(new_n80_), .B(new_n99_), .C(new_n82_), .Y(new_n199_));
  OR3x1_ASAP7_75t_R   g156(.A(new_n54_), .B(new_n56_), .C(new_n44_), .Y(new_n200_));
  NOR3x1_ASAP7_75t_R  g157(.A(new_n141_), .B(new_n199_), .C(new_n200_), .Y(new_n201_));
  OAI21x1_ASAP7_75t_R g158(.A1(new_n86_), .A2(new_n201_), .B(new_n126_), .Y(new_n202_));
  NAND2x1_ASAP7_75t_R g159(.A(new_n111_), .B(new_n144_), .Y(new_n203_));
  NAND2x1_ASAP7_75t_R g160(.A(new_n114_), .B(new_n176_), .Y(new_n204_));
  NAND3x1_ASAP7_75t_R g161(.A(new_n202_), .B(new_n203_), .C(new_n204_), .Y(new_n205_));
  AO21x1_ASAP7_75t_R  g162(.A1(new_n46_), .A2(o0), .B(new_n127_), .Y(new_n206_));
  AO21x1_ASAP7_75t_R  g163(.A1(new_n61_), .A2(new_n102_), .B(new_n104_), .Y(new_n207_));
  AOI21x1_ASAP7_75t_R g164(.A1(new_n61_), .A2(new_n121_), .B(new_n207_), .Y(new_n208_));
  AOI21x1_ASAP7_75t_R g165(.A1(new_n184_), .A2(new_n96_), .B(new_n208_), .Y(new_n209_));
  NAND2x1_ASAP7_75t_R g166(.A(new_n206_), .B(new_n209_), .Y(new_n210_));
  NOR3x1_ASAP7_75t_R  g167(.A(new_n198_), .B(new_n205_), .C(new_n210_), .Y(new_n211_));
  NAND3x1_ASAP7_75t_R g168(.A(new_n186_), .B(new_n192_), .C(new_n189_), .Y(new_n212_));
  AOI21x1_ASAP7_75t_R g169(.A1(new_n197_), .A2(new_n211_), .B(new_n212_), .Y(new_n213_));
  OAI21x1_ASAP7_75t_R g170(.A1(new_n210_), .A2(new_n205_), .B(p17), .Y(new_n214_));
  NAND2x1_ASAP7_75t_R g171(.A(p17), .B(new_n198_), .Y(new_n215_));
  NAND3x1_ASAP7_75t_R g172(.A(new_n214_), .B(new_n215_), .C(new_n146_), .Y(new_n216_));
  OAI21x1_ASAP7_75t_R g173(.A1(new_n210_), .A2(new_n205_), .B(p20), .Y(new_n217_));
  NAND2x1_ASAP7_75t_R g174(.A(new_n92_), .B(new_n77_), .Y(new_n218_));
  AOI21x1_ASAP7_75t_R g175(.A1(p20), .A2(new_n218_), .B(new_n135_), .Y(new_n219_));
  INVx1_ASAP7_75t_R   g176(.A(p29), .Y(new_n220_));
  NAND3x1_ASAP7_75t_R g177(.A(new_n217_), .B(new_n219_), .C(new_n220_), .Y(new_n221_));
  NAND3x1_ASAP7_75t_R g178(.A(new_n213_), .B(new_n216_), .C(new_n221_), .Y(new_n222_));
  OAI21x1_ASAP7_75t_R g179(.A1(p20), .A2(new_n135_), .B(new_n106_), .Y(new_n223_));
  NOR3x1_ASAP7_75t_R  g180(.A(new_n223_), .B(new_n128_), .C(new_n133_), .Y(new_n224_));
  OAI21x1_ASAP7_75t_R g181(.A1(new_n115_), .A2(new_n118_), .B(new_n203_), .Y(new_n225_));
  AND2x2_ASAP7_75t_R  g182(.A(new_n126_), .B(new_n124_), .Y(new_n226_));
  AND3x1_ASAP7_75t_R  g183(.A(new_n83_), .B(p12), .C(new_n61_), .Y(new_n227_));
  AOI21x1_ASAP7_75t_R g184(.A1(new_n101_), .A2(new_n227_), .B(new_n69_), .Y(new_n228_));
  AND3x1_ASAP7_75t_R  g185(.A(new_n64_), .B(new_n89_), .C(new_n85_), .Y(new_n229_));
  OAI21x1_ASAP7_75t_R g186(.A1(new_n56_), .A2(new_n229_), .B(new_n96_), .Y(new_n230_));
  OAI21x1_ASAP7_75t_R g187(.A1(p23), .A2(new_n228_), .B(new_n230_), .Y(new_n231_));
  NOR3x1_ASAP7_75t_R  g188(.A(new_n225_), .B(new_n226_), .C(new_n231_), .Y(new_n232_));
  AOI21x1_ASAP7_75t_R g189(.A1(new_n224_), .A2(new_n232_), .B(new_n152_), .Y(new_n233_));
  AO21x1_ASAP7_75t_R  g190(.A1(p10), .A2(new_n155_), .B(new_n88_), .Y(new_n234_));
  NAND3x1_ASAP7_75t_R g191(.A(new_n148_), .B(new_n234_), .C(new_n68_), .Y(new_n235_));
  NAND2x1_ASAP7_75t_R g192(.A(new_n129_), .B(new_n120_), .Y(new_n236_));
  OAI21x1_ASAP7_75t_R g193(.A1(new_n235_), .A2(new_n236_), .B(new_n206_), .Y(new_n237_));
  OAI21x1_ASAP7_75t_R g194(.A1(new_n158_), .A2(new_n233_), .B(new_n237_), .Y(new_n238_));
  AOI21x1_ASAP7_75t_R g195(.A1(new_n50_), .A2(o0), .B(new_n67_), .Y(new_n239_));
  INVx1_ASAP7_75t_R   g196(.A(new_n124_), .Y(new_n240_));
  AOI21x1_ASAP7_75t_R g197(.A1(p21), .A2(new_n239_), .B(new_n240_), .Y(new_n241_));
  OAI21x1_ASAP7_75t_R g198(.A1(new_n131_), .A2(new_n133_), .B(p21), .Y(new_n242_));
  NAND2x1_ASAP7_75t_R g199(.A(new_n241_), .B(new_n242_), .Y(new_n243_));
  NOR2x1_ASAP7_75t_R  g200(.A(new_n113_), .B(new_n119_), .Y(new_n244_));
  AOI21x1_ASAP7_75t_R g201(.A1(new_n209_), .A2(new_n244_), .B(new_n152_), .Y(new_n245_));
  AOI21x1_ASAP7_75t_R g202(.A1(new_n202_), .A2(new_n206_), .B(new_n152_), .Y(new_n246_));
  NOR3x1_ASAP7_75t_R  g203(.A(new_n243_), .B(new_n245_), .C(new_n246_), .Y(new_n247_));
  NAND3x1_ASAP7_75t_R g204(.A(new_n197_), .B(new_n232_), .C(new_n224_), .Y(new_n248_));
  AND3x1_ASAP7_75t_R  g205(.A(new_n247_), .B(new_n248_), .C(new_n193_), .Y(new_n249_));
  NOR2x1_ASAP7_75t_R  g206(.A(new_n210_), .B(new_n205_), .Y(new_n250_));
  AND3x1_ASAP7_75t_R  g207(.A(new_n148_), .B(new_n234_), .C(new_n68_), .Y(new_n251_));
  AOI21x1_ASAP7_75t_R g208(.A1(new_n250_), .A2(new_n251_), .B(new_n128_), .Y(new_n252_));
  OAI21x1_ASAP7_75t_R g209(.A1(new_n152_), .A2(new_n211_), .B(new_n157_), .Y(new_n253_));
  OAI21x1_ASAP7_75t_R g210(.A1(p31), .A2(new_n252_), .B(new_n253_), .Y(new_n254_));
  AOI21x1_ASAP7_75t_R g211(.A1(new_n249_), .A2(new_n151_), .B(new_n254_), .Y(new_n255_));
  OAI21x1_ASAP7_75t_R g212(.A1(new_n222_), .A2(new_n238_), .B(new_n255_), .Y(new_n256_));
  NOR2x1_ASAP7_75t_R  g213(.A(new_n53_), .B(new_n118_), .Y(new_n257_));
  AO21x1_ASAP7_75t_R  g214(.A1(new_n257_), .A2(new_n211_), .B(new_n119_), .Y(new_n258_));
  NAND2x1_ASAP7_75t_R g215(.A(new_n253_), .B(new_n258_), .Y(new_n259_));
  NAND2x1_ASAP7_75t_R g216(.A(new_n177_), .B(new_n176_), .Y(new_n260_));
  AO21x1_ASAP7_75t_R  g217(.A1(p24), .A2(o1), .B(new_n260_), .Y(new_n261_));
  OAI21x1_ASAP7_75t_R g218(.A1(new_n222_), .A2(new_n259_), .B(new_n261_), .Y(new_n262_));
  AOI21x1_ASAP7_75t_R g219(.A1(p23), .A2(o1), .B(new_n228_), .Y(new_n263_));
  NAND2x1_ASAP7_75t_R g220(.A(new_n253_), .B(new_n263_), .Y(new_n264_));
  NAND2x1_ASAP7_75t_R g221(.A(new_n164_), .B(new_n263_), .Y(new_n265_));
  OAI21x1_ASAP7_75t_R g222(.A1(new_n264_), .A2(new_n222_), .B(new_n265_), .Y(new_n266_));
  NOR3x1_ASAP7_75t_R  g223(.A(new_n256_), .B(new_n262_), .C(new_n266_), .Y(new_n267_));
  INVx1_ASAP7_75t_R   g224(.A(new_n267_), .Y(o4));
  NOR2x1_ASAP7_75t_R  g225(.A(new_n145_), .B(o1), .Y(new_n269_));
  NAND3x1_ASAP7_75t_R g226(.A(new_n232_), .B(new_n224_), .C(new_n91_), .Y(new_n270_));
  NAND3x1_ASAP7_75t_R g227(.A(new_n270_), .B(new_n203_), .C(new_n92_), .Y(new_n271_));
  OAI21x1_ASAP7_75t_R g228(.A1(new_n269_), .A2(new_n271_), .B(new_n253_), .Y(new_n272_));
  AOI21x1_ASAP7_75t_R g229(.A1(new_n91_), .A2(new_n211_), .B(new_n133_), .Y(new_n273_));
  OA21x2_ASAP7_75t_R  g230(.A1(p27), .A2(new_n273_), .B(new_n216_), .Y(new_n274_));
  OAI21x1_ASAP7_75t_R g231(.A1(new_n222_), .A2(new_n272_), .B(new_n274_), .Y(new_n275_));
  AOI21x1_ASAP7_75t_R g232(.A1(new_n129_), .A2(new_n120_), .B(new_n103_), .Y(new_n276_));
  OR2x4_ASAP7_75t_R   g233(.A(new_n98_), .B(new_n171_), .Y(new_n277_));
  AOI21x1_ASAP7_75t_R g234(.A1(new_n68_), .A2(new_n148_), .B(new_n103_), .Y(new_n278_));
  NOR3x1_ASAP7_75t_R  g235(.A(new_n276_), .B(new_n277_), .C(new_n278_), .Y(new_n279_));
  OAI21x1_ASAP7_75t_R g236(.A1(new_n158_), .A2(new_n233_), .B(new_n279_), .Y(new_n280_));
  AOI21x1_ASAP7_75t_R g237(.A1(new_n172_), .A2(new_n211_), .B(new_n191_), .Y(new_n281_));
  OAI21x1_ASAP7_75t_R g238(.A1(new_n280_), .A2(new_n222_), .B(new_n281_), .Y(new_n282_));
  AO21x1_ASAP7_75t_R  g239(.A1(new_n68_), .A2(new_n137_), .B(new_n160_), .Y(new_n283_));
  OAI21x1_ASAP7_75t_R g240(.A1(new_n222_), .A2(new_n283_), .B(new_n221_), .Y(new_n284_));
  NOR3x1_ASAP7_75t_R  g241(.A(new_n275_), .B(new_n282_), .C(new_n284_), .Y(new_n285_));
  NAND2x1_ASAP7_75t_R g242(.A(new_n179_), .B(new_n184_), .Y(new_n286_));
  AO21x1_ASAP7_75t_R  g243(.A1(p25), .A2(o1), .B(new_n286_), .Y(new_n287_));
  AOI21x1_ASAP7_75t_R g244(.A1(p34), .A2(o2), .B(new_n287_), .Y(new_n288_));
  AOI21x1_ASAP7_75t_R g245(.A1(new_n285_), .A2(new_n267_), .B(new_n288_), .Y(o3));
  AOI21x1_ASAP7_75t_R g246(.A1(new_n224_), .A2(new_n232_), .B(new_n139_), .Y(new_n290_));
  OAI21x1_ASAP7_75t_R g247(.A1(new_n147_), .A2(new_n290_), .B(new_n221_), .Y(new_n291_));
  NAND3x1_ASAP7_75t_R g248(.A(new_n247_), .B(new_n248_), .C(new_n193_), .Y(new_n292_));
  AOI21x1_ASAP7_75t_R g249(.A1(new_n161_), .A2(new_n237_), .B(new_n160_), .Y(new_n293_));
  OAI21x1_ASAP7_75t_R g250(.A1(new_n291_), .A2(new_n292_), .B(new_n293_), .Y(new_n294_));
  NOR3x1_ASAP7_75t_R  g251(.A(new_n291_), .B(new_n238_), .C(new_n194_), .Y(new_n295_));
  NOR2x1_ASAP7_75t_R  g252(.A(new_n294_), .B(new_n295_), .Y(new_n296_));
  OA21x2_ASAP7_75t_R  g253(.A1(new_n264_), .A2(new_n222_), .B(new_n265_), .Y(new_n297_));
  NAND3x1_ASAP7_75t_R g254(.A(new_n296_), .B(new_n297_), .C(new_n284_), .Y(new_n298_));
  NAND2x1_ASAP7_75t_R g255(.A(new_n282_), .B(new_n296_), .Y(new_n299_));
  NOR2x1_ASAP7_75t_R  g256(.A(new_n266_), .B(new_n262_), .Y(new_n300_));
  NAND3x1_ASAP7_75t_R g257(.A(new_n298_), .B(new_n299_), .C(new_n300_), .Y(o5));
  NOR3x1_ASAP7_75t_R  g258(.A(new_n280_), .B(new_n291_), .C(new_n194_), .Y(new_n302_));
  NAND2x1_ASAP7_75t_R g259(.A(new_n161_), .B(new_n237_), .Y(new_n303_));
  NAND2x1_ASAP7_75t_R g260(.A(new_n281_), .B(new_n303_), .Y(new_n304_));
  NOR3x1_ASAP7_75t_R  g261(.A(new_n302_), .B(new_n295_), .C(new_n304_), .Y(new_n305_));
  AOI21x1_ASAP7_75t_R g262(.A1(new_n151_), .A2(new_n195_), .B(new_n168_), .Y(new_n306_));
  AOI21x1_ASAP7_75t_R g263(.A1(new_n164_), .A2(new_n263_), .B(new_n273_), .Y(new_n307_));
  OAI21x1_ASAP7_75t_R g264(.A1(new_n264_), .A2(new_n222_), .B(new_n307_), .Y(new_n308_));
  NOR2x1_ASAP7_75t_R  g265(.A(new_n306_), .B(new_n308_), .Y(new_n309_));
  NAND2x1_ASAP7_75t_R g266(.A(new_n305_), .B(new_n309_), .Y(new_n310_));
  OAI21x1_ASAP7_75t_R g267(.A1(new_n238_), .A2(new_n222_), .B(new_n303_), .Y(new_n311_));
  AOI21x1_ASAP7_75t_R g268(.A1(new_n311_), .A2(new_n297_), .B(new_n262_), .Y(new_n312_));
  NAND3x1_ASAP7_75t_R g269(.A(new_n310_), .B(new_n298_), .C(new_n312_), .Y(o6));
endmodule


