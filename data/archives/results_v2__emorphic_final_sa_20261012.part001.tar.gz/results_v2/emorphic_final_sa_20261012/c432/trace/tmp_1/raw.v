// Benchmark "/tmp/" written by ABC on Mon Oct 12 14:40:51 2026

module \/tmp/  ( 
    p3, p29, p12, p10, p27, p33, p17, p15, p28, p20, p11, p1, p6, p2, p14,
    p21, p32, p23, p13, p9, p4, p7, p18, p24, p8, p35, p0, p26, p16, p34,
    p30, p19, p25, p31, p22, p5,
    o0, o1, o2, o4, o3, o5, o6  );
  input  p3, p29, p12, p10, p27, p33, p17, p15, p28, p20, p11, p1, p6,
    p2, p14, p21, p32, p23, p13, p9, p4, p7, p18, p24, p8, p35, p0, p26,
    p16, p34, p30, p19, p25, p31, p22, p5;
  output o0, o1, o2, o4, o3, o5, o6;
  wire new_n44_, new_n45_, new_n46_, new_n47_, new_n48_, new_n49_, new_n50_,
    new_n51_, new_n52_, new_n53_, new_n54_, new_n55_, new_n56_, new_n57_,
    new_n58_, new_n59_, new_n60_, new_n61_, new_n62_, new_n63_, new_n64_,
    new_n66_, new_n67_, new_n68_, new_n69_, new_n70_, new_n71_, new_n72_,
    new_n73_, new_n74_, new_n75_, new_n76_, new_n77_, new_n78_, new_n79_,
    new_n80_, new_n81_, new_n82_, new_n83_, new_n84_, new_n85_, new_n86_,
    new_n87_, new_n88_, new_n89_, new_n90_, new_n91_, new_n92_, new_n93_,
    new_n94_, new_n95_, new_n96_, new_n97_, new_n98_, new_n99_, new_n100_,
    new_n101_, new_n102_, new_n103_, new_n104_, new_n105_, new_n106_,
    new_n107_, new_n108_, new_n109_, new_n110_, new_n111_, new_n112_,
    new_n113_, new_n114_, new_n115_, new_n116_, new_n117_, new_n118_,
    new_n119_, new_n120_, new_n121_, new_n122_, new_n123_, new_n124_,
    new_n125_, new_n126_, new_n127_, new_n129_, new_n130_, new_n131_,
    new_n132_, new_n133_, new_n134_, new_n135_, new_n136_, new_n137_,
    new_n138_, new_n139_, new_n140_, new_n141_, new_n142_, new_n143_,
    new_n144_, new_n145_, new_n146_, new_n147_, new_n148_, new_n149_,
    new_n150_, new_n151_, new_n152_, new_n153_, new_n154_, new_n155_,
    new_n156_, new_n157_, new_n158_, new_n159_, new_n160_, new_n161_,
    new_n162_, new_n163_, new_n164_, new_n165_, new_n166_, new_n167_,
    new_n168_, new_n169_, new_n170_, new_n171_, new_n172_, new_n173_,
    new_n174_, new_n175_, new_n176_, new_n177_, new_n178_, new_n179_,
    new_n180_, new_n181_, new_n182_, new_n183_, new_n184_, new_n185_,
    new_n186_, new_n187_, new_n188_, new_n189_, new_n190_, new_n191_,
    new_n192_, new_n193_, new_n194_, new_n195_, new_n196_, new_n197_,
    new_n198_, new_n199_, new_n200_, new_n202_, new_n203_, new_n204_,
    new_n205_, new_n206_, new_n207_, new_n208_, new_n209_, new_n210_,
    new_n211_, new_n212_, new_n213_, new_n214_, new_n215_, new_n216_,
    new_n217_, new_n218_, new_n219_, new_n220_, new_n221_, new_n222_,
    new_n223_, new_n224_, new_n225_, new_n226_, new_n227_, new_n228_,
    new_n229_, new_n230_, new_n231_, new_n232_, new_n233_, new_n234_,
    new_n235_, new_n236_, new_n237_, new_n238_, new_n239_, new_n240_,
    new_n241_, new_n242_, new_n243_, new_n244_, new_n245_, new_n246_,
    new_n247_, new_n248_, new_n249_, new_n250_, new_n251_, new_n252_,
    new_n254_, new_n255_, new_n256_, new_n257_, new_n258_, new_n259_,
    new_n260_, new_n261_, new_n262_, new_n263_, new_n264_, new_n265_,
    new_n266_, new_n267_, new_n268_, new_n269_, new_n270_, new_n272_,
    new_n273_, new_n274_, new_n275_, new_n276_, new_n277_, new_n278_,
    new_n279_, new_n280_, new_n281_, new_n282_, new_n283_, new_n284_,
    new_n285_, new_n286_, new_n287_, new_n288_, new_n290_, new_n291_,
    new_n292_, new_n293_, new_n294_, new_n295_, new_n296_, new_n297_,
    new_n298_, new_n299_, new_n300_;
  INVx1_ASAP7_75t_R   g000(.A(p8), .Y(new_n44_));
  INVx1_ASAP7_75t_R   g001(.A(p9), .Y(new_n45_));
  NAND2x1_ASAP7_75t_R g002(.A(p10), .B(new_n45_), .Y(new_n46_));
  OAI21x1_ASAP7_75t_R g003(.A1(p7), .A2(new_n44_), .B(new_n46_), .Y(new_n47_));
  INVx1_ASAP7_75t_R   g004(.A(p6), .Y(new_n48_));
  INVx1_ASAP7_75t_R   g005(.A(p11), .Y(new_n49_));
  NAND2x1_ASAP7_75t_R g006(.A(p12), .B(new_n49_), .Y(new_n50_));
  OAI21x1_ASAP7_75t_R g007(.A1(new_n48_), .A2(p5), .B(new_n50_), .Y(new_n51_));
  NOR2x1_ASAP7_75t_R  g008(.A(new_n47_), .B(new_n51_), .Y(new_n52_));
  INVx1_ASAP7_75t_R   g009(.A(p16), .Y(new_n53_));
  NOR2x1_ASAP7_75t_R  g010(.A(p15), .B(new_n53_), .Y(new_n54_));
  INVx1_ASAP7_75t_R   g011(.A(p14), .Y(new_n55_));
  NOR2x1_ASAP7_75t_R  g012(.A(p13), .B(new_n55_), .Y(new_n56_));
  NOR2x1_ASAP7_75t_R  g013(.A(new_n54_), .B(new_n56_), .Y(new_n57_));
  INVx1_ASAP7_75t_R   g014(.A(p3), .Y(new_n58_));
  NAND2x1_ASAP7_75t_R g015(.A(p4), .B(new_n58_), .Y(new_n59_));
  INVx1_ASAP7_75t_R   g016(.A(p35), .Y(new_n60_));
  NAND2x1_ASAP7_75t_R g017(.A(p0), .B(new_n60_), .Y(new_n61_));
  INVx1_ASAP7_75t_R   g018(.A(p1), .Y(new_n62_));
  NAND2x1_ASAP7_75t_R g019(.A(p2), .B(new_n62_), .Y(new_n63_));
  AND3x1_ASAP7_75t_R  g020(.A(new_n59_), .B(new_n61_), .C(new_n63_), .Y(new_n64_));
  NAND3x1_ASAP7_75t_R g021(.A(new_n52_), .B(new_n57_), .C(new_n64_), .Y(o0));
  NOR2x1_ASAP7_75t_R  g022(.A(p5), .B(new_n48_), .Y(new_n66_));
  INVx1_ASAP7_75t_R   g023(.A(new_n66_), .Y(new_n67_));
  INVx1_ASAP7_75t_R   g024(.A(p15), .Y(new_n68_));
  NAND2x1_ASAP7_75t_R g025(.A(p16), .B(new_n68_), .Y(new_n69_));
  INVx1_ASAP7_75t_R   g026(.A(p13), .Y(new_n70_));
  NAND2x1_ASAP7_75t_R g027(.A(p14), .B(new_n70_), .Y(new_n71_));
  AND3x1_ASAP7_75t_R  g028(.A(new_n69_), .B(new_n71_), .C(p6), .Y(new_n72_));
  NAND3x1_ASAP7_75t_R g029(.A(new_n52_), .B(new_n64_), .C(new_n72_), .Y(new_n73_));
  AOI21x1_ASAP7_75t_R g030(.A1(new_n67_), .A2(new_n73_), .B(p20), .Y(new_n74_));
  INVx1_ASAP7_75t_R   g031(.A(p23), .Y(new_n75_));
  NAND2x1_ASAP7_75t_R g032(.A(p12), .B(new_n75_), .Y(new_n76_));
  AOI21x1_ASAP7_75t_R g033(.A1(new_n50_), .A2(o0), .B(new_n76_), .Y(new_n77_));
  INVx1_ASAP7_75t_R   g034(.A(p2), .Y(new_n78_));
  OR2x4_ASAP7_75t_R   g035(.A(p18), .B(new_n78_), .Y(new_n79_));
  AOI21x1_ASAP7_75t_R g036(.A1(new_n63_), .A2(o0), .B(new_n79_), .Y(new_n80_));
  NOR3x1_ASAP7_75t_R  g037(.A(new_n74_), .B(new_n77_), .C(new_n80_), .Y(new_n81_));
  NAND3x1_ASAP7_75t_R g038(.A(new_n59_), .B(new_n61_), .C(new_n63_), .Y(new_n82_));
  NOR2x1_ASAP7_75t_R  g039(.A(new_n44_), .B(new_n82_), .Y(new_n83_));
  NAND2x1_ASAP7_75t_R g040(.A(new_n69_), .B(new_n71_), .Y(new_n84_));
  NOR3x1_ASAP7_75t_R  g041(.A(new_n84_), .B(new_n47_), .C(new_n51_), .Y(new_n85_));
  NOR2x1_ASAP7_75t_R  g042(.A(p7), .B(new_n44_), .Y(new_n86_));
  AOI21x1_ASAP7_75t_R g043(.A1(new_n83_), .A2(new_n85_), .B(new_n86_), .Y(new_n87_));
  AOI21x1_ASAP7_75t_R g044(.A1(p12), .A2(new_n49_), .B(new_n66_), .Y(new_n88_));
  INVx1_ASAP7_75t_R   g045(.A(p10), .Y(new_n89_));
  NOR2x1_ASAP7_75t_R  g046(.A(p9), .B(new_n89_), .Y(new_n90_));
  NOR2x1_ASAP7_75t_R  g047(.A(new_n90_), .B(new_n86_), .Y(new_n91_));
  NAND3x1_ASAP7_75t_R g048(.A(new_n57_), .B(new_n88_), .C(new_n91_), .Y(new_n92_));
  INVx1_ASAP7_75t_R   g049(.A(p7), .Y(new_n93_));
  NAND2x1_ASAP7_75t_R g050(.A(new_n93_), .B(new_n64_), .Y(new_n94_));
  INVx1_ASAP7_75t_R   g051(.A(p21), .Y(new_n95_));
  OAI21x1_ASAP7_75t_R g052(.A1(new_n92_), .A2(new_n94_), .B(new_n95_), .Y(new_n96_));
  NOR2x1_ASAP7_75t_R  g053(.A(new_n87_), .B(new_n96_), .Y(new_n97_));
  INVx1_ASAP7_75t_R   g054(.A(p24), .Y(new_n98_));
  NAND2x1_ASAP7_75t_R g055(.A(p14), .B(new_n98_), .Y(new_n99_));
  NAND2x1_ASAP7_75t_R g056(.A(new_n61_), .B(new_n63_), .Y(new_n100_));
  NAND2x1_ASAP7_75t_R g057(.A(new_n69_), .B(new_n59_), .Y(new_n101_));
  NOR2x1_ASAP7_75t_R  g058(.A(new_n100_), .B(new_n101_), .Y(new_n102_));
  AOI21x1_ASAP7_75t_R g059(.A1(new_n52_), .A2(new_n102_), .B(new_n56_), .Y(new_n103_));
  NOR3x1_ASAP7_75t_R  g060(.A(new_n82_), .B(new_n47_), .C(new_n51_), .Y(new_n104_));
  AND3x1_ASAP7_75t_R  g061(.A(new_n70_), .B(p15), .C(p14), .Y(new_n105_));
  OR3x1_ASAP7_75t_R   g062(.A(new_n105_), .B(new_n53_), .C(p25), .Y(new_n106_));
  INVx1_ASAP7_75t_R   g063(.A(new_n106_), .Y(new_n107_));
  OAI21x1_ASAP7_75t_R g064(.A1(new_n54_), .A2(new_n104_), .B(new_n107_), .Y(new_n108_));
  OAI21x1_ASAP7_75t_R g065(.A1(new_n99_), .A2(new_n103_), .B(new_n108_), .Y(new_n109_));
  NOR2x1_ASAP7_75t_R  g066(.A(new_n97_), .B(new_n109_), .Y(new_n110_));
  NOR2x1_ASAP7_75t_R  g067(.A(p22), .B(new_n89_), .Y(new_n111_));
  INVx1_ASAP7_75t_R   g068(.A(new_n111_), .Y(new_n112_));
  AOI21x1_ASAP7_75t_R g069(.A1(p9), .A2(o0), .B(new_n112_), .Y(new_n113_));
  INVx1_ASAP7_75t_R   g070(.A(p4), .Y(new_n114_));
  NOR2x1_ASAP7_75t_R  g071(.A(p19), .B(new_n114_), .Y(new_n115_));
  INVx1_ASAP7_75t_R   g072(.A(new_n115_), .Y(new_n116_));
  NOR2x1_ASAP7_75t_R  g073(.A(new_n84_), .B(new_n100_), .Y(new_n117_));
  AOI21x1_ASAP7_75t_R g074(.A1(new_n52_), .A2(new_n117_), .B(new_n58_), .Y(new_n118_));
  NOR2x1_ASAP7_75t_R  g075(.A(new_n116_), .B(new_n118_), .Y(new_n119_));
  NAND2x1_ASAP7_75t_R g076(.A(new_n59_), .B(new_n63_), .Y(new_n120_));
  NOR2x1_ASAP7_75t_R  g077(.A(new_n84_), .B(new_n120_), .Y(new_n121_));
  NAND2x1_ASAP7_75t_R g078(.A(new_n52_), .B(new_n121_), .Y(new_n122_));
  INVx1_ASAP7_75t_R   g079(.A(p0), .Y(new_n123_));
  NOR2x1_ASAP7_75t_R  g080(.A(p17), .B(new_n123_), .Y(new_n124_));
  INVx1_ASAP7_75t_R   g081(.A(new_n124_), .Y(new_n125_));
  AOI21x1_ASAP7_75t_R g082(.A1(new_n61_), .A2(new_n122_), .B(new_n125_), .Y(new_n126_));
  NOR3x1_ASAP7_75t_R  g083(.A(new_n113_), .B(new_n119_), .C(new_n126_), .Y(new_n127_));
  NAND3x1_ASAP7_75t_R g084(.A(new_n81_), .B(new_n110_), .C(new_n127_), .Y(o1));
  AO21x1_ASAP7_75t_R  g085(.A1(p35), .A2(new_n122_), .B(new_n123_), .Y(new_n129_));
  NOR2x1_ASAP7_75t_R  g086(.A(p26), .B(new_n129_), .Y(new_n130_));
  INVx1_ASAP7_75t_R   g087(.A(new_n130_), .Y(new_n131_));
  AOI21x1_ASAP7_75t_R g088(.A1(p17), .A2(o1), .B(new_n131_), .Y(new_n132_));
  INVx1_ASAP7_75t_R   g089(.A(p31), .Y(new_n133_));
  AO21x1_ASAP7_75t_R  g090(.A1(p14), .A2(new_n70_), .B(new_n89_), .Y(new_n134_));
  NAND2x1_ASAP7_75t_R g091(.A(new_n52_), .B(new_n102_), .Y(new_n135_));
  OAI21x1_ASAP7_75t_R g092(.A1(new_n134_), .A2(new_n135_), .B(new_n46_), .Y(new_n136_));
  NOR3x1_ASAP7_75t_R  g093(.A(new_n103_), .B(p33), .C(new_n55_), .Y(new_n137_));
  AOI21x1_ASAP7_75t_R g094(.A1(new_n133_), .A2(new_n136_), .B(new_n137_), .Y(new_n138_));
  NOR2x1_ASAP7_75t_R  g095(.A(p27), .B(new_n78_), .Y(new_n139_));
  NAND2x1_ASAP7_75t_R g096(.A(new_n63_), .B(o0), .Y(new_n140_));
  OR2x4_ASAP7_75t_R   g097(.A(p28), .B(new_n114_), .Y(new_n141_));
  AO21x1_ASAP7_75t_R  g098(.A1(new_n59_), .A2(new_n100_), .B(new_n141_), .Y(new_n142_));
  AOI21x1_ASAP7_75t_R g099(.A1(new_n59_), .A2(new_n92_), .B(new_n142_), .Y(new_n143_));
  AOI21x1_ASAP7_75t_R g100(.A1(new_n139_), .A2(new_n140_), .B(new_n143_), .Y(new_n144_));
  INVx1_ASAP7_75t_R   g101(.A(p32), .Y(new_n145_));
  NAND2x1_ASAP7_75t_R g102(.A(p12), .B(new_n64_), .Y(new_n146_));
  OAI21x1_ASAP7_75t_R g103(.A1(new_n92_), .A2(new_n146_), .B(new_n50_), .Y(new_n147_));
  AO21x1_ASAP7_75t_R  g104(.A1(p15), .A2(new_n56_), .B(new_n53_), .Y(new_n148_));
  NOR2x1_ASAP7_75t_R  g105(.A(p34), .B(new_n148_), .Y(new_n149_));
  OA21x2_ASAP7_75t_R  g106(.A1(new_n54_), .A2(new_n104_), .B(new_n149_), .Y(new_n150_));
  AOI21x1_ASAP7_75t_R g107(.A1(new_n145_), .A2(new_n147_), .B(new_n150_), .Y(new_n151_));
  AND3x1_ASAP7_75t_R  g108(.A(new_n138_), .B(new_n144_), .C(new_n151_), .Y(new_n152_));
  INVx1_ASAP7_75t_R   g109(.A(p33), .Y(new_n153_));
  NOR2x1_ASAP7_75t_R  g110(.A(new_n99_), .B(new_n103_), .Y(new_n154_));
  NOR2x1_ASAP7_75t_R  g111(.A(p34), .B(new_n108_), .Y(new_n155_));
  AOI21x1_ASAP7_75t_R g112(.A1(new_n153_), .A2(new_n154_), .B(new_n155_), .Y(new_n156_));
  NAND2x1_ASAP7_75t_R g113(.A(new_n52_), .B(new_n117_), .Y(new_n157_));
  OR3x1_ASAP7_75t_R   g114(.A(new_n114_), .B(p28), .C(p19), .Y(new_n158_));
  AOI21x1_ASAP7_75t_R g115(.A1(new_n59_), .A2(new_n157_), .B(new_n158_), .Y(new_n159_));
  AOI21x1_ASAP7_75t_R g116(.A1(new_n145_), .A2(new_n77_), .B(new_n159_), .Y(new_n160_));
  INVx1_ASAP7_75t_R   g117(.A(p27), .Y(new_n161_));
  OR3x1_ASAP7_75t_R   g118(.A(new_n89_), .B(p31), .C(p22), .Y(new_n162_));
  AOI21x1_ASAP7_75t_R g119(.A1(new_n46_), .A2(o0), .B(new_n162_), .Y(new_n163_));
  AOI21x1_ASAP7_75t_R g120(.A1(new_n161_), .A2(new_n80_), .B(new_n163_), .Y(new_n164_));
  AND3x1_ASAP7_75t_R  g121(.A(new_n156_), .B(new_n160_), .C(new_n164_), .Y(new_n165_));
  OAI21x1_ASAP7_75t_R g122(.A1(new_n152_), .A2(o1), .B(new_n165_), .Y(new_n166_));
  NOR2x1_ASAP7_75t_R  g123(.A(new_n132_), .B(new_n166_), .Y(new_n167_));
  NAND2x1_ASAP7_75t_R g124(.A(new_n91_), .B(new_n88_), .Y(new_n168_));
  OR3x1_ASAP7_75t_R   g125(.A(new_n54_), .B(new_n56_), .C(new_n44_), .Y(new_n169_));
  NOR3x1_ASAP7_75t_R  g126(.A(new_n168_), .B(new_n82_), .C(new_n169_), .Y(new_n170_));
  NOR2x1_ASAP7_75t_R  g127(.A(p7), .B(new_n82_), .Y(new_n171_));
  AOI21x1_ASAP7_75t_R g128(.A1(new_n171_), .A2(new_n85_), .B(p21), .Y(new_n172_));
  OAI21x1_ASAP7_75t_R g129(.A1(new_n86_), .A2(new_n170_), .B(new_n172_), .Y(new_n173_));
  AO21x1_ASAP7_75t_R  g130(.A1(new_n71_), .A2(new_n135_), .B(new_n99_), .Y(new_n174_));
  NAND3x1_ASAP7_75t_R g131(.A(new_n173_), .B(new_n174_), .C(new_n108_), .Y(new_n175_));
  NOR3x1_ASAP7_75t_R  g132(.A(new_n168_), .B(new_n84_), .C(new_n82_), .Y(new_n176_));
  OAI21x1_ASAP7_75t_R g133(.A1(new_n45_), .A2(new_n176_), .B(new_n111_), .Y(new_n177_));
  AO21x1_ASAP7_75t_R  g134(.A1(new_n61_), .A2(new_n122_), .B(new_n125_), .Y(new_n178_));
  NAND3x1_ASAP7_75t_R g135(.A(new_n57_), .B(new_n61_), .C(new_n63_), .Y(new_n179_));
  OAI21x1_ASAP7_75t_R g136(.A1(new_n168_), .A2(new_n179_), .B(p3), .Y(new_n180_));
  NAND2x1_ASAP7_75t_R g137(.A(new_n115_), .B(new_n180_), .Y(new_n181_));
  NAND3x1_ASAP7_75t_R g138(.A(new_n177_), .B(new_n178_), .C(new_n181_), .Y(new_n182_));
  OAI21x1_ASAP7_75t_R g139(.A1(new_n175_), .A2(new_n182_), .B(p20), .Y(new_n183_));
  INVx1_ASAP7_75t_R   g140(.A(p29), .Y(new_n184_));
  INVx1_ASAP7_75t_R   g141(.A(new_n147_), .Y(new_n185_));
  AO21x1_ASAP7_75t_R  g142(.A1(new_n63_), .A2(o0), .B(new_n79_), .Y(new_n186_));
  OAI21x1_ASAP7_75t_R g143(.A1(p23), .A2(new_n185_), .B(new_n186_), .Y(new_n187_));
  AND2x2_ASAP7_75t_R  g144(.A(new_n67_), .B(new_n73_), .Y(new_n188_));
  AOI21x1_ASAP7_75t_R g145(.A1(p20), .A2(new_n187_), .B(new_n188_), .Y(new_n189_));
  AND3x1_ASAP7_75t_R  g146(.A(new_n183_), .B(new_n184_), .C(new_n189_), .Y(new_n190_));
  AO21x1_ASAP7_75t_R  g147(.A1(new_n83_), .A2(new_n85_), .B(new_n86_), .Y(new_n191_));
  AOI21x1_ASAP7_75t_R g148(.A1(new_n191_), .A2(new_n172_), .B(new_n113_), .Y(new_n192_));
  OAI21x1_ASAP7_75t_R g149(.A1(new_n116_), .A2(new_n118_), .B(new_n108_), .Y(new_n193_));
  NOR3x1_ASAP7_75t_R  g150(.A(new_n193_), .B(new_n126_), .C(new_n154_), .Y(new_n194_));
  AOI21x1_ASAP7_75t_R g151(.A1(new_n192_), .A2(new_n194_), .B(new_n95_), .Y(new_n195_));
  NOR2x1_ASAP7_75t_R  g152(.A(new_n77_), .B(new_n80_), .Y(new_n196_));
  AOI21x1_ASAP7_75t_R g153(.A1(p21), .A2(new_n74_), .B(new_n87_), .Y(new_n197_));
  OAI21x1_ASAP7_75t_R g154(.A1(new_n95_), .A2(new_n196_), .B(new_n197_), .Y(new_n198_));
  NOR3x1_ASAP7_75t_R  g155(.A(new_n195_), .B(p30), .C(new_n198_), .Y(new_n199_));
  NOR2x1_ASAP7_75t_R  g156(.A(new_n190_), .B(new_n199_), .Y(new_n200_));
  NAND2x1_ASAP7_75t_R g157(.A(new_n167_), .B(new_n200_), .Y(o2));
  NAND3x1_ASAP7_75t_R g158(.A(new_n138_), .B(new_n144_), .C(new_n151_), .Y(new_n202_));
  AND3x1_ASAP7_75t_R  g159(.A(new_n81_), .B(new_n110_), .C(new_n127_), .Y(new_n203_));
  NAND3x1_ASAP7_75t_R g160(.A(new_n156_), .B(new_n160_), .C(new_n164_), .Y(new_n204_));
  AOI21x1_ASAP7_75t_R g161(.A1(new_n202_), .A2(new_n203_), .B(new_n204_), .Y(new_n205_));
  OAI21x1_ASAP7_75t_R g162(.A1(new_n175_), .A2(new_n182_), .B(p17), .Y(new_n206_));
  OAI21x1_ASAP7_75t_R g163(.A1(new_n74_), .A2(new_n187_), .B(p17), .Y(new_n207_));
  NAND3x1_ASAP7_75t_R g164(.A(new_n206_), .B(new_n207_), .C(new_n130_), .Y(new_n208_));
  NAND3x1_ASAP7_75t_R g165(.A(new_n183_), .B(new_n189_), .C(new_n184_), .Y(new_n209_));
  NAND3x1_ASAP7_75t_R g166(.A(new_n205_), .B(new_n208_), .C(new_n209_), .Y(new_n210_));
  OAI21x1_ASAP7_75t_R g167(.A1(new_n87_), .A2(new_n96_), .B(new_n177_), .Y(new_n211_));
  OAI21x1_ASAP7_75t_R g168(.A1(new_n99_), .A2(new_n103_), .B(new_n178_), .Y(new_n212_));
  NOR3x1_ASAP7_75t_R  g169(.A(new_n211_), .B(new_n212_), .C(new_n193_), .Y(new_n213_));
  INVx1_ASAP7_75t_R   g170(.A(p30), .Y(new_n214_));
  OA21x2_ASAP7_75t_R  g171(.A1(new_n86_), .A2(new_n170_), .B(new_n214_), .Y(new_n215_));
  NAND3x1_ASAP7_75t_R g172(.A(new_n213_), .B(new_n81_), .C(new_n215_), .Y(new_n216_));
  INVx1_ASAP7_75t_R   g173(.A(new_n74_), .Y(new_n217_));
  NAND3x1_ASAP7_75t_R g174(.A(new_n196_), .B(new_n217_), .C(new_n136_), .Y(new_n218_));
  NOR2x1_ASAP7_75t_R  g175(.A(new_n126_), .B(new_n154_), .Y(new_n219_));
  NAND3x1_ASAP7_75t_R g176(.A(new_n64_), .B(new_n91_), .C(new_n88_), .Y(new_n220_));
  AOI21x1_ASAP7_75t_R g177(.A1(new_n69_), .A2(new_n220_), .B(new_n106_), .Y(new_n221_));
  AOI21x1_ASAP7_75t_R g178(.A1(new_n115_), .A2(new_n180_), .B(new_n221_), .Y(new_n222_));
  NAND3x1_ASAP7_75t_R g179(.A(new_n192_), .B(new_n219_), .C(new_n222_), .Y(new_n223_));
  OAI21x1_ASAP7_75t_R g180(.A1(new_n218_), .A2(new_n223_), .B(new_n177_), .Y(new_n224_));
  NAND2x1_ASAP7_75t_R g181(.A(new_n95_), .B(new_n215_), .Y(new_n225_));
  NAND3x1_ASAP7_75t_R g182(.A(new_n216_), .B(new_n224_), .C(new_n225_), .Y(new_n226_));
  OR3x1_ASAP7_75t_R   g183(.A(new_n188_), .B(new_n77_), .C(new_n80_), .Y(new_n227_));
  OAI21x1_ASAP7_75t_R g184(.A1(new_n227_), .A2(new_n223_), .B(new_n217_), .Y(new_n228_));
  AOI21x1_ASAP7_75t_R g185(.A1(new_n222_), .A2(new_n219_), .B(new_n95_), .Y(new_n229_));
  NOR2x1_ASAP7_75t_R  g186(.A(new_n95_), .B(new_n192_), .Y(new_n230_));
  OR3x1_ASAP7_75t_R   g187(.A(new_n198_), .B(new_n229_), .C(new_n230_), .Y(new_n231_));
  AOI21x1_ASAP7_75t_R g188(.A1(new_n184_), .A2(new_n228_), .B(new_n231_), .Y(new_n232_));
  AND3x1_ASAP7_75t_R  g189(.A(new_n196_), .B(new_n217_), .C(new_n136_), .Y(new_n233_));
  AOI21x1_ASAP7_75t_R g190(.A1(new_n213_), .A2(new_n233_), .B(new_n113_), .Y(new_n234_));
  NAND3x1_ASAP7_75t_R g191(.A(new_n222_), .B(new_n178_), .C(new_n174_), .Y(new_n235_));
  OAI21x1_ASAP7_75t_R g192(.A1(new_n211_), .A2(new_n235_), .B(p21), .Y(new_n236_));
  OA21x2_ASAP7_75t_R  g193(.A1(new_n95_), .A2(new_n196_), .B(new_n197_), .Y(new_n237_));
  NAND3x1_ASAP7_75t_R g194(.A(new_n236_), .B(new_n214_), .C(new_n237_), .Y(new_n238_));
  OAI21x1_ASAP7_75t_R g195(.A1(p31), .A2(new_n234_), .B(new_n238_), .Y(new_n239_));
  AOI21x1_ASAP7_75t_R g196(.A1(new_n167_), .A2(new_n232_), .B(new_n239_), .Y(new_n240_));
  OAI21x1_ASAP7_75t_R g197(.A1(new_n210_), .A2(new_n226_), .B(new_n240_), .Y(new_n241_));
  AO21x1_ASAP7_75t_R  g198(.A1(p23), .A2(o1), .B(new_n185_), .Y(new_n242_));
  NOR2x1_ASAP7_75t_R  g199(.A(new_n199_), .B(new_n242_), .Y(new_n243_));
  AND3x1_ASAP7_75t_R  g200(.A(new_n205_), .B(new_n208_), .C(new_n209_), .Y(new_n244_));
  NOR2x1_ASAP7_75t_R  g201(.A(p32), .B(new_n242_), .Y(new_n245_));
  AO21x1_ASAP7_75t_R  g202(.A1(new_n243_), .A2(new_n244_), .B(new_n245_), .Y(new_n246_));
  AO21x1_ASAP7_75t_R  g203(.A1(p13), .A2(new_n135_), .B(new_n55_), .Y(new_n247_));
  AO21x1_ASAP7_75t_R  g204(.A1(p24), .A2(o1), .B(new_n247_), .Y(new_n248_));
  NOR2x1_ASAP7_75t_R  g205(.A(new_n199_), .B(new_n248_), .Y(new_n249_));
  OA21x2_ASAP7_75t_R  g206(.A1(new_n98_), .A2(new_n203_), .B(new_n137_), .Y(new_n250_));
  AO21x1_ASAP7_75t_R  g207(.A1(new_n249_), .A2(new_n244_), .B(new_n250_), .Y(new_n251_));
  NOR3x1_ASAP7_75t_R  g208(.A(new_n241_), .B(new_n246_), .C(new_n251_), .Y(new_n252_));
  INVx1_ASAP7_75t_R   g209(.A(new_n252_), .Y(o4));
  AO21x1_ASAP7_75t_R  g210(.A1(p17), .A2(o1), .B(new_n129_), .Y(new_n254_));
  OR3x1_ASAP7_75t_R   g211(.A(new_n135_), .B(new_n78_), .C(new_n56_), .Y(new_n255_));
  AND2x2_ASAP7_75t_R  g212(.A(new_n63_), .B(new_n255_), .Y(new_n256_));
  AO21x1_ASAP7_75t_R  g213(.A1(p18), .A2(o1), .B(new_n256_), .Y(new_n257_));
  NAND2x1_ASAP7_75t_R g214(.A(p4), .B(new_n180_), .Y(new_n258_));
  AO21x1_ASAP7_75t_R  g215(.A1(p19), .A2(o1), .B(new_n258_), .Y(new_n259_));
  AND3x1_ASAP7_75t_R  g216(.A(new_n254_), .B(new_n257_), .C(new_n259_), .Y(new_n260_));
  INVx1_ASAP7_75t_R   g217(.A(new_n143_), .Y(new_n261_));
  AO21x1_ASAP7_75t_R  g218(.A1(p19), .A2(o1), .B(new_n261_), .Y(new_n262_));
  OA21x2_ASAP7_75t_R  g219(.A1(p27), .A2(new_n257_), .B(new_n262_), .Y(new_n263_));
  NAND3x1_ASAP7_75t_R g220(.A(new_n238_), .B(new_n205_), .C(new_n228_), .Y(new_n264_));
  AOI21x1_ASAP7_75t_R g221(.A1(new_n184_), .A2(new_n228_), .B(new_n132_), .Y(new_n265_));
  AND3x1_ASAP7_75t_R  g222(.A(new_n263_), .B(new_n264_), .C(new_n265_), .Y(new_n266_));
  OA21x2_ASAP7_75t_R  g223(.A1(o2), .A2(new_n260_), .B(new_n266_), .Y(new_n267_));
  AO21x1_ASAP7_75t_R  g224(.A1(new_n69_), .A2(new_n220_), .B(new_n148_), .Y(new_n268_));
  AO21x1_ASAP7_75t_R  g225(.A1(p25), .A2(o1), .B(new_n268_), .Y(new_n269_));
  AOI21x1_ASAP7_75t_R g226(.A1(p34), .A2(o2), .B(new_n269_), .Y(new_n270_));
  AOI21x1_ASAP7_75t_R g227(.A1(new_n267_), .A2(new_n252_), .B(new_n270_), .Y(o3));
  NAND2x1_ASAP7_75t_R g228(.A(new_n208_), .B(new_n209_), .Y(new_n272_));
  NOR3x1_ASAP7_75t_R  g229(.A(new_n272_), .B(new_n226_), .C(new_n166_), .Y(new_n273_));
  NOR3x1_ASAP7_75t_R  g230(.A(new_n198_), .B(new_n229_), .C(new_n230_), .Y(new_n274_));
  NAND2x1_ASAP7_75t_R g231(.A(new_n274_), .B(new_n209_), .Y(new_n275_));
  NAND3x1_ASAP7_75t_R g232(.A(new_n213_), .B(new_n202_), .C(new_n81_), .Y(new_n276_));
  NAND3x1_ASAP7_75t_R g233(.A(new_n208_), .B(new_n276_), .C(new_n165_), .Y(new_n277_));
  AOI21x1_ASAP7_75t_R g234(.A1(new_n133_), .A2(new_n224_), .B(new_n199_), .Y(new_n278_));
  OAI21x1_ASAP7_75t_R g235(.A1(new_n275_), .A2(new_n277_), .B(new_n278_), .Y(new_n279_));
  NOR2x1_ASAP7_75t_R  g236(.A(new_n273_), .B(new_n279_), .Y(new_n280_));
  AOI21x1_ASAP7_75t_R g237(.A1(new_n243_), .A2(new_n244_), .B(new_n245_), .Y(new_n281_));
  OAI21x1_ASAP7_75t_R g238(.A1(new_n132_), .A2(new_n264_), .B(new_n209_), .Y(new_n282_));
  NAND3x1_ASAP7_75t_R g239(.A(new_n280_), .B(new_n281_), .C(new_n282_), .Y(new_n283_));
  NOR2x1_ASAP7_75t_R  g240(.A(new_n246_), .B(new_n251_), .Y(new_n284_));
  AOI21x1_ASAP7_75t_R g241(.A1(p19), .A2(o1), .B(new_n258_), .Y(new_n285_));
  NAND2x1_ASAP7_75t_R g242(.A(new_n285_), .B(new_n238_), .Y(new_n286_));
  OAI21x1_ASAP7_75t_R g243(.A1(new_n286_), .A2(new_n210_), .B(new_n262_), .Y(new_n287_));
  NAND2x1_ASAP7_75t_R g244(.A(new_n287_), .B(new_n280_), .Y(new_n288_));
  NAND3x1_ASAP7_75t_R g245(.A(new_n283_), .B(new_n284_), .C(new_n288_), .Y(o5));
  AOI21x1_ASAP7_75t_R g246(.A1(new_n167_), .A2(new_n200_), .B(new_n161_), .Y(new_n290_));
  AOI21x1_ASAP7_75t_R g247(.A1(p23), .A2(o1), .B(new_n185_), .Y(new_n291_));
  NAND2x1_ASAP7_75t_R g248(.A(new_n291_), .B(new_n238_), .Y(new_n292_));
  AOI21x1_ASAP7_75t_R g249(.A1(new_n145_), .A2(new_n291_), .B(new_n257_), .Y(new_n293_));
  OAI21x1_ASAP7_75t_R g250(.A1(new_n292_), .A2(new_n210_), .B(new_n293_), .Y(new_n294_));
  NOR2x1_ASAP7_75t_R  g251(.A(new_n290_), .B(new_n294_), .Y(new_n295_));
  NAND2x1_ASAP7_75t_R g252(.A(new_n133_), .B(new_n224_), .Y(new_n296_));
  OAI21x1_ASAP7_75t_R g253(.A1(new_n226_), .A2(new_n210_), .B(new_n296_), .Y(new_n297_));
  NOR2x1_ASAP7_75t_R  g254(.A(new_n297_), .B(new_n287_), .Y(new_n298_));
  NAND2x1_ASAP7_75t_R g255(.A(new_n295_), .B(new_n298_), .Y(new_n299_));
  AOI21x1_ASAP7_75t_R g256(.A1(new_n297_), .A2(new_n281_), .B(new_n251_), .Y(new_n300_));
  NAND3x1_ASAP7_75t_R g257(.A(new_n299_), .B(new_n283_), .C(new_n300_), .Y(o6));
endmodule


