// Benchmark "/tmp/" written by ABC on Mon Oct 12 14:40:57 2026

module \/tmp/  ( 
    p24, p33, p31, p13, p27, p23, p28, p22, p7, p18, p2, p19, p34, p5, p0,
    p4, p21, p8, p16, p25, p10, p15, p26, p35, p1, p11, p9, p30, p3, p20,
    p14, p32, p17, p29, p12, p6,
    o0, o1, o2, o4, o3, o5, o6  );
  input  p24, p33, p31, p13, p27, p23, p28, p22, p7, p18, p2, p19, p34,
    p5, p0, p4, p21, p8, p16, p25, p10, p15, p26, p35, p1, p11, p9, p30,
    p3, p20, p14, p32, p17, p29, p12, p6;
  output o0, o1, o2, o4, o3, o5, o6;
  wire new_n44_, new_n45_, new_n46_, new_n47_, new_n48_, new_n49_, new_n50_,
    new_n51_, new_n52_, new_n53_, new_n54_, new_n55_, new_n56_, new_n57_,
    new_n58_, new_n59_, new_n60_, new_n61_, new_n62_, new_n63_, new_n64_,
    new_n66_, new_n67_, new_n68_, new_n69_, new_n70_, new_n71_, new_n72_,
    new_n73_, new_n74_, new_n75_, new_n76_, new_n77_, new_n78_, new_n79_,
    new_n80_, new_n81_, new_n82_, new_n83_, new_n84_, new_n85_, new_n86_,
    new_n87_, new_n88_, new_n89_, new_n90_, new_n91_, new_n92_, new_n93_,
    new_n94_, new_n95_, new_n96_, new_n97_, new_n98_, new_n99_, new_n100_,
    new_n101_, new_n102_, new_n103_, new_n104_, new_n105_, new_n106_,
    new_n107_, new_n108_, new_n109_, new_n110_, new_n111_, new_n112_,
    new_n113_, new_n114_, new_n115_, new_n116_, new_n117_, new_n118_,
    new_n119_, new_n120_, new_n122_, new_n123_, new_n124_, new_n125_,
    new_n126_, new_n127_, new_n128_, new_n129_, new_n130_, new_n131_,
    new_n132_, new_n133_, new_n134_, new_n135_, new_n136_, new_n137_,
    new_n138_, new_n139_, new_n140_, new_n141_, new_n142_, new_n143_,
    new_n144_, new_n145_, new_n146_, new_n147_, new_n148_, new_n149_,
    new_n150_, new_n151_, new_n152_, new_n153_, new_n154_, new_n155_,
    new_n156_, new_n157_, new_n158_, new_n159_, new_n160_, new_n161_,
    new_n162_, new_n163_, new_n164_, new_n165_, new_n166_, new_n167_,
    new_n168_, new_n169_, new_n170_, new_n171_, new_n172_, new_n173_,
    new_n174_, new_n175_, new_n176_, new_n177_, new_n178_, new_n179_,
    new_n180_, new_n181_, new_n182_, new_n183_, new_n184_, new_n185_,
    new_n186_, new_n187_, new_n189_, new_n190_, new_n191_, new_n192_,
    new_n193_, new_n194_, new_n195_, new_n196_, new_n197_, new_n198_,
    new_n199_, new_n200_, new_n201_, new_n202_, new_n203_, new_n204_,
    new_n205_, new_n206_, new_n207_, new_n208_, new_n209_, new_n210_,
    new_n211_, new_n212_, new_n213_, new_n214_, new_n215_, new_n216_,
    new_n217_, new_n218_, new_n219_, new_n220_, new_n221_, new_n222_,
    new_n223_, new_n224_, new_n225_, new_n226_, new_n227_, new_n228_,
    new_n229_, new_n230_, new_n231_, new_n232_, new_n233_, new_n234_,
    new_n235_, new_n236_, new_n237_, new_n238_, new_n239_, new_n240_,
    new_n241_, new_n242_, new_n243_, new_n244_, new_n245_, new_n246_,
    new_n247_, new_n248_, new_n249_, new_n250_, new_n252_, new_n253_,
    new_n254_, new_n255_, new_n256_, new_n257_, new_n258_, new_n259_,
    new_n260_, new_n261_, new_n262_, new_n263_, new_n264_, new_n265_,
    new_n266_, new_n267_, new_n268_, new_n269_, new_n271_, new_n272_,
    new_n273_, new_n274_, new_n275_, new_n276_, new_n277_, new_n278_,
    new_n279_, new_n280_, new_n281_, new_n282_, new_n284_, new_n285_,
    new_n286_, new_n287_, new_n288_, new_n289_, new_n290_, new_n291_,
    new_n292_, new_n293_, new_n294_, new_n295_, new_n296_;
  INVx1_ASAP7_75t_R   g000(.A(p8), .Y(new_n44_));
  INVx1_ASAP7_75t_R   g001(.A(p9), .Y(new_n45_));
  NAND2x1_ASAP7_75t_R g002(.A(p10), .B(new_n45_), .Y(new_n46_));
  OAI21x1_ASAP7_75t_R g003(.A1(p7), .A2(new_n44_), .B(new_n46_), .Y(new_n47_));
  INVx1_ASAP7_75t_R   g004(.A(p12), .Y(new_n48_));
  INVx1_ASAP7_75t_R   g005(.A(p5), .Y(new_n49_));
  NAND2x1_ASAP7_75t_R g006(.A(p6), .B(new_n49_), .Y(new_n50_));
  OAI21x1_ASAP7_75t_R g007(.A1(p11), .A2(new_n48_), .B(new_n50_), .Y(new_n51_));
  NOR2x1_ASAP7_75t_R  g008(.A(new_n47_), .B(new_n51_), .Y(new_n52_));
  INVx1_ASAP7_75t_R   g009(.A(p14), .Y(new_n53_));
  NOR2x1_ASAP7_75t_R  g010(.A(p13), .B(new_n53_), .Y(new_n54_));
  INVx1_ASAP7_75t_R   g011(.A(p16), .Y(new_n55_));
  NOR2x1_ASAP7_75t_R  g012(.A(p15), .B(new_n55_), .Y(new_n56_));
  NOR2x1_ASAP7_75t_R  g013(.A(new_n54_), .B(new_n56_), .Y(new_n57_));
  INVx1_ASAP7_75t_R   g014(.A(p35), .Y(new_n58_));
  NAND2x1_ASAP7_75t_R g015(.A(p0), .B(new_n58_), .Y(new_n59_));
  INVx1_ASAP7_75t_R   g016(.A(p3), .Y(new_n60_));
  NAND2x1_ASAP7_75t_R g017(.A(p4), .B(new_n60_), .Y(new_n61_));
  INVx1_ASAP7_75t_R   g018(.A(p1), .Y(new_n62_));
  NAND2x1_ASAP7_75t_R g019(.A(p2), .B(new_n62_), .Y(new_n63_));
  AND3x1_ASAP7_75t_R  g020(.A(new_n59_), .B(new_n61_), .C(new_n63_), .Y(new_n64_));
  NAND3x1_ASAP7_75t_R g021(.A(new_n52_), .B(new_n57_), .C(new_n64_), .Y(o0));
  INVx1_ASAP7_75t_R   g022(.A(p6), .Y(new_n66_));
  OR2x4_ASAP7_75t_R   g023(.A(p20), .B(new_n66_), .Y(new_n67_));
  AOI21x1_ASAP7_75t_R g024(.A1(new_n50_), .A2(o0), .B(new_n67_), .Y(new_n68_));
  INVx1_ASAP7_75t_R   g025(.A(p18), .Y(new_n69_));
  NAND2x1_ASAP7_75t_R g026(.A(p2), .B(new_n69_), .Y(new_n70_));
  AOI21x1_ASAP7_75t_R g027(.A1(new_n63_), .A2(o0), .B(new_n70_), .Y(new_n71_));
  NOR2x1_ASAP7_75t_R  g028(.A(p11), .B(new_n48_), .Y(new_n72_));
  INVx1_ASAP7_75t_R   g029(.A(new_n72_), .Y(new_n73_));
  INVx1_ASAP7_75t_R   g030(.A(p13), .Y(new_n74_));
  NAND2x1_ASAP7_75t_R g031(.A(p14), .B(new_n74_), .Y(new_n75_));
  INVx1_ASAP7_75t_R   g032(.A(p15), .Y(new_n76_));
  NAND2x1_ASAP7_75t_R g033(.A(p16), .B(new_n76_), .Y(new_n77_));
  AND3x1_ASAP7_75t_R  g034(.A(new_n75_), .B(new_n77_), .C(p12), .Y(new_n78_));
  NAND3x1_ASAP7_75t_R g035(.A(new_n52_), .B(new_n64_), .C(new_n78_), .Y(new_n79_));
  AOI21x1_ASAP7_75t_R g036(.A1(new_n73_), .A2(new_n79_), .B(p23), .Y(new_n80_));
  NOR3x1_ASAP7_75t_R  g037(.A(new_n68_), .B(new_n71_), .C(new_n80_), .Y(new_n81_));
  AOI21x1_ASAP7_75t_R g038(.A1(new_n64_), .A2(new_n52_), .B(new_n56_), .Y(new_n82_));
  AO21x1_ASAP7_75t_R  g039(.A1(p15), .A2(new_n54_), .B(new_n55_), .Y(new_n83_));
  NOR2x1_ASAP7_75t_R  g040(.A(p25), .B(new_n83_), .Y(new_n84_));
  INVx1_ASAP7_75t_R   g041(.A(new_n84_), .Y(new_n85_));
  INVx1_ASAP7_75t_R   g042(.A(p4), .Y(new_n86_));
  NOR2x1_ASAP7_75t_R  g043(.A(p3), .B(new_n86_), .Y(new_n87_));
  NAND2x1_ASAP7_75t_R g044(.A(new_n75_), .B(new_n77_), .Y(new_n88_));
  NOR3x1_ASAP7_75t_R  g045(.A(new_n88_), .B(new_n47_), .C(new_n51_), .Y(new_n89_));
  NAND2x1_ASAP7_75t_R g046(.A(new_n59_), .B(new_n63_), .Y(new_n90_));
  OR2x4_ASAP7_75t_R   g047(.A(p19), .B(new_n86_), .Y(new_n91_));
  AOI21x1_ASAP7_75t_R g048(.A1(new_n61_), .A2(new_n90_), .B(new_n91_), .Y(new_n92_));
  OAI21x1_ASAP7_75t_R g049(.A1(new_n87_), .A2(new_n89_), .B(new_n92_), .Y(new_n93_));
  OAI21x1_ASAP7_75t_R g050(.A1(new_n82_), .A2(new_n85_), .B(new_n93_), .Y(new_n94_));
  NAND2x1_ASAP7_75t_R g051(.A(new_n61_), .B(new_n63_), .Y(new_n95_));
  NOR2x1_ASAP7_75t_R  g052(.A(new_n88_), .B(new_n95_), .Y(new_n96_));
  NAND2x1_ASAP7_75t_R g053(.A(new_n52_), .B(new_n96_), .Y(new_n97_));
  INVx1_ASAP7_75t_R   g054(.A(p0), .Y(new_n98_));
  NOR2x1_ASAP7_75t_R  g055(.A(p17), .B(new_n98_), .Y(new_n99_));
  INVx1_ASAP7_75t_R   g056(.A(new_n99_), .Y(new_n100_));
  AOI21x1_ASAP7_75t_R g057(.A1(new_n59_), .A2(new_n97_), .B(new_n100_), .Y(new_n101_));
  NAND2x1_ASAP7_75t_R g058(.A(new_n77_), .B(new_n59_), .Y(new_n102_));
  NOR2x1_ASAP7_75t_R  g059(.A(new_n95_), .B(new_n102_), .Y(new_n103_));
  NAND2x1_ASAP7_75t_R g060(.A(new_n52_), .B(new_n103_), .Y(new_n104_));
  NOR2x1_ASAP7_75t_R  g061(.A(p24), .B(new_n53_), .Y(new_n105_));
  INVx1_ASAP7_75t_R   g062(.A(new_n105_), .Y(new_n106_));
  AOI21x1_ASAP7_75t_R g063(.A1(new_n75_), .A2(new_n104_), .B(new_n106_), .Y(new_n107_));
  NOR3x1_ASAP7_75t_R  g064(.A(new_n94_), .B(new_n101_), .C(new_n107_), .Y(new_n108_));
  INVx1_ASAP7_75t_R   g065(.A(p2), .Y(new_n109_));
  NOR2x1_ASAP7_75t_R  g066(.A(p1), .B(new_n109_), .Y(new_n110_));
  NOR2x1_ASAP7_75t_R  g067(.A(new_n87_), .B(new_n110_), .Y(new_n111_));
  AND3x1_ASAP7_75t_R  g068(.A(new_n111_), .B(p8), .C(new_n59_), .Y(new_n112_));
  NOR2x1_ASAP7_75t_R  g069(.A(p7), .B(new_n44_), .Y(new_n113_));
  AO21x1_ASAP7_75t_R  g070(.A1(new_n89_), .A2(new_n112_), .B(new_n113_), .Y(new_n114_));
  NOR3x1_ASAP7_75t_R  g071(.A(new_n90_), .B(p7), .C(new_n87_), .Y(new_n115_));
  AOI21x1_ASAP7_75t_R g072(.A1(new_n115_), .A2(new_n89_), .B(p21), .Y(new_n116_));
  INVx1_ASAP7_75t_R   g073(.A(p10), .Y(new_n117_));
  OR2x4_ASAP7_75t_R   g074(.A(p22), .B(new_n117_), .Y(new_n118_));
  AOI21x1_ASAP7_75t_R g075(.A1(new_n46_), .A2(o0), .B(new_n118_), .Y(new_n119_));
  AOI21x1_ASAP7_75t_R g076(.A1(new_n114_), .A2(new_n116_), .B(new_n119_), .Y(new_n120_));
  NAND3x1_ASAP7_75t_R g077(.A(new_n81_), .B(new_n108_), .C(new_n120_), .Y(o1));
  AO21x1_ASAP7_75t_R  g078(.A1(new_n50_), .A2(o0), .B(new_n67_), .Y(new_n122_));
  AOI21x1_ASAP7_75t_R g079(.A1(p10), .A2(new_n45_), .B(new_n113_), .Y(new_n123_));
  NOR2x1_ASAP7_75t_R  g080(.A(p5), .B(new_n66_), .Y(new_n124_));
  NOR2x1_ASAP7_75t_R  g081(.A(new_n72_), .B(new_n124_), .Y(new_n125_));
  NAND3x1_ASAP7_75t_R g082(.A(new_n57_), .B(new_n123_), .C(new_n125_), .Y(new_n126_));
  NAND2x1_ASAP7_75t_R g083(.A(p6), .B(new_n64_), .Y(new_n127_));
  OA21x2_ASAP7_75t_R  g084(.A1(new_n126_), .A2(new_n127_), .B(new_n50_), .Y(new_n128_));
  NOR3x1_ASAP7_75t_R  g085(.A(new_n71_), .B(new_n80_), .C(new_n128_), .Y(new_n129_));
  NAND3x1_ASAP7_75t_R g086(.A(new_n108_), .B(new_n129_), .C(new_n120_), .Y(new_n130_));
  AOI21x1_ASAP7_75t_R g087(.A1(new_n122_), .A2(new_n130_), .B(p29), .Y(new_n131_));
  INVx1_ASAP7_75t_R   g088(.A(p17), .Y(new_n132_));
  AOI21x1_ASAP7_75t_R g089(.A1(new_n120_), .A2(new_n108_), .B(new_n132_), .Y(new_n133_));
  AO21x1_ASAP7_75t_R  g090(.A1(p35), .A2(new_n97_), .B(new_n98_), .Y(new_n134_));
  NOR2x1_ASAP7_75t_R  g091(.A(p26), .B(new_n134_), .Y(new_n135_));
  INVx1_ASAP7_75t_R   g092(.A(new_n135_), .Y(new_n136_));
  NOR2x1_ASAP7_75t_R  g093(.A(new_n132_), .B(new_n81_), .Y(new_n137_));
  NOR3x1_ASAP7_75t_R  g094(.A(new_n133_), .B(new_n136_), .C(new_n137_), .Y(new_n138_));
  NOR2x1_ASAP7_75t_R  g095(.A(new_n131_), .B(new_n138_), .Y(new_n139_));
  INVx1_ASAP7_75t_R   g096(.A(p7), .Y(new_n140_));
  INVx1_ASAP7_75t_R   g097(.A(o0), .Y(new_n141_));
  NOR2x1_ASAP7_75t_R  g098(.A(p30), .B(new_n44_), .Y(new_n142_));
  OA21x2_ASAP7_75t_R  g099(.A1(new_n140_), .A2(new_n141_), .B(new_n142_), .Y(new_n143_));
  INVx1_ASAP7_75t_R   g100(.A(new_n143_), .Y(new_n144_));
  AOI21x1_ASAP7_75t_R g101(.A1(p21), .A2(o1), .B(new_n144_), .Y(new_n145_));
  INVx1_ASAP7_75t_R   g102(.A(p31), .Y(new_n146_));
  NAND2x1_ASAP7_75t_R g103(.A(p10), .B(new_n64_), .Y(new_n147_));
  OAI21x1_ASAP7_75t_R g104(.A1(new_n126_), .A2(new_n147_), .B(new_n46_), .Y(new_n148_));
  INVx1_ASAP7_75t_R   g105(.A(p32), .Y(new_n149_));
  NAND2x1_ASAP7_75t_R g106(.A(p12), .B(new_n149_), .Y(new_n150_));
  AOI21x1_ASAP7_75t_R g107(.A1(p11), .A2(o0), .B(new_n150_), .Y(new_n151_));
  AOI21x1_ASAP7_75t_R g108(.A1(new_n146_), .A2(new_n148_), .B(new_n151_), .Y(new_n152_));
  NAND2x1_ASAP7_75t_R g109(.A(new_n125_), .B(new_n123_), .Y(new_n153_));
  NOR2x1_ASAP7_75t_R  g110(.A(p35), .B(new_n98_), .Y(new_n154_));
  NOR2x1_ASAP7_75t_R  g111(.A(new_n56_), .B(new_n154_), .Y(new_n155_));
  NAND2x1_ASAP7_75t_R g112(.A(new_n111_), .B(new_n155_), .Y(new_n156_));
  OAI21x1_ASAP7_75t_R g113(.A1(new_n153_), .A2(new_n156_), .B(new_n75_), .Y(new_n157_));
  NOR2x1_ASAP7_75t_R  g114(.A(p33), .B(new_n53_), .Y(new_n158_));
  INVx1_ASAP7_75t_R   g115(.A(p34), .Y(new_n159_));
  INVx1_ASAP7_75t_R   g116(.A(new_n83_), .Y(new_n160_));
  NAND2x1_ASAP7_75t_R g117(.A(new_n159_), .B(new_n160_), .Y(new_n161_));
  NOR2x1_ASAP7_75t_R  g118(.A(new_n161_), .B(new_n82_), .Y(new_n162_));
  AOI21x1_ASAP7_75t_R g119(.A1(new_n157_), .A2(new_n158_), .B(new_n162_), .Y(new_n163_));
  INVx1_ASAP7_75t_R   g120(.A(p27), .Y(new_n164_));
  NAND3x1_ASAP7_75t_R g121(.A(new_n57_), .B(new_n111_), .C(new_n59_), .Y(new_n165_));
  NAND3x1_ASAP7_75t_R g122(.A(new_n123_), .B(new_n125_), .C(p2), .Y(new_n166_));
  OAI21x1_ASAP7_75t_R g123(.A1(new_n165_), .A2(new_n166_), .B(new_n63_), .Y(new_n167_));
  NOR2x1_ASAP7_75t_R  g124(.A(p28), .B(new_n86_), .Y(new_n168_));
  INVx1_ASAP7_75t_R   g125(.A(new_n168_), .Y(new_n169_));
  NOR2x1_ASAP7_75t_R  g126(.A(new_n88_), .B(new_n90_), .Y(new_n170_));
  AOI21x1_ASAP7_75t_R g127(.A1(new_n52_), .A2(new_n170_), .B(new_n87_), .Y(new_n171_));
  NOR2x1_ASAP7_75t_R  g128(.A(new_n169_), .B(new_n171_), .Y(new_n172_));
  AOI21x1_ASAP7_75t_R g129(.A1(new_n164_), .A2(new_n167_), .B(new_n172_), .Y(new_n173_));
  AND3x1_ASAP7_75t_R  g130(.A(new_n152_), .B(new_n163_), .C(new_n173_), .Y(new_n174_));
  INVx1_ASAP7_75t_R   g131(.A(p24), .Y(new_n175_));
  AND3x1_ASAP7_75t_R  g132(.A(new_n157_), .B(new_n175_), .C(new_n158_), .Y(new_n176_));
  AO21x1_ASAP7_75t_R  g133(.A1(new_n64_), .A2(new_n52_), .B(new_n56_), .Y(new_n177_));
  AND3x1_ASAP7_75t_R  g134(.A(new_n177_), .B(new_n159_), .C(new_n84_), .Y(new_n178_));
  NOR2x1_ASAP7_75t_R  g135(.A(new_n176_), .B(new_n178_), .Y(new_n179_));
  OR3x1_ASAP7_75t_R   g136(.A(new_n117_), .B(p31), .C(p22), .Y(new_n180_));
  AOI21x1_ASAP7_75t_R g137(.A1(new_n46_), .A2(o0), .B(new_n180_), .Y(new_n181_));
  AOI21x1_ASAP7_75t_R g138(.A1(new_n149_), .A2(new_n80_), .B(new_n181_), .Y(new_n182_));
  NOR3x1_ASAP7_75t_R  g139(.A(new_n171_), .B(p19), .C(new_n169_), .Y(new_n183_));
  AOI21x1_ASAP7_75t_R g140(.A1(new_n164_), .A2(new_n71_), .B(new_n183_), .Y(new_n184_));
  AND3x1_ASAP7_75t_R  g141(.A(new_n179_), .B(new_n182_), .C(new_n184_), .Y(new_n185_));
  OAI21x1_ASAP7_75t_R g142(.A1(new_n174_), .A2(o1), .B(new_n185_), .Y(new_n186_));
  NOR2x1_ASAP7_75t_R  g143(.A(new_n145_), .B(new_n186_), .Y(new_n187_));
  NAND2x1_ASAP7_75t_R g144(.A(new_n139_), .B(new_n187_), .Y(o2));
  NAND3x1_ASAP7_75t_R g145(.A(new_n152_), .B(new_n173_), .C(new_n163_), .Y(new_n189_));
  AO21x1_ASAP7_75t_R  g146(.A1(new_n73_), .A2(new_n79_), .B(p23), .Y(new_n190_));
  NAND2x1_ASAP7_75t_R g147(.A(new_n69_), .B(new_n167_), .Y(new_n191_));
  NAND3x1_ASAP7_75t_R g148(.A(new_n122_), .B(new_n190_), .C(new_n191_), .Y(new_n192_));
  OR3x1_ASAP7_75t_R   g149(.A(new_n154_), .B(new_n87_), .C(new_n110_), .Y(new_n193_));
  OR3x1_ASAP7_75t_R   g150(.A(new_n54_), .B(new_n56_), .C(new_n44_), .Y(new_n194_));
  NOR3x1_ASAP7_75t_R  g151(.A(new_n153_), .B(new_n193_), .C(new_n194_), .Y(new_n195_));
  OAI21x1_ASAP7_75t_R g152(.A1(new_n113_), .A2(new_n195_), .B(new_n116_), .Y(new_n196_));
  AO21x1_ASAP7_75t_R  g153(.A1(new_n59_), .A2(new_n97_), .B(new_n100_), .Y(new_n197_));
  NAND2x1_ASAP7_75t_R g154(.A(new_n105_), .B(new_n157_), .Y(new_n198_));
  NAND3x1_ASAP7_75t_R g155(.A(new_n196_), .B(new_n197_), .C(new_n198_), .Y(new_n199_));
  AO21x1_ASAP7_75t_R  g156(.A1(new_n46_), .A2(o0), .B(new_n118_), .Y(new_n200_));
  AO21x1_ASAP7_75t_R  g157(.A1(new_n61_), .A2(new_n90_), .B(new_n91_), .Y(new_n201_));
  AOI21x1_ASAP7_75t_R g158(.A1(new_n61_), .A2(new_n126_), .B(new_n201_), .Y(new_n202_));
  AOI21x1_ASAP7_75t_R g159(.A1(new_n177_), .A2(new_n84_), .B(new_n202_), .Y(new_n203_));
  NAND2x1_ASAP7_75t_R g160(.A(new_n200_), .B(new_n203_), .Y(new_n204_));
  NOR3x1_ASAP7_75t_R  g161(.A(new_n192_), .B(new_n199_), .C(new_n204_), .Y(new_n205_));
  NAND3x1_ASAP7_75t_R g162(.A(new_n179_), .B(new_n182_), .C(new_n184_), .Y(new_n206_));
  AOI21x1_ASAP7_75t_R g163(.A1(new_n189_), .A2(new_n205_), .B(new_n206_), .Y(new_n207_));
  OAI21x1_ASAP7_75t_R g164(.A1(new_n204_), .A2(new_n199_), .B(p17), .Y(new_n208_));
  NAND2x1_ASAP7_75t_R g165(.A(p17), .B(new_n192_), .Y(new_n209_));
  NAND3x1_ASAP7_75t_R g166(.A(new_n208_), .B(new_n209_), .C(new_n135_), .Y(new_n210_));
  OAI21x1_ASAP7_75t_R g167(.A1(new_n204_), .A2(new_n199_), .B(p20), .Y(new_n211_));
  NAND2x1_ASAP7_75t_R g168(.A(new_n191_), .B(new_n190_), .Y(new_n212_));
  AOI21x1_ASAP7_75t_R g169(.A1(p20), .A2(new_n212_), .B(new_n128_), .Y(new_n213_));
  INVx1_ASAP7_75t_R   g170(.A(p29), .Y(new_n214_));
  NAND3x1_ASAP7_75t_R g171(.A(new_n211_), .B(new_n213_), .C(new_n214_), .Y(new_n215_));
  NAND3x1_ASAP7_75t_R g172(.A(new_n207_), .B(new_n210_), .C(new_n215_), .Y(new_n216_));
  NOR2x1_ASAP7_75t_R  g173(.A(new_n71_), .B(new_n80_), .Y(new_n217_));
  NAND3x1_ASAP7_75t_R g174(.A(new_n217_), .B(new_n122_), .C(new_n148_), .Y(new_n218_));
  NAND2x1_ASAP7_75t_R g175(.A(new_n120_), .B(new_n108_), .Y(new_n219_));
  OAI21x1_ASAP7_75t_R g176(.A1(new_n218_), .A2(new_n219_), .B(new_n200_), .Y(new_n220_));
  INVx1_ASAP7_75t_R   g177(.A(p21), .Y(new_n221_));
  OAI21x1_ASAP7_75t_R g178(.A1(new_n221_), .A2(new_n205_), .B(new_n143_), .Y(new_n222_));
  NAND2x1_ASAP7_75t_R g179(.A(new_n220_), .B(new_n222_), .Y(new_n223_));
  NOR2x1_ASAP7_75t_R  g180(.A(new_n113_), .B(new_n195_), .Y(new_n224_));
  AOI21x1_ASAP7_75t_R g181(.A1(p21), .A2(new_n68_), .B(new_n224_), .Y(new_n225_));
  OAI21x1_ASAP7_75t_R g182(.A1(new_n71_), .A2(new_n80_), .B(p21), .Y(new_n226_));
  NAND2x1_ASAP7_75t_R g183(.A(new_n225_), .B(new_n226_), .Y(new_n227_));
  NOR2x1_ASAP7_75t_R  g184(.A(new_n101_), .B(new_n107_), .Y(new_n228_));
  AOI21x1_ASAP7_75t_R g185(.A1(new_n203_), .A2(new_n228_), .B(new_n221_), .Y(new_n229_));
  NOR2x1_ASAP7_75t_R  g186(.A(new_n221_), .B(new_n120_), .Y(new_n230_));
  OR3x1_ASAP7_75t_R   g187(.A(new_n227_), .B(new_n229_), .C(new_n230_), .Y(new_n231_));
  NOR2x1_ASAP7_75t_R  g188(.A(new_n231_), .B(new_n186_), .Y(new_n232_));
  NOR2x1_ASAP7_75t_R  g189(.A(new_n204_), .B(new_n199_), .Y(new_n233_));
  AND3x1_ASAP7_75t_R  g190(.A(new_n217_), .B(new_n122_), .C(new_n148_), .Y(new_n234_));
  AOI21x1_ASAP7_75t_R g191(.A1(new_n233_), .A2(new_n234_), .B(new_n119_), .Y(new_n235_));
  OAI21x1_ASAP7_75t_R g192(.A1(p31), .A2(new_n235_), .B(new_n222_), .Y(new_n236_));
  AOI21x1_ASAP7_75t_R g193(.A1(new_n139_), .A2(new_n232_), .B(new_n236_), .Y(new_n237_));
  OAI21x1_ASAP7_75t_R g194(.A1(new_n216_), .A2(new_n223_), .B(new_n237_), .Y(new_n238_));
  NAND2x1_ASAP7_75t_R g195(.A(p14), .B(new_n157_), .Y(new_n239_));
  OR3x1_ASAP7_75t_R   g196(.A(new_n219_), .B(new_n192_), .C(new_n239_), .Y(new_n240_));
  AO21x1_ASAP7_75t_R  g197(.A1(new_n198_), .A2(new_n240_), .B(new_n145_), .Y(new_n241_));
  NAND2x1_ASAP7_75t_R g198(.A(new_n158_), .B(new_n157_), .Y(new_n242_));
  AO21x1_ASAP7_75t_R  g199(.A1(p24), .A2(o1), .B(new_n242_), .Y(new_n243_));
  OAI21x1_ASAP7_75t_R g200(.A1(new_n216_), .A2(new_n241_), .B(new_n243_), .Y(new_n244_));
  AND2x2_ASAP7_75t_R  g201(.A(new_n73_), .B(new_n79_), .Y(new_n245_));
  AOI21x1_ASAP7_75t_R g202(.A1(p23), .A2(o1), .B(new_n245_), .Y(new_n246_));
  NAND2x1_ASAP7_75t_R g203(.A(new_n246_), .B(new_n222_), .Y(new_n247_));
  NAND2x1_ASAP7_75t_R g204(.A(new_n149_), .B(new_n246_), .Y(new_n248_));
  OAI21x1_ASAP7_75t_R g205(.A1(new_n247_), .A2(new_n216_), .B(new_n248_), .Y(new_n249_));
  NOR3x1_ASAP7_75t_R  g206(.A(new_n238_), .B(new_n244_), .C(new_n249_), .Y(new_n250_));
  INVx1_ASAP7_75t_R   g207(.A(new_n250_), .Y(o4));
  NOR2x1_ASAP7_75t_R  g208(.A(new_n134_), .B(o1), .Y(new_n252_));
  AND3x1_ASAP7_75t_R  g209(.A(new_n217_), .B(new_n122_), .C(new_n167_), .Y(new_n253_));
  AOI21x1_ASAP7_75t_R g210(.A1(new_n233_), .A2(new_n253_), .B(new_n71_), .Y(new_n254_));
  NAND2x1_ASAP7_75t_R g211(.A(new_n197_), .B(new_n254_), .Y(new_n255_));
  OAI21x1_ASAP7_75t_R g212(.A1(new_n252_), .A2(new_n255_), .B(new_n222_), .Y(new_n256_));
  OA21x2_ASAP7_75t_R  g213(.A1(p27), .A2(new_n254_), .B(new_n210_), .Y(new_n257_));
  OAI21x1_ASAP7_75t_R g214(.A1(new_n216_), .A2(new_n256_), .B(new_n257_), .Y(new_n258_));
  OR2x4_ASAP7_75t_R   g215(.A(new_n86_), .B(new_n171_), .Y(new_n259_));
  AOI21x1_ASAP7_75t_R g216(.A1(p19), .A2(o1), .B(new_n259_), .Y(new_n260_));
  AND3x1_ASAP7_75t_R  g217(.A(new_n222_), .B(new_n207_), .C(new_n260_), .Y(new_n261_));
  AO21x1_ASAP7_75t_R  g218(.A1(new_n172_), .A2(new_n205_), .B(new_n183_), .Y(new_n262_));
  AO21x1_ASAP7_75t_R  g219(.A1(new_n139_), .A2(new_n261_), .B(new_n262_), .Y(new_n263_));
  AO21x1_ASAP7_75t_R  g220(.A1(new_n122_), .A2(new_n130_), .B(new_n145_), .Y(new_n264_));
  OAI21x1_ASAP7_75t_R g221(.A1(new_n216_), .A2(new_n264_), .B(new_n215_), .Y(new_n265_));
  NOR3x1_ASAP7_75t_R  g222(.A(new_n258_), .B(new_n263_), .C(new_n265_), .Y(new_n266_));
  NAND2x1_ASAP7_75t_R g223(.A(new_n160_), .B(new_n177_), .Y(new_n267_));
  AO21x1_ASAP7_75t_R  g224(.A1(p25), .A2(o1), .B(new_n267_), .Y(new_n268_));
  AOI21x1_ASAP7_75t_R g225(.A1(p34), .A2(o2), .B(new_n268_), .Y(new_n269_));
  AOI21x1_ASAP7_75t_R g226(.A1(new_n266_), .A2(new_n250_), .B(new_n269_), .Y(o3));
  AND3x1_ASAP7_75t_R  g227(.A(new_n222_), .B(new_n207_), .C(new_n220_), .Y(new_n271_));
  NAND2x1_ASAP7_75t_R g228(.A(new_n215_), .B(new_n210_), .Y(new_n272_));
  NAND3x1_ASAP7_75t_R g229(.A(new_n233_), .B(new_n189_), .C(new_n81_), .Y(new_n273_));
  NOR3x1_ASAP7_75t_R  g230(.A(new_n227_), .B(new_n229_), .C(new_n230_), .Y(new_n274_));
  NAND3x1_ASAP7_75t_R g231(.A(new_n273_), .B(new_n274_), .C(new_n185_), .Y(new_n275_));
  AOI21x1_ASAP7_75t_R g232(.A1(new_n146_), .A2(new_n220_), .B(new_n145_), .Y(new_n276_));
  OAI21x1_ASAP7_75t_R g233(.A1(new_n272_), .A2(new_n275_), .B(new_n276_), .Y(new_n277_));
  AOI21x1_ASAP7_75t_R g234(.A1(new_n139_), .A2(new_n271_), .B(new_n277_), .Y(new_n278_));
  OA21x2_ASAP7_75t_R  g235(.A1(new_n247_), .A2(new_n216_), .B(new_n248_), .Y(new_n279_));
  NAND3x1_ASAP7_75t_R g236(.A(new_n278_), .B(new_n279_), .C(new_n265_), .Y(new_n280_));
  NAND2x1_ASAP7_75t_R g237(.A(new_n263_), .B(new_n278_), .Y(new_n281_));
  NOR2x1_ASAP7_75t_R  g238(.A(new_n249_), .B(new_n244_), .Y(new_n282_));
  NAND3x1_ASAP7_75t_R g239(.A(new_n280_), .B(new_n281_), .C(new_n282_), .Y(o5));
  AOI21x1_ASAP7_75t_R g240(.A1(new_n139_), .A2(new_n187_), .B(new_n164_), .Y(new_n284_));
  AOI21x1_ASAP7_75t_R g241(.A1(new_n149_), .A2(new_n246_), .B(new_n254_), .Y(new_n285_));
  OAI21x1_ASAP7_75t_R g242(.A1(new_n247_), .A2(new_n216_), .B(new_n285_), .Y(new_n286_));
  NOR2x1_ASAP7_75t_R  g243(.A(new_n284_), .B(new_n286_), .Y(new_n287_));
  NOR2x1_ASAP7_75t_R  g244(.A(new_n223_), .B(new_n216_), .Y(new_n288_));
  NAND2x1_ASAP7_75t_R g245(.A(new_n260_), .B(new_n222_), .Y(new_n289_));
  AOI21x1_ASAP7_75t_R g246(.A1(new_n146_), .A2(new_n220_), .B(new_n262_), .Y(new_n290_));
  OAI21x1_ASAP7_75t_R g247(.A1(new_n289_), .A2(new_n216_), .B(new_n290_), .Y(new_n291_));
  NOR2x1_ASAP7_75t_R  g248(.A(new_n288_), .B(new_n291_), .Y(new_n292_));
  NAND2x1_ASAP7_75t_R g249(.A(new_n287_), .B(new_n292_), .Y(new_n293_));
  NOR2x1_ASAP7_75t_R  g250(.A(p31), .B(new_n235_), .Y(new_n294_));
  AO21x1_ASAP7_75t_R  g251(.A1(new_n139_), .A2(new_n271_), .B(new_n294_), .Y(new_n295_));
  AOI21x1_ASAP7_75t_R g252(.A1(new_n279_), .A2(new_n295_), .B(new_n244_), .Y(new_n296_));
  NAND3x1_ASAP7_75t_R g253(.A(new_n293_), .B(new_n280_), .C(new_n296_), .Y(o6));
endmodule


