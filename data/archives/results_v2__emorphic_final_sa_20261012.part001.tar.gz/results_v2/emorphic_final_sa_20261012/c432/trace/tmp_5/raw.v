// Benchmark "/tmp/" written by ABC on Mon Oct 12 14:40:52 2026

module \/tmp/  ( 
    p20, p30, p7, p28, p29, p15, p32, p26, p34, p17, p5, p1, p22, p13, p12,
    p11, p35, p8, p3, p24, p14, p33, p9, p23, p6, p4, p0, p25, p2, p10,
    p18, p31, p19, p21, p27, p16,
    o0, o1, o2, o4, o3, o5, o6  );
  input  p20, p30, p7, p28, p29, p15, p32, p26, p34, p17, p5, p1, p22,
    p13, p12, p11, p35, p8, p3, p24, p14, p33, p9, p23, p6, p4, p0, p25,
    p2, p10, p18, p31, p19, p21, p27, p16;
  output o0, o1, o2, o4, o3, o5, o6;
  wire new_n44_, new_n45_, new_n46_, new_n47_, new_n48_, new_n49_, new_n50_,
    new_n51_, new_n52_, new_n53_, new_n54_, new_n55_, new_n56_, new_n57_,
    new_n58_, new_n59_, new_n60_, new_n61_, new_n62_, new_n63_, new_n64_,
    new_n66_, new_n67_, new_n68_, new_n69_, new_n70_, new_n71_, new_n72_,
    new_n73_, new_n74_, new_n75_, new_n76_, new_n77_, new_n78_, new_n79_,
    new_n80_, new_n81_, new_n82_, new_n83_, new_n84_, new_n85_, new_n86_,
    new_n87_, new_n88_, new_n89_, new_n90_, new_n91_, new_n92_, new_n93_,
    new_n94_, new_n95_, new_n96_, new_n97_, new_n98_, new_n99_, new_n100_,
    new_n101_, new_n102_, new_n103_, new_n104_, new_n105_, new_n106_,
    new_n107_, new_n108_, new_n109_, new_n110_, new_n111_, new_n112_,
    new_n113_, new_n114_, new_n115_, new_n116_, new_n117_, new_n118_,
    new_n119_, new_n120_, new_n121_, new_n122_, new_n123_, new_n124_,
    new_n125_, new_n126_, new_n127_, new_n128_, new_n129_, new_n130_,
    new_n131_, new_n133_, new_n134_, new_n135_, new_n136_, new_n137_,
    new_n138_, new_n139_, new_n140_, new_n141_, new_n142_, new_n143_,
    new_n144_, new_n145_, new_n146_, new_n147_, new_n148_, new_n149_,
    new_n150_, new_n151_, new_n152_, new_n153_, new_n154_, new_n155_,
    new_n156_, new_n157_, new_n158_, new_n159_, new_n160_, new_n161_,
    new_n162_, new_n163_, new_n164_, new_n165_, new_n166_, new_n167_,
    new_n168_, new_n169_, new_n170_, new_n171_, new_n172_, new_n173_,
    new_n174_, new_n175_, new_n176_, new_n177_, new_n178_, new_n179_,
    new_n180_, new_n181_, new_n182_, new_n184_, new_n185_, new_n186_,
    new_n187_, new_n188_, new_n189_, new_n190_, new_n191_, new_n192_,
    new_n193_, new_n194_, new_n195_, new_n196_, new_n197_, new_n198_,
    new_n199_, new_n200_, new_n201_, new_n202_, new_n203_, new_n204_,
    new_n205_, new_n206_, new_n207_, new_n208_, new_n209_, new_n210_,
    new_n211_, new_n212_, new_n213_, new_n214_, new_n215_, new_n216_,
    new_n217_, new_n218_, new_n219_, new_n220_, new_n221_, new_n222_,
    new_n223_, new_n224_, new_n225_, new_n226_, new_n227_, new_n228_,
    new_n229_, new_n230_, new_n231_, new_n232_, new_n233_, new_n234_,
    new_n235_, new_n236_, new_n237_, new_n238_, new_n239_, new_n241_,
    new_n242_, new_n243_, new_n244_, new_n245_, new_n246_, new_n247_,
    new_n248_, new_n249_, new_n250_, new_n251_, new_n252_, new_n253_,
    new_n254_, new_n255_, new_n256_, new_n257_, new_n258_, new_n259_,
    new_n260_, new_n261_, new_n263_, new_n264_, new_n265_, new_n266_,
    new_n267_, new_n268_, new_n269_, new_n270_, new_n271_, new_n272_,
    new_n273_, new_n274_, new_n275_, new_n276_, new_n277_, new_n279_,
    new_n280_, new_n281_, new_n282_, new_n283_, new_n284_, new_n285_;
  INVx1_ASAP7_75t_R   g000(.A(p6), .Y(new_n44_));
  INVx1_ASAP7_75t_R   g001(.A(p11), .Y(new_n45_));
  NAND2x1_ASAP7_75t_R g002(.A(p12), .B(new_n45_), .Y(new_n46_));
  OAI21x1_ASAP7_75t_R g003(.A1(p5), .A2(new_n44_), .B(new_n46_), .Y(new_n47_));
  INVx1_ASAP7_75t_R   g004(.A(p10), .Y(new_n48_));
  INVx1_ASAP7_75t_R   g005(.A(p7), .Y(new_n49_));
  NAND2x1_ASAP7_75t_R g006(.A(p8), .B(new_n49_), .Y(new_n50_));
  OAI21x1_ASAP7_75t_R g007(.A1(p9), .A2(new_n48_), .B(new_n50_), .Y(new_n51_));
  NOR2x1_ASAP7_75t_R  g008(.A(new_n47_), .B(new_n51_), .Y(new_n52_));
  INVx1_ASAP7_75t_R   g009(.A(p35), .Y(new_n53_));
  NAND2x1_ASAP7_75t_R g010(.A(p0), .B(new_n53_), .Y(new_n54_));
  INVx1_ASAP7_75t_R   g011(.A(p1), .Y(new_n55_));
  NAND2x1_ASAP7_75t_R g012(.A(p2), .B(new_n55_), .Y(new_n56_));
  INVx1_ASAP7_75t_R   g013(.A(p3), .Y(new_n57_));
  NAND2x1_ASAP7_75t_R g014(.A(p4), .B(new_n57_), .Y(new_n58_));
  AND3x1_ASAP7_75t_R  g015(.A(new_n54_), .B(new_n56_), .C(new_n58_), .Y(new_n59_));
  INVx1_ASAP7_75t_R   g016(.A(p16), .Y(new_n60_));
  NOR2x1_ASAP7_75t_R  g017(.A(p15), .B(new_n60_), .Y(new_n61_));
  INVx1_ASAP7_75t_R   g018(.A(p14), .Y(new_n62_));
  NOR2x1_ASAP7_75t_R  g019(.A(p13), .B(new_n62_), .Y(new_n63_));
  NOR2x1_ASAP7_75t_R  g020(.A(new_n61_), .B(new_n63_), .Y(new_n64_));
  NAND3x1_ASAP7_75t_R g021(.A(new_n52_), .B(new_n59_), .C(new_n64_), .Y(o0));
  NOR2x1_ASAP7_75t_R  g022(.A(p5), .B(new_n44_), .Y(new_n66_));
  INVx1_ASAP7_75t_R   g023(.A(new_n66_), .Y(new_n67_));
  INVx1_ASAP7_75t_R   g024(.A(p15), .Y(new_n68_));
  NAND2x1_ASAP7_75t_R g025(.A(p16), .B(new_n68_), .Y(new_n69_));
  INVx1_ASAP7_75t_R   g026(.A(p13), .Y(new_n70_));
  NAND2x1_ASAP7_75t_R g027(.A(p14), .B(new_n70_), .Y(new_n71_));
  AND3x1_ASAP7_75t_R  g028(.A(new_n69_), .B(new_n71_), .C(p6), .Y(new_n72_));
  NAND3x1_ASAP7_75t_R g029(.A(new_n52_), .B(new_n72_), .C(new_n59_), .Y(new_n73_));
  AOI21x1_ASAP7_75t_R g030(.A1(new_n67_), .A2(new_n73_), .B(p20), .Y(new_n74_));
  INVx1_ASAP7_75t_R   g031(.A(p18), .Y(new_n75_));
  NAND2x1_ASAP7_75t_R g032(.A(p2), .B(new_n75_), .Y(new_n76_));
  AOI21x1_ASAP7_75t_R g033(.A1(p1), .A2(o0), .B(new_n76_), .Y(new_n77_));
  INVx1_ASAP7_75t_R   g034(.A(p12), .Y(new_n78_));
  OR2x4_ASAP7_75t_R   g035(.A(p23), .B(new_n78_), .Y(new_n79_));
  AOI21x1_ASAP7_75t_R g036(.A1(new_n46_), .A2(o0), .B(new_n79_), .Y(new_n80_));
  NOR3x1_ASAP7_75t_R  g037(.A(new_n74_), .B(new_n77_), .C(new_n80_), .Y(new_n81_));
  NOR2x1_ASAP7_75t_R  g038(.A(p9), .B(new_n48_), .Y(new_n82_));
  INVx1_ASAP7_75t_R   g039(.A(new_n82_), .Y(new_n83_));
  INVx1_ASAP7_75t_R   g040(.A(p2), .Y(new_n84_));
  OAI21x1_ASAP7_75t_R g041(.A1(p1), .A2(new_n84_), .B(new_n58_), .Y(new_n85_));
  NAND2x1_ASAP7_75t_R g042(.A(new_n54_), .B(new_n69_), .Y(new_n86_));
  NOR2x1_ASAP7_75t_R  g043(.A(new_n85_), .B(new_n86_), .Y(new_n87_));
  NOR2x1_ASAP7_75t_R  g044(.A(new_n48_), .B(new_n63_), .Y(new_n88_));
  NAND3x1_ASAP7_75t_R g045(.A(new_n52_), .B(new_n87_), .C(new_n88_), .Y(new_n89_));
  AOI21x1_ASAP7_75t_R g046(.A1(new_n83_), .A2(new_n89_), .B(p22), .Y(new_n90_));
  NAND2x1_ASAP7_75t_R g047(.A(new_n59_), .B(new_n52_), .Y(new_n91_));
  INVx1_ASAP7_75t_R   g048(.A(p25), .Y(new_n92_));
  AO21x1_ASAP7_75t_R  g049(.A1(p16), .A2(new_n71_), .B(new_n61_), .Y(new_n93_));
  NAND2x1_ASAP7_75t_R g050(.A(new_n92_), .B(new_n93_), .Y(new_n94_));
  AOI21x1_ASAP7_75t_R g051(.A1(new_n69_), .A2(new_n91_), .B(new_n94_), .Y(new_n95_));
  INVx1_ASAP7_75t_R   g052(.A(p24), .Y(new_n96_));
  NAND2x1_ASAP7_75t_R g053(.A(p14), .B(new_n96_), .Y(new_n97_));
  AOI21x1_ASAP7_75t_R g054(.A1(new_n52_), .A2(new_n87_), .B(new_n63_), .Y(new_n98_));
  NOR2x1_ASAP7_75t_R  g055(.A(new_n97_), .B(new_n98_), .Y(new_n99_));
  NOR3x1_ASAP7_75t_R  g056(.A(new_n90_), .B(new_n95_), .C(new_n99_), .Y(new_n100_));
  INVx1_ASAP7_75t_R   g057(.A(p8), .Y(new_n101_));
  NOR2x1_ASAP7_75t_R  g058(.A(new_n101_), .B(new_n63_), .Y(new_n102_));
  INVx1_ASAP7_75t_R   g059(.A(new_n102_), .Y(new_n103_));
  NAND2x1_ASAP7_75t_R g060(.A(new_n52_), .B(new_n87_), .Y(new_n104_));
  OAI21x1_ASAP7_75t_R g061(.A1(new_n103_), .A2(new_n104_), .B(new_n50_), .Y(new_n105_));
  AOI21x1_ASAP7_75t_R g062(.A1(p12), .A2(new_n45_), .B(new_n66_), .Y(new_n106_));
  NOR2x1_ASAP7_75t_R  g063(.A(p7), .B(new_n101_), .Y(new_n107_));
  NOR2x1_ASAP7_75t_R  g064(.A(new_n107_), .B(new_n82_), .Y(new_n108_));
  NAND3x1_ASAP7_75t_R g065(.A(new_n64_), .B(new_n106_), .C(new_n108_), .Y(new_n109_));
  INVx1_ASAP7_75t_R   g066(.A(new_n54_), .Y(new_n110_));
  OR3x1_ASAP7_75t_R   g067(.A(new_n85_), .B(p7), .C(new_n110_), .Y(new_n111_));
  INVx1_ASAP7_75t_R   g068(.A(p21), .Y(new_n112_));
  OAI21x1_ASAP7_75t_R g069(.A1(new_n109_), .A2(new_n111_), .B(new_n112_), .Y(new_n113_));
  INVx1_ASAP7_75t_R   g070(.A(new_n113_), .Y(new_n114_));
  INVx1_ASAP7_75t_R   g071(.A(p4), .Y(new_n115_));
  NOR2x1_ASAP7_75t_R  g072(.A(p19), .B(new_n115_), .Y(new_n116_));
  INVx1_ASAP7_75t_R   g073(.A(new_n116_), .Y(new_n117_));
  NAND2x1_ASAP7_75t_R g074(.A(new_n54_), .B(new_n56_), .Y(new_n118_));
  NAND2x1_ASAP7_75t_R g075(.A(new_n69_), .B(new_n71_), .Y(new_n119_));
  NOR2x1_ASAP7_75t_R  g076(.A(new_n118_), .B(new_n119_), .Y(new_n120_));
  NOR2x1_ASAP7_75t_R  g077(.A(p3), .B(new_n115_), .Y(new_n121_));
  AOI21x1_ASAP7_75t_R g078(.A1(new_n52_), .A2(new_n120_), .B(new_n121_), .Y(new_n122_));
  NOR3x1_ASAP7_75t_R  g079(.A(new_n119_), .B(new_n47_), .C(new_n51_), .Y(new_n123_));
  NOR2x1_ASAP7_75t_R  g080(.A(p1), .B(new_n84_), .Y(new_n124_));
  NOR2x1_ASAP7_75t_R  g081(.A(new_n124_), .B(new_n121_), .Y(new_n125_));
  INVx1_ASAP7_75t_R   g082(.A(p17), .Y(new_n126_));
  AND2x2_ASAP7_75t_R  g083(.A(p0), .B(new_n126_), .Y(new_n127_));
  OA21x2_ASAP7_75t_R  g084(.A1(new_n110_), .A2(new_n125_), .B(new_n127_), .Y(new_n128_));
  OAI21x1_ASAP7_75t_R g085(.A1(new_n110_), .A2(new_n123_), .B(new_n128_), .Y(new_n129_));
  OAI21x1_ASAP7_75t_R g086(.A1(new_n117_), .A2(new_n122_), .B(new_n129_), .Y(new_n130_));
  AOI21x1_ASAP7_75t_R g087(.A1(new_n105_), .A2(new_n114_), .B(new_n130_), .Y(new_n131_));
  NAND3x1_ASAP7_75t_R g088(.A(new_n81_), .B(new_n100_), .C(new_n131_), .Y(o1));
  AOI21x1_ASAP7_75t_R g089(.A1(new_n131_), .A2(new_n100_), .B(new_n126_), .Y(new_n133_));
  AND3x1_ASAP7_75t_R  g090(.A(new_n52_), .B(new_n125_), .C(new_n64_), .Y(new_n134_));
  AOI21x1_ASAP7_75t_R g091(.A1(p0), .A2(new_n134_), .B(new_n110_), .Y(new_n135_));
  NOR2x1_ASAP7_75t_R  g092(.A(p26), .B(new_n135_), .Y(new_n136_));
  OAI21x1_ASAP7_75t_R g093(.A1(new_n126_), .A2(new_n81_), .B(new_n136_), .Y(new_n137_));
  NOR2x1_ASAP7_75t_R  g094(.A(new_n133_), .B(new_n137_), .Y(new_n138_));
  NOR2x1_ASAP7_75t_R  g095(.A(new_n77_), .B(new_n80_), .Y(new_n139_));
  NAND3x1_ASAP7_75t_R g096(.A(new_n100_), .B(new_n131_), .C(new_n139_), .Y(new_n140_));
  AND2x2_ASAP7_75t_R  g097(.A(new_n67_), .B(new_n73_), .Y(new_n141_));
  NOR2x1_ASAP7_75t_R  g098(.A(p29), .B(new_n141_), .Y(new_n142_));
  INVx1_ASAP7_75t_R   g099(.A(new_n142_), .Y(new_n143_));
  AOI21x1_ASAP7_75t_R g100(.A1(p20), .A2(new_n140_), .B(new_n143_), .Y(new_n144_));
  NOR2x1_ASAP7_75t_R  g101(.A(new_n138_), .B(new_n144_), .Y(new_n145_));
  OA21x2_ASAP7_75t_R  g102(.A1(new_n103_), .A2(new_n104_), .B(new_n50_), .Y(new_n146_));
  OR2x4_ASAP7_75t_R   g103(.A(p30), .B(new_n146_), .Y(new_n147_));
  AOI21x1_ASAP7_75t_R g104(.A1(p21), .A2(o1), .B(new_n147_), .Y(new_n148_));
  INVx1_ASAP7_75t_R   g105(.A(p27), .Y(new_n149_));
  AOI21x1_ASAP7_75t_R g106(.A1(p1), .A2(o0), .B(new_n84_), .Y(new_n150_));
  NOR2x1_ASAP7_75t_R  g107(.A(p28), .B(new_n115_), .Y(new_n151_));
  INVx1_ASAP7_75t_R   g108(.A(new_n151_), .Y(new_n152_));
  NOR2x1_ASAP7_75t_R  g109(.A(new_n152_), .B(new_n122_), .Y(new_n153_));
  AOI21x1_ASAP7_75t_R g110(.A1(new_n149_), .A2(new_n150_), .B(new_n153_), .Y(new_n154_));
  INVx1_ASAP7_75t_R   g111(.A(p31), .Y(new_n155_));
  NAND2x1_ASAP7_75t_R g112(.A(new_n83_), .B(new_n89_), .Y(new_n156_));
  NOR3x1_ASAP7_75t_R  g113(.A(new_n98_), .B(new_n62_), .C(p33), .Y(new_n157_));
  AOI21x1_ASAP7_75t_R g114(.A1(new_n155_), .A2(new_n156_), .B(new_n157_), .Y(new_n158_));
  NOR2x1_ASAP7_75t_R  g115(.A(p32), .B(new_n78_), .Y(new_n159_));
  NAND2x1_ASAP7_75t_R g116(.A(new_n46_), .B(o0), .Y(new_n160_));
  AND3x1_ASAP7_75t_R  g117(.A(new_n59_), .B(new_n106_), .C(new_n108_), .Y(new_n161_));
  INVx1_ASAP7_75t_R   g118(.A(p34), .Y(new_n162_));
  AND2x2_ASAP7_75t_R  g119(.A(new_n162_), .B(new_n93_), .Y(new_n163_));
  OA21x2_ASAP7_75t_R  g120(.A1(new_n61_), .A2(new_n161_), .B(new_n163_), .Y(new_n164_));
  AOI21x1_ASAP7_75t_R g121(.A1(new_n159_), .A2(new_n160_), .B(new_n164_), .Y(new_n165_));
  AND3x1_ASAP7_75t_R  g122(.A(new_n154_), .B(new_n158_), .C(new_n165_), .Y(new_n166_));
  NOR3x1_ASAP7_75t_R  g123(.A(new_n98_), .B(p33), .C(new_n97_), .Y(new_n167_));
  AO21x1_ASAP7_75t_R  g124(.A1(new_n92_), .A2(new_n164_), .B(new_n167_), .Y(new_n168_));
  AO21x1_ASAP7_75t_R  g125(.A1(new_n46_), .A2(o0), .B(new_n79_), .Y(new_n169_));
  AND3x1_ASAP7_75t_R  g126(.A(new_n52_), .B(new_n59_), .C(new_n64_), .Y(new_n170_));
  AND3x1_ASAP7_75t_R  g127(.A(new_n75_), .B(new_n149_), .C(p2), .Y(new_n171_));
  OAI21x1_ASAP7_75t_R g128(.A1(new_n124_), .A2(new_n170_), .B(new_n171_), .Y(new_n172_));
  OAI21x1_ASAP7_75t_R g129(.A1(p32), .A2(new_n169_), .B(new_n172_), .Y(new_n173_));
  INVx1_ASAP7_75t_R   g130(.A(p9), .Y(new_n174_));
  INVx1_ASAP7_75t_R   g131(.A(p22), .Y(new_n175_));
  AND3x1_ASAP7_75t_R  g132(.A(new_n175_), .B(new_n155_), .C(p10), .Y(new_n176_));
  OAI21x1_ASAP7_75t_R g133(.A1(new_n174_), .A2(new_n170_), .B(new_n176_), .Y(new_n177_));
  OR3x1_ASAP7_75t_R   g134(.A(new_n122_), .B(p19), .C(new_n152_), .Y(new_n178_));
  NAND2x1_ASAP7_75t_R g135(.A(new_n177_), .B(new_n178_), .Y(new_n179_));
  NOR3x1_ASAP7_75t_R  g136(.A(new_n168_), .B(new_n173_), .C(new_n179_), .Y(new_n180_));
  OAI21x1_ASAP7_75t_R g137(.A1(new_n166_), .A2(o1), .B(new_n180_), .Y(new_n181_));
  NOR2x1_ASAP7_75t_R  g138(.A(new_n148_), .B(new_n181_), .Y(new_n182_));
  NAND2x1_ASAP7_75t_R g139(.A(new_n145_), .B(new_n182_), .Y(o2));
  NAND3x1_ASAP7_75t_R g140(.A(new_n154_), .B(new_n158_), .C(new_n165_), .Y(new_n184_));
  AND3x1_ASAP7_75t_R  g141(.A(new_n81_), .B(new_n100_), .C(new_n131_), .Y(new_n185_));
  INVx1_ASAP7_75t_R   g142(.A(p32), .Y(new_n186_));
  OA21x2_ASAP7_75t_R  g143(.A1(new_n124_), .A2(new_n170_), .B(new_n171_), .Y(new_n187_));
  AOI21x1_ASAP7_75t_R g144(.A1(new_n186_), .A2(new_n80_), .B(new_n187_), .Y(new_n188_));
  AO21x1_ASAP7_75t_R  g145(.A1(new_n52_), .A2(new_n120_), .B(new_n121_), .Y(new_n189_));
  INVx1_ASAP7_75t_R   g146(.A(p19), .Y(new_n190_));
  AND3x1_ASAP7_75t_R  g147(.A(new_n189_), .B(new_n190_), .C(new_n151_), .Y(new_n191_));
  OA21x2_ASAP7_75t_R  g148(.A1(new_n174_), .A2(new_n170_), .B(new_n176_), .Y(new_n192_));
  NOR2x1_ASAP7_75t_R  g149(.A(new_n191_), .B(new_n192_), .Y(new_n193_));
  AOI21x1_ASAP7_75t_R g150(.A1(new_n92_), .A2(new_n164_), .B(new_n167_), .Y(new_n194_));
  NAND3x1_ASAP7_75t_R g151(.A(new_n188_), .B(new_n193_), .C(new_n194_), .Y(new_n195_));
  AOI21x1_ASAP7_75t_R g152(.A1(new_n184_), .A2(new_n185_), .B(new_n195_), .Y(new_n196_));
  OAI21x1_ASAP7_75t_R g153(.A1(new_n110_), .A2(new_n125_), .B(new_n127_), .Y(new_n197_));
  AOI21x1_ASAP7_75t_R g154(.A1(new_n54_), .A2(new_n109_), .B(new_n197_), .Y(new_n198_));
  AOI21x1_ASAP7_75t_R g155(.A1(new_n116_), .A2(new_n189_), .B(new_n198_), .Y(new_n199_));
  OAI21x1_ASAP7_75t_R g156(.A1(new_n113_), .A2(new_n146_), .B(new_n199_), .Y(new_n200_));
  AND3x1_ASAP7_75t_R  g157(.A(new_n52_), .B(new_n87_), .C(new_n88_), .Y(new_n201_));
  OAI21x1_ASAP7_75t_R g158(.A1(new_n82_), .A2(new_n201_), .B(new_n175_), .Y(new_n202_));
  AO21x1_ASAP7_75t_R  g159(.A1(new_n69_), .A2(new_n91_), .B(new_n94_), .Y(new_n203_));
  AO21x1_ASAP7_75t_R  g160(.A1(new_n71_), .A2(new_n104_), .B(new_n97_), .Y(new_n204_));
  NAND3x1_ASAP7_75t_R g161(.A(new_n202_), .B(new_n203_), .C(new_n204_), .Y(new_n205_));
  NOR2x1_ASAP7_75t_R  g162(.A(new_n200_), .B(new_n205_), .Y(new_n206_));
  OR3x1_ASAP7_75t_R   g163(.A(new_n74_), .B(new_n77_), .C(new_n80_), .Y(new_n207_));
  NAND2x1_ASAP7_75t_R g164(.A(p0), .B(new_n134_), .Y(new_n208_));
  AO21x1_ASAP7_75t_R  g165(.A1(new_n54_), .A2(new_n208_), .B(p26), .Y(new_n209_));
  AOI21x1_ASAP7_75t_R g166(.A1(p17), .A2(new_n207_), .B(new_n209_), .Y(new_n210_));
  OAI21x1_ASAP7_75t_R g167(.A1(new_n126_), .A2(new_n206_), .B(new_n210_), .Y(new_n211_));
  OAI21x1_ASAP7_75t_R g168(.A1(new_n200_), .A2(new_n205_), .B(p20), .Y(new_n212_));
  AO21x1_ASAP7_75t_R  g169(.A1(p1), .A2(o0), .B(new_n76_), .Y(new_n213_));
  NAND2x1_ASAP7_75t_R g170(.A(new_n213_), .B(new_n169_), .Y(new_n214_));
  NAND2x1_ASAP7_75t_R g171(.A(p20), .B(new_n214_), .Y(new_n215_));
  NAND3x1_ASAP7_75t_R g172(.A(new_n212_), .B(new_n142_), .C(new_n215_), .Y(new_n216_));
  NAND3x1_ASAP7_75t_R g173(.A(new_n196_), .B(new_n211_), .C(new_n216_), .Y(new_n217_));
  INVx1_ASAP7_75t_R   g174(.A(new_n156_), .Y(new_n218_));
  AOI21x1_ASAP7_75t_R g175(.A1(p22), .A2(o1), .B(new_n218_), .Y(new_n219_));
  AO21x1_ASAP7_75t_R  g176(.A1(p21), .A2(o1), .B(new_n147_), .Y(new_n220_));
  NAND2x1_ASAP7_75t_R g177(.A(new_n219_), .B(new_n220_), .Y(new_n221_));
  AOI21x1_ASAP7_75t_R g178(.A1(p21), .A2(o1), .B(new_n146_), .Y(new_n222_));
  NOR3x1_ASAP7_75t_R  g179(.A(new_n181_), .B(new_n144_), .C(new_n138_), .Y(new_n223_));
  OAI21x1_ASAP7_75t_R g180(.A1(new_n175_), .A2(new_n185_), .B(new_n156_), .Y(new_n224_));
  OAI21x1_ASAP7_75t_R g181(.A1(p31), .A2(new_n224_), .B(new_n220_), .Y(new_n225_));
  AOI21x1_ASAP7_75t_R g182(.A1(new_n222_), .A2(new_n223_), .B(new_n225_), .Y(new_n226_));
  OAI21x1_ASAP7_75t_R g183(.A1(new_n217_), .A2(new_n221_), .B(new_n226_), .Y(new_n227_));
  NOR2x1_ASAP7_75t_R  g184(.A(new_n96_), .B(new_n185_), .Y(new_n228_));
  OR3x1_ASAP7_75t_R   g185(.A(new_n228_), .B(new_n62_), .C(new_n98_), .Y(new_n229_));
  INVx1_ASAP7_75t_R   g186(.A(p33), .Y(new_n230_));
  AOI21x1_ASAP7_75t_R g187(.A1(new_n145_), .A2(new_n182_), .B(new_n230_), .Y(new_n231_));
  OR3x1_ASAP7_75t_R   g188(.A(new_n104_), .B(new_n78_), .C(new_n63_), .Y(new_n232_));
  AND2x2_ASAP7_75t_R  g189(.A(new_n46_), .B(new_n232_), .Y(new_n233_));
  OA21x2_ASAP7_75t_R  g190(.A1(new_n233_), .A2(o1), .B(new_n169_), .Y(new_n234_));
  NOR2x1_ASAP7_75t_R  g191(.A(new_n148_), .B(new_n234_), .Y(new_n235_));
  NOR2x1_ASAP7_75t_R  g192(.A(p32), .B(new_n234_), .Y(new_n236_));
  AOI21x1_ASAP7_75t_R g193(.A1(new_n223_), .A2(new_n235_), .B(new_n236_), .Y(new_n237_));
  OAI21x1_ASAP7_75t_R g194(.A1(new_n229_), .A2(new_n231_), .B(new_n237_), .Y(new_n238_));
  NOR2x1_ASAP7_75t_R  g195(.A(new_n227_), .B(new_n238_), .Y(new_n239_));
  INVx1_ASAP7_75t_R   g196(.A(new_n239_), .Y(o4));
  NOR2x1_ASAP7_75t_R  g197(.A(new_n135_), .B(o1), .Y(new_n241_));
  AO21x1_ASAP7_75t_R  g198(.A1(new_n67_), .A2(new_n73_), .B(p20), .Y(new_n242_));
  AND3x1_ASAP7_75t_R  g199(.A(new_n139_), .B(new_n242_), .C(new_n150_), .Y(new_n243_));
  NAND2x1_ASAP7_75t_R g200(.A(new_n243_), .B(new_n206_), .Y(new_n244_));
  NAND3x1_ASAP7_75t_R g201(.A(new_n244_), .B(new_n129_), .C(new_n213_), .Y(new_n245_));
  OAI21x1_ASAP7_75t_R g202(.A1(new_n241_), .A2(new_n245_), .B(new_n220_), .Y(new_n246_));
  OAI21x1_ASAP7_75t_R g203(.A1(p27), .A2(new_n244_), .B(new_n172_), .Y(new_n247_));
  NOR2x1_ASAP7_75t_R  g204(.A(new_n138_), .B(new_n247_), .Y(new_n248_));
  OAI21x1_ASAP7_75t_R g205(.A1(new_n217_), .A2(new_n246_), .B(new_n248_), .Y(new_n249_));
  NAND2x1_ASAP7_75t_R g206(.A(p4), .B(new_n189_), .Y(new_n250_));
  AO21x1_ASAP7_75t_R  g207(.A1(p19), .A2(o1), .B(new_n250_), .Y(new_n251_));
  NOR3x1_ASAP7_75t_R  g208(.A(new_n217_), .B(new_n148_), .C(new_n251_), .Y(new_n252_));
  AO21x1_ASAP7_75t_R  g209(.A1(p20), .A2(new_n140_), .B(new_n141_), .Y(new_n253_));
  NOR2x1_ASAP7_75t_R  g210(.A(new_n148_), .B(new_n253_), .Y(new_n254_));
  OAI21x1_ASAP7_75t_R g211(.A1(new_n190_), .A2(new_n185_), .B(new_n153_), .Y(new_n255_));
  NAND2x1_ASAP7_75t_R g212(.A(new_n216_), .B(new_n255_), .Y(new_n256_));
  AO21x1_ASAP7_75t_R  g213(.A1(new_n254_), .A2(new_n223_), .B(new_n256_), .Y(new_n257_));
  NOR3x1_ASAP7_75t_R  g214(.A(new_n249_), .B(new_n252_), .C(new_n257_), .Y(new_n258_));
  OAI21x1_ASAP7_75t_R g215(.A1(new_n61_), .A2(new_n161_), .B(new_n93_), .Y(new_n259_));
  AO21x1_ASAP7_75t_R  g216(.A1(p25), .A2(o1), .B(new_n259_), .Y(new_n260_));
  AOI21x1_ASAP7_75t_R g217(.A1(p34), .A2(o2), .B(new_n260_), .Y(new_n261_));
  AOI21x1_ASAP7_75t_R g218(.A1(new_n258_), .A2(new_n239_), .B(new_n261_), .Y(o3));
  AO21x1_ASAP7_75t_R  g219(.A1(p28), .A2(new_n148_), .B(new_n251_), .Y(new_n263_));
  AO21x1_ASAP7_75t_R  g220(.A1(new_n217_), .A2(new_n255_), .B(new_n263_), .Y(new_n264_));
  NOR2x1_ASAP7_75t_R  g221(.A(new_n221_), .B(new_n217_), .Y(new_n265_));
  NAND2x1_ASAP7_75t_R g222(.A(new_n211_), .B(new_n216_), .Y(new_n266_));
  NAND2x1_ASAP7_75t_R g223(.A(new_n222_), .B(new_n196_), .Y(new_n267_));
  AOI21x1_ASAP7_75t_R g224(.A1(new_n155_), .A2(new_n219_), .B(new_n148_), .Y(new_n268_));
  OAI21x1_ASAP7_75t_R g225(.A1(new_n266_), .A2(new_n267_), .B(new_n268_), .Y(new_n269_));
  NOR2x1_ASAP7_75t_R  g226(.A(new_n265_), .B(new_n269_), .Y(new_n270_));
  AOI21x1_ASAP7_75t_R g227(.A1(new_n254_), .A2(new_n223_), .B(new_n144_), .Y(new_n271_));
  OAI21x1_ASAP7_75t_R g228(.A1(new_n233_), .A2(o1), .B(new_n169_), .Y(new_n272_));
  NAND2x1_ASAP7_75t_R g229(.A(new_n272_), .B(new_n220_), .Y(new_n273_));
  NAND2x1_ASAP7_75t_R g230(.A(new_n186_), .B(new_n272_), .Y(new_n274_));
  OAI21x1_ASAP7_75t_R g231(.A1(new_n273_), .A2(new_n217_), .B(new_n274_), .Y(new_n275_));
  NOR2x1_ASAP7_75t_R  g232(.A(new_n271_), .B(new_n275_), .Y(new_n276_));
  AOI21x1_ASAP7_75t_R g233(.A1(new_n270_), .A2(new_n276_), .B(new_n238_), .Y(new_n277_));
  OAI21x1_ASAP7_75t_R g234(.A1(new_n227_), .A2(new_n264_), .B(new_n277_), .Y(o5));
  AND2x2_ASAP7_75t_R  g235(.A(new_n213_), .B(new_n244_), .Y(new_n279_));
  AOI21x1_ASAP7_75t_R g236(.A1(p27), .A2(o2), .B(new_n279_), .Y(new_n280_));
  NAND2x1_ASAP7_75t_R g237(.A(new_n155_), .B(new_n219_), .Y(new_n281_));
  OAI21x1_ASAP7_75t_R g238(.A1(new_n221_), .A2(new_n217_), .B(new_n281_), .Y(new_n282_));
  AOI21x1_ASAP7_75t_R g239(.A1(new_n264_), .A2(new_n280_), .B(new_n282_), .Y(new_n283_));
  NOR2x1_ASAP7_75t_R  g240(.A(new_n229_), .B(new_n231_), .Y(new_n284_));
  AOI21x1_ASAP7_75t_R g241(.A1(new_n270_), .A2(new_n276_), .B(new_n284_), .Y(new_n285_));
  OAI21x1_ASAP7_75t_R g242(.A1(new_n275_), .A2(new_n283_), .B(new_n285_), .Y(o6));
endmodule


