# 跨结构功能 cuts 与安全源选择，2026-10-19

本轮实现和实验均在隔离版本中完成，主源码、默认配置和 native 8f6 未变，baseline 原算法、模型和参数未改。V31 有可重复的 sqrt 延迟及面积收益，但仍有全套回退；V32 源选择并未解决导入超限。两版本独立，不按设计拼接结果，不合入主版本。

## V31：已有信号的全 care 功能分解

对已有精确 cut F(S)，从已计入全局节点的类中找 G(T)，T 是 S 的真子集，尝试 F(S)=Q(S\T,G(T))。枚举 S 的全部赋值，要求每个新边界赋值上的 F 唯一且全覆盖，才接受 Q。不存在采样证明、任意 don't-care 补全或条件 union；新过程不增加 e-nodes。

每个 support 最多4个已有伙伴，每根、每个原 cut round 最多32个分解尝试；仍在原32rounds/每类16cutbank内竞争。原 mandatory witnesses 不变，旧 optional cuts 可以被挤出；物理候选池也会变化。两个对照都启用 V29 terminal-area1，仅 functional_cuts0/1 不同；所有其他旗标固定。终态 guard 只保护本次运行已取得的完整旧 cover，不保证另一个候选池或另一次限时运行的结果。

源码、默认关闭旗标、RED/GREEN、130项 egraph 相关回归/5ignored、release、完整Cargo/fixtures和补丁见 `functional_cuts_implementation_20261019`。最小 RED 确认紧凑三输入根无法利用已存在的共享 g=b&c，新过程给出 (a,g)；全三输入 F/G 的3584种组合独立检查可分解性和重构，另4096个四输入样本及实际共享输出物理真值回归。初始类型/fixture/测试触发配置失败日志全部保留，未作为实际EPFL数据。

## 完整 EPFL 与预先固定的重复

两库、20设计、两profile共80项完整尝试，68公共 named-port CEC 成功，12次为三个大设计实际导入失败。24个试验记录与完整矩阵具有相同完整依赖指纹，全部显式采用且只计一次，其余56项新执行。

34有效配对：延迟7改善/25相同/2回退，面积15改善/7相同/12回退。AD只有事后比较，并非新增AD配置。完整逐项结果、失败原因、命令与预算证书见 `functional_cuts_full_20261019/functional_validation.json`。

| 库/设计 | 对照面积 | 新面积 | 对照延迟 | 新延迟 |
|---|---:|---:|---:|---:|
| K3 sqrt | 2153.90 | 2021.89 | 60087.26 | 55862.56 |
| K4 sqrt | 2251.18 | 2215.87 | 47047.28 | 47031.68 |
| K4 sin | 580.11 | 567.46 | 1793.92 | 1806.55 |
| K4 adder | 90.31 | 95.34 | 2569.79 | 2571.81 |
| K4 cavlc | 40.98 | 40.67 | 186.01 | 185.87 |

未按设计挑赢家。router/voter 等还有延迟与面积取舍，所有12项面积回退均留在完整数据中。特别是四输入sin的面积下降不能称为(D,A)改进。

固定 sqrt/bar/sin、两库、两profile，正/反/正三轮共36fresh尝试，全部公共CEC。18有效配对：D6改善/9相同/3回退，A12改善/6相同/0回退。这是目标设计重复，不是全20设计的三次重跑，也不是统计稳定性证明。sqrt两库各3/3同时改善；sin四输入延迟回退同样3/3出现，不能靠选最好重复消去。

- K3 sqrt 三轮对照面积：2153.37, 2153.55, 2153.82；新面积：2021.89, 2021.89, 2021.89；对照D 60087.26，新D 55862.56（三轮一致）。
- K4 sqrt 三轮对照面积：2250.29, 2251.14, 2250.80；新面积：2215.16, 2215.86, 2215.98；对照D 47047.28，新D 47031.68（三轮一致）。

与固定原版 emap **delay模式**比较（不按设计选模式）：

| 库 | 新延迟/emap变化 | 新面积/emap变化 |
|---|---:|---:|
| K3 sqrt | -7.0309% | +22.92% |
| K4 sqrt | -0.0332% | +41.82% |

因此，sqrt已有同库延迟优势，面积差距仍明显；不能改称Pareto支配。两库DA/AD事后/Pareto共六个全范围gate全部false，MtM未接入。主表保持原8f6参考配置，不能把V31按设计混入主表。

## 选中覆盖与关键路径的只读诊断

公共f32 pin→f64路径和全部物理实例面积与独立evaluator一致。下表的“新边界绑定”指该已选目标只匹配新最终bank中的精确cut，不是新物理单元数；更不证明它在旧未导出physical pool中绝不存在（旧SDC等仍可能授权）。这不是额外映射或CEC，也不向mapper回灌离线建议。

| 库/设计 | 新最终cuts | 被挤出旧cuts | 只匹配新cut的选中目标绑定 | 两覆盖关键路径单元数 |
|---|---:|---:|---:|---|
| K3 sqrt | 34754 | 0 | 2332 | 2951 → 2052 |
| K3 bar | 55 | 15 | 0 | 9 → 9 |
| K3 sin | 23312 | 11759 | 73 | 87 → 87 |
| K4 sqrt | 109365 | 30984 | 711 | 2077 → 2076 |
| K4 bar | 53 | 35 | 0 | 7 → 7 |
| K4 sin | 26958 | 26500 | 105 | 81 → 78 |

三输入sqrt显著减少所选关键路径单元数；四输入sin虽然更少单元却更慢，说明逻辑层数不能代替真实pin delay。bar没有该类新边界选中绑定。本诊断支持继续研究有用候选和实际时序反馈，但不把关联当作已证明的单一因果，也不声称审计过未选的完整物理pool。

## V32：独立源选择过滤，拒绝采用

从V25源选择版本独立实现，不与V31拼接。两个profile均保留原proof/structural propagation/groups1；仅 EGM_SOURCE_CLOSURE_FILTER0/1 不同。对原本已证明的候选，保守检查其是否仍依赖要释放的共享锥；最多展开256个源节点；第257个新节点只作为超界拒绝标记，seen集合可能含257项。未知即拒绝。没有新增真值查询或隐藏函数，原16次联合group/pair事务额度不变；原单候选扫描不在此计数内且未改。不要将16误称为所有图遍历/所有计算的上限。

最小RED/GREEN显示三消费者首个候选仍依赖旧锥时，后续已有候选可实现联合释放。19source tests和101egraph相关tests/4ignored通过，两组有重叠不相加为不同测试。完整源码/bin/patch在 `source_closure_implementation_20261019`。

16个物理尝试，4次priority公共CEC成功、12次实际导入失败；全部失败的import sidecar均为 incomplete、admitted20000/allowance20000，无合法cover。

| 设计/库 | 原源计划估算 | 新估算 |
|---|---:|---:|
| div K4 | 20366 | 20366 |
| hyp K4 | 99143 | 106344 |
| mem_ctrl K4 | 24860 | 24854 |
| div K3 | 20537 | 20537 |
| hyp K3 | 104047 | 111430 |
| mem_ctrl K3 | 27903 | 27904 |

这些只是源表示计划估算，不是最小下界、实际完整导入节点、CEC/PPA或不可能证明。div未改善；mem_ctrl K4仅减少6、K3反而增加1；hyp明显回退。安全语义与有效优化不是同一回事，因此本源过滤也不合入。

尚未区分的原因包括256展开额度后的未知拒绝，以及“必须释放触发共享节点”这个必要条件过强：有用的联合替换也可能释放别的锥。下一步应先记录拒绝原因，再以严格rank不变量安全终止不可能依赖的分支，避免过度过滤；不能只因group_trials下降就报速度/质量提升。`next_rank_pruning.md`只是新版本计划，未实现、未试验。

## 预算、来源及后续

保留一次resyn2 AIG、两原库、公共unique physical instance area/unloaded dependent-pin block delay及独立original named-port CEC。实际累计导入20000、SAT16、cuts/class16、retainedpool100000、原cut rounds32、原area4rounds/每轮2000应用trial、post-admission recovery2秒（含setup/最终验证/返回预留）、native60/mapping-only300秒均不变。原pre-admission finite/frontier5秒子guard在2秒外、60/300秒内；2秒不等于整个映射。保留池不是raw generation/RAM上限，完整线上评分数不是应用trial数。阶段检查非抢占式，不按区域重置额度，不豁免原输入，不退役egraph状态后清累计账。

两种新因素分开，132个不重复物理尝试、108公共CEC、24实际节点失败；旧24pilot显式采用只计一次。没有rerun或优化baseline。原版baseline240groups/520状态槽(372CEC/124reported failure/24unmeasured)完整保留；四个small binaries重新hash一致，既有13403文件完整审计只引用而非本轮重跑。

下一优化需要在一个候选池和同一恢复deadline内，让新cut替换接受基于真实pin arrivals、完整共享面积/绑定和cycle校验，同时保护完整旧共享cover；不能用旧历史文件免费当incumbent，也不能新开第二个2秒恢复或按设计选版本。sqrt已找到有用结构，优先降低其面积代价；bar新增边界未被用到，sin/adder有稳定回退。源压缩另立新版本验证，现有三个大输入继续失败。没有全面完成或SOTA声明。

完整证书见 qualification.json、functional_validation.json、source_validation.json、selected_cover_analysis.json 和 baseline_scope/；所有native argv、hash、失败、调度顺序及6个raw永久归档保留。PDF为6页正文+1页参考，标准字号边距与五张表的数据保持不变。
