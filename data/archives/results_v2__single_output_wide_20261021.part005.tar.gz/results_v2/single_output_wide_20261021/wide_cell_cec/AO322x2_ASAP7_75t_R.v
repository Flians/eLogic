module mapped(\A1[0] , \A2[0] , \A3[0] , \B1[0] , \B2[0] , \C1[0] , \C2[0] , \result[0] );
  input \A1[0] ;
  input \A2[0] ;
  input \A3[0] ;
  input \B1[0] ;
  input \B2[0] ;
  input \C1[0] ;
  input \C2[0] ;
  output \result[0] ;
  wire __egm_s49;
  AO322x2_ASAP7_75t_R __egm_g381 (.A1(\A2[0] ), .A2(\A1[0] ), .A3(\A3[0] ), .B1(\B2[0] ), .B2(\B1[0] ), .C1(\C2[0] ), .C2(\C1[0] ), .Y(__egm_s49));
  assign \result[0]  = __egm_s49;
endmodule
