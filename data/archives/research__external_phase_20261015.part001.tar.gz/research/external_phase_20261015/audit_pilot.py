"""Independently re-audit all archived usb pilots and pair their cold/warm results."""
import csv,hashlib,json,re,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];P=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'scripts/experiments'))
from audit_mapped_ppa import audit
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
inputs=ROOT/'results_v20_three_parts_chain/inputs'
initial=ROOT/'results_v25_three_parts_progressive_phase/cold/tab_main/ae.usb_phy/epmapping_baseline.v'
previous=ROOT/'results_v25_three_parts_progressive_phase/cold/tab_main/ae.usb_phy/epmapping_mapped.v'
runs=json.loads((P/'pilot_results.json').read_text());assert len(runs)==34,len(runs)
idx={(r['arm'],r['mode']):r for r in runs};assert len(idx)==34
proof=[];flat=[]
for r in runs:
 wd=P/'runs'/f"{r['arm']}_{r['mode']}";m=json.loads((wd/'manifest.json').read_text());text=(wd/'log').read_text();e=m['env']
 assert 'cec=1' in text and 'window_synth windows=0 applied=0' in text and 'post_mapping_timeout=1000' in text
 assert e['EPMAPPING_WINDOW_SYN']=='0' and e['EPMAPPING_POST_TIMEOUT']=='1000' and e['EPMAPPING_DSE']=='0'
 assert e['EPMAPPING_OBJECTIVE']=='area_delay_bound' and e['EPMAPPING_BASELINE']=='high_effort'
 assert sha(wd/'epmapping_check')==m['binary_sha256']==r['binary_sha256']
 assert sha(wd/'epmapping_mapped.v')==r['netlist_sha256']
 for p,h in m['input_sha256'].items():assert sha(inputs/p)==h,(wd,p)
 assert (wd/'epmapping_baseline.v').read_bytes()==initial.read_bytes()
 b=audit(wd/'epmapping_baseline.v',inputs/'asap7.genlib');o=audit(wd/'epmapping_mapped.v',inputs/'asap7.genlib')
 assert o['area']<=b['area']+.0001 and o['delay']<=b['delay']+.001
 assert o['serialized_delay']<=b['serialized_delay']+.001
 assert abs(o['area']-r['area'])<.0001 and abs(o['delay']-r['delay'])<.001
 assert r['optimizer_seconds']<1000 and not r['stats']['corrupt'] and not r['stats']['write_failures']
 if r['mode']=='warm':
  c=idx[r['arm'],'cold'];assert r['netlist_sha256']==c['netlist_sha256'] and r['binary_sha256']==c['binary_sha256']
  assert r['stats']['builds']==0
 proof.append(dict(arm=r['arm'],mode=r['mode'],baseline=b,output=o,sha256={p.name:sha(p) for p in [wd/'manifest.json',wd/'log',wd/'audit.json',wd/'epmapping_mapped.v']}))
 flat.append({k:r[k] for k in ['arm','mode','area','delay','optimizer_seconds','cec','netlist_sha256','binary_sha256']})
with (P/'comparison.tsv').open('w') as f:
 w=csv.DictWriter(f,fieldnames=list(flat[0]),delimiter='\t');w.writeheader();w.writerows(flat)
cache={}
for arm in sorted({r['arm'] for r in runs}):
 files=list((P/'cache'/arm).glob('*.json'));records=[json.loads(f.read_text()) for f in files]
 cache[arm]=dict(records=len(records),covers=sum(len(r['covers']) for r in records),bytes=sum(f.stat().st_size for f in files))
summary=dict(runs=len(runs),cold_warm_pairs=17,all_cec=True,all_initial_bounds=True,original_baseline_sha256=sha(initial),previous_output_sha256=sha(previous),best_area=min(r['area'] for r in runs),delay_range=[min(r['delay'] for r in runs),max(r['delay'] for r in runs)],all_warm_builds_zero=True,cache=cache)
(P/'verification.json').write_text(json.dumps(dict(summary=summary,runs=proof),indent=2)+'\n')
lines=['usb_phy 外部相位复用探索：最终审计','',f"完成 {len(runs)} 次冷/热运行、17 组配对；全部 CEC、初始面积/延迟上界、1000 秒优化器时限及网表一致性检查通过。",'输入、预处理、初始网表与 v25/v20 对齐；整窗口综合与 unmap/remap 关闭。','', '配置 area delay cold_s warm_s cache_covers cache_bytes']
for arm in sorted({r['arm'] for r in runs}):
 c,w=idx[arm,'cold'],idx[arm,'warm'];z=cache[arm]
 lines.append(f"{arm} {c['area']:.2f} {c['delay']:.2f} {c['optimizer_seconds']:.6f} {w['optimizer_seconds']:.6f} {z['covers']} {z['bytes']}")
lines+=['','各配置与机制见 README.txt；未加前缀为早期原型，fanout_* 为加入外部 INV 扇出，refined_* 为最终同二进制、关闭估价明细日志的五项对照，wide16/32 为最终二进制在相同 20000 组合/4000 访问预算下扩大保留前沿的探索。','候选保留策略确实改变候选池，单元回归也证明其能保住独立面积被支配、但有外部反相时更便宜的实现；这不等于 usb_phy 必然增加面积收益。','时间为单次共享主机观测，保留 replacement tracing；早期还有 phase-cost tracing，不应跨阶段直接计算稳定加速比。','新控制默认关闭，当前完整三部分论文和 v25 实验归档未被替换。']
(P/'RESULTS.txt').write_text('\n'.join(lines)+'\n')
print(json.dumps(summary,indent=2))
