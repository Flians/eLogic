"""Paired cold/warm usb_phy pilot; frozen original inputs and native 1000 s deadline."""
import argparse, hashlib, json, os, re, shutil, subprocess, sys
from pathlib import Path

ROOT=Path(__file__).resolve().parents[2]
OUT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'scripts/experiments'))
from audit_mapped_ppa import audit

def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
ap=argparse.ArgumentParser();ap.add_argument('--arms',nargs='+',default=['control','cost','keep','both'])
ap.add_argument('--tag',default='');ap.add_argument('--cost-trace',default='0',choices=['0','1'])
ap.add_argument('--frontier',default=8,type=int);a=ap.parse_args()
inputs=ROOT/'results_v20_three_parts_chain/inputs'
frozen=ROOT/'results_v25_three_parts_progressive_phase/cold'
environment=json.loads((frozen/'manifest.json').read_text())['goal']
env={k:v for k,v in os.environ.items() if not k.startswith(('EPMAPPING_','MAP_EGG_'))}
env.update(environment)
env['MAP_EGG_PROFILE_FRONTIER']=str(a.frontier)
env.update(ABC=str(inputs/'abc'),RAYON_NUM_THREADS='1',EPMAPPING_BASELINE='high_effort',
 EPMAPPING_AREA_MAPPING='1',EPMAPPING_CUT_LIMIT='12',EPMAPPING_RELAX_REQUIRED='100',
 EPMAPPING_NO_DELAY_REGRESSION='1',EPMAPPING_DC_TIME_BUDGET='60',EPMAPPING_ROUNDS='6',
 EPMAPPING_SUPER=str(inputs/'database.super'),EPMAPPING_REPLACEMENT_TRACE='1')
if a.cost_trace=='1': env['EPMAPPING_PHASE_COST_TRACE']='1'
binary=ROOT/'build/epmapping/epmapping_check'
rows=json.loads((OUT/'pilot_results.json').read_text()) if (OUT/'pilot_results.json').exists() else []
for arm in a.arms:
 flags={'control':('0','0','0'),'cost':('1','0','0'),'keep':('0','1','0'),'both':('1','1','0'),
        'fanout_only':('0','0','1'),'fanout_cost':('1','0','1'),
        'fanout_keep':('0','1','1'),'fanout_both':('1','1','1')}[arm]
 arm=a.tag+arm
 cache=OUT/'cache'/arm
 for mode in ['cold','warm']:
  wd=OUT/'runs'/f'{arm}_{mode}';wd.mkdir(parents=True,exist_ok=False)
  assert mode!='cold' or not cache.exists(),cache
  ee=dict(env,EPMAPPING_PHASE_COST=flags[0],MAP_EGG_PROFILE_PHASE_KEEP=flags[1],EPMAPPING_PHASE_FANOUT=flags[2],MAP_EGG_PROFILE_CACHE_DIR=str(cache))
  shutil.copy2(binary,wd/'epmapping_check')
  cmd=[str(wd/'epmapping_check'),str(inputs/'asap7.genlib'),str(inputs/'benchmarks/usb_phy.aig'),str(wd)]
  manifest=dict(cmd=cmd,env={k:v for k,v in ee.items() if k.startswith(('EPMAPPING_','MAP_EGG_'))},binary_sha256=sha(binary),input_sha256={str(p.relative_to(inputs)):sha(p) for p in [inputs/'abc',inputs/'asap7.genlib',inputs/'database.super',inputs/'benchmarks/usb_phy.aig']})
  (wd/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
  with (wd/'log').open('w') as log:
   q=subprocess.run(cmd,env=ee,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,timeout=1100)
  text=(wd/'log').read_text();assert q.returncode==0,text[-3000:]
  assert 'cec=1' in text and 'window_synth windows=0 applied=0' in text and 'post_mapping_timeout=1000' in text
  assert (wd/'epmapping_baseline.v').read_bytes()==(frozen/'tab_main/ae.usb_phy/epmapping_baseline.v').read_bytes()
  base=audit(wd/'epmapping_baseline.v',inputs/'asap7.genlib');out=audit(wd/'epmapping_mapped.v',inputs/'asap7.genlib')
  assert out['area']<=base['area']+.0001 and out['delay']<=base['delay']+.001
  assert out['serialized_delay']<=base['serialized_delay']+.001
  (wd/'audit.json').write_text(json.dumps(dict(base=base,out=out),indent=2)+'\n')
  stat={k:int(v) for k,v in re.findall(r'(\w+)=(\d+)',re.search(r'egraph_profile (.*)',text)[1])}
  row=dict(arm=arm,mode=mode,area=round(out['area'],4),delay=round(out['delay'],4),optimizer_seconds=float(re.search(r'epmapping timing .*optimizer=([\d.]+)',text)[1]),stats=stat,cec=1,baseline_sha256=sha(wd/'epmapping_baseline.v'),netlist_sha256=sha(wd/'epmapping_mapped.v'),binary_sha256=sha(binary),repricing_events=text.count('[phase_cost]'))
  if mode=='warm':
   c=rows[-1];assert c['netlist_sha256']==row['netlist_sha256'] and stat['builds']==0,(c,row)
  rows.append(row);(OUT/'pilot_results.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(row),flush=True)
