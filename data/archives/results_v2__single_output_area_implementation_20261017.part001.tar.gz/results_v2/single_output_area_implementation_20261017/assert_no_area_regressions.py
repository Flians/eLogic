"""Read-only qualification symptom; fails on all retained equal-delay area losses."""
import json
from pathlib import Path
p=Path(__file__).resolve().parents[1]/'single_output_area_full_20261017/validation.json'
v=json.loads(p.read_text())
bad=[(r['k'],r['bench'],r['area_delta']) for r in v['pairs'] if r['control']['valid'] and r['candidate']['valid'] and r['delay_outcome']=='equal' and r['area_delta']>1e-6*max(1,abs(r['control']['area']))]
assert not bad, f'Historical full-tail incumbent criterion failed: {bad}'
