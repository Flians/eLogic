"""Re-audit all usb-only candidate-generation arms without trusting printed PPA."""
import csv,hashlib,json,re,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];P=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'scripts/experiments'))
from audit_mapped_ppa import audit
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
names=['control','output_phase','shannon','davio','all','all_phase_cost','shared_control','shared_phase_only',
       'output_shared','shannon_shared','davio_shared','all_shared','all_shared_unpriced','shannon_phase_cost','final_control','final_best',
       'phase_shannon_shared','shannon_davio_shared']
inputs=ROOT/'results_v20_three_parts_chain/inputs'
previous=ROOT/'results_v25_three_parts_progressive_phase/cold/tab_main/ae.usb_phy'
rows=[];proof=[]
for name in names:
 pair=json.loads((P/f'{name}.json').read_text());assert len(pair)==2
 for r in pair:
  wd=P/'runs'/f"{name}_{r['mode']}";m=json.loads((wd/'manifest.json').read_text());text=(wd/'log').read_text();e=m['env']
  assert e['EPMAPPING_WINDOW_SYN']=='0' and e['EPMAPPING_POST_TIMEOUT']=='1000' and e['EPMAPPING_DSE']=='0'
  assert e['EPMAPPING_OBJECTIVE']=='area_delay_bound' and e['EPMAPPING_BASELINE']=='high_effort'
  assert e['EPMAPPING_ROUNDS']=='6'
  assert 'cec=1' in text and 'window_synth windows=0 applied=0' in text and 'post_mapping_timeout=1000' in text
  assert sha(wd/'epmapping_check')==r['binary_sha256']==m['binary_sha256']
  assert sha(wd/'epmapping_mapped.v')==r['netlist_sha256']
  for path,h in m['input_sha256'].items():assert sha(inputs/path)==h
  assert (wd/'epmapping_baseline.v').read_bytes()==(previous/'epmapping_baseline.v').read_bytes()
  b=audit(wd/'epmapping_baseline.v',inputs/'asap7.genlib');o=audit(wd/'epmapping_mapped.v',inputs/'asap7.genlib')
  assert o['area']<=b['area']+.0001 and o['delay']<=b['delay']+.001
  assert o['serialized_delay']<=b['serialized_delay']+.001
  assert abs(o['area']-r['area'])<.0001 and abs(o['delay']-r['delay'])<.001
  assert r['optimizer_seconds']<1000 and r['cec']==1
  assert not r['profile']['corrupt'] and not r['profile']['write_failures']
  if r['mode']=='warm':
   assert r['netlist_sha256']==pair[0]['netlist_sha256'] and r['binary_sha256']==pair[0]['binary_sha256']
   assert r['profile']['builds']==0
  rows.append(r);proof.append(dict(arm=name,mode=r['mode'],initial=b,output=o,sha256={p.name:sha(p) for p in [wd/'manifest.json',wd/'log',wd/'audit.json',wd/'epmapping_mapped.v']}))
idx={(r['arm'],r['mode']):r for r in rows}
assert idx['final_control','cold']['netlist_sha256']==sha(previous/'epmapping_mapped.v')
assert idx['final_best','cold']['netlist_sha256']==idx['all_shared','cold']['netlist_sha256']
assert idx['shannon_davio_shared','cold']['netlist_sha256']==idx['final_best','cold']['netlist_sha256']
assert idx['final_best','cold']['area']<=21.38001 and idx['final_best','cold']['delay']<=158.681
assert idx['final_best','cold']['binary_sha256']==sha(ROOT/'build/epmapping/epmapping_check')
# Independently check the selector identity responsible for repeated-pin AO33 candidates.
for x in range(16):
 a,b,c,d=[bool((x>>i)&1) for i in range(4)]
 left=d and ((not c) or a) and (c or b)
 right=d and ((c and a) or ((not c) and b))
 assert left==right
summary=dict(scope='usb_phy only, full library, original initial netlist',runs=len(rows),paired_cold_warm=len(names),all_cec=True,all_initial_bounds=True,all_pairs_byte_identical=True,all_warm_profile_builds_zero=True,best_area=idx['final_best','cold']['area'],best_delay=idx['final_best','cold']['delay'],previous_area=22.48,initial_area=22.54,initial_delay=163.29,improvement_vs_previous_percent=100*(1-idx['final_best','cold']['area']/22.48),final_binary_sha256=sha(ROOT/'build/epmapping/epmapping_check'))
summary.update(recommended_arm='shannon_davio_shared',recommended_modes=6,recommended_cold_seconds=idx['shannon_davio_shared','cold']['optimizer_seconds'],recommended_warm_seconds=idx['shannon_davio_shared','warm']['optimizer_seconds'])
(P/'verified_pilot.json').write_text(json.dumps(dict(summary=summary,runs=rows,independent_audits=proof),indent=2)+'\n')
with (P/'comparison.tsv').open('w') as f:
 fields=['arm','mode','area','delay','optimizer_seconds','binary_sha256','netlist_sha256'];w=csv.DictWriter(f,fieldnames=fields,delimiter='\t');w.writeheader();w.writerows({k:r[k] for k in fields} for r in rows)
lines=['usb_phy 候选生成扩展：完整审计结果','',json.dumps(summary,ensure_ascii=False,indent=2),'','配置 面积(μm²) 延迟(ps) 冷优化器秒 热优化器秒 新源替换数']
for name in names:
 c,w=idx[name,'cold'],idx[name,'warm'];lines.append(f"{name} {c['area']:.2f} {c['delay']:.2f} {c['optimizer_seconds']:.6f} {w['optimizer_seconds']:.6f} {int(c['cofactor']['replacements'])}")
lines+=['','输入、原始预处理脚本及初始映射保持一致；整窗口综合和 DSE 关闭；优化器统一限时 1000 秒。时间为最多四个独立单线程进程共享机器的单次观测，有 replacement/cofactor tracing；不构成统计加速比。','冷/热只区分 Rust e-graph 持久化候选池；native cofactor cache 为进程内缓存，因此热运行仍会构建本地分解。','配置族、算法及缓存口径详见 README.txt。各开发阶段二进制有区别，final_control/final_best 是最终编译版本的复验。','所有数据属于 usb_phy 方法验证，不能推广为全部电路的统计结论；正式三部分论文和 v25 归档保持原样。']
(P/'RESULTS.txt').write_text('\n'.join(lines)+'\n');print(json.dumps(summary,indent=2))
