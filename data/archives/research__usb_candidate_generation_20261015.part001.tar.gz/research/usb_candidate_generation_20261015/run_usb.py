"""Frozen-input usb_phy cut-candidate pilot; paired processes and native 1000s limit."""
import argparse,hashlib,json,os,re,shutil,subprocess,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];P=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'scripts/experiments'))
from audit_mapped_ppa import audit
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
ap=argparse.ArgumentParser();ap.add_argument('name');ap.add_argument('--modes',type=int,default=7)
ap.add_argument('--min-leaves',type=int,default=3);ap.add_argument('--phase-cost',action='store_true')
ap.add_argument('--fanout',action='store_true');a=ap.parse_args()
inputs=ROOT/'results_v20_three_parts_chain/inputs';old=ROOT/'results_v25_three_parts_progressive_phase/cold'
env={k:v for k,v in os.environ.items() if not k.startswith(('EPMAPPING_','MAP_EGG_'))}
env.update(json.loads((old/'manifest.json').read_text())['goal'])
env.update(ABC=str(inputs/'abc'),RAYON_NUM_THREADS='1',EPMAPPING_BASELINE='high_effort',EPMAPPING_AREA_MAPPING='1',
 EPMAPPING_CUT_LIMIT='12',EPMAPPING_RELAX_REQUIRED='100',EPMAPPING_NO_DELAY_REGRESSION='1',EPMAPPING_DC_TIME_BUDGET='60',
 EPMAPPING_ROUNDS='6',EPMAPPING_SUPER=str(inputs/'database.super'),EPMAPPING_REPLACEMENT_TRACE='1',
 EPMAPPING_COFAC_TRACE='1',EPMAPPING_COFAC=str(a.modes),EPMAPPING_COFAC_MIN_LEAVES=str(a.min_leaves),
 EPMAPPING_PHASE_COST='1' if a.phase_cost else '0',EPMAPPING_PHASE_FANOUT='1' if a.fanout else '0',MAP_EGG_PROFILE_PHASE_KEEP='0')
cache=P/'cache'/a.name;assert not cache.exists()
env['MAP_EGG_PROFILE_CACHE_DIR']=str(cache)
rows=[];binary=ROOT/'build/epmapping/epmapping_check'
for mode in ['cold','warm']:
 wd=P/'runs'/f'{a.name}_{mode}';wd.mkdir(parents=True,exist_ok=False);shutil.copy2(binary,wd/'epmapping_check')
 cmd=[str(wd/'epmapping_check'),str(inputs/'asap7.genlib'),str(inputs/'benchmarks/usb_phy.aig'),str(wd)]
 manifest=dict(cmd=cmd,env={k:v for k,v in env.items() if k.startswith(('EPMAPPING_','MAP_EGG_'))},binary_sha256=sha(binary),input_sha256={str(x.relative_to(inputs)):sha(x) for x in [inputs/'abc',inputs/'database.super',inputs/'asap7.genlib',inputs/'benchmarks/usb_phy.aig']})
 (wd/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
 with (wd/'log').open('w') as f:q=subprocess.run(cmd,cwd=ROOT,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=1100)
 text=(wd/'log').read_text();assert q.returncode==0,text[-3000:]
 assert 'cec=1' in text and 'window_synth windows=0 applied=0' in text and 'post_mapping_timeout=1000' in text
 assert (wd/'epmapping_baseline.v').read_bytes()==(old/'tab_main/ae.usb_phy/epmapping_baseline.v').read_bytes()
 b=audit(wd/'epmapping_baseline.v',inputs/'asap7.genlib');o=audit(wd/'epmapping_mapped.v',inputs/'asap7.genlib')
 assert o['area']<=b['area']+.0001 and o['delay']<=b['delay']+.001 and o['serialized_delay']<=b['serialized_delay']+.001
 stats={k:int(v) for k,v in re.findall(r'(\w+)=(\d+)',re.search(r'egraph_profile (.*)',text)[1])}
 cof={k:float(v) for k,v in re.findall(r'(\w+)=([\d.]+)',re.search(r'epmapping cofactor (.*)',text)[1])}
 row=dict(arm=a.name,mode=mode,area=round(o['area'],4),delay=round(o['delay'],4),optimizer_seconds=float(re.search(r'epmapping timing .*optimizer=([\d.]+)',text)[1]),cofactor=cof,profile=stats,cec=1,baseline_sha256=sha(wd/'epmapping_baseline.v'),netlist_sha256=sha(wd/'epmapping_mapped.v'),binary_sha256=sha(binary))
 if mode=='warm':assert stats['builds']==0 and row['netlist_sha256']==rows[0]['netlist_sha256']
 (wd/'audit.json').write_text(json.dumps(dict(base=b,out=o),indent=2)+'\n')
 rows.append(row);(P/f'{a.name}.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(row),flush=True)
