# Fixed-bound actual-area recovery: isolated full EPFL study

Same prepared once-resyn2 inputs and inventories; original baseline algorithms unchanged. No production promotion or per-design source/profile selection.

**Reference matters:** against V2 regional cuts, thirty eligible pairs have equal delay and 29 lower areas (one tie). Against production, delay has 11 gains / 7 ties / 12 regressions; area has 7 gains / 23 regressions. The production incumbent is not yet protected by this prototype.

Two complete runs: 80 observations, 68 CEC passes, 60 legacy-import-eligible covers and 12 explicit pending-dependency pool-reservation failures. All successful repeat delays agree; twelve area values vary. Two runs provide no statistical confidence, and no best run is selected.

The six full-scope dominance gates are false. Area-delay is a posthoc comparison on this delay-first, fixed-delay-bound area-recovery profile, not a separately area-first optimized experiment.

Multiplier still uses 55,628 cumulative imported nodes and is ineligible under the old 20,000 allowance. State retirement is not a cumulative-import repair. Hyp/div/mem_ctrl reserve failures remain recorded.

## First full run: delay

| Inventory | Design | Production | Isolated recovery | Legacy import eligible | Status |
|---|---|---:|---:|---|---|
| 3in | adder | 2585.47999 | 2585.47999 | yes | diagnostic_cec_ok |
| 3in | bar | 190.87000 | 254.76000 | yes | diagnostic_cec_ok |
| 3in | div | — | — | no | failed |
| 3in | hyp | — | — | no | failed |
| 3in | log2 | — | 4465.34001 | no | diagnostic_cec_ok |
| 3in | max | 2111.03000 | 2156.02000 | yes | diagnostic_cec_ok |
| 3in | multiplier | — | 3075.63000 | no | diagnostic_cec_ok |
| 3in | sin | 2095.27001 | 2112.14999 | yes | diagnostic_cec_ok |
| 3in | sqrt | 73038.35034 | 60295.99044 | yes | diagnostic_cec_ok |
| 3in | square | 2707.67996 | 2535.25000 | yes | diagnostic_cec_ok |
| 3in | arbiter | 905.89000 | 923.44000 | yes | diagnostic_cec_ok |
| 3in | cavlc | 197.59000 | 203.63000 | yes | diagnostic_cec_ok |
| 3in | ctrl | 108.06000 | 108.06000 | yes | diagnostic_cec_ok |
| 3in | dec | 82.92000 | 82.92000 | yes | diagnostic_cec_ok |
| 3in | i2c | 166.78000 | 169.15000 | yes | diagnostic_cec_ok |
| 3in | int2float | 183.34000 | 183.34000 | yes | diagnostic_cec_ok |
| 3in | mem_ctrl | — | — | no | failed |
| 3in | priority | 2062.18000 | 2065.92000 | yes | diagnostic_cec_ok |
| 3in | router | 216.40000 | 216.40000 | yes | diagnostic_cec_ok |
| 3in | voter | 817.57001 | 801.93999 | yes | diagnostic_cec_ok |
| 4in | adder | 2585.23000 | 2570.91000 | yes | diagnostic_cec_ok |
| 4in | bar | 188.34000 | 216.03000 | yes | diagnostic_cec_ok |
| 4in | div | — | — | no | failed |
| 4in | hyp | — | — | no | failed |
| 4in | log2 | — | 4147.40002 | no | diagnostic_cec_ok |
| 4in | max | 2098.34000 | 2119.86000 | yes | diagnostic_cec_ok |
| 4in | multiplier | — | 2999.51002 | no | diagnostic_cec_ok |
| 4in | sin | 2029.35002 | 1882.00001 | yes | diagnostic_cec_ok |
| 4in | sqrt | 73633.69061 | 48010.83131 | yes | diagnostic_cec_ok |
| 4in | square | 2772.81997 | 2500.72000 | yes | diagnostic_cec_ok |
| 4in | arbiter | 925.93000 | 923.44000 | yes | diagnostic_cec_ok |
| 4in | cavlc | 194.95000 | 202.93000 | yes | diagnostic_cec_ok |
| 4in | ctrl | 103.17000 | 103.17000 | yes | diagnostic_cec_ok |
| 4in | dec | 66.15000 | 68.67000 | yes | diagnostic_cec_ok |
| 4in | i2c | 165.79000 | 165.79000 | yes | diagnostic_cec_ok |
| 4in | int2float | 181.28000 | 181.00000 | yes | diagnostic_cec_ok |
| 4in | mem_ctrl | — | — | no | failed |
| 4in | priority | 2047.24000 | 2062.54000 | yes | diagnostic_cec_ok |
| 4in | router | 199.00000 | 187.47000 | yes | diagnostic_cec_ok |
| 4in | voter | 758.00001 | 739.97001 | yes | diagnostic_cec_ok |

## First full run: area

| Inventory | Design | Production | Isolated recovery | Legacy import eligible | Status |
|---|---|---:|---:|---|---|
| 3in | adder | 72.55000 | 85.68000 | yes | diagnostic_cec_ok |
| 3in | bar | 289.64000 | 282.13001 | yes | diagnostic_cec_ok |
| 3in | div | — | — | no | failed |
| 3in | hyp | — | — | no | failed |
| 3in | log2 | — | 3582.48002 | no | diagnostic_cec_ok |
| 3in | max | 284.96000 | 260.62000 | yes | diagnostic_cec_ok |
| 3in | multiplier | — | 3128.77000 | no | diagnostic_cec_ok |
| 3in | sin | 620.10000 | 635.67000 | yes | diagnostic_cec_ok |
| 3in | sqrt | 2939.22998 | 2833.16999 | yes | diagnostic_cec_ok |
| 3in | square | 2582.80000 | 2609.31000 | yes | diagnostic_cec_ok |
| 3in | arbiter | 767.02999 | 782.32999 | yes | diagnostic_cec_ok |
| 3in | cavlc | 44.93000 | 47.55000 | yes | diagnostic_cec_ok |
| 3in | ctrl | 7.33000 | 8.31000 | yes | diagnostic_cec_ok |
| 3in | dec | 27.68000 | 27.86000 | yes | diagnostic_cec_ok |
| 3in | i2c | 82.87000 | 83.77000 | yes | diagnostic_cec_ok |
| 3in | int2float | 14.40000 | 14.86000 | yes | diagnostic_cec_ok |
| 3in | mem_ctrl | — | — | no | failed |
| 3in | priority | 68.54000 | 101.13000 | yes | diagnostic_cec_ok |
| 3in | router | 13.75000 | 15.59000 | yes | diagnostic_cec_ok |
| 3in | voter | 1382.32999 | 1332.04000 | yes | diagnostic_cec_ok |
| 4in | adder | 84.49000 | 119.30000 | yes | diagnostic_cec_ok |
| 4in | bar | 304.71000 | 250.82001 | yes | diagnostic_cec_ok |
| 4in | div | — | — | no | failed |
| 4in | hyp | — | — | no | failed |
| 4in | log2 | — | 4161.68001 | no | diagnostic_cec_ok |
| 4in | max | 281.63000 | 266.06000 | yes | diagnostic_cec_ok |
| 4in | multiplier | — | 3695.62001 | no | diagnostic_cec_ok |
| 4in | sin | 717.67000 | 761.61000 | yes | diagnostic_cec_ok |
| 4in | sqrt | 3847.46000 | 2867.34002 | yes | diagnostic_cec_ok |
| 4in | square | 2953.72001 | 2979.92001 | yes | diagnostic_cec_ok |
| 4in | arbiter | 728.71999 | 786.20999 | yes | diagnostic_cec_ok |
| 4in | cavlc | 44.60000 | 47.60000 | yes | diagnostic_cec_ok |
| 4in | ctrl | 7.19000 | 8.31000 | yes | diagnostic_cec_ok |
| 4in | dec | 29.18000 | 30.22000 | yes | diagnostic_cec_ok |
| 4in | i2c | 80.69000 | 82.77000 | yes | diagnostic_cec_ok |
| 4in | int2float | 13.22000 | 15.29000 | yes | diagnostic_cec_ok |
| 4in | mem_ctrl | — | — | no | failed |
| 4in | priority | 52.55000 | 93.48000 | yes | diagnostic_cec_ok |
| 4in | router | 13.07000 | 17.76000 | yes | diagnostic_cec_ok |
| 4in | voter | 1687.46000 | 1823.07000 | yes | diagnostic_cec_ok |

## Repeated target ranges

| Inventory | Design | Delay | Area range |
|---|---|---:|---:|
| 3in | bar | 254.76000 | 282.13001–282.13001 |
| 3in | multiplier | 3075.63000 | 3128.77000–3130.46000 |
| 3in | sin | 2112.14999 | 635.67000–636.81000 |
| 3in | sqrt | 60295.99044 | 2833.16999–2833.97999 |
| 4in | bar | 216.03000 | 250.82001–250.82001 |
| 4in | multiplier | 2999.51002 | 3695.62001–3695.69001 |
| 4in | sin | 1882.00001 | 761.61000–762.33000 |
| 4in | sqrt | 48010.83131 | 2867.34002–2867.34002 |

Commands, report/audit/artifact hashes, actual budget values, all failure logs and source fingerprints are preserved in both full-run directories and the implementation archive. Six native tests pass. Global limits remain 20k nodes / 16 cuts per class / 100k retained pool / 2s construction and recovery / SAT limit 16 (actual SAT 0), with mapping-only external 300s and original 60s process guard.

Next integration must reuse the production import and incumbent in one graph, pool and deadline. Running separate mappers and choosing per-design outputs would not establish compliance.
