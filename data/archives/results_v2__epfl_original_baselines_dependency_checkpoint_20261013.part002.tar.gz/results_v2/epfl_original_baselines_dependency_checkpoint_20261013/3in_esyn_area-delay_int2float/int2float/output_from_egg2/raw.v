// Benchmark "/home/flynn/workplace/MIGBalance/results_v2/epfl_original_baselines_dependency_checkpoint_20261013/3in_esyn_area-delay_int2float/int2float/output_from_egg2/logic" written by ABC on Tue Oct 13 14:24:09 2026

module \/home/flynn/workplace/MIGBalance/results_v2/epfl_original_baselines_dependency_checkpoint_20261013/3in_esyn_area-delay_int2float/int2float/output_from_egg2/logic  ( 
    \B[1] , \B[2] , \B[3] , \B[4] , \B[5] , \B[6] , \B[7] , \B[8] , \B[9] ,
    \B[10] , \B[0] ,
    \M[0] , \M[1] , \M[2] , \M[3] , \E[0] , \E[1] , \E[2]   );
  input  \B[1] , \B[2] , \B[3] , \B[4] , \B[5] , \B[6] , \B[7] , \B[8] ,
    \B[9] , \B[10] , \B[0] ;
  output \M[0] , \M[1] , \M[2] , \M[3] , \E[0] , \E[1] , \E[2] ;
  wire new_n19_, new_n20_, new_n21_, new_n22_, new_n23_, new_n24_, new_n25_,
    new_n26_, new_n27_, new_n28_, new_n29_, new_n30_, new_n31_, new_n32_,
    new_n33_, new_n34_, new_n35_, new_n36_, new_n37_, new_n38_, new_n39_,
    new_n40_, new_n41_, new_n42_, new_n43_, new_n44_, new_n45_, new_n46_,
    new_n47_, new_n48_, new_n49_, new_n50_, new_n51_, new_n52_, new_n53_,
    new_n54_, new_n55_, new_n56_, new_n57_, new_n58_, new_n59_, new_n60_,
    new_n61_, new_n62_, new_n63_, new_n64_, new_n65_, new_n66_, new_n67_,
    new_n68_, new_n70_, new_n71_, new_n72_, new_n73_, new_n74_, new_n75_,
    new_n76_, new_n77_, new_n78_, new_n79_, new_n80_, new_n81_, new_n82_,
    new_n83_, new_n84_, new_n85_, new_n86_, new_n87_, new_n88_, new_n89_,
    new_n90_, new_n91_, new_n92_, new_n93_, new_n94_, new_n95_, new_n96_,
    new_n97_, new_n98_, new_n99_, new_n100_, new_n101_, new_n102_,
    new_n103_, new_n104_, new_n105_, new_n106_, new_n107_, new_n109_,
    new_n110_, new_n111_, new_n112_, new_n113_, new_n114_, new_n115_,
    new_n116_, new_n117_, new_n118_, new_n119_, new_n120_, new_n121_,
    new_n122_, new_n123_, new_n124_, new_n125_, new_n126_, new_n127_,
    new_n128_, new_n129_, new_n130_, new_n131_, new_n132_, new_n133_,
    new_n134_, new_n135_, new_n136_, new_n137_, new_n138_, new_n139_,
    new_n140_, new_n142_, new_n143_, new_n144_, new_n145_, new_n146_,
    new_n147_, new_n148_, new_n150_, new_n151_, new_n152_, new_n153_,
    new_n154_, new_n155_, new_n156_, new_n157_, new_n158_, new_n159_,
    new_n160_, new_n162_, new_n163_, new_n164_, new_n165_, new_n166_,
    new_n167_, new_n168_, new_n169_;
  INVx1_ASAP7_75t_R   g000(.A(\B[1] ), .Y(new_n19_));
  INVx1_ASAP7_75t_R   g001(.A(\B[2] ), .Y(new_n20_));
  INVx1_ASAP7_75t_R   g002(.A(\B[3] ), .Y(new_n21_));
  INVx1_ASAP7_75t_R   g003(.A(\B[4] ), .Y(new_n22_));
  INVx1_ASAP7_75t_R   g004(.A(\B[5] ), .Y(new_n23_));
  INVx1_ASAP7_75t_R   g005(.A(\B[6] ), .Y(new_n24_));
  INVx1_ASAP7_75t_R   g006(.A(\B[7] ), .Y(new_n25_));
  INVx1_ASAP7_75t_R   g007(.A(\B[8] ), .Y(new_n26_));
  INVx1_ASAP7_75t_R   g008(.A(\B[9] ), .Y(new_n27_));
  INVx1_ASAP7_75t_R   g009(.A(\B[10] ), .Y(new_n28_));
  INVx1_ASAP7_75t_R   g010(.A(\B[0] ), .Y(new_n29_));
  NOR2x1_ASAP7_75t_R  g011(.A(\B[8] ), .B(\B[9] ), .Y(new_n30_));
  INVx1_ASAP7_75t_R   g012(.A(new_n30_), .Y(new_n31_));
  NAND2x1_ASAP7_75t_R g013(.A(\B[2] ), .B(new_n21_), .Y(new_n32_));
  NAND2x1_ASAP7_75t_R g014(.A(new_n20_), .B(\B[3] ), .Y(new_n33_));
  AO21x1_ASAP7_75t_R  g015(.A1(new_n32_), .A2(new_n33_), .B(new_n31_), .Y(new_n34_));
  AOI21x1_ASAP7_75t_R g016(.A1(new_n28_), .A2(new_n34_), .B(\B[7] ), .Y(new_n35_));
  NOR2x1_ASAP7_75t_R  g017(.A(new_n26_), .B(new_n28_), .Y(new_n36_));
  AO21x1_ASAP7_75t_R  g018(.A1(\B[9] ), .A2(new_n36_), .B(new_n35_), .Y(new_n37_));
  AND3x1_ASAP7_75t_R  g019(.A(new_n24_), .B(\B[7] ), .C(\B[10] ), .Y(new_n38_));
  AO21x1_ASAP7_75t_R  g020(.A1(\B[6] ), .A2(new_n37_), .B(new_n38_), .Y(new_n39_));
  NAND2x1_ASAP7_75t_R g021(.A(new_n20_), .B(new_n25_), .Y(new_n40_));
  OR3x1_ASAP7_75t_R   g022(.A(new_n19_), .B(new_n23_), .C(new_n40_), .Y(new_n41_));
  NOR2x1_ASAP7_75t_R  g023(.A(\B[4] ), .B(new_n25_), .Y(new_n42_));
  OAI21x1_ASAP7_75t_R g024(.A1(\B[4] ), .A2(new_n25_), .B(new_n41_), .Y(new_n43_));
  NAND2x1_ASAP7_75t_R g025(.A(new_n21_), .B(\B[4] ), .Y(new_n44_));
  AND3x1_ASAP7_75t_R  g026(.A(new_n21_), .B(\B[4] ), .C(\B[7] ), .Y(new_n45_));
  AO21x1_ASAP7_75t_R  g027(.A1(\B[3] ), .A2(new_n43_), .B(new_n45_), .Y(new_n46_));
  AND3x1_ASAP7_75t_R  g028(.A(new_n22_), .B(\B[5] ), .C(\B[8] ), .Y(new_n47_));
  AOI21x1_ASAP7_75t_R g029(.A1(new_n26_), .A2(new_n46_), .B(new_n47_), .Y(new_n48_));
  NOR2x1_ASAP7_75t_R  g030(.A(\B[4] ), .B(new_n26_), .Y(new_n49_));
  AO21x1_ASAP7_75t_R  g031(.A1(\B[1] ), .A2(\B[4] ), .B(new_n49_), .Y(new_n50_));
  OA21x2_ASAP7_75t_R  g032(.A1(new_n19_), .A2(new_n22_), .B(new_n29_), .Y(new_n51_));
  OR3x1_ASAP7_75t_R   g033(.A(\B[6] ), .B(\B[7] ), .C(new_n51_), .Y(new_n52_));
  AO21x1_ASAP7_75t_R  g034(.A1(\B[0] ), .A2(new_n50_), .B(new_n52_), .Y(new_n53_));
  NOR2x1_ASAP7_75t_R  g035(.A(new_n22_), .B(new_n26_), .Y(new_n54_));
  INVx1_ASAP7_75t_R   g036(.A(new_n54_), .Y(new_n55_));
  AO21x1_ASAP7_75t_R  g037(.A1(new_n53_), .A2(new_n55_), .B(\B[5] ), .Y(new_n56_));
  AOI21x1_ASAP7_75t_R g038(.A1(new_n48_), .A2(new_n56_), .B(\B[9] ), .Y(new_n57_));
  NAND2x1_ASAP7_75t_R g039(.A(new_n25_), .B(new_n26_), .Y(new_n58_));
  OR3x1_ASAP7_75t_R   g040(.A(\B[1] ), .B(new_n20_), .C(new_n58_), .Y(new_n59_));
  NOR2x1_ASAP7_75t_R  g041(.A(new_n21_), .B(new_n22_), .Y(new_n60_));
  INVx1_ASAP7_75t_R   g042(.A(new_n60_), .Y(new_n61_));
  OR3x1_ASAP7_75t_R   g043(.A(new_n19_), .B(\B[2] ), .C(new_n42_), .Y(new_n62_));
  OR3x1_ASAP7_75t_R   g044(.A(new_n54_), .B(new_n60_), .C(new_n62_), .Y(new_n63_));
  AND3x1_ASAP7_75t_R  g045(.A(new_n27_), .B(new_n59_), .C(new_n63_), .Y(new_n64_));
  OR3x1_ASAP7_75t_R   g046(.A(new_n23_), .B(\B[6] ), .C(new_n64_), .Y(new_n65_));
  INVx1_ASAP7_75t_R   g047(.A(new_n65_), .Y(new_n66_));
  AND3x1_ASAP7_75t_R  g048(.A(new_n23_), .B(\B[6] ), .C(\B[9] ), .Y(new_n67_));
  OR3x1_ASAP7_75t_R   g049(.A(new_n66_), .B(new_n67_), .C(new_n57_), .Y(new_n68_));
  AO21x1_ASAP7_75t_R  g050(.A1(new_n28_), .A2(new_n68_), .B(new_n39_), .Y(\M[0] ));
  NOR2x1_ASAP7_75t_R  g051(.A(new_n24_), .B(new_n25_), .Y(new_n70_));
  OR3x1_ASAP7_75t_R   g052(.A(new_n24_), .B(new_n25_), .C(\B[9] ), .Y(new_n71_));
  OR3x1_ASAP7_75t_R   g053(.A(new_n26_), .B(new_n28_), .C(new_n71_), .Y(new_n72_));
  NOR2x1_ASAP7_75t_R  g054(.A(new_n24_), .B(\B[9] ), .Y(new_n73_));
  OR3x1_ASAP7_75t_R   g055(.A(new_n24_), .B(\B[9] ), .C(\B[4] ), .Y(new_n74_));
  OR3x1_ASAP7_75t_R   g056(.A(new_n23_), .B(\B[6] ), .C(\B[1] ), .Y(new_n75_));
  AOI21x1_ASAP7_75t_R g057(.A1(new_n74_), .A2(new_n75_), .B(\B[3] ), .Y(new_n76_));
  NAND2x1_ASAP7_75t_R g058(.A(new_n21_), .B(\B[5] ), .Y(new_n77_));
  OR3x1_ASAP7_75t_R   g059(.A(\B[3] ), .B(new_n23_), .C(\B[6] ), .Y(new_n78_));
  AOI21x1_ASAP7_75t_R g060(.A1(new_n74_), .A2(new_n78_), .B(\B[2] ), .Y(new_n79_));
  AND3x1_ASAP7_75t_R  g061(.A(\B[2] ), .B(new_n60_), .C(new_n73_), .Y(new_n80_));
  OR3x1_ASAP7_75t_R   g062(.A(new_n79_), .B(new_n80_), .C(new_n76_), .Y(new_n81_));
  AOI21x1_ASAP7_75t_R g063(.A1(new_n25_), .A2(new_n81_), .B(\B[10] ), .Y(new_n82_));
  OR3x1_ASAP7_75t_R   g064(.A(\B[8] ), .B(new_n70_), .C(new_n82_), .Y(new_n83_));
  NAND2x1_ASAP7_75t_R g065(.A(new_n22_), .B(new_n27_), .Y(new_n84_));
  AOI21x1_ASAP7_75t_R g066(.A1(new_n40_), .A2(new_n84_), .B(\B[1] ), .Y(new_n85_));
  AOI21x1_ASAP7_75t_R g067(.A1(\B[8] ), .A2(new_n27_), .B(new_n85_), .Y(new_n86_));
  NOR2x1_ASAP7_75t_R  g068(.A(new_n20_), .B(\B[0] ), .Y(new_n87_));
  OR3x1_ASAP7_75t_R   g069(.A(new_n22_), .B(\B[7] ), .C(new_n87_), .Y(new_n88_));
  NAND2x1_ASAP7_75t_R g070(.A(\B[1] ), .B(\B[2] ), .Y(new_n89_));
  AO21x1_ASAP7_75t_R  g071(.A1(\B[0] ), .A2(new_n89_), .B(new_n88_), .Y(new_n90_));
  AOI21x1_ASAP7_75t_R g072(.A1(new_n86_), .A2(new_n90_), .B(\B[6] ), .Y(new_n91_));
  NOR2x1_ASAP7_75t_R  g073(.A(\B[7] ), .B(new_n27_), .Y(new_n92_));
  AND3x1_ASAP7_75t_R  g074(.A(\B[7] ), .B(new_n30_), .C(new_n61_), .Y(new_n93_));
  OR3x1_ASAP7_75t_R   g075(.A(new_n92_), .B(new_n93_), .C(new_n91_), .Y(new_n94_));
  AO21x1_ASAP7_75t_R  g076(.A1(new_n27_), .A2(new_n49_), .B(new_n92_), .Y(new_n95_));
  AO21x1_ASAP7_75t_R  g077(.A1(new_n22_), .A2(new_n27_), .B(new_n92_), .Y(new_n96_));
  OR3x1_ASAP7_75t_R   g078(.A(new_n24_), .B(new_n30_), .C(new_n96_), .Y(new_n97_));
  OR3x1_ASAP7_75t_R   g079(.A(\B[8] ), .B(\B[9] ), .C(new_n22_), .Y(new_n98_));
  AO21x1_ASAP7_75t_R  g080(.A1(new_n25_), .A2(new_n89_), .B(new_n98_), .Y(new_n99_));
  NAND2x1_ASAP7_75t_R g081(.A(new_n22_), .B(new_n24_), .Y(new_n100_));
  OR3x1_ASAP7_75t_R   g082(.A(new_n19_), .B(new_n20_), .C(\B[7] ), .Y(new_n101_));
  OR3x1_ASAP7_75t_R   g083(.A(\B[4] ), .B(\B[6] ), .C(new_n101_), .Y(new_n102_));
  AO21x1_ASAP7_75t_R  g084(.A1(new_n99_), .A2(new_n102_), .B(new_n21_), .Y(new_n103_));
  AOI21x1_ASAP7_75t_R g085(.A1(new_n97_), .A2(new_n103_), .B(new_n23_), .Y(new_n104_));
  AO21x1_ASAP7_75t_R  g086(.A1(new_n24_), .A2(new_n95_), .B(new_n104_), .Y(new_n105_));
  AO21x1_ASAP7_75t_R  g087(.A1(new_n23_), .A2(new_n94_), .B(new_n105_), .Y(new_n106_));
  NAND2x1_ASAP7_75t_R g088(.A(new_n28_), .B(new_n106_), .Y(new_n107_));
  AND3x1_ASAP7_75t_R  g089(.A(new_n72_), .B(new_n83_), .C(new_n107_), .Y(\M[1] ));
  AO21x1_ASAP7_75t_R  g090(.A1(\B[5] ), .A2(\B[7] ), .B(new_n26_), .Y(new_n109_));
  AOI21x1_ASAP7_75t_R g091(.A1(new_n28_), .A2(new_n109_), .B(new_n27_), .Y(new_n110_));
  AND3x1_ASAP7_75t_R  g092(.A(\B[5] ), .B(new_n26_), .C(\B[9] ), .Y(new_n111_));
  OA21x2_ASAP7_75t_R  g093(.A1(new_n36_), .A2(new_n111_), .B(new_n70_), .Y(new_n112_));
  NOR2x1_ASAP7_75t_R  g094(.A(new_n23_), .B(new_n24_), .Y(new_n113_));
  INVx1_ASAP7_75t_R   g095(.A(new_n113_), .Y(new_n114_));
  OR3x1_ASAP7_75t_R   g096(.A(\B[5] ), .B(new_n24_), .C(new_n20_), .Y(new_n115_));
  AOI21x1_ASAP7_75t_R g097(.A1(new_n75_), .A2(new_n115_), .B(new_n61_), .Y(new_n116_));
  AOI21x1_ASAP7_75t_R g098(.A1(new_n61_), .A2(new_n113_), .B(new_n116_), .Y(new_n117_));
  OR3x1_ASAP7_75t_R   g099(.A(\B[4] ), .B(new_n23_), .C(new_n21_), .Y(new_n118_));
  OR3x1_ASAP7_75t_R   g100(.A(\B[6] ), .B(new_n29_), .C(new_n44_), .Y(new_n119_));
  AO21x1_ASAP7_75t_R  g101(.A1(new_n118_), .A2(new_n119_), .B(new_n19_), .Y(new_n120_));
  NOR2x1_ASAP7_75t_R  g102(.A(new_n19_), .B(new_n29_), .Y(new_n121_));
  INVx1_ASAP7_75t_R   g103(.A(new_n121_), .Y(new_n122_));
  OR3x1_ASAP7_75t_R   g104(.A(new_n21_), .B(new_n22_), .C(new_n121_), .Y(new_n123_));
  AO21x1_ASAP7_75t_R  g105(.A1(new_n100_), .A2(new_n123_), .B(\B[5] ), .Y(new_n124_));
  AO21x1_ASAP7_75t_R  g106(.A1(new_n120_), .A2(new_n124_), .B(new_n20_), .Y(new_n125_));
  OR3x1_ASAP7_75t_R   g107(.A(\B[2] ), .B(new_n21_), .C(\B[6] ), .Y(new_n126_));
  AO21x1_ASAP7_75t_R  g108(.A1(new_n77_), .A2(new_n126_), .B(new_n22_), .Y(new_n127_));
  AO21x1_ASAP7_75t_R  g109(.A1(new_n125_), .A2(new_n127_), .B(\B[7] ), .Y(new_n128_));
  AO21x1_ASAP7_75t_R  g110(.A1(new_n117_), .A2(new_n128_), .B(\B[8] ), .Y(new_n129_));
  NAND2x1_ASAP7_75t_R g111(.A(\B[4] ), .B(\B[5] ), .Y(new_n130_));
  OR3x1_ASAP7_75t_R   g112(.A(\B[6] ), .B(new_n25_), .C(new_n21_), .Y(new_n131_));
  NOR2x1_ASAP7_75t_R  g113(.A(new_n24_), .B(\B[7] ), .Y(new_n132_));
  OR3x1_ASAP7_75t_R   g114(.A(new_n24_), .B(\B[7] ), .C(\B[2] ), .Y(new_n133_));
  AOI21x1_ASAP7_75t_R g115(.A1(new_n131_), .A2(new_n133_), .B(new_n130_), .Y(new_n134_));
  AOI21x1_ASAP7_75t_R g116(.A1(new_n70_), .A2(new_n130_), .B(new_n134_), .Y(new_n135_));
  AO21x1_ASAP7_75t_R  g117(.A1(new_n129_), .A2(new_n135_), .B(\B[9] ), .Y(new_n136_));
  AND3x1_ASAP7_75t_R  g118(.A(\B[4] ), .B(\B[5] ), .C(new_n132_), .Y(new_n137_));
  AO21x1_ASAP7_75t_R  g119(.A1(new_n24_), .A2(\B[7] ), .B(new_n137_), .Y(new_n138_));
  NAND2x1_ASAP7_75t_R g120(.A(\B[8] ), .B(new_n138_), .Y(new_n139_));
  AOI21x1_ASAP7_75t_R g121(.A1(new_n136_), .A2(new_n139_), .B(\B[10] ), .Y(new_n140_));
  OR3x1_ASAP7_75t_R   g122(.A(new_n110_), .B(new_n112_), .C(new_n140_), .Y(\M[2] ));
  NAND2x1_ASAP7_75t_R g123(.A(new_n27_), .B(new_n28_), .Y(new_n142_));
  OR3x1_ASAP7_75t_R   g124(.A(new_n23_), .B(new_n24_), .C(new_n25_), .Y(new_n143_));
  OR3x1_ASAP7_75t_R   g125(.A(\B[2] ), .B(new_n55_), .C(new_n143_), .Y(new_n144_));
  INVx1_ASAP7_75t_R   g126(.A(new_n144_), .Y(new_n145_));
  AND3x1_ASAP7_75t_R  g127(.A(new_n22_), .B(new_n25_), .C(new_n26_), .Y(new_n146_));
  NOR2x1_ASAP7_75t_R  g128(.A(\B[5] ), .B(\B[6] ), .Y(new_n147_));
  AOI21x1_ASAP7_75t_R g129(.A1(new_n146_), .A2(new_n147_), .B(new_n145_), .Y(new_n148_));
  OR3x1_ASAP7_75t_R   g130(.A(\B[3] ), .B(new_n142_), .C(new_n148_), .Y(\M[3] ));
  AOI21x1_ASAP7_75t_R g131(.A1(new_n121_), .A2(new_n147_), .B(new_n137_), .Y(new_n150_));
  OR3x1_ASAP7_75t_R   g132(.A(new_n20_), .B(new_n21_), .C(new_n150_), .Y(new_n151_));
  AOI21x1_ASAP7_75t_R g133(.A1(new_n101_), .A2(new_n114_), .B(new_n21_), .Y(new_n152_));
  AO21x1_ASAP7_75t_R  g134(.A1(new_n23_), .A2(new_n25_), .B(new_n152_), .Y(new_n153_));
  AO21x1_ASAP7_75t_R  g135(.A1(\B[4] ), .A2(new_n153_), .B(new_n132_), .Y(new_n154_));
  AO21x1_ASAP7_75t_R  g136(.A1(new_n151_), .A2(new_n154_), .B(\B[8] ), .Y(new_n155_));
  OA21x2_ASAP7_75t_R  g137(.A1(new_n21_), .A2(new_n26_), .B(new_n32_), .Y(new_n156_));
  OR3x1_ASAP7_75t_R   g138(.A(new_n71_), .B(new_n130_), .C(new_n156_), .Y(new_n157_));
  OR3x1_ASAP7_75t_R   g139(.A(new_n25_), .B(new_n114_), .C(new_n26_), .Y(new_n158_));
  INVx1_ASAP7_75t_R   g140(.A(new_n158_), .Y(new_n159_));
  OA21x2_ASAP7_75t_R  g141(.A1(new_n27_), .A2(new_n159_), .B(new_n157_), .Y(new_n160_));
  AO21x1_ASAP7_75t_R  g142(.A1(new_n155_), .A2(new_n160_), .B(\B[10] ), .Y(\E[0] ));
  OR3x1_ASAP7_75t_R   g143(.A(new_n21_), .B(\B[8] ), .C(new_n122_), .Y(new_n162_));
  OR3x1_ASAP7_75t_R   g144(.A(\B[5] ), .B(\B[7] ), .C(new_n162_), .Y(new_n163_));
  AO21x1_ASAP7_75t_R  g145(.A1(new_n158_), .A2(new_n163_), .B(new_n20_), .Y(new_n164_));
  OR3x1_ASAP7_75t_R   g146(.A(new_n21_), .B(new_n26_), .C(new_n143_), .Y(new_n165_));
  AOI21x1_ASAP7_75t_R g147(.A1(new_n164_), .A2(new_n165_), .B(new_n22_), .Y(new_n166_));
  AND3x1_ASAP7_75t_R  g148(.A(\B[2] ), .B(new_n60_), .C(new_n113_), .Y(new_n167_));
  OR3x1_ASAP7_75t_R   g149(.A(new_n58_), .B(new_n147_), .C(new_n167_), .Y(new_n168_));
  INVx1_ASAP7_75t_R   g150(.A(new_n168_), .Y(new_n169_));
  OR3x1_ASAP7_75t_R   g151(.A(new_n142_), .B(new_n169_), .C(new_n166_), .Y(\E[1] ));
  OR3x1_ASAP7_75t_R   g152(.A(new_n58_), .B(new_n142_), .C(new_n167_), .Y(\E[2] ));
endmodule


