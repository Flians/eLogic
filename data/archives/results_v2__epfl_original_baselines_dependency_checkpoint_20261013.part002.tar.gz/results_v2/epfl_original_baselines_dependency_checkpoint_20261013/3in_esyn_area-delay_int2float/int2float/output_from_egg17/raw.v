// Benchmark "/home/flynn/workplace/MIGBalance/results_v2/epfl_original_baselines_dependency_checkpoint_20261013/3in_esyn_area-delay_int2float/int2float/output_from_egg17/logic" written by ABC on Tue Oct 13 14:24:08 2026

module \/home/flynn/workplace/MIGBalance/results_v2/epfl_original_baselines_dependency_checkpoint_20261013/3in_esyn_area-delay_int2float/int2float/output_from_egg17/logic  ( 
    \B[1] , \B[2] , \B[3] , \B[4] , \B[5] , \B[6] , \B[7] , \B[8] , \B[9] ,
    \B[10] , \B[0] ,
    \M[0] , \M[1] , \M[2] , \M[3] , \E[0] , \E[1] , \E[2]   );
  input  \B[1] , \B[2] , \B[3] , \B[4] , \B[5] , \B[6] , \B[7] , \B[8] ,
    \B[9] , \B[10] , \B[0] ;
  output \M[0] , \M[1] , \M[2] , \M[3] , \E[0] , \E[1] , \E[2] ;
  wire new_n19_, new_n20_, new_n21_, new_n22_, new_n23_, new_n24_, new_n25_,
    new_n26_, new_n27_, new_n28_, new_n29_, new_n30_, new_n31_, new_n32_,
    new_n33_, new_n34_, new_n35_, new_n36_, new_n37_, new_n38_, new_n39_,
    new_n40_, new_n41_, new_n42_, new_n43_, new_n44_, new_n45_, new_n46_,
    new_n47_, new_n48_, new_n49_, new_n50_, new_n51_, new_n52_, new_n53_,
    new_n54_, new_n55_, new_n56_, new_n57_, new_n58_, new_n59_, new_n60_,
    new_n61_, new_n62_, new_n63_, new_n64_, new_n65_, new_n66_, new_n67_,
    new_n68_, new_n69_, new_n71_, new_n72_, new_n73_, new_n74_, new_n75_,
    new_n76_, new_n77_, new_n78_, new_n79_, new_n80_, new_n81_, new_n82_,
    new_n83_, new_n84_, new_n85_, new_n86_, new_n87_, new_n88_, new_n89_,
    new_n90_, new_n91_, new_n92_, new_n93_, new_n94_, new_n95_, new_n96_,
    new_n97_, new_n98_, new_n99_, new_n100_, new_n101_, new_n102_,
    new_n103_, new_n104_, new_n105_, new_n106_, new_n107_, new_n108_,
    new_n110_, new_n111_, new_n112_, new_n113_, new_n114_, new_n115_,
    new_n116_, new_n117_, new_n118_, new_n119_, new_n120_, new_n121_,
    new_n122_, new_n123_, new_n124_, new_n125_, new_n126_, new_n127_,
    new_n128_, new_n129_, new_n130_, new_n131_, new_n132_, new_n133_,
    new_n134_, new_n135_, new_n136_, new_n137_, new_n138_, new_n139_,
    new_n140_, new_n141_, new_n143_, new_n144_, new_n145_, new_n146_,
    new_n147_, new_n148_, new_n149_, new_n151_, new_n152_, new_n153_,
    new_n154_, new_n155_, new_n156_, new_n157_, new_n158_, new_n159_,
    new_n160_, new_n161_, new_n163_, new_n164_, new_n165_, new_n166_,
    new_n167_, new_n168_, new_n169_, new_n170_;
  INVx1_ASAP7_75t_R   g000(.A(\B[1] ), .Y(new_n19_));
  INVx1_ASAP7_75t_R   g001(.A(\B[2] ), .Y(new_n20_));
  INVx1_ASAP7_75t_R   g002(.A(\B[3] ), .Y(new_n21_));
  INVx1_ASAP7_75t_R   g003(.A(\B[4] ), .Y(new_n22_));
  INVx1_ASAP7_75t_R   g004(.A(\B[5] ), .Y(new_n23_));
  INVx1_ASAP7_75t_R   g005(.A(\B[6] ), .Y(new_n24_));
  INVx1_ASAP7_75t_R   g006(.A(\B[7] ), .Y(new_n25_));
  INVx1_ASAP7_75t_R   g007(.A(\B[8] ), .Y(new_n26_));
  INVx1_ASAP7_75t_R   g008(.A(\B[9] ), .Y(new_n27_));
  INVx1_ASAP7_75t_R   g009(.A(\B[10] ), .Y(new_n28_));
  INVx1_ASAP7_75t_R   g010(.A(\B[0] ), .Y(new_n29_));
  NOR2x1_ASAP7_75t_R  g011(.A(\B[8] ), .B(\B[9] ), .Y(new_n30_));
  INVx1_ASAP7_75t_R   g012(.A(new_n30_), .Y(new_n31_));
  NAND2x1_ASAP7_75t_R g013(.A(\B[2] ), .B(new_n21_), .Y(new_n32_));
  NAND2x1_ASAP7_75t_R g014(.A(new_n20_), .B(\B[3] ), .Y(new_n33_));
  AO21x1_ASAP7_75t_R  g015(.A1(new_n32_), .A2(new_n33_), .B(new_n31_), .Y(new_n34_));
  AOI21x1_ASAP7_75t_R g016(.A1(new_n28_), .A2(new_n34_), .B(\B[7] ), .Y(new_n35_));
  NOR2x1_ASAP7_75t_R  g017(.A(new_n26_), .B(new_n28_), .Y(new_n36_));
  AO21x1_ASAP7_75t_R  g018(.A1(\B[9] ), .A2(new_n36_), .B(new_n35_), .Y(new_n37_));
  AND3x1_ASAP7_75t_R  g019(.A(new_n24_), .B(\B[7] ), .C(\B[10] ), .Y(new_n38_));
  AO21x1_ASAP7_75t_R  g020(.A1(\B[6] ), .A2(new_n37_), .B(new_n38_), .Y(new_n39_));
  NOR2x1_ASAP7_75t_R  g021(.A(\B[3] ), .B(new_n22_), .Y(new_n40_));
  INVx1_ASAP7_75t_R   g022(.A(new_n40_), .Y(new_n41_));
  NAND2x1_ASAP7_75t_R g023(.A(new_n20_), .B(new_n25_), .Y(new_n42_));
  OR3x1_ASAP7_75t_R   g024(.A(new_n19_), .B(new_n23_), .C(new_n42_), .Y(new_n43_));
  INVx1_ASAP7_75t_R   g025(.A(new_n43_), .Y(new_n44_));
  NOR2x1_ASAP7_75t_R  g026(.A(\B[4] ), .B(new_n25_), .Y(new_n45_));
  OA21x2_ASAP7_75t_R  g027(.A1(new_n44_), .A2(new_n45_), .B(\B[3] ), .Y(new_n46_));
  AO21x1_ASAP7_75t_R  g028(.A1(\B[7] ), .A2(new_n40_), .B(new_n46_), .Y(new_n47_));
  AND3x1_ASAP7_75t_R  g029(.A(new_n22_), .B(\B[5] ), .C(\B[8] ), .Y(new_n48_));
  AOI21x1_ASAP7_75t_R g030(.A1(new_n26_), .A2(new_n47_), .B(new_n48_), .Y(new_n49_));
  NOR2x1_ASAP7_75t_R  g031(.A(\B[4] ), .B(new_n26_), .Y(new_n50_));
  AO21x1_ASAP7_75t_R  g032(.A1(\B[1] ), .A2(\B[4] ), .B(new_n50_), .Y(new_n51_));
  OA21x2_ASAP7_75t_R  g033(.A1(new_n19_), .A2(new_n22_), .B(new_n29_), .Y(new_n52_));
  OR3x1_ASAP7_75t_R   g034(.A(\B[6] ), .B(\B[7] ), .C(new_n52_), .Y(new_n53_));
  AO21x1_ASAP7_75t_R  g035(.A1(\B[0] ), .A2(new_n51_), .B(new_n53_), .Y(new_n54_));
  NOR2x1_ASAP7_75t_R  g036(.A(new_n22_), .B(new_n26_), .Y(new_n55_));
  INVx1_ASAP7_75t_R   g037(.A(new_n55_), .Y(new_n56_));
  AO21x1_ASAP7_75t_R  g038(.A1(new_n54_), .A2(new_n56_), .B(\B[5] ), .Y(new_n57_));
  AOI21x1_ASAP7_75t_R g039(.A1(new_n49_), .A2(new_n57_), .B(\B[9] ), .Y(new_n58_));
  NAND2x1_ASAP7_75t_R g040(.A(new_n25_), .B(new_n26_), .Y(new_n59_));
  OR3x1_ASAP7_75t_R   g041(.A(\B[1] ), .B(new_n20_), .C(new_n59_), .Y(new_n60_));
  NOR2x1_ASAP7_75t_R  g042(.A(new_n21_), .B(new_n22_), .Y(new_n61_));
  INVx1_ASAP7_75t_R   g043(.A(new_n61_), .Y(new_n62_));
  OR3x1_ASAP7_75t_R   g044(.A(new_n19_), .B(\B[2] ), .C(new_n45_), .Y(new_n63_));
  OR3x1_ASAP7_75t_R   g045(.A(new_n55_), .B(new_n61_), .C(new_n63_), .Y(new_n64_));
  AND3x1_ASAP7_75t_R  g046(.A(new_n27_), .B(new_n60_), .C(new_n64_), .Y(new_n65_));
  OR3x1_ASAP7_75t_R   g047(.A(new_n23_), .B(\B[6] ), .C(new_n65_), .Y(new_n66_));
  INVx1_ASAP7_75t_R   g048(.A(new_n66_), .Y(new_n67_));
  AND3x1_ASAP7_75t_R  g049(.A(new_n23_), .B(\B[6] ), .C(\B[9] ), .Y(new_n68_));
  OR3x1_ASAP7_75t_R   g050(.A(new_n67_), .B(new_n68_), .C(new_n58_), .Y(new_n69_));
  AO21x1_ASAP7_75t_R  g051(.A1(new_n28_), .A2(new_n69_), .B(new_n39_), .Y(\M[0] ));
  NOR2x1_ASAP7_75t_R  g052(.A(new_n24_), .B(new_n25_), .Y(new_n71_));
  OR3x1_ASAP7_75t_R   g053(.A(new_n24_), .B(new_n25_), .C(\B[9] ), .Y(new_n72_));
  OR3x1_ASAP7_75t_R   g054(.A(new_n26_), .B(new_n28_), .C(new_n72_), .Y(new_n73_));
  NOR2x1_ASAP7_75t_R  g055(.A(new_n24_), .B(\B[9] ), .Y(new_n74_));
  OR3x1_ASAP7_75t_R   g056(.A(new_n24_), .B(\B[9] ), .C(\B[4] ), .Y(new_n75_));
  OR3x1_ASAP7_75t_R   g057(.A(new_n23_), .B(\B[6] ), .C(\B[1] ), .Y(new_n76_));
  AOI21x1_ASAP7_75t_R g058(.A1(new_n75_), .A2(new_n76_), .B(\B[3] ), .Y(new_n77_));
  NAND2x1_ASAP7_75t_R g059(.A(new_n21_), .B(\B[5] ), .Y(new_n78_));
  OR3x1_ASAP7_75t_R   g060(.A(\B[3] ), .B(new_n23_), .C(\B[6] ), .Y(new_n79_));
  AOI21x1_ASAP7_75t_R g061(.A1(new_n75_), .A2(new_n79_), .B(\B[2] ), .Y(new_n80_));
  AND3x1_ASAP7_75t_R  g062(.A(\B[2] ), .B(new_n61_), .C(new_n74_), .Y(new_n81_));
  OR3x1_ASAP7_75t_R   g063(.A(new_n80_), .B(new_n81_), .C(new_n77_), .Y(new_n82_));
  AOI21x1_ASAP7_75t_R g064(.A1(new_n25_), .A2(new_n82_), .B(\B[10] ), .Y(new_n83_));
  OR3x1_ASAP7_75t_R   g065(.A(\B[8] ), .B(new_n71_), .C(new_n83_), .Y(new_n84_));
  NAND2x1_ASAP7_75t_R g066(.A(new_n22_), .B(new_n27_), .Y(new_n85_));
  AOI21x1_ASAP7_75t_R g067(.A1(new_n42_), .A2(new_n85_), .B(\B[1] ), .Y(new_n86_));
  AOI21x1_ASAP7_75t_R g068(.A1(\B[8] ), .A2(new_n27_), .B(new_n86_), .Y(new_n87_));
  NOR2x1_ASAP7_75t_R  g069(.A(new_n20_), .B(\B[0] ), .Y(new_n88_));
  OR3x1_ASAP7_75t_R   g070(.A(new_n22_), .B(\B[7] ), .C(new_n88_), .Y(new_n89_));
  NAND2x1_ASAP7_75t_R g071(.A(\B[1] ), .B(\B[2] ), .Y(new_n90_));
  AO21x1_ASAP7_75t_R  g072(.A1(\B[0] ), .A2(new_n90_), .B(new_n89_), .Y(new_n91_));
  AOI21x1_ASAP7_75t_R g073(.A1(new_n87_), .A2(new_n91_), .B(\B[6] ), .Y(new_n92_));
  NOR2x1_ASAP7_75t_R  g074(.A(\B[7] ), .B(new_n27_), .Y(new_n93_));
  AND3x1_ASAP7_75t_R  g075(.A(\B[7] ), .B(new_n30_), .C(new_n62_), .Y(new_n94_));
  OR3x1_ASAP7_75t_R   g076(.A(new_n93_), .B(new_n94_), .C(new_n92_), .Y(new_n95_));
  AO21x1_ASAP7_75t_R  g077(.A1(new_n27_), .A2(new_n50_), .B(new_n93_), .Y(new_n96_));
  AO21x1_ASAP7_75t_R  g078(.A1(new_n22_), .A2(new_n27_), .B(new_n93_), .Y(new_n97_));
  OR3x1_ASAP7_75t_R   g079(.A(new_n24_), .B(new_n30_), .C(new_n97_), .Y(new_n98_));
  OR3x1_ASAP7_75t_R   g080(.A(\B[8] ), .B(\B[9] ), .C(new_n22_), .Y(new_n99_));
  AO21x1_ASAP7_75t_R  g081(.A1(new_n25_), .A2(new_n90_), .B(new_n99_), .Y(new_n100_));
  NAND2x1_ASAP7_75t_R g082(.A(new_n22_), .B(new_n24_), .Y(new_n101_));
  OR3x1_ASAP7_75t_R   g083(.A(new_n19_), .B(new_n20_), .C(\B[7] ), .Y(new_n102_));
  OR3x1_ASAP7_75t_R   g084(.A(\B[4] ), .B(\B[6] ), .C(new_n102_), .Y(new_n103_));
  AO21x1_ASAP7_75t_R  g085(.A1(new_n100_), .A2(new_n103_), .B(new_n21_), .Y(new_n104_));
  AOI21x1_ASAP7_75t_R g086(.A1(new_n98_), .A2(new_n104_), .B(new_n23_), .Y(new_n105_));
  AO21x1_ASAP7_75t_R  g087(.A1(new_n24_), .A2(new_n96_), .B(new_n105_), .Y(new_n106_));
  AO21x1_ASAP7_75t_R  g088(.A1(new_n23_), .A2(new_n95_), .B(new_n106_), .Y(new_n107_));
  NAND2x1_ASAP7_75t_R g089(.A(new_n28_), .B(new_n107_), .Y(new_n108_));
  AND3x1_ASAP7_75t_R  g090(.A(new_n73_), .B(new_n84_), .C(new_n108_), .Y(\M[1] ));
  AO21x1_ASAP7_75t_R  g091(.A1(\B[5] ), .A2(\B[7] ), .B(new_n26_), .Y(new_n110_));
  AOI21x1_ASAP7_75t_R g092(.A1(new_n28_), .A2(new_n110_), .B(new_n27_), .Y(new_n111_));
  AND3x1_ASAP7_75t_R  g093(.A(\B[5] ), .B(new_n26_), .C(\B[9] ), .Y(new_n112_));
  OA21x2_ASAP7_75t_R  g094(.A1(new_n36_), .A2(new_n112_), .B(new_n71_), .Y(new_n113_));
  OR3x1_ASAP7_75t_R   g095(.A(\B[6] ), .B(new_n25_), .C(new_n21_), .Y(new_n114_));
  NOR2x1_ASAP7_75t_R  g096(.A(new_n24_), .B(\B[7] ), .Y(new_n115_));
  OR3x1_ASAP7_75t_R   g097(.A(new_n24_), .B(\B[7] ), .C(\B[2] ), .Y(new_n116_));
  NAND2x1_ASAP7_75t_R g098(.A(\B[4] ), .B(\B[5] ), .Y(new_n117_));
  AOI21x1_ASAP7_75t_R g099(.A1(new_n114_), .A2(new_n116_), .B(new_n117_), .Y(new_n118_));
  AOI21x1_ASAP7_75t_R g100(.A1(new_n71_), .A2(new_n117_), .B(new_n118_), .Y(new_n119_));
  NOR2x1_ASAP7_75t_R  g101(.A(new_n23_), .B(new_n24_), .Y(new_n120_));
  INVx1_ASAP7_75t_R   g102(.A(new_n120_), .Y(new_n121_));
  OR3x1_ASAP7_75t_R   g103(.A(\B[5] ), .B(new_n24_), .C(new_n20_), .Y(new_n122_));
  AOI21x1_ASAP7_75t_R g104(.A1(new_n76_), .A2(new_n122_), .B(new_n62_), .Y(new_n123_));
  AOI21x1_ASAP7_75t_R g105(.A1(new_n62_), .A2(new_n120_), .B(new_n123_), .Y(new_n124_));
  NOR2x1_ASAP7_75t_R  g106(.A(new_n19_), .B(new_n29_), .Y(new_n125_));
  INVx1_ASAP7_75t_R   g107(.A(new_n125_), .Y(new_n126_));
  OR3x1_ASAP7_75t_R   g108(.A(new_n21_), .B(new_n22_), .C(new_n125_), .Y(new_n127_));
  AO21x1_ASAP7_75t_R  g109(.A1(new_n101_), .A2(new_n127_), .B(\B[5] ), .Y(new_n128_));
  OR3x1_ASAP7_75t_R   g110(.A(\B[4] ), .B(new_n23_), .C(new_n21_), .Y(new_n129_));
  OR3x1_ASAP7_75t_R   g111(.A(\B[6] ), .B(new_n29_), .C(new_n41_), .Y(new_n130_));
  AO21x1_ASAP7_75t_R  g112(.A1(new_n129_), .A2(new_n130_), .B(new_n19_), .Y(new_n131_));
  AO21x1_ASAP7_75t_R  g113(.A1(new_n128_), .A2(new_n131_), .B(new_n20_), .Y(new_n132_));
  OR3x1_ASAP7_75t_R   g114(.A(\B[2] ), .B(new_n21_), .C(\B[6] ), .Y(new_n133_));
  AO21x1_ASAP7_75t_R  g115(.A1(new_n78_), .A2(new_n133_), .B(new_n22_), .Y(new_n134_));
  AO21x1_ASAP7_75t_R  g116(.A1(new_n132_), .A2(new_n134_), .B(\B[7] ), .Y(new_n135_));
  AO21x1_ASAP7_75t_R  g117(.A1(new_n124_), .A2(new_n135_), .B(\B[8] ), .Y(new_n136_));
  AO21x1_ASAP7_75t_R  g118(.A1(new_n119_), .A2(new_n136_), .B(\B[9] ), .Y(new_n137_));
  AND3x1_ASAP7_75t_R  g119(.A(\B[4] ), .B(\B[5] ), .C(new_n115_), .Y(new_n138_));
  AO21x1_ASAP7_75t_R  g120(.A1(new_n24_), .A2(\B[7] ), .B(new_n138_), .Y(new_n139_));
  NAND2x1_ASAP7_75t_R g121(.A(\B[8] ), .B(new_n139_), .Y(new_n140_));
  AOI21x1_ASAP7_75t_R g122(.A1(new_n137_), .A2(new_n140_), .B(\B[10] ), .Y(new_n141_));
  OR3x1_ASAP7_75t_R   g123(.A(new_n111_), .B(new_n113_), .C(new_n141_), .Y(\M[2] ));
  NAND2x1_ASAP7_75t_R g124(.A(new_n27_), .B(new_n28_), .Y(new_n143_));
  OR3x1_ASAP7_75t_R   g125(.A(new_n23_), .B(new_n24_), .C(new_n25_), .Y(new_n144_));
  OR3x1_ASAP7_75t_R   g126(.A(\B[2] ), .B(new_n56_), .C(new_n144_), .Y(new_n145_));
  INVx1_ASAP7_75t_R   g127(.A(new_n145_), .Y(new_n146_));
  AND3x1_ASAP7_75t_R  g128(.A(new_n22_), .B(new_n25_), .C(new_n26_), .Y(new_n147_));
  NOR2x1_ASAP7_75t_R  g129(.A(\B[5] ), .B(\B[6] ), .Y(new_n148_));
  AOI21x1_ASAP7_75t_R g130(.A1(new_n147_), .A2(new_n148_), .B(new_n146_), .Y(new_n149_));
  OR3x1_ASAP7_75t_R   g131(.A(\B[3] ), .B(new_n143_), .C(new_n149_), .Y(\M[3] ));
  AOI21x1_ASAP7_75t_R g132(.A1(new_n125_), .A2(new_n148_), .B(new_n138_), .Y(new_n151_));
  OR3x1_ASAP7_75t_R   g133(.A(new_n20_), .B(new_n21_), .C(new_n151_), .Y(new_n152_));
  AOI21x1_ASAP7_75t_R g134(.A1(new_n102_), .A2(new_n121_), .B(new_n21_), .Y(new_n153_));
  AO21x1_ASAP7_75t_R  g135(.A1(new_n23_), .A2(new_n25_), .B(new_n153_), .Y(new_n154_));
  AO21x1_ASAP7_75t_R  g136(.A1(\B[4] ), .A2(new_n154_), .B(new_n115_), .Y(new_n155_));
  AO21x1_ASAP7_75t_R  g137(.A1(new_n152_), .A2(new_n155_), .B(\B[8] ), .Y(new_n156_));
  OA21x2_ASAP7_75t_R  g138(.A1(new_n21_), .A2(new_n26_), .B(new_n32_), .Y(new_n157_));
  OR3x1_ASAP7_75t_R   g139(.A(new_n72_), .B(new_n117_), .C(new_n157_), .Y(new_n158_));
  OR3x1_ASAP7_75t_R   g140(.A(new_n25_), .B(new_n121_), .C(new_n26_), .Y(new_n159_));
  INVx1_ASAP7_75t_R   g141(.A(new_n159_), .Y(new_n160_));
  OA21x2_ASAP7_75t_R  g142(.A1(new_n27_), .A2(new_n160_), .B(new_n158_), .Y(new_n161_));
  AO21x1_ASAP7_75t_R  g143(.A1(new_n156_), .A2(new_n161_), .B(\B[10] ), .Y(\E[0] ));
  OR3x1_ASAP7_75t_R   g144(.A(new_n21_), .B(\B[8] ), .C(new_n126_), .Y(new_n163_));
  OR3x1_ASAP7_75t_R   g145(.A(\B[5] ), .B(\B[7] ), .C(new_n163_), .Y(new_n164_));
  AO21x1_ASAP7_75t_R  g146(.A1(new_n159_), .A2(new_n164_), .B(new_n20_), .Y(new_n165_));
  OR3x1_ASAP7_75t_R   g147(.A(new_n21_), .B(new_n26_), .C(new_n144_), .Y(new_n166_));
  AOI21x1_ASAP7_75t_R g148(.A1(new_n165_), .A2(new_n166_), .B(new_n22_), .Y(new_n167_));
  AND3x1_ASAP7_75t_R  g149(.A(\B[2] ), .B(new_n61_), .C(new_n120_), .Y(new_n168_));
  OR3x1_ASAP7_75t_R   g150(.A(new_n59_), .B(new_n148_), .C(new_n168_), .Y(new_n169_));
  INVx1_ASAP7_75t_R   g151(.A(new_n169_), .Y(new_n170_));
  OR3x1_ASAP7_75t_R   g152(.A(new_n143_), .B(new_n170_), .C(new_n167_), .Y(\E[1] ));
  OR3x1_ASAP7_75t_R   g153(.A(new_n59_), .B(new_n143_), .C(new_n168_), .Y(\E[2] ));
endmodule


