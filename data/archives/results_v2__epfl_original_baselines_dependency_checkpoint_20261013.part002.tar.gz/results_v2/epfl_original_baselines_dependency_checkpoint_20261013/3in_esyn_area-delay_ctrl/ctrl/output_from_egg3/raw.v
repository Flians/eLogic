// Benchmark "/home/flynn/workplace/MIGBalance/results_v2/epfl_original_baselines_dependency_checkpoint_20261013/3in_esyn_area-delay_ctrl/ctrl/output_from_egg3/logic" written by ABC on Tue Oct 13 13:03:33 2026

module \/home/flynn/workplace/MIGBalance/results_v2/epfl_original_baselines_dependency_checkpoint_20261013/3in_esyn_area-delay_ctrl/ctrl/output_from_egg3/logic  ( 
    \opcode[1] , \opcode[2] , \opcode[3] , \opcode[4] , \op_ext[0] ,
    \op_ext[1] , \opcode[0] ,
    \sel_reg_dst[0] , \sel_reg_dst[1] , \sel_alu_opB[0] , \sel_alu_opB[1] ,
    \alu_op[0] , \alu_op[1] , \alu_op[2] , \alu_op_ext[0] ,
    \alu_op_ext[1] , \alu_op_ext[2] , \alu_op_ext[3] , halt, reg_write,
    sel_pc_opA, sel_pc_opB, beqz, bnez, bgez, bltz, jump, Cin, invA, invB,
    sign, mem_write, sel_wb  );
  input  \opcode[1] , \opcode[2] , \opcode[3] , \opcode[4] , \op_ext[0] ,
    \op_ext[1] , \opcode[0] ;
  output \sel_reg_dst[0] , \sel_reg_dst[1] , \sel_alu_opB[0] ,
    \sel_alu_opB[1] , \alu_op[0] , \alu_op[1] , \alu_op[2] ,
    \alu_op_ext[0] , \alu_op_ext[1] , \alu_op_ext[2] , \alu_op_ext[3] ,
    halt, reg_write, sel_pc_opA, sel_pc_opB, beqz, bnez, bgez, bltz, jump,
    Cin, invA, invB, sign, mem_write, sel_wb;
  wire new_n34_, new_n35_, new_n36_, new_n37_, new_n38_, new_n39_, new_n40_,
    new_n41_, new_n42_, new_n43_, new_n44_, new_n45_, new_n46_, new_n48_,
    new_n49_, new_n50_, new_n51_, new_n52_, new_n53_, new_n55_, new_n56_,
    new_n57_, new_n59_, new_n60_, new_n61_, new_n63_, new_n64_, new_n65_,
    new_n66_, new_n67_, new_n68_, new_n69_, new_n70_, new_n72_, new_n74_,
    new_n75_, new_n76_, new_n78_, new_n80_, new_n81_, new_n82_, new_n84_,
    new_n85_, new_n87_, new_n88_, new_n89_, new_n92_, new_n93_, new_n94_,
    new_n99_, new_n100_, new_n103_, new_n105_, new_n107_, new_n108_,
    new_n109_, new_n111_, new_n112_, new_n113_, new_n115_, new_n117_,
    new_n119_;
  INVx1_ASAP7_75t_R   g00(.A(\opcode[1] ), .Y(new_n34_));
  INVx1_ASAP7_75t_R   g01(.A(\opcode[2] ), .Y(new_n35_));
  INVx1_ASAP7_75t_R   g02(.A(\opcode[3] ), .Y(new_n36_));
  INVx1_ASAP7_75t_R   g03(.A(\opcode[4] ), .Y(new_n37_));
  INVx1_ASAP7_75t_R   g04(.A(\op_ext[1] ), .Y(new_n38_));
  INVx1_ASAP7_75t_R   g05(.A(\opcode[0] ), .Y(new_n39_));
  NOR2x1_ASAP7_75t_R  g06(.A(\opcode[3] ), .B(\opcode[4] ), .Y(new_n40_));
  INVx1_ASAP7_75t_R   g07(.A(new_n40_), .Y(new_n41_));
  OR3x1_ASAP7_75t_R   g08(.A(\opcode[3] ), .B(\opcode[4] ), .C(new_n34_), .Y(new_n42_));
  NOR2x1_ASAP7_75t_R  g09(.A(new_n36_), .B(new_n37_), .Y(new_n43_));
  INVx1_ASAP7_75t_R   g10(.A(new_n43_), .Y(new_n44_));
  AOI21x1_ASAP7_75t_R g11(.A1(new_n42_), .A2(new_n44_), .B(new_n35_), .Y(new_n45_));
  NAND2x1_ASAP7_75t_R g12(.A(new_n34_), .B(new_n39_), .Y(new_n46_));
  AO21x1_ASAP7_75t_R  g13(.A1(new_n43_), .A2(new_n46_), .B(new_n45_), .Y(\sel_reg_dst[0] ));
  AND2x2_ASAP7_75t_R  g14(.A(\opcode[2] ), .B(new_n42_), .Y(new_n48_));
  AND3x1_ASAP7_75t_R  g15(.A(\opcode[3] ), .B(new_n39_), .C(\opcode[4] ), .Y(new_n49_));
  NOR2x1_ASAP7_75t_R  g16(.A(\opcode[1] ), .B(new_n49_), .Y(new_n50_));
  NOR2x1_ASAP7_75t_R  g17(.A(\opcode[3] ), .B(new_n37_), .Y(new_n51_));
  INVx1_ASAP7_75t_R   g18(.A(new_n51_), .Y(new_n52_));
  AO21x1_ASAP7_75t_R  g19(.A1(\opcode[1] ), .A2(new_n52_), .B(new_n50_), .Y(new_n53_));
  AOI21x1_ASAP7_75t_R g20(.A1(new_n35_), .A2(new_n53_), .B(new_n48_), .Y(\sel_reg_dst[1] ));
  AO21x1_ASAP7_75t_R  g21(.A1(new_n39_), .A2(new_n51_), .B(new_n34_), .Y(new_n55_));
  AOI21x1_ASAP7_75t_R g22(.A1(\opcode[3] ), .A2(new_n37_), .B(new_n55_), .Y(new_n56_));
  OR3x1_ASAP7_75t_R   g23(.A(\opcode[2] ), .B(new_n50_), .C(new_n56_), .Y(new_n57_));
  INVx1_ASAP7_75t_R   g24(.A(new_n57_), .Y(\sel_alu_opB[0] ));
  NOR2x1_ASAP7_75t_R  g25(.A(\opcode[1] ), .B(\opcode[2] ), .Y(new_n59_));
  AO21x1_ASAP7_75t_R  g26(.A1(new_n34_), .A2(new_n35_), .B(new_n36_), .Y(new_n60_));
  OR3x1_ASAP7_75t_R   g27(.A(new_n36_), .B(new_n37_), .C(new_n39_), .Y(new_n61_));
  AND3x1_ASAP7_75t_R  g28(.A(new_n41_), .B(new_n60_), .C(new_n61_), .Y(\sel_alu_opB[1] ));
  NOR2x1_ASAP7_75t_R  g29(.A(new_n35_), .B(new_n51_), .Y(new_n63_));
  AO21x1_ASAP7_75t_R  g30(.A1(\opcode[2] ), .A2(new_n39_), .B(new_n63_), .Y(new_n64_));
  NOR2x1_ASAP7_75t_R  g31(.A(new_n37_), .B(\op_ext[0] ), .Y(new_n65_));
  AO21x1_ASAP7_75t_R  g32(.A1(\opcode[4] ), .A2(new_n38_), .B(new_n36_), .Y(new_n66_));
  AO21x1_ASAP7_75t_R  g33(.A1(\op_ext[1] ), .A2(new_n65_), .B(new_n66_), .Y(new_n67_));
  NOR2x1_ASAP7_75t_R  g34(.A(new_n39_), .B(new_n67_), .Y(new_n68_));
  AO21x1_ASAP7_75t_R  g35(.A1(\op_ext[0] ), .A2(new_n49_), .B(new_n68_), .Y(new_n69_));
  NAND2x1_ASAP7_75t_R g36(.A(\opcode[1] ), .B(new_n69_), .Y(new_n70_));
  AOI21x1_ASAP7_75t_R g37(.A1(new_n35_), .A2(new_n70_), .B(new_n64_), .Y(\alu_op[0] ));
  AO21x1_ASAP7_75t_R  g38(.A1(\opcode[2] ), .A2(new_n52_), .B(new_n34_), .Y(new_n72_));
  AOI21x1_ASAP7_75t_R g39(.A1(new_n35_), .A2(new_n66_), .B(new_n72_), .Y(\alu_op[1] ));
  NAND2x1_ASAP7_75t_R g40(.A(\opcode[1] ), .B(\opcode[0] ), .Y(new_n74_));
  AND3x1_ASAP7_75t_R  g41(.A(\opcode[3] ), .B(\opcode[4] ), .C(new_n74_), .Y(new_n75_));
  AO21x1_ASAP7_75t_R  g42(.A1(\opcode[2] ), .A2(new_n44_), .B(new_n40_), .Y(new_n76_));
  AOI21x1_ASAP7_75t_R g43(.A1(new_n35_), .A2(new_n75_), .B(new_n76_), .Y(\alu_op[2] ));
  AOI21x1_ASAP7_75t_R g44(.A1(new_n42_), .A2(new_n61_), .B(new_n35_), .Y(new_n78_));
  AO21x1_ASAP7_75t_R  g45(.A1(new_n49_), .A2(new_n59_), .B(new_n78_), .Y(\alu_op_ext[0] ));
  NOR2x1_ASAP7_75t_R  g46(.A(\opcode[2] ), .B(new_n55_), .Y(new_n80_));
  AND3x1_ASAP7_75t_R  g47(.A(\opcode[2] ), .B(new_n44_), .C(new_n41_), .Y(new_n81_));
  OR3x1_ASAP7_75t_R   g48(.A(new_n34_), .B(new_n81_), .C(new_n80_), .Y(new_n82_));
  INVx1_ASAP7_75t_R   g49(.A(new_n82_), .Y(\alu_op_ext[1] ));
  AND3x1_ASAP7_75t_R  g50(.A(new_n34_), .B(new_n35_), .C(new_n44_), .Y(new_n84_));
  OR3x1_ASAP7_75t_R   g51(.A(new_n48_), .B(new_n84_), .C(new_n80_), .Y(new_n85_));
  INVx1_ASAP7_75t_R   g52(.A(new_n85_), .Y(\alu_op_ext[2] ));
  AO21x1_ASAP7_75t_R  g53(.A1(new_n34_), .A2(\opcode[4] ), .B(new_n36_), .Y(new_n87_));
  AO21x1_ASAP7_75t_R  g54(.A1(\opcode[1] ), .A2(new_n39_), .B(new_n52_), .Y(new_n88_));
  AND3x1_ASAP7_75t_R  g55(.A(new_n35_), .B(new_n88_), .C(new_n87_), .Y(new_n89_));
  NOR2x1_ASAP7_75t_R  g56(.A(new_n63_), .B(new_n89_), .Y(\alu_op_ext[3] ));
  AND3x1_ASAP7_75t_R  g57(.A(new_n39_), .B(new_n40_), .C(new_n59_), .Y(halt));
  AO21x1_ASAP7_75t_R  g58(.A1(\opcode[1] ), .A2(new_n36_), .B(\opcode[4] ), .Y(new_n92_));
  AO21x1_ASAP7_75t_R  g59(.A1(\opcode[4] ), .A2(new_n46_), .B(\opcode[3] ), .Y(new_n93_));
  AND2x2_ASAP7_75t_R  g60(.A(new_n35_), .B(new_n93_), .Y(new_n94_));
  AO21x1_ASAP7_75t_R  g61(.A1(\opcode[2] ), .A2(new_n92_), .B(new_n94_), .Y(reg_write));
  AND3x1_ASAP7_75t_R  g62(.A(new_n36_), .B(new_n37_), .C(\opcode[2] ), .Y(jump));
  AND3x1_ASAP7_75t_R  g63(.A(\opcode[2] ), .B(new_n40_), .C(\opcode[0] ), .Y(sel_pc_opA));
  AND3x1_ASAP7_75t_R  g64(.A(\opcode[2] ), .B(new_n39_), .C(new_n40_), .Y(sel_pc_opB));
  OR3x1_ASAP7_75t_R   g65(.A(new_n36_), .B(\opcode[4] ), .C(\opcode[1] ), .Y(new_n99_));
  INVx1_ASAP7_75t_R   g66(.A(new_n99_), .Y(new_n100_));
  AND3x1_ASAP7_75t_R  g67(.A(\opcode[2] ), .B(new_n39_), .C(new_n100_), .Y(beqz));
  AND3x1_ASAP7_75t_R  g68(.A(\opcode[0] ), .B(new_n100_), .C(\opcode[2] ), .Y(bnez));
  OR3x1_ASAP7_75t_R   g69(.A(new_n36_), .B(\opcode[4] ), .C(new_n35_), .Y(new_n103_));
  NOR2x1_ASAP7_75t_R  g70(.A(new_n74_), .B(new_n103_), .Y(bgez));
  OR3x1_ASAP7_75t_R   g71(.A(new_n34_), .B(\opcode[0] ), .C(new_n103_), .Y(new_n105_));
  INVx1_ASAP7_75t_R   g72(.A(new_n105_), .Y(bltz));
  OA21x2_ASAP7_75t_R  g73(.A1(new_n39_), .A2(new_n99_), .B(new_n35_), .Y(new_n107_));
  OR3x1_ASAP7_75t_R   g74(.A(new_n36_), .B(new_n65_), .C(new_n74_), .Y(new_n108_));
  NOR2x1_ASAP7_75t_R  g75(.A(new_n35_), .B(new_n75_), .Y(new_n109_));
  AOI21x1_ASAP7_75t_R g76(.A1(new_n107_), .A2(new_n108_), .B(new_n109_), .Y(Cin));
  NAND2x1_ASAP7_75t_R g77(.A(new_n35_), .B(\opcode[0] ), .Y(new_n111_));
  AND3x1_ASAP7_75t_R  g78(.A(\opcode[1] ), .B(\op_ext[0] ), .C(new_n38_), .Y(new_n112_));
  AOI21x1_ASAP7_75t_R g79(.A1(new_n43_), .A2(new_n112_), .B(new_n100_), .Y(new_n113_));
  NOR2x1_ASAP7_75t_R  g80(.A(new_n111_), .B(new_n113_), .Y(invA));
  OR3x1_ASAP7_75t_R   g81(.A(new_n34_), .B(new_n39_), .C(new_n67_), .Y(new_n115_));
  AOI21x1_ASAP7_75t_R g82(.A1(new_n35_), .A2(new_n115_), .B(new_n109_), .Y(invB));
  NAND2x1_ASAP7_75t_R g83(.A(new_n46_), .B(new_n74_), .Y(new_n117_));
  AND3x1_ASAP7_75t_R  g84(.A(new_n35_), .B(new_n51_), .C(new_n117_), .Y(mem_write));
  OR3x1_ASAP7_75t_R   g85(.A(\opcode[1] ), .B(new_n52_), .C(new_n111_), .Y(new_n119_));
  INVx1_ASAP7_75t_R   g86(.A(new_n119_), .Y(sel_wb));
  assign              sign = 1'b1;
endmodule


