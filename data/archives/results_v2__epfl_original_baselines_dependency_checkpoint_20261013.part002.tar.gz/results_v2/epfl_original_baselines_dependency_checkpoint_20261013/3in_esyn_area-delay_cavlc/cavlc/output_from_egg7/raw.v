// Benchmark "/home/flynn/workplace/MIGBalance/results_v2/epfl_original_baselines_dependency_checkpoint_20261013/3in_esyn_area-delay_cavlc/cavlc/output_from_egg7/logic" written by ABC on Tue Oct 13 13:01:02 2026

module \/home/flynn/workplace/MIGBalance/results_v2/epfl_original_baselines_dependency_checkpoint_20261013/3in_esyn_area-delay_cavlc/cavlc/output_from_egg7/logic  ( 
    \totalcoeffs[1] , \totalcoeffs[2] , \totalcoeffs[3] , \totalcoeffs[4] ,
    \ctable[0] , \ctable[1] , \ctable[2] , \trailingones[0] ,
    \trailingones[1] , \totalcoeffs[0] ,
    \coeff_token[0] , \coeff_token[1] , \coeff_token[2] , \coeff_token[3] ,
    \coeff_token[4] , \coeff_token[5] , \ctoken_len[0] , \ctoken_len[1] ,
    \ctoken_len[2] , \ctoken_len[3] , \ctoken_len[4]   );
  input  \totalcoeffs[1] , \totalcoeffs[2] , \totalcoeffs[3] ,
    \totalcoeffs[4] , \ctable[0] , \ctable[1] , \ctable[2] ,
    \trailingones[0] , \trailingones[1] , \totalcoeffs[0] ;
  output \coeff_token[0] , \coeff_token[1] , \coeff_token[2] ,
    \coeff_token[3] , \coeff_token[4] , \coeff_token[5] , \ctoken_len[0] ,
    \ctoken_len[1] , \ctoken_len[2] , \ctoken_len[3] , \ctoken_len[4] ;
  wire new_n22_, new_n23_, new_n24_, new_n25_, new_n26_, new_n27_, new_n28_,
    new_n29_, new_n30_, new_n31_, new_n32_, new_n33_, new_n34_, new_n35_,
    new_n36_, new_n37_, new_n38_, new_n39_, new_n40_, new_n41_, new_n42_,
    new_n43_, new_n44_, new_n45_, new_n46_, new_n47_, new_n48_, new_n49_,
    new_n50_, new_n51_, new_n52_, new_n53_, new_n54_, new_n55_, new_n56_,
    new_n57_, new_n58_, new_n59_, new_n60_, new_n61_, new_n62_, new_n63_,
    new_n64_, new_n65_, new_n66_, new_n67_, new_n68_, new_n69_, new_n70_,
    new_n71_, new_n72_, new_n73_, new_n74_, new_n75_, new_n76_, new_n77_,
    new_n78_, new_n79_, new_n80_, new_n81_, new_n82_, new_n83_, new_n84_,
    new_n85_, new_n86_, new_n87_, new_n88_, new_n89_, new_n90_, new_n91_,
    new_n92_, new_n93_, new_n94_, new_n95_, new_n96_, new_n97_, new_n98_,
    new_n99_, new_n100_, new_n101_, new_n102_, new_n103_, new_n104_,
    new_n105_, new_n106_, new_n107_, new_n108_, new_n109_, new_n110_,
    new_n111_, new_n112_, new_n113_, new_n114_, new_n115_, new_n116_,
    new_n117_, new_n118_, new_n119_, new_n120_, new_n121_, new_n122_,
    new_n123_, new_n124_, new_n126_, new_n127_, new_n128_, new_n129_,
    new_n130_, new_n131_, new_n132_, new_n133_, new_n134_, new_n135_,
    new_n136_, new_n137_, new_n138_, new_n139_, new_n140_, new_n141_,
    new_n142_, new_n143_, new_n144_, new_n145_, new_n146_, new_n147_,
    new_n148_, new_n149_, new_n150_, new_n151_, new_n152_, new_n153_,
    new_n154_, new_n155_, new_n156_, new_n157_, new_n158_, new_n159_,
    new_n160_, new_n161_, new_n162_, new_n163_, new_n164_, new_n165_,
    new_n166_, new_n167_, new_n168_, new_n169_, new_n170_, new_n171_,
    new_n172_, new_n173_, new_n174_, new_n175_, new_n176_, new_n177_,
    new_n178_, new_n179_, new_n180_, new_n181_, new_n182_, new_n183_,
    new_n184_, new_n185_, new_n186_, new_n187_, new_n188_, new_n189_,
    new_n190_, new_n191_, new_n192_, new_n193_, new_n194_, new_n195_,
    new_n196_, new_n197_, new_n198_, new_n199_, new_n200_, new_n201_,
    new_n202_, new_n203_, new_n204_, new_n205_, new_n206_, new_n208_,
    new_n209_, new_n210_, new_n211_, new_n212_, new_n213_, new_n214_,
    new_n215_, new_n216_, new_n217_, new_n218_, new_n219_, new_n220_,
    new_n221_, new_n222_, new_n223_, new_n224_, new_n225_, new_n226_,
    new_n227_, new_n228_, new_n229_, new_n230_, new_n231_, new_n232_,
    new_n233_, new_n234_, new_n235_, new_n236_, new_n237_, new_n238_,
    new_n239_, new_n240_, new_n241_, new_n242_, new_n243_, new_n244_,
    new_n245_, new_n246_, new_n247_, new_n248_, new_n249_, new_n250_,
    new_n251_, new_n252_, new_n253_, new_n254_, new_n255_, new_n256_,
    new_n257_, new_n258_, new_n259_, new_n260_, new_n261_, new_n262_,
    new_n263_, new_n264_, new_n265_, new_n266_, new_n267_, new_n268_,
    new_n269_, new_n270_, new_n271_, new_n272_, new_n273_, new_n275_,
    new_n276_, new_n277_, new_n278_, new_n279_, new_n280_, new_n281_,
    new_n282_, new_n283_, new_n284_, new_n285_, new_n286_, new_n287_,
    new_n288_, new_n289_, new_n290_, new_n291_, new_n292_, new_n293_,
    new_n294_, new_n295_, new_n296_, new_n297_, new_n298_, new_n299_,
    new_n300_, new_n301_, new_n302_, new_n303_, new_n304_, new_n305_,
    new_n306_, new_n307_, new_n308_, new_n309_, new_n310_, new_n311_,
    new_n312_, new_n313_, new_n314_, new_n315_, new_n316_, new_n317_,
    new_n319_, new_n320_, new_n321_, new_n322_, new_n324_, new_n325_,
    new_n327_, new_n328_, new_n329_, new_n330_, new_n331_, new_n332_,
    new_n333_, new_n334_, new_n335_, new_n336_, new_n337_, new_n338_,
    new_n339_, new_n340_, new_n341_, new_n342_, new_n343_, new_n344_,
    new_n345_, new_n346_, new_n347_, new_n348_, new_n349_, new_n350_,
    new_n351_, new_n352_, new_n353_, new_n354_, new_n355_, new_n356_,
    new_n357_, new_n358_, new_n359_, new_n360_, new_n361_, new_n362_,
    new_n363_, new_n364_, new_n365_, new_n366_, new_n367_, new_n368_,
    new_n369_, new_n370_, new_n371_, new_n372_, new_n373_, new_n374_,
    new_n375_, new_n376_, new_n378_, new_n379_, new_n380_, new_n381_,
    new_n382_, new_n383_, new_n384_, new_n385_, new_n386_, new_n387_,
    new_n388_, new_n389_, new_n390_, new_n391_, new_n392_, new_n393_,
    new_n394_, new_n395_, new_n396_, new_n397_, new_n398_, new_n399_,
    new_n400_, new_n401_, new_n402_, new_n403_, new_n404_, new_n405_,
    new_n406_, new_n407_, new_n408_, new_n409_, new_n410_, new_n411_,
    new_n412_, new_n413_, new_n414_, new_n415_, new_n416_, new_n417_,
    new_n418_, new_n419_, new_n420_, new_n421_, new_n422_, new_n423_,
    new_n424_, new_n426_, new_n427_, new_n428_, new_n429_, new_n430_,
    new_n431_, new_n432_, new_n433_, new_n434_, new_n435_, new_n436_,
    new_n437_, new_n438_, new_n439_, new_n440_, new_n441_, new_n442_,
    new_n443_, new_n444_, new_n445_, new_n446_, new_n447_, new_n448_,
    new_n449_, new_n450_, new_n451_, new_n452_, new_n453_, new_n454_,
    new_n455_, new_n456_, new_n457_, new_n459_, new_n460_, new_n461_,
    new_n462_, new_n463_, new_n464_, new_n465_, new_n466_, new_n467_,
    new_n468_, new_n469_, new_n470_, new_n471_, new_n472_, new_n473_,
    new_n474_, new_n475_, new_n476_, new_n477_, new_n479_, new_n480_,
    new_n481_;
  INVx1_ASAP7_75t_R   g000(.A(\totalcoeffs[1] ), .Y(new_n22_));
  INVx1_ASAP7_75t_R   g001(.A(\totalcoeffs[2] ), .Y(new_n23_));
  INVx1_ASAP7_75t_R   g002(.A(\totalcoeffs[3] ), .Y(new_n24_));
  INVx1_ASAP7_75t_R   g003(.A(\totalcoeffs[4] ), .Y(new_n25_));
  INVx1_ASAP7_75t_R   g004(.A(\ctable[0] ), .Y(new_n26_));
  INVx1_ASAP7_75t_R   g005(.A(\ctable[1] ), .Y(new_n27_));
  INVx1_ASAP7_75t_R   g006(.A(\ctable[2] ), .Y(new_n28_));
  INVx1_ASAP7_75t_R   g007(.A(\trailingones[0] ), .Y(new_n29_));
  INVx1_ASAP7_75t_R   g008(.A(\trailingones[1] ), .Y(new_n30_));
  INVx1_ASAP7_75t_R   g009(.A(\totalcoeffs[0] ), .Y(new_n31_));
  OR3x1_ASAP7_75t_R   g010(.A(\totalcoeffs[2] ), .B(\totalcoeffs[0] ), .C(\ctable[2] ), .Y(new_n32_));
  NOR2x1_ASAP7_75t_R  g011(.A(\totalcoeffs[1] ), .B(\totalcoeffs[3] ), .Y(new_n33_));
  INVx1_ASAP7_75t_R   g012(.A(new_n33_), .Y(new_n34_));
  NAND2x1_ASAP7_75t_R g013(.A(new_n27_), .B(\trailingones[0] ), .Y(new_n35_));
  AND2x2_ASAP7_75t_R  g014(.A(\ctable[0] ), .B(new_n35_), .Y(new_n36_));
  NOR2x1_ASAP7_75t_R  g015(.A(\ctable[1] ), .B(\trailingones[1] ), .Y(new_n37_));
  INVx1_ASAP7_75t_R   g016(.A(new_n37_), .Y(new_n38_));
  AO21x1_ASAP7_75t_R  g017(.A1(\totalcoeffs[4] ), .A2(\trailingones[0] ), .B(new_n37_), .Y(new_n39_));
  NOR2x1_ASAP7_75t_R  g018(.A(new_n26_), .B(new_n27_), .Y(new_n40_));
  NOR2x1_ASAP7_75t_R  g019(.A(new_n27_), .B(\trailingones[1] ), .Y(new_n41_));
  INVx1_ASAP7_75t_R   g020(.A(new_n41_), .Y(new_n42_));
  OA21x2_ASAP7_75t_R  g021(.A1(new_n25_), .A2(new_n30_), .B(new_n42_), .Y(new_n43_));
  OR3x1_ASAP7_75t_R   g022(.A(\trailingones[0] ), .B(new_n40_), .C(new_n43_), .Y(new_n44_));
  INVx1_ASAP7_75t_R   g023(.A(new_n44_), .Y(new_n45_));
  AOI21x1_ASAP7_75t_R g024(.A1(new_n36_), .A2(new_n39_), .B(new_n45_), .Y(new_n46_));
  OR3x1_ASAP7_75t_R   g025(.A(new_n32_), .B(new_n34_), .C(new_n46_), .Y(new_n47_));
  INVx1_ASAP7_75t_R   g026(.A(new_n47_), .Y(new_n48_));
  AND3x1_ASAP7_75t_R  g027(.A(new_n26_), .B(\ctable[2] ), .C(\trailingones[0] ), .Y(new_n49_));
  AO21x1_ASAP7_75t_R  g028(.A1(new_n28_), .A2(\trailingones[1] ), .B(new_n49_), .Y(new_n50_));
  NOR2x1_ASAP7_75t_R  g029(.A(\ctable[0] ), .B(\trailingones[1] ), .Y(new_n51_));
  INVx1_ASAP7_75t_R   g030(.A(new_n51_), .Y(new_n52_));
  OA21x2_ASAP7_75t_R  g031(.A1(new_n22_), .A2(\ctable[2] ), .B(new_n51_), .Y(new_n53_));
  AOI21x1_ASAP7_75t_R g032(.A1(\totalcoeffs[1] ), .A2(new_n50_), .B(new_n53_), .Y(new_n54_));
  OR3x1_ASAP7_75t_R   g033(.A(\totalcoeffs[2] ), .B(new_n31_), .C(new_n54_), .Y(new_n55_));
  INVx1_ASAP7_75t_R   g034(.A(new_n55_), .Y(new_n56_));
  NAND2x1_ASAP7_75t_R g035(.A(new_n22_), .B(new_n31_), .Y(new_n57_));
  NAND2x1_ASAP7_75t_R g036(.A(\totalcoeffs[2] ), .B(new_n30_), .Y(new_n58_));
  NOR2x1_ASAP7_75t_R  g037(.A(new_n57_), .B(new_n58_), .Y(new_n59_));
  AO21x1_ASAP7_75t_R  g038(.A1(new_n49_), .A2(new_n59_), .B(new_n56_), .Y(new_n60_));
  NOR2x1_ASAP7_75t_R  g039(.A(\trailingones[1] ), .B(new_n31_), .Y(new_n61_));
  INVx1_ASAP7_75t_R   g040(.A(new_n61_), .Y(new_n62_));
  NOR2x1_ASAP7_75t_R  g041(.A(\totalcoeffs[1] ), .B(new_n61_), .Y(new_n63_));
  NOR2x1_ASAP7_75t_R  g042(.A(new_n22_), .B(\trailingones[1] ), .Y(new_n64_));
  INVx1_ASAP7_75t_R   g043(.A(new_n64_), .Y(new_n65_));
  OR3x1_ASAP7_75t_R   g044(.A(\ctable[2] ), .B(new_n64_), .C(new_n63_), .Y(new_n66_));
  NAND2x1_ASAP7_75t_R g045(.A(\trailingones[1] ), .B(new_n31_), .Y(new_n67_));
  AO21x1_ASAP7_75t_R  g046(.A1(\trailingones[1] ), .A2(new_n31_), .B(new_n22_), .Y(new_n68_));
  INVx1_ASAP7_75t_R   g047(.A(new_n68_), .Y(new_n69_));
  NAND2x1_ASAP7_75t_R g048(.A(new_n24_), .B(new_n26_), .Y(new_n70_));
  NOR2x1_ASAP7_75t_R  g049(.A(\totalcoeffs[1] ), .B(new_n30_), .Y(new_n71_));
  INVx1_ASAP7_75t_R   g050(.A(new_n71_), .Y(new_n72_));
  OR3x1_ASAP7_75t_R   g051(.A(new_n70_), .B(new_n71_), .C(new_n69_), .Y(new_n73_));
  AO21x1_ASAP7_75t_R  g052(.A1(new_n66_), .A2(new_n73_), .B(\totalcoeffs[2] ), .Y(new_n74_));
  NOR2x1_ASAP7_75t_R  g053(.A(new_n24_), .B(new_n31_), .Y(new_n75_));
  NOR2x1_ASAP7_75t_R  g054(.A(\totalcoeffs[2] ), .B(\totalcoeffs[3] ), .Y(new_n76_));
  INVx1_ASAP7_75t_R   g055(.A(new_n76_), .Y(new_n77_));
  AO21x1_ASAP7_75t_R  g056(.A1(\trailingones[1] ), .A2(new_n77_), .B(new_n75_), .Y(new_n78_));
  AND2x2_ASAP7_75t_R  g057(.A(new_n22_), .B(new_n78_), .Y(new_n79_));
  AOI21x1_ASAP7_75t_R g058(.A1(\totalcoeffs[1] ), .A2(new_n24_), .B(new_n79_), .Y(new_n80_));
  AO21x1_ASAP7_75t_R  g059(.A1(new_n23_), .A2(new_n26_), .B(\totalcoeffs[0] ), .Y(new_n81_));
  NOR2x1_ASAP7_75t_R  g060(.A(new_n22_), .B(new_n23_), .Y(new_n82_));
  INVx1_ASAP7_75t_R   g061(.A(new_n82_), .Y(new_n83_));
  AO21x1_ASAP7_75t_R  g062(.A1(new_n81_), .A2(new_n83_), .B(\trailingones[1] ), .Y(new_n84_));
  AO21x1_ASAP7_75t_R  g063(.A1(new_n80_), .A2(new_n84_), .B(\ctable[2] ), .Y(new_n85_));
  AOI21x1_ASAP7_75t_R g064(.A1(new_n74_), .A2(new_n85_), .B(\trailingones[0] ), .Y(new_n86_));
  AO21x1_ASAP7_75t_R  g065(.A1(new_n24_), .A2(new_n60_), .B(new_n86_), .Y(new_n87_));
  NOR2x1_ASAP7_75t_R  g066(.A(new_n23_), .B(new_n30_), .Y(new_n88_));
  OR3x1_ASAP7_75t_R   g067(.A(new_n22_), .B(\trailingones[1] ), .C(\totalcoeffs[2] ), .Y(new_n89_));
  AO21x1_ASAP7_75t_R  g068(.A1(new_n23_), .A2(new_n64_), .B(new_n88_), .Y(new_n90_));
  NOR2x1_ASAP7_75t_R  g069(.A(\totalcoeffs[3] ), .B(\totalcoeffs[0] ), .Y(new_n91_));
  AND3x1_ASAP7_75t_R  g070(.A(\ctable[1] ), .B(new_n91_), .C(new_n90_), .Y(new_n92_));
  AO21x1_ASAP7_75t_R  g071(.A1(new_n30_), .A2(\totalcoeffs[0] ), .B(\totalcoeffs[2] ), .Y(new_n93_));
  AO21x1_ASAP7_75t_R  g072(.A1(new_n24_), .A2(new_n69_), .B(new_n93_), .Y(new_n94_));
  AOI21x1_ASAP7_75t_R g073(.A1(new_n27_), .A2(new_n93_), .B(new_n26_), .Y(new_n95_));
  AO21x1_ASAP7_75t_R  g074(.A1(new_n94_), .A2(new_n95_), .B(new_n92_), .Y(new_n96_));
  NOR2x1_ASAP7_75t_R  g075(.A(\totalcoeffs[1] ), .B(\trailingones[1] ), .Y(new_n97_));
  INVx1_ASAP7_75t_R   g076(.A(new_n97_), .Y(new_n98_));
  OR3x1_ASAP7_75t_R   g077(.A(\totalcoeffs[2] ), .B(\totalcoeffs[3] ), .C(\totalcoeffs[0] ), .Y(new_n99_));
  OR3x1_ASAP7_75t_R   g078(.A(\trailingones[0] ), .B(new_n98_), .C(new_n99_), .Y(new_n100_));
  INVx1_ASAP7_75t_R   g079(.A(new_n100_), .Y(new_n101_));
  NAND2x1_ASAP7_75t_R g080(.A(\totalcoeffs[2] ), .B(new_n24_), .Y(new_n102_));
  OR3x1_ASAP7_75t_R   g081(.A(\totalcoeffs[1] ), .B(new_n30_), .C(new_n102_), .Y(new_n103_));
  NAND2x1_ASAP7_75t_R g082(.A(\totalcoeffs[1] ), .B(new_n29_), .Y(new_n104_));
  AOI21x1_ASAP7_75t_R g083(.A1(new_n103_), .A2(new_n104_), .B(\totalcoeffs[0] ), .Y(new_n105_));
  AO21x1_ASAP7_75t_R  g084(.A1(new_n23_), .A2(\ctable[1] ), .B(new_n24_), .Y(new_n106_));
  AO21x1_ASAP7_75t_R  g085(.A1(new_n97_), .A2(new_n106_), .B(new_n88_), .Y(new_n107_));
  AO21x1_ASAP7_75t_R  g086(.A1(new_n29_), .A2(new_n107_), .B(new_n105_), .Y(new_n108_));
  AO21x1_ASAP7_75t_R  g087(.A1(new_n26_), .A2(new_n108_), .B(new_n101_), .Y(new_n109_));
  AOI21x1_ASAP7_75t_R g088(.A1(\trailingones[0] ), .A2(new_n96_), .B(new_n109_), .Y(new_n110_));
  OR3x1_ASAP7_75t_R   g089(.A(\totalcoeffs[2] ), .B(\totalcoeffs[0] ), .C(new_n72_), .Y(new_n111_));
  AO21x1_ASAP7_75t_R  g090(.A1(new_n26_), .A2(new_n111_), .B(new_n27_), .Y(new_n112_));
  AO21x1_ASAP7_75t_R  g091(.A1(\trailingones[1] ), .A2(new_n31_), .B(new_n61_), .Y(new_n113_));
  INVx1_ASAP7_75t_R   g092(.A(new_n113_), .Y(new_n114_));
  NOR2x1_ASAP7_75t_R  g093(.A(new_n22_), .B(new_n26_), .Y(new_n115_));
  INVx1_ASAP7_75t_R   g094(.A(new_n115_), .Y(new_n116_));
  OR3x1_ASAP7_75t_R   g095(.A(new_n23_), .B(new_n116_), .C(new_n113_), .Y(new_n117_));
  AO21x1_ASAP7_75t_R  g096(.A1(new_n112_), .A2(new_n117_), .B(new_n29_), .Y(new_n118_));
  AO21x1_ASAP7_75t_R  g097(.A1(new_n22_), .A2(new_n67_), .B(\trailingones[0] ), .Y(new_n119_));
  OR3x1_ASAP7_75t_R   g098(.A(\totalcoeffs[1] ), .B(new_n23_), .C(new_n62_), .Y(new_n120_));
  AO21x1_ASAP7_75t_R  g099(.A1(new_n119_), .A2(new_n120_), .B(\ctable[0] ), .Y(new_n121_));
  AO21x1_ASAP7_75t_R  g100(.A1(new_n118_), .A2(new_n121_), .B(new_n24_), .Y(new_n122_));
  AOI21x1_ASAP7_75t_R g101(.A1(new_n110_), .A2(new_n122_), .B(\ctable[2] ), .Y(new_n123_));
  AO21x1_ASAP7_75t_R  g102(.A1(new_n27_), .A2(new_n87_), .B(new_n123_), .Y(new_n124_));
  AO21x1_ASAP7_75t_R  g103(.A1(new_n25_), .A2(new_n124_), .B(new_n48_), .Y(\coeff_token[0] ));
  NOR2x1_ASAP7_75t_R  g104(.A(new_n27_), .B(new_n30_), .Y(new_n126_));
  INVx1_ASAP7_75t_R   g105(.A(new_n126_), .Y(new_n127_));
  NOR2x1_ASAP7_75t_R  g106(.A(new_n26_), .B(\trailingones[0] ), .Y(new_n128_));
  AO21x1_ASAP7_75t_R  g107(.A1(\totalcoeffs[4] ), .A2(\trailingones[0] ), .B(new_n128_), .Y(new_n129_));
  AND3x1_ASAP7_75t_R  g108(.A(new_n27_), .B(new_n30_), .C(new_n129_), .Y(new_n130_));
  AO21x1_ASAP7_75t_R  g109(.A1(\totalcoeffs[4] ), .A2(new_n126_), .B(new_n130_), .Y(new_n131_));
  OR3x1_ASAP7_75t_R   g110(.A(\totalcoeffs[1] ), .B(\totalcoeffs[0] ), .C(\totalcoeffs[2] ), .Y(new_n132_));
  INVx1_ASAP7_75t_R   g111(.A(new_n132_), .Y(new_n133_));
  NAND2x1_ASAP7_75t_R g112(.A(new_n26_), .B(\trailingones[0] ), .Y(new_n134_));
  AND2x2_ASAP7_75t_R  g113(.A(new_n127_), .B(new_n134_), .Y(new_n135_));
  AO21x1_ASAP7_75t_R  g114(.A1(new_n127_), .A2(new_n134_), .B(\totalcoeffs[0] ), .Y(new_n136_));
  NOR2x1_ASAP7_75t_R  g115(.A(new_n27_), .B(new_n29_), .Y(new_n137_));
  AND3x1_ASAP7_75t_R  g116(.A(new_n26_), .B(new_n30_), .C(new_n29_), .Y(new_n138_));
  AOI21x1_ASAP7_75t_R g117(.A1(\trailingones[1] ), .A2(new_n137_), .B(new_n138_), .Y(new_n139_));
  AOI21x1_ASAP7_75t_R g118(.A1(new_n136_), .A2(new_n139_), .B(new_n23_), .Y(new_n140_));
  NOR2x1_ASAP7_75t_R  g119(.A(\totalcoeffs[2] ), .B(\trailingones[0] ), .Y(new_n141_));
  AND3x1_ASAP7_75t_R  g120(.A(new_n30_), .B(new_n31_), .C(new_n141_), .Y(new_n142_));
  NAND2x1_ASAP7_75t_R g121(.A(\trailingones[0] ), .B(\totalcoeffs[0] ), .Y(new_n143_));
  OR3x1_ASAP7_75t_R   g122(.A(new_n29_), .B(new_n31_), .C(new_n30_), .Y(new_n144_));
  INVx1_ASAP7_75t_R   g123(.A(new_n144_), .Y(new_n145_));
  AO21x1_ASAP7_75t_R  g124(.A1(\totalcoeffs[2] ), .A2(new_n145_), .B(new_n142_), .Y(new_n146_));
  AO21x1_ASAP7_75t_R  g125(.A1(\ctable[0] ), .A2(new_n146_), .B(new_n140_), .Y(new_n147_));
  NAND2x1_ASAP7_75t_R g126(.A(new_n22_), .B(new_n147_), .Y(new_n148_));
  OA21x2_ASAP7_75t_R  g127(.A1(new_n35_), .A2(new_n58_), .B(new_n148_), .Y(new_n149_));
  NAND2x1_ASAP7_75t_R g128(.A(\ctable[1] ), .B(new_n31_), .Y(new_n150_));
  AO21x1_ASAP7_75t_R  g129(.A1(new_n23_), .A2(new_n150_), .B(new_n134_), .Y(new_n151_));
  NAND2x1_ASAP7_75t_R g130(.A(new_n27_), .B(new_n29_), .Y(new_n152_));
  AO21x1_ASAP7_75t_R  g131(.A1(new_n151_), .A2(new_n152_), .B(\trailingones[1] ), .Y(new_n153_));
  OR3x1_ASAP7_75t_R   g132(.A(new_n31_), .B(new_n137_), .C(new_n135_), .Y(new_n154_));
  NOR2x1_ASAP7_75t_R  g133(.A(\trailingones[0] ), .B(new_n30_), .Y(new_n155_));
  NOR2x1_ASAP7_75t_R  g134(.A(new_n26_), .B(\totalcoeffs[0] ), .Y(new_n156_));
  NAND2x1_ASAP7_75t_R g135(.A(new_n155_), .B(new_n156_), .Y(new_n157_));
  AO21x1_ASAP7_75t_R  g136(.A1(new_n154_), .A2(new_n157_), .B(\totalcoeffs[2] ), .Y(new_n158_));
  AO21x1_ASAP7_75t_R  g137(.A1(new_n153_), .A2(new_n158_), .B(new_n22_), .Y(new_n159_));
  AOI21x1_ASAP7_75t_R g138(.A1(new_n149_), .A2(new_n159_), .B(\totalcoeffs[4] ), .Y(new_n160_));
  AO21x1_ASAP7_75t_R  g139(.A1(new_n131_), .A2(new_n133_), .B(new_n160_), .Y(new_n161_));
  NAND2x1_ASAP7_75t_R g140(.A(new_n24_), .B(new_n161_), .Y(new_n162_));
  OR3x1_ASAP7_75t_R   g141(.A(\totalcoeffs[2] ), .B(\trailingones[0] ), .C(new_n26_), .Y(new_n163_));
  INVx1_ASAP7_75t_R   g142(.A(new_n163_), .Y(new_n164_));
  NAND2x1_ASAP7_75t_R g143(.A(new_n24_), .B(new_n29_), .Y(new_n165_));
  AND2x2_ASAP7_75t_R  g144(.A(new_n134_), .B(new_n165_), .Y(new_n166_));
  AO21x1_ASAP7_75t_R  g145(.A1(\totalcoeffs[0] ), .A2(new_n166_), .B(new_n164_), .Y(new_n167_));
  NAND2x1_ASAP7_75t_R g146(.A(new_n23_), .B(\trailingones[0] ), .Y(new_n168_));
  AND3x1_ASAP7_75t_R  g147(.A(new_n23_), .B(\trailingones[0] ), .C(\totalcoeffs[0] ), .Y(new_n169_));
  NOR2x1_ASAP7_75t_R  g148(.A(\ctable[0] ), .B(new_n31_), .Y(new_n170_));
  OR3x1_ASAP7_75t_R   g149(.A(new_n156_), .B(new_n170_), .C(new_n169_), .Y(new_n171_));
  OA21x2_ASAP7_75t_R  g150(.A1(new_n24_), .A2(new_n29_), .B(new_n23_), .Y(new_n172_));
  NOR2x1_ASAP7_75t_R  g151(.A(\totalcoeffs[0] ), .B(new_n172_), .Y(new_n173_));
  AO21x1_ASAP7_75t_R  g152(.A1(\totalcoeffs[1] ), .A2(new_n171_), .B(new_n173_), .Y(new_n174_));
  AO21x1_ASAP7_75t_R  g153(.A1(new_n22_), .A2(new_n167_), .B(new_n174_), .Y(new_n175_));
  NOR2x1_ASAP7_75t_R  g154(.A(\totalcoeffs[1] ), .B(new_n29_), .Y(new_n176_));
  INVx1_ASAP7_75t_R   g155(.A(new_n176_), .Y(new_n177_));
  OR3x1_ASAP7_75t_R   g156(.A(\totalcoeffs[1] ), .B(new_n29_), .C(new_n27_), .Y(new_n178_));
  NOR2x1_ASAP7_75t_R  g157(.A(\totalcoeffs[1] ), .B(\trailingones[0] ), .Y(new_n179_));
  OAI21x1_ASAP7_75t_R g158(.A1(\totalcoeffs[2] ), .A2(new_n179_), .B(new_n178_), .Y(new_n180_));
  NOR2x1_ASAP7_75t_R  g159(.A(\totalcoeffs[1] ), .B(\ctable[1] ), .Y(new_n181_));
  AO21x1_ASAP7_75t_R  g160(.A1(\totalcoeffs[1] ), .A2(\totalcoeffs[0] ), .B(new_n181_), .Y(new_n182_));
  NOR2x1_ASAP7_75t_R  g161(.A(new_n29_), .B(\totalcoeffs[0] ), .Y(new_n183_));
  OR3x1_ASAP7_75t_R   g162(.A(\totalcoeffs[2] ), .B(new_n183_), .C(new_n182_), .Y(new_n184_));
  INVx1_ASAP7_75t_R   g163(.A(new_n184_), .Y(new_n185_));
  AO21x1_ASAP7_75t_R  g164(.A1(\totalcoeffs[3] ), .A2(new_n180_), .B(new_n185_), .Y(new_n186_));
  AO21x1_ASAP7_75t_R  g165(.A1(new_n26_), .A2(new_n186_), .B(\trailingones[1] ), .Y(new_n187_));
  AOI21x1_ASAP7_75t_R g166(.A1(new_n27_), .A2(new_n175_), .B(new_n187_), .Y(new_n188_));
  AND3x1_ASAP7_75t_R  g167(.A(\totalcoeffs[1] ), .B(\totalcoeffs[2] ), .C(\totalcoeffs[3] ), .Y(new_n189_));
  AO21x1_ASAP7_75t_R  g168(.A1(new_n128_), .A2(new_n189_), .B(new_n30_), .Y(new_n190_));
  NOR2x1_ASAP7_75t_R  g169(.A(\totalcoeffs[1] ), .B(new_n24_), .Y(new_n191_));
  INVx1_ASAP7_75t_R   g170(.A(new_n191_), .Y(new_n192_));
  AO21x1_ASAP7_75t_R  g171(.A1(new_n141_), .A2(new_n191_), .B(new_n115_), .Y(new_n193_));
  OA21x2_ASAP7_75t_R  g172(.A1(\ctable[0] ), .A2(new_n189_), .B(new_n77_), .Y(new_n194_));
  AO21x1_ASAP7_75t_R  g173(.A1(\totalcoeffs[0] ), .A2(new_n193_), .B(new_n194_), .Y(new_n195_));
  AOI21x1_ASAP7_75t_R g174(.A1(\ctable[1] ), .A2(new_n195_), .B(new_n190_), .Y(new_n196_));
  OR3x1_ASAP7_75t_R   g175(.A(\totalcoeffs[4] ), .B(new_n196_), .C(new_n188_), .Y(new_n197_));
  AO21x1_ASAP7_75t_R  g176(.A1(new_n162_), .A2(new_n197_), .B(\ctable[2] ), .Y(new_n198_));
  OR3x1_ASAP7_75t_R   g177(.A(\totalcoeffs[3] ), .B(\ctable[0] ), .C(\ctable[1] ), .Y(new_n199_));
  INVx1_ASAP7_75t_R   g178(.A(new_n199_), .Y(new_n200_));
  AOI21x1_ASAP7_75t_R g179(.A1(\totalcoeffs[1] ), .A2(\totalcoeffs[0] ), .B(new_n93_), .Y(new_n201_));
  AND2x2_ASAP7_75t_R  g180(.A(\totalcoeffs[2] ), .B(new_n57_), .Y(new_n202_));
  OR3x1_ASAP7_75t_R   g181(.A(\trailingones[0] ), .B(new_n202_), .C(new_n201_), .Y(new_n203_));
  OAI21x1_ASAP7_75t_R g182(.A1(new_n65_), .A2(new_n168_), .B(new_n203_), .Y(new_n204_));
  AOI21x1_ASAP7_75t_R g183(.A1(\ctable[2] ), .A2(new_n204_), .B(new_n59_), .Y(new_n205_));
  OR3x1_ASAP7_75t_R   g184(.A(\totalcoeffs[4] ), .B(new_n199_), .C(new_n205_), .Y(new_n206_));
  NAND2x1_ASAP7_75t_R g185(.A(new_n198_), .B(new_n206_), .Y(\coeff_token[1] ));
  NOR2x1_ASAP7_75t_R  g186(.A(\ctable[0] ), .B(new_n88_), .Y(new_n208_));
  NOR2x1_ASAP7_75t_R  g187(.A(\trailingones[0] ), .B(\trailingones[1] ), .Y(new_n209_));
  INVx1_ASAP7_75t_R   g188(.A(new_n209_), .Y(new_n210_));
  AND3x1_ASAP7_75t_R  g189(.A(\ctable[0] ), .B(new_n210_), .C(new_n144_), .Y(new_n211_));
  OR3x1_ASAP7_75t_R   g190(.A(new_n22_), .B(new_n208_), .C(new_n211_), .Y(new_n212_));
  NOR2x1_ASAP7_75t_R  g191(.A(new_n29_), .B(new_n30_), .Y(new_n213_));
  AO21x1_ASAP7_75t_R  g192(.A1(\trailingones[0] ), .A2(\trailingones[1] ), .B(new_n209_), .Y(new_n214_));
  INVx1_ASAP7_75t_R   g193(.A(new_n214_), .Y(new_n215_));
  AO21x1_ASAP7_75t_R  g194(.A1(new_n98_), .A2(new_n214_), .B(new_n23_), .Y(new_n216_));
  AO21x1_ASAP7_75t_R  g195(.A1(new_n212_), .A2(new_n216_), .B(\totalcoeffs[3] ), .Y(new_n217_));
  NOR2x1_ASAP7_75t_R  g196(.A(new_n26_), .B(new_n191_), .Y(new_n218_));
  OR3x1_ASAP7_75t_R   g197(.A(\totalcoeffs[2] ), .B(new_n210_), .C(new_n218_), .Y(new_n219_));
  OR3x1_ASAP7_75t_R   g198(.A(new_n30_), .B(new_n76_), .C(new_n177_), .Y(new_n220_));
  AO21x1_ASAP7_75t_R  g199(.A1(new_n219_), .A2(new_n220_), .B(new_n31_), .Y(new_n221_));
  AO21x1_ASAP7_75t_R  g200(.A1(new_n217_), .A2(new_n221_), .B(\ctable[1] ), .Y(new_n222_));
  NOR2x1_ASAP7_75t_R  g201(.A(new_n22_), .B(new_n30_), .Y(new_n223_));
  INVx1_ASAP7_75t_R   g202(.A(new_n223_), .Y(new_n224_));
  AO21x1_ASAP7_75t_R  g203(.A1(\totalcoeffs[2] ), .A2(new_n223_), .B(new_n176_), .Y(new_n225_));
  AND3x1_ASAP7_75t_R  g204(.A(new_n29_), .B(new_n30_), .C(\totalcoeffs[2] ), .Y(new_n226_));
  AO21x1_ASAP7_75t_R  g205(.A1(\trailingones[0] ), .A2(new_n58_), .B(new_n226_), .Y(new_n227_));
  AO21x1_ASAP7_75t_R  g206(.A1(\ctable[1] ), .A2(new_n225_), .B(new_n227_), .Y(new_n228_));
  AO21x1_ASAP7_75t_R  g207(.A1(new_n22_), .A2(\trailingones[1] ), .B(new_n27_), .Y(new_n229_));
  AO21x1_ASAP7_75t_R  g208(.A1(new_n65_), .A2(new_n229_), .B(new_n29_), .Y(new_n230_));
  AO21x1_ASAP7_75t_R  g209(.A1(\totalcoeffs[1] ), .A2(\trailingones[1] ), .B(new_n97_), .Y(new_n231_));
  INVx1_ASAP7_75t_R   g210(.A(new_n231_), .Y(new_n232_));
  OR3x1_ASAP7_75t_R   g211(.A(\totalcoeffs[3] ), .B(\trailingones[0] ), .C(new_n232_), .Y(new_n233_));
  AOI21x1_ASAP7_75t_R g212(.A1(new_n230_), .A2(new_n233_), .B(\totalcoeffs[2] ), .Y(new_n234_));
  AOI21x1_ASAP7_75t_R g213(.A1(\totalcoeffs[3] ), .A2(new_n228_), .B(new_n234_), .Y(new_n235_));
  OR3x1_ASAP7_75t_R   g214(.A(\ctable[0] ), .B(new_n31_), .C(new_n235_), .Y(new_n236_));
  AO21x1_ASAP7_75t_R  g215(.A1(new_n222_), .A2(new_n236_), .B(\totalcoeffs[4] ), .Y(new_n237_));
  NAND2x1_ASAP7_75t_R g216(.A(\totalcoeffs[2] ), .B(new_n26_), .Y(new_n238_));
  AOI21x1_ASAP7_75t_R g217(.A1(\totalcoeffs[3] ), .A2(new_n238_), .B(new_n29_), .Y(new_n239_));
  AO21x1_ASAP7_75t_R  g218(.A1(new_n23_), .A2(\trailingones[0] ), .B(new_n24_), .Y(new_n240_));
  AO21x1_ASAP7_75t_R  g219(.A1(\ctable[0] ), .A2(new_n240_), .B(new_n239_), .Y(new_n241_));
  NOR2x1_ASAP7_75t_R  g220(.A(\ctable[0] ), .B(new_n27_), .Y(new_n242_));
  OR3x1_ASAP7_75t_R   g221(.A(\ctable[0] ), .B(new_n27_), .C(\totalcoeffs[3] ), .Y(new_n243_));
  AND3x1_ASAP7_75t_R  g222(.A(new_n24_), .B(new_n242_), .C(new_n179_), .Y(new_n244_));
  AO21x1_ASAP7_75t_R  g223(.A1(\totalcoeffs[1] ), .A2(new_n241_), .B(new_n244_), .Y(new_n245_));
  NAND2x1_ASAP7_75t_R g224(.A(\totalcoeffs[3] ), .B(new_n29_), .Y(new_n246_));
  NOR2x1_ASAP7_75t_R  g225(.A(new_n24_), .B(\trailingones[1] ), .Y(new_n247_));
  AO21x1_ASAP7_75t_R  g226(.A1(\totalcoeffs[3] ), .A2(new_n30_), .B(\ctable[1] ), .Y(new_n248_));
  AOI21x1_ASAP7_75t_R g227(.A1(new_n65_), .A2(new_n246_), .B(new_n248_), .Y(new_n249_));
  AND3x1_ASAP7_75t_R  g228(.A(new_n24_), .B(\trailingones[1] ), .C(\totalcoeffs[1] ), .Y(new_n250_));
  NOR2x1_ASAP7_75t_R  g229(.A(new_n27_), .B(\trailingones[0] ), .Y(new_n251_));
  INVx1_ASAP7_75t_R   g230(.A(new_n251_), .Y(new_n252_));
  AO21x1_ASAP7_75t_R  g231(.A1(new_n250_), .A2(new_n251_), .B(\totalcoeffs[4] ), .Y(new_n253_));
  AOI21x1_ASAP7_75t_R g232(.A1(\totalcoeffs[2] ), .A2(new_n35_), .B(new_n22_), .Y(new_n254_));
  OR3x1_ASAP7_75t_R   g233(.A(new_n26_), .B(new_n172_), .C(new_n254_), .Y(new_n255_));
  INVx1_ASAP7_75t_R   g234(.A(new_n255_), .Y(new_n256_));
  OR3x1_ASAP7_75t_R   g235(.A(new_n249_), .B(new_n253_), .C(new_n256_), .Y(new_n257_));
  AO21x1_ASAP7_75t_R  g236(.A1(\totalcoeffs[1] ), .A2(\trailingones[0] ), .B(new_n27_), .Y(new_n258_));
  AOI21x1_ASAP7_75t_R g237(.A1(new_n30_), .A2(new_n258_), .B(\totalcoeffs[2] ), .Y(new_n259_));
  AO21x1_ASAP7_75t_R  g238(.A1(new_n29_), .A2(new_n71_), .B(new_n259_), .Y(new_n260_));
  AO21x1_ASAP7_75t_R  g239(.A1(\totalcoeffs[3] ), .A2(new_n260_), .B(new_n257_), .Y(new_n261_));
  AOI21x1_ASAP7_75t_R g240(.A1(new_n30_), .A2(new_n245_), .B(new_n261_), .Y(new_n262_));
  OA21x2_ASAP7_75t_R  g241(.A1(new_n213_), .A2(new_n251_), .B(new_n26_), .Y(new_n263_));
  OR3x1_ASAP7_75t_R   g242(.A(\totalcoeffs[1] ), .B(\totalcoeffs[3] ), .C(\totalcoeffs[2] ), .Y(new_n264_));
  OA21x2_ASAP7_75t_R  g243(.A1(new_n263_), .A2(new_n264_), .B(\totalcoeffs[4] ), .Y(new_n265_));
  OR3x1_ASAP7_75t_R   g244(.A(\totalcoeffs[0] ), .B(new_n265_), .C(new_n262_), .Y(new_n266_));
  AOI21x1_ASAP7_75t_R g245(.A1(new_n237_), .A2(new_n266_), .B(\ctable[2] ), .Y(new_n267_));
  AO21x1_ASAP7_75t_R  g246(.A1(\ctable[2] ), .A2(new_n213_), .B(new_n31_), .Y(new_n268_));
  AND3x1_ASAP7_75t_R  g247(.A(\totalcoeffs[1] ), .B(new_n67_), .C(new_n268_), .Y(new_n269_));
  AO21x1_ASAP7_75t_R  g248(.A1(new_n61_), .A2(new_n179_), .B(new_n269_), .Y(new_n270_));
  NOR2x1_ASAP7_75t_R  g249(.A(\ctable[0] ), .B(\ctable[1] ), .Y(new_n271_));
  INVx1_ASAP7_75t_R   g250(.A(new_n271_), .Y(new_n272_));
  AND3x1_ASAP7_75t_R  g251(.A(new_n25_), .B(new_n76_), .C(new_n271_), .Y(new_n273_));
  AO21x1_ASAP7_75t_R  g252(.A1(new_n270_), .A2(new_n273_), .B(new_n267_), .Y(\coeff_token[2] ));
  AOI21x1_ASAP7_75t_R g253(.A1(new_n24_), .A2(new_n252_), .B(new_n36_), .Y(new_n275_));
  AND3x1_ASAP7_75t_R  g254(.A(\ctable[0] ), .B(\trailingones[1] ), .C(\trailingones[0] ), .Y(new_n276_));
  AO21x1_ASAP7_75t_R  g255(.A1(new_n27_), .A2(new_n276_), .B(new_n138_), .Y(new_n277_));
  AO21x1_ASAP7_75t_R  g256(.A1(\totalcoeffs[2] ), .A2(new_n277_), .B(new_n275_), .Y(new_n278_));
  AO21x1_ASAP7_75t_R  g257(.A1(\ctable[1] ), .A2(new_n77_), .B(new_n247_), .Y(new_n279_));
  AND3x1_ASAP7_75t_R  g258(.A(new_n26_), .B(\ctable[1] ), .C(\totalcoeffs[2] ), .Y(new_n280_));
  AO21x1_ASAP7_75t_R  g259(.A1(new_n22_), .A2(new_n279_), .B(new_n280_), .Y(new_n281_));
  AO21x1_ASAP7_75t_R  g260(.A1(\totalcoeffs[1] ), .A2(new_n278_), .B(new_n281_), .Y(new_n282_));
  NAND2x1_ASAP7_75t_R g261(.A(new_n24_), .B(\totalcoeffs[4] ), .Y(new_n283_));
  OR3x1_ASAP7_75t_R   g262(.A(\totalcoeffs[1] ), .B(\totalcoeffs[2] ), .C(new_n283_), .Y(new_n284_));
  NOR2x1_ASAP7_75t_R  g263(.A(\ctable[0] ), .B(new_n213_), .Y(new_n285_));
  NOR2x1_ASAP7_75t_R  g264(.A(new_n284_), .B(new_n285_), .Y(new_n286_));
  OA21x2_ASAP7_75t_R  g265(.A1(new_n40_), .A2(new_n271_), .B(new_n286_), .Y(new_n287_));
  AO21x1_ASAP7_75t_R  g266(.A1(new_n25_), .A2(new_n282_), .B(new_n287_), .Y(new_n288_));
  AO21x1_ASAP7_75t_R  g267(.A1(\ctable[0] ), .A2(new_n155_), .B(\totalcoeffs[3] ), .Y(new_n289_));
  NOR2x1_ASAP7_75t_R  g268(.A(new_n24_), .B(\ctable[0] ), .Y(new_n290_));
  INVx1_ASAP7_75t_R   g269(.A(new_n290_), .Y(new_n291_));
  AOI21x1_ASAP7_75t_R g270(.A1(new_n27_), .A2(new_n246_), .B(new_n290_), .Y(new_n292_));
  AOI21x1_ASAP7_75t_R g271(.A1(new_n23_), .A2(new_n289_), .B(new_n292_), .Y(new_n293_));
  NOR2x1_ASAP7_75t_R  g272(.A(\totalcoeffs[2] ), .B(new_n26_), .Y(new_n294_));
  OR3x1_ASAP7_75t_R   g273(.A(\totalcoeffs[2] ), .B(new_n26_), .C(new_n29_), .Y(new_n295_));
  AO21x1_ASAP7_75t_R  g274(.A1(new_n134_), .A2(new_n165_), .B(new_n23_), .Y(new_n296_));
  AO21x1_ASAP7_75t_R  g275(.A1(new_n295_), .A2(new_n296_), .B(\trailingones[1] ), .Y(new_n297_));
  AO21x1_ASAP7_75t_R  g276(.A1(new_n293_), .A2(new_n297_), .B(new_n22_), .Y(new_n298_));
  OR3x1_ASAP7_75t_R   g277(.A(\totalcoeffs[1] ), .B(\ctable[1] ), .C(new_n163_), .Y(new_n299_));
  AO21x1_ASAP7_75t_R  g278(.A1(new_n243_), .A2(new_n299_), .B(\trailingones[1] ), .Y(new_n300_));
  AO21x1_ASAP7_75t_R  g279(.A1(new_n298_), .A2(new_n300_), .B(new_n31_), .Y(new_n301_));
  AO21x1_ASAP7_75t_R  g280(.A1(new_n27_), .A2(new_n29_), .B(new_n51_), .Y(new_n302_));
  NAND2x1_ASAP7_75t_R g281(.A(\ctable[0] ), .B(\trailingones[0] ), .Y(new_n303_));
  AO21x1_ASAP7_75t_R  g282(.A1(\ctable[0] ), .A2(\trailingones[1] ), .B(\ctable[1] ), .Y(new_n304_));
  AOI21x1_ASAP7_75t_R g283(.A1(new_n224_), .A2(new_n303_), .B(new_n304_), .Y(new_n305_));
  AO21x1_ASAP7_75t_R  g284(.A1(new_n23_), .A2(new_n302_), .B(new_n305_), .Y(new_n306_));
  AND3x1_ASAP7_75t_R  g285(.A(new_n26_), .B(\ctable[1] ), .C(new_n30_), .Y(new_n307_));
  AND3x1_ASAP7_75t_R  g286(.A(\totalcoeffs[1] ), .B(\trailingones[0] ), .C(new_n307_), .Y(new_n308_));
  AO21x1_ASAP7_75t_R  g287(.A1(\totalcoeffs[3] ), .A2(new_n306_), .B(new_n308_), .Y(new_n309_));
  NOR2x1_ASAP7_75t_R  g288(.A(new_n24_), .B(\ctable[1] ), .Y(new_n310_));
  AND3x1_ASAP7_75t_R  g289(.A(\totalcoeffs[3] ), .B(new_n27_), .C(\totalcoeffs[2] ), .Y(new_n311_));
  AO21x1_ASAP7_75t_R  g290(.A1(new_n77_), .A2(new_n242_), .B(new_n311_), .Y(new_n312_));
  OA21x2_ASAP7_75t_R  g291(.A1(new_n307_), .A2(new_n310_), .B(new_n29_), .Y(new_n313_));
  AO21x1_ASAP7_75t_R  g292(.A1(\trailingones[1] ), .A2(new_n312_), .B(new_n313_), .Y(new_n314_));
  AOI21x1_ASAP7_75t_R g293(.A1(new_n22_), .A2(new_n314_), .B(new_n309_), .Y(new_n315_));
  AOI21x1_ASAP7_75t_R g294(.A1(new_n301_), .A2(new_n315_), .B(\totalcoeffs[4] ), .Y(new_n316_));
  AOI21x1_ASAP7_75t_R g295(.A1(new_n31_), .A2(new_n288_), .B(new_n316_), .Y(new_n317_));
  NOR2x1_ASAP7_75t_R  g296(.A(\ctable[2] ), .B(new_n317_), .Y(\coeff_token[3] ));
  OR3x1_ASAP7_75t_R   g297(.A(new_n26_), .B(new_n27_), .C(\ctable[2] ), .Y(new_n319_));
  NAND2x1_ASAP7_75t_R g298(.A(\totalcoeffs[3] ), .B(new_n25_), .Y(new_n320_));
  AOI21x1_ASAP7_75t_R g299(.A1(new_n283_), .A2(new_n320_), .B(new_n132_), .Y(new_n321_));
  AOI21x1_ASAP7_75t_R g300(.A1(new_n25_), .A2(new_n202_), .B(new_n321_), .Y(new_n322_));
  NOR2x1_ASAP7_75t_R  g301(.A(new_n319_), .B(new_n322_), .Y(\coeff_token[4] ));
  OR3x1_ASAP7_75t_R   g302(.A(new_n24_), .B(\totalcoeffs[4] ), .C(new_n133_), .Y(new_n324_));
  OR3x1_ASAP7_75t_R   g303(.A(\totalcoeffs[3] ), .B(new_n25_), .C(new_n132_), .Y(new_n325_));
  AOI21x1_ASAP7_75t_R g304(.A1(new_n324_), .A2(new_n325_), .B(new_n319_), .Y(\coeff_token[5] ));
  NOR2x1_ASAP7_75t_R  g305(.A(new_n23_), .B(\totalcoeffs[0] ), .Y(new_n327_));
  INVx1_ASAP7_75t_R   g306(.A(new_n327_), .Y(new_n328_));
  OR3x1_ASAP7_75t_R   g307(.A(new_n23_), .B(\totalcoeffs[0] ), .C(new_n51_), .Y(new_n329_));
  NAND2x1_ASAP7_75t_R g308(.A(new_n22_), .B(new_n26_), .Y(new_n330_));
  AO21x1_ASAP7_75t_R  g309(.A1(\totalcoeffs[2] ), .A2(new_n330_), .B(new_n38_), .Y(new_n331_));
  OR3x1_ASAP7_75t_R   g310(.A(new_n22_), .B(new_n30_), .C(new_n26_), .Y(new_n332_));
  AO21x1_ASAP7_75t_R  g311(.A1(new_n331_), .A2(new_n332_), .B(new_n31_), .Y(new_n333_));
  AO21x1_ASAP7_75t_R  g312(.A1(new_n329_), .A2(new_n333_), .B(new_n29_), .Y(new_n334_));
  AND3x1_ASAP7_75t_R  g313(.A(\totalcoeffs[2] ), .B(new_n31_), .C(\trailingones[1] ), .Y(new_n335_));
  AO21x1_ASAP7_75t_R  g314(.A1(new_n29_), .A2(new_n97_), .B(new_n335_), .Y(new_n336_));
  AO21x1_ASAP7_75t_R  g315(.A1(\totalcoeffs[2] ), .A2(\trailingones[0] ), .B(new_n141_), .Y(new_n337_));
  AND3x1_ASAP7_75t_R  g316(.A(\ctable[1] ), .B(new_n214_), .C(new_n337_), .Y(new_n338_));
  AOI21x1_ASAP7_75t_R g317(.A1(\ctable[0] ), .A2(new_n336_), .B(new_n338_), .Y(new_n339_));
  AO21x1_ASAP7_75t_R  g318(.A1(new_n334_), .A2(new_n339_), .B(\ctable[2] ), .Y(new_n340_));
  OA21x2_ASAP7_75t_R  g319(.A1(new_n22_), .A2(new_n144_), .B(new_n210_), .Y(new_n341_));
  OR3x1_ASAP7_75t_R   g320(.A(\totalcoeffs[2] ), .B(new_n28_), .C(new_n341_), .Y(new_n342_));
  OA21x2_ASAP7_75t_R  g321(.A1(new_n28_), .A2(\trailingones[1] ), .B(\trailingones[0] ), .Y(new_n343_));
  OR3x1_ASAP7_75t_R   g322(.A(\totalcoeffs[1] ), .B(new_n23_), .C(new_n343_), .Y(new_n344_));
  AO21x1_ASAP7_75t_R  g323(.A1(new_n89_), .A2(new_n344_), .B(\totalcoeffs[0] ), .Y(new_n345_));
  AO21x1_ASAP7_75t_R  g324(.A1(new_n342_), .A2(new_n345_), .B(new_n272_), .Y(new_n346_));
  AOI21x1_ASAP7_75t_R g325(.A1(new_n340_), .A2(new_n346_), .B(\totalcoeffs[3] ), .Y(new_n347_));
  OR3x1_ASAP7_75t_R   g326(.A(new_n22_), .B(\trailingones[1] ), .C(new_n170_), .Y(new_n348_));
  AOI21x1_ASAP7_75t_R g327(.A1(new_n29_), .A2(new_n31_), .B(new_n348_), .Y(new_n349_));
  AND3x1_ASAP7_75t_R  g328(.A(\totalcoeffs[1] ), .B(new_n29_), .C(new_n328_), .Y(new_n350_));
  AND3x1_ASAP7_75t_R  g329(.A(\ctable[1] ), .B(\trailingones[0] ), .C(\totalcoeffs[0] ), .Y(new_n351_));
  AO21x1_ASAP7_75t_R  g330(.A1(new_n23_), .A2(new_n351_), .B(new_n350_), .Y(new_n352_));
  AO21x1_ASAP7_75t_R  g331(.A1(\trailingones[1] ), .A2(new_n352_), .B(new_n349_), .Y(new_n353_));
  AO21x1_ASAP7_75t_R  g332(.A1(new_n29_), .A2(new_n30_), .B(\totalcoeffs[1] ), .Y(new_n354_));
  AO21x1_ASAP7_75t_R  g333(.A1(new_n22_), .A2(new_n210_), .B(new_n31_), .Y(new_n355_));
  INVx1_ASAP7_75t_R   g334(.A(new_n355_), .Y(new_n356_));
  OR3x1_ASAP7_75t_R   g335(.A(\ctable[1] ), .B(\totalcoeffs[0] ), .C(new_n179_), .Y(new_n357_));
  AOI21x1_ASAP7_75t_R g336(.A1(new_n83_), .A2(new_n357_), .B(new_n231_), .Y(new_n358_));
  AO21x1_ASAP7_75t_R  g337(.A1(new_n65_), .A2(new_n356_), .B(new_n358_), .Y(new_n359_));
  AO21x1_ASAP7_75t_R  g338(.A1(new_n26_), .A2(new_n359_), .B(new_n353_), .Y(new_n360_));
  NOR2x1_ASAP7_75t_R  g339(.A(\totalcoeffs[2] ), .B(\trailingones[1] ), .Y(new_n361_));
  NAND2x1_ASAP7_75t_R g340(.A(new_n303_), .B(new_n361_), .Y(new_n362_));
  AO21x1_ASAP7_75t_R  g341(.A1(new_n31_), .A2(new_n252_), .B(new_n362_), .Y(new_n363_));
  OR3x1_ASAP7_75t_R   g342(.A(new_n23_), .B(new_n29_), .C(new_n67_), .Y(new_n364_));
  AOI21x1_ASAP7_75t_R g343(.A1(new_n363_), .A2(new_n364_), .B(\totalcoeffs[1] ), .Y(new_n365_));
  AOI21x1_ASAP7_75t_R g344(.A1(new_n27_), .A2(new_n238_), .B(new_n67_), .Y(new_n366_));
  AO21x1_ASAP7_75t_R  g345(.A1(new_n114_), .A2(new_n294_), .B(new_n366_), .Y(new_n367_));
  AO21x1_ASAP7_75t_R  g346(.A1(new_n29_), .A2(new_n30_), .B(new_n23_), .Y(new_n368_));
  AOI21x1_ASAP7_75t_R g347(.A1(new_n144_), .A2(new_n368_), .B(new_n27_), .Y(new_n369_));
  AO21x1_ASAP7_75t_R  g348(.A1(new_n29_), .A2(new_n367_), .B(new_n369_), .Y(new_n370_));
  AO21x1_ASAP7_75t_R  g349(.A1(\totalcoeffs[1] ), .A2(new_n370_), .B(new_n365_), .Y(new_n371_));
  AO21x1_ASAP7_75t_R  g350(.A1(\totalcoeffs[3] ), .A2(new_n360_), .B(new_n371_), .Y(new_n372_));
  AO21x1_ASAP7_75t_R  g351(.A1(new_n28_), .A2(new_n372_), .B(new_n347_), .Y(new_n373_));
  OR3x1_ASAP7_75t_R   g352(.A(new_n25_), .B(new_n57_), .C(new_n77_), .Y(new_n374_));
  INVx1_ASAP7_75t_R   g353(.A(new_n374_), .Y(new_n375_));
  OA21x2_ASAP7_75t_R  g354(.A1(new_n40_), .A2(new_n375_), .B(new_n28_), .Y(new_n376_));
  AOI21x1_ASAP7_75t_R g355(.A1(new_n25_), .A2(new_n373_), .B(new_n376_), .Y(\ctoken_len[0] ));
  OR3x1_ASAP7_75t_R   g356(.A(\totalcoeffs[2] ), .B(new_n31_), .C(new_n29_), .Y(new_n378_));
  OR3x1_ASAP7_75t_R   g357(.A(new_n28_), .B(\trailingones[1] ), .C(new_n378_), .Y(new_n379_));
  OA21x2_ASAP7_75t_R  g358(.A1(new_n214_), .A2(new_n328_), .B(new_n379_), .Y(new_n380_));
  OR3x1_ASAP7_75t_R   g359(.A(new_n34_), .B(new_n272_), .C(new_n380_), .Y(new_n381_));
  AO21x1_ASAP7_75t_R  g360(.A1(new_n183_), .A2(new_n310_), .B(new_n251_), .Y(new_n382_));
  OA21x2_ASAP7_75t_R  g361(.A1(new_n31_), .A2(new_n310_), .B(new_n42_), .Y(new_n383_));
  AOI21x1_ASAP7_75t_R g362(.A1(new_n29_), .A2(new_n127_), .B(new_n383_), .Y(new_n384_));
  AO21x1_ASAP7_75t_R  g363(.A1(\trailingones[1] ), .A2(new_n382_), .B(new_n384_), .Y(new_n385_));
  NAND2x1_ASAP7_75t_R g364(.A(new_n23_), .B(new_n385_), .Y(new_n386_));
  OA21x2_ASAP7_75t_R  g365(.A1(new_n38_), .A2(new_n165_), .B(new_n386_), .Y(new_n387_));
  OR3x1_ASAP7_75t_R   g366(.A(new_n29_), .B(new_n30_), .C(\totalcoeffs[3] ), .Y(new_n388_));
  AO21x1_ASAP7_75t_R  g367(.A1(\trailingones[0] ), .A2(\trailingones[1] ), .B(new_n24_), .Y(new_n389_));
  AO21x1_ASAP7_75t_R  g368(.A1(new_n143_), .A2(new_n389_), .B(\ctable[1] ), .Y(new_n390_));
  AO21x1_ASAP7_75t_R  g369(.A1(new_n388_), .A2(new_n390_), .B(new_n23_), .Y(new_n391_));
  AO21x1_ASAP7_75t_R  g370(.A1(new_n387_), .A2(new_n391_), .B(new_n22_), .Y(new_n392_));
  AND3x1_ASAP7_75t_R  g371(.A(\totalcoeffs[3] ), .B(new_n141_), .C(new_n41_), .Y(new_n393_));
  AO21x1_ASAP7_75t_R  g372(.A1(new_n31_), .A2(new_n141_), .B(new_n351_), .Y(new_n394_));
  AOI21x1_ASAP7_75t_R g373(.A1(new_n27_), .A2(new_n165_), .B(new_n368_), .Y(new_n395_));
  AO21x1_ASAP7_75t_R  g374(.A1(new_n30_), .A2(new_n394_), .B(new_n395_), .Y(new_n396_));
  OR3x1_ASAP7_75t_R   g375(.A(\ctable[1] ), .B(new_n213_), .C(new_n93_), .Y(new_n397_));
  OAI21x1_ASAP7_75t_R g376(.A1(new_n150_), .A2(new_n215_), .B(new_n397_), .Y(new_n398_));
  AO21x1_ASAP7_75t_R  g377(.A1(\totalcoeffs[3] ), .A2(new_n398_), .B(new_n396_), .Y(new_n399_));
  AOI21x1_ASAP7_75t_R g378(.A1(new_n22_), .A2(new_n399_), .B(new_n393_), .Y(new_n400_));
  AO21x1_ASAP7_75t_R  g379(.A1(new_n392_), .A2(new_n400_), .B(\ctable[0] ), .Y(new_n401_));
  AND3x1_ASAP7_75t_R  g380(.A(\totalcoeffs[2] ), .B(\totalcoeffs[3] ), .C(new_n276_), .Y(new_n402_));
  AO21x1_ASAP7_75t_R  g381(.A1(\totalcoeffs[3] ), .A2(\totalcoeffs[0] ), .B(\totalcoeffs[2] ), .Y(new_n403_));
  AO21x1_ASAP7_75t_R  g382(.A1(\totalcoeffs[2] ), .A2(\totalcoeffs[3] ), .B(new_n214_), .Y(new_n404_));
  AND3x1_ASAP7_75t_R  g383(.A(\ctable[0] ), .B(new_n403_), .C(new_n404_), .Y(new_n405_));
  AO21x1_ASAP7_75t_R  g384(.A1(new_n75_), .A2(new_n226_), .B(new_n405_), .Y(new_n406_));
  AOI21x1_ASAP7_75t_R g385(.A1(new_n22_), .A2(new_n406_), .B(new_n402_), .Y(new_n407_));
  NAND2x1_ASAP7_75t_R g386(.A(new_n88_), .B(new_n128_), .Y(new_n408_));
  OR3x1_ASAP7_75t_R   g387(.A(new_n31_), .B(new_n88_), .C(new_n361_), .Y(new_n409_));
  OR3x1_ASAP7_75t_R   g388(.A(new_n26_), .B(\totalcoeffs[0] ), .C(\trailingones[1] ), .Y(new_n410_));
  AO21x1_ASAP7_75t_R  g389(.A1(new_n409_), .A2(new_n410_), .B(new_n29_), .Y(new_n411_));
  AO21x1_ASAP7_75t_R  g390(.A1(new_n408_), .A2(new_n411_), .B(\totalcoeffs[3] ), .Y(new_n412_));
  NOR2x1_ASAP7_75t_R  g391(.A(new_n24_), .B(new_n26_), .Y(new_n413_));
  INVx1_ASAP7_75t_R   g392(.A(new_n413_), .Y(new_n414_));
  AOI21x1_ASAP7_75t_R g393(.A1(new_n58_), .A2(new_n414_), .B(\totalcoeffs[0] ), .Y(new_n415_));
  AO21x1_ASAP7_75t_R  g394(.A1(\totalcoeffs[3] ), .A2(new_n294_), .B(new_n415_), .Y(new_n416_));
  AND3x1_ASAP7_75t_R  g395(.A(new_n23_), .B(new_n30_), .C(new_n413_), .Y(new_n417_));
  AOI21x1_ASAP7_75t_R g396(.A1(new_n29_), .A2(new_n416_), .B(new_n417_), .Y(new_n418_));
  AO21x1_ASAP7_75t_R  g397(.A1(new_n412_), .A2(new_n418_), .B(new_n22_), .Y(new_n419_));
  AO21x1_ASAP7_75t_R  g398(.A1(new_n407_), .A2(new_n419_), .B(\ctable[1] ), .Y(new_n420_));
  AO21x1_ASAP7_75t_R  g399(.A1(new_n401_), .A2(new_n420_), .B(\ctable[2] ), .Y(new_n421_));
  NAND2x1_ASAP7_75t_R g400(.A(new_n381_), .B(new_n421_), .Y(new_n422_));
  NAND2x1_ASAP7_75t_R g401(.A(new_n25_), .B(new_n422_), .Y(new_n423_));
  OR3x1_ASAP7_75t_R   g402(.A(\ctable[0] ), .B(\ctable[2] ), .C(new_n325_), .Y(new_n424_));
  OA21x2_ASAP7_75t_R  g403(.A1(\ctable[1] ), .A2(new_n424_), .B(new_n423_), .Y(\ctoken_len[1] ));
  AND3x1_ASAP7_75t_R  g404(.A(new_n31_), .B(new_n141_), .C(new_n223_), .Y(new_n426_));
  AND3x1_ASAP7_75t_R  g405(.A(\trailingones[1] ), .B(new_n327_), .C(new_n29_), .Y(new_n427_));
  AO21x1_ASAP7_75t_R  g406(.A1(new_n31_), .A2(new_n337_), .B(new_n169_), .Y(new_n428_));
  AO21x1_ASAP7_75t_R  g407(.A1(new_n30_), .A2(new_n428_), .B(new_n427_), .Y(new_n429_));
  AO21x1_ASAP7_75t_R  g408(.A1(new_n22_), .A2(new_n429_), .B(new_n426_), .Y(new_n430_));
  AOI21x1_ASAP7_75t_R g409(.A1(new_n232_), .A2(new_n330_), .B(new_n102_), .Y(new_n431_));
  AO21x1_ASAP7_75t_R  g410(.A1(new_n97_), .A2(new_n294_), .B(new_n250_), .Y(new_n432_));
  AOI21x1_ASAP7_75t_R g411(.A1(new_n31_), .A2(new_n432_), .B(new_n431_), .Y(new_n433_));
  AO21x1_ASAP7_75t_R  g412(.A1(\totalcoeffs[1] ), .A2(\ctable[0] ), .B(new_n290_), .Y(new_n434_));
  AO21x1_ASAP7_75t_R  g413(.A1(new_n22_), .A2(new_n30_), .B(\totalcoeffs[2] ), .Y(new_n435_));
  AO21x1_ASAP7_75t_R  g414(.A1(new_n24_), .A2(\trailingones[1] ), .B(new_n435_), .Y(new_n436_));
  OR3x1_ASAP7_75t_R   g415(.A(new_n115_), .B(new_n290_), .C(new_n436_), .Y(new_n437_));
  AO21x1_ASAP7_75t_R  g416(.A1(new_n433_), .A2(new_n437_), .B(\trailingones[0] ), .Y(new_n438_));
  AO21x1_ASAP7_75t_R  g417(.A1(\totalcoeffs[3] ), .A2(new_n168_), .B(new_n22_), .Y(new_n439_));
  AO21x1_ASAP7_75t_R  g418(.A1(new_n238_), .A2(new_n414_), .B(new_n439_), .Y(new_n440_));
  OR3x1_ASAP7_75t_R   g419(.A(new_n156_), .B(new_n168_), .C(new_n192_), .Y(new_n441_));
  AOI21x1_ASAP7_75t_R g420(.A1(new_n440_), .A2(new_n441_), .B(new_n30_), .Y(new_n442_));
  OR3x1_ASAP7_75t_R   g421(.A(\totalcoeffs[2] ), .B(new_n91_), .C(new_n434_), .Y(new_n443_));
  INVx1_ASAP7_75t_R   g422(.A(new_n443_), .Y(new_n444_));
  AO21x1_ASAP7_75t_R  g423(.A1(new_n33_), .A2(new_n170_), .B(new_n444_), .Y(new_n445_));
  AO21x1_ASAP7_75t_R  g424(.A1(\trailingones[0] ), .A2(new_n31_), .B(\ctable[0] ), .Y(new_n446_));
  AND3x1_ASAP7_75t_R  g425(.A(new_n82_), .B(new_n414_), .C(new_n446_), .Y(new_n447_));
  AO21x1_ASAP7_75t_R  g426(.A1(\trailingones[0] ), .A2(new_n445_), .B(new_n447_), .Y(new_n448_));
  AOI21x1_ASAP7_75t_R g427(.A1(new_n30_), .A2(new_n448_), .B(new_n442_), .Y(new_n449_));
  AO21x1_ASAP7_75t_R  g428(.A1(new_n438_), .A2(new_n449_), .B(\ctable[1] ), .Y(new_n450_));
  AND2x2_ASAP7_75t_R  g429(.A(new_n27_), .B(new_n104_), .Y(new_n451_));
  AO21x1_ASAP7_75t_R  g430(.A1(new_n65_), .A2(new_n183_), .B(new_n229_), .Y(new_n452_));
  AO21x1_ASAP7_75t_R  g431(.A1(new_n23_), .A2(new_n452_), .B(new_n291_), .Y(new_n453_));
  AO21x1_ASAP7_75t_R  g432(.A1(new_n355_), .A2(new_n451_), .B(new_n453_), .Y(new_n454_));
  AOI21x1_ASAP7_75t_R g433(.A1(new_n450_), .A2(new_n454_), .B(\ctable[2] ), .Y(new_n455_));
  AO21x1_ASAP7_75t_R  g434(.A1(new_n200_), .A2(new_n430_), .B(new_n455_), .Y(new_n456_));
  NAND2x1_ASAP7_75t_R g435(.A(new_n25_), .B(new_n456_), .Y(new_n457_));
  AND2x2_ASAP7_75t_R  g436(.A(new_n424_), .B(new_n457_), .Y(\ctoken_len[2] ));
  AOI21x1_ASAP7_75t_R g437(.A1(new_n28_), .A2(new_n264_), .B(new_n31_), .Y(new_n459_));
  AND2x2_ASAP7_75t_R  g438(.A(\ctable[2] ), .B(new_n102_), .Y(new_n460_));
  AO21x1_ASAP7_75t_R  g439(.A1(\totalcoeffs[4] ), .A2(new_n264_), .B(new_n460_), .Y(new_n461_));
  AOI21x1_ASAP7_75t_R g440(.A1(new_n26_), .A2(new_n102_), .B(new_n27_), .Y(new_n462_));
  OR3x1_ASAP7_75t_R   g441(.A(new_n461_), .B(new_n462_), .C(new_n459_), .Y(new_n463_));
  AO21x1_ASAP7_75t_R  g442(.A1(new_n170_), .A2(new_n311_), .B(\ctable[2] ), .Y(new_n464_));
  AO21x1_ASAP7_75t_R  g443(.A1(new_n354_), .A2(new_n464_), .B(new_n463_), .Y(new_n465_));
  OA21x2_ASAP7_75t_R  g444(.A1(\ctable[1] ), .A2(new_n276_), .B(new_n24_), .Y(new_n466_));
  AO21x1_ASAP7_75t_R  g445(.A1(new_n285_), .A2(new_n311_), .B(new_n466_), .Y(new_n467_));
  AO21x1_ASAP7_75t_R  g446(.A1(\ctable[1] ), .A2(\trailingones[1] ), .B(new_n24_), .Y(new_n468_));
  AND3x1_ASAP7_75t_R  g447(.A(\trailingones[0] ), .B(new_n31_), .C(new_n468_), .Y(new_n469_));
  AO21x1_ASAP7_75t_R  g448(.A1(new_n24_), .A2(new_n52_), .B(new_n469_), .Y(new_n470_));
  AO21x1_ASAP7_75t_R  g449(.A1(new_n23_), .A2(new_n470_), .B(new_n467_), .Y(new_n471_));
  AO21x1_ASAP7_75t_R  g450(.A1(\totalcoeffs[1] ), .A2(new_n471_), .B(new_n465_), .Y(new_n472_));
  OA21x2_ASAP7_75t_R  g451(.A1(new_n271_), .A2(new_n283_), .B(new_n23_), .Y(new_n473_));
  AO21x1_ASAP7_75t_R  g452(.A1(new_n183_), .A2(new_n304_), .B(new_n468_), .Y(new_n474_));
  OR3x1_ASAP7_75t_R   g453(.A(new_n102_), .B(new_n209_), .C(new_n285_), .Y(new_n475_));
  INVx1_ASAP7_75t_R   g454(.A(new_n475_), .Y(new_n476_));
  AO21x1_ASAP7_75t_R  g455(.A1(new_n473_), .A2(new_n474_), .B(new_n476_), .Y(new_n477_));
  AOI21x1_ASAP7_75t_R g456(.A1(new_n22_), .A2(new_n477_), .B(new_n472_), .Y(\ctoken_len[3] ));
  OR3x1_ASAP7_75t_R   g457(.A(new_n23_), .B(new_n320_), .C(new_n63_), .Y(new_n479_));
  AO21x1_ASAP7_75t_R  g458(.A1(\trailingones[0] ), .A2(new_n68_), .B(new_n479_), .Y(new_n480_));
  NAND2x1_ASAP7_75t_R g459(.A(new_n325_), .B(new_n480_), .Y(new_n481_));
  AND3x1_ASAP7_75t_R  g460(.A(new_n28_), .B(new_n271_), .C(new_n481_), .Y(\ctoken_len[4] ));
endmodule


