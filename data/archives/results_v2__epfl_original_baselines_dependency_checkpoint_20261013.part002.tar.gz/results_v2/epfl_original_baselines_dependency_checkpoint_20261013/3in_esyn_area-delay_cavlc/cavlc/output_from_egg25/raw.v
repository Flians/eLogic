// Benchmark "/home/flynn/workplace/MIGBalance/results_v2/epfl_original_baselines_dependency_checkpoint_20261013/3in_esyn_area-delay_cavlc/cavlc/output_from_egg25/logic" written by ABC on Tue Oct 13 13:00:56 2026

module \/home/flynn/workplace/MIGBalance/results_v2/epfl_original_baselines_dependency_checkpoint_20261013/3in_esyn_area-delay_cavlc/cavlc/output_from_egg25/logic  ( 
    \totalcoeffs[1] , \totalcoeffs[2] , \totalcoeffs[3] , \totalcoeffs[4] ,
    \ctable[0] , \ctable[1] , \ctable[2] , \trailingones[0] ,
    \trailingones[1] , \totalcoeffs[0] ,
    \coeff_token[0] , \coeff_token[1] , \coeff_token[2] , \coeff_token[3] ,
    \coeff_token[4] , \coeff_token[5] , \ctoken_len[0] , \ctoken_len[1] ,
    \ctoken_len[2] , \ctoken_len[3] , \ctoken_len[4]   );
  input  \totalcoeffs[1] , \totalcoeffs[2] , \totalcoeffs[3] ,
    \totalcoeffs[4] , \ctable[0] , \ctable[1] , \ctable[2] ,
    \trailingones[0] , \trailingones[1] , \totalcoeffs[0] ;
  output \coeff_token[0] , \coeff_token[1] , \coeff_token[2] ,
    \coeff_token[3] , \coeff_token[4] , \coeff_token[5] , \ctoken_len[0] ,
    \ctoken_len[1] , \ctoken_len[2] , \ctoken_len[3] , \ctoken_len[4] ;
  wire new_n22_, new_n23_, new_n24_, new_n25_, new_n26_, new_n27_, new_n28_,
    new_n29_, new_n30_, new_n31_, new_n32_, new_n33_, new_n34_, new_n35_,
    new_n36_, new_n37_, new_n38_, new_n39_, new_n40_, new_n41_, new_n42_,
    new_n43_, new_n44_, new_n45_, new_n46_, new_n47_, new_n48_, new_n49_,
    new_n50_, new_n51_, new_n52_, new_n53_, new_n54_, new_n55_, new_n56_,
    new_n57_, new_n58_, new_n59_, new_n60_, new_n61_, new_n62_, new_n63_,
    new_n64_, new_n65_, new_n66_, new_n67_, new_n68_, new_n69_, new_n70_,
    new_n71_, new_n72_, new_n73_, new_n74_, new_n75_, new_n76_, new_n77_,
    new_n78_, new_n79_, new_n80_, new_n81_, new_n82_, new_n83_, new_n84_,
    new_n85_, new_n86_, new_n87_, new_n88_, new_n89_, new_n90_, new_n91_,
    new_n92_, new_n93_, new_n94_, new_n95_, new_n96_, new_n97_, new_n98_,
    new_n99_, new_n100_, new_n101_, new_n102_, new_n103_, new_n104_,
    new_n105_, new_n106_, new_n107_, new_n108_, new_n109_, new_n110_,
    new_n111_, new_n112_, new_n113_, new_n114_, new_n115_, new_n116_,
    new_n117_, new_n118_, new_n119_, new_n120_, new_n121_, new_n122_,
    new_n123_, new_n125_, new_n126_, new_n127_, new_n128_, new_n129_,
    new_n130_, new_n131_, new_n132_, new_n133_, new_n134_, new_n135_,
    new_n136_, new_n137_, new_n138_, new_n139_, new_n140_, new_n141_,
    new_n142_, new_n143_, new_n144_, new_n145_, new_n146_, new_n147_,
    new_n148_, new_n149_, new_n150_, new_n151_, new_n152_, new_n153_,
    new_n154_, new_n155_, new_n156_, new_n157_, new_n158_, new_n159_,
    new_n160_, new_n161_, new_n162_, new_n163_, new_n164_, new_n165_,
    new_n166_, new_n167_, new_n168_, new_n169_, new_n170_, new_n171_,
    new_n172_, new_n173_, new_n174_, new_n175_, new_n176_, new_n177_,
    new_n178_, new_n179_, new_n180_, new_n181_, new_n182_, new_n183_,
    new_n184_, new_n185_, new_n186_, new_n187_, new_n188_, new_n189_,
    new_n190_, new_n191_, new_n192_, new_n193_, new_n194_, new_n195_,
    new_n196_, new_n197_, new_n198_, new_n199_, new_n200_, new_n201_,
    new_n202_, new_n203_, new_n204_, new_n205_, new_n207_, new_n208_,
    new_n209_, new_n210_, new_n211_, new_n212_, new_n213_, new_n214_,
    new_n215_, new_n216_, new_n217_, new_n218_, new_n219_, new_n220_,
    new_n221_, new_n222_, new_n223_, new_n224_, new_n225_, new_n226_,
    new_n227_, new_n228_, new_n229_, new_n230_, new_n231_, new_n232_,
    new_n233_, new_n234_, new_n235_, new_n236_, new_n237_, new_n238_,
    new_n239_, new_n240_, new_n241_, new_n242_, new_n243_, new_n244_,
    new_n245_, new_n246_, new_n247_, new_n248_, new_n249_, new_n250_,
    new_n251_, new_n252_, new_n253_, new_n254_, new_n255_, new_n256_,
    new_n257_, new_n258_, new_n259_, new_n260_, new_n261_, new_n262_,
    new_n263_, new_n264_, new_n265_, new_n266_, new_n267_, new_n268_,
    new_n269_, new_n270_, new_n272_, new_n273_, new_n274_, new_n275_,
    new_n276_, new_n277_, new_n278_, new_n279_, new_n280_, new_n281_,
    new_n282_, new_n283_, new_n284_, new_n285_, new_n286_, new_n287_,
    new_n288_, new_n289_, new_n290_, new_n291_, new_n292_, new_n293_,
    new_n294_, new_n295_, new_n296_, new_n297_, new_n298_, new_n299_,
    new_n300_, new_n301_, new_n302_, new_n303_, new_n304_, new_n305_,
    new_n306_, new_n307_, new_n308_, new_n309_, new_n310_, new_n311_,
    new_n312_, new_n313_, new_n314_, new_n315_, new_n317_, new_n318_,
    new_n319_, new_n320_, new_n322_, new_n323_, new_n325_, new_n326_,
    new_n327_, new_n328_, new_n329_, new_n330_, new_n331_, new_n332_,
    new_n333_, new_n334_, new_n335_, new_n336_, new_n337_, new_n338_,
    new_n339_, new_n340_, new_n341_, new_n342_, new_n343_, new_n344_,
    new_n345_, new_n346_, new_n347_, new_n348_, new_n349_, new_n350_,
    new_n351_, new_n352_, new_n353_, new_n354_, new_n355_, new_n356_,
    new_n357_, new_n358_, new_n359_, new_n360_, new_n361_, new_n362_,
    new_n363_, new_n364_, new_n365_, new_n366_, new_n367_, new_n368_,
    new_n369_, new_n370_, new_n371_, new_n372_, new_n373_, new_n374_,
    new_n376_, new_n377_, new_n378_, new_n379_, new_n380_, new_n381_,
    new_n382_, new_n383_, new_n384_, new_n385_, new_n386_, new_n387_,
    new_n388_, new_n389_, new_n390_, new_n391_, new_n392_, new_n393_,
    new_n394_, new_n395_, new_n396_, new_n397_, new_n398_, new_n399_,
    new_n400_, new_n401_, new_n402_, new_n403_, new_n404_, new_n405_,
    new_n406_, new_n407_, new_n408_, new_n409_, new_n410_, new_n411_,
    new_n412_, new_n413_, new_n414_, new_n415_, new_n416_, new_n417_,
    new_n418_, new_n419_, new_n420_, new_n421_, new_n423_, new_n424_,
    new_n425_, new_n426_, new_n427_, new_n428_, new_n429_, new_n430_,
    new_n431_, new_n432_, new_n433_, new_n434_, new_n435_, new_n436_,
    new_n437_, new_n438_, new_n439_, new_n440_, new_n441_, new_n442_,
    new_n443_, new_n444_, new_n445_, new_n446_, new_n447_, new_n448_,
    new_n449_, new_n450_, new_n451_, new_n452_, new_n453_, new_n454_,
    new_n456_, new_n457_, new_n458_, new_n459_, new_n460_, new_n461_,
    new_n462_, new_n463_, new_n464_, new_n465_, new_n466_, new_n467_,
    new_n468_, new_n469_, new_n470_, new_n471_, new_n472_, new_n473_,
    new_n474_, new_n476_, new_n477_, new_n478_;
  INVx1_ASAP7_75t_R   g000(.A(\totalcoeffs[1] ), .Y(new_n22_));
  INVx1_ASAP7_75t_R   g001(.A(\totalcoeffs[2] ), .Y(new_n23_));
  INVx1_ASAP7_75t_R   g002(.A(\totalcoeffs[3] ), .Y(new_n24_));
  INVx1_ASAP7_75t_R   g003(.A(\totalcoeffs[4] ), .Y(new_n25_));
  INVx1_ASAP7_75t_R   g004(.A(\ctable[0] ), .Y(new_n26_));
  INVx1_ASAP7_75t_R   g005(.A(\ctable[1] ), .Y(new_n27_));
  INVx1_ASAP7_75t_R   g006(.A(\ctable[2] ), .Y(new_n28_));
  INVx1_ASAP7_75t_R   g007(.A(\trailingones[0] ), .Y(new_n29_));
  INVx1_ASAP7_75t_R   g008(.A(\trailingones[1] ), .Y(new_n30_));
  INVx1_ASAP7_75t_R   g009(.A(\totalcoeffs[0] ), .Y(new_n31_));
  NAND2x1_ASAP7_75t_R g010(.A(\totalcoeffs[2] ), .B(new_n30_), .Y(new_n32_));
  NAND2x1_ASAP7_75t_R g011(.A(new_n22_), .B(new_n31_), .Y(new_n33_));
  NOR2x1_ASAP7_75t_R  g012(.A(new_n32_), .B(new_n33_), .Y(new_n34_));
  AND3x1_ASAP7_75t_R  g013(.A(new_n26_), .B(\ctable[2] ), .C(\trailingones[0] ), .Y(new_n35_));
  NOR2x1_ASAP7_75t_R  g014(.A(\ctable[0] ), .B(\trailingones[1] ), .Y(new_n36_));
  INVx1_ASAP7_75t_R   g015(.A(new_n36_), .Y(new_n37_));
  OA21x2_ASAP7_75t_R  g016(.A1(new_n22_), .A2(\ctable[2] ), .B(new_n36_), .Y(new_n38_));
  AO21x1_ASAP7_75t_R  g017(.A1(new_n28_), .A2(\trailingones[1] ), .B(new_n35_), .Y(new_n39_));
  AOI21x1_ASAP7_75t_R g018(.A1(\totalcoeffs[1] ), .A2(new_n39_), .B(new_n38_), .Y(new_n40_));
  OR3x1_ASAP7_75t_R   g019(.A(\totalcoeffs[2] ), .B(new_n31_), .C(new_n40_), .Y(new_n41_));
  INVx1_ASAP7_75t_R   g020(.A(new_n41_), .Y(new_n42_));
  AO21x1_ASAP7_75t_R  g021(.A1(new_n34_), .A2(new_n35_), .B(new_n42_), .Y(new_n43_));
  NOR2x1_ASAP7_75t_R  g022(.A(new_n24_), .B(new_n31_), .Y(new_n44_));
  NOR2x1_ASAP7_75t_R  g023(.A(\totalcoeffs[2] ), .B(\totalcoeffs[3] ), .Y(new_n45_));
  INVx1_ASAP7_75t_R   g024(.A(new_n45_), .Y(new_n46_));
  AO21x1_ASAP7_75t_R  g025(.A1(\trailingones[1] ), .A2(new_n46_), .B(new_n44_), .Y(new_n47_));
  AND2x2_ASAP7_75t_R  g026(.A(new_n22_), .B(new_n47_), .Y(new_n48_));
  AOI21x1_ASAP7_75t_R g027(.A1(\totalcoeffs[1] ), .A2(new_n24_), .B(new_n48_), .Y(new_n49_));
  AO21x1_ASAP7_75t_R  g028(.A1(new_n23_), .A2(new_n26_), .B(\totalcoeffs[0] ), .Y(new_n50_));
  NOR2x1_ASAP7_75t_R  g029(.A(new_n22_), .B(new_n23_), .Y(new_n51_));
  INVx1_ASAP7_75t_R   g030(.A(new_n51_), .Y(new_n52_));
  AO21x1_ASAP7_75t_R  g031(.A1(new_n50_), .A2(new_n52_), .B(\trailingones[1] ), .Y(new_n53_));
  AO21x1_ASAP7_75t_R  g032(.A1(new_n49_), .A2(new_n53_), .B(\ctable[2] ), .Y(new_n54_));
  NOR2x1_ASAP7_75t_R  g033(.A(new_n22_), .B(\trailingones[1] ), .Y(new_n55_));
  INVx1_ASAP7_75t_R   g034(.A(new_n55_), .Y(new_n56_));
  NOR2x1_ASAP7_75t_R  g035(.A(\trailingones[1] ), .B(new_n31_), .Y(new_n57_));
  INVx1_ASAP7_75t_R   g036(.A(new_n57_), .Y(new_n58_));
  NOR2x1_ASAP7_75t_R  g037(.A(\totalcoeffs[1] ), .B(new_n57_), .Y(new_n59_));
  OR3x1_ASAP7_75t_R   g038(.A(\ctable[2] ), .B(new_n55_), .C(new_n59_), .Y(new_n60_));
  NAND2x1_ASAP7_75t_R g039(.A(\trailingones[1] ), .B(new_n31_), .Y(new_n61_));
  AO21x1_ASAP7_75t_R  g040(.A1(\trailingones[1] ), .A2(new_n31_), .B(new_n22_), .Y(new_n62_));
  INVx1_ASAP7_75t_R   g041(.A(new_n62_), .Y(new_n63_));
  NAND2x1_ASAP7_75t_R g042(.A(new_n24_), .B(new_n26_), .Y(new_n64_));
  NOR2x1_ASAP7_75t_R  g043(.A(\totalcoeffs[1] ), .B(new_n30_), .Y(new_n65_));
  INVx1_ASAP7_75t_R   g044(.A(new_n65_), .Y(new_n66_));
  OR3x1_ASAP7_75t_R   g045(.A(new_n64_), .B(new_n65_), .C(new_n63_), .Y(new_n67_));
  AO21x1_ASAP7_75t_R  g046(.A1(new_n60_), .A2(new_n67_), .B(\totalcoeffs[2] ), .Y(new_n68_));
  AOI21x1_ASAP7_75t_R g047(.A1(new_n54_), .A2(new_n68_), .B(\trailingones[0] ), .Y(new_n69_));
  AO21x1_ASAP7_75t_R  g048(.A1(new_n24_), .A2(new_n43_), .B(new_n69_), .Y(new_n70_));
  NOR2x1_ASAP7_75t_R  g049(.A(new_n23_), .B(new_n30_), .Y(new_n71_));
  NOR2x1_ASAP7_75t_R  g050(.A(\totalcoeffs[1] ), .B(\trailingones[1] ), .Y(new_n72_));
  INVx1_ASAP7_75t_R   g051(.A(new_n72_), .Y(new_n73_));
  AO21x1_ASAP7_75t_R  g052(.A1(new_n23_), .A2(\ctable[1] ), .B(new_n24_), .Y(new_n74_));
  AO21x1_ASAP7_75t_R  g053(.A1(new_n72_), .A2(new_n74_), .B(new_n71_), .Y(new_n75_));
  NAND2x1_ASAP7_75t_R g054(.A(\totalcoeffs[2] ), .B(new_n24_), .Y(new_n76_));
  OR3x1_ASAP7_75t_R   g055(.A(\totalcoeffs[1] ), .B(new_n30_), .C(new_n76_), .Y(new_n77_));
  NAND2x1_ASAP7_75t_R g056(.A(\totalcoeffs[1] ), .B(new_n29_), .Y(new_n78_));
  AOI21x1_ASAP7_75t_R g057(.A1(new_n77_), .A2(new_n78_), .B(\totalcoeffs[0] ), .Y(new_n79_));
  AO21x1_ASAP7_75t_R  g058(.A1(new_n29_), .A2(new_n75_), .B(new_n79_), .Y(new_n80_));
  OR3x1_ASAP7_75t_R   g059(.A(\totalcoeffs[2] ), .B(\totalcoeffs[3] ), .C(\totalcoeffs[0] ), .Y(new_n81_));
  OR3x1_ASAP7_75t_R   g060(.A(\trailingones[0] ), .B(new_n73_), .C(new_n81_), .Y(new_n82_));
  INVx1_ASAP7_75t_R   g061(.A(new_n82_), .Y(new_n83_));
  AO21x1_ASAP7_75t_R  g062(.A1(new_n26_), .A2(new_n80_), .B(new_n83_), .Y(new_n84_));
  AO21x1_ASAP7_75t_R  g063(.A1(new_n30_), .A2(\totalcoeffs[0] ), .B(\totalcoeffs[2] ), .Y(new_n85_));
  AO21x1_ASAP7_75t_R  g064(.A1(new_n24_), .A2(new_n63_), .B(new_n85_), .Y(new_n86_));
  AOI21x1_ASAP7_75t_R g065(.A1(new_n27_), .A2(new_n85_), .B(new_n26_), .Y(new_n87_));
  OR3x1_ASAP7_75t_R   g066(.A(new_n22_), .B(\trailingones[1] ), .C(\totalcoeffs[2] ), .Y(new_n88_));
  AO21x1_ASAP7_75t_R  g067(.A1(new_n23_), .A2(new_n55_), .B(new_n71_), .Y(new_n89_));
  NOR2x1_ASAP7_75t_R  g068(.A(\totalcoeffs[3] ), .B(\totalcoeffs[0] ), .Y(new_n90_));
  AND3x1_ASAP7_75t_R  g069(.A(\ctable[1] ), .B(new_n90_), .C(new_n89_), .Y(new_n91_));
  AO21x1_ASAP7_75t_R  g070(.A1(new_n86_), .A2(new_n87_), .B(new_n91_), .Y(new_n92_));
  AOI21x1_ASAP7_75t_R g071(.A1(\trailingones[0] ), .A2(new_n92_), .B(new_n84_), .Y(new_n93_));
  OR3x1_ASAP7_75t_R   g072(.A(\totalcoeffs[2] ), .B(\totalcoeffs[0] ), .C(new_n66_), .Y(new_n94_));
  AO21x1_ASAP7_75t_R  g073(.A1(new_n26_), .A2(new_n94_), .B(new_n27_), .Y(new_n95_));
  NOR2x1_ASAP7_75t_R  g074(.A(new_n22_), .B(new_n26_), .Y(new_n96_));
  INVx1_ASAP7_75t_R   g075(.A(new_n96_), .Y(new_n97_));
  AO21x1_ASAP7_75t_R  g076(.A1(\trailingones[1] ), .A2(new_n31_), .B(new_n57_), .Y(new_n98_));
  INVx1_ASAP7_75t_R   g077(.A(new_n98_), .Y(new_n99_));
  OR3x1_ASAP7_75t_R   g078(.A(new_n23_), .B(new_n97_), .C(new_n98_), .Y(new_n100_));
  AO21x1_ASAP7_75t_R  g079(.A1(new_n95_), .A2(new_n100_), .B(new_n29_), .Y(new_n101_));
  OR3x1_ASAP7_75t_R   g080(.A(\totalcoeffs[1] ), .B(new_n23_), .C(new_n58_), .Y(new_n102_));
  AO21x1_ASAP7_75t_R  g081(.A1(new_n22_), .A2(new_n61_), .B(\trailingones[0] ), .Y(new_n103_));
  AO21x1_ASAP7_75t_R  g082(.A1(new_n102_), .A2(new_n103_), .B(\ctable[0] ), .Y(new_n104_));
  AO21x1_ASAP7_75t_R  g083(.A1(new_n101_), .A2(new_n104_), .B(new_n24_), .Y(new_n105_));
  AOI21x1_ASAP7_75t_R g084(.A1(new_n93_), .A2(new_n105_), .B(\ctable[2] ), .Y(new_n106_));
  AO21x1_ASAP7_75t_R  g085(.A1(new_n27_), .A2(new_n70_), .B(new_n106_), .Y(new_n107_));
  OR3x1_ASAP7_75t_R   g086(.A(\totalcoeffs[2] ), .B(\totalcoeffs[0] ), .C(\ctable[2] ), .Y(new_n108_));
  NOR2x1_ASAP7_75t_R  g087(.A(\totalcoeffs[1] ), .B(\totalcoeffs[3] ), .Y(new_n109_));
  INVx1_ASAP7_75t_R   g088(.A(new_n109_), .Y(new_n110_));
  NAND2x1_ASAP7_75t_R g089(.A(new_n27_), .B(\trailingones[0] ), .Y(new_n111_));
  AND2x2_ASAP7_75t_R  g090(.A(\ctable[0] ), .B(new_n111_), .Y(new_n112_));
  NOR2x1_ASAP7_75t_R  g091(.A(\ctable[1] ), .B(\trailingones[1] ), .Y(new_n113_));
  INVx1_ASAP7_75t_R   g092(.A(new_n113_), .Y(new_n114_));
  AO21x1_ASAP7_75t_R  g093(.A1(\totalcoeffs[4] ), .A2(\trailingones[0] ), .B(new_n113_), .Y(new_n115_));
  NOR2x1_ASAP7_75t_R  g094(.A(new_n26_), .B(new_n27_), .Y(new_n116_));
  NOR2x1_ASAP7_75t_R  g095(.A(new_n27_), .B(\trailingones[1] ), .Y(new_n117_));
  AOI21x1_ASAP7_75t_R g096(.A1(\totalcoeffs[4] ), .A2(\trailingones[1] ), .B(new_n117_), .Y(new_n118_));
  OR3x1_ASAP7_75t_R   g097(.A(\trailingones[0] ), .B(new_n116_), .C(new_n118_), .Y(new_n119_));
  INVx1_ASAP7_75t_R   g098(.A(new_n119_), .Y(new_n120_));
  AOI21x1_ASAP7_75t_R g099(.A1(new_n112_), .A2(new_n115_), .B(new_n120_), .Y(new_n121_));
  OR3x1_ASAP7_75t_R   g100(.A(new_n108_), .B(new_n110_), .C(new_n121_), .Y(new_n122_));
  INVx1_ASAP7_75t_R   g101(.A(new_n122_), .Y(new_n123_));
  AO21x1_ASAP7_75t_R  g102(.A1(new_n25_), .A2(new_n107_), .B(new_n123_), .Y(\coeff_token[0] ));
  NAND2x1_ASAP7_75t_R g103(.A(new_n23_), .B(\trailingones[0] ), .Y(new_n125_));
  AND2x2_ASAP7_75t_R  g104(.A(\totalcoeffs[2] ), .B(new_n33_), .Y(new_n126_));
  AOI21x1_ASAP7_75t_R g105(.A1(\totalcoeffs[1] ), .A2(\totalcoeffs[0] ), .B(new_n85_), .Y(new_n127_));
  OR3x1_ASAP7_75t_R   g106(.A(\trailingones[0] ), .B(new_n126_), .C(new_n127_), .Y(new_n128_));
  OAI21x1_ASAP7_75t_R g107(.A1(new_n56_), .A2(new_n125_), .B(new_n128_), .Y(new_n129_));
  AOI21x1_ASAP7_75t_R g108(.A1(\ctable[2] ), .A2(new_n129_), .B(new_n34_), .Y(new_n130_));
  OR3x1_ASAP7_75t_R   g109(.A(\totalcoeffs[3] ), .B(\ctable[0] ), .C(\ctable[1] ), .Y(new_n131_));
  INVx1_ASAP7_75t_R   g110(.A(new_n131_), .Y(new_n132_));
  OR3x1_ASAP7_75t_R   g111(.A(\totalcoeffs[4] ), .B(new_n131_), .C(new_n130_), .Y(new_n133_));
  NOR2x1_ASAP7_75t_R  g112(.A(\totalcoeffs[1] ), .B(\ctable[1] ), .Y(new_n134_));
  AO21x1_ASAP7_75t_R  g113(.A1(\totalcoeffs[1] ), .A2(\totalcoeffs[0] ), .B(new_n134_), .Y(new_n135_));
  NOR2x1_ASAP7_75t_R  g114(.A(new_n29_), .B(\totalcoeffs[0] ), .Y(new_n136_));
  OR3x1_ASAP7_75t_R   g115(.A(\totalcoeffs[2] ), .B(new_n136_), .C(new_n135_), .Y(new_n137_));
  INVx1_ASAP7_75t_R   g116(.A(new_n137_), .Y(new_n138_));
  NOR2x1_ASAP7_75t_R  g117(.A(\totalcoeffs[1] ), .B(\trailingones[0] ), .Y(new_n139_));
  NOR2x1_ASAP7_75t_R  g118(.A(\totalcoeffs[1] ), .B(new_n29_), .Y(new_n140_));
  INVx1_ASAP7_75t_R   g119(.A(new_n140_), .Y(new_n141_));
  OR3x1_ASAP7_75t_R   g120(.A(\totalcoeffs[1] ), .B(new_n29_), .C(new_n27_), .Y(new_n142_));
  OAI21x1_ASAP7_75t_R g121(.A1(\totalcoeffs[2] ), .A2(new_n139_), .B(new_n142_), .Y(new_n143_));
  AO21x1_ASAP7_75t_R  g122(.A1(\totalcoeffs[3] ), .A2(new_n143_), .B(new_n138_), .Y(new_n144_));
  AO21x1_ASAP7_75t_R  g123(.A1(new_n26_), .A2(new_n144_), .B(\trailingones[1] ), .Y(new_n145_));
  NOR2x1_ASAP7_75t_R  g124(.A(\totalcoeffs[3] ), .B(\trailingones[0] ), .Y(new_n146_));
  INVx1_ASAP7_75t_R   g125(.A(new_n146_), .Y(new_n147_));
  NAND2x1_ASAP7_75t_R g126(.A(new_n26_), .B(\trailingones[0] ), .Y(new_n148_));
  AND2x2_ASAP7_75t_R  g127(.A(new_n147_), .B(new_n148_), .Y(new_n149_));
  NOR2x1_ASAP7_75t_R  g128(.A(\totalcoeffs[2] ), .B(\trailingones[0] ), .Y(new_n150_));
  AND3x1_ASAP7_75t_R  g129(.A(new_n23_), .B(new_n29_), .C(\ctable[0] ), .Y(new_n151_));
  AO21x1_ASAP7_75t_R  g130(.A1(\totalcoeffs[0] ), .A2(new_n149_), .B(new_n151_), .Y(new_n152_));
  OA21x2_ASAP7_75t_R  g131(.A1(new_n24_), .A2(new_n29_), .B(new_n23_), .Y(new_n153_));
  NOR2x1_ASAP7_75t_R  g132(.A(\totalcoeffs[0] ), .B(new_n153_), .Y(new_n154_));
  NOR2x1_ASAP7_75t_R  g133(.A(new_n26_), .B(\totalcoeffs[0] ), .Y(new_n155_));
  NOR2x1_ASAP7_75t_R  g134(.A(\ctable[0] ), .B(new_n31_), .Y(new_n156_));
  AND3x1_ASAP7_75t_R  g135(.A(new_n23_), .B(\trailingones[0] ), .C(\totalcoeffs[0] ), .Y(new_n157_));
  OR3x1_ASAP7_75t_R   g136(.A(new_n155_), .B(new_n156_), .C(new_n157_), .Y(new_n158_));
  AO21x1_ASAP7_75t_R  g137(.A1(\totalcoeffs[1] ), .A2(new_n158_), .B(new_n154_), .Y(new_n159_));
  AO21x1_ASAP7_75t_R  g138(.A1(new_n22_), .A2(new_n152_), .B(new_n159_), .Y(new_n160_));
  AOI21x1_ASAP7_75t_R g139(.A1(new_n27_), .A2(new_n160_), .B(new_n145_), .Y(new_n161_));
  AND3x1_ASAP7_75t_R  g140(.A(\totalcoeffs[1] ), .B(\totalcoeffs[2] ), .C(\totalcoeffs[3] ), .Y(new_n162_));
  OA21x2_ASAP7_75t_R  g141(.A1(\ctable[0] ), .A2(new_n162_), .B(new_n46_), .Y(new_n163_));
  NOR2x1_ASAP7_75t_R  g142(.A(\totalcoeffs[1] ), .B(new_n24_), .Y(new_n164_));
  INVx1_ASAP7_75t_R   g143(.A(new_n164_), .Y(new_n165_));
  AO21x1_ASAP7_75t_R  g144(.A1(new_n150_), .A2(new_n164_), .B(new_n96_), .Y(new_n166_));
  AO21x1_ASAP7_75t_R  g145(.A1(\totalcoeffs[0] ), .A2(new_n166_), .B(new_n163_), .Y(new_n167_));
  NOR2x1_ASAP7_75t_R  g146(.A(new_n26_), .B(\trailingones[0] ), .Y(new_n168_));
  AO21x1_ASAP7_75t_R  g147(.A1(new_n162_), .A2(new_n168_), .B(new_n30_), .Y(new_n169_));
  AOI21x1_ASAP7_75t_R g148(.A1(\ctable[1] ), .A2(new_n167_), .B(new_n169_), .Y(new_n170_));
  OR3x1_ASAP7_75t_R   g149(.A(\totalcoeffs[4] ), .B(new_n170_), .C(new_n161_), .Y(new_n171_));
  NAND2x1_ASAP7_75t_R g150(.A(\ctable[1] ), .B(new_n31_), .Y(new_n172_));
  AO21x1_ASAP7_75t_R  g151(.A1(new_n23_), .A2(new_n172_), .B(new_n148_), .Y(new_n173_));
  NAND2x1_ASAP7_75t_R g152(.A(new_n27_), .B(new_n29_), .Y(new_n174_));
  AO21x1_ASAP7_75t_R  g153(.A1(new_n173_), .A2(new_n174_), .B(\trailingones[1] ), .Y(new_n175_));
  NOR2x1_ASAP7_75t_R  g154(.A(new_n27_), .B(new_n29_), .Y(new_n176_));
  NOR2x1_ASAP7_75t_R  g155(.A(new_n27_), .B(new_n30_), .Y(new_n177_));
  INVx1_ASAP7_75t_R   g156(.A(new_n177_), .Y(new_n178_));
  AND2x2_ASAP7_75t_R  g157(.A(new_n148_), .B(new_n178_), .Y(new_n179_));
  OR3x1_ASAP7_75t_R   g158(.A(new_n31_), .B(new_n176_), .C(new_n179_), .Y(new_n180_));
  NOR2x1_ASAP7_75t_R  g159(.A(\trailingones[0] ), .B(new_n30_), .Y(new_n181_));
  NAND2x1_ASAP7_75t_R g160(.A(new_n155_), .B(new_n181_), .Y(new_n182_));
  AO21x1_ASAP7_75t_R  g161(.A1(new_n180_), .A2(new_n182_), .B(\totalcoeffs[2] ), .Y(new_n183_));
  AO21x1_ASAP7_75t_R  g162(.A1(new_n175_), .A2(new_n183_), .B(new_n22_), .Y(new_n184_));
  AND3x1_ASAP7_75t_R  g163(.A(new_n26_), .B(new_n30_), .C(new_n29_), .Y(new_n185_));
  AOI21x1_ASAP7_75t_R g164(.A1(\trailingones[1] ), .A2(new_n176_), .B(new_n185_), .Y(new_n186_));
  AO21x1_ASAP7_75t_R  g165(.A1(new_n148_), .A2(new_n178_), .B(\totalcoeffs[0] ), .Y(new_n187_));
  AOI21x1_ASAP7_75t_R g166(.A1(new_n186_), .A2(new_n187_), .B(new_n23_), .Y(new_n188_));
  NAND2x1_ASAP7_75t_R g167(.A(\trailingones[0] ), .B(\totalcoeffs[0] ), .Y(new_n189_));
  OR3x1_ASAP7_75t_R   g168(.A(new_n29_), .B(new_n31_), .C(new_n30_), .Y(new_n190_));
  INVx1_ASAP7_75t_R   g169(.A(new_n190_), .Y(new_n191_));
  AND3x1_ASAP7_75t_R  g170(.A(new_n30_), .B(new_n31_), .C(new_n150_), .Y(new_n192_));
  AO21x1_ASAP7_75t_R  g171(.A1(\totalcoeffs[2] ), .A2(new_n191_), .B(new_n192_), .Y(new_n193_));
  AO21x1_ASAP7_75t_R  g172(.A1(\ctable[0] ), .A2(new_n193_), .B(new_n188_), .Y(new_n194_));
  NAND2x1_ASAP7_75t_R g173(.A(new_n22_), .B(new_n194_), .Y(new_n195_));
  OA21x2_ASAP7_75t_R  g174(.A1(new_n32_), .A2(new_n111_), .B(new_n195_), .Y(new_n196_));
  AOI21x1_ASAP7_75t_R g175(.A1(new_n184_), .A2(new_n196_), .B(\totalcoeffs[4] ), .Y(new_n197_));
  OR3x1_ASAP7_75t_R   g176(.A(\totalcoeffs[1] ), .B(\totalcoeffs[0] ), .C(\totalcoeffs[2] ), .Y(new_n198_));
  INVx1_ASAP7_75t_R   g177(.A(new_n198_), .Y(new_n199_));
  AO21x1_ASAP7_75t_R  g178(.A1(\totalcoeffs[4] ), .A2(\trailingones[0] ), .B(new_n168_), .Y(new_n200_));
  AND3x1_ASAP7_75t_R  g179(.A(new_n27_), .B(new_n30_), .C(new_n200_), .Y(new_n201_));
  AO21x1_ASAP7_75t_R  g180(.A1(\totalcoeffs[4] ), .A2(new_n177_), .B(new_n201_), .Y(new_n202_));
  AO21x1_ASAP7_75t_R  g181(.A1(new_n199_), .A2(new_n202_), .B(new_n197_), .Y(new_n203_));
  NAND2x1_ASAP7_75t_R g182(.A(new_n24_), .B(new_n203_), .Y(new_n204_));
  AO21x1_ASAP7_75t_R  g183(.A1(new_n171_), .A2(new_n204_), .B(\ctable[2] ), .Y(new_n205_));
  NAND2x1_ASAP7_75t_R g184(.A(new_n133_), .B(new_n205_), .Y(\coeff_token[1] ));
  NOR2x1_ASAP7_75t_R  g185(.A(new_n22_), .B(new_n30_), .Y(new_n207_));
  AO21x1_ASAP7_75t_R  g186(.A1(\totalcoeffs[2] ), .A2(new_n207_), .B(new_n140_), .Y(new_n208_));
  NOR2x1_ASAP7_75t_R  g187(.A(\trailingones[0] ), .B(\trailingones[1] ), .Y(new_n209_));
  INVx1_ASAP7_75t_R   g188(.A(new_n209_), .Y(new_n210_));
  AND3x1_ASAP7_75t_R  g189(.A(new_n29_), .B(new_n30_), .C(\totalcoeffs[2] ), .Y(new_n211_));
  AO21x1_ASAP7_75t_R  g190(.A1(\trailingones[0] ), .A2(new_n32_), .B(new_n211_), .Y(new_n212_));
  AO21x1_ASAP7_75t_R  g191(.A1(\ctable[1] ), .A2(new_n208_), .B(new_n212_), .Y(new_n213_));
  AO21x1_ASAP7_75t_R  g192(.A1(new_n22_), .A2(\trailingones[1] ), .B(new_n27_), .Y(new_n214_));
  AO21x1_ASAP7_75t_R  g193(.A1(new_n56_), .A2(new_n214_), .B(new_n29_), .Y(new_n215_));
  AO21x1_ASAP7_75t_R  g194(.A1(\totalcoeffs[1] ), .A2(\trailingones[1] ), .B(new_n72_), .Y(new_n216_));
  INVx1_ASAP7_75t_R   g195(.A(new_n216_), .Y(new_n217_));
  OR3x1_ASAP7_75t_R   g196(.A(\totalcoeffs[3] ), .B(\trailingones[0] ), .C(new_n217_), .Y(new_n218_));
  AOI21x1_ASAP7_75t_R g197(.A1(new_n215_), .A2(new_n218_), .B(\totalcoeffs[2] ), .Y(new_n219_));
  AOI21x1_ASAP7_75t_R g198(.A1(\totalcoeffs[3] ), .A2(new_n213_), .B(new_n219_), .Y(new_n220_));
  OR3x1_ASAP7_75t_R   g199(.A(\ctable[0] ), .B(new_n31_), .C(new_n220_), .Y(new_n221_));
  AND3x1_ASAP7_75t_R  g200(.A(\ctable[0] ), .B(new_n210_), .C(new_n190_), .Y(new_n222_));
  NOR2x1_ASAP7_75t_R  g201(.A(\ctable[0] ), .B(new_n71_), .Y(new_n223_));
  OR3x1_ASAP7_75t_R   g202(.A(new_n22_), .B(new_n223_), .C(new_n222_), .Y(new_n224_));
  NOR2x1_ASAP7_75t_R  g203(.A(new_n29_), .B(new_n30_), .Y(new_n225_));
  AO21x1_ASAP7_75t_R  g204(.A1(\trailingones[0] ), .A2(\trailingones[1] ), .B(new_n209_), .Y(new_n226_));
  INVx1_ASAP7_75t_R   g205(.A(new_n226_), .Y(new_n227_));
  AO21x1_ASAP7_75t_R  g206(.A1(new_n73_), .A2(new_n226_), .B(new_n23_), .Y(new_n228_));
  AO21x1_ASAP7_75t_R  g207(.A1(new_n224_), .A2(new_n228_), .B(\totalcoeffs[3] ), .Y(new_n229_));
  OR3x1_ASAP7_75t_R   g208(.A(new_n30_), .B(new_n45_), .C(new_n141_), .Y(new_n230_));
  NOR2x1_ASAP7_75t_R  g209(.A(new_n26_), .B(new_n164_), .Y(new_n231_));
  OR3x1_ASAP7_75t_R   g210(.A(\totalcoeffs[2] ), .B(new_n210_), .C(new_n231_), .Y(new_n232_));
  AO21x1_ASAP7_75t_R  g211(.A1(new_n230_), .A2(new_n232_), .B(new_n31_), .Y(new_n233_));
  AO21x1_ASAP7_75t_R  g212(.A1(new_n229_), .A2(new_n233_), .B(\ctable[1] ), .Y(new_n234_));
  AO21x1_ASAP7_75t_R  g213(.A1(new_n221_), .A2(new_n234_), .B(\totalcoeffs[4] ), .Y(new_n235_));
  NOR2x1_ASAP7_75t_R  g214(.A(new_n27_), .B(\trailingones[0] ), .Y(new_n236_));
  INVx1_ASAP7_75t_R   g215(.A(new_n236_), .Y(new_n237_));
  OA21x2_ASAP7_75t_R  g216(.A1(new_n225_), .A2(new_n236_), .B(new_n26_), .Y(new_n238_));
  OR3x1_ASAP7_75t_R   g217(.A(\totalcoeffs[1] ), .B(\totalcoeffs[3] ), .C(\totalcoeffs[2] ), .Y(new_n239_));
  OA21x2_ASAP7_75t_R  g218(.A1(new_n238_), .A2(new_n239_), .B(\totalcoeffs[4] ), .Y(new_n240_));
  NOR2x1_ASAP7_75t_R  g219(.A(\ctable[0] ), .B(new_n27_), .Y(new_n241_));
  AND3x1_ASAP7_75t_R  g220(.A(new_n26_), .B(\ctable[1] ), .C(new_n24_), .Y(new_n242_));
  NAND2x1_ASAP7_75t_R g221(.A(\totalcoeffs[2] ), .B(new_n26_), .Y(new_n243_));
  AO21x1_ASAP7_75t_R  g222(.A1(\totalcoeffs[3] ), .A2(new_n243_), .B(new_n29_), .Y(new_n244_));
  AO21x1_ASAP7_75t_R  g223(.A1(\totalcoeffs[3] ), .A2(new_n125_), .B(new_n26_), .Y(new_n245_));
  AOI21x1_ASAP7_75t_R g224(.A1(new_n244_), .A2(new_n245_), .B(new_n22_), .Y(new_n246_));
  AO21x1_ASAP7_75t_R  g225(.A1(new_n139_), .A2(new_n242_), .B(new_n246_), .Y(new_n247_));
  AOI21x1_ASAP7_75t_R g226(.A1(\totalcoeffs[2] ), .A2(new_n111_), .B(new_n22_), .Y(new_n248_));
  OR3x1_ASAP7_75t_R   g227(.A(new_n26_), .B(new_n153_), .C(new_n248_), .Y(new_n249_));
  INVx1_ASAP7_75t_R   g228(.A(new_n249_), .Y(new_n250_));
  AND3x1_ASAP7_75t_R  g229(.A(new_n24_), .B(\trailingones[1] ), .C(\totalcoeffs[1] ), .Y(new_n251_));
  AO21x1_ASAP7_75t_R  g230(.A1(new_n236_), .A2(new_n251_), .B(\totalcoeffs[4] ), .Y(new_n252_));
  NAND2x1_ASAP7_75t_R g231(.A(\totalcoeffs[3] ), .B(new_n29_), .Y(new_n253_));
  NOR2x1_ASAP7_75t_R  g232(.A(new_n24_), .B(\trailingones[1] ), .Y(new_n254_));
  AO21x1_ASAP7_75t_R  g233(.A1(\totalcoeffs[3] ), .A2(new_n30_), .B(\ctable[1] ), .Y(new_n255_));
  AOI21x1_ASAP7_75t_R g234(.A1(new_n56_), .A2(new_n253_), .B(new_n255_), .Y(new_n256_));
  OR3x1_ASAP7_75t_R   g235(.A(new_n252_), .B(new_n256_), .C(new_n250_), .Y(new_n257_));
  AO21x1_ASAP7_75t_R  g236(.A1(\totalcoeffs[1] ), .A2(\trailingones[0] ), .B(new_n27_), .Y(new_n258_));
  AOI21x1_ASAP7_75t_R g237(.A1(new_n30_), .A2(new_n258_), .B(\totalcoeffs[2] ), .Y(new_n259_));
  AO21x1_ASAP7_75t_R  g238(.A1(new_n29_), .A2(new_n65_), .B(new_n259_), .Y(new_n260_));
  AO21x1_ASAP7_75t_R  g239(.A1(\totalcoeffs[3] ), .A2(new_n260_), .B(new_n257_), .Y(new_n261_));
  AOI21x1_ASAP7_75t_R g240(.A1(new_n30_), .A2(new_n247_), .B(new_n261_), .Y(new_n262_));
  OR3x1_ASAP7_75t_R   g241(.A(\totalcoeffs[0] ), .B(new_n240_), .C(new_n262_), .Y(new_n263_));
  AOI21x1_ASAP7_75t_R g242(.A1(new_n235_), .A2(new_n263_), .B(\ctable[2] ), .Y(new_n264_));
  NOR2x1_ASAP7_75t_R  g243(.A(\ctable[0] ), .B(\ctable[1] ), .Y(new_n265_));
  INVx1_ASAP7_75t_R   g244(.A(new_n265_), .Y(new_n266_));
  AND3x1_ASAP7_75t_R  g245(.A(new_n25_), .B(new_n45_), .C(new_n265_), .Y(new_n267_));
  AO21x1_ASAP7_75t_R  g246(.A1(\ctable[2] ), .A2(new_n225_), .B(new_n31_), .Y(new_n268_));
  AND3x1_ASAP7_75t_R  g247(.A(\totalcoeffs[1] ), .B(new_n61_), .C(new_n268_), .Y(new_n269_));
  AO21x1_ASAP7_75t_R  g248(.A1(new_n57_), .A2(new_n139_), .B(new_n269_), .Y(new_n270_));
  AO21x1_ASAP7_75t_R  g249(.A1(new_n267_), .A2(new_n270_), .B(new_n264_), .Y(\coeff_token[2] ));
  NAND2x1_ASAP7_75t_R g250(.A(new_n24_), .B(\totalcoeffs[4] ), .Y(new_n272_));
  OR3x1_ASAP7_75t_R   g251(.A(\totalcoeffs[1] ), .B(\totalcoeffs[2] ), .C(new_n272_), .Y(new_n273_));
  NOR2x1_ASAP7_75t_R  g252(.A(\ctable[0] ), .B(new_n225_), .Y(new_n274_));
  NOR2x1_ASAP7_75t_R  g253(.A(new_n273_), .B(new_n274_), .Y(new_n275_));
  OA21x2_ASAP7_75t_R  g254(.A1(new_n116_), .A2(new_n265_), .B(new_n275_), .Y(new_n276_));
  AOI21x1_ASAP7_75t_R g255(.A1(new_n24_), .A2(new_n237_), .B(new_n112_), .Y(new_n277_));
  AND3x1_ASAP7_75t_R  g256(.A(\ctable[0] ), .B(\trailingones[1] ), .C(\trailingones[0] ), .Y(new_n278_));
  AO21x1_ASAP7_75t_R  g257(.A1(new_n27_), .A2(new_n278_), .B(new_n185_), .Y(new_n279_));
  AO21x1_ASAP7_75t_R  g258(.A1(\totalcoeffs[2] ), .A2(new_n279_), .B(new_n277_), .Y(new_n280_));
  AO21x1_ASAP7_75t_R  g259(.A1(\ctable[1] ), .A2(new_n46_), .B(new_n254_), .Y(new_n281_));
  AND3x1_ASAP7_75t_R  g260(.A(new_n26_), .B(\ctable[1] ), .C(\totalcoeffs[2] ), .Y(new_n282_));
  AO21x1_ASAP7_75t_R  g261(.A1(new_n22_), .A2(new_n281_), .B(new_n282_), .Y(new_n283_));
  AO21x1_ASAP7_75t_R  g262(.A1(\totalcoeffs[1] ), .A2(new_n280_), .B(new_n283_), .Y(new_n284_));
  AO21x1_ASAP7_75t_R  g263(.A1(new_n25_), .A2(new_n284_), .B(new_n276_), .Y(new_n285_));
  NAND2x1_ASAP7_75t_R g264(.A(\totalcoeffs[3] ), .B(new_n27_), .Y(new_n286_));
  OR3x1_ASAP7_75t_R   g265(.A(\ctable[0] ), .B(new_n27_), .C(\trailingones[1] ), .Y(new_n287_));
  AOI21x1_ASAP7_75t_R g266(.A1(new_n286_), .A2(new_n287_), .B(\trailingones[0] ), .Y(new_n288_));
  AND3x1_ASAP7_75t_R  g267(.A(\totalcoeffs[3] ), .B(new_n27_), .C(\totalcoeffs[2] ), .Y(new_n289_));
  AO21x1_ASAP7_75t_R  g268(.A1(new_n46_), .A2(new_n241_), .B(new_n289_), .Y(new_n290_));
  AO21x1_ASAP7_75t_R  g269(.A1(\trailingones[1] ), .A2(new_n290_), .B(new_n288_), .Y(new_n291_));
  AO21x1_ASAP7_75t_R  g270(.A1(\ctable[0] ), .A2(\trailingones[1] ), .B(\ctable[1] ), .Y(new_n292_));
  INVx1_ASAP7_75t_R   g271(.A(new_n292_), .Y(new_n293_));
  AO21x1_ASAP7_75t_R  g272(.A1(\ctable[0] ), .A2(\trailingones[0] ), .B(new_n207_), .Y(new_n294_));
  AOI21x1_ASAP7_75t_R g273(.A1(new_n37_), .A2(new_n174_), .B(\totalcoeffs[2] ), .Y(new_n295_));
  AO21x1_ASAP7_75t_R  g274(.A1(new_n293_), .A2(new_n294_), .B(new_n295_), .Y(new_n296_));
  OR3x1_ASAP7_75t_R   g275(.A(new_n22_), .B(new_n29_), .C(new_n287_), .Y(new_n297_));
  INVx1_ASAP7_75t_R   g276(.A(new_n297_), .Y(new_n298_));
  AO21x1_ASAP7_75t_R  g277(.A1(\totalcoeffs[3] ), .A2(new_n296_), .B(new_n298_), .Y(new_n299_));
  AOI21x1_ASAP7_75t_R g278(.A1(new_n22_), .A2(new_n291_), .B(new_n299_), .Y(new_n300_));
  AO21x1_ASAP7_75t_R  g279(.A1(new_n134_), .A2(new_n151_), .B(new_n242_), .Y(new_n301_));
  NAND2x1_ASAP7_75t_R g280(.A(new_n30_), .B(new_n301_), .Y(new_n302_));
  NOR2x1_ASAP7_75t_R  g281(.A(\totalcoeffs[2] ), .B(new_n26_), .Y(new_n303_));
  OR3x1_ASAP7_75t_R   g282(.A(\totalcoeffs[2] ), .B(new_n26_), .C(new_n29_), .Y(new_n304_));
  AO21x1_ASAP7_75t_R  g283(.A1(new_n147_), .A2(new_n148_), .B(new_n23_), .Y(new_n305_));
  AO21x1_ASAP7_75t_R  g284(.A1(new_n304_), .A2(new_n305_), .B(\trailingones[1] ), .Y(new_n306_));
  AO21x1_ASAP7_75t_R  g285(.A1(\ctable[0] ), .A2(new_n181_), .B(\totalcoeffs[3] ), .Y(new_n307_));
  NOR2x1_ASAP7_75t_R  g286(.A(new_n24_), .B(\ctable[0] ), .Y(new_n308_));
  INVx1_ASAP7_75t_R   g287(.A(new_n308_), .Y(new_n309_));
  AOI21x1_ASAP7_75t_R g288(.A1(new_n27_), .A2(new_n253_), .B(new_n308_), .Y(new_n310_));
  AOI21x1_ASAP7_75t_R g289(.A1(new_n23_), .A2(new_n307_), .B(new_n310_), .Y(new_n311_));
  AO21x1_ASAP7_75t_R  g290(.A1(new_n306_), .A2(new_n311_), .B(new_n22_), .Y(new_n312_));
  AO21x1_ASAP7_75t_R  g291(.A1(new_n302_), .A2(new_n312_), .B(new_n31_), .Y(new_n313_));
  AOI21x1_ASAP7_75t_R g292(.A1(new_n300_), .A2(new_n313_), .B(\totalcoeffs[4] ), .Y(new_n314_));
  AOI21x1_ASAP7_75t_R g293(.A1(new_n31_), .A2(new_n285_), .B(new_n314_), .Y(new_n315_));
  NOR2x1_ASAP7_75t_R  g294(.A(\ctable[2] ), .B(new_n315_), .Y(\coeff_token[3] ));
  OR3x1_ASAP7_75t_R   g295(.A(new_n26_), .B(new_n27_), .C(\ctable[2] ), .Y(new_n317_));
  NAND2x1_ASAP7_75t_R g296(.A(\totalcoeffs[3] ), .B(new_n25_), .Y(new_n318_));
  AOI21x1_ASAP7_75t_R g297(.A1(new_n272_), .A2(new_n318_), .B(new_n198_), .Y(new_n319_));
  AOI21x1_ASAP7_75t_R g298(.A1(new_n25_), .A2(new_n126_), .B(new_n319_), .Y(new_n320_));
  NOR2x1_ASAP7_75t_R  g299(.A(new_n317_), .B(new_n320_), .Y(\coeff_token[4] ));
  OR3x1_ASAP7_75t_R   g300(.A(\totalcoeffs[3] ), .B(new_n25_), .C(new_n198_), .Y(new_n322_));
  OR3x1_ASAP7_75t_R   g301(.A(new_n24_), .B(\totalcoeffs[4] ), .C(new_n199_), .Y(new_n323_));
  AOI21x1_ASAP7_75t_R g302(.A1(new_n322_), .A2(new_n323_), .B(new_n317_), .Y(\coeff_token[5] ));
  OA21x2_ASAP7_75t_R  g303(.A1(new_n22_), .A2(new_n190_), .B(new_n210_), .Y(new_n325_));
  OR3x1_ASAP7_75t_R   g304(.A(\totalcoeffs[2] ), .B(new_n28_), .C(new_n325_), .Y(new_n326_));
  OA21x2_ASAP7_75t_R  g305(.A1(new_n28_), .A2(\trailingones[1] ), .B(\trailingones[0] ), .Y(new_n327_));
  OR3x1_ASAP7_75t_R   g306(.A(\totalcoeffs[1] ), .B(new_n23_), .C(new_n327_), .Y(new_n328_));
  AO21x1_ASAP7_75t_R  g307(.A1(new_n88_), .A2(new_n328_), .B(\totalcoeffs[0] ), .Y(new_n329_));
  AO21x1_ASAP7_75t_R  g308(.A1(new_n326_), .A2(new_n329_), .B(new_n266_), .Y(new_n330_));
  NOR2x1_ASAP7_75t_R  g309(.A(new_n23_), .B(\totalcoeffs[0] ), .Y(new_n331_));
  INVx1_ASAP7_75t_R   g310(.A(new_n331_), .Y(new_n332_));
  OR3x1_ASAP7_75t_R   g311(.A(new_n23_), .B(\totalcoeffs[0] ), .C(new_n36_), .Y(new_n333_));
  OR3x1_ASAP7_75t_R   g312(.A(new_n22_), .B(new_n30_), .C(new_n26_), .Y(new_n334_));
  NAND2x1_ASAP7_75t_R g313(.A(new_n22_), .B(new_n26_), .Y(new_n335_));
  AO21x1_ASAP7_75t_R  g314(.A1(\totalcoeffs[2] ), .A2(new_n335_), .B(new_n114_), .Y(new_n336_));
  AO21x1_ASAP7_75t_R  g315(.A1(new_n334_), .A2(new_n336_), .B(new_n31_), .Y(new_n337_));
  AO21x1_ASAP7_75t_R  g316(.A1(new_n333_), .A2(new_n337_), .B(new_n29_), .Y(new_n338_));
  AND3x1_ASAP7_75t_R  g317(.A(\totalcoeffs[2] ), .B(new_n31_), .C(\trailingones[1] ), .Y(new_n339_));
  AO21x1_ASAP7_75t_R  g318(.A1(new_n29_), .A2(new_n72_), .B(new_n339_), .Y(new_n340_));
  AO21x1_ASAP7_75t_R  g319(.A1(\totalcoeffs[2] ), .A2(\trailingones[0] ), .B(new_n150_), .Y(new_n341_));
  AND3x1_ASAP7_75t_R  g320(.A(\ctable[1] ), .B(new_n226_), .C(new_n341_), .Y(new_n342_));
  AOI21x1_ASAP7_75t_R g321(.A1(\ctable[0] ), .A2(new_n340_), .B(new_n342_), .Y(new_n343_));
  AO21x1_ASAP7_75t_R  g322(.A1(new_n338_), .A2(new_n343_), .B(\ctable[2] ), .Y(new_n344_));
  AOI21x1_ASAP7_75t_R g323(.A1(new_n330_), .A2(new_n344_), .B(\totalcoeffs[3] ), .Y(new_n345_));
  OR3x1_ASAP7_75t_R   g324(.A(new_n22_), .B(\trailingones[1] ), .C(new_n156_), .Y(new_n346_));
  AOI21x1_ASAP7_75t_R g325(.A1(new_n29_), .A2(new_n31_), .B(new_n346_), .Y(new_n347_));
  AND3x1_ASAP7_75t_R  g326(.A(\totalcoeffs[1] ), .B(new_n29_), .C(new_n332_), .Y(new_n348_));
  AND3x1_ASAP7_75t_R  g327(.A(\ctable[1] ), .B(\trailingones[0] ), .C(\totalcoeffs[0] ), .Y(new_n349_));
  AO21x1_ASAP7_75t_R  g328(.A1(new_n23_), .A2(new_n349_), .B(new_n348_), .Y(new_n350_));
  AO21x1_ASAP7_75t_R  g329(.A1(\trailingones[1] ), .A2(new_n350_), .B(new_n347_), .Y(new_n351_));
  AO21x1_ASAP7_75t_R  g330(.A1(new_n29_), .A2(new_n30_), .B(\totalcoeffs[1] ), .Y(new_n352_));
  AO21x1_ASAP7_75t_R  g331(.A1(new_n22_), .A2(new_n210_), .B(new_n31_), .Y(new_n353_));
  INVx1_ASAP7_75t_R   g332(.A(new_n353_), .Y(new_n354_));
  OR3x1_ASAP7_75t_R   g333(.A(\ctable[1] ), .B(\totalcoeffs[0] ), .C(new_n139_), .Y(new_n355_));
  AOI21x1_ASAP7_75t_R g334(.A1(new_n52_), .A2(new_n355_), .B(new_n216_), .Y(new_n356_));
  AO21x1_ASAP7_75t_R  g335(.A1(new_n56_), .A2(new_n354_), .B(new_n356_), .Y(new_n357_));
  AO21x1_ASAP7_75t_R  g336(.A1(new_n26_), .A2(new_n357_), .B(new_n351_), .Y(new_n358_));
  OR3x1_ASAP7_75t_R   g337(.A(new_n23_), .B(new_n29_), .C(new_n61_), .Y(new_n359_));
  NOR2x1_ASAP7_75t_R  g338(.A(\totalcoeffs[2] ), .B(\trailingones[1] ), .Y(new_n360_));
  OAI21x1_ASAP7_75t_R g339(.A1(new_n26_), .A2(new_n29_), .B(new_n360_), .Y(new_n361_));
  AO21x1_ASAP7_75t_R  g340(.A1(new_n31_), .A2(new_n237_), .B(new_n361_), .Y(new_n362_));
  AOI21x1_ASAP7_75t_R g341(.A1(new_n359_), .A2(new_n362_), .B(\totalcoeffs[1] ), .Y(new_n363_));
  AO21x1_ASAP7_75t_R  g342(.A1(new_n29_), .A2(new_n30_), .B(new_n23_), .Y(new_n364_));
  AOI21x1_ASAP7_75t_R g343(.A1(new_n190_), .A2(new_n364_), .B(new_n27_), .Y(new_n365_));
  AOI21x1_ASAP7_75t_R g344(.A1(new_n27_), .A2(new_n243_), .B(new_n61_), .Y(new_n366_));
  AO21x1_ASAP7_75t_R  g345(.A1(new_n99_), .A2(new_n303_), .B(new_n366_), .Y(new_n367_));
  AO21x1_ASAP7_75t_R  g346(.A1(new_n29_), .A2(new_n367_), .B(new_n365_), .Y(new_n368_));
  AO21x1_ASAP7_75t_R  g347(.A1(\totalcoeffs[1] ), .A2(new_n368_), .B(new_n363_), .Y(new_n369_));
  AO21x1_ASAP7_75t_R  g348(.A1(\totalcoeffs[3] ), .A2(new_n358_), .B(new_n369_), .Y(new_n370_));
  AO21x1_ASAP7_75t_R  g349(.A1(new_n28_), .A2(new_n370_), .B(new_n345_), .Y(new_n371_));
  OR3x1_ASAP7_75t_R   g350(.A(new_n25_), .B(new_n33_), .C(new_n46_), .Y(new_n372_));
  INVx1_ASAP7_75t_R   g351(.A(new_n372_), .Y(new_n373_));
  OA21x2_ASAP7_75t_R  g352(.A1(new_n116_), .A2(new_n373_), .B(new_n28_), .Y(new_n374_));
  AOI21x1_ASAP7_75t_R g353(.A1(new_n25_), .A2(new_n371_), .B(new_n374_), .Y(\ctoken_len[0] ));
  OR3x1_ASAP7_75t_R   g354(.A(\ctable[0] ), .B(\ctable[2] ), .C(new_n322_), .Y(new_n376_));
  AND3x1_ASAP7_75t_R  g355(.A(\totalcoeffs[3] ), .B(new_n150_), .C(new_n117_), .Y(new_n377_));
  OR3x1_ASAP7_75t_R   g356(.A(\ctable[1] ), .B(new_n225_), .C(new_n85_), .Y(new_n378_));
  OAI21x1_ASAP7_75t_R g357(.A1(new_n172_), .A2(new_n227_), .B(new_n378_), .Y(new_n379_));
  AOI21x1_ASAP7_75t_R g358(.A1(new_n27_), .A2(new_n147_), .B(new_n364_), .Y(new_n380_));
  AO21x1_ASAP7_75t_R  g359(.A1(new_n31_), .A2(new_n150_), .B(new_n349_), .Y(new_n381_));
  AO21x1_ASAP7_75t_R  g360(.A1(new_n30_), .A2(new_n381_), .B(new_n380_), .Y(new_n382_));
  AO21x1_ASAP7_75t_R  g361(.A1(\totalcoeffs[3] ), .A2(new_n379_), .B(new_n382_), .Y(new_n383_));
  AOI21x1_ASAP7_75t_R g362(.A1(new_n22_), .A2(new_n383_), .B(new_n377_), .Y(new_n384_));
  AO21x1_ASAP7_75t_R  g363(.A1(\trailingones[0] ), .A2(\trailingones[1] ), .B(new_n24_), .Y(new_n385_));
  AO21x1_ASAP7_75t_R  g364(.A1(new_n189_), .A2(new_n385_), .B(\ctable[1] ), .Y(new_n386_));
  OR3x1_ASAP7_75t_R   g365(.A(new_n29_), .B(new_n30_), .C(\totalcoeffs[3] ), .Y(new_n387_));
  AO21x1_ASAP7_75t_R  g366(.A1(new_n386_), .A2(new_n387_), .B(new_n23_), .Y(new_n388_));
  AOI21x1_ASAP7_75t_R g367(.A1(\totalcoeffs[0] ), .A2(new_n286_), .B(new_n117_), .Y(new_n389_));
  AO21x1_ASAP7_75t_R  g368(.A1(new_n29_), .A2(new_n178_), .B(new_n389_), .Y(new_n390_));
  OR3x1_ASAP7_75t_R   g369(.A(new_n29_), .B(\totalcoeffs[0] ), .C(new_n286_), .Y(new_n391_));
  AO21x1_ASAP7_75t_R  g370(.A1(new_n237_), .A2(new_n391_), .B(new_n30_), .Y(new_n392_));
  AOI21x1_ASAP7_75t_R g371(.A1(new_n390_), .A2(new_n392_), .B(\totalcoeffs[2] ), .Y(new_n393_));
  AOI21x1_ASAP7_75t_R g372(.A1(new_n113_), .A2(new_n146_), .B(new_n393_), .Y(new_n394_));
  AO21x1_ASAP7_75t_R  g373(.A1(new_n388_), .A2(new_n394_), .B(new_n22_), .Y(new_n395_));
  AO21x1_ASAP7_75t_R  g374(.A1(new_n384_), .A2(new_n395_), .B(\ctable[0] ), .Y(new_n396_));
  AO21x1_ASAP7_75t_R  g375(.A1(\totalcoeffs[3] ), .A2(\totalcoeffs[0] ), .B(\totalcoeffs[2] ), .Y(new_n397_));
  AO21x1_ASAP7_75t_R  g376(.A1(\totalcoeffs[2] ), .A2(\totalcoeffs[3] ), .B(new_n226_), .Y(new_n398_));
  AND3x1_ASAP7_75t_R  g377(.A(\ctable[0] ), .B(new_n397_), .C(new_n398_), .Y(new_n399_));
  AO21x1_ASAP7_75t_R  g378(.A1(new_n44_), .A2(new_n211_), .B(new_n399_), .Y(new_n400_));
  AND3x1_ASAP7_75t_R  g379(.A(\totalcoeffs[2] ), .B(\totalcoeffs[3] ), .C(new_n278_), .Y(new_n401_));
  AOI21x1_ASAP7_75t_R g380(.A1(new_n22_), .A2(new_n400_), .B(new_n401_), .Y(new_n402_));
  NOR2x1_ASAP7_75t_R  g381(.A(new_n24_), .B(new_n26_), .Y(new_n403_));
  INVx1_ASAP7_75t_R   g382(.A(new_n403_), .Y(new_n404_));
  AOI21x1_ASAP7_75t_R g383(.A1(new_n32_), .A2(new_n404_), .B(\totalcoeffs[0] ), .Y(new_n405_));
  AO21x1_ASAP7_75t_R  g384(.A1(\totalcoeffs[3] ), .A2(new_n303_), .B(new_n405_), .Y(new_n406_));
  AND3x1_ASAP7_75t_R  g385(.A(new_n23_), .B(new_n30_), .C(new_n403_), .Y(new_n407_));
  AOI21x1_ASAP7_75t_R g386(.A1(new_n29_), .A2(new_n406_), .B(new_n407_), .Y(new_n408_));
  OR3x1_ASAP7_75t_R   g387(.A(new_n31_), .B(new_n71_), .C(new_n360_), .Y(new_n409_));
  OR3x1_ASAP7_75t_R   g388(.A(new_n26_), .B(\totalcoeffs[0] ), .C(\trailingones[1] ), .Y(new_n410_));
  AO21x1_ASAP7_75t_R  g389(.A1(new_n409_), .A2(new_n410_), .B(new_n29_), .Y(new_n411_));
  NAND2x1_ASAP7_75t_R g390(.A(new_n71_), .B(new_n168_), .Y(new_n412_));
  AO21x1_ASAP7_75t_R  g391(.A1(new_n411_), .A2(new_n412_), .B(\totalcoeffs[3] ), .Y(new_n413_));
  AO21x1_ASAP7_75t_R  g392(.A1(new_n408_), .A2(new_n413_), .B(new_n22_), .Y(new_n414_));
  AO21x1_ASAP7_75t_R  g393(.A1(new_n402_), .A2(new_n414_), .B(\ctable[1] ), .Y(new_n415_));
  AO21x1_ASAP7_75t_R  g394(.A1(new_n396_), .A2(new_n415_), .B(\ctable[2] ), .Y(new_n416_));
  OR3x1_ASAP7_75t_R   g395(.A(\totalcoeffs[2] ), .B(new_n31_), .C(new_n29_), .Y(new_n417_));
  OR3x1_ASAP7_75t_R   g396(.A(new_n28_), .B(\trailingones[1] ), .C(new_n417_), .Y(new_n418_));
  OA21x2_ASAP7_75t_R  g397(.A1(new_n226_), .A2(new_n332_), .B(new_n418_), .Y(new_n419_));
  OR3x1_ASAP7_75t_R   g398(.A(new_n110_), .B(new_n266_), .C(new_n419_), .Y(new_n420_));
  AO21x1_ASAP7_75t_R  g399(.A1(new_n416_), .A2(new_n420_), .B(\totalcoeffs[4] ), .Y(new_n421_));
  OA21x2_ASAP7_75t_R  g400(.A1(\ctable[1] ), .A2(new_n376_), .B(new_n421_), .Y(\ctoken_len[1] ));
  AND3x1_ASAP7_75t_R  g401(.A(new_n31_), .B(new_n150_), .C(new_n207_), .Y(new_n423_));
  AND3x1_ASAP7_75t_R  g402(.A(\trailingones[1] ), .B(new_n331_), .C(new_n29_), .Y(new_n424_));
  AO21x1_ASAP7_75t_R  g403(.A1(new_n31_), .A2(new_n341_), .B(new_n157_), .Y(new_n425_));
  AO21x1_ASAP7_75t_R  g404(.A1(new_n30_), .A2(new_n425_), .B(new_n424_), .Y(new_n426_));
  AO21x1_ASAP7_75t_R  g405(.A1(new_n22_), .A2(new_n426_), .B(new_n423_), .Y(new_n427_));
  AND2x2_ASAP7_75t_R  g406(.A(new_n27_), .B(new_n78_), .Y(new_n428_));
  AO21x1_ASAP7_75t_R  g407(.A1(new_n56_), .A2(new_n136_), .B(new_n214_), .Y(new_n429_));
  AO21x1_ASAP7_75t_R  g408(.A1(new_n23_), .A2(new_n429_), .B(new_n309_), .Y(new_n430_));
  AO21x1_ASAP7_75t_R  g409(.A1(new_n353_), .A2(new_n428_), .B(new_n430_), .Y(new_n431_));
  AO21x1_ASAP7_75t_R  g410(.A1(\totalcoeffs[1] ), .A2(\ctable[0] ), .B(new_n308_), .Y(new_n432_));
  AO21x1_ASAP7_75t_R  g411(.A1(new_n22_), .A2(new_n30_), .B(\totalcoeffs[2] ), .Y(new_n433_));
  AO21x1_ASAP7_75t_R  g412(.A1(new_n24_), .A2(\trailingones[1] ), .B(new_n433_), .Y(new_n434_));
  OR3x1_ASAP7_75t_R   g413(.A(new_n96_), .B(new_n308_), .C(new_n434_), .Y(new_n435_));
  AO21x1_ASAP7_75t_R  g414(.A1(new_n72_), .A2(new_n303_), .B(new_n251_), .Y(new_n436_));
  AOI21x1_ASAP7_75t_R g415(.A1(new_n217_), .A2(new_n335_), .B(new_n76_), .Y(new_n437_));
  AOI21x1_ASAP7_75t_R g416(.A1(new_n31_), .A2(new_n436_), .B(new_n437_), .Y(new_n438_));
  AO21x1_ASAP7_75t_R  g417(.A1(new_n435_), .A2(new_n438_), .B(\trailingones[0] ), .Y(new_n439_));
  OR3x1_ASAP7_75t_R   g418(.A(new_n125_), .B(new_n155_), .C(new_n165_), .Y(new_n440_));
  AO21x1_ASAP7_75t_R  g419(.A1(\totalcoeffs[3] ), .A2(new_n125_), .B(new_n22_), .Y(new_n441_));
  AO21x1_ASAP7_75t_R  g420(.A1(new_n243_), .A2(new_n404_), .B(new_n441_), .Y(new_n442_));
  AOI21x1_ASAP7_75t_R g421(.A1(new_n440_), .A2(new_n442_), .B(new_n30_), .Y(new_n443_));
  OR3x1_ASAP7_75t_R   g422(.A(\totalcoeffs[2] ), .B(new_n90_), .C(new_n432_), .Y(new_n444_));
  INVx1_ASAP7_75t_R   g423(.A(new_n444_), .Y(new_n445_));
  AO21x1_ASAP7_75t_R  g424(.A1(new_n109_), .A2(new_n156_), .B(new_n445_), .Y(new_n446_));
  AO21x1_ASAP7_75t_R  g425(.A1(\trailingones[0] ), .A2(new_n31_), .B(\ctable[0] ), .Y(new_n447_));
  AND3x1_ASAP7_75t_R  g426(.A(new_n51_), .B(new_n404_), .C(new_n447_), .Y(new_n448_));
  AO21x1_ASAP7_75t_R  g427(.A1(\trailingones[0] ), .A2(new_n446_), .B(new_n448_), .Y(new_n449_));
  AOI21x1_ASAP7_75t_R g428(.A1(new_n30_), .A2(new_n449_), .B(new_n443_), .Y(new_n450_));
  AO21x1_ASAP7_75t_R  g429(.A1(new_n439_), .A2(new_n450_), .B(\ctable[1] ), .Y(new_n451_));
  AOI21x1_ASAP7_75t_R g430(.A1(new_n431_), .A2(new_n451_), .B(\ctable[2] ), .Y(new_n452_));
  AO21x1_ASAP7_75t_R  g431(.A1(new_n132_), .A2(new_n427_), .B(new_n452_), .Y(new_n453_));
  NAND2x1_ASAP7_75t_R g432(.A(new_n25_), .B(new_n453_), .Y(new_n454_));
  AND2x2_ASAP7_75t_R  g433(.A(new_n376_), .B(new_n454_), .Y(\ctoken_len[2] ));
  OA21x2_ASAP7_75t_R  g434(.A1(\ctable[1] ), .A2(new_n278_), .B(new_n24_), .Y(new_n456_));
  AO21x1_ASAP7_75t_R  g435(.A1(new_n274_), .A2(new_n289_), .B(new_n456_), .Y(new_n457_));
  AO21x1_ASAP7_75t_R  g436(.A1(\ctable[1] ), .A2(\trailingones[1] ), .B(new_n24_), .Y(new_n458_));
  AND3x1_ASAP7_75t_R  g437(.A(\trailingones[0] ), .B(new_n31_), .C(new_n458_), .Y(new_n459_));
  AO21x1_ASAP7_75t_R  g438(.A1(new_n24_), .A2(new_n37_), .B(new_n459_), .Y(new_n460_));
  AO21x1_ASAP7_75t_R  g439(.A1(new_n23_), .A2(new_n460_), .B(new_n457_), .Y(new_n461_));
  AOI21x1_ASAP7_75t_R g440(.A1(new_n28_), .A2(new_n239_), .B(new_n31_), .Y(new_n462_));
  AND2x2_ASAP7_75t_R  g441(.A(\ctable[2] ), .B(new_n76_), .Y(new_n463_));
  AO21x1_ASAP7_75t_R  g442(.A1(\totalcoeffs[4] ), .A2(new_n239_), .B(new_n463_), .Y(new_n464_));
  AOI21x1_ASAP7_75t_R g443(.A1(new_n26_), .A2(new_n76_), .B(new_n27_), .Y(new_n465_));
  OR3x1_ASAP7_75t_R   g444(.A(new_n464_), .B(new_n465_), .C(new_n462_), .Y(new_n466_));
  AO21x1_ASAP7_75t_R  g445(.A1(new_n156_), .A2(new_n289_), .B(\ctable[2] ), .Y(new_n467_));
  AO21x1_ASAP7_75t_R  g446(.A1(new_n352_), .A2(new_n467_), .B(new_n466_), .Y(new_n468_));
  AO21x1_ASAP7_75t_R  g447(.A1(\totalcoeffs[1] ), .A2(new_n461_), .B(new_n468_), .Y(new_n469_));
  AO21x1_ASAP7_75t_R  g448(.A1(new_n136_), .A2(new_n292_), .B(new_n458_), .Y(new_n470_));
  OA21x2_ASAP7_75t_R  g449(.A1(new_n265_), .A2(new_n272_), .B(new_n23_), .Y(new_n471_));
  OR3x1_ASAP7_75t_R   g450(.A(new_n76_), .B(new_n209_), .C(new_n274_), .Y(new_n472_));
  INVx1_ASAP7_75t_R   g451(.A(new_n472_), .Y(new_n473_));
  AO21x1_ASAP7_75t_R  g452(.A1(new_n470_), .A2(new_n471_), .B(new_n473_), .Y(new_n474_));
  AOI21x1_ASAP7_75t_R g453(.A1(new_n22_), .A2(new_n474_), .B(new_n469_), .Y(\ctoken_len[3] ));
  OR3x1_ASAP7_75t_R   g454(.A(new_n23_), .B(new_n318_), .C(new_n59_), .Y(new_n476_));
  AO21x1_ASAP7_75t_R  g455(.A1(\trailingones[0] ), .A2(new_n62_), .B(new_n476_), .Y(new_n477_));
  NAND2x1_ASAP7_75t_R g456(.A(new_n322_), .B(new_n477_), .Y(new_n478_));
  AND3x1_ASAP7_75t_R  g457(.A(new_n28_), .B(new_n265_), .C(new_n478_), .Y(\ctoken_len[4] ));
endmodule


