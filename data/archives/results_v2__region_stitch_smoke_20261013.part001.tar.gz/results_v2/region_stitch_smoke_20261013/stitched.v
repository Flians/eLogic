module region_0(input n1, input n2, input n3, output n7, output n8);
assign n7 = n2 & n1;
assign n8 = n7 & n3;
endmodule
module region_1(input n4, input n5, input n8, output n9, output n10);
assign n9 = n8 & n4;
assign n10 = n9 & ~n5;
endmodule
module region_2(input n6, input n7, input n10, output n11, output n12);
assign n11 = n10 & n6;
assign n12 = n10 & n7;
endmodule
module mapped(input p0, input p1, input p2, input p3, input p4, input p5, output o0, output o1, output o2);
wire n1;
wire n2;
wire n3;
wire n4;
wire n5;
wire n6;
wire n7;
wire n8;
wire n9;
wire n10;
wire n11;
wire n12;
assign n1 = p0;
assign n2 = p1;
assign n3 = p2;
assign n4 = p3;
assign n5 = p4;
assign n6 = p5;
region_0 r0(.n1(n1), .n2(n2), .n3(n3), .n7(n7), .n8(n8));
region_1 r1(.n4(n4), .n5(n5), .n8(n8), .n9(n9), .n10(n10));
region_2 r2(.n6(n6), .n7(n7), .n10(n10), .n11(n11), .n12(n12));
assign o0 = n11;
assign o1 = n12;
assign o2 = ~n9;
endmodule
