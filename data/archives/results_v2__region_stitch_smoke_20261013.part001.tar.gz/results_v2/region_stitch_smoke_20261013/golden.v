module mapped(input p0,p1,p2,p3,p4,p5,output o0,o1,o2);wire a=p0&p1;wire b=a&p2;wire c=b&p3;wire d=c&~p4;wire e=d&p5;assign o0=e;assign o1=d&a;assign o2=~c;endmodule
