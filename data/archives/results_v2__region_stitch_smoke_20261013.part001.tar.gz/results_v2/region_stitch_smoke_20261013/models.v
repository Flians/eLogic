// logical prototype uses no physical cells
