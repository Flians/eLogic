//! Explicit anytime prototype: match newly admitted cuts and commit complete covers.
//! No archived netlists, count caps, per-round time renewals, or conditional unions.
use super::*;
use std::path::PathBuf;
#[cfg(test)] thread_local!{static TEST_ENABLED:std::cell::Cell<bool>=const{std::cell::Cell::new(false)};}
pub(super) fn enabled()->bool {
 #[cfg(test)] if TEST_ENABLED.with(|x|x.get()){return true}
 std::env::var("EGM_ONLINE_MAPPING").as_deref()==Ok("1")
}
pub(super) struct State {
    pool:Vec<Instance>,index:HashMap<InstanceKey,usize>,free:Vec<bool>,
    inputs:Vec<(usize,u32,String)>,outputs:Vec<(usize,String)>,constants:Vec<Option<bool>>,
    best:Option<MappedGraph>,best_global:Option<Vec<Option<Binding>>>,batches:usize,matched_cuts:usize,commits:usize,wide_done:bool,
}
impl State {
 pub(super) fn new(free:&[bool],inputs:&[(usize,u32,String)],outputs:&[(usize,String)],constants:&[Option<bool>])->Self {
  Self{pool:Vec::new(),index:HashMap::new(),free:free.to_vec(),inputs:inputs.to_vec(),outputs:outputs.to_vec(),constants:constants.to_vec(),best:None,best_global:None,batches:0,matched_cuts:0,commits:0,wide_done:false}
 }
 pub(super) fn consume(&mut self,bank:&[BTreeSet<Cut>],delta:&[BTreeSet<Cut>],interface_free:&[bool],interface_constants:&[Option<bool>],aliases:Option<(&[usize],&[bool])>,tech:&TechLib,ps:&MapParams,reach:&mut Reachability,stats:&mut MapStats){
  let end=crate::egraph_time_policy::deadline().expect("shared time-only window");
  if Instant::now()>=end{return}
  let added:usize=delta.iter().map(BTreeSet::len).sum();if added==0{return}
  self.batches+=1;self.matched_cuts+=added;stage_trace("online_delta_match_start");
  let mut batch=generate(delta,interface_free,interface_constants,tech,ps,reach,stats,aliases,Some(end));
  if let Some((canonical,_))=aliases{batch=normalize_generated_pool(batch,canonical,&self.free,ps,false,false);}
  for m in batch {let key=exchange::recorded_key(&m).unwrap_or_else(||instance_key(&m));insert_instance_key(&mut self.pool,&mut self.index,m,key);}
  stage_trace("online_delta_match_done");
  let roots:Vec<_>=self.outputs.iter().map(|v|v.0).collect();
  let Some((chosen,_))=delay_frontier_seed(&self.pool,&self.free,end)else{return};
  self.consider(bank,&roots,chosen,stats,end);
 }
 pub(super) fn consume_wide(&mut self,bank:&[BTreeSet<Cut>],nodes:&[Vec<AigLang>],dense:&impl Fn(Id)->usize,aliases:Option<(&[usize],&[bool])>,tech:&TechLib,ps:&MapParams,stats:&mut MapStats){
  if self.wide_done{return}let end=crate::egraph_time_policy::deadline().unwrap();if Instant::now()>=end{return}self.wide_done=true;
  stage_trace("online_wide_start");let mut batch=Vec::new();wide::generate(nodes,dense,tech,ps,&self.free,&self.constants,aliases,&mut batch,stats);
  for m in batch {let key=exchange::recorded_key(&m).unwrap_or_else(||instance_key(&m));insert_instance_key(&mut self.pool,&mut self.index,m,key);}
  stage_trace("online_wide_done");let roots:Vec<_>=self.outputs.iter().map(|v|v.0).collect();
  if let Some((chosen,_))=delay_frontier_seed(&self.pool,&self.free,end){self.consider(bank,&roots,chosen,stats,end);}
 }
 pub(super) fn ready_for_wide(&self)->bool{self.batches>=2}
 fn consider(&mut self,bank:&[BTreeSet<Cut>],roots:&[usize],chosen:Vec<Option<Binding>>,stats:&MapStats,end:Instant){
  if Instant::now()>=end{return}
  let Ok(cert)=exchange::ProtectedCover::capture(&self.pool,&chosen,&self.free,roots,bank)else{return};
  if self.best.as_ref().is_some_and(|old|!better_cover(cert.value,(old.area,old.delay),&MapParams{objective:MapObjective::DelayArea,..Default::default()})){return}
  let mut ids=HashMap::new();let mut instances=Vec::new();
  for &i in &cert.live {ids.insert(i,instances.len());instances.push(self.pool[i].clone());}
  let global_chosen=cert.chosen.clone();
  let chosen=cert.chosen.into_iter().map(|b|b.map(|b|Binding{instance:ids[&b.instance],pin:b.pin})).collect();
  let graph=MappedGraph{instances,chosen,inputs:self.inputs.clone(),outputs:self.outputs.clone(),constants:self.constants.clone(),area:cert.value.0,delay:cert.value.1,stats:stats.clone()};
  // Validate the compact index space before any disk publication.
  let mut check=graph.chosen.clone();if prune(&graph.instances,&mut check,&self.free,roots).is_err(){return}
  if metrics(&graph.instances,&check,&self.free,roots)!=(graph.area,graph.delay){return}
  if Instant::now()>=end{return}
  self.commits+=1;
  if let Err(error)=publish(&graph,self.commits,self.batches,self.matched_cuts,end){eprintln!("online publication failed: {error}");}
  self.best=Some(graph);self.best_global=Some(global_chosen);stage_trace("online_incumbent_validated");
 }
 // One exact selected-input shared-area sweep after cut closure. No extra clock.
 // Rejected proposals leave the complete prior incumbent unchanged.
 fn area_recover(&mut self,bank:&[BTreeSet<Cut>],stats:&MapStats){
  let Some(end)=crate::egraph_time_policy::deadline()else{return};
  let roots:Vec<_>=self.outputs.iter().map(|x|x.0).collect();stage_trace("online_actual_area_start");
  let mut cached=None;let mut i=0;while i<self.pool.len(){
   if Instant::now()>=end{break}
   let Some(chosen)=self.best_global.as_ref()else{break};let value=self.best.as_ref().map(|x|(x.area,x.delay)).unwrap();
   if cached.is_none(){let(refs,users)=shared_area_counters(&self.pool,chosen,&roots);let required=required_times(&self.pool,chosen,&self.free,&roots,value.1);let arrival=critical_arrivals(&self.pool,chosen,&self.free,&roots).0;cached=Some((refs,users,required,arrival));}
   let(refs,users,required,arrival)=cached.as_ref().unwrap();
   if selected_input_area(&self.pool,chosen,&self.free,i,value.0,refs,users).is_some_and(|a|a<value.0-1e-6){
    let m=&self.pool[i];let mut trial=chosen.clone();let mut feasible=true;let mut replaced=false;
    for(pin,o)in m.outputs.iter().enumerate(){let time=m.inputs.iter().enumerate().filter(|(p,_)|o.has_arc(*p)).map(|(p,&x)|arrival[x].unwrap_or(f64::INFINITY)+f64::from(o.delays[p])).fold(0.,f64::max);
     for &target in &o.targets {if trial[target].is_some(){if time>required[target]+1e-7{feasible=false;break}trial[target]=Some(Binding{instance:i,pin});replaced=true;}}
    }
    if feasible && replaced && prune(&self.pool,&mut trial,&self.free,&roots).is_ok(){let next=metrics(&self.pool,&trial,&self.free,&roots);
     if next.0<value.0-1e-6 && next.1<=value.1 {self.consider(bank,&roots,trial,stats,end);cached=None;}
    }
   }
   i+=1;
  }
  stage_trace("online_actual_area_done");
 }
 // Reuse the existing whole-cover recovery oracle, warm-started from the
 // saved complete online incumbent. The original delay/area cap is immutable.
 fn cone_area_recover(&mut self,bank:&[BTreeSet<Cut>],ps:&MapParams,stats:&mut MapStats){
  let Some(end)=crate::egraph_time_policy::deadline()else{return};if Instant::now()>=end{return}
  let Some(chosen)=self.best_global.clone()else{return};let old=self.best.as_ref().map(|g|(g.area,g.delay)).unwrap();let roots:Vec<_>=self.outputs.iter().map(|x|x.0).collect();
  let Some((witness,_))=delay_frontier_seed(&self.pool,&self.free,end)else{return};if Instant::now()>=end{return}
  let mut p=ps.clone();p.objective=MapObjective::AreaDelay;p.max_delay=Some(old.1);p.fixed_area_bound=true;p.protected_area_limit=Some(old.0);p.online_area=true;p.refresh_area_timing=true;p.delta_area_filter=true;p.fast_area_scan=true;
  stage_trace("online_cone_area_start");
  let(trial,value)=slack_area_pass(&self.pool,&self.free,&roots,&witness,chosen,old,&p,stats,end,true);
  if value.1<=old.1 && value.0<=old.0 {self.consider(bank,&roots,trial,stats,end);}
  stage_trace("online_cone_area_done");
 }
 pub(super) fn finish(mut self,bank:&[BTreeSet<Cut>],ps:&MapParams,mut stats:MapStats)->Result<MappedGraph,String>{
  match std::env::var("EGM_ONLINE_AREA_RECOVERY").as_deref(){Ok("1")=>self.area_recover(bank,&stats),Ok("2")=>self.cone_area_recover(bank,ps,&mut stats),_=>{}}
  let mut graph=self.best.take().ok_or("online search has no complete validated generated cover")?;
  graph.stats=stats;graph.stats.instances=self.pool.len();graph.stats.generated_instances=self.pool.len();Ok(graph)
 }
}
fn fnv(bytes:&[u8])->u64 {bytes.iter().fold(0xcbf29ce484222325u64,|v,&b|(v^u64::from(b)).wrapping_mul(0x100000001b3))}
fn publish(graph:&MappedGraph,sequence:usize,batches:usize,matched_cuts:usize,end:Instant)->Result<(),String>{
 let Some(root)=std::env::var_os("EGM_INCUMBENT_DIR").map(PathBuf::from)else{return Ok(())};
 publish_at(graph,sequence,batches,matched_cuts,end,&root)
}
fn publish_at(graph:&MappedGraph,sequence:usize,batches:usize,matched_cuts:usize,end:Instant,root:&std::path::Path)->Result<(),String>{
 std::fs::create_dir_all(root).map_err(|e|e.to_string())?;
 let pending=root.join(format!("{sequence:08}.pending"));let committed=root.join(format!("{sequence:08}"));
 std::fs::create_dir(&pending).map_err(|e|e.to_string())?;
 let mut text=Vec::new();graph.write_verilog(&mut text,"mapped").map_err(|e|e.to_string())?;
 std::fs::write(pending.join("mapped.v"),&text).map_err(|e|e.to_string())?;
 let manifest=serde_json::json!({"kind":"complete-generated-cover","area":graph.area,"delay":graph.delay,"instances":graph.instances.len(),"sequence":sequence,"batches":batches,"matched_cuts":matched_cuts,"bytes":text.len(),"fnv64":format!("{:016x}",fnv(&text)),"legality":"complete driver/cycle/cut-care-phase-pin proof and whole-cover metrics","CEC":false,"search_exhaustive":false});
 std::fs::write(pending.join("manifest.json"),manifest.to_string()).map_err(|e|e.to_string())?;
 if Instant::now()>=end{return Err("deadline before atomic incumbent commit".into())}
 std::fs::rename(pending,committed).map_err(|e|e.to_string())
}

#[cfg(test)]mod tests {
 use super::*;
 fn fixture()->(Aig,TechLib){
  let dir=std::env::temp_dir().join(format!("online-fixture-{}-{}",std::process::id(),std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).unwrap().as_nanos()));std::fs::create_dir(&dir).unwrap();
  let a=dir.join("test.aag");std::fs::write(&a,"aag 5 3 0 2 2\n2\n4\n6\n10\n11\n8 2 4\n10 8 6\ni0 a[0]\ni1 b[0]\ni2 c[0]\no0 y[0]\no1 y[1]\nc\n").unwrap();
  let l=dir.join("test.genlib");std::fs::write(&l,"GATE AND2 1 Y=A*B;\nPIN * NONINV 1 999 1 0 1 0\nGATE AND3 1.5 Y=A*B*C;\nPIN * NONINV 1 999 1 0 1 0\nGATE NAND2 1 Y=!(A*B);\nPIN * INV 1 999 1 0 1 0\nGATE INV .2 Y=!A;\nPIN * INV 1 999 .1 0 .1 0\n").unwrap();
  (Aig::from_aiger(a.to_str().unwrap()),TechLib::from_genlib_directed(&l).unwrap())
 }
 #[test]fn complete_online_cover_matches_exhaustive_function_and_index_space(){
  let(a,t)=fixture();let _window=crate::egraph_time_policy::Window::enter(3.).unwrap();TEST_ENABLED.with(|x|x.set(true));
  let p=MapParams{strict_budgets:true,protected_exchange:true,functional_cuts:true,canonical_phases:true,canonical_wire_only:true,time_limit_secs:0.,multioutput:false,objective:MapObjective::DelayArea,..Default::default()};
  let m=map(&a,&t,&p).unwrap();TEST_ENABLED.with(|x|x.set(false));
  assert!(m.area>0. &&m.delay.is_finite());assert_eq!(m.outputs[0].1,"y[0]");assert_eq!(m.inputs[0].2,"a[0]");
  for assignment in 0..8 {let v=m.inputs.iter().enumerate().map(|(i,(_,id,_))|(*id,assignment&(1<<i)!=0)).collect();assert_eq!(m.evaluate(&v).unwrap(),vec![assignment==7,assignment!=7]);}
 }
 #[test]fn round_delta_reconstructs_uncapped_bank_and_matches_control(){
  let(a,t)=fixture();let(mut e,_)=import_aig(&a).unwrap();e.rebuild();
  let mut classes:Vec<_>=e.classes().map(|c|c.id).collect();classes.sort();let ids:HashMap<_,_>=classes.iter().enumerate().map(|(i,&c)|(c,i)).collect();let nodes:Vec<_>=classes.iter().map(|&c|e[c].nodes.clone()).collect();
  let p=MapParams{cuts_per_class:usize::MAX,cut_rounds:32,..Default::default()};let mut stats=MapStats::default();
  let control=enumerate_with_source_mode(&nodes,&ids,&e,&t,&p,&mut stats,&[],true);let mut seen=vec![BTreeSet::new();nodes.len()];let mut calls=0;
  let mut notify=|bank:&[BTreeSet<Cut>],delta:&[BTreeSet<Cut>],_:&mut MapStats|{calls+=1;for c in 0..bank.len(){assert!(seen[c].is_disjoint(&delta[c]));seen[c].extend(delta[c].iter().cloned());assert_eq!(seen[c],bank[c]);}};
  let online=enumerate_with_source_notify(&nodes,&ids,&e,&t,&p,&mut stats,&[],true,Some(&mut notify));drop(notify);assert!(calls>=2);assert_eq!(online,control);
 }
 #[test]fn seminaive_cuts_equal_full_pair_closure_on_reconvergent_compact_graphs(){
  let(_,t)=fixture();
  for seed in 0..64usize {
   let mut g=egg::EGraph::<AigLang,()>::default();let mut all=vec![g.add(AigLang::Zero),g.add(AigLang::One)];for p in 0..4{all.push(g.add(AigLang::Pi(p)));}
   for i in 0..9 {let a=all[(i+seed)%all.len()];let b=all[(i*3+seed+1)%all.len()];if i%3==1{let c=all[(i*5+seed+2)%all.len()];all.push(g.add(AigLang::Cell(format!("@egm_tt3_{:02x}",[0x80,0xfe,0x96,0xe8][seed%4]).into(),vec![a,b,c])));}else{all.push(g.add(AigLang::And([a,b])));}if i%3==0{all.push(g.add(AigLang::Not(a)));}}
   g.rebuild();let mut classes:Vec<_>=g.classes().map(|c|c.id).collect();classes.sort();let ids:HashMap<_,_>=classes.iter().enumerate().map(|(i,&id)|(id,i)).collect();let nodes:Vec<_>=classes.iter().map(|&id|g[id].nodes.clone()).collect();
   let p=MapParams{max_inputs:4,cuts_per_class:usize::MAX,cut_rounds:32,..Default::default()};let mut stats=MapStats::default();let control=enumerate_with_source_mode(&nodes,&ids,&g,&t,&p,&mut stats,&[],true);let mut seen=vec![BTreeSet::new();nodes.len()];
   let mut notify=|bank:&[BTreeSet<Cut>],delta:&[BTreeSet<Cut>],_:&mut MapStats|{for c in 0..bank.len(){assert!(seen[c].is_disjoint(&delta[c]));seen[c].extend(delta[c].iter().cloned());assert_eq!(seen[c],bank[c]);}};
   let online=enumerate_with_source_notify(&nodes,&ids,&g,&t,&p,&mut stats,&[],true,Some(&mut notify));assert_eq!(online,control,"seed={seed}");
  }
 }
 #[test]fn incremental_matching_has_same_physical_keys_and_targets_as_batch_matching(){
  let(a,t)=fixture();let(mut e,roots)=import_aig(&a).unwrap();e.rebuild();
  let mut classes:Vec<_>=e.classes().map(|c|c.id).collect();classes.sort();let ids:HashMap<_,_>=classes.iter().enumerate().map(|(i,&c)|(c,i)).collect();let nodes:Vec<_>=classes.iter().map(|&c|e[c].nodes.clone()).collect();
  let mut free=vec![false;classes.len()*2];let mut constants=vec![None;free.len()];let mut inputs=Vec::new();
  for(c,bank)in nodes.iter().enumerate(){for n in bank{match n{AigLang::Pi(v)=>{free[c*2]=true;inputs.push((c*2,*v,format!("i{v}")));},AigLang::Zero|AigLang::One=>{for p in 0..2{free[c*2+p]=true;constants[c*2+p]=Some(matches!(n,AigLang::One)^(p==1));}},_=>{}}}}
  let outputs:Vec<_>=roots.iter().map(|(p,id)|(ids[&e.find(*id)]*2,format!("o{p}"))).collect();
  let p=MapParams{protected_exchange:true,multioutput:false,objective:MapObjective::DelayArea,cuts_per_class:usize::MAX,cut_rounds:32,..Default::default()};
  let witness=cheapest_nodes_queued(&e);let mut reach=Reachability{nodes:classes.iter().map(|c|witness[c].clone()).collect(),ids:ids.clone(),cache:HashMap::new()};
  let _w=crate::egraph_time_policy::Window::enter(5.).unwrap();let mut state=State::new(&free,&inputs,&outputs,&constants);let mut stats=MapStats::default();
  let mut f=|bank:&[BTreeSet<Cut>],delta:&[BTreeSet<Cut>],stats:&mut MapStats|state.consume(bank,delta,&free,&constants,None,&t,&p,&mut reach,stats);
  let bank=enumerate_with_source_notify(&nodes,&ids,&e,&t,&p,&mut stats,&[],true,Some(&mut f));drop(f);
  let batch=generate(&bank,&free,&constants,&t,&p,&mut reach,&mut stats,None,None);
  let signature=|pool:&[Instance]|pool.iter().map(|m|(format!("{:?}",instance_key(m)),m.outputs.iter().map(|o|o.targets.clone()).collect::<Vec<_>>())).collect::<BTreeMap<_,_>>();
  assert_eq!(signature(&state.pool),signature(&batch));assert!(state.best.is_some());
 }
 #[test]fn selected_input_shared_area_recovery_preserves_complete_cover_and_delay(){
  let(a,_)=fixture();let dir=std::env::temp_dir().join(format!("online-area-{}",std::process::id()));std::fs::create_dir_all(&dir).unwrap();let lib=dir.join("test.genlib");std::fs::write(&lib,"GATE AND3 1.5 Y=A*B*C;\nPIN * NONINV 1 999 1 0 1 0\nGATE AND3_EXPENSIVE 10 Y=A*B*C;\nPIN * NONINV 1 999 1 0 1 0\nGATE AND2 1 Y=A*B;\nPIN * NONINV 1 999 1 0 1 0\nGATE INV .2 Y=!A;\nPIN * INV 1 999 .1 0 .1 0\n").unwrap();let t=TechLib::from_genlib_directed(&lib).unwrap();
  let(mut e,roots)=import_aig(&a).unwrap();e.rebuild();let mut classes:Vec<_>=e.classes().map(|c|c.id).collect();classes.sort();let ids:HashMap<_,_>=classes.iter().enumerate().map(|(i,&c)|(c,i)).collect();let nodes:Vec<_>=classes.iter().map(|&c|e[c].nodes.clone()).collect();let mut free=vec![false;nodes.len()*2];let mut constants=vec![None;free.len()];let mut inputs=Vec::new();for(c,ns)in nodes.iter().enumerate(){for n in ns{match n{AigLang::Pi(v)=>{free[c*2]=true;inputs.push((c*2,*v,format!("i{v}")));},AigLang::Zero|AigLang::One=>{for p in 0..2{free[c*2+p]=true;constants[c*2+p]=Some(matches!(n,AigLang::One)^(p==1));}},_=>{}}}}
  let outputs:Vec<_>=roots.iter().map(|(p,id)|(ids[&e.find(*id)]*2,format!("o{p}"))).collect();let p=MapParams{protected_exchange:true,multioutput:false,objective:MapObjective::DelayArea,cuts_per_class:usize::MAX,cut_rounds:32,..Default::default()};let witness=cheapest_nodes_queued(&e);let mut reach=Reachability{nodes:classes.iter().map(|c|witness[c].clone()).collect(),ids:ids.clone(),cache:HashMap::new()};let mut stats=MapStats::default();let bank=enumerate_with_source_mode(&nodes,&ids,&e,&t,&p,&mut stats,&[],true);let _window=crate::egraph_time_policy::Window::enter(5.).unwrap();let mut state=State::new(&free,&inputs,&outputs,&constants);state.consume(&bank,&bank,&free,&constants,None,&t,&p,&mut reach,&mut stats);
  let expensive=state.pool.iter().position(|m|m.cell=="AND3_EXPENSIVE").unwrap();let mut chosen=state.best_global.clone().unwrap();for(pin,o)in state.pool[expensive].outputs.iter().enumerate(){for &target in &o.targets{if chosen[target].is_some(){chosen[target]=Some(Binding{instance:expensive,pin});}}}let roots:Vec<_>=outputs.iter().map(|x|x.0).collect();state.best=None;state.best_global=None;state.consider(&bank,&roots,chosen,&stats,crate::egraph_time_policy::deadline().unwrap());let old=state.best.as_ref().map(|g|(g.area,g.delay)).unwrap();assert!(old.0>=10.);state.area_recover(&bank,&stats);let m=state.best.unwrap();assert!(m.area<old.0);assert!(m.delay<=old.1);for assignment in 0..8{let v=m.inputs.iter().enumerate().map(|(i,(_,id,_))|(*id,assignment&(1<<i)!=0)).collect();assert_eq!(m.evaluate(&v).unwrap(),vec![assignment==7,assignment!=7]);}
 }
 #[test]fn warm_started_cone_area_recovery_preserves_complete_cover_and_delay(){
  let(a,_)=fixture();let dir=std::env::temp_dir().join(format!("online-area-{}",std::process::id()));std::fs::create_dir_all(&dir).unwrap();let lib=dir.join("test.genlib");std::fs::write(&lib,"GATE AND3 1.5 Y=A*B*C;\nPIN * NONINV 1 999 1 0 1 0\nGATE AND3_EXPENSIVE 10 Y=A*B*C;\nPIN * NONINV 1 999 1 0 1 0\nGATE AND2 1 Y=A*B;\nPIN * NONINV 1 999 1 0 1 0\nGATE INV .2 Y=!A;\nPIN * INV 1 999 .1 0 .1 0\n").unwrap();let t=TechLib::from_genlib_directed(&lib).unwrap();
  let(mut e,roots)=import_aig(&a).unwrap();e.rebuild();let mut classes:Vec<_>=e.classes().map(|c|c.id).collect();classes.sort();let ids:HashMap<_,_>=classes.iter().enumerate().map(|(i,&c)|(c,i)).collect();let nodes:Vec<_>=classes.iter().map(|&c|e[c].nodes.clone()).collect();let mut free=vec![false;nodes.len()*2];let mut constants=vec![None;free.len()];let mut inputs=Vec::new();for(c,ns)in nodes.iter().enumerate(){for n in ns{match n{AigLang::Pi(v)=>{free[c*2]=true;inputs.push((c*2,*v,format!("i{v}")));},AigLang::Zero|AigLang::One=>{for p in 0..2{free[c*2+p]=true;constants[c*2+p]=Some(matches!(n,AigLang::One)^(p==1));}},_=>{}}}}
  let outputs:Vec<_>=roots.iter().map(|(p,id)|(ids[&e.find(*id)]*2,format!("o{p}"))).collect();let p=MapParams{protected_exchange:true,multioutput:false,objective:MapObjective::DelayArea,cuts_per_class:usize::MAX,cut_rounds:32,..Default::default()};let witness=cheapest_nodes_queued(&e);let mut reach=Reachability{nodes:classes.iter().map(|c|witness[c].clone()).collect(),ids:ids.clone(),cache:HashMap::new()};let mut stats=MapStats::default();let bank=enumerate_with_source_mode(&nodes,&ids,&e,&t,&p,&mut stats,&[],true);let _window=crate::egraph_time_policy::Window::enter(5.).unwrap();let mut state=State::new(&free,&inputs,&outputs,&constants);state.consume(&bank,&bank,&free,&constants,None,&t,&p,&mut reach,&mut stats);
  let expensive=state.pool.iter().position(|m|m.cell=="AND3_EXPENSIVE").unwrap();let mut chosen=state.best_global.clone().unwrap();for(pin,o)in state.pool[expensive].outputs.iter().enumerate(){for &target in &o.targets{if chosen[target].is_some(){chosen[target]=Some(Binding{instance:expensive,pin});}}}let roots:Vec<_>=outputs.iter().map(|x|x.0).collect();state.best=None;state.best_global=None;state.consider(&bank,&roots,chosen,&stats,crate::egraph_time_policy::deadline().unwrap());let old=state.best.as_ref().map(|g|(g.area,g.delay)).unwrap();assert!(old.0>=10.);state.cone_area_recover(&bank,&p,&mut stats);let m=state.best.unwrap();assert!(m.area<old.0);assert!(m.delay<=old.1);for assignment in 0..8{let v=m.inputs.iter().enumerate().map(|(i,(_,id,_))|(*id,assignment&(1<<i)!=0)).collect();assert_eq!(m.evaluate(&v).unwrap(),vec![assignment==7,assignment!=7]);}
 }
 #[test]fn incomplete_or_unproved_binding_is_never_an_incumbent(){
  let mut s=State::new(&[true,false,false],&[(0,1,"x".into())],&[(2,"y".into())],&[None;3]);
  let bank=vec![BTreeSet::new();2];s.consider(&bank,&[2],vec![None;3],&MapStats::default(),Instant::now()+std::time::Duration::from_secs(1));assert!(s.best.is_none());
 }
 #[test]fn deadline_during_publication_cannot_leave_committed_directory(){
  let(a,t)=fixture();let p=MapParams{multioutput:false,..Default::default()};let m=map(&a,&t,&p).unwrap();
  let dir=std::env::temp_dir().join(format!("online-atomic-{}",std::process::id()));let _=std::fs::remove_dir_all(&dir);
  assert!(publish_at(&m,1,1,1,Instant::now(),&dir).is_err());assert!(!dir.join("00000001").exists());assert!(dir.join("00000001.pending").exists());
  publish_at(&m,2,1,1,Instant::now()+std::time::Duration::from_secs(2),&dir).unwrap();let bytes=std::fs::read(dir.join("00000002/mapped.v")).unwrap();let j:serde_json::Value=serde_json::from_slice(&std::fs::read(dir.join("00000002/manifest.json")).unwrap()).unwrap();assert_eq!(j["fnv64"],format!("{:016x}",fnv(&bytes)));
 }
}
