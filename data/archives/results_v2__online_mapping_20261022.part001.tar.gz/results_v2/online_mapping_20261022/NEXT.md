# Online mapping: adoption gates and remaining work

The v1/v2 kernel and harness snapshots are independent, opt-in experiments. Main native source/defaults and baseline algorithms remain unchanged. The current allowance is a single 600-second mapping-related search window; CEC, once-shared resyn2, pure conversion and metrics are excluded. No node/cut/pool/stage caps are reinstated.

## Implemented and checked

* Mandatory cuts are matched before optional cut closure. A generated complete cover is validated for exact binding/care/phase/pins, drivers and cycles, then saved with all selected shared instances.
* Incremental rounds combine delta-A with all-B and old-A with delta-B; matched cut deltas feed one deduplicated physical pool. Cyclic e-class dependencies continue through rounds, not an assumed DAG order.
* Committed netlist bundles require an atomic rename. A parent receipt selects an improvement before the original global deadline; only this receipt may survive worker timeout. Independent named-port CEC remains required afterwards. Arbitrary partial files and late bundles are rejected.
* V2 optionally performs one selected-input ref/deref area sweep under the incumbent delay, using whole-cover validation before acceptance. Cached arrivals, required times and reference counts refresh after accepted replacements.

## Observed limitation

Adder/bar first2 and one candidate repeat pass CEC and reproduce their A/D. Area recovery reduces area without changing delay but still loses against the previous complete recovery. This is insufficient for adoption. The report includes both regressions and 18 missing designs in full20 scope.

## Next experiments in order

1. Reuse the existing complete-cover area recovery with the early incumbent as warm start and immutable delay/area cap; allow unselected input cones via a valid witness. Keep v2 immutable and use a new versioned source/cohort. No archived mapper output is an incumbent for a new invocation.
2. Test whether early mandatory-cover receipts reach log2/hyp/div/mem_ctrl before their actual 600-second deadlines; distinguish optimized incumbent, unfinished search and source-only fallback. Do not reuse the old stage classifier for the new interleaved algorithm.
3. Introduce deferred physical materialization using lightweight library templates plus exact cut/care/phase/pin bindings. This is NOT yet implemented: v2 still materializes all physical matches in each delta. Materializing only selected netlist cells is not a substitute for this step.
4. Complete a uniform full20 cohort and same-binary ablations, then repeated paired runs in alternating order. Do not pick per-design winners across versions. Freeze parameters and all actually executed dependencies before each cohort.
5. Continue the unchanged original-baseline600 cohort from its verified checkpoint, sequentially under the same global lock. Preserve timeouts/native failures and source hashes. No source/model/algorithm tuning.
6. Only after CEC, full-suite comparisons and repeats justify improvement: update main, public data and paper. Current public manuscript remains on its prior verified evidence; these limited prototype results are not final tables.

## V3 follow-up observation (not an adoption claim)

Warm-started existing full-cover area recovery has now passed253 related tests and three paired adder/bar rounds (12CEC). Bar area248.36 is below the historical262.77; adder87.10 remains slightly above87.06. Late physical materialization is still absent. The dedicated log2 case is being allowed its full600 window; its parent accepted an optimized generated incumbent around24.85s, but CEC must finish before it is evidence. Runtime stage logs place subsequent work in the original wide-cell matcher. That matcher builds a whole result batch and lacks incremental incumbent callbacks; outer600 still enforces the true budget. Diagnose this separately from cut closure.

Search-status auditing: the prototype runner derives search_finished from frontend exit in its receipt-promotion branch; the frontend may exit0 after a native failure. Inspect native_exit_code and search_deadline_hit as well, preserving raw reports. Earlier completed first2 cases have native exit0; their claims are unaffected. For any killed/failed worker, an accepted legal receipt is only an optimized output, not a completed search. Future harness revision must preserve both frontend and native failure/timeout flags, with a new explicit cohort or dependency-audited reporting view.
