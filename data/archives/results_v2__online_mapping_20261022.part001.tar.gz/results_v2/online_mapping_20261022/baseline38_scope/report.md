#600秒完整范围检查

{
  "candidate_completed": 20,
  "candidate_expected": 20,
  "candidate_optimized": 11,
  "candidate_verified_outputs": 20,
  "candidate_statuses": {
    "mapping_timeout": 9,
    "ok": 11
  },
  "baseline_completed_groups": 38,
  "baseline_expected_groups": 120,
  "baseline_qualified_observations": 104,
  "baseline_statuses": {
    "failed": 4,
    "ok": 104,
    "pending600": 152
  },
  "gates": {
    "delay-area": false,
    "area-delay": false,
    "pareto": false
  },
  "unconnected_tools": [
    "MtM"
  ],
  "all_failures_retained": true,
  "verification_proof_reuses": [
    {
      "bench": "hyp",
      "method": "mockturtle_emap_delay_resyn2",
      "proof": "/home/flynn/workplace/MIGBalance/results_v2/time_only_600_20261022/hyp_identical_delay_proof/proof_reuse.json",
      "original_failure_retained": true
    }
  ],
  "interpretation": "600s is a changed resource protocol. Adopted completed observations retain their original stricter policy and time/upper-bound labels. Source-only CEC is not optimized coverage. Lexicographic wins are not Pareto dominance."
}

|设计|状态|优化覆盖返回|面积|延迟|映射秒|CEC|
|---|---|---|---:|---:|---:|---:|
|adder|ok|True|87.06000077724457|2569.1499977111816|9.2044287440076|1|
|bar|ok|True|262.7700018361211|168.2899990081787|12.657033625990152|1|
|div|mapping_timeout|False|4154.880134962499|99097.35843467712|600.1059006899886|1|
|hyp|mapping_timeout|False|22414.780679889023|667115.2042598724|600.0292925280228|1|
|log2|mapping_timeout|False|2919.34009886533|9710.569911956787|600.104309938004|1|
|max|ok|True|209.68000053614378|2074.5800037384033|60.9915932790027|1|
|multiplier|mapping_timeout|False|2502.8000812754035|5925.149908065796|600.104644549021|1|
|sin|mapping_timeout|False|503.5900169014931|4772.1899700164795|600.1036523859948|1|
|sqrt|mapping_timeout|False|1955.33006490767|126168.74898910522|600.104332406976|1|
|square|mapping_timeout|False|1785.3900529816747|5582.399908065796|600.0287740270142|1|
|arbiter|ok|True|766.619985498488|898.7499980926514|119.75111350699444|1|
|cavlc|ok|True|37.120000287890434|185.8700008392334|23.024513350013876|1|
|ctrl|ok|True|6.700000047683716|103.17000198364258|2.0486878310039174|1|
|dec|ok|True|30.830000288784504|65.72000122070312|4.856113407004159|1|
|i2c|ok|True|69.00000048428774|165.79000091552734|22.13406143899192|1|
|int2float|ok|True|12.330000080168247|181|2.097730129986303|1|
|mem_ctrl|mapping_timeout|False|4290.740158982575|2731.2299823760986|600.0321796479984|1|
|priority|ok|True|64.45999991893768|2045.5799980163574|5.619293921015924|1|
|router|ok|True|12.39000003784895|187.47000122070312|2.3009363239980303|1|
|voter|mapping_timeout|False|1049.2800310626626|1620.0999927520752|600.1028436449997|1|
