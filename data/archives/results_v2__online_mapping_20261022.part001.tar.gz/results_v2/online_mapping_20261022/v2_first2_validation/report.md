# Online mapper v2: limited-scope verification

600s total mapping search; independent CEC excluded; original baselines unchanged. Full20 coverage pending.

|Design|Control A|Area recovery A|D (both)|T control / recovery|Old-flow A|Repeat AD|
|---|---:|---:|---:|---:|---:|---|
|adder|160.30|96.03|2569.15|9.43 / 21.55|87.06|True|
|bar|290.36|271.09|168.29|8.08 / 15.01|262.77|True|

All shown outputs pass independent named-port CEC. V2 still loses area against old complete recovery. This does not establish baseline dominance or justify main adoption. Late materialization and full shared-cover recovery remain incomplete.
