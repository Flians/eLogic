# V3: full-cover area recovery, limited-scope paired validation

One600-second mapping-search window, CEC excluded. Same source/binary per pair; three rounds with alternated configuration order.

|Design|Rep|Control A|Candidate A|D control / candidate|T control / candidate|CEC both|
|---|---:|---:|---:|---:|---:|---:|
|adder|0|160.30|87.10|2569.15 / 2569.15|9.43 / 13.89|1|
|bar|0|290.36|248.36|168.29 / 168.29|7.77 / 12.85|1|
|adder|1|160.30|87.10|2569.15 / 2569.15|9.28 / 15.04|1|
|bar|1|290.36|248.36|168.29 / 168.29|7.71 / 12.21|1|
|adder|2|160.30|87.10|2569.15 / 2569.15|9.29 / 13.94|1|
|bar|2|290.36|248.36|168.29 / 168.29|7.69 / 12.59|1|

Old full-flow areas are adder87.06 and bar262.77. The new adder remains about0.04 larger; bar improves. These are separate historical full-flow comparisons, not the same-binary ablation above. All regressions and missing designs remain. No main adoption or final paper-table update. Deferred materialization is not implemented.
