from pathlib import Path
import json,hashlib
R=Path('/home/flynn/workplace/MIGBalance');E=R/'results_v2/independent_components_20261019';p=R/'epmapping_paper/DAC-eGraphMap-draft/main.tex';s=p.read_text();before=(E/'paper_before.tex').read_text();t=json.loads((E/'paper_table_sources.json').read_text());old=json.loads((R/'results_v2/combined_runtime_tables_20261019/runtime_sources.json').read_text())['records'];sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert len(t['records'])==240 and t['source_sha256']==sha(p)
assert s.split('\\begin{document}')[0]==before.split('\\begin{document}')[0]
assert s[s.index('\\clearpage'):]==before[before.index('\\clearpage'):]
assert all(ord(c)>=32 or c in '\n\t'for c in s)
assert 'B/X'not in s and '\\multicolumn{3}{c}{B}'not in s and '\\multicolumn{3}{c}{X}'not in s
blocks=s[s.index('% BEGIN EPFL COMPLETE TABLES'):s.index('% END EPFL COMPLETE TABLES')].split('\\begin{table*}')[1:];assert len(blocks)==2;n=0;baseline=0
for k,block in zip([3,4],blocks):
 assert block.count('\\multicolumn{3}{c}')==6
 for line in block.splitlines():
  design=line.split(' & ')[0].replace('\\_','_');records=[r for r in t['records']if r['k']==k and r['design']==design]
  if not records:continue
  cells=[z.strip()for z in line.rsplit('\\\\',1)[0].split(' & ')[1:]];assert cells==[z for r in records for z in r['cells']],(k,design)
  for r in records:
   if r['method']=='eGraphMap':assert r['source']['profile']=='full' and '/emapper-independent-full-'in r['source']['report']
   else:
    o=next(o for o in old if(o['k'],o['design'],o['method'])==(k,design,r['method']));assert r['cells']==[o['area_cell'],o['delay_cell'],o['runtime_cell']];baseline+=3
  n+=len(cells)
assert n==720 and baseline==600
q=json.loads((E/'evidence/qualification.json').read_text());assert not any(g['passed']for g in q['gates']);assert all(sha(p)==h for p,h in q['source_hashes'].items())
# Each ablation-table A/D count is checked against the authoritative summary.
trip=lambda d:'/'.join(str(d.get(k,0))for k in ['lower','equal','higher'])
labels={'full':'Full configuration','no_functional_cuts':'No functional quotients','single_witness_cuts':'One-witness structural cuts','no_input_phase':'No input-phase matching','canonical_pins':'Canonical pin assignment','no_sdc':'No SDC matching','no_shared_area':'No post-phase area recovery','no_incumbent_guard':'No seed-metric protection'}
for profile,x in q['summary'].items():
 line=next(l for l in s.splitlines()if l.startswith(labels[profile]+' & '));cells=[c.strip()for c in line.rsplit('\\\\',1)[0].split(' & ')];assert cells[1]==f"{x['full_CEC']}/40" and cells[5]==f"{x['repeat_CEC']}/18"
 if profile!='full':assert [cells[i]for i in [2,3,6,7]]==[trip(x[k])for k in ['full_area','full_delay','repeat_area','repeat_delay']]
x=dict(main_tables=2,methods_per_table=6,main_metric_cells=n,baseline_metric_cells_unchanged=baseline,final_profile_metric_cells=120,all_final_points_from_fresh_full40=True,B_X_removed=True,IEEE_preamble_and_reference_source_unchanged=True,all_frozen_source_hashes_still_match=True,all_ablation_coverage_and_AD_count_cells_checked=True,baseline_algorithms_changed=False,gate_results=[g['passed']for g in q['gates']],source_sha256=sha(p),checker_sha256=sha(__file__))
(E/'paper_data_validation.json').write_text(json.dumps(x,indent=2));print(json.dumps(x,indent=2))
