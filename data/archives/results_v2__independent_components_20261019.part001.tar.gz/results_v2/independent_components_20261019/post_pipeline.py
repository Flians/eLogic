from pathlib import Path
import json,subprocess,sys,time
R=Path('/home/flynn/workplace/MIGBalance');E=R/'results_v2/independent_components_20261019';D=R/'scripts/experiments/campaigns'
(E/'post_pipeline_state.json').write_text(json.dumps({'phase':'waiting for original three repeat rounds; no extra mapper runs concurrently'}))
while not (E/'finite_finished.json').exists():
 log=(E/'repetitions_pipeline.log').read_text()
 if 'Traceback' in log:raise RuntimeError('original repetition pipeline needs attention; no extra mapping started')
 if (E/'post_pipeline_stop.json').exists():raise RuntimeError('operator requested coordinator stop')
 time.sleep(5)
def run(args,log):
 print('RUN',*[str(x)for x in args],flush=True)
 with (E/log).open('w')as f:p=subprocess.run([sys.executable,*map(str,args)],cwd=R,stdout=f,stderr=subprocess.STDOUT)
 if p.returncode:raise RuntimeError('post pipeline failed: '+log)
(E/'post_pipeline_state.json').write_text(json.dumps({'phase':'timestamp-triggered multiplier sensitivity,16cases, all eight profiles; no primary-point replacement'}))
s=Path('/tmp/emapper-independent-storage-replay-20261019')
run([D/'run_independent_components.py','--output',s,'--designs','multiplier','--repetition','3','--max-jobs','16'],'storage_replay_runner.log')
run([D/'check_independent_components.py',s/'campaign.json'],'storage_replay_validation.log')
(E/'post_pipeline_state.json').write_text(json.dumps({'phase':'all timed mappings finished; aggregate complete data and baseline gates'}))
run([E/'finalize_results.py','--full','/tmp/emapper-independent-full-20261019','--repeats',*['/tmp/emapper-independent-repeat-r%d-20261019'%i for i in range(3)],'--storage-replay',s,'--output',E/'evidence'],'finalize_results.log')
(E/'data_ready.json').write_text(json.dumps({'full_attempts':320,'planned_repetition_attempts':144,'storage_sensitivity_attempts':16,'source':'one frozen executable, uniform settings except named component','primary_points_replaced':False,'paper_authoring_started':False},indent=2));(E/'post_pipeline_state.json').write_text(json.dumps({'phase':'data ready; archive/source snapshot/marker+paper/QA/publication still required'}));print('DATA_READY',flush=True)
