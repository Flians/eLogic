from pathlib import Path
import hashlib,json,subprocess,shutil,os,time,re,fcntl
R=Path('/home/flynn/workplace/MIGBalance');E=R/'results_v2/independent_components_20261019';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();load=lambda p:json.loads(Path(p).read_text())
assert E.is_dir() and not E.is_symlink() and load(E/'persistence.json')['complete']
subprocess.run(['python3',str(E/'check_paper_data.py')],cwd=R,check=True,capture_output=True,text=True)
q=load(E/'evidence/qualification.json');v=load(E/'paper_data_validation.json');compiled=E/'build/main.pdf';tex=R/'epmapping_paper/DAC-eGraphMap-draft/main.tex';out=R/'output/pdf/DAC-eGraphMap-draft.pdf'
assert sha(tex)==v['source_sha256']
text=subprocess.check_output(['/usr/bin/pdftotext','-layout',str(compiled),'-'],text=True);pages=[x for x in text.split('\f')if x.strip()];assert len(pages)==7 and re.search(r'R\s*EFERENCES',pages[6]) and not any(re.search(r'R\s*EFERENCES',p)for p in pages[:6])
log=(E/'build/main.log').read_text();assert 'Overfull'not in log and 'undefined'not in log.lower() and 'LaTeX Warning'not in log
assert 'This is a 10 point document'in log
archives=load(E/'archives_permanent.json');assert len(archives)==6
for a in archives:
 assert a['stream_member_hash_verification'] and sha(a['archive'])==a['archive_sha256'] and sha(a['manifest'])==a['manifest_sha256']
lock_paths=[E/'global.lock',R/'results_v2/epfl_original_baselines_resumed_checkpoint_20261013/runner.lock',R/'results_v2/small_cut_quota_cases_20261014/runner.lock',*[Path('/tmp/emapper-independent-'+s+'-20261019/runner.lock')for s in ['full','repeat-r0','repeat-r1','repeat-r2','storage-replay','smoke']]];locks=[]
for p in lock_paths:
 h=p.open('r');fcntl.flock(h,fcntl.LOCK_EX|fcntl.LOCK_NB);locks.append(h)
(E/'lock_audit.json').write_text(json.dumps(dict(all_tracked_runners_idle=True,paths=list(map(str,lock_paths)),time_unix=time.time()),indent=2))
previous=load(E/'qa_previous_page_hashes.json');hashes={str(i):sha(E/f'qa_images/page-{i}.png')for i in range(1,8)};assert all(hashes[str(i)]==previous[str(i)]for i in [1,2,3,7])
# All seven pages were visually inspected; final edits changed only4/5/6, reinspected.
assert sha(out)==sha(E/'paper_before.pdf'),'published file changed concurrently; preserve before replacing'
copy=out.with_suffix('.pdf.pending');assert not copy.exists();shutil.copy2(compiled,copy);assert sha(copy)==sha(compiled);os.replace(copy,out)
qa=dict(published=True,pdf=str(out),pdf_sha256=sha(out),source=str(tex),source_sha256=sha(tex),pages=7,body_pages=6,reference_pages=1,body_10pt_original_preamble_and_margins=True,main_tables_8pt=True,ablation_table_footnotesize=True,main_metric_cells_checked=720,baseline_metric_cells_unchanged=600,final_profile_metric_cells_from_fresh_full40=120,B_X_removed=True,uniform_final_profile='full',all_pages_visual_QA=[1,2,3,4,5,6,7],final_changed_pages_reinspected=[4,5,6],unchanged_pages_pixel_identical=[1,2,3,7],page_png_sha256=hashes,overfull_boxes=0,undefined_references=0,nonfatal_underfull_count=log.count('Underfull'),full_attempts=q['full_attempts'],full_CEC=q['full_CEC'],repeated_designs=['sqrt','sin','priority'],repeat_rounds=3,repeated_attempts=q['repetition_attempts'],repeated_CEC=q['repetition_CEC'],storage_replay_attempts=16,storage_replay_CEC=q['storage_sensitivity']['CEC'],primary_points_replaced=False,baseline_algorithms_changed=False,all_scope_gates_passed=False,unconnected=['MtM'],archives_permanent=6,all_tracked_finite_processes_finished=True,time_unix=time.time())
(E/'paper_qa.json').write_text(json.dumps(qa,indent=2))
S=E/'source_snapshot/final_authoring_checked';S.mkdir(exist_ok=False);idx=[]
for p in [E/'update_paper.py',E/'finalize_results.py',E/'check_paper_data.py',E/'publish_checked_paper.py',tex]:
 d=S/p.name;shutil.copy2(p,d);assert sha(d)==sha(p);idx.append(dict(original=str(p),snapshot=str(d.relative_to(E/'source_snapshot')),sha256=sha(d)))
(S/'index.json').write_text(json.dumps(idx,indent=2))
(E/'final_state.json').write_text(json.dumps(dict(scope='User request: uniform main tables, independent removals, targeted repetitions, data/paper update',scope_complete=True,whole_project_complete=False,all_gates_passed=False,open=['div/hyp/mem_ctrl cumulative node refusals','sqrt area premium','functional-cut adverse sin timing','SDC independent delay gain unproven','historical full-budget shared incumbent quality not guaranteed'],active_sessions=[],paper_qa=str(E/'paper_qa.json'),permanent_evidence=str(E)),indent=2))
print(json.dumps(qa,indent=2))
