from pathlib import Path
import shutil,hashlib,json,os,time
R=Path('/home/flynn/workplace/MIGBalance');E=R/'results_v2/independent_components_20261019';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert (E/'archival_ready.json').exists() and (E/'data_ready.json').exists()
assert E.is_symlink(),'one-time durable transfer; inspect existing state rather than overwrite'
P=E.resolve();records=json.loads((E/'archives_temporary_verified.json').read_text());dest=R/'results_v2/archives'
required=sum(Path(v[k]).stat().st_size for v in records for k in ['archive','manifest'])+sum(p.stat().st_size for p in P.rglob('*') if p.is_file())
free=shutil.disk_usage(R).free
print('Durable transfer bytes',required,'workspace free',free,flush=True)
assert free>required+256*1024*1024,'insufficient workspace headroom; preserve inactive build cache before retrying'
permanent=[]
for v in records:
 w=dict(v,temporary_archive=v['archive'],temporary_manifest=v['manifest'])
 for key in ['archive','manifest']:
  src=Path(v[key]);target=dest/src.name;assert sha(src)==v[key+'_sha256']
  if target.exists():assert sha(target)==sha(src)
  else:
   tmp=target.with_name(target.name+'.copying');assert not tmp.exists();shutil.copy2(src,tmp);assert sha(tmp)==sha(src);os.replace(tmp,target)
  w[key]=str(target)
 target=dest/(Path(v['archive']).name.replace('.tar.zst','.verified.json'));tmp=target.with_name(target.name+'.pending');tmp.write_text(json.dumps(w,indent=2)+'\n');os.replace(tmp,target);permanent.append(w);print('Durable archive',target.name,flush=True)
(E/'archives_permanent.json').write_text(json.dumps(permanent,indent=2))
# The closed, externally backed test listing is materialized before metadata transfer.
materialized=[]
for p in list(P.rglob('*')):
 if p.is_symlink() and p.is_file() and str(p.resolve()).startswith('/tmp/'):
  target=p.resolve();h=sha(target);tmp=p.with_name(p.name+'.materializing');assert not tmp.exists();shutil.copy2(target,tmp);assert sha(tmp)==h;os.replace(tmp,p);materialized.append(dict(path=str(p.relative_to(P)),former_target=str(target),sha256=h))
(E/'materialized_logs.json').write_text(json.dumps(materialized,indent=2))
stage=E.with_name('.independent_components_20261019.durable');assert not stage.exists();shutil.copytree(P,stage,symlinks=True)
for p in P.rglob('*'):
 q=stage/p.relative_to(P)
 if p.is_symlink():assert q.is_symlink() and os.readlink(q)==os.readlink(p)
 elif p.is_file():assert sha(p)==sha(q),str(p)
 else:assert q.is_dir()
backup=P.with_name(P.name+'.runtime-original');assert not backup.exists()
E.unlink();stage.rename(E);P.rename(backup);P.symlink_to(E,target_is_directory=True)
(E/'persistence.json').write_text(json.dumps(dict(complete=True,workspace_evidence=str(E),temporary_alias=str(P),runtime_backup=str(backup),archives=len(permanent),no_raw_data_deleted=True,all_copied_members_SHA_verified=True,time_unix=time.time()),indent=2))
v=json.loads((E/'archival_ready.json').read_text());v['workspace_copy_pending']=False;v['permanent_archives']=str(E/'archives_permanent.json');(E/'archival_ready.json').write_text(json.dumps(v,indent=2))
print('EVIDENCE_AND_SIX_ARCHIVES_DURABLE',flush=True)
