import fcntl,json,subprocess,sys
from pathlib import Path
R=Path('/home/flynn/workplace/MIGBalance');D=R/'scripts/experiments/campaigns';E=R/'results_v2/independent_components_20261019';full=Path('/tmp/emapper-independent-full-20261019')
def run(args,log):
 print('RUN',*[str(x)for x in args],flush=True)
 with (E/log).open('w')as f:p=subprocess.run([sys.executable,*map(str,args)],cwd=R,stdout=f,stderr=subprocess.STDOUT)
 if p.returncode:raise RuntimeError('finite pipeline failed: '+log)
with (full/'runner.lock').open('a')as h:fcntl.flock(h,fcntl.LOCK_EX)
c=json.loads((full/'campaign.json').read_text());assert c.get('status')=='attempted' and len(c['jobs'])==320
run([D/'check_independent_components.py',full/'campaign.json'],'full_validation.log')
for i in range(3):
 p=Path('/tmp/emapper-independent-repeat-r%d-20261019'%i)
 run([D/'run_independent_components.py','--output',p,'--designs','sqrt','sin','priority','--repetition',str(i),'--max-jobs','48'],'repeat_r%d_runner.log'%i)
 run([D/'check_independent_components.py',p/'campaign.json'],'repeat_r%d_validation.log'%i)
(E/'finite_finished.json').write_text(json.dumps({'full':str(full),'repeats':['/tmp/emapper-independent-repeat-r%d-20261019'%i for i in range(3)],'status':'finished'},indent=2))
print('ALL_FINITE_COMPONENT_EXPERIMENTS_FINISHED',flush=True)
