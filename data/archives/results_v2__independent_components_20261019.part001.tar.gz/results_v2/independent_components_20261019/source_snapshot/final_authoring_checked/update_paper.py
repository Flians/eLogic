from pathlib import Path
import json,math,re,hashlib,statistics,os
R=Path('/home/flynn/workplace/MIGBalance');E=R/'results_v2/independent_components_20261019';V=E/'evidence';q=json.loads((V/'qualification.json').read_text());assert q['complete'];rows=json.loads((V/'full_rows.json').read_text());ranges=json.loads((V/'repetition_ranges.json').read_text());old=json.loads((R/'results_v2/combined_runtime_tables_20261019/runtime_sources.json').read_text())['records'];s=(E/'paper_before.tex').read_text();sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();methods=['abc_map_delay_resyn2','mockturtle_emap_delay_resyn2','eqmap_lut_amap','esyn_frozen_model_amap_bounded_dag','emorphic_final_sa','eGraphMap'];labels=['ABC map','emap','EqMap','E-Syn','E-morphic','eGraphMap'];table_sources=[];tables=[]
for k in [3,4]:
 lines=[r'\begin{table*}[!t]\centering\fontsize{8}{9.5}\selectfont',r'\setlength{\tabcolsep}{1.1pt}',r'\renewcommand{\arraystretch}{1.0}',r'\caption{EPFL '+str(k)+r'-input inventory: physical area (A), unloaded block delay (D), and mapping runtime in seconds (T). $\leq$ denotes a conservative upper bound; -- denotes unavailable runtime. Fixed method configurations; F/N retain failure/node-rejection status.}',r'\label{tab:epfl'+str(k)+r'area}\label{tab:epfl'+str(k)+r'delay}',r'\begin{tabular}{@{}l'+('rrr'*6)+r'@{}}\toprule','Design & '+' & '.join(r'\multicolumn{3}{c}{'+x+'}'for x in labels)+r' \\',' '.join(r'\cmidrule(lr){'+str(2+3*i)+'-'+str(4+3*i)+'}'for i in range(6)),' & '+' & '.join(['A & D & T']*6)+r' \\ \midrule']
 designs=list(dict.fromkeys(x['design']for x in old if x['k']==k))
 for design in designs:
  cells=[]
  for method in methods:
   if method!='eGraphMap':
    x=next(x for x in old if (x['k'],x['design'],x['method'])==(k,design,method));z=[x['area_cell'],x['delay_cell'],x['runtime_cell']];proof=dict(x)
   else:
    x=next(x for x in rows if (x['k'],x['bench'],x['profile'])==(k,design,'full'));status='N' if (x.get('failure')or{}).get('stage')=='cumulative_node_budget' else 'F';z=[f"{x['area']:.2f}",f"{x['delay']:.2f}",r'$\leq$'+f"{math.ceil(x['mapping_wall_upper_secs']*100)/100:.2f}"]if x['valid']else[status,status,'--'];proof=dict(x,method=method,design=design)
   cells.extend(z);table_sources.append(dict(k=k,design=design,method=method,cells=z,source=proof))
  lines.append(design.replace('_',r'\_')+' & '+' & '.join(cells)+r' \\')
 lines.append(r'\bottomrule\end{tabular}\end{table*}');tables.append('\n'.join(lines))
a=s.index('% BEGIN EPFL COMPLETE TABLES');b=s.index('% END EPFL COMPLETE TABLES')+len('% END EPFL COMPLETE TABLES');s=s[:a]+'% BEGIN EPFL COMPLETE TABLES\n'+'\n\n'.join(tables)+'\n% END EPFL COMPLETE TABLES'+s[b:]
full=[r for r in rows if r['profile']=='full'];fullok=[r for r in full if r['valid']];summary=q['summary'];n=len(fullok)
assert not any(g['passed'] for g in q['gates']), 'Inspect new gate outcomes before using failure-scope prose'
a=s.index('The proposed method has three components.');b=s.index('\n\nStandard-cell evaluation',a)
s=s[:a]+"""The study combines three mechanisms. First, structural cuts and exact
functional-quotient boundaries are constructed over the retained e-graph,
rather than committing to one extracted Boolean network. Second, matching
retains input phase, pin-specific delay and conditional care information;
SDC matches remain outside the global equivalence relation. Third,
whole-cover recovery separates physical-instance activation from binding,
charges shared cells once, and protects an already visited seed while
reducing actual area under a validated delay bound. Explicit source
proofs accompany exchanged bindings. The implementation exports acyclic
netlists and checks primary-output equivalence independently. Joint-output
selection is retained as an extension.
"""+s[b:]
# Replace old cross-version abstract; component outcomes enter only from verified data.
a=s.index('Two fixed profiles each produce');b=s.index('\\end{abstract}',a)
s=s[:a]+f'''One uniformly selected delay-area configuration produces {n} verified
covers across 40 circuit/library cases. Seven independent component
removals use the same executable, input and budgets; all failed and
unfavorable outcomes remain in scope. Three repeated runs on sqrt,
sin and priority produce {q['repetition_CEC']} CEC passes in
{q['repetition_attempts']} attempts across the eight settings. Conditional timing
gains do not establish full-suite dominance; candidate coverage,
area costs and cumulative import limits remain open problems.
'''+s[b:]
s=s.replace('Each mapping invocation has a 300-second allowance; preparation,', 'Each circuit/method case has a cumulative 300-second mapping allowance; preparation,')
s=s.replace('Mapper process guards include internal reports. X omits optional pool\nproxy rows while retaining exact counts and selected-binding proofs;', 'Mapper process guards include internal reports. The mapper omits optional\npool proxy rows while retaining exact counts and selected-binding proofs;').replace('or B/X internal reports;','or eGraphMap internal reports;')
s=s.replace('ownership, dependency-driven flow and a 0.25 phase window. Small-cut', 'ownership, dependency-driven flow and a 0.25 phase window. Stage checks\noccur between atomic trials; the fractions are not preemptive caps. Small-cut')
a=s.index('CBC is disabled. Tables show two uniform');b=s.index('\n\nThe evaluator charges',a)
s=s[:a]+'''CBC is disabled. The main tables contain one uniform eGraphMap
configuration with functional cuts, proof-preserving exchange,
fixed-bound shared-area recovery, required retention-witness reuse and
sparse ownership transactions. It was fixed before the new experiments;
no per-design configuration or source selection is made. The full
profile rejects points that worsen either pre-exchange seed metric;
this explicit area guard can exclude faster, larger covers. Independent
removals share one instrumented executable; their switches default to
off and do not change the full configuration's algorithm.
'''+s[b:]
a=s.index('Tables~\\ref{tab:epfl3area} and~\\ref{tab:epfl4area} combine');b=s.index('\n\\subsection{Baseline adaptations}',a)
s=s[:a]+f'''Tables~\\ref{{tab:epfl3area}} and~\\ref{{tab:epfl4area}} combine area, delay
and mapping runtime for ABC map, delay-mode emap, depth-oriented EqMap,
delay-oriented E-Syn, native final E-morphic SA, and the fixed eGraphMap
configuration. Every eGraphMap point comes from its fresh complete
40-case run, never the best target repetition. Area-oriented baseline
configurations and staging controls remain in the machine-readable data.
F denotes a failed or unmeasured result; N denotes cumulative import
rejection. Failed cases are retained rather than assigned numeric PPA.

The selected configuration has {n} validated covers and {40-n} failed
cases. Exact bounded cone import admits log2 and multiplier, but coverage
is not superiority over unavailable baselines. Full-suite delay-area
and Pareto gates remain false. The restricted inventories contain
single-output cells and do not establish an industrial multi-output
advantage.
'''+s[b:]
# Ablation counts are ablated relative to full; no additive-causality claim.
names={'full':'Full configuration','no_functional_cuts':'No functional quotients','single_witness_cuts':'One-witness structural cuts','no_input_phase':'No input-phase matching','canonical_pins':'Canonical pin assignment','no_sdc':'No SDC matching','no_shared_area':'No post-phase area recovery','no_incumbent_guard':'No seed-metric protection'}
trip=lambda d:'/'.join(str(d.get(k,0))for k in ['lower','equal','higher'])
lines=[r'\begin{table*}[!t]\centering\footnotesize',r'\setlength{\tabcolsep}{2.5pt}',r'\caption{Independent removals from the fixed configuration, both inventories. A/D counts are lower/equal/higher for the ablated setting among jointly legal full-suite pairs. Repeated CEC is out of 18 attempts per setting; repeated A/D use same-round jointly legal pairs. Failure coverage is retained, not folded into PPA counts. T is the median mapping-process wall upper bound (seconds) over successful full-suite runs, excluding external preparation, CEC and evaluation.}',r'\label{tab:ablation}',r'\begin{tabular}{lrrrrrrr}\toprule',r'Setting & CEC/40 & A & D & T & Repeat CEC/18 & Repeat A & Repeat D \\ \midrule']
for profile,x in summary.items():
 vals=[names[profile],f"{x['full_CEC']}/40",trip(x['full_area'])if profile!='full'else'--',trip(x['full_delay'])if profile!='full'else'--',(r'$\leq$'+f"{math.ceil(statistics.median(r['mapping_wall_upper_secs']for r in rows if r['profile']==profile and r['valid'])*100)/100:.2f}")if x['full_CEC']else'--',f"{x['repeat_CEC']}/18",trip(x['repeat_area'])if profile!='full'else'--',trip(x['repeat_delay'])if profile!='full'else'--'];lines.append(' & '.join(vals)+r' \\')
lines.append(r'\bottomrule\end{tabular}\end{table*}')
a=s.index('\\section{Discussion and Conclusion}');b=s.index('\\clearpage',a)
body='\n'.join(lines)+'\n\n'+'''\\subsection{Independent component removals}
Table~\\ref{tab:ablation} uses all 20 designs and both inventories for
each setting. The seven removals are fixed independently, not cumulative.
Functional-quotient construction is disabled in both initial cuts and
exchange. The one-witness setting changes optional structural cut
enumeration while retaining identical mandatory source fallbacks;
functional quotients remain a separate factor. Input-phase removal
rejects complemented input assignments but retains explicit inverters.
Canonical pin assignment retains real pin delays but restricts functional
assignment freedom; it does not isolate pin-delay lookup alone. SDC removal
sets the boundary-support allowance to zero without introducing unions.

The area-recovery removal omits post-phase required-time area flow and
actual-area substitution; common seed initialization remains unchanged.
The incumbent removal disables seed-referenced metric protection: the
dual-metric envelope, seed-area ceiling and its bound-feasible DA cache.
Ordinary working/fast-cover selection remains, as do cycle checks,
generator proofs and pinned physical bindings. It is a module removal,
not a cap-only experiment or a removal of correctness checks. All
settings retain the same cumulative node, cut, retained-pool and global
time limits and stage fractions. No replacement stage is added, but
earlier completion can change the time remaining for existing stages.

Three fresh runs of every setting use sqrt, sin and priority in both
inventories, with rotated setting order and alternating circuit/library
order. All per-case A/D/T values, failures and ranges are retained.
Paired counts condition on two valid covers; coverage is reported
separately. These are targeted repeats, not machine-independent or
full-suite stability guarantees. Component interactions and time-limited
search mean that removal effects need not be additive or uniformly
beneficial.



\\section{Discussion and Conclusion}
The fixed configuration avoids selecting different builds for individual
circuits. Independent removals identify effects within its bounded search,
not universal benefits of each component. Missing PPA records remain
failures, and equal-delay area regressions are retained. Full-scope gates
still fail; post-hoc area-delay checks are not area-oriented optimization
experiments.

'''
for k in [3,4]:
 sr=next(r for r in full if r['k']==k and r['bench']=='sqrt');rr=next(r for r in ranges if r['k']==k and r['bench']=='sqrt'and r['profile']=='full')
 if sr['valid']:
  emap=next(x for x in old if (x['k'],x['design'],x['method'])==(k,'sqrt','mockturtle_emap_delay_resyn2'));A=float(emap['area_cell']);D=float(emap['delay_cell']);gain=(D-sr['delay'])/D*100;cost=(sr['area']-A)/A*100
  body+=f"For the {k}-input inventory, sqrt has delay {sr['delay']:.2f} and area {sr['area']:.2f}; relative to emap, delay changes by {-gain:.3f}\\% and area by {cost:+.1f}\\%. "
  if rr['area']:
   dt=f"delay {rr['delay']['min']:.2f}" if rr['delay']['min']==rr['delay']['max'] else f"delay {rr['delay']['min']:.2f}--{rr['delay']['max']:.2f}"
   body+=f"Its {rr['CEC']}/3 successful repeats have area {rr['area']['min']:.2f}--{rr['area']['max']:.2f} and {dt}. "
adverse_full=next(r for r in rows if r['k']==4 and r['bench']=='sin' and r['profile']=='full')
adverse_cut=next(r for r in rows if r['k']==4 and r['bench']=='sin' and r['profile']=='no_functional_cuts')
if adverse_full['valid'] and adverse_cut['valid']:
 body+=f"\n\nFor four-input sin, removing functional quotients changes delay from {adverse_full['delay']:.2f} to {adverse_cut['delay']:.2f}, while area changes from {adverse_full['area']:.2f} to {adverse_cut['area']:.2f}. Both points remain in the comparison; this interaction is not hidden by choosing a different main-table configuration. "
proof_count=q.get('selected_mechanism_totals',{}).get('full',{}).get('selected_sdc_only_bindings',0)
body+=f"\n\nThe final banks contain {proof_count} selected target bindings with only SDC generator evidence. Disabling SDC nevertheless leaves all {q['summary']['no_sdc']['full_delay'].get('equal',0)} jointly legal delays unchanged. Admission capability is not evidence of an independent timing gain on this suite. "
if q.get('storage_sensitivity'):
 body+=f"\n\nOne cache-copy I/O interval overlaps a wall-bounded recovery in the original multiplier area-removal case. The original observation is retained; a separate, timestamp-triggered 16-case multiplier sensitivity repeat yields {q['storage_sensitivity']['CEC']}/16 CEC passes and replaces no primary point. "
body+=f"\n\nWithout post-phase area recovery, {q['summary']['no_shared_area']['full_area'].get('higher',0)} jointly legal covers have higher area and all {q['summary']['no_shared_area']['full_delay'].get('equal',0)} have unchanged delay. Removing input-phase matching leaves {q['summary']['no_input_phase']['full_CEC']}/40 legal covers, and canonical pin assignment leaves {q['summary']['canonical_pins']['full_CEC']}/40. These losses include failed extraction rather than solely worse PPA. Functional-quotient removal also improves delay in {q['summary']['no_functional_cuts']['full_delay'].get('lower',0)} legal pair; the full setting is not uniformly superior. "
if q['final_seed_envelope_violations'].get('full')==0 and q['final_seed_envelope_violations'].get('no_incumbent_guard')==0:
 body+=' The full and no-seed-protection settings both remain within their respective seed envelopes in these full-suite samples; their quality differences do not establish that the final acceptance guard was binding.'
body+='''

Earlier cross-version studies and their failures remain archived;
they are not counted as component ablations. Same-binary removals do
not establish preservation of a historical full-budget shared-area
cover. Recovering that reference, widening useful candidates and safely
compressing rejected inputs remain open.

'''
s=s[:a]+body+s[b:];p=R/'epmapping_paper/DAC-eGraphMap-draft/main.tex';tmp=p.with_suffix('.tex.pending');tmp.write_text(s);os.replace(tmp,p);(E/'paper_table_sources.json').write_text(json.dumps(dict(records=table_sources,selected_configuration='full',selected_before_experiments=True,mapper_sha256=q['frozen_mapper_sha256'],source_sha256=sha(p)),indent=2));print('paper source updated from verified same-binary experiment; selected full profile only')
