from pathlib import Path
import json,hashlib,shutil,subprocess,sys
R=Path('/home/flynn/workplace/MIGBalance');E=R/'results_v2/independent_components_20261019';D=R/'scripts/experiments/campaigns';T=Path('/tmp/emapper-independent-archives-20261019');T.mkdir(exist_ok=True)
assert (E/'data_ready.json').exists(),'no archival I/O during timed experiments'
q=json.loads((E/'evidence/qualification.json').read_text());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();S=E/'source_snapshot';S.mkdir(exist_ok=False);index=[]
paths={Path(p):h for p,h in q['source_hashes'].items()}
subjects=R/'results_v2/epfl_resyn2_subjects_20261012/report.json'
for row in json.loads(subjects.read_text())['results']:
 for p,h in [(R/'tools/mockturtle/experiments/benchmarks'/(row['bench']+'.aig'),row['input_sha256']),(subjects.parent/(row['bench']+'.resyn2.aig'),row['preprocessing']['sha256'])]:
  assert sha(p)==h;paths[p]=h
for p in [D/'check_independent_components.py',D/'finalize_independent_components.py',R/'scripts/experiments/check_mapping_dominance.py',E/'finalize_results.py',E/'plan.json',E/'storage_event.json',E/'update_paper.py',E/'paper_before.tex',R/'results_v2/combined_runtime_tables_20261019/runtime_sources.json',*[R/f'results_v2/guarded_joint_evidence_20261016/baseline_scope/baselines_{k}in.json' for k in [3,4]]]:
 paths[p]=sha(p)
for p,h in paths.items():
 assert sha(p)==h
 try:rel=Path('workspace')/p.relative_to(R)
 except ValueError:rel=Path('external')/str(p).lstrip('/')
 dest=S/rel;dest.parent.mkdir(exist_ok=True,parents=True);shutil.copy2(p,dest);assert sha(dest)==h;index.append(dict(original=str(p),snapshot=str(rel),sha256=h,bytes=p.stat().st_size))
(S/'index.json').write_text(json.dumps(index,indent=2));(E/'snapshot_index.json').write_text(json.dumps(index,indent=2))
# All newly archived payloads are already completed and independently audited.
script=Path('/tmp/archive_independent_payload_20261019.py');text=(D/'archive_component_artifacts.py').read_text().replace('R=Path(__file__).resolve().parents[3]',"R=Path('/home/flynn/workplace/MIGBalance')").replace("dest=R/'results_v2/archives'","dest=Path('/tmp/emapper-independent-archives-20261019')").replace("['tar','-C'","['tar','--hard-dereference','-C'");script.write_text(text)
items=[('/tmp/emapper-independent-full-20261019','independent_components_full_20261019')]+[('/tmp/emapper-independent-repeat-r%d-20261019'%i,'independent_components_repeat_r%d_20261019'%i)for i in range(3)]+[('/tmp/emapper-independent-storage-replay-20261019','independent_components_storage_replay_20261019'),('/tmp/emapper-independent-smoke-20261019','independent_components_smoke_20261019')]
records=[]
for folder,label in items:
 print('ARCHIVE',label,flush=True);p=subprocess.run([sys.executable,str(script),folder,'--label',label],cwd=R,capture_output=True,text=True);(E/(label+'.archive.log')).write_text(p.stdout+p.stderr);assert p.returncode==0,p.stderr
 v=json.loads((T/(label+'.verified.json')).read_text());records.append(v);(E/'archives_temporary_verified.json').write_text(json.dumps(records,indent=2))
(E/'archival_ready.json').write_text(json.dumps({'archives':records,'source_snapshot':str(S),'native_mappings_complete':True,'source_index':str(E/'snapshot_index.json'),'workspace_copy_pending':True},indent=2));print('ARCHIVES_MEMBER_SHA_VERIFIED_AND_SOURCE_SNAPSHOTTED',flush=True)
