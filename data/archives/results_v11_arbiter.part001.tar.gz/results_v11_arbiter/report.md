# Arbiter diagnosis and feasible improvement

All nine runs pass CEC, disable whole-window synthesis, and use a 1000-second post-mapping cap. They keep the initial-output-delay bound. The two preprocessing arms also improve over the original 557.72 / 999.87 mapping.

## Structure and scope

The original AIG has 256 inputs, 129 outputs and 11839 ANDs. The original high-effort recipe stops without accepting any iteration. Mapping produces 6163 cells, including 5504 AO21 cells (89.31%); the longest consecutive AO21 chain is 43 cells and 5376 AO21 cells have only one consumer. The replicated deep chains offer scope for restructuring and sharing across larger cones. This is a structural diagnosis, not an attribution of all reject_delay counts to those chains.

Seven identical-input controls (baseline, hybrid matching, expanded node/per-cut care, 8-leaf cuts, exact small-cut synthesis and deeper bidirectional e-graphs) all return the unchanged 557.72 / 999.87 netlist. Simply increasing these tested local budgets does not explain the published arbiter gain.

## Results

| Variant | Initial area | Initial delay | Final area | Final delay | CEC |
| --- | ---: | ---: | ---: | ---: | --- |
| control | 557.72 | 999.87 | 557.72 | 999.87 | 1 |
| hybrid | 557.72 | 999.87 | 557.72 | 999.87 | 1 |
| care12 | 557.72 | 999.87 | 557.72 | 999.87 | 1 |
| care_percut12 | 557.72 | 999.87 | 557.72 | 999.87 | 1 |
| wide8 | 557.72 | 999.87 | 557.72 | 999.87 | 1 |
| exact4 | 557.72 | 999.87 | 557.72 | 999.87 | 1 |
| egg_deeper | 557.72 | 999.87 | 557.72 | 999.87 | 1 |
| pre_syn4 | 264.43 | 373.01 | 261.89 | 368.93 | 1 |
| pre_sopb | 296.71 | 348.74 | 293.32 | 334.76 | 1 |

The selected area-first result is syn4: AIG preprocessing reaches 4166 ANDs after eight accepted iterations; the initial mapping becomes 264.43 / 373.01. Post-mapping then reaches 261.89 / 368.93 after four rounds. Total process wall time is 98 seconds; the measured optimizer phase is 82.11 seconds.

Compared with the original mapping: area -53.04%, delay -63.10%. The post-mapping stage alone changes area by -0.96% and delay by -1.09%. Relative to the rounded published ASPDAC final result (268.82 / 604.27), changes are -2.58% / -38.95%.

The dominant gain is from a different initial AIG preprocessing recipe, not from cut-only post-mapping on the old start. The original paper table and all-design means are therefore preserved. This circuit-specific exploration does not establish an all-design improvement; the same generic recipe must be tested on the full suite before adopting it for a new main comparison.

## Reproduction

Frozen diagnosis: `python3 scripts/experiments/analyze_arbiter.py`.

The generic structural-input entry works for any benchmark (no arbiter special case):

```bash
bash scripts/experiments/run_structural_input.sh results_structural arbiter syn4
```

`best/epmapping_mapped.v` is the CEC-verified selected output. All logs, initial and final netlists, exact profiles and hashes remain under runs/ and inputs/.
