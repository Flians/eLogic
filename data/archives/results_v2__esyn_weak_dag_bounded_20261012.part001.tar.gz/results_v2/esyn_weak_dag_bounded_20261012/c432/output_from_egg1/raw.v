// Benchmark "/home/flynn/workplace/MIGBalance/results_v2/esyn_weak_dag_bounded_20261012/c432/output_from_egg1/logic" written by ABC on Mon Oct 12 13:43:21 2026

module \/home/flynn/workplace/MIGBalance/results_v2/esyn_weak_dag_bounded_20261012/c432/output_from_egg1/logic  ( 
    G34, G28, G30, G24, G26, G20, G22, G16, G18, G12, G14, G8, G10, G4, G6,
    G1, G2, G35, G31, G27, G23, G19, G15, G11, G7, G3, G36, G33, G29, G25,
    G21, G17, G13, G9, G5, G32,
    G426, G427, G428, G429, G430, G431, G432  );
  input  G34, G28, G30, G24, G26, G20, G22, G16, G18, G12, G14, G8, G10,
    G4, G6, G1, G2, G35, G31, G27, G23, G19, G15, G11, G7, G3, G36, G33,
    G29, G25, G21, G17, G13, G9, G5, G32;
  output G426, G427, G428, G429, G430, G431, G432;
  wire new_n44_, new_n45_, new_n46_, new_n47_, new_n48_, new_n49_, new_n50_,
    new_n51_, new_n52_, new_n53_, new_n54_, new_n55_, new_n56_, new_n57_,
    new_n58_, new_n59_, new_n60_, new_n61_, new_n62_, new_n63_, new_n64_,
    new_n65_, new_n66_, new_n67_, new_n69_, new_n70_, new_n71_, new_n72_,
    new_n73_, new_n74_, new_n75_, new_n76_, new_n77_, new_n78_, new_n79_,
    new_n80_, new_n81_, new_n82_, new_n83_, new_n84_, new_n85_, new_n86_,
    new_n87_, new_n88_, new_n89_, new_n90_, new_n91_, new_n92_, new_n93_,
    new_n94_, new_n95_, new_n97_, new_n98_, new_n99_, new_n100_, new_n101_,
    new_n102_, new_n103_, new_n104_, new_n105_, new_n106_, new_n107_,
    new_n108_, new_n109_, new_n110_, new_n111_, new_n112_, new_n113_,
    new_n114_, new_n115_, new_n116_, new_n117_, new_n118_, new_n119_,
    new_n120_, new_n121_, new_n122_, new_n123_, new_n124_, new_n125_,
    new_n126_, new_n127_, new_n128_, new_n129_, new_n131_, new_n132_,
    new_n133_, new_n134_, new_n135_, new_n136_, new_n137_, new_n138_,
    new_n139_, new_n140_, new_n141_, new_n142_, new_n143_, new_n144_,
    new_n145_, new_n146_, new_n147_, new_n148_, new_n149_, new_n150_,
    new_n151_, new_n152_, new_n153_, new_n154_, new_n155_, new_n156_,
    new_n157_, new_n158_, new_n159_, new_n160_, new_n161_, new_n162_,
    new_n163_, new_n164_, new_n165_, new_n166_, new_n167_, new_n168_,
    new_n169_, new_n170_, new_n171_, new_n172_, new_n174_, new_n176_,
    new_n177_, new_n178_, new_n179_, new_n181_, new_n182_, new_n183_;
  INVx1_ASAP7_75t_R   g000(.A(G34), .Y(new_n44_));
  INVx1_ASAP7_75t_R   g001(.A(G28), .Y(new_n45_));
  INVx1_ASAP7_75t_R   g002(.A(G30), .Y(new_n46_));
  INVx1_ASAP7_75t_R   g003(.A(G26), .Y(new_n47_));
  INVx1_ASAP7_75t_R   g004(.A(G20), .Y(new_n48_));
  INVx1_ASAP7_75t_R   g005(.A(G22), .Y(new_n49_));
  INVx1_ASAP7_75t_R   g006(.A(G18), .Y(new_n50_));
  INVx1_ASAP7_75t_R   g007(.A(G14), .Y(new_n51_));
  INVx1_ASAP7_75t_R   g008(.A(G10), .Y(new_n52_));
  INVx1_ASAP7_75t_R   g009(.A(G6), .Y(new_n53_));
  INVx1_ASAP7_75t_R   g010(.A(G2), .Y(new_n54_));
  NAND2x1_ASAP7_75t_R g011(.A(new_n45_), .B(G30), .Y(new_n55_));
  NOR2x1_ASAP7_75t_R  g012(.A(new_n44_), .B(G32), .Y(new_n56_));
  AO21x1_ASAP7_75t_R  g013(.A1(new_n45_), .A2(G30), .B(new_n56_), .Y(new_n57_));
  NAND2x1_ASAP7_75t_R g014(.A(new_n48_), .B(G22), .Y(new_n58_));
  NOR2x1_ASAP7_75t_R  g015(.A(G24), .B(new_n47_), .Y(new_n59_));
  AO21x1_ASAP7_75t_R  g016(.A1(new_n48_), .A2(G22), .B(new_n59_), .Y(new_n60_));
  NOR2x1_ASAP7_75t_R  g017(.A(G12), .B(new_n51_), .Y(new_n61_));
  NOR2x1_ASAP7_75t_R  g018(.A(G16), .B(new_n50_), .Y(new_n62_));
  NOR2x1_ASAP7_75t_R  g019(.A(G1), .B(new_n54_), .Y(new_n63_));
  NOR2x1_ASAP7_75t_R  g020(.A(G4), .B(new_n53_), .Y(new_n64_));
  NOR2x1_ASAP7_75t_R  g021(.A(G8), .B(new_n52_), .Y(new_n65_));
  OR3x1_ASAP7_75t_R   g022(.A(new_n63_), .B(new_n64_), .C(new_n65_), .Y(new_n66_));
  OR3x1_ASAP7_75t_R   g023(.A(new_n61_), .B(new_n62_), .C(new_n66_), .Y(new_n67_));
  OR3x1_ASAP7_75t_R   g024(.A(new_n57_), .B(new_n60_), .C(new_n67_), .Y(G426));
  INVx1_ASAP7_75t_R   g025(.A(G426), .Y(new_n69_));
  XOR2x2_ASAP7_75t_R  g026(.A(new_n63_), .B(G426), .Y(new_n70_));
  OR3x1_ASAP7_75t_R   g027(.A(new_n54_), .B(G3), .C(new_n70_), .Y(new_n71_));
  XOR2x2_ASAP7_75t_R  g028(.A(new_n64_), .B(G426), .Y(new_n72_));
  OR3x1_ASAP7_75t_R   g029(.A(new_n53_), .B(G7), .C(new_n72_), .Y(new_n73_));
  XOR2x2_ASAP7_75t_R  g030(.A(new_n65_), .B(G426), .Y(new_n74_));
  OR3x1_ASAP7_75t_R   g031(.A(new_n52_), .B(G11), .C(new_n74_), .Y(new_n75_));
  AND3x1_ASAP7_75t_R  g032(.A(new_n71_), .B(new_n73_), .C(new_n75_), .Y(new_n76_));
  XOR2x2_ASAP7_75t_R  g033(.A(new_n61_), .B(G426), .Y(new_n77_));
  OR3x1_ASAP7_75t_R   g034(.A(new_n51_), .B(G15), .C(new_n77_), .Y(new_n78_));
  XOR2x2_ASAP7_75t_R  g035(.A(new_n62_), .B(G426), .Y(new_n79_));
  OR3x1_ASAP7_75t_R   g036(.A(new_n50_), .B(G19), .C(new_n79_), .Y(new_n80_));
  AND3x1_ASAP7_75t_R  g037(.A(new_n78_), .B(new_n80_), .C(new_n76_), .Y(new_n81_));
  INVx1_ASAP7_75t_R   g038(.A(new_n81_), .Y(new_n82_));
  XOR2x2_ASAP7_75t_R  g039(.A(new_n59_), .B(G426), .Y(new_n83_));
  OR3x1_ASAP7_75t_R   g040(.A(new_n47_), .B(G27), .C(new_n83_), .Y(new_n84_));
  INVx1_ASAP7_75t_R   g041(.A(new_n84_), .Y(new_n85_));
  XOR2x2_ASAP7_75t_R  g042(.A(new_n58_), .B(new_n69_), .Y(new_n86_));
  OR3x1_ASAP7_75t_R   g043(.A(new_n49_), .B(G23), .C(new_n86_), .Y(new_n87_));
  INVx1_ASAP7_75t_R   g044(.A(new_n87_), .Y(new_n88_));
  XOR2x2_ASAP7_75t_R  g045(.A(new_n56_), .B(G426), .Y(new_n89_));
  OR3x1_ASAP7_75t_R   g046(.A(new_n44_), .B(G35), .C(new_n89_), .Y(new_n90_));
  XOR2x2_ASAP7_75t_R  g047(.A(new_n55_), .B(new_n69_), .Y(new_n91_));
  OR3x1_ASAP7_75t_R   g048(.A(new_n46_), .B(G31), .C(new_n91_), .Y(new_n92_));
  NAND2x1_ASAP7_75t_R g049(.A(new_n90_), .B(new_n92_), .Y(new_n93_));
  OR3x1_ASAP7_75t_R   g050(.A(new_n85_), .B(new_n88_), .C(new_n93_), .Y(new_n94_));
  NOR2x1_ASAP7_75t_R  g051(.A(new_n82_), .B(new_n94_), .Y(new_n95_));
  INVx1_ASAP7_75t_R   g052(.A(new_n95_), .Y(G427));
  OR3x1_ASAP7_75t_R   g053(.A(new_n46_), .B(G33), .C(new_n91_), .Y(new_n97_));
  INVx1_ASAP7_75t_R   g054(.A(new_n97_), .Y(new_n98_));
  XNOR2x2_ASAP7_75t_R g055(.A(new_n92_), .B(new_n95_), .Y(new_n99_));
  OR3x1_ASAP7_75t_R   g056(.A(new_n44_), .B(G36), .C(new_n89_), .Y(new_n100_));
  XOR2x2_ASAP7_75t_R  g057(.A(new_n90_), .B(new_n95_), .Y(new_n101_));
  NOR2x1_ASAP7_75t_R  g058(.A(new_n100_), .B(new_n101_), .Y(new_n102_));
  AO21x1_ASAP7_75t_R  g059(.A1(new_n98_), .A2(new_n99_), .B(new_n102_), .Y(new_n103_));
  OR3x1_ASAP7_75t_R   g060(.A(new_n49_), .B(G25), .C(new_n86_), .Y(new_n104_));
  INVx1_ASAP7_75t_R   g061(.A(new_n104_), .Y(new_n105_));
  XNOR2x2_ASAP7_75t_R g062(.A(new_n87_), .B(new_n95_), .Y(new_n106_));
  OR3x1_ASAP7_75t_R   g063(.A(new_n47_), .B(G29), .C(new_n83_), .Y(new_n107_));
  XOR2x2_ASAP7_75t_R  g064(.A(new_n84_), .B(new_n95_), .Y(new_n108_));
  NOR2x1_ASAP7_75t_R  g065(.A(new_n107_), .B(new_n108_), .Y(new_n109_));
  AO21x1_ASAP7_75t_R  g066(.A1(new_n105_), .A2(new_n106_), .B(new_n109_), .Y(new_n110_));
  OR3x1_ASAP7_75t_R   g067(.A(new_n51_), .B(G17), .C(new_n77_), .Y(new_n111_));
  INVx1_ASAP7_75t_R   g068(.A(new_n111_), .Y(new_n112_));
  XNOR2x2_ASAP7_75t_R g069(.A(new_n78_), .B(new_n95_), .Y(new_n113_));
  OR3x1_ASAP7_75t_R   g070(.A(new_n50_), .B(G21), .C(new_n79_), .Y(new_n114_));
  XOR2x2_ASAP7_75t_R  g071(.A(new_n80_), .B(new_n95_), .Y(new_n115_));
  NOR2x1_ASAP7_75t_R  g072(.A(new_n114_), .B(new_n115_), .Y(new_n116_));
  AO21x1_ASAP7_75t_R  g073(.A1(new_n112_), .A2(new_n113_), .B(new_n116_), .Y(new_n117_));
  OR3x1_ASAP7_75t_R   g074(.A(new_n54_), .B(G5), .C(new_n70_), .Y(new_n118_));
  INVx1_ASAP7_75t_R   g075(.A(new_n118_), .Y(new_n119_));
  XNOR2x2_ASAP7_75t_R g076(.A(new_n71_), .B(new_n95_), .Y(new_n120_));
  OR3x1_ASAP7_75t_R   g077(.A(new_n53_), .B(G9), .C(new_n72_), .Y(new_n121_));
  XOR2x2_ASAP7_75t_R  g078(.A(new_n73_), .B(new_n95_), .Y(new_n122_));
  NOR2x1_ASAP7_75t_R  g079(.A(new_n121_), .B(new_n122_), .Y(new_n123_));
  AO21x1_ASAP7_75t_R  g080(.A1(new_n119_), .A2(new_n120_), .B(new_n123_), .Y(new_n124_));
  OR3x1_ASAP7_75t_R   g081(.A(new_n52_), .B(G13), .C(new_n74_), .Y(new_n125_));
  INVx1_ASAP7_75t_R   g082(.A(new_n125_), .Y(new_n126_));
  XNOR2x2_ASAP7_75t_R g083(.A(new_n75_), .B(new_n95_), .Y(new_n127_));
  AO21x1_ASAP7_75t_R  g084(.A1(new_n126_), .A2(new_n127_), .B(new_n124_), .Y(new_n128_));
  OR2x4_ASAP7_75t_R   g085(.A(new_n117_), .B(new_n128_), .Y(new_n129_));
  OR3x1_ASAP7_75t_R   g086(.A(new_n103_), .B(new_n110_), .C(new_n129_), .Y(G428));
  AO21x1_ASAP7_75t_R  g087(.A1(G33), .A2(G428), .B(new_n46_), .Y(new_n131_));
  AND2x2_ASAP7_75t_R  g088(.A(G31), .B(G427), .Y(new_n132_));
  AO21x1_ASAP7_75t_R  g089(.A1(G28), .A2(G426), .B(new_n132_), .Y(new_n133_));
  NOR2x1_ASAP7_75t_R  g090(.A(new_n131_), .B(new_n133_), .Y(new_n134_));
  INVx1_ASAP7_75t_R   g091(.A(new_n134_), .Y(new_n135_));
  AOI21x1_ASAP7_75t_R g092(.A1(G36), .A2(G428), .B(new_n44_), .Y(new_n136_));
  AND2x2_ASAP7_75t_R  g093(.A(G35), .B(G427), .Y(new_n137_));
  AOI21x1_ASAP7_75t_R g094(.A1(G32), .A2(G426), .B(new_n137_), .Y(new_n138_));
  AO21x1_ASAP7_75t_R  g095(.A1(new_n136_), .A2(new_n138_), .B(new_n134_), .Y(new_n139_));
  AO21x1_ASAP7_75t_R  g096(.A1(G25), .A2(G428), .B(new_n49_), .Y(new_n140_));
  AND2x2_ASAP7_75t_R  g097(.A(G23), .B(G427), .Y(new_n141_));
  AO21x1_ASAP7_75t_R  g098(.A1(G20), .A2(G426), .B(new_n141_), .Y(new_n142_));
  NOR2x1_ASAP7_75t_R  g099(.A(new_n140_), .B(new_n142_), .Y(new_n143_));
  INVx1_ASAP7_75t_R   g100(.A(new_n143_), .Y(new_n144_));
  AO21x1_ASAP7_75t_R  g101(.A1(G29), .A2(G428), .B(new_n47_), .Y(new_n145_));
  AND2x2_ASAP7_75t_R  g102(.A(G27), .B(G427), .Y(new_n146_));
  AO21x1_ASAP7_75t_R  g103(.A1(G24), .A2(G426), .B(new_n146_), .Y(new_n147_));
  NOR2x1_ASAP7_75t_R  g104(.A(new_n145_), .B(new_n147_), .Y(new_n148_));
  OR3x1_ASAP7_75t_R   g105(.A(new_n143_), .B(new_n148_), .C(new_n139_), .Y(new_n149_));
  AO21x1_ASAP7_75t_R  g106(.A1(G17), .A2(G428), .B(new_n51_), .Y(new_n150_));
  AND2x2_ASAP7_75t_R  g107(.A(G15), .B(G427), .Y(new_n151_));
  AO21x1_ASAP7_75t_R  g108(.A1(G12), .A2(G426), .B(new_n151_), .Y(new_n152_));
  NOR2x1_ASAP7_75t_R  g109(.A(new_n150_), .B(new_n152_), .Y(new_n153_));
  AO21x1_ASAP7_75t_R  g110(.A1(G21), .A2(G428), .B(new_n50_), .Y(new_n154_));
  AND2x2_ASAP7_75t_R  g111(.A(G19), .B(G427), .Y(new_n155_));
  AO21x1_ASAP7_75t_R  g112(.A1(G16), .A2(G426), .B(new_n155_), .Y(new_n156_));
  NOR2x1_ASAP7_75t_R  g113(.A(new_n154_), .B(new_n156_), .Y(new_n157_));
  NOR2x1_ASAP7_75t_R  g114(.A(new_n153_), .B(new_n157_), .Y(new_n158_));
  AO21x1_ASAP7_75t_R  g115(.A1(G9), .A2(G428), .B(new_n53_), .Y(new_n159_));
  AND2x2_ASAP7_75t_R  g116(.A(G7), .B(G427), .Y(new_n160_));
  AO21x1_ASAP7_75t_R  g117(.A1(G4), .A2(G426), .B(new_n160_), .Y(new_n161_));
  NOR2x1_ASAP7_75t_R  g118(.A(new_n159_), .B(new_n161_), .Y(new_n162_));
  AO21x1_ASAP7_75t_R  g119(.A1(G13), .A2(G428), .B(new_n52_), .Y(new_n163_));
  AND2x2_ASAP7_75t_R  g120(.A(G11), .B(G427), .Y(new_n164_));
  AO21x1_ASAP7_75t_R  g121(.A1(G8), .A2(G426), .B(new_n164_), .Y(new_n165_));
  NOR2x1_ASAP7_75t_R  g122(.A(new_n163_), .B(new_n165_), .Y(new_n166_));
  OR2x4_ASAP7_75t_R   g123(.A(new_n162_), .B(new_n166_), .Y(new_n167_));
  OR3x1_ASAP7_75t_R   g124(.A(new_n153_), .B(new_n157_), .C(new_n167_), .Y(new_n168_));
  AND2x2_ASAP7_75t_R  g125(.A(G5), .B(G428), .Y(new_n169_));
  AOI21x1_ASAP7_75t_R g126(.A1(G3), .A2(G427), .B(new_n169_), .Y(new_n170_));
  AOI21x1_ASAP7_75t_R g127(.A1(G1), .A2(G426), .B(new_n54_), .Y(new_n171_));
  NAND2x1_ASAP7_75t_R g128(.A(new_n170_), .B(new_n171_), .Y(new_n172_));
  OA21x2_ASAP7_75t_R  g129(.A1(new_n149_), .A2(new_n168_), .B(new_n172_), .Y(G429));
  OA21x2_ASAP7_75t_R  g130(.A1(new_n163_), .A2(new_n165_), .B(new_n153_), .Y(new_n174_));
  OR3x1_ASAP7_75t_R   g131(.A(new_n157_), .B(new_n174_), .C(new_n167_), .Y(G430));
  OR2x4_ASAP7_75t_R   g132(.A(new_n153_), .B(new_n166_), .Y(new_n176_));
  OR3x1_ASAP7_75t_R   g133(.A(new_n144_), .B(new_n157_), .C(new_n176_), .Y(new_n177_));
  INVx1_ASAP7_75t_R   g134(.A(new_n177_), .Y(new_n178_));
  AO21x1_ASAP7_75t_R  g135(.A1(new_n148_), .A2(new_n158_), .B(new_n178_), .Y(new_n179_));
  OR3x1_ASAP7_75t_R   g136(.A(new_n162_), .B(new_n166_), .C(new_n179_), .Y(G431));
  OR3x1_ASAP7_75t_R   g137(.A(new_n135_), .B(new_n148_), .C(new_n176_), .Y(new_n181_));
  INVx1_ASAP7_75t_R   g138(.A(new_n181_), .Y(new_n182_));
  OR2x4_ASAP7_75t_R   g139(.A(new_n162_), .B(new_n174_), .Y(new_n183_));
  OR3x1_ASAP7_75t_R   g140(.A(new_n178_), .B(new_n182_), .C(new_n183_), .Y(G432));
endmodule


