// Benchmark "/home/flynn/workplace/MIGBalance/results_v2/esyn_weak_dag_bounded_20261012/c1908/output_from_egg1/logic" written by ABC on Mon Oct 12 13:44:00 2026

module \/home/flynn/workplace/MIGBalance/results_v2/esyn_weak_dag_bounded_20261012/c1908/output_from_egg1/logic  ( 
    G24, G33, G31, G30, G32, G8, G6, G3, G15, G10, G12, G19, G28, G9, G14,
    G16, G18, G11, G5, G2, G27, G7, G4, G20, G13, G1, G17, G26, G22, G25,
    G21, G29, G23,
    G1899, G1884, G1885, G1898, G1886, G1887, G1888, G1889, G1890, G1891,
    G1892, G1893, G1894, G1895, G1896, G1897, G1900, G1901, G1902, G1903,
    G1904, G1905, G1906, G1907, G1908  );
  input  G24, G33, G31, G30, G32, G8, G6, G3, G15, G10, G12, G19, G28,
    G9, G14, G16, G18, G11, G5, G2, G27, G7, G4, G20, G13, G1, G17, G26,
    G22, G25, G21, G29, G23;
  output G1899, G1884, G1885, G1898, G1886, G1887, G1888, G1889, G1890, G1891,
    G1892, G1893, G1894, G1895, G1896, G1897, G1900, G1901, G1902, G1903,
    G1904, G1905, G1906, G1907, G1908;
  wire new_n59_, new_n60_, new_n61_, new_n62_, new_n63_, new_n64_, new_n65_,
    new_n66_, new_n67_, new_n68_, new_n69_, new_n70_, new_n71_, new_n72_,
    new_n73_, new_n74_, new_n75_, new_n76_, new_n77_, new_n78_, new_n79_,
    new_n80_, new_n81_, new_n82_, new_n83_, new_n84_, new_n85_, new_n86_,
    new_n87_, new_n88_, new_n89_, new_n90_, new_n91_, new_n92_, new_n93_,
    new_n94_, new_n95_, new_n96_, new_n97_, new_n98_, new_n99_, new_n100_,
    new_n101_, new_n102_, new_n103_, new_n104_, new_n105_, new_n106_,
    new_n107_, new_n108_, new_n109_, new_n110_, new_n111_, new_n112_,
    new_n113_, new_n114_, new_n115_, new_n116_, new_n117_, new_n118_,
    new_n119_, new_n120_, new_n121_, new_n122_, new_n123_, new_n124_,
    new_n125_, new_n126_, new_n127_, new_n128_, new_n129_, new_n130_,
    new_n131_, new_n132_, new_n133_, new_n134_, new_n135_, new_n136_,
    new_n137_, new_n138_, new_n139_, new_n140_, new_n141_, new_n142_,
    new_n143_, new_n144_, new_n145_, new_n146_, new_n147_, new_n148_,
    new_n149_, new_n150_, new_n152_, new_n153_, new_n154_, new_n155_,
    new_n156_, new_n162_, new_n166_, new_n167_, new_n168_, new_n169_,
    new_n174_, new_n178_, new_n179_, new_n180_, new_n181_, new_n182_,
    new_n183_, new_n184_, new_n185_, new_n186_, new_n187_, new_n188_,
    new_n189_, new_n190_, new_n191_, new_n192_, new_n193_, new_n194_,
    new_n195_, new_n196_, new_n198_, new_n199_, new_n200_, new_n202_,
    new_n203_, new_n205_, new_n206_, new_n208_, new_n209_, new_n211_,
    new_n212_, new_n214_, new_n215_, new_n216_, new_n217_, new_n219_,
    new_n220_, new_n221_, new_n222_, new_n223_, new_n224_, new_n226_,
    new_n227_, new_n228_;
  INVx1_ASAP7_75t_R   g000(.A(G24), .Y(new_n59_));
  INVx1_ASAP7_75t_R   g001(.A(G33), .Y(new_n60_));
  INVx1_ASAP7_75t_R   g002(.A(G31), .Y(new_n61_));
  INVx1_ASAP7_75t_R   g003(.A(G30), .Y(new_n62_));
  INVx1_ASAP7_75t_R   g004(.A(G32), .Y(new_n63_));
  INVx1_ASAP7_75t_R   g005(.A(G10), .Y(new_n64_));
  INVx1_ASAP7_75t_R   g006(.A(G19), .Y(new_n65_));
  INVx1_ASAP7_75t_R   g007(.A(G28), .Y(new_n66_));
  INVx1_ASAP7_75t_R   g008(.A(G18), .Y(new_n67_));
  INVx1_ASAP7_75t_R   g009(.A(G27), .Y(new_n68_));
  INVx1_ASAP7_75t_R   g010(.A(G4), .Y(new_n69_));
  INVx1_ASAP7_75t_R   g011(.A(G26), .Y(new_n70_));
  INVx1_ASAP7_75t_R   g012(.A(G25), .Y(new_n71_));
  INVx1_ASAP7_75t_R   g013(.A(G29), .Y(new_n72_));
  INVx1_ASAP7_75t_R   g014(.A(G23), .Y(new_n73_));
  AO21x1_ASAP7_75t_R  g015(.A1(new_n61_), .A2(new_n73_), .B(new_n65_), .Y(new_n74_));
  XNOR2x2_ASAP7_75t_R g016(.A(new_n64_), .B(G7), .Y(new_n75_));
  XNOR2x2_ASAP7_75t_R g017(.A(new_n69_), .B(new_n75_), .Y(new_n76_));
  XNOR2x2_ASAP7_75t_R g018(.A(G9), .B(G14), .Y(new_n77_));
  XOR2x2_ASAP7_75t_R  g019(.A(G16), .B(new_n77_), .Y(new_n78_));
  XNOR2x2_ASAP7_75t_R g020(.A(new_n76_), .B(new_n78_), .Y(new_n79_));
  AND3x1_ASAP7_75t_R  g021(.A(G20), .B(new_n73_), .C(new_n60_), .Y(new_n80_));
  XOR2x2_ASAP7_75t_R  g022(.A(G13), .B(new_n80_), .Y(new_n81_));
  XOR2x2_ASAP7_75t_R  g023(.A(new_n79_), .B(new_n81_), .Y(new_n82_));
  NOR2x1_ASAP7_75t_R  g024(.A(G31), .B(new_n82_), .Y(new_n83_));
  XNOR2x2_ASAP7_75t_R g025(.A(new_n74_), .B(new_n83_), .Y(new_n84_));
  XNOR2x2_ASAP7_75t_R g026(.A(G12), .B(G13), .Y(new_n85_));
  XNOR2x2_ASAP7_75t_R g027(.A(G11), .B(new_n85_), .Y(new_n86_));
  XNOR2x2_ASAP7_75t_R g028(.A(G15), .B(G16), .Y(new_n87_));
  XOR2x2_ASAP7_75t_R  g029(.A(G10), .B(new_n87_), .Y(new_n88_));
  XNOR2x2_ASAP7_75t_R g030(.A(new_n86_), .B(new_n88_), .Y(new_n89_));
  XNOR2x2_ASAP7_75t_R g031(.A(G6), .B(G7), .Y(new_n90_));
  XOR2x2_ASAP7_75t_R  g032(.A(G5), .B(new_n90_), .Y(new_n91_));
  XNOR2x2_ASAP7_75t_R g033(.A(new_n89_), .B(new_n91_), .Y(new_n92_));
  AND3x1_ASAP7_75t_R  g034(.A(new_n59_), .B(G17), .C(new_n60_), .Y(new_n93_));
  XOR2x2_ASAP7_75t_R  g035(.A(G1), .B(new_n93_), .Y(new_n94_));
  XOR2x2_ASAP7_75t_R  g036(.A(new_n92_), .B(new_n94_), .Y(new_n95_));
  NOR2x1_ASAP7_75t_R  g037(.A(G31), .B(new_n95_), .Y(new_n96_));
  XNOR2x2_ASAP7_75t_R g038(.A(new_n70_), .B(new_n96_), .Y(new_n97_));
  OR2x4_ASAP7_75t_R   g039(.A(new_n84_), .B(new_n97_), .Y(new_n98_));
  AO21x1_ASAP7_75t_R  g040(.A1(new_n59_), .A2(new_n61_), .B(new_n67_), .Y(new_n99_));
  INVx1_ASAP7_75t_R   g041(.A(new_n99_), .Y(new_n100_));
  OAI21x1_ASAP7_75t_R g042(.A1(G24), .A2(G31), .B(G17), .Y(new_n101_));
  XNOR2x2_ASAP7_75t_R g043(.A(G3), .B(G2), .Y(new_n102_));
  XOR2x2_ASAP7_75t_R  g044(.A(G1), .B(new_n102_), .Y(new_n103_));
  XNOR2x2_ASAP7_75t_R g045(.A(new_n91_), .B(new_n103_), .Y(new_n104_));
  XOR2x2_ASAP7_75t_R  g046(.A(G8), .B(new_n69_), .Y(new_n105_));
  XNOR2x2_ASAP7_75t_R g047(.A(new_n104_), .B(new_n105_), .Y(new_n106_));
  XNOR2x2_ASAP7_75t_R g048(.A(G9), .B(new_n88_), .Y(new_n107_));
  AND2x2_ASAP7_75t_R  g049(.A(new_n60_), .B(G21), .Y(new_n108_));
  XOR2x2_ASAP7_75t_R  g050(.A(new_n107_), .B(new_n108_), .Y(new_n109_));
  XNOR2x2_ASAP7_75t_R g051(.A(new_n106_), .B(new_n109_), .Y(new_n110_));
  NOR2x1_ASAP7_75t_R  g052(.A(G31), .B(new_n110_), .Y(new_n111_));
  XOR2x2_ASAP7_75t_R  g053(.A(new_n101_), .B(new_n111_), .Y(new_n112_));
  NAND2x1_ASAP7_75t_R g054(.A(new_n100_), .B(new_n112_), .Y(new_n113_));
  OA21x2_ASAP7_75t_R  g055(.A1(G31), .A2(G23), .B(G20), .Y(new_n114_));
  INVx1_ASAP7_75t_R   g056(.A(new_n114_), .Y(new_n115_));
  XNOR2x2_ASAP7_75t_R g057(.A(G14), .B(G4), .Y(new_n116_));
  AND2x2_ASAP7_75t_R  g058(.A(new_n60_), .B(G22), .Y(new_n117_));
  XNOR2x2_ASAP7_75t_R g059(.A(new_n116_), .B(new_n117_), .Y(new_n118_));
  XOR2x2_ASAP7_75t_R  g060(.A(new_n88_), .B(new_n103_), .Y(new_n119_));
  XNOR2x2_ASAP7_75t_R g061(.A(new_n86_), .B(new_n119_), .Y(new_n120_));
  XOR2x2_ASAP7_75t_R  g062(.A(new_n118_), .B(new_n120_), .Y(new_n121_));
  NOR2x1_ASAP7_75t_R  g063(.A(G31), .B(new_n121_), .Y(new_n122_));
  XOR2x2_ASAP7_75t_R  g064(.A(new_n71_), .B(new_n122_), .Y(new_n123_));
  NOR2x1_ASAP7_75t_R  g065(.A(new_n115_), .B(new_n123_), .Y(new_n124_));
  OR3x1_ASAP7_75t_R   g066(.A(new_n113_), .B(new_n124_), .C(new_n98_), .Y(new_n125_));
  OR3x1_ASAP7_75t_R   g067(.A(G24), .B(new_n67_), .C(G33), .Y(new_n126_));
  XNOR2x2_ASAP7_75t_R g068(.A(G15), .B(new_n126_), .Y(new_n127_));
  XNOR2x2_ASAP7_75t_R g069(.A(G11), .B(new_n127_), .Y(new_n128_));
  XOR2x2_ASAP7_75t_R  g070(.A(new_n78_), .B(new_n128_), .Y(new_n129_));
  XOR2x2_ASAP7_75t_R  g071(.A(G8), .B(G5), .Y(new_n130_));
  XNOR2x2_ASAP7_75t_R g072(.A(G2), .B(new_n130_), .Y(new_n131_));
  XOR2x2_ASAP7_75t_R  g073(.A(new_n129_), .B(new_n131_), .Y(new_n132_));
  NOR2x1_ASAP7_75t_R  g074(.A(G31), .B(new_n132_), .Y(new_n133_));
  XNOR2x2_ASAP7_75t_R g075(.A(new_n68_), .B(new_n133_), .Y(new_n134_));
  XOR2x2_ASAP7_75t_R  g076(.A(G8), .B(G6), .Y(new_n135_));
  XOR2x2_ASAP7_75t_R  g077(.A(G3), .B(new_n135_), .Y(new_n136_));
  XNOR2x2_ASAP7_75t_R g078(.A(G15), .B(new_n64_), .Y(new_n137_));
  XNOR2x2_ASAP7_75t_R g079(.A(G12), .B(new_n137_), .Y(new_n138_));
  XNOR2x2_ASAP7_75t_R g080(.A(new_n136_), .B(new_n138_), .Y(new_n139_));
  OR3x1_ASAP7_75t_R   g081(.A(new_n65_), .B(G23), .C(G33), .Y(new_n140_));
  XOR2x2_ASAP7_75t_R  g082(.A(new_n139_), .B(new_n140_), .Y(new_n141_));
  NOR2x1_ASAP7_75t_R  g083(.A(G31), .B(new_n141_), .Y(new_n142_));
  XNOR2x2_ASAP7_75t_R g084(.A(new_n66_), .B(new_n142_), .Y(new_n143_));
  OR2x4_ASAP7_75t_R   g085(.A(new_n134_), .B(new_n143_), .Y(new_n144_));
  NOR2x1_ASAP7_75t_R  g086(.A(new_n59_), .B(G23), .Y(new_n145_));
  OR3x1_ASAP7_75t_R   g087(.A(G33), .B(G32), .C(new_n145_), .Y(new_n146_));
  AO21x1_ASAP7_75t_R  g088(.A1(G24), .A2(new_n73_), .B(G33), .Y(new_n147_));
  OR3x1_ASAP7_75t_R   g089(.A(G31), .B(G30), .C(new_n147_), .Y(new_n148_));
  AO21x1_ASAP7_75t_R  g090(.A1(new_n146_), .A2(new_n148_), .B(new_n144_), .Y(new_n149_));
  NOR2x1_ASAP7_75t_R  g091(.A(new_n125_), .B(new_n149_), .Y(new_n150_));
  XNOR2x2_ASAP7_75t_R g092(.A(G14), .B(new_n150_), .Y(G1899));
  OR3x1_ASAP7_75t_R   g093(.A(G31), .B(G29), .C(new_n147_), .Y(new_n152_));
  AO21x1_ASAP7_75t_R  g094(.A1(new_n146_), .A2(new_n152_), .B(new_n144_), .Y(new_n153_));
  NOR2x1_ASAP7_75t_R  g095(.A(new_n99_), .B(new_n112_), .Y(new_n154_));
  OR3x1_ASAP7_75t_R   g096(.A(new_n124_), .B(new_n154_), .C(new_n98_), .Y(new_n155_));
  NOR2x1_ASAP7_75t_R  g097(.A(new_n153_), .B(new_n155_), .Y(new_n156_));
  XNOR2x2_ASAP7_75t_R g098(.A(G1), .B(new_n156_), .Y(G1884));
  XNOR2x2_ASAP7_75t_R g099(.A(G2), .B(new_n156_), .Y(G1885));
  XNOR2x2_ASAP7_75t_R g100(.A(G13), .B(new_n150_), .Y(G1898));
  XNOR2x2_ASAP7_75t_R g101(.A(G3), .B(new_n156_), .Y(G1886));
  XNOR2x2_ASAP7_75t_R g102(.A(G4), .B(new_n156_), .Y(G1887));
  NOR2x1_ASAP7_75t_R  g103(.A(new_n149_), .B(new_n155_), .Y(new_n162_));
  XNOR2x2_ASAP7_75t_R g104(.A(G10), .B(new_n162_), .Y(G1888));
  XNOR2x2_ASAP7_75t_R g105(.A(G15), .B(new_n162_), .Y(G1889));
  XNOR2x2_ASAP7_75t_R g106(.A(G16), .B(new_n162_), .Y(G1890));
  NAND2x1_ASAP7_75t_R g107(.A(new_n114_), .B(new_n123_), .Y(new_n166_));
  OR3x1_ASAP7_75t_R   g108(.A(new_n154_), .B(new_n166_), .C(new_n98_), .Y(new_n167_));
  INVx1_ASAP7_75t_R   g109(.A(new_n167_), .Y(new_n168_));
  NOR2x1_ASAP7_75t_R  g110(.A(new_n153_), .B(new_n167_), .Y(new_n169_));
  XNOR2x2_ASAP7_75t_R g111(.A(G5), .B(new_n169_), .Y(G1891));
  XNOR2x2_ASAP7_75t_R g112(.A(G6), .B(new_n169_), .Y(G1892));
  XNOR2x2_ASAP7_75t_R g113(.A(G7), .B(new_n169_), .Y(G1893));
  XNOR2x2_ASAP7_75t_R g114(.A(G8), .B(new_n169_), .Y(G1894));
  NOR2x1_ASAP7_75t_R  g115(.A(new_n149_), .B(new_n167_), .Y(new_n174_));
  XNOR2x2_ASAP7_75t_R g116(.A(G9), .B(new_n174_), .Y(G1895));
  XNOR2x2_ASAP7_75t_R g117(.A(G11), .B(new_n150_), .Y(G1896));
  XNOR2x2_ASAP7_75t_R g118(.A(G12), .B(new_n150_), .Y(G1897));
  AND2x2_ASAP7_75t_R  g119(.A(new_n99_), .B(new_n123_), .Y(new_n178_));
  AND3x1_ASAP7_75t_R  g120(.A(new_n112_), .B(new_n115_), .C(new_n178_), .Y(new_n179_));
  OR2x4_ASAP7_75t_R   g121(.A(new_n84_), .B(new_n143_), .Y(new_n180_));
  OR3x1_ASAP7_75t_R   g122(.A(new_n97_), .B(new_n134_), .C(new_n180_), .Y(new_n181_));
  INVx1_ASAP7_75t_R   g123(.A(new_n181_), .Y(new_n182_));
  AO21x1_ASAP7_75t_R  g124(.A1(new_n179_), .A2(new_n182_), .B(G33), .Y(new_n183_));
  NOR2x1_ASAP7_75t_R  g125(.A(new_n144_), .B(new_n146_), .Y(new_n184_));
  INVx1_ASAP7_75t_R   g126(.A(new_n184_), .Y(new_n185_));
  OR3x1_ASAP7_75t_R   g127(.A(new_n113_), .B(new_n166_), .C(new_n98_), .Y(new_n186_));
  NOR2x1_ASAP7_75t_R  g128(.A(new_n185_), .B(new_n186_), .Y(new_n187_));
  NOR2x1_ASAP7_75t_R  g129(.A(new_n125_), .B(new_n185_), .Y(new_n188_));
  AO21x1_ASAP7_75t_R  g130(.A1(new_n168_), .A2(new_n184_), .B(new_n188_), .Y(new_n189_));
  OR3x1_ASAP7_75t_R   g131(.A(new_n187_), .B(new_n189_), .C(new_n187_), .Y(new_n190_));
  OR3x1_ASAP7_75t_R   g132(.A(new_n162_), .B(new_n174_), .C(new_n150_), .Y(new_n191_));
  OR3x1_ASAP7_75t_R   g133(.A(new_n150_), .B(new_n162_), .C(new_n191_), .Y(new_n192_));
  OR3x1_ASAP7_75t_R   g134(.A(new_n156_), .B(new_n169_), .C(new_n192_), .Y(new_n193_));
  INVx1_ASAP7_75t_R   g135(.A(new_n193_), .Y(new_n194_));
  OR3x1_ASAP7_75t_R   g136(.A(new_n190_), .B(new_n193_), .C(new_n63_), .Y(new_n195_));
  OR2x4_ASAP7_75t_R   g137(.A(new_n183_), .B(new_n195_), .Y(new_n196_));
  OA21x2_ASAP7_75t_R  g138(.A1(G32), .A2(new_n183_), .B(new_n196_), .Y(G1900));
  XOR2x2_ASAP7_75t_R  g139(.A(new_n106_), .B(new_n109_), .Y(new_n198_));
  OR3x1_ASAP7_75t_R   g140(.A(G31), .B(new_n101_), .C(new_n194_), .Y(new_n199_));
  XOR2x2_ASAP7_75t_R  g141(.A(new_n198_), .B(new_n199_), .Y(new_n200_));
  AOI21x1_ASAP7_75t_R g142(.A1(new_n60_), .A2(new_n63_), .B(new_n200_), .Y(G1901));
  OR3x1_ASAP7_75t_R   g143(.A(G31), .B(new_n71_), .C(new_n194_), .Y(new_n202_));
  XNOR2x2_ASAP7_75t_R g144(.A(new_n121_), .B(new_n202_), .Y(new_n203_));
  AOI21x1_ASAP7_75t_R g145(.A1(new_n60_), .A2(new_n63_), .B(new_n203_), .Y(G1902));
  OR3x1_ASAP7_75t_R   g146(.A(G31), .B(new_n68_), .C(new_n194_), .Y(new_n205_));
  XOR2x2_ASAP7_75t_R  g147(.A(new_n132_), .B(new_n205_), .Y(new_n206_));
  AOI21x1_ASAP7_75t_R g148(.A1(new_n60_), .A2(new_n63_), .B(new_n206_), .Y(G1903));
  OR3x1_ASAP7_75t_R   g149(.A(G31), .B(new_n66_), .C(new_n194_), .Y(new_n208_));
  XOR2x2_ASAP7_75t_R  g150(.A(new_n141_), .B(new_n208_), .Y(new_n209_));
  AOI21x1_ASAP7_75t_R g151(.A1(new_n60_), .A2(new_n63_), .B(new_n209_), .Y(G1904));
  OR3x1_ASAP7_75t_R   g152(.A(G31), .B(new_n74_), .C(new_n194_), .Y(new_n211_));
  XOR2x2_ASAP7_75t_R  g153(.A(new_n82_), .B(new_n211_), .Y(new_n212_));
  AOI21x1_ASAP7_75t_R g154(.A1(new_n60_), .A2(new_n63_), .B(new_n212_), .Y(G1905));
  AO21x1_ASAP7_75t_R  g155(.A1(new_n60_), .A2(new_n72_), .B(new_n106_), .Y(new_n214_));
  OA21x2_ASAP7_75t_R  g156(.A1(new_n156_), .A2(new_n169_), .B(new_n60_), .Y(new_n215_));
  XNOR2x2_ASAP7_75t_R g157(.A(new_n214_), .B(new_n215_), .Y(new_n216_));
  AO21x1_ASAP7_75t_R  g158(.A1(G21), .A2(G29), .B(G33), .Y(new_n217_));
  XNOR2x2_ASAP7_75t_R g159(.A(new_n216_), .B(new_n217_), .Y(G1906));
  XOR2x2_ASAP7_75t_R  g160(.A(G9), .B(G14), .Y(new_n219_));
  XNOR2x2_ASAP7_75t_R g161(.A(new_n89_), .B(new_n219_), .Y(new_n220_));
  AO21x1_ASAP7_75t_R  g162(.A1(new_n60_), .A2(new_n62_), .B(new_n220_), .Y(new_n221_));
  AND2x2_ASAP7_75t_R  g163(.A(new_n60_), .B(new_n192_), .Y(new_n222_));
  XNOR2x2_ASAP7_75t_R g164(.A(new_n221_), .B(new_n222_), .Y(new_n223_));
  AO21x1_ASAP7_75t_R  g165(.A1(G30), .A2(G22), .B(G33), .Y(new_n224_));
  XNOR2x2_ASAP7_75t_R g166(.A(new_n223_), .B(new_n224_), .Y(G1907));
  OR3x1_ASAP7_75t_R   g167(.A(G31), .B(new_n70_), .C(new_n194_), .Y(new_n226_));
  XNOR2x2_ASAP7_75t_R g168(.A(new_n92_), .B(new_n226_), .Y(new_n227_));
  XOR2x2_ASAP7_75t_R  g169(.A(new_n94_), .B(new_n227_), .Y(new_n228_));
  AOI21x1_ASAP7_75t_R g170(.A1(new_n60_), .A2(new_n63_), .B(new_n228_), .Y(G1908));
endmodule


