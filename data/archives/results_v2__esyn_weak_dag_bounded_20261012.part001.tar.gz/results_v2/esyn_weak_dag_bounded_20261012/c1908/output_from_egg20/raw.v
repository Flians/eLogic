// Benchmark "/home/flynn/workplace/MIGBalance/results_v2/esyn_weak_dag_bounded_20261012/c1908/output_from_egg20/logic" written by ABC on Mon Oct 12 13:44:05 2026

module \/home/flynn/workplace/MIGBalance/results_v2/esyn_weak_dag_bounded_20261012/c1908/output_from_egg20/logic  ( 
    G24, G33, G31, G30, G32, G8, G6, G3, G15, G10, G12, G19, G28, G9, G14,
    G16, G18, G11, G5, G2, G27, G7, G4, G20, G13, G1, G17, G26, G22, G25,
    G21, G29, G23,
    G1899, G1884, G1885, G1898, G1886, G1887, G1888, G1889, G1890, G1891,
    G1892, G1893, G1894, G1895, G1896, G1897, G1900, G1901, G1902, G1903,
    G1904, G1905, G1906, G1907, G1908  );
  input  G24, G33, G31, G30, G32, G8, G6, G3, G15, G10, G12, G19, G28,
    G9, G14, G16, G18, G11, G5, G2, G27, G7, G4, G20, G13, G1, G17, G26,
    G22, G25, G21, G29, G23;
  output G1899, G1884, G1885, G1898, G1886, G1887, G1888, G1889, G1890, G1891,
    G1892, G1893, G1894, G1895, G1896, G1897, G1900, G1901, G1902, G1903,
    G1904, G1905, G1906, G1907, G1908;
  wire new_n59_, new_n60_, new_n61_, new_n62_, new_n63_, new_n64_, new_n65_,
    new_n66_, new_n67_, new_n68_, new_n69_, new_n70_, new_n71_, new_n72_,
    new_n73_, new_n74_, new_n75_, new_n76_, new_n77_, new_n78_, new_n79_,
    new_n80_, new_n81_, new_n82_, new_n83_, new_n84_, new_n85_, new_n86_,
    new_n87_, new_n88_, new_n89_, new_n90_, new_n91_, new_n92_, new_n93_,
    new_n94_, new_n95_, new_n96_, new_n97_, new_n98_, new_n99_, new_n100_,
    new_n101_, new_n102_, new_n103_, new_n104_, new_n105_, new_n106_,
    new_n107_, new_n108_, new_n109_, new_n110_, new_n111_, new_n112_,
    new_n113_, new_n114_, new_n115_, new_n116_, new_n117_, new_n118_,
    new_n119_, new_n120_, new_n121_, new_n122_, new_n123_, new_n124_,
    new_n125_, new_n126_, new_n127_, new_n128_, new_n129_, new_n130_,
    new_n131_, new_n132_, new_n133_, new_n134_, new_n135_, new_n136_,
    new_n137_, new_n138_, new_n139_, new_n140_, new_n141_, new_n142_,
    new_n143_, new_n144_, new_n145_, new_n146_, new_n147_, new_n148_,
    new_n149_, new_n150_, new_n151_, new_n152_, new_n153_, new_n154_,
    new_n156_, new_n157_, new_n158_, new_n159_, new_n160_, new_n161_,
    new_n167_, new_n171_, new_n172_, new_n173_, new_n174_, new_n179_,
    new_n183_, new_n184_, new_n185_, new_n186_, new_n187_, new_n188_,
    new_n189_, new_n190_, new_n191_, new_n192_, new_n193_, new_n194_,
    new_n195_, new_n196_, new_n197_, new_n198_, new_n199_, new_n200_,
    new_n202_, new_n203_, new_n204_, new_n206_, new_n207_, new_n209_,
    new_n210_, new_n212_, new_n213_, new_n215_, new_n216_, new_n218_,
    new_n219_, new_n220_, new_n221_, new_n223_, new_n224_, new_n225_,
    new_n226_, new_n227_, new_n228_, new_n230_, new_n231_, new_n232_;
  INVx1_ASAP7_75t_R   g000(.A(G24), .Y(new_n59_));
  INVx1_ASAP7_75t_R   g001(.A(G33), .Y(new_n60_));
  INVx1_ASAP7_75t_R   g002(.A(G31), .Y(new_n61_));
  INVx1_ASAP7_75t_R   g003(.A(G32), .Y(new_n62_));
  INVx1_ASAP7_75t_R   g004(.A(G8), .Y(new_n63_));
  INVx1_ASAP7_75t_R   g005(.A(G3), .Y(new_n64_));
  INVx1_ASAP7_75t_R   g006(.A(G12), .Y(new_n65_));
  INVx1_ASAP7_75t_R   g007(.A(G19), .Y(new_n66_));
  INVx1_ASAP7_75t_R   g008(.A(G9), .Y(new_n67_));
  INVx1_ASAP7_75t_R   g009(.A(G18), .Y(new_n68_));
  INVx1_ASAP7_75t_R   g010(.A(G11), .Y(new_n69_));
  INVx1_ASAP7_75t_R   g011(.A(G5), .Y(new_n70_));
  INVx1_ASAP7_75t_R   g012(.A(G2), .Y(new_n71_));
  INVx1_ASAP7_75t_R   g013(.A(G7), .Y(new_n72_));
  INVx1_ASAP7_75t_R   g014(.A(G17), .Y(new_n73_));
  INVx1_ASAP7_75t_R   g015(.A(G26), .Y(new_n74_));
  INVx1_ASAP7_75t_R   g016(.A(G23), .Y(new_n75_));
  XNOR2x2_ASAP7_75t_R g017(.A(new_n63_), .B(G5), .Y(new_n76_));
  XOR2x2_ASAP7_75t_R  g018(.A(new_n71_), .B(new_n76_), .Y(new_n77_));
  OR3x1_ASAP7_75t_R   g019(.A(G24), .B(new_n68_), .C(G33), .Y(new_n78_));
  XNOR2x2_ASAP7_75t_R g020(.A(G15), .B(new_n78_), .Y(new_n79_));
  XOR2x2_ASAP7_75t_R  g021(.A(new_n69_), .B(new_n79_), .Y(new_n80_));
  XNOR2x2_ASAP7_75t_R g022(.A(G9), .B(G14), .Y(new_n81_));
  XNOR2x2_ASAP7_75t_R g023(.A(G16), .B(new_n81_), .Y(new_n82_));
  XNOR2x2_ASAP7_75t_R g024(.A(new_n80_), .B(new_n82_), .Y(new_n83_));
  XNOR2x2_ASAP7_75t_R g025(.A(new_n77_), .B(new_n83_), .Y(new_n84_));
  NAND2x1_ASAP7_75t_R g026(.A(new_n61_), .B(new_n84_), .Y(new_n85_));
  XNOR2x2_ASAP7_75t_R g027(.A(G27), .B(new_n85_), .Y(new_n86_));
  OR3x1_ASAP7_75t_R   g028(.A(new_n66_), .B(G23), .C(G33), .Y(new_n87_));
  XNOR2x2_ASAP7_75t_R g029(.A(new_n63_), .B(G6), .Y(new_n88_));
  XNOR2x2_ASAP7_75t_R g030(.A(new_n64_), .B(new_n88_), .Y(new_n89_));
  XOR2x2_ASAP7_75t_R  g031(.A(G15), .B(G10), .Y(new_n90_));
  XOR2x2_ASAP7_75t_R  g032(.A(new_n65_), .B(new_n90_), .Y(new_n91_));
  XNOR2x2_ASAP7_75t_R g033(.A(new_n89_), .B(new_n91_), .Y(new_n92_));
  XOR2x2_ASAP7_75t_R  g034(.A(new_n87_), .B(new_n92_), .Y(new_n93_));
  NOR2x1_ASAP7_75t_R  g035(.A(G31), .B(new_n93_), .Y(new_n94_));
  XOR2x2_ASAP7_75t_R  g036(.A(G28), .B(new_n94_), .Y(new_n95_));
  OR2x4_ASAP7_75t_R   g037(.A(new_n86_), .B(new_n95_), .Y(new_n96_));
  NOR2x1_ASAP7_75t_R  g038(.A(new_n59_), .B(G23), .Y(new_n97_));
  OR3x1_ASAP7_75t_R   g039(.A(G33), .B(G32), .C(new_n97_), .Y(new_n98_));
  AO21x1_ASAP7_75t_R  g040(.A1(G24), .A2(new_n75_), .B(G33), .Y(new_n99_));
  OR3x1_ASAP7_75t_R   g041(.A(G31), .B(G30), .C(new_n99_), .Y(new_n100_));
  AO21x1_ASAP7_75t_R  g042(.A1(new_n98_), .A2(new_n100_), .B(new_n96_), .Y(new_n101_));
  AO21x1_ASAP7_75t_R  g043(.A1(new_n61_), .A2(new_n75_), .B(new_n66_), .Y(new_n102_));
  XOR2x2_ASAP7_75t_R  g044(.A(G10), .B(new_n72_), .Y(new_n103_));
  XOR2x2_ASAP7_75t_R  g045(.A(G4), .B(new_n103_), .Y(new_n104_));
  XNOR2x2_ASAP7_75t_R g046(.A(new_n82_), .B(new_n104_), .Y(new_n105_));
  AND3x1_ASAP7_75t_R  g047(.A(G20), .B(new_n75_), .C(new_n60_), .Y(new_n106_));
  XOR2x2_ASAP7_75t_R  g048(.A(G13), .B(new_n106_), .Y(new_n107_));
  XOR2x2_ASAP7_75t_R  g049(.A(new_n105_), .B(new_n107_), .Y(new_n108_));
  NOR2x1_ASAP7_75t_R  g050(.A(G31), .B(new_n108_), .Y(new_n109_));
  XNOR2x2_ASAP7_75t_R g051(.A(new_n102_), .B(new_n109_), .Y(new_n110_));
  XNOR2x2_ASAP7_75t_R g052(.A(G15), .B(G16), .Y(new_n111_));
  XOR2x2_ASAP7_75t_R  g053(.A(G10), .B(new_n111_), .Y(new_n112_));
  INVx1_ASAP7_75t_R   g054(.A(new_n112_), .Y(new_n113_));
  XOR2x2_ASAP7_75t_R  g055(.A(G12), .B(G13), .Y(new_n114_));
  XNOR2x2_ASAP7_75t_R g056(.A(new_n69_), .B(new_n114_), .Y(new_n115_));
  XOR2x2_ASAP7_75t_R  g057(.A(new_n112_), .B(new_n115_), .Y(new_n116_));
  XOR2x2_ASAP7_75t_R  g058(.A(G6), .B(G7), .Y(new_n117_));
  XNOR2x2_ASAP7_75t_R g059(.A(new_n70_), .B(new_n117_), .Y(new_n118_));
  XNOR2x2_ASAP7_75t_R g060(.A(new_n116_), .B(new_n118_), .Y(new_n119_));
  OR3x1_ASAP7_75t_R   g061(.A(G24), .B(new_n73_), .C(G33), .Y(new_n120_));
  XOR2x2_ASAP7_75t_R  g062(.A(G1), .B(new_n120_), .Y(new_n121_));
  XNOR2x2_ASAP7_75t_R g063(.A(new_n119_), .B(new_n121_), .Y(new_n122_));
  NOR2x1_ASAP7_75t_R  g064(.A(G31), .B(new_n122_), .Y(new_n123_));
  XNOR2x2_ASAP7_75t_R g065(.A(new_n74_), .B(new_n123_), .Y(new_n124_));
  OR2x4_ASAP7_75t_R   g066(.A(new_n110_), .B(new_n124_), .Y(new_n125_));
  AO21x1_ASAP7_75t_R  g067(.A1(new_n59_), .A2(new_n61_), .B(new_n68_), .Y(new_n126_));
  INVx1_ASAP7_75t_R   g068(.A(new_n126_), .Y(new_n127_));
  AO21x1_ASAP7_75t_R  g069(.A1(new_n59_), .A2(new_n61_), .B(new_n73_), .Y(new_n128_));
  XOR2x2_ASAP7_75t_R  g070(.A(new_n63_), .B(G4), .Y(new_n129_));
  XNOR2x2_ASAP7_75t_R g071(.A(new_n64_), .B(new_n71_), .Y(new_n130_));
  XOR2x2_ASAP7_75t_R  g072(.A(G1), .B(new_n130_), .Y(new_n131_));
  XOR2x2_ASAP7_75t_R  g073(.A(new_n118_), .B(new_n131_), .Y(new_n132_));
  XOR2x2_ASAP7_75t_R  g074(.A(new_n129_), .B(new_n132_), .Y(new_n133_));
  XNOR2x2_ASAP7_75t_R g075(.A(new_n67_), .B(new_n113_), .Y(new_n134_));
  AND2x2_ASAP7_75t_R  g076(.A(new_n60_), .B(G21), .Y(new_n135_));
  XOR2x2_ASAP7_75t_R  g077(.A(new_n134_), .B(new_n135_), .Y(new_n136_));
  XOR2x2_ASAP7_75t_R  g078(.A(new_n133_), .B(new_n136_), .Y(new_n137_));
  OR2x4_ASAP7_75t_R   g079(.A(G31), .B(new_n137_), .Y(new_n138_));
  XNOR2x2_ASAP7_75t_R g080(.A(new_n128_), .B(new_n138_), .Y(new_n139_));
  NAND2x1_ASAP7_75t_R g081(.A(new_n127_), .B(new_n139_), .Y(new_n140_));
  XOR2x2_ASAP7_75t_R  g082(.A(G14), .B(G4), .Y(new_n141_));
  NAND2x1_ASAP7_75t_R g083(.A(new_n60_), .B(G22), .Y(new_n142_));
  XOR2x2_ASAP7_75t_R  g084(.A(new_n141_), .B(new_n142_), .Y(new_n143_));
  XNOR2x2_ASAP7_75t_R g085(.A(new_n113_), .B(new_n131_), .Y(new_n144_));
  XOR2x2_ASAP7_75t_R  g086(.A(new_n115_), .B(new_n144_), .Y(new_n145_));
  XOR2x2_ASAP7_75t_R  g087(.A(new_n143_), .B(new_n145_), .Y(new_n146_));
  NOR2x1_ASAP7_75t_R  g088(.A(G31), .B(new_n146_), .Y(new_n147_));
  XNOR2x2_ASAP7_75t_R g089(.A(G25), .B(new_n147_), .Y(new_n148_));
  OA21x2_ASAP7_75t_R  g090(.A1(G31), .A2(G23), .B(G20), .Y(new_n149_));
  INVx1_ASAP7_75t_R   g091(.A(new_n149_), .Y(new_n150_));
  NOR2x1_ASAP7_75t_R  g092(.A(new_n148_), .B(new_n150_), .Y(new_n151_));
  OR3x1_ASAP7_75t_R   g093(.A(new_n140_), .B(new_n151_), .C(new_n125_), .Y(new_n152_));
  NOR2x1_ASAP7_75t_R  g094(.A(new_n101_), .B(new_n152_), .Y(new_n153_));
  INVx1_ASAP7_75t_R   g095(.A(new_n153_), .Y(new_n154_));
  XNOR2x2_ASAP7_75t_R g096(.A(G14), .B(new_n153_), .Y(G1899));
  OR3x1_ASAP7_75t_R   g097(.A(G31), .B(G29), .C(new_n99_), .Y(new_n156_));
  AO21x1_ASAP7_75t_R  g098(.A1(new_n98_), .A2(new_n156_), .B(new_n96_), .Y(new_n157_));
  NOR2x1_ASAP7_75t_R  g099(.A(new_n126_), .B(new_n139_), .Y(new_n158_));
  OR3x1_ASAP7_75t_R   g100(.A(new_n151_), .B(new_n158_), .C(new_n125_), .Y(new_n159_));
  NOR2x1_ASAP7_75t_R  g101(.A(new_n157_), .B(new_n159_), .Y(new_n160_));
  INVx1_ASAP7_75t_R   g102(.A(new_n160_), .Y(new_n161_));
  XNOR2x2_ASAP7_75t_R g103(.A(G1), .B(new_n160_), .Y(G1884));
  XNOR2x2_ASAP7_75t_R g104(.A(new_n71_), .B(new_n161_), .Y(G1885));
  XNOR2x2_ASAP7_75t_R g105(.A(G13), .B(new_n153_), .Y(G1898));
  XNOR2x2_ASAP7_75t_R g106(.A(G3), .B(new_n160_), .Y(G1886));
  XNOR2x2_ASAP7_75t_R g107(.A(G4), .B(new_n160_), .Y(G1887));
  NOR2x1_ASAP7_75t_R  g108(.A(new_n101_), .B(new_n159_), .Y(new_n167_));
  XNOR2x2_ASAP7_75t_R g109(.A(G10), .B(new_n167_), .Y(G1888));
  XNOR2x2_ASAP7_75t_R g110(.A(G15), .B(new_n167_), .Y(G1889));
  XNOR2x2_ASAP7_75t_R g111(.A(G16), .B(new_n167_), .Y(G1890));
  NAND2x1_ASAP7_75t_R g112(.A(new_n148_), .B(new_n149_), .Y(new_n171_));
  OR3x1_ASAP7_75t_R   g113(.A(new_n158_), .B(new_n171_), .C(new_n125_), .Y(new_n172_));
  NOR2x1_ASAP7_75t_R  g114(.A(new_n157_), .B(new_n172_), .Y(new_n173_));
  INVx1_ASAP7_75t_R   g115(.A(new_n173_), .Y(new_n174_));
  XNOR2x2_ASAP7_75t_R g116(.A(new_n70_), .B(new_n174_), .Y(G1891));
  XNOR2x2_ASAP7_75t_R g117(.A(G6), .B(new_n173_), .Y(G1892));
  XNOR2x2_ASAP7_75t_R g118(.A(new_n72_), .B(new_n174_), .Y(G1893));
  XNOR2x2_ASAP7_75t_R g119(.A(new_n63_), .B(new_n174_), .Y(G1894));
  NOR2x1_ASAP7_75t_R  g120(.A(new_n101_), .B(new_n172_), .Y(new_n179_));
  XNOR2x2_ASAP7_75t_R g121(.A(G9), .B(new_n179_), .Y(G1895));
  XNOR2x2_ASAP7_75t_R g122(.A(new_n69_), .B(new_n154_), .Y(G1896));
  XNOR2x2_ASAP7_75t_R g123(.A(new_n65_), .B(new_n154_), .Y(G1897));
  OR3x1_ASAP7_75t_R   g124(.A(new_n140_), .B(new_n171_), .C(new_n125_), .Y(new_n183_));
  OR3x1_ASAP7_75t_R   g125(.A(new_n86_), .B(new_n95_), .C(new_n98_), .Y(new_n184_));
  NOR2x1_ASAP7_75t_R  g126(.A(new_n183_), .B(new_n184_), .Y(new_n185_));
  OR3x1_ASAP7_75t_R   g127(.A(new_n96_), .B(new_n98_), .C(new_n152_), .Y(new_n186_));
  OAI21x1_ASAP7_75t_R g128(.A1(new_n172_), .A2(new_n184_), .B(new_n186_), .Y(new_n187_));
  OR3x1_ASAP7_75t_R   g129(.A(new_n185_), .B(new_n187_), .C(new_n185_), .Y(new_n188_));
  OR3x1_ASAP7_75t_R   g130(.A(new_n167_), .B(new_n179_), .C(new_n153_), .Y(new_n189_));
  OR3x1_ASAP7_75t_R   g131(.A(new_n153_), .B(new_n167_), .C(new_n189_), .Y(new_n190_));
  OR3x1_ASAP7_75t_R   g132(.A(new_n160_), .B(new_n173_), .C(new_n190_), .Y(new_n191_));
  INVx1_ASAP7_75t_R   g133(.A(new_n191_), .Y(new_n192_));
  OR3x1_ASAP7_75t_R   g134(.A(new_n188_), .B(new_n191_), .C(new_n62_), .Y(new_n193_));
  AND2x2_ASAP7_75t_R  g135(.A(new_n139_), .B(new_n150_), .Y(new_n194_));
  AND3x1_ASAP7_75t_R  g136(.A(new_n126_), .B(new_n148_), .C(new_n194_), .Y(new_n195_));
  OR2x4_ASAP7_75t_R   g137(.A(new_n86_), .B(new_n124_), .Y(new_n196_));
  OR3x1_ASAP7_75t_R   g138(.A(new_n95_), .B(new_n110_), .C(new_n196_), .Y(new_n197_));
  INVx1_ASAP7_75t_R   g139(.A(new_n197_), .Y(new_n198_));
  AO21x1_ASAP7_75t_R  g140(.A1(new_n195_), .A2(new_n198_), .B(G33), .Y(new_n199_));
  OR2x4_ASAP7_75t_R   g141(.A(new_n193_), .B(new_n199_), .Y(new_n200_));
  OA21x2_ASAP7_75t_R  g142(.A1(G32), .A2(new_n199_), .B(new_n200_), .Y(G1900));
  OR3x1_ASAP7_75t_R   g143(.A(G31), .B(new_n128_), .C(new_n192_), .Y(new_n202_));
  XNOR2x2_ASAP7_75t_R g144(.A(new_n133_), .B(new_n136_), .Y(new_n203_));
  XOR2x2_ASAP7_75t_R  g145(.A(new_n202_), .B(new_n203_), .Y(new_n204_));
  AOI21x1_ASAP7_75t_R g146(.A1(new_n60_), .A2(new_n62_), .B(new_n204_), .Y(G1901));
  AND3x1_ASAP7_75t_R  g147(.A(new_n61_), .B(G25), .C(new_n191_), .Y(new_n206_));
  XOR2x2_ASAP7_75t_R  g148(.A(new_n146_), .B(new_n206_), .Y(new_n207_));
  AOI21x1_ASAP7_75t_R g149(.A1(new_n60_), .A2(new_n62_), .B(new_n207_), .Y(G1902));
  AND3x1_ASAP7_75t_R  g150(.A(new_n61_), .B(G27), .C(new_n191_), .Y(new_n209_));
  XOR2x2_ASAP7_75t_R  g151(.A(new_n84_), .B(new_n209_), .Y(new_n210_));
  AOI21x1_ASAP7_75t_R g152(.A1(new_n60_), .A2(new_n62_), .B(new_n210_), .Y(G1903));
  AND3x1_ASAP7_75t_R  g153(.A(new_n61_), .B(G28), .C(new_n191_), .Y(new_n212_));
  XNOR2x2_ASAP7_75t_R g154(.A(new_n93_), .B(new_n212_), .Y(new_n213_));
  AOI21x1_ASAP7_75t_R g155(.A1(new_n60_), .A2(new_n62_), .B(new_n213_), .Y(G1904));
  OR3x1_ASAP7_75t_R   g156(.A(G31), .B(new_n102_), .C(new_n192_), .Y(new_n215_));
  XOR2x2_ASAP7_75t_R  g157(.A(new_n108_), .B(new_n215_), .Y(new_n216_));
  AOI21x1_ASAP7_75t_R g158(.A1(new_n60_), .A2(new_n62_), .B(new_n216_), .Y(G1905));
  AOI21x1_ASAP7_75t_R g159(.A1(G21), .A2(G29), .B(G33), .Y(new_n218_));
  AO21x1_ASAP7_75t_R  g160(.A1(new_n161_), .A2(new_n174_), .B(G33), .Y(new_n219_));
  OA21x2_ASAP7_75t_R  g161(.A1(G33), .A2(G29), .B(new_n133_), .Y(new_n220_));
  XOR2x2_ASAP7_75t_R  g162(.A(new_n219_), .B(new_n220_), .Y(new_n221_));
  XNOR2x2_ASAP7_75t_R g163(.A(new_n218_), .B(new_n221_), .Y(G1906));
  AO21x1_ASAP7_75t_R  g164(.A1(G30), .A2(G22), .B(G33), .Y(new_n223_));
  XNOR2x2_ASAP7_75t_R g165(.A(new_n67_), .B(G14), .Y(new_n224_));
  XNOR2x2_ASAP7_75t_R g166(.A(new_n116_), .B(new_n224_), .Y(new_n225_));
  OA21x2_ASAP7_75t_R  g167(.A1(G33), .A2(G30), .B(new_n225_), .Y(new_n226_));
  NAND2x1_ASAP7_75t_R g168(.A(new_n60_), .B(new_n190_), .Y(new_n227_));
  XNOR2x2_ASAP7_75t_R g169(.A(new_n226_), .B(new_n227_), .Y(new_n228_));
  XNOR2x2_ASAP7_75t_R g170(.A(new_n223_), .B(new_n228_), .Y(G1907));
  OR3x1_ASAP7_75t_R   g171(.A(G31), .B(new_n74_), .C(new_n192_), .Y(new_n230_));
  XOR2x2_ASAP7_75t_R  g172(.A(new_n119_), .B(new_n230_), .Y(new_n231_));
  XOR2x2_ASAP7_75t_R  g173(.A(new_n121_), .B(new_n231_), .Y(new_n232_));
  AOI21x1_ASAP7_75t_R g174(.A1(new_n60_), .A2(new_n62_), .B(new_n232_), .Y(G1908));
endmodule


