// Benchmark "/home/flynn/workplace/MIGBalance/results_v2/esyn_weak_dag_bounded_20261012/c1908/output_from_egg11/logic" written by ABC on Mon Oct 12 13:44:01 2026

module \/home/flynn/workplace/MIGBalance/results_v2/esyn_weak_dag_bounded_20261012/c1908/output_from_egg11/logic  ( 
    G24, G33, G31, G30, G32, G8, G6, G3, G15, G10, G12, G19, G28, G9, G14,
    G16, G18, G11, G5, G2, G27, G7, G4, G20, G13, G1, G17, G26, G22, G25,
    G21, G29, G23,
    G1899, G1884, G1885, G1898, G1886, G1887, G1888, G1889, G1890, G1891,
    G1892, G1893, G1894, G1895, G1896, G1897, G1900, G1901, G1902, G1903,
    G1904, G1905, G1906, G1907, G1908  );
  input  G24, G33, G31, G30, G32, G8, G6, G3, G15, G10, G12, G19, G28,
    G9, G14, G16, G18, G11, G5, G2, G27, G7, G4, G20, G13, G1, G17, G26,
    G22, G25, G21, G29, G23;
  output G1899, G1884, G1885, G1898, G1886, G1887, G1888, G1889, G1890, G1891,
    G1892, G1893, G1894, G1895, G1896, G1897, G1900, G1901, G1902, G1903,
    G1904, G1905, G1906, G1907, G1908;
  wire new_n59_, new_n60_, new_n61_, new_n62_, new_n63_, new_n64_, new_n65_,
    new_n66_, new_n67_, new_n68_, new_n69_, new_n70_, new_n71_, new_n72_,
    new_n73_, new_n74_, new_n75_, new_n76_, new_n77_, new_n78_, new_n79_,
    new_n80_, new_n81_, new_n82_, new_n83_, new_n84_, new_n85_, new_n86_,
    new_n87_, new_n88_, new_n89_, new_n90_, new_n91_, new_n92_, new_n93_,
    new_n94_, new_n95_, new_n96_, new_n97_, new_n98_, new_n99_, new_n100_,
    new_n101_, new_n102_, new_n103_, new_n104_, new_n105_, new_n106_,
    new_n107_, new_n108_, new_n109_, new_n110_, new_n111_, new_n112_,
    new_n113_, new_n114_, new_n115_, new_n116_, new_n117_, new_n118_,
    new_n119_, new_n120_, new_n121_, new_n122_, new_n123_, new_n124_,
    new_n125_, new_n126_, new_n127_, new_n128_, new_n129_, new_n130_,
    new_n131_, new_n132_, new_n133_, new_n134_, new_n135_, new_n136_,
    new_n137_, new_n138_, new_n139_, new_n140_, new_n141_, new_n142_,
    new_n143_, new_n144_, new_n145_, new_n146_, new_n147_, new_n148_,
    new_n149_, new_n150_, new_n151_, new_n152_, new_n153_, new_n155_,
    new_n156_, new_n157_, new_n158_, new_n159_, new_n160_, new_n166_,
    new_n170_, new_n171_, new_n172_, new_n173_, new_n178_, new_n182_,
    new_n183_, new_n184_, new_n185_, new_n186_, new_n187_, new_n188_,
    new_n189_, new_n190_, new_n191_, new_n192_, new_n193_, new_n194_,
    new_n195_, new_n196_, new_n197_, new_n198_, new_n199_, new_n201_,
    new_n202_, new_n203_, new_n205_, new_n206_, new_n208_, new_n209_,
    new_n211_, new_n212_, new_n214_, new_n215_, new_n217_, new_n218_,
    new_n219_, new_n220_, new_n222_, new_n223_, new_n224_, new_n225_,
    new_n226_, new_n227_, new_n229_, new_n230_, new_n231_;
  INVx1_ASAP7_75t_R   g000(.A(G24), .Y(new_n59_));
  INVx1_ASAP7_75t_R   g001(.A(G33), .Y(new_n60_));
  INVx1_ASAP7_75t_R   g002(.A(G31), .Y(new_n61_));
  INVx1_ASAP7_75t_R   g003(.A(G32), .Y(new_n62_));
  INVx1_ASAP7_75t_R   g004(.A(G8), .Y(new_n63_));
  INVx1_ASAP7_75t_R   g005(.A(G12), .Y(new_n64_));
  INVx1_ASAP7_75t_R   g006(.A(G9), .Y(new_n65_));
  INVx1_ASAP7_75t_R   g007(.A(G18), .Y(new_n66_));
  INVx1_ASAP7_75t_R   g008(.A(G11), .Y(new_n67_));
  INVx1_ASAP7_75t_R   g009(.A(G5), .Y(new_n68_));
  INVx1_ASAP7_75t_R   g010(.A(G2), .Y(new_n69_));
  INVx1_ASAP7_75t_R   g011(.A(G7), .Y(new_n70_));
  INVx1_ASAP7_75t_R   g012(.A(G1), .Y(new_n71_));
  INVx1_ASAP7_75t_R   g013(.A(G17), .Y(new_n72_));
  INVx1_ASAP7_75t_R   g014(.A(G26), .Y(new_n73_));
  INVx1_ASAP7_75t_R   g015(.A(G23), .Y(new_n74_));
  XNOR2x2_ASAP7_75t_R g016(.A(new_n63_), .B(G5), .Y(new_n75_));
  XOR2x2_ASAP7_75t_R  g017(.A(new_n69_), .B(new_n75_), .Y(new_n76_));
  OR3x1_ASAP7_75t_R   g018(.A(G24), .B(new_n66_), .C(G33), .Y(new_n77_));
  XNOR2x2_ASAP7_75t_R g019(.A(G15), .B(new_n77_), .Y(new_n78_));
  XOR2x2_ASAP7_75t_R  g020(.A(new_n67_), .B(new_n78_), .Y(new_n79_));
  XNOR2x2_ASAP7_75t_R g021(.A(G9), .B(G14), .Y(new_n80_));
  XNOR2x2_ASAP7_75t_R g022(.A(G16), .B(new_n80_), .Y(new_n81_));
  XNOR2x2_ASAP7_75t_R g023(.A(new_n79_), .B(new_n81_), .Y(new_n82_));
  XNOR2x2_ASAP7_75t_R g024(.A(new_n76_), .B(new_n82_), .Y(new_n83_));
  NAND2x1_ASAP7_75t_R g025(.A(new_n61_), .B(new_n83_), .Y(new_n84_));
  XNOR2x2_ASAP7_75t_R g026(.A(G27), .B(new_n84_), .Y(new_n85_));
  AND3x1_ASAP7_75t_R  g027(.A(G19), .B(new_n74_), .C(new_n60_), .Y(new_n86_));
  XOR2x2_ASAP7_75t_R  g028(.A(G15), .B(G10), .Y(new_n87_));
  XOR2x2_ASAP7_75t_R  g029(.A(new_n64_), .B(new_n87_), .Y(new_n88_));
  XOR2x2_ASAP7_75t_R  g030(.A(new_n63_), .B(G6), .Y(new_n89_));
  XNOR2x2_ASAP7_75t_R g031(.A(G3), .B(new_n89_), .Y(new_n90_));
  XOR2x2_ASAP7_75t_R  g032(.A(new_n88_), .B(new_n90_), .Y(new_n91_));
  XOR2x2_ASAP7_75t_R  g033(.A(new_n86_), .B(new_n91_), .Y(new_n92_));
  NOR2x1_ASAP7_75t_R  g034(.A(G31), .B(new_n92_), .Y(new_n93_));
  XOR2x2_ASAP7_75t_R  g035(.A(G28), .B(new_n93_), .Y(new_n94_));
  OR2x4_ASAP7_75t_R   g036(.A(new_n85_), .B(new_n94_), .Y(new_n95_));
  NOR2x1_ASAP7_75t_R  g037(.A(new_n59_), .B(G23), .Y(new_n96_));
  OR3x1_ASAP7_75t_R   g038(.A(G33), .B(G32), .C(new_n96_), .Y(new_n97_));
  AO21x1_ASAP7_75t_R  g039(.A1(G24), .A2(new_n74_), .B(G33), .Y(new_n98_));
  OR3x1_ASAP7_75t_R   g040(.A(G31), .B(G30), .C(new_n98_), .Y(new_n99_));
  AO21x1_ASAP7_75t_R  g041(.A1(new_n97_), .A2(new_n99_), .B(new_n95_), .Y(new_n100_));
  OA21x2_ASAP7_75t_R  g042(.A1(G31), .A2(G23), .B(G19), .Y(new_n101_));
  XOR2x2_ASAP7_75t_R  g043(.A(G10), .B(new_n70_), .Y(new_n102_));
  XOR2x2_ASAP7_75t_R  g044(.A(G4), .B(new_n102_), .Y(new_n103_));
  XNOR2x2_ASAP7_75t_R g045(.A(new_n81_), .B(new_n103_), .Y(new_n104_));
  AND3x1_ASAP7_75t_R  g046(.A(G20), .B(new_n74_), .C(new_n60_), .Y(new_n105_));
  XOR2x2_ASAP7_75t_R  g047(.A(G13), .B(new_n105_), .Y(new_n106_));
  XNOR2x2_ASAP7_75t_R g048(.A(new_n104_), .B(new_n106_), .Y(new_n107_));
  NAND2x1_ASAP7_75t_R g049(.A(new_n61_), .B(new_n107_), .Y(new_n108_));
  XNOR2x2_ASAP7_75t_R g050(.A(new_n101_), .B(new_n108_), .Y(new_n109_));
  XNOR2x2_ASAP7_75t_R g051(.A(G15), .B(G16), .Y(new_n110_));
  XOR2x2_ASAP7_75t_R  g052(.A(G10), .B(new_n110_), .Y(new_n111_));
  INVx1_ASAP7_75t_R   g053(.A(new_n111_), .Y(new_n112_));
  XOR2x2_ASAP7_75t_R  g054(.A(G12), .B(G13), .Y(new_n113_));
  XNOR2x2_ASAP7_75t_R g055(.A(new_n67_), .B(new_n113_), .Y(new_n114_));
  XNOR2x2_ASAP7_75t_R g056(.A(new_n111_), .B(new_n114_), .Y(new_n115_));
  XOR2x2_ASAP7_75t_R  g057(.A(G6), .B(G7), .Y(new_n116_));
  XOR2x2_ASAP7_75t_R  g058(.A(new_n68_), .B(new_n116_), .Y(new_n117_));
  XNOR2x2_ASAP7_75t_R g059(.A(new_n115_), .B(new_n117_), .Y(new_n118_));
  OR3x1_ASAP7_75t_R   g060(.A(G24), .B(new_n72_), .C(G33), .Y(new_n119_));
  XOR2x2_ASAP7_75t_R  g061(.A(new_n71_), .B(new_n119_), .Y(new_n120_));
  XOR2x2_ASAP7_75t_R  g062(.A(new_n118_), .B(new_n120_), .Y(new_n121_));
  NOR2x1_ASAP7_75t_R  g063(.A(G31), .B(new_n121_), .Y(new_n122_));
  XNOR2x2_ASAP7_75t_R g064(.A(new_n73_), .B(new_n122_), .Y(new_n123_));
  OR2x4_ASAP7_75t_R   g065(.A(new_n109_), .B(new_n123_), .Y(new_n124_));
  AO21x1_ASAP7_75t_R  g066(.A1(new_n59_), .A2(new_n61_), .B(new_n66_), .Y(new_n125_));
  INVx1_ASAP7_75t_R   g067(.A(new_n125_), .Y(new_n126_));
  AO21x1_ASAP7_75t_R  g068(.A1(new_n59_), .A2(new_n61_), .B(new_n72_), .Y(new_n127_));
  XOR2x2_ASAP7_75t_R  g069(.A(new_n63_), .B(G4), .Y(new_n128_));
  XNOR2x2_ASAP7_75t_R g070(.A(G3), .B(G2), .Y(new_n129_));
  XOR2x2_ASAP7_75t_R  g071(.A(G1), .B(new_n129_), .Y(new_n130_));
  XNOR2x2_ASAP7_75t_R g072(.A(new_n117_), .B(new_n130_), .Y(new_n131_));
  XOR2x2_ASAP7_75t_R  g073(.A(new_n128_), .B(new_n131_), .Y(new_n132_));
  NAND2x1_ASAP7_75t_R g074(.A(new_n60_), .B(G21), .Y(new_n133_));
  XOR2x2_ASAP7_75t_R  g075(.A(new_n65_), .B(new_n112_), .Y(new_n134_));
  XOR2x2_ASAP7_75t_R  g076(.A(new_n133_), .B(new_n134_), .Y(new_n135_));
  XOR2x2_ASAP7_75t_R  g077(.A(new_n132_), .B(new_n135_), .Y(new_n136_));
  OR2x4_ASAP7_75t_R   g078(.A(G31), .B(new_n136_), .Y(new_n137_));
  XNOR2x2_ASAP7_75t_R g079(.A(new_n127_), .B(new_n137_), .Y(new_n138_));
  NAND2x1_ASAP7_75t_R g080(.A(new_n126_), .B(new_n138_), .Y(new_n139_));
  XOR2x2_ASAP7_75t_R  g081(.A(G14), .B(G4), .Y(new_n140_));
  NAND2x1_ASAP7_75t_R g082(.A(new_n60_), .B(G22), .Y(new_n141_));
  XOR2x2_ASAP7_75t_R  g083(.A(new_n140_), .B(new_n141_), .Y(new_n142_));
  XNOR2x2_ASAP7_75t_R g084(.A(new_n112_), .B(new_n130_), .Y(new_n143_));
  XOR2x2_ASAP7_75t_R  g085(.A(new_n114_), .B(new_n143_), .Y(new_n144_));
  XOR2x2_ASAP7_75t_R  g086(.A(new_n142_), .B(new_n144_), .Y(new_n145_));
  OR2x4_ASAP7_75t_R   g087(.A(G31), .B(new_n145_), .Y(new_n146_));
  XOR2x2_ASAP7_75t_R  g088(.A(G25), .B(new_n146_), .Y(new_n147_));
  OA21x2_ASAP7_75t_R  g089(.A1(G31), .A2(G23), .B(G20), .Y(new_n148_));
  INVx1_ASAP7_75t_R   g090(.A(new_n148_), .Y(new_n149_));
  NOR2x1_ASAP7_75t_R  g091(.A(new_n147_), .B(new_n149_), .Y(new_n150_));
  OR3x1_ASAP7_75t_R   g092(.A(new_n139_), .B(new_n150_), .C(new_n124_), .Y(new_n151_));
  NOR2x1_ASAP7_75t_R  g093(.A(new_n100_), .B(new_n151_), .Y(new_n152_));
  INVx1_ASAP7_75t_R   g094(.A(new_n152_), .Y(new_n153_));
  XNOR2x2_ASAP7_75t_R g095(.A(G14), .B(new_n152_), .Y(G1899));
  OR3x1_ASAP7_75t_R   g096(.A(G31), .B(G29), .C(new_n98_), .Y(new_n155_));
  AO21x1_ASAP7_75t_R  g097(.A1(new_n97_), .A2(new_n155_), .B(new_n95_), .Y(new_n156_));
  NOR2x1_ASAP7_75t_R  g098(.A(new_n125_), .B(new_n138_), .Y(new_n157_));
  OR3x1_ASAP7_75t_R   g099(.A(new_n150_), .B(new_n157_), .C(new_n124_), .Y(new_n158_));
  NOR2x1_ASAP7_75t_R  g100(.A(new_n156_), .B(new_n158_), .Y(new_n159_));
  INVx1_ASAP7_75t_R   g101(.A(new_n159_), .Y(new_n160_));
  XNOR2x2_ASAP7_75t_R g102(.A(new_n71_), .B(new_n160_), .Y(G1884));
  XNOR2x2_ASAP7_75t_R g103(.A(new_n69_), .B(new_n160_), .Y(G1885));
  XNOR2x2_ASAP7_75t_R g104(.A(G13), .B(new_n152_), .Y(G1898));
  XNOR2x2_ASAP7_75t_R g105(.A(G3), .B(new_n159_), .Y(G1886));
  XNOR2x2_ASAP7_75t_R g106(.A(G4), .B(new_n159_), .Y(G1887));
  NOR2x1_ASAP7_75t_R  g107(.A(new_n100_), .B(new_n158_), .Y(new_n166_));
  XNOR2x2_ASAP7_75t_R g108(.A(G10), .B(new_n166_), .Y(G1888));
  XNOR2x2_ASAP7_75t_R g109(.A(G15), .B(new_n166_), .Y(G1889));
  XNOR2x2_ASAP7_75t_R g110(.A(G16), .B(new_n166_), .Y(G1890));
  NAND2x1_ASAP7_75t_R g111(.A(new_n147_), .B(new_n148_), .Y(new_n170_));
  OR3x1_ASAP7_75t_R   g112(.A(new_n157_), .B(new_n170_), .C(new_n124_), .Y(new_n171_));
  NOR2x1_ASAP7_75t_R  g113(.A(new_n156_), .B(new_n171_), .Y(new_n172_));
  INVx1_ASAP7_75t_R   g114(.A(new_n172_), .Y(new_n173_));
  XNOR2x2_ASAP7_75t_R g115(.A(new_n68_), .B(new_n173_), .Y(G1891));
  XNOR2x2_ASAP7_75t_R g116(.A(G6), .B(new_n172_), .Y(G1892));
  XNOR2x2_ASAP7_75t_R g117(.A(new_n70_), .B(new_n173_), .Y(G1893));
  XNOR2x2_ASAP7_75t_R g118(.A(new_n63_), .B(new_n173_), .Y(G1894));
  NOR2x1_ASAP7_75t_R  g119(.A(new_n100_), .B(new_n171_), .Y(new_n178_));
  XNOR2x2_ASAP7_75t_R g120(.A(G9), .B(new_n178_), .Y(G1895));
  XNOR2x2_ASAP7_75t_R g121(.A(new_n67_), .B(new_n153_), .Y(G1896));
  XNOR2x2_ASAP7_75t_R g122(.A(new_n64_), .B(new_n153_), .Y(G1897));
  OR3x1_ASAP7_75t_R   g123(.A(new_n139_), .B(new_n170_), .C(new_n124_), .Y(new_n182_));
  OR3x1_ASAP7_75t_R   g124(.A(new_n85_), .B(new_n94_), .C(new_n97_), .Y(new_n183_));
  NOR2x1_ASAP7_75t_R  g125(.A(new_n182_), .B(new_n183_), .Y(new_n184_));
  OR3x1_ASAP7_75t_R   g126(.A(new_n95_), .B(new_n97_), .C(new_n151_), .Y(new_n185_));
  OAI21x1_ASAP7_75t_R g127(.A1(new_n171_), .A2(new_n183_), .B(new_n185_), .Y(new_n186_));
  OR3x1_ASAP7_75t_R   g128(.A(new_n184_), .B(new_n186_), .C(new_n184_), .Y(new_n187_));
  OR3x1_ASAP7_75t_R   g129(.A(new_n166_), .B(new_n178_), .C(new_n152_), .Y(new_n188_));
  OR3x1_ASAP7_75t_R   g130(.A(new_n152_), .B(new_n166_), .C(new_n188_), .Y(new_n189_));
  OR3x1_ASAP7_75t_R   g131(.A(new_n159_), .B(new_n172_), .C(new_n189_), .Y(new_n190_));
  INVx1_ASAP7_75t_R   g132(.A(new_n190_), .Y(new_n191_));
  OR3x1_ASAP7_75t_R   g133(.A(new_n187_), .B(new_n190_), .C(new_n62_), .Y(new_n192_));
  AND2x2_ASAP7_75t_R  g134(.A(new_n138_), .B(new_n149_), .Y(new_n193_));
  AND3x1_ASAP7_75t_R  g135(.A(new_n125_), .B(new_n147_), .C(new_n193_), .Y(new_n194_));
  OR2x4_ASAP7_75t_R   g136(.A(new_n94_), .B(new_n109_), .Y(new_n195_));
  OR3x1_ASAP7_75t_R   g137(.A(new_n85_), .B(new_n123_), .C(new_n195_), .Y(new_n196_));
  INVx1_ASAP7_75t_R   g138(.A(new_n196_), .Y(new_n197_));
  AO21x1_ASAP7_75t_R  g139(.A1(new_n194_), .A2(new_n197_), .B(G33), .Y(new_n198_));
  OR2x4_ASAP7_75t_R   g140(.A(new_n192_), .B(new_n198_), .Y(new_n199_));
  OA21x2_ASAP7_75t_R  g141(.A1(G32), .A2(new_n198_), .B(new_n199_), .Y(G1900));
  OR3x1_ASAP7_75t_R   g142(.A(G31), .B(new_n127_), .C(new_n191_), .Y(new_n201_));
  XNOR2x2_ASAP7_75t_R g143(.A(new_n132_), .B(new_n135_), .Y(new_n202_));
  XOR2x2_ASAP7_75t_R  g144(.A(new_n201_), .B(new_n202_), .Y(new_n203_));
  AOI21x1_ASAP7_75t_R g145(.A1(new_n60_), .A2(new_n62_), .B(new_n203_), .Y(G1901));
  AND3x1_ASAP7_75t_R  g146(.A(new_n61_), .B(G25), .C(new_n190_), .Y(new_n205_));
  XOR2x2_ASAP7_75t_R  g147(.A(new_n145_), .B(new_n205_), .Y(new_n206_));
  AOI21x1_ASAP7_75t_R g148(.A1(new_n60_), .A2(new_n62_), .B(new_n206_), .Y(G1902));
  AND3x1_ASAP7_75t_R  g149(.A(new_n61_), .B(G27), .C(new_n190_), .Y(new_n208_));
  XOR2x2_ASAP7_75t_R  g150(.A(new_n83_), .B(new_n208_), .Y(new_n209_));
  AOI21x1_ASAP7_75t_R g151(.A1(new_n60_), .A2(new_n62_), .B(new_n209_), .Y(G1903));
  AND3x1_ASAP7_75t_R  g152(.A(new_n61_), .B(G28), .C(new_n190_), .Y(new_n211_));
  XNOR2x2_ASAP7_75t_R g153(.A(new_n92_), .B(new_n211_), .Y(new_n212_));
  AOI21x1_ASAP7_75t_R g154(.A1(new_n60_), .A2(new_n62_), .B(new_n212_), .Y(G1904));
  AND3x1_ASAP7_75t_R  g155(.A(new_n61_), .B(new_n101_), .C(new_n190_), .Y(new_n214_));
  XOR2x2_ASAP7_75t_R  g156(.A(new_n107_), .B(new_n214_), .Y(new_n215_));
  AOI21x1_ASAP7_75t_R g157(.A1(new_n60_), .A2(new_n62_), .B(new_n215_), .Y(G1905));
  AOI21x1_ASAP7_75t_R g158(.A1(G21), .A2(G29), .B(G33), .Y(new_n217_));
  OAI21x1_ASAP7_75t_R g159(.A1(G33), .A2(G29), .B(new_n132_), .Y(new_n218_));
  OA21x2_ASAP7_75t_R  g160(.A1(new_n159_), .A2(new_n172_), .B(new_n60_), .Y(new_n219_));
  XOR2x2_ASAP7_75t_R  g161(.A(new_n218_), .B(new_n219_), .Y(new_n220_));
  XNOR2x2_ASAP7_75t_R g162(.A(new_n217_), .B(new_n220_), .Y(G1906));
  AO21x1_ASAP7_75t_R  g163(.A1(G30), .A2(G22), .B(G33), .Y(new_n222_));
  XNOR2x2_ASAP7_75t_R g164(.A(new_n65_), .B(G14), .Y(new_n223_));
  XOR2x2_ASAP7_75t_R  g165(.A(new_n115_), .B(new_n223_), .Y(new_n224_));
  OA21x2_ASAP7_75t_R  g166(.A1(G33), .A2(G30), .B(new_n224_), .Y(new_n225_));
  NAND2x1_ASAP7_75t_R g167(.A(new_n60_), .B(new_n189_), .Y(new_n226_));
  XNOR2x2_ASAP7_75t_R g168(.A(new_n225_), .B(new_n226_), .Y(new_n227_));
  XNOR2x2_ASAP7_75t_R g169(.A(new_n222_), .B(new_n227_), .Y(G1907));
  OR3x1_ASAP7_75t_R   g170(.A(G31), .B(new_n73_), .C(new_n191_), .Y(new_n229_));
  XOR2x2_ASAP7_75t_R  g171(.A(new_n118_), .B(new_n229_), .Y(new_n230_));
  XNOR2x2_ASAP7_75t_R g172(.A(new_n120_), .B(new_n230_), .Y(new_n231_));
  AOI21x1_ASAP7_75t_R g173(.A1(new_n60_), .A2(new_n62_), .B(new_n231_), .Y(G1908));
endmodule


