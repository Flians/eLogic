// Benchmark "/home/flynn/workplace/MIGBalance/results_v2/fixed_all_eqmap_delay_20261012/c880/eqmap_lut_amap/stage" written by ABC on Mon Oct 12 15:02:23 2026

module \/home/flynn/workplace/MIGBalance/results_v2/fixed_all_eqmap_delay_20261012/c880/eqmap_lut_amap/stage  ( 
    G1, G10, G11, G12, G13, G14, G15, G16, G17, G18, G19, G2, G20, G21,
    G22, G23, G24, G25, G26, G27, G28, G29, G3, G30, G31, G32, G33, G34,
    G35, G36, G37, G38, G39, G4, G40, G41, G42, G43, G44, G45, G46, G47,
    G48, G49, G5, G50, G51, G52, G53, G54, G55, G56, G57, G58, G59, G6,
    G60, G7, G8, G9,
    G855, G856, G857, G858, G859, G860, G861, G862, G863, G864, G865, G866,
    G867, G868, G869, G870, G871, G872, G873, G874, G875, G876, G877, G878,
    G879, G880  );
  input  G1, G10, G11, G12, G13, G14, G15, G16, G17, G18, G19, G2, G20,
    G21, G22, G23, G24, G25, G26, G27, G28, G29, G3, G30, G31, G32, G33,
    G34, G35, G36, G37, G38, G39, G4, G40, G41, G42, G43, G44, G45, G46,
    G47, G48, G49, G5, G50, G51, G52, G53, G54, G55, G56, G57, G58, G59,
    G6, G60, G7, G8, G9;
  output G855, G856, G857, G858, G859, G860, G861, G862, G863, G864, G865,
    G866, G867, G868, G869, G870, G871, G872, G873, G874, G875, G876, G877,
    G878, G879, G880;
  wire new_n87_, new_n88_, new_n89_, new_n90_, new_n91_, new_n92_, new_n93_,
    new_n94_, new_n95_, new_n96_, new_n97_, new_n98_, new_n99_, new_n100_,
    new_n101_, new_n102_, new_n103_, new_n104_, new_n105_, new_n106_,
    new_n107_, new_n108_, new_n109_, new_n110_, new_n111_, new_n112_,
    new_n113_, new_n114_, new_n115_, new_n116_, new_n117_, new_n118_,
    new_n119_, new_n120_, new_n121_, new_n122_, new_n123_, new_n124_,
    new_n125_, new_n126_, new_n127_, new_n128_, new_n129_, new_n130_,
    new_n131_, new_n132_, new_n134_, new_n136_, new_n138_, new_n140_,
    new_n141_, new_n143_, new_n144_, new_n149_, new_n151_, new_n152_,
    new_n154_, new_n156_, new_n157_, new_n158_, new_n159_, new_n160_,
    new_n162_, new_n163_, new_n164_, new_n165_, new_n168_, new_n169_,
    new_n170_, new_n171_, new_n172_, new_n173_, new_n174_, new_n175_,
    new_n176_, new_n177_, new_n178_, new_n179_, new_n180_, new_n181_,
    new_n182_, new_n183_, new_n184_, new_n185_, new_n186_, new_n187_,
    new_n188_, new_n189_, new_n190_, new_n191_, new_n193_, new_n194_,
    new_n195_, new_n196_, new_n197_, new_n198_, new_n199_, new_n200_,
    new_n201_, new_n202_, new_n203_, new_n204_, new_n205_, new_n206_,
    new_n207_, new_n208_, new_n209_, new_n210_, new_n211_, new_n212_,
    new_n213_, new_n214_, new_n215_, new_n216_, new_n217_, new_n218_,
    new_n219_, new_n220_, new_n221_, new_n222_, new_n223_, new_n224_,
    new_n226_, new_n227_, new_n228_, new_n229_, new_n230_, new_n231_,
    new_n232_, new_n233_, new_n234_, new_n235_, new_n236_, new_n237_,
    new_n238_, new_n239_, new_n240_, new_n241_, new_n242_, new_n243_,
    new_n244_, new_n245_, new_n246_, new_n247_, new_n248_, new_n249_,
    new_n250_, new_n251_, new_n252_, new_n253_, new_n254_, new_n255_,
    new_n256_, new_n257_, new_n258_, new_n259_, new_n260_, new_n261_,
    new_n262_, new_n263_, new_n264_, new_n265_, new_n266_, new_n267_,
    new_n268_, new_n269_, new_n270_, new_n271_, new_n272_, new_n273_,
    new_n275_, new_n276_, new_n277_, new_n278_, new_n279_, new_n280_,
    new_n281_, new_n282_, new_n283_, new_n284_, new_n285_, new_n286_,
    new_n287_, new_n288_, new_n289_, new_n290_, new_n291_, new_n292_,
    new_n293_, new_n294_, new_n295_, new_n296_, new_n297_, new_n298_,
    new_n299_, new_n300_, new_n301_, new_n302_, new_n303_, new_n304_,
    new_n305_, new_n306_, new_n307_, new_n308_, new_n309_, new_n310_,
    new_n311_, new_n312_, new_n313_, new_n314_, new_n315_, new_n316_,
    new_n317_, new_n318_, new_n319_, new_n320_, new_n321_, new_n322_,
    new_n323_, new_n324_, new_n325_, new_n326_, new_n327_, new_n328_,
    new_n329_, new_n330_, new_n331_, new_n332_, new_n333_, new_n334_,
    new_n335_, new_n336_, new_n337_, new_n338_, new_n339_, new_n340_,
    new_n341_, new_n342_, new_n343_, new_n344_, new_n345_, new_n346_,
    new_n347_, new_n348_, new_n350_, new_n351_, new_n352_, new_n353_,
    new_n354_, new_n355_, new_n356_, new_n357_, new_n358_, new_n359_,
    new_n360_, new_n361_, new_n362_, new_n363_, new_n364_, new_n365_,
    new_n366_, new_n367_, new_n368_, new_n369_, new_n370_, new_n371_,
    new_n372_, new_n373_, new_n375_, new_n376_, new_n377_, new_n378_,
    new_n379_, new_n380_, new_n381_, new_n382_, new_n383_, new_n384_,
    new_n385_, new_n386_, new_n387_, new_n388_, new_n389_, new_n390_,
    new_n391_, new_n392_, new_n393_, new_n395_, new_n396_, new_n397_,
    new_n398_, new_n399_, new_n400_, new_n401_, new_n402_, new_n403_,
    new_n404_, new_n405_, new_n406_, new_n407_, new_n408_, new_n409_,
    new_n410_, new_n411_, new_n412_, new_n413_, new_n414_, new_n415_,
    new_n416_, new_n417_, new_n418_, new_n419_, new_n420_, new_n421_,
    new_n422_, new_n423_, new_n424_, new_n425_, new_n426_, new_n427_,
    new_n428_, new_n429_, new_n430_, new_n431_, new_n432_, new_n433_,
    new_n434_, new_n435_, new_n436_, new_n437_, new_n438_, new_n439_,
    new_n440_, new_n441_, new_n442_, new_n443_, new_n444_, new_n445_,
    new_n446_, new_n447_, new_n448_, new_n449_, new_n450_, new_n451_,
    new_n452_, new_n453_, new_n454_, new_n455_, new_n456_, new_n457_,
    new_n458_, new_n459_, new_n460_, new_n461_, new_n462_, new_n463_,
    new_n464_, new_n465_, new_n466_, new_n467_, new_n468_, new_n469_,
    new_n470_, new_n471_, new_n472_, new_n473_, new_n474_, new_n475_,
    new_n476_, new_n477_, new_n478_, new_n479_, new_n481_, new_n482_,
    new_n483_, new_n484_, new_n485_, new_n486_, new_n487_, new_n488_,
    new_n489_, new_n490_, new_n491_, new_n492_, new_n493_, new_n494_,
    new_n495_, new_n496_, new_n497_, new_n498_, new_n499_, new_n500_,
    new_n501_, new_n503_, new_n504_, new_n505_, new_n506_, new_n507_,
    new_n508_, new_n509_, new_n510_, new_n511_, new_n512_, new_n513_,
    new_n514_, new_n515_, new_n516_, new_n517_, new_n518_, new_n519_,
    new_n520_, new_n521_, new_n522_, new_n523_, new_n524_, new_n525_,
    new_n526_, new_n527_, new_n528_, new_n529_, new_n530_, new_n531_,
    new_n532_, new_n533_, new_n534_, new_n535_, new_n536_, new_n537_,
    new_n539_, new_n540_, new_n541_, new_n542_, new_n543_, new_n544_,
    new_n545_, new_n546_, new_n547_, new_n548_, new_n549_, new_n550_,
    new_n551_, new_n552_, new_n553_, new_n555_, new_n556_, new_n557_,
    new_n558_, new_n559_, new_n560_, new_n561_, new_n562_, new_n563_,
    new_n564_, new_n565_, new_n566_, new_n567_, new_n568_, new_n569_,
    new_n570_, new_n571_, new_n572_, new_n573_, new_n574_, new_n575_,
    new_n576_;
  INVx1_ASAP7_75t_R   g000(.A(G1), .Y(new_n87_));
  INVx1_ASAP7_75t_R   g001(.A(G10), .Y(new_n88_));
  INVx1_ASAP7_75t_R   g002(.A(G11), .Y(new_n89_));
  INVx1_ASAP7_75t_R   g003(.A(G12), .Y(new_n90_));
  INVx1_ASAP7_75t_R   g004(.A(G16), .Y(new_n91_));
  INVx1_ASAP7_75t_R   g005(.A(G17), .Y(new_n92_));
  INVx1_ASAP7_75t_R   g006(.A(G18), .Y(new_n93_));
  INVx1_ASAP7_75t_R   g007(.A(G2), .Y(new_n94_));
  INVx1_ASAP7_75t_R   g008(.A(G22), .Y(new_n95_));
  INVx1_ASAP7_75t_R   g009(.A(G23), .Y(new_n96_));
  INVx1_ASAP7_75t_R   g010(.A(G24), .Y(new_n97_));
  INVx1_ASAP7_75t_R   g011(.A(G25), .Y(new_n98_));
  INVx1_ASAP7_75t_R   g012(.A(G26), .Y(new_n99_));
  INVx1_ASAP7_75t_R   g013(.A(G27), .Y(new_n100_));
  INVx1_ASAP7_75t_R   g014(.A(G28), .Y(new_n101_));
  INVx1_ASAP7_75t_R   g015(.A(G29), .Y(new_n102_));
  INVx1_ASAP7_75t_R   g016(.A(G3), .Y(new_n103_));
  INVx1_ASAP7_75t_R   g017(.A(G30), .Y(new_n104_));
  INVx1_ASAP7_75t_R   g018(.A(G31), .Y(new_n105_));
  INVx1_ASAP7_75t_R   g019(.A(G34), .Y(new_n106_));
  INVx1_ASAP7_75t_R   g020(.A(G35), .Y(new_n107_));
  INVx1_ASAP7_75t_R   g021(.A(G37), .Y(new_n108_));
  INVx1_ASAP7_75t_R   g022(.A(G39), .Y(new_n109_));
  INVx1_ASAP7_75t_R   g023(.A(G4), .Y(new_n110_));
  INVx1_ASAP7_75t_R   g024(.A(G40), .Y(new_n111_));
  INVx1_ASAP7_75t_R   g025(.A(G41), .Y(new_n112_));
  INVx1_ASAP7_75t_R   g026(.A(G42), .Y(new_n113_));
  INVx1_ASAP7_75t_R   g027(.A(G43), .Y(new_n114_));
  INVx1_ASAP7_75t_R   g028(.A(G44), .Y(new_n115_));
  INVx1_ASAP7_75t_R   g029(.A(G45), .Y(new_n116_));
  INVx1_ASAP7_75t_R   g030(.A(G46), .Y(new_n117_));
  INVx1_ASAP7_75t_R   g031(.A(G47), .Y(new_n118_));
  INVx1_ASAP7_75t_R   g032(.A(G48), .Y(new_n119_));
  INVx1_ASAP7_75t_R   g033(.A(G5), .Y(new_n120_));
  INVx1_ASAP7_75t_R   g034(.A(G50), .Y(new_n121_));
  INVx1_ASAP7_75t_R   g035(.A(G51), .Y(new_n122_));
  INVx1_ASAP7_75t_R   g036(.A(G52), .Y(new_n123_));
  INVx1_ASAP7_75t_R   g037(.A(G54), .Y(new_n124_));
  INVx1_ASAP7_75t_R   g038(.A(G55), .Y(new_n125_));
  INVx1_ASAP7_75t_R   g039(.A(G57), .Y(new_n126_));
  INVx1_ASAP7_75t_R   g040(.A(G58), .Y(new_n127_));
  INVx1_ASAP7_75t_R   g041(.A(G6), .Y(new_n128_));
  INVx1_ASAP7_75t_R   g042(.A(G7), .Y(new_n129_));
  INVx1_ASAP7_75t_R   g043(.A(G8), .Y(new_n130_));
  INVx1_ASAP7_75t_R   g044(.A(G9), .Y(new_n131_));
  AO21x1_ASAP7_75t_R  g045(.A1(G16), .A2(new_n128_), .B(new_n91_), .Y(new_n132_));
  AO21x1_ASAP7_75t_R  g046(.A1(G8), .A2(new_n132_), .B(new_n130_), .Y(G855));
  AO21x1_ASAP7_75t_R  g047(.A1(G17), .A2(new_n129_), .B(new_n92_), .Y(new_n134_));
  AO21x1_ASAP7_75t_R  g048(.A1(G6), .A2(new_n134_), .B(new_n128_), .Y(G856));
  AO21x1_ASAP7_75t_R  g049(.A1(G6), .A2(new_n129_), .B(new_n128_), .Y(new_n136_));
  AO21x1_ASAP7_75t_R  g050(.A1(G8), .A2(new_n136_), .B(new_n130_), .Y(G857));
  INVx1_ASAP7_75t_R   g051(.A(G857), .Y(new_n138_));
  OAI21x1_ASAP7_75t_R g052(.A1(new_n93_), .A2(G19), .B(G18), .Y(G858));
  AO21x1_ASAP7_75t_R  g053(.A1(G1), .A2(new_n110_), .B(new_n87_), .Y(new_n140_));
  AO21x1_ASAP7_75t_R  g054(.A1(G2), .A2(new_n140_), .B(new_n94_), .Y(new_n141_));
  AO21x1_ASAP7_75t_R  g055(.A1(G3), .A2(new_n141_), .B(new_n103_), .Y(G859));
  OR3x1_ASAP7_75t_R   g056(.A(new_n110_), .B(new_n138_), .C(new_n120_), .Y(new_n143_));
  OR3x1_ASAP7_75t_R   g057(.A(new_n87_), .B(new_n143_), .C(new_n103_), .Y(new_n144_));
  INVx1_ASAP7_75t_R   g058(.A(new_n144_), .Y(G860));
  AND3x1_ASAP7_75t_R  g059(.A(G16), .B(G17), .C(G11), .Y(G861));
  AND3x1_ASAP7_75t_R  g060(.A(G17), .B(G7), .C(G11), .Y(G862));
  AND3x1_ASAP7_75t_R  g061(.A(G11), .B(G7), .C(G8), .Y(G863));
  NOR2x1_ASAP7_75t_R  g062(.A(G20), .B(G21), .Y(new_n149_));
  AO21x1_ASAP7_75t_R  g063(.A1(G23), .A2(new_n149_), .B(new_n96_), .Y(G864));
  OR3x1_ASAP7_75t_R   g064(.A(new_n110_), .B(new_n120_), .C(new_n87_), .Y(new_n151_));
  OR3x1_ASAP7_75t_R   g065(.A(new_n103_), .B(new_n151_), .C(G857), .Y(new_n152_));
  INVx1_ASAP7_75t_R   g066(.A(new_n152_), .Y(G865));
  AO21x1_ASAP7_75t_R  g067(.A1(G5), .A2(new_n131_), .B(new_n120_), .Y(new_n154_));
  AO21x1_ASAP7_75t_R  g068(.A1(G1), .A2(new_n154_), .B(new_n87_), .Y(G866));
  INVx1_ASAP7_75t_R   g069(.A(G866), .Y(new_n156_));
  AO21x1_ASAP7_75t_R  g070(.A1(G1), .A2(new_n128_), .B(new_n87_), .Y(new_n157_));
  AO21x1_ASAP7_75t_R  g071(.A1(G10), .A2(new_n157_), .B(new_n88_), .Y(new_n158_));
  AO21x1_ASAP7_75t_R  g072(.A1(G2), .A2(new_n158_), .B(new_n94_), .Y(new_n159_));
  AO21x1_ASAP7_75t_R  g073(.A1(G3), .A2(new_n159_), .B(new_n103_), .Y(new_n160_));
  AO21x1_ASAP7_75t_R  g074(.A1(G12), .A2(new_n160_), .B(new_n90_), .Y(G867));
  OR3x1_ASAP7_75t_R   g075(.A(new_n87_), .B(new_n89_), .C(new_n88_), .Y(new_n162_));
  NOR2x1_ASAP7_75t_R  g076(.A(new_n94_), .B(new_n162_), .Y(new_n163_));
  AND3x1_ASAP7_75t_R  g077(.A(G3), .B(new_n163_), .C(G12), .Y(new_n164_));
  INVx1_ASAP7_75t_R   g078(.A(new_n164_), .Y(new_n165_));
  OAI21x1_ASAP7_75t_R g079(.A1(G15), .A2(new_n165_), .B(new_n164_), .Y(G868));
  AO21x1_ASAP7_75t_R  g080(.A1(G22), .A2(new_n149_), .B(new_n95_), .Y(G869));
  XNOR2x2_ASAP7_75t_R g081(.A(G30), .B(new_n105_), .Y(new_n168_));
  XOR2x2_ASAP7_75t_R  g082(.A(new_n104_), .B(new_n105_), .Y(new_n169_));
  NOR2x1_ASAP7_75t_R  g083(.A(G27), .B(new_n169_), .Y(new_n170_));
  AO21x1_ASAP7_75t_R  g084(.A1(G27), .A2(new_n168_), .B(new_n170_), .Y(new_n171_));
  NOR2x1_ASAP7_75t_R  g085(.A(new_n100_), .B(new_n169_), .Y(new_n172_));
  AO21x1_ASAP7_75t_R  g086(.A1(new_n100_), .A2(new_n168_), .B(new_n172_), .Y(new_n173_));
  AND2x2_ASAP7_75t_R  g087(.A(new_n99_), .B(new_n173_), .Y(new_n174_));
  AO21x1_ASAP7_75t_R  g088(.A1(G26), .A2(new_n171_), .B(new_n174_), .Y(new_n175_));
  XOR2x2_ASAP7_75t_R  g089(.A(G33), .B(new_n175_), .Y(new_n176_));
  XOR2x2_ASAP7_75t_R  g090(.A(G33), .B(new_n175_), .Y(new_n177_));
  NOR2x1_ASAP7_75t_R  g091(.A(G29), .B(new_n177_), .Y(new_n178_));
  AO21x1_ASAP7_75t_R  g092(.A1(G29), .A2(new_n176_), .B(new_n178_), .Y(new_n179_));
  NOR2x1_ASAP7_75t_R  g093(.A(new_n102_), .B(new_n177_), .Y(new_n180_));
  AO21x1_ASAP7_75t_R  g094(.A1(new_n102_), .A2(new_n176_), .B(new_n180_), .Y(new_n181_));
  AND2x2_ASAP7_75t_R  g095(.A(new_n101_), .B(new_n181_), .Y(new_n182_));
  AO21x1_ASAP7_75t_R  g096(.A1(G28), .A2(new_n179_), .B(new_n182_), .Y(new_n183_));
  XOR2x2_ASAP7_75t_R  g097(.A(G24), .B(new_n183_), .Y(new_n184_));
  NOR2x1_ASAP7_75t_R  g098(.A(new_n98_), .B(new_n184_), .Y(new_n185_));
  XNOR2x2_ASAP7_75t_R g099(.A(new_n97_), .B(new_n183_), .Y(new_n186_));
  AO21x1_ASAP7_75t_R  g100(.A1(new_n98_), .A2(new_n186_), .B(new_n185_), .Y(new_n187_));
  NAND2x1_ASAP7_75t_R g101(.A(G32), .B(new_n187_), .Y(new_n188_));
  NAND2x1_ASAP7_75t_R g102(.A(G25), .B(new_n186_), .Y(new_n189_));
  OA21x2_ASAP7_75t_R  g103(.A1(G25), .A2(new_n184_), .B(new_n189_), .Y(new_n190_));
  OR2x4_ASAP7_75t_R   g104(.A(G32), .B(new_n190_), .Y(new_n191_));
  NAND2x1_ASAP7_75t_R g105(.A(new_n188_), .B(new_n191_), .Y(G870));
  XOR2x2_ASAP7_75t_R  g106(.A(new_n118_), .B(new_n119_), .Y(new_n193_));
  NOR2x1_ASAP7_75t_R  g107(.A(new_n117_), .B(new_n193_), .Y(new_n194_));
  XNOR2x2_ASAP7_75t_R g108(.A(new_n118_), .B(G48), .Y(new_n195_));
  AO21x1_ASAP7_75t_R  g109(.A1(new_n117_), .A2(new_n195_), .B(new_n194_), .Y(new_n196_));
  INVx1_ASAP7_75t_R   g110(.A(new_n196_), .Y(new_n197_));
  NOR2x1_ASAP7_75t_R  g111(.A(G46), .B(new_n193_), .Y(new_n198_));
  AO21x1_ASAP7_75t_R  g112(.A1(G46), .A2(new_n195_), .B(new_n198_), .Y(new_n199_));
  INVx1_ASAP7_75t_R   g113(.A(new_n199_), .Y(new_n200_));
  NOR2x1_ASAP7_75t_R  g114(.A(G49), .B(new_n200_), .Y(new_n201_));
  AO21x1_ASAP7_75t_R  g115(.A1(G49), .A2(new_n196_), .B(new_n201_), .Y(new_n202_));
  NOR2x1_ASAP7_75t_R  g116(.A(G49), .B(new_n197_), .Y(new_n203_));
  AO21x1_ASAP7_75t_R  g117(.A1(G49), .A2(new_n199_), .B(new_n203_), .Y(new_n204_));
  AND2x2_ASAP7_75t_R  g118(.A(new_n114_), .B(new_n204_), .Y(new_n205_));
  AO21x1_ASAP7_75t_R  g119(.A1(G43), .A2(new_n202_), .B(new_n205_), .Y(new_n206_));
  AND2x2_ASAP7_75t_R  g120(.A(new_n114_), .B(new_n202_), .Y(new_n207_));
  AOI21x1_ASAP7_75t_R g121(.A1(G43), .A2(new_n204_), .B(new_n207_), .Y(new_n208_));
  NOR2x1_ASAP7_75t_R  g122(.A(G44), .B(new_n208_), .Y(new_n209_));
  AO21x1_ASAP7_75t_R  g123(.A1(G44), .A2(new_n206_), .B(new_n209_), .Y(new_n210_));
  XOR2x2_ASAP7_75t_R  g124(.A(G41), .B(new_n210_), .Y(new_n211_));
  NOR2x1_ASAP7_75t_R  g125(.A(new_n113_), .B(new_n211_), .Y(new_n212_));
  XNOR2x2_ASAP7_75t_R g126(.A(new_n112_), .B(new_n210_), .Y(new_n213_));
  AO21x1_ASAP7_75t_R  g127(.A1(new_n113_), .A2(new_n213_), .B(new_n212_), .Y(new_n214_));
  INVx1_ASAP7_75t_R   g128(.A(new_n214_), .Y(new_n215_));
  NOR2x1_ASAP7_75t_R  g129(.A(G42), .B(new_n211_), .Y(new_n216_));
  AO21x1_ASAP7_75t_R  g130(.A1(G42), .A2(new_n213_), .B(new_n216_), .Y(new_n217_));
  INVx1_ASAP7_75t_R   g131(.A(new_n217_), .Y(new_n218_));
  NOR2x1_ASAP7_75t_R  g132(.A(G32), .B(new_n218_), .Y(new_n219_));
  AO21x1_ASAP7_75t_R  g133(.A1(G32), .A2(new_n214_), .B(new_n219_), .Y(new_n220_));
  NAND2x1_ASAP7_75t_R g134(.A(G45), .B(new_n220_), .Y(new_n221_));
  NAND2x1_ASAP7_75t_R g135(.A(G32), .B(new_n217_), .Y(new_n222_));
  OA21x2_ASAP7_75t_R  g136(.A1(G32), .A2(new_n215_), .B(new_n222_), .Y(new_n223_));
  OR2x4_ASAP7_75t_R   g137(.A(G45), .B(new_n223_), .Y(new_n224_));
  NAND2x1_ASAP7_75t_R g138(.A(new_n221_), .B(new_n224_), .Y(G871));
  OAI21x1_ASAP7_75t_R g139(.A1(new_n125_), .A2(G59), .B(G55), .Y(new_n226_));
  AND3x1_ASAP7_75t_R  g140(.A(new_n104_), .B(new_n226_), .C(G50), .Y(new_n227_));
  AOI21x1_ASAP7_75t_R g141(.A1(new_n121_), .A2(new_n226_), .B(new_n227_), .Y(new_n228_));
  OR3x1_ASAP7_75t_R   g142(.A(G60), .B(G866), .C(new_n92_), .Y(new_n229_));
  OR3x1_ASAP7_75t_R   g143(.A(new_n128_), .B(new_n229_), .C(new_n91_), .Y(new_n230_));
  NOR2x1_ASAP7_75t_R  g144(.A(new_n88_), .B(new_n230_), .Y(new_n231_));
  INVx1_ASAP7_75t_R   g145(.A(new_n231_), .Y(new_n232_));
  AO21x1_ASAP7_75t_R  g146(.A1(G11), .A2(new_n111_), .B(new_n89_), .Y(new_n233_));
  AO21x1_ASAP7_75t_R  g147(.A1(G1), .A2(new_n233_), .B(new_n87_), .Y(new_n234_));
  AND2x2_ASAP7_75t_R  g148(.A(new_n156_), .B(new_n234_), .Y(new_n235_));
  AO21x1_ASAP7_75t_R  g149(.A1(new_n87_), .A2(G866), .B(new_n235_), .Y(new_n236_));
  NAND2x1_ASAP7_75t_R g150(.A(G4), .B(new_n236_), .Y(new_n237_));
  OA21x2_ASAP7_75t_R  g151(.A1(G1), .A2(G4), .B(new_n237_), .Y(new_n238_));
  NOR2x1_ASAP7_75t_R  g152(.A(new_n109_), .B(new_n238_), .Y(new_n239_));
  AO21x1_ASAP7_75t_R  g153(.A1(G11), .A2(new_n91_), .B(new_n89_), .Y(new_n240_));
  AOI21x1_ASAP7_75t_R g154(.A1(G8), .A2(new_n240_), .B(new_n130_), .Y(new_n241_));
  OR3x1_ASAP7_75t_R   g155(.A(new_n110_), .B(new_n241_), .C(new_n131_), .Y(new_n242_));
  AO21x1_ASAP7_75t_R  g156(.A1(G1), .A2(new_n242_), .B(new_n87_), .Y(new_n243_));
  AO21x1_ASAP7_75t_R  g157(.A1(G2), .A2(new_n243_), .B(new_n94_), .Y(new_n244_));
  XOR2x2_ASAP7_75t_R  g158(.A(G4), .B(new_n130_), .Y(new_n245_));
  OR3x1_ASAP7_75t_R   g159(.A(new_n111_), .B(new_n245_), .C(new_n89_), .Y(new_n246_));
  AND3x1_ASAP7_75t_R  g160(.A(new_n244_), .B(new_n246_), .C(new_n156_), .Y(new_n247_));
  AO21x1_ASAP7_75t_R  g161(.A1(G866), .A2(new_n244_), .B(new_n247_), .Y(new_n248_));
  INVx1_ASAP7_75t_R   g162(.A(new_n248_), .Y(new_n249_));
  OA21x2_ASAP7_75t_R  g163(.A1(G31), .A2(new_n248_), .B(new_n249_), .Y(new_n250_));
  OR3x1_ASAP7_75t_R   g164(.A(new_n239_), .B(new_n250_), .C(new_n231_), .Y(new_n251_));
  INVx1_ASAP7_75t_R   g165(.A(new_n251_), .Y(new_n252_));
  AND2x2_ASAP7_75t_R  g166(.A(G13), .B(new_n164_), .Y(new_n253_));
  AND3x1_ASAP7_75t_R  g167(.A(G8), .B(new_n253_), .C(G14), .Y(new_n254_));
  INVx1_ASAP7_75t_R   g168(.A(new_n254_), .Y(new_n255_));
  OR3x1_ASAP7_75t_R   g169(.A(G52), .B(new_n254_), .C(new_n251_), .Y(new_n256_));
  OR3x1_ASAP7_75t_R   g170(.A(G53), .B(new_n254_), .C(new_n252_), .Y(new_n257_));
  AOI21x1_ASAP7_75t_R g171(.A1(new_n256_), .A2(new_n257_), .B(new_n119_), .Y(new_n258_));
  AO21x1_ASAP7_75t_R  g172(.A1(new_n123_), .A2(new_n251_), .B(new_n252_), .Y(new_n259_));
  AOI21x1_ASAP7_75t_R g173(.A1(new_n119_), .A2(new_n259_), .B(new_n258_), .Y(new_n260_));
  AO21x1_ASAP7_75t_R  g174(.A1(new_n122_), .A2(new_n127_), .B(G58), .Y(new_n261_));
  AO21x1_ASAP7_75t_R  g175(.A1(new_n122_), .A2(G58), .B(new_n127_), .Y(new_n262_));
  AND2x2_ASAP7_75t_R  g176(.A(new_n119_), .B(new_n262_), .Y(new_n263_));
  AO21x1_ASAP7_75t_R  g177(.A1(G48), .A2(new_n261_), .B(new_n263_), .Y(new_n264_));
  NAND2x1_ASAP7_75t_R g178(.A(new_n252_), .B(new_n264_), .Y(new_n265_));
  AND3x1_ASAP7_75t_R  g179(.A(new_n122_), .B(new_n124_), .C(G58), .Y(new_n266_));
  AO21x1_ASAP7_75t_R  g180(.A1(new_n124_), .A2(new_n127_), .B(new_n266_), .Y(new_n267_));
  AND3x1_ASAP7_75t_R  g181(.A(new_n122_), .B(new_n124_), .C(new_n127_), .Y(new_n268_));
  AO21x1_ASAP7_75t_R  g182(.A1(new_n124_), .A2(G58), .B(new_n268_), .Y(new_n269_));
  AND2x2_ASAP7_75t_R  g183(.A(new_n119_), .B(new_n269_), .Y(new_n270_));
  AOI21x1_ASAP7_75t_R g184(.A1(G48), .A2(new_n267_), .B(new_n270_), .Y(new_n271_));
  OA21x2_ASAP7_75t_R  g185(.A1(new_n252_), .A2(new_n271_), .B(new_n265_), .Y(new_n272_));
  OR3x1_ASAP7_75t_R   g186(.A(new_n228_), .B(new_n260_), .C(new_n272_), .Y(new_n273_));
  INVx1_ASAP7_75t_R   g187(.A(new_n273_), .Y(G872));
  AO21x1_ASAP7_75t_R  g188(.A1(new_n110_), .A2(new_n111_), .B(G40), .Y(new_n275_));
  NAND2x1_ASAP7_75t_R g189(.A(G9), .B(new_n275_), .Y(new_n276_));
  AO21x1_ASAP7_75t_R  g190(.A1(G9), .A2(new_n276_), .B(new_n120_), .Y(new_n277_));
  AO21x1_ASAP7_75t_R  g191(.A1(G5), .A2(new_n277_), .B(new_n89_), .Y(new_n278_));
  AO21x1_ASAP7_75t_R  g192(.A1(new_n110_), .A2(G9), .B(new_n131_), .Y(new_n279_));
  AOI21x1_ASAP7_75t_R g193(.A1(G5), .A2(new_n279_), .B(new_n120_), .Y(new_n280_));
  OA21x2_ASAP7_75t_R  g194(.A1(G11), .A2(new_n280_), .B(new_n278_), .Y(new_n281_));
  NOR2x1_ASAP7_75t_R  g195(.A(new_n87_), .B(new_n281_), .Y(new_n282_));
  INVx1_ASAP7_75t_R   g196(.A(new_n282_), .Y(new_n283_));
  NOR2x1_ASAP7_75t_R  g197(.A(new_n249_), .B(new_n283_), .Y(new_n284_));
  NOR2x1_ASAP7_75t_R  g198(.A(G28), .B(new_n283_), .Y(new_n285_));
  AO21x1_ASAP7_75t_R  g199(.A1(G28), .A2(new_n284_), .B(new_n285_), .Y(new_n286_));
  NAND2x1_ASAP7_75t_R g200(.A(G35), .B(new_n286_), .Y(new_n287_));
  OA21x2_ASAP7_75t_R  g201(.A1(new_n101_), .A2(new_n249_), .B(G28), .Y(new_n288_));
  OA21x2_ASAP7_75t_R  g202(.A1(G35), .A2(new_n288_), .B(new_n287_), .Y(new_n289_));
  NOR2x1_ASAP7_75t_R  g203(.A(new_n231_), .B(new_n289_), .Y(new_n290_));
  INVx1_ASAP7_75t_R   g204(.A(new_n290_), .Y(new_n291_));
  NOR2x1_ASAP7_75t_R  g205(.A(G45), .B(new_n291_), .Y(new_n292_));
  NOR2x1_ASAP7_75t_R  g206(.A(new_n254_), .B(new_n291_), .Y(new_n293_));
  AO21x1_ASAP7_75t_R  g207(.A1(new_n254_), .A2(new_n292_), .B(new_n293_), .Y(new_n294_));
  NAND2x1_ASAP7_75t_R g208(.A(G54), .B(new_n294_), .Y(new_n295_));
  NAND2x1_ASAP7_75t_R g209(.A(new_n116_), .B(new_n254_), .Y(new_n296_));
  OAI21x1_ASAP7_75t_R g210(.A1(G53), .A2(new_n290_), .B(new_n291_), .Y(new_n297_));
  AOI21x1_ASAP7_75t_R g211(.A1(G45), .A2(new_n297_), .B(new_n116_), .Y(new_n298_));
  OA21x2_ASAP7_75t_R  g212(.A1(new_n254_), .A2(new_n298_), .B(new_n296_), .Y(new_n299_));
  OA21x2_ASAP7_75t_R  g213(.A1(G54), .A2(new_n299_), .B(new_n295_), .Y(new_n300_));
  AO21x1_ASAP7_75t_R  g214(.A1(G27), .A2(G50), .B(new_n300_), .Y(new_n301_));
  AO21x1_ASAP7_75t_R  g215(.A1(new_n119_), .A2(G58), .B(G48), .Y(new_n302_));
  NAND2x1_ASAP7_75t_R g216(.A(G31), .B(new_n249_), .Y(new_n303_));
  OR3x1_ASAP7_75t_R   g217(.A(new_n105_), .B(new_n248_), .C(G58), .Y(new_n304_));
  AO21x1_ASAP7_75t_R  g218(.A1(new_n127_), .A2(new_n304_), .B(new_n119_), .Y(new_n305_));
  OR3x1_ASAP7_75t_R   g219(.A(new_n127_), .B(new_n303_), .C(G48), .Y(new_n306_));
  AOI21x1_ASAP7_75t_R g220(.A1(new_n305_), .A2(new_n306_), .B(new_n239_), .Y(new_n307_));
  AOI21x1_ASAP7_75t_R g221(.A1(new_n239_), .A2(new_n302_), .B(new_n307_), .Y(new_n308_));
  NOR2x1_ASAP7_75t_R  g222(.A(new_n231_), .B(new_n308_), .Y(new_n309_));
  AO21x1_ASAP7_75t_R  g223(.A1(new_n231_), .A2(new_n302_), .B(new_n309_), .Y(new_n310_));
  INVx1_ASAP7_75t_R   g224(.A(new_n310_), .Y(new_n311_));
  NOR2x1_ASAP7_75t_R  g225(.A(G30), .B(new_n283_), .Y(new_n312_));
  AO21x1_ASAP7_75t_R  g226(.A1(G30), .A2(new_n284_), .B(new_n312_), .Y(new_n313_));
  NAND2x1_ASAP7_75t_R g227(.A(G37), .B(new_n313_), .Y(new_n314_));
  OA21x2_ASAP7_75t_R  g228(.A1(new_n104_), .A2(new_n249_), .B(G30), .Y(new_n315_));
  OA21x2_ASAP7_75t_R  g229(.A1(G37), .A2(new_n315_), .B(new_n314_), .Y(new_n316_));
  NOR2x1_ASAP7_75t_R  g230(.A(new_n231_), .B(new_n316_), .Y(new_n317_));
  INVx1_ASAP7_75t_R   g231(.A(new_n317_), .Y(new_n318_));
  NOR2x1_ASAP7_75t_R  g232(.A(G29), .B(new_n283_), .Y(new_n319_));
  AO21x1_ASAP7_75t_R  g233(.A1(G29), .A2(new_n284_), .B(new_n319_), .Y(new_n320_));
  NAND2x1_ASAP7_75t_R g234(.A(G36), .B(new_n320_), .Y(new_n321_));
  OA21x2_ASAP7_75t_R  g235(.A1(new_n102_), .A2(new_n249_), .B(G29), .Y(new_n322_));
  OA21x2_ASAP7_75t_R  g236(.A1(G36), .A2(new_n322_), .B(new_n321_), .Y(new_n323_));
  NOR2x1_ASAP7_75t_R  g237(.A(new_n231_), .B(new_n323_), .Y(new_n324_));
  INVx1_ASAP7_75t_R   g238(.A(new_n324_), .Y(new_n325_));
  NOR2x1_ASAP7_75t_R  g239(.A(new_n318_), .B(new_n325_), .Y(new_n326_));
  AND3x1_ASAP7_75t_R  g240(.A(new_n311_), .B(new_n326_), .C(G47), .Y(new_n327_));
  NOR2x1_ASAP7_75t_R  g241(.A(new_n310_), .B(new_n325_), .Y(new_n328_));
  AO21x1_ASAP7_75t_R  g242(.A1(new_n310_), .A2(new_n326_), .B(new_n328_), .Y(new_n329_));
  AO21x1_ASAP7_75t_R  g243(.A1(new_n118_), .A2(new_n329_), .B(new_n327_), .Y(new_n330_));
  AO21x1_ASAP7_75t_R  g244(.A1(new_n318_), .A2(new_n324_), .B(new_n317_), .Y(new_n331_));
  AND2x2_ASAP7_75t_R  g245(.A(new_n311_), .B(new_n331_), .Y(new_n332_));
  AO21x1_ASAP7_75t_R  g246(.A1(new_n310_), .A2(new_n324_), .B(new_n332_), .Y(new_n333_));
  NAND2x1_ASAP7_75t_R g247(.A(G47), .B(new_n333_), .Y(new_n334_));
  AOI21x1_ASAP7_75t_R g248(.A1(new_n310_), .A2(new_n331_), .B(new_n311_), .Y(new_n335_));
  OA21x2_ASAP7_75t_R  g249(.A1(G47), .A2(new_n335_), .B(new_n334_), .Y(new_n336_));
  NOR2x1_ASAP7_75t_R  g250(.A(G46), .B(new_n336_), .Y(new_n337_));
  AO21x1_ASAP7_75t_R  g251(.A1(G46), .A2(new_n330_), .B(new_n337_), .Y(new_n338_));
  INVx1_ASAP7_75t_R   g252(.A(new_n338_), .Y(new_n339_));
  AND3x1_ASAP7_75t_R  g253(.A(new_n122_), .B(new_n123_), .C(new_n338_), .Y(new_n340_));
  AO21x1_ASAP7_75t_R  g254(.A1(new_n123_), .A2(new_n339_), .B(new_n340_), .Y(new_n341_));
  AO21x1_ASAP7_75t_R  g255(.A1(new_n122_), .A2(new_n339_), .B(new_n338_), .Y(new_n342_));
  AND2x2_ASAP7_75t_R  g256(.A(new_n291_), .B(new_n342_), .Y(new_n343_));
  AO21x1_ASAP7_75t_R  g257(.A1(new_n290_), .A2(new_n341_), .B(new_n343_), .Y(new_n344_));
  NAND2x1_ASAP7_75t_R g258(.A(G45), .B(new_n344_), .Y(new_n345_));
  AND2x2_ASAP7_75t_R  g259(.A(new_n291_), .B(new_n341_), .Y(new_n346_));
  AOI21x1_ASAP7_75t_R g260(.A1(new_n290_), .A2(new_n342_), .B(new_n346_), .Y(new_n347_));
  OA21x2_ASAP7_75t_R  g261(.A1(G45), .A2(new_n347_), .B(new_n345_), .Y(new_n348_));
  NOR2x1_ASAP7_75t_R  g262(.A(new_n301_), .B(new_n348_), .Y(G873));
  OR3x1_ASAP7_75t_R   g263(.A(G52), .B(new_n254_), .C(new_n325_), .Y(new_n350_));
  OR2x4_ASAP7_75t_R   g264(.A(G53), .B(G54), .Y(new_n351_));
  OR3x1_ASAP7_75t_R   g265(.A(new_n254_), .B(new_n351_), .C(new_n324_), .Y(new_n352_));
  AO21x1_ASAP7_75t_R  g266(.A1(new_n350_), .A2(new_n352_), .B(new_n117_), .Y(new_n353_));
  OR3x1_ASAP7_75t_R   g267(.A(G52), .B(G54), .C(new_n324_), .Y(new_n354_));
  AO21x1_ASAP7_75t_R  g268(.A1(new_n325_), .A2(new_n354_), .B(G46), .Y(new_n355_));
  AND3x1_ASAP7_75t_R  g269(.A(new_n311_), .B(new_n317_), .C(G47), .Y(new_n356_));
  AO21x1_ASAP7_75t_R  g270(.A1(new_n310_), .A2(new_n317_), .B(new_n311_), .Y(new_n357_));
  AO21x1_ASAP7_75t_R  g271(.A1(new_n118_), .A2(new_n357_), .B(new_n356_), .Y(new_n358_));
  AO21x1_ASAP7_75t_R  g272(.A1(new_n311_), .A2(new_n318_), .B(new_n310_), .Y(new_n359_));
  AND3x1_ASAP7_75t_R  g273(.A(new_n310_), .B(new_n318_), .C(new_n118_), .Y(new_n360_));
  AO21x1_ASAP7_75t_R  g274(.A1(G47), .A2(new_n359_), .B(new_n360_), .Y(new_n361_));
  AND2x2_ASAP7_75t_R  g275(.A(new_n325_), .B(new_n361_), .Y(new_n362_));
  AO21x1_ASAP7_75t_R  g276(.A1(new_n324_), .A2(new_n358_), .B(new_n362_), .Y(new_n363_));
  AND2x2_ASAP7_75t_R  g277(.A(new_n325_), .B(new_n358_), .Y(new_n364_));
  AOI21x1_ASAP7_75t_R g278(.A1(new_n324_), .A2(new_n361_), .B(new_n364_), .Y(new_n365_));
  NOR2x1_ASAP7_75t_R  g279(.A(G46), .B(new_n365_), .Y(new_n366_));
  AO21x1_ASAP7_75t_R  g280(.A1(G46), .A2(new_n363_), .B(new_n366_), .Y(new_n367_));
  OR3x1_ASAP7_75t_R   g281(.A(G28), .B(G56), .C(new_n125_), .Y(new_n368_));
  OAI21x1_ASAP7_75t_R g282(.A1(G28), .A2(G55), .B(new_n368_), .Y(new_n369_));
  NAND2x1_ASAP7_75t_R g283(.A(G50), .B(new_n369_), .Y(new_n370_));
  OA21x2_ASAP7_75t_R  g284(.A1(new_n125_), .A2(G56), .B(G55), .Y(new_n371_));
  OA21x2_ASAP7_75t_R  g285(.A1(G50), .A2(new_n371_), .B(new_n370_), .Y(new_n372_));
  AO21x1_ASAP7_75t_R  g286(.A1(G51), .A2(new_n367_), .B(new_n372_), .Y(new_n373_));
  AOI21x1_ASAP7_75t_R g287(.A1(new_n353_), .A2(new_n355_), .B(new_n373_), .Y(G874));
  AO21x1_ASAP7_75t_R  g288(.A1(new_n125_), .A2(G57), .B(new_n126_), .Y(new_n375_));
  AND3x1_ASAP7_75t_R  g289(.A(new_n102_), .B(new_n375_), .C(G50), .Y(new_n376_));
  AO21x1_ASAP7_75t_R  g290(.A1(new_n121_), .A2(new_n375_), .B(new_n376_), .Y(new_n377_));
  AND3x1_ASAP7_75t_R  g291(.A(new_n255_), .B(new_n377_), .C(G47), .Y(new_n378_));
  AOI21x1_ASAP7_75t_R g292(.A1(new_n118_), .A2(new_n377_), .B(new_n378_), .Y(new_n379_));
  NOR2x1_ASAP7_75t_R  g293(.A(new_n317_), .B(new_n351_), .Y(new_n380_));
  AO21x1_ASAP7_75t_R  g294(.A1(new_n123_), .A2(new_n317_), .B(new_n380_), .Y(new_n381_));
  OR3x1_ASAP7_75t_R   g295(.A(G52), .B(G54), .C(new_n317_), .Y(new_n382_));
  AOI21x1_ASAP7_75t_R g296(.A1(new_n318_), .A2(new_n382_), .B(G47), .Y(new_n383_));
  AOI21x1_ASAP7_75t_R g297(.A1(G47), .A2(new_n381_), .B(new_n383_), .Y(new_n384_));
  AO21x1_ASAP7_75t_R  g298(.A1(new_n122_), .A2(new_n318_), .B(new_n317_), .Y(new_n385_));
  AO21x1_ASAP7_75t_R  g299(.A1(new_n122_), .A2(new_n317_), .B(new_n318_), .Y(new_n386_));
  AND2x2_ASAP7_75t_R  g300(.A(new_n311_), .B(new_n386_), .Y(new_n387_));
  AO21x1_ASAP7_75t_R  g301(.A1(new_n310_), .A2(new_n385_), .B(new_n387_), .Y(new_n388_));
  NAND2x1_ASAP7_75t_R g302(.A(G47), .B(new_n388_), .Y(new_n389_));
  AND2x2_ASAP7_75t_R  g303(.A(new_n311_), .B(new_n385_), .Y(new_n390_));
  AOI21x1_ASAP7_75t_R g304(.A1(new_n310_), .A2(new_n386_), .B(new_n390_), .Y(new_n391_));
  OA21x2_ASAP7_75t_R  g305(.A1(G47), .A2(new_n391_), .B(new_n389_), .Y(new_n392_));
  OR3x1_ASAP7_75t_R   g306(.A(new_n379_), .B(new_n384_), .C(new_n392_), .Y(new_n393_));
  INVx1_ASAP7_75t_R   g307(.A(new_n393_), .Y(G875));
  AO21x1_ASAP7_75t_R  g308(.A1(new_n317_), .A2(new_n325_), .B(new_n318_), .Y(new_n395_));
  AO21x1_ASAP7_75t_R  g309(.A1(new_n311_), .A2(new_n395_), .B(new_n310_), .Y(new_n396_));
  NAND2x1_ASAP7_75t_R g310(.A(new_n310_), .B(new_n395_), .Y(new_n397_));
  OA21x2_ASAP7_75t_R  g311(.A1(new_n310_), .A2(new_n324_), .B(new_n397_), .Y(new_n398_));
  NOR2x1_ASAP7_75t_R  g312(.A(G47), .B(new_n398_), .Y(new_n399_));
  AO21x1_ASAP7_75t_R  g313(.A1(G47), .A2(new_n396_), .B(new_n399_), .Y(new_n400_));
  NAND2x1_ASAP7_75t_R g314(.A(G46), .B(new_n400_), .Y(new_n401_));
  AND3x1_ASAP7_75t_R  g315(.A(new_n318_), .B(new_n325_), .C(new_n311_), .Y(new_n402_));
  AO21x1_ASAP7_75t_R  g316(.A1(new_n310_), .A2(new_n325_), .B(new_n402_), .Y(new_n403_));
  NAND2x1_ASAP7_75t_R g317(.A(G47), .B(new_n403_), .Y(new_n404_));
  OR3x1_ASAP7_75t_R   g318(.A(new_n317_), .B(new_n324_), .C(new_n311_), .Y(new_n405_));
  OA21x2_ASAP7_75t_R  g319(.A1(G47), .A2(new_n405_), .B(new_n404_), .Y(new_n406_));
  OA21x2_ASAP7_75t_R  g320(.A1(G46), .A2(new_n406_), .B(new_n401_), .Y(new_n407_));
  NOR2x1_ASAP7_75t_R  g321(.A(new_n292_), .B(new_n407_), .Y(new_n408_));
  AND3x1_ASAP7_75t_R  g322(.A(new_n111_), .B(G9), .C(G5), .Y(new_n409_));
  AND3x1_ASAP7_75t_R  g323(.A(G5), .B(G9), .C(new_n89_), .Y(new_n410_));
  AOI21x1_ASAP7_75t_R g324(.A1(G11), .A2(new_n409_), .B(new_n410_), .Y(new_n411_));
  OR3x1_ASAP7_75t_R   g325(.A(new_n87_), .B(new_n411_), .C(new_n88_), .Y(new_n412_));
  INVx1_ASAP7_75t_R   g326(.A(new_n412_), .Y(new_n413_));
  OAI21x1_ASAP7_75t_R g327(.A1(new_n106_), .A2(G38), .B(G34), .Y(new_n414_));
  AND3x1_ASAP7_75t_R  g328(.A(new_n109_), .B(new_n414_), .C(new_n413_), .Y(new_n415_));
  AO21x1_ASAP7_75t_R  g329(.A1(new_n412_), .A2(new_n414_), .B(new_n415_), .Y(new_n416_));
  AND3x1_ASAP7_75t_R  g330(.A(new_n248_), .B(new_n416_), .C(G27), .Y(new_n417_));
  AOI21x1_ASAP7_75t_R g331(.A1(new_n100_), .A2(new_n416_), .B(new_n417_), .Y(new_n418_));
  NOR2x1_ASAP7_75t_R  g332(.A(new_n110_), .B(new_n230_), .Y(new_n419_));
  NOR2x1_ASAP7_75t_R  g333(.A(new_n418_), .B(new_n419_), .Y(new_n420_));
  INVx1_ASAP7_75t_R   g334(.A(new_n420_), .Y(new_n421_));
  AO21x1_ASAP7_75t_R  g335(.A1(G37), .A2(new_n412_), .B(new_n108_), .Y(new_n422_));
  AND3x1_ASAP7_75t_R  g336(.A(new_n106_), .B(new_n422_), .C(G4), .Y(new_n423_));
  AO21x1_ASAP7_75t_R  g337(.A1(new_n110_), .A2(new_n422_), .B(new_n423_), .Y(new_n424_));
  AND3x1_ASAP7_75t_R  g338(.A(new_n248_), .B(new_n424_), .C(G26), .Y(new_n425_));
  AO21x1_ASAP7_75t_R  g339(.A1(new_n99_), .A2(new_n424_), .B(new_n425_), .Y(new_n426_));
  INVx1_ASAP7_75t_R   g340(.A(new_n426_), .Y(new_n427_));
  NOR2x1_ASAP7_75t_R  g341(.A(new_n419_), .B(new_n427_), .Y(new_n428_));
  INVx1_ASAP7_75t_R   g342(.A(new_n428_), .Y(new_n429_));
  AO21x1_ASAP7_75t_R  g343(.A1(new_n420_), .A2(new_n429_), .B(new_n421_), .Y(new_n430_));
  AO21x1_ASAP7_75t_R  g344(.A1(new_n115_), .A2(new_n430_), .B(G44), .Y(new_n431_));
  AND3x1_ASAP7_75t_R  g345(.A(new_n421_), .B(new_n429_), .C(new_n115_), .Y(new_n432_));
  AO21x1_ASAP7_75t_R  g346(.A1(G44), .A2(new_n429_), .B(new_n432_), .Y(new_n433_));
  AND2x2_ASAP7_75t_R  g347(.A(new_n114_), .B(new_n433_), .Y(new_n434_));
  AO21x1_ASAP7_75t_R  g348(.A1(G43), .A2(new_n431_), .B(new_n434_), .Y(new_n435_));
  OR3x1_ASAP7_75t_R   g349(.A(new_n107_), .B(new_n282_), .C(new_n231_), .Y(new_n436_));
  AOI21x1_ASAP7_75t_R g350(.A1(new_n232_), .A2(new_n436_), .B(new_n249_), .Y(new_n437_));
  AO21x1_ASAP7_75t_R  g351(.A1(new_n101_), .A2(new_n283_), .B(G28), .Y(new_n438_));
  NOR2x1_ASAP7_75t_R  g352(.A(new_n101_), .B(G35), .Y(new_n439_));
  AO21x1_ASAP7_75t_R  g353(.A1(G35), .A2(new_n438_), .B(new_n439_), .Y(new_n440_));
  AO21x1_ASAP7_75t_R  g354(.A1(new_n232_), .A2(new_n440_), .B(new_n231_), .Y(new_n441_));
  AOI21x1_ASAP7_75t_R g355(.A1(new_n249_), .A2(new_n441_), .B(new_n437_), .Y(new_n442_));
  NOR2x1_ASAP7_75t_R  g356(.A(new_n116_), .B(new_n442_), .Y(new_n443_));
  NAND2x1_ASAP7_75t_R g357(.A(new_n435_), .B(new_n443_), .Y(new_n444_));
  NOR2x1_ASAP7_75t_R  g358(.A(G44), .B(new_n428_), .Y(new_n445_));
  AO21x1_ASAP7_75t_R  g359(.A1(G44), .A2(new_n430_), .B(new_n445_), .Y(new_n446_));
  NAND2x1_ASAP7_75t_R g360(.A(G43), .B(new_n446_), .Y(new_n447_));
  OR3x1_ASAP7_75t_R   g361(.A(new_n420_), .B(new_n428_), .C(new_n115_), .Y(new_n448_));
  OA21x2_ASAP7_75t_R  g362(.A1(G43), .A2(new_n448_), .B(new_n447_), .Y(new_n449_));
  OA21x2_ASAP7_75t_R  g363(.A1(new_n443_), .A2(new_n449_), .B(new_n444_), .Y(new_n450_));
  NOR2x1_ASAP7_75t_R  g364(.A(new_n408_), .B(new_n450_), .Y(new_n451_));
  AO21x1_ASAP7_75t_R  g365(.A1(new_n408_), .A2(new_n435_), .B(new_n451_), .Y(new_n452_));
  INVx1_ASAP7_75t_R   g366(.A(new_n452_), .Y(new_n453_));
  OAI21x1_ASAP7_75t_R g367(.A1(G36), .A2(new_n412_), .B(new_n413_), .Y(new_n454_));
  AND3x1_ASAP7_75t_R  g368(.A(new_n106_), .B(new_n454_), .C(G9), .Y(new_n455_));
  AO21x1_ASAP7_75t_R  g369(.A1(new_n131_), .A2(new_n454_), .B(new_n455_), .Y(new_n456_));
  AND3x1_ASAP7_75t_R  g370(.A(new_n248_), .B(new_n456_), .C(G25), .Y(new_n457_));
  AOI21x1_ASAP7_75t_R g371(.A1(new_n98_), .A2(new_n456_), .B(new_n457_), .Y(new_n458_));
  NOR2x1_ASAP7_75t_R  g372(.A(new_n419_), .B(new_n458_), .Y(new_n459_));
  INVx1_ASAP7_75t_R   g373(.A(new_n459_), .Y(new_n460_));
  AO21x1_ASAP7_75t_R  g374(.A1(new_n107_), .A2(new_n413_), .B(new_n412_), .Y(new_n461_));
  AND3x1_ASAP7_75t_R  g375(.A(new_n106_), .B(new_n461_), .C(G2), .Y(new_n462_));
  AOI21x1_ASAP7_75t_R g376(.A1(new_n94_), .A2(new_n461_), .B(new_n462_), .Y(new_n463_));
  NOR2x1_ASAP7_75t_R  g377(.A(new_n419_), .B(new_n463_), .Y(new_n464_));
  AO21x1_ASAP7_75t_R  g378(.A1(new_n97_), .A2(new_n249_), .B(new_n248_), .Y(new_n465_));
  NAND2x1_ASAP7_75t_R g379(.A(new_n464_), .B(new_n465_), .Y(new_n466_));
  INVx1_ASAP7_75t_R   g380(.A(new_n466_), .Y(new_n467_));
  OR3x1_ASAP7_75t_R   g381(.A(new_n460_), .B(new_n466_), .C(new_n452_), .Y(new_n468_));
  NOR2x1_ASAP7_75t_R  g382(.A(new_n113_), .B(new_n468_), .Y(new_n469_));
  AND3x1_ASAP7_75t_R  g383(.A(new_n459_), .B(new_n467_), .C(new_n452_), .Y(new_n470_));
  AO21x1_ASAP7_75t_R  g384(.A1(new_n453_), .A2(new_n467_), .B(new_n470_), .Y(new_n471_));
  AO21x1_ASAP7_75t_R  g385(.A1(new_n113_), .A2(new_n471_), .B(new_n469_), .Y(new_n472_));
  AO21x1_ASAP7_75t_R  g386(.A1(new_n460_), .A2(new_n467_), .B(new_n459_), .Y(new_n473_));
  AND2x2_ASAP7_75t_R  g387(.A(new_n453_), .B(new_n473_), .Y(new_n474_));
  AO21x1_ASAP7_75t_R  g388(.A1(new_n452_), .A2(new_n467_), .B(new_n474_), .Y(new_n475_));
  NAND2x1_ASAP7_75t_R g389(.A(G42), .B(new_n475_), .Y(new_n476_));
  AOI21x1_ASAP7_75t_R g390(.A1(new_n452_), .A2(new_n473_), .B(new_n453_), .Y(new_n477_));
  OA21x2_ASAP7_75t_R  g391(.A1(G42), .A2(new_n477_), .B(new_n476_), .Y(new_n478_));
  NOR2x1_ASAP7_75t_R  g392(.A(G41), .B(new_n478_), .Y(new_n479_));
  AO21x1_ASAP7_75t_R  g393(.A1(G41), .A2(new_n472_), .B(new_n479_), .Y(G876));
  OR3x1_ASAP7_75t_R   g394(.A(G52), .B(new_n254_), .C(new_n421_), .Y(new_n481_));
  OR3x1_ASAP7_75t_R   g395(.A(G53), .B(new_n254_), .C(new_n420_), .Y(new_n482_));
  AOI21x1_ASAP7_75t_R g396(.A1(new_n481_), .A2(new_n482_), .B(new_n115_), .Y(new_n483_));
  AO21x1_ASAP7_75t_R  g397(.A1(new_n123_), .A2(new_n421_), .B(new_n420_), .Y(new_n484_));
  AOI21x1_ASAP7_75t_R g398(.A1(new_n115_), .A2(new_n484_), .B(new_n483_), .Y(new_n485_));
  AO21x1_ASAP7_75t_R  g399(.A1(G26), .A2(G50), .B(new_n485_), .Y(new_n486_));
  NOR2x1_ASAP7_75t_R  g400(.A(new_n408_), .B(new_n443_), .Y(new_n487_));
  INVx1_ASAP7_75t_R   g401(.A(new_n487_), .Y(new_n488_));
  AO21x1_ASAP7_75t_R  g402(.A1(new_n122_), .A2(new_n487_), .B(new_n488_), .Y(new_n489_));
  AND2x2_ASAP7_75t_R  g403(.A(G44), .B(new_n489_), .Y(new_n490_));
  AO21x1_ASAP7_75t_R  g404(.A1(new_n122_), .A2(new_n488_), .B(new_n487_), .Y(new_n491_));
  NAND2x1_ASAP7_75t_R g405(.A(new_n115_), .B(new_n491_), .Y(new_n492_));
  INVx1_ASAP7_75t_R   g406(.A(new_n492_), .Y(new_n493_));
  OA21x2_ASAP7_75t_R  g407(.A1(new_n490_), .A2(new_n493_), .B(new_n420_), .Y(new_n494_));
  AND3x1_ASAP7_75t_R  g408(.A(new_n122_), .B(new_n124_), .C(new_n488_), .Y(new_n495_));
  AO21x1_ASAP7_75t_R  g409(.A1(new_n124_), .A2(new_n487_), .B(new_n495_), .Y(new_n496_));
  AND3x1_ASAP7_75t_R  g410(.A(new_n122_), .B(new_n124_), .C(new_n487_), .Y(new_n497_));
  AO21x1_ASAP7_75t_R  g411(.A1(new_n124_), .A2(new_n488_), .B(new_n497_), .Y(new_n498_));
  AND2x2_ASAP7_75t_R  g412(.A(new_n115_), .B(new_n498_), .Y(new_n499_));
  AO21x1_ASAP7_75t_R  g413(.A1(G44), .A2(new_n496_), .B(new_n499_), .Y(new_n500_));
  AOI21x1_ASAP7_75t_R g414(.A1(new_n421_), .A2(new_n500_), .B(new_n494_), .Y(new_n501_));
  NOR2x1_ASAP7_75t_R  g415(.A(new_n486_), .B(new_n501_), .Y(G877));
  OAI21x1_ASAP7_75t_R g416(.A1(new_n121_), .A2(G60), .B(G50), .Y(new_n503_));
  AND3x1_ASAP7_75t_R  g417(.A(new_n255_), .B(new_n503_), .C(G41), .Y(new_n504_));
  AOI21x1_ASAP7_75t_R g418(.A1(new_n112_), .A2(new_n503_), .B(new_n504_), .Y(new_n505_));
  AO21x1_ASAP7_75t_R  g419(.A1(G54), .A2(new_n465_), .B(new_n124_), .Y(new_n506_));
  NAND2x1_ASAP7_75t_R g420(.A(new_n464_), .B(new_n506_), .Y(new_n507_));
  OA21x2_ASAP7_75t_R  g421(.A1(G54), .A2(new_n464_), .B(new_n507_), .Y(new_n508_));
  NOR2x1_ASAP7_75t_R  g422(.A(G53), .B(new_n467_), .Y(new_n509_));
  AO21x1_ASAP7_75t_R  g423(.A1(new_n123_), .A2(new_n467_), .B(new_n509_), .Y(new_n510_));
  NAND2x1_ASAP7_75t_R g424(.A(G41), .B(new_n510_), .Y(new_n511_));
  OA21x2_ASAP7_75t_R  g425(.A1(G52), .A2(new_n467_), .B(new_n466_), .Y(new_n512_));
  OA21x2_ASAP7_75t_R  g426(.A1(G41), .A2(new_n512_), .B(new_n511_), .Y(new_n513_));
  OR3x1_ASAP7_75t_R   g427(.A(new_n505_), .B(new_n508_), .C(new_n513_), .Y(new_n514_));
  AND3x1_ASAP7_75t_R  g428(.A(new_n97_), .B(new_n464_), .C(new_n249_), .Y(new_n515_));
  AO21x1_ASAP7_75t_R  g429(.A1(new_n248_), .A2(new_n464_), .B(new_n515_), .Y(new_n516_));
  NOR2x1_ASAP7_75t_R  g430(.A(new_n249_), .B(new_n464_), .Y(new_n517_));
  OA21x2_ASAP7_75t_R  g431(.A1(G24), .A2(new_n464_), .B(new_n97_), .Y(new_n518_));
  NOR2x1_ASAP7_75t_R  g432(.A(new_n248_), .B(new_n518_), .Y(new_n519_));
  OA21x2_ASAP7_75t_R  g433(.A1(new_n517_), .A2(new_n519_), .B(new_n112_), .Y(new_n520_));
  AO21x1_ASAP7_75t_R  g434(.A1(G41), .A2(new_n516_), .B(new_n520_), .Y(new_n521_));
  AO21x1_ASAP7_75t_R  g435(.A1(new_n122_), .A2(new_n453_), .B(new_n452_), .Y(new_n522_));
  INVx1_ASAP7_75t_R   g436(.A(new_n522_), .Y(new_n523_));
  NOR2x1_ASAP7_75t_R  g437(.A(new_n113_), .B(new_n523_), .Y(new_n524_));
  AO21x1_ASAP7_75t_R  g438(.A1(new_n113_), .A2(new_n122_), .B(new_n524_), .Y(new_n525_));
  AO21x1_ASAP7_75t_R  g439(.A1(new_n113_), .A2(new_n522_), .B(G42), .Y(new_n526_));
  AND2x2_ASAP7_75t_R  g440(.A(new_n460_), .B(new_n526_), .Y(new_n527_));
  AO21x1_ASAP7_75t_R  g441(.A1(new_n459_), .A2(new_n525_), .B(new_n527_), .Y(new_n528_));
  NAND2x1_ASAP7_75t_R g442(.A(new_n521_), .B(new_n528_), .Y(new_n529_));
  AO21x1_ASAP7_75t_R  g443(.A1(new_n122_), .A2(new_n452_), .B(new_n453_), .Y(new_n530_));
  INVx1_ASAP7_75t_R   g444(.A(new_n530_), .Y(new_n531_));
  AO21x1_ASAP7_75t_R  g445(.A1(G42), .A2(new_n530_), .B(new_n113_), .Y(new_n532_));
  NOR2x1_ASAP7_75t_R  g446(.A(G42), .B(new_n531_), .Y(new_n533_));
  AO21x1_ASAP7_75t_R  g447(.A1(G42), .A2(new_n122_), .B(new_n533_), .Y(new_n534_));
  AND2x2_ASAP7_75t_R  g448(.A(new_n460_), .B(new_n534_), .Y(new_n535_));
  AOI21x1_ASAP7_75t_R g449(.A1(new_n459_), .A2(new_n532_), .B(new_n535_), .Y(new_n536_));
  OA21x2_ASAP7_75t_R  g450(.A1(new_n521_), .A2(new_n536_), .B(new_n529_), .Y(new_n537_));
  NOR2x1_ASAP7_75t_R  g451(.A(new_n514_), .B(new_n537_), .Y(G878));
  AO21x1_ASAP7_75t_R  g452(.A1(new_n97_), .A2(G50), .B(new_n121_), .Y(new_n539_));
  AND3x1_ASAP7_75t_R  g453(.A(new_n255_), .B(new_n539_), .C(G42), .Y(new_n540_));
  AOI21x1_ASAP7_75t_R g454(.A1(new_n113_), .A2(new_n539_), .B(new_n540_), .Y(new_n541_));
  NOR2x1_ASAP7_75t_R  g455(.A(new_n351_), .B(new_n459_), .Y(new_n542_));
  AO21x1_ASAP7_75t_R  g456(.A1(new_n123_), .A2(new_n459_), .B(new_n542_), .Y(new_n543_));
  OR3x1_ASAP7_75t_R   g457(.A(G52), .B(G54), .C(new_n459_), .Y(new_n544_));
  AOI21x1_ASAP7_75t_R g458(.A1(new_n460_), .A2(new_n544_), .B(G42), .Y(new_n545_));
  AOI21x1_ASAP7_75t_R g459(.A1(G42), .A2(new_n543_), .B(new_n545_), .Y(new_n546_));
  NOR2x1_ASAP7_75t_R  g460(.A(new_n459_), .B(new_n531_), .Y(new_n547_));
  AO21x1_ASAP7_75t_R  g461(.A1(new_n459_), .A2(new_n522_), .B(new_n547_), .Y(new_n548_));
  NOR2x1_ASAP7_75t_R  g462(.A(new_n459_), .B(new_n523_), .Y(new_n549_));
  AO21x1_ASAP7_75t_R  g463(.A1(new_n459_), .A2(new_n530_), .B(new_n549_), .Y(new_n550_));
  AND2x2_ASAP7_75t_R  g464(.A(new_n113_), .B(new_n550_), .Y(new_n551_));
  AOI21x1_ASAP7_75t_R g465(.A1(G42), .A2(new_n548_), .B(new_n551_), .Y(new_n552_));
  OR3x1_ASAP7_75t_R   g466(.A(new_n541_), .B(new_n546_), .C(new_n552_), .Y(new_n553_));
  INVx1_ASAP7_75t_R   g467(.A(new_n553_), .Y(G879));
  AO21x1_ASAP7_75t_R  g468(.A1(G25), .A2(new_n121_), .B(new_n98_), .Y(new_n555_));
  AND3x1_ASAP7_75t_R  g469(.A(new_n255_), .B(new_n555_), .C(G43), .Y(new_n556_));
  AOI21x1_ASAP7_75t_R g470(.A1(new_n114_), .A2(new_n555_), .B(new_n556_), .Y(new_n557_));
  NOR2x1_ASAP7_75t_R  g471(.A(new_n351_), .B(new_n428_), .Y(new_n558_));
  AO21x1_ASAP7_75t_R  g472(.A1(new_n123_), .A2(new_n428_), .B(new_n558_), .Y(new_n559_));
  OR3x1_ASAP7_75t_R   g473(.A(G52), .B(G54), .C(new_n428_), .Y(new_n560_));
  AOI21x1_ASAP7_75t_R g474(.A1(new_n429_), .A2(new_n560_), .B(G43), .Y(new_n561_));
  AOI21x1_ASAP7_75t_R g475(.A1(G43), .A2(new_n559_), .B(new_n561_), .Y(new_n562_));
  AOI21x1_ASAP7_75t_R g476(.A1(new_n419_), .A2(new_n426_), .B(new_n427_), .Y(new_n563_));
  NOR2x1_ASAP7_75t_R  g477(.A(G43), .B(new_n563_), .Y(new_n564_));
  AO21x1_ASAP7_75t_R  g478(.A1(G43), .A2(new_n428_), .B(new_n564_), .Y(new_n565_));
  AO21x1_ASAP7_75t_R  g479(.A1(new_n115_), .A2(new_n122_), .B(new_n490_), .Y(new_n566_));
  AO21x1_ASAP7_75t_R  g480(.A1(new_n115_), .A2(new_n489_), .B(G44), .Y(new_n567_));
  AND2x2_ASAP7_75t_R  g481(.A(new_n421_), .B(new_n567_), .Y(new_n568_));
  AO21x1_ASAP7_75t_R  g482(.A1(new_n420_), .A2(new_n566_), .B(new_n568_), .Y(new_n569_));
  NAND2x1_ASAP7_75t_R g483(.A(new_n565_), .B(new_n569_), .Y(new_n570_));
  NAND2x1_ASAP7_75t_R g484(.A(G44), .B(new_n491_), .Y(new_n571_));
  AO21x1_ASAP7_75t_R  g485(.A1(G44), .A2(new_n571_), .B(new_n421_), .Y(new_n572_));
  OA21x2_ASAP7_75t_R  g486(.A1(new_n115_), .A2(G51), .B(new_n492_), .Y(new_n573_));
  OA21x2_ASAP7_75t_R  g487(.A1(new_n420_), .A2(new_n573_), .B(new_n572_), .Y(new_n574_));
  OA21x2_ASAP7_75t_R  g488(.A1(new_n565_), .A2(new_n574_), .B(new_n570_), .Y(new_n575_));
  OR3x1_ASAP7_75t_R   g489(.A(new_n557_), .B(new_n562_), .C(new_n575_), .Y(new_n576_));
  INVx1_ASAP7_75t_R   g490(.A(new_n576_), .Y(G880));
endmodule


