(* techmap_celltype = "$lut" *) module lut_adapter(A,Y);
parameter WIDTH=1; parameter [2**WIDTH-1:0] LUT=0;
input [WIDTH-1:0] A; output Y; generate
if (WIDTH==1) begin LUT1 #(.INIT(LUT)) _TECHMAP_REPLACE_(.I0(A[0]),.O(Y)); end
if (WIDTH==2) begin LUT2 #(.INIT(LUT)) _TECHMAP_REPLACE_(.I0(A[0]),.I1(A[1]),.O(Y)); end
if (WIDTH==3) begin LUT3 #(.INIT(LUT)) _TECHMAP_REPLACE_(.I0(A[0]),.I1(A[1]),.I2(A[2]),.O(Y)); end
if (WIDTH==4) begin LUT4 #(.INIT(LUT)) _TECHMAP_REPLACE_(.I0(A[0]),.I1(A[1]),.I2(A[2]),.I3(A[3]),.O(Y)); end
if (WIDTH==5) begin LUT5 #(.INIT(LUT)) _TECHMAP_REPLACE_(.I0(A[0]),.I1(A[1]),.I2(A[2]),.I3(A[3]),.I4(A[4]),.O(Y)); end
if (WIDTH==6) begin LUT6 #(.INIT(LUT)) _TECHMAP_REPLACE_(.I0(A[0]),.I1(A[1]),.I2(A[2]),.I3(A[3]),.I4(A[4]),.I5(A[5]),.O(Y)); end
endgenerate endmodule
