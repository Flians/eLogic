# DA source-planning round: no new delay gain; no main promotion

The unchanged original baseline campaign already attempted all20EPFL designs, two restricted libraries and all original configurations:240groups/520status slots (372CEC,124reported failures,24unmeasured). This round reaudited13403original dependencies with zero drift. No baseline algorithm, model, native parameter or unsuccessful record was changed. All six full-scope DA/AD/Pareto gates remain false; AD is posthoc on DA covers, MtM unconnected.

## Fixed-version complete and repeated observations

V6 (`/tmp/emapper-library-source-plan-20261016`) performs exact library-aware TT3/TT4 source planning, bounded by the original inventory K3/K4 and global node/cut/pool/SAT/recovery/mapping limits. Planning is before one e-graph construction and inside native/mapping clocks. All operands/helpers/actual admitted functions count; no e-graph retirement or regional counter reset. The richer scalar function unit is not expanded-AND work units.93egraph-related tests pass in both debug and release, four ignored. Initial failed builds/tests and earlier adverse versions remain separately archived.

Full study:80fresh attempts,68direct original named-port CEC and12node failures; candidate34/40covers. Same-binary old-protected/candidate34common legal pairs: delay0better/34equal/0worse, area1better/33equal/0worse. Four-input multiplier2087.12->2086.32 at unchangedD2954.30 is the sole full-study gain.

Two alternating-order repetitions on eight predeclared targets (sqrt,multiplier,adder,bar,priority,int2float,sin,max) add64fresh attempts:63directCEC,one strict recovery failure. The control4in max r1 took2.004620s and remains failed; no partial incumbent, rerun replacement or extended deadline is used. This is NOT new large-design coverage. The96-observation target view includes32full observations and has47common legal pairs, all delay ties; area4better/43equal/0worse. Multiplier area-0.80 recurs in all3observations; priority area-0.27 appears only once. This is a target repeat study, not a repeat of all20designs.

Unique full+repeat totals:144native attempts,131directCEC,13failures. Their65common legal pairs have D0/65/0 and A4/61/0. Overlapping full/target summaries are not added. Every successful actual budget and artifact-hash audit passes; failures remain failures.

The production-main comparison is a separate observational check, not the same-binary causal contrast: V6 full4in priority area52.42 exceeds canonical main52.15; multiplier improves0.80, all other legal full-R0 metrics tie. Runtime sensitivity is not a reason to discard this regression. Therefore the main source, binary, defaults and four primary result tables are unchanged. The source planner is **not promoted**. The read-only checker's original generic any-metric field was misleadingly named promotion; initial outputs/source are retained and the field is now explicitly a full-study nonregression check. Actual production qualification is false in qualification.json; no algorithm or numerical gate threshold was altered.

## What limits sqrt now

Sqrt D remains63951.92/57161.09 (3in/4in),6.43%/21.50% above same-library emap. Added4in source expressions number2139TT4 nodes, yet retained cut sets (48966/108759), raw generated instances (367347/819195), physical pool fingerprints and selected physical instances are identical between profiles. More equivalent source expressions have not broadened retained physical choices.

Four-input selected critical paths: eGraphMap2613cells/512AO31 versus emap2077/1742. This reproduces public f32-pin/f64-path delay and all-instance area exactly, but does not prove candidate absence or a causal remedy. Among currently retained critical-signal producers neither inventory has a faster one-step estimate whose inputs all already have selected-cover arrivals. Alternative producers on2359/3309critical signals (3in) and1987/2614(4in) depend on unselected inputs. These are read-only estimates, not acyclic whole-cover trials or new PPA. Joint input-cone/phase recovery is a better-supported next hypothesis than adding duplicate source expressions.

## Remaining import failures

Candidate planned source-function upper counts are3in div20701/hyp111621/mem_ctrl28603 and4in20528/108117/25626. These are conservative source-plan estimates, not actual complete imports, lower bounds, mapped CEC or impossibility proofs. Every incomplete actual20000-node prefix fails before another distinct admission. Div is near the numeric allowance but has no validated bounded cover; hyp/mem_ctrl still require substantial representation/candidate work. Regional resident peaks cannot substitute for cumulative global accounting.

## Next experiments (not yet implemented)

1. Joint producer/input-cone and phase trials using already admitted bindings: graft finite witnesses, prune and check acyclicity, recompute whole-cover physical metrics, retain old shared-area and fast incumbents under one unchanged2s deadline. Preserve current proposal-order control for an isolated test; never relabel estimates as successful trials.
2. Audit actual-child operand canonicalization and full TT truth permutations before source admission/hash-consing, first on exact shared/phase fixtures, then on div. A source estimate reduction alone will not establish budget-feasible mapping; actual complete graph/cover/CEC is required.
3. For hyp/mem_ctrl, investigate globally shared exact function/phase factoring; do not reset budgets by region or count only residency. If no complete legal cover exists in an experiment, keep its failure.

Do not promote a new branch without fixed-profile full20/two-library evidence, repeated verification, canonical-main shared-area protection and the unchanged original baseline comparison. No best-run or per-design version mixture.

## Evidence and paper

`qualification.json`, `final_integrity.json`, `baseline_integrity.json`, `baseline_scope/`, `main_observation_comparison.json`, `failed_imports.json`, `failures.json`, `sqrt_retention.json`, `sqrt_paths.json`, `sqrt_critical_producers.json`; full and repeat raw campaigns/reports retain commands, hashes, diagnostics and all failures. Native sources/binaries/Cargo/patches are archived under library_source_plan_implementation_20261016 (V5 separately archived).

DAC text now distinguishes this negative source-planning study from the earlier validated main gains. Four primary EPFL tables remain byte-identical; standard font/margins unchanged. All7rendered pages were visually checked,6body+1references, no overflow or LaTeX warnings. Rejected8-page layout and a small-caps text-parser assertion failure are retained. Published output: output/pdf/DAC-eGraphMap-draft.pdf; QA: library_source_plan_paper_20261016/paper_qa.json. The overall delay/coverage task remains unfinished.
