"""Read-only retained producer estimates on selected critical path; not cover trials."""
import json,hashlib
from pathlib import Path
ROOT=Path('/home/flynn/workplace/MIGBalance');OUT=Path(__file__).resolve().parent
records=[]
for k in [3,4]:
 path=ROOT/f'results_v2/library_source_plan_full_20261016/{k}in_sqrt_protected_area/sqrt.egraph_staged_control_resyn2/candidate-diagnostics.json'
 d=json.loads(path.read_text());arr=d['arrivals'];counts=dict(critical_signals=len(d['critical_signals']),with_AO31=0,selected_AO31=0,faster_known_input_estimate=0,with_unselected_input=0);examples=[]
 for s in d['critical_signals']:
  ps=s['producers'];counts['with_AO31']+=any(p['cell'].startswith('AO31') for p in ps)
  sel=next((p for p in ps if s['selected']==[p['instance'],p['pin']]),None)
  counts['selected_AO31']+=bool(sel and sel['cell'].startswith('AO31'))
  unknown=False;faster=[]
  for p in ps:
   if any(arr[i] is None for i in p['inputs']):unknown=True;continue
   estimate=max((arr[i]+v for i,v in zip(p['inputs'],p['delays'])),default=0.)
   if estimate<s['arrival']-1e-5:faster.append(dict(cell=p['cell'],instance=p['instance'],pin=p['pin'],estimated_arrival=estimate))
  counts['with_unselected_input']+=unknown;counts['faster_known_input_estimate']+=bool(faster)
  if faster and len(examples)<12:examples.append(dict(signal=s['signal'],current_arrival=s['arrival'],estimates=faster))
 records.append(dict(k=k,counts=counts,examples=examples,source=str(path),sha256=hashlib.sha256(path.read_bytes()).hexdigest()))
result=dict(records=records,caution='Per-producer max-plus estimates use current selected-input arrivals only. Unselected input cones are unknown. No alternative was applied, no acyclicity/area check was performed, and these are not measured PPA or causal claims.')
(OUT/'sqrt_critical_producers.json').write_text(json.dumps(result,indent=2)+'\n')
for r in records:print(r['k'],r['counts'])
