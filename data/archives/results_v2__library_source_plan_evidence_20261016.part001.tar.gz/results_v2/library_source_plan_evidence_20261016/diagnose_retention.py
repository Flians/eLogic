"""Read-only source-to-physical retention comparison; no causal PPA claim."""
import json,hashlib
from pathlib import Path
ROOT=Path('/home/flynn/workplace/MIGBalance');OUT=Path(__file__).resolve().parent
load=lambda p:json.loads(Path(p).read_text())
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
c=load(ROOT/'results_v2/library_source_plan_full_20261016/campaign.json');jobs={j['name']:j for j in c['jobs']};records=[]
for k in [3,4]:
 old,new=[jobs[f'{k}in_sqrt_{p}'] for p in ['legacy_control','protected_area']]
 ds=[load(j['candidates']) for j in [old,new]]
 cuts=[{(x['class'],tuple(x['leaves']),x['function']) for x in d['cuts']} for d in ds]
 selected=[d['selected_instances'] for d in ds]
 r=dict(k=k,source_records=[dict(path=j['candidates'],sha256=sha(j['candidates'])) for j in [old,new]],
   cut_counts=[len(x) for x in cuts],new_cuts=len(cuts[1]-cuts[0]),removed_cuts=len(cuts[0]-cuts[1]),
   retained_pool_fingerprints=[d['retained_pool_fingerprint'] for d in ds],
   raw_generated_instances=[d['raw_generated_instances'] for d in ds],
   selected_physical_instances_identical=selected[0]==selected[1],
   tt4_enode_counts=[sum(x['nodes'].count('@egm_tt4_') for x in d['egraph_nodes']) for d in ds])
 records.append(r)
result=dict(records=records,interpretation='If cut sets and physical pools are identical, added source expressions have not broadened retained physical choices in this fixed setting. This does not prove a general candidate-absence cause or global optimality.',baseline_algorithms_changed=False)
(OUT/'sqrt_retention.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
