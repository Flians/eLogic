"""Read-only path reconstruction; no new mapping or candidate-causality claim."""
import sys,json,hashlib
from pathlib import Path
ROOT=Path('/home/flynn/workplace/MIGBalance');OUT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'scripts/experiments/campaigns'))
from analyze_delay_causes import reconstruct
load=lambda p:json.loads(p.read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
c=load(ROOT/'results_v2/cone_guard_full_20261015/campaign.json')
b=load(ROOT/'results_v2/epfl_original_baselines_resumed_checkpoint_20261013/campaign.json')
records=[]
for k in [3,4]:
 specimens=[]
 for label in ['legacy_control','protected_area']:
  j=next(j for j in c['jobs'] if j['k']==k and j['bench']=='sqrt' and j['profile']==label)
  p=Path(j['report']);r=load(p);row=r['results'][0];specimens.append((label,p,r,row))
 j=next(j for j in b['jobs'] if j['name']==f'{k}in_core_sqrt')
 p=Path(j['report']);r=load(p)
 for method in ['abc_map_delay_resyn2','mockturtle_emap_delay_resyn2']:
  row=next(x for x in r['results'] if x['method']==method);specimens.append((method,p,r,row))
 identities=set()
 for label,p,r,row in specimens:
  assert row['status']=='ok' and row['measured']['cec']==1
  identities.add((row['input_sha256'],row['preprocessing']['sha256'],r['library_sha256']))
  rec=reconstruct(p.parent/f'sqrt.{row["method"]}/mapped.json',p.parent/'library.json',row['measured'])
  rec.update(k=k,profile=label,report=str(p),report_sha256=sha(p));records.append(rec)
  print(k,label,rec['delay'],rec['critical_path_cells'],rec['critical_path_types'])
 assert len(identities)==1
(OUT/'validation.json').write_text(json.dumps(dict(records=records,reconstruction_errors=0,baseline_algorithms_changed=False,new_mapping_runs=0,limitation='Selected cover paths may end at different outputs. Cell counts and types describe retained paths, not proof of missing matches or causal changes.',script_sha256=sha(Path(__file__))),indent=2)+'\n')
