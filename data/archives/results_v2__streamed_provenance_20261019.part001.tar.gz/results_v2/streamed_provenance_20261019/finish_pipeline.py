import subprocess,sys,json
from pathlib import Path
R=Path('/home/flynn/workplace/MIGBalance');D=R/'scripts/experiments/campaigns';E=R/'results_v2/streamed_provenance_20261019';full=Path('/tmp/emapper-streamed-provenance-full-20261019');reps=[]
def run(argv):
 print('RUN',*[str(x)for x in argv],flush=True);subprocess.run([sys.executable,*map(str,argv)],cwd=R,check=True)
def check(p):
 run([D/'check_generation_frontier_mapping.py',p/'campaign.json']);run([D/'audit_generation_stages.py',p/'campaign.json'])
run([D/'run_streamed_provenance.py','--output',full,'--max-jobs','80']);check(full)
for i in range(3):
 p=Path('/tmp/emapper-streamed-provenance-repeat-r%d-20261019'%i);reps.append(p/'campaign.json');args=[D/'run_streamed_provenance.py','--output',p,'--designs','sqrt','sin','adder','--max-jobs','12']
 if i%2:args+=['--reverse-order']
 run(args);check(p)
run([D/'finalize_streamed_provenance.py',full/'campaign.json','--repeats',*reps,'--output',E/'evidence'])
(E/'finite_finished.json').write_text(json.dumps({'full':str(full),'repeats':list(map(str,reps)),'status':'finished'},indent=2))
