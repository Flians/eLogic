"""Real timed probes, with immutable original starts and no checkpoint fallback."""
import argparse,hashlib,json,os,re,subprocess,sys
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT/'scripts/experiments'))
from audit_mapped_ppa import audit
from report import read_counters
ap=argparse.ArgumentParser();ap.add_argument('--root',type=Path,default=Path('/tmp/epm-no-timeout-20261016'));ap.add_argument('--rounds',type=int);ap.add_argument('--pivots',type=int,default=2);ap.add_argument('--binary',type=Path,default=ROOT/'build/epmapping/epmapping_check');ap.add_argument('--bits',type=int,default=9);ap.add_argument('--designs',nargs='+',default=['usb_phy','div','sqrt','mem_ctrl']);ap.add_argument('--recipe',default='high_effort',choices=['direct','high_effort']);ap.add_argument('--modes',nargs='+',default=['cold','warm']);ap.add_argument('--jobs',type=int,default=3);a=ap.parse_args()
P=a.root / (f'pivots{a.pivots}' if a.pivots else '.');P=P/(f'rounds{a.rounds}' if a.rounds else '.');P.mkdir(parents=True,exist_ok=True);binary=a.binary;ref=ROOT/'results_v27_three_parts_build_reuse';stage='tab_mfs3' if a.recipe=='direct' else 'tab_main';arm='ours' if stage=='tab_mfs3' else 'ae';frozen=ref/'cold/inputs';lib=frozen/('asap7_6in.genlib' if stage=='tab_mfs3' else 'asap7.genlib');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def run(d):
 for mode in a.modes:
  wd=P/f'b{a.bits}.{a.recipe}.{mode}.{d}';result=wd/'result.json'
  if result.exists():
   assert json.loads((wd/'manifest.json').read_text())['binary_sha256']==sha(binary)
   print(result.read_text(),flush=True);continue
  wd.mkdir(exist_ok=True);old=ref/'cold'/stage/f'{arm}.{d}'
  options=dict(x.split('=',1) for x in (old/'experiment_env.txt').read_text().splitlines() if x.startswith(('EPMAPPING_','MAP_EGG_')))
  options.update(EPMAPPING_LIVE_QUERY_CACHE=str(a.bits),EPMAPPING_COFAC_PIVOTS=str(a.pivots))
  if a.rounds:options['EPMAPPING_ROUNDS']=str(a.rounds)
  cache=P/'cache'/f'b{a.bits}.{a.recipe}.{d}'
  if mode=='cold':assert not cache.exists()
  else:assert cache.exists()
  options['MAP_EGG_PROFILE_CACHE_DIR']=str(cache)
  env={k:v for k,v in os.environ.items() if not k.startswith(('EPMAPPING_','MAP_EGG_','EPM_'))};env.update(options,ABC=str(frozen/'abc'),RAYON_NUM_THREADS='1')
  command=[str(binary),str(lib),str(frozen/'benchmarks'/f'{d}.aig'),str(wd)]
  manifest=dict(command=command,env=options,binary_sha256=sha(binary),initial_reference_sha256=sha(old/'epmapping_baseline.v'))
  (wd/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
  with (wd/'log').open('w') as log:
   try:rc=subprocess.run(command,env=env,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,timeout=1800).returncode
   except subprocess.TimeoutExpired:rc=124
  text=(wd/'log').read_text();out=dict(bits=a.bits,recipe=a.recipe,mode=mode,design=d,rc=rc)
  if rc==0:
   assert '[i] cec=1' in text
   assert (wd/'epmapping_baseline.v').read_bytes()==(old/'epmapping_baseline.v').read_bytes()
   before=audit(wd/'epmapping_baseline.v',lib);after=audit(wd/'epmapping_mapped.v',lib)
   assert all(after[k]<=before[k]+.001 for k in ['area','delay','serialized_area','serialized_delay']),(d,before,after)
   counters=read_counters(str(wd/'log'));assert counters['time_optimizer']<=1000.01
   q=re.search(r'epmapping live_queries ([^\n]+)',text)
   out.update(initial=before,final=after,optimizer_seconds=counters['time_optimizer'],queries=q[1] if q else None,cec=1)
  result.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out),flush=True)
with ThreadPoolExecutor(max_workers=a.jobs) as pool:list(pool.map(run,a.designs))
