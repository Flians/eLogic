"""Verify the installed defaults without either new environment override."""
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys

project = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(project / 'scripts/experiments'))
from audit_mapped_ppa import audit
from report import read_counters

root = Path('/tmp/epm-no-timeout-20261016')
reference = root / 'pivots2/b9.high_effort.cold.usb_phy'
template = json.loads((reference / 'manifest.json').read_text())
binary = Path('/tmp/epm-no-timeout-build-default/epmapping_check')
cache = root / 'default_smoke_cache'
assert not cache.exists(), 'use a new smoke directory instead of relabeling an existing cache cold'
results = []
for mode in ['cold', 'warm']:
    wd = root / f'default_smoke_{mode}'
    wd.mkdir(exist_ok=True)
    options = dict(template['env'])
    options.pop('EPMAPPING_LIVE_QUERY_CACHE')
    options.pop('EPMAPPING_COFAC_PIVOTS')
    options['MAP_EGG_PROFILE_CACHE_DIR'] = str(cache)
    env = {k: v for k, v in os.environ.items() if not k.startswith(('EPMAPPING_', 'MAP_EGG_', 'EPM_'))}
    env.update(options, ABC=str(project / 'results_v27_three_parts_build_reuse/cold/inputs/abc'), RAYON_NUM_THREADS='1')
    command = [str(binary), *template['command'][1:3], str(wd)]
    manifest = dict(command=command, env=options, binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest())
    (wd / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
    with (wd / 'log').open('w') as output:
        subprocess.run(command, env=env, cwd=project, stdout=output, stderr=subprocess.STDOUT, check=True, timeout=1800)
    log = (wd / 'log').read_text()
    assert 'cofactor_pivots=2, live_query_memo=9' in log
    assert '[i] cec=1' in log
    assert (wd / 'epmapping_baseline.v').read_bytes() == (reference / 'epmapping_baseline.v').read_bytes()
    final = audit(wd / 'epmapping_mapped.v', command[1])
    expected = json.loads((reference / 'result.json').read_text())['final']
    assert final == expected
    results.append(dict(mode=mode, cec=1, rc=0, final=final,
                        optimizer_seconds=read_counters(str(wd / 'log'))['time_optimizer'],
                        binary_sha256=manifest['binary_sha256']))
Path(__file__).with_name('default_smoke.json').write_text(json.dumps(results, indent=2) + '\n')
print(json.dumps([{k: r[k] for k in ['mode', 'cec', 'rc', 'optimizer_seconds']} for r in results]))
