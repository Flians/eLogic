"""Completion gate over real timed runs; checkpoint selections never turn TO green."""
import csv,json,sys
from pathlib import Path
root=Path(sys.argv[1]);bad=[]
for mode in ['cold','warm']:
 for stage,arms in [('tab_mfs3',['ours']),('tab_main',['ae.r1','ae'])]:
  for r in csv.DictReader((root/mode/stage/'summary.tsv').open(),delimiter='\t'):
   if r['stage'] in arms and r['rc']!='0':bad.append((mode,stage,r['stage'],r['design'],r['rc']))
print(json.dumps(dict(incomplete=len(bad),runs=bad),indent=2));sys.exit(bool(bad))
