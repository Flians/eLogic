"""Build the report only after the native completion and quality gate passes."""
import argparse
import csv
import json
from pathlib import Path
import subprocess
import sys

ap = argparse.ArgumentParser()
ap.add_argument('--root', type=Path, required=True)
ap.add_argument('--bits', type=int, default=9)
ap.add_argument('--out', type=Path, required=True)
a = ap.parse_args()
gate = subprocess.run([sys.executable, str(Path(__file__).with_name('verify_method.py')),
                       '--root', str(a.root), '--bits', str(a.bits)],
                      capture_output=True, text=True, check=True)
summary = json.loads(gate.stdout)
rows = [json.loads(f.read_text()) for f in sorted(a.root.glob(f'b{a.bits}.*/*result.json'))]
assert len(rows) == 64 and all(r['rc'] == 0 for r in rows)
a.out.mkdir(parents=True, exist_ok=True)
(a.out / 'gate.json').write_text(gate.stdout)
with (a.out / 'results.tsv').open('w') as output:
    writer = csv.writer(output, delimiter='\t')
    writer.writerow(['recipe', 'mode', 'design', 'initial_area', 'initial_delay',
                     'final_area', 'final_delay', 'optimizer_seconds', 'rc', 'cec'])
    for r in rows:
        writer.writerow([r['recipe'], r['mode'], r['design'], r['initial']['area'],
                         r['initial']['delay'], r['final']['area'], r['final']['delay'],
                         r['optimizer_seconds'], r['rc'], r['cec']])

text = ['# ePMapping 原生完成与质量验证', '',
        '原始 AIG 与初始门级网表保持一致；整窗口综合关闭；post-mapping 原生限时仍为 1000 秒。',
        '所有 64 次运行正常退出并通过 CEC，以及独立的网表面积、引脚延迟检查。超时检查点不计作完成。', '',
        f'显式完整扫描上限：{summary["round_caps"]}；每种分解的 pivot 上限：{summary["cofactor_pivots"]}。', '',
        '这里验证两种初始映射下的完整方法，不代表全部消融配置都已重新执行。', '',
        '| 初始映射 | 缓存 | 正常完成 | 最大耗时 (s) | 平均面积下降 | 平均延迟下降 |',
        '|---|---|---:|---:|---:|---:|']
for recipe in ['direct', 'high_effort']:
    for mode in ['cold', 'warm']:
        g = summary[f'{mode}_{recipe}']
        text.append(f'| {recipe} | {mode} | {g["completed"]}/16 | {g["max_seconds"]:.2f} | '
                    f'{g["mean_area_reduction_percent"]:.3f}% | {g["mean_delay_reduction_percent"]:.3f}% |')
text += ['', '百分比使用每个电路相对自身初始网表的比值，再作算术平均；运行时间只计 post-mapping，包含准备与重建。', '',
         '## 与 mfs3 的同起点比较', '',
         '双方使用相同的 ≤6 输入子库和初始门级网表。沿用未修改的 v27 mfs3 原生 1000 秒运行：13 个正常完成，3 个超时。',
         '以下仅在这 13 个正常完成的电路上配对；超时 baseline 不用于声称单电路胜出。', '',
         '| 缓存 | 我们的平均归一化面积 | 延迟受限 mfs3 | 对原始 mfs3 面积的平均比值 | 原始面积胜/负/平 |',
         '|---|---:|---:|---:|---:|']
for mode in ['cold', 'warm']:
    wins = summary[f'{mode}_area_wins_vs_raw_mfs3']
    losses = summary[f'{mode}_area_losses_vs_raw_mfs3']
    text.append(f'| {mode} | {summary[mode+"_paired_area_ratio"]:.6f} | '
                f'{summary["baseline_guarded_area_ratio"]:.6f} | '
                f'{summary[mode+"_mean_area_ratio_to_raw_mfs3"]:.6f} | {wins}/{losses}/{13-wins-losses} |')
text += ['', '“延迟受限 mfs3”指其输出违反相同初始延迟或面积边界时保留初始网表；同时报告原始输出面积，避免只展示受限口径。',
         '优势是整体结果，不表示每个电路的面积都优于原始 mfs3 输出。ASPDAC’25 无源码，不将其论文数据当作相同起点的可执行 baseline。', '',
         '## 完整方法逐电路结果', '',
         '| 电路 | 初始面积 | 初始延迟 | 冷面积 | 冷延迟 | 冷耗时 (s) | 热面积 | 热延迟 | 热耗时 (s) |',
         '|---|---:|---:|---:|---:|---:|---:|---:|---:|']
main = {(r['mode'], r['design']): r for r in rows if r['recipe'] == 'high_effort'}
for d in sorted({r['design'] for r in rows}):
    c, w = main['cold', d], main['warm', d]
    text.append(f'| {d} | {c["initial"]["area"]:.2f} | {c["initial"]["delay"]:.2f} | '
                f'{c["final"]["area"]:.2f} | {c["final"]["delay"]:.2f} | {c["optimizer_seconds"]:.2f} | '
                f'{w["final"]["area"]:.2f} | {w["final"]["delay"]:.2f} | {w["optimizer_seconds"]:.2f} |')
text += ['', '详细数值见 results.tsv；门类型计数、序列化指标、环境变量、二进制和初始网表哈希保存在逐次运行记录中。',
         '本结果只支持当前 16 电路集合内的无 TO 结论，不作任意规模电路的最坏运行时间保证。', '']
(a.out / 'REPORT.md').write_text('\n'.join(text))
