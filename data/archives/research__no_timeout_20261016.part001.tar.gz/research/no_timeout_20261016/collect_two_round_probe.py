"""Collect one predetermined configuration, never the best result per circuit."""
import json
from pathlib import Path
import shutil

root = Path('/tmp/epm-no-timeout-20261016')
project = Path(__file__).resolve().parents[2]
designs = json.loads((project / 'results_v27_three_parts_build_reuse/cold/manifest.json').read_text())['designs']
target = root / 'selected'
target.mkdir(exist_ok=True)
provenance = {}
for recipe in ['direct', 'high_effort']:
    parent = root / 'pivots2'
    rounds = '1'
    if recipe == 'high_effort':
        parent /= 'rounds2'
        rounds = '2'
    for mode in ['cold', 'warm']:
        for d in designs:
            name = f'b9.{recipe}.{mode}.{d}'
            source = parent / name
            provenance[name] = str(source)
            if not (source / 'result.json').exists():
                continue
            env = json.loads((source / 'manifest.json').read_text())['env']
            assert env['EPMAPPING_LIVE_QUERY_CACHE'] == '9'
            assert env['EPMAPPING_COFAC_PIVOTS'] == '2'
            assert env['EPMAPPING_ROUNDS'] == rounds
            assert env['EPMAPPING_POST_TIMEOUT'] == '1000'
            if not (target / name).exists():
                shutil.copytree(source, target / name)
(target / 'selection.json').write_text(json.dumps(dict(
    policy='one fixed configuration; no per-circuit selection or checkpoint fallback',
    live_query_cache=9, cofactor_pivots=2, rounds=dict(direct=1, high_effort=2),
    post_mapping_timeout=1000, source_directories=provenance), indent=2) + '\n')
print(f'Collected {len(list(target.glob("b9.*/*result.json")))}/64 native results')
