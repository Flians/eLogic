from pathlib import Path
import subprocess,shlex
root=Path('/home/flynn/workplace/MIGBalance');dest=Path('/tmp/epm-no-timeout-build-default');dest.mkdir(exist_ok=True)
f=(root/'build/epmapping/CMakeFiles/epmapping_check.dir/flags.make').read_text().splitlines();v={line.split(' = ',1)[0]:line.split(' = ',1)[1] for line in f if ' = ' in line}
compiler='/home/flynn/miniconda3/bin/x86_64-conda-linux-gnu-c++'
args=[compiler]+sum([shlex.split(v[k]) for k in ['CXX_DEFINES','CXX_INCLUDES','CXX_FLAGS']],[])+['-c',str(root/'epmapping/main.cpp'),'-o',str(dest/'main.o')]
subprocess.run(args,cwd=root,check=True)
args=shlex.split((root/'build/epmapping/CMakeFiles/epmapping_check.dir/link.txt').read_text());args=[str(dest/'main.o') if x=='CMakeFiles/epmapping_check.dir/main.cpp.o' else str(dest/'epmapping_check') if x=='epmapping_check' else x for x in args]
subprocess.run(args,cwd=root/'build/epmapping',check=True)
