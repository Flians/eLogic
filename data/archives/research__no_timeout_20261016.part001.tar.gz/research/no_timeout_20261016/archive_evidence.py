"""Losslessly archive the fixed validated matrix, raw proofs and exact tools."""
import hashlib
import io
import json
from pathlib import Path
import tarfile

project = Path(__file__).resolve().parents[2]
research = Path(__file__).parent
output = research / 'validated'
gate = json.loads((output / 'gate.json').read_text())
assert gate['observed'] == 64 and not gate['missing'] and not gate['incomplete']
root = Path('/tmp/epm-no-timeout-20261016')
matrix = root / 'pivots2'
inputs = project / 'results_v27_three_parts_build_reuse/cold/inputs'
files = {}

def add_tree(source, name):
    if source.is_file():
        files[name] = source
    else:
        for f in sorted(source.rglob('*')):
            if f.is_file():
                files[f'{name}/{f.relative_to(source)}'] = f

for wd in sorted(matrix.glob('b9.*')):
    assert (wd / 'result.json').exists()
    assert json.loads((wd / 'result.json').read_text())['rc'] == 0
    add_tree(wd, f'runs/{wd.name}')
add_tree(matrix / 'cache', 'cache')
for wd in sorted((matrix / 'rounds2').glob('b9.*')):
    if (wd / 'result.json').exists():
        add_tree(wd, f'diagnostics/two_round/{wd.name}')
for name in ['b1.high_effort.cold.div', 'b1.high_effort.cold.sqrt',
             'b1.high_effort.cold.mem_ctrl', 'b3.high_effort.cold.mem_ctrl',
             'b5.high_effort.cold.mem_ctrl', 'b9.high_effort.cold.mem_ctrl']:
    assert (root / name / 'result.json').exists()
    add_tree(root / name, f'diagnostics/isolated/{name}')
for name in ['abc', 'asap7.genlib', 'asap7_6in.genlib', 'database.super', 'benchmarks']:
    add_tree(inputs / name, f'inputs/{name}')
add_tree(inputs.parent / 'manifest.json', 'inputs/original_campaign_manifest.json')
add_tree(inputs.parent / 'tab_mfs3/abc_results.json', 'baseline/abc_results.json')
for d in gate['baseline_completed_designs']:
    add_tree(inputs.parent / 'tab_mfs3' / f'abc.{d}', f'baseline/abc.{d}')
add_tree(Path('/tmp/epm-no-timeout-build2/epmapping_check'), 'binary/timed_epmapping_check')
add_tree(Path('/tmp/epm-no-timeout-build/epmapping_check'), 'binary/phase_memo_probe_epmapping_check')
add_tree(Path('/tmp/epm-no-timeout-build-default/epmapping_check'), 'binary/default_epmapping_check')
add_tree(research / 'versions/local_truth', 'source/timed')
for f in ['epmapping.hpp', 'main.cpp', 'live_query_cache.hpp', 'local_truth_table.hpp']:
    add_tree(project / 'epmapping' / f, f'source/default/{f}')
add_tree(project / 'epmapping/README.md', 'source/README.md')
for pattern in ['*.py', '*before*', '*.md', '*.json', '*.log']:
    for f in research.glob(pattern):
        add_tree(f, f'research/{f.name}')
for name in ['test_live_query_cache.cpp', 'test_local_truth_table.cpp']:
    add_tree(project / 'scripts/experiments/tests' / name, f'tests/{name}')
for name in ['run_three_parts.py', 'audit_mapped_ppa.py', 'report.py']:
    add_tree(project / 'scripts/experiments' / name, f'scripts/{name}')
for mode in ['cold', 'warm']:
    add_tree(root / f'default_smoke_{mode}', f'default_smoke/{mode}')
for name in ['gate.json', 'results.tsv', 'REPORT.md']:
    add_tree(output / name, f'report/{name}')

hashes = {name: hashlib.sha256(f.read_bytes()).hexdigest() for name, f in files.items()}
assert hashes['binary/timed_epmapping_check'] == gate['binary_sha256'][0]
manifest = dict(files=hashes, fixed_configuration=dict(live_query_cache=9, cofactor_pivots=2,
                rounds=dict(direct=1, high_effort=6), post_mapping_timeout=1000),
                completed=64, timeouts=0, default_binary_differences='only parameter defaults and environment fallbacks')
(output / 'evidence_manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
archive = output / 'evidence.tar.gz'
assert not archive.exists(), 'do not overwrite an archived experiment'
with tarfile.open(archive, 'w:gz', compresslevel=1) as bundle:
    for name, f in files.items():
        bundle.add(f, arcname=name, recursive=False)
    data = json.dumps(manifest, indent=2).encode()
    info = tarfile.TarInfo('MANIFEST.json')
    info.size = len(data)
    bundle.addfile(info, io.BytesIO(data))
# Re-read every archived member and verify its bytes, rather than only its tar CRC.
with tarfile.open(archive, 'r:gz') as bundle:
    for member in bundle:
        if member.name in hashes:
            assert hashlib.sha256(bundle.extractfile(member).read()).hexdigest() == hashes[member.name], member.name
digest = hashlib.sha256(archive.read_bytes()).hexdigest()
(output / 'evidence.sha256').write_text(f'{digest}  evidence.tar.gz\n')
print(json.dumps(dict(files=len(files), bytes=archive.stat().st_size, sha256=digest)))
