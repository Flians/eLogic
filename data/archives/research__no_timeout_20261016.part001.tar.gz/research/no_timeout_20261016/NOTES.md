# No-timeout optimization, 2026-10-16

This is a separate validation campaign. It does not replace the v27 paper tables.

## Target and audit

Normal native completion under the unchanged 1000 s post-mapping alarm, on the original 16 benchmark AIGs and identical initial mapped Verilog. Whole-window synthesis remains disabled. Both native and serialized area/delay must not exceed the original start. Cold and warm profile-cache runs use distinct per-circuit/per-recipe cache directories, empty before cold and reused by warm. CEC compares the final mapped function with the original AIG. A checkpoint written by an interrupted process is never a completed result.

`check_completion.py` went red on the archived v27 primary method runs: 12 native timeouts, comprising cold/warm main div/sqrt/mem_ctrl, main one-round sqrt, and direct div/sqrt.

## Ranked hypotheses and isolated probes

1. External phase pricing repeats inverse-fanout and cycle queries for many candidate covers in an unchanged root context. Cache positive and negative answers; invalidate on substitution/rebuild, network growth, or root change. A live parent with a strictly smaller structural level cannot depend on the replacement root; other cases retain the original traversal.
2. A cut repeatedly reconstructs its removable-node set and repeats truth-table simulation. Probe removable-set caching and dynamic truth-table reuse independently before combining anything.
3. Full Shannon/Davio pivot enumeration spends time on many related candidates. A fixed structural pivot budget ranks variables by cofactor/difference support; it is independent of circuit name, elapsed time and remaining deadline.

The first cache resolved div/sqrt native timeouts, but high-effort mem_ctrl still timed out. USB with caching retained the byte-identical final Verilog. Removable-set and dynamic-table-only variants are diagnostic probes, not automatically selected improvements.

## Local truth-table implementation

The scalar reference re-fetches and copies the same node function inside each minterm loop. The new path decodes each node once per closed cut, reuses scratch storage without clearing unrelated network slots, and reuses the cut's cached truth table. Gate pin order, edge complement, constants and minterm order are preserved. The helper differential test covers 1400 random closed DAGs, zero to six cut leaves, zero to nine gate fanins, multiword LUTs, sparse node indices and dirty/resized scratch. Independent final CEC is still required for every integration run.

## Search budget

The pivot-budget probe retains all enabled decomposition families and at most two structurally ranked pivots per family. Every retained candidate passes the existing functional and exact delay/area guards. This changes candidate coverage and can sacrifice small area gains; it must be judged against the unchanged baseline, rather than claimed equivalent to exhaustive enumeration. The post-mapping deadline and round cap remain unchanged in this probe.

## Commands

- Unit: `c++ -std=c++17 -O2 -I. scripts/experiments/tests/test_live_query_cache.cpp -o /tmp/test_live_query_cache && /tmp/test_live_query_cache`
- Differential simulation: `c++ -std=c++17 -O2 -I. scripts/experiments/tests/test_local_truth_table.cpp -o /tmp/test_local_truth_table && /tmp/test_local_truth_table`
- Timed matrix driver: `python3 research/no_timeout_20261016/run_probe.py --help`
- Completion/quality gate: `python3 research/no_timeout_20261016/verify_method.py --root /tmp/epm-no-timeout-20261016/pivots2 --bits 9`

All probe outputs live under `/tmp/epm-no-timeout-20261016` while the matrix is running. Failed diagnostic variants are retained as failures. The gate remains red until all 64 selected-config runs complete, satisfy the physical bounds, and beat delay-guarded mfs3 in mean normalized area on its 13 completed circuits. Raw mfs3 area comparisons are also reported; its 3 native timeouts are excluded from paired claims.

## Diagnostic controls and defaults

The two-round control is kept separately under `pivots2/rounds2`; it is not mixed with six-round results. High-effort mem_ctrl completed cold at 832.679 s with six rounds (area 1818.16, delay 1461.58), compared with 537.294 s and area 1824.18 / delay 1479.36 for the fixed two-round control. Thus the six-round configuration remains the preferred candidate pending the full warm check.

The timed binary is SHA256 `9680f65d2245d1630b28704559f0d7b6d17661c5a3dde881a2384174738593cb`. The rebuilt default binary is SHA256 `a48bf54b80ebd17b266e6fa1e3d6c2f7cf4af1318f01fcb18c2f6f97d03d0f37`. Their sources differ only in the two default parameter values and their environment fallbacks; timed runs explicitly set the same values (live-query mask 9 and pivot cap 2). `default_smoke.json` independently verifies cold/warm behavior without either environment override, with matching final metrics and CEC.

## Final selected configuration

The full fixed configuration passed: 64/64 normal completions, zero timeouts, CEC and independent native/serialized area/delay bounds all satisfied. The six-round main cap is retained; direct/mfs3 still uses one round. The final two additions to the three-part runner are `EPMAPPING_LIVE_QUERY_CACHE=9` and `EPMAPPING_COFAC_PIVOTS=2`. The new headers are frozen with future campaigns. The two-round control remains a separate diagnostic, not the selected method. The installed build and its before/after digests are recorded in `installed_build.json`.

See `validated/REPORT.md`, `validated/results.tsv` and `validated/gate.json`. The timed full-library method averages 7.106% less area and 7.432% less delay than the original initial mapping, with matching cold/warm PPA. Maximum optimizer time is 832.679 s cold / 474.601 s warm. On 13 completed matched-start mfs3 pairs, the mean area ratio to raw mfs3 is 0.964571; per-circuit raw area is 7 wins and 6 losses. Do not claim universal per-circuit dominance. Published v27 paper tables and old ablation results have not been overwritten by this separate method validation.
