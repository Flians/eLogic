"""Fail on missing runs, native TO, invalid bounds or aggregate baseline regression."""
import argparse,hashlib,json,statistics,sys
from pathlib import Path
ap=argparse.ArgumentParser();ap.add_argument('--root',type=Path,default=Path('/tmp/epm-no-timeout-20261016'));ap.add_argument('--bits',type=int,default=1);a=ap.parse_args()
project=Path(__file__).resolve().parents[2];sys.path.insert(0,str(project/'scripts/experiments'));from audit_mapped_ppa import audit
ref=project/'results_v27_three_parts_build_reuse';designs=json.loads((ref/'cold/manifest.json').read_text())['designs'];missing=[];bad=[];rows=[]
for recipe in ['direct','high_effort']:
 for mode in ['cold','warm']:
  for d in designs:
   wd=a.root/f'b{a.bits}.{recipe}.{mode}.{d}';f=wd/'result.json'
   if not f.exists():missing.append(wd.name);continue
   r=json.loads(f.read_text());rows.append(r)
   if r['rc'] or r.get('cec')!=1:bad.append(wd.name);continue
   manifest=json.loads((wd/'manifest.json').read_text());assert manifest['env']['EPMAPPING_POST_TIMEOUT']=='1000';assert manifest['env']['EPMAPPING_WINDOW_SYN']=='0'
   assert manifest['env']['EPMAPPING_LIVE_QUERY_CACHE']==str(a.bits)
   assert manifest['env']['EPMAPPING_AREA_UNDER_DELAY']=='1'
   assert r['optimizer_seconds']<=1000.01
   assert '[i] cec=1' in (wd/'log').read_text()
   assert hashlib.sha256((wd/'epmapping_baseline.v').read_bytes()).hexdigest()==manifest['initial_reference_sha256']
   assert audit(wd/'epmapping_baseline.v',manifest['command'][1])==r['initial']
   assert audit(wd/'epmapping_mapped.v',manifest['command'][1])==r['final']
   for k in ['area','delay','serialized_area','serialized_delay']:assert r['final'][k]<=r['initial'][k]+.001,(wd,k)
manifests=[json.loads((a.root/f'b{a.bits}.{r["recipe"]}.{r["mode"]}.{r["design"]}'/'manifest.json').read_text()) for r in rows]
hashes={m['binary_sha256'] for m in manifests};assert len(hashes)<=1, 'mixed engine versions'
pivots={m['env'].get('EPMAPPING_COFAC_PIVOTS','0') for m in manifests};assert len(pivots)<=1, 'mixed search budgets'
summary=dict(expected=64,observed=len(rows),missing=missing,incomplete=bad,binary_sha256=sorted(hashes),cofactor_pivots=sorted(pivots))
summary['round_caps']={recipe:sorted({m['env']['EPMAPPING_ROUNDS'] for m,r in zip(manifests,rows) if r['recipe']==recipe}) for recipe in ['direct','high_effort']}
assert all(len(v)<=1 for v in summary['round_caps'].values()), 'mixed round caps'
abc=json.loads((ref/'cold/tab_mfs3/abc_results.json').read_text());paired=[r['design'] for r in abc if r['rc']==0];baseline=statistics.mean(r['area']/r['baseline']['area'] if r['delay']<=r['baseline']['delay']+.001 and r['area']<=r['baseline']['area']+.001 else 1 for r in abc if r['rc']==0)
summary['baseline_guarded_area_ratio']=baseline;summary['baseline_completed_designs']=paired
for m in ['cold','warm']:
 rr=[r for r in rows if r['mode']==m and r['recipe']=='direct' and r['design'] in paired and r['rc']==0]
 if len(rr)==len(paired):
  v=statistics.mean(r['final']['area']/r['initial']['area'] for r in rr);summary[m+'_paired_area_ratio']=v;assert v<baseline,(m,v,baseline)
  raw={r['design']:r for r in abc if r['rc']==0}
  summary[m+'_area_wins_vs_raw_mfs3']=sum(r['final']['area']<raw[r['design']]['area']-.001 for r in rr)
  summary[m+'_area_losses_vs_raw_mfs3']=sum(r['final']['area']>raw[r['design']]['area']+.001 for r in rr)
  summary[m+'_mean_area_ratio_to_raw_mfs3']=statistics.mean(r['final']['area']/raw[r['design']]['area'] for r in rr)
  assert summary[m+'_mean_area_ratio_to_raw_mfs3']<1
 for recipe in ['direct','high_effort']:
  group=[r for r in rows if r['mode']==m and r['recipe']==recipe and r['rc']==0]
  if group:
   summary[f'{m}_{recipe}']=dict(completed=len(group),max_seconds=max(r['optimizer_seconds'] for r in group),mean_seconds=statistics.mean(r['optimizer_seconds'] for r in group),mean_area_reduction_percent=100*(1-statistics.mean(r['final']['area']/r['initial']['area'] for r in group)),mean_delay_reduction_percent=100*(1-statistics.mean(r['final']['delay']/r['initial']['delay'] for r in group)))
print(json.dumps(summary,indent=2));sys.exit(bool(missing or bad))
