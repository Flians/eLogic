// Benchmark "/tmp/" written by ABC on Mon Oct 12 15:06:04 2026

module \/tmp/  ( 
    p9, p24, p23, p22, p19, p14, p28, p32, p1, p35, p25, p21, p5, p7, p4,
    p8, p0, p17, p26, p27, p30, p16, p31, p13, p3, p2, p18, p12, p10, p6,
    p33, p34, p20, p29, p15, p11,
    o0, o1, o2, o3, o4, o5, o6  );
  input  p9, p24, p23, p22, p19, p14, p28, p32, p1, p35, p25, p21, p5,
    p7, p4, p8, p0, p17, p26, p27, p30, p16, p31, p13, p3, p2, p18, p12,
    p10, p6, p33, p34, p20, p29, p15, p11;
  output o0, o1, o2, o3, o4, o5, o6;
  wire new_n44_, new_n45_, new_n46_, new_n47_, new_n48_, new_n49_, new_n50_,
    new_n51_, new_n52_, new_n53_, new_n54_, new_n55_, new_n56_, new_n57_,
    new_n58_, new_n59_, new_n60_, new_n61_, new_n63_, new_n64_, new_n65_,
    new_n66_, new_n67_, new_n68_, new_n69_, new_n70_, new_n71_, new_n72_,
    new_n73_, new_n74_, new_n75_, new_n76_, new_n77_, new_n78_, new_n79_,
    new_n80_, new_n81_, new_n82_, new_n83_, new_n84_, new_n85_, new_n86_,
    new_n87_, new_n88_, new_n89_, new_n90_, new_n91_, new_n92_, new_n93_,
    new_n94_, new_n95_, new_n96_, new_n97_, new_n98_, new_n99_, new_n100_,
    new_n101_, new_n102_, new_n103_, new_n104_, new_n105_, new_n106_,
    new_n107_, new_n108_, new_n109_, new_n111_, new_n112_, new_n113_,
    new_n114_, new_n115_, new_n116_, new_n117_, new_n118_, new_n119_,
    new_n120_, new_n121_, new_n122_, new_n123_, new_n124_, new_n125_,
    new_n126_, new_n127_, new_n128_, new_n129_, new_n130_, new_n131_,
    new_n132_, new_n133_, new_n134_, new_n135_, new_n136_, new_n137_,
    new_n138_, new_n139_, new_n140_, new_n141_, new_n142_, new_n143_,
    new_n144_, new_n145_, new_n146_, new_n147_, new_n148_, new_n149_,
    new_n150_, new_n151_, new_n152_, new_n153_, new_n154_, new_n155_,
    new_n156_, new_n157_, new_n158_, new_n159_, new_n160_, new_n161_,
    new_n163_, new_n164_, new_n165_, new_n166_, new_n167_, new_n168_,
    new_n169_, new_n170_, new_n171_, new_n172_, new_n173_, new_n174_,
    new_n175_, new_n176_, new_n177_, new_n178_, new_n179_, new_n180_,
    new_n181_, new_n182_, new_n183_, new_n184_, new_n185_, new_n186_,
    new_n187_, new_n188_, new_n189_, new_n190_, new_n191_, new_n192_,
    new_n193_, new_n194_, new_n195_, new_n196_, new_n197_, new_n198_,
    new_n199_, new_n200_, new_n201_, new_n202_, new_n203_, new_n204_,
    new_n205_, new_n206_, new_n207_, new_n208_, new_n209_, new_n210_,
    new_n211_, new_n213_, new_n214_, new_n216_, new_n217_, new_n218_,
    new_n219_, new_n220_, new_n221_, new_n222_, new_n223_, new_n224_,
    new_n225_, new_n226_, new_n227_, new_n228_, new_n229_, new_n231_,
    new_n232_, new_n233_;
  INVx1_ASAP7_75t_R    g000(.A(p5), .Y(new_n44_));
  INVx1_ASAP7_75t_R    g001(.A(p7), .Y(new_n45_));
  AOI22x1_ASAP7_75t_R  g002(.A1(new_n44_), .A2(p6), .B1(new_n45_), .B2(p8), .Y(new_n46_));
  INVx1_ASAP7_75t_R    g003(.A(p3), .Y(new_n47_));
  NAND2x1_ASAP7_75t_R  g004(.A(p4), .B(new_n47_), .Y(new_n48_));
  INVx1_ASAP7_75t_R    g005(.A(p15), .Y(new_n49_));
  NAND2x1_ASAP7_75t_R  g006(.A(p16), .B(new_n49_), .Y(new_n50_));
  NAND3x1_ASAP7_75t_R  g007(.A(new_n46_), .B(new_n48_), .C(new_n50_), .Y(new_n51_));
  INVx1_ASAP7_75t_R    g008(.A(p9), .Y(new_n52_));
  INVx1_ASAP7_75t_R    g009(.A(p13), .Y(new_n53_));
  AOI22x1_ASAP7_75t_R  g010(.A1(new_n52_), .A2(p10), .B1(new_n53_), .B2(p14), .Y(new_n54_));
  INVx1_ASAP7_75t_R    g011(.A(p35), .Y(new_n55_));
  INVx1_ASAP7_75t_R    g012(.A(p11), .Y(new_n56_));
  AOI22x1_ASAP7_75t_R  g013(.A1(new_n55_), .A2(p0), .B1(new_n56_), .B2(p12), .Y(new_n57_));
  INVx1_ASAP7_75t_R    g014(.A(p1), .Y(new_n58_));
  NAND2x1_ASAP7_75t_R  g015(.A(p2), .B(new_n58_), .Y(new_n59_));
  NAND3x1_ASAP7_75t_R  g016(.A(new_n54_), .B(new_n57_), .C(new_n59_), .Y(new_n60_));
  NOR2x1_ASAP7_75t_R   g017(.A(new_n51_), .B(new_n60_), .Y(new_n61_));
  INVx1_ASAP7_75t_R    g018(.A(new_n61_), .Y(o0));
  OAI21x1_ASAP7_75t_R  g019(.A1(new_n51_), .A2(new_n60_), .B(p11), .Y(new_n63_));
  INVx1_ASAP7_75t_R    g020(.A(p12), .Y(new_n64_));
  NOR2x1_ASAP7_75t_R   g021(.A(p23), .B(new_n64_), .Y(new_n65_));
  INVx1_ASAP7_75t_R    g022(.A(p10), .Y(new_n66_));
  INVx1_ASAP7_75t_R    g023(.A(p14), .Y(new_n67_));
  OAI22x1_ASAP7_75t_R  g024(.A1(p9), .A2(new_n66_), .B1(new_n67_), .B2(p13), .Y(new_n68_));
  INVx1_ASAP7_75t_R    g025(.A(p0), .Y(new_n69_));
  OAI22x1_ASAP7_75t_R  g026(.A1(p35), .A2(new_n69_), .B1(new_n64_), .B2(p11), .Y(new_n70_));
  AOI211x1_ASAP7_75t_R g027(.A1(new_n58_), .A2(p2), .B(new_n68_), .C(new_n70_), .Y(new_n71_));
  INVx1_ASAP7_75t_R    g028(.A(p6), .Y(new_n72_));
  INVx1_ASAP7_75t_R    g029(.A(p8), .Y(new_n73_));
  OAI22x1_ASAP7_75t_R  g030(.A1(p5), .A2(new_n72_), .B1(new_n73_), .B2(p7), .Y(new_n74_));
  INVx1_ASAP7_75t_R    g031(.A(p4), .Y(new_n75_));
  INVx1_ASAP7_75t_R    g032(.A(p16), .Y(new_n76_));
  OAI22x1_ASAP7_75t_R  g033(.A1(new_n75_), .A2(p3), .B1(new_n76_), .B2(p15), .Y(new_n77_));
  NOR2x1_ASAP7_75t_R   g034(.A(new_n74_), .B(new_n77_), .Y(new_n78_));
  NOR2x1_ASAP7_75t_R   g035(.A(p19), .B(new_n75_), .Y(new_n79_));
  INVx1_ASAP7_75t_R    g036(.A(p19), .Y(new_n80_));
  AND3x1_ASAP7_75t_R   g037(.A(new_n80_), .B(new_n47_), .C(p4), .Y(new_n81_));
  AO31x2_ASAP7_75t_R   g038(.A1(new_n71_), .A2(new_n78_), .A3(new_n79_), .B(new_n81_), .Y(new_n82_));
  AOI22x1_ASAP7_75t_R  g039(.A1(p4), .A2(new_n47_), .B1(new_n56_), .B2(p12), .Y(new_n83_));
  AOI22x1_ASAP7_75t_R  g040(.A1(new_n58_), .A2(p2), .B1(new_n55_), .B2(p0), .Y(new_n84_));
  AOI22x1_ASAP7_75t_R  g041(.A1(p14), .A2(new_n53_), .B1(new_n49_), .B2(p16), .Y(new_n85_));
  NAND3x1_ASAP7_75t_R  g042(.A(new_n83_), .B(new_n84_), .C(new_n85_), .Y(new_n86_));
  NAND2x1_ASAP7_75t_R  g043(.A(p6), .B(new_n44_), .Y(new_n87_));
  AOI22x1_ASAP7_75t_R  g044(.A1(new_n52_), .A2(p10), .B1(new_n45_), .B2(p8), .Y(new_n88_));
  AOI21x1_ASAP7_75t_R  g045(.A1(new_n87_), .A2(new_n88_), .B(new_n58_), .Y(new_n89_));
  INVx1_ASAP7_75t_R    g046(.A(p18), .Y(new_n90_));
  NAND2x1_ASAP7_75t_R  g047(.A(p2), .B(new_n90_), .Y(new_n91_));
  AOI211x1_ASAP7_75t_R g048(.A1(p1), .A2(new_n86_), .B(new_n89_), .C(new_n91_), .Y(new_n92_));
  AOI211x1_ASAP7_75t_R g049(.A1(new_n63_), .A2(new_n65_), .B(new_n82_), .C(new_n92_), .Y(new_n93_));
  AO21x1_ASAP7_75t_R   g050(.A1(new_n78_), .A2(new_n71_), .B(new_n53_), .Y(new_n94_));
  NOR2x1_ASAP7_75t_R   g051(.A(p24), .B(new_n67_), .Y(new_n95_));
  OAI21x1_ASAP7_75t_R  g052(.A1(new_n51_), .A2(new_n60_), .B(p35), .Y(new_n96_));
  NOR2x1_ASAP7_75t_R   g053(.A(p17), .B(new_n69_), .Y(new_n97_));
  AOI22x1_ASAP7_75t_R  g054(.A1(new_n94_), .A2(new_n95_), .B1(new_n96_), .B2(new_n97_), .Y(new_n98_));
  OAI21x1_ASAP7_75t_R  g055(.A1(new_n51_), .A2(new_n60_), .B(p15), .Y(new_n99_));
  NOR2x1_ASAP7_75t_R   g056(.A(p25), .B(new_n76_), .Y(new_n100_));
  OAI21x1_ASAP7_75t_R  g057(.A1(new_n51_), .A2(new_n60_), .B(p7), .Y(new_n101_));
  NOR2x1_ASAP7_75t_R   g058(.A(p21), .B(new_n73_), .Y(new_n102_));
  AOI22x1_ASAP7_75t_R  g059(.A1(new_n99_), .A2(new_n100_), .B1(new_n101_), .B2(new_n102_), .Y(new_n103_));
  OAI21x1_ASAP7_75t_R  g060(.A1(new_n51_), .A2(new_n60_), .B(p9), .Y(new_n104_));
  NOR2x1_ASAP7_75t_R   g061(.A(p22), .B(new_n66_), .Y(new_n105_));
  OAI21x1_ASAP7_75t_R  g062(.A1(new_n51_), .A2(new_n60_), .B(p5), .Y(new_n106_));
  NOR2x1_ASAP7_75t_R   g063(.A(p20), .B(new_n72_), .Y(new_n107_));
  AOI22x1_ASAP7_75t_R  g064(.A1(new_n104_), .A2(new_n105_), .B1(new_n106_), .B2(new_n107_), .Y(new_n108_));
  AND4x2_ASAP7_75t_R   g065(.A(new_n93_), .B(new_n98_), .C(new_n103_), .D(new_n108_), .Y(new_n109_));
  INVx1_ASAP7_75t_R    g066(.A(new_n109_), .Y(o1));
  INVx1_ASAP7_75t_R    g067(.A(p20), .Y(new_n111_));
  INVx1_ASAP7_75t_R    g068(.A(p29), .Y(new_n112_));
  AND3x1_ASAP7_75t_R   g069(.A(new_n106_), .B(p6), .C(new_n112_), .Y(new_n113_));
  OAI21x1_ASAP7_75t_R  g070(.A1(new_n111_), .A2(new_n109_), .B(new_n113_), .Y(new_n114_));
  INVx1_ASAP7_75t_R    g071(.A(p22), .Y(new_n115_));
  INVx1_ASAP7_75t_R    g072(.A(p31), .Y(new_n116_));
  AND3x1_ASAP7_75t_R   g073(.A(new_n104_), .B(new_n116_), .C(p10), .Y(new_n117_));
  OAI21x1_ASAP7_75t_R  g074(.A1(new_n115_), .A2(new_n109_), .B(new_n117_), .Y(new_n118_));
  INVx1_ASAP7_75t_R    g075(.A(p21), .Y(new_n119_));
  AO31x2_ASAP7_75t_R   g076(.A1(new_n98_), .A2(new_n103_), .A3(new_n108_), .B(new_n119_), .Y(new_n120_));
  INVx1_ASAP7_75t_R    g077(.A(new_n82_), .Y(new_n121_));
  AOI21x1_ASAP7_75t_R  g078(.A1(new_n63_), .A2(new_n65_), .B(new_n92_), .Y(new_n122_));
  AO21x1_ASAP7_75t_R   g079(.A1(new_n121_), .A2(new_n122_), .B(new_n119_), .Y(new_n123_));
  INVx1_ASAP7_75t_R    g080(.A(p30), .Y(new_n124_));
  AND3x1_ASAP7_75t_R   g081(.A(new_n101_), .B(p8), .C(new_n124_), .Y(new_n125_));
  NAND3x1_ASAP7_75t_R  g082(.A(new_n120_), .B(new_n123_), .C(new_n125_), .Y(new_n126_));
  AND3x1_ASAP7_75t_R   g083(.A(new_n114_), .B(new_n118_), .C(new_n126_), .Y(new_n127_));
  AOI21x1_ASAP7_75t_R  g084(.A1(new_n104_), .A2(new_n105_), .B(new_n92_), .Y(new_n128_));
  NAND2x1_ASAP7_75t_R  g085(.A(new_n98_), .B(new_n128_), .Y(new_n129_));
  AOI22x1_ASAP7_75t_R  g086(.A1(new_n106_), .A2(new_n107_), .B1(new_n63_), .B2(new_n65_), .Y(new_n130_));
  NAND3x1_ASAP7_75t_R  g087(.A(new_n130_), .B(new_n103_), .C(new_n121_), .Y(new_n131_));
  OAI21x1_ASAP7_75t_R  g088(.A1(new_n129_), .A2(new_n131_), .B(p23), .Y(new_n132_));
  INVx1_ASAP7_75t_R    g089(.A(p32), .Y(new_n133_));
  AND3x1_ASAP7_75t_R   g090(.A(new_n63_), .B(new_n133_), .C(p12), .Y(new_n134_));
  NAND3x1_ASAP7_75t_R  g091(.A(new_n98_), .B(new_n103_), .C(new_n108_), .Y(new_n135_));
  INVx1_ASAP7_75t_R    g092(.A(p28), .Y(new_n136_));
  OA21x2_ASAP7_75t_R   g093(.A1(new_n47_), .A2(new_n61_), .B(p4), .Y(new_n137_));
  NAND2x1_ASAP7_75t_R  g094(.A(new_n136_), .B(new_n137_), .Y(new_n138_));
  NOR2x1_ASAP7_75t_R   g095(.A(new_n82_), .B(new_n122_), .Y(new_n139_));
  AOI211x1_ASAP7_75t_R g096(.A1(new_n121_), .A2(new_n135_), .B(new_n138_), .C(new_n139_), .Y(new_n140_));
  AOI21x1_ASAP7_75t_R  g097(.A1(new_n132_), .A2(new_n134_), .B(new_n140_), .Y(new_n141_));
  OAI21x1_ASAP7_75t_R  g098(.A1(new_n129_), .A2(new_n131_), .B(p25), .Y(new_n142_));
  INVx1_ASAP7_75t_R    g099(.A(p34), .Y(new_n143_));
  AND3x1_ASAP7_75t_R   g100(.A(new_n99_), .B(p16), .C(new_n143_), .Y(new_n144_));
  INVx1_ASAP7_75t_R    g101(.A(p24), .Y(new_n145_));
  NOR2x1_ASAP7_75t_R   g102(.A(new_n145_), .B(new_n93_), .Y(new_n146_));
  INVx1_ASAP7_75t_R    g103(.A(p33), .Y(new_n147_));
  NAND3x1_ASAP7_75t_R  g104(.A(new_n94_), .B(p14), .C(new_n147_), .Y(new_n148_));
  AOI211x1_ASAP7_75t_R g105(.A1(p24), .A2(new_n135_), .B(new_n146_), .C(new_n148_), .Y(new_n149_));
  AOI21x1_ASAP7_75t_R  g106(.A1(new_n142_), .A2(new_n144_), .B(new_n149_), .Y(new_n150_));
  INVx1_ASAP7_75t_R    g107(.A(new_n59_), .Y(new_n151_));
  AND3x1_ASAP7_75t_R   g108(.A(new_n71_), .B(p2), .C(new_n78_), .Y(new_n152_));
  OAI21x1_ASAP7_75t_R  g109(.A1(new_n151_), .A2(new_n152_), .B(new_n93_), .Y(new_n153_));
  AO21x1_ASAP7_75t_R   g110(.A1(p1), .A2(o0), .B(new_n91_), .Y(new_n154_));
  OAI21x1_ASAP7_75t_R  g111(.A1(new_n135_), .A2(new_n153_), .B(new_n154_), .Y(new_n155_));
  INVx1_ASAP7_75t_R    g112(.A(p27), .Y(new_n156_));
  OAI21x1_ASAP7_75t_R  g113(.A1(new_n129_), .A2(new_n131_), .B(p17), .Y(new_n157_));
  INVx1_ASAP7_75t_R    g114(.A(p26), .Y(new_n158_));
  AND3x1_ASAP7_75t_R   g115(.A(new_n96_), .B(p0), .C(new_n158_), .Y(new_n159_));
  AOI22x1_ASAP7_75t_R  g116(.A1(new_n155_), .A2(new_n156_), .B1(new_n157_), .B2(new_n159_), .Y(new_n160_));
  AND3x1_ASAP7_75t_R   g117(.A(new_n141_), .B(new_n150_), .C(new_n160_), .Y(new_n161_));
  NAND2x1_ASAP7_75t_R  g118(.A(new_n127_), .B(new_n161_), .Y(o2));
  AOI211x1_ASAP7_75t_R g119(.A1(new_n156_), .A2(new_n155_), .B(new_n140_), .C(new_n149_), .Y(new_n163_));
  INVx1_ASAP7_75t_R    g120(.A(p17), .Y(new_n164_));
  OAI21x1_ASAP7_75t_R  g121(.A1(new_n164_), .A2(new_n109_), .B(new_n159_), .Y(new_n165_));
  INVx1_ASAP7_75t_R    g122(.A(p25), .Y(new_n166_));
  OAI21x1_ASAP7_75t_R  g123(.A1(new_n166_), .A2(new_n109_), .B(new_n144_), .Y(new_n167_));
  INVx1_ASAP7_75t_R    g124(.A(p23), .Y(new_n168_));
  AO31x2_ASAP7_75t_R   g125(.A1(new_n98_), .A2(new_n103_), .A3(new_n108_), .B(new_n168_), .Y(new_n169_));
  AO21x1_ASAP7_75t_R   g126(.A1(new_n121_), .A2(new_n122_), .B(new_n168_), .Y(new_n170_));
  NAND3x1_ASAP7_75t_R  g127(.A(new_n169_), .B(new_n170_), .C(new_n134_), .Y(new_n171_));
  AND3x1_ASAP7_75t_R   g128(.A(new_n165_), .B(new_n167_), .C(new_n171_), .Y(new_n172_));
  AOI21x1_ASAP7_75t_R  g129(.A1(new_n163_), .A2(new_n172_), .B(new_n156_), .Y(new_n173_));
  OAI21x1_ASAP7_75t_R  g130(.A1(new_n156_), .A2(new_n127_), .B(new_n155_), .Y(new_n174_));
  AOI21x1_ASAP7_75t_R  g131(.A1(new_n163_), .A2(new_n172_), .B(new_n112_), .Y(new_n175_));
  AND2x2_ASAP7_75t_R   g132(.A(new_n126_), .B(new_n118_), .Y(new_n176_));
  OAI21x1_ASAP7_75t_R  g133(.A1(new_n111_), .A2(new_n93_), .B(new_n106_), .Y(new_n177_));
  AOI211x1_ASAP7_75t_R g134(.A1(p20), .A2(new_n135_), .B(new_n72_), .C(new_n177_), .Y(new_n178_));
  OAI21x1_ASAP7_75t_R  g135(.A1(new_n112_), .A2(new_n176_), .B(new_n178_), .Y(new_n179_));
  OAI22x1_ASAP7_75t_R  g136(.A1(new_n173_), .A2(new_n174_), .B1(new_n175_), .B2(new_n179_), .Y(new_n180_));
  AOI21x1_ASAP7_75t_R  g137(.A1(new_n163_), .A2(new_n172_), .B(new_n158_), .Y(new_n181_));
  AND3x1_ASAP7_75t_R   g138(.A(new_n157_), .B(p0), .C(new_n96_), .Y(new_n182_));
  OAI21x1_ASAP7_75t_R  g139(.A1(new_n158_), .A2(new_n127_), .B(new_n182_), .Y(new_n183_));
  OA21x2_ASAP7_75t_R   g140(.A1(new_n80_), .A2(new_n109_), .B(new_n137_), .Y(new_n184_));
  AO31x2_ASAP7_75t_R   g141(.A1(new_n114_), .A2(new_n118_), .A3(new_n126_), .B(new_n136_), .Y(new_n185_));
  NAND2x1_ASAP7_75t_R  g142(.A(new_n184_), .B(new_n185_), .Y(new_n186_));
  AOI21x1_ASAP7_75t_R  g143(.A1(new_n163_), .A2(new_n172_), .B(new_n136_), .Y(new_n187_));
  OAI22x1_ASAP7_75t_R  g144(.A1(new_n181_), .A2(new_n183_), .B1(new_n186_), .B2(new_n187_), .Y(new_n188_));
  AND3x1_ASAP7_75t_R   g145(.A(new_n127_), .B(new_n172_), .C(new_n163_), .Y(new_n189_));
  AND3x1_ASAP7_75t_R   g146(.A(new_n142_), .B(p16), .C(new_n99_), .Y(new_n190_));
  OAI21x1_ASAP7_75t_R  g147(.A1(new_n143_), .A2(new_n189_), .B(new_n190_), .Y(new_n191_));
  OAI21x1_ASAP7_75t_R  g148(.A1(new_n180_), .A2(new_n188_), .B(new_n191_), .Y(new_n192_));
  NAND3x1_ASAP7_75t_R  g149(.A(new_n114_), .B(new_n118_), .C(new_n126_), .Y(new_n193_));
  AND2x2_ASAP7_75t_R   g150(.A(p10), .B(new_n104_), .Y(new_n194_));
  OAI21x1_ASAP7_75t_R  g151(.A1(new_n115_), .A2(new_n109_), .B(new_n194_), .Y(new_n195_));
  AO21x1_ASAP7_75t_R   g152(.A1(p31), .A2(new_n193_), .B(new_n195_), .Y(new_n196_));
  AOI21x1_ASAP7_75t_R  g153(.A1(new_n163_), .A2(new_n172_), .B(new_n116_), .Y(new_n197_));
  AOI21x1_ASAP7_75t_R  g154(.A1(new_n163_), .A2(new_n172_), .B(new_n124_), .Y(new_n198_));
  NAND2x1_ASAP7_75t_R  g155(.A(new_n114_), .B(new_n118_), .Y(new_n199_));
  NAND2x1_ASAP7_75t_R  g156(.A(p8), .B(new_n101_), .Y(new_n200_));
  AO21x1_ASAP7_75t_R   g157(.A1(p21), .A2(o1), .B(new_n200_), .Y(new_n201_));
  AO21x1_ASAP7_75t_R   g158(.A1(p30), .A2(new_n199_), .B(new_n201_), .Y(new_n202_));
  OAI22x1_ASAP7_75t_R  g159(.A1(new_n196_), .A2(new_n197_), .B1(new_n198_), .B2(new_n202_), .Y(new_n203_));
  NAND3x1_ASAP7_75t_R  g160(.A(new_n132_), .B(p12), .C(new_n63_), .Y(new_n204_));
  AO21x1_ASAP7_75t_R   g161(.A1(p32), .A2(new_n193_), .B(new_n204_), .Y(new_n205_));
  AOI21x1_ASAP7_75t_R  g162(.A1(new_n163_), .A2(new_n172_), .B(new_n133_), .Y(new_n206_));
  OA211x2_ASAP7_75t_R  g163(.A1(new_n145_), .A2(new_n109_), .B(p14), .C(new_n94_), .Y(new_n207_));
  OAI21x1_ASAP7_75t_R  g164(.A1(new_n147_), .A2(new_n127_), .B(new_n207_), .Y(new_n208_));
  AOI21x1_ASAP7_75t_R  g165(.A1(new_n163_), .A2(new_n172_), .B(new_n147_), .Y(new_n209_));
  OAI22x1_ASAP7_75t_R  g166(.A1(new_n205_), .A2(new_n206_), .B1(new_n208_), .B2(new_n209_), .Y(new_n210_));
  OAI21x1_ASAP7_75t_R  g167(.A1(new_n203_), .A2(new_n210_), .B(new_n191_), .Y(new_n211_));
  NAND2x1_ASAP7_75t_R  g168(.A(new_n192_), .B(new_n211_), .Y(o3));
  NOR2x1_ASAP7_75t_R   g169(.A(new_n209_), .B(new_n208_), .Y(new_n213_));
  NOR2x1_ASAP7_75t_R   g170(.A(new_n206_), .B(new_n205_), .Y(new_n214_));
  OR3x1_ASAP7_75t_R    g171(.A(new_n203_), .B(new_n213_), .C(new_n214_), .Y(o4));
  INVx1_ASAP7_75t_R    g172(.A(new_n184_), .Y(new_n216_));
  NOR2x1_ASAP7_75t_R   g173(.A(new_n216_), .B(new_n193_), .Y(new_n217_));
  AOI21x1_ASAP7_75t_R  g174(.A1(new_n217_), .A2(new_n161_), .B(new_n140_), .Y(new_n218_));
  AO31x2_ASAP7_75t_R   g175(.A1(new_n141_), .A2(new_n150_), .A3(new_n160_), .B(new_n116_), .Y(new_n219_));
  AOI21x1_ASAP7_75t_R  g176(.A1(p31), .A2(new_n193_), .B(new_n195_), .Y(new_n220_));
  AO31x2_ASAP7_75t_R   g177(.A1(new_n141_), .A2(new_n150_), .A3(new_n160_), .B(new_n124_), .Y(new_n221_));
  AOI21x1_ASAP7_75t_R  g178(.A1(p30), .A2(new_n199_), .B(new_n201_), .Y(new_n222_));
  AOI22x1_ASAP7_75t_R  g179(.A1(new_n219_), .A2(new_n220_), .B1(new_n221_), .B2(new_n222_), .Y(new_n223_));
  AND4x2_ASAP7_75t_R   g180(.A(new_n118_), .B(new_n178_), .C(new_n126_), .D(p29), .Y(new_n224_));
  NAND3x1_ASAP7_75t_R  g181(.A(new_n224_), .B(new_n172_), .C(new_n163_), .Y(new_n225_));
  AO31x2_ASAP7_75t_R   g182(.A1(new_n141_), .A2(new_n150_), .A3(new_n160_), .B(new_n133_), .Y(new_n226_));
  AOI21x1_ASAP7_75t_R  g183(.A1(p32), .A2(new_n193_), .B(new_n204_), .Y(new_n227_));
  AOI22x1_ASAP7_75t_R  g184(.A1(new_n225_), .A2(new_n114_), .B1(new_n226_), .B2(new_n227_), .Y(new_n228_));
  AOI21x1_ASAP7_75t_R  g185(.A1(new_n223_), .A2(new_n228_), .B(new_n210_), .Y(new_n229_));
  OAI21x1_ASAP7_75t_R  g186(.A1(new_n218_), .A2(new_n203_), .B(new_n229_), .Y(o5));
  NOR2x1_ASAP7_75t_R   g187(.A(new_n173_), .B(new_n174_), .Y(new_n231_));
  AOI22x1_ASAP7_75t_R  g188(.A1(new_n231_), .A2(new_n218_), .B1(new_n219_), .B2(new_n220_), .Y(new_n232_));
  AOI21x1_ASAP7_75t_R  g189(.A1(new_n223_), .A2(new_n228_), .B(new_n213_), .Y(new_n233_));
  OAI21x1_ASAP7_75t_R  g190(.A1(new_n214_), .A2(new_n232_), .B(new_n233_), .Y(o6));
endmodule


