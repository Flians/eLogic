// Benchmark "/tmp/" written by ABC on Mon Oct 12 15:06:04 2026

module \/tmp/  ( 
    p33, p16, p5, p4, p14, p29, p9, p24, p30, p23, p1, p11, p31, p2, p32,
    p21, p27, p22, p8, p3, p35, p28, p15, p17, p10, p12, p20, p6, p26, p0,
    p13, p19, p18, p34, p25, p7,
    o0, o1, o2, o3, o4, o5, o6  );
  input  p33, p16, p5, p4, p14, p29, p9, p24, p30, p23, p1, p11, p31, p2,
    p32, p21, p27, p22, p8, p3, p35, p28, p15, p17, p10, p12, p20, p6, p26,
    p0, p13, p19, p18, p34, p25, p7;
  output o0, o1, o2, o3, o4, o5, o6;
  wire new_n44_, new_n45_, new_n46_, new_n47_, new_n48_, new_n49_, new_n50_,
    new_n51_, new_n52_, new_n53_, new_n54_, new_n55_, new_n56_, new_n57_,
    new_n58_, new_n59_, new_n61_, new_n62_, new_n63_, new_n64_, new_n65_,
    new_n66_, new_n67_, new_n68_, new_n69_, new_n70_, new_n71_, new_n72_,
    new_n73_, new_n74_, new_n75_, new_n76_, new_n77_, new_n78_, new_n79_,
    new_n80_, new_n81_, new_n82_, new_n83_, new_n84_, new_n85_, new_n86_,
    new_n87_, new_n88_, new_n89_, new_n90_, new_n91_, new_n92_, new_n93_,
    new_n94_, new_n95_, new_n96_, new_n97_, new_n98_, new_n99_, new_n100_,
    new_n101_, new_n102_, new_n104_, new_n105_, new_n106_, new_n107_,
    new_n108_, new_n109_, new_n110_, new_n111_, new_n112_, new_n113_,
    new_n114_, new_n115_, new_n116_, new_n117_, new_n118_, new_n119_,
    new_n120_, new_n121_, new_n122_, new_n123_, new_n124_, new_n125_,
    new_n126_, new_n127_, new_n128_, new_n129_, new_n130_, new_n131_,
    new_n132_, new_n133_, new_n134_, new_n135_, new_n136_, new_n137_,
    new_n138_, new_n139_, new_n140_, new_n141_, new_n142_, new_n143_,
    new_n144_, new_n145_, new_n146_, new_n147_, new_n148_, new_n149_,
    new_n150_, new_n151_, new_n152_, new_n153_, new_n155_, new_n156_,
    new_n157_, new_n158_, new_n159_, new_n160_, new_n161_, new_n162_,
    new_n163_, new_n164_, new_n165_, new_n166_, new_n167_, new_n168_,
    new_n169_, new_n170_, new_n171_, new_n172_, new_n173_, new_n174_,
    new_n175_, new_n176_, new_n177_, new_n178_, new_n179_, new_n180_,
    new_n181_, new_n182_, new_n183_, new_n184_, new_n185_, new_n186_,
    new_n187_, new_n188_, new_n189_, new_n190_, new_n191_, new_n192_,
    new_n193_, new_n194_, new_n195_, new_n196_, new_n197_, new_n198_,
    new_n199_, new_n200_, new_n201_, new_n202_, new_n203_, new_n204_,
    new_n205_, new_n206_, new_n207_, new_n208_, new_n209_, new_n210_,
    new_n211_, new_n212_, new_n215_, new_n216_, new_n217_, new_n218_,
    new_n219_, new_n220_, new_n221_, new_n222_, new_n223_, new_n224_,
    new_n225_, new_n226_, new_n228_, new_n229_, new_n230_, new_n231_,
    new_n232_, new_n233_;
  INVx1_ASAP7_75t_R    g000(.A(p15), .Y(new_n44_));
  INVx1_ASAP7_75t_R    g001(.A(p13), .Y(new_n45_));
  AOI22x1_ASAP7_75t_R  g002(.A1(p16), .A2(new_n44_), .B1(new_n45_), .B2(p14), .Y(new_n46_));
  INVx1_ASAP7_75t_R    g003(.A(p3), .Y(new_n47_));
  INVx1_ASAP7_75t_R    g004(.A(p11), .Y(new_n48_));
  AOI22x1_ASAP7_75t_R  g005(.A1(p4), .A2(new_n47_), .B1(new_n48_), .B2(p12), .Y(new_n49_));
  AND2x2_ASAP7_75t_R   g006(.A(new_n46_), .B(new_n49_), .Y(new_n50_));
  INVx1_ASAP7_75t_R    g007(.A(p1), .Y(new_n51_));
  INVx1_ASAP7_75t_R    g008(.A(p35), .Y(new_n52_));
  AOI22x1_ASAP7_75t_R  g009(.A1(new_n51_), .A2(p2), .B1(new_n52_), .B2(p0), .Y(new_n53_));
  INVx1_ASAP7_75t_R    g010(.A(p9), .Y(new_n54_));
  INVx1_ASAP7_75t_R    g011(.A(p7), .Y(new_n55_));
  AOI22x1_ASAP7_75t_R  g012(.A1(new_n54_), .A2(p10), .B1(new_n55_), .B2(p8), .Y(new_n56_));
  INVx1_ASAP7_75t_R    g013(.A(p5), .Y(new_n57_));
  NAND2x1_ASAP7_75t_R  g014(.A(p6), .B(new_n57_), .Y(new_n58_));
  AND3x1_ASAP7_75t_R   g015(.A(new_n53_), .B(new_n56_), .C(new_n58_), .Y(new_n59_));
  NAND2x1_ASAP7_75t_R  g016(.A(new_n50_), .B(new_n59_), .Y(o0));
  AOI21x1_ASAP7_75t_R  g017(.A1(new_n50_), .A2(new_n59_), .B(new_n48_), .Y(new_n61_));
  INVx1_ASAP7_75t_R    g018(.A(p12), .Y(new_n62_));
  NOR2x1_ASAP7_75t_R   g019(.A(p23), .B(new_n62_), .Y(new_n63_));
  INVx1_ASAP7_75t_R    g020(.A(new_n63_), .Y(new_n64_));
  AOI21x1_ASAP7_75t_R  g021(.A1(new_n50_), .A2(new_n59_), .B(new_n51_), .Y(new_n65_));
  INVx1_ASAP7_75t_R    g022(.A(p2), .Y(new_n66_));
  NOR2x1_ASAP7_75t_R   g023(.A(p18), .B(new_n66_), .Y(new_n67_));
  INVx1_ASAP7_75t_R    g024(.A(new_n67_), .Y(new_n68_));
  OAI22x1_ASAP7_75t_R  g025(.A1(new_n61_), .A2(new_n64_), .B1(new_n65_), .B2(new_n68_), .Y(new_n69_));
  INVx1_ASAP7_75t_R    g026(.A(p0), .Y(new_n70_));
  NOR2x1_ASAP7_75t_R   g027(.A(p17), .B(new_n70_), .Y(new_n71_));
  INVx1_ASAP7_75t_R    g028(.A(new_n71_), .Y(new_n72_));
  AOI21x1_ASAP7_75t_R  g029(.A1(new_n50_), .A2(new_n59_), .B(new_n52_), .Y(new_n73_));
  AO31x2_ASAP7_75t_R   g030(.A1(new_n46_), .A2(new_n49_), .A3(new_n53_), .B(new_n45_), .Y(new_n74_));
  AO21x1_ASAP7_75t_R   g031(.A1(new_n58_), .A2(new_n56_), .B(new_n45_), .Y(new_n75_));
  INVx1_ASAP7_75t_R    g032(.A(p24), .Y(new_n76_));
  AND2x2_ASAP7_75t_R   g033(.A(p14), .B(new_n76_), .Y(new_n77_));
  NAND3x1_ASAP7_75t_R  g034(.A(new_n74_), .B(new_n75_), .C(new_n77_), .Y(new_n78_));
  OAI21x1_ASAP7_75t_R  g035(.A1(new_n72_), .A2(new_n73_), .B(new_n78_), .Y(new_n79_));
  INVx1_ASAP7_75t_R    g036(.A(p4), .Y(new_n80_));
  NOR2x1_ASAP7_75t_R   g037(.A(p3), .B(new_n80_), .Y(new_n81_));
  NAND2x1_ASAP7_75t_R  g038(.A(new_n46_), .B(new_n49_), .Y(new_n82_));
  NAND3x1_ASAP7_75t_R  g039(.A(new_n53_), .B(new_n56_), .C(new_n58_), .Y(new_n83_));
  NOR2x1_ASAP7_75t_R   g040(.A(new_n82_), .B(new_n83_), .Y(new_n84_));
  NOR2x1_ASAP7_75t_R   g041(.A(p19), .B(new_n80_), .Y(new_n85_));
  OA21x2_ASAP7_75t_R   g042(.A1(new_n81_), .A2(new_n84_), .B(new_n85_), .Y(new_n86_));
  NOR3x1_ASAP7_75t_R   g043(.A(new_n69_), .B(new_n79_), .C(new_n86_), .Y(new_n87_));
  OAI21x1_ASAP7_75t_R  g044(.A1(new_n82_), .A2(new_n83_), .B(p15), .Y(new_n88_));
  INVx1_ASAP7_75t_R    g045(.A(p16), .Y(new_n89_));
  NOR2x1_ASAP7_75t_R   g046(.A(p25), .B(new_n89_), .Y(new_n90_));
  OAI21x1_ASAP7_75t_R  g047(.A1(new_n82_), .A2(new_n83_), .B(p7), .Y(new_n91_));
  INVx1_ASAP7_75t_R    g048(.A(p21), .Y(new_n92_));
  AND2x2_ASAP7_75t_R   g049(.A(p8), .B(new_n92_), .Y(new_n93_));
  AOI22x1_ASAP7_75t_R  g050(.A1(new_n88_), .A2(new_n90_), .B1(new_n91_), .B2(new_n93_), .Y(new_n94_));
  OAI21x1_ASAP7_75t_R  g051(.A1(new_n82_), .A2(new_n83_), .B(p9), .Y(new_n95_));
  INVx1_ASAP7_75t_R    g052(.A(p22), .Y(new_n96_));
  AND2x2_ASAP7_75t_R   g053(.A(p10), .B(new_n96_), .Y(new_n97_));
  OAI21x1_ASAP7_75t_R  g054(.A1(new_n82_), .A2(new_n83_), .B(p5), .Y(new_n98_));
  INVx1_ASAP7_75t_R    g055(.A(p20), .Y(new_n99_));
  AND2x2_ASAP7_75t_R   g056(.A(p6), .B(new_n99_), .Y(new_n100_));
  AOI22x1_ASAP7_75t_R  g057(.A1(new_n95_), .A2(new_n97_), .B1(new_n98_), .B2(new_n100_), .Y(new_n101_));
  AND2x2_ASAP7_75t_R   g058(.A(new_n94_), .B(new_n101_), .Y(new_n102_));
  NAND2x1_ASAP7_75t_R  g059(.A(new_n87_), .B(new_n102_), .Y(o1));
  OAI21x1_ASAP7_75t_R  g060(.A1(new_n82_), .A2(new_n83_), .B(p11), .Y(new_n104_));
  OAI21x1_ASAP7_75t_R  g061(.A1(new_n82_), .A2(new_n83_), .B(p1), .Y(new_n105_));
  AOI22x1_ASAP7_75t_R  g062(.A1(new_n104_), .A2(new_n63_), .B1(new_n105_), .B2(new_n67_), .Y(new_n106_));
  OAI21x1_ASAP7_75t_R  g063(.A1(new_n81_), .A2(new_n84_), .B(new_n85_), .Y(new_n107_));
  NOR2x1_ASAP7_75t_R   g064(.A(new_n66_), .B(new_n65_), .Y(new_n108_));
  AND3x1_ASAP7_75t_R   g065(.A(new_n106_), .B(new_n107_), .C(new_n108_), .Y(new_n109_));
  OAI21x1_ASAP7_75t_R  g066(.A1(new_n82_), .A2(new_n83_), .B(p13), .Y(new_n110_));
  OAI21x1_ASAP7_75t_R  g067(.A1(new_n82_), .A2(new_n83_), .B(p35), .Y(new_n111_));
  AOI22x1_ASAP7_75t_R  g068(.A1(new_n110_), .A2(new_n77_), .B1(new_n111_), .B2(new_n71_), .Y(new_n112_));
  AND3x1_ASAP7_75t_R   g069(.A(new_n112_), .B(new_n94_), .C(new_n101_), .Y(new_n113_));
  NOR2x1_ASAP7_75t_R   g070(.A(new_n68_), .B(new_n65_), .Y(new_n114_));
  AO21x1_ASAP7_75t_R   g071(.A1(new_n109_), .A2(new_n113_), .B(new_n114_), .Y(new_n115_));
  INVx1_ASAP7_75t_R    g072(.A(p27), .Y(new_n116_));
  NAND2x1_ASAP7_75t_R  g073(.A(new_n94_), .B(new_n101_), .Y(new_n117_));
  NAND3x1_ASAP7_75t_R  g074(.A(new_n112_), .B(new_n106_), .C(new_n107_), .Y(new_n118_));
  OAI21x1_ASAP7_75t_R  g075(.A1(new_n117_), .A2(new_n118_), .B(p17), .Y(new_n119_));
  NOR2x1_ASAP7_75t_R   g076(.A(new_n70_), .B(new_n73_), .Y(new_n120_));
  INVx1_ASAP7_75t_R    g077(.A(new_n120_), .Y(new_n121_));
  NOR2x1_ASAP7_75t_R   g078(.A(p26), .B(new_n121_), .Y(new_n122_));
  AOI22x1_ASAP7_75t_R  g079(.A1(new_n115_), .A2(new_n116_), .B1(new_n119_), .B2(new_n122_), .Y(new_n123_));
  OAI21x1_ASAP7_75t_R  g080(.A1(new_n117_), .A2(new_n118_), .B(new_n107_), .Y(new_n124_));
  INVx1_ASAP7_75t_R    g081(.A(p28), .Y(new_n125_));
  OA211x2_ASAP7_75t_R  g082(.A1(new_n81_), .A2(new_n84_), .B(p4), .C(new_n125_), .Y(new_n126_));
  OAI21x1_ASAP7_75t_R  g083(.A1(new_n117_), .A2(new_n118_), .B(p23), .Y(new_n127_));
  INVx1_ASAP7_75t_R    g084(.A(p32), .Y(new_n128_));
  AND3x1_ASAP7_75t_R   g085(.A(new_n104_), .B(new_n128_), .C(p12), .Y(new_n129_));
  AOI22x1_ASAP7_75t_R  g086(.A1(new_n124_), .A2(new_n126_), .B1(new_n127_), .B2(new_n129_), .Y(new_n130_));
  OAI21x1_ASAP7_75t_R  g087(.A1(new_n117_), .A2(new_n118_), .B(p25), .Y(new_n131_));
  INVx1_ASAP7_75t_R    g088(.A(new_n88_), .Y(new_n132_));
  OR3x1_ASAP7_75t_R    g089(.A(new_n132_), .B(new_n89_), .C(p34), .Y(new_n133_));
  INVx1_ASAP7_75t_R    g090(.A(new_n133_), .Y(new_n134_));
  OAI21x1_ASAP7_75t_R  g091(.A1(new_n117_), .A2(new_n118_), .B(p24), .Y(new_n135_));
  INVx1_ASAP7_75t_R    g092(.A(p33), .Y(new_n136_));
  AND3x1_ASAP7_75t_R   g093(.A(new_n110_), .B(new_n136_), .C(p14), .Y(new_n137_));
  AOI22x1_ASAP7_75t_R  g094(.A1(new_n131_), .A2(new_n134_), .B1(new_n135_), .B2(new_n137_), .Y(new_n138_));
  NAND3x1_ASAP7_75t_R  g095(.A(new_n123_), .B(new_n130_), .C(new_n138_), .Y(new_n139_));
  OAI21x1_ASAP7_75t_R  g096(.A1(new_n79_), .A2(new_n117_), .B(p22), .Y(new_n140_));
  AO21x1_ASAP7_75t_R   g097(.A1(new_n107_), .A2(new_n106_), .B(new_n96_), .Y(new_n141_));
  INVx1_ASAP7_75t_R    g098(.A(p31), .Y(new_n142_));
  AND3x1_ASAP7_75t_R   g099(.A(new_n95_), .B(new_n142_), .C(p10), .Y(new_n143_));
  AND3x1_ASAP7_75t_R   g100(.A(new_n140_), .B(new_n141_), .C(new_n143_), .Y(new_n144_));
  AOI21x1_ASAP7_75t_R  g101(.A1(new_n87_), .A2(new_n102_), .B(new_n92_), .Y(new_n145_));
  NAND2x1_ASAP7_75t_R  g102(.A(p8), .B(new_n91_), .Y(new_n146_));
  NOR2x1_ASAP7_75t_R   g103(.A(p30), .B(new_n146_), .Y(new_n147_));
  INVx1_ASAP7_75t_R    g104(.A(new_n147_), .Y(new_n148_));
  AOI21x1_ASAP7_75t_R  g105(.A1(new_n87_), .A2(new_n102_), .B(new_n99_), .Y(new_n149_));
  NAND2x1_ASAP7_75t_R  g106(.A(p6), .B(new_n98_), .Y(new_n150_));
  NOR2x1_ASAP7_75t_R   g107(.A(p29), .B(new_n150_), .Y(new_n151_));
  INVx1_ASAP7_75t_R    g108(.A(new_n151_), .Y(new_n152_));
  OAI22x1_ASAP7_75t_R  g109(.A1(new_n145_), .A2(new_n148_), .B1(new_n149_), .B2(new_n152_), .Y(new_n153_));
  OR3x1_ASAP7_75t_R    g110(.A(new_n139_), .B(new_n144_), .C(new_n153_), .Y(o2));
  OAI21x1_ASAP7_75t_R  g111(.A1(new_n117_), .A2(new_n118_), .B(p21), .Y(new_n155_));
  OAI21x1_ASAP7_75t_R  g112(.A1(new_n117_), .A2(new_n118_), .B(p20), .Y(new_n156_));
  AOI22x1_ASAP7_75t_R  g113(.A1(new_n155_), .A2(new_n147_), .B1(new_n156_), .B2(new_n151_), .Y(new_n157_));
  AND2x2_ASAP7_75t_R   g114(.A(p10), .B(new_n95_), .Y(new_n158_));
  AND3x1_ASAP7_75t_R   g115(.A(new_n140_), .B(new_n158_), .C(new_n141_), .Y(new_n159_));
  OAI21x1_ASAP7_75t_R  g116(.A1(new_n142_), .A2(new_n157_), .B(new_n159_), .Y(new_n160_));
  AO21x1_ASAP7_75t_R   g117(.A1(p31), .A2(new_n139_), .B(new_n160_), .Y(new_n161_));
  AOI21x1_ASAP7_75t_R  g118(.A1(new_n109_), .A2(new_n113_), .B(new_n114_), .Y(new_n162_));
  INVx1_ASAP7_75t_R    g119(.A(p17), .Y(new_n163_));
  AOI21x1_ASAP7_75t_R  g120(.A1(new_n87_), .A2(new_n102_), .B(new_n163_), .Y(new_n164_));
  INVx1_ASAP7_75t_R    g121(.A(new_n122_), .Y(new_n165_));
  OAI22x1_ASAP7_75t_R  g122(.A1(new_n162_), .A2(p27), .B1(new_n164_), .B2(new_n165_), .Y(new_n166_));
  INVx1_ASAP7_75t_R    g123(.A(new_n129_), .Y(new_n167_));
  INVx1_ASAP7_75t_R    g124(.A(p23), .Y(new_n168_));
  AOI21x1_ASAP7_75t_R  g125(.A1(new_n87_), .A2(new_n102_), .B(new_n168_), .Y(new_n169_));
  AO31x2_ASAP7_75t_R   g126(.A1(new_n112_), .A2(new_n94_), .A3(new_n101_), .B(new_n86_), .Y(new_n170_));
  NAND2x1_ASAP7_75t_R  g127(.A(new_n107_), .B(new_n69_), .Y(new_n171_));
  NAND3x1_ASAP7_75t_R  g128(.A(new_n170_), .B(new_n126_), .C(new_n171_), .Y(new_n172_));
  OAI21x1_ASAP7_75t_R  g129(.A1(new_n167_), .A2(new_n169_), .B(new_n172_), .Y(new_n173_));
  INVx1_ASAP7_75t_R    g130(.A(p25), .Y(new_n174_));
  AOI21x1_ASAP7_75t_R  g131(.A1(new_n87_), .A2(new_n102_), .B(new_n174_), .Y(new_n175_));
  AO31x2_ASAP7_75t_R   g132(.A1(new_n112_), .A2(new_n94_), .A3(new_n101_), .B(new_n76_), .Y(new_n176_));
  AO21x1_ASAP7_75t_R   g133(.A1(new_n107_), .A2(new_n106_), .B(new_n76_), .Y(new_n177_));
  NAND3x1_ASAP7_75t_R  g134(.A(new_n176_), .B(new_n177_), .C(new_n137_), .Y(new_n178_));
  OAI21x1_ASAP7_75t_R  g135(.A1(new_n175_), .A2(new_n133_), .B(new_n178_), .Y(new_n179_));
  NOR3x1_ASAP7_75t_R   g136(.A(new_n166_), .B(new_n173_), .C(new_n179_), .Y(new_n180_));
  NAND3x1_ASAP7_75t_R  g137(.A(new_n140_), .B(new_n141_), .C(new_n143_), .Y(new_n181_));
  NOR2x1_ASAP7_75t_R   g138(.A(new_n146_), .B(new_n145_), .Y(new_n182_));
  AND3x1_ASAP7_75t_R   g139(.A(new_n157_), .B(new_n181_), .C(new_n182_), .Y(new_n183_));
  AOI22x1_ASAP7_75t_R  g140(.A1(new_n180_), .A2(new_n183_), .B1(new_n155_), .B2(new_n147_), .Y(new_n184_));
  AND3x1_ASAP7_75t_R   g141(.A(new_n74_), .B(p14), .C(new_n75_), .Y(new_n185_));
  AND3x1_ASAP7_75t_R   g142(.A(new_n176_), .B(new_n177_), .C(new_n185_), .Y(new_n186_));
  AND3x1_ASAP7_75t_R   g143(.A(new_n157_), .B(new_n181_), .C(new_n186_), .Y(new_n187_));
  INVx1_ASAP7_75t_R    g144(.A(new_n178_), .Y(new_n188_));
  AOI21x1_ASAP7_75t_R  g145(.A1(new_n187_), .A2(new_n180_), .B(new_n188_), .Y(new_n189_));
  NAND3x1_ASAP7_75t_R  g146(.A(new_n127_), .B(p12), .C(new_n104_), .Y(new_n190_));
  NOR3x1_ASAP7_75t_R   g147(.A(new_n153_), .B(new_n190_), .C(new_n144_), .Y(new_n191_));
  NOR2x1_ASAP7_75t_R   g148(.A(new_n167_), .B(new_n169_), .Y(new_n192_));
  AOI21x1_ASAP7_75t_R  g149(.A1(new_n191_), .A2(new_n180_), .B(new_n192_), .Y(new_n193_));
  AND4x2_ASAP7_75t_R   g150(.A(new_n161_), .B(new_n184_), .C(new_n189_), .D(new_n193_), .Y(new_n194_));
  NOR2x1_ASAP7_75t_R   g151(.A(new_n121_), .B(new_n164_), .Y(new_n195_));
  AND3x1_ASAP7_75t_R   g152(.A(new_n157_), .B(new_n181_), .C(new_n195_), .Y(new_n196_));
  AOI22x1_ASAP7_75t_R  g153(.A1(new_n180_), .A2(new_n196_), .B1(new_n119_), .B2(new_n122_), .Y(new_n197_));
  AND3x1_ASAP7_75t_R   g154(.A(new_n157_), .B(new_n181_), .C(new_n115_), .Y(new_n198_));
  NOR2x1_ASAP7_75t_R   g155(.A(p27), .B(new_n162_), .Y(new_n199_));
  AOI21x1_ASAP7_75t_R  g156(.A1(new_n198_), .A2(new_n180_), .B(new_n199_), .Y(new_n200_));
  AO21x1_ASAP7_75t_R   g157(.A1(p3), .A2(o0), .B(new_n80_), .Y(new_n201_));
  AOI21x1_ASAP7_75t_R  g158(.A1(p19), .A2(o1), .B(new_n201_), .Y(new_n202_));
  AND3x1_ASAP7_75t_R   g159(.A(new_n157_), .B(new_n181_), .C(new_n202_), .Y(new_n203_));
  INVx1_ASAP7_75t_R    g160(.A(new_n172_), .Y(new_n204_));
  AOI21x1_ASAP7_75t_R  g161(.A1(new_n203_), .A2(new_n180_), .B(new_n204_), .Y(new_n205_));
  NOR2x1_ASAP7_75t_R   g162(.A(new_n150_), .B(new_n149_), .Y(new_n206_));
  AND3x1_ASAP7_75t_R   g163(.A(new_n157_), .B(new_n181_), .C(new_n206_), .Y(new_n207_));
  NOR2x1_ASAP7_75t_R   g164(.A(new_n152_), .B(new_n149_), .Y(new_n208_));
  AOI21x1_ASAP7_75t_R  g165(.A1(new_n207_), .A2(new_n180_), .B(new_n208_), .Y(new_n209_));
  AND4x2_ASAP7_75t_R   g166(.A(new_n197_), .B(new_n200_), .C(new_n205_), .D(new_n209_), .Y(new_n210_));
  OR3x1_ASAP7_75t_R    g167(.A(new_n175_), .B(new_n89_), .C(new_n132_), .Y(new_n211_));
  AOI21x1_ASAP7_75t_R  g168(.A1(p34), .A2(o2), .B(new_n211_), .Y(new_n212_));
  AOI21x1_ASAP7_75t_R  g169(.A1(new_n194_), .A2(new_n210_), .B(new_n212_), .Y(o3));
  INVx1_ASAP7_75t_R    g170(.A(new_n194_), .Y(o4));
  NAND3x1_ASAP7_75t_R  g171(.A(new_n157_), .B(new_n181_), .C(new_n182_), .Y(new_n215_));
  OAI22x1_ASAP7_75t_R  g172(.A1(new_n139_), .A2(new_n215_), .B1(new_n145_), .B2(new_n148_), .Y(new_n216_));
  NOR2x1_ASAP7_75t_R   g173(.A(new_n209_), .B(new_n216_), .Y(new_n217_));
  NAND2x1_ASAP7_75t_R  g174(.A(p31), .B(new_n139_), .Y(new_n218_));
  INVx1_ASAP7_75t_R    g175(.A(new_n160_), .Y(new_n219_));
  NAND2x1_ASAP7_75t_R  g176(.A(new_n181_), .B(new_n157_), .Y(new_n220_));
  AOI21x1_ASAP7_75t_R  g177(.A1(p32), .A2(new_n220_), .B(new_n190_), .Y(new_n221_));
  AO31x2_ASAP7_75t_R   g178(.A1(new_n123_), .A2(new_n130_), .A3(new_n138_), .B(new_n128_), .Y(new_n222_));
  AOI22x1_ASAP7_75t_R  g179(.A1(new_n218_), .A2(new_n219_), .B1(new_n221_), .B2(new_n222_), .Y(new_n223_));
  NAND2x1_ASAP7_75t_R  g180(.A(new_n189_), .B(new_n193_), .Y(new_n224_));
  AOI21x1_ASAP7_75t_R  g181(.A1(p31), .A2(new_n139_), .B(new_n160_), .Y(new_n225_));
  NOR3x1_ASAP7_75t_R   g182(.A(new_n216_), .B(new_n225_), .C(new_n205_), .Y(new_n226_));
  AO211x2_ASAP7_75t_R  g183(.A1(new_n217_), .A2(new_n223_), .B(new_n224_), .C(new_n226_), .Y(o5));
  OA21x2_ASAP7_75t_R   g184(.A1(new_n209_), .A2(new_n216_), .B(new_n189_), .Y(new_n228_));
  AO21x1_ASAP7_75t_R   g185(.A1(new_n187_), .A2(new_n180_), .B(new_n188_), .Y(new_n229_));
  AOI21x1_ASAP7_75t_R  g186(.A1(new_n193_), .A2(new_n161_), .B(new_n229_), .Y(new_n230_));
  INVx1_ASAP7_75t_R    g187(.A(new_n193_), .Y(new_n231_));
  AO21x1_ASAP7_75t_R   g188(.A1(new_n198_), .A2(new_n180_), .B(new_n199_), .Y(new_n232_));
  AOI21x1_ASAP7_75t_R  g189(.A1(new_n205_), .A2(new_n232_), .B(new_n225_), .Y(new_n233_));
  OAI22x1_ASAP7_75t_R  g190(.A1(new_n228_), .A2(new_n230_), .B1(new_n231_), .B2(new_n233_), .Y(o6));
endmodule


