// Benchmark "/tmp/" written by ABC on Mon Oct 12 15:06:04 2026

module \/tmp/  ( 
    p5, p3, p28, p24, p32, p10, p33, p27, p22, p11, p1, p21, p19, p23, p34,
    p12, p30, p25, p14, p29, p35, p4, p17, p26, p13, p31, p20, p6, p9, p15,
    p7, p2, p8, p16, p0, p18,
    o0, o1, o2, o3, o4, o5, o6  );
  input  p5, p3, p28, p24, p32, p10, p33, p27, p22, p11, p1, p21, p19,
    p23, p34, p12, p30, p25, p14, p29, p35, p4, p17, p26, p13, p31, p20,
    p6, p9, p15, p7, p2, p8, p16, p0, p18;
  output o0, o1, o2, o3, o4, o5, o6;
  wire new_n44_, new_n45_, new_n46_, new_n47_, new_n48_, new_n49_, new_n50_,
    new_n51_, new_n52_, new_n53_, new_n54_, new_n55_, new_n56_, new_n57_,
    new_n58_, new_n59_, new_n60_, new_n62_, new_n63_, new_n64_, new_n65_,
    new_n66_, new_n67_, new_n68_, new_n69_, new_n70_, new_n71_, new_n72_,
    new_n73_, new_n74_, new_n75_, new_n76_, new_n77_, new_n78_, new_n79_,
    new_n80_, new_n81_, new_n82_, new_n83_, new_n84_, new_n85_, new_n86_,
    new_n87_, new_n88_, new_n89_, new_n90_, new_n91_, new_n92_, new_n93_,
    new_n94_, new_n95_, new_n96_, new_n98_, new_n99_, new_n100_, new_n101_,
    new_n102_, new_n103_, new_n104_, new_n105_, new_n106_, new_n107_,
    new_n108_, new_n109_, new_n110_, new_n111_, new_n112_, new_n113_,
    new_n114_, new_n115_, new_n116_, new_n117_, new_n118_, new_n119_,
    new_n120_, new_n121_, new_n122_, new_n123_, new_n124_, new_n125_,
    new_n126_, new_n127_, new_n128_, new_n129_, new_n130_, new_n131_,
    new_n132_, new_n133_, new_n134_, new_n135_, new_n136_, new_n137_,
    new_n138_, new_n139_, new_n140_, new_n141_, new_n143_, new_n144_,
    new_n145_, new_n146_, new_n147_, new_n148_, new_n149_, new_n150_,
    new_n151_, new_n152_, new_n153_, new_n154_, new_n155_, new_n156_,
    new_n157_, new_n158_, new_n159_, new_n160_, new_n161_, new_n162_,
    new_n163_, new_n164_, new_n165_, new_n166_, new_n167_, new_n168_,
    new_n169_, new_n170_, new_n171_, new_n172_, new_n173_, new_n174_,
    new_n175_, new_n176_, new_n177_, new_n178_, new_n179_, new_n180_,
    new_n181_, new_n182_, new_n183_, new_n184_, new_n185_, new_n186_,
    new_n187_, new_n188_, new_n189_, new_n192_, new_n193_, new_n194_,
    new_n195_, new_n196_, new_n197_, new_n198_, new_n199_, new_n200_,
    new_n201_, new_n202_, new_n203_, new_n204_, new_n205_, new_n206_,
    new_n207_, new_n208_, new_n210_, new_n211_, new_n212_, new_n213_,
    new_n214_;
  INVx1_ASAP7_75t_R    g000(.A(p7), .Y(new_n44_));
  NAND2x1_ASAP7_75t_R  g001(.A(p8), .B(new_n44_), .Y(new_n45_));
  INVx1_ASAP7_75t_R    g002(.A(p5), .Y(new_n46_));
  INVx1_ASAP7_75t_R    g003(.A(p9), .Y(new_n47_));
  AOI22x1_ASAP7_75t_R  g004(.A1(new_n46_), .A2(p6), .B1(new_n47_), .B2(p10), .Y(new_n48_));
  NAND2x1_ASAP7_75t_R  g005(.A(new_n45_), .B(new_n48_), .Y(new_n49_));
  INVx1_ASAP7_75t_R    g006(.A(p1), .Y(new_n50_));
  INVx1_ASAP7_75t_R    g007(.A(p35), .Y(new_n51_));
  AOI22x1_ASAP7_75t_R  g008(.A1(new_n50_), .A2(p2), .B1(new_n51_), .B2(p0), .Y(new_n52_));
  INVx1_ASAP7_75t_R    g009(.A(p13), .Y(new_n53_));
  INVx1_ASAP7_75t_R    g010(.A(p15), .Y(new_n54_));
  AOI22x1_ASAP7_75t_R  g011(.A1(p14), .A2(new_n53_), .B1(new_n54_), .B2(p16), .Y(new_n55_));
  INVx1_ASAP7_75t_R    g012(.A(p3), .Y(new_n56_));
  INVx1_ASAP7_75t_R    g013(.A(p11), .Y(new_n57_));
  AOI22x1_ASAP7_75t_R  g014(.A1(new_n56_), .A2(p4), .B1(new_n57_), .B2(p12), .Y(new_n58_));
  NAND3x1_ASAP7_75t_R  g015(.A(new_n52_), .B(new_n55_), .C(new_n58_), .Y(new_n59_));
  NOR2x1_ASAP7_75t_R   g016(.A(new_n49_), .B(new_n59_), .Y(new_n60_));
  INVx1_ASAP7_75t_R    g017(.A(new_n60_), .Y(o0));
  OAI21x1_ASAP7_75t_R  g018(.A1(new_n49_), .A2(new_n59_), .B(p5), .Y(new_n62_));
  INVx1_ASAP7_75t_R    g019(.A(p6), .Y(new_n63_));
  NOR2x1_ASAP7_75t_R   g020(.A(p20), .B(new_n63_), .Y(new_n64_));
  OAI21x1_ASAP7_75t_R  g021(.A1(new_n49_), .A2(new_n59_), .B(p9), .Y(new_n65_));
  INVx1_ASAP7_75t_R    g022(.A(p10), .Y(new_n66_));
  NOR2x1_ASAP7_75t_R   g023(.A(p22), .B(new_n66_), .Y(new_n67_));
  AOI22x1_ASAP7_75t_R  g024(.A1(new_n62_), .A2(new_n64_), .B1(new_n65_), .B2(new_n67_), .Y(new_n68_));
  OAI21x1_ASAP7_75t_R  g025(.A1(new_n49_), .A2(new_n59_), .B(p15), .Y(new_n69_));
  INVx1_ASAP7_75t_R    g026(.A(p16), .Y(new_n70_));
  NOR2x1_ASAP7_75t_R   g027(.A(p25), .B(new_n70_), .Y(new_n71_));
  OAI21x1_ASAP7_75t_R  g028(.A1(new_n49_), .A2(new_n59_), .B(p7), .Y(new_n72_));
  INVx1_ASAP7_75t_R    g029(.A(p21), .Y(new_n73_));
  AND2x2_ASAP7_75t_R   g030(.A(p8), .B(new_n73_), .Y(new_n74_));
  AOI22x1_ASAP7_75t_R  g031(.A1(new_n69_), .A2(new_n71_), .B1(new_n72_), .B2(new_n74_), .Y(new_n75_));
  AND2x2_ASAP7_75t_R   g032(.A(new_n68_), .B(new_n75_), .Y(new_n76_));
  OAI21x1_ASAP7_75t_R  g033(.A1(new_n49_), .A2(new_n59_), .B(p1), .Y(new_n77_));
  INVx1_ASAP7_75t_R    g034(.A(p2), .Y(new_n78_));
  NOR2x1_ASAP7_75t_R   g035(.A(p18), .B(new_n78_), .Y(new_n79_));
  OAI21x1_ASAP7_75t_R  g036(.A1(new_n49_), .A2(new_n59_), .B(p11), .Y(new_n80_));
  INVx1_ASAP7_75t_R    g037(.A(p12), .Y(new_n81_));
  NOR2x1_ASAP7_75t_R   g038(.A(p23), .B(new_n81_), .Y(new_n82_));
  AOI22x1_ASAP7_75t_R  g039(.A1(new_n77_), .A2(new_n79_), .B1(new_n80_), .B2(new_n82_), .Y(new_n83_));
  OAI21x1_ASAP7_75t_R  g040(.A1(new_n49_), .A2(new_n59_), .B(p13), .Y(new_n84_));
  INVx1_ASAP7_75t_R    g041(.A(p14), .Y(new_n85_));
  NOR2x1_ASAP7_75t_R   g042(.A(p24), .B(new_n85_), .Y(new_n86_));
  AOI21x1_ASAP7_75t_R  g043(.A1(new_n45_), .A2(new_n48_), .B(new_n51_), .Y(new_n87_));
  AOI21x1_ASAP7_75t_R  g044(.A1(p35), .A2(new_n59_), .B(new_n87_), .Y(new_n88_));
  INVx1_ASAP7_75t_R    g045(.A(p0), .Y(new_n89_));
  NOR2x1_ASAP7_75t_R   g046(.A(p17), .B(new_n89_), .Y(new_n90_));
  AOI22x1_ASAP7_75t_R  g047(.A1(new_n84_), .A2(new_n86_), .B1(new_n88_), .B2(new_n90_), .Y(new_n91_));
  INVx1_ASAP7_75t_R    g048(.A(p4), .Y(new_n92_));
  NOR2x1_ASAP7_75t_R   g049(.A(p3), .B(new_n92_), .Y(new_n93_));
  NOR2x1_ASAP7_75t_R   g050(.A(p19), .B(new_n92_), .Y(new_n94_));
  OAI21x1_ASAP7_75t_R  g051(.A1(new_n93_), .A2(new_n60_), .B(new_n94_), .Y(new_n95_));
  AND3x1_ASAP7_75t_R   g052(.A(new_n83_), .B(new_n91_), .C(new_n95_), .Y(new_n96_));
  NAND2x1_ASAP7_75t_R  g053(.A(new_n76_), .B(new_n96_), .Y(o1));
  INVx1_ASAP7_75t_R    g054(.A(p29), .Y(new_n98_));
  AND3x1_ASAP7_75t_R   g055(.A(new_n62_), .B(new_n98_), .C(p6), .Y(new_n99_));
  NAND2x1_ASAP7_75t_R  g056(.A(new_n68_), .B(new_n75_), .Y(new_n100_));
  NAND3x1_ASAP7_75t_R  g057(.A(new_n83_), .B(new_n91_), .C(new_n95_), .Y(new_n101_));
  OAI21x1_ASAP7_75t_R  g058(.A1(new_n100_), .A2(new_n101_), .B(p20), .Y(new_n102_));
  NAND2x1_ASAP7_75t_R  g059(.A(new_n99_), .B(new_n102_), .Y(new_n103_));
  INVx1_ASAP7_75t_R    g060(.A(p31), .Y(new_n104_));
  AND3x1_ASAP7_75t_R   g061(.A(new_n65_), .B(p10), .C(new_n104_), .Y(new_n105_));
  OAI21x1_ASAP7_75t_R  g062(.A1(new_n100_), .A2(new_n101_), .B(p22), .Y(new_n106_));
  NAND2x1_ASAP7_75t_R  g063(.A(new_n105_), .B(new_n106_), .Y(new_n107_));
  AO31x2_ASAP7_75t_R   g064(.A1(new_n68_), .A2(new_n75_), .A3(new_n91_), .B(new_n73_), .Y(new_n108_));
  AO21x1_ASAP7_75t_R   g065(.A1(new_n95_), .A2(new_n83_), .B(new_n73_), .Y(new_n109_));
  INVx1_ASAP7_75t_R    g066(.A(p30), .Y(new_n110_));
  AND3x1_ASAP7_75t_R   g067(.A(new_n72_), .B(new_n110_), .C(p8), .Y(new_n111_));
  NAND3x1_ASAP7_75t_R  g068(.A(new_n108_), .B(new_n109_), .C(new_n111_), .Y(new_n112_));
  NAND3x1_ASAP7_75t_R  g069(.A(new_n103_), .B(new_n107_), .C(new_n112_), .Y(new_n113_));
  INVx1_ASAP7_75t_R    g070(.A(p34), .Y(new_n114_));
  AND3x1_ASAP7_75t_R   g071(.A(new_n69_), .B(new_n114_), .C(p16), .Y(new_n115_));
  OAI21x1_ASAP7_75t_R  g072(.A1(new_n100_), .A2(new_n101_), .B(p25), .Y(new_n116_));
  OAI21x1_ASAP7_75t_R  g073(.A1(new_n100_), .A2(new_n101_), .B(p24), .Y(new_n117_));
  INVx1_ASAP7_75t_R    g074(.A(p33), .Y(new_n118_));
  AND3x1_ASAP7_75t_R   g075(.A(new_n84_), .B(new_n118_), .C(p14), .Y(new_n119_));
  AO22x1_ASAP7_75t_R   g076(.A1(new_n115_), .A2(new_n116_), .B1(new_n117_), .B2(new_n119_), .Y(new_n120_));
  OA21x2_ASAP7_75t_R   g077(.A1(new_n100_), .A2(new_n101_), .B(p23), .Y(new_n121_));
  INVx1_ASAP7_75t_R    g078(.A(p32), .Y(new_n122_));
  AND3x1_ASAP7_75t_R   g079(.A(new_n80_), .B(new_n122_), .C(p12), .Y(new_n123_));
  INVx1_ASAP7_75t_R    g080(.A(new_n123_), .Y(new_n124_));
  INVx1_ASAP7_75t_R    g081(.A(p19), .Y(new_n125_));
  AO21x1_ASAP7_75t_R   g082(.A1(new_n95_), .A2(new_n83_), .B(new_n125_), .Y(new_n126_));
  AO31x2_ASAP7_75t_R   g083(.A1(new_n68_), .A2(new_n75_), .A3(new_n91_), .B(new_n125_), .Y(new_n127_));
  NAND2x1_ASAP7_75t_R  g084(.A(new_n126_), .B(new_n127_), .Y(new_n128_));
  AO21x1_ASAP7_75t_R   g085(.A1(p3), .A2(o0), .B(new_n92_), .Y(new_n129_));
  NOR2x1_ASAP7_75t_R   g086(.A(p28), .B(new_n129_), .Y(new_n130_));
  INVx1_ASAP7_75t_R    g087(.A(new_n130_), .Y(new_n131_));
  OAI22x1_ASAP7_75t_R  g088(.A1(new_n121_), .A2(new_n124_), .B1(new_n128_), .B2(new_n131_), .Y(new_n132_));
  OA21x2_ASAP7_75t_R   g089(.A1(new_n100_), .A2(new_n101_), .B(p18), .Y(new_n133_));
  OA21x2_ASAP7_75t_R   g090(.A1(new_n49_), .A2(new_n59_), .B(p1), .Y(new_n134_));
  OR3x1_ASAP7_75t_R    g091(.A(new_n134_), .B(p27), .C(new_n78_), .Y(new_n135_));
  INVx1_ASAP7_75t_R    g092(.A(p17), .Y(new_n136_));
  AOI21x1_ASAP7_75t_R  g093(.A1(new_n76_), .A2(new_n96_), .B(new_n136_), .Y(new_n137_));
  AO21x1_ASAP7_75t_R   g094(.A1(p35), .A2(o0), .B(new_n89_), .Y(new_n138_));
  NOR2x1_ASAP7_75t_R   g095(.A(p26), .B(new_n138_), .Y(new_n139_));
  INVx1_ASAP7_75t_R    g096(.A(new_n139_), .Y(new_n140_));
  OAI22x1_ASAP7_75t_R  g097(.A1(new_n133_), .A2(new_n135_), .B1(new_n137_), .B2(new_n140_), .Y(new_n141_));
  OR4x2_ASAP7_75t_R    g098(.A(new_n113_), .B(new_n120_), .C(new_n132_), .D(new_n141_), .Y(o2));
  AND3x1_ASAP7_75t_R   g099(.A(new_n106_), .B(p10), .C(new_n65_), .Y(new_n143_));
  OAI21x1_ASAP7_75t_R  g100(.A1(new_n100_), .A2(new_n101_), .B(p21), .Y(new_n144_));
  AOI22x1_ASAP7_75t_R  g101(.A1(new_n106_), .A2(new_n105_), .B1(new_n144_), .B2(new_n111_), .Y(new_n145_));
  NAND3x1_ASAP7_75t_R  g102(.A(new_n143_), .B(new_n145_), .C(new_n103_), .Y(new_n146_));
  AOI22x1_ASAP7_75t_R  g103(.A1(new_n116_), .A2(new_n115_), .B1(new_n117_), .B2(new_n119_), .Y(new_n147_));
  OAI21x1_ASAP7_75t_R  g104(.A1(new_n100_), .A2(new_n101_), .B(p19), .Y(new_n148_));
  OAI21x1_ASAP7_75t_R  g105(.A1(new_n100_), .A2(new_n101_), .B(p23), .Y(new_n149_));
  AOI22x1_ASAP7_75t_R  g106(.A1(new_n148_), .A2(new_n130_), .B1(new_n149_), .B2(new_n123_), .Y(new_n150_));
  NOR2x1_ASAP7_75t_R   g107(.A(new_n78_), .B(new_n134_), .Y(new_n151_));
  NAND3x1_ASAP7_75t_R  g108(.A(new_n83_), .B(new_n151_), .C(new_n95_), .Y(new_n152_));
  NAND3x1_ASAP7_75t_R  g109(.A(new_n68_), .B(new_n75_), .C(new_n91_), .Y(new_n153_));
  NAND2x1_ASAP7_75t_R  g110(.A(new_n79_), .B(new_n77_), .Y(new_n154_));
  OAI21x1_ASAP7_75t_R  g111(.A1(new_n152_), .A2(new_n153_), .B(new_n154_), .Y(new_n155_));
  INVx1_ASAP7_75t_R    g112(.A(p27), .Y(new_n156_));
  OAI21x1_ASAP7_75t_R  g113(.A1(new_n100_), .A2(new_n101_), .B(p17), .Y(new_n157_));
  AOI22x1_ASAP7_75t_R  g114(.A1(new_n155_), .A2(new_n156_), .B1(new_n157_), .B2(new_n139_), .Y(new_n158_));
  NAND3x1_ASAP7_75t_R  g115(.A(new_n147_), .B(new_n150_), .C(new_n158_), .Y(new_n159_));
  OA21x2_ASAP7_75t_R   g116(.A1(new_n146_), .A2(new_n159_), .B(new_n145_), .Y(new_n160_));
  AND3x1_ASAP7_75t_R   g117(.A(new_n147_), .B(new_n150_), .C(new_n158_), .Y(new_n161_));
  AND3x1_ASAP7_75t_R   g118(.A(new_n117_), .B(p14), .C(new_n84_), .Y(new_n162_));
  AND3x1_ASAP7_75t_R   g119(.A(new_n162_), .B(new_n145_), .C(new_n103_), .Y(new_n163_));
  AOI22x1_ASAP7_75t_R  g120(.A1(new_n161_), .A2(new_n163_), .B1(new_n118_), .B2(new_n162_), .Y(new_n164_));
  AND3x1_ASAP7_75t_R   g121(.A(new_n149_), .B(p12), .C(new_n80_), .Y(new_n165_));
  AND3x1_ASAP7_75t_R   g122(.A(new_n165_), .B(new_n145_), .C(new_n103_), .Y(new_n166_));
  NOR2x1_ASAP7_75t_R   g123(.A(new_n124_), .B(new_n121_), .Y(new_n167_));
  AOI21x1_ASAP7_75t_R  g124(.A1(new_n166_), .A2(new_n161_), .B(new_n167_), .Y(new_n168_));
  AND3x1_ASAP7_75t_R   g125(.A(new_n144_), .B(p8), .C(new_n72_), .Y(new_n169_));
  AND3x1_ASAP7_75t_R   g126(.A(new_n169_), .B(new_n145_), .C(new_n103_), .Y(new_n170_));
  NAND2x1_ASAP7_75t_R  g127(.A(new_n170_), .B(new_n161_), .Y(new_n171_));
  AND4x2_ASAP7_75t_R   g128(.A(new_n160_), .B(new_n164_), .C(new_n168_), .D(new_n171_), .Y(new_n172_));
  NOR2x1_ASAP7_75t_R   g129(.A(new_n138_), .B(new_n137_), .Y(new_n173_));
  AND3x1_ASAP7_75t_R   g130(.A(new_n145_), .B(new_n103_), .C(new_n173_), .Y(new_n174_));
  AOI22x1_ASAP7_75t_R  g131(.A1(new_n161_), .A2(new_n174_), .B1(new_n157_), .B2(new_n139_), .Y(new_n175_));
  AND3x1_ASAP7_75t_R   g132(.A(new_n145_), .B(new_n103_), .C(new_n155_), .Y(new_n176_));
  NOR2x1_ASAP7_75t_R   g133(.A(new_n135_), .B(new_n133_), .Y(new_n177_));
  AOI21x1_ASAP7_75t_R  g134(.A1(new_n176_), .A2(new_n161_), .B(new_n177_), .Y(new_n178_));
  NOR2x1_ASAP7_75t_R   g135(.A(new_n129_), .B(new_n128_), .Y(new_n179_));
  AND3x1_ASAP7_75t_R   g136(.A(new_n145_), .B(new_n103_), .C(new_n179_), .Y(new_n180_));
  AOI22x1_ASAP7_75t_R  g137(.A1(new_n161_), .A2(new_n180_), .B1(new_n148_), .B2(new_n130_), .Y(new_n181_));
  NAND2x1_ASAP7_75t_R  g138(.A(p6), .B(new_n62_), .Y(new_n182_));
  AOI21x1_ASAP7_75t_R  g139(.A1(p20), .A2(o1), .B(new_n182_), .Y(new_n183_));
  AND3x1_ASAP7_75t_R   g140(.A(new_n145_), .B(p29), .C(new_n183_), .Y(new_n184_));
  INVx1_ASAP7_75t_R    g141(.A(new_n103_), .Y(new_n185_));
  AOI21x1_ASAP7_75t_R  g142(.A1(new_n184_), .A2(new_n161_), .B(new_n185_), .Y(new_n186_));
  AND4x2_ASAP7_75t_R   g143(.A(new_n175_), .B(new_n178_), .C(new_n181_), .D(new_n186_), .Y(new_n187_));
  NAND2x1_ASAP7_75t_R  g144(.A(new_n69_), .B(new_n116_), .Y(new_n188_));
  AOI211x1_ASAP7_75t_R g145(.A1(p34), .A2(o2), .B(new_n70_), .C(new_n188_), .Y(new_n189_));
  AOI21x1_ASAP7_75t_R  g146(.A1(new_n172_), .A2(new_n187_), .B(new_n189_), .Y(o3));
  INVx1_ASAP7_75t_R    g147(.A(new_n172_), .Y(o4));
  AO31x2_ASAP7_75t_R   g148(.A1(new_n147_), .A2(new_n150_), .A3(new_n158_), .B(new_n110_), .Y(new_n192_));
  NAND3x1_ASAP7_75t_R  g149(.A(new_n144_), .B(p8), .C(new_n72_), .Y(new_n193_));
  AOI21x1_ASAP7_75t_R  g150(.A1(new_n103_), .A2(new_n107_), .B(new_n110_), .Y(new_n194_));
  NOR2x1_ASAP7_75t_R   g151(.A(new_n193_), .B(new_n194_), .Y(new_n195_));
  OA31x2_ASAP7_75t_R   g152(.A1(new_n132_), .A2(new_n141_), .A3(new_n120_), .B1(p29), .Y(new_n196_));
  OAI21x1_ASAP7_75t_R  g153(.A1(new_n98_), .A2(new_n145_), .B(new_n183_), .Y(new_n197_));
  AOI211x1_ASAP7_75t_R g154(.A1(new_n192_), .A2(new_n195_), .B(new_n196_), .C(new_n197_), .Y(new_n198_));
  AO31x2_ASAP7_75t_R   g155(.A1(new_n147_), .A2(new_n150_), .A3(new_n158_), .B(new_n104_), .Y(new_n199_));
  INVx1_ASAP7_75t_R    g156(.A(new_n143_), .Y(new_n200_));
  AOI21x1_ASAP7_75t_R  g157(.A1(p31), .A2(new_n113_), .B(new_n200_), .Y(new_n201_));
  INVx1_ASAP7_75t_R    g158(.A(new_n165_), .Y(new_n202_));
  AOI21x1_ASAP7_75t_R  g159(.A1(p32), .A2(new_n113_), .B(new_n202_), .Y(new_n203_));
  AO31x2_ASAP7_75t_R   g160(.A1(new_n147_), .A2(new_n150_), .A3(new_n158_), .B(new_n122_), .Y(new_n204_));
  AOI22x1_ASAP7_75t_R  g161(.A1(new_n199_), .A2(new_n201_), .B1(new_n203_), .B2(new_n204_), .Y(new_n205_));
  NAND2x1_ASAP7_75t_R  g162(.A(new_n168_), .B(new_n164_), .Y(new_n206_));
  OAI21x1_ASAP7_75t_R  g163(.A1(new_n146_), .A2(new_n159_), .B(new_n145_), .Y(new_n207_));
  AOI211x1_ASAP7_75t_R g164(.A1(new_n161_), .A2(new_n170_), .B(new_n207_), .C(new_n181_), .Y(new_n208_));
  AO211x2_ASAP7_75t_R  g165(.A1(new_n198_), .A2(new_n205_), .B(new_n206_), .C(new_n208_), .Y(o5));
  INVx1_ASAP7_75t_R    g166(.A(new_n168_), .Y(new_n210_));
  AO21x1_ASAP7_75t_R   g167(.A1(new_n176_), .A2(new_n161_), .B(new_n177_), .Y(new_n211_));
  AOI22x1_ASAP7_75t_R  g168(.A1(new_n211_), .A2(new_n181_), .B1(new_n199_), .B2(new_n201_), .Y(new_n212_));
  INVx1_ASAP7_75t_R    g169(.A(new_n164_), .Y(new_n213_));
  AOI21x1_ASAP7_75t_R  g170(.A1(new_n205_), .A2(new_n198_), .B(new_n213_), .Y(new_n214_));
  OAI21x1_ASAP7_75t_R  g171(.A1(new_n210_), .A2(new_n212_), .B(new_n214_), .Y(o6));
endmodule


