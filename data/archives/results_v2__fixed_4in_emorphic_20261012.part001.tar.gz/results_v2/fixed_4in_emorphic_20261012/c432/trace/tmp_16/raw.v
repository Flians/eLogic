// Benchmark "/tmp/" written by ABC on Mon Oct 12 15:06:05 2026

module \/tmp/  ( 
    p26, p11, p29, p21, p27, p0, p25, p18, p9, p22, p19, p33, p23, p7, p32,
    p20, p17, p30, p2, p15, p35, p16, p10, p1, p28, p24, p13, p6, p3, p4,
    p34, p14, p8, p12, p31, p5,
    o0, o1, o2, o3, o4, o5, o6  );
  input  p26, p11, p29, p21, p27, p0, p25, p18, p9, p22, p19, p33, p23,
    p7, p32, p20, p17, p30, p2, p15, p35, p16, p10, p1, p28, p24, p13, p6,
    p3, p4, p34, p14, p8, p12, p31, p5;
  output o0, o1, o2, o3, o4, o5, o6;
  wire new_n44_, new_n45_, new_n46_, new_n47_, new_n48_, new_n49_, new_n50_,
    new_n51_, new_n52_, new_n53_, new_n54_, new_n55_, new_n56_, new_n57_,
    new_n58_, new_n59_, new_n60_, new_n61_, new_n63_, new_n64_, new_n65_,
    new_n66_, new_n67_, new_n68_, new_n69_, new_n70_, new_n71_, new_n72_,
    new_n73_, new_n74_, new_n75_, new_n76_, new_n77_, new_n78_, new_n79_,
    new_n80_, new_n81_, new_n82_, new_n83_, new_n84_, new_n85_, new_n86_,
    new_n87_, new_n88_, new_n89_, new_n90_, new_n91_, new_n92_, new_n93_,
    new_n94_, new_n95_, new_n96_, new_n97_, new_n98_, new_n99_, new_n100_,
    new_n101_, new_n102_, new_n103_, new_n104_, new_n105_, new_n106_,
    new_n108_, new_n109_, new_n110_, new_n111_, new_n112_, new_n113_,
    new_n114_, new_n115_, new_n116_, new_n117_, new_n118_, new_n119_,
    new_n120_, new_n121_, new_n122_, new_n123_, new_n124_, new_n125_,
    new_n126_, new_n127_, new_n128_, new_n129_, new_n130_, new_n131_,
    new_n132_, new_n133_, new_n134_, new_n135_, new_n136_, new_n137_,
    new_n138_, new_n139_, new_n140_, new_n141_, new_n142_, new_n143_,
    new_n144_, new_n145_, new_n146_, new_n147_, new_n148_, new_n149_,
    new_n150_, new_n152_, new_n153_, new_n154_, new_n155_, new_n156_,
    new_n157_, new_n158_, new_n159_, new_n160_, new_n161_, new_n162_,
    new_n163_, new_n164_, new_n165_, new_n166_, new_n167_, new_n168_,
    new_n169_, new_n170_, new_n171_, new_n172_, new_n173_, new_n174_,
    new_n175_, new_n176_, new_n177_, new_n178_, new_n179_, new_n180_,
    new_n181_, new_n182_, new_n183_, new_n184_, new_n185_, new_n186_,
    new_n187_, new_n188_, new_n189_, new_n190_, new_n191_, new_n192_,
    new_n193_, new_n194_, new_n195_, new_n196_, new_n197_, new_n198_,
    new_n199_, new_n200_, new_n201_, new_n202_, new_n203_, new_n204_,
    new_n205_, new_n206_, new_n207_, new_n208_, new_n209_, new_n210_,
    new_n211_, new_n212_, new_n213_, new_n214_, new_n215_, new_n216_,
    new_n217_, new_n218_, new_n219_, new_n220_, new_n221_, new_n222_,
    new_n223_, new_n224_, new_n225_, new_n226_, new_n227_, new_n228_,
    new_n229_, new_n230_, new_n233_, new_n234_, new_n235_, new_n236_,
    new_n237_, new_n238_, new_n239_, new_n240_, new_n241_, new_n242_,
    new_n243_, new_n244_, new_n245_, new_n246_, new_n248_, new_n249_,
    new_n250_, new_n251_, new_n252_, new_n253_, new_n254_, new_n255_;
  INVx1_ASAP7_75t_R    g000(.A(p7), .Y(new_n44_));
  INVx1_ASAP7_75t_R    g001(.A(p5), .Y(new_n45_));
  AOI22x1_ASAP7_75t_R  g002(.A1(new_n44_), .A2(p8), .B1(new_n45_), .B2(p6), .Y(new_n46_));
  INVx1_ASAP7_75t_R    g003(.A(p3), .Y(new_n47_));
  NAND2x1_ASAP7_75t_R  g004(.A(p4), .B(new_n47_), .Y(new_n48_));
  INVx1_ASAP7_75t_R    g005(.A(p9), .Y(new_n49_));
  NAND2x1_ASAP7_75t_R  g006(.A(p10), .B(new_n49_), .Y(new_n50_));
  AND3x1_ASAP7_75t_R   g007(.A(new_n46_), .B(new_n48_), .C(new_n50_), .Y(new_n51_));
  INVx1_ASAP7_75t_R    g008(.A(p0), .Y(new_n52_));
  INVx1_ASAP7_75t_R    g009(.A(p2), .Y(new_n53_));
  OAI22x1_ASAP7_75t_R  g010(.A1(new_n52_), .A2(p35), .B1(new_n53_), .B2(p1), .Y(new_n54_));
  INVx1_ASAP7_75t_R    g011(.A(p16), .Y(new_n55_));
  INVx1_ASAP7_75t_R    g012(.A(p14), .Y(new_n56_));
  OAI22x1_ASAP7_75t_R  g013(.A1(p15), .A2(new_n55_), .B1(new_n56_), .B2(p13), .Y(new_n57_));
  INVx1_ASAP7_75t_R    g014(.A(p12), .Y(new_n58_));
  INVx1_ASAP7_75t_R    g015(.A(p4), .Y(new_n59_));
  OAI22x1_ASAP7_75t_R  g016(.A1(p11), .A2(new_n58_), .B1(new_n59_), .B2(p3), .Y(new_n60_));
  NOR3x1_ASAP7_75t_R   g017(.A(new_n54_), .B(new_n57_), .C(new_n60_), .Y(new_n61_));
  NAND2x1_ASAP7_75t_R  g018(.A(new_n51_), .B(new_n61_), .Y(o0));
  NAND3x1_ASAP7_75t_R  g019(.A(new_n46_), .B(new_n48_), .C(new_n50_), .Y(new_n63_));
  INVx1_ASAP7_75t_R    g020(.A(p35), .Y(new_n64_));
  INVx1_ASAP7_75t_R    g021(.A(p1), .Y(new_n65_));
  AOI22x1_ASAP7_75t_R  g022(.A1(p0), .A2(new_n64_), .B1(new_n65_), .B2(p2), .Y(new_n66_));
  INVx1_ASAP7_75t_R    g023(.A(p15), .Y(new_n67_));
  INVx1_ASAP7_75t_R    g024(.A(p13), .Y(new_n68_));
  AOI22x1_ASAP7_75t_R  g025(.A1(new_n67_), .A2(p16), .B1(new_n68_), .B2(p14), .Y(new_n69_));
  INVx1_ASAP7_75t_R    g026(.A(p11), .Y(new_n70_));
  AOI22x1_ASAP7_75t_R  g027(.A1(new_n70_), .A2(p12), .B1(new_n47_), .B2(p4), .Y(new_n71_));
  NAND3x1_ASAP7_75t_R  g028(.A(new_n66_), .B(new_n69_), .C(new_n71_), .Y(new_n72_));
  OAI21x1_ASAP7_75t_R  g029(.A1(new_n63_), .A2(new_n72_), .B(p5), .Y(new_n73_));
  INVx1_ASAP7_75t_R    g030(.A(p20), .Y(new_n74_));
  AND2x2_ASAP7_75t_R   g031(.A(p6), .B(new_n74_), .Y(new_n75_));
  AOI21x1_ASAP7_75t_R  g032(.A1(new_n50_), .A2(new_n46_), .B(new_n68_), .Y(new_n76_));
  NOR2x1_ASAP7_75t_R   g033(.A(p24), .B(new_n56_), .Y(new_n77_));
  INVx1_ASAP7_75t_R    g034(.A(new_n77_), .Y(new_n78_));
  AOI211x1_ASAP7_75t_R g035(.A1(p13), .A2(new_n72_), .B(new_n76_), .C(new_n78_), .Y(new_n79_));
  NOR2x1_ASAP7_75t_R   g036(.A(p19), .B(new_n59_), .Y(new_n80_));
  INVx1_ASAP7_75t_R    g037(.A(p19), .Y(new_n81_));
  AND3x1_ASAP7_75t_R   g038(.A(new_n81_), .B(new_n47_), .C(p4), .Y(new_n82_));
  AO31x2_ASAP7_75t_R   g039(.A1(new_n61_), .A2(new_n51_), .A3(new_n80_), .B(new_n82_), .Y(new_n83_));
  AOI211x1_ASAP7_75t_R g040(.A1(new_n73_), .A2(new_n75_), .B(new_n79_), .C(new_n83_), .Y(new_n84_));
  AO21x1_ASAP7_75t_R   g041(.A1(new_n51_), .A2(new_n61_), .B(new_n65_), .Y(new_n85_));
  INVx1_ASAP7_75t_R    g042(.A(p18), .Y(new_n86_));
  NAND2x1_ASAP7_75t_R  g043(.A(p2), .B(new_n86_), .Y(new_n87_));
  INVx1_ASAP7_75t_R    g044(.A(new_n87_), .Y(new_n88_));
  OAI21x1_ASAP7_75t_R  g045(.A1(new_n63_), .A2(new_n72_), .B(p11), .Y(new_n89_));
  INVx1_ASAP7_75t_R    g046(.A(p23), .Y(new_n90_));
  NAND2x1_ASAP7_75t_R  g047(.A(p12), .B(new_n90_), .Y(new_n91_));
  INVx1_ASAP7_75t_R    g048(.A(new_n91_), .Y(new_n92_));
  AOI22x1_ASAP7_75t_R  g049(.A1(new_n85_), .A2(new_n88_), .B1(new_n89_), .B2(new_n92_), .Y(new_n93_));
  OAI21x1_ASAP7_75t_R  g050(.A1(new_n63_), .A2(new_n72_), .B(p9), .Y(new_n94_));
  INVx1_ASAP7_75t_R    g051(.A(p22), .Y(new_n95_));
  AND2x2_ASAP7_75t_R   g052(.A(p10), .B(new_n95_), .Y(new_n96_));
  OAI21x1_ASAP7_75t_R  g053(.A1(new_n63_), .A2(new_n72_), .B(p7), .Y(new_n97_));
  INVx1_ASAP7_75t_R    g054(.A(p21), .Y(new_n98_));
  AND2x2_ASAP7_75t_R   g055(.A(p8), .B(new_n98_), .Y(new_n99_));
  AOI22x1_ASAP7_75t_R  g056(.A1(new_n94_), .A2(new_n96_), .B1(new_n97_), .B2(new_n99_), .Y(new_n100_));
  OAI21x1_ASAP7_75t_R  g057(.A1(new_n63_), .A2(new_n72_), .B(p35), .Y(new_n101_));
  NOR2x1_ASAP7_75t_R   g058(.A(p17), .B(new_n52_), .Y(new_n102_));
  OAI21x1_ASAP7_75t_R  g059(.A1(new_n63_), .A2(new_n72_), .B(p15), .Y(new_n103_));
  NOR2x1_ASAP7_75t_R   g060(.A(p25), .B(new_n55_), .Y(new_n104_));
  AOI22x1_ASAP7_75t_R  g061(.A1(new_n101_), .A2(new_n102_), .B1(new_n103_), .B2(new_n104_), .Y(new_n105_));
  AND4x2_ASAP7_75t_R   g062(.A(new_n84_), .B(new_n93_), .C(new_n100_), .D(new_n105_), .Y(new_n106_));
  INVx1_ASAP7_75t_R    g063(.A(new_n106_), .Y(o1));
  INVx1_ASAP7_75t_R    g064(.A(p30), .Y(new_n108_));
  AND3x1_ASAP7_75t_R   g065(.A(new_n97_), .B(new_n108_), .C(p8), .Y(new_n109_));
  OAI21x1_ASAP7_75t_R  g066(.A1(new_n98_), .A2(new_n106_), .B(new_n109_), .Y(new_n110_));
  INVx1_ASAP7_75t_R    g067(.A(p29), .Y(new_n111_));
  AND3x1_ASAP7_75t_R   g068(.A(new_n73_), .B(new_n111_), .C(p6), .Y(new_n112_));
  OAI21x1_ASAP7_75t_R  g069(.A1(new_n74_), .A2(new_n106_), .B(new_n112_), .Y(new_n113_));
  INVx1_ASAP7_75t_R    g070(.A(p31), .Y(new_n114_));
  AND3x1_ASAP7_75t_R   g071(.A(new_n94_), .B(p10), .C(new_n114_), .Y(new_n115_));
  OAI21x1_ASAP7_75t_R  g072(.A1(new_n95_), .A2(new_n106_), .B(new_n115_), .Y(new_n116_));
  AND3x1_ASAP7_75t_R   g073(.A(new_n110_), .B(new_n113_), .C(new_n116_), .Y(new_n117_));
  NOR2x1_ASAP7_75t_R   g074(.A(new_n63_), .B(new_n72_), .Y(new_n118_));
  AOI21x1_ASAP7_75t_R  g075(.A1(new_n80_), .A2(new_n118_), .B(new_n82_), .Y(new_n119_));
  NAND2x1_ASAP7_75t_R  g076(.A(new_n119_), .B(new_n93_), .Y(new_n120_));
  AOI22x1_ASAP7_75t_R  g077(.A1(new_n73_), .A2(new_n75_), .B1(new_n94_), .B2(new_n96_), .Y(new_n121_));
  AOI22x1_ASAP7_75t_R  g078(.A1(new_n97_), .A2(new_n99_), .B1(new_n103_), .B2(new_n104_), .Y(new_n122_));
  AOI21x1_ASAP7_75t_R  g079(.A1(p13), .A2(new_n72_), .B(new_n76_), .Y(new_n123_));
  AOI22x1_ASAP7_75t_R  g080(.A1(new_n101_), .A2(new_n102_), .B1(new_n123_), .B2(new_n77_), .Y(new_n124_));
  NAND3x1_ASAP7_75t_R  g081(.A(new_n121_), .B(new_n122_), .C(new_n124_), .Y(new_n125_));
  OAI21x1_ASAP7_75t_R  g082(.A1(new_n120_), .A2(new_n125_), .B(p23), .Y(new_n126_));
  INVx1_ASAP7_75t_R    g083(.A(p32), .Y(new_n127_));
  AND3x1_ASAP7_75t_R   g084(.A(new_n89_), .B(new_n127_), .C(p12), .Y(new_n128_));
  OAI21x1_ASAP7_75t_R  g085(.A1(new_n120_), .A2(new_n125_), .B(p19), .Y(new_n129_));
  AO21x1_ASAP7_75t_R   g086(.A1(p3), .A2(o0), .B(new_n59_), .Y(new_n130_));
  NOR2x1_ASAP7_75t_R   g087(.A(p28), .B(new_n130_), .Y(new_n131_));
  AOI22x1_ASAP7_75t_R  g088(.A1(new_n126_), .A2(new_n128_), .B1(new_n129_), .B2(new_n131_), .Y(new_n132_));
  AOI21x1_ASAP7_75t_R  g089(.A1(p1), .A2(o0), .B(new_n53_), .Y(new_n133_));
  NAND3x1_ASAP7_75t_R  g090(.A(new_n93_), .B(new_n119_), .C(new_n133_), .Y(new_n134_));
  AO21x1_ASAP7_75t_R   g091(.A1(p1), .A2(o0), .B(new_n87_), .Y(new_n135_));
  OAI21x1_ASAP7_75t_R  g092(.A1(new_n125_), .A2(new_n134_), .B(new_n135_), .Y(new_n136_));
  INVx1_ASAP7_75t_R    g093(.A(p27), .Y(new_n137_));
  OAI21x1_ASAP7_75t_R  g094(.A1(new_n120_), .A2(new_n125_), .B(p17), .Y(new_n138_));
  INVx1_ASAP7_75t_R    g095(.A(p26), .Y(new_n139_));
  AND3x1_ASAP7_75t_R   g096(.A(new_n101_), .B(new_n139_), .C(p0), .Y(new_n140_));
  AOI22x1_ASAP7_75t_R  g097(.A1(new_n136_), .A2(new_n137_), .B1(new_n138_), .B2(new_n140_), .Y(new_n141_));
  OAI21x1_ASAP7_75t_R  g098(.A1(new_n120_), .A2(new_n125_), .B(p25), .Y(new_n142_));
  AOI21x1_ASAP7_75t_R  g099(.A1(new_n51_), .A2(new_n61_), .B(new_n67_), .Y(new_n143_));
  OR3x1_ASAP7_75t_R    g100(.A(new_n143_), .B(new_n55_), .C(p34), .Y(new_n144_));
  INVx1_ASAP7_75t_R    g101(.A(new_n144_), .Y(new_n145_));
  OAI21x1_ASAP7_75t_R  g102(.A1(new_n120_), .A2(new_n125_), .B(p24), .Y(new_n146_));
  INVx1_ASAP7_75t_R    g103(.A(p33), .Y(new_n147_));
  AND3x1_ASAP7_75t_R   g104(.A(new_n123_), .B(new_n147_), .C(p14), .Y(new_n148_));
  AOI22x1_ASAP7_75t_R  g105(.A1(new_n142_), .A2(new_n145_), .B1(new_n146_), .B2(new_n148_), .Y(new_n149_));
  AND3x1_ASAP7_75t_R   g106(.A(new_n132_), .B(new_n141_), .C(new_n149_), .Y(new_n150_));
  NAND2x1_ASAP7_75t_R  g107(.A(new_n117_), .B(new_n150_), .Y(o2));
  NAND2x1_ASAP7_75t_R  g108(.A(new_n92_), .B(new_n89_), .Y(new_n152_));
  AND3x1_ASAP7_75t_R   g109(.A(new_n135_), .B(new_n152_), .C(new_n119_), .Y(new_n153_));
  AOI21x1_ASAP7_75t_R  g110(.A1(new_n51_), .A2(new_n61_), .B(new_n45_), .Y(new_n154_));
  INVx1_ASAP7_75t_R    g111(.A(new_n75_), .Y(new_n155_));
  AOI21x1_ASAP7_75t_R  g112(.A1(new_n51_), .A2(new_n61_), .B(new_n49_), .Y(new_n156_));
  INVx1_ASAP7_75t_R    g113(.A(new_n96_), .Y(new_n157_));
  OAI22x1_ASAP7_75t_R  g114(.A1(new_n154_), .A2(new_n155_), .B1(new_n156_), .B2(new_n157_), .Y(new_n158_));
  AOI21x1_ASAP7_75t_R  g115(.A1(new_n51_), .A2(new_n61_), .B(new_n44_), .Y(new_n159_));
  INVx1_ASAP7_75t_R    g116(.A(new_n99_), .Y(new_n160_));
  INVx1_ASAP7_75t_R    g117(.A(new_n104_), .Y(new_n161_));
  OAI22x1_ASAP7_75t_R  g118(.A1(new_n159_), .A2(new_n160_), .B1(new_n143_), .B2(new_n161_), .Y(new_n162_));
  AOI21x1_ASAP7_75t_R  g119(.A1(new_n51_), .A2(new_n61_), .B(new_n64_), .Y(new_n163_));
  INVx1_ASAP7_75t_R    g120(.A(new_n102_), .Y(new_n164_));
  AO31x2_ASAP7_75t_R   g121(.A1(new_n66_), .A2(new_n69_), .A3(new_n71_), .B(new_n68_), .Y(new_n165_));
  AO21x1_ASAP7_75t_R   g122(.A1(new_n50_), .A2(new_n46_), .B(new_n68_), .Y(new_n166_));
  NAND3x1_ASAP7_75t_R  g123(.A(new_n165_), .B(new_n166_), .C(new_n77_), .Y(new_n167_));
  OAI21x1_ASAP7_75t_R  g124(.A1(new_n163_), .A2(new_n164_), .B(new_n167_), .Y(new_n168_));
  NOR3x1_ASAP7_75t_R   g125(.A(new_n158_), .B(new_n162_), .C(new_n168_), .Y(new_n169_));
  AOI21x1_ASAP7_75t_R  g126(.A1(new_n153_), .A2(new_n169_), .B(new_n81_), .Y(new_n170_));
  INVx1_ASAP7_75t_R    g127(.A(new_n131_), .Y(new_n171_));
  AO31x2_ASAP7_75t_R   g128(.A1(new_n121_), .A2(new_n122_), .A3(new_n124_), .B(new_n90_), .Y(new_n172_));
  AO21x1_ASAP7_75t_R   g129(.A1(new_n119_), .A2(new_n135_), .B(new_n90_), .Y(new_n173_));
  NAND3x1_ASAP7_75t_R  g130(.A(new_n172_), .B(new_n173_), .C(new_n128_), .Y(new_n174_));
  OAI21x1_ASAP7_75t_R  g131(.A1(new_n170_), .A2(new_n171_), .B(new_n174_), .Y(new_n175_));
  AND4x2_ASAP7_75t_R   g132(.A(new_n119_), .B(new_n133_), .C(new_n152_), .D(p18), .Y(new_n176_));
  AOI22x1_ASAP7_75t_R  g133(.A1(new_n169_), .A2(new_n176_), .B1(new_n85_), .B2(new_n88_), .Y(new_n177_));
  INVx1_ASAP7_75t_R    g134(.A(p17), .Y(new_n178_));
  AO31x2_ASAP7_75t_R   g135(.A1(new_n121_), .A2(new_n122_), .A3(new_n124_), .B(new_n178_), .Y(new_n179_));
  AO21x1_ASAP7_75t_R   g136(.A1(new_n119_), .A2(new_n93_), .B(new_n178_), .Y(new_n180_));
  NAND3x1_ASAP7_75t_R  g137(.A(new_n179_), .B(new_n180_), .C(new_n140_), .Y(new_n181_));
  OAI21x1_ASAP7_75t_R  g138(.A1(p27), .A2(new_n177_), .B(new_n181_), .Y(new_n182_));
  INVx1_ASAP7_75t_R    g139(.A(p25), .Y(new_n183_));
  AOI21x1_ASAP7_75t_R  g140(.A1(new_n153_), .A2(new_n169_), .B(new_n183_), .Y(new_n184_));
  INVx1_ASAP7_75t_R    g141(.A(p24), .Y(new_n185_));
  AO31x2_ASAP7_75t_R   g142(.A1(new_n121_), .A2(new_n122_), .A3(new_n124_), .B(new_n185_), .Y(new_n186_));
  AO21x1_ASAP7_75t_R   g143(.A1(new_n119_), .A2(new_n93_), .B(new_n185_), .Y(new_n187_));
  NAND3x1_ASAP7_75t_R  g144(.A(new_n186_), .B(new_n187_), .C(new_n148_), .Y(new_n188_));
  OAI21x1_ASAP7_75t_R  g145(.A1(new_n184_), .A2(new_n144_), .B(new_n188_), .Y(new_n189_));
  OA31x2_ASAP7_75t_R   g146(.A1(new_n175_), .A2(new_n182_), .A3(new_n189_), .B1(p32), .Y(new_n190_));
  NAND2x1_ASAP7_75t_R  g147(.A(p12), .B(new_n89_), .Y(new_n191_));
  INVx1_ASAP7_75t_R    g148(.A(new_n191_), .Y(new_n192_));
  AND3x1_ASAP7_75t_R   g149(.A(new_n172_), .B(new_n192_), .C(new_n173_), .Y(new_n193_));
  OAI21x1_ASAP7_75t_R  g150(.A1(new_n127_), .A2(new_n117_), .B(new_n193_), .Y(new_n194_));
  OA211x2_ASAP7_75t_R  g151(.A1(new_n185_), .A2(new_n106_), .B(p14), .C(new_n123_), .Y(new_n195_));
  AO31x2_ASAP7_75t_R   g152(.A1(new_n110_), .A2(new_n113_), .A3(new_n116_), .B(new_n147_), .Y(new_n196_));
  NAND2x1_ASAP7_75t_R  g153(.A(new_n195_), .B(new_n196_), .Y(new_n197_));
  NOR2x1_ASAP7_75t_R   g154(.A(new_n144_), .B(new_n184_), .Y(new_n198_));
  OA31x2_ASAP7_75t_R   g155(.A1(new_n198_), .A2(new_n175_), .A3(new_n182_), .B1(p33), .Y(new_n199_));
  OAI22x1_ASAP7_75t_R  g156(.A1(new_n190_), .A2(new_n194_), .B1(new_n197_), .B2(new_n199_), .Y(new_n200_));
  NAND3x1_ASAP7_75t_R  g157(.A(new_n110_), .B(new_n113_), .C(new_n116_), .Y(new_n201_));
  AND2x2_ASAP7_75t_R   g158(.A(p10), .B(new_n94_), .Y(new_n202_));
  AO21x1_ASAP7_75t_R   g159(.A1(new_n153_), .A2(new_n169_), .B(new_n95_), .Y(new_n203_));
  NAND2x1_ASAP7_75t_R  g160(.A(new_n202_), .B(new_n203_), .Y(new_n204_));
  AO21x1_ASAP7_75t_R   g161(.A1(p31), .A2(new_n201_), .B(new_n204_), .Y(new_n205_));
  OA31x2_ASAP7_75t_R   g162(.A1(new_n175_), .A2(new_n182_), .A3(new_n189_), .B1(p31), .Y(new_n206_));
  OA31x2_ASAP7_75t_R   g163(.A1(new_n175_), .A2(new_n182_), .A3(new_n189_), .B1(p30), .Y(new_n207_));
  NAND2x1_ASAP7_75t_R  g164(.A(new_n113_), .B(new_n116_), .Y(new_n208_));
  NAND2x1_ASAP7_75t_R  g165(.A(p8), .B(new_n97_), .Y(new_n209_));
  AO21x1_ASAP7_75t_R   g166(.A1(p21), .A2(o1), .B(new_n209_), .Y(new_n210_));
  AO21x1_ASAP7_75t_R   g167(.A1(p30), .A2(new_n208_), .B(new_n210_), .Y(new_n211_));
  OAI22x1_ASAP7_75t_R  g168(.A1(new_n205_), .A2(new_n206_), .B1(new_n207_), .B2(new_n211_), .Y(new_n212_));
  NOR2x1_ASAP7_75t_R   g169(.A(new_n200_), .B(new_n212_), .Y(new_n213_));
  OA31x2_ASAP7_75t_R   g170(.A1(new_n175_), .A2(new_n182_), .A3(new_n189_), .B1(p26), .Y(new_n214_));
  AND3x1_ASAP7_75t_R   g171(.A(new_n138_), .B(p0), .C(new_n101_), .Y(new_n215_));
  OAI21x1_ASAP7_75t_R  g172(.A1(new_n139_), .A2(new_n117_), .B(new_n215_), .Y(new_n216_));
  OA31x2_ASAP7_75t_R   g173(.A1(new_n175_), .A2(new_n182_), .A3(new_n189_), .B1(p27), .Y(new_n217_));
  AO31x2_ASAP7_75t_R   g174(.A1(new_n110_), .A2(new_n113_), .A3(new_n116_), .B(new_n137_), .Y(new_n218_));
  NAND2x1_ASAP7_75t_R  g175(.A(new_n136_), .B(new_n218_), .Y(new_n219_));
  OAI22x1_ASAP7_75t_R  g176(.A1(new_n214_), .A2(new_n216_), .B1(new_n217_), .B2(new_n219_), .Y(new_n220_));
  AO21x1_ASAP7_75t_R   g177(.A1(p19), .A2(o1), .B(new_n130_), .Y(new_n221_));
  AO21x1_ASAP7_75t_R   g178(.A1(p28), .A2(new_n201_), .B(new_n221_), .Y(new_n222_));
  OA31x2_ASAP7_75t_R   g179(.A1(new_n175_), .A2(new_n182_), .A3(new_n189_), .B1(p28), .Y(new_n223_));
  OA31x2_ASAP7_75t_R   g180(.A1(new_n175_), .A2(new_n182_), .A3(new_n189_), .B1(p29), .Y(new_n224_));
  OA211x2_ASAP7_75t_R  g181(.A1(new_n74_), .A2(new_n106_), .B(p6), .C(new_n73_), .Y(new_n225_));
  OAI21x1_ASAP7_75t_R  g182(.A1(new_n111_), .A2(new_n117_), .B(new_n225_), .Y(new_n226_));
  OAI22x1_ASAP7_75t_R  g183(.A1(new_n222_), .A2(new_n223_), .B1(new_n224_), .B2(new_n226_), .Y(new_n227_));
  NOR2x1_ASAP7_75t_R   g184(.A(new_n220_), .B(new_n227_), .Y(new_n228_));
  OR3x1_ASAP7_75t_R    g185(.A(new_n184_), .B(new_n55_), .C(new_n143_), .Y(new_n229_));
  AOI21x1_ASAP7_75t_R  g186(.A1(p34), .A2(o2), .B(new_n229_), .Y(new_n230_));
  AOI21x1_ASAP7_75t_R  g187(.A1(new_n213_), .A2(new_n228_), .B(new_n230_), .Y(o3));
  INVx1_ASAP7_75t_R    g188(.A(new_n213_), .Y(o4));
  AOI21x1_ASAP7_75t_R  g189(.A1(p30), .A2(new_n208_), .B(new_n210_), .Y(new_n233_));
  AO31x2_ASAP7_75t_R   g190(.A1(new_n132_), .A2(new_n141_), .A3(new_n149_), .B(new_n108_), .Y(new_n234_));
  AO31x2_ASAP7_75t_R   g191(.A1(new_n132_), .A2(new_n141_), .A3(new_n149_), .B(new_n114_), .Y(new_n235_));
  AOI21x1_ASAP7_75t_R  g192(.A1(new_n110_), .A2(new_n113_), .B(new_n114_), .Y(new_n236_));
  NOR2x1_ASAP7_75t_R   g193(.A(new_n204_), .B(new_n236_), .Y(new_n237_));
  AOI22x1_ASAP7_75t_R  g194(.A1(new_n233_), .A2(new_n234_), .B1(new_n235_), .B2(new_n237_), .Y(new_n238_));
  NOR2x1_ASAP7_75t_R   g195(.A(new_n226_), .B(new_n224_), .Y(new_n239_));
  AO31x2_ASAP7_75t_R   g196(.A1(new_n132_), .A2(new_n141_), .A3(new_n149_), .B(new_n127_), .Y(new_n240_));
  INVx1_ASAP7_75t_R    g197(.A(new_n193_), .Y(new_n241_));
  AOI21x1_ASAP7_75t_R  g198(.A1(p32), .A2(new_n201_), .B(new_n241_), .Y(new_n242_));
  NAND2x1_ASAP7_75t_R  g199(.A(new_n240_), .B(new_n242_), .Y(new_n243_));
  NAND3x1_ASAP7_75t_R  g200(.A(new_n238_), .B(new_n239_), .C(new_n243_), .Y(new_n244_));
  NOR2x1_ASAP7_75t_R   g201(.A(new_n223_), .B(new_n222_), .Y(new_n245_));
  AOI21x1_ASAP7_75t_R  g202(.A1(new_n238_), .A2(new_n245_), .B(new_n200_), .Y(new_n246_));
  NAND2x1_ASAP7_75t_R  g203(.A(new_n244_), .B(new_n246_), .Y(o5));
  AOI22x1_ASAP7_75t_R  g204(.A1(new_n242_), .A2(new_n240_), .B1(new_n235_), .B2(new_n237_), .Y(new_n248_));
  NOR2x1_ASAP7_75t_R   g205(.A(new_n219_), .B(new_n217_), .Y(new_n249_));
  NOR2x1_ASAP7_75t_R   g206(.A(new_n221_), .B(new_n201_), .Y(new_n250_));
  AOI22x1_ASAP7_75t_R  g207(.A1(new_n250_), .A2(new_n150_), .B1(new_n129_), .B2(new_n131_), .Y(new_n251_));
  NAND3x1_ASAP7_75t_R  g208(.A(new_n248_), .B(new_n249_), .C(new_n251_), .Y(new_n252_));
  NOR2x1_ASAP7_75t_R   g209(.A(new_n206_), .B(new_n205_), .Y(new_n253_));
  NOR2x1_ASAP7_75t_R   g210(.A(new_n199_), .B(new_n197_), .Y(new_n254_));
  AOI21x1_ASAP7_75t_R  g211(.A1(new_n243_), .A2(new_n253_), .B(new_n254_), .Y(new_n255_));
  NAND3x1_ASAP7_75t_R  g212(.A(new_n244_), .B(new_n252_), .C(new_n255_), .Y(o6));
endmodule


