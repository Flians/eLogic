// Benchmark "/tmp/" written by ABC on Mon Oct 12 15:06:04 2026

module \/tmp/  ( 
    p24, p9, p0, p34, p8, p4, p35, p1, p3, p20, p31, p25, p19, p16, p23,
    p11, p5, p29, p13, p7, p17, p6, p22, p18, p12, p10, p15, p27, p32, p2,
    p30, p33, p28, p26, p14, p21,
    o0, o1, o2, o3, o4, o5, o6  );
  input  p24, p9, p0, p34, p8, p4, p35, p1, p3, p20, p31, p25, p19, p16,
    p23, p11, p5, p29, p13, p7, p17, p6, p22, p18, p12, p10, p15, p27, p32,
    p2, p30, p33, p28, p26, p14, p21;
  output o0, o1, o2, o3, o4, o5, o6;
  wire new_n44_, new_n45_, new_n46_, new_n47_, new_n48_, new_n49_, new_n50_,
    new_n51_, new_n52_, new_n53_, new_n54_, new_n55_, new_n56_, new_n57_,
    new_n58_, new_n60_, new_n61_, new_n62_, new_n63_, new_n64_, new_n65_,
    new_n66_, new_n67_, new_n68_, new_n69_, new_n70_, new_n71_, new_n72_,
    new_n73_, new_n74_, new_n75_, new_n76_, new_n77_, new_n78_, new_n79_,
    new_n80_, new_n81_, new_n82_, new_n83_, new_n84_, new_n85_, new_n86_,
    new_n87_, new_n88_, new_n89_, new_n90_, new_n91_, new_n92_, new_n93_,
    new_n94_, new_n95_, new_n96_, new_n97_, new_n98_, new_n99_, new_n100_,
    new_n101_, new_n102_, new_n103_, new_n104_, new_n105_, new_n106_,
    new_n107_, new_n108_, new_n110_, new_n111_, new_n112_, new_n113_,
    new_n114_, new_n115_, new_n116_, new_n117_, new_n118_, new_n119_,
    new_n120_, new_n121_, new_n122_, new_n123_, new_n124_, new_n125_,
    new_n126_, new_n127_, new_n128_, new_n129_, new_n130_, new_n131_,
    new_n132_, new_n133_, new_n134_, new_n135_, new_n136_, new_n137_,
    new_n138_, new_n139_, new_n140_, new_n141_, new_n142_, new_n143_,
    new_n144_, new_n145_, new_n146_, new_n147_, new_n148_, new_n149_,
    new_n150_, new_n151_, new_n152_, new_n153_, new_n154_, new_n155_,
    new_n156_, new_n157_, new_n158_, new_n159_, new_n160_, new_n161_,
    new_n162_, new_n163_, new_n164_, new_n165_, new_n166_, new_n167_,
    new_n168_, new_n169_, new_n170_, new_n171_, new_n172_, new_n173_,
    new_n174_, new_n175_, new_n176_, new_n177_, new_n178_, new_n179_,
    new_n180_, new_n181_, new_n182_, new_n183_, new_n184_, new_n186_,
    new_n187_, new_n188_, new_n189_, new_n190_, new_n191_, new_n192_,
    new_n193_, new_n194_, new_n195_, new_n196_, new_n197_, new_n198_,
    new_n199_, new_n200_, new_n201_, new_n202_, new_n203_, new_n204_,
    new_n205_, new_n206_, new_n207_, new_n208_, new_n209_, new_n210_,
    new_n211_, new_n212_, new_n213_, new_n214_, new_n215_, new_n216_,
    new_n217_, new_n218_, new_n219_, new_n220_, new_n221_, new_n222_,
    new_n223_, new_n224_, new_n225_, new_n226_, new_n227_, new_n228_,
    new_n229_, new_n230_, new_n231_, new_n232_, new_n233_, new_n234_,
    new_n237_, new_n238_, new_n239_, new_n240_, new_n241_, new_n242_,
    new_n243_, new_n244_, new_n245_, new_n246_, new_n247_, new_n248_,
    new_n249_, new_n250_, new_n251_, new_n252_, new_n253_, new_n254_,
    new_n255_, new_n256_, new_n257_, new_n258_, new_n259_, new_n260_,
    new_n261_, new_n263_, new_n264_, new_n265_;
  INVx1_ASAP7_75t_R    g000(.A(p3), .Y(new_n44_));
  INVx1_ASAP7_75t_R    g001(.A(p12), .Y(new_n45_));
  NOR2x1_ASAP7_75t_R   g002(.A(p11), .B(new_n45_), .Y(new_n46_));
  INVx1_ASAP7_75t_R    g003(.A(p16), .Y(new_n47_));
  INVx1_ASAP7_75t_R    g004(.A(p14), .Y(new_n48_));
  OAI22x1_ASAP7_75t_R  g005(.A1(new_n47_), .A2(p15), .B1(new_n48_), .B2(p13), .Y(new_n49_));
  AOI211x1_ASAP7_75t_R g006(.A1(p4), .A2(new_n44_), .B(new_n46_), .C(new_n49_), .Y(new_n50_));
  INVx1_ASAP7_75t_R    g007(.A(p5), .Y(new_n51_));
  INVx1_ASAP7_75t_R    g008(.A(p10), .Y(new_n52_));
  INVx1_ASAP7_75t_R    g009(.A(p8), .Y(new_n53_));
  OAI22x1_ASAP7_75t_R  g010(.A1(p9), .A2(new_n52_), .B1(new_n53_), .B2(p7), .Y(new_n54_));
  INVx1_ASAP7_75t_R    g011(.A(p0), .Y(new_n55_));
  INVx1_ASAP7_75t_R    g012(.A(p2), .Y(new_n56_));
  OAI22x1_ASAP7_75t_R  g013(.A1(new_n55_), .A2(p35), .B1(new_n56_), .B2(p1), .Y(new_n57_));
  AOI211x1_ASAP7_75t_R g014(.A1(new_n51_), .A2(p6), .B(new_n54_), .C(new_n57_), .Y(new_n58_));
  NAND2x1_ASAP7_75t_R  g015(.A(new_n50_), .B(new_n58_), .Y(o0));
  INVx1_ASAP7_75t_R    g016(.A(p15), .Y(new_n60_));
  INVx1_ASAP7_75t_R    g017(.A(p13), .Y(new_n61_));
  AOI22x1_ASAP7_75t_R  g018(.A1(p16), .A2(new_n60_), .B1(new_n61_), .B2(p14), .Y(new_n62_));
  INVx1_ASAP7_75t_R    g019(.A(p11), .Y(new_n63_));
  AOI22x1_ASAP7_75t_R  g020(.A1(p4), .A2(new_n44_), .B1(new_n63_), .B2(p12), .Y(new_n64_));
  NAND2x1_ASAP7_75t_R  g021(.A(new_n62_), .B(new_n64_), .Y(new_n65_));
  INVx1_ASAP7_75t_R    g022(.A(p9), .Y(new_n66_));
  INVx1_ASAP7_75t_R    g023(.A(p7), .Y(new_n67_));
  AOI22x1_ASAP7_75t_R  g024(.A1(new_n66_), .A2(p10), .B1(new_n67_), .B2(p8), .Y(new_n68_));
  INVx1_ASAP7_75t_R    g025(.A(p35), .Y(new_n69_));
  INVx1_ASAP7_75t_R    g026(.A(p1), .Y(new_n70_));
  AOI22x1_ASAP7_75t_R  g027(.A1(p0), .A2(new_n69_), .B1(new_n70_), .B2(p2), .Y(new_n71_));
  NAND2x1_ASAP7_75t_R  g028(.A(p6), .B(new_n51_), .Y(new_n72_));
  NAND3x1_ASAP7_75t_R  g029(.A(new_n68_), .B(new_n71_), .C(new_n72_), .Y(new_n73_));
  OAI21x1_ASAP7_75t_R  g030(.A1(new_n65_), .A2(new_n73_), .B(p5), .Y(new_n74_));
  INVx1_ASAP7_75t_R    g031(.A(p6), .Y(new_n75_));
  NOR2x1_ASAP7_75t_R   g032(.A(p20), .B(new_n75_), .Y(new_n76_));
  INVx1_ASAP7_75t_R    g033(.A(p4), .Y(new_n77_));
  NOR2x1_ASAP7_75t_R   g034(.A(p19), .B(new_n77_), .Y(new_n78_));
  NAND2x1_ASAP7_75t_R  g035(.A(p4), .B(new_n44_), .Y(new_n79_));
  OAI21x1_ASAP7_75t_R  g036(.A1(new_n65_), .A2(new_n73_), .B(new_n79_), .Y(new_n80_));
  AND2x2_ASAP7_75t_R   g037(.A(new_n78_), .B(new_n80_), .Y(new_n81_));
  AOI21x1_ASAP7_75t_R  g038(.A1(new_n50_), .A2(new_n58_), .B(new_n63_), .Y(new_n82_));
  NOR2x1_ASAP7_75t_R   g039(.A(p23), .B(new_n45_), .Y(new_n83_));
  INVx1_ASAP7_75t_R    g040(.A(new_n83_), .Y(new_n84_));
  AO31x2_ASAP7_75t_R   g041(.A1(new_n62_), .A2(new_n64_), .A3(new_n71_), .B(new_n70_), .Y(new_n85_));
  AO21x1_ASAP7_75t_R   g042(.A1(new_n72_), .A2(new_n68_), .B(new_n70_), .Y(new_n86_));
  NOR2x1_ASAP7_75t_R   g043(.A(p18), .B(new_n56_), .Y(new_n87_));
  NAND3x1_ASAP7_75t_R  g044(.A(new_n85_), .B(new_n86_), .C(new_n87_), .Y(new_n88_));
  OAI21x1_ASAP7_75t_R  g045(.A1(new_n82_), .A2(new_n84_), .B(new_n88_), .Y(new_n89_));
  AOI211x1_ASAP7_75t_R g046(.A1(new_n74_), .A2(new_n76_), .B(new_n81_), .C(new_n89_), .Y(new_n90_));
  OAI21x1_ASAP7_75t_R  g047(.A1(new_n65_), .A2(new_n73_), .B(p13), .Y(new_n91_));
  NOR2x1_ASAP7_75t_R   g048(.A(p24), .B(new_n48_), .Y(new_n92_));
  AOI21x1_ASAP7_75t_R  g049(.A1(new_n50_), .A2(new_n58_), .B(new_n69_), .Y(new_n93_));
  NOR2x1_ASAP7_75t_R   g050(.A(p17), .B(new_n55_), .Y(new_n94_));
  INVx1_ASAP7_75t_R    g051(.A(new_n94_), .Y(new_n95_));
  AO31x2_ASAP7_75t_R   g052(.A1(new_n62_), .A2(new_n64_), .A3(new_n71_), .B(new_n60_), .Y(new_n96_));
  AO21x1_ASAP7_75t_R   g053(.A1(new_n72_), .A2(new_n68_), .B(new_n60_), .Y(new_n97_));
  NOR2x1_ASAP7_75t_R   g054(.A(p25), .B(new_n47_), .Y(new_n98_));
  NAND3x1_ASAP7_75t_R  g055(.A(new_n96_), .B(new_n97_), .C(new_n98_), .Y(new_n99_));
  OAI21x1_ASAP7_75t_R  g056(.A1(new_n93_), .A2(new_n95_), .B(new_n99_), .Y(new_n100_));
  AOI21x1_ASAP7_75t_R  g057(.A1(new_n50_), .A2(new_n58_), .B(new_n67_), .Y(new_n101_));
  NOR2x1_ASAP7_75t_R   g058(.A(p21), .B(new_n53_), .Y(new_n102_));
  INVx1_ASAP7_75t_R    g059(.A(new_n102_), .Y(new_n103_));
  AOI21x1_ASAP7_75t_R  g060(.A1(new_n50_), .A2(new_n58_), .B(new_n66_), .Y(new_n104_));
  NOR2x1_ASAP7_75t_R   g061(.A(p22), .B(new_n52_), .Y(new_n105_));
  INVx1_ASAP7_75t_R    g062(.A(new_n105_), .Y(new_n106_));
  OAI22x1_ASAP7_75t_R  g063(.A1(new_n101_), .A2(new_n103_), .B1(new_n104_), .B2(new_n106_), .Y(new_n107_));
  AOI211x1_ASAP7_75t_R g064(.A1(new_n91_), .A2(new_n92_), .B(new_n100_), .C(new_n107_), .Y(new_n108_));
  NAND2x1_ASAP7_75t_R  g065(.A(new_n90_), .B(new_n108_), .Y(o1));
  INVx1_ASAP7_75t_R    g066(.A(p21), .Y(new_n110_));
  OAI21x1_ASAP7_75t_R  g067(.A1(new_n65_), .A2(new_n73_), .B(p7), .Y(new_n111_));
  NAND2x1_ASAP7_75t_R  g068(.A(new_n102_), .B(new_n111_), .Y(new_n112_));
  NAND2x1_ASAP7_75t_R  g069(.A(new_n92_), .B(new_n91_), .Y(new_n113_));
  NAND2x1_ASAP7_75t_R  g070(.A(new_n76_), .B(new_n74_), .Y(new_n114_));
  NAND3x1_ASAP7_75t_R  g071(.A(new_n112_), .B(new_n113_), .C(new_n114_), .Y(new_n115_));
  OAI21x1_ASAP7_75t_R  g072(.A1(new_n65_), .A2(new_n73_), .B(p11), .Y(new_n116_));
  NAND2x1_ASAP7_75t_R  g073(.A(new_n83_), .B(new_n116_), .Y(new_n117_));
  NAND2x1_ASAP7_75t_R  g074(.A(new_n78_), .B(new_n80_), .Y(new_n118_));
  NAND3x1_ASAP7_75t_R  g075(.A(new_n117_), .B(new_n118_), .C(new_n88_), .Y(new_n119_));
  OAI21x1_ASAP7_75t_R  g076(.A1(new_n65_), .A2(new_n73_), .B(p9), .Y(new_n120_));
  NAND2x1_ASAP7_75t_R  g077(.A(new_n105_), .B(new_n120_), .Y(new_n121_));
  AO31x2_ASAP7_75t_R   g078(.A1(new_n62_), .A2(new_n64_), .A3(new_n71_), .B(new_n69_), .Y(new_n122_));
  AO21x1_ASAP7_75t_R   g079(.A1(new_n72_), .A2(new_n68_), .B(new_n69_), .Y(new_n123_));
  NAND3x1_ASAP7_75t_R  g080(.A(new_n122_), .B(new_n123_), .C(new_n94_), .Y(new_n124_));
  NAND3x1_ASAP7_75t_R  g081(.A(new_n121_), .B(new_n99_), .C(new_n124_), .Y(new_n125_));
  NOR3x1_ASAP7_75t_R   g082(.A(new_n115_), .B(new_n119_), .C(new_n125_), .Y(new_n126_));
  INVx1_ASAP7_75t_R    g083(.A(p30), .Y(new_n127_));
  AND3x1_ASAP7_75t_R   g084(.A(new_n111_), .B(p8), .C(new_n127_), .Y(new_n128_));
  OAI21x1_ASAP7_75t_R  g085(.A1(new_n110_), .A2(new_n126_), .B(new_n128_), .Y(new_n129_));
  INVx1_ASAP7_75t_R    g086(.A(p22), .Y(new_n130_));
  INVx1_ASAP7_75t_R    g087(.A(p31), .Y(new_n131_));
  AND3x1_ASAP7_75t_R   g088(.A(new_n120_), .B(new_n131_), .C(p10), .Y(new_n132_));
  OAI21x1_ASAP7_75t_R  g089(.A1(new_n130_), .A2(new_n126_), .B(new_n132_), .Y(new_n133_));
  INVx1_ASAP7_75t_R    g090(.A(p20), .Y(new_n134_));
  INVx1_ASAP7_75t_R    g091(.A(p29), .Y(new_n135_));
  AND3x1_ASAP7_75t_R   g092(.A(new_n74_), .B(new_n135_), .C(p6), .Y(new_n136_));
  OAI21x1_ASAP7_75t_R  g093(.A1(new_n134_), .A2(new_n126_), .B(new_n136_), .Y(new_n137_));
  AND3x1_ASAP7_75t_R   g094(.A(new_n129_), .B(new_n133_), .C(new_n137_), .Y(new_n138_));
  INVx1_ASAP7_75t_R    g095(.A(p25), .Y(new_n139_));
  AOI21x1_ASAP7_75t_R  g096(.A1(new_n90_), .A2(new_n108_), .B(new_n139_), .Y(new_n140_));
  OAI21x1_ASAP7_75t_R  g097(.A1(new_n65_), .A2(new_n73_), .B(p15), .Y(new_n141_));
  NAND2x1_ASAP7_75t_R  g098(.A(p16), .B(new_n141_), .Y(new_n142_));
  OR2x4_ASAP7_75t_R    g099(.A(p34), .B(new_n142_), .Y(new_n143_));
  INVx1_ASAP7_75t_R    g100(.A(p24), .Y(new_n144_));
  AOI21x1_ASAP7_75t_R  g101(.A1(new_n90_), .A2(new_n108_), .B(new_n144_), .Y(new_n145_));
  OA21x2_ASAP7_75t_R   g102(.A1(new_n65_), .A2(new_n73_), .B(p13), .Y(new_n146_));
  OR3x1_ASAP7_75t_R    g103(.A(new_n146_), .B(p33), .C(new_n48_), .Y(new_n147_));
  OAI22x1_ASAP7_75t_R  g104(.A1(new_n140_), .A2(new_n143_), .B1(new_n145_), .B2(new_n147_), .Y(new_n148_));
  OAI21x1_ASAP7_75t_R  g105(.A1(new_n65_), .A2(new_n73_), .B(p1), .Y(new_n149_));
  AOI22x1_ASAP7_75t_R  g106(.A1(new_n116_), .A2(new_n83_), .B1(new_n149_), .B2(new_n87_), .Y(new_n150_));
  AND3x1_ASAP7_75t_R   g107(.A(new_n85_), .B(p2), .C(new_n86_), .Y(new_n151_));
  AND3x1_ASAP7_75t_R   g108(.A(new_n150_), .B(new_n151_), .C(new_n118_), .Y(new_n152_));
  INVx1_ASAP7_75t_R    g109(.A(new_n92_), .Y(new_n153_));
  OAI21x1_ASAP7_75t_R  g110(.A1(new_n153_), .A2(new_n146_), .B(new_n124_), .Y(new_n154_));
  AOI21x1_ASAP7_75t_R  g111(.A1(new_n50_), .A2(new_n58_), .B(new_n51_), .Y(new_n155_));
  INVx1_ASAP7_75t_R    g112(.A(new_n76_), .Y(new_n156_));
  OAI22x1_ASAP7_75t_R  g113(.A1(new_n104_), .A2(new_n106_), .B1(new_n155_), .B2(new_n156_), .Y(new_n157_));
  OAI21x1_ASAP7_75t_R  g114(.A1(new_n101_), .A2(new_n103_), .B(new_n99_), .Y(new_n158_));
  NOR3x1_ASAP7_75t_R   g115(.A(new_n154_), .B(new_n157_), .C(new_n158_), .Y(new_n159_));
  INVx1_ASAP7_75t_R    g116(.A(new_n88_), .Y(new_n160_));
  AOI21x1_ASAP7_75t_R  g117(.A1(new_n152_), .A2(new_n159_), .B(new_n160_), .Y(new_n161_));
  INVx1_ASAP7_75t_R    g118(.A(p17), .Y(new_n162_));
  AOI21x1_ASAP7_75t_R  g119(.A1(new_n90_), .A2(new_n108_), .B(new_n162_), .Y(new_n163_));
  OAI21x1_ASAP7_75t_R  g120(.A1(new_n65_), .A2(new_n73_), .B(p35), .Y(new_n164_));
  NAND2x1_ASAP7_75t_R  g121(.A(p0), .B(new_n164_), .Y(new_n165_));
  NOR2x1_ASAP7_75t_R   g122(.A(p26), .B(new_n165_), .Y(new_n166_));
  INVx1_ASAP7_75t_R    g123(.A(new_n166_), .Y(new_n167_));
  OAI22x1_ASAP7_75t_R  g124(.A1(new_n161_), .A2(p27), .B1(new_n163_), .B2(new_n167_), .Y(new_n168_));
  INVx1_ASAP7_75t_R    g125(.A(p23), .Y(new_n169_));
  AOI21x1_ASAP7_75t_R  g126(.A1(new_n90_), .A2(new_n108_), .B(new_n169_), .Y(new_n170_));
  INVx1_ASAP7_75t_R    g127(.A(p32), .Y(new_n171_));
  AND3x1_ASAP7_75t_R   g128(.A(new_n116_), .B(p12), .C(new_n171_), .Y(new_n172_));
  INVx1_ASAP7_75t_R    g129(.A(new_n172_), .Y(new_n173_));
  AOI22x1_ASAP7_75t_R  g130(.A1(new_n141_), .A2(new_n98_), .B1(new_n111_), .B2(new_n102_), .Y(new_n174_));
  AOI22x1_ASAP7_75t_R  g131(.A1(new_n91_), .A2(new_n92_), .B1(new_n164_), .B2(new_n94_), .Y(new_n175_));
  AOI22x1_ASAP7_75t_R  g132(.A1(new_n120_), .A2(new_n105_), .B1(new_n74_), .B2(new_n76_), .Y(new_n176_));
  INVx1_ASAP7_75t_R    g133(.A(p19), .Y(new_n177_));
  AO31x2_ASAP7_75t_R   g134(.A1(new_n174_), .A2(new_n175_), .A3(new_n176_), .B(new_n177_), .Y(new_n178_));
  NAND2x1_ASAP7_75t_R  g135(.A(p19), .B(new_n89_), .Y(new_n179_));
  AO21x1_ASAP7_75t_R   g136(.A1(p3), .A2(o0), .B(new_n77_), .Y(new_n180_));
  NOR2x1_ASAP7_75t_R   g137(.A(p28), .B(new_n180_), .Y(new_n181_));
  NAND3x1_ASAP7_75t_R  g138(.A(new_n178_), .B(new_n179_), .C(new_n181_), .Y(new_n182_));
  OAI21x1_ASAP7_75t_R  g139(.A1(new_n170_), .A2(new_n173_), .B(new_n182_), .Y(new_n183_));
  NOR3x1_ASAP7_75t_R   g140(.A(new_n148_), .B(new_n168_), .C(new_n183_), .Y(new_n184_));
  NAND2x1_ASAP7_75t_R  g141(.A(new_n138_), .B(new_n184_), .Y(o2));
  NAND3x1_ASAP7_75t_R  g142(.A(new_n174_), .B(new_n175_), .C(new_n176_), .Y(new_n186_));
  OAI21x1_ASAP7_75t_R  g143(.A1(new_n119_), .A2(new_n186_), .B(p17), .Y(new_n187_));
  OA21x2_ASAP7_75t_R   g144(.A1(new_n81_), .A2(new_n89_), .B(p24), .Y(new_n188_));
  AOI211x1_ASAP7_75t_R g145(.A1(p24), .A2(new_n186_), .B(new_n188_), .C(new_n147_), .Y(new_n189_));
  OA21x2_ASAP7_75t_R   g146(.A1(new_n81_), .A2(new_n89_), .B(p23), .Y(new_n190_));
  AOI211x1_ASAP7_75t_R g147(.A1(p23), .A2(new_n186_), .B(new_n173_), .C(new_n190_), .Y(new_n191_));
  AOI211x1_ASAP7_75t_R g148(.A1(new_n187_), .A2(new_n166_), .B(new_n189_), .C(new_n191_), .Y(new_n192_));
  INVx1_ASAP7_75t_R    g149(.A(p27), .Y(new_n193_));
  NAND3x1_ASAP7_75t_R  g150(.A(new_n150_), .B(new_n151_), .C(new_n118_), .Y(new_n194_));
  OAI21x1_ASAP7_75t_R  g151(.A1(new_n194_), .A2(new_n186_), .B(new_n88_), .Y(new_n195_));
  OA21x2_ASAP7_75t_R   g152(.A1(new_n81_), .A2(new_n89_), .B(p25), .Y(new_n196_));
  AOI211x1_ASAP7_75t_R g153(.A1(p25), .A2(new_n186_), .B(new_n196_), .C(new_n143_), .Y(new_n197_));
  AND3x1_ASAP7_75t_R   g154(.A(new_n178_), .B(new_n179_), .C(new_n181_), .Y(new_n198_));
  AOI211x1_ASAP7_75t_R g155(.A1(new_n193_), .A2(new_n195_), .B(new_n197_), .C(new_n198_), .Y(new_n199_));
  AOI21x1_ASAP7_75t_R  g156(.A1(new_n192_), .A2(new_n199_), .B(new_n131_), .Y(new_n200_));
  AO21x1_ASAP7_75t_R   g157(.A1(new_n90_), .A2(new_n108_), .B(new_n110_), .Y(new_n201_));
  OAI21x1_ASAP7_75t_R  g158(.A1(new_n119_), .A2(new_n186_), .B(p20), .Y(new_n202_));
  AOI22x1_ASAP7_75t_R  g159(.A1(new_n201_), .A2(new_n128_), .B1(new_n202_), .B2(new_n136_), .Y(new_n203_));
  OAI21x1_ASAP7_75t_R  g160(.A1(new_n119_), .A2(new_n186_), .B(p22), .Y(new_n204_));
  AND3x1_ASAP7_75t_R   g161(.A(new_n204_), .B(p10), .C(new_n120_), .Y(new_n205_));
  OAI21x1_ASAP7_75t_R  g162(.A1(new_n131_), .A2(new_n203_), .B(new_n205_), .Y(new_n206_));
  AOI21x1_ASAP7_75t_R  g163(.A1(new_n192_), .A2(new_n199_), .B(new_n127_), .Y(new_n207_));
  AOI22x1_ASAP7_75t_R  g164(.A1(new_n204_), .A2(new_n132_), .B1(new_n202_), .B2(new_n136_), .Y(new_n208_));
  AND3x1_ASAP7_75t_R   g165(.A(new_n201_), .B(p8), .C(new_n111_), .Y(new_n209_));
  OAI21x1_ASAP7_75t_R  g166(.A1(new_n127_), .A2(new_n208_), .B(new_n209_), .Y(new_n210_));
  OAI22x1_ASAP7_75t_R  g167(.A1(new_n200_), .A2(new_n206_), .B1(new_n207_), .B2(new_n210_), .Y(new_n211_));
  NAND2x1_ASAP7_75t_R  g168(.A(p12), .B(new_n116_), .Y(new_n212_));
  NOR2x1_ASAP7_75t_R   g169(.A(new_n212_), .B(new_n170_), .Y(new_n213_));
  AO31x2_ASAP7_75t_R   g170(.A1(new_n184_), .A2(new_n138_), .A3(new_n213_), .B(new_n191_), .Y(new_n214_));
  OA211x2_ASAP7_75t_R  g171(.A1(new_n144_), .A2(new_n126_), .B(p14), .C(new_n91_), .Y(new_n215_));
  AO31x2_ASAP7_75t_R   g172(.A1(new_n184_), .A2(new_n138_), .A3(new_n215_), .B(new_n189_), .Y(new_n216_));
  NOR3x1_ASAP7_75t_R   g173(.A(new_n211_), .B(new_n214_), .C(new_n216_), .Y(new_n217_));
  NOR2x1_ASAP7_75t_R   g174(.A(new_n165_), .B(new_n163_), .Y(new_n218_));
  AND3x1_ASAP7_75t_R   g175(.A(new_n208_), .B(new_n129_), .C(new_n218_), .Y(new_n219_));
  AOI22x1_ASAP7_75t_R  g176(.A1(new_n219_), .A2(new_n184_), .B1(new_n187_), .B2(new_n166_), .Y(new_n220_));
  AND3x1_ASAP7_75t_R   g177(.A(new_n208_), .B(new_n129_), .C(new_n195_), .Y(new_n221_));
  NOR2x1_ASAP7_75t_R   g178(.A(p27), .B(new_n161_), .Y(new_n222_));
  AOI21x1_ASAP7_75t_R  g179(.A1(new_n184_), .A2(new_n221_), .B(new_n222_), .Y(new_n223_));
  AOI21x1_ASAP7_75t_R  g180(.A1(p19), .A2(o1), .B(new_n180_), .Y(new_n224_));
  AND3x1_ASAP7_75t_R   g181(.A(new_n208_), .B(new_n129_), .C(new_n224_), .Y(new_n225_));
  AOI21x1_ASAP7_75t_R  g182(.A1(new_n184_), .A2(new_n225_), .B(new_n198_), .Y(new_n226_));
  NAND2x1_ASAP7_75t_R  g183(.A(p6), .B(new_n74_), .Y(new_n227_));
  AOI21x1_ASAP7_75t_R  g184(.A1(new_n90_), .A2(new_n108_), .B(new_n134_), .Y(new_n228_));
  NOR2x1_ASAP7_75t_R   g185(.A(new_n227_), .B(new_n228_), .Y(new_n229_));
  AND4x2_ASAP7_75t_R   g186(.A(new_n229_), .B(new_n129_), .C(new_n133_), .D(p29), .Y(new_n230_));
  INVx1_ASAP7_75t_R    g187(.A(new_n137_), .Y(new_n231_));
  AOI21x1_ASAP7_75t_R  g188(.A1(new_n230_), .A2(new_n184_), .B(new_n231_), .Y(new_n232_));
  AND4x2_ASAP7_75t_R   g189(.A(new_n220_), .B(new_n223_), .C(new_n226_), .D(new_n232_), .Y(new_n233_));
  AOI211x1_ASAP7_75t_R g190(.A1(p34), .A2(o2), .B(new_n142_), .C(new_n140_), .Y(new_n234_));
  AOI21x1_ASAP7_75t_R  g191(.A1(new_n217_), .A2(new_n233_), .B(new_n234_), .Y(o3));
  INVx1_ASAP7_75t_R    g192(.A(new_n217_), .Y(o4));
  OA21x2_ASAP7_75t_R   g193(.A1(new_n110_), .A2(new_n126_), .B(new_n128_), .Y(new_n237_));
  AO21x1_ASAP7_75t_R   g194(.A1(new_n208_), .A2(new_n209_), .B(new_n237_), .Y(new_n238_));
  NOR2x1_ASAP7_75t_R   g195(.A(new_n197_), .B(new_n189_), .Y(new_n239_));
  AOI22x1_ASAP7_75t_R  g196(.A1(new_n195_), .A2(new_n193_), .B1(new_n187_), .B2(new_n166_), .Y(new_n240_));
  OAI21x1_ASAP7_75t_R  g197(.A1(new_n119_), .A2(new_n186_), .B(p23), .Y(new_n241_));
  NOR2x1_ASAP7_75t_R   g198(.A(new_n177_), .B(new_n150_), .Y(new_n242_));
  AOI21x1_ASAP7_75t_R  g199(.A1(p19), .A2(new_n186_), .B(new_n242_), .Y(new_n243_));
  AOI22x1_ASAP7_75t_R  g200(.A1(new_n241_), .A2(new_n172_), .B1(new_n243_), .B2(new_n181_), .Y(new_n244_));
  AO31x2_ASAP7_75t_R   g201(.A1(new_n239_), .A2(new_n240_), .A3(new_n244_), .B(new_n127_), .Y(new_n245_));
  AOI21x1_ASAP7_75t_R  g202(.A1(new_n192_), .A2(new_n199_), .B(new_n135_), .Y(new_n246_));
  AO21x1_ASAP7_75t_R   g203(.A1(new_n129_), .A2(new_n133_), .B(new_n135_), .Y(new_n247_));
  NAND2x1_ASAP7_75t_R  g204(.A(new_n229_), .B(new_n247_), .Y(new_n248_));
  AOI211x1_ASAP7_75t_R g205(.A1(new_n238_), .A2(new_n245_), .B(new_n246_), .C(new_n248_), .Y(new_n249_));
  NAND3x1_ASAP7_75t_R  g206(.A(new_n129_), .B(new_n133_), .C(new_n137_), .Y(new_n250_));
  OR3x1_ASAP7_75t_R    g207(.A(new_n170_), .B(new_n45_), .C(new_n82_), .Y(new_n251_));
  AOI21x1_ASAP7_75t_R  g208(.A1(p32), .A2(new_n250_), .B(new_n251_), .Y(new_n252_));
  AO21x1_ASAP7_75t_R   g209(.A1(new_n192_), .A2(new_n199_), .B(new_n171_), .Y(new_n253_));
  AO21x1_ASAP7_75t_R   g210(.A1(new_n192_), .A2(new_n199_), .B(new_n131_), .Y(new_n254_));
  OA21x2_ASAP7_75t_R   g211(.A1(new_n131_), .A2(new_n203_), .B(new_n205_), .Y(new_n255_));
  AOI22x1_ASAP7_75t_R  g212(.A1(new_n252_), .A2(new_n253_), .B1(new_n254_), .B2(new_n255_), .Y(new_n256_));
  NAND2x1_ASAP7_75t_R  g213(.A(new_n249_), .B(new_n256_), .Y(new_n257_));
  NOR2x1_ASAP7_75t_R   g214(.A(new_n216_), .B(new_n214_), .Y(new_n258_));
  NOR2x1_ASAP7_75t_R   g215(.A(new_n206_), .B(new_n200_), .Y(new_n259_));
  NOR2x1_ASAP7_75t_R   g216(.A(new_n210_), .B(new_n207_), .Y(new_n260_));
  OR3x1_ASAP7_75t_R    g217(.A(new_n259_), .B(new_n260_), .C(new_n226_), .Y(new_n261_));
  NAND3x1_ASAP7_75t_R  g218(.A(new_n257_), .B(new_n258_), .C(new_n261_), .Y(o5));
  AO21x1_ASAP7_75t_R   g219(.A1(new_n184_), .A2(new_n221_), .B(new_n222_), .Y(new_n263_));
  AOI21x1_ASAP7_75t_R  g220(.A1(new_n226_), .A2(new_n263_), .B(new_n259_), .Y(new_n264_));
  AOI21x1_ASAP7_75t_R  g221(.A1(new_n249_), .A2(new_n256_), .B(new_n216_), .Y(new_n265_));
  OAI21x1_ASAP7_75t_R  g222(.A1(new_n214_), .A2(new_n264_), .B(new_n265_), .Y(o6));
endmodule


