// Benchmark "/tmp/" written by ABC on Mon Oct 12 15:06:04 2026

module \/tmp/  ( 
    p30, p22, p16, p27, p9, p34, p6, p14, p32, p19, p15, p2, p5, p29, p3,
    p10, p35, p31, p26, p4, p20, p13, p8, p28, p12, p1, p25, p21, p18, p11,
    p24, p17, p7, p0, p23, p33,
    o0, o1, o2, o3, o4, o5, o6  );
  input  p30, p22, p16, p27, p9, p34, p6, p14, p32, p19, p15, p2, p5,
    p29, p3, p10, p35, p31, p26, p4, p20, p13, p8, p28, p12, p1, p25, p21,
    p18, p11, p24, p17, p7, p0, p23, p33;
  output o0, o1, o2, o3, o4, o5, o6;
  wire new_n44_, new_n45_, new_n46_, new_n47_, new_n48_, new_n49_, new_n50_,
    new_n51_, new_n52_, new_n53_, new_n54_, new_n55_, new_n56_, new_n57_,
    new_n58_, new_n59_, new_n60_, new_n62_, new_n63_, new_n64_, new_n65_,
    new_n66_, new_n67_, new_n68_, new_n69_, new_n70_, new_n71_, new_n72_,
    new_n73_, new_n74_, new_n75_, new_n76_, new_n77_, new_n78_, new_n79_,
    new_n80_, new_n81_, new_n82_, new_n83_, new_n84_, new_n85_, new_n86_,
    new_n87_, new_n88_, new_n89_, new_n90_, new_n91_, new_n92_, new_n93_,
    new_n94_, new_n95_, new_n96_, new_n97_, new_n98_, new_n100_, new_n101_,
    new_n102_, new_n103_, new_n104_, new_n105_, new_n106_, new_n107_,
    new_n108_, new_n109_, new_n110_, new_n111_, new_n112_, new_n113_,
    new_n114_, new_n115_, new_n116_, new_n117_, new_n118_, new_n119_,
    new_n120_, new_n121_, new_n122_, new_n123_, new_n124_, new_n125_,
    new_n126_, new_n127_, new_n128_, new_n129_, new_n130_, new_n131_,
    new_n132_, new_n133_, new_n134_, new_n135_, new_n136_, new_n137_,
    new_n138_, new_n139_, new_n140_, new_n141_, new_n142_, new_n143_,
    new_n144_, new_n145_, new_n146_, new_n147_, new_n148_, new_n149_,
    new_n151_, new_n152_, new_n153_, new_n154_, new_n155_, new_n156_,
    new_n157_, new_n158_, new_n159_, new_n160_, new_n161_, new_n162_,
    new_n163_, new_n164_, new_n165_, new_n166_, new_n167_, new_n168_,
    new_n169_, new_n170_, new_n171_, new_n172_, new_n173_, new_n174_,
    new_n175_, new_n176_, new_n177_, new_n178_, new_n179_, new_n180_,
    new_n181_, new_n182_, new_n183_, new_n184_, new_n185_, new_n186_,
    new_n187_, new_n188_, new_n189_, new_n190_, new_n191_, new_n192_,
    new_n193_, new_n194_, new_n195_, new_n196_, new_n197_, new_n198_,
    new_n199_, new_n202_, new_n203_, new_n204_, new_n205_, new_n206_,
    new_n207_, new_n208_, new_n209_, new_n211_, new_n212_, new_n213_,
    new_n214_, new_n215_, new_n216_;
  INVx1_ASAP7_75t_R    g000(.A(p9), .Y(new_n44_));
  INVx1_ASAP7_75t_R    g001(.A(p7), .Y(new_n45_));
  AOI22x1_ASAP7_75t_R  g002(.A1(new_n44_), .A2(p10), .B1(new_n45_), .B2(p8), .Y(new_n46_));
  INVx1_ASAP7_75t_R    g003(.A(p1), .Y(new_n47_));
  NAND2x1_ASAP7_75t_R  g004(.A(p2), .B(new_n47_), .Y(new_n48_));
  INVx1_ASAP7_75t_R    g005(.A(p15), .Y(new_n49_));
  NAND2x1_ASAP7_75t_R  g006(.A(p16), .B(new_n49_), .Y(new_n50_));
  AND3x1_ASAP7_75t_R   g007(.A(new_n46_), .B(new_n48_), .C(new_n50_), .Y(new_n51_));
  INVx1_ASAP7_75t_R    g008(.A(p5), .Y(new_n52_));
  INVx1_ASAP7_75t_R    g009(.A(p13), .Y(new_n53_));
  AOI22x1_ASAP7_75t_R  g010(.A1(p6), .A2(new_n52_), .B1(new_n53_), .B2(p14), .Y(new_n54_));
  INVx1_ASAP7_75t_R    g011(.A(p35), .Y(new_n55_));
  INVx1_ASAP7_75t_R    g012(.A(p11), .Y(new_n56_));
  AOI22x1_ASAP7_75t_R  g013(.A1(new_n55_), .A2(p0), .B1(new_n56_), .B2(p12), .Y(new_n57_));
  INVx1_ASAP7_75t_R    g014(.A(p3), .Y(new_n58_));
  NAND2x1_ASAP7_75t_R  g015(.A(p4), .B(new_n58_), .Y(new_n59_));
  AND3x1_ASAP7_75t_R   g016(.A(new_n54_), .B(new_n57_), .C(new_n59_), .Y(new_n60_));
  NAND2x1_ASAP7_75t_R  g017(.A(new_n51_), .B(new_n60_), .Y(o0));
  INVx1_ASAP7_75t_R    g018(.A(p18), .Y(new_n62_));
  NAND2x1_ASAP7_75t_R  g019(.A(p2), .B(new_n62_), .Y(new_n63_));
  AO21x1_ASAP7_75t_R   g020(.A1(p1), .A2(o0), .B(new_n63_), .Y(new_n64_));
  INVx1_ASAP7_75t_R    g021(.A(p17), .Y(new_n65_));
  AND2x2_ASAP7_75t_R   g022(.A(p0), .B(new_n65_), .Y(new_n66_));
  NAND3x1_ASAP7_75t_R  g023(.A(new_n46_), .B(new_n48_), .C(new_n50_), .Y(new_n67_));
  NAND3x1_ASAP7_75t_R  g024(.A(new_n54_), .B(new_n57_), .C(new_n59_), .Y(new_n68_));
  OAI21x1_ASAP7_75t_R  g025(.A1(new_n67_), .A2(new_n68_), .B(p35), .Y(new_n69_));
  NAND2x1_ASAP7_75t_R  g026(.A(new_n66_), .B(new_n69_), .Y(new_n70_));
  INVx1_ASAP7_75t_R    g027(.A(p24), .Y(new_n71_));
  AND2x2_ASAP7_75t_R   g028(.A(p14), .B(new_n71_), .Y(new_n72_));
  OAI21x1_ASAP7_75t_R  g029(.A1(new_n67_), .A2(new_n68_), .B(p13), .Y(new_n73_));
  NAND2x1_ASAP7_75t_R  g030(.A(new_n72_), .B(new_n73_), .Y(new_n74_));
  NAND3x1_ASAP7_75t_R  g031(.A(new_n64_), .B(new_n70_), .C(new_n74_), .Y(new_n75_));
  OAI21x1_ASAP7_75t_R  g032(.A1(new_n67_), .A2(new_n68_), .B(p5), .Y(new_n76_));
  INVx1_ASAP7_75t_R    g033(.A(p20), .Y(new_n77_));
  AND2x2_ASAP7_75t_R   g034(.A(p6), .B(new_n77_), .Y(new_n78_));
  OAI21x1_ASAP7_75t_R  g035(.A1(new_n67_), .A2(new_n68_), .B(p9), .Y(new_n79_));
  INVx1_ASAP7_75t_R    g036(.A(p10), .Y(new_n80_));
  NOR2x1_ASAP7_75t_R   g037(.A(p22), .B(new_n80_), .Y(new_n81_));
  AOI22x1_ASAP7_75t_R  g038(.A1(new_n76_), .A2(new_n78_), .B1(new_n79_), .B2(new_n81_), .Y(new_n82_));
  OAI21x1_ASAP7_75t_R  g039(.A1(new_n67_), .A2(new_n68_), .B(p7), .Y(new_n83_));
  INVx1_ASAP7_75t_R    g040(.A(p21), .Y(new_n84_));
  AND2x2_ASAP7_75t_R   g041(.A(p8), .B(new_n84_), .Y(new_n85_));
  OAI21x1_ASAP7_75t_R  g042(.A1(new_n67_), .A2(new_n68_), .B(p15), .Y(new_n86_));
  INVx1_ASAP7_75t_R    g043(.A(p16), .Y(new_n87_));
  NOR2x1_ASAP7_75t_R   g044(.A(p25), .B(new_n87_), .Y(new_n88_));
  AOI22x1_ASAP7_75t_R  g045(.A1(new_n83_), .A2(new_n85_), .B1(new_n86_), .B2(new_n88_), .Y(new_n89_));
  INVx1_ASAP7_75t_R    g046(.A(p4), .Y(new_n90_));
  NOR2x1_ASAP7_75t_R   g047(.A(p19), .B(new_n90_), .Y(new_n91_));
  OAI21x1_ASAP7_75t_R  g048(.A1(new_n67_), .A2(new_n68_), .B(new_n59_), .Y(new_n92_));
  OAI21x1_ASAP7_75t_R  g049(.A1(new_n67_), .A2(new_n68_), .B(p11), .Y(new_n93_));
  INVx1_ASAP7_75t_R    g050(.A(p23), .Y(new_n94_));
  AND2x2_ASAP7_75t_R   g051(.A(p12), .B(new_n94_), .Y(new_n95_));
  AOI22x1_ASAP7_75t_R  g052(.A1(new_n91_), .A2(new_n92_), .B1(new_n93_), .B2(new_n95_), .Y(new_n96_));
  NAND3x1_ASAP7_75t_R  g053(.A(new_n82_), .B(new_n89_), .C(new_n96_), .Y(new_n97_));
  NOR2x1_ASAP7_75t_R   g054(.A(new_n75_), .B(new_n97_), .Y(new_n98_));
  INVx1_ASAP7_75t_R    g055(.A(new_n98_), .Y(o1));
  OAI21x1_ASAP7_75t_R  g056(.A1(new_n75_), .A2(new_n97_), .B(p22), .Y(new_n100_));
  INVx1_ASAP7_75t_R    g057(.A(p31), .Y(new_n101_));
  AND3x1_ASAP7_75t_R   g058(.A(new_n79_), .B(p10), .C(new_n101_), .Y(new_n102_));
  AOI22x1_ASAP7_75t_R  g059(.A1(new_n69_), .A2(new_n66_), .B1(new_n73_), .B2(new_n72_), .Y(new_n103_));
  NAND3x1_ASAP7_75t_R  g060(.A(new_n82_), .B(new_n89_), .C(new_n103_), .Y(new_n104_));
  NAND2x1_ASAP7_75t_R  g061(.A(new_n91_), .B(new_n92_), .Y(new_n105_));
  AO21x1_ASAP7_75t_R   g062(.A1(new_n51_), .A2(new_n60_), .B(new_n47_), .Y(new_n106_));
  INVx1_ASAP7_75t_R    g063(.A(new_n63_), .Y(new_n107_));
  AOI22x1_ASAP7_75t_R  g064(.A1(new_n106_), .A2(new_n107_), .B1(new_n93_), .B2(new_n95_), .Y(new_n108_));
  AOI21x1_ASAP7_75t_R  g065(.A1(new_n105_), .A2(new_n108_), .B(new_n84_), .Y(new_n109_));
  INVx1_ASAP7_75t_R    g066(.A(p30), .Y(new_n110_));
  NAND3x1_ASAP7_75t_R  g067(.A(new_n83_), .B(new_n110_), .C(p8), .Y(new_n111_));
  AOI211x1_ASAP7_75t_R g068(.A1(p21), .A2(new_n104_), .B(new_n109_), .C(new_n111_), .Y(new_n112_));
  AOI21x1_ASAP7_75t_R  g069(.A1(new_n105_), .A2(new_n108_), .B(new_n77_), .Y(new_n113_));
  NAND2x1_ASAP7_75t_R  g070(.A(p6), .B(new_n76_), .Y(new_n114_));
  OR2x4_ASAP7_75t_R    g071(.A(p29), .B(new_n114_), .Y(new_n115_));
  AOI211x1_ASAP7_75t_R g072(.A1(p20), .A2(new_n104_), .B(new_n113_), .C(new_n115_), .Y(new_n116_));
  AOI211x1_ASAP7_75t_R g073(.A1(new_n100_), .A2(new_n102_), .B(new_n112_), .C(new_n116_), .Y(new_n117_));
  OA21x2_ASAP7_75t_R   g074(.A1(new_n75_), .A2(new_n97_), .B(p25), .Y(new_n118_));
  NAND2x1_ASAP7_75t_R  g075(.A(p16), .B(new_n86_), .Y(new_n119_));
  NOR2x1_ASAP7_75t_R   g076(.A(p34), .B(new_n119_), .Y(new_n120_));
  INVx1_ASAP7_75t_R    g077(.A(new_n120_), .Y(new_n121_));
  AOI21x1_ASAP7_75t_R  g078(.A1(new_n105_), .A2(new_n108_), .B(new_n71_), .Y(new_n122_));
  INVx1_ASAP7_75t_R    g079(.A(p33), .Y(new_n123_));
  NAND3x1_ASAP7_75t_R  g080(.A(new_n73_), .B(p14), .C(new_n123_), .Y(new_n124_));
  AO211x2_ASAP7_75t_R  g081(.A1(new_n104_), .A2(p24), .B(new_n122_), .C(new_n124_), .Y(new_n125_));
  OAI21x1_ASAP7_75t_R  g082(.A1(new_n118_), .A2(new_n121_), .B(new_n125_), .Y(new_n126_));
  NAND2x1_ASAP7_75t_R  g083(.A(new_n95_), .B(new_n93_), .Y(new_n127_));
  AND3x1_ASAP7_75t_R   g084(.A(new_n64_), .B(new_n127_), .C(new_n105_), .Y(new_n128_));
  AND3x1_ASAP7_75t_R   g085(.A(new_n82_), .B(new_n89_), .C(new_n103_), .Y(new_n129_));
  AOI21x1_ASAP7_75t_R  g086(.A1(new_n128_), .A2(new_n129_), .B(new_n94_), .Y(new_n130_));
  INVx1_ASAP7_75t_R    g087(.A(p32), .Y(new_n131_));
  AND2x2_ASAP7_75t_R   g088(.A(p12), .B(new_n93_), .Y(new_n132_));
  NAND2x1_ASAP7_75t_R  g089(.A(new_n131_), .B(new_n132_), .Y(new_n133_));
  AND2x2_ASAP7_75t_R   g090(.A(new_n91_), .B(new_n92_), .Y(new_n134_));
  AOI21x1_ASAP7_75t_R  g091(.A1(new_n128_), .A2(new_n129_), .B(new_n134_), .Y(new_n135_));
  INVx1_ASAP7_75t_R    g092(.A(p28), .Y(new_n136_));
  NAND3x1_ASAP7_75t_R  g093(.A(new_n92_), .B(p4), .C(new_n136_), .Y(new_n137_));
  OAI22x1_ASAP7_75t_R  g094(.A1(new_n130_), .A2(new_n133_), .B1(new_n135_), .B2(new_n137_), .Y(new_n138_));
  INVx1_ASAP7_75t_R    g095(.A(p2), .Y(new_n139_));
  AOI21x1_ASAP7_75t_R  g096(.A1(p1), .A2(o0), .B(new_n139_), .Y(new_n140_));
  AND4x2_ASAP7_75t_R   g097(.A(new_n140_), .B(new_n105_), .C(new_n127_), .D(p18), .Y(new_n141_));
  AOI22x1_ASAP7_75t_R  g098(.A1(new_n129_), .A2(new_n141_), .B1(new_n62_), .B2(new_n140_), .Y(new_n142_));
  AO31x2_ASAP7_75t_R   g099(.A1(new_n82_), .A2(new_n89_), .A3(new_n103_), .B(new_n65_), .Y(new_n143_));
  AO21x1_ASAP7_75t_R   g100(.A1(new_n105_), .A2(new_n108_), .B(new_n65_), .Y(new_n144_));
  INVx1_ASAP7_75t_R    g101(.A(p26), .Y(new_n145_));
  AND3x1_ASAP7_75t_R   g102(.A(new_n69_), .B(new_n145_), .C(p0), .Y(new_n146_));
  NAND3x1_ASAP7_75t_R  g103(.A(new_n143_), .B(new_n144_), .C(new_n146_), .Y(new_n147_));
  OAI21x1_ASAP7_75t_R  g104(.A1(p27), .A2(new_n142_), .B(new_n147_), .Y(new_n148_));
  NOR3x1_ASAP7_75t_R   g105(.A(new_n126_), .B(new_n138_), .C(new_n148_), .Y(new_n149_));
  NAND2x1_ASAP7_75t_R  g106(.A(new_n117_), .B(new_n149_), .Y(o2));
  OAI21x1_ASAP7_75t_R  g107(.A1(new_n75_), .A2(new_n97_), .B(p25), .Y(new_n151_));
  AOI211x1_ASAP7_75t_R g108(.A1(p24), .A2(new_n104_), .B(new_n122_), .C(new_n124_), .Y(new_n152_));
  AOI21x1_ASAP7_75t_R  g109(.A1(new_n105_), .A2(new_n108_), .B(new_n94_), .Y(new_n153_));
  AOI211x1_ASAP7_75t_R g110(.A1(p23), .A2(new_n104_), .B(new_n153_), .C(new_n133_), .Y(new_n154_));
  AOI211x1_ASAP7_75t_R g111(.A1(new_n151_), .A2(new_n120_), .B(new_n152_), .C(new_n154_), .Y(new_n155_));
  INVx1_ASAP7_75t_R    g112(.A(p27), .Y(new_n156_));
  NAND3x1_ASAP7_75t_R  g113(.A(new_n108_), .B(new_n140_), .C(new_n105_), .Y(new_n157_));
  OAI21x1_ASAP7_75t_R  g114(.A1(new_n104_), .A2(new_n157_), .B(new_n64_), .Y(new_n158_));
  NOR2x1_ASAP7_75t_R   g115(.A(new_n134_), .B(new_n108_), .Y(new_n159_));
  AOI211x1_ASAP7_75t_R g116(.A1(new_n105_), .A2(new_n104_), .B(new_n137_), .C(new_n159_), .Y(new_n160_));
  AOI21x1_ASAP7_75t_R  g117(.A1(new_n105_), .A2(new_n108_), .B(new_n65_), .Y(new_n161_));
  INVx1_ASAP7_75t_R    g118(.A(new_n146_), .Y(new_n162_));
  AOI211x1_ASAP7_75t_R g119(.A1(p17), .A2(new_n104_), .B(new_n161_), .C(new_n162_), .Y(new_n163_));
  AOI211x1_ASAP7_75t_R g120(.A1(new_n156_), .A2(new_n158_), .B(new_n160_), .C(new_n163_), .Y(new_n164_));
  AOI21x1_ASAP7_75t_R  g121(.A1(new_n155_), .A2(new_n164_), .B(new_n145_), .Y(new_n165_));
  OA211x2_ASAP7_75t_R  g122(.A1(new_n65_), .A2(new_n98_), .B(p0), .C(new_n69_), .Y(new_n166_));
  OAI21x1_ASAP7_75t_R  g123(.A1(new_n145_), .A2(new_n117_), .B(new_n166_), .Y(new_n167_));
  AOI21x1_ASAP7_75t_R  g124(.A1(new_n155_), .A2(new_n164_), .B(new_n156_), .Y(new_n168_));
  OAI21x1_ASAP7_75t_R  g125(.A1(new_n156_), .A2(new_n117_), .B(new_n158_), .Y(new_n169_));
  OAI22x1_ASAP7_75t_R  g126(.A1(new_n165_), .A2(new_n167_), .B1(new_n168_), .B2(new_n169_), .Y(new_n170_));
  AOI21x1_ASAP7_75t_R  g127(.A1(new_n155_), .A2(new_n164_), .B(new_n136_), .Y(new_n171_));
  AO21x1_ASAP7_75t_R   g128(.A1(p3), .A2(o0), .B(new_n90_), .Y(new_n172_));
  AOI21x1_ASAP7_75t_R  g129(.A1(p19), .A2(o1), .B(new_n172_), .Y(new_n173_));
  OAI21x1_ASAP7_75t_R  g130(.A1(new_n136_), .A2(new_n117_), .B(new_n173_), .Y(new_n174_));
  INVx1_ASAP7_75t_R    g131(.A(p29), .Y(new_n175_));
  AOI21x1_ASAP7_75t_R  g132(.A1(new_n155_), .A2(new_n164_), .B(new_n175_), .Y(new_n176_));
  AOI211x1_ASAP7_75t_R g133(.A1(p20), .A2(new_n104_), .B(new_n113_), .C(new_n114_), .Y(new_n177_));
  OAI21x1_ASAP7_75t_R  g134(.A1(new_n175_), .A2(new_n117_), .B(new_n177_), .Y(new_n178_));
  OAI22x1_ASAP7_75t_R  g135(.A1(new_n171_), .A2(new_n174_), .B1(new_n176_), .B2(new_n178_), .Y(new_n179_));
  NOR2x1_ASAP7_75t_R   g136(.A(new_n170_), .B(new_n179_), .Y(new_n180_));
  AOI21x1_ASAP7_75t_R  g137(.A1(new_n155_), .A2(new_n164_), .B(new_n110_), .Y(new_n181_));
  OA211x2_ASAP7_75t_R  g138(.A1(new_n84_), .A2(new_n98_), .B(p8), .C(new_n83_), .Y(new_n182_));
  OAI21x1_ASAP7_75t_R  g139(.A1(new_n110_), .A2(new_n117_), .B(new_n182_), .Y(new_n183_));
  AOI21x1_ASAP7_75t_R  g140(.A1(new_n155_), .A2(new_n164_), .B(new_n101_), .Y(new_n184_));
  NOR2x1_ASAP7_75t_R   g141(.A(new_n112_), .B(new_n116_), .Y(new_n185_));
  AND3x1_ASAP7_75t_R   g142(.A(new_n100_), .B(p10), .C(new_n79_), .Y(new_n186_));
  OAI21x1_ASAP7_75t_R  g143(.A1(new_n101_), .A2(new_n185_), .B(new_n186_), .Y(new_n187_));
  OAI22x1_ASAP7_75t_R  g144(.A1(new_n181_), .A2(new_n183_), .B1(new_n184_), .B2(new_n187_), .Y(new_n188_));
  AOI21x1_ASAP7_75t_R  g145(.A1(new_n155_), .A2(new_n164_), .B(new_n123_), .Y(new_n189_));
  NAND2x1_ASAP7_75t_R  g146(.A(p14), .B(new_n73_), .Y(new_n190_));
  AOI211x1_ASAP7_75t_R g147(.A1(p24), .A2(new_n104_), .B(new_n190_), .C(new_n122_), .Y(new_n191_));
  OAI21x1_ASAP7_75t_R  g148(.A1(new_n123_), .A2(new_n117_), .B(new_n191_), .Y(new_n192_));
  AOI21x1_ASAP7_75t_R  g149(.A1(new_n155_), .A2(new_n164_), .B(new_n131_), .Y(new_n193_));
  OA21x2_ASAP7_75t_R   g150(.A1(new_n94_), .A2(new_n98_), .B(new_n132_), .Y(new_n194_));
  OAI21x1_ASAP7_75t_R  g151(.A1(new_n131_), .A2(new_n117_), .B(new_n194_), .Y(new_n195_));
  OAI22x1_ASAP7_75t_R  g152(.A1(new_n189_), .A2(new_n192_), .B1(new_n193_), .B2(new_n195_), .Y(new_n196_));
  NOR2x1_ASAP7_75t_R   g153(.A(new_n188_), .B(new_n196_), .Y(new_n197_));
  NOR2x1_ASAP7_75t_R   g154(.A(new_n119_), .B(new_n118_), .Y(new_n198_));
  NAND2x1_ASAP7_75t_R  g155(.A(p34), .B(o2), .Y(new_n199_));
  AOI22x1_ASAP7_75t_R  g156(.A1(new_n180_), .A2(new_n197_), .B1(new_n198_), .B2(new_n199_), .Y(o3));
  INVx1_ASAP7_75t_R    g157(.A(new_n197_), .Y(o4));
  NAND2x1_ASAP7_75t_R  g158(.A(new_n102_), .B(new_n100_), .Y(new_n202_));
  AND3x1_ASAP7_75t_R   g159(.A(new_n185_), .B(new_n177_), .C(new_n202_), .Y(new_n203_));
  AOI21x1_ASAP7_75t_R  g160(.A1(new_n203_), .A2(new_n149_), .B(new_n116_), .Y(new_n204_));
  NOR2x1_ASAP7_75t_R   g161(.A(new_n195_), .B(new_n193_), .Y(new_n205_));
  NOR3x1_ASAP7_75t_R   g162(.A(new_n188_), .B(new_n204_), .C(new_n205_), .Y(new_n206_));
  NAND2x1_ASAP7_75t_R  g163(.A(new_n155_), .B(new_n164_), .Y(new_n207_));
  AO21x1_ASAP7_75t_R   g164(.A1(p28), .A2(new_n207_), .B(new_n174_), .Y(new_n208_));
  NOR2x1_ASAP7_75t_R   g165(.A(new_n188_), .B(new_n208_), .Y(new_n209_));
  OR3x1_ASAP7_75t_R    g166(.A(new_n206_), .B(new_n209_), .C(new_n196_), .Y(o5));
  NOR2x1_ASAP7_75t_R   g167(.A(new_n169_), .B(new_n168_), .Y(new_n211_));
  NOR2x1_ASAP7_75t_R   g168(.A(new_n187_), .B(new_n184_), .Y(new_n212_));
  AOI21x1_ASAP7_75t_R  g169(.A1(new_n211_), .A2(new_n208_), .B(new_n212_), .Y(new_n213_));
  AND3x1_ASAP7_75t_R   g170(.A(new_n185_), .B(new_n202_), .C(new_n191_), .Y(new_n214_));
  AOI21x1_ASAP7_75t_R  g171(.A1(new_n214_), .A2(new_n149_), .B(new_n152_), .Y(new_n215_));
  OA31x2_ASAP7_75t_R   g172(.A1(new_n204_), .A2(new_n205_), .A3(new_n188_), .B1(new_n215_), .Y(new_n216_));
  OAI21x1_ASAP7_75t_R  g173(.A1(new_n205_), .A2(new_n213_), .B(new_n216_), .Y(o6));
endmodule


