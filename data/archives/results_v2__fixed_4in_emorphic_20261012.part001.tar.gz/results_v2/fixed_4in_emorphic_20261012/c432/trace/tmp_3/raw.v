// Benchmark "/tmp/" written by ABC on Mon Oct 12 15:06:04 2026

module \/tmp/  ( 
    p16, p2, p22, p17, p35, p26, p1, p21, p33, p8, p3, p11, p0, p24, p7,
    p23, p12, p9, p20, p13, p10, p29, p30, p28, p31, p19, p27, p25, p15,
    p6, p14, p32, p34, p18, p5, p4,
    o0, o1, o2, o3, o4, o5, o6  );
  input  p16, p2, p22, p17, p35, p26, p1, p21, p33, p8, p3, p11, p0, p24,
    p7, p23, p12, p9, p20, p13, p10, p29, p30, p28, p31, p19, p27, p25,
    p15, p6, p14, p32, p34, p18, p5, p4;
  output o0, o1, o2, o3, o4, o5, o6;
  wire new_n44_, new_n45_, new_n46_, new_n47_, new_n48_, new_n49_, new_n50_,
    new_n51_, new_n52_, new_n53_, new_n54_, new_n55_, new_n56_, new_n57_,
    new_n58_, new_n59_, new_n60_, new_n62_, new_n63_, new_n64_, new_n65_,
    new_n66_, new_n67_, new_n68_, new_n69_, new_n70_, new_n71_, new_n72_,
    new_n73_, new_n74_, new_n75_, new_n76_, new_n77_, new_n78_, new_n79_,
    new_n80_, new_n81_, new_n82_, new_n83_, new_n84_, new_n85_, new_n86_,
    new_n87_, new_n88_, new_n89_, new_n90_, new_n91_, new_n92_, new_n93_,
    new_n94_, new_n95_, new_n96_, new_n97_, new_n98_, new_n99_, new_n100_,
    new_n102_, new_n103_, new_n104_, new_n105_, new_n106_, new_n107_,
    new_n108_, new_n109_, new_n110_, new_n111_, new_n112_, new_n113_,
    new_n114_, new_n115_, new_n116_, new_n117_, new_n118_, new_n119_,
    new_n120_, new_n121_, new_n122_, new_n123_, new_n124_, new_n125_,
    new_n126_, new_n127_, new_n128_, new_n129_, new_n130_, new_n131_,
    new_n132_, new_n133_, new_n134_, new_n135_, new_n136_, new_n137_,
    new_n138_, new_n139_, new_n140_, new_n141_, new_n142_, new_n143_,
    new_n144_, new_n145_, new_n146_, new_n147_, new_n148_, new_n149_,
    new_n151_, new_n152_, new_n153_, new_n154_, new_n155_, new_n156_,
    new_n157_, new_n158_, new_n159_, new_n160_, new_n161_, new_n162_,
    new_n163_, new_n164_, new_n165_, new_n166_, new_n167_, new_n168_,
    new_n169_, new_n170_, new_n171_, new_n172_, new_n173_, new_n174_,
    new_n175_, new_n176_, new_n177_, new_n178_, new_n179_, new_n180_,
    new_n181_, new_n182_, new_n183_, new_n184_, new_n185_, new_n186_,
    new_n187_, new_n188_, new_n189_, new_n190_, new_n191_, new_n192_,
    new_n193_, new_n194_, new_n195_, new_n196_, new_n197_, new_n198_,
    new_n199_, new_n200_, new_n201_, new_n202_, new_n203_, new_n204_,
    new_n205_, new_n206_, new_n207_, new_n210_, new_n211_, new_n212_,
    new_n213_, new_n214_, new_n215_, new_n216_, new_n217_, new_n218_,
    new_n219_, new_n220_, new_n221_, new_n222_, new_n223_, new_n224_,
    new_n225_, new_n226_, new_n227_, new_n229_, new_n230_, new_n231_,
    new_n232_, new_n233_;
  INVx1_ASAP7_75t_R    g000(.A(p15), .Y(new_n44_));
  INVx1_ASAP7_75t_R    g001(.A(p13), .Y(new_n45_));
  AOI22x1_ASAP7_75t_R  g002(.A1(p16), .A2(new_n44_), .B1(new_n45_), .B2(p14), .Y(new_n46_));
  INVx1_ASAP7_75t_R    g003(.A(p3), .Y(new_n47_));
  NAND2x1_ASAP7_75t_R  g004(.A(p4), .B(new_n47_), .Y(new_n48_));
  INVx1_ASAP7_75t_R    g005(.A(p11), .Y(new_n49_));
  NAND2x1_ASAP7_75t_R  g006(.A(p12), .B(new_n49_), .Y(new_n50_));
  AND3x1_ASAP7_75t_R   g007(.A(new_n46_), .B(new_n48_), .C(new_n50_), .Y(new_n51_));
  INVx1_ASAP7_75t_R    g008(.A(p9), .Y(new_n52_));
  INVx1_ASAP7_75t_R    g009(.A(p5), .Y(new_n53_));
  AOI22x1_ASAP7_75t_R  g010(.A1(new_n52_), .A2(p10), .B1(new_n53_), .B2(p6), .Y(new_n54_));
  INVx1_ASAP7_75t_R    g011(.A(p1), .Y(new_n55_));
  INVx1_ASAP7_75t_R    g012(.A(p35), .Y(new_n56_));
  AOI22x1_ASAP7_75t_R  g013(.A1(p2), .A2(new_n55_), .B1(new_n56_), .B2(p0), .Y(new_n57_));
  INVx1_ASAP7_75t_R    g014(.A(p7), .Y(new_n58_));
  NAND2x1_ASAP7_75t_R  g015(.A(p8), .B(new_n58_), .Y(new_n59_));
  AND3x1_ASAP7_75t_R   g016(.A(new_n54_), .B(new_n57_), .C(new_n59_), .Y(new_n60_));
  NAND2x1_ASAP7_75t_R  g017(.A(new_n51_), .B(new_n60_), .Y(o0));
  NAND3x1_ASAP7_75t_R  g018(.A(new_n46_), .B(new_n48_), .C(new_n50_), .Y(new_n62_));
  NAND3x1_ASAP7_75t_R  g019(.A(new_n54_), .B(new_n57_), .C(new_n59_), .Y(new_n63_));
  OAI21x1_ASAP7_75t_R  g020(.A1(new_n62_), .A2(new_n63_), .B(p1), .Y(new_n64_));
  INVx1_ASAP7_75t_R    g021(.A(p2), .Y(new_n65_));
  NOR2x1_ASAP7_75t_R   g022(.A(p18), .B(new_n65_), .Y(new_n66_));
  OAI21x1_ASAP7_75t_R  g023(.A1(new_n62_), .A2(new_n63_), .B(p11), .Y(new_n67_));
  INVx1_ASAP7_75t_R    g024(.A(p12), .Y(new_n68_));
  NOR2x1_ASAP7_75t_R   g025(.A(p23), .B(new_n68_), .Y(new_n69_));
  AOI22x1_ASAP7_75t_R  g026(.A1(new_n64_), .A2(new_n66_), .B1(new_n67_), .B2(new_n69_), .Y(new_n70_));
  INVx1_ASAP7_75t_R    g027(.A(p20), .Y(new_n71_));
  AND2x2_ASAP7_75t_R   g028(.A(p6), .B(new_n71_), .Y(new_n72_));
  OAI21x1_ASAP7_75t_R  g029(.A1(new_n62_), .A2(new_n63_), .B(p5), .Y(new_n73_));
  NAND2x1_ASAP7_75t_R  g030(.A(new_n72_), .B(new_n73_), .Y(new_n74_));
  INVx1_ASAP7_75t_R    g031(.A(new_n48_), .Y(new_n75_));
  NOR2x1_ASAP7_75t_R   g032(.A(new_n62_), .B(new_n63_), .Y(new_n76_));
  INVx1_ASAP7_75t_R    g033(.A(p19), .Y(new_n77_));
  NAND2x1_ASAP7_75t_R  g034(.A(p4), .B(new_n77_), .Y(new_n78_));
  INVx1_ASAP7_75t_R    g035(.A(new_n78_), .Y(new_n79_));
  OAI21x1_ASAP7_75t_R  g036(.A1(new_n75_), .A2(new_n76_), .B(new_n79_), .Y(new_n80_));
  AND3x1_ASAP7_75t_R   g037(.A(new_n70_), .B(new_n74_), .C(new_n80_), .Y(new_n81_));
  OAI21x1_ASAP7_75t_R  g038(.A1(new_n62_), .A2(new_n63_), .B(p35), .Y(new_n82_));
  INVx1_ASAP7_75t_R    g039(.A(p17), .Y(new_n83_));
  AND2x2_ASAP7_75t_R   g040(.A(p0), .B(new_n83_), .Y(new_n84_));
  OAI21x1_ASAP7_75t_R  g041(.A1(new_n62_), .A2(new_n63_), .B(p13), .Y(new_n85_));
  INVx1_ASAP7_75t_R    g042(.A(p14), .Y(new_n86_));
  NOR2x1_ASAP7_75t_R   g043(.A(p24), .B(new_n86_), .Y(new_n87_));
  AOI22x1_ASAP7_75t_R  g044(.A1(new_n82_), .A2(new_n84_), .B1(new_n85_), .B2(new_n87_), .Y(new_n88_));
  OAI21x1_ASAP7_75t_R  g045(.A1(new_n62_), .A2(new_n63_), .B(p7), .Y(new_n89_));
  INVx1_ASAP7_75t_R    g046(.A(p8), .Y(new_n90_));
  NOR2x1_ASAP7_75t_R   g047(.A(p21), .B(new_n90_), .Y(new_n91_));
  OAI21x1_ASAP7_75t_R  g048(.A1(new_n62_), .A2(new_n63_), .B(p15), .Y(new_n92_));
  INVx1_ASAP7_75t_R    g049(.A(p25), .Y(new_n93_));
  AND2x2_ASAP7_75t_R   g050(.A(p16), .B(new_n93_), .Y(new_n94_));
  AOI22x1_ASAP7_75t_R  g051(.A1(new_n89_), .A2(new_n91_), .B1(new_n92_), .B2(new_n94_), .Y(new_n95_));
  INVx1_ASAP7_75t_R    g052(.A(p10), .Y(new_n96_));
  NOR2x1_ASAP7_75t_R   g053(.A(p22), .B(new_n96_), .Y(new_n97_));
  OAI21x1_ASAP7_75t_R  g054(.A1(new_n62_), .A2(new_n63_), .B(p9), .Y(new_n98_));
  NAND2x1_ASAP7_75t_R  g055(.A(new_n97_), .B(new_n98_), .Y(new_n99_));
  AND3x1_ASAP7_75t_R   g056(.A(new_n88_), .B(new_n95_), .C(new_n99_), .Y(new_n100_));
  NAND2x1_ASAP7_75t_R  g057(.A(new_n81_), .B(new_n100_), .Y(o1));
  INVx1_ASAP7_75t_R    g058(.A(p30), .Y(new_n102_));
  AND3x1_ASAP7_75t_R   g059(.A(new_n89_), .B(p8), .C(new_n102_), .Y(new_n103_));
  NAND3x1_ASAP7_75t_R  g060(.A(new_n70_), .B(new_n74_), .C(new_n80_), .Y(new_n104_));
  NAND3x1_ASAP7_75t_R  g061(.A(new_n88_), .B(new_n95_), .C(new_n99_), .Y(new_n105_));
  OAI21x1_ASAP7_75t_R  g062(.A1(new_n104_), .A2(new_n105_), .B(p21), .Y(new_n106_));
  NAND2x1_ASAP7_75t_R  g063(.A(new_n103_), .B(new_n106_), .Y(new_n107_));
  INVx1_ASAP7_75t_R    g064(.A(p31), .Y(new_n108_));
  AND3x1_ASAP7_75t_R   g065(.A(new_n98_), .B(p10), .C(new_n108_), .Y(new_n109_));
  OAI21x1_ASAP7_75t_R  g066(.A1(new_n104_), .A2(new_n105_), .B(p22), .Y(new_n110_));
  NAND2x1_ASAP7_75t_R  g067(.A(new_n109_), .B(new_n110_), .Y(new_n111_));
  AOI22x1_ASAP7_75t_R  g068(.A1(new_n73_), .A2(new_n72_), .B1(new_n98_), .B2(new_n97_), .Y(new_n112_));
  AO31x2_ASAP7_75t_R   g069(.A1(new_n88_), .A2(new_n95_), .A3(new_n112_), .B(new_n71_), .Y(new_n113_));
  AO21x1_ASAP7_75t_R   g070(.A1(new_n80_), .A2(new_n70_), .B(new_n71_), .Y(new_n114_));
  INVx1_ASAP7_75t_R    g071(.A(p29), .Y(new_n115_));
  AND3x1_ASAP7_75t_R   g072(.A(new_n73_), .B(new_n115_), .C(p6), .Y(new_n116_));
  NAND3x1_ASAP7_75t_R  g073(.A(new_n113_), .B(new_n114_), .C(new_n116_), .Y(new_n117_));
  NAND3x1_ASAP7_75t_R  g074(.A(new_n107_), .B(new_n111_), .C(new_n117_), .Y(new_n118_));
  INVx1_ASAP7_75t_R    g075(.A(p32), .Y(new_n119_));
  AND3x1_ASAP7_75t_R   g076(.A(new_n67_), .B(p12), .C(new_n119_), .Y(new_n120_));
  INVx1_ASAP7_75t_R    g077(.A(new_n120_), .Y(new_n121_));
  INVx1_ASAP7_75t_R    g078(.A(p23), .Y(new_n122_));
  AOI21x1_ASAP7_75t_R  g079(.A1(new_n81_), .A2(new_n100_), .B(new_n122_), .Y(new_n123_));
  AO31x2_ASAP7_75t_R   g080(.A1(new_n88_), .A2(new_n95_), .A3(new_n112_), .B(new_n77_), .Y(new_n124_));
  AO21x1_ASAP7_75t_R   g081(.A1(new_n80_), .A2(new_n70_), .B(new_n77_), .Y(new_n125_));
  OAI21x1_ASAP7_75t_R  g082(.A1(new_n47_), .A2(new_n76_), .B(p4), .Y(new_n126_));
  NOR2x1_ASAP7_75t_R   g083(.A(p28), .B(new_n126_), .Y(new_n127_));
  NAND3x1_ASAP7_75t_R  g084(.A(new_n124_), .B(new_n125_), .C(new_n127_), .Y(new_n128_));
  OAI21x1_ASAP7_75t_R  g085(.A1(new_n121_), .A2(new_n123_), .B(new_n128_), .Y(new_n129_));
  OA21x2_ASAP7_75t_R   g086(.A1(new_n62_), .A2(new_n63_), .B(p1), .Y(new_n130_));
  OR3x1_ASAP7_75t_R    g087(.A(new_n130_), .B(new_n65_), .C(p27), .Y(new_n131_));
  INVx1_ASAP7_75t_R    g088(.A(p18), .Y(new_n132_));
  AOI21x1_ASAP7_75t_R  g089(.A1(new_n81_), .A2(new_n100_), .B(new_n132_), .Y(new_n133_));
  AO31x2_ASAP7_75t_R   g090(.A1(new_n88_), .A2(new_n95_), .A3(new_n112_), .B(new_n83_), .Y(new_n134_));
  AO21x1_ASAP7_75t_R   g091(.A1(new_n80_), .A2(new_n70_), .B(new_n83_), .Y(new_n135_));
  INVx1_ASAP7_75t_R    g092(.A(p26), .Y(new_n136_));
  AND3x1_ASAP7_75t_R   g093(.A(new_n82_), .B(new_n136_), .C(p0), .Y(new_n137_));
  NAND3x1_ASAP7_75t_R  g094(.A(new_n134_), .B(new_n135_), .C(new_n137_), .Y(new_n138_));
  OAI21x1_ASAP7_75t_R  g095(.A1(new_n131_), .A2(new_n133_), .B(new_n138_), .Y(new_n139_));
  AOI21x1_ASAP7_75t_R  g096(.A1(new_n81_), .A2(new_n100_), .B(new_n93_), .Y(new_n140_));
  INVx1_ASAP7_75t_R    g097(.A(p34), .Y(new_n141_));
  AND3x1_ASAP7_75t_R   g098(.A(new_n92_), .B(p16), .C(new_n141_), .Y(new_n142_));
  INVx1_ASAP7_75t_R    g099(.A(new_n142_), .Y(new_n143_));
  INVx1_ASAP7_75t_R    g100(.A(p24), .Y(new_n144_));
  AOI21x1_ASAP7_75t_R  g101(.A1(new_n81_), .A2(new_n100_), .B(new_n144_), .Y(new_n145_));
  NOR2x1_ASAP7_75t_R   g102(.A(p33), .B(new_n86_), .Y(new_n146_));
  AND2x2_ASAP7_75t_R   g103(.A(new_n146_), .B(new_n85_), .Y(new_n147_));
  INVx1_ASAP7_75t_R    g104(.A(new_n147_), .Y(new_n148_));
  OAI22x1_ASAP7_75t_R  g105(.A1(new_n140_), .A2(new_n143_), .B1(new_n145_), .B2(new_n148_), .Y(new_n149_));
  OR4x2_ASAP7_75t_R    g106(.A(new_n118_), .B(new_n129_), .C(new_n139_), .D(new_n149_), .Y(o2));
  OAI21x1_ASAP7_75t_R  g107(.A1(new_n104_), .A2(new_n105_), .B(p20), .Y(new_n151_));
  AOI22x1_ASAP7_75t_R  g108(.A1(new_n151_), .A2(new_n116_), .B1(new_n110_), .B2(new_n109_), .Y(new_n152_));
  NOR2x1_ASAP7_75t_R   g109(.A(new_n65_), .B(new_n130_), .Y(new_n153_));
  NAND3x1_ASAP7_75t_R  g110(.A(new_n70_), .B(new_n153_), .C(new_n80_), .Y(new_n154_));
  NAND3x1_ASAP7_75t_R  g111(.A(new_n88_), .B(new_n95_), .C(new_n112_), .Y(new_n155_));
  NAND2x1_ASAP7_75t_R  g112(.A(new_n66_), .B(new_n64_), .Y(new_n156_));
  OAI21x1_ASAP7_75t_R  g113(.A1(new_n154_), .A2(new_n155_), .B(new_n156_), .Y(new_n157_));
  AND3x1_ASAP7_75t_R   g114(.A(new_n152_), .B(new_n107_), .C(new_n157_), .Y(new_n158_));
  NOR3x1_ASAP7_75t_R   g115(.A(new_n149_), .B(new_n129_), .C(new_n139_), .Y(new_n159_));
  AOI21x1_ASAP7_75t_R  g116(.A1(new_n80_), .A2(new_n70_), .B(new_n132_), .Y(new_n160_));
  AOI211x1_ASAP7_75t_R g117(.A1(p18), .A2(new_n155_), .B(new_n160_), .C(new_n131_), .Y(new_n161_));
  AOI21x1_ASAP7_75t_R  g118(.A1(new_n158_), .A2(new_n159_), .B(new_n161_), .Y(new_n162_));
  OAI21x1_ASAP7_75t_R  g119(.A1(new_n104_), .A2(new_n105_), .B(p17), .Y(new_n163_));
  AND3x1_ASAP7_75t_R   g120(.A(new_n163_), .B(p0), .C(new_n82_), .Y(new_n164_));
  AND3x1_ASAP7_75t_R   g121(.A(new_n164_), .B(new_n152_), .C(new_n107_), .Y(new_n165_));
  AND3x1_ASAP7_75t_R   g122(.A(new_n134_), .B(new_n135_), .C(new_n137_), .Y(new_n166_));
  AOI21x1_ASAP7_75t_R  g123(.A1(new_n159_), .A2(new_n165_), .B(new_n166_), .Y(new_n167_));
  AO21x1_ASAP7_75t_R   g124(.A1(p4), .A2(new_n76_), .B(new_n75_), .Y(new_n168_));
  AND3x1_ASAP7_75t_R   g125(.A(new_n124_), .B(new_n168_), .C(new_n125_), .Y(new_n169_));
  AND3x1_ASAP7_75t_R   g126(.A(new_n152_), .B(new_n107_), .C(new_n169_), .Y(new_n170_));
  AND3x1_ASAP7_75t_R   g127(.A(new_n124_), .B(new_n125_), .C(new_n127_), .Y(new_n171_));
  AOI21x1_ASAP7_75t_R  g128(.A1(new_n170_), .A2(new_n159_), .B(new_n171_), .Y(new_n172_));
  NAND2x1_ASAP7_75t_R  g129(.A(p6), .B(new_n73_), .Y(new_n173_));
  AOI21x1_ASAP7_75t_R  g130(.A1(p20), .A2(o1), .B(new_n173_), .Y(new_n174_));
  AND3x1_ASAP7_75t_R   g131(.A(new_n152_), .B(new_n107_), .C(new_n174_), .Y(new_n175_));
  INVx1_ASAP7_75t_R    g132(.A(new_n117_), .Y(new_n176_));
  AOI21x1_ASAP7_75t_R  g133(.A1(new_n175_), .A2(new_n159_), .B(new_n176_), .Y(new_n177_));
  AND4x2_ASAP7_75t_R   g134(.A(new_n162_), .B(new_n167_), .C(new_n172_), .D(new_n177_), .Y(new_n178_));
  AND3x1_ASAP7_75t_R   g135(.A(new_n110_), .B(p10), .C(new_n98_), .Y(new_n179_));
  AND3x1_ASAP7_75t_R   g136(.A(new_n179_), .B(new_n152_), .C(new_n107_), .Y(new_n180_));
  AOI22x1_ASAP7_75t_R  g137(.A1(new_n180_), .A2(new_n159_), .B1(new_n108_), .B2(new_n179_), .Y(new_n181_));
  AND3x1_ASAP7_75t_R   g138(.A(new_n106_), .B(p8), .C(new_n89_), .Y(new_n182_));
  OA21x2_ASAP7_75t_R   g139(.A1(new_n102_), .A2(new_n152_), .B(new_n182_), .Y(new_n183_));
  OAI21x1_ASAP7_75t_R  g140(.A1(new_n104_), .A2(new_n105_), .B(p19), .Y(new_n184_));
  OAI21x1_ASAP7_75t_R  g141(.A1(new_n104_), .A2(new_n105_), .B(p23), .Y(new_n185_));
  AOI22x1_ASAP7_75t_R  g142(.A1(new_n184_), .A2(new_n127_), .B1(new_n185_), .B2(new_n120_), .Y(new_n186_));
  INVx1_ASAP7_75t_R    g143(.A(p27), .Y(new_n187_));
  AOI22x1_ASAP7_75t_R  g144(.A1(new_n157_), .A2(new_n187_), .B1(new_n163_), .B2(new_n137_), .Y(new_n188_));
  OAI21x1_ASAP7_75t_R  g145(.A1(new_n104_), .A2(new_n105_), .B(p25), .Y(new_n189_));
  OAI21x1_ASAP7_75t_R  g146(.A1(new_n104_), .A2(new_n105_), .B(p24), .Y(new_n190_));
  AOI22x1_ASAP7_75t_R  g147(.A1(new_n189_), .A2(new_n142_), .B1(new_n190_), .B2(new_n147_), .Y(new_n191_));
  AO31x2_ASAP7_75t_R   g148(.A1(new_n186_), .A2(new_n188_), .A3(new_n191_), .B(new_n102_), .Y(new_n192_));
  NAND2x1_ASAP7_75t_R  g149(.A(new_n183_), .B(new_n192_), .Y(new_n193_));
  AND3x1_ASAP7_75t_R   g150(.A(new_n190_), .B(p14), .C(new_n85_), .Y(new_n194_));
  AND3x1_ASAP7_75t_R   g151(.A(new_n194_), .B(new_n152_), .C(new_n107_), .Y(new_n195_));
  AO31x2_ASAP7_75t_R   g152(.A1(new_n88_), .A2(new_n95_), .A3(new_n112_), .B(new_n144_), .Y(new_n196_));
  AO21x1_ASAP7_75t_R   g153(.A1(new_n80_), .A2(new_n70_), .B(new_n144_), .Y(new_n197_));
  AND4x2_ASAP7_75t_R   g154(.A(new_n196_), .B(new_n85_), .C(new_n197_), .D(new_n146_), .Y(new_n198_));
  AOI21x1_ASAP7_75t_R  g155(.A1(new_n159_), .A2(new_n195_), .B(new_n198_), .Y(new_n199_));
  AO21x1_ASAP7_75t_R   g156(.A1(p11), .A2(o0), .B(new_n68_), .Y(new_n200_));
  NOR2x1_ASAP7_75t_R   g157(.A(new_n200_), .B(new_n123_), .Y(new_n201_));
  AND3x1_ASAP7_75t_R   g158(.A(new_n152_), .B(new_n107_), .C(new_n201_), .Y(new_n202_));
  NOR2x1_ASAP7_75t_R   g159(.A(new_n121_), .B(new_n123_), .Y(new_n203_));
  AOI21x1_ASAP7_75t_R  g160(.A1(new_n202_), .A2(new_n159_), .B(new_n203_), .Y(new_n204_));
  AND4x2_ASAP7_75t_R   g161(.A(new_n181_), .B(new_n193_), .C(new_n199_), .D(new_n204_), .Y(new_n205_));
  NAND2x1_ASAP7_75t_R  g162(.A(p16), .B(new_n92_), .Y(new_n206_));
  AOI211x1_ASAP7_75t_R g163(.A1(p34), .A2(o2), .B(new_n206_), .C(new_n140_), .Y(new_n207_));
  AOI21x1_ASAP7_75t_R  g164(.A1(new_n178_), .A2(new_n205_), .B(new_n207_), .Y(o3));
  INVx1_ASAP7_75t_R    g165(.A(new_n205_), .Y(o4));
  AOI211x1_ASAP7_75t_R g166(.A1(new_n189_), .A2(new_n142_), .B(new_n171_), .C(new_n166_), .Y(new_n210_));
  AOI211x1_ASAP7_75t_R g167(.A1(new_n185_), .A2(new_n120_), .B(new_n161_), .C(new_n198_), .Y(new_n211_));
  AO21x1_ASAP7_75t_R   g168(.A1(new_n210_), .A2(new_n211_), .B(new_n108_), .Y(new_n212_));
  INVx1_ASAP7_75t_R    g169(.A(new_n179_), .Y(new_n213_));
  AOI21x1_ASAP7_75t_R  g170(.A1(p31), .A2(new_n118_), .B(new_n213_), .Y(new_n214_));
  INVx1_ASAP7_75t_R    g171(.A(new_n201_), .Y(new_n215_));
  AOI21x1_ASAP7_75t_R  g172(.A1(p32), .A2(new_n118_), .B(new_n215_), .Y(new_n216_));
  AO21x1_ASAP7_75t_R   g173(.A1(new_n210_), .A2(new_n211_), .B(new_n119_), .Y(new_n217_));
  AOI22x1_ASAP7_75t_R  g174(.A1(new_n212_), .A2(new_n214_), .B1(new_n216_), .B2(new_n217_), .Y(new_n218_));
  AOI21x1_ASAP7_75t_R  g175(.A1(new_n210_), .A2(new_n211_), .B(new_n115_), .Y(new_n219_));
  AO21x1_ASAP7_75t_R   g176(.A1(new_n107_), .A2(new_n111_), .B(new_n115_), .Y(new_n220_));
  NAND2x1_ASAP7_75t_R  g177(.A(new_n174_), .B(new_n220_), .Y(new_n221_));
  AOI211x1_ASAP7_75t_R g178(.A1(new_n183_), .A2(new_n192_), .B(new_n219_), .C(new_n221_), .Y(new_n222_));
  NAND2x1_ASAP7_75t_R  g179(.A(new_n204_), .B(new_n199_), .Y(new_n223_));
  NAND3x1_ASAP7_75t_R  g180(.A(new_n186_), .B(new_n188_), .C(new_n191_), .Y(new_n224_));
  OAI21x1_ASAP7_75t_R  g181(.A1(new_n102_), .A2(new_n152_), .B(new_n182_), .Y(new_n225_));
  AOI21x1_ASAP7_75t_R  g182(.A1(p30), .A2(new_n224_), .B(new_n225_), .Y(new_n226_));
  AOI211x1_ASAP7_75t_R g183(.A1(new_n212_), .A2(new_n214_), .B(new_n226_), .C(new_n172_), .Y(new_n227_));
  AO211x2_ASAP7_75t_R  g184(.A1(new_n218_), .A2(new_n222_), .B(new_n223_), .C(new_n227_), .Y(o5));
  INVx1_ASAP7_75t_R    g185(.A(new_n204_), .Y(new_n229_));
  AO21x1_ASAP7_75t_R   g186(.A1(new_n170_), .A2(new_n159_), .B(new_n171_), .Y(new_n230_));
  OA21x2_ASAP7_75t_R   g187(.A1(new_n162_), .A2(new_n230_), .B(new_n181_), .Y(new_n231_));
  INVx1_ASAP7_75t_R    g188(.A(new_n199_), .Y(new_n232_));
  AOI21x1_ASAP7_75t_R  g189(.A1(new_n222_), .A2(new_n218_), .B(new_n232_), .Y(new_n233_));
  OAI21x1_ASAP7_75t_R  g190(.A1(new_n229_), .A2(new_n231_), .B(new_n233_), .Y(o6));
endmodule


