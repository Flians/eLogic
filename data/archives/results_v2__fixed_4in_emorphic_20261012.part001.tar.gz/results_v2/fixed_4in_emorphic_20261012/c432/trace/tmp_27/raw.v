// Benchmark "/tmp/" written by ABC on Mon Oct 12 15:06:06 2026

module \/tmp/  ( 
    p12, p25, p27, p16, p30, p23, p26, p34, p0, p28, p10, p15, p4, p31,
    p17, p20, p3, p24, p18, p11, p35, p32, p1, p22, p29, p6, p21, p9, p5,
    p13, p7, p19, p33, p14, p2, p8,
    o0, o1, o2, o3, o4, o5, o6  );
  input  p12, p25, p27, p16, p30, p23, p26, p34, p0, p28, p10, p15, p4,
    p31, p17, p20, p3, p24, p18, p11, p35, p32, p1, p22, p29, p6, p21, p9,
    p5, p13, p7, p19, p33, p14, p2, p8;
  output o0, o1, o2, o3, o4, o5, o6;
  wire new_n44_, new_n45_, new_n46_, new_n47_, new_n48_, new_n49_, new_n50_,
    new_n51_, new_n52_, new_n53_, new_n54_, new_n55_, new_n56_, new_n57_,
    new_n58_, new_n59_, new_n60_, new_n61_, new_n63_, new_n64_, new_n65_,
    new_n66_, new_n67_, new_n68_, new_n69_, new_n70_, new_n71_, new_n72_,
    new_n73_, new_n74_, new_n75_, new_n76_, new_n77_, new_n78_, new_n79_,
    new_n80_, new_n81_, new_n82_, new_n83_, new_n84_, new_n85_, new_n86_,
    new_n87_, new_n88_, new_n89_, new_n90_, new_n91_, new_n92_, new_n93_,
    new_n94_, new_n95_, new_n96_, new_n97_, new_n98_, new_n99_, new_n100_,
    new_n101_, new_n102_, new_n103_, new_n104_, new_n105_, new_n106_,
    new_n107_, new_n109_, new_n110_, new_n111_, new_n112_, new_n113_,
    new_n114_, new_n115_, new_n116_, new_n117_, new_n118_, new_n119_,
    new_n120_, new_n121_, new_n122_, new_n123_, new_n124_, new_n125_,
    new_n126_, new_n127_, new_n128_, new_n129_, new_n130_, new_n131_,
    new_n132_, new_n133_, new_n134_, new_n135_, new_n136_, new_n137_,
    new_n138_, new_n139_, new_n140_, new_n141_, new_n142_, new_n143_,
    new_n144_, new_n145_, new_n146_, new_n147_, new_n148_, new_n149_,
    new_n150_, new_n151_, new_n152_, new_n153_, new_n154_, new_n155_,
    new_n156_, new_n157_, new_n158_, new_n159_, new_n160_, new_n161_,
    new_n162_, new_n163_, new_n164_, new_n165_, new_n166_, new_n167_,
    new_n168_, new_n169_, new_n170_, new_n171_, new_n172_, new_n173_,
    new_n174_, new_n175_, new_n176_, new_n177_, new_n178_, new_n179_,
    new_n180_, new_n181_, new_n182_, new_n183_, new_n185_, new_n186_,
    new_n187_, new_n188_, new_n189_, new_n190_, new_n191_, new_n192_,
    new_n193_, new_n194_, new_n195_, new_n196_, new_n197_, new_n198_,
    new_n199_, new_n200_, new_n201_, new_n202_, new_n203_, new_n204_,
    new_n205_, new_n206_, new_n207_, new_n208_, new_n209_, new_n210_,
    new_n211_, new_n212_, new_n213_, new_n214_, new_n215_, new_n216_,
    new_n217_, new_n218_, new_n219_, new_n220_, new_n221_, new_n222_,
    new_n223_, new_n224_, new_n225_, new_n226_, new_n229_, new_n230_,
    new_n231_, new_n232_, new_n233_, new_n234_, new_n235_, new_n236_,
    new_n237_, new_n238_, new_n239_, new_n240_, new_n241_, new_n242_,
    new_n243_, new_n244_, new_n245_, new_n246_, new_n247_, new_n248_,
    new_n249_, new_n250_, new_n251_, new_n252_, new_n253_, new_n254_,
    new_n255_, new_n256_, new_n257_, new_n259_, new_n260_;
  INVx1_ASAP7_75t_R    g000(.A(p5), .Y(new_n44_));
  INVx1_ASAP7_75t_R    g001(.A(p7), .Y(new_n45_));
  AOI22x1_ASAP7_75t_R  g002(.A1(p6), .A2(new_n44_), .B1(new_n45_), .B2(p8), .Y(new_n46_));
  INVx1_ASAP7_75t_R    g003(.A(p3), .Y(new_n47_));
  NAND2x1_ASAP7_75t_R  g004(.A(p4), .B(new_n47_), .Y(new_n48_));
  INVx1_ASAP7_75t_R    g005(.A(p9), .Y(new_n49_));
  NAND2x1_ASAP7_75t_R  g006(.A(p10), .B(new_n49_), .Y(new_n50_));
  AND3x1_ASAP7_75t_R   g007(.A(new_n46_), .B(new_n48_), .C(new_n50_), .Y(new_n51_));
  INVx1_ASAP7_75t_R    g008(.A(p16), .Y(new_n52_));
  INVx1_ASAP7_75t_R    g009(.A(p14), .Y(new_n53_));
  OAI22x1_ASAP7_75t_R  g010(.A1(new_n52_), .A2(p15), .B1(new_n53_), .B2(p13), .Y(new_n54_));
  INVx1_ASAP7_75t_R    g011(.A(p0), .Y(new_n55_));
  INVx1_ASAP7_75t_R    g012(.A(p2), .Y(new_n56_));
  OAI22x1_ASAP7_75t_R  g013(.A1(new_n55_), .A2(p35), .B1(new_n56_), .B2(p1), .Y(new_n57_));
  INVx1_ASAP7_75t_R    g014(.A(p12), .Y(new_n58_));
  INVx1_ASAP7_75t_R    g015(.A(p4), .Y(new_n59_));
  OAI22x1_ASAP7_75t_R  g016(.A1(new_n58_), .A2(p11), .B1(new_n59_), .B2(p3), .Y(new_n60_));
  NOR3x1_ASAP7_75t_R   g017(.A(new_n54_), .B(new_n57_), .C(new_n60_), .Y(new_n61_));
  NAND2x1_ASAP7_75t_R  g018(.A(new_n51_), .B(new_n61_), .Y(o0));
  INVx1_ASAP7_75t_R    g019(.A(p35), .Y(new_n63_));
  AOI21x1_ASAP7_75t_R  g020(.A1(new_n51_), .A2(new_n61_), .B(new_n63_), .Y(new_n64_));
  NOR2x1_ASAP7_75t_R   g021(.A(p17), .B(new_n55_), .Y(new_n65_));
  INVx1_ASAP7_75t_R    g022(.A(new_n65_), .Y(new_n66_));
  INVx1_ASAP7_75t_R    g023(.A(p15), .Y(new_n67_));
  INVx1_ASAP7_75t_R    g024(.A(p13), .Y(new_n68_));
  AOI22x1_ASAP7_75t_R  g025(.A1(p16), .A2(new_n67_), .B1(new_n68_), .B2(p14), .Y(new_n69_));
  INVx1_ASAP7_75t_R    g026(.A(p1), .Y(new_n70_));
  AOI22x1_ASAP7_75t_R  g027(.A1(p0), .A2(new_n63_), .B1(new_n70_), .B2(p2), .Y(new_n71_));
  INVx1_ASAP7_75t_R    g028(.A(p11), .Y(new_n72_));
  AOI22x1_ASAP7_75t_R  g029(.A1(p12), .A2(new_n72_), .B1(new_n47_), .B2(p4), .Y(new_n73_));
  AO31x2_ASAP7_75t_R   g030(.A1(new_n69_), .A2(new_n71_), .A3(new_n73_), .B(new_n68_), .Y(new_n74_));
  AO21x1_ASAP7_75t_R   g031(.A1(new_n50_), .A2(new_n46_), .B(new_n68_), .Y(new_n75_));
  NOR2x1_ASAP7_75t_R   g032(.A(p24), .B(new_n53_), .Y(new_n76_));
  NAND3x1_ASAP7_75t_R  g033(.A(new_n74_), .B(new_n75_), .C(new_n76_), .Y(new_n77_));
  OAI21x1_ASAP7_75t_R  g034(.A1(new_n64_), .A2(new_n66_), .B(new_n77_), .Y(new_n78_));
  AOI21x1_ASAP7_75t_R  g035(.A1(new_n51_), .A2(new_n61_), .B(new_n67_), .Y(new_n79_));
  NOR2x1_ASAP7_75t_R   g036(.A(p25), .B(new_n52_), .Y(new_n80_));
  INVx1_ASAP7_75t_R    g037(.A(new_n80_), .Y(new_n81_));
  AOI21x1_ASAP7_75t_R  g038(.A1(new_n51_), .A2(new_n61_), .B(new_n45_), .Y(new_n82_));
  INVx1_ASAP7_75t_R    g039(.A(p8), .Y(new_n83_));
  NOR2x1_ASAP7_75t_R   g040(.A(p21), .B(new_n83_), .Y(new_n84_));
  INVx1_ASAP7_75t_R    g041(.A(new_n84_), .Y(new_n85_));
  OAI22x1_ASAP7_75t_R  g042(.A1(new_n79_), .A2(new_n81_), .B1(new_n82_), .B2(new_n85_), .Y(new_n86_));
  NOR2x1_ASAP7_75t_R   g043(.A(new_n78_), .B(new_n86_), .Y(new_n87_));
  INVx1_ASAP7_75t_R    g044(.A(p18), .Y(new_n88_));
  NOR2x1_ASAP7_75t_R   g045(.A(p1), .B(new_n56_), .Y(new_n89_));
  AO31x2_ASAP7_75t_R   g046(.A1(new_n61_), .A2(new_n51_), .A3(p2), .B(new_n89_), .Y(new_n90_));
  INVx1_ASAP7_75t_R    g047(.A(p19), .Y(new_n91_));
  NAND2x1_ASAP7_75t_R  g048(.A(p4), .B(new_n91_), .Y(new_n92_));
  AOI21x1_ASAP7_75t_R  g049(.A1(new_n48_), .A2(o0), .B(new_n92_), .Y(new_n93_));
  NOR2x1_ASAP7_75t_R   g050(.A(p23), .B(new_n58_), .Y(new_n94_));
  INVx1_ASAP7_75t_R    g051(.A(new_n94_), .Y(new_n95_));
  AOI21x1_ASAP7_75t_R  g052(.A1(new_n51_), .A2(new_n61_), .B(new_n72_), .Y(new_n96_));
  NOR2x1_ASAP7_75t_R   g053(.A(new_n95_), .B(new_n96_), .Y(new_n97_));
  AOI211x1_ASAP7_75t_R g054(.A1(new_n88_), .A2(new_n90_), .B(new_n93_), .C(new_n97_), .Y(new_n98_));
  NAND3x1_ASAP7_75t_R  g055(.A(new_n46_), .B(new_n48_), .C(new_n50_), .Y(new_n99_));
  NAND3x1_ASAP7_75t_R  g056(.A(new_n69_), .B(new_n71_), .C(new_n73_), .Y(new_n100_));
  OAI21x1_ASAP7_75t_R  g057(.A1(new_n99_), .A2(new_n100_), .B(p5), .Y(new_n101_));
  INVx1_ASAP7_75t_R    g058(.A(p6), .Y(new_n102_));
  NOR2x1_ASAP7_75t_R   g059(.A(p20), .B(new_n102_), .Y(new_n103_));
  OAI21x1_ASAP7_75t_R  g060(.A1(new_n99_), .A2(new_n100_), .B(p9), .Y(new_n104_));
  INVx1_ASAP7_75t_R    g061(.A(p22), .Y(new_n105_));
  AND2x2_ASAP7_75t_R   g062(.A(p10), .B(new_n105_), .Y(new_n106_));
  AOI22x1_ASAP7_75t_R  g063(.A1(new_n101_), .A2(new_n103_), .B1(new_n104_), .B2(new_n106_), .Y(new_n107_));
  NAND3x1_ASAP7_75t_R  g064(.A(new_n87_), .B(new_n98_), .C(new_n107_), .Y(o1));
  OAI21x1_ASAP7_75t_R  g065(.A1(new_n99_), .A2(new_n100_), .B(p35), .Y(new_n109_));
  AOI21x1_ASAP7_75t_R  g066(.A1(new_n50_), .A2(new_n46_), .B(new_n68_), .Y(new_n110_));
  AOI21x1_ASAP7_75t_R  g067(.A1(p13), .A2(new_n100_), .B(new_n110_), .Y(new_n111_));
  AOI22x1_ASAP7_75t_R  g068(.A1(new_n109_), .A2(new_n65_), .B1(new_n111_), .B2(new_n76_), .Y(new_n112_));
  NAND2x1_ASAP7_75t_R  g069(.A(p2), .B(new_n88_), .Y(new_n113_));
  AO21x1_ASAP7_75t_R   g070(.A1(p1), .A2(o0), .B(new_n113_), .Y(new_n114_));
  OR3x1_ASAP7_75t_R    g071(.A(new_n59_), .B(p3), .C(p19), .Y(new_n115_));
  OA31x2_ASAP7_75t_R   g072(.A1(new_n92_), .A2(new_n99_), .A3(new_n100_), .B1(new_n115_), .Y(new_n116_));
  NAND3x1_ASAP7_75t_R  g073(.A(new_n112_), .B(new_n114_), .C(new_n116_), .Y(new_n117_));
  OAI21x1_ASAP7_75t_R  g074(.A1(new_n99_), .A2(new_n100_), .B(p11), .Y(new_n118_));
  AOI22x1_ASAP7_75t_R  g075(.A1(new_n104_), .A2(new_n106_), .B1(new_n118_), .B2(new_n94_), .Y(new_n119_));
  OAI21x1_ASAP7_75t_R  g076(.A1(new_n99_), .A2(new_n100_), .B(p15), .Y(new_n120_));
  OAI21x1_ASAP7_75t_R  g077(.A1(new_n99_), .A2(new_n100_), .B(p7), .Y(new_n121_));
  AOI22x1_ASAP7_75t_R  g078(.A1(new_n120_), .A2(new_n80_), .B1(new_n121_), .B2(new_n84_), .Y(new_n122_));
  NAND2x1_ASAP7_75t_R  g079(.A(new_n103_), .B(new_n101_), .Y(new_n123_));
  NAND3x1_ASAP7_75t_R  g080(.A(new_n119_), .B(new_n122_), .C(new_n123_), .Y(new_n124_));
  OAI21x1_ASAP7_75t_R  g081(.A1(new_n117_), .A2(new_n124_), .B(p21), .Y(new_n125_));
  INVx1_ASAP7_75t_R    g082(.A(p30), .Y(new_n126_));
  AND3x1_ASAP7_75t_R   g083(.A(new_n121_), .B(new_n126_), .C(p8), .Y(new_n127_));
  AO31x2_ASAP7_75t_R   g084(.A1(new_n122_), .A2(new_n107_), .A3(new_n112_), .B(new_n105_), .Y(new_n128_));
  AO21x1_ASAP7_75t_R   g085(.A1(new_n51_), .A2(new_n61_), .B(new_n70_), .Y(new_n129_));
  INVx1_ASAP7_75t_R    g086(.A(new_n113_), .Y(new_n130_));
  AOI22x1_ASAP7_75t_R  g087(.A1(new_n129_), .A2(new_n130_), .B1(new_n118_), .B2(new_n94_), .Y(new_n131_));
  AO21x1_ASAP7_75t_R   g088(.A1(new_n116_), .A2(new_n131_), .B(new_n105_), .Y(new_n132_));
  INVx1_ASAP7_75t_R    g089(.A(p31), .Y(new_n133_));
  AND3x1_ASAP7_75t_R   g090(.A(new_n104_), .B(p10), .C(new_n133_), .Y(new_n134_));
  AND3x1_ASAP7_75t_R   g091(.A(new_n128_), .B(new_n132_), .C(new_n134_), .Y(new_n135_));
  INVx1_ASAP7_75t_R    g092(.A(p29), .Y(new_n136_));
  AND3x1_ASAP7_75t_R   g093(.A(new_n101_), .B(new_n136_), .C(p6), .Y(new_n137_));
  INVx1_ASAP7_75t_R    g094(.A(new_n137_), .Y(new_n138_));
  AOI21x1_ASAP7_75t_R  g095(.A1(p20), .A2(o1), .B(new_n138_), .Y(new_n139_));
  AOI211x1_ASAP7_75t_R g096(.A1(new_n125_), .A2(new_n127_), .B(new_n135_), .C(new_n139_), .Y(new_n140_));
  AO21x1_ASAP7_75t_R   g097(.A1(p3), .A2(o0), .B(new_n59_), .Y(new_n141_));
  NOR2x1_ASAP7_75t_R   g098(.A(p28), .B(new_n141_), .Y(new_n142_));
  INVx1_ASAP7_75t_R    g099(.A(new_n142_), .Y(new_n143_));
  AND3x1_ASAP7_75t_R   g100(.A(new_n112_), .B(new_n114_), .C(new_n116_), .Y(new_n144_));
  INVx1_ASAP7_75t_R    g101(.A(p20), .Y(new_n145_));
  AOI21x1_ASAP7_75t_R  g102(.A1(p5), .A2(o0), .B(new_n102_), .Y(new_n146_));
  AOI21x1_ASAP7_75t_R  g103(.A1(new_n51_), .A2(new_n61_), .B(new_n49_), .Y(new_n147_));
  INVx1_ASAP7_75t_R    g104(.A(new_n106_), .Y(new_n148_));
  OAI22x1_ASAP7_75t_R  g105(.A1(new_n147_), .A2(new_n148_), .B1(new_n96_), .B2(new_n95_), .Y(new_n149_));
  AOI211x1_ASAP7_75t_R g106(.A1(new_n145_), .A2(new_n146_), .B(new_n149_), .C(new_n86_), .Y(new_n150_));
  AOI21x1_ASAP7_75t_R  g107(.A1(new_n144_), .A2(new_n150_), .B(new_n91_), .Y(new_n151_));
  INVx1_ASAP7_75t_R    g108(.A(p23), .Y(new_n152_));
  AO31x2_ASAP7_75t_R   g109(.A1(new_n122_), .A2(new_n107_), .A3(new_n112_), .B(new_n152_), .Y(new_n153_));
  AO21x1_ASAP7_75t_R   g110(.A1(new_n116_), .A2(new_n131_), .B(new_n152_), .Y(new_n154_));
  INVx1_ASAP7_75t_R    g111(.A(p32), .Y(new_n155_));
  AND3x1_ASAP7_75t_R   g112(.A(new_n118_), .B(p12), .C(new_n155_), .Y(new_n156_));
  NAND3x1_ASAP7_75t_R  g113(.A(new_n153_), .B(new_n154_), .C(new_n156_), .Y(new_n157_));
  OAI21x1_ASAP7_75t_R  g114(.A1(new_n143_), .A2(new_n151_), .B(new_n157_), .Y(new_n158_));
  OA21x2_ASAP7_75t_R   g115(.A1(new_n99_), .A2(new_n100_), .B(p1), .Y(new_n159_));
  OAI22x1_ASAP7_75t_R  g116(.A1(new_n159_), .A2(new_n113_), .B1(new_n96_), .B2(new_n95_), .Y(new_n160_));
  INVx1_ASAP7_75t_R    g117(.A(new_n90_), .Y(new_n161_));
  NOR3x1_ASAP7_75t_R   g118(.A(new_n160_), .B(new_n93_), .C(new_n161_), .Y(new_n162_));
  AND3x1_ASAP7_75t_R   g119(.A(new_n122_), .B(new_n107_), .C(new_n112_), .Y(new_n163_));
  INVx1_ASAP7_75t_R    g120(.A(new_n114_), .Y(new_n164_));
  AOI21x1_ASAP7_75t_R  g121(.A1(new_n162_), .A2(new_n163_), .B(new_n164_), .Y(new_n165_));
  INVx1_ASAP7_75t_R    g122(.A(p17), .Y(new_n166_));
  AO31x2_ASAP7_75t_R   g123(.A1(new_n122_), .A2(new_n107_), .A3(new_n112_), .B(new_n166_), .Y(new_n167_));
  AO21x1_ASAP7_75t_R   g124(.A1(new_n116_), .A2(new_n131_), .B(new_n166_), .Y(new_n168_));
  NAND2x1_ASAP7_75t_R  g125(.A(p0), .B(new_n109_), .Y(new_n169_));
  NOR2x1_ASAP7_75t_R   g126(.A(p26), .B(new_n169_), .Y(new_n170_));
  NAND3x1_ASAP7_75t_R  g127(.A(new_n167_), .B(new_n168_), .C(new_n170_), .Y(new_n171_));
  OAI21x1_ASAP7_75t_R  g128(.A1(p27), .A2(new_n165_), .B(new_n171_), .Y(new_n172_));
  INVx1_ASAP7_75t_R    g129(.A(p25), .Y(new_n173_));
  AOI21x1_ASAP7_75t_R  g130(.A1(new_n144_), .A2(new_n150_), .B(new_n173_), .Y(new_n174_));
  OR3x1_ASAP7_75t_R    g131(.A(new_n79_), .B(new_n52_), .C(p34), .Y(new_n175_));
  INVx1_ASAP7_75t_R    g132(.A(p24), .Y(new_n176_));
  AO31x2_ASAP7_75t_R   g133(.A1(new_n122_), .A2(new_n107_), .A3(new_n112_), .B(new_n176_), .Y(new_n177_));
  OAI21x1_ASAP7_75t_R  g134(.A1(new_n93_), .A2(new_n160_), .B(p24), .Y(new_n178_));
  NAND2x1_ASAP7_75t_R  g135(.A(p14), .B(new_n111_), .Y(new_n179_));
  NOR2x1_ASAP7_75t_R   g136(.A(p33), .B(new_n179_), .Y(new_n180_));
  NAND3x1_ASAP7_75t_R  g137(.A(new_n177_), .B(new_n178_), .C(new_n180_), .Y(new_n181_));
  OAI21x1_ASAP7_75t_R  g138(.A1(new_n174_), .A2(new_n175_), .B(new_n181_), .Y(new_n182_));
  NOR3x1_ASAP7_75t_R   g139(.A(new_n158_), .B(new_n172_), .C(new_n182_), .Y(new_n183_));
  NAND2x1_ASAP7_75t_R  g140(.A(new_n140_), .B(new_n183_), .Y(o2));
  AOI21x1_ASAP7_75t_R  g141(.A1(new_n144_), .A2(new_n150_), .B(new_n145_), .Y(new_n185_));
  NAND3x1_ASAP7_75t_R  g142(.A(new_n128_), .B(new_n132_), .C(new_n134_), .Y(new_n186_));
  OAI21x1_ASAP7_75t_R  g143(.A1(new_n138_), .A2(new_n185_), .B(new_n186_), .Y(new_n187_));
  AND2x2_ASAP7_75t_R   g144(.A(new_n127_), .B(new_n125_), .Y(new_n188_));
  AO21x1_ASAP7_75t_R   g145(.A1(p24), .A2(o1), .B(new_n179_), .Y(new_n189_));
  NOR3x1_ASAP7_75t_R   g146(.A(new_n187_), .B(new_n188_), .C(new_n189_), .Y(new_n190_));
  INVx1_ASAP7_75t_R    g147(.A(new_n181_), .Y(new_n191_));
  AOI21x1_ASAP7_75t_R  g148(.A1(new_n190_), .A2(new_n183_), .B(new_n191_), .Y(new_n192_));
  OAI21x1_ASAP7_75t_R  g149(.A1(new_n117_), .A2(new_n124_), .B(p23), .Y(new_n193_));
  NAND3x1_ASAP7_75t_R  g150(.A(new_n193_), .B(p12), .C(new_n118_), .Y(new_n194_));
  NOR3x1_ASAP7_75t_R   g151(.A(new_n187_), .B(new_n188_), .C(new_n194_), .Y(new_n195_));
  INVx1_ASAP7_75t_R    g152(.A(new_n157_), .Y(new_n196_));
  AOI21x1_ASAP7_75t_R  g153(.A1(new_n195_), .A2(new_n183_), .B(new_n196_), .Y(new_n197_));
  NAND2x1_ASAP7_75t_R  g154(.A(p10), .B(new_n104_), .Y(new_n198_));
  AO21x1_ASAP7_75t_R   g155(.A1(p22), .A2(o1), .B(new_n198_), .Y(new_n199_));
  NOR3x1_ASAP7_75t_R   g156(.A(new_n187_), .B(new_n188_), .C(new_n199_), .Y(new_n200_));
  AOI21x1_ASAP7_75t_R  g157(.A1(new_n200_), .A2(new_n183_), .B(new_n135_), .Y(new_n201_));
  NAND3x1_ASAP7_75t_R  g158(.A(new_n125_), .B(p8), .C(new_n121_), .Y(new_n202_));
  NOR3x1_ASAP7_75t_R   g159(.A(new_n187_), .B(new_n126_), .C(new_n202_), .Y(new_n203_));
  AOI21x1_ASAP7_75t_R  g160(.A1(new_n203_), .A2(new_n183_), .B(new_n188_), .Y(new_n204_));
  AND4x2_ASAP7_75t_R   g161(.A(new_n192_), .B(new_n197_), .C(new_n201_), .D(new_n204_), .Y(new_n205_));
  AO21x1_ASAP7_75t_R   g162(.A1(p17), .A2(o1), .B(new_n169_), .Y(new_n206_));
  NOR3x1_ASAP7_75t_R   g163(.A(new_n187_), .B(new_n188_), .C(new_n206_), .Y(new_n207_));
  OAI21x1_ASAP7_75t_R  g164(.A1(new_n117_), .A2(new_n124_), .B(p17), .Y(new_n208_));
  AOI22x1_ASAP7_75t_R  g165(.A1(new_n183_), .A2(new_n207_), .B1(new_n208_), .B2(new_n170_), .Y(new_n209_));
  NOR3x1_ASAP7_75t_R   g166(.A(new_n187_), .B(new_n188_), .C(new_n165_), .Y(new_n210_));
  INVx1_ASAP7_75t_R    g167(.A(p27), .Y(new_n211_));
  NAND3x1_ASAP7_75t_R  g168(.A(new_n122_), .B(new_n107_), .C(new_n112_), .Y(new_n212_));
  NAND3x1_ASAP7_75t_R  g169(.A(new_n131_), .B(new_n116_), .C(new_n90_), .Y(new_n213_));
  OAI21x1_ASAP7_75t_R  g170(.A1(new_n212_), .A2(new_n213_), .B(new_n114_), .Y(new_n214_));
  AOI22x1_ASAP7_75t_R  g171(.A1(new_n183_), .A2(new_n210_), .B1(new_n211_), .B2(new_n214_), .Y(new_n215_));
  AO21x1_ASAP7_75t_R   g172(.A1(p19), .A2(o1), .B(new_n141_), .Y(new_n216_));
  NOR3x1_ASAP7_75t_R   g173(.A(new_n187_), .B(new_n188_), .C(new_n216_), .Y(new_n217_));
  NOR2x1_ASAP7_75t_R   g174(.A(new_n143_), .B(new_n151_), .Y(new_n218_));
  AOI21x1_ASAP7_75t_R  g175(.A1(new_n217_), .A2(new_n183_), .B(new_n218_), .Y(new_n219_));
  OAI21x1_ASAP7_75t_R  g176(.A1(new_n117_), .A2(new_n124_), .B(p20), .Y(new_n220_));
  NAND2x1_ASAP7_75t_R  g177(.A(new_n146_), .B(new_n220_), .Y(new_n221_));
  NOR3x1_ASAP7_75t_R   g178(.A(new_n187_), .B(new_n188_), .C(new_n221_), .Y(new_n222_));
  AOI21x1_ASAP7_75t_R  g179(.A1(new_n222_), .A2(new_n183_), .B(new_n139_), .Y(new_n223_));
  AND4x2_ASAP7_75t_R   g180(.A(new_n209_), .B(new_n215_), .C(new_n219_), .D(new_n223_), .Y(new_n224_));
  OR3x1_ASAP7_75t_R    g181(.A(new_n174_), .B(new_n52_), .C(new_n79_), .Y(new_n225_));
  AOI21x1_ASAP7_75t_R  g182(.A1(p34), .A2(o2), .B(new_n225_), .Y(new_n226_));
  AOI21x1_ASAP7_75t_R  g183(.A1(new_n205_), .A2(new_n224_), .B(new_n226_), .Y(o3));
  INVx1_ASAP7_75t_R    g184(.A(new_n205_), .Y(o4));
  NAND2x1_ASAP7_75t_R  g185(.A(new_n127_), .B(new_n125_), .Y(new_n229_));
  NAND2x1_ASAP7_75t_R  g186(.A(new_n137_), .B(new_n220_), .Y(new_n230_));
  NAND3x1_ASAP7_75t_R  g187(.A(new_n229_), .B(new_n230_), .C(new_n186_), .Y(new_n231_));
  AOI21x1_ASAP7_75t_R  g188(.A1(p32), .A2(new_n231_), .B(new_n194_), .Y(new_n232_));
  OAI21x1_ASAP7_75t_R  g189(.A1(new_n117_), .A2(new_n124_), .B(p19), .Y(new_n233_));
  AOI22x1_ASAP7_75t_R  g190(.A1(new_n193_), .A2(new_n156_), .B1(new_n233_), .B2(new_n142_), .Y(new_n234_));
  AOI22x1_ASAP7_75t_R  g191(.A1(new_n214_), .A2(new_n211_), .B1(new_n208_), .B2(new_n170_), .Y(new_n235_));
  NAND2x1_ASAP7_75t_R  g192(.A(new_n116_), .B(new_n131_), .Y(new_n236_));
  OAI21x1_ASAP7_75t_R  g193(.A1(new_n236_), .A2(new_n212_), .B(p24), .Y(new_n237_));
  OAI21x1_ASAP7_75t_R  g194(.A1(new_n117_), .A2(new_n124_), .B(p25), .Y(new_n238_));
  INVx1_ASAP7_75t_R    g195(.A(new_n175_), .Y(new_n239_));
  AOI22x1_ASAP7_75t_R  g196(.A1(new_n237_), .A2(new_n180_), .B1(new_n238_), .B2(new_n239_), .Y(new_n240_));
  AO31x2_ASAP7_75t_R   g197(.A1(new_n234_), .A2(new_n235_), .A3(new_n240_), .B(new_n155_), .Y(new_n241_));
  AO31x2_ASAP7_75t_R   g198(.A1(new_n234_), .A2(new_n235_), .A3(new_n240_), .B(new_n133_), .Y(new_n242_));
  AOI21x1_ASAP7_75t_R  g199(.A1(new_n229_), .A2(new_n230_), .B(new_n133_), .Y(new_n243_));
  NOR2x1_ASAP7_75t_R   g200(.A(new_n199_), .B(new_n243_), .Y(new_n244_));
  AOI22x1_ASAP7_75t_R  g201(.A1(new_n232_), .A2(new_n241_), .B1(new_n242_), .B2(new_n244_), .Y(new_n245_));
  AO31x2_ASAP7_75t_R   g202(.A1(new_n234_), .A2(new_n235_), .A3(new_n240_), .B(new_n126_), .Y(new_n246_));
  AOI21x1_ASAP7_75t_R  g203(.A1(p30), .A2(new_n187_), .B(new_n202_), .Y(new_n247_));
  OA31x2_ASAP7_75t_R   g204(.A1(new_n182_), .A2(new_n158_), .A3(new_n172_), .B1(p29), .Y(new_n248_));
  INVx1_ASAP7_75t_R    g205(.A(new_n221_), .Y(new_n249_));
  OAI21x1_ASAP7_75t_R  g206(.A1(new_n136_), .A2(new_n140_), .B(new_n249_), .Y(new_n250_));
  AOI211x1_ASAP7_75t_R g207(.A1(new_n246_), .A2(new_n247_), .B(new_n248_), .C(new_n250_), .Y(new_n251_));
  NAND2x1_ASAP7_75t_R  g208(.A(new_n245_), .B(new_n251_), .Y(new_n252_));
  AO21x1_ASAP7_75t_R   g209(.A1(new_n190_), .A2(new_n183_), .B(new_n191_), .Y(new_n253_));
  AO21x1_ASAP7_75t_R   g210(.A1(new_n195_), .A2(new_n183_), .B(new_n196_), .Y(new_n254_));
  NOR2x1_ASAP7_75t_R   g211(.A(new_n253_), .B(new_n254_), .Y(new_n255_));
  AO21x1_ASAP7_75t_R   g212(.A1(new_n217_), .A2(new_n183_), .B(new_n218_), .Y(new_n256_));
  NAND3x1_ASAP7_75t_R  g213(.A(new_n256_), .B(new_n201_), .C(new_n204_), .Y(new_n257_));
  NAND3x1_ASAP7_75t_R  g214(.A(new_n252_), .B(new_n255_), .C(new_n257_), .Y(o5));
  OA21x2_ASAP7_75t_R   g215(.A1(new_n215_), .A2(new_n256_), .B(new_n201_), .Y(new_n259_));
  AOI21x1_ASAP7_75t_R  g216(.A1(new_n245_), .A2(new_n251_), .B(new_n253_), .Y(new_n260_));
  OAI21x1_ASAP7_75t_R  g217(.A1(new_n254_), .A2(new_n259_), .B(new_n260_), .Y(o6));
endmodule


