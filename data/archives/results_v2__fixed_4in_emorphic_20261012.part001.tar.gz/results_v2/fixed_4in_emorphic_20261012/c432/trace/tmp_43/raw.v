// Benchmark "/tmp/" written by ABC on Mon Oct 12 15:06:08 2026

module \/tmp/  ( 
    p13, p31, p24, p15, p23, p16, p26, p1, p25, p19, p6, p27, p8, p2, p32,
    p14, p18, p35, p4, p9, p28, p29, p22, p12, p7, p5, p11, p21, p30, p20,
    p34, p33, p0, p3, p10, p17,
    o0, o1, o2, o3, o4, o5, o6  );
  input  p13, p31, p24, p15, p23, p16, p26, p1, p25, p19, p6, p27, p8,
    p2, p32, p14, p18, p35, p4, p9, p28, p29, p22, p12, p7, p5, p11, p21,
    p30, p20, p34, p33, p0, p3, p10, p17;
  output o0, o1, o2, o3, o4, o5, o6;
  wire new_n44_, new_n45_, new_n46_, new_n47_, new_n48_, new_n49_, new_n50_,
    new_n51_, new_n52_, new_n53_, new_n54_, new_n55_, new_n56_, new_n57_,
    new_n58_, new_n59_, new_n61_, new_n62_, new_n63_, new_n64_, new_n65_,
    new_n66_, new_n67_, new_n68_, new_n69_, new_n70_, new_n71_, new_n72_,
    new_n73_, new_n74_, new_n75_, new_n76_, new_n77_, new_n78_, new_n79_,
    new_n80_, new_n81_, new_n82_, new_n83_, new_n84_, new_n85_, new_n86_,
    new_n87_, new_n88_, new_n89_, new_n90_, new_n91_, new_n92_, new_n93_,
    new_n94_, new_n95_, new_n96_, new_n97_, new_n98_, new_n99_, new_n100_,
    new_n101_, new_n102_, new_n103_, new_n104_, new_n105_, new_n106_,
    new_n107_, new_n108_, new_n109_, new_n111_, new_n112_, new_n113_,
    new_n114_, new_n115_, new_n116_, new_n117_, new_n118_, new_n119_,
    new_n120_, new_n121_, new_n122_, new_n123_, new_n124_, new_n125_,
    new_n126_, new_n127_, new_n128_, new_n129_, new_n130_, new_n131_,
    new_n132_, new_n133_, new_n134_, new_n135_, new_n136_, new_n137_,
    new_n138_, new_n139_, new_n140_, new_n141_, new_n142_, new_n143_,
    new_n144_, new_n145_, new_n146_, new_n147_, new_n148_, new_n149_,
    new_n150_, new_n151_, new_n152_, new_n153_, new_n154_, new_n155_,
    new_n156_, new_n157_, new_n158_, new_n159_, new_n160_, new_n161_,
    new_n162_, new_n163_, new_n164_, new_n165_, new_n166_, new_n167_,
    new_n168_, new_n169_, new_n170_, new_n171_, new_n172_, new_n173_,
    new_n174_, new_n175_, new_n177_, new_n178_, new_n179_, new_n180_,
    new_n181_, new_n182_, new_n183_, new_n184_, new_n185_, new_n186_,
    new_n187_, new_n188_, new_n189_, new_n190_, new_n191_, new_n192_,
    new_n193_, new_n194_, new_n195_, new_n196_, new_n197_, new_n198_,
    new_n199_, new_n200_, new_n201_, new_n202_, new_n203_, new_n204_,
    new_n205_, new_n206_, new_n207_, new_n208_, new_n209_, new_n210_,
    new_n211_, new_n212_, new_n213_, new_n214_, new_n215_, new_n216_,
    new_n217_, new_n218_, new_n219_, new_n220_, new_n221_, new_n222_,
    new_n223_, new_n224_, new_n225_, new_n226_, new_n227_, new_n228_,
    new_n229_, new_n230_, new_n231_, new_n232_, new_n233_, new_n234_,
    new_n235_, new_n236_, new_n237_, new_n238_, new_n239_, new_n240_,
    new_n243_, new_n244_, new_n245_, new_n246_, new_n247_, new_n248_,
    new_n249_, new_n250_, new_n251_, new_n252_, new_n253_, new_n254_,
    new_n255_, new_n256_, new_n257_, new_n258_, new_n259_, new_n260_,
    new_n261_, new_n262_, new_n263_, new_n265_, new_n266_, new_n267_,
    new_n268_, new_n269_, new_n270_;
  INVx1_ASAP7_75t_R    g000(.A(p4), .Y(new_n44_));
  INVx1_ASAP7_75t_R    g001(.A(p12), .Y(new_n45_));
  OAI22x1_ASAP7_75t_R  g002(.A1(new_n44_), .A2(p3), .B1(new_n45_), .B2(p11), .Y(new_n46_));
  INVx1_ASAP7_75t_R    g003(.A(p14), .Y(new_n47_));
  INVx1_ASAP7_75t_R    g004(.A(p16), .Y(new_n48_));
  OAI22x1_ASAP7_75t_R  g005(.A1(p13), .A2(new_n47_), .B1(new_n48_), .B2(p15), .Y(new_n49_));
  NOR2x1_ASAP7_75t_R   g006(.A(new_n46_), .B(new_n49_), .Y(new_n50_));
  INVx1_ASAP7_75t_R    g007(.A(p7), .Y(new_n51_));
  INVx1_ASAP7_75t_R    g008(.A(p10), .Y(new_n52_));
  NOR2x1_ASAP7_75t_R   g009(.A(p9), .B(new_n52_), .Y(new_n53_));
  INVx1_ASAP7_75t_R    g010(.A(p6), .Y(new_n54_));
  NOR2x1_ASAP7_75t_R   g011(.A(p5), .B(new_n54_), .Y(new_n55_));
  AOI211x1_ASAP7_75t_R g012(.A1(p8), .A2(new_n51_), .B(new_n53_), .C(new_n55_), .Y(new_n56_));
  INVx1_ASAP7_75t_R    g013(.A(p1), .Y(new_n57_));
  INVx1_ASAP7_75t_R    g014(.A(p35), .Y(new_n58_));
  AOI22x1_ASAP7_75t_R  g015(.A1(new_n57_), .A2(p2), .B1(new_n58_), .B2(p0), .Y(new_n59_));
  NAND3x1_ASAP7_75t_R  g016(.A(new_n50_), .B(new_n56_), .C(new_n59_), .Y(o0));
  INVx1_ASAP7_75t_R    g017(.A(p5), .Y(new_n61_));
  AOI22x1_ASAP7_75t_R  g018(.A1(p6), .A2(new_n61_), .B1(new_n51_), .B2(p8), .Y(new_n62_));
  INVx1_ASAP7_75t_R    g019(.A(p3), .Y(new_n63_));
  NAND2x1_ASAP7_75t_R  g020(.A(p4), .B(new_n63_), .Y(new_n64_));
  INVx1_ASAP7_75t_R    g021(.A(p9), .Y(new_n65_));
  NAND2x1_ASAP7_75t_R  g022(.A(p10), .B(new_n65_), .Y(new_n66_));
  NAND3x1_ASAP7_75t_R  g023(.A(new_n62_), .B(new_n64_), .C(new_n66_), .Y(new_n67_));
  INVx1_ASAP7_75t_R    g024(.A(p11), .Y(new_n68_));
  AOI22x1_ASAP7_75t_R  g025(.A1(p4), .A2(new_n63_), .B1(new_n68_), .B2(p12), .Y(new_n69_));
  INVx1_ASAP7_75t_R    g026(.A(p13), .Y(new_n70_));
  INVx1_ASAP7_75t_R    g027(.A(p15), .Y(new_n71_));
  AOI22x1_ASAP7_75t_R  g028(.A1(new_n70_), .A2(p14), .B1(new_n71_), .B2(p16), .Y(new_n72_));
  NAND3x1_ASAP7_75t_R  g029(.A(new_n69_), .B(new_n72_), .C(new_n59_), .Y(new_n73_));
  OAI21x1_ASAP7_75t_R  g030(.A1(new_n67_), .A2(new_n73_), .B(p9), .Y(new_n74_));
  NOR2x1_ASAP7_75t_R   g031(.A(p22), .B(new_n52_), .Y(new_n75_));
  INVx1_ASAP7_75t_R    g032(.A(p8), .Y(new_n76_));
  NOR2x1_ASAP7_75t_R   g033(.A(p21), .B(new_n76_), .Y(new_n77_));
  INVx1_ASAP7_75t_R    g034(.A(new_n77_), .Y(new_n78_));
  AOI21x1_ASAP7_75t_R  g035(.A1(p7), .A2(o0), .B(new_n78_), .Y(new_n79_));
  INVx1_ASAP7_75t_R    g036(.A(p0), .Y(new_n80_));
  NOR2x1_ASAP7_75t_R   g037(.A(p17), .B(new_n80_), .Y(new_n81_));
  INVx1_ASAP7_75t_R    g038(.A(new_n81_), .Y(new_n82_));
  AND3x1_ASAP7_75t_R   g039(.A(new_n62_), .B(new_n64_), .C(new_n66_), .Y(new_n83_));
  INVx1_ASAP7_75t_R    g040(.A(p2), .Y(new_n84_));
  OAI22x1_ASAP7_75t_R  g041(.A1(p1), .A2(new_n84_), .B1(new_n80_), .B2(p35), .Y(new_n85_));
  NOR3x1_ASAP7_75t_R   g042(.A(new_n46_), .B(new_n49_), .C(new_n85_), .Y(new_n86_));
  AOI21x1_ASAP7_75t_R  g043(.A1(new_n83_), .A2(new_n86_), .B(new_n58_), .Y(new_n87_));
  NOR2x1_ASAP7_75t_R   g044(.A(new_n82_), .B(new_n87_), .Y(new_n88_));
  AOI211x1_ASAP7_75t_R g045(.A1(new_n74_), .A2(new_n75_), .B(new_n79_), .C(new_n88_), .Y(new_n89_));
  AO21x1_ASAP7_75t_R   g046(.A1(new_n83_), .A2(new_n86_), .B(new_n68_), .Y(new_n90_));
  NOR2x1_ASAP7_75t_R   g047(.A(p23), .B(new_n45_), .Y(new_n91_));
  NOR2x1_ASAP7_75t_R   g048(.A(p19), .B(new_n44_), .Y(new_n92_));
  INVx1_ASAP7_75t_R    g049(.A(p19), .Y(new_n93_));
  AND3x1_ASAP7_75t_R   g050(.A(new_n93_), .B(new_n63_), .C(p4), .Y(new_n94_));
  AO31x2_ASAP7_75t_R   g051(.A1(new_n86_), .A2(new_n83_), .A3(new_n92_), .B(new_n94_), .Y(new_n95_));
  NOR2x1_ASAP7_75t_R   g052(.A(p18), .B(new_n84_), .Y(new_n96_));
  INVx1_ASAP7_75t_R    g053(.A(new_n96_), .Y(new_n97_));
  AOI21x1_ASAP7_75t_R  g054(.A1(p1), .A2(o0), .B(new_n97_), .Y(new_n98_));
  AOI211x1_ASAP7_75t_R g055(.A1(new_n90_), .A2(new_n91_), .B(new_n95_), .C(new_n98_), .Y(new_n99_));
  OAI21x1_ASAP7_75t_R  g056(.A1(new_n67_), .A2(new_n73_), .B(p5), .Y(new_n100_));
  NOR2x1_ASAP7_75t_R   g057(.A(p20), .B(new_n54_), .Y(new_n101_));
  AO31x2_ASAP7_75t_R   g058(.A1(new_n69_), .A2(new_n72_), .A3(new_n59_), .B(new_n70_), .Y(new_n102_));
  AO21x1_ASAP7_75t_R   g059(.A1(new_n66_), .A2(new_n62_), .B(new_n70_), .Y(new_n103_));
  NOR2x1_ASAP7_75t_R   g060(.A(p24), .B(new_n47_), .Y(new_n104_));
  AND3x1_ASAP7_75t_R   g061(.A(new_n102_), .B(new_n103_), .C(new_n104_), .Y(new_n105_));
  NOR2x1_ASAP7_75t_R   g062(.A(p25), .B(new_n48_), .Y(new_n106_));
  INVx1_ASAP7_75t_R    g063(.A(new_n106_), .Y(new_n107_));
  AOI21x1_ASAP7_75t_R  g064(.A1(p15), .A2(o0), .B(new_n107_), .Y(new_n108_));
  AOI211x1_ASAP7_75t_R g065(.A1(new_n100_), .A2(new_n101_), .B(new_n105_), .C(new_n108_), .Y(new_n109_));
  NAND3x1_ASAP7_75t_R  g066(.A(new_n89_), .B(new_n99_), .C(new_n109_), .Y(o1));
  AOI21x1_ASAP7_75t_R  g067(.A1(new_n83_), .A2(new_n86_), .B(new_n61_), .Y(new_n111_));
  INVx1_ASAP7_75t_R    g068(.A(new_n101_), .Y(new_n112_));
  AOI21x1_ASAP7_75t_R  g069(.A1(new_n83_), .A2(new_n86_), .B(new_n65_), .Y(new_n113_));
  INVx1_ASAP7_75t_R    g070(.A(new_n75_), .Y(new_n114_));
  OAI22x1_ASAP7_75t_R  g071(.A1(new_n111_), .A2(new_n112_), .B1(new_n113_), .B2(new_n114_), .Y(new_n115_));
  AOI21x1_ASAP7_75t_R  g072(.A1(new_n83_), .A2(new_n86_), .B(new_n51_), .Y(new_n116_));
  AOI21x1_ASAP7_75t_R  g073(.A1(new_n83_), .A2(new_n86_), .B(new_n71_), .Y(new_n117_));
  OAI22x1_ASAP7_75t_R  g074(.A1(new_n116_), .A2(new_n78_), .B1(new_n117_), .B2(new_n107_), .Y(new_n118_));
  NAND3x1_ASAP7_75t_R  g075(.A(new_n102_), .B(new_n103_), .C(new_n104_), .Y(new_n119_));
  OAI21x1_ASAP7_75t_R  g076(.A1(new_n87_), .A2(new_n82_), .B(new_n119_), .Y(new_n120_));
  NOR3x1_ASAP7_75t_R   g077(.A(new_n115_), .B(new_n118_), .C(new_n120_), .Y(new_n121_));
  INVx1_ASAP7_75t_R    g078(.A(p20), .Y(new_n122_));
  AO21x1_ASAP7_75t_R   g079(.A1(new_n99_), .A2(new_n121_), .B(new_n122_), .Y(new_n123_));
  INVx1_ASAP7_75t_R    g080(.A(p29), .Y(new_n124_));
  AND3x1_ASAP7_75t_R   g081(.A(new_n100_), .B(p6), .C(new_n124_), .Y(new_n125_));
  INVx1_ASAP7_75t_R    g082(.A(new_n92_), .Y(new_n126_));
  INVx1_ASAP7_75t_R    g083(.A(new_n94_), .Y(new_n127_));
  OA31x2_ASAP7_75t_R   g084(.A1(new_n126_), .A2(new_n67_), .A3(new_n73_), .B1(new_n127_), .Y(new_n128_));
  AO21x1_ASAP7_75t_R   g085(.A1(new_n83_), .A2(new_n86_), .B(new_n57_), .Y(new_n129_));
  AOI22x1_ASAP7_75t_R  g086(.A1(new_n129_), .A2(new_n96_), .B1(new_n90_), .B2(new_n91_), .Y(new_n130_));
  INVx1_ASAP7_75t_R    g087(.A(p22), .Y(new_n131_));
  AO21x1_ASAP7_75t_R   g088(.A1(new_n128_), .A2(new_n130_), .B(new_n131_), .Y(new_n132_));
  AOI22x1_ASAP7_75t_R  g089(.A1(new_n100_), .A2(new_n101_), .B1(new_n74_), .B2(new_n75_), .Y(new_n133_));
  OAI21x1_ASAP7_75t_R  g090(.A1(new_n67_), .A2(new_n73_), .B(p7), .Y(new_n134_));
  OAI21x1_ASAP7_75t_R  g091(.A1(new_n67_), .A2(new_n73_), .B(p15), .Y(new_n135_));
  AOI22x1_ASAP7_75t_R  g092(.A1(new_n134_), .A2(new_n77_), .B1(new_n135_), .B2(new_n106_), .Y(new_n136_));
  OAI21x1_ASAP7_75t_R  g093(.A1(new_n67_), .A2(new_n73_), .B(p13), .Y(new_n137_));
  OAI21x1_ASAP7_75t_R  g094(.A1(new_n67_), .A2(new_n73_), .B(p35), .Y(new_n138_));
  AOI22x1_ASAP7_75t_R  g095(.A1(new_n137_), .A2(new_n104_), .B1(new_n138_), .B2(new_n81_), .Y(new_n139_));
  AO31x2_ASAP7_75t_R   g096(.A1(new_n133_), .A2(new_n136_), .A3(new_n139_), .B(new_n131_), .Y(new_n140_));
  INVx1_ASAP7_75t_R    g097(.A(p31), .Y(new_n141_));
  AND3x1_ASAP7_75t_R   g098(.A(new_n74_), .B(new_n141_), .C(p10), .Y(new_n142_));
  AND3x1_ASAP7_75t_R   g099(.A(new_n132_), .B(new_n140_), .C(new_n142_), .Y(new_n143_));
  OR3x1_ASAP7_75t_R    g100(.A(new_n116_), .B(new_n76_), .C(p30), .Y(new_n144_));
  AOI21x1_ASAP7_75t_R  g101(.A1(p21), .A2(o1), .B(new_n144_), .Y(new_n145_));
  AOI211x1_ASAP7_75t_R g102(.A1(new_n123_), .A2(new_n125_), .B(new_n143_), .C(new_n145_), .Y(new_n146_));
  AO21x1_ASAP7_75t_R   g103(.A1(p1), .A2(o0), .B(new_n97_), .Y(new_n147_));
  NOR2x1_ASAP7_75t_R   g104(.A(new_n67_), .B(new_n73_), .Y(new_n148_));
  OAI21x1_ASAP7_75t_R  g105(.A1(new_n68_), .A2(new_n148_), .B(new_n91_), .Y(new_n149_));
  NAND3x1_ASAP7_75t_R  g106(.A(new_n147_), .B(new_n149_), .C(new_n128_), .Y(new_n150_));
  NAND3x1_ASAP7_75t_R  g107(.A(new_n133_), .B(new_n136_), .C(new_n139_), .Y(new_n151_));
  OAI21x1_ASAP7_75t_R  g108(.A1(new_n150_), .A2(new_n151_), .B(p23), .Y(new_n152_));
  INVx1_ASAP7_75t_R    g109(.A(p32), .Y(new_n153_));
  AND3x1_ASAP7_75t_R   g110(.A(new_n90_), .B(new_n153_), .C(p12), .Y(new_n154_));
  OAI21x1_ASAP7_75t_R  g111(.A1(new_n150_), .A2(new_n151_), .B(new_n128_), .Y(new_n155_));
  INVx1_ASAP7_75t_R    g112(.A(p28), .Y(new_n156_));
  OA21x2_ASAP7_75t_R   g113(.A1(new_n63_), .A2(new_n148_), .B(p4), .Y(new_n157_));
  AND2x2_ASAP7_75t_R   g114(.A(new_n156_), .B(new_n157_), .Y(new_n158_));
  AOI22x1_ASAP7_75t_R  g115(.A1(new_n152_), .A2(new_n154_), .B1(new_n155_), .B2(new_n158_), .Y(new_n159_));
  AOI21x1_ASAP7_75t_R  g116(.A1(p1), .A2(o0), .B(new_n84_), .Y(new_n160_));
  NAND3x1_ASAP7_75t_R  g117(.A(new_n130_), .B(new_n128_), .C(new_n160_), .Y(new_n161_));
  OAI21x1_ASAP7_75t_R  g118(.A1(new_n151_), .A2(new_n161_), .B(new_n147_), .Y(new_n162_));
  INVx1_ASAP7_75t_R    g119(.A(p27), .Y(new_n163_));
  OAI21x1_ASAP7_75t_R  g120(.A1(new_n150_), .A2(new_n151_), .B(p17), .Y(new_n164_));
  INVx1_ASAP7_75t_R    g121(.A(p26), .Y(new_n165_));
  AND3x1_ASAP7_75t_R   g122(.A(new_n138_), .B(new_n165_), .C(p0), .Y(new_n166_));
  AOI22x1_ASAP7_75t_R  g123(.A1(new_n162_), .A2(new_n163_), .B1(new_n164_), .B2(new_n166_), .Y(new_n167_));
  OAI21x1_ASAP7_75t_R  g124(.A1(new_n150_), .A2(new_n151_), .B(p25), .Y(new_n168_));
  OR3x1_ASAP7_75t_R    g125(.A(new_n117_), .B(new_n48_), .C(p34), .Y(new_n169_));
  INVx1_ASAP7_75t_R    g126(.A(new_n169_), .Y(new_n170_));
  OAI21x1_ASAP7_75t_R  g127(.A1(new_n150_), .A2(new_n151_), .B(p24), .Y(new_n171_));
  INVx1_ASAP7_75t_R    g128(.A(p33), .Y(new_n172_));
  AND3x1_ASAP7_75t_R   g129(.A(new_n137_), .B(p14), .C(new_n172_), .Y(new_n173_));
  AOI22x1_ASAP7_75t_R  g130(.A1(new_n168_), .A2(new_n170_), .B1(new_n171_), .B2(new_n173_), .Y(new_n174_));
  AND3x1_ASAP7_75t_R   g131(.A(new_n159_), .B(new_n167_), .C(new_n174_), .Y(new_n175_));
  NAND2x1_ASAP7_75t_R  g132(.A(new_n146_), .B(new_n175_), .Y(o2));
  AND3x1_ASAP7_75t_R   g133(.A(new_n132_), .B(new_n140_), .C(new_n74_), .Y(new_n177_));
  NAND2x1_ASAP7_75t_R  g134(.A(p10), .B(new_n177_), .Y(new_n178_));
  INVx1_ASAP7_75t_R    g135(.A(new_n178_), .Y(new_n179_));
  OAI21x1_ASAP7_75t_R  g136(.A1(new_n141_), .A2(new_n146_), .B(new_n179_), .Y(new_n180_));
  AOI21x1_ASAP7_75t_R  g137(.A1(new_n99_), .A2(new_n121_), .B(new_n93_), .Y(new_n181_));
  INVx1_ASAP7_75t_R    g138(.A(new_n158_), .Y(new_n182_));
  INVx1_ASAP7_75t_R    g139(.A(p23), .Y(new_n183_));
  AO31x2_ASAP7_75t_R   g140(.A1(new_n133_), .A2(new_n136_), .A3(new_n139_), .B(new_n183_), .Y(new_n184_));
  OA21x2_ASAP7_75t_R   g141(.A1(new_n67_), .A2(new_n73_), .B(p1), .Y(new_n185_));
  OA21x2_ASAP7_75t_R   g142(.A1(new_n67_), .A2(new_n73_), .B(p11), .Y(new_n186_));
  INVx1_ASAP7_75t_R    g143(.A(new_n91_), .Y(new_n187_));
  OAI22x1_ASAP7_75t_R  g144(.A1(new_n185_), .A2(new_n97_), .B1(new_n186_), .B2(new_n187_), .Y(new_n188_));
  OAI21x1_ASAP7_75t_R  g145(.A1(new_n95_), .A2(new_n188_), .B(p23), .Y(new_n189_));
  NAND3x1_ASAP7_75t_R  g146(.A(new_n184_), .B(new_n189_), .C(new_n154_), .Y(new_n190_));
  OAI21x1_ASAP7_75t_R  g147(.A1(new_n181_), .A2(new_n182_), .B(new_n190_), .Y(new_n191_));
  AND4x2_ASAP7_75t_R   g148(.A(new_n147_), .B(new_n149_), .C(new_n160_), .D(new_n128_), .Y(new_n192_));
  AOI21x1_ASAP7_75t_R  g149(.A1(new_n192_), .A2(new_n121_), .B(new_n98_), .Y(new_n193_));
  INVx1_ASAP7_75t_R    g150(.A(p17), .Y(new_n194_));
  AO31x2_ASAP7_75t_R   g151(.A1(new_n133_), .A2(new_n136_), .A3(new_n139_), .B(new_n194_), .Y(new_n195_));
  OAI21x1_ASAP7_75t_R  g152(.A1(new_n95_), .A2(new_n188_), .B(p17), .Y(new_n196_));
  NAND3x1_ASAP7_75t_R  g153(.A(new_n195_), .B(new_n196_), .C(new_n166_), .Y(new_n197_));
  OAI21x1_ASAP7_75t_R  g154(.A1(p27), .A2(new_n193_), .B(new_n197_), .Y(new_n198_));
  INVx1_ASAP7_75t_R    g155(.A(p25), .Y(new_n199_));
  AOI21x1_ASAP7_75t_R  g156(.A1(new_n99_), .A2(new_n121_), .B(new_n199_), .Y(new_n200_));
  INVx1_ASAP7_75t_R    g157(.A(p24), .Y(new_n201_));
  AO21x1_ASAP7_75t_R   g158(.A1(new_n128_), .A2(new_n130_), .B(new_n201_), .Y(new_n202_));
  AO31x2_ASAP7_75t_R   g159(.A1(new_n133_), .A2(new_n136_), .A3(new_n139_), .B(new_n201_), .Y(new_n203_));
  NAND3x1_ASAP7_75t_R  g160(.A(new_n202_), .B(new_n203_), .C(new_n173_), .Y(new_n204_));
  OAI21x1_ASAP7_75t_R  g161(.A1(new_n200_), .A2(new_n169_), .B(new_n204_), .Y(new_n205_));
  OA31x2_ASAP7_75t_R   g162(.A1(new_n191_), .A2(new_n198_), .A3(new_n205_), .B1(p31), .Y(new_n206_));
  OA31x2_ASAP7_75t_R   g163(.A1(new_n191_), .A2(new_n198_), .A3(new_n205_), .B1(p30), .Y(new_n207_));
  INVx1_ASAP7_75t_R    g164(.A(new_n125_), .Y(new_n208_));
  OA21x2_ASAP7_75t_R   g165(.A1(new_n150_), .A2(new_n151_), .B(p20), .Y(new_n209_));
  NAND3x1_ASAP7_75t_R  g166(.A(new_n132_), .B(new_n140_), .C(new_n142_), .Y(new_n210_));
  OAI21x1_ASAP7_75t_R  g167(.A1(new_n208_), .A2(new_n209_), .B(new_n210_), .Y(new_n211_));
  NAND2x1_ASAP7_75t_R  g168(.A(p8), .B(new_n134_), .Y(new_n212_));
  AO21x1_ASAP7_75t_R   g169(.A1(p21), .A2(o1), .B(new_n212_), .Y(new_n213_));
  AO21x1_ASAP7_75t_R   g170(.A1(p30), .A2(new_n211_), .B(new_n213_), .Y(new_n214_));
  OAI22x1_ASAP7_75t_R  g171(.A1(new_n180_), .A2(new_n206_), .B1(new_n207_), .B2(new_n214_), .Y(new_n215_));
  OA31x2_ASAP7_75t_R   g172(.A1(new_n191_), .A2(new_n198_), .A3(new_n205_), .B1(p33), .Y(new_n216_));
  AND3x1_ASAP7_75t_R   g173(.A(new_n171_), .B(p14), .C(new_n137_), .Y(new_n217_));
  OAI21x1_ASAP7_75t_R  g174(.A1(new_n172_), .A2(new_n146_), .B(new_n217_), .Y(new_n218_));
  AND3x1_ASAP7_75t_R   g175(.A(new_n152_), .B(p12), .C(new_n90_), .Y(new_n219_));
  OAI21x1_ASAP7_75t_R  g176(.A1(new_n153_), .A2(new_n146_), .B(new_n219_), .Y(new_n220_));
  OA31x2_ASAP7_75t_R   g177(.A1(new_n191_), .A2(new_n198_), .A3(new_n205_), .B1(p32), .Y(new_n221_));
  OAI22x1_ASAP7_75t_R  g178(.A1(new_n216_), .A2(new_n218_), .B1(new_n220_), .B2(new_n221_), .Y(new_n222_));
  NOR2x1_ASAP7_75t_R   g179(.A(new_n215_), .B(new_n222_), .Y(new_n223_));
  OA31x2_ASAP7_75t_R   g180(.A1(new_n191_), .A2(new_n198_), .A3(new_n205_), .B1(p26), .Y(new_n224_));
  AND3x1_ASAP7_75t_R   g181(.A(new_n164_), .B(p0), .C(new_n138_), .Y(new_n225_));
  OAI21x1_ASAP7_75t_R  g182(.A1(new_n165_), .A2(new_n146_), .B(new_n225_), .Y(new_n226_));
  OAI21x1_ASAP7_75t_R  g183(.A1(new_n163_), .A2(new_n146_), .B(new_n162_), .Y(new_n227_));
  OA31x2_ASAP7_75t_R   g184(.A1(new_n191_), .A2(new_n198_), .A3(new_n205_), .B1(p27), .Y(new_n228_));
  OAI22x1_ASAP7_75t_R  g185(.A1(new_n224_), .A2(new_n226_), .B1(new_n227_), .B2(new_n228_), .Y(new_n229_));
  OA31x2_ASAP7_75t_R   g186(.A1(new_n191_), .A2(new_n198_), .A3(new_n205_), .B1(p28), .Y(new_n230_));
  INVx1_ASAP7_75t_R    g187(.A(new_n181_), .Y(new_n231_));
  AND2x2_ASAP7_75t_R   g188(.A(new_n157_), .B(new_n231_), .Y(new_n232_));
  OAI21x1_ASAP7_75t_R  g189(.A1(new_n156_), .A2(new_n146_), .B(new_n232_), .Y(new_n233_));
  AND3x1_ASAP7_75t_R   g190(.A(new_n123_), .B(p6), .C(new_n100_), .Y(new_n234_));
  OAI21x1_ASAP7_75t_R  g191(.A1(new_n124_), .A2(new_n146_), .B(new_n234_), .Y(new_n235_));
  OA31x2_ASAP7_75t_R   g192(.A1(new_n191_), .A2(new_n198_), .A3(new_n205_), .B1(p29), .Y(new_n236_));
  OAI22x1_ASAP7_75t_R  g193(.A1(new_n230_), .A2(new_n233_), .B1(new_n235_), .B2(new_n236_), .Y(new_n237_));
  NOR2x1_ASAP7_75t_R   g194(.A(new_n229_), .B(new_n237_), .Y(new_n238_));
  OR3x1_ASAP7_75t_R    g195(.A(new_n200_), .B(new_n48_), .C(new_n117_), .Y(new_n239_));
  AOI21x1_ASAP7_75t_R  g196(.A1(p34), .A2(o2), .B(new_n239_), .Y(new_n240_));
  AOI21x1_ASAP7_75t_R  g197(.A1(new_n223_), .A2(new_n238_), .B(new_n240_), .Y(o3));
  INVx1_ASAP7_75t_R    g198(.A(new_n223_), .Y(o4));
  NAND2x1_ASAP7_75t_R  g199(.A(new_n157_), .B(new_n231_), .Y(new_n243_));
  AO21x1_ASAP7_75t_R   g200(.A1(p21), .A2(o1), .B(new_n144_), .Y(new_n244_));
  NAND2x1_ASAP7_75t_R  g201(.A(new_n136_), .B(new_n139_), .Y(new_n245_));
  NOR3x1_ASAP7_75t_R   g202(.A(new_n245_), .B(new_n150_), .C(new_n115_), .Y(new_n246_));
  OAI21x1_ASAP7_75t_R  g203(.A1(new_n122_), .A2(new_n246_), .B(new_n125_), .Y(new_n247_));
  NAND3x1_ASAP7_75t_R  g204(.A(new_n244_), .B(new_n247_), .C(new_n210_), .Y(new_n248_));
  NOR2x1_ASAP7_75t_R   g205(.A(new_n243_), .B(new_n248_), .Y(new_n249_));
  NOR2x1_ASAP7_75t_R   g206(.A(new_n182_), .B(new_n181_), .Y(new_n250_));
  AOI21x1_ASAP7_75t_R  g207(.A1(new_n175_), .A2(new_n249_), .B(new_n250_), .Y(new_n251_));
  AOI21x1_ASAP7_75t_R  g208(.A1(p30), .A2(new_n211_), .B(new_n213_), .Y(new_n252_));
  INVx1_ASAP7_75t_R    g209(.A(p30), .Y(new_n253_));
  AO31x2_ASAP7_75t_R   g210(.A1(new_n159_), .A2(new_n167_), .A3(new_n174_), .B(new_n253_), .Y(new_n254_));
  AOI211x1_ASAP7_75t_R g211(.A1(new_n252_), .A2(new_n254_), .B(new_n236_), .C(new_n235_), .Y(new_n255_));
  INVx1_ASAP7_75t_R    g212(.A(new_n219_), .Y(new_n256_));
  AOI21x1_ASAP7_75t_R  g213(.A1(p32), .A2(new_n248_), .B(new_n256_), .Y(new_n257_));
  AO31x2_ASAP7_75t_R   g214(.A1(new_n159_), .A2(new_n167_), .A3(new_n174_), .B(new_n153_), .Y(new_n258_));
  AO31x2_ASAP7_75t_R   g215(.A1(new_n159_), .A2(new_n167_), .A3(new_n174_), .B(new_n141_), .Y(new_n259_));
  AOI21x1_ASAP7_75t_R  g216(.A1(new_n247_), .A2(new_n244_), .B(new_n141_), .Y(new_n260_));
  NOR2x1_ASAP7_75t_R   g217(.A(new_n178_), .B(new_n260_), .Y(new_n261_));
  AOI22x1_ASAP7_75t_R  g218(.A1(new_n257_), .A2(new_n258_), .B1(new_n259_), .B2(new_n261_), .Y(new_n262_));
  AOI21x1_ASAP7_75t_R  g219(.A1(new_n255_), .A2(new_n262_), .B(new_n222_), .Y(new_n263_));
  OAI21x1_ASAP7_75t_R  g220(.A1(new_n215_), .A2(new_n251_), .B(new_n263_), .Y(o5));
  NOR2x1_ASAP7_75t_R   g221(.A(new_n221_), .B(new_n220_), .Y(new_n265_));
  NOR2x1_ASAP7_75t_R   g222(.A(new_n228_), .B(new_n227_), .Y(new_n266_));
  NOR2x1_ASAP7_75t_R   g223(.A(new_n206_), .B(new_n180_), .Y(new_n267_));
  AOI21x1_ASAP7_75t_R  g224(.A1(new_n266_), .A2(new_n251_), .B(new_n267_), .Y(new_n268_));
  NOR2x1_ASAP7_75t_R   g225(.A(new_n216_), .B(new_n218_), .Y(new_n269_));
  AOI21x1_ASAP7_75t_R  g226(.A1(new_n255_), .A2(new_n262_), .B(new_n269_), .Y(new_n270_));
  OAI21x1_ASAP7_75t_R  g227(.A1(new_n265_), .A2(new_n268_), .B(new_n270_), .Y(o6));
endmodule


