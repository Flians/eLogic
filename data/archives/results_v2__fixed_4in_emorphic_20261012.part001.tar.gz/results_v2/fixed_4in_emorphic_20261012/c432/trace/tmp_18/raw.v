// Benchmark "/tmp/" written by ABC on Mon Oct 12 15:06:05 2026

module \/tmp/  ( 
    p24, p11, p28, p23, p27, p26, p21, p33, p30, p6, p4, p8, p34, p14, p35,
    p15, p18, p16, p25, p22, p13, p3, p12, p7, p1, p29, p32, p2, p9, p20,
    p19, p5, p10, p17, p31, p0,
    o0, o1, o2, o3, o4, o5, o6  );
  input  p24, p11, p28, p23, p27, p26, p21, p33, p30, p6, p4, p8, p34,
    p14, p35, p15, p18, p16, p25, p22, p13, p3, p12, p7, p1, p29, p32, p2,
    p9, p20, p19, p5, p10, p17, p31, p0;
  output o0, o1, o2, o3, o4, o5, o6;
  wire new_n44_, new_n45_, new_n46_, new_n47_, new_n48_, new_n49_, new_n50_,
    new_n51_, new_n52_, new_n53_, new_n54_, new_n55_, new_n56_, new_n57_,
    new_n58_, new_n59_, new_n60_, new_n61_, new_n63_, new_n64_, new_n65_,
    new_n66_, new_n67_, new_n68_, new_n69_, new_n70_, new_n71_, new_n72_,
    new_n73_, new_n74_, new_n75_, new_n76_, new_n77_, new_n78_, new_n79_,
    new_n80_, new_n81_, new_n82_, new_n83_, new_n84_, new_n85_, new_n86_,
    new_n87_, new_n88_, new_n89_, new_n90_, new_n91_, new_n92_, new_n93_,
    new_n94_, new_n95_, new_n96_, new_n97_, new_n98_, new_n99_, new_n100_,
    new_n101_, new_n102_, new_n103_, new_n104_, new_n105_, new_n106_,
    new_n107_, new_n109_, new_n110_, new_n111_, new_n112_, new_n113_,
    new_n114_, new_n115_, new_n116_, new_n117_, new_n118_, new_n119_,
    new_n120_, new_n121_, new_n122_, new_n123_, new_n124_, new_n125_,
    new_n126_, new_n127_, new_n128_, new_n129_, new_n130_, new_n131_,
    new_n132_, new_n133_, new_n134_, new_n135_, new_n136_, new_n137_,
    new_n138_, new_n139_, new_n140_, new_n141_, new_n142_, new_n143_,
    new_n144_, new_n145_, new_n146_, new_n147_, new_n148_, new_n149_,
    new_n150_, new_n151_, new_n152_, new_n153_, new_n154_, new_n155_,
    new_n156_, new_n157_, new_n158_, new_n159_, new_n160_, new_n161_,
    new_n162_, new_n163_, new_n164_, new_n165_, new_n166_, new_n167_,
    new_n168_, new_n169_, new_n170_, new_n171_, new_n172_, new_n173_,
    new_n174_, new_n175_, new_n176_, new_n177_, new_n178_, new_n179_,
    new_n180_, new_n181_, new_n183_, new_n184_, new_n185_, new_n186_,
    new_n187_, new_n188_, new_n189_, new_n190_, new_n191_, new_n192_,
    new_n193_, new_n194_, new_n195_, new_n196_, new_n197_, new_n198_,
    new_n199_, new_n200_, new_n201_, new_n202_, new_n203_, new_n204_,
    new_n205_, new_n206_, new_n207_, new_n208_, new_n209_, new_n210_,
    new_n211_, new_n212_, new_n213_, new_n214_, new_n215_, new_n216_,
    new_n217_, new_n218_, new_n219_, new_n220_, new_n221_, new_n222_,
    new_n223_, new_n224_, new_n225_, new_n226_, new_n227_, new_n228_,
    new_n229_, new_n230_, new_n233_, new_n234_, new_n235_, new_n236_,
    new_n237_, new_n238_, new_n239_, new_n240_, new_n241_, new_n242_,
    new_n243_, new_n244_, new_n245_, new_n246_, new_n247_, new_n248_,
    new_n249_, new_n250_, new_n251_, new_n252_, new_n253_, new_n254_,
    new_n255_, new_n256_, new_n257_, new_n258_, new_n259_, new_n261_,
    new_n262_, new_n263_;
  INVx1_ASAP7_75t_R    g000(.A(p5), .Y(new_n44_));
  INVx1_ASAP7_75t_R    g001(.A(p7), .Y(new_n45_));
  AOI22x1_ASAP7_75t_R  g002(.A1(p6), .A2(new_n44_), .B1(new_n45_), .B2(p8), .Y(new_n46_));
  INVx1_ASAP7_75t_R    g003(.A(p3), .Y(new_n47_));
  NAND2x1_ASAP7_75t_R  g004(.A(p4), .B(new_n47_), .Y(new_n48_));
  INVx1_ASAP7_75t_R    g005(.A(p9), .Y(new_n49_));
  NAND2x1_ASAP7_75t_R  g006(.A(p10), .B(new_n49_), .Y(new_n50_));
  AND3x1_ASAP7_75t_R   g007(.A(new_n46_), .B(new_n48_), .C(new_n50_), .Y(new_n51_));
  INVx1_ASAP7_75t_R    g008(.A(p14), .Y(new_n52_));
  INVx1_ASAP7_75t_R    g009(.A(p16), .Y(new_n53_));
  OAI22x1_ASAP7_75t_R  g010(.A1(new_n52_), .A2(p13), .B1(new_n53_), .B2(p15), .Y(new_n54_));
  INVx1_ASAP7_75t_R    g011(.A(p0), .Y(new_n55_));
  INVx1_ASAP7_75t_R    g012(.A(p2), .Y(new_n56_));
  OAI22x1_ASAP7_75t_R  g013(.A1(p35), .A2(new_n55_), .B1(new_n56_), .B2(p1), .Y(new_n57_));
  INVx1_ASAP7_75t_R    g014(.A(p12), .Y(new_n58_));
  INVx1_ASAP7_75t_R    g015(.A(p4), .Y(new_n59_));
  OAI22x1_ASAP7_75t_R  g016(.A1(p11), .A2(new_n58_), .B1(new_n59_), .B2(p3), .Y(new_n60_));
  NOR3x1_ASAP7_75t_R   g017(.A(new_n54_), .B(new_n57_), .C(new_n60_), .Y(new_n61_));
  NAND2x1_ASAP7_75t_R  g018(.A(new_n51_), .B(new_n61_), .Y(o0));
  INVx1_ASAP7_75t_R    g019(.A(p35), .Y(new_n63_));
  AOI21x1_ASAP7_75t_R  g020(.A1(new_n51_), .A2(new_n61_), .B(new_n63_), .Y(new_n64_));
  NOR2x1_ASAP7_75t_R   g021(.A(p17), .B(new_n55_), .Y(new_n65_));
  INVx1_ASAP7_75t_R    g022(.A(new_n65_), .Y(new_n66_));
  INVx1_ASAP7_75t_R    g023(.A(p13), .Y(new_n67_));
  INVx1_ASAP7_75t_R    g024(.A(p15), .Y(new_n68_));
  AOI22x1_ASAP7_75t_R  g025(.A1(p14), .A2(new_n67_), .B1(new_n68_), .B2(p16), .Y(new_n69_));
  INVx1_ASAP7_75t_R    g026(.A(p1), .Y(new_n70_));
  AOI22x1_ASAP7_75t_R  g027(.A1(new_n63_), .A2(p0), .B1(new_n70_), .B2(p2), .Y(new_n71_));
  INVx1_ASAP7_75t_R    g028(.A(p11), .Y(new_n72_));
  AOI22x1_ASAP7_75t_R  g029(.A1(new_n72_), .A2(p12), .B1(new_n47_), .B2(p4), .Y(new_n73_));
  AO31x2_ASAP7_75t_R   g030(.A1(new_n69_), .A2(new_n71_), .A3(new_n73_), .B(new_n67_), .Y(new_n74_));
  AO21x1_ASAP7_75t_R   g031(.A1(new_n50_), .A2(new_n46_), .B(new_n67_), .Y(new_n75_));
  NOR2x1_ASAP7_75t_R   g032(.A(p24), .B(new_n52_), .Y(new_n76_));
  NAND3x1_ASAP7_75t_R  g033(.A(new_n74_), .B(new_n75_), .C(new_n76_), .Y(new_n77_));
  OAI21x1_ASAP7_75t_R  g034(.A1(new_n64_), .A2(new_n66_), .B(new_n77_), .Y(new_n78_));
  AOI21x1_ASAP7_75t_R  g035(.A1(new_n51_), .A2(new_n61_), .B(new_n68_), .Y(new_n79_));
  NOR2x1_ASAP7_75t_R   g036(.A(p25), .B(new_n53_), .Y(new_n80_));
  INVx1_ASAP7_75t_R    g037(.A(new_n80_), .Y(new_n81_));
  AOI21x1_ASAP7_75t_R  g038(.A1(new_n51_), .A2(new_n61_), .B(new_n45_), .Y(new_n82_));
  INVx1_ASAP7_75t_R    g039(.A(p8), .Y(new_n83_));
  NOR2x1_ASAP7_75t_R   g040(.A(p21), .B(new_n83_), .Y(new_n84_));
  INVx1_ASAP7_75t_R    g041(.A(new_n84_), .Y(new_n85_));
  OAI22x1_ASAP7_75t_R  g042(.A1(new_n79_), .A2(new_n81_), .B1(new_n82_), .B2(new_n85_), .Y(new_n86_));
  NOR2x1_ASAP7_75t_R   g043(.A(new_n78_), .B(new_n86_), .Y(new_n87_));
  AO21x1_ASAP7_75t_R   g044(.A1(new_n51_), .A2(new_n61_), .B(new_n72_), .Y(new_n88_));
  INVx1_ASAP7_75t_R    g045(.A(p23), .Y(new_n89_));
  NAND2x1_ASAP7_75t_R  g046(.A(p12), .B(new_n89_), .Y(new_n90_));
  INVx1_ASAP7_75t_R    g047(.A(new_n90_), .Y(new_n91_));
  INVx1_ASAP7_75t_R    g048(.A(p19), .Y(new_n92_));
  NAND2x1_ASAP7_75t_R  g049(.A(p4), .B(new_n92_), .Y(new_n93_));
  AOI21x1_ASAP7_75t_R  g050(.A1(new_n48_), .A2(o0), .B(new_n93_), .Y(new_n94_));
  INVx1_ASAP7_75t_R    g051(.A(p18), .Y(new_n95_));
  NAND2x1_ASAP7_75t_R  g052(.A(p2), .B(new_n95_), .Y(new_n96_));
  AOI21x1_ASAP7_75t_R  g053(.A1(p1), .A2(o0), .B(new_n96_), .Y(new_n97_));
  AOI211x1_ASAP7_75t_R g054(.A1(new_n88_), .A2(new_n91_), .B(new_n94_), .C(new_n97_), .Y(new_n98_));
  NAND3x1_ASAP7_75t_R  g055(.A(new_n46_), .B(new_n48_), .C(new_n50_), .Y(new_n99_));
  NAND3x1_ASAP7_75t_R  g056(.A(new_n69_), .B(new_n71_), .C(new_n73_), .Y(new_n100_));
  OAI21x1_ASAP7_75t_R  g057(.A1(new_n99_), .A2(new_n100_), .B(p5), .Y(new_n101_));
  INVx1_ASAP7_75t_R    g058(.A(p6), .Y(new_n102_));
  NOR2x1_ASAP7_75t_R   g059(.A(p20), .B(new_n102_), .Y(new_n103_));
  OAI21x1_ASAP7_75t_R  g060(.A1(new_n99_), .A2(new_n100_), .B(p9), .Y(new_n104_));
  INVx1_ASAP7_75t_R    g061(.A(p10), .Y(new_n105_));
  NOR2x1_ASAP7_75t_R   g062(.A(p22), .B(new_n105_), .Y(new_n106_));
  AOI22x1_ASAP7_75t_R  g063(.A1(new_n101_), .A2(new_n103_), .B1(new_n104_), .B2(new_n106_), .Y(new_n107_));
  NAND3x1_ASAP7_75t_R  g064(.A(new_n87_), .B(new_n98_), .C(new_n107_), .Y(o1));
  NOR2x1_ASAP7_75t_R   g065(.A(p19), .B(new_n59_), .Y(new_n109_));
  NOR2x1_ASAP7_75t_R   g066(.A(new_n99_), .B(new_n100_), .Y(new_n110_));
  AND3x1_ASAP7_75t_R   g067(.A(new_n47_), .B(new_n92_), .C(p4), .Y(new_n111_));
  AOI21x1_ASAP7_75t_R  g068(.A1(new_n109_), .A2(new_n110_), .B(new_n111_), .Y(new_n112_));
  AO21x1_ASAP7_75t_R   g069(.A1(new_n51_), .A2(new_n61_), .B(new_n70_), .Y(new_n113_));
  INVx1_ASAP7_75t_R    g070(.A(new_n96_), .Y(new_n114_));
  AOI22x1_ASAP7_75t_R  g071(.A1(new_n113_), .A2(new_n114_), .B1(new_n88_), .B2(new_n91_), .Y(new_n115_));
  NAND2x1_ASAP7_75t_R  g072(.A(new_n112_), .B(new_n115_), .Y(new_n116_));
  OAI21x1_ASAP7_75t_R  g073(.A1(new_n99_), .A2(new_n100_), .B(p15), .Y(new_n117_));
  OAI21x1_ASAP7_75t_R  g074(.A1(new_n99_), .A2(new_n100_), .B(p7), .Y(new_n118_));
  AOI22x1_ASAP7_75t_R  g075(.A1(new_n117_), .A2(new_n80_), .B1(new_n118_), .B2(new_n84_), .Y(new_n119_));
  OAI21x1_ASAP7_75t_R  g076(.A1(new_n99_), .A2(new_n100_), .B(p35), .Y(new_n120_));
  AOI21x1_ASAP7_75t_R  g077(.A1(new_n50_), .A2(new_n46_), .B(new_n67_), .Y(new_n121_));
  AOI21x1_ASAP7_75t_R  g078(.A1(p13), .A2(new_n100_), .B(new_n121_), .Y(new_n122_));
  AOI22x1_ASAP7_75t_R  g079(.A1(new_n120_), .A2(new_n65_), .B1(new_n122_), .B2(new_n76_), .Y(new_n123_));
  NAND3x1_ASAP7_75t_R  g080(.A(new_n107_), .B(new_n119_), .C(new_n123_), .Y(new_n124_));
  OAI21x1_ASAP7_75t_R  g081(.A1(new_n116_), .A2(new_n124_), .B(p21), .Y(new_n125_));
  INVx1_ASAP7_75t_R    g082(.A(p30), .Y(new_n126_));
  AND3x1_ASAP7_75t_R   g083(.A(new_n118_), .B(new_n126_), .C(p8), .Y(new_n127_));
  INVx1_ASAP7_75t_R    g084(.A(p22), .Y(new_n128_));
  AO21x1_ASAP7_75t_R   g085(.A1(new_n112_), .A2(new_n115_), .B(new_n128_), .Y(new_n129_));
  AO31x2_ASAP7_75t_R   g086(.A1(new_n107_), .A2(new_n119_), .A3(new_n123_), .B(new_n128_), .Y(new_n130_));
  INVx1_ASAP7_75t_R    g087(.A(p31), .Y(new_n131_));
  AND3x1_ASAP7_75t_R   g088(.A(new_n104_), .B(p10), .C(new_n131_), .Y(new_n132_));
  AND3x1_ASAP7_75t_R   g089(.A(new_n129_), .B(new_n130_), .C(new_n132_), .Y(new_n133_));
  INVx1_ASAP7_75t_R    g090(.A(p29), .Y(new_n134_));
  AND3x1_ASAP7_75t_R   g091(.A(new_n101_), .B(p6), .C(new_n134_), .Y(new_n135_));
  INVx1_ASAP7_75t_R    g092(.A(new_n135_), .Y(new_n136_));
  AOI21x1_ASAP7_75t_R  g093(.A1(p20), .A2(o1), .B(new_n136_), .Y(new_n137_));
  AOI211x1_ASAP7_75t_R g094(.A1(new_n125_), .A2(new_n127_), .B(new_n133_), .C(new_n137_), .Y(new_n138_));
  OA21x2_ASAP7_75t_R   g095(.A1(new_n99_), .A2(new_n100_), .B(p1), .Y(new_n139_));
  AOI21x1_ASAP7_75t_R  g096(.A1(new_n51_), .A2(new_n61_), .B(new_n72_), .Y(new_n140_));
  OAI22x1_ASAP7_75t_R  g097(.A1(new_n139_), .A2(new_n96_), .B1(new_n140_), .B2(new_n90_), .Y(new_n141_));
  NOR2x1_ASAP7_75t_R   g098(.A(new_n78_), .B(new_n141_), .Y(new_n142_));
  AOI21x1_ASAP7_75t_R  g099(.A1(new_n51_), .A2(new_n61_), .B(new_n44_), .Y(new_n143_));
  INVx1_ASAP7_75t_R    g100(.A(new_n103_), .Y(new_n144_));
  AOI21x1_ASAP7_75t_R  g101(.A1(new_n51_), .A2(new_n61_), .B(new_n49_), .Y(new_n145_));
  INVx1_ASAP7_75t_R    g102(.A(new_n106_), .Y(new_n146_));
  OAI22x1_ASAP7_75t_R  g103(.A1(new_n143_), .A2(new_n144_), .B1(new_n145_), .B2(new_n146_), .Y(new_n147_));
  NOR3x1_ASAP7_75t_R   g104(.A(new_n147_), .B(new_n86_), .C(new_n94_), .Y(new_n148_));
  AOI21x1_ASAP7_75t_R  g105(.A1(new_n142_), .A2(new_n148_), .B(new_n92_), .Y(new_n149_));
  INVx1_ASAP7_75t_R    g106(.A(p28), .Y(new_n150_));
  OA21x2_ASAP7_75t_R   g107(.A1(new_n47_), .A2(new_n110_), .B(p4), .Y(new_n151_));
  AND2x2_ASAP7_75t_R   g108(.A(new_n150_), .B(new_n151_), .Y(new_n152_));
  INVx1_ASAP7_75t_R    g109(.A(new_n152_), .Y(new_n153_));
  AO21x1_ASAP7_75t_R   g110(.A1(new_n112_), .A2(new_n115_), .B(new_n89_), .Y(new_n154_));
  AO31x2_ASAP7_75t_R   g111(.A1(new_n107_), .A2(new_n119_), .A3(new_n123_), .B(new_n89_), .Y(new_n155_));
  INVx1_ASAP7_75t_R    g112(.A(p32), .Y(new_n156_));
  AND3x1_ASAP7_75t_R   g113(.A(new_n88_), .B(p12), .C(new_n156_), .Y(new_n157_));
  NAND3x1_ASAP7_75t_R  g114(.A(new_n154_), .B(new_n155_), .C(new_n157_), .Y(new_n158_));
  OAI21x1_ASAP7_75t_R  g115(.A1(new_n149_), .A2(new_n153_), .B(new_n158_), .Y(new_n159_));
  AO21x1_ASAP7_75t_R   g116(.A1(p1), .A2(o0), .B(new_n56_), .Y(new_n160_));
  NOR3x1_ASAP7_75t_R   g117(.A(new_n141_), .B(new_n94_), .C(new_n160_), .Y(new_n161_));
  AND3x1_ASAP7_75t_R   g118(.A(new_n107_), .B(new_n119_), .C(new_n123_), .Y(new_n162_));
  AOI21x1_ASAP7_75t_R  g119(.A1(new_n161_), .A2(new_n162_), .B(new_n97_), .Y(new_n163_));
  INVx1_ASAP7_75t_R    g120(.A(p17), .Y(new_n164_));
  AO31x2_ASAP7_75t_R   g121(.A1(new_n107_), .A2(new_n119_), .A3(new_n123_), .B(new_n164_), .Y(new_n165_));
  OAI21x1_ASAP7_75t_R  g122(.A1(new_n94_), .A2(new_n141_), .B(p17), .Y(new_n166_));
  INVx1_ASAP7_75t_R    g123(.A(p26), .Y(new_n167_));
  AND3x1_ASAP7_75t_R   g124(.A(new_n120_), .B(new_n167_), .C(p0), .Y(new_n168_));
  NAND3x1_ASAP7_75t_R  g125(.A(new_n165_), .B(new_n166_), .C(new_n168_), .Y(new_n169_));
  OAI21x1_ASAP7_75t_R  g126(.A1(p27), .A2(new_n163_), .B(new_n169_), .Y(new_n170_));
  INVx1_ASAP7_75t_R    g127(.A(p25), .Y(new_n171_));
  AOI21x1_ASAP7_75t_R  g128(.A1(new_n142_), .A2(new_n148_), .B(new_n171_), .Y(new_n172_));
  OR3x1_ASAP7_75t_R    g129(.A(new_n79_), .B(p34), .C(new_n53_), .Y(new_n173_));
  INVx1_ASAP7_75t_R    g130(.A(p24), .Y(new_n174_));
  AO31x2_ASAP7_75t_R   g131(.A1(new_n107_), .A2(new_n119_), .A3(new_n123_), .B(new_n174_), .Y(new_n175_));
  OAI21x1_ASAP7_75t_R  g132(.A1(new_n94_), .A2(new_n141_), .B(p24), .Y(new_n176_));
  NAND2x1_ASAP7_75t_R  g133(.A(p14), .B(new_n122_), .Y(new_n177_));
  NOR2x1_ASAP7_75t_R   g134(.A(p33), .B(new_n177_), .Y(new_n178_));
  NAND3x1_ASAP7_75t_R  g135(.A(new_n175_), .B(new_n176_), .C(new_n178_), .Y(new_n179_));
  OAI21x1_ASAP7_75t_R  g136(.A1(new_n172_), .A2(new_n173_), .B(new_n179_), .Y(new_n180_));
  NOR3x1_ASAP7_75t_R   g137(.A(new_n159_), .B(new_n170_), .C(new_n180_), .Y(new_n181_));
  NAND2x1_ASAP7_75t_R  g138(.A(new_n138_), .B(new_n181_), .Y(o2));
  OAI21x1_ASAP7_75t_R  g139(.A1(new_n116_), .A2(new_n124_), .B(p20), .Y(new_n183_));
  OAI21x1_ASAP7_75t_R  g140(.A1(new_n116_), .A2(new_n124_), .B(p22), .Y(new_n184_));
  AOI22x1_ASAP7_75t_R  g141(.A1(new_n183_), .A2(new_n135_), .B1(new_n184_), .B2(new_n132_), .Y(new_n185_));
  NAND2x1_ASAP7_75t_R  g142(.A(new_n127_), .B(new_n125_), .Y(new_n186_));
  AOI21x1_ASAP7_75t_R  g143(.A1(p24), .A2(o1), .B(new_n177_), .Y(new_n187_));
  AND3x1_ASAP7_75t_R   g144(.A(new_n185_), .B(new_n186_), .C(new_n187_), .Y(new_n188_));
  INVx1_ASAP7_75t_R    g145(.A(new_n179_), .Y(new_n189_));
  AOI21x1_ASAP7_75t_R  g146(.A1(new_n181_), .A2(new_n188_), .B(new_n189_), .Y(new_n190_));
  INVx1_ASAP7_75t_R    g147(.A(p20), .Y(new_n191_));
  AOI21x1_ASAP7_75t_R  g148(.A1(new_n142_), .A2(new_n148_), .B(new_n191_), .Y(new_n192_));
  NAND3x1_ASAP7_75t_R  g149(.A(new_n129_), .B(new_n130_), .C(new_n132_), .Y(new_n193_));
  OAI21x1_ASAP7_75t_R  g150(.A1(new_n192_), .A2(new_n136_), .B(new_n193_), .Y(new_n194_));
  AND2x2_ASAP7_75t_R   g151(.A(new_n127_), .B(new_n125_), .Y(new_n195_));
  OAI21x1_ASAP7_75t_R  g152(.A1(new_n116_), .A2(new_n124_), .B(p23), .Y(new_n196_));
  NAND3x1_ASAP7_75t_R  g153(.A(new_n196_), .B(p12), .C(new_n88_), .Y(new_n197_));
  NOR3x1_ASAP7_75t_R   g154(.A(new_n194_), .B(new_n195_), .C(new_n197_), .Y(new_n198_));
  INVx1_ASAP7_75t_R    g155(.A(new_n158_), .Y(new_n199_));
  AOI21x1_ASAP7_75t_R  g156(.A1(new_n198_), .A2(new_n181_), .B(new_n199_), .Y(new_n200_));
  NOR2x1_ASAP7_75t_R   g157(.A(new_n105_), .B(new_n145_), .Y(new_n201_));
  AND3x1_ASAP7_75t_R   g158(.A(new_n129_), .B(new_n130_), .C(new_n201_), .Y(new_n202_));
  AND3x1_ASAP7_75t_R   g159(.A(new_n185_), .B(new_n186_), .C(new_n202_), .Y(new_n203_));
  AOI21x1_ASAP7_75t_R  g160(.A1(new_n181_), .A2(new_n203_), .B(new_n133_), .Y(new_n204_));
  NAND3x1_ASAP7_75t_R  g161(.A(new_n125_), .B(p8), .C(new_n118_), .Y(new_n205_));
  NOR3x1_ASAP7_75t_R   g162(.A(new_n194_), .B(new_n126_), .C(new_n205_), .Y(new_n206_));
  AOI21x1_ASAP7_75t_R  g163(.A1(new_n206_), .A2(new_n181_), .B(new_n195_), .Y(new_n207_));
  AND4x2_ASAP7_75t_R   g164(.A(new_n190_), .B(new_n200_), .C(new_n204_), .D(new_n207_), .Y(new_n208_));
  OAI21x1_ASAP7_75t_R  g165(.A1(new_n116_), .A2(new_n124_), .B(p17), .Y(new_n209_));
  AND3x1_ASAP7_75t_R   g166(.A(new_n209_), .B(p0), .C(new_n120_), .Y(new_n210_));
  AND3x1_ASAP7_75t_R   g167(.A(new_n210_), .B(new_n185_), .C(new_n186_), .Y(new_n211_));
  AOI22x1_ASAP7_75t_R  g168(.A1(new_n211_), .A2(new_n181_), .B1(new_n167_), .B2(new_n210_), .Y(new_n212_));
  OAI21x1_ASAP7_75t_R  g169(.A1(new_n116_), .A2(new_n124_), .B(p19), .Y(new_n213_));
  AND2x2_ASAP7_75t_R   g170(.A(new_n151_), .B(new_n213_), .Y(new_n214_));
  AND3x1_ASAP7_75t_R   g171(.A(new_n214_), .B(new_n185_), .C(new_n186_), .Y(new_n215_));
  NOR2x1_ASAP7_75t_R   g172(.A(new_n153_), .B(new_n149_), .Y(new_n216_));
  AOI21x1_ASAP7_75t_R  g173(.A1(new_n181_), .A2(new_n215_), .B(new_n216_), .Y(new_n217_));
  NOR2x1_ASAP7_75t_R   g174(.A(new_n56_), .B(new_n139_), .Y(new_n218_));
  NAND3x1_ASAP7_75t_R  g175(.A(new_n115_), .B(new_n112_), .C(new_n218_), .Y(new_n219_));
  OAI22x1_ASAP7_75t_R  g176(.A1(new_n219_), .A2(new_n124_), .B1(p18), .B2(new_n160_), .Y(new_n220_));
  AND3x1_ASAP7_75t_R   g177(.A(new_n185_), .B(new_n186_), .C(new_n220_), .Y(new_n221_));
  NOR2x1_ASAP7_75t_R   g178(.A(p27), .B(new_n163_), .Y(new_n222_));
  AOI21x1_ASAP7_75t_R  g179(.A1(new_n181_), .A2(new_n221_), .B(new_n222_), .Y(new_n223_));
  NAND2x1_ASAP7_75t_R  g180(.A(p6), .B(new_n101_), .Y(new_n224_));
  NOR2x1_ASAP7_75t_R   g181(.A(new_n224_), .B(new_n192_), .Y(new_n225_));
  AND4x2_ASAP7_75t_R   g182(.A(new_n225_), .B(new_n186_), .C(p29), .D(new_n193_), .Y(new_n226_));
  AOI21x1_ASAP7_75t_R  g183(.A1(new_n226_), .A2(new_n181_), .B(new_n137_), .Y(new_n227_));
  AND4x2_ASAP7_75t_R   g184(.A(new_n212_), .B(new_n217_), .C(new_n223_), .D(new_n227_), .Y(new_n228_));
  OR3x1_ASAP7_75t_R    g185(.A(new_n172_), .B(new_n53_), .C(new_n79_), .Y(new_n229_));
  AOI21x1_ASAP7_75t_R  g186(.A1(p34), .A2(o2), .B(new_n229_), .Y(new_n230_));
  AOI21x1_ASAP7_75t_R  g187(.A1(new_n208_), .A2(new_n228_), .B(new_n230_), .Y(o3));
  INVx1_ASAP7_75t_R    g188(.A(new_n208_), .Y(o4));
  AOI21x1_ASAP7_75t_R  g189(.A1(p30), .A2(new_n194_), .B(new_n205_), .Y(new_n233_));
  INVx1_ASAP7_75t_R    g190(.A(p27), .Y(new_n234_));
  AOI22x1_ASAP7_75t_R  g191(.A1(new_n220_), .A2(new_n234_), .B1(new_n209_), .B2(new_n168_), .Y(new_n235_));
  AOI22x1_ASAP7_75t_R  g192(.A1(new_n196_), .A2(new_n157_), .B1(new_n213_), .B2(new_n152_), .Y(new_n236_));
  OAI21x1_ASAP7_75t_R  g193(.A1(new_n116_), .A2(new_n124_), .B(p25), .Y(new_n237_));
  INVx1_ASAP7_75t_R    g194(.A(new_n173_), .Y(new_n238_));
  OAI21x1_ASAP7_75t_R  g195(.A1(new_n116_), .A2(new_n124_), .B(p24), .Y(new_n239_));
  AOI22x1_ASAP7_75t_R  g196(.A1(new_n237_), .A2(new_n238_), .B1(new_n239_), .B2(new_n178_), .Y(new_n240_));
  AO31x2_ASAP7_75t_R   g197(.A1(new_n235_), .A2(new_n236_), .A3(new_n240_), .B(new_n126_), .Y(new_n241_));
  OA31x2_ASAP7_75t_R   g198(.A1(new_n180_), .A2(new_n170_), .A3(new_n159_), .B1(p29), .Y(new_n242_));
  OAI21x1_ASAP7_75t_R  g199(.A1(new_n134_), .A2(new_n138_), .B(new_n225_), .Y(new_n243_));
  AOI211x1_ASAP7_75t_R g200(.A1(new_n233_), .A2(new_n241_), .B(new_n242_), .C(new_n243_), .Y(new_n244_));
  NAND2x1_ASAP7_75t_R  g201(.A(new_n135_), .B(new_n183_), .Y(new_n245_));
  NAND3x1_ASAP7_75t_R  g202(.A(new_n186_), .B(new_n245_), .C(new_n193_), .Y(new_n246_));
  AOI21x1_ASAP7_75t_R  g203(.A1(p32), .A2(new_n246_), .B(new_n197_), .Y(new_n247_));
  AO31x2_ASAP7_75t_R   g204(.A1(new_n235_), .A2(new_n236_), .A3(new_n240_), .B(new_n156_), .Y(new_n248_));
  AO31x2_ASAP7_75t_R   g205(.A1(new_n235_), .A2(new_n236_), .A3(new_n240_), .B(new_n131_), .Y(new_n249_));
  INVx1_ASAP7_75t_R    g206(.A(new_n202_), .Y(new_n250_));
  AOI21x1_ASAP7_75t_R  g207(.A1(new_n245_), .A2(new_n186_), .B(new_n131_), .Y(new_n251_));
  NOR2x1_ASAP7_75t_R   g208(.A(new_n250_), .B(new_n251_), .Y(new_n252_));
  AOI22x1_ASAP7_75t_R  g209(.A1(new_n247_), .A2(new_n248_), .B1(new_n249_), .B2(new_n252_), .Y(new_n253_));
  NAND2x1_ASAP7_75t_R  g210(.A(new_n244_), .B(new_n253_), .Y(new_n254_));
  AO21x1_ASAP7_75t_R   g211(.A1(new_n198_), .A2(new_n181_), .B(new_n199_), .Y(new_n255_));
  AO21x1_ASAP7_75t_R   g212(.A1(new_n181_), .A2(new_n188_), .B(new_n189_), .Y(new_n256_));
  NOR2x1_ASAP7_75t_R   g213(.A(new_n255_), .B(new_n256_), .Y(new_n257_));
  AO21x1_ASAP7_75t_R   g214(.A1(new_n181_), .A2(new_n215_), .B(new_n216_), .Y(new_n258_));
  NAND3x1_ASAP7_75t_R  g215(.A(new_n258_), .B(new_n204_), .C(new_n207_), .Y(new_n259_));
  NAND3x1_ASAP7_75t_R  g216(.A(new_n254_), .B(new_n257_), .C(new_n259_), .Y(o5));
  AO21x1_ASAP7_75t_R   g217(.A1(new_n181_), .A2(new_n221_), .B(new_n222_), .Y(new_n261_));
  AOI22x1_ASAP7_75t_R  g218(.A1(new_n261_), .A2(new_n217_), .B1(new_n249_), .B2(new_n252_), .Y(new_n262_));
  AOI21x1_ASAP7_75t_R  g219(.A1(new_n244_), .A2(new_n253_), .B(new_n256_), .Y(new_n263_));
  OAI21x1_ASAP7_75t_R  g220(.A1(new_n255_), .A2(new_n262_), .B(new_n263_), .Y(o6));
endmodule


