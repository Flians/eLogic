// Benchmark "/tmp/" written by ABC on Mon Oct 12 15:06:04 2026

module \/tmp/  ( 
    p9, p14, p11, p15, p1, p0, p22, p19, p25, p3, p28, p10, p2, p32, p18,
    p16, p8, p33, p17, p21, p20, p5, p6, p23, p30, p13, p4, p29, p27, p31,
    p35, p26, p34, p7, p24, p12,
    o0, o1, o2, o3, o4, o5, o6  );
  input  p9, p14, p11, p15, p1, p0, p22, p19, p25, p3, p28, p10, p2, p32,
    p18, p16, p8, p33, p17, p21, p20, p5, p6, p23, p30, p13, p4, p29, p27,
    p31, p35, p26, p34, p7, p24, p12;
  output o0, o1, o2, o3, o4, o5, o6;
  wire new_n44_, new_n45_, new_n46_, new_n47_, new_n48_, new_n49_, new_n50_,
    new_n51_, new_n52_, new_n53_, new_n54_, new_n55_, new_n56_, new_n57_,
    new_n58_, new_n59_, new_n60_, new_n62_, new_n63_, new_n64_, new_n65_,
    new_n66_, new_n67_, new_n68_, new_n69_, new_n70_, new_n71_, new_n72_,
    new_n73_, new_n74_, new_n75_, new_n76_, new_n77_, new_n78_, new_n79_,
    new_n80_, new_n81_, new_n82_, new_n83_, new_n84_, new_n85_, new_n86_,
    new_n87_, new_n88_, new_n89_, new_n90_, new_n91_, new_n92_, new_n93_,
    new_n94_, new_n95_, new_n96_, new_n97_, new_n98_, new_n99_, new_n100_,
    new_n101_, new_n102_, new_n103_, new_n104_, new_n105_, new_n106_,
    new_n107_, new_n108_, new_n110_, new_n111_, new_n112_, new_n113_,
    new_n114_, new_n115_, new_n116_, new_n117_, new_n118_, new_n119_,
    new_n120_, new_n121_, new_n122_, new_n123_, new_n124_, new_n125_,
    new_n126_, new_n127_, new_n128_, new_n129_, new_n130_, new_n131_,
    new_n132_, new_n133_, new_n134_, new_n135_, new_n136_, new_n137_,
    new_n138_, new_n139_, new_n140_, new_n141_, new_n142_, new_n143_,
    new_n144_, new_n145_, new_n146_, new_n147_, new_n148_, new_n149_,
    new_n150_, new_n151_, new_n152_, new_n153_, new_n154_, new_n155_,
    new_n156_, new_n157_, new_n158_, new_n159_, new_n160_, new_n161_,
    new_n162_, new_n163_, new_n164_, new_n165_, new_n166_, new_n167_,
    new_n168_, new_n169_, new_n170_, new_n171_, new_n172_, new_n173_,
    new_n174_, new_n175_, new_n176_, new_n178_, new_n179_, new_n180_,
    new_n181_, new_n182_, new_n183_, new_n184_, new_n185_, new_n186_,
    new_n187_, new_n188_, new_n189_, new_n190_, new_n191_, new_n192_,
    new_n193_, new_n194_, new_n195_, new_n196_, new_n197_, new_n198_,
    new_n199_, new_n200_, new_n201_, new_n202_, new_n203_, new_n204_,
    new_n205_, new_n206_, new_n207_, new_n208_, new_n209_, new_n210_,
    new_n211_, new_n212_, new_n213_, new_n214_, new_n215_, new_n216_,
    new_n217_, new_n218_, new_n219_, new_n220_, new_n221_, new_n222_,
    new_n223_, new_n224_, new_n227_, new_n228_, new_n229_, new_n230_,
    new_n231_, new_n232_, new_n233_, new_n234_, new_n235_, new_n236_,
    new_n237_, new_n238_, new_n239_, new_n240_, new_n241_, new_n242_,
    new_n243_, new_n244_, new_n245_, new_n246_, new_n248_, new_n249_,
    new_n250_, new_n251_, new_n252_;
  INVx1_ASAP7_75t_R    g000(.A(p15), .Y(new_n44_));
  INVx1_ASAP7_75t_R    g001(.A(p35), .Y(new_n45_));
  AOI22x1_ASAP7_75t_R  g002(.A1(new_n44_), .A2(p16), .B1(new_n45_), .B2(p0), .Y(new_n46_));
  INVx1_ASAP7_75t_R    g003(.A(p9), .Y(new_n47_));
  NAND2x1_ASAP7_75t_R  g004(.A(p10), .B(new_n47_), .Y(new_n48_));
  INVx1_ASAP7_75t_R    g005(.A(p7), .Y(new_n49_));
  NAND2x1_ASAP7_75t_R  g006(.A(p8), .B(new_n49_), .Y(new_n50_));
  AND3x1_ASAP7_75t_R   g007(.A(new_n46_), .B(new_n48_), .C(new_n50_), .Y(new_n51_));
  INVx1_ASAP7_75t_R    g008(.A(p13), .Y(new_n52_));
  INVx1_ASAP7_75t_R    g009(.A(p11), .Y(new_n53_));
  AOI22x1_ASAP7_75t_R  g010(.A1(p14), .A2(new_n52_), .B1(new_n53_), .B2(p12), .Y(new_n54_));
  INVx1_ASAP7_75t_R    g011(.A(p1), .Y(new_n55_));
  INVx1_ASAP7_75t_R    g012(.A(p5), .Y(new_n56_));
  AOI22x1_ASAP7_75t_R  g013(.A1(new_n55_), .A2(p2), .B1(new_n56_), .B2(p6), .Y(new_n57_));
  INVx1_ASAP7_75t_R    g014(.A(p3), .Y(new_n58_));
  NAND2x1_ASAP7_75t_R  g015(.A(p4), .B(new_n58_), .Y(new_n59_));
  AND3x1_ASAP7_75t_R   g016(.A(new_n54_), .B(new_n57_), .C(new_n59_), .Y(new_n60_));
  NAND2x1_ASAP7_75t_R  g017(.A(new_n51_), .B(new_n60_), .Y(o0));
  AOI21x1_ASAP7_75t_R  g018(.A1(new_n51_), .A2(new_n60_), .B(new_n45_), .Y(new_n62_));
  INVx1_ASAP7_75t_R    g019(.A(p0), .Y(new_n63_));
  NOR2x1_ASAP7_75t_R   g020(.A(p17), .B(new_n63_), .Y(new_n64_));
  INVx1_ASAP7_75t_R    g021(.A(new_n64_), .Y(new_n65_));
  AOI22x1_ASAP7_75t_R  g022(.A1(new_n55_), .A2(p2), .B1(new_n45_), .B2(p0), .Y(new_n66_));
  AOI22x1_ASAP7_75t_R  g023(.A1(p14), .A2(new_n52_), .B1(new_n44_), .B2(p16), .Y(new_n67_));
  AOI22x1_ASAP7_75t_R  g024(.A1(new_n53_), .A2(p12), .B1(new_n58_), .B2(p4), .Y(new_n68_));
  AO31x2_ASAP7_75t_R   g025(.A1(new_n66_), .A2(new_n67_), .A3(new_n68_), .B(new_n52_), .Y(new_n69_));
  AO22x1_ASAP7_75t_R   g026(.A1(p8), .A2(new_n49_), .B1(new_n56_), .B2(p6), .Y(new_n70_));
  INVx1_ASAP7_75t_R    g027(.A(new_n48_), .Y(new_n71_));
  OAI21x1_ASAP7_75t_R  g028(.A1(new_n70_), .A2(new_n71_), .B(p13), .Y(new_n72_));
  INVx1_ASAP7_75t_R    g029(.A(p24), .Y(new_n73_));
  AND2x2_ASAP7_75t_R   g030(.A(p14), .B(new_n73_), .Y(new_n74_));
  NAND3x1_ASAP7_75t_R  g031(.A(new_n69_), .B(new_n72_), .C(new_n74_), .Y(new_n75_));
  OAI21x1_ASAP7_75t_R  g032(.A1(new_n62_), .A2(new_n65_), .B(new_n75_), .Y(new_n76_));
  AOI21x1_ASAP7_75t_R  g033(.A1(new_n51_), .A2(new_n60_), .B(new_n47_), .Y(new_n77_));
  INVx1_ASAP7_75t_R    g034(.A(p10), .Y(new_n78_));
  NOR2x1_ASAP7_75t_R   g035(.A(p22), .B(new_n78_), .Y(new_n79_));
  INVx1_ASAP7_75t_R    g036(.A(new_n79_), .Y(new_n80_));
  AOI21x1_ASAP7_75t_R  g037(.A1(new_n51_), .A2(new_n60_), .B(new_n56_), .Y(new_n81_));
  INVx1_ASAP7_75t_R    g038(.A(p6), .Y(new_n82_));
  NOR2x1_ASAP7_75t_R   g039(.A(p20), .B(new_n82_), .Y(new_n83_));
  INVx1_ASAP7_75t_R    g040(.A(new_n83_), .Y(new_n84_));
  OAI22x1_ASAP7_75t_R  g041(.A1(new_n77_), .A2(new_n80_), .B1(new_n81_), .B2(new_n84_), .Y(new_n85_));
  NOR2x1_ASAP7_75t_R   g042(.A(new_n76_), .B(new_n85_), .Y(new_n86_));
  INVx1_ASAP7_75t_R    g043(.A(p18), .Y(new_n87_));
  INVx1_ASAP7_75t_R    g044(.A(p2), .Y(new_n88_));
  NOR2x1_ASAP7_75t_R   g045(.A(p1), .B(new_n88_), .Y(new_n89_));
  AO31x2_ASAP7_75t_R   g046(.A1(new_n60_), .A2(new_n51_), .A3(p2), .B(new_n89_), .Y(new_n90_));
  AO31x2_ASAP7_75t_R   g047(.A1(new_n66_), .A2(new_n67_), .A3(new_n68_), .B(new_n53_), .Y(new_n91_));
  OAI21x1_ASAP7_75t_R  g048(.A1(new_n70_), .A2(new_n71_), .B(p11), .Y(new_n92_));
  INVx1_ASAP7_75t_R    g049(.A(p23), .Y(new_n93_));
  AND2x2_ASAP7_75t_R   g050(.A(p12), .B(new_n93_), .Y(new_n94_));
  AND3x1_ASAP7_75t_R   g051(.A(new_n91_), .B(new_n92_), .C(new_n94_), .Y(new_n95_));
  INVx1_ASAP7_75t_R    g052(.A(p19), .Y(new_n96_));
  NAND2x1_ASAP7_75t_R  g053(.A(p4), .B(new_n96_), .Y(new_n97_));
  AOI21x1_ASAP7_75t_R  g054(.A1(new_n59_), .A2(o0), .B(new_n97_), .Y(new_n98_));
  AOI211x1_ASAP7_75t_R g055(.A1(new_n87_), .A2(new_n90_), .B(new_n95_), .C(new_n98_), .Y(new_n99_));
  NAND3x1_ASAP7_75t_R  g056(.A(new_n46_), .B(new_n48_), .C(new_n50_), .Y(new_n100_));
  NAND3x1_ASAP7_75t_R  g057(.A(new_n54_), .B(new_n57_), .C(new_n59_), .Y(new_n101_));
  OAI21x1_ASAP7_75t_R  g058(.A1(new_n100_), .A2(new_n101_), .B(p15), .Y(new_n102_));
  INVx1_ASAP7_75t_R    g059(.A(p16), .Y(new_n103_));
  NOR2x1_ASAP7_75t_R   g060(.A(p25), .B(new_n103_), .Y(new_n104_));
  OAI21x1_ASAP7_75t_R  g061(.A1(new_n100_), .A2(new_n101_), .B(p7), .Y(new_n105_));
  INVx1_ASAP7_75t_R    g062(.A(p8), .Y(new_n106_));
  NOR2x1_ASAP7_75t_R   g063(.A(p21), .B(new_n106_), .Y(new_n107_));
  AOI22x1_ASAP7_75t_R  g064(.A1(new_n102_), .A2(new_n104_), .B1(new_n105_), .B2(new_n107_), .Y(new_n108_));
  NAND3x1_ASAP7_75t_R  g065(.A(new_n86_), .B(new_n99_), .C(new_n108_), .Y(o1));
  INVx1_ASAP7_75t_R    g066(.A(p30), .Y(new_n110_));
  AND3x1_ASAP7_75t_R   g067(.A(new_n105_), .B(p8), .C(new_n110_), .Y(new_n111_));
  OAI21x1_ASAP7_75t_R  g068(.A1(new_n100_), .A2(new_n101_), .B(p11), .Y(new_n112_));
  AOI22x1_ASAP7_75t_R  g069(.A1(new_n112_), .A2(new_n94_), .B1(new_n102_), .B2(new_n104_), .Y(new_n113_));
  OAI21x1_ASAP7_75t_R  g070(.A1(new_n100_), .A2(new_n101_), .B(p35), .Y(new_n114_));
  NAND2x1_ASAP7_75t_R  g071(.A(new_n64_), .B(new_n114_), .Y(new_n115_));
  OAI21x1_ASAP7_75t_R  g072(.A1(new_n100_), .A2(new_n101_), .B(p1), .Y(new_n116_));
  NAND3x1_ASAP7_75t_R  g073(.A(new_n116_), .B(p2), .C(new_n87_), .Y(new_n117_));
  NAND3x1_ASAP7_75t_R  g074(.A(new_n113_), .B(new_n115_), .C(new_n117_), .Y(new_n118_));
  OAI21x1_ASAP7_75t_R  g075(.A1(new_n100_), .A2(new_n101_), .B(p13), .Y(new_n119_));
  AOI22x1_ASAP7_75t_R  g076(.A1(new_n119_), .A2(new_n74_), .B1(new_n105_), .B2(new_n107_), .Y(new_n120_));
  OAI21x1_ASAP7_75t_R  g077(.A1(new_n100_), .A2(new_n101_), .B(p9), .Y(new_n121_));
  OAI21x1_ASAP7_75t_R  g078(.A1(new_n100_), .A2(new_n101_), .B(p5), .Y(new_n122_));
  AOI22x1_ASAP7_75t_R  g079(.A1(new_n121_), .A2(new_n79_), .B1(new_n122_), .B2(new_n83_), .Y(new_n123_));
  OAI21x1_ASAP7_75t_R  g080(.A1(new_n100_), .A2(new_n101_), .B(new_n59_), .Y(new_n124_));
  NAND3x1_ASAP7_75t_R  g081(.A(new_n124_), .B(new_n96_), .C(p4), .Y(new_n125_));
  NAND3x1_ASAP7_75t_R  g082(.A(new_n120_), .B(new_n123_), .C(new_n125_), .Y(new_n126_));
  OAI21x1_ASAP7_75t_R  g083(.A1(new_n118_), .A2(new_n126_), .B(p21), .Y(new_n127_));
  NAND2x1_ASAP7_75t_R  g084(.A(new_n111_), .B(new_n127_), .Y(new_n128_));
  INVx1_ASAP7_75t_R    g085(.A(p31), .Y(new_n129_));
  AND3x1_ASAP7_75t_R   g086(.A(new_n121_), .B(p10), .C(new_n129_), .Y(new_n130_));
  OAI21x1_ASAP7_75t_R  g087(.A1(new_n118_), .A2(new_n126_), .B(p22), .Y(new_n131_));
  NAND2x1_ASAP7_75t_R  g088(.A(new_n130_), .B(new_n131_), .Y(new_n132_));
  INVx1_ASAP7_75t_R    g089(.A(p29), .Y(new_n133_));
  AND3x1_ASAP7_75t_R   g090(.A(new_n122_), .B(p6), .C(new_n133_), .Y(new_n134_));
  OAI21x1_ASAP7_75t_R  g091(.A1(new_n118_), .A2(new_n126_), .B(p20), .Y(new_n135_));
  NAND2x1_ASAP7_75t_R  g092(.A(new_n134_), .B(new_n135_), .Y(new_n136_));
  AND3x1_ASAP7_75t_R   g093(.A(new_n128_), .B(new_n132_), .C(new_n136_), .Y(new_n137_));
  INVx1_ASAP7_75t_R    g094(.A(p26), .Y(new_n138_));
  AND3x1_ASAP7_75t_R   g095(.A(new_n114_), .B(p0), .C(new_n138_), .Y(new_n139_));
  INVx1_ASAP7_75t_R    g096(.A(new_n139_), .Y(new_n140_));
  AND3x1_ASAP7_75t_R   g097(.A(new_n113_), .B(new_n115_), .C(new_n117_), .Y(new_n141_));
  AND3x1_ASAP7_75t_R   g098(.A(new_n120_), .B(new_n123_), .C(new_n125_), .Y(new_n142_));
  INVx1_ASAP7_75t_R    g099(.A(p17), .Y(new_n143_));
  AOI21x1_ASAP7_75t_R  g100(.A1(new_n141_), .A2(new_n142_), .B(new_n143_), .Y(new_n144_));
  AOI22x1_ASAP7_75t_R  g101(.A1(new_n119_), .A2(new_n74_), .B1(new_n114_), .B2(new_n64_), .Y(new_n145_));
  AO31x2_ASAP7_75t_R   g102(.A1(new_n145_), .A2(new_n123_), .A3(new_n108_), .B(new_n96_), .Y(new_n146_));
  NAND2x1_ASAP7_75t_R  g103(.A(p2), .B(new_n87_), .Y(new_n147_));
  OA21x2_ASAP7_75t_R   g104(.A1(new_n100_), .A2(new_n101_), .B(p1), .Y(new_n148_));
  NAND3x1_ASAP7_75t_R  g105(.A(new_n91_), .B(new_n92_), .C(new_n94_), .Y(new_n149_));
  OAI21x1_ASAP7_75t_R  g106(.A1(new_n147_), .A2(new_n148_), .B(new_n149_), .Y(new_n150_));
  OAI21x1_ASAP7_75t_R  g107(.A1(new_n98_), .A2(new_n150_), .B(p19), .Y(new_n151_));
  INVx1_ASAP7_75t_R    g108(.A(p4), .Y(new_n152_));
  AO21x1_ASAP7_75t_R   g109(.A1(p3), .A2(o0), .B(new_n152_), .Y(new_n153_));
  NOR2x1_ASAP7_75t_R   g110(.A(p28), .B(new_n153_), .Y(new_n154_));
  NAND3x1_ASAP7_75t_R  g111(.A(new_n146_), .B(new_n151_), .C(new_n154_), .Y(new_n155_));
  OAI21x1_ASAP7_75t_R  g112(.A1(new_n140_), .A2(new_n144_), .B(new_n155_), .Y(new_n156_));
  INVx1_ASAP7_75t_R    g113(.A(new_n90_), .Y(new_n157_));
  NOR3x1_ASAP7_75t_R   g114(.A(new_n150_), .B(new_n98_), .C(new_n157_), .Y(new_n158_));
  AND3x1_ASAP7_75t_R   g115(.A(new_n145_), .B(new_n123_), .C(new_n108_), .Y(new_n159_));
  INVx1_ASAP7_75t_R    g116(.A(new_n117_), .Y(new_n160_));
  AOI21x1_ASAP7_75t_R  g117(.A1(new_n158_), .A2(new_n159_), .B(new_n160_), .Y(new_n161_));
  AO31x2_ASAP7_75t_R   g118(.A1(new_n145_), .A2(new_n123_), .A3(new_n108_), .B(new_n93_), .Y(new_n162_));
  OAI21x1_ASAP7_75t_R  g119(.A1(new_n98_), .A2(new_n150_), .B(p23), .Y(new_n163_));
  INVx1_ASAP7_75t_R    g120(.A(p32), .Y(new_n164_));
  AND3x1_ASAP7_75t_R   g121(.A(new_n112_), .B(new_n164_), .C(p12), .Y(new_n165_));
  NAND3x1_ASAP7_75t_R  g122(.A(new_n162_), .B(new_n163_), .C(new_n165_), .Y(new_n166_));
  OAI21x1_ASAP7_75t_R  g123(.A1(p27), .A2(new_n161_), .B(new_n166_), .Y(new_n167_));
  NOR2x1_ASAP7_75t_R   g124(.A(new_n156_), .B(new_n167_), .Y(new_n168_));
  OAI21x1_ASAP7_75t_R  g125(.A1(new_n118_), .A2(new_n126_), .B(p25), .Y(new_n169_));
  INVx1_ASAP7_75t_R    g126(.A(p34), .Y(new_n170_));
  AND3x1_ASAP7_75t_R   g127(.A(new_n102_), .B(p16), .C(new_n170_), .Y(new_n171_));
  OAI21x1_ASAP7_75t_R  g128(.A1(new_n118_), .A2(new_n126_), .B(p24), .Y(new_n172_));
  INVx1_ASAP7_75t_R    g129(.A(p33), .Y(new_n173_));
  AND3x1_ASAP7_75t_R   g130(.A(new_n119_), .B(p14), .C(new_n173_), .Y(new_n174_));
  AOI22x1_ASAP7_75t_R  g131(.A1(new_n169_), .A2(new_n171_), .B1(new_n172_), .B2(new_n174_), .Y(new_n175_));
  AND3x1_ASAP7_75t_R   g132(.A(new_n137_), .B(new_n168_), .C(new_n175_), .Y(new_n176_));
  INVx1_ASAP7_75t_R    g133(.A(new_n176_), .Y(o2));
  OA21x2_ASAP7_75t_R   g134(.A1(new_n118_), .A2(new_n126_), .B(p25), .Y(new_n178_));
  INVx1_ASAP7_75t_R    g135(.A(new_n171_), .Y(new_n179_));
  AOI21x1_ASAP7_75t_R  g136(.A1(new_n141_), .A2(new_n142_), .B(new_n73_), .Y(new_n180_));
  INVx1_ASAP7_75t_R    g137(.A(new_n174_), .Y(new_n181_));
  OAI22x1_ASAP7_75t_R  g138(.A1(new_n178_), .A2(new_n179_), .B1(new_n180_), .B2(new_n181_), .Y(new_n182_));
  NOR3x1_ASAP7_75t_R   g139(.A(new_n182_), .B(new_n167_), .C(new_n156_), .Y(new_n183_));
  INVx1_ASAP7_75t_R    g140(.A(new_n136_), .Y(new_n184_));
  AO22x1_ASAP7_75t_R   g141(.A1(new_n111_), .A2(new_n127_), .B1(new_n131_), .B2(new_n130_), .Y(new_n185_));
  OAI21x1_ASAP7_75t_R  g142(.A1(new_n118_), .A2(new_n126_), .B(p23), .Y(new_n186_));
  NAND3x1_ASAP7_75t_R  g143(.A(new_n186_), .B(p12), .C(new_n112_), .Y(new_n187_));
  NOR3x1_ASAP7_75t_R   g144(.A(new_n184_), .B(new_n185_), .C(new_n187_), .Y(new_n188_));
  INVx1_ASAP7_75t_R    g145(.A(new_n166_), .Y(new_n189_));
  AOI21x1_ASAP7_75t_R  g146(.A1(new_n183_), .A2(new_n188_), .B(new_n189_), .Y(new_n190_));
  NOR2x1_ASAP7_75t_R   g147(.A(new_n78_), .B(new_n77_), .Y(new_n191_));
  AND2x2_ASAP7_75t_R   g148(.A(new_n191_), .B(new_n131_), .Y(new_n192_));
  AOI22x1_ASAP7_75t_R  g149(.A1(new_n127_), .A2(new_n111_), .B1(new_n131_), .B2(new_n130_), .Y(new_n193_));
  AND3x1_ASAP7_75t_R   g150(.A(new_n192_), .B(new_n193_), .C(new_n136_), .Y(new_n194_));
  AOI21x1_ASAP7_75t_R  g151(.A1(new_n194_), .A2(new_n183_), .B(new_n185_), .Y(new_n195_));
  AND3x1_ASAP7_75t_R   g152(.A(new_n172_), .B(p14), .C(new_n119_), .Y(new_n196_));
  AND3x1_ASAP7_75t_R   g153(.A(new_n196_), .B(new_n193_), .C(new_n136_), .Y(new_n197_));
  NOR2x1_ASAP7_75t_R   g154(.A(new_n181_), .B(new_n180_), .Y(new_n198_));
  AOI21x1_ASAP7_75t_R  g155(.A1(new_n197_), .A2(new_n183_), .B(new_n198_), .Y(new_n199_));
  AND2x2_ASAP7_75t_R   g156(.A(p8), .B(new_n105_), .Y(new_n200_));
  AND2x2_ASAP7_75t_R   g157(.A(new_n200_), .B(new_n127_), .Y(new_n201_));
  NAND3x1_ASAP7_75t_R  g158(.A(new_n183_), .B(new_n137_), .C(new_n201_), .Y(new_n202_));
  AND4x2_ASAP7_75t_R   g159(.A(new_n190_), .B(new_n195_), .C(new_n199_), .D(new_n202_), .Y(new_n203_));
  OAI21x1_ASAP7_75t_R  g160(.A1(new_n118_), .A2(new_n126_), .B(p17), .Y(new_n204_));
  AND3x1_ASAP7_75t_R   g161(.A(new_n204_), .B(p0), .C(new_n114_), .Y(new_n205_));
  AND3x1_ASAP7_75t_R   g162(.A(new_n205_), .B(new_n193_), .C(new_n136_), .Y(new_n206_));
  AOI22x1_ASAP7_75t_R  g163(.A1(new_n183_), .A2(new_n206_), .B1(new_n138_), .B2(new_n205_), .Y(new_n207_));
  AOI21x1_ASAP7_75t_R  g164(.A1(p19), .A2(o1), .B(new_n153_), .Y(new_n208_));
  AND3x1_ASAP7_75t_R   g165(.A(new_n193_), .B(new_n136_), .C(new_n208_), .Y(new_n209_));
  AO21x1_ASAP7_75t_R   g166(.A1(new_n141_), .A2(new_n142_), .B(new_n96_), .Y(new_n210_));
  AOI22x1_ASAP7_75t_R  g167(.A1(new_n183_), .A2(new_n209_), .B1(new_n210_), .B2(new_n154_), .Y(new_n211_));
  AO21x1_ASAP7_75t_R   g168(.A1(new_n158_), .A2(new_n159_), .B(new_n160_), .Y(new_n212_));
  AND3x1_ASAP7_75t_R   g169(.A(new_n193_), .B(new_n136_), .C(new_n212_), .Y(new_n213_));
  NOR2x1_ASAP7_75t_R   g170(.A(p27), .B(new_n161_), .Y(new_n214_));
  AOI21x1_ASAP7_75t_R  g171(.A1(new_n213_), .A2(new_n183_), .B(new_n214_), .Y(new_n215_));
  NOR2x1_ASAP7_75t_R   g172(.A(new_n82_), .B(new_n81_), .Y(new_n216_));
  NAND2x1_ASAP7_75t_R  g173(.A(new_n216_), .B(new_n135_), .Y(new_n217_));
  INVx1_ASAP7_75t_R    g174(.A(new_n111_), .Y(new_n218_));
  AOI21x1_ASAP7_75t_R  g175(.A1(p21), .A2(o1), .B(new_n218_), .Y(new_n219_));
  AOI211x1_ASAP7_75t_R g176(.A1(new_n131_), .A2(new_n130_), .B(new_n217_), .C(new_n219_), .Y(new_n220_));
  AOI21x1_ASAP7_75t_R  g177(.A1(new_n220_), .A2(new_n183_), .B(new_n184_), .Y(new_n221_));
  AND4x2_ASAP7_75t_R   g178(.A(new_n207_), .B(new_n211_), .C(new_n215_), .D(new_n221_), .Y(new_n222_));
  AND3x1_ASAP7_75t_R   g179(.A(new_n169_), .B(p16), .C(new_n102_), .Y(new_n223_));
  OA21x2_ASAP7_75t_R   g180(.A1(new_n170_), .A2(new_n176_), .B(new_n223_), .Y(new_n224_));
  AOI21x1_ASAP7_75t_R  g181(.A1(new_n203_), .A2(new_n222_), .B(new_n224_), .Y(o3));
  INVx1_ASAP7_75t_R    g182(.A(new_n203_), .Y(o4));
  INVx1_ASAP7_75t_R    g183(.A(p27), .Y(new_n227_));
  AOI22x1_ASAP7_75t_R  g184(.A1(new_n212_), .A2(new_n227_), .B1(new_n204_), .B2(new_n139_), .Y(new_n228_));
  AOI22x1_ASAP7_75t_R  g185(.A1(new_n210_), .A2(new_n154_), .B1(new_n186_), .B2(new_n165_), .Y(new_n229_));
  AO31x2_ASAP7_75t_R   g186(.A1(new_n228_), .A2(new_n229_), .A3(new_n175_), .B(new_n129_), .Y(new_n230_));
  NAND3x1_ASAP7_75t_R  g187(.A(new_n128_), .B(new_n132_), .C(new_n136_), .Y(new_n231_));
  INVx1_ASAP7_75t_R    g188(.A(new_n192_), .Y(new_n232_));
  AOI21x1_ASAP7_75t_R  g189(.A1(p31), .A2(new_n231_), .B(new_n232_), .Y(new_n233_));
  INVx1_ASAP7_75t_R    g190(.A(new_n201_), .Y(new_n234_));
  AOI21x1_ASAP7_75t_R  g191(.A1(p30), .A2(new_n231_), .B(new_n234_), .Y(new_n235_));
  AO31x2_ASAP7_75t_R   g192(.A1(new_n228_), .A2(new_n229_), .A3(new_n175_), .B(new_n110_), .Y(new_n236_));
  AOI22x1_ASAP7_75t_R  g193(.A1(new_n230_), .A2(new_n233_), .B1(new_n235_), .B2(new_n236_), .Y(new_n237_));
  NAND3x1_ASAP7_75t_R  g194(.A(new_n168_), .B(new_n220_), .C(new_n175_), .Y(new_n238_));
  AOI21x1_ASAP7_75t_R  g195(.A1(p32), .A2(new_n231_), .B(new_n187_), .Y(new_n239_));
  AO31x2_ASAP7_75t_R   g196(.A1(new_n228_), .A2(new_n229_), .A3(new_n175_), .B(new_n164_), .Y(new_n240_));
  AOI22x1_ASAP7_75t_R  g197(.A1(new_n238_), .A2(new_n136_), .B1(new_n239_), .B2(new_n240_), .Y(new_n241_));
  NAND2x1_ASAP7_75t_R  g198(.A(new_n199_), .B(new_n190_), .Y(new_n242_));
  NAND3x1_ASAP7_75t_R  g199(.A(new_n192_), .B(new_n193_), .C(new_n136_), .Y(new_n243_));
  NAND3x1_ASAP7_75t_R  g200(.A(new_n228_), .B(new_n229_), .C(new_n175_), .Y(new_n244_));
  OAI21x1_ASAP7_75t_R  g201(.A1(new_n243_), .A2(new_n244_), .B(new_n132_), .Y(new_n245_));
  AOI211x1_ASAP7_75t_R g202(.A1(new_n236_), .A2(new_n235_), .B(new_n211_), .C(new_n245_), .Y(new_n246_));
  AO211x2_ASAP7_75t_R  g203(.A1(new_n237_), .A2(new_n241_), .B(new_n242_), .C(new_n246_), .Y(o5));
  INVx1_ASAP7_75t_R    g204(.A(new_n190_), .Y(new_n248_));
  AO21x1_ASAP7_75t_R   g205(.A1(new_n213_), .A2(new_n183_), .B(new_n214_), .Y(new_n249_));
  AOI21x1_ASAP7_75t_R  g206(.A1(new_n211_), .A2(new_n249_), .B(new_n245_), .Y(new_n250_));
  INVx1_ASAP7_75t_R    g207(.A(new_n199_), .Y(new_n251_));
  AOI21x1_ASAP7_75t_R  g208(.A1(new_n237_), .A2(new_n241_), .B(new_n251_), .Y(new_n252_));
  OAI21x1_ASAP7_75t_R  g209(.A1(new_n248_), .A2(new_n250_), .B(new_n252_), .Y(o6));
endmodule


