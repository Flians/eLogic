// Benchmark "/tmp/" written by ABC on Mon Oct 12 15:06:05 2026

module \/tmp/  ( 
    p0, p30, p21, p18, p20, p2, p26, p23, p3, p12, p33, p27, p29, p7, p34,
    p22, p1, p19, p35, p5, p4, p28, p14, p6, p15, p32, p17, p16, p13, p11,
    p10, p8, p31, p9, p25, p24,
    o0, o1, o2, o3, o4, o5, o6  );
  input  p0, p30, p21, p18, p20, p2, p26, p23, p3, p12, p33, p27, p29,
    p7, p34, p22, p1, p19, p35, p5, p4, p28, p14, p6, p15, p32, p17, p16,
    p13, p11, p10, p8, p31, p9, p25, p24;
  output o0, o1, o2, o3, o4, o5, o6;
  wire new_n44_, new_n45_, new_n46_, new_n47_, new_n48_, new_n49_, new_n50_,
    new_n51_, new_n52_, new_n53_, new_n54_, new_n55_, new_n56_, new_n57_,
    new_n58_, new_n59_, new_n61_, new_n62_, new_n63_, new_n64_, new_n65_,
    new_n66_, new_n67_, new_n68_, new_n69_, new_n70_, new_n71_, new_n72_,
    new_n73_, new_n74_, new_n75_, new_n76_, new_n77_, new_n78_, new_n79_,
    new_n80_, new_n81_, new_n82_, new_n83_, new_n84_, new_n85_, new_n86_,
    new_n87_, new_n88_, new_n89_, new_n90_, new_n91_, new_n92_, new_n93_,
    new_n94_, new_n95_, new_n96_, new_n97_, new_n98_, new_n99_, new_n100_,
    new_n101_, new_n102_, new_n103_, new_n104_, new_n105_, new_n106_,
    new_n107_, new_n108_, new_n109_, new_n111_, new_n112_, new_n113_,
    new_n114_, new_n115_, new_n116_, new_n117_, new_n118_, new_n119_,
    new_n120_, new_n121_, new_n122_, new_n123_, new_n124_, new_n125_,
    new_n126_, new_n127_, new_n128_, new_n129_, new_n130_, new_n131_,
    new_n132_, new_n133_, new_n134_, new_n135_, new_n136_, new_n137_,
    new_n138_, new_n139_, new_n140_, new_n141_, new_n142_, new_n143_,
    new_n144_, new_n145_, new_n146_, new_n147_, new_n148_, new_n149_,
    new_n150_, new_n151_, new_n152_, new_n153_, new_n154_, new_n155_,
    new_n156_, new_n157_, new_n158_, new_n159_, new_n160_, new_n161_,
    new_n162_, new_n163_, new_n164_, new_n165_, new_n166_, new_n167_,
    new_n168_, new_n169_, new_n170_, new_n171_, new_n172_, new_n173_,
    new_n174_, new_n175_, new_n176_, new_n177_, new_n178_, new_n179_,
    new_n180_, new_n181_, new_n182_, new_n183_, new_n184_, new_n185_,
    new_n186_, new_n187_, new_n188_, new_n190_, new_n191_, new_n192_,
    new_n193_, new_n194_, new_n195_, new_n196_, new_n197_, new_n198_,
    new_n199_, new_n200_, new_n201_, new_n202_, new_n203_, new_n204_,
    new_n205_, new_n206_, new_n207_, new_n208_, new_n209_, new_n210_,
    new_n211_, new_n212_, new_n213_, new_n214_, new_n215_, new_n216_,
    new_n217_, new_n218_, new_n219_, new_n220_, new_n221_, new_n222_,
    new_n223_, new_n224_, new_n225_, new_n226_, new_n227_, new_n228_,
    new_n229_, new_n230_, new_n231_, new_n232_, new_n233_, new_n234_,
    new_n235_, new_n238_, new_n239_, new_n240_, new_n241_, new_n242_,
    new_n243_, new_n244_, new_n245_, new_n246_, new_n247_, new_n248_,
    new_n249_, new_n250_, new_n251_, new_n252_, new_n253_, new_n254_,
    new_n255_, new_n256_, new_n257_, new_n258_, new_n259_, new_n260_,
    new_n261_, new_n262_, new_n263_, new_n264_, new_n265_, new_n266_,
    new_n267_, new_n269_, new_n270_, new_n271_, new_n272_, new_n273_;
  INVx1_ASAP7_75t_R    g000(.A(p4), .Y(new_n44_));
  INVx1_ASAP7_75t_R    g001(.A(p12), .Y(new_n45_));
  OAI22x1_ASAP7_75t_R  g002(.A1(p3), .A2(new_n44_), .B1(new_n45_), .B2(p11), .Y(new_n46_));
  INVx1_ASAP7_75t_R    g003(.A(p14), .Y(new_n47_));
  INVx1_ASAP7_75t_R    g004(.A(p16), .Y(new_n48_));
  OAI22x1_ASAP7_75t_R  g005(.A1(new_n47_), .A2(p13), .B1(new_n48_), .B2(p15), .Y(new_n49_));
  NOR2x1_ASAP7_75t_R   g006(.A(new_n46_), .B(new_n49_), .Y(new_n50_));
  INVx1_ASAP7_75t_R    g007(.A(p10), .Y(new_n51_));
  NOR2x1_ASAP7_75t_R   g008(.A(p9), .B(new_n51_), .Y(new_n52_));
  INVx1_ASAP7_75t_R    g009(.A(p8), .Y(new_n53_));
  INVx1_ASAP7_75t_R    g010(.A(p6), .Y(new_n54_));
  OAI22x1_ASAP7_75t_R  g011(.A1(p7), .A2(new_n53_), .B1(new_n54_), .B2(p5), .Y(new_n55_));
  NOR2x1_ASAP7_75t_R   g012(.A(new_n52_), .B(new_n55_), .Y(new_n56_));
  INVx1_ASAP7_75t_R    g013(.A(p35), .Y(new_n57_));
  INVx1_ASAP7_75t_R    g014(.A(p1), .Y(new_n58_));
  AOI22x1_ASAP7_75t_R  g015(.A1(p0), .A2(new_n57_), .B1(new_n58_), .B2(p2), .Y(new_n59_));
  NAND3x1_ASAP7_75t_R  g016(.A(new_n50_), .B(new_n56_), .C(new_n59_), .Y(o0));
  INVx1_ASAP7_75t_R    g017(.A(p7), .Y(new_n61_));
  INVx1_ASAP7_75t_R    g018(.A(p5), .Y(new_n62_));
  AOI22x1_ASAP7_75t_R  g019(.A1(new_n61_), .A2(p8), .B1(new_n62_), .B2(p6), .Y(new_n63_));
  INVx1_ASAP7_75t_R    g020(.A(p3), .Y(new_n64_));
  NAND2x1_ASAP7_75t_R  g021(.A(p4), .B(new_n64_), .Y(new_n65_));
  INVx1_ASAP7_75t_R    g022(.A(p9), .Y(new_n66_));
  NAND2x1_ASAP7_75t_R  g023(.A(p10), .B(new_n66_), .Y(new_n67_));
  NAND3x1_ASAP7_75t_R  g024(.A(new_n63_), .B(new_n65_), .C(new_n67_), .Y(new_n68_));
  INVx1_ASAP7_75t_R    g025(.A(p11), .Y(new_n69_));
  AOI22x1_ASAP7_75t_R  g026(.A1(new_n64_), .A2(p4), .B1(new_n69_), .B2(p12), .Y(new_n70_));
  INVx1_ASAP7_75t_R    g027(.A(p13), .Y(new_n71_));
  INVx1_ASAP7_75t_R    g028(.A(p15), .Y(new_n72_));
  AOI22x1_ASAP7_75t_R  g029(.A1(p14), .A2(new_n71_), .B1(new_n72_), .B2(p16), .Y(new_n73_));
  NAND3x1_ASAP7_75t_R  g030(.A(new_n70_), .B(new_n73_), .C(new_n59_), .Y(new_n74_));
  OAI21x1_ASAP7_75t_R  g031(.A1(new_n68_), .A2(new_n74_), .B(p9), .Y(new_n75_));
  NOR2x1_ASAP7_75t_R   g032(.A(p22), .B(new_n51_), .Y(new_n76_));
  NOR2x1_ASAP7_75t_R   g033(.A(p25), .B(new_n48_), .Y(new_n77_));
  INVx1_ASAP7_75t_R    g034(.A(new_n77_), .Y(new_n78_));
  AOI21x1_ASAP7_75t_R  g035(.A1(p15), .A2(o0), .B(new_n78_), .Y(new_n79_));
  NOR2x1_ASAP7_75t_R   g036(.A(p20), .B(new_n54_), .Y(new_n80_));
  INVx1_ASAP7_75t_R    g037(.A(new_n80_), .Y(new_n81_));
  AND3x1_ASAP7_75t_R   g038(.A(new_n63_), .B(new_n65_), .C(new_n67_), .Y(new_n82_));
  INVx1_ASAP7_75t_R    g039(.A(p0), .Y(new_n83_));
  INVx1_ASAP7_75t_R    g040(.A(p2), .Y(new_n84_));
  OAI22x1_ASAP7_75t_R  g041(.A1(new_n83_), .A2(p35), .B1(new_n84_), .B2(p1), .Y(new_n85_));
  NOR3x1_ASAP7_75t_R   g042(.A(new_n46_), .B(new_n49_), .C(new_n85_), .Y(new_n86_));
  AOI21x1_ASAP7_75t_R  g043(.A1(new_n82_), .A2(new_n86_), .B(new_n62_), .Y(new_n87_));
  NOR2x1_ASAP7_75t_R   g044(.A(new_n81_), .B(new_n87_), .Y(new_n88_));
  AOI211x1_ASAP7_75t_R g045(.A1(new_n75_), .A2(new_n76_), .B(new_n79_), .C(new_n88_), .Y(new_n89_));
  AO21x1_ASAP7_75t_R   g046(.A1(new_n82_), .A2(new_n86_), .B(new_n69_), .Y(new_n90_));
  NOR2x1_ASAP7_75t_R   g047(.A(p23), .B(new_n45_), .Y(new_n91_));
  NOR2x1_ASAP7_75t_R   g048(.A(p19), .B(new_n44_), .Y(new_n92_));
  INVx1_ASAP7_75t_R    g049(.A(p19), .Y(new_n93_));
  AND3x1_ASAP7_75t_R   g050(.A(new_n64_), .B(new_n93_), .C(p4), .Y(new_n94_));
  AO31x2_ASAP7_75t_R   g051(.A1(new_n86_), .A2(new_n82_), .A3(new_n92_), .B(new_n94_), .Y(new_n95_));
  NOR2x1_ASAP7_75t_R   g052(.A(p18), .B(new_n84_), .Y(new_n96_));
  INVx1_ASAP7_75t_R    g053(.A(new_n96_), .Y(new_n97_));
  AOI21x1_ASAP7_75t_R  g054(.A1(p1), .A2(o0), .B(new_n97_), .Y(new_n98_));
  AOI211x1_ASAP7_75t_R g055(.A1(new_n90_), .A2(new_n91_), .B(new_n95_), .C(new_n98_), .Y(new_n99_));
  OAI21x1_ASAP7_75t_R  g056(.A1(new_n68_), .A2(new_n74_), .B(p35), .Y(new_n100_));
  NOR2x1_ASAP7_75t_R   g057(.A(p17), .B(new_n83_), .Y(new_n101_));
  AO31x2_ASAP7_75t_R   g058(.A1(new_n70_), .A2(new_n73_), .A3(new_n59_), .B(new_n71_), .Y(new_n102_));
  AO21x1_ASAP7_75t_R   g059(.A1(new_n67_), .A2(new_n63_), .B(new_n71_), .Y(new_n103_));
  NOR2x1_ASAP7_75t_R   g060(.A(p24), .B(new_n47_), .Y(new_n104_));
  AND3x1_ASAP7_75t_R   g061(.A(new_n102_), .B(new_n103_), .C(new_n104_), .Y(new_n105_));
  NOR2x1_ASAP7_75t_R   g062(.A(p21), .B(new_n53_), .Y(new_n106_));
  INVx1_ASAP7_75t_R    g063(.A(new_n106_), .Y(new_n107_));
  AOI21x1_ASAP7_75t_R  g064(.A1(p7), .A2(o0), .B(new_n107_), .Y(new_n108_));
  AOI211x1_ASAP7_75t_R g065(.A1(new_n100_), .A2(new_n101_), .B(new_n105_), .C(new_n108_), .Y(new_n109_));
  NAND3x1_ASAP7_75t_R  g066(.A(new_n89_), .B(new_n99_), .C(new_n109_), .Y(o1));
  AOI21x1_ASAP7_75t_R  g067(.A1(new_n82_), .A2(new_n86_), .B(new_n66_), .Y(new_n111_));
  INVx1_ASAP7_75t_R    g068(.A(new_n76_), .Y(new_n112_));
  OAI22x1_ASAP7_75t_R  g069(.A1(new_n111_), .A2(new_n112_), .B1(new_n87_), .B2(new_n81_), .Y(new_n113_));
  AOI21x1_ASAP7_75t_R  g070(.A1(new_n82_), .A2(new_n86_), .B(new_n72_), .Y(new_n114_));
  AOI21x1_ASAP7_75t_R  g071(.A1(new_n82_), .A2(new_n86_), .B(new_n61_), .Y(new_n115_));
  OAI22x1_ASAP7_75t_R  g072(.A1(new_n114_), .A2(new_n78_), .B1(new_n115_), .B2(new_n107_), .Y(new_n116_));
  AOI21x1_ASAP7_75t_R  g073(.A1(new_n82_), .A2(new_n86_), .B(new_n57_), .Y(new_n117_));
  INVx1_ASAP7_75t_R    g074(.A(new_n101_), .Y(new_n118_));
  NAND3x1_ASAP7_75t_R  g075(.A(new_n102_), .B(new_n103_), .C(new_n104_), .Y(new_n119_));
  OAI21x1_ASAP7_75t_R  g076(.A1(new_n117_), .A2(new_n118_), .B(new_n119_), .Y(new_n120_));
  NOR3x1_ASAP7_75t_R   g077(.A(new_n113_), .B(new_n116_), .C(new_n120_), .Y(new_n121_));
  INVx1_ASAP7_75t_R    g078(.A(p20), .Y(new_n122_));
  AO21x1_ASAP7_75t_R   g079(.A1(new_n99_), .A2(new_n121_), .B(new_n122_), .Y(new_n123_));
  OAI21x1_ASAP7_75t_R  g080(.A1(new_n68_), .A2(new_n74_), .B(p5), .Y(new_n124_));
  INVx1_ASAP7_75t_R    g081(.A(p29), .Y(new_n125_));
  AND3x1_ASAP7_75t_R   g082(.A(new_n124_), .B(new_n125_), .C(p6), .Y(new_n126_));
  INVx1_ASAP7_75t_R    g083(.A(new_n92_), .Y(new_n127_));
  INVx1_ASAP7_75t_R    g084(.A(new_n94_), .Y(new_n128_));
  OA31x2_ASAP7_75t_R   g085(.A1(new_n127_), .A2(new_n68_), .A3(new_n74_), .B1(new_n128_), .Y(new_n129_));
  AO21x1_ASAP7_75t_R   g086(.A1(new_n82_), .A2(new_n86_), .B(new_n58_), .Y(new_n130_));
  AOI22x1_ASAP7_75t_R  g087(.A1(new_n130_), .A2(new_n96_), .B1(new_n90_), .B2(new_n91_), .Y(new_n131_));
  INVx1_ASAP7_75t_R    g088(.A(p22), .Y(new_n132_));
  AO21x1_ASAP7_75t_R   g089(.A1(new_n129_), .A2(new_n131_), .B(new_n132_), .Y(new_n133_));
  AOI22x1_ASAP7_75t_R  g090(.A1(new_n75_), .A2(new_n76_), .B1(new_n124_), .B2(new_n80_), .Y(new_n134_));
  OAI21x1_ASAP7_75t_R  g091(.A1(new_n68_), .A2(new_n74_), .B(p13), .Y(new_n135_));
  AOI22x1_ASAP7_75t_R  g092(.A1(new_n100_), .A2(new_n101_), .B1(new_n135_), .B2(new_n104_), .Y(new_n136_));
  OAI21x1_ASAP7_75t_R  g093(.A1(new_n68_), .A2(new_n74_), .B(p15), .Y(new_n137_));
  OAI21x1_ASAP7_75t_R  g094(.A1(new_n68_), .A2(new_n74_), .B(p7), .Y(new_n138_));
  AOI22x1_ASAP7_75t_R  g095(.A1(new_n137_), .A2(new_n77_), .B1(new_n138_), .B2(new_n106_), .Y(new_n139_));
  AO31x2_ASAP7_75t_R   g096(.A1(new_n134_), .A2(new_n136_), .A3(new_n139_), .B(new_n132_), .Y(new_n140_));
  INVx1_ASAP7_75t_R    g097(.A(p31), .Y(new_n141_));
  AND3x1_ASAP7_75t_R   g098(.A(new_n75_), .B(p10), .C(new_n141_), .Y(new_n142_));
  AND3x1_ASAP7_75t_R   g099(.A(new_n133_), .B(new_n140_), .C(new_n142_), .Y(new_n143_));
  OR3x1_ASAP7_75t_R    g100(.A(new_n115_), .B(p30), .C(new_n53_), .Y(new_n144_));
  AOI21x1_ASAP7_75t_R  g101(.A1(p21), .A2(o1), .B(new_n144_), .Y(new_n145_));
  AOI211x1_ASAP7_75t_R g102(.A1(new_n123_), .A2(new_n126_), .B(new_n143_), .C(new_n145_), .Y(new_n146_));
  AOI21x1_ASAP7_75t_R  g103(.A1(new_n99_), .A2(new_n121_), .B(new_n93_), .Y(new_n147_));
  AO21x1_ASAP7_75t_R   g104(.A1(p3), .A2(o0), .B(new_n44_), .Y(new_n148_));
  NOR2x1_ASAP7_75t_R   g105(.A(p28), .B(new_n148_), .Y(new_n149_));
  INVx1_ASAP7_75t_R    g106(.A(new_n149_), .Y(new_n150_));
  INVx1_ASAP7_75t_R    g107(.A(p23), .Y(new_n151_));
  AO31x2_ASAP7_75t_R   g108(.A1(new_n134_), .A2(new_n136_), .A3(new_n139_), .B(new_n151_), .Y(new_n152_));
  OA21x2_ASAP7_75t_R   g109(.A1(new_n68_), .A2(new_n74_), .B(p1), .Y(new_n153_));
  OA21x2_ASAP7_75t_R   g110(.A1(new_n68_), .A2(new_n74_), .B(p11), .Y(new_n154_));
  INVx1_ASAP7_75t_R    g111(.A(new_n91_), .Y(new_n155_));
  OAI22x1_ASAP7_75t_R  g112(.A1(new_n153_), .A2(new_n97_), .B1(new_n154_), .B2(new_n155_), .Y(new_n156_));
  OAI21x1_ASAP7_75t_R  g113(.A1(new_n95_), .A2(new_n156_), .B(p23), .Y(new_n157_));
  INVx1_ASAP7_75t_R    g114(.A(p32), .Y(new_n158_));
  AND3x1_ASAP7_75t_R   g115(.A(new_n90_), .B(p12), .C(new_n158_), .Y(new_n159_));
  NAND3x1_ASAP7_75t_R  g116(.A(new_n152_), .B(new_n157_), .C(new_n159_), .Y(new_n160_));
  OAI21x1_ASAP7_75t_R  g117(.A1(new_n147_), .A2(new_n150_), .B(new_n160_), .Y(new_n161_));
  NOR2x1_ASAP7_75t_R   g118(.A(new_n68_), .B(new_n74_), .Y(new_n162_));
  OAI21x1_ASAP7_75t_R  g119(.A1(new_n58_), .A2(new_n162_), .B(new_n96_), .Y(new_n163_));
  OAI21x1_ASAP7_75t_R  g120(.A1(new_n69_), .A2(new_n162_), .B(new_n91_), .Y(new_n164_));
  AOI21x1_ASAP7_75t_R  g121(.A1(p1), .A2(o0), .B(new_n84_), .Y(new_n165_));
  AND4x2_ASAP7_75t_R   g122(.A(new_n163_), .B(new_n164_), .C(new_n165_), .D(new_n129_), .Y(new_n166_));
  AOI21x1_ASAP7_75t_R  g123(.A1(new_n166_), .A2(new_n121_), .B(new_n98_), .Y(new_n167_));
  INVx1_ASAP7_75t_R    g124(.A(p17), .Y(new_n168_));
  AO31x2_ASAP7_75t_R   g125(.A1(new_n134_), .A2(new_n136_), .A3(new_n139_), .B(new_n168_), .Y(new_n169_));
  OAI21x1_ASAP7_75t_R  g126(.A1(new_n95_), .A2(new_n156_), .B(p17), .Y(new_n170_));
  NAND2x1_ASAP7_75t_R  g127(.A(p0), .B(new_n100_), .Y(new_n171_));
  NOR2x1_ASAP7_75t_R   g128(.A(p26), .B(new_n171_), .Y(new_n172_));
  NAND3x1_ASAP7_75t_R  g129(.A(new_n169_), .B(new_n170_), .C(new_n172_), .Y(new_n173_));
  OAI21x1_ASAP7_75t_R  g130(.A1(p27), .A2(new_n167_), .B(new_n173_), .Y(new_n174_));
  OR3x1_ASAP7_75t_R    g131(.A(new_n114_), .B(p34), .C(new_n48_), .Y(new_n175_));
  INVx1_ASAP7_75t_R    g132(.A(p25), .Y(new_n176_));
  AOI21x1_ASAP7_75t_R  g133(.A1(new_n99_), .A2(new_n121_), .B(new_n176_), .Y(new_n177_));
  AOI22x1_ASAP7_75t_R  g134(.A1(new_n100_), .A2(new_n101_), .B1(new_n137_), .B2(new_n77_), .Y(new_n178_));
  AOI22x1_ASAP7_75t_R  g135(.A1(new_n75_), .A2(new_n76_), .B1(new_n138_), .B2(new_n106_), .Y(new_n179_));
  NAND2x1_ASAP7_75t_R  g136(.A(new_n80_), .B(new_n124_), .Y(new_n180_));
  INVx1_ASAP7_75t_R    g137(.A(p24), .Y(new_n181_));
  AO31x2_ASAP7_75t_R   g138(.A1(new_n178_), .A2(new_n179_), .A3(new_n180_), .B(new_n181_), .Y(new_n182_));
  OAI21x1_ASAP7_75t_R  g139(.A1(new_n95_), .A2(new_n156_), .B(p24), .Y(new_n183_));
  INVx1_ASAP7_75t_R    g140(.A(p33), .Y(new_n184_));
  AND3x1_ASAP7_75t_R   g141(.A(new_n135_), .B(new_n184_), .C(p14), .Y(new_n185_));
  NAND3x1_ASAP7_75t_R  g142(.A(new_n182_), .B(new_n183_), .C(new_n185_), .Y(new_n186_));
  OAI21x1_ASAP7_75t_R  g143(.A1(new_n175_), .A2(new_n177_), .B(new_n186_), .Y(new_n187_));
  NOR3x1_ASAP7_75t_R   g144(.A(new_n161_), .B(new_n174_), .C(new_n187_), .Y(new_n188_));
  NAND2x1_ASAP7_75t_R  g145(.A(new_n146_), .B(new_n188_), .Y(o2));
  OA31x2_ASAP7_75t_R   g146(.A1(new_n187_), .A2(new_n161_), .A3(new_n174_), .B1(p31), .Y(new_n190_));
  AND3x1_ASAP7_75t_R   g147(.A(new_n133_), .B(new_n140_), .C(new_n75_), .Y(new_n191_));
  AND2x2_ASAP7_75t_R   g148(.A(p10), .B(new_n191_), .Y(new_n192_));
  INVx1_ASAP7_75t_R    g149(.A(new_n126_), .Y(new_n193_));
  AOI21x1_ASAP7_75t_R  g150(.A1(p20), .A2(o1), .B(new_n193_), .Y(new_n194_));
  OAI21x1_ASAP7_75t_R  g151(.A1(new_n145_), .A2(new_n194_), .B(p31), .Y(new_n195_));
  NAND2x1_ASAP7_75t_R  g152(.A(new_n192_), .B(new_n195_), .Y(new_n196_));
  OA31x2_ASAP7_75t_R   g153(.A1(new_n187_), .A2(new_n161_), .A3(new_n174_), .B1(p30), .Y(new_n197_));
  AOI21x1_ASAP7_75t_R  g154(.A1(new_n99_), .A2(new_n121_), .B(new_n122_), .Y(new_n198_));
  NAND3x1_ASAP7_75t_R  g155(.A(new_n133_), .B(new_n140_), .C(new_n142_), .Y(new_n199_));
  OAI21x1_ASAP7_75t_R  g156(.A1(new_n198_), .A2(new_n193_), .B(new_n199_), .Y(new_n200_));
  NAND2x1_ASAP7_75t_R  g157(.A(p8), .B(new_n138_), .Y(new_n201_));
  AO21x1_ASAP7_75t_R   g158(.A1(p21), .A2(o1), .B(new_n201_), .Y(new_n202_));
  AO21x1_ASAP7_75t_R   g159(.A1(p30), .A2(new_n200_), .B(new_n202_), .Y(new_n203_));
  OAI22x1_ASAP7_75t_R  g160(.A1(new_n190_), .A2(new_n196_), .B1(new_n197_), .B2(new_n203_), .Y(new_n204_));
  OA31x2_ASAP7_75t_R   g161(.A1(new_n187_), .A2(new_n161_), .A3(new_n174_), .B1(p33), .Y(new_n205_));
  NAND2x1_ASAP7_75t_R  g162(.A(p14), .B(new_n135_), .Y(new_n206_));
  AOI21x1_ASAP7_75t_R  g163(.A1(p24), .A2(o1), .B(new_n206_), .Y(new_n207_));
  OAI21x1_ASAP7_75t_R  g164(.A1(new_n184_), .A2(new_n146_), .B(new_n207_), .Y(new_n208_));
  NAND3x1_ASAP7_75t_R  g165(.A(new_n163_), .B(new_n164_), .C(new_n129_), .Y(new_n209_));
  NAND3x1_ASAP7_75t_R  g166(.A(new_n134_), .B(new_n136_), .C(new_n139_), .Y(new_n210_));
  OAI21x1_ASAP7_75t_R  g167(.A1(new_n209_), .A2(new_n210_), .B(p23), .Y(new_n211_));
  AND3x1_ASAP7_75t_R   g168(.A(new_n211_), .B(p12), .C(new_n90_), .Y(new_n212_));
  OAI21x1_ASAP7_75t_R  g169(.A1(new_n158_), .A2(new_n146_), .B(new_n212_), .Y(new_n213_));
  OA31x2_ASAP7_75t_R   g170(.A1(new_n187_), .A2(new_n161_), .A3(new_n174_), .B1(p32), .Y(new_n214_));
  OAI22x1_ASAP7_75t_R  g171(.A1(new_n205_), .A2(new_n208_), .B1(new_n213_), .B2(new_n214_), .Y(new_n215_));
  NOR2x1_ASAP7_75t_R   g172(.A(new_n204_), .B(new_n215_), .Y(new_n216_));
  AO21x1_ASAP7_75t_R   g173(.A1(p17), .A2(o1), .B(new_n171_), .Y(new_n217_));
  NOR3x1_ASAP7_75t_R   g174(.A(new_n200_), .B(new_n145_), .C(new_n217_), .Y(new_n218_));
  OAI21x1_ASAP7_75t_R  g175(.A1(new_n209_), .A2(new_n210_), .B(p17), .Y(new_n219_));
  AOI22x1_ASAP7_75t_R  g176(.A1(new_n188_), .A2(new_n218_), .B1(new_n219_), .B2(new_n172_), .Y(new_n220_));
  NOR3x1_ASAP7_75t_R   g177(.A(new_n200_), .B(new_n145_), .C(new_n167_), .Y(new_n221_));
  NOR2x1_ASAP7_75t_R   g178(.A(p27), .B(new_n167_), .Y(new_n222_));
  AOI21x1_ASAP7_75t_R  g179(.A1(new_n221_), .A2(new_n188_), .B(new_n222_), .Y(new_n223_));
  AO21x1_ASAP7_75t_R   g180(.A1(p19), .A2(o1), .B(new_n148_), .Y(new_n224_));
  NOR3x1_ASAP7_75t_R   g181(.A(new_n200_), .B(new_n145_), .C(new_n224_), .Y(new_n225_));
  NOR2x1_ASAP7_75t_R   g182(.A(new_n150_), .B(new_n147_), .Y(new_n226_));
  AOI21x1_ASAP7_75t_R  g183(.A1(new_n225_), .A2(new_n188_), .B(new_n226_), .Y(new_n227_));
  NAND2x1_ASAP7_75t_R  g184(.A(p6), .B(new_n124_), .Y(new_n228_));
  NOR2x1_ASAP7_75t_R   g185(.A(new_n228_), .B(new_n198_), .Y(new_n229_));
  AO21x1_ASAP7_75t_R   g186(.A1(p21), .A2(o1), .B(new_n144_), .Y(new_n230_));
  AND4x2_ASAP7_75t_R   g187(.A(new_n229_), .B(new_n230_), .C(p29), .D(new_n199_), .Y(new_n231_));
  AOI21x1_ASAP7_75t_R  g188(.A1(new_n231_), .A2(new_n188_), .B(new_n194_), .Y(new_n232_));
  AND4x2_ASAP7_75t_R   g189(.A(new_n220_), .B(new_n223_), .C(new_n227_), .D(new_n232_), .Y(new_n233_));
  OR3x1_ASAP7_75t_R    g190(.A(new_n177_), .B(new_n48_), .C(new_n114_), .Y(new_n234_));
  AOI21x1_ASAP7_75t_R  g191(.A1(p34), .A2(o2), .B(new_n234_), .Y(new_n235_));
  AOI21x1_ASAP7_75t_R  g192(.A1(new_n216_), .A2(new_n233_), .B(new_n235_), .Y(o3));
  INVx1_ASAP7_75t_R    g193(.A(new_n216_), .Y(o4));
  AOI21x1_ASAP7_75t_R  g194(.A1(p30), .A2(new_n200_), .B(new_n202_), .Y(new_n238_));
  NAND3x1_ASAP7_75t_R  g195(.A(new_n131_), .B(new_n129_), .C(new_n165_), .Y(new_n239_));
  OAI21x1_ASAP7_75t_R  g196(.A1(new_n210_), .A2(new_n239_), .B(new_n163_), .Y(new_n240_));
  INVx1_ASAP7_75t_R    g197(.A(p27), .Y(new_n241_));
  AOI22x1_ASAP7_75t_R  g198(.A1(new_n240_), .A2(new_n241_), .B1(new_n219_), .B2(new_n172_), .Y(new_n242_));
  OAI21x1_ASAP7_75t_R  g199(.A1(new_n209_), .A2(new_n210_), .B(p25), .Y(new_n243_));
  INVx1_ASAP7_75t_R    g200(.A(new_n175_), .Y(new_n244_));
  OAI21x1_ASAP7_75t_R  g201(.A1(new_n209_), .A2(new_n210_), .B(p24), .Y(new_n245_));
  AOI22x1_ASAP7_75t_R  g202(.A1(new_n243_), .A2(new_n244_), .B1(new_n245_), .B2(new_n185_), .Y(new_n246_));
  NOR2x1_ASAP7_75t_R   g203(.A(new_n95_), .B(new_n131_), .Y(new_n247_));
  AOI21x1_ASAP7_75t_R  g204(.A1(new_n129_), .A2(new_n210_), .B(new_n247_), .Y(new_n248_));
  AOI22x1_ASAP7_75t_R  g205(.A1(new_n211_), .A2(new_n159_), .B1(new_n248_), .B2(new_n149_), .Y(new_n249_));
  INVx1_ASAP7_75t_R    g206(.A(p30), .Y(new_n250_));
  AO31x2_ASAP7_75t_R   g207(.A1(new_n242_), .A2(new_n246_), .A3(new_n249_), .B(new_n250_), .Y(new_n251_));
  OA31x2_ASAP7_75t_R   g208(.A1(new_n187_), .A2(new_n161_), .A3(new_n174_), .B1(p29), .Y(new_n252_));
  OAI21x1_ASAP7_75t_R  g209(.A1(new_n125_), .A2(new_n146_), .B(new_n229_), .Y(new_n253_));
  AOI211x1_ASAP7_75t_R g210(.A1(new_n238_), .A2(new_n251_), .B(new_n252_), .C(new_n253_), .Y(new_n254_));
  NAND2x1_ASAP7_75t_R  g211(.A(new_n136_), .B(new_n139_), .Y(new_n255_));
  NOR3x1_ASAP7_75t_R   g212(.A(new_n255_), .B(new_n209_), .C(new_n113_), .Y(new_n256_));
  OAI21x1_ASAP7_75t_R  g213(.A1(new_n122_), .A2(new_n256_), .B(new_n126_), .Y(new_n257_));
  NAND3x1_ASAP7_75t_R  g214(.A(new_n230_), .B(new_n257_), .C(new_n199_), .Y(new_n258_));
  INVx1_ASAP7_75t_R    g215(.A(new_n212_), .Y(new_n259_));
  AOI21x1_ASAP7_75t_R  g216(.A1(p32), .A2(new_n258_), .B(new_n259_), .Y(new_n260_));
  AO31x2_ASAP7_75t_R   g217(.A1(new_n242_), .A2(new_n246_), .A3(new_n249_), .B(new_n158_), .Y(new_n261_));
  AO31x2_ASAP7_75t_R   g218(.A1(new_n242_), .A2(new_n246_), .A3(new_n249_), .B(new_n141_), .Y(new_n262_));
  NAND2x1_ASAP7_75t_R  g219(.A(p10), .B(new_n191_), .Y(new_n263_));
  AOI21x1_ASAP7_75t_R  g220(.A1(new_n257_), .A2(new_n230_), .B(new_n141_), .Y(new_n264_));
  NOR2x1_ASAP7_75t_R   g221(.A(new_n263_), .B(new_n264_), .Y(new_n265_));
  AOI22x1_ASAP7_75t_R  g222(.A1(new_n260_), .A2(new_n261_), .B1(new_n262_), .B2(new_n265_), .Y(new_n266_));
  AOI21x1_ASAP7_75t_R  g223(.A1(new_n254_), .A2(new_n266_), .B(new_n215_), .Y(new_n267_));
  OAI21x1_ASAP7_75t_R  g224(.A1(new_n204_), .A2(new_n227_), .B(new_n267_), .Y(o5));
  NOR2x1_ASAP7_75t_R   g225(.A(new_n214_), .B(new_n213_), .Y(new_n269_));
  AO21x1_ASAP7_75t_R   g226(.A1(new_n221_), .A2(new_n188_), .B(new_n222_), .Y(new_n270_));
  AOI22x1_ASAP7_75t_R  g227(.A1(new_n270_), .A2(new_n227_), .B1(new_n262_), .B2(new_n265_), .Y(new_n271_));
  NOR2x1_ASAP7_75t_R   g228(.A(new_n205_), .B(new_n208_), .Y(new_n272_));
  AOI21x1_ASAP7_75t_R  g229(.A1(new_n254_), .A2(new_n266_), .B(new_n272_), .Y(new_n273_));
  OAI21x1_ASAP7_75t_R  g230(.A1(new_n269_), .A2(new_n271_), .B(new_n273_), .Y(o6));
endmodule


