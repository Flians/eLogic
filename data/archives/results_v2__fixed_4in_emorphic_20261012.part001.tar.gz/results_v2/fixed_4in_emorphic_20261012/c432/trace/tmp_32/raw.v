// Benchmark "/tmp/" written by ABC on Mon Oct 12 15:06:07 2026

module \/tmp/  ( 
    p15, p18, p10, p11, p4, p31, p12, p34, p30, p19, p29, p0, p7, p24, p26,
    p17, p35, p3, p27, p21, p5, p6, p22, p32, p20, p8, p16, p23, p1, p13,
    p33, p25, p9, p2, p28, p14,
    o0, o1, o2, o3, o4, o5, o6  );
  input  p15, p18, p10, p11, p4, p31, p12, p34, p30, p19, p29, p0, p7,
    p24, p26, p17, p35, p3, p27, p21, p5, p6, p22, p32, p20, p8, p16, p23,
    p1, p13, p33, p25, p9, p2, p28, p14;
  output o0, o1, o2, o3, o4, o5, o6;
  wire new_n44_, new_n45_, new_n46_, new_n47_, new_n48_, new_n49_, new_n50_,
    new_n51_, new_n52_, new_n53_, new_n54_, new_n55_, new_n56_, new_n57_,
    new_n58_, new_n59_, new_n60_, new_n61_, new_n63_, new_n64_, new_n65_,
    new_n66_, new_n67_, new_n68_, new_n69_, new_n70_, new_n71_, new_n72_,
    new_n73_, new_n74_, new_n75_, new_n76_, new_n77_, new_n78_, new_n79_,
    new_n80_, new_n81_, new_n82_, new_n83_, new_n84_, new_n85_, new_n86_,
    new_n87_, new_n88_, new_n89_, new_n90_, new_n91_, new_n92_, new_n93_,
    new_n94_, new_n95_, new_n96_, new_n97_, new_n98_, new_n99_, new_n100_,
    new_n101_, new_n102_, new_n103_, new_n104_, new_n105_, new_n106_,
    new_n107_, new_n108_, new_n110_, new_n111_, new_n112_, new_n113_,
    new_n114_, new_n115_, new_n116_, new_n117_, new_n118_, new_n119_,
    new_n120_, new_n121_, new_n122_, new_n123_, new_n124_, new_n125_,
    new_n126_, new_n127_, new_n128_, new_n129_, new_n130_, new_n131_,
    new_n132_, new_n133_, new_n134_, new_n135_, new_n136_, new_n137_,
    new_n138_, new_n139_, new_n140_, new_n141_, new_n142_, new_n143_,
    new_n144_, new_n145_, new_n146_, new_n147_, new_n148_, new_n149_,
    new_n150_, new_n151_, new_n152_, new_n153_, new_n154_, new_n155_,
    new_n156_, new_n157_, new_n158_, new_n159_, new_n160_, new_n161_,
    new_n162_, new_n163_, new_n164_, new_n165_, new_n166_, new_n167_,
    new_n168_, new_n169_, new_n170_, new_n171_, new_n172_, new_n173_,
    new_n174_, new_n175_, new_n176_, new_n177_, new_n178_, new_n179_,
    new_n181_, new_n182_, new_n183_, new_n184_, new_n185_, new_n186_,
    new_n187_, new_n188_, new_n189_, new_n190_, new_n191_, new_n192_,
    new_n193_, new_n194_, new_n195_, new_n196_, new_n197_, new_n198_,
    new_n199_, new_n200_, new_n201_, new_n202_, new_n203_, new_n204_,
    new_n205_, new_n206_, new_n207_, new_n208_, new_n209_, new_n210_,
    new_n211_, new_n212_, new_n213_, new_n214_, new_n215_, new_n216_,
    new_n217_, new_n218_, new_n219_, new_n220_, new_n221_, new_n222_,
    new_n223_, new_n224_, new_n225_, new_n226_, new_n227_, new_n228_,
    new_n229_, new_n230_, new_n231_, new_n232_, new_n233_, new_n236_,
    new_n237_, new_n238_, new_n239_, new_n240_, new_n241_, new_n242_,
    new_n243_, new_n244_, new_n245_, new_n246_, new_n247_, new_n248_,
    new_n249_, new_n250_, new_n251_, new_n252_, new_n253_, new_n254_,
    new_n255_, new_n256_, new_n257_, new_n258_, new_n259_, new_n260_,
    new_n261_, new_n262_, new_n263_, new_n264_, new_n266_, new_n267_;
  INVx1_ASAP7_75t_R    g000(.A(p7), .Y(new_n44_));
  INVx1_ASAP7_75t_R    g001(.A(p5), .Y(new_n45_));
  AOI22x1_ASAP7_75t_R  g002(.A1(new_n44_), .A2(p8), .B1(new_n45_), .B2(p6), .Y(new_n46_));
  INVx1_ASAP7_75t_R    g003(.A(p3), .Y(new_n47_));
  NAND2x1_ASAP7_75t_R  g004(.A(p4), .B(new_n47_), .Y(new_n48_));
  INVx1_ASAP7_75t_R    g005(.A(p9), .Y(new_n49_));
  NAND2x1_ASAP7_75t_R  g006(.A(p10), .B(new_n49_), .Y(new_n50_));
  NAND3x1_ASAP7_75t_R  g007(.A(new_n46_), .B(new_n48_), .C(new_n50_), .Y(new_n51_));
  INVx1_ASAP7_75t_R    g008(.A(p15), .Y(new_n52_));
  INVx1_ASAP7_75t_R    g009(.A(p13), .Y(new_n53_));
  AOI22x1_ASAP7_75t_R  g010(.A1(new_n52_), .A2(p16), .B1(new_n53_), .B2(p14), .Y(new_n54_));
  INVx1_ASAP7_75t_R    g011(.A(p35), .Y(new_n55_));
  INVx1_ASAP7_75t_R    g012(.A(p1), .Y(new_n56_));
  AOI22x1_ASAP7_75t_R  g013(.A1(p0), .A2(new_n55_), .B1(new_n56_), .B2(p2), .Y(new_n57_));
  INVx1_ASAP7_75t_R    g014(.A(p11), .Y(new_n58_));
  AOI22x1_ASAP7_75t_R  g015(.A1(new_n58_), .A2(p12), .B1(new_n47_), .B2(p4), .Y(new_n59_));
  NAND3x1_ASAP7_75t_R  g016(.A(new_n54_), .B(new_n57_), .C(new_n59_), .Y(new_n60_));
  NOR2x1_ASAP7_75t_R   g017(.A(new_n51_), .B(new_n60_), .Y(new_n61_));
  INVx1_ASAP7_75t_R    g018(.A(new_n61_), .Y(o0));
  AND3x1_ASAP7_75t_R   g019(.A(new_n46_), .B(new_n48_), .C(new_n50_), .Y(new_n63_));
  INVx1_ASAP7_75t_R    g020(.A(p16), .Y(new_n64_));
  INVx1_ASAP7_75t_R    g021(.A(p14), .Y(new_n65_));
  OAI22x1_ASAP7_75t_R  g022(.A1(p15), .A2(new_n64_), .B1(new_n65_), .B2(p13), .Y(new_n66_));
  INVx1_ASAP7_75t_R    g023(.A(p0), .Y(new_n67_));
  INVx1_ASAP7_75t_R    g024(.A(p2), .Y(new_n68_));
  OAI22x1_ASAP7_75t_R  g025(.A1(new_n67_), .A2(p35), .B1(new_n68_), .B2(p1), .Y(new_n69_));
  INVx1_ASAP7_75t_R    g026(.A(p12), .Y(new_n70_));
  INVx1_ASAP7_75t_R    g027(.A(p4), .Y(new_n71_));
  OAI22x1_ASAP7_75t_R  g028(.A1(p11), .A2(new_n70_), .B1(new_n71_), .B2(p3), .Y(new_n72_));
  NOR3x1_ASAP7_75t_R   g029(.A(new_n66_), .B(new_n69_), .C(new_n72_), .Y(new_n73_));
  AOI21x1_ASAP7_75t_R  g030(.A1(new_n63_), .A2(new_n73_), .B(new_n55_), .Y(new_n74_));
  NOR2x1_ASAP7_75t_R   g031(.A(p17), .B(new_n67_), .Y(new_n75_));
  INVx1_ASAP7_75t_R    g032(.A(new_n75_), .Y(new_n76_));
  AO31x2_ASAP7_75t_R   g033(.A1(new_n54_), .A2(new_n57_), .A3(new_n59_), .B(new_n53_), .Y(new_n77_));
  AO21x1_ASAP7_75t_R   g034(.A1(new_n50_), .A2(new_n46_), .B(new_n53_), .Y(new_n78_));
  NOR2x1_ASAP7_75t_R   g035(.A(p24), .B(new_n65_), .Y(new_n79_));
  NAND3x1_ASAP7_75t_R  g036(.A(new_n77_), .B(new_n78_), .C(new_n79_), .Y(new_n80_));
  OAI21x1_ASAP7_75t_R  g037(.A1(new_n74_), .A2(new_n76_), .B(new_n80_), .Y(new_n81_));
  AOI21x1_ASAP7_75t_R  g038(.A1(new_n63_), .A2(new_n73_), .B(new_n44_), .Y(new_n82_));
  INVx1_ASAP7_75t_R    g039(.A(p8), .Y(new_n83_));
  NOR2x1_ASAP7_75t_R   g040(.A(p21), .B(new_n83_), .Y(new_n84_));
  INVx1_ASAP7_75t_R    g041(.A(new_n84_), .Y(new_n85_));
  AOI21x1_ASAP7_75t_R  g042(.A1(new_n63_), .A2(new_n73_), .B(new_n52_), .Y(new_n86_));
  NOR2x1_ASAP7_75t_R   g043(.A(p25), .B(new_n64_), .Y(new_n87_));
  INVx1_ASAP7_75t_R    g044(.A(new_n87_), .Y(new_n88_));
  OAI22x1_ASAP7_75t_R  g045(.A1(new_n82_), .A2(new_n85_), .B1(new_n86_), .B2(new_n88_), .Y(new_n89_));
  NOR2x1_ASAP7_75t_R   g046(.A(new_n81_), .B(new_n89_), .Y(new_n90_));
  AO21x1_ASAP7_75t_R   g047(.A1(new_n63_), .A2(new_n73_), .B(new_n56_), .Y(new_n91_));
  NOR2x1_ASAP7_75t_R   g048(.A(p18), .B(new_n68_), .Y(new_n92_));
  NOR2x1_ASAP7_75t_R   g049(.A(p19), .B(new_n71_), .Y(new_n93_));
  INVx1_ASAP7_75t_R    g050(.A(p19), .Y(new_n94_));
  AND3x1_ASAP7_75t_R   g051(.A(new_n94_), .B(new_n47_), .C(p4), .Y(new_n95_));
  AO31x2_ASAP7_75t_R   g052(.A1(new_n73_), .A2(new_n63_), .A3(new_n93_), .B(new_n95_), .Y(new_n96_));
  NOR2x1_ASAP7_75t_R   g053(.A(p23), .B(new_n70_), .Y(new_n97_));
  INVx1_ASAP7_75t_R    g054(.A(new_n97_), .Y(new_n98_));
  AOI21x1_ASAP7_75t_R  g055(.A1(new_n63_), .A2(new_n73_), .B(new_n58_), .Y(new_n99_));
  NOR2x1_ASAP7_75t_R   g056(.A(new_n98_), .B(new_n99_), .Y(new_n100_));
  AOI211x1_ASAP7_75t_R g057(.A1(new_n91_), .A2(new_n92_), .B(new_n96_), .C(new_n100_), .Y(new_n101_));
  OAI21x1_ASAP7_75t_R  g058(.A1(new_n51_), .A2(new_n60_), .B(p5), .Y(new_n102_));
  INVx1_ASAP7_75t_R    g059(.A(p6), .Y(new_n103_));
  NOR2x1_ASAP7_75t_R   g060(.A(p20), .B(new_n103_), .Y(new_n104_));
  OAI21x1_ASAP7_75t_R  g061(.A1(new_n51_), .A2(new_n60_), .B(p9), .Y(new_n105_));
  INVx1_ASAP7_75t_R    g062(.A(p10), .Y(new_n106_));
  NOR2x1_ASAP7_75t_R   g063(.A(p22), .B(new_n106_), .Y(new_n107_));
  AOI22x1_ASAP7_75t_R  g064(.A1(new_n102_), .A2(new_n104_), .B1(new_n105_), .B2(new_n107_), .Y(new_n108_));
  NAND3x1_ASAP7_75t_R  g065(.A(new_n90_), .B(new_n101_), .C(new_n108_), .Y(o1));
  INVx1_ASAP7_75t_R    g066(.A(p30), .Y(new_n110_));
  OAI21x1_ASAP7_75t_R  g067(.A1(new_n51_), .A2(new_n60_), .B(p11), .Y(new_n111_));
  OAI21x1_ASAP7_75t_R  g068(.A1(new_n51_), .A2(new_n60_), .B(p15), .Y(new_n112_));
  AOI22x1_ASAP7_75t_R  g069(.A1(new_n111_), .A2(new_n97_), .B1(new_n112_), .B2(new_n87_), .Y(new_n113_));
  NAND2x1_ASAP7_75t_R  g070(.A(new_n92_), .B(new_n91_), .Y(new_n114_));
  OAI21x1_ASAP7_75t_R  g071(.A1(new_n51_), .A2(new_n60_), .B(p35), .Y(new_n115_));
  NAND2x1_ASAP7_75t_R  g072(.A(new_n75_), .B(new_n115_), .Y(new_n116_));
  AND3x1_ASAP7_75t_R   g073(.A(new_n113_), .B(new_n114_), .C(new_n116_), .Y(new_n117_));
  AOI21x1_ASAP7_75t_R  g074(.A1(new_n63_), .A2(new_n73_), .B(new_n45_), .Y(new_n118_));
  INVx1_ASAP7_75t_R    g075(.A(new_n104_), .Y(new_n119_));
  AOI21x1_ASAP7_75t_R  g076(.A1(new_n63_), .A2(new_n73_), .B(new_n49_), .Y(new_n120_));
  INVx1_ASAP7_75t_R    g077(.A(new_n107_), .Y(new_n121_));
  OAI22x1_ASAP7_75t_R  g078(.A1(new_n118_), .A2(new_n119_), .B1(new_n120_), .B2(new_n121_), .Y(new_n122_));
  OAI21x1_ASAP7_75t_R  g079(.A1(new_n82_), .A2(new_n85_), .B(new_n80_), .Y(new_n123_));
  NOR3x1_ASAP7_75t_R   g080(.A(new_n122_), .B(new_n123_), .C(new_n96_), .Y(new_n124_));
  NOR2x1_ASAP7_75t_R   g081(.A(new_n83_), .B(new_n82_), .Y(new_n125_));
  NOR2x1_ASAP7_75t_R   g082(.A(new_n85_), .B(new_n82_), .Y(new_n126_));
  AO31x2_ASAP7_75t_R   g083(.A1(new_n117_), .A2(new_n124_), .A3(new_n125_), .B(new_n126_), .Y(new_n127_));
  INVx1_ASAP7_75t_R    g084(.A(p29), .Y(new_n128_));
  AND3x1_ASAP7_75t_R   g085(.A(new_n102_), .B(new_n128_), .C(p6), .Y(new_n129_));
  INVx1_ASAP7_75t_R    g086(.A(new_n129_), .Y(new_n130_));
  AOI21x1_ASAP7_75t_R  g087(.A1(p20), .A2(o1), .B(new_n130_), .Y(new_n131_));
  INVx1_ASAP7_75t_R    g088(.A(p31), .Y(new_n132_));
  AND3x1_ASAP7_75t_R   g089(.A(new_n105_), .B(p10), .C(new_n132_), .Y(new_n133_));
  INVx1_ASAP7_75t_R    g090(.A(new_n133_), .Y(new_n134_));
  AOI21x1_ASAP7_75t_R  g091(.A1(p22), .A2(o1), .B(new_n134_), .Y(new_n135_));
  AOI211x1_ASAP7_75t_R g092(.A1(new_n110_), .A2(new_n127_), .B(new_n131_), .C(new_n135_), .Y(new_n136_));
  AO21x1_ASAP7_75t_R   g093(.A1(p3), .A2(o0), .B(new_n71_), .Y(new_n137_));
  NOR2x1_ASAP7_75t_R   g094(.A(p28), .B(new_n137_), .Y(new_n138_));
  INVx1_ASAP7_75t_R    g095(.A(new_n138_), .Y(new_n139_));
  AOI21x1_ASAP7_75t_R  g096(.A1(new_n124_), .A2(new_n117_), .B(new_n94_), .Y(new_n140_));
  OAI21x1_ASAP7_75t_R  g097(.A1(new_n51_), .A2(new_n60_), .B(p7), .Y(new_n141_));
  AOI22x1_ASAP7_75t_R  g098(.A1(new_n141_), .A2(new_n84_), .B1(new_n112_), .B2(new_n87_), .Y(new_n142_));
  AOI21x1_ASAP7_75t_R  g099(.A1(new_n50_), .A2(new_n46_), .B(new_n53_), .Y(new_n143_));
  AOI21x1_ASAP7_75t_R  g100(.A1(p13), .A2(new_n60_), .B(new_n143_), .Y(new_n144_));
  AOI22x1_ASAP7_75t_R  g101(.A1(new_n115_), .A2(new_n75_), .B1(new_n144_), .B2(new_n79_), .Y(new_n145_));
  INVx1_ASAP7_75t_R    g102(.A(p23), .Y(new_n146_));
  AO31x2_ASAP7_75t_R   g103(.A1(new_n108_), .A2(new_n142_), .A3(new_n145_), .B(new_n146_), .Y(new_n147_));
  INVx1_ASAP7_75t_R    g104(.A(new_n96_), .Y(new_n148_));
  AOI22x1_ASAP7_75t_R  g105(.A1(new_n91_), .A2(new_n92_), .B1(new_n111_), .B2(new_n97_), .Y(new_n149_));
  AO21x1_ASAP7_75t_R   g106(.A1(new_n148_), .A2(new_n149_), .B(new_n146_), .Y(new_n150_));
  INVx1_ASAP7_75t_R    g107(.A(p32), .Y(new_n151_));
  AND3x1_ASAP7_75t_R   g108(.A(new_n111_), .B(p12), .C(new_n151_), .Y(new_n152_));
  NAND3x1_ASAP7_75t_R  g109(.A(new_n147_), .B(new_n150_), .C(new_n152_), .Y(new_n153_));
  OAI21x1_ASAP7_75t_R  g110(.A1(new_n139_), .A2(new_n140_), .B(new_n153_), .Y(new_n154_));
  NAND2x1_ASAP7_75t_R  g111(.A(new_n97_), .B(new_n111_), .Y(new_n155_));
  NOR2x1_ASAP7_75t_R   g112(.A(p1), .B(new_n68_), .Y(new_n156_));
  AO31x2_ASAP7_75t_R   g113(.A1(new_n73_), .A2(new_n63_), .A3(p2), .B(new_n156_), .Y(new_n157_));
  AND4x2_ASAP7_75t_R   g114(.A(new_n148_), .B(new_n155_), .C(p18), .D(new_n157_), .Y(new_n158_));
  AND3x1_ASAP7_75t_R   g115(.A(new_n108_), .B(new_n142_), .C(new_n145_), .Y(new_n159_));
  INVx1_ASAP7_75t_R    g116(.A(new_n114_), .Y(new_n160_));
  AOI21x1_ASAP7_75t_R  g117(.A1(new_n158_), .A2(new_n159_), .B(new_n160_), .Y(new_n161_));
  INVx1_ASAP7_75t_R    g118(.A(p17), .Y(new_n162_));
  AO31x2_ASAP7_75t_R   g119(.A1(new_n108_), .A2(new_n142_), .A3(new_n145_), .B(new_n162_), .Y(new_n163_));
  AO21x1_ASAP7_75t_R   g120(.A1(new_n148_), .A2(new_n149_), .B(new_n162_), .Y(new_n164_));
  INVx1_ASAP7_75t_R    g121(.A(p26), .Y(new_n165_));
  AND3x1_ASAP7_75t_R   g122(.A(new_n115_), .B(p0), .C(new_n165_), .Y(new_n166_));
  NAND3x1_ASAP7_75t_R  g123(.A(new_n163_), .B(new_n164_), .C(new_n166_), .Y(new_n167_));
  OAI21x1_ASAP7_75t_R  g124(.A1(p27), .A2(new_n161_), .B(new_n167_), .Y(new_n168_));
  INVx1_ASAP7_75t_R    g125(.A(p25), .Y(new_n169_));
  AOI21x1_ASAP7_75t_R  g126(.A1(new_n124_), .A2(new_n117_), .B(new_n169_), .Y(new_n170_));
  OR3x1_ASAP7_75t_R    g127(.A(new_n86_), .B(p34), .C(new_n64_), .Y(new_n171_));
  INVx1_ASAP7_75t_R    g128(.A(p24), .Y(new_n172_));
  AO31x2_ASAP7_75t_R   g129(.A1(new_n108_), .A2(new_n142_), .A3(new_n145_), .B(new_n172_), .Y(new_n173_));
  AO31x2_ASAP7_75t_R   g130(.A1(new_n114_), .A2(new_n148_), .A3(new_n155_), .B(new_n172_), .Y(new_n174_));
  NAND2x1_ASAP7_75t_R  g131(.A(p14), .B(new_n144_), .Y(new_n175_));
  NOR2x1_ASAP7_75t_R   g132(.A(p33), .B(new_n175_), .Y(new_n176_));
  NAND3x1_ASAP7_75t_R  g133(.A(new_n173_), .B(new_n174_), .C(new_n176_), .Y(new_n177_));
  OAI21x1_ASAP7_75t_R  g134(.A1(new_n170_), .A2(new_n171_), .B(new_n177_), .Y(new_n178_));
  NOR3x1_ASAP7_75t_R   g135(.A(new_n154_), .B(new_n168_), .C(new_n178_), .Y(new_n179_));
  NAND2x1_ASAP7_75t_R  g136(.A(new_n136_), .B(new_n179_), .Y(o2));
  INVx1_ASAP7_75t_R    g137(.A(p22), .Y(new_n181_));
  AO21x1_ASAP7_75t_R   g138(.A1(new_n124_), .A2(new_n117_), .B(new_n181_), .Y(new_n182_));
  NAND3x1_ASAP7_75t_R  g139(.A(new_n113_), .B(new_n114_), .C(new_n116_), .Y(new_n183_));
  AOI22x1_ASAP7_75t_R  g140(.A1(new_n141_), .A2(new_n84_), .B1(new_n144_), .B2(new_n79_), .Y(new_n184_));
  NAND3x1_ASAP7_75t_R  g141(.A(new_n108_), .B(new_n184_), .C(new_n148_), .Y(new_n185_));
  OAI21x1_ASAP7_75t_R  g142(.A1(new_n183_), .A2(new_n185_), .B(p20), .Y(new_n186_));
  AOI22x1_ASAP7_75t_R  g143(.A1(new_n182_), .A2(new_n133_), .B1(new_n186_), .B2(new_n129_), .Y(new_n187_));
  AND3x1_ASAP7_75t_R   g144(.A(new_n141_), .B(new_n110_), .C(p8), .Y(new_n188_));
  OAI21x1_ASAP7_75t_R  g145(.A1(new_n183_), .A2(new_n185_), .B(p21), .Y(new_n189_));
  NAND2x1_ASAP7_75t_R  g146(.A(new_n188_), .B(new_n189_), .Y(new_n190_));
  AOI21x1_ASAP7_75t_R  g147(.A1(p24), .A2(o1), .B(new_n175_), .Y(new_n191_));
  AND3x1_ASAP7_75t_R   g148(.A(new_n187_), .B(new_n190_), .C(new_n191_), .Y(new_n192_));
  INVx1_ASAP7_75t_R    g149(.A(new_n177_), .Y(new_n193_));
  AOI21x1_ASAP7_75t_R  g150(.A1(new_n179_), .A2(new_n192_), .B(new_n193_), .Y(new_n194_));
  NAND2x1_ASAP7_75t_R  g151(.A(new_n129_), .B(new_n186_), .Y(new_n195_));
  NAND2x1_ASAP7_75t_R  g152(.A(p12), .B(new_n111_), .Y(new_n196_));
  AOI21x1_ASAP7_75t_R  g153(.A1(p23), .A2(o1), .B(new_n196_), .Y(new_n197_));
  NAND2x1_ASAP7_75t_R  g154(.A(new_n145_), .B(new_n142_), .Y(new_n198_));
  OAI21x1_ASAP7_75t_R  g155(.A1(new_n122_), .A2(new_n198_), .B(p22), .Y(new_n199_));
  AO21x1_ASAP7_75t_R   g156(.A1(new_n148_), .A2(new_n149_), .B(new_n181_), .Y(new_n200_));
  NAND3x1_ASAP7_75t_R  g157(.A(new_n199_), .B(new_n200_), .C(new_n133_), .Y(new_n201_));
  AND4x2_ASAP7_75t_R   g158(.A(new_n190_), .B(new_n195_), .C(new_n197_), .D(new_n201_), .Y(new_n202_));
  INVx1_ASAP7_75t_R    g159(.A(new_n153_), .Y(new_n203_));
  AOI21x1_ASAP7_75t_R  g160(.A1(new_n202_), .A2(new_n179_), .B(new_n203_), .Y(new_n204_));
  NAND2x1_ASAP7_75t_R  g161(.A(p10), .B(new_n105_), .Y(new_n205_));
  AOI21x1_ASAP7_75t_R  g162(.A1(p22), .A2(o1), .B(new_n205_), .Y(new_n206_));
  AND4x2_ASAP7_75t_R   g163(.A(new_n190_), .B(new_n195_), .C(new_n206_), .D(p31), .Y(new_n207_));
  AOI21x1_ASAP7_75t_R  g164(.A1(new_n207_), .A2(new_n179_), .B(new_n135_), .Y(new_n208_));
  AND4x2_ASAP7_75t_R   g165(.A(new_n195_), .B(new_n201_), .C(p30), .D(new_n127_), .Y(new_n209_));
  INVx1_ASAP7_75t_R    g166(.A(new_n190_), .Y(new_n210_));
  AOI21x1_ASAP7_75t_R  g167(.A1(new_n209_), .A2(new_n179_), .B(new_n210_), .Y(new_n211_));
  AND4x2_ASAP7_75t_R   g168(.A(new_n194_), .B(new_n204_), .C(new_n208_), .D(new_n211_), .Y(new_n212_));
  OAI21x1_ASAP7_75t_R  g169(.A1(new_n183_), .A2(new_n185_), .B(p17), .Y(new_n213_));
  AND3x1_ASAP7_75t_R   g170(.A(new_n213_), .B(p0), .C(new_n115_), .Y(new_n214_));
  AND3x1_ASAP7_75t_R   g171(.A(new_n187_), .B(new_n190_), .C(new_n214_), .Y(new_n215_));
  AOI22x1_ASAP7_75t_R  g172(.A1(new_n215_), .A2(new_n179_), .B1(new_n213_), .B2(new_n166_), .Y(new_n216_));
  NAND3x1_ASAP7_75t_R  g173(.A(new_n108_), .B(new_n142_), .C(new_n145_), .Y(new_n217_));
  NAND3x1_ASAP7_75t_R  g174(.A(new_n149_), .B(new_n148_), .C(new_n157_), .Y(new_n218_));
  OAI21x1_ASAP7_75t_R  g175(.A1(new_n217_), .A2(new_n218_), .B(new_n114_), .Y(new_n219_));
  AND4x2_ASAP7_75t_R   g176(.A(new_n190_), .B(new_n195_), .C(new_n201_), .D(new_n219_), .Y(new_n220_));
  INVx1_ASAP7_75t_R    g177(.A(p27), .Y(new_n221_));
  AOI22x1_ASAP7_75t_R  g178(.A1(new_n179_), .A2(new_n220_), .B1(new_n221_), .B2(new_n219_), .Y(new_n222_));
  AOI21x1_ASAP7_75t_R  g179(.A1(p19), .A2(o1), .B(new_n137_), .Y(new_n223_));
  AND4x2_ASAP7_75t_R   g180(.A(new_n190_), .B(new_n195_), .C(new_n223_), .D(new_n201_), .Y(new_n224_));
  NOR2x1_ASAP7_75t_R   g181(.A(new_n139_), .B(new_n140_), .Y(new_n225_));
  AOI21x1_ASAP7_75t_R  g182(.A1(new_n224_), .A2(new_n179_), .B(new_n225_), .Y(new_n226_));
  NAND2x1_ASAP7_75t_R  g183(.A(p6), .B(new_n102_), .Y(new_n227_));
  AOI21x1_ASAP7_75t_R  g184(.A1(p20), .A2(o1), .B(new_n227_), .Y(new_n228_));
  AND4x2_ASAP7_75t_R   g185(.A(new_n190_), .B(new_n228_), .C(new_n201_), .D(p29), .Y(new_n229_));
  AOI21x1_ASAP7_75t_R  g186(.A1(new_n229_), .A2(new_n179_), .B(new_n131_), .Y(new_n230_));
  AND4x2_ASAP7_75t_R   g187(.A(new_n216_), .B(new_n222_), .C(new_n226_), .D(new_n230_), .Y(new_n231_));
  OR3x1_ASAP7_75t_R    g188(.A(new_n170_), .B(new_n64_), .C(new_n86_), .Y(new_n232_));
  AOI21x1_ASAP7_75t_R  g189(.A1(p34), .A2(o2), .B(new_n232_), .Y(new_n233_));
  AOI21x1_ASAP7_75t_R  g190(.A1(new_n212_), .A2(new_n231_), .B(new_n233_), .Y(o3));
  INVx1_ASAP7_75t_R    g191(.A(new_n212_), .Y(o4));
  NAND3x1_ASAP7_75t_R  g192(.A(new_n190_), .B(new_n195_), .C(new_n201_), .Y(new_n236_));
  INVx1_ASAP7_75t_R    g193(.A(new_n197_), .Y(new_n237_));
  AOI21x1_ASAP7_75t_R  g194(.A1(p32), .A2(new_n236_), .B(new_n237_), .Y(new_n238_));
  OAI21x1_ASAP7_75t_R  g195(.A1(new_n183_), .A2(new_n185_), .B(p23), .Y(new_n239_));
  OAI21x1_ASAP7_75t_R  g196(.A1(new_n183_), .A2(new_n185_), .B(p19), .Y(new_n240_));
  AOI22x1_ASAP7_75t_R  g197(.A1(new_n239_), .A2(new_n152_), .B1(new_n240_), .B2(new_n138_), .Y(new_n241_));
  AOI22x1_ASAP7_75t_R  g198(.A1(new_n219_), .A2(new_n221_), .B1(new_n213_), .B2(new_n166_), .Y(new_n242_));
  NAND2x1_ASAP7_75t_R  g199(.A(new_n148_), .B(new_n149_), .Y(new_n243_));
  OAI21x1_ASAP7_75t_R  g200(.A1(new_n243_), .A2(new_n217_), .B(p24), .Y(new_n244_));
  OAI21x1_ASAP7_75t_R  g201(.A1(new_n183_), .A2(new_n185_), .B(p25), .Y(new_n245_));
  INVx1_ASAP7_75t_R    g202(.A(new_n171_), .Y(new_n246_));
  AOI22x1_ASAP7_75t_R  g203(.A1(new_n244_), .A2(new_n176_), .B1(new_n245_), .B2(new_n246_), .Y(new_n247_));
  AO31x2_ASAP7_75t_R   g204(.A1(new_n241_), .A2(new_n242_), .A3(new_n247_), .B(new_n151_), .Y(new_n248_));
  AO31x2_ASAP7_75t_R   g205(.A1(new_n241_), .A2(new_n242_), .A3(new_n247_), .B(new_n132_), .Y(new_n249_));
  INVx1_ASAP7_75t_R    g206(.A(new_n206_), .Y(new_n250_));
  AOI21x1_ASAP7_75t_R  g207(.A1(new_n190_), .A2(new_n195_), .B(new_n132_), .Y(new_n251_));
  NOR2x1_ASAP7_75t_R   g208(.A(new_n250_), .B(new_n251_), .Y(new_n252_));
  AOI22x1_ASAP7_75t_R  g209(.A1(new_n238_), .A2(new_n248_), .B1(new_n249_), .B2(new_n252_), .Y(new_n253_));
  AO31x2_ASAP7_75t_R   g210(.A1(new_n241_), .A2(new_n242_), .A3(new_n247_), .B(new_n110_), .Y(new_n254_));
  OA21x2_ASAP7_75t_R   g211(.A1(new_n110_), .A2(new_n187_), .B(new_n127_), .Y(new_n255_));
  OA31x2_ASAP7_75t_R   g212(.A1(new_n178_), .A2(new_n154_), .A3(new_n168_), .B1(p29), .Y(new_n256_));
  OAI21x1_ASAP7_75t_R  g213(.A1(new_n128_), .A2(new_n136_), .B(new_n228_), .Y(new_n257_));
  AOI211x1_ASAP7_75t_R g214(.A1(new_n254_), .A2(new_n255_), .B(new_n256_), .C(new_n257_), .Y(new_n258_));
  NAND2x1_ASAP7_75t_R  g215(.A(new_n253_), .B(new_n258_), .Y(new_n259_));
  AO21x1_ASAP7_75t_R   g216(.A1(new_n202_), .A2(new_n179_), .B(new_n203_), .Y(new_n260_));
  AO21x1_ASAP7_75t_R   g217(.A1(new_n179_), .A2(new_n192_), .B(new_n193_), .Y(new_n261_));
  NOR2x1_ASAP7_75t_R   g218(.A(new_n260_), .B(new_n261_), .Y(new_n262_));
  AO21x1_ASAP7_75t_R   g219(.A1(new_n224_), .A2(new_n179_), .B(new_n225_), .Y(new_n263_));
  NAND3x1_ASAP7_75t_R  g220(.A(new_n263_), .B(new_n208_), .C(new_n211_), .Y(new_n264_));
  NAND3x1_ASAP7_75t_R  g221(.A(new_n259_), .B(new_n262_), .C(new_n264_), .Y(o5));
  OA21x2_ASAP7_75t_R   g222(.A1(new_n222_), .A2(new_n263_), .B(new_n208_), .Y(new_n266_));
  AOI21x1_ASAP7_75t_R  g223(.A1(new_n253_), .A2(new_n258_), .B(new_n261_), .Y(new_n267_));
  OAI21x1_ASAP7_75t_R  g224(.A1(new_n260_), .A2(new_n266_), .B(new_n267_), .Y(o6));
endmodule


