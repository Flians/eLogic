// Benchmark "/tmp/" written by ABC on Mon Oct 12 15:06:04 2026

module \/tmp/  ( 
    p15, p3, p29, p27, p34, p13, p12, p7, p32, p31, p21, p8, p4, p14, p30,
    p23, p25, p2, p26, p35, p16, p10, p28, p6, p33, p24, p1, p11, p5, p9,
    p0, p20, p17, p19, p22, p18,
    o0, o1, o2, o3, o4, o5, o6  );
  input  p15, p3, p29, p27, p34, p13, p12, p7, p32, p31, p21, p8, p4,
    p14, p30, p23, p25, p2, p26, p35, p16, p10, p28, p6, p33, p24, p1, p11,
    p5, p9, p0, p20, p17, p19, p22, p18;
  output o0, o1, o2, o3, o4, o5, o6;
  wire new_n44_, new_n45_, new_n46_, new_n47_, new_n48_, new_n49_, new_n50_,
    new_n51_, new_n52_, new_n53_, new_n54_, new_n55_, new_n56_, new_n57_,
    new_n58_, new_n59_, new_n61_, new_n62_, new_n63_, new_n64_, new_n65_,
    new_n66_, new_n67_, new_n68_, new_n69_, new_n70_, new_n71_, new_n72_,
    new_n73_, new_n74_, new_n75_, new_n76_, new_n77_, new_n78_, new_n79_,
    new_n80_, new_n81_, new_n82_, new_n83_, new_n84_, new_n85_, new_n86_,
    new_n87_, new_n88_, new_n89_, new_n90_, new_n91_, new_n92_, new_n93_,
    new_n94_, new_n95_, new_n96_, new_n97_, new_n98_, new_n99_, new_n100_,
    new_n101_, new_n102_, new_n103_, new_n104_, new_n105_, new_n106_,
    new_n107_, new_n108_, new_n109_, new_n110_, new_n112_, new_n113_,
    new_n114_, new_n115_, new_n116_, new_n117_, new_n118_, new_n119_,
    new_n120_, new_n121_, new_n122_, new_n123_, new_n124_, new_n125_,
    new_n126_, new_n127_, new_n128_, new_n129_, new_n130_, new_n131_,
    new_n132_, new_n133_, new_n134_, new_n135_, new_n136_, new_n137_,
    new_n138_, new_n139_, new_n140_, new_n141_, new_n142_, new_n143_,
    new_n144_, new_n145_, new_n146_, new_n147_, new_n148_, new_n149_,
    new_n150_, new_n151_, new_n152_, new_n153_, new_n154_, new_n155_,
    new_n156_, new_n157_, new_n158_, new_n159_, new_n160_, new_n161_,
    new_n162_, new_n163_, new_n164_, new_n165_, new_n166_, new_n167_,
    new_n168_, new_n169_, new_n170_, new_n171_, new_n172_, new_n173_,
    new_n174_, new_n175_, new_n176_, new_n178_, new_n179_, new_n180_,
    new_n181_, new_n182_, new_n183_, new_n184_, new_n185_, new_n186_,
    new_n187_, new_n188_, new_n189_, new_n190_, new_n191_, new_n192_,
    new_n193_, new_n194_, new_n195_, new_n196_, new_n197_, new_n198_,
    new_n199_, new_n200_, new_n201_, new_n202_, new_n203_, new_n204_,
    new_n205_, new_n206_, new_n207_, new_n208_, new_n209_, new_n210_,
    new_n211_, new_n212_, new_n213_, new_n214_, new_n215_, new_n216_,
    new_n217_, new_n218_, new_n219_, new_n220_, new_n221_, new_n222_,
    new_n223_, new_n224_, new_n225_, new_n226_, new_n227_, new_n228_,
    new_n229_, new_n230_, new_n231_, new_n232_, new_n233_, new_n234_,
    new_n235_, new_n236_, new_n237_, new_n238_, new_n239_, new_n240_,
    new_n241_, new_n242_, new_n244_, new_n245_, new_n247_, new_n248_,
    new_n249_, new_n250_, new_n251_, new_n252_, new_n253_, new_n254_,
    new_n255_, new_n256_, new_n257_, new_n258_, new_n259_, new_n260_,
    new_n261_, new_n262_, new_n263_, new_n264_, new_n265_, new_n266_,
    new_n267_, new_n268_, new_n270_, new_n271_, new_n272_;
  INVx1_ASAP7_75t_R    g000(.A(p16), .Y(new_n44_));
  INVx1_ASAP7_75t_R    g001(.A(p14), .Y(new_n45_));
  OAI22x1_ASAP7_75t_R  g002(.A1(p15), .A2(new_n44_), .B1(new_n45_), .B2(p13), .Y(new_n46_));
  INVx1_ASAP7_75t_R    g003(.A(p4), .Y(new_n47_));
  INVx1_ASAP7_75t_R    g004(.A(p12), .Y(new_n48_));
  OAI22x1_ASAP7_75t_R  g005(.A1(p3), .A2(new_n47_), .B1(new_n48_), .B2(p11), .Y(new_n49_));
  NOR2x1_ASAP7_75t_R   g006(.A(new_n46_), .B(new_n49_), .Y(new_n50_));
  INVx1_ASAP7_75t_R    g007(.A(p8), .Y(new_n51_));
  NOR2x1_ASAP7_75t_R   g008(.A(p7), .B(new_n51_), .Y(new_n52_));
  INVx1_ASAP7_75t_R    g009(.A(p10), .Y(new_n53_));
  INVx1_ASAP7_75t_R    g010(.A(p6), .Y(new_n54_));
  OAI22x1_ASAP7_75t_R  g011(.A1(new_n53_), .A2(p9), .B1(new_n54_), .B2(p5), .Y(new_n55_));
  NOR2x1_ASAP7_75t_R   g012(.A(new_n52_), .B(new_n55_), .Y(new_n56_));
  INVx1_ASAP7_75t_R    g013(.A(p1), .Y(new_n57_));
  INVx1_ASAP7_75t_R    g014(.A(p35), .Y(new_n58_));
  AOI22x1_ASAP7_75t_R  g015(.A1(p2), .A2(new_n57_), .B1(new_n58_), .B2(p0), .Y(new_n59_));
  NAND3x1_ASAP7_75t_R  g016(.A(new_n50_), .B(new_n56_), .C(new_n59_), .Y(o0));
  INVx1_ASAP7_75t_R    g017(.A(p9), .Y(new_n61_));
  INVx1_ASAP7_75t_R    g018(.A(p5), .Y(new_n62_));
  AOI22x1_ASAP7_75t_R  g019(.A1(p10), .A2(new_n61_), .B1(new_n62_), .B2(p6), .Y(new_n63_));
  INVx1_ASAP7_75t_R    g020(.A(p7), .Y(new_n64_));
  NAND2x1_ASAP7_75t_R  g021(.A(p8), .B(new_n64_), .Y(new_n65_));
  INVx1_ASAP7_75t_R    g022(.A(p3), .Y(new_n66_));
  NAND2x1_ASAP7_75t_R  g023(.A(p4), .B(new_n66_), .Y(new_n67_));
  AND3x1_ASAP7_75t_R   g024(.A(new_n63_), .B(new_n65_), .C(new_n67_), .Y(new_n68_));
  INVx1_ASAP7_75t_R    g025(.A(p2), .Y(new_n69_));
  INVx1_ASAP7_75t_R    g026(.A(p0), .Y(new_n70_));
  OAI22x1_ASAP7_75t_R  g027(.A1(new_n69_), .A2(p1), .B1(new_n70_), .B2(p35), .Y(new_n71_));
  NOR3x1_ASAP7_75t_R   g028(.A(new_n46_), .B(new_n71_), .C(new_n49_), .Y(new_n72_));
  AOI21x1_ASAP7_75t_R  g029(.A1(new_n68_), .A2(new_n72_), .B(new_n62_), .Y(new_n73_));
  NOR2x1_ASAP7_75t_R   g030(.A(p20), .B(new_n54_), .Y(new_n74_));
  INVx1_ASAP7_75t_R    g031(.A(new_n74_), .Y(new_n75_));
  INVx1_ASAP7_75t_R    g032(.A(p15), .Y(new_n76_));
  INVx1_ASAP7_75t_R    g033(.A(p13), .Y(new_n77_));
  AOI22x1_ASAP7_75t_R  g034(.A1(new_n76_), .A2(p16), .B1(new_n77_), .B2(p14), .Y(new_n78_));
  INVx1_ASAP7_75t_R    g035(.A(p11), .Y(new_n79_));
  AOI22x1_ASAP7_75t_R  g036(.A1(new_n66_), .A2(p4), .B1(new_n79_), .B2(p12), .Y(new_n80_));
  AO31x2_ASAP7_75t_R   g037(.A1(new_n78_), .A2(new_n59_), .A3(new_n80_), .B(new_n61_), .Y(new_n81_));
  AO21x1_ASAP7_75t_R   g038(.A1(new_n65_), .A2(new_n63_), .B(new_n61_), .Y(new_n82_));
  NOR2x1_ASAP7_75t_R   g039(.A(p22), .B(new_n53_), .Y(new_n83_));
  NAND3x1_ASAP7_75t_R  g040(.A(new_n81_), .B(new_n82_), .C(new_n83_), .Y(new_n84_));
  OAI21x1_ASAP7_75t_R  g041(.A1(new_n73_), .A2(new_n75_), .B(new_n84_), .Y(new_n85_));
  AOI21x1_ASAP7_75t_R  g042(.A1(new_n68_), .A2(new_n72_), .B(new_n76_), .Y(new_n86_));
  NOR2x1_ASAP7_75t_R   g043(.A(p25), .B(new_n44_), .Y(new_n87_));
  INVx1_ASAP7_75t_R    g044(.A(new_n87_), .Y(new_n88_));
  AOI21x1_ASAP7_75t_R  g045(.A1(new_n68_), .A2(new_n72_), .B(new_n64_), .Y(new_n89_));
  NOR2x1_ASAP7_75t_R   g046(.A(p21), .B(new_n51_), .Y(new_n90_));
  INVx1_ASAP7_75t_R    g047(.A(new_n90_), .Y(new_n91_));
  OAI22x1_ASAP7_75t_R  g048(.A1(new_n86_), .A2(new_n88_), .B1(new_n89_), .B2(new_n91_), .Y(new_n92_));
  NOR2x1_ASAP7_75t_R   g049(.A(new_n85_), .B(new_n92_), .Y(new_n93_));
  NAND3x1_ASAP7_75t_R  g050(.A(new_n63_), .B(new_n65_), .C(new_n67_), .Y(new_n94_));
  NAND3x1_ASAP7_75t_R  g051(.A(new_n78_), .B(new_n59_), .C(new_n80_), .Y(new_n95_));
  OAI21x1_ASAP7_75t_R  g052(.A1(new_n94_), .A2(new_n95_), .B(p35), .Y(new_n96_));
  NOR2x1_ASAP7_75t_R   g053(.A(p17), .B(new_n70_), .Y(new_n97_));
  OAI21x1_ASAP7_75t_R  g054(.A1(new_n94_), .A2(new_n95_), .B(p13), .Y(new_n98_));
  NOR2x1_ASAP7_75t_R   g055(.A(p24), .B(new_n45_), .Y(new_n99_));
  AOI22x1_ASAP7_75t_R  g056(.A1(new_n96_), .A2(new_n97_), .B1(new_n98_), .B2(new_n99_), .Y(new_n100_));
  OAI21x1_ASAP7_75t_R  g057(.A1(new_n94_), .A2(new_n95_), .B(p11), .Y(new_n101_));
  NOR2x1_ASAP7_75t_R   g058(.A(p23), .B(new_n48_), .Y(new_n102_));
  NOR2x1_ASAP7_75t_R   g059(.A(p19), .B(new_n47_), .Y(new_n103_));
  INVx1_ASAP7_75t_R    g060(.A(p19), .Y(new_n104_));
  AND3x1_ASAP7_75t_R   g061(.A(new_n66_), .B(new_n104_), .C(p4), .Y(new_n105_));
  AO31x2_ASAP7_75t_R   g062(.A1(new_n72_), .A2(new_n68_), .A3(new_n103_), .B(new_n105_), .Y(new_n106_));
  NOR2x1_ASAP7_75t_R   g063(.A(p18), .B(new_n69_), .Y(new_n107_));
  INVx1_ASAP7_75t_R    g064(.A(new_n107_), .Y(new_n108_));
  AOI21x1_ASAP7_75t_R  g065(.A1(p1), .A2(o0), .B(new_n108_), .Y(new_n109_));
  AOI211x1_ASAP7_75t_R g066(.A1(new_n101_), .A2(new_n102_), .B(new_n106_), .C(new_n109_), .Y(new_n110_));
  NAND3x1_ASAP7_75t_R  g067(.A(new_n93_), .B(new_n100_), .C(new_n110_), .Y(o1));
  INVx1_ASAP7_75t_R    g068(.A(p30), .Y(new_n112_));
  AOI21x1_ASAP7_75t_R  g069(.A1(new_n68_), .A2(new_n72_), .B(new_n58_), .Y(new_n113_));
  INVx1_ASAP7_75t_R    g070(.A(new_n97_), .Y(new_n114_));
  AOI21x1_ASAP7_75t_R  g071(.A1(new_n68_), .A2(new_n72_), .B(new_n77_), .Y(new_n115_));
  INVx1_ASAP7_75t_R    g072(.A(new_n99_), .Y(new_n116_));
  OAI22x1_ASAP7_75t_R  g073(.A1(new_n113_), .A2(new_n114_), .B1(new_n115_), .B2(new_n116_), .Y(new_n117_));
  NOR3x1_ASAP7_75t_R   g074(.A(new_n92_), .B(new_n117_), .C(new_n85_), .Y(new_n118_));
  OAI21x1_ASAP7_75t_R  g075(.A1(new_n51_), .A2(o0), .B(new_n65_), .Y(new_n119_));
  NOR2x1_ASAP7_75t_R   g076(.A(new_n91_), .B(new_n89_), .Y(new_n120_));
  AO31x2_ASAP7_75t_R   g077(.A1(new_n118_), .A2(new_n119_), .A3(new_n110_), .B(new_n120_), .Y(new_n121_));
  OAI21x1_ASAP7_75t_R  g078(.A1(new_n94_), .A2(new_n95_), .B(p15), .Y(new_n122_));
  OAI21x1_ASAP7_75t_R  g079(.A1(new_n94_), .A2(new_n95_), .B(p7), .Y(new_n123_));
  AOI22x1_ASAP7_75t_R  g080(.A1(new_n122_), .A2(new_n87_), .B1(new_n123_), .B2(new_n90_), .Y(new_n124_));
  OAI21x1_ASAP7_75t_R  g081(.A1(new_n94_), .A2(new_n95_), .B(p5), .Y(new_n125_));
  AOI21x1_ASAP7_75t_R  g082(.A1(new_n65_), .A2(new_n63_), .B(new_n61_), .Y(new_n126_));
  AOI21x1_ASAP7_75t_R  g083(.A1(p9), .A2(new_n95_), .B(new_n126_), .Y(new_n127_));
  AOI22x1_ASAP7_75t_R  g084(.A1(new_n125_), .A2(new_n74_), .B1(new_n127_), .B2(new_n83_), .Y(new_n128_));
  INVx1_ASAP7_75t_R    g085(.A(p22), .Y(new_n129_));
  AO31x2_ASAP7_75t_R   g086(.A1(new_n124_), .A2(new_n100_), .A3(new_n128_), .B(new_n129_), .Y(new_n130_));
  INVx1_ASAP7_75t_R    g087(.A(new_n106_), .Y(new_n131_));
  OAI21x1_ASAP7_75t_R  g088(.A1(new_n94_), .A2(new_n95_), .B(p1), .Y(new_n132_));
  AOI22x1_ASAP7_75t_R  g089(.A1(new_n132_), .A2(new_n107_), .B1(new_n101_), .B2(new_n102_), .Y(new_n133_));
  AO21x1_ASAP7_75t_R   g090(.A1(new_n131_), .A2(new_n133_), .B(new_n129_), .Y(new_n134_));
  INVx1_ASAP7_75t_R    g091(.A(p31), .Y(new_n135_));
  AND3x1_ASAP7_75t_R   g092(.A(new_n127_), .B(new_n135_), .C(p10), .Y(new_n136_));
  AND3x1_ASAP7_75t_R   g093(.A(new_n130_), .B(new_n134_), .C(new_n136_), .Y(new_n137_));
  INVx1_ASAP7_75t_R    g094(.A(p29), .Y(new_n138_));
  AND3x1_ASAP7_75t_R   g095(.A(new_n125_), .B(new_n138_), .C(p6), .Y(new_n139_));
  INVx1_ASAP7_75t_R    g096(.A(new_n139_), .Y(new_n140_));
  AOI21x1_ASAP7_75t_R  g097(.A1(p20), .A2(o1), .B(new_n140_), .Y(new_n141_));
  AOI211x1_ASAP7_75t_R g098(.A1(new_n112_), .A2(new_n121_), .B(new_n137_), .C(new_n141_), .Y(new_n142_));
  INVx1_ASAP7_75t_R    g099(.A(p25), .Y(new_n143_));
  AOI21x1_ASAP7_75t_R  g100(.A1(new_n110_), .A2(new_n118_), .B(new_n143_), .Y(new_n144_));
  INVx1_ASAP7_75t_R    g101(.A(p34), .Y(new_n145_));
  AND3x1_ASAP7_75t_R   g102(.A(new_n122_), .B(new_n145_), .C(p16), .Y(new_n146_));
  INVx1_ASAP7_75t_R    g103(.A(new_n146_), .Y(new_n147_));
  INVx1_ASAP7_75t_R    g104(.A(p24), .Y(new_n148_));
  AOI21x1_ASAP7_75t_R  g105(.A1(new_n110_), .A2(new_n118_), .B(new_n148_), .Y(new_n149_));
  INVx1_ASAP7_75t_R    g106(.A(p33), .Y(new_n150_));
  AND3x1_ASAP7_75t_R   g107(.A(new_n98_), .B(p14), .C(new_n150_), .Y(new_n151_));
  INVx1_ASAP7_75t_R    g108(.A(new_n151_), .Y(new_n152_));
  OAI22x1_ASAP7_75t_R  g109(.A1(new_n144_), .A2(new_n147_), .B1(new_n149_), .B2(new_n152_), .Y(new_n153_));
  AOI21x1_ASAP7_75t_R  g110(.A1(new_n110_), .A2(new_n118_), .B(new_n104_), .Y(new_n154_));
  OAI21x1_ASAP7_75t_R  g111(.A1(new_n94_), .A2(new_n95_), .B(new_n67_), .Y(new_n155_));
  NAND2x1_ASAP7_75t_R  g112(.A(p4), .B(new_n155_), .Y(new_n156_));
  NOR2x1_ASAP7_75t_R   g113(.A(p28), .B(new_n156_), .Y(new_n157_));
  INVx1_ASAP7_75t_R    g114(.A(new_n157_), .Y(new_n158_));
  INVx1_ASAP7_75t_R    g115(.A(p23), .Y(new_n159_));
  AO31x2_ASAP7_75t_R   g116(.A1(new_n124_), .A2(new_n100_), .A3(new_n128_), .B(new_n159_), .Y(new_n160_));
  AO21x1_ASAP7_75t_R   g117(.A1(new_n131_), .A2(new_n133_), .B(new_n159_), .Y(new_n161_));
  INVx1_ASAP7_75t_R    g118(.A(p32), .Y(new_n162_));
  AND3x1_ASAP7_75t_R   g119(.A(new_n101_), .B(p12), .C(new_n162_), .Y(new_n163_));
  NAND3x1_ASAP7_75t_R  g120(.A(new_n160_), .B(new_n161_), .C(new_n163_), .Y(new_n164_));
  OAI21x1_ASAP7_75t_R  g121(.A1(new_n154_), .A2(new_n158_), .B(new_n164_), .Y(new_n165_));
  AOI21x1_ASAP7_75t_R  g122(.A1(p1), .A2(o0), .B(new_n69_), .Y(new_n166_));
  AND3x1_ASAP7_75t_R   g123(.A(new_n133_), .B(new_n131_), .C(new_n166_), .Y(new_n167_));
  AOI21x1_ASAP7_75t_R  g124(.A1(new_n167_), .A2(new_n118_), .B(new_n109_), .Y(new_n168_));
  INVx1_ASAP7_75t_R    g125(.A(p17), .Y(new_n169_));
  AO31x2_ASAP7_75t_R   g126(.A1(new_n124_), .A2(new_n100_), .A3(new_n128_), .B(new_n169_), .Y(new_n170_));
  AO21x1_ASAP7_75t_R   g127(.A1(new_n131_), .A2(new_n133_), .B(new_n169_), .Y(new_n171_));
  INVx1_ASAP7_75t_R    g128(.A(p26), .Y(new_n172_));
  AND3x1_ASAP7_75t_R   g129(.A(new_n96_), .B(new_n172_), .C(p0), .Y(new_n173_));
  NAND3x1_ASAP7_75t_R  g130(.A(new_n170_), .B(new_n171_), .C(new_n173_), .Y(new_n174_));
  OAI21x1_ASAP7_75t_R  g131(.A1(p27), .A2(new_n168_), .B(new_n174_), .Y(new_n175_));
  NOR3x1_ASAP7_75t_R   g132(.A(new_n153_), .B(new_n165_), .C(new_n175_), .Y(new_n176_));
  NAND2x1_ASAP7_75t_R  g133(.A(new_n142_), .B(new_n176_), .Y(o2));
  NAND2x1_ASAP7_75t_R  g134(.A(new_n128_), .B(new_n124_), .Y(new_n178_));
  AOI22x1_ASAP7_75t_R  g135(.A1(new_n98_), .A2(new_n99_), .B1(new_n101_), .B2(new_n102_), .Y(new_n179_));
  AOI22x1_ASAP7_75t_R  g136(.A1(new_n132_), .A2(new_n107_), .B1(new_n155_), .B2(new_n103_), .Y(new_n180_));
  NAND2x1_ASAP7_75t_R  g137(.A(new_n97_), .B(new_n96_), .Y(new_n181_));
  NAND3x1_ASAP7_75t_R  g138(.A(new_n179_), .B(new_n180_), .C(new_n181_), .Y(new_n182_));
  OAI21x1_ASAP7_75t_R  g139(.A1(new_n178_), .A2(new_n182_), .B(p25), .Y(new_n183_));
  AND3x1_ASAP7_75t_R   g140(.A(new_n183_), .B(p16), .C(new_n122_), .Y(new_n184_));
  OA21x2_ASAP7_75t_R   g141(.A1(new_n145_), .A2(new_n142_), .B(new_n184_), .Y(new_n185_));
  OAI21x1_ASAP7_75t_R  g142(.A1(new_n145_), .A2(new_n176_), .B(new_n185_), .Y(new_n186_));
  INVx1_ASAP7_75t_R    g143(.A(new_n186_), .Y(new_n187_));
  INVx1_ASAP7_75t_R    g144(.A(p20), .Y(new_n188_));
  AOI21x1_ASAP7_75t_R  g145(.A1(new_n110_), .A2(new_n118_), .B(new_n188_), .Y(new_n189_));
  NAND3x1_ASAP7_75t_R  g146(.A(new_n130_), .B(new_n134_), .C(new_n136_), .Y(new_n190_));
  OAI21x1_ASAP7_75t_R  g147(.A1(new_n189_), .A2(new_n140_), .B(new_n190_), .Y(new_n191_));
  INVx1_ASAP7_75t_R    g148(.A(p21), .Y(new_n192_));
  NOR2x1_ASAP7_75t_R   g149(.A(new_n178_), .B(new_n182_), .Y(new_n193_));
  AND3x1_ASAP7_75t_R   g150(.A(new_n123_), .B(p8), .C(new_n112_), .Y(new_n194_));
  OA21x2_ASAP7_75t_R   g151(.A1(new_n192_), .A2(new_n193_), .B(new_n194_), .Y(new_n195_));
  NOR2x1_ASAP7_75t_R   g152(.A(new_n70_), .B(new_n113_), .Y(new_n196_));
  OAI21x1_ASAP7_75t_R  g153(.A1(new_n178_), .A2(new_n182_), .B(p17), .Y(new_n197_));
  NAND2x1_ASAP7_75t_R  g154(.A(new_n196_), .B(new_n197_), .Y(new_n198_));
  NOR3x1_ASAP7_75t_R   g155(.A(new_n191_), .B(new_n195_), .C(new_n198_), .Y(new_n199_));
  AND3x1_ASAP7_75t_R   g156(.A(new_n170_), .B(new_n171_), .C(new_n173_), .Y(new_n200_));
  AOI21x1_ASAP7_75t_R  g157(.A1(new_n199_), .A2(new_n176_), .B(new_n200_), .Y(new_n201_));
  NOR3x1_ASAP7_75t_R   g158(.A(new_n191_), .B(new_n195_), .C(new_n168_), .Y(new_n202_));
  NOR2x1_ASAP7_75t_R   g159(.A(p27), .B(new_n168_), .Y(new_n203_));
  AOI21x1_ASAP7_75t_R  g160(.A1(new_n202_), .A2(new_n176_), .B(new_n203_), .Y(new_n204_));
  AO21x1_ASAP7_75t_R   g161(.A1(p19), .A2(o1), .B(new_n156_), .Y(new_n205_));
  NOR3x1_ASAP7_75t_R   g162(.A(new_n191_), .B(new_n195_), .C(new_n205_), .Y(new_n206_));
  AOI21x1_ASAP7_75t_R  g163(.A1(p19), .A2(o1), .B(new_n158_), .Y(new_n207_));
  AOI21x1_ASAP7_75t_R  g164(.A1(new_n206_), .A2(new_n176_), .B(new_n207_), .Y(new_n208_));
  NOR2x1_ASAP7_75t_R   g165(.A(new_n54_), .B(new_n73_), .Y(new_n209_));
  OAI21x1_ASAP7_75t_R  g166(.A1(new_n178_), .A2(new_n182_), .B(p20), .Y(new_n210_));
  NAND2x1_ASAP7_75t_R  g167(.A(new_n209_), .B(new_n210_), .Y(new_n211_));
  NOR3x1_ASAP7_75t_R   g168(.A(new_n191_), .B(new_n195_), .C(new_n211_), .Y(new_n212_));
  AOI21x1_ASAP7_75t_R  g169(.A1(new_n212_), .A2(new_n176_), .B(new_n141_), .Y(new_n213_));
  AND4x2_ASAP7_75t_R   g170(.A(new_n201_), .B(new_n204_), .C(new_n208_), .D(new_n213_), .Y(new_n214_));
  OAI21x1_ASAP7_75t_R  g171(.A1(new_n178_), .A2(new_n182_), .B(p24), .Y(new_n215_));
  AND3x1_ASAP7_75t_R   g172(.A(new_n160_), .B(new_n161_), .C(new_n163_), .Y(new_n216_));
  AOI211x1_ASAP7_75t_R g173(.A1(new_n215_), .A2(new_n151_), .B(new_n216_), .C(new_n200_), .Y(new_n217_));
  INVx1_ASAP7_75t_R    g174(.A(p27), .Y(new_n218_));
  NAND3x1_ASAP7_75t_R  g175(.A(new_n124_), .B(new_n100_), .C(new_n128_), .Y(new_n219_));
  NAND3x1_ASAP7_75t_R  g176(.A(new_n133_), .B(new_n131_), .C(new_n166_), .Y(new_n220_));
  INVx1_ASAP7_75t_R    g177(.A(new_n166_), .Y(new_n221_));
  OAI22x1_ASAP7_75t_R  g178(.A1(new_n219_), .A2(new_n220_), .B1(p18), .B2(new_n221_), .Y(new_n222_));
  AOI21x1_ASAP7_75t_R  g179(.A1(p25), .A2(o1), .B(new_n147_), .Y(new_n223_));
  AOI211x1_ASAP7_75t_R g180(.A1(new_n218_), .A2(new_n222_), .B(new_n223_), .C(new_n207_), .Y(new_n224_));
  AOI21x1_ASAP7_75t_R  g181(.A1(new_n217_), .A2(new_n224_), .B(new_n135_), .Y(new_n225_));
  AND3x1_ASAP7_75t_R   g182(.A(new_n81_), .B(p10), .C(new_n82_), .Y(new_n226_));
  AND3x1_ASAP7_75t_R   g183(.A(new_n130_), .B(new_n226_), .C(new_n134_), .Y(new_n227_));
  OAI21x1_ASAP7_75t_R  g184(.A1(new_n135_), .A2(new_n142_), .B(new_n227_), .Y(new_n228_));
  OA31x2_ASAP7_75t_R   g185(.A1(new_n165_), .A2(new_n175_), .A3(new_n153_), .B1(p30), .Y(new_n229_));
  NAND2x1_ASAP7_75t_R  g186(.A(new_n139_), .B(new_n210_), .Y(new_n230_));
  AND3x1_ASAP7_75t_R   g187(.A(new_n230_), .B(new_n121_), .C(new_n190_), .Y(new_n231_));
  NOR2x1_ASAP7_75t_R   g188(.A(new_n195_), .B(new_n231_), .Y(new_n232_));
  OAI22x1_ASAP7_75t_R  g189(.A1(new_n225_), .A2(new_n228_), .B1(new_n229_), .B2(new_n232_), .Y(new_n233_));
  AOI21x1_ASAP7_75t_R  g190(.A1(new_n217_), .A2(new_n224_), .B(new_n150_), .Y(new_n234_));
  AND3x1_ASAP7_75t_R   g191(.A(new_n215_), .B(p14), .C(new_n98_), .Y(new_n235_));
  OAI21x1_ASAP7_75t_R  g192(.A1(new_n150_), .A2(new_n142_), .B(new_n235_), .Y(new_n236_));
  AND2x2_ASAP7_75t_R   g193(.A(p12), .B(new_n101_), .Y(new_n237_));
  AND3x1_ASAP7_75t_R   g194(.A(new_n160_), .B(new_n161_), .C(new_n237_), .Y(new_n238_));
  OAI21x1_ASAP7_75t_R  g195(.A1(new_n162_), .A2(new_n142_), .B(new_n238_), .Y(new_n239_));
  OA31x2_ASAP7_75t_R   g196(.A1(new_n165_), .A2(new_n175_), .A3(new_n153_), .B1(p32), .Y(new_n240_));
  OAI22x1_ASAP7_75t_R  g197(.A1(new_n234_), .A2(new_n236_), .B1(new_n239_), .B2(new_n240_), .Y(new_n241_));
  OAI21x1_ASAP7_75t_R  g198(.A1(new_n233_), .A2(new_n241_), .B(new_n186_), .Y(new_n242_));
  OAI21x1_ASAP7_75t_R  g199(.A1(new_n187_), .A2(new_n214_), .B(new_n242_), .Y(o3));
  NOR2x1_ASAP7_75t_R   g200(.A(new_n236_), .B(new_n234_), .Y(new_n244_));
  NOR2x1_ASAP7_75t_R   g201(.A(new_n240_), .B(new_n239_), .Y(new_n245_));
  OR3x1_ASAP7_75t_R    g202(.A(new_n233_), .B(new_n244_), .C(new_n245_), .Y(o4));
  AO31x2_ASAP7_75t_R   g203(.A1(new_n121_), .A2(new_n230_), .A3(new_n190_), .B(new_n195_), .Y(new_n247_));
  AOI22x1_ASAP7_75t_R  g204(.A1(new_n183_), .A2(new_n146_), .B1(new_n215_), .B2(new_n151_), .Y(new_n248_));
  OAI21x1_ASAP7_75t_R  g205(.A1(new_n178_), .A2(new_n182_), .B(p19), .Y(new_n249_));
  OAI21x1_ASAP7_75t_R  g206(.A1(new_n178_), .A2(new_n182_), .B(p23), .Y(new_n250_));
  AOI22x1_ASAP7_75t_R  g207(.A1(new_n249_), .A2(new_n157_), .B1(new_n250_), .B2(new_n163_), .Y(new_n251_));
  AOI22x1_ASAP7_75t_R  g208(.A1(new_n222_), .A2(new_n218_), .B1(new_n197_), .B2(new_n173_), .Y(new_n252_));
  AO31x2_ASAP7_75t_R   g209(.A1(new_n248_), .A2(new_n251_), .A3(new_n252_), .B(new_n112_), .Y(new_n253_));
  OA31x2_ASAP7_75t_R   g210(.A1(new_n165_), .A2(new_n175_), .A3(new_n153_), .B1(p29), .Y(new_n254_));
  INVx1_ASAP7_75t_R    g211(.A(new_n211_), .Y(new_n255_));
  OAI21x1_ASAP7_75t_R  g212(.A1(new_n138_), .A2(new_n142_), .B(new_n255_), .Y(new_n256_));
  AOI211x1_ASAP7_75t_R g213(.A1(new_n247_), .A2(new_n253_), .B(new_n254_), .C(new_n256_), .Y(new_n257_));
  OAI21x1_ASAP7_75t_R  g214(.A1(new_n192_), .A2(new_n193_), .B(new_n194_), .Y(new_n258_));
  NAND3x1_ASAP7_75t_R  g215(.A(new_n258_), .B(new_n230_), .C(new_n190_), .Y(new_n259_));
  INVx1_ASAP7_75t_R    g216(.A(new_n238_), .Y(new_n260_));
  AOI21x1_ASAP7_75t_R  g217(.A1(p32), .A2(new_n259_), .B(new_n260_), .Y(new_n261_));
  AO31x2_ASAP7_75t_R   g218(.A1(new_n248_), .A2(new_n251_), .A3(new_n252_), .B(new_n162_), .Y(new_n262_));
  AO31x2_ASAP7_75t_R   g219(.A1(new_n248_), .A2(new_n251_), .A3(new_n252_), .B(new_n135_), .Y(new_n263_));
  INVx1_ASAP7_75t_R    g220(.A(new_n227_), .Y(new_n264_));
  AOI21x1_ASAP7_75t_R  g221(.A1(new_n230_), .A2(new_n258_), .B(new_n135_), .Y(new_n265_));
  NOR2x1_ASAP7_75t_R   g222(.A(new_n264_), .B(new_n265_), .Y(new_n266_));
  AOI22x1_ASAP7_75t_R  g223(.A1(new_n261_), .A2(new_n262_), .B1(new_n263_), .B2(new_n266_), .Y(new_n267_));
  AOI21x1_ASAP7_75t_R  g224(.A1(new_n257_), .A2(new_n267_), .B(new_n241_), .Y(new_n268_));
  OAI21x1_ASAP7_75t_R  g225(.A1(new_n208_), .A2(new_n233_), .B(new_n268_), .Y(o5));
  AO21x1_ASAP7_75t_R   g226(.A1(new_n202_), .A2(new_n176_), .B(new_n203_), .Y(new_n270_));
  AOI22x1_ASAP7_75t_R  g227(.A1(new_n270_), .A2(new_n208_), .B1(new_n263_), .B2(new_n266_), .Y(new_n271_));
  AOI21x1_ASAP7_75t_R  g228(.A1(new_n257_), .A2(new_n267_), .B(new_n244_), .Y(new_n272_));
  OAI21x1_ASAP7_75t_R  g229(.A1(new_n245_), .A2(new_n271_), .B(new_n272_), .Y(o6));
endmodule


