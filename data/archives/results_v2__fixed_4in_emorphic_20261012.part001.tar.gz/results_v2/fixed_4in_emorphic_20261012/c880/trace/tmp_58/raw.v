// Benchmark "/tmp/" written by ABC on Mon Oct 12 15:08:00 2026

module \/tmp/  ( 
    p43, p44, p40, p7, p52, p4, p23, p32, p25, p13, p10, p29, p8, p21, p36,
    p56, p1, p20, p46, p6, p18, p57, p5, p22, p0, p35, p54, p30, p59, p19,
    p28, p53, p26, p14, p33, p31, p42, p37, p34, p2, p24, p17, p9, p11,
    p55, p51, p49, p15, p50, p38, p41, p45, p39, p16, p12, p3, p58, p48,
    p47, p27,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25  );
  input  p43, p44, p40, p7, p52, p4, p23, p32, p25, p13, p10, p29, p8,
    p21, p36, p56, p1, p20, p46, p6, p18, p57, p5, p22, p0, p35, p54, p30,
    p59, p19, p28, p53, p26, p14, p33, p31, p42, p37, p34, p2, p24, p17,
    p9, p11, p55, p51, p49, p15, p50, p38, p41, p45, p39, p16, p12, p3,
    p58, p48, p47, p27;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25;
  wire new_n87_, new_n88_, new_n90_, new_n91_, new_n92_, new_n94_, new_n97_,
    new_n98_, new_n99_, new_n101_, new_n102_, new_n103_, new_n111_,
    new_n112_, new_n113_, new_n115_, new_n116_, new_n119_, new_n120_,
    new_n121_, new_n122_, new_n123_, new_n124_, new_n125_, new_n126_,
    new_n127_, new_n129_, new_n130_, new_n131_, new_n132_, new_n133_,
    new_n134_, new_n135_, new_n136_, new_n137_, new_n139_, new_n140_,
    new_n141_, new_n142_, new_n143_, new_n144_, new_n145_, new_n146_,
    new_n147_, new_n148_, new_n149_, new_n150_, new_n151_, new_n152_,
    new_n153_, new_n154_, new_n155_, new_n156_, new_n157_, new_n158_,
    new_n159_, new_n160_, new_n161_, new_n162_, new_n163_, new_n164_,
    new_n165_, new_n166_, new_n167_, new_n168_, new_n169_, new_n170_,
    new_n171_, new_n172_, new_n173_, new_n174_, new_n175_, new_n177_,
    new_n178_, new_n179_, new_n180_, new_n181_, new_n182_, new_n183_,
    new_n184_, new_n185_, new_n186_, new_n187_, new_n188_, new_n189_,
    new_n190_, new_n191_, new_n192_, new_n193_, new_n194_, new_n195_,
    new_n196_, new_n197_, new_n198_, new_n199_, new_n200_, new_n201_,
    new_n202_, new_n203_, new_n204_, new_n205_, new_n206_, new_n207_,
    new_n208_, new_n209_, new_n210_, new_n211_, new_n212_, new_n213_,
    new_n214_, new_n215_, new_n216_, new_n217_, new_n218_, new_n219_,
    new_n220_, new_n221_, new_n222_, new_n223_, new_n224_, new_n225_,
    new_n226_, new_n227_, new_n228_, new_n229_, new_n230_, new_n231_,
    new_n232_, new_n233_, new_n235_, new_n236_, new_n237_, new_n238_,
    new_n239_, new_n240_, new_n241_, new_n242_, new_n243_, new_n244_,
    new_n245_, new_n246_, new_n247_, new_n248_, new_n249_, new_n250_,
    new_n251_, new_n253_, new_n254_, new_n255_, new_n256_, new_n257_,
    new_n258_, new_n259_, new_n261_, new_n262_, new_n263_, new_n264_,
    new_n265_, new_n266_, new_n267_, new_n268_, new_n269_, new_n270_,
    new_n271_, new_n272_, new_n273_, new_n274_, new_n275_, new_n276_,
    new_n277_, new_n278_, new_n279_, new_n280_, new_n281_, new_n282_,
    new_n283_, new_n284_, new_n285_, new_n286_, new_n287_, new_n288_,
    new_n289_, new_n290_, new_n291_, new_n292_, new_n293_, new_n294_,
    new_n295_, new_n296_, new_n297_, new_n298_, new_n299_, new_n300_,
    new_n301_, new_n302_, new_n303_, new_n304_, new_n305_, new_n306_,
    new_n307_, new_n308_, new_n309_, new_n310_, new_n311_, new_n312_,
    new_n313_, new_n315_, new_n316_, new_n317_, new_n318_, new_n319_,
    new_n320_, new_n321_, new_n322_, new_n323_, new_n324_, new_n325_,
    new_n326_, new_n327_, new_n328_, new_n329_, new_n330_, new_n332_,
    new_n333_, new_n334_, new_n335_, new_n336_, new_n337_, new_n338_,
    new_n339_, new_n340_, new_n341_, new_n342_, new_n343_, new_n344_,
    new_n346_, new_n347_, new_n348_, new_n349_, new_n350_, new_n351_,
    new_n352_, new_n353_, new_n354_, new_n355_, new_n356_, new_n357_,
    new_n358_, new_n359_, new_n360_, new_n361_, new_n362_, new_n364_,
    new_n365_, new_n366_, new_n367_, new_n368_, new_n369_, new_n370_,
    new_n371_, new_n372_, new_n373_, new_n374_, new_n375_;
  INVx1_ASAP7_75t_R    g000(.A(p59), .Y(new_n87_));
  NAND2x1_ASAP7_75t_R  g001(.A(p1), .B(p0), .Y(new_n88_));
  OR2x4_ASAP7_75t_R    g002(.A(new_n87_), .B(new_n88_), .Y(o0));
  INVx1_ASAP7_75t_R    g003(.A(p1), .Y(new_n90_));
  INVx1_ASAP7_75t_R    g004(.A(p2), .Y(new_n91_));
  INVx1_ASAP7_75t_R    g005(.A(p3), .Y(new_n92_));
  OR3x1_ASAP7_75t_R    g006(.A(new_n90_), .B(new_n91_), .C(new_n92_), .Y(o1));
  AND3x1_ASAP7_75t_R   g007(.A(p1), .B(p59), .C(p3), .Y(new_n94_));
  INVx1_ASAP7_75t_R    g008(.A(new_n94_), .Y(o2));
  NAND2x1_ASAP7_75t_R  g009(.A(p4), .B(p5), .Y(o3));
  NAND2x1_ASAP7_75t_R  g010(.A(p8), .B(p9), .Y(new_n97_));
  INVx1_ASAP7_75t_R    g011(.A(p7), .Y(new_n98_));
  INVx1_ASAP7_75t_R    g012(.A(p6), .Y(new_n99_));
  OR3x1_ASAP7_75t_R    g013(.A(new_n97_), .B(new_n98_), .C(new_n99_), .Y(o4));
  AND2x2_ASAP7_75t_R   g014(.A(p7), .B(p6), .Y(new_n101_));
  NAND2x1_ASAP7_75t_R  g015(.A(p10), .B(p9), .Y(new_n102_));
  INVx1_ASAP7_75t_R    g016(.A(new_n102_), .Y(new_n103_));
  AND3x1_ASAP7_75t_R   g017(.A(o2), .B(new_n101_), .C(new_n103_), .Y(o5));
  AND3x1_ASAP7_75t_R   g018(.A(p0), .B(p2), .C(p11), .Y(o6));
  AND3x1_ASAP7_75t_R   g019(.A(p2), .B(p11), .C(p3), .Y(o7));
  AND3x1_ASAP7_75t_R   g020(.A(p59), .B(p11), .C(p3), .Y(o8));
  OAI21x1_ASAP7_75t_R  g021(.A1(p13), .A2(p14), .B(p12), .Y(o9));
  AND3x1_ASAP7_75t_R   g022(.A(new_n103_), .B(new_n94_), .C(new_n101_), .Y(o10));
  NAND3x1_ASAP7_75t_R  g023(.A(p10), .B(p9), .C(p15), .Y(o11));
  INVx1_ASAP7_75t_R    g024(.A(p16), .Y(new_n111_));
  OR3x1_ASAP7_75t_R    g025(.A(new_n97_), .B(new_n98_), .C(new_n111_), .Y(new_n112_));
  INVx1_ASAP7_75t_R    g026(.A(p17), .Y(new_n113_));
  OR3x1_ASAP7_75t_R    g027(.A(new_n112_), .B(new_n90_), .C(new_n113_), .Y(o12));
  INVx1_ASAP7_75t_R    g028(.A(p11), .Y(new_n115_));
  NOR3x1_ASAP7_75t_R   g029(.A(new_n112_), .B(new_n113_), .C(new_n115_), .Y(new_n116_));
  NAND2x1_ASAP7_75t_R  g030(.A(p18), .B(new_n116_), .Y(o13));
  OAI21x1_ASAP7_75t_R  g031(.A1(p13), .A2(p14), .B(p19), .Y(o14));
  XOR2x2_ASAP7_75t_R   g032(.A(p23), .B(p24), .Y(new_n119_));
  XOR2x2_ASAP7_75t_R   g033(.A(p28), .B(p27), .Y(new_n120_));
  XOR2x2_ASAP7_75t_R   g034(.A(new_n119_), .B(new_n120_), .Y(new_n121_));
  XOR2x2_ASAP7_75t_R   g035(.A(p21), .B(p20), .Y(new_n122_));
  INVx1_ASAP7_75t_R    g036(.A(p22), .Y(new_n123_));
  XOR2x2_ASAP7_75t_R   g037(.A(new_n122_), .B(new_n123_), .Y(new_n124_));
  XOR2x2_ASAP7_75t_R   g038(.A(new_n121_), .B(new_n124_), .Y(new_n125_));
  XOR2x2_ASAP7_75t_R   g039(.A(p25), .B(p29), .Y(new_n126_));
  XOR2x2_ASAP7_75t_R   g040(.A(new_n126_), .B(p26), .Y(new_n127_));
  XOR2x2_ASAP7_75t_R   g041(.A(new_n125_), .B(new_n127_), .Y(o15));
  XOR2x2_ASAP7_75t_R   g042(.A(p32), .B(p33), .Y(new_n129_));
  XOR2x2_ASAP7_75t_R   g043(.A(p36), .B(p37), .Y(new_n130_));
  XOR2x2_ASAP7_75t_R   g044(.A(new_n129_), .B(new_n130_), .Y(new_n131_));
  XOR2x2_ASAP7_75t_R   g045(.A(p20), .B(p30), .Y(new_n132_));
  INVx1_ASAP7_75t_R    g046(.A(p31), .Y(new_n133_));
  XOR2x2_ASAP7_75t_R   g047(.A(new_n132_), .B(new_n133_), .Y(new_n134_));
  XOR2x2_ASAP7_75t_R   g048(.A(new_n131_), .B(new_n134_), .Y(new_n135_));
  XOR2x2_ASAP7_75t_R   g049(.A(p35), .B(p34), .Y(new_n136_));
  XOR2x2_ASAP7_75t_R   g050(.A(new_n136_), .B(p38), .Y(new_n137_));
  XOR2x2_ASAP7_75t_R   g051(.A(new_n135_), .B(new_n137_), .Y(o16));
  AND3x1_ASAP7_75t_R   g052(.A(p0), .B(p59), .C(p11), .Y(new_n139_));
  NAND2x1_ASAP7_75t_R  g053(.A(p6), .B(p15), .Y(new_n140_));
  NOR3x1_ASAP7_75t_R   g054(.A(new_n139_), .B(new_n97_), .C(new_n140_), .Y(new_n141_));
  AND4x2_ASAP7_75t_R   g055(.A(p10), .B(p2), .C(p9), .D(p15), .Y(new_n142_));
  NOR3x1_ASAP7_75t_R   g056(.A(new_n88_), .B(p44), .C(new_n111_), .Y(new_n143_));
  AOI22x1_ASAP7_75t_R  g057(.A1(new_n141_), .A2(p28), .B1(new_n142_), .B2(new_n143_), .Y(new_n144_));
  OAI21x1_ASAP7_75t_R  g058(.A1(p6), .A2(p59), .B(p15), .Y(new_n145_));
  NOR2x1_ASAP7_75t_R   g059(.A(new_n102_), .B(new_n145_), .Y(new_n146_));
  NAND2x1_ASAP7_75t_R  g060(.A(p46), .B(p11), .Y(new_n147_));
  AOI21x1_ASAP7_75t_R  g061(.A1(p6), .A2(p59), .B(new_n147_), .Y(new_n148_));
  NAND3x1_ASAP7_75t_R  g062(.A(new_n146_), .B(new_n148_), .C(p28), .Y(new_n149_));
  AOI211x1_ASAP7_75t_R g063(.A1(p46), .A2(p11), .B(new_n102_), .C(new_n140_), .Y(new_n150_));
  INVx1_ASAP7_75t_R    g064(.A(p9), .Y(new_n151_));
  AO21x1_ASAP7_75t_R   g065(.A1(p45), .A2(new_n151_), .B(p37), .Y(new_n152_));
  AOI21x1_ASAP7_75t_R  g066(.A1(p45), .A2(new_n150_), .B(new_n152_), .Y(new_n153_));
  AND3x1_ASAP7_75t_R   g067(.A(new_n144_), .B(new_n149_), .C(new_n153_), .Y(new_n154_));
  AO31x2_ASAP7_75t_R   g068(.A1(new_n147_), .A2(p10), .A3(p15), .B(new_n151_), .Y(new_n155_));
  OA21x2_ASAP7_75t_R   g069(.A1(p6), .A2(new_n151_), .B(p45), .Y(new_n156_));
  AOI22x1_ASAP7_75t_R  g070(.A1(new_n155_), .A2(new_n156_), .B1(new_n142_), .B2(new_n143_), .Y(new_n157_));
  NAND3x1_ASAP7_75t_R  g071(.A(p0), .B(p59), .C(p11), .Y(new_n158_));
  AND4x2_ASAP7_75t_R   g072(.A(p8), .B(p6), .C(p9), .D(p15), .Y(new_n159_));
  NAND2x1_ASAP7_75t_R  g073(.A(new_n158_), .B(new_n159_), .Y(new_n160_));
  NAND2x1_ASAP7_75t_R  g074(.A(new_n148_), .B(new_n146_), .Y(new_n161_));
  INVx1_ASAP7_75t_R    g075(.A(p28), .Y(new_n162_));
  AO21x1_ASAP7_75t_R   g076(.A1(new_n160_), .A2(new_n161_), .B(new_n162_), .Y(new_n163_));
  INVx1_ASAP7_75t_R    g077(.A(p37), .Y(new_n164_));
  AOI21x1_ASAP7_75t_R  g078(.A1(new_n157_), .A2(new_n163_), .B(new_n164_), .Y(new_n165_));
  NOR2x1_ASAP7_75t_R   g079(.A(new_n154_), .B(new_n165_), .Y(new_n166_));
  XOR2x2_ASAP7_75t_R   g080(.A(new_n166_), .B(p51), .Y(new_n167_));
  NAND2x1_ASAP7_75t_R  g081(.A(new_n157_), .B(new_n163_), .Y(new_n168_));
  AND3x1_ASAP7_75t_R   g082(.A(p40), .B(p59), .C(p39), .Y(new_n169_));
  AND2x2_ASAP7_75t_R   g083(.A(p37), .B(new_n169_), .Y(new_n170_));
  AO22x1_ASAP7_75t_R   g084(.A1(p42), .A2(p41), .B1(p49), .B2(p27), .Y(new_n171_));
  AO21x1_ASAP7_75t_R   g085(.A1(new_n170_), .A2(new_n116_), .B(new_n171_), .Y(new_n172_));
  AO21x1_ASAP7_75t_R   g086(.A1(p43), .A2(new_n168_), .B(new_n172_), .Y(new_n173_));
  AO21x1_ASAP7_75t_R   g087(.A1(p48), .A2(new_n165_), .B(new_n173_), .Y(new_n174_));
  AO21x1_ASAP7_75t_R   g088(.A1(p47), .A2(new_n166_), .B(new_n174_), .Y(new_n175_));
  AOI21x1_ASAP7_75t_R  g089(.A1(p50), .A2(new_n167_), .B(new_n175_), .Y(o17));
  INVx1_ASAP7_75t_R    g090(.A(p50), .Y(new_n177_));
  AO21x1_ASAP7_75t_R   g091(.A1(new_n148_), .A2(new_n146_), .B(new_n141_), .Y(new_n178_));
  NOR2x1_ASAP7_75t_R   g092(.A(p44), .B(new_n88_), .Y(new_n179_));
  AND3x1_ASAP7_75t_R   g093(.A(new_n179_), .B(p16), .C(new_n142_), .Y(new_n180_));
  OA21x2_ASAP7_75t_R   g094(.A1(p6), .A2(new_n151_), .B(p52), .Y(new_n181_));
  AO21x1_ASAP7_75t_R   g095(.A1(new_n181_), .A2(new_n155_), .B(p34), .Y(new_n182_));
  AO211x2_ASAP7_75t_R  g096(.A1(new_n178_), .A2(p25), .B(new_n180_), .C(new_n182_), .Y(new_n183_));
  AOI21x1_ASAP7_75t_R  g097(.A1(new_n155_), .A2(new_n181_), .B(new_n180_), .Y(new_n184_));
  NAND2x1_ASAP7_75t_R  g098(.A(p25), .B(new_n178_), .Y(new_n185_));
  INVx1_ASAP7_75t_R    g099(.A(p34), .Y(new_n186_));
  AO21x1_ASAP7_75t_R   g100(.A1(new_n184_), .A2(new_n185_), .B(new_n186_), .Y(new_n187_));
  NAND2x1_ASAP7_75t_R  g101(.A(new_n183_), .B(new_n187_), .Y(new_n188_));
  OA21x2_ASAP7_75t_R   g102(.A1(p6), .A2(new_n151_), .B(p53), .Y(new_n189_));
  AOI22x1_ASAP7_75t_R  g103(.A1(new_n155_), .A2(new_n189_), .B1(new_n142_), .B2(new_n143_), .Y(new_n190_));
  NAND3x1_ASAP7_75t_R  g104(.A(new_n146_), .B(new_n148_), .C(p27), .Y(new_n191_));
  NAND3x1_ASAP7_75t_R  g105(.A(new_n159_), .B(p27), .C(new_n158_), .Y(new_n192_));
  INVx1_ASAP7_75t_R    g106(.A(p36), .Y(new_n193_));
  AO31x2_ASAP7_75t_R   g107(.A1(new_n190_), .A2(new_n191_), .A3(new_n192_), .B(new_n193_), .Y(new_n194_));
  AOI22x1_ASAP7_75t_R  g108(.A1(new_n141_), .A2(p26), .B1(new_n142_), .B2(new_n143_), .Y(new_n195_));
  NAND3x1_ASAP7_75t_R  g109(.A(new_n146_), .B(new_n148_), .C(p26), .Y(new_n196_));
  OA21x2_ASAP7_75t_R   g110(.A1(p6), .A2(new_n151_), .B(p54), .Y(new_n197_));
  AOI21x1_ASAP7_75t_R  g111(.A1(new_n197_), .A2(new_n155_), .B(p35), .Y(new_n198_));
  AND3x1_ASAP7_75t_R   g112(.A(new_n195_), .B(new_n196_), .C(new_n198_), .Y(new_n199_));
  INVx1_ASAP7_75t_R    g113(.A(p35), .Y(new_n200_));
  NAND2x1_ASAP7_75t_R  g114(.A(new_n197_), .B(new_n155_), .Y(new_n201_));
  AND3x1_ASAP7_75t_R   g115(.A(new_n195_), .B(new_n196_), .C(new_n201_), .Y(new_n202_));
  OA22x2_ASAP7_75t_R   g116(.A1(new_n194_), .A2(new_n199_), .B1(new_n200_), .B2(new_n202_), .Y(new_n203_));
  AO21x1_ASAP7_75t_R   g117(.A1(p45), .A2(new_n150_), .B(new_n152_), .Y(new_n204_));
  INVx1_ASAP7_75t_R    g118(.A(new_n149_), .Y(new_n205_));
  NAND2x1_ASAP7_75t_R  g119(.A(new_n142_), .B(new_n143_), .Y(new_n206_));
  OAI21x1_ASAP7_75t_R  g120(.A1(new_n162_), .A2(new_n160_), .B(new_n206_), .Y(new_n207_));
  OA31x2_ASAP7_75t_R   g121(.A1(new_n204_), .A2(new_n205_), .A3(new_n207_), .B1(p51), .Y(new_n208_));
  INVx1_ASAP7_75t_R    g122(.A(p26), .Y(new_n209_));
  OR4x2_ASAP7_75t_R    g123(.A(new_n139_), .B(new_n209_), .C(new_n97_), .D(new_n140_), .Y(new_n210_));
  NAND3x1_ASAP7_75t_R  g124(.A(new_n196_), .B(new_n210_), .C(new_n206_), .Y(new_n211_));
  INVx1_ASAP7_75t_R    g125(.A(new_n198_), .Y(new_n212_));
  AO21x1_ASAP7_75t_R   g126(.A1(new_n189_), .A2(new_n155_), .B(p36), .Y(new_n213_));
  NAND3x1_ASAP7_75t_R  g127(.A(new_n191_), .B(new_n206_), .C(new_n192_), .Y(new_n214_));
  OA22x2_ASAP7_75t_R   g128(.A1(new_n211_), .A2(new_n212_), .B1(new_n213_), .B2(new_n214_), .Y(new_n215_));
  OAI21x1_ASAP7_75t_R  g129(.A1(new_n165_), .A2(new_n208_), .B(new_n215_), .Y(new_n216_));
  AND3x1_ASAP7_75t_R   g130(.A(new_n188_), .B(new_n203_), .C(new_n216_), .Y(new_n217_));
  NAND2x1_ASAP7_75t_R  g131(.A(p28), .B(new_n141_), .Y(new_n218_));
  AO31x2_ASAP7_75t_R   g132(.A1(new_n157_), .A2(new_n149_), .A3(new_n218_), .B(new_n164_), .Y(new_n219_));
  INVx1_ASAP7_75t_R    g133(.A(p51), .Y(new_n220_));
  AO31x2_ASAP7_75t_R   g134(.A1(new_n144_), .A2(new_n149_), .A3(new_n153_), .B(new_n220_), .Y(new_n221_));
  NAND2x1_ASAP7_75t_R  g135(.A(new_n219_), .B(new_n221_), .Y(new_n222_));
  OAI22x1_ASAP7_75t_R  g136(.A1(new_n194_), .A2(new_n199_), .B1(new_n202_), .B2(new_n200_), .Y(new_n223_));
  AO21x1_ASAP7_75t_R   g137(.A1(new_n222_), .A2(new_n215_), .B(new_n223_), .Y(new_n224_));
  AND3x1_ASAP7_75t_R   g138(.A(new_n224_), .B(new_n187_), .C(new_n183_), .Y(new_n225_));
  INVx1_ASAP7_75t_R    g139(.A(p47), .Y(new_n226_));
  AND3x1_ASAP7_75t_R   g140(.A(new_n116_), .B(p34), .C(new_n169_), .Y(new_n227_));
  AOI21x1_ASAP7_75t_R  g141(.A1(p24), .A2(p49), .B(new_n227_), .Y(new_n228_));
  INVx1_ASAP7_75t_R    g142(.A(p48), .Y(new_n229_));
  INVx1_ASAP7_75t_R    g143(.A(p43), .Y(new_n230_));
  OA21x2_ASAP7_75t_R   g144(.A1(new_n186_), .A2(new_n229_), .B(new_n230_), .Y(new_n231_));
  AO21x1_ASAP7_75t_R   g145(.A1(new_n184_), .A2(new_n185_), .B(new_n231_), .Y(new_n232_));
  OA211x2_ASAP7_75t_R  g146(.A1(new_n226_), .A2(new_n188_), .B(new_n228_), .C(new_n232_), .Y(new_n233_));
  OA31x2_ASAP7_75t_R   g147(.A1(new_n177_), .A2(new_n217_), .A3(new_n225_), .B1(new_n233_), .Y(o18));
  AND2x2_ASAP7_75t_R   g148(.A(new_n192_), .B(new_n191_), .Y(new_n235_));
  NAND2x1_ASAP7_75t_R  g149(.A(new_n190_), .B(new_n235_), .Y(new_n236_));
  OA21x2_ASAP7_75t_R   g150(.A1(p36), .A2(new_n236_), .B(new_n222_), .Y(new_n237_));
  AOI21x1_ASAP7_75t_R  g151(.A1(new_n190_), .A2(new_n235_), .B(new_n193_), .Y(new_n238_));
  AND3x1_ASAP7_75t_R   g152(.A(new_n196_), .B(new_n210_), .C(new_n206_), .Y(new_n239_));
  AOI21x1_ASAP7_75t_R  g153(.A1(new_n201_), .A2(new_n239_), .B(new_n200_), .Y(new_n240_));
  NOR2x1_ASAP7_75t_R   g154(.A(new_n199_), .B(new_n240_), .Y(new_n241_));
  OR3x1_ASAP7_75t_R    g155(.A(new_n237_), .B(new_n238_), .C(new_n241_), .Y(new_n242_));
  AO21x1_ASAP7_75t_R   g156(.A1(new_n238_), .A2(new_n241_), .B(new_n177_), .Y(new_n243_));
  AOI21x1_ASAP7_75t_R  g157(.A1(new_n241_), .A2(new_n237_), .B(new_n243_), .Y(new_n244_));
  OR3x1_ASAP7_75t_R    g158(.A(new_n240_), .B(new_n226_), .C(new_n199_), .Y(new_n245_));
  OA21x2_ASAP7_75t_R   g159(.A1(new_n200_), .A2(new_n229_), .B(new_n230_), .Y(new_n246_));
  AND2x2_ASAP7_75t_R   g160(.A(new_n169_), .B(new_n116_), .Y(new_n247_));
  AO22x1_ASAP7_75t_R   g161(.A1(p25), .A2(p49), .B1(p55), .B2(p41), .Y(new_n248_));
  AOI21x1_ASAP7_75t_R  g162(.A1(p35), .A2(new_n247_), .B(new_n248_), .Y(new_n249_));
  OA21x2_ASAP7_75t_R   g163(.A1(new_n202_), .A2(new_n246_), .B(new_n249_), .Y(new_n250_));
  NAND2x1_ASAP7_75t_R  g164(.A(new_n245_), .B(new_n250_), .Y(new_n251_));
  AOI21x1_ASAP7_75t_R  g165(.A1(new_n242_), .A2(new_n244_), .B(new_n251_), .Y(o19));
  OA21x2_ASAP7_75t_R   g166(.A1(new_n214_), .A2(new_n213_), .B(new_n194_), .Y(new_n253_));
  XOR2x2_ASAP7_75t_R   g167(.A(new_n253_), .B(new_n222_), .Y(new_n254_));
  AO21x1_ASAP7_75t_R   g168(.A1(p48), .A2(new_n236_), .B(new_n247_), .Y(new_n255_));
  AO22x1_ASAP7_75t_R   g169(.A1(p56), .A2(p41), .B1(p26), .B2(p49), .Y(new_n256_));
  AO21x1_ASAP7_75t_R   g170(.A1(p43), .A2(new_n236_), .B(new_n256_), .Y(new_n257_));
  AO21x1_ASAP7_75t_R   g171(.A1(p47), .A2(new_n253_), .B(new_n257_), .Y(new_n258_));
  AO21x1_ASAP7_75t_R   g172(.A1(p36), .A2(new_n255_), .B(new_n258_), .Y(new_n259_));
  AOI21x1_ASAP7_75t_R  g173(.A1(p50), .A2(new_n254_), .B(new_n259_), .Y(o20));
  INVx1_ASAP7_75t_R    g174(.A(p23), .Y(new_n261_));
  AO21x1_ASAP7_75t_R   g175(.A1(new_n160_), .A2(new_n161_), .B(new_n261_), .Y(new_n262_));
  AND3x1_ASAP7_75t_R   g176(.A(new_n179_), .B(p6), .C(new_n142_), .Y(new_n263_));
  AND3x1_ASAP7_75t_R   g177(.A(p10), .B(p9), .C(p15), .Y(new_n264_));
  AND2x2_ASAP7_75t_R   g178(.A(p53), .B(p16), .Y(new_n265_));
  AND2x2_ASAP7_75t_R   g179(.A(p6), .B(p57), .Y(new_n266_));
  AO31x2_ASAP7_75t_R   g180(.A1(new_n264_), .A2(new_n265_), .A3(new_n147_), .B(new_n266_), .Y(new_n267_));
  NOR3x1_ASAP7_75t_R   g181(.A(new_n263_), .B(p32), .C(new_n267_), .Y(new_n268_));
  AND2x2_ASAP7_75t_R   g182(.A(p45), .B(p16), .Y(new_n269_));
  AND2x2_ASAP7_75t_R   g183(.A(p57), .B(p58), .Y(new_n270_));
  AO31x2_ASAP7_75t_R   g184(.A1(new_n264_), .A2(new_n269_), .A3(new_n147_), .B(new_n270_), .Y(new_n271_));
  NOR3x1_ASAP7_75t_R   g185(.A(new_n263_), .B(p33), .C(new_n271_), .Y(new_n272_));
  INVx1_ASAP7_75t_R    g186(.A(p24), .Y(new_n273_));
  AO21x1_ASAP7_75t_R   g187(.A1(new_n160_), .A2(new_n161_), .B(new_n273_), .Y(new_n274_));
  AOI22x1_ASAP7_75t_R  g188(.A1(new_n262_), .A2(new_n268_), .B1(new_n272_), .B2(new_n274_), .Y(new_n275_));
  AND2x2_ASAP7_75t_R   g189(.A(p57), .B(p15), .Y(new_n276_));
  NOR3x1_ASAP7_75t_R   g190(.A(new_n263_), .B(p31), .C(new_n276_), .Y(new_n277_));
  AND2x2_ASAP7_75t_R   g191(.A(p54), .B(p16), .Y(new_n278_));
  AND3x1_ASAP7_75t_R   g192(.A(new_n264_), .B(new_n278_), .C(new_n147_), .Y(new_n279_));
  AND3x1_ASAP7_75t_R   g193(.A(new_n146_), .B(p22), .C(new_n148_), .Y(new_n280_));
  AOI211x1_ASAP7_75t_R g194(.A1(p22), .A2(new_n141_), .B(new_n279_), .C(new_n280_), .Y(new_n281_));
  NAND2x1_ASAP7_75t_R  g195(.A(new_n277_), .B(new_n281_), .Y(new_n282_));
  NAND3x1_ASAP7_75t_R  g196(.A(new_n183_), .B(new_n275_), .C(new_n282_), .Y(new_n283_));
  AO31x2_ASAP7_75t_R   g197(.A1(new_n216_), .A2(new_n187_), .A3(new_n203_), .B(new_n283_), .Y(new_n284_));
  AND2x2_ASAP7_75t_R   g198(.A(p46), .B(p11), .Y(new_n285_));
  INVx1_ASAP7_75t_R    g199(.A(p52), .Y(new_n286_));
  OR4x2_ASAP7_75t_R    g200(.A(new_n285_), .B(o11), .C(new_n286_), .D(new_n111_), .Y(new_n287_));
  NOR3x1_ASAP7_75t_R   g201(.A(new_n88_), .B(p44), .C(new_n99_), .Y(new_n288_));
  NAND2x1_ASAP7_75t_R  g202(.A(new_n142_), .B(new_n288_), .Y(new_n289_));
  NAND2x1_ASAP7_75t_R  g203(.A(p8), .B(p57), .Y(new_n290_));
  AND3x1_ASAP7_75t_R   g204(.A(new_n287_), .B(new_n289_), .C(new_n290_), .Y(new_n291_));
  NAND2x1_ASAP7_75t_R  g205(.A(p21), .B(new_n178_), .Y(new_n292_));
  INVx1_ASAP7_75t_R    g206(.A(p30), .Y(new_n293_));
  AO21x1_ASAP7_75t_R   g207(.A1(new_n291_), .A2(new_n292_), .B(new_n293_), .Y(new_n294_));
  AOI22x1_ASAP7_75t_R  g208(.A1(new_n281_), .A2(new_n277_), .B1(new_n262_), .B2(new_n268_), .Y(new_n295_));
  INVx1_ASAP7_75t_R    g209(.A(new_n267_), .Y(new_n296_));
  NAND3x1_ASAP7_75t_R  g210(.A(new_n146_), .B(new_n148_), .C(p23), .Y(new_n297_));
  OR4x2_ASAP7_75t_R    g211(.A(new_n139_), .B(new_n261_), .C(new_n97_), .D(new_n140_), .Y(new_n298_));
  AND4x2_ASAP7_75t_R   g212(.A(new_n296_), .B(new_n297_), .C(new_n289_), .D(new_n298_), .Y(new_n299_));
  INVx1_ASAP7_75t_R    g213(.A(p32), .Y(new_n300_));
  AND3x1_ASAP7_75t_R   g214(.A(new_n147_), .B(p45), .C(p16), .Y(new_n301_));
  AOI21x1_ASAP7_75t_R  g215(.A1(new_n264_), .A2(new_n301_), .B(new_n270_), .Y(new_n302_));
  NAND3x1_ASAP7_75t_R  g216(.A(new_n146_), .B(new_n148_), .C(p24), .Y(new_n303_));
  OR4x2_ASAP7_75t_R    g217(.A(new_n139_), .B(new_n273_), .C(new_n97_), .D(new_n140_), .Y(new_n304_));
  AND4x2_ASAP7_75t_R   g218(.A(new_n302_), .B(new_n303_), .C(new_n289_), .D(new_n304_), .Y(new_n305_));
  INVx1_ASAP7_75t_R    g219(.A(p33), .Y(new_n306_));
  OAI22x1_ASAP7_75t_R  g220(.A1(new_n299_), .A2(new_n300_), .B1(new_n305_), .B2(new_n306_), .Y(new_n307_));
  AO21x1_ASAP7_75t_R   g221(.A1(new_n160_), .A2(new_n161_), .B(new_n123_), .Y(new_n308_));
  NOR3x1_ASAP7_75t_R   g222(.A(new_n263_), .B(new_n276_), .C(new_n279_), .Y(new_n309_));
  AOI21x1_ASAP7_75t_R  g223(.A1(new_n308_), .A2(new_n309_), .B(new_n133_), .Y(new_n310_));
  AOI21x1_ASAP7_75t_R  g224(.A1(new_n295_), .A2(new_n307_), .B(new_n310_), .Y(new_n311_));
  AND2x2_ASAP7_75t_R   g225(.A(new_n294_), .B(new_n311_), .Y(new_n312_));
  AND3x1_ASAP7_75t_R   g226(.A(new_n292_), .B(new_n293_), .C(new_n291_), .Y(new_n313_));
  AO21x1_ASAP7_75t_R   g227(.A1(new_n284_), .A2(new_n312_), .B(new_n313_), .Y(o21));
  NAND2x1_ASAP7_75t_R  g228(.A(new_n274_), .B(new_n272_), .Y(new_n315_));
  NAND2x1_ASAP7_75t_R  g229(.A(new_n304_), .B(new_n303_), .Y(new_n316_));
  AO21x1_ASAP7_75t_R   g230(.A1(new_n142_), .A2(new_n288_), .B(new_n271_), .Y(new_n317_));
  OAI21x1_ASAP7_75t_R  g231(.A1(new_n316_), .A2(new_n317_), .B(p33), .Y(new_n318_));
  NAND2x1_ASAP7_75t_R  g232(.A(new_n315_), .B(new_n318_), .Y(new_n319_));
  AOI21x1_ASAP7_75t_R  g233(.A1(new_n184_), .A2(new_n185_), .B(new_n186_), .Y(new_n320_));
  AOI211x1_ASAP7_75t_R g234(.A1(p25), .A2(new_n178_), .B(new_n180_), .C(new_n182_), .Y(new_n321_));
  OAI22x1_ASAP7_75t_R  g235(.A1(new_n211_), .A2(new_n212_), .B1(new_n214_), .B2(new_n213_), .Y(new_n322_));
  AOI211x1_ASAP7_75t_R g236(.A1(new_n219_), .A2(new_n221_), .B(new_n321_), .C(new_n322_), .Y(new_n323_));
  AOI211x1_ASAP7_75t_R g237(.A1(new_n183_), .A2(new_n223_), .B(new_n320_), .C(new_n323_), .Y(new_n324_));
  NAND2x1_ASAP7_75t_R  g238(.A(new_n319_), .B(new_n324_), .Y(new_n325_));
  OA21x2_ASAP7_75t_R   g239(.A1(new_n319_), .A2(new_n324_), .B(p50), .Y(new_n326_));
  AOI22x1_ASAP7_75t_R  g240(.A1(new_n247_), .A2(p33), .B1(p23), .B2(p49), .Y(new_n327_));
  OAI21x1_ASAP7_75t_R  g241(.A1(new_n316_), .A2(new_n317_), .B(p43), .Y(new_n328_));
  OA211x2_ASAP7_75t_R  g242(.A1(new_n229_), .A2(new_n318_), .B(new_n327_), .C(new_n328_), .Y(new_n329_));
  OAI21x1_ASAP7_75t_R  g243(.A1(new_n226_), .A2(new_n319_), .B(new_n329_), .Y(new_n330_));
  AOI21x1_ASAP7_75t_R  g244(.A1(new_n325_), .A2(new_n326_), .B(new_n330_), .Y(o22));
  NAND2x1_ASAP7_75t_R  g245(.A(new_n282_), .B(new_n275_), .Y(new_n332_));
  NAND3x1_ASAP7_75t_R  g246(.A(new_n292_), .B(new_n293_), .C(new_n291_), .Y(new_n333_));
  NAND2x1_ASAP7_75t_R  g247(.A(new_n333_), .B(new_n294_), .Y(new_n334_));
  OR3x1_ASAP7_75t_R    g248(.A(new_n324_), .B(new_n332_), .C(new_n334_), .Y(new_n335_));
  AOI21x1_ASAP7_75t_R  g249(.A1(new_n291_), .A2(new_n292_), .B(new_n293_), .Y(new_n336_));
  NOR2x1_ASAP7_75t_R   g250(.A(new_n336_), .B(new_n313_), .Y(new_n337_));
  AOI211x1_ASAP7_75t_R g251(.A1(new_n307_), .A2(new_n295_), .B(new_n310_), .C(new_n337_), .Y(new_n338_));
  OAI21x1_ASAP7_75t_R  g252(.A1(new_n334_), .A2(new_n311_), .B(p50), .Y(new_n339_));
  AOI21x1_ASAP7_75t_R  g253(.A1(new_n338_), .A2(new_n284_), .B(new_n339_), .Y(new_n340_));
  AO21x1_ASAP7_75t_R   g254(.A1(new_n291_), .A2(new_n292_), .B(new_n230_), .Y(new_n341_));
  AOI22x1_ASAP7_75t_R  g255(.A1(new_n247_), .A2(p30), .B1(p44), .B2(p49), .Y(new_n342_));
  OA211x2_ASAP7_75t_R  g256(.A1(new_n229_), .A2(new_n294_), .B(new_n341_), .C(new_n342_), .Y(new_n343_));
  OAI21x1_ASAP7_75t_R  g257(.A1(new_n226_), .A2(new_n334_), .B(new_n343_), .Y(new_n344_));
  AOI21x1_ASAP7_75t_R  g258(.A1(new_n335_), .A2(new_n340_), .B(new_n344_), .Y(o23));
  INVx1_ASAP7_75t_R    g259(.A(new_n275_), .Y(new_n346_));
  NAND2x1_ASAP7_75t_R  g260(.A(new_n298_), .B(new_n297_), .Y(new_n347_));
  AO21x1_ASAP7_75t_R   g261(.A1(new_n142_), .A2(new_n288_), .B(new_n267_), .Y(new_n348_));
  OAI21x1_ASAP7_75t_R  g262(.A1(new_n347_), .A2(new_n348_), .B(p32), .Y(new_n349_));
  NOR3x1_ASAP7_75t_R   g263(.A(new_n348_), .B(new_n347_), .C(p32), .Y(new_n350_));
  AOI21x1_ASAP7_75t_R  g264(.A1(new_n349_), .A2(new_n318_), .B(new_n350_), .Y(new_n351_));
  AOI21x1_ASAP7_75t_R  g265(.A1(new_n281_), .A2(new_n277_), .B(new_n310_), .Y(new_n352_));
  NOR2x1_ASAP7_75t_R   g266(.A(new_n351_), .B(new_n352_), .Y(new_n353_));
  OAI21x1_ASAP7_75t_R  g267(.A1(new_n346_), .A2(new_n324_), .B(new_n353_), .Y(new_n354_));
  INVx1_ASAP7_75t_R    g268(.A(new_n352_), .Y(new_n355_));
  AOI21x1_ASAP7_75t_R  g269(.A1(new_n351_), .A2(new_n352_), .B(new_n177_), .Y(new_n356_));
  OA31x2_ASAP7_75t_R   g270(.A1(new_n346_), .A2(new_n355_), .A3(new_n324_), .B1(new_n356_), .Y(new_n357_));
  NAND2x1_ASAP7_75t_R  g271(.A(p48), .B(new_n310_), .Y(new_n358_));
  AO21x1_ASAP7_75t_R   g272(.A1(new_n308_), .A2(new_n309_), .B(new_n230_), .Y(new_n359_));
  AOI22x1_ASAP7_75t_R  g273(.A1(new_n247_), .A2(p31), .B1(p21), .B2(p49), .Y(new_n360_));
  AND3x1_ASAP7_75t_R   g274(.A(new_n358_), .B(new_n359_), .C(new_n360_), .Y(new_n361_));
  OAI21x1_ASAP7_75t_R  g275(.A1(new_n226_), .A2(new_n355_), .B(new_n361_), .Y(new_n362_));
  AOI21x1_ASAP7_75t_R  g276(.A1(new_n354_), .A2(new_n357_), .B(new_n362_), .Y(o24));
  NAND2x1_ASAP7_75t_R  g277(.A(new_n262_), .B(new_n268_), .Y(new_n364_));
  NAND2x1_ASAP7_75t_R  g278(.A(new_n364_), .B(new_n349_), .Y(new_n365_));
  AO21x1_ASAP7_75t_R   g279(.A1(new_n274_), .A2(new_n272_), .B(new_n365_), .Y(new_n366_));
  AO21x1_ASAP7_75t_R   g280(.A1(new_n318_), .A2(new_n324_), .B(new_n366_), .Y(new_n367_));
  AND2x2_ASAP7_75t_R   g281(.A(new_n318_), .B(new_n365_), .Y(new_n368_));
  NAND2x1_ASAP7_75t_R  g282(.A(new_n315_), .B(new_n183_), .Y(new_n369_));
  AO31x2_ASAP7_75t_R   g283(.A1(new_n216_), .A2(new_n187_), .A3(new_n203_), .B(new_n369_), .Y(new_n370_));
  AOI21x1_ASAP7_75t_R  g284(.A1(new_n368_), .A2(new_n370_), .B(new_n177_), .Y(new_n371_));
  AOI22x1_ASAP7_75t_R  g285(.A1(new_n247_), .A2(p32), .B1(p22), .B2(p49), .Y(new_n372_));
  OA21x2_ASAP7_75t_R   g286(.A1(new_n230_), .A2(new_n299_), .B(new_n372_), .Y(new_n373_));
  OA21x2_ASAP7_75t_R   g287(.A1(new_n229_), .A2(new_n349_), .B(new_n373_), .Y(new_n374_));
  OAI21x1_ASAP7_75t_R  g288(.A1(new_n226_), .A2(new_n365_), .B(new_n374_), .Y(new_n375_));
  AOI21x1_ASAP7_75t_R  g289(.A1(new_n367_), .A2(new_n371_), .B(new_n375_), .Y(o25));
endmodule


