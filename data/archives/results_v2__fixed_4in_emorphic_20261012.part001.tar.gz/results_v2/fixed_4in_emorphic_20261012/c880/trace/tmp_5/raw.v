// Benchmark "/tmp/" written by ABC on Mon Oct 12 15:07:53 2026

module \/tmp/  ( 
    p44, p37, p54, p27, p11, p51, p52, p33, p15, p31, p6, p26, p45, p22,
    p46, p56, p48, p59, p24, p58, p42, p1, p14, p8, p53, p10, p3, p55, p0,
    p57, p9, p16, p23, p47, p41, p28, p25, p20, p12, p29, p49, p30, p32,
    p5, p38, p18, p4, p43, p40, p19, p2, p50, p34, p21, p17, p36, p13, p7,
    p39, p35,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25  );
  input  p44, p37, p54, p27, p11, p51, p52, p33, p15, p31, p6, p26, p45,
    p22, p46, p56, p48, p59, p24, p58, p42, p1, p14, p8, p53, p10, p3, p55,
    p0, p57, p9, p16, p23, p47, p41, p28, p25, p20, p12, p29, p49, p30,
    p32, p5, p38, p18, p4, p43, p40, p19, p2, p50, p34, p21, p17, p36, p13,
    p7, p39, p35;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25;
  wire new_n87_, new_n88_, new_n90_, new_n91_, new_n92_, new_n94_, new_n97_,
    new_n98_, new_n100_, new_n101_, new_n109_, new_n111_, new_n114_,
    new_n115_, new_n116_, new_n117_, new_n118_, new_n119_, new_n120_,
    new_n121_, new_n122_, new_n124_, new_n125_, new_n126_, new_n127_,
    new_n128_, new_n129_, new_n130_, new_n131_, new_n132_, new_n134_,
    new_n135_, new_n136_, new_n137_, new_n138_, new_n139_, new_n140_,
    new_n141_, new_n142_, new_n143_, new_n144_, new_n145_, new_n146_,
    new_n147_, new_n148_, new_n149_, new_n150_, new_n151_, new_n152_,
    new_n153_, new_n154_, new_n155_, new_n156_, new_n157_, new_n158_,
    new_n159_, new_n160_, new_n161_, new_n162_, new_n163_, new_n164_,
    new_n165_, new_n166_, new_n167_, new_n168_, new_n169_, new_n170_,
    new_n171_, new_n173_, new_n174_, new_n175_, new_n176_, new_n177_,
    new_n178_, new_n179_, new_n180_, new_n181_, new_n182_, new_n183_,
    new_n184_, new_n185_, new_n186_, new_n187_, new_n188_, new_n189_,
    new_n190_, new_n191_, new_n192_, new_n193_, new_n194_, new_n195_,
    new_n196_, new_n197_, new_n198_, new_n199_, new_n200_, new_n201_,
    new_n202_, new_n203_, new_n204_, new_n205_, new_n206_, new_n207_,
    new_n208_, new_n209_, new_n210_, new_n211_, new_n212_, new_n213_,
    new_n214_, new_n215_, new_n216_, new_n217_, new_n218_, new_n219_,
    new_n221_, new_n222_, new_n223_, new_n224_, new_n225_, new_n226_,
    new_n227_, new_n228_, new_n229_, new_n230_, new_n231_, new_n232_,
    new_n233_, new_n234_, new_n235_, new_n236_, new_n237_, new_n238_,
    new_n239_, new_n240_, new_n241_, new_n243_, new_n244_, new_n245_,
    new_n246_, new_n247_, new_n248_, new_n249_, new_n250_, new_n251_,
    new_n252_, new_n253_, new_n255_, new_n256_, new_n257_, new_n258_,
    new_n259_, new_n260_, new_n261_, new_n262_, new_n263_, new_n264_,
    new_n265_, new_n266_, new_n267_, new_n268_, new_n269_, new_n270_,
    new_n271_, new_n272_, new_n273_, new_n274_, new_n275_, new_n276_,
    new_n277_, new_n278_, new_n279_, new_n280_, new_n281_, new_n282_,
    new_n283_, new_n284_, new_n285_, new_n286_, new_n287_, new_n288_,
    new_n289_, new_n290_, new_n291_, new_n292_, new_n293_, new_n294_,
    new_n295_, new_n296_, new_n297_, new_n298_, new_n299_, new_n301_,
    new_n302_, new_n303_, new_n304_, new_n305_, new_n306_, new_n307_,
    new_n308_, new_n309_, new_n310_, new_n311_, new_n312_, new_n314_,
    new_n315_, new_n316_, new_n317_, new_n318_, new_n319_, new_n320_,
    new_n321_, new_n322_, new_n323_, new_n324_, new_n325_, new_n326_,
    new_n328_, new_n329_, new_n330_, new_n331_, new_n332_, new_n333_,
    new_n334_, new_n335_, new_n336_, new_n337_, new_n338_, new_n339_,
    new_n340_, new_n341_, new_n342_, new_n343_, new_n344_, new_n346_,
    new_n347_, new_n348_, new_n349_, new_n350_, new_n351_, new_n352_,
    new_n353_, new_n354_, new_n355_, new_n356_, new_n357_, new_n358_,
    new_n359_, new_n360_, new_n361_;
  INVx1_ASAP7_75t_R    g000(.A(p59), .Y(new_n87_));
  NAND2x1_ASAP7_75t_R  g001(.A(p1), .B(p0), .Y(new_n88_));
  OR2x4_ASAP7_75t_R    g002(.A(new_n87_), .B(new_n88_), .Y(o0));
  INVx1_ASAP7_75t_R    g003(.A(p1), .Y(new_n90_));
  INVx1_ASAP7_75t_R    g004(.A(p3), .Y(new_n91_));
  INVx1_ASAP7_75t_R    g005(.A(p2), .Y(new_n92_));
  OR3x1_ASAP7_75t_R    g006(.A(new_n90_), .B(new_n91_), .C(new_n92_), .Y(o1));
  AND3x1_ASAP7_75t_R   g007(.A(p59), .B(p1), .C(p3), .Y(new_n94_));
  INVx1_ASAP7_75t_R    g008(.A(new_n94_), .Y(o2));
  NAND2x1_ASAP7_75t_R  g009(.A(p5), .B(p4), .Y(o3));
  AND2x2_ASAP7_75t_R   g010(.A(p6), .B(p7), .Y(new_n97_));
  AND2x2_ASAP7_75t_R   g011(.A(p8), .B(p9), .Y(new_n98_));
  NAND2x1_ASAP7_75t_R  g012(.A(new_n97_), .B(new_n98_), .Y(o4));
  NAND2x1_ASAP7_75t_R  g013(.A(p10), .B(p9), .Y(new_n100_));
  INVx1_ASAP7_75t_R    g014(.A(new_n100_), .Y(new_n101_));
  AND3x1_ASAP7_75t_R   g015(.A(o2), .B(new_n97_), .C(new_n101_), .Y(o5));
  AND3x1_ASAP7_75t_R   g016(.A(p11), .B(p0), .C(p2), .Y(o6));
  AND3x1_ASAP7_75t_R   g017(.A(p11), .B(p3), .C(p2), .Y(o7));
  AND3x1_ASAP7_75t_R   g018(.A(p11), .B(p59), .C(p3), .Y(o8));
  OAI21x1_ASAP7_75t_R  g019(.A1(p14), .A2(p13), .B(p12), .Y(o9));
  AND3x1_ASAP7_75t_R   g020(.A(new_n101_), .B(new_n94_), .C(new_n97_), .Y(o10));
  NAND3x1_ASAP7_75t_R  g021(.A(p15), .B(p10), .C(p9), .Y(o11));
  AND3x1_ASAP7_75t_R   g022(.A(new_n98_), .B(p16), .C(p7), .Y(new_n109_));
  NAND3x1_ASAP7_75t_R  g023(.A(new_n109_), .B(p1), .C(p17), .Y(o12));
  AND3x1_ASAP7_75t_R   g024(.A(new_n109_), .B(p11), .C(p17), .Y(new_n111_));
  NAND2x1_ASAP7_75t_R  g025(.A(p18), .B(new_n111_), .Y(o13));
  OAI21x1_ASAP7_75t_R  g026(.A1(p14), .A2(p13), .B(p19), .Y(o14));
  XOR2x2_ASAP7_75t_R   g027(.A(p24), .B(p23), .Y(new_n114_));
  XOR2x2_ASAP7_75t_R   g028(.A(p27), .B(p28), .Y(new_n115_));
  XOR2x2_ASAP7_75t_R   g029(.A(new_n114_), .B(new_n115_), .Y(new_n116_));
  XOR2x2_ASAP7_75t_R   g030(.A(p26), .B(p25), .Y(new_n117_));
  XOR2x2_ASAP7_75t_R   g031(.A(new_n117_), .B(p29), .Y(new_n118_));
  XOR2x2_ASAP7_75t_R   g032(.A(new_n116_), .B(new_n118_), .Y(new_n119_));
  XOR2x2_ASAP7_75t_R   g033(.A(p22), .B(p20), .Y(new_n120_));
  INVx1_ASAP7_75t_R    g034(.A(p21), .Y(new_n121_));
  XOR2x2_ASAP7_75t_R   g035(.A(new_n120_), .B(new_n121_), .Y(new_n122_));
  XOR2x2_ASAP7_75t_R   g036(.A(new_n119_), .B(new_n122_), .Y(o15));
  XOR2x2_ASAP7_75t_R   g037(.A(p33), .B(p32), .Y(new_n124_));
  XOR2x2_ASAP7_75t_R   g038(.A(p37), .B(p36), .Y(new_n125_));
  XOR2x2_ASAP7_75t_R   g039(.A(new_n124_), .B(new_n125_), .Y(new_n126_));
  XOR2x2_ASAP7_75t_R   g040(.A(p38), .B(p34), .Y(new_n127_));
  XOR2x2_ASAP7_75t_R   g041(.A(new_n127_), .B(p35), .Y(new_n128_));
  XOR2x2_ASAP7_75t_R   g042(.A(new_n126_), .B(new_n128_), .Y(new_n129_));
  XOR2x2_ASAP7_75t_R   g043(.A(p20), .B(p30), .Y(new_n130_));
  INVx1_ASAP7_75t_R    g044(.A(p31), .Y(new_n131_));
  XOR2x2_ASAP7_75t_R   g045(.A(new_n130_), .B(new_n131_), .Y(new_n132_));
  XOR2x2_ASAP7_75t_R   g046(.A(new_n129_), .B(new_n132_), .Y(o16));
  AND3x1_ASAP7_75t_R   g047(.A(p11), .B(p59), .C(p0), .Y(new_n134_));
  NAND2x1_ASAP7_75t_R  g048(.A(p8), .B(p9), .Y(new_n135_));
  NAND2x1_ASAP7_75t_R  g049(.A(p15), .B(p6), .Y(new_n136_));
  NOR3x1_ASAP7_75t_R   g050(.A(new_n134_), .B(new_n135_), .C(new_n136_), .Y(new_n137_));
  NOR2x1_ASAP7_75t_R   g051(.A(p44), .B(new_n88_), .Y(new_n138_));
  INVx1_ASAP7_75t_R    g052(.A(p16), .Y(new_n139_));
  NOR3x1_ASAP7_75t_R   g053(.A(o11), .B(new_n139_), .C(new_n92_), .Y(new_n140_));
  AOI22x1_ASAP7_75t_R  g054(.A1(new_n137_), .A2(p28), .B1(new_n138_), .B2(new_n140_), .Y(new_n141_));
  OAI21x1_ASAP7_75t_R  g055(.A1(p6), .A2(p59), .B(p15), .Y(new_n142_));
  NOR2x1_ASAP7_75t_R   g056(.A(new_n100_), .B(new_n142_), .Y(new_n143_));
  NAND2x1_ASAP7_75t_R  g057(.A(p11), .B(p46), .Y(new_n144_));
  AOI21x1_ASAP7_75t_R  g058(.A1(p6), .A2(p59), .B(new_n144_), .Y(new_n145_));
  NAND3x1_ASAP7_75t_R  g059(.A(new_n143_), .B(new_n145_), .C(p28), .Y(new_n146_));
  AND2x2_ASAP7_75t_R   g060(.A(p11), .B(p46), .Y(new_n147_));
  NOR3x1_ASAP7_75t_R   g061(.A(new_n147_), .B(new_n100_), .C(new_n136_), .Y(new_n148_));
  INVx1_ASAP7_75t_R    g062(.A(p9), .Y(new_n149_));
  AO21x1_ASAP7_75t_R   g063(.A1(p45), .A2(new_n149_), .B(p37), .Y(new_n150_));
  AOI21x1_ASAP7_75t_R  g064(.A1(p45), .A2(new_n148_), .B(new_n150_), .Y(new_n151_));
  AND3x1_ASAP7_75t_R   g065(.A(new_n141_), .B(new_n146_), .C(new_n151_), .Y(new_n152_));
  OAI21x1_ASAP7_75t_R  g066(.A1(new_n149_), .A2(new_n148_), .B(p45), .Y(new_n153_));
  INVx1_ASAP7_75t_R    g067(.A(p37), .Y(new_n154_));
  AO31x2_ASAP7_75t_R   g068(.A1(new_n141_), .A2(new_n153_), .A3(new_n146_), .B(new_n154_), .Y(new_n155_));
  INVx1_ASAP7_75t_R    g069(.A(new_n155_), .Y(new_n156_));
  INVx1_ASAP7_75t_R    g070(.A(p51), .Y(new_n157_));
  OA21x2_ASAP7_75t_R   g071(.A1(new_n152_), .A2(new_n156_), .B(new_n157_), .Y(new_n158_));
  AO31x2_ASAP7_75t_R   g072(.A1(new_n141_), .A2(new_n151_), .A3(new_n146_), .B(new_n157_), .Y(new_n159_));
  OAI21x1_ASAP7_75t_R  g073(.A1(new_n159_), .A2(new_n156_), .B(p50), .Y(new_n160_));
  AND3x1_ASAP7_75t_R   g074(.A(new_n141_), .B(new_n153_), .C(new_n146_), .Y(new_n161_));
  INVx1_ASAP7_75t_R    g075(.A(p48), .Y(new_n162_));
  INVx1_ASAP7_75t_R    g076(.A(p43), .Y(new_n163_));
  OA21x2_ASAP7_75t_R   g077(.A1(new_n154_), .A2(new_n162_), .B(new_n163_), .Y(new_n164_));
  AND3x1_ASAP7_75t_R   g078(.A(p59), .B(p40), .C(p39), .Y(new_n165_));
  AND2x2_ASAP7_75t_R   g079(.A(new_n165_), .B(new_n111_), .Y(new_n166_));
  AO22x1_ASAP7_75t_R   g080(.A1(p27), .A2(p49), .B1(p42), .B2(p41), .Y(new_n167_));
  AOI21x1_ASAP7_75t_R  g081(.A1(p37), .A2(new_n166_), .B(new_n167_), .Y(new_n168_));
  OA21x2_ASAP7_75t_R   g082(.A1(new_n161_), .A2(new_n164_), .B(new_n168_), .Y(new_n169_));
  INVx1_ASAP7_75t_R    g083(.A(p47), .Y(new_n170_));
  OR3x1_ASAP7_75t_R    g084(.A(new_n156_), .B(new_n170_), .C(new_n152_), .Y(new_n171_));
  OA211x2_ASAP7_75t_R  g085(.A1(new_n158_), .A2(new_n160_), .B(new_n169_), .C(new_n171_), .Y(o17));
  NAND3x1_ASAP7_75t_R  g086(.A(p11), .B(p59), .C(p0), .Y(new_n173_));
  AND4x2_ASAP7_75t_R   g087(.A(p15), .B(p6), .C(p8), .D(p9), .Y(new_n174_));
  AO22x1_ASAP7_75t_R   g088(.A1(new_n173_), .A2(new_n174_), .B1(new_n145_), .B2(new_n143_), .Y(new_n175_));
  NAND2x1_ASAP7_75t_R  g089(.A(p25), .B(new_n175_), .Y(new_n176_));
  AND3x1_ASAP7_75t_R   g090(.A(p15), .B(p10), .C(p9), .Y(new_n177_));
  AO21x1_ASAP7_75t_R   g091(.A1(new_n144_), .A2(new_n177_), .B(new_n149_), .Y(new_n178_));
  OA21x2_ASAP7_75t_R   g092(.A1(p6), .A2(new_n149_), .B(p52), .Y(new_n179_));
  AND4x2_ASAP7_75t_R   g093(.A(p15), .B(p10), .C(p9), .D(p2), .Y(new_n180_));
  NOR3x1_ASAP7_75t_R   g094(.A(new_n88_), .B(p44), .C(new_n139_), .Y(new_n181_));
  NAND2x1_ASAP7_75t_R  g095(.A(new_n180_), .B(new_n181_), .Y(new_n182_));
  INVx1_ASAP7_75t_R    g096(.A(new_n182_), .Y(new_n183_));
  AOI21x1_ASAP7_75t_R  g097(.A1(new_n178_), .A2(new_n179_), .B(new_n183_), .Y(new_n184_));
  INVx1_ASAP7_75t_R    g098(.A(p34), .Y(new_n185_));
  AOI21x1_ASAP7_75t_R  g099(.A1(new_n176_), .A2(new_n184_), .B(new_n185_), .Y(new_n186_));
  INVx1_ASAP7_75t_R    g100(.A(p25), .Y(new_n187_));
  AOI22x1_ASAP7_75t_R  g101(.A1(new_n143_), .A2(new_n145_), .B1(new_n173_), .B2(new_n174_), .Y(new_n188_));
  NOR2x1_ASAP7_75t_R   g102(.A(new_n187_), .B(new_n188_), .Y(new_n189_));
  AO21x1_ASAP7_75t_R   g103(.A1(new_n179_), .A2(new_n178_), .B(p34), .Y(new_n190_));
  NOR3x1_ASAP7_75t_R   g104(.A(new_n189_), .B(new_n183_), .C(new_n190_), .Y(new_n191_));
  NOR2x1_ASAP7_75t_R   g105(.A(new_n191_), .B(new_n186_), .Y(new_n192_));
  NAND2x1_ASAP7_75t_R  g106(.A(new_n176_), .B(new_n184_), .Y(new_n193_));
  AO22x1_ASAP7_75t_R   g107(.A1(p24), .A2(p49), .B1(p34), .B2(new_n166_), .Y(new_n194_));
  AO21x1_ASAP7_75t_R   g108(.A1(p43), .A2(new_n193_), .B(new_n194_), .Y(new_n195_));
  AO21x1_ASAP7_75t_R   g109(.A1(p47), .A2(new_n192_), .B(new_n195_), .Y(new_n196_));
  AOI22x1_ASAP7_75t_R  g110(.A1(new_n137_), .A2(p27), .B1(new_n138_), .B2(new_n140_), .Y(new_n197_));
  OA21x2_ASAP7_75t_R   g111(.A1(p6), .A2(new_n149_), .B(p53), .Y(new_n198_));
  NAND2x1_ASAP7_75t_R  g112(.A(new_n198_), .B(new_n178_), .Y(new_n199_));
  NAND3x1_ASAP7_75t_R  g113(.A(new_n143_), .B(new_n145_), .C(p27), .Y(new_n200_));
  INVx1_ASAP7_75t_R    g114(.A(p36), .Y(new_n201_));
  AO31x2_ASAP7_75t_R   g115(.A1(new_n197_), .A2(new_n199_), .A3(new_n200_), .B(new_n201_), .Y(new_n202_));
  OA21x2_ASAP7_75t_R   g116(.A1(p6), .A2(new_n149_), .B(p54), .Y(new_n203_));
  AO21x1_ASAP7_75t_R   g117(.A1(new_n203_), .A2(new_n178_), .B(p35), .Y(new_n204_));
  NAND3x1_ASAP7_75t_R  g118(.A(new_n143_), .B(new_n145_), .C(p26), .Y(new_n205_));
  NAND3x1_ASAP7_75t_R  g119(.A(new_n174_), .B(p26), .C(new_n173_), .Y(new_n206_));
  NAND3x1_ASAP7_75t_R  g120(.A(new_n205_), .B(new_n182_), .C(new_n206_), .Y(new_n207_));
  NOR2x1_ASAP7_75t_R   g121(.A(new_n204_), .B(new_n207_), .Y(new_n208_));
  AND2x2_ASAP7_75t_R   g122(.A(new_n203_), .B(new_n178_), .Y(new_n209_));
  OAI21x1_ASAP7_75t_R  g123(.A1(new_n209_), .A2(new_n207_), .B(p35), .Y(new_n210_));
  OAI21x1_ASAP7_75t_R  g124(.A1(new_n202_), .A2(new_n208_), .B(new_n210_), .Y(new_n211_));
  NAND3x1_ASAP7_75t_R  g125(.A(new_n174_), .B(p27), .C(new_n173_), .Y(new_n212_));
  NAND3x1_ASAP7_75t_R  g126(.A(new_n200_), .B(new_n182_), .C(new_n212_), .Y(new_n213_));
  AO21x1_ASAP7_75t_R   g127(.A1(new_n198_), .A2(new_n178_), .B(p36), .Y(new_n214_));
  OAI22x1_ASAP7_75t_R  g128(.A1(new_n207_), .A2(new_n204_), .B1(new_n213_), .B2(new_n214_), .Y(new_n215_));
  AOI21x1_ASAP7_75t_R  g129(.A1(new_n155_), .A2(new_n159_), .B(new_n215_), .Y(new_n216_));
  OR3x1_ASAP7_75t_R    g130(.A(new_n192_), .B(new_n211_), .C(new_n216_), .Y(new_n217_));
  OAI21x1_ASAP7_75t_R  g131(.A1(new_n211_), .A2(new_n216_), .B(new_n192_), .Y(new_n218_));
  AND3x1_ASAP7_75t_R   g132(.A(new_n217_), .B(p50), .C(new_n218_), .Y(new_n219_));
  AOI211x1_ASAP7_75t_R g133(.A1(p48), .A2(new_n186_), .B(new_n196_), .C(new_n219_), .Y(o18));
  AOI22x1_ASAP7_75t_R  g134(.A1(new_n181_), .A2(new_n180_), .B1(p53), .B2(new_n149_), .Y(new_n221_));
  NAND2x1_ASAP7_75t_R  g135(.A(p53), .B(new_n148_), .Y(new_n222_));
  AOI21x1_ASAP7_75t_R  g136(.A1(new_n221_), .A2(new_n222_), .B(new_n201_), .Y(new_n223_));
  INVx1_ASAP7_75t_R    g137(.A(p27), .Y(new_n224_));
  NOR3x1_ASAP7_75t_R   g138(.A(new_n188_), .B(new_n224_), .C(new_n201_), .Y(new_n225_));
  OAI22x1_ASAP7_75t_R  g139(.A1(new_n223_), .A2(new_n225_), .B1(new_n207_), .B2(new_n204_), .Y(new_n226_));
  AO21x1_ASAP7_75t_R   g140(.A1(new_n155_), .A2(new_n159_), .B(new_n215_), .Y(new_n227_));
  OA21x2_ASAP7_75t_R   g141(.A1(new_n209_), .A2(new_n207_), .B(p35), .Y(new_n228_));
  AOI21x1_ASAP7_75t_R  g142(.A1(new_n226_), .A2(new_n227_), .B(new_n228_), .Y(new_n229_));
  OR2x4_ASAP7_75t_R    g143(.A(new_n214_), .B(new_n213_), .Y(new_n230_));
  NAND2x1_ASAP7_75t_R  g144(.A(new_n155_), .B(new_n159_), .Y(new_n231_));
  NAND2x1_ASAP7_75t_R  g145(.A(new_n230_), .B(new_n231_), .Y(new_n232_));
  OA21x2_ASAP7_75t_R   g146(.A1(new_n208_), .A2(new_n228_), .B(new_n202_), .Y(new_n233_));
  INVx1_ASAP7_75t_R    g147(.A(p50), .Y(new_n234_));
  AO21x1_ASAP7_75t_R   g148(.A1(new_n232_), .A2(new_n233_), .B(new_n234_), .Y(new_n235_));
  OR3x1_ASAP7_75t_R    g149(.A(new_n228_), .B(new_n170_), .C(new_n208_), .Y(new_n236_));
  AO21x1_ASAP7_75t_R   g150(.A1(new_n178_), .A2(new_n203_), .B(new_n207_), .Y(new_n237_));
  AO21x1_ASAP7_75t_R   g151(.A1(p48), .A2(new_n237_), .B(new_n166_), .Y(new_n238_));
  AO22x1_ASAP7_75t_R   g152(.A1(p55), .A2(p41), .B1(p25), .B2(p49), .Y(new_n239_));
  AO21x1_ASAP7_75t_R   g153(.A1(p43), .A2(new_n237_), .B(new_n239_), .Y(new_n240_));
  AOI21x1_ASAP7_75t_R  g154(.A1(p35), .A2(new_n238_), .B(new_n240_), .Y(new_n241_));
  OA211x2_ASAP7_75t_R  g155(.A1(new_n229_), .A2(new_n235_), .B(new_n236_), .C(new_n241_), .Y(o19));
  NAND2x1_ASAP7_75t_R  g156(.A(new_n202_), .B(new_n230_), .Y(new_n243_));
  XNOR2x2_ASAP7_75t_R  g157(.A(new_n231_), .B(new_n243_), .Y(new_n244_));
  NAND2x1_ASAP7_75t_R  g158(.A(p27), .B(new_n175_), .Y(new_n245_));
  AND2x2_ASAP7_75t_R   g159(.A(new_n221_), .B(new_n222_), .Y(new_n246_));
  NAND2x1_ASAP7_75t_R  g160(.A(new_n245_), .B(new_n246_), .Y(new_n247_));
  AO21x1_ASAP7_75t_R   g161(.A1(p48), .A2(new_n247_), .B(new_n166_), .Y(new_n248_));
  AND2x2_ASAP7_75t_R   g162(.A(p36), .B(new_n248_), .Y(new_n249_));
  AND3x1_ASAP7_75t_R   g163(.A(new_n230_), .B(p47), .C(new_n202_), .Y(new_n250_));
  AO22x1_ASAP7_75t_R   g164(.A1(p26), .A2(p49), .B1(p56), .B2(p41), .Y(new_n251_));
  AO21x1_ASAP7_75t_R   g165(.A1(p43), .A2(new_n247_), .B(new_n251_), .Y(new_n252_));
  OR3x1_ASAP7_75t_R    g166(.A(new_n249_), .B(new_n250_), .C(new_n252_), .Y(new_n253_));
  AOI21x1_ASAP7_75t_R  g167(.A1(p50), .A2(new_n244_), .B(new_n253_), .Y(o20));
  NAND2x1_ASAP7_75t_R  g168(.A(p21), .B(new_n175_), .Y(new_n255_));
  AND3x1_ASAP7_75t_R   g169(.A(new_n138_), .B(p6), .C(new_n180_), .Y(new_n256_));
  NOR2x1_ASAP7_75t_R   g170(.A(new_n139_), .B(o11), .Y(new_n257_));
  AND3x1_ASAP7_75t_R   g171(.A(new_n257_), .B(p52), .C(new_n144_), .Y(new_n258_));
  AOI211x1_ASAP7_75t_R g172(.A1(p8), .A2(p57), .B(new_n256_), .C(new_n258_), .Y(new_n259_));
  INVx1_ASAP7_75t_R    g173(.A(p30), .Y(new_n260_));
  AO21x1_ASAP7_75t_R   g174(.A1(new_n255_), .A2(new_n259_), .B(new_n260_), .Y(new_n261_));
  INVx1_ASAP7_75t_R    g175(.A(p32), .Y(new_n262_));
  AND3x1_ASAP7_75t_R   g176(.A(new_n144_), .B(p53), .C(p16), .Y(new_n263_));
  AOI22x1_ASAP7_75t_R  g177(.A1(new_n263_), .A2(new_n177_), .B1(p6), .B2(p57), .Y(new_n264_));
  NAND3x1_ASAP7_75t_R  g178(.A(new_n143_), .B(new_n145_), .C(p23), .Y(new_n265_));
  NAND3x1_ASAP7_75t_R  g179(.A(new_n174_), .B(p23), .C(new_n173_), .Y(new_n266_));
  INVx1_ASAP7_75t_R    g180(.A(p6), .Y(new_n267_));
  NOR3x1_ASAP7_75t_R   g181(.A(new_n88_), .B(p44), .C(new_n267_), .Y(new_n268_));
  NAND2x1_ASAP7_75t_R  g182(.A(new_n180_), .B(new_n268_), .Y(new_n269_));
  AND4x2_ASAP7_75t_R   g183(.A(new_n264_), .B(new_n265_), .C(new_n266_), .D(new_n269_), .Y(new_n270_));
  AND2x2_ASAP7_75t_R   g184(.A(p58), .B(p57), .Y(new_n271_));
  AND2x2_ASAP7_75t_R   g185(.A(p45), .B(p16), .Y(new_n272_));
  AND3x1_ASAP7_75t_R   g186(.A(new_n177_), .B(new_n272_), .C(new_n144_), .Y(new_n273_));
  AO211x2_ASAP7_75t_R  g187(.A1(new_n180_), .A2(new_n268_), .B(new_n271_), .C(new_n273_), .Y(new_n274_));
  NAND3x1_ASAP7_75t_R  g188(.A(new_n174_), .B(p24), .C(new_n173_), .Y(new_n275_));
  NAND3x1_ASAP7_75t_R  g189(.A(new_n143_), .B(new_n145_), .C(p24), .Y(new_n276_));
  NAND2x1_ASAP7_75t_R  g190(.A(new_n275_), .B(new_n276_), .Y(new_n277_));
  NOR3x1_ASAP7_75t_R   g191(.A(new_n274_), .B(new_n277_), .C(p33), .Y(new_n278_));
  AND2x2_ASAP7_75t_R   g192(.A(p54), .B(new_n144_), .Y(new_n279_));
  AND2x2_ASAP7_75t_R   g193(.A(p15), .B(p57), .Y(new_n280_));
  AOI21x1_ASAP7_75t_R  g194(.A1(new_n257_), .A2(new_n279_), .B(new_n280_), .Y(new_n281_));
  NAND2x1_ASAP7_75t_R  g195(.A(new_n269_), .B(new_n281_), .Y(new_n282_));
  AOI211x1_ASAP7_75t_R g196(.A1(p22), .A2(new_n175_), .B(p31), .C(new_n282_), .Y(new_n283_));
  AOI211x1_ASAP7_75t_R g197(.A1(new_n262_), .A2(new_n270_), .B(new_n278_), .C(new_n283_), .Y(new_n284_));
  INVx1_ASAP7_75t_R    g198(.A(new_n284_), .Y(new_n285_));
  OR3x1_ASAP7_75t_R    g199(.A(new_n189_), .B(new_n183_), .C(new_n190_), .Y(new_n286_));
  AOI211x1_ASAP7_75t_R g200(.A1(new_n155_), .A2(new_n159_), .B(new_n191_), .C(new_n215_), .Y(new_n287_));
  AOI211x1_ASAP7_75t_R g201(.A1(new_n286_), .A2(new_n211_), .B(new_n186_), .C(new_n287_), .Y(new_n288_));
  NAND2x1_ASAP7_75t_R  g202(.A(p22), .B(new_n175_), .Y(new_n289_));
  AND3x1_ASAP7_75t_R   g203(.A(new_n281_), .B(new_n131_), .C(new_n269_), .Y(new_n290_));
  AOI22x1_ASAP7_75t_R  g204(.A1(new_n270_), .A2(new_n262_), .B1(new_n289_), .B2(new_n290_), .Y(new_n291_));
  OAI21x1_ASAP7_75t_R  g205(.A1(new_n277_), .A2(new_n274_), .B(p33), .Y(new_n292_));
  OAI21x1_ASAP7_75t_R  g206(.A1(new_n262_), .A2(new_n270_), .B(new_n292_), .Y(new_n293_));
  AOI211x1_ASAP7_75t_R g207(.A1(new_n257_), .A2(new_n279_), .B(new_n280_), .C(new_n256_), .Y(new_n294_));
  AOI21x1_ASAP7_75t_R  g208(.A1(new_n294_), .A2(new_n289_), .B(new_n131_), .Y(new_n295_));
  AOI21x1_ASAP7_75t_R  g209(.A1(new_n291_), .A2(new_n293_), .B(new_n295_), .Y(new_n296_));
  OA21x2_ASAP7_75t_R   g210(.A1(new_n285_), .A2(new_n288_), .B(new_n296_), .Y(new_n297_));
  NAND3x1_ASAP7_75t_R  g211(.A(new_n259_), .B(new_n255_), .C(new_n260_), .Y(new_n298_));
  INVx1_ASAP7_75t_R    g212(.A(new_n298_), .Y(new_n299_));
  AO21x1_ASAP7_75t_R   g213(.A1(new_n261_), .A2(new_n297_), .B(new_n299_), .Y(o21));
  AOI21x1_ASAP7_75t_R  g214(.A1(new_n210_), .A2(new_n226_), .B(new_n191_), .Y(new_n301_));
  OA21x2_ASAP7_75t_R   g215(.A1(new_n277_), .A2(new_n274_), .B(p33), .Y(new_n302_));
  NOR2x1_ASAP7_75t_R   g216(.A(new_n278_), .B(new_n302_), .Y(new_n303_));
  OR4x2_ASAP7_75t_R    g217(.A(new_n301_), .B(new_n287_), .C(new_n186_), .D(new_n303_), .Y(new_n304_));
  AO21x1_ASAP7_75t_R   g218(.A1(new_n186_), .A2(new_n303_), .B(new_n234_), .Y(new_n305_));
  OA21x2_ASAP7_75t_R   g219(.A1(new_n287_), .A2(new_n301_), .B(new_n303_), .Y(new_n306_));
  NOR2x1_ASAP7_75t_R   g220(.A(new_n305_), .B(new_n306_), .Y(new_n307_));
  NOR2x1_ASAP7_75t_R   g221(.A(new_n162_), .B(new_n292_), .Y(new_n308_));
  OAI21x1_ASAP7_75t_R  g222(.A1(new_n277_), .A2(new_n274_), .B(p43), .Y(new_n309_));
  AOI22x1_ASAP7_75t_R  g223(.A1(new_n166_), .A2(p33), .B1(p23), .B2(p49), .Y(new_n310_));
  NAND2x1_ASAP7_75t_R  g224(.A(new_n309_), .B(new_n310_), .Y(new_n311_));
  AO21x1_ASAP7_75t_R   g225(.A1(p47), .A2(new_n303_), .B(new_n311_), .Y(new_n312_));
  AOI211x1_ASAP7_75t_R g226(.A1(new_n304_), .A2(new_n307_), .B(new_n308_), .C(new_n312_), .Y(o22));
  AND2x2_ASAP7_75t_R   g227(.A(new_n298_), .B(new_n261_), .Y(new_n314_));
  AOI211x1_ASAP7_75t_R g228(.A1(new_n293_), .A2(new_n291_), .B(new_n295_), .C(new_n314_), .Y(new_n315_));
  OAI21x1_ASAP7_75t_R  g229(.A1(new_n288_), .A2(new_n285_), .B(new_n315_), .Y(new_n316_));
  OA31x2_ASAP7_75t_R   g230(.A1(new_n186_), .A2(new_n287_), .A3(new_n301_), .B1(new_n284_), .Y(new_n317_));
  NAND2x1_ASAP7_75t_R  g231(.A(new_n298_), .B(new_n261_), .Y(new_n318_));
  OAI21x1_ASAP7_75t_R  g232(.A1(new_n318_), .A2(new_n296_), .B(p50), .Y(new_n319_));
  AOI21x1_ASAP7_75t_R  g233(.A1(new_n314_), .A2(new_n317_), .B(new_n319_), .Y(new_n320_));
  NAND2x1_ASAP7_75t_R  g234(.A(new_n255_), .B(new_n259_), .Y(new_n321_));
  AO22x1_ASAP7_75t_R   g235(.A1(p44), .A2(p49), .B1(p30), .B2(new_n166_), .Y(new_n322_));
  AO21x1_ASAP7_75t_R   g236(.A1(p43), .A2(new_n321_), .B(new_n322_), .Y(new_n323_));
  AND3x1_ASAP7_75t_R   g237(.A(new_n261_), .B(p47), .C(new_n298_), .Y(new_n324_));
  AND3x1_ASAP7_75t_R   g238(.A(new_n321_), .B(p48), .C(p30), .Y(new_n325_));
  OR3x1_ASAP7_75t_R    g239(.A(new_n323_), .B(new_n324_), .C(new_n325_), .Y(new_n326_));
  AOI21x1_ASAP7_75t_R  g240(.A1(new_n316_), .A2(new_n320_), .B(new_n326_), .Y(o23));
  AO21x1_ASAP7_75t_R   g241(.A1(new_n262_), .A2(new_n270_), .B(new_n278_), .Y(new_n328_));
  NOR2x1_ASAP7_75t_R   g242(.A(new_n283_), .B(new_n295_), .Y(new_n329_));
  NAND2x1_ASAP7_75t_R  g243(.A(new_n266_), .B(new_n265_), .Y(new_n330_));
  NAND2x1_ASAP7_75t_R  g244(.A(new_n269_), .B(new_n264_), .Y(new_n331_));
  OAI21x1_ASAP7_75t_R  g245(.A1(new_n330_), .A2(new_n331_), .B(p32), .Y(new_n332_));
  NOR3x1_ASAP7_75t_R   g246(.A(new_n331_), .B(new_n330_), .C(p32), .Y(new_n333_));
  AOI21x1_ASAP7_75t_R  g247(.A1(new_n292_), .A2(new_n332_), .B(new_n333_), .Y(new_n334_));
  NOR2x1_ASAP7_75t_R   g248(.A(new_n329_), .B(new_n334_), .Y(new_n335_));
  OAI21x1_ASAP7_75t_R  g249(.A1(new_n328_), .A2(new_n288_), .B(new_n335_), .Y(new_n336_));
  INVx1_ASAP7_75t_R    g250(.A(new_n329_), .Y(new_n337_));
  AOI21x1_ASAP7_75t_R  g251(.A1(new_n329_), .A2(new_n334_), .B(new_n234_), .Y(new_n338_));
  OA31x2_ASAP7_75t_R   g252(.A1(new_n328_), .A2(new_n337_), .A3(new_n288_), .B1(new_n338_), .Y(new_n339_));
  AND2x2_ASAP7_75t_R   g253(.A(p47), .B(new_n329_), .Y(new_n340_));
  AND2x2_ASAP7_75t_R   g254(.A(p48), .B(new_n295_), .Y(new_n341_));
  AOI21x1_ASAP7_75t_R  g255(.A1(new_n294_), .A2(new_n289_), .B(new_n163_), .Y(new_n342_));
  AO22x1_ASAP7_75t_R   g256(.A1(p49), .A2(p21), .B1(p31), .B2(new_n166_), .Y(new_n343_));
  OR4x2_ASAP7_75t_R    g257(.A(new_n340_), .B(new_n341_), .C(new_n342_), .D(new_n343_), .Y(new_n344_));
  AOI21x1_ASAP7_75t_R  g258(.A1(new_n336_), .A2(new_n339_), .B(new_n344_), .Y(o24));
  NOR2x1_ASAP7_75t_R   g259(.A(new_n262_), .B(new_n270_), .Y(new_n346_));
  OR3x1_ASAP7_75t_R    g260(.A(new_n346_), .B(new_n333_), .C(new_n278_), .Y(new_n347_));
  AO21x1_ASAP7_75t_R   g261(.A1(new_n292_), .A2(new_n288_), .B(new_n347_), .Y(new_n348_));
  NOR2x1_ASAP7_75t_R   g262(.A(new_n333_), .B(new_n346_), .Y(new_n349_));
  NOR2x1_ASAP7_75t_R   g263(.A(new_n302_), .B(new_n349_), .Y(new_n350_));
  OA21x2_ASAP7_75t_R   g264(.A1(new_n208_), .A2(new_n202_), .B(new_n210_), .Y(new_n351_));
  INVx1_ASAP7_75t_R    g265(.A(new_n186_), .Y(new_n352_));
  OR3x1_ASAP7_75t_R    g266(.A(new_n274_), .B(new_n277_), .C(p33), .Y(new_n353_));
  NAND2x1_ASAP7_75t_R  g267(.A(new_n353_), .B(new_n286_), .Y(new_n354_));
  AO31x2_ASAP7_75t_R   g268(.A1(new_n227_), .A2(new_n351_), .A3(new_n352_), .B(new_n354_), .Y(new_n355_));
  AOI21x1_ASAP7_75t_R  g269(.A1(new_n350_), .A2(new_n355_), .B(new_n234_), .Y(new_n356_));
  AND2x2_ASAP7_75t_R   g270(.A(p47), .B(new_n349_), .Y(new_n357_));
  NOR2x1_ASAP7_75t_R   g271(.A(new_n162_), .B(new_n332_), .Y(new_n358_));
  AOI22x1_ASAP7_75t_R  g272(.A1(new_n166_), .A2(p32), .B1(p22), .B2(p49), .Y(new_n359_));
  OAI21x1_ASAP7_75t_R  g273(.A1(new_n163_), .A2(new_n270_), .B(new_n359_), .Y(new_n360_));
  OR3x1_ASAP7_75t_R    g274(.A(new_n357_), .B(new_n358_), .C(new_n360_), .Y(new_n361_));
  AOI21x1_ASAP7_75t_R  g275(.A1(new_n348_), .A2(new_n356_), .B(new_n361_), .Y(o25));
endmodule


