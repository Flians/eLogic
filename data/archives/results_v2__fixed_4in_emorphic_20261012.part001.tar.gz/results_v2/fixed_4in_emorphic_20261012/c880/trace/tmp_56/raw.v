// Benchmark "/tmp/" written by ABC on Mon Oct 12 15:08:00 2026

module \/tmp/  ( 
    p33, p40, p51, p50, p18, p41, p8, p49, p24, p46, p19, p39, p1, p12,
    p56, p29, p21, p17, p14, p36, p2, p37, p0, p28, p42, p9, p31, p34, p11,
    p43, p54, p52, p20, p26, p3, p4, p5, p23, p32, p38, p59, p57, p16, p10,
    p30, p47, p13, p48, p15, p27, p44, p53, p35, p45, p7, p25, p55, p6,
    p22, p58,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25  );
  input  p33, p40, p51, p50, p18, p41, p8, p49, p24, p46, p19, p39, p1,
    p12, p56, p29, p21, p17, p14, p36, p2, p37, p0, p28, p42, p9, p31, p34,
    p11, p43, p54, p52, p20, p26, p3, p4, p5, p23, p32, p38, p59, p57, p16,
    p10, p30, p47, p13, p48, p15, p27, p44, p53, p35, p45, p7, p25, p55,
    p6, p22, p58;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25;
  wire new_n87_, new_n88_, new_n90_, new_n91_, new_n92_, new_n94_, new_n97_,
    new_n98_, new_n99_, new_n101_, new_n102_, new_n109_, new_n111_,
    new_n113_, new_n116_, new_n117_, new_n118_, new_n119_, new_n120_,
    new_n121_, new_n122_, new_n123_, new_n124_, new_n126_, new_n127_,
    new_n128_, new_n129_, new_n130_, new_n131_, new_n132_, new_n133_,
    new_n134_, new_n136_, new_n137_, new_n138_, new_n139_, new_n140_,
    new_n141_, new_n142_, new_n143_, new_n144_, new_n145_, new_n146_,
    new_n147_, new_n148_, new_n149_, new_n150_, new_n151_, new_n152_,
    new_n153_, new_n154_, new_n155_, new_n156_, new_n157_, new_n158_,
    new_n159_, new_n160_, new_n161_, new_n162_, new_n163_, new_n164_,
    new_n165_, new_n166_, new_n167_, new_n168_, new_n169_, new_n170_,
    new_n171_, new_n172_, new_n173_, new_n174_, new_n175_, new_n177_,
    new_n178_, new_n179_, new_n180_, new_n181_, new_n182_, new_n183_,
    new_n184_, new_n185_, new_n186_, new_n187_, new_n188_, new_n189_,
    new_n190_, new_n191_, new_n192_, new_n193_, new_n194_, new_n195_,
    new_n196_, new_n197_, new_n198_, new_n199_, new_n200_, new_n201_,
    new_n202_, new_n203_, new_n204_, new_n205_, new_n206_, new_n207_,
    new_n208_, new_n209_, new_n210_, new_n211_, new_n212_, new_n213_,
    new_n214_, new_n215_, new_n216_, new_n217_, new_n218_, new_n219_,
    new_n220_, new_n221_, new_n222_, new_n223_, new_n224_, new_n225_,
    new_n226_, new_n227_, new_n228_, new_n229_, new_n231_, new_n232_,
    new_n233_, new_n234_, new_n235_, new_n236_, new_n237_, new_n238_,
    new_n239_, new_n240_, new_n241_, new_n242_, new_n243_, new_n244_,
    new_n245_, new_n246_, new_n248_, new_n249_, new_n250_, new_n251_,
    new_n252_, new_n253_, new_n254_, new_n256_, new_n257_, new_n258_,
    new_n259_, new_n260_, new_n261_, new_n262_, new_n263_, new_n264_,
    new_n265_, new_n266_, new_n267_, new_n268_, new_n269_, new_n270_,
    new_n271_, new_n272_, new_n273_, new_n274_, new_n275_, new_n276_,
    new_n277_, new_n278_, new_n279_, new_n280_, new_n281_, new_n282_,
    new_n283_, new_n284_, new_n285_, new_n286_, new_n287_, new_n288_,
    new_n289_, new_n290_, new_n291_, new_n292_, new_n293_, new_n294_,
    new_n295_, new_n296_, new_n297_, new_n298_, new_n299_, new_n300_,
    new_n301_, new_n302_, new_n303_, new_n304_, new_n305_, new_n306_,
    new_n307_, new_n308_, new_n309_, new_n310_, new_n311_, new_n312_,
    new_n313_, new_n314_, new_n315_, new_n317_, new_n318_, new_n319_,
    new_n320_, new_n321_, new_n322_, new_n323_, new_n324_, new_n325_,
    new_n326_, new_n327_, new_n328_, new_n329_, new_n330_, new_n331_,
    new_n332_, new_n333_, new_n335_, new_n336_, new_n337_, new_n338_,
    new_n339_, new_n340_, new_n341_, new_n342_, new_n343_, new_n344_,
    new_n345_, new_n346_, new_n348_, new_n349_, new_n350_, new_n351_,
    new_n352_, new_n353_, new_n354_, new_n355_, new_n356_, new_n357_,
    new_n358_, new_n359_, new_n360_, new_n361_, new_n362_, new_n363_,
    new_n364_, new_n366_, new_n367_, new_n368_, new_n369_, new_n370_,
    new_n371_, new_n372_, new_n373_, new_n374_, new_n375_, new_n376_,
    new_n377_;
  INVx1_ASAP7_75t_R    g000(.A(p59), .Y(new_n87_));
  NAND2x1_ASAP7_75t_R  g001(.A(p1), .B(p0), .Y(new_n88_));
  OR2x4_ASAP7_75t_R    g002(.A(new_n87_), .B(new_n88_), .Y(o0));
  INVx1_ASAP7_75t_R    g003(.A(p1), .Y(new_n90_));
  INVx1_ASAP7_75t_R    g004(.A(p2), .Y(new_n91_));
  INVx1_ASAP7_75t_R    g005(.A(p3), .Y(new_n92_));
  OR3x1_ASAP7_75t_R    g006(.A(new_n90_), .B(new_n91_), .C(new_n92_), .Y(o1));
  AND3x1_ASAP7_75t_R   g007(.A(p1), .B(p3), .C(p59), .Y(new_n94_));
  INVx1_ASAP7_75t_R    g008(.A(new_n94_), .Y(o2));
  NAND2x1_ASAP7_75t_R  g009(.A(p4), .B(p5), .Y(o3));
  AND2x2_ASAP7_75t_R   g010(.A(p7), .B(p6), .Y(new_n97_));
  NAND2x1_ASAP7_75t_R  g011(.A(p8), .B(p9), .Y(new_n98_));
  INVx1_ASAP7_75t_R    g012(.A(new_n98_), .Y(new_n99_));
  NAND2x1_ASAP7_75t_R  g013(.A(new_n97_), .B(new_n99_), .Y(o4));
  NAND2x1_ASAP7_75t_R  g014(.A(p9), .B(p10), .Y(new_n101_));
  INVx1_ASAP7_75t_R    g015(.A(new_n101_), .Y(new_n102_));
  AND3x1_ASAP7_75t_R   g016(.A(o2), .B(new_n97_), .C(new_n102_), .Y(o5));
  AND3x1_ASAP7_75t_R   g017(.A(p2), .B(p0), .C(p11), .Y(o6));
  AND3x1_ASAP7_75t_R   g018(.A(p2), .B(p11), .C(p3), .Y(o7));
  AND3x1_ASAP7_75t_R   g019(.A(p11), .B(p3), .C(p59), .Y(o8));
  OAI21x1_ASAP7_75t_R  g020(.A1(p14), .A2(p13), .B(p12), .Y(o9));
  AND3x1_ASAP7_75t_R   g021(.A(new_n102_), .B(new_n94_), .C(new_n97_), .Y(o10));
  AND3x1_ASAP7_75t_R   g022(.A(p9), .B(p10), .C(p15), .Y(new_n109_));
  INVx1_ASAP7_75t_R    g023(.A(new_n109_), .Y(o11));
  AND3x1_ASAP7_75t_R   g024(.A(new_n99_), .B(p16), .C(p7), .Y(new_n111_));
  NAND3x1_ASAP7_75t_R  g025(.A(new_n111_), .B(p1), .C(p17), .Y(o12));
  AND3x1_ASAP7_75t_R   g026(.A(new_n111_), .B(p17), .C(p11), .Y(new_n113_));
  NAND2x1_ASAP7_75t_R  g027(.A(p18), .B(new_n113_), .Y(o13));
  OAI21x1_ASAP7_75t_R  g028(.A1(p14), .A2(p13), .B(p19), .Y(o14));
  XOR2x2_ASAP7_75t_R   g029(.A(p24), .B(p23), .Y(new_n116_));
  XOR2x2_ASAP7_75t_R   g030(.A(p28), .B(p27), .Y(new_n117_));
  XOR2x2_ASAP7_75t_R   g031(.A(new_n116_), .B(new_n117_), .Y(new_n118_));
  XOR2x2_ASAP7_75t_R   g032(.A(p21), .B(p20), .Y(new_n119_));
  INVx1_ASAP7_75t_R    g033(.A(p22), .Y(new_n120_));
  XOR2x2_ASAP7_75t_R   g034(.A(new_n119_), .B(new_n120_), .Y(new_n121_));
  XOR2x2_ASAP7_75t_R   g035(.A(new_n118_), .B(new_n121_), .Y(new_n122_));
  XOR2x2_ASAP7_75t_R   g036(.A(p29), .B(p26), .Y(new_n123_));
  XOR2x2_ASAP7_75t_R   g037(.A(new_n123_), .B(p25), .Y(new_n124_));
  XOR2x2_ASAP7_75t_R   g038(.A(new_n122_), .B(new_n124_), .Y(o15));
  XOR2x2_ASAP7_75t_R   g039(.A(p33), .B(p32), .Y(new_n126_));
  XOR2x2_ASAP7_75t_R   g040(.A(p36), .B(p37), .Y(new_n127_));
  XOR2x2_ASAP7_75t_R   g041(.A(new_n126_), .B(new_n127_), .Y(new_n128_));
  XOR2x2_ASAP7_75t_R   g042(.A(p31), .B(p20), .Y(new_n129_));
  INVx1_ASAP7_75t_R    g043(.A(p30), .Y(new_n130_));
  XOR2x2_ASAP7_75t_R   g044(.A(new_n129_), .B(new_n130_), .Y(new_n131_));
  XOR2x2_ASAP7_75t_R   g045(.A(new_n128_), .B(new_n131_), .Y(new_n132_));
  XOR2x2_ASAP7_75t_R   g046(.A(p34), .B(p38), .Y(new_n133_));
  XOR2x2_ASAP7_75t_R   g047(.A(new_n133_), .B(p35), .Y(new_n134_));
  XOR2x2_ASAP7_75t_R   g048(.A(new_n132_), .B(new_n134_), .Y(o16));
  AND3x1_ASAP7_75t_R   g049(.A(p0), .B(p11), .C(p59), .Y(new_n136_));
  NAND2x1_ASAP7_75t_R  g050(.A(p15), .B(p6), .Y(new_n137_));
  NOR3x1_ASAP7_75t_R   g051(.A(new_n136_), .B(new_n98_), .C(new_n137_), .Y(new_n138_));
  AND4x2_ASAP7_75t_R   g052(.A(p2), .B(p9), .C(p10), .D(p15), .Y(new_n139_));
  INVx1_ASAP7_75t_R    g053(.A(p16), .Y(new_n140_));
  NOR3x1_ASAP7_75t_R   g054(.A(new_n88_), .B(new_n140_), .C(p44), .Y(new_n141_));
  AOI22x1_ASAP7_75t_R  g055(.A1(new_n138_), .A2(p28), .B1(new_n139_), .B2(new_n141_), .Y(new_n142_));
  OAI21x1_ASAP7_75t_R  g056(.A1(p59), .A2(p6), .B(p15), .Y(new_n143_));
  NOR2x1_ASAP7_75t_R   g057(.A(new_n101_), .B(new_n143_), .Y(new_n144_));
  NAND2x1_ASAP7_75t_R  g058(.A(p46), .B(p11), .Y(new_n145_));
  AOI21x1_ASAP7_75t_R  g059(.A1(p59), .A2(p6), .B(new_n145_), .Y(new_n146_));
  NAND3x1_ASAP7_75t_R  g060(.A(new_n144_), .B(new_n146_), .C(p28), .Y(new_n147_));
  AOI211x1_ASAP7_75t_R g061(.A1(p46), .A2(p11), .B(new_n101_), .C(new_n137_), .Y(new_n148_));
  INVx1_ASAP7_75t_R    g062(.A(p9), .Y(new_n149_));
  AO21x1_ASAP7_75t_R   g063(.A1(p45), .A2(new_n149_), .B(p37), .Y(new_n150_));
  AOI21x1_ASAP7_75t_R  g064(.A1(p45), .A2(new_n148_), .B(new_n150_), .Y(new_n151_));
  AND3x1_ASAP7_75t_R   g065(.A(new_n142_), .B(new_n147_), .C(new_n151_), .Y(new_n152_));
  AO31x2_ASAP7_75t_R   g066(.A1(new_n145_), .A2(p10), .A3(p15), .B(new_n149_), .Y(new_n153_));
  OA21x2_ASAP7_75t_R   g067(.A1(p6), .A2(new_n149_), .B(p45), .Y(new_n154_));
  AOI22x1_ASAP7_75t_R  g068(.A1(new_n153_), .A2(new_n154_), .B1(new_n139_), .B2(new_n141_), .Y(new_n155_));
  NAND3x1_ASAP7_75t_R  g069(.A(p0), .B(p11), .C(p59), .Y(new_n156_));
  AND4x2_ASAP7_75t_R   g070(.A(p8), .B(p9), .C(p15), .D(p6), .Y(new_n157_));
  NAND2x1_ASAP7_75t_R  g071(.A(new_n156_), .B(new_n157_), .Y(new_n158_));
  NAND2x1_ASAP7_75t_R  g072(.A(new_n146_), .B(new_n144_), .Y(new_n159_));
  INVx1_ASAP7_75t_R    g073(.A(p28), .Y(new_n160_));
  AO21x1_ASAP7_75t_R   g074(.A1(new_n158_), .A2(new_n159_), .B(new_n160_), .Y(new_n161_));
  INVx1_ASAP7_75t_R    g075(.A(p37), .Y(new_n162_));
  AOI21x1_ASAP7_75t_R  g076(.A1(new_n155_), .A2(new_n161_), .B(new_n162_), .Y(new_n163_));
  NOR2x1_ASAP7_75t_R   g077(.A(new_n152_), .B(new_n163_), .Y(new_n164_));
  XOR2x2_ASAP7_75t_R   g078(.A(new_n164_), .B(p51), .Y(new_n165_));
  AND2x2_ASAP7_75t_R   g079(.A(p47), .B(new_n164_), .Y(new_n166_));
  AND3x1_ASAP7_75t_R   g080(.A(p40), .B(p39), .C(p59), .Y(new_n167_));
  AND2x2_ASAP7_75t_R   g081(.A(new_n167_), .B(new_n113_), .Y(new_n168_));
  AO22x1_ASAP7_75t_R   g082(.A1(p41), .A2(p42), .B1(p49), .B2(p27), .Y(new_n169_));
  AO21x1_ASAP7_75t_R   g083(.A1(p37), .A2(new_n168_), .B(new_n169_), .Y(new_n170_));
  INVx1_ASAP7_75t_R    g084(.A(p48), .Y(new_n171_));
  INVx1_ASAP7_75t_R    g085(.A(p43), .Y(new_n172_));
  OA21x2_ASAP7_75t_R   g086(.A1(new_n162_), .A2(new_n171_), .B(new_n172_), .Y(new_n173_));
  AOI21x1_ASAP7_75t_R  g087(.A1(new_n155_), .A2(new_n161_), .B(new_n173_), .Y(new_n174_));
  OR3x1_ASAP7_75t_R    g088(.A(new_n166_), .B(new_n170_), .C(new_n174_), .Y(new_n175_));
  AOI21x1_ASAP7_75t_R  g089(.A1(p50), .A2(new_n165_), .B(new_n175_), .Y(o17));
  INVx1_ASAP7_75t_R    g090(.A(p50), .Y(new_n177_));
  AO21x1_ASAP7_75t_R   g091(.A1(new_n146_), .A2(new_n144_), .B(new_n138_), .Y(new_n178_));
  AND2x2_ASAP7_75t_R   g092(.A(new_n139_), .B(new_n141_), .Y(new_n179_));
  OA21x2_ASAP7_75t_R   g093(.A1(p6), .A2(new_n149_), .B(p52), .Y(new_n180_));
  AO21x1_ASAP7_75t_R   g094(.A1(new_n180_), .A2(new_n153_), .B(p34), .Y(new_n181_));
  AO211x2_ASAP7_75t_R  g095(.A1(new_n178_), .A2(p25), .B(new_n179_), .C(new_n181_), .Y(new_n182_));
  AOI21x1_ASAP7_75t_R  g096(.A1(new_n153_), .A2(new_n180_), .B(new_n179_), .Y(new_n183_));
  NAND2x1_ASAP7_75t_R  g097(.A(p25), .B(new_n178_), .Y(new_n184_));
  INVx1_ASAP7_75t_R    g098(.A(p34), .Y(new_n185_));
  AO21x1_ASAP7_75t_R   g099(.A1(new_n183_), .A2(new_n184_), .B(new_n185_), .Y(new_n186_));
  NAND2x1_ASAP7_75t_R  g100(.A(new_n182_), .B(new_n186_), .Y(new_n187_));
  OA21x2_ASAP7_75t_R   g101(.A1(p6), .A2(new_n149_), .B(p53), .Y(new_n188_));
  AOI22x1_ASAP7_75t_R  g102(.A1(new_n153_), .A2(new_n188_), .B1(new_n139_), .B2(new_n141_), .Y(new_n189_));
  NAND3x1_ASAP7_75t_R  g103(.A(new_n144_), .B(new_n146_), .C(p27), .Y(new_n190_));
  NAND3x1_ASAP7_75t_R  g104(.A(new_n157_), .B(p27), .C(new_n156_), .Y(new_n191_));
  INVx1_ASAP7_75t_R    g105(.A(p36), .Y(new_n192_));
  AO31x2_ASAP7_75t_R   g106(.A1(new_n189_), .A2(new_n190_), .A3(new_n191_), .B(new_n192_), .Y(new_n193_));
  AOI22x1_ASAP7_75t_R  g107(.A1(new_n138_), .A2(p26), .B1(new_n139_), .B2(new_n141_), .Y(new_n194_));
  NAND3x1_ASAP7_75t_R  g108(.A(new_n144_), .B(new_n146_), .C(p26), .Y(new_n195_));
  OA21x2_ASAP7_75t_R   g109(.A1(p6), .A2(new_n149_), .B(p54), .Y(new_n196_));
  AOI21x1_ASAP7_75t_R  g110(.A1(new_n196_), .A2(new_n153_), .B(p35), .Y(new_n197_));
  AND3x1_ASAP7_75t_R   g111(.A(new_n194_), .B(new_n195_), .C(new_n197_), .Y(new_n198_));
  INVx1_ASAP7_75t_R    g112(.A(p35), .Y(new_n199_));
  NAND2x1_ASAP7_75t_R  g113(.A(new_n196_), .B(new_n153_), .Y(new_n200_));
  AND3x1_ASAP7_75t_R   g114(.A(new_n194_), .B(new_n195_), .C(new_n200_), .Y(new_n201_));
  OA22x2_ASAP7_75t_R   g115(.A1(new_n193_), .A2(new_n198_), .B1(new_n199_), .B2(new_n201_), .Y(new_n202_));
  AO21x1_ASAP7_75t_R   g116(.A1(p45), .A2(new_n148_), .B(new_n150_), .Y(new_n203_));
  INVx1_ASAP7_75t_R    g117(.A(new_n147_), .Y(new_n204_));
  NAND2x1_ASAP7_75t_R  g118(.A(new_n139_), .B(new_n141_), .Y(new_n205_));
  OAI21x1_ASAP7_75t_R  g119(.A1(new_n160_), .A2(new_n158_), .B(new_n205_), .Y(new_n206_));
  OA31x2_ASAP7_75t_R   g120(.A1(new_n203_), .A2(new_n204_), .A3(new_n206_), .B1(p51), .Y(new_n207_));
  INVx1_ASAP7_75t_R    g121(.A(p26), .Y(new_n208_));
  OR4x2_ASAP7_75t_R    g122(.A(new_n136_), .B(new_n208_), .C(new_n98_), .D(new_n137_), .Y(new_n209_));
  NAND3x1_ASAP7_75t_R  g123(.A(new_n195_), .B(new_n209_), .C(new_n205_), .Y(new_n210_));
  INVx1_ASAP7_75t_R    g124(.A(new_n197_), .Y(new_n211_));
  AO21x1_ASAP7_75t_R   g125(.A1(new_n188_), .A2(new_n153_), .B(p36), .Y(new_n212_));
  NAND3x1_ASAP7_75t_R  g126(.A(new_n190_), .B(new_n205_), .C(new_n191_), .Y(new_n213_));
  OA22x2_ASAP7_75t_R   g127(.A1(new_n210_), .A2(new_n211_), .B1(new_n212_), .B2(new_n213_), .Y(new_n214_));
  OAI21x1_ASAP7_75t_R  g128(.A1(new_n163_), .A2(new_n207_), .B(new_n214_), .Y(new_n215_));
  AND3x1_ASAP7_75t_R   g129(.A(new_n187_), .B(new_n202_), .C(new_n215_), .Y(new_n216_));
  NAND2x1_ASAP7_75t_R  g130(.A(p28), .B(new_n138_), .Y(new_n217_));
  AO31x2_ASAP7_75t_R   g131(.A1(new_n155_), .A2(new_n147_), .A3(new_n217_), .B(new_n162_), .Y(new_n218_));
  INVx1_ASAP7_75t_R    g132(.A(p51), .Y(new_n219_));
  AO31x2_ASAP7_75t_R   g133(.A1(new_n142_), .A2(new_n147_), .A3(new_n151_), .B(new_n219_), .Y(new_n220_));
  NAND2x1_ASAP7_75t_R  g134(.A(new_n218_), .B(new_n220_), .Y(new_n221_));
  OAI22x1_ASAP7_75t_R  g135(.A1(new_n193_), .A2(new_n198_), .B1(new_n201_), .B2(new_n199_), .Y(new_n222_));
  AO21x1_ASAP7_75t_R   g136(.A1(new_n221_), .A2(new_n214_), .B(new_n222_), .Y(new_n223_));
  AND3x1_ASAP7_75t_R   g137(.A(new_n223_), .B(new_n186_), .C(new_n182_), .Y(new_n224_));
  INVx1_ASAP7_75t_R    g138(.A(p47), .Y(new_n225_));
  AOI22x1_ASAP7_75t_R  g139(.A1(new_n168_), .A2(p34), .B1(p49), .B2(p24), .Y(new_n226_));
  OA21x2_ASAP7_75t_R   g140(.A1(new_n185_), .A2(new_n171_), .B(new_n172_), .Y(new_n227_));
  AO21x1_ASAP7_75t_R   g141(.A1(new_n183_), .A2(new_n184_), .B(new_n227_), .Y(new_n228_));
  OA211x2_ASAP7_75t_R  g142(.A1(new_n225_), .A2(new_n187_), .B(new_n226_), .C(new_n228_), .Y(new_n229_));
  OA31x2_ASAP7_75t_R   g143(.A1(new_n177_), .A2(new_n216_), .A3(new_n224_), .B1(new_n229_), .Y(o18));
  AND2x2_ASAP7_75t_R   g144(.A(new_n191_), .B(new_n190_), .Y(new_n231_));
  NAND2x1_ASAP7_75t_R  g145(.A(new_n189_), .B(new_n231_), .Y(new_n232_));
  OA21x2_ASAP7_75t_R   g146(.A1(p36), .A2(new_n232_), .B(new_n221_), .Y(new_n233_));
  AOI21x1_ASAP7_75t_R  g147(.A1(new_n189_), .A2(new_n231_), .B(new_n192_), .Y(new_n234_));
  AND3x1_ASAP7_75t_R   g148(.A(new_n195_), .B(new_n209_), .C(new_n205_), .Y(new_n235_));
  AOI21x1_ASAP7_75t_R  g149(.A1(new_n200_), .A2(new_n235_), .B(new_n199_), .Y(new_n236_));
  NOR2x1_ASAP7_75t_R   g150(.A(new_n198_), .B(new_n236_), .Y(new_n237_));
  OR3x1_ASAP7_75t_R    g151(.A(new_n233_), .B(new_n234_), .C(new_n237_), .Y(new_n238_));
  AO21x1_ASAP7_75t_R   g152(.A1(new_n234_), .A2(new_n237_), .B(new_n177_), .Y(new_n239_));
  AOI21x1_ASAP7_75t_R  g153(.A1(new_n237_), .A2(new_n233_), .B(new_n239_), .Y(new_n240_));
  OR3x1_ASAP7_75t_R    g154(.A(new_n236_), .B(new_n225_), .C(new_n198_), .Y(new_n241_));
  OA21x2_ASAP7_75t_R   g155(.A1(new_n171_), .A2(new_n199_), .B(new_n172_), .Y(new_n242_));
  AO22x1_ASAP7_75t_R   g156(.A1(p41), .A2(p55), .B1(p49), .B2(p25), .Y(new_n243_));
  AOI21x1_ASAP7_75t_R  g157(.A1(p35), .A2(new_n168_), .B(new_n243_), .Y(new_n244_));
  OA21x2_ASAP7_75t_R   g158(.A1(new_n201_), .A2(new_n242_), .B(new_n244_), .Y(new_n245_));
  NAND2x1_ASAP7_75t_R  g159(.A(new_n241_), .B(new_n245_), .Y(new_n246_));
  AOI21x1_ASAP7_75t_R  g160(.A1(new_n238_), .A2(new_n240_), .B(new_n246_), .Y(o19));
  OA21x2_ASAP7_75t_R   g161(.A1(new_n213_), .A2(new_n212_), .B(new_n193_), .Y(new_n248_));
  XOR2x2_ASAP7_75t_R   g162(.A(new_n248_), .B(new_n221_), .Y(new_n249_));
  AO21x1_ASAP7_75t_R   g163(.A1(p48), .A2(new_n232_), .B(new_n168_), .Y(new_n250_));
  AO22x1_ASAP7_75t_R   g164(.A1(p41), .A2(p56), .B1(p49), .B2(p26), .Y(new_n251_));
  AO21x1_ASAP7_75t_R   g165(.A1(p43), .A2(new_n232_), .B(new_n251_), .Y(new_n252_));
  AO21x1_ASAP7_75t_R   g166(.A1(p47), .A2(new_n248_), .B(new_n252_), .Y(new_n253_));
  AO21x1_ASAP7_75t_R   g167(.A1(p36), .A2(new_n250_), .B(new_n253_), .Y(new_n254_));
  AOI21x1_ASAP7_75t_R  g168(.A1(p50), .A2(new_n249_), .B(new_n254_), .Y(o20));
  INVx1_ASAP7_75t_R    g169(.A(p23), .Y(new_n256_));
  AO21x1_ASAP7_75t_R   g170(.A1(new_n158_), .A2(new_n159_), .B(new_n256_), .Y(new_n257_));
  INVx1_ASAP7_75t_R    g171(.A(p6), .Y(new_n258_));
  NOR3x1_ASAP7_75t_R   g172(.A(new_n88_), .B(p44), .C(new_n258_), .Y(new_n259_));
  AND2x2_ASAP7_75t_R   g173(.A(p16), .B(p53), .Y(new_n260_));
  AND2x2_ASAP7_75t_R   g174(.A(p57), .B(p6), .Y(new_n261_));
  AO31x2_ASAP7_75t_R   g175(.A1(new_n109_), .A2(new_n260_), .A3(new_n145_), .B(new_n261_), .Y(new_n262_));
  AOI211x1_ASAP7_75t_R g176(.A1(new_n139_), .A2(new_n259_), .B(p32), .C(new_n262_), .Y(new_n263_));
  INVx1_ASAP7_75t_R    g177(.A(p24), .Y(new_n264_));
  AO21x1_ASAP7_75t_R   g178(.A1(new_n158_), .A2(new_n159_), .B(new_n264_), .Y(new_n265_));
  AND2x2_ASAP7_75t_R   g179(.A(p16), .B(p45), .Y(new_n266_));
  AND2x2_ASAP7_75t_R   g180(.A(p57), .B(p58), .Y(new_n267_));
  AO31x2_ASAP7_75t_R   g181(.A1(new_n109_), .A2(new_n266_), .A3(new_n145_), .B(new_n267_), .Y(new_n268_));
  AOI211x1_ASAP7_75t_R g182(.A1(new_n139_), .A2(new_n259_), .B(p33), .C(new_n268_), .Y(new_n269_));
  AOI22x1_ASAP7_75t_R  g183(.A1(new_n257_), .A2(new_n263_), .B1(new_n265_), .B2(new_n269_), .Y(new_n270_));
  AND2x2_ASAP7_75t_R   g184(.A(p57), .B(p15), .Y(new_n271_));
  AOI211x1_ASAP7_75t_R g185(.A1(new_n139_), .A2(new_n259_), .B(p31), .C(new_n271_), .Y(new_n272_));
  AND2x2_ASAP7_75t_R   g186(.A(p54), .B(p16), .Y(new_n273_));
  AND3x1_ASAP7_75t_R   g187(.A(new_n109_), .B(new_n273_), .C(new_n145_), .Y(new_n274_));
  AND3x1_ASAP7_75t_R   g188(.A(new_n144_), .B(p22), .C(new_n146_), .Y(new_n275_));
  AOI211x1_ASAP7_75t_R g189(.A1(p22), .A2(new_n138_), .B(new_n274_), .C(new_n275_), .Y(new_n276_));
  NAND2x1_ASAP7_75t_R  g190(.A(new_n272_), .B(new_n276_), .Y(new_n277_));
  NAND3x1_ASAP7_75t_R  g191(.A(new_n182_), .B(new_n270_), .C(new_n277_), .Y(new_n278_));
  AO31x2_ASAP7_75t_R   g192(.A1(new_n215_), .A2(new_n186_), .A3(new_n202_), .B(new_n278_), .Y(new_n279_));
  NAND2x1_ASAP7_75t_R  g193(.A(p21), .B(new_n178_), .Y(new_n280_));
  AND2x2_ASAP7_75t_R   g194(.A(p52), .B(p16), .Y(new_n281_));
  AND3x1_ASAP7_75t_R   g195(.A(new_n109_), .B(new_n281_), .C(new_n145_), .Y(new_n282_));
  NAND2x1_ASAP7_75t_R  g196(.A(p8), .B(p57), .Y(new_n283_));
  NAND2x1_ASAP7_75t_R  g197(.A(new_n139_), .B(new_n259_), .Y(new_n284_));
  NAND2x1_ASAP7_75t_R  g198(.A(new_n283_), .B(new_n284_), .Y(new_n285_));
  NOR2x1_ASAP7_75t_R   g199(.A(new_n282_), .B(new_n285_), .Y(new_n286_));
  AO21x1_ASAP7_75t_R   g200(.A1(new_n280_), .A2(new_n286_), .B(new_n130_), .Y(new_n287_));
  AOI22x1_ASAP7_75t_R  g201(.A1(new_n276_), .A2(new_n272_), .B1(new_n257_), .B2(new_n263_), .Y(new_n288_));
  INVx1_ASAP7_75t_R    g202(.A(new_n268_), .Y(new_n289_));
  NAND3x1_ASAP7_75t_R  g203(.A(new_n144_), .B(new_n146_), .C(p24), .Y(new_n290_));
  OR4x2_ASAP7_75t_R    g204(.A(new_n136_), .B(new_n264_), .C(new_n98_), .D(new_n137_), .Y(new_n291_));
  AND4x2_ASAP7_75t_R   g205(.A(new_n289_), .B(new_n284_), .C(new_n290_), .D(new_n291_), .Y(new_n292_));
  INVx1_ASAP7_75t_R    g206(.A(p33), .Y(new_n293_));
  AND3x1_ASAP7_75t_R   g207(.A(new_n145_), .B(p16), .C(p53), .Y(new_n294_));
  AOI21x1_ASAP7_75t_R  g208(.A1(new_n109_), .A2(new_n294_), .B(new_n261_), .Y(new_n295_));
  NAND3x1_ASAP7_75t_R  g209(.A(new_n144_), .B(new_n146_), .C(p23), .Y(new_n296_));
  OR4x2_ASAP7_75t_R    g210(.A(new_n136_), .B(new_n256_), .C(new_n98_), .D(new_n137_), .Y(new_n297_));
  AND4x2_ASAP7_75t_R   g211(.A(new_n295_), .B(new_n296_), .C(new_n284_), .D(new_n297_), .Y(new_n298_));
  INVx1_ASAP7_75t_R    g212(.A(p32), .Y(new_n299_));
  OAI22x1_ASAP7_75t_R  g213(.A1(new_n292_), .A2(new_n293_), .B1(new_n298_), .B2(new_n299_), .Y(new_n300_));
  AOI211x1_ASAP7_75t_R g214(.A1(new_n139_), .A2(new_n259_), .B(new_n271_), .C(new_n274_), .Y(new_n301_));
  AO21x1_ASAP7_75t_R   g215(.A1(new_n158_), .A2(new_n159_), .B(new_n120_), .Y(new_n302_));
  INVx1_ASAP7_75t_R    g216(.A(p31), .Y(new_n303_));
  AOI21x1_ASAP7_75t_R  g217(.A1(new_n301_), .A2(new_n302_), .B(new_n303_), .Y(new_n304_));
  AOI21x1_ASAP7_75t_R  g218(.A1(new_n288_), .A2(new_n300_), .B(new_n304_), .Y(new_n305_));
  AND2x2_ASAP7_75t_R   g219(.A(new_n287_), .B(new_n305_), .Y(new_n306_));
  AND3x1_ASAP7_75t_R   g220(.A(new_n284_), .B(new_n130_), .C(new_n283_), .Y(new_n307_));
  AOI21x1_ASAP7_75t_R  g221(.A1(p21), .A2(new_n138_), .B(new_n282_), .Y(new_n308_));
  NAND2x1_ASAP7_75t_R  g222(.A(new_n87_), .B(new_n258_), .Y(new_n309_));
  AND2x2_ASAP7_75t_R   g223(.A(p46), .B(p11), .Y(new_n310_));
  NAND2x1_ASAP7_75t_R  g224(.A(p59), .B(p6), .Y(new_n311_));
  AND4x2_ASAP7_75t_R   g225(.A(new_n309_), .B(new_n109_), .C(new_n310_), .D(new_n311_), .Y(new_n312_));
  NAND2x1_ASAP7_75t_R  g226(.A(p21), .B(new_n312_), .Y(new_n313_));
  NAND3x1_ASAP7_75t_R  g227(.A(new_n307_), .B(new_n308_), .C(new_n313_), .Y(new_n314_));
  INVx1_ASAP7_75t_R    g228(.A(new_n314_), .Y(new_n315_));
  AO21x1_ASAP7_75t_R   g229(.A1(new_n279_), .A2(new_n306_), .B(new_n315_), .Y(o21));
  NAND2x1_ASAP7_75t_R  g230(.A(new_n269_), .B(new_n265_), .Y(new_n317_));
  NAND2x1_ASAP7_75t_R  g231(.A(new_n291_), .B(new_n290_), .Y(new_n318_));
  AO21x1_ASAP7_75t_R   g232(.A1(new_n139_), .A2(new_n259_), .B(new_n268_), .Y(new_n319_));
  OAI21x1_ASAP7_75t_R  g233(.A1(new_n318_), .A2(new_n319_), .B(p33), .Y(new_n320_));
  NAND2x1_ASAP7_75t_R  g234(.A(new_n317_), .B(new_n320_), .Y(new_n321_));
  AOI21x1_ASAP7_75t_R  g235(.A1(new_n183_), .A2(new_n184_), .B(new_n185_), .Y(new_n322_));
  AOI211x1_ASAP7_75t_R g236(.A1(p25), .A2(new_n178_), .B(new_n179_), .C(new_n181_), .Y(new_n323_));
  OAI22x1_ASAP7_75t_R  g237(.A1(new_n210_), .A2(new_n211_), .B1(new_n213_), .B2(new_n212_), .Y(new_n324_));
  AOI211x1_ASAP7_75t_R g238(.A1(new_n218_), .A2(new_n220_), .B(new_n323_), .C(new_n324_), .Y(new_n325_));
  AOI211x1_ASAP7_75t_R g239(.A1(new_n182_), .A2(new_n222_), .B(new_n322_), .C(new_n325_), .Y(new_n326_));
  NAND2x1_ASAP7_75t_R  g240(.A(new_n321_), .B(new_n326_), .Y(new_n327_));
  OA21x2_ASAP7_75t_R   g241(.A1(new_n321_), .A2(new_n326_), .B(p50), .Y(new_n328_));
  AOI22x1_ASAP7_75t_R  g242(.A1(new_n168_), .A2(p33), .B1(p49), .B2(p23), .Y(new_n329_));
  OAI21x1_ASAP7_75t_R  g243(.A1(new_n172_), .A2(new_n292_), .B(new_n329_), .Y(new_n330_));
  AND3x1_ASAP7_75t_R   g244(.A(new_n320_), .B(p47), .C(new_n317_), .Y(new_n331_));
  NOR2x1_ASAP7_75t_R   g245(.A(new_n171_), .B(new_n320_), .Y(new_n332_));
  OR3x1_ASAP7_75t_R    g246(.A(new_n330_), .B(new_n331_), .C(new_n332_), .Y(new_n333_));
  AOI21x1_ASAP7_75t_R  g247(.A1(new_n327_), .A2(new_n328_), .B(new_n333_), .Y(o22));
  NAND2x1_ASAP7_75t_R  g248(.A(new_n277_), .B(new_n270_), .Y(new_n335_));
  NAND2x1_ASAP7_75t_R  g249(.A(new_n314_), .B(new_n287_), .Y(new_n336_));
  OR3x1_ASAP7_75t_R    g250(.A(new_n326_), .B(new_n335_), .C(new_n336_), .Y(new_n337_));
  AOI21x1_ASAP7_75t_R  g251(.A1(new_n280_), .A2(new_n286_), .B(new_n130_), .Y(new_n338_));
  NOR2x1_ASAP7_75t_R   g252(.A(new_n338_), .B(new_n315_), .Y(new_n339_));
  AOI211x1_ASAP7_75t_R g253(.A1(new_n300_), .A2(new_n288_), .B(new_n304_), .C(new_n339_), .Y(new_n340_));
  OAI21x1_ASAP7_75t_R  g254(.A1(new_n336_), .A2(new_n305_), .B(p50), .Y(new_n341_));
  AOI21x1_ASAP7_75t_R  g255(.A1(new_n279_), .A2(new_n340_), .B(new_n341_), .Y(new_n342_));
  AOI22x1_ASAP7_75t_R  g256(.A1(new_n168_), .A2(p30), .B1(p49), .B2(p44), .Y(new_n343_));
  AO21x1_ASAP7_75t_R   g257(.A1(new_n280_), .A2(new_n286_), .B(new_n172_), .Y(new_n344_));
  OA211x2_ASAP7_75t_R  g258(.A1(new_n171_), .A2(new_n287_), .B(new_n343_), .C(new_n344_), .Y(new_n345_));
  OAI21x1_ASAP7_75t_R  g259(.A1(new_n225_), .A2(new_n336_), .B(new_n345_), .Y(new_n346_));
  AOI21x1_ASAP7_75t_R  g260(.A1(new_n337_), .A2(new_n342_), .B(new_n346_), .Y(o23));
  INVx1_ASAP7_75t_R    g261(.A(new_n270_), .Y(new_n348_));
  AOI21x1_ASAP7_75t_R  g262(.A1(new_n276_), .A2(new_n272_), .B(new_n304_), .Y(new_n349_));
  AND3x1_ASAP7_75t_R   g263(.A(new_n263_), .B(new_n297_), .C(new_n296_), .Y(new_n350_));
  NAND2x1_ASAP7_75t_R  g264(.A(new_n297_), .B(new_n296_), .Y(new_n351_));
  AO21x1_ASAP7_75t_R   g265(.A1(new_n139_), .A2(new_n259_), .B(new_n262_), .Y(new_n352_));
  OAI21x1_ASAP7_75t_R  g266(.A1(new_n351_), .A2(new_n352_), .B(p32), .Y(new_n353_));
  OAI21x1_ASAP7_75t_R  g267(.A1(new_n350_), .A2(new_n320_), .B(new_n353_), .Y(new_n354_));
  NOR2x1_ASAP7_75t_R   g268(.A(new_n349_), .B(new_n354_), .Y(new_n355_));
  OAI21x1_ASAP7_75t_R  g269(.A1(new_n348_), .A2(new_n326_), .B(new_n355_), .Y(new_n356_));
  INVx1_ASAP7_75t_R    g270(.A(new_n349_), .Y(new_n357_));
  AOI21x1_ASAP7_75t_R  g271(.A1(new_n349_), .A2(new_n354_), .B(new_n177_), .Y(new_n358_));
  OA31x2_ASAP7_75t_R   g272(.A1(new_n348_), .A2(new_n357_), .A3(new_n326_), .B1(new_n358_), .Y(new_n359_));
  AOI22x1_ASAP7_75t_R  g273(.A1(new_n168_), .A2(p31), .B1(p49), .B2(p21), .Y(new_n360_));
  AO21x1_ASAP7_75t_R   g274(.A1(new_n301_), .A2(new_n302_), .B(new_n172_), .Y(new_n361_));
  NAND2x1_ASAP7_75t_R  g275(.A(p48), .B(new_n304_), .Y(new_n362_));
  AND3x1_ASAP7_75t_R   g276(.A(new_n360_), .B(new_n361_), .C(new_n362_), .Y(new_n363_));
  OAI21x1_ASAP7_75t_R  g277(.A1(new_n225_), .A2(new_n357_), .B(new_n363_), .Y(new_n364_));
  AOI21x1_ASAP7_75t_R  g278(.A1(new_n356_), .A2(new_n359_), .B(new_n364_), .Y(o24));
  XOR2x2_ASAP7_75t_R   g279(.A(new_n298_), .B(new_n299_), .Y(new_n366_));
  NAND2x1_ASAP7_75t_R  g280(.A(new_n317_), .B(new_n366_), .Y(new_n367_));
  AO21x1_ASAP7_75t_R   g281(.A1(new_n320_), .A2(new_n326_), .B(new_n367_), .Y(new_n368_));
  INVx1_ASAP7_75t_R    g282(.A(new_n320_), .Y(new_n369_));
  NOR2x1_ASAP7_75t_R   g283(.A(new_n369_), .B(new_n366_), .Y(new_n370_));
  NAND2x1_ASAP7_75t_R  g284(.A(new_n317_), .B(new_n182_), .Y(new_n371_));
  AO31x2_ASAP7_75t_R   g285(.A1(new_n215_), .A2(new_n186_), .A3(new_n202_), .B(new_n371_), .Y(new_n372_));
  AOI21x1_ASAP7_75t_R  g286(.A1(new_n370_), .A2(new_n372_), .B(new_n177_), .Y(new_n373_));
  AOI22x1_ASAP7_75t_R  g287(.A1(new_n168_), .A2(p32), .B1(p49), .B2(p22), .Y(new_n374_));
  OAI21x1_ASAP7_75t_R  g288(.A1(new_n172_), .A2(new_n298_), .B(new_n374_), .Y(new_n375_));
  AOI21x1_ASAP7_75t_R  g289(.A1(p47), .A2(new_n366_), .B(new_n375_), .Y(new_n376_));
  OAI21x1_ASAP7_75t_R  g290(.A1(new_n171_), .A2(new_n353_), .B(new_n376_), .Y(new_n377_));
  AOI21x1_ASAP7_75t_R  g291(.A1(new_n368_), .A2(new_n373_), .B(new_n377_), .Y(o25));
endmodule


