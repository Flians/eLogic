// Benchmark "/tmp/" written by ABC on Mon Oct 12 15:07:53 2026

module \/tmp/  ( 
    p43, p50, p7, p4, p39, p53, p8, p33, p3, p55, p58, p14, p18, p10, p36,
    p54, p1, p2, p40, p19, p42, p28, p5, p56, p59, p0, p6, p9, p26, p37,
    p48, p34, p47, p35, p57, p45, p16, p38, p44, p51, p20, p12, p22, p41,
    p29, p52, p49, p25, p31, p46, p11, p30, p15, p32, p13, p24, p27, p21,
    p23, p17,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25  );
  input  p43, p50, p7, p4, p39, p53, p8, p33, p3, p55, p58, p14, p18,
    p10, p36, p54, p1, p2, p40, p19, p42, p28, p5, p56, p59, p0, p6, p9,
    p26, p37, p48, p34, p47, p35, p57, p45, p16, p38, p44, p51, p20, p12,
    p22, p41, p29, p52, p49, p25, p31, p46, p11, p30, p15, p32, p13, p24,
    p27, p21, p23, p17;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25;
  wire new_n87_, new_n88_, new_n90_, new_n91_, new_n92_, new_n94_, new_n97_,
    new_n98_, new_n100_, new_n108_, new_n110_, new_n113_, new_n114_,
    new_n115_, new_n116_, new_n117_, new_n118_, new_n119_, new_n120_,
    new_n122_, new_n123_, new_n124_, new_n125_, new_n126_, new_n127_,
    new_n128_, new_n129_, new_n131_, new_n132_, new_n133_, new_n134_,
    new_n135_, new_n136_, new_n137_, new_n138_, new_n139_, new_n140_,
    new_n141_, new_n142_, new_n143_, new_n144_, new_n145_, new_n146_,
    new_n147_, new_n148_, new_n149_, new_n150_, new_n151_, new_n152_,
    new_n153_, new_n154_, new_n155_, new_n156_, new_n157_, new_n158_,
    new_n159_, new_n160_, new_n161_, new_n162_, new_n163_, new_n164_,
    new_n166_, new_n167_, new_n168_, new_n169_, new_n170_, new_n171_,
    new_n172_, new_n173_, new_n174_, new_n175_, new_n176_, new_n177_,
    new_n178_, new_n179_, new_n180_, new_n181_, new_n182_, new_n183_,
    new_n184_, new_n185_, new_n186_, new_n187_, new_n188_, new_n189_,
    new_n190_, new_n191_, new_n192_, new_n193_, new_n194_, new_n195_,
    new_n196_, new_n197_, new_n198_, new_n199_, new_n200_, new_n201_,
    new_n202_, new_n203_, new_n204_, new_n205_, new_n206_, new_n207_,
    new_n208_, new_n209_, new_n210_, new_n211_, new_n212_, new_n213_,
    new_n214_, new_n215_, new_n216_, new_n217_, new_n218_, new_n219_,
    new_n220_, new_n221_, new_n222_, new_n223_, new_n224_, new_n225_,
    new_n226_, new_n227_, new_n229_, new_n230_, new_n231_, new_n232_,
    new_n233_, new_n234_, new_n235_, new_n236_, new_n237_, new_n238_,
    new_n239_, new_n240_, new_n241_, new_n242_, new_n243_, new_n244_,
    new_n245_, new_n247_, new_n248_, new_n249_, new_n250_, new_n251_,
    new_n252_, new_n253_, new_n255_, new_n256_, new_n257_, new_n258_,
    new_n259_, new_n260_, new_n261_, new_n262_, new_n263_, new_n264_,
    new_n265_, new_n266_, new_n267_, new_n268_, new_n269_, new_n270_,
    new_n271_, new_n272_, new_n273_, new_n274_, new_n275_, new_n276_,
    new_n277_, new_n278_, new_n279_, new_n280_, new_n281_, new_n282_,
    new_n283_, new_n284_, new_n285_, new_n286_, new_n287_, new_n288_,
    new_n289_, new_n290_, new_n291_, new_n292_, new_n293_, new_n294_,
    new_n295_, new_n296_, new_n297_, new_n298_, new_n299_, new_n300_,
    new_n301_, new_n302_, new_n303_, new_n304_, new_n305_, new_n307_,
    new_n308_, new_n309_, new_n310_, new_n311_, new_n312_, new_n313_,
    new_n314_, new_n315_, new_n316_, new_n317_, new_n318_, new_n319_,
    new_n320_, new_n322_, new_n323_, new_n324_, new_n325_, new_n326_,
    new_n327_, new_n328_, new_n329_, new_n330_, new_n331_, new_n332_,
    new_n333_, new_n334_, new_n336_, new_n337_, new_n338_, new_n339_,
    new_n340_, new_n341_, new_n342_, new_n343_, new_n344_, new_n345_,
    new_n346_, new_n347_, new_n348_, new_n349_, new_n351_, new_n352_,
    new_n353_, new_n354_, new_n355_, new_n356_, new_n357_, new_n358_,
    new_n359_, new_n360_, new_n361_, new_n362_;
  INVx1_ASAP7_75t_R    g000(.A(p59), .Y(new_n87_));
  NAND2x1_ASAP7_75t_R  g001(.A(p1), .B(p0), .Y(new_n88_));
  OR2x4_ASAP7_75t_R    g002(.A(new_n87_), .B(new_n88_), .Y(o0));
  INVx1_ASAP7_75t_R    g003(.A(p3), .Y(new_n90_));
  INVx1_ASAP7_75t_R    g004(.A(p1), .Y(new_n91_));
  INVx1_ASAP7_75t_R    g005(.A(p2), .Y(new_n92_));
  OR3x1_ASAP7_75t_R    g006(.A(new_n90_), .B(new_n91_), .C(new_n92_), .Y(o1));
  AND3x1_ASAP7_75t_R   g007(.A(p3), .B(p1), .C(p59), .Y(new_n94_));
  INVx1_ASAP7_75t_R    g008(.A(new_n94_), .Y(o2));
  NAND2x1_ASAP7_75t_R  g009(.A(p4), .B(p5), .Y(o3));
  AND2x2_ASAP7_75t_R   g010(.A(p8), .B(p9), .Y(new_n97_));
  AND2x2_ASAP7_75t_R   g011(.A(p7), .B(p6), .Y(new_n98_));
  NAND2x1_ASAP7_75t_R  g012(.A(new_n97_), .B(new_n98_), .Y(o4));
  AND2x2_ASAP7_75t_R   g013(.A(p10), .B(p9), .Y(new_n100_));
  AND3x1_ASAP7_75t_R   g014(.A(o2), .B(new_n98_), .C(new_n100_), .Y(o5));
  AND3x1_ASAP7_75t_R   g015(.A(p2), .B(p0), .C(p11), .Y(o6));
  AND3x1_ASAP7_75t_R   g016(.A(p3), .B(p2), .C(p11), .Y(o7));
  AND3x1_ASAP7_75t_R   g017(.A(p3), .B(p59), .C(p11), .Y(o8));
  OAI21x1_ASAP7_75t_R  g018(.A1(p14), .A2(p13), .B(p12), .Y(o9));
  AND3x1_ASAP7_75t_R   g019(.A(new_n94_), .B(new_n98_), .C(new_n100_), .Y(o10));
  NAND3x1_ASAP7_75t_R  g020(.A(p10), .B(p9), .C(p15), .Y(o11));
  AND3x1_ASAP7_75t_R   g021(.A(new_n97_), .B(p7), .C(p16), .Y(new_n108_));
  NAND3x1_ASAP7_75t_R  g022(.A(new_n108_), .B(p1), .C(p17), .Y(o12));
  AND3x1_ASAP7_75t_R   g023(.A(new_n108_), .B(p11), .C(p17), .Y(new_n110_));
  NAND2x1_ASAP7_75t_R  g024(.A(p18), .B(new_n110_), .Y(o13));
  OAI21x1_ASAP7_75t_R  g025(.A1(p14), .A2(p13), .B(p19), .Y(o14));
  XOR2x2_ASAP7_75t_R   g026(.A(p29), .B(p25), .Y(new_n113_));
  XOR2x2_ASAP7_75t_R   g027(.A(new_n113_), .B(p26), .Y(new_n114_));
  XOR2x2_ASAP7_75t_R   g028(.A(p20), .B(p22), .Y(new_n115_));
  XOR2x2_ASAP7_75t_R   g029(.A(new_n115_), .B(p21), .Y(new_n116_));
  XOR2x2_ASAP7_75t_R   g030(.A(new_n114_), .B(new_n116_), .Y(new_n117_));
  XNOR2x2_ASAP7_75t_R  g031(.A(p24), .B(p23), .Y(new_n118_));
  XOR2x2_ASAP7_75t_R   g032(.A(p28), .B(p27), .Y(new_n119_));
  XOR2x2_ASAP7_75t_R   g033(.A(new_n118_), .B(new_n119_), .Y(new_n120_));
  XOR2x2_ASAP7_75t_R   g034(.A(new_n117_), .B(new_n120_), .Y(o15));
  XOR2x2_ASAP7_75t_R   g035(.A(p35), .B(p38), .Y(new_n122_));
  XOR2x2_ASAP7_75t_R   g036(.A(p33), .B(p36), .Y(new_n123_));
  XOR2x2_ASAP7_75t_R   g037(.A(new_n122_), .B(new_n123_), .Y(new_n124_));
  XOR2x2_ASAP7_75t_R   g038(.A(p37), .B(p32), .Y(new_n125_));
  XOR2x2_ASAP7_75t_R   g039(.A(new_n124_), .B(new_n125_), .Y(new_n126_));
  XNOR2x2_ASAP7_75t_R  g040(.A(p31), .B(p30), .Y(new_n127_));
  XOR2x2_ASAP7_75t_R   g041(.A(p34), .B(p20), .Y(new_n128_));
  XOR2x2_ASAP7_75t_R   g042(.A(new_n127_), .B(new_n128_), .Y(new_n129_));
  XOR2x2_ASAP7_75t_R   g043(.A(new_n126_), .B(new_n129_), .Y(o16));
  INVx1_ASAP7_75t_R    g044(.A(p51), .Y(new_n131_));
  AND3x1_ASAP7_75t_R   g045(.A(p59), .B(p0), .C(p11), .Y(new_n132_));
  NAND2x1_ASAP7_75t_R  g046(.A(p8), .B(p9), .Y(new_n133_));
  NAND2x1_ASAP7_75t_R  g047(.A(p6), .B(p15), .Y(new_n134_));
  NOR3x1_ASAP7_75t_R   g048(.A(new_n132_), .B(new_n133_), .C(new_n134_), .Y(new_n135_));
  AND4x2_ASAP7_75t_R   g049(.A(p10), .B(p2), .C(p9), .D(p15), .Y(new_n136_));
  INVx1_ASAP7_75t_R    g050(.A(p16), .Y(new_n137_));
  NOR3x1_ASAP7_75t_R   g051(.A(new_n88_), .B(new_n137_), .C(p44), .Y(new_n138_));
  AOI22x1_ASAP7_75t_R  g052(.A1(new_n135_), .A2(p28), .B1(new_n136_), .B2(new_n138_), .Y(new_n139_));
  NAND2x1_ASAP7_75t_R  g053(.A(p10), .B(p9), .Y(new_n140_));
  OAI21x1_ASAP7_75t_R  g054(.A1(p59), .A2(p6), .B(p15), .Y(new_n141_));
  NOR2x1_ASAP7_75t_R   g055(.A(new_n140_), .B(new_n141_), .Y(new_n142_));
  NAND2x1_ASAP7_75t_R  g056(.A(p46), .B(p11), .Y(new_n143_));
  AOI21x1_ASAP7_75t_R  g057(.A1(p59), .A2(p6), .B(new_n143_), .Y(new_n144_));
  NAND3x1_ASAP7_75t_R  g058(.A(new_n142_), .B(new_n144_), .C(p28), .Y(new_n145_));
  INVx1_ASAP7_75t_R    g059(.A(p9), .Y(new_n146_));
  AND2x2_ASAP7_75t_R   g060(.A(p46), .B(p11), .Y(new_n147_));
  NOR3x1_ASAP7_75t_R   g061(.A(new_n147_), .B(new_n140_), .C(new_n134_), .Y(new_n148_));
  OAI21x1_ASAP7_75t_R  g062(.A1(new_n146_), .A2(new_n148_), .B(p45), .Y(new_n149_));
  NAND3x1_ASAP7_75t_R  g063(.A(new_n139_), .B(new_n145_), .C(new_n149_), .Y(new_n150_));
  AO21x1_ASAP7_75t_R   g064(.A1(p45), .A2(new_n146_), .B(p37), .Y(new_n151_));
  AOI21x1_ASAP7_75t_R  g065(.A1(p45), .A2(new_n148_), .B(new_n151_), .Y(new_n152_));
  AND3x1_ASAP7_75t_R   g066(.A(new_n139_), .B(new_n145_), .C(new_n152_), .Y(new_n153_));
  AO21x1_ASAP7_75t_R   g067(.A1(p37), .A2(new_n150_), .B(new_n153_), .Y(new_n154_));
  AND2x2_ASAP7_75t_R   g068(.A(new_n131_), .B(new_n154_), .Y(new_n155_));
  OAI21x1_ASAP7_75t_R  g069(.A1(new_n131_), .A2(new_n154_), .B(p50), .Y(new_n156_));
  INVx1_ASAP7_75t_R    g070(.A(p47), .Y(new_n157_));
  AO21x1_ASAP7_75t_R   g071(.A1(p37), .A2(p48), .B(p43), .Y(new_n158_));
  AND3x1_ASAP7_75t_R   g072(.A(p39), .B(p40), .C(p59), .Y(new_n159_));
  AND2x2_ASAP7_75t_R   g073(.A(new_n159_), .B(new_n110_), .Y(new_n160_));
  AO22x1_ASAP7_75t_R   g074(.A1(p42), .A2(p41), .B1(p49), .B2(p27), .Y(new_n161_));
  AO21x1_ASAP7_75t_R   g075(.A1(p37), .A2(new_n160_), .B(new_n161_), .Y(new_n162_));
  AOI21x1_ASAP7_75t_R  g076(.A1(new_n150_), .A2(new_n158_), .B(new_n162_), .Y(new_n163_));
  OA21x2_ASAP7_75t_R   g077(.A1(new_n157_), .A2(new_n154_), .B(new_n163_), .Y(new_n164_));
  OA21x2_ASAP7_75t_R   g078(.A1(new_n155_), .A2(new_n156_), .B(new_n164_), .Y(o17));
  AND2x2_ASAP7_75t_R   g079(.A(p10), .B(p15), .Y(new_n166_));
  AOI21x1_ASAP7_75t_R  g080(.A1(new_n143_), .A2(new_n166_), .B(new_n146_), .Y(new_n167_));
  OA21x2_ASAP7_75t_R   g081(.A1(p6), .A2(new_n146_), .B(p52), .Y(new_n168_));
  INVx1_ASAP7_75t_R    g082(.A(new_n168_), .Y(new_n169_));
  INVx1_ASAP7_75t_R    g083(.A(p34), .Y(new_n170_));
  OAI21x1_ASAP7_75t_R  g084(.A1(new_n167_), .A2(new_n169_), .B(new_n170_), .Y(new_n171_));
  INVx1_ASAP7_75t_R    g085(.A(p25), .Y(new_n172_));
  NAND3x1_ASAP7_75t_R  g086(.A(p59), .B(p0), .C(p11), .Y(new_n173_));
  AND4x2_ASAP7_75t_R   g087(.A(p8), .B(p6), .C(p9), .D(p15), .Y(new_n174_));
  AOI22x1_ASAP7_75t_R  g088(.A1(new_n142_), .A2(new_n144_), .B1(new_n173_), .B2(new_n174_), .Y(new_n175_));
  NAND2x1_ASAP7_75t_R  g089(.A(new_n136_), .B(new_n138_), .Y(new_n176_));
  OAI21x1_ASAP7_75t_R  g090(.A1(new_n172_), .A2(new_n175_), .B(new_n176_), .Y(new_n177_));
  NOR2x1_ASAP7_75t_R   g091(.A(new_n171_), .B(new_n177_), .Y(new_n178_));
  AO21x1_ASAP7_75t_R   g092(.A1(p59), .A2(p6), .B(new_n143_), .Y(new_n179_));
  OA21x2_ASAP7_75t_R   g093(.A1(p59), .A2(p6), .B(p15), .Y(new_n180_));
  NAND2x1_ASAP7_75t_R  g094(.A(new_n100_), .B(new_n180_), .Y(new_n181_));
  NAND2x1_ASAP7_75t_R  g095(.A(new_n173_), .B(new_n174_), .Y(new_n182_));
  OAI21x1_ASAP7_75t_R  g096(.A1(new_n179_), .A2(new_n181_), .B(new_n182_), .Y(new_n183_));
  OAI21x1_ASAP7_75t_R  g097(.A1(new_n167_), .A2(new_n169_), .B(new_n176_), .Y(new_n184_));
  AOI21x1_ASAP7_75t_R  g098(.A1(p25), .A2(new_n183_), .B(new_n184_), .Y(new_n185_));
  NOR2x1_ASAP7_75t_R   g099(.A(new_n170_), .B(new_n185_), .Y(new_n186_));
  NOR2x1_ASAP7_75t_R   g100(.A(new_n178_), .B(new_n186_), .Y(new_n187_));
  INVx1_ASAP7_75t_R    g101(.A(p37), .Y(new_n188_));
  AO31x2_ASAP7_75t_R   g102(.A1(new_n139_), .A2(new_n149_), .A3(new_n145_), .B(new_n188_), .Y(new_n189_));
  AO31x2_ASAP7_75t_R   g103(.A1(new_n139_), .A2(new_n152_), .A3(new_n145_), .B(new_n131_), .Y(new_n190_));
  NAND2x1_ASAP7_75t_R  g104(.A(new_n189_), .B(new_n190_), .Y(new_n191_));
  NAND3x1_ASAP7_75t_R  g105(.A(new_n142_), .B(new_n144_), .C(p26), .Y(new_n192_));
  NAND3x1_ASAP7_75t_R  g106(.A(new_n174_), .B(p26), .C(new_n173_), .Y(new_n193_));
  NAND3x1_ASAP7_75t_R  g107(.A(new_n192_), .B(new_n176_), .C(new_n193_), .Y(new_n194_));
  INVx1_ASAP7_75t_R    g108(.A(p6), .Y(new_n195_));
  INVx1_ASAP7_75t_R    g109(.A(p54), .Y(new_n196_));
  AO21x1_ASAP7_75t_R   g110(.A1(p9), .A2(new_n195_), .B(new_n196_), .Y(new_n197_));
  INVx1_ASAP7_75t_R    g111(.A(p35), .Y(new_n198_));
  OAI21x1_ASAP7_75t_R  g112(.A1(new_n197_), .A2(new_n167_), .B(new_n198_), .Y(new_n199_));
  NAND3x1_ASAP7_75t_R  g113(.A(new_n142_), .B(new_n144_), .C(p27), .Y(new_n200_));
  NAND3x1_ASAP7_75t_R  g114(.A(new_n174_), .B(p27), .C(new_n173_), .Y(new_n201_));
  NAND3x1_ASAP7_75t_R  g115(.A(new_n200_), .B(new_n176_), .C(new_n201_), .Y(new_n202_));
  OAI21x1_ASAP7_75t_R  g116(.A1(p6), .A2(new_n146_), .B(p53), .Y(new_n203_));
  INVx1_ASAP7_75t_R    g117(.A(p36), .Y(new_n204_));
  OAI21x1_ASAP7_75t_R  g118(.A1(new_n203_), .A2(new_n167_), .B(new_n204_), .Y(new_n205_));
  OAI22x1_ASAP7_75t_R  g119(.A1(new_n194_), .A2(new_n199_), .B1(new_n202_), .B2(new_n205_), .Y(new_n206_));
  INVx1_ASAP7_75t_R    g120(.A(new_n206_), .Y(new_n207_));
  AND3x1_ASAP7_75t_R   g121(.A(new_n187_), .B(new_n191_), .C(new_n207_), .Y(new_n208_));
  AND3x1_ASAP7_75t_R   g122(.A(p10), .B(p9), .C(p15), .Y(new_n209_));
  NAND2x1_ASAP7_75t_R  g123(.A(p2), .B(new_n209_), .Y(new_n210_));
  OR3x1_ASAP7_75t_R    g124(.A(new_n88_), .B(new_n137_), .C(p44), .Y(new_n211_));
  OAI22x1_ASAP7_75t_R  g125(.A1(new_n167_), .A2(new_n203_), .B1(new_n210_), .B2(new_n211_), .Y(new_n212_));
  AOI21x1_ASAP7_75t_R  g126(.A1(p27), .A2(new_n183_), .B(new_n212_), .Y(new_n213_));
  OAI22x1_ASAP7_75t_R  g127(.A1(new_n167_), .A2(new_n197_), .B1(new_n210_), .B2(new_n211_), .Y(new_n214_));
  AOI21x1_ASAP7_75t_R  g128(.A1(p26), .A2(new_n183_), .B(new_n214_), .Y(new_n215_));
  OAI22x1_ASAP7_75t_R  g129(.A1(new_n204_), .A2(new_n213_), .B1(new_n215_), .B2(new_n198_), .Y(new_n216_));
  OA21x2_ASAP7_75t_R   g130(.A1(new_n194_), .A2(new_n199_), .B(new_n216_), .Y(new_n217_));
  AOI211x1_ASAP7_75t_R g131(.A1(new_n191_), .A2(new_n207_), .B(new_n187_), .C(new_n217_), .Y(new_n218_));
  INVx1_ASAP7_75t_R    g132(.A(p50), .Y(new_n219_));
  AO21x1_ASAP7_75t_R   g133(.A1(new_n187_), .A2(new_n217_), .B(new_n219_), .Y(new_n220_));
  INVx1_ASAP7_75t_R    g134(.A(p43), .Y(new_n221_));
  NOR2x1_ASAP7_75t_R   g135(.A(new_n221_), .B(new_n185_), .Y(new_n222_));
  AO21x1_ASAP7_75t_R   g136(.A1(p49), .A2(p24), .B(new_n222_), .Y(new_n223_));
  INVx1_ASAP7_75t_R    g137(.A(p48), .Y(new_n224_));
  NOR2x1_ASAP7_75t_R   g138(.A(new_n224_), .B(new_n185_), .Y(new_n225_));
  OA21x2_ASAP7_75t_R   g139(.A1(new_n160_), .A2(new_n225_), .B(p34), .Y(new_n226_));
  AOI211x1_ASAP7_75t_R g140(.A1(p47), .A2(new_n187_), .B(new_n223_), .C(new_n226_), .Y(new_n227_));
  OA31x2_ASAP7_75t_R   g141(.A1(new_n208_), .A2(new_n218_), .A3(new_n220_), .B1(new_n227_), .Y(o18));
  NAND2x1_ASAP7_75t_R  g142(.A(new_n193_), .B(new_n192_), .Y(new_n229_));
  OAI21x1_ASAP7_75t_R  g143(.A1(new_n214_), .A2(new_n229_), .B(p35), .Y(new_n230_));
  OA21x2_ASAP7_75t_R   g144(.A1(new_n194_), .A2(new_n199_), .B(new_n230_), .Y(new_n231_));
  NOR2x1_ASAP7_75t_R   g145(.A(new_n205_), .B(new_n202_), .Y(new_n232_));
  INVx1_ASAP7_75t_R    g146(.A(new_n232_), .Y(new_n233_));
  NOR2x1_ASAP7_75t_R   g147(.A(new_n203_), .B(new_n167_), .Y(new_n234_));
  OAI21x1_ASAP7_75t_R  g148(.A1(new_n234_), .A2(new_n202_), .B(p36), .Y(new_n235_));
  INVx1_ASAP7_75t_R    g149(.A(new_n235_), .Y(new_n236_));
  AO21x1_ASAP7_75t_R   g150(.A1(new_n233_), .A2(new_n191_), .B(new_n236_), .Y(new_n237_));
  NOR2x1_ASAP7_75t_R   g151(.A(new_n231_), .B(new_n237_), .Y(new_n238_));
  AO21x1_ASAP7_75t_R   g152(.A1(new_n231_), .A2(new_n237_), .B(new_n219_), .Y(new_n239_));
  INVx1_ASAP7_75t_R    g153(.A(new_n215_), .Y(new_n240_));
  AO21x1_ASAP7_75t_R   g154(.A1(p48), .A2(new_n240_), .B(new_n160_), .Y(new_n241_));
  AO22x1_ASAP7_75t_R   g155(.A1(p55), .A2(p41), .B1(p49), .B2(p25), .Y(new_n242_));
  AO21x1_ASAP7_75t_R   g156(.A1(p43), .A2(new_n240_), .B(new_n242_), .Y(new_n243_));
  AO21x1_ASAP7_75t_R   g157(.A1(p47), .A2(new_n231_), .B(new_n243_), .Y(new_n244_));
  AOI21x1_ASAP7_75t_R  g158(.A1(p35), .A2(new_n241_), .B(new_n244_), .Y(new_n245_));
  OA21x2_ASAP7_75t_R   g159(.A1(new_n238_), .A2(new_n239_), .B(new_n245_), .Y(o19));
  NAND2x1_ASAP7_75t_R  g160(.A(new_n235_), .B(new_n233_), .Y(new_n247_));
  XOR2x2_ASAP7_75t_R   g161(.A(new_n247_), .B(new_n191_), .Y(new_n248_));
  OA21x2_ASAP7_75t_R   g162(.A1(new_n204_), .A2(new_n224_), .B(new_n221_), .Y(new_n249_));
  AO22x1_ASAP7_75t_R   g163(.A1(p56), .A2(p41), .B1(p26), .B2(p49), .Y(new_n250_));
  AOI21x1_ASAP7_75t_R  g164(.A1(p36), .A2(new_n160_), .B(new_n250_), .Y(new_n251_));
  OA21x2_ASAP7_75t_R   g165(.A1(new_n213_), .A2(new_n249_), .B(new_n251_), .Y(new_n252_));
  OA21x2_ASAP7_75t_R   g166(.A1(new_n157_), .A2(new_n247_), .B(new_n252_), .Y(new_n253_));
  OA21x2_ASAP7_75t_R   g167(.A1(new_n219_), .A2(new_n248_), .B(new_n253_), .Y(o20));
  NAND2x1_ASAP7_75t_R  g168(.A(p21), .B(new_n183_), .Y(new_n255_));
  INVx1_ASAP7_75t_R    g169(.A(p30), .Y(new_n256_));
  AND2x2_ASAP7_75t_R   g170(.A(p16), .B(p52), .Y(new_n257_));
  AND3x1_ASAP7_75t_R   g171(.A(new_n209_), .B(new_n257_), .C(new_n143_), .Y(new_n258_));
  NOR2x1_ASAP7_75t_R   g172(.A(p44), .B(new_n88_), .Y(new_n259_));
  AND3x1_ASAP7_75t_R   g173(.A(new_n259_), .B(p6), .C(new_n136_), .Y(new_n260_));
  AOI211x1_ASAP7_75t_R g174(.A1(p8), .A2(p57), .B(new_n258_), .C(new_n260_), .Y(new_n261_));
  AND3x1_ASAP7_75t_R   g175(.A(new_n255_), .B(new_n256_), .C(new_n261_), .Y(new_n262_));
  INVx1_ASAP7_75t_R    g176(.A(new_n262_), .Y(new_n263_));
  AO211x2_ASAP7_75t_R  g177(.A1(new_n189_), .A2(new_n190_), .B(new_n178_), .C(new_n206_), .Y(new_n264_));
  OA21x2_ASAP7_75t_R   g178(.A1(new_n172_), .A2(new_n175_), .B(new_n176_), .Y(new_n265_));
  OA21x2_ASAP7_75t_R   g179(.A1(new_n167_), .A2(new_n169_), .B(new_n170_), .Y(new_n266_));
  AND3x1_ASAP7_75t_R   g180(.A(new_n192_), .B(new_n193_), .C(new_n176_), .Y(new_n267_));
  INVx1_ASAP7_75t_R    g181(.A(new_n199_), .Y(new_n268_));
  AOI22x1_ASAP7_75t_R  g182(.A1(new_n265_), .A2(new_n266_), .B1(new_n267_), .B2(new_n268_), .Y(new_n269_));
  AOI21x1_ASAP7_75t_R  g183(.A1(new_n269_), .A2(new_n216_), .B(new_n186_), .Y(new_n270_));
  INVx1_ASAP7_75t_R    g184(.A(p23), .Y(new_n271_));
  INVx1_ASAP7_75t_R    g185(.A(p44), .Y(new_n272_));
  AND4x2_ASAP7_75t_R   g186(.A(new_n272_), .B(p1), .C(p0), .D(p6), .Y(new_n273_));
  AND2x2_ASAP7_75t_R   g187(.A(p6), .B(p57), .Y(new_n274_));
  NAND2x1_ASAP7_75t_R  g188(.A(p53), .B(p16), .Y(new_n275_));
  AOI211x1_ASAP7_75t_R g189(.A1(p46), .A2(p11), .B(new_n275_), .C(o11), .Y(new_n276_));
  AOI211x1_ASAP7_75t_R g190(.A1(new_n136_), .A2(new_n273_), .B(new_n274_), .C(new_n276_), .Y(new_n277_));
  OAI21x1_ASAP7_75t_R  g191(.A1(new_n271_), .A2(new_n175_), .B(new_n277_), .Y(new_n278_));
  NOR2x1_ASAP7_75t_R   g192(.A(p32), .B(new_n278_), .Y(new_n279_));
  INVx1_ASAP7_75t_R    g193(.A(p24), .Y(new_n280_));
  AND2x2_ASAP7_75t_R   g194(.A(p58), .B(p57), .Y(new_n281_));
  NAND2x1_ASAP7_75t_R  g195(.A(p45), .B(p16), .Y(new_n282_));
  AOI211x1_ASAP7_75t_R g196(.A1(p46), .A2(p11), .B(new_n282_), .C(o11), .Y(new_n283_));
  AOI211x1_ASAP7_75t_R g197(.A1(new_n136_), .A2(new_n273_), .B(new_n281_), .C(new_n283_), .Y(new_n284_));
  OAI21x1_ASAP7_75t_R  g198(.A1(new_n280_), .A2(new_n175_), .B(new_n284_), .Y(new_n285_));
  NOR2x1_ASAP7_75t_R   g199(.A(p33), .B(new_n285_), .Y(new_n286_));
  NAND2x1_ASAP7_75t_R  g200(.A(new_n136_), .B(new_n273_), .Y(new_n287_));
  INVx1_ASAP7_75t_R    g201(.A(p31), .Y(new_n288_));
  NAND2x1_ASAP7_75t_R  g202(.A(p57), .B(p15), .Y(new_n289_));
  NAND3x1_ASAP7_75t_R  g203(.A(new_n287_), .B(new_n288_), .C(new_n289_), .Y(new_n290_));
  NAND2x1_ASAP7_75t_R  g204(.A(p22), .B(new_n135_), .Y(new_n291_));
  NAND3x1_ASAP7_75t_R  g205(.A(new_n142_), .B(new_n144_), .C(p22), .Y(new_n292_));
  OR4x2_ASAP7_75t_R    g206(.A(new_n147_), .B(o11), .C(new_n196_), .D(new_n137_), .Y(new_n293_));
  NAND3x1_ASAP7_75t_R  g207(.A(new_n291_), .B(new_n292_), .C(new_n293_), .Y(new_n294_));
  NOR2x1_ASAP7_75t_R   g208(.A(new_n290_), .B(new_n294_), .Y(new_n295_));
  OR3x1_ASAP7_75t_R    g209(.A(new_n279_), .B(new_n286_), .C(new_n295_), .Y(new_n296_));
  AOI21x1_ASAP7_75t_R  g210(.A1(new_n264_), .A2(new_n270_), .B(new_n296_), .Y(new_n297_));
  OAI22x1_ASAP7_75t_R  g211(.A1(p32), .A2(new_n278_), .B1(new_n294_), .B2(new_n290_), .Y(new_n298_));
  AOI22x1_ASAP7_75t_R  g212(.A1(p33), .A2(new_n285_), .B1(new_n278_), .B2(p32), .Y(new_n299_));
  AND3x1_ASAP7_75t_R   g213(.A(new_n293_), .B(new_n287_), .C(new_n289_), .Y(new_n300_));
  NAND2x1_ASAP7_75t_R  g214(.A(p22), .B(new_n183_), .Y(new_n301_));
  AO21x1_ASAP7_75t_R   g215(.A1(new_n300_), .A2(new_n301_), .B(new_n288_), .Y(new_n302_));
  OAI21x1_ASAP7_75t_R  g216(.A1(new_n298_), .A2(new_n299_), .B(new_n302_), .Y(new_n303_));
  AOI21x1_ASAP7_75t_R  g217(.A1(new_n261_), .A2(new_n255_), .B(new_n256_), .Y(new_n304_));
  AO21x1_ASAP7_75t_R   g218(.A1(new_n263_), .A2(new_n303_), .B(new_n304_), .Y(new_n305_));
  AOI21x1_ASAP7_75t_R  g219(.A1(new_n263_), .A2(new_n297_), .B(new_n305_), .Y(o21));
  NAND2x1_ASAP7_75t_R  g220(.A(p33), .B(new_n285_), .Y(new_n307_));
  INVx1_ASAP7_75t_R    g221(.A(new_n286_), .Y(new_n308_));
  NAND2x1_ASAP7_75t_R  g222(.A(new_n307_), .B(new_n308_), .Y(new_n309_));
  AOI21x1_ASAP7_75t_R  g223(.A1(new_n189_), .A2(new_n190_), .B(new_n232_), .Y(new_n310_));
  OAI22x1_ASAP7_75t_R  g224(.A1(new_n177_), .A2(new_n171_), .B1(new_n194_), .B2(new_n199_), .Y(new_n311_));
  AOI21x1_ASAP7_75t_R  g225(.A1(new_n230_), .A2(new_n235_), .B(new_n311_), .Y(new_n312_));
  AOI211x1_ASAP7_75t_R g226(.A1(new_n269_), .A2(new_n310_), .B(new_n186_), .C(new_n312_), .Y(new_n313_));
  NAND2x1_ASAP7_75t_R  g227(.A(new_n309_), .B(new_n313_), .Y(new_n314_));
  OA21x2_ASAP7_75t_R   g228(.A1(new_n309_), .A2(new_n313_), .B(p50), .Y(new_n315_));
  AO21x1_ASAP7_75t_R   g229(.A1(p48), .A2(new_n285_), .B(new_n160_), .Y(new_n316_));
  AND2x2_ASAP7_75t_R   g230(.A(p33), .B(new_n316_), .Y(new_n317_));
  AND3x1_ASAP7_75t_R   g231(.A(new_n308_), .B(p47), .C(new_n307_), .Y(new_n318_));
  AO22x1_ASAP7_75t_R   g232(.A1(p49), .A2(p23), .B1(p43), .B2(new_n285_), .Y(new_n319_));
  OR3x1_ASAP7_75t_R    g233(.A(new_n317_), .B(new_n318_), .C(new_n319_), .Y(new_n320_));
  AOI21x1_ASAP7_75t_R  g234(.A1(new_n314_), .A2(new_n315_), .B(new_n320_), .Y(o22));
  NOR2x1_ASAP7_75t_R   g235(.A(new_n298_), .B(new_n299_), .Y(new_n322_));
  OAI21x1_ASAP7_75t_R  g236(.A1(new_n304_), .A2(new_n262_), .B(new_n302_), .Y(new_n323_));
  NOR2x1_ASAP7_75t_R   g237(.A(new_n322_), .B(new_n323_), .Y(new_n324_));
  OAI21x1_ASAP7_75t_R  g238(.A1(new_n296_), .A2(new_n313_), .B(new_n324_), .Y(new_n325_));
  NOR2x1_ASAP7_75t_R   g239(.A(new_n304_), .B(new_n262_), .Y(new_n326_));
  AO21x1_ASAP7_75t_R   g240(.A1(new_n326_), .A2(new_n303_), .B(new_n219_), .Y(new_n327_));
  AOI21x1_ASAP7_75t_R  g241(.A1(new_n326_), .A2(new_n297_), .B(new_n327_), .Y(new_n328_));
  NAND2x1_ASAP7_75t_R  g242(.A(new_n261_), .B(new_n255_), .Y(new_n329_));
  AO22x1_ASAP7_75t_R   g243(.A1(p44), .A2(p49), .B1(p30), .B2(new_n160_), .Y(new_n330_));
  AO21x1_ASAP7_75t_R   g244(.A1(p43), .A2(new_n329_), .B(new_n330_), .Y(new_n331_));
  AND2x2_ASAP7_75t_R   g245(.A(p47), .B(new_n326_), .Y(new_n332_));
  AND3x1_ASAP7_75t_R   g246(.A(new_n329_), .B(p48), .C(p30), .Y(new_n333_));
  OR3x1_ASAP7_75t_R    g247(.A(new_n331_), .B(new_n332_), .C(new_n333_), .Y(new_n334_));
  AOI21x1_ASAP7_75t_R  g248(.A1(new_n325_), .A2(new_n328_), .B(new_n334_), .Y(o23));
  INVx1_ASAP7_75t_R    g249(.A(new_n277_), .Y(new_n336_));
  NOR2x1_ASAP7_75t_R   g250(.A(new_n271_), .B(new_n175_), .Y(new_n337_));
  OR3x1_ASAP7_75t_R    g251(.A(new_n336_), .B(p32), .C(new_n337_), .Y(new_n338_));
  NAND2x1_ASAP7_75t_R  g252(.A(new_n338_), .B(new_n308_), .Y(new_n339_));
  OAI21x1_ASAP7_75t_R  g253(.A1(new_n290_), .A2(new_n294_), .B(new_n302_), .Y(new_n340_));
  OA21x2_ASAP7_75t_R   g254(.A1(new_n299_), .A2(new_n279_), .B(new_n340_), .Y(new_n341_));
  OAI21x1_ASAP7_75t_R  g255(.A1(new_n339_), .A2(new_n313_), .B(new_n341_), .Y(new_n342_));
  AO21x1_ASAP7_75t_R   g256(.A1(new_n302_), .A2(new_n322_), .B(new_n219_), .Y(new_n343_));
  AOI21x1_ASAP7_75t_R  g257(.A1(new_n302_), .A2(new_n297_), .B(new_n343_), .Y(new_n344_));
  NOR2x1_ASAP7_75t_R   g258(.A(new_n157_), .B(new_n340_), .Y(new_n345_));
  AOI21x1_ASAP7_75t_R  g259(.A1(new_n300_), .A2(new_n301_), .B(new_n221_), .Y(new_n346_));
  NOR2x1_ASAP7_75t_R   g260(.A(new_n224_), .B(new_n302_), .Y(new_n347_));
  AO22x1_ASAP7_75t_R   g261(.A1(p49), .A2(p21), .B1(p31), .B2(new_n160_), .Y(new_n348_));
  OR4x2_ASAP7_75t_R    g262(.A(new_n345_), .B(new_n346_), .C(new_n347_), .D(new_n348_), .Y(new_n349_));
  AOI21x1_ASAP7_75t_R  g263(.A1(new_n342_), .A2(new_n344_), .B(new_n349_), .Y(o24));
  NAND2x1_ASAP7_75t_R  g264(.A(p32), .B(new_n278_), .Y(new_n351_));
  AOI22x1_ASAP7_75t_R  g265(.A1(new_n338_), .A2(new_n351_), .B1(p33), .B2(new_n285_), .Y(new_n352_));
  OAI21x1_ASAP7_75t_R  g266(.A1(new_n286_), .A2(new_n313_), .B(new_n352_), .Y(new_n353_));
  AND3x1_ASAP7_75t_R   g267(.A(new_n308_), .B(new_n351_), .C(new_n338_), .Y(new_n354_));
  OAI21x1_ASAP7_75t_R  g268(.A1(new_n170_), .A2(new_n185_), .B(new_n307_), .Y(new_n355_));
  AO211x2_ASAP7_75t_R  g269(.A1(new_n310_), .A2(new_n269_), .B(new_n355_), .C(new_n312_), .Y(new_n356_));
  AOI21x1_ASAP7_75t_R  g270(.A1(new_n354_), .A2(new_n356_), .B(new_n219_), .Y(new_n357_));
  AO21x1_ASAP7_75t_R   g271(.A1(p48), .A2(new_n278_), .B(new_n160_), .Y(new_n358_));
  AND2x2_ASAP7_75t_R   g272(.A(p32), .B(new_n358_), .Y(new_n359_));
  AND3x1_ASAP7_75t_R   g273(.A(new_n338_), .B(p47), .C(new_n351_), .Y(new_n360_));
  AO22x1_ASAP7_75t_R   g274(.A1(p22), .A2(p49), .B1(p43), .B2(new_n278_), .Y(new_n361_));
  OR3x1_ASAP7_75t_R    g275(.A(new_n359_), .B(new_n360_), .C(new_n361_), .Y(new_n362_));
  AOI21x1_ASAP7_75t_R  g276(.A1(new_n353_), .A2(new_n357_), .B(new_n362_), .Y(o25));
endmodule


