// Benchmark "/tmp/" written by ABC on Mon Oct 12 15:07:53 2026

module \/tmp/  ( 
    p3, p22, p47, p39, p15, p59, p26, p44, p46, p24, p34, p11, p38, p53,
    p4, p32, p7, p14, p54, p17, p41, p18, p43, p8, p51, p30, p1, p40, p21,
    p55, p12, p28, p0, p37, p56, p23, p6, p49, p48, p10, p9, p16, p33, p5,
    p45, p31, p50, p57, p19, p13, p35, p42, p20, p58, p29, p36, p52, p27,
    p2, p25,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25  );
  input  p3, p22, p47, p39, p15, p59, p26, p44, p46, p24, p34, p11, p38,
    p53, p4, p32, p7, p14, p54, p17, p41, p18, p43, p8, p51, p30, p1, p40,
    p21, p55, p12, p28, p0, p37, p56, p23, p6, p49, p48, p10, p9, p16, p33,
    p5, p45, p31, p50, p57, p19, p13, p35, p42, p20, p58, p29, p36, p52,
    p27, p2, p25;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25;
  wire new_n87_, new_n88_, new_n90_, new_n91_, new_n92_, new_n94_, new_n97_,
    new_n98_, new_n100_, new_n101_, new_n109_, new_n110_, new_n114_,
    new_n115_, new_n116_, new_n117_, new_n118_, new_n119_, new_n120_,
    new_n121_, new_n123_, new_n124_, new_n125_, new_n126_, new_n127_,
    new_n128_, new_n129_, new_n130_, new_n132_, new_n133_, new_n134_,
    new_n135_, new_n136_, new_n137_, new_n138_, new_n139_, new_n140_,
    new_n141_, new_n142_, new_n143_, new_n144_, new_n145_, new_n146_,
    new_n147_, new_n148_, new_n149_, new_n150_, new_n151_, new_n152_,
    new_n153_, new_n154_, new_n155_, new_n156_, new_n157_, new_n158_,
    new_n159_, new_n160_, new_n161_, new_n162_, new_n163_, new_n164_,
    new_n165_, new_n166_, new_n167_, new_n168_, new_n169_, new_n170_,
    new_n172_, new_n173_, new_n174_, new_n175_, new_n176_, new_n177_,
    new_n178_, new_n179_, new_n180_, new_n181_, new_n182_, new_n183_,
    new_n184_, new_n185_, new_n186_, new_n187_, new_n188_, new_n189_,
    new_n190_, new_n191_, new_n192_, new_n193_, new_n194_, new_n195_,
    new_n196_, new_n197_, new_n198_, new_n199_, new_n200_, new_n201_,
    new_n202_, new_n203_, new_n204_, new_n205_, new_n206_, new_n207_,
    new_n208_, new_n209_, new_n210_, new_n211_, new_n212_, new_n213_,
    new_n214_, new_n215_, new_n216_, new_n217_, new_n219_, new_n220_,
    new_n221_, new_n222_, new_n223_, new_n224_, new_n225_, new_n226_,
    new_n227_, new_n228_, new_n229_, new_n230_, new_n231_, new_n232_,
    new_n233_, new_n234_, new_n236_, new_n237_, new_n238_, new_n239_,
    new_n240_, new_n241_, new_n242_, new_n243_, new_n244_, new_n245_,
    new_n247_, new_n248_, new_n249_, new_n250_, new_n251_, new_n252_,
    new_n253_, new_n254_, new_n255_, new_n256_, new_n257_, new_n258_,
    new_n259_, new_n260_, new_n261_, new_n262_, new_n263_, new_n264_,
    new_n265_, new_n266_, new_n267_, new_n268_, new_n269_, new_n270_,
    new_n271_, new_n272_, new_n273_, new_n274_, new_n275_, new_n276_,
    new_n277_, new_n278_, new_n279_, new_n280_, new_n281_, new_n282_,
    new_n283_, new_n284_, new_n285_, new_n286_, new_n287_, new_n288_,
    new_n289_, new_n290_, new_n291_, new_n292_, new_n293_, new_n294_,
    new_n296_, new_n297_, new_n298_, new_n299_, new_n300_, new_n301_,
    new_n302_, new_n303_, new_n304_, new_n305_, new_n306_, new_n308_,
    new_n309_, new_n310_, new_n311_, new_n312_, new_n313_, new_n314_,
    new_n315_, new_n316_, new_n317_, new_n318_, new_n319_, new_n320_,
    new_n321_, new_n322_, new_n323_, new_n324_, new_n325_, new_n327_,
    new_n328_, new_n329_, new_n330_, new_n331_, new_n332_, new_n333_,
    new_n334_, new_n335_, new_n336_, new_n337_, new_n338_, new_n339_,
    new_n340_, new_n341_, new_n343_, new_n344_, new_n345_, new_n346_,
    new_n347_, new_n348_, new_n349_, new_n350_, new_n351_, new_n352_,
    new_n353_, new_n354_, new_n355_, new_n356_;
  INVx1_ASAP7_75t_R    g000(.A(p59), .Y(new_n87_));
  NAND2x1_ASAP7_75t_R  g001(.A(p1), .B(p0), .Y(new_n88_));
  OR2x4_ASAP7_75t_R    g002(.A(new_n87_), .B(new_n88_), .Y(o0));
  INVx1_ASAP7_75t_R    g003(.A(p3), .Y(new_n90_));
  INVx1_ASAP7_75t_R    g004(.A(p1), .Y(new_n91_));
  INVx1_ASAP7_75t_R    g005(.A(p2), .Y(new_n92_));
  OR3x1_ASAP7_75t_R    g006(.A(new_n90_), .B(new_n91_), .C(new_n92_), .Y(o1));
  AND3x1_ASAP7_75t_R   g007(.A(p3), .B(p59), .C(p1), .Y(new_n94_));
  INVx1_ASAP7_75t_R    g008(.A(new_n94_), .Y(o2));
  NAND2x1_ASAP7_75t_R  g009(.A(p4), .B(p5), .Y(o3));
  AND2x2_ASAP7_75t_R   g010(.A(p8), .B(p9), .Y(new_n97_));
  AND2x2_ASAP7_75t_R   g011(.A(p7), .B(p6), .Y(new_n98_));
  NAND2x1_ASAP7_75t_R  g012(.A(new_n97_), .B(new_n98_), .Y(o4));
  NAND2x1_ASAP7_75t_R  g013(.A(p10), .B(p9), .Y(new_n100_));
  INVx1_ASAP7_75t_R    g014(.A(new_n100_), .Y(new_n101_));
  AND3x1_ASAP7_75t_R   g015(.A(o2), .B(new_n98_), .C(new_n101_), .Y(o5));
  AND3x1_ASAP7_75t_R   g016(.A(p11), .B(p0), .C(p2), .Y(o6));
  AND3x1_ASAP7_75t_R   g017(.A(p3), .B(p11), .C(p2), .Y(o7));
  AND3x1_ASAP7_75t_R   g018(.A(p3), .B(p59), .C(p11), .Y(o8));
  OAI21x1_ASAP7_75t_R  g019(.A1(p14), .A2(p13), .B(p12), .Y(o9));
  AND3x1_ASAP7_75t_R   g020(.A(new_n101_), .B(new_n94_), .C(new_n98_), .Y(o10));
  NAND3x1_ASAP7_75t_R  g021(.A(p15), .B(p10), .C(p9), .Y(o11));
  AND3x1_ASAP7_75t_R   g022(.A(new_n97_), .B(p7), .C(p16), .Y(new_n109_));
  AND2x2_ASAP7_75t_R   g023(.A(p17), .B(new_n109_), .Y(new_n110_));
  NAND2x1_ASAP7_75t_R  g024(.A(p1), .B(new_n110_), .Y(o12));
  NAND3x1_ASAP7_75t_R  g025(.A(new_n110_), .B(p11), .C(p18), .Y(o13));
  OAI21x1_ASAP7_75t_R  g026(.A1(p14), .A2(p13), .B(p19), .Y(o14));
  XOR2x2_ASAP7_75t_R   g027(.A(p28), .B(p27), .Y(new_n114_));
  XOR2x2_ASAP7_75t_R   g028(.A(p24), .B(p23), .Y(new_n115_));
  XOR2x2_ASAP7_75t_R   g029(.A(new_n114_), .B(new_n115_), .Y(new_n116_));
  XOR2x2_ASAP7_75t_R   g030(.A(p26), .B(p29), .Y(new_n117_));
  XOR2x2_ASAP7_75t_R   g031(.A(new_n117_), .B(p25), .Y(new_n118_));
  XOR2x2_ASAP7_75t_R   g032(.A(new_n116_), .B(new_n118_), .Y(new_n119_));
  XNOR2x2_ASAP7_75t_R  g033(.A(p22), .B(p21), .Y(new_n120_));
  XOR2x2_ASAP7_75t_R   g034(.A(new_n120_), .B(p20), .Y(new_n121_));
  XOR2x2_ASAP7_75t_R   g035(.A(new_n119_), .B(new_n121_), .Y(o15));
  XNOR2x2_ASAP7_75t_R  g036(.A(p32), .B(p33), .Y(new_n123_));
  XOR2x2_ASAP7_75t_R   g037(.A(p37), .B(p36), .Y(new_n124_));
  XOR2x2_ASAP7_75t_R   g038(.A(new_n123_), .B(new_n124_), .Y(new_n125_));
  XOR2x2_ASAP7_75t_R   g039(.A(p30), .B(p31), .Y(new_n126_));
  XOR2x2_ASAP7_75t_R   g040(.A(new_n126_), .B(p20), .Y(new_n127_));
  XOR2x2_ASAP7_75t_R   g041(.A(new_n125_), .B(new_n127_), .Y(new_n128_));
  XOR2x2_ASAP7_75t_R   g042(.A(p38), .B(p35), .Y(new_n129_));
  XOR2x2_ASAP7_75t_R   g043(.A(new_n129_), .B(p34), .Y(new_n130_));
  XOR2x2_ASAP7_75t_R   g044(.A(new_n128_), .B(new_n130_), .Y(o16));
  AND3x1_ASAP7_75t_R   g045(.A(p59), .B(p11), .C(p0), .Y(new_n132_));
  NAND2x1_ASAP7_75t_R  g046(.A(p8), .B(p9), .Y(new_n133_));
  NAND2x1_ASAP7_75t_R  g047(.A(p15), .B(p6), .Y(new_n134_));
  NOR3x1_ASAP7_75t_R   g048(.A(new_n132_), .B(new_n133_), .C(new_n134_), .Y(new_n135_));
  NAND2x1_ASAP7_75t_R  g049(.A(p15), .B(p2), .Y(new_n136_));
  NOR2x1_ASAP7_75t_R   g050(.A(new_n100_), .B(new_n136_), .Y(new_n137_));
  INVx1_ASAP7_75t_R    g051(.A(p16), .Y(new_n138_));
  NOR3x1_ASAP7_75t_R   g052(.A(new_n88_), .B(p44), .C(new_n138_), .Y(new_n139_));
  AOI22x1_ASAP7_75t_R  g053(.A1(new_n135_), .A2(p28), .B1(new_n137_), .B2(new_n139_), .Y(new_n140_));
  NAND2x1_ASAP7_75t_R  g054(.A(p15), .B(p9), .Y(new_n141_));
  OAI21x1_ASAP7_75t_R  g055(.A1(p59), .A2(p6), .B(p10), .Y(new_n142_));
  NOR2x1_ASAP7_75t_R   g056(.A(new_n141_), .B(new_n142_), .Y(new_n143_));
  NAND2x1_ASAP7_75t_R  g057(.A(p46), .B(p11), .Y(new_n144_));
  AOI21x1_ASAP7_75t_R  g058(.A1(p59), .A2(p6), .B(new_n144_), .Y(new_n145_));
  NAND3x1_ASAP7_75t_R  g059(.A(new_n143_), .B(new_n145_), .C(p28), .Y(new_n146_));
  INVx1_ASAP7_75t_R    g060(.A(p9), .Y(new_n147_));
  OA21x2_ASAP7_75t_R   g061(.A1(p6), .A2(new_n147_), .B(p45), .Y(new_n148_));
  AND2x2_ASAP7_75t_R   g062(.A(p46), .B(p11), .Y(new_n149_));
  OAI21x1_ASAP7_75t_R  g063(.A1(o11), .A2(new_n149_), .B(p9), .Y(new_n150_));
  NAND2x1_ASAP7_75t_R  g064(.A(new_n148_), .B(new_n150_), .Y(new_n151_));
  INVx1_ASAP7_75t_R    g065(.A(p37), .Y(new_n152_));
  AO31x2_ASAP7_75t_R   g066(.A1(new_n140_), .A2(new_n146_), .A3(new_n151_), .B(new_n152_), .Y(new_n153_));
  AOI21x1_ASAP7_75t_R  g067(.A1(new_n148_), .A2(new_n150_), .B(p37), .Y(new_n154_));
  AND2x2_ASAP7_75t_R   g068(.A(new_n146_), .B(new_n140_), .Y(new_n155_));
  NAND2x1_ASAP7_75t_R  g069(.A(new_n154_), .B(new_n155_), .Y(new_n156_));
  NAND2x1_ASAP7_75t_R  g070(.A(new_n153_), .B(new_n156_), .Y(new_n157_));
  INVx1_ASAP7_75t_R    g071(.A(p51), .Y(new_n158_));
  XOR2x2_ASAP7_75t_R   g072(.A(new_n157_), .B(new_n158_), .Y(new_n159_));
  AND3x1_ASAP7_75t_R   g073(.A(new_n156_), .B(p47), .C(new_n153_), .Y(new_n160_));
  INVx1_ASAP7_75t_R    g074(.A(p48), .Y(new_n161_));
  INVx1_ASAP7_75t_R    g075(.A(p43), .Y(new_n162_));
  OA21x2_ASAP7_75t_R   g076(.A1(new_n152_), .A2(new_n161_), .B(new_n162_), .Y(new_n163_));
  AOI21x1_ASAP7_75t_R  g077(.A1(new_n151_), .A2(new_n155_), .B(new_n163_), .Y(new_n164_));
  AND2x2_ASAP7_75t_R   g078(.A(p59), .B(p11), .Y(new_n165_));
  AND3x1_ASAP7_75t_R   g079(.A(new_n165_), .B(p39), .C(p40), .Y(new_n166_));
  AND3x1_ASAP7_75t_R   g080(.A(new_n109_), .B(new_n166_), .C(p17), .Y(new_n167_));
  AO22x1_ASAP7_75t_R   g081(.A1(p41), .A2(p42), .B1(p49), .B2(p27), .Y(new_n168_));
  AO21x1_ASAP7_75t_R   g082(.A1(p37), .A2(new_n167_), .B(new_n168_), .Y(new_n169_));
  OR3x1_ASAP7_75t_R    g083(.A(new_n160_), .B(new_n164_), .C(new_n169_), .Y(new_n170_));
  AOI21x1_ASAP7_75t_R  g084(.A1(p50), .A2(new_n159_), .B(new_n170_), .Y(o17));
  NAND2x1_ASAP7_75t_R  g085(.A(new_n137_), .B(new_n139_), .Y(new_n172_));
  OA21x2_ASAP7_75t_R   g086(.A1(p6), .A2(new_n147_), .B(p52), .Y(new_n173_));
  NAND2x1_ASAP7_75t_R  g087(.A(new_n173_), .B(new_n150_), .Y(new_n174_));
  AND2x2_ASAP7_75t_R   g088(.A(new_n172_), .B(new_n174_), .Y(new_n175_));
  AO21x1_ASAP7_75t_R   g089(.A1(new_n145_), .A2(new_n143_), .B(new_n135_), .Y(new_n176_));
  NAND2x1_ASAP7_75t_R  g090(.A(p25), .B(new_n176_), .Y(new_n177_));
  NAND2x1_ASAP7_75t_R  g091(.A(new_n175_), .B(new_n177_), .Y(new_n178_));
  OA21x2_ASAP7_75t_R   g092(.A1(p6), .A2(new_n147_), .B(p53), .Y(new_n179_));
  AOI22x1_ASAP7_75t_R  g093(.A1(new_n150_), .A2(new_n179_), .B1(new_n137_), .B2(new_n139_), .Y(new_n180_));
  NAND3x1_ASAP7_75t_R  g094(.A(new_n143_), .B(new_n145_), .C(p27), .Y(new_n181_));
  AND4x2_ASAP7_75t_R   g095(.A(p15), .B(p8), .C(p6), .D(p9), .Y(new_n182_));
  NAND3x1_ASAP7_75t_R  g096(.A(p59), .B(p11), .C(p0), .Y(new_n183_));
  NAND3x1_ASAP7_75t_R  g097(.A(new_n182_), .B(p27), .C(new_n183_), .Y(new_n184_));
  INVx1_ASAP7_75t_R    g098(.A(p36), .Y(new_n185_));
  AO31x2_ASAP7_75t_R   g099(.A1(new_n180_), .A2(new_n181_), .A3(new_n184_), .B(new_n185_), .Y(new_n186_));
  AOI22x1_ASAP7_75t_R  g100(.A1(new_n135_), .A2(p26), .B1(new_n137_), .B2(new_n139_), .Y(new_n187_));
  INVx1_ASAP7_75t_R    g101(.A(p35), .Y(new_n188_));
  NAND3x1_ASAP7_75t_R  g102(.A(new_n143_), .B(new_n145_), .C(p26), .Y(new_n189_));
  OA21x2_ASAP7_75t_R   g103(.A1(p6), .A2(new_n147_), .B(p54), .Y(new_n190_));
  NAND2x1_ASAP7_75t_R  g104(.A(new_n190_), .B(new_n150_), .Y(new_n191_));
  AND4x2_ASAP7_75t_R   g105(.A(new_n187_), .B(new_n188_), .C(new_n189_), .D(new_n191_), .Y(new_n192_));
  AO31x2_ASAP7_75t_R   g106(.A1(new_n187_), .A2(new_n189_), .A3(new_n191_), .B(new_n188_), .Y(new_n193_));
  OAI21x1_ASAP7_75t_R  g107(.A1(new_n186_), .A2(new_n192_), .B(new_n193_), .Y(new_n194_));
  AO31x2_ASAP7_75t_R   g108(.A1(new_n140_), .A2(new_n146_), .A3(new_n154_), .B(new_n158_), .Y(new_n195_));
  NAND3x1_ASAP7_75t_R  g109(.A(new_n182_), .B(p26), .C(new_n183_), .Y(new_n196_));
  NAND3x1_ASAP7_75t_R  g110(.A(new_n189_), .B(new_n172_), .C(new_n196_), .Y(new_n197_));
  AO21x1_ASAP7_75t_R   g111(.A1(new_n190_), .A2(new_n150_), .B(p35), .Y(new_n198_));
  NAND3x1_ASAP7_75t_R  g112(.A(new_n181_), .B(new_n172_), .C(new_n184_), .Y(new_n199_));
  AO21x1_ASAP7_75t_R   g113(.A1(new_n179_), .A2(new_n150_), .B(p36), .Y(new_n200_));
  OAI22x1_ASAP7_75t_R  g114(.A1(new_n197_), .A2(new_n198_), .B1(new_n199_), .B2(new_n200_), .Y(new_n201_));
  AOI21x1_ASAP7_75t_R  g115(.A1(new_n153_), .A2(new_n195_), .B(new_n201_), .Y(new_n202_));
  INVx1_ASAP7_75t_R    g116(.A(p34), .Y(new_n203_));
  NAND3x1_ASAP7_75t_R  g117(.A(new_n177_), .B(new_n203_), .C(new_n175_), .Y(new_n204_));
  OAI21x1_ASAP7_75t_R  g118(.A1(new_n194_), .A2(new_n202_), .B(new_n204_), .Y(new_n205_));
  AO21x1_ASAP7_75t_R   g119(.A1(p34), .A2(new_n178_), .B(new_n205_), .Y(new_n206_));
  AOI21x1_ASAP7_75t_R  g120(.A1(new_n175_), .A2(new_n177_), .B(new_n203_), .Y(new_n207_));
  INVx1_ASAP7_75t_R    g121(.A(new_n204_), .Y(new_n208_));
  NOR2x1_ASAP7_75t_R   g122(.A(new_n207_), .B(new_n208_), .Y(new_n209_));
  NAND2x1_ASAP7_75t_R  g123(.A(new_n153_), .B(new_n195_), .Y(new_n210_));
  INVx1_ASAP7_75t_R    g124(.A(new_n201_), .Y(new_n211_));
  AO21x1_ASAP7_75t_R   g125(.A1(new_n210_), .A2(new_n211_), .B(new_n194_), .Y(new_n212_));
  OA21x2_ASAP7_75t_R   g126(.A1(new_n209_), .A2(new_n212_), .B(p50), .Y(new_n213_));
  AO21x1_ASAP7_75t_R   g127(.A1(p48), .A2(new_n178_), .B(new_n167_), .Y(new_n214_));
  AND2x2_ASAP7_75t_R   g128(.A(p34), .B(new_n214_), .Y(new_n215_));
  AO22x1_ASAP7_75t_R   g129(.A1(p24), .A2(p49), .B1(p43), .B2(new_n178_), .Y(new_n216_));
  AO21x1_ASAP7_75t_R   g130(.A1(p47), .A2(new_n209_), .B(new_n216_), .Y(new_n217_));
  AOI211x1_ASAP7_75t_R g131(.A1(new_n206_), .A2(new_n213_), .B(new_n215_), .C(new_n217_), .Y(o18));
  OA21x2_ASAP7_75t_R   g132(.A1(new_n199_), .A2(new_n200_), .B(new_n210_), .Y(new_n219_));
  INVx1_ASAP7_75t_R    g133(.A(new_n186_), .Y(new_n220_));
  INVx1_ASAP7_75t_R    g134(.A(new_n193_), .Y(new_n221_));
  NOR2x1_ASAP7_75t_R   g135(.A(new_n192_), .B(new_n221_), .Y(new_n222_));
  OR3x1_ASAP7_75t_R    g136(.A(new_n219_), .B(new_n220_), .C(new_n222_), .Y(new_n223_));
  INVx1_ASAP7_75t_R    g137(.A(p50), .Y(new_n224_));
  OA21x2_ASAP7_75t_R   g138(.A1(new_n220_), .A2(new_n219_), .B(new_n222_), .Y(new_n225_));
  NOR2x1_ASAP7_75t_R   g139(.A(new_n224_), .B(new_n225_), .Y(new_n226_));
  AO21x1_ASAP7_75t_R   g140(.A1(p48), .A2(p35), .B(p43), .Y(new_n227_));
  AO21x1_ASAP7_75t_R   g141(.A1(new_n150_), .A2(new_n190_), .B(new_n197_), .Y(new_n228_));
  AO22x1_ASAP7_75t_R   g142(.A1(p41), .A2(p55), .B1(p49), .B2(p25), .Y(new_n229_));
  AO21x1_ASAP7_75t_R   g143(.A1(p35), .A2(new_n167_), .B(new_n229_), .Y(new_n230_));
  AOI21x1_ASAP7_75t_R  g144(.A1(new_n227_), .A2(new_n228_), .B(new_n230_), .Y(new_n231_));
  INVx1_ASAP7_75t_R    g145(.A(p47), .Y(new_n232_));
  OR3x1_ASAP7_75t_R    g146(.A(new_n221_), .B(new_n232_), .C(new_n192_), .Y(new_n233_));
  NAND2x1_ASAP7_75t_R  g147(.A(new_n231_), .B(new_n233_), .Y(new_n234_));
  AOI21x1_ASAP7_75t_R  g148(.A1(new_n223_), .A2(new_n226_), .B(new_n234_), .Y(o19));
  OA21x2_ASAP7_75t_R   g149(.A1(new_n199_), .A2(new_n200_), .B(new_n186_), .Y(new_n236_));
  NOR2x1_ASAP7_75t_R   g150(.A(new_n210_), .B(new_n236_), .Y(new_n237_));
  AO21x1_ASAP7_75t_R   g151(.A1(new_n210_), .A2(new_n236_), .B(new_n224_), .Y(new_n238_));
  AND3x1_ASAP7_75t_R   g152(.A(new_n180_), .B(new_n181_), .C(new_n184_), .Y(new_n239_));
  INVx1_ASAP7_75t_R    g153(.A(new_n239_), .Y(new_n240_));
  AO21x1_ASAP7_75t_R   g154(.A1(p48), .A2(new_n240_), .B(new_n167_), .Y(new_n241_));
  AO22x1_ASAP7_75t_R   g155(.A1(p26), .A2(p49), .B1(p41), .B2(p56), .Y(new_n242_));
  AO21x1_ASAP7_75t_R   g156(.A1(p43), .A2(new_n240_), .B(new_n242_), .Y(new_n243_));
  AO21x1_ASAP7_75t_R   g157(.A1(p47), .A2(new_n236_), .B(new_n243_), .Y(new_n244_));
  AOI21x1_ASAP7_75t_R  g158(.A1(p36), .A2(new_n241_), .B(new_n244_), .Y(new_n245_));
  OA21x2_ASAP7_75t_R   g159(.A1(new_n237_), .A2(new_n238_), .B(new_n245_), .Y(o20));
  INVx1_ASAP7_75t_R    g160(.A(p6), .Y(new_n247_));
  NOR3x1_ASAP7_75t_R   g161(.A(new_n88_), .B(p44), .C(new_n247_), .Y(new_n248_));
  NAND2x1_ASAP7_75t_R  g162(.A(new_n137_), .B(new_n248_), .Y(new_n249_));
  AND3x1_ASAP7_75t_R   g163(.A(new_n144_), .B(p54), .C(p16), .Y(new_n250_));
  AND3x1_ASAP7_75t_R   g164(.A(p15), .B(p10), .C(p9), .Y(new_n251_));
  AOI22x1_ASAP7_75t_R  g165(.A1(new_n250_), .A2(new_n251_), .B1(p15), .B2(p57), .Y(new_n252_));
  NAND2x1_ASAP7_75t_R  g166(.A(new_n249_), .B(new_n252_), .Y(new_n253_));
  NAND2x1_ASAP7_75t_R  g167(.A(new_n87_), .B(new_n247_), .Y(new_n254_));
  NAND2x1_ASAP7_75t_R  g168(.A(p59), .B(p6), .Y(new_n255_));
  AND4x2_ASAP7_75t_R   g169(.A(new_n254_), .B(new_n251_), .C(new_n255_), .D(new_n149_), .Y(new_n256_));
  OA21x2_ASAP7_75t_R   g170(.A1(new_n135_), .A2(new_n256_), .B(p22), .Y(new_n257_));
  OAI21x1_ASAP7_75t_R  g171(.A1(new_n253_), .A2(new_n257_), .B(p31), .Y(new_n258_));
  INVx1_ASAP7_75t_R    g172(.A(p23), .Y(new_n259_));
  AOI21x1_ASAP7_75t_R  g173(.A1(new_n145_), .A2(new_n143_), .B(new_n135_), .Y(new_n260_));
  AND2x2_ASAP7_75t_R   g174(.A(p6), .B(p57), .Y(new_n261_));
  AND2x2_ASAP7_75t_R   g175(.A(p53), .B(p16), .Y(new_n262_));
  AND3x1_ASAP7_75t_R   g176(.A(new_n251_), .B(new_n262_), .C(new_n144_), .Y(new_n263_));
  AOI211x1_ASAP7_75t_R g177(.A1(new_n137_), .A2(new_n248_), .B(new_n261_), .C(new_n263_), .Y(new_n264_));
  OAI21x1_ASAP7_75t_R  g178(.A1(new_n259_), .A2(new_n260_), .B(new_n264_), .Y(new_n265_));
  INVx1_ASAP7_75t_R    g179(.A(p31), .Y(new_n266_));
  AND3x1_ASAP7_75t_R   g180(.A(new_n252_), .B(new_n266_), .C(new_n249_), .Y(new_n267_));
  NAND2x1_ASAP7_75t_R  g181(.A(p22), .B(new_n176_), .Y(new_n268_));
  NAND2x1_ASAP7_75t_R  g182(.A(new_n267_), .B(new_n268_), .Y(new_n269_));
  OAI21x1_ASAP7_75t_R  g183(.A1(p32), .A2(new_n265_), .B(new_n269_), .Y(new_n270_));
  NAND2x1_ASAP7_75t_R  g184(.A(p21), .B(new_n256_), .Y(new_n271_));
  AND2x2_ASAP7_75t_R   g185(.A(p8), .B(p57), .Y(new_n272_));
  AOI211x1_ASAP7_75t_R g186(.A1(new_n137_), .A2(new_n248_), .B(p30), .C(new_n272_), .Y(new_n273_));
  AND2x2_ASAP7_75t_R   g187(.A(p16), .B(p52), .Y(new_n274_));
  AND3x1_ASAP7_75t_R   g188(.A(new_n251_), .B(new_n274_), .C(new_n144_), .Y(new_n275_));
  AOI21x1_ASAP7_75t_R  g189(.A1(p21), .A2(new_n135_), .B(new_n275_), .Y(new_n276_));
  AND3x1_ASAP7_75t_R   g190(.A(new_n271_), .B(new_n273_), .C(new_n276_), .Y(new_n277_));
  AOI21x1_ASAP7_75t_R  g191(.A1(new_n258_), .A2(new_n270_), .B(new_n277_), .Y(new_n278_));
  INVx1_ASAP7_75t_R    g192(.A(p24), .Y(new_n279_));
  AND2x2_ASAP7_75t_R   g193(.A(p57), .B(p58), .Y(new_n280_));
  AND2x2_ASAP7_75t_R   g194(.A(p16), .B(p45), .Y(new_n281_));
  AND3x1_ASAP7_75t_R   g195(.A(new_n251_), .B(new_n281_), .C(new_n144_), .Y(new_n282_));
  AOI211x1_ASAP7_75t_R g196(.A1(new_n137_), .A2(new_n248_), .B(new_n280_), .C(new_n282_), .Y(new_n283_));
  OAI21x1_ASAP7_75t_R  g197(.A1(new_n279_), .A2(new_n260_), .B(new_n283_), .Y(new_n284_));
  NOR2x1_ASAP7_75t_R   g198(.A(p33), .B(new_n284_), .Y(new_n285_));
  NOR2x1_ASAP7_75t_R   g199(.A(new_n285_), .B(new_n208_), .Y(new_n286_));
  OR3x1_ASAP7_75t_R    g200(.A(new_n202_), .B(new_n207_), .C(new_n194_), .Y(new_n287_));
  AOI22x1_ASAP7_75t_R  g201(.A1(p32), .A2(new_n265_), .B1(new_n284_), .B2(p33), .Y(new_n288_));
  OAI21x1_ASAP7_75t_R  g202(.A1(new_n288_), .A2(new_n270_), .B(new_n258_), .Y(new_n289_));
  AO21x1_ASAP7_75t_R   g203(.A1(new_n286_), .A2(new_n287_), .B(new_n289_), .Y(new_n290_));
  AOI211x1_ASAP7_75t_R g204(.A1(new_n137_), .A2(new_n248_), .B(new_n272_), .C(new_n275_), .Y(new_n291_));
  OAI21x1_ASAP7_75t_R  g205(.A1(new_n135_), .A2(new_n256_), .B(p21), .Y(new_n292_));
  INVx1_ASAP7_75t_R    g206(.A(p30), .Y(new_n293_));
  AOI21x1_ASAP7_75t_R  g207(.A1(new_n291_), .A2(new_n292_), .B(new_n293_), .Y(new_n294_));
  AOI21x1_ASAP7_75t_R  g208(.A1(new_n278_), .A2(new_n290_), .B(new_n294_), .Y(o21));
  NAND2x1_ASAP7_75t_R  g209(.A(p33), .B(new_n284_), .Y(new_n296_));
  INVx1_ASAP7_75t_R    g210(.A(new_n285_), .Y(new_n297_));
  NAND2x1_ASAP7_75t_R  g211(.A(new_n296_), .B(new_n297_), .Y(new_n298_));
  NOR2x1_ASAP7_75t_R   g212(.A(new_n298_), .B(new_n205_), .Y(new_n299_));
  INVx1_ASAP7_75t_R    g213(.A(new_n207_), .Y(new_n300_));
  AND3x1_ASAP7_75t_R   g214(.A(new_n205_), .B(new_n300_), .C(new_n298_), .Y(new_n301_));
  OAI21x1_ASAP7_75t_R  g215(.A1(new_n300_), .A2(new_n298_), .B(p50), .Y(new_n302_));
  AO21x1_ASAP7_75t_R   g216(.A1(p48), .A2(new_n284_), .B(new_n167_), .Y(new_n303_));
  NAND2x1_ASAP7_75t_R  g217(.A(p33), .B(new_n303_), .Y(new_n304_));
  AOI22x1_ASAP7_75t_R  g218(.A1(new_n284_), .A2(p43), .B1(p23), .B2(p49), .Y(new_n305_));
  OA211x2_ASAP7_75t_R  g219(.A1(new_n232_), .A2(new_n298_), .B(new_n304_), .C(new_n305_), .Y(new_n306_));
  OA31x2_ASAP7_75t_R   g220(.A1(new_n299_), .A2(new_n301_), .A3(new_n302_), .B1(new_n306_), .Y(o22));
  NOR2x1_ASAP7_75t_R   g221(.A(new_n277_), .B(new_n294_), .Y(new_n308_));
  AO21x1_ASAP7_75t_R   g222(.A1(new_n308_), .A2(new_n289_), .B(new_n224_), .Y(new_n309_));
  INVx1_ASAP7_75t_R    g223(.A(p32), .Y(new_n310_));
  AND2x2_ASAP7_75t_R   g224(.A(new_n310_), .B(new_n264_), .Y(new_n311_));
  NAND2x1_ASAP7_75t_R  g225(.A(p23), .B(new_n176_), .Y(new_n312_));
  AOI22x1_ASAP7_75t_R  g226(.A1(new_n311_), .A2(new_n312_), .B1(new_n268_), .B2(new_n267_), .Y(new_n313_));
  AND4x2_ASAP7_75t_R   g227(.A(new_n287_), .B(new_n313_), .C(new_n286_), .D(new_n308_), .Y(new_n314_));
  NAND2x1_ASAP7_75t_R  g228(.A(new_n204_), .B(new_n297_), .Y(new_n315_));
  NOR3x1_ASAP7_75t_R   g229(.A(new_n202_), .B(new_n207_), .C(new_n194_), .Y(new_n316_));
  AO22x1_ASAP7_75t_R   g230(.A1(p32), .A2(new_n265_), .B1(p33), .B2(new_n284_), .Y(new_n317_));
  OAI21x1_ASAP7_75t_R  g231(.A1(new_n277_), .A2(new_n294_), .B(new_n258_), .Y(new_n318_));
  AOI21x1_ASAP7_75t_R  g232(.A1(new_n313_), .A2(new_n317_), .B(new_n318_), .Y(new_n319_));
  OA31x2_ASAP7_75t_R   g233(.A1(new_n270_), .A2(new_n315_), .A3(new_n316_), .B1(new_n319_), .Y(new_n320_));
  NAND2x1_ASAP7_75t_R  g234(.A(new_n291_), .B(new_n292_), .Y(new_n321_));
  AO22x1_ASAP7_75t_R   g235(.A1(p44), .A2(p49), .B1(p30), .B2(new_n167_), .Y(new_n322_));
  AO21x1_ASAP7_75t_R   g236(.A1(p43), .A2(new_n321_), .B(new_n322_), .Y(new_n323_));
  AO21x1_ASAP7_75t_R   g237(.A1(p48), .A2(new_n294_), .B(new_n323_), .Y(new_n324_));
  AOI21x1_ASAP7_75t_R  g238(.A1(p47), .A2(new_n308_), .B(new_n324_), .Y(new_n325_));
  OA31x2_ASAP7_75t_R   g239(.A1(new_n309_), .A2(new_n314_), .A3(new_n320_), .B1(new_n325_), .Y(o23));
  NOR2x1_ASAP7_75t_R   g240(.A(p32), .B(new_n265_), .Y(new_n327_));
  NOR2x1_ASAP7_75t_R   g241(.A(new_n327_), .B(new_n288_), .Y(new_n328_));
  AND2x2_ASAP7_75t_R   g242(.A(new_n258_), .B(new_n269_), .Y(new_n329_));
  NOR2x1_ASAP7_75t_R   g243(.A(new_n328_), .B(new_n329_), .Y(new_n330_));
  AO21x1_ASAP7_75t_R   g244(.A1(new_n312_), .A2(new_n311_), .B(new_n285_), .Y(new_n331_));
  AO21x1_ASAP7_75t_R   g245(.A1(new_n300_), .A2(new_n205_), .B(new_n331_), .Y(new_n332_));
  NAND2x1_ASAP7_75t_R  g246(.A(new_n330_), .B(new_n332_), .Y(new_n333_));
  AOI21x1_ASAP7_75t_R  g247(.A1(new_n300_), .A2(new_n205_), .B(new_n331_), .Y(new_n334_));
  AO21x1_ASAP7_75t_R   g248(.A1(new_n328_), .A2(new_n329_), .B(new_n224_), .Y(new_n335_));
  AOI21x1_ASAP7_75t_R  g249(.A1(new_n329_), .A2(new_n334_), .B(new_n335_), .Y(new_n336_));
  AO21x1_ASAP7_75t_R   g250(.A1(p48), .A2(p31), .B(p43), .Y(new_n337_));
  AO22x1_ASAP7_75t_R   g251(.A1(p21), .A2(p49), .B1(p31), .B2(new_n167_), .Y(new_n338_));
  AO21x1_ASAP7_75t_R   g252(.A1(new_n253_), .A2(new_n337_), .B(new_n338_), .Y(new_n339_));
  AO21x1_ASAP7_75t_R   g253(.A1(new_n257_), .A2(new_n337_), .B(new_n339_), .Y(new_n340_));
  AO21x1_ASAP7_75t_R   g254(.A1(p47), .A2(new_n329_), .B(new_n340_), .Y(new_n341_));
  AOI21x1_ASAP7_75t_R  g255(.A1(new_n333_), .A2(new_n336_), .B(new_n341_), .Y(o24));
  INVx1_ASAP7_75t_R    g256(.A(new_n296_), .Y(new_n343_));
  NAND2x1_ASAP7_75t_R  g257(.A(new_n300_), .B(new_n205_), .Y(new_n344_));
  INVx1_ASAP7_75t_R    g258(.A(new_n327_), .Y(new_n345_));
  NAND2x1_ASAP7_75t_R  g259(.A(p32), .B(new_n265_), .Y(new_n346_));
  AND3x1_ASAP7_75t_R   g260(.A(new_n345_), .B(new_n297_), .C(new_n346_), .Y(new_n347_));
  OAI21x1_ASAP7_75t_R  g261(.A1(new_n343_), .A2(new_n344_), .B(new_n347_), .Y(new_n348_));
  NAND2x1_ASAP7_75t_R  g262(.A(new_n346_), .B(new_n345_), .Y(new_n349_));
  AND2x2_ASAP7_75t_R   g263(.A(new_n296_), .B(new_n349_), .Y(new_n350_));
  OAI21x1_ASAP7_75t_R  g264(.A1(new_n207_), .A2(new_n212_), .B(new_n286_), .Y(new_n351_));
  AOI21x1_ASAP7_75t_R  g265(.A1(new_n350_), .A2(new_n351_), .B(new_n224_), .Y(new_n352_));
  NAND2x1_ASAP7_75t_R  g266(.A(p43), .B(new_n265_), .Y(new_n353_));
  AOI22x1_ASAP7_75t_R  g267(.A1(new_n167_), .A2(p32), .B1(p22), .B2(p49), .Y(new_n354_));
  OA211x2_ASAP7_75t_R  g268(.A1(new_n161_), .A2(new_n346_), .B(new_n353_), .C(new_n354_), .Y(new_n355_));
  OAI21x1_ASAP7_75t_R  g269(.A1(new_n232_), .A2(new_n349_), .B(new_n355_), .Y(new_n356_));
  AOI21x1_ASAP7_75t_R  g270(.A1(new_n348_), .A2(new_n352_), .B(new_n356_), .Y(o25));
endmodule


