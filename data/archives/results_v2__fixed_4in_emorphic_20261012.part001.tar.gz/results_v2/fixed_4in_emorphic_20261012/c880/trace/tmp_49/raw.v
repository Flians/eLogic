// Benchmark "/tmp/" written by ABC on Mon Oct 12 15:07:59 2026

module \/tmp/  ( 
    p8, p42, p28, p38, p30, p44, p51, p18, p19, p41, p24, p50, p5, p31,
    p16, p32, p13, p17, p0, p1, p7, p52, p6, p15, p26, p48, p14, p12, p36,
    p34, p56, p39, p20, p33, p9, p21, p25, p10, p2, p54, p27, p35, p58,
    p59, p22, p4, p29, p3, p11, p53, p45, p46, p23, p37, p40, p43, p47,
    p57, p55, p49,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25  );
  input  p8, p42, p28, p38, p30, p44, p51, p18, p19, p41, p24, p50, p5,
    p31, p16, p32, p13, p17, p0, p1, p7, p52, p6, p15, p26, p48, p14, p12,
    p36, p34, p56, p39, p20, p33, p9, p21, p25, p10, p2, p54, p27, p35,
    p58, p59, p22, p4, p29, p3, p11, p53, p45, p46, p23, p37, p40, p43,
    p47, p57, p55, p49;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25;
  wire new_n87_, new_n88_, new_n90_, new_n91_, new_n92_, new_n94_, new_n97_,
    new_n98_, new_n99_, new_n101_, new_n109_, new_n111_, new_n114_,
    new_n115_, new_n116_, new_n117_, new_n118_, new_n119_, new_n120_,
    new_n121_, new_n123_, new_n124_, new_n125_, new_n126_, new_n127_,
    new_n128_, new_n129_, new_n130_, new_n132_, new_n133_, new_n134_,
    new_n135_, new_n136_, new_n137_, new_n138_, new_n139_, new_n140_,
    new_n141_, new_n142_, new_n143_, new_n144_, new_n145_, new_n146_,
    new_n147_, new_n148_, new_n149_, new_n150_, new_n151_, new_n152_,
    new_n153_, new_n154_, new_n155_, new_n156_, new_n157_, new_n158_,
    new_n159_, new_n160_, new_n161_, new_n162_, new_n163_, new_n164_,
    new_n165_, new_n166_, new_n167_, new_n168_, new_n169_, new_n170_,
    new_n171_, new_n172_, new_n173_, new_n174_, new_n175_, new_n176_,
    new_n177_, new_n178_, new_n179_, new_n181_, new_n182_, new_n183_,
    new_n184_, new_n185_, new_n186_, new_n187_, new_n188_, new_n189_,
    new_n190_, new_n191_, new_n192_, new_n193_, new_n194_, new_n195_,
    new_n196_, new_n197_, new_n198_, new_n199_, new_n200_, new_n201_,
    new_n202_, new_n203_, new_n204_, new_n205_, new_n206_, new_n207_,
    new_n208_, new_n209_, new_n210_, new_n211_, new_n212_, new_n213_,
    new_n214_, new_n215_, new_n216_, new_n217_, new_n218_, new_n219_,
    new_n220_, new_n221_, new_n222_, new_n223_, new_n224_, new_n225_,
    new_n226_, new_n227_, new_n228_, new_n229_, new_n230_, new_n232_,
    new_n233_, new_n234_, new_n235_, new_n236_, new_n237_, new_n238_,
    new_n239_, new_n240_, new_n241_, new_n242_, new_n243_, new_n244_,
    new_n245_, new_n246_, new_n247_, new_n248_, new_n249_, new_n250_,
    new_n251_, new_n252_, new_n253_, new_n254_, new_n255_, new_n256_,
    new_n258_, new_n259_, new_n260_, new_n261_, new_n262_, new_n263_,
    new_n264_, new_n265_, new_n266_, new_n267_, new_n269_, new_n270_,
    new_n271_, new_n272_, new_n273_, new_n274_, new_n275_, new_n276_,
    new_n277_, new_n278_, new_n279_, new_n280_, new_n281_, new_n282_,
    new_n283_, new_n284_, new_n285_, new_n286_, new_n287_, new_n288_,
    new_n289_, new_n290_, new_n291_, new_n292_, new_n293_, new_n294_,
    new_n295_, new_n296_, new_n297_, new_n298_, new_n299_, new_n300_,
    new_n301_, new_n302_, new_n303_, new_n304_, new_n305_, new_n306_,
    new_n307_, new_n308_, new_n309_, new_n310_, new_n311_, new_n312_,
    new_n313_, new_n314_, new_n315_, new_n316_, new_n317_, new_n318_,
    new_n319_, new_n320_, new_n321_, new_n322_, new_n324_, new_n325_,
    new_n326_, new_n327_, new_n328_, new_n329_, new_n330_, new_n331_,
    new_n332_, new_n333_, new_n334_, new_n335_, new_n336_, new_n337_,
    new_n338_, new_n339_, new_n340_, new_n341_, new_n342_, new_n343_,
    new_n344_, new_n345_, new_n347_, new_n348_, new_n349_, new_n350_,
    new_n351_, new_n352_, new_n353_, new_n354_, new_n355_, new_n356_,
    new_n357_, new_n358_, new_n359_, new_n360_, new_n362_, new_n363_,
    new_n364_, new_n365_, new_n366_, new_n367_, new_n368_, new_n369_,
    new_n370_, new_n371_, new_n372_, new_n373_, new_n374_, new_n375_,
    new_n376_, new_n377_, new_n379_, new_n380_, new_n381_, new_n382_,
    new_n383_, new_n384_, new_n385_, new_n386_, new_n387_, new_n388_,
    new_n389_, new_n390_, new_n391_, new_n392_;
  NAND2x1_ASAP7_75t_R  g000(.A(p0), .B(p1), .Y(new_n87_));
  INVx1_ASAP7_75t_R    g001(.A(new_n87_), .Y(new_n88_));
  NAND2x1_ASAP7_75t_R  g002(.A(p59), .B(new_n88_), .Y(o0));
  INVx1_ASAP7_75t_R    g003(.A(p1), .Y(new_n90_));
  INVx1_ASAP7_75t_R    g004(.A(p2), .Y(new_n91_));
  INVx1_ASAP7_75t_R    g005(.A(p3), .Y(new_n92_));
  OR3x1_ASAP7_75t_R    g006(.A(new_n90_), .B(new_n91_), .C(new_n92_), .Y(o1));
  AND3x1_ASAP7_75t_R   g007(.A(p1), .B(p59), .C(p3), .Y(new_n94_));
  INVx1_ASAP7_75t_R    g008(.A(new_n94_), .Y(o2));
  NAND2x1_ASAP7_75t_R  g009(.A(p5), .B(p4), .Y(o3));
  AND2x2_ASAP7_75t_R   g010(.A(p7), .B(p6), .Y(new_n97_));
  NAND2x1_ASAP7_75t_R  g011(.A(p8), .B(p9), .Y(new_n98_));
  INVx1_ASAP7_75t_R    g012(.A(new_n98_), .Y(new_n99_));
  NAND2x1_ASAP7_75t_R  g013(.A(new_n97_), .B(new_n99_), .Y(o4));
  AND2x2_ASAP7_75t_R   g014(.A(p9), .B(p10), .Y(new_n101_));
  AND3x1_ASAP7_75t_R   g015(.A(o2), .B(new_n97_), .C(new_n101_), .Y(o5));
  AND3x1_ASAP7_75t_R   g016(.A(p0), .B(p2), .C(p11), .Y(o6));
  AND3x1_ASAP7_75t_R   g017(.A(p2), .B(p3), .C(p11), .Y(o7));
  AND3x1_ASAP7_75t_R   g018(.A(p59), .B(p3), .C(p11), .Y(o8));
  OAI21x1_ASAP7_75t_R  g019(.A1(p13), .A2(p14), .B(p12), .Y(o9));
  AND3x1_ASAP7_75t_R   g020(.A(new_n94_), .B(new_n97_), .C(new_n101_), .Y(o10));
  NAND3x1_ASAP7_75t_R  g021(.A(p15), .B(p9), .C(p10), .Y(o11));
  AND3x1_ASAP7_75t_R   g022(.A(p16), .B(p17), .C(p7), .Y(new_n109_));
  NAND3x1_ASAP7_75t_R  g023(.A(new_n99_), .B(p1), .C(new_n109_), .Y(o12));
  AND3x1_ASAP7_75t_R   g024(.A(new_n99_), .B(p11), .C(new_n109_), .Y(new_n111_));
  NAND2x1_ASAP7_75t_R  g025(.A(p18), .B(new_n111_), .Y(o13));
  OAI21x1_ASAP7_75t_R  g026(.A1(p13), .A2(p14), .B(p19), .Y(o14));
  XOR2x2_ASAP7_75t_R   g027(.A(p21), .B(p22), .Y(new_n114_));
  XOR2x2_ASAP7_75t_R   g028(.A(p28), .B(p24), .Y(new_n115_));
  XOR2x2_ASAP7_75t_R   g029(.A(new_n114_), .B(new_n115_), .Y(new_n116_));
  XOR2x2_ASAP7_75t_R   g030(.A(p27), .B(p23), .Y(new_n117_));
  XOR2x2_ASAP7_75t_R   g031(.A(new_n116_), .B(new_n117_), .Y(new_n118_));
  XNOR2x2_ASAP7_75t_R  g032(.A(p25), .B(p29), .Y(new_n119_));
  XOR2x2_ASAP7_75t_R   g033(.A(p26), .B(p20), .Y(new_n120_));
  XOR2x2_ASAP7_75t_R   g034(.A(new_n119_), .B(new_n120_), .Y(new_n121_));
  XOR2x2_ASAP7_75t_R   g035(.A(new_n118_), .B(new_n121_), .Y(o15));
  XOR2x2_ASAP7_75t_R   g036(.A(p33), .B(p37), .Y(new_n123_));
  XOR2x2_ASAP7_75t_R   g037(.A(p31), .B(p20), .Y(new_n124_));
  XOR2x2_ASAP7_75t_R   g038(.A(new_n123_), .B(new_n124_), .Y(new_n125_));
  XNOR2x2_ASAP7_75t_R  g039(.A(p32), .B(p36), .Y(new_n126_));
  XOR2x2_ASAP7_75t_R   g040(.A(new_n125_), .B(new_n126_), .Y(new_n127_));
  XOR2x2_ASAP7_75t_R   g041(.A(p34), .B(p35), .Y(new_n128_));
  XOR2x2_ASAP7_75t_R   g042(.A(p38), .B(p30), .Y(new_n129_));
  XOR2x2_ASAP7_75t_R   g043(.A(new_n128_), .B(new_n129_), .Y(new_n130_));
  XOR2x2_ASAP7_75t_R   g044(.A(new_n127_), .B(new_n130_), .Y(o16));
  NAND2x1_ASAP7_75t_R  g045(.A(p11), .B(p46), .Y(new_n132_));
  INVx1_ASAP7_75t_R    g046(.A(p9), .Y(new_n133_));
  AO31x2_ASAP7_75t_R   g047(.A1(new_n132_), .A2(p15), .A3(p10), .B(new_n133_), .Y(new_n134_));
  OA21x2_ASAP7_75t_R   g048(.A1(p6), .A2(new_n133_), .B(p45), .Y(new_n135_));
  AND4x2_ASAP7_75t_R   g049(.A(p15), .B(p9), .C(p10), .D(p2), .Y(new_n136_));
  INVx1_ASAP7_75t_R    g050(.A(p16), .Y(new_n137_));
  NOR3x1_ASAP7_75t_R   g051(.A(new_n87_), .B(p44), .C(new_n137_), .Y(new_n138_));
  AOI22x1_ASAP7_75t_R  g052(.A1(new_n134_), .A2(new_n135_), .B1(new_n136_), .B2(new_n138_), .Y(new_n139_));
  NAND2x1_ASAP7_75t_R  g053(.A(p9), .B(p10), .Y(new_n140_));
  OAI21x1_ASAP7_75t_R  g054(.A1(p6), .A2(p59), .B(p15), .Y(new_n141_));
  NOR2x1_ASAP7_75t_R   g055(.A(new_n140_), .B(new_n141_), .Y(new_n142_));
  AOI21x1_ASAP7_75t_R  g056(.A1(p6), .A2(p59), .B(new_n132_), .Y(new_n143_));
  NAND3x1_ASAP7_75t_R  g057(.A(new_n142_), .B(new_n143_), .C(p28), .Y(new_n144_));
  AND3x1_ASAP7_75t_R   g058(.A(p0), .B(p59), .C(p11), .Y(new_n145_));
  INVx1_ASAP7_75t_R    g059(.A(p28), .Y(new_n146_));
  NAND2x1_ASAP7_75t_R  g060(.A(p6), .B(p15), .Y(new_n147_));
  OR4x2_ASAP7_75t_R    g061(.A(new_n145_), .B(new_n146_), .C(new_n98_), .D(new_n147_), .Y(new_n148_));
  INVx1_ASAP7_75t_R    g062(.A(p37), .Y(new_n149_));
  AO31x2_ASAP7_75t_R   g063(.A1(new_n139_), .A2(new_n144_), .A3(new_n148_), .B(new_n149_), .Y(new_n150_));
  NAND3x1_ASAP7_75t_R  g064(.A(p0), .B(p59), .C(p11), .Y(new_n151_));
  AND4x2_ASAP7_75t_R   g065(.A(p8), .B(p6), .C(p15), .D(p9), .Y(new_n152_));
  NAND2x1_ASAP7_75t_R  g066(.A(new_n151_), .B(new_n152_), .Y(new_n153_));
  INVx1_ASAP7_75t_R    g067(.A(new_n136_), .Y(new_n154_));
  OR3x1_ASAP7_75t_R    g068(.A(new_n87_), .B(p44), .C(new_n137_), .Y(new_n155_));
  OAI22x1_ASAP7_75t_R  g069(.A1(new_n153_), .A2(new_n146_), .B1(new_n154_), .B2(new_n155_), .Y(new_n156_));
  AND3x1_ASAP7_75t_R   g070(.A(new_n142_), .B(p28), .C(new_n143_), .Y(new_n157_));
  AOI211x1_ASAP7_75t_R g071(.A1(p11), .A2(p46), .B(new_n140_), .C(new_n147_), .Y(new_n158_));
  AO21x1_ASAP7_75t_R   g072(.A1(p45), .A2(new_n133_), .B(p37), .Y(new_n159_));
  AO21x1_ASAP7_75t_R   g073(.A1(p45), .A2(new_n158_), .B(new_n159_), .Y(new_n160_));
  OR3x1_ASAP7_75t_R    g074(.A(new_n156_), .B(new_n157_), .C(new_n160_), .Y(new_n161_));
  AO21x1_ASAP7_75t_R   g075(.A1(new_n150_), .A2(new_n161_), .B(p51), .Y(new_n162_));
  NOR3x1_ASAP7_75t_R   g076(.A(new_n145_), .B(new_n98_), .C(new_n147_), .Y(new_n163_));
  AOI22x1_ASAP7_75t_R  g077(.A1(new_n163_), .A2(p28), .B1(new_n136_), .B2(new_n138_), .Y(new_n164_));
  AOI21x1_ASAP7_75t_R  g078(.A1(p45), .A2(new_n158_), .B(new_n159_), .Y(new_n165_));
  INVx1_ASAP7_75t_R    g079(.A(p51), .Y(new_n166_));
  AO31x2_ASAP7_75t_R   g080(.A1(new_n164_), .A2(new_n144_), .A3(new_n165_), .B(new_n166_), .Y(new_n167_));
  NAND2x1_ASAP7_75t_R  g081(.A(new_n143_), .B(new_n142_), .Y(new_n168_));
  AO21x1_ASAP7_75t_R   g082(.A1(new_n153_), .A2(new_n168_), .B(new_n146_), .Y(new_n169_));
  AOI21x1_ASAP7_75t_R  g083(.A1(new_n139_), .A2(new_n169_), .B(new_n149_), .Y(new_n170_));
  OA21x2_ASAP7_75t_R   g084(.A1(new_n167_), .A2(new_n170_), .B(p50), .Y(new_n171_));
  AND3x1_ASAP7_75t_R   g085(.A(new_n161_), .B(new_n150_), .C(p47), .Y(new_n172_));
  NAND3x1_ASAP7_75t_R  g086(.A(new_n139_), .B(new_n144_), .C(new_n148_), .Y(new_n173_));
  AO21x1_ASAP7_75t_R   g087(.A1(p48), .A2(p37), .B(p43), .Y(new_n174_));
  AND3x1_ASAP7_75t_R   g088(.A(p39), .B(p59), .C(p40), .Y(new_n175_));
  AND2x2_ASAP7_75t_R   g089(.A(new_n175_), .B(new_n111_), .Y(new_n176_));
  AO22x1_ASAP7_75t_R   g090(.A1(p42), .A2(p41), .B1(p27), .B2(p49), .Y(new_n177_));
  AO21x1_ASAP7_75t_R   g091(.A1(p37), .A2(new_n176_), .B(new_n177_), .Y(new_n178_));
  AO21x1_ASAP7_75t_R   g092(.A1(new_n173_), .A2(new_n174_), .B(new_n178_), .Y(new_n179_));
  AOI211x1_ASAP7_75t_R g093(.A1(new_n162_), .A2(new_n171_), .B(new_n172_), .C(new_n179_), .Y(o17));
  INVx1_ASAP7_75t_R    g094(.A(p50), .Y(new_n181_));
  OA31x2_ASAP7_75t_R   g095(.A1(new_n157_), .A2(new_n160_), .A3(new_n156_), .B1(p51), .Y(new_n182_));
  OA21x2_ASAP7_75t_R   g096(.A1(p6), .A2(p59), .B(p15), .Y(new_n183_));
  AND2x2_ASAP7_75t_R   g097(.A(p11), .B(p46), .Y(new_n184_));
  NAND2x1_ASAP7_75t_R  g098(.A(p6), .B(p59), .Y(new_n185_));
  AND4x2_ASAP7_75t_R   g099(.A(new_n183_), .B(new_n101_), .C(new_n184_), .D(new_n185_), .Y(new_n186_));
  NOR2x1_ASAP7_75t_R   g100(.A(p44), .B(new_n137_), .Y(new_n187_));
  AND3x1_ASAP7_75t_R   g101(.A(new_n88_), .B(new_n187_), .C(new_n136_), .Y(new_n188_));
  AND3x1_ASAP7_75t_R   g102(.A(new_n152_), .B(p26), .C(new_n151_), .Y(new_n189_));
  AOI211x1_ASAP7_75t_R g103(.A1(p26), .A2(new_n186_), .B(new_n188_), .C(new_n189_), .Y(new_n190_));
  OA21x2_ASAP7_75t_R   g104(.A1(p6), .A2(new_n133_), .B(p54), .Y(new_n191_));
  AOI21x1_ASAP7_75t_R  g105(.A1(new_n191_), .A2(new_n134_), .B(p35), .Y(new_n192_));
  AND3x1_ASAP7_75t_R   g106(.A(new_n152_), .B(p27), .C(new_n151_), .Y(new_n193_));
  AOI211x1_ASAP7_75t_R g107(.A1(p27), .A2(new_n186_), .B(new_n188_), .C(new_n193_), .Y(new_n194_));
  OA21x2_ASAP7_75t_R   g108(.A1(p6), .A2(new_n133_), .B(p53), .Y(new_n195_));
  AOI21x1_ASAP7_75t_R  g109(.A1(new_n195_), .A2(new_n134_), .B(p36), .Y(new_n196_));
  AOI22x1_ASAP7_75t_R  g110(.A1(new_n190_), .A2(new_n192_), .B1(new_n194_), .B2(new_n196_), .Y(new_n197_));
  OAI21x1_ASAP7_75t_R  g111(.A1(new_n170_), .A2(new_n182_), .B(new_n197_), .Y(new_n198_));
  AOI21x1_ASAP7_75t_R  g112(.A1(p25), .A2(new_n163_), .B(new_n188_), .Y(new_n199_));
  NAND2x1_ASAP7_75t_R  g113(.A(p25), .B(new_n186_), .Y(new_n200_));
  OA21x2_ASAP7_75t_R   g114(.A1(p6), .A2(new_n133_), .B(p52), .Y(new_n201_));
  AOI21x1_ASAP7_75t_R  g115(.A1(new_n201_), .A2(new_n134_), .B(p34), .Y(new_n202_));
  NAND3x1_ASAP7_75t_R  g116(.A(new_n199_), .B(new_n200_), .C(new_n202_), .Y(new_n203_));
  NAND2x1_ASAP7_75t_R  g117(.A(new_n201_), .B(new_n134_), .Y(new_n204_));
  INVx1_ASAP7_75t_R    g118(.A(p34), .Y(new_n205_));
  AO31x2_ASAP7_75t_R   g119(.A1(new_n199_), .A2(new_n204_), .A3(new_n200_), .B(new_n205_), .Y(new_n206_));
  NAND2x1_ASAP7_75t_R  g120(.A(new_n203_), .B(new_n206_), .Y(new_n207_));
  AOI22x1_ASAP7_75t_R  g121(.A1(new_n134_), .A2(new_n195_), .B1(new_n136_), .B2(new_n138_), .Y(new_n208_));
  AOI21x1_ASAP7_75t_R  g122(.A1(p27), .A2(new_n186_), .B(new_n193_), .Y(new_n209_));
  INVx1_ASAP7_75t_R    g123(.A(p36), .Y(new_n210_));
  AOI21x1_ASAP7_75t_R  g124(.A1(new_n208_), .A2(new_n209_), .B(new_n210_), .Y(new_n211_));
  NAND2x1_ASAP7_75t_R  g125(.A(new_n192_), .B(new_n190_), .Y(new_n212_));
  AOI21x1_ASAP7_75t_R  g126(.A1(new_n134_), .A2(new_n191_), .B(new_n188_), .Y(new_n213_));
  INVx1_ASAP7_75t_R    g127(.A(p26), .Y(new_n214_));
  AO21x1_ASAP7_75t_R   g128(.A1(new_n153_), .A2(new_n168_), .B(new_n214_), .Y(new_n215_));
  INVx1_ASAP7_75t_R    g129(.A(p35), .Y(new_n216_));
  AOI21x1_ASAP7_75t_R  g130(.A1(new_n213_), .A2(new_n215_), .B(new_n216_), .Y(new_n217_));
  AOI21x1_ASAP7_75t_R  g131(.A1(new_n211_), .A2(new_n212_), .B(new_n217_), .Y(new_n218_));
  AND3x1_ASAP7_75t_R   g132(.A(new_n198_), .B(new_n207_), .C(new_n218_), .Y(new_n219_));
  NOR2x1_ASAP7_75t_R   g133(.A(new_n181_), .B(new_n219_), .Y(new_n220_));
  INVx1_ASAP7_75t_R    g134(.A(new_n206_), .Y(new_n221_));
  AND3x1_ASAP7_75t_R   g135(.A(new_n199_), .B(new_n200_), .C(new_n202_), .Y(new_n222_));
  AO211x2_ASAP7_75t_R  g136(.A1(new_n198_), .A2(new_n218_), .B(new_n221_), .C(new_n222_), .Y(new_n223_));
  INVx1_ASAP7_75t_R    g137(.A(new_n207_), .Y(new_n224_));
  INVx1_ASAP7_75t_R    g138(.A(p43), .Y(new_n225_));
  AND3x1_ASAP7_75t_R   g139(.A(new_n199_), .B(new_n204_), .C(new_n200_), .Y(new_n226_));
  AOI22x1_ASAP7_75t_R  g140(.A1(new_n176_), .A2(p34), .B1(p24), .B2(p49), .Y(new_n227_));
  OAI21x1_ASAP7_75t_R  g141(.A1(new_n225_), .A2(new_n226_), .B(new_n227_), .Y(new_n228_));
  AO21x1_ASAP7_75t_R   g142(.A1(p48), .A2(new_n221_), .B(new_n228_), .Y(new_n229_));
  AO21x1_ASAP7_75t_R   g143(.A1(p47), .A2(new_n224_), .B(new_n229_), .Y(new_n230_));
  AOI21x1_ASAP7_75t_R  g144(.A1(new_n220_), .A2(new_n223_), .B(new_n230_), .Y(o18));
  NAND3x1_ASAP7_75t_R  g145(.A(new_n142_), .B(new_n143_), .C(p27), .Y(new_n232_));
  NAND2x1_ASAP7_75t_R  g146(.A(new_n136_), .B(new_n138_), .Y(new_n233_));
  NAND3x1_ASAP7_75t_R  g147(.A(new_n152_), .B(p27), .C(new_n151_), .Y(new_n234_));
  NAND3x1_ASAP7_75t_R  g148(.A(new_n232_), .B(new_n233_), .C(new_n234_), .Y(new_n235_));
  INVx1_ASAP7_75t_R    g149(.A(new_n196_), .Y(new_n236_));
  NOR2x1_ASAP7_75t_R   g150(.A(new_n235_), .B(new_n236_), .Y(new_n237_));
  NOR2x1_ASAP7_75t_R   g151(.A(new_n182_), .B(new_n170_), .Y(new_n238_));
  NOR2x1_ASAP7_75t_R   g152(.A(new_n237_), .B(new_n238_), .Y(new_n239_));
  AND2x2_ASAP7_75t_R   g153(.A(new_n191_), .B(new_n134_), .Y(new_n240_));
  NAND3x1_ASAP7_75t_R  g154(.A(new_n142_), .B(new_n143_), .C(p26), .Y(new_n241_));
  OR4x2_ASAP7_75t_R    g155(.A(new_n145_), .B(new_n214_), .C(new_n98_), .D(new_n147_), .Y(new_n242_));
  NAND3x1_ASAP7_75t_R  g156(.A(new_n241_), .B(new_n242_), .C(new_n233_), .Y(new_n243_));
  OAI21x1_ASAP7_75t_R  g157(.A1(new_n240_), .A2(new_n243_), .B(p35), .Y(new_n244_));
  NAND2x1_ASAP7_75t_R  g158(.A(new_n212_), .B(new_n244_), .Y(new_n245_));
  INVx1_ASAP7_75t_R    g159(.A(new_n245_), .Y(new_n246_));
  OR3x1_ASAP7_75t_R    g160(.A(new_n239_), .B(new_n211_), .C(new_n246_), .Y(new_n247_));
  AND3x1_ASAP7_75t_R   g161(.A(new_n244_), .B(new_n212_), .C(new_n211_), .Y(new_n248_));
  AOI211x1_ASAP7_75t_R g162(.A1(new_n246_), .A2(new_n239_), .B(new_n181_), .C(new_n248_), .Y(new_n249_));
  AND3x1_ASAP7_75t_R   g163(.A(new_n244_), .B(new_n212_), .C(p47), .Y(new_n250_));
  AO22x1_ASAP7_75t_R   g164(.A1(p41), .A2(p55), .B1(p25), .B2(p49), .Y(new_n251_));
  AO21x1_ASAP7_75t_R   g165(.A1(p35), .A2(new_n176_), .B(new_n251_), .Y(new_n252_));
  AO21x1_ASAP7_75t_R   g166(.A1(p48), .A2(p35), .B(p43), .Y(new_n253_));
  NAND2x1_ASAP7_75t_R  g167(.A(new_n213_), .B(new_n215_), .Y(new_n254_));
  AND2x2_ASAP7_75t_R   g168(.A(new_n253_), .B(new_n254_), .Y(new_n255_));
  OR3x1_ASAP7_75t_R    g169(.A(new_n250_), .B(new_n252_), .C(new_n255_), .Y(new_n256_));
  AOI21x1_ASAP7_75t_R  g170(.A1(new_n247_), .A2(new_n249_), .B(new_n256_), .Y(o19));
  NOR2x1_ASAP7_75t_R   g171(.A(new_n211_), .B(new_n237_), .Y(new_n258_));
  NOR3x1_ASAP7_75t_R   g172(.A(new_n156_), .B(new_n157_), .C(new_n160_), .Y(new_n259_));
  OAI21x1_ASAP7_75t_R  g173(.A1(new_n166_), .A2(new_n259_), .B(new_n150_), .Y(new_n260_));
  XOR2x2_ASAP7_75t_R   g174(.A(new_n258_), .B(new_n260_), .Y(new_n261_));
  NAND2x1_ASAP7_75t_R  g175(.A(new_n208_), .B(new_n209_), .Y(new_n262_));
  AO21x1_ASAP7_75t_R   g176(.A1(p48), .A2(new_n262_), .B(new_n176_), .Y(new_n263_));
  AO22x1_ASAP7_75t_R   g177(.A1(p41), .A2(p56), .B1(p26), .B2(p49), .Y(new_n264_));
  AO21x1_ASAP7_75t_R   g178(.A1(p43), .A2(new_n262_), .B(new_n264_), .Y(new_n265_));
  AO21x1_ASAP7_75t_R   g179(.A1(p47), .A2(new_n258_), .B(new_n265_), .Y(new_n266_));
  AO21x1_ASAP7_75t_R   g180(.A1(p36), .A2(new_n263_), .B(new_n266_), .Y(new_n267_));
  AOI21x1_ASAP7_75t_R  g181(.A1(p50), .A2(new_n261_), .B(new_n267_), .Y(o20));
  OAI21x1_ASAP7_75t_R  g182(.A1(new_n163_), .A2(new_n186_), .B(p23), .Y(new_n269_));
  INVx1_ASAP7_75t_R    g183(.A(p6), .Y(new_n270_));
  NOR3x1_ASAP7_75t_R   g184(.A(new_n87_), .B(p44), .C(new_n270_), .Y(new_n271_));
  AND3x1_ASAP7_75t_R   g185(.A(p15), .B(p9), .C(p10), .Y(new_n272_));
  AND2x2_ASAP7_75t_R   g186(.A(p16), .B(p53), .Y(new_n273_));
  AND2x2_ASAP7_75t_R   g187(.A(p6), .B(p57), .Y(new_n274_));
  AO31x2_ASAP7_75t_R   g188(.A1(new_n272_), .A2(new_n273_), .A3(new_n132_), .B(new_n274_), .Y(new_n275_));
  AOI211x1_ASAP7_75t_R g189(.A1(new_n136_), .A2(new_n271_), .B(p32), .C(new_n275_), .Y(new_n276_));
  OAI21x1_ASAP7_75t_R  g190(.A1(new_n163_), .A2(new_n186_), .B(p24), .Y(new_n277_));
  AND2x2_ASAP7_75t_R   g191(.A(p16), .B(p45), .Y(new_n278_));
  AND2x2_ASAP7_75t_R   g192(.A(p58), .B(p57), .Y(new_n279_));
  AO31x2_ASAP7_75t_R   g193(.A1(new_n272_), .A2(new_n278_), .A3(new_n132_), .B(new_n279_), .Y(new_n280_));
  AOI211x1_ASAP7_75t_R g194(.A1(new_n136_), .A2(new_n271_), .B(p33), .C(new_n280_), .Y(new_n281_));
  AOI22x1_ASAP7_75t_R  g195(.A1(new_n269_), .A2(new_n276_), .B1(new_n277_), .B2(new_n281_), .Y(new_n282_));
  AND3x1_ASAP7_75t_R   g196(.A(new_n152_), .B(p22), .C(new_n151_), .Y(new_n283_));
  AOI21x1_ASAP7_75t_R  g197(.A1(p22), .A2(new_n186_), .B(new_n283_), .Y(new_n284_));
  INVx1_ASAP7_75t_R    g198(.A(p31), .Y(new_n285_));
  AND2x2_ASAP7_75t_R   g199(.A(p15), .B(p57), .Y(new_n286_));
  AND2x2_ASAP7_75t_R   g200(.A(p16), .B(p54), .Y(new_n287_));
  AND3x1_ASAP7_75t_R   g201(.A(new_n272_), .B(new_n287_), .C(new_n132_), .Y(new_n288_));
  AOI211x1_ASAP7_75t_R g202(.A1(new_n136_), .A2(new_n271_), .B(new_n286_), .C(new_n288_), .Y(new_n289_));
  NAND3x1_ASAP7_75t_R  g203(.A(new_n284_), .B(new_n285_), .C(new_n289_), .Y(new_n290_));
  NAND3x1_ASAP7_75t_R  g204(.A(new_n282_), .B(new_n203_), .C(new_n290_), .Y(new_n291_));
  AO31x2_ASAP7_75t_R   g205(.A1(new_n198_), .A2(new_n206_), .A3(new_n218_), .B(new_n291_), .Y(new_n292_));
  OAI21x1_ASAP7_75t_R  g206(.A1(new_n163_), .A2(new_n186_), .B(p21), .Y(new_n293_));
  INVx1_ASAP7_75t_R    g207(.A(p52), .Y(new_n294_));
  OR4x2_ASAP7_75t_R    g208(.A(new_n184_), .B(o11), .C(new_n137_), .D(new_n294_), .Y(new_n295_));
  NAND2x1_ASAP7_75t_R  g209(.A(new_n136_), .B(new_n271_), .Y(new_n296_));
  NAND2x1_ASAP7_75t_R  g210(.A(p8), .B(p57), .Y(new_n297_));
  AND3x1_ASAP7_75t_R   g211(.A(new_n295_), .B(new_n296_), .C(new_n297_), .Y(new_n298_));
  INVx1_ASAP7_75t_R    g212(.A(p30), .Y(new_n299_));
  AO21x1_ASAP7_75t_R   g213(.A1(new_n293_), .A2(new_n298_), .B(new_n299_), .Y(new_n300_));
  AOI211x1_ASAP7_75t_R g214(.A1(p22), .A2(new_n186_), .B(new_n283_), .C(new_n288_), .Y(new_n301_));
  AOI211x1_ASAP7_75t_R g215(.A1(new_n136_), .A2(new_n271_), .B(p31), .C(new_n286_), .Y(new_n302_));
  AOI22x1_ASAP7_75t_R  g216(.A1(new_n301_), .A2(new_n302_), .B1(new_n269_), .B2(new_n276_), .Y(new_n303_));
  INVx1_ASAP7_75t_R    g217(.A(p32), .Y(new_n304_));
  NAND3x1_ASAP7_75t_R  g218(.A(new_n142_), .B(new_n143_), .C(p23), .Y(new_n305_));
  NAND2x1_ASAP7_75t_R  g219(.A(p16), .B(p53), .Y(new_n306_));
  NAND2x1_ASAP7_75t_R  g220(.A(p6), .B(p57), .Y(new_n307_));
  OA31x2_ASAP7_75t_R   g221(.A1(new_n306_), .A2(o11), .A3(new_n184_), .B1(new_n307_), .Y(new_n308_));
  NAND3x1_ASAP7_75t_R  g222(.A(new_n152_), .B(p23), .C(new_n151_), .Y(new_n309_));
  AND4x2_ASAP7_75t_R   g223(.A(new_n305_), .B(new_n296_), .C(new_n308_), .D(new_n309_), .Y(new_n310_));
  NAND3x1_ASAP7_75t_R  g224(.A(new_n142_), .B(new_n143_), .C(p24), .Y(new_n311_));
  NAND2x1_ASAP7_75t_R  g225(.A(p16), .B(p45), .Y(new_n312_));
  NAND2x1_ASAP7_75t_R  g226(.A(p58), .B(p57), .Y(new_n313_));
  OA31x2_ASAP7_75t_R   g227(.A1(new_n312_), .A2(o11), .A3(new_n184_), .B1(new_n313_), .Y(new_n314_));
  NAND3x1_ASAP7_75t_R  g228(.A(new_n152_), .B(p24), .C(new_n151_), .Y(new_n315_));
  AND4x2_ASAP7_75t_R   g229(.A(new_n311_), .B(new_n296_), .C(new_n314_), .D(new_n315_), .Y(new_n316_));
  INVx1_ASAP7_75t_R    g230(.A(p33), .Y(new_n317_));
  OAI22x1_ASAP7_75t_R  g231(.A1(new_n304_), .A2(new_n310_), .B1(new_n316_), .B2(new_n317_), .Y(new_n318_));
  AOI21x1_ASAP7_75t_R  g232(.A1(new_n289_), .A2(new_n284_), .B(new_n285_), .Y(new_n319_));
  AOI21x1_ASAP7_75t_R  g233(.A1(new_n303_), .A2(new_n318_), .B(new_n319_), .Y(new_n320_));
  AND2x2_ASAP7_75t_R   g234(.A(new_n300_), .B(new_n320_), .Y(new_n321_));
  AND3x1_ASAP7_75t_R   g235(.A(new_n298_), .B(new_n299_), .C(new_n293_), .Y(new_n322_));
  AO21x1_ASAP7_75t_R   g236(.A1(new_n292_), .A2(new_n321_), .B(new_n322_), .Y(o21));
  NAND2x1_ASAP7_75t_R  g237(.A(new_n281_), .B(new_n277_), .Y(new_n324_));
  NOR3x1_ASAP7_75t_R   g238(.A(new_n184_), .B(o11), .C(new_n312_), .Y(new_n325_));
  AOI211x1_ASAP7_75t_R g239(.A1(new_n136_), .A2(new_n271_), .B(new_n279_), .C(new_n325_), .Y(new_n326_));
  AO31x2_ASAP7_75t_R   g240(.A1(new_n326_), .A2(new_n315_), .A3(new_n311_), .B(new_n317_), .Y(new_n327_));
  NAND2x1_ASAP7_75t_R  g241(.A(new_n324_), .B(new_n327_), .Y(new_n328_));
  AO31x2_ASAP7_75t_R   g242(.A1(new_n208_), .A2(new_n232_), .A3(new_n234_), .B(new_n210_), .Y(new_n329_));
  INVx1_ASAP7_75t_R    g243(.A(new_n192_), .Y(new_n330_));
  NOR2x1_ASAP7_75t_R   g244(.A(new_n330_), .B(new_n243_), .Y(new_n331_));
  OAI21x1_ASAP7_75t_R  g245(.A1(new_n329_), .A2(new_n331_), .B(new_n244_), .Y(new_n332_));
  OAI22x1_ASAP7_75t_R  g246(.A1(new_n243_), .A2(new_n330_), .B1(new_n236_), .B2(new_n235_), .Y(new_n333_));
  AOI211x1_ASAP7_75t_R g247(.A1(new_n150_), .A2(new_n167_), .B(new_n222_), .C(new_n333_), .Y(new_n334_));
  AOI211x1_ASAP7_75t_R g248(.A1(new_n203_), .A2(new_n332_), .B(new_n221_), .C(new_n334_), .Y(new_n335_));
  NAND2x1_ASAP7_75t_R  g249(.A(new_n328_), .B(new_n335_), .Y(new_n336_));
  INVx1_ASAP7_75t_R    g250(.A(new_n328_), .Y(new_n337_));
  AO21x1_ASAP7_75t_R   g251(.A1(new_n221_), .A2(new_n337_), .B(new_n181_), .Y(new_n338_));
  AOI211x1_ASAP7_75t_R g252(.A1(new_n218_), .A2(new_n198_), .B(new_n222_), .C(new_n328_), .Y(new_n339_));
  NOR2x1_ASAP7_75t_R   g253(.A(new_n338_), .B(new_n339_), .Y(new_n340_));
  INVx1_ASAP7_75t_R    g254(.A(p48), .Y(new_n341_));
  AOI22x1_ASAP7_75t_R  g255(.A1(new_n176_), .A2(p33), .B1(p23), .B2(p49), .Y(new_n342_));
  OA21x2_ASAP7_75t_R   g256(.A1(new_n225_), .A2(new_n316_), .B(new_n342_), .Y(new_n343_));
  OAI21x1_ASAP7_75t_R  g257(.A1(new_n341_), .A2(new_n327_), .B(new_n343_), .Y(new_n344_));
  AO21x1_ASAP7_75t_R   g258(.A1(p47), .A2(new_n337_), .B(new_n344_), .Y(new_n345_));
  AOI21x1_ASAP7_75t_R  g259(.A1(new_n336_), .A2(new_n340_), .B(new_n345_), .Y(o22));
  AOI211x1_ASAP7_75t_R g260(.A1(new_n197_), .A2(new_n260_), .B(new_n221_), .C(new_n332_), .Y(new_n347_));
  NAND3x1_ASAP7_75t_R  g261(.A(new_n298_), .B(new_n299_), .C(new_n293_), .Y(new_n348_));
  NAND2x1_ASAP7_75t_R  g262(.A(new_n348_), .B(new_n300_), .Y(new_n349_));
  OR3x1_ASAP7_75t_R    g263(.A(new_n347_), .B(new_n291_), .C(new_n349_), .Y(new_n350_));
  AO21x1_ASAP7_75t_R   g264(.A1(new_n348_), .A2(new_n300_), .B(new_n319_), .Y(new_n351_));
  AOI21x1_ASAP7_75t_R  g265(.A1(new_n303_), .A2(new_n318_), .B(new_n351_), .Y(new_n352_));
  OAI21x1_ASAP7_75t_R  g266(.A1(new_n349_), .A2(new_n320_), .B(p50), .Y(new_n353_));
  AOI21x1_ASAP7_75t_R  g267(.A1(new_n352_), .A2(new_n292_), .B(new_n353_), .Y(new_n354_));
  NAND2x1_ASAP7_75t_R  g268(.A(new_n293_), .B(new_n298_), .Y(new_n355_));
  AO22x1_ASAP7_75t_R   g269(.A1(p44), .A2(p49), .B1(p30), .B2(new_n176_), .Y(new_n356_));
  AO21x1_ASAP7_75t_R   g270(.A1(p43), .A2(new_n355_), .B(new_n356_), .Y(new_n357_));
  AND3x1_ASAP7_75t_R   g271(.A(new_n300_), .B(p47), .C(new_n348_), .Y(new_n358_));
  AND3x1_ASAP7_75t_R   g272(.A(new_n355_), .B(p30), .C(p48), .Y(new_n359_));
  OR3x1_ASAP7_75t_R    g273(.A(new_n357_), .B(new_n358_), .C(new_n359_), .Y(new_n360_));
  AOI21x1_ASAP7_75t_R  g274(.A1(new_n350_), .A2(new_n354_), .B(new_n360_), .Y(o23));
  INVx1_ASAP7_75t_R    g275(.A(new_n282_), .Y(new_n362_));
  AOI21x1_ASAP7_75t_R  g276(.A1(new_n301_), .A2(new_n302_), .B(new_n319_), .Y(new_n363_));
  NOR3x1_ASAP7_75t_R   g277(.A(new_n184_), .B(o11), .C(new_n306_), .Y(new_n364_));
  AOI211x1_ASAP7_75t_R g278(.A1(new_n136_), .A2(new_n271_), .B(new_n274_), .C(new_n364_), .Y(new_n365_));
  AO31x2_ASAP7_75t_R   g279(.A1(new_n365_), .A2(new_n309_), .A3(new_n305_), .B(new_n304_), .Y(new_n366_));
  AND4x2_ASAP7_75t_R   g280(.A(new_n365_), .B(new_n304_), .C(new_n309_), .D(new_n305_), .Y(new_n367_));
  AOI21x1_ASAP7_75t_R  g281(.A1(new_n366_), .A2(new_n327_), .B(new_n367_), .Y(new_n368_));
  NOR2x1_ASAP7_75t_R   g282(.A(new_n363_), .B(new_n368_), .Y(new_n369_));
  OAI21x1_ASAP7_75t_R  g283(.A1(new_n362_), .A2(new_n335_), .B(new_n369_), .Y(new_n370_));
  AOI21x1_ASAP7_75t_R  g284(.A1(new_n363_), .A2(new_n368_), .B(new_n181_), .Y(new_n371_));
  OA31x2_ASAP7_75t_R   g285(.A1(new_n291_), .A2(new_n319_), .A3(new_n347_), .B1(new_n371_), .Y(new_n372_));
  AND2x2_ASAP7_75t_R   g286(.A(p48), .B(new_n319_), .Y(new_n373_));
  AOI21x1_ASAP7_75t_R  g287(.A1(new_n289_), .A2(new_n284_), .B(new_n225_), .Y(new_n374_));
  AO22x1_ASAP7_75t_R   g288(.A1(p21), .A2(p49), .B1(p31), .B2(new_n176_), .Y(new_n375_));
  OR3x1_ASAP7_75t_R    g289(.A(new_n373_), .B(new_n374_), .C(new_n375_), .Y(new_n376_));
  AO21x1_ASAP7_75t_R   g290(.A1(p47), .A2(new_n363_), .B(new_n376_), .Y(new_n377_));
  AOI21x1_ASAP7_75t_R  g291(.A1(new_n370_), .A2(new_n372_), .B(new_n377_), .Y(o24));
  NOR2x1_ASAP7_75t_R   g292(.A(new_n221_), .B(new_n334_), .Y(new_n379_));
  NAND2x1_ASAP7_75t_R  g293(.A(new_n203_), .B(new_n332_), .Y(new_n380_));
  XOR2x2_ASAP7_75t_R   g294(.A(new_n310_), .B(new_n304_), .Y(new_n381_));
  NAND2x1_ASAP7_75t_R  g295(.A(new_n324_), .B(new_n381_), .Y(new_n382_));
  AO31x2_ASAP7_75t_R   g296(.A1(new_n379_), .A2(new_n380_), .A3(new_n327_), .B(new_n382_), .Y(new_n383_));
  INVx1_ASAP7_75t_R    g297(.A(new_n366_), .Y(new_n384_));
  OA21x2_ASAP7_75t_R   g298(.A1(new_n367_), .A2(new_n384_), .B(new_n327_), .Y(new_n385_));
  NAND2x1_ASAP7_75t_R  g299(.A(new_n324_), .B(new_n203_), .Y(new_n386_));
  AO31x2_ASAP7_75t_R   g300(.A1(new_n198_), .A2(new_n206_), .A3(new_n218_), .B(new_n386_), .Y(new_n387_));
  AOI21x1_ASAP7_75t_R  g301(.A1(new_n385_), .A2(new_n387_), .B(new_n181_), .Y(new_n388_));
  AOI22x1_ASAP7_75t_R  g302(.A1(new_n176_), .A2(p32), .B1(p22), .B2(p49), .Y(new_n389_));
  OA21x2_ASAP7_75t_R   g303(.A1(new_n225_), .A2(new_n310_), .B(new_n389_), .Y(new_n390_));
  OAI21x1_ASAP7_75t_R  g304(.A1(new_n341_), .A2(new_n366_), .B(new_n390_), .Y(new_n391_));
  AO21x1_ASAP7_75t_R   g305(.A1(p47), .A2(new_n381_), .B(new_n391_), .Y(new_n392_));
  AOI21x1_ASAP7_75t_R  g306(.A1(new_n383_), .A2(new_n388_), .B(new_n392_), .Y(o25));
endmodule


