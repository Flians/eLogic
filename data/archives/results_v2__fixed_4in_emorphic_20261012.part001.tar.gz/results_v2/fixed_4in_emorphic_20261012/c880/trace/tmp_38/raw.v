// Benchmark "/tmp/" written by ABC on Mon Oct 12 15:07:57 2026

module \/tmp/  ( 
    p23, p30, p50, p44, p10, p6, p29, p4, p1, p14, p49, p17, p7, p47, p54,
    p36, p58, p32, p45, p26, p48, p39, p34, p11, p16, p40, p0, p9, p52,
    p25, p12, p37, p5, p22, p56, p31, p27, p53, p18, p8, p19, p57, p13,
    p55, p15, p43, p3, p24, p35, p42, p28, p59, p38, p2, p20, p41, p46,
    p33, p21, p51,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25  );
  input  p23, p30, p50, p44, p10, p6, p29, p4, p1, p14, p49, p17, p7,
    p47, p54, p36, p58, p32, p45, p26, p48, p39, p34, p11, p16, p40, p0,
    p9, p52, p25, p12, p37, p5, p22, p56, p31, p27, p53, p18, p8, p19, p57,
    p13, p55, p15, p43, p3, p24, p35, p42, p28, p59, p38, p2, p20, p41,
    p46, p33, p21, p51;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25;
  wire new_n87_, new_n88_, new_n90_, new_n91_, new_n92_, new_n94_, new_n97_,
    new_n99_, new_n100_, new_n101_, new_n108_, new_n110_, new_n112_,
    new_n115_, new_n116_, new_n117_, new_n118_, new_n119_, new_n120_,
    new_n121_, new_n122_, new_n124_, new_n125_, new_n126_, new_n127_,
    new_n128_, new_n129_, new_n130_, new_n131_, new_n133_, new_n134_,
    new_n135_, new_n136_, new_n137_, new_n138_, new_n139_, new_n140_,
    new_n141_, new_n142_, new_n143_, new_n144_, new_n145_, new_n146_,
    new_n147_, new_n148_, new_n149_, new_n150_, new_n151_, new_n152_,
    new_n153_, new_n154_, new_n155_, new_n156_, new_n157_, new_n158_,
    new_n159_, new_n160_, new_n161_, new_n162_, new_n163_, new_n164_,
    new_n165_, new_n166_, new_n167_, new_n168_, new_n169_, new_n170_,
    new_n171_, new_n173_, new_n174_, new_n175_, new_n176_, new_n177_,
    new_n178_, new_n179_, new_n180_, new_n181_, new_n182_, new_n183_,
    new_n184_, new_n185_, new_n186_, new_n187_, new_n188_, new_n189_,
    new_n190_, new_n191_, new_n192_, new_n193_, new_n194_, new_n195_,
    new_n196_, new_n197_, new_n198_, new_n199_, new_n200_, new_n201_,
    new_n202_, new_n203_, new_n204_, new_n205_, new_n206_, new_n207_,
    new_n208_, new_n209_, new_n210_, new_n211_, new_n212_, new_n213_,
    new_n214_, new_n215_, new_n216_, new_n217_, new_n218_, new_n219_,
    new_n220_, new_n221_, new_n222_, new_n223_, new_n224_, new_n225_,
    new_n226_, new_n227_, new_n228_, new_n230_, new_n231_, new_n232_,
    new_n233_, new_n234_, new_n235_, new_n236_, new_n237_, new_n238_,
    new_n239_, new_n240_, new_n241_, new_n242_, new_n243_, new_n244_,
    new_n245_, new_n247_, new_n248_, new_n249_, new_n250_, new_n251_,
    new_n252_, new_n253_, new_n255_, new_n256_, new_n257_, new_n258_,
    new_n259_, new_n260_, new_n261_, new_n262_, new_n263_, new_n264_,
    new_n265_, new_n266_, new_n267_, new_n268_, new_n269_, new_n270_,
    new_n271_, new_n272_, new_n273_, new_n274_, new_n275_, new_n276_,
    new_n277_, new_n278_, new_n279_, new_n280_, new_n281_, new_n282_,
    new_n283_, new_n284_, new_n285_, new_n286_, new_n287_, new_n288_,
    new_n289_, new_n290_, new_n291_, new_n292_, new_n293_, new_n294_,
    new_n295_, new_n296_, new_n297_, new_n298_, new_n299_, new_n300_,
    new_n301_, new_n302_, new_n303_, new_n304_, new_n305_, new_n306_,
    new_n307_, new_n308_, new_n309_, new_n310_, new_n312_, new_n313_,
    new_n314_, new_n315_, new_n316_, new_n317_, new_n318_, new_n319_,
    new_n320_, new_n321_, new_n322_, new_n323_, new_n324_, new_n325_,
    new_n326_, new_n327_, new_n328_, new_n330_, new_n331_, new_n332_,
    new_n333_, new_n334_, new_n335_, new_n336_, new_n337_, new_n338_,
    new_n339_, new_n340_, new_n341_, new_n342_, new_n343_, new_n344_,
    new_n345_, new_n347_, new_n348_, new_n349_, new_n350_, new_n351_,
    new_n352_, new_n353_, new_n354_, new_n355_, new_n356_, new_n357_,
    new_n358_, new_n359_, new_n360_, new_n361_, new_n362_, new_n364_,
    new_n365_, new_n366_, new_n367_, new_n368_, new_n369_, new_n370_,
    new_n371_, new_n372_, new_n373_, new_n374_, new_n375_;
  INVx1_ASAP7_75t_R    g000(.A(p59), .Y(new_n87_));
  NAND2x1_ASAP7_75t_R  g001(.A(p1), .B(p0), .Y(new_n88_));
  OR2x4_ASAP7_75t_R    g002(.A(new_n87_), .B(new_n88_), .Y(o0));
  INVx1_ASAP7_75t_R    g003(.A(p1), .Y(new_n90_));
  INVx1_ASAP7_75t_R    g004(.A(p3), .Y(new_n91_));
  INVx1_ASAP7_75t_R    g005(.A(p2), .Y(new_n92_));
  OR3x1_ASAP7_75t_R    g006(.A(new_n90_), .B(new_n91_), .C(new_n92_), .Y(o1));
  AND3x1_ASAP7_75t_R   g007(.A(p1), .B(p3), .C(p59), .Y(new_n94_));
  INVx1_ASAP7_75t_R    g008(.A(new_n94_), .Y(o2));
  NAND2x1_ASAP7_75t_R  g009(.A(p4), .B(p5), .Y(o3));
  AND3x1_ASAP7_75t_R   g010(.A(p7), .B(p9), .C(p8), .Y(new_n97_));
  NAND2x1_ASAP7_75t_R  g011(.A(p6), .B(new_n97_), .Y(o4));
  AND2x2_ASAP7_75t_R   g012(.A(p6), .B(p7), .Y(new_n99_));
  NAND2x1_ASAP7_75t_R  g013(.A(p10), .B(p9), .Y(new_n100_));
  INVx1_ASAP7_75t_R    g014(.A(new_n100_), .Y(new_n101_));
  AND3x1_ASAP7_75t_R   g015(.A(o2), .B(new_n99_), .C(new_n101_), .Y(o5));
  AND3x1_ASAP7_75t_R   g016(.A(p11), .B(p0), .C(p2), .Y(o6));
  AND3x1_ASAP7_75t_R   g017(.A(p11), .B(p3), .C(p2), .Y(o7));
  AND3x1_ASAP7_75t_R   g018(.A(p11), .B(p3), .C(p59), .Y(o8));
  OAI21x1_ASAP7_75t_R  g019(.A1(p14), .A2(p13), .B(p12), .Y(o9));
  AND3x1_ASAP7_75t_R   g020(.A(new_n101_), .B(new_n94_), .C(new_n99_), .Y(o10));
  AND3x1_ASAP7_75t_R   g021(.A(p10), .B(p9), .C(p15), .Y(new_n108_));
  INVx1_ASAP7_75t_R    g022(.A(new_n108_), .Y(o11));
  AND2x2_ASAP7_75t_R   g023(.A(p17), .B(p16), .Y(new_n110_));
  NAND3x1_ASAP7_75t_R  g024(.A(new_n97_), .B(new_n110_), .C(p1), .Y(o12));
  AND3x1_ASAP7_75t_R   g025(.A(new_n97_), .B(new_n110_), .C(p11), .Y(new_n112_));
  NAND2x1_ASAP7_75t_R  g026(.A(p18), .B(new_n112_), .Y(o13));
  OAI21x1_ASAP7_75t_R  g027(.A1(p14), .A2(p13), .B(p19), .Y(o14));
  XOR2x2_ASAP7_75t_R   g028(.A(p20), .B(p21), .Y(new_n115_));
  XOR2x2_ASAP7_75t_R   g029(.A(p23), .B(p27), .Y(new_n116_));
  XOR2x2_ASAP7_75t_R   g030(.A(new_n115_), .B(new_n116_), .Y(new_n117_));
  XNOR2x2_ASAP7_75t_R  g031(.A(p24), .B(p28), .Y(new_n118_));
  XOR2x2_ASAP7_75t_R   g032(.A(new_n117_), .B(new_n118_), .Y(new_n119_));
  XOR2x2_ASAP7_75t_R   g033(.A(p29), .B(p26), .Y(new_n120_));
  XOR2x2_ASAP7_75t_R   g034(.A(p25), .B(p22), .Y(new_n121_));
  XOR2x2_ASAP7_75t_R   g035(.A(new_n120_), .B(new_n121_), .Y(new_n122_));
  XOR2x2_ASAP7_75t_R   g036(.A(new_n119_), .B(new_n122_), .Y(o15));
  XOR2x2_ASAP7_75t_R   g037(.A(p37), .B(p33), .Y(new_n124_));
  XOR2x2_ASAP7_75t_R   g038(.A(p31), .B(p20), .Y(new_n125_));
  XOR2x2_ASAP7_75t_R   g039(.A(new_n124_), .B(new_n125_), .Y(new_n126_));
  XNOR2x2_ASAP7_75t_R  g040(.A(p36), .B(p32), .Y(new_n127_));
  XOR2x2_ASAP7_75t_R   g041(.A(new_n126_), .B(new_n127_), .Y(new_n128_));
  XOR2x2_ASAP7_75t_R   g042(.A(p35), .B(p38), .Y(new_n129_));
  XOR2x2_ASAP7_75t_R   g043(.A(p30), .B(p34), .Y(new_n130_));
  XOR2x2_ASAP7_75t_R   g044(.A(new_n129_), .B(new_n130_), .Y(new_n131_));
  XOR2x2_ASAP7_75t_R   g045(.A(new_n128_), .B(new_n131_), .Y(o16));
  AND3x1_ASAP7_75t_R   g046(.A(p11), .B(p0), .C(p59), .Y(new_n133_));
  NAND2x1_ASAP7_75t_R  g047(.A(p9), .B(p8), .Y(new_n134_));
  NAND2x1_ASAP7_75t_R  g048(.A(p6), .B(p15), .Y(new_n135_));
  NOR3x1_ASAP7_75t_R   g049(.A(new_n133_), .B(new_n134_), .C(new_n135_), .Y(new_n136_));
  AND4x2_ASAP7_75t_R   g050(.A(p10), .B(p9), .C(p15), .D(p2), .Y(new_n137_));
  INVx1_ASAP7_75t_R    g051(.A(p16), .Y(new_n138_));
  NOR3x1_ASAP7_75t_R   g052(.A(new_n88_), .B(p44), .C(new_n138_), .Y(new_n139_));
  AOI22x1_ASAP7_75t_R  g053(.A1(new_n136_), .A2(p28), .B1(new_n137_), .B2(new_n139_), .Y(new_n140_));
  OAI21x1_ASAP7_75t_R  g054(.A1(p6), .A2(p59), .B(p15), .Y(new_n141_));
  NOR2x1_ASAP7_75t_R   g055(.A(new_n100_), .B(new_n141_), .Y(new_n142_));
  NAND2x1_ASAP7_75t_R  g056(.A(p11), .B(p46), .Y(new_n143_));
  AOI21x1_ASAP7_75t_R  g057(.A1(p6), .A2(p59), .B(new_n143_), .Y(new_n144_));
  NAND3x1_ASAP7_75t_R  g058(.A(new_n142_), .B(new_n144_), .C(p28), .Y(new_n145_));
  AOI211x1_ASAP7_75t_R g059(.A1(p11), .A2(p46), .B(new_n100_), .C(new_n135_), .Y(new_n146_));
  INVx1_ASAP7_75t_R    g060(.A(p9), .Y(new_n147_));
  AO21x1_ASAP7_75t_R   g061(.A1(p45), .A2(new_n147_), .B(p37), .Y(new_n148_));
  AOI21x1_ASAP7_75t_R  g062(.A1(p45), .A2(new_n146_), .B(new_n148_), .Y(new_n149_));
  AND3x1_ASAP7_75t_R   g063(.A(new_n140_), .B(new_n145_), .C(new_n149_), .Y(new_n150_));
  AO31x2_ASAP7_75t_R   g064(.A1(new_n143_), .A2(p10), .A3(p15), .B(new_n147_), .Y(new_n151_));
  OA21x2_ASAP7_75t_R   g065(.A1(p6), .A2(new_n147_), .B(p45), .Y(new_n152_));
  AOI22x1_ASAP7_75t_R  g066(.A1(new_n151_), .A2(new_n152_), .B1(new_n137_), .B2(new_n139_), .Y(new_n153_));
  NAND3x1_ASAP7_75t_R  g067(.A(p11), .B(p0), .C(p59), .Y(new_n154_));
  AND4x2_ASAP7_75t_R   g068(.A(p6), .B(p9), .C(p8), .D(p15), .Y(new_n155_));
  NAND2x1_ASAP7_75t_R  g069(.A(new_n154_), .B(new_n155_), .Y(new_n156_));
  NAND2x1_ASAP7_75t_R  g070(.A(new_n144_), .B(new_n142_), .Y(new_n157_));
  INVx1_ASAP7_75t_R    g071(.A(p28), .Y(new_n158_));
  AO21x1_ASAP7_75t_R   g072(.A1(new_n156_), .A2(new_n157_), .B(new_n158_), .Y(new_n159_));
  INVx1_ASAP7_75t_R    g073(.A(p37), .Y(new_n160_));
  AOI21x1_ASAP7_75t_R  g074(.A1(new_n153_), .A2(new_n159_), .B(new_n160_), .Y(new_n161_));
  NOR2x1_ASAP7_75t_R   g075(.A(new_n150_), .B(new_n161_), .Y(new_n162_));
  XOR2x2_ASAP7_75t_R   g076(.A(new_n162_), .B(p51), .Y(new_n163_));
  NAND2x1_ASAP7_75t_R  g077(.A(new_n153_), .B(new_n159_), .Y(new_n164_));
  AND3x1_ASAP7_75t_R   g078(.A(p39), .B(p40), .C(p59), .Y(new_n165_));
  AND2x2_ASAP7_75t_R   g079(.A(new_n165_), .B(new_n112_), .Y(new_n166_));
  AO22x1_ASAP7_75t_R   g080(.A1(p49), .A2(p27), .B1(p42), .B2(p41), .Y(new_n167_));
  AO21x1_ASAP7_75t_R   g081(.A1(p37), .A2(new_n166_), .B(new_n167_), .Y(new_n168_));
  AO21x1_ASAP7_75t_R   g082(.A1(p43), .A2(new_n164_), .B(new_n168_), .Y(new_n169_));
  AO21x1_ASAP7_75t_R   g083(.A1(p48), .A2(new_n161_), .B(new_n169_), .Y(new_n170_));
  AO21x1_ASAP7_75t_R   g084(.A1(p47), .A2(new_n162_), .B(new_n170_), .Y(new_n171_));
  AOI21x1_ASAP7_75t_R  g085(.A1(p50), .A2(new_n163_), .B(new_n171_), .Y(o17));
  INVx1_ASAP7_75t_R    g086(.A(p50), .Y(new_n173_));
  AO21x1_ASAP7_75t_R   g087(.A1(new_n144_), .A2(new_n142_), .B(new_n136_), .Y(new_n174_));
  NOR2x1_ASAP7_75t_R   g088(.A(p44), .B(new_n88_), .Y(new_n175_));
  AND3x1_ASAP7_75t_R   g089(.A(new_n175_), .B(p16), .C(new_n137_), .Y(new_n176_));
  OA21x2_ASAP7_75t_R   g090(.A1(p6), .A2(new_n147_), .B(p52), .Y(new_n177_));
  AO21x1_ASAP7_75t_R   g091(.A1(new_n177_), .A2(new_n151_), .B(p34), .Y(new_n178_));
  AO211x2_ASAP7_75t_R  g092(.A1(new_n174_), .A2(p25), .B(new_n176_), .C(new_n178_), .Y(new_n179_));
  AOI21x1_ASAP7_75t_R  g093(.A1(new_n151_), .A2(new_n177_), .B(new_n176_), .Y(new_n180_));
  NAND2x1_ASAP7_75t_R  g094(.A(p25), .B(new_n174_), .Y(new_n181_));
  INVx1_ASAP7_75t_R    g095(.A(p34), .Y(new_n182_));
  AO21x1_ASAP7_75t_R   g096(.A1(new_n180_), .A2(new_n181_), .B(new_n182_), .Y(new_n183_));
  NAND2x1_ASAP7_75t_R  g097(.A(new_n179_), .B(new_n183_), .Y(new_n184_));
  OA21x2_ASAP7_75t_R   g098(.A1(p6), .A2(new_n147_), .B(p53), .Y(new_n185_));
  AOI22x1_ASAP7_75t_R  g099(.A1(new_n151_), .A2(new_n185_), .B1(new_n137_), .B2(new_n139_), .Y(new_n186_));
  NAND3x1_ASAP7_75t_R  g100(.A(new_n142_), .B(new_n144_), .C(p27), .Y(new_n187_));
  NAND3x1_ASAP7_75t_R  g101(.A(new_n155_), .B(p27), .C(new_n154_), .Y(new_n188_));
  INVx1_ASAP7_75t_R    g102(.A(p36), .Y(new_n189_));
  AO31x2_ASAP7_75t_R   g103(.A1(new_n186_), .A2(new_n187_), .A3(new_n188_), .B(new_n189_), .Y(new_n190_));
  AOI22x1_ASAP7_75t_R  g104(.A1(new_n136_), .A2(p26), .B1(new_n137_), .B2(new_n139_), .Y(new_n191_));
  NAND3x1_ASAP7_75t_R  g105(.A(new_n142_), .B(new_n144_), .C(p26), .Y(new_n192_));
  OA21x2_ASAP7_75t_R   g106(.A1(p6), .A2(new_n147_), .B(p54), .Y(new_n193_));
  AOI21x1_ASAP7_75t_R  g107(.A1(new_n193_), .A2(new_n151_), .B(p35), .Y(new_n194_));
  AND3x1_ASAP7_75t_R   g108(.A(new_n191_), .B(new_n192_), .C(new_n194_), .Y(new_n195_));
  INVx1_ASAP7_75t_R    g109(.A(p35), .Y(new_n196_));
  NAND2x1_ASAP7_75t_R  g110(.A(new_n193_), .B(new_n151_), .Y(new_n197_));
  AND3x1_ASAP7_75t_R   g111(.A(new_n191_), .B(new_n192_), .C(new_n197_), .Y(new_n198_));
  OA22x2_ASAP7_75t_R   g112(.A1(new_n190_), .A2(new_n195_), .B1(new_n196_), .B2(new_n198_), .Y(new_n199_));
  AO21x1_ASAP7_75t_R   g113(.A1(p45), .A2(new_n146_), .B(new_n148_), .Y(new_n200_));
  INVx1_ASAP7_75t_R    g114(.A(new_n145_), .Y(new_n201_));
  NAND2x1_ASAP7_75t_R  g115(.A(new_n137_), .B(new_n139_), .Y(new_n202_));
  OAI21x1_ASAP7_75t_R  g116(.A1(new_n158_), .A2(new_n156_), .B(new_n202_), .Y(new_n203_));
  OA31x2_ASAP7_75t_R   g117(.A1(new_n200_), .A2(new_n201_), .A3(new_n203_), .B1(p51), .Y(new_n204_));
  INVx1_ASAP7_75t_R    g118(.A(p26), .Y(new_n205_));
  OR4x2_ASAP7_75t_R    g119(.A(new_n133_), .B(new_n205_), .C(new_n134_), .D(new_n135_), .Y(new_n206_));
  NAND3x1_ASAP7_75t_R  g120(.A(new_n192_), .B(new_n206_), .C(new_n202_), .Y(new_n207_));
  INVx1_ASAP7_75t_R    g121(.A(new_n194_), .Y(new_n208_));
  AO21x1_ASAP7_75t_R   g122(.A1(new_n185_), .A2(new_n151_), .B(p36), .Y(new_n209_));
  NAND3x1_ASAP7_75t_R  g123(.A(new_n187_), .B(new_n202_), .C(new_n188_), .Y(new_n210_));
  OA22x2_ASAP7_75t_R   g124(.A1(new_n207_), .A2(new_n208_), .B1(new_n209_), .B2(new_n210_), .Y(new_n211_));
  OAI21x1_ASAP7_75t_R  g125(.A1(new_n161_), .A2(new_n204_), .B(new_n211_), .Y(new_n212_));
  AND3x1_ASAP7_75t_R   g126(.A(new_n184_), .B(new_n199_), .C(new_n212_), .Y(new_n213_));
  NAND2x1_ASAP7_75t_R  g127(.A(p28), .B(new_n136_), .Y(new_n214_));
  AO31x2_ASAP7_75t_R   g128(.A1(new_n153_), .A2(new_n145_), .A3(new_n214_), .B(new_n160_), .Y(new_n215_));
  INVx1_ASAP7_75t_R    g129(.A(p51), .Y(new_n216_));
  AO31x2_ASAP7_75t_R   g130(.A1(new_n140_), .A2(new_n145_), .A3(new_n149_), .B(new_n216_), .Y(new_n217_));
  NAND2x1_ASAP7_75t_R  g131(.A(new_n215_), .B(new_n217_), .Y(new_n218_));
  OAI22x1_ASAP7_75t_R  g132(.A1(new_n190_), .A2(new_n195_), .B1(new_n198_), .B2(new_n196_), .Y(new_n219_));
  AO21x1_ASAP7_75t_R   g133(.A1(new_n218_), .A2(new_n211_), .B(new_n219_), .Y(new_n220_));
  AND3x1_ASAP7_75t_R   g134(.A(new_n220_), .B(new_n183_), .C(new_n179_), .Y(new_n221_));
  INVx1_ASAP7_75t_R    g135(.A(p47), .Y(new_n222_));
  AOI22x1_ASAP7_75t_R  g136(.A1(new_n166_), .A2(p34), .B1(p49), .B2(p24), .Y(new_n223_));
  INVx1_ASAP7_75t_R    g137(.A(p48), .Y(new_n224_));
  INVx1_ASAP7_75t_R    g138(.A(p43), .Y(new_n225_));
  OA21x2_ASAP7_75t_R   g139(.A1(new_n224_), .A2(new_n182_), .B(new_n225_), .Y(new_n226_));
  AO21x1_ASAP7_75t_R   g140(.A1(new_n180_), .A2(new_n181_), .B(new_n226_), .Y(new_n227_));
  OA211x2_ASAP7_75t_R  g141(.A1(new_n222_), .A2(new_n184_), .B(new_n223_), .C(new_n227_), .Y(new_n228_));
  OA31x2_ASAP7_75t_R   g142(.A1(new_n173_), .A2(new_n213_), .A3(new_n221_), .B1(new_n228_), .Y(o18));
  AND2x2_ASAP7_75t_R   g143(.A(new_n188_), .B(new_n187_), .Y(new_n230_));
  NAND2x1_ASAP7_75t_R  g144(.A(new_n186_), .B(new_n230_), .Y(new_n231_));
  OA21x2_ASAP7_75t_R   g145(.A1(p36), .A2(new_n231_), .B(new_n218_), .Y(new_n232_));
  AOI21x1_ASAP7_75t_R  g146(.A1(new_n186_), .A2(new_n230_), .B(new_n189_), .Y(new_n233_));
  AND3x1_ASAP7_75t_R   g147(.A(new_n192_), .B(new_n206_), .C(new_n202_), .Y(new_n234_));
  AOI21x1_ASAP7_75t_R  g148(.A1(new_n197_), .A2(new_n234_), .B(new_n196_), .Y(new_n235_));
  NOR2x1_ASAP7_75t_R   g149(.A(new_n195_), .B(new_n235_), .Y(new_n236_));
  OR3x1_ASAP7_75t_R    g150(.A(new_n232_), .B(new_n233_), .C(new_n236_), .Y(new_n237_));
  AO21x1_ASAP7_75t_R   g151(.A1(new_n233_), .A2(new_n236_), .B(new_n173_), .Y(new_n238_));
  AOI21x1_ASAP7_75t_R  g152(.A1(new_n236_), .A2(new_n232_), .B(new_n238_), .Y(new_n239_));
  OA21x2_ASAP7_75t_R   g153(.A1(new_n224_), .A2(new_n196_), .B(new_n225_), .Y(new_n240_));
  AO22x1_ASAP7_75t_R   g154(.A1(p49), .A2(p25), .B1(p55), .B2(p41), .Y(new_n241_));
  AOI21x1_ASAP7_75t_R  g155(.A1(p35), .A2(new_n166_), .B(new_n241_), .Y(new_n242_));
  OA21x2_ASAP7_75t_R   g156(.A1(new_n240_), .A2(new_n198_), .B(new_n242_), .Y(new_n243_));
  OR3x1_ASAP7_75t_R    g157(.A(new_n235_), .B(new_n222_), .C(new_n195_), .Y(new_n244_));
  NAND2x1_ASAP7_75t_R  g158(.A(new_n243_), .B(new_n244_), .Y(new_n245_));
  AOI21x1_ASAP7_75t_R  g159(.A1(new_n237_), .A2(new_n239_), .B(new_n245_), .Y(o19));
  OA21x2_ASAP7_75t_R   g160(.A1(new_n210_), .A2(new_n209_), .B(new_n190_), .Y(new_n247_));
  XOR2x2_ASAP7_75t_R   g161(.A(new_n247_), .B(new_n218_), .Y(new_n248_));
  AO21x1_ASAP7_75t_R   g162(.A1(p48), .A2(new_n231_), .B(new_n166_), .Y(new_n249_));
  AO22x1_ASAP7_75t_R   g163(.A1(p49), .A2(p26), .B1(p56), .B2(p41), .Y(new_n250_));
  AO21x1_ASAP7_75t_R   g164(.A1(p43), .A2(new_n231_), .B(new_n250_), .Y(new_n251_));
  AO21x1_ASAP7_75t_R   g165(.A1(p47), .A2(new_n247_), .B(new_n251_), .Y(new_n252_));
  AO21x1_ASAP7_75t_R   g166(.A1(p36), .A2(new_n249_), .B(new_n252_), .Y(new_n253_));
  AOI21x1_ASAP7_75t_R  g167(.A1(p50), .A2(new_n248_), .B(new_n253_), .Y(o20));
  INVx1_ASAP7_75t_R    g168(.A(p23), .Y(new_n255_));
  AO21x1_ASAP7_75t_R   g169(.A1(new_n156_), .A2(new_n157_), .B(new_n255_), .Y(new_n256_));
  AND3x1_ASAP7_75t_R   g170(.A(new_n175_), .B(p6), .C(new_n137_), .Y(new_n257_));
  AND2x2_ASAP7_75t_R   g171(.A(p16), .B(p53), .Y(new_n258_));
  AND2x2_ASAP7_75t_R   g172(.A(p6), .B(p57), .Y(new_n259_));
  AO31x2_ASAP7_75t_R   g173(.A1(new_n108_), .A2(new_n258_), .A3(new_n143_), .B(new_n259_), .Y(new_n260_));
  NOR3x1_ASAP7_75t_R   g174(.A(new_n257_), .B(p32), .C(new_n260_), .Y(new_n261_));
  AND2x2_ASAP7_75t_R   g175(.A(p45), .B(p16), .Y(new_n262_));
  AND2x2_ASAP7_75t_R   g176(.A(p58), .B(p57), .Y(new_n263_));
  AO31x2_ASAP7_75t_R   g177(.A1(new_n108_), .A2(new_n262_), .A3(new_n143_), .B(new_n263_), .Y(new_n264_));
  NOR3x1_ASAP7_75t_R   g178(.A(new_n257_), .B(p33), .C(new_n264_), .Y(new_n265_));
  INVx1_ASAP7_75t_R    g179(.A(p24), .Y(new_n266_));
  AO21x1_ASAP7_75t_R   g180(.A1(new_n156_), .A2(new_n157_), .B(new_n266_), .Y(new_n267_));
  AOI22x1_ASAP7_75t_R  g181(.A1(new_n256_), .A2(new_n261_), .B1(new_n265_), .B2(new_n267_), .Y(new_n268_));
  AND2x2_ASAP7_75t_R   g182(.A(p57), .B(p15), .Y(new_n269_));
  NOR3x1_ASAP7_75t_R   g183(.A(new_n257_), .B(p31), .C(new_n269_), .Y(new_n270_));
  INVx1_ASAP7_75t_R    g184(.A(p6), .Y(new_n271_));
  NAND2x1_ASAP7_75t_R  g185(.A(new_n271_), .B(new_n87_), .Y(new_n272_));
  AND2x2_ASAP7_75t_R   g186(.A(p11), .B(p46), .Y(new_n273_));
  NAND2x1_ASAP7_75t_R  g187(.A(p6), .B(p59), .Y(new_n274_));
  AND4x2_ASAP7_75t_R   g188(.A(new_n272_), .B(new_n108_), .C(new_n273_), .D(new_n274_), .Y(new_n275_));
  AND3x1_ASAP7_75t_R   g189(.A(new_n155_), .B(p22), .C(new_n154_), .Y(new_n276_));
  AND2x2_ASAP7_75t_R   g190(.A(p54), .B(p16), .Y(new_n277_));
  AND3x1_ASAP7_75t_R   g191(.A(new_n108_), .B(new_n277_), .C(new_n143_), .Y(new_n278_));
  AOI211x1_ASAP7_75t_R g192(.A1(p22), .A2(new_n275_), .B(new_n276_), .C(new_n278_), .Y(new_n279_));
  NAND2x1_ASAP7_75t_R  g193(.A(new_n270_), .B(new_n279_), .Y(new_n280_));
  NAND3x1_ASAP7_75t_R  g194(.A(new_n179_), .B(new_n268_), .C(new_n280_), .Y(new_n281_));
  AO31x2_ASAP7_75t_R   g195(.A1(new_n212_), .A2(new_n183_), .A3(new_n199_), .B(new_n281_), .Y(new_n282_));
  NOR3x1_ASAP7_75t_R   g196(.A(new_n88_), .B(p44), .C(new_n271_), .Y(new_n283_));
  NAND2x1_ASAP7_75t_R  g197(.A(new_n137_), .B(new_n283_), .Y(new_n284_));
  AND3x1_ASAP7_75t_R   g198(.A(new_n143_), .B(p16), .C(p52), .Y(new_n285_));
  AOI22x1_ASAP7_75t_R  g199(.A1(new_n285_), .A2(new_n108_), .B1(p8), .B2(p57), .Y(new_n286_));
  AND2x2_ASAP7_75t_R   g200(.A(new_n284_), .B(new_n286_), .Y(new_n287_));
  NAND2x1_ASAP7_75t_R  g201(.A(p21), .B(new_n174_), .Y(new_n288_));
  INVx1_ASAP7_75t_R    g202(.A(p30), .Y(new_n289_));
  AO21x1_ASAP7_75t_R   g203(.A1(new_n287_), .A2(new_n288_), .B(new_n289_), .Y(new_n290_));
  AOI22x1_ASAP7_75t_R  g204(.A1(new_n279_), .A2(new_n270_), .B1(new_n256_), .B2(new_n261_), .Y(new_n291_));
  INVx1_ASAP7_75t_R    g205(.A(new_n260_), .Y(new_n292_));
  NAND3x1_ASAP7_75t_R  g206(.A(new_n142_), .B(new_n144_), .C(p23), .Y(new_n293_));
  OR4x2_ASAP7_75t_R    g207(.A(new_n133_), .B(new_n255_), .C(new_n134_), .D(new_n135_), .Y(new_n294_));
  AND4x2_ASAP7_75t_R   g208(.A(new_n292_), .B(new_n293_), .C(new_n284_), .D(new_n294_), .Y(new_n295_));
  INVx1_ASAP7_75t_R    g209(.A(p32), .Y(new_n296_));
  AND3x1_ASAP7_75t_R   g210(.A(new_n143_), .B(p45), .C(p16), .Y(new_n297_));
  AOI21x1_ASAP7_75t_R  g211(.A1(new_n108_), .A2(new_n297_), .B(new_n263_), .Y(new_n298_));
  NAND3x1_ASAP7_75t_R  g212(.A(new_n142_), .B(new_n144_), .C(p24), .Y(new_n299_));
  OR4x2_ASAP7_75t_R    g213(.A(new_n133_), .B(new_n266_), .C(new_n134_), .D(new_n135_), .Y(new_n300_));
  AND4x2_ASAP7_75t_R   g214(.A(new_n298_), .B(new_n299_), .C(new_n284_), .D(new_n300_), .Y(new_n301_));
  INVx1_ASAP7_75t_R    g215(.A(p33), .Y(new_n302_));
  OAI22x1_ASAP7_75t_R  g216(.A1(new_n295_), .A2(new_n296_), .B1(new_n301_), .B2(new_n302_), .Y(new_n303_));
  AOI21x1_ASAP7_75t_R  g217(.A1(p22), .A2(new_n275_), .B(new_n276_), .Y(new_n304_));
  NOR3x1_ASAP7_75t_R   g218(.A(new_n257_), .B(new_n269_), .C(new_n278_), .Y(new_n305_));
  INVx1_ASAP7_75t_R    g219(.A(p31), .Y(new_n306_));
  AOI21x1_ASAP7_75t_R  g220(.A1(new_n304_), .A2(new_n305_), .B(new_n306_), .Y(new_n307_));
  AOI21x1_ASAP7_75t_R  g221(.A1(new_n291_), .A2(new_n303_), .B(new_n307_), .Y(new_n308_));
  AND2x2_ASAP7_75t_R   g222(.A(new_n290_), .B(new_n308_), .Y(new_n309_));
  AND3x1_ASAP7_75t_R   g223(.A(new_n288_), .B(new_n289_), .C(new_n287_), .Y(new_n310_));
  AO21x1_ASAP7_75t_R   g224(.A1(new_n282_), .A2(new_n309_), .B(new_n310_), .Y(o21));
  NAND2x1_ASAP7_75t_R  g225(.A(new_n267_), .B(new_n265_), .Y(new_n312_));
  NAND2x1_ASAP7_75t_R  g226(.A(new_n300_), .B(new_n299_), .Y(new_n313_));
  AO21x1_ASAP7_75t_R   g227(.A1(new_n137_), .A2(new_n283_), .B(new_n264_), .Y(new_n314_));
  OAI21x1_ASAP7_75t_R  g228(.A1(new_n313_), .A2(new_n314_), .B(p33), .Y(new_n315_));
  NAND2x1_ASAP7_75t_R  g229(.A(new_n312_), .B(new_n315_), .Y(new_n316_));
  AOI21x1_ASAP7_75t_R  g230(.A1(new_n180_), .A2(new_n181_), .B(new_n182_), .Y(new_n317_));
  AOI211x1_ASAP7_75t_R g231(.A1(p25), .A2(new_n174_), .B(new_n176_), .C(new_n178_), .Y(new_n318_));
  OAI22x1_ASAP7_75t_R  g232(.A1(new_n207_), .A2(new_n208_), .B1(new_n210_), .B2(new_n209_), .Y(new_n319_));
  AOI211x1_ASAP7_75t_R g233(.A1(new_n215_), .A2(new_n217_), .B(new_n318_), .C(new_n319_), .Y(new_n320_));
  AOI211x1_ASAP7_75t_R g234(.A1(new_n179_), .A2(new_n219_), .B(new_n317_), .C(new_n320_), .Y(new_n321_));
  NAND2x1_ASAP7_75t_R  g235(.A(new_n316_), .B(new_n321_), .Y(new_n322_));
  OA21x2_ASAP7_75t_R   g236(.A1(new_n316_), .A2(new_n321_), .B(p50), .Y(new_n323_));
  OR3x1_ASAP7_75t_R    g237(.A(new_n301_), .B(new_n224_), .C(new_n302_), .Y(new_n324_));
  AOI22x1_ASAP7_75t_R  g238(.A1(new_n166_), .A2(p33), .B1(p23), .B2(p49), .Y(new_n325_));
  OA21x2_ASAP7_75t_R   g239(.A1(new_n225_), .A2(new_n301_), .B(new_n325_), .Y(new_n326_));
  OA21x2_ASAP7_75t_R   g240(.A1(new_n222_), .A2(new_n316_), .B(new_n326_), .Y(new_n327_));
  NAND2x1_ASAP7_75t_R  g241(.A(new_n324_), .B(new_n327_), .Y(new_n328_));
  AOI21x1_ASAP7_75t_R  g242(.A1(new_n322_), .A2(new_n323_), .B(new_n328_), .Y(o22));
  NAND2x1_ASAP7_75t_R  g243(.A(new_n280_), .B(new_n268_), .Y(new_n330_));
  NAND3x1_ASAP7_75t_R  g244(.A(new_n288_), .B(new_n287_), .C(new_n289_), .Y(new_n331_));
  NAND2x1_ASAP7_75t_R  g245(.A(new_n331_), .B(new_n290_), .Y(new_n332_));
  OR3x1_ASAP7_75t_R    g246(.A(new_n321_), .B(new_n330_), .C(new_n332_), .Y(new_n333_));
  AOI21x1_ASAP7_75t_R  g247(.A1(new_n287_), .A2(new_n288_), .B(new_n289_), .Y(new_n334_));
  INVx1_ASAP7_75t_R    g248(.A(new_n307_), .Y(new_n335_));
  OAI21x1_ASAP7_75t_R  g249(.A1(new_n334_), .A2(new_n310_), .B(new_n335_), .Y(new_n336_));
  AOI21x1_ASAP7_75t_R  g250(.A1(new_n291_), .A2(new_n303_), .B(new_n336_), .Y(new_n337_));
  OAI21x1_ASAP7_75t_R  g251(.A1(new_n332_), .A2(new_n308_), .B(p50), .Y(new_n338_));
  AOI21x1_ASAP7_75t_R  g252(.A1(new_n337_), .A2(new_n282_), .B(new_n338_), .Y(new_n339_));
  AND3x1_ASAP7_75t_R   g253(.A(new_n290_), .B(p47), .C(new_n331_), .Y(new_n340_));
  NAND2x1_ASAP7_75t_R  g254(.A(new_n287_), .B(new_n288_), .Y(new_n341_));
  AND3x1_ASAP7_75t_R   g255(.A(new_n341_), .B(p30), .C(p48), .Y(new_n342_));
  AO22x1_ASAP7_75t_R   g256(.A1(p44), .A2(p49), .B1(p30), .B2(new_n166_), .Y(new_n343_));
  AO21x1_ASAP7_75t_R   g257(.A1(p43), .A2(new_n341_), .B(new_n343_), .Y(new_n344_));
  OR3x1_ASAP7_75t_R    g258(.A(new_n340_), .B(new_n342_), .C(new_n344_), .Y(new_n345_));
  AOI21x1_ASAP7_75t_R  g259(.A1(new_n333_), .A2(new_n339_), .B(new_n345_), .Y(o23));
  INVx1_ASAP7_75t_R    g260(.A(new_n268_), .Y(new_n347_));
  NAND2x1_ASAP7_75t_R  g261(.A(new_n294_), .B(new_n293_), .Y(new_n348_));
  AO21x1_ASAP7_75t_R   g262(.A1(new_n137_), .A2(new_n283_), .B(new_n260_), .Y(new_n349_));
  OAI21x1_ASAP7_75t_R  g263(.A1(new_n348_), .A2(new_n349_), .B(p32), .Y(new_n350_));
  NOR3x1_ASAP7_75t_R   g264(.A(new_n349_), .B(new_n348_), .C(p32), .Y(new_n351_));
  AOI21x1_ASAP7_75t_R  g265(.A1(new_n350_), .A2(new_n315_), .B(new_n351_), .Y(new_n352_));
  AOI21x1_ASAP7_75t_R  g266(.A1(new_n279_), .A2(new_n270_), .B(new_n307_), .Y(new_n353_));
  NOR2x1_ASAP7_75t_R   g267(.A(new_n352_), .B(new_n353_), .Y(new_n354_));
  OAI21x1_ASAP7_75t_R  g268(.A1(new_n347_), .A2(new_n321_), .B(new_n354_), .Y(new_n355_));
  INVx1_ASAP7_75t_R    g269(.A(new_n353_), .Y(new_n356_));
  AOI21x1_ASAP7_75t_R  g270(.A1(new_n352_), .A2(new_n353_), .B(new_n173_), .Y(new_n357_));
  OA31x2_ASAP7_75t_R   g271(.A1(new_n347_), .A2(new_n356_), .A3(new_n321_), .B1(new_n357_), .Y(new_n358_));
  AO21x1_ASAP7_75t_R   g272(.A1(new_n304_), .A2(new_n305_), .B(new_n225_), .Y(new_n359_));
  AOI22x1_ASAP7_75t_R  g273(.A1(new_n166_), .A2(p31), .B1(p49), .B2(p21), .Y(new_n360_));
  OA211x2_ASAP7_75t_R  g274(.A1(new_n224_), .A2(new_n335_), .B(new_n359_), .C(new_n360_), .Y(new_n361_));
  OAI21x1_ASAP7_75t_R  g275(.A1(new_n222_), .A2(new_n356_), .B(new_n361_), .Y(new_n362_));
  AOI21x1_ASAP7_75t_R  g276(.A1(new_n355_), .A2(new_n358_), .B(new_n362_), .Y(o24));
  NAND2x1_ASAP7_75t_R  g277(.A(new_n256_), .B(new_n261_), .Y(new_n364_));
  NAND2x1_ASAP7_75t_R  g278(.A(new_n364_), .B(new_n350_), .Y(new_n365_));
  AO21x1_ASAP7_75t_R   g279(.A1(new_n267_), .A2(new_n265_), .B(new_n365_), .Y(new_n366_));
  AO21x1_ASAP7_75t_R   g280(.A1(new_n315_), .A2(new_n321_), .B(new_n366_), .Y(new_n367_));
  AND2x2_ASAP7_75t_R   g281(.A(new_n315_), .B(new_n365_), .Y(new_n368_));
  NAND2x1_ASAP7_75t_R  g282(.A(new_n312_), .B(new_n179_), .Y(new_n369_));
  AO31x2_ASAP7_75t_R   g283(.A1(new_n212_), .A2(new_n183_), .A3(new_n199_), .B(new_n369_), .Y(new_n370_));
  AOI21x1_ASAP7_75t_R  g284(.A1(new_n368_), .A2(new_n370_), .B(new_n173_), .Y(new_n371_));
  AOI22x1_ASAP7_75t_R  g285(.A1(new_n166_), .A2(p32), .B1(p49), .B2(p22), .Y(new_n372_));
  OA21x2_ASAP7_75t_R   g286(.A1(new_n225_), .A2(new_n295_), .B(new_n372_), .Y(new_n373_));
  OA21x2_ASAP7_75t_R   g287(.A1(new_n224_), .A2(new_n350_), .B(new_n373_), .Y(new_n374_));
  OAI21x1_ASAP7_75t_R  g288(.A1(new_n222_), .A2(new_n365_), .B(new_n374_), .Y(new_n375_));
  AOI21x1_ASAP7_75t_R  g289(.A1(new_n367_), .A2(new_n371_), .B(new_n375_), .Y(o25));
endmodule


