// Benchmark "/tmp/" written by ABC on Mon Oct 12 15:07:58 2026

module \/tmp/  ( 
    p32, p1, p20, p26, p27, p10, p53, p58, p33, p34, p4, p56, p38, p50,
    p46, p6, p40, p43, p49, p59, p52, p47, p54, p14, p31, p29, p39, p15,
    p44, p36, p11, p8, p28, p17, p55, p48, p57, p22, p16, p41, p45, p30,
    p19, p2, p0, p3, p24, p23, p18, p21, p37, p35, p12, p5, p51, p7, p9,
    p42, p25, p13,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25  );
  input  p32, p1, p20, p26, p27, p10, p53, p58, p33, p34, p4, p56, p38,
    p50, p46, p6, p40, p43, p49, p59, p52, p47, p54, p14, p31, p29, p39,
    p15, p44, p36, p11, p8, p28, p17, p55, p48, p57, p22, p16, p41, p45,
    p30, p19, p2, p0, p3, p24, p23, p18, p21, p37, p35, p12, p5, p51, p7,
    p9, p42, p25, p13;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25;
  wire new_n87_, new_n88_, new_n90_, new_n91_, new_n92_, new_n94_, new_n97_,
    new_n98_, new_n99_, new_n101_, new_n102_, new_n109_, new_n111_,
    new_n113_, new_n116_, new_n117_, new_n118_, new_n119_, new_n120_,
    new_n121_, new_n122_, new_n123_, new_n125_, new_n126_, new_n127_,
    new_n128_, new_n129_, new_n130_, new_n131_, new_n132_, new_n133_,
    new_n134_, new_n136_, new_n137_, new_n138_, new_n139_, new_n140_,
    new_n141_, new_n142_, new_n143_, new_n144_, new_n145_, new_n146_,
    new_n147_, new_n148_, new_n149_, new_n150_, new_n151_, new_n152_,
    new_n153_, new_n154_, new_n155_, new_n156_, new_n157_, new_n158_,
    new_n159_, new_n160_, new_n161_, new_n162_, new_n163_, new_n164_,
    new_n165_, new_n166_, new_n167_, new_n168_, new_n169_, new_n170_,
    new_n171_, new_n172_, new_n173_, new_n174_, new_n175_, new_n177_,
    new_n178_, new_n179_, new_n180_, new_n181_, new_n182_, new_n183_,
    new_n184_, new_n185_, new_n186_, new_n187_, new_n188_, new_n189_,
    new_n190_, new_n191_, new_n192_, new_n193_, new_n194_, new_n195_,
    new_n196_, new_n197_, new_n198_, new_n199_, new_n200_, new_n201_,
    new_n202_, new_n203_, new_n204_, new_n205_, new_n206_, new_n207_,
    new_n208_, new_n209_, new_n210_, new_n211_, new_n212_, new_n213_,
    new_n214_, new_n215_, new_n216_, new_n217_, new_n218_, new_n219_,
    new_n220_, new_n221_, new_n222_, new_n223_, new_n224_, new_n225_,
    new_n226_, new_n227_, new_n228_, new_n229_, new_n230_, new_n231_,
    new_n232_, new_n234_, new_n235_, new_n236_, new_n237_, new_n238_,
    new_n239_, new_n240_, new_n241_, new_n242_, new_n243_, new_n244_,
    new_n245_, new_n246_, new_n247_, new_n248_, new_n249_, new_n251_,
    new_n252_, new_n253_, new_n254_, new_n255_, new_n256_, new_n257_,
    new_n259_, new_n260_, new_n261_, new_n262_, new_n263_, new_n264_,
    new_n265_, new_n266_, new_n267_, new_n268_, new_n269_, new_n270_,
    new_n271_, new_n272_, new_n273_, new_n274_, new_n275_, new_n276_,
    new_n277_, new_n278_, new_n279_, new_n280_, new_n281_, new_n282_,
    new_n283_, new_n284_, new_n285_, new_n286_, new_n287_, new_n288_,
    new_n289_, new_n290_, new_n291_, new_n292_, new_n293_, new_n294_,
    new_n295_, new_n296_, new_n297_, new_n298_, new_n299_, new_n300_,
    new_n301_, new_n302_, new_n303_, new_n304_, new_n305_, new_n306_,
    new_n307_, new_n308_, new_n309_, new_n310_, new_n311_, new_n312_,
    new_n313_, new_n314_, new_n315_, new_n316_, new_n317_, new_n318_,
    new_n320_, new_n321_, new_n322_, new_n323_, new_n324_, new_n325_,
    new_n326_, new_n327_, new_n328_, new_n329_, new_n330_, new_n331_,
    new_n332_, new_n333_, new_n334_, new_n335_, new_n336_, new_n338_,
    new_n339_, new_n340_, new_n341_, new_n342_, new_n343_, new_n344_,
    new_n345_, new_n346_, new_n347_, new_n348_, new_n349_, new_n351_,
    new_n352_, new_n353_, new_n354_, new_n355_, new_n356_, new_n357_,
    new_n358_, new_n359_, new_n360_, new_n361_, new_n362_, new_n363_,
    new_n364_, new_n365_, new_n366_, new_n367_, new_n369_, new_n370_,
    new_n371_, new_n372_, new_n373_, new_n374_, new_n375_, new_n376_,
    new_n377_, new_n378_, new_n379_, new_n380_;
  INVx1_ASAP7_75t_R    g000(.A(p59), .Y(new_n87_));
  NAND2x1_ASAP7_75t_R  g001(.A(p1), .B(p0), .Y(new_n88_));
  OR2x4_ASAP7_75t_R    g002(.A(new_n87_), .B(new_n88_), .Y(o0));
  INVx1_ASAP7_75t_R    g003(.A(p1), .Y(new_n90_));
  INVx1_ASAP7_75t_R    g004(.A(p2), .Y(new_n91_));
  INVx1_ASAP7_75t_R    g005(.A(p3), .Y(new_n92_));
  OR3x1_ASAP7_75t_R    g006(.A(new_n90_), .B(new_n91_), .C(new_n92_), .Y(o1));
  AND3x1_ASAP7_75t_R   g007(.A(p1), .B(p59), .C(p3), .Y(new_n94_));
  INVx1_ASAP7_75t_R    g008(.A(new_n94_), .Y(o2));
  NAND2x1_ASAP7_75t_R  g009(.A(p4), .B(p5), .Y(o3));
  AND2x2_ASAP7_75t_R   g010(.A(p6), .B(p7), .Y(new_n97_));
  NAND2x1_ASAP7_75t_R  g011(.A(p8), .B(p9), .Y(new_n98_));
  INVx1_ASAP7_75t_R    g012(.A(new_n98_), .Y(new_n99_));
  NAND2x1_ASAP7_75t_R  g013(.A(new_n97_), .B(new_n99_), .Y(o4));
  NAND2x1_ASAP7_75t_R  g014(.A(p10), .B(p9), .Y(new_n101_));
  INVx1_ASAP7_75t_R    g015(.A(new_n101_), .Y(new_n102_));
  AND3x1_ASAP7_75t_R   g016(.A(o2), .B(new_n97_), .C(new_n102_), .Y(o5));
  AND3x1_ASAP7_75t_R   g017(.A(p11), .B(p2), .C(p0), .Y(o6));
  AND3x1_ASAP7_75t_R   g018(.A(p11), .B(p2), .C(p3), .Y(o7));
  AND3x1_ASAP7_75t_R   g019(.A(p59), .B(p11), .C(p3), .Y(o8));
  OAI21x1_ASAP7_75t_R  g020(.A1(p14), .A2(p13), .B(p12), .Y(o9));
  AND3x1_ASAP7_75t_R   g021(.A(new_n102_), .B(new_n94_), .C(new_n97_), .Y(o10));
  AND3x1_ASAP7_75t_R   g022(.A(p10), .B(p15), .C(p9), .Y(new_n109_));
  INVx1_ASAP7_75t_R    g023(.A(new_n109_), .Y(o11));
  AND3x1_ASAP7_75t_R   g024(.A(new_n99_), .B(p16), .C(p7), .Y(new_n111_));
  NAND3x1_ASAP7_75t_R  g025(.A(new_n111_), .B(p1), .C(p17), .Y(o12));
  AND3x1_ASAP7_75t_R   g026(.A(new_n111_), .B(p11), .C(p17), .Y(new_n113_));
  NAND2x1_ASAP7_75t_R  g027(.A(p18), .B(new_n113_), .Y(o13));
  OAI21x1_ASAP7_75t_R  g028(.A1(p14), .A2(p13), .B(p19), .Y(o14));
  XNOR2x2_ASAP7_75t_R  g029(.A(p24), .B(p23), .Y(new_n116_));
  XOR2x2_ASAP7_75t_R   g030(.A(p27), .B(p28), .Y(new_n117_));
  XOR2x2_ASAP7_75t_R   g031(.A(new_n116_), .B(new_n117_), .Y(new_n118_));
  XOR2x2_ASAP7_75t_R   g032(.A(p29), .B(p25), .Y(new_n119_));
  XOR2x2_ASAP7_75t_R   g033(.A(new_n119_), .B(p26), .Y(new_n120_));
  XOR2x2_ASAP7_75t_R   g034(.A(new_n118_), .B(new_n120_), .Y(new_n121_));
  XOR2x2_ASAP7_75t_R   g035(.A(p22), .B(p21), .Y(new_n122_));
  XOR2x2_ASAP7_75t_R   g036(.A(new_n122_), .B(p20), .Y(new_n123_));
  XOR2x2_ASAP7_75t_R   g037(.A(new_n121_), .B(new_n123_), .Y(o15));
  XNOR2x2_ASAP7_75t_R  g038(.A(p32), .B(p33), .Y(new_n125_));
  XOR2x2_ASAP7_75t_R   g039(.A(p36), .B(p37), .Y(new_n126_));
  XOR2x2_ASAP7_75t_R   g040(.A(new_n125_), .B(new_n126_), .Y(new_n127_));
  XOR2x2_ASAP7_75t_R   g041(.A(p38), .B(p35), .Y(new_n128_));
  INVx1_ASAP7_75t_R    g042(.A(p34), .Y(new_n129_));
  XOR2x2_ASAP7_75t_R   g043(.A(new_n128_), .B(new_n129_), .Y(new_n130_));
  XOR2x2_ASAP7_75t_R   g044(.A(new_n127_), .B(new_n130_), .Y(new_n131_));
  XOR2x2_ASAP7_75t_R   g045(.A(p20), .B(p31), .Y(new_n132_));
  INVx1_ASAP7_75t_R    g046(.A(p30), .Y(new_n133_));
  XOR2x2_ASAP7_75t_R   g047(.A(new_n132_), .B(new_n133_), .Y(new_n134_));
  XOR2x2_ASAP7_75t_R   g048(.A(new_n131_), .B(new_n134_), .Y(o16));
  AND3x1_ASAP7_75t_R   g049(.A(p59), .B(p11), .C(p0), .Y(new_n136_));
  NAND2x1_ASAP7_75t_R  g050(.A(p6), .B(p15), .Y(new_n137_));
  NOR3x1_ASAP7_75t_R   g051(.A(new_n136_), .B(new_n98_), .C(new_n137_), .Y(new_n138_));
  AND4x2_ASAP7_75t_R   g052(.A(p10), .B(p15), .C(p2), .D(p9), .Y(new_n139_));
  INVx1_ASAP7_75t_R    g053(.A(p16), .Y(new_n140_));
  NOR3x1_ASAP7_75t_R   g054(.A(new_n88_), .B(p44), .C(new_n140_), .Y(new_n141_));
  AOI22x1_ASAP7_75t_R  g055(.A1(new_n138_), .A2(p28), .B1(new_n139_), .B2(new_n141_), .Y(new_n142_));
  OAI21x1_ASAP7_75t_R  g056(.A1(p6), .A2(p59), .B(p15), .Y(new_n143_));
  NOR2x1_ASAP7_75t_R   g057(.A(new_n101_), .B(new_n143_), .Y(new_n144_));
  NAND2x1_ASAP7_75t_R  g058(.A(p46), .B(p11), .Y(new_n145_));
  AOI21x1_ASAP7_75t_R  g059(.A1(p6), .A2(p59), .B(new_n145_), .Y(new_n146_));
  NAND3x1_ASAP7_75t_R  g060(.A(new_n144_), .B(new_n146_), .C(p28), .Y(new_n147_));
  AOI211x1_ASAP7_75t_R g061(.A1(p46), .A2(p11), .B(new_n101_), .C(new_n137_), .Y(new_n148_));
  INVx1_ASAP7_75t_R    g062(.A(p9), .Y(new_n149_));
  AO21x1_ASAP7_75t_R   g063(.A1(p45), .A2(new_n149_), .B(p37), .Y(new_n150_));
  AOI21x1_ASAP7_75t_R  g064(.A1(p45), .A2(new_n148_), .B(new_n150_), .Y(new_n151_));
  AND3x1_ASAP7_75t_R   g065(.A(new_n142_), .B(new_n147_), .C(new_n151_), .Y(new_n152_));
  AO31x2_ASAP7_75t_R   g066(.A1(new_n145_), .A2(p10), .A3(p15), .B(new_n149_), .Y(new_n153_));
  OA21x2_ASAP7_75t_R   g067(.A1(p6), .A2(new_n149_), .B(p45), .Y(new_n154_));
  AOI22x1_ASAP7_75t_R  g068(.A1(new_n153_), .A2(new_n154_), .B1(new_n139_), .B2(new_n141_), .Y(new_n155_));
  NAND3x1_ASAP7_75t_R  g069(.A(p59), .B(p11), .C(p0), .Y(new_n156_));
  AND4x2_ASAP7_75t_R   g070(.A(p6), .B(p15), .C(p8), .D(p9), .Y(new_n157_));
  NAND2x1_ASAP7_75t_R  g071(.A(new_n156_), .B(new_n157_), .Y(new_n158_));
  NAND2x1_ASAP7_75t_R  g072(.A(new_n146_), .B(new_n144_), .Y(new_n159_));
  INVx1_ASAP7_75t_R    g073(.A(p28), .Y(new_n160_));
  AO21x1_ASAP7_75t_R   g074(.A1(new_n158_), .A2(new_n159_), .B(new_n160_), .Y(new_n161_));
  INVx1_ASAP7_75t_R    g075(.A(p37), .Y(new_n162_));
  AOI21x1_ASAP7_75t_R  g076(.A1(new_n155_), .A2(new_n161_), .B(new_n162_), .Y(new_n163_));
  NOR2x1_ASAP7_75t_R   g077(.A(new_n152_), .B(new_n163_), .Y(new_n164_));
  XOR2x2_ASAP7_75t_R   g078(.A(new_n164_), .B(p51), .Y(new_n165_));
  AND2x2_ASAP7_75t_R   g079(.A(p47), .B(new_n164_), .Y(new_n166_));
  AND3x1_ASAP7_75t_R   g080(.A(p40), .B(p59), .C(p39), .Y(new_n167_));
  AND2x2_ASAP7_75t_R   g081(.A(new_n167_), .B(new_n113_), .Y(new_n168_));
  AO22x1_ASAP7_75t_R   g082(.A1(p27), .A2(p49), .B1(p41), .B2(p42), .Y(new_n169_));
  AO21x1_ASAP7_75t_R   g083(.A1(p37), .A2(new_n168_), .B(new_n169_), .Y(new_n170_));
  INVx1_ASAP7_75t_R    g084(.A(p48), .Y(new_n171_));
  INVx1_ASAP7_75t_R    g085(.A(p43), .Y(new_n172_));
  OA21x2_ASAP7_75t_R   g086(.A1(new_n171_), .A2(new_n162_), .B(new_n172_), .Y(new_n173_));
  AOI21x1_ASAP7_75t_R  g087(.A1(new_n155_), .A2(new_n161_), .B(new_n173_), .Y(new_n174_));
  OR3x1_ASAP7_75t_R    g088(.A(new_n166_), .B(new_n170_), .C(new_n174_), .Y(new_n175_));
  AOI21x1_ASAP7_75t_R  g089(.A1(p50), .A2(new_n165_), .B(new_n175_), .Y(o17));
  INVx1_ASAP7_75t_R    g090(.A(p50), .Y(new_n177_));
  AO21x1_ASAP7_75t_R   g091(.A1(new_n146_), .A2(new_n144_), .B(new_n138_), .Y(new_n178_));
  NOR2x1_ASAP7_75t_R   g092(.A(p44), .B(new_n88_), .Y(new_n179_));
  AND3x1_ASAP7_75t_R   g093(.A(new_n179_), .B(p16), .C(new_n139_), .Y(new_n180_));
  INVx1_ASAP7_75t_R    g094(.A(p52), .Y(new_n181_));
  NOR2x1_ASAP7_75t_R   g095(.A(p6), .B(new_n149_), .Y(new_n182_));
  NOR2x1_ASAP7_75t_R   g096(.A(new_n181_), .B(new_n182_), .Y(new_n183_));
  AO21x1_ASAP7_75t_R   g097(.A1(new_n153_), .A2(new_n183_), .B(p34), .Y(new_n184_));
  AO211x2_ASAP7_75t_R  g098(.A1(new_n178_), .A2(p25), .B(new_n180_), .C(new_n184_), .Y(new_n185_));
  AOI21x1_ASAP7_75t_R  g099(.A1(new_n153_), .A2(new_n183_), .B(new_n180_), .Y(new_n186_));
  NAND2x1_ASAP7_75t_R  g100(.A(p25), .B(new_n178_), .Y(new_n187_));
  AO21x1_ASAP7_75t_R   g101(.A1(new_n186_), .A2(new_n187_), .B(new_n129_), .Y(new_n188_));
  NAND2x1_ASAP7_75t_R  g102(.A(new_n185_), .B(new_n188_), .Y(new_n189_));
  OA21x2_ASAP7_75t_R   g103(.A1(p6), .A2(new_n149_), .B(p53), .Y(new_n190_));
  AOI22x1_ASAP7_75t_R  g104(.A1(new_n153_), .A2(new_n190_), .B1(new_n139_), .B2(new_n141_), .Y(new_n191_));
  NAND3x1_ASAP7_75t_R  g105(.A(new_n144_), .B(new_n146_), .C(p27), .Y(new_n192_));
  NAND3x1_ASAP7_75t_R  g106(.A(new_n157_), .B(p27), .C(new_n156_), .Y(new_n193_));
  INVx1_ASAP7_75t_R    g107(.A(p36), .Y(new_n194_));
  AO31x2_ASAP7_75t_R   g108(.A1(new_n191_), .A2(new_n192_), .A3(new_n193_), .B(new_n194_), .Y(new_n195_));
  AOI22x1_ASAP7_75t_R  g109(.A1(new_n138_), .A2(p26), .B1(new_n139_), .B2(new_n141_), .Y(new_n196_));
  NAND3x1_ASAP7_75t_R  g110(.A(new_n144_), .B(new_n146_), .C(p26), .Y(new_n197_));
  OA21x2_ASAP7_75t_R   g111(.A1(p6), .A2(new_n149_), .B(p54), .Y(new_n198_));
  AOI21x1_ASAP7_75t_R  g112(.A1(new_n198_), .A2(new_n153_), .B(p35), .Y(new_n199_));
  AND3x1_ASAP7_75t_R   g113(.A(new_n196_), .B(new_n197_), .C(new_n199_), .Y(new_n200_));
  INVx1_ASAP7_75t_R    g114(.A(p35), .Y(new_n201_));
  NAND2x1_ASAP7_75t_R  g115(.A(new_n198_), .B(new_n153_), .Y(new_n202_));
  AND3x1_ASAP7_75t_R   g116(.A(new_n196_), .B(new_n197_), .C(new_n202_), .Y(new_n203_));
  OA22x2_ASAP7_75t_R   g117(.A1(new_n195_), .A2(new_n200_), .B1(new_n201_), .B2(new_n203_), .Y(new_n204_));
  AO21x1_ASAP7_75t_R   g118(.A1(p45), .A2(new_n148_), .B(new_n150_), .Y(new_n205_));
  INVx1_ASAP7_75t_R    g119(.A(new_n147_), .Y(new_n206_));
  NAND2x1_ASAP7_75t_R  g120(.A(new_n139_), .B(new_n141_), .Y(new_n207_));
  OAI21x1_ASAP7_75t_R  g121(.A1(new_n160_), .A2(new_n158_), .B(new_n207_), .Y(new_n208_));
  OA31x2_ASAP7_75t_R   g122(.A1(new_n205_), .A2(new_n206_), .A3(new_n208_), .B1(p51), .Y(new_n209_));
  INVx1_ASAP7_75t_R    g123(.A(p26), .Y(new_n210_));
  OR4x2_ASAP7_75t_R    g124(.A(new_n136_), .B(new_n210_), .C(new_n98_), .D(new_n137_), .Y(new_n211_));
  NAND3x1_ASAP7_75t_R  g125(.A(new_n197_), .B(new_n211_), .C(new_n207_), .Y(new_n212_));
  INVx1_ASAP7_75t_R    g126(.A(new_n199_), .Y(new_n213_));
  AO21x1_ASAP7_75t_R   g127(.A1(new_n190_), .A2(new_n153_), .B(p36), .Y(new_n214_));
  NAND3x1_ASAP7_75t_R  g128(.A(new_n192_), .B(new_n207_), .C(new_n193_), .Y(new_n215_));
  OA22x2_ASAP7_75t_R   g129(.A1(new_n212_), .A2(new_n213_), .B1(new_n214_), .B2(new_n215_), .Y(new_n216_));
  OAI21x1_ASAP7_75t_R  g130(.A1(new_n163_), .A2(new_n209_), .B(new_n216_), .Y(new_n217_));
  AND3x1_ASAP7_75t_R   g131(.A(new_n189_), .B(new_n204_), .C(new_n217_), .Y(new_n218_));
  NAND2x1_ASAP7_75t_R  g132(.A(p28), .B(new_n138_), .Y(new_n219_));
  AO31x2_ASAP7_75t_R   g133(.A1(new_n155_), .A2(new_n147_), .A3(new_n219_), .B(new_n162_), .Y(new_n220_));
  INVx1_ASAP7_75t_R    g134(.A(p51), .Y(new_n221_));
  AO31x2_ASAP7_75t_R   g135(.A1(new_n142_), .A2(new_n147_), .A3(new_n151_), .B(new_n221_), .Y(new_n222_));
  NAND2x1_ASAP7_75t_R  g136(.A(new_n220_), .B(new_n222_), .Y(new_n223_));
  OAI22x1_ASAP7_75t_R  g137(.A1(new_n195_), .A2(new_n200_), .B1(new_n203_), .B2(new_n201_), .Y(new_n224_));
  AO21x1_ASAP7_75t_R   g138(.A1(new_n223_), .A2(new_n216_), .B(new_n224_), .Y(new_n225_));
  AND3x1_ASAP7_75t_R   g139(.A(new_n225_), .B(new_n188_), .C(new_n185_), .Y(new_n226_));
  INVx1_ASAP7_75t_R    g140(.A(p47), .Y(new_n227_));
  AOI22x1_ASAP7_75t_R  g141(.A1(new_n168_), .A2(p34), .B1(p49), .B2(p24), .Y(new_n228_));
  AO21x1_ASAP7_75t_R   g142(.A1(p34), .A2(p48), .B(p43), .Y(new_n229_));
  NAND2x1_ASAP7_75t_R  g143(.A(new_n186_), .B(new_n187_), .Y(new_n230_));
  NAND2x1_ASAP7_75t_R  g144(.A(new_n229_), .B(new_n230_), .Y(new_n231_));
  OA211x2_ASAP7_75t_R  g145(.A1(new_n227_), .A2(new_n189_), .B(new_n228_), .C(new_n231_), .Y(new_n232_));
  OA31x2_ASAP7_75t_R   g146(.A1(new_n177_), .A2(new_n218_), .A3(new_n226_), .B1(new_n232_), .Y(o18));
  AND2x2_ASAP7_75t_R   g147(.A(new_n193_), .B(new_n192_), .Y(new_n234_));
  NAND2x1_ASAP7_75t_R  g148(.A(new_n191_), .B(new_n234_), .Y(new_n235_));
  OA21x2_ASAP7_75t_R   g149(.A1(p36), .A2(new_n235_), .B(new_n223_), .Y(new_n236_));
  AOI21x1_ASAP7_75t_R  g150(.A1(new_n191_), .A2(new_n234_), .B(new_n194_), .Y(new_n237_));
  AND3x1_ASAP7_75t_R   g151(.A(new_n197_), .B(new_n211_), .C(new_n207_), .Y(new_n238_));
  AOI21x1_ASAP7_75t_R  g152(.A1(new_n202_), .A2(new_n238_), .B(new_n201_), .Y(new_n239_));
  NOR2x1_ASAP7_75t_R   g153(.A(new_n200_), .B(new_n239_), .Y(new_n240_));
  OR3x1_ASAP7_75t_R    g154(.A(new_n236_), .B(new_n237_), .C(new_n240_), .Y(new_n241_));
  AO21x1_ASAP7_75t_R   g155(.A1(new_n237_), .A2(new_n240_), .B(new_n177_), .Y(new_n242_));
  AOI21x1_ASAP7_75t_R  g156(.A1(new_n240_), .A2(new_n236_), .B(new_n242_), .Y(new_n243_));
  OR3x1_ASAP7_75t_R    g157(.A(new_n239_), .B(new_n227_), .C(new_n200_), .Y(new_n244_));
  OA21x2_ASAP7_75t_R   g158(.A1(new_n171_), .A2(new_n201_), .B(new_n172_), .Y(new_n245_));
  AO22x1_ASAP7_75t_R   g159(.A1(p49), .A2(p25), .B1(p55), .B2(p41), .Y(new_n246_));
  AOI21x1_ASAP7_75t_R  g160(.A1(p35), .A2(new_n168_), .B(new_n246_), .Y(new_n247_));
  OA21x2_ASAP7_75t_R   g161(.A1(new_n203_), .A2(new_n245_), .B(new_n247_), .Y(new_n248_));
  NAND2x1_ASAP7_75t_R  g162(.A(new_n244_), .B(new_n248_), .Y(new_n249_));
  AOI21x1_ASAP7_75t_R  g163(.A1(new_n241_), .A2(new_n243_), .B(new_n249_), .Y(o19));
  OA21x2_ASAP7_75t_R   g164(.A1(new_n215_), .A2(new_n214_), .B(new_n195_), .Y(new_n251_));
  XOR2x2_ASAP7_75t_R   g165(.A(new_n251_), .B(new_n223_), .Y(new_n252_));
  AO21x1_ASAP7_75t_R   g166(.A1(p48), .A2(new_n235_), .B(new_n168_), .Y(new_n253_));
  AO22x1_ASAP7_75t_R   g167(.A1(p26), .A2(p49), .B1(p56), .B2(p41), .Y(new_n254_));
  AO21x1_ASAP7_75t_R   g168(.A1(p43), .A2(new_n235_), .B(new_n254_), .Y(new_n255_));
  AO21x1_ASAP7_75t_R   g169(.A1(p47), .A2(new_n251_), .B(new_n255_), .Y(new_n256_));
  AO21x1_ASAP7_75t_R   g170(.A1(p36), .A2(new_n253_), .B(new_n256_), .Y(new_n257_));
  AOI21x1_ASAP7_75t_R  g171(.A1(p50), .A2(new_n252_), .B(new_n257_), .Y(o20));
  INVx1_ASAP7_75t_R    g172(.A(p23), .Y(new_n259_));
  AO21x1_ASAP7_75t_R   g173(.A1(new_n158_), .A2(new_n159_), .B(new_n259_), .Y(new_n260_));
  AND3x1_ASAP7_75t_R   g174(.A(new_n179_), .B(p6), .C(new_n139_), .Y(new_n261_));
  AND2x2_ASAP7_75t_R   g175(.A(p53), .B(p16), .Y(new_n262_));
  AND2x2_ASAP7_75t_R   g176(.A(p6), .B(p57), .Y(new_n263_));
  AO31x2_ASAP7_75t_R   g177(.A1(new_n109_), .A2(new_n262_), .A3(new_n145_), .B(new_n263_), .Y(new_n264_));
  NOR3x1_ASAP7_75t_R   g178(.A(new_n261_), .B(p32), .C(new_n264_), .Y(new_n265_));
  AND2x2_ASAP7_75t_R   g179(.A(p16), .B(p45), .Y(new_n266_));
  AND2x2_ASAP7_75t_R   g180(.A(p58), .B(p57), .Y(new_n267_));
  AO31x2_ASAP7_75t_R   g181(.A1(new_n109_), .A2(new_n266_), .A3(new_n145_), .B(new_n267_), .Y(new_n268_));
  NOR3x1_ASAP7_75t_R   g182(.A(new_n261_), .B(p33), .C(new_n268_), .Y(new_n269_));
  INVx1_ASAP7_75t_R    g183(.A(p24), .Y(new_n270_));
  AO21x1_ASAP7_75t_R   g184(.A1(new_n158_), .A2(new_n159_), .B(new_n270_), .Y(new_n271_));
  AOI22x1_ASAP7_75t_R  g185(.A1(new_n260_), .A2(new_n265_), .B1(new_n269_), .B2(new_n271_), .Y(new_n272_));
  AND2x2_ASAP7_75t_R   g186(.A(p15), .B(p57), .Y(new_n273_));
  NOR3x1_ASAP7_75t_R   g187(.A(new_n261_), .B(p31), .C(new_n273_), .Y(new_n274_));
  INVx1_ASAP7_75t_R    g188(.A(p6), .Y(new_n275_));
  NAND2x1_ASAP7_75t_R  g189(.A(new_n275_), .B(new_n87_), .Y(new_n276_));
  AND2x2_ASAP7_75t_R   g190(.A(p46), .B(p11), .Y(new_n277_));
  NAND2x1_ASAP7_75t_R  g191(.A(p6), .B(p59), .Y(new_n278_));
  AND4x2_ASAP7_75t_R   g192(.A(new_n276_), .B(new_n109_), .C(new_n277_), .D(new_n278_), .Y(new_n279_));
  AND3x1_ASAP7_75t_R   g193(.A(new_n157_), .B(p22), .C(new_n156_), .Y(new_n280_));
  AND2x2_ASAP7_75t_R   g194(.A(p54), .B(p16), .Y(new_n281_));
  AND3x1_ASAP7_75t_R   g195(.A(new_n109_), .B(new_n281_), .C(new_n145_), .Y(new_n282_));
  AOI211x1_ASAP7_75t_R g196(.A1(p22), .A2(new_n279_), .B(new_n280_), .C(new_n282_), .Y(new_n283_));
  NAND2x1_ASAP7_75t_R  g197(.A(new_n274_), .B(new_n283_), .Y(new_n284_));
  NAND3x1_ASAP7_75t_R  g198(.A(new_n185_), .B(new_n272_), .C(new_n284_), .Y(new_n285_));
  AO31x2_ASAP7_75t_R   g199(.A1(new_n217_), .A2(new_n188_), .A3(new_n204_), .B(new_n285_), .Y(new_n286_));
  AND2x2_ASAP7_75t_R   g200(.A(p52), .B(p16), .Y(new_n287_));
  AND3x1_ASAP7_75t_R   g201(.A(new_n109_), .B(new_n287_), .C(new_n145_), .Y(new_n288_));
  AOI211x1_ASAP7_75t_R g202(.A1(p8), .A2(p57), .B(new_n288_), .C(new_n261_), .Y(new_n289_));
  NAND2x1_ASAP7_75t_R  g203(.A(p21), .B(new_n178_), .Y(new_n290_));
  AO21x1_ASAP7_75t_R   g204(.A1(new_n289_), .A2(new_n290_), .B(new_n133_), .Y(new_n291_));
  AOI22x1_ASAP7_75t_R  g205(.A1(new_n283_), .A2(new_n274_), .B1(new_n260_), .B2(new_n265_), .Y(new_n292_));
  INVx1_ASAP7_75t_R    g206(.A(new_n264_), .Y(new_n293_));
  NAND3x1_ASAP7_75t_R  g207(.A(new_n144_), .B(new_n146_), .C(p23), .Y(new_n294_));
  NOR3x1_ASAP7_75t_R   g208(.A(new_n88_), .B(new_n275_), .C(p44), .Y(new_n295_));
  NAND2x1_ASAP7_75t_R  g209(.A(new_n139_), .B(new_n295_), .Y(new_n296_));
  OR4x2_ASAP7_75t_R    g210(.A(new_n136_), .B(new_n259_), .C(new_n98_), .D(new_n137_), .Y(new_n297_));
  AND4x2_ASAP7_75t_R   g211(.A(new_n293_), .B(new_n294_), .C(new_n296_), .D(new_n297_), .Y(new_n298_));
  INVx1_ASAP7_75t_R    g212(.A(p32), .Y(new_n299_));
  AND3x1_ASAP7_75t_R   g213(.A(new_n145_), .B(p16), .C(p45), .Y(new_n300_));
  AOI21x1_ASAP7_75t_R  g214(.A1(new_n109_), .A2(new_n300_), .B(new_n267_), .Y(new_n301_));
  NAND3x1_ASAP7_75t_R  g215(.A(new_n144_), .B(new_n146_), .C(p24), .Y(new_n302_));
  OR4x2_ASAP7_75t_R    g216(.A(new_n136_), .B(new_n270_), .C(new_n98_), .D(new_n137_), .Y(new_n303_));
  AND4x2_ASAP7_75t_R   g217(.A(new_n301_), .B(new_n302_), .C(new_n296_), .D(new_n303_), .Y(new_n304_));
  INVx1_ASAP7_75t_R    g218(.A(p33), .Y(new_n305_));
  OAI22x1_ASAP7_75t_R  g219(.A1(new_n298_), .A2(new_n299_), .B1(new_n304_), .B2(new_n305_), .Y(new_n306_));
  AOI21x1_ASAP7_75t_R  g220(.A1(p22), .A2(new_n279_), .B(new_n280_), .Y(new_n307_));
  NOR3x1_ASAP7_75t_R   g221(.A(new_n261_), .B(new_n273_), .C(new_n282_), .Y(new_n308_));
  INVx1_ASAP7_75t_R    g222(.A(p31), .Y(new_n309_));
  AOI21x1_ASAP7_75t_R  g223(.A1(new_n307_), .A2(new_n308_), .B(new_n309_), .Y(new_n310_));
  AOI21x1_ASAP7_75t_R  g224(.A1(new_n292_), .A2(new_n306_), .B(new_n310_), .Y(new_n311_));
  AND2x2_ASAP7_75t_R   g225(.A(new_n291_), .B(new_n311_), .Y(new_n312_));
  NAND2x1_ASAP7_75t_R  g226(.A(p8), .B(p57), .Y(new_n313_));
  AND3x1_ASAP7_75t_R   g227(.A(new_n296_), .B(new_n133_), .C(new_n313_), .Y(new_n314_));
  AOI21x1_ASAP7_75t_R  g228(.A1(p21), .A2(new_n138_), .B(new_n288_), .Y(new_n315_));
  NAND2x1_ASAP7_75t_R  g229(.A(p21), .B(new_n279_), .Y(new_n316_));
  NAND3x1_ASAP7_75t_R  g230(.A(new_n314_), .B(new_n315_), .C(new_n316_), .Y(new_n317_));
  INVx1_ASAP7_75t_R    g231(.A(new_n317_), .Y(new_n318_));
  AO21x1_ASAP7_75t_R   g232(.A1(new_n286_), .A2(new_n312_), .B(new_n318_), .Y(o21));
  NAND2x1_ASAP7_75t_R  g233(.A(new_n271_), .B(new_n269_), .Y(new_n320_));
  NAND2x1_ASAP7_75t_R  g234(.A(new_n303_), .B(new_n302_), .Y(new_n321_));
  AO21x1_ASAP7_75t_R   g235(.A1(new_n139_), .A2(new_n295_), .B(new_n268_), .Y(new_n322_));
  OAI21x1_ASAP7_75t_R  g236(.A1(new_n321_), .A2(new_n322_), .B(p33), .Y(new_n323_));
  NAND2x1_ASAP7_75t_R  g237(.A(new_n320_), .B(new_n323_), .Y(new_n324_));
  AOI21x1_ASAP7_75t_R  g238(.A1(new_n186_), .A2(new_n187_), .B(new_n129_), .Y(new_n325_));
  AOI211x1_ASAP7_75t_R g239(.A1(p25), .A2(new_n178_), .B(new_n180_), .C(new_n184_), .Y(new_n326_));
  OAI22x1_ASAP7_75t_R  g240(.A1(new_n212_), .A2(new_n213_), .B1(new_n215_), .B2(new_n214_), .Y(new_n327_));
  AOI211x1_ASAP7_75t_R g241(.A1(new_n220_), .A2(new_n222_), .B(new_n326_), .C(new_n327_), .Y(new_n328_));
  AOI211x1_ASAP7_75t_R g242(.A1(new_n185_), .A2(new_n224_), .B(new_n325_), .C(new_n328_), .Y(new_n329_));
  NAND2x1_ASAP7_75t_R  g243(.A(new_n324_), .B(new_n329_), .Y(new_n330_));
  OA21x2_ASAP7_75t_R   g244(.A1(new_n324_), .A2(new_n329_), .B(p50), .Y(new_n331_));
  AOI22x1_ASAP7_75t_R  g245(.A1(new_n168_), .A2(p33), .B1(p49), .B2(p23), .Y(new_n332_));
  OAI21x1_ASAP7_75t_R  g246(.A1(new_n172_), .A2(new_n304_), .B(new_n332_), .Y(new_n333_));
  AND3x1_ASAP7_75t_R   g247(.A(new_n323_), .B(new_n320_), .C(p47), .Y(new_n334_));
  NOR2x1_ASAP7_75t_R   g248(.A(new_n171_), .B(new_n323_), .Y(new_n335_));
  OR3x1_ASAP7_75t_R    g249(.A(new_n333_), .B(new_n334_), .C(new_n335_), .Y(new_n336_));
  AOI21x1_ASAP7_75t_R  g250(.A1(new_n330_), .A2(new_n331_), .B(new_n336_), .Y(o22));
  NAND2x1_ASAP7_75t_R  g251(.A(new_n284_), .B(new_n272_), .Y(new_n338_));
  NAND2x1_ASAP7_75t_R  g252(.A(new_n317_), .B(new_n291_), .Y(new_n339_));
  OR3x1_ASAP7_75t_R    g253(.A(new_n329_), .B(new_n338_), .C(new_n339_), .Y(new_n340_));
  AOI21x1_ASAP7_75t_R  g254(.A1(new_n289_), .A2(new_n290_), .B(new_n133_), .Y(new_n341_));
  NOR2x1_ASAP7_75t_R   g255(.A(new_n341_), .B(new_n318_), .Y(new_n342_));
  AOI211x1_ASAP7_75t_R g256(.A1(new_n292_), .A2(new_n306_), .B(new_n310_), .C(new_n342_), .Y(new_n343_));
  OAI21x1_ASAP7_75t_R  g257(.A1(new_n339_), .A2(new_n311_), .B(p50), .Y(new_n344_));
  AOI21x1_ASAP7_75t_R  g258(.A1(new_n343_), .A2(new_n286_), .B(new_n344_), .Y(new_n345_));
  AOI22x1_ASAP7_75t_R  g259(.A1(new_n168_), .A2(p30), .B1(p49), .B2(p44), .Y(new_n346_));
  AO21x1_ASAP7_75t_R   g260(.A1(new_n289_), .A2(new_n290_), .B(new_n172_), .Y(new_n347_));
  OA211x2_ASAP7_75t_R  g261(.A1(new_n171_), .A2(new_n291_), .B(new_n346_), .C(new_n347_), .Y(new_n348_));
  OAI21x1_ASAP7_75t_R  g262(.A1(new_n227_), .A2(new_n339_), .B(new_n348_), .Y(new_n349_));
  AOI21x1_ASAP7_75t_R  g263(.A1(new_n340_), .A2(new_n345_), .B(new_n349_), .Y(o23));
  INVx1_ASAP7_75t_R    g264(.A(new_n272_), .Y(new_n351_));
  NAND2x1_ASAP7_75t_R  g265(.A(new_n297_), .B(new_n294_), .Y(new_n352_));
  AO21x1_ASAP7_75t_R   g266(.A1(new_n139_), .A2(new_n295_), .B(new_n264_), .Y(new_n353_));
  OAI21x1_ASAP7_75t_R  g267(.A1(new_n352_), .A2(new_n353_), .B(p32), .Y(new_n354_));
  NOR3x1_ASAP7_75t_R   g268(.A(new_n353_), .B(new_n352_), .C(p32), .Y(new_n355_));
  AOI21x1_ASAP7_75t_R  g269(.A1(new_n354_), .A2(new_n323_), .B(new_n355_), .Y(new_n356_));
  AOI21x1_ASAP7_75t_R  g270(.A1(new_n283_), .A2(new_n274_), .B(new_n310_), .Y(new_n357_));
  NOR2x1_ASAP7_75t_R   g271(.A(new_n356_), .B(new_n357_), .Y(new_n358_));
  OAI21x1_ASAP7_75t_R  g272(.A1(new_n351_), .A2(new_n329_), .B(new_n358_), .Y(new_n359_));
  INVx1_ASAP7_75t_R    g273(.A(new_n357_), .Y(new_n360_));
  AOI21x1_ASAP7_75t_R  g274(.A1(new_n356_), .A2(new_n357_), .B(new_n177_), .Y(new_n361_));
  OA31x2_ASAP7_75t_R   g275(.A1(new_n351_), .A2(new_n360_), .A3(new_n329_), .B1(new_n361_), .Y(new_n362_));
  AOI22x1_ASAP7_75t_R  g276(.A1(new_n168_), .A2(p31), .B1(p49), .B2(p21), .Y(new_n363_));
  AO21x1_ASAP7_75t_R   g277(.A1(new_n307_), .A2(new_n308_), .B(new_n172_), .Y(new_n364_));
  NAND2x1_ASAP7_75t_R  g278(.A(p48), .B(new_n310_), .Y(new_n365_));
  AND3x1_ASAP7_75t_R   g279(.A(new_n363_), .B(new_n364_), .C(new_n365_), .Y(new_n366_));
  OAI21x1_ASAP7_75t_R  g280(.A1(new_n227_), .A2(new_n360_), .B(new_n366_), .Y(new_n367_));
  AOI21x1_ASAP7_75t_R  g281(.A1(new_n359_), .A2(new_n362_), .B(new_n367_), .Y(o24));
  NAND2x1_ASAP7_75t_R  g282(.A(new_n260_), .B(new_n265_), .Y(new_n369_));
  NAND2x1_ASAP7_75t_R  g283(.A(new_n369_), .B(new_n354_), .Y(new_n370_));
  AO21x1_ASAP7_75t_R   g284(.A1(new_n271_), .A2(new_n269_), .B(new_n370_), .Y(new_n371_));
  AO21x1_ASAP7_75t_R   g285(.A1(new_n323_), .A2(new_n329_), .B(new_n371_), .Y(new_n372_));
  AND2x2_ASAP7_75t_R   g286(.A(new_n323_), .B(new_n370_), .Y(new_n373_));
  NAND2x1_ASAP7_75t_R  g287(.A(new_n320_), .B(new_n185_), .Y(new_n374_));
  AO31x2_ASAP7_75t_R   g288(.A1(new_n217_), .A2(new_n188_), .A3(new_n204_), .B(new_n374_), .Y(new_n375_));
  AOI21x1_ASAP7_75t_R  g289(.A1(new_n373_), .A2(new_n375_), .B(new_n177_), .Y(new_n376_));
  AOI22x1_ASAP7_75t_R  g290(.A1(new_n168_), .A2(p32), .B1(p49), .B2(p22), .Y(new_n377_));
  OR3x1_ASAP7_75t_R    g291(.A(new_n298_), .B(new_n299_), .C(new_n171_), .Y(new_n378_));
  OA211x2_ASAP7_75t_R  g292(.A1(new_n172_), .A2(new_n298_), .B(new_n377_), .C(new_n378_), .Y(new_n379_));
  OAI21x1_ASAP7_75t_R  g293(.A1(new_n227_), .A2(new_n370_), .B(new_n379_), .Y(new_n380_));
  AOI21x1_ASAP7_75t_R  g294(.A1(new_n372_), .A2(new_n376_), .B(new_n380_), .Y(o25));
endmodule


