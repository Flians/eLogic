// Benchmark "/tmp/" written by ABC on Mon Oct 12 15:07:59 2026

module \/tmp/  ( 
    p41, p40, p20, p56, p0, p15, p25, p16, p44, p32, p28, p23, p46, p21,
    p2, p55, p54, p18, p6, p39, p45, p10, p7, p1, p36, p42, p37, p30, p26,
    p58, p52, p53, p11, p49, p14, p50, p31, p17, p4, p24, p34, p29, p57,
    p22, p38, p51, p33, p43, p19, p9, p47, p3, p8, p5, p48, p13, p35, p59,
    p27, p12,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25  );
  input  p41, p40, p20, p56, p0, p15, p25, p16, p44, p32, p28, p23, p46,
    p21, p2, p55, p54, p18, p6, p39, p45, p10, p7, p1, p36, p42, p37, p30,
    p26, p58, p52, p53, p11, p49, p14, p50, p31, p17, p4, p24, p34, p29,
    p57, p22, p38, p51, p33, p43, p19, p9, p47, p3, p8, p5, p48, p13, p35,
    p59, p27, p12;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25;
  wire new_n87_, new_n88_, new_n90_, new_n91_, new_n92_, new_n94_, new_n97_,
    new_n98_, new_n99_, new_n101_, new_n102_, new_n103_, new_n110_,
    new_n112_, new_n113_, new_n114_, new_n116_, new_n117_, new_n120_,
    new_n121_, new_n122_, new_n123_, new_n124_, new_n125_, new_n126_,
    new_n127_, new_n129_, new_n130_, new_n131_, new_n132_, new_n133_,
    new_n134_, new_n135_, new_n136_, new_n138_, new_n139_, new_n140_,
    new_n141_, new_n142_, new_n143_, new_n144_, new_n145_, new_n146_,
    new_n147_, new_n148_, new_n149_, new_n150_, new_n151_, new_n152_,
    new_n153_, new_n154_, new_n155_, new_n156_, new_n157_, new_n158_,
    new_n159_, new_n160_, new_n161_, new_n162_, new_n163_, new_n164_,
    new_n165_, new_n166_, new_n167_, new_n168_, new_n169_, new_n170_,
    new_n171_, new_n172_, new_n173_, new_n174_, new_n176_, new_n177_,
    new_n178_, new_n179_, new_n180_, new_n181_, new_n182_, new_n183_,
    new_n184_, new_n185_, new_n186_, new_n187_, new_n188_, new_n189_,
    new_n190_, new_n191_, new_n192_, new_n193_, new_n194_, new_n195_,
    new_n196_, new_n197_, new_n198_, new_n199_, new_n200_, new_n201_,
    new_n202_, new_n203_, new_n204_, new_n205_, new_n206_, new_n207_,
    new_n208_, new_n209_, new_n210_, new_n211_, new_n212_, new_n213_,
    new_n214_, new_n215_, new_n216_, new_n217_, new_n218_, new_n219_,
    new_n220_, new_n221_, new_n222_, new_n223_, new_n224_, new_n225_,
    new_n226_, new_n227_, new_n228_, new_n229_, new_n230_, new_n231_,
    new_n233_, new_n234_, new_n235_, new_n236_, new_n237_, new_n238_,
    new_n239_, new_n240_, new_n241_, new_n242_, new_n243_, new_n244_,
    new_n245_, new_n246_, new_n247_, new_n248_, new_n249_, new_n251_,
    new_n252_, new_n253_, new_n254_, new_n255_, new_n256_, new_n257_,
    new_n259_, new_n260_, new_n261_, new_n262_, new_n263_, new_n264_,
    new_n265_, new_n266_, new_n267_, new_n268_, new_n269_, new_n270_,
    new_n271_, new_n272_, new_n273_, new_n274_, new_n275_, new_n276_,
    new_n277_, new_n278_, new_n279_, new_n280_, new_n281_, new_n282_,
    new_n283_, new_n284_, new_n285_, new_n286_, new_n287_, new_n288_,
    new_n289_, new_n290_, new_n291_, new_n292_, new_n293_, new_n294_,
    new_n295_, new_n296_, new_n297_, new_n298_, new_n299_, new_n300_,
    new_n301_, new_n302_, new_n303_, new_n304_, new_n305_, new_n306_,
    new_n307_, new_n308_, new_n309_, new_n310_, new_n311_, new_n312_,
    new_n313_, new_n315_, new_n316_, new_n317_, new_n318_, new_n319_,
    new_n320_, new_n321_, new_n322_, new_n323_, new_n324_, new_n325_,
    new_n326_, new_n327_, new_n328_, new_n329_, new_n330_, new_n331_,
    new_n332_, new_n334_, new_n335_, new_n336_, new_n337_, new_n338_,
    new_n339_, new_n340_, new_n341_, new_n342_, new_n343_, new_n344_,
    new_n345_, new_n347_, new_n348_, new_n349_, new_n350_, new_n351_,
    new_n352_, new_n353_, new_n354_, new_n355_, new_n356_, new_n357_,
    new_n358_, new_n359_, new_n360_, new_n361_, new_n362_, new_n363_,
    new_n365_, new_n366_, new_n367_, new_n368_, new_n369_, new_n370_,
    new_n371_, new_n372_, new_n373_, new_n374_, new_n375_;
  INVx1_ASAP7_75t_R    g000(.A(p59), .Y(new_n87_));
  NAND2x1_ASAP7_75t_R  g001(.A(p0), .B(p1), .Y(new_n88_));
  OR2x4_ASAP7_75t_R    g002(.A(new_n87_), .B(new_n88_), .Y(o0));
  INVx1_ASAP7_75t_R    g003(.A(p2), .Y(new_n90_));
  INVx1_ASAP7_75t_R    g004(.A(p1), .Y(new_n91_));
  INVx1_ASAP7_75t_R    g005(.A(p3), .Y(new_n92_));
  OR3x1_ASAP7_75t_R    g006(.A(new_n90_), .B(new_n91_), .C(new_n92_), .Y(o1));
  AND3x1_ASAP7_75t_R   g007(.A(p1), .B(p3), .C(p59), .Y(new_n94_));
  INVx1_ASAP7_75t_R    g008(.A(new_n94_), .Y(o2));
  NAND2x1_ASAP7_75t_R  g009(.A(p4), .B(p5), .Y(o3));
  NAND2x1_ASAP7_75t_R  g010(.A(p9), .B(p8), .Y(new_n97_));
  INVx1_ASAP7_75t_R    g011(.A(p6), .Y(new_n98_));
  INVx1_ASAP7_75t_R    g012(.A(p7), .Y(new_n99_));
  OR3x1_ASAP7_75t_R    g013(.A(new_n97_), .B(new_n98_), .C(new_n99_), .Y(o4));
  AND2x2_ASAP7_75t_R   g014(.A(p6), .B(p7), .Y(new_n101_));
  NAND2x1_ASAP7_75t_R  g015(.A(p10), .B(p9), .Y(new_n102_));
  INVx1_ASAP7_75t_R    g016(.A(new_n102_), .Y(new_n103_));
  AND3x1_ASAP7_75t_R   g017(.A(o2), .B(new_n101_), .C(new_n103_), .Y(o5));
  AND3x1_ASAP7_75t_R   g018(.A(p0), .B(p2), .C(p11), .Y(o6));
  AND3x1_ASAP7_75t_R   g019(.A(p2), .B(p11), .C(p3), .Y(o7));
  AND3x1_ASAP7_75t_R   g020(.A(p11), .B(p3), .C(p59), .Y(o8));
  OAI21x1_ASAP7_75t_R  g021(.A1(p14), .A2(p13), .B(p12), .Y(o9));
  AND3x1_ASAP7_75t_R   g022(.A(new_n103_), .B(new_n94_), .C(new_n101_), .Y(o10));
  AND3x1_ASAP7_75t_R   g023(.A(p15), .B(p10), .C(p9), .Y(new_n110_));
  INVx1_ASAP7_75t_R    g024(.A(new_n110_), .Y(o11));
  INVx1_ASAP7_75t_R    g025(.A(p16), .Y(new_n112_));
  OR3x1_ASAP7_75t_R    g026(.A(new_n97_), .B(new_n112_), .C(new_n99_), .Y(new_n113_));
  INVx1_ASAP7_75t_R    g027(.A(p17), .Y(new_n114_));
  OR3x1_ASAP7_75t_R    g028(.A(new_n113_), .B(new_n91_), .C(new_n114_), .Y(o12));
  NAND2x1_ASAP7_75t_R  g029(.A(p11), .B(p17), .Y(new_n116_));
  NOR2x1_ASAP7_75t_R   g030(.A(new_n116_), .B(new_n113_), .Y(new_n117_));
  NAND2x1_ASAP7_75t_R  g031(.A(p18), .B(new_n117_), .Y(o13));
  OAI21x1_ASAP7_75t_R  g032(.A1(p14), .A2(p13), .B(p19), .Y(o14));
  XOR2x2_ASAP7_75t_R   g033(.A(p21), .B(p22), .Y(new_n120_));
  XOR2x2_ASAP7_75t_R   g034(.A(p28), .B(p23), .Y(new_n121_));
  XOR2x2_ASAP7_75t_R   g035(.A(new_n120_), .B(new_n121_), .Y(new_n122_));
  XOR2x2_ASAP7_75t_R   g036(.A(p24), .B(p27), .Y(new_n123_));
  XOR2x2_ASAP7_75t_R   g037(.A(new_n122_), .B(new_n123_), .Y(new_n124_));
  XNOR2x2_ASAP7_75t_R  g038(.A(p26), .B(p29), .Y(new_n125_));
  XOR2x2_ASAP7_75t_R   g039(.A(p20), .B(p25), .Y(new_n126_));
  XOR2x2_ASAP7_75t_R   g040(.A(new_n125_), .B(new_n126_), .Y(new_n127_));
  XOR2x2_ASAP7_75t_R   g041(.A(new_n124_), .B(new_n127_), .Y(o15));
  XOR2x2_ASAP7_75t_R   g042(.A(p30), .B(p31), .Y(new_n129_));
  XOR2x2_ASAP7_75t_R   g043(.A(new_n129_), .B(p20), .Y(new_n130_));
  XOR2x2_ASAP7_75t_R   g044(.A(p38), .B(p33), .Y(new_n131_));
  XOR2x2_ASAP7_75t_R   g045(.A(new_n131_), .B(p32), .Y(new_n132_));
  XOR2x2_ASAP7_75t_R   g046(.A(new_n130_), .B(new_n132_), .Y(new_n133_));
  XNOR2x2_ASAP7_75t_R  g047(.A(p34), .B(p35), .Y(new_n134_));
  XOR2x2_ASAP7_75t_R   g048(.A(p36), .B(p37), .Y(new_n135_));
  XOR2x2_ASAP7_75t_R   g049(.A(new_n134_), .B(new_n135_), .Y(new_n136_));
  XOR2x2_ASAP7_75t_R   g050(.A(new_n133_), .B(new_n136_), .Y(o16));
  AND3x1_ASAP7_75t_R   g051(.A(p0), .B(p11), .C(p59), .Y(new_n138_));
  NAND2x1_ASAP7_75t_R  g052(.A(p15), .B(p6), .Y(new_n139_));
  NOR3x1_ASAP7_75t_R   g053(.A(new_n138_), .B(new_n97_), .C(new_n139_), .Y(new_n140_));
  AND4x2_ASAP7_75t_R   g054(.A(p15), .B(p2), .C(p10), .D(p9), .Y(new_n141_));
  NOR3x1_ASAP7_75t_R   g055(.A(new_n88_), .B(new_n112_), .C(p44), .Y(new_n142_));
  AOI22x1_ASAP7_75t_R  g056(.A1(new_n140_), .A2(p28), .B1(new_n141_), .B2(new_n142_), .Y(new_n143_));
  OAI21x1_ASAP7_75t_R  g057(.A1(p6), .A2(p59), .B(p15), .Y(new_n144_));
  NOR2x1_ASAP7_75t_R   g058(.A(new_n102_), .B(new_n144_), .Y(new_n145_));
  NAND2x1_ASAP7_75t_R  g059(.A(p46), .B(p11), .Y(new_n146_));
  AOI21x1_ASAP7_75t_R  g060(.A1(p6), .A2(p59), .B(new_n146_), .Y(new_n147_));
  NAND3x1_ASAP7_75t_R  g061(.A(new_n145_), .B(new_n147_), .C(p28), .Y(new_n148_));
  AOI211x1_ASAP7_75t_R g062(.A1(p46), .A2(p11), .B(new_n102_), .C(new_n139_), .Y(new_n149_));
  INVx1_ASAP7_75t_R    g063(.A(p9), .Y(new_n150_));
  AO21x1_ASAP7_75t_R   g064(.A1(p45), .A2(new_n150_), .B(p37), .Y(new_n151_));
  AOI21x1_ASAP7_75t_R  g065(.A1(p45), .A2(new_n149_), .B(new_n151_), .Y(new_n152_));
  AND3x1_ASAP7_75t_R   g066(.A(new_n143_), .B(new_n148_), .C(new_n152_), .Y(new_n153_));
  AO31x2_ASAP7_75t_R   g067(.A1(new_n146_), .A2(p15), .A3(p10), .B(new_n150_), .Y(new_n154_));
  OA21x2_ASAP7_75t_R   g068(.A1(p6), .A2(new_n150_), .B(p45), .Y(new_n155_));
  AOI22x1_ASAP7_75t_R  g069(.A1(new_n154_), .A2(new_n155_), .B1(new_n141_), .B2(new_n142_), .Y(new_n156_));
  NAND3x1_ASAP7_75t_R  g070(.A(p0), .B(p11), .C(p59), .Y(new_n157_));
  AND4x2_ASAP7_75t_R   g071(.A(p15), .B(p6), .C(p9), .D(p8), .Y(new_n158_));
  NAND2x1_ASAP7_75t_R  g072(.A(new_n157_), .B(new_n158_), .Y(new_n159_));
  NAND2x1_ASAP7_75t_R  g073(.A(new_n147_), .B(new_n145_), .Y(new_n160_));
  INVx1_ASAP7_75t_R    g074(.A(p28), .Y(new_n161_));
  AO21x1_ASAP7_75t_R   g075(.A1(new_n159_), .A2(new_n160_), .B(new_n161_), .Y(new_n162_));
  INVx1_ASAP7_75t_R    g076(.A(p37), .Y(new_n163_));
  AOI21x1_ASAP7_75t_R  g077(.A1(new_n156_), .A2(new_n162_), .B(new_n163_), .Y(new_n164_));
  NOR2x1_ASAP7_75t_R   g078(.A(new_n153_), .B(new_n164_), .Y(new_n165_));
  XOR2x2_ASAP7_75t_R   g079(.A(new_n165_), .B(p51), .Y(new_n166_));
  NAND2x1_ASAP7_75t_R  g080(.A(new_n156_), .B(new_n162_), .Y(new_n167_));
  AND3x1_ASAP7_75t_R   g081(.A(p40), .B(p39), .C(p59), .Y(new_n168_));
  AND2x2_ASAP7_75t_R   g082(.A(p37), .B(new_n168_), .Y(new_n169_));
  AO22x1_ASAP7_75t_R   g083(.A1(p41), .A2(p42), .B1(p49), .B2(p27), .Y(new_n170_));
  AO21x1_ASAP7_75t_R   g084(.A1(new_n169_), .A2(new_n117_), .B(new_n170_), .Y(new_n171_));
  AO21x1_ASAP7_75t_R   g085(.A1(p43), .A2(new_n167_), .B(new_n171_), .Y(new_n172_));
  AO21x1_ASAP7_75t_R   g086(.A1(p48), .A2(new_n164_), .B(new_n172_), .Y(new_n173_));
  AO21x1_ASAP7_75t_R   g087(.A1(p47), .A2(new_n165_), .B(new_n173_), .Y(new_n174_));
  AOI21x1_ASAP7_75t_R  g088(.A1(p50), .A2(new_n166_), .B(new_n174_), .Y(o17));
  INVx1_ASAP7_75t_R    g089(.A(p50), .Y(new_n176_));
  AO21x1_ASAP7_75t_R   g090(.A1(new_n147_), .A2(new_n145_), .B(new_n140_), .Y(new_n177_));
  AND2x2_ASAP7_75t_R   g091(.A(new_n141_), .B(new_n142_), .Y(new_n178_));
  OA21x2_ASAP7_75t_R   g092(.A1(p6), .A2(new_n150_), .B(p52), .Y(new_n179_));
  AO21x1_ASAP7_75t_R   g093(.A1(new_n179_), .A2(new_n154_), .B(p34), .Y(new_n180_));
  AO211x2_ASAP7_75t_R  g094(.A1(new_n177_), .A2(p25), .B(new_n178_), .C(new_n180_), .Y(new_n181_));
  AOI21x1_ASAP7_75t_R  g095(.A1(new_n154_), .A2(new_n179_), .B(new_n178_), .Y(new_n182_));
  NAND2x1_ASAP7_75t_R  g096(.A(p25), .B(new_n177_), .Y(new_n183_));
  INVx1_ASAP7_75t_R    g097(.A(p34), .Y(new_n184_));
  AO21x1_ASAP7_75t_R   g098(.A1(new_n182_), .A2(new_n183_), .B(new_n184_), .Y(new_n185_));
  NAND2x1_ASAP7_75t_R  g099(.A(new_n181_), .B(new_n185_), .Y(new_n186_));
  OA21x2_ASAP7_75t_R   g100(.A1(p6), .A2(new_n150_), .B(p53), .Y(new_n187_));
  AOI22x1_ASAP7_75t_R  g101(.A1(new_n154_), .A2(new_n187_), .B1(new_n141_), .B2(new_n142_), .Y(new_n188_));
  NAND3x1_ASAP7_75t_R  g102(.A(new_n145_), .B(new_n147_), .C(p27), .Y(new_n189_));
  NAND3x1_ASAP7_75t_R  g103(.A(new_n158_), .B(p27), .C(new_n157_), .Y(new_n190_));
  INVx1_ASAP7_75t_R    g104(.A(p36), .Y(new_n191_));
  AO31x2_ASAP7_75t_R   g105(.A1(new_n188_), .A2(new_n189_), .A3(new_n190_), .B(new_n191_), .Y(new_n192_));
  AOI22x1_ASAP7_75t_R  g106(.A1(new_n140_), .A2(p26), .B1(new_n141_), .B2(new_n142_), .Y(new_n193_));
  NAND3x1_ASAP7_75t_R  g107(.A(new_n145_), .B(new_n147_), .C(p26), .Y(new_n194_));
  OA21x2_ASAP7_75t_R   g108(.A1(p6), .A2(new_n150_), .B(p54), .Y(new_n195_));
  AOI21x1_ASAP7_75t_R  g109(.A1(new_n195_), .A2(new_n154_), .B(p35), .Y(new_n196_));
  AND3x1_ASAP7_75t_R   g110(.A(new_n193_), .B(new_n194_), .C(new_n196_), .Y(new_n197_));
  INVx1_ASAP7_75t_R    g111(.A(p35), .Y(new_n198_));
  NAND2x1_ASAP7_75t_R  g112(.A(new_n195_), .B(new_n154_), .Y(new_n199_));
  AND3x1_ASAP7_75t_R   g113(.A(new_n193_), .B(new_n199_), .C(new_n194_), .Y(new_n200_));
  OA22x2_ASAP7_75t_R   g114(.A1(new_n192_), .A2(new_n197_), .B1(new_n198_), .B2(new_n200_), .Y(new_n201_));
  AO21x1_ASAP7_75t_R   g115(.A1(p45), .A2(new_n149_), .B(new_n151_), .Y(new_n202_));
  INVx1_ASAP7_75t_R    g116(.A(new_n148_), .Y(new_n203_));
  NAND2x1_ASAP7_75t_R  g117(.A(new_n141_), .B(new_n142_), .Y(new_n204_));
  OAI21x1_ASAP7_75t_R  g118(.A1(new_n161_), .A2(new_n159_), .B(new_n204_), .Y(new_n205_));
  OA31x2_ASAP7_75t_R   g119(.A1(new_n202_), .A2(new_n203_), .A3(new_n205_), .B1(p51), .Y(new_n206_));
  INVx1_ASAP7_75t_R    g120(.A(p26), .Y(new_n207_));
  OR4x2_ASAP7_75t_R    g121(.A(new_n138_), .B(new_n207_), .C(new_n97_), .D(new_n139_), .Y(new_n208_));
  NAND3x1_ASAP7_75t_R  g122(.A(new_n194_), .B(new_n208_), .C(new_n204_), .Y(new_n209_));
  INVx1_ASAP7_75t_R    g123(.A(new_n196_), .Y(new_n210_));
  AO21x1_ASAP7_75t_R   g124(.A1(new_n187_), .A2(new_n154_), .B(p36), .Y(new_n211_));
  NAND3x1_ASAP7_75t_R  g125(.A(new_n189_), .B(new_n204_), .C(new_n190_), .Y(new_n212_));
  OA22x2_ASAP7_75t_R   g126(.A1(new_n209_), .A2(new_n210_), .B1(new_n211_), .B2(new_n212_), .Y(new_n213_));
  OAI21x1_ASAP7_75t_R  g127(.A1(new_n164_), .A2(new_n206_), .B(new_n213_), .Y(new_n214_));
  AND3x1_ASAP7_75t_R   g128(.A(new_n186_), .B(new_n201_), .C(new_n214_), .Y(new_n215_));
  NAND2x1_ASAP7_75t_R  g129(.A(p28), .B(new_n140_), .Y(new_n216_));
  AO31x2_ASAP7_75t_R   g130(.A1(new_n156_), .A2(new_n148_), .A3(new_n216_), .B(new_n163_), .Y(new_n217_));
  INVx1_ASAP7_75t_R    g131(.A(p51), .Y(new_n218_));
  AO31x2_ASAP7_75t_R   g132(.A1(new_n143_), .A2(new_n148_), .A3(new_n152_), .B(new_n218_), .Y(new_n219_));
  NAND2x1_ASAP7_75t_R  g133(.A(new_n217_), .B(new_n219_), .Y(new_n220_));
  OAI22x1_ASAP7_75t_R  g134(.A1(new_n192_), .A2(new_n197_), .B1(new_n200_), .B2(new_n198_), .Y(new_n221_));
  AO21x1_ASAP7_75t_R   g135(.A1(new_n220_), .A2(new_n213_), .B(new_n221_), .Y(new_n222_));
  AND3x1_ASAP7_75t_R   g136(.A(new_n222_), .B(new_n181_), .C(new_n185_), .Y(new_n223_));
  INVx1_ASAP7_75t_R    g137(.A(p47), .Y(new_n224_));
  AND3x1_ASAP7_75t_R   g138(.A(new_n117_), .B(p34), .C(new_n168_), .Y(new_n225_));
  AOI21x1_ASAP7_75t_R  g139(.A1(p49), .A2(p24), .B(new_n225_), .Y(new_n226_));
  INVx1_ASAP7_75t_R    g140(.A(p48), .Y(new_n227_));
  INVx1_ASAP7_75t_R    g141(.A(p43), .Y(new_n228_));
  OA21x2_ASAP7_75t_R   g142(.A1(new_n184_), .A2(new_n227_), .B(new_n228_), .Y(new_n229_));
  AO21x1_ASAP7_75t_R   g143(.A1(new_n182_), .A2(new_n183_), .B(new_n229_), .Y(new_n230_));
  OA211x2_ASAP7_75t_R  g144(.A1(new_n224_), .A2(new_n186_), .B(new_n226_), .C(new_n230_), .Y(new_n231_));
  OA31x2_ASAP7_75t_R   g145(.A1(new_n176_), .A2(new_n215_), .A3(new_n223_), .B1(new_n231_), .Y(o18));
  AND2x2_ASAP7_75t_R   g146(.A(new_n190_), .B(new_n189_), .Y(new_n233_));
  NAND2x1_ASAP7_75t_R  g147(.A(new_n188_), .B(new_n233_), .Y(new_n234_));
  OA21x2_ASAP7_75t_R   g148(.A1(p36), .A2(new_n234_), .B(new_n220_), .Y(new_n235_));
  AOI21x1_ASAP7_75t_R  g149(.A1(new_n188_), .A2(new_n233_), .B(new_n191_), .Y(new_n236_));
  AND3x1_ASAP7_75t_R   g150(.A(new_n194_), .B(new_n208_), .C(new_n204_), .Y(new_n237_));
  AOI21x1_ASAP7_75t_R  g151(.A1(new_n199_), .A2(new_n237_), .B(new_n198_), .Y(new_n238_));
  NOR2x1_ASAP7_75t_R   g152(.A(new_n197_), .B(new_n238_), .Y(new_n239_));
  OR3x1_ASAP7_75t_R    g153(.A(new_n235_), .B(new_n236_), .C(new_n239_), .Y(new_n240_));
  AO21x1_ASAP7_75t_R   g154(.A1(new_n236_), .A2(new_n239_), .B(new_n176_), .Y(new_n241_));
  AOI21x1_ASAP7_75t_R  g155(.A1(new_n239_), .A2(new_n235_), .B(new_n241_), .Y(new_n242_));
  OR3x1_ASAP7_75t_R    g156(.A(new_n238_), .B(new_n224_), .C(new_n197_), .Y(new_n243_));
  OA21x2_ASAP7_75t_R   g157(.A1(new_n227_), .A2(new_n198_), .B(new_n228_), .Y(new_n244_));
  AND2x2_ASAP7_75t_R   g158(.A(new_n168_), .B(new_n117_), .Y(new_n245_));
  AO22x1_ASAP7_75t_R   g159(.A1(p41), .A2(p55), .B1(p25), .B2(p49), .Y(new_n246_));
  AOI21x1_ASAP7_75t_R  g160(.A1(p35), .A2(new_n245_), .B(new_n246_), .Y(new_n247_));
  OA21x2_ASAP7_75t_R   g161(.A1(new_n200_), .A2(new_n244_), .B(new_n247_), .Y(new_n248_));
  NAND2x1_ASAP7_75t_R  g162(.A(new_n243_), .B(new_n248_), .Y(new_n249_));
  AOI21x1_ASAP7_75t_R  g163(.A1(new_n240_), .A2(new_n242_), .B(new_n249_), .Y(o19));
  OA21x2_ASAP7_75t_R   g164(.A1(new_n212_), .A2(new_n211_), .B(new_n192_), .Y(new_n251_));
  XOR2x2_ASAP7_75t_R   g165(.A(new_n251_), .B(new_n220_), .Y(new_n252_));
  AO21x1_ASAP7_75t_R   g166(.A1(p48), .A2(new_n234_), .B(new_n245_), .Y(new_n253_));
  AO22x1_ASAP7_75t_R   g167(.A1(p41), .A2(p56), .B1(p26), .B2(p49), .Y(new_n254_));
  AO21x1_ASAP7_75t_R   g168(.A1(p43), .A2(new_n234_), .B(new_n254_), .Y(new_n255_));
  AO21x1_ASAP7_75t_R   g169(.A1(p47), .A2(new_n251_), .B(new_n255_), .Y(new_n256_));
  AO21x1_ASAP7_75t_R   g170(.A1(p36), .A2(new_n253_), .B(new_n256_), .Y(new_n257_));
  AOI21x1_ASAP7_75t_R  g171(.A1(p50), .A2(new_n252_), .B(new_n257_), .Y(o20));
  INVx1_ASAP7_75t_R    g172(.A(p23), .Y(new_n259_));
  AO21x1_ASAP7_75t_R   g173(.A1(new_n159_), .A2(new_n160_), .B(new_n259_), .Y(new_n260_));
  NOR3x1_ASAP7_75t_R   g174(.A(new_n88_), .B(p44), .C(new_n98_), .Y(new_n261_));
  AND2x2_ASAP7_75t_R   g175(.A(p16), .B(p53), .Y(new_n262_));
  AND2x2_ASAP7_75t_R   g176(.A(p6), .B(p57), .Y(new_n263_));
  AO31x2_ASAP7_75t_R   g177(.A1(new_n110_), .A2(new_n262_), .A3(new_n146_), .B(new_n263_), .Y(new_n264_));
  AOI211x1_ASAP7_75t_R g178(.A1(new_n141_), .A2(new_n261_), .B(p32), .C(new_n264_), .Y(new_n265_));
  INVx1_ASAP7_75t_R    g179(.A(p24), .Y(new_n266_));
  AO21x1_ASAP7_75t_R   g180(.A1(new_n159_), .A2(new_n160_), .B(new_n266_), .Y(new_n267_));
  AND2x2_ASAP7_75t_R   g181(.A(p16), .B(p45), .Y(new_n268_));
  AND2x2_ASAP7_75t_R   g182(.A(p58), .B(p57), .Y(new_n269_));
  AO31x2_ASAP7_75t_R   g183(.A1(new_n110_), .A2(new_n268_), .A3(new_n146_), .B(new_n269_), .Y(new_n270_));
  AOI211x1_ASAP7_75t_R g184(.A1(new_n141_), .A2(new_n261_), .B(p33), .C(new_n270_), .Y(new_n271_));
  AOI22x1_ASAP7_75t_R  g185(.A1(new_n260_), .A2(new_n265_), .B1(new_n267_), .B2(new_n271_), .Y(new_n272_));
  AND2x2_ASAP7_75t_R   g186(.A(p15), .B(p57), .Y(new_n273_));
  AOI211x1_ASAP7_75t_R g187(.A1(new_n141_), .A2(new_n261_), .B(p31), .C(new_n273_), .Y(new_n274_));
  NAND2x1_ASAP7_75t_R  g188(.A(new_n98_), .B(new_n87_), .Y(new_n275_));
  AND2x2_ASAP7_75t_R   g189(.A(p46), .B(p11), .Y(new_n276_));
  NAND2x1_ASAP7_75t_R  g190(.A(p6), .B(p59), .Y(new_n277_));
  AND4x2_ASAP7_75t_R   g191(.A(new_n275_), .B(new_n110_), .C(new_n276_), .D(new_n277_), .Y(new_n278_));
  AND3x1_ASAP7_75t_R   g192(.A(new_n158_), .B(p22), .C(new_n157_), .Y(new_n279_));
  AND2x2_ASAP7_75t_R   g193(.A(p16), .B(p54), .Y(new_n280_));
  AND3x1_ASAP7_75t_R   g194(.A(new_n110_), .B(new_n280_), .C(new_n146_), .Y(new_n281_));
  AOI211x1_ASAP7_75t_R g195(.A1(p22), .A2(new_n278_), .B(new_n279_), .C(new_n281_), .Y(new_n282_));
  NAND2x1_ASAP7_75t_R  g196(.A(new_n274_), .B(new_n282_), .Y(new_n283_));
  NAND3x1_ASAP7_75t_R  g197(.A(new_n181_), .B(new_n272_), .C(new_n283_), .Y(new_n284_));
  AO31x2_ASAP7_75t_R   g198(.A1(new_n214_), .A2(new_n185_), .A3(new_n201_), .B(new_n284_), .Y(new_n285_));
  NAND2x1_ASAP7_75t_R  g199(.A(new_n141_), .B(new_n261_), .Y(new_n286_));
  AND3x1_ASAP7_75t_R   g200(.A(new_n146_), .B(p16), .C(p52), .Y(new_n287_));
  AOI22x1_ASAP7_75t_R  g201(.A1(new_n287_), .A2(new_n110_), .B1(p57), .B2(p8), .Y(new_n288_));
  AND2x2_ASAP7_75t_R   g202(.A(new_n286_), .B(new_n288_), .Y(new_n289_));
  NAND2x1_ASAP7_75t_R  g203(.A(p21), .B(new_n177_), .Y(new_n290_));
  INVx1_ASAP7_75t_R    g204(.A(p30), .Y(new_n291_));
  AO21x1_ASAP7_75t_R   g205(.A1(new_n289_), .A2(new_n290_), .B(new_n291_), .Y(new_n292_));
  AOI22x1_ASAP7_75t_R  g206(.A1(new_n282_), .A2(new_n274_), .B1(new_n260_), .B2(new_n265_), .Y(new_n293_));
  AND3x1_ASAP7_75t_R   g207(.A(new_n146_), .B(p16), .C(p53), .Y(new_n294_));
  AOI21x1_ASAP7_75t_R  g208(.A1(new_n110_), .A2(new_n294_), .B(new_n263_), .Y(new_n295_));
  NAND3x1_ASAP7_75t_R  g209(.A(new_n145_), .B(new_n147_), .C(p23), .Y(new_n296_));
  OR4x2_ASAP7_75t_R    g210(.A(new_n138_), .B(new_n259_), .C(new_n97_), .D(new_n139_), .Y(new_n297_));
  AND4x2_ASAP7_75t_R   g211(.A(new_n295_), .B(new_n296_), .C(new_n286_), .D(new_n297_), .Y(new_n298_));
  INVx1_ASAP7_75t_R    g212(.A(p32), .Y(new_n299_));
  AOI21x1_ASAP7_75t_R  g213(.A1(new_n141_), .A2(new_n261_), .B(new_n269_), .Y(new_n300_));
  NAND3x1_ASAP7_75t_R  g214(.A(new_n145_), .B(new_n147_), .C(p24), .Y(new_n301_));
  OR4x2_ASAP7_75t_R    g215(.A(new_n138_), .B(new_n266_), .C(new_n97_), .D(new_n139_), .Y(new_n302_));
  NAND3x1_ASAP7_75t_R  g216(.A(new_n110_), .B(new_n268_), .C(new_n146_), .Y(new_n303_));
  AND4x2_ASAP7_75t_R   g217(.A(new_n300_), .B(new_n301_), .C(new_n302_), .D(new_n303_), .Y(new_n304_));
  INVx1_ASAP7_75t_R    g218(.A(p33), .Y(new_n305_));
  OAI22x1_ASAP7_75t_R  g219(.A1(new_n298_), .A2(new_n299_), .B1(new_n304_), .B2(new_n305_), .Y(new_n306_));
  AOI211x1_ASAP7_75t_R g220(.A1(new_n141_), .A2(new_n261_), .B(new_n273_), .C(new_n281_), .Y(new_n307_));
  AOI21x1_ASAP7_75t_R  g221(.A1(p22), .A2(new_n278_), .B(new_n279_), .Y(new_n308_));
  INVx1_ASAP7_75t_R    g222(.A(p31), .Y(new_n309_));
  AOI21x1_ASAP7_75t_R  g223(.A1(new_n307_), .A2(new_n308_), .B(new_n309_), .Y(new_n310_));
  AOI21x1_ASAP7_75t_R  g224(.A1(new_n293_), .A2(new_n306_), .B(new_n310_), .Y(new_n311_));
  AND2x2_ASAP7_75t_R   g225(.A(new_n292_), .B(new_n311_), .Y(new_n312_));
  AND3x1_ASAP7_75t_R   g226(.A(new_n290_), .B(new_n291_), .C(new_n289_), .Y(new_n313_));
  AO21x1_ASAP7_75t_R   g227(.A1(new_n285_), .A2(new_n312_), .B(new_n313_), .Y(o21));
  NAND2x1_ASAP7_75t_R  g228(.A(new_n271_), .B(new_n267_), .Y(new_n315_));
  NAND2x1_ASAP7_75t_R  g229(.A(new_n302_), .B(new_n301_), .Y(new_n316_));
  NAND2x1_ASAP7_75t_R  g230(.A(new_n303_), .B(new_n300_), .Y(new_n317_));
  OAI21x1_ASAP7_75t_R  g231(.A1(new_n316_), .A2(new_n317_), .B(p33), .Y(new_n318_));
  NAND2x1_ASAP7_75t_R  g232(.A(new_n315_), .B(new_n318_), .Y(new_n319_));
  NAND2x1_ASAP7_75t_R  g233(.A(new_n185_), .B(new_n319_), .Y(new_n320_));
  AOI21x1_ASAP7_75t_R  g234(.A1(new_n181_), .A2(new_n222_), .B(new_n320_), .Y(new_n321_));
  AOI21x1_ASAP7_75t_R  g235(.A1(new_n182_), .A2(new_n183_), .B(new_n184_), .Y(new_n322_));
  AOI211x1_ASAP7_75t_R g236(.A1(p25), .A2(new_n177_), .B(new_n178_), .C(new_n180_), .Y(new_n323_));
  OAI22x1_ASAP7_75t_R  g237(.A1(new_n209_), .A2(new_n210_), .B1(new_n212_), .B2(new_n211_), .Y(new_n324_));
  AOI211x1_ASAP7_75t_R g238(.A1(new_n217_), .A2(new_n219_), .B(new_n323_), .C(new_n324_), .Y(new_n325_));
  AOI211x1_ASAP7_75t_R g239(.A1(new_n181_), .A2(new_n221_), .B(new_n322_), .C(new_n325_), .Y(new_n326_));
  NOR2x1_ASAP7_75t_R   g240(.A(new_n319_), .B(new_n326_), .Y(new_n327_));
  AOI22x1_ASAP7_75t_R  g241(.A1(new_n245_), .A2(p33), .B1(p23), .B2(p49), .Y(new_n328_));
  OA21x2_ASAP7_75t_R   g242(.A1(new_n228_), .A2(new_n304_), .B(new_n328_), .Y(new_n329_));
  NAND3x1_ASAP7_75t_R  g243(.A(new_n318_), .B(new_n315_), .C(p47), .Y(new_n330_));
  OR3x1_ASAP7_75t_R    g244(.A(new_n304_), .B(new_n305_), .C(new_n227_), .Y(new_n331_));
  AND3x1_ASAP7_75t_R   g245(.A(new_n329_), .B(new_n330_), .C(new_n331_), .Y(new_n332_));
  OA31x2_ASAP7_75t_R   g246(.A1(new_n176_), .A2(new_n321_), .A3(new_n327_), .B1(new_n332_), .Y(o22));
  NAND2x1_ASAP7_75t_R  g247(.A(new_n283_), .B(new_n272_), .Y(new_n334_));
  NAND3x1_ASAP7_75t_R  g248(.A(new_n290_), .B(new_n289_), .C(new_n291_), .Y(new_n335_));
  NAND2x1_ASAP7_75t_R  g249(.A(new_n335_), .B(new_n292_), .Y(new_n336_));
  OR3x1_ASAP7_75t_R    g250(.A(new_n326_), .B(new_n334_), .C(new_n336_), .Y(new_n337_));
  AO21x1_ASAP7_75t_R   g251(.A1(new_n293_), .A2(new_n306_), .B(new_n310_), .Y(new_n338_));
  AOI21x1_ASAP7_75t_R  g252(.A1(new_n292_), .A2(new_n335_), .B(new_n338_), .Y(new_n339_));
  OAI21x1_ASAP7_75t_R  g253(.A1(new_n336_), .A2(new_n311_), .B(p50), .Y(new_n340_));
  AOI21x1_ASAP7_75t_R  g254(.A1(new_n285_), .A2(new_n339_), .B(new_n340_), .Y(new_n341_));
  AO21x1_ASAP7_75t_R   g255(.A1(new_n289_), .A2(new_n290_), .B(new_n228_), .Y(new_n342_));
  AOI22x1_ASAP7_75t_R  g256(.A1(new_n245_), .A2(p30), .B1(p44), .B2(p49), .Y(new_n343_));
  OA211x2_ASAP7_75t_R  g257(.A1(new_n227_), .A2(new_n292_), .B(new_n342_), .C(new_n343_), .Y(new_n344_));
  OAI21x1_ASAP7_75t_R  g258(.A1(new_n224_), .A2(new_n336_), .B(new_n344_), .Y(new_n345_));
  AOI21x1_ASAP7_75t_R  g259(.A1(new_n337_), .A2(new_n341_), .B(new_n345_), .Y(o23));
  INVx1_ASAP7_75t_R    g260(.A(new_n272_), .Y(new_n347_));
  AOI21x1_ASAP7_75t_R  g261(.A1(new_n282_), .A2(new_n274_), .B(new_n310_), .Y(new_n348_));
  NAND2x1_ASAP7_75t_R  g262(.A(new_n297_), .B(new_n296_), .Y(new_n349_));
  AO21x1_ASAP7_75t_R   g263(.A1(new_n141_), .A2(new_n261_), .B(new_n264_), .Y(new_n350_));
  OAI21x1_ASAP7_75t_R  g264(.A1(new_n349_), .A2(new_n350_), .B(p32), .Y(new_n351_));
  AND3x1_ASAP7_75t_R   g265(.A(new_n265_), .B(new_n297_), .C(new_n296_), .Y(new_n352_));
  AOI21x1_ASAP7_75t_R  g266(.A1(new_n318_), .A2(new_n351_), .B(new_n352_), .Y(new_n353_));
  NOR2x1_ASAP7_75t_R   g267(.A(new_n348_), .B(new_n353_), .Y(new_n354_));
  OAI21x1_ASAP7_75t_R  g268(.A1(new_n347_), .A2(new_n326_), .B(new_n354_), .Y(new_n355_));
  INVx1_ASAP7_75t_R    g269(.A(new_n348_), .Y(new_n356_));
  AOI21x1_ASAP7_75t_R  g270(.A1(new_n348_), .A2(new_n353_), .B(new_n176_), .Y(new_n357_));
  OA31x2_ASAP7_75t_R   g271(.A1(new_n347_), .A2(new_n356_), .A3(new_n326_), .B1(new_n357_), .Y(new_n358_));
  NAND2x1_ASAP7_75t_R  g272(.A(p48), .B(new_n310_), .Y(new_n359_));
  AO21x1_ASAP7_75t_R   g273(.A1(new_n307_), .A2(new_n308_), .B(new_n228_), .Y(new_n360_));
  AOI22x1_ASAP7_75t_R  g274(.A1(new_n245_), .A2(p31), .B1(p21), .B2(p49), .Y(new_n361_));
  AND3x1_ASAP7_75t_R   g275(.A(new_n359_), .B(new_n360_), .C(new_n361_), .Y(new_n362_));
  OAI21x1_ASAP7_75t_R  g276(.A1(new_n224_), .A2(new_n356_), .B(new_n362_), .Y(new_n363_));
  AOI21x1_ASAP7_75t_R  g277(.A1(new_n355_), .A2(new_n358_), .B(new_n363_), .Y(o24));
  XOR2x2_ASAP7_75t_R   g278(.A(new_n298_), .B(p32), .Y(new_n365_));
  AO21x1_ASAP7_75t_R   g279(.A1(new_n267_), .A2(new_n271_), .B(new_n365_), .Y(new_n366_));
  AO21x1_ASAP7_75t_R   g280(.A1(new_n318_), .A2(new_n326_), .B(new_n366_), .Y(new_n367_));
  AND2x2_ASAP7_75t_R   g281(.A(new_n318_), .B(new_n365_), .Y(new_n368_));
  NAND2x1_ASAP7_75t_R  g282(.A(new_n315_), .B(new_n181_), .Y(new_n369_));
  AO31x2_ASAP7_75t_R   g283(.A1(new_n214_), .A2(new_n185_), .A3(new_n201_), .B(new_n369_), .Y(new_n370_));
  AOI21x1_ASAP7_75t_R  g284(.A1(new_n368_), .A2(new_n370_), .B(new_n176_), .Y(new_n371_));
  AOI22x1_ASAP7_75t_R  g285(.A1(new_n245_), .A2(p32), .B1(p49), .B2(p22), .Y(new_n372_));
  OA21x2_ASAP7_75t_R   g286(.A1(new_n228_), .A2(new_n298_), .B(new_n372_), .Y(new_n373_));
  OA21x2_ASAP7_75t_R   g287(.A1(new_n227_), .A2(new_n351_), .B(new_n373_), .Y(new_n374_));
  OAI21x1_ASAP7_75t_R  g288(.A1(new_n224_), .A2(new_n365_), .B(new_n374_), .Y(new_n375_));
  AOI21x1_ASAP7_75t_R  g289(.A1(new_n367_), .A2(new_n371_), .B(new_n375_), .Y(o25));
endmodule


