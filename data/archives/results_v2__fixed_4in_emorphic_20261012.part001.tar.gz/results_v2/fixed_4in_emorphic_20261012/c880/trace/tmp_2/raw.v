// Benchmark "/tmp/" written by ABC on Mon Oct 12 15:07:53 2026

module \/tmp/  ( 
    p20, p8, p29, p17, p38, p49, p26, p32, p59, p1, p56, p15, p19, p39,
    p31, p11, p27, p43, p44, p12, p9, p23, p28, p42, p0, p13, p24, p33,
    p10, p40, p37, p6, p45, p3, p21, p14, p53, p47, p55, p25, p52, p4, p30,
    p35, p22, p46, p36, p34, p57, p16, p18, p41, p5, p7, p58, p54, p2, p50,
    p48, p51,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25  );
  input  p20, p8, p29, p17, p38, p49, p26, p32, p59, p1, p56, p15, p19,
    p39, p31, p11, p27, p43, p44, p12, p9, p23, p28, p42, p0, p13, p24,
    p33, p10, p40, p37, p6, p45, p3, p21, p14, p53, p47, p55, p25, p52, p4,
    p30, p35, p22, p46, p36, p34, p57, p16, p18, p41, p5, p7, p58, p54, p2,
    p50, p48, p51;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25;
  wire new_n87_, new_n89_, new_n90_, new_n91_, new_n93_, new_n96_, new_n97_,
    new_n99_, new_n107_, new_n109_, new_n112_, new_n113_, new_n114_,
    new_n115_, new_n116_, new_n117_, new_n118_, new_n119_, new_n121_,
    new_n122_, new_n123_, new_n124_, new_n125_, new_n126_, new_n127_,
    new_n128_, new_n130_, new_n131_, new_n132_, new_n133_, new_n134_,
    new_n135_, new_n136_, new_n137_, new_n138_, new_n139_, new_n140_,
    new_n141_, new_n142_, new_n143_, new_n144_, new_n145_, new_n146_,
    new_n147_, new_n148_, new_n149_, new_n150_, new_n151_, new_n152_,
    new_n153_, new_n154_, new_n155_, new_n156_, new_n157_, new_n158_,
    new_n159_, new_n160_, new_n161_, new_n162_, new_n163_, new_n164_,
    new_n165_, new_n166_, new_n167_, new_n168_, new_n169_, new_n170_,
    new_n171_, new_n172_, new_n173_, new_n174_, new_n175_, new_n176_,
    new_n177_, new_n178_, new_n179_, new_n180_, new_n181_, new_n182_,
    new_n183_, new_n184_, new_n185_, new_n187_, new_n188_, new_n189_,
    new_n190_, new_n191_, new_n192_, new_n193_, new_n194_, new_n195_,
    new_n196_, new_n197_, new_n198_, new_n199_, new_n200_, new_n201_,
    new_n202_, new_n203_, new_n204_, new_n205_, new_n206_, new_n207_,
    new_n208_, new_n209_, new_n210_, new_n211_, new_n212_, new_n213_,
    new_n214_, new_n215_, new_n216_, new_n217_, new_n218_, new_n219_,
    new_n220_, new_n221_, new_n222_, new_n223_, new_n224_, new_n225_,
    new_n226_, new_n227_, new_n228_, new_n229_, new_n230_, new_n231_,
    new_n232_, new_n233_, new_n234_, new_n235_, new_n236_, new_n237_,
    new_n238_, new_n239_, new_n240_, new_n241_, new_n242_, new_n243_,
    new_n245_, new_n246_, new_n247_, new_n248_, new_n249_, new_n250_,
    new_n251_, new_n252_, new_n253_, new_n254_, new_n255_, new_n256_,
    new_n257_, new_n259_, new_n260_, new_n261_, new_n262_, new_n263_,
    new_n264_, new_n265_, new_n266_, new_n267_, new_n268_, new_n269_,
    new_n270_, new_n271_, new_n273_, new_n274_, new_n275_, new_n276_,
    new_n277_, new_n278_, new_n279_, new_n280_, new_n281_, new_n282_,
    new_n283_, new_n284_, new_n285_, new_n286_, new_n287_, new_n288_,
    new_n289_, new_n290_, new_n291_, new_n292_, new_n293_, new_n294_,
    new_n295_, new_n296_, new_n297_, new_n298_, new_n299_, new_n300_,
    new_n301_, new_n302_, new_n303_, new_n304_, new_n305_, new_n306_,
    new_n307_, new_n308_, new_n309_, new_n310_, new_n311_, new_n312_,
    new_n313_, new_n314_, new_n315_, new_n316_, new_n317_, new_n318_,
    new_n319_, new_n320_, new_n322_, new_n323_, new_n324_, new_n325_,
    new_n326_, new_n327_, new_n328_, new_n329_, new_n330_, new_n331_,
    new_n332_, new_n333_, new_n334_, new_n336_, new_n337_, new_n338_,
    new_n339_, new_n340_, new_n341_, new_n342_, new_n343_, new_n344_,
    new_n345_, new_n346_, new_n347_, new_n348_, new_n349_, new_n350_,
    new_n351_, new_n352_, new_n353_, new_n354_, new_n356_, new_n357_,
    new_n358_, new_n359_, new_n360_, new_n361_, new_n362_, new_n363_,
    new_n364_, new_n365_, new_n366_, new_n367_, new_n368_, new_n369_,
    new_n370_, new_n371_, new_n372_, new_n373_, new_n375_, new_n376_,
    new_n377_, new_n378_, new_n379_, new_n380_, new_n381_, new_n382_,
    new_n383_, new_n384_, new_n385_, new_n386_, new_n387_;
  AND2x2_ASAP7_75t_R   g000(.A(p1), .B(p0), .Y(new_n87_));
  NAND2x1_ASAP7_75t_R  g001(.A(p59), .B(new_n87_), .Y(o0));
  INVx1_ASAP7_75t_R    g002(.A(p1), .Y(new_n89_));
  INVx1_ASAP7_75t_R    g003(.A(p3), .Y(new_n90_));
  INVx1_ASAP7_75t_R    g004(.A(p2), .Y(new_n91_));
  OR3x1_ASAP7_75t_R    g005(.A(new_n89_), .B(new_n90_), .C(new_n91_), .Y(o1));
  AND3x1_ASAP7_75t_R   g006(.A(p59), .B(p1), .C(p3), .Y(new_n93_));
  INVx1_ASAP7_75t_R    g007(.A(new_n93_), .Y(o2));
  NAND2x1_ASAP7_75t_R  g008(.A(p4), .B(p5), .Y(o3));
  AND2x2_ASAP7_75t_R   g009(.A(p8), .B(p9), .Y(new_n96_));
  AND2x2_ASAP7_75t_R   g010(.A(p6), .B(p7), .Y(new_n97_));
  NAND2x1_ASAP7_75t_R  g011(.A(new_n96_), .B(new_n97_), .Y(o4));
  AND2x2_ASAP7_75t_R   g012(.A(p9), .B(p10), .Y(new_n99_));
  AND3x1_ASAP7_75t_R   g013(.A(o2), .B(new_n97_), .C(new_n99_), .Y(o5));
  AND3x1_ASAP7_75t_R   g014(.A(p11), .B(p0), .C(p2), .Y(o6));
  AND3x1_ASAP7_75t_R   g015(.A(p11), .B(p3), .C(p2), .Y(o7));
  AND3x1_ASAP7_75t_R   g016(.A(p59), .B(p11), .C(p3), .Y(o8));
  OAI21x1_ASAP7_75t_R  g017(.A1(p13), .A2(p14), .B(p12), .Y(o9));
  AND3x1_ASAP7_75t_R   g018(.A(new_n93_), .B(new_n97_), .C(new_n99_), .Y(o10));
  NAND3x1_ASAP7_75t_R  g019(.A(p15), .B(p9), .C(p10), .Y(o11));
  AND3x1_ASAP7_75t_R   g020(.A(new_n96_), .B(p16), .C(p7), .Y(new_n107_));
  NAND3x1_ASAP7_75t_R  g021(.A(new_n107_), .B(p17), .C(p1), .Y(o12));
  AND3x1_ASAP7_75t_R   g022(.A(new_n107_), .B(p17), .C(p11), .Y(new_n109_));
  NAND2x1_ASAP7_75t_R  g023(.A(p18), .B(new_n109_), .Y(o13));
  OAI21x1_ASAP7_75t_R  g024(.A1(p13), .A2(p14), .B(p19), .Y(o14));
  XNOR2x2_ASAP7_75t_R  g025(.A(p23), .B(p24), .Y(new_n112_));
  XOR2x2_ASAP7_75t_R   g026(.A(p27), .B(p28), .Y(new_n113_));
  XOR2x2_ASAP7_75t_R   g027(.A(new_n112_), .B(new_n113_), .Y(new_n114_));
  XOR2x2_ASAP7_75t_R   g028(.A(p29), .B(p26), .Y(new_n115_));
  XOR2x2_ASAP7_75t_R   g029(.A(new_n115_), .B(p25), .Y(new_n116_));
  XOR2x2_ASAP7_75t_R   g030(.A(new_n114_), .B(new_n116_), .Y(new_n117_));
  XOR2x2_ASAP7_75t_R   g031(.A(p20), .B(p21), .Y(new_n118_));
  XOR2x2_ASAP7_75t_R   g032(.A(new_n118_), .B(p22), .Y(new_n119_));
  XOR2x2_ASAP7_75t_R   g033(.A(new_n117_), .B(new_n119_), .Y(o15));
  XOR2x2_ASAP7_75t_R   g034(.A(p32), .B(p33), .Y(new_n121_));
  XOR2x2_ASAP7_75t_R   g035(.A(p31), .B(p30), .Y(new_n122_));
  XOR2x2_ASAP7_75t_R   g036(.A(new_n121_), .B(new_n122_), .Y(new_n123_));
  XNOR2x2_ASAP7_75t_R  g037(.A(p37), .B(p36), .Y(new_n124_));
  XOR2x2_ASAP7_75t_R   g038(.A(new_n123_), .B(new_n124_), .Y(new_n125_));
  XNOR2x2_ASAP7_75t_R  g039(.A(p35), .B(p34), .Y(new_n126_));
  XNOR2x2_ASAP7_75t_R  g040(.A(p20), .B(p38), .Y(new_n127_));
  XOR2x2_ASAP7_75t_R   g041(.A(new_n126_), .B(new_n127_), .Y(new_n128_));
  XOR2x2_ASAP7_75t_R   g042(.A(new_n125_), .B(new_n128_), .Y(o16));
  INVx1_ASAP7_75t_R    g043(.A(p51), .Y(new_n130_));
  NAND2x1_ASAP7_75t_R  g044(.A(p59), .B(p6), .Y(new_n131_));
  AND2x2_ASAP7_75t_R   g045(.A(p11), .B(p46), .Y(new_n132_));
  NAND2x1_ASAP7_75t_R  g046(.A(new_n131_), .B(new_n132_), .Y(new_n133_));
  AND3x1_ASAP7_75t_R   g047(.A(p15), .B(p9), .C(p10), .Y(new_n134_));
  OAI21x1_ASAP7_75t_R  g048(.A1(p59), .A2(p6), .B(new_n134_), .Y(new_n135_));
  AND2x2_ASAP7_75t_R   g049(.A(p15), .B(p6), .Y(new_n136_));
  NAND3x1_ASAP7_75t_R  g050(.A(p59), .B(p11), .C(p0), .Y(new_n137_));
  NAND3x1_ASAP7_75t_R  g051(.A(new_n96_), .B(new_n136_), .C(new_n137_), .Y(new_n138_));
  OAI21x1_ASAP7_75t_R  g052(.A1(new_n133_), .A2(new_n135_), .B(new_n138_), .Y(new_n139_));
  NAND2x1_ASAP7_75t_R  g053(.A(p11), .B(p46), .Y(new_n140_));
  AND2x2_ASAP7_75t_R   g054(.A(p15), .B(p10), .Y(new_n141_));
  INVx1_ASAP7_75t_R    g055(.A(p9), .Y(new_n142_));
  AOI21x1_ASAP7_75t_R  g056(.A1(new_n140_), .A2(new_n141_), .B(new_n142_), .Y(new_n143_));
  INVx1_ASAP7_75t_R    g057(.A(p6), .Y(new_n144_));
  INVx1_ASAP7_75t_R    g058(.A(p45), .Y(new_n145_));
  AO21x1_ASAP7_75t_R   g059(.A1(p9), .A2(new_n144_), .B(new_n145_), .Y(new_n146_));
  NAND2x1_ASAP7_75t_R  g060(.A(p2), .B(new_n134_), .Y(new_n147_));
  NAND2x1_ASAP7_75t_R  g061(.A(p1), .B(p0), .Y(new_n148_));
  INVx1_ASAP7_75t_R    g062(.A(p16), .Y(new_n149_));
  OR3x1_ASAP7_75t_R    g063(.A(new_n148_), .B(p44), .C(new_n149_), .Y(new_n150_));
  OAI22x1_ASAP7_75t_R  g064(.A1(new_n143_), .A2(new_n146_), .B1(new_n147_), .B2(new_n150_), .Y(new_n151_));
  AOI21x1_ASAP7_75t_R  g065(.A1(p28), .A2(new_n139_), .B(new_n151_), .Y(new_n152_));
  INVx1_ASAP7_75t_R    g066(.A(new_n152_), .Y(new_n153_));
  NAND2x1_ASAP7_75t_R  g067(.A(p9), .B(p10), .Y(new_n154_));
  NAND2x1_ASAP7_75t_R  g068(.A(p15), .B(p6), .Y(new_n155_));
  AOI211x1_ASAP7_75t_R g069(.A1(p11), .A2(p46), .B(new_n154_), .C(new_n155_), .Y(new_n156_));
  AO21x1_ASAP7_75t_R   g070(.A1(p45), .A2(new_n142_), .B(p37), .Y(new_n157_));
  AOI21x1_ASAP7_75t_R  g071(.A1(p45), .A2(new_n156_), .B(new_n157_), .Y(new_n158_));
  NOR2x1_ASAP7_75t_R   g072(.A(p59), .B(p6), .Y(new_n159_));
  NOR2x1_ASAP7_75t_R   g073(.A(new_n159_), .B(o11), .Y(new_n160_));
  AOI21x1_ASAP7_75t_R  g074(.A1(p59), .A2(p6), .B(new_n140_), .Y(new_n161_));
  NAND3x1_ASAP7_75t_R  g075(.A(new_n160_), .B(p28), .C(new_n161_), .Y(new_n162_));
  NOR2x1_ASAP7_75t_R   g076(.A(p44), .B(new_n149_), .Y(new_n163_));
  AND4x2_ASAP7_75t_R   g077(.A(p15), .B(p9), .C(p10), .D(p2), .Y(new_n164_));
  NAND3x1_ASAP7_75t_R  g078(.A(new_n163_), .B(new_n164_), .C(new_n87_), .Y(new_n165_));
  NAND2x1_ASAP7_75t_R  g079(.A(p8), .B(p9), .Y(new_n166_));
  NOR2x1_ASAP7_75t_R   g080(.A(new_n166_), .B(new_n155_), .Y(new_n167_));
  NAND3x1_ASAP7_75t_R  g081(.A(new_n167_), .B(p28), .C(new_n137_), .Y(new_n168_));
  AND4x2_ASAP7_75t_R   g082(.A(new_n158_), .B(new_n162_), .C(new_n165_), .D(new_n168_), .Y(new_n169_));
  AO21x1_ASAP7_75t_R   g083(.A1(p37), .A2(new_n153_), .B(new_n169_), .Y(new_n170_));
  NOR2x1_ASAP7_75t_R   g084(.A(new_n130_), .B(new_n170_), .Y(new_n171_));
  INVx1_ASAP7_75t_R    g085(.A(p50), .Y(new_n172_));
  AO21x1_ASAP7_75t_R   g086(.A1(new_n130_), .A2(new_n170_), .B(new_n172_), .Y(new_n173_));
  INVx1_ASAP7_75t_R    g087(.A(new_n151_), .Y(new_n174_));
  NAND2x1_ASAP7_75t_R  g088(.A(p28), .B(new_n139_), .Y(new_n175_));
  INVx1_ASAP7_75t_R    g089(.A(p37), .Y(new_n176_));
  AOI21x1_ASAP7_75t_R  g090(.A1(new_n174_), .A2(new_n175_), .B(new_n176_), .Y(new_n177_));
  INVx1_ASAP7_75t_R    g091(.A(p47), .Y(new_n178_));
  OR3x1_ASAP7_75t_R    g092(.A(new_n177_), .B(new_n178_), .C(new_n169_), .Y(new_n179_));
  AO21x1_ASAP7_75t_R   g093(.A1(p37), .A2(p48), .B(p43), .Y(new_n180_));
  AND3x1_ASAP7_75t_R   g094(.A(p59), .B(p39), .C(p40), .Y(new_n181_));
  AND2x2_ASAP7_75t_R   g095(.A(new_n181_), .B(new_n109_), .Y(new_n182_));
  AO22x1_ASAP7_75t_R   g096(.A1(p49), .A2(p27), .B1(p42), .B2(p41), .Y(new_n183_));
  AO21x1_ASAP7_75t_R   g097(.A1(p37), .A2(new_n182_), .B(new_n183_), .Y(new_n184_));
  AOI21x1_ASAP7_75t_R  g098(.A1(new_n153_), .A2(new_n180_), .B(new_n184_), .Y(new_n185_));
  OA211x2_ASAP7_75t_R  g099(.A1(new_n171_), .A2(new_n173_), .B(new_n179_), .C(new_n185_), .Y(o17));
  OA21x2_ASAP7_75t_R   g100(.A1(p6), .A2(new_n142_), .B(p52), .Y(new_n187_));
  AO21x1_ASAP7_75t_R   g101(.A1(new_n140_), .A2(new_n141_), .B(new_n142_), .Y(new_n188_));
  NAND2x1_ASAP7_75t_R  g102(.A(new_n187_), .B(new_n188_), .Y(new_n189_));
  INVx1_ASAP7_75t_R    g103(.A(p25), .Y(new_n190_));
  AND3x1_ASAP7_75t_R   g104(.A(new_n96_), .B(new_n136_), .C(new_n137_), .Y(new_n191_));
  AOI21x1_ASAP7_75t_R  g105(.A1(new_n161_), .A2(new_n160_), .B(new_n191_), .Y(new_n192_));
  OA21x2_ASAP7_75t_R   g106(.A1(new_n190_), .A2(new_n192_), .B(new_n165_), .Y(new_n193_));
  INVx1_ASAP7_75t_R    g107(.A(p34), .Y(new_n194_));
  AO21x1_ASAP7_75t_R   g108(.A1(new_n189_), .A2(new_n193_), .B(new_n194_), .Y(new_n195_));
  AND3x1_ASAP7_75t_R   g109(.A(new_n163_), .B(new_n164_), .C(new_n87_), .Y(new_n196_));
  AO21x1_ASAP7_75t_R   g110(.A1(new_n187_), .A2(new_n188_), .B(p34), .Y(new_n197_));
  AO211x2_ASAP7_75t_R  g111(.A1(p25), .A2(new_n139_), .B(new_n196_), .C(new_n197_), .Y(new_n198_));
  INVx1_ASAP7_75t_R    g112(.A(p53), .Y(new_n199_));
  AO21x1_ASAP7_75t_R   g113(.A1(p9), .A2(new_n144_), .B(new_n199_), .Y(new_n200_));
  OA22x2_ASAP7_75t_R   g114(.A1(new_n143_), .A2(new_n200_), .B1(new_n147_), .B2(new_n150_), .Y(new_n201_));
  OA21x2_ASAP7_75t_R   g115(.A1(p59), .A2(p6), .B(p15), .Y(new_n202_));
  AND4x2_ASAP7_75t_R   g116(.A(new_n202_), .B(new_n99_), .C(new_n132_), .D(new_n131_), .Y(new_n203_));
  OAI21x1_ASAP7_75t_R  g117(.A1(new_n191_), .A2(new_n203_), .B(p27), .Y(new_n204_));
  INVx1_ASAP7_75t_R    g118(.A(p36), .Y(new_n205_));
  AOI21x1_ASAP7_75t_R  g119(.A1(new_n201_), .A2(new_n204_), .B(new_n205_), .Y(new_n206_));
  OAI21x1_ASAP7_75t_R  g120(.A1(new_n191_), .A2(new_n203_), .B(p26), .Y(new_n207_));
  OAI21x1_ASAP7_75t_R  g121(.A1(p6), .A2(new_n142_), .B(p54), .Y(new_n208_));
  OA21x2_ASAP7_75t_R   g122(.A1(new_n143_), .A2(new_n208_), .B(new_n165_), .Y(new_n209_));
  INVx1_ASAP7_75t_R    g123(.A(p35), .Y(new_n210_));
  AOI21x1_ASAP7_75t_R  g124(.A1(new_n207_), .A2(new_n209_), .B(new_n210_), .Y(new_n211_));
  OA21x2_ASAP7_75t_R   g125(.A1(new_n208_), .A2(new_n143_), .B(new_n210_), .Y(new_n212_));
  AND3x1_ASAP7_75t_R   g126(.A(new_n167_), .B(p26), .C(new_n137_), .Y(new_n213_));
  AOI211x1_ASAP7_75t_R g127(.A1(p26), .A2(new_n203_), .B(new_n196_), .C(new_n213_), .Y(new_n214_));
  NAND2x1_ASAP7_75t_R  g128(.A(new_n212_), .B(new_n214_), .Y(new_n215_));
  OAI21x1_ASAP7_75t_R  g129(.A1(new_n206_), .A2(new_n211_), .B(new_n215_), .Y(new_n216_));
  AND3x1_ASAP7_75t_R   g130(.A(new_n160_), .B(p28), .C(new_n161_), .Y(new_n217_));
  AO21x1_ASAP7_75t_R   g131(.A1(p45), .A2(new_n156_), .B(new_n157_), .Y(new_n218_));
  INVx1_ASAP7_75t_R    g132(.A(p28), .Y(new_n219_));
  OAI21x1_ASAP7_75t_R  g133(.A1(new_n219_), .A2(new_n138_), .B(new_n165_), .Y(new_n220_));
  OA31x2_ASAP7_75t_R   g134(.A1(new_n217_), .A2(new_n218_), .A3(new_n220_), .B1(p51), .Y(new_n221_));
  AND3x1_ASAP7_75t_R   g135(.A(new_n167_), .B(p27), .C(new_n137_), .Y(new_n222_));
  AOI211x1_ASAP7_75t_R g136(.A1(p27), .A2(new_n203_), .B(new_n196_), .C(new_n222_), .Y(new_n223_));
  OA21x2_ASAP7_75t_R   g137(.A1(new_n200_), .A2(new_n143_), .B(new_n205_), .Y(new_n224_));
  AOI22x1_ASAP7_75t_R  g138(.A1(new_n212_), .A2(new_n214_), .B1(new_n223_), .B2(new_n224_), .Y(new_n225_));
  OAI21x1_ASAP7_75t_R  g139(.A1(new_n221_), .A2(new_n177_), .B(new_n225_), .Y(new_n226_));
  NAND2x1_ASAP7_75t_R  g140(.A(new_n216_), .B(new_n226_), .Y(new_n227_));
  AO21x1_ASAP7_75t_R   g141(.A1(new_n195_), .A2(new_n198_), .B(new_n227_), .Y(new_n228_));
  NOR2x1_ASAP7_75t_R   g142(.A(new_n190_), .B(new_n192_), .Y(new_n229_));
  AO21x1_ASAP7_75t_R   g143(.A1(new_n188_), .A2(new_n187_), .B(new_n196_), .Y(new_n230_));
  NOR3x1_ASAP7_75t_R   g144(.A(new_n229_), .B(p34), .C(new_n230_), .Y(new_n231_));
  OA21x2_ASAP7_75t_R   g145(.A1(new_n230_), .A2(new_n229_), .B(p34), .Y(new_n232_));
  NOR2x1_ASAP7_75t_R   g146(.A(new_n231_), .B(new_n232_), .Y(new_n233_));
  OAI22x1_ASAP7_75t_R  g147(.A1(new_n169_), .A2(new_n130_), .B1(new_n176_), .B2(new_n152_), .Y(new_n234_));
  AND3x1_ASAP7_75t_R   g148(.A(new_n233_), .B(new_n225_), .C(new_n234_), .Y(new_n235_));
  OA21x2_ASAP7_75t_R   g149(.A1(new_n206_), .A2(new_n211_), .B(new_n215_), .Y(new_n236_));
  AO21x1_ASAP7_75t_R   g150(.A1(new_n236_), .A2(new_n233_), .B(new_n172_), .Y(new_n237_));
  NOR2x1_ASAP7_75t_R   g151(.A(new_n235_), .B(new_n237_), .Y(new_n238_));
  AO21x1_ASAP7_75t_R   g152(.A1(p25), .A2(new_n139_), .B(new_n230_), .Y(new_n239_));
  AO21x1_ASAP7_75t_R   g153(.A1(p34), .A2(p48), .B(p43), .Y(new_n240_));
  AO22x1_ASAP7_75t_R   g154(.A1(p49), .A2(p24), .B1(p34), .B2(new_n182_), .Y(new_n241_));
  AO21x1_ASAP7_75t_R   g155(.A1(new_n239_), .A2(new_n240_), .B(new_n241_), .Y(new_n242_));
  AO21x1_ASAP7_75t_R   g156(.A1(p47), .A2(new_n233_), .B(new_n242_), .Y(new_n243_));
  AOI21x1_ASAP7_75t_R  g157(.A1(new_n228_), .A2(new_n238_), .B(new_n243_), .Y(o18));
  AOI21x1_ASAP7_75t_R  g158(.A1(new_n212_), .A2(new_n214_), .B(new_n211_), .Y(new_n245_));
  NAND2x1_ASAP7_75t_R  g159(.A(new_n224_), .B(new_n223_), .Y(new_n246_));
  AND2x2_ASAP7_75t_R   g160(.A(new_n246_), .B(new_n234_), .Y(new_n247_));
  AO21x1_ASAP7_75t_R   g161(.A1(new_n206_), .A2(new_n245_), .B(new_n172_), .Y(new_n248_));
  AOI21x1_ASAP7_75t_R  g162(.A1(new_n245_), .A2(new_n247_), .B(new_n248_), .Y(new_n249_));
  OR3x1_ASAP7_75t_R    g163(.A(new_n247_), .B(new_n206_), .C(new_n245_), .Y(new_n250_));
  OAI22x1_ASAP7_75t_R  g164(.A1(new_n143_), .A2(new_n208_), .B1(new_n147_), .B2(new_n150_), .Y(new_n251_));
  AO21x1_ASAP7_75t_R   g165(.A1(p26), .A2(new_n139_), .B(new_n251_), .Y(new_n252_));
  AO21x1_ASAP7_75t_R   g166(.A1(p48), .A2(new_n252_), .B(new_n182_), .Y(new_n253_));
  AO22x1_ASAP7_75t_R   g167(.A1(p49), .A2(p25), .B1(p55), .B2(p41), .Y(new_n254_));
  AO21x1_ASAP7_75t_R   g168(.A1(p43), .A2(new_n252_), .B(new_n254_), .Y(new_n255_));
  AO21x1_ASAP7_75t_R   g169(.A1(p47), .A2(new_n245_), .B(new_n255_), .Y(new_n256_));
  AO21x1_ASAP7_75t_R   g170(.A1(p35), .A2(new_n253_), .B(new_n256_), .Y(new_n257_));
  AOI21x1_ASAP7_75t_R  g171(.A1(new_n249_), .A2(new_n250_), .B(new_n257_), .Y(o19));
  NOR2x1_ASAP7_75t_R   g172(.A(new_n221_), .B(new_n177_), .Y(new_n259_));
  AO21x1_ASAP7_75t_R   g173(.A1(new_n223_), .A2(new_n224_), .B(new_n206_), .Y(new_n260_));
  OA21x2_ASAP7_75t_R   g174(.A1(new_n172_), .A2(new_n259_), .B(new_n260_), .Y(new_n261_));
  OA21x2_ASAP7_75t_R   g175(.A1(new_n259_), .A2(new_n260_), .B(p50), .Y(new_n262_));
  NOR2x1_ASAP7_75t_R   g176(.A(p47), .B(new_n262_), .Y(new_n263_));
  OAI22x1_ASAP7_75t_R  g177(.A1(new_n143_), .A2(new_n200_), .B1(new_n147_), .B2(new_n150_), .Y(new_n264_));
  AOI21x1_ASAP7_75t_R  g178(.A1(p27), .A2(new_n139_), .B(new_n264_), .Y(new_n265_));
  INVx1_ASAP7_75t_R    g179(.A(p48), .Y(new_n266_));
  INVx1_ASAP7_75t_R    g180(.A(p43), .Y(new_n267_));
  OA21x2_ASAP7_75t_R   g181(.A1(new_n205_), .A2(new_n266_), .B(new_n267_), .Y(new_n268_));
  AO22x1_ASAP7_75t_R   g182(.A1(p49), .A2(p26), .B1(p56), .B2(p41), .Y(new_n269_));
  AOI21x1_ASAP7_75t_R  g183(.A1(p36), .A2(new_n182_), .B(new_n269_), .Y(new_n270_));
  OA21x2_ASAP7_75t_R   g184(.A1(new_n265_), .A2(new_n268_), .B(new_n270_), .Y(new_n271_));
  OA21x2_ASAP7_75t_R   g185(.A1(new_n261_), .A2(new_n263_), .B(new_n271_), .Y(o20));
  AND2x2_ASAP7_75t_R   g186(.A(p16), .B(p54), .Y(new_n273_));
  NAND2x1_ASAP7_75t_R  g187(.A(new_n140_), .B(new_n273_), .Y(new_n274_));
  NAND2x1_ASAP7_75t_R  g188(.A(p15), .B(p57), .Y(new_n275_));
  OAI21x1_ASAP7_75t_R  g189(.A1(o11), .A2(new_n274_), .B(new_n275_), .Y(new_n276_));
  NOR2x1_ASAP7_75t_R   g190(.A(p44), .B(new_n144_), .Y(new_n277_));
  AND3x1_ASAP7_75t_R   g191(.A(new_n277_), .B(new_n164_), .C(new_n87_), .Y(new_n278_));
  NOR3x1_ASAP7_75t_R   g192(.A(new_n276_), .B(p31), .C(new_n278_), .Y(new_n279_));
  NAND2x1_ASAP7_75t_R  g193(.A(p22), .B(new_n139_), .Y(new_n280_));
  NAND2x1_ASAP7_75t_R  g194(.A(p23), .B(new_n139_), .Y(new_n281_));
  NOR3x1_ASAP7_75t_R   g195(.A(new_n148_), .B(p44), .C(new_n144_), .Y(new_n282_));
  NAND2x1_ASAP7_75t_R  g196(.A(new_n164_), .B(new_n282_), .Y(new_n283_));
  INVx1_ASAP7_75t_R    g197(.A(p32), .Y(new_n284_));
  AND4x2_ASAP7_75t_R   g198(.A(p15), .B(p9), .C(p10), .D(p16), .Y(new_n285_));
  AOI21x1_ASAP7_75t_R  g199(.A1(p11), .A2(p46), .B(new_n199_), .Y(new_n286_));
  AND2x2_ASAP7_75t_R   g200(.A(p6), .B(p57), .Y(new_n287_));
  AOI21x1_ASAP7_75t_R  g201(.A1(new_n285_), .A2(new_n286_), .B(new_n287_), .Y(new_n288_));
  AND3x1_ASAP7_75t_R   g202(.A(new_n283_), .B(new_n284_), .C(new_n288_), .Y(new_n289_));
  AOI22x1_ASAP7_75t_R  g203(.A1(new_n279_), .A2(new_n280_), .B1(new_n281_), .B2(new_n289_), .Y(new_n290_));
  NAND3x1_ASAP7_75t_R  g204(.A(new_n160_), .B(p23), .C(new_n161_), .Y(new_n291_));
  NAND3x1_ASAP7_75t_R  g205(.A(new_n167_), .B(p23), .C(new_n137_), .Y(new_n292_));
  AND4x2_ASAP7_75t_R   g206(.A(new_n291_), .B(new_n283_), .C(new_n292_), .D(new_n288_), .Y(new_n293_));
  NAND3x1_ASAP7_75t_R  g207(.A(new_n160_), .B(p24), .C(new_n161_), .Y(new_n294_));
  NAND3x1_ASAP7_75t_R  g208(.A(new_n167_), .B(p24), .C(new_n137_), .Y(new_n295_));
  AOI21x1_ASAP7_75t_R  g209(.A1(p11), .A2(p46), .B(new_n145_), .Y(new_n296_));
  AND2x2_ASAP7_75t_R   g210(.A(p57), .B(p58), .Y(new_n297_));
  AOI21x1_ASAP7_75t_R  g211(.A1(new_n285_), .A2(new_n296_), .B(new_n297_), .Y(new_n298_));
  AND4x2_ASAP7_75t_R   g212(.A(new_n294_), .B(new_n283_), .C(new_n295_), .D(new_n298_), .Y(new_n299_));
  INVx1_ASAP7_75t_R    g213(.A(p33), .Y(new_n300_));
  OAI22x1_ASAP7_75t_R  g214(.A1(new_n284_), .A2(new_n293_), .B1(new_n299_), .B2(new_n300_), .Y(new_n301_));
  NOR2x1_ASAP7_75t_R   g215(.A(new_n278_), .B(new_n276_), .Y(new_n302_));
  INVx1_ASAP7_75t_R    g216(.A(p31), .Y(new_n303_));
  AOI21x1_ASAP7_75t_R  g217(.A1(new_n302_), .A2(new_n280_), .B(new_n303_), .Y(new_n304_));
  AOI21x1_ASAP7_75t_R  g218(.A1(new_n290_), .A2(new_n301_), .B(new_n304_), .Y(new_n305_));
  INVx1_ASAP7_75t_R    g219(.A(new_n290_), .Y(new_n306_));
  NAND2x1_ASAP7_75t_R  g220(.A(p21), .B(new_n139_), .Y(new_n307_));
  AND3x1_ASAP7_75t_R   g221(.A(new_n285_), .B(p52), .C(new_n140_), .Y(new_n308_));
  AND2x2_ASAP7_75t_R   g222(.A(p8), .B(p57), .Y(new_n309_));
  OR3x1_ASAP7_75t_R    g223(.A(new_n278_), .B(new_n308_), .C(new_n309_), .Y(new_n310_));
  NOR2x1_ASAP7_75t_R   g224(.A(p30), .B(new_n310_), .Y(new_n311_));
  AOI22x1_ASAP7_75t_R  g225(.A1(new_n305_), .A2(new_n306_), .B1(new_n307_), .B2(new_n311_), .Y(new_n312_));
  NAND2x1_ASAP7_75t_R  g226(.A(new_n300_), .B(new_n299_), .Y(new_n313_));
  NAND2x1_ASAP7_75t_R  g227(.A(new_n198_), .B(new_n313_), .Y(new_n314_));
  AO31x2_ASAP7_75t_R   g228(.A1(new_n226_), .A2(new_n195_), .A3(new_n216_), .B(new_n314_), .Y(new_n315_));
  NAND2x1_ASAP7_75t_R  g229(.A(new_n305_), .B(new_n315_), .Y(new_n316_));
  NOR3x1_ASAP7_75t_R   g230(.A(new_n278_), .B(new_n308_), .C(new_n309_), .Y(new_n317_));
  INVx1_ASAP7_75t_R    g231(.A(p30), .Y(new_n318_));
  AO21x1_ASAP7_75t_R   g232(.A1(new_n317_), .A2(new_n307_), .B(new_n318_), .Y(new_n319_));
  INVx1_ASAP7_75t_R    g233(.A(new_n319_), .Y(new_n320_));
  AOI21x1_ASAP7_75t_R  g234(.A1(new_n312_), .A2(new_n316_), .B(new_n320_), .Y(o21));
  AND3x1_ASAP7_75t_R   g235(.A(new_n295_), .B(new_n283_), .C(new_n298_), .Y(new_n322_));
  AO21x1_ASAP7_75t_R   g236(.A1(new_n294_), .A2(new_n322_), .B(new_n300_), .Y(new_n323_));
  AO21x1_ASAP7_75t_R   g237(.A1(new_n323_), .A2(new_n313_), .B(new_n232_), .Y(new_n324_));
  AO21x1_ASAP7_75t_R   g238(.A1(new_n198_), .A2(new_n227_), .B(new_n324_), .Y(new_n325_));
  NAND2x1_ASAP7_75t_R  g239(.A(new_n313_), .B(new_n323_), .Y(new_n326_));
  OAI21x1_ASAP7_75t_R  g240(.A1(new_n195_), .A2(new_n326_), .B(p50), .Y(new_n327_));
  AOI211x1_ASAP7_75t_R g241(.A1(new_n216_), .A2(new_n226_), .B(new_n231_), .C(new_n326_), .Y(new_n328_));
  NOR2x1_ASAP7_75t_R   g242(.A(new_n327_), .B(new_n328_), .Y(new_n329_));
  AOI22x1_ASAP7_75t_R  g243(.A1(new_n182_), .A2(p33), .B1(p49), .B2(p23), .Y(new_n330_));
  OAI21x1_ASAP7_75t_R  g244(.A1(new_n267_), .A2(new_n299_), .B(new_n330_), .Y(new_n331_));
  AND3x1_ASAP7_75t_R   g245(.A(new_n323_), .B(p47), .C(new_n313_), .Y(new_n332_));
  NOR2x1_ASAP7_75t_R   g246(.A(new_n266_), .B(new_n323_), .Y(new_n333_));
  OR3x1_ASAP7_75t_R    g247(.A(new_n331_), .B(new_n332_), .C(new_n333_), .Y(new_n334_));
  AOI21x1_ASAP7_75t_R  g248(.A1(new_n325_), .A2(new_n329_), .B(new_n334_), .Y(o22));
  NAND2x1_ASAP7_75t_R  g249(.A(new_n290_), .B(new_n301_), .Y(new_n336_));
  INVx1_ASAP7_75t_R    g250(.A(new_n304_), .Y(new_n337_));
  AOI21x1_ASAP7_75t_R  g251(.A1(new_n317_), .A2(new_n307_), .B(p30), .Y(new_n338_));
  AND3x1_ASAP7_75t_R   g252(.A(new_n307_), .B(p30), .C(new_n317_), .Y(new_n339_));
  NOR2x1_ASAP7_75t_R   g253(.A(new_n338_), .B(new_n339_), .Y(new_n340_));
  AND3x1_ASAP7_75t_R   g254(.A(new_n336_), .B(new_n337_), .C(new_n340_), .Y(new_n341_));
  OAI21x1_ASAP7_75t_R  g255(.A1(new_n306_), .A2(new_n315_), .B(new_n341_), .Y(new_n342_));
  OA211x2_ASAP7_75t_R  g256(.A1(new_n339_), .A2(new_n338_), .B(new_n290_), .C(new_n313_), .Y(new_n343_));
  NAND3x1_ASAP7_75t_R  g257(.A(new_n234_), .B(new_n198_), .C(new_n225_), .Y(new_n344_));
  AOI21x1_ASAP7_75t_R  g258(.A1(p26), .A2(new_n139_), .B(new_n251_), .Y(new_n345_));
  OAI22x1_ASAP7_75t_R  g259(.A1(new_n210_), .A2(new_n345_), .B1(new_n265_), .B2(new_n205_), .Y(new_n346_));
  NAND3x1_ASAP7_75t_R  g260(.A(new_n346_), .B(new_n198_), .C(new_n215_), .Y(new_n347_));
  NAND3x1_ASAP7_75t_R  g261(.A(new_n344_), .B(new_n347_), .C(new_n195_), .Y(new_n348_));
  OAI21x1_ASAP7_75t_R  g262(.A1(new_n340_), .A2(new_n305_), .B(p50), .Y(new_n349_));
  AOI21x1_ASAP7_75t_R  g263(.A1(new_n343_), .A2(new_n348_), .B(new_n349_), .Y(new_n350_));
  AOI22x1_ASAP7_75t_R  g264(.A1(new_n182_), .A2(p30), .B1(p49), .B2(p44), .Y(new_n351_));
  AO21x1_ASAP7_75t_R   g265(.A1(new_n317_), .A2(new_n307_), .B(new_n267_), .Y(new_n352_));
  OA211x2_ASAP7_75t_R  g266(.A1(new_n266_), .A2(new_n319_), .B(new_n351_), .C(new_n352_), .Y(new_n353_));
  OAI21x1_ASAP7_75t_R  g267(.A1(new_n178_), .A2(new_n340_), .B(new_n353_), .Y(new_n354_));
  AOI21x1_ASAP7_75t_R  g268(.A1(new_n342_), .A2(new_n350_), .B(new_n354_), .Y(o23));
  AND3x1_ASAP7_75t_R   g269(.A(new_n289_), .B(new_n292_), .C(new_n291_), .Y(new_n356_));
  AOI21x1_ASAP7_75t_R  g270(.A1(new_n280_), .A2(new_n279_), .B(new_n304_), .Y(new_n357_));
  NAND2x1_ASAP7_75t_R  g271(.A(new_n288_), .B(new_n283_), .Y(new_n358_));
  NAND2x1_ASAP7_75t_R  g272(.A(new_n292_), .B(new_n291_), .Y(new_n359_));
  OAI21x1_ASAP7_75t_R  g273(.A1(new_n358_), .A2(new_n359_), .B(p32), .Y(new_n360_));
  AOI21x1_ASAP7_75t_R  g274(.A1(new_n360_), .A2(new_n323_), .B(new_n356_), .Y(new_n361_));
  NOR2x1_ASAP7_75t_R   g275(.A(new_n357_), .B(new_n361_), .Y(new_n362_));
  OAI21x1_ASAP7_75t_R  g276(.A1(new_n356_), .A2(new_n315_), .B(new_n362_), .Y(new_n363_));
  NAND2x1_ASAP7_75t_R  g277(.A(new_n289_), .B(new_n281_), .Y(new_n364_));
  AND3x1_ASAP7_75t_R   g278(.A(new_n357_), .B(new_n364_), .C(new_n313_), .Y(new_n365_));
  AO21x1_ASAP7_75t_R   g279(.A1(new_n357_), .A2(new_n361_), .B(new_n172_), .Y(new_n366_));
  AOI21x1_ASAP7_75t_R  g280(.A1(new_n365_), .A2(new_n348_), .B(new_n366_), .Y(new_n367_));
  NAND2x1_ASAP7_75t_R  g281(.A(new_n302_), .B(new_n280_), .Y(new_n368_));
  AO22x1_ASAP7_75t_R   g282(.A1(p49), .A2(p21), .B1(p31), .B2(new_n182_), .Y(new_n369_));
  AO21x1_ASAP7_75t_R   g283(.A1(p43), .A2(new_n368_), .B(new_n369_), .Y(new_n370_));
  AND2x2_ASAP7_75t_R   g284(.A(p47), .B(new_n357_), .Y(new_n371_));
  AND3x1_ASAP7_75t_R   g285(.A(new_n368_), .B(p31), .C(p48), .Y(new_n372_));
  OR3x1_ASAP7_75t_R    g286(.A(new_n370_), .B(new_n371_), .C(new_n372_), .Y(new_n373_));
  AOI21x1_ASAP7_75t_R  g287(.A1(new_n363_), .A2(new_n367_), .B(new_n373_), .Y(o24));
  AND2x2_ASAP7_75t_R   g288(.A(new_n323_), .B(new_n195_), .Y(new_n375_));
  AO21x1_ASAP7_75t_R   g289(.A1(new_n216_), .A2(new_n226_), .B(new_n231_), .Y(new_n376_));
  AND2x2_ASAP7_75t_R   g290(.A(new_n364_), .B(new_n360_), .Y(new_n377_));
  NAND2x1_ASAP7_75t_R  g291(.A(new_n313_), .B(new_n377_), .Y(new_n378_));
  AO21x1_ASAP7_75t_R   g292(.A1(new_n375_), .A2(new_n376_), .B(new_n378_), .Y(new_n379_));
  INVx1_ASAP7_75t_R    g293(.A(new_n360_), .Y(new_n380_));
  OA21x2_ASAP7_75t_R   g294(.A1(new_n356_), .A2(new_n380_), .B(new_n323_), .Y(new_n381_));
  AOI21x1_ASAP7_75t_R  g295(.A1(new_n381_), .A2(new_n315_), .B(new_n172_), .Y(new_n382_));
  AO22x1_ASAP7_75t_R   g296(.A1(p49), .A2(p22), .B1(p32), .B2(new_n182_), .Y(new_n383_));
  NOR2x1_ASAP7_75t_R   g297(.A(new_n266_), .B(new_n360_), .Y(new_n384_));
  NOR2x1_ASAP7_75t_R   g298(.A(new_n267_), .B(new_n293_), .Y(new_n385_));
  OR3x1_ASAP7_75t_R    g299(.A(new_n383_), .B(new_n384_), .C(new_n385_), .Y(new_n386_));
  AO21x1_ASAP7_75t_R   g300(.A1(p47), .A2(new_n377_), .B(new_n386_), .Y(new_n387_));
  AOI21x1_ASAP7_75t_R  g301(.A1(new_n379_), .A2(new_n382_), .B(new_n387_), .Y(o25));
endmodule


