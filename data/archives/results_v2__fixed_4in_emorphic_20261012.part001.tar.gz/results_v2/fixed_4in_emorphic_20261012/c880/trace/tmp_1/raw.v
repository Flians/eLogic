// Benchmark "/tmp/" written by ABC on Mon Oct 12 15:07:53 2026

module \/tmp/  ( 
    p24, p6, p34, p55, p23, p18, p54, p15, p59, p9, p2, p47, p35, p1, p52,
    p37, p36, p44, p7, p32, p22, p4, p31, p57, p25, p40, p45, p39, p41,
    p29, p8, p17, p53, p42, p30, p33, p13, p56, p0, p10, p20, p3, p43, p21,
    p50, p5, p27, p12, p16, p11, p48, p51, p46, p58, p19, p26, p38, p14,
    p28, p49,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25  );
  input  p24, p6, p34, p55, p23, p18, p54, p15, p59, p9, p2, p47, p35,
    p1, p52, p37, p36, p44, p7, p32, p22, p4, p31, p57, p25, p40, p45, p39,
    p41, p29, p8, p17, p53, p42, p30, p33, p13, p56, p0, p10, p20, p3, p43,
    p21, p50, p5, p27, p12, p16, p11, p48, p51, p46, p58, p19, p26, p38,
    p14, p28, p49;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25;
  wire new_n87_, new_n88_, new_n90_, new_n91_, new_n92_, new_n94_, new_n97_,
    new_n98_, new_n99_, new_n101_, new_n102_, new_n103_, new_n111_,
    new_n112_, new_n113_, new_n115_, new_n116_, new_n117_, new_n120_,
    new_n121_, new_n122_, new_n123_, new_n124_, new_n125_, new_n126_,
    new_n127_, new_n128_, new_n130_, new_n131_, new_n132_, new_n133_,
    new_n134_, new_n135_, new_n136_, new_n137_, new_n138_, new_n140_,
    new_n141_, new_n142_, new_n143_, new_n144_, new_n145_, new_n146_,
    new_n147_, new_n148_, new_n149_, new_n150_, new_n151_, new_n152_,
    new_n153_, new_n154_, new_n155_, new_n156_, new_n157_, new_n158_,
    new_n159_, new_n160_, new_n161_, new_n162_, new_n163_, new_n164_,
    new_n165_, new_n166_, new_n167_, new_n168_, new_n169_, new_n170_,
    new_n171_, new_n172_, new_n173_, new_n174_, new_n175_, new_n176_,
    new_n177_, new_n178_, new_n180_, new_n181_, new_n182_, new_n183_,
    new_n184_, new_n185_, new_n186_, new_n187_, new_n188_, new_n189_,
    new_n190_, new_n191_, new_n192_, new_n193_, new_n194_, new_n195_,
    new_n196_, new_n197_, new_n198_, new_n199_, new_n200_, new_n201_,
    new_n202_, new_n203_, new_n204_, new_n205_, new_n206_, new_n207_,
    new_n208_, new_n209_, new_n210_, new_n211_, new_n212_, new_n213_,
    new_n214_, new_n215_, new_n216_, new_n217_, new_n218_, new_n219_,
    new_n220_, new_n221_, new_n222_, new_n223_, new_n224_, new_n226_,
    new_n227_, new_n228_, new_n229_, new_n230_, new_n231_, new_n232_,
    new_n233_, new_n234_, new_n235_, new_n236_, new_n237_, new_n238_,
    new_n239_, new_n240_, new_n241_, new_n242_, new_n244_, new_n245_,
    new_n246_, new_n247_, new_n248_, new_n249_, new_n250_, new_n251_,
    new_n252_, new_n254_, new_n255_, new_n256_, new_n257_, new_n258_,
    new_n259_, new_n260_, new_n261_, new_n262_, new_n263_, new_n264_,
    new_n265_, new_n266_, new_n267_, new_n268_, new_n269_, new_n270_,
    new_n271_, new_n272_, new_n273_, new_n274_, new_n275_, new_n276_,
    new_n277_, new_n278_, new_n279_, new_n280_, new_n281_, new_n282_,
    new_n283_, new_n284_, new_n285_, new_n286_, new_n287_, new_n288_,
    new_n289_, new_n290_, new_n291_, new_n292_, new_n293_, new_n294_,
    new_n295_, new_n296_, new_n297_, new_n298_, new_n299_, new_n300_,
    new_n302_, new_n303_, new_n304_, new_n305_, new_n306_, new_n307_,
    new_n308_, new_n309_, new_n310_, new_n311_, new_n313_, new_n314_,
    new_n315_, new_n316_, new_n317_, new_n318_, new_n319_, new_n320_,
    new_n321_, new_n322_, new_n323_, new_n324_, new_n325_, new_n326_,
    new_n327_, new_n328_, new_n330_, new_n331_, new_n332_, new_n333_,
    new_n334_, new_n335_, new_n336_, new_n337_, new_n338_, new_n339_,
    new_n340_, new_n341_, new_n342_, new_n343_, new_n344_, new_n345_,
    new_n347_, new_n348_, new_n349_, new_n350_, new_n351_, new_n352_,
    new_n353_, new_n354_, new_n355_, new_n356_, new_n357_, new_n358_,
    new_n359_, new_n360_;
  INVx1_ASAP7_75t_R    g000(.A(p59), .Y(new_n87_));
  NAND2x1_ASAP7_75t_R  g001(.A(p1), .B(p0), .Y(new_n88_));
  OR2x4_ASAP7_75t_R    g002(.A(new_n87_), .B(new_n88_), .Y(o0));
  INVx1_ASAP7_75t_R    g003(.A(p2), .Y(new_n90_));
  INVx1_ASAP7_75t_R    g004(.A(p1), .Y(new_n91_));
  INVx1_ASAP7_75t_R    g005(.A(p3), .Y(new_n92_));
  OR3x1_ASAP7_75t_R    g006(.A(new_n90_), .B(new_n91_), .C(new_n92_), .Y(o1));
  AND3x1_ASAP7_75t_R   g007(.A(p59), .B(p1), .C(p3), .Y(new_n94_));
  INVx1_ASAP7_75t_R    g008(.A(new_n94_), .Y(o2));
  NAND2x1_ASAP7_75t_R  g009(.A(p4), .B(p5), .Y(o3));
  NAND2x1_ASAP7_75t_R  g010(.A(p9), .B(p8), .Y(new_n97_));
  INVx1_ASAP7_75t_R    g011(.A(p6), .Y(new_n98_));
  INVx1_ASAP7_75t_R    g012(.A(p7), .Y(new_n99_));
  OR3x1_ASAP7_75t_R    g013(.A(new_n97_), .B(new_n98_), .C(new_n99_), .Y(o4));
  AND2x2_ASAP7_75t_R   g014(.A(p6), .B(p7), .Y(new_n101_));
  NAND2x1_ASAP7_75t_R  g015(.A(p9), .B(p10), .Y(new_n102_));
  INVx1_ASAP7_75t_R    g016(.A(new_n102_), .Y(new_n103_));
  AND3x1_ASAP7_75t_R   g017(.A(o2), .B(new_n101_), .C(new_n103_), .Y(o5));
  AND3x1_ASAP7_75t_R   g018(.A(p2), .B(p0), .C(p11), .Y(o6));
  AND3x1_ASAP7_75t_R   g019(.A(p2), .B(p3), .C(p11), .Y(o7));
  AND3x1_ASAP7_75t_R   g020(.A(p59), .B(p3), .C(p11), .Y(o8));
  OAI21x1_ASAP7_75t_R  g021(.A1(p13), .A2(p14), .B(p12), .Y(o9));
  AND3x1_ASAP7_75t_R   g022(.A(new_n103_), .B(new_n94_), .C(new_n101_), .Y(o10));
  NAND3x1_ASAP7_75t_R  g023(.A(p15), .B(p9), .C(p10), .Y(o11));
  INVx1_ASAP7_75t_R    g024(.A(p16), .Y(new_n111_));
  OR3x1_ASAP7_75t_R    g025(.A(new_n97_), .B(new_n99_), .C(new_n111_), .Y(new_n112_));
  INVx1_ASAP7_75t_R    g026(.A(p17), .Y(new_n113_));
  OR3x1_ASAP7_75t_R    g027(.A(new_n112_), .B(new_n91_), .C(new_n113_), .Y(o12));
  INVx1_ASAP7_75t_R    g028(.A(p11), .Y(new_n115_));
  OR3x1_ASAP7_75t_R    g029(.A(new_n112_), .B(new_n113_), .C(new_n115_), .Y(new_n116_));
  INVx1_ASAP7_75t_R    g030(.A(new_n116_), .Y(new_n117_));
  NAND2x1_ASAP7_75t_R  g031(.A(p18), .B(new_n117_), .Y(o13));
  OAI21x1_ASAP7_75t_R  g032(.A1(p13), .A2(p14), .B(p19), .Y(o14));
  XOR2x2_ASAP7_75t_R   g033(.A(p24), .B(p23), .Y(new_n120_));
  XOR2x2_ASAP7_75t_R   g034(.A(p27), .B(p28), .Y(new_n121_));
  XOR2x2_ASAP7_75t_R   g035(.A(new_n120_), .B(new_n121_), .Y(new_n122_));
  XOR2x2_ASAP7_75t_R   g036(.A(p25), .B(p29), .Y(new_n123_));
  XOR2x2_ASAP7_75t_R   g037(.A(new_n123_), .B(p26), .Y(new_n124_));
  XOR2x2_ASAP7_75t_R   g038(.A(new_n122_), .B(new_n124_), .Y(new_n125_));
  XOR2x2_ASAP7_75t_R   g039(.A(p22), .B(p20), .Y(new_n126_));
  INVx1_ASAP7_75t_R    g040(.A(p21), .Y(new_n127_));
  XOR2x2_ASAP7_75t_R   g041(.A(new_n126_), .B(new_n127_), .Y(new_n128_));
  XOR2x2_ASAP7_75t_R   g042(.A(new_n125_), .B(new_n128_), .Y(o15));
  XOR2x2_ASAP7_75t_R   g043(.A(p37), .B(p36), .Y(new_n130_));
  XOR2x2_ASAP7_75t_R   g044(.A(p32), .B(p33), .Y(new_n131_));
  XOR2x2_ASAP7_75t_R   g045(.A(new_n130_), .B(new_n131_), .Y(new_n132_));
  XOR2x2_ASAP7_75t_R   g046(.A(p35), .B(p38), .Y(new_n133_));
  INVx1_ASAP7_75t_R    g047(.A(p34), .Y(new_n134_));
  XOR2x2_ASAP7_75t_R   g048(.A(new_n133_), .B(new_n134_), .Y(new_n135_));
  XOR2x2_ASAP7_75t_R   g049(.A(new_n132_), .B(new_n135_), .Y(new_n136_));
  XOR2x2_ASAP7_75t_R   g050(.A(p30), .B(p20), .Y(new_n137_));
  XOR2x2_ASAP7_75t_R   g051(.A(new_n137_), .B(p31), .Y(new_n138_));
  XOR2x2_ASAP7_75t_R   g052(.A(new_n136_), .B(new_n138_), .Y(o16));
  AND3x1_ASAP7_75t_R   g053(.A(p59), .B(p0), .C(p11), .Y(new_n140_));
  NAND2x1_ASAP7_75t_R  g054(.A(p6), .B(p15), .Y(new_n141_));
  NOR3x1_ASAP7_75t_R   g055(.A(new_n140_), .B(new_n97_), .C(new_n141_), .Y(new_n142_));
  NAND2x1_ASAP7_75t_R  g056(.A(p15), .B(p9), .Y(new_n143_));
  NAND2x1_ASAP7_75t_R  g057(.A(p2), .B(p10), .Y(new_n144_));
  NOR2x1_ASAP7_75t_R   g058(.A(new_n143_), .B(new_n144_), .Y(new_n145_));
  NOR3x1_ASAP7_75t_R   g059(.A(new_n88_), .B(p44), .C(new_n111_), .Y(new_n146_));
  AOI22x1_ASAP7_75t_R  g060(.A1(new_n142_), .A2(p28), .B1(new_n145_), .B2(new_n146_), .Y(new_n147_));
  OAI21x1_ASAP7_75t_R  g061(.A1(p6), .A2(p59), .B(p10), .Y(new_n148_));
  NOR2x1_ASAP7_75t_R   g062(.A(new_n143_), .B(new_n148_), .Y(new_n149_));
  NAND2x1_ASAP7_75t_R  g063(.A(p11), .B(p46), .Y(new_n150_));
  AOI21x1_ASAP7_75t_R  g064(.A1(p6), .A2(p59), .B(new_n150_), .Y(new_n151_));
  NAND3x1_ASAP7_75t_R  g065(.A(new_n149_), .B(new_n151_), .C(p28), .Y(new_n152_));
  INVx1_ASAP7_75t_R    g066(.A(p9), .Y(new_n153_));
  OA21x2_ASAP7_75t_R   g067(.A1(p6), .A2(new_n153_), .B(p45), .Y(new_n154_));
  AND2x2_ASAP7_75t_R   g068(.A(p11), .B(p46), .Y(new_n155_));
  OAI21x1_ASAP7_75t_R  g069(.A1(o11), .A2(new_n155_), .B(p9), .Y(new_n156_));
  AOI21x1_ASAP7_75t_R  g070(.A1(new_n154_), .A2(new_n156_), .B(p37), .Y(new_n157_));
  INVx1_ASAP7_75t_R    g071(.A(p51), .Y(new_n158_));
  AO31x2_ASAP7_75t_R   g072(.A1(new_n147_), .A2(new_n152_), .A3(new_n157_), .B(new_n158_), .Y(new_n159_));
  NAND2x1_ASAP7_75t_R  g073(.A(new_n154_), .B(new_n156_), .Y(new_n160_));
  INVx1_ASAP7_75t_R    g074(.A(p37), .Y(new_n161_));
  AO31x2_ASAP7_75t_R   g075(.A1(new_n147_), .A2(new_n160_), .A3(new_n152_), .B(new_n161_), .Y(new_n162_));
  INVx1_ASAP7_75t_R    g076(.A(new_n162_), .Y(new_n163_));
  OAI21x1_ASAP7_75t_R  g077(.A1(new_n159_), .A2(new_n163_), .B(p50), .Y(new_n164_));
  AND3x1_ASAP7_75t_R   g078(.A(new_n147_), .B(new_n152_), .C(new_n157_), .Y(new_n165_));
  OA21x2_ASAP7_75t_R   g079(.A1(new_n165_), .A2(new_n163_), .B(new_n158_), .Y(new_n166_));
  AND3x1_ASAP7_75t_R   g080(.A(p59), .B(p40), .C(p39), .Y(new_n167_));
  INVx1_ASAP7_75t_R    g081(.A(new_n167_), .Y(new_n168_));
  NOR2x1_ASAP7_75t_R   g082(.A(new_n168_), .B(new_n116_), .Y(new_n169_));
  INVx1_ASAP7_75t_R    g083(.A(new_n169_), .Y(new_n170_));
  INVx1_ASAP7_75t_R    g084(.A(p48), .Y(new_n171_));
  INVx1_ASAP7_75t_R    g085(.A(p43), .Y(new_n172_));
  OA21x2_ASAP7_75t_R   g086(.A1(new_n161_), .A2(new_n171_), .B(new_n172_), .Y(new_n173_));
  AO31x2_ASAP7_75t_R   g087(.A1(new_n147_), .A2(new_n160_), .A3(new_n152_), .B(new_n173_), .Y(new_n174_));
  AOI22x1_ASAP7_75t_R  g088(.A1(p41), .A2(p42), .B1(p27), .B2(p49), .Y(new_n175_));
  OA211x2_ASAP7_75t_R  g089(.A1(new_n161_), .A2(new_n170_), .B(new_n174_), .C(new_n175_), .Y(new_n176_));
  INVx1_ASAP7_75t_R    g090(.A(p47), .Y(new_n177_));
  OR3x1_ASAP7_75t_R    g091(.A(new_n163_), .B(new_n177_), .C(new_n165_), .Y(new_n178_));
  OA211x2_ASAP7_75t_R  g092(.A1(new_n164_), .A2(new_n166_), .B(new_n176_), .C(new_n178_), .Y(o17));
  NAND3x1_ASAP7_75t_R  g093(.A(p59), .B(p0), .C(p11), .Y(new_n180_));
  AND4x2_ASAP7_75t_R   g094(.A(p6), .B(p15), .C(p9), .D(p8), .Y(new_n181_));
  AO22x1_ASAP7_75t_R   g095(.A1(new_n180_), .A2(new_n181_), .B1(new_n151_), .B2(new_n149_), .Y(new_n182_));
  NAND2x1_ASAP7_75t_R  g096(.A(new_n145_), .B(new_n146_), .Y(new_n183_));
  INVx1_ASAP7_75t_R    g097(.A(new_n183_), .Y(new_n184_));
  OAI21x1_ASAP7_75t_R  g098(.A1(p6), .A2(new_n153_), .B(p52), .Y(new_n185_));
  INVx1_ASAP7_75t_R    g099(.A(new_n156_), .Y(new_n186_));
  OAI21x1_ASAP7_75t_R  g100(.A1(new_n185_), .A2(new_n186_), .B(new_n134_), .Y(new_n187_));
  AOI211x1_ASAP7_75t_R g101(.A1(p25), .A2(new_n182_), .B(new_n184_), .C(new_n187_), .Y(new_n188_));
  NAND2x1_ASAP7_75t_R  g102(.A(p25), .B(new_n182_), .Y(new_n189_));
  OA21x2_ASAP7_75t_R   g103(.A1(new_n186_), .A2(new_n185_), .B(new_n183_), .Y(new_n190_));
  AOI21x1_ASAP7_75t_R  g104(.A1(new_n189_), .A2(new_n190_), .B(new_n134_), .Y(new_n191_));
  NOR2x1_ASAP7_75t_R   g105(.A(new_n188_), .B(new_n191_), .Y(new_n192_));
  OA21x2_ASAP7_75t_R   g106(.A1(p6), .A2(new_n153_), .B(p54), .Y(new_n193_));
  AND2x2_ASAP7_75t_R   g107(.A(new_n193_), .B(new_n156_), .Y(new_n194_));
  NAND3x1_ASAP7_75t_R  g108(.A(new_n149_), .B(new_n151_), .C(p26), .Y(new_n195_));
  NAND3x1_ASAP7_75t_R  g109(.A(new_n181_), .B(p26), .C(new_n180_), .Y(new_n196_));
  NAND3x1_ASAP7_75t_R  g110(.A(new_n195_), .B(new_n183_), .C(new_n196_), .Y(new_n197_));
  OAI21x1_ASAP7_75t_R  g111(.A1(new_n194_), .A2(new_n197_), .B(p35), .Y(new_n198_));
  INVx1_ASAP7_75t_R    g112(.A(p53), .Y(new_n199_));
  OR4x2_ASAP7_75t_R    g113(.A(new_n155_), .B(new_n199_), .C(new_n102_), .D(new_n141_), .Y(new_n200_));
  NOR2x1_ASAP7_75t_R   g114(.A(p9), .B(new_n199_), .Y(new_n201_));
  AOI21x1_ASAP7_75t_R  g115(.A1(new_n145_), .A2(new_n146_), .B(new_n201_), .Y(new_n202_));
  INVx1_ASAP7_75t_R    g116(.A(p36), .Y(new_n203_));
  AOI21x1_ASAP7_75t_R  g117(.A1(new_n200_), .A2(new_n202_), .B(new_n203_), .Y(new_n204_));
  NAND3x1_ASAP7_75t_R  g118(.A(new_n181_), .B(p27), .C(new_n180_), .Y(new_n205_));
  NAND3x1_ASAP7_75t_R  g119(.A(new_n149_), .B(new_n151_), .C(p27), .Y(new_n206_));
  AOI21x1_ASAP7_75t_R  g120(.A1(new_n205_), .A2(new_n206_), .B(new_n203_), .Y(new_n207_));
  AO21x1_ASAP7_75t_R   g121(.A1(new_n193_), .A2(new_n156_), .B(p35), .Y(new_n208_));
  OAI22x1_ASAP7_75t_R  g122(.A1(new_n204_), .A2(new_n207_), .B1(new_n197_), .B2(new_n208_), .Y(new_n209_));
  AND2x2_ASAP7_75t_R   g123(.A(new_n198_), .B(new_n209_), .Y(new_n210_));
  NAND3x1_ASAP7_75t_R  g124(.A(new_n206_), .B(new_n183_), .C(new_n205_), .Y(new_n211_));
  OA21x2_ASAP7_75t_R   g125(.A1(p6), .A2(new_n153_), .B(p53), .Y(new_n212_));
  AO21x1_ASAP7_75t_R   g126(.A1(new_n212_), .A2(new_n156_), .B(p36), .Y(new_n213_));
  OAI22x1_ASAP7_75t_R  g127(.A1(new_n197_), .A2(new_n208_), .B1(new_n211_), .B2(new_n213_), .Y(new_n214_));
  AO21x1_ASAP7_75t_R   g128(.A1(new_n162_), .A2(new_n159_), .B(new_n214_), .Y(new_n215_));
  NAND2x1_ASAP7_75t_R  g129(.A(new_n210_), .B(new_n215_), .Y(new_n216_));
  NAND2x1_ASAP7_75t_R  g130(.A(new_n192_), .B(new_n216_), .Y(new_n217_));
  OA21x2_ASAP7_75t_R   g131(.A1(new_n192_), .A2(new_n216_), .B(p50), .Y(new_n218_));
  AND2x2_ASAP7_75t_R   g132(.A(p47), .B(new_n192_), .Y(new_n219_));
  AO21x1_ASAP7_75t_R   g133(.A1(p34), .A2(p48), .B(p43), .Y(new_n220_));
  NAND2x1_ASAP7_75t_R  g134(.A(new_n189_), .B(new_n190_), .Y(new_n221_));
  AND2x2_ASAP7_75t_R   g135(.A(new_n220_), .B(new_n221_), .Y(new_n222_));
  AO22x1_ASAP7_75t_R   g136(.A1(p24), .A2(p49), .B1(p34), .B2(new_n169_), .Y(new_n223_));
  OR3x1_ASAP7_75t_R    g137(.A(new_n219_), .B(new_n222_), .C(new_n223_), .Y(new_n224_));
  AOI21x1_ASAP7_75t_R  g138(.A1(new_n217_), .A2(new_n218_), .B(new_n224_), .Y(o18));
  NOR2x1_ASAP7_75t_R   g139(.A(new_n213_), .B(new_n211_), .Y(new_n226_));
  AND2x2_ASAP7_75t_R   g140(.A(new_n162_), .B(new_n159_), .Y(new_n227_));
  NOR2x1_ASAP7_75t_R   g141(.A(new_n226_), .B(new_n227_), .Y(new_n228_));
  NOR2x1_ASAP7_75t_R   g142(.A(new_n207_), .B(new_n204_), .Y(new_n229_));
  INVx1_ASAP7_75t_R    g143(.A(new_n229_), .Y(new_n230_));
  OA21x2_ASAP7_75t_R   g144(.A1(new_n197_), .A2(new_n208_), .B(new_n198_), .Y(new_n231_));
  OR3x1_ASAP7_75t_R    g145(.A(new_n228_), .B(new_n230_), .C(new_n231_), .Y(new_n232_));
  INVx1_ASAP7_75t_R    g146(.A(p50), .Y(new_n233_));
  AO21x1_ASAP7_75t_R   g147(.A1(new_n230_), .A2(new_n231_), .B(new_n233_), .Y(new_n234_));
  AOI21x1_ASAP7_75t_R  g148(.A1(new_n231_), .A2(new_n228_), .B(new_n234_), .Y(new_n235_));
  OA21x2_ASAP7_75t_R   g149(.A1(new_n208_), .A2(new_n197_), .B(p47), .Y(new_n236_));
  AND3x1_ASAP7_75t_R   g150(.A(new_n117_), .B(p35), .C(new_n167_), .Y(new_n237_));
  AO21x1_ASAP7_75t_R   g151(.A1(p35), .A2(p48), .B(p43), .Y(new_n238_));
  OA21x2_ASAP7_75t_R   g152(.A1(new_n194_), .A2(new_n197_), .B(new_n238_), .Y(new_n239_));
  AO22x1_ASAP7_75t_R   g153(.A1(p55), .A2(p41), .B1(p25), .B2(p49), .Y(new_n240_));
  OR3x1_ASAP7_75t_R    g154(.A(new_n237_), .B(new_n239_), .C(new_n240_), .Y(new_n241_));
  AO21x1_ASAP7_75t_R   g155(.A1(new_n198_), .A2(new_n236_), .B(new_n241_), .Y(new_n242_));
  AOI21x1_ASAP7_75t_R  g156(.A1(new_n232_), .A2(new_n235_), .B(new_n242_), .Y(o19));
  OR3x1_ASAP7_75t_R    g157(.A(new_n226_), .B(new_n204_), .C(new_n207_), .Y(new_n244_));
  NOR2x1_ASAP7_75t_R   g158(.A(new_n227_), .B(new_n244_), .Y(new_n245_));
  AO21x1_ASAP7_75t_R   g159(.A1(new_n227_), .A2(new_n244_), .B(new_n233_), .Y(new_n246_));
  AND2x2_ASAP7_75t_R   g160(.A(new_n212_), .B(new_n156_), .Y(new_n247_));
  AO21x1_ASAP7_75t_R   g161(.A1(p36), .A2(p48), .B(p43), .Y(new_n248_));
  OAI21x1_ASAP7_75t_R  g162(.A1(new_n247_), .A2(new_n211_), .B(new_n248_), .Y(new_n249_));
  AOI22x1_ASAP7_75t_R  g163(.A1(p41), .A2(p56), .B1(p26), .B2(p49), .Y(new_n250_));
  OA211x2_ASAP7_75t_R  g164(.A1(new_n203_), .A2(new_n170_), .B(new_n249_), .C(new_n250_), .Y(new_n251_));
  OA21x2_ASAP7_75t_R   g165(.A1(new_n177_), .A2(new_n244_), .B(new_n251_), .Y(new_n252_));
  OA21x2_ASAP7_75t_R   g166(.A1(new_n245_), .A2(new_n246_), .B(new_n252_), .Y(o20));
  NAND2x1_ASAP7_75t_R  g167(.A(p21), .B(new_n182_), .Y(new_n254_));
  INVx1_ASAP7_75t_R    g168(.A(p52), .Y(new_n255_));
  OR4x2_ASAP7_75t_R    g169(.A(new_n155_), .B(o11), .C(new_n255_), .D(new_n111_), .Y(new_n256_));
  NOR3x1_ASAP7_75t_R   g170(.A(new_n88_), .B(new_n98_), .C(p44), .Y(new_n257_));
  NAND2x1_ASAP7_75t_R  g171(.A(new_n145_), .B(new_n257_), .Y(new_n258_));
  NAND2x1_ASAP7_75t_R  g172(.A(p57), .B(p8), .Y(new_n259_));
  NAND3x1_ASAP7_75t_R  g173(.A(new_n256_), .B(new_n258_), .C(new_n259_), .Y(new_n260_));
  INVx1_ASAP7_75t_R    g174(.A(new_n260_), .Y(new_n261_));
  INVx1_ASAP7_75t_R    g175(.A(p30), .Y(new_n262_));
  AO21x1_ASAP7_75t_R   g176(.A1(new_n254_), .A2(new_n261_), .B(new_n262_), .Y(new_n263_));
  NAND2x1_ASAP7_75t_R  g177(.A(p22), .B(new_n182_), .Y(new_n264_));
  AND3x1_ASAP7_75t_R   g178(.A(new_n150_), .B(p54), .C(p16), .Y(new_n265_));
  AND3x1_ASAP7_75t_R   g179(.A(p15), .B(p9), .C(p10), .Y(new_n266_));
  AOI22x1_ASAP7_75t_R  g180(.A1(new_n265_), .A2(new_n266_), .B1(p15), .B2(p57), .Y(new_n267_));
  INVx1_ASAP7_75t_R    g181(.A(p31), .Y(new_n268_));
  AND3x1_ASAP7_75t_R   g182(.A(new_n267_), .B(new_n268_), .C(new_n258_), .Y(new_n269_));
  NAND2x1_ASAP7_75t_R  g183(.A(p53), .B(p16), .Y(new_n270_));
  NAND2x1_ASAP7_75t_R  g184(.A(p6), .B(p57), .Y(new_n271_));
  OA31x2_ASAP7_75t_R   g185(.A1(new_n270_), .A2(o11), .A3(new_n155_), .B1(new_n271_), .Y(new_n272_));
  NAND2x1_ASAP7_75t_R  g186(.A(new_n272_), .B(new_n258_), .Y(new_n273_));
  AOI211x1_ASAP7_75t_R g187(.A1(p23), .A2(new_n182_), .B(p32), .C(new_n273_), .Y(new_n274_));
  AOI21x1_ASAP7_75t_R  g188(.A1(new_n264_), .A2(new_n269_), .B(new_n274_), .Y(new_n275_));
  NAND3x1_ASAP7_75t_R  g189(.A(new_n181_), .B(p23), .C(new_n180_), .Y(new_n276_));
  NAND3x1_ASAP7_75t_R  g190(.A(new_n149_), .B(new_n151_), .C(p23), .Y(new_n277_));
  NAND2x1_ASAP7_75t_R  g191(.A(new_n276_), .B(new_n277_), .Y(new_n278_));
  OAI21x1_ASAP7_75t_R  g192(.A1(new_n273_), .A2(new_n278_), .B(p32), .Y(new_n279_));
  AND2x2_ASAP7_75t_R   g193(.A(p57), .B(p58), .Y(new_n280_));
  AND2x2_ASAP7_75t_R   g194(.A(p45), .B(p16), .Y(new_n281_));
  AND3x1_ASAP7_75t_R   g195(.A(new_n266_), .B(new_n281_), .C(new_n150_), .Y(new_n282_));
  AOI211x1_ASAP7_75t_R g196(.A1(new_n145_), .A2(new_n257_), .B(new_n280_), .C(new_n282_), .Y(new_n283_));
  NAND2x1_ASAP7_75t_R  g197(.A(p24), .B(new_n142_), .Y(new_n284_));
  NAND3x1_ASAP7_75t_R  g198(.A(new_n149_), .B(new_n151_), .C(p24), .Y(new_n285_));
  INVx1_ASAP7_75t_R    g199(.A(p33), .Y(new_n286_));
  AO31x2_ASAP7_75t_R   g200(.A1(new_n283_), .A2(new_n284_), .A3(new_n285_), .B(new_n286_), .Y(new_n287_));
  NAND2x1_ASAP7_75t_R  g201(.A(new_n279_), .B(new_n287_), .Y(new_n288_));
  AND2x2_ASAP7_75t_R   g202(.A(p22), .B(new_n182_), .Y(new_n289_));
  AOI21x1_ASAP7_75t_R  g203(.A1(new_n258_), .A2(new_n267_), .B(new_n268_), .Y(new_n290_));
  AO21x1_ASAP7_75t_R   g204(.A1(p31), .A2(new_n289_), .B(new_n290_), .Y(new_n291_));
  AOI21x1_ASAP7_75t_R  g205(.A1(new_n275_), .A2(new_n288_), .B(new_n291_), .Y(new_n292_));
  NAND2x1_ASAP7_75t_R  g206(.A(new_n263_), .B(new_n292_), .Y(new_n293_));
  AOI21x1_ASAP7_75t_R  g207(.A1(new_n198_), .A2(new_n209_), .B(new_n188_), .Y(new_n294_));
  AOI211x1_ASAP7_75t_R g208(.A1(new_n162_), .A2(new_n159_), .B(new_n188_), .C(new_n214_), .Y(new_n295_));
  AND4x2_ASAP7_75t_R   g209(.A(new_n283_), .B(new_n286_), .C(new_n284_), .D(new_n285_), .Y(new_n296_));
  AOI211x1_ASAP7_75t_R g210(.A1(new_n264_), .A2(new_n269_), .B(new_n274_), .C(new_n296_), .Y(new_n297_));
  OA31x2_ASAP7_75t_R   g211(.A1(new_n191_), .A2(new_n294_), .A3(new_n295_), .B1(new_n297_), .Y(new_n298_));
  AND2x2_ASAP7_75t_R   g212(.A(p21), .B(new_n182_), .Y(new_n299_));
  OR3x1_ASAP7_75t_R    g213(.A(new_n299_), .B(p30), .C(new_n260_), .Y(new_n300_));
  OAI21x1_ASAP7_75t_R  g214(.A1(new_n293_), .A2(new_n298_), .B(new_n300_), .Y(o21));
  INVx1_ASAP7_75t_R    g215(.A(new_n296_), .Y(new_n302_));
  NAND2x1_ASAP7_75t_R  g216(.A(new_n287_), .B(new_n302_), .Y(new_n303_));
  AOI211x1_ASAP7_75t_R g217(.A1(p34), .A2(new_n221_), .B(new_n294_), .C(new_n295_), .Y(new_n304_));
  NAND2x1_ASAP7_75t_R  g218(.A(new_n303_), .B(new_n304_), .Y(new_n305_));
  OA21x2_ASAP7_75t_R   g219(.A1(new_n303_), .A2(new_n304_), .B(p50), .Y(new_n306_));
  AND3x1_ASAP7_75t_R   g220(.A(new_n283_), .B(new_n284_), .C(new_n285_), .Y(new_n307_));
  OA21x2_ASAP7_75t_R   g221(.A1(new_n286_), .A2(new_n171_), .B(new_n172_), .Y(new_n308_));
  AOI22x1_ASAP7_75t_R  g222(.A1(new_n169_), .A2(p33), .B1(p23), .B2(p49), .Y(new_n309_));
  OA21x2_ASAP7_75t_R   g223(.A1(new_n307_), .A2(new_n308_), .B(new_n309_), .Y(new_n310_));
  OAI21x1_ASAP7_75t_R  g224(.A1(new_n177_), .A2(new_n303_), .B(new_n310_), .Y(new_n311_));
  AOI21x1_ASAP7_75t_R  g225(.A1(new_n305_), .A2(new_n306_), .B(new_n311_), .Y(o22));
  INVx1_ASAP7_75t_R    g226(.A(new_n297_), .Y(new_n313_));
  NAND2x1_ASAP7_75t_R  g227(.A(new_n264_), .B(new_n269_), .Y(new_n314_));
  AOI21x1_ASAP7_75t_R  g228(.A1(new_n279_), .A2(new_n287_), .B(new_n274_), .Y(new_n315_));
  AO21x1_ASAP7_75t_R   g229(.A1(new_n254_), .A2(new_n261_), .B(p30), .Y(new_n316_));
  OR3x1_ASAP7_75t_R    g230(.A(new_n299_), .B(new_n262_), .C(new_n260_), .Y(new_n317_));
  NAND2x1_ASAP7_75t_R  g231(.A(new_n316_), .B(new_n317_), .Y(new_n318_));
  AOI211x1_ASAP7_75t_R g232(.A1(new_n314_), .A2(new_n315_), .B(new_n291_), .C(new_n318_), .Y(new_n319_));
  OAI21x1_ASAP7_75t_R  g233(.A1(new_n304_), .A2(new_n313_), .B(new_n319_), .Y(new_n320_));
  NAND2x1_ASAP7_75t_R  g234(.A(new_n300_), .B(new_n263_), .Y(new_n321_));
  OAI21x1_ASAP7_75t_R  g235(.A1(new_n321_), .A2(new_n292_), .B(p50), .Y(new_n322_));
  AOI21x1_ASAP7_75t_R  g236(.A1(new_n318_), .A2(new_n298_), .B(new_n322_), .Y(new_n323_));
  AND3x1_ASAP7_75t_R   g237(.A(new_n263_), .B(new_n300_), .C(p47), .Y(new_n324_));
  AO21x1_ASAP7_75t_R   g238(.A1(p30), .A2(p48), .B(p43), .Y(new_n325_));
  OA21x2_ASAP7_75t_R   g239(.A1(new_n260_), .A2(new_n299_), .B(new_n325_), .Y(new_n326_));
  AO22x1_ASAP7_75t_R   g240(.A1(p44), .A2(p49), .B1(p30), .B2(new_n169_), .Y(new_n327_));
  OR3x1_ASAP7_75t_R    g241(.A(new_n324_), .B(new_n326_), .C(new_n327_), .Y(new_n328_));
  AOI21x1_ASAP7_75t_R  g242(.A1(new_n320_), .A2(new_n323_), .B(new_n328_), .Y(o23));
  AOI21x1_ASAP7_75t_R  g243(.A1(p24), .A2(new_n182_), .B(new_n282_), .Y(new_n330_));
  AOI211x1_ASAP7_75t_R g244(.A1(new_n145_), .A2(new_n257_), .B(p33), .C(new_n280_), .Y(new_n331_));
  AO21x1_ASAP7_75t_R   g245(.A1(new_n330_), .A2(new_n331_), .B(new_n274_), .Y(new_n332_));
  AND3x1_ASAP7_75t_R   g246(.A(new_n182_), .B(p22), .C(p31), .Y(new_n333_));
  AOI211x1_ASAP7_75t_R g247(.A1(new_n264_), .A2(new_n269_), .B(new_n290_), .C(new_n333_), .Y(new_n334_));
  NOR2x1_ASAP7_75t_R   g248(.A(new_n334_), .B(new_n315_), .Y(new_n335_));
  OAI21x1_ASAP7_75t_R  g249(.A1(new_n332_), .A2(new_n304_), .B(new_n335_), .Y(new_n336_));
  INVx1_ASAP7_75t_R    g250(.A(new_n334_), .Y(new_n337_));
  AOI21x1_ASAP7_75t_R  g251(.A1(new_n334_), .A2(new_n315_), .B(new_n233_), .Y(new_n338_));
  OA31x2_ASAP7_75t_R   g252(.A1(new_n332_), .A2(new_n337_), .A3(new_n304_), .B1(new_n338_), .Y(new_n339_));
  OA21x2_ASAP7_75t_R   g253(.A1(new_n268_), .A2(new_n171_), .B(new_n172_), .Y(new_n340_));
  AND3x1_ASAP7_75t_R   g254(.A(new_n264_), .B(new_n258_), .C(new_n267_), .Y(new_n341_));
  NAND2x1_ASAP7_75t_R  g255(.A(p21), .B(p49), .Y(new_n342_));
  OR3x1_ASAP7_75t_R    g256(.A(new_n116_), .B(new_n268_), .C(new_n168_), .Y(new_n343_));
  OA211x2_ASAP7_75t_R  g257(.A1(new_n340_), .A2(new_n341_), .B(new_n342_), .C(new_n343_), .Y(new_n344_));
  OAI21x1_ASAP7_75t_R  g258(.A1(new_n177_), .A2(new_n337_), .B(new_n344_), .Y(new_n345_));
  AOI21x1_ASAP7_75t_R  g259(.A1(new_n336_), .A2(new_n339_), .B(new_n345_), .Y(o24));
  INVx1_ASAP7_75t_R    g260(.A(new_n279_), .Y(new_n347_));
  OR3x1_ASAP7_75t_R    g261(.A(new_n347_), .B(new_n274_), .C(new_n296_), .Y(new_n348_));
  AO21x1_ASAP7_75t_R   g262(.A1(new_n287_), .A2(new_n304_), .B(new_n348_), .Y(new_n349_));
  OA21x2_ASAP7_75t_R   g263(.A1(new_n274_), .A2(new_n347_), .B(new_n287_), .Y(new_n350_));
  INVx1_ASAP7_75t_R    g264(.A(new_n191_), .Y(new_n351_));
  AO21x1_ASAP7_75t_R   g265(.A1(new_n331_), .A2(new_n330_), .B(new_n188_), .Y(new_n352_));
  AO31x2_ASAP7_75t_R   g266(.A1(new_n215_), .A2(new_n210_), .A3(new_n351_), .B(new_n352_), .Y(new_n353_));
  AOI21x1_ASAP7_75t_R  g267(.A1(new_n350_), .A2(new_n353_), .B(new_n233_), .Y(new_n354_));
  AO21x1_ASAP7_75t_R   g268(.A1(p23), .A2(new_n182_), .B(new_n273_), .Y(new_n355_));
  AO21x1_ASAP7_75t_R   g269(.A1(p32), .A2(p48), .B(p43), .Y(new_n356_));
  AO22x1_ASAP7_75t_R   g270(.A1(p22), .A2(p49), .B1(p32), .B2(new_n169_), .Y(new_n357_));
  AOI21x1_ASAP7_75t_R  g271(.A1(new_n355_), .A2(new_n356_), .B(new_n357_), .Y(new_n358_));
  OR3x1_ASAP7_75t_R    g272(.A(new_n347_), .B(new_n177_), .C(new_n274_), .Y(new_n359_));
  NAND2x1_ASAP7_75t_R  g273(.A(new_n358_), .B(new_n359_), .Y(new_n360_));
  AOI21x1_ASAP7_75t_R  g274(.A1(new_n349_), .A2(new_n354_), .B(new_n360_), .Y(o25));
endmodule


