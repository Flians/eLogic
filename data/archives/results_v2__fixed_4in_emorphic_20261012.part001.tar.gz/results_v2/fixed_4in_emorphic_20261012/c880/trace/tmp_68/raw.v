// Benchmark "/tmp/" written by ABC on Mon Oct 12 15:08:01 2026

module \/tmp/  ( 
    p56, p58, p0, p50, p22, p39, p31, p5, p19, p17, p35, p38, p44, p40,
    p12, p23, p29, p8, p52, p26, p3, p6, p45, p2, p1, p33, p37, p32, p57,
    p14, p25, p48, p16, p51, p21, p20, p59, p46, p9, p18, p53, p24, p27,
    p42, p55, p10, p41, p30, p36, p11, p28, p54, p43, p34, p7, p13, p47,
    p4, p49, p15,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25  );
  input  p56, p58, p0, p50, p22, p39, p31, p5, p19, p17, p35, p38, p44,
    p40, p12, p23, p29, p8, p52, p26, p3, p6, p45, p2, p1, p33, p37, p32,
    p57, p14, p25, p48, p16, p51, p21, p20, p59, p46, p9, p18, p53, p24,
    p27, p42, p55, p10, p41, p30, p36, p11, p28, p54, p43, p34, p7, p13,
    p47, p4, p49, p15;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25;
  wire new_n87_, new_n88_, new_n90_, new_n91_, new_n92_, new_n94_, new_n97_,
    new_n98_, new_n99_, new_n101_, new_n102_, new_n103_, new_n110_,
    new_n112_, new_n113_, new_n115_, new_n118_, new_n119_, new_n120_,
    new_n121_, new_n122_, new_n123_, new_n124_, new_n125_, new_n127_,
    new_n128_, new_n129_, new_n130_, new_n131_, new_n132_, new_n133_,
    new_n134_, new_n135_, new_n136_, new_n138_, new_n139_, new_n140_,
    new_n141_, new_n142_, new_n143_, new_n144_, new_n145_, new_n146_,
    new_n147_, new_n148_, new_n149_, new_n150_, new_n151_, new_n152_,
    new_n153_, new_n154_, new_n155_, new_n156_, new_n157_, new_n158_,
    new_n159_, new_n160_, new_n161_, new_n162_, new_n163_, new_n164_,
    new_n165_, new_n166_, new_n167_, new_n168_, new_n169_, new_n170_,
    new_n171_, new_n172_, new_n173_, new_n174_, new_n175_, new_n176_,
    new_n177_, new_n178_, new_n179_, new_n180_, new_n181_, new_n182_,
    new_n183_, new_n184_, new_n185_, new_n186_, new_n188_, new_n189_,
    new_n190_, new_n191_, new_n192_, new_n193_, new_n194_, new_n195_,
    new_n196_, new_n197_, new_n198_, new_n199_, new_n200_, new_n201_,
    new_n202_, new_n203_, new_n204_, new_n205_, new_n206_, new_n207_,
    new_n208_, new_n209_, new_n210_, new_n211_, new_n212_, new_n213_,
    new_n214_, new_n215_, new_n216_, new_n217_, new_n218_, new_n219_,
    new_n220_, new_n221_, new_n222_, new_n223_, new_n224_, new_n225_,
    new_n226_, new_n227_, new_n228_, new_n229_, new_n230_, new_n231_,
    new_n232_, new_n234_, new_n235_, new_n236_, new_n237_, new_n238_,
    new_n239_, new_n240_, new_n241_, new_n242_, new_n243_, new_n244_,
    new_n245_, new_n246_, new_n247_, new_n248_, new_n249_, new_n251_,
    new_n252_, new_n253_, new_n254_, new_n255_, new_n256_, new_n257_,
    new_n259_, new_n260_, new_n261_, new_n262_, new_n263_, new_n264_,
    new_n265_, new_n266_, new_n267_, new_n268_, new_n269_, new_n270_,
    new_n271_, new_n272_, new_n273_, new_n274_, new_n275_, new_n276_,
    new_n277_, new_n278_, new_n279_, new_n280_, new_n281_, new_n282_,
    new_n283_, new_n284_, new_n285_, new_n286_, new_n287_, new_n288_,
    new_n289_, new_n290_, new_n291_, new_n292_, new_n293_, new_n294_,
    new_n295_, new_n296_, new_n297_, new_n298_, new_n299_, new_n300_,
    new_n301_, new_n302_, new_n303_, new_n304_, new_n305_, new_n306_,
    new_n307_, new_n308_, new_n309_, new_n310_, new_n311_, new_n312_,
    new_n313_, new_n314_, new_n315_, new_n316_, new_n317_, new_n318_,
    new_n320_, new_n321_, new_n322_, new_n323_, new_n324_, new_n325_,
    new_n326_, new_n327_, new_n328_, new_n329_, new_n330_, new_n331_,
    new_n332_, new_n333_, new_n334_, new_n336_, new_n337_, new_n338_,
    new_n339_, new_n340_, new_n341_, new_n342_, new_n343_, new_n344_,
    new_n345_, new_n346_, new_n347_, new_n348_, new_n350_, new_n351_,
    new_n352_, new_n353_, new_n354_, new_n355_, new_n356_, new_n357_,
    new_n358_, new_n359_, new_n360_, new_n361_, new_n362_, new_n363_,
    new_n364_, new_n365_, new_n367_, new_n368_, new_n369_, new_n370_,
    new_n371_, new_n372_, new_n373_, new_n374_, new_n375_, new_n376_,
    new_n377_, new_n378_, new_n379_;
  INVx1_ASAP7_75t_R    g000(.A(p59), .Y(new_n87_));
  NAND2x1_ASAP7_75t_R  g001(.A(p0), .B(p1), .Y(new_n88_));
  OR2x4_ASAP7_75t_R    g002(.A(new_n87_), .B(new_n88_), .Y(o0));
  INVx1_ASAP7_75t_R    g003(.A(p3), .Y(new_n90_));
  INVx1_ASAP7_75t_R    g004(.A(p2), .Y(new_n91_));
  INVx1_ASAP7_75t_R    g005(.A(p1), .Y(new_n92_));
  OR3x1_ASAP7_75t_R    g006(.A(new_n90_), .B(new_n91_), .C(new_n92_), .Y(o1));
  AND3x1_ASAP7_75t_R   g007(.A(p3), .B(p1), .C(p59), .Y(new_n94_));
  INVx1_ASAP7_75t_R    g008(.A(new_n94_), .Y(o2));
  NAND2x1_ASAP7_75t_R  g009(.A(p5), .B(p4), .Y(o3));
  NAND2x1_ASAP7_75t_R  g010(.A(p8), .B(p9), .Y(new_n97_));
  INVx1_ASAP7_75t_R    g011(.A(p6), .Y(new_n98_));
  INVx1_ASAP7_75t_R    g012(.A(p7), .Y(new_n99_));
  OR3x1_ASAP7_75t_R    g013(.A(new_n97_), .B(new_n98_), .C(new_n99_), .Y(o4));
  AND2x2_ASAP7_75t_R   g014(.A(p6), .B(p7), .Y(new_n101_));
  NAND2x1_ASAP7_75t_R  g015(.A(p9), .B(p10), .Y(new_n102_));
  INVx1_ASAP7_75t_R    g016(.A(new_n102_), .Y(new_n103_));
  AND3x1_ASAP7_75t_R   g017(.A(o2), .B(new_n101_), .C(new_n103_), .Y(o5));
  AND3x1_ASAP7_75t_R   g018(.A(p0), .B(p2), .C(p11), .Y(o6));
  AND3x1_ASAP7_75t_R   g019(.A(p3), .B(p2), .C(p11), .Y(o7));
  AND3x1_ASAP7_75t_R   g020(.A(p3), .B(p59), .C(p11), .Y(o8));
  OAI21x1_ASAP7_75t_R  g021(.A1(p14), .A2(p13), .B(p12), .Y(o9));
  AND3x1_ASAP7_75t_R   g022(.A(new_n103_), .B(new_n94_), .C(new_n101_), .Y(o10));
  AND3x1_ASAP7_75t_R   g023(.A(p9), .B(p10), .C(p15), .Y(new_n110_));
  INVx1_ASAP7_75t_R    g024(.A(new_n110_), .Y(o11));
  INVx1_ASAP7_75t_R    g025(.A(new_n97_), .Y(new_n112_));
  AND3x1_ASAP7_75t_R   g026(.A(p17), .B(p16), .C(p7), .Y(new_n113_));
  NAND3x1_ASAP7_75t_R  g027(.A(new_n112_), .B(p1), .C(new_n113_), .Y(o12));
  AND3x1_ASAP7_75t_R   g028(.A(new_n112_), .B(p11), .C(new_n113_), .Y(new_n115_));
  NAND2x1_ASAP7_75t_R  g029(.A(p18), .B(new_n115_), .Y(o13));
  OAI21x1_ASAP7_75t_R  g030(.A1(p14), .A2(p13), .B(p19), .Y(o14));
  XOR2x2_ASAP7_75t_R   g031(.A(p27), .B(p28), .Y(new_n118_));
  XOR2x2_ASAP7_75t_R   g032(.A(p23), .B(p24), .Y(new_n119_));
  XOR2x2_ASAP7_75t_R   g033(.A(new_n118_), .B(new_n119_), .Y(new_n120_));
  XOR2x2_ASAP7_75t_R   g034(.A(p22), .B(p21), .Y(new_n121_));
  XOR2x2_ASAP7_75t_R   g035(.A(new_n121_), .B(p20), .Y(new_n122_));
  XOR2x2_ASAP7_75t_R   g036(.A(new_n120_), .B(new_n122_), .Y(new_n123_));
  XNOR2x2_ASAP7_75t_R  g037(.A(p26), .B(p25), .Y(new_n124_));
  XOR2x2_ASAP7_75t_R   g038(.A(new_n124_), .B(p29), .Y(new_n125_));
  XOR2x2_ASAP7_75t_R   g039(.A(new_n123_), .B(new_n125_), .Y(o15));
  XNOR2x2_ASAP7_75t_R  g040(.A(p33), .B(p32), .Y(new_n127_));
  XOR2x2_ASAP7_75t_R   g041(.A(p37), .B(p36), .Y(new_n128_));
  XOR2x2_ASAP7_75t_R   g042(.A(new_n127_), .B(new_n128_), .Y(new_n129_));
  XOR2x2_ASAP7_75t_R   g043(.A(p38), .B(p34), .Y(new_n130_));
  INVx1_ASAP7_75t_R    g044(.A(p35), .Y(new_n131_));
  XOR2x2_ASAP7_75t_R   g045(.A(new_n130_), .B(new_n131_), .Y(new_n132_));
  XOR2x2_ASAP7_75t_R   g046(.A(new_n129_), .B(new_n132_), .Y(new_n133_));
  XOR2x2_ASAP7_75t_R   g047(.A(p31), .B(p20), .Y(new_n134_));
  INVx1_ASAP7_75t_R    g048(.A(p30), .Y(new_n135_));
  XOR2x2_ASAP7_75t_R   g049(.A(new_n134_), .B(new_n135_), .Y(new_n136_));
  XOR2x2_ASAP7_75t_R   g050(.A(new_n133_), .B(new_n136_), .Y(o16));
  NAND2x1_ASAP7_75t_R  g051(.A(p46), .B(p11), .Y(new_n138_));
  INVx1_ASAP7_75t_R    g052(.A(p9), .Y(new_n139_));
  AO31x2_ASAP7_75t_R   g053(.A1(new_n138_), .A2(p10), .A3(p15), .B(new_n139_), .Y(new_n140_));
  OA21x2_ASAP7_75t_R   g054(.A1(p6), .A2(new_n139_), .B(p45), .Y(new_n141_));
  AND4x2_ASAP7_75t_R   g055(.A(p2), .B(p9), .C(p10), .D(p15), .Y(new_n142_));
  INVx1_ASAP7_75t_R    g056(.A(p16), .Y(new_n143_));
  NOR3x1_ASAP7_75t_R   g057(.A(new_n88_), .B(p44), .C(new_n143_), .Y(new_n144_));
  AOI22x1_ASAP7_75t_R  g058(.A1(new_n140_), .A2(new_n141_), .B1(new_n142_), .B2(new_n144_), .Y(new_n145_));
  OAI21x1_ASAP7_75t_R  g059(.A1(p6), .A2(p59), .B(p15), .Y(new_n146_));
  NOR2x1_ASAP7_75t_R   g060(.A(new_n102_), .B(new_n146_), .Y(new_n147_));
  AOI21x1_ASAP7_75t_R  g061(.A1(p6), .A2(p59), .B(new_n138_), .Y(new_n148_));
  NAND3x1_ASAP7_75t_R  g062(.A(new_n147_), .B(new_n148_), .C(p28), .Y(new_n149_));
  AND3x1_ASAP7_75t_R   g063(.A(p0), .B(p59), .C(p11), .Y(new_n150_));
  NAND2x1_ASAP7_75t_R  g064(.A(p6), .B(p15), .Y(new_n151_));
  NOR3x1_ASAP7_75t_R   g065(.A(new_n150_), .B(new_n97_), .C(new_n151_), .Y(new_n152_));
  NAND2x1_ASAP7_75t_R  g066(.A(p28), .B(new_n152_), .Y(new_n153_));
  INVx1_ASAP7_75t_R    g067(.A(p37), .Y(new_n154_));
  AO31x2_ASAP7_75t_R   g068(.A1(new_n145_), .A2(new_n149_), .A3(new_n153_), .B(new_n154_), .Y(new_n155_));
  AOI211x1_ASAP7_75t_R g069(.A1(p46), .A2(p11), .B(new_n102_), .C(new_n151_), .Y(new_n156_));
  AO21x1_ASAP7_75t_R   g070(.A1(p45), .A2(new_n139_), .B(p37), .Y(new_n157_));
  AO21x1_ASAP7_75t_R   g071(.A1(p45), .A2(new_n156_), .B(new_n157_), .Y(new_n158_));
  INVx1_ASAP7_75t_R    g072(.A(new_n149_), .Y(new_n159_));
  INVx1_ASAP7_75t_R    g073(.A(p28), .Y(new_n160_));
  NAND3x1_ASAP7_75t_R  g074(.A(p0), .B(p59), .C(p11), .Y(new_n161_));
  AND4x2_ASAP7_75t_R   g075(.A(p8), .B(p6), .C(p9), .D(p15), .Y(new_n162_));
  NAND2x1_ASAP7_75t_R  g076(.A(new_n161_), .B(new_n162_), .Y(new_n163_));
  NAND2x1_ASAP7_75t_R  g077(.A(new_n142_), .B(new_n144_), .Y(new_n164_));
  OAI21x1_ASAP7_75t_R  g078(.A1(new_n160_), .A2(new_n163_), .B(new_n164_), .Y(new_n165_));
  OA31x2_ASAP7_75t_R   g079(.A1(new_n158_), .A2(new_n159_), .A3(new_n165_), .B1(p51), .Y(new_n166_));
  INVx1_ASAP7_75t_R    g080(.A(p50), .Y(new_n167_));
  AO21x1_ASAP7_75t_R   g081(.A1(new_n155_), .A2(new_n166_), .B(new_n167_), .Y(new_n168_));
  AOI22x1_ASAP7_75t_R  g082(.A1(new_n152_), .A2(p28), .B1(new_n142_), .B2(new_n144_), .Y(new_n169_));
  AOI21x1_ASAP7_75t_R  g083(.A1(p45), .A2(new_n156_), .B(new_n157_), .Y(new_n170_));
  AND3x1_ASAP7_75t_R   g084(.A(new_n169_), .B(new_n149_), .C(new_n170_), .Y(new_n171_));
  NAND2x1_ASAP7_75t_R  g085(.A(new_n148_), .B(new_n147_), .Y(new_n172_));
  AO21x1_ASAP7_75t_R   g086(.A1(new_n163_), .A2(new_n172_), .B(new_n160_), .Y(new_n173_));
  AOI21x1_ASAP7_75t_R  g087(.A1(new_n145_), .A2(new_n173_), .B(new_n154_), .Y(new_n174_));
  NOR2x1_ASAP7_75t_R   g088(.A(new_n171_), .B(new_n174_), .Y(new_n175_));
  NOR2x1_ASAP7_75t_R   g089(.A(p51), .B(new_n175_), .Y(new_n176_));
  INVx1_ASAP7_75t_R    g090(.A(p47), .Y(new_n177_));
  OR3x1_ASAP7_75t_R    g091(.A(new_n174_), .B(new_n177_), .C(new_n171_), .Y(new_n178_));
  INVx1_ASAP7_75t_R    g092(.A(p48), .Y(new_n179_));
  INVx1_ASAP7_75t_R    g093(.A(p43), .Y(new_n180_));
  AO21x1_ASAP7_75t_R   g094(.A1(new_n145_), .A2(new_n173_), .B(new_n180_), .Y(new_n181_));
  AND3x1_ASAP7_75t_R   g095(.A(p39), .B(p40), .C(p59), .Y(new_n182_));
  AND2x2_ASAP7_75t_R   g096(.A(new_n182_), .B(new_n115_), .Y(new_n183_));
  AO22x1_ASAP7_75t_R   g097(.A1(p27), .A2(p49), .B1(p42), .B2(p41), .Y(new_n184_));
  AOI21x1_ASAP7_75t_R  g098(.A1(p37), .A2(new_n183_), .B(new_n184_), .Y(new_n185_));
  OA211x2_ASAP7_75t_R  g099(.A1(new_n179_), .A2(new_n155_), .B(new_n181_), .C(new_n185_), .Y(new_n186_));
  OA211x2_ASAP7_75t_R  g100(.A1(new_n168_), .A2(new_n176_), .B(new_n178_), .C(new_n186_), .Y(o17));
  AO21x1_ASAP7_75t_R   g101(.A1(new_n148_), .A2(new_n147_), .B(new_n152_), .Y(new_n188_));
  NOR2x1_ASAP7_75t_R   g102(.A(p44), .B(new_n88_), .Y(new_n189_));
  AND3x1_ASAP7_75t_R   g103(.A(new_n189_), .B(p16), .C(new_n142_), .Y(new_n190_));
  OA21x2_ASAP7_75t_R   g104(.A1(p6), .A2(new_n139_), .B(p52), .Y(new_n191_));
  AO21x1_ASAP7_75t_R   g105(.A1(new_n191_), .A2(new_n140_), .B(p34), .Y(new_n192_));
  AOI211x1_ASAP7_75t_R g106(.A1(p25), .A2(new_n188_), .B(new_n190_), .C(new_n192_), .Y(new_n193_));
  AOI21x1_ASAP7_75t_R  g107(.A1(new_n140_), .A2(new_n191_), .B(new_n190_), .Y(new_n194_));
  NAND2x1_ASAP7_75t_R  g108(.A(p25), .B(new_n188_), .Y(new_n195_));
  INVx1_ASAP7_75t_R    g109(.A(p34), .Y(new_n196_));
  AOI21x1_ASAP7_75t_R  g110(.A1(new_n194_), .A2(new_n195_), .B(new_n196_), .Y(new_n197_));
  NOR2x1_ASAP7_75t_R   g111(.A(new_n193_), .B(new_n197_), .Y(new_n198_));
  INVx1_ASAP7_75t_R    g112(.A(p51), .Y(new_n199_));
  AO31x2_ASAP7_75t_R   g113(.A1(new_n169_), .A2(new_n149_), .A3(new_n170_), .B(new_n199_), .Y(new_n200_));
  NAND2x1_ASAP7_75t_R  g114(.A(new_n155_), .B(new_n200_), .Y(new_n201_));
  NAND3x1_ASAP7_75t_R  g115(.A(new_n147_), .B(new_n148_), .C(p26), .Y(new_n202_));
  INVx1_ASAP7_75t_R    g116(.A(p26), .Y(new_n203_));
  OR4x2_ASAP7_75t_R    g117(.A(new_n150_), .B(new_n203_), .C(new_n97_), .D(new_n151_), .Y(new_n204_));
  NAND3x1_ASAP7_75t_R  g118(.A(new_n202_), .B(new_n204_), .C(new_n164_), .Y(new_n205_));
  OA21x2_ASAP7_75t_R   g119(.A1(p6), .A2(new_n139_), .B(p54), .Y(new_n206_));
  AOI21x1_ASAP7_75t_R  g120(.A1(new_n206_), .A2(new_n140_), .B(p35), .Y(new_n207_));
  INVx1_ASAP7_75t_R    g121(.A(new_n207_), .Y(new_n208_));
  OA21x2_ASAP7_75t_R   g122(.A1(p6), .A2(new_n139_), .B(p53), .Y(new_n209_));
  AO21x1_ASAP7_75t_R   g123(.A1(new_n209_), .A2(new_n140_), .B(p36), .Y(new_n210_));
  NAND3x1_ASAP7_75t_R  g124(.A(new_n147_), .B(new_n148_), .C(p27), .Y(new_n211_));
  NAND3x1_ASAP7_75t_R  g125(.A(new_n162_), .B(p27), .C(new_n161_), .Y(new_n212_));
  NAND3x1_ASAP7_75t_R  g126(.A(new_n211_), .B(new_n164_), .C(new_n212_), .Y(new_n213_));
  OA22x2_ASAP7_75t_R   g127(.A1(new_n205_), .A2(new_n208_), .B1(new_n210_), .B2(new_n213_), .Y(new_n214_));
  AOI22x1_ASAP7_75t_R  g128(.A1(new_n140_), .A2(new_n209_), .B1(new_n142_), .B2(new_n144_), .Y(new_n215_));
  INVx1_ASAP7_75t_R    g129(.A(p36), .Y(new_n216_));
  AO31x2_ASAP7_75t_R   g130(.A1(new_n215_), .A2(new_n211_), .A3(new_n212_), .B(new_n216_), .Y(new_n217_));
  AOI22x1_ASAP7_75t_R  g131(.A1(new_n152_), .A2(p26), .B1(new_n142_), .B2(new_n144_), .Y(new_n218_));
  AND3x1_ASAP7_75t_R   g132(.A(new_n218_), .B(new_n202_), .C(new_n207_), .Y(new_n219_));
  NAND2x1_ASAP7_75t_R  g133(.A(new_n206_), .B(new_n140_), .Y(new_n220_));
  AND3x1_ASAP7_75t_R   g134(.A(new_n218_), .B(new_n202_), .C(new_n220_), .Y(new_n221_));
  OAI22x1_ASAP7_75t_R  g135(.A1(new_n217_), .A2(new_n219_), .B1(new_n221_), .B2(new_n131_), .Y(new_n222_));
  AO21x1_ASAP7_75t_R   g136(.A1(new_n201_), .A2(new_n214_), .B(new_n222_), .Y(new_n223_));
  OAI21x1_ASAP7_75t_R  g137(.A1(new_n198_), .A2(new_n223_), .B(p50), .Y(new_n224_));
  INVx1_ASAP7_75t_R    g138(.A(new_n197_), .Y(new_n225_));
  AO211x2_ASAP7_75t_R  g139(.A1(new_n188_), .A2(p25), .B(new_n190_), .C(new_n192_), .Y(new_n226_));
  AND3x1_ASAP7_75t_R   g140(.A(new_n223_), .B(new_n225_), .C(new_n226_), .Y(new_n227_));
  AO21x1_ASAP7_75t_R   g141(.A1(p48), .A2(p34), .B(p43), .Y(new_n228_));
  NAND2x1_ASAP7_75t_R  g142(.A(new_n194_), .B(new_n195_), .Y(new_n229_));
  AO22x1_ASAP7_75t_R   g143(.A1(p24), .A2(p49), .B1(p34), .B2(new_n183_), .Y(new_n230_));
  AO21x1_ASAP7_75t_R   g144(.A1(new_n228_), .A2(new_n229_), .B(new_n230_), .Y(new_n231_));
  AOI21x1_ASAP7_75t_R  g145(.A1(p47), .A2(new_n198_), .B(new_n231_), .Y(new_n232_));
  OA21x2_ASAP7_75t_R   g146(.A1(new_n224_), .A2(new_n227_), .B(new_n232_), .Y(o18));
  AND2x2_ASAP7_75t_R   g147(.A(new_n212_), .B(new_n211_), .Y(new_n234_));
  NAND2x1_ASAP7_75t_R  g148(.A(new_n215_), .B(new_n234_), .Y(new_n235_));
  OA21x2_ASAP7_75t_R   g149(.A1(p36), .A2(new_n235_), .B(new_n201_), .Y(new_n236_));
  AOI21x1_ASAP7_75t_R  g150(.A1(new_n215_), .A2(new_n234_), .B(new_n216_), .Y(new_n237_));
  AND3x1_ASAP7_75t_R   g151(.A(new_n202_), .B(new_n204_), .C(new_n164_), .Y(new_n238_));
  AOI21x1_ASAP7_75t_R  g152(.A1(new_n220_), .A2(new_n238_), .B(new_n131_), .Y(new_n239_));
  NOR2x1_ASAP7_75t_R   g153(.A(new_n219_), .B(new_n239_), .Y(new_n240_));
  OR3x1_ASAP7_75t_R    g154(.A(new_n236_), .B(new_n237_), .C(new_n240_), .Y(new_n241_));
  AO21x1_ASAP7_75t_R   g155(.A1(new_n237_), .A2(new_n240_), .B(new_n167_), .Y(new_n242_));
  AOI21x1_ASAP7_75t_R  g156(.A1(new_n240_), .A2(new_n236_), .B(new_n242_), .Y(new_n243_));
  OA21x2_ASAP7_75t_R   g157(.A1(new_n131_), .A2(new_n179_), .B(new_n180_), .Y(new_n244_));
  AO22x1_ASAP7_75t_R   g158(.A1(p25), .A2(p49), .B1(p55), .B2(p41), .Y(new_n245_));
  AOI21x1_ASAP7_75t_R  g159(.A1(p35), .A2(new_n183_), .B(new_n245_), .Y(new_n246_));
  OA21x2_ASAP7_75t_R   g160(.A1(new_n244_), .A2(new_n221_), .B(new_n246_), .Y(new_n247_));
  OR3x1_ASAP7_75t_R    g161(.A(new_n239_), .B(new_n177_), .C(new_n219_), .Y(new_n248_));
  NAND2x1_ASAP7_75t_R  g162(.A(new_n247_), .B(new_n248_), .Y(new_n249_));
  AOI21x1_ASAP7_75t_R  g163(.A1(new_n241_), .A2(new_n243_), .B(new_n249_), .Y(o19));
  OA21x2_ASAP7_75t_R   g164(.A1(new_n213_), .A2(new_n210_), .B(new_n217_), .Y(new_n251_));
  XOR2x2_ASAP7_75t_R   g165(.A(new_n251_), .B(new_n201_), .Y(new_n252_));
  AO21x1_ASAP7_75t_R   g166(.A1(p48), .A2(new_n235_), .B(new_n183_), .Y(new_n253_));
  AO22x1_ASAP7_75t_R   g167(.A1(p56), .A2(p41), .B1(p26), .B2(p49), .Y(new_n254_));
  AO21x1_ASAP7_75t_R   g168(.A1(p43), .A2(new_n235_), .B(new_n254_), .Y(new_n255_));
  AO21x1_ASAP7_75t_R   g169(.A1(p47), .A2(new_n251_), .B(new_n255_), .Y(new_n256_));
  AO21x1_ASAP7_75t_R   g170(.A1(p36), .A2(new_n253_), .B(new_n256_), .Y(new_n257_));
  AOI21x1_ASAP7_75t_R  g171(.A1(p50), .A2(new_n252_), .B(new_n257_), .Y(o20));
  OAI21x1_ASAP7_75t_R  g172(.A1(new_n174_), .A2(new_n166_), .B(new_n214_), .Y(new_n259_));
  OA22x2_ASAP7_75t_R   g173(.A1(new_n217_), .A2(new_n219_), .B1(new_n131_), .B2(new_n221_), .Y(new_n260_));
  INVx1_ASAP7_75t_R    g174(.A(p23), .Y(new_n261_));
  AO21x1_ASAP7_75t_R   g175(.A1(new_n163_), .A2(new_n172_), .B(new_n261_), .Y(new_n262_));
  AND3x1_ASAP7_75t_R   g176(.A(new_n189_), .B(p6), .C(new_n142_), .Y(new_n263_));
  AND2x2_ASAP7_75t_R   g177(.A(p16), .B(p53), .Y(new_n264_));
  AND2x2_ASAP7_75t_R   g178(.A(p6), .B(p57), .Y(new_n265_));
  AO31x2_ASAP7_75t_R   g179(.A1(new_n110_), .A2(new_n264_), .A3(new_n138_), .B(new_n265_), .Y(new_n266_));
  NOR3x1_ASAP7_75t_R   g180(.A(new_n263_), .B(new_n266_), .C(p32), .Y(new_n267_));
  AND2x2_ASAP7_75t_R   g181(.A(p45), .B(p16), .Y(new_n268_));
  AND2x2_ASAP7_75t_R   g182(.A(p58), .B(p57), .Y(new_n269_));
  AO31x2_ASAP7_75t_R   g183(.A1(new_n110_), .A2(new_n268_), .A3(new_n138_), .B(new_n269_), .Y(new_n270_));
  NOR3x1_ASAP7_75t_R   g184(.A(new_n263_), .B(p33), .C(new_n270_), .Y(new_n271_));
  INVx1_ASAP7_75t_R    g185(.A(p24), .Y(new_n272_));
  AO21x1_ASAP7_75t_R   g186(.A1(new_n163_), .A2(new_n172_), .B(new_n272_), .Y(new_n273_));
  AOI22x1_ASAP7_75t_R  g187(.A1(new_n262_), .A2(new_n267_), .B1(new_n271_), .B2(new_n273_), .Y(new_n274_));
  AND2x2_ASAP7_75t_R   g188(.A(p57), .B(p15), .Y(new_n275_));
  NOR3x1_ASAP7_75t_R   g189(.A(new_n263_), .B(p31), .C(new_n275_), .Y(new_n276_));
  NAND2x1_ASAP7_75t_R  g190(.A(new_n98_), .B(new_n87_), .Y(new_n277_));
  AND2x2_ASAP7_75t_R   g191(.A(p46), .B(p11), .Y(new_n278_));
  NAND2x1_ASAP7_75t_R  g192(.A(p6), .B(p59), .Y(new_n279_));
  AND4x2_ASAP7_75t_R   g193(.A(new_n277_), .B(new_n110_), .C(new_n278_), .D(new_n279_), .Y(new_n280_));
  AND3x1_ASAP7_75t_R   g194(.A(new_n162_), .B(p22), .C(new_n161_), .Y(new_n281_));
  AND2x2_ASAP7_75t_R   g195(.A(p16), .B(p54), .Y(new_n282_));
  AND3x1_ASAP7_75t_R   g196(.A(new_n110_), .B(new_n282_), .C(new_n138_), .Y(new_n283_));
  AOI211x1_ASAP7_75t_R g197(.A1(p22), .A2(new_n280_), .B(new_n281_), .C(new_n283_), .Y(new_n284_));
  NAND2x1_ASAP7_75t_R  g198(.A(new_n276_), .B(new_n284_), .Y(new_n285_));
  NAND3x1_ASAP7_75t_R  g199(.A(new_n226_), .B(new_n274_), .C(new_n285_), .Y(new_n286_));
  AO31x2_ASAP7_75t_R   g200(.A1(new_n259_), .A2(new_n225_), .A3(new_n260_), .B(new_n286_), .Y(new_n287_));
  AND2x2_ASAP7_75t_R   g201(.A(p52), .B(p16), .Y(new_n288_));
  AND3x1_ASAP7_75t_R   g202(.A(new_n110_), .B(new_n288_), .C(new_n138_), .Y(new_n289_));
  NOR3x1_ASAP7_75t_R   g203(.A(new_n88_), .B(p44), .C(new_n98_), .Y(new_n290_));
  AO22x1_ASAP7_75t_R   g204(.A1(p8), .A2(p57), .B1(new_n142_), .B2(new_n290_), .Y(new_n291_));
  NOR2x1_ASAP7_75t_R   g205(.A(new_n289_), .B(new_n291_), .Y(new_n292_));
  NAND2x1_ASAP7_75t_R  g206(.A(p21), .B(new_n188_), .Y(new_n293_));
  AO21x1_ASAP7_75t_R   g207(.A1(new_n292_), .A2(new_n293_), .B(new_n135_), .Y(new_n294_));
  AOI22x1_ASAP7_75t_R  g208(.A1(new_n284_), .A2(new_n276_), .B1(new_n262_), .B2(new_n267_), .Y(new_n295_));
  INVx1_ASAP7_75t_R    g209(.A(new_n270_), .Y(new_n296_));
  NAND2x1_ASAP7_75t_R  g210(.A(new_n142_), .B(new_n290_), .Y(new_n297_));
  NAND3x1_ASAP7_75t_R  g211(.A(new_n147_), .B(new_n148_), .C(p24), .Y(new_n298_));
  OR4x2_ASAP7_75t_R    g212(.A(new_n150_), .B(new_n272_), .C(new_n97_), .D(new_n151_), .Y(new_n299_));
  AND4x2_ASAP7_75t_R   g213(.A(new_n296_), .B(new_n297_), .C(new_n298_), .D(new_n299_), .Y(new_n300_));
  INVx1_ASAP7_75t_R    g214(.A(p33), .Y(new_n301_));
  AND3x1_ASAP7_75t_R   g215(.A(new_n138_), .B(p16), .C(p53), .Y(new_n302_));
  AOI21x1_ASAP7_75t_R  g216(.A1(new_n110_), .A2(new_n302_), .B(new_n265_), .Y(new_n303_));
  NAND3x1_ASAP7_75t_R  g217(.A(new_n147_), .B(new_n148_), .C(p23), .Y(new_n304_));
  OR4x2_ASAP7_75t_R    g218(.A(new_n150_), .B(new_n261_), .C(new_n97_), .D(new_n151_), .Y(new_n305_));
  AND4x2_ASAP7_75t_R   g219(.A(new_n303_), .B(new_n304_), .C(new_n297_), .D(new_n305_), .Y(new_n306_));
  INVx1_ASAP7_75t_R    g220(.A(p32), .Y(new_n307_));
  OAI22x1_ASAP7_75t_R  g221(.A1(new_n300_), .A2(new_n301_), .B1(new_n306_), .B2(new_n307_), .Y(new_n308_));
  AOI21x1_ASAP7_75t_R  g222(.A1(p22), .A2(new_n280_), .B(new_n281_), .Y(new_n309_));
  NOR3x1_ASAP7_75t_R   g223(.A(new_n263_), .B(new_n275_), .C(new_n283_), .Y(new_n310_));
  INVx1_ASAP7_75t_R    g224(.A(p31), .Y(new_n311_));
  AOI21x1_ASAP7_75t_R  g225(.A1(new_n309_), .A2(new_n310_), .B(new_n311_), .Y(new_n312_));
  AOI21x1_ASAP7_75t_R  g226(.A1(new_n295_), .A2(new_n308_), .B(new_n312_), .Y(new_n313_));
  AND2x2_ASAP7_75t_R   g227(.A(new_n294_), .B(new_n313_), .Y(new_n314_));
  NOR2x1_ASAP7_75t_R   g228(.A(p30), .B(new_n291_), .Y(new_n315_));
  AOI21x1_ASAP7_75t_R  g229(.A1(p21), .A2(new_n152_), .B(new_n289_), .Y(new_n316_));
  NAND2x1_ASAP7_75t_R  g230(.A(p21), .B(new_n280_), .Y(new_n317_));
  AND3x1_ASAP7_75t_R   g231(.A(new_n315_), .B(new_n316_), .C(new_n317_), .Y(new_n318_));
  AO21x1_ASAP7_75t_R   g232(.A1(new_n287_), .A2(new_n314_), .B(new_n318_), .Y(o21));
  NAND2x1_ASAP7_75t_R  g233(.A(new_n273_), .B(new_n271_), .Y(new_n320_));
  NAND2x1_ASAP7_75t_R  g234(.A(new_n299_), .B(new_n298_), .Y(new_n321_));
  AO21x1_ASAP7_75t_R   g235(.A1(new_n142_), .A2(new_n290_), .B(new_n270_), .Y(new_n322_));
  OAI21x1_ASAP7_75t_R  g236(.A1(new_n321_), .A2(new_n322_), .B(p33), .Y(new_n323_));
  NAND2x1_ASAP7_75t_R  g237(.A(new_n320_), .B(new_n323_), .Y(new_n324_));
  OAI22x1_ASAP7_75t_R  g238(.A1(new_n205_), .A2(new_n208_), .B1(new_n213_), .B2(new_n210_), .Y(new_n325_));
  AOI211x1_ASAP7_75t_R g239(.A1(new_n155_), .A2(new_n200_), .B(new_n193_), .C(new_n325_), .Y(new_n326_));
  AOI211x1_ASAP7_75t_R g240(.A1(new_n226_), .A2(new_n222_), .B(new_n197_), .C(new_n326_), .Y(new_n327_));
  NAND2x1_ASAP7_75t_R  g241(.A(new_n324_), .B(new_n327_), .Y(new_n328_));
  OA21x2_ASAP7_75t_R   g242(.A1(new_n324_), .A2(new_n327_), .B(p50), .Y(new_n329_));
  OR3x1_ASAP7_75t_R    g243(.A(new_n300_), .B(new_n301_), .C(new_n179_), .Y(new_n330_));
  AOI22x1_ASAP7_75t_R  g244(.A1(new_n183_), .A2(p33), .B1(p23), .B2(p49), .Y(new_n331_));
  OA21x2_ASAP7_75t_R   g245(.A1(new_n180_), .A2(new_n300_), .B(new_n331_), .Y(new_n332_));
  OA21x2_ASAP7_75t_R   g246(.A1(new_n177_), .A2(new_n324_), .B(new_n332_), .Y(new_n333_));
  NAND2x1_ASAP7_75t_R  g247(.A(new_n330_), .B(new_n333_), .Y(new_n334_));
  AOI21x1_ASAP7_75t_R  g248(.A1(new_n328_), .A2(new_n329_), .B(new_n334_), .Y(o22));
  NAND2x1_ASAP7_75t_R  g249(.A(new_n285_), .B(new_n274_), .Y(new_n336_));
  AND2x2_ASAP7_75t_R   g250(.A(new_n316_), .B(new_n317_), .Y(new_n337_));
  AOI21x1_ASAP7_75t_R  g251(.A1(new_n292_), .A2(new_n293_), .B(new_n135_), .Y(new_n338_));
  AO21x1_ASAP7_75t_R   g252(.A1(new_n315_), .A2(new_n337_), .B(new_n338_), .Y(new_n339_));
  OR3x1_ASAP7_75t_R    g253(.A(new_n327_), .B(new_n336_), .C(new_n339_), .Y(new_n340_));
  NOR2x1_ASAP7_75t_R   g254(.A(new_n318_), .B(new_n338_), .Y(new_n341_));
  AOI211x1_ASAP7_75t_R g255(.A1(new_n295_), .A2(new_n308_), .B(new_n312_), .C(new_n341_), .Y(new_n342_));
  OAI21x1_ASAP7_75t_R  g256(.A1(new_n313_), .A2(new_n339_), .B(p50), .Y(new_n343_));
  AOI21x1_ASAP7_75t_R  g257(.A1(new_n342_), .A2(new_n287_), .B(new_n343_), .Y(new_n344_));
  AO21x1_ASAP7_75t_R   g258(.A1(new_n292_), .A2(new_n293_), .B(new_n180_), .Y(new_n345_));
  AOI22x1_ASAP7_75t_R  g259(.A1(new_n183_), .A2(p30), .B1(p44), .B2(p49), .Y(new_n346_));
  OA211x2_ASAP7_75t_R  g260(.A1(new_n179_), .A2(new_n294_), .B(new_n345_), .C(new_n346_), .Y(new_n347_));
  OAI21x1_ASAP7_75t_R  g261(.A1(new_n177_), .A2(new_n339_), .B(new_n347_), .Y(new_n348_));
  AOI21x1_ASAP7_75t_R  g262(.A1(new_n340_), .A2(new_n344_), .B(new_n348_), .Y(o23));
  INVx1_ASAP7_75t_R    g263(.A(new_n274_), .Y(new_n350_));
  AOI21x1_ASAP7_75t_R  g264(.A1(new_n142_), .A2(new_n290_), .B(new_n266_), .Y(new_n351_));
  AO31x2_ASAP7_75t_R   g265(.A1(new_n351_), .A2(new_n305_), .A3(new_n304_), .B(new_n307_), .Y(new_n352_));
  AND4x2_ASAP7_75t_R   g266(.A(new_n351_), .B(new_n307_), .C(new_n305_), .D(new_n304_), .Y(new_n353_));
  AOI21x1_ASAP7_75t_R  g267(.A1(new_n352_), .A2(new_n323_), .B(new_n353_), .Y(new_n354_));
  AOI21x1_ASAP7_75t_R  g268(.A1(new_n284_), .A2(new_n276_), .B(new_n312_), .Y(new_n355_));
  NOR2x1_ASAP7_75t_R   g269(.A(new_n354_), .B(new_n355_), .Y(new_n356_));
  OAI21x1_ASAP7_75t_R  g270(.A1(new_n350_), .A2(new_n327_), .B(new_n356_), .Y(new_n357_));
  INVx1_ASAP7_75t_R    g271(.A(new_n355_), .Y(new_n358_));
  AOI21x1_ASAP7_75t_R  g272(.A1(new_n354_), .A2(new_n355_), .B(new_n167_), .Y(new_n359_));
  OA31x2_ASAP7_75t_R   g273(.A1(new_n350_), .A2(new_n358_), .A3(new_n327_), .B1(new_n359_), .Y(new_n360_));
  NAND2x1_ASAP7_75t_R  g274(.A(p48), .B(new_n312_), .Y(new_n361_));
  AO21x1_ASAP7_75t_R   g275(.A1(new_n309_), .A2(new_n310_), .B(new_n180_), .Y(new_n362_));
  AOI22x1_ASAP7_75t_R  g276(.A1(new_n183_), .A2(p31), .B1(p21), .B2(p49), .Y(new_n363_));
  AND3x1_ASAP7_75t_R   g277(.A(new_n361_), .B(new_n362_), .C(new_n363_), .Y(new_n364_));
  OAI21x1_ASAP7_75t_R  g278(.A1(new_n177_), .A2(new_n358_), .B(new_n364_), .Y(new_n365_));
  AOI21x1_ASAP7_75t_R  g279(.A1(new_n357_), .A2(new_n360_), .B(new_n365_), .Y(o24));
  INVx1_ASAP7_75t_R    g280(.A(new_n353_), .Y(new_n367_));
  NAND3x1_ASAP7_75t_R  g281(.A(new_n367_), .B(new_n352_), .C(new_n320_), .Y(new_n368_));
  AO21x1_ASAP7_75t_R   g282(.A1(new_n323_), .A2(new_n327_), .B(new_n368_), .Y(new_n369_));
  INVx1_ASAP7_75t_R    g283(.A(new_n352_), .Y(new_n370_));
  OA21x2_ASAP7_75t_R   g284(.A1(new_n353_), .A2(new_n370_), .B(new_n323_), .Y(new_n371_));
  NAND2x1_ASAP7_75t_R  g285(.A(new_n320_), .B(new_n226_), .Y(new_n372_));
  AO31x2_ASAP7_75t_R   g286(.A1(new_n259_), .A2(new_n225_), .A3(new_n260_), .B(new_n372_), .Y(new_n373_));
  AOI21x1_ASAP7_75t_R  g287(.A1(new_n371_), .A2(new_n373_), .B(new_n167_), .Y(new_n374_));
  AND3x1_ASAP7_75t_R   g288(.A(new_n367_), .B(p47), .C(new_n352_), .Y(new_n375_));
  NOR2x1_ASAP7_75t_R   g289(.A(new_n179_), .B(new_n352_), .Y(new_n376_));
  NOR2x1_ASAP7_75t_R   g290(.A(new_n180_), .B(new_n306_), .Y(new_n377_));
  AO22x1_ASAP7_75t_R   g291(.A1(p22), .A2(p49), .B1(p32), .B2(new_n183_), .Y(new_n378_));
  OR4x2_ASAP7_75t_R    g292(.A(new_n375_), .B(new_n376_), .C(new_n377_), .D(new_n378_), .Y(new_n379_));
  AOI21x1_ASAP7_75t_R  g293(.A1(new_n369_), .A2(new_n374_), .B(new_n379_), .Y(o25));
endmodule


