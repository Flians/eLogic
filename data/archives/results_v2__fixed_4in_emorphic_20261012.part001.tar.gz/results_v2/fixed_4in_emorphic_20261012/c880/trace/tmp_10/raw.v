// Benchmark "/tmp/" written by ABC on Mon Oct 12 15:07:54 2026

module \/tmp/  ( 
    p34, p37, p17, p44, p49, p4, p13, p20, p35, p29, p7, p24, p19, p18,
    p41, p59, p43, p22, p47, p30, p14, p40, p3, p56, p0, p9, p2, p26, p39,
    p50, p58, p33, p11, p5, p25, p10, p46, p38, p16, p36, p21, p27, p54,
    p53, p12, p1, p6, p45, p52, p23, p48, p55, p31, p42, p8, p15, p32, p57,
    p51, p28,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25  );
  input  p34, p37, p17, p44, p49, p4, p13, p20, p35, p29, p7, p24, p19,
    p18, p41, p59, p43, p22, p47, p30, p14, p40, p3, p56, p0, p9, p2, p26,
    p39, p50, p58, p33, p11, p5, p25, p10, p46, p38, p16, p36, p21, p27,
    p54, p53, p12, p1, p6, p45, p52, p23, p48, p55, p31, p42, p8, p15, p32,
    p57, p51, p28;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25;
  wire new_n87_, new_n88_, new_n90_, new_n91_, new_n92_, new_n94_, new_n97_,
    new_n99_, new_n100_, new_n101_, new_n108_, new_n110_, new_n112_,
    new_n115_, new_n116_, new_n117_, new_n118_, new_n119_, new_n120_,
    new_n121_, new_n122_, new_n124_, new_n125_, new_n126_, new_n127_,
    new_n128_, new_n129_, new_n130_, new_n131_, new_n132_, new_n134_,
    new_n135_, new_n136_, new_n137_, new_n138_, new_n139_, new_n140_,
    new_n141_, new_n142_, new_n143_, new_n144_, new_n145_, new_n146_,
    new_n147_, new_n148_, new_n149_, new_n150_, new_n151_, new_n152_,
    new_n153_, new_n154_, new_n155_, new_n156_, new_n157_, new_n158_,
    new_n159_, new_n160_, new_n161_, new_n162_, new_n163_, new_n164_,
    new_n165_, new_n166_, new_n167_, new_n168_, new_n169_, new_n170_,
    new_n171_, new_n172_, new_n174_, new_n175_, new_n176_, new_n177_,
    new_n178_, new_n179_, new_n180_, new_n181_, new_n182_, new_n183_,
    new_n184_, new_n185_, new_n186_, new_n187_, new_n188_, new_n189_,
    new_n190_, new_n191_, new_n192_, new_n193_, new_n194_, new_n195_,
    new_n196_, new_n197_, new_n198_, new_n199_, new_n200_, new_n201_,
    new_n202_, new_n203_, new_n204_, new_n205_, new_n206_, new_n207_,
    new_n208_, new_n209_, new_n210_, new_n211_, new_n212_, new_n213_,
    new_n214_, new_n215_, new_n216_, new_n217_, new_n218_, new_n219_,
    new_n220_, new_n221_, new_n222_, new_n223_, new_n224_, new_n225_,
    new_n226_, new_n227_, new_n228_, new_n230_, new_n231_, new_n232_,
    new_n233_, new_n234_, new_n235_, new_n236_, new_n237_, new_n238_,
    new_n239_, new_n240_, new_n241_, new_n242_, new_n243_, new_n244_,
    new_n245_, new_n246_, new_n247_, new_n249_, new_n250_, new_n251_,
    new_n252_, new_n253_, new_n254_, new_n255_, new_n257_, new_n258_,
    new_n259_, new_n260_, new_n261_, new_n262_, new_n263_, new_n264_,
    new_n265_, new_n266_, new_n267_, new_n268_, new_n269_, new_n270_,
    new_n271_, new_n272_, new_n273_, new_n274_, new_n275_, new_n276_,
    new_n277_, new_n278_, new_n279_, new_n280_, new_n281_, new_n282_,
    new_n283_, new_n284_, new_n285_, new_n286_, new_n287_, new_n288_,
    new_n289_, new_n290_, new_n291_, new_n292_, new_n293_, new_n294_,
    new_n295_, new_n296_, new_n297_, new_n298_, new_n299_, new_n300_,
    new_n301_, new_n302_, new_n303_, new_n304_, new_n305_, new_n306_,
    new_n307_, new_n308_, new_n309_, new_n310_, new_n311_, new_n313_,
    new_n314_, new_n315_, new_n316_, new_n317_, new_n318_, new_n319_,
    new_n320_, new_n321_, new_n322_, new_n323_, new_n324_, new_n325_,
    new_n326_, new_n327_, new_n328_, new_n329_, new_n331_, new_n332_,
    new_n333_, new_n334_, new_n335_, new_n336_, new_n337_, new_n338_,
    new_n339_, new_n340_, new_n341_, new_n342_, new_n343_, new_n344_,
    new_n345_, new_n346_, new_n348_, new_n349_, new_n350_, new_n351_,
    new_n352_, new_n353_, new_n354_, new_n355_, new_n356_, new_n357_,
    new_n358_, new_n359_, new_n360_, new_n361_, new_n362_, new_n363_,
    new_n365_, new_n366_, new_n367_, new_n368_, new_n369_, new_n370_,
    new_n371_, new_n372_, new_n373_, new_n374_, new_n375_;
  INVx1_ASAP7_75t_R    g000(.A(p59), .Y(new_n87_));
  NAND2x1_ASAP7_75t_R  g001(.A(p0), .B(p1), .Y(new_n88_));
  OR2x4_ASAP7_75t_R    g002(.A(new_n87_), .B(new_n88_), .Y(o0));
  INVx1_ASAP7_75t_R    g003(.A(p3), .Y(new_n90_));
  INVx1_ASAP7_75t_R    g004(.A(p2), .Y(new_n91_));
  INVx1_ASAP7_75t_R    g005(.A(p1), .Y(new_n92_));
  OR3x1_ASAP7_75t_R    g006(.A(new_n90_), .B(new_n91_), .C(new_n92_), .Y(o1));
  AND3x1_ASAP7_75t_R   g007(.A(p59), .B(p3), .C(p1), .Y(new_n94_));
  INVx1_ASAP7_75t_R    g008(.A(new_n94_), .Y(o2));
  NAND2x1_ASAP7_75t_R  g009(.A(p4), .B(p5), .Y(o3));
  AND3x1_ASAP7_75t_R   g010(.A(p7), .B(p9), .C(p8), .Y(new_n97_));
  NAND2x1_ASAP7_75t_R  g011(.A(p6), .B(new_n97_), .Y(o4));
  AND2x2_ASAP7_75t_R   g012(.A(p7), .B(p6), .Y(new_n99_));
  NAND2x1_ASAP7_75t_R  g013(.A(p9), .B(p10), .Y(new_n100_));
  INVx1_ASAP7_75t_R    g014(.A(new_n100_), .Y(new_n101_));
  AND3x1_ASAP7_75t_R   g015(.A(o2), .B(new_n99_), .C(new_n101_), .Y(o5));
  AND3x1_ASAP7_75t_R   g016(.A(p0), .B(p2), .C(p11), .Y(o6));
  AND3x1_ASAP7_75t_R   g017(.A(p3), .B(p2), .C(p11), .Y(o7));
  AND3x1_ASAP7_75t_R   g018(.A(p59), .B(p3), .C(p11), .Y(o8));
  OAI21x1_ASAP7_75t_R  g019(.A1(p13), .A2(p14), .B(p12), .Y(o9));
  AND3x1_ASAP7_75t_R   g020(.A(new_n101_), .B(new_n94_), .C(new_n99_), .Y(o10));
  AND3x1_ASAP7_75t_R   g021(.A(p9), .B(p10), .C(p15), .Y(new_n108_));
  INVx1_ASAP7_75t_R    g022(.A(new_n108_), .Y(o11));
  AND2x2_ASAP7_75t_R   g023(.A(p17), .B(p16), .Y(new_n110_));
  NAND3x1_ASAP7_75t_R  g024(.A(new_n97_), .B(new_n110_), .C(p1), .Y(o12));
  AND3x1_ASAP7_75t_R   g025(.A(new_n97_), .B(new_n110_), .C(p11), .Y(new_n112_));
  NAND2x1_ASAP7_75t_R  g026(.A(p18), .B(new_n112_), .Y(o13));
  OAI21x1_ASAP7_75t_R  g027(.A1(p13), .A2(p14), .B(p19), .Y(o14));
  XOR2x2_ASAP7_75t_R   g028(.A(p22), .B(p21), .Y(new_n115_));
  XOR2x2_ASAP7_75t_R   g029(.A(p24), .B(p27), .Y(new_n116_));
  XOR2x2_ASAP7_75t_R   g030(.A(new_n115_), .B(new_n116_), .Y(new_n117_));
  XOR2x2_ASAP7_75t_R   g031(.A(p23), .B(p28), .Y(new_n118_));
  XOR2x2_ASAP7_75t_R   g032(.A(new_n117_), .B(new_n118_), .Y(new_n119_));
  XNOR2x2_ASAP7_75t_R  g033(.A(p26), .B(p25), .Y(new_n120_));
  XOR2x2_ASAP7_75t_R   g034(.A(p20), .B(p29), .Y(new_n121_));
  XOR2x2_ASAP7_75t_R   g035(.A(new_n120_), .B(new_n121_), .Y(new_n122_));
  XOR2x2_ASAP7_75t_R   g036(.A(new_n119_), .B(new_n122_), .Y(o15));
  XOR2x2_ASAP7_75t_R   g037(.A(p33), .B(p32), .Y(new_n124_));
  XOR2x2_ASAP7_75t_R   g038(.A(p37), .B(p36), .Y(new_n125_));
  XOR2x2_ASAP7_75t_R   g039(.A(new_n124_), .B(new_n125_), .Y(new_n126_));
  XOR2x2_ASAP7_75t_R   g040(.A(p35), .B(p38), .Y(new_n127_));
  XOR2x2_ASAP7_75t_R   g041(.A(new_n127_), .B(p34), .Y(new_n128_));
  XOR2x2_ASAP7_75t_R   g042(.A(new_n126_), .B(new_n128_), .Y(new_n129_));
  XOR2x2_ASAP7_75t_R   g043(.A(p20), .B(p30), .Y(new_n130_));
  INVx1_ASAP7_75t_R    g044(.A(p31), .Y(new_n131_));
  XOR2x2_ASAP7_75t_R   g045(.A(new_n130_), .B(new_n131_), .Y(new_n132_));
  XOR2x2_ASAP7_75t_R   g046(.A(new_n129_), .B(new_n132_), .Y(o16));
  AND3x1_ASAP7_75t_R   g047(.A(p59), .B(p0), .C(p11), .Y(new_n134_));
  NAND2x1_ASAP7_75t_R  g048(.A(p9), .B(p8), .Y(new_n135_));
  NAND2x1_ASAP7_75t_R  g049(.A(p6), .B(p15), .Y(new_n136_));
  NOR3x1_ASAP7_75t_R   g050(.A(new_n134_), .B(new_n135_), .C(new_n136_), .Y(new_n137_));
  AND4x2_ASAP7_75t_R   g051(.A(p9), .B(p2), .C(p10), .D(p15), .Y(new_n138_));
  INVx1_ASAP7_75t_R    g052(.A(p16), .Y(new_n139_));
  NOR3x1_ASAP7_75t_R   g053(.A(new_n88_), .B(p44), .C(new_n139_), .Y(new_n140_));
  AOI22x1_ASAP7_75t_R  g054(.A1(new_n137_), .A2(p28), .B1(new_n138_), .B2(new_n140_), .Y(new_n141_));
  OAI21x1_ASAP7_75t_R  g055(.A1(p59), .A2(p6), .B(p15), .Y(new_n142_));
  NOR2x1_ASAP7_75t_R   g056(.A(new_n100_), .B(new_n142_), .Y(new_n143_));
  NAND2x1_ASAP7_75t_R  g057(.A(p11), .B(p46), .Y(new_n144_));
  AOI21x1_ASAP7_75t_R  g058(.A1(p59), .A2(p6), .B(new_n144_), .Y(new_n145_));
  NAND3x1_ASAP7_75t_R  g059(.A(new_n143_), .B(new_n145_), .C(p28), .Y(new_n146_));
  AOI211x1_ASAP7_75t_R g060(.A1(p11), .A2(p46), .B(new_n100_), .C(new_n136_), .Y(new_n147_));
  INVx1_ASAP7_75t_R    g061(.A(p9), .Y(new_n148_));
  AO21x1_ASAP7_75t_R   g062(.A1(p45), .A2(new_n148_), .B(p37), .Y(new_n149_));
  AOI21x1_ASAP7_75t_R  g063(.A1(p45), .A2(new_n147_), .B(new_n149_), .Y(new_n150_));
  AND3x1_ASAP7_75t_R   g064(.A(new_n141_), .B(new_n146_), .C(new_n150_), .Y(new_n151_));
  AO31x2_ASAP7_75t_R   g065(.A1(new_n144_), .A2(p10), .A3(p15), .B(new_n148_), .Y(new_n152_));
  OA21x2_ASAP7_75t_R   g066(.A1(p6), .A2(new_n148_), .B(p45), .Y(new_n153_));
  AOI22x1_ASAP7_75t_R  g067(.A1(new_n152_), .A2(new_n153_), .B1(new_n138_), .B2(new_n140_), .Y(new_n154_));
  NAND3x1_ASAP7_75t_R  g068(.A(p59), .B(p0), .C(p11), .Y(new_n155_));
  AND4x2_ASAP7_75t_R   g069(.A(p9), .B(p6), .C(p8), .D(p15), .Y(new_n156_));
  NAND2x1_ASAP7_75t_R  g070(.A(new_n155_), .B(new_n156_), .Y(new_n157_));
  NAND2x1_ASAP7_75t_R  g071(.A(new_n145_), .B(new_n143_), .Y(new_n158_));
  INVx1_ASAP7_75t_R    g072(.A(p28), .Y(new_n159_));
  AO21x1_ASAP7_75t_R   g073(.A1(new_n157_), .A2(new_n158_), .B(new_n159_), .Y(new_n160_));
  INVx1_ASAP7_75t_R    g074(.A(p37), .Y(new_n161_));
  AOI21x1_ASAP7_75t_R  g075(.A1(new_n154_), .A2(new_n160_), .B(new_n161_), .Y(new_n162_));
  NOR2x1_ASAP7_75t_R   g076(.A(new_n151_), .B(new_n162_), .Y(new_n163_));
  XOR2x2_ASAP7_75t_R   g077(.A(new_n163_), .B(p51), .Y(new_n164_));
  NAND2x1_ASAP7_75t_R  g078(.A(new_n154_), .B(new_n160_), .Y(new_n165_));
  AND3x1_ASAP7_75t_R   g079(.A(p59), .B(p40), .C(p39), .Y(new_n166_));
  AND2x2_ASAP7_75t_R   g080(.A(new_n166_), .B(new_n112_), .Y(new_n167_));
  AO22x1_ASAP7_75t_R   g081(.A1(p49), .A2(p27), .B1(p41), .B2(p42), .Y(new_n168_));
  AO21x1_ASAP7_75t_R   g082(.A1(p37), .A2(new_n167_), .B(new_n168_), .Y(new_n169_));
  AO21x1_ASAP7_75t_R   g083(.A1(p43), .A2(new_n165_), .B(new_n169_), .Y(new_n170_));
  AO21x1_ASAP7_75t_R   g084(.A1(p48), .A2(new_n162_), .B(new_n170_), .Y(new_n171_));
  AO21x1_ASAP7_75t_R   g085(.A1(p47), .A2(new_n163_), .B(new_n171_), .Y(new_n172_));
  AOI21x1_ASAP7_75t_R  g086(.A1(p50), .A2(new_n164_), .B(new_n172_), .Y(o17));
  INVx1_ASAP7_75t_R    g087(.A(p50), .Y(new_n174_));
  AO21x1_ASAP7_75t_R   g088(.A1(new_n145_), .A2(new_n143_), .B(new_n137_), .Y(new_n175_));
  NOR2x1_ASAP7_75t_R   g089(.A(p44), .B(new_n88_), .Y(new_n176_));
  AND3x1_ASAP7_75t_R   g090(.A(new_n176_), .B(p16), .C(new_n138_), .Y(new_n177_));
  OA21x2_ASAP7_75t_R   g091(.A1(p6), .A2(new_n148_), .B(p52), .Y(new_n178_));
  AO21x1_ASAP7_75t_R   g092(.A1(new_n178_), .A2(new_n152_), .B(p34), .Y(new_n179_));
  AO211x2_ASAP7_75t_R  g093(.A1(new_n175_), .A2(p25), .B(new_n177_), .C(new_n179_), .Y(new_n180_));
  AOI21x1_ASAP7_75t_R  g094(.A1(new_n152_), .A2(new_n178_), .B(new_n177_), .Y(new_n181_));
  NAND2x1_ASAP7_75t_R  g095(.A(p25), .B(new_n175_), .Y(new_n182_));
  INVx1_ASAP7_75t_R    g096(.A(p34), .Y(new_n183_));
  AO21x1_ASAP7_75t_R   g097(.A1(new_n181_), .A2(new_n182_), .B(new_n183_), .Y(new_n184_));
  NAND2x1_ASAP7_75t_R  g098(.A(new_n180_), .B(new_n184_), .Y(new_n185_));
  OA21x2_ASAP7_75t_R   g099(.A1(p6), .A2(new_n148_), .B(p53), .Y(new_n186_));
  AOI22x1_ASAP7_75t_R  g100(.A1(new_n152_), .A2(new_n186_), .B1(new_n138_), .B2(new_n140_), .Y(new_n187_));
  NAND3x1_ASAP7_75t_R  g101(.A(new_n143_), .B(new_n145_), .C(p27), .Y(new_n188_));
  NAND3x1_ASAP7_75t_R  g102(.A(new_n156_), .B(p27), .C(new_n155_), .Y(new_n189_));
  INVx1_ASAP7_75t_R    g103(.A(p36), .Y(new_n190_));
  AO31x2_ASAP7_75t_R   g104(.A1(new_n187_), .A2(new_n188_), .A3(new_n189_), .B(new_n190_), .Y(new_n191_));
  AOI22x1_ASAP7_75t_R  g105(.A1(new_n137_), .A2(p26), .B1(new_n138_), .B2(new_n140_), .Y(new_n192_));
  NAND3x1_ASAP7_75t_R  g106(.A(new_n143_), .B(new_n145_), .C(p26), .Y(new_n193_));
  OA21x2_ASAP7_75t_R   g107(.A1(p6), .A2(new_n148_), .B(p54), .Y(new_n194_));
  AOI21x1_ASAP7_75t_R  g108(.A1(new_n194_), .A2(new_n152_), .B(p35), .Y(new_n195_));
  AND3x1_ASAP7_75t_R   g109(.A(new_n192_), .B(new_n193_), .C(new_n195_), .Y(new_n196_));
  INVx1_ASAP7_75t_R    g110(.A(p35), .Y(new_n197_));
  NAND2x1_ASAP7_75t_R  g111(.A(new_n194_), .B(new_n152_), .Y(new_n198_));
  AND3x1_ASAP7_75t_R   g112(.A(new_n192_), .B(new_n198_), .C(new_n193_), .Y(new_n199_));
  OA22x2_ASAP7_75t_R   g113(.A1(new_n191_), .A2(new_n196_), .B1(new_n197_), .B2(new_n199_), .Y(new_n200_));
  AO21x1_ASAP7_75t_R   g114(.A1(p45), .A2(new_n147_), .B(new_n149_), .Y(new_n201_));
  INVx1_ASAP7_75t_R    g115(.A(new_n146_), .Y(new_n202_));
  NAND2x1_ASAP7_75t_R  g116(.A(new_n138_), .B(new_n140_), .Y(new_n203_));
  OAI21x1_ASAP7_75t_R  g117(.A1(new_n159_), .A2(new_n157_), .B(new_n203_), .Y(new_n204_));
  OA31x2_ASAP7_75t_R   g118(.A1(new_n201_), .A2(new_n202_), .A3(new_n204_), .B1(p51), .Y(new_n205_));
  INVx1_ASAP7_75t_R    g119(.A(p26), .Y(new_n206_));
  OR4x2_ASAP7_75t_R    g120(.A(new_n134_), .B(new_n206_), .C(new_n135_), .D(new_n136_), .Y(new_n207_));
  NAND3x1_ASAP7_75t_R  g121(.A(new_n193_), .B(new_n207_), .C(new_n203_), .Y(new_n208_));
  INVx1_ASAP7_75t_R    g122(.A(new_n195_), .Y(new_n209_));
  AO21x1_ASAP7_75t_R   g123(.A1(new_n186_), .A2(new_n152_), .B(p36), .Y(new_n210_));
  NAND3x1_ASAP7_75t_R  g124(.A(new_n188_), .B(new_n203_), .C(new_n189_), .Y(new_n211_));
  OA22x2_ASAP7_75t_R   g125(.A1(new_n208_), .A2(new_n209_), .B1(new_n210_), .B2(new_n211_), .Y(new_n212_));
  OAI21x1_ASAP7_75t_R  g126(.A1(new_n162_), .A2(new_n205_), .B(new_n212_), .Y(new_n213_));
  AND3x1_ASAP7_75t_R   g127(.A(new_n185_), .B(new_n200_), .C(new_n213_), .Y(new_n214_));
  NAND2x1_ASAP7_75t_R  g128(.A(p28), .B(new_n137_), .Y(new_n215_));
  AO31x2_ASAP7_75t_R   g129(.A1(new_n154_), .A2(new_n146_), .A3(new_n215_), .B(new_n161_), .Y(new_n216_));
  INVx1_ASAP7_75t_R    g130(.A(p51), .Y(new_n217_));
  AO31x2_ASAP7_75t_R   g131(.A1(new_n141_), .A2(new_n146_), .A3(new_n150_), .B(new_n217_), .Y(new_n218_));
  NAND2x1_ASAP7_75t_R  g132(.A(new_n216_), .B(new_n218_), .Y(new_n219_));
  OAI22x1_ASAP7_75t_R  g133(.A1(new_n191_), .A2(new_n196_), .B1(new_n199_), .B2(new_n197_), .Y(new_n220_));
  AO21x1_ASAP7_75t_R   g134(.A1(new_n219_), .A2(new_n212_), .B(new_n220_), .Y(new_n221_));
  AND3x1_ASAP7_75t_R   g135(.A(new_n221_), .B(new_n180_), .C(new_n184_), .Y(new_n222_));
  INVx1_ASAP7_75t_R    g136(.A(p47), .Y(new_n223_));
  AO21x1_ASAP7_75t_R   g137(.A1(p34), .A2(p48), .B(p43), .Y(new_n224_));
  NAND2x1_ASAP7_75t_R  g138(.A(new_n181_), .B(new_n182_), .Y(new_n225_));
  AO22x1_ASAP7_75t_R   g139(.A1(p49), .A2(p24), .B1(p34), .B2(new_n167_), .Y(new_n226_));
  AOI21x1_ASAP7_75t_R  g140(.A1(new_n224_), .A2(new_n225_), .B(new_n226_), .Y(new_n227_));
  OA21x2_ASAP7_75t_R   g141(.A1(new_n223_), .A2(new_n185_), .B(new_n227_), .Y(new_n228_));
  OA31x2_ASAP7_75t_R   g142(.A1(new_n174_), .A2(new_n214_), .A3(new_n222_), .B1(new_n228_), .Y(o18));
  AND2x2_ASAP7_75t_R   g143(.A(new_n189_), .B(new_n188_), .Y(new_n230_));
  NAND2x1_ASAP7_75t_R  g144(.A(new_n187_), .B(new_n230_), .Y(new_n231_));
  OA21x2_ASAP7_75t_R   g145(.A1(p36), .A2(new_n231_), .B(new_n219_), .Y(new_n232_));
  AOI21x1_ASAP7_75t_R  g146(.A1(new_n187_), .A2(new_n230_), .B(new_n190_), .Y(new_n233_));
  AND3x1_ASAP7_75t_R   g147(.A(new_n193_), .B(new_n207_), .C(new_n203_), .Y(new_n234_));
  AOI21x1_ASAP7_75t_R  g148(.A1(new_n198_), .A2(new_n234_), .B(new_n197_), .Y(new_n235_));
  NOR2x1_ASAP7_75t_R   g149(.A(new_n196_), .B(new_n235_), .Y(new_n236_));
  OR3x1_ASAP7_75t_R    g150(.A(new_n232_), .B(new_n233_), .C(new_n236_), .Y(new_n237_));
  AO21x1_ASAP7_75t_R   g151(.A1(new_n233_), .A2(new_n236_), .B(new_n174_), .Y(new_n238_));
  AOI21x1_ASAP7_75t_R  g152(.A1(new_n236_), .A2(new_n232_), .B(new_n238_), .Y(new_n239_));
  INVx1_ASAP7_75t_R    g153(.A(p48), .Y(new_n240_));
  INVx1_ASAP7_75t_R    g154(.A(p43), .Y(new_n241_));
  OA21x2_ASAP7_75t_R   g155(.A1(new_n197_), .A2(new_n240_), .B(new_n241_), .Y(new_n242_));
  AO22x1_ASAP7_75t_R   g156(.A1(p49), .A2(p25), .B1(p41), .B2(p55), .Y(new_n243_));
  AOI21x1_ASAP7_75t_R  g157(.A1(p35), .A2(new_n167_), .B(new_n243_), .Y(new_n244_));
  OA21x2_ASAP7_75t_R   g158(.A1(new_n242_), .A2(new_n199_), .B(new_n244_), .Y(new_n245_));
  OR3x1_ASAP7_75t_R    g159(.A(new_n235_), .B(new_n223_), .C(new_n196_), .Y(new_n246_));
  NAND2x1_ASAP7_75t_R  g160(.A(new_n245_), .B(new_n246_), .Y(new_n247_));
  AOI21x1_ASAP7_75t_R  g161(.A1(new_n237_), .A2(new_n239_), .B(new_n247_), .Y(o19));
  OA21x2_ASAP7_75t_R   g162(.A1(new_n211_), .A2(new_n210_), .B(new_n191_), .Y(new_n249_));
  XOR2x2_ASAP7_75t_R   g163(.A(new_n249_), .B(new_n219_), .Y(new_n250_));
  AO21x1_ASAP7_75t_R   g164(.A1(p48), .A2(new_n231_), .B(new_n167_), .Y(new_n251_));
  AO22x1_ASAP7_75t_R   g165(.A1(p49), .A2(p26), .B1(p41), .B2(p56), .Y(new_n252_));
  AO21x1_ASAP7_75t_R   g166(.A1(p43), .A2(new_n231_), .B(new_n252_), .Y(new_n253_));
  AO21x1_ASAP7_75t_R   g167(.A1(p47), .A2(new_n249_), .B(new_n253_), .Y(new_n254_));
  AO21x1_ASAP7_75t_R   g168(.A1(p36), .A2(new_n251_), .B(new_n254_), .Y(new_n255_));
  AOI21x1_ASAP7_75t_R  g169(.A1(p50), .A2(new_n250_), .B(new_n255_), .Y(o20));
  INVx1_ASAP7_75t_R    g170(.A(p23), .Y(new_n257_));
  AO21x1_ASAP7_75t_R   g171(.A1(new_n157_), .A2(new_n158_), .B(new_n257_), .Y(new_n258_));
  AND3x1_ASAP7_75t_R   g172(.A(new_n176_), .B(p6), .C(new_n138_), .Y(new_n259_));
  AND2x2_ASAP7_75t_R   g173(.A(p16), .B(p53), .Y(new_n260_));
  AND2x2_ASAP7_75t_R   g174(.A(p6), .B(p57), .Y(new_n261_));
  AO31x2_ASAP7_75t_R   g175(.A1(new_n108_), .A2(new_n260_), .A3(new_n144_), .B(new_n261_), .Y(new_n262_));
  NOR3x1_ASAP7_75t_R   g176(.A(new_n259_), .B(p32), .C(new_n262_), .Y(new_n263_));
  AND2x2_ASAP7_75t_R   g177(.A(p16), .B(p45), .Y(new_n264_));
  AND2x2_ASAP7_75t_R   g178(.A(p58), .B(p57), .Y(new_n265_));
  AO31x2_ASAP7_75t_R   g179(.A1(new_n108_), .A2(new_n264_), .A3(new_n144_), .B(new_n265_), .Y(new_n266_));
  NOR3x1_ASAP7_75t_R   g180(.A(new_n259_), .B(p33), .C(new_n266_), .Y(new_n267_));
  INVx1_ASAP7_75t_R    g181(.A(p24), .Y(new_n268_));
  AO21x1_ASAP7_75t_R   g182(.A1(new_n157_), .A2(new_n158_), .B(new_n268_), .Y(new_n269_));
  AOI22x1_ASAP7_75t_R  g183(.A1(new_n258_), .A2(new_n263_), .B1(new_n267_), .B2(new_n269_), .Y(new_n270_));
  AND2x2_ASAP7_75t_R   g184(.A(p15), .B(p57), .Y(new_n271_));
  NOR3x1_ASAP7_75t_R   g185(.A(new_n259_), .B(p31), .C(new_n271_), .Y(new_n272_));
  INVx1_ASAP7_75t_R    g186(.A(p6), .Y(new_n273_));
  NAND2x1_ASAP7_75t_R  g187(.A(new_n87_), .B(new_n273_), .Y(new_n274_));
  AND2x2_ASAP7_75t_R   g188(.A(p11), .B(p46), .Y(new_n275_));
  NAND2x1_ASAP7_75t_R  g189(.A(p59), .B(p6), .Y(new_n276_));
  AND4x2_ASAP7_75t_R   g190(.A(new_n274_), .B(new_n108_), .C(new_n275_), .D(new_n276_), .Y(new_n277_));
  AND3x1_ASAP7_75t_R   g191(.A(new_n156_), .B(p22), .C(new_n155_), .Y(new_n278_));
  AND2x2_ASAP7_75t_R   g192(.A(p16), .B(p54), .Y(new_n279_));
  AND3x1_ASAP7_75t_R   g193(.A(new_n108_), .B(new_n279_), .C(new_n144_), .Y(new_n280_));
  AOI211x1_ASAP7_75t_R g194(.A1(p22), .A2(new_n277_), .B(new_n278_), .C(new_n280_), .Y(new_n281_));
  NAND2x1_ASAP7_75t_R  g195(.A(new_n272_), .B(new_n281_), .Y(new_n282_));
  NAND3x1_ASAP7_75t_R  g196(.A(new_n180_), .B(new_n270_), .C(new_n282_), .Y(new_n283_));
  AO31x2_ASAP7_75t_R   g197(.A1(new_n213_), .A2(new_n184_), .A3(new_n200_), .B(new_n283_), .Y(new_n284_));
  NOR3x1_ASAP7_75t_R   g198(.A(new_n88_), .B(p44), .C(new_n273_), .Y(new_n285_));
  NAND2x1_ASAP7_75t_R  g199(.A(new_n138_), .B(new_n285_), .Y(new_n286_));
  AND3x1_ASAP7_75t_R   g200(.A(new_n144_), .B(p16), .C(p52), .Y(new_n287_));
  AOI22x1_ASAP7_75t_R  g201(.A1(new_n287_), .A2(new_n108_), .B1(p8), .B2(p57), .Y(new_n288_));
  AND2x2_ASAP7_75t_R   g202(.A(new_n286_), .B(new_n288_), .Y(new_n289_));
  NAND2x1_ASAP7_75t_R  g203(.A(p21), .B(new_n175_), .Y(new_n290_));
  INVx1_ASAP7_75t_R    g204(.A(p30), .Y(new_n291_));
  AO21x1_ASAP7_75t_R   g205(.A1(new_n289_), .A2(new_n290_), .B(new_n291_), .Y(new_n292_));
  AOI22x1_ASAP7_75t_R  g206(.A1(new_n281_), .A2(new_n272_), .B1(new_n258_), .B2(new_n263_), .Y(new_n293_));
  INVx1_ASAP7_75t_R    g207(.A(new_n266_), .Y(new_n294_));
  NAND3x1_ASAP7_75t_R  g208(.A(new_n143_), .B(new_n145_), .C(p24), .Y(new_n295_));
  OR4x2_ASAP7_75t_R    g209(.A(new_n134_), .B(new_n268_), .C(new_n135_), .D(new_n136_), .Y(new_n296_));
  AND4x2_ASAP7_75t_R   g210(.A(new_n294_), .B(new_n286_), .C(new_n295_), .D(new_n296_), .Y(new_n297_));
  INVx1_ASAP7_75t_R    g211(.A(p33), .Y(new_n298_));
  AND3x1_ASAP7_75t_R   g212(.A(new_n144_), .B(p16), .C(p53), .Y(new_n299_));
  AOI21x1_ASAP7_75t_R  g213(.A1(new_n108_), .A2(new_n299_), .B(new_n261_), .Y(new_n300_));
  NAND3x1_ASAP7_75t_R  g214(.A(new_n143_), .B(new_n145_), .C(p23), .Y(new_n301_));
  OR4x2_ASAP7_75t_R    g215(.A(new_n134_), .B(new_n257_), .C(new_n135_), .D(new_n136_), .Y(new_n302_));
  AND4x2_ASAP7_75t_R   g216(.A(new_n300_), .B(new_n301_), .C(new_n286_), .D(new_n302_), .Y(new_n303_));
  INVx1_ASAP7_75t_R    g217(.A(p32), .Y(new_n304_));
  OAI22x1_ASAP7_75t_R  g218(.A1(new_n297_), .A2(new_n298_), .B1(new_n303_), .B2(new_n304_), .Y(new_n305_));
  AOI21x1_ASAP7_75t_R  g219(.A1(p22), .A2(new_n277_), .B(new_n278_), .Y(new_n306_));
  NOR3x1_ASAP7_75t_R   g220(.A(new_n259_), .B(new_n271_), .C(new_n280_), .Y(new_n307_));
  AOI21x1_ASAP7_75t_R  g221(.A1(new_n306_), .A2(new_n307_), .B(new_n131_), .Y(new_n308_));
  AOI21x1_ASAP7_75t_R  g222(.A1(new_n293_), .A2(new_n305_), .B(new_n308_), .Y(new_n309_));
  AND2x2_ASAP7_75t_R   g223(.A(new_n292_), .B(new_n309_), .Y(new_n310_));
  AND3x1_ASAP7_75t_R   g224(.A(new_n290_), .B(new_n291_), .C(new_n289_), .Y(new_n311_));
  AO21x1_ASAP7_75t_R   g225(.A1(new_n284_), .A2(new_n310_), .B(new_n311_), .Y(o21));
  NAND2x1_ASAP7_75t_R  g226(.A(new_n269_), .B(new_n267_), .Y(new_n313_));
  NAND2x1_ASAP7_75t_R  g227(.A(new_n296_), .B(new_n295_), .Y(new_n314_));
  AO21x1_ASAP7_75t_R   g228(.A1(new_n138_), .A2(new_n285_), .B(new_n266_), .Y(new_n315_));
  OAI21x1_ASAP7_75t_R  g229(.A1(new_n314_), .A2(new_n315_), .B(p33), .Y(new_n316_));
  NAND2x1_ASAP7_75t_R  g230(.A(new_n313_), .B(new_n316_), .Y(new_n317_));
  AOI21x1_ASAP7_75t_R  g231(.A1(new_n181_), .A2(new_n182_), .B(new_n183_), .Y(new_n318_));
  AOI211x1_ASAP7_75t_R g232(.A1(p25), .A2(new_n175_), .B(new_n177_), .C(new_n179_), .Y(new_n319_));
  OAI22x1_ASAP7_75t_R  g233(.A1(new_n208_), .A2(new_n209_), .B1(new_n211_), .B2(new_n210_), .Y(new_n320_));
  AOI211x1_ASAP7_75t_R g234(.A1(new_n216_), .A2(new_n218_), .B(new_n319_), .C(new_n320_), .Y(new_n321_));
  AOI211x1_ASAP7_75t_R g235(.A1(new_n180_), .A2(new_n220_), .B(new_n318_), .C(new_n321_), .Y(new_n322_));
  NAND2x1_ASAP7_75t_R  g236(.A(new_n317_), .B(new_n322_), .Y(new_n323_));
  OA21x2_ASAP7_75t_R   g237(.A1(new_n317_), .A2(new_n322_), .B(p50), .Y(new_n324_));
  OR3x1_ASAP7_75t_R    g238(.A(new_n297_), .B(new_n298_), .C(new_n240_), .Y(new_n325_));
  AOI22x1_ASAP7_75t_R  g239(.A1(new_n167_), .A2(p33), .B1(p49), .B2(p23), .Y(new_n326_));
  OA21x2_ASAP7_75t_R   g240(.A1(new_n241_), .A2(new_n297_), .B(new_n326_), .Y(new_n327_));
  OA21x2_ASAP7_75t_R   g241(.A1(new_n223_), .A2(new_n317_), .B(new_n327_), .Y(new_n328_));
  NAND2x1_ASAP7_75t_R  g242(.A(new_n325_), .B(new_n328_), .Y(new_n329_));
  AOI21x1_ASAP7_75t_R  g243(.A1(new_n323_), .A2(new_n324_), .B(new_n329_), .Y(o22));
  NAND2x1_ASAP7_75t_R  g244(.A(new_n282_), .B(new_n270_), .Y(new_n331_));
  NAND3x1_ASAP7_75t_R  g245(.A(new_n290_), .B(new_n289_), .C(new_n291_), .Y(new_n332_));
  NAND2x1_ASAP7_75t_R  g246(.A(new_n332_), .B(new_n292_), .Y(new_n333_));
  OR3x1_ASAP7_75t_R    g247(.A(new_n322_), .B(new_n331_), .C(new_n333_), .Y(new_n334_));
  AOI21x1_ASAP7_75t_R  g248(.A1(new_n289_), .A2(new_n290_), .B(new_n291_), .Y(new_n335_));
  INVx1_ASAP7_75t_R    g249(.A(new_n308_), .Y(new_n336_));
  OAI21x1_ASAP7_75t_R  g250(.A1(new_n335_), .A2(new_n311_), .B(new_n336_), .Y(new_n337_));
  AOI21x1_ASAP7_75t_R  g251(.A1(new_n293_), .A2(new_n305_), .B(new_n337_), .Y(new_n338_));
  OAI21x1_ASAP7_75t_R  g252(.A1(new_n333_), .A2(new_n309_), .B(p50), .Y(new_n339_));
  AOI21x1_ASAP7_75t_R  g253(.A1(new_n338_), .A2(new_n284_), .B(new_n339_), .Y(new_n340_));
  AND3x1_ASAP7_75t_R   g254(.A(new_n292_), .B(p47), .C(new_n332_), .Y(new_n341_));
  NAND2x1_ASAP7_75t_R  g255(.A(new_n289_), .B(new_n290_), .Y(new_n342_));
  AND3x1_ASAP7_75t_R   g256(.A(new_n342_), .B(p30), .C(p48), .Y(new_n343_));
  AO22x1_ASAP7_75t_R   g257(.A1(p44), .A2(p49), .B1(p30), .B2(new_n167_), .Y(new_n344_));
  AO21x1_ASAP7_75t_R   g258(.A1(p43), .A2(new_n342_), .B(new_n344_), .Y(new_n345_));
  OR3x1_ASAP7_75t_R    g259(.A(new_n341_), .B(new_n343_), .C(new_n345_), .Y(new_n346_));
  AOI21x1_ASAP7_75t_R  g260(.A1(new_n334_), .A2(new_n340_), .B(new_n346_), .Y(o23));
  INVx1_ASAP7_75t_R    g261(.A(new_n270_), .Y(new_n348_));
  NAND2x1_ASAP7_75t_R  g262(.A(new_n302_), .B(new_n301_), .Y(new_n349_));
  AO21x1_ASAP7_75t_R   g263(.A1(new_n138_), .A2(new_n285_), .B(new_n262_), .Y(new_n350_));
  OAI21x1_ASAP7_75t_R  g264(.A1(new_n349_), .A2(new_n350_), .B(p32), .Y(new_n351_));
  NOR3x1_ASAP7_75t_R   g265(.A(new_n350_), .B(new_n349_), .C(p32), .Y(new_n352_));
  AOI21x1_ASAP7_75t_R  g266(.A1(new_n351_), .A2(new_n316_), .B(new_n352_), .Y(new_n353_));
  AOI21x1_ASAP7_75t_R  g267(.A1(new_n281_), .A2(new_n272_), .B(new_n308_), .Y(new_n354_));
  NOR2x1_ASAP7_75t_R   g268(.A(new_n353_), .B(new_n354_), .Y(new_n355_));
  OAI21x1_ASAP7_75t_R  g269(.A1(new_n348_), .A2(new_n322_), .B(new_n355_), .Y(new_n356_));
  INVx1_ASAP7_75t_R    g270(.A(new_n354_), .Y(new_n357_));
  AOI21x1_ASAP7_75t_R  g271(.A1(new_n353_), .A2(new_n354_), .B(new_n174_), .Y(new_n358_));
  OA31x2_ASAP7_75t_R   g272(.A1(new_n348_), .A2(new_n357_), .A3(new_n322_), .B1(new_n358_), .Y(new_n359_));
  AO21x1_ASAP7_75t_R   g273(.A1(new_n306_), .A2(new_n307_), .B(new_n241_), .Y(new_n360_));
  AOI22x1_ASAP7_75t_R  g274(.A1(new_n167_), .A2(p31), .B1(p49), .B2(p21), .Y(new_n361_));
  OA211x2_ASAP7_75t_R  g275(.A1(new_n240_), .A2(new_n336_), .B(new_n360_), .C(new_n361_), .Y(new_n362_));
  OAI21x1_ASAP7_75t_R  g276(.A1(new_n223_), .A2(new_n357_), .B(new_n362_), .Y(new_n363_));
  AOI21x1_ASAP7_75t_R  g277(.A1(new_n356_), .A2(new_n359_), .B(new_n363_), .Y(o24));
  XOR2x2_ASAP7_75t_R   g278(.A(new_n303_), .B(p32), .Y(new_n365_));
  AO21x1_ASAP7_75t_R   g279(.A1(new_n269_), .A2(new_n267_), .B(new_n365_), .Y(new_n366_));
  AO21x1_ASAP7_75t_R   g280(.A1(new_n316_), .A2(new_n322_), .B(new_n366_), .Y(new_n367_));
  AND2x2_ASAP7_75t_R   g281(.A(new_n316_), .B(new_n365_), .Y(new_n368_));
  NAND2x1_ASAP7_75t_R  g282(.A(new_n313_), .B(new_n180_), .Y(new_n369_));
  AO31x2_ASAP7_75t_R   g283(.A1(new_n213_), .A2(new_n184_), .A3(new_n200_), .B(new_n369_), .Y(new_n370_));
  AOI21x1_ASAP7_75t_R  g284(.A1(new_n368_), .A2(new_n370_), .B(new_n174_), .Y(new_n371_));
  AOI22x1_ASAP7_75t_R  g285(.A1(new_n167_), .A2(p32), .B1(p49), .B2(p22), .Y(new_n372_));
  OA21x2_ASAP7_75t_R   g286(.A1(new_n241_), .A2(new_n303_), .B(new_n372_), .Y(new_n373_));
  OA21x2_ASAP7_75t_R   g287(.A1(new_n240_), .A2(new_n351_), .B(new_n373_), .Y(new_n374_));
  OAI21x1_ASAP7_75t_R  g288(.A1(new_n223_), .A2(new_n365_), .B(new_n374_), .Y(new_n375_));
  AOI21x1_ASAP7_75t_R  g289(.A1(new_n367_), .A2(new_n371_), .B(new_n375_), .Y(o25));
endmodule


