// Benchmark "/tmp/" written by ABC on Mon Oct 12 15:07:53 2026

module \/tmp/  ( 
    p15, p38, p3, p58, p9, p52, p57, p5, p29, p31, p46, p41, p36, p1, p59,
    p0, p4, p34, p40, p14, p12, p7, p55, p49, p2, p13, p18, p20, p26, p47,
    p24, p51, p54, p56, p25, p16, p17, p35, p8, p28, p53, p45, p22, p32,
    p43, p50, p23, p11, p21, p27, p37, p42, p33, p48, p6, p10, p39, p30,
    p44, p19,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25  );
  input  p15, p38, p3, p58, p9, p52, p57, p5, p29, p31, p46, p41, p36,
    p1, p59, p0, p4, p34, p40, p14, p12, p7, p55, p49, p2, p13, p18, p20,
    p26, p47, p24, p51, p54, p56, p25, p16, p17, p35, p8, p28, p53, p45,
    p22, p32, p43, p50, p23, p11, p21, p27, p37, p42, p33, p48, p6, p10,
    p39, p30, p44, p19;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25;
  wire new_n87_, new_n89_, new_n90_, new_n91_, new_n93_, new_n96_, new_n97_,
    new_n99_, new_n106_, new_n108_, new_n110_, new_n113_, new_n114_,
    new_n115_, new_n116_, new_n117_, new_n118_, new_n119_, new_n120_,
    new_n122_, new_n123_, new_n124_, new_n125_, new_n126_, new_n127_,
    new_n128_, new_n129_, new_n130_, new_n132_, new_n133_, new_n134_,
    new_n135_, new_n136_, new_n137_, new_n138_, new_n139_, new_n140_,
    new_n141_, new_n142_, new_n143_, new_n144_, new_n145_, new_n146_,
    new_n147_, new_n148_, new_n149_, new_n150_, new_n151_, new_n152_,
    new_n153_, new_n154_, new_n155_, new_n156_, new_n157_, new_n158_,
    new_n159_, new_n160_, new_n161_, new_n162_, new_n163_, new_n164_,
    new_n165_, new_n166_, new_n167_, new_n168_, new_n169_, new_n170_,
    new_n171_, new_n172_, new_n173_, new_n174_, new_n176_, new_n177_,
    new_n178_, new_n179_, new_n180_, new_n181_, new_n182_, new_n183_,
    new_n184_, new_n185_, new_n186_, new_n187_, new_n188_, new_n189_,
    new_n190_, new_n191_, new_n192_, new_n193_, new_n194_, new_n195_,
    new_n196_, new_n197_, new_n198_, new_n199_, new_n200_, new_n201_,
    new_n202_, new_n203_, new_n204_, new_n205_, new_n206_, new_n207_,
    new_n208_, new_n209_, new_n210_, new_n211_, new_n212_, new_n213_,
    new_n214_, new_n215_, new_n216_, new_n217_, new_n218_, new_n219_,
    new_n220_, new_n221_, new_n223_, new_n224_, new_n225_, new_n226_,
    new_n227_, new_n228_, new_n229_, new_n230_, new_n231_, new_n232_,
    new_n233_, new_n234_, new_n235_, new_n236_, new_n237_, new_n238_,
    new_n239_, new_n240_, new_n241_, new_n243_, new_n244_, new_n245_,
    new_n246_, new_n247_, new_n248_, new_n249_, new_n250_, new_n251_,
    new_n252_, new_n254_, new_n255_, new_n256_, new_n257_, new_n258_,
    new_n259_, new_n260_, new_n261_, new_n262_, new_n263_, new_n264_,
    new_n265_, new_n266_, new_n267_, new_n268_, new_n269_, new_n270_,
    new_n271_, new_n272_, new_n273_, new_n274_, new_n275_, new_n276_,
    new_n277_, new_n278_, new_n279_, new_n280_, new_n281_, new_n282_,
    new_n283_, new_n284_, new_n285_, new_n286_, new_n287_, new_n288_,
    new_n289_, new_n290_, new_n291_, new_n292_, new_n293_, new_n294_,
    new_n295_, new_n296_, new_n297_, new_n298_, new_n299_, new_n300_,
    new_n301_, new_n302_, new_n303_, new_n304_, new_n306_, new_n307_,
    new_n308_, new_n309_, new_n310_, new_n311_, new_n312_, new_n313_,
    new_n314_, new_n315_, new_n316_, new_n317_, new_n318_, new_n319_,
    new_n321_, new_n322_, new_n323_, new_n324_, new_n325_, new_n326_,
    new_n327_, new_n328_, new_n329_, new_n330_, new_n331_, new_n332_,
    new_n333_, new_n334_, new_n336_, new_n337_, new_n338_, new_n339_,
    new_n340_, new_n341_, new_n342_, new_n343_, new_n344_, new_n345_,
    new_n346_, new_n347_, new_n348_, new_n349_, new_n350_, new_n352_,
    new_n353_, new_n354_, new_n355_, new_n356_, new_n357_, new_n358_,
    new_n359_, new_n360_, new_n361_, new_n362_, new_n363_, new_n364_;
  AND2x2_ASAP7_75t_R   g000(.A(p1), .B(p0), .Y(new_n87_));
  NAND2x1_ASAP7_75t_R  g001(.A(p59), .B(new_n87_), .Y(o0));
  INVx1_ASAP7_75t_R    g002(.A(p3), .Y(new_n89_));
  INVx1_ASAP7_75t_R    g003(.A(p1), .Y(new_n90_));
  INVx1_ASAP7_75t_R    g004(.A(p2), .Y(new_n91_));
  OR3x1_ASAP7_75t_R    g005(.A(new_n89_), .B(new_n90_), .C(new_n91_), .Y(o1));
  AND3x1_ASAP7_75t_R   g006(.A(p3), .B(p1), .C(p59), .Y(new_n93_));
  INVx1_ASAP7_75t_R    g007(.A(new_n93_), .Y(o2));
  NAND2x1_ASAP7_75t_R  g008(.A(p5), .B(p4), .Y(o3));
  AND2x2_ASAP7_75t_R   g009(.A(p9), .B(p8), .Y(new_n96_));
  AND2x2_ASAP7_75t_R   g010(.A(p7), .B(p6), .Y(new_n97_));
  NAND2x1_ASAP7_75t_R  g011(.A(new_n96_), .B(new_n97_), .Y(o4));
  AND2x2_ASAP7_75t_R   g012(.A(p9), .B(p10), .Y(new_n99_));
  AND3x1_ASAP7_75t_R   g013(.A(o2), .B(new_n97_), .C(new_n99_), .Y(o5));
  AND3x1_ASAP7_75t_R   g014(.A(p0), .B(p2), .C(p11), .Y(o6));
  AND3x1_ASAP7_75t_R   g015(.A(p3), .B(p2), .C(p11), .Y(o7));
  AND3x1_ASAP7_75t_R   g016(.A(p3), .B(p59), .C(p11), .Y(o8));
  OAI21x1_ASAP7_75t_R  g017(.A1(p14), .A2(p13), .B(p12), .Y(o9));
  AND3x1_ASAP7_75t_R   g018(.A(new_n93_), .B(new_n97_), .C(new_n99_), .Y(o10));
  AND3x1_ASAP7_75t_R   g019(.A(p15), .B(p9), .C(p10), .Y(new_n106_));
  INVx1_ASAP7_75t_R    g020(.A(new_n106_), .Y(o11));
  AND3x1_ASAP7_75t_R   g021(.A(new_n96_), .B(p7), .C(p16), .Y(new_n108_));
  NAND3x1_ASAP7_75t_R  g022(.A(new_n108_), .B(p1), .C(p17), .Y(o12));
  AND3x1_ASAP7_75t_R   g023(.A(new_n108_), .B(p17), .C(p11), .Y(new_n110_));
  NAND2x1_ASAP7_75t_R  g024(.A(p18), .B(new_n110_), .Y(o13));
  OAI21x1_ASAP7_75t_R  g025(.A1(p14), .A2(p13), .B(p19), .Y(o14));
  XNOR2x2_ASAP7_75t_R  g026(.A(p24), .B(p23), .Y(new_n113_));
  XOR2x2_ASAP7_75t_R   g027(.A(p28), .B(p27), .Y(new_n114_));
  XOR2x2_ASAP7_75t_R   g028(.A(new_n113_), .B(new_n114_), .Y(new_n115_));
  XOR2x2_ASAP7_75t_R   g029(.A(p20), .B(p22), .Y(new_n116_));
  XOR2x2_ASAP7_75t_R   g030(.A(new_n116_), .B(p21), .Y(new_n117_));
  XOR2x2_ASAP7_75t_R   g031(.A(new_n115_), .B(new_n117_), .Y(new_n118_));
  XOR2x2_ASAP7_75t_R   g032(.A(p29), .B(p26), .Y(new_n119_));
  XOR2x2_ASAP7_75t_R   g033(.A(new_n119_), .B(p25), .Y(new_n120_));
  XOR2x2_ASAP7_75t_R   g034(.A(new_n118_), .B(new_n120_), .Y(o15));
  XOR2x2_ASAP7_75t_R   g035(.A(p32), .B(p33), .Y(new_n122_));
  XOR2x2_ASAP7_75t_R   g036(.A(p36), .B(p37), .Y(new_n123_));
  XOR2x2_ASAP7_75t_R   g037(.A(new_n122_), .B(new_n123_), .Y(new_n124_));
  XOR2x2_ASAP7_75t_R   g038(.A(p38), .B(p34), .Y(new_n125_));
  XOR2x2_ASAP7_75t_R   g039(.A(new_n125_), .B(p35), .Y(new_n126_));
  XOR2x2_ASAP7_75t_R   g040(.A(new_n124_), .B(new_n126_), .Y(new_n127_));
  XOR2x2_ASAP7_75t_R   g041(.A(p20), .B(p30), .Y(new_n128_));
  INVx1_ASAP7_75t_R    g042(.A(p31), .Y(new_n129_));
  XOR2x2_ASAP7_75t_R   g043(.A(new_n128_), .B(new_n129_), .Y(new_n130_));
  XOR2x2_ASAP7_75t_R   g044(.A(new_n127_), .B(new_n130_), .Y(o16));
  AND2x2_ASAP7_75t_R   g045(.A(p15), .B(p6), .Y(new_n132_));
  NAND3x1_ASAP7_75t_R  g046(.A(p59), .B(p0), .C(p11), .Y(new_n133_));
  AND3x1_ASAP7_75t_R   g047(.A(new_n96_), .B(new_n132_), .C(new_n133_), .Y(new_n134_));
  INVx1_ASAP7_75t_R    g048(.A(p44), .Y(new_n135_));
  AND3x1_ASAP7_75t_R   g049(.A(new_n87_), .B(p16), .C(new_n135_), .Y(new_n136_));
  AND4x2_ASAP7_75t_R   g050(.A(p15), .B(p9), .C(p2), .D(p10), .Y(new_n137_));
  AOI22x1_ASAP7_75t_R  g051(.A1(new_n134_), .A2(p28), .B1(new_n136_), .B2(new_n137_), .Y(new_n138_));
  INVx1_ASAP7_75t_R    g052(.A(p9), .Y(new_n139_));
  OA21x2_ASAP7_75t_R   g053(.A1(p6), .A2(new_n139_), .B(p45), .Y(new_n140_));
  NAND2x1_ASAP7_75t_R  g054(.A(p46), .B(p11), .Y(new_n141_));
  AO21x1_ASAP7_75t_R   g055(.A1(new_n141_), .A2(new_n106_), .B(new_n139_), .Y(new_n142_));
  AOI21x1_ASAP7_75t_R  g056(.A1(new_n140_), .A2(new_n142_), .B(p37), .Y(new_n143_));
  NAND2x1_ASAP7_75t_R  g057(.A(p9), .B(p10), .Y(new_n144_));
  OAI21x1_ASAP7_75t_R  g058(.A1(p59), .A2(p6), .B(p15), .Y(new_n145_));
  NOR2x1_ASAP7_75t_R   g059(.A(new_n144_), .B(new_n145_), .Y(new_n146_));
  AOI21x1_ASAP7_75t_R  g060(.A1(p59), .A2(p6), .B(new_n141_), .Y(new_n147_));
  NAND3x1_ASAP7_75t_R  g061(.A(new_n146_), .B(new_n147_), .C(p28), .Y(new_n148_));
  NAND3x1_ASAP7_75t_R  g062(.A(new_n138_), .B(new_n143_), .C(new_n148_), .Y(new_n149_));
  NAND2x1_ASAP7_75t_R  g063(.A(new_n140_), .B(new_n142_), .Y(new_n150_));
  INVx1_ASAP7_75t_R    g064(.A(p37), .Y(new_n151_));
  AO31x2_ASAP7_75t_R   g065(.A1(new_n138_), .A2(new_n148_), .A3(new_n150_), .B(new_n151_), .Y(new_n152_));
  AO21x1_ASAP7_75t_R   g066(.A1(new_n149_), .A2(new_n152_), .B(p51), .Y(new_n153_));
  INVx1_ASAP7_75t_R    g067(.A(p51), .Y(new_n154_));
  AO31x2_ASAP7_75t_R   g068(.A1(new_n138_), .A2(new_n143_), .A3(new_n148_), .B(new_n154_), .Y(new_n155_));
  INVx1_ASAP7_75t_R    g069(.A(p16), .Y(new_n156_));
  NOR2x1_ASAP7_75t_R   g070(.A(p44), .B(new_n156_), .Y(new_n157_));
  AND3x1_ASAP7_75t_R   g071(.A(new_n157_), .B(new_n137_), .C(new_n87_), .Y(new_n158_));
  AOI21x1_ASAP7_75t_R  g072(.A1(new_n142_), .A2(new_n140_), .B(new_n158_), .Y(new_n159_));
  AND4x2_ASAP7_75t_R   g073(.A(p15), .B(p9), .C(p8), .D(p6), .Y(new_n160_));
  NAND2x1_ASAP7_75t_R  g074(.A(new_n133_), .B(new_n160_), .Y(new_n161_));
  NAND2x1_ASAP7_75t_R  g075(.A(new_n147_), .B(new_n146_), .Y(new_n162_));
  INVx1_ASAP7_75t_R    g076(.A(p28), .Y(new_n163_));
  AO21x1_ASAP7_75t_R   g077(.A1(new_n161_), .A2(new_n162_), .B(new_n163_), .Y(new_n164_));
  AOI21x1_ASAP7_75t_R  g078(.A1(new_n159_), .A2(new_n164_), .B(new_n151_), .Y(new_n165_));
  OA21x2_ASAP7_75t_R   g079(.A1(new_n155_), .A2(new_n165_), .B(p50), .Y(new_n166_));
  AND3x1_ASAP7_75t_R   g080(.A(new_n152_), .B(p47), .C(new_n149_), .Y(new_n167_));
  NAND2x1_ASAP7_75t_R  g081(.A(new_n159_), .B(new_n164_), .Y(new_n168_));
  AO21x1_ASAP7_75t_R   g082(.A1(p37), .A2(p48), .B(p43), .Y(new_n169_));
  AND3x1_ASAP7_75t_R   g083(.A(p59), .B(p40), .C(p39), .Y(new_n170_));
  AND2x2_ASAP7_75t_R   g084(.A(new_n170_), .B(new_n110_), .Y(new_n171_));
  AO22x1_ASAP7_75t_R   g085(.A1(p41), .A2(p42), .B1(p49), .B2(p27), .Y(new_n172_));
  AO21x1_ASAP7_75t_R   g086(.A1(p37), .A2(new_n171_), .B(new_n172_), .Y(new_n173_));
  AO21x1_ASAP7_75t_R   g087(.A1(new_n168_), .A2(new_n169_), .B(new_n173_), .Y(new_n174_));
  AOI211x1_ASAP7_75t_R g088(.A1(new_n153_), .A2(new_n166_), .B(new_n167_), .C(new_n174_), .Y(o17));
  NAND2x1_ASAP7_75t_R  g089(.A(new_n161_), .B(new_n162_), .Y(new_n176_));
  NAND2x1_ASAP7_75t_R  g090(.A(p25), .B(new_n176_), .Y(new_n177_));
  INVx1_ASAP7_75t_R    g091(.A(p52), .Y(new_n178_));
  AND3x1_ASAP7_75t_R   g092(.A(new_n99_), .B(new_n132_), .C(new_n141_), .Y(new_n179_));
  NOR2x1_ASAP7_75t_R   g093(.A(new_n139_), .B(new_n179_), .Y(new_n180_));
  NAND3x1_ASAP7_75t_R  g094(.A(new_n157_), .B(new_n137_), .C(new_n87_), .Y(new_n181_));
  OA21x2_ASAP7_75t_R   g095(.A1(new_n178_), .A2(new_n180_), .B(new_n181_), .Y(new_n182_));
  INVx1_ASAP7_75t_R    g096(.A(p34), .Y(new_n183_));
  AOI21x1_ASAP7_75t_R  g097(.A1(new_n177_), .A2(new_n182_), .B(new_n183_), .Y(new_n184_));
  OA21x2_ASAP7_75t_R   g098(.A1(p6), .A2(new_n139_), .B(p54), .Y(new_n185_));
  AO21x1_ASAP7_75t_R   g099(.A1(new_n185_), .A2(new_n142_), .B(p35), .Y(new_n186_));
  NAND3x1_ASAP7_75t_R  g100(.A(new_n146_), .B(new_n147_), .C(p26), .Y(new_n187_));
  NAND3x1_ASAP7_75t_R  g101(.A(new_n160_), .B(p26), .C(new_n133_), .Y(new_n188_));
  NAND3x1_ASAP7_75t_R  g102(.A(new_n187_), .B(new_n188_), .C(new_n181_), .Y(new_n189_));
  NOR2x1_ASAP7_75t_R   g103(.A(new_n186_), .B(new_n189_), .Y(new_n190_));
  AOI22x1_ASAP7_75t_R  g104(.A1(new_n134_), .A2(p27), .B1(new_n136_), .B2(new_n137_), .Y(new_n191_));
  OA21x2_ASAP7_75t_R   g105(.A1(p6), .A2(new_n139_), .B(p53), .Y(new_n192_));
  NAND2x1_ASAP7_75t_R  g106(.A(new_n192_), .B(new_n142_), .Y(new_n193_));
  NAND3x1_ASAP7_75t_R  g107(.A(new_n146_), .B(new_n147_), .C(p27), .Y(new_n194_));
  INVx1_ASAP7_75t_R    g108(.A(p36), .Y(new_n195_));
  AO31x2_ASAP7_75t_R   g109(.A1(new_n191_), .A2(new_n193_), .A3(new_n194_), .B(new_n195_), .Y(new_n196_));
  AND2x2_ASAP7_75t_R   g110(.A(new_n185_), .B(new_n142_), .Y(new_n197_));
  OAI21x1_ASAP7_75t_R  g111(.A1(new_n197_), .A2(new_n189_), .B(p35), .Y(new_n198_));
  OAI21x1_ASAP7_75t_R  g112(.A1(new_n190_), .A2(new_n196_), .B(new_n198_), .Y(new_n199_));
  NAND3x1_ASAP7_75t_R  g113(.A(new_n160_), .B(p27), .C(new_n133_), .Y(new_n200_));
  NAND3x1_ASAP7_75t_R  g114(.A(new_n194_), .B(new_n181_), .C(new_n200_), .Y(new_n201_));
  AO21x1_ASAP7_75t_R   g115(.A1(new_n192_), .A2(new_n142_), .B(p36), .Y(new_n202_));
  OAI22x1_ASAP7_75t_R  g116(.A1(new_n189_), .A2(new_n186_), .B1(new_n201_), .B2(new_n202_), .Y(new_n203_));
  AOI21x1_ASAP7_75t_R  g117(.A1(new_n152_), .A2(new_n155_), .B(new_n203_), .Y(new_n204_));
  NAND3x1_ASAP7_75t_R  g118(.A(new_n182_), .B(new_n183_), .C(new_n177_), .Y(new_n205_));
  OAI21x1_ASAP7_75t_R  g119(.A1(new_n199_), .A2(new_n204_), .B(new_n205_), .Y(new_n206_));
  NOR2x1_ASAP7_75t_R   g120(.A(new_n184_), .B(new_n206_), .Y(new_n207_));
  AND3x1_ASAP7_75t_R   g121(.A(new_n182_), .B(new_n183_), .C(new_n177_), .Y(new_n208_));
  NOR2x1_ASAP7_75t_R   g122(.A(new_n184_), .B(new_n208_), .Y(new_n209_));
  AOI21x1_ASAP7_75t_R  g123(.A1(p51), .A2(new_n149_), .B(new_n165_), .Y(new_n210_));
  OA21x2_ASAP7_75t_R   g124(.A1(new_n190_), .A2(new_n196_), .B(new_n198_), .Y(new_n211_));
  OAI21x1_ASAP7_75t_R  g125(.A1(new_n203_), .A2(new_n210_), .B(new_n211_), .Y(new_n212_));
  OAI21x1_ASAP7_75t_R  g126(.A1(new_n209_), .A2(new_n212_), .B(p50), .Y(new_n213_));
  INVx1_ASAP7_75t_R    g127(.A(p48), .Y(new_n214_));
  INVx1_ASAP7_75t_R    g128(.A(new_n184_), .Y(new_n215_));
  INVx1_ASAP7_75t_R    g129(.A(p43), .Y(new_n216_));
  AO21x1_ASAP7_75t_R   g130(.A1(new_n177_), .A2(new_n182_), .B(new_n216_), .Y(new_n217_));
  AOI22x1_ASAP7_75t_R  g131(.A1(new_n171_), .A2(p34), .B1(p49), .B2(p24), .Y(new_n218_));
  OA211x2_ASAP7_75t_R  g132(.A1(new_n214_), .A2(new_n215_), .B(new_n217_), .C(new_n218_), .Y(new_n219_));
  INVx1_ASAP7_75t_R    g133(.A(p47), .Y(new_n220_));
  OR3x1_ASAP7_75t_R    g134(.A(new_n208_), .B(new_n184_), .C(new_n220_), .Y(new_n221_));
  OA211x2_ASAP7_75t_R  g135(.A1(new_n207_), .A2(new_n213_), .B(new_n219_), .C(new_n221_), .Y(o18));
  NOR2x1_ASAP7_75t_R   g136(.A(new_n202_), .B(new_n201_), .Y(new_n223_));
  NOR2x1_ASAP7_75t_R   g137(.A(new_n223_), .B(new_n210_), .Y(new_n224_));
  AOI21x1_ASAP7_75t_R  g138(.A1(new_n142_), .A2(new_n192_), .B(new_n158_), .Y(new_n225_));
  INVx1_ASAP7_75t_R    g139(.A(p27), .Y(new_n226_));
  AO21x1_ASAP7_75t_R   g140(.A1(new_n161_), .A2(new_n162_), .B(new_n226_), .Y(new_n227_));
  AOI21x1_ASAP7_75t_R  g141(.A1(new_n225_), .A2(new_n227_), .B(new_n195_), .Y(new_n228_));
  OA21x2_ASAP7_75t_R   g142(.A1(new_n189_), .A2(new_n186_), .B(new_n198_), .Y(new_n229_));
  OR3x1_ASAP7_75t_R    g143(.A(new_n224_), .B(new_n228_), .C(new_n229_), .Y(new_n230_));
  INVx1_ASAP7_75t_R    g144(.A(p50), .Y(new_n231_));
  OA21x2_ASAP7_75t_R   g145(.A1(new_n228_), .A2(new_n224_), .B(new_n229_), .Y(new_n232_));
  NOR2x1_ASAP7_75t_R   g146(.A(new_n231_), .B(new_n232_), .Y(new_n233_));
  AOI21x1_ASAP7_75t_R  g147(.A1(new_n142_), .A2(new_n185_), .B(new_n158_), .Y(new_n234_));
  AND2x2_ASAP7_75t_R   g148(.A(new_n188_), .B(new_n187_), .Y(new_n235_));
  NAND2x1_ASAP7_75t_R  g149(.A(new_n234_), .B(new_n235_), .Y(new_n236_));
  AO21x1_ASAP7_75t_R   g150(.A1(p48), .A2(new_n236_), .B(new_n171_), .Y(new_n237_));
  AO22x1_ASAP7_75t_R   g151(.A1(p41), .A2(p55), .B1(p49), .B2(p25), .Y(new_n238_));
  AO21x1_ASAP7_75t_R   g152(.A1(p43), .A2(new_n236_), .B(new_n238_), .Y(new_n239_));
  AO21x1_ASAP7_75t_R   g153(.A1(p47), .A2(new_n229_), .B(new_n239_), .Y(new_n240_));
  AO21x1_ASAP7_75t_R   g154(.A1(p35), .A2(new_n237_), .B(new_n240_), .Y(new_n241_));
  AOI21x1_ASAP7_75t_R  g155(.A1(new_n230_), .A2(new_n233_), .B(new_n241_), .Y(o19));
  OAI21x1_ASAP7_75t_R  g156(.A1(new_n201_), .A2(new_n202_), .B(new_n196_), .Y(new_n243_));
  AO21x1_ASAP7_75t_R   g157(.A1(new_n243_), .A2(new_n210_), .B(new_n231_), .Y(new_n244_));
  AO21x1_ASAP7_75t_R   g158(.A1(new_n196_), .A2(new_n224_), .B(new_n244_), .Y(new_n245_));
  OR3x1_ASAP7_75t_R    g159(.A(new_n228_), .B(new_n220_), .C(new_n223_), .Y(new_n246_));
  AO21x1_ASAP7_75t_R   g160(.A1(new_n225_), .A2(new_n227_), .B(new_n214_), .Y(new_n247_));
  INVx1_ASAP7_75t_R    g161(.A(new_n171_), .Y(new_n248_));
  AO21x1_ASAP7_75t_R   g162(.A1(new_n247_), .A2(new_n248_), .B(new_n195_), .Y(new_n249_));
  AOI22x1_ASAP7_75t_R  g163(.A1(p41), .A2(p56), .B1(p49), .B2(p26), .Y(new_n250_));
  AO21x1_ASAP7_75t_R   g164(.A1(new_n225_), .A2(new_n227_), .B(new_n216_), .Y(new_n251_));
  AND3x1_ASAP7_75t_R   g165(.A(new_n249_), .B(new_n250_), .C(new_n251_), .Y(new_n252_));
  AND3x1_ASAP7_75t_R   g166(.A(new_n245_), .B(new_n246_), .C(new_n252_), .Y(o20));
  AND3x1_ASAP7_75t_R   g167(.A(new_n87_), .B(p6), .C(new_n135_), .Y(new_n254_));
  AND2x2_ASAP7_75t_R   g168(.A(p52), .B(p16), .Y(new_n255_));
  AND3x1_ASAP7_75t_R   g169(.A(new_n106_), .B(new_n255_), .C(new_n141_), .Y(new_n256_));
  AND2x2_ASAP7_75t_R   g170(.A(p57), .B(p8), .Y(new_n257_));
  AOI211x1_ASAP7_75t_R g171(.A1(new_n137_), .A2(new_n254_), .B(new_n256_), .C(new_n257_), .Y(new_n258_));
  INVx1_ASAP7_75t_R    g172(.A(p21), .Y(new_n259_));
  AO21x1_ASAP7_75t_R   g173(.A1(new_n161_), .A2(new_n162_), .B(new_n259_), .Y(new_n260_));
  INVx1_ASAP7_75t_R    g174(.A(p30), .Y(new_n261_));
  AOI21x1_ASAP7_75t_R  g175(.A1(new_n258_), .A2(new_n260_), .B(new_n261_), .Y(new_n262_));
  AOI22x1_ASAP7_75t_R  g176(.A1(new_n254_), .A2(new_n137_), .B1(p57), .B2(p6), .Y(new_n263_));
  INVx1_ASAP7_75t_R    g177(.A(p32), .Y(new_n264_));
  AND3x1_ASAP7_75t_R   g178(.A(new_n141_), .B(p16), .C(p53), .Y(new_n265_));
  NAND2x1_ASAP7_75t_R  g179(.A(new_n106_), .B(new_n265_), .Y(new_n266_));
  AND3x1_ASAP7_75t_R   g180(.A(new_n263_), .B(new_n264_), .C(new_n266_), .Y(new_n267_));
  NAND2x1_ASAP7_75t_R  g181(.A(p23), .B(new_n176_), .Y(new_n268_));
  INVx1_ASAP7_75t_R    g182(.A(p22), .Y(new_n269_));
  AO21x1_ASAP7_75t_R   g183(.A1(new_n161_), .A2(new_n162_), .B(new_n269_), .Y(new_n270_));
  AND2x2_ASAP7_75t_R   g184(.A(p15), .B(p57), .Y(new_n271_));
  AND2x2_ASAP7_75t_R   g185(.A(p54), .B(p16), .Y(new_n272_));
  AND3x1_ASAP7_75t_R   g186(.A(new_n106_), .B(new_n272_), .C(new_n141_), .Y(new_n273_));
  NOR2x1_ASAP7_75t_R   g187(.A(new_n271_), .B(new_n273_), .Y(new_n274_));
  NAND2x1_ASAP7_75t_R  g188(.A(new_n137_), .B(new_n254_), .Y(new_n275_));
  AND3x1_ASAP7_75t_R   g189(.A(new_n274_), .B(new_n129_), .C(new_n275_), .Y(new_n276_));
  AOI22x1_ASAP7_75t_R  g190(.A1(new_n267_), .A2(new_n268_), .B1(new_n270_), .B2(new_n276_), .Y(new_n277_));
  NAND2x1_ASAP7_75t_R  g191(.A(p23), .B(new_n134_), .Y(new_n278_));
  NAND3x1_ASAP7_75t_R  g192(.A(new_n146_), .B(new_n147_), .C(p23), .Y(new_n279_));
  AND4x2_ASAP7_75t_R   g193(.A(new_n263_), .B(new_n278_), .C(new_n266_), .D(new_n279_), .Y(new_n280_));
  INVx1_ASAP7_75t_R    g194(.A(p33), .Y(new_n281_));
  NAND2x1_ASAP7_75t_R  g195(.A(p24), .B(new_n134_), .Y(new_n282_));
  AND3x1_ASAP7_75t_R   g196(.A(new_n141_), .B(p16), .C(p45), .Y(new_n283_));
  AND2x2_ASAP7_75t_R   g197(.A(p58), .B(p57), .Y(new_n284_));
  AOI21x1_ASAP7_75t_R  g198(.A1(new_n106_), .A2(new_n283_), .B(new_n284_), .Y(new_n285_));
  NAND3x1_ASAP7_75t_R  g199(.A(new_n146_), .B(new_n147_), .C(p24), .Y(new_n286_));
  AND4x2_ASAP7_75t_R   g200(.A(new_n282_), .B(new_n275_), .C(new_n285_), .D(new_n286_), .Y(new_n287_));
  OAI22x1_ASAP7_75t_R  g201(.A1(new_n280_), .A2(new_n264_), .B1(new_n281_), .B2(new_n287_), .Y(new_n288_));
  AOI211x1_ASAP7_75t_R g202(.A1(new_n137_), .A2(new_n254_), .B(new_n273_), .C(new_n271_), .Y(new_n289_));
  AO21x1_ASAP7_75t_R   g203(.A1(new_n289_), .A2(new_n270_), .B(new_n129_), .Y(new_n290_));
  INVx1_ASAP7_75t_R    g204(.A(new_n290_), .Y(new_n291_));
  AO21x1_ASAP7_75t_R   g205(.A1(new_n277_), .A2(new_n288_), .B(new_n291_), .Y(new_n292_));
  NOR2x1_ASAP7_75t_R   g206(.A(new_n262_), .B(new_n292_), .Y(new_n293_));
  NOR3x1_ASAP7_75t_R   g207(.A(new_n204_), .B(new_n199_), .C(new_n184_), .Y(new_n294_));
  INVx1_ASAP7_75t_R    g208(.A(new_n277_), .Y(new_n295_));
  NAND2x1_ASAP7_75t_R  g209(.A(new_n281_), .B(new_n287_), .Y(new_n296_));
  NAND2x1_ASAP7_75t_R  g210(.A(new_n296_), .B(new_n205_), .Y(new_n297_));
  OR3x1_ASAP7_75t_R    g211(.A(new_n294_), .B(new_n295_), .C(new_n297_), .Y(new_n298_));
  INVx1_ASAP7_75t_R    g212(.A(new_n137_), .Y(new_n299_));
  NAND3x1_ASAP7_75t_R  g213(.A(new_n87_), .B(p6), .C(new_n135_), .Y(new_n300_));
  AND3x1_ASAP7_75t_R   g214(.A(new_n141_), .B(p52), .C(p16), .Y(new_n301_));
  AOI21x1_ASAP7_75t_R  g215(.A1(new_n106_), .A2(new_n301_), .B(new_n257_), .Y(new_n302_));
  OAI21x1_ASAP7_75t_R  g216(.A1(new_n299_), .A2(new_n300_), .B(new_n302_), .Y(new_n303_));
  AOI211x1_ASAP7_75t_R g217(.A1(p21), .A2(new_n176_), .B(p30), .C(new_n303_), .Y(new_n304_));
  AO21x1_ASAP7_75t_R   g218(.A1(new_n293_), .A2(new_n298_), .B(new_n304_), .Y(o21));
  NOR2x1_ASAP7_75t_R   g219(.A(new_n281_), .B(new_n287_), .Y(new_n306_));
  AND2x2_ASAP7_75t_R   g220(.A(new_n286_), .B(new_n282_), .Y(new_n307_));
  AND2x2_ASAP7_75t_R   g221(.A(new_n285_), .B(new_n275_), .Y(new_n308_));
  AND3x1_ASAP7_75t_R   g222(.A(new_n307_), .B(new_n308_), .C(new_n281_), .Y(new_n309_));
  NOR2x1_ASAP7_75t_R   g223(.A(new_n306_), .B(new_n309_), .Y(new_n310_));
  INVx1_ASAP7_75t_R    g224(.A(new_n310_), .Y(new_n311_));
  NOR2x1_ASAP7_75t_R   g225(.A(new_n206_), .B(new_n311_), .Y(new_n312_));
  AO21x1_ASAP7_75t_R   g226(.A1(new_n184_), .A2(new_n310_), .B(new_n231_), .Y(new_n313_));
  AND3x1_ASAP7_75t_R   g227(.A(new_n311_), .B(new_n215_), .C(new_n206_), .Y(new_n314_));
  AOI22x1_ASAP7_75t_R  g228(.A1(new_n171_), .A2(p33), .B1(p49), .B2(p23), .Y(new_n315_));
  OA21x2_ASAP7_75t_R   g229(.A1(new_n216_), .A2(new_n287_), .B(new_n315_), .Y(new_n316_));
  OR3x1_ASAP7_75t_R    g230(.A(new_n309_), .B(new_n220_), .C(new_n306_), .Y(new_n317_));
  OR3x1_ASAP7_75t_R    g231(.A(new_n287_), .B(new_n281_), .C(new_n214_), .Y(new_n318_));
  AND3x1_ASAP7_75t_R   g232(.A(new_n316_), .B(new_n317_), .C(new_n318_), .Y(new_n319_));
  OA31x2_ASAP7_75t_R   g233(.A1(new_n312_), .A2(new_n313_), .A3(new_n314_), .B1(new_n319_), .Y(o22));
  NOR2x1_ASAP7_75t_R   g234(.A(new_n262_), .B(new_n304_), .Y(new_n321_));
  AO21x1_ASAP7_75t_R   g235(.A1(new_n321_), .A2(new_n292_), .B(new_n231_), .Y(new_n322_));
  OR3x1_ASAP7_75t_R    g236(.A(new_n204_), .B(new_n199_), .C(new_n184_), .Y(new_n323_));
  NOR2x1_ASAP7_75t_R   g237(.A(new_n309_), .B(new_n208_), .Y(new_n324_));
  AND4x2_ASAP7_75t_R   g238(.A(new_n323_), .B(new_n277_), .C(new_n324_), .D(new_n321_), .Y(new_n325_));
  OAI21x1_ASAP7_75t_R  g239(.A1(new_n262_), .A2(new_n304_), .B(new_n290_), .Y(new_n326_));
  AOI21x1_ASAP7_75t_R  g240(.A1(new_n277_), .A2(new_n288_), .B(new_n326_), .Y(new_n327_));
  OA31x2_ASAP7_75t_R   g241(.A1(new_n295_), .A2(new_n297_), .A3(new_n294_), .B1(new_n327_), .Y(new_n328_));
  AO21x1_ASAP7_75t_R   g242(.A1(new_n258_), .A2(new_n260_), .B(new_n216_), .Y(new_n329_));
  NAND2x1_ASAP7_75t_R  g243(.A(p49), .B(p44), .Y(new_n330_));
  OA211x2_ASAP7_75t_R  g244(.A1(new_n261_), .A2(new_n248_), .B(new_n329_), .C(new_n330_), .Y(new_n331_));
  OR3x1_ASAP7_75t_R    g245(.A(new_n304_), .B(new_n262_), .C(new_n220_), .Y(new_n332_));
  NAND2x1_ASAP7_75t_R  g246(.A(p48), .B(new_n262_), .Y(new_n333_));
  AND3x1_ASAP7_75t_R   g247(.A(new_n331_), .B(new_n332_), .C(new_n333_), .Y(new_n334_));
  OA31x2_ASAP7_75t_R   g248(.A1(new_n322_), .A2(new_n325_), .A3(new_n328_), .B1(new_n334_), .Y(o23));
  NAND2x1_ASAP7_75t_R  g249(.A(new_n268_), .B(new_n267_), .Y(new_n336_));
  AOI21x1_ASAP7_75t_R  g250(.A1(new_n270_), .A2(new_n276_), .B(new_n291_), .Y(new_n337_));
  AOI21x1_ASAP7_75t_R  g251(.A1(new_n336_), .A2(new_n288_), .B(new_n337_), .Y(new_n338_));
  NAND2x1_ASAP7_75t_R  g252(.A(new_n296_), .B(new_n336_), .Y(new_n339_));
  AO21x1_ASAP7_75t_R   g253(.A1(new_n215_), .A2(new_n206_), .B(new_n339_), .Y(new_n340_));
  NAND2x1_ASAP7_75t_R  g254(.A(new_n338_), .B(new_n340_), .Y(new_n341_));
  AOI21x1_ASAP7_75t_R  g255(.A1(new_n215_), .A2(new_n206_), .B(new_n339_), .Y(new_n342_));
  AND2x2_ASAP7_75t_R   g256(.A(new_n277_), .B(new_n288_), .Y(new_n343_));
  AO21x1_ASAP7_75t_R   g257(.A1(new_n290_), .A2(new_n343_), .B(new_n231_), .Y(new_n344_));
  AOI21x1_ASAP7_75t_R  g258(.A1(new_n337_), .A2(new_n342_), .B(new_n344_), .Y(new_n345_));
  NAND2x1_ASAP7_75t_R  g259(.A(new_n289_), .B(new_n270_), .Y(new_n346_));
  AO22x1_ASAP7_75t_R   g260(.A1(p49), .A2(p21), .B1(p31), .B2(new_n171_), .Y(new_n347_));
  AO21x1_ASAP7_75t_R   g261(.A1(p43), .A2(new_n346_), .B(new_n347_), .Y(new_n348_));
  AOI21x1_ASAP7_75t_R  g262(.A1(p47), .A2(new_n337_), .B(new_n348_), .Y(new_n349_));
  OAI21x1_ASAP7_75t_R  g263(.A1(new_n214_), .A2(new_n290_), .B(new_n349_), .Y(new_n350_));
  AOI21x1_ASAP7_75t_R  g264(.A1(new_n341_), .A2(new_n345_), .B(new_n350_), .Y(o24));
  NAND2x1_ASAP7_75t_R  g265(.A(new_n215_), .B(new_n206_), .Y(new_n352_));
  AND3x1_ASAP7_75t_R   g266(.A(new_n278_), .B(new_n266_), .C(new_n279_), .Y(new_n353_));
  AO21x1_ASAP7_75t_R   g267(.A1(new_n263_), .A2(new_n353_), .B(new_n264_), .Y(new_n354_));
  AND3x1_ASAP7_75t_R   g268(.A(new_n354_), .B(new_n336_), .C(new_n296_), .Y(new_n355_));
  OAI21x1_ASAP7_75t_R  g269(.A1(new_n306_), .A2(new_n352_), .B(new_n355_), .Y(new_n356_));
  NAND2x1_ASAP7_75t_R  g270(.A(new_n336_), .B(new_n354_), .Y(new_n357_));
  OA21x2_ASAP7_75t_R   g271(.A1(new_n281_), .A2(new_n287_), .B(new_n357_), .Y(new_n358_));
  OAI21x1_ASAP7_75t_R  g272(.A1(new_n184_), .A2(new_n212_), .B(new_n324_), .Y(new_n359_));
  AOI21x1_ASAP7_75t_R  g273(.A1(new_n358_), .A2(new_n359_), .B(new_n231_), .Y(new_n360_));
  AOI22x1_ASAP7_75t_R  g274(.A1(new_n171_), .A2(p32), .B1(p49), .B2(p22), .Y(new_n361_));
  OA21x2_ASAP7_75t_R   g275(.A1(new_n216_), .A2(new_n280_), .B(new_n361_), .Y(new_n362_));
  OA21x2_ASAP7_75t_R   g276(.A1(new_n214_), .A2(new_n354_), .B(new_n362_), .Y(new_n363_));
  OAI21x1_ASAP7_75t_R  g277(.A1(new_n220_), .A2(new_n357_), .B(new_n363_), .Y(new_n364_));
  AOI21x1_ASAP7_75t_R  g278(.A1(new_n356_), .A2(new_n360_), .B(new_n364_), .Y(o25));
endmodule


