// Benchmark "/tmp/" written by ABC on Mon Oct 12 15:07:53 2026

module \/tmp/  ( 
    p21, p12, p8, p42, p48, p40, p46, p16, p19, p4, p31, p22, p20, p17, p7,
    p29, p43, p15, p2, p52, p51, p32, p57, p50, p55, p23, p36, p3, p5, p27,
    p54, p13, p53, p44, p33, p11, p18, p49, p38, p25, p56, p9, p34, p28,
    p6, p45, p37, p14, p30, p47, p39, p58, p0, p41, p24, p10, p1, p59, p35,
    p26,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25  );
  input  p21, p12, p8, p42, p48, p40, p46, p16, p19, p4, p31, p22, p20,
    p17, p7, p29, p43, p15, p2, p52, p51, p32, p57, p50, p55, p23, p36, p3,
    p5, p27, p54, p13, p53, p44, p33, p11, p18, p49, p38, p25, p56, p9,
    p34, p28, p6, p45, p37, p14, p30, p47, p39, p58, p0, p41, p24, p10, p1,
    p59, p35, p26;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25;
  wire new_n87_, new_n88_, new_n90_, new_n91_, new_n92_, new_n94_, new_n97_,
    new_n98_, new_n99_, new_n101_, new_n108_, new_n110_, new_n112_,
    new_n115_, new_n116_, new_n117_, new_n118_, new_n119_, new_n120_,
    new_n121_, new_n122_, new_n124_, new_n125_, new_n126_, new_n127_,
    new_n128_, new_n129_, new_n130_, new_n131_, new_n132_, new_n134_,
    new_n135_, new_n136_, new_n137_, new_n138_, new_n139_, new_n140_,
    new_n141_, new_n142_, new_n143_, new_n144_, new_n145_, new_n146_,
    new_n147_, new_n148_, new_n149_, new_n150_, new_n151_, new_n152_,
    new_n153_, new_n154_, new_n155_, new_n156_, new_n157_, new_n158_,
    new_n159_, new_n160_, new_n161_, new_n162_, new_n163_, new_n164_,
    new_n165_, new_n166_, new_n167_, new_n168_, new_n169_, new_n170_,
    new_n171_, new_n172_, new_n173_, new_n174_, new_n175_, new_n176_,
    new_n177_, new_n178_, new_n179_, new_n180_, new_n182_, new_n183_,
    new_n184_, new_n185_, new_n186_, new_n187_, new_n188_, new_n189_,
    new_n190_, new_n191_, new_n192_, new_n193_, new_n194_, new_n195_,
    new_n196_, new_n197_, new_n198_, new_n199_, new_n200_, new_n201_,
    new_n202_, new_n203_, new_n204_, new_n205_, new_n206_, new_n207_,
    new_n208_, new_n209_, new_n210_, new_n211_, new_n212_, new_n213_,
    new_n214_, new_n215_, new_n216_, new_n217_, new_n218_, new_n219_,
    new_n220_, new_n221_, new_n222_, new_n223_, new_n224_, new_n225_,
    new_n226_, new_n227_, new_n228_, new_n229_, new_n230_, new_n231_,
    new_n233_, new_n234_, new_n235_, new_n236_, new_n237_, new_n238_,
    new_n239_, new_n240_, new_n241_, new_n242_, new_n243_, new_n244_,
    new_n245_, new_n246_, new_n247_, new_n248_, new_n249_, new_n250_,
    new_n251_, new_n252_, new_n254_, new_n255_, new_n256_, new_n257_,
    new_n258_, new_n259_, new_n260_, new_n261_, new_n263_, new_n264_,
    new_n265_, new_n266_, new_n267_, new_n268_, new_n269_, new_n270_,
    new_n271_, new_n272_, new_n273_, new_n274_, new_n275_, new_n276_,
    new_n277_, new_n278_, new_n279_, new_n280_, new_n281_, new_n282_,
    new_n283_, new_n284_, new_n285_, new_n286_, new_n287_, new_n288_,
    new_n289_, new_n290_, new_n291_, new_n292_, new_n293_, new_n294_,
    new_n295_, new_n296_, new_n297_, new_n298_, new_n299_, new_n300_,
    new_n301_, new_n302_, new_n303_, new_n304_, new_n305_, new_n306_,
    new_n307_, new_n308_, new_n309_, new_n310_, new_n311_, new_n312_,
    new_n313_, new_n315_, new_n316_, new_n317_, new_n318_, new_n319_,
    new_n320_, new_n321_, new_n322_, new_n323_, new_n324_, new_n326_,
    new_n327_, new_n328_, new_n329_, new_n330_, new_n331_, new_n332_,
    new_n333_, new_n334_, new_n335_, new_n336_, new_n337_, new_n338_,
    new_n340_, new_n341_, new_n342_, new_n343_, new_n344_, new_n345_,
    new_n346_, new_n347_, new_n348_, new_n349_, new_n350_, new_n351_,
    new_n352_, new_n353_, new_n354_, new_n355_, new_n356_, new_n358_,
    new_n359_, new_n360_, new_n361_, new_n362_, new_n363_, new_n364_,
    new_n365_, new_n366_;
  INVx1_ASAP7_75t_R    g000(.A(p59), .Y(new_n87_));
  NAND2x1_ASAP7_75t_R  g001(.A(p0), .B(p1), .Y(new_n88_));
  OR2x4_ASAP7_75t_R    g002(.A(new_n87_), .B(new_n88_), .Y(o0));
  INVx1_ASAP7_75t_R    g003(.A(p2), .Y(new_n90_));
  INVx1_ASAP7_75t_R    g004(.A(p3), .Y(new_n91_));
  INVx1_ASAP7_75t_R    g005(.A(p1), .Y(new_n92_));
  OR3x1_ASAP7_75t_R    g006(.A(new_n90_), .B(new_n91_), .C(new_n92_), .Y(o1));
  AND3x1_ASAP7_75t_R   g007(.A(p3), .B(p1), .C(p59), .Y(new_n94_));
  INVx1_ASAP7_75t_R    g008(.A(new_n94_), .Y(o2));
  NAND2x1_ASAP7_75t_R  g009(.A(p4), .B(p5), .Y(o3));
  AND2x2_ASAP7_75t_R   g010(.A(p7), .B(p6), .Y(new_n97_));
  NAND2x1_ASAP7_75t_R  g011(.A(p8), .B(p9), .Y(new_n98_));
  INVx1_ASAP7_75t_R    g012(.A(new_n98_), .Y(new_n99_));
  NAND2x1_ASAP7_75t_R  g013(.A(new_n97_), .B(new_n99_), .Y(o4));
  AND2x2_ASAP7_75t_R   g014(.A(p9), .B(p10), .Y(new_n101_));
  AND3x1_ASAP7_75t_R   g015(.A(o2), .B(new_n97_), .C(new_n101_), .Y(o5));
  AND3x1_ASAP7_75t_R   g016(.A(p2), .B(p11), .C(p0), .Y(o6));
  AND3x1_ASAP7_75t_R   g017(.A(p2), .B(p3), .C(p11), .Y(o7));
  AND3x1_ASAP7_75t_R   g018(.A(p3), .B(p11), .C(p59), .Y(o8));
  OAI21x1_ASAP7_75t_R  g019(.A1(p13), .A2(p14), .B(p12), .Y(o9));
  AND3x1_ASAP7_75t_R   g020(.A(new_n94_), .B(new_n97_), .C(new_n101_), .Y(o10));
  AND3x1_ASAP7_75t_R   g021(.A(p15), .B(p9), .C(p10), .Y(new_n108_));
  INVx1_ASAP7_75t_R    g022(.A(new_n108_), .Y(o11));
  AND3x1_ASAP7_75t_R   g023(.A(new_n99_), .B(p16), .C(p7), .Y(new_n110_));
  NAND3x1_ASAP7_75t_R  g024(.A(new_n110_), .B(p17), .C(p1), .Y(o12));
  AND3x1_ASAP7_75t_R   g025(.A(new_n110_), .B(p17), .C(p11), .Y(new_n112_));
  NAND2x1_ASAP7_75t_R  g026(.A(p18), .B(new_n112_), .Y(o13));
  OAI21x1_ASAP7_75t_R  g027(.A1(p13), .A2(p14), .B(p19), .Y(o14));
  XNOR2x2_ASAP7_75t_R  g028(.A(p23), .B(p24), .Y(new_n115_));
  XOR2x2_ASAP7_75t_R   g029(.A(p27), .B(p28), .Y(new_n116_));
  XOR2x2_ASAP7_75t_R   g030(.A(new_n115_), .B(new_n116_), .Y(new_n117_));
  XOR2x2_ASAP7_75t_R   g031(.A(p21), .B(p22), .Y(new_n118_));
  XOR2x2_ASAP7_75t_R   g032(.A(new_n118_), .B(p20), .Y(new_n119_));
  XOR2x2_ASAP7_75t_R   g033(.A(new_n117_), .B(new_n119_), .Y(new_n120_));
  XOR2x2_ASAP7_75t_R   g034(.A(p29), .B(p25), .Y(new_n121_));
  XOR2x2_ASAP7_75t_R   g035(.A(new_n121_), .B(p26), .Y(new_n122_));
  XOR2x2_ASAP7_75t_R   g036(.A(new_n120_), .B(new_n122_), .Y(o15));
  XOR2x2_ASAP7_75t_R   g037(.A(p32), .B(p33), .Y(new_n124_));
  XOR2x2_ASAP7_75t_R   g038(.A(p36), .B(p37), .Y(new_n125_));
  XOR2x2_ASAP7_75t_R   g039(.A(new_n124_), .B(new_n125_), .Y(new_n126_));
  XOR2x2_ASAP7_75t_R   g040(.A(p38), .B(p34), .Y(new_n127_));
  XOR2x2_ASAP7_75t_R   g041(.A(new_n127_), .B(p35), .Y(new_n128_));
  XOR2x2_ASAP7_75t_R   g042(.A(new_n126_), .B(new_n128_), .Y(new_n129_));
  XOR2x2_ASAP7_75t_R   g043(.A(p20), .B(p30), .Y(new_n130_));
  INVx1_ASAP7_75t_R    g044(.A(p31), .Y(new_n131_));
  XOR2x2_ASAP7_75t_R   g045(.A(new_n130_), .B(new_n131_), .Y(new_n132_));
  XOR2x2_ASAP7_75t_R   g046(.A(new_n129_), .B(new_n132_), .Y(o16));
  AND3x1_ASAP7_75t_R   g047(.A(p11), .B(p0), .C(p59), .Y(new_n134_));
  NAND2x1_ASAP7_75t_R  g048(.A(p15), .B(p6), .Y(new_n135_));
  NOR3x1_ASAP7_75t_R   g049(.A(new_n134_), .B(new_n98_), .C(new_n135_), .Y(new_n136_));
  AND4x2_ASAP7_75t_R   g050(.A(p15), .B(p2), .C(p9), .D(p10), .Y(new_n137_));
  INVx1_ASAP7_75t_R    g051(.A(p16), .Y(new_n138_));
  NOR3x1_ASAP7_75t_R   g052(.A(new_n88_), .B(new_n138_), .C(p44), .Y(new_n139_));
  AOI22x1_ASAP7_75t_R  g053(.A1(new_n136_), .A2(p28), .B1(new_n137_), .B2(new_n139_), .Y(new_n140_));
  NAND2x1_ASAP7_75t_R  g054(.A(p9), .B(p10), .Y(new_n141_));
  OAI21x1_ASAP7_75t_R  g055(.A1(p6), .A2(p59), .B(p15), .Y(new_n142_));
  NOR2x1_ASAP7_75t_R   g056(.A(new_n141_), .B(new_n142_), .Y(new_n143_));
  NAND2x1_ASAP7_75t_R  g057(.A(p46), .B(p11), .Y(new_n144_));
  AOI21x1_ASAP7_75t_R  g058(.A1(p6), .A2(p59), .B(new_n144_), .Y(new_n145_));
  NAND3x1_ASAP7_75t_R  g059(.A(new_n143_), .B(new_n145_), .C(p28), .Y(new_n146_));
  INVx1_ASAP7_75t_R    g060(.A(p9), .Y(new_n147_));
  OA21x2_ASAP7_75t_R   g061(.A1(p6), .A2(new_n147_), .B(p45), .Y(new_n148_));
  AO31x2_ASAP7_75t_R   g062(.A1(new_n144_), .A2(p15), .A3(p10), .B(new_n147_), .Y(new_n149_));
  NAND2x1_ASAP7_75t_R  g063(.A(new_n148_), .B(new_n149_), .Y(new_n150_));
  INVx1_ASAP7_75t_R    g064(.A(p37), .Y(new_n151_));
  AO31x2_ASAP7_75t_R   g065(.A1(new_n140_), .A2(new_n146_), .A3(new_n150_), .B(new_n151_), .Y(new_n152_));
  INVx1_ASAP7_75t_R    g066(.A(p28), .Y(new_n153_));
  NAND3x1_ASAP7_75t_R  g067(.A(p11), .B(p0), .C(p59), .Y(new_n154_));
  AND4x2_ASAP7_75t_R   g068(.A(p8), .B(p15), .C(p9), .D(p6), .Y(new_n155_));
  NAND2x1_ASAP7_75t_R  g069(.A(new_n154_), .B(new_n155_), .Y(new_n156_));
  NAND2x1_ASAP7_75t_R  g070(.A(new_n137_), .B(new_n139_), .Y(new_n157_));
  OAI21x1_ASAP7_75t_R  g071(.A1(new_n153_), .A2(new_n156_), .B(new_n157_), .Y(new_n158_));
  AND3x1_ASAP7_75t_R   g072(.A(new_n143_), .B(p28), .C(new_n145_), .Y(new_n159_));
  AO21x1_ASAP7_75t_R   g073(.A1(new_n148_), .A2(new_n149_), .B(p37), .Y(new_n160_));
  OR3x1_ASAP7_75t_R    g074(.A(new_n158_), .B(new_n159_), .C(new_n160_), .Y(new_n161_));
  AO21x1_ASAP7_75t_R   g075(.A1(new_n152_), .A2(new_n161_), .B(p51), .Y(new_n162_));
  AOI21x1_ASAP7_75t_R  g076(.A1(new_n148_), .A2(new_n149_), .B(p37), .Y(new_n163_));
  INVx1_ASAP7_75t_R    g077(.A(p51), .Y(new_n164_));
  AO31x2_ASAP7_75t_R   g078(.A1(new_n140_), .A2(new_n146_), .A3(new_n163_), .B(new_n164_), .Y(new_n165_));
  NOR2x1_ASAP7_75t_R   g079(.A(p44), .B(new_n88_), .Y(new_n166_));
  AND3x1_ASAP7_75t_R   g080(.A(new_n166_), .B(p16), .C(new_n137_), .Y(new_n167_));
  AOI21x1_ASAP7_75t_R  g081(.A1(new_n149_), .A2(new_n148_), .B(new_n167_), .Y(new_n168_));
  NAND2x1_ASAP7_75t_R  g082(.A(new_n145_), .B(new_n143_), .Y(new_n169_));
  AO21x1_ASAP7_75t_R   g083(.A1(new_n156_), .A2(new_n169_), .B(new_n153_), .Y(new_n170_));
  AOI21x1_ASAP7_75t_R  g084(.A1(new_n168_), .A2(new_n170_), .B(new_n151_), .Y(new_n171_));
  OA21x2_ASAP7_75t_R   g085(.A1(new_n165_), .A2(new_n171_), .B(p50), .Y(new_n172_));
  AND3x1_ASAP7_75t_R   g086(.A(new_n161_), .B(p47), .C(new_n152_), .Y(new_n173_));
  NAND2x1_ASAP7_75t_R  g087(.A(new_n168_), .B(new_n170_), .Y(new_n174_));
  AO21x1_ASAP7_75t_R   g088(.A1(p48), .A2(p37), .B(p43), .Y(new_n175_));
  AND3x1_ASAP7_75t_R   g089(.A(p40), .B(p39), .C(p59), .Y(new_n176_));
  AND2x2_ASAP7_75t_R   g090(.A(new_n176_), .B(new_n112_), .Y(new_n177_));
  AO22x1_ASAP7_75t_R   g091(.A1(p42), .A2(p41), .B1(p27), .B2(p49), .Y(new_n178_));
  AO21x1_ASAP7_75t_R   g092(.A1(p37), .A2(new_n177_), .B(new_n178_), .Y(new_n179_));
  AO21x1_ASAP7_75t_R   g093(.A1(new_n174_), .A2(new_n175_), .B(new_n179_), .Y(new_n180_));
  AOI211x1_ASAP7_75t_R g094(.A1(new_n162_), .A2(new_n172_), .B(new_n173_), .C(new_n180_), .Y(o17));
  OA21x2_ASAP7_75t_R   g095(.A1(p6), .A2(p59), .B(p15), .Y(new_n182_));
  AND2x2_ASAP7_75t_R   g096(.A(p46), .B(p11), .Y(new_n183_));
  NAND2x1_ASAP7_75t_R  g097(.A(p6), .B(p59), .Y(new_n184_));
  AND4x2_ASAP7_75t_R   g098(.A(new_n182_), .B(new_n101_), .C(new_n183_), .D(new_n184_), .Y(new_n185_));
  OAI21x1_ASAP7_75t_R  g099(.A1(new_n136_), .A2(new_n185_), .B(p25), .Y(new_n186_));
  OA21x2_ASAP7_75t_R   g100(.A1(p6), .A2(new_n147_), .B(p52), .Y(new_n187_));
  AOI21x1_ASAP7_75t_R  g101(.A1(new_n187_), .A2(new_n149_), .B(p34), .Y(new_n188_));
  AND3x1_ASAP7_75t_R   g102(.A(new_n186_), .B(new_n157_), .C(new_n188_), .Y(new_n189_));
  INVx1_ASAP7_75t_R    g103(.A(new_n189_), .Y(new_n190_));
  AOI22x1_ASAP7_75t_R  g104(.A1(new_n136_), .A2(p27), .B1(new_n137_), .B2(new_n139_), .Y(new_n191_));
  OA21x2_ASAP7_75t_R   g105(.A1(p6), .A2(new_n147_), .B(p53), .Y(new_n192_));
  NAND2x1_ASAP7_75t_R  g106(.A(new_n192_), .B(new_n149_), .Y(new_n193_));
  NAND3x1_ASAP7_75t_R  g107(.A(new_n143_), .B(new_n145_), .C(p27), .Y(new_n194_));
  INVx1_ASAP7_75t_R    g108(.A(p36), .Y(new_n195_));
  AO31x2_ASAP7_75t_R   g109(.A1(new_n191_), .A2(new_n193_), .A3(new_n194_), .B(new_n195_), .Y(new_n196_));
  AOI22x1_ASAP7_75t_R  g110(.A1(new_n136_), .A2(p26), .B1(new_n137_), .B2(new_n139_), .Y(new_n197_));
  NAND3x1_ASAP7_75t_R  g111(.A(new_n143_), .B(new_n145_), .C(p26), .Y(new_n198_));
  OA21x2_ASAP7_75t_R   g112(.A1(p6), .A2(new_n147_), .B(p54), .Y(new_n199_));
  AOI21x1_ASAP7_75t_R  g113(.A1(new_n199_), .A2(new_n149_), .B(p35), .Y(new_n200_));
  AND3x1_ASAP7_75t_R   g114(.A(new_n197_), .B(new_n198_), .C(new_n200_), .Y(new_n201_));
  INVx1_ASAP7_75t_R    g115(.A(p35), .Y(new_n202_));
  AOI22x1_ASAP7_75t_R  g116(.A1(new_n149_), .A2(new_n199_), .B1(new_n137_), .B2(new_n139_), .Y(new_n203_));
  INVx1_ASAP7_75t_R    g117(.A(p26), .Y(new_n204_));
  OR4x2_ASAP7_75t_R    g118(.A(new_n134_), .B(new_n204_), .C(new_n98_), .D(new_n135_), .Y(new_n205_));
  AND3x1_ASAP7_75t_R   g119(.A(new_n203_), .B(new_n205_), .C(new_n198_), .Y(new_n206_));
  OAI22x1_ASAP7_75t_R  g120(.A1(new_n196_), .A2(new_n201_), .B1(new_n202_), .B2(new_n206_), .Y(new_n207_));
  NAND2x1_ASAP7_75t_R  g121(.A(new_n190_), .B(new_n207_), .Y(new_n208_));
  NAND3x1_ASAP7_75t_R  g122(.A(new_n198_), .B(new_n205_), .C(new_n157_), .Y(new_n209_));
  INVx1_ASAP7_75t_R    g123(.A(new_n200_), .Y(new_n210_));
  NAND3x1_ASAP7_75t_R  g124(.A(new_n155_), .B(p27), .C(new_n154_), .Y(new_n211_));
  NAND3x1_ASAP7_75t_R  g125(.A(new_n194_), .B(new_n157_), .C(new_n211_), .Y(new_n212_));
  AO21x1_ASAP7_75t_R   g126(.A1(new_n192_), .A2(new_n149_), .B(p36), .Y(new_n213_));
  OAI22x1_ASAP7_75t_R  g127(.A1(new_n209_), .A2(new_n210_), .B1(new_n212_), .B2(new_n213_), .Y(new_n214_));
  AOI211x1_ASAP7_75t_R g128(.A1(new_n152_), .A2(new_n165_), .B(new_n189_), .C(new_n214_), .Y(new_n215_));
  INVx1_ASAP7_75t_R    g129(.A(new_n215_), .Y(new_n216_));
  AOI21x1_ASAP7_75t_R  g130(.A1(new_n149_), .A2(new_n187_), .B(new_n167_), .Y(new_n217_));
  INVx1_ASAP7_75t_R    g131(.A(p34), .Y(new_n218_));
  AOI21x1_ASAP7_75t_R  g132(.A1(new_n186_), .A2(new_n217_), .B(new_n218_), .Y(new_n219_));
  AO21x1_ASAP7_75t_R   g133(.A1(new_n208_), .A2(new_n216_), .B(new_n219_), .Y(new_n220_));
  AOI21x1_ASAP7_75t_R  g134(.A1(new_n152_), .A2(new_n165_), .B(new_n214_), .Y(new_n221_));
  INVx1_ASAP7_75t_R    g135(.A(new_n219_), .Y(new_n222_));
  AO21x1_ASAP7_75t_R   g136(.A1(new_n222_), .A2(new_n190_), .B(new_n207_), .Y(new_n223_));
  OA21x2_ASAP7_75t_R   g137(.A1(new_n221_), .A2(new_n223_), .B(p50), .Y(new_n224_));
  AND3x1_ASAP7_75t_R   g138(.A(new_n222_), .B(new_n190_), .C(p47), .Y(new_n225_));
  AO22x1_ASAP7_75t_R   g139(.A1(p49), .A2(p24), .B1(p34), .B2(new_n177_), .Y(new_n226_));
  INVx1_ASAP7_75t_R    g140(.A(p48), .Y(new_n227_));
  INVx1_ASAP7_75t_R    g141(.A(p43), .Y(new_n228_));
  OA21x2_ASAP7_75t_R   g142(.A1(new_n227_), .A2(new_n218_), .B(new_n228_), .Y(new_n229_));
  AOI21x1_ASAP7_75t_R  g143(.A1(new_n186_), .A2(new_n217_), .B(new_n229_), .Y(new_n230_));
  OR3x1_ASAP7_75t_R    g144(.A(new_n225_), .B(new_n226_), .C(new_n230_), .Y(new_n231_));
  AOI21x1_ASAP7_75t_R  g145(.A1(new_n220_), .A2(new_n224_), .B(new_n231_), .Y(o18));
  NOR2x1_ASAP7_75t_R   g146(.A(new_n213_), .B(new_n212_), .Y(new_n233_));
  AND2x2_ASAP7_75t_R   g147(.A(new_n152_), .B(new_n165_), .Y(new_n234_));
  NOR2x1_ASAP7_75t_R   g148(.A(new_n233_), .B(new_n234_), .Y(new_n235_));
  AO21x1_ASAP7_75t_R   g149(.A1(new_n156_), .A2(new_n169_), .B(new_n204_), .Y(new_n236_));
  AOI21x1_ASAP7_75t_R  g150(.A1(new_n203_), .A2(new_n236_), .B(new_n202_), .Y(new_n237_));
  NOR2x1_ASAP7_75t_R   g151(.A(new_n201_), .B(new_n237_), .Y(new_n238_));
  AOI22x1_ASAP7_75t_R  g152(.A1(new_n149_), .A2(new_n192_), .B1(new_n137_), .B2(new_n139_), .Y(new_n239_));
  OAI21x1_ASAP7_75t_R  g153(.A1(new_n136_), .A2(new_n185_), .B(p27), .Y(new_n240_));
  AOI21x1_ASAP7_75t_R  g154(.A1(new_n239_), .A2(new_n240_), .B(new_n195_), .Y(new_n241_));
  INVx1_ASAP7_75t_R    g155(.A(p50), .Y(new_n242_));
  AO21x1_ASAP7_75t_R   g156(.A1(new_n241_), .A2(new_n238_), .B(new_n242_), .Y(new_n243_));
  AOI21x1_ASAP7_75t_R  g157(.A1(new_n235_), .A2(new_n238_), .B(new_n243_), .Y(new_n244_));
  OR3x1_ASAP7_75t_R    g158(.A(new_n235_), .B(new_n241_), .C(new_n238_), .Y(new_n245_));
  AO22x1_ASAP7_75t_R   g159(.A1(p55), .A2(p41), .B1(p49), .B2(p25), .Y(new_n246_));
  AO21x1_ASAP7_75t_R   g160(.A1(p35), .A2(new_n177_), .B(new_n246_), .Y(new_n247_));
  NAND3x1_ASAP7_75t_R  g161(.A(new_n197_), .B(new_n198_), .C(new_n200_), .Y(new_n248_));
  OA211x2_ASAP7_75t_R  g162(.A1(new_n202_), .A2(new_n206_), .B(new_n248_), .C(p47), .Y(new_n249_));
  OA21x2_ASAP7_75t_R   g163(.A1(new_n227_), .A2(new_n202_), .B(new_n228_), .Y(new_n250_));
  NOR2x1_ASAP7_75t_R   g164(.A(new_n250_), .B(new_n206_), .Y(new_n251_));
  OR3x1_ASAP7_75t_R    g165(.A(new_n247_), .B(new_n249_), .C(new_n251_), .Y(new_n252_));
  AOI21x1_ASAP7_75t_R  g166(.A1(new_n244_), .A2(new_n245_), .B(new_n252_), .Y(o19));
  NOR2x1_ASAP7_75t_R   g167(.A(new_n241_), .B(new_n233_), .Y(new_n254_));
  XNOR2x2_ASAP7_75t_R  g168(.A(new_n254_), .B(new_n234_), .Y(new_n255_));
  NAND2x1_ASAP7_75t_R  g169(.A(new_n239_), .B(new_n240_), .Y(new_n256_));
  AO21x1_ASAP7_75t_R   g170(.A1(p48), .A2(new_n256_), .B(new_n177_), .Y(new_n257_));
  AO22x1_ASAP7_75t_R   g171(.A1(p49), .A2(p26), .B1(p56), .B2(p41), .Y(new_n258_));
  AO21x1_ASAP7_75t_R   g172(.A1(p43), .A2(new_n256_), .B(new_n258_), .Y(new_n259_));
  AO21x1_ASAP7_75t_R   g173(.A1(p47), .A2(new_n254_), .B(new_n259_), .Y(new_n260_));
  AO21x1_ASAP7_75t_R   g174(.A1(p36), .A2(new_n257_), .B(new_n260_), .Y(new_n261_));
  AOI21x1_ASAP7_75t_R  g175(.A1(p50), .A2(new_n255_), .B(new_n261_), .Y(o20));
  NAND2x1_ASAP7_75t_R  g176(.A(p16), .B(p15), .Y(new_n263_));
  NOR2x1_ASAP7_75t_R   g177(.A(new_n141_), .B(new_n263_), .Y(new_n264_));
  AND3x1_ASAP7_75t_R   g178(.A(new_n264_), .B(p52), .C(new_n144_), .Y(new_n265_));
  AND3x1_ASAP7_75t_R   g179(.A(new_n166_), .B(p6), .C(new_n137_), .Y(new_n266_));
  AND2x2_ASAP7_75t_R   g180(.A(p8), .B(p57), .Y(new_n267_));
  NOR3x1_ASAP7_75t_R   g181(.A(new_n265_), .B(new_n266_), .C(new_n267_), .Y(new_n268_));
  AO21x1_ASAP7_75t_R   g182(.A1(new_n143_), .A2(new_n145_), .B(new_n136_), .Y(new_n269_));
  NAND2x1_ASAP7_75t_R  g183(.A(p21), .B(new_n269_), .Y(new_n270_));
  INVx1_ASAP7_75t_R    g184(.A(p30), .Y(new_n271_));
  AO21x1_ASAP7_75t_R   g185(.A1(new_n268_), .A2(new_n270_), .B(new_n271_), .Y(new_n272_));
  INVx1_ASAP7_75t_R    g186(.A(p32), .Y(new_n273_));
  AND2x2_ASAP7_75t_R   g187(.A(p53), .B(new_n144_), .Y(new_n274_));
  AND2x2_ASAP7_75t_R   g188(.A(p57), .B(p6), .Y(new_n275_));
  AOI21x1_ASAP7_75t_R  g189(.A1(new_n264_), .A2(new_n274_), .B(new_n275_), .Y(new_n276_));
  NAND3x1_ASAP7_75t_R  g190(.A(new_n143_), .B(new_n145_), .C(p23), .Y(new_n277_));
  NAND3x1_ASAP7_75t_R  g191(.A(new_n155_), .B(p23), .C(new_n154_), .Y(new_n278_));
  INVx1_ASAP7_75t_R    g192(.A(p6), .Y(new_n279_));
  NOR3x1_ASAP7_75t_R   g193(.A(new_n88_), .B(p44), .C(new_n279_), .Y(new_n280_));
  NAND2x1_ASAP7_75t_R  g194(.A(new_n137_), .B(new_n280_), .Y(new_n281_));
  AND4x2_ASAP7_75t_R   g195(.A(new_n276_), .B(new_n277_), .C(new_n278_), .D(new_n281_), .Y(new_n282_));
  AND2x2_ASAP7_75t_R   g196(.A(p57), .B(p58), .Y(new_n283_));
  AND2x2_ASAP7_75t_R   g197(.A(p16), .B(p45), .Y(new_n284_));
  AND3x1_ASAP7_75t_R   g198(.A(new_n108_), .B(new_n284_), .C(new_n144_), .Y(new_n285_));
  AOI211x1_ASAP7_75t_R g199(.A1(new_n137_), .A2(new_n280_), .B(new_n283_), .C(new_n285_), .Y(new_n286_));
  NAND2x1_ASAP7_75t_R  g200(.A(p24), .B(new_n136_), .Y(new_n287_));
  NAND3x1_ASAP7_75t_R  g201(.A(new_n143_), .B(new_n145_), .C(p24), .Y(new_n288_));
  INVx1_ASAP7_75t_R    g202(.A(p33), .Y(new_n289_));
  AO31x2_ASAP7_75t_R   g203(.A1(new_n286_), .A2(new_n287_), .A3(new_n288_), .B(new_n289_), .Y(new_n290_));
  OAI21x1_ASAP7_75t_R  g204(.A1(new_n273_), .A2(new_n282_), .B(new_n290_), .Y(new_n291_));
  NAND2x1_ASAP7_75t_R  g205(.A(p22), .B(new_n269_), .Y(new_n292_));
  AND3x1_ASAP7_75t_R   g206(.A(new_n144_), .B(p16), .C(p54), .Y(new_n293_));
  AOI22x1_ASAP7_75t_R  g207(.A1(new_n293_), .A2(new_n108_), .B1(p15), .B2(p57), .Y(new_n294_));
  AND3x1_ASAP7_75t_R   g208(.A(new_n294_), .B(new_n131_), .C(new_n281_), .Y(new_n295_));
  AND2x2_ASAP7_75t_R   g209(.A(p16), .B(p53), .Y(new_n296_));
  AND3x1_ASAP7_75t_R   g210(.A(new_n108_), .B(new_n296_), .C(new_n144_), .Y(new_n297_));
  AOI211x1_ASAP7_75t_R g211(.A1(new_n137_), .A2(new_n280_), .B(new_n275_), .C(new_n297_), .Y(new_n298_));
  AND4x2_ASAP7_75t_R   g212(.A(new_n298_), .B(new_n273_), .C(new_n278_), .D(new_n277_), .Y(new_n299_));
  AOI21x1_ASAP7_75t_R  g213(.A1(new_n292_), .A2(new_n295_), .B(new_n299_), .Y(new_n300_));
  AND2x2_ASAP7_75t_R   g214(.A(new_n281_), .B(new_n294_), .Y(new_n301_));
  AOI21x1_ASAP7_75t_R  g215(.A1(new_n301_), .A2(new_n292_), .B(new_n131_), .Y(new_n302_));
  AOI21x1_ASAP7_75t_R  g216(.A1(new_n291_), .A2(new_n300_), .B(new_n302_), .Y(new_n303_));
  NAND2x1_ASAP7_75t_R  g217(.A(new_n272_), .B(new_n303_), .Y(new_n304_));
  AOI211x1_ASAP7_75t_R g218(.A1(new_n248_), .A2(new_n241_), .B(new_n219_), .C(new_n237_), .Y(new_n305_));
  OA31x2_ASAP7_75t_R   g219(.A1(new_n159_), .A2(new_n160_), .A3(new_n158_), .B1(p51), .Y(new_n306_));
  OA22x2_ASAP7_75t_R   g220(.A1(new_n209_), .A2(new_n210_), .B1(new_n213_), .B2(new_n212_), .Y(new_n307_));
  OAI21x1_ASAP7_75t_R  g221(.A1(new_n171_), .A2(new_n306_), .B(new_n307_), .Y(new_n308_));
  INVx1_ASAP7_75t_R    g222(.A(new_n300_), .Y(new_n309_));
  AND3x1_ASAP7_75t_R   g223(.A(new_n286_), .B(new_n287_), .C(new_n288_), .Y(new_n310_));
  AO21x1_ASAP7_75t_R   g224(.A1(new_n289_), .A2(new_n310_), .B(new_n189_), .Y(new_n311_));
  AOI211x1_ASAP7_75t_R g225(.A1(new_n305_), .A2(new_n308_), .B(new_n309_), .C(new_n311_), .Y(new_n312_));
  NAND3x1_ASAP7_75t_R  g226(.A(new_n270_), .B(new_n271_), .C(new_n268_), .Y(new_n313_));
  OAI21x1_ASAP7_75t_R  g227(.A1(new_n304_), .A2(new_n312_), .B(new_n313_), .Y(o21));
  XOR2x2_ASAP7_75t_R   g228(.A(new_n310_), .B(p33), .Y(new_n315_));
  AOI211x1_ASAP7_75t_R g229(.A1(new_n190_), .A2(new_n207_), .B(new_n219_), .C(new_n215_), .Y(new_n316_));
  NOR2x1_ASAP7_75t_R   g230(.A(new_n315_), .B(new_n316_), .Y(new_n317_));
  AND4x2_ASAP7_75t_R   g231(.A(new_n216_), .B(new_n208_), .C(new_n222_), .D(new_n315_), .Y(new_n318_));
  INVx1_ASAP7_75t_R    g232(.A(p47), .Y(new_n319_));
  AOI21x1_ASAP7_75t_R  g233(.A1(new_n289_), .A2(new_n310_), .B(new_n319_), .Y(new_n320_));
  NOR2x1_ASAP7_75t_R   g234(.A(new_n227_), .B(new_n290_), .Y(new_n321_));
  AOI22x1_ASAP7_75t_R  g235(.A1(new_n177_), .A2(p33), .B1(p23), .B2(p49), .Y(new_n322_));
  OAI21x1_ASAP7_75t_R  g236(.A1(new_n228_), .A2(new_n310_), .B(new_n322_), .Y(new_n323_));
  AOI211x1_ASAP7_75t_R g237(.A1(new_n290_), .A2(new_n320_), .B(new_n321_), .C(new_n323_), .Y(new_n324_));
  OA31x2_ASAP7_75t_R   g238(.A1(new_n242_), .A2(new_n317_), .A3(new_n318_), .B1(new_n324_), .Y(o22));
  AO21x1_ASAP7_75t_R   g239(.A1(new_n305_), .A2(new_n308_), .B(new_n311_), .Y(new_n326_));
  NAND2x1_ASAP7_75t_R  g240(.A(new_n291_), .B(new_n300_), .Y(new_n327_));
  NAND2x1_ASAP7_75t_R  g241(.A(new_n313_), .B(new_n272_), .Y(new_n328_));
  INVx1_ASAP7_75t_R    g242(.A(new_n302_), .Y(new_n329_));
  AND3x1_ASAP7_75t_R   g243(.A(new_n327_), .B(new_n328_), .C(new_n329_), .Y(new_n330_));
  OAI21x1_ASAP7_75t_R  g244(.A1(new_n309_), .A2(new_n326_), .B(new_n330_), .Y(new_n331_));
  NAND2x1_ASAP7_75t_R  g245(.A(p50), .B(new_n303_), .Y(new_n332_));
  AO21x1_ASAP7_75t_R   g246(.A1(new_n313_), .A2(new_n272_), .B(new_n242_), .Y(new_n333_));
  OAI21x1_ASAP7_75t_R  g247(.A1(new_n332_), .A2(new_n312_), .B(new_n333_), .Y(new_n334_));
  AOI22x1_ASAP7_75t_R  g248(.A1(new_n177_), .A2(p30), .B1(p44), .B2(p49), .Y(new_n335_));
  AO21x1_ASAP7_75t_R   g249(.A1(new_n268_), .A2(new_n270_), .B(new_n228_), .Y(new_n336_));
  OA211x2_ASAP7_75t_R  g250(.A1(new_n227_), .A2(new_n272_), .B(new_n335_), .C(new_n336_), .Y(new_n337_));
  OAI21x1_ASAP7_75t_R  g251(.A1(new_n319_), .A2(new_n328_), .B(new_n337_), .Y(new_n338_));
  AOI21x1_ASAP7_75t_R  g252(.A1(new_n331_), .A2(new_n334_), .B(new_n338_), .Y(o23));
  AO21x1_ASAP7_75t_R   g253(.A1(new_n289_), .A2(new_n310_), .B(new_n299_), .Y(new_n340_));
  AOI21x1_ASAP7_75t_R  g254(.A1(new_n281_), .A2(new_n294_), .B(new_n131_), .Y(new_n341_));
  AND3x1_ASAP7_75t_R   g255(.A(new_n269_), .B(p31), .C(p22), .Y(new_n342_));
  AOI211x1_ASAP7_75t_R g256(.A1(new_n295_), .A2(new_n292_), .B(new_n341_), .C(new_n342_), .Y(new_n343_));
  NAND2x1_ASAP7_75t_R  g257(.A(new_n278_), .B(new_n277_), .Y(new_n344_));
  NAND2x1_ASAP7_75t_R  g258(.A(new_n281_), .B(new_n276_), .Y(new_n345_));
  OAI21x1_ASAP7_75t_R  g259(.A1(new_n344_), .A2(new_n345_), .B(p32), .Y(new_n346_));
  OAI21x1_ASAP7_75t_R  g260(.A1(new_n299_), .A2(new_n290_), .B(new_n346_), .Y(new_n347_));
  NOR2x1_ASAP7_75t_R   g261(.A(new_n343_), .B(new_n347_), .Y(new_n348_));
  OAI21x1_ASAP7_75t_R  g262(.A1(new_n340_), .A2(new_n316_), .B(new_n348_), .Y(new_n349_));
  INVx1_ASAP7_75t_R    g263(.A(new_n343_), .Y(new_n350_));
  AOI21x1_ASAP7_75t_R  g264(.A1(new_n343_), .A2(new_n347_), .B(new_n242_), .Y(new_n351_));
  OA31x2_ASAP7_75t_R   g265(.A1(new_n350_), .A2(new_n340_), .A3(new_n316_), .B1(new_n351_), .Y(new_n352_));
  AOI22x1_ASAP7_75t_R  g266(.A1(new_n177_), .A2(p31), .B1(p21), .B2(p49), .Y(new_n353_));
  AO21x1_ASAP7_75t_R   g267(.A1(new_n301_), .A2(new_n292_), .B(new_n228_), .Y(new_n354_));
  OA211x2_ASAP7_75t_R  g268(.A1(new_n227_), .A2(new_n329_), .B(new_n353_), .C(new_n354_), .Y(new_n355_));
  OAI21x1_ASAP7_75t_R  g269(.A1(new_n319_), .A2(new_n350_), .B(new_n355_), .Y(new_n356_));
  AOI21x1_ASAP7_75t_R  g270(.A1(new_n349_), .A2(new_n352_), .B(new_n356_), .Y(o24));
  XOR2x2_ASAP7_75t_R   g271(.A(new_n282_), .B(p32), .Y(new_n358_));
  AND2x2_ASAP7_75t_R   g272(.A(new_n290_), .B(new_n358_), .Y(new_n359_));
  AOI21x1_ASAP7_75t_R  g273(.A1(new_n359_), .A2(new_n326_), .B(new_n242_), .Y(new_n360_));
  AO21x1_ASAP7_75t_R   g274(.A1(new_n289_), .A2(new_n310_), .B(new_n358_), .Y(new_n361_));
  AO21x1_ASAP7_75t_R   g275(.A1(new_n290_), .A2(new_n316_), .B(new_n361_), .Y(new_n362_));
  AOI22x1_ASAP7_75t_R  g276(.A1(new_n177_), .A2(p32), .B1(p22), .B2(p49), .Y(new_n363_));
  OR3x1_ASAP7_75t_R    g277(.A(new_n282_), .B(new_n227_), .C(new_n273_), .Y(new_n364_));
  OA211x2_ASAP7_75t_R  g278(.A1(new_n228_), .A2(new_n282_), .B(new_n363_), .C(new_n364_), .Y(new_n365_));
  OAI21x1_ASAP7_75t_R  g279(.A1(new_n319_), .A2(new_n358_), .B(new_n365_), .Y(new_n366_));
  AOI21x1_ASAP7_75t_R  g280(.A1(new_n360_), .A2(new_n362_), .B(new_n366_), .Y(o25));
endmodule


