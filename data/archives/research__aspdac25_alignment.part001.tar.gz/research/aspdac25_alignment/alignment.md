# ASPDAC 2025 input-alignment audit

Primary source: Costamagna et al., Area-Oriented Optimization After Standard-Cell Mapping, DOI 10.1145/3658617.3697722. The official author-hosted PDF is archived here; printed pages 1117-1118 (PDF pages 6-7), Table 1 and Sections 4.1/4.3/4.4, were visually checked.

## Protocol interpretation

- Section 4.3 (Table 1): iterate resyn2rs and compress2rs, preceded by fraig for each script; area-oriented emap on ASAP7; post-mapping must not increase delay.
- Section 4.1 investigates intermediate graph/area correlation and also uses rw, rs and rf. It is a different experiment; those extra commands should not silently be treated as Table 1 setup.
- Section 4.4 (Table 2): two iterations of fraig; compress2rs; resyn2rs, then mapped-domain optimization with an unmap/balance/remap exploration variant. This is not the Table 1 baseline.
- Table 1 defines A_e and D_e as pre-post-mapping metrics. Its bottom averages cover all 39 designs, although only selected rows are printed. Our subset has 16 designs.

## Original script assessment

The default round fraig; resyn2rs; fraig; compress2rs follows the Section 4.3 description. It retains a whole round only if the final AND count decreases and has a 20-round safety cap. The paper does not specify enough detail to prove that its per-script acceptance/stopping schedule is identical, nor does it publish the exact emap parameter set, tool revisions, genlib revision or intermediate mapped netlists.

The original arbiter baseline is strong evidence of approximate scalar alignment: paper A_i=A_e=557.84 and D_e=999.95; ours A_e=557.72 and D_e=999.87. Lack of AIG reduction is therefore consistent with the reported experiment. Matching area/delay closely is not proof of byte-identical topology.

The current emap area-oriented mode bypasses required-time propagation. Section 4.3 directly supports constraining post-mapping to its input delay; the caption mentions best possible delay, but does not establish that a separate delay-oriented mapping must be run first. Do not infer undocumented mapper settings as a reproducibility fact.

Adding syn4 yields a different initial netlist (264.43 / 373.01). Its favorable final result is a separate end-to-end exploration and cannot demonstrate superior post-mapping optimization from the paper-aligned arbiter input.

## Initial mapped metrics, not optimized outputs

| Design | Paper A_e | Ours A_e | dA % | Paper D_e | Ours D_e | dD % |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| aes_core | 1106.60 | 1029.98 | -6.92 | 434.52 | 410.72 | -5.48 |
| arbiter | 557.84 | 557.72 | -0.02 | 999.95 | 999.87 | -0.01 |
| div | 1296.90 | 1184.50 | -8.67 | 60248.23 | 53105.06 | -11.86 |
| ethernet | 3123.35 | 2541.41 | -18.63 | 588.34 | 543.88 | -7.56 |
| iwls05_i2c | 49.96 | 47.66 | -4.60 | 288.07 | 303.61 | +5.39 |
| mem_ctrl | 2063.01 | 1895.40 | -8.12 | 1649.46 | 1519.75 | -7.86 |
| RISC | 3172.54 | 2927.19 | -7.73 | 1304.74 | 1453.77 | +11.42 |
| sasc | 31.72 | 27.28 | -14.00 | 191.00 | 191.20 | +0.10 |
| simple_spi | 41.58 | 36.96 | -11.11 | 287.00 | 308.22 | +7.39 |
| spi | 167.59 | 149.43 | -10.84 | 489.49 | 500.98 | +2.35 |
| sqrt | 1171.15 | 1157.38 | -1.18 | 78957.63 | 88015.07 | +11.47 |
| systemcaes | 530.89 | 483.75 | -8.88 | 784.00 | 709.03 | -9.56 |
| systemcdes | 142.22 | 131.06 | -7.85 | 530.29 | 488.85 | -7.81 |
| tv80 | 356.38 | 340.61 | -4.43 | 907.86 | 846.12 | -6.80 |
| usb_funct | 702.45 | 646.23 | -8.00 | 722.00 | 668.08 | -7.47 |
| usb_phy | 23.97 | 22.54 | -5.97 | 179.06 | 163.29 | -8.81 |

## Evaluation policy

Keep the original high_effort initial mapping for the main ASPDAC Table 1 comparison. arbiter method improvements must receive the exact existing mapped input and hold its initial 999.87 ps bound; whole-window synthesis remains disabled and the post-mapping cap remains 1000 seconds.
Only arbiter is within 1% on both initial metrics among these 16 designs. Other designs are not fully input-aligned, so their published-final-output comparisons remain end-to-end comparisons with different starts. Own-input before/after changes are the isolated evidence for ePMapping efficacy.
Prioritize additional non-local candidate generation (dependency cuts, reuse of existing divisors and SAT-validated global information) rather than claiming preprocessing improvements as post-mapping gains. The current cut-only engine does not actually generate dependency cuts despite retaining old diagnostic terminology. This audit specifies the next method direction; it does not claim that such an extension has already been implemented.
