# Proportional input-capacity protocol

For the frozen once-resyn2 AIG header with I PIs and A ANDs:

- Primitive input allowance B = 2*(I+A)+2 (both phases and two constants).
- Additional search allowance S = ceil(rho*B), computed with exact rational arithmetic.
- Total cumulative e-node admission limit G = B+S. There is no additional fixed20k floor.

rho defaults to1 for the initial experiments. This is an experimental starting value, not a PPA-tuned optimum. Ratios1/2,1,2 are planned sensitivity settings; do not select a different ratio per design or claim they have all been measured. Global ledger accounting is unchanged: admitted imports, helpers and rewrite RHSs count; merging/rebuild/retirement do not refund. The primitive bound does not make optional TT/helper import nodes free. The native optimizer's first admission reservation is min(20000,G) and any retry receives only G minus the actually consumed first reservation, sharing the same60-second native scheduling window. This is one cumulative budget, not two independently reset searches.

The physical source incumbent and the optional100000-instance retained bank have a separate explicit total retained bound. The physical-bank allowance is not an e-node allowance. All frontend construction/search/export remain inside mapping-only300seconds; native2-second recovery and the existing60-second guard are unchanged. CEC remains outside the mapping clock under the existing60-second verification guard; a verification timeout remains failure. Baseline algorithms/models/parameters are unchanged.

New experimental driver: scripts/experiments/campaigns/bench_proportional_capacity.py --search-ratio 1. New finite campaign runner: scripts/experiments/campaigns/run_proportional_capacity_campaign.py. Native main binary and published main tables are not replaced by this resource-policy experiment. Old fixed20k and additive-capacity data remain separate.

Validation: five proportional-policy unit tests and five source-cover regression tests pass. ctrl in both inventories independently passes original named-port CEC, returns an e-graph cover, and records299 admissions within464. Large-input retry validation is recorded separately upon completion; no full20 proportional optimization matrix has been completed yet.

Accounting detail: S is the extra total capacity above the conservative primitive-input reservation, not an independent saturation-phase admission counter. If a compact import uses fewer than B nodes, the shared ledger can use the unused headroom. Every admitted helper and rewrite still counts toward G. Thus rho=0 adds no capacity above B; it does not disable all equality rewriting. Enforcing a separate hard rewrite counter would be a distinct policy, not a property claimed by this experiment. The proportional cap controls admitted node volume; candidate generation and matching costs need not scale linearly with it, so the existing time guards remain necessary.

Large-input retry validation is now complete: div in both inventories independently passes CEC on the protected source cover. Each consumes20000 admissions in the rejected first attempt plus118301 in the second, within163604. The second import completes but subsequent optimization hits the unchanged60-second guard; no optimized cover is returned for div. Both failures and all four native-attempt logs remain. No full20 proportional optimization matrix or ratio sensitivity comparison has been completed.
