// Benchmark "/home/flynn/workplace/MIGBalance/tools/mockturtle/experiments/benchmarks/c880" written by ABC on Wed Oct  7 16:25:10 2026

module \/home/flynn/workplace/MIGBalance/tools/mockturtle/experiments/benchmarks/c880  ( 
    G8, G16, G6, G17, G7, G18, G19, G4, G3, G2, G1, G5, G11, G23, G20, G21,
    G9, G10, G12, G15, G22, G32, G24, G25, G26, G27, G28, G29, G30, G31,
    G33, G41, G42, G43, G44, G45, G46, G47, G48, G49, G13, G14, G55, G59,
    G54, G60, G39, G40, G52, G53, G50, G51, G58, G35, G37, G36, G56, G57,
    G34, G38,
    G855, G856, G857, G858, G859, G860, G861, G862, G863, G864, G865, G866,
    G867, G868, G869, G870, G871, G872, G873, G874, G875, G876, G877, G878,
    G879, G880  );
  input  G8, G16, G6, G17, G7, G18, G19, G4, G3, G2, G1, G5, G11, G23,
    G20, G21, G9, G10, G12, G15, G22, G32, G24, G25, G26, G27, G28, G29,
    G30, G31, G33, G41, G42, G43, G44, G45, G46, G47, G48, G49, G13, G14,
    G55, G59, G54, G60, G39, G40, G52, G53, G50, G51, G58, G35, G37, G36,
    G56, G57, G34, G38;
  output G855, G856, G857, G858, G859, G860, G861, G862, G863, G864, G865,
    G866, G867, G868, G869, G870, G871, G872, G873, G874, G875, G876, G877,
    G878, G879, G880;
  wire new_n87_, new_n88_, new_n89_, new_n90_, new_n91_, new_n92_, new_n93_,
    new_n94_, new_n95_, new_n96_, new_n97_, new_n98_, new_n99_, new_n100_,
    new_n101_, new_n102_, new_n103_, new_n104_, new_n105_, new_n106_,
    new_n107_, new_n108_, new_n109_, new_n110_, new_n111_, new_n112_,
    new_n113_, new_n114_, new_n115_, new_n116_, new_n117_, new_n118_,
    new_n119_, new_n120_, new_n121_, new_n125_, new_n127_, new_n129_,
    new_n130_, new_n138_, new_n140_, new_n143_, new_n144_, new_n145_,
    new_n146_, new_n147_, new_n148_, new_n149_, new_n150_, new_n152_,
    new_n153_, new_n154_, new_n155_, new_n156_, new_n157_, new_n158_,
    new_n159_, new_n161_, new_n162_, new_n163_, new_n164_, new_n165_,
    new_n166_, new_n167_, new_n168_, new_n169_, new_n170_, new_n171_,
    new_n172_, new_n173_, new_n174_, new_n175_, new_n176_, new_n177_,
    new_n178_, new_n179_, new_n180_, new_n181_, new_n182_, new_n183_,
    new_n184_, new_n185_, new_n186_, new_n187_, new_n188_, new_n189_,
    new_n190_, new_n191_, new_n192_, new_n194_, new_n195_, new_n196_,
    new_n197_, new_n198_, new_n199_, new_n200_, new_n201_, new_n202_,
    new_n203_, new_n204_, new_n205_, new_n206_, new_n207_, new_n208_,
    new_n209_, new_n210_, new_n211_, new_n212_, new_n213_, new_n214_,
    new_n215_, new_n216_, new_n217_, new_n218_, new_n219_, new_n220_,
    new_n221_, new_n222_, new_n223_, new_n224_, new_n225_, new_n227_,
    new_n228_, new_n229_, new_n230_, new_n231_, new_n232_, new_n233_,
    new_n234_, new_n235_, new_n236_, new_n237_, new_n238_, new_n239_,
    new_n241_, new_n242_, new_n243_, new_n244_, new_n245_, new_n246_,
    new_n247_, new_n248_, new_n249_, new_n250_, new_n251_, new_n253_,
    new_n254_, new_n255_, new_n256_, new_n257_, new_n258_, new_n259_,
    new_n260_, new_n261_, new_n262_, new_n263_, new_n264_, new_n265_,
    new_n266_, new_n267_, new_n268_, new_n269_, new_n270_, new_n271_,
    new_n272_, new_n273_, new_n274_, new_n275_, new_n276_, new_n277_,
    new_n278_, new_n279_, new_n280_, new_n281_, new_n282_, new_n283_,
    new_n284_, new_n285_, new_n286_, new_n287_, new_n288_, new_n290_,
    new_n291_, new_n292_, new_n293_, new_n294_, new_n295_, new_n296_,
    new_n297_, new_n298_, new_n300_, new_n301_, new_n302_, new_n303_,
    new_n304_, new_n305_, new_n306_, new_n307_, new_n308_, new_n310_,
    new_n311_, new_n312_, new_n313_, new_n314_, new_n315_, new_n316_,
    new_n317_, new_n318_, new_n319_, new_n320_, new_n321_, new_n323_,
    new_n324_, new_n325_, new_n326_, new_n327_, new_n328_, new_n329_,
    new_n330_, new_n331_, new_n332_;
  INVx1_ASAP7_75t_R   g000(.A(G8), .Y(new_n87_));
  INVx1_ASAP7_75t_R   g001(.A(G16), .Y(new_n88_));
  INVx1_ASAP7_75t_R   g002(.A(G6), .Y(new_n89_));
  INVx1_ASAP7_75t_R   g003(.A(G17), .Y(new_n90_));
  INVx1_ASAP7_75t_R   g004(.A(G7), .Y(new_n91_));
  INVx1_ASAP7_75t_R   g005(.A(G4), .Y(new_n92_));
  INVx1_ASAP7_75t_R   g006(.A(G3), .Y(new_n93_));
  INVx1_ASAP7_75t_R   g007(.A(G11), .Y(new_n94_));
  INVx1_ASAP7_75t_R   g008(.A(G9), .Y(new_n95_));
  INVx1_ASAP7_75t_R   g009(.A(G10), .Y(new_n96_));
  INVx1_ASAP7_75t_R   g010(.A(G12), .Y(new_n97_));
  INVx1_ASAP7_75t_R   g011(.A(G15), .Y(new_n98_));
  INVx1_ASAP7_75t_R   g012(.A(G32), .Y(new_n99_));
  INVx1_ASAP7_75t_R   g013(.A(G24), .Y(new_n100_));
  INVx1_ASAP7_75t_R   g014(.A(G25), .Y(new_n101_));
  INVx1_ASAP7_75t_R   g015(.A(G26), .Y(new_n102_));
  INVx1_ASAP7_75t_R   g016(.A(G27), .Y(new_n103_));
  INVx1_ASAP7_75t_R   g017(.A(G28), .Y(new_n104_));
  INVx1_ASAP7_75t_R   g018(.A(G29), .Y(new_n105_));
  INVx1_ASAP7_75t_R   g019(.A(G30), .Y(new_n106_));
  INVx1_ASAP7_75t_R   g020(.A(G31), .Y(new_n107_));
  INVx1_ASAP7_75t_R   g021(.A(G41), .Y(new_n108_));
  INVx1_ASAP7_75t_R   g022(.A(G42), .Y(new_n109_));
  INVx1_ASAP7_75t_R   g023(.A(G43), .Y(new_n110_));
  INVx1_ASAP7_75t_R   g024(.A(G44), .Y(new_n111_));
  INVx1_ASAP7_75t_R   g025(.A(G45), .Y(new_n112_));
  INVx1_ASAP7_75t_R   g026(.A(G46), .Y(new_n113_));
  INVx1_ASAP7_75t_R   g027(.A(G47), .Y(new_n114_));
  INVx1_ASAP7_75t_R   g028(.A(G48), .Y(new_n115_));
  INVx1_ASAP7_75t_R   g029(.A(G13), .Y(new_n116_));
  INVx1_ASAP7_75t_R   g030(.A(G14), .Y(new_n117_));
  INVx1_ASAP7_75t_R   g031(.A(G54), .Y(new_n118_));
  INVx1_ASAP7_75t_R   g032(.A(G40), .Y(new_n119_));
  INVx1_ASAP7_75t_R   g033(.A(G53), .Y(new_n120_));
  INVx1_ASAP7_75t_R   g034(.A(G51), .Y(new_n121_));
  OR3x1_ASAP7_75t_R   g035(.A(new_n88_), .B(new_n89_), .C(new_n87_), .Y(G855));
  OR3x1_ASAP7_75t_R   g036(.A(new_n89_), .B(new_n91_), .C(new_n90_), .Y(G856));
  OR3x1_ASAP7_75t_R   g037(.A(new_n89_), .B(new_n91_), .C(new_n87_), .Y(G857));
  INVx1_ASAP7_75t_R   g038(.A(G857), .Y(new_n125_));
  NAND2x1_ASAP7_75t_R g039(.A(G18), .B(G19), .Y(G858));
  NAND2x1_ASAP7_75t_R g040(.A(G2), .B(G1), .Y(new_n127_));
  OR3x1_ASAP7_75t_R   g041(.A(new_n92_), .B(new_n93_), .C(new_n127_), .Y(G859));
  NAND2x1_ASAP7_75t_R g042(.A(G1), .B(G5), .Y(new_n129_));
  OR3x1_ASAP7_75t_R   g043(.A(new_n92_), .B(new_n93_), .C(new_n129_), .Y(new_n130_));
  NOR2x1_ASAP7_75t_R  g044(.A(new_n125_), .B(new_n130_), .Y(G860));
  AND3x1_ASAP7_75t_R  g045(.A(G16), .B(G11), .C(G17), .Y(G861));
  AND3x1_ASAP7_75t_R  g046(.A(G7), .B(G11), .C(G17), .Y(G862));
  AND3x1_ASAP7_75t_R  g047(.A(G7), .B(G11), .C(G8), .Y(G863));
  OAI21x1_ASAP7_75t_R g048(.A1(G20), .A2(G21), .B(G23), .Y(G864));
  NOR2x1_ASAP7_75t_R  g049(.A(G857), .B(new_n130_), .Y(G865));
  OR2x4_ASAP7_75t_R   g050(.A(new_n95_), .B(new_n129_), .Y(G866));
  OR3x1_ASAP7_75t_R   g051(.A(new_n93_), .B(new_n96_), .C(new_n127_), .Y(new_n138_));
  OR3x1_ASAP7_75t_R   g052(.A(new_n89_), .B(new_n97_), .C(new_n138_), .Y(G867));
  OR3x1_ASAP7_75t_R   g053(.A(new_n94_), .B(new_n97_), .C(new_n98_), .Y(new_n140_));
  OR2x4_ASAP7_75t_R   g054(.A(new_n138_), .B(new_n140_), .Y(G868));
  OAI21x1_ASAP7_75t_R g055(.A1(G20), .A2(G21), .B(G22), .Y(G869));
  XOR2x2_ASAP7_75t_R  g056(.A(new_n100_), .B(new_n101_), .Y(new_n143_));
  XOR2x2_ASAP7_75t_R  g057(.A(new_n102_), .B(new_n103_), .Y(new_n144_));
  XNOR2x2_ASAP7_75t_R g058(.A(new_n143_), .B(new_n144_), .Y(new_n145_));
  XOR2x2_ASAP7_75t_R  g059(.A(new_n99_), .B(new_n145_), .Y(new_n146_));
  XOR2x2_ASAP7_75t_R  g060(.A(new_n104_), .B(new_n105_), .Y(new_n147_));
  XOR2x2_ASAP7_75t_R  g061(.A(new_n106_), .B(new_n107_), .Y(new_n148_));
  XNOR2x2_ASAP7_75t_R g062(.A(new_n147_), .B(new_n148_), .Y(new_n149_));
  XNOR2x2_ASAP7_75t_R g063(.A(G33), .B(new_n149_), .Y(new_n150_));
  XNOR2x2_ASAP7_75t_R g064(.A(new_n146_), .B(new_n150_), .Y(G870));
  XOR2x2_ASAP7_75t_R  g065(.A(new_n108_), .B(new_n109_), .Y(new_n152_));
  XOR2x2_ASAP7_75t_R  g066(.A(new_n110_), .B(new_n111_), .Y(new_n153_));
  XNOR2x2_ASAP7_75t_R g067(.A(new_n152_), .B(new_n153_), .Y(new_n154_));
  XOR2x2_ASAP7_75t_R  g068(.A(new_n99_), .B(new_n154_), .Y(new_n155_));
  XOR2x2_ASAP7_75t_R  g069(.A(new_n112_), .B(new_n113_), .Y(new_n156_));
  XOR2x2_ASAP7_75t_R  g070(.A(new_n114_), .B(new_n115_), .Y(new_n157_));
  XNOR2x2_ASAP7_75t_R g071(.A(new_n156_), .B(new_n157_), .Y(new_n158_));
  XNOR2x2_ASAP7_75t_R g072(.A(G49), .B(new_n158_), .Y(new_n159_));
  XNOR2x2_ASAP7_75t_R g073(.A(new_n155_), .B(new_n159_), .Y(G871));
  NAND2x1_ASAP7_75t_R g074(.A(G8), .B(G11), .Y(new_n161_));
  OR3x1_ASAP7_75t_R   g075(.A(new_n97_), .B(new_n116_), .C(new_n161_), .Y(new_n162_));
  OR3x1_ASAP7_75t_R   g076(.A(new_n138_), .B(new_n162_), .C(new_n117_), .Y(new_n163_));
  INVx1_ASAP7_75t_R   g077(.A(new_n163_), .Y(new_n164_));
  OR3x1_ASAP7_75t_R   g078(.A(new_n88_), .B(new_n89_), .C(new_n90_), .Y(new_n165_));
  OR3x1_ASAP7_75t_R   g079(.A(G866), .B(new_n165_), .C(new_n96_), .Y(new_n166_));
  NOR2x1_ASAP7_75t_R  g080(.A(G60), .B(new_n166_), .Y(new_n167_));
  AO21x1_ASAP7_75t_R  g081(.A1(G11), .A2(G40), .B(G866), .Y(new_n168_));
  OAI21x1_ASAP7_75t_R g082(.A1(new_n92_), .A2(new_n168_), .B(G1), .Y(new_n169_));
  NOR2x1_ASAP7_75t_R  g083(.A(new_n119_), .B(G866), .Y(new_n170_));
  XOR2x2_ASAP7_75t_R  g084(.A(G8), .B(G4), .Y(new_n171_));
  AND3x1_ASAP7_75t_R  g085(.A(G11), .B(new_n171_), .C(new_n170_), .Y(new_n172_));
  OR3x1_ASAP7_75t_R   g086(.A(new_n92_), .B(new_n95_), .C(new_n127_), .Y(new_n173_));
  INVx1_ASAP7_75t_R   g087(.A(new_n173_), .Y(new_n174_));
  OR3x1_ASAP7_75t_R   g088(.A(new_n88_), .B(new_n94_), .C(new_n87_), .Y(new_n175_));
  AOI21x1_ASAP7_75t_R g089(.A1(new_n174_), .A2(new_n175_), .B(new_n172_), .Y(new_n176_));
  NOR2x1_ASAP7_75t_R  g090(.A(new_n107_), .B(new_n176_), .Y(new_n177_));
  AO21x1_ASAP7_75t_R  g091(.A1(G39), .A2(new_n169_), .B(new_n177_), .Y(new_n178_));
  NOR2x1_ASAP7_75t_R  g092(.A(new_n167_), .B(new_n178_), .Y(new_n179_));
  NOR2x1_ASAP7_75t_R  g093(.A(new_n118_), .B(new_n179_), .Y(new_n180_));
  AO21x1_ASAP7_75t_R  g094(.A1(G55), .A2(G59), .B(new_n180_), .Y(new_n181_));
  AO21x1_ASAP7_75t_R  g095(.A1(G48), .A2(new_n164_), .B(new_n181_), .Y(new_n182_));
  OR3x1_ASAP7_75t_R   g096(.A(new_n167_), .B(new_n178_), .C(G48), .Y(new_n183_));
  INVx1_ASAP7_75t_R   g097(.A(new_n183_), .Y(new_n184_));
  NOR2x1_ASAP7_75t_R  g098(.A(new_n115_), .B(new_n179_), .Y(new_n185_));
  NOR2x1_ASAP7_75t_R  g099(.A(new_n184_), .B(new_n185_), .Y(new_n186_));
  AND2x2_ASAP7_75t_R  g100(.A(G53), .B(new_n185_), .Y(new_n187_));
  AO21x1_ASAP7_75t_R  g101(.A1(G52), .A2(new_n186_), .B(new_n187_), .Y(new_n188_));
  XNOR2x2_ASAP7_75t_R g102(.A(G58), .B(new_n186_), .Y(new_n189_));
  NOR2x1_ASAP7_75t_R  g103(.A(new_n121_), .B(new_n189_), .Y(new_n190_));
  AO21x1_ASAP7_75t_R  g104(.A1(G30), .A2(G50), .B(new_n190_), .Y(new_n191_));
  OR3x1_ASAP7_75t_R   g105(.A(new_n188_), .B(new_n191_), .C(new_n182_), .Y(new_n192_));
  INVx1_ASAP7_75t_R   g106(.A(new_n192_), .Y(G872));
  NOR2x1_ASAP7_75t_R  g107(.A(new_n104_), .B(new_n176_), .Y(new_n194_));
  AO21x1_ASAP7_75t_R  g108(.A1(G35), .A2(new_n169_), .B(new_n194_), .Y(new_n195_));
  NOR2x1_ASAP7_75t_R  g109(.A(new_n167_), .B(new_n195_), .Y(new_n196_));
  NOR2x1_ASAP7_75t_R  g110(.A(new_n118_), .B(new_n196_), .Y(new_n197_));
  AO21x1_ASAP7_75t_R  g111(.A1(G45), .A2(new_n164_), .B(new_n197_), .Y(new_n198_));
  OR3x1_ASAP7_75t_R   g112(.A(new_n167_), .B(new_n195_), .C(G45), .Y(new_n199_));
  NOR2x1_ASAP7_75t_R  g113(.A(new_n112_), .B(new_n196_), .Y(new_n200_));
  INVx1_ASAP7_75t_R   g114(.A(new_n200_), .Y(new_n201_));
  AND2x2_ASAP7_75t_R  g115(.A(new_n199_), .B(new_n201_), .Y(new_n202_));
  NOR2x1_ASAP7_75t_R  g116(.A(new_n120_), .B(new_n201_), .Y(new_n203_));
  AO21x1_ASAP7_75t_R  g117(.A1(G52), .A2(new_n202_), .B(new_n203_), .Y(new_n204_));
  NOR2x1_ASAP7_75t_R  g118(.A(new_n106_), .B(new_n176_), .Y(new_n205_));
  AO21x1_ASAP7_75t_R  g119(.A1(G37), .A2(new_n169_), .B(new_n205_), .Y(new_n206_));
  NOR2x1_ASAP7_75t_R  g120(.A(new_n167_), .B(new_n206_), .Y(new_n207_));
  OR3x1_ASAP7_75t_R   g121(.A(new_n167_), .B(new_n206_), .C(G47), .Y(new_n208_));
  INVx1_ASAP7_75t_R   g122(.A(new_n208_), .Y(new_n209_));
  NOR2x1_ASAP7_75t_R  g123(.A(new_n105_), .B(new_n176_), .Y(new_n210_));
  AO21x1_ASAP7_75t_R  g124(.A1(G36), .A2(new_n169_), .B(new_n210_), .Y(new_n211_));
  NOR2x1_ASAP7_75t_R  g125(.A(new_n167_), .B(new_n211_), .Y(new_n212_));
  OR3x1_ASAP7_75t_R   g126(.A(new_n167_), .B(new_n211_), .C(G46), .Y(new_n213_));
  AND2x2_ASAP7_75t_R  g127(.A(new_n208_), .B(new_n213_), .Y(new_n214_));
  AND3x1_ASAP7_75t_R  g128(.A(G58), .B(new_n183_), .C(new_n214_), .Y(new_n215_));
  AND3x1_ASAP7_75t_R  g129(.A(new_n208_), .B(new_n213_), .C(new_n185_), .Y(new_n216_));
  NOR2x1_ASAP7_75t_R  g130(.A(new_n114_), .B(new_n207_), .Y(new_n217_));
  NOR2x1_ASAP7_75t_R  g131(.A(new_n113_), .B(new_n212_), .Y(new_n218_));
  INVx1_ASAP7_75t_R   g132(.A(new_n218_), .Y(new_n219_));
  AO21x1_ASAP7_75t_R  g133(.A1(new_n213_), .A2(new_n217_), .B(new_n218_), .Y(new_n220_));
  OR3x1_ASAP7_75t_R   g134(.A(new_n215_), .B(new_n216_), .C(new_n220_), .Y(new_n221_));
  XNOR2x2_ASAP7_75t_R g135(.A(new_n202_), .B(new_n221_), .Y(new_n222_));
  NOR2x1_ASAP7_75t_R  g136(.A(new_n121_), .B(new_n222_), .Y(new_n223_));
  AO21x1_ASAP7_75t_R  g137(.A1(G27), .A2(G50), .B(new_n223_), .Y(new_n224_));
  OR3x1_ASAP7_75t_R   g138(.A(new_n204_), .B(new_n224_), .C(new_n198_), .Y(new_n225_));
  INVx1_ASAP7_75t_R   g139(.A(new_n225_), .Y(G873));
  NOR2x1_ASAP7_75t_R  g140(.A(new_n118_), .B(new_n212_), .Y(new_n227_));
  AO21x1_ASAP7_75t_R  g141(.A1(G55), .A2(G56), .B(new_n227_), .Y(new_n228_));
  AO21x1_ASAP7_75t_R  g142(.A1(G46), .A2(new_n164_), .B(new_n228_), .Y(new_n229_));
  AND2x2_ASAP7_75t_R  g143(.A(new_n213_), .B(new_n219_), .Y(new_n230_));
  NOR2x1_ASAP7_75t_R  g144(.A(new_n120_), .B(new_n219_), .Y(new_n231_));
  AO21x1_ASAP7_75t_R  g145(.A1(G52), .A2(new_n230_), .B(new_n231_), .Y(new_n232_));
  NOR2x1_ASAP7_75t_R  g146(.A(new_n184_), .B(new_n209_), .Y(new_n233_));
  AO21x1_ASAP7_75t_R  g147(.A1(new_n185_), .A2(new_n208_), .B(new_n217_), .Y(new_n234_));
  AO21x1_ASAP7_75t_R  g148(.A1(G58), .A2(new_n233_), .B(new_n234_), .Y(new_n235_));
  XNOR2x2_ASAP7_75t_R g149(.A(new_n230_), .B(new_n235_), .Y(new_n236_));
  NOR2x1_ASAP7_75t_R  g150(.A(new_n121_), .B(new_n236_), .Y(new_n237_));
  AO21x1_ASAP7_75t_R  g151(.A1(G28), .A2(G50), .B(new_n237_), .Y(new_n238_));
  OR3x1_ASAP7_75t_R   g152(.A(new_n232_), .B(new_n238_), .C(new_n229_), .Y(new_n239_));
  INVx1_ASAP7_75t_R   g153(.A(new_n239_), .Y(G874));
  NOR2x1_ASAP7_75t_R  g154(.A(new_n118_), .B(new_n207_), .Y(new_n241_));
  AO21x1_ASAP7_75t_R  g155(.A1(G55), .A2(G57), .B(new_n241_), .Y(new_n242_));
  AO21x1_ASAP7_75t_R  g156(.A1(G47), .A2(new_n164_), .B(new_n242_), .Y(new_n243_));
  NOR2x1_ASAP7_75t_R  g157(.A(new_n209_), .B(new_n217_), .Y(new_n244_));
  AND2x2_ASAP7_75t_R  g158(.A(G53), .B(new_n217_), .Y(new_n245_));
  AO21x1_ASAP7_75t_R  g159(.A1(G52), .A2(new_n244_), .B(new_n245_), .Y(new_n246_));
  AO21x1_ASAP7_75t_R  g160(.A1(G58), .A2(new_n183_), .B(new_n185_), .Y(new_n247_));
  XNOR2x2_ASAP7_75t_R g161(.A(new_n244_), .B(new_n247_), .Y(new_n248_));
  NOR2x1_ASAP7_75t_R  g162(.A(new_n121_), .B(new_n248_), .Y(new_n249_));
  AO21x1_ASAP7_75t_R  g163(.A1(G29), .A2(G50), .B(new_n249_), .Y(new_n250_));
  OR3x1_ASAP7_75t_R   g164(.A(new_n246_), .B(new_n250_), .C(new_n243_), .Y(new_n251_));
  INVx1_ASAP7_75t_R   g165(.A(new_n251_), .Y(G875));
  NOR2x1_ASAP7_75t_R  g166(.A(new_n100_), .B(new_n176_), .Y(new_n253_));
  AO21x1_ASAP7_75t_R  g167(.A1(G2), .A2(G34), .B(new_n253_), .Y(new_n254_));
  NOR2x1_ASAP7_75t_R  g168(.A(new_n96_), .B(new_n168_), .Y(new_n255_));
  OR3x1_ASAP7_75t_R   g169(.A(new_n92_), .B(G866), .C(new_n165_), .Y(new_n256_));
  NOR2x1_ASAP7_75t_R  g170(.A(G60), .B(new_n256_), .Y(new_n257_));
  AO21x1_ASAP7_75t_R  g171(.A1(G35), .A2(new_n255_), .B(new_n257_), .Y(new_n258_));
  NOR2x1_ASAP7_75t_R  g172(.A(new_n254_), .B(new_n258_), .Y(new_n259_));
  NOR2x1_ASAP7_75t_R  g173(.A(new_n108_), .B(new_n259_), .Y(new_n260_));
  INVx1_ASAP7_75t_R   g174(.A(new_n260_), .Y(new_n261_));
  AO21x1_ASAP7_75t_R  g175(.A1(new_n199_), .A2(new_n221_), .B(new_n200_), .Y(new_n262_));
  INVx1_ASAP7_75t_R   g176(.A(new_n262_), .Y(new_n263_));
  NOR2x1_ASAP7_75t_R  g177(.A(new_n103_), .B(new_n176_), .Y(new_n264_));
  AO21x1_ASAP7_75t_R  g178(.A1(G34), .A2(G38), .B(new_n264_), .Y(new_n265_));
  AO21x1_ASAP7_75t_R  g179(.A1(G39), .A2(new_n255_), .B(new_n257_), .Y(new_n266_));
  NOR2x1_ASAP7_75t_R  g180(.A(new_n265_), .B(new_n266_), .Y(new_n267_));
  AND2x2_ASAP7_75t_R  g181(.A(new_n111_), .B(new_n267_), .Y(new_n268_));
  NOR2x1_ASAP7_75t_R  g182(.A(new_n102_), .B(new_n176_), .Y(new_n269_));
  AO21x1_ASAP7_75t_R  g183(.A1(G4), .A2(G34), .B(new_n269_), .Y(new_n270_));
  AO21x1_ASAP7_75t_R  g184(.A1(G37), .A2(new_n255_), .B(new_n257_), .Y(new_n271_));
  NOR2x1_ASAP7_75t_R  g185(.A(new_n270_), .B(new_n271_), .Y(new_n272_));
  AND2x2_ASAP7_75t_R  g186(.A(new_n110_), .B(new_n272_), .Y(new_n273_));
  NOR2x1_ASAP7_75t_R  g187(.A(new_n101_), .B(new_n176_), .Y(new_n274_));
  AO21x1_ASAP7_75t_R  g188(.A1(G9), .A2(G34), .B(new_n274_), .Y(new_n275_));
  AO21x1_ASAP7_75t_R  g189(.A1(G36), .A2(new_n255_), .B(new_n257_), .Y(new_n276_));
  NOR2x1_ASAP7_75t_R  g190(.A(new_n275_), .B(new_n276_), .Y(new_n277_));
  AO21x1_ASAP7_75t_R  g191(.A1(new_n109_), .A2(new_n277_), .B(new_n273_), .Y(new_n278_));
  OR3x1_ASAP7_75t_R   g192(.A(new_n263_), .B(new_n268_), .C(new_n278_), .Y(new_n279_));
  NOR2x1_ASAP7_75t_R  g193(.A(new_n111_), .B(new_n267_), .Y(new_n280_));
  INVx1_ASAP7_75t_R   g194(.A(new_n280_), .Y(new_n281_));
  OAI21x1_ASAP7_75t_R g195(.A1(new_n278_), .A2(new_n281_), .B(new_n279_), .Y(new_n282_));
  NOR2x1_ASAP7_75t_R  g196(.A(new_n110_), .B(new_n272_), .Y(new_n283_));
  INVx1_ASAP7_75t_R   g197(.A(new_n283_), .Y(new_n284_));
  AOI21x1_ASAP7_75t_R g198(.A1(new_n109_), .A2(new_n277_), .B(new_n284_), .Y(new_n285_));
  NOR2x1_ASAP7_75t_R  g199(.A(new_n109_), .B(new_n277_), .Y(new_n286_));
  OR3x1_ASAP7_75t_R   g200(.A(new_n285_), .B(new_n286_), .C(new_n282_), .Y(new_n287_));
  NAND2x1_ASAP7_75t_R g201(.A(new_n108_), .B(new_n259_), .Y(new_n288_));
  AOI21x1_ASAP7_75t_R g202(.A1(new_n287_), .A2(new_n288_), .B(new_n260_), .Y(G876));
  NOR2x1_ASAP7_75t_R  g203(.A(new_n118_), .B(new_n267_), .Y(new_n290_));
  AO21x1_ASAP7_75t_R  g204(.A1(G44), .A2(new_n164_), .B(new_n290_), .Y(new_n291_));
  NOR2x1_ASAP7_75t_R  g205(.A(new_n268_), .B(new_n280_), .Y(new_n292_));
  NOR2x1_ASAP7_75t_R  g206(.A(new_n120_), .B(new_n281_), .Y(new_n293_));
  AO21x1_ASAP7_75t_R  g207(.A1(G52), .A2(new_n292_), .B(new_n293_), .Y(new_n294_));
  XNOR2x2_ASAP7_75t_R g208(.A(new_n262_), .B(new_n292_), .Y(new_n295_));
  NOR2x1_ASAP7_75t_R  g209(.A(new_n121_), .B(new_n295_), .Y(new_n296_));
  AO21x1_ASAP7_75t_R  g210(.A1(G26), .A2(G50), .B(new_n296_), .Y(new_n297_));
  OR3x1_ASAP7_75t_R   g211(.A(new_n294_), .B(new_n297_), .C(new_n291_), .Y(new_n298_));
  INVx1_ASAP7_75t_R   g212(.A(new_n298_), .Y(G877));
  NOR2x1_ASAP7_75t_R  g213(.A(new_n118_), .B(new_n259_), .Y(new_n300_));
  AO21x1_ASAP7_75t_R  g214(.A1(G41), .A2(new_n164_), .B(new_n300_), .Y(new_n301_));
  AND2x2_ASAP7_75t_R  g215(.A(new_n261_), .B(new_n288_), .Y(new_n302_));
  NOR2x1_ASAP7_75t_R  g216(.A(new_n120_), .B(new_n261_), .Y(new_n303_));
  AO21x1_ASAP7_75t_R  g217(.A1(G52), .A2(new_n302_), .B(new_n303_), .Y(new_n304_));
  XNOR2x2_ASAP7_75t_R g218(.A(new_n287_), .B(new_n302_), .Y(new_n305_));
  NOR2x1_ASAP7_75t_R  g219(.A(new_n121_), .B(new_n305_), .Y(new_n306_));
  AO21x1_ASAP7_75t_R  g220(.A1(G60), .A2(G50), .B(new_n306_), .Y(new_n307_));
  OR3x1_ASAP7_75t_R   g221(.A(new_n304_), .B(new_n307_), .C(new_n301_), .Y(new_n308_));
  INVx1_ASAP7_75t_R   g222(.A(new_n308_), .Y(G878));
  NOR2x1_ASAP7_75t_R  g223(.A(new_n118_), .B(new_n277_), .Y(new_n310_));
  AO21x1_ASAP7_75t_R  g224(.A1(G42), .A2(new_n164_), .B(new_n310_), .Y(new_n311_));
  AOI21x1_ASAP7_75t_R g225(.A1(new_n109_), .A2(new_n277_), .B(new_n286_), .Y(new_n312_));
  AND2x2_ASAP7_75t_R  g226(.A(G53), .B(new_n286_), .Y(new_n313_));
  AO21x1_ASAP7_75t_R  g227(.A1(G52), .A2(new_n312_), .B(new_n313_), .Y(new_n314_));
  NOR2x1_ASAP7_75t_R  g228(.A(new_n268_), .B(new_n273_), .Y(new_n315_));
  OAI21x1_ASAP7_75t_R g229(.A1(new_n273_), .A2(new_n281_), .B(new_n284_), .Y(new_n316_));
  AO21x1_ASAP7_75t_R  g230(.A1(new_n262_), .A2(new_n315_), .B(new_n316_), .Y(new_n317_));
  XNOR2x2_ASAP7_75t_R g231(.A(new_n312_), .B(new_n317_), .Y(new_n318_));
  NOR2x1_ASAP7_75t_R  g232(.A(new_n121_), .B(new_n318_), .Y(new_n319_));
  AO21x1_ASAP7_75t_R  g233(.A1(G24), .A2(G50), .B(new_n319_), .Y(new_n320_));
  OR3x1_ASAP7_75t_R   g234(.A(new_n314_), .B(new_n320_), .C(new_n311_), .Y(new_n321_));
  INVx1_ASAP7_75t_R   g235(.A(new_n321_), .Y(G879));
  NOR2x1_ASAP7_75t_R  g236(.A(new_n118_), .B(new_n272_), .Y(new_n323_));
  AO21x1_ASAP7_75t_R  g237(.A1(G43), .A2(new_n164_), .B(new_n323_), .Y(new_n324_));
  NOR2x1_ASAP7_75t_R  g238(.A(new_n273_), .B(new_n283_), .Y(new_n325_));
  NOR2x1_ASAP7_75t_R  g239(.A(new_n120_), .B(new_n284_), .Y(new_n326_));
  AO21x1_ASAP7_75t_R  g240(.A1(G52), .A2(new_n325_), .B(new_n326_), .Y(new_n327_));
  OAI21x1_ASAP7_75t_R g241(.A1(new_n263_), .A2(new_n268_), .B(new_n281_), .Y(new_n328_));
  XNOR2x2_ASAP7_75t_R g242(.A(new_n325_), .B(new_n328_), .Y(new_n329_));
  NOR2x1_ASAP7_75t_R  g243(.A(new_n121_), .B(new_n329_), .Y(new_n330_));
  AO21x1_ASAP7_75t_R  g244(.A1(G25), .A2(G50), .B(new_n330_), .Y(new_n331_));
  OR3x1_ASAP7_75t_R   g245(.A(new_n327_), .B(new_n331_), .C(new_n324_), .Y(new_n332_));
  INVx1_ASAP7_75t_R   g246(.A(new_n332_), .Y(G880));
endmodule


