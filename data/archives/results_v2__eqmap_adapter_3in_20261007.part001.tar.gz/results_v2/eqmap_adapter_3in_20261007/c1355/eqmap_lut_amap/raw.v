// Benchmark "/home/flynn/workplace/MIGBalance/results_v2/eqmap_adapter_3in_20261007/c1355/eqmap_lut_amap/stage" written by ABC on Wed Oct  7 16:25:22 2026

module \/home/flynn/workplace/MIGBalance/results_v2/eqmap_adapter_3in_20261007/c1355/eqmap_lut_amap/stage  ( 
    G1, G10, G11, G12, G13, G14, G15, G16, G17, G18, G19, G2, G20, G21,
    G22, G23, G24, G25, G26, G27, G28, G29, G3, G30, G31, G32, G33, G34,
    G35, G36, G37, G38, G39, G4, G40, G41, G5, G6, G7, G8, G9,
    G1324, G1325, G1326, G1327, G1328, G1329, G1330, G1331, G1332, G1333,
    G1334, G1335, G1336, G1337, G1338, G1339, G1340, G1341, G1342, G1343,
    G1344, G1345, G1346, G1347, G1348, G1349, G1350, G1351, G1352, G1353,
    G1354, G1355  );
  input  G1, G10, G11, G12, G13, G14, G15, G16, G17, G18, G19, G2, G20,
    G21, G22, G23, G24, G25, G26, G27, G28, G29, G3, G30, G31, G32, G33,
    G34, G35, G36, G37, G38, G39, G4, G40, G41, G5, G6, G7, G8, G9;
  output G1324, G1325, G1326, G1327, G1328, G1329, G1330, G1331, G1332, G1333,
    G1334, G1335, G1336, G1337, G1338, G1339, G1340, G1341, G1342, G1343,
    G1344, G1345, G1346, G1347, G1348, G1349, G1350, G1351, G1352, G1353,
    G1354, G1355;
  wire new_n74_, new_n75_, new_n76_, new_n77_, new_n78_, new_n79_, new_n80_,
    new_n81_, new_n82_, new_n83_, new_n84_, new_n85_, new_n86_, new_n87_,
    new_n88_, new_n89_, new_n90_, new_n91_, new_n92_, new_n93_, new_n94_,
    new_n95_, new_n96_, new_n97_, new_n98_, new_n99_, new_n100_, new_n101_,
    new_n102_, new_n103_, new_n104_, new_n105_, new_n106_, new_n107_,
    new_n108_, new_n109_, new_n110_, new_n111_, new_n112_, new_n113_,
    new_n114_, new_n115_, new_n116_, new_n117_, new_n118_, new_n119_,
    new_n120_, new_n121_, new_n122_, new_n123_, new_n124_, new_n125_,
    new_n126_, new_n127_, new_n128_, new_n129_, new_n130_, new_n131_,
    new_n132_, new_n133_, new_n134_, new_n135_, new_n136_, new_n137_,
    new_n138_, new_n139_, new_n140_, new_n141_, new_n142_, new_n143_,
    new_n144_, new_n145_, new_n146_, new_n147_, new_n148_, new_n149_,
    new_n150_, new_n151_, new_n152_, new_n153_, new_n154_, new_n155_,
    new_n156_, new_n157_, new_n158_, new_n159_, new_n160_, new_n161_,
    new_n162_, new_n163_, new_n164_, new_n165_, new_n166_, new_n167_,
    new_n168_, new_n169_, new_n170_, new_n171_, new_n172_, new_n173_,
    new_n174_, new_n175_, new_n176_, new_n177_, new_n178_, new_n179_,
    new_n180_, new_n181_, new_n182_, new_n183_, new_n184_, new_n185_,
    new_n186_, new_n187_, new_n188_, new_n189_, new_n190_, new_n191_,
    new_n192_, new_n193_, new_n194_, new_n195_, new_n196_, new_n197_,
    new_n198_, new_n199_, new_n200_, new_n201_, new_n202_, new_n203_,
    new_n204_, new_n205_, new_n206_, new_n207_, new_n208_, new_n209_,
    new_n210_, new_n211_, new_n212_, new_n213_, new_n214_, new_n215_,
    new_n216_, new_n217_, new_n218_, new_n219_, new_n220_, new_n221_,
    new_n222_, new_n223_, new_n224_, new_n225_, new_n226_, new_n227_,
    new_n228_, new_n229_, new_n230_, new_n231_, new_n232_, new_n233_,
    new_n234_, new_n235_, new_n236_, new_n237_, new_n238_, new_n239_,
    new_n240_, new_n241_, new_n242_, new_n243_, new_n244_, new_n245_,
    new_n246_, new_n247_, new_n248_, new_n249_, new_n250_, new_n251_,
    new_n252_, new_n253_, new_n254_, new_n255_, new_n256_, new_n257_,
    new_n258_, new_n259_, new_n260_, new_n261_, new_n262_, new_n263_,
    new_n265_, new_n266_, new_n268_, new_n269_, new_n271_, new_n272_,
    new_n274_, new_n275_, new_n276_, new_n277_, new_n278_, new_n280_,
    new_n281_, new_n283_, new_n284_, new_n286_, new_n287_, new_n289_,
    new_n290_, new_n291_, new_n292_, new_n293_, new_n294_, new_n296_,
    new_n297_, new_n299_, new_n300_, new_n302_, new_n303_, new_n305_,
    new_n306_, new_n307_, new_n308_, new_n310_, new_n311_, new_n313_,
    new_n314_, new_n316_, new_n317_, new_n319_, new_n320_, new_n321_,
    new_n322_, new_n323_, new_n324_, new_n325_, new_n326_, new_n327_,
    new_n328_, new_n329_, new_n331_, new_n332_, new_n334_, new_n335_,
    new_n337_, new_n338_, new_n340_, new_n341_, new_n342_, new_n344_,
    new_n346_, new_n348_, new_n350_, new_n351_, new_n352_, new_n353_,
    new_n355_, new_n356_, new_n358_, new_n359_, new_n361_, new_n362_,
    new_n364_, new_n365_, new_n367_, new_n369_, new_n371_;
  INVx1_ASAP7_75t_R   g000(.A(G1), .Y(new_n74_));
  INVx1_ASAP7_75t_R   g001(.A(G10), .Y(new_n75_));
  INVx1_ASAP7_75t_R   g002(.A(G11), .Y(new_n76_));
  INVx1_ASAP7_75t_R   g003(.A(G12), .Y(new_n77_));
  INVx1_ASAP7_75t_R   g004(.A(G13), .Y(new_n78_));
  INVx1_ASAP7_75t_R   g005(.A(G14), .Y(new_n79_));
  INVx1_ASAP7_75t_R   g006(.A(G15), .Y(new_n80_));
  INVx1_ASAP7_75t_R   g007(.A(G16), .Y(new_n81_));
  INVx1_ASAP7_75t_R   g008(.A(G17), .Y(new_n82_));
  INVx1_ASAP7_75t_R   g009(.A(G18), .Y(new_n83_));
  INVx1_ASAP7_75t_R   g010(.A(G19), .Y(new_n84_));
  INVx1_ASAP7_75t_R   g011(.A(G2), .Y(new_n85_));
  INVx1_ASAP7_75t_R   g012(.A(G20), .Y(new_n86_));
  INVx1_ASAP7_75t_R   g013(.A(G21), .Y(new_n87_));
  INVx1_ASAP7_75t_R   g014(.A(G22), .Y(new_n88_));
  INVx1_ASAP7_75t_R   g015(.A(G23), .Y(new_n89_));
  INVx1_ASAP7_75t_R   g016(.A(G24), .Y(new_n90_));
  INVx1_ASAP7_75t_R   g017(.A(G25), .Y(new_n91_));
  INVx1_ASAP7_75t_R   g018(.A(G26), .Y(new_n92_));
  INVx1_ASAP7_75t_R   g019(.A(G27), .Y(new_n93_));
  INVx1_ASAP7_75t_R   g020(.A(G28), .Y(new_n94_));
  INVx1_ASAP7_75t_R   g021(.A(G29), .Y(new_n95_));
  INVx1_ASAP7_75t_R   g022(.A(G3), .Y(new_n96_));
  INVx1_ASAP7_75t_R   g023(.A(G30), .Y(new_n97_));
  INVx1_ASAP7_75t_R   g024(.A(G31), .Y(new_n98_));
  INVx1_ASAP7_75t_R   g025(.A(G32), .Y(new_n99_));
  INVx1_ASAP7_75t_R   g026(.A(G33), .Y(new_n100_));
  INVx1_ASAP7_75t_R   g027(.A(G34), .Y(new_n101_));
  INVx1_ASAP7_75t_R   g028(.A(G4), .Y(new_n102_));
  INVx1_ASAP7_75t_R   g029(.A(G41), .Y(new_n103_));
  INVx1_ASAP7_75t_R   g030(.A(G5), .Y(new_n104_));
  INVx1_ASAP7_75t_R   g031(.A(G6), .Y(new_n105_));
  INVx1_ASAP7_75t_R   g032(.A(G7), .Y(new_n106_));
  INVx1_ASAP7_75t_R   g033(.A(G8), .Y(new_n107_));
  INVx1_ASAP7_75t_R   g034(.A(G9), .Y(new_n108_));
  XOR2x2_ASAP7_75t_R  g035(.A(new_n84_), .B(new_n86_), .Y(new_n109_));
  XNOR2x2_ASAP7_75t_R g036(.A(new_n83_), .B(new_n109_), .Y(new_n110_));
  XOR2x2_ASAP7_75t_R  g037(.A(G18), .B(new_n109_), .Y(new_n111_));
  NOR2x1_ASAP7_75t_R  g038(.A(G17), .B(new_n111_), .Y(new_n112_));
  AO21x1_ASAP7_75t_R  g039(.A1(G17), .A2(new_n110_), .B(new_n112_), .Y(new_n113_));
  XOR2x2_ASAP7_75t_R  g040(.A(new_n89_), .B(new_n90_), .Y(new_n114_));
  XNOR2x2_ASAP7_75t_R g041(.A(new_n88_), .B(new_n114_), .Y(new_n115_));
  XOR2x2_ASAP7_75t_R  g042(.A(G22), .B(new_n114_), .Y(new_n116_));
  NOR2x1_ASAP7_75t_R  g043(.A(G21), .B(new_n116_), .Y(new_n117_));
  AO21x1_ASAP7_75t_R  g044(.A1(G21), .A2(new_n115_), .B(new_n117_), .Y(new_n118_));
  XNOR2x2_ASAP7_75t_R g045(.A(new_n78_), .B(new_n104_), .Y(new_n119_));
  AO21x1_ASAP7_75t_R  g046(.A1(new_n100_), .A2(G41), .B(new_n103_), .Y(new_n120_));
  OR3x1_ASAP7_75t_R   g047(.A(new_n100_), .B(new_n103_), .C(new_n119_), .Y(new_n121_));
  INVx1_ASAP7_75t_R   g048(.A(new_n121_), .Y(new_n122_));
  AO21x1_ASAP7_75t_R  g049(.A1(new_n119_), .A2(new_n120_), .B(new_n122_), .Y(new_n123_));
  XNOR2x2_ASAP7_75t_R g050(.A(new_n74_), .B(new_n123_), .Y(new_n124_));
  XOR2x2_ASAP7_75t_R  g051(.A(G1), .B(new_n123_), .Y(new_n125_));
  NOR2x1_ASAP7_75t_R  g052(.A(G9), .B(new_n125_), .Y(new_n126_));
  AO21x1_ASAP7_75t_R  g053(.A1(G9), .A2(new_n124_), .B(new_n126_), .Y(new_n127_));
  XOR2x2_ASAP7_75t_R  g054(.A(new_n118_), .B(new_n127_), .Y(new_n128_));
  XOR2x2_ASAP7_75t_R  g055(.A(new_n118_), .B(new_n127_), .Y(new_n129_));
  NOR2x1_ASAP7_75t_R  g056(.A(new_n113_), .B(new_n129_), .Y(new_n130_));
  AO21x1_ASAP7_75t_R  g057(.A1(new_n113_), .A2(new_n128_), .B(new_n130_), .Y(new_n131_));
  INVx1_ASAP7_75t_R   g058(.A(new_n131_), .Y(new_n132_));
  XNOR2x2_ASAP7_75t_R g059(.A(new_n86_), .B(new_n90_), .Y(new_n133_));
  XOR2x2_ASAP7_75t_R  g060(.A(new_n94_), .B(new_n99_), .Y(new_n134_));
  NAND2x1_ASAP7_75t_R g061(.A(G40), .B(G41), .Y(new_n135_));
  XNOR2x2_ASAP7_75t_R g062(.A(new_n134_), .B(new_n135_), .Y(new_n136_));
  XNOR2x2_ASAP7_75t_R g063(.A(new_n134_), .B(new_n135_), .Y(new_n137_));
  NOR2x1_ASAP7_75t_R  g064(.A(new_n133_), .B(new_n137_), .Y(new_n138_));
  AO21x1_ASAP7_75t_R  g065(.A1(new_n133_), .A2(new_n136_), .B(new_n138_), .Y(new_n139_));
  XOR2x2_ASAP7_75t_R  g066(.A(new_n79_), .B(new_n80_), .Y(new_n140_));
  XNOR2x2_ASAP7_75t_R g067(.A(new_n81_), .B(new_n140_), .Y(new_n141_));
  NAND2x1_ASAP7_75t_R g068(.A(G13), .B(new_n141_), .Y(new_n142_));
  XOR2x2_ASAP7_75t_R  g069(.A(G16), .B(new_n140_), .Y(new_n143_));
  OA21x2_ASAP7_75t_R  g070(.A1(G13), .A2(new_n143_), .B(new_n142_), .Y(new_n144_));
  XOR2x2_ASAP7_75t_R  g071(.A(new_n105_), .B(new_n106_), .Y(new_n145_));
  XNOR2x2_ASAP7_75t_R g072(.A(new_n107_), .B(new_n145_), .Y(new_n146_));
  XOR2x2_ASAP7_75t_R  g073(.A(G8), .B(new_n145_), .Y(new_n147_));
  NOR2x1_ASAP7_75t_R  g074(.A(G5), .B(new_n147_), .Y(new_n148_));
  AO21x1_ASAP7_75t_R  g075(.A1(G5), .A2(new_n146_), .B(new_n148_), .Y(new_n149_));
  INVx1_ASAP7_75t_R   g076(.A(new_n149_), .Y(new_n150_));
  XNOR2x2_ASAP7_75t_R g077(.A(new_n144_), .B(new_n149_), .Y(new_n151_));
  XOR2x2_ASAP7_75t_R  g078(.A(new_n144_), .B(new_n150_), .Y(new_n152_));
  NOR2x1_ASAP7_75t_R  g079(.A(new_n139_), .B(new_n152_), .Y(new_n153_));
  AO21x1_ASAP7_75t_R  g080(.A1(new_n139_), .A2(new_n151_), .B(new_n153_), .Y(new_n154_));
  INVx1_ASAP7_75t_R   g081(.A(new_n154_), .Y(new_n155_));
  XNOR2x2_ASAP7_75t_R g082(.A(new_n84_), .B(new_n89_), .Y(new_n156_));
  XOR2x2_ASAP7_75t_R  g083(.A(new_n93_), .B(new_n98_), .Y(new_n157_));
  NAND2x1_ASAP7_75t_R g084(.A(G39), .B(G41), .Y(new_n158_));
  XNOR2x2_ASAP7_75t_R g085(.A(new_n157_), .B(new_n158_), .Y(new_n159_));
  XNOR2x2_ASAP7_75t_R g086(.A(new_n157_), .B(new_n158_), .Y(new_n160_));
  NOR2x1_ASAP7_75t_R  g087(.A(new_n156_), .B(new_n160_), .Y(new_n161_));
  AO21x1_ASAP7_75t_R  g088(.A1(new_n156_), .A2(new_n159_), .B(new_n161_), .Y(new_n162_));
  XOR2x2_ASAP7_75t_R  g089(.A(new_n75_), .B(new_n76_), .Y(new_n163_));
  XNOR2x2_ASAP7_75t_R g090(.A(new_n77_), .B(new_n163_), .Y(new_n164_));
  XOR2x2_ASAP7_75t_R  g091(.A(G12), .B(new_n163_), .Y(new_n165_));
  NOR2x1_ASAP7_75t_R  g092(.A(G9), .B(new_n165_), .Y(new_n166_));
  AO21x1_ASAP7_75t_R  g093(.A1(G9), .A2(new_n164_), .B(new_n166_), .Y(new_n167_));
  XOR2x2_ASAP7_75t_R  g094(.A(new_n85_), .B(new_n96_), .Y(new_n168_));
  XNOR2x2_ASAP7_75t_R g095(.A(new_n102_), .B(new_n168_), .Y(new_n169_));
  XOR2x2_ASAP7_75t_R  g096(.A(G4), .B(new_n168_), .Y(new_n170_));
  NOR2x1_ASAP7_75t_R  g097(.A(G1), .B(new_n170_), .Y(new_n171_));
  AO21x1_ASAP7_75t_R  g098(.A1(G1), .A2(new_n169_), .B(new_n171_), .Y(new_n172_));
  XOR2x2_ASAP7_75t_R  g099(.A(new_n167_), .B(new_n172_), .Y(new_n173_));
  XOR2x2_ASAP7_75t_R  g100(.A(new_n167_), .B(new_n172_), .Y(new_n174_));
  NOR2x1_ASAP7_75t_R  g101(.A(new_n162_), .B(new_n174_), .Y(new_n175_));
  AO21x1_ASAP7_75t_R  g102(.A1(new_n162_), .A2(new_n173_), .B(new_n175_), .Y(new_n176_));
  INVx1_ASAP7_75t_R   g103(.A(new_n176_), .Y(new_n177_));
  NOR2x1_ASAP7_75t_R  g104(.A(new_n155_), .B(new_n176_), .Y(new_n178_));
  INVx1_ASAP7_75t_R   g105(.A(new_n178_), .Y(new_n179_));
  XNOR2x2_ASAP7_75t_R g106(.A(new_n83_), .B(new_n88_), .Y(new_n180_));
  XOR2x2_ASAP7_75t_R  g107(.A(new_n92_), .B(new_n97_), .Y(new_n181_));
  NAND2x1_ASAP7_75t_R g108(.A(G38), .B(G41), .Y(new_n182_));
  XNOR2x2_ASAP7_75t_R g109(.A(new_n181_), .B(new_n182_), .Y(new_n183_));
  XNOR2x2_ASAP7_75t_R g110(.A(new_n181_), .B(new_n182_), .Y(new_n184_));
  NOR2x1_ASAP7_75t_R  g111(.A(new_n180_), .B(new_n184_), .Y(new_n185_));
  AO21x1_ASAP7_75t_R  g112(.A1(new_n180_), .A2(new_n183_), .B(new_n185_), .Y(new_n186_));
  XNOR2x2_ASAP7_75t_R g113(.A(new_n144_), .B(new_n186_), .Y(new_n187_));
  XNOR2x2_ASAP7_75t_R g114(.A(new_n144_), .B(new_n186_), .Y(new_n188_));
  NOR2x1_ASAP7_75t_R  g115(.A(new_n167_), .B(new_n188_), .Y(new_n189_));
  AO21x1_ASAP7_75t_R  g116(.A1(new_n167_), .A2(new_n187_), .B(new_n189_), .Y(new_n190_));
  INVx1_ASAP7_75t_R   g117(.A(new_n190_), .Y(new_n191_));
  XNOR2x2_ASAP7_75t_R g118(.A(new_n82_), .B(new_n87_), .Y(new_n192_));
  XOR2x2_ASAP7_75t_R  g119(.A(new_n91_), .B(new_n95_), .Y(new_n193_));
  NAND2x1_ASAP7_75t_R g120(.A(G37), .B(G41), .Y(new_n194_));
  XNOR2x2_ASAP7_75t_R g121(.A(new_n193_), .B(new_n194_), .Y(new_n195_));
  XNOR2x2_ASAP7_75t_R g122(.A(new_n193_), .B(new_n194_), .Y(new_n196_));
  NOR2x1_ASAP7_75t_R  g123(.A(new_n192_), .B(new_n196_), .Y(new_n197_));
  AO21x1_ASAP7_75t_R  g124(.A1(new_n192_), .A2(new_n195_), .B(new_n197_), .Y(new_n198_));
  XNOR2x2_ASAP7_75t_R g125(.A(new_n150_), .B(new_n198_), .Y(new_n199_));
  XOR2x2_ASAP7_75t_R  g126(.A(new_n149_), .B(new_n198_), .Y(new_n200_));
  NOR2x1_ASAP7_75t_R  g127(.A(new_n172_), .B(new_n200_), .Y(new_n201_));
  AO21x1_ASAP7_75t_R  g128(.A1(new_n172_), .A2(new_n199_), .B(new_n201_), .Y(new_n202_));
  INVx1_ASAP7_75t_R   g129(.A(new_n202_), .Y(new_n203_));
  NOR2x1_ASAP7_75t_R  g130(.A(new_n191_), .B(new_n202_), .Y(new_n204_));
  INVx1_ASAP7_75t_R   g131(.A(new_n204_), .Y(new_n205_));
  XOR2x2_ASAP7_75t_R  g132(.A(new_n91_), .B(new_n92_), .Y(new_n206_));
  XNOR2x2_ASAP7_75t_R g133(.A(new_n94_), .B(new_n206_), .Y(new_n207_));
  XOR2x2_ASAP7_75t_R  g134(.A(G28), .B(new_n206_), .Y(new_n208_));
  NOR2x1_ASAP7_75t_R  g135(.A(G27), .B(new_n208_), .Y(new_n209_));
  AO21x1_ASAP7_75t_R  g136(.A1(G27), .A2(new_n207_), .B(new_n209_), .Y(new_n210_));
  XNOR2x2_ASAP7_75t_R g137(.A(new_n76_), .B(new_n80_), .Y(new_n211_));
  XOR2x2_ASAP7_75t_R  g138(.A(new_n96_), .B(new_n106_), .Y(new_n212_));
  NAND2x1_ASAP7_75t_R g139(.A(G35), .B(G41), .Y(new_n213_));
  XNOR2x2_ASAP7_75t_R g140(.A(new_n212_), .B(new_n213_), .Y(new_n214_));
  NAND2x1_ASAP7_75t_R g141(.A(new_n211_), .B(new_n214_), .Y(new_n215_));
  XNOR2x2_ASAP7_75t_R g142(.A(new_n212_), .B(new_n213_), .Y(new_n216_));
  OA21x2_ASAP7_75t_R  g143(.A1(new_n211_), .A2(new_n216_), .B(new_n215_), .Y(new_n217_));
  XNOR2x2_ASAP7_75t_R g144(.A(new_n113_), .B(new_n217_), .Y(new_n218_));
  XNOR2x2_ASAP7_75t_R g145(.A(new_n113_), .B(new_n217_), .Y(new_n219_));
  NOR2x1_ASAP7_75t_R  g146(.A(new_n210_), .B(new_n219_), .Y(new_n220_));
  AO21x1_ASAP7_75t_R  g147(.A1(new_n210_), .A2(new_n218_), .B(new_n220_), .Y(new_n221_));
  INVx1_ASAP7_75t_R   g148(.A(new_n221_), .Y(new_n222_));
  XOR2x2_ASAP7_75t_R  g149(.A(new_n95_), .B(new_n97_), .Y(new_n223_));
  XNOR2x2_ASAP7_75t_R g150(.A(new_n99_), .B(new_n223_), .Y(new_n224_));
  NAND2x1_ASAP7_75t_R g151(.A(G31), .B(new_n224_), .Y(new_n225_));
  XOR2x2_ASAP7_75t_R  g152(.A(G32), .B(new_n223_), .Y(new_n226_));
  OA21x2_ASAP7_75t_R  g153(.A1(G31), .A2(new_n226_), .B(new_n225_), .Y(new_n227_));
  XNOR2x2_ASAP7_75t_R g154(.A(new_n85_), .B(new_n105_), .Y(new_n228_));
  AO21x1_ASAP7_75t_R  g155(.A1(new_n101_), .A2(G41), .B(new_n103_), .Y(new_n229_));
  OR3x1_ASAP7_75t_R   g156(.A(new_n101_), .B(new_n103_), .C(new_n228_), .Y(new_n230_));
  INVx1_ASAP7_75t_R   g157(.A(new_n230_), .Y(new_n231_));
  AO21x1_ASAP7_75t_R  g158(.A1(new_n228_), .A2(new_n229_), .B(new_n231_), .Y(new_n232_));
  XNOR2x2_ASAP7_75t_R g159(.A(new_n79_), .B(new_n232_), .Y(new_n233_));
  XOR2x2_ASAP7_75t_R  g160(.A(G14), .B(new_n232_), .Y(new_n234_));
  NOR2x1_ASAP7_75t_R  g161(.A(G10), .B(new_n234_), .Y(new_n235_));
  AO21x1_ASAP7_75t_R  g162(.A1(G10), .A2(new_n233_), .B(new_n235_), .Y(new_n236_));
  XNOR2x2_ASAP7_75t_R g163(.A(new_n227_), .B(new_n236_), .Y(new_n237_));
  XNOR2x2_ASAP7_75t_R g164(.A(new_n227_), .B(new_n236_), .Y(new_n238_));
  NOR2x1_ASAP7_75t_R  g165(.A(new_n210_), .B(new_n238_), .Y(new_n239_));
  AO21x1_ASAP7_75t_R  g166(.A1(new_n210_), .A2(new_n237_), .B(new_n239_), .Y(new_n240_));
  INVx1_ASAP7_75t_R   g167(.A(new_n240_), .Y(new_n241_));
  XNOR2x2_ASAP7_75t_R g168(.A(new_n77_), .B(new_n102_), .Y(new_n242_));
  XOR2x2_ASAP7_75t_R  g169(.A(new_n81_), .B(new_n107_), .Y(new_n243_));
  NAND2x1_ASAP7_75t_R g170(.A(G36), .B(G41), .Y(new_n244_));
  XNOR2x2_ASAP7_75t_R g171(.A(new_n243_), .B(new_n244_), .Y(new_n245_));
  XNOR2x2_ASAP7_75t_R g172(.A(new_n243_), .B(new_n244_), .Y(new_n246_));
  NOR2x1_ASAP7_75t_R  g173(.A(new_n242_), .B(new_n246_), .Y(new_n247_));
  AO21x1_ASAP7_75t_R  g174(.A1(new_n242_), .A2(new_n245_), .B(new_n247_), .Y(new_n248_));
  XNOR2x2_ASAP7_75t_R g175(.A(new_n227_), .B(new_n248_), .Y(new_n249_));
  XNOR2x2_ASAP7_75t_R g176(.A(new_n227_), .B(new_n248_), .Y(new_n250_));
  NOR2x1_ASAP7_75t_R  g177(.A(new_n118_), .B(new_n250_), .Y(new_n251_));
  AO21x1_ASAP7_75t_R  g178(.A1(new_n118_), .A2(new_n249_), .B(new_n251_), .Y(new_n252_));
  INVx1_ASAP7_75t_R   g179(.A(new_n252_), .Y(new_n253_));
  XNOR2x2_ASAP7_75t_R g180(.A(new_n241_), .B(new_n252_), .Y(new_n254_));
  AND3x1_ASAP7_75t_R  g181(.A(new_n240_), .B(new_n252_), .C(new_n132_), .Y(new_n255_));
  AO21x1_ASAP7_75t_R  g182(.A1(new_n131_), .A2(new_n254_), .B(new_n255_), .Y(new_n256_));
  NAND2x1_ASAP7_75t_R g183(.A(new_n221_), .B(new_n256_), .Y(new_n257_));
  OR3x1_ASAP7_75t_R   g184(.A(new_n241_), .B(new_n253_), .C(new_n132_), .Y(new_n258_));
  OA21x2_ASAP7_75t_R  g185(.A1(new_n221_), .A2(new_n258_), .B(new_n257_), .Y(new_n259_));
  OR3x1_ASAP7_75t_R   g186(.A(new_n205_), .B(new_n259_), .C(new_n179_), .Y(new_n260_));
  INVx1_ASAP7_75t_R   g187(.A(new_n260_), .Y(new_n261_));
  AND3x1_ASAP7_75t_R  g188(.A(new_n132_), .B(new_n261_), .C(G1), .Y(new_n262_));
  AO21x1_ASAP7_75t_R  g189(.A1(new_n131_), .A2(new_n261_), .B(new_n260_), .Y(new_n263_));
  AO21x1_ASAP7_75t_R  g190(.A1(new_n74_), .A2(new_n263_), .B(new_n262_), .Y(G1324));
  AND3x1_ASAP7_75t_R  g191(.A(new_n241_), .B(new_n261_), .C(G2), .Y(new_n265_));
  AO21x1_ASAP7_75t_R  g192(.A1(new_n240_), .A2(new_n261_), .B(new_n260_), .Y(new_n266_));
  AO21x1_ASAP7_75t_R  g193(.A1(new_n85_), .A2(new_n266_), .B(new_n265_), .Y(G1325));
  AND3x1_ASAP7_75t_R  g194(.A(new_n222_), .B(new_n261_), .C(G3), .Y(new_n268_));
  AO21x1_ASAP7_75t_R  g195(.A1(new_n221_), .A2(new_n261_), .B(new_n260_), .Y(new_n269_));
  AO21x1_ASAP7_75t_R  g196(.A1(new_n96_), .A2(new_n269_), .B(new_n268_), .Y(G1326));
  AND3x1_ASAP7_75t_R  g197(.A(new_n253_), .B(new_n261_), .C(G4), .Y(new_n271_));
  AO21x1_ASAP7_75t_R  g198(.A1(new_n252_), .A2(new_n261_), .B(new_n260_), .Y(new_n272_));
  AO21x1_ASAP7_75t_R  g199(.A1(new_n102_), .A2(new_n272_), .B(new_n271_), .Y(G1327));
  NAND2x1_ASAP7_75t_R g200(.A(new_n155_), .B(new_n176_), .Y(new_n274_));
  OR3x1_ASAP7_75t_R   g201(.A(new_n259_), .B(new_n274_), .C(new_n205_), .Y(new_n275_));
  INVx1_ASAP7_75t_R   g202(.A(new_n275_), .Y(new_n276_));
  AND3x1_ASAP7_75t_R  g203(.A(new_n132_), .B(new_n276_), .C(G5), .Y(new_n277_));
  AO21x1_ASAP7_75t_R  g204(.A1(new_n131_), .A2(new_n276_), .B(new_n275_), .Y(new_n278_));
  AO21x1_ASAP7_75t_R  g205(.A1(new_n104_), .A2(new_n278_), .B(new_n277_), .Y(G1328));
  AND3x1_ASAP7_75t_R  g206(.A(new_n241_), .B(new_n276_), .C(G6), .Y(new_n280_));
  AO21x1_ASAP7_75t_R  g207(.A1(new_n240_), .A2(new_n276_), .B(new_n275_), .Y(new_n281_));
  AO21x1_ASAP7_75t_R  g208(.A1(new_n105_), .A2(new_n281_), .B(new_n280_), .Y(G1329));
  AND3x1_ASAP7_75t_R  g209(.A(new_n222_), .B(new_n276_), .C(G7), .Y(new_n283_));
  AO21x1_ASAP7_75t_R  g210(.A1(new_n221_), .A2(new_n276_), .B(new_n275_), .Y(new_n284_));
  AO21x1_ASAP7_75t_R  g211(.A1(new_n106_), .A2(new_n284_), .B(new_n283_), .Y(G1330));
  AND3x1_ASAP7_75t_R  g212(.A(new_n253_), .B(new_n276_), .C(G8), .Y(new_n286_));
  AO21x1_ASAP7_75t_R  g213(.A1(new_n252_), .A2(new_n276_), .B(new_n275_), .Y(new_n287_));
  AO21x1_ASAP7_75t_R  g214(.A1(new_n107_), .A2(new_n287_), .B(new_n286_), .Y(G1331));
  NOR2x1_ASAP7_75t_R  g215(.A(new_n190_), .B(new_n203_), .Y(new_n289_));
  INVx1_ASAP7_75t_R   g216(.A(new_n289_), .Y(new_n290_));
  OR3x1_ASAP7_75t_R   g217(.A(new_n259_), .B(new_n290_), .C(new_n179_), .Y(new_n291_));
  INVx1_ASAP7_75t_R   g218(.A(new_n291_), .Y(new_n292_));
  AND3x1_ASAP7_75t_R  g219(.A(new_n132_), .B(new_n292_), .C(G9), .Y(new_n293_));
  AO21x1_ASAP7_75t_R  g220(.A1(new_n131_), .A2(new_n292_), .B(new_n291_), .Y(new_n294_));
  AO21x1_ASAP7_75t_R  g221(.A1(new_n108_), .A2(new_n294_), .B(new_n293_), .Y(G1332));
  AND3x1_ASAP7_75t_R  g222(.A(new_n241_), .B(new_n292_), .C(G10), .Y(new_n296_));
  AO21x1_ASAP7_75t_R  g223(.A1(new_n240_), .A2(new_n292_), .B(new_n291_), .Y(new_n297_));
  AO21x1_ASAP7_75t_R  g224(.A1(new_n75_), .A2(new_n297_), .B(new_n296_), .Y(G1333));
  AND3x1_ASAP7_75t_R  g225(.A(new_n222_), .B(new_n292_), .C(G11), .Y(new_n299_));
  AO21x1_ASAP7_75t_R  g226(.A1(new_n221_), .A2(new_n292_), .B(new_n291_), .Y(new_n300_));
  AO21x1_ASAP7_75t_R  g227(.A1(new_n76_), .A2(new_n300_), .B(new_n299_), .Y(G1334));
  AND3x1_ASAP7_75t_R  g228(.A(new_n253_), .B(new_n292_), .C(G12), .Y(new_n302_));
  AO21x1_ASAP7_75t_R  g229(.A1(new_n252_), .A2(new_n292_), .B(new_n291_), .Y(new_n303_));
  AO21x1_ASAP7_75t_R  g230(.A1(new_n77_), .A2(new_n303_), .B(new_n302_), .Y(G1335));
  OR3x1_ASAP7_75t_R   g231(.A(new_n274_), .B(new_n290_), .C(new_n259_), .Y(new_n305_));
  INVx1_ASAP7_75t_R   g232(.A(new_n305_), .Y(new_n306_));
  AND3x1_ASAP7_75t_R  g233(.A(new_n132_), .B(new_n306_), .C(G13), .Y(new_n307_));
  AO21x1_ASAP7_75t_R  g234(.A1(new_n131_), .A2(new_n306_), .B(new_n305_), .Y(new_n308_));
  AO21x1_ASAP7_75t_R  g235(.A1(new_n78_), .A2(new_n308_), .B(new_n307_), .Y(G1336));
  AND3x1_ASAP7_75t_R  g236(.A(new_n241_), .B(new_n306_), .C(G14), .Y(new_n310_));
  AO21x1_ASAP7_75t_R  g237(.A1(new_n240_), .A2(new_n306_), .B(new_n305_), .Y(new_n311_));
  AO21x1_ASAP7_75t_R  g238(.A1(new_n79_), .A2(new_n311_), .B(new_n310_), .Y(G1337));
  AND3x1_ASAP7_75t_R  g239(.A(new_n222_), .B(new_n306_), .C(G15), .Y(new_n313_));
  AO21x1_ASAP7_75t_R  g240(.A1(new_n221_), .A2(new_n306_), .B(new_n305_), .Y(new_n314_));
  AO21x1_ASAP7_75t_R  g241(.A1(new_n80_), .A2(new_n314_), .B(new_n313_), .Y(G1338));
  AND3x1_ASAP7_75t_R  g242(.A(new_n253_), .B(new_n306_), .C(G16), .Y(new_n316_));
  AO21x1_ASAP7_75t_R  g243(.A1(new_n252_), .A2(new_n306_), .B(new_n305_), .Y(new_n317_));
  AO21x1_ASAP7_75t_R  g244(.A1(new_n81_), .A2(new_n317_), .B(new_n316_), .Y(G1339));
  NOR2x1_ASAP7_75t_R  g245(.A(new_n204_), .B(new_n289_), .Y(new_n319_));
  OR3x1_ASAP7_75t_R   g246(.A(new_n155_), .B(new_n177_), .C(new_n319_), .Y(new_n320_));
  INVx1_ASAP7_75t_R   g247(.A(new_n320_), .Y(new_n321_));
  AO21x1_ASAP7_75t_R  g248(.A1(new_n155_), .A2(new_n176_), .B(new_n178_), .Y(new_n322_));
  AND3x1_ASAP7_75t_R  g249(.A(new_n190_), .B(new_n202_), .C(new_n322_), .Y(new_n323_));
  AOI21x1_ASAP7_75t_R g250(.A1(new_n320_), .A2(new_n323_), .B(new_n321_), .Y(new_n324_));
  OR3x1_ASAP7_75t_R   g251(.A(new_n253_), .B(new_n324_), .C(new_n221_), .Y(new_n325_));
  OR3x1_ASAP7_75t_R   g252(.A(new_n131_), .B(new_n241_), .C(new_n325_), .Y(new_n326_));
  INVx1_ASAP7_75t_R   g253(.A(new_n326_), .Y(new_n327_));
  AND3x1_ASAP7_75t_R  g254(.A(new_n203_), .B(new_n327_), .C(G17), .Y(new_n328_));
  AO21x1_ASAP7_75t_R  g255(.A1(new_n202_), .A2(new_n327_), .B(new_n326_), .Y(new_n329_));
  AO21x1_ASAP7_75t_R  g256(.A1(new_n82_), .A2(new_n329_), .B(new_n328_), .Y(G1340));
  AND3x1_ASAP7_75t_R  g257(.A(new_n191_), .B(new_n327_), .C(G18), .Y(new_n331_));
  AO21x1_ASAP7_75t_R  g258(.A1(new_n190_), .A2(new_n327_), .B(new_n326_), .Y(new_n332_));
  AO21x1_ASAP7_75t_R  g259(.A1(new_n83_), .A2(new_n332_), .B(new_n331_), .Y(G1341));
  AND3x1_ASAP7_75t_R  g260(.A(new_n177_), .B(new_n327_), .C(G19), .Y(new_n334_));
  AO21x1_ASAP7_75t_R  g261(.A1(new_n176_), .A2(new_n327_), .B(new_n326_), .Y(new_n335_));
  AO21x1_ASAP7_75t_R  g262(.A1(new_n84_), .A2(new_n335_), .B(new_n334_), .Y(G1342));
  AND3x1_ASAP7_75t_R  g263(.A(new_n155_), .B(new_n327_), .C(G20), .Y(new_n337_));
  AO21x1_ASAP7_75t_R  g264(.A1(new_n154_), .A2(new_n327_), .B(new_n326_), .Y(new_n338_));
  AO21x1_ASAP7_75t_R  g265(.A1(new_n86_), .A2(new_n338_), .B(new_n337_), .Y(G1343));
  OR2x4_ASAP7_75t_R   g266(.A(new_n252_), .B(new_n324_), .Y(new_n340_));
  OR3x1_ASAP7_75t_R   g267(.A(new_n131_), .B(new_n241_), .C(new_n222_), .Y(new_n341_));
  OR3x1_ASAP7_75t_R   g268(.A(new_n202_), .B(new_n341_), .C(new_n340_), .Y(new_n342_));
  XNOR2x2_ASAP7_75t_R g269(.A(new_n87_), .B(new_n342_), .Y(G1344));
  OR3x1_ASAP7_75t_R   g270(.A(new_n190_), .B(new_n341_), .C(new_n340_), .Y(new_n344_));
  XNOR2x2_ASAP7_75t_R g271(.A(new_n88_), .B(new_n344_), .Y(G1345));
  OR3x1_ASAP7_75t_R   g272(.A(new_n176_), .B(new_n341_), .C(new_n340_), .Y(new_n346_));
  XNOR2x2_ASAP7_75t_R g273(.A(new_n89_), .B(new_n346_), .Y(G1346));
  OR3x1_ASAP7_75t_R   g274(.A(new_n154_), .B(new_n341_), .C(new_n340_), .Y(new_n348_));
  XNOR2x2_ASAP7_75t_R g275(.A(new_n90_), .B(new_n348_), .Y(G1347));
  OR3x1_ASAP7_75t_R   g276(.A(new_n132_), .B(new_n240_), .C(new_n325_), .Y(new_n350_));
  INVx1_ASAP7_75t_R   g277(.A(new_n350_), .Y(new_n351_));
  AND3x1_ASAP7_75t_R  g278(.A(new_n203_), .B(new_n351_), .C(G25), .Y(new_n352_));
  AO21x1_ASAP7_75t_R  g279(.A1(new_n202_), .A2(new_n351_), .B(new_n350_), .Y(new_n353_));
  AO21x1_ASAP7_75t_R  g280(.A1(new_n91_), .A2(new_n353_), .B(new_n352_), .Y(G1348));
  AND3x1_ASAP7_75t_R  g281(.A(new_n191_), .B(new_n351_), .C(G26), .Y(new_n355_));
  AO21x1_ASAP7_75t_R  g282(.A1(new_n190_), .A2(new_n351_), .B(new_n350_), .Y(new_n356_));
  AO21x1_ASAP7_75t_R  g283(.A1(new_n92_), .A2(new_n356_), .B(new_n355_), .Y(G1349));
  AND3x1_ASAP7_75t_R  g284(.A(new_n177_), .B(new_n351_), .C(G27), .Y(new_n358_));
  AO21x1_ASAP7_75t_R  g285(.A1(new_n176_), .A2(new_n351_), .B(new_n350_), .Y(new_n359_));
  AO21x1_ASAP7_75t_R  g286(.A1(new_n93_), .A2(new_n359_), .B(new_n358_), .Y(G1350));
  AND3x1_ASAP7_75t_R  g287(.A(new_n155_), .B(new_n351_), .C(G28), .Y(new_n361_));
  AO21x1_ASAP7_75t_R  g288(.A1(new_n154_), .A2(new_n351_), .B(new_n350_), .Y(new_n362_));
  AO21x1_ASAP7_75t_R  g289(.A1(new_n94_), .A2(new_n362_), .B(new_n361_), .Y(G1351));
  OR3x1_ASAP7_75t_R   g290(.A(new_n132_), .B(new_n240_), .C(new_n222_), .Y(new_n364_));
  OR3x1_ASAP7_75t_R   g291(.A(new_n202_), .B(new_n340_), .C(new_n364_), .Y(new_n365_));
  XNOR2x2_ASAP7_75t_R g292(.A(new_n95_), .B(new_n365_), .Y(G1352));
  OR3x1_ASAP7_75t_R   g293(.A(new_n190_), .B(new_n340_), .C(new_n364_), .Y(new_n367_));
  XNOR2x2_ASAP7_75t_R g294(.A(new_n97_), .B(new_n367_), .Y(G1353));
  OR3x1_ASAP7_75t_R   g295(.A(new_n176_), .B(new_n340_), .C(new_n364_), .Y(new_n369_));
  XNOR2x2_ASAP7_75t_R g296(.A(new_n98_), .B(new_n369_), .Y(G1354));
  OR3x1_ASAP7_75t_R   g297(.A(new_n154_), .B(new_n340_), .C(new_n364_), .Y(new_n371_));
  XNOR2x2_ASAP7_75t_R g298(.A(new_n99_), .B(new_n371_), .Y(G1355));
endmodule


