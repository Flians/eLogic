// Benchmark "/home/flynn/workplace/MIGBalance/results_v2/eqmap_adapter_3in_20261007/c1908/lut_stage_amap/stage" written by ABC on Wed Oct  7 16:25:24 2026

module \/home/flynn/workplace/MIGBalance/results_v2/eqmap_adapter_3in_20261007/c1908/lut_stage_amap/stage  ( 
    G1, G10, G11, G12, G13, G14, G15, G16, G17, G18, G19, G2, G20, G21,
    G22, G23, G24, G25, G26, G27, G28, G29, G3, G30, G31, G32, G33, G4, G5,
    G6, G7, G8, G9,
    G1884, G1885, G1886, G1887, G1888, G1889, G1890, G1891, G1892, G1893,
    G1894, G1895, G1896, G1897, G1898, G1899, G1900, G1901, G1902, G1903,
    G1904, G1905, G1906, G1907, G1908  );
  input  G1, G10, G11, G12, G13, G14, G15, G16, G17, G18, G19, G2, G20,
    G21, G22, G23, G24, G25, G26, G27, G28, G29, G3, G30, G31, G32, G33,
    G4, G5, G6, G7, G8, G9;
  output G1884, G1885, G1886, G1887, G1888, G1889, G1890, G1891, G1892, G1893,
    G1894, G1895, G1896, G1897, G1898, G1899, G1900, G1901, G1902, G1903,
    G1904, G1905, G1906, G1907, G1908;
  wire new_n59_, new_n60_, new_n61_, new_n62_, new_n63_, new_n64_, new_n65_,
    new_n66_, new_n67_, new_n68_, new_n69_, new_n70_, new_n71_, new_n72_,
    new_n73_, new_n74_, new_n75_, new_n76_, new_n77_, new_n78_, new_n79_,
    new_n80_, new_n81_, new_n82_, new_n83_, new_n84_, new_n85_, new_n86_,
    new_n87_, new_n88_, new_n89_, new_n90_, new_n91_, new_n92_, new_n93_,
    new_n94_, new_n95_, new_n96_, new_n97_, new_n98_, new_n99_, new_n100_,
    new_n101_, new_n102_, new_n103_, new_n104_, new_n105_, new_n106_,
    new_n107_, new_n108_, new_n109_, new_n110_, new_n111_, new_n112_,
    new_n113_, new_n114_, new_n115_, new_n116_, new_n117_, new_n118_,
    new_n119_, new_n120_, new_n121_, new_n122_, new_n123_, new_n124_,
    new_n125_, new_n126_, new_n127_, new_n128_, new_n129_, new_n130_,
    new_n131_, new_n132_, new_n133_, new_n134_, new_n135_, new_n136_,
    new_n137_, new_n138_, new_n139_, new_n140_, new_n141_, new_n142_,
    new_n143_, new_n144_, new_n145_, new_n146_, new_n147_, new_n148_,
    new_n149_, new_n150_, new_n151_, new_n152_, new_n153_, new_n154_,
    new_n155_, new_n156_, new_n157_, new_n158_, new_n159_, new_n160_,
    new_n161_, new_n162_, new_n163_, new_n164_, new_n165_, new_n166_,
    new_n167_, new_n168_, new_n169_, new_n170_, new_n171_, new_n172_,
    new_n173_, new_n174_, new_n175_, new_n176_, new_n177_, new_n178_,
    new_n179_, new_n180_, new_n181_, new_n182_, new_n183_, new_n184_,
    new_n185_, new_n186_, new_n187_, new_n188_, new_n189_, new_n190_,
    new_n191_, new_n192_, new_n193_, new_n194_, new_n195_, new_n196_,
    new_n197_, new_n198_, new_n199_, new_n200_, new_n201_, new_n202_,
    new_n203_, new_n204_, new_n205_, new_n206_, new_n207_, new_n208_,
    new_n209_, new_n210_, new_n211_, new_n212_, new_n217_, new_n218_,
    new_n219_, new_n220_, new_n221_, new_n222_, new_n226_, new_n227_,
    new_n232_, new_n233_, new_n234_, new_n236_, new_n237_, new_n238_,
    new_n239_, new_n244_, new_n245_, new_n246_, new_n247_, new_n248_,
    new_n249_, new_n250_, new_n252_, new_n253_, new_n254_, new_n255_,
    new_n256_, new_n258_, new_n259_, new_n260_, new_n261_, new_n263_,
    new_n264_, new_n266_, new_n268_, new_n270_, new_n271_, new_n272_,
    new_n273_, new_n274_, new_n275_, new_n276_, new_n278_, new_n279_,
    new_n280_, new_n281_, new_n282_, new_n283_, new_n284_, new_n285_,
    new_n286_, new_n288_, new_n289_;
  INVx1_ASAP7_75t_R   g000(.A(G1), .Y(new_n59_));
  INVx1_ASAP7_75t_R   g001(.A(G10), .Y(new_n60_));
  INVx1_ASAP7_75t_R   g002(.A(G11), .Y(new_n61_));
  INVx1_ASAP7_75t_R   g003(.A(G12), .Y(new_n62_));
  INVx1_ASAP7_75t_R   g004(.A(G13), .Y(new_n63_));
  INVx1_ASAP7_75t_R   g005(.A(G14), .Y(new_n64_));
  INVx1_ASAP7_75t_R   g006(.A(G15), .Y(new_n65_));
  INVx1_ASAP7_75t_R   g007(.A(G16), .Y(new_n66_));
  INVx1_ASAP7_75t_R   g008(.A(G17), .Y(new_n67_));
  INVx1_ASAP7_75t_R   g009(.A(G18), .Y(new_n68_));
  INVx1_ASAP7_75t_R   g010(.A(G2), .Y(new_n69_));
  INVx1_ASAP7_75t_R   g011(.A(G20), .Y(new_n70_));
  INVx1_ASAP7_75t_R   g012(.A(G21), .Y(new_n71_));
  INVx1_ASAP7_75t_R   g013(.A(G22), .Y(new_n72_));
  INVx1_ASAP7_75t_R   g014(.A(G23), .Y(new_n73_));
  INVx1_ASAP7_75t_R   g015(.A(G24), .Y(new_n74_));
  INVx1_ASAP7_75t_R   g016(.A(G28), .Y(new_n75_));
  INVx1_ASAP7_75t_R   g017(.A(G3), .Y(new_n76_));
  INVx1_ASAP7_75t_R   g018(.A(G31), .Y(new_n77_));
  INVx1_ASAP7_75t_R   g019(.A(G33), .Y(new_n78_));
  INVx1_ASAP7_75t_R   g020(.A(G4), .Y(new_n79_));
  INVx1_ASAP7_75t_R   g021(.A(G5), .Y(new_n80_));
  INVx1_ASAP7_75t_R   g022(.A(G6), .Y(new_n81_));
  INVx1_ASAP7_75t_R   g023(.A(G7), .Y(new_n82_));
  INVx1_ASAP7_75t_R   g024(.A(G8), .Y(new_n83_));
  INVx1_ASAP7_75t_R   g025(.A(G9), .Y(new_n84_));
  AND3x1_ASAP7_75t_R  g026(.A(new_n73_), .B(new_n78_), .C(G19), .Y(new_n85_));
  XNOR2x2_ASAP7_75t_R g027(.A(new_n62_), .B(new_n65_), .Y(new_n86_));
  NAND2x1_ASAP7_75t_R g028(.A(G10), .B(new_n86_), .Y(new_n87_));
  XOR2x2_ASAP7_75t_R  g029(.A(G12), .B(new_n65_), .Y(new_n88_));
  OA21x2_ASAP7_75t_R  g030(.A1(G10), .A2(new_n88_), .B(new_n87_), .Y(new_n89_));
  XNOR2x2_ASAP7_75t_R g031(.A(new_n76_), .B(new_n81_), .Y(new_n90_));
  XOR2x2_ASAP7_75t_R  g032(.A(new_n76_), .B(G6), .Y(new_n91_));
  NOR2x1_ASAP7_75t_R  g033(.A(G8), .B(new_n91_), .Y(new_n92_));
  AO21x1_ASAP7_75t_R  g034(.A1(G8), .A2(new_n90_), .B(new_n92_), .Y(new_n93_));
  XNOR2x2_ASAP7_75t_R g035(.A(new_n89_), .B(new_n93_), .Y(new_n94_));
  XNOR2x2_ASAP7_75t_R g036(.A(new_n89_), .B(new_n93_), .Y(new_n95_));
  NOR2x1_ASAP7_75t_R  g037(.A(new_n85_), .B(new_n95_), .Y(new_n96_));
  AO21x1_ASAP7_75t_R  g038(.A1(new_n85_), .A2(new_n94_), .B(new_n96_), .Y(new_n97_));
  OR3x1_ASAP7_75t_R   g039(.A(G31), .B(new_n97_), .C(new_n75_), .Y(new_n98_));
  NAND2x1_ASAP7_75t_R g040(.A(new_n77_), .B(new_n97_), .Y(new_n99_));
  AO21x1_ASAP7_75t_R  g041(.A1(new_n77_), .A2(new_n99_), .B(G28), .Y(new_n100_));
  XNOR2x2_ASAP7_75t_R g042(.A(new_n69_), .B(new_n80_), .Y(new_n101_));
  XOR2x2_ASAP7_75t_R  g043(.A(new_n69_), .B(G5), .Y(new_n102_));
  NOR2x1_ASAP7_75t_R  g044(.A(G8), .B(new_n102_), .Y(new_n103_));
  AO21x1_ASAP7_75t_R  g045(.A1(G8), .A2(new_n101_), .B(new_n103_), .Y(new_n104_));
  INVx1_ASAP7_75t_R   g046(.A(new_n104_), .Y(new_n105_));
  XNOR2x2_ASAP7_75t_R g047(.A(new_n61_), .B(new_n65_), .Y(new_n106_));
  OR3x1_ASAP7_75t_R   g048(.A(G24), .B(G33), .C(new_n68_), .Y(new_n107_));
  XNOR2x2_ASAP7_75t_R g049(.A(new_n64_), .B(new_n66_), .Y(new_n108_));
  XOR2x2_ASAP7_75t_R  g050(.A(new_n64_), .B(G16), .Y(new_n109_));
  NOR2x1_ASAP7_75t_R  g051(.A(G9), .B(new_n109_), .Y(new_n110_));
  AO21x1_ASAP7_75t_R  g052(.A1(G9), .A2(new_n108_), .B(new_n110_), .Y(new_n111_));
  INVx1_ASAP7_75t_R   g053(.A(new_n111_), .Y(new_n112_));
  XNOR2x2_ASAP7_75t_R g054(.A(new_n107_), .B(new_n111_), .Y(new_n113_));
  XOR2x2_ASAP7_75t_R  g055(.A(new_n107_), .B(new_n112_), .Y(new_n114_));
  NOR2x1_ASAP7_75t_R  g056(.A(new_n106_), .B(new_n114_), .Y(new_n115_));
  AO21x1_ASAP7_75t_R  g057(.A1(new_n106_), .A2(new_n113_), .B(new_n115_), .Y(new_n116_));
  INVx1_ASAP7_75t_R   g058(.A(new_n116_), .Y(new_n117_));
  AND3x1_ASAP7_75t_R  g059(.A(new_n77_), .B(new_n117_), .C(new_n104_), .Y(new_n118_));
  AND3x1_ASAP7_75t_R  g060(.A(new_n77_), .B(new_n116_), .C(new_n105_), .Y(new_n119_));
  NOR2x1_ASAP7_75t_R  g061(.A(new_n118_), .B(new_n119_), .Y(new_n120_));
  XNOR2x2_ASAP7_75t_R g062(.A(G27), .B(new_n120_), .Y(new_n121_));
  AO21x1_ASAP7_75t_R  g063(.A1(new_n98_), .A2(new_n100_), .B(new_n121_), .Y(new_n122_));
  NOR2x1_ASAP7_75t_R  g064(.A(G32), .B(G33), .Y(new_n123_));
  OA21x2_ASAP7_75t_R  g065(.A1(G23), .A2(new_n74_), .B(new_n123_), .Y(new_n124_));
  INVx1_ASAP7_75t_R   g066(.A(new_n124_), .Y(new_n125_));
  NOR2x1_ASAP7_75t_R  g067(.A(G29), .B(G33), .Y(new_n126_));
  INVx1_ASAP7_75t_R   g068(.A(new_n126_), .Y(new_n127_));
  AO21x1_ASAP7_75t_R  g069(.A1(new_n73_), .A2(G24), .B(G31), .Y(new_n128_));
  OR3x1_ASAP7_75t_R   g070(.A(new_n127_), .B(new_n128_), .C(new_n124_), .Y(new_n129_));
  AO21x1_ASAP7_75t_R  g071(.A1(new_n125_), .A2(new_n129_), .B(new_n122_), .Y(new_n130_));
  AO21x1_ASAP7_75t_R  g072(.A1(new_n73_), .A2(G31), .B(G23), .Y(new_n131_));
  NAND2x1_ASAP7_75t_R g073(.A(G19), .B(new_n131_), .Y(new_n132_));
  XNOR2x2_ASAP7_75t_R g074(.A(new_n60_), .B(new_n79_), .Y(new_n133_));
  XOR2x2_ASAP7_75t_R  g075(.A(new_n60_), .B(G4), .Y(new_n134_));
  NOR2x1_ASAP7_75t_R  g076(.A(G7), .B(new_n134_), .Y(new_n135_));
  AO21x1_ASAP7_75t_R  g077(.A1(G7), .A2(new_n133_), .B(new_n135_), .Y(new_n136_));
  INVx1_ASAP7_75t_R   g078(.A(new_n136_), .Y(new_n137_));
  OR3x1_ASAP7_75t_R   g079(.A(G23), .B(G33), .C(new_n70_), .Y(new_n138_));
  XNOR2x2_ASAP7_75t_R g080(.A(new_n111_), .B(new_n138_), .Y(new_n139_));
  XOR2x2_ASAP7_75t_R  g081(.A(new_n112_), .B(new_n138_), .Y(new_n140_));
  NOR2x1_ASAP7_75t_R  g082(.A(G13), .B(new_n140_), .Y(new_n141_));
  AO21x1_ASAP7_75t_R  g083(.A1(G13), .A2(new_n139_), .B(new_n141_), .Y(new_n142_));
  OR3x1_ASAP7_75t_R   g084(.A(G31), .B(new_n142_), .C(new_n137_), .Y(new_n143_));
  NAND2x1_ASAP7_75t_R g085(.A(new_n77_), .B(new_n142_), .Y(new_n144_));
  OA21x2_ASAP7_75t_R  g086(.A1(new_n136_), .A2(new_n144_), .B(new_n143_), .Y(new_n145_));
  XOR2x2_ASAP7_75t_R  g087(.A(new_n132_), .B(new_n145_), .Y(new_n146_));
  INVx1_ASAP7_75t_R   g088(.A(new_n146_), .Y(new_n147_));
  OA21x2_ASAP7_75t_R  g089(.A1(G24), .A2(new_n77_), .B(new_n74_), .Y(new_n148_));
  NOR2x1_ASAP7_75t_R  g090(.A(new_n68_), .B(new_n148_), .Y(new_n149_));
  NOR2x1_ASAP7_75t_R  g091(.A(new_n67_), .B(new_n148_), .Y(new_n150_));
  AND3x1_ASAP7_75t_R  g092(.A(G21), .B(new_n78_), .C(G9), .Y(new_n151_));
  AO21x1_ASAP7_75t_R  g093(.A1(G21), .A2(G33), .B(new_n71_), .Y(new_n152_));
  AOI21x1_ASAP7_75t_R g094(.A1(new_n84_), .A2(new_n152_), .B(new_n151_), .Y(new_n153_));
  XNOR2x2_ASAP7_75t_R g095(.A(new_n65_), .B(G16), .Y(new_n154_));
  NAND2x1_ASAP7_75t_R g096(.A(G10), .B(new_n154_), .Y(new_n155_));
  XOR2x2_ASAP7_75t_R  g097(.A(new_n65_), .B(new_n66_), .Y(new_n156_));
  OA21x2_ASAP7_75t_R  g098(.A1(G10), .A2(new_n156_), .B(new_n155_), .Y(new_n157_));
  XOR2x2_ASAP7_75t_R  g099(.A(new_n153_), .B(new_n157_), .Y(new_n158_));
  INVx1_ASAP7_75t_R   g100(.A(new_n158_), .Y(new_n159_));
  XNOR2x2_ASAP7_75t_R g101(.A(G4), .B(new_n83_), .Y(new_n160_));
  XNOR2x2_ASAP7_75t_R g102(.A(new_n81_), .B(new_n82_), .Y(new_n161_));
  XOR2x2_ASAP7_75t_R  g103(.A(new_n81_), .B(G7), .Y(new_n162_));
  NOR2x1_ASAP7_75t_R  g104(.A(G5), .B(new_n162_), .Y(new_n163_));
  AO21x1_ASAP7_75t_R  g105(.A1(G5), .A2(new_n161_), .B(new_n163_), .Y(new_n164_));
  INVx1_ASAP7_75t_R   g106(.A(new_n164_), .Y(new_n165_));
  XNOR2x2_ASAP7_75t_R g107(.A(new_n59_), .B(new_n69_), .Y(new_n166_));
  XOR2x2_ASAP7_75t_R  g108(.A(G1), .B(new_n69_), .Y(new_n167_));
  NOR2x1_ASAP7_75t_R  g109(.A(G3), .B(new_n167_), .Y(new_n168_));
  AO21x1_ASAP7_75t_R  g110(.A1(G3), .A2(new_n166_), .B(new_n168_), .Y(new_n169_));
  XNOR2x2_ASAP7_75t_R g111(.A(new_n164_), .B(new_n169_), .Y(new_n170_));
  XOR2x2_ASAP7_75t_R  g112(.A(new_n165_), .B(new_n169_), .Y(new_n171_));
  NOR2x1_ASAP7_75t_R  g113(.A(new_n160_), .B(new_n171_), .Y(new_n172_));
  AO21x1_ASAP7_75t_R  g114(.A1(new_n160_), .A2(new_n170_), .B(new_n172_), .Y(new_n173_));
  NOR2x1_ASAP7_75t_R  g115(.A(G31), .B(new_n173_), .Y(new_n174_));
  AND3x1_ASAP7_75t_R  g116(.A(new_n77_), .B(new_n173_), .C(new_n158_), .Y(new_n175_));
  AO21x1_ASAP7_75t_R  g117(.A1(new_n159_), .A2(new_n174_), .B(new_n175_), .Y(new_n176_));
  XNOR2x2_ASAP7_75t_R g118(.A(new_n150_), .B(new_n176_), .Y(new_n177_));
  OR3x1_ASAP7_75t_R   g119(.A(new_n68_), .B(new_n148_), .C(new_n177_), .Y(new_n178_));
  INVx1_ASAP7_75t_R   g120(.A(new_n178_), .Y(new_n179_));
  OR3x1_ASAP7_75t_R   g121(.A(G24), .B(G33), .C(new_n67_), .Y(new_n180_));
  XNOR2x2_ASAP7_75t_R g122(.A(new_n165_), .B(new_n180_), .Y(new_n181_));
  XOR2x2_ASAP7_75t_R  g123(.A(new_n164_), .B(new_n180_), .Y(new_n182_));
  NOR2x1_ASAP7_75t_R  g124(.A(G1), .B(new_n182_), .Y(new_n183_));
  AO21x1_ASAP7_75t_R  g125(.A1(G1), .A2(new_n181_), .B(new_n183_), .Y(new_n184_));
  INVx1_ASAP7_75t_R   g126(.A(new_n184_), .Y(new_n185_));
  XNOR2x2_ASAP7_75t_R g127(.A(new_n62_), .B(G13), .Y(new_n186_));
  NAND2x1_ASAP7_75t_R g128(.A(G11), .B(new_n186_), .Y(new_n187_));
  XOR2x2_ASAP7_75t_R  g129(.A(new_n62_), .B(new_n63_), .Y(new_n188_));
  OA21x2_ASAP7_75t_R  g130(.A1(G11), .A2(new_n188_), .B(new_n187_), .Y(new_n189_));
  XOR2x2_ASAP7_75t_R  g131(.A(new_n157_), .B(new_n189_), .Y(new_n190_));
  INVx1_ASAP7_75t_R   g132(.A(new_n190_), .Y(new_n191_));
  NOR2x1_ASAP7_75t_R  g133(.A(G31), .B(new_n191_), .Y(new_n192_));
  AND3x1_ASAP7_75t_R  g134(.A(new_n77_), .B(new_n191_), .C(new_n185_), .Y(new_n193_));
  AO21x1_ASAP7_75t_R  g135(.A1(new_n184_), .A2(new_n192_), .B(new_n193_), .Y(new_n194_));
  XOR2x2_ASAP7_75t_R  g136(.A(G26), .B(new_n194_), .Y(new_n195_));
  AO21x1_ASAP7_75t_R  g137(.A1(new_n178_), .A2(new_n195_), .B(new_n179_), .Y(new_n196_));
  AO21x1_ASAP7_75t_R  g138(.A1(new_n147_), .A2(new_n196_), .B(new_n146_), .Y(new_n197_));
  NAND2x1_ASAP7_75t_R g139(.A(G20), .B(new_n131_), .Y(new_n198_));
  INVx1_ASAP7_75t_R   g140(.A(new_n198_), .Y(new_n199_));
  XNOR2x2_ASAP7_75t_R g141(.A(new_n64_), .B(new_n79_), .Y(new_n200_));
  AO21x1_ASAP7_75t_R  g142(.A1(G22), .A2(G33), .B(new_n72_), .Y(new_n201_));
  OR3x1_ASAP7_75t_R   g143(.A(new_n72_), .B(G33), .C(new_n200_), .Y(new_n202_));
  INVx1_ASAP7_75t_R   g144(.A(new_n202_), .Y(new_n203_));
  AOI21x1_ASAP7_75t_R g145(.A1(new_n200_), .A2(new_n201_), .B(new_n203_), .Y(new_n204_));
  XNOR2x2_ASAP7_75t_R g146(.A(new_n190_), .B(new_n204_), .Y(new_n205_));
  XOR2x2_ASAP7_75t_R  g147(.A(new_n191_), .B(new_n204_), .Y(new_n206_));
  NOR2x1_ASAP7_75t_R  g148(.A(new_n169_), .B(new_n206_), .Y(new_n207_));
  AO21x1_ASAP7_75t_R  g149(.A1(new_n169_), .A2(new_n205_), .B(new_n207_), .Y(new_n208_));
  AND2x2_ASAP7_75t_R  g150(.A(new_n77_), .B(new_n208_), .Y(new_n209_));
  XOR2x2_ASAP7_75t_R  g151(.A(G25), .B(new_n209_), .Y(new_n210_));
  AND2x2_ASAP7_75t_R  g152(.A(new_n199_), .B(new_n210_), .Y(new_n211_));
  OR3x1_ASAP7_75t_R   g153(.A(new_n197_), .B(new_n211_), .C(new_n130_), .Y(new_n212_));
  XNOR2x2_ASAP7_75t_R g154(.A(new_n59_), .B(new_n212_), .Y(G1884));
  XNOR2x2_ASAP7_75t_R g155(.A(new_n69_), .B(new_n212_), .Y(G1885));
  XNOR2x2_ASAP7_75t_R g156(.A(new_n76_), .B(new_n212_), .Y(G1886));
  XNOR2x2_ASAP7_75t_R g157(.A(new_n79_), .B(new_n212_), .Y(G1887));
  NOR2x1_ASAP7_75t_R  g158(.A(G30), .B(G33), .Y(new_n217_));
  INVx1_ASAP7_75t_R   g159(.A(new_n217_), .Y(new_n218_));
  OR3x1_ASAP7_75t_R   g160(.A(new_n128_), .B(new_n218_), .C(new_n124_), .Y(new_n219_));
  AO21x1_ASAP7_75t_R  g161(.A1(new_n125_), .A2(new_n219_), .B(new_n122_), .Y(new_n220_));
  INVx1_ASAP7_75t_R   g162(.A(new_n220_), .Y(new_n221_));
  OR3x1_ASAP7_75t_R   g163(.A(new_n197_), .B(new_n211_), .C(new_n220_), .Y(new_n222_));
  XNOR2x2_ASAP7_75t_R g164(.A(new_n60_), .B(new_n222_), .Y(G1888));
  XNOR2x2_ASAP7_75t_R g165(.A(new_n65_), .B(new_n222_), .Y(G1889));
  XNOR2x2_ASAP7_75t_R g166(.A(new_n66_), .B(new_n222_), .Y(G1890));
  OR3x1_ASAP7_75t_R   g167(.A(new_n197_), .B(new_n210_), .C(new_n198_), .Y(new_n226_));
  OR2x4_ASAP7_75t_R   g168(.A(new_n130_), .B(new_n226_), .Y(new_n227_));
  XNOR2x2_ASAP7_75t_R g169(.A(new_n80_), .B(new_n227_), .Y(G1891));
  XNOR2x2_ASAP7_75t_R g170(.A(new_n81_), .B(new_n227_), .Y(G1892));
  XNOR2x2_ASAP7_75t_R g171(.A(new_n82_), .B(new_n227_), .Y(G1893));
  XNOR2x2_ASAP7_75t_R g172(.A(new_n83_), .B(new_n227_), .Y(G1894));
  OR3x1_ASAP7_75t_R   g173(.A(new_n220_), .B(new_n226_), .C(new_n84_), .Y(new_n232_));
  INVx1_ASAP7_75t_R   g174(.A(new_n232_), .Y(new_n233_));
  AO21x1_ASAP7_75t_R  g175(.A1(new_n221_), .A2(new_n226_), .B(new_n220_), .Y(new_n234_));
  AO21x1_ASAP7_75t_R  g176(.A1(new_n84_), .A2(new_n234_), .B(new_n233_), .Y(G1895));
  OR3x1_ASAP7_75t_R   g177(.A(new_n68_), .B(new_n148_), .C(new_n211_), .Y(new_n236_));
  XOR2x2_ASAP7_75t_R  g178(.A(new_n150_), .B(new_n176_), .Y(new_n237_));
  OR3x1_ASAP7_75t_R   g179(.A(new_n146_), .B(new_n195_), .C(new_n237_), .Y(new_n238_));
  OR3x1_ASAP7_75t_R   g180(.A(new_n236_), .B(new_n238_), .C(new_n220_), .Y(new_n239_));
  XNOR2x2_ASAP7_75t_R g181(.A(new_n61_), .B(new_n239_), .Y(G1896));
  XNOR2x2_ASAP7_75t_R g182(.A(new_n62_), .B(new_n239_), .Y(G1897));
  XNOR2x2_ASAP7_75t_R g183(.A(new_n63_), .B(new_n239_), .Y(G1898));
  XNOR2x2_ASAP7_75t_R g184(.A(new_n64_), .B(new_n239_), .Y(G1899));
  NAND2x1_ASAP7_75t_R g185(.A(new_n212_), .B(new_n222_), .Y(new_n244_));
  INVx1_ASAP7_75t_R   g186(.A(new_n244_), .Y(new_n245_));
  NOR2x1_ASAP7_75t_R  g187(.A(G32), .B(new_n245_), .Y(new_n246_));
  OA21x2_ASAP7_75t_R  g188(.A1(new_n245_), .A2(new_n246_), .B(new_n78_), .Y(new_n247_));
  INVx1_ASAP7_75t_R   g189(.A(new_n247_), .Y(new_n248_));
  OR3x1_ASAP7_75t_R   g190(.A(new_n149_), .B(new_n199_), .C(new_n122_), .Y(new_n249_));
  OR3x1_ASAP7_75t_R   g191(.A(new_n210_), .B(new_n238_), .C(new_n249_), .Y(new_n250_));
  OAI21x1_ASAP7_75t_R g192(.A1(new_n248_), .A2(new_n250_), .B(new_n247_), .Y(G1900));
  XNOR2x2_ASAP7_75t_R g193(.A(new_n158_), .B(new_n173_), .Y(new_n252_));
  NAND2x1_ASAP7_75t_R g194(.A(new_n150_), .B(new_n244_), .Y(new_n253_));
  OA21x2_ASAP7_75t_R  g195(.A1(G32), .A2(G33), .B(new_n253_), .Y(new_n254_));
  OR3x1_ASAP7_75t_R   g196(.A(new_n123_), .B(new_n253_), .C(new_n252_), .Y(new_n255_));
  INVx1_ASAP7_75t_R   g197(.A(new_n255_), .Y(new_n256_));
  AO21x1_ASAP7_75t_R  g198(.A1(new_n252_), .A2(new_n254_), .B(new_n256_), .Y(G1901));
  NAND2x1_ASAP7_75t_R g199(.A(G25), .B(new_n244_), .Y(new_n258_));
  OA21x2_ASAP7_75t_R  g200(.A1(G32), .A2(G33), .B(new_n258_), .Y(new_n259_));
  OR3x1_ASAP7_75t_R   g201(.A(new_n123_), .B(new_n258_), .C(new_n208_), .Y(new_n260_));
  INVx1_ASAP7_75t_R   g202(.A(new_n260_), .Y(new_n261_));
  AO21x1_ASAP7_75t_R  g203(.A1(new_n208_), .A2(new_n259_), .B(new_n261_), .Y(G1902));
  XNOR2x2_ASAP7_75t_R g204(.A(new_n105_), .B(new_n117_), .Y(new_n263_));
  AO21x1_ASAP7_75t_R  g205(.A1(new_n245_), .A2(new_n263_), .B(new_n244_), .Y(new_n264_));
  OA21x2_ASAP7_75t_R  g206(.A1(G32), .A2(G33), .B(new_n264_), .Y(G1903));
  AO21x1_ASAP7_75t_R  g207(.A1(new_n97_), .A2(new_n245_), .B(new_n244_), .Y(new_n266_));
  OA21x2_ASAP7_75t_R  g208(.A1(G32), .A2(G33), .B(new_n266_), .Y(G1904));
  XNOR2x2_ASAP7_75t_R g209(.A(new_n137_), .B(new_n142_), .Y(new_n268_));
  AOI21x1_ASAP7_75t_R g210(.A1(new_n245_), .A2(new_n268_), .B(new_n123_), .Y(G1905));
  AO21x1_ASAP7_75t_R  g211(.A1(G21), .A2(new_n78_), .B(G33), .Y(new_n270_));
  OR3x1_ASAP7_75t_R   g212(.A(G21), .B(G33), .C(new_n173_), .Y(new_n271_));
  INVx1_ASAP7_75t_R   g213(.A(new_n271_), .Y(new_n272_));
  AO21x1_ASAP7_75t_R  g214(.A1(new_n173_), .A2(new_n270_), .B(new_n272_), .Y(new_n273_));
  OR3x1_ASAP7_75t_R   g215(.A(new_n126_), .B(new_n273_), .C(new_n212_), .Y(new_n274_));
  INVx1_ASAP7_75t_R   g216(.A(new_n274_), .Y(new_n275_));
  AO21x1_ASAP7_75t_R  g217(.A1(new_n127_), .A2(new_n273_), .B(new_n126_), .Y(new_n276_));
  AO21x1_ASAP7_75t_R  g218(.A1(new_n212_), .A2(new_n276_), .B(new_n275_), .Y(G1906));
  OA21x2_ASAP7_75t_R  g219(.A1(new_n72_), .A2(G30), .B(G22), .Y(new_n278_));
  NOR2x1_ASAP7_75t_R  g220(.A(G33), .B(new_n278_), .Y(new_n279_));
  XOR2x2_ASAP7_75t_R  g221(.A(G14), .B(new_n84_), .Y(new_n280_));
  NOR2x1_ASAP7_75t_R  g222(.A(new_n217_), .B(new_n280_), .Y(new_n281_));
  AND3x1_ASAP7_75t_R  g223(.A(new_n218_), .B(new_n280_), .C(new_n190_), .Y(new_n282_));
  AOI21x1_ASAP7_75t_R g224(.A1(new_n191_), .A2(new_n281_), .B(new_n282_), .Y(new_n283_));
  XNOR2x2_ASAP7_75t_R g225(.A(new_n222_), .B(new_n283_), .Y(new_n284_));
  XNOR2x2_ASAP7_75t_R g226(.A(new_n222_), .B(new_n283_), .Y(new_n285_));
  NOR2x1_ASAP7_75t_R  g227(.A(new_n279_), .B(new_n285_), .Y(new_n286_));
  AO21x1_ASAP7_75t_R  g228(.A1(new_n279_), .A2(new_n284_), .B(new_n286_), .Y(G1907));
  XOR2x2_ASAP7_75t_R  g229(.A(new_n185_), .B(new_n191_), .Y(new_n288_));
  OR3x1_ASAP7_75t_R   g230(.A(new_n123_), .B(new_n288_), .C(new_n244_), .Y(new_n289_));
  INVx1_ASAP7_75t_R   g231(.A(new_n289_), .Y(G1908));
endmodule


