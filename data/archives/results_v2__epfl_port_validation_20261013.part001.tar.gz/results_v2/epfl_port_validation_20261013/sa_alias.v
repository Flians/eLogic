module mapped(p0,o0); input p0; output o0; assign o0=~p0; endmodule
