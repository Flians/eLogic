# Fixed helper allocation factor, isolated V8 sqrt pilot

Four actual fresh attempts, all original named-port CEC and cumulative budget checks pass. Both profiles use V7joint method; onlycandidate enables explicit global-capacity helperallocation. Four-input delay51470.40106391907->47047.281381607056, area1983.1000016406178->2250.280001282692. Three-input delay63200.36017036438->60087.260389328, area1869.4799989908934->2155.66998655349. Both candidate delays match same-library recorded emap, no claim of area/Pareto superiority. Not full20/repeated evidence or productionqualification.

All old2048mandatoryhelpers retained; extra helperfunctions fill the same18000initialnodeceiling, not additionalglobal20000capacity. Bothcandidateactualimport18000/postsat19944/cutsperclass16/retained100000/globalrecovery<2s. More generated transient candidates are disclosed separately. No baseline algorithm, library, prep or numerical acceptance threshold changed. Source/helperfunction richness differs from expanded-AND work units; not identicalexecutedwork or memorylimit.

Bigthree remain mandatory-source nodefailures. Adding helpers cannot remove that failure, but this does not rule out a different exact compact representation. V9unselectedINVphase is a separate mechanism experiment, not pooled with V8bestcases.
