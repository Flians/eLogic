// Benchmark "/home/flynn/workplace/MIGBalance/results_v2/fixed_4in_eqmap_20261012/c432/lut_stage_amap/stage" written by ABC on Mon Oct 12 15:05:50 2026

module \/home/flynn/workplace/MIGBalance/results_v2/fixed_4in_eqmap_20261012/c432/lut_stage_amap/stage  ( 
    G1, G10, G11, G12, G13, G14, G15, G16, G17, G18, G19, G2, G20, G21,
    G22, G23, G24, G25, G26, G27, G28, G29, G3, G30, G31, G32, G33, G34,
    G35, G36, G4, G5, G6, G7, G8, G9,
    G426, G427, G428, G429, G430, G431, G432  );
  input  G1, G10, G11, G12, G13, G14, G15, G16, G17, G18, G19, G2, G20,
    G21, G22, G23, G24, G25, G26, G27, G28, G29, G3, G30, G31, G32, G33,
    G34, G35, G36, G4, G5, G6, G7, G8, G9;
  output G426, G427, G428, G429, G430, G431, G432;
  wire new_n44_, new_n45_, new_n46_, new_n47_, new_n48_, new_n49_, new_n50_,
    new_n51_, new_n52_, new_n53_, new_n54_, new_n55_, new_n56_, new_n57_,
    new_n58_, new_n59_, new_n60_, new_n61_, new_n62_, new_n63_, new_n64_,
    new_n65_, new_n66_, new_n67_, new_n68_, new_n69_, new_n70_, new_n71_,
    new_n72_, new_n73_, new_n74_, new_n75_, new_n76_, new_n77_, new_n78_,
    new_n79_, new_n80_, new_n81_, new_n82_, new_n83_, new_n84_, new_n85_,
    new_n87_, new_n88_, new_n89_, new_n90_, new_n91_, new_n92_, new_n93_,
    new_n94_, new_n95_, new_n96_, new_n97_, new_n98_, new_n99_, new_n100_,
    new_n101_, new_n102_, new_n103_, new_n104_, new_n105_, new_n106_,
    new_n107_, new_n108_, new_n109_, new_n110_, new_n111_, new_n112_,
    new_n113_, new_n114_, new_n115_, new_n116_, new_n117_, new_n118_,
    new_n119_, new_n120_, new_n121_, new_n122_, new_n123_, new_n124_,
    new_n125_, new_n126_, new_n127_, new_n128_, new_n129_, new_n130_,
    new_n131_, new_n133_, new_n134_, new_n135_, new_n136_, new_n137_,
    new_n138_, new_n139_, new_n140_, new_n141_, new_n142_, new_n143_,
    new_n144_, new_n145_, new_n146_, new_n147_, new_n148_, new_n149_,
    new_n150_, new_n151_, new_n152_, new_n153_, new_n154_, new_n155_,
    new_n156_, new_n157_, new_n158_, new_n159_, new_n160_, new_n161_,
    new_n162_, new_n163_, new_n164_, new_n165_, new_n166_, new_n167_,
    new_n168_, new_n169_, new_n170_, new_n171_, new_n172_, new_n173_,
    new_n174_, new_n175_, new_n176_, new_n177_, new_n178_, new_n179_,
    new_n180_, new_n181_, new_n182_, new_n183_, new_n184_, new_n185_,
    new_n186_, new_n188_, new_n189_, new_n190_, new_n191_, new_n192_,
    new_n193_, new_n194_, new_n195_, new_n196_, new_n197_, new_n198_,
    new_n199_, new_n200_, new_n201_, new_n202_, new_n203_, new_n204_,
    new_n205_, new_n206_, new_n207_, new_n208_, new_n209_, new_n210_,
    new_n211_, new_n213_, new_n214_, new_n215_, new_n216_, new_n217_,
    new_n218_, new_n219_, new_n220_, new_n221_, new_n222_, new_n223_,
    new_n225_, new_n226_, new_n227_, new_n229_, new_n230_, new_n231_,
    new_n232_, new_n233_, new_n234_, new_n235_;
  INVx1_ASAP7_75t_R    g000(.A(G10), .Y(new_n44_));
  INVx1_ASAP7_75t_R    g001(.A(G13), .Y(new_n45_));
  INVx1_ASAP7_75t_R    g002(.A(G14), .Y(new_n46_));
  INVx1_ASAP7_75t_R    g003(.A(G15), .Y(new_n47_));
  INVx1_ASAP7_75t_R    g004(.A(G17), .Y(new_n48_));
  INVx1_ASAP7_75t_R    g005(.A(G18), .Y(new_n49_));
  INVx1_ASAP7_75t_R    g006(.A(G19), .Y(new_n50_));
  INVx1_ASAP7_75t_R    g007(.A(G2), .Y(new_n51_));
  INVx1_ASAP7_75t_R    g008(.A(G21), .Y(new_n52_));
  INVx1_ASAP7_75t_R    g009(.A(G22), .Y(new_n53_));
  INVx1_ASAP7_75t_R    g010(.A(G23), .Y(new_n54_));
  INVx1_ASAP7_75t_R    g011(.A(G25), .Y(new_n55_));
  INVx1_ASAP7_75t_R    g012(.A(G26), .Y(new_n56_));
  INVx1_ASAP7_75t_R    g013(.A(G29), .Y(new_n57_));
  INVx1_ASAP7_75t_R    g014(.A(G3), .Y(new_n58_));
  INVx1_ASAP7_75t_R    g015(.A(G30), .Y(new_n59_));
  INVx1_ASAP7_75t_R    g016(.A(G33), .Y(new_n60_));
  INVx1_ASAP7_75t_R    g017(.A(G34), .Y(new_n61_));
  INVx1_ASAP7_75t_R    g018(.A(G35), .Y(new_n62_));
  INVx1_ASAP7_75t_R    g019(.A(G5), .Y(new_n63_));
  INVx1_ASAP7_75t_R    g020(.A(G6), .Y(new_n64_));
  INVx1_ASAP7_75t_R    g021(.A(G7), .Y(new_n65_));
  INVx1_ASAP7_75t_R    g022(.A(G9), .Y(new_n66_));
  AO21x1_ASAP7_75t_R   g023(.A1(G10), .A2(G8), .B(new_n44_), .Y(new_n67_));
  AND3x1_ASAP7_75t_R   g024(.A(G32), .B(new_n67_), .C(G34), .Y(new_n68_));
  AO21x1_ASAP7_75t_R   g025(.A1(new_n61_), .A2(new_n67_), .B(new_n68_), .Y(new_n69_));
  INVx1_ASAP7_75t_R    g026(.A(new_n69_), .Y(new_n70_));
  AO21x1_ASAP7_75t_R   g027(.A1(G16), .A2(G18), .B(new_n49_), .Y(new_n71_));
  AND3x1_ASAP7_75t_R   g028(.A(G12), .B(new_n71_), .C(G14), .Y(new_n72_));
  AO21x1_ASAP7_75t_R   g029(.A1(new_n46_), .A2(new_n71_), .B(new_n72_), .Y(new_n73_));
  AND3x1_ASAP7_75t_R   g030(.A(G20), .B(new_n73_), .C(G22), .Y(new_n74_));
  AO21x1_ASAP7_75t_R   g031(.A1(new_n53_), .A2(new_n73_), .B(new_n74_), .Y(new_n75_));
  INVx1_ASAP7_75t_R    g032(.A(new_n75_), .Y(new_n76_));
  AO21x1_ASAP7_75t_R   g033(.A1(G28), .A2(G30), .B(new_n59_), .Y(new_n77_));
  AND3x1_ASAP7_75t_R   g034(.A(G24), .B(new_n77_), .C(G26), .Y(new_n78_));
  AO21x1_ASAP7_75t_R   g035(.A1(new_n56_), .A2(new_n77_), .B(new_n78_), .Y(new_n79_));
  INVx1_ASAP7_75t_R    g036(.A(new_n79_), .Y(new_n80_));
  AO21x1_ASAP7_75t_R   g037(.A1(G4), .A2(G6), .B(new_n64_), .Y(new_n81_));
  AND3x1_ASAP7_75t_R   g038(.A(G1), .B(new_n81_), .C(G2), .Y(new_n82_));
  AO21x1_ASAP7_75t_R   g039(.A1(new_n51_), .A2(new_n81_), .B(new_n82_), .Y(new_n83_));
  OAI21x1_ASAP7_75t_R  g040(.A1(new_n80_), .A2(new_n83_), .B(new_n79_), .Y(new_n84_));
  AO21x1_ASAP7_75t_R   g041(.A1(new_n75_), .A2(new_n84_), .B(new_n76_), .Y(new_n85_));
  AO21x1_ASAP7_75t_R   g042(.A1(new_n69_), .A2(new_n85_), .B(new_n70_), .Y(G426));
  INVx1_ASAP7_75t_R    g043(.A(G426), .Y(new_n87_));
  AND4x2_ASAP7_75t_R   g044(.A(new_n69_), .B(new_n83_), .C(new_n79_), .D(new_n75_), .Y(new_n88_));
  NAND2x1_ASAP7_75t_R  g045(.A(G20), .B(new_n88_), .Y(new_n89_));
  AO21x1_ASAP7_75t_R   g046(.A1(G20), .A2(new_n89_), .B(new_n53_), .Y(new_n90_));
  AO21x1_ASAP7_75t_R   g047(.A1(new_n54_), .A2(new_n90_), .B(G23), .Y(new_n91_));
  AND2x2_ASAP7_75t_R   g048(.A(G16), .B(G426), .Y(new_n92_));
  AND3x1_ASAP7_75t_R   g049(.A(new_n90_), .B(new_n92_), .C(new_n54_), .Y(new_n93_));
  AO21x1_ASAP7_75t_R   g050(.A1(G23), .A2(new_n92_), .B(new_n93_), .Y(new_n94_));
  AO22x1_ASAP7_75t_R   g051(.A1(G19), .A2(new_n91_), .B1(new_n50_), .B2(new_n94_), .Y(new_n95_));
  AO22x1_ASAP7_75t_R   g052(.A1(G18), .A2(new_n95_), .B1(new_n49_), .B2(new_n91_), .Y(new_n96_));
  INVx1_ASAP7_75t_R    g053(.A(new_n96_), .Y(new_n97_));
  NAND2x1_ASAP7_75t_R  g054(.A(G8), .B(new_n88_), .Y(new_n98_));
  AO21x1_ASAP7_75t_R   g055(.A1(G8), .A2(new_n98_), .B(new_n44_), .Y(new_n99_));
  INVx1_ASAP7_75t_R    g056(.A(new_n99_), .Y(new_n100_));
  NAND2x1_ASAP7_75t_R  g057(.A(G24), .B(new_n88_), .Y(new_n101_));
  AO21x1_ASAP7_75t_R   g058(.A1(G24), .A2(new_n101_), .B(new_n56_), .Y(new_n102_));
  INVx1_ASAP7_75t_R    g059(.A(new_n102_), .Y(new_n103_));
  NAND2x1_ASAP7_75t_R  g060(.A(G28), .B(new_n88_), .Y(new_n104_));
  AO21x1_ASAP7_75t_R   g061(.A1(G28), .A2(new_n104_), .B(new_n59_), .Y(new_n105_));
  INVx1_ASAP7_75t_R    g062(.A(new_n105_), .Y(new_n106_));
  AO21x1_ASAP7_75t_R   g063(.A1(G31), .A2(new_n106_), .B(new_n105_), .Y(new_n107_));
  AND3x1_ASAP7_75t_R   g064(.A(G27), .B(new_n107_), .C(new_n103_), .Y(new_n108_));
  AO21x1_ASAP7_75t_R   g065(.A1(new_n102_), .A2(new_n107_), .B(new_n108_), .Y(new_n109_));
  AND3x1_ASAP7_75t_R   g066(.A(G11), .B(new_n109_), .C(new_n100_), .Y(new_n110_));
  AO21x1_ASAP7_75t_R   g067(.A1(new_n99_), .A2(new_n109_), .B(new_n110_), .Y(new_n111_));
  INVx1_ASAP7_75t_R    g068(.A(new_n111_), .Y(new_n112_));
  NAND2x1_ASAP7_75t_R  g069(.A(G12), .B(new_n88_), .Y(new_n113_));
  AO21x1_ASAP7_75t_R   g070(.A1(G12), .A2(new_n113_), .B(new_n46_), .Y(new_n114_));
  AO21x1_ASAP7_75t_R   g071(.A1(new_n47_), .A2(new_n114_), .B(G15), .Y(new_n115_));
  AND2x2_ASAP7_75t_R   g072(.A(G1), .B(G426), .Y(new_n116_));
  AND3x1_ASAP7_75t_R   g073(.A(new_n114_), .B(new_n116_), .C(new_n47_), .Y(new_n117_));
  AO21x1_ASAP7_75t_R   g074(.A1(G15), .A2(new_n116_), .B(new_n117_), .Y(new_n118_));
  AO22x1_ASAP7_75t_R   g075(.A1(G3), .A2(new_n115_), .B1(new_n58_), .B2(new_n118_), .Y(new_n119_));
  AO22x1_ASAP7_75t_R   g076(.A1(G2), .A2(new_n119_), .B1(new_n51_), .B2(new_n115_), .Y(new_n120_));
  INVx1_ASAP7_75t_R    g077(.A(new_n120_), .Y(new_n121_));
  NAND2x1_ASAP7_75t_R  g078(.A(G32), .B(new_n88_), .Y(new_n122_));
  AO21x1_ASAP7_75t_R   g079(.A1(G32), .A2(new_n122_), .B(new_n61_), .Y(new_n123_));
  AO21x1_ASAP7_75t_R   g080(.A1(new_n62_), .A2(new_n123_), .B(G35), .Y(new_n124_));
  AND2x2_ASAP7_75t_R   g081(.A(G4), .B(G426), .Y(new_n125_));
  AND3x1_ASAP7_75t_R   g082(.A(new_n123_), .B(new_n125_), .C(new_n62_), .Y(new_n126_));
  AO21x1_ASAP7_75t_R   g083(.A1(G35), .A2(new_n125_), .B(new_n126_), .Y(new_n127_));
  AO22x1_ASAP7_75t_R   g084(.A1(G7), .A2(new_n124_), .B1(new_n65_), .B2(new_n127_), .Y(new_n128_));
  AO22x1_ASAP7_75t_R   g085(.A1(G6), .A2(new_n128_), .B1(new_n64_), .B2(new_n124_), .Y(new_n129_));
  OAI21x1_ASAP7_75t_R  g086(.A1(new_n121_), .A2(new_n129_), .B(new_n120_), .Y(new_n130_));
  AO21x1_ASAP7_75t_R   g087(.A1(new_n111_), .A2(new_n130_), .B(new_n112_), .Y(new_n131_));
  AO21x1_ASAP7_75t_R   g088(.A1(new_n96_), .A2(new_n131_), .B(new_n97_), .Y(G427));
  INVx1_ASAP7_75t_R    g089(.A(G427), .Y(new_n133_));
  NOR2x1_ASAP7_75t_R   g090(.A(G16), .B(new_n87_), .Y(new_n134_));
  OA21x2_ASAP7_75t_R   g091(.A1(new_n87_), .A2(new_n134_), .B(G18), .Y(new_n135_));
  INVx1_ASAP7_75t_R    g092(.A(new_n135_), .Y(new_n136_));
  AND4x2_ASAP7_75t_R   g093(.A(new_n96_), .B(new_n129_), .C(new_n120_), .D(new_n111_), .Y(new_n137_));
  NAND2x1_ASAP7_75t_R  g094(.A(G23), .B(new_n137_), .Y(new_n138_));
  AO21x1_ASAP7_75t_R   g095(.A1(G23), .A2(new_n138_), .B(new_n90_), .Y(new_n139_));
  AO21x1_ASAP7_75t_R   g096(.A1(new_n55_), .A2(new_n139_), .B(G25), .Y(new_n140_));
  NOR2x1_ASAP7_75t_R   g097(.A(new_n50_), .B(new_n133_), .Y(new_n141_));
  AND3x1_ASAP7_75t_R   g098(.A(new_n139_), .B(new_n141_), .C(new_n55_), .Y(new_n142_));
  AO21x1_ASAP7_75t_R   g099(.A1(G25), .A2(new_n141_), .B(new_n142_), .Y(new_n143_));
  AO22x1_ASAP7_75t_R   g100(.A1(G21), .A2(new_n140_), .B1(new_n52_), .B2(new_n143_), .Y(new_n144_));
  AO22x1_ASAP7_75t_R   g101(.A1(new_n135_), .A2(new_n144_), .B1(new_n136_), .B2(new_n140_), .Y(new_n145_));
  INVx1_ASAP7_75t_R    g102(.A(new_n145_), .Y(new_n146_));
  NOR2x1_ASAP7_75t_R   g103(.A(G1), .B(new_n87_), .Y(new_n147_));
  OA21x2_ASAP7_75t_R   g104(.A1(new_n87_), .A2(new_n147_), .B(G2), .Y(new_n148_));
  INVx1_ASAP7_75t_R    g105(.A(new_n148_), .Y(new_n149_));
  NAND2x1_ASAP7_75t_R  g106(.A(G27), .B(new_n137_), .Y(new_n150_));
  AO21x1_ASAP7_75t_R   g107(.A1(G27), .A2(new_n150_), .B(new_n102_), .Y(new_n151_));
  AO21x1_ASAP7_75t_R   g108(.A1(new_n57_), .A2(new_n151_), .B(G29), .Y(new_n152_));
  NOR2x1_ASAP7_75t_R   g109(.A(new_n58_), .B(new_n133_), .Y(new_n153_));
  AND3x1_ASAP7_75t_R   g110(.A(new_n151_), .B(new_n153_), .C(new_n57_), .Y(new_n154_));
  AO21x1_ASAP7_75t_R   g111(.A1(G29), .A2(new_n153_), .B(new_n154_), .Y(new_n155_));
  AO22x1_ASAP7_75t_R   g112(.A1(G5), .A2(new_n152_), .B1(new_n63_), .B2(new_n155_), .Y(new_n156_));
  AO22x1_ASAP7_75t_R   g113(.A1(new_n148_), .A2(new_n156_), .B1(new_n149_), .B2(new_n152_), .Y(new_n157_));
  INVx1_ASAP7_75t_R    g114(.A(new_n157_), .Y(new_n158_));
  NAND2x1_ASAP7_75t_R  g115(.A(G35), .B(new_n137_), .Y(new_n159_));
  AO21x1_ASAP7_75t_R   g116(.A1(G35), .A2(new_n159_), .B(new_n123_), .Y(new_n160_));
  INVx1_ASAP7_75t_R    g117(.A(new_n160_), .Y(new_n161_));
  OA21x2_ASAP7_75t_R   g118(.A1(G4), .A2(new_n87_), .B(G426), .Y(new_n162_));
  AND4x2_ASAP7_75t_R   g119(.A(new_n96_), .B(new_n111_), .C(new_n129_), .D(new_n120_), .Y(new_n163_));
  AOI21x1_ASAP7_75t_R  g120(.A1(G7), .A2(new_n163_), .B(new_n65_), .Y(new_n164_));
  OR3x1_ASAP7_75t_R    g121(.A(new_n64_), .B(new_n162_), .C(new_n164_), .Y(new_n165_));
  INVx1_ASAP7_75t_R    g122(.A(new_n165_), .Y(new_n166_));
  NAND2x1_ASAP7_75t_R  g123(.A(G31), .B(new_n137_), .Y(new_n167_));
  AO21x1_ASAP7_75t_R   g124(.A1(G31), .A2(new_n167_), .B(new_n105_), .Y(new_n168_));
  INVx1_ASAP7_75t_R    g125(.A(new_n168_), .Y(new_n169_));
  AO21x1_ASAP7_75t_R   g126(.A1(G33), .A2(new_n169_), .B(new_n168_), .Y(new_n170_));
  AND3x1_ASAP7_75t_R   g127(.A(G9), .B(new_n170_), .C(new_n166_), .Y(new_n171_));
  AO21x1_ASAP7_75t_R   g128(.A1(new_n165_), .A2(new_n170_), .B(new_n171_), .Y(new_n172_));
  AND3x1_ASAP7_75t_R   g129(.A(G36), .B(new_n172_), .C(new_n161_), .Y(new_n173_));
  AO21x1_ASAP7_75t_R   g130(.A1(new_n160_), .A2(new_n172_), .B(new_n173_), .Y(new_n174_));
  INVx1_ASAP7_75t_R    g131(.A(new_n174_), .Y(new_n175_));
  NAND2x1_ASAP7_75t_R  g132(.A(G15), .B(new_n137_), .Y(new_n176_));
  AO21x1_ASAP7_75t_R   g133(.A1(G15), .A2(new_n176_), .B(new_n114_), .Y(new_n177_));
  AO21x1_ASAP7_75t_R   g134(.A1(new_n48_), .A2(new_n177_), .B(G17), .Y(new_n178_));
  AND2x2_ASAP7_75t_R   g135(.A(G11), .B(G427), .Y(new_n179_));
  AND3x1_ASAP7_75t_R   g136(.A(new_n177_), .B(new_n179_), .C(new_n48_), .Y(new_n180_));
  AO21x1_ASAP7_75t_R   g137(.A1(G17), .A2(new_n179_), .B(new_n180_), .Y(new_n181_));
  AO22x1_ASAP7_75t_R   g138(.A1(G13), .A2(new_n178_), .B1(new_n45_), .B2(new_n181_), .Y(new_n182_));
  AO22x1_ASAP7_75t_R   g139(.A1(new_n100_), .A2(new_n182_), .B1(new_n99_), .B2(new_n178_), .Y(new_n183_));
  INVx1_ASAP7_75t_R    g140(.A(new_n183_), .Y(new_n184_));
  AO21x1_ASAP7_75t_R   g141(.A1(new_n174_), .A2(new_n184_), .B(new_n175_), .Y(new_n185_));
  AO21x1_ASAP7_75t_R   g142(.A1(new_n157_), .A2(new_n185_), .B(new_n158_), .Y(new_n186_));
  AO21x1_ASAP7_75t_R   g143(.A1(new_n145_), .A2(new_n186_), .B(new_n146_), .Y(G428));
  INVx1_ASAP7_75t_R    g144(.A(G428), .Y(new_n188_));
  AO21x1_ASAP7_75t_R   g145(.A1(new_n58_), .A2(G427), .B(new_n133_), .Y(new_n189_));
  AND3x1_ASAP7_75t_R   g146(.A(new_n188_), .B(new_n189_), .C(G5), .Y(new_n190_));
  AOI21x1_ASAP7_75t_R  g147(.A1(new_n63_), .A2(new_n189_), .B(new_n190_), .Y(new_n191_));
  AO21x1_ASAP7_75t_R   g148(.A1(new_n50_), .A2(G427), .B(new_n133_), .Y(new_n192_));
  INVx1_ASAP7_75t_R    g149(.A(new_n192_), .Y(new_n193_));
  AO21x1_ASAP7_75t_R   g150(.A1(new_n158_), .A2(new_n174_), .B(new_n175_), .Y(new_n194_));
  AO22x1_ASAP7_75t_R   g151(.A1(new_n145_), .A2(new_n194_), .B1(G21), .B2(new_n146_), .Y(new_n195_));
  AND3x1_ASAP7_75t_R   g152(.A(new_n135_), .B(new_n192_), .C(new_n195_), .Y(new_n196_));
  OR3x1_ASAP7_75t_R    g153(.A(new_n136_), .B(new_n193_), .C(new_n196_), .Y(new_n197_));
  INVx1_ASAP7_75t_R    g154(.A(new_n197_), .Y(new_n198_));
  OR3x1_ASAP7_75t_R    g155(.A(new_n146_), .B(new_n184_), .C(new_n175_), .Y(new_n199_));
  OR3x1_ASAP7_75t_R    g156(.A(new_n158_), .B(new_n199_), .C(new_n66_), .Y(new_n200_));
  AO21x1_ASAP7_75t_R   g157(.A1(G9), .A2(new_n200_), .B(new_n165_), .Y(new_n201_));
  INVx1_ASAP7_75t_R    g158(.A(new_n201_), .Y(new_n202_));
  OA21x2_ASAP7_75t_R   g159(.A1(G11), .A2(new_n133_), .B(G427), .Y(new_n203_));
  AND4x2_ASAP7_75t_R   g160(.A(new_n145_), .B(new_n157_), .C(new_n183_), .D(new_n174_), .Y(new_n204_));
  AOI21x1_ASAP7_75t_R  g161(.A1(G13), .A2(new_n204_), .B(new_n45_), .Y(new_n205_));
  OR3x1_ASAP7_75t_R    g162(.A(new_n99_), .B(new_n203_), .C(new_n205_), .Y(new_n206_));
  INVx1_ASAP7_75t_R    g163(.A(new_n206_), .Y(new_n207_));
  OR4x2_ASAP7_75t_R    g164(.A(new_n146_), .B(new_n175_), .C(new_n158_), .D(new_n48_), .Y(new_n208_));
  AOI21x1_ASAP7_75t_R  g165(.A1(G17), .A2(new_n208_), .B(new_n177_), .Y(new_n209_));
  AO21x1_ASAP7_75t_R   g166(.A1(new_n206_), .A2(new_n209_), .B(new_n207_), .Y(new_n210_));
  AO21x1_ASAP7_75t_R   g167(.A1(new_n201_), .A2(new_n210_), .B(new_n202_), .Y(new_n211_));
  AO21x1_ASAP7_75t_R   g168(.A1(new_n197_), .A2(new_n211_), .B(new_n198_), .Y(G430));
  INVx1_ASAP7_75t_R    g169(.A(G430), .Y(new_n213_));
  OA21x2_ASAP7_75t_R   g170(.A1(G25), .A2(new_n188_), .B(G428), .Y(new_n214_));
  NOR2x1_ASAP7_75t_R   g171(.A(new_n139_), .B(new_n214_), .Y(new_n215_));
  INVx1_ASAP7_75t_R    g172(.A(new_n215_), .Y(new_n216_));
  OR3x1_ASAP7_75t_R    g173(.A(new_n158_), .B(new_n175_), .C(new_n57_), .Y(new_n217_));
  AO21x1_ASAP7_75t_R   g174(.A1(G29), .A2(new_n217_), .B(new_n151_), .Y(new_n218_));
  INVx1_ASAP7_75t_R    g175(.A(new_n218_), .Y(new_n219_));
  AO21x1_ASAP7_75t_R   g176(.A1(new_n216_), .A2(new_n219_), .B(new_n215_), .Y(new_n220_));
  AO21x1_ASAP7_75t_R   g177(.A1(new_n213_), .A2(new_n220_), .B(G430), .Y(new_n221_));
  AND3x1_ASAP7_75t_R   g178(.A(new_n160_), .B(new_n168_), .C(new_n221_), .Y(new_n222_));
  OR3x1_ASAP7_75t_R    g179(.A(new_n161_), .B(new_n169_), .C(new_n222_), .Y(new_n223_));
  OA21x2_ASAP7_75t_R   g180(.A1(new_n149_), .A2(new_n191_), .B(new_n223_), .Y(G429));
  OA21x2_ASAP7_75t_R   g181(.A1(new_n216_), .A2(new_n219_), .B(new_n218_), .Y(new_n225_));
  OR3x1_ASAP7_75t_R    g182(.A(new_n198_), .B(new_n225_), .C(new_n209_), .Y(new_n226_));
  OAI21x1_ASAP7_75t_R  g183(.A1(new_n202_), .A2(new_n226_), .B(new_n201_), .Y(new_n227_));
  AO21x1_ASAP7_75t_R   g184(.A1(new_n206_), .A2(new_n227_), .B(new_n207_), .Y(G431));
  OR3x1_ASAP7_75t_R    g185(.A(new_n60_), .B(new_n188_), .C(new_n168_), .Y(new_n229_));
  AO21x1_ASAP7_75t_R   g186(.A1(new_n169_), .A2(new_n229_), .B(new_n219_), .Y(new_n230_));
  AO21x1_ASAP7_75t_R   g187(.A1(new_n218_), .A2(new_n230_), .B(new_n209_), .Y(new_n231_));
  INVx1_ASAP7_75t_R    g188(.A(new_n231_), .Y(new_n232_));
  OR3x1_ASAP7_75t_R    g189(.A(new_n198_), .B(new_n216_), .C(new_n231_), .Y(new_n233_));
  AO21x1_ASAP7_75t_R   g190(.A1(new_n232_), .A2(new_n233_), .B(new_n202_), .Y(new_n234_));
  AOI21x1_ASAP7_75t_R  g191(.A1(new_n201_), .A2(new_n234_), .B(new_n207_), .Y(new_n235_));
  AO21x1_ASAP7_75t_R   g192(.A1(new_n202_), .A2(new_n207_), .B(new_n235_), .Y(G432));
endmodule


