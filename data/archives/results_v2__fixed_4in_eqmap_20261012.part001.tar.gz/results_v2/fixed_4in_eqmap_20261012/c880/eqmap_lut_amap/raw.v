// Benchmark "/home/flynn/workplace/MIGBalance/results_v2/fixed_4in_eqmap_20261012/c880/eqmap_lut_amap/stage" written by ABC on Mon Oct 12 15:06:17 2026

module \/home/flynn/workplace/MIGBalance/results_v2/fixed_4in_eqmap_20261012/c880/eqmap_lut_amap/stage  ( 
    G1, G10, G11, G12, G13, G14, G15, G16, G17, G18, G19, G2, G20, G21,
    G22, G23, G24, G25, G26, G27, G28, G29, G3, G30, G31, G32, G33, G34,
    G35, G36, G37, G38, G39, G4, G40, G41, G42, G43, G44, G45, G46, G47,
    G48, G49, G5, G50, G51, G52, G53, G54, G55, G56, G57, G58, G59, G6,
    G60, G7, G8, G9,
    G855, G856, G857, G858, G859, G860, G861, G862, G863, G864, G865, G866,
    G867, G868, G869, G870, G871, G872, G873, G874, G875, G876, G877, G878,
    G879, G880  );
  input  G1, G10, G11, G12, G13, G14, G15, G16, G17, G18, G19, G2, G20,
    G21, G22, G23, G24, G25, G26, G27, G28, G29, G3, G30, G31, G32, G33,
    G34, G35, G36, G37, G38, G39, G4, G40, G41, G42, G43, G44, G45, G46,
    G47, G48, G49, G5, G50, G51, G52, G53, G54, G55, G56, G57, G58, G59,
    G6, G60, G7, G8, G9;
  output G855, G856, G857, G858, G859, G860, G861, G862, G863, G864, G865,
    G866, G867, G868, G869, G870, G871, G872, G873, G874, G875, G876, G877,
    G878, G879, G880;
  wire new_n87_, new_n88_, new_n89_, new_n90_, new_n91_, new_n92_, new_n93_,
    new_n94_, new_n95_, new_n96_, new_n97_, new_n98_, new_n99_, new_n100_,
    new_n101_, new_n102_, new_n103_, new_n104_, new_n105_, new_n106_,
    new_n107_, new_n108_, new_n109_, new_n110_, new_n111_, new_n112_,
    new_n113_, new_n114_, new_n115_, new_n116_, new_n117_, new_n118_,
    new_n119_, new_n120_, new_n121_, new_n122_, new_n123_, new_n124_,
    new_n125_, new_n126_, new_n127_, new_n128_, new_n129_, new_n130_,
    new_n131_, new_n132_, new_n133_, new_n134_, new_n135_, new_n136_,
    new_n137_, new_n138_, new_n140_, new_n142_, new_n144_, new_n146_,
    new_n147_, new_n149_, new_n154_, new_n156_, new_n158_, new_n160_,
    new_n161_, new_n162_, new_n163_, new_n164_, new_n166_, new_n167_,
    new_n168_, new_n171_, new_n172_, new_n173_, new_n174_, new_n175_,
    new_n176_, new_n177_, new_n178_, new_n179_, new_n180_, new_n181_,
    new_n182_, new_n183_, new_n184_, new_n185_, new_n186_, new_n187_,
    new_n189_, new_n190_, new_n191_, new_n192_, new_n193_, new_n194_,
    new_n195_, new_n196_, new_n197_, new_n198_, new_n199_, new_n200_,
    new_n201_, new_n202_, new_n203_, new_n204_, new_n205_, new_n207_,
    new_n208_, new_n209_, new_n210_, new_n211_, new_n212_, new_n213_,
    new_n214_, new_n215_, new_n216_, new_n217_, new_n218_, new_n219_,
    new_n220_, new_n221_, new_n222_, new_n223_, new_n224_, new_n225_,
    new_n226_, new_n227_, new_n228_, new_n229_, new_n230_, new_n231_,
    new_n232_, new_n233_, new_n234_, new_n235_, new_n236_, new_n237_,
    new_n238_, new_n239_, new_n240_, new_n241_, new_n242_, new_n243_,
    new_n244_, new_n245_, new_n246_, new_n247_, new_n248_, new_n249_,
    new_n250_, new_n251_, new_n252_, new_n254_, new_n255_, new_n256_,
    new_n257_, new_n258_, new_n259_, new_n260_, new_n261_, new_n262_,
    new_n263_, new_n264_, new_n265_, new_n266_, new_n267_, new_n268_,
    new_n269_, new_n270_, new_n271_, new_n272_, new_n273_, new_n274_,
    new_n275_, new_n276_, new_n277_, new_n278_, new_n279_, new_n280_,
    new_n281_, new_n282_, new_n283_, new_n284_, new_n285_, new_n286_,
    new_n287_, new_n288_, new_n289_, new_n290_, new_n291_, new_n292_,
    new_n293_, new_n294_, new_n295_, new_n296_, new_n297_, new_n298_,
    new_n299_, new_n300_, new_n301_, new_n302_, new_n303_, new_n304_,
    new_n305_, new_n306_, new_n307_, new_n309_, new_n310_, new_n311_,
    new_n312_, new_n313_, new_n314_, new_n315_, new_n316_, new_n317_,
    new_n318_, new_n319_, new_n320_, new_n321_, new_n322_, new_n323_,
    new_n324_, new_n325_, new_n326_, new_n327_, new_n329_, new_n330_,
    new_n331_, new_n332_, new_n333_, new_n334_, new_n335_, new_n336_,
    new_n337_, new_n338_, new_n339_, new_n340_, new_n341_, new_n342_,
    new_n344_, new_n345_, new_n346_, new_n347_, new_n348_, new_n349_,
    new_n350_, new_n351_, new_n352_, new_n353_, new_n354_, new_n355_,
    new_n356_, new_n357_, new_n358_, new_n359_, new_n360_, new_n361_,
    new_n362_, new_n363_, new_n364_, new_n365_, new_n366_, new_n367_,
    new_n368_, new_n369_, new_n370_, new_n371_, new_n372_, new_n373_,
    new_n374_, new_n375_, new_n376_, new_n377_, new_n378_, new_n379_,
    new_n380_, new_n381_, new_n382_, new_n383_, new_n384_, new_n385_,
    new_n386_, new_n387_, new_n388_, new_n389_, new_n390_, new_n391_,
    new_n392_, new_n393_, new_n394_, new_n395_, new_n396_, new_n397_,
    new_n398_, new_n399_, new_n400_, new_n401_, new_n402_, new_n403_,
    new_n404_, new_n405_, new_n406_, new_n407_, new_n408_, new_n409_,
    new_n410_, new_n411_, new_n412_, new_n413_, new_n414_, new_n415_,
    new_n416_, new_n417_, new_n418_, new_n419_, new_n421_, new_n422_,
    new_n423_, new_n424_, new_n425_, new_n426_, new_n427_, new_n428_,
    new_n429_, new_n430_, new_n431_, new_n432_, new_n433_, new_n434_,
    new_n436_, new_n437_, new_n438_, new_n439_, new_n440_, new_n441_,
    new_n442_, new_n443_, new_n444_, new_n445_, new_n446_, new_n447_,
    new_n448_, new_n449_, new_n450_, new_n451_, new_n452_, new_n453_,
    new_n454_, new_n455_, new_n456_, new_n457_, new_n458_, new_n459_,
    new_n460_, new_n462_, new_n463_, new_n464_, new_n465_, new_n466_,
    new_n467_, new_n468_, new_n469_, new_n470_, new_n471_, new_n472_,
    new_n473_, new_n474_, new_n475_, new_n476_, new_n477_, new_n478_,
    new_n479_, new_n480_, new_n482_, new_n483_, new_n484_, new_n485_,
    new_n486_, new_n487_, new_n488_, new_n489_, new_n490_, new_n491_,
    new_n492_, new_n493_, new_n494_, new_n495_, new_n496_, new_n497_,
    new_n498_;
  INVx1_ASAP7_75t_R    g000(.A(G1), .Y(new_n87_));
  INVx1_ASAP7_75t_R    g001(.A(G10), .Y(new_n88_));
  INVx1_ASAP7_75t_R    g002(.A(G11), .Y(new_n89_));
  INVx1_ASAP7_75t_R    g003(.A(G12), .Y(new_n90_));
  INVx1_ASAP7_75t_R    g004(.A(G16), .Y(new_n91_));
  INVx1_ASAP7_75t_R    g005(.A(G17), .Y(new_n92_));
  INVx1_ASAP7_75t_R    g006(.A(G18), .Y(new_n93_));
  INVx1_ASAP7_75t_R    g007(.A(G2), .Y(new_n94_));
  INVx1_ASAP7_75t_R    g008(.A(G22), .Y(new_n95_));
  INVx1_ASAP7_75t_R    g009(.A(G23), .Y(new_n96_));
  INVx1_ASAP7_75t_R    g010(.A(G24), .Y(new_n97_));
  INVx1_ASAP7_75t_R    g011(.A(G25), .Y(new_n98_));
  INVx1_ASAP7_75t_R    g012(.A(G26), .Y(new_n99_));
  INVx1_ASAP7_75t_R    g013(.A(G27), .Y(new_n100_));
  INVx1_ASAP7_75t_R    g014(.A(G28), .Y(new_n101_));
  INVx1_ASAP7_75t_R    g015(.A(G29), .Y(new_n102_));
  INVx1_ASAP7_75t_R    g016(.A(G3), .Y(new_n103_));
  INVx1_ASAP7_75t_R    g017(.A(G30), .Y(new_n104_));
  INVx1_ASAP7_75t_R    g018(.A(G31), .Y(new_n105_));
  INVx1_ASAP7_75t_R    g019(.A(G32), .Y(new_n106_));
  INVx1_ASAP7_75t_R    g020(.A(G33), .Y(new_n107_));
  INVx1_ASAP7_75t_R    g021(.A(G34), .Y(new_n108_));
  INVx1_ASAP7_75t_R    g022(.A(G35), .Y(new_n109_));
  INVx1_ASAP7_75t_R    g023(.A(G36), .Y(new_n110_));
  INVx1_ASAP7_75t_R    g024(.A(G37), .Y(new_n111_));
  INVx1_ASAP7_75t_R    g025(.A(G39), .Y(new_n112_));
  INVx1_ASAP7_75t_R    g026(.A(G4), .Y(new_n113_));
  INVx1_ASAP7_75t_R    g027(.A(G40), .Y(new_n114_));
  INVx1_ASAP7_75t_R    g028(.A(G41), .Y(new_n115_));
  INVx1_ASAP7_75t_R    g029(.A(G42), .Y(new_n116_));
  INVx1_ASAP7_75t_R    g030(.A(G43), .Y(new_n117_));
  INVx1_ASAP7_75t_R    g031(.A(G44), .Y(new_n118_));
  INVx1_ASAP7_75t_R    g032(.A(G45), .Y(new_n119_));
  INVx1_ASAP7_75t_R    g033(.A(G46), .Y(new_n120_));
  INVx1_ASAP7_75t_R    g034(.A(G47), .Y(new_n121_));
  INVx1_ASAP7_75t_R    g035(.A(G48), .Y(new_n122_));
  INVx1_ASAP7_75t_R    g036(.A(G49), .Y(new_n123_));
  INVx1_ASAP7_75t_R    g037(.A(G5), .Y(new_n124_));
  INVx1_ASAP7_75t_R    g038(.A(G50), .Y(new_n125_));
  INVx1_ASAP7_75t_R    g039(.A(G51), .Y(new_n126_));
  INVx1_ASAP7_75t_R    g040(.A(G52), .Y(new_n127_));
  INVx1_ASAP7_75t_R    g041(.A(G53), .Y(new_n128_));
  INVx1_ASAP7_75t_R    g042(.A(G54), .Y(new_n129_));
  INVx1_ASAP7_75t_R    g043(.A(G55), .Y(new_n130_));
  INVx1_ASAP7_75t_R    g044(.A(G56), .Y(new_n131_));
  INVx1_ASAP7_75t_R    g045(.A(G57), .Y(new_n132_));
  INVx1_ASAP7_75t_R    g046(.A(G58), .Y(new_n133_));
  INVx1_ASAP7_75t_R    g047(.A(G6), .Y(new_n134_));
  INVx1_ASAP7_75t_R    g048(.A(G7), .Y(new_n135_));
  INVx1_ASAP7_75t_R    g049(.A(G8), .Y(new_n136_));
  INVx1_ASAP7_75t_R    g050(.A(G9), .Y(new_n137_));
  AO21x1_ASAP7_75t_R   g051(.A1(G16), .A2(new_n134_), .B(new_n91_), .Y(new_n138_));
  AO21x1_ASAP7_75t_R   g052(.A1(G8), .A2(new_n138_), .B(new_n136_), .Y(G855));
  AO21x1_ASAP7_75t_R   g053(.A1(G17), .A2(new_n135_), .B(new_n92_), .Y(new_n140_));
  AO21x1_ASAP7_75t_R   g054(.A1(G6), .A2(new_n140_), .B(new_n134_), .Y(G856));
  AO21x1_ASAP7_75t_R   g055(.A1(G6), .A2(new_n135_), .B(new_n134_), .Y(new_n142_));
  AO21x1_ASAP7_75t_R   g056(.A1(G8), .A2(new_n142_), .B(new_n136_), .Y(G857));
  INVx1_ASAP7_75t_R    g057(.A(G857), .Y(new_n144_));
  OAI21x1_ASAP7_75t_R  g058(.A1(new_n93_), .A2(G19), .B(G18), .Y(G858));
  AO21x1_ASAP7_75t_R   g059(.A1(G1), .A2(new_n113_), .B(new_n87_), .Y(new_n146_));
  AO21x1_ASAP7_75t_R   g060(.A1(G2), .A2(new_n146_), .B(new_n94_), .Y(new_n147_));
  AO21x1_ASAP7_75t_R   g061(.A1(G3), .A2(new_n147_), .B(new_n103_), .Y(G859));
  NOR2x1_ASAP7_75t_R   g062(.A(new_n113_), .B(new_n144_), .Y(new_n149_));
  AND4x2_ASAP7_75t_R   g063(.A(G5), .B(new_n149_), .C(G1), .D(G3), .Y(G860));
  AND3x1_ASAP7_75t_R   g064(.A(G16), .B(G17), .C(G11), .Y(G861));
  AND3x1_ASAP7_75t_R   g065(.A(G17), .B(G7), .C(G11), .Y(G862));
  AND3x1_ASAP7_75t_R   g066(.A(G11), .B(G7), .C(G8), .Y(G863));
  NOR2x1_ASAP7_75t_R   g067(.A(G20), .B(G21), .Y(new_n154_));
  AO21x1_ASAP7_75t_R   g068(.A1(G23), .A2(new_n154_), .B(new_n96_), .Y(G864));
  NOR2x1_ASAP7_75t_R   g069(.A(new_n113_), .B(new_n124_), .Y(new_n156_));
  AND4x2_ASAP7_75t_R   g070(.A(G1), .B(new_n156_), .C(G3), .D(new_n144_), .Y(G865));
  AO21x1_ASAP7_75t_R   g071(.A1(G5), .A2(new_n137_), .B(new_n124_), .Y(new_n158_));
  AO21x1_ASAP7_75t_R   g072(.A1(G1), .A2(new_n158_), .B(new_n87_), .Y(G866));
  INVx1_ASAP7_75t_R    g073(.A(G866), .Y(new_n160_));
  AO21x1_ASAP7_75t_R   g074(.A1(G1), .A2(new_n134_), .B(new_n87_), .Y(new_n161_));
  AO21x1_ASAP7_75t_R   g075(.A1(G10), .A2(new_n161_), .B(new_n88_), .Y(new_n162_));
  AO21x1_ASAP7_75t_R   g076(.A1(G2), .A2(new_n162_), .B(new_n94_), .Y(new_n163_));
  AO21x1_ASAP7_75t_R   g077(.A1(G3), .A2(new_n163_), .B(new_n103_), .Y(new_n164_));
  AO21x1_ASAP7_75t_R   g078(.A1(G12), .A2(new_n164_), .B(new_n90_), .Y(G867));
  OR3x1_ASAP7_75t_R    g079(.A(new_n87_), .B(new_n89_), .C(new_n88_), .Y(new_n166_));
  OR4x2_ASAP7_75t_R    g080(.A(new_n94_), .B(new_n166_), .C(new_n103_), .D(new_n90_), .Y(new_n167_));
  INVx1_ASAP7_75t_R    g081(.A(new_n167_), .Y(new_n168_));
  OAI21x1_ASAP7_75t_R  g082(.A1(G15), .A2(new_n167_), .B(new_n168_), .Y(G868));
  AO21x1_ASAP7_75t_R   g083(.A1(G22), .A2(new_n154_), .B(new_n95_), .Y(G869));
  AO22x1_ASAP7_75t_R   g084(.A1(new_n104_), .A2(G31), .B1(G30), .B2(new_n105_), .Y(new_n171_));
  AO22x1_ASAP7_75t_R   g085(.A1(G30), .A2(G31), .B1(new_n104_), .B2(new_n105_), .Y(new_n172_));
  AO22x1_ASAP7_75t_R   g086(.A1(G27), .A2(new_n171_), .B1(new_n100_), .B2(new_n172_), .Y(new_n173_));
  AO22x1_ASAP7_75t_R   g087(.A1(G27), .A2(new_n172_), .B1(new_n100_), .B2(new_n171_), .Y(new_n174_));
  AO22x1_ASAP7_75t_R   g088(.A1(G26), .A2(new_n173_), .B1(new_n99_), .B2(new_n174_), .Y(new_n175_));
  INVx1_ASAP7_75t_R    g089(.A(new_n175_), .Y(new_n176_));
  AO22x1_ASAP7_75t_R   g090(.A1(G33), .A2(new_n176_), .B1(new_n107_), .B2(new_n175_), .Y(new_n177_));
  AO22x1_ASAP7_75t_R   g091(.A1(G33), .A2(new_n175_), .B1(new_n107_), .B2(new_n176_), .Y(new_n178_));
  AO22x1_ASAP7_75t_R   g092(.A1(G29), .A2(new_n177_), .B1(new_n102_), .B2(new_n178_), .Y(new_n179_));
  AO22x1_ASAP7_75t_R   g093(.A1(G29), .A2(new_n178_), .B1(new_n102_), .B2(new_n177_), .Y(new_n180_));
  AO22x1_ASAP7_75t_R   g094(.A1(G28), .A2(new_n179_), .B1(new_n101_), .B2(new_n180_), .Y(new_n181_));
  XNOR2x2_ASAP7_75t_R  g095(.A(G24), .B(new_n181_), .Y(new_n182_));
  XNOR2x2_ASAP7_75t_R  g096(.A(new_n97_), .B(new_n181_), .Y(new_n183_));
  AO22x1_ASAP7_75t_R   g097(.A1(G25), .A2(new_n182_), .B1(new_n98_), .B2(new_n183_), .Y(new_n184_));
  NAND2x1_ASAP7_75t_R  g098(.A(G32), .B(new_n184_), .Y(new_n185_));
  AO22x1_ASAP7_75t_R   g099(.A1(G25), .A2(new_n183_), .B1(new_n98_), .B2(new_n182_), .Y(new_n186_));
  NAND2x1_ASAP7_75t_R  g100(.A(new_n106_), .B(new_n186_), .Y(new_n187_));
  NAND2x1_ASAP7_75t_R  g101(.A(new_n185_), .B(new_n187_), .Y(G870));
  AO22x1_ASAP7_75t_R   g102(.A1(G47), .A2(G48), .B1(new_n121_), .B2(new_n122_), .Y(new_n189_));
  AO22x1_ASAP7_75t_R   g103(.A1(G47), .A2(new_n122_), .B1(new_n121_), .B2(G48), .Y(new_n190_));
  AO22x1_ASAP7_75t_R   g104(.A1(G46), .A2(new_n189_), .B1(new_n120_), .B2(new_n190_), .Y(new_n191_));
  AO22x1_ASAP7_75t_R   g105(.A1(G46), .A2(new_n190_), .B1(new_n120_), .B2(new_n189_), .Y(new_n192_));
  AO22x1_ASAP7_75t_R   g106(.A1(G49), .A2(new_n191_), .B1(new_n123_), .B2(new_n192_), .Y(new_n193_));
  AO22x1_ASAP7_75t_R   g107(.A1(G49), .A2(new_n192_), .B1(new_n123_), .B2(new_n191_), .Y(new_n194_));
  AO22x1_ASAP7_75t_R   g108(.A1(G43), .A2(new_n193_), .B1(new_n117_), .B2(new_n194_), .Y(new_n195_));
  AO22x1_ASAP7_75t_R   g109(.A1(G43), .A2(new_n194_), .B1(new_n117_), .B2(new_n193_), .Y(new_n196_));
  AO22x1_ASAP7_75t_R   g110(.A1(G44), .A2(new_n195_), .B1(new_n118_), .B2(new_n196_), .Y(new_n197_));
  XNOR2x2_ASAP7_75t_R  g111(.A(G41), .B(new_n197_), .Y(new_n198_));
  XNOR2x2_ASAP7_75t_R  g112(.A(new_n115_), .B(new_n197_), .Y(new_n199_));
  AO22x1_ASAP7_75t_R   g113(.A1(G42), .A2(new_n198_), .B1(new_n116_), .B2(new_n199_), .Y(new_n200_));
  AO22x1_ASAP7_75t_R   g114(.A1(G42), .A2(new_n199_), .B1(new_n116_), .B2(new_n198_), .Y(new_n201_));
  AO22x1_ASAP7_75t_R   g115(.A1(G32), .A2(new_n200_), .B1(new_n106_), .B2(new_n201_), .Y(new_n202_));
  NAND2x1_ASAP7_75t_R  g116(.A(G45), .B(new_n202_), .Y(new_n203_));
  AO22x1_ASAP7_75t_R   g117(.A1(G32), .A2(new_n201_), .B1(new_n106_), .B2(new_n200_), .Y(new_n204_));
  NAND2x1_ASAP7_75t_R  g118(.A(new_n119_), .B(new_n204_), .Y(new_n205_));
  NAND2x1_ASAP7_75t_R  g119(.A(new_n203_), .B(new_n205_), .Y(G871));
  OAI21x1_ASAP7_75t_R  g120(.A1(new_n130_), .A2(G59), .B(G55), .Y(new_n207_));
  AND3x1_ASAP7_75t_R   g121(.A(new_n104_), .B(new_n207_), .C(G50), .Y(new_n208_));
  AOI21x1_ASAP7_75t_R  g122(.A1(new_n125_), .A2(new_n207_), .B(new_n208_), .Y(new_n209_));
  OR3x1_ASAP7_75t_R    g123(.A(G60), .B(G866), .C(new_n92_), .Y(new_n210_));
  OR3x1_ASAP7_75t_R    g124(.A(new_n134_), .B(new_n210_), .C(new_n91_), .Y(new_n211_));
  NOR2x1_ASAP7_75t_R   g125(.A(new_n88_), .B(new_n211_), .Y(new_n212_));
  INVx1_ASAP7_75t_R    g126(.A(new_n212_), .Y(new_n213_));
  AO21x1_ASAP7_75t_R   g127(.A1(G11), .A2(new_n114_), .B(new_n89_), .Y(new_n214_));
  AO21x1_ASAP7_75t_R   g128(.A1(G1), .A2(new_n214_), .B(new_n87_), .Y(new_n215_));
  AO22x1_ASAP7_75t_R   g129(.A1(new_n87_), .A2(G866), .B1(new_n160_), .B2(new_n215_), .Y(new_n216_));
  AOI22x1_ASAP7_75t_R  g130(.A1(G4), .A2(new_n216_), .B1(new_n87_), .B2(new_n113_), .Y(new_n217_));
  NOR2x1_ASAP7_75t_R   g131(.A(new_n112_), .B(new_n217_), .Y(new_n218_));
  INVx1_ASAP7_75t_R    g132(.A(new_n218_), .Y(new_n219_));
  AOI22x1_ASAP7_75t_R  g133(.A1(new_n113_), .A2(G8), .B1(G4), .B2(new_n136_), .Y(new_n220_));
  OR3x1_ASAP7_75t_R    g134(.A(new_n114_), .B(new_n220_), .C(new_n89_), .Y(new_n221_));
  AO21x1_ASAP7_75t_R   g135(.A1(G11), .A2(new_n91_), .B(new_n89_), .Y(new_n222_));
  AOI21x1_ASAP7_75t_R  g136(.A1(G8), .A2(new_n222_), .B(new_n136_), .Y(new_n223_));
  OR3x1_ASAP7_75t_R    g137(.A(new_n113_), .B(new_n223_), .C(new_n137_), .Y(new_n224_));
  AND3x1_ASAP7_75t_R   g138(.A(new_n221_), .B(new_n224_), .C(G9), .Y(new_n225_));
  AO21x1_ASAP7_75t_R   g139(.A1(new_n137_), .A2(new_n224_), .B(new_n225_), .Y(new_n226_));
  AO22x1_ASAP7_75t_R   g140(.A1(G5), .A2(new_n226_), .B1(new_n124_), .B2(new_n224_), .Y(new_n227_));
  AO21x1_ASAP7_75t_R   g141(.A1(G1), .A2(new_n227_), .B(new_n87_), .Y(new_n228_));
  AO21x1_ASAP7_75t_R   g142(.A1(G9), .A2(new_n221_), .B(new_n137_), .Y(new_n229_));
  AO21x1_ASAP7_75t_R   g143(.A1(G5), .A2(new_n229_), .B(new_n124_), .Y(new_n230_));
  AO21x1_ASAP7_75t_R   g144(.A1(G1), .A2(new_n230_), .B(new_n87_), .Y(new_n231_));
  AO22x1_ASAP7_75t_R   g145(.A1(G2), .A2(new_n228_), .B1(new_n94_), .B2(new_n231_), .Y(new_n232_));
  INVx1_ASAP7_75t_R    g146(.A(new_n232_), .Y(new_n233_));
  OA21x2_ASAP7_75t_R   g147(.A1(G31), .A2(new_n232_), .B(new_n233_), .Y(new_n234_));
  OR3x1_ASAP7_75t_R    g148(.A(new_n218_), .B(new_n234_), .C(new_n212_), .Y(new_n235_));
  INVx1_ASAP7_75t_R    g149(.A(new_n235_), .Y(new_n236_));
  AND4x2_ASAP7_75t_R   g150(.A(G13), .B(new_n168_), .C(G8), .D(G14), .Y(new_n237_));
  INVx1_ASAP7_75t_R    g151(.A(new_n237_), .Y(new_n238_));
  NOR2x1_ASAP7_75t_R   g152(.A(G52), .B(new_n237_), .Y(new_n239_));
  NOR2x1_ASAP7_75t_R   g153(.A(G53), .B(new_n237_), .Y(new_n240_));
  AO22x1_ASAP7_75t_R   g154(.A1(new_n236_), .A2(new_n239_), .B1(new_n235_), .B2(new_n240_), .Y(new_n241_));
  AO21x1_ASAP7_75t_R   g155(.A1(new_n127_), .A2(new_n235_), .B(new_n236_), .Y(new_n242_));
  AOI22x1_ASAP7_75t_R  g156(.A1(G48), .A2(new_n241_), .B1(new_n122_), .B2(new_n242_), .Y(new_n243_));
  AO21x1_ASAP7_75t_R   g157(.A1(new_n126_), .A2(new_n133_), .B(G58), .Y(new_n244_));
  AO21x1_ASAP7_75t_R   g158(.A1(new_n126_), .A2(G58), .B(new_n133_), .Y(new_n245_));
  AO22x1_ASAP7_75t_R   g159(.A1(G48), .A2(new_n244_), .B1(new_n122_), .B2(new_n245_), .Y(new_n246_));
  NOR2x1_ASAP7_75t_R   g160(.A(G51), .B(G54), .Y(new_n247_));
  AO22x1_ASAP7_75t_R   g161(.A1(G58), .A2(new_n247_), .B1(new_n129_), .B2(new_n133_), .Y(new_n248_));
  AO22x1_ASAP7_75t_R   g162(.A1(new_n129_), .A2(G58), .B1(new_n133_), .B2(new_n247_), .Y(new_n249_));
  AO22x1_ASAP7_75t_R   g163(.A1(G48), .A2(new_n248_), .B1(new_n122_), .B2(new_n249_), .Y(new_n250_));
  AOI22x1_ASAP7_75t_R  g164(.A1(new_n236_), .A2(new_n246_), .B1(new_n235_), .B2(new_n250_), .Y(new_n251_));
  OR3x1_ASAP7_75t_R    g165(.A(new_n209_), .B(new_n243_), .C(new_n251_), .Y(new_n252_));
  INVx1_ASAP7_75t_R    g166(.A(new_n252_), .Y(G872));
  AO21x1_ASAP7_75t_R   g167(.A1(new_n113_), .A2(new_n114_), .B(G40), .Y(new_n254_));
  AO21x1_ASAP7_75t_R   g168(.A1(G9), .A2(new_n254_), .B(new_n137_), .Y(new_n255_));
  AO21x1_ASAP7_75t_R   g169(.A1(G5), .A2(new_n255_), .B(new_n124_), .Y(new_n256_));
  AO21x1_ASAP7_75t_R   g170(.A1(new_n113_), .A2(G9), .B(new_n137_), .Y(new_n257_));
  AO21x1_ASAP7_75t_R   g171(.A1(G5), .A2(new_n257_), .B(new_n124_), .Y(new_n258_));
  AOI22x1_ASAP7_75t_R  g172(.A1(G11), .A2(new_n256_), .B1(new_n89_), .B2(new_n258_), .Y(new_n259_));
  NOR2x1_ASAP7_75t_R   g173(.A(new_n87_), .B(new_n259_), .Y(new_n260_));
  INVx1_ASAP7_75t_R    g174(.A(new_n260_), .Y(new_n261_));
  NOR2x1_ASAP7_75t_R   g175(.A(new_n233_), .B(new_n261_), .Y(new_n262_));
  AO22x1_ASAP7_75t_R   g176(.A1(G28), .A2(new_n262_), .B1(new_n101_), .B2(new_n260_), .Y(new_n263_));
  AO21x1_ASAP7_75t_R   g177(.A1(G28), .A2(new_n232_), .B(new_n101_), .Y(new_n264_));
  AOI22x1_ASAP7_75t_R  g178(.A1(G35), .A2(new_n263_), .B1(new_n109_), .B2(new_n264_), .Y(new_n265_));
  NOR2x1_ASAP7_75t_R   g179(.A(new_n212_), .B(new_n265_), .Y(new_n266_));
  INVx1_ASAP7_75t_R    g180(.A(new_n266_), .Y(new_n267_));
  OR3x1_ASAP7_75t_R    g181(.A(G45), .B(new_n267_), .C(new_n238_), .Y(new_n268_));
  OAI21x1_ASAP7_75t_R  g182(.A1(new_n237_), .A2(new_n267_), .B(new_n268_), .Y(new_n269_));
  AO21x1_ASAP7_75t_R   g183(.A1(new_n128_), .A2(new_n267_), .B(new_n266_), .Y(new_n270_));
  AO21x1_ASAP7_75t_R   g184(.A1(G45), .A2(new_n270_), .B(new_n119_), .Y(new_n271_));
  AO22x1_ASAP7_75t_R   g185(.A1(new_n119_), .A2(new_n237_), .B1(new_n238_), .B2(new_n271_), .Y(new_n272_));
  AO22x1_ASAP7_75t_R   g186(.A1(G54), .A2(new_n269_), .B1(new_n129_), .B2(new_n272_), .Y(new_n273_));
  AO21x1_ASAP7_75t_R   g187(.A1(new_n122_), .A2(G58), .B(G48), .Y(new_n274_));
  NOR2x1_ASAP7_75t_R   g188(.A(new_n105_), .B(new_n232_), .Y(new_n275_));
  AO21x1_ASAP7_75t_R   g189(.A1(new_n133_), .A2(new_n275_), .B(G58), .Y(new_n276_));
  AND3x1_ASAP7_75t_R   g190(.A(G58), .B(new_n275_), .C(new_n122_), .Y(new_n277_));
  AO21x1_ASAP7_75t_R   g191(.A1(G48), .A2(new_n276_), .B(new_n277_), .Y(new_n278_));
  AO22x1_ASAP7_75t_R   g192(.A1(new_n218_), .A2(new_n274_), .B1(new_n219_), .B2(new_n278_), .Y(new_n279_));
  AO22x1_ASAP7_75t_R   g193(.A1(new_n212_), .A2(new_n274_), .B1(new_n213_), .B2(new_n279_), .Y(new_n280_));
  INVx1_ASAP7_75t_R    g194(.A(new_n280_), .Y(new_n281_));
  AO22x1_ASAP7_75t_R   g195(.A1(G30), .A2(new_n262_), .B1(new_n104_), .B2(new_n260_), .Y(new_n282_));
  AO21x1_ASAP7_75t_R   g196(.A1(G30), .A2(new_n232_), .B(new_n104_), .Y(new_n283_));
  AOI22x1_ASAP7_75t_R  g197(.A1(G37), .A2(new_n282_), .B1(new_n111_), .B2(new_n283_), .Y(new_n284_));
  NOR2x1_ASAP7_75t_R   g198(.A(new_n212_), .B(new_n284_), .Y(new_n285_));
  INVx1_ASAP7_75t_R    g199(.A(new_n285_), .Y(new_n286_));
  AO22x1_ASAP7_75t_R   g200(.A1(G29), .A2(new_n262_), .B1(new_n102_), .B2(new_n260_), .Y(new_n287_));
  AO21x1_ASAP7_75t_R   g201(.A1(G29), .A2(new_n232_), .B(new_n102_), .Y(new_n288_));
  AOI22x1_ASAP7_75t_R  g202(.A1(G36), .A2(new_n287_), .B1(new_n110_), .B2(new_n288_), .Y(new_n289_));
  NOR2x1_ASAP7_75t_R   g203(.A(new_n212_), .B(new_n289_), .Y(new_n290_));
  INVx1_ASAP7_75t_R    g204(.A(new_n290_), .Y(new_n291_));
  NOR2x1_ASAP7_75t_R   g205(.A(new_n286_), .B(new_n291_), .Y(new_n292_));
  AND3x1_ASAP7_75t_R   g206(.A(new_n281_), .B(new_n292_), .C(G47), .Y(new_n293_));
  AO22x1_ASAP7_75t_R   g207(.A1(new_n280_), .A2(new_n292_), .B1(new_n281_), .B2(new_n290_), .Y(new_n294_));
  AO21x1_ASAP7_75t_R   g208(.A1(new_n121_), .A2(new_n294_), .B(new_n293_), .Y(new_n295_));
  AO21x1_ASAP7_75t_R   g209(.A1(new_n286_), .A2(new_n290_), .B(new_n285_), .Y(new_n296_));
  AO22x1_ASAP7_75t_R   g210(.A1(new_n280_), .A2(new_n290_), .B1(new_n281_), .B2(new_n296_), .Y(new_n297_));
  AO21x1_ASAP7_75t_R   g211(.A1(new_n280_), .A2(new_n296_), .B(new_n281_), .Y(new_n298_));
  AO22x1_ASAP7_75t_R   g212(.A1(G47), .A2(new_n297_), .B1(new_n121_), .B2(new_n298_), .Y(new_n299_));
  AO22x1_ASAP7_75t_R   g213(.A1(G46), .A2(new_n295_), .B1(new_n120_), .B2(new_n299_), .Y(new_n300_));
  INVx1_ASAP7_75t_R    g214(.A(new_n300_), .Y(new_n301_));
  AND3x1_ASAP7_75t_R   g215(.A(new_n126_), .B(new_n127_), .C(new_n300_), .Y(new_n302_));
  AO21x1_ASAP7_75t_R   g216(.A1(new_n127_), .A2(new_n301_), .B(new_n302_), .Y(new_n303_));
  AO21x1_ASAP7_75t_R   g217(.A1(new_n126_), .A2(new_n301_), .B(new_n300_), .Y(new_n304_));
  AO22x1_ASAP7_75t_R   g218(.A1(new_n266_), .A2(new_n303_), .B1(new_n267_), .B2(new_n304_), .Y(new_n305_));
  AO22x1_ASAP7_75t_R   g219(.A1(new_n266_), .A2(new_n304_), .B1(new_n267_), .B2(new_n303_), .Y(new_n306_));
  AO22x1_ASAP7_75t_R   g220(.A1(G45), .A2(new_n305_), .B1(new_n119_), .B2(new_n306_), .Y(new_n307_));
  OA211x2_ASAP7_75t_R  g221(.A1(new_n100_), .A2(new_n125_), .B(new_n273_), .C(new_n307_), .Y(G873));
  NOR2x1_ASAP7_75t_R   g222(.A(G53), .B(G54), .Y(new_n309_));
  AND3x1_ASAP7_75t_R   g223(.A(new_n238_), .B(new_n309_), .C(new_n291_), .Y(new_n310_));
  AO21x1_ASAP7_75t_R   g224(.A1(new_n239_), .A2(new_n290_), .B(new_n310_), .Y(new_n311_));
  NOR2x1_ASAP7_75t_R   g225(.A(G52), .B(G54), .Y(new_n312_));
  AO21x1_ASAP7_75t_R   g226(.A1(new_n291_), .A2(new_n312_), .B(new_n290_), .Y(new_n313_));
  AO22x1_ASAP7_75t_R   g227(.A1(G46), .A2(new_n311_), .B1(new_n120_), .B2(new_n313_), .Y(new_n314_));
  AND3x1_ASAP7_75t_R   g228(.A(new_n281_), .B(new_n285_), .C(G47), .Y(new_n315_));
  AO21x1_ASAP7_75t_R   g229(.A1(new_n280_), .A2(new_n285_), .B(new_n281_), .Y(new_n316_));
  AO21x1_ASAP7_75t_R   g230(.A1(new_n121_), .A2(new_n316_), .B(new_n315_), .Y(new_n317_));
  AO21x1_ASAP7_75t_R   g231(.A1(new_n281_), .A2(new_n286_), .B(new_n280_), .Y(new_n318_));
  AND3x1_ASAP7_75t_R   g232(.A(new_n280_), .B(new_n286_), .C(new_n121_), .Y(new_n319_));
  AO21x1_ASAP7_75t_R   g233(.A1(G47), .A2(new_n318_), .B(new_n319_), .Y(new_n320_));
  AO22x1_ASAP7_75t_R   g234(.A1(new_n290_), .A2(new_n317_), .B1(new_n291_), .B2(new_n320_), .Y(new_n321_));
  AO22x1_ASAP7_75t_R   g235(.A1(new_n290_), .A2(new_n320_), .B1(new_n291_), .B2(new_n317_), .Y(new_n322_));
  AOI22x1_ASAP7_75t_R  g236(.A1(G46), .A2(new_n321_), .B1(new_n120_), .B2(new_n322_), .Y(new_n323_));
  AND3x1_ASAP7_75t_R   g237(.A(new_n101_), .B(new_n131_), .C(G55), .Y(new_n324_));
  AO21x1_ASAP7_75t_R   g238(.A1(new_n101_), .A2(new_n130_), .B(new_n324_), .Y(new_n325_));
  AO21x1_ASAP7_75t_R   g239(.A1(G55), .A2(new_n131_), .B(new_n130_), .Y(new_n326_));
  AO22x1_ASAP7_75t_R   g240(.A1(G50), .A2(new_n325_), .B1(new_n125_), .B2(new_n326_), .Y(new_n327_));
  OA211x2_ASAP7_75t_R  g241(.A1(new_n126_), .A2(new_n323_), .B(new_n327_), .C(new_n314_), .Y(G874));
  AO21x1_ASAP7_75t_R   g242(.A1(new_n130_), .A2(G57), .B(new_n132_), .Y(new_n329_));
  AND3x1_ASAP7_75t_R   g243(.A(new_n102_), .B(new_n329_), .C(G50), .Y(new_n330_));
  AO21x1_ASAP7_75t_R   g244(.A1(new_n125_), .A2(new_n329_), .B(new_n330_), .Y(new_n331_));
  AND3x1_ASAP7_75t_R   g245(.A(new_n238_), .B(new_n331_), .C(G47), .Y(new_n332_));
  AOI21x1_ASAP7_75t_R  g246(.A1(new_n121_), .A2(new_n331_), .B(new_n332_), .Y(new_n333_));
  AO22x1_ASAP7_75t_R   g247(.A1(new_n127_), .A2(new_n285_), .B1(new_n286_), .B2(new_n309_), .Y(new_n334_));
  AO21x1_ASAP7_75t_R   g248(.A1(new_n286_), .A2(new_n312_), .B(new_n285_), .Y(new_n335_));
  AOI22x1_ASAP7_75t_R  g249(.A1(G47), .A2(new_n334_), .B1(new_n121_), .B2(new_n335_), .Y(new_n336_));
  AO21x1_ASAP7_75t_R   g250(.A1(new_n126_), .A2(new_n286_), .B(new_n285_), .Y(new_n337_));
  AO21x1_ASAP7_75t_R   g251(.A1(new_n126_), .A2(new_n285_), .B(new_n286_), .Y(new_n338_));
  AO22x1_ASAP7_75t_R   g252(.A1(new_n280_), .A2(new_n337_), .B1(new_n281_), .B2(new_n338_), .Y(new_n339_));
  AO22x1_ASAP7_75t_R   g253(.A1(new_n280_), .A2(new_n338_), .B1(new_n281_), .B2(new_n337_), .Y(new_n340_));
  AOI22x1_ASAP7_75t_R  g254(.A1(G47), .A2(new_n339_), .B1(new_n121_), .B2(new_n340_), .Y(new_n341_));
  OR3x1_ASAP7_75t_R    g255(.A(new_n333_), .B(new_n336_), .C(new_n341_), .Y(new_n342_));
  INVx1_ASAP7_75t_R    g256(.A(new_n342_), .Y(G875));
  NOR2x1_ASAP7_75t_R   g257(.A(new_n113_), .B(new_n211_), .Y(new_n344_));
  INVx1_ASAP7_75t_R    g258(.A(new_n344_), .Y(new_n345_));
  AND4x2_ASAP7_75t_R   g259(.A(new_n114_), .B(G9), .C(G5), .D(G11), .Y(new_n346_));
  AND3x1_ASAP7_75t_R   g260(.A(G5), .B(G9), .C(new_n89_), .Y(new_n347_));
  OA211x2_ASAP7_75t_R  g261(.A1(new_n346_), .A2(new_n347_), .B(G1), .C(G10), .Y(new_n348_));
  INVx1_ASAP7_75t_R    g262(.A(new_n348_), .Y(new_n349_));
  AO21x1_ASAP7_75t_R   g263(.A1(new_n110_), .A2(new_n348_), .B(new_n349_), .Y(new_n350_));
  AND3x1_ASAP7_75t_R   g264(.A(new_n108_), .B(new_n350_), .C(G9), .Y(new_n351_));
  AO21x1_ASAP7_75t_R   g265(.A1(new_n137_), .A2(new_n350_), .B(new_n351_), .Y(new_n352_));
  AND3x1_ASAP7_75t_R   g266(.A(new_n232_), .B(new_n352_), .C(G25), .Y(new_n353_));
  AO21x1_ASAP7_75t_R   g267(.A1(new_n98_), .A2(new_n352_), .B(new_n353_), .Y(new_n354_));
  INVx1_ASAP7_75t_R    g268(.A(new_n354_), .Y(new_n355_));
  AO21x1_ASAP7_75t_R   g269(.A1(new_n109_), .A2(new_n348_), .B(new_n349_), .Y(new_n356_));
  AND3x1_ASAP7_75t_R   g270(.A(new_n108_), .B(new_n356_), .C(G2), .Y(new_n357_));
  AOI21x1_ASAP7_75t_R  g271(.A1(new_n94_), .A2(new_n356_), .B(new_n357_), .Y(new_n358_));
  NOR2x1_ASAP7_75t_R   g272(.A(new_n344_), .B(new_n358_), .Y(new_n359_));
  INVx1_ASAP7_75t_R    g273(.A(new_n359_), .Y(new_n360_));
  AO21x1_ASAP7_75t_R   g274(.A1(new_n97_), .A2(new_n233_), .B(new_n232_), .Y(new_n361_));
  NAND2x1_ASAP7_75t_R  g275(.A(new_n359_), .B(new_n361_), .Y(new_n362_));
  INVx1_ASAP7_75t_R    g276(.A(new_n362_), .Y(new_n363_));
  AO21x1_ASAP7_75t_R   g277(.A1(new_n285_), .A2(new_n291_), .B(new_n286_), .Y(new_n364_));
  AO21x1_ASAP7_75t_R   g278(.A1(new_n281_), .A2(new_n364_), .B(new_n280_), .Y(new_n365_));
  AO22x1_ASAP7_75t_R   g279(.A1(new_n280_), .A2(new_n364_), .B1(new_n281_), .B2(new_n291_), .Y(new_n366_));
  AO22x1_ASAP7_75t_R   g280(.A1(G47), .A2(new_n365_), .B1(new_n121_), .B2(new_n366_), .Y(new_n367_));
  NOR2x1_ASAP7_75t_R   g281(.A(new_n285_), .B(new_n290_), .Y(new_n368_));
  AO22x1_ASAP7_75t_R   g282(.A1(new_n280_), .A2(new_n291_), .B1(new_n281_), .B2(new_n368_), .Y(new_n369_));
  AND3x1_ASAP7_75t_R   g283(.A(new_n280_), .B(new_n368_), .C(new_n121_), .Y(new_n370_));
  AO21x1_ASAP7_75t_R   g284(.A1(G47), .A2(new_n369_), .B(new_n370_), .Y(new_n371_));
  AOI22x1_ASAP7_75t_R  g285(.A1(G46), .A2(new_n367_), .B1(new_n120_), .B2(new_n371_), .Y(new_n372_));
  AO21x1_ASAP7_75t_R   g286(.A1(new_n119_), .A2(new_n266_), .B(new_n372_), .Y(new_n373_));
  INVx1_ASAP7_75t_R    g287(.A(new_n373_), .Y(new_n374_));
  OAI21x1_ASAP7_75t_R  g288(.A1(new_n108_), .A2(G38), .B(G34), .Y(new_n375_));
  AND3x1_ASAP7_75t_R   g289(.A(new_n112_), .B(new_n375_), .C(new_n348_), .Y(new_n376_));
  AO21x1_ASAP7_75t_R   g290(.A1(new_n349_), .A2(new_n375_), .B(new_n376_), .Y(new_n377_));
  AND3x1_ASAP7_75t_R   g291(.A(new_n232_), .B(new_n377_), .C(G27), .Y(new_n378_));
  AOI21x1_ASAP7_75t_R  g292(.A1(new_n100_), .A2(new_n377_), .B(new_n378_), .Y(new_n379_));
  NOR2x1_ASAP7_75t_R   g293(.A(new_n344_), .B(new_n379_), .Y(new_n380_));
  INVx1_ASAP7_75t_R    g294(.A(new_n380_), .Y(new_n381_));
  AO21x1_ASAP7_75t_R   g295(.A1(G37), .A2(new_n349_), .B(new_n111_), .Y(new_n382_));
  AND3x1_ASAP7_75t_R   g296(.A(new_n108_), .B(new_n382_), .C(G4), .Y(new_n383_));
  AO21x1_ASAP7_75t_R   g297(.A1(new_n113_), .A2(new_n382_), .B(new_n383_), .Y(new_n384_));
  AND3x1_ASAP7_75t_R   g298(.A(new_n232_), .B(new_n384_), .C(G26), .Y(new_n385_));
  AO21x1_ASAP7_75t_R   g299(.A1(new_n99_), .A2(new_n384_), .B(new_n385_), .Y(new_n386_));
  INVx1_ASAP7_75t_R    g300(.A(new_n386_), .Y(new_n387_));
  NOR2x1_ASAP7_75t_R   g301(.A(new_n344_), .B(new_n387_), .Y(new_n388_));
  INVx1_ASAP7_75t_R    g302(.A(new_n388_), .Y(new_n389_));
  AO21x1_ASAP7_75t_R   g303(.A1(new_n380_), .A2(new_n389_), .B(new_n381_), .Y(new_n390_));
  AO21x1_ASAP7_75t_R   g304(.A1(new_n118_), .A2(new_n390_), .B(G44), .Y(new_n391_));
  OR3x1_ASAP7_75t_R    g305(.A(new_n380_), .B(new_n388_), .C(G44), .Y(new_n392_));
  OAI21x1_ASAP7_75t_R  g306(.A1(new_n118_), .A2(new_n388_), .B(new_n392_), .Y(new_n393_));
  AO22x1_ASAP7_75t_R   g307(.A1(G43), .A2(new_n391_), .B1(new_n117_), .B2(new_n393_), .Y(new_n394_));
  NOR2x1_ASAP7_75t_R   g308(.A(new_n109_), .B(new_n260_), .Y(new_n395_));
  AO21x1_ASAP7_75t_R   g309(.A1(new_n213_), .A2(new_n395_), .B(new_n212_), .Y(new_n396_));
  AO21x1_ASAP7_75t_R   g310(.A1(new_n101_), .A2(new_n261_), .B(G28), .Y(new_n397_));
  AO22x1_ASAP7_75t_R   g311(.A1(G35), .A2(new_n397_), .B1(G28), .B2(new_n109_), .Y(new_n398_));
  AO21x1_ASAP7_75t_R   g312(.A1(new_n213_), .A2(new_n398_), .B(new_n212_), .Y(new_n399_));
  AOI22x1_ASAP7_75t_R  g313(.A1(new_n232_), .A2(new_n396_), .B1(new_n233_), .B2(new_n399_), .Y(new_n400_));
  NOR2x1_ASAP7_75t_R   g314(.A(new_n119_), .B(new_n400_), .Y(new_n401_));
  INVx1_ASAP7_75t_R    g315(.A(new_n401_), .Y(new_n402_));
  AO22x1_ASAP7_75t_R   g316(.A1(G44), .A2(new_n390_), .B1(new_n118_), .B2(new_n389_), .Y(new_n403_));
  AND4x2_ASAP7_75t_R   g317(.A(new_n381_), .B(new_n389_), .C(G44), .D(new_n117_), .Y(new_n404_));
  AO21x1_ASAP7_75t_R   g318(.A1(G43), .A2(new_n403_), .B(new_n404_), .Y(new_n405_));
  AO22x1_ASAP7_75t_R   g319(.A1(new_n394_), .A2(new_n401_), .B1(new_n402_), .B2(new_n405_), .Y(new_n406_));
  AO22x1_ASAP7_75t_R   g320(.A1(new_n374_), .A2(new_n394_), .B1(new_n373_), .B2(new_n406_), .Y(new_n407_));
  INVx1_ASAP7_75t_R    g321(.A(new_n407_), .Y(new_n408_));
  NOR2x1_ASAP7_75t_R   g322(.A(new_n362_), .B(new_n407_), .Y(new_n409_));
  AND4x2_ASAP7_75t_R   g323(.A(new_n354_), .B(new_n409_), .C(new_n345_), .D(G41), .Y(new_n410_));
  AO21x1_ASAP7_75t_R   g324(.A1(new_n362_), .A2(new_n408_), .B(new_n363_), .Y(new_n411_));
  AO22x1_ASAP7_75t_R   g325(.A1(new_n354_), .A2(new_n411_), .B1(new_n355_), .B2(new_n363_), .Y(new_n412_));
  AO22x1_ASAP7_75t_R   g326(.A1(new_n344_), .A2(new_n363_), .B1(new_n345_), .B2(new_n412_), .Y(new_n413_));
  AO21x1_ASAP7_75t_R   g327(.A1(new_n115_), .A2(new_n413_), .B(new_n410_), .Y(new_n414_));
  AO22x1_ASAP7_75t_R   g328(.A1(new_n354_), .A2(new_n363_), .B1(new_n355_), .B2(new_n409_), .Y(new_n415_));
  AO22x1_ASAP7_75t_R   g329(.A1(new_n344_), .A2(new_n409_), .B1(new_n345_), .B2(new_n415_), .Y(new_n416_));
  AO21x1_ASAP7_75t_R   g330(.A1(new_n355_), .A2(new_n411_), .B(new_n354_), .Y(new_n417_));
  AO22x1_ASAP7_75t_R   g331(.A1(new_n344_), .A2(new_n411_), .B1(new_n345_), .B2(new_n417_), .Y(new_n418_));
  AO22x1_ASAP7_75t_R   g332(.A1(G41), .A2(new_n416_), .B1(new_n115_), .B2(new_n418_), .Y(new_n419_));
  AO22x1_ASAP7_75t_R   g333(.A1(G42), .A2(new_n414_), .B1(new_n116_), .B2(new_n419_), .Y(G876));
  AO22x1_ASAP7_75t_R   g334(.A1(new_n239_), .A2(new_n380_), .B1(new_n240_), .B2(new_n381_), .Y(new_n421_));
  AO21x1_ASAP7_75t_R   g335(.A1(new_n127_), .A2(new_n381_), .B(new_n380_), .Y(new_n422_));
  AO22x1_ASAP7_75t_R   g336(.A1(G44), .A2(new_n421_), .B1(new_n118_), .B2(new_n422_), .Y(new_n423_));
  NOR2x1_ASAP7_75t_R   g337(.A(new_n374_), .B(new_n401_), .Y(new_n424_));
  INVx1_ASAP7_75t_R    g338(.A(new_n424_), .Y(new_n425_));
  AO21x1_ASAP7_75t_R   g339(.A1(new_n126_), .A2(new_n424_), .B(new_n425_), .Y(new_n426_));
  AND2x2_ASAP7_75t_R   g340(.A(G44), .B(new_n426_), .Y(new_n427_));
  AO21x1_ASAP7_75t_R   g341(.A1(new_n126_), .A2(new_n425_), .B(new_n424_), .Y(new_n428_));
  AND2x2_ASAP7_75t_R   g342(.A(new_n118_), .B(new_n428_), .Y(new_n429_));
  OA21x2_ASAP7_75t_R   g343(.A1(new_n427_), .A2(new_n429_), .B(new_n380_), .Y(new_n430_));
  AO22x1_ASAP7_75t_R   g344(.A1(new_n129_), .A2(new_n424_), .B1(new_n247_), .B2(new_n425_), .Y(new_n431_));
  AO22x1_ASAP7_75t_R   g345(.A1(new_n247_), .A2(new_n424_), .B1(new_n129_), .B2(new_n425_), .Y(new_n432_));
  AO22x1_ASAP7_75t_R   g346(.A1(G44), .A2(new_n431_), .B1(new_n118_), .B2(new_n432_), .Y(new_n433_));
  AO21x1_ASAP7_75t_R   g347(.A1(new_n381_), .A2(new_n433_), .B(new_n430_), .Y(new_n434_));
  OA211x2_ASAP7_75t_R  g348(.A1(new_n99_), .A2(new_n125_), .B(new_n423_), .C(new_n434_), .Y(G877));
  OAI21x1_ASAP7_75t_R  g349(.A1(new_n125_), .A2(G60), .B(G50), .Y(new_n436_));
  AND3x1_ASAP7_75t_R   g350(.A(new_n238_), .B(new_n436_), .C(G41), .Y(new_n437_));
  AO21x1_ASAP7_75t_R   g351(.A1(new_n115_), .A2(new_n436_), .B(new_n437_), .Y(new_n438_));
  AO21x1_ASAP7_75t_R   g352(.A1(G54), .A2(new_n361_), .B(new_n129_), .Y(new_n439_));
  AO22x1_ASAP7_75t_R   g353(.A1(new_n359_), .A2(new_n439_), .B1(new_n129_), .B2(new_n360_), .Y(new_n440_));
  AO22x1_ASAP7_75t_R   g354(.A1(new_n127_), .A2(new_n363_), .B1(new_n128_), .B2(new_n362_), .Y(new_n441_));
  AO21x1_ASAP7_75t_R   g355(.A1(new_n127_), .A2(new_n362_), .B(new_n363_), .Y(new_n442_));
  AO22x1_ASAP7_75t_R   g356(.A1(G41), .A2(new_n441_), .B1(new_n115_), .B2(new_n442_), .Y(new_n443_));
  AND3x1_ASAP7_75t_R   g357(.A(new_n97_), .B(new_n359_), .C(new_n233_), .Y(new_n444_));
  AO21x1_ASAP7_75t_R   g358(.A1(new_n232_), .A2(new_n359_), .B(new_n444_), .Y(new_n445_));
  AO21x1_ASAP7_75t_R   g359(.A1(new_n97_), .A2(new_n360_), .B(G24), .Y(new_n446_));
  AO22x1_ASAP7_75t_R   g360(.A1(new_n232_), .A2(new_n360_), .B1(new_n233_), .B2(new_n446_), .Y(new_n447_));
  AO22x1_ASAP7_75t_R   g361(.A1(G41), .A2(new_n445_), .B1(new_n115_), .B2(new_n447_), .Y(new_n448_));
  INVx1_ASAP7_75t_R    g362(.A(new_n448_), .Y(new_n449_));
  NOR2x1_ASAP7_75t_R   g363(.A(new_n344_), .B(new_n355_), .Y(new_n450_));
  INVx1_ASAP7_75t_R    g364(.A(new_n450_), .Y(new_n451_));
  AO21x1_ASAP7_75t_R   g365(.A1(new_n126_), .A2(new_n408_), .B(new_n407_), .Y(new_n452_));
  AO22x1_ASAP7_75t_R   g366(.A1(G42), .A2(new_n452_), .B1(new_n116_), .B2(new_n126_), .Y(new_n453_));
  AO21x1_ASAP7_75t_R   g367(.A1(new_n116_), .A2(new_n452_), .B(G42), .Y(new_n454_));
  AO22x1_ASAP7_75t_R   g368(.A1(new_n450_), .A2(new_n453_), .B1(new_n451_), .B2(new_n454_), .Y(new_n455_));
  AO21x1_ASAP7_75t_R   g369(.A1(new_n126_), .A2(new_n407_), .B(new_n408_), .Y(new_n456_));
  AO21x1_ASAP7_75t_R   g370(.A1(G42), .A2(new_n456_), .B(new_n116_), .Y(new_n457_));
  AO22x1_ASAP7_75t_R   g371(.A1(G42), .A2(new_n126_), .B1(new_n116_), .B2(new_n456_), .Y(new_n458_));
  AO22x1_ASAP7_75t_R   g372(.A1(new_n450_), .A2(new_n457_), .B1(new_n451_), .B2(new_n458_), .Y(new_n459_));
  AO22x1_ASAP7_75t_R   g373(.A1(new_n448_), .A2(new_n455_), .B1(new_n449_), .B2(new_n459_), .Y(new_n460_));
  AND4x2_ASAP7_75t_R   g374(.A(new_n438_), .B(new_n440_), .C(new_n443_), .D(new_n460_), .Y(G878));
  AO21x1_ASAP7_75t_R   g375(.A1(new_n97_), .A2(G50), .B(new_n125_), .Y(new_n462_));
  INVx1_ASAP7_75t_R    g376(.A(new_n462_), .Y(new_n463_));
  OR3x1_ASAP7_75t_R    g377(.A(new_n237_), .B(new_n463_), .C(new_n116_), .Y(new_n464_));
  NAND2x1_ASAP7_75t_R  g378(.A(new_n116_), .B(new_n462_), .Y(new_n465_));
  AO22x1_ASAP7_75t_R   g379(.A1(new_n127_), .A2(new_n450_), .B1(new_n309_), .B2(new_n451_), .Y(new_n466_));
  AO21x1_ASAP7_75t_R   g380(.A1(new_n312_), .A2(new_n451_), .B(new_n450_), .Y(new_n467_));
  AOI22x1_ASAP7_75t_R  g381(.A1(G42), .A2(new_n466_), .B1(new_n116_), .B2(new_n467_), .Y(new_n468_));
  AO21x1_ASAP7_75t_R   g382(.A1(new_n464_), .A2(new_n465_), .B(new_n468_), .Y(new_n469_));
  NOR2x1_ASAP7_75t_R   g383(.A(new_n407_), .B(new_n469_), .Y(new_n470_));
  NOR2x1_ASAP7_75t_R   g384(.A(G51), .B(new_n469_), .Y(new_n471_));
  AO21x1_ASAP7_75t_R   g385(.A1(G51), .A2(new_n470_), .B(new_n471_), .Y(new_n472_));
  NOR2x1_ASAP7_75t_R   g386(.A(new_n408_), .B(new_n469_), .Y(new_n473_));
  AO22x1_ASAP7_75t_R   g387(.A1(new_n354_), .A2(new_n473_), .B1(new_n355_), .B2(new_n470_), .Y(new_n474_));
  AO21x1_ASAP7_75t_R   g388(.A1(G51), .A2(new_n474_), .B(new_n471_), .Y(new_n475_));
  AO22x1_ASAP7_75t_R   g389(.A1(new_n344_), .A2(new_n472_), .B1(new_n345_), .B2(new_n475_), .Y(new_n476_));
  AO21x1_ASAP7_75t_R   g390(.A1(G51), .A2(new_n473_), .B(new_n471_), .Y(new_n477_));
  AO22x1_ASAP7_75t_R   g391(.A1(new_n354_), .A2(new_n470_), .B1(new_n355_), .B2(new_n473_), .Y(new_n478_));
  AO21x1_ASAP7_75t_R   g392(.A1(G51), .A2(new_n478_), .B(new_n471_), .Y(new_n479_));
  AO22x1_ASAP7_75t_R   g393(.A1(new_n344_), .A2(new_n477_), .B1(new_n345_), .B2(new_n479_), .Y(new_n480_));
  AO22x1_ASAP7_75t_R   g394(.A1(G42), .A2(new_n476_), .B1(new_n116_), .B2(new_n480_), .Y(G879));
  AO21x1_ASAP7_75t_R   g395(.A1(G25), .A2(new_n125_), .B(new_n98_), .Y(new_n482_));
  AND3x1_ASAP7_75t_R   g396(.A(new_n238_), .B(new_n482_), .C(G43), .Y(new_n483_));
  AOI21x1_ASAP7_75t_R  g397(.A1(new_n117_), .A2(new_n482_), .B(new_n483_), .Y(new_n484_));
  AO22x1_ASAP7_75t_R   g398(.A1(new_n127_), .A2(new_n388_), .B1(new_n309_), .B2(new_n389_), .Y(new_n485_));
  AO21x1_ASAP7_75t_R   g399(.A1(new_n312_), .A2(new_n389_), .B(new_n388_), .Y(new_n486_));
  AOI22x1_ASAP7_75t_R  g400(.A1(G43), .A2(new_n485_), .B1(new_n117_), .B2(new_n486_), .Y(new_n487_));
  AO21x1_ASAP7_75t_R   g401(.A1(new_n344_), .A2(new_n386_), .B(new_n387_), .Y(new_n488_));
  AO22x1_ASAP7_75t_R   g402(.A1(G43), .A2(new_n388_), .B1(new_n117_), .B2(new_n488_), .Y(new_n489_));
  INVx1_ASAP7_75t_R    g403(.A(new_n489_), .Y(new_n490_));
  AO21x1_ASAP7_75t_R   g404(.A1(new_n118_), .A2(new_n126_), .B(new_n427_), .Y(new_n491_));
  AO21x1_ASAP7_75t_R   g405(.A1(new_n118_), .A2(new_n426_), .B(G44), .Y(new_n492_));
  AO22x1_ASAP7_75t_R   g406(.A1(new_n380_), .A2(new_n491_), .B1(new_n381_), .B2(new_n492_), .Y(new_n493_));
  AO21x1_ASAP7_75t_R   g407(.A1(G44), .A2(new_n428_), .B(new_n118_), .Y(new_n494_));
  AO21x1_ASAP7_75t_R   g408(.A1(G44), .A2(new_n126_), .B(new_n429_), .Y(new_n495_));
  AO22x1_ASAP7_75t_R   g409(.A1(new_n380_), .A2(new_n494_), .B1(new_n381_), .B2(new_n495_), .Y(new_n496_));
  AOI22x1_ASAP7_75t_R  g410(.A1(new_n489_), .A2(new_n493_), .B1(new_n490_), .B2(new_n496_), .Y(new_n497_));
  OR3x1_ASAP7_75t_R    g411(.A(new_n484_), .B(new_n487_), .C(new_n497_), .Y(new_n498_));
  INVx1_ASAP7_75t_R    g412(.A(new_n498_), .Y(G880));
endmodule


