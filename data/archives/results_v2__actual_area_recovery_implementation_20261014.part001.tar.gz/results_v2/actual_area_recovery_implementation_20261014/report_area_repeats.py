import json,hashlib
from pathlib import Path
root=Path('/home/flynn/workplace/MIGBalance');out=root/'results_v2/actual_area_recovery_report_20261014'
reports=[root/f'results_v2/{name}/report.json' for name in ['actual_area_recovery_full_20261014','actual_area_recovery_full_repeat_20261014']];runs=[json.load(open(p)) for p in reports];assert runs[0]['hashes']==runs[1]['hashes']; assert all(len(x['results'])==40 for x in runs)
rows=[];errors=[]
for r0,r1 in zip(runs[0]['results'],runs[1]['results']):
 assert all(r0[k]==r1[k] for k in ['bench','k','input_sha256','prepared_sha256','library_sha256'])
 row={'bench':r0['bench'],'k':r0['k'],'statuses':[r0['status'],r1['status']],'runs':[r0,r1]}
 if all(r['status']=='diagnostic_cec_ok' for r in [r0,r1]):
  row['delay_range']=[min(r['measured']['delay'] for r in [r0,r1]),max(r['measured']['delay'] for r in [r0,r1])];row['area_range']=[min(r['measured']['area'] for r in [r0,r1]),max(r['measured']['area'] for r in [r0,r1])]
 for r in [r0,r1]:
  if r['status']!='diagnostic_cec_ok':continue
  b=r['budget'];assert r['measured']['cec']==1
  if r['measured']['delay']>b['fixed_delay_bound']+1e-5 or b['global_recovery_seconds']>2 or b['global_pool_prefix_plus_plans_and_proposals_peak']>100000 or b['global_resident_charged_state_peak']>20000 or b['cuts_per_original_class']>16:errors.append([r['k'],r['bench']])
 rows.append(row)
allrows=[r for x in runs for r in x['results']];valid=[r for r in allrows if r['status']=='diagnostic_cec_ok'];eligible=[r for r in valid if r['formal_same_import_budget_eligible']]
summary={'observations':len(allrows),'cec':len(valid),'legacy_eligible_cec':len(eligible),'failure_observations':len(allrows)-len(valid),'bound_budget_errors':errors,'source_hashes_identical':True,'two_runs_per_case_not_statistical_confidence':True,'all_successful_repeat_delays_identical':all(r.get('delay_range',[0,0])[0]==r.get('delay_range',[0,0])[1] for r in rows),'area_varying_case_count':sum(r.get('area_range',[0,0])[0]!=r.get('area_range',[0,0])[1] for r in rows),'targets':[{k:r[k] for k in ['bench','k','statuses','delay_range','area_range'] if k in r} for r in rows if r['bench'] in ['sqrt','bar','sin','multiplier']],'reports':{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in reports}}
(out/'full_repeat_pairs.json').write_text(json.dumps(rows,indent=2));(out/'repeat_validation.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary,indent=2))
