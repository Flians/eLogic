import json,subprocess
from pathlib import Path
root=Path('/home/flynn/workplace/MIGBalance');out=root/'results_v2/actual_area_recovery_report_20261014';x=json.load(open(root/'results_v2/actual_area_recovery_full_20261014/report.json'));commands=[]
required=['abc_map_area_resyn2','abc_map_delay_resyn2','mockturtle_emap_area_resyn2','mockturtle_emap_delay_resyn2','eqmap_lut_amap','esyn_frozen_model_amap_bounded_dag','emorphic_final_sa']
for k in [3,4]:
 base=root/f'results_v2/epfl_queue_baseline_scope_complete_20261013/baselines_{k}in_delay-area.json';b=json.load(open(base));c={'library_sha256':b['library_sha256'],'metric_model':b['metric_model'],'results':[]}
 for r in x['results']:
  if r['k']!=k:continue
  ok=r['status']=='diagnostic_cec_ok' and r['formal_same_import_budget_eligible']
  c['results'].append({'bench':r['bench'],'method':'regional_actual_area_v4','input_sha256':r['input_sha256'],'preprocessing':{'sha256':r['prepared_sha256'],'cec':1},'status':'ok' if ok else 'failed','measured':r.get('measured'),'error':None if ok else r.get('error','cumulative import exceeds legacy budget'),'diagnostic_status':r['status']})
 p=out/f'candidate_{k}in.json';p.write_text(json.dumps(c,indent=2))
 for objective in ['delay-area','area-delay','pareto']:
  cmd=['python3',str(root/'scripts/experiments/check_mapping_dominance.py'),'--candidate',str(p),'--baselines',str(base),'--required-baselines',*required,'--candidate-methods','regional_actual_area_v4','--objective',objective,'--output',str(out/f'gate_{k}in_{objective}.json')]
  run=subprocess.run(cmd,cwd=root,capture_output=True,text=True);commands.append({'argv':cmd,'exit':run.returncode,'stdout':run.stdout,'stderr':run.stderr})
(out/'gate_commands.json').write_text(json.dumps({'commands':commands,'optimization_profile':'delay-area only; area-delay is a posthoc gate, not an area-delay optimized experiment'},indent=2))
print([(r['argv'][-1],r['exit']) for r in commands])
