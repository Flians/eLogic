import json,hashlib,subprocess,shutil
from pathlib import Path
root=Path('/home/flynn/workplace/MIGBalance');out=root/'results_v2/actual_area_recovery_implementation_20261014'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
f=json.load(open(root/'results_v2/epfl_original_baselines_resumed_checkpoint_20261013/campaign.json'))['fingerprint'];drift=[];checked=0;excluded=[]
for p,h in f['files'].items():
 if '/emapper/src/' in p or p.endswith('/target/release/bench_rs_egraph_map') or p.endswith('/src/bin/bench_rs_egraph_map.rs'):excluded.append(p);continue
 if not Path(p).exists() or sha(Path(p))!=h:drift.append(p)
 checked+=1
for r,v in f['native'].items():
 if subprocess.check_output(['git','-C',r,'rev-parse','HEAD'],text=True).strip()!=v['commit']:drift.append(r+':commit')
 for rel,h in v['tracked_sha256'].items():
  p=Path(r)/rel;checked+=1
  if not p.exists() or sha(p)!=h:drift.append(str(p))
(out/'baseline_integrity.json').write_text(json.dumps({'checked_files':checked,'drift':drift,'explicitly_unexecuted_rust_candidate_dependencies_excluded':excluded,'baseline_algorithms_changed':False,'production_binary_sha256':sha(root/'target/release/bench_rs_egraph_map')},indent=2))
assert not drift,drift
for version in [3,4]:
 dst=out/f'v{version}';dst.mkdir(exist_ok=True);src=root/f'research/state_retirement_cuts_v{version}_20261014'
 for name in ['src/main.rs','Cargo.toml','Cargo.lock']:
  p=dst/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src/name,p)
 shutil.copy2(src/f'target/release/state_retirement_cuts_v{version}_probe',dst/'probe.bin')
 d=root/f'scripts/experiments/campaigns/run_retirement_cuts_v{version}.py';shutil.copy2(d,dst/'driver.py')
 (dst/'hashes.json').write_text(json.dumps({str(p):sha(p) for p in dst.rglob('*') if p.is_file()},indent=2))
print(checked,'files checked, drift',len(drift))
