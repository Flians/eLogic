"""Read-only reconciliation of the uniform full-library mapper and frozen baselines."""
from collections import Counter
import csv
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
campaign = ROOT / "results_v2/search_resources_20261021/small_key_epfl/campaign.json"
baseline = ROOT / "results_v2/single_output_wide_20261021/full_library_baseline_A_D_T/baseline_A_D_T.csv"
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
hashes = {str(p): sha(p) for p in [campaign, baseline, Path(__file__)]}
state = json.loads(campaign.read_text())
assert len(state["jobs"]) == state["expected_jobs"] == 20
baselines = list(csv.DictReader(baseline.open()))
records, comparisons = [], []


def compare(x, y, keys):
    for key in keys:
        eps = 1e-6 * max(1, abs(y[key]))
        if x[key] < y[key] - eps:
            return "better"
        if x[key] > y[key] + eps:
            return "worse"
    return "equal"


for job in state["jobs"]:
    p = Path(job["report"])
    assert sha(p) == job["sha256"][str(p)]
    hashes[str(p)] = sha(p)
    data = json.loads(p.read_text())
    value = data["results"][0]
    search = value["scalability"]
    native = search.get("optimizer_native", {})
    row = dict(bench=value["bench"], A=value["measured"]["area"],
               D=value["measured"]["delay"], T=value["mapping_wall_secs"],
               native_selected=search.get("selected_attempt") is not None,
               cec=value["measured"]["cec"], report=str(p), native=native)
    assert row["cec"] == 1
    for method, objective in [
        ("abc_map_delay_resyn2", "delay-area"),
        ("mockturtle_emap_delay_resyn2", "delay-area"),
        ("eqmap_lut_amap", "delay-area"),
        ("esyn_frozen_model_amap_bounded_dag", "delay-area"),
        ("emorphic_final_sa", "native-final"),
    ]:
        matches = [r for r in baselines if r["bench"] == row["bench"]
                   and r["method"] == method and r["objective"] == objective]
        assert len(matches) == 1
        b = matches[0]
        if b["qualification"] != "equivalent":
            comparisons.append(dict(bench=row["bench"], method=method, valid=False,
                                    qualification=b["qualification"]))
            continue
        metrics = {k: float(b[k]) for k in ["A", "D", "T"]}
        comparisons.append(dict(bench=row["bench"], method=method, valid=True,
                                native_selected=row["native_selected"],
                                DA=compare(row, metrics, ["D", "A"]),
                                D=compare(row, metrics, ["D"]),
                                A=compare(row, metrics, ["A"]),
                                delta_D_percent=100 * (row["D"] / metrics["D"] - 1),
                                delta_A_percent=100 * (row["A"] / metrics["A"] - 1),
                                baseline=metrics, candidate={k: row[k] for k in ["A", "D", "T"]},
                                baseline_time_kind=b["T_kind"]))
    stages, imports = [], []
    for f in p.parent.rglob("*.stages.jsonl"):
        hashes[str(f)] = sha(f)
        stages += [json.loads(line) for line in f.read_text().splitlines()]
    times = {s["stage"]: s["unix_secs"] for s in stages}
    phase_intervals = {}
    for label, start, end in [
        ("Boolean_saturation", "saturation_start", "saturation_done"),
        ("cut_stage", "cuts_start", "cuts_done_generate_start"),
        ("ordinary_generation", "cuts_done_generate_start", "generate_done"),
        ("post_generation_to_prune", "generate_done", "cone_prune_start"),
        ("prune_and_cap", "cone_prune_start", "recover_start"),
    ]:
        if start in times and end in times:
            phase_intervals[label] = times[end] - times[start]
    row["stage_intervals_seconds"] = phase_intervals
    for f in p.parent.rglob("*.import.json"):
        hashes[str(f)] = sha(f)
        imports.append(json.loads(f.read_text()))
    row["import_diagnostics"] = imports
    failures = []
    for attempt in search["attempts"]:
        f = Path(attempt["stderr_path"])
        hashes[str(f)] = sha(f)
        text = f.read_text()
        failures.append(dict(exit_code=attempt["exit_code"], timeout=attempt["timeout"],
                             error_lines=[s for s in text.splitlines()
                                          if "Error:" in s or "memory allocation" in s],
                             last_stage=stages[-1]["stage"] if stages else None))
    row["attempt_outcomes"] = failures
    row["extra_nodes"] = (native["cumulative_admitted_enodes"] - native["cumulative_imported_enodes"]
                          if native else None)
    row["search_allowance"] = value["resource_policy"]["node_extra"]
    row["retained_over_generated"] = (native["instances"] / native["generated_instances"]
                                      if native and native["generated_instances"] else None)
    records.append(row)

summary = {}
for method in sorted({x["method"] for x in comparisons}):
    valid = [r for r in comparisons if r["method"] == method and r["valid"]]
    summary[method] = {"qualified_baseline_pairs": len(valid),
                       "DA_all_final_covers": dict(Counter(r["DA"] for r in valid)),
                       "D_all_final_covers": dict(Counter(r["D"] for r in valid)),
                       "A_all_final_covers": dict(Counter(r["A"] for r in valid)),
                       "DA_native_selected_only": dict(Counter(r["DA"] for r in valid if r["native_selected"]))}
result = dict(scope="one uniform source_small_key configuration, all20, 47cells; not production main",
              native_selected=sum(r["native_selected"] for r in records),
              final_CEC=sum(r["cec"] == 1 for r in records),
              final_delay_equals_seed=sum(abs(r["D"] - r["native"].get("seed_delay", -1))
                                          <= 1e-6 * max(1, r["D"])
                                          for r in records if r["native_selected"]),
              summary=summary, rows=records, comparisons=comparisons,
              hashes=hashes, mapping_rerun=False, source_modified=False,
              best_baseline_per_design_selection=False)
(OUT / "reconciliation.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps({k: result[k] for k in ["native_selected", "final_CEC", "final_delay_equals_seed", "summary"]}, indent=2))
