//! Region-owned physical matching on one global egraph and joint phase recovery.
//! Region boundaries retain global class IDs. Neither nodes, candidates, saturation
//! iterations nor recovery time are reset at region boundaries.
use super::*;

/// Import only logically demanded inversion enodes, while retaining every PI
/// and the constant. Physical signal phases remain globally available through
/// library matches; unreferenced Not enodes need not consume the egraph budget.
/// All actually imported nodes and all rewrite nodes still count globally.
pub(super) fn import_demanded(aig: &Aig) -> Option<(egg::EGraph<AigLang, ()>, Vec<(u32, Id)>)> {
    let (expr, roots) = crate::egraph_sat::build_expr(aig)?;
    let nodes = expr.as_ref();
    let mut needed = vec![false; nodes.len()];
    let mut stack: Vec<_> = roots.iter().map(|(_, id)| *id).collect();
    for (i, node) in nodes.iter().enumerate() {
        if matches!(node, AigLang::Pi(_) | AigLang::Zero) {
            stack.push(Id::from(i));
        }
    }
    while let Some(id) = stack.pop() {
        let i = usize::from(id);
        if needed[i] {
            continue;
        }
        needed[i] = true;
        stack.extend(nodes[i].children().iter().copied());
    }
    let mut graph = egg::EGraph::default();
    let mut translated = vec![None; nodes.len()];
    for (i, node) in nodes.iter().enumerate() {
        if needed[i] {
            translated[i] = Some(
                graph.add(
                    node.clone()
                        .map_children(|child| translated[usize::from(child)].unwrap()),
                ),
            );
        }
    }
    graph.rebuild();
    let roots = roots
        .into_iter()
        .map(|(pos, id)| (pos, graph.find(translated[usize::from(id)].unwrap())))
        .collect();
    Some((graph, roots))
}

/// Direct phase-edge logical import. Original live AND nodes and every PI/zero
/// are represented, hash-consed and charged globally; only separate NOT enodes
/// on internal edges are replaced by explicit bits on the logical operator.
/// Conservative raw-language preflight. This plans storage without allocating
/// an oversized egraph; all live ANDs/PIs are still imported and charged later.
pub(super) fn ordinary_node_upper(aig:&Aig)->Option<usize> {
    use crate::aig_graph::AigNode;use petgraph::visit::EdgeRef;use petgraph::Direction;
    let g=aig.graph();let mut needed=HashSet::new();let mut stack=Vec::new();
    for n in g.node_indices() {if matches!(aig.node_type(n),AigNode::Input(_)|AigNode::Zero|AigNode::Output(_)){stack.push(n);}}
    while let Some(n)=stack.pop(){if needed.insert(n){stack.extend(g.edges_directed(n,Direction::Incoming).map(|e|e.source()));}}
    let base=needed.iter().filter(|&&n|!matches!(aig.node_type(n),AigNode::Output(_))).count();
    let inverted:HashSet<_>=needed.iter().flat_map(|&n|g.edges_directed(n,Direction::Incoming)).filter(|e|*e.weight()).map(|e|e.source()).collect();
    Some(base+inverted.len())
}

pub(super) fn import_literals(aig: &Aig) -> Option<(egg::EGraph<AigLang, ()>, Vec<(u32, Id)>)> {
    use crate::aig_graph::AigNode;
    use petgraph::visit::{EdgeRef,Topo,IntoEdgeReferences};
    use petgraph::Direction;
    let g=aig.graph();let mut needed=HashSet::new();let mut stack=Vec::new();
    for n in g.node_indices() {
        if matches!(aig.node_type(n),AigNode::Input(_)|AigNode::Zero|AigNode::Output(_)) {stack.push(n);}
    }
    while let Some(n)=stack.pop() {
        if !needed.insert(n) {continue;}
        stack.extend(g.edges_directed(n,Direction::Incoming).map(|e|e.source()));
    }
    let mut graph=egg::EGraph::default();let mut ids=HashMap::new();let mut topo=Topo::new(g);
    while let Some(n)=topo.next(g) {
        if !needed.contains(&n) {continue;}
        let node=match aig.node_type(n) {
            AigNode::Zero=>AigLang::Zero,
            AigNode::Input(v)=>AigLang::Pi(v),
            AigNode::And=>{
                let (a,b)=aig.try_unwrap_and(n)?;
                let x=*ids.get(&aig.edge_source(a))?;let y=*ids.get(&aig.edge_source(b))?;
                match (aig.is_edge_inverted(a),aig.is_edge_inverted(b)) {
                    (false,false)=>AigLang::And([x,y]),
                    (true,false)=>AigLang::Cell("@egm_and_np".into(),vec![x,y]),
                    (false,true)=>AigLang::Cell("@egm_and_pn".into(),vec![x,y]),
                    (true,true)=>AigLang::Cell("@egm_and_nn".into(),vec![x,y]),
                }
            }
            AigNode::Output(_)=>continue,
        };
        ids.insert(n,graph.add(node));
    }
    let mut roots=Vec::new();
    for n in g.node_indices() {
        if let AigNode::Output(pos)=aig.node_type(n) {
            let edge=g.edges_directed(n,Direction::Incoming).next()?;
            let base=*ids.get(&edge.source())?;
            let root=if *edge.weight() {graph.add(AigLang::Not(base))} else {base};
            roots.push((pos,root));
        }
    }
    roots.sort_by_key(|(p,_)|*p);graph.rebuild();
    let roots=roots.into_iter().map(|(p,id)|(p,graph.find(id))).collect();
    Some((graph,roots))
}

pub(super) fn ordered_boundaries<'a>(
    boundaries: &'a BTreeMap<Vec<usize>, Vec<Target>>,
    classes: usize,
    width: usize,
    stats: &mut MapStats,
) -> Vec<(&'a Vec<usize>, &'a Vec<Target>)> {
    let mut result: Vec<_> = boundaries.iter().collect();
    if width == 0 {
        return result;
    }
    stats.regions = classes.div_ceil(width);
    // One owner for a complete boundary, including targets in other regions:
    // multioutput sharing cannot be split into separately charged instances.
    result.sort_by_key(|(boundary, targets)| {
        let owner = targets
            .iter()
            .map(|t| t.signal / 2 / width)
            .min()
            .unwrap_or(0);
        (owner, *boundary)
    });
    stats.cross_region_boundaries = result
        .iter()
        .filter(|(boundary, targets)| {
            let owner = targets
                .iter()
                .map(|t| t.signal / 2 / width)
                .min()
                .unwrap_or(0);
            boundary.iter().any(|c| c / width != owner)
                || targets.iter().any(|t| t.signal / 2 / width != owner)
        })
        .count();
    result
}

/// Partition the remaining window without extending or resetting the global deadline.
/// Fraction one exactly preserves the previous scheduling policy.
pub(super) fn phase_deadline(start: Instant, global: Instant, fraction: f64) -> Instant {
    if fraction == 1.0 || global <= start {
        global
    } else {
        start + global.saturating_duration_since(start).mul_f64(fraction)
    }
}

pub(super) fn recover_phases(
    instances: &[Instance],
    chosen: &mut Vec<Option<Binding>>,
    witness: &[Option<Binding>],
    free: &[bool],
    roots: &[usize],
    ps: &MapParams,
    stats: &mut MapStats,
    deadline: Instant,
) -> Result<(), String> {
    let mut producers = vec![Vec::new(); free.len()];
    let mut reverse = HashMap::<(usize, usize), Binding>::new();
    // Recognize physical unary INV pins. Use only already admitted bindings;
    // this pass creates no logical equality and never unions SDC classes.
    for (i, m) in instances.iter().enumerate() {
        if Instant::now() >= deadline {
            return Ok(());
        }
        for (pin, o) in m.outputs.iter().enumerate() {
            for &s in &o.targets {
                producers[s].push(Binding { instance: i, pin });
                if m.inputs.len() == 1 && o.function == 1 {
                    reverse
                        .entry((m.inputs[0], s))
                        .or_insert(Binding { instance: i, pin });
                }
            }
        }
    }
    let mut best = metrics(instances, chosen, free, roots);
    stats.phase_initial_delay = best.1;
    stats.phase_final_delay = best.1;
    for t in 0..chosen.len() {
        if Instant::now() >= deadline || stats.phase_trials >= ps.refine_trials {
            break;
        }
        let Some(old) = chosen[t] else {
            continue;
        };
        let inv = &instances[old.instance];
        if inv.inputs.len() != 1 || inv.outputs[old.pin].function != 1 {
            continue;
        }
        let s = inv.inputs[0];
        if free[s] || chosen[s].is_none() {
            continue;
        }
        let Some(&back) = reverse.get(&(t, s)) else {
            continue;
        };
        for &alternative in &producers[t] {
            if Instant::now() >= deadline || stats.phase_trials >= ps.refine_trials {
                break;
            }
            let candidate = &instances[alternative.instance];
            if alternative.instance == old.instance
                || candidate.inputs.contains(&s)
                || candidate.inputs.contains(&t)
            {
                continue;
            }
            stats.phase_trials += 1;
            let mut trial = chosen.clone();
            trial[t] = Some(alternative);
            trial[s] = Some(back);
            // Atomic replacement prevents the temporary s->t->s inverse cycle.
            // Full DAG validation and global unique-instance metric handle
            // fanout sharing and all live pins, including multioutput cells.
            if fill_from_witness(instances, &mut trial, witness, free, roots).is_err() {
                continue;
            }
            let score = metrics(instances, &trial, free, roots);
            if better_cover(score, best, ps) {
                *chosen = trial;
                best = score;
                stats.phase_accepted += 1;
                stats.phase_final_delay = score.1;
            }
        }
    }
    prune(instances, chosen, free, roots)
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn phase_allocation_preserves_global_deadline() {
        let start = Instant::now();
        let global = start + std::time::Duration::from_secs(2);
        assert_eq!(phase_deadline(start, global, 1.0), global);
        assert_eq!(phase_deadline(start, global, 0.0), start);
        assert_eq!(phase_deadline(start, global, 0.25), start + std::time::Duration::from_millis(500));
        let expired = start - std::time::Duration::from_millis(1);
        assert_eq!(phase_deadline(start, expired, 1.0), expired);
        assert_eq!(phase_deadline(start, expired, 0.25), expired);
    }

    fn cell(name: &str, inputs: Vec<usize>, target: usize, function: u64, delay: f32) -> Instance {
        Instance {
            cell: name.into(),
            area: 1.,
            input_pins: inputs.iter().map(|_| "A".into()).collect(),
            outputs: vec![OutputPin {
                name: "Y".into(),
                delays: vec![delay; inputs.len()],
                function,
                targets: vec![target],
            }],
            inputs,
        }
    }
    #[test]
    fn atomic_phase_flip_preserves_shared_positive_root() {
        let m = vec![
            cell("AND", vec![0, 1], 2, 8, 10.),
            cell("INV", vec![2], 3, 1, 3.),
            cell("NAND", vec![0, 1], 3, 7, 4.),
            cell("INV", vec![3], 2, 1, 3.),
        ];
        let free = vec![true, true, false, false];
        let roots = vec![2, 3];
        for objective in [MapObjective::AreaDelay, MapObjective::DelayArea] {
            let mut chosen = vec![
                None,
                None,
                Some(Binding {
                    instance: 0,
                    pin: 0,
                }),
                Some(Binding {
                    instance: 1,
                    pin: 0,
                }),
            ];
            let witness = chosen.clone();
            let ps = MapParams {
                objective,
                phase_recovery: true,
                ..Default::default()
            };
            let mut stats = MapStats::default();
            recover_phases(
                &m,
                &mut chosen,
                &witness,
                &free,
                &roots,
                &ps,
                &mut stats,
                Instant::now() + std::time::Duration::from_secs(1),
            )
            .unwrap();
            assert_eq!(metrics(&m, &chosen, &free, &roots), (2., 7.));
            assert_eq!(stats.phase_accepted, 1);
        }
    }
    #[test]
    fn expired_phase_deadline_preserves_incumbent() {
        let m = vec![
            cell("AND", vec![0, 1], 2, 8, 10.),
            cell("INV", vec![2], 3, 1, 3.),
        ];
        let free = vec![true, true, false, false];
        let roots = vec![2, 3];
        let mut chosen = vec![
            None,
            None,
            Some(Binding {
                instance: 0,
                pin: 0,
            }),
            Some(Binding {
                instance: 1,
                pin: 0,
            }),
        ];
        let witness = chosen.clone();
        let mut stats = MapStats::default();
        recover_phases(
            &m,
            &mut chosen,
            &witness,
            &free,
            &roots,
            &MapParams::default(),
            &mut stats,
            Instant::now(),
        )
        .unwrap();
        assert_eq!(stats.phase_trials, 0);
        assert_eq!(metrics(&m, &chosen, &free, &roots), (2., 13.));
    }

    #[test]
    fn region_ownership_keeps_cross_region_joint_targets() {
        let b = BTreeMap::from([(
            vec![0, 3],
            vec![
                Target {
                    signal: 4,
                    function: 8,
                },
                Target {
                    signal: 12,
                    function: 7,
                },
            ],
        )]);
        let mut stats = MapStats::default();
        let owned = ordered_boundaries(&b, 8, 2, &mut stats);
        assert_eq!(owned.len(), 1);
        assert_eq!(owned[0].1.len(), 2);
        assert_eq!(stats.regions, 4);
        assert_eq!(stats.cross_region_boundaries, 1);
    }
}

/// Conservative reservation before each exact rewrite application. The RHS
/// pattern size bounds new enodes (variables add none). This prevents a full
/// iteration from first overshooting the global allowance and then rejecting
/// an otherwise usable input. It changes search coverage, never equivalence.
struct ReservedRewrite {
    inner: std::sync::Arc<dyn egg::Applier<AigLang, ()> + Send + Sync>,
    allowance: usize,
    reservation: usize,
    skipped: std::sync::Arc<std::sync::atomic::AtomicUsize>,
}
impl egg::Applier<AigLang, ()> for ReservedRewrite {
    fn apply_one(
        &self,
        graph: &mut egg::EGraph<AigLang, ()>,
        id: Id,
        subst: &egg::Subst,
        ast: Option<&egg::PatternAst<AigLang>>,
        name: egg::Symbol,
    ) -> Vec<Id> {
        if graph
            .total_number_of_nodes()
            .saturating_add(self.reservation)
            > self.allowance
        {
            self.skipped
                .fetch_add(1, std::sync::atomic::Ordering::Relaxed);
            return vec![];
        }
        self.inner.apply_one(graph, id, subst, ast, name)
    }
    fn vars(&self) -> Vec<egg::Var> {
        self.inner.vars()
    }
    fn get_pattern_ast(&self) -> Option<&egg::PatternAst<AigLang>> {
        self.inner.get_pattern_ast()
    }
}
pub(super) fn reserve_rewrites(
    rules: &mut [egg::Rewrite<AigLang, ()>],
    allowance: usize,
) -> std::sync::Arc<std::sync::atomic::AtomicUsize> {
    let skipped = std::sync::Arc::new(std::sync::atomic::AtomicUsize::new(0));
    for rule in rules {
        // Non-pattern appliers keep their own guard; no unproven size estimate.
        if let Some(ast) = rule.applier.get_pattern_ast() {
            let reservation = ast.as_ref().len();
            rule.applier = std::sync::Arc::new(ReservedRewrite {
                inner: rule.applier.clone(),
                allowance,
                reservation,
                skipped: skipped.clone(),
            });
        }
    }
    skipped
}

/// Fixed exact XOR pattern contraction BEFORE import. Original intermediate AND
/// functions replaced by a two-input XOR are not materialized as hidden eclasses.
/// Every realized XOR/AND/PI/Not/constant is globally charged; no retirement/reset.
#[derive(Clone,Copy)]
pub(super) struct SourceAnd{pub root:Id,pub left:Id,pub right:Id,pub left_neg:bool,pub right_neg:bool}

pub(super) fn import_xors(aig:&Aig)->Option<(egg::EGraph<AigLang,()>,Vec<(u32,Id)>)>{import_with_source(aig,false).map(|(g,r,_)|(g,r))}

/// All helper functions are actual imported nodes. The source AND certificate
/// only authorizes physical cut/match records in the ordinary bounded cut/pool
/// bank; it adds no egraph alternative or conditional union. No omitted function
/// may appear in any certificate or physical boundary.
pub(super) fn import_with_source(aig:&Aig,keep_helpers:bool)->Option<(egg::EGraph<AigLang,()>,Vec<(u32,Id)>,Vec<SourceAnd>)>{
 import_with_helpers(aig,if keep_helpers{usize::MAX}else{0},usize::MAX)
}
/// floor(9n/10), without overflowing on an arbitrary caller's node allowance.
pub(super) fn initial_node_ceiling(n:usize)->usize{n-n/10-usize::from(n%10!=0)}

pub(super) fn import_with_shared_helpers(aig:&Aig,quota:usize,limit:usize)->Option<(egg::EGraph<AigLang,()>,Vec<(u32,Id)>,Vec<SourceAnd>)>{import_helpers_impl(aig,quota,limit,true)}
pub(super) fn import_with_helpers(aig:&Aig,helper_quota:usize,node_allowance:usize)->Option<(egg::EGraph<AigLang,()>,Vec<(u32,Id)>,Vec<SourceAnd>)>{
 import_helpers_impl(aig,helper_quota,node_allowance,false)
}
fn import_helpers_impl(aig:&Aig,helper_quota:usize,node_allowance:usize,shared_majority:bool)->Option<(egg::EGraph<AigLang,()>,Vec<(u32,Id)>,Vec<SourceAnd>)>{
 use crate::aig_graph::AigNode;use petgraph::visit::{EdgeRef,Topo,IntoEdgeReferences};use petgraph::Direction;
 let g=aig.graph();let pair=|n|{let (a,b)=aig.try_unwrap_and(n)?;let mut v=vec![(aig.edge_source(a),aig.is_edge_inverted(a)),(aig.edge_source(b),aig.is_edge_inverted(b))];v.sort();Some(v)};
 let mut macros=HashMap::new();
 for n in g.node_indices(){if !matches!(aig.node_type(n),AigNode::And){continue}let outer=pair(n)?;if !outer.iter().all(|(n,p)|*p && matches!(aig.node_type(*n),AigNode::And)){continue}let x=pair(outer[0].0)?;let y=pair(outer[1].0)?;let mut complement:Vec<_>=y.iter().map(|&(n,p)|(n,!p)).collect();complement.sort();if x==complement{macros.insert(n,x);}}
 let mut uses=HashMap::<_,usize>::new();for e in g.edge_references(){*uses.entry(e.source()).or_default()+=1;}
 let mut triples=HashMap::new();
 for n in g.node_indices(){if !matches!(aig.node_type(n),AigNode::And)||macros.contains_key(&n){continue}let outer=pair(n)?;
  for which in 0..2{let child=outer[which].0;if !matches!(aig.node_type(child),AigNode::And)||uses[&child]!=1||macros.contains_key(&child){continue}let inner=pair(child)?;let leaves:Vec<_>=[outer[1-which].0,inner[0].0,inner[1].0].into_iter().collect::<BTreeSet<_>>().into_iter().collect();if leaves.len()!=3{continue}let mut tt=0;for a in 0..8{let get=|node|((a>>leaves.binary_search(&node).unwrap())&1)!=0;let c=(get(inner[0].0)^inner[0].1)&(get(inner[1].0)^inner[1].1);let other=get(outer[1-which].0)^outer[1-which].1;tt|=u64::from((c^outer[which].1)&other)<<a;}triples.insert(n,(leaves,tt));break;}
 }
 let mut raw_source_upper=0usize;
 if shared_majority {
  let mut raw=HashSet::new();let mut work:Vec<_>=g.node_indices().filter(|&n|matches!(aig.node_type(n),AigNode::Input(_)|AigNode::Zero|AigNode::Output(_))).collect();
  while let Some(n)=work.pop(){if !raw.insert(n){continue}if let Some((leaves,_))=triples.get(&n){work.extend(leaves);}else if let Some(v)=macros.get(&n){work.extend(v.iter().map(|x|x.0));}else{work.extend(g.edges_directed(n,Direction::Incoming).map(|e|e.source()));}}
  let inversions:HashSet<_>=g.node_indices().filter(|&n|matches!(aig.node_type(n),AigNode::Output(_))).flat_map(|n|g.edges_directed(n,Direction::Incoming)).filter(|e|*e.weight()).map(|e|e.source()).collect();
  raw_source_upper=raw.iter().filter(|&&n|!matches!(aig.node_type(n),AigNode::Output(_))).count()+inversions.len();
 }
 let compact_primitives=shared_majority && raw_source_upper>node_allowance;
 let mut original_triples=if shared_majority {Some(triples.clone())}else{None};
 let mut majority_folds=0usize;let mut source_choices=HashMap::<_,Vec<(Vec<petgraph::graph::NodeIndex>,u64)>>::new();let mut source_depth=HashMap::new();
 if shared_majority {
  // At most four exact source fringes per child, hence sixteen combinations.
  // This plans a representation, not an extra retained physical-cut bank.
  let majority_tables:BTreeSet<u64>=(0..8).map(|phase|(0u32..8).fold(0u64,|tt,a|tt|(u64::from((a^phase).count_ones()>=2)<<a))).collect();
  let mut majority_tables=majority_tables;
  if compact_primitives {for phase in 0..8 {for neg in [false,true] {for last in 0..3 {
   let others:Vec<_>=(0..3).filter(|p|*p!=last).collect();
   majority_tables.insert((0..8).fold(0u64,|tt,a|{let v=a^phase;let bit=(((v>>others[0])&1!=0)&&((v>>others[1])&1!=0))||((v>>last)&1!=0);tt|(u64::from(bit^neg)<<a)}));
  }majority_tables.insert((0..8).fold(0u64,|tt,a|tt|(u64::from(((a^phase)==7)^neg)<<a)));}}}

  let mut topo=Topo::new(g);let depth=&mut source_depth;
  while let Some(n)=topo.next(g){
   let level=g.edges_directed(n,Direction::Incoming).map(|e|depth[&e.source()]).max().unwrap_or(0usize)+usize::from(matches!(aig.node_type(n),AigNode::And));depth.insert(n,level);
   if !matches!(aig.node_type(n),AigNode::And)||macros.contains_key(&n){continue}
   let original=pair(n)?;
   let fringe=|node,triples:&HashMap<petgraph::graph::NodeIndex,(Vec<petgraph::graph::NodeIndex>,u64)>|{
    let mut cuts=vec![(vec![node],2u64)];let mut extra=Vec::new();
    if let Some(v)=pair(node){let leaves:Vec<_>=v.iter().map(|x|x.0).collect();let tt=(0..4).fold(0u64,|tt,a|tt|(u64::from((((a&1)!=0)^v[0].1)&&(((a&2)!=0)^v[1].1))<<a));cuts.push((leaves,tt));
     for which in 0..2 {if let Some(x)=macros.get(&v[which].0){
      let leaves:Vec<_>=x.iter().map(|x|x.0).chain(std::iter::once(v[1-which].0)).collect::<BTreeSet<_>>().into_iter().collect();if leaves.len()>3{continue}
      let tt=(0..1usize<<leaves.len()).fold(0u64,|tt,bits|{let get=|n|bits&(1<<leaves.binary_search(&n).unwrap())!=0;let parity=(get(x[0].0)^get(x[1].0))^(x[0].1^x[1].1);let other=get(v[1-which].0)^v[1-which].1;tt|(u64::from((parity^v[which].1)&other)<<bits)});extra.push((leaves,tt));
     }}
    }
    if let Some(cut)=triples.get(&node){extra.push(cut.clone());}
    if let Some(v)=macros.get(&node){extra.push((v.iter().map(|x|x.0).collect(),if v[0].1^v[1].1{9}else{6}));}
    extra.sort_by_key(|(leaves,tt)|(leaves.iter().map(|n|depth[n]).sum::<usize>(),leaves.clone(),*tt));extra.dedup();cuts.extend(extra.into_iter().take(4-cuts.len()));
    cuts
   };
   let left=fringe(original[0].0,&triples);let right=fringe(original[1].0,&triples);let mut best=None;
   for (a,at) in &left{for (b,bt) in &right{
    let leaves:Vec<_>=a.iter().chain(b).copied().collect::<BTreeSet<_>>().into_iter().collect();if leaves.len()!=3{continue}
    let value=|bits:usize,cut:&Vec<petgraph::graph::NodeIndex>,tt:u64|{let row=cut.iter().enumerate().map(|(p,x)|((bits>>leaves.binary_search(x).unwrap())&1)<<p).sum::<usize>();(tt>>row)&1!=0};
    let tt=(0..8).fold(0u64,|tt,bits|tt|(u64::from((value(bits,a,*at)^original[0].1)&(value(bits,b,*bt)^original[1].1))<<bits));if !majority_tables.contains(&tt){continue}
    source_choices.entry(n).or_default().push((leaves.clone(),tt));
    let rank=(leaves.iter().map(|n|depth[n]).sum::<usize>(),leaves.clone(),tt);
    if best.as_ref().is_none_or(|old|rank<*old){best=Some(rank);}
   }}
   if let Some((_,leaves,tt))=best {if triples.get(&n)!=Some(&(leaves.clone(),tt)){majority_folds+=1;triples.insert(n,(leaves,tt));}}
  }
 }
 let mut source_plan_before=0usize;let mut source_plan_after=0usize;let mut source_plan_swaps=0usize;
 if compact_primitives {
  let original=original_triples.take().unwrap();let size=g.node_indices().map(|n|n.index()+1).max().unwrap_or(0);
  let mut parents=vec![Vec::new();size];let mut roots=Vec::new();let mut rank=vec![0usize;size];
  for n in g.node_indices(){rank[n.index()]=source_depth.get(&n).copied().unwrap_or(0);match aig.node_type(n){
   AigNode::Input(_)|AigNode::Zero=>roots.push(n.index()),
   AigNode::Output(_)=>{let e=g.edges_directed(n,Direction::Incoming).next()?;roots.push(e.source().index());},
   AigNode::And=>{parents[n.index()]=if let Some((leaves,_))=original.get(&n){leaves.iter().map(|n|n.index()).collect()}else if let Some(v)=macros.get(&n){v.iter().map(|x|x.0.index()).collect()}else{pair(n)?.iter().map(|x|x.0.index()).collect()};}
  }}
  let mut truth_banks=vec![Vec::new();size];let mut choices=vec![Vec::new();size];
  for (n,mut candidates) in source_choices {
   candidates.sort_by_key(|(leaves,tt)|(leaves.iter().map(|n|source_depth[n]).sum::<usize>(),leaves.clone(),*tt));candidates.dedup();candidates.truncate(15);
   choices[n.index()]=candidates.iter().map(|(leaves,_)|leaves.iter().map(|n|n.index()).collect()).collect();truth_banks[n.index()]=candidates;
  }
  let mut topo=Topo::new(g);let mut order=Vec::new();while let Some(n)=topo.next(g){order.push(n.index());}order.reverse();
  let (selected,before,after)=crate::egraph_source_plan::select(&parents,&roots,&choices,&rank,&order);source_plan_before=before;source_plan_after=after;
  triples=original;
  for (n,choice) in selected.into_iter().enumerate(){if let Some(i)=choice{triples.insert(petgraph::graph::NodeIndex::new(n),truth_banks[n][i].clone());source_plan_swaps+=1;}}
 }
 let mut alternative_plan=Vec::new();
 if let Some(original_triples)=original_triples {
  for (n,cut) in &triples {if original_triples.get(n)!=Some(cut){alternative_plan.push((*n,cut.clone()));}}
  alternative_plan.sort_by_key(|(n,_)|*n);triples=original_triples;
 }
 let mut needed=HashSet::new();let mut stack:Vec<_>=g.node_indices().filter(|&n|matches!(aig.node_type(n),AigNode::Input(_)|AigNode::Zero|AigNode::Output(_))).collect();
 while let Some(n)=stack.pop(){if !needed.insert(n){continue}if let Some((leaves,_))=triples.get(&n){stack.extend(leaves);}else if let Some(v)=macros.get(&n){stack.extend(v.iter().map(|(n,_)|*n));}else{stack.extend(g.edges_directed(n,Direction::Incoming).map(|e|e.source()));}}
 let mut helpers=HashSet::new();
 if helper_quota==usize::MAX {for n in g.node_indices(){if matches!(aig.node_type(n),AigNode::And)&&!needed.contains(&n){helpers.insert(n);needed.insert(n);}}}
 else if helper_quota>0 {
  let mut topo=Topo::new(g);let mut order=Vec::new();let mut depth=HashMap::<_,usize>::new();while let Some(n)=topo.next(g){let d=if matches!(aig.node_type(n),AigNode::And){let v=pair(n)?;depth[&v[0].0].max(depth[&v[1].0])+1usize}else if matches!(aig.node_type(n),AigNode::Output(_)){let e=g.edges_directed(n,Direction::Incoming).next()?;depth[&e.source()]}else{0};depth.insert(n,d);order.push(n);}
  let maximum=order.iter().filter(|&&n|matches!(aig.node_type(n),AigNode::Output(_))).map(|n|depth[n]).max().unwrap_or(0);let mut required=HashMap::<_,usize>::new();for &n in &order{if matches!(aig.node_type(n),AigNode::Output(_)){required.insert(n,maximum);}}
  for &n in order.iter().rev(){if let Some(&r)=required.get(&n){let child_r=r.saturating_sub(usize::from(matches!(aig.node_type(n),AigNode::And)));for e in g.edges_directed(n,Direction::Incoming){required.entry(e.source()).and_modify(|v|*v=(*v).min(child_r)).or_insert(child_r);}}}
  let mut groups=Vec::new();for &n in &needed{if !matches!(aig.node_type(n),AigNode::And)||(!macros.contains_key(&n)&&!triples.contains_key(&n)){continue}let original=pair(n)?;let missing:Vec<_>=original.iter().map(|v|v.0).filter(|n|!needed.contains(n)).collect::<BTreeSet<_>>().into_iter().collect();if missing.is_empty(){continue}if missing.iter().all(|n|matches!(aig.node_type(*n),AigNode::And)&&pair(*n).is_some_and(|v|v.iter().all(|(c,_)|needed.contains(c)))){groups.push((required.get(&n).copied().unwrap_or(usize::MAX).saturating_sub(depth[&n]),std::cmp::Reverse(depth[&n]),n,missing));}}
  groups.sort_by_key(|(slack,d,n,_)|(*slack,*d,*n));let output_not:HashSet<_>=g.node_indices().filter(|&n|matches!(aig.node_type(n),AigNode::Output(_))).flat_map(|n|g.edges_directed(n,Direction::Incoming)).filter(|e|*e.weight()).map(|e|e.source()).collect();let base=needed.iter().filter(|&&n|!matches!(aig.node_type(n),AigNode::Output(_))).count()+output_not.len();let ceiling=initial_node_ceiling(node_allowance);
  for (_,_,_,missing) in groups{let novel:Vec<_>=missing.into_iter().filter(|n|!needed.contains(n)).collect();if helpers.len()+novel.len()>helper_quota||base+helpers.len()+novel.len()>ceiling{continue}for n in novel{needed.insert(n);helpers.insert(n);}}
 }
 let planned_not:HashSet<_>=g.node_indices().filter(|&n|matches!(aig.node_type(n),AigNode::Output(_))).flat_map(|n|g.edges_directed(n,Direction::Incoming)).filter(|e|*e.weight()).map(|e|e.source()).collect();
 let planned_folded_source_upper=needed.iter().filter(|&&n|!matches!(aig.node_type(n),AigNode::Output(_))).count()+planned_not.len();
 let mut graph=egg::EGraph::default();let mut ids=HashMap::new();let mut topo=Topo::new(g);let mut actual_xor=0;let mut actual_tt3=0;
 while let Some(n)=topo.next(g){if !needed.contains(&n){continue}let node=match aig.node_type(n){
 AigNode::Zero=>AigLang::Zero,AigNode::Input(v)=>AigLang::Pi(v),AigNode::Output(_)=>continue,
 AigNode::And=>{if let Some((leaves,tt))=triples.get(&n).filter(|_|!helpers.contains(&n)){actual_tt3+=1;AigLang::Cell(format!("@egm_tt3_{tt:02x}").into(),leaves.iter().map(|n|ids[n]).collect())}else if let Some(v)=macros.get(&n).filter(|_|!helpers.contains(&n)){actual_xor+=1;let odd=v[0].1^v[1].1;AigLang::Cell(if odd{"@egm_xnor"}else{"@egm_xor"}.into(),v.iter().map(|(n,_)|ids[n]).collect())}else{let v=pair(n)?;let x=ids[&v[0].0];let y=ids[&v[1].0];match(v[0].1,v[1].1){(false,false)=>AigLang::And([x,y]),(true,false)=>AigLang::Cell("@egm_and_np".into(),vec![x,y]),(false,true)=>AigLang::Cell("@egm_and_pn".into(),vec![x,y]),(true,true)=>AigLang::Cell("@egm_and_nn".into(),vec![x,y])}}}};
 if shared_majority && graph.total_number_of_nodes()>=node_allowance && graph.lookup(node.clone()).is_none(){
  import_prefix_failure(node_allowance,raw_source_upper,planned_folded_source_upper,graph.total_number_of_nodes());return None;
 }
 ids.insert(n,graph.add(node));}
 let initial_base_enodes=graph.total_number_of_nodes();let mut alternative_enodes=0usize;let mut alternatives=0usize;let mut skipped_alternatives=0usize;
 let po_reserve:HashSet<_>=g.node_indices().filter(|&n|matches!(aig.node_type(n),AigNode::Output(_))).flat_map(|n|g.edges_directed(n,Direction::Incoming)).filter(|e|*e.weight()).map(|e|e.source()).collect();
 for (root,(leaves,tt)) in alternative_plan {
  if !ids.contains_key(&root)||leaves.iter().any(|n|!ids.contains_key(n)){skipped_alternatives+=1;continue}
  if initial_base_enodes.saturating_add(alternative_enodes).saturating_add(po_reserve.len()).saturating_add(1)>initial_node_ceiling(node_allowance){skipped_alternatives+=1;continue}
  let node=AigLang::Cell(format!("@egm_tt3_{tt:02x}").into(),leaves.iter().map(|n|ids[n]).collect());let before=graph.total_number_of_nodes();let new=graph.add(node);alternative_enodes+=graph.total_number_of_nodes()-before;graph.union(ids[&root],new);alternatives+=1;
 }
 let mut roots=Vec::new();for n in g.node_indices(){if let AigNode::Output(pos)=aig.node_type(n){let e=g.edges_directed(n,Direction::Incoming).next()?;let base=ids[&e.source()];let root=if *e.weight(){let node=AigLang::Not(base);if shared_majority && graph.total_number_of_nodes()>=node_allowance && graph.lookup(node.clone()).is_none(){import_prefix_failure(node_allowance,raw_source_upper,planned_folded_source_upper,graph.total_number_of_nodes());return None}graph.add(node)}else{base};roots.push((pos,root));}}
 let pre_rebuild_import_enodes=graph.total_number_of_nodes();
 roots.sort_by_key(|(p,_)|*p);graph.rebuild();let roots=roots.into_iter().map(|(p,id)|(p,graph.find(id))).collect();
 let mut source=Vec::new();for n in g.node_indices(){if !ids.contains_key(&n)||helpers.contains(&n)||(!macros.contains_key(&n)&&!triples.contains_key(&n)){continue}let inputs=pair(n)?;if let(Some(&a),Some(&b))=(ids.get(&inputs[0].0),ids.get(&inputs[1].0)){source.push(SourceAnd{root:graph.find(ids[&n]),left:graph.find(a),right:graph.find(b),left_neg:inputs[0].1,right_neg:inputs[1].1});}}

 let helper_classes:BTreeSet<_>=helpers.iter().map(|n|graph.find(ids[n])).collect();
 let unique_xor=graph.classes().flat_map(|c|&c.nodes).filter(|n|crate::egraph_sat::xor_inputs(n).is_some()).count();
 let unique_tt3=graph.classes().flat_map(|c|&c.nodes).filter(|n|crate::egraph_sat::tt3_inputs(n).is_some()).count();
 if let Some(path)=std::env::var_os("EGM_POOL_DIAG_PATH"){let path=std::path::Path::new(&path).with_extension("import.json");let _=std::fs::write(path,serde_json::json!({"schema_version":4,"source_plan_before":source_plan_before,"source_plan_after":source_plan_after,"source_plan_swaps":source_plan_swaps,"source_planning_choices_per_node":16,"source_planning_has_no_egraph_retirement":true,"import_complete":true,"raw_source_upper":raw_source_upper,"planned_folded_source_upper":planned_folded_source_upper,"compaction_threshold":node_allowance,"compact_primitives":compact_primitives,"source_fringe_cap":4,"source_fringe_combinations":16,"majority_alternatives":alternatives,"alternative_enodes_admitted":alternative_enodes,"skipped_alternatives":skipped_alternatives,"pre_rebuild_import_enodes":pre_rebuild_import_enodes,"shared_majority_enabled":shared_majority,"source_primitive_folds":majority_folds,"legacy_majority_fold_counter_is_primitive_fold_alias":true,"shared_majority_folds":majority_folds,"actual_imported_enodes":graph.total_number_of_nodes(),"source_xor_occurrences":actual_xor,"source_tt3_occurrences":actual_tt3,"actual_xor_enodes":unique_xor,"actual_tt3_enodes":unique_tt3,"retained_xor_operators":unique_xor,"retained_tt3_operators":unique_tt3,"all_original_helpers_retained":helper_quota==usize::MAX,"helper_quota":helper_quota,"selected_source_helpers":helpers.len(),"actual_helpers":helper_classes.len(),"helper_node_reserve_fraction":0.1,"source_physical_witnesses":source.len(),"original_source_ands":g.node_indices().filter(|&n|matches!(aig.node_type(n),AigNode::And)).count(),"representation":if shared_majority{"Exact XOR/TT3 plus bounded exact majority reconvergence folding with XOR-propagation source fringes; all retained operands/helpers are actual cumulative enodes. No omitted functions stored as hidden classes; no regional reset; richer node unit is not expanded-AND work units."}else{"Exact pre-import XOR and unshared two-AND TT3 contraction; all retained operands/helpers count. No regional reset; richer node unit is not expanded-AND work units."}}).to_string());}
 Some((graph,roots,source))
}

fn import_prefix_failure(allowance:usize,source_upper:usize,planned:usize,admitted:usize){
 eprintln!("budget: cumulative import would exceed node allowance {allowance}; {admitted} admitted, complete input not imported");
 if let Some(p)=std::env::var_os("EGM_POOL_DIAG_PATH"){let path=std::path::Path::new(&p).with_extension("import.json");let _=std::fs::write(path,serde_json::json!({"schema_version":4,"source_planning_has_no_egraph_retirement":true,"import_complete":false,"cumulative_import_admitted_enodes":admitted,"raw_source_upper":source_upper,"planned_folded_source_upper":planned,"node_allowance":allowance,"error":"additional distinct enode rejected before admission; incomplete import is not a legal cover"}).to_string());}
}

pub(super) fn compact_node_upper(aig:&Aig)->Option<usize>{
 use crate::aig_graph::AigNode;use petgraph::visit::EdgeRef;use petgraph::Direction;
 let g=aig.graph();let mut live=HashSet::new();let mut stack:Vec<_>=g.node_indices().filter(|&n|matches!(aig.node_type(n),AigNode::Input(_)|AigNode::Zero|AigNode::Output(_))).collect();
 while let Some(n)=stack.pop(){if live.insert(n){stack.extend(g.edges_directed(n,Direction::Incoming).map(|e|e.source()));}}
 let output_not:HashSet<_>=g.node_indices().filter(|&n|matches!(aig.node_type(n),AigNode::Output(_))).flat_map(|n|g.edges_directed(n,Direction::Incoming)).filter(|e|*e.weight()).map(|e|e.source()).collect();
 Some(live.iter().filter(|&&n|!matches!(aig.node_type(n),AigNode::Output(_))).count()+output_not.len())
}
