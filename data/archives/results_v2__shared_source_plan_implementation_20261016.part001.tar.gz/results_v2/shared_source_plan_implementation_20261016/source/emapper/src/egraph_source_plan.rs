//! Plan source cuts before constructing an egraph. Never retire admitted egraph state.
use std::collections::{BTreeSet,HashMap};
#[cfg(test)] fn reachable(parents:&[Vec<usize>],roots:&[usize])->usize {let mut todo=roots.to_vec();let mut seen=BTreeSet::new();while let Some(n)=todo.pop(){if seen.insert(n){todo.extend(&parents[n]);}}seen.len()}
fn unique(v:&[usize])->Vec<usize>{v.iter().copied().collect::<BTreeSet<_>>().into_iter().collect()}
fn transaction(parents:&[Vec<usize>],refs:&[usize],old:&[usize],new:&[usize])->(isize,HashMap<usize,usize>){
 let mut changes=HashMap::new();let mut delta=0isize;
 for (inputs,add) in [(new,true),(old,false)] {
  let mut todo:Vec<_>=unique(inputs);
  while let Some(n)=todo.pop(){let before=changes.get(&n).copied().unwrap_or(refs[n]);
   let after=if add{before+1}else{before.checked_sub(1).expect("source-plan reference underflow")};changes.insert(n,after);
   if add&&before==0{delta+=1;todo.extend(&parents[n]);}
   if !add&&after==0{delta-=1;todo.extend(&parents[n]);}
  }
 }
 (delta,changes)
}
pub(crate) fn select(parents:&[Vec<usize>],roots:&[usize],choices:&[Vec<Vec<usize>>],rank:&[usize],order:&[usize])->(Vec<Option<usize>>,usize,usize){
 let mut parents:Vec<_>=parents.iter().map(|p|unique(p)).collect();let mut refs=vec![0usize;parents.len()];let mut before=0usize;
 for &root in roots {let mut todo=vec![root];while let Some(n)=todo.pop(){refs[n]+=1;if refs[n]==1{before+=1;todo.extend(&parents[n]);}}}
 let mut count=before;let mut selected=vec![None;parents.len()];
 for &n in order {if refs[n]==0||choices[n].is_empty(){continue}
  let old_rank=parents[n].iter().map(|&p|rank[p]).sum::<usize>();let mut best_key=(0isize,old_rank,parents[n].clone());let mut winner=None;
  for (i,inputs) in choices[n].iter().enumerate(){let inputs=unique(inputs);
   if inputs==parents[n]||inputs.iter().any(|&p|rank[p]>=rank[n]){continue}
   let (delta,changes)=transaction(&parents,&refs,&parents[n],&inputs);if delta>0{continue}
   let key=(delta,inputs.iter().map(|&p|rank[p]).sum::<usize>(),inputs.clone());
   if key<best_key{best_key=key;winner=Some((i,inputs,changes));}
  }
  if let Some((i,inputs,changes))=winner{count=(count as isize+best_key.0) as usize;for(p,r)in changes{refs[p]=r;}parents[n]=inputs;selected[n]=Some(i);}
 }
 debug_assert_eq!(refs.iter().filter(|&&r|r>0).count(),count);debug_assert!(count<=before);(selected,before,count)
}

#[cfg(test)] mod tests {
 use super::*;
 #[test] fn egraph_source_plan_preserves_shared_refs_and_joint_reclamation(){
  let parents=vec![vec![],vec![],vec![0,1],vec![0,1],vec![0,1],vec![0,1],vec![2,3],vec![2,3]];let roots=vec![0,1,6,7];let rank:Vec<_>=(0..8).collect();let order:Vec<_>=(0..8).rev().collect();
  let mut choices=vec![vec![];8];choices[6]=vec![vec![4,5]];let (s,b,a)=select(&parents,&roots,&choices,&rank,&order);assert_eq!((b,a),(6,6));assert_eq!(s[6],None,"do not abandon live shared dependencies and add two private functions");
  choices[6]=vec![vec![0,1]];choices[7]=vec![vec![0,1]];let (s,b,a)=select(&parents,&roots,&choices,&rank,&order);assert_eq!((b,a),(6,4),"zero-cost shared-ref transitions must enable joint reclamation without an intermediate node-count increase");let mut actual=parents.clone();for (n,i) in s.iter().enumerate(){if let Some(i)=i{actual[n]=choices[n][*i].clone();}}assert_eq!(reachable(&actual,&roots),a);
 }
 #[test] fn egraph_source_plan_matches_independent_reachability_on_reconvergent_dags(){
  let mut state=0x12345678u64;for _ in 0..128 {let mut next=|n|{state=state.wrapping_mul(6364136223846793005).wrapping_add(1);(state as usize)%n};let n=24;let mut parents=vec![vec![];n];let mut choices=vec![vec![];n];
   for i in 3..n {parents[i]=vec![next(i),next(i)];for _ in 0..4{choices[i].push(vec![next(i),next(i),next(i)]);}}
   let roots=vec![0,1,2,n-1,n-2];let rank:Vec<_>=(0..n).collect();let order:Vec<_>=(0..n).rev().collect();let (selected,before,after)=select(&parents,&roots,&choices,&rank,&order);assert_eq!(before,reachable(&parents,&roots));let mut actual=parents.clone();for (i,c) in selected.iter().enumerate(){if let Some(c)=c{actual[i]=choices[i][*c].clone();}}assert_eq!(after,reachable(&actual,&roots));assert!(after<=before);
  }
 }
}
