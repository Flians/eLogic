module mapped(G1, G3, G2, G4, G5, G16, G17);
  input G1;
  input G3;
  input G2;
  input G4;
  input G5;
  output G16;
  output G17;
  wire __egm_s17;
  wire __egm_s20;
  wire __egm_s30;
  wire __egm_s42;
  AO21x1_ASAP7_75t_R __egm_g37 (.A1(G5), .A2(__egm_s17), .B(__egm_s20), .Y(__egm_s30));
  NAND2x1_ASAP7_75t_R __egm_g88 (.A(G4), .B(G3), .Y(__egm_s17));
  AND2x2_ASAP7_75t_R __egm_g92 (.B(G2), .A(__egm_s17), .Y(__egm_s20));
  AO21x1_ASAP7_75t_R __egm_g176 (.A1(G3), .B(__egm_s20), .A2(G1), .Y(__egm_s42));
  assign G16 = __egm_s42;
  assign G17 = __egm_s30;
endmodule
