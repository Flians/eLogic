// Benchmark "/home/flynn/workplace/MIGBalance/results_v2/fixed_4in_eqmap_delay_20261012/c880/lut_stage_amap/stage" written by ABC on Mon Oct 12 15:06:11 2026

module \/home/flynn/workplace/MIGBalance/results_v2/fixed_4in_eqmap_delay_20261012/c880/lut_stage_amap/stage  ( 
    G1, G10, G11, G12, G13, G14, G15, G16, G17, G18, G19, G2, G20, G21,
    G22, G23, G24, G25, G26, G27, G28, G29, G3, G30, G31, G32, G33, G34,
    G35, G36, G37, G38, G39, G4, G40, G41, G42, G43, G44, G45, G46, G47,
    G48, G49, G5, G50, G51, G52, G53, G54, G55, G56, G57, G58, G59, G6,
    G60, G7, G8, G9,
    G855, G856, G857, G858, G859, G860, G861, G862, G863, G864, G865, G866,
    G867, G868, G869, G870, G871, G872, G873, G874, G875, G876, G877, G878,
    G879, G880  );
  input  G1, G10, G11, G12, G13, G14, G15, G16, G17, G18, G19, G2, G20,
    G21, G22, G23, G24, G25, G26, G27, G28, G29, G3, G30, G31, G32, G33,
    G34, G35, G36, G37, G38, G39, G4, G40, G41, G42, G43, G44, G45, G46,
    G47, G48, G49, G5, G50, G51, G52, G53, G54, G55, G56, G57, G58, G59,
    G6, G60, G7, G8, G9;
  output G855, G856, G857, G858, G859, G860, G861, G862, G863, G864, G865,
    G866, G867, G868, G869, G870, G871, G872, G873, G874, G875, G876, G877,
    G878, G879, G880;
  wire new_n87_, new_n88_, new_n89_, new_n90_, new_n91_, new_n92_, new_n93_,
    new_n94_, new_n95_, new_n96_, new_n97_, new_n98_, new_n99_, new_n100_,
    new_n101_, new_n102_, new_n103_, new_n104_, new_n105_, new_n106_,
    new_n107_, new_n108_, new_n109_, new_n110_, new_n111_, new_n112_,
    new_n113_, new_n114_, new_n115_, new_n116_, new_n117_, new_n118_,
    new_n119_, new_n120_, new_n121_, new_n122_, new_n123_, new_n124_,
    new_n125_, new_n126_, new_n127_, new_n128_, new_n129_, new_n130_,
    new_n131_, new_n132_, new_n133_, new_n134_, new_n135_, new_n136_,
    new_n137_, new_n138_, new_n139_, new_n140_, new_n141_, new_n142_,
    new_n144_, new_n148_, new_n149_, new_n151_, new_n156_, new_n158_,
    new_n160_, new_n162_, new_n163_, new_n164_, new_n165_, new_n166_,
    new_n168_, new_n169_, new_n170_, new_n173_, new_n174_, new_n175_,
    new_n176_, new_n177_, new_n178_, new_n179_, new_n180_, new_n181_,
    new_n182_, new_n183_, new_n184_, new_n185_, new_n186_, new_n187_,
    new_n188_, new_n189_, new_n191_, new_n192_, new_n193_, new_n194_,
    new_n195_, new_n196_, new_n197_, new_n198_, new_n199_, new_n200_,
    new_n201_, new_n202_, new_n203_, new_n204_, new_n205_, new_n206_,
    new_n207_, new_n209_, new_n210_, new_n211_, new_n212_, new_n213_,
    new_n214_, new_n215_, new_n216_, new_n217_, new_n218_, new_n219_,
    new_n220_, new_n221_, new_n222_, new_n223_, new_n224_, new_n225_,
    new_n226_, new_n227_, new_n228_, new_n229_, new_n230_, new_n231_,
    new_n232_, new_n233_, new_n234_, new_n235_, new_n236_, new_n237_,
    new_n238_, new_n239_, new_n240_, new_n241_, new_n242_, new_n243_,
    new_n244_, new_n245_, new_n246_, new_n247_, new_n248_, new_n249_,
    new_n251_, new_n252_, new_n253_, new_n254_, new_n255_, new_n256_,
    new_n257_, new_n258_, new_n259_, new_n260_, new_n261_, new_n262_,
    new_n263_, new_n264_, new_n265_, new_n266_, new_n267_, new_n268_,
    new_n269_, new_n270_, new_n271_, new_n272_, new_n273_, new_n274_,
    new_n275_, new_n276_, new_n277_, new_n278_, new_n279_, new_n280_,
    new_n281_, new_n282_, new_n283_, new_n284_, new_n285_, new_n286_,
    new_n287_, new_n288_, new_n289_, new_n290_, new_n291_, new_n292_,
    new_n293_, new_n294_, new_n295_, new_n296_, new_n297_, new_n298_,
    new_n299_, new_n301_, new_n302_, new_n303_, new_n304_, new_n305_,
    new_n306_, new_n307_, new_n308_, new_n309_, new_n310_, new_n311_,
    new_n312_, new_n313_, new_n314_, new_n315_, new_n316_, new_n317_,
    new_n318_, new_n319_, new_n321_, new_n322_, new_n323_, new_n324_,
    new_n325_, new_n326_, new_n327_, new_n328_, new_n329_, new_n330_,
    new_n331_, new_n332_, new_n333_, new_n334_, new_n336_, new_n337_,
    new_n338_, new_n339_, new_n340_, new_n341_, new_n342_, new_n343_,
    new_n344_, new_n345_, new_n346_, new_n347_, new_n348_, new_n349_,
    new_n350_, new_n351_, new_n352_, new_n353_, new_n354_, new_n355_,
    new_n356_, new_n357_, new_n358_, new_n359_, new_n360_, new_n361_,
    new_n362_, new_n363_, new_n364_, new_n365_, new_n366_, new_n367_,
    new_n368_, new_n369_, new_n370_, new_n371_, new_n372_, new_n373_,
    new_n374_, new_n375_, new_n376_, new_n377_, new_n378_, new_n379_,
    new_n380_, new_n381_, new_n382_, new_n383_, new_n384_, new_n385_,
    new_n386_, new_n387_, new_n388_, new_n389_, new_n390_, new_n391_,
    new_n392_, new_n393_, new_n394_, new_n395_, new_n396_, new_n397_,
    new_n398_, new_n399_, new_n400_, new_n401_, new_n402_, new_n403_,
    new_n404_, new_n406_, new_n407_, new_n408_, new_n409_, new_n410_,
    new_n411_, new_n412_, new_n413_, new_n414_, new_n415_, new_n416_,
    new_n417_, new_n418_, new_n419_, new_n421_, new_n422_, new_n423_,
    new_n424_, new_n425_, new_n426_, new_n427_, new_n428_, new_n429_,
    new_n430_, new_n431_, new_n432_, new_n433_, new_n434_, new_n435_,
    new_n436_, new_n437_, new_n438_, new_n439_, new_n441_, new_n442_,
    new_n443_, new_n444_, new_n445_, new_n446_, new_n447_, new_n448_,
    new_n449_, new_n450_, new_n452_, new_n453_, new_n454_, new_n455_,
    new_n456_, new_n457_, new_n458_, new_n459_, new_n460_, new_n461_,
    new_n462_, new_n463_, new_n464_, new_n465_, new_n466_, new_n467_;
  INVx1_ASAP7_75t_R    g000(.A(G1), .Y(new_n87_));
  INVx1_ASAP7_75t_R    g001(.A(G10), .Y(new_n88_));
  INVx1_ASAP7_75t_R    g002(.A(G11), .Y(new_n89_));
  INVx1_ASAP7_75t_R    g003(.A(G12), .Y(new_n90_));
  INVx1_ASAP7_75t_R    g004(.A(G15), .Y(new_n91_));
  INVx1_ASAP7_75t_R    g005(.A(G16), .Y(new_n92_));
  INVx1_ASAP7_75t_R    g006(.A(G17), .Y(new_n93_));
  INVx1_ASAP7_75t_R    g007(.A(G18), .Y(new_n94_));
  INVx1_ASAP7_75t_R    g008(.A(G2), .Y(new_n95_));
  INVx1_ASAP7_75t_R    g009(.A(G22), .Y(new_n96_));
  INVx1_ASAP7_75t_R    g010(.A(G23), .Y(new_n97_));
  INVx1_ASAP7_75t_R    g011(.A(G24), .Y(new_n98_));
  INVx1_ASAP7_75t_R    g012(.A(G25), .Y(new_n99_));
  INVx1_ASAP7_75t_R    g013(.A(G26), .Y(new_n100_));
  INVx1_ASAP7_75t_R    g014(.A(G27), .Y(new_n101_));
  INVx1_ASAP7_75t_R    g015(.A(G28), .Y(new_n102_));
  INVx1_ASAP7_75t_R    g016(.A(G29), .Y(new_n103_));
  INVx1_ASAP7_75t_R    g017(.A(G3), .Y(new_n104_));
  INVx1_ASAP7_75t_R    g018(.A(G30), .Y(new_n105_));
  INVx1_ASAP7_75t_R    g019(.A(G31), .Y(new_n106_));
  INVx1_ASAP7_75t_R    g020(.A(G32), .Y(new_n107_));
  INVx1_ASAP7_75t_R    g021(.A(G33), .Y(new_n108_));
  INVx1_ASAP7_75t_R    g022(.A(G34), .Y(new_n109_));
  INVx1_ASAP7_75t_R    g023(.A(G35), .Y(new_n110_));
  INVx1_ASAP7_75t_R    g024(.A(G36), .Y(new_n111_));
  INVx1_ASAP7_75t_R    g025(.A(G37), .Y(new_n112_));
  INVx1_ASAP7_75t_R    g026(.A(G38), .Y(new_n113_));
  INVx1_ASAP7_75t_R    g027(.A(G39), .Y(new_n114_));
  INVx1_ASAP7_75t_R    g028(.A(G4), .Y(new_n115_));
  INVx1_ASAP7_75t_R    g029(.A(G40), .Y(new_n116_));
  INVx1_ASAP7_75t_R    g030(.A(G41), .Y(new_n117_));
  INVx1_ASAP7_75t_R    g031(.A(G42), .Y(new_n118_));
  INVx1_ASAP7_75t_R    g032(.A(G43), .Y(new_n119_));
  INVx1_ASAP7_75t_R    g033(.A(G44), .Y(new_n120_));
  INVx1_ASAP7_75t_R    g034(.A(G45), .Y(new_n121_));
  INVx1_ASAP7_75t_R    g035(.A(G46), .Y(new_n122_));
  INVx1_ASAP7_75t_R    g036(.A(G47), .Y(new_n123_));
  INVx1_ASAP7_75t_R    g037(.A(G48), .Y(new_n124_));
  INVx1_ASAP7_75t_R    g038(.A(G49), .Y(new_n125_));
  INVx1_ASAP7_75t_R    g039(.A(G5), .Y(new_n126_));
  INVx1_ASAP7_75t_R    g040(.A(G50), .Y(new_n127_));
  INVx1_ASAP7_75t_R    g041(.A(G51), .Y(new_n128_));
  INVx1_ASAP7_75t_R    g042(.A(G52), .Y(new_n129_));
  INVx1_ASAP7_75t_R    g043(.A(G53), .Y(new_n130_));
  INVx1_ASAP7_75t_R    g044(.A(G54), .Y(new_n131_));
  INVx1_ASAP7_75t_R    g045(.A(G55), .Y(new_n132_));
  INVx1_ASAP7_75t_R    g046(.A(G56), .Y(new_n133_));
  INVx1_ASAP7_75t_R    g047(.A(G57), .Y(new_n134_));
  INVx1_ASAP7_75t_R    g048(.A(G58), .Y(new_n135_));
  INVx1_ASAP7_75t_R    g049(.A(G59), .Y(new_n136_));
  INVx1_ASAP7_75t_R    g050(.A(G6), .Y(new_n137_));
  INVx1_ASAP7_75t_R    g051(.A(G60), .Y(new_n138_));
  INVx1_ASAP7_75t_R    g052(.A(G7), .Y(new_n139_));
  INVx1_ASAP7_75t_R    g053(.A(G8), .Y(new_n140_));
  INVx1_ASAP7_75t_R    g054(.A(G9), .Y(new_n141_));
  AO21x1_ASAP7_75t_R   g055(.A1(G6), .A2(new_n140_), .B(new_n137_), .Y(new_n142_));
  AO21x1_ASAP7_75t_R   g056(.A1(G16), .A2(new_n142_), .B(new_n92_), .Y(G855));
  AO21x1_ASAP7_75t_R   g057(.A1(new_n93_), .A2(G6), .B(new_n137_), .Y(new_n144_));
  AO21x1_ASAP7_75t_R   g058(.A1(G7), .A2(new_n144_), .B(new_n139_), .Y(G856));
  AO21x1_ASAP7_75t_R   g059(.A1(G7), .A2(new_n142_), .B(new_n139_), .Y(G857));
  OAI21x1_ASAP7_75t_R  g060(.A1(new_n94_), .A2(G19), .B(G18), .Y(G858));
  AO21x1_ASAP7_75t_R   g061(.A1(G1), .A2(new_n115_), .B(new_n87_), .Y(new_n148_));
  AO21x1_ASAP7_75t_R   g062(.A1(G2), .A2(new_n148_), .B(new_n95_), .Y(new_n149_));
  AO21x1_ASAP7_75t_R   g063(.A1(G3), .A2(new_n149_), .B(new_n104_), .Y(G859));
  AND3x1_ASAP7_75t_R   g064(.A(G4), .B(G857), .C(G1), .Y(new_n151_));
  AND3x1_ASAP7_75t_R   g065(.A(G3), .B(new_n151_), .C(G5), .Y(G860));
  AND3x1_ASAP7_75t_R   g066(.A(G11), .B(G17), .C(G16), .Y(G861));
  AND3x1_ASAP7_75t_R   g067(.A(G11), .B(G17), .C(G7), .Y(G862));
  AND3x1_ASAP7_75t_R   g068(.A(G11), .B(G8), .C(G7), .Y(G863));
  NOR2x1_ASAP7_75t_R   g069(.A(G20), .B(G21), .Y(new_n156_));
  AO21x1_ASAP7_75t_R   g070(.A1(G23), .A2(new_n156_), .B(new_n97_), .Y(G864));
  NOR2x1_ASAP7_75t_R   g071(.A(new_n115_), .B(G857), .Y(new_n158_));
  AND4x2_ASAP7_75t_R   g072(.A(G1), .B(new_n158_), .C(G3), .D(G5), .Y(G865));
  AO21x1_ASAP7_75t_R   g073(.A1(G1), .A2(new_n141_), .B(new_n87_), .Y(new_n160_));
  AO21x1_ASAP7_75t_R   g074(.A1(G5), .A2(new_n160_), .B(new_n126_), .Y(G866));
  INVx1_ASAP7_75t_R    g075(.A(G866), .Y(new_n162_));
  AO21x1_ASAP7_75t_R   g076(.A1(new_n87_), .A2(G10), .B(new_n88_), .Y(new_n163_));
  AO21x1_ASAP7_75t_R   g077(.A1(G2), .A2(new_n163_), .B(new_n95_), .Y(new_n164_));
  AO21x1_ASAP7_75t_R   g078(.A1(G6), .A2(new_n164_), .B(new_n137_), .Y(new_n165_));
  AO21x1_ASAP7_75t_R   g079(.A1(G3), .A2(new_n165_), .B(new_n104_), .Y(new_n166_));
  AO21x1_ASAP7_75t_R   g080(.A1(G12), .A2(new_n166_), .B(new_n90_), .Y(G867));
  OR3x1_ASAP7_75t_R    g081(.A(new_n87_), .B(new_n89_), .C(new_n88_), .Y(new_n168_));
  OR4x2_ASAP7_75t_R    g082(.A(new_n95_), .B(new_n168_), .C(new_n104_), .D(new_n90_), .Y(new_n169_));
  INVx1_ASAP7_75t_R    g083(.A(new_n169_), .Y(new_n170_));
  AO21x1_ASAP7_75t_R   g084(.A1(G15), .A2(new_n169_), .B(new_n91_), .Y(G868));
  AO21x1_ASAP7_75t_R   g085(.A1(G22), .A2(new_n156_), .B(new_n96_), .Y(G869));
  AO22x1_ASAP7_75t_R   g086(.A1(new_n100_), .A2(G27), .B1(G26), .B2(new_n101_), .Y(new_n173_));
  AO22x1_ASAP7_75t_R   g087(.A1(G26), .A2(G27), .B1(new_n100_), .B2(new_n101_), .Y(new_n174_));
  AO22x1_ASAP7_75t_R   g088(.A1(G31), .A2(new_n173_), .B1(new_n106_), .B2(new_n174_), .Y(new_n175_));
  AO22x1_ASAP7_75t_R   g089(.A1(G31), .A2(new_n174_), .B1(new_n106_), .B2(new_n173_), .Y(new_n176_));
  AO22x1_ASAP7_75t_R   g090(.A1(G30), .A2(new_n175_), .B1(new_n105_), .B2(new_n176_), .Y(new_n177_));
  INVx1_ASAP7_75t_R    g091(.A(new_n177_), .Y(new_n178_));
  AO22x1_ASAP7_75t_R   g092(.A1(G28), .A2(new_n178_), .B1(new_n102_), .B2(new_n177_), .Y(new_n179_));
  AO22x1_ASAP7_75t_R   g093(.A1(G28), .A2(new_n177_), .B1(new_n102_), .B2(new_n178_), .Y(new_n180_));
  AO22x1_ASAP7_75t_R   g094(.A1(G29), .A2(new_n179_), .B1(new_n103_), .B2(new_n180_), .Y(new_n181_));
  AO22x1_ASAP7_75t_R   g095(.A1(G29), .A2(new_n180_), .B1(new_n103_), .B2(new_n179_), .Y(new_n182_));
  AO22x1_ASAP7_75t_R   g096(.A1(G33), .A2(new_n181_), .B1(new_n108_), .B2(new_n182_), .Y(new_n183_));
  XNOR2x2_ASAP7_75t_R  g097(.A(G32), .B(new_n183_), .Y(new_n184_));
  XNOR2x2_ASAP7_75t_R  g098(.A(new_n107_), .B(new_n183_), .Y(new_n185_));
  AO22x1_ASAP7_75t_R   g099(.A1(G24), .A2(new_n184_), .B1(new_n98_), .B2(new_n185_), .Y(new_n186_));
  NAND2x1_ASAP7_75t_R  g100(.A(G25), .B(new_n186_), .Y(new_n187_));
  AO22x1_ASAP7_75t_R   g101(.A1(G24), .A2(new_n185_), .B1(new_n98_), .B2(new_n184_), .Y(new_n188_));
  NAND2x1_ASAP7_75t_R  g102(.A(new_n99_), .B(new_n188_), .Y(new_n189_));
  NAND2x1_ASAP7_75t_R  g103(.A(new_n187_), .B(new_n189_), .Y(G870));
  AO22x1_ASAP7_75t_R   g104(.A1(G47), .A2(G48), .B1(new_n123_), .B2(new_n124_), .Y(new_n191_));
  AO22x1_ASAP7_75t_R   g105(.A1(G47), .A2(new_n124_), .B1(new_n123_), .B2(G48), .Y(new_n192_));
  AO22x1_ASAP7_75t_R   g106(.A1(G46), .A2(new_n191_), .B1(new_n122_), .B2(new_n192_), .Y(new_n193_));
  AO22x1_ASAP7_75t_R   g107(.A1(G46), .A2(new_n192_), .B1(new_n122_), .B2(new_n191_), .Y(new_n194_));
  AO22x1_ASAP7_75t_R   g108(.A1(G49), .A2(new_n193_), .B1(new_n125_), .B2(new_n194_), .Y(new_n195_));
  AO22x1_ASAP7_75t_R   g109(.A1(G49), .A2(new_n194_), .B1(new_n125_), .B2(new_n193_), .Y(new_n196_));
  AO22x1_ASAP7_75t_R   g110(.A1(G43), .A2(new_n195_), .B1(new_n119_), .B2(new_n196_), .Y(new_n197_));
  AO22x1_ASAP7_75t_R   g111(.A1(G43), .A2(new_n196_), .B1(new_n119_), .B2(new_n195_), .Y(new_n198_));
  AO22x1_ASAP7_75t_R   g112(.A1(G44), .A2(new_n197_), .B1(new_n120_), .B2(new_n198_), .Y(new_n199_));
  XNOR2x2_ASAP7_75t_R  g113(.A(G41), .B(new_n199_), .Y(new_n200_));
  XNOR2x2_ASAP7_75t_R  g114(.A(new_n117_), .B(new_n199_), .Y(new_n201_));
  AO22x1_ASAP7_75t_R   g115(.A1(G42), .A2(new_n200_), .B1(new_n118_), .B2(new_n201_), .Y(new_n202_));
  AO22x1_ASAP7_75t_R   g116(.A1(G42), .A2(new_n201_), .B1(new_n118_), .B2(new_n200_), .Y(new_n203_));
  AO22x1_ASAP7_75t_R   g117(.A1(G32), .A2(new_n202_), .B1(new_n107_), .B2(new_n203_), .Y(new_n204_));
  NAND2x1_ASAP7_75t_R  g118(.A(G45), .B(new_n204_), .Y(new_n205_));
  AO22x1_ASAP7_75t_R   g119(.A1(G32), .A2(new_n203_), .B1(new_n107_), .B2(new_n202_), .Y(new_n206_));
  NAND2x1_ASAP7_75t_R  g120(.A(new_n121_), .B(new_n206_), .Y(new_n207_));
  NAND2x1_ASAP7_75t_R  g121(.A(new_n205_), .B(new_n207_), .Y(G871));
  AO21x1_ASAP7_75t_R   g122(.A1(G30), .A2(new_n127_), .B(new_n105_), .Y(new_n209_));
  AND3x1_ASAP7_75t_R   g123(.A(new_n136_), .B(new_n209_), .C(G55), .Y(new_n210_));
  AOI21x1_ASAP7_75t_R  g124(.A1(new_n132_), .A2(new_n209_), .B(new_n210_), .Y(new_n211_));
  AO21x1_ASAP7_75t_R   g125(.A1(new_n89_), .A2(G40), .B(new_n116_), .Y(new_n212_));
  AO21x1_ASAP7_75t_R   g126(.A1(G1), .A2(new_n212_), .B(new_n87_), .Y(new_n213_));
  AO22x1_ASAP7_75t_R   g127(.A1(new_n87_), .A2(G866), .B1(new_n162_), .B2(new_n213_), .Y(new_n214_));
  AOI22x1_ASAP7_75t_R  g128(.A1(G4), .A2(new_n214_), .B1(new_n87_), .B2(new_n115_), .Y(new_n215_));
  NOR2x1_ASAP7_75t_R   g129(.A(new_n114_), .B(new_n215_), .Y(new_n216_));
  INVx1_ASAP7_75t_R    g130(.A(new_n216_), .Y(new_n217_));
  OR4x2_ASAP7_75t_R    g131(.A(G60), .B(G866), .C(new_n88_), .D(new_n93_), .Y(new_n218_));
  OR3x1_ASAP7_75t_R    g132(.A(new_n137_), .B(new_n218_), .C(new_n92_), .Y(new_n219_));
  INVx1_ASAP7_75t_R    g133(.A(new_n219_), .Y(new_n220_));
  AO21x1_ASAP7_75t_R   g134(.A1(G11), .A2(new_n92_), .B(new_n89_), .Y(new_n221_));
  AOI21x1_ASAP7_75t_R  g135(.A1(G8), .A2(new_n221_), .B(new_n140_), .Y(new_n222_));
  OR3x1_ASAP7_75t_R    g136(.A(new_n141_), .B(new_n222_), .C(new_n115_), .Y(new_n223_));
  AO21x1_ASAP7_75t_R   g137(.A1(G1), .A2(new_n223_), .B(new_n87_), .Y(new_n224_));
  AO21x1_ASAP7_75t_R   g138(.A1(G2), .A2(new_n224_), .B(new_n95_), .Y(new_n225_));
  AOI22x1_ASAP7_75t_R  g139(.A1(G4), .A2(new_n140_), .B1(new_n115_), .B2(G8), .Y(new_n226_));
  OR3x1_ASAP7_75t_R    g140(.A(new_n116_), .B(new_n226_), .C(new_n89_), .Y(new_n227_));
  AND3x1_ASAP7_75t_R   g141(.A(new_n225_), .B(new_n227_), .C(new_n162_), .Y(new_n228_));
  AO21x1_ASAP7_75t_R   g142(.A1(G866), .A2(new_n225_), .B(new_n228_), .Y(new_n229_));
  INVx1_ASAP7_75t_R    g143(.A(new_n229_), .Y(new_n230_));
  OA21x2_ASAP7_75t_R   g144(.A1(G31), .A2(new_n229_), .B(new_n230_), .Y(new_n231_));
  OR3x1_ASAP7_75t_R    g145(.A(new_n220_), .B(new_n231_), .C(new_n216_), .Y(new_n232_));
  INVx1_ASAP7_75t_R    g146(.A(new_n232_), .Y(new_n233_));
  AND4x2_ASAP7_75t_R   g147(.A(G13), .B(new_n170_), .C(G8), .D(G14), .Y(new_n234_));
  INVx1_ASAP7_75t_R    g148(.A(new_n234_), .Y(new_n235_));
  NOR2x1_ASAP7_75t_R   g149(.A(G52), .B(new_n234_), .Y(new_n236_));
  NOR2x1_ASAP7_75t_R   g150(.A(G53), .B(new_n234_), .Y(new_n237_));
  AO22x1_ASAP7_75t_R   g151(.A1(new_n233_), .A2(new_n236_), .B1(new_n232_), .B2(new_n237_), .Y(new_n238_));
  AO21x1_ASAP7_75t_R   g152(.A1(new_n129_), .A2(new_n232_), .B(new_n233_), .Y(new_n239_));
  AOI22x1_ASAP7_75t_R  g153(.A1(G48), .A2(new_n238_), .B1(new_n124_), .B2(new_n239_), .Y(new_n240_));
  AO21x1_ASAP7_75t_R   g154(.A1(new_n124_), .A2(new_n128_), .B(G48), .Y(new_n241_));
  AO21x1_ASAP7_75t_R   g155(.A1(G48), .A2(new_n128_), .B(new_n124_), .Y(new_n242_));
  AO22x1_ASAP7_75t_R   g156(.A1(G58), .A2(new_n241_), .B1(new_n135_), .B2(new_n242_), .Y(new_n243_));
  NOR2x1_ASAP7_75t_R   g157(.A(G51), .B(G54), .Y(new_n244_));
  AO22x1_ASAP7_75t_R   g158(.A1(G48), .A2(new_n244_), .B1(new_n124_), .B2(new_n131_), .Y(new_n245_));
  AO22x1_ASAP7_75t_R   g159(.A1(G48), .A2(new_n131_), .B1(new_n124_), .B2(new_n244_), .Y(new_n246_));
  AO22x1_ASAP7_75t_R   g160(.A1(G58), .A2(new_n245_), .B1(new_n135_), .B2(new_n246_), .Y(new_n247_));
  AOI22x1_ASAP7_75t_R  g161(.A1(new_n233_), .A2(new_n243_), .B1(new_n232_), .B2(new_n247_), .Y(new_n248_));
  OR3x1_ASAP7_75t_R    g162(.A(new_n211_), .B(new_n240_), .C(new_n248_), .Y(new_n249_));
  INVx1_ASAP7_75t_R    g163(.A(new_n249_), .Y(G872));
  OR3x1_ASAP7_75t_R    g164(.A(new_n89_), .B(new_n116_), .C(new_n115_), .Y(new_n251_));
  AO21x1_ASAP7_75t_R   g165(.A1(G4), .A2(new_n251_), .B(G866), .Y(new_n252_));
  AO21x1_ASAP7_75t_R   g166(.A1(new_n162_), .A2(new_n252_), .B(new_n87_), .Y(new_n253_));
  INVx1_ASAP7_75t_R    g167(.A(new_n253_), .Y(new_n254_));
  AO21x1_ASAP7_75t_R   g168(.A1(G28), .A2(new_n229_), .B(new_n102_), .Y(new_n255_));
  AND2x2_ASAP7_75t_R   g169(.A(new_n110_), .B(new_n255_), .Y(new_n256_));
  AOI22x1_ASAP7_75t_R  g170(.A1(new_n254_), .A2(new_n255_), .B1(new_n253_), .B2(new_n256_), .Y(new_n257_));
  NOR2x1_ASAP7_75t_R   g171(.A(new_n220_), .B(new_n257_), .Y(new_n258_));
  INVx1_ASAP7_75t_R    g172(.A(new_n258_), .Y(new_n259_));
  AND3x1_ASAP7_75t_R   g173(.A(new_n121_), .B(new_n258_), .C(new_n234_), .Y(new_n260_));
  AO21x1_ASAP7_75t_R   g174(.A1(new_n235_), .A2(new_n258_), .B(new_n260_), .Y(new_n261_));
  AO21x1_ASAP7_75t_R   g175(.A1(new_n130_), .A2(new_n259_), .B(new_n258_), .Y(new_n262_));
  AO21x1_ASAP7_75t_R   g176(.A1(G45), .A2(new_n262_), .B(new_n121_), .Y(new_n263_));
  AO22x1_ASAP7_75t_R   g177(.A1(new_n121_), .A2(new_n234_), .B1(new_n235_), .B2(new_n263_), .Y(new_n264_));
  AO22x1_ASAP7_75t_R   g178(.A1(G54), .A2(new_n261_), .B1(new_n131_), .B2(new_n264_), .Y(new_n265_));
  AO21x1_ASAP7_75t_R   g179(.A1(G48), .A2(new_n135_), .B(G58), .Y(new_n266_));
  NOR2x1_ASAP7_75t_R   g180(.A(new_n106_), .B(new_n229_), .Y(new_n267_));
  AO21x1_ASAP7_75t_R   g181(.A1(new_n124_), .A2(new_n267_), .B(G48), .Y(new_n268_));
  AND3x1_ASAP7_75t_R   g182(.A(G48), .B(new_n267_), .C(new_n135_), .Y(new_n269_));
  AO21x1_ASAP7_75t_R   g183(.A1(G58), .A2(new_n268_), .B(new_n269_), .Y(new_n270_));
  AO22x1_ASAP7_75t_R   g184(.A1(new_n216_), .A2(new_n266_), .B1(new_n217_), .B2(new_n270_), .Y(new_n271_));
  AO22x1_ASAP7_75t_R   g185(.A1(new_n220_), .A2(new_n266_), .B1(new_n219_), .B2(new_n271_), .Y(new_n272_));
  INVx1_ASAP7_75t_R    g186(.A(new_n272_), .Y(new_n273_));
  AO21x1_ASAP7_75t_R   g187(.A1(G30), .A2(new_n229_), .B(new_n105_), .Y(new_n274_));
  AND3x1_ASAP7_75t_R   g188(.A(new_n112_), .B(new_n274_), .C(new_n253_), .Y(new_n275_));
  AOI21x1_ASAP7_75t_R  g189(.A1(new_n254_), .A2(new_n274_), .B(new_n275_), .Y(new_n276_));
  NOR2x1_ASAP7_75t_R   g190(.A(new_n220_), .B(new_n276_), .Y(new_n277_));
  INVx1_ASAP7_75t_R    g191(.A(new_n277_), .Y(new_n278_));
  AO21x1_ASAP7_75t_R   g192(.A1(G29), .A2(new_n229_), .B(new_n103_), .Y(new_n279_));
  AND3x1_ASAP7_75t_R   g193(.A(new_n111_), .B(new_n279_), .C(new_n253_), .Y(new_n280_));
  AOI21x1_ASAP7_75t_R  g194(.A1(new_n254_), .A2(new_n279_), .B(new_n280_), .Y(new_n281_));
  NOR2x1_ASAP7_75t_R   g195(.A(new_n220_), .B(new_n281_), .Y(new_n282_));
  INVx1_ASAP7_75t_R    g196(.A(new_n282_), .Y(new_n283_));
  NOR2x1_ASAP7_75t_R   g197(.A(new_n278_), .B(new_n283_), .Y(new_n284_));
  AND3x1_ASAP7_75t_R   g198(.A(new_n273_), .B(new_n284_), .C(G47), .Y(new_n285_));
  AO22x1_ASAP7_75t_R   g199(.A1(new_n272_), .A2(new_n284_), .B1(new_n273_), .B2(new_n282_), .Y(new_n286_));
  AO21x1_ASAP7_75t_R   g200(.A1(new_n123_), .A2(new_n286_), .B(new_n285_), .Y(new_n287_));
  AO21x1_ASAP7_75t_R   g201(.A1(new_n278_), .A2(new_n282_), .B(new_n277_), .Y(new_n288_));
  AO22x1_ASAP7_75t_R   g202(.A1(new_n272_), .A2(new_n282_), .B1(new_n273_), .B2(new_n288_), .Y(new_n289_));
  AO21x1_ASAP7_75t_R   g203(.A1(new_n272_), .A2(new_n288_), .B(new_n273_), .Y(new_n290_));
  AO22x1_ASAP7_75t_R   g204(.A1(G47), .A2(new_n289_), .B1(new_n123_), .B2(new_n290_), .Y(new_n291_));
  AO22x1_ASAP7_75t_R   g205(.A1(G46), .A2(new_n287_), .B1(new_n122_), .B2(new_n291_), .Y(new_n292_));
  INVx1_ASAP7_75t_R    g206(.A(new_n292_), .Y(new_n293_));
  AND3x1_ASAP7_75t_R   g207(.A(new_n128_), .B(new_n129_), .C(new_n292_), .Y(new_n294_));
  AO21x1_ASAP7_75t_R   g208(.A1(new_n129_), .A2(new_n293_), .B(new_n294_), .Y(new_n295_));
  AO21x1_ASAP7_75t_R   g209(.A1(new_n128_), .A2(new_n293_), .B(new_n292_), .Y(new_n296_));
  AO22x1_ASAP7_75t_R   g210(.A1(new_n258_), .A2(new_n295_), .B1(new_n259_), .B2(new_n296_), .Y(new_n297_));
  AO22x1_ASAP7_75t_R   g211(.A1(new_n258_), .A2(new_n296_), .B1(new_n259_), .B2(new_n295_), .Y(new_n298_));
  AO22x1_ASAP7_75t_R   g212(.A1(G45), .A2(new_n297_), .B1(new_n121_), .B2(new_n298_), .Y(new_n299_));
  OA211x2_ASAP7_75t_R  g213(.A1(new_n101_), .A2(new_n127_), .B(new_n265_), .C(new_n299_), .Y(G873));
  NOR2x1_ASAP7_75t_R   g214(.A(G53), .B(G54), .Y(new_n301_));
  AND3x1_ASAP7_75t_R   g215(.A(new_n235_), .B(new_n301_), .C(new_n283_), .Y(new_n302_));
  AO21x1_ASAP7_75t_R   g216(.A1(new_n236_), .A2(new_n282_), .B(new_n302_), .Y(new_n303_));
  NOR2x1_ASAP7_75t_R   g217(.A(G52), .B(G54), .Y(new_n304_));
  AO21x1_ASAP7_75t_R   g218(.A1(new_n283_), .A2(new_n304_), .B(new_n282_), .Y(new_n305_));
  AO22x1_ASAP7_75t_R   g219(.A1(G46), .A2(new_n303_), .B1(new_n122_), .B2(new_n305_), .Y(new_n306_));
  AND3x1_ASAP7_75t_R   g220(.A(new_n273_), .B(new_n277_), .C(G47), .Y(new_n307_));
  AO21x1_ASAP7_75t_R   g221(.A1(new_n272_), .A2(new_n277_), .B(new_n273_), .Y(new_n308_));
  AO21x1_ASAP7_75t_R   g222(.A1(new_n123_), .A2(new_n308_), .B(new_n307_), .Y(new_n309_));
  AO21x1_ASAP7_75t_R   g223(.A1(new_n273_), .A2(new_n278_), .B(new_n272_), .Y(new_n310_));
  AND3x1_ASAP7_75t_R   g224(.A(new_n272_), .B(new_n278_), .C(new_n123_), .Y(new_n311_));
  AO21x1_ASAP7_75t_R   g225(.A1(G47), .A2(new_n310_), .B(new_n311_), .Y(new_n312_));
  AO22x1_ASAP7_75t_R   g226(.A1(new_n282_), .A2(new_n309_), .B1(new_n283_), .B2(new_n312_), .Y(new_n313_));
  AO22x1_ASAP7_75t_R   g227(.A1(new_n282_), .A2(new_n312_), .B1(new_n283_), .B2(new_n309_), .Y(new_n314_));
  AOI22x1_ASAP7_75t_R  g228(.A1(G46), .A2(new_n313_), .B1(new_n122_), .B2(new_n314_), .Y(new_n315_));
  AND3x1_ASAP7_75t_R   g229(.A(new_n102_), .B(new_n132_), .C(G56), .Y(new_n316_));
  AO21x1_ASAP7_75t_R   g230(.A1(new_n102_), .A2(new_n133_), .B(new_n316_), .Y(new_n317_));
  AO21x1_ASAP7_75t_R   g231(.A1(new_n132_), .A2(G56), .B(new_n133_), .Y(new_n318_));
  AO22x1_ASAP7_75t_R   g232(.A1(G50), .A2(new_n317_), .B1(new_n127_), .B2(new_n318_), .Y(new_n319_));
  OA211x2_ASAP7_75t_R  g233(.A1(new_n128_), .A2(new_n315_), .B(new_n319_), .C(new_n306_), .Y(G874));
  AO21x1_ASAP7_75t_R   g234(.A1(new_n132_), .A2(G57), .B(new_n134_), .Y(new_n321_));
  AND3x1_ASAP7_75t_R   g235(.A(new_n103_), .B(new_n321_), .C(G50), .Y(new_n322_));
  AO21x1_ASAP7_75t_R   g236(.A1(new_n127_), .A2(new_n321_), .B(new_n322_), .Y(new_n323_));
  AND3x1_ASAP7_75t_R   g237(.A(new_n235_), .B(new_n323_), .C(G47), .Y(new_n324_));
  AOI21x1_ASAP7_75t_R  g238(.A1(new_n123_), .A2(new_n323_), .B(new_n324_), .Y(new_n325_));
  AO22x1_ASAP7_75t_R   g239(.A1(new_n129_), .A2(new_n277_), .B1(new_n278_), .B2(new_n301_), .Y(new_n326_));
  AO21x1_ASAP7_75t_R   g240(.A1(new_n278_), .A2(new_n304_), .B(new_n277_), .Y(new_n327_));
  AOI22x1_ASAP7_75t_R  g241(.A1(G47), .A2(new_n326_), .B1(new_n123_), .B2(new_n327_), .Y(new_n328_));
  AO21x1_ASAP7_75t_R   g242(.A1(new_n128_), .A2(new_n278_), .B(new_n277_), .Y(new_n329_));
  AO21x1_ASAP7_75t_R   g243(.A1(new_n128_), .A2(new_n277_), .B(new_n278_), .Y(new_n330_));
  AO22x1_ASAP7_75t_R   g244(.A1(new_n272_), .A2(new_n329_), .B1(new_n273_), .B2(new_n330_), .Y(new_n331_));
  AO22x1_ASAP7_75t_R   g245(.A1(new_n272_), .A2(new_n330_), .B1(new_n273_), .B2(new_n329_), .Y(new_n332_));
  AOI22x1_ASAP7_75t_R  g246(.A1(G47), .A2(new_n331_), .B1(new_n123_), .B2(new_n332_), .Y(new_n333_));
  OR3x1_ASAP7_75t_R    g247(.A(new_n325_), .B(new_n328_), .C(new_n333_), .Y(new_n334_));
  INVx1_ASAP7_75t_R    g248(.A(new_n334_), .Y(G875));
  AND3x1_ASAP7_75t_R   g249(.A(new_n162_), .B(new_n212_), .C(G10), .Y(new_n336_));
  INVx1_ASAP7_75t_R    g250(.A(new_n336_), .Y(new_n337_));
  AO21x1_ASAP7_75t_R   g251(.A1(new_n109_), .A2(G9), .B(new_n141_), .Y(new_n338_));
  AND3x1_ASAP7_75t_R   g252(.A(new_n111_), .B(new_n338_), .C(new_n336_), .Y(new_n339_));
  AO21x1_ASAP7_75t_R   g253(.A1(new_n337_), .A2(new_n338_), .B(new_n339_), .Y(new_n340_));
  AND3x1_ASAP7_75t_R   g254(.A(new_n229_), .B(new_n340_), .C(G25), .Y(new_n341_));
  AOI21x1_ASAP7_75t_R  g255(.A1(new_n99_), .A2(new_n340_), .B(new_n341_), .Y(new_n342_));
  AND3x1_ASAP7_75t_R   g256(.A(new_n138_), .B(new_n162_), .C(G17), .Y(new_n343_));
  AND4x2_ASAP7_75t_R   g257(.A(G4), .B(new_n343_), .C(G6), .D(G16), .Y(new_n344_));
  NOR2x1_ASAP7_75t_R   g258(.A(new_n342_), .B(new_n344_), .Y(new_n345_));
  INVx1_ASAP7_75t_R    g259(.A(new_n345_), .Y(new_n346_));
  AO21x1_ASAP7_75t_R   g260(.A1(new_n95_), .A2(G34), .B(new_n109_), .Y(new_n347_));
  AND3x1_ASAP7_75t_R   g261(.A(new_n337_), .B(new_n347_), .C(G35), .Y(new_n348_));
  AOI21x1_ASAP7_75t_R  g262(.A1(new_n110_), .A2(new_n347_), .B(new_n348_), .Y(new_n349_));
  NOR2x1_ASAP7_75t_R   g263(.A(new_n344_), .B(new_n349_), .Y(new_n350_));
  INVx1_ASAP7_75t_R    g264(.A(new_n350_), .Y(new_n351_));
  AO21x1_ASAP7_75t_R   g265(.A1(new_n98_), .A2(new_n230_), .B(new_n229_), .Y(new_n352_));
  NAND2x1_ASAP7_75t_R  g266(.A(new_n350_), .B(new_n352_), .Y(new_n353_));
  INVx1_ASAP7_75t_R    g267(.A(new_n353_), .Y(new_n354_));
  NOR2x1_ASAP7_75t_R   g268(.A(new_n121_), .B(new_n258_), .Y(new_n355_));
  INVx1_ASAP7_75t_R    g269(.A(new_n355_), .Y(new_n356_));
  AO21x1_ASAP7_75t_R   g270(.A1(new_n109_), .A2(G38), .B(new_n113_), .Y(new_n357_));
  AND3x1_ASAP7_75t_R   g271(.A(new_n337_), .B(new_n357_), .C(G39), .Y(new_n358_));
  AO21x1_ASAP7_75t_R   g272(.A1(new_n114_), .A2(new_n357_), .B(new_n358_), .Y(new_n359_));
  AND3x1_ASAP7_75t_R   g273(.A(new_n229_), .B(new_n359_), .C(G27), .Y(new_n360_));
  AOI21x1_ASAP7_75t_R  g274(.A1(new_n101_), .A2(new_n359_), .B(new_n360_), .Y(new_n361_));
  NOR2x1_ASAP7_75t_R   g275(.A(new_n344_), .B(new_n361_), .Y(new_n362_));
  INVx1_ASAP7_75t_R    g276(.A(new_n362_), .Y(new_n363_));
  AO21x1_ASAP7_75t_R   g277(.A1(G34), .A2(new_n115_), .B(new_n109_), .Y(new_n364_));
  AND3x1_ASAP7_75t_R   g278(.A(new_n337_), .B(new_n364_), .C(G37), .Y(new_n365_));
  AO21x1_ASAP7_75t_R   g279(.A1(new_n112_), .A2(new_n364_), .B(new_n365_), .Y(new_n366_));
  AND3x1_ASAP7_75t_R   g280(.A(new_n229_), .B(new_n366_), .C(G26), .Y(new_n367_));
  AOI21x1_ASAP7_75t_R  g281(.A1(new_n100_), .A2(new_n366_), .B(new_n367_), .Y(new_n368_));
  NOR2x1_ASAP7_75t_R   g282(.A(new_n344_), .B(new_n368_), .Y(new_n369_));
  INVx1_ASAP7_75t_R    g283(.A(new_n369_), .Y(new_n370_));
  AO21x1_ASAP7_75t_R   g284(.A1(new_n362_), .A2(new_n370_), .B(new_n363_), .Y(new_n371_));
  AO21x1_ASAP7_75t_R   g285(.A1(new_n120_), .A2(new_n371_), .B(G44), .Y(new_n372_));
  NOR2x1_ASAP7_75t_R   g286(.A(new_n362_), .B(new_n369_), .Y(new_n373_));
  AO22x1_ASAP7_75t_R   g287(.A1(G44), .A2(new_n370_), .B1(new_n120_), .B2(new_n373_), .Y(new_n374_));
  AO22x1_ASAP7_75t_R   g288(.A1(G43), .A2(new_n372_), .B1(new_n119_), .B2(new_n374_), .Y(new_n375_));
  AND3x1_ASAP7_75t_R   g289(.A(new_n229_), .B(new_n254_), .C(G28), .Y(new_n376_));
  AO21x1_ASAP7_75t_R   g290(.A1(new_n102_), .A2(new_n254_), .B(new_n376_), .Y(new_n377_));
  AOI21x1_ASAP7_75t_R  g291(.A1(G35), .A2(new_n377_), .B(new_n256_), .Y(new_n378_));
  NOR2x1_ASAP7_75t_R   g292(.A(G45), .B(new_n378_), .Y(new_n379_));
  AO21x1_ASAP7_75t_R   g293(.A1(new_n277_), .A2(new_n283_), .B(new_n278_), .Y(new_n380_));
  AO21x1_ASAP7_75t_R   g294(.A1(new_n273_), .A2(new_n380_), .B(new_n272_), .Y(new_n381_));
  AO22x1_ASAP7_75t_R   g295(.A1(new_n272_), .A2(new_n380_), .B1(new_n273_), .B2(new_n283_), .Y(new_n382_));
  AO22x1_ASAP7_75t_R   g296(.A1(G47), .A2(new_n381_), .B1(new_n123_), .B2(new_n382_), .Y(new_n383_));
  NOR2x1_ASAP7_75t_R   g297(.A(new_n277_), .B(new_n282_), .Y(new_n384_));
  AO22x1_ASAP7_75t_R   g298(.A1(new_n272_), .A2(new_n283_), .B1(new_n273_), .B2(new_n384_), .Y(new_n385_));
  AND3x1_ASAP7_75t_R   g299(.A(new_n272_), .B(new_n384_), .C(new_n123_), .Y(new_n386_));
  AO21x1_ASAP7_75t_R   g300(.A1(G47), .A2(new_n385_), .B(new_n386_), .Y(new_n387_));
  AOI22x1_ASAP7_75t_R  g301(.A1(G46), .A2(new_n383_), .B1(new_n122_), .B2(new_n387_), .Y(new_n388_));
  AO21x1_ASAP7_75t_R   g302(.A1(new_n219_), .A2(new_n379_), .B(new_n388_), .Y(new_n389_));
  INVx1_ASAP7_75t_R    g303(.A(new_n389_), .Y(new_n390_));
  AO22x1_ASAP7_75t_R   g304(.A1(G44), .A2(new_n371_), .B1(new_n120_), .B2(new_n370_), .Y(new_n391_));
  AND3x1_ASAP7_75t_R   g305(.A(G44), .B(new_n373_), .C(new_n119_), .Y(new_n392_));
  AO21x1_ASAP7_75t_R   g306(.A1(G43), .A2(new_n391_), .B(new_n392_), .Y(new_n393_));
  AO22x1_ASAP7_75t_R   g307(.A1(new_n375_), .A2(new_n390_), .B1(new_n389_), .B2(new_n393_), .Y(new_n394_));
  AO22x1_ASAP7_75t_R   g308(.A1(new_n355_), .A2(new_n375_), .B1(new_n356_), .B2(new_n394_), .Y(new_n395_));
  INVx1_ASAP7_75t_R    g309(.A(new_n395_), .Y(new_n396_));
  AND3x1_ASAP7_75t_R   g310(.A(new_n354_), .B(new_n396_), .C(G41), .Y(new_n397_));
  AO21x1_ASAP7_75t_R   g311(.A1(new_n353_), .A2(new_n396_), .B(new_n354_), .Y(new_n398_));
  AO21x1_ASAP7_75t_R   g312(.A1(new_n117_), .A2(new_n398_), .B(new_n397_), .Y(new_n399_));
  NOR2x1_ASAP7_75t_R   g313(.A(new_n117_), .B(new_n353_), .Y(new_n400_));
  OA21x2_ASAP7_75t_R   g314(.A1(new_n117_), .A2(new_n400_), .B(new_n118_), .Y(new_n401_));
  AO21x1_ASAP7_75t_R   g315(.A1(G42), .A2(new_n399_), .B(new_n401_), .Y(new_n402_));
  AND3x1_ASAP7_75t_R   g316(.A(new_n117_), .B(new_n354_), .C(G42), .Y(new_n403_));
  AO21x1_ASAP7_75t_R   g317(.A1(new_n118_), .A2(new_n399_), .B(new_n403_), .Y(new_n404_));
  AO22x1_ASAP7_75t_R   g318(.A1(new_n345_), .A2(new_n402_), .B1(new_n346_), .B2(new_n404_), .Y(G876));
  AO22x1_ASAP7_75t_R   g319(.A1(new_n236_), .A2(new_n362_), .B1(new_n237_), .B2(new_n363_), .Y(new_n406_));
  AO21x1_ASAP7_75t_R   g320(.A1(new_n129_), .A2(new_n363_), .B(new_n362_), .Y(new_n407_));
  AO22x1_ASAP7_75t_R   g321(.A1(G44), .A2(new_n406_), .B1(new_n120_), .B2(new_n407_), .Y(new_n408_));
  AO21x1_ASAP7_75t_R   g322(.A1(G45), .A2(new_n259_), .B(new_n390_), .Y(new_n409_));
  INVx1_ASAP7_75t_R    g323(.A(new_n409_), .Y(new_n410_));
  AO21x1_ASAP7_75t_R   g324(.A1(new_n128_), .A2(new_n410_), .B(new_n409_), .Y(new_n411_));
  AND2x2_ASAP7_75t_R   g325(.A(G44), .B(new_n411_), .Y(new_n412_));
  AO21x1_ASAP7_75t_R   g326(.A1(new_n128_), .A2(new_n409_), .B(new_n410_), .Y(new_n413_));
  AND2x2_ASAP7_75t_R   g327(.A(new_n120_), .B(new_n413_), .Y(new_n414_));
  OA21x2_ASAP7_75t_R   g328(.A1(new_n412_), .A2(new_n414_), .B(new_n362_), .Y(new_n415_));
  AO22x1_ASAP7_75t_R   g329(.A1(new_n131_), .A2(new_n410_), .B1(new_n244_), .B2(new_n409_), .Y(new_n416_));
  AO22x1_ASAP7_75t_R   g330(.A1(new_n244_), .A2(new_n410_), .B1(new_n131_), .B2(new_n409_), .Y(new_n417_));
  AO22x1_ASAP7_75t_R   g331(.A1(G44), .A2(new_n416_), .B1(new_n120_), .B2(new_n417_), .Y(new_n418_));
  AO21x1_ASAP7_75t_R   g332(.A1(new_n363_), .A2(new_n418_), .B(new_n415_), .Y(new_n419_));
  OA211x2_ASAP7_75t_R  g333(.A1(new_n100_), .A2(new_n127_), .B(new_n408_), .C(new_n419_), .Y(G877));
  AO21x1_ASAP7_75t_R   g334(.A1(new_n127_), .A2(G60), .B(new_n138_), .Y(new_n421_));
  AND3x1_ASAP7_75t_R   g335(.A(new_n235_), .B(new_n421_), .C(G41), .Y(new_n422_));
  AO21x1_ASAP7_75t_R   g336(.A1(new_n117_), .A2(new_n421_), .B(new_n422_), .Y(new_n423_));
  AO21x1_ASAP7_75t_R   g337(.A1(G54), .A2(new_n352_), .B(new_n131_), .Y(new_n424_));
  AO22x1_ASAP7_75t_R   g338(.A1(new_n350_), .A2(new_n424_), .B1(new_n131_), .B2(new_n351_), .Y(new_n425_));
  AO22x1_ASAP7_75t_R   g339(.A1(new_n129_), .A2(new_n354_), .B1(new_n130_), .B2(new_n353_), .Y(new_n426_));
  AO21x1_ASAP7_75t_R   g340(.A1(new_n129_), .A2(new_n353_), .B(new_n354_), .Y(new_n427_));
  AO22x1_ASAP7_75t_R   g341(.A1(G41), .A2(new_n426_), .B1(new_n117_), .B2(new_n427_), .Y(new_n428_));
  AO21x1_ASAP7_75t_R   g342(.A1(new_n117_), .A2(new_n353_), .B(new_n400_), .Y(new_n429_));
  INVx1_ASAP7_75t_R    g343(.A(new_n429_), .Y(new_n430_));
  AO21x1_ASAP7_75t_R   g344(.A1(new_n128_), .A2(new_n396_), .B(new_n395_), .Y(new_n431_));
  AO22x1_ASAP7_75t_R   g345(.A1(G42), .A2(new_n431_), .B1(new_n118_), .B2(new_n128_), .Y(new_n432_));
  AO21x1_ASAP7_75t_R   g346(.A1(new_n118_), .A2(new_n431_), .B(G42), .Y(new_n433_));
  AO22x1_ASAP7_75t_R   g347(.A1(new_n345_), .A2(new_n432_), .B1(new_n346_), .B2(new_n433_), .Y(new_n434_));
  AO21x1_ASAP7_75t_R   g348(.A1(new_n128_), .A2(new_n395_), .B(new_n396_), .Y(new_n435_));
  AO21x1_ASAP7_75t_R   g349(.A1(G42), .A2(new_n435_), .B(new_n118_), .Y(new_n436_));
  AO22x1_ASAP7_75t_R   g350(.A1(G42), .A2(new_n128_), .B1(new_n118_), .B2(new_n435_), .Y(new_n437_));
  AO22x1_ASAP7_75t_R   g351(.A1(new_n345_), .A2(new_n436_), .B1(new_n346_), .B2(new_n437_), .Y(new_n438_));
  AO22x1_ASAP7_75t_R   g352(.A1(new_n429_), .A2(new_n434_), .B1(new_n430_), .B2(new_n438_), .Y(new_n439_));
  AND4x2_ASAP7_75t_R   g353(.A(new_n423_), .B(new_n425_), .C(new_n428_), .D(new_n439_), .Y(G878));
  AO21x1_ASAP7_75t_R   g354(.A1(G24), .A2(new_n127_), .B(new_n98_), .Y(new_n441_));
  AND3x1_ASAP7_75t_R   g355(.A(new_n235_), .B(new_n441_), .C(G42), .Y(new_n442_));
  AOI21x1_ASAP7_75t_R  g356(.A1(new_n118_), .A2(new_n441_), .B(new_n442_), .Y(new_n443_));
  AO22x1_ASAP7_75t_R   g357(.A1(new_n129_), .A2(new_n345_), .B1(new_n301_), .B2(new_n346_), .Y(new_n444_));
  AO21x1_ASAP7_75t_R   g358(.A1(new_n304_), .A2(new_n346_), .B(new_n345_), .Y(new_n445_));
  AOI22x1_ASAP7_75t_R  g359(.A1(G42), .A2(new_n444_), .B1(new_n118_), .B2(new_n445_), .Y(new_n446_));
  AO22x1_ASAP7_75t_R   g360(.A1(new_n345_), .A2(new_n431_), .B1(new_n346_), .B2(new_n435_), .Y(new_n447_));
  AO22x1_ASAP7_75t_R   g361(.A1(new_n345_), .A2(new_n435_), .B1(new_n346_), .B2(new_n431_), .Y(new_n448_));
  AOI22x1_ASAP7_75t_R  g362(.A1(G42), .A2(new_n447_), .B1(new_n118_), .B2(new_n448_), .Y(new_n449_));
  OR3x1_ASAP7_75t_R    g363(.A(new_n443_), .B(new_n446_), .C(new_n449_), .Y(new_n450_));
  INVx1_ASAP7_75t_R    g364(.A(new_n450_), .Y(G879));
  AO21x1_ASAP7_75t_R   g365(.A1(G25), .A2(new_n127_), .B(new_n99_), .Y(new_n452_));
  AND3x1_ASAP7_75t_R   g366(.A(new_n235_), .B(new_n452_), .C(G43), .Y(new_n453_));
  AOI21x1_ASAP7_75t_R  g367(.A1(new_n119_), .A2(new_n452_), .B(new_n453_), .Y(new_n454_));
  AO22x1_ASAP7_75t_R   g368(.A1(new_n129_), .A2(new_n369_), .B1(new_n301_), .B2(new_n370_), .Y(new_n455_));
  AO21x1_ASAP7_75t_R   g369(.A1(new_n304_), .A2(new_n370_), .B(new_n369_), .Y(new_n456_));
  AOI22x1_ASAP7_75t_R  g370(.A1(G43), .A2(new_n455_), .B1(new_n119_), .B2(new_n456_), .Y(new_n457_));
  AO22x1_ASAP7_75t_R   g371(.A1(G43), .A2(new_n369_), .B1(new_n119_), .B2(new_n370_), .Y(new_n458_));
  INVx1_ASAP7_75t_R    g372(.A(new_n458_), .Y(new_n459_));
  AO21x1_ASAP7_75t_R   g373(.A1(new_n120_), .A2(new_n128_), .B(new_n412_), .Y(new_n460_));
  AO21x1_ASAP7_75t_R   g374(.A1(new_n120_), .A2(new_n411_), .B(G44), .Y(new_n461_));
  AO22x1_ASAP7_75t_R   g375(.A1(new_n362_), .A2(new_n460_), .B1(new_n363_), .B2(new_n461_), .Y(new_n462_));
  AO21x1_ASAP7_75t_R   g376(.A1(G44), .A2(new_n413_), .B(new_n120_), .Y(new_n463_));
  AO21x1_ASAP7_75t_R   g377(.A1(G44), .A2(new_n128_), .B(new_n414_), .Y(new_n464_));
  AO22x1_ASAP7_75t_R   g378(.A1(new_n362_), .A2(new_n463_), .B1(new_n363_), .B2(new_n464_), .Y(new_n465_));
  AOI22x1_ASAP7_75t_R  g379(.A1(new_n458_), .A2(new_n462_), .B1(new_n459_), .B2(new_n465_), .Y(new_n466_));
  OR3x1_ASAP7_75t_R    g380(.A(new_n454_), .B(new_n457_), .C(new_n466_), .Y(new_n467_));
  INVx1_ASAP7_75t_R    g381(.A(new_n467_), .Y(G880));
endmodule


