# Event-flow validation

{
  "event_vs_staged_sweep": {
    "valid_pairs": 12,
    "both_failed": 0,
    "one_failed": 0,
    "delay_better": 12,
    "delay_equal": 0,
    "delay_worse": 0,
    "area_better": 6,
    "area_equal": 0,
    "area_worse": 6
  }
}

Every profile/run retained; no selection of best results.
