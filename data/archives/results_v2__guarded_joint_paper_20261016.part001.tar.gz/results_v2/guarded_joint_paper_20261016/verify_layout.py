from pathlib import Path
import re,hashlib,json
R=Path('/home/flynn/workplace/MIGBalance');O=Path(__file__).parent;s=(R/'epmapping_paper/DAC-eGraphMap-draft/main.tex').read_text();old=(O/'before.tex').read_text();pat=r'\\begin\{table\*\}.*?\\end\{table\*\}';a=re.findall(pat,s,re.S);b=re.findall(pat,old,re.S);assert len(a)==len(b)==4 and a==b
pages=[p for p in (O/'paper.txt').read_text().split('\f') if p.strip()];assert len(pages)==7
headings=[i+1 for i,p in enumerate(pages) if any(re.sub(r'\s+','',line).upper()=='REFERENCES' for line in p.splitlines())];assert headings==[7]
assert s.split('\\begin{document}')[0]==old.split('\\begin{document}')[0]
log=(R/'epmapping_paper/DAC-eGraphMap-draft/main.log').read_text();assert 'Overfull' not in log and 'LaTeX Warning:' not in log
(O/'structural_qa.json').write_text(json.dumps(dict(body_pages=6,reference_pages=1,reference_heading_pages=headings,primary_tables_byte_identical=True,table_hashes=[hashlib.sha256(x.encode()).hexdigest() for x in a],preamble_font_and_margins_unchanged=True,overfull=False,latex_warning=False,underfull_lines=[l for l in log.splitlines() if 'Underfull' in l],visual_check_pending=True),indent=2)+'\n');print('6+1;4primary tables byte-identical;standardpreamble; nooverfull/warnings; visualpending')
