from pathlib import Path
import re,subprocess
R=Path('/home/flynn/workplace/MIGBalance');P=R/'epmapping_paper/DAC-eGraphMap-draft';O=R/'results_v2/guarded_joint_paper_20261016';p=P/'main.tex';s=p.read_text();(O/'expanded_discussion_pre_layout.tex').write_text(s);a=s.index('\\subsection{Recovery and mechanism tests}');b=s.index('\\clearpage\n\\begin{thebibliography}',a)
s=s[:a]+r'''\subsection{Recovery and mechanism tests}
The isolated delay-first variant reserves complete area and fast input/phase
witnesses before truncation. A live-sharing lower bound and fused validation
preserve physical-area scoring. A saved incumbent belongs to the current
pool, not necessarily the previous pipeline's final cover. Source admission
retains the original 2048 helpers and uses spare capacity for additional
original functions: optional additions stop at 18000 nodes, while mandatory
import and saturation obey the unchanged 20000 limit. Added inverse-binding
trials share the original phase cap and deadline after faster-reference
activation; conditional matches remain outside equality.

The full comparison against guarded recovery covers all 20 circuits and
both libraries: 80 fresh attempts, 68 direct named-port CEC passes and twelve
admission failures. Four of 34 legal pairs improve delay at larger area;
thirty tie. Two alternating-order repetitions on nine targets add 72 CEC
passes; multiplier was included before repetitions following its full-run
gain. Unique accounting is 152 fresh attempts, 140 CEC passes and twelve
failures. Among 70 legal pairs, twelve improve delay at larger area and
58 tie in both metrics. Actual budgets and artifact checks pass. Targeted
repetition does not establish full-suite statistical stability.

\section{Discussion and Conclusion}
Four-input sqrt changes area/delay from 1982.22/51470.40 to
2250.39/47047.28; three-input sqrt changes from 1868.97/63200.36 to
2155.93/60087.26. Delay matches same-library emap to reported precision,
but area exceeds its 1562.46 and 1644.87. The four-input candidate uses
5445 helpers and 19944 post-saturation nodes. Its selected path shrinks
from 2281 to 2077 cells, with AO31 count rising from 1338 to 1743
(emap: 1742). These path counts do not prove individual candidate absence;
generated transient candidates are not retained-pool or memory-cap units.

Multiplier delay changes from 2744.83 to 2642.70 and from 2805.50 to
2715.38, at larger area. Priority/max preserve canonical main areas in all
three observations: four-input 52.15/221.30 and three-input 68.54/249.37.
Against canonical main, 34 common legal pairs give fourteen delay gains
and twenty ties, without equal-delay area regressions; eleven area costs
accompany lower delay. This is neither Pareto dominance nor a guarantee
that every previous final cover survives a changed pool. Primary comparisons
retain the validated main configuration.

Separate phase-factor repetitions add eight CEC passes to four pilot
observations. All six pairs tie in delay, but only two improve area and
four regress. A one-trial synthetic case exposes cyclic optional proposals
starving an old atomic flip: delay stays 13 instead of reaching 7. Giving
legacy proposals priority repairs that fixture; the repair has not undergone
full-suite physical validation. The phase extension is therefore unqualified.

Div, hyp and mem\_ctrl fail before saturation or cut matching, with no
optional helpers admitted; the next distinct operator is rejected at a
20000-node prefix. Planned representation counts are upper estimates, not
minimum lower bounds or impossibility proofs. Exact shared representation
remains unresolved. All six baseline gates remain false; 13,403 original
dependencies show zero drift. Industrial multi-output, ODC and independent
regional saturation remain unassessed; timing omits load, slew and wiring.

'''+s[b:]
old=(O/'before.tex').read_text();pattern=r'\\begin\{table\*\}.*?\\end\{table\*\}';assert re.findall(pattern,s,re.S)==re.findall(pattern,old,re.S);assert s.split('\\begin{document}')[0]==old.split('\\begin{document}')[0]
p.write_text(s);print('tail words',len(s[a:s.index('\\clearpage\n\\begin{thebibliography}',a)].split()))
for n in [1,2]:
 with (O/f'latex_final_pass{n}.log').open('w') as log:subprocess.run(['pdflatex','-interaction=nonstopmode','-halt-on-error','main.tex'],cwd=P,stdout=log,stderr=subprocess.STDOUT,check=True)
print(subprocess.check_output(['pdfinfo',str(P/'main.pdf')],text=True))
