#!/usr/bin/env python3
"""Read-only reconstruction of public unloaded pin-delay paths, not new PPA."""
from collections import Counter
import hashlib
import json
from pathlib import Path
import struct

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
f32 = lambda x: struct.unpack('f', struct.pack('f', x))[0]
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()


def analyze(folder, bench, method):
    report = folder/'report.json'
    r = next(r for r in json.loads(report.read_text())['results'] if r['method'] == method)
    assert r['status'] == 'ok' and r['measured']['cec'] == 1
    path = folder/f'{bench}.{method}'/'mapped.json'
    library = folder/'library.json'
    pins = {}
    for c in json.loads(library.read_text()): pins.setdefault(c['name'], []).append(c)
    m = json.loads(path.read_text())['modules']['mapped']
    arrival, previous, drivers = {'0': 0., '1': 0.}, {}, {}
    area = 0.
    for name, p in m['ports'].items():
        if p['direction'] == 'input':
            for b in p['bits']: arrival[b] = 0.; previous[b] = {'input_port': name}
    for name, c in m['cells'].items():
        model = pins[c['type']]
        assert all(abs(p['area']-model[0]['area']) < 1e-6 for p in model)
        area += f32(model[0]['area'])
        for p in model:
            bits = c['connections'][p['out_pin']]; assert len(bits) == 1
            assert bits[0] not in drivers
            drivers[bits[0]] = (name, c, p)
    pending = set(drivers)
    while pending:
        changed = False
        for bit in list(pending):
            name, c, p = drivers[bit]
            deps = [(pin, c['connections'][pin][0]) for pin in p['vars']]
            if not all(b in arrival for _, b in deps): continue
            best = max(((arrival[b]+f32(p['pin_delay'].get(pin, 0.)), pin, b)
                        for pin, b in deps), default=(0., None, None))
            arrival[bit] = best[0]
            previous[bit] = {'cell': name, 'type': c['type'], 'output_pin': p['out_pin'],
                             'input_pin': best[1], 'input_bit': best[2],
                             'arc_delay': f32(p['pin_delay'].get(best[1], 0.)), 'arrival': best[0]}
            pending.remove(bit); changed = True
        if not changed: raise ValueError('cycle or undriven dependency')
    outputs = [(arrival[b], name, b) for name, p in m['ports'].items()
               if p['direction'] == 'output' for b in p['bits']]
    delay, port, bit = max(outputs)
    assert abs(area-r['measured']['area']) < 1e-6, (area, r['measured']['area'])
    assert abs(delay-r['measured']['delay']) < 1e-6, (delay, r['measured']['delay'])
    chain = []
    while 'cell' in previous.get(bit, {}):
        a = previous[bit]; chain.append(a); bit = a['input_bit']
    chain.reverse()
    return {'method': method, 'bench': bench, 'area': area, 'delay': delay,
            'endpoint': port, 'critical_path_cell_count': len(chain),
            'critical_path_types': dict(Counter(a['type'] for a in chain)),
            'all_cell_types': dict(Counter(c['type'] for c in m['cells'].values())),
            'path': chain, 'sources': {str(p): sha(p) for p in [report, library, path]},
            'input_sha256': r['input_sha256'], 'prepared_sha256': r['preprocessing']['sha256'],
            'library_sha256': json.loads(report.read_text())['library_sha256']}


def main():
    campaign=ROOT/'results_v2/epfl_staged_factors_checkpoint_20261013'
    baseline=ROOT/'results_v2/epfl_mapping_policy_checkpoint_20261013/3in_core_adder'
    records=[analyze(baseline,'adder','abc_map_delay_resyn2')]
    natives=[]
    for profile in ['control','region_phase','critical_only','both']:
        folder=campaign/f'3in_delay-area_adder_{profile}'
        record=analyze(folder,'adder','egraph_staged_resyn2');record['profile']=profile
        records.append(record)
        natives.append(json.loads((folder/'report.json').read_text())['results'][0]['native'])
    for key in ['input_sha256','prepared_sha256','library_sha256']:
        assert len({r[key] for r in records})==1
    upstream=['enodes','eclasses','cuts','instances','generated_instances','bindings','dc_bindings']
    for key in upstream:assert len({r[key] for r in natives})==1,(key,[r[key] for r in natives])
    (OUT/'validation.json').write_text(json.dumps({'scope':'3in adder, original ABC map and4 isolated staged fixed profiles; all independent named-port CEC pass','public_metric_reproduced':True,'upstream_counts_identical':upstream,'baseline_algorithms_changed':False,'limitation':'One fixed-design ablation; identical counters are not a byte-level dump of the candidate pool, timing-limited stage behavior can vary','records':records},indent=2))
    for r in records:print(r.get('profile',r['method']),r['delay'],r['critical_path_cell_count'],r['critical_path_types'])
if __name__=='__main__':main()
