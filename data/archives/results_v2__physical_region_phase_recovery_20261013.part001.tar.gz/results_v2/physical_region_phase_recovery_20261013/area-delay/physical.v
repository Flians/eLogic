module region_0(input n1, input n2, output n6, output m6);
NAND2x1_ASAP7_75t_R nand_6(.A(n2), .B(n1), .Y(m6));
INVx1_ASAP7_75t_R inv_positive_6(.A(m6), .Y(n6));
endmodule
module region_1(input n3, input n6, output n7, input m6);
AND2x2_ASAP7_75t_R and_7(.A(m6), .B(n3), .Y(n7));
endmodule
module region_2(input n4, input n7, output n8);
AND2x2_ASAP7_75t_R and_8(.A(n7), .B(n4), .Y(n8));
endmodule
module region_3(input n5, input n8, output n9);
AND2x2_ASAP7_75t_R and_9(.A(n8), .B(n5), .Y(n9));
endmodule
module mapped(input p0, input p1, input p2, input p3, input p4, output o0, output o1);
wire n1;
wire n2;
wire n3;
wire n4;
wire n5;
wire n6;
wire m6;
wire n7;
wire n8;
wire n9;
assign n1 = p0;
assign n2 = p1;
assign n3 = p2;
assign n4 = p3;
assign n5 = p4;
region_0 r0(.n1(n1), .n2(n2), .n6(n6), .m6(m6));
region_1 r1(.n3(n3), .n6(n6), .n7(n7), .m6(m6));
region_2 r2(.n4(n4), .n7(n7), .n8(n8));
region_3 r3(.n5(n5), .n8(n8), .n9(n9));
assign o0 = n9;
assign o1 = n6;
endmodule
