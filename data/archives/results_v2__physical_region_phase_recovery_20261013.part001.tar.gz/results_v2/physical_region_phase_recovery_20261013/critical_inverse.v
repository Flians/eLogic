module mapped(input p0,p1,p2,p3,p4,output o0,o1);wire a=p0&p1;wire b=~a&p2;wire c=b&p3;wire d=c&p4;assign o0=d;assign o1=a;endmodule
