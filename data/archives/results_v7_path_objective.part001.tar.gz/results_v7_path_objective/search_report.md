# Cut-only search exploration

All configurations keep whole-window synthesis off. One fixed configuration applies to every design. An all-design phase tests the declared policy directly; tuning/validation phases use six declared tuning and ten validation designs. Round-cap six controls cover the six exploration designs only. Every admitted result passes CEC, raw-log agreement, paired serialized input equality and objective/budget checks. Path-objective runs allow area growth for critical timing improvement and guard the whole-network (delay, area) pair.

| Cohort | Configuration | Completed | Mean area change (%) | Mean delay change (%) |
|---|---|---:|---:|---:|
| rounds | path | 6/6 | +0.188 | -15.092 |
| all16 | required | 16/16 | -2.717 | -2.347 |
| all16 | path | 16/16 | +3.987 | -9.875 |

Final mapped outputs versus ABC mfs3 on its 13 completed designs (same serialized start; ABC timeouts excluded):

| Configuration | Matched | Mean area difference (%) | Mean delay difference (%) | Smaller / faster / Pareto dominates |
|---|---:|---:|---:|---:|
| required | 13 | +1.505 | -10.736 | 3 / 10 / 3 |
| path | 13 | +2.981 | -15.599 | 2 / 13 / 2 |

Negative means smaller/faster. Means average per-design percentages. A larger area saving can consume some delay improvement even when final delay never exceeds the initial mapping. Pure lexicographic v5 runs are separate experiments. No per-design best-of selection is used.

Failures/timeouts: []
