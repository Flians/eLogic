# Critical timing / noncritical area archive

This archive contains 32 all-design one-round runs (path versus required)
and six path-mode runs with a six-round cap and early stopping. All 38 runs
complete and pass CEC. Whole-window synthesis is disabled. Inputs are byte-identical
across profiles and equal the historical ABC serialized starts. The engine and
source snapshot are frozen in inputs/ and hashed in manifest.json.

The path policy processes initially critical roots first, then reclassifies each
root from live arrival and backward required time. Critical roots prioritize delay
then net area change; noncritical roots prioritize net area change then delay.
The required-time target follows the live worst output delay after substitutions.
The canonical whole-network (delay, area) pair is checked transactionally per round.
Area growth is permitted on global delay improvement; it is not bounded by default.

The required control is area-first under the fixed initial output-delay budget.
Its sixteen output area/delay values exactly reproduce the v6 required profile.
Critical-first ordering and local-objective changes are part of the path variant;
these measurements are not an isolated scheduling ablation.

All-design path means: area +3.987%, delay -9.875%. All sixteen are faster than
their initial mapping and thirteen are also smaller. sqrt trades +75.382% area
for -39.820% delay and dominates the area mean; it is retained in the headline.
The separate six-design/six-round mean is area +0.188%, delay -15.092%; it must
not be reported as a sixteen-design result. No per-design configuration selection is used.

The batch cap is 1500 seconds per engine process, for both path and control.
All actual process walls are below 300 seconds in this batch. Historical ABC
uses a 1000-second optimization cap; comparisons use its thirteen completed,
CEC-verified outputs and exclude its three timeouts. Times are observational.

| Design | Area change (%) | Delay change (%) | Critical replacements | Noncritical replacements |
|---|---:|---:|---:|---:|
| aes_core | -0.485 | -1.932 | 8 | 674 |
| arbiter | +5.444 | -0.508 | 171 | 0 |
| div | -1.284 | -3.499 | 243 | 8209 |
| ethernet | -0.650 | -11.963 | 27 | 1100 |
| iwls05_i2c | -1.078 | -11.422 | 7 | 59 |
| mem_ctrl | -1.069 | -8.489 | 16 | 1282 |
| RISC | -1.944 | -10.373 | 15 | 2342 |
| sasc | +2.120 | -7.923 | 6 | 15 |
| simple_spi | -0.423 | -4.541 | 2 | 25 |
| spi | -1.000 | -7.950 | 23 | 160 |
| sqrt | +75.382 | -39.820 | 3601 | 3341 |
| systemcaes | -1.454 | -15.060 | 6 | 506 |
| systemcdes | -1.635 | -4.225 | 5 | 378 |
| tv80 | -1.763 | -7.179 | 18 | 453 |
| usb_funct | -3.640 | -10.069 | 10 | 564 |
| usb_phy | -2.726 | -13.044 | 3 | 57 |

Reproduction and audit:

```sh
python3 scripts/experiments/explore_cut_only.py --root results_v7_path_objective --phase all --profiles path,required
python3 scripts/experiments/explore_cut_only.py --root results_v7_path_objective --phase rounds --profiles path --rounds 6 --jobs 4
python3 scripts/experiments/report_cut_search.py --root results_v7_path_objective
MPLCONFIGDIR=/tmp/epm-mpl python3 scripts/experiments/plot_cut_search.py --root results_v7_path_objective --profiles required,path
```

Existing rows are reused only with the same plan and frozen hashes. A fresh root
executes new runs and freezes the currently built engine. See search_report.md
for matched ABC comparisons and verified_search.json for raw artifact hashes.
