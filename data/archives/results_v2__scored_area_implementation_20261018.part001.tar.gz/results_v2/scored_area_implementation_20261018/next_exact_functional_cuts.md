# Next actual structural experiment (proposal only, NOT implemented)

The current small rule set mostly retains commuted ANDs; compact TT3/XOR imports can hide syntactic factoring patterns. Candidate presence must be demonstrated before another broad QoR study.

Representation-independent exact functional cuts over existing counted classes:
- For root cut F(S), |S|<=4, find an already imported class g with a cut G(T), 2<=|T|<|S| and T subset S. Require g != root, g not in S\T, G nonconstant.
- Test a TOTAL Boolean decomposition F(S)=Q(S\T,G(T)): for every old full-care assignment, assignments with equal (rest,G) must have the same F. Disjoint local supports plus nonconstant G make every new boundary assignment reachable in that local independent domain; Q is fully specified, not an arbitrary don't-care extension. Enumerate <=16 old assignments, no new SAT or care queries.
- Add derived cut boundary (S\T,g) with exact Q/proof; no new logical nodes or conditional union. Because g is already a counted node, no input-exemption/retirement/counter reset. Existing whole-cover acyclicity must reject circular choices; correctness proof concerns functions, not syntactic dominance.
- Index old cuts by subset support and truth table; bound partner trials deterministically within original generation limits. Integrate generation into existing <=32 cut rounds, rather than append an unaccounted33rd global round. Keep one actual16cut bank perclass and original mandatory source witnesses. Existing cut retention/pool cap may lose old candidates: full legacy physical-cover protection/admission still needs validation; never assume per-run recovery protection fixes a changed pool.
- Library-root prefilter: retain only Q with actual same-library cells or justified counted implementation, not arbitrary cheap lookup costs. Full physical pin timing and instance-once sharing decide selection, followed by original named-port CEC.

Meaningful candidate RED: existing shared class g=b|c is used by a separate output, while a different root represents (a&b)|(a&c) as TT3 or expanded AIG. Old syntactic cuts cannot use g. Functional derivation supplies (a,g), Q=a&g, verified on all8 assignments. Then test emitted physical sharing/delay with explicit synthetic cells before actual ASAP7; do not call a logical-only test a PPA improvement. The actual EPFL once-resyn2 input is NOT changed/preoptimized again.

Need independent full20/two-library fixed-factor study and adverse cases/repeats under unchanged node/cut/pool/time budgets. Big div/hyp/mem_ctrl still fail BEFORE cuts; this factor alone cannot repair their current source-import overflow.
