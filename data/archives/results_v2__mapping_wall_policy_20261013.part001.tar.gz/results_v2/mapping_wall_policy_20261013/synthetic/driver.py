import sys,json,pathlib,subprocess,os,signal
out=pathlib.Path(sys.argv[sys.argv.index("--output")+1]);out.mkdir()
row={"bench":"test","method":"abc_map","status":"ok","measured":{"area":1,"delay":1,"cec":1}}
def run(argv):
 with subprocess.Popen(argv,start_new_session=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE) as p:
  try:p.communicate(timeout=1)
  except subprocess.TimeoutExpired:
   os.killpg(p.pid,signal.SIGKILL);p.communicate()
for argv in [[str(pathlib.Path(__file__).parent/"bench_rs_netlist_eval"),"--cec-models"],[str(pathlib.Path(__file__).parent/"abc"),"-c","map"],[str(pathlib.Path(__file__).parent/"abc"),"-c","map"]]:run(argv)
(out/"report.json").write_text(json.dumps({"results":[row]}))
