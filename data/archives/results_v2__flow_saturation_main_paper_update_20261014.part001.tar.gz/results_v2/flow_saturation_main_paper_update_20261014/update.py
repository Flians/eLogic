from pathlib import Path
import json,shutil,re
root=Path('/home/flynn/workplace/MIGBalance');o=root/'results_v2/flow_saturation_main_paper_update_20261014';o.mkdir(exist_ok=True);p=root/'epmapping_paper/DAC-eGraphMap-draft/main.tex';shutil.copy2(p,o/'before.tex');shutil.copy2(root/'output/pdf/DAC-eGraphMap-draft.pdf',o/'before.pdf');s=p.read_text()
def sub(a,b):
 global s
 assert a in s,a[:80]
 s=s.replace(a,b)
sub('''Compared with the preceding wire profile, all 22 existing legal pairs
retain delay; area improves in eight, ties in thirteen and increases in one.''','''Compared with the preceding capacity profile, two of 30 legal pairs
improve delay and 28 tie; area improves in seven, ties in twenty and
increases in three.''')
sub('''Controls are the archived
preceding wire version, verified against original source and binary
hashes;''','''Controls are the archived
preceding capacity version, verified against original source and binary
hashes;''')
c=json.loads((root/'results_v2/flow_saturation_main_checkpoint_20261014/campaign.json').read_text());data={}
for j in c['jobs']:
 if j['profile']=='flow_sat':
  assert 'adopted_control_campaign' not in j
  data[j['k'],j['bench']]=json.loads(Path(j['report']).read_text())['results'][0]
assert len(data)==40
start=s.index('% BEGIN EPFL COMPLETE TABLES');end=s.index('% END EPFL COMPLETE TABLES');block=s[start:end];lines=[];checks=[];k=None;metric=None
for line in block.splitlines(keepends=True):
 m=re.search(r'label\{tab:epfl([34])(area|delay)\}',line)
 if m:k=int(m[1]);metric=m[2]
 name=line.split(' & ')[0].replace('\\_','_')
 if k and (k,name) in data and ' & ' in line:
  parts=line.strip().rstrip(chr(92)).strip().split(' & ');assert len(parts)==7
  r=data[k,name];value=f"{r['measured'][metric]:.2f}" if r['status']=='ok' else 'N';prefix=parts[:6];parts[-1]=value;line=' & '.join(parts)+' '+chr(92)*2+'\n';assert line.strip().rstrip(chr(92)).strip().split(' & ')[:6]==prefix
  checks.append({'k':k,'bench':name,'metric':metric,'table_value':value,'measured':r.get('measured',{}).get(metric),'baseline_columns_unchanged':True})
 lines.append(line)
assert len(checks)==80;s=s[:start]+''.join(lines)+s[end:]
a=s.index('An earlier same-binary EPFL study compares');b=s.index('Synthetic fixtures verify joint output',a)
s=s[:a]+'''Earlier coupled-worklist recovery improves six delays over 22 legal
pairs, with four area costs. Area-flow reservations also cause area
regressions in full studies. They are retained as separate profiles,
not chosen per circuit.

Delay flow used finite tree-area labels to recognize reachable signals.
A finite reconvergent DAG can have an overflowing unfolded tree cost;
this incorrectly suppresses valid alternatives. The optional worklist
caps only overflow from known finite inputs at the largest finite
floating value. Unknown inputs remain unavailable. Actual physical
area and pin delay are never capped, and complete-cover acceptance
uses the original lexicographic objective. A 2200-layer acyclic fixture
fails before this repair and passes afterwards. Sorted unique-input
summation preserves ordinary numerical order without tree allocations.
The main full comparison yields two lower delays, 28 ties, seven area
gains, twenty ties and three regressions; sqrt remains slower than
conventional mapping. Deadline checks are not preemptive stage caps.

'''+s[b:]
a=s.index('Arrival-only retention regresses bar/dec;');b=s.index('\\section{Conclusion}',a)
s=s[:a]+'''The main sqrt/bar/sin study retains full-run r0 and two alternating-order
repetitions in each inventory: 36 covers, six lower delays and twelve
ties, with fifteen area gains and three ties. All six sqrt pairs
improve both metrics. Delays decrease by 1700.25--2841.25 in the
three-input inventory and 1288.72--2783.49 in the four-input inventory.
Sin saves area; four-input bar ties. Outcomes still vary with the
wall deadline, and earlier full-suite area regressions remain in the
dataset. These repetitions do not establish statistical confidence.

For each remaining design, 2048 exact input vectors distinguish over
20,000 original functions up to complementation. Differing canonical
truth vectors supply concrete separating assignments. Thus retaining
all original scalar functions simultaneously cannot fit this scalar
representation in 20,000 nodes. This is not a physical cell/area bound
or an impossibility result for state retirement or other representations.
Raw live-frontier counts motivate retirement but do not verify native
region matching, stitching or global budget compliance. All baseline
gates remain false. Industrial multi-output, ODC and independent
regional saturation remain unassessed; public timing omits load, slew
and interconnect.

'''+s[b:];p.write_text(s);shutil.copy2(p,o/'after.tex');shutil.copy2(Path(__file__),o/'update.py');(o/'table_verification.json').write_text(json.dumps({'verified_candidate_cells':80,'baseline_columns_unchanged':True,'all40_candidates_fresh_main_binary':'247ab1119aafbc3f66d094c3db0209a6206a7fa38d689054c13eaaec7375798c','no_best_repeat_selection':True,'records':checks},indent=2)+'\n');print('updatedall80rootcells,baselinecolumnsunchanged')
