# Next hypothesis: exact local physical-area transactions with safe timing envelopes

Not implemented or PPA evidence. Current completed-pass bound is sound and saves some scores, but every surviving proposal still clones/prunes/scores the whole cover. Sqrt has about20000selected physical instances, so a few hundred ms often permit only a handful of useful commits. More source functions alone worsens area in the V15pilot despite preserving its fast delay. Investigate cheaper physical transactions rather than growing a pool or raising the deadline.

## Safe first subset

Use already admitted cell bindings whose every input is currently selected/free. Preserve the original full-score fallback for new/unselected input cones. For a candidate, collect all currently selected output targets to replace; reject if any target is reachable from a proposed input in the current selected dependency graph. This avoids cyclic producer/consumer grafts. Truth/phase legality remains established by ordinary exact library matching; this cache introduces no equality union or don't-care assumption.

Maintain physical-instance active membership, binding users and unique input signal refs. Activate a new physical instance BEFORE dereferencing replaced outputs, so its live inputs cannot be reclaimed prematurely. Charge the new instance once even when several pins/aliases are selected. Deactivate an old instance only when its final bound output loses its last user; recursively dereference its unique inputs and remove dead signals. Shared or multi-output cells remain charged once. Transactions must be reversible; reject without mutating the incumbent. Initial/final full physical-instance summation and validation remain inside the same inclusive2s deadline.

## Timing proof obligations

Fix the validated fast reference D. Initially compute dependent-pin arrival upper labels and backward required labels for the actual selected cover. For all changed targets, candidate pin arrival from input upper labels must satisfy its required time. For accepted replacements, propagate arrival INCREASES through current live fanout so later trials never use stale underestimates. Decreases may initially be ignored as conservative upper labels, sacrificing completeness rather than safety.

New producer edges must also tighten the required time of every dependent input by required[target]-pin_delay, recursively backward through current bindings. Old edge constraints may remain as conservative extra restrictions in the first implementation; they must never be relaxed without an exact repair algorithm. Updating refs alone while leaving stale required-time labels for newly used edges is unsafe. Multi-output pins and nondependent arcs need explicit cases. Recompute/check whole-cover pin delay after each accepted batch and before return; no candidate outside D can become successful. A faster visited valid cover may be stored separately under the global(D,A) objective; don't silently change the objective to area-only or spend a second recovery window.

## Feedback loop before native experiments

1. RED tiny shared-output fixture: stale active membership falsely charges an already active instance; existing V13test already locks this down.
2. RED delta transaction fixture: activating after deref incorrectly removes a new producer's required input. Joint-pin alias/last-user/root-ref cases mandatory.
3. RED stale-required fixture: a newly introduced producer edge has a tighter input requirement than the old graph, and a later local substitution otherwise violates D.
4. Differential generated small DAGs: completed incremental transactions versus full prune/physical unique-area/dependent-pin metrics, including cycles, unselected-input fallback and nonarc pins; exhaustive Boolean fixtures where practical.
5. Same binary, fixed original pools, original inclusive2s/cuts16/pool100k/nodes20k/SAT16 and per-process/mapping guards; full20/two-library and alternating-order repeats. No main adoption until shared-area incumbent and delay checks pass. All negative cases retained.

This is inspired by baseline ref/deref and required-time propagation, not a baseline change. No new physical candidates, LUT proxy metric, per-region time reset, hidden input functions or best-run selection.
