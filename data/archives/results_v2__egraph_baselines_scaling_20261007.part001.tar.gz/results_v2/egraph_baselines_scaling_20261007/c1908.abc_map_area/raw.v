// Benchmark "/home/flynn/workplace/MIGBalance/tools/mockturtle/experiments/benchmarks/c1908" written by ABC on Wed Oct  7 15:36:43 2026

module \/home/flynn/workplace/MIGBalance/tools/mockturtle/experiments/benchmarks/c1908  ( 
    G23, G24, G33, G31, G30, G32, G8, G6, G3, G15, G10, G12, G19, G28, G9,
    G14, G16, G18, G11, G5, G2, G27, G7, G4, G20, G13, G1, G17, G26, G22,
    G25, G21, G29,
    G1899, G1884, G1885, G1898, G1886, G1887, G1888, G1889, G1890, G1891,
    G1892, G1893, G1894, G1895, G1896, G1897, G1900, G1901, G1902, G1903,
    G1904, G1905, G1906, G1907, G1908  );
  input  G23, G24, G33, G31, G30, G32, G8, G6, G3, G15, G10, G12, G19,
    G28, G9, G14, G16, G18, G11, G5, G2, G27, G7, G4, G20, G13, G1, G17,
    G26, G22, G25, G21, G29;
  output G1899, G1884, G1885, G1898, G1886, G1887, G1888, G1889, G1890, G1891,
    G1892, G1893, G1894, G1895, G1896, G1897, G1900, G1901, G1902, G1903,
    G1904, G1905, G1906, G1907, G1908;
  wire new_n59_, new_n60_, new_n61_, new_n62_, new_n63_, new_n64_, new_n65_,
    new_n66_, new_n67_, new_n68_, new_n69_, new_n70_, new_n71_, new_n72_,
    new_n73_, new_n74_, new_n75_, new_n76_, new_n77_, new_n78_, new_n79_,
    new_n80_, new_n81_, new_n82_, new_n83_, new_n84_, new_n85_, new_n86_,
    new_n87_, new_n88_, new_n89_, new_n90_, new_n91_, new_n92_, new_n93_,
    new_n94_, new_n95_, new_n96_, new_n97_, new_n98_, new_n99_, new_n100_,
    new_n101_, new_n102_, new_n103_, new_n104_, new_n105_, new_n106_,
    new_n107_, new_n108_, new_n109_, new_n110_, new_n111_, new_n112_,
    new_n113_, new_n114_, new_n115_, new_n116_, new_n117_, new_n118_,
    new_n119_, new_n120_, new_n121_, new_n122_, new_n123_, new_n124_,
    new_n125_, new_n126_, new_n127_, new_n128_, new_n129_, new_n130_,
    new_n131_, new_n132_, new_n133_, new_n134_, new_n135_, new_n136_,
    new_n137_, new_n138_, new_n139_, new_n140_, new_n141_, new_n143_,
    new_n144_, new_n145_, new_n146_, new_n147_, new_n148_, new_n154_,
    new_n158_, new_n159_, new_n160_, new_n161_, new_n166_, new_n170_,
    new_n171_, new_n172_, new_n173_, new_n174_, new_n175_, new_n176_,
    new_n177_, new_n178_, new_n179_, new_n180_, new_n181_, new_n182_,
    new_n183_, new_n184_, new_n186_, new_n187_, new_n188_, new_n190_,
    new_n191_, new_n193_, new_n194_, new_n196_, new_n197_, new_n199_,
    new_n200_, new_n202_, new_n203_, new_n204_, new_n205_, new_n206_,
    new_n208_, new_n209_, new_n210_, new_n211_, new_n212_, new_n213_,
    new_n215_, new_n216_, new_n217_;
  INVx1_ASAP7_75t_R   g000(.A(G23), .Y(new_n59_));
  AO21x1_ASAP7_75t_R  g001(.A1(new_n59_), .A2(G24), .B(G33), .Y(new_n60_));
  OR3x1_ASAP7_75t_R   g002(.A(new_n60_), .B(G31), .C(G30), .Y(new_n61_));
  INVx1_ASAP7_75t_R   g003(.A(G24), .Y(new_n62_));
  NOR2x1_ASAP7_75t_R  g004(.A(G33), .B(G32), .Y(new_n63_));
  OA21x2_ASAP7_75t_R  g005(.A1(G23), .A2(new_n62_), .B(new_n63_), .Y(new_n64_));
  INVx1_ASAP7_75t_R   g006(.A(new_n64_), .Y(new_n65_));
  XNOR2x2_ASAP7_75t_R g007(.A(G8), .B(G6), .Y(new_n66_));
  XOR2x2_ASAP7_75t_R  g008(.A(new_n66_), .B(G3), .Y(new_n67_));
  XNOR2x2_ASAP7_75t_R g009(.A(G15), .B(G10), .Y(new_n68_));
  XNOR2x2_ASAP7_75t_R g010(.A(G12), .B(new_n68_), .Y(new_n69_));
  XOR2x2_ASAP7_75t_R  g011(.A(new_n69_), .B(new_n67_), .Y(new_n70_));
  INVx1_ASAP7_75t_R   g012(.A(G33), .Y(new_n71_));
  AND3x1_ASAP7_75t_R  g013(.A(new_n59_), .B(new_n71_), .C(G19), .Y(new_n72_));
  XOR2x2_ASAP7_75t_R  g014(.A(new_n70_), .B(new_n72_), .Y(new_n73_));
  NOR2x1_ASAP7_75t_R  g015(.A(G31), .B(new_n73_), .Y(new_n74_));
  XNOR2x2_ASAP7_75t_R g016(.A(G28), .B(new_n74_), .Y(new_n75_));
  XNOR2x2_ASAP7_75t_R g017(.A(G9), .B(G14), .Y(new_n76_));
  XOR2x2_ASAP7_75t_R  g018(.A(new_n76_), .B(G16), .Y(new_n77_));
  AND3x1_ASAP7_75t_R  g019(.A(new_n62_), .B(new_n71_), .C(G18), .Y(new_n78_));
  XOR2x2_ASAP7_75t_R  g020(.A(new_n78_), .B(G15), .Y(new_n79_));
  XOR2x2_ASAP7_75t_R  g021(.A(new_n79_), .B(G11), .Y(new_n80_));
  XOR2x2_ASAP7_75t_R  g022(.A(new_n80_), .B(new_n77_), .Y(new_n81_));
  XOR2x2_ASAP7_75t_R  g023(.A(G8), .B(G5), .Y(new_n82_));
  XOR2x2_ASAP7_75t_R  g024(.A(new_n82_), .B(G2), .Y(new_n83_));
  XOR2x2_ASAP7_75t_R  g025(.A(new_n81_), .B(new_n83_), .Y(new_n84_));
  NOR2x1_ASAP7_75t_R  g026(.A(G31), .B(new_n84_), .Y(new_n85_));
  XNOR2x2_ASAP7_75t_R g027(.A(G27), .B(new_n85_), .Y(new_n86_));
  AND2x2_ASAP7_75t_R  g028(.A(new_n86_), .B(new_n75_), .Y(new_n87_));
  INVx1_ASAP7_75t_R   g029(.A(new_n87_), .Y(new_n88_));
  AOI21x1_ASAP7_75t_R g030(.A1(new_n61_), .A2(new_n65_), .B(new_n88_), .Y(new_n89_));
  XNOR2x2_ASAP7_75t_R g031(.A(G10), .B(G7), .Y(new_n90_));
  XNOR2x2_ASAP7_75t_R g032(.A(G4), .B(new_n90_), .Y(new_n91_));
  XOR2x2_ASAP7_75t_R  g033(.A(new_n91_), .B(new_n77_), .Y(new_n92_));
  AND3x1_ASAP7_75t_R  g034(.A(new_n59_), .B(new_n71_), .C(G20), .Y(new_n93_));
  XNOR2x2_ASAP7_75t_R g035(.A(G13), .B(new_n93_), .Y(new_n94_));
  XOR2x2_ASAP7_75t_R  g036(.A(new_n92_), .B(new_n94_), .Y(new_n95_));
  NOR2x1_ASAP7_75t_R  g037(.A(G31), .B(new_n95_), .Y(new_n96_));
  OA21x2_ASAP7_75t_R  g038(.A1(G23), .A2(G31), .B(G19), .Y(new_n97_));
  XNOR2x2_ASAP7_75t_R g039(.A(new_n97_), .B(new_n96_), .Y(new_n98_));
  INVx1_ASAP7_75t_R   g040(.A(G31), .Y(new_n99_));
  AND3x1_ASAP7_75t_R  g041(.A(new_n62_), .B(new_n71_), .C(G17), .Y(new_n100_));
  XOR2x2_ASAP7_75t_R  g042(.A(new_n100_), .B(G1), .Y(new_n101_));
  XNOR2x2_ASAP7_75t_R g043(.A(G12), .B(G13), .Y(new_n102_));
  XOR2x2_ASAP7_75t_R  g044(.A(new_n102_), .B(G11), .Y(new_n103_));
  XNOR2x2_ASAP7_75t_R g045(.A(G15), .B(G16), .Y(new_n104_));
  XOR2x2_ASAP7_75t_R  g046(.A(new_n104_), .B(G10), .Y(new_n105_));
  XOR2x2_ASAP7_75t_R  g047(.A(new_n105_), .B(new_n103_), .Y(new_n106_));
  INVx1_ASAP7_75t_R   g048(.A(G5), .Y(new_n107_));
  XOR2x2_ASAP7_75t_R  g049(.A(G6), .B(G7), .Y(new_n108_));
  XOR2x2_ASAP7_75t_R  g050(.A(new_n108_), .B(new_n107_), .Y(new_n109_));
  XOR2x2_ASAP7_75t_R  g051(.A(new_n106_), .B(new_n109_), .Y(new_n110_));
  XOR2x2_ASAP7_75t_R  g052(.A(new_n110_), .B(new_n101_), .Y(new_n111_));
  NAND2x1_ASAP7_75t_R g053(.A(new_n99_), .B(new_n111_), .Y(new_n112_));
  XOR2x2_ASAP7_75t_R  g054(.A(new_n112_), .B(G26), .Y(new_n113_));
  AND2x2_ASAP7_75t_R  g055(.A(new_n113_), .B(new_n98_), .Y(new_n114_));
  OA21x2_ASAP7_75t_R  g056(.A1(G23), .A2(G31), .B(G20), .Y(new_n115_));
  XNOR2x2_ASAP7_75t_R g057(.A(G14), .B(G4), .Y(new_n116_));
  NAND2x1_ASAP7_75t_R g058(.A(G22), .B(new_n71_), .Y(new_n117_));
  XOR2x2_ASAP7_75t_R  g059(.A(new_n116_), .B(new_n117_), .Y(new_n118_));
  XNOR2x2_ASAP7_75t_R g060(.A(G3), .B(G2), .Y(new_n119_));
  XOR2x2_ASAP7_75t_R  g061(.A(new_n119_), .B(G1), .Y(new_n120_));
  XNOR2x2_ASAP7_75t_R g062(.A(new_n120_), .B(new_n105_), .Y(new_n121_));
  XOR2x2_ASAP7_75t_R  g063(.A(new_n121_), .B(new_n103_), .Y(new_n122_));
  XOR2x2_ASAP7_75t_R  g064(.A(new_n122_), .B(new_n118_), .Y(new_n123_));
  AND2x2_ASAP7_75t_R  g065(.A(new_n123_), .B(new_n99_), .Y(new_n124_));
  XOR2x2_ASAP7_75t_R  g066(.A(new_n124_), .B(G25), .Y(new_n125_));
  NAND2x1_ASAP7_75t_R g067(.A(new_n115_), .B(new_n125_), .Y(new_n126_));
  OA21x2_ASAP7_75t_R  g068(.A1(G24), .A2(G31), .B(G18), .Y(new_n127_));
  INVx1_ASAP7_75t_R   g069(.A(G9), .Y(new_n128_));
  XOR2x2_ASAP7_75t_R  g070(.A(new_n105_), .B(new_n128_), .Y(new_n129_));
  AND2x2_ASAP7_75t_R  g071(.A(new_n71_), .B(G21), .Y(new_n130_));
  XOR2x2_ASAP7_75t_R  g072(.A(new_n129_), .B(new_n130_), .Y(new_n131_));
  XOR2x2_ASAP7_75t_R  g073(.A(new_n120_), .B(new_n109_), .Y(new_n132_));
  XNOR2x2_ASAP7_75t_R g074(.A(G8), .B(G4), .Y(new_n133_));
  XOR2x2_ASAP7_75t_R  g075(.A(new_n132_), .B(new_n133_), .Y(new_n134_));
  XOR2x2_ASAP7_75t_R  g076(.A(new_n131_), .B(new_n134_), .Y(new_n135_));
  AND2x2_ASAP7_75t_R  g077(.A(new_n135_), .B(new_n99_), .Y(new_n136_));
  OA21x2_ASAP7_75t_R  g078(.A1(G24), .A2(G31), .B(G17), .Y(new_n137_));
  XNOR2x2_ASAP7_75t_R g079(.A(new_n137_), .B(new_n136_), .Y(new_n138_));
  AND2x2_ASAP7_75t_R  g080(.A(new_n138_), .B(new_n127_), .Y(new_n139_));
  AND3x1_ASAP7_75t_R  g081(.A(new_n139_), .B(new_n126_), .C(new_n114_), .Y(new_n140_));
  NAND2x1_ASAP7_75t_R g082(.A(new_n140_), .B(new_n89_), .Y(new_n141_));
  XOR2x2_ASAP7_75t_R  g083(.A(new_n141_), .B(G14), .Y(G1899));
  OR3x1_ASAP7_75t_R   g084(.A(new_n60_), .B(G31), .C(G29), .Y(new_n143_));
  AOI21x1_ASAP7_75t_R g085(.A1(new_n65_), .A2(new_n143_), .B(new_n88_), .Y(new_n144_));
  INVx1_ASAP7_75t_R   g086(.A(new_n138_), .Y(new_n145_));
  NAND2x1_ASAP7_75t_R g087(.A(new_n127_), .B(new_n145_), .Y(new_n146_));
  AND3x1_ASAP7_75t_R  g088(.A(new_n146_), .B(new_n114_), .C(new_n126_), .Y(new_n147_));
  NAND2x1_ASAP7_75t_R g089(.A(new_n147_), .B(new_n144_), .Y(new_n148_));
  XOR2x2_ASAP7_75t_R  g090(.A(new_n148_), .B(G1), .Y(G1884));
  XOR2x2_ASAP7_75t_R  g091(.A(new_n148_), .B(G2), .Y(G1885));
  XOR2x2_ASAP7_75t_R  g092(.A(new_n141_), .B(G13), .Y(G1898));
  XOR2x2_ASAP7_75t_R  g093(.A(new_n148_), .B(G3), .Y(G1886));
  XOR2x2_ASAP7_75t_R  g094(.A(new_n148_), .B(G4), .Y(G1887));
  NAND2x1_ASAP7_75t_R g095(.A(new_n147_), .B(new_n89_), .Y(new_n154_));
  XOR2x2_ASAP7_75t_R  g096(.A(new_n154_), .B(G10), .Y(G1888));
  XOR2x2_ASAP7_75t_R  g097(.A(new_n154_), .B(G15), .Y(G1889));
  XOR2x2_ASAP7_75t_R  g098(.A(new_n154_), .B(G16), .Y(G1890));
  INVx1_ASAP7_75t_R   g099(.A(new_n115_), .Y(new_n158_));
  NOR2x1_ASAP7_75t_R  g100(.A(new_n158_), .B(new_n125_), .Y(new_n159_));
  AND3x1_ASAP7_75t_R  g101(.A(new_n146_), .B(new_n159_), .C(new_n114_), .Y(new_n160_));
  AND2x2_ASAP7_75t_R  g102(.A(new_n144_), .B(new_n160_), .Y(new_n161_));
  XOR2x2_ASAP7_75t_R  g103(.A(new_n161_), .B(new_n107_), .Y(G1891));
  XNOR2x2_ASAP7_75t_R g104(.A(G6), .B(new_n161_), .Y(G1892));
  XNOR2x2_ASAP7_75t_R g105(.A(G7), .B(new_n161_), .Y(G1893));
  XNOR2x2_ASAP7_75t_R g106(.A(G8), .B(new_n161_), .Y(G1894));
  AND2x2_ASAP7_75t_R  g107(.A(new_n89_), .B(new_n160_), .Y(new_n166_));
  XOR2x2_ASAP7_75t_R  g108(.A(new_n166_), .B(new_n128_), .Y(G1895));
  XOR2x2_ASAP7_75t_R  g109(.A(new_n141_), .B(G11), .Y(G1896));
  XOR2x2_ASAP7_75t_R  g110(.A(new_n141_), .B(G12), .Y(G1897));
  NOR2x1_ASAP7_75t_R  g111(.A(new_n127_), .B(new_n125_), .Y(new_n170_));
  AND3x1_ASAP7_75t_R  g112(.A(new_n170_), .B(new_n158_), .C(new_n138_), .Y(new_n171_));
  AND2x2_ASAP7_75t_R  g113(.A(new_n98_), .B(new_n75_), .Y(new_n172_));
  AND3x1_ASAP7_75t_R  g114(.A(new_n86_), .B(new_n113_), .C(new_n172_), .Y(new_n173_));
  AO21x1_ASAP7_75t_R  g115(.A1(new_n171_), .A2(new_n173_), .B(G33), .Y(new_n174_));
  AND3x1_ASAP7_75t_R  g116(.A(new_n86_), .B(new_n64_), .C(new_n75_), .Y(new_n175_));
  AND3x1_ASAP7_75t_R  g117(.A(new_n159_), .B(new_n139_), .C(new_n114_), .Y(new_n176_));
  AND2x2_ASAP7_75t_R  g118(.A(new_n176_), .B(new_n175_), .Y(new_n177_));
  OA21x2_ASAP7_75t_R  g119(.A1(new_n160_), .A2(new_n140_), .B(new_n175_), .Y(new_n178_));
  INVx1_ASAP7_75t_R   g120(.A(new_n166_), .Y(new_n179_));
  AND3x1_ASAP7_75t_R  g121(.A(new_n179_), .B(new_n141_), .C(new_n154_), .Y(new_n180_));
  OAI21x1_ASAP7_75t_R g122(.A1(new_n147_), .A2(new_n160_), .B(new_n144_), .Y(new_n181_));
  AND2x2_ASAP7_75t_R  g123(.A(new_n180_), .B(new_n181_), .Y(new_n182_));
  INVx1_ASAP7_75t_R   g124(.A(new_n182_), .Y(new_n183_));
  OR3x1_ASAP7_75t_R   g125(.A(new_n183_), .B(new_n177_), .C(new_n178_), .Y(new_n184_));
  AO21x1_ASAP7_75t_R  g126(.A1(new_n184_), .A2(G32), .B(new_n174_), .Y(G1900));
  XNOR2x2_ASAP7_75t_R g127(.A(new_n134_), .B(new_n131_), .Y(new_n186_));
  AND3x1_ASAP7_75t_R  g128(.A(new_n183_), .B(new_n99_), .C(new_n137_), .Y(new_n187_));
  XOR2x2_ASAP7_75t_R  g129(.A(new_n187_), .B(new_n186_), .Y(new_n188_));
  NOR2x1_ASAP7_75t_R  g130(.A(new_n63_), .B(new_n188_), .Y(G1901));
  AND3x1_ASAP7_75t_R  g131(.A(new_n183_), .B(new_n99_), .C(G25), .Y(new_n190_));
  XNOR2x2_ASAP7_75t_R g132(.A(new_n123_), .B(new_n190_), .Y(new_n191_));
  NOR2x1_ASAP7_75t_R  g133(.A(new_n63_), .B(new_n191_), .Y(G1902));
  AND3x1_ASAP7_75t_R  g134(.A(new_n183_), .B(new_n99_), .C(G27), .Y(new_n193_));
  XNOR2x2_ASAP7_75t_R g135(.A(new_n84_), .B(new_n193_), .Y(new_n194_));
  NOR2x1_ASAP7_75t_R  g136(.A(new_n63_), .B(new_n194_), .Y(G1903));
  AND3x1_ASAP7_75t_R  g137(.A(new_n183_), .B(new_n99_), .C(G28), .Y(new_n196_));
  XNOR2x2_ASAP7_75t_R g138(.A(new_n73_), .B(new_n196_), .Y(new_n197_));
  NOR2x1_ASAP7_75t_R  g139(.A(new_n63_), .B(new_n197_), .Y(G1904));
  AND3x1_ASAP7_75t_R  g140(.A(new_n183_), .B(new_n99_), .C(new_n97_), .Y(new_n199_));
  XNOR2x2_ASAP7_75t_R g141(.A(new_n95_), .B(new_n199_), .Y(new_n200_));
  NOR2x1_ASAP7_75t_R  g142(.A(new_n63_), .B(new_n200_), .Y(G1905));
  NOR2x1_ASAP7_75t_R  g143(.A(G33), .B(new_n181_), .Y(new_n202_));
  INVx1_ASAP7_75t_R   g144(.A(G29), .Y(new_n203_));
  AO21x1_ASAP7_75t_R  g145(.A1(new_n71_), .A2(new_n203_), .B(new_n134_), .Y(new_n204_));
  XOR2x2_ASAP7_75t_R  g146(.A(new_n202_), .B(new_n204_), .Y(new_n205_));
  AO21x1_ASAP7_75t_R  g147(.A1(G21), .A2(G29), .B(G33), .Y(new_n206_));
  XOR2x2_ASAP7_75t_R  g148(.A(new_n205_), .B(new_n206_), .Y(G1906));
  NOR2x1_ASAP7_75t_R  g149(.A(G33), .B(new_n180_), .Y(new_n208_));
  XOR2x2_ASAP7_75t_R  g150(.A(G9), .B(G14), .Y(new_n209_));
  XOR2x2_ASAP7_75t_R  g151(.A(new_n106_), .B(new_n209_), .Y(new_n210_));
  OA21x2_ASAP7_75t_R  g152(.A1(G33), .A2(G30), .B(new_n210_), .Y(new_n211_));
  XNOR2x2_ASAP7_75t_R g153(.A(new_n211_), .B(new_n208_), .Y(new_n212_));
  AO21x1_ASAP7_75t_R  g154(.A1(G30), .A2(G22), .B(G33), .Y(new_n213_));
  XOR2x2_ASAP7_75t_R  g155(.A(new_n212_), .B(new_n213_), .Y(G1907));
  AND3x1_ASAP7_75t_R  g156(.A(new_n183_), .B(new_n99_), .C(G26), .Y(new_n215_));
  XOR2x2_ASAP7_75t_R  g157(.A(new_n215_), .B(new_n110_), .Y(new_n216_));
  XNOR2x2_ASAP7_75t_R g158(.A(new_n101_), .B(new_n216_), .Y(new_n217_));
  NOR2x1_ASAP7_75t_R  g159(.A(new_n63_), .B(new_n217_), .Y(G1908));
endmodule


