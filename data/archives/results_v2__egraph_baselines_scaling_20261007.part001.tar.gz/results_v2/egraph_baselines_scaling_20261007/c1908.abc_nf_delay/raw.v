// Benchmark "/home/flynn/workplace/MIGBalance/tools/mockturtle/experiments/benchmarks/c1908" written by ABC on Wed Oct  7 15:36:43 2026

module \/home/flynn/workplace/MIGBalance/tools/mockturtle/experiments/benchmarks/c1908  ( 
    G23, G24, G33, G31, G30, G32, G8, G6, G3, G15, G10, G12, G19, G28, G9,
    G14, G16, G18, G11, G5, G2, G27, G7, G4, G20, G13, G1, G17, G26, G22,
    G25, G21, G29,
    G1899, G1884, G1885, G1898, G1886, G1887, G1888, G1889, G1890, G1891,
    G1892, G1893, G1894, G1895, G1896, G1897, G1900, G1901, G1902, G1903,
    G1904, G1905, G1906, G1907, G1908  );
  input  G23, G24, G33, G31, G30, G32, G8, G6, G3, G15, G10, G12, G19,
    G28, G9, G14, G16, G18, G11, G5, G2, G27, G7, G4, G20, G13, G1, G17,
    G26, G22, G25, G21, G29;
  output G1899, G1884, G1885, G1898, G1886, G1887, G1888, G1889, G1890, G1891,
    G1892, G1893, G1894, G1895, G1896, G1897, G1900, G1901, G1902, G1903,
    G1904, G1905, G1906, G1907, G1908;
  wire new_n59_, new_n60_, new_n61_, new_n62_, new_n63_, new_n64_, new_n65_,
    new_n66_, new_n67_, new_n68_, new_n69_, new_n70_, new_n71_, new_n72_,
    new_n73_, new_n74_, new_n75_, new_n76_, new_n77_, new_n78_, new_n79_,
    new_n80_, new_n81_, new_n82_, new_n83_, new_n84_, new_n85_, new_n86_,
    new_n87_, new_n88_, new_n89_, new_n90_, new_n91_, new_n92_, new_n93_,
    new_n94_, new_n95_, new_n96_, new_n97_, new_n98_, new_n99_, new_n100_,
    new_n101_, new_n102_, new_n103_, new_n104_, new_n105_, new_n106_,
    new_n107_, new_n108_, new_n109_, new_n110_, new_n111_, new_n112_,
    new_n113_, new_n114_, new_n115_, new_n116_, new_n117_, new_n118_,
    new_n119_, new_n120_, new_n121_, new_n122_, new_n123_, new_n124_,
    new_n125_, new_n126_, new_n127_, new_n128_, new_n129_, new_n130_,
    new_n131_, new_n132_, new_n133_, new_n134_, new_n135_, new_n136_,
    new_n137_, new_n138_, new_n139_, new_n140_, new_n141_, new_n142_,
    new_n143_, new_n144_, new_n145_, new_n146_, new_n147_, new_n148_,
    new_n149_, new_n150_, new_n151_, new_n152_, new_n153_, new_n154_,
    new_n155_, new_n156_, new_n157_, new_n158_, new_n159_, new_n160_,
    new_n161_, new_n162_, new_n163_, new_n164_, new_n165_, new_n166_,
    new_n167_, new_n168_, new_n169_, new_n170_, new_n171_, new_n172_,
    new_n173_, new_n174_, new_n176_, new_n177_, new_n178_, new_n179_,
    new_n180_, new_n186_, new_n190_, new_n191_, new_n192_, new_n193_,
    new_n198_, new_n202_, new_n203_, new_n204_, new_n205_, new_n206_,
    new_n207_, new_n208_, new_n209_, new_n210_, new_n211_, new_n212_,
    new_n213_, new_n214_, new_n215_, new_n216_, new_n217_, new_n218_,
    new_n220_, new_n221_, new_n222_, new_n223_, new_n225_, new_n226_,
    new_n227_, new_n229_, new_n230_, new_n231_, new_n233_, new_n234_,
    new_n235_, new_n237_, new_n238_, new_n239_, new_n241_, new_n242_,
    new_n243_, new_n244_, new_n246_, new_n247_, new_n248_, new_n249_,
    new_n250_, new_n251_, new_n252_, new_n254_, new_n255_, new_n256_,
    new_n257_, new_n258_, new_n259_;
  INVx1_ASAP7_75t_R   g000(.A(G23), .Y(new_n59_));
  INVx1_ASAP7_75t_R   g001(.A(G24), .Y(new_n60_));
  INVx1_ASAP7_75t_R   g002(.A(G33), .Y(new_n61_));
  INVx1_ASAP7_75t_R   g003(.A(G31), .Y(new_n62_));
  INVx1_ASAP7_75t_R   g004(.A(G10), .Y(new_n63_));
  INVx1_ASAP7_75t_R   g005(.A(G18), .Y(new_n64_));
  INVx1_ASAP7_75t_R   g006(.A(G27), .Y(new_n65_));
  INVx1_ASAP7_75t_R   g007(.A(G25), .Y(new_n66_));
  AO21x1_ASAP7_75t_R  g008(.A1(new_n59_), .A2(G24), .B(G33), .Y(new_n67_));
  OR3x1_ASAP7_75t_R   g009(.A(new_n67_), .B(G30), .C(G31), .Y(new_n68_));
  INVx1_ASAP7_75t_R   g010(.A(new_n68_), .Y(new_n69_));
  OR2x4_ASAP7_75t_R   g011(.A(G33), .B(G32), .Y(new_n70_));
  AOI21x1_ASAP7_75t_R g012(.A1(new_n59_), .A2(G24), .B(new_n70_), .Y(new_n71_));
  XOR2x2_ASAP7_75t_R  g013(.A(G8), .B(G6), .Y(new_n72_));
  XNOR2x2_ASAP7_75t_R g014(.A(G3), .B(new_n72_), .Y(new_n73_));
  XOR2x2_ASAP7_75t_R  g015(.A(G15), .B(G10), .Y(new_n74_));
  XOR2x2_ASAP7_75t_R  g016(.A(G12), .B(new_n74_), .Y(new_n75_));
  XOR2x2_ASAP7_75t_R  g017(.A(new_n73_), .B(new_n75_), .Y(new_n76_));
  AND3x1_ASAP7_75t_R  g018(.A(new_n59_), .B(new_n61_), .C(G19), .Y(new_n77_));
  NOR2x1_ASAP7_75t_R  g019(.A(new_n76_), .B(new_n77_), .Y(new_n78_));
  AND2x2_ASAP7_75t_R  g020(.A(new_n76_), .B(new_n77_), .Y(new_n79_));
  NOR2x1_ASAP7_75t_R  g021(.A(new_n78_), .B(new_n79_), .Y(new_n80_));
  OA21x2_ASAP7_75t_R  g022(.A1(new_n78_), .A2(new_n79_), .B(new_n62_), .Y(new_n81_));
  XNOR2x2_ASAP7_75t_R g023(.A(G28), .B(new_n81_), .Y(new_n82_));
  XOR2x2_ASAP7_75t_R  g024(.A(G9), .B(G14), .Y(new_n83_));
  XNOR2x2_ASAP7_75t_R g025(.A(G16), .B(new_n83_), .Y(new_n84_));
  OR3x1_ASAP7_75t_R   g026(.A(new_n64_), .B(G33), .C(G24), .Y(new_n85_));
  NAND2x1_ASAP7_75t_R g027(.A(G15), .B(new_n85_), .Y(new_n86_));
  OR2x4_ASAP7_75t_R   g028(.A(G15), .B(new_n85_), .Y(new_n87_));
  AOI21x1_ASAP7_75t_R g029(.A1(new_n86_), .A2(new_n87_), .B(G11), .Y(new_n88_));
  AND3x1_ASAP7_75t_R  g030(.A(new_n87_), .B(G11), .C(new_n86_), .Y(new_n89_));
  OR3x1_ASAP7_75t_R   g031(.A(new_n84_), .B(new_n88_), .C(new_n89_), .Y(new_n90_));
  OAI21x1_ASAP7_75t_R g032(.A1(new_n88_), .A2(new_n89_), .B(new_n84_), .Y(new_n91_));
  XOR2x2_ASAP7_75t_R  g033(.A(G8), .B(G5), .Y(new_n92_));
  XOR2x2_ASAP7_75t_R  g034(.A(G2), .B(new_n92_), .Y(new_n93_));
  AOI21x1_ASAP7_75t_R g035(.A1(new_n90_), .A2(new_n91_), .B(new_n93_), .Y(new_n94_));
  AND3x1_ASAP7_75t_R  g036(.A(new_n90_), .B(new_n91_), .C(new_n93_), .Y(new_n95_));
  NOR2x1_ASAP7_75t_R  g037(.A(new_n94_), .B(new_n95_), .Y(new_n96_));
  OA21x2_ASAP7_75t_R  g038(.A1(new_n94_), .A2(new_n95_), .B(new_n62_), .Y(new_n97_));
  NAND2x1_ASAP7_75t_R g039(.A(new_n65_), .B(new_n97_), .Y(new_n98_));
  OAI21x1_ASAP7_75t_R g040(.A1(G31), .A2(new_n96_), .B(G27), .Y(new_n99_));
  AND2x2_ASAP7_75t_R  g041(.A(new_n98_), .B(new_n99_), .Y(new_n100_));
  AND3x1_ASAP7_75t_R  g042(.A(new_n98_), .B(new_n99_), .C(new_n82_), .Y(new_n101_));
  OA21x2_ASAP7_75t_R  g043(.A1(new_n69_), .A2(new_n71_), .B(new_n101_), .Y(new_n102_));
  XOR2x2_ASAP7_75t_R  g044(.A(G10), .B(G7), .Y(new_n103_));
  XNOR2x2_ASAP7_75t_R g045(.A(G4), .B(new_n103_), .Y(new_n104_));
  XOR2x2_ASAP7_75t_R  g046(.A(new_n84_), .B(new_n104_), .Y(new_n105_));
  AND3x1_ASAP7_75t_R  g047(.A(new_n59_), .B(new_n61_), .C(G20), .Y(new_n106_));
  XOR2x2_ASAP7_75t_R  g048(.A(G13), .B(new_n106_), .Y(new_n107_));
  XOR2x2_ASAP7_75t_R  g049(.A(new_n105_), .B(new_n107_), .Y(new_n108_));
  NOR2x1_ASAP7_75t_R  g050(.A(G31), .B(new_n108_), .Y(new_n109_));
  OA21x2_ASAP7_75t_R  g051(.A1(G23), .A2(G31), .B(G19), .Y(new_n110_));
  XNOR2x2_ASAP7_75t_R g052(.A(new_n109_), .B(new_n110_), .Y(new_n111_));
  AND3x1_ASAP7_75t_R  g053(.A(new_n60_), .B(new_n61_), .C(G17), .Y(new_n112_));
  XNOR2x2_ASAP7_75t_R g054(.A(G1), .B(new_n112_), .Y(new_n113_));
  XOR2x2_ASAP7_75t_R  g055(.A(G12), .B(G13), .Y(new_n114_));
  XNOR2x2_ASAP7_75t_R g056(.A(G11), .B(new_n114_), .Y(new_n115_));
  AND2x2_ASAP7_75t_R  g057(.A(G15), .B(G16), .Y(new_n116_));
  NOR2x1_ASAP7_75t_R  g058(.A(G15), .B(G16), .Y(new_n117_));
  XOR2x2_ASAP7_75t_R  g059(.A(G15), .B(G16), .Y(new_n118_));
  OAI21x1_ASAP7_75t_R g060(.A1(new_n116_), .A2(new_n117_), .B(G10), .Y(new_n119_));
  OR3x1_ASAP7_75t_R   g061(.A(G10), .B(new_n116_), .C(new_n117_), .Y(new_n120_));
  XOR2x2_ASAP7_75t_R  g062(.A(new_n63_), .B(new_n118_), .Y(new_n121_));
  XOR2x2_ASAP7_75t_R  g063(.A(new_n115_), .B(new_n121_), .Y(new_n122_));
  XOR2x2_ASAP7_75t_R  g064(.A(G6), .B(G7), .Y(new_n123_));
  XOR2x2_ASAP7_75t_R  g065(.A(G5), .B(new_n123_), .Y(new_n124_));
  INVx1_ASAP7_75t_R   g066(.A(new_n124_), .Y(new_n125_));
  NAND2x1_ASAP7_75t_R g067(.A(new_n125_), .B(new_n122_), .Y(new_n126_));
  OR2x4_ASAP7_75t_R   g068(.A(new_n125_), .B(new_n122_), .Y(new_n127_));
  AND2x2_ASAP7_75t_R  g069(.A(new_n126_), .B(new_n127_), .Y(new_n128_));
  AOI21x1_ASAP7_75t_R g070(.A1(new_n126_), .A2(new_n127_), .B(new_n113_), .Y(new_n129_));
  AND3x1_ASAP7_75t_R  g071(.A(new_n113_), .B(new_n126_), .C(new_n127_), .Y(new_n130_));
  OA21x2_ASAP7_75t_R  g072(.A1(new_n129_), .A2(new_n130_), .B(new_n62_), .Y(new_n131_));
  XNOR2x2_ASAP7_75t_R g073(.A(G26), .B(new_n131_), .Y(new_n132_));
  AND2x2_ASAP7_75t_R  g074(.A(new_n111_), .B(new_n132_), .Y(new_n133_));
  OA21x2_ASAP7_75t_R  g075(.A1(G23), .A2(G31), .B(G20), .Y(new_n134_));
  INVx1_ASAP7_75t_R   g076(.A(new_n134_), .Y(new_n135_));
  XNOR2x2_ASAP7_75t_R g077(.A(G14), .B(G4), .Y(new_n136_));
  NAND2x1_ASAP7_75t_R g078(.A(G22), .B(new_n61_), .Y(new_n137_));
  XOR2x2_ASAP7_75t_R  g079(.A(new_n136_), .B(new_n137_), .Y(new_n138_));
  XOR2x2_ASAP7_75t_R  g080(.A(G3), .B(G2), .Y(new_n139_));
  XOR2x2_ASAP7_75t_R  g081(.A(G1), .B(new_n139_), .Y(new_n140_));
  AO21x1_ASAP7_75t_R  g082(.A1(new_n119_), .A2(new_n120_), .B(new_n140_), .Y(new_n141_));
  NAND2x1_ASAP7_75t_R g083(.A(new_n121_), .B(new_n140_), .Y(new_n142_));
  AOI21x1_ASAP7_75t_R g084(.A1(new_n141_), .A2(new_n142_), .B(new_n115_), .Y(new_n143_));
  AND3x1_ASAP7_75t_R  g085(.A(new_n142_), .B(new_n115_), .C(new_n141_), .Y(new_n144_));
  OAI21x1_ASAP7_75t_R g086(.A1(new_n143_), .A2(new_n144_), .B(new_n138_), .Y(new_n145_));
  OR3x1_ASAP7_75t_R   g087(.A(new_n144_), .B(new_n138_), .C(new_n143_), .Y(new_n146_));
  NAND2x1_ASAP7_75t_R g088(.A(new_n145_), .B(new_n146_), .Y(new_n147_));
  AOI21x1_ASAP7_75t_R g089(.A1(new_n145_), .A2(new_n146_), .B(G31), .Y(new_n148_));
  AND2x2_ASAP7_75t_R  g090(.A(new_n148_), .B(new_n66_), .Y(new_n149_));
  NOR2x1_ASAP7_75t_R  g091(.A(new_n66_), .B(new_n148_), .Y(new_n150_));
  OAI21x1_ASAP7_75t_R g092(.A1(new_n149_), .A2(new_n150_), .B(new_n134_), .Y(new_n151_));
  OA21x2_ASAP7_75t_R  g093(.A1(G24), .A2(G31), .B(G18), .Y(new_n152_));
  AO21x1_ASAP7_75t_R  g094(.A1(new_n60_), .A2(new_n62_), .B(new_n64_), .Y(new_n153_));
  AND3x1_ASAP7_75t_R  g095(.A(new_n120_), .B(G9), .C(new_n119_), .Y(new_n154_));
  AOI21x1_ASAP7_75t_R g096(.A1(new_n119_), .A2(new_n120_), .B(G9), .Y(new_n155_));
  AND2x2_ASAP7_75t_R  g097(.A(new_n61_), .B(G21), .Y(new_n156_));
  OAI21x1_ASAP7_75t_R g098(.A1(new_n154_), .A2(new_n155_), .B(new_n156_), .Y(new_n157_));
  OR3x1_ASAP7_75t_R   g099(.A(new_n154_), .B(new_n155_), .C(new_n156_), .Y(new_n158_));
  NAND2x1_ASAP7_75t_R g100(.A(new_n157_), .B(new_n158_), .Y(new_n159_));
  AND2x2_ASAP7_75t_R  g101(.A(new_n124_), .B(new_n140_), .Y(new_n160_));
  NOR2x1_ASAP7_75t_R  g102(.A(new_n124_), .B(new_n140_), .Y(new_n161_));
  XNOR2x2_ASAP7_75t_R g103(.A(G8), .B(G4), .Y(new_n162_));
  OAI21x1_ASAP7_75t_R g104(.A1(new_n160_), .A2(new_n161_), .B(new_n162_), .Y(new_n163_));
  OR3x1_ASAP7_75t_R   g105(.A(new_n160_), .B(new_n161_), .C(new_n162_), .Y(new_n164_));
  NAND2x1_ASAP7_75t_R g106(.A(new_n163_), .B(new_n164_), .Y(new_n165_));
  INVx1_ASAP7_75t_R   g107(.A(new_n165_), .Y(new_n166_));
  AO21x1_ASAP7_75t_R  g108(.A1(new_n163_), .A2(new_n164_), .B(new_n159_), .Y(new_n167_));
  NAND3x1_ASAP7_75t_R g109(.A(new_n159_), .B(new_n163_), .C(new_n164_), .Y(new_n168_));
  AND3x1_ASAP7_75t_R  g110(.A(new_n62_), .B(new_n167_), .C(new_n168_), .Y(new_n169_));
  OAI21x1_ASAP7_75t_R g111(.A1(G24), .A2(G31), .B(G17), .Y(new_n170_));
  XOR2x2_ASAP7_75t_R  g112(.A(new_n169_), .B(new_n170_), .Y(new_n171_));
  XNOR2x2_ASAP7_75t_R g113(.A(new_n169_), .B(new_n170_), .Y(new_n172_));
  AND3x1_ASAP7_75t_R  g114(.A(new_n171_), .B(new_n151_), .C(new_n152_), .Y(new_n173_));
  AND3x1_ASAP7_75t_R  g115(.A(new_n102_), .B(new_n133_), .C(new_n173_), .Y(new_n174_));
  XNOR2x2_ASAP7_75t_R g116(.A(G14), .B(new_n174_), .Y(G1899));
  OR3x1_ASAP7_75t_R   g117(.A(new_n67_), .B(G29), .C(G31), .Y(new_n176_));
  INVx1_ASAP7_75t_R   g118(.A(new_n176_), .Y(new_n177_));
  OA21x2_ASAP7_75t_R  g119(.A1(new_n71_), .A2(new_n177_), .B(new_n101_), .Y(new_n178_));
  OA21x2_ASAP7_75t_R  g120(.A1(new_n171_), .A2(new_n153_), .B(new_n151_), .Y(new_n179_));
  AND3x1_ASAP7_75t_R  g121(.A(new_n133_), .B(new_n178_), .C(new_n179_), .Y(new_n180_));
  XNOR2x2_ASAP7_75t_R g122(.A(G1), .B(new_n180_), .Y(G1884));
  XNOR2x2_ASAP7_75t_R g123(.A(G2), .B(new_n180_), .Y(G1885));
  XNOR2x2_ASAP7_75t_R g124(.A(G13), .B(new_n174_), .Y(G1898));
  XNOR2x2_ASAP7_75t_R g125(.A(G3), .B(new_n180_), .Y(G1886));
  XNOR2x2_ASAP7_75t_R g126(.A(G4), .B(new_n180_), .Y(G1887));
  AND3x1_ASAP7_75t_R  g127(.A(new_n102_), .B(new_n133_), .C(new_n179_), .Y(new_n186_));
  XOR2x2_ASAP7_75t_R  g128(.A(new_n63_), .B(new_n186_), .Y(G1888));
  XNOR2x2_ASAP7_75t_R g129(.A(G15), .B(new_n186_), .Y(G1889));
  XNOR2x2_ASAP7_75t_R g130(.A(G16), .B(new_n186_), .Y(G1890));
  OR3x1_ASAP7_75t_R   g131(.A(new_n150_), .B(new_n135_), .C(new_n149_), .Y(new_n190_));
  AOI21x1_ASAP7_75t_R g132(.A1(new_n152_), .A2(new_n172_), .B(new_n190_), .Y(new_n191_));
  AND2x2_ASAP7_75t_R  g133(.A(new_n133_), .B(new_n191_), .Y(new_n192_));
  AND3x1_ASAP7_75t_R  g134(.A(new_n133_), .B(new_n178_), .C(new_n191_), .Y(new_n193_));
  XNOR2x2_ASAP7_75t_R g135(.A(G5), .B(new_n193_), .Y(G1891));
  XNOR2x2_ASAP7_75t_R g136(.A(G6), .B(new_n193_), .Y(G1892));
  XNOR2x2_ASAP7_75t_R g137(.A(G7), .B(new_n193_), .Y(G1893));
  XNOR2x2_ASAP7_75t_R g138(.A(G8), .B(new_n193_), .Y(G1894));
  AND3x1_ASAP7_75t_R  g139(.A(new_n102_), .B(new_n133_), .C(new_n191_), .Y(new_n198_));
  XNOR2x2_ASAP7_75t_R g140(.A(G9), .B(new_n198_), .Y(G1895));
  XNOR2x2_ASAP7_75t_R g141(.A(G11), .B(new_n174_), .Y(G1896));
  XNOR2x2_ASAP7_75t_R g142(.A(G12), .B(new_n174_), .Y(G1897));
  OR3x1_ASAP7_75t_R   g143(.A(new_n149_), .B(new_n150_), .C(new_n152_), .Y(new_n202_));
  OR3x1_ASAP7_75t_R   g144(.A(new_n202_), .B(new_n134_), .C(new_n172_), .Y(new_n203_));
  INVx1_ASAP7_75t_R   g145(.A(new_n203_), .Y(new_n204_));
  AND2x2_ASAP7_75t_R  g146(.A(new_n82_), .B(new_n111_), .Y(new_n205_));
  AND3x1_ASAP7_75t_R  g147(.A(new_n100_), .B(new_n132_), .C(new_n205_), .Y(new_n206_));
  AO21x1_ASAP7_75t_R  g148(.A1(new_n204_), .A2(new_n206_), .B(G33), .Y(new_n207_));
  AND2x2_ASAP7_75t_R  g149(.A(new_n71_), .B(new_n101_), .Y(new_n208_));
  OR3x1_ASAP7_75t_R   g150(.A(new_n153_), .B(new_n172_), .C(new_n190_), .Y(new_n209_));
  INVx1_ASAP7_75t_R   g151(.A(new_n209_), .Y(new_n210_));
  AND3x1_ASAP7_75t_R  g152(.A(new_n133_), .B(new_n208_), .C(new_n210_), .Y(new_n211_));
  AND3x1_ASAP7_75t_R  g153(.A(new_n133_), .B(new_n173_), .C(new_n208_), .Y(new_n212_));
  AO21x1_ASAP7_75t_R  g154(.A1(new_n192_), .A2(new_n208_), .B(new_n212_), .Y(new_n213_));
  OR3x1_ASAP7_75t_R   g155(.A(new_n174_), .B(new_n186_), .C(new_n198_), .Y(new_n214_));
  AO21x1_ASAP7_75t_R  g156(.A1(new_n178_), .A2(new_n192_), .B(new_n180_), .Y(new_n215_));
  NOR2x1_ASAP7_75t_R  g157(.A(new_n214_), .B(new_n215_), .Y(new_n216_));
  INVx1_ASAP7_75t_R   g158(.A(new_n216_), .Y(new_n217_));
  OR3x1_ASAP7_75t_R   g159(.A(new_n217_), .B(new_n211_), .C(new_n213_), .Y(new_n218_));
  AO21x1_ASAP7_75t_R  g160(.A1(new_n218_), .A2(G32), .B(new_n207_), .Y(G1900));
  XOR2x2_ASAP7_75t_R  g161(.A(new_n159_), .B(new_n165_), .Y(new_n220_));
  AND3x1_ASAP7_75t_R  g162(.A(new_n62_), .B(G17), .C(G24), .Y(new_n221_));
  OA21x2_ASAP7_75t_R  g163(.A1(new_n214_), .A2(new_n215_), .B(new_n221_), .Y(new_n222_));
  XNOR2x2_ASAP7_75t_R g164(.A(new_n220_), .B(new_n222_), .Y(new_n223_));
  AND2x2_ASAP7_75t_R  g165(.A(new_n70_), .B(new_n223_), .Y(G1901));
  AND2x2_ASAP7_75t_R  g166(.A(new_n62_), .B(G25), .Y(new_n225_));
  OA21x2_ASAP7_75t_R  g167(.A1(new_n214_), .A2(new_n215_), .B(new_n225_), .Y(new_n226_));
  XOR2x2_ASAP7_75t_R  g168(.A(new_n147_), .B(new_n226_), .Y(new_n227_));
  AND2x2_ASAP7_75t_R  g169(.A(new_n70_), .B(new_n227_), .Y(G1902));
  AND2x2_ASAP7_75t_R  g170(.A(new_n62_), .B(G27), .Y(new_n229_));
  OA21x2_ASAP7_75t_R  g171(.A1(new_n214_), .A2(new_n215_), .B(new_n229_), .Y(new_n230_));
  XOR2x2_ASAP7_75t_R  g172(.A(new_n96_), .B(new_n230_), .Y(new_n231_));
  AND2x2_ASAP7_75t_R  g173(.A(new_n70_), .B(new_n231_), .Y(G1903));
  AND2x2_ASAP7_75t_R  g174(.A(new_n62_), .B(G28), .Y(new_n233_));
  OA21x2_ASAP7_75t_R  g175(.A1(new_n214_), .A2(new_n215_), .B(new_n233_), .Y(new_n234_));
  XOR2x2_ASAP7_75t_R  g176(.A(new_n80_), .B(new_n234_), .Y(new_n235_));
  AND2x2_ASAP7_75t_R  g177(.A(new_n70_), .B(new_n235_), .Y(G1904));
  AND3x1_ASAP7_75t_R  g178(.A(new_n62_), .B(G19), .C(G23), .Y(new_n237_));
  OA21x2_ASAP7_75t_R  g179(.A1(new_n214_), .A2(new_n215_), .B(new_n237_), .Y(new_n238_));
  XOR2x2_ASAP7_75t_R  g180(.A(new_n108_), .B(new_n238_), .Y(new_n239_));
  AND2x2_ASAP7_75t_R  g181(.A(new_n70_), .B(new_n239_), .Y(G1905));
  NAND2x1_ASAP7_75t_R g182(.A(new_n61_), .B(new_n215_), .Y(new_n241_));
  OA21x2_ASAP7_75t_R  g183(.A1(G33), .A2(G29), .B(new_n166_), .Y(new_n242_));
  XOR2x2_ASAP7_75t_R  g184(.A(new_n241_), .B(new_n242_), .Y(new_n243_));
  AO21x1_ASAP7_75t_R  g185(.A1(G21), .A2(G29), .B(G33), .Y(new_n244_));
  XOR2x2_ASAP7_75t_R  g186(.A(new_n243_), .B(new_n244_), .Y(G1906));
  XOR2x2_ASAP7_75t_R  g187(.A(G9), .B(G14), .Y(new_n246_));
  XOR2x2_ASAP7_75t_R  g188(.A(new_n122_), .B(new_n246_), .Y(new_n247_));
  OAI21x1_ASAP7_75t_R g189(.A1(G33), .A2(G30), .B(new_n247_), .Y(new_n248_));
  AND3x1_ASAP7_75t_R  g190(.A(new_n61_), .B(new_n214_), .C(new_n248_), .Y(new_n249_));
  AOI21x1_ASAP7_75t_R g191(.A1(new_n61_), .A2(new_n214_), .B(new_n248_), .Y(new_n250_));
  NOR2x1_ASAP7_75t_R  g192(.A(new_n249_), .B(new_n250_), .Y(new_n251_));
  AO21x1_ASAP7_75t_R  g193(.A1(G30), .A2(G22), .B(G33), .Y(new_n252_));
  XOR2x2_ASAP7_75t_R  g194(.A(new_n251_), .B(new_n252_), .Y(G1907));
  AND2x2_ASAP7_75t_R  g195(.A(new_n62_), .B(G26), .Y(new_n254_));
  OA21x2_ASAP7_75t_R  g196(.A1(new_n214_), .A2(new_n215_), .B(new_n254_), .Y(new_n255_));
  AO21x1_ASAP7_75t_R  g197(.A1(new_n126_), .A2(new_n127_), .B(new_n255_), .Y(new_n256_));
  NAND2x1_ASAP7_75t_R g198(.A(new_n128_), .B(new_n255_), .Y(new_n257_));
  AOI21x1_ASAP7_75t_R g199(.A1(new_n256_), .A2(new_n257_), .B(new_n113_), .Y(new_n258_));
  AND3x1_ASAP7_75t_R  g200(.A(new_n113_), .B(new_n256_), .C(new_n257_), .Y(new_n259_));
  OA21x2_ASAP7_75t_R  g201(.A1(new_n258_), .A2(new_n259_), .B(new_n70_), .Y(G1908));
endmodule


