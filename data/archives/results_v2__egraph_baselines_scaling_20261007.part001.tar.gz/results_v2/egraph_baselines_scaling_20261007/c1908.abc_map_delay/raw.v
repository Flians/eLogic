// Benchmark "/home/flynn/workplace/MIGBalance/tools/mockturtle/experiments/benchmarks/c1908" written by ABC on Wed Oct  7 15:36:42 2026

module \/home/flynn/workplace/MIGBalance/tools/mockturtle/experiments/benchmarks/c1908  ( 
    G23, G24, G33, G31, G30, G32, G8, G6, G3, G15, G10, G12, G19, G28, G9,
    G14, G16, G18, G11, G5, G2, G27, G7, G4, G20, G13, G1, G17, G26, G22,
    G25, G21, G29,
    G1899, G1884, G1885, G1898, G1886, G1887, G1888, G1889, G1890, G1891,
    G1892, G1893, G1894, G1895, G1896, G1897, G1900, G1901, G1902, G1903,
    G1904, G1905, G1906, G1907, G1908  );
  input  G23, G24, G33, G31, G30, G32, G8, G6, G3, G15, G10, G12, G19,
    G28, G9, G14, G16, G18, G11, G5, G2, G27, G7, G4, G20, G13, G1, G17,
    G26, G22, G25, G21, G29;
  output G1899, G1884, G1885, G1898, G1886, G1887, G1888, G1889, G1890, G1891,
    G1892, G1893, G1894, G1895, G1896, G1897, G1900, G1901, G1902, G1903,
    G1904, G1905, G1906, G1907, G1908;
  wire new_n59_, new_n60_, new_n61_, new_n62_, new_n63_, new_n64_, new_n65_,
    new_n66_, new_n67_, new_n68_, new_n69_, new_n70_, new_n71_, new_n72_,
    new_n73_, new_n74_, new_n75_, new_n76_, new_n77_, new_n78_, new_n79_,
    new_n80_, new_n81_, new_n82_, new_n83_, new_n84_, new_n85_, new_n86_,
    new_n87_, new_n88_, new_n89_, new_n90_, new_n91_, new_n92_, new_n93_,
    new_n94_, new_n95_, new_n96_, new_n97_, new_n98_, new_n99_, new_n100_,
    new_n101_, new_n102_, new_n103_, new_n104_, new_n105_, new_n106_,
    new_n107_, new_n108_, new_n109_, new_n110_, new_n111_, new_n112_,
    new_n113_, new_n114_, new_n115_, new_n116_, new_n117_, new_n118_,
    new_n119_, new_n120_, new_n121_, new_n122_, new_n123_, new_n124_,
    new_n125_, new_n126_, new_n127_, new_n128_, new_n129_, new_n130_,
    new_n131_, new_n132_, new_n133_, new_n134_, new_n135_, new_n136_,
    new_n137_, new_n138_, new_n139_, new_n140_, new_n141_, new_n142_,
    new_n143_, new_n144_, new_n145_, new_n146_, new_n147_, new_n148_,
    new_n149_, new_n150_, new_n151_, new_n152_, new_n153_, new_n154_,
    new_n155_, new_n156_, new_n157_, new_n158_, new_n159_, new_n160_,
    new_n161_, new_n162_, new_n163_, new_n164_, new_n165_, new_n166_,
    new_n167_, new_n168_, new_n169_, new_n170_, new_n171_, new_n172_,
    new_n173_, new_n174_, new_n175_, new_n176_, new_n177_, new_n179_,
    new_n180_, new_n181_, new_n182_, new_n183_, new_n184_, new_n185_,
    new_n191_, new_n195_, new_n196_, new_n197_, new_n198_, new_n199_,
    new_n204_, new_n205_, new_n209_, new_n210_, new_n211_, new_n212_,
    new_n213_, new_n214_, new_n215_, new_n216_, new_n217_, new_n218_,
    new_n219_, new_n220_, new_n221_, new_n222_, new_n223_, new_n225_,
    new_n226_, new_n227_, new_n228_, new_n229_, new_n231_, new_n232_,
    new_n233_, new_n234_, new_n236_, new_n237_, new_n238_, new_n239_,
    new_n241_, new_n242_, new_n243_, new_n245_, new_n246_, new_n247_,
    new_n249_, new_n250_, new_n251_, new_n252_, new_n253_, new_n255_,
    new_n256_, new_n257_, new_n258_, new_n259_, new_n260_, new_n261_,
    new_n262_, new_n263_, new_n265_, new_n266_, new_n267_, new_n268_,
    new_n269_, new_n270_, new_n271_, new_n272_, new_n273_;
  INVx1_ASAP7_75t_R   g000(.A(G23), .Y(new_n59_));
  AO21x1_ASAP7_75t_R  g001(.A1(new_n59_), .A2(G24), .B(G33), .Y(new_n60_));
  OR3x1_ASAP7_75t_R   g002(.A(new_n60_), .B(G31), .C(G30), .Y(new_n61_));
  NOR2x1_ASAP7_75t_R  g003(.A(G33), .B(G32), .Y(new_n62_));
  INVx1_ASAP7_75t_R   g004(.A(new_n62_), .Y(new_n63_));
  AO21x1_ASAP7_75t_R  g005(.A1(new_n59_), .A2(G24), .B(new_n63_), .Y(new_n64_));
  NAND2x1_ASAP7_75t_R g006(.A(new_n64_), .B(new_n61_), .Y(new_n65_));
  INVx1_ASAP7_75t_R   g007(.A(G31), .Y(new_n66_));
  INVx1_ASAP7_75t_R   g008(.A(G3), .Y(new_n67_));
  XOR2x2_ASAP7_75t_R  g009(.A(G8), .B(G6), .Y(new_n68_));
  XOR2x2_ASAP7_75t_R  g010(.A(new_n68_), .B(new_n67_), .Y(new_n69_));
  INVx1_ASAP7_75t_R   g011(.A(G12), .Y(new_n70_));
  XOR2x2_ASAP7_75t_R  g012(.A(G15), .B(G10), .Y(new_n71_));
  XOR2x2_ASAP7_75t_R  g013(.A(new_n71_), .B(new_n70_), .Y(new_n72_));
  XOR2x2_ASAP7_75t_R  g014(.A(new_n69_), .B(new_n72_), .Y(new_n73_));
  INVx1_ASAP7_75t_R   g015(.A(G33), .Y(new_n74_));
  AND3x1_ASAP7_75t_R  g016(.A(new_n59_), .B(new_n74_), .C(G19), .Y(new_n75_));
  XOR2x2_ASAP7_75t_R  g017(.A(new_n73_), .B(new_n75_), .Y(new_n76_));
  NAND2x1_ASAP7_75t_R g018(.A(new_n66_), .B(new_n76_), .Y(new_n77_));
  XOR2x2_ASAP7_75t_R  g019(.A(new_n77_), .B(G28), .Y(new_n78_));
  INVx1_ASAP7_75t_R   g020(.A(G16), .Y(new_n79_));
  XOR2x2_ASAP7_75t_R  g021(.A(G9), .B(G14), .Y(new_n80_));
  XOR2x2_ASAP7_75t_R  g022(.A(new_n80_), .B(new_n79_), .Y(new_n81_));
  INVx1_ASAP7_75t_R   g023(.A(G15), .Y(new_n82_));
  INVx1_ASAP7_75t_R   g024(.A(G24), .Y(new_n83_));
  AND3x1_ASAP7_75t_R  g025(.A(new_n83_), .B(new_n74_), .C(G18), .Y(new_n84_));
  XOR2x2_ASAP7_75t_R  g026(.A(new_n84_), .B(new_n82_), .Y(new_n85_));
  NOR2x1_ASAP7_75t_R  g027(.A(G11), .B(new_n85_), .Y(new_n86_));
  AND2x2_ASAP7_75t_R  g028(.A(new_n85_), .B(G11), .Y(new_n87_));
  OR3x1_ASAP7_75t_R   g029(.A(new_n86_), .B(new_n87_), .C(new_n81_), .Y(new_n88_));
  OAI21x1_ASAP7_75t_R g030(.A1(new_n87_), .A2(new_n86_), .B(new_n81_), .Y(new_n89_));
  XOR2x2_ASAP7_75t_R  g031(.A(G8), .B(G5), .Y(new_n90_));
  XOR2x2_ASAP7_75t_R  g032(.A(new_n90_), .B(G2), .Y(new_n91_));
  AOI21x1_ASAP7_75t_R g033(.A1(new_n89_), .A2(new_n88_), .B(new_n91_), .Y(new_n92_));
  AND3x1_ASAP7_75t_R  g034(.A(new_n88_), .B(new_n89_), .C(new_n91_), .Y(new_n93_));
  OAI21x1_ASAP7_75t_R g035(.A1(new_n92_), .A2(new_n93_), .B(new_n66_), .Y(new_n94_));
  XOR2x2_ASAP7_75t_R  g036(.A(new_n94_), .B(G27), .Y(new_n95_));
  AND3x1_ASAP7_75t_R  g037(.A(new_n95_), .B(new_n65_), .C(new_n78_), .Y(new_n96_));
  XOR2x2_ASAP7_75t_R  g038(.A(G10), .B(G7), .Y(new_n97_));
  XOR2x2_ASAP7_75t_R  g039(.A(new_n97_), .B(G4), .Y(new_n98_));
  XOR2x2_ASAP7_75t_R  g040(.A(new_n81_), .B(new_n98_), .Y(new_n99_));
  INVx1_ASAP7_75t_R   g041(.A(G13), .Y(new_n100_));
  AND3x1_ASAP7_75t_R  g042(.A(new_n59_), .B(new_n74_), .C(G20), .Y(new_n101_));
  XOR2x2_ASAP7_75t_R  g043(.A(new_n101_), .B(new_n100_), .Y(new_n102_));
  NOR2x1_ASAP7_75t_R  g044(.A(new_n102_), .B(new_n99_), .Y(new_n103_));
  AND2x2_ASAP7_75t_R  g045(.A(new_n99_), .B(new_n102_), .Y(new_n104_));
  OR2x4_ASAP7_75t_R   g046(.A(new_n104_), .B(new_n103_), .Y(new_n105_));
  NAND2x1_ASAP7_75t_R g047(.A(new_n66_), .B(new_n105_), .Y(new_n106_));
  OA21x2_ASAP7_75t_R  g048(.A1(G23), .A2(G31), .B(G19), .Y(new_n107_));
  XOR2x2_ASAP7_75t_R  g049(.A(new_n106_), .B(new_n107_), .Y(new_n108_));
  INVx1_ASAP7_75t_R   g050(.A(G26), .Y(new_n109_));
  AND3x1_ASAP7_75t_R  g051(.A(new_n83_), .B(new_n74_), .C(G17), .Y(new_n110_));
  XOR2x2_ASAP7_75t_R  g052(.A(new_n110_), .B(G1), .Y(new_n111_));
  XOR2x2_ASAP7_75t_R  g053(.A(G12), .B(G13), .Y(new_n112_));
  XOR2x2_ASAP7_75t_R  g054(.A(new_n112_), .B(G11), .Y(new_n113_));
  AND2x2_ASAP7_75t_R  g055(.A(G15), .B(G16), .Y(new_n114_));
  NOR2x1_ASAP7_75t_R  g056(.A(G15), .B(G16), .Y(new_n115_));
  OA21x2_ASAP7_75t_R  g057(.A1(new_n115_), .A2(new_n114_), .B(G10), .Y(new_n116_));
  INVx1_ASAP7_75t_R   g058(.A(G10), .Y(new_n117_));
  NAND2x1_ASAP7_75t_R g059(.A(G15), .B(G16), .Y(new_n118_));
  OR2x4_ASAP7_75t_R   g060(.A(G15), .B(G16), .Y(new_n119_));
  AND3x1_ASAP7_75t_R  g061(.A(new_n119_), .B(new_n117_), .C(new_n118_), .Y(new_n120_));
  NOR2x1_ASAP7_75t_R  g062(.A(new_n116_), .B(new_n120_), .Y(new_n121_));
  NAND2x1_ASAP7_75t_R g063(.A(new_n113_), .B(new_n121_), .Y(new_n122_));
  AO21x1_ASAP7_75t_R  g064(.A1(new_n119_), .A2(new_n118_), .B(new_n117_), .Y(new_n123_));
  OR3x1_ASAP7_75t_R   g065(.A(new_n115_), .B(G10), .C(new_n114_), .Y(new_n124_));
  AO21x1_ASAP7_75t_R  g066(.A1(new_n123_), .A2(new_n124_), .B(new_n113_), .Y(new_n125_));
  XOR2x2_ASAP7_75t_R  g067(.A(G6), .B(G7), .Y(new_n126_));
  XOR2x2_ASAP7_75t_R  g068(.A(new_n126_), .B(G5), .Y(new_n127_));
  AOI21x1_ASAP7_75t_R g069(.A1(new_n125_), .A2(new_n122_), .B(new_n127_), .Y(new_n128_));
  AND3x1_ASAP7_75t_R  g070(.A(new_n122_), .B(new_n125_), .C(new_n127_), .Y(new_n129_));
  OAI21x1_ASAP7_75t_R g071(.A1(new_n128_), .A2(new_n129_), .B(new_n111_), .Y(new_n130_));
  OR3x1_ASAP7_75t_R   g072(.A(new_n129_), .B(new_n111_), .C(new_n128_), .Y(new_n131_));
  AOI21x1_ASAP7_75t_R g073(.A1(new_n130_), .A2(new_n131_), .B(G31), .Y(new_n132_));
  NAND2x1_ASAP7_75t_R g074(.A(new_n109_), .B(new_n132_), .Y(new_n133_));
  OR2x4_ASAP7_75t_R   g075(.A(new_n109_), .B(new_n132_), .Y(new_n134_));
  AND2x2_ASAP7_75t_R  g076(.A(new_n134_), .B(new_n133_), .Y(new_n135_));
  AND2x2_ASAP7_75t_R  g077(.A(new_n135_), .B(new_n108_), .Y(new_n136_));
  OA21x2_ASAP7_75t_R  g078(.A1(G23), .A2(G31), .B(G20), .Y(new_n137_));
  INVx1_ASAP7_75t_R   g079(.A(new_n137_), .Y(new_n138_));
  INVx1_ASAP7_75t_R   g080(.A(G25), .Y(new_n139_));
  XNOR2x2_ASAP7_75t_R g081(.A(G14), .B(G4), .Y(new_n140_));
  NAND2x1_ASAP7_75t_R g082(.A(G22), .B(new_n74_), .Y(new_n141_));
  XOR2x2_ASAP7_75t_R  g083(.A(new_n140_), .B(new_n141_), .Y(new_n142_));
  INVx1_ASAP7_75t_R   g084(.A(new_n113_), .Y(new_n143_));
  XOR2x2_ASAP7_75t_R  g085(.A(G3), .B(G2), .Y(new_n144_));
  XOR2x2_ASAP7_75t_R  g086(.A(new_n144_), .B(G1), .Y(new_n145_));
  AO21x1_ASAP7_75t_R  g087(.A1(new_n123_), .A2(new_n124_), .B(new_n145_), .Y(new_n146_));
  NAND2x1_ASAP7_75t_R g088(.A(new_n145_), .B(new_n121_), .Y(new_n147_));
  AOI21x1_ASAP7_75t_R g089(.A1(new_n146_), .A2(new_n147_), .B(new_n143_), .Y(new_n148_));
  AND3x1_ASAP7_75t_R  g090(.A(new_n147_), .B(new_n143_), .C(new_n146_), .Y(new_n149_));
  OAI21x1_ASAP7_75t_R g091(.A1(new_n148_), .A2(new_n149_), .B(new_n142_), .Y(new_n150_));
  OR3x1_ASAP7_75t_R   g092(.A(new_n149_), .B(new_n142_), .C(new_n148_), .Y(new_n151_));
  AOI21x1_ASAP7_75t_R g093(.A1(new_n150_), .A2(new_n151_), .B(G31), .Y(new_n152_));
  NAND2x1_ASAP7_75t_R g094(.A(new_n139_), .B(new_n152_), .Y(new_n153_));
  NAND2x1_ASAP7_75t_R g095(.A(new_n150_), .B(new_n151_), .Y(new_n154_));
  AO21x1_ASAP7_75t_R  g096(.A1(new_n154_), .A2(new_n66_), .B(new_n139_), .Y(new_n155_));
  AO21x1_ASAP7_75t_R  g097(.A1(new_n155_), .A2(new_n153_), .B(new_n138_), .Y(new_n156_));
  OA21x2_ASAP7_75t_R  g098(.A1(G24), .A2(G31), .B(G18), .Y(new_n157_));
  AND3x1_ASAP7_75t_R  g099(.A(new_n124_), .B(G9), .C(new_n123_), .Y(new_n158_));
  INVx1_ASAP7_75t_R   g100(.A(G9), .Y(new_n159_));
  OA21x2_ASAP7_75t_R  g101(.A1(new_n120_), .A2(new_n116_), .B(new_n159_), .Y(new_n160_));
  AND2x2_ASAP7_75t_R  g102(.A(new_n74_), .B(G21), .Y(new_n161_));
  OAI21x1_ASAP7_75t_R g103(.A1(new_n160_), .A2(new_n158_), .B(new_n161_), .Y(new_n162_));
  OR3x1_ASAP7_75t_R   g104(.A(new_n158_), .B(new_n160_), .C(new_n161_), .Y(new_n163_));
  NAND2x1_ASAP7_75t_R g105(.A(new_n162_), .B(new_n163_), .Y(new_n164_));
  NAND2x1_ASAP7_75t_R g106(.A(new_n127_), .B(new_n145_), .Y(new_n165_));
  OR2x4_ASAP7_75t_R   g107(.A(new_n127_), .B(new_n145_), .Y(new_n166_));
  XNOR2x2_ASAP7_75t_R g108(.A(G8), .B(G4), .Y(new_n167_));
  INVx1_ASAP7_75t_R   g109(.A(new_n167_), .Y(new_n168_));
  AO21x1_ASAP7_75t_R  g110(.A1(new_n166_), .A2(new_n165_), .B(new_n168_), .Y(new_n169_));
  NAND3x1_ASAP7_75t_R g111(.A(new_n166_), .B(new_n168_), .C(new_n165_), .Y(new_n170_));
  AO21x1_ASAP7_75t_R  g112(.A1(new_n169_), .A2(new_n170_), .B(new_n164_), .Y(new_n171_));
  NAND3x1_ASAP7_75t_R g113(.A(new_n164_), .B(new_n170_), .C(new_n169_), .Y(new_n172_));
  AND3x1_ASAP7_75t_R  g114(.A(new_n172_), .B(new_n66_), .C(new_n171_), .Y(new_n173_));
  OAI21x1_ASAP7_75t_R g115(.A1(G24), .A2(G31), .B(G17), .Y(new_n174_));
  XOR2x2_ASAP7_75t_R  g116(.A(new_n173_), .B(new_n174_), .Y(new_n175_));
  AND3x1_ASAP7_75t_R  g117(.A(new_n175_), .B(new_n156_), .C(new_n157_), .Y(new_n176_));
  NAND3x1_ASAP7_75t_R g118(.A(new_n176_), .B(new_n136_), .C(new_n96_), .Y(new_n177_));
  XOR2x2_ASAP7_75t_R  g119(.A(new_n177_), .B(G14), .Y(G1899));
  NAND2x1_ASAP7_75t_R g120(.A(new_n78_), .B(new_n95_), .Y(new_n179_));
  OR3x1_ASAP7_75t_R   g121(.A(new_n60_), .B(G31), .C(G29), .Y(new_n180_));
  AO21x1_ASAP7_75t_R  g122(.A1(new_n64_), .A2(new_n180_), .B(new_n179_), .Y(new_n181_));
  INVx1_ASAP7_75t_R   g123(.A(new_n157_), .Y(new_n182_));
  OA21x2_ASAP7_75t_R  g124(.A1(new_n175_), .A2(new_n182_), .B(new_n156_), .Y(new_n183_));
  NAND2x1_ASAP7_75t_R g125(.A(new_n183_), .B(new_n136_), .Y(new_n184_));
  NOR2x1_ASAP7_75t_R  g126(.A(new_n181_), .B(new_n184_), .Y(new_n185_));
  XNOR2x2_ASAP7_75t_R g127(.A(G1), .B(new_n185_), .Y(G1884));
  XNOR2x2_ASAP7_75t_R g128(.A(G2), .B(new_n185_), .Y(G1885));
  XOR2x2_ASAP7_75t_R  g129(.A(new_n177_), .B(G13), .Y(G1898));
  XOR2x2_ASAP7_75t_R  g130(.A(new_n185_), .B(new_n67_), .Y(G1886));
  XNOR2x2_ASAP7_75t_R g131(.A(G4), .B(new_n185_), .Y(G1887));
  NAND3x1_ASAP7_75t_R g132(.A(new_n136_), .B(new_n183_), .C(new_n96_), .Y(new_n191_));
  XOR2x2_ASAP7_75t_R  g133(.A(new_n191_), .B(G10), .Y(G1888));
  XOR2x2_ASAP7_75t_R  g134(.A(new_n191_), .B(G15), .Y(G1889));
  XOR2x2_ASAP7_75t_R  g135(.A(new_n191_), .B(G16), .Y(G1890));
  NAND2x1_ASAP7_75t_R g136(.A(new_n108_), .B(new_n135_), .Y(new_n195_));
  AND3x1_ASAP7_75t_R  g137(.A(new_n155_), .B(new_n137_), .C(new_n153_), .Y(new_n196_));
  OAI21x1_ASAP7_75t_R g138(.A1(new_n182_), .A2(new_n175_), .B(new_n196_), .Y(new_n197_));
  OR2x4_ASAP7_75t_R   g139(.A(new_n197_), .B(new_n195_), .Y(new_n198_));
  NOR2x1_ASAP7_75t_R  g140(.A(new_n181_), .B(new_n198_), .Y(new_n199_));
  XNOR2x2_ASAP7_75t_R g141(.A(G5), .B(new_n199_), .Y(G1891));
  XNOR2x2_ASAP7_75t_R g142(.A(G6), .B(new_n199_), .Y(G1892));
  XNOR2x2_ASAP7_75t_R g143(.A(G7), .B(new_n199_), .Y(G1893));
  XNOR2x2_ASAP7_75t_R g144(.A(G8), .B(new_n199_), .Y(G1894));
  NAND3x1_ASAP7_75t_R g145(.A(new_n95_), .B(new_n78_), .C(new_n65_), .Y(new_n204_));
  OR3x1_ASAP7_75t_R   g146(.A(new_n195_), .B(new_n204_), .C(new_n197_), .Y(new_n205_));
  XOR2x2_ASAP7_75t_R  g147(.A(new_n205_), .B(G9), .Y(G1895));
  XOR2x2_ASAP7_75t_R  g148(.A(new_n177_), .B(G11), .Y(G1896));
  XOR2x2_ASAP7_75t_R  g149(.A(new_n177_), .B(G12), .Y(G1897));
  AND3x1_ASAP7_75t_R  g150(.A(new_n155_), .B(new_n153_), .C(new_n182_), .Y(new_n209_));
  AND3x1_ASAP7_75t_R  g151(.A(new_n209_), .B(new_n138_), .C(new_n175_), .Y(new_n210_));
  AND3x1_ASAP7_75t_R  g152(.A(new_n95_), .B(new_n133_), .C(new_n134_), .Y(new_n211_));
  AND3x1_ASAP7_75t_R  g153(.A(new_n211_), .B(new_n78_), .C(new_n108_), .Y(new_n212_));
  AO21x1_ASAP7_75t_R  g154(.A1(new_n212_), .A2(new_n210_), .B(G33), .Y(new_n213_));
  NOR2x1_ASAP7_75t_R  g155(.A(new_n64_), .B(new_n179_), .Y(new_n214_));
  AND3x1_ASAP7_75t_R  g156(.A(new_n196_), .B(new_n157_), .C(new_n175_), .Y(new_n215_));
  AND3x1_ASAP7_75t_R  g157(.A(new_n214_), .B(new_n136_), .C(new_n215_), .Y(new_n216_));
  INVx1_ASAP7_75t_R   g158(.A(new_n198_), .Y(new_n217_));
  AND3x1_ASAP7_75t_R  g159(.A(new_n214_), .B(new_n136_), .C(new_n176_), .Y(new_n218_));
  AO21x1_ASAP7_75t_R  g160(.A1(new_n217_), .A2(new_n214_), .B(new_n218_), .Y(new_n219_));
  AND3x1_ASAP7_75t_R  g161(.A(new_n177_), .B(new_n191_), .C(new_n205_), .Y(new_n220_));
  AO21x1_ASAP7_75t_R  g162(.A1(new_n198_), .A2(new_n184_), .B(new_n181_), .Y(new_n221_));
  NAND2x1_ASAP7_75t_R g163(.A(new_n221_), .B(new_n220_), .Y(new_n222_));
  OR3x1_ASAP7_75t_R   g164(.A(new_n222_), .B(new_n216_), .C(new_n219_), .Y(new_n223_));
  AO21x1_ASAP7_75t_R  g165(.A1(new_n223_), .A2(G32), .B(new_n213_), .Y(G1900));
  NAND2x1_ASAP7_75t_R g166(.A(new_n169_), .B(new_n170_), .Y(new_n225_));
  XOR2x2_ASAP7_75t_R  g167(.A(new_n225_), .B(new_n164_), .Y(new_n226_));
  AND3x1_ASAP7_75t_R  g168(.A(new_n66_), .B(G24), .C(G17), .Y(new_n227_));
  AOI21x1_ASAP7_75t_R g169(.A1(new_n227_), .A2(new_n222_), .B(new_n226_), .Y(new_n228_));
  AND3x1_ASAP7_75t_R  g170(.A(new_n222_), .B(new_n226_), .C(new_n227_), .Y(new_n229_));
  OA21x2_ASAP7_75t_R  g171(.A1(new_n229_), .A2(new_n228_), .B(new_n63_), .Y(G1901));
  INVx1_ASAP7_75t_R   g172(.A(new_n154_), .Y(new_n231_));
  AND2x2_ASAP7_75t_R  g173(.A(new_n66_), .B(G25), .Y(new_n232_));
  AOI21x1_ASAP7_75t_R g174(.A1(new_n232_), .A2(new_n222_), .B(new_n231_), .Y(new_n233_));
  AND3x1_ASAP7_75t_R  g175(.A(new_n222_), .B(new_n231_), .C(new_n232_), .Y(new_n234_));
  OA21x2_ASAP7_75t_R  g176(.A1(new_n234_), .A2(new_n233_), .B(new_n63_), .Y(G1902));
  OR2x4_ASAP7_75t_R   g177(.A(new_n92_), .B(new_n93_), .Y(new_n236_));
  AND2x2_ASAP7_75t_R  g178(.A(new_n66_), .B(G27), .Y(new_n237_));
  AOI21x1_ASAP7_75t_R g179(.A1(new_n237_), .A2(new_n222_), .B(new_n236_), .Y(new_n238_));
  AND3x1_ASAP7_75t_R  g180(.A(new_n222_), .B(new_n236_), .C(new_n237_), .Y(new_n239_));
  OA21x2_ASAP7_75t_R  g181(.A1(new_n239_), .A2(new_n238_), .B(new_n63_), .Y(G1903));
  AND2x2_ASAP7_75t_R  g182(.A(new_n66_), .B(G28), .Y(new_n241_));
  AOI21x1_ASAP7_75t_R g183(.A1(new_n241_), .A2(new_n222_), .B(new_n76_), .Y(new_n242_));
  AND3x1_ASAP7_75t_R  g184(.A(new_n222_), .B(new_n76_), .C(new_n241_), .Y(new_n243_));
  OA21x2_ASAP7_75t_R  g185(.A1(new_n243_), .A2(new_n242_), .B(new_n63_), .Y(G1904));
  AND3x1_ASAP7_75t_R  g186(.A(new_n66_), .B(G23), .C(G19), .Y(new_n245_));
  AOI21x1_ASAP7_75t_R g187(.A1(new_n245_), .A2(new_n222_), .B(new_n105_), .Y(new_n246_));
  AND3x1_ASAP7_75t_R  g188(.A(new_n222_), .B(new_n105_), .C(new_n245_), .Y(new_n247_));
  OA21x2_ASAP7_75t_R  g189(.A1(new_n247_), .A2(new_n246_), .B(new_n63_), .Y(G1905));
  NOR2x1_ASAP7_75t_R  g190(.A(G33), .B(new_n221_), .Y(new_n249_));
  INVx1_ASAP7_75t_R   g191(.A(G29), .Y(new_n250_));
  AO21x1_ASAP7_75t_R  g192(.A1(new_n74_), .A2(new_n250_), .B(new_n225_), .Y(new_n251_));
  XOR2x2_ASAP7_75t_R  g193(.A(new_n249_), .B(new_n251_), .Y(new_n252_));
  AO21x1_ASAP7_75t_R  g194(.A1(G21), .A2(G29), .B(G33), .Y(new_n253_));
  XOR2x2_ASAP7_75t_R  g195(.A(new_n252_), .B(new_n253_), .Y(G1906));
  NAND3x1_ASAP7_75t_R g196(.A(new_n177_), .B(new_n205_), .C(new_n191_), .Y(new_n255_));
  AND2x2_ASAP7_75t_R  g197(.A(new_n122_), .B(new_n125_), .Y(new_n256_));
  XNOR2x2_ASAP7_75t_R g198(.A(G9), .B(G14), .Y(new_n257_));
  XOR2x2_ASAP7_75t_R  g199(.A(new_n256_), .B(new_n257_), .Y(new_n258_));
  OAI21x1_ASAP7_75t_R g200(.A1(G33), .A2(G30), .B(new_n258_), .Y(new_n259_));
  AND3x1_ASAP7_75t_R  g201(.A(new_n255_), .B(new_n74_), .C(new_n259_), .Y(new_n260_));
  AOI21x1_ASAP7_75t_R g202(.A1(new_n74_), .A2(new_n255_), .B(new_n259_), .Y(new_n261_));
  NOR2x1_ASAP7_75t_R  g203(.A(new_n261_), .B(new_n260_), .Y(new_n262_));
  AO21x1_ASAP7_75t_R  g204(.A1(G30), .A2(G22), .B(G33), .Y(new_n263_));
  XOR2x2_ASAP7_75t_R  g205(.A(new_n262_), .B(new_n263_), .Y(G1907));
  INVx1_ASAP7_75t_R   g206(.A(new_n111_), .Y(new_n265_));
  NAND2x1_ASAP7_75t_R g207(.A(G26), .B(new_n66_), .Y(new_n266_));
  AO21x1_ASAP7_75t_R  g208(.A1(new_n220_), .A2(new_n221_), .B(new_n266_), .Y(new_n267_));
  OAI21x1_ASAP7_75t_R g209(.A1(new_n128_), .A2(new_n129_), .B(new_n267_), .Y(new_n268_));
  NOR2x1_ASAP7_75t_R  g210(.A(new_n128_), .B(new_n129_), .Y(new_n269_));
  AOI21x1_ASAP7_75t_R g211(.A1(new_n221_), .A2(new_n220_), .B(new_n266_), .Y(new_n270_));
  NAND2x1_ASAP7_75t_R g212(.A(new_n269_), .B(new_n270_), .Y(new_n271_));
  AOI21x1_ASAP7_75t_R g213(.A1(new_n268_), .A2(new_n271_), .B(new_n265_), .Y(new_n272_));
  AND3x1_ASAP7_75t_R  g214(.A(new_n271_), .B(new_n265_), .C(new_n268_), .Y(new_n273_));
  OA21x2_ASAP7_75t_R  g215(.A1(new_n273_), .A2(new_n272_), .B(new_n63_), .Y(G1908));
endmodule


