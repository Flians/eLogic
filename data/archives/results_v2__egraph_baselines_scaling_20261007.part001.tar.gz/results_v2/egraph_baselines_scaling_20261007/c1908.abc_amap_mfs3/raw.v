// Benchmark "/home/flynn/workplace/MIGBalance/tools/mockturtle/experiments/benchmarks/c1908" written by ABC on Wed Oct  7 15:36:44 2026

module \/home/flynn/workplace/MIGBalance/tools/mockturtle/experiments/benchmarks/c1908  ( 
    G23, G24, G33, G31, G30, G32, G8, G6, G3, G15, G10, G12, G19, G28, G9,
    G14, G16, G18, G11, G5, G2, G27, G7, G4, G20, G13, G1, G17, G26, G22,
    G25, G21, G29,
    G1899, G1884, G1885, G1898, G1886, G1887, G1888, G1889, G1890, G1891,
    G1892, G1893, G1894, G1895, G1896, G1897, G1900, G1901, G1902, G1903,
    G1904, G1905, G1906, G1907, G1908  );
  input  G23, G24, G33, G31, G30, G32, G8, G6, G3, G15, G10, G12, G19,
    G28, G9, G14, G16, G18, G11, G5, G2, G27, G7, G4, G20, G13, G1, G17,
    G26, G22, G25, G21, G29;
  output G1899, G1884, G1885, G1898, G1886, G1887, G1888, G1889, G1890, G1891,
    G1892, G1893, G1894, G1895, G1896, G1897, G1900, G1901, G1902, G1903,
    G1904, G1905, G1906, G1907, G1908;
  wire new_n83_, new_n84_, new_n86_, new_n87_, new_n88_, new_n89_, new_n90_,
    new_n91_, new_n92_, new_n93_, new_n94_, new_n96_, new_n97_, new_n98_,
    new_n99_, new_n100_, new_n101_, new_n102_, new_n103_, new_n104_,
    new_n105_, new_n106_, new_n107_, new_n108_, new_n109_, new_n110_,
    new_n111_, new_n112_, new_n113_, new_n114_, new_n115_, new_n116_,
    new_n117_, new_n118_, new_n119_, new_n120_, new_n123_, new_n124_,
    new_n125_, new_n126_, new_n127_, new_n128_, new_n129_, new_n130_,
    new_n131_, new_n133_, new_n134_, new_n135_, new_n136_, new_n137_,
    new_n140_, new_n141_, new_n142_, new_n143_, new_n144_, new_n146_,
    new_n147_, new_n148_, new_n149_, new_n150_, new_n151_, new_n153_,
    new_n154_, new_n155_, new_n156_, new_n157_, new_n158_, new_n161_,
    new_n162_, new_n163_, new_n164_, new_n165_, new_n172_, new_n177_,
    new_n178_, new_n179_, new_n185_, new_n189_, new_n190_, new_n194_,
    new_n204_, new_n208_, new_n209_, new_n210_, new_n212_, new_n213_,
    new_n215_, new_n216_, new_n218_, new_n219_, new_n221_, new_n222_,
    new_n225_, new_n226_, new_n227_, new_n230_, new_n231_, new_n232_,
    new_n233_, new_n234_, new_n240_, new_n241_, new_n242_, new_n243_,
    new_n244_, new_n245_, new_n246_, new_n247_, new_n248_, new_n249_,
    new_n250_, new_n251_, new_n255_, new_n263_, new_n265_;
  AO21x1_ASAP7_75t_R  g000(.A1(new_n240_), .A2(G24), .B(G33), .Y(new_n83_));
  OR3x1_ASAP7_75t_R   g001(.A(G31), .B(G30), .C(new_n83_), .Y(new_n84_));
  XNOR2x2_ASAP7_75t_R g002(.A(G8), .B(G6), .Y(new_n86_));
  XOR2x2_ASAP7_75t_R  g003(.A(G3), .B(new_n86_), .Y(new_n87_));
  XNOR2x2_ASAP7_75t_R g004(.A(G15), .B(G10), .Y(new_n88_));
  XNOR2x2_ASAP7_75t_R g005(.A(G12), .B(new_n88_), .Y(new_n89_));
  XOR2x2_ASAP7_75t_R  g006(.A(new_n87_), .B(new_n89_), .Y(new_n90_));
  AND3x1_ASAP7_75t_R  g007(.A(new_n240_), .B(G19), .C(new_n242_), .Y(new_n91_));
  XNOR2x2_ASAP7_75t_R g008(.A(new_n90_), .B(new_n91_), .Y(new_n92_));
  NAND2x1_ASAP7_75t_R g009(.A(new_n243_), .B(new_n92_), .Y(new_n93_));
  XNOR2x2_ASAP7_75t_R g010(.A(G28), .B(new_n93_), .Y(new_n94_));
  XOR2x2_ASAP7_75t_R  g011(.A(G16), .B(new_n230_), .Y(new_n96_));
  AND3x1_ASAP7_75t_R  g012(.A(new_n241_), .B(G18), .C(new_n242_), .Y(new_n97_));
  XNOR2x2_ASAP7_75t_R g013(.A(G15), .B(new_n97_), .Y(new_n98_));
  XNOR2x2_ASAP7_75t_R g014(.A(G11), .B(new_n98_), .Y(new_n99_));
  XOR2x2_ASAP7_75t_R  g015(.A(new_n96_), .B(new_n99_), .Y(new_n100_));
  XNOR2x2_ASAP7_75t_R g016(.A(G8), .B(G5), .Y(new_n101_));
  XNOR2x2_ASAP7_75t_R g017(.A(G2), .B(new_n101_), .Y(new_n102_));
  XNOR2x2_ASAP7_75t_R g018(.A(new_n100_), .B(new_n102_), .Y(new_n103_));
  NAND2x1_ASAP7_75t_R g019(.A(new_n243_), .B(new_n103_), .Y(new_n104_));
  XNOR2x2_ASAP7_75t_R g020(.A(G27), .B(new_n104_), .Y(new_n105_));
  OR2x4_ASAP7_75t_R   g021(.A(new_n94_), .B(new_n105_), .Y(new_n106_));
  AO21x1_ASAP7_75t_R  g022(.A1(new_n84_), .A2(new_n247_), .B(new_n106_), .Y(new_n107_));
  XNOR2x2_ASAP7_75t_R g023(.A(G10), .B(G7), .Y(new_n108_));
  XOR2x2_ASAP7_75t_R  g024(.A(G4), .B(new_n108_), .Y(new_n109_));
  XNOR2x2_ASAP7_75t_R g025(.A(new_n96_), .B(new_n109_), .Y(new_n110_));
  OR3x1_ASAP7_75t_R   g026(.A(G23), .B(new_n245_), .C(G33), .Y(new_n111_));
  XOR2x2_ASAP7_75t_R  g027(.A(G13), .B(new_n111_), .Y(new_n112_));
  XNOR2x2_ASAP7_75t_R g028(.A(new_n110_), .B(new_n112_), .Y(new_n113_));
  NAND2x1_ASAP7_75t_R g029(.A(new_n243_), .B(new_n113_), .Y(new_n114_));
  OA21x2_ASAP7_75t_R  g030(.A1(G23), .A2(G31), .B(G19), .Y(new_n115_));
  XNOR2x2_ASAP7_75t_R g031(.A(new_n114_), .B(new_n115_), .Y(new_n116_));
  OR3x1_ASAP7_75t_R   g032(.A(G24), .B(new_n246_), .C(G33), .Y(new_n117_));
  XOR2x2_ASAP7_75t_R  g033(.A(G1), .B(new_n117_), .Y(new_n118_));
  XOR2x2_ASAP7_75t_R  g034(.A(G12), .B(G13), .Y(new_n119_));
  XNOR2x2_ASAP7_75t_R g035(.A(G11), .B(new_n119_), .Y(new_n120_));
  XOR2x2_ASAP7_75t_R  g036(.A(new_n120_), .B(new_n248_), .Y(new_n123_));
  XOR2x2_ASAP7_75t_R  g037(.A(G6), .B(G7), .Y(new_n124_));
  XNOR2x2_ASAP7_75t_R g038(.A(G5), .B(new_n124_), .Y(new_n125_));
  XNOR2x2_ASAP7_75t_R g039(.A(new_n123_), .B(new_n125_), .Y(new_n126_));
  XOR2x2_ASAP7_75t_R  g040(.A(new_n118_), .B(new_n126_), .Y(new_n127_));
  NOR2x1_ASAP7_75t_R  g041(.A(G31), .B(new_n127_), .Y(new_n128_));
  XOR2x2_ASAP7_75t_R  g042(.A(G26), .B(new_n128_), .Y(new_n129_));
  OR2x4_ASAP7_75t_R   g043(.A(new_n116_), .B(new_n129_), .Y(new_n130_));
  AO21x1_ASAP7_75t_R  g044(.A1(new_n240_), .A2(new_n243_), .B(new_n245_), .Y(new_n131_));
  XOR2x2_ASAP7_75t_R  g045(.A(G14), .B(G4), .Y(new_n133_));
  NAND2x1_ASAP7_75t_R g046(.A(new_n242_), .B(G22), .Y(new_n134_));
  XOR2x2_ASAP7_75t_R  g047(.A(new_n133_), .B(new_n134_), .Y(new_n135_));
  XOR2x2_ASAP7_75t_R  g048(.A(G3), .B(G2), .Y(new_n136_));
  XNOR2x2_ASAP7_75t_R g049(.A(G1), .B(new_n136_), .Y(new_n137_));
  XOR2x2_ASAP7_75t_R  g050(.A(new_n135_), .B(new_n250_), .Y(new_n140_));
  NOR2x1_ASAP7_75t_R  g051(.A(G31), .B(new_n140_), .Y(new_n141_));
  XNOR2x2_ASAP7_75t_R g052(.A(G25), .B(new_n141_), .Y(new_n142_));
  NOR2x1_ASAP7_75t_R  g053(.A(new_n131_), .B(new_n142_), .Y(new_n143_));
  OA21x2_ASAP7_75t_R  g054(.A1(G24), .A2(G31), .B(G18), .Y(new_n144_));
  XNOR2x2_ASAP7_75t_R g055(.A(G9), .B(new_n248_), .Y(new_n146_));
  NAND2x1_ASAP7_75t_R g056(.A(new_n242_), .B(G21), .Y(new_n147_));
  XOR2x2_ASAP7_75t_R  g057(.A(new_n146_), .B(new_n147_), .Y(new_n148_));
  XOR2x2_ASAP7_75t_R  g058(.A(new_n125_), .B(new_n137_), .Y(new_n149_));
  XOR2x2_ASAP7_75t_R  g059(.A(G8), .B(G4), .Y(new_n150_));
  XOR2x2_ASAP7_75t_R  g060(.A(new_n149_), .B(new_n150_), .Y(new_n151_));
  NOR2x1_ASAP7_75t_R  g061(.A(G31), .B(new_n208_), .Y(new_n153_));
  AO21x1_ASAP7_75t_R  g062(.A1(new_n241_), .A2(new_n243_), .B(new_n246_), .Y(new_n154_));
  XNOR2x2_ASAP7_75t_R g063(.A(new_n153_), .B(new_n154_), .Y(new_n155_));
  OR2x4_ASAP7_75t_R   g064(.A(new_n251_), .B(new_n155_), .Y(new_n156_));
  OR3x1_ASAP7_75t_R   g065(.A(new_n143_), .B(new_n156_), .C(new_n130_), .Y(new_n157_));
  NOR2x1_ASAP7_75t_R  g066(.A(new_n107_), .B(new_n157_), .Y(new_n158_));
  XNOR2x2_ASAP7_75t_R g067(.A(G14), .B(new_n158_), .Y(G1899));
  OR3x1_ASAP7_75t_R   g068(.A(G31), .B(G29), .C(new_n83_), .Y(new_n161_));
  AO21x1_ASAP7_75t_R  g069(.A1(new_n247_), .A2(new_n161_), .B(new_n106_), .Y(new_n162_));
  AND2x2_ASAP7_75t_R  g070(.A(new_n144_), .B(new_n155_), .Y(new_n163_));
  OR3x1_ASAP7_75t_R   g071(.A(new_n143_), .B(new_n163_), .C(new_n130_), .Y(new_n164_));
  NOR2x1_ASAP7_75t_R  g072(.A(new_n162_), .B(new_n164_), .Y(new_n165_));
  XNOR2x2_ASAP7_75t_R g073(.A(G1), .B(new_n165_), .Y(G1884));
  XNOR2x2_ASAP7_75t_R g074(.A(G2), .B(new_n165_), .Y(G1885));
  XNOR2x2_ASAP7_75t_R g075(.A(G13), .B(new_n158_), .Y(G1898));
  XNOR2x2_ASAP7_75t_R g076(.A(G3), .B(new_n165_), .Y(G1886));
  XNOR2x2_ASAP7_75t_R g077(.A(G4), .B(new_n165_), .Y(G1887));
  NOR2x1_ASAP7_75t_R  g078(.A(new_n107_), .B(new_n164_), .Y(new_n172_));
  XNOR2x2_ASAP7_75t_R g079(.A(G10), .B(new_n172_), .Y(G1888));
  XNOR2x2_ASAP7_75t_R g080(.A(G15), .B(new_n172_), .Y(G1889));
  XNOR2x2_ASAP7_75t_R g081(.A(G16), .B(new_n172_), .Y(G1890));
  NAND2x1_ASAP7_75t_R g082(.A(new_n249_), .B(new_n142_), .Y(new_n177_));
  OR3x1_ASAP7_75t_R   g083(.A(new_n163_), .B(new_n177_), .C(new_n130_), .Y(new_n178_));
  NOR2x1_ASAP7_75t_R  g084(.A(new_n162_), .B(new_n178_), .Y(new_n179_));
  XNOR2x2_ASAP7_75t_R g085(.A(G5), .B(new_n179_), .Y(G1891));
  XNOR2x2_ASAP7_75t_R g086(.A(G6), .B(new_n179_), .Y(G1892));
  XNOR2x2_ASAP7_75t_R g087(.A(G7), .B(new_n179_), .Y(G1893));
  XNOR2x2_ASAP7_75t_R g088(.A(G8), .B(new_n179_), .Y(G1894));
  NOR2x1_ASAP7_75t_R  g089(.A(new_n107_), .B(new_n178_), .Y(new_n185_));
  XNOR2x2_ASAP7_75t_R g090(.A(G9), .B(new_n185_), .Y(G1895));
  XNOR2x2_ASAP7_75t_R g091(.A(G11), .B(new_n158_), .Y(G1896));
  XNOR2x2_ASAP7_75t_R g092(.A(G12), .B(new_n158_), .Y(G1897));
  NOR2x1_ASAP7_75t_R  g093(.A(new_n249_), .B(new_n155_), .Y(new_n189_));
  AND3x1_ASAP7_75t_R  g094(.A(new_n142_), .B(new_n251_), .C(new_n189_), .Y(new_n190_));
  AO21x1_ASAP7_75t_R  g095(.A1(new_n190_), .A2(new_n255_), .B(G33), .Y(new_n194_));
  OR3x1_ASAP7_75t_R   g096(.A(new_n165_), .B(new_n179_), .C(new_n172_), .Y(new_n204_));
  XOR2x2_ASAP7_75t_R  g097(.A(new_n148_), .B(new_n151_), .Y(new_n208_));
  OR3x1_ASAP7_75t_R   g098(.A(G31), .B(new_n154_), .C(new_n263_), .Y(new_n209_));
  XNOR2x2_ASAP7_75t_R g099(.A(new_n208_), .B(new_n209_), .Y(new_n210_));
  AOI21x1_ASAP7_75t_R g100(.A1(new_n242_), .A2(new_n244_), .B(new_n210_), .Y(G1901));
  AND3x1_ASAP7_75t_R  g101(.A(new_n243_), .B(G25), .C(new_n204_), .Y(new_n212_));
  XOR2x2_ASAP7_75t_R  g102(.A(new_n140_), .B(new_n212_), .Y(new_n213_));
  AOI21x1_ASAP7_75t_R g103(.A1(new_n242_), .A2(new_n244_), .B(new_n213_), .Y(G1902));
  AND3x1_ASAP7_75t_R  g104(.A(new_n243_), .B(G27), .C(new_n204_), .Y(new_n215_));
  XOR2x2_ASAP7_75t_R  g105(.A(new_n103_), .B(new_n215_), .Y(new_n216_));
  AOI21x1_ASAP7_75t_R g106(.A1(new_n242_), .A2(new_n244_), .B(new_n216_), .Y(G1903));
  AND3x1_ASAP7_75t_R  g107(.A(new_n243_), .B(G28), .C(new_n204_), .Y(new_n218_));
  XOR2x2_ASAP7_75t_R  g108(.A(new_n92_), .B(new_n218_), .Y(new_n219_));
  AOI21x1_ASAP7_75t_R g109(.A1(new_n242_), .A2(new_n244_), .B(new_n219_), .Y(G1904));
  AND3x1_ASAP7_75t_R  g110(.A(new_n243_), .B(new_n115_), .C(new_n204_), .Y(new_n221_));
  XOR2x2_ASAP7_75t_R  g111(.A(new_n113_), .B(new_n221_), .Y(new_n222_));
  AOI21x1_ASAP7_75t_R g112(.A1(new_n242_), .A2(new_n244_), .B(new_n222_), .Y(G1905));
  OA21x2_ASAP7_75t_R  g113(.A1(G33), .A2(G29), .B(new_n151_), .Y(new_n225_));
  XNOR2x2_ASAP7_75t_R g114(.A(new_n165_), .B(new_n225_), .Y(new_n226_));
  AO21x1_ASAP7_75t_R  g115(.A1(G21), .A2(G29), .B(G33), .Y(new_n227_));
  XOR2x2_ASAP7_75t_R  g116(.A(new_n226_), .B(new_n227_), .Y(G1906));
  XNOR2x2_ASAP7_75t_R g117(.A(G9), .B(G14), .Y(new_n230_));
  XOR2x2_ASAP7_75t_R  g118(.A(new_n123_), .B(new_n230_), .Y(new_n231_));
  OA21x2_ASAP7_75t_R  g119(.A1(G33), .A2(G30), .B(new_n231_), .Y(new_n232_));
  XNOR2x2_ASAP7_75t_R g120(.A(new_n172_), .B(new_n232_), .Y(new_n233_));
  AO21x1_ASAP7_75t_R  g121(.A1(G30), .A2(G22), .B(G33), .Y(new_n234_));
  XOR2x2_ASAP7_75t_R  g122(.A(new_n233_), .B(new_n234_), .Y(G1907));
  AOI21x1_ASAP7_75t_R g123(.A1(new_n242_), .A2(new_n244_), .B(new_n265_), .Y(G1908));
  INVx1_ASAP7_75t_R   g124(.A(G23), .Y(new_n240_));
  INVx1_ASAP7_75t_R   g125(.A(G24), .Y(new_n241_));
  INVx1_ASAP7_75t_R   g126(.A(G33), .Y(new_n242_));
  INVx1_ASAP7_75t_R   g127(.A(G31), .Y(new_n243_));
  INVx1_ASAP7_75t_R   g128(.A(G32), .Y(new_n244_));
  INVx1_ASAP7_75t_R   g129(.A(G20), .Y(new_n245_));
  INVx1_ASAP7_75t_R   g130(.A(G17), .Y(new_n246_));
  OR2x4_ASAP7_75t_R   g131(.A(G32), .B(new_n83_), .Y(new_n247_));
  XNOR2x2_ASAP7_75t_R g132(.A(G16), .B(new_n88_), .Y(new_n248_));
  INVx1_ASAP7_75t_R   g133(.A(new_n131_), .Y(new_n249_));
  XOR2x2_ASAP7_75t_R  g134(.A(new_n137_), .B(new_n123_), .Y(new_n250_));
  INVx1_ASAP7_75t_R   g135(.A(new_n144_), .Y(new_n251_));
  NOR2x1_ASAP7_75t_R  g136(.A(new_n130_), .B(new_n106_), .Y(new_n255_));
  INVx1_ASAP7_75t_R   g137(.A(new_n204_), .Y(new_n263_));
  AO21x1_ASAP7_75t_R  g138(.A1(G32), .A2(new_n204_), .B(new_n194_), .Y(G1900));
  OR2x4_ASAP7_75t_R   g139(.A(new_n127_), .B(new_n204_), .Y(new_n265_));
endmodule


