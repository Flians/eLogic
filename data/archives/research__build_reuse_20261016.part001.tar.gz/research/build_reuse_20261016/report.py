"""Audit all frozen trials; keep pilot selection separate from exploratory arms."""
import hashlib,json,re,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];P=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'scripts/experiments'))
from audit_mapped_ppa import audit
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
rows=[]
for f in sorted((P/'runs').glob('*/result.json')):
 r=json.loads(f.read_text());m=json.loads((f.parent/'manifest.json').read_text())
 assert r['status']=='complete' and r['cec']==1 and r['optimizer_seconds']<1000
 assert r['binary_sha256']==sha(Path(m['command'][0]))
 assert r['log_sha256']==sha(f.parent/'log') and r['netlist_sha256']==sha(f.parent/'epmapping_mapped.v')
 assert r['baseline_sha256']==sha(f.parent/'epmapping_baseline.v')
 for name,h in m['input_sha256'].items():assert h==sha(ROOT/'results_v20_three_parts_chain/inputs'/name)
 assert m['env']['EPMAPPING_WINDOW_SYN']=='0' and m['env']['EPMAPPING_POST_TIMEOUT']=='1000'
 b=json.loads((ROOT/'research/trigger_recheck_20261016/runs'/f"recheck.recheck.{r['mode']}.{r['design']}"/'result.json').read_text())
 assert r['netlist_sha256']==b['netlist_sha256'] and r['baseline_sha256']==b['baseline_sha256']
 assert r['area']==b['area'] and r['delay']==b['delay']
 old_manifest=json.loads((ROOT/'research/trigger_recheck_20261016/runs'/f"recheck.recheck.{r['mode']}.{r['design']}"/'manifest.json').read_text())
 assert m['input_sha256']==old_manifest['input_sha256']
 for key in ['cuts','covers','replacements']:
  assert r['counters']['cofactor'][key]==b['counters']['cofactor'][key]
 assert r['counters']['duplicates']==b['counters']['duplicates']
 assert sum(r['counters']['cofactor'][k] for k in ['builds','hits'])==sum(b['counters']['cofactor'][k] for k in ['builds','hits'])
 r['prior_policy3']={k:b[k] for k in ['area','delay','optimizer_seconds','netlist_sha256']}
 r['runtime_change_percent']=100*(r['optimizer_seconds']/b['optimizer_seconds']-1)
 c=r['counters'].get('build_reuse',{})
 if c:
  assert c['mapping_calls']+c['reused']==r['counters']['cofactor']['builds']
  if r['arm']!='probe':assert c['alias_hits']==c['reused']
  else:assert c['reused']==0
  r['mapping_reduction_percent']=100*(1-c['mapping_calls']/b['counters']['cofactor']['builds'])
  r['requests_change_percent']=100*(r['counters']['cofactor']['builds']/b['counters']['cofactor']['builds']-1)
 records=[dict(re.findall(r'(\w+)=([^\s]+)',line)) for line in (f.parent/'log').read_text().splitlines() if 'operator_policy source=' in line]
 for key in ['deferred','rechecked','skipped','dominated']:
  r[key]=sum(int(x.get(key,0)) for x in records)
 assert r['deferred']==r['rechecked'] and r['skipped']==0
 if r['mode']=='warm':assert r['counters']['profile']['builds']==0
 rows.append(r)
(P/'verified_results.json').write_text(json.dumps(rows,indent=2)+'\n')
selected=[r for r in rows if r['version']=='shared' and r['arm']=='reuse256']
lines=['# Candidate build/recheck efficiency pilot','',
'Frozen original AIG and original high_effort initial mapping, six-round cap, full library, area minimization under original D0, window synthesis OFF, post-mapping deadline 1000 s. Every completed final netlist is byte-identical to the prior quality-preserving policy3 result and passes CEC. Cold and warm restart all native structural caches; only each private persistent e-graph pool carries over.','',
'## Selected three-circuit configuration','',
'`EPMAPPING_OPERATOR_POLICY=3`, `EPMAPPING_BUILD_REUSE=2`, `EPMAPPING_SHARED_MAPPED_LIBRARY=1`, `EPMAPPING_SYN_CACHE=262144`. Each native structural cache has this entry limit, applied universally; actual entries grow on demand. Memory is a tradeoff, not free acceleration. No circuit-name scheduling.','',
'| Circuit | Cache | Area / Delay | Previous policy3 s | New s | Runtime change | Peak RSS MiB |','|---|---|---:|---:|---:|---:|---:|']
for r in selected:
 lines.append(f"| {r['design']} | {r['mode']} | {r['area']:.2f} / {r['delay']:.2f} | {r['prior_policy3']['optimizer_seconds']:.3f} | {r['optimizer_seconds']:.3f} | {r['runtime_change_percent']:+.2f}% | {r.get('peak_rss_kib',0)/1024:.1f} |")
lines+=['','Prior policy3 timings above are archived single trials from trigger_recheck_20261016. Timings are shared-host observations, not statistically established speedups. Same-session usb_phy controls and all development arms are listed below. Peak RSS is per native process from wait4, including preprocessing and library loading; old trials without that instrumentation have no comparable RSS measurement.','',
'| Circuit | Cache | Prior build requests / mapper calls | New build requests | Actual mapper calls | Exact aliases reused | Mapping work reduction |','|---|---|---:|---:|---:|---:|---:|']
for r in selected:
 b=json.loads((ROOT/'research/trigger_recheck_20261016/runs'/f"recheck.recheck.{r['mode']}.{r['design']}"/'result.json').read_text());c=r['counters']['build_reuse']
 lines.append(f"| {r['design']} | {r['mode']} | {int(b['counters']['cofactor']['builds'])} | {int(r['counters']['cofactor']['builds'])} | {int(c['mapping_calls'])} | {int(c['reused'])} | {r['mapping_reduction_percent']:.2f}% |")
lines+=['','Mechanisms: an exact pre-mapping AIG key shares immutable mapped covers/proofs across family/pivot requests. The key includes ordered truth, objective, PI/PO order, node slots including dangling/dead nodes, edge phases, reference counts and value/traversal state. It is not NPN or functional canonicalization. The optimizer fixes the library and mapper parameters. Live arrival/phase cost is still recomputed on use. A second bounded cache and the larger request cache reduce repeated work after eviction. A shared immutable cell library avoids repeated full-library copies when constructing transient mapped networks. Existing candidate order, mandatory operator rechecks and strict area dominance rules remain.','',
'## Development and controlled usb_phy arms','',
'| Version | Arm | Circuit | Cache | Optimizer s | Mapper calls |','|---|---|---|---|---:|---:|']
for r in rows:
 lines.append(f"| {r['version']} | {r['arm']} | {r['design']} | {r['mode']} | {r['optimizer_seconds']:.3f} | {int(r['counters'].get('build_reuse',{}).get('mapping_calls',r['counters']['cofactor']['builds']))} |")
lines+=['','`baseline`: prior frozen policy3. `probe`: exact-AIG alias measurement with all mapping calls retained. `reuse` version: exact-AIG reuse only at 65536 entries. `shared/control`: same executable with new mechanisms disabled. `shared/shared_only`: shared cell library only, 65536 entries. `shared/reuse`: exact-AIG reuse plus shared cell library, 65536 entries. `shared/reuse256`: both mechanisms with 262144-entry limits. The full three-circuit results are opt-in pilot data; no paper or published campaign numbers are replaced.']
(P/'RESULTS.md').write_text('\n'.join(lines)+'\n')
print(json.dumps({'verified_trials':len(rows),'selected_cold_warm_trials':len(selected)}))
