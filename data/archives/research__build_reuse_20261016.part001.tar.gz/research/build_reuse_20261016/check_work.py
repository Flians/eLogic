"""Deterministic work/quality differential, independent of noisy wall-clock timing."""
import argparse,json
from pathlib import Path
ap=argparse.ArgumentParser();ap.add_argument('run');a=ap.parse_args()
p=Path(a.run);r=json.loads((p/'result.json').read_text())
root=Path(__file__).resolve().parents[2]
b=json.loads((root/'research/trigger_recheck_20261016/runs'/f"recheck.recheck.{r['mode']}.{r['design']}"/'result.json').read_text())
assert r['cec']==1 and r['netlist_sha256']==b['netlist_sha256']
requests=r['counters']['cofactor']['builds']
mapping=r['counters'].get('build_reuse',{}).get('mapping_calls',requests)
print(json.dumps({'design':r['design'],'mode':r['mode'],'requests':requests,'mapping_calls':mapping,'same_netlist':True}),flush=True)
assert mapping<requests, 'repeated structural build requests still each invoke technology mapping'
