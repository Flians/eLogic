import subprocess,sys,time
from pathlib import Path
P=Path(__file__).resolve().parent
while not (P/'runs/shared.reuse256.warm.tv80/result.json').exists():time.sleep(5)
# Runner writes aggregate metadata immediately after the final result.
time.sleep(5)
subprocess.run([sys.executable,str(P/'finalize.py')],check=True)
