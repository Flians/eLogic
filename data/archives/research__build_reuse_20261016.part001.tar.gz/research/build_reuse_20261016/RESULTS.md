# Candidate build/recheck efficiency pilot

Frozen original AIG and original high_effort initial mapping, six-round cap, full library, area minimization under original D0, window synthesis OFF, post-mapping deadline 1000 s. Every completed final netlist is byte-identical to the prior quality-preserving policy3 result and passes CEC. Cold and warm restart all native structural caches; only each private persistent e-graph pool carries over.

## Selected three-circuit configuration

`EPMAPPING_OPERATOR_POLICY=3`, `EPMAPPING_BUILD_REUSE=2`, `EPMAPPING_SHARED_MAPPED_LIBRARY=1`, `EPMAPPING_SYN_CACHE=262144`. Each native structural cache has this entry limit, applied universally; actual entries grow on demand. Memory is a tradeoff, not free acceleration. No circuit-name scheduling.

| Circuit | Cache | Area / Delay | Previous policy3 s | New s | Runtime change | Peak RSS MiB |
|---|---|---:|---:|---:|---:|---:|
| arbiter | cold | 223.64 / 261.39 | 21.749 | 21.852 | +0.48% | 393.5 |
| tv80 | cold | 328.16 / 833.94 | 449.478 | 215.929 | -51.96% | 1220.6 |
| usb_phy | cold | 21.38 / 158.68 | 11.844 | 11.291 | -4.67% | 406.6 |
| arbiter | warm | 223.64 / 261.39 | 20.730 | 20.589 | -0.68% | 393.0 |
| tv80 | warm | 328.16 / 833.94 | 359.433 | 132.943 | -63.01% | 1218.1 |
| usb_phy | warm | 21.38 / 158.68 | 4.612 | 4.283 | -7.13% | 405.4 |

Prior policy3 timings above are archived single trials from trigger_recheck_20261016. Timings are shared-host observations, not statistically established speedups. Same-session usb_phy controls and all development arms are listed below. Peak RSS is per native process from wait4, including preprocessing and library loading; old trials without that instrumentation have no comparable RSS measurement.

| Circuit | Cache | Prior build requests / mapper calls | New build requests | Actual mapper calls | Exact aliases reused | Mapping work reduction |
|---|---|---:|---:|---:|---:|---:|
| arbiter | cold | 4260 | 4260 | 4103 | 157 | 3.69% |
| tv80 | cold | 622794 | 139740 | 135446 | 4294 | 78.25% |
| usb_phy | cold | 9096 | 9096 | 8524 | 572 | 6.29% |
| arbiter | warm | 4260 | 4260 | 4103 | 157 | 3.69% |
| tv80 | warm | 622794 | 139740 | 135446 | 4294 | 78.25% |
| usb_phy | warm | 9096 | 9096 | 8524 | 572 | 6.29% |

Mechanisms: an exact pre-mapping AIG key shares immutable mapped covers/proofs across family/pivot requests. The key includes ordered truth, objective, PI/PO order, node slots including dangling/dead nodes, edge phases, reference counts and value/traversal state. It is not NPN or functional canonicalization. The optimizer fixes the library and mapper parameters. Live arrival/phase cost is still recomputed on use. A second bounded cache and the larger request cache reduce repeated work after eviction. A shared immutable cell library avoids repeated full-library copies when constructing transient mapped networks. Existing candidate order, mandatory operator rechecks and strict area dominance rules remain.

## Development and controlled usb_phy arms

| Version | Arm | Circuit | Cache | Optimizer s | Mapper calls |
|---|---|---|---|---:|---:|
| reuse | baseline | usb_phy | cold | 11.345 | 9096 |
| reuse | baseline | usb_phy | warm | 4.680 | 9096 |
| reuse | probe | usb_phy | cold | 11.382 | 9096 |
| reuse | probe | usb_phy | warm | 4.659 | 9096 |
| reuse | reuse | usb_phy | cold | 11.336 | 8524 |
| reuse | reuse | usb_phy | warm | 4.546 | 8524 |
| shared | control | usb_phy | cold | 11.347 | 9096 |
| shared | control | usb_phy | warm | 4.548 | 9096 |
| shared | reuse | usb_phy | cold | 10.806 | 8524 |
| shared | reuse | usb_phy | warm | 4.058 | 8524 |
| shared | reuse256 | arbiter | cold | 21.852 | 4103 |
| shared | reuse256 | tv80 | cold | 215.929 | 135446 |
| shared | reuse256 | usb_phy | cold | 11.291 | 8524 |
| shared | reuse256 | arbiter | warm | 20.589 | 4103 |
| shared | reuse256 | tv80 | warm | 132.943 | 135446 |
| shared | reuse256 | usb_phy | warm | 4.283 | 8524 |
| shared | shared_only | usb_phy | cold | 10.713 | 9096 |
| shared | shared_only | usb_phy | warm | 4.066 | 9096 |

`baseline`: prior frozen policy3. `probe`: exact-AIG alias measurement with all mapping calls retained. `reuse` version: exact-AIG reuse only at 65536 entries. `shared/control`: same executable with new mechanisms disabled. `shared/shared_only`: shared cell library only, 65536 entries. `shared/reuse`: exact-AIG reuse plus shared cell library, 65536 entries. `shared/reuse256`: both mechanisms with 262144-entry limits. The full three-circuit results are opt-in pilot data; no paper or published campaign numbers are replaced.
