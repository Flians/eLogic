import difflib,hashlib,json,os,shutil,subprocess,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];P=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'scripts/experiments'))
from audit_mapped_ppa import audit
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
subprocess.run([sys.executable,str(P/'report.py')],check=True)
rows=json.loads((P/'verified_results.json').read_text());assert len(rows)==18
selected=[r for r in rows if r['version']=='shared' and r['arm']=='reuse256'];assert len(selected)==6
for r in rows:
 wd=P/'runs'/f"{r['version']}.{r['arm']}.{r['mode']}.{r['design']}"
 a=audit(wd/'epmapping_mapped.v',ROOT/'results_v20_three_parts_chain/inputs/asap7.genlib')
 assert abs(a['area']-r['area'])<.0001 and abs(a['delay']-r['delay'])<.001
for r in selected:
 wd=P/'runs'/f"{r['version']}.{r['arm']}.{r['mode']}.{r['design']}"
 subprocess.run([sys.executable,str(P/'check_work.py'),str(wd)],check=True)
for name in ['epmapping.hpp','main.cpp','bounded_cache.hpp','operator_policy.hpp','exact_aig_key.hpp']:
 assert sha(P/'shared'/name)==sha(ROOT/'epmapping'/name)
for rel in ['algorithms/emap.hpp','views/cell_view.hpp']:
 assert sha(P/'shared'/Path(rel).name)==sha(ROOT/'tools/mockturtle/include/mockturtle'/rel)
assert sha(P/'shared/epmapping_check')==sha(ROOT/'build/epmapping/epmapping_check')
checks=[]
env={k:v for k,v in os.environ.items() if not k.startswith(('EPMAPPING_','MAP_EGG_'))}
env['ABC']=str(ROOT/'results_v20_three_parts_chain/inputs/abc')
for name,cmd in [('exact_aig_key',['/tmp/epmapping-exact-aig-test']),('shared_library',['/tmp/epmapping-shared-lib-test']),('installed_patches',['bash',str(ROOT/'scripts/apply_mockturtle_patches.sh')]),('patches',[sys.executable,str(ROOT/'scripts/experiments/tests/test_mockturtle_patch.py')]),('bounded_goal',[sys.executable,str(ROOT/'scripts/experiments/tests/test_area_delay_bound.py')]),('cofactor_candidates_default',[sys.executable,str(ROOT/'scripts/experiments/tests/test_cofactor_candidates.py')])]:
 q=subprocess.run(cmd,cwd=ROOT,env=env,capture_output=True,text=True,timeout=1100)
 (P/f'final_{name}.log').write_text(q.stdout+q.stderr)
 assert q.returncode==0,(name,q.stdout+q.stderr)
 checks.append({'test':name,'exit_code':q.returncode})
flags=json.loads((ROOT/'research/usb_candidate_generation_20261015/validated_env.json').read_text())
flags.update(EPMAPPING_OPERATOR_POLICY='3',EPMAPPING_SYN_CACHE='262144',EPMAPPING_CHECKPOINT='1',EPMAPPING_BUILD_REUSE='2',EPMAPPING_SHARED_MAPPED_LIBRARY='1')
(P/'pilot_env.json').write_text(json.dumps(flags,indent=2)+'\n')
for name in ['epmapping.hpp','main.cpp','operator_policy.hpp','exact_aig_key.hpp']:
 old=ROOT/'research/trigger_recheck_20261016/recheck'/name
 if old.exists():a=old.read_text().splitlines(keepends=True)
 else:a=[]
 b=(ROOT/'epmapping'/name).read_text().splitlines(keepends=True)
 (P/(name+'.diff')).write_text(''.join(difflib.unified_diff(a,b,fromfile='prior/'+name,tofile='new/'+name)))
for rel in ['scripts/apply_mockturtle_patches.sh','patches/mockturtle/shared-mapped-library.patch','patches/mockturtle/tech-library-function-buckets.patch','scripts/experiments/run_three_parts.py','scripts/experiments/tests/test_mockturtle_patch.py','scripts/experiments/tests/test_exact_aig_key.cpp','scripts/experiments/tests/test_shared_mapped_library.cpp']:
 dest=P/'pipeline_sources'/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(ROOT/rel,dest)
tv=next(r for r in selected if r['design']=='tv80' and r['mode']=='warm')
text=(P/'ANALYSIS.md').read_text().split('\n最终热缓存验证：')[0]
text+=f"\n最终热缓存验证：tv80 为 {tv['optimizer_seconds']:.3f} 秒，较上一轮 {tv['prior_policy3']['optimizer_seconds']:.3f} 秒变化 {tv['runtime_change_percent']:+.2f}%；面积/延迟 {tv['area']:.2f} / {tv['delay']:.2f}，网表逐字节一致。实际 cofactor 映射 {int(tv['counters']['build_reuse']['mapping_calls'])} 次，原生构建请求 {int(tv['counters']['cofactor']['builds'])} 次，e-graph 新建数为零；峰值 RSS {tv['peak_rss_kib']/1024:.1f} MiB。全部 18 次运行审计通过，其中 6 次为最终统一配置的冷/热验证。\n"
(P/'ANALYSIS.md').write_text(text)
(P/'final_validation.json').write_text(json.dumps({'complete_trials':18,'selected_cold_warm_trials':6,'same_initial_and_final_netlists':True,'cec_all':True,'independent_ppa_reaudit_all':True,'strictly_fewer_actual_mapping_calls_all_selected':True,'no_permanent_operator_skips':True,'cold_warm_native_caches_restart':True,'native_sources_binary_and_mockturtle_headers_match_frozen_trial':True,'tests':checks},indent=2)+'\n')
files={str(f.relative_to(P)):{'sha256':sha(f),'bytes':f.stat().st_size} for f in sorted(P.rglob('*')) if f.is_file() and f.name!='delivery_manifest.json' and '__pycache__' not in f.parts}
(P/'delivery_manifest.json').write_text(json.dumps({'files':files},indent=2)+'\n')
print(json.dumps({'status':'pass','trials':18,'selected':6,'files_hashed':len(files)}))
