// Benchmark "/home/flynn/workplace/MIGBalance/results_v2/emorphic_random_area_20261012/c1908/rewritten_egraph_with_weight_cost_serd_random-based-faster-bottom-up_2/logic" written by ABC on Mon Oct 12 14:24:48 2026

module \/home/flynn/workplace/MIGBalance/results_v2/emorphic_random_area_20261012/c1908/rewritten_egraph_with_weight_cost_serd_random-based-faster-bottom-up_2/logic  ( 
    G24, G33, G31, G30, G32, G8, G6, G3, G15, G10, G12, G19, G28, G9, G14,
    G16, G18, G11, G5, G2, G27, G7, G4, G20, G13, G1, G17, G26, G22, G25,
    G21, G29, G23,
    G1899, G1884, G1885, G1898, G1886, G1887, G1888, G1889, G1890, G1891,
    G1892, G1893, G1894, G1895, G1896, G1897, G1900, G1901, G1902, G1903,
    G1904, G1905, G1906, G1907, G1908  );
  input  G24, G33, G31, G30, G32, G8, G6, G3, G15, G10, G12, G19, G28,
    G9, G14, G16, G18, G11, G5, G2, G27, G7, G4, G20, G13, G1, G17, G26,
    G22, G25, G21, G29, G23;
  output G1899, G1884, G1885, G1898, G1886, G1887, G1888, G1889, G1890, G1891,
    G1892, G1893, G1894, G1895, G1896, G1897, G1900, G1901, G1902, G1903,
    G1904, G1905, G1906, G1907, G1908;
  wire new_n59_, new_n60_, new_n61_, new_n62_, new_n63_, new_n64_, new_n65_,
    new_n66_, new_n67_, new_n68_, new_n69_, new_n70_, new_n71_, new_n72_,
    new_n73_, new_n74_, new_n75_, new_n76_, new_n77_, new_n78_, new_n79_,
    new_n80_, new_n81_, new_n82_, new_n83_, new_n84_, new_n85_, new_n86_,
    new_n87_, new_n88_, new_n89_, new_n90_, new_n91_, new_n92_, new_n93_,
    new_n94_, new_n95_, new_n96_, new_n97_, new_n98_, new_n99_, new_n100_,
    new_n101_, new_n102_, new_n103_, new_n104_, new_n105_, new_n106_,
    new_n107_, new_n108_, new_n109_, new_n110_, new_n111_, new_n112_,
    new_n113_, new_n114_, new_n115_, new_n116_, new_n117_, new_n118_,
    new_n119_, new_n120_, new_n121_, new_n122_, new_n123_, new_n124_,
    new_n125_, new_n126_, new_n127_, new_n128_, new_n129_, new_n130_,
    new_n131_, new_n132_, new_n133_, new_n134_, new_n135_, new_n136_,
    new_n137_, new_n138_, new_n139_, new_n140_, new_n141_, new_n142_,
    new_n143_, new_n144_, new_n145_, new_n146_, new_n147_, new_n148_,
    new_n149_, new_n150_, new_n151_, new_n152_, new_n153_, new_n154_,
    new_n155_, new_n156_, new_n157_, new_n158_, new_n159_, new_n160_,
    new_n161_, new_n162_, new_n163_, new_n164_, new_n165_, new_n166_,
    new_n167_, new_n168_, new_n169_, new_n170_, new_n171_, new_n172_,
    new_n173_, new_n174_, new_n175_, new_n176_, new_n177_, new_n178_,
    new_n179_, new_n180_, new_n181_, new_n182_, new_n183_, new_n184_,
    new_n185_, new_n186_, new_n187_, new_n188_, new_n189_, new_n190_,
    new_n191_, new_n192_, new_n193_, new_n194_, new_n195_, new_n196_,
    new_n197_, new_n198_, new_n199_, new_n200_, new_n201_, new_n202_,
    new_n203_, new_n204_, new_n205_, new_n206_, new_n207_, new_n208_,
    new_n209_, new_n210_, new_n211_, new_n212_, new_n213_, new_n214_,
    new_n215_, new_n216_, new_n217_, new_n218_, new_n219_, new_n220_,
    new_n221_, new_n222_, new_n223_, new_n224_, new_n225_, new_n226_,
    new_n227_, new_n228_, new_n229_, new_n230_, new_n231_, new_n232_,
    new_n233_, new_n234_, new_n235_, new_n236_, new_n237_, new_n238_,
    new_n239_, new_n240_, new_n241_, new_n242_, new_n243_, new_n244_,
    new_n245_, new_n246_, new_n247_, new_n248_, new_n249_, new_n250_,
    new_n251_, new_n252_, new_n253_, new_n254_, new_n255_, new_n256_,
    new_n257_, new_n258_, new_n259_, new_n260_, new_n261_, new_n262_,
    new_n263_, new_n264_, new_n265_, new_n266_, new_n267_, new_n268_,
    new_n269_, new_n270_, new_n271_, new_n272_, new_n273_, new_n274_,
    new_n275_, new_n276_, new_n277_, new_n278_, new_n279_, new_n280_,
    new_n281_, new_n282_, new_n283_, new_n285_, new_n286_, new_n287_,
    new_n288_, new_n289_, new_n290_, new_n291_, new_n297_, new_n301_,
    new_n302_, new_n303_, new_n304_, new_n305_, new_n310_, new_n314_,
    new_n315_, new_n316_, new_n317_, new_n318_, new_n319_, new_n320_,
    new_n321_, new_n322_, new_n323_, new_n324_, new_n325_, new_n326_,
    new_n327_, new_n328_, new_n329_, new_n330_, new_n331_, new_n332_,
    new_n333_, new_n334_, new_n335_, new_n336_, new_n337_, new_n338_,
    new_n339_, new_n341_, new_n342_, new_n343_, new_n344_, new_n345_,
    new_n346_, new_n347_, new_n348_, new_n349_, new_n350_, new_n351_,
    new_n352_, new_n354_, new_n355_, new_n356_, new_n357_, new_n358_,
    new_n359_, new_n361_, new_n362_, new_n363_, new_n364_, new_n365_,
    new_n366_, new_n367_, new_n368_, new_n370_, new_n371_, new_n372_,
    new_n373_, new_n374_, new_n375_, new_n377_, new_n378_, new_n379_,
    new_n380_, new_n381_, new_n383_, new_n384_, new_n385_, new_n386_,
    new_n387_, new_n388_, new_n389_, new_n390_, new_n391_, new_n392_,
    new_n393_, new_n395_, new_n396_, new_n397_, new_n398_, new_n399_,
    new_n400_, new_n401_, new_n402_, new_n403_, new_n404_, new_n405_,
    new_n406_, new_n407_, new_n408_, new_n409_, new_n410_, new_n411_,
    new_n412_, new_n414_, new_n415_, new_n416_, new_n417_, new_n418_,
    new_n419_, new_n420_, new_n421_;
  INVx1_ASAP7_75t_R   g000(.A(G24), .Y(new_n59_));
  INVx1_ASAP7_75t_R   g001(.A(G33), .Y(new_n60_));
  INVx1_ASAP7_75t_R   g002(.A(G31), .Y(new_n61_));
  INVx1_ASAP7_75t_R   g003(.A(G30), .Y(new_n62_));
  INVx1_ASAP7_75t_R   g004(.A(G8), .Y(new_n63_));
  INVx1_ASAP7_75t_R   g005(.A(G6), .Y(new_n64_));
  INVx1_ASAP7_75t_R   g006(.A(G3), .Y(new_n65_));
  INVx1_ASAP7_75t_R   g007(.A(G15), .Y(new_n66_));
  INVx1_ASAP7_75t_R   g008(.A(G10), .Y(new_n67_));
  INVx1_ASAP7_75t_R   g009(.A(G12), .Y(new_n68_));
  INVx1_ASAP7_75t_R   g010(.A(G19), .Y(new_n69_));
  INVx1_ASAP7_75t_R   g011(.A(G28), .Y(new_n70_));
  INVx1_ASAP7_75t_R   g012(.A(G9), .Y(new_n71_));
  INVx1_ASAP7_75t_R   g013(.A(G14), .Y(new_n72_));
  INVx1_ASAP7_75t_R   g014(.A(G16), .Y(new_n73_));
  INVx1_ASAP7_75t_R   g015(.A(G18), .Y(new_n74_));
  INVx1_ASAP7_75t_R   g016(.A(G5), .Y(new_n75_));
  INVx1_ASAP7_75t_R   g017(.A(G2), .Y(new_n76_));
  INVx1_ASAP7_75t_R   g018(.A(G27), .Y(new_n77_));
  INVx1_ASAP7_75t_R   g019(.A(G7), .Y(new_n78_));
  INVx1_ASAP7_75t_R   g020(.A(G4), .Y(new_n79_));
  INVx1_ASAP7_75t_R   g021(.A(G20), .Y(new_n80_));
  INVx1_ASAP7_75t_R   g022(.A(G13), .Y(new_n81_));
  INVx1_ASAP7_75t_R   g023(.A(G1), .Y(new_n82_));
  INVx1_ASAP7_75t_R   g024(.A(G17), .Y(new_n83_));
  INVx1_ASAP7_75t_R   g025(.A(G26), .Y(new_n84_));
  INVx1_ASAP7_75t_R   g026(.A(G25), .Y(new_n85_));
  INVx1_ASAP7_75t_R   g027(.A(G23), .Y(new_n86_));
  OA21x2_ASAP7_75t_R  g028(.A1(G31), .A2(G30), .B(G32), .Y(new_n87_));
  AO21x1_ASAP7_75t_R  g029(.A1(G24), .A2(new_n86_), .B(G33), .Y(new_n88_));
  XOR2x2_ASAP7_75t_R  g030(.A(G8), .B(new_n64_), .Y(new_n89_));
  NOR2x1_ASAP7_75t_R  g031(.A(G3), .B(new_n89_), .Y(new_n90_));
  AO21x1_ASAP7_75t_R  g032(.A1(G3), .A2(new_n89_), .B(new_n90_), .Y(new_n91_));
  NOR2x1_ASAP7_75t_R  g033(.A(new_n66_), .B(G10), .Y(new_n92_));
  AO21x1_ASAP7_75t_R  g034(.A1(new_n66_), .A2(G10), .B(new_n92_), .Y(new_n93_));
  OA21x2_ASAP7_75t_R  g035(.A1(new_n68_), .A2(new_n93_), .B(new_n91_), .Y(new_n94_));
  NAND2x1_ASAP7_75t_R g036(.A(new_n68_), .B(new_n93_), .Y(new_n95_));
  OA21x2_ASAP7_75t_R  g037(.A1(new_n68_), .A2(new_n93_), .B(new_n95_), .Y(new_n96_));
  AO21x1_ASAP7_75t_R  g038(.A1(G3), .A2(new_n89_), .B(new_n96_), .Y(new_n97_));
  NOR2x1_ASAP7_75t_R  g039(.A(new_n90_), .B(new_n97_), .Y(new_n98_));
  AO21x1_ASAP7_75t_R  g040(.A1(new_n94_), .A2(new_n95_), .B(new_n98_), .Y(new_n99_));
  OR3x1_ASAP7_75t_R   g041(.A(G33), .B(new_n69_), .C(G23), .Y(new_n100_));
  AO21x1_ASAP7_75t_R  g042(.A1(G15), .A2(new_n67_), .B(new_n68_), .Y(new_n101_));
  AO21x1_ASAP7_75t_R  g043(.A1(new_n66_), .A2(G10), .B(new_n101_), .Y(new_n102_));
  AND3x1_ASAP7_75t_R  g044(.A(new_n91_), .B(new_n95_), .C(new_n102_), .Y(new_n103_));
  NOR2x1_ASAP7_75t_R  g045(.A(G33), .B(G23), .Y(new_n104_));
  OR3x1_ASAP7_75t_R   g046(.A(G33), .B(G23), .C(new_n69_), .Y(new_n105_));
  OAI21x1_ASAP7_75t_R g047(.A1(new_n98_), .A2(new_n103_), .B(new_n105_), .Y(new_n106_));
  OA21x2_ASAP7_75t_R  g048(.A1(new_n99_), .A2(new_n100_), .B(new_n106_), .Y(new_n107_));
  OR3x1_ASAP7_75t_R   g049(.A(G31), .B(G28), .C(new_n107_), .Y(new_n108_));
  INVx1_ASAP7_75t_R   g050(.A(new_n108_), .Y(new_n109_));
  OA21x2_ASAP7_75t_R  g051(.A1(G31), .A2(new_n107_), .B(G28), .Y(new_n110_));
  OR2x4_ASAP7_75t_R   g052(.A(new_n109_), .B(new_n110_), .Y(new_n111_));
  OR3x1_ASAP7_75t_R   g053(.A(new_n87_), .B(new_n88_), .C(new_n111_), .Y(new_n112_));
  XOR2x2_ASAP7_75t_R  g054(.A(G8), .B(new_n75_), .Y(new_n113_));
  NOR2x1_ASAP7_75t_R  g055(.A(G2), .B(new_n113_), .Y(new_n114_));
  INVx1_ASAP7_75t_R   g056(.A(new_n114_), .Y(new_n115_));
  NOR2x1_ASAP7_75t_R  g057(.A(G9), .B(G14), .Y(new_n116_));
  NOR2x1_ASAP7_75t_R  g058(.A(new_n71_), .B(new_n72_), .Y(new_n117_));
  OA21x2_ASAP7_75t_R  g059(.A1(new_n116_), .A2(new_n117_), .B(G16), .Y(new_n118_));
  OR3x1_ASAP7_75t_R   g060(.A(G16), .B(new_n117_), .C(new_n116_), .Y(new_n119_));
  INVx1_ASAP7_75t_R   g061(.A(new_n119_), .Y(new_n120_));
  NOR2x1_ASAP7_75t_R  g062(.A(new_n118_), .B(new_n120_), .Y(new_n121_));
  NOR2x1_ASAP7_75t_R  g063(.A(G24), .B(G33), .Y(new_n122_));
  AO21x1_ASAP7_75t_R  g064(.A1(G18), .A2(new_n122_), .B(new_n66_), .Y(new_n123_));
  NAND2x1_ASAP7_75t_R g065(.A(new_n59_), .B(G18), .Y(new_n124_));
  OR3x1_ASAP7_75t_R   g066(.A(G33), .B(G15), .C(new_n124_), .Y(new_n125_));
  AOI21x1_ASAP7_75t_R g067(.A1(new_n123_), .A2(new_n125_), .B(G11), .Y(new_n126_));
  AND3x1_ASAP7_75t_R  g068(.A(G11), .B(new_n123_), .C(new_n125_), .Y(new_n127_));
  OAI21x1_ASAP7_75t_R g069(.A1(new_n126_), .A2(new_n127_), .B(new_n121_), .Y(new_n128_));
  AND3x1_ASAP7_75t_R  g070(.A(G11), .B(new_n125_), .C(new_n123_), .Y(new_n129_));
  OR3x1_ASAP7_75t_R   g071(.A(new_n121_), .B(new_n126_), .C(new_n129_), .Y(new_n130_));
  AND2x2_ASAP7_75t_R  g072(.A(new_n128_), .B(new_n130_), .Y(new_n131_));
  AO21x1_ASAP7_75t_R  g073(.A1(G2), .A2(new_n113_), .B(new_n131_), .Y(new_n132_));
  NOR2x1_ASAP7_75t_R  g074(.A(new_n114_), .B(new_n132_), .Y(new_n133_));
  OR3x1_ASAP7_75t_R   g075(.A(new_n121_), .B(new_n126_), .C(new_n127_), .Y(new_n134_));
  AO21x1_ASAP7_75t_R  g076(.A1(G2), .A2(new_n113_), .B(new_n114_), .Y(new_n135_));
  AND3x1_ASAP7_75t_R  g077(.A(new_n128_), .B(new_n135_), .C(new_n134_), .Y(new_n136_));
  NOR2x1_ASAP7_75t_R  g078(.A(new_n133_), .B(new_n136_), .Y(new_n137_));
  OR3x1_ASAP7_75t_R   g079(.A(G31), .B(G27), .C(new_n137_), .Y(new_n138_));
  INVx1_ASAP7_75t_R   g080(.A(new_n138_), .Y(new_n139_));
  OA21x2_ASAP7_75t_R  g081(.A1(G31), .A2(new_n137_), .B(G27), .Y(new_n140_));
  OR3x1_ASAP7_75t_R   g082(.A(new_n139_), .B(new_n140_), .C(new_n112_), .Y(new_n141_));
  AO21x1_ASAP7_75t_R  g083(.A1(G17), .A2(new_n122_), .B(G1), .Y(new_n142_));
  OR3x1_ASAP7_75t_R   g084(.A(G33), .B(new_n83_), .C(G24), .Y(new_n143_));
  OA21x2_ASAP7_75t_R  g085(.A1(new_n82_), .A2(new_n143_), .B(new_n142_), .Y(new_n144_));
  XNOR2x2_ASAP7_75t_R g086(.A(new_n64_), .B(new_n78_), .Y(new_n145_));
  AO21x1_ASAP7_75t_R  g087(.A1(G6), .A2(G7), .B(G5), .Y(new_n146_));
  AOI21x1_ASAP7_75t_R g088(.A1(new_n64_), .A2(new_n78_), .B(new_n146_), .Y(new_n147_));
  AO21x1_ASAP7_75t_R  g089(.A1(G5), .A2(new_n145_), .B(new_n147_), .Y(new_n148_));
  INVx1_ASAP7_75t_R   g090(.A(new_n148_), .Y(new_n149_));
  NOR2x1_ASAP7_75t_R  g091(.A(G12), .B(G13), .Y(new_n150_));
  NOR2x1_ASAP7_75t_R  g092(.A(new_n68_), .B(new_n81_), .Y(new_n151_));
  OA21x2_ASAP7_75t_R  g093(.A1(new_n150_), .A2(new_n151_), .B(G11), .Y(new_n152_));
  INVx1_ASAP7_75t_R   g094(.A(new_n152_), .Y(new_n153_));
  OR3x1_ASAP7_75t_R   g095(.A(G11), .B(new_n150_), .C(new_n151_), .Y(new_n154_));
  NAND2x1_ASAP7_75t_R g096(.A(new_n153_), .B(new_n154_), .Y(new_n155_));
  INVx1_ASAP7_75t_R   g097(.A(new_n155_), .Y(new_n156_));
  NOR2x1_ASAP7_75t_R  g098(.A(new_n66_), .B(new_n73_), .Y(new_n157_));
  NOR2x1_ASAP7_75t_R  g099(.A(G15), .B(G16), .Y(new_n158_));
  OA21x2_ASAP7_75t_R  g100(.A1(new_n157_), .A2(new_n158_), .B(G10), .Y(new_n159_));
  OR3x1_ASAP7_75t_R   g101(.A(G10), .B(new_n157_), .C(new_n158_), .Y(new_n160_));
  INVx1_ASAP7_75t_R   g102(.A(new_n160_), .Y(new_n161_));
  OR3x1_ASAP7_75t_R   g103(.A(new_n156_), .B(new_n159_), .C(new_n161_), .Y(new_n162_));
  OR3x1_ASAP7_75t_R   g104(.A(G11), .B(new_n151_), .C(new_n150_), .Y(new_n163_));
  INVx1_ASAP7_75t_R   g105(.A(new_n163_), .Y(new_n164_));
  NOR2x1_ASAP7_75t_R  g106(.A(new_n159_), .B(new_n161_), .Y(new_n165_));
  INVx1_ASAP7_75t_R   g107(.A(new_n165_), .Y(new_n166_));
  OR3x1_ASAP7_75t_R   g108(.A(new_n152_), .B(new_n165_), .C(new_n164_), .Y(new_n167_));
  NAND2x1_ASAP7_75t_R g109(.A(new_n162_), .B(new_n167_), .Y(new_n168_));
  AND2x2_ASAP7_75t_R  g110(.A(new_n149_), .B(new_n168_), .Y(new_n169_));
  NOR2x1_ASAP7_75t_R  g111(.A(new_n149_), .B(new_n168_), .Y(new_n170_));
  OR3x1_ASAP7_75t_R   g112(.A(new_n169_), .B(new_n170_), .C(new_n144_), .Y(new_n171_));
  AND3x1_ASAP7_75t_R  g113(.A(G1), .B(G17), .C(new_n122_), .Y(new_n172_));
  AO21x1_ASAP7_75t_R  g114(.A1(new_n82_), .A2(new_n143_), .B(new_n172_), .Y(new_n173_));
  NOR2x1_ASAP7_75t_R  g115(.A(new_n152_), .B(new_n164_), .Y(new_n174_));
  OR3x1_ASAP7_75t_R   g116(.A(new_n161_), .B(new_n174_), .C(new_n159_), .Y(new_n175_));
  OA21x2_ASAP7_75t_R  g117(.A1(new_n155_), .A2(new_n165_), .B(new_n175_), .Y(new_n176_));
  INVx1_ASAP7_75t_R   g118(.A(new_n176_), .Y(new_n177_));
  AOI21x1_ASAP7_75t_R g119(.A1(new_n148_), .A2(new_n176_), .B(new_n169_), .Y(new_n178_));
  OA21x2_ASAP7_75t_R  g120(.A1(new_n173_), .A2(new_n178_), .B(new_n171_), .Y(new_n179_));
  NOR2x1_ASAP7_75t_R  g121(.A(G31), .B(new_n179_), .Y(new_n180_));
  INVx1_ASAP7_75t_R   g122(.A(new_n180_), .Y(new_n181_));
  NOR2x1_ASAP7_75t_R  g123(.A(G31), .B(G23), .Y(new_n182_));
  AO21x1_ASAP7_75t_R  g124(.A1(new_n61_), .A2(new_n86_), .B(new_n69_), .Y(new_n183_));
  NOR2x1_ASAP7_75t_R  g125(.A(new_n80_), .B(G23), .Y(new_n184_));
  AND3x1_ASAP7_75t_R  g126(.A(new_n60_), .B(new_n81_), .C(new_n184_), .Y(new_n185_));
  NOR2x1_ASAP7_75t_R  g127(.A(new_n67_), .B(G7), .Y(new_n186_));
  NOR2x1_ASAP7_75t_R  g128(.A(G10), .B(new_n78_), .Y(new_n187_));
  OR3x1_ASAP7_75t_R   g129(.A(new_n79_), .B(new_n186_), .C(new_n187_), .Y(new_n188_));
  INVx1_ASAP7_75t_R   g130(.A(new_n188_), .Y(new_n189_));
  OA21x2_ASAP7_75t_R  g131(.A1(new_n186_), .A2(new_n187_), .B(new_n79_), .Y(new_n190_));
  NOR2x1_ASAP7_75t_R  g132(.A(new_n189_), .B(new_n190_), .Y(new_n191_));
  OR3x1_ASAP7_75t_R   g133(.A(new_n118_), .B(new_n191_), .C(new_n120_), .Y(new_n192_));
  INVx1_ASAP7_75t_R   g134(.A(new_n192_), .Y(new_n193_));
  NOR2x1_ASAP7_75t_R  g135(.A(new_n185_), .B(new_n193_), .Y(new_n194_));
  OR3x1_ASAP7_75t_R   g136(.A(new_n79_), .B(new_n187_), .C(new_n186_), .Y(new_n195_));
  INVx1_ASAP7_75t_R   g137(.A(new_n195_), .Y(new_n196_));
  OR3x1_ASAP7_75t_R   g138(.A(new_n121_), .B(new_n190_), .C(new_n196_), .Y(new_n197_));
  AO21x1_ASAP7_75t_R  g139(.A1(G20), .A2(new_n104_), .B(new_n81_), .Y(new_n198_));
  INVx1_ASAP7_75t_R   g140(.A(new_n198_), .Y(new_n199_));
  AND3x1_ASAP7_75t_R  g141(.A(new_n194_), .B(new_n197_), .C(new_n198_), .Y(new_n200_));
  NAND2x1_ASAP7_75t_R g142(.A(new_n192_), .B(new_n197_), .Y(new_n201_));
  OA21x2_ASAP7_75t_R  g143(.A1(new_n185_), .A2(new_n199_), .B(new_n201_), .Y(new_n202_));
  NOR2x1_ASAP7_75t_R  g144(.A(new_n200_), .B(new_n202_), .Y(new_n203_));
  INVx1_ASAP7_75t_R   g145(.A(new_n203_), .Y(new_n204_));
  AND3x1_ASAP7_75t_R  g146(.A(new_n61_), .B(new_n204_), .C(new_n183_), .Y(new_n205_));
  NOR2x1_ASAP7_75t_R  g147(.A(new_n86_), .B(new_n204_), .Y(new_n206_));
  OA21x2_ASAP7_75t_R  g148(.A1(G31), .A2(new_n206_), .B(G19), .Y(new_n207_));
  OR2x4_ASAP7_75t_R   g149(.A(new_n205_), .B(new_n207_), .Y(new_n208_));
  AO21x1_ASAP7_75t_R  g150(.A1(new_n84_), .A2(new_n180_), .B(new_n208_), .Y(new_n209_));
  AO21x1_ASAP7_75t_R  g151(.A1(G26), .A2(new_n181_), .B(new_n209_), .Y(new_n210_));
  NOR2x1_ASAP7_75t_R  g152(.A(new_n65_), .B(new_n76_), .Y(new_n211_));
  NOR2x1_ASAP7_75t_R  g153(.A(G3), .B(G2), .Y(new_n212_));
  OA21x2_ASAP7_75t_R  g154(.A1(new_n211_), .A2(new_n212_), .B(G1), .Y(new_n213_));
  OR3x1_ASAP7_75t_R   g155(.A(G1), .B(new_n211_), .C(new_n212_), .Y(new_n214_));
  INVx1_ASAP7_75t_R   g156(.A(new_n214_), .Y(new_n215_));
  NOR2x1_ASAP7_75t_R  g157(.A(new_n213_), .B(new_n215_), .Y(new_n216_));
  NAND2x1_ASAP7_75t_R g158(.A(new_n166_), .B(new_n216_), .Y(new_n217_));
  OR3x1_ASAP7_75t_R   g159(.A(new_n159_), .B(new_n216_), .C(new_n161_), .Y(new_n218_));
  AO21x1_ASAP7_75t_R  g160(.A1(new_n217_), .A2(new_n218_), .B(new_n174_), .Y(new_n219_));
  OR3x1_ASAP7_75t_R   g161(.A(new_n159_), .B(new_n161_), .C(new_n216_), .Y(new_n220_));
  OR3x1_ASAP7_75t_R   g162(.A(new_n165_), .B(new_n213_), .C(new_n215_), .Y(new_n221_));
  AND3x1_ASAP7_75t_R  g163(.A(new_n156_), .B(new_n221_), .C(new_n220_), .Y(new_n222_));
  NOR2x1_ASAP7_75t_R  g164(.A(G14), .B(G4), .Y(new_n223_));
  NOR2x1_ASAP7_75t_R  g165(.A(new_n72_), .B(new_n79_), .Y(new_n224_));
  AO21x1_ASAP7_75t_R  g166(.A1(G14), .A2(G4), .B(new_n223_), .Y(new_n225_));
  AND2x2_ASAP7_75t_R  g167(.A(new_n60_), .B(G22), .Y(new_n226_));
  NOR2x1_ASAP7_75t_R  g168(.A(new_n225_), .B(new_n226_), .Y(new_n227_));
  AND3x1_ASAP7_75t_R  g169(.A(new_n60_), .B(new_n225_), .C(G22), .Y(new_n228_));
  OR3x1_ASAP7_75t_R   g170(.A(new_n227_), .B(new_n228_), .C(new_n222_), .Y(new_n229_));
  INVx1_ASAP7_75t_R   g171(.A(new_n229_), .Y(new_n230_));
  AND3x1_ASAP7_75t_R  g172(.A(new_n153_), .B(new_n217_), .C(new_n163_), .Y(new_n231_));
  AOI21x1_ASAP7_75t_R g173(.A1(new_n220_), .A2(new_n221_), .B(new_n156_), .Y(new_n232_));
  AO21x1_ASAP7_75t_R  g174(.A1(new_n218_), .A2(new_n231_), .B(new_n232_), .Y(new_n233_));
  OR3x1_ASAP7_75t_R   g175(.A(new_n224_), .B(new_n226_), .C(new_n223_), .Y(new_n234_));
  INVx1_ASAP7_75t_R   g176(.A(new_n234_), .Y(new_n235_));
  AND3x1_ASAP7_75t_R  g177(.A(new_n60_), .B(G22), .C(new_n225_), .Y(new_n236_));
  OA21x2_ASAP7_75t_R  g178(.A1(new_n235_), .A2(new_n236_), .B(new_n233_), .Y(new_n237_));
  AO21x1_ASAP7_75t_R  g179(.A1(new_n219_), .A2(new_n230_), .B(new_n237_), .Y(new_n238_));
  AND3x1_ASAP7_75t_R  g180(.A(new_n61_), .B(new_n85_), .C(new_n238_), .Y(new_n239_));
  AOI21x1_ASAP7_75t_R g181(.A1(new_n61_), .A2(new_n238_), .B(new_n85_), .Y(new_n240_));
  NOR2x1_ASAP7_75t_R  g182(.A(new_n239_), .B(new_n240_), .Y(new_n241_));
  INVx1_ASAP7_75t_R   g183(.A(new_n241_), .Y(new_n242_));
  OR3x1_ASAP7_75t_R   g184(.A(new_n80_), .B(new_n241_), .C(new_n182_), .Y(new_n243_));
  INVx1_ASAP7_75t_R   g185(.A(new_n243_), .Y(new_n244_));
  AO21x1_ASAP7_75t_R  g186(.A1(new_n59_), .A2(new_n61_), .B(new_n74_), .Y(new_n245_));
  INVx1_ASAP7_75t_R   g187(.A(new_n245_), .Y(new_n246_));
  AO21x1_ASAP7_75t_R  g188(.A1(new_n59_), .A2(new_n61_), .B(new_n83_), .Y(new_n247_));
  NOR2x1_ASAP7_75t_R  g189(.A(new_n149_), .B(new_n216_), .Y(new_n248_));
  OR3x1_ASAP7_75t_R   g190(.A(new_n148_), .B(new_n213_), .C(new_n215_), .Y(new_n249_));
  INVx1_ASAP7_75t_R   g191(.A(new_n249_), .Y(new_n250_));
  NOR2x1_ASAP7_75t_R  g192(.A(new_n248_), .B(new_n250_), .Y(new_n251_));
  AO21x1_ASAP7_75t_R  g193(.A1(G8), .A2(new_n79_), .B(new_n251_), .Y(new_n252_));
  AO21x1_ASAP7_75t_R  g194(.A1(new_n63_), .A2(G4), .B(new_n252_), .Y(new_n253_));
  XOR2x2_ASAP7_75t_R  g195(.A(G8), .B(new_n79_), .Y(new_n254_));
  OR3x1_ASAP7_75t_R   g196(.A(new_n250_), .B(new_n254_), .C(new_n248_), .Y(new_n255_));
  INVx1_ASAP7_75t_R   g197(.A(new_n255_), .Y(new_n256_));
  NAND2x1_ASAP7_75t_R g198(.A(new_n253_), .B(new_n255_), .Y(new_n257_));
  OR3x1_ASAP7_75t_R   g199(.A(new_n71_), .B(new_n161_), .C(new_n159_), .Y(new_n258_));
  INVx1_ASAP7_75t_R   g200(.A(new_n258_), .Y(new_n259_));
  NOR2x1_ASAP7_75t_R  g201(.A(G9), .B(new_n165_), .Y(new_n260_));
  AND2x2_ASAP7_75t_R  g202(.A(new_n60_), .B(G21), .Y(new_n261_));
  OR3x1_ASAP7_75t_R   g203(.A(new_n260_), .B(new_n261_), .C(new_n259_), .Y(new_n262_));
  INVx1_ASAP7_75t_R   g204(.A(new_n262_), .Y(new_n263_));
  OR3x1_ASAP7_75t_R   g205(.A(new_n71_), .B(new_n159_), .C(new_n161_), .Y(new_n264_));
  INVx1_ASAP7_75t_R   g206(.A(new_n264_), .Y(new_n265_));
  AO21x1_ASAP7_75t_R  g207(.A1(new_n71_), .A2(new_n166_), .B(new_n265_), .Y(new_n266_));
  AO21x1_ASAP7_75t_R  g208(.A1(new_n261_), .A2(new_n266_), .B(new_n263_), .Y(new_n267_));
  AO21x1_ASAP7_75t_R  g209(.A1(new_n253_), .A2(new_n255_), .B(new_n267_), .Y(new_n268_));
  OA21x2_ASAP7_75t_R  g210(.A1(new_n248_), .A2(new_n250_), .B(new_n254_), .Y(new_n269_));
  AND3x1_ASAP7_75t_R  g211(.A(new_n60_), .B(new_n266_), .C(G21), .Y(new_n270_));
  OR3x1_ASAP7_75t_R   g212(.A(new_n261_), .B(new_n265_), .C(new_n260_), .Y(new_n271_));
  INVx1_ASAP7_75t_R   g213(.A(new_n271_), .Y(new_n272_));
  NOR2x1_ASAP7_75t_R  g214(.A(new_n270_), .B(new_n272_), .Y(new_n273_));
  INVx1_ASAP7_75t_R   g215(.A(new_n273_), .Y(new_n274_));
  OR3x1_ASAP7_75t_R   g216(.A(new_n269_), .B(new_n273_), .C(new_n256_), .Y(new_n275_));
  AND3x1_ASAP7_75t_R  g217(.A(new_n61_), .B(new_n268_), .C(new_n275_), .Y(new_n276_));
  AND2x2_ASAP7_75t_R  g218(.A(new_n247_), .B(new_n276_), .Y(new_n277_));
  AO21x1_ASAP7_75t_R  g219(.A1(new_n268_), .A2(new_n275_), .B(new_n59_), .Y(new_n278_));
  AOI21x1_ASAP7_75t_R g220(.A1(new_n61_), .A2(new_n278_), .B(new_n83_), .Y(new_n279_));
  NOR2x1_ASAP7_75t_R  g221(.A(new_n277_), .B(new_n279_), .Y(new_n280_));
  INVx1_ASAP7_75t_R   g222(.A(new_n280_), .Y(new_n281_));
  OR3x1_ASAP7_75t_R   g223(.A(new_n244_), .B(new_n245_), .C(new_n281_), .Y(new_n282_));
  OR3x1_ASAP7_75t_R   g224(.A(new_n210_), .B(new_n282_), .C(new_n141_), .Y(new_n283_));
  XNOR2x2_ASAP7_75t_R g225(.A(new_n72_), .B(new_n283_), .Y(G1899));
  AO21x1_ASAP7_75t_R  g226(.A1(new_n59_), .A2(new_n61_), .B(new_n280_), .Y(new_n285_));
  NOR2x1_ASAP7_75t_R  g227(.A(new_n74_), .B(new_n285_), .Y(new_n286_));
  OAI21x1_ASAP7_75t_R g228(.A1(new_n74_), .A2(new_n285_), .B(new_n243_), .Y(new_n287_));
  OA21x2_ASAP7_75t_R  g229(.A1(G31), .A2(G29), .B(G32), .Y(new_n288_));
  OR3x1_ASAP7_75t_R   g230(.A(new_n88_), .B(new_n288_), .C(new_n140_), .Y(new_n289_));
  OR3x1_ASAP7_75t_R   g231(.A(new_n139_), .B(new_n289_), .C(new_n111_), .Y(new_n290_));
  OR3x1_ASAP7_75t_R   g232(.A(new_n287_), .B(new_n290_), .C(new_n210_), .Y(new_n291_));
  XNOR2x2_ASAP7_75t_R g233(.A(new_n82_), .B(new_n291_), .Y(G1884));
  XNOR2x2_ASAP7_75t_R g234(.A(new_n76_), .B(new_n291_), .Y(G1885));
  XNOR2x2_ASAP7_75t_R g235(.A(new_n81_), .B(new_n283_), .Y(G1898));
  XNOR2x2_ASAP7_75t_R g236(.A(new_n65_), .B(new_n291_), .Y(G1886));
  XNOR2x2_ASAP7_75t_R g237(.A(new_n79_), .B(new_n291_), .Y(G1887));
  OR3x1_ASAP7_75t_R   g238(.A(new_n141_), .B(new_n210_), .C(new_n287_), .Y(new_n297_));
  XNOR2x2_ASAP7_75t_R g239(.A(new_n67_), .B(new_n297_), .Y(G1888));
  XNOR2x2_ASAP7_75t_R g240(.A(new_n66_), .B(new_n297_), .Y(G1889));
  XNOR2x2_ASAP7_75t_R g241(.A(new_n73_), .B(new_n297_), .Y(G1890));
  NOR2x1_ASAP7_75t_R  g242(.A(new_n80_), .B(new_n182_), .Y(new_n301_));
  OR3x1_ASAP7_75t_R   g243(.A(new_n80_), .B(new_n182_), .C(new_n286_), .Y(new_n302_));
  OR3x1_ASAP7_75t_R   g244(.A(new_n240_), .B(new_n302_), .C(new_n239_), .Y(new_n303_));
  OR3x1_ASAP7_75t_R   g245(.A(new_n210_), .B(new_n290_), .C(new_n303_), .Y(new_n304_));
  INVx1_ASAP7_75t_R   g246(.A(new_n304_), .Y(new_n305_));
  XNOR2x2_ASAP7_75t_R g247(.A(new_n75_), .B(new_n304_), .Y(G1891));
  XNOR2x2_ASAP7_75t_R g248(.A(G6), .B(new_n305_), .Y(G1892));
  XNOR2x2_ASAP7_75t_R g249(.A(G7), .B(new_n305_), .Y(G1893));
  XNOR2x2_ASAP7_75t_R g250(.A(new_n63_), .B(new_n304_), .Y(G1894));
  OR3x1_ASAP7_75t_R   g251(.A(new_n141_), .B(new_n210_), .C(new_n303_), .Y(new_n310_));
  XNOR2x2_ASAP7_75t_R g252(.A(new_n71_), .B(new_n310_), .Y(G1895));
  XOR2x2_ASAP7_75t_R  g253(.A(G11), .B(new_n283_), .Y(G1896));
  XNOR2x2_ASAP7_75t_R g254(.A(new_n68_), .B(new_n283_), .Y(G1897));
  OR3x1_ASAP7_75t_R   g255(.A(new_n245_), .B(new_n277_), .C(new_n279_), .Y(new_n314_));
  OR3x1_ASAP7_75t_R   g256(.A(new_n80_), .B(new_n182_), .C(new_n314_), .Y(new_n315_));
  OR3x1_ASAP7_75t_R   g257(.A(new_n239_), .B(new_n315_), .C(new_n240_), .Y(new_n316_));
  AND3x1_ASAP7_75t_R  g258(.A(new_n282_), .B(new_n303_), .C(new_n316_), .Y(new_n317_));
  OR3x1_ASAP7_75t_R   g259(.A(new_n139_), .B(new_n140_), .C(new_n111_), .Y(new_n318_));
  OR3x1_ASAP7_75t_R   g260(.A(G32), .B(new_n318_), .C(new_n88_), .Y(new_n319_));
  OR3x1_ASAP7_75t_R   g261(.A(new_n210_), .B(new_n317_), .C(new_n319_), .Y(new_n320_));
  NAND2x1_ASAP7_75t_R g262(.A(G32), .B(new_n320_), .Y(new_n321_));
  XNOR2x2_ASAP7_75t_R g263(.A(new_n84_), .B(new_n180_), .Y(new_n322_));
  OR3x1_ASAP7_75t_R   g264(.A(new_n207_), .B(new_n322_), .C(new_n205_), .Y(new_n323_));
  OR3x1_ASAP7_75t_R   g265(.A(new_n80_), .B(new_n242_), .C(new_n182_), .Y(new_n324_));
  AND2x2_ASAP7_75t_R  g266(.A(new_n244_), .B(new_n324_), .Y(new_n325_));
  OR3x1_ASAP7_75t_R   g267(.A(new_n286_), .B(new_n323_), .C(new_n325_), .Y(new_n326_));
  OR3x1_ASAP7_75t_R   g268(.A(new_n314_), .B(new_n323_), .C(new_n244_), .Y(new_n327_));
  AO21x1_ASAP7_75t_R  g269(.A1(new_n326_), .A2(new_n327_), .B(new_n141_), .Y(new_n328_));
  NOR2x1_ASAP7_75t_R  g270(.A(new_n290_), .B(new_n326_), .Y(new_n329_));
  INVx1_ASAP7_75t_R   g271(.A(new_n329_), .Y(new_n330_));
  NAND2x1_ASAP7_75t_R g272(.A(new_n328_), .B(new_n330_), .Y(new_n331_));
  INVx1_ASAP7_75t_R   g273(.A(new_n331_), .Y(new_n332_));
  OA21x2_ASAP7_75t_R  g274(.A1(new_n321_), .A2(new_n331_), .B(G32), .Y(new_n333_));
  OR3x1_ASAP7_75t_R   g275(.A(new_n279_), .B(new_n301_), .C(new_n277_), .Y(new_n334_));
  OR3x1_ASAP7_75t_R   g276(.A(new_n242_), .B(new_n246_), .C(new_n334_), .Y(new_n335_));
  OR3x1_ASAP7_75t_R   g277(.A(new_n110_), .B(new_n208_), .C(new_n109_), .Y(new_n336_));
  OR3x1_ASAP7_75t_R   g278(.A(new_n139_), .B(new_n322_), .C(new_n140_), .Y(new_n337_));
  OR3x1_ASAP7_75t_R   g279(.A(new_n336_), .B(new_n337_), .C(new_n335_), .Y(new_n338_));
  INVx1_ASAP7_75t_R   g280(.A(new_n338_), .Y(new_n339_));
  OR3x1_ASAP7_75t_R   g281(.A(G33), .B(new_n339_), .C(new_n333_), .Y(G1900));
  OR3x1_ASAP7_75t_R   g282(.A(G31), .B(new_n247_), .C(new_n332_), .Y(new_n341_));
  AND3x1_ASAP7_75t_R  g283(.A(new_n253_), .B(new_n273_), .C(new_n255_), .Y(new_n342_));
  AO21x1_ASAP7_75t_R  g284(.A1(new_n257_), .A2(new_n274_), .B(new_n342_), .Y(new_n343_));
  NOR2x1_ASAP7_75t_R  g285(.A(G31), .B(new_n332_), .Y(new_n344_));
  INVx1_ASAP7_75t_R   g286(.A(new_n344_), .Y(new_n345_));
  OR3x1_ASAP7_75t_R   g287(.A(new_n257_), .B(new_n272_), .C(new_n270_), .Y(new_n346_));
  INVx1_ASAP7_75t_R   g288(.A(new_n346_), .Y(new_n347_));
  OR3x1_ASAP7_75t_R   g289(.A(new_n247_), .B(new_n345_), .C(new_n347_), .Y(new_n348_));
  OR2x4_ASAP7_75t_R   g290(.A(new_n256_), .B(new_n269_), .Y(new_n349_));
  AOI21x1_ASAP7_75t_R g291(.A1(new_n267_), .A2(new_n349_), .B(new_n348_), .Y(new_n350_));
  AOI21x1_ASAP7_75t_R g292(.A1(new_n341_), .A2(new_n343_), .B(new_n350_), .Y(new_n351_));
  NOR2x1_ASAP7_75t_R  g293(.A(G33), .B(G32), .Y(new_n352_));
  NOR2x1_ASAP7_75t_R  g294(.A(new_n351_), .B(new_n352_), .Y(G1901));
  OR3x1_ASAP7_75t_R   g295(.A(new_n233_), .B(new_n236_), .C(new_n235_), .Y(new_n354_));
  INVx1_ASAP7_75t_R   g296(.A(new_n354_), .Y(new_n355_));
  NOR2x1_ASAP7_75t_R  g297(.A(new_n237_), .B(new_n355_), .Y(new_n356_));
  AO21x1_ASAP7_75t_R  g298(.A1(G25), .A2(new_n344_), .B(new_n356_), .Y(new_n357_));
  AO21x1_ASAP7_75t_R  g299(.A1(new_n328_), .A2(new_n330_), .B(new_n238_), .Y(new_n358_));
  OR3x1_ASAP7_75t_R   g300(.A(G31), .B(new_n85_), .C(new_n358_), .Y(new_n359_));
  AOI21x1_ASAP7_75t_R g301(.A1(new_n357_), .A2(new_n359_), .B(new_n352_), .Y(G1902));
  AND3x1_ASAP7_75t_R  g302(.A(G27), .B(new_n331_), .C(new_n61_), .Y(new_n361_));
  OR3x1_ASAP7_75t_R   g303(.A(new_n136_), .B(new_n361_), .C(new_n133_), .Y(new_n362_));
  AND3x1_ASAP7_75t_R  g304(.A(new_n130_), .B(new_n135_), .C(new_n128_), .Y(new_n363_));
  AO21x1_ASAP7_75t_R  g305(.A1(new_n63_), .A2(G5), .B(new_n76_), .Y(new_n364_));
  AOI21x1_ASAP7_75t_R g306(.A1(G8), .A2(new_n75_), .B(new_n364_), .Y(new_n365_));
  AOI21x1_ASAP7_75t_R g307(.A1(new_n128_), .A2(new_n134_), .B(new_n365_), .Y(new_n366_));
  AOI21x1_ASAP7_75t_R g308(.A1(new_n115_), .A2(new_n366_), .B(new_n363_), .Y(new_n367_));
  OR3x1_ASAP7_75t_R   g309(.A(new_n77_), .B(new_n345_), .C(new_n367_), .Y(new_n368_));
  AOI21x1_ASAP7_75t_R g310(.A1(new_n362_), .A2(new_n368_), .B(new_n352_), .Y(G1903));
  OR3x1_ASAP7_75t_R   g311(.A(new_n98_), .B(new_n105_), .C(new_n103_), .Y(new_n370_));
  NAND2x1_ASAP7_75t_R g312(.A(new_n99_), .B(new_n100_), .Y(new_n371_));
  AO21x1_ASAP7_75t_R  g313(.A1(new_n370_), .A2(new_n371_), .B(new_n332_), .Y(new_n372_));
  OR3x1_ASAP7_75t_R   g314(.A(G31), .B(new_n70_), .C(new_n372_), .Y(new_n373_));
  OR3x1_ASAP7_75t_R   g315(.A(new_n70_), .B(new_n332_), .C(G31), .Y(new_n374_));
  NAND2x1_ASAP7_75t_R g316(.A(new_n107_), .B(new_n374_), .Y(new_n375_));
  AOI21x1_ASAP7_75t_R g317(.A1(new_n373_), .A2(new_n375_), .B(new_n352_), .Y(G1904));
  OR3x1_ASAP7_75t_R   g318(.A(new_n69_), .B(new_n182_), .C(G31), .Y(new_n377_));
  OR3x1_ASAP7_75t_R   g319(.A(new_n203_), .B(new_n332_), .C(new_n377_), .Y(new_n378_));
  OR3x1_ASAP7_75t_R   g320(.A(new_n183_), .B(new_n332_), .C(G31), .Y(new_n379_));
  INVx1_ASAP7_75t_R   g321(.A(new_n379_), .Y(new_n380_));
  OR3x1_ASAP7_75t_R   g322(.A(new_n200_), .B(new_n380_), .C(new_n202_), .Y(new_n381_));
  AOI21x1_ASAP7_75t_R g323(.A1(new_n378_), .A2(new_n381_), .B(new_n352_), .Y(G1905));
  AO21x1_ASAP7_75t_R  g324(.A1(G21), .A2(G29), .B(G33), .Y(new_n383_));
  NOR2x1_ASAP7_75t_R  g325(.A(G33), .B(G29), .Y(new_n384_));
  NOR2x1_ASAP7_75t_R  g326(.A(new_n256_), .B(new_n384_), .Y(new_n385_));
  AOI21x1_ASAP7_75t_R g327(.A1(new_n253_), .A2(new_n385_), .B(G33), .Y(new_n386_));
  NAND2x1_ASAP7_75t_R g328(.A(G29), .B(new_n330_), .Y(new_n387_));
  AOI21x1_ASAP7_75t_R g329(.A1(new_n60_), .A2(new_n387_), .B(new_n349_), .Y(new_n388_));
  AO21x1_ASAP7_75t_R  g330(.A1(new_n329_), .A2(new_n386_), .B(new_n388_), .Y(new_n389_));
  OR3x1_ASAP7_75t_R   g331(.A(new_n269_), .B(new_n384_), .C(new_n256_), .Y(new_n390_));
  AND3x1_ASAP7_75t_R  g332(.A(new_n60_), .B(new_n390_), .C(new_n329_), .Y(new_n391_));
  OR3x1_ASAP7_75t_R   g333(.A(new_n383_), .B(new_n388_), .C(new_n391_), .Y(new_n392_));
  INVx1_ASAP7_75t_R   g334(.A(new_n392_), .Y(new_n393_));
  AO21x1_ASAP7_75t_R  g335(.A1(new_n383_), .A2(new_n389_), .B(new_n393_), .Y(G1906));
  NOR2x1_ASAP7_75t_R  g336(.A(new_n71_), .B(G14), .Y(new_n395_));
  NOR2x1_ASAP7_75t_R  g337(.A(G9), .B(new_n72_), .Y(new_n396_));
  OR3x1_ASAP7_75t_R   g338(.A(new_n177_), .B(new_n396_), .C(new_n395_), .Y(new_n397_));
  INVx1_ASAP7_75t_R   g339(.A(new_n397_), .Y(new_n398_));
  OA21x2_ASAP7_75t_R  g340(.A1(new_n395_), .A2(new_n396_), .B(new_n168_), .Y(new_n399_));
  AOI21x1_ASAP7_75t_R g341(.A1(G30), .A2(new_n328_), .B(G33), .Y(new_n400_));
  OR3x1_ASAP7_75t_R   g342(.A(new_n398_), .B(new_n399_), .C(new_n400_), .Y(new_n401_));
  INVx1_ASAP7_75t_R   g343(.A(new_n401_), .Y(new_n402_));
  AO21x1_ASAP7_75t_R  g344(.A1(G30), .A2(G22), .B(G33), .Y(new_n403_));
  INVx1_ASAP7_75t_R   g345(.A(new_n403_), .Y(new_n404_));
  AO21x1_ASAP7_75t_R  g346(.A1(new_n60_), .A2(new_n62_), .B(new_n398_), .Y(new_n405_));
  NOR2x1_ASAP7_75t_R  g347(.A(new_n399_), .B(new_n405_), .Y(new_n406_));
  OR3x1_ASAP7_75t_R   g348(.A(G33), .B(new_n406_), .C(new_n328_), .Y(new_n407_));
  AND3x1_ASAP7_75t_R  g349(.A(new_n401_), .B(new_n404_), .C(new_n407_), .Y(new_n408_));
  AOI21x1_ASAP7_75t_R g350(.A1(new_n60_), .A2(new_n62_), .B(new_n399_), .Y(new_n409_));
  OR3x1_ASAP7_75t_R   g351(.A(new_n168_), .B(new_n396_), .C(new_n395_), .Y(new_n410_));
  AOI21x1_ASAP7_75t_R g352(.A1(new_n409_), .A2(new_n410_), .B(new_n328_), .Y(new_n411_));
  AO21x1_ASAP7_75t_R  g353(.A1(new_n60_), .A2(new_n411_), .B(new_n402_), .Y(new_n412_));
  AO21x1_ASAP7_75t_R  g354(.A1(new_n403_), .A2(new_n412_), .B(new_n408_), .Y(G1907));
  AND3x1_ASAP7_75t_R  g355(.A(G26), .B(new_n331_), .C(new_n61_), .Y(new_n414_));
  OR3x1_ASAP7_75t_R   g356(.A(G31), .B(new_n84_), .C(new_n332_), .Y(new_n415_));
  OA21x2_ASAP7_75t_R  g357(.A1(new_n169_), .A2(new_n170_), .B(new_n415_), .Y(new_n416_));
  AO21x1_ASAP7_75t_R  g358(.A1(new_n178_), .A2(new_n414_), .B(new_n416_), .Y(new_n417_));
  OR2x4_ASAP7_75t_R   g359(.A(new_n178_), .B(new_n414_), .Y(new_n418_));
  OR3x1_ASAP7_75t_R   g360(.A(new_n170_), .B(new_n415_), .C(new_n169_), .Y(new_n419_));
  AND3x1_ASAP7_75t_R  g361(.A(new_n173_), .B(new_n418_), .C(new_n419_), .Y(new_n420_));
  AOI21x1_ASAP7_75t_R g362(.A1(new_n144_), .A2(new_n417_), .B(new_n420_), .Y(new_n421_));
  NOR2x1_ASAP7_75t_R  g363(.A(new_n352_), .B(new_n421_), .Y(G1908));
endmodule


