// Benchmark "/home/flynn/workplace/MIGBalance/results_v2/emorphic_random_area_20261012/c1908/rewritten_egraph_with_weight_cost_serd_random-based-faster-bottom-up_7/logic" written by ABC on Mon Oct 12 14:24:50 2026

module \/home/flynn/workplace/MIGBalance/results_v2/emorphic_random_area_20261012/c1908/rewritten_egraph_with_weight_cost_serd_random-based-faster-bottom-up_7/logic  ( 
    G24, G33, G31, G30, G32, G8, G6, G3, G15, G10, G12, G19, G28, G9, G14,
    G16, G18, G11, G5, G2, G27, G7, G4, G20, G13, G1, G17, G26, G22, G25,
    G21, G29, G23,
    G1899, G1884, G1885, G1898, G1886, G1887, G1888, G1889, G1890, G1891,
    G1892, G1893, G1894, G1895, G1896, G1897, G1900, G1901, G1902, G1903,
    G1904, G1905, G1906, G1907, G1908  );
  input  G24, G33, G31, G30, G32, G8, G6, G3, G15, G10, G12, G19, G28,
    G9, G14, G16, G18, G11, G5, G2, G27, G7, G4, G20, G13, G1, G17, G26,
    G22, G25, G21, G29, G23;
  output G1899, G1884, G1885, G1898, G1886, G1887, G1888, G1889, G1890, G1891,
    G1892, G1893, G1894, G1895, G1896, G1897, G1900, G1901, G1902, G1903,
    G1904, G1905, G1906, G1907, G1908;
  wire new_n59_, new_n60_, new_n61_, new_n62_, new_n63_, new_n64_, new_n65_,
    new_n66_, new_n67_, new_n68_, new_n69_, new_n70_, new_n71_, new_n72_,
    new_n73_, new_n74_, new_n75_, new_n76_, new_n77_, new_n78_, new_n79_,
    new_n80_, new_n81_, new_n82_, new_n83_, new_n84_, new_n85_, new_n86_,
    new_n87_, new_n88_, new_n89_, new_n90_, new_n91_, new_n92_, new_n93_,
    new_n94_, new_n95_, new_n96_, new_n97_, new_n98_, new_n99_, new_n100_,
    new_n101_, new_n102_, new_n103_, new_n104_, new_n105_, new_n106_,
    new_n107_, new_n108_, new_n109_, new_n110_, new_n111_, new_n112_,
    new_n113_, new_n114_, new_n115_, new_n116_, new_n117_, new_n118_,
    new_n119_, new_n120_, new_n121_, new_n122_, new_n123_, new_n124_,
    new_n125_, new_n126_, new_n127_, new_n128_, new_n129_, new_n130_,
    new_n131_, new_n132_, new_n133_, new_n134_, new_n135_, new_n136_,
    new_n137_, new_n138_, new_n139_, new_n140_, new_n141_, new_n142_,
    new_n143_, new_n144_, new_n145_, new_n146_, new_n147_, new_n148_,
    new_n149_, new_n150_, new_n151_, new_n152_, new_n153_, new_n154_,
    new_n155_, new_n156_, new_n157_, new_n158_, new_n159_, new_n160_,
    new_n161_, new_n162_, new_n163_, new_n164_, new_n165_, new_n166_,
    new_n167_, new_n168_, new_n169_, new_n170_, new_n171_, new_n172_,
    new_n173_, new_n174_, new_n175_, new_n176_, new_n177_, new_n178_,
    new_n179_, new_n180_, new_n181_, new_n182_, new_n183_, new_n184_,
    new_n185_, new_n186_, new_n187_, new_n188_, new_n189_, new_n190_,
    new_n191_, new_n192_, new_n193_, new_n194_, new_n195_, new_n196_,
    new_n197_, new_n198_, new_n199_, new_n200_, new_n201_, new_n202_,
    new_n203_, new_n204_, new_n205_, new_n206_, new_n207_, new_n208_,
    new_n209_, new_n210_, new_n211_, new_n212_, new_n213_, new_n214_,
    new_n215_, new_n216_, new_n217_, new_n218_, new_n219_, new_n220_,
    new_n221_, new_n222_, new_n223_, new_n224_, new_n225_, new_n226_,
    new_n227_, new_n228_, new_n229_, new_n230_, new_n231_, new_n232_,
    new_n233_, new_n234_, new_n235_, new_n236_, new_n237_, new_n238_,
    new_n239_, new_n240_, new_n241_, new_n242_, new_n243_, new_n244_,
    new_n245_, new_n246_, new_n247_, new_n248_, new_n249_, new_n250_,
    new_n251_, new_n252_, new_n253_, new_n254_, new_n255_, new_n256_,
    new_n257_, new_n258_, new_n259_, new_n260_, new_n261_, new_n262_,
    new_n263_, new_n264_, new_n265_, new_n266_, new_n267_, new_n268_,
    new_n269_, new_n270_, new_n271_, new_n272_, new_n273_, new_n274_,
    new_n275_, new_n276_, new_n277_, new_n278_, new_n279_, new_n280_,
    new_n281_, new_n282_, new_n283_, new_n284_, new_n286_, new_n287_,
    new_n288_, new_n289_, new_n290_, new_n291_, new_n292_, new_n293_,
    new_n294_, new_n300_, new_n304_, new_n305_, new_n306_, new_n307_,
    new_n312_, new_n316_, new_n317_, new_n318_, new_n319_, new_n320_,
    new_n321_, new_n322_, new_n323_, new_n324_, new_n325_, new_n326_,
    new_n327_, new_n328_, new_n329_, new_n330_, new_n331_, new_n332_,
    new_n333_, new_n334_, new_n335_, new_n336_, new_n337_, new_n338_,
    new_n339_, new_n340_, new_n341_, new_n342_, new_n344_, new_n345_,
    new_n346_, new_n347_, new_n348_, new_n349_, new_n350_, new_n351_,
    new_n352_, new_n354_, new_n355_, new_n356_, new_n357_, new_n358_,
    new_n360_, new_n361_, new_n362_, new_n364_, new_n365_, new_n366_,
    new_n367_, new_n368_, new_n369_, new_n371_, new_n372_, new_n373_,
    new_n374_, new_n376_, new_n377_, new_n378_, new_n379_, new_n380_,
    new_n381_, new_n382_, new_n383_, new_n384_, new_n385_, new_n386_,
    new_n388_, new_n389_, new_n390_, new_n391_, new_n392_, new_n393_,
    new_n394_, new_n395_, new_n396_, new_n397_, new_n398_, new_n399_,
    new_n400_, new_n401_, new_n402_, new_n403_, new_n404_, new_n406_,
    new_n407_, new_n408_, new_n409_, new_n410_, new_n411_, new_n412_,
    new_n413_, new_n414_;
  INVx1_ASAP7_75t_R   g000(.A(G24), .Y(new_n59_));
  INVx1_ASAP7_75t_R   g001(.A(G33), .Y(new_n60_));
  INVx1_ASAP7_75t_R   g002(.A(G31), .Y(new_n61_));
  INVx1_ASAP7_75t_R   g003(.A(G8), .Y(new_n62_));
  INVx1_ASAP7_75t_R   g004(.A(G6), .Y(new_n63_));
  INVx1_ASAP7_75t_R   g005(.A(G3), .Y(new_n64_));
  INVx1_ASAP7_75t_R   g006(.A(G15), .Y(new_n65_));
  INVx1_ASAP7_75t_R   g007(.A(G10), .Y(new_n66_));
  INVx1_ASAP7_75t_R   g008(.A(G12), .Y(new_n67_));
  INVx1_ASAP7_75t_R   g009(.A(G19), .Y(new_n68_));
  INVx1_ASAP7_75t_R   g010(.A(G28), .Y(new_n69_));
  INVx1_ASAP7_75t_R   g011(.A(G9), .Y(new_n70_));
  INVx1_ASAP7_75t_R   g012(.A(G14), .Y(new_n71_));
  INVx1_ASAP7_75t_R   g013(.A(G16), .Y(new_n72_));
  INVx1_ASAP7_75t_R   g014(.A(G18), .Y(new_n73_));
  INVx1_ASAP7_75t_R   g015(.A(G5), .Y(new_n74_));
  INVx1_ASAP7_75t_R   g016(.A(G2), .Y(new_n75_));
  INVx1_ASAP7_75t_R   g017(.A(G7), .Y(new_n76_));
  INVx1_ASAP7_75t_R   g018(.A(G4), .Y(new_n77_));
  INVx1_ASAP7_75t_R   g019(.A(G20), .Y(new_n78_));
  INVx1_ASAP7_75t_R   g020(.A(G13), .Y(new_n79_));
  INVx1_ASAP7_75t_R   g021(.A(G1), .Y(new_n80_));
  INVx1_ASAP7_75t_R   g022(.A(G17), .Y(new_n81_));
  INVx1_ASAP7_75t_R   g023(.A(G26), .Y(new_n82_));
  INVx1_ASAP7_75t_R   g024(.A(G25), .Y(new_n83_));
  INVx1_ASAP7_75t_R   g025(.A(G21), .Y(new_n84_));
  INVx1_ASAP7_75t_R   g026(.A(G29), .Y(new_n85_));
  INVx1_ASAP7_75t_R   g027(.A(G23), .Y(new_n86_));
  XNOR2x2_ASAP7_75t_R g028(.A(G3), .B(G2), .Y(new_n87_));
  NOR2x1_ASAP7_75t_R  g029(.A(G1), .B(new_n87_), .Y(new_n88_));
  AND2x2_ASAP7_75t_R  g030(.A(G1), .B(new_n87_), .Y(new_n89_));
  NOR2x1_ASAP7_75t_R  g031(.A(new_n65_), .B(new_n72_), .Y(new_n90_));
  NOR2x1_ASAP7_75t_R  g032(.A(G15), .B(G16), .Y(new_n91_));
  OA21x2_ASAP7_75t_R  g033(.A1(new_n90_), .A2(new_n91_), .B(G10), .Y(new_n92_));
  OR3x1_ASAP7_75t_R   g034(.A(G10), .B(new_n90_), .C(new_n91_), .Y(new_n93_));
  INVx1_ASAP7_75t_R   g035(.A(new_n93_), .Y(new_n94_));
  NOR2x1_ASAP7_75t_R  g036(.A(new_n92_), .B(new_n94_), .Y(new_n95_));
  INVx1_ASAP7_75t_R   g037(.A(new_n95_), .Y(new_n96_));
  OR3x1_ASAP7_75t_R   g038(.A(new_n89_), .B(new_n95_), .C(new_n88_), .Y(new_n97_));
  AO21x1_ASAP7_75t_R  g039(.A1(G3), .A2(G2), .B(G1), .Y(new_n98_));
  AOI21x1_ASAP7_75t_R g040(.A1(new_n64_), .A2(new_n75_), .B(new_n98_), .Y(new_n99_));
  NOR2x1_ASAP7_75t_R  g041(.A(new_n89_), .B(new_n99_), .Y(new_n100_));
  OR3x1_ASAP7_75t_R   g042(.A(new_n94_), .B(new_n100_), .C(new_n92_), .Y(new_n101_));
  NOR2x1_ASAP7_75t_R  g043(.A(G12), .B(G13), .Y(new_n102_));
  NOR2x1_ASAP7_75t_R  g044(.A(new_n67_), .B(new_n79_), .Y(new_n103_));
  OR3x1_ASAP7_75t_R   g045(.A(G11), .B(new_n103_), .C(new_n102_), .Y(new_n104_));
  OAI21x1_ASAP7_75t_R g046(.A1(new_n102_), .A2(new_n103_), .B(G11), .Y(new_n105_));
  AND2x2_ASAP7_75t_R  g047(.A(new_n104_), .B(new_n105_), .Y(new_n106_));
  AOI21x1_ASAP7_75t_R g048(.A1(new_n97_), .A2(new_n101_), .B(new_n106_), .Y(new_n107_));
  AND2x2_ASAP7_75t_R  g049(.A(new_n97_), .B(new_n104_), .Y(new_n108_));
  AND3x1_ASAP7_75t_R  g050(.A(new_n105_), .B(new_n108_), .C(new_n101_), .Y(new_n109_));
  NAND2x1_ASAP7_75t_R g051(.A(new_n60_), .B(G22), .Y(new_n110_));
  NOR2x1_ASAP7_75t_R  g052(.A(G14), .B(G4), .Y(new_n111_));
  INVx1_ASAP7_75t_R   g053(.A(new_n111_), .Y(new_n112_));
  AO21x1_ASAP7_75t_R  g054(.A1(G14), .A2(G4), .B(new_n111_), .Y(new_n113_));
  INVx1_ASAP7_75t_R   g055(.A(new_n113_), .Y(new_n114_));
  AND3x1_ASAP7_75t_R  g056(.A(new_n60_), .B(new_n113_), .C(G22), .Y(new_n115_));
  AO21x1_ASAP7_75t_R  g057(.A1(new_n110_), .A2(new_n114_), .B(new_n115_), .Y(new_n116_));
  OR3x1_ASAP7_75t_R   g058(.A(new_n107_), .B(new_n109_), .C(new_n116_), .Y(new_n117_));
  INVx1_ASAP7_75t_R   g059(.A(new_n117_), .Y(new_n118_));
  OR3x1_ASAP7_75t_R   g060(.A(G11), .B(new_n102_), .C(new_n103_), .Y(new_n119_));
  AND2x2_ASAP7_75t_R  g061(.A(new_n105_), .B(new_n119_), .Y(new_n120_));
  OR3x1_ASAP7_75t_R   g062(.A(new_n89_), .B(new_n95_), .C(new_n99_), .Y(new_n121_));
  OA21x2_ASAP7_75t_R  g063(.A1(new_n96_), .A2(new_n100_), .B(new_n121_), .Y(new_n122_));
  NOR2x1_ASAP7_75t_R  g064(.A(new_n120_), .B(new_n122_), .Y(new_n123_));
  OA21x2_ASAP7_75t_R  g065(.A1(new_n71_), .A2(new_n77_), .B(new_n110_), .Y(new_n124_));
  AO21x1_ASAP7_75t_R  g066(.A1(new_n112_), .A2(new_n124_), .B(new_n115_), .Y(new_n125_));
  OA21x2_ASAP7_75t_R  g067(.A1(new_n109_), .A2(new_n123_), .B(new_n125_), .Y(new_n126_));
  INVx1_ASAP7_75t_R   g068(.A(new_n126_), .Y(new_n127_));
  NOR2x1_ASAP7_75t_R  g069(.A(new_n118_), .B(new_n126_), .Y(new_n128_));
  OR3x1_ASAP7_75t_R   g070(.A(G31), .B(G25), .C(new_n128_), .Y(new_n129_));
  INVx1_ASAP7_75t_R   g071(.A(new_n129_), .Y(new_n130_));
  OA21x2_ASAP7_75t_R  g072(.A1(G31), .A2(new_n128_), .B(G25), .Y(new_n131_));
  NOR2x1_ASAP7_75t_R  g073(.A(new_n130_), .B(new_n131_), .Y(new_n132_));
  INVx1_ASAP7_75t_R   g074(.A(new_n132_), .Y(new_n133_));
  NOR2x1_ASAP7_75t_R  g075(.A(G31), .B(G23), .Y(new_n134_));
  OR3x1_ASAP7_75t_R   g076(.A(new_n132_), .B(new_n134_), .C(new_n78_), .Y(new_n135_));
  INVx1_ASAP7_75t_R   g077(.A(new_n135_), .Y(new_n136_));
  NOR2x1_ASAP7_75t_R  g078(.A(new_n63_), .B(new_n76_), .Y(new_n137_));
  NOR2x1_ASAP7_75t_R  g079(.A(G6), .B(G7), .Y(new_n138_));
  OA21x2_ASAP7_75t_R  g080(.A1(new_n137_), .A2(new_n138_), .B(G5), .Y(new_n139_));
  OR3x1_ASAP7_75t_R   g081(.A(G5), .B(new_n137_), .C(new_n138_), .Y(new_n140_));
  INVx1_ASAP7_75t_R   g082(.A(new_n140_), .Y(new_n141_));
  NOR2x1_ASAP7_75t_R  g083(.A(new_n139_), .B(new_n141_), .Y(new_n142_));
  OR2x4_ASAP7_75t_R   g084(.A(new_n100_), .B(new_n142_), .Y(new_n143_));
  OR3x1_ASAP7_75t_R   g085(.A(new_n89_), .B(new_n139_), .C(new_n141_), .Y(new_n144_));
  OA21x2_ASAP7_75t_R  g086(.A1(new_n88_), .A2(new_n144_), .B(new_n143_), .Y(new_n145_));
  XNOR2x2_ASAP7_75t_R g087(.A(G8), .B(new_n77_), .Y(new_n146_));
  AND2x2_ASAP7_75t_R  g088(.A(new_n145_), .B(new_n146_), .Y(new_n147_));
  OA21x2_ASAP7_75t_R  g089(.A1(new_n99_), .A2(new_n144_), .B(new_n143_), .Y(new_n148_));
  NOR2x1_ASAP7_75t_R  g090(.A(new_n146_), .B(new_n148_), .Y(new_n149_));
  NOR2x1_ASAP7_75t_R  g091(.A(new_n147_), .B(new_n149_), .Y(new_n150_));
  NOR2x1_ASAP7_75t_R  g092(.A(G9), .B(new_n95_), .Y(new_n151_));
  OR3x1_ASAP7_75t_R   g093(.A(new_n70_), .B(new_n94_), .C(new_n92_), .Y(new_n152_));
  INVx1_ASAP7_75t_R   g094(.A(new_n152_), .Y(new_n153_));
  NOR2x1_ASAP7_75t_R  g095(.A(new_n151_), .B(new_n153_), .Y(new_n154_));
  OR3x1_ASAP7_75t_R   g096(.A(G33), .B(new_n154_), .C(new_n84_), .Y(new_n155_));
  AO21x1_ASAP7_75t_R  g097(.A1(new_n60_), .A2(G21), .B(new_n153_), .Y(new_n156_));
  AO21x1_ASAP7_75t_R  g098(.A1(new_n70_), .A2(new_n96_), .B(new_n156_), .Y(new_n157_));
  NAND2x1_ASAP7_75t_R g099(.A(new_n155_), .B(new_n157_), .Y(new_n158_));
  INVx1_ASAP7_75t_R   g100(.A(new_n158_), .Y(new_n159_));
  AO21x1_ASAP7_75t_R  g101(.A1(G9), .A2(new_n95_), .B(new_n151_), .Y(new_n160_));
  AO21x1_ASAP7_75t_R  g102(.A1(new_n60_), .A2(G21), .B(new_n160_), .Y(new_n161_));
  OR3x1_ASAP7_75t_R   g103(.A(G33), .B(new_n84_), .C(new_n154_), .Y(new_n162_));
  AO21x1_ASAP7_75t_R  g104(.A1(new_n62_), .A2(G4), .B(new_n145_), .Y(new_n163_));
  AO21x1_ASAP7_75t_R  g105(.A1(G8), .A2(new_n77_), .B(new_n163_), .Y(new_n164_));
  INVx1_ASAP7_75t_R   g106(.A(new_n164_), .Y(new_n165_));
  NOR2x1_ASAP7_75t_R  g107(.A(new_n147_), .B(new_n165_), .Y(new_n166_));
  INVx1_ASAP7_75t_R   g108(.A(new_n166_), .Y(new_n167_));
  AND3x1_ASAP7_75t_R  g109(.A(new_n162_), .B(new_n167_), .C(new_n161_), .Y(new_n168_));
  AO21x1_ASAP7_75t_R  g110(.A1(new_n150_), .A2(new_n158_), .B(new_n168_), .Y(new_n169_));
  NAND2x1_ASAP7_75t_R g111(.A(G24), .B(new_n169_), .Y(new_n170_));
  AOI21x1_ASAP7_75t_R g112(.A1(new_n61_), .A2(new_n170_), .B(new_n81_), .Y(new_n171_));
  OA21x2_ASAP7_75t_R  g113(.A1(G24), .A2(G31), .B(G17), .Y(new_n172_));
  OR3x1_ASAP7_75t_R   g114(.A(new_n169_), .B(new_n172_), .C(G31), .Y(new_n173_));
  INVx1_ASAP7_75t_R   g115(.A(new_n173_), .Y(new_n174_));
  AO21x1_ASAP7_75t_R  g116(.A1(new_n59_), .A2(new_n61_), .B(new_n73_), .Y(new_n175_));
  INVx1_ASAP7_75t_R   g117(.A(new_n175_), .Y(new_n176_));
  OR3x1_ASAP7_75t_R   g118(.A(new_n174_), .B(new_n175_), .C(new_n171_), .Y(new_n177_));
  OR2x4_ASAP7_75t_R   g119(.A(new_n136_), .B(new_n177_), .Y(new_n178_));
  NOR2x1_ASAP7_75t_R  g120(.A(G10), .B(new_n76_), .Y(new_n179_));
  NOR2x1_ASAP7_75t_R  g121(.A(new_n66_), .B(G7), .Y(new_n180_));
  OA21x2_ASAP7_75t_R  g122(.A1(new_n179_), .A2(new_n180_), .B(new_n77_), .Y(new_n181_));
  NOR2x1_ASAP7_75t_R  g123(.A(new_n70_), .B(new_n71_), .Y(new_n182_));
  NOR2x1_ASAP7_75t_R  g124(.A(G9), .B(G14), .Y(new_n183_));
  OA21x2_ASAP7_75t_R  g125(.A1(new_n182_), .A2(new_n183_), .B(G16), .Y(new_n184_));
  OR3x1_ASAP7_75t_R   g126(.A(G16), .B(new_n182_), .C(new_n183_), .Y(new_n185_));
  INVx1_ASAP7_75t_R   g127(.A(new_n185_), .Y(new_n186_));
  NOR2x1_ASAP7_75t_R  g128(.A(new_n184_), .B(new_n186_), .Y(new_n187_));
  OR3x1_ASAP7_75t_R   g129(.A(new_n77_), .B(new_n179_), .C(new_n180_), .Y(new_n188_));
  INVx1_ASAP7_75t_R   g130(.A(new_n188_), .Y(new_n189_));
  OR3x1_ASAP7_75t_R   g131(.A(new_n181_), .B(new_n187_), .C(new_n189_), .Y(new_n190_));
  INVx1_ASAP7_75t_R   g132(.A(new_n190_), .Y(new_n191_));
  OR3x1_ASAP7_75t_R   g133(.A(new_n77_), .B(new_n180_), .C(new_n179_), .Y(new_n192_));
  INVx1_ASAP7_75t_R   g134(.A(new_n192_), .Y(new_n193_));
  NOR2x1_ASAP7_75t_R  g135(.A(new_n181_), .B(new_n193_), .Y(new_n194_));
  OR3x1_ASAP7_75t_R   g136(.A(new_n184_), .B(new_n194_), .C(new_n186_), .Y(new_n195_));
  INVx1_ASAP7_75t_R   g137(.A(new_n195_), .Y(new_n196_));
  NOR2x1_ASAP7_75t_R  g138(.A(G33), .B(G23), .Y(new_n197_));
  INVx1_ASAP7_75t_R   g139(.A(new_n197_), .Y(new_n198_));
  OR3x1_ASAP7_75t_R   g140(.A(G33), .B(G23), .C(new_n78_), .Y(new_n199_));
  AND3x1_ASAP7_75t_R  g141(.A(G20), .B(new_n79_), .C(new_n197_), .Y(new_n200_));
  AOI21x1_ASAP7_75t_R g142(.A1(G13), .A2(new_n199_), .B(new_n200_), .Y(new_n201_));
  AOI21x1_ASAP7_75t_R g143(.A1(new_n190_), .A2(new_n195_), .B(new_n201_), .Y(new_n202_));
  OR3x1_ASAP7_75t_R   g144(.A(new_n196_), .B(new_n200_), .C(new_n191_), .Y(new_n203_));
  OR3x1_ASAP7_75t_R   g145(.A(new_n78_), .B(G23), .C(G33), .Y(new_n204_));
  AOI21x1_ASAP7_75t_R g146(.A1(G13), .A2(new_n204_), .B(new_n203_), .Y(new_n205_));
  NOR2x1_ASAP7_75t_R  g147(.A(new_n202_), .B(new_n205_), .Y(new_n206_));
  INVx1_ASAP7_75t_R   g148(.A(new_n206_), .Y(new_n207_));
  AO21x1_ASAP7_75t_R  g149(.A1(new_n61_), .A2(new_n86_), .B(new_n68_), .Y(new_n208_));
  AND3x1_ASAP7_75t_R  g150(.A(new_n61_), .B(new_n208_), .C(new_n207_), .Y(new_n209_));
  NOR2x1_ASAP7_75t_R  g151(.A(new_n86_), .B(new_n207_), .Y(new_n210_));
  OA21x2_ASAP7_75t_R  g152(.A1(G31), .A2(new_n210_), .B(G19), .Y(new_n211_));
  OR2x4_ASAP7_75t_R   g153(.A(new_n209_), .B(new_n211_), .Y(new_n212_));
  NOR2x1_ASAP7_75t_R  g154(.A(new_n80_), .B(new_n81_), .Y(new_n213_));
  AND3x1_ASAP7_75t_R  g155(.A(new_n59_), .B(new_n60_), .C(new_n213_), .Y(new_n214_));
  AND3x1_ASAP7_75t_R  g156(.A(new_n59_), .B(new_n60_), .C(G17), .Y(new_n215_));
  NOR2x1_ASAP7_75t_R  g157(.A(G1), .B(new_n215_), .Y(new_n216_));
  OR3x1_ASAP7_75t_R   g158(.A(new_n92_), .B(new_n120_), .C(new_n94_), .Y(new_n217_));
  INVx1_ASAP7_75t_R   g159(.A(new_n217_), .Y(new_n218_));
  AND3x1_ASAP7_75t_R  g160(.A(new_n96_), .B(new_n104_), .C(new_n105_), .Y(new_n219_));
  OR3x1_ASAP7_75t_R   g161(.A(new_n142_), .B(new_n219_), .C(new_n218_), .Y(new_n220_));
  INVx1_ASAP7_75t_R   g162(.A(new_n220_), .Y(new_n221_));
  NOR2x1_ASAP7_75t_R  g163(.A(new_n218_), .B(new_n219_), .Y(new_n222_));
  INVx1_ASAP7_75t_R   g164(.A(new_n222_), .Y(new_n223_));
  OR3x1_ASAP7_75t_R   g165(.A(new_n139_), .B(new_n222_), .C(new_n141_), .Y(new_n224_));
  INVx1_ASAP7_75t_R   g166(.A(new_n224_), .Y(new_n225_));
  NOR2x1_ASAP7_75t_R  g167(.A(new_n221_), .B(new_n225_), .Y(new_n226_));
  OR3x1_ASAP7_75t_R   g168(.A(new_n216_), .B(new_n226_), .C(new_n214_), .Y(new_n227_));
  INVx1_ASAP7_75t_R   g169(.A(new_n227_), .Y(new_n228_));
  AO21x1_ASAP7_75t_R  g170(.A1(G1), .A2(new_n215_), .B(new_n216_), .Y(new_n229_));
  AO21x1_ASAP7_75t_R  g171(.A1(new_n226_), .A2(new_n229_), .B(new_n228_), .Y(new_n230_));
  AOI21x1_ASAP7_75t_R g172(.A1(new_n61_), .A2(new_n230_), .B(new_n82_), .Y(new_n231_));
  AND3x1_ASAP7_75t_R  g173(.A(new_n61_), .B(new_n82_), .C(new_n230_), .Y(new_n232_));
  OR2x4_ASAP7_75t_R   g174(.A(new_n231_), .B(new_n232_), .Y(new_n233_));
  OR3x1_ASAP7_75t_R   g175(.A(new_n209_), .B(new_n211_), .C(new_n233_), .Y(new_n234_));
  OA21x2_ASAP7_75t_R  g176(.A1(G31), .A2(G30), .B(G32), .Y(new_n235_));
  NOR2x1_ASAP7_75t_R  g177(.A(new_n59_), .B(G23), .Y(new_n236_));
  OR3x1_ASAP7_75t_R   g178(.A(G33), .B(new_n236_), .C(new_n235_), .Y(new_n237_));
  NOR2x1_ASAP7_75t_R  g179(.A(G8), .B(new_n63_), .Y(new_n238_));
  NOR2x1_ASAP7_75t_R  g180(.A(new_n62_), .B(G6), .Y(new_n239_));
  OA21x2_ASAP7_75t_R  g181(.A1(new_n238_), .A2(new_n239_), .B(new_n64_), .Y(new_n240_));
  OR3x1_ASAP7_75t_R   g182(.A(new_n64_), .B(new_n239_), .C(new_n238_), .Y(new_n241_));
  INVx1_ASAP7_75t_R   g183(.A(new_n241_), .Y(new_n242_));
  NOR2x1_ASAP7_75t_R  g184(.A(G15), .B(new_n66_), .Y(new_n243_));
  NOR2x1_ASAP7_75t_R  g185(.A(new_n65_), .B(G10), .Y(new_n244_));
  OAI21x1_ASAP7_75t_R g186(.A1(new_n243_), .A2(new_n244_), .B(new_n67_), .Y(new_n245_));
  OA21x2_ASAP7_75t_R  g187(.A1(new_n240_), .A2(new_n242_), .B(new_n245_), .Y(new_n246_));
  OR3x1_ASAP7_75t_R   g188(.A(new_n67_), .B(new_n243_), .C(new_n244_), .Y(new_n247_));
  NAND2x1_ASAP7_75t_R g189(.A(new_n246_), .B(new_n247_), .Y(new_n248_));
  OR3x1_ASAP7_75t_R   g190(.A(new_n67_), .B(new_n244_), .C(new_n243_), .Y(new_n249_));
  AO21x1_ASAP7_75t_R  g191(.A1(new_n245_), .A2(new_n249_), .B(new_n240_), .Y(new_n250_));
  OR2x4_ASAP7_75t_R   g192(.A(new_n242_), .B(new_n250_), .Y(new_n251_));
  OR3x1_ASAP7_75t_R   g193(.A(G33), .B(G23), .C(new_n68_), .Y(new_n252_));
  INVx1_ASAP7_75t_R   g194(.A(new_n252_), .Y(new_n253_));
  AND3x1_ASAP7_75t_R  g195(.A(new_n251_), .B(new_n253_), .C(new_n248_), .Y(new_n254_));
  AO21x1_ASAP7_75t_R  g196(.A1(new_n245_), .A2(new_n247_), .B(new_n242_), .Y(new_n255_));
  NOR2x1_ASAP7_75t_R  g197(.A(new_n240_), .B(new_n255_), .Y(new_n256_));
  AO21x1_ASAP7_75t_R  g198(.A1(new_n246_), .A2(new_n249_), .B(new_n256_), .Y(new_n257_));
  AND2x2_ASAP7_75t_R  g199(.A(new_n252_), .B(new_n257_), .Y(new_n258_));
  OA21x2_ASAP7_75t_R  g200(.A1(new_n254_), .A2(new_n258_), .B(new_n61_), .Y(new_n259_));
  INVx1_ASAP7_75t_R   g201(.A(new_n259_), .Y(new_n260_));
  XNOR2x2_ASAP7_75t_R g202(.A(G28), .B(new_n260_), .Y(new_n261_));
  OR3x1_ASAP7_75t_R   g203(.A(G24), .B(G33), .C(new_n73_), .Y(new_n262_));
  NAND2x1_ASAP7_75t_R g204(.A(G15), .B(new_n262_), .Y(new_n263_));
  OR2x4_ASAP7_75t_R   g205(.A(G15), .B(new_n262_), .Y(new_n264_));
  AND3x1_ASAP7_75t_R  g206(.A(G11), .B(new_n263_), .C(new_n264_), .Y(new_n265_));
  AOI21x1_ASAP7_75t_R g207(.A1(new_n263_), .A2(new_n264_), .B(G11), .Y(new_n266_));
  OAI21x1_ASAP7_75t_R g208(.A1(new_n265_), .A2(new_n266_), .B(new_n187_), .Y(new_n267_));
  OR3x1_ASAP7_75t_R   g209(.A(new_n187_), .B(new_n265_), .C(new_n266_), .Y(new_n268_));
  NAND2x1_ASAP7_75t_R g210(.A(G8), .B(new_n74_), .Y(new_n269_));
  OA21x2_ASAP7_75t_R  g211(.A1(G8), .A2(new_n74_), .B(new_n269_), .Y(new_n270_));
  NOR2x1_ASAP7_75t_R  g212(.A(G2), .B(new_n270_), .Y(new_n271_));
  AO21x1_ASAP7_75t_R  g213(.A1(G2), .A2(new_n270_), .B(new_n271_), .Y(new_n272_));
  AND3x1_ASAP7_75t_R  g214(.A(new_n268_), .B(new_n272_), .C(new_n267_), .Y(new_n273_));
  OA21x2_ASAP7_75t_R  g215(.A1(G8), .A2(new_n74_), .B(G2), .Y(new_n274_));
  OR3x1_ASAP7_75t_R   g216(.A(new_n187_), .B(new_n266_), .C(new_n265_), .Y(new_n275_));
  AO21x1_ASAP7_75t_R  g217(.A1(new_n267_), .A2(new_n275_), .B(new_n271_), .Y(new_n276_));
  AOI21x1_ASAP7_75t_R g218(.A1(new_n269_), .A2(new_n274_), .B(new_n276_), .Y(new_n277_));
  NOR2x1_ASAP7_75t_R  g219(.A(new_n273_), .B(new_n277_), .Y(new_n278_));
  OR3x1_ASAP7_75t_R   g220(.A(G31), .B(G27), .C(new_n278_), .Y(new_n279_));
  INVx1_ASAP7_75t_R   g221(.A(new_n279_), .Y(new_n280_));
  OA21x2_ASAP7_75t_R  g222(.A1(G31), .A2(new_n278_), .B(G27), .Y(new_n281_));
  OR2x4_ASAP7_75t_R   g223(.A(new_n280_), .B(new_n281_), .Y(new_n282_));
  OR3x1_ASAP7_75t_R   g224(.A(new_n237_), .B(new_n261_), .C(new_n282_), .Y(new_n283_));
  OR3x1_ASAP7_75t_R   g225(.A(new_n178_), .B(new_n234_), .C(new_n283_), .Y(new_n284_));
  XNOR2x2_ASAP7_75t_R g226(.A(new_n71_), .B(new_n284_), .Y(G1899));
  OA21x2_ASAP7_75t_R  g227(.A1(G31), .A2(G29), .B(G32), .Y(new_n286_));
  OR3x1_ASAP7_75t_R   g228(.A(G33), .B(new_n236_), .C(new_n286_), .Y(new_n287_));
  OR3x1_ASAP7_75t_R   g229(.A(new_n261_), .B(new_n281_), .C(new_n280_), .Y(new_n288_));
  NOR2x1_ASAP7_75t_R  g230(.A(new_n171_), .B(new_n174_), .Y(new_n289_));
  INVx1_ASAP7_75t_R   g231(.A(new_n289_), .Y(new_n290_));
  NOR2x1_ASAP7_75t_R  g232(.A(new_n175_), .B(new_n289_), .Y(new_n291_));
  OR3x1_ASAP7_75t_R   g233(.A(new_n136_), .B(new_n291_), .C(new_n231_), .Y(new_n292_));
  OR3x1_ASAP7_75t_R   g234(.A(new_n232_), .B(new_n292_), .C(new_n212_), .Y(new_n293_));
  OR3x1_ASAP7_75t_R   g235(.A(new_n288_), .B(new_n293_), .C(new_n287_), .Y(new_n294_));
  XNOR2x2_ASAP7_75t_R g236(.A(new_n80_), .B(new_n294_), .Y(G1884));
  XNOR2x2_ASAP7_75t_R g237(.A(new_n75_), .B(new_n294_), .Y(G1885));
  XNOR2x2_ASAP7_75t_R g238(.A(new_n79_), .B(new_n284_), .Y(G1898));
  XNOR2x2_ASAP7_75t_R g239(.A(new_n64_), .B(new_n294_), .Y(G1886));
  XNOR2x2_ASAP7_75t_R g240(.A(new_n77_), .B(new_n294_), .Y(G1887));
  OR3x1_ASAP7_75t_R   g241(.A(new_n288_), .B(new_n293_), .C(new_n237_), .Y(new_n300_));
  XNOR2x2_ASAP7_75t_R g242(.A(new_n66_), .B(new_n300_), .Y(G1888));
  XNOR2x2_ASAP7_75t_R g243(.A(new_n65_), .B(new_n300_), .Y(G1889));
  XNOR2x2_ASAP7_75t_R g244(.A(new_n72_), .B(new_n300_), .Y(G1890));
  AO21x1_ASAP7_75t_R  g245(.A1(new_n61_), .A2(new_n86_), .B(new_n78_), .Y(new_n304_));
  OR3x1_ASAP7_75t_R   g246(.A(new_n291_), .B(new_n304_), .C(new_n133_), .Y(new_n305_));
  OR2x4_ASAP7_75t_R   g247(.A(new_n287_), .B(new_n288_), .Y(new_n306_));
  OR3x1_ASAP7_75t_R   g248(.A(new_n234_), .B(new_n306_), .C(new_n305_), .Y(new_n307_));
  XNOR2x2_ASAP7_75t_R g249(.A(new_n74_), .B(new_n307_), .Y(G1891));
  XNOR2x2_ASAP7_75t_R g250(.A(new_n63_), .B(new_n307_), .Y(G1892));
  XNOR2x2_ASAP7_75t_R g251(.A(new_n76_), .B(new_n307_), .Y(G1893));
  XNOR2x2_ASAP7_75t_R g252(.A(new_n62_), .B(new_n307_), .Y(G1894));
  OR3x1_ASAP7_75t_R   g253(.A(new_n234_), .B(new_n283_), .C(new_n305_), .Y(new_n312_));
  XNOR2x2_ASAP7_75t_R g254(.A(new_n70_), .B(new_n312_), .Y(G1895));
  XOR2x2_ASAP7_75t_R  g255(.A(G11), .B(new_n284_), .Y(G1896));
  XNOR2x2_ASAP7_75t_R g256(.A(new_n67_), .B(new_n284_), .Y(G1897));
  OR3x1_ASAP7_75t_R   g257(.A(new_n131_), .B(new_n134_), .C(new_n130_), .Y(new_n316_));
  OR3x1_ASAP7_75t_R   g258(.A(new_n78_), .B(new_n177_), .C(new_n316_), .Y(new_n317_));
  AND3x1_ASAP7_75t_R  g259(.A(new_n178_), .B(new_n305_), .C(new_n317_), .Y(new_n318_));
  NOR2x1_ASAP7_75t_R  g260(.A(G33), .B(G32), .Y(new_n319_));
  INVx1_ASAP7_75t_R   g261(.A(new_n319_), .Y(new_n320_));
  OR3x1_ASAP7_75t_R   g262(.A(new_n236_), .B(new_n288_), .C(new_n320_), .Y(new_n321_));
  OR3x1_ASAP7_75t_R   g263(.A(new_n234_), .B(new_n318_), .C(new_n321_), .Y(new_n322_));
  OR3x1_ASAP7_75t_R   g264(.A(new_n211_), .B(new_n233_), .C(new_n209_), .Y(new_n323_));
  OR3x1_ASAP7_75t_R   g265(.A(new_n133_), .B(new_n134_), .C(new_n78_), .Y(new_n324_));
  AND2x2_ASAP7_75t_R  g266(.A(new_n136_), .B(new_n324_), .Y(new_n325_));
  OR3x1_ASAP7_75t_R   g267(.A(new_n291_), .B(new_n323_), .C(new_n325_), .Y(new_n326_));
  NAND2x1_ASAP7_75t_R g268(.A(new_n135_), .B(new_n176_), .Y(new_n327_));
  OR3x1_ASAP7_75t_R   g269(.A(new_n290_), .B(new_n323_), .C(new_n327_), .Y(new_n328_));
  AO21x1_ASAP7_75t_R  g270(.A1(new_n326_), .A2(new_n328_), .B(new_n283_), .Y(new_n329_));
  OR3x1_ASAP7_75t_R   g271(.A(new_n287_), .B(new_n288_), .C(new_n326_), .Y(new_n330_));
  INVx1_ASAP7_75t_R   g272(.A(new_n330_), .Y(new_n331_));
  NAND2x1_ASAP7_75t_R g273(.A(new_n329_), .B(new_n330_), .Y(new_n332_));
  INVx1_ASAP7_75t_R   g274(.A(new_n332_), .Y(new_n333_));
  AND3x1_ASAP7_75t_R  g275(.A(G32), .B(new_n322_), .C(new_n333_), .Y(new_n334_));
  INVx1_ASAP7_75t_R   g276(.A(new_n334_), .Y(new_n335_));
  AO21x1_ASAP7_75t_R  g277(.A1(new_n69_), .A2(new_n259_), .B(new_n212_), .Y(new_n336_));
  AO21x1_ASAP7_75t_R  g278(.A1(G28), .A2(new_n260_), .B(new_n336_), .Y(new_n337_));
  OR3x1_ASAP7_75t_R   g279(.A(new_n233_), .B(new_n282_), .C(new_n337_), .Y(new_n338_));
  INVx1_ASAP7_75t_R   g280(.A(new_n338_), .Y(new_n339_));
  NOR2x1_ASAP7_75t_R  g281(.A(new_n133_), .B(new_n176_), .Y(new_n340_));
  AND3x1_ASAP7_75t_R  g282(.A(new_n289_), .B(new_n304_), .C(new_n340_), .Y(new_n341_));
  AO21x1_ASAP7_75t_R  g283(.A1(new_n339_), .A2(new_n341_), .B(G33), .Y(new_n342_));
  AO21x1_ASAP7_75t_R  g284(.A1(G32), .A2(new_n335_), .B(new_n342_), .Y(G1900));
  OR3x1_ASAP7_75t_R   g285(.A(new_n158_), .B(new_n165_), .C(new_n147_), .Y(new_n344_));
  OA21x2_ASAP7_75t_R  g286(.A1(new_n159_), .A2(new_n166_), .B(new_n344_), .Y(new_n345_));
  AND2x2_ASAP7_75t_R  g287(.A(new_n172_), .B(new_n332_), .Y(new_n346_));
  AO21x1_ASAP7_75t_R  g288(.A1(new_n61_), .A2(new_n346_), .B(new_n345_), .Y(new_n347_));
  AND3x1_ASAP7_75t_R  g289(.A(new_n157_), .B(new_n166_), .C(new_n155_), .Y(new_n348_));
  AOI21x1_ASAP7_75t_R g290(.A1(new_n161_), .A2(new_n162_), .B(new_n150_), .Y(new_n349_));
  OR3x1_ASAP7_75t_R   g291(.A(new_n348_), .B(new_n349_), .C(new_n333_), .Y(new_n350_));
  OR3x1_ASAP7_75t_R   g292(.A(G31), .B(new_n81_), .C(new_n350_), .Y(new_n351_));
  AO21x1_ASAP7_75t_R  g293(.A1(new_n59_), .A2(new_n61_), .B(new_n351_), .Y(new_n352_));
  AOI21x1_ASAP7_75t_R g294(.A1(new_n347_), .A2(new_n352_), .B(new_n319_), .Y(G1901));
  OR3x1_ASAP7_75t_R   g295(.A(new_n109_), .B(new_n125_), .C(new_n123_), .Y(new_n354_));
  AND3x1_ASAP7_75t_R  g296(.A(new_n61_), .B(new_n332_), .C(G25), .Y(new_n355_));
  AO21x1_ASAP7_75t_R  g297(.A1(new_n127_), .A2(new_n354_), .B(new_n355_), .Y(new_n356_));
  OR3x1_ASAP7_75t_R   g298(.A(new_n118_), .B(new_n333_), .C(new_n126_), .Y(new_n357_));
  OR3x1_ASAP7_75t_R   g299(.A(new_n83_), .B(new_n357_), .C(G31), .Y(new_n358_));
  AOI21x1_ASAP7_75t_R g300(.A1(new_n356_), .A2(new_n358_), .B(new_n319_), .Y(G1902));
  AND3x1_ASAP7_75t_R  g301(.A(new_n61_), .B(new_n332_), .C(G27), .Y(new_n360_));
  OR3x1_ASAP7_75t_R   g302(.A(new_n273_), .B(new_n360_), .C(new_n277_), .Y(new_n361_));
  OAI21x1_ASAP7_75t_R g303(.A1(new_n273_), .A2(new_n277_), .B(new_n360_), .Y(new_n362_));
  AOI21x1_ASAP7_75t_R g304(.A1(new_n361_), .A2(new_n362_), .B(new_n319_), .Y(G1903));
  AND3x1_ASAP7_75t_R  g305(.A(new_n61_), .B(G28), .C(new_n332_), .Y(new_n364_));
  OR3x1_ASAP7_75t_R   g306(.A(new_n258_), .B(new_n364_), .C(new_n254_), .Y(new_n365_));
  AO21x1_ASAP7_75t_R  g307(.A1(new_n248_), .A2(new_n251_), .B(new_n253_), .Y(new_n366_));
  OR3x1_ASAP7_75t_R   g308(.A(new_n68_), .B(new_n257_), .C(new_n198_), .Y(new_n367_));
  AO21x1_ASAP7_75t_R  g309(.A1(new_n366_), .A2(new_n367_), .B(new_n333_), .Y(new_n368_));
  OR3x1_ASAP7_75t_R   g310(.A(G31), .B(new_n368_), .C(new_n69_), .Y(new_n369_));
  AOI21x1_ASAP7_75t_R g311(.A1(new_n365_), .A2(new_n369_), .B(new_n319_), .Y(G1904));
  NOR2x1_ASAP7_75t_R  g312(.A(new_n208_), .B(new_n333_), .Y(new_n371_));
  AO21x1_ASAP7_75t_R  g313(.A1(new_n61_), .A2(new_n371_), .B(new_n207_), .Y(new_n372_));
  OR3x1_ASAP7_75t_R   g314(.A(G31), .B(new_n208_), .C(new_n206_), .Y(new_n373_));
  OA21x2_ASAP7_75t_R  g315(.A1(new_n333_), .A2(new_n373_), .B(new_n372_), .Y(new_n374_));
  NOR2x1_ASAP7_75t_R  g316(.A(new_n319_), .B(new_n374_), .Y(G1905));
  NOR2x1_ASAP7_75t_R  g317(.A(new_n85_), .B(new_n331_), .Y(new_n376_));
  OA21x2_ASAP7_75t_R  g318(.A1(G33), .A2(new_n376_), .B(new_n150_), .Y(new_n377_));
  AO21x1_ASAP7_75t_R  g319(.A1(G21), .A2(G29), .B(G33), .Y(new_n378_));
  AO21x1_ASAP7_75t_R  g320(.A1(new_n60_), .A2(new_n85_), .B(new_n149_), .Y(new_n379_));
  NOR2x1_ASAP7_75t_R  g321(.A(G33), .B(new_n330_), .Y(new_n380_));
  OA21x2_ASAP7_75t_R  g322(.A1(new_n147_), .A2(new_n379_), .B(new_n380_), .Y(new_n381_));
  OR3x1_ASAP7_75t_R   g323(.A(new_n377_), .B(new_n378_), .C(new_n381_), .Y(new_n382_));
  INVx1_ASAP7_75t_R   g324(.A(new_n382_), .Y(new_n383_));
  AOI21x1_ASAP7_75t_R g325(.A1(new_n60_), .A2(new_n85_), .B(new_n147_), .Y(new_n384_));
  AOI21x1_ASAP7_75t_R g326(.A1(new_n164_), .A2(new_n384_), .B(G33), .Y(new_n385_));
  AO21x1_ASAP7_75t_R  g327(.A1(new_n331_), .A2(new_n385_), .B(new_n377_), .Y(new_n386_));
  AO21x1_ASAP7_75t_R  g328(.A1(new_n378_), .A2(new_n386_), .B(new_n383_), .Y(G1906));
  NOR2x1_ASAP7_75t_R  g329(.A(G9), .B(new_n71_), .Y(new_n388_));
  NOR2x1_ASAP7_75t_R  g330(.A(new_n70_), .B(G14), .Y(new_n389_));
  OR3x1_ASAP7_75t_R   g331(.A(new_n94_), .B(new_n106_), .C(new_n92_), .Y(new_n390_));
  INVx1_ASAP7_75t_R   g332(.A(new_n390_), .Y(new_n391_));
  AO21x1_ASAP7_75t_R  g333(.A1(new_n96_), .A2(new_n120_), .B(new_n391_), .Y(new_n392_));
  OR3x1_ASAP7_75t_R   g334(.A(new_n389_), .B(new_n392_), .C(new_n388_), .Y(new_n393_));
  INVx1_ASAP7_75t_R   g335(.A(new_n393_), .Y(new_n394_));
  OA21x2_ASAP7_75t_R  g336(.A1(new_n388_), .A2(new_n389_), .B(new_n223_), .Y(new_n395_));
  AOI21x1_ASAP7_75t_R g337(.A1(G30), .A2(new_n329_), .B(G33), .Y(new_n396_));
  OR3x1_ASAP7_75t_R   g338(.A(new_n395_), .B(new_n396_), .C(new_n394_), .Y(new_n397_));
  AO21x1_ASAP7_75t_R  g339(.A1(G30), .A2(G22), .B(G33), .Y(new_n398_));
  INVx1_ASAP7_75t_R   g340(.A(new_n398_), .Y(new_n399_));
  OAI21x1_ASAP7_75t_R g341(.A1(G33), .A2(G30), .B(new_n393_), .Y(new_n400_));
  NOR2x1_ASAP7_75t_R  g342(.A(new_n395_), .B(new_n400_), .Y(new_n401_));
  OR3x1_ASAP7_75t_R   g343(.A(G33), .B(new_n329_), .C(new_n401_), .Y(new_n402_));
  AND3x1_ASAP7_75t_R  g344(.A(new_n397_), .B(new_n399_), .C(new_n402_), .Y(new_n403_));
  NAND2x1_ASAP7_75t_R g345(.A(new_n397_), .B(new_n402_), .Y(new_n404_));
  AO21x1_ASAP7_75t_R  g346(.A1(new_n398_), .A2(new_n404_), .B(new_n403_), .Y(G1907));
  NOR2x1_ASAP7_75t_R  g347(.A(G31), .B(new_n82_), .Y(new_n406_));
  AO21x1_ASAP7_75t_R  g348(.A1(new_n332_), .A2(new_n406_), .B(new_n226_), .Y(new_n407_));
  INVx1_ASAP7_75t_R   g349(.A(new_n407_), .Y(new_n408_));
  OR3x1_ASAP7_75t_R   g350(.A(new_n225_), .B(new_n333_), .C(new_n221_), .Y(new_n409_));
  OR3x1_ASAP7_75t_R   g351(.A(G31), .B(new_n409_), .C(new_n82_), .Y(new_n410_));
  AO21x1_ASAP7_75t_R  g352(.A1(new_n407_), .A2(new_n410_), .B(new_n229_), .Y(new_n411_));
  AND3x1_ASAP7_75t_R  g353(.A(new_n226_), .B(new_n406_), .C(new_n332_), .Y(new_n412_));
  NOR2x1_ASAP7_75t_R  g354(.A(new_n214_), .B(new_n216_), .Y(new_n413_));
  OR3x1_ASAP7_75t_R   g355(.A(new_n412_), .B(new_n413_), .C(new_n408_), .Y(new_n414_));
  AOI21x1_ASAP7_75t_R g356(.A1(new_n411_), .A2(new_n414_), .B(new_n319_), .Y(G1908));
endmodule


