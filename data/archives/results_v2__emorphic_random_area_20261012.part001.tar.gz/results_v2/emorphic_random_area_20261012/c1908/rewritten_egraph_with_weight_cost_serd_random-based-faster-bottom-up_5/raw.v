// Benchmark "/home/flynn/workplace/MIGBalance/results_v2/emorphic_random_area_20261012/c1908/rewritten_egraph_with_weight_cost_serd_random-based-faster-bottom-up_5/logic" written by ABC on Mon Oct 12 14:24:49 2026

module \/home/flynn/workplace/MIGBalance/results_v2/emorphic_random_area_20261012/c1908/rewritten_egraph_with_weight_cost_serd_random-based-faster-bottom-up_5/logic  ( 
    G24, G33, G31, G30, G32, G8, G6, G3, G15, G10, G12, G19, G28, G9, G14,
    G16, G18, G11, G5, G2, G27, G7, G4, G20, G13, G1, G17, G26, G22, G25,
    G21, G29, G23,
    G1899, G1884, G1885, G1898, G1886, G1887, G1888, G1889, G1890, G1891,
    G1892, G1893, G1894, G1895, G1896, G1897, G1900, G1901, G1902, G1903,
    G1904, G1905, G1906, G1907, G1908  );
  input  G24, G33, G31, G30, G32, G8, G6, G3, G15, G10, G12, G19, G28,
    G9, G14, G16, G18, G11, G5, G2, G27, G7, G4, G20, G13, G1, G17, G26,
    G22, G25, G21, G29, G23;
  output G1899, G1884, G1885, G1898, G1886, G1887, G1888, G1889, G1890, G1891,
    G1892, G1893, G1894, G1895, G1896, G1897, G1900, G1901, G1902, G1903,
    G1904, G1905, G1906, G1907, G1908;
  wire new_n59_, new_n60_, new_n61_, new_n62_, new_n63_, new_n64_, new_n65_,
    new_n66_, new_n67_, new_n68_, new_n69_, new_n70_, new_n71_, new_n72_,
    new_n73_, new_n74_, new_n75_, new_n76_, new_n77_, new_n78_, new_n79_,
    new_n80_, new_n81_, new_n82_, new_n83_, new_n84_, new_n85_, new_n86_,
    new_n87_, new_n88_, new_n89_, new_n90_, new_n91_, new_n92_, new_n93_,
    new_n94_, new_n95_, new_n96_, new_n97_, new_n98_, new_n99_, new_n100_,
    new_n101_, new_n102_, new_n103_, new_n104_, new_n105_, new_n106_,
    new_n107_, new_n108_, new_n109_, new_n110_, new_n111_, new_n112_,
    new_n113_, new_n114_, new_n115_, new_n116_, new_n117_, new_n118_,
    new_n119_, new_n120_, new_n121_, new_n122_, new_n123_, new_n124_,
    new_n125_, new_n126_, new_n127_, new_n128_, new_n129_, new_n130_,
    new_n131_, new_n132_, new_n133_, new_n134_, new_n135_, new_n136_,
    new_n137_, new_n138_, new_n139_, new_n140_, new_n141_, new_n142_,
    new_n143_, new_n144_, new_n145_, new_n146_, new_n147_, new_n148_,
    new_n149_, new_n150_, new_n151_, new_n152_, new_n153_, new_n154_,
    new_n155_, new_n156_, new_n157_, new_n158_, new_n159_, new_n160_,
    new_n161_, new_n162_, new_n163_, new_n164_, new_n165_, new_n166_,
    new_n167_, new_n168_, new_n169_, new_n170_, new_n171_, new_n172_,
    new_n173_, new_n174_, new_n175_, new_n176_, new_n177_, new_n178_,
    new_n179_, new_n180_, new_n181_, new_n182_, new_n183_, new_n184_,
    new_n185_, new_n186_, new_n187_, new_n188_, new_n189_, new_n190_,
    new_n191_, new_n192_, new_n193_, new_n194_, new_n195_, new_n196_,
    new_n197_, new_n198_, new_n199_, new_n200_, new_n201_, new_n202_,
    new_n203_, new_n204_, new_n205_, new_n206_, new_n207_, new_n208_,
    new_n209_, new_n210_, new_n211_, new_n212_, new_n213_, new_n214_,
    new_n215_, new_n216_, new_n217_, new_n218_, new_n219_, new_n220_,
    new_n221_, new_n222_, new_n223_, new_n224_, new_n225_, new_n226_,
    new_n227_, new_n228_, new_n229_, new_n230_, new_n231_, new_n232_,
    new_n233_, new_n234_, new_n235_, new_n236_, new_n237_, new_n238_,
    new_n239_, new_n240_, new_n241_, new_n242_, new_n243_, new_n244_,
    new_n245_, new_n246_, new_n247_, new_n248_, new_n249_, new_n250_,
    new_n251_, new_n252_, new_n253_, new_n254_, new_n255_, new_n256_,
    new_n257_, new_n258_, new_n259_, new_n260_, new_n261_, new_n262_,
    new_n263_, new_n264_, new_n265_, new_n266_, new_n267_, new_n268_,
    new_n269_, new_n270_, new_n271_, new_n272_, new_n273_, new_n274_,
    new_n275_, new_n276_, new_n277_, new_n278_, new_n279_, new_n280_,
    new_n281_, new_n282_, new_n283_, new_n284_, new_n285_, new_n287_,
    new_n288_, new_n289_, new_n290_, new_n291_, new_n292_, new_n298_,
    new_n302_, new_n303_, new_n304_, new_n305_, new_n310_, new_n311_,
    new_n312_, new_n316_, new_n317_, new_n318_, new_n319_, new_n320_,
    new_n321_, new_n322_, new_n323_, new_n324_, new_n325_, new_n326_,
    new_n327_, new_n328_, new_n329_, new_n330_, new_n331_, new_n332_,
    new_n333_, new_n334_, new_n335_, new_n336_, new_n337_, new_n338_,
    new_n339_, new_n340_, new_n341_, new_n342_, new_n343_, new_n345_,
    new_n346_, new_n347_, new_n348_, new_n349_, new_n350_, new_n351_,
    new_n352_, new_n353_, new_n354_, new_n355_, new_n357_, new_n358_,
    new_n359_, new_n360_, new_n361_, new_n363_, new_n364_, new_n365_,
    new_n366_, new_n367_, new_n369_, new_n370_, new_n371_, new_n372_,
    new_n373_, new_n375_, new_n376_, new_n377_, new_n378_, new_n380_,
    new_n381_, new_n382_, new_n383_, new_n384_, new_n385_, new_n386_,
    new_n387_, new_n389_, new_n390_, new_n391_, new_n392_, new_n393_,
    new_n394_, new_n395_, new_n396_, new_n397_, new_n398_, new_n399_,
    new_n400_, new_n401_, new_n402_, new_n403_, new_n404_, new_n405_,
    new_n406_, new_n408_, new_n409_, new_n410_, new_n411_, new_n412_,
    new_n413_, new_n414_;
  INVx1_ASAP7_75t_R   g000(.A(G24), .Y(new_n59_));
  INVx1_ASAP7_75t_R   g001(.A(G33), .Y(new_n60_));
  INVx1_ASAP7_75t_R   g002(.A(G31), .Y(new_n61_));
  INVx1_ASAP7_75t_R   g003(.A(G8), .Y(new_n62_));
  INVx1_ASAP7_75t_R   g004(.A(G6), .Y(new_n63_));
  INVx1_ASAP7_75t_R   g005(.A(G3), .Y(new_n64_));
  INVx1_ASAP7_75t_R   g006(.A(G15), .Y(new_n65_));
  INVx1_ASAP7_75t_R   g007(.A(G10), .Y(new_n66_));
  INVx1_ASAP7_75t_R   g008(.A(G12), .Y(new_n67_));
  INVx1_ASAP7_75t_R   g009(.A(G19), .Y(new_n68_));
  INVx1_ASAP7_75t_R   g010(.A(G28), .Y(new_n69_));
  INVx1_ASAP7_75t_R   g011(.A(G9), .Y(new_n70_));
  INVx1_ASAP7_75t_R   g012(.A(G14), .Y(new_n71_));
  INVx1_ASAP7_75t_R   g013(.A(G16), .Y(new_n72_));
  INVx1_ASAP7_75t_R   g014(.A(G18), .Y(new_n73_));
  INVx1_ASAP7_75t_R   g015(.A(G11), .Y(new_n74_));
  INVx1_ASAP7_75t_R   g016(.A(G5), .Y(new_n75_));
  INVx1_ASAP7_75t_R   g017(.A(G2), .Y(new_n76_));
  INVx1_ASAP7_75t_R   g018(.A(G27), .Y(new_n77_));
  INVx1_ASAP7_75t_R   g019(.A(G7), .Y(new_n78_));
  INVx1_ASAP7_75t_R   g020(.A(G4), .Y(new_n79_));
  INVx1_ASAP7_75t_R   g021(.A(G20), .Y(new_n80_));
  INVx1_ASAP7_75t_R   g022(.A(G13), .Y(new_n81_));
  INVx1_ASAP7_75t_R   g023(.A(G1), .Y(new_n82_));
  INVx1_ASAP7_75t_R   g024(.A(G17), .Y(new_n83_));
  INVx1_ASAP7_75t_R   g025(.A(G26), .Y(new_n84_));
  INVx1_ASAP7_75t_R   g026(.A(G25), .Y(new_n85_));
  INVx1_ASAP7_75t_R   g027(.A(G21), .Y(new_n86_));
  INVx1_ASAP7_75t_R   g028(.A(G23), .Y(new_n87_));
  NOR2x1_ASAP7_75t_R  g029(.A(new_n67_), .B(new_n81_), .Y(new_n88_));
  NOR2x1_ASAP7_75t_R  g030(.A(G12), .B(G13), .Y(new_n89_));
  OA21x2_ASAP7_75t_R  g031(.A1(new_n88_), .A2(new_n89_), .B(G11), .Y(new_n90_));
  OR3x1_ASAP7_75t_R   g032(.A(G11), .B(new_n88_), .C(new_n89_), .Y(new_n91_));
  INVx1_ASAP7_75t_R   g033(.A(new_n91_), .Y(new_n92_));
  NOR2x1_ASAP7_75t_R  g034(.A(new_n90_), .B(new_n92_), .Y(new_n93_));
  INVx1_ASAP7_75t_R   g035(.A(new_n93_), .Y(new_n94_));
  NOR2x1_ASAP7_75t_R  g036(.A(new_n64_), .B(new_n76_), .Y(new_n95_));
  NOR2x1_ASAP7_75t_R  g037(.A(G3), .B(G2), .Y(new_n96_));
  OR3x1_ASAP7_75t_R   g038(.A(G1), .B(new_n95_), .C(new_n96_), .Y(new_n97_));
  INVx1_ASAP7_75t_R   g039(.A(new_n97_), .Y(new_n98_));
  OA21x2_ASAP7_75t_R  g040(.A1(new_n95_), .A2(new_n96_), .B(G1), .Y(new_n99_));
  XOR2x2_ASAP7_75t_R  g041(.A(new_n65_), .B(new_n72_), .Y(new_n100_));
  INVx1_ASAP7_75t_R   g042(.A(new_n100_), .Y(new_n101_));
  NOR2x1_ASAP7_75t_R  g043(.A(new_n66_), .B(new_n100_), .Y(new_n102_));
  AO21x1_ASAP7_75t_R  g044(.A1(G15), .A2(G16), .B(G10), .Y(new_n103_));
  AOI21x1_ASAP7_75t_R g045(.A1(new_n65_), .A2(new_n72_), .B(new_n103_), .Y(new_n104_));
  AO21x1_ASAP7_75t_R  g046(.A1(G10), .A2(new_n101_), .B(new_n104_), .Y(new_n105_));
  INVx1_ASAP7_75t_R   g047(.A(new_n105_), .Y(new_n106_));
  OR3x1_ASAP7_75t_R   g048(.A(new_n99_), .B(new_n106_), .C(new_n98_), .Y(new_n107_));
  INVx1_ASAP7_75t_R   g049(.A(new_n107_), .Y(new_n108_));
  NOR2x1_ASAP7_75t_R  g050(.A(G10), .B(new_n101_), .Y(new_n109_));
  NOR2x1_ASAP7_75t_R  g051(.A(new_n98_), .B(new_n99_), .Y(new_n110_));
  INVx1_ASAP7_75t_R   g052(.A(new_n110_), .Y(new_n111_));
  OR3x1_ASAP7_75t_R   g053(.A(new_n109_), .B(new_n110_), .C(new_n102_), .Y(new_n112_));
  INVx1_ASAP7_75t_R   g054(.A(new_n112_), .Y(new_n113_));
  OA21x2_ASAP7_75t_R  g055(.A1(new_n108_), .A2(new_n113_), .B(new_n94_), .Y(new_n114_));
  AO21x1_ASAP7_75t_R  g056(.A1(new_n66_), .A2(new_n100_), .B(new_n102_), .Y(new_n115_));
  INVx1_ASAP7_75t_R   g057(.A(new_n115_), .Y(new_n116_));
  NAND2x1_ASAP7_75t_R g058(.A(new_n110_), .B(new_n115_), .Y(new_n117_));
  NAND2x1_ASAP7_75t_R g059(.A(new_n106_), .B(new_n111_), .Y(new_n118_));
  AND3x1_ASAP7_75t_R  g060(.A(new_n93_), .B(new_n118_), .C(new_n117_), .Y(new_n119_));
  NOR2x1_ASAP7_75t_R  g061(.A(G14), .B(G4), .Y(new_n120_));
  NOR2x1_ASAP7_75t_R  g062(.A(new_n71_), .B(new_n79_), .Y(new_n121_));
  AO21x1_ASAP7_75t_R  g063(.A1(G14), .A2(G4), .B(new_n120_), .Y(new_n122_));
  INVx1_ASAP7_75t_R   g064(.A(new_n122_), .Y(new_n123_));
  AND3x1_ASAP7_75t_R  g065(.A(new_n60_), .B(new_n122_), .C(G22), .Y(new_n124_));
  NAND2x1_ASAP7_75t_R g066(.A(new_n60_), .B(G22), .Y(new_n125_));
  INVx1_ASAP7_75t_R   g067(.A(new_n125_), .Y(new_n126_));
  AO21x1_ASAP7_75t_R  g068(.A1(new_n123_), .A2(new_n125_), .B(new_n124_), .Y(new_n127_));
  OR3x1_ASAP7_75t_R   g069(.A(new_n119_), .B(new_n127_), .C(new_n114_), .Y(new_n128_));
  INVx1_ASAP7_75t_R   g070(.A(new_n128_), .Y(new_n129_));
  AO21x1_ASAP7_75t_R  g071(.A1(new_n117_), .A2(new_n118_), .B(new_n93_), .Y(new_n130_));
  OR3x1_ASAP7_75t_R   g072(.A(new_n94_), .B(new_n108_), .C(new_n113_), .Y(new_n131_));
  OR3x1_ASAP7_75t_R   g073(.A(new_n121_), .B(new_n126_), .C(new_n120_), .Y(new_n132_));
  OA21x2_ASAP7_75t_R  g074(.A1(new_n123_), .A2(new_n125_), .B(new_n132_), .Y(new_n133_));
  AOI21x1_ASAP7_75t_R g075(.A1(new_n130_), .A2(new_n131_), .B(new_n133_), .Y(new_n134_));
  NOR2x1_ASAP7_75t_R  g076(.A(new_n129_), .B(new_n134_), .Y(new_n135_));
  OR3x1_ASAP7_75t_R   g077(.A(G31), .B(G25), .C(new_n135_), .Y(new_n136_));
  INVx1_ASAP7_75t_R   g078(.A(new_n136_), .Y(new_n137_));
  OA21x2_ASAP7_75t_R  g079(.A1(G31), .A2(new_n135_), .B(G25), .Y(new_n138_));
  NOR2x1_ASAP7_75t_R  g080(.A(new_n137_), .B(new_n138_), .Y(new_n139_));
  INVx1_ASAP7_75t_R   g081(.A(new_n139_), .Y(new_n140_));
  NOR2x1_ASAP7_75t_R  g082(.A(G31), .B(G23), .Y(new_n141_));
  OR3x1_ASAP7_75t_R   g083(.A(new_n80_), .B(new_n139_), .C(new_n141_), .Y(new_n142_));
  INVx1_ASAP7_75t_R   g084(.A(new_n142_), .Y(new_n143_));
  NOR2x1_ASAP7_75t_R  g085(.A(G24), .B(G31), .Y(new_n144_));
  AO21x1_ASAP7_75t_R  g086(.A1(new_n59_), .A2(new_n61_), .B(new_n73_), .Y(new_n145_));
  INVx1_ASAP7_75t_R   g087(.A(new_n145_), .Y(new_n146_));
  NAND2x1_ASAP7_75t_R g088(.A(new_n70_), .B(new_n115_), .Y(new_n147_));
  OA21x2_ASAP7_75t_R  g089(.A1(new_n70_), .A2(new_n105_), .B(new_n147_), .Y(new_n148_));
  OR3x1_ASAP7_75t_R   g090(.A(G33), .B(new_n148_), .C(new_n86_), .Y(new_n149_));
  INVx1_ASAP7_75t_R   g091(.A(new_n149_), .Y(new_n150_));
  NOR2x1_ASAP7_75t_R  g092(.A(G33), .B(new_n86_), .Y(new_n151_));
  AOI21x1_ASAP7_75t_R g093(.A1(G9), .A2(new_n106_), .B(new_n151_), .Y(new_n152_));
  AO21x1_ASAP7_75t_R  g094(.A1(new_n147_), .A2(new_n152_), .B(new_n150_), .Y(new_n153_));
  INVx1_ASAP7_75t_R   g095(.A(new_n153_), .Y(new_n154_));
  XNOR2x2_ASAP7_75t_R g096(.A(new_n63_), .B(new_n78_), .Y(new_n155_));
  AO21x1_ASAP7_75t_R  g097(.A1(G6), .A2(G7), .B(G5), .Y(new_n156_));
  AOI21x1_ASAP7_75t_R g098(.A1(new_n63_), .A2(new_n78_), .B(new_n156_), .Y(new_n157_));
  AO21x1_ASAP7_75t_R  g099(.A1(G5), .A2(new_n155_), .B(new_n157_), .Y(new_n158_));
  INVx1_ASAP7_75t_R   g100(.A(new_n158_), .Y(new_n159_));
  NOR2x1_ASAP7_75t_R  g101(.A(G8), .B(new_n79_), .Y(new_n160_));
  NOR2x1_ASAP7_75t_R  g102(.A(new_n62_), .B(G4), .Y(new_n161_));
  NOR2x1_ASAP7_75t_R  g103(.A(new_n160_), .B(new_n161_), .Y(new_n162_));
  AO21x1_ASAP7_75t_R  g104(.A1(new_n110_), .A2(new_n159_), .B(new_n162_), .Y(new_n163_));
  AOI21x1_ASAP7_75t_R g105(.A1(new_n111_), .A2(new_n158_), .B(new_n163_), .Y(new_n164_));
  XOR2x2_ASAP7_75t_R  g106(.A(new_n110_), .B(new_n159_), .Y(new_n165_));
  OR3x1_ASAP7_75t_R   g107(.A(new_n160_), .B(new_n161_), .C(new_n165_), .Y(new_n166_));
  INVx1_ASAP7_75t_R   g108(.A(new_n166_), .Y(new_n167_));
  OR3x1_ASAP7_75t_R   g109(.A(new_n154_), .B(new_n164_), .C(new_n167_), .Y(new_n168_));
  INVx1_ASAP7_75t_R   g110(.A(new_n168_), .Y(new_n169_));
  OR3x1_ASAP7_75t_R   g111(.A(new_n160_), .B(new_n165_), .C(new_n161_), .Y(new_n170_));
  INVx1_ASAP7_75t_R   g112(.A(new_n170_), .Y(new_n171_));
  NOR2x1_ASAP7_75t_R  g113(.A(new_n164_), .B(new_n171_), .Y(new_n172_));
  INVx1_ASAP7_75t_R   g114(.A(new_n172_), .Y(new_n173_));
  AO21x1_ASAP7_75t_R  g115(.A1(new_n70_), .A2(new_n105_), .B(new_n151_), .Y(new_n174_));
  AO21x1_ASAP7_75t_R  g116(.A1(G9), .A2(new_n116_), .B(new_n174_), .Y(new_n175_));
  AND3x1_ASAP7_75t_R  g117(.A(new_n149_), .B(new_n173_), .C(new_n175_), .Y(new_n176_));
  OAI21x1_ASAP7_75t_R g118(.A1(new_n169_), .A2(new_n176_), .B(G24), .Y(new_n177_));
  AOI21x1_ASAP7_75t_R g119(.A1(new_n61_), .A2(new_n177_), .B(new_n83_), .Y(new_n178_));
  NOR2x1_ASAP7_75t_R  g120(.A(new_n83_), .B(new_n144_), .Y(new_n179_));
  OR3x1_ASAP7_75t_R   g121(.A(new_n169_), .B(new_n179_), .C(new_n176_), .Y(new_n180_));
  NOR2x1_ASAP7_75t_R  g122(.A(G31), .B(new_n180_), .Y(new_n181_));
  NOR2x1_ASAP7_75t_R  g123(.A(new_n178_), .B(new_n181_), .Y(new_n182_));
  INVx1_ASAP7_75t_R   g124(.A(new_n182_), .Y(new_n183_));
  OR3x1_ASAP7_75t_R   g125(.A(new_n143_), .B(new_n145_), .C(new_n183_), .Y(new_n184_));
  OR3x1_ASAP7_75t_R   g126(.A(new_n80_), .B(G23), .C(G33), .Y(new_n185_));
  OR2x4_ASAP7_75t_R   g127(.A(G13), .B(new_n185_), .Y(new_n186_));
  NOR2x1_ASAP7_75t_R  g128(.A(G10), .B(new_n78_), .Y(new_n187_));
  NOR2x1_ASAP7_75t_R  g129(.A(new_n66_), .B(G7), .Y(new_n188_));
  OAI21x1_ASAP7_75t_R g130(.A1(new_n187_), .A2(new_n188_), .B(new_n79_), .Y(new_n189_));
  XNOR2x2_ASAP7_75t_R g131(.A(new_n70_), .B(new_n71_), .Y(new_n190_));
  AO21x1_ASAP7_75t_R  g132(.A1(G9), .A2(G14), .B(G16), .Y(new_n191_));
  AOI21x1_ASAP7_75t_R g133(.A1(new_n70_), .A2(new_n71_), .B(new_n191_), .Y(new_n192_));
  AO21x1_ASAP7_75t_R  g134(.A1(G16), .A2(new_n190_), .B(new_n192_), .Y(new_n193_));
  INVx1_ASAP7_75t_R   g135(.A(new_n193_), .Y(new_n194_));
  OR3x1_ASAP7_75t_R   g136(.A(new_n79_), .B(new_n187_), .C(new_n188_), .Y(new_n195_));
  AND3x1_ASAP7_75t_R  g137(.A(new_n189_), .B(new_n193_), .C(new_n195_), .Y(new_n196_));
  NAND2x1_ASAP7_75t_R g138(.A(new_n189_), .B(new_n195_), .Y(new_n197_));
  AOI21x1_ASAP7_75t_R g139(.A1(new_n194_), .A2(new_n197_), .B(new_n196_), .Y(new_n198_));
  NAND2x1_ASAP7_75t_R g140(.A(G13), .B(new_n185_), .Y(new_n199_));
  AND3x1_ASAP7_75t_R  g141(.A(new_n186_), .B(new_n198_), .C(new_n199_), .Y(new_n200_));
  AOI21x1_ASAP7_75t_R g142(.A1(new_n186_), .A2(new_n199_), .B(new_n198_), .Y(new_n201_));
  NOR2x1_ASAP7_75t_R  g143(.A(new_n200_), .B(new_n201_), .Y(new_n202_));
  INVx1_ASAP7_75t_R   g144(.A(new_n202_), .Y(new_n203_));
  NOR2x1_ASAP7_75t_R  g145(.A(new_n87_), .B(new_n203_), .Y(new_n204_));
  OA21x2_ASAP7_75t_R  g146(.A1(G31), .A2(new_n204_), .B(G19), .Y(new_n205_));
  AO21x1_ASAP7_75t_R  g147(.A1(new_n61_), .A2(new_n87_), .B(new_n68_), .Y(new_n206_));
  AND3x1_ASAP7_75t_R  g148(.A(new_n61_), .B(new_n206_), .C(new_n203_), .Y(new_n207_));
  NOR2x1_ASAP7_75t_R  g149(.A(G24), .B(G33), .Y(new_n208_));
  AOI21x1_ASAP7_75t_R g150(.A1(G17), .A2(new_n208_), .B(G1), .Y(new_n209_));
  NOR2x1_ASAP7_75t_R  g151(.A(G24), .B(new_n83_), .Y(new_n210_));
  AND3x1_ASAP7_75t_R  g152(.A(new_n60_), .B(G1), .C(new_n210_), .Y(new_n211_));
  NOR2x1_ASAP7_75t_R  g153(.A(new_n94_), .B(new_n116_), .Y(new_n212_));
  OR3x1_ASAP7_75t_R   g154(.A(new_n93_), .B(new_n102_), .C(new_n104_), .Y(new_n213_));
  INVx1_ASAP7_75t_R   g155(.A(new_n213_), .Y(new_n214_));
  NOR2x1_ASAP7_75t_R  g156(.A(new_n212_), .B(new_n214_), .Y(new_n215_));
  OR2x4_ASAP7_75t_R   g157(.A(new_n158_), .B(new_n215_), .Y(new_n216_));
  OA21x2_ASAP7_75t_R  g158(.A1(new_n209_), .A2(new_n211_), .B(new_n216_), .Y(new_n217_));
  OR3x1_ASAP7_75t_R   g159(.A(new_n159_), .B(new_n212_), .C(new_n214_), .Y(new_n218_));
  NOR2x1_ASAP7_75t_R  g160(.A(new_n82_), .B(new_n83_), .Y(new_n219_));
  AO21x1_ASAP7_75t_R  g161(.A1(new_n208_), .A2(new_n219_), .B(new_n209_), .Y(new_n220_));
  AND2x2_ASAP7_75t_R  g162(.A(new_n216_), .B(new_n218_), .Y(new_n221_));
  NOR2x1_ASAP7_75t_R  g163(.A(new_n220_), .B(new_n221_), .Y(new_n222_));
  AO21x1_ASAP7_75t_R  g164(.A1(new_n217_), .A2(new_n218_), .B(new_n222_), .Y(new_n223_));
  AND3x1_ASAP7_75t_R  g165(.A(new_n61_), .B(new_n84_), .C(new_n223_), .Y(new_n224_));
  AOI21x1_ASAP7_75t_R g166(.A1(new_n61_), .A2(new_n223_), .B(new_n84_), .Y(new_n225_));
  OR2x4_ASAP7_75t_R   g167(.A(new_n224_), .B(new_n225_), .Y(new_n226_));
  OR3x1_ASAP7_75t_R   g168(.A(new_n207_), .B(new_n226_), .C(new_n205_), .Y(new_n227_));
  OR3x1_ASAP7_75t_R   g169(.A(G33), .B(new_n73_), .C(G24), .Y(new_n228_));
  NOR2x1_ASAP7_75t_R  g170(.A(G15), .B(new_n228_), .Y(new_n229_));
  AO21x1_ASAP7_75t_R  g171(.A1(G15), .A2(new_n228_), .B(new_n74_), .Y(new_n230_));
  OR2x4_ASAP7_75t_R   g172(.A(new_n229_), .B(new_n230_), .Y(new_n231_));
  OR3x1_ASAP7_75t_R   g173(.A(G24), .B(G33), .C(new_n73_), .Y(new_n232_));
  AO21x1_ASAP7_75t_R  g174(.A1(G15), .A2(new_n232_), .B(new_n229_), .Y(new_n233_));
  NAND2x1_ASAP7_75t_R g175(.A(new_n74_), .B(new_n233_), .Y(new_n234_));
  INVx1_ASAP7_75t_R   g176(.A(new_n234_), .Y(new_n235_));
  AND3x1_ASAP7_75t_R  g177(.A(new_n193_), .B(new_n231_), .C(new_n234_), .Y(new_n236_));
  AO21x1_ASAP7_75t_R  g178(.A1(new_n231_), .A2(new_n234_), .B(new_n193_), .Y(new_n237_));
  INVx1_ASAP7_75t_R   g179(.A(new_n237_), .Y(new_n238_));
  XNOR2x2_ASAP7_75t_R g180(.A(G8), .B(new_n75_), .Y(new_n239_));
  AO21x1_ASAP7_75t_R  g181(.A1(new_n62_), .A2(G5), .B(new_n76_), .Y(new_n240_));
  AOI21x1_ASAP7_75t_R g182(.A1(G8), .A2(new_n75_), .B(new_n240_), .Y(new_n241_));
  AO21x1_ASAP7_75t_R  g183(.A1(new_n76_), .A2(new_n239_), .B(new_n241_), .Y(new_n242_));
  INVx1_ASAP7_75t_R   g184(.A(new_n242_), .Y(new_n243_));
  OR3x1_ASAP7_75t_R   g185(.A(new_n236_), .B(new_n238_), .C(new_n243_), .Y(new_n244_));
  NOR2x1_ASAP7_75t_R  g186(.A(new_n74_), .B(new_n233_), .Y(new_n245_));
  OR3x1_ASAP7_75t_R   g187(.A(new_n194_), .B(new_n235_), .C(new_n245_), .Y(new_n246_));
  INVx1_ASAP7_75t_R   g188(.A(new_n246_), .Y(new_n247_));
  AO21x1_ASAP7_75t_R  g189(.A1(new_n237_), .A2(new_n246_), .B(new_n242_), .Y(new_n248_));
  NAND2x1_ASAP7_75t_R g190(.A(new_n244_), .B(new_n248_), .Y(new_n249_));
  AOI21x1_ASAP7_75t_R g191(.A1(new_n61_), .A2(new_n249_), .B(new_n77_), .Y(new_n250_));
  AND3x1_ASAP7_75t_R  g192(.A(new_n77_), .B(new_n249_), .C(new_n61_), .Y(new_n251_));
  NOR2x1_ASAP7_75t_R  g193(.A(G8), .B(new_n63_), .Y(new_n252_));
  NOR2x1_ASAP7_75t_R  g194(.A(new_n62_), .B(G6), .Y(new_n253_));
  OA21x2_ASAP7_75t_R  g195(.A1(new_n252_), .A2(new_n253_), .B(new_n64_), .Y(new_n254_));
  OR3x1_ASAP7_75t_R   g196(.A(new_n64_), .B(new_n252_), .C(new_n253_), .Y(new_n255_));
  INVx1_ASAP7_75t_R   g197(.A(new_n255_), .Y(new_n256_));
  NOR2x1_ASAP7_75t_R  g198(.A(G15), .B(new_n66_), .Y(new_n257_));
  NOR2x1_ASAP7_75t_R  g199(.A(new_n65_), .B(G10), .Y(new_n258_));
  OA21x2_ASAP7_75t_R  g200(.A1(new_n257_), .A2(new_n258_), .B(new_n67_), .Y(new_n259_));
  OR3x1_ASAP7_75t_R   g201(.A(new_n67_), .B(new_n258_), .C(new_n257_), .Y(new_n260_));
  INVx1_ASAP7_75t_R   g202(.A(new_n260_), .Y(new_n261_));
  NOR2x1_ASAP7_75t_R  g203(.A(new_n259_), .B(new_n261_), .Y(new_n262_));
  OR3x1_ASAP7_75t_R   g204(.A(new_n256_), .B(new_n262_), .C(new_n254_), .Y(new_n263_));
  INVx1_ASAP7_75t_R   g205(.A(new_n263_), .Y(new_n264_));
  NOR2x1_ASAP7_75t_R  g206(.A(new_n254_), .B(new_n256_), .Y(new_n265_));
  OR3x1_ASAP7_75t_R   g207(.A(new_n261_), .B(new_n265_), .C(new_n259_), .Y(new_n266_));
  INVx1_ASAP7_75t_R   g208(.A(new_n266_), .Y(new_n267_));
  OR3x1_ASAP7_75t_R   g209(.A(G33), .B(G23), .C(new_n68_), .Y(new_n268_));
  OA21x2_ASAP7_75t_R  g210(.A1(new_n264_), .A2(new_n267_), .B(new_n268_), .Y(new_n269_));
  NOR2x1_ASAP7_75t_R  g211(.A(new_n254_), .B(new_n262_), .Y(new_n270_));
  AO21x1_ASAP7_75t_R  g212(.A1(new_n255_), .A2(new_n270_), .B(new_n267_), .Y(new_n271_));
  NOR2x1_ASAP7_75t_R  g213(.A(new_n68_), .B(new_n271_), .Y(new_n272_));
  AND3x1_ASAP7_75t_R  g214(.A(new_n60_), .B(new_n87_), .C(new_n272_), .Y(new_n273_));
  NOR2x1_ASAP7_75t_R  g215(.A(new_n269_), .B(new_n273_), .Y(new_n274_));
  INVx1_ASAP7_75t_R   g216(.A(new_n274_), .Y(new_n275_));
  OA21x2_ASAP7_75t_R  g217(.A1(G31), .A2(new_n274_), .B(G28), .Y(new_n276_));
  NOR2x1_ASAP7_75t_R  g218(.A(G31), .B(G28), .Y(new_n277_));
  AO21x1_ASAP7_75t_R  g219(.A1(new_n275_), .A2(new_n277_), .B(new_n276_), .Y(new_n278_));
  OR3x1_ASAP7_75t_R   g220(.A(new_n251_), .B(new_n278_), .C(new_n250_), .Y(new_n279_));
  OA21x2_ASAP7_75t_R  g221(.A1(G31), .A2(G30), .B(G32), .Y(new_n280_));
  NOR2x1_ASAP7_75t_R  g222(.A(new_n59_), .B(G23), .Y(new_n281_));
  AO21x1_ASAP7_75t_R  g223(.A1(G24), .A2(new_n87_), .B(G33), .Y(new_n282_));
  OR3x1_ASAP7_75t_R   g224(.A(G33), .B(new_n281_), .C(new_n280_), .Y(new_n283_));
  OR3x1_ASAP7_75t_R   g225(.A(new_n280_), .B(new_n282_), .C(new_n279_), .Y(new_n284_));
  OR3x1_ASAP7_75t_R   g226(.A(new_n227_), .B(new_n284_), .C(new_n184_), .Y(new_n285_));
  XNOR2x2_ASAP7_75t_R g227(.A(new_n71_), .B(new_n285_), .Y(G1899));
  OA21x2_ASAP7_75t_R  g228(.A1(G31), .A2(G29), .B(G32), .Y(new_n287_));
  OR3x1_ASAP7_75t_R   g229(.A(new_n282_), .B(new_n287_), .C(new_n279_), .Y(new_n288_));
  OR3x1_ASAP7_75t_R   g230(.A(new_n144_), .B(new_n182_), .C(new_n73_), .Y(new_n289_));
  INVx1_ASAP7_75t_R   g231(.A(new_n289_), .Y(new_n290_));
  OR3x1_ASAP7_75t_R   g232(.A(new_n143_), .B(new_n290_), .C(new_n227_), .Y(new_n291_));
  OR2x4_ASAP7_75t_R   g233(.A(new_n288_), .B(new_n291_), .Y(new_n292_));
  XNOR2x2_ASAP7_75t_R g234(.A(new_n82_), .B(new_n292_), .Y(G1884));
  XNOR2x2_ASAP7_75t_R g235(.A(new_n76_), .B(new_n292_), .Y(G1885));
  XNOR2x2_ASAP7_75t_R g236(.A(new_n81_), .B(new_n285_), .Y(G1898));
  XNOR2x2_ASAP7_75t_R g237(.A(new_n64_), .B(new_n292_), .Y(G1886));
  XNOR2x2_ASAP7_75t_R g238(.A(new_n79_), .B(new_n292_), .Y(G1887));
  OR3x1_ASAP7_75t_R   g239(.A(new_n283_), .B(new_n291_), .C(new_n279_), .Y(new_n298_));
  XNOR2x2_ASAP7_75t_R g240(.A(new_n66_), .B(new_n298_), .Y(G1888));
  XNOR2x2_ASAP7_75t_R g241(.A(new_n65_), .B(new_n298_), .Y(G1889));
  XNOR2x2_ASAP7_75t_R g242(.A(new_n72_), .B(new_n298_), .Y(G1890));
  OR3x1_ASAP7_75t_R   g243(.A(new_n80_), .B(new_n137_), .C(new_n141_), .Y(new_n302_));
  NOR2x1_ASAP7_75t_R  g244(.A(new_n145_), .B(new_n182_), .Y(new_n303_));
  OR3x1_ASAP7_75t_R   g245(.A(new_n302_), .B(new_n303_), .C(new_n138_), .Y(new_n304_));
  OR3x1_ASAP7_75t_R   g246(.A(new_n227_), .B(new_n288_), .C(new_n304_), .Y(new_n305_));
  XNOR2x2_ASAP7_75t_R g247(.A(new_n75_), .B(new_n305_), .Y(G1891));
  XNOR2x2_ASAP7_75t_R g248(.A(new_n63_), .B(new_n305_), .Y(G1892));
  XNOR2x2_ASAP7_75t_R g249(.A(new_n78_), .B(new_n305_), .Y(G1893));
  XNOR2x2_ASAP7_75t_R g250(.A(new_n62_), .B(new_n305_), .Y(G1894));
  OR2x4_ASAP7_75t_R   g251(.A(new_n250_), .B(new_n251_), .Y(new_n310_));
  OR3x1_ASAP7_75t_R   g252(.A(new_n227_), .B(new_n304_), .C(new_n310_), .Y(new_n311_));
  OR3x1_ASAP7_75t_R   g253(.A(new_n278_), .B(new_n283_), .C(new_n311_), .Y(new_n312_));
  XNOR2x2_ASAP7_75t_R g254(.A(new_n70_), .B(new_n312_), .Y(G1895));
  XNOR2x2_ASAP7_75t_R g255(.A(new_n74_), .B(new_n285_), .Y(G1896));
  XNOR2x2_ASAP7_75t_R g256(.A(new_n67_), .B(new_n285_), .Y(G1897));
  OR3x1_ASAP7_75t_R   g257(.A(new_n140_), .B(new_n141_), .C(new_n80_), .Y(new_n316_));
  OR3x1_ASAP7_75t_R   g258(.A(new_n73_), .B(new_n183_), .C(new_n144_), .Y(new_n317_));
  OR2x4_ASAP7_75t_R   g259(.A(new_n316_), .B(new_n317_), .Y(new_n318_));
  AND3x1_ASAP7_75t_R  g260(.A(new_n184_), .B(new_n304_), .C(new_n318_), .Y(new_n319_));
  NOR2x1_ASAP7_75t_R  g261(.A(G33), .B(G32), .Y(new_n320_));
  INVx1_ASAP7_75t_R   g262(.A(new_n320_), .Y(new_n321_));
  OR3x1_ASAP7_75t_R   g263(.A(new_n281_), .B(new_n321_), .C(new_n279_), .Y(new_n322_));
  OR3x1_ASAP7_75t_R   g264(.A(new_n227_), .B(new_n319_), .C(new_n322_), .Y(new_n323_));
  NAND2x1_ASAP7_75t_R g265(.A(G32), .B(new_n323_), .Y(new_n324_));
  OR3x1_ASAP7_75t_R   g266(.A(new_n224_), .B(new_n225_), .C(new_n205_), .Y(new_n325_));
  OR3x1_ASAP7_75t_R   g267(.A(new_n207_), .B(new_n325_), .C(new_n303_), .Y(new_n326_));
  AO21x1_ASAP7_75t_R  g268(.A1(new_n143_), .A2(new_n316_), .B(new_n326_), .Y(new_n327_));
  OR3x1_ASAP7_75t_R   g269(.A(new_n73_), .B(new_n144_), .C(new_n181_), .Y(new_n328_));
  OR3x1_ASAP7_75t_R   g270(.A(new_n143_), .B(new_n325_), .C(new_n207_), .Y(new_n329_));
  OR3x1_ASAP7_75t_R   g271(.A(new_n328_), .B(new_n329_), .C(new_n178_), .Y(new_n330_));
  AO21x1_ASAP7_75t_R  g272(.A1(new_n327_), .A2(new_n330_), .B(new_n284_), .Y(new_n331_));
  INVx1_ASAP7_75t_R   g273(.A(new_n331_), .Y(new_n332_));
  NOR2x1_ASAP7_75t_R  g274(.A(new_n288_), .B(new_n327_), .Y(new_n333_));
  NOR2x1_ASAP7_75t_R  g275(.A(new_n332_), .B(new_n333_), .Y(new_n334_));
  INVx1_ASAP7_75t_R   g276(.A(new_n334_), .Y(new_n335_));
  OA21x2_ASAP7_75t_R  g277(.A1(new_n324_), .A2(new_n335_), .B(G32), .Y(new_n336_));
  NOR2x1_ASAP7_75t_R  g278(.A(new_n80_), .B(new_n141_), .Y(new_n337_));
  OR3x1_ASAP7_75t_R   g279(.A(new_n181_), .B(new_n337_), .C(new_n178_), .Y(new_n338_));
  OR3x1_ASAP7_75t_R   g280(.A(new_n140_), .B(new_n146_), .C(new_n338_), .Y(new_n339_));
  OR3x1_ASAP7_75t_R   g281(.A(new_n207_), .B(new_n278_), .C(new_n205_), .Y(new_n340_));
  OR3x1_ASAP7_75t_R   g282(.A(new_n225_), .B(new_n310_), .C(new_n224_), .Y(new_n341_));
  OR3x1_ASAP7_75t_R   g283(.A(new_n340_), .B(new_n341_), .C(new_n339_), .Y(new_n342_));
  INVx1_ASAP7_75t_R   g284(.A(new_n342_), .Y(new_n343_));
  OR3x1_ASAP7_75t_R   g285(.A(G33), .B(new_n343_), .C(new_n336_), .Y(G1900));
  NOR2x1_ASAP7_75t_R  g286(.A(G31), .B(new_n334_), .Y(new_n345_));
  INVx1_ASAP7_75t_R   g287(.A(new_n345_), .Y(new_n346_));
  OR3x1_ASAP7_75t_R   g288(.A(new_n153_), .B(new_n171_), .C(new_n164_), .Y(new_n347_));
  OA21x2_ASAP7_75t_R  g289(.A1(new_n154_), .A2(new_n172_), .B(new_n347_), .Y(new_n348_));
  AO21x1_ASAP7_75t_R  g290(.A1(new_n179_), .A2(new_n345_), .B(new_n348_), .Y(new_n349_));
  OR3x1_ASAP7_75t_R   g291(.A(G31), .B(new_n83_), .C(new_n334_), .Y(new_n350_));
  NOR2x1_ASAP7_75t_R  g292(.A(new_n164_), .B(new_n167_), .Y(new_n351_));
  AOI21x1_ASAP7_75t_R g293(.A1(new_n149_), .A2(new_n175_), .B(new_n351_), .Y(new_n352_));
  OR3x1_ASAP7_75t_R   g294(.A(new_n144_), .B(new_n350_), .C(new_n352_), .Y(new_n353_));
  INVx1_ASAP7_75t_R   g295(.A(new_n353_), .Y(new_n354_));
  NAND2x1_ASAP7_75t_R g296(.A(new_n347_), .B(new_n354_), .Y(new_n355_));
  AOI21x1_ASAP7_75t_R g297(.A1(new_n349_), .A2(new_n355_), .B(new_n320_), .Y(G1901));
  AND3x1_ASAP7_75t_R  g298(.A(new_n131_), .B(new_n133_), .C(new_n130_), .Y(new_n357_));
  NOR2x1_ASAP7_75t_R  g299(.A(new_n134_), .B(new_n357_), .Y(new_n358_));
  AO21x1_ASAP7_75t_R  g300(.A1(G25), .A2(new_n345_), .B(new_n358_), .Y(new_n359_));
  OR3x1_ASAP7_75t_R   g301(.A(new_n85_), .B(new_n334_), .C(G31), .Y(new_n360_));
  OR3x1_ASAP7_75t_R   g302(.A(new_n134_), .B(new_n360_), .C(new_n129_), .Y(new_n361_));
  AOI21x1_ASAP7_75t_R g303(.A1(new_n359_), .A2(new_n361_), .B(new_n320_), .Y(G1902));
  OA21x2_ASAP7_75t_R  g304(.A1(new_n77_), .A2(new_n346_), .B(new_n248_), .Y(new_n363_));
  NAND2x1_ASAP7_75t_R g305(.A(new_n244_), .B(new_n363_), .Y(new_n364_));
  OR3x1_ASAP7_75t_R   g306(.A(new_n238_), .B(new_n243_), .C(new_n247_), .Y(new_n365_));
  AO21x1_ASAP7_75t_R  g307(.A1(new_n248_), .A2(new_n365_), .B(new_n334_), .Y(new_n366_));
  OR3x1_ASAP7_75t_R   g308(.A(G31), .B(new_n77_), .C(new_n366_), .Y(new_n367_));
  AOI21x1_ASAP7_75t_R g309(.A1(new_n364_), .A2(new_n367_), .B(new_n320_), .Y(G1903));
  AO21x1_ASAP7_75t_R  g310(.A1(G28), .A2(new_n345_), .B(new_n275_), .Y(new_n369_));
  OR3x1_ASAP7_75t_R   g311(.A(new_n267_), .B(new_n268_), .C(new_n264_), .Y(new_n370_));
  INVx1_ASAP7_75t_R   g312(.A(new_n370_), .Y(new_n371_));
  AOI21x1_ASAP7_75t_R g313(.A1(new_n268_), .A2(new_n271_), .B(new_n371_), .Y(new_n372_));
  OR3x1_ASAP7_75t_R   g314(.A(new_n346_), .B(new_n372_), .C(new_n69_), .Y(new_n373_));
  AOI21x1_ASAP7_75t_R g315(.A1(new_n369_), .A2(new_n373_), .B(new_n320_), .Y(G1904));
  OR3x1_ASAP7_75t_R   g316(.A(G31), .B(new_n206_), .C(new_n334_), .Y(new_n375_));
  INVx1_ASAP7_75t_R   g317(.A(new_n375_), .Y(new_n376_));
  OR3x1_ASAP7_75t_R   g318(.A(new_n200_), .B(new_n376_), .C(new_n201_), .Y(new_n377_));
  OA21x2_ASAP7_75t_R  g319(.A1(new_n202_), .A2(new_n375_), .B(new_n377_), .Y(new_n378_));
  NOR2x1_ASAP7_75t_R  g320(.A(new_n320_), .B(new_n378_), .Y(G1905));
  AO21x1_ASAP7_75t_R  g321(.A1(G21), .A2(G29), .B(G33), .Y(new_n380_));
  OA21x2_ASAP7_75t_R  g322(.A1(new_n288_), .A2(new_n327_), .B(G29), .Y(new_n381_));
  OA21x2_ASAP7_75t_R  g323(.A1(G33), .A2(new_n381_), .B(new_n351_), .Y(new_n382_));
  NOR2x1_ASAP7_75t_R  g324(.A(G33), .B(G29), .Y(new_n383_));
  OR3x1_ASAP7_75t_R   g325(.A(new_n164_), .B(new_n383_), .C(new_n167_), .Y(new_n384_));
  AND3x1_ASAP7_75t_R  g326(.A(new_n60_), .B(new_n384_), .C(new_n333_), .Y(new_n385_));
  OAI21x1_ASAP7_75t_R g327(.A1(new_n382_), .A2(new_n385_), .B(new_n380_), .Y(new_n386_));
  OR3x1_ASAP7_75t_R   g328(.A(new_n380_), .B(new_n382_), .C(new_n385_), .Y(new_n387_));
  NAND2x1_ASAP7_75t_R g329(.A(new_n386_), .B(new_n387_), .Y(G1906));
  AO21x1_ASAP7_75t_R  g330(.A1(G30), .A2(G22), .B(G33), .Y(new_n389_));
  XOR2x2_ASAP7_75t_R  g331(.A(new_n70_), .B(G14), .Y(new_n390_));
  NOR2x1_ASAP7_75t_R  g332(.A(new_n215_), .B(new_n390_), .Y(new_n391_));
  NOR2x1_ASAP7_75t_R  g333(.A(G33), .B(G30), .Y(new_n392_));
  OR2x4_ASAP7_75t_R   g334(.A(new_n391_), .B(new_n392_), .Y(new_n393_));
  AOI21x1_ASAP7_75t_R g335(.A1(new_n215_), .A2(new_n390_), .B(new_n393_), .Y(new_n394_));
  NOR2x1_ASAP7_75t_R  g336(.A(new_n331_), .B(new_n394_), .Y(new_n395_));
  OR3x1_ASAP7_75t_R   g337(.A(new_n90_), .B(new_n106_), .C(new_n92_), .Y(new_n396_));
  OR3x1_ASAP7_75t_R   g338(.A(new_n93_), .B(new_n109_), .C(new_n102_), .Y(new_n397_));
  AND3x1_ASAP7_75t_R  g339(.A(new_n396_), .B(new_n397_), .C(new_n390_), .Y(new_n398_));
  AOI21x1_ASAP7_75t_R g340(.A1(G30), .A2(new_n331_), .B(G33), .Y(new_n399_));
  OR3x1_ASAP7_75t_R   g341(.A(new_n398_), .B(new_n399_), .C(new_n391_), .Y(new_n400_));
  INVx1_ASAP7_75t_R   g342(.A(new_n400_), .Y(new_n401_));
  AO21x1_ASAP7_75t_R  g343(.A1(new_n60_), .A2(new_n395_), .B(new_n401_), .Y(new_n402_));
  OR3x1_ASAP7_75t_R   g344(.A(new_n392_), .B(new_n398_), .C(new_n391_), .Y(new_n403_));
  AND3x1_ASAP7_75t_R  g345(.A(new_n60_), .B(new_n332_), .C(new_n403_), .Y(new_n404_));
  OR3x1_ASAP7_75t_R   g346(.A(new_n389_), .B(new_n401_), .C(new_n404_), .Y(new_n405_));
  INVx1_ASAP7_75t_R   g347(.A(new_n405_), .Y(new_n406_));
  AO21x1_ASAP7_75t_R  g348(.A1(new_n389_), .A2(new_n402_), .B(new_n406_), .Y(G1907));
  AND3x1_ASAP7_75t_R  g349(.A(new_n221_), .B(new_n335_), .C(G26), .Y(new_n408_));
  NAND2x1_ASAP7_75t_R g350(.A(new_n61_), .B(new_n408_), .Y(new_n409_));
  AND3x1_ASAP7_75t_R  g351(.A(new_n61_), .B(G26), .C(new_n335_), .Y(new_n410_));
  OA21x2_ASAP7_75t_R  g352(.A1(new_n221_), .A2(new_n410_), .B(new_n409_), .Y(new_n411_));
  OR3x1_ASAP7_75t_R   g353(.A(new_n211_), .B(new_n411_), .C(new_n209_), .Y(new_n412_));
  XOR2x2_ASAP7_75t_R  g354(.A(new_n221_), .B(new_n410_), .Y(new_n413_));
  NAND2x1_ASAP7_75t_R g355(.A(new_n220_), .B(new_n413_), .Y(new_n414_));
  AOI21x1_ASAP7_75t_R g356(.A1(new_n412_), .A2(new_n414_), .B(new_n320_), .Y(G1908));
endmodule


