module mapped(G3,G2,G4,G5,G1,G16,G17);
input G3,G2,G4,G5,G1;
output G16,G17;
wire __emorphic_0,__emorphic_1,__emorphic_2,__emorphic_3,__emorphic_4,__emorphic_5,__emorphic_6;
assign __emorphic_0 = (G1 & G3);
assign __emorphic_1 = (G4 & G3);
assign __emorphic_2 = ~__emorphic_1;
assign __emorphic_3 = (G2 & __emorphic_2);
assign __emorphic_4 = (__emorphic_0 | __emorphic_3);
assign __emorphic_5 = (G2 | G5);
assign __emorphic_6 = (__emorphic_2 & __emorphic_5);
assign G16 = __emorphic_4;
assign G17 = __emorphic_6;
endmodule
