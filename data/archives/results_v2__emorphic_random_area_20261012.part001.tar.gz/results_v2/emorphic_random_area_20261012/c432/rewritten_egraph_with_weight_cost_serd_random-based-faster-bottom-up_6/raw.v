// Benchmark "/home/flynn/workplace/MIGBalance/results_v2/emorphic_random_area_20261012/c432/rewritten_egraph_with_weight_cost_serd_random-based-faster-bottom-up_6/logic" written by ABC on Mon Oct 12 14:24:44 2026

module \/home/flynn/workplace/MIGBalance/results_v2/emorphic_random_area_20261012/c432/rewritten_egraph_with_weight_cost_serd_random-based-faster-bottom-up_6/logic  ( 
    G34, G28, G30, G24, G26, G20, G22, G16, G18, G12, G14, G8, G10, G4, G6,
    G1, G2, G35, G31, G27, G23, G19, G15, G11, G7, G3, G36, G33, G29, G25,
    G21, G17, G13, G9, G5, G32,
    G426, G427, G428, G429, G430, G431, G432  );
  input  G34, G28, G30, G24, G26, G20, G22, G16, G18, G12, G14, G8, G10,
    G4, G6, G1, G2, G35, G31, G27, G23, G19, G15, G11, G7, G3, G36, G33,
    G29, G25, G21, G17, G13, G9, G5, G32;
  output G426, G427, G428, G429, G430, G431, G432;
  wire new_n44_, new_n45_, new_n46_, new_n47_, new_n48_, new_n49_, new_n50_,
    new_n51_, new_n52_, new_n53_, new_n54_, new_n55_, new_n56_, new_n57_,
    new_n58_, new_n59_, new_n60_, new_n61_, new_n62_, new_n63_, new_n64_,
    new_n65_, new_n66_, new_n67_, new_n68_, new_n69_, new_n70_, new_n71_,
    new_n72_, new_n73_, new_n74_, new_n76_, new_n77_, new_n78_, new_n79_,
    new_n80_, new_n81_, new_n82_, new_n83_, new_n84_, new_n85_, new_n86_,
    new_n87_, new_n88_, new_n89_, new_n90_, new_n91_, new_n92_, new_n93_,
    new_n94_, new_n95_, new_n96_, new_n97_, new_n98_, new_n99_, new_n100_,
    new_n101_, new_n102_, new_n103_, new_n104_, new_n105_, new_n106_,
    new_n107_, new_n108_, new_n109_, new_n110_, new_n111_, new_n112_,
    new_n113_, new_n114_, new_n115_, new_n116_, new_n118_, new_n119_,
    new_n120_, new_n121_, new_n122_, new_n123_, new_n124_, new_n125_,
    new_n126_, new_n127_, new_n128_, new_n129_, new_n130_, new_n131_,
    new_n132_, new_n133_, new_n134_, new_n135_, new_n136_, new_n137_,
    new_n138_, new_n139_, new_n140_, new_n141_, new_n142_, new_n143_,
    new_n144_, new_n145_, new_n146_, new_n147_, new_n148_, new_n149_,
    new_n150_, new_n151_, new_n152_, new_n153_, new_n154_, new_n155_,
    new_n156_, new_n157_, new_n158_, new_n159_, new_n160_, new_n161_,
    new_n162_, new_n163_, new_n164_, new_n165_, new_n166_, new_n167_,
    new_n169_, new_n170_, new_n171_, new_n172_, new_n173_, new_n174_,
    new_n175_, new_n176_, new_n177_, new_n178_, new_n179_, new_n180_,
    new_n181_, new_n182_, new_n183_, new_n184_, new_n185_, new_n186_,
    new_n187_, new_n188_, new_n189_, new_n190_, new_n191_, new_n192_,
    new_n193_, new_n194_, new_n195_, new_n196_, new_n197_, new_n198_,
    new_n199_, new_n200_, new_n201_, new_n202_, new_n203_, new_n204_,
    new_n205_, new_n206_, new_n207_, new_n208_, new_n209_, new_n210_,
    new_n211_, new_n212_, new_n214_, new_n215_, new_n216_, new_n217_,
    new_n219_, new_n220_, new_n221_, new_n223_, new_n224_, new_n225_,
    new_n226_;
  INVx1_ASAP7_75t_R   g000(.A(G34), .Y(new_n44_));
  INVx1_ASAP7_75t_R   g001(.A(G30), .Y(new_n45_));
  INVx1_ASAP7_75t_R   g002(.A(G26), .Y(new_n46_));
  INVx1_ASAP7_75t_R   g003(.A(G22), .Y(new_n47_));
  INVx1_ASAP7_75t_R   g004(.A(G18), .Y(new_n48_));
  INVx1_ASAP7_75t_R   g005(.A(G12), .Y(new_n49_));
  INVx1_ASAP7_75t_R   g006(.A(G14), .Y(new_n50_));
  INVx1_ASAP7_75t_R   g007(.A(G8), .Y(new_n51_));
  INVx1_ASAP7_75t_R   g008(.A(G10), .Y(new_n52_));
  INVx1_ASAP7_75t_R   g009(.A(G4), .Y(new_n53_));
  INVx1_ASAP7_75t_R   g010(.A(G6), .Y(new_n54_));
  INVx1_ASAP7_75t_R   g011(.A(G1), .Y(new_n55_));
  INVx1_ASAP7_75t_R   g012(.A(G2), .Y(new_n56_));
  INVx1_ASAP7_75t_R   g013(.A(G7), .Y(new_n57_));
  NOR2x1_ASAP7_75t_R  g014(.A(G24), .B(new_n46_), .Y(new_n58_));
  INVx1_ASAP7_75t_R   g015(.A(new_n58_), .Y(new_n59_));
  NOR2x1_ASAP7_75t_R  g016(.A(G20), .B(new_n47_), .Y(new_n60_));
  NOR2x1_ASAP7_75t_R  g017(.A(new_n44_), .B(G32), .Y(new_n61_));
  INVx1_ASAP7_75t_R   g018(.A(new_n61_), .Y(new_n62_));
  OR3x1_ASAP7_75t_R   g019(.A(new_n58_), .B(new_n60_), .C(new_n61_), .Y(new_n63_));
  NOR2x1_ASAP7_75t_R  g020(.A(G28), .B(new_n45_), .Y(new_n64_));
  INVx1_ASAP7_75t_R   g021(.A(new_n64_), .Y(new_n65_));
  NOR2x1_ASAP7_75t_R  g022(.A(G8), .B(new_n52_), .Y(new_n66_));
  NOR2x1_ASAP7_75t_R  g023(.A(G4), .B(new_n54_), .Y(new_n67_));
  AO21x1_ASAP7_75t_R  g024(.A1(new_n55_), .A2(G2), .B(new_n67_), .Y(new_n68_));
  AO21x1_ASAP7_75t_R  g025(.A1(new_n51_), .A2(G10), .B(new_n68_), .Y(new_n69_));
  OR3x1_ASAP7_75t_R   g026(.A(new_n63_), .B(new_n64_), .C(new_n69_), .Y(new_n70_));
  NOR2x1_ASAP7_75t_R  g027(.A(G16), .B(new_n48_), .Y(new_n71_));
  INVx1_ASAP7_75t_R   g028(.A(new_n71_), .Y(new_n72_));
  AO21x1_ASAP7_75t_R  g029(.A1(new_n49_), .A2(G14), .B(new_n71_), .Y(new_n73_));
  NOR2x1_ASAP7_75t_R  g030(.A(new_n70_), .B(new_n73_), .Y(new_n74_));
  INVx1_ASAP7_75t_R   g031(.A(new_n74_), .Y(G426));
  NOR2x1_ASAP7_75t_R  g032(.A(new_n52_), .B(G11), .Y(new_n76_));
  INVx1_ASAP7_75t_R   g033(.A(new_n76_), .Y(new_n77_));
  OA21x2_ASAP7_75t_R  g034(.A1(new_n66_), .A2(new_n74_), .B(new_n76_), .Y(new_n78_));
  OA21x2_ASAP7_75t_R  g035(.A1(G1), .A2(new_n56_), .B(G426), .Y(new_n79_));
  OR3x1_ASAP7_75t_R   g036(.A(new_n56_), .B(G3), .C(new_n79_), .Y(new_n80_));
  INVx1_ASAP7_75t_R   g037(.A(new_n80_), .Y(new_n81_));
  OR3x1_ASAP7_75t_R   g038(.A(new_n58_), .B(new_n60_), .C(new_n73_), .Y(new_n82_));
  OR3x1_ASAP7_75t_R   g039(.A(new_n61_), .B(new_n64_), .C(new_n82_), .Y(new_n83_));
  OR3x1_ASAP7_75t_R   g040(.A(new_n68_), .B(new_n83_), .C(new_n66_), .Y(new_n84_));
  INVx1_ASAP7_75t_R   g041(.A(new_n84_), .Y(new_n85_));
  OR3x1_ASAP7_75t_R   g042(.A(G4), .B(new_n54_), .C(new_n85_), .Y(new_n86_));
  OR3x1_ASAP7_75t_R   g043(.A(new_n60_), .B(new_n64_), .C(new_n58_), .Y(new_n87_));
  OR3x1_ASAP7_75t_R   g044(.A(new_n61_), .B(new_n67_), .C(new_n87_), .Y(new_n88_));
  AO21x1_ASAP7_75t_R  g045(.A1(new_n51_), .A2(G10), .B(new_n73_), .Y(new_n89_));
  OR3x1_ASAP7_75t_R   g046(.A(new_n88_), .B(new_n89_), .C(new_n68_), .Y(new_n90_));
  NAND2x1_ASAP7_75t_R g047(.A(new_n86_), .B(new_n90_), .Y(new_n91_));
  AND3x1_ASAP7_75t_R  g048(.A(new_n57_), .B(new_n91_), .C(G6), .Y(new_n92_));
  OR3x1_ASAP7_75t_R   g049(.A(new_n78_), .B(new_n81_), .C(new_n92_), .Y(new_n93_));
  OR3x1_ASAP7_75t_R   g050(.A(new_n50_), .B(new_n85_), .C(G12), .Y(new_n94_));
  AO21x1_ASAP7_75t_R  g051(.A1(new_n49_), .A2(G14), .B(new_n61_), .Y(new_n95_));
  OR3x1_ASAP7_75t_R   g052(.A(new_n87_), .B(new_n95_), .C(new_n89_), .Y(new_n96_));
  OA21x2_ASAP7_75t_R  g053(.A1(new_n68_), .A2(new_n96_), .B(new_n94_), .Y(new_n97_));
  OR3x1_ASAP7_75t_R   g054(.A(new_n50_), .B(G15), .C(new_n97_), .Y(new_n98_));
  INVx1_ASAP7_75t_R   g055(.A(new_n98_), .Y(new_n99_));
  OA21x2_ASAP7_75t_R  g056(.A1(new_n71_), .A2(new_n84_), .B(new_n72_), .Y(new_n100_));
  OR3x1_ASAP7_75t_R   g057(.A(new_n48_), .B(new_n100_), .C(G19), .Y(new_n101_));
  INVx1_ASAP7_75t_R   g058(.A(new_n101_), .Y(new_n102_));
  OR3x1_ASAP7_75t_R   g059(.A(new_n93_), .B(new_n99_), .C(new_n102_), .Y(new_n103_));
  AO21x1_ASAP7_75t_R  g060(.A1(new_n62_), .A2(G426), .B(new_n44_), .Y(new_n104_));
  NOR2x1_ASAP7_75t_R  g061(.A(G35), .B(new_n104_), .Y(new_n105_));
  OA21x2_ASAP7_75t_R  g062(.A1(new_n64_), .A2(G426), .B(new_n65_), .Y(new_n106_));
  OR3x1_ASAP7_75t_R   g063(.A(new_n45_), .B(G31), .C(new_n106_), .Y(new_n107_));
  INVx1_ASAP7_75t_R   g064(.A(new_n107_), .Y(new_n108_));
  OA21x2_ASAP7_75t_R  g065(.A1(new_n58_), .A2(new_n84_), .B(new_n59_), .Y(new_n109_));
  OR3x1_ASAP7_75t_R   g066(.A(new_n46_), .B(new_n109_), .C(G27), .Y(new_n110_));
  INVx1_ASAP7_75t_R   g067(.A(new_n110_), .Y(new_n111_));
  NOR2x1_ASAP7_75t_R  g068(.A(new_n47_), .B(G23), .Y(new_n112_));
  OA21x2_ASAP7_75t_R  g069(.A1(new_n60_), .A2(new_n74_), .B(new_n112_), .Y(new_n113_));
  OR2x4_ASAP7_75t_R   g070(.A(new_n111_), .B(new_n113_), .Y(new_n114_));
  OR3x1_ASAP7_75t_R   g071(.A(new_n105_), .B(new_n108_), .C(new_n114_), .Y(new_n115_));
  NOR2x1_ASAP7_75t_R  g072(.A(new_n103_), .B(new_n115_), .Y(new_n116_));
  INVx1_ASAP7_75t_R   g073(.A(new_n116_), .Y(G427));
  OR3x1_ASAP7_75t_R   g074(.A(G19), .B(new_n100_), .C(new_n48_), .Y(new_n118_));
  OA21x2_ASAP7_75t_R  g075(.A1(new_n102_), .A2(G427), .B(new_n118_), .Y(new_n119_));
  OR3x1_ASAP7_75t_R   g076(.A(new_n100_), .B(new_n119_), .C(G21), .Y(new_n120_));
  OR3x1_ASAP7_75t_R   g077(.A(new_n99_), .B(new_n115_), .C(new_n103_), .Y(new_n121_));
  OA21x2_ASAP7_75t_R  g078(.A1(new_n98_), .A2(new_n116_), .B(new_n121_), .Y(new_n122_));
  AO21x1_ASAP7_75t_R  g079(.A1(new_n49_), .A2(G14), .B(new_n84_), .Y(new_n123_));
  AO21x1_ASAP7_75t_R  g080(.A1(new_n94_), .A2(new_n123_), .B(new_n50_), .Y(new_n124_));
  OR3x1_ASAP7_75t_R   g081(.A(G17), .B(new_n122_), .C(new_n124_), .Y(new_n125_));
  OAI21x1_ASAP7_75t_R g082(.A1(new_n48_), .A2(new_n120_), .B(new_n125_), .Y(new_n126_));
  NOR2x1_ASAP7_75t_R  g083(.A(new_n66_), .B(new_n85_), .Y(new_n127_));
  OA21x2_ASAP7_75t_R  g084(.A1(new_n77_), .A2(new_n127_), .B(G427), .Y(new_n128_));
  OR3x1_ASAP7_75t_R   g085(.A(new_n127_), .B(new_n128_), .C(new_n52_), .Y(new_n129_));
  OA21x2_ASAP7_75t_R  g086(.A1(G1), .A2(new_n56_), .B(new_n84_), .Y(new_n130_));
  OR3x1_ASAP7_75t_R   g087(.A(G3), .B(new_n130_), .C(new_n56_), .Y(new_n131_));
  AO21x1_ASAP7_75t_R  g088(.A1(G427), .A2(new_n131_), .B(G5), .Y(new_n132_));
  OR3x1_ASAP7_75t_R   g089(.A(new_n56_), .B(new_n130_), .C(new_n132_), .Y(new_n133_));
  OAI21x1_ASAP7_75t_R g090(.A1(G13), .A2(new_n129_), .B(new_n133_), .Y(new_n134_));
  AO21x1_ASAP7_75t_R  g091(.A1(new_n53_), .A2(G6), .B(new_n84_), .Y(new_n135_));
  NAND2x1_ASAP7_75t_R g092(.A(new_n98_), .B(new_n101_), .Y(new_n136_));
  OR3x1_ASAP7_75t_R   g093(.A(new_n108_), .B(new_n114_), .C(new_n136_), .Y(new_n137_));
  OR2x4_ASAP7_75t_R   g094(.A(new_n105_), .B(new_n137_), .Y(new_n138_));
  OR3x1_ASAP7_75t_R   g095(.A(new_n92_), .B(new_n93_), .C(new_n138_), .Y(new_n139_));
  INVx1_ASAP7_75t_R   g096(.A(new_n139_), .Y(new_n140_));
  AND3x1_ASAP7_75t_R  g097(.A(G6), .B(new_n57_), .C(G427), .Y(new_n141_));
  AOI21x1_ASAP7_75t_R g098(.A1(new_n91_), .A2(new_n141_), .B(new_n140_), .Y(new_n142_));
  AO21x1_ASAP7_75t_R  g099(.A1(new_n86_), .A2(new_n135_), .B(new_n142_), .Y(new_n143_));
  OR3x1_ASAP7_75t_R   g100(.A(new_n54_), .B(G9), .C(new_n143_), .Y(new_n144_));
  INVx1_ASAP7_75t_R   g101(.A(new_n144_), .Y(new_n145_));
  OR3x1_ASAP7_75t_R   g102(.A(new_n134_), .B(new_n145_), .C(new_n126_), .Y(new_n146_));
  OR3x1_ASAP7_75t_R   g103(.A(new_n93_), .B(new_n114_), .C(new_n136_), .Y(new_n147_));
  OR3x1_ASAP7_75t_R   g104(.A(new_n108_), .B(new_n111_), .C(new_n105_), .Y(new_n148_));
  OR3x1_ASAP7_75t_R   g105(.A(new_n46_), .B(G27), .C(new_n109_), .Y(new_n149_));
  OA21x2_ASAP7_75t_R  g106(.A1(new_n147_), .A2(new_n148_), .B(new_n149_), .Y(new_n150_));
  OR2x4_ASAP7_75t_R   g107(.A(new_n109_), .B(new_n150_), .Y(new_n151_));
  OR3x1_ASAP7_75t_R   g108(.A(new_n46_), .B(G29), .C(new_n151_), .Y(new_n152_));
  NOR2x1_ASAP7_75t_R  g109(.A(new_n60_), .B(new_n85_), .Y(new_n153_));
  OR3x1_ASAP7_75t_R   g110(.A(G23), .B(new_n153_), .C(new_n47_), .Y(new_n154_));
  OR3x1_ASAP7_75t_R   g111(.A(new_n47_), .B(G25), .C(new_n153_), .Y(new_n155_));
  AO21x1_ASAP7_75t_R  g112(.A1(G427), .A2(new_n154_), .B(new_n155_), .Y(new_n156_));
  NAND2x1_ASAP7_75t_R g113(.A(new_n152_), .B(new_n156_), .Y(new_n157_));
  NOR2x1_ASAP7_75t_R  g114(.A(new_n61_), .B(new_n85_), .Y(new_n158_));
  AO21x1_ASAP7_75t_R  g115(.A1(new_n62_), .A2(new_n84_), .B(new_n44_), .Y(new_n159_));
  OR3x1_ASAP7_75t_R   g116(.A(new_n44_), .B(G35), .C(new_n158_), .Y(new_n160_));
  AO21x1_ASAP7_75t_R  g117(.A1(G427), .A2(new_n160_), .B(new_n159_), .Y(new_n161_));
  OA21x2_ASAP7_75t_R  g118(.A1(new_n64_), .A2(new_n84_), .B(new_n65_), .Y(new_n162_));
  OR3x1_ASAP7_75t_R   g119(.A(new_n45_), .B(new_n162_), .C(G31), .Y(new_n163_));
  OR3x1_ASAP7_75t_R   g120(.A(new_n103_), .B(new_n108_), .C(new_n115_), .Y(new_n164_));
  AO21x1_ASAP7_75t_R  g121(.A1(new_n163_), .A2(new_n164_), .B(new_n162_), .Y(new_n165_));
  OR3x1_ASAP7_75t_R   g122(.A(new_n45_), .B(G33), .C(new_n165_), .Y(new_n166_));
  OAI21x1_ASAP7_75t_R g123(.A1(G36), .A2(new_n161_), .B(new_n166_), .Y(new_n167_));
  OR3x1_ASAP7_75t_R   g124(.A(new_n146_), .B(new_n157_), .C(new_n167_), .Y(G428));
  AND2x2_ASAP7_75t_R  g125(.A(G21), .B(G428), .Y(new_n169_));
  AND2x2_ASAP7_75t_R  g126(.A(G16), .B(G426), .Y(new_n170_));
  AO21x1_ASAP7_75t_R  g127(.A1(G19), .A2(G427), .B(new_n170_), .Y(new_n171_));
  OR3x1_ASAP7_75t_R   g128(.A(new_n169_), .B(new_n171_), .C(new_n48_), .Y(new_n172_));
  INVx1_ASAP7_75t_R   g129(.A(new_n172_), .Y(new_n173_));
  AND2x2_ASAP7_75t_R  g130(.A(G15), .B(G427), .Y(new_n174_));
  AO21x1_ASAP7_75t_R  g131(.A1(G12), .A2(G426), .B(new_n174_), .Y(new_n175_));
  AO21x1_ASAP7_75t_R  g132(.A1(G17), .A2(G428), .B(new_n175_), .Y(new_n176_));
  NOR2x1_ASAP7_75t_R  g133(.A(new_n50_), .B(new_n176_), .Y(new_n177_));
  INVx1_ASAP7_75t_R   g134(.A(new_n177_), .Y(new_n178_));
  NOR2x1_ASAP7_75t_R  g135(.A(new_n53_), .B(new_n74_), .Y(new_n179_));
  AO21x1_ASAP7_75t_R  g136(.A1(G7), .A2(G427), .B(new_n179_), .Y(new_n180_));
  AO21x1_ASAP7_75t_R  g137(.A1(G9), .A2(G428), .B(new_n180_), .Y(new_n181_));
  NOR2x1_ASAP7_75t_R  g138(.A(new_n54_), .B(new_n181_), .Y(new_n182_));
  NOR2x1_ASAP7_75t_R  g139(.A(new_n51_), .B(new_n74_), .Y(new_n183_));
  AO21x1_ASAP7_75t_R  g140(.A1(G11), .A2(G427), .B(new_n183_), .Y(new_n184_));
  AND2x2_ASAP7_75t_R  g141(.A(G13), .B(G428), .Y(new_n185_));
  OR3x1_ASAP7_75t_R   g142(.A(new_n184_), .B(new_n185_), .C(new_n52_), .Y(new_n186_));
  INVx1_ASAP7_75t_R   g143(.A(new_n186_), .Y(new_n187_));
  OAI21x1_ASAP7_75t_R g144(.A1(new_n54_), .A2(new_n181_), .B(new_n186_), .Y(new_n188_));
  NOR2x1_ASAP7_75t_R  g145(.A(new_n177_), .B(new_n188_), .Y(new_n189_));
  AND2x2_ASAP7_75t_R  g146(.A(G35), .B(G427), .Y(new_n190_));
  AO21x1_ASAP7_75t_R  g147(.A1(G36), .A2(G428), .B(new_n190_), .Y(new_n191_));
  AO21x1_ASAP7_75t_R  g148(.A1(G32), .A2(G426), .B(new_n191_), .Y(new_n192_));
  AND2x2_ASAP7_75t_R  g149(.A(G31), .B(G427), .Y(new_n193_));
  AO21x1_ASAP7_75t_R  g150(.A1(G33), .A2(G428), .B(new_n193_), .Y(new_n194_));
  AO21x1_ASAP7_75t_R  g151(.A1(G28), .A2(G426), .B(new_n194_), .Y(new_n195_));
  NOR2x1_ASAP7_75t_R  g152(.A(new_n45_), .B(new_n195_), .Y(new_n196_));
  AND2x2_ASAP7_75t_R  g153(.A(G29), .B(G428), .Y(new_n197_));
  AND2x2_ASAP7_75t_R  g154(.A(G24), .B(G426), .Y(new_n198_));
  AO21x1_ASAP7_75t_R  g155(.A1(G27), .A2(G427), .B(new_n198_), .Y(new_n199_));
  OR3x1_ASAP7_75t_R   g156(.A(new_n197_), .B(new_n199_), .C(new_n46_), .Y(new_n200_));
  INVx1_ASAP7_75t_R   g157(.A(new_n200_), .Y(new_n201_));
  NOR2x1_ASAP7_75t_R  g158(.A(new_n196_), .B(new_n201_), .Y(new_n202_));
  OA21x2_ASAP7_75t_R  g159(.A1(new_n44_), .A2(new_n192_), .B(new_n202_), .Y(new_n203_));
  AND2x2_ASAP7_75t_R  g160(.A(G20), .B(G426), .Y(new_n204_));
  AO21x1_ASAP7_75t_R  g161(.A1(G23), .A2(G427), .B(new_n204_), .Y(new_n205_));
  AO21x1_ASAP7_75t_R  g162(.A1(G25), .A2(G428), .B(new_n205_), .Y(new_n206_));
  NOR2x1_ASAP7_75t_R  g163(.A(new_n47_), .B(new_n206_), .Y(new_n207_));
  INVx1_ASAP7_75t_R   g164(.A(new_n207_), .Y(new_n208_));
  AND3x1_ASAP7_75t_R  g165(.A(new_n203_), .B(new_n208_), .C(new_n189_), .Y(new_n209_));
  AO21x1_ASAP7_75t_R  g166(.A1(G1), .A2(G426), .B(new_n56_), .Y(new_n210_));
  AO21x1_ASAP7_75t_R  g167(.A1(G5), .A2(G428), .B(new_n210_), .Y(new_n211_));
  AOI21x1_ASAP7_75t_R g168(.A1(G3), .A2(G427), .B(new_n211_), .Y(new_n212_));
  AOI21x1_ASAP7_75t_R g169(.A1(new_n172_), .A2(new_n209_), .B(new_n212_), .Y(G429));
  OR3x1_ASAP7_75t_R   g170(.A(new_n52_), .B(new_n185_), .C(new_n184_), .Y(new_n214_));
  INVx1_ASAP7_75t_R   g171(.A(new_n214_), .Y(new_n215_));
  NOR2x1_ASAP7_75t_R  g172(.A(new_n176_), .B(new_n215_), .Y(new_n216_));
  OR3x1_ASAP7_75t_R   g173(.A(new_n173_), .B(new_n182_), .C(new_n187_), .Y(new_n217_));
  AO21x1_ASAP7_75t_R  g174(.A1(G14), .A2(new_n216_), .B(new_n217_), .Y(G430));
  OR3x1_ASAP7_75t_R   g175(.A(new_n48_), .B(new_n169_), .C(new_n171_), .Y(new_n219_));
  AND3x1_ASAP7_75t_R  g176(.A(new_n178_), .B(new_n214_), .C(new_n207_), .Y(new_n220_));
  AO21x1_ASAP7_75t_R  g177(.A1(new_n178_), .A2(new_n201_), .B(new_n220_), .Y(new_n221_));
  AO21x1_ASAP7_75t_R  g178(.A1(new_n219_), .A2(new_n221_), .B(new_n188_), .Y(G431));
  OR3x1_ASAP7_75t_R   g179(.A(new_n46_), .B(new_n197_), .C(new_n199_), .Y(new_n223_));
  AND2x2_ASAP7_75t_R  g180(.A(new_n207_), .B(new_n219_), .Y(new_n224_));
  AO21x1_ASAP7_75t_R  g181(.A1(new_n196_), .A2(new_n223_), .B(new_n224_), .Y(new_n225_));
  AO21x1_ASAP7_75t_R  g182(.A1(new_n178_), .A2(new_n225_), .B(new_n177_), .Y(new_n226_));
  AO21x1_ASAP7_75t_R  g183(.A1(new_n214_), .A2(new_n226_), .B(new_n182_), .Y(G432));
endmodule


