// Benchmark "/home/flynn/workplace/MIGBalance/results_v2/emorphic_random_area_20261012/c432/rewritten_egraph_with_weight_cost_serd_random-based-faster-bottom-up_9/logic" written by ABC on Mon Oct 12 14:24:45 2026

module \/home/flynn/workplace/MIGBalance/results_v2/emorphic_random_area_20261012/c432/rewritten_egraph_with_weight_cost_serd_random-based-faster-bottom-up_9/logic  ( 
    G34, G28, G30, G24, G26, G20, G22, G16, G18, G12, G14, G8, G10, G4, G6,
    G1, G2, G35, G31, G27, G23, G19, G15, G11, G7, G3, G36, G33, G29, G25,
    G21, G17, G13, G9, G5, G32,
    G426, G427, G428, G429, G430, G431, G432  );
  input  G34, G28, G30, G24, G26, G20, G22, G16, G18, G12, G14, G8, G10,
    G4, G6, G1, G2, G35, G31, G27, G23, G19, G15, G11, G7, G3, G36, G33,
    G29, G25, G21, G17, G13, G9, G5, G32;
  output G426, G427, G428, G429, G430, G431, G432;
  wire new_n44_, new_n45_, new_n46_, new_n47_, new_n48_, new_n49_, new_n50_,
    new_n51_, new_n52_, new_n53_, new_n54_, new_n55_, new_n56_, new_n57_,
    new_n58_, new_n59_, new_n60_, new_n61_, new_n62_, new_n63_, new_n64_,
    new_n65_, new_n66_, new_n67_, new_n68_, new_n69_, new_n70_, new_n71_,
    new_n72_, new_n74_, new_n75_, new_n76_, new_n77_, new_n78_, new_n79_,
    new_n80_, new_n81_, new_n82_, new_n83_, new_n84_, new_n85_, new_n86_,
    new_n87_, new_n88_, new_n89_, new_n90_, new_n91_, new_n92_, new_n93_,
    new_n94_, new_n95_, new_n96_, new_n97_, new_n98_, new_n99_, new_n100_,
    new_n101_, new_n102_, new_n103_, new_n104_, new_n105_, new_n106_,
    new_n107_, new_n108_, new_n109_, new_n110_, new_n111_, new_n112_,
    new_n113_, new_n114_, new_n115_, new_n116_, new_n118_, new_n119_,
    new_n120_, new_n121_, new_n122_, new_n123_, new_n124_, new_n125_,
    new_n126_, new_n127_, new_n128_, new_n129_, new_n130_, new_n131_,
    new_n132_, new_n133_, new_n134_, new_n135_, new_n136_, new_n137_,
    new_n138_, new_n139_, new_n140_, new_n141_, new_n142_, new_n143_,
    new_n144_, new_n145_, new_n146_, new_n147_, new_n148_, new_n149_,
    new_n150_, new_n151_, new_n152_, new_n153_, new_n154_, new_n155_,
    new_n156_, new_n157_, new_n158_, new_n159_, new_n160_, new_n161_,
    new_n162_, new_n163_, new_n164_, new_n165_, new_n166_, new_n167_,
    new_n168_, new_n169_, new_n170_, new_n171_, new_n172_, new_n173_,
    new_n174_, new_n175_, new_n176_, new_n178_, new_n179_, new_n180_,
    new_n181_, new_n182_, new_n183_, new_n184_, new_n185_, new_n186_,
    new_n187_, new_n188_, new_n189_, new_n190_, new_n191_, new_n192_,
    new_n193_, new_n194_, new_n195_, new_n196_, new_n197_, new_n198_,
    new_n199_, new_n200_, new_n201_, new_n202_, new_n203_, new_n204_,
    new_n205_, new_n206_, new_n207_, new_n208_, new_n209_, new_n210_,
    new_n211_, new_n212_, new_n213_, new_n214_, new_n215_, new_n216_,
    new_n217_, new_n218_, new_n219_, new_n221_, new_n222_, new_n223_,
    new_n225_, new_n226_, new_n227_, new_n228_, new_n229_, new_n230_,
    new_n231_, new_n232_, new_n233_, new_n235_, new_n236_, new_n237_,
    new_n238_, new_n239_, new_n240_;
  INVx1_ASAP7_75t_R   g000(.A(G34), .Y(new_n44_));
  INVx1_ASAP7_75t_R   g001(.A(G30), .Y(new_n45_));
  INVx1_ASAP7_75t_R   g002(.A(G26), .Y(new_n46_));
  INVx1_ASAP7_75t_R   g003(.A(G22), .Y(new_n47_));
  INVx1_ASAP7_75t_R   g004(.A(G16), .Y(new_n48_));
  INVx1_ASAP7_75t_R   g005(.A(G18), .Y(new_n49_));
  INVx1_ASAP7_75t_R   g006(.A(G14), .Y(new_n50_));
  INVx1_ASAP7_75t_R   g007(.A(G10), .Y(new_n51_));
  INVx1_ASAP7_75t_R   g008(.A(G4), .Y(new_n52_));
  INVx1_ASAP7_75t_R   g009(.A(G6), .Y(new_n53_));
  INVx1_ASAP7_75t_R   g010(.A(G2), .Y(new_n54_));
  INVx1_ASAP7_75t_R   g011(.A(G29), .Y(new_n55_));
  NOR2x1_ASAP7_75t_R  g012(.A(G16), .B(new_n49_), .Y(new_n56_));
  INVx1_ASAP7_75t_R   g013(.A(new_n56_), .Y(new_n57_));
  NOR2x1_ASAP7_75t_R  g014(.A(G12), .B(new_n50_), .Y(new_n58_));
  AO21x1_ASAP7_75t_R  g015(.A1(new_n48_), .A2(G18), .B(new_n58_), .Y(new_n59_));
  NOR2x1_ASAP7_75t_R  g016(.A(G8), .B(new_n51_), .Y(new_n60_));
  NOR2x1_ASAP7_75t_R  g017(.A(G4), .B(new_n53_), .Y(new_n61_));
  NOR2x1_ASAP7_75t_R  g018(.A(G1), .B(new_n54_), .Y(new_n62_));
  AO21x1_ASAP7_75t_R  g019(.A1(new_n52_), .A2(G6), .B(new_n62_), .Y(new_n63_));
  NOR2x1_ASAP7_75t_R  g020(.A(G28), .B(new_n45_), .Y(new_n64_));
  INVx1_ASAP7_75t_R   g021(.A(new_n64_), .Y(new_n65_));
  NOR2x1_ASAP7_75t_R  g022(.A(new_n44_), .B(G32), .Y(new_n66_));
  NOR2x1_ASAP7_75t_R  g023(.A(G24), .B(new_n46_), .Y(new_n67_));
  INVx1_ASAP7_75t_R   g024(.A(new_n67_), .Y(new_n68_));
  OR3x1_ASAP7_75t_R   g025(.A(new_n66_), .B(new_n67_), .C(new_n64_), .Y(new_n69_));
  NOR2x1_ASAP7_75t_R  g026(.A(G20), .B(new_n47_), .Y(new_n70_));
  OR2x4_ASAP7_75t_R   g027(.A(new_n69_), .B(new_n70_), .Y(new_n71_));
  OR3x1_ASAP7_75t_R   g028(.A(new_n60_), .B(new_n63_), .C(new_n71_), .Y(new_n72_));
  OR3x1_ASAP7_75t_R   g029(.A(new_n56_), .B(new_n58_), .C(new_n72_), .Y(G426));
  INVx1_ASAP7_75t_R   g030(.A(G426), .Y(new_n74_));
  AO21x1_ASAP7_75t_R  g031(.A1(new_n52_), .A2(G6), .B(new_n60_), .Y(new_n75_));
  OR3x1_ASAP7_75t_R   g032(.A(new_n59_), .B(new_n75_), .C(new_n62_), .Y(new_n76_));
  OR3x1_ASAP7_75t_R   g033(.A(new_n70_), .B(new_n76_), .C(new_n67_), .Y(new_n77_));
  OR3x1_ASAP7_75t_R   g034(.A(new_n66_), .B(new_n77_), .C(new_n64_), .Y(new_n78_));
  INVx1_ASAP7_75t_R   g035(.A(new_n78_), .Y(new_n79_));
  OA21x2_ASAP7_75t_R  g036(.A1(new_n64_), .A2(new_n78_), .B(new_n65_), .Y(new_n80_));
  OR3x1_ASAP7_75t_R   g037(.A(new_n45_), .B(G31), .C(new_n80_), .Y(new_n81_));
  INVx1_ASAP7_75t_R   g038(.A(new_n81_), .Y(new_n82_));
  NOR2x1_ASAP7_75t_R  g039(.A(new_n66_), .B(new_n79_), .Y(new_n83_));
  OR3x1_ASAP7_75t_R   g040(.A(new_n44_), .B(G35), .C(new_n83_), .Y(new_n84_));
  INVx1_ASAP7_75t_R   g041(.A(new_n84_), .Y(new_n85_));
  NOR2x1_ASAP7_75t_R  g042(.A(new_n62_), .B(new_n79_), .Y(new_n86_));
  OR3x1_ASAP7_75t_R   g043(.A(new_n54_), .B(new_n86_), .C(G3), .Y(new_n87_));
  OR3x1_ASAP7_75t_R   g044(.A(new_n64_), .B(new_n70_), .C(new_n67_), .Y(new_n88_));
  OR3x1_ASAP7_75t_R   g045(.A(new_n61_), .B(new_n66_), .C(new_n88_), .Y(new_n89_));
  OR3x1_ASAP7_75t_R   g046(.A(new_n58_), .B(new_n60_), .C(new_n56_), .Y(new_n90_));
  OR3x1_ASAP7_75t_R   g047(.A(new_n89_), .B(new_n90_), .C(new_n63_), .Y(new_n91_));
  OR3x1_ASAP7_75t_R   g048(.A(G4), .B(new_n53_), .C(new_n79_), .Y(new_n92_));
  AO21x1_ASAP7_75t_R  g049(.A1(new_n91_), .A2(new_n92_), .B(G7), .Y(new_n93_));
  NOR2x1_ASAP7_75t_R  g050(.A(new_n53_), .B(new_n93_), .Y(new_n94_));
  OAI21x1_ASAP7_75t_R g051(.A1(new_n53_), .A2(new_n93_), .B(new_n87_), .Y(new_n95_));
  NOR2x1_ASAP7_75t_R  g052(.A(new_n51_), .B(G11), .Y(new_n96_));
  OA21x2_ASAP7_75t_R  g053(.A1(new_n60_), .A2(new_n74_), .B(new_n96_), .Y(new_n97_));
  OR3x1_ASAP7_75t_R   g054(.A(new_n69_), .B(new_n70_), .C(new_n56_), .Y(new_n98_));
  OR3x1_ASAP7_75t_R   g055(.A(new_n63_), .B(new_n90_), .C(new_n98_), .Y(new_n99_));
  AO21x1_ASAP7_75t_R  g056(.A1(new_n57_), .A2(new_n99_), .B(new_n49_), .Y(new_n100_));
  NOR2x1_ASAP7_75t_R  g057(.A(G19), .B(new_n100_), .Y(new_n101_));
  NAND2x1_ASAP7_75t_R g058(.A(new_n58_), .B(new_n78_), .Y(new_n102_));
  OR3x1_ASAP7_75t_R   g059(.A(new_n58_), .B(new_n66_), .C(new_n88_), .Y(new_n103_));
  OR3x1_ASAP7_75t_R   g060(.A(new_n90_), .B(new_n103_), .C(new_n63_), .Y(new_n104_));
  AND2x2_ASAP7_75t_R  g061(.A(new_n102_), .B(new_n104_), .Y(new_n105_));
  OR3x1_ASAP7_75t_R   g062(.A(new_n50_), .B(G15), .C(new_n105_), .Y(new_n106_));
  INVx1_ASAP7_75t_R   g063(.A(new_n106_), .Y(new_n107_));
  OR3x1_ASAP7_75t_R   g064(.A(new_n97_), .B(new_n101_), .C(new_n107_), .Y(new_n108_));
  NOR2x1_ASAP7_75t_R  g065(.A(new_n70_), .B(new_n74_), .Y(new_n109_));
  OR3x1_ASAP7_75t_R   g066(.A(new_n47_), .B(new_n109_), .C(G23), .Y(new_n110_));
  INVx1_ASAP7_75t_R   g067(.A(new_n110_), .Y(new_n111_));
  OA21x2_ASAP7_75t_R  g068(.A1(new_n67_), .A2(new_n78_), .B(new_n68_), .Y(new_n112_));
  OR3x1_ASAP7_75t_R   g069(.A(new_n46_), .B(new_n112_), .C(G27), .Y(new_n113_));
  INVx1_ASAP7_75t_R   g070(.A(new_n113_), .Y(new_n114_));
  OR3x1_ASAP7_75t_R   g071(.A(new_n111_), .B(new_n114_), .C(new_n108_), .Y(new_n115_));
  OR2x4_ASAP7_75t_R   g072(.A(new_n95_), .B(new_n115_), .Y(new_n116_));
  OR3x1_ASAP7_75t_R   g073(.A(new_n82_), .B(new_n85_), .C(new_n116_), .Y(G427));
  OR3x1_ASAP7_75t_R   g074(.A(new_n45_), .B(new_n80_), .C(G31), .Y(new_n118_));
  INVx1_ASAP7_75t_R   g075(.A(new_n118_), .Y(new_n119_));
  OR3x1_ASAP7_75t_R   g076(.A(new_n44_), .B(new_n83_), .C(G35), .Y(new_n120_));
  INVx1_ASAP7_75t_R   g077(.A(new_n120_), .Y(new_n121_));
  OR3x1_ASAP7_75t_R   g078(.A(new_n119_), .B(new_n121_), .C(new_n116_), .Y(new_n122_));
  INVx1_ASAP7_75t_R   g079(.A(new_n122_), .Y(new_n123_));
  OR3x1_ASAP7_75t_R   g080(.A(new_n44_), .B(new_n83_), .C(G36), .Y(new_n124_));
  AOI21x1_ASAP7_75t_R g081(.A1(new_n84_), .A2(new_n122_), .B(new_n124_), .Y(new_n125_));
  AO21x1_ASAP7_75t_R  g082(.A1(new_n118_), .A2(new_n123_), .B(new_n82_), .Y(new_n126_));
  OR3x1_ASAP7_75t_R   g083(.A(new_n45_), .B(G33), .C(new_n80_), .Y(new_n127_));
  INVx1_ASAP7_75t_R   g084(.A(new_n127_), .Y(new_n128_));
  OA21x2_ASAP7_75t_R  g085(.A1(new_n114_), .A2(new_n122_), .B(new_n113_), .Y(new_n129_));
  NOR2x1_ASAP7_75t_R  g086(.A(new_n112_), .B(new_n129_), .Y(new_n130_));
  AND3x1_ASAP7_75t_R  g087(.A(G26), .B(new_n130_), .C(new_n55_), .Y(new_n131_));
  AO21x1_ASAP7_75t_R  g088(.A1(new_n126_), .A2(new_n128_), .B(new_n131_), .Y(new_n132_));
  NOR2x1_ASAP7_75t_R  g089(.A(new_n70_), .B(new_n79_), .Y(new_n133_));
  OR3x1_ASAP7_75t_R   g090(.A(new_n47_), .B(G25), .C(new_n133_), .Y(new_n134_));
  OR3x1_ASAP7_75t_R   g091(.A(new_n47_), .B(G23), .C(new_n133_), .Y(new_n135_));
  AOI21x1_ASAP7_75t_R g092(.A1(new_n122_), .A2(new_n135_), .B(new_n134_), .Y(new_n136_));
  OR3x1_ASAP7_75t_R   g093(.A(new_n132_), .B(new_n136_), .C(new_n125_), .Y(new_n137_));
  OR3x1_ASAP7_75t_R   g094(.A(new_n54_), .B(G3), .C(new_n86_), .Y(new_n138_));
  AO21x1_ASAP7_75t_R  g095(.A1(new_n122_), .A2(new_n138_), .B(G5), .Y(new_n139_));
  OR3x1_ASAP7_75t_R   g096(.A(new_n54_), .B(new_n86_), .C(new_n139_), .Y(new_n140_));
  OR3x1_ASAP7_75t_R   g097(.A(new_n64_), .B(new_n67_), .C(new_n66_), .Y(new_n141_));
  OR3x1_ASAP7_75t_R   g098(.A(new_n61_), .B(new_n141_), .C(new_n70_), .Y(new_n142_));
  OR3x1_ASAP7_75t_R   g099(.A(new_n62_), .B(new_n75_), .C(new_n142_), .Y(new_n143_));
  OA21x2_ASAP7_75t_R  g100(.A1(new_n59_), .A2(new_n143_), .B(new_n92_), .Y(new_n144_));
  OR3x1_ASAP7_75t_R   g101(.A(new_n53_), .B(G9), .C(new_n144_), .Y(new_n145_));
  AO21x1_ASAP7_75t_R  g102(.A1(new_n91_), .A2(new_n92_), .B(new_n123_), .Y(new_n146_));
  OR3x1_ASAP7_75t_R   g103(.A(new_n53_), .B(G7), .C(new_n146_), .Y(new_n147_));
  OAI21x1_ASAP7_75t_R g104(.A1(G19), .A2(new_n100_), .B(new_n106_), .Y(new_n148_));
  OR3x1_ASAP7_75t_R   g105(.A(new_n111_), .B(new_n119_), .C(new_n114_), .Y(new_n149_));
  OR3x1_ASAP7_75t_R   g106(.A(new_n94_), .B(new_n121_), .C(new_n149_), .Y(new_n150_));
  OR3x1_ASAP7_75t_R   g107(.A(new_n95_), .B(new_n97_), .C(new_n150_), .Y(new_n151_));
  OA21x2_ASAP7_75t_R  g108(.A1(new_n148_), .A2(new_n151_), .B(new_n147_), .Y(new_n152_));
  OAI21x1_ASAP7_75t_R g109(.A1(new_n145_), .A2(new_n152_), .B(new_n140_), .Y(new_n153_));
  NOR2x1_ASAP7_75t_R  g110(.A(new_n60_), .B(new_n79_), .Y(new_n154_));
  OR3x1_ASAP7_75t_R   g111(.A(new_n51_), .B(G11), .C(new_n154_), .Y(new_n155_));
  AO21x1_ASAP7_75t_R  g112(.A1(new_n122_), .A2(new_n155_), .B(new_n154_), .Y(new_n156_));
  OR3x1_ASAP7_75t_R   g113(.A(new_n51_), .B(G13), .C(new_n156_), .Y(new_n157_));
  INVx1_ASAP7_75t_R   g114(.A(new_n157_), .Y(new_n158_));
  OR3x1_ASAP7_75t_R   g115(.A(new_n153_), .B(new_n158_), .C(new_n137_), .Y(new_n159_));
  NOR2x1_ASAP7_75t_R  g116(.A(new_n114_), .B(new_n121_), .Y(new_n160_));
  AND3x1_ASAP7_75t_R  g117(.A(new_n118_), .B(new_n160_), .C(new_n110_), .Y(new_n161_));
  OR3x1_ASAP7_75t_R   g118(.A(new_n95_), .B(new_n148_), .C(new_n97_), .Y(new_n162_));
  INVx1_ASAP7_75t_R   g119(.A(new_n162_), .Y(new_n163_));
  AND3x1_ASAP7_75t_R  g120(.A(new_n106_), .B(new_n163_), .C(new_n161_), .Y(new_n164_));
  AOI21x1_ASAP7_75t_R g121(.A1(new_n107_), .A2(new_n122_), .B(new_n164_), .Y(new_n165_));
  OR2x4_ASAP7_75t_R   g122(.A(new_n58_), .B(new_n78_), .Y(new_n166_));
  AO21x1_ASAP7_75t_R  g123(.A1(new_n102_), .A2(new_n166_), .B(new_n165_), .Y(new_n167_));
  OR3x1_ASAP7_75t_R   g124(.A(G17), .B(new_n167_), .C(new_n50_), .Y(new_n168_));
  OR3x1_ASAP7_75t_R   g125(.A(new_n67_), .B(new_n70_), .C(new_n66_), .Y(new_n169_));
  OR3x1_ASAP7_75t_R   g126(.A(new_n64_), .B(new_n169_), .C(new_n56_), .Y(new_n170_));
  OA21x2_ASAP7_75t_R  g127(.A1(new_n76_), .A2(new_n170_), .B(new_n57_), .Y(new_n171_));
  OR3x1_ASAP7_75t_R   g128(.A(G19), .B(new_n171_), .C(new_n49_), .Y(new_n172_));
  OA21x2_ASAP7_75t_R  g129(.A1(new_n101_), .A2(new_n122_), .B(new_n172_), .Y(new_n173_));
  OR3x1_ASAP7_75t_R   g130(.A(new_n171_), .B(new_n173_), .C(new_n49_), .Y(new_n174_));
  OAI21x1_ASAP7_75t_R g131(.A1(G21), .A2(new_n174_), .B(new_n168_), .Y(new_n175_));
  NOR2x1_ASAP7_75t_R  g132(.A(new_n159_), .B(new_n175_), .Y(new_n176_));
  INVx1_ASAP7_75t_R   g133(.A(new_n176_), .Y(G428));
  AND2x2_ASAP7_75t_R  g134(.A(G5), .B(G428), .Y(new_n178_));
  AO21x1_ASAP7_75t_R  g135(.A1(G3), .A2(G427), .B(new_n178_), .Y(new_n179_));
  AND2x2_ASAP7_75t_R  g136(.A(G1), .B(G426), .Y(new_n180_));
  OR3x1_ASAP7_75t_R   g137(.A(new_n54_), .B(new_n179_), .C(new_n180_), .Y(new_n181_));
  AND2x2_ASAP7_75t_R  g138(.A(G32), .B(G426), .Y(new_n182_));
  AO21x1_ASAP7_75t_R  g139(.A1(G36), .A2(G428), .B(new_n182_), .Y(new_n183_));
  AO21x1_ASAP7_75t_R  g140(.A1(G35), .A2(G427), .B(new_n183_), .Y(new_n184_));
  NOR2x1_ASAP7_75t_R  g141(.A(new_n44_), .B(new_n184_), .Y(new_n185_));
  AND2x2_ASAP7_75t_R  g142(.A(G28), .B(G426), .Y(new_n186_));
  AO21x1_ASAP7_75t_R  g143(.A1(G33), .A2(G428), .B(new_n186_), .Y(new_n187_));
  AO21x1_ASAP7_75t_R  g144(.A1(G31), .A2(G427), .B(new_n187_), .Y(new_n188_));
  NOR2x1_ASAP7_75t_R  g145(.A(new_n55_), .B(new_n176_), .Y(new_n189_));
  AND2x2_ASAP7_75t_R  g146(.A(G27), .B(G427), .Y(new_n190_));
  AO21x1_ASAP7_75t_R  g147(.A1(G24), .A2(G426), .B(new_n190_), .Y(new_n191_));
  OR3x1_ASAP7_75t_R   g148(.A(new_n189_), .B(new_n191_), .C(new_n46_), .Y(new_n192_));
  INVx1_ASAP7_75t_R   g149(.A(new_n192_), .Y(new_n193_));
  OAI21x1_ASAP7_75t_R g150(.A1(new_n45_), .A2(new_n188_), .B(new_n192_), .Y(new_n194_));
  AND2x2_ASAP7_75t_R  g151(.A(G23), .B(G427), .Y(new_n195_));
  AO21x1_ASAP7_75t_R  g152(.A1(G20), .A2(G426), .B(new_n195_), .Y(new_n196_));
  AO21x1_ASAP7_75t_R  g153(.A1(G25), .A2(G428), .B(new_n196_), .Y(new_n197_));
  NOR2x1_ASAP7_75t_R  g154(.A(new_n47_), .B(new_n197_), .Y(new_n198_));
  OR3x1_ASAP7_75t_R   g155(.A(new_n194_), .B(new_n198_), .C(new_n185_), .Y(new_n199_));
  NOR2x1_ASAP7_75t_R  g156(.A(new_n48_), .B(new_n74_), .Y(new_n200_));
  AO21x1_ASAP7_75t_R  g157(.A1(G19), .A2(G427), .B(new_n200_), .Y(new_n201_));
  AND2x2_ASAP7_75t_R  g158(.A(G21), .B(G428), .Y(new_n202_));
  OR3x1_ASAP7_75t_R   g159(.A(new_n201_), .B(new_n202_), .C(new_n49_), .Y(new_n203_));
  INVx1_ASAP7_75t_R   g160(.A(new_n203_), .Y(new_n204_));
  AND2x2_ASAP7_75t_R  g161(.A(G17), .B(G428), .Y(new_n205_));
  AO21x1_ASAP7_75t_R  g162(.A1(G15), .A2(G427), .B(new_n205_), .Y(new_n206_));
  AO21x1_ASAP7_75t_R  g163(.A1(G12), .A2(G426), .B(new_n206_), .Y(new_n207_));
  NOR2x1_ASAP7_75t_R  g164(.A(new_n50_), .B(new_n207_), .Y(new_n208_));
  AND2x2_ASAP7_75t_R  g165(.A(G7), .B(G427), .Y(new_n209_));
  AO21x1_ASAP7_75t_R  g166(.A1(G9), .A2(G428), .B(new_n209_), .Y(new_n210_));
  AO21x1_ASAP7_75t_R  g167(.A1(G4), .A2(G426), .B(new_n210_), .Y(new_n211_));
  NOR2x1_ASAP7_75t_R  g168(.A(new_n53_), .B(new_n211_), .Y(new_n212_));
  AND2x2_ASAP7_75t_R  g169(.A(G11), .B(G427), .Y(new_n213_));
  AO21x1_ASAP7_75t_R  g170(.A1(G8), .A2(G426), .B(new_n213_), .Y(new_n214_));
  AND2x2_ASAP7_75t_R  g171(.A(G13), .B(G428), .Y(new_n215_));
  OR3x1_ASAP7_75t_R   g172(.A(new_n214_), .B(new_n215_), .C(new_n51_), .Y(new_n216_));
  INVx1_ASAP7_75t_R   g173(.A(new_n216_), .Y(new_n217_));
  OR3x1_ASAP7_75t_R   g174(.A(new_n208_), .B(new_n212_), .C(new_n217_), .Y(new_n218_));
  OR3x1_ASAP7_75t_R   g175(.A(new_n199_), .B(new_n204_), .C(new_n218_), .Y(new_n219_));
  AND2x2_ASAP7_75t_R  g176(.A(new_n181_), .B(new_n219_), .Y(G429));
  OR3x1_ASAP7_75t_R   g177(.A(new_n51_), .B(new_n215_), .C(new_n213_), .Y(new_n221_));
  AO21x1_ASAP7_75t_R  g178(.A1(G8), .A2(G426), .B(new_n221_), .Y(new_n222_));
  AO21x1_ASAP7_75t_R  g179(.A1(new_n208_), .A2(new_n222_), .B(new_n204_), .Y(new_n223_));
  OR3x1_ASAP7_75t_R   g180(.A(new_n217_), .B(new_n223_), .C(new_n212_), .Y(G430));
  OR3x1_ASAP7_75t_R   g181(.A(new_n49_), .B(new_n202_), .C(new_n200_), .Y(new_n225_));
  AO21x1_ASAP7_75t_R  g182(.A1(G19), .A2(G427), .B(new_n225_), .Y(new_n226_));
  INVx1_ASAP7_75t_R   g183(.A(new_n226_), .Y(new_n227_));
  AO21x1_ASAP7_75t_R  g184(.A1(G17), .A2(G428), .B(new_n50_), .Y(new_n228_));
  AO21x1_ASAP7_75t_R  g185(.A1(G15), .A2(G427), .B(new_n228_), .Y(new_n229_));
  AO21x1_ASAP7_75t_R  g186(.A1(G12), .A2(G426), .B(new_n229_), .Y(new_n230_));
  AND3x1_ASAP7_75t_R  g187(.A(new_n222_), .B(new_n230_), .C(new_n198_), .Y(new_n231_));
  AO21x1_ASAP7_75t_R  g188(.A1(new_n193_), .A2(new_n230_), .B(new_n231_), .Y(new_n232_));
  AO21x1_ASAP7_75t_R  g189(.A1(new_n226_), .A2(new_n232_), .B(new_n217_), .Y(new_n233_));
  OR2x4_ASAP7_75t_R   g190(.A(new_n212_), .B(new_n233_), .Y(G431));
  OR3x1_ASAP7_75t_R   g191(.A(new_n47_), .B(new_n227_), .C(new_n197_), .Y(new_n235_));
  OR3x1_ASAP7_75t_R   g192(.A(new_n46_), .B(new_n189_), .C(new_n191_), .Y(new_n236_));
  INVx1_ASAP7_75t_R   g193(.A(new_n236_), .Y(new_n237_));
  OR3x1_ASAP7_75t_R   g194(.A(new_n188_), .B(new_n237_), .C(new_n45_), .Y(new_n238_));
  NAND2x1_ASAP7_75t_R g195(.A(new_n235_), .B(new_n238_), .Y(new_n239_));
  AO21x1_ASAP7_75t_R  g196(.A1(new_n230_), .A2(new_n239_), .B(new_n208_), .Y(new_n240_));
  AO21x1_ASAP7_75t_R  g197(.A1(new_n222_), .A2(new_n240_), .B(new_n212_), .Y(G432));
endmodule


