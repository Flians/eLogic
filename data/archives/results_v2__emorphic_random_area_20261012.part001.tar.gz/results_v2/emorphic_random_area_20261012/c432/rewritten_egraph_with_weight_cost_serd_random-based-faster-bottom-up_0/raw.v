// Benchmark "/home/flynn/workplace/MIGBalance/results_v2/emorphic_random_area_20261012/c432/rewritten_egraph_with_weight_cost_serd_random-based-faster-bottom-up_0/logic" written by ABC on Mon Oct 12 14:24:41 2026

module \/home/flynn/workplace/MIGBalance/results_v2/emorphic_random_area_20261012/c432/rewritten_egraph_with_weight_cost_serd_random-based-faster-bottom-up_0/logic  ( 
    G34, G28, G30, G24, G26, G20, G22, G16, G18, G12, G14, G8, G10, G4, G6,
    G1, G2, G35, G31, G27, G23, G19, G15, G11, G7, G3, G36, G33, G29, G25,
    G21, G17, G13, G9, G5, G32,
    G426, G427, G428, G429, G430, G431, G432  );
  input  G34, G28, G30, G24, G26, G20, G22, G16, G18, G12, G14, G8, G10,
    G4, G6, G1, G2, G35, G31, G27, G23, G19, G15, G11, G7, G3, G36, G33,
    G29, G25, G21, G17, G13, G9, G5, G32;
  output G426, G427, G428, G429, G430, G431, G432;
  wire new_n44_, new_n45_, new_n46_, new_n47_, new_n48_, new_n49_, new_n50_,
    new_n51_, new_n52_, new_n53_, new_n54_, new_n55_, new_n56_, new_n57_,
    new_n58_, new_n59_, new_n60_, new_n61_, new_n62_, new_n63_, new_n64_,
    new_n65_, new_n66_, new_n67_, new_n68_, new_n69_, new_n70_, new_n71_,
    new_n72_, new_n73_, new_n74_, new_n75_, new_n77_, new_n78_, new_n79_,
    new_n80_, new_n81_, new_n82_, new_n83_, new_n84_, new_n85_, new_n86_,
    new_n87_, new_n88_, new_n89_, new_n90_, new_n91_, new_n92_, new_n93_,
    new_n94_, new_n95_, new_n96_, new_n97_, new_n98_, new_n99_, new_n100_,
    new_n101_, new_n102_, new_n103_, new_n104_, new_n105_, new_n106_,
    new_n107_, new_n108_, new_n109_, new_n110_, new_n111_, new_n112_,
    new_n113_, new_n114_, new_n115_, new_n116_, new_n117_, new_n118_,
    new_n120_, new_n121_, new_n122_, new_n123_, new_n124_, new_n125_,
    new_n126_, new_n127_, new_n128_, new_n129_, new_n130_, new_n131_,
    new_n132_, new_n133_, new_n134_, new_n135_, new_n136_, new_n137_,
    new_n138_, new_n139_, new_n140_, new_n141_, new_n142_, new_n143_,
    new_n144_, new_n145_, new_n146_, new_n147_, new_n148_, new_n149_,
    new_n150_, new_n151_, new_n152_, new_n153_, new_n154_, new_n155_,
    new_n156_, new_n157_, new_n158_, new_n159_, new_n160_, new_n161_,
    new_n162_, new_n163_, new_n164_, new_n165_, new_n166_, new_n167_,
    new_n168_, new_n169_, new_n170_, new_n171_, new_n172_, new_n173_,
    new_n174_, new_n175_, new_n176_, new_n177_, new_n178_, new_n180_,
    new_n181_, new_n182_, new_n183_, new_n184_, new_n185_, new_n186_,
    new_n187_, new_n188_, new_n189_, new_n190_, new_n191_, new_n192_,
    new_n193_, new_n194_, new_n195_, new_n196_, new_n197_, new_n198_,
    new_n199_, new_n200_, new_n201_, new_n202_, new_n203_, new_n204_,
    new_n205_, new_n206_, new_n207_, new_n208_, new_n209_, new_n210_,
    new_n211_, new_n212_, new_n213_, new_n214_, new_n215_, new_n216_,
    new_n217_, new_n218_, new_n219_, new_n220_, new_n222_, new_n223_,
    new_n224_, new_n225_, new_n227_, new_n228_, new_n229_, new_n230_,
    new_n231_, new_n232_, new_n233_, new_n234_, new_n236_, new_n237_,
    new_n238_, new_n239_, new_n240_;
  INVx1_ASAP7_75t_R   g000(.A(G34), .Y(new_n44_));
  INVx1_ASAP7_75t_R   g001(.A(G30), .Y(new_n45_));
  INVx1_ASAP7_75t_R   g002(.A(G26), .Y(new_n46_));
  INVx1_ASAP7_75t_R   g003(.A(G20), .Y(new_n47_));
  INVx1_ASAP7_75t_R   g004(.A(G22), .Y(new_n48_));
  INVx1_ASAP7_75t_R   g005(.A(G16), .Y(new_n49_));
  INVx1_ASAP7_75t_R   g006(.A(G18), .Y(new_n50_));
  INVx1_ASAP7_75t_R   g007(.A(G12), .Y(new_n51_));
  INVx1_ASAP7_75t_R   g008(.A(G14), .Y(new_n52_));
  INVx1_ASAP7_75t_R   g009(.A(G8), .Y(new_n53_));
  INVx1_ASAP7_75t_R   g010(.A(G10), .Y(new_n54_));
  INVx1_ASAP7_75t_R   g011(.A(G6), .Y(new_n55_));
  INVx1_ASAP7_75t_R   g012(.A(G1), .Y(new_n56_));
  INVx1_ASAP7_75t_R   g013(.A(G2), .Y(new_n57_));
  INVx1_ASAP7_75t_R   g014(.A(G35), .Y(new_n58_));
  INVx1_ASAP7_75t_R   g015(.A(G15), .Y(new_n59_));
  INVx1_ASAP7_75t_R   g016(.A(G32), .Y(new_n60_));
  NOR2x1_ASAP7_75t_R  g017(.A(G12), .B(new_n52_), .Y(new_n61_));
  NOR2x1_ASAP7_75t_R  g018(.A(G16), .B(new_n50_), .Y(new_n62_));
  INVx1_ASAP7_75t_R   g019(.A(new_n62_), .Y(new_n63_));
  AO21x1_ASAP7_75t_R  g020(.A1(new_n51_), .A2(G14), .B(new_n62_), .Y(new_n64_));
  AO21x1_ASAP7_75t_R  g021(.A1(new_n53_), .A2(G10), .B(new_n64_), .Y(new_n65_));
  NOR2x1_ASAP7_75t_R  g022(.A(G4), .B(new_n55_), .Y(new_n66_));
  AO21x1_ASAP7_75t_R  g023(.A1(new_n56_), .A2(G2), .B(new_n66_), .Y(new_n67_));
  NOR2x1_ASAP7_75t_R  g024(.A(G20), .B(new_n48_), .Y(new_n68_));
  NAND2x1_ASAP7_75t_R g025(.A(G34), .B(new_n60_), .Y(new_n69_));
  NOR2x1_ASAP7_75t_R  g026(.A(G28), .B(new_n45_), .Y(new_n70_));
  INVx1_ASAP7_75t_R   g027(.A(new_n70_), .Y(new_n71_));
  AO21x1_ASAP7_75t_R  g028(.A1(G34), .A2(new_n60_), .B(new_n70_), .Y(new_n72_));
  NOR2x1_ASAP7_75t_R  g029(.A(G24), .B(new_n46_), .Y(new_n73_));
  INVx1_ASAP7_75t_R   g030(.A(new_n73_), .Y(new_n74_));
  OR3x1_ASAP7_75t_R   g031(.A(new_n72_), .B(new_n73_), .C(new_n68_), .Y(new_n75_));
  OR3x1_ASAP7_75t_R   g032(.A(new_n67_), .B(new_n75_), .C(new_n65_), .Y(G426));
  INVx1_ASAP7_75t_R   g033(.A(G426), .Y(new_n77_));
  AO21x1_ASAP7_75t_R  g034(.A1(new_n47_), .A2(G22), .B(new_n73_), .Y(new_n78_));
  AO21x1_ASAP7_75t_R  g035(.A1(new_n51_), .A2(G14), .B(new_n67_), .Y(new_n79_));
  AO21x1_ASAP7_75t_R  g036(.A1(new_n53_), .A2(G10), .B(new_n79_), .Y(new_n80_));
  AO21x1_ASAP7_75t_R  g037(.A1(new_n49_), .A2(G18), .B(new_n80_), .Y(new_n81_));
  OR3x1_ASAP7_75t_R   g038(.A(new_n72_), .B(new_n81_), .C(new_n78_), .Y(new_n82_));
  INVx1_ASAP7_75t_R   g039(.A(new_n82_), .Y(new_n83_));
  AND2x2_ASAP7_75t_R  g040(.A(new_n69_), .B(new_n82_), .Y(new_n84_));
  OR3x1_ASAP7_75t_R   g041(.A(G35), .B(new_n84_), .C(new_n44_), .Y(new_n85_));
  OR3x1_ASAP7_75t_R   g042(.A(new_n70_), .B(new_n73_), .C(new_n68_), .Y(new_n86_));
  OR3x1_ASAP7_75t_R   g043(.A(new_n72_), .B(new_n86_), .C(new_n81_), .Y(new_n87_));
  AND2x2_ASAP7_75t_R  g044(.A(new_n71_), .B(new_n87_), .Y(new_n88_));
  OR3x1_ASAP7_75t_R   g045(.A(new_n45_), .B(G31), .C(new_n88_), .Y(new_n89_));
  OA21x2_ASAP7_75t_R  g046(.A1(new_n73_), .A2(new_n82_), .B(new_n74_), .Y(new_n90_));
  OR3x1_ASAP7_75t_R   g047(.A(G27), .B(new_n90_), .C(new_n46_), .Y(new_n91_));
  AND3x1_ASAP7_75t_R  g048(.A(new_n89_), .B(new_n91_), .C(new_n85_), .Y(new_n92_));
  NOR2x1_ASAP7_75t_R  g049(.A(new_n68_), .B(new_n83_), .Y(new_n93_));
  OR3x1_ASAP7_75t_R   g050(.A(new_n48_), .B(G23), .C(new_n93_), .Y(new_n94_));
  OR3x1_ASAP7_75t_R   g051(.A(new_n62_), .B(new_n75_), .C(new_n81_), .Y(new_n95_));
  AND2x2_ASAP7_75t_R  g052(.A(new_n63_), .B(new_n95_), .Y(new_n96_));
  OR3x1_ASAP7_75t_R   g053(.A(new_n50_), .B(G19), .C(new_n96_), .Y(new_n97_));
  OR3x1_ASAP7_75t_R   g054(.A(G12), .B(new_n83_), .C(new_n52_), .Y(new_n98_));
  OR3x1_ASAP7_75t_R   g055(.A(new_n72_), .B(new_n73_), .C(new_n61_), .Y(new_n99_));
  AO21x1_ASAP7_75t_R  g056(.A1(new_n53_), .A2(G10), .B(new_n67_), .Y(new_n100_));
  OR3x1_ASAP7_75t_R   g057(.A(new_n68_), .B(new_n99_), .C(new_n100_), .Y(new_n101_));
  OA21x2_ASAP7_75t_R  g058(.A1(new_n64_), .A2(new_n101_), .B(new_n98_), .Y(new_n102_));
  OR3x1_ASAP7_75t_R   g059(.A(new_n52_), .B(G15), .C(new_n102_), .Y(new_n103_));
  INVx1_ASAP7_75t_R   g060(.A(new_n103_), .Y(new_n104_));
  OA21x2_ASAP7_75t_R  g061(.A1(G8), .A2(new_n54_), .B(new_n82_), .Y(new_n105_));
  OR3x1_ASAP7_75t_R   g062(.A(new_n54_), .B(new_n105_), .C(G11), .Y(new_n106_));
  INVx1_ASAP7_75t_R   g063(.A(new_n106_), .Y(new_n107_));
  NOR2x1_ASAP7_75t_R  g064(.A(new_n57_), .B(G3), .Y(new_n108_));
  AO21x1_ASAP7_75t_R  g065(.A1(new_n56_), .A2(G2), .B(new_n77_), .Y(new_n109_));
  NAND2x1_ASAP7_75t_R g066(.A(new_n66_), .B(new_n82_), .Y(new_n110_));
  OR3x1_ASAP7_75t_R   g067(.A(new_n66_), .B(new_n75_), .C(new_n100_), .Y(new_n111_));
  OA21x2_ASAP7_75t_R  g068(.A1(new_n64_), .A2(new_n111_), .B(new_n110_), .Y(new_n112_));
  OR3x1_ASAP7_75t_R   g069(.A(new_n55_), .B(G7), .C(new_n112_), .Y(new_n113_));
  INVx1_ASAP7_75t_R   g070(.A(new_n113_), .Y(new_n114_));
  AO21x1_ASAP7_75t_R  g071(.A1(new_n108_), .A2(new_n109_), .B(new_n114_), .Y(new_n115_));
  NOR2x1_ASAP7_75t_R  g072(.A(new_n107_), .B(new_n115_), .Y(new_n116_));
  AND3x1_ASAP7_75t_R  g073(.A(new_n103_), .B(new_n116_), .C(new_n97_), .Y(new_n117_));
  AND3x1_ASAP7_75t_R  g074(.A(new_n94_), .B(new_n117_), .C(new_n92_), .Y(new_n118_));
  INVx1_ASAP7_75t_R   g075(.A(new_n118_), .Y(G427));
  OR3x1_ASAP7_75t_R   g076(.A(new_n48_), .B(new_n93_), .C(G23), .Y(new_n120_));
  OR3x1_ASAP7_75t_R   g077(.A(new_n73_), .B(new_n75_), .C(new_n64_), .Y(new_n121_));
  OA21x2_ASAP7_75t_R  g078(.A1(new_n100_), .A2(new_n121_), .B(new_n74_), .Y(new_n122_));
  OR3x1_ASAP7_75t_R   g079(.A(G27), .B(new_n122_), .C(new_n46_), .Y(new_n123_));
  INVx1_ASAP7_75t_R   g080(.A(new_n123_), .Y(new_n124_));
  OR3x1_ASAP7_75t_R   g081(.A(new_n65_), .B(new_n67_), .C(new_n70_), .Y(new_n125_));
  OA21x2_ASAP7_75t_R  g082(.A1(new_n75_), .A2(new_n125_), .B(new_n71_), .Y(new_n126_));
  OR3x1_ASAP7_75t_R   g083(.A(new_n45_), .B(G31), .C(new_n126_), .Y(new_n127_));
  INVx1_ASAP7_75t_R   g084(.A(new_n127_), .Y(new_n128_));
  AOI21x1_ASAP7_75t_R g085(.A1(new_n69_), .A2(G426), .B(new_n44_), .Y(new_n129_));
  AO21x1_ASAP7_75t_R  g086(.A1(new_n58_), .A2(new_n129_), .B(new_n128_), .Y(new_n130_));
  NOR2x1_ASAP7_75t_R  g087(.A(new_n124_), .B(new_n130_), .Y(new_n131_));
  OA21x2_ASAP7_75t_R  g088(.A1(new_n62_), .A2(G426), .B(new_n63_), .Y(new_n132_));
  OR3x1_ASAP7_75t_R   g089(.A(new_n50_), .B(new_n132_), .C(G19), .Y(new_n133_));
  INVx1_ASAP7_75t_R   g090(.A(new_n133_), .Y(new_n134_));
  OR3x1_ASAP7_75t_R   g091(.A(new_n104_), .B(new_n134_), .C(new_n115_), .Y(new_n135_));
  NOR2x1_ASAP7_75t_R  g092(.A(new_n107_), .B(new_n135_), .Y(new_n136_));
  INVx1_ASAP7_75t_R   g093(.A(new_n136_), .Y(new_n137_));
  AND3x1_ASAP7_75t_R  g094(.A(new_n131_), .B(new_n136_), .C(new_n120_), .Y(new_n138_));
  INVx1_ASAP7_75t_R   g095(.A(new_n138_), .Y(new_n139_));
  OR3x1_ASAP7_75t_R   g096(.A(G25), .B(new_n93_), .C(new_n48_), .Y(new_n140_));
  AOI21x1_ASAP7_75t_R g097(.A1(new_n94_), .A2(new_n139_), .B(new_n140_), .Y(new_n141_));
  OAI21x1_ASAP7_75t_R g098(.A1(new_n124_), .A2(new_n139_), .B(new_n91_), .Y(new_n142_));
  OR3x1_ASAP7_75t_R   g099(.A(new_n46_), .B(new_n90_), .C(G29), .Y(new_n143_));
  INVx1_ASAP7_75t_R   g100(.A(new_n143_), .Y(new_n144_));
  AO21x1_ASAP7_75t_R  g101(.A1(new_n142_), .A2(new_n144_), .B(new_n141_), .Y(new_n145_));
  AO21x1_ASAP7_75t_R  g102(.A1(new_n85_), .A2(new_n139_), .B(new_n84_), .Y(new_n146_));
  OR3x1_ASAP7_75t_R   g103(.A(new_n44_), .B(G36), .C(new_n146_), .Y(new_n147_));
  NAND2x1_ASAP7_75t_R g104(.A(new_n120_), .B(new_n123_), .Y(new_n148_));
  OR2x4_ASAP7_75t_R   g105(.A(new_n130_), .B(new_n148_), .Y(new_n149_));
  OR3x1_ASAP7_75t_R   g106(.A(new_n128_), .B(new_n137_), .C(new_n149_), .Y(new_n150_));
  OR3x1_ASAP7_75t_R   g107(.A(new_n45_), .B(G33), .C(new_n88_), .Y(new_n151_));
  AO21x1_ASAP7_75t_R  g108(.A1(new_n89_), .A2(new_n150_), .B(new_n151_), .Y(new_n152_));
  NAND2x1_ASAP7_75t_R g109(.A(new_n147_), .B(new_n152_), .Y(new_n153_));
  OR3x1_ASAP7_75t_R   g110(.A(new_n61_), .B(new_n75_), .C(new_n81_), .Y(new_n154_));
  AO21x1_ASAP7_75t_R  g111(.A1(new_n98_), .A2(new_n154_), .B(G17), .Y(new_n155_));
  NOR2x1_ASAP7_75t_R  g112(.A(new_n102_), .B(new_n138_), .Y(new_n156_));
  AND3x1_ASAP7_75t_R  g113(.A(G14), .B(new_n59_), .C(new_n156_), .Y(new_n157_));
  AOI21x1_ASAP7_75t_R g114(.A1(new_n103_), .A2(new_n138_), .B(new_n157_), .Y(new_n158_));
  OR3x1_ASAP7_75t_R   g115(.A(new_n52_), .B(new_n155_), .C(new_n158_), .Y(new_n159_));
  OA21x2_ASAP7_75t_R  g116(.A1(new_n134_), .A2(new_n139_), .B(new_n97_), .Y(new_n160_));
  OR3x1_ASAP7_75t_R   g117(.A(new_n50_), .B(new_n96_), .C(new_n160_), .Y(new_n161_));
  OAI21x1_ASAP7_75t_R g118(.A1(G21), .A2(new_n161_), .B(new_n159_), .Y(new_n162_));
  OR3x1_ASAP7_75t_R   g119(.A(G11), .B(new_n105_), .C(new_n54_), .Y(new_n163_));
  OR3x1_ASAP7_75t_R   g120(.A(new_n54_), .B(G13), .C(new_n105_), .Y(new_n164_));
  AO21x1_ASAP7_75t_R  g121(.A1(new_n139_), .A2(new_n163_), .B(new_n164_), .Y(new_n165_));
  OR3x1_ASAP7_75t_R   g122(.A(new_n78_), .B(new_n81_), .C(new_n66_), .Y(new_n166_));
  OA21x2_ASAP7_75t_R  g123(.A1(new_n72_), .A2(new_n166_), .B(new_n110_), .Y(new_n167_));
  OR3x1_ASAP7_75t_R   g124(.A(new_n114_), .B(new_n148_), .C(new_n130_), .Y(new_n168_));
  NOR2x1_ASAP7_75t_R  g125(.A(new_n137_), .B(new_n168_), .Y(new_n169_));
  AOI21x1_ASAP7_75t_R g126(.A1(new_n114_), .A2(new_n139_), .B(new_n169_), .Y(new_n170_));
  OR3x1_ASAP7_75t_R   g127(.A(new_n167_), .B(new_n170_), .C(new_n55_), .Y(new_n171_));
  OAI21x1_ASAP7_75t_R g128(.A1(G9), .A2(new_n171_), .B(new_n165_), .Y(new_n172_));
  OA21x2_ASAP7_75t_R  g129(.A1(G1), .A2(new_n57_), .B(new_n82_), .Y(new_n173_));
  OR3x1_ASAP7_75t_R   g130(.A(new_n57_), .B(G3), .C(new_n173_), .Y(new_n174_));
  AO21x1_ASAP7_75t_R  g131(.A1(new_n139_), .A2(new_n174_), .B(G5), .Y(new_n175_));
  OR3x1_ASAP7_75t_R   g132(.A(new_n57_), .B(new_n173_), .C(new_n175_), .Y(new_n176_));
  INVx1_ASAP7_75t_R   g133(.A(new_n176_), .Y(new_n177_));
  OR3x1_ASAP7_75t_R   g134(.A(new_n172_), .B(new_n177_), .C(new_n162_), .Y(new_n178_));
  OR3x1_ASAP7_75t_R   g135(.A(new_n153_), .B(new_n178_), .C(new_n145_), .Y(G428));
  AND2x2_ASAP7_75t_R  g136(.A(G7), .B(G427), .Y(new_n180_));
  AO21x1_ASAP7_75t_R  g137(.A1(G9), .A2(G428), .B(new_n180_), .Y(new_n181_));
  AO21x1_ASAP7_75t_R  g138(.A1(G4), .A2(G426), .B(new_n181_), .Y(new_n182_));
  NOR2x1_ASAP7_75t_R  g139(.A(new_n55_), .B(new_n182_), .Y(new_n183_));
  AND2x2_ASAP7_75t_R  g140(.A(G11), .B(G427), .Y(new_n184_));
  AO21x1_ASAP7_75t_R  g141(.A1(G8), .A2(G426), .B(new_n184_), .Y(new_n185_));
  AND2x2_ASAP7_75t_R  g142(.A(G13), .B(G428), .Y(new_n186_));
  OR3x1_ASAP7_75t_R   g143(.A(new_n185_), .B(new_n186_), .C(new_n54_), .Y(new_n187_));
  OAI21x1_ASAP7_75t_R g144(.A1(new_n55_), .A2(new_n182_), .B(new_n187_), .Y(new_n188_));
  NOR2x1_ASAP7_75t_R  g145(.A(new_n49_), .B(new_n77_), .Y(new_n189_));
  AO21x1_ASAP7_75t_R  g146(.A1(G19), .A2(G427), .B(new_n189_), .Y(new_n190_));
  AND2x2_ASAP7_75t_R  g147(.A(G21), .B(G428), .Y(new_n191_));
  OR3x1_ASAP7_75t_R   g148(.A(new_n190_), .B(new_n191_), .C(new_n50_), .Y(new_n192_));
  INVx1_ASAP7_75t_R   g149(.A(new_n192_), .Y(new_n193_));
  AND2x2_ASAP7_75t_R  g150(.A(G17), .B(G428), .Y(new_n194_));
  NOR2x1_ASAP7_75t_R  g151(.A(new_n59_), .B(new_n118_), .Y(new_n195_));
  AO21x1_ASAP7_75t_R  g152(.A1(G12), .A2(G426), .B(new_n195_), .Y(new_n196_));
  AO21x1_ASAP7_75t_R  g153(.A1(G17), .A2(G428), .B(new_n196_), .Y(new_n197_));
  INVx1_ASAP7_75t_R   g154(.A(new_n197_), .Y(new_n198_));
  NOR2x1_ASAP7_75t_R  g155(.A(new_n52_), .B(new_n197_), .Y(new_n199_));
  OR3x1_ASAP7_75t_R   g156(.A(new_n193_), .B(new_n199_), .C(new_n188_), .Y(new_n200_));
  INVx1_ASAP7_75t_R   g157(.A(new_n200_), .Y(new_n201_));
  AND2x2_ASAP7_75t_R  g158(.A(G24), .B(G426), .Y(new_n202_));
  AO21x1_ASAP7_75t_R  g159(.A1(G27), .A2(G427), .B(new_n202_), .Y(new_n203_));
  AND2x2_ASAP7_75t_R  g160(.A(G29), .B(G428), .Y(new_n204_));
  OR3x1_ASAP7_75t_R   g161(.A(new_n203_), .B(new_n204_), .C(new_n46_), .Y(new_n205_));
  NOR2x1_ASAP7_75t_R  g162(.A(new_n47_), .B(new_n77_), .Y(new_n206_));
  AO21x1_ASAP7_75t_R  g163(.A1(G23), .A2(G427), .B(new_n206_), .Y(new_n207_));
  AO21x1_ASAP7_75t_R  g164(.A1(G25), .A2(G428), .B(new_n207_), .Y(new_n208_));
  OAI21x1_ASAP7_75t_R g165(.A1(new_n48_), .A2(new_n208_), .B(new_n205_), .Y(new_n209_));
  NOR2x1_ASAP7_75t_R  g166(.A(new_n58_), .B(new_n118_), .Y(new_n210_));
  AO21x1_ASAP7_75t_R  g167(.A1(G32), .A2(G426), .B(new_n210_), .Y(new_n211_));
  AOI21x1_ASAP7_75t_R g168(.A1(G36), .A2(G428), .B(new_n211_), .Y(new_n212_));
  AOI21x1_ASAP7_75t_R g169(.A1(G34), .A2(new_n212_), .B(new_n209_), .Y(new_n213_));
  AND2x2_ASAP7_75t_R  g170(.A(G28), .B(G426), .Y(new_n214_));
  AO21x1_ASAP7_75t_R  g171(.A1(G31), .A2(G427), .B(new_n214_), .Y(new_n215_));
  AO21x1_ASAP7_75t_R  g172(.A1(G33), .A2(G428), .B(new_n215_), .Y(new_n216_));
  OA21x2_ASAP7_75t_R  g173(.A1(new_n45_), .A2(new_n216_), .B(new_n213_), .Y(new_n217_));
  AO21x1_ASAP7_75t_R  g174(.A1(G1), .A2(G426), .B(new_n57_), .Y(new_n218_));
  AO21x1_ASAP7_75t_R  g175(.A1(G3), .A2(G427), .B(new_n218_), .Y(new_n219_));
  AOI21x1_ASAP7_75t_R g176(.A1(G5), .A2(G428), .B(new_n219_), .Y(new_n220_));
  AOI21x1_ASAP7_75t_R g177(.A1(new_n201_), .A2(new_n217_), .B(new_n220_), .Y(G429));
  AO21x1_ASAP7_75t_R  g178(.A1(G13), .A2(G428), .B(new_n54_), .Y(new_n222_));
  AO21x1_ASAP7_75t_R  g179(.A1(G8), .A2(G426), .B(new_n222_), .Y(new_n223_));
  AO21x1_ASAP7_75t_R  g180(.A1(G11), .A2(G427), .B(new_n223_), .Y(new_n224_));
  AND3x1_ASAP7_75t_R  g181(.A(G14), .B(new_n224_), .C(new_n198_), .Y(new_n225_));
  OR3x1_ASAP7_75t_R   g182(.A(new_n188_), .B(new_n225_), .C(new_n193_), .Y(G430));
  OR3x1_ASAP7_75t_R   g183(.A(new_n52_), .B(new_n194_), .C(new_n196_), .Y(new_n227_));
  OR3x1_ASAP7_75t_R   g184(.A(new_n50_), .B(new_n190_), .C(new_n191_), .Y(new_n228_));
  INVx1_ASAP7_75t_R   g185(.A(new_n228_), .Y(new_n229_));
  NOR2x1_ASAP7_75t_R  g186(.A(new_n205_), .B(new_n229_), .Y(new_n230_));
  OR3x1_ASAP7_75t_R   g187(.A(new_n48_), .B(new_n229_), .C(new_n208_), .Y(new_n231_));
  INVx1_ASAP7_75t_R   g188(.A(new_n231_), .Y(new_n232_));
  AO21x1_ASAP7_75t_R  g189(.A1(new_n224_), .A2(new_n232_), .B(new_n230_), .Y(new_n233_));
  AOI21x1_ASAP7_75t_R g190(.A1(new_n227_), .A2(new_n233_), .B(new_n183_), .Y(new_n234_));
  NAND2x1_ASAP7_75t_R g191(.A(new_n187_), .B(new_n234_), .Y(G431));
  OR3x1_ASAP7_75t_R   g192(.A(new_n46_), .B(new_n204_), .C(new_n203_), .Y(new_n236_));
  INVx1_ASAP7_75t_R   g193(.A(new_n236_), .Y(new_n237_));
  OR3x1_ASAP7_75t_R   g194(.A(new_n45_), .B(new_n237_), .C(new_n216_), .Y(new_n238_));
  NAND2x1_ASAP7_75t_R g195(.A(new_n231_), .B(new_n238_), .Y(new_n239_));
  AO21x1_ASAP7_75t_R  g196(.A1(new_n227_), .A2(new_n239_), .B(new_n199_), .Y(new_n240_));
  AO21x1_ASAP7_75t_R  g197(.A1(new_n224_), .A2(new_n240_), .B(new_n183_), .Y(G432));
endmodule


