Three-part evaluation of progressive profile extraction and physical phase reuse

Original reference: results_v20_three_parts_chain. All sixteen raw AIGs, full/restricted genlibs, ABC binary and database are frozen and checked byte-for-byte. Initial direct/full-preprocessed mapped netlists are checked against the original archive. The AIG preprocessing recipe and stopping criterion are unchanged.

Common objective: minimum area under each initial mapping's fixed worst-output delay, with delay as an area-tie secondary objective. Whole-window synthesis, unmap/remap exploration, nonlocal dependency cuts, global divisor search and observability-care experiments remain disabled. All post-mapping configurations and fresh ABC mfs3 jobs have a 1000 s limit. An outer 3600 s guard covers preprocessing and validation; it does not extend the optimizer deadline.

Part 1: direct initial mapping, both tools use the same <=6-input subset, one post-mapping pass. The restriction comes from this mfs3 implementation. Fresh ABC jobs are executed in cold and reused by warm only after matching initial netlists, library and executable. Raw ABC outputs and external guarded selection are reported separately.
Part 2: unchanged high_effort AIG preprocessing, full original library, identical initial netlists for one-round and six-round-cap runs. ASPDAC'25 remains a published contextual comparison because its implementation is unavailable.
Part 3: all sixteen circuits, six-round cap, full/noSYN/noEGG/noDB/noCARE/noCHAIN/noSHARE/noNARROW/noPHASE. noNARROW removes only the width-1 initialization, retaining the profile's 20,000-combination / 4,000-visit caps. noPHASE removes only physical opposite-phase reuse, retaining polarity-aware matching. Results are marginal and not additive contributions.

Cold: each stage/arm/design starts with its own absent candidate-cache directory. Warm waits for that exact cold result and provenance, then reuses only that directory. Other in-process memo tables start fresh. Narrow mode is part of the cache key; physical emission is checked by the caller and does not change the intrinsic pool. Every completed output requires CEC and independent native/serialized PPA auditing. Cache construction/loading counts toward optimizer time. Operating-system caches are not cleared. Each mode is one shared-host observation; times are not statistically controlled speedup measurements.

Plan: execution_plan.json. Full row count: 416 engine invocations including 32 initial-only rows, 384 method runs (192 per mode), plus sixteen fresh ABC jobs. Up to eight native workers per cohort and eight independent ABC workers. Runs are archived under cold/ and warm/, with binary/source/input hashes in each manifest and pool provenance for each method row.

Monitoring:
  python3 results_v25_three_parts_progressive_phase/check_progress.py
Complete audit and paper export:
  python3 scripts/experiments/report_three_parts_profiles.py --root results_v25_three_parts_progressive_phase --out epmapping_paper/DATE27-ePMapping-sub/doc/generated_results.tex
Figures and compilation:
  make -C epmapping_paper/DATE27-ePMapping-sub all

The final publication is delivered only after the complete paired audit, seven-page (6+1) compilation and page-image inspection. Draft source edits or partial rows are not published results. Unit-test fixtures and native regression scripts are separately archived in validation_sources/.
