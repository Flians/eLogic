# Three-part constrained-area experiments

Every ePMapping output satisfies its own initial area/delay bounds and passes CEC.
ABC raw area-mode outputs are preserved. The guarded comparison reverts an infeasible completed output to its native initial mapping; it is an external output-selection policy, not an internal mfs3 timing constraint. Timeouts are excluded from paired means.

{
  "whole_window_synthesis": false,
  "engine_cec_outputs": 192,
  "baseline_cec_outputs": 16,
  "main_own_area": -4.6135958054638015,
  "main_own_delay": -6.3978129808716275,
  "main_one_area": -3.0295029572916548,
  "main_one_delay": -4.490312420034331,
  "main_other_area": -0.9277671522116641,
  "main_other_delay": -1.9004937470501715,
  "main_area_wins": 16,
  "reference_area": -6.736959480891769,
  "reference_delay": -5.843280262116793,
  "reference_wins": 14,
  "mfs_ours_area": -5.061526407257263,
  "mfs_ours_delay": -5.062489298052411,
  "abc_completed": 13,
  "abc_timeouts": 3,
  "abc_feasible": 6,
  "abc_delay_violations": 7,
  "cut_oracle_times": {
    "secs_stage1": 263.290801704,
    "secs_stage2": 104.577117525,
    "secs_synth": 773.4691270009998,
    "secs_egg": 389.78346280399995,
    "secs_care": 58.758443498000005,
    "secs_window": 0.0,
    "secs_chain": 0.252556571
  },
  "abc_raw_area": -3.575691302200082,
  "abc_guarded_area": -1.5940348664441888,
  "paired_ours_area": -5.032697480338651,
  "abc_raw_delay": 11.018744353868293,
  "abc_guarded_delay": -0.14558063949823968,
  "paired_ours_delay": -6.144396581965269,
  "paired_area_wins": 4,
  "guarded_paired_area_wins": 9,
  "ablation": {
    "full": {
      "area": 0.0,
      "worse": 0,
      "better": 0,
      "own_area": -4.6135958054638015,
      "own_delay": -6.3978129808716275,
      "optimizer_seconds": 1714.6754276729998,
      "time_ratio": 1.0
    },
    "noSYN": {
      "area": 116.87000000000015,
      "worse": 14,
      "better": 0,
      "own_area": -3.852288254582876,
      "own_delay": -5.473826518593026,
      "optimizer_seconds": 812.31721505,
      "time_ratio": 0.4737440112222302
    },
    "noEGG": {
      "area": 2.2600000000001934,
      "worse": 11,
      "better": 0,
      "own_area": -4.584210416922748,
      "own_delay": -6.357121810072237,
      "optimizer_seconds": 1266.4385107209998,
      "time_ratio": 0.7385878926600669
    },
    "noDB": {
      "area": 0.540000000000127,
      "worse": 6,
      "better": 3,
      "own_area": -4.608210337262232,
      "own_delay": -6.311764650646216,
      "optimizer_seconds": 1219.799639903,
      "time_ratio": 0.7113880680954298
    },
    "noCARE": {
      "area": 11.579999999999636,
      "worse": 13,
      "better": 0,
      "own_area": -4.523135245145923,
      "own_delay": -6.140957019617904,
      "optimizer_seconds": 1451.4492399000003,
      "time_ratio": 0.8464862891688919
    },
    "noCHAIN": {
      "area": 334.08000000000004,
      "worse": 1,
      "better": 0,
      "own_area": -0.8697817051984351,
      "own_delay": -1.7817128878595359,
      "optimizer_seconds": 1671.700949796,
      "time_ratio": 0.9749372521566249
    },
    "noSHARE": {
      "area": 334.08000000000004,
      "worse": 1,
      "better": 0,
      "own_area": -0.8697817051984351,
      "own_delay": -1.7817128878595359,
      "optimizer_seconds": 1701.5942701610004,
      "time_ratio": 0.992371059093235
    },
    "noNARROW": {
      "area": 0.38999999999992596,
      "worse": 7,
      "better": 1,
      "own_area": -4.595687189464878,
      "own_delay": -6.403613037468098,
      "optimizer_seconds": 2300.490666921,
      "time_ratio": 1.3416478884537435
    },
    "noPHASE": {
      "area": 0.7999999999998195,
      "worse": 6,
      "better": 0,
      "own_area": -4.598147514541707,
      "own_delay": -6.3978129808716275,
      "optimizer_seconds": 1700.2046436630003,
      "time_ratio": 0.991560627873674
    }
  },
  "chain_activity": {
    "aes_core": {
      "chain_wins": 0,
      "secs_chain": 0.0
    },
    "arbiter": {
      "chain_wins": 384,
      "secs_chain": 0.056573284
    },
    "div": {
      "chain_wins": 0,
      "secs_chain": 0.0
    },
    "ethernet": {
      "chain_wins": 0,
      "secs_chain": 0.0
    },
    "iwls05_i2c": {
      "chain_wins": 0,
      "secs_chain": 0.0
    },
    "mem_ctrl": {
      "chain_wins": 0,
      "secs_chain": 0.214627134
    },
    "RISC": {
      "chain_wins": 0,
      "secs_chain": 0.0
    },
    "sasc": {
      "chain_wins": 0,
      "secs_chain": 0.0
    },
    "simple_spi": {
      "chain_wins": 0,
      "secs_chain": 0.0
    },
    "spi": {
      "chain_wins": 0,
      "secs_chain": 0.0
    },
    "sqrt": {
      "chain_wins": 0,
      "secs_chain": 0.0
    },
    "systemcaes": {
      "chain_wins": 0,
      "secs_chain": 0.0
    },
    "systemcdes": {
      "chain_wins": 0,
      "secs_chain": 0.0
    },
    "tv80": {
      "chain_wins": 0,
      "secs_chain": 0.0
    },
    "usb_funct": {
      "chain_wins": 0,
      "secs_chain": 0.0
    },
    "usb_phy": {
      "chain_wins": 0,
      "secs_chain": 0.0
    }
  }
}

## Per-design fully preprocessed results

| Design | A0 | D0 | A | D | dA % | dD % |
| --- | --- | --- | --- | --- | --- | --- |
| aes_core | 1029.98 | 410.72 | 1010.14 | 410.72 | -1.93 | +0.00 |
| arbiter | 557.72 | 999.87 | 223.64 | 261.39 | -59.90 | -73.86 |
| div | 1184.5 | 53105.06 | 1183.21 | 53041.21 | -0.11 | -0.12 |
| ethernet | 2541.41 | 543.88 | 2539.28 | 540.76 | -0.08 | -0.57 |
| iwls05_i2c | 47.66 | 303.61 | 47.45 | 303.61 | -0.44 | +0.00 |
| mem_ctrl | 1895.4 | 1519.75 | 1879.09 | 1490.32 | -0.86 | -1.94 |
| RISC | 2927.19 | 1453.77 | 2917.74 | 1428.82 | -0.32 | -1.72 |
| sasc | 27.28 | 191.2 | 27.17 | 191.2 | -0.40 | +0.00 |
| simple_spi | 36.96 | 308.22 | 36.79 | 291.82 | -0.46 | -5.32 |
| spi | 149.43 | 500.98 | 149.3 | 480.72 | -0.09 | -4.04 |
| sqrt | 1157.38 | 88015.07 | 1094.63 | 81535.14 | -5.42 | -7.36 |
| systemcaes | 483.75 | 709.03 | 474.07 | 682.83 | -2.00 | -3.70 |
| systemcdes | 131.06 | 488.85 | 130.64 | 487.83 | -0.32 | -0.21 |
| tv80 | 340.61 | 846.12 | 338.81 | 846.12 | -0.53 | +0.00 |
| usb_funct | 646.23 | 668.08 | 641.8 | 663.36 | -0.69 | -0.71 |
| usb_phy | 22.54 | 163.29 | 22.48 | 158.68 | -0.27 | -2.82 |
