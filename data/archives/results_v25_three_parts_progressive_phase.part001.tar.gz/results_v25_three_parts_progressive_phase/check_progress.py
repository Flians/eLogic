import json,csv,hashlib,re,sys
from pathlib import Path
root=Path(__file__).resolve().parent;project=root.parent;sys.path.insert(0,str(project/'scripts/experiments'))
from audit_mapped_ppa import audit
saved=root/'partial_audit.json';checked=json.loads(saved.read_text()) if saved.exists() else {};status={}
for mode in ['cold','warm']:
 folder=root/mode;status[mode]={}
 for stage,total in [('tab_mfs3',32),('tab_main',32),('ablation',144)]:
  paths=sorted((folder/stage).glob('*/row.tsv'));status[mode][stage]=[len(paths),total]
  for p in paths:
   key=str(p.relative_to(root))
   if key in checked:continue
   fields=p.read_text().strip().split('\t');assert len(fields)==14,(p,fields)
   arm,d=fields[:2];assert fields[-1]=='0',(p,fields)
   if arm=='base':checked[key]={'base':True};continue
   assert fields[-3]=='1',(p,fields)
   log=(p.parent/'log').read_text();assert 'post_mapping_timeout=1000' in log and 'window_synth windows=0 applied=0' in log
   assert 'area_under_delay=1,' in log and 'path_objective=0,' in log
   assert f", phase_reuse={0 if arm=='noPHASE' else 1}," in log
   flags=(p.parent/'experiment_env.txt').read_text().splitlines()
   assert [s for s in flags if s.startswith('MAP_EGG_PROFILE_NARROW=')][-1]==f"MAP_EGG_PROFILE_NARROW={0 if arm=='noNARROW' else 1}"
   lib=folder/'inputs'/('asap7_6in.genlib' if stage=='tab_mfs3' else 'asap7.genlib')
   b=audit(p.parent/'epmapping_baseline.v',lib);a=audit(p.parent/'epmapping_mapped.v',lib)
   for cost in ['area','delay','serialized_area','serialized_delay']:assert a[cost]<=b[cost]+.001,(p,cost,b[cost],a[cost])
   t=float(re.search(r'epmapping timing .*optimizer=([\d.]+)',log)[1]);assert t<=1000.01,(p,t)
   checked[key]={'area':a['area'],'delay':a['delay'],'optimizer_seconds':t,'log_sha256':hashlib.sha256((p.parent/'log').read_bytes()).hexdigest()}
   other=str(Path('cold' if mode=='warm' else 'warm')/stage/p.parent.name/'row.tsv')
   if other in checked:assert abs(checked[other]['area']-a['area'])<.001 and abs(checked[other]['delay']-a['delay'])<.001,(p,checked[other],a)
abc=[json.loads(p.read_text()) for p in (root/'cold/tab_mfs3').glob('abc.*/result.json')];status['ABC']={'completed':sum(r['rc']==0 for r in abc),'timeout':sum(r['rc']==124 for r in abc),'pending':16-len(abc)}
saved.write_text(json.dumps(checked,indent=2)+'\n');print(json.dumps(status));print('Independently checked rows:',len(checked))
