"""Compile only a complete audited campaign; leave final visual QA to the caller."""
from pathlib import Path
import subprocess,time,json,re
root=Path(__file__).resolve().parent;project=root.parent
while True:
 ready=all(len(list((root/m/s).glob('*/row.tsv')))==n for m in ['cold','warm'] for s,n in [('tab_mfs3',32),('tab_main',32),('ablation',144)])
 ready=ready and all((root/m/'tab_mfs3/abc_results.json').exists() for m in ['cold','warm'])
 if ready:break
 for m in ['cold','warm']:
  log=(root/(m+'_execution.log')).read_text()
  if 'Traceback (most recent call last)' in log:raise RuntimeError(m+' runner failed; inspect execution log')
 time.sleep(30)
with (root/'paper_build.log').open('w') as stream:
 q=subprocess.run(['make','-C',str(project/'epmapping_paper/DATE27-ePMapping-sub'),'all','RESULTS='+root.name,'ENGINE=pdflatex -interaction=nonstopmode -halt-on-error'],cwd=project,stdout=stream,stderr=subprocess.STDOUT)
assert q.returncode==0,'Complete audit/figure/build failed; inspect paper_build.log'
pdf=project/'epmapping_paper/DATE27-ePMapping-sub/DATE27-ePMapping.pdf'
info=subprocess.check_output(['/usr/bin/pdfinfo',str(pdf)],text=True);pages=int(re.search(r'Pages:\s+(\d+)',info)[1]);assert pages==7,('Needs 6+1 layout repair',pages)
for p,word in [(6,'CONCLUSION'),(7,'REFERENCES')]:
 text=subprocess.check_output(['/usr/bin/pdftotext','-f',str(p),'-l',str(p),str(pdf),'-'],text=True)
 assert word in ''.join(text.split()),(p,word)
(root/'build_ready.json').write_text(json.dumps(dict(pages=pages,body_pages=6,reference_pages=1,visual_QA_pending=True,pdf=str(pdf)),indent=2)+'\n')
print('Complete paired audit and 6+1 build passed. Visual page inspection is still required.',flush=True)
