# Exact shared-source transaction hypothesis

Baseline inspiration: reference/dereference shared physical DAGs and backward required times, from `tools/mockturtle/include/mockturtle/algorithms/emap.hpp` (read only). Apply the sharing principle to eGraphMap source representation BEFORE graph admission, not by changing any original baseline. The native source importer only admits exact library-supported source-function cuts. All retained nodes still count cumulatively in one global egraph.

Hypothesis: single-source non-increasing transactions get stuck when switching either of two same-rank users costs one extra live function, but switching both releases two old shared functions. Test a deterministic seven-node reference DAG, then compare against independent full reachability. Same-rank partners ensure neither changed root depends on the other. Only existing candidate truth tables are used; no additional Boolean queries or cut-bank capacity. A bounded pair search must stay in the original native/mapping clock. No feasibility/PPA/CEC claim from this structural kernel alone.

This is independent of V11 signed-source normalization and is NOT a production change. Mandatory source nodes, PIs, and demanded output phases must all be admitted and measured. It may fail on div/hyp/mem_ctrl; estimates cannot establish impossibility or a mapping gain.
