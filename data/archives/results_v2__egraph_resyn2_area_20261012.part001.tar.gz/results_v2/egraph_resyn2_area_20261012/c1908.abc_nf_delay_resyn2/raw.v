// Benchmark "/home/flynn/workplace/MIGBalance/results_v2/egraph_resyn2_area_20261012/c1908.resyn2" written by ABC on Mon Oct 12 13:18:33 2026

module \/home/flynn/workplace/MIGBalance/results_v2/egraph_resyn2_area_20261012/c1908.resyn2  ( 
    G23, G24, G33, G31, G30, G32, G8, G6, G3, G15, G10, G12, G19, G28, G9,
    G14, G16, G18, G11, G5, G2, G27, G7, G4, G20, G13, G1, G17, G26, G22,
    G25, G21, G29,
    G1899, G1884, G1885, G1898, G1886, G1887, G1888, G1889, G1890, G1891,
    G1892, G1893, G1894, G1895, G1896, G1897, G1900, G1901, G1902, G1903,
    G1904, G1905, G1906, G1907, G1908  );
  input  G23, G24, G33, G31, G30, G32, G8, G6, G3, G15, G10, G12, G19,
    G28, G9, G14, G16, G18, G11, G5, G2, G27, G7, G4, G20, G13, G1, G17,
    G26, G22, G25, G21, G29;
  output G1899, G1884, G1885, G1898, G1886, G1887, G1888, G1889, G1890, G1891,
    G1892, G1893, G1894, G1895, G1896, G1897, G1900, G1901, G1902, G1903,
    G1904, G1905, G1906, G1907, G1908;
  wire new_n59_, new_n60_, new_n61_, new_n62_, new_n63_, new_n64_, new_n65_,
    new_n66_, new_n67_, new_n68_, new_n69_, new_n70_, new_n71_, new_n72_,
    new_n73_, new_n74_, new_n75_, new_n76_, new_n77_, new_n78_, new_n79_,
    new_n80_, new_n81_, new_n82_, new_n83_, new_n84_, new_n85_, new_n86_,
    new_n87_, new_n88_, new_n89_, new_n90_, new_n91_, new_n92_, new_n93_,
    new_n94_, new_n95_, new_n96_, new_n97_, new_n98_, new_n99_, new_n100_,
    new_n101_, new_n102_, new_n103_, new_n104_, new_n105_, new_n106_,
    new_n107_, new_n108_, new_n109_, new_n110_, new_n111_, new_n112_,
    new_n113_, new_n114_, new_n115_, new_n116_, new_n117_, new_n118_,
    new_n119_, new_n120_, new_n121_, new_n122_, new_n123_, new_n124_,
    new_n125_, new_n126_, new_n127_, new_n128_, new_n129_, new_n130_,
    new_n131_, new_n132_, new_n133_, new_n134_, new_n135_, new_n136_,
    new_n137_, new_n138_, new_n139_, new_n140_, new_n141_, new_n142_,
    new_n143_, new_n144_, new_n145_, new_n146_, new_n147_, new_n148_,
    new_n149_, new_n150_, new_n151_, new_n152_, new_n153_, new_n154_,
    new_n155_, new_n156_, new_n157_, new_n158_, new_n159_, new_n160_,
    new_n161_, new_n162_, new_n163_, new_n164_, new_n165_, new_n166_,
    new_n167_, new_n168_, new_n169_, new_n170_, new_n171_, new_n172_,
    new_n173_, new_n174_, new_n175_, new_n176_, new_n177_, new_n178_,
    new_n179_, new_n180_, new_n181_, new_n182_, new_n183_, new_n184_,
    new_n185_, new_n187_, new_n188_, new_n189_, new_n190_, new_n191_,
    new_n192_, new_n193_, new_n199_, new_n203_, new_n204_, new_n205_,
    new_n210_, new_n214_, new_n215_, new_n216_, new_n217_, new_n218_,
    new_n219_, new_n220_, new_n221_, new_n223_, new_n224_, new_n226_,
    new_n227_, new_n229_, new_n230_, new_n232_, new_n233_, new_n235_,
    new_n236_, new_n238_, new_n239_, new_n240_, new_n241_, new_n242_,
    new_n243_, new_n244_, new_n246_, new_n247_, new_n248_, new_n249_,
    new_n250_, new_n251_, new_n252_, new_n253_, new_n254_, new_n256_,
    new_n257_;
  INVx1_ASAP7_75t_R   g000(.A(G23), .Y(new_n59_));
  INVx1_ASAP7_75t_R   g001(.A(G24), .Y(new_n60_));
  INVx1_ASAP7_75t_R   g002(.A(G33), .Y(new_n61_));
  INVx1_ASAP7_75t_R   g003(.A(G31), .Y(new_n62_));
  INVx1_ASAP7_75t_R   g004(.A(G10), .Y(new_n63_));
  INVx1_ASAP7_75t_R   g005(.A(G11), .Y(new_n64_));
  INVx1_ASAP7_75t_R   g006(.A(G5), .Y(new_n65_));
  INVx1_ASAP7_75t_R   g007(.A(G1), .Y(new_n66_));
  INVx1_ASAP7_75t_R   g008(.A(G25), .Y(new_n67_));
  NOR2x1_ASAP7_75t_R  g009(.A(G33), .B(G32), .Y(new_n68_));
  OA21x2_ASAP7_75t_R  g010(.A1(G23), .A2(new_n60_), .B(new_n68_), .Y(new_n69_));
  NOR2x1_ASAP7_75t_R  g011(.A(G33), .B(G30), .Y(new_n70_));
  INVx1_ASAP7_75t_R   g012(.A(new_n70_), .Y(new_n71_));
  OA21x2_ASAP7_75t_R  g013(.A1(new_n60_), .A2(G23), .B(new_n62_), .Y(new_n72_));
  AOI21x1_ASAP7_75t_R g014(.A1(new_n70_), .A2(new_n72_), .B(new_n69_), .Y(new_n73_));
  INVx1_ASAP7_75t_R   g015(.A(new_n73_), .Y(new_n74_));
  XOR2x2_ASAP7_75t_R  g016(.A(G15), .B(G11), .Y(new_n75_));
  XOR2x2_ASAP7_75t_R  g017(.A(G8), .B(G5), .Y(new_n76_));
  XOR2x2_ASAP7_75t_R  g018(.A(G2), .B(new_n76_), .Y(new_n77_));
  AND3x1_ASAP7_75t_R  g019(.A(new_n60_), .B(new_n61_), .C(G18), .Y(new_n78_));
  XOR2x2_ASAP7_75t_R  g020(.A(G9), .B(G14), .Y(new_n79_));
  XNOR2x2_ASAP7_75t_R g021(.A(G9), .B(G14), .Y(new_n80_));
  NOR2x1_ASAP7_75t_R  g022(.A(G16), .B(new_n79_), .Y(new_n81_));
  AND2x2_ASAP7_75t_R  g023(.A(G16), .B(new_n79_), .Y(new_n82_));
  OAI21x1_ASAP7_75t_R g024(.A1(new_n81_), .A2(new_n82_), .B(new_n78_), .Y(new_n83_));
  OR3x1_ASAP7_75t_R   g025(.A(new_n78_), .B(new_n81_), .C(new_n82_), .Y(new_n84_));
  AOI21x1_ASAP7_75t_R g026(.A1(new_n83_), .A2(new_n84_), .B(new_n77_), .Y(new_n85_));
  AND3x1_ASAP7_75t_R  g027(.A(new_n77_), .B(new_n83_), .C(new_n84_), .Y(new_n86_));
  NOR2x1_ASAP7_75t_R  g028(.A(new_n85_), .B(new_n86_), .Y(new_n87_));
  XOR2x2_ASAP7_75t_R  g029(.A(new_n75_), .B(new_n87_), .Y(new_n88_));
  OR3x1_ASAP7_75t_R   g030(.A(new_n88_), .B(G27), .C(G31), .Y(new_n89_));
  OAI21x1_ASAP7_75t_R g031(.A1(G31), .A2(new_n88_), .B(G27), .Y(new_n90_));
  XOR2x2_ASAP7_75t_R  g032(.A(G15), .B(G10), .Y(new_n91_));
  AND3x1_ASAP7_75t_R  g033(.A(new_n59_), .B(new_n61_), .C(G19), .Y(new_n92_));
  XNOR2x2_ASAP7_75t_R g034(.A(G8), .B(G6), .Y(new_n93_));
  XOR2x2_ASAP7_75t_R  g035(.A(G3), .B(G12), .Y(new_n94_));
  XOR2x2_ASAP7_75t_R  g036(.A(new_n93_), .B(new_n94_), .Y(new_n95_));
  XOR2x2_ASAP7_75t_R  g037(.A(new_n92_), .B(new_n95_), .Y(new_n96_));
  XOR2x2_ASAP7_75t_R  g038(.A(new_n91_), .B(new_n96_), .Y(new_n97_));
  OR3x1_ASAP7_75t_R   g039(.A(new_n97_), .B(G28), .C(G31), .Y(new_n98_));
  OAI21x1_ASAP7_75t_R g040(.A1(G31), .A2(new_n97_), .B(G28), .Y(new_n99_));
  AND3x1_ASAP7_75t_R  g041(.A(new_n90_), .B(new_n98_), .C(new_n99_), .Y(new_n100_));
  NAND2x1_ASAP7_75t_R g042(.A(new_n89_), .B(new_n100_), .Y(new_n101_));
  AND3x1_ASAP7_75t_R  g043(.A(new_n100_), .B(new_n89_), .C(new_n74_), .Y(new_n102_));
  OA21x2_ASAP7_75t_R  g044(.A1(G23), .A2(G31), .B(G20), .Y(new_n103_));
  XOR2x2_ASAP7_75t_R  g045(.A(G12), .B(G13), .Y(new_n104_));
  XNOR2x2_ASAP7_75t_R g046(.A(G15), .B(G16), .Y(new_n105_));
  XOR2x2_ASAP7_75t_R  g047(.A(G15), .B(G16), .Y(new_n106_));
  NAND2x1_ASAP7_75t_R g048(.A(G10), .B(new_n105_), .Y(new_n107_));
  NAND2x1_ASAP7_75t_R g049(.A(new_n63_), .B(new_n106_), .Y(new_n108_));
  XOR2x2_ASAP7_75t_R  g050(.A(G10), .B(new_n106_), .Y(new_n109_));
  AOI21x1_ASAP7_75t_R g051(.A1(new_n107_), .A2(new_n108_), .B(new_n64_), .Y(new_n110_));
  AND3x1_ASAP7_75t_R  g052(.A(new_n64_), .B(new_n107_), .C(new_n108_), .Y(new_n111_));
  OR3x1_ASAP7_75t_R   g053(.A(new_n111_), .B(new_n104_), .C(new_n110_), .Y(new_n112_));
  OAI21x1_ASAP7_75t_R g054(.A1(new_n110_), .A2(new_n111_), .B(new_n104_), .Y(new_n113_));
  AND2x2_ASAP7_75t_R  g055(.A(new_n112_), .B(new_n113_), .Y(new_n114_));
  XNOR2x2_ASAP7_75t_R g056(.A(G14), .B(G4), .Y(new_n115_));
  XNOR2x2_ASAP7_75t_R g057(.A(G3), .B(G2), .Y(new_n116_));
  XOR2x2_ASAP7_75t_R  g058(.A(G3), .B(G2), .Y(new_n117_));
  NOR2x1_ASAP7_75t_R  g059(.A(new_n66_), .B(new_n117_), .Y(new_n118_));
  NAND2x1_ASAP7_75t_R g060(.A(G1), .B(new_n116_), .Y(new_n119_));
  AND2x2_ASAP7_75t_R  g061(.A(new_n66_), .B(new_n117_), .Y(new_n120_));
  NAND2x1_ASAP7_75t_R g062(.A(new_n66_), .B(new_n117_), .Y(new_n121_));
  XOR2x2_ASAP7_75t_R  g063(.A(new_n66_), .B(new_n117_), .Y(new_n122_));
  NAND2x1_ASAP7_75t_R g064(.A(G22), .B(new_n61_), .Y(new_n123_));
  AND3x1_ASAP7_75t_R  g065(.A(new_n119_), .B(new_n121_), .C(new_n123_), .Y(new_n124_));
  AOI21x1_ASAP7_75t_R g066(.A1(new_n119_), .A2(new_n121_), .B(new_n123_), .Y(new_n125_));
  OAI21x1_ASAP7_75t_R g067(.A1(new_n124_), .A2(new_n125_), .B(new_n115_), .Y(new_n126_));
  OR3x1_ASAP7_75t_R   g068(.A(new_n115_), .B(new_n124_), .C(new_n125_), .Y(new_n127_));
  NAND2x1_ASAP7_75t_R g069(.A(new_n126_), .B(new_n127_), .Y(new_n128_));
  XOR2x2_ASAP7_75t_R  g070(.A(new_n114_), .B(new_n128_), .Y(new_n129_));
  AND3x1_ASAP7_75t_R  g071(.A(new_n62_), .B(new_n67_), .C(new_n129_), .Y(new_n130_));
  AOI21x1_ASAP7_75t_R g072(.A1(new_n62_), .A2(new_n129_), .B(new_n67_), .Y(new_n131_));
  NOR2x1_ASAP7_75t_R  g073(.A(new_n130_), .B(new_n131_), .Y(new_n132_));
  OAI21x1_ASAP7_75t_R g074(.A1(new_n130_), .A2(new_n131_), .B(new_n103_), .Y(new_n133_));
  AND3x1_ASAP7_75t_R  g075(.A(new_n60_), .B(new_n61_), .C(G17), .Y(new_n134_));
  XNOR2x2_ASAP7_75t_R g076(.A(G6), .B(G7), .Y(new_n135_));
  XOR2x2_ASAP7_75t_R  g077(.A(G6), .B(G7), .Y(new_n136_));
  NOR2x1_ASAP7_75t_R  g078(.A(new_n65_), .B(new_n136_), .Y(new_n137_));
  NAND2x1_ASAP7_75t_R g079(.A(G5), .B(new_n135_), .Y(new_n138_));
  AND2x2_ASAP7_75t_R  g080(.A(new_n65_), .B(new_n136_), .Y(new_n139_));
  NAND2x1_ASAP7_75t_R g081(.A(new_n65_), .B(new_n136_), .Y(new_n140_));
  XOR2x2_ASAP7_75t_R  g082(.A(new_n65_), .B(new_n136_), .Y(new_n141_));
  OA21x2_ASAP7_75t_R  g083(.A1(new_n137_), .A2(new_n139_), .B(G1), .Y(new_n142_));
  AND3x1_ASAP7_75t_R  g084(.A(new_n66_), .B(new_n138_), .C(new_n140_), .Y(new_n143_));
  OAI21x1_ASAP7_75t_R g085(.A1(new_n142_), .A2(new_n143_), .B(new_n134_), .Y(new_n144_));
  OR3x1_ASAP7_75t_R   g086(.A(new_n134_), .B(new_n142_), .C(new_n143_), .Y(new_n145_));
  NAND2x1_ASAP7_75t_R g087(.A(new_n144_), .B(new_n145_), .Y(new_n146_));
  XOR2x2_ASAP7_75t_R  g088(.A(new_n114_), .B(new_n146_), .Y(new_n147_));
  AOI21x1_ASAP7_75t_R g089(.A1(new_n62_), .A2(new_n147_), .B(G26), .Y(new_n148_));
  AND3x1_ASAP7_75t_R  g090(.A(new_n62_), .B(new_n147_), .C(G26), .Y(new_n149_));
  XOR2x2_ASAP7_75t_R  g091(.A(G10), .B(G7), .Y(new_n150_));
  AND3x1_ASAP7_75t_R  g092(.A(new_n59_), .B(new_n61_), .C(G20), .Y(new_n151_));
  XOR2x2_ASAP7_75t_R  g093(.A(G13), .B(new_n151_), .Y(new_n152_));
  OAI21x1_ASAP7_75t_R g094(.A1(new_n81_), .A2(new_n82_), .B(G4), .Y(new_n153_));
  OR3x1_ASAP7_75t_R   g095(.A(G4), .B(new_n81_), .C(new_n82_), .Y(new_n154_));
  AOI21x1_ASAP7_75t_R g096(.A1(new_n153_), .A2(new_n154_), .B(new_n152_), .Y(new_n155_));
  AND3x1_ASAP7_75t_R  g097(.A(new_n152_), .B(new_n153_), .C(new_n154_), .Y(new_n156_));
  OR3x1_ASAP7_75t_R   g098(.A(new_n156_), .B(new_n150_), .C(new_n155_), .Y(new_n157_));
  OAI21x1_ASAP7_75t_R g099(.A1(new_n155_), .A2(new_n156_), .B(new_n150_), .Y(new_n158_));
  AND2x2_ASAP7_75t_R  g100(.A(new_n157_), .B(new_n158_), .Y(new_n159_));
  AO21x1_ASAP7_75t_R  g101(.A1(new_n157_), .A2(new_n158_), .B(G31), .Y(new_n160_));
  OA21x2_ASAP7_75t_R  g102(.A1(G23), .A2(G31), .B(G19), .Y(new_n161_));
  XOR2x2_ASAP7_75t_R  g103(.A(new_n160_), .B(new_n161_), .Y(new_n162_));
  OA21x2_ASAP7_75t_R  g104(.A1(new_n148_), .A2(new_n149_), .B(new_n162_), .Y(new_n163_));
  OA21x2_ASAP7_75t_R  g105(.A1(G24), .A2(G31), .B(G18), .Y(new_n164_));
  OA21x2_ASAP7_75t_R  g106(.A1(G24), .A2(G31), .B(G17), .Y(new_n165_));
  XNOR2x2_ASAP7_75t_R g107(.A(G8), .B(G4), .Y(new_n166_));
  OAI21x1_ASAP7_75t_R g108(.A1(new_n137_), .A2(new_n139_), .B(new_n122_), .Y(new_n167_));
  OAI21x1_ASAP7_75t_R g109(.A1(new_n118_), .A2(new_n120_), .B(new_n141_), .Y(new_n168_));
  AND3x1_ASAP7_75t_R  g110(.A(new_n167_), .B(new_n168_), .C(new_n166_), .Y(new_n169_));
  AOI21x1_ASAP7_75t_R g111(.A1(new_n167_), .A2(new_n168_), .B(new_n166_), .Y(new_n170_));
  NOR2x1_ASAP7_75t_R  g112(.A(new_n169_), .B(new_n170_), .Y(new_n171_));
  INVx1_ASAP7_75t_R   g113(.A(new_n171_), .Y(new_n172_));
  NAND2x1_ASAP7_75t_R g114(.A(G21), .B(new_n61_), .Y(new_n173_));
  XNOR2x2_ASAP7_75t_R g115(.A(G9), .B(new_n173_), .Y(new_n174_));
  XOR2x2_ASAP7_75t_R  g116(.A(new_n109_), .B(new_n174_), .Y(new_n175_));
  OR3x1_ASAP7_75t_R   g117(.A(new_n169_), .B(new_n170_), .C(new_n175_), .Y(new_n176_));
  OAI21x1_ASAP7_75t_R g118(.A1(new_n169_), .A2(new_n170_), .B(new_n175_), .Y(new_n177_));
  AND2x2_ASAP7_75t_R  g119(.A(new_n176_), .B(new_n177_), .Y(new_n178_));
  NAND2x1_ASAP7_75t_R g120(.A(new_n176_), .B(new_n177_), .Y(new_n179_));
  NOR3x1_ASAP7_75t_R  g121(.A(new_n179_), .B(new_n165_), .C(G31), .Y(new_n180_));
  OA21x2_ASAP7_75t_R  g122(.A1(new_n179_), .A2(G31), .B(new_n165_), .Y(new_n181_));
  NOR2x1_ASAP7_75t_R  g123(.A(new_n180_), .B(new_n181_), .Y(new_n182_));
  AND3x1_ASAP7_75t_R  g124(.A(new_n163_), .B(new_n164_), .C(new_n182_), .Y(new_n183_));
  NAND2x1_ASAP7_75t_R g125(.A(new_n133_), .B(new_n183_), .Y(new_n184_));
  OR3x1_ASAP7_75t_R   g126(.A(new_n184_), .B(new_n73_), .C(new_n101_), .Y(new_n185_));
  XOR2x2_ASAP7_75t_R  g127(.A(G14), .B(new_n185_), .Y(G1899));
  NOR2x1_ASAP7_75t_R  g128(.A(G33), .B(G29), .Y(new_n187_));
  AOI21x1_ASAP7_75t_R g129(.A1(new_n72_), .A2(new_n187_), .B(new_n69_), .Y(new_n188_));
  AO21x1_ASAP7_75t_R  g130(.A1(new_n72_), .A2(new_n187_), .B(new_n69_), .Y(new_n189_));
  AND3x1_ASAP7_75t_R  g131(.A(new_n100_), .B(new_n189_), .C(new_n89_), .Y(new_n190_));
  OAI21x1_ASAP7_75t_R g132(.A1(new_n180_), .A2(new_n181_), .B(new_n164_), .Y(new_n191_));
  AND3x1_ASAP7_75t_R  g133(.A(new_n163_), .B(new_n191_), .C(new_n133_), .Y(new_n192_));
  NAND2x1_ASAP7_75t_R g134(.A(new_n190_), .B(new_n192_), .Y(new_n193_));
  XOR2x2_ASAP7_75t_R  g135(.A(G1), .B(new_n193_), .Y(G1884));
  XOR2x2_ASAP7_75t_R  g136(.A(G2), .B(new_n193_), .Y(G1885));
  XOR2x2_ASAP7_75t_R  g137(.A(G13), .B(new_n185_), .Y(G1898));
  XOR2x2_ASAP7_75t_R  g138(.A(G3), .B(new_n193_), .Y(G1886));
  XOR2x2_ASAP7_75t_R  g139(.A(G4), .B(new_n193_), .Y(G1887));
  NAND2x1_ASAP7_75t_R g140(.A(new_n102_), .B(new_n192_), .Y(new_n199_));
  XOR2x2_ASAP7_75t_R  g141(.A(G10), .B(new_n199_), .Y(G1888));
  XOR2x2_ASAP7_75t_R  g142(.A(G15), .B(new_n199_), .Y(G1889));
  XOR2x2_ASAP7_75t_R  g143(.A(G16), .B(new_n199_), .Y(G1890));
  AND2x2_ASAP7_75t_R  g144(.A(new_n103_), .B(new_n132_), .Y(new_n203_));
  NAND3x1_ASAP7_75t_R g145(.A(new_n163_), .B(new_n191_), .C(new_n203_), .Y(new_n204_));
  OR3x1_ASAP7_75t_R   g146(.A(new_n101_), .B(new_n204_), .C(new_n188_), .Y(new_n205_));
  XOR2x2_ASAP7_75t_R  g147(.A(G5), .B(new_n205_), .Y(G1891));
  XOR2x2_ASAP7_75t_R  g148(.A(G6), .B(new_n205_), .Y(G1892));
  XOR2x2_ASAP7_75t_R  g149(.A(G7), .B(new_n205_), .Y(G1893));
  XOR2x2_ASAP7_75t_R  g150(.A(G8), .B(new_n205_), .Y(G1894));
  OR3x1_ASAP7_75t_R   g151(.A(new_n204_), .B(new_n73_), .C(new_n101_), .Y(new_n210_));
  XOR2x2_ASAP7_75t_R  g152(.A(G9), .B(new_n210_), .Y(G1895));
  XOR2x2_ASAP7_75t_R  g153(.A(G11), .B(new_n185_), .Y(G1896));
  XOR2x2_ASAP7_75t_R  g154(.A(G12), .B(new_n185_), .Y(G1897));
  OA21x2_ASAP7_75t_R  g155(.A1(new_n102_), .A2(new_n190_), .B(new_n192_), .Y(new_n214_));
  NAND2x1_ASAP7_75t_R g156(.A(new_n184_), .B(new_n204_), .Y(new_n215_));
  AND3x1_ASAP7_75t_R  g157(.A(new_n69_), .B(new_n100_), .C(new_n89_), .Y(new_n216_));
  AO21x1_ASAP7_75t_R  g158(.A1(new_n215_), .A2(new_n216_), .B(new_n214_), .Y(new_n217_));
  NOR2x1_ASAP7_75t_R  g159(.A(new_n103_), .B(new_n164_), .Y(new_n218_));
  AND3x1_ASAP7_75t_R  g160(.A(new_n132_), .B(new_n182_), .C(new_n218_), .Y(new_n219_));
  AND3x1_ASAP7_75t_R  g161(.A(new_n163_), .B(new_n89_), .C(new_n100_), .Y(new_n220_));
  AO21x1_ASAP7_75t_R  g162(.A1(new_n219_), .A2(new_n220_), .B(G33), .Y(new_n221_));
  AO21x1_ASAP7_75t_R  g163(.A1(new_n217_), .A2(G32), .B(new_n221_), .Y(G1900));
  AND3x1_ASAP7_75t_R  g164(.A(new_n62_), .B(new_n214_), .C(new_n165_), .Y(new_n223_));
  AOI21x1_ASAP7_75t_R g165(.A1(new_n178_), .A2(new_n223_), .B(new_n68_), .Y(new_n224_));
  OA21x2_ASAP7_75t_R  g166(.A1(new_n178_), .A2(new_n223_), .B(new_n224_), .Y(G1901));
  AND3x1_ASAP7_75t_R  g167(.A(new_n62_), .B(new_n214_), .C(G25), .Y(new_n226_));
  AOI21x1_ASAP7_75t_R g168(.A1(new_n129_), .A2(new_n226_), .B(new_n68_), .Y(new_n227_));
  OA21x2_ASAP7_75t_R  g169(.A1(new_n129_), .A2(new_n226_), .B(new_n227_), .Y(G1902));
  AND3x1_ASAP7_75t_R  g170(.A(new_n62_), .B(new_n214_), .C(G27), .Y(new_n229_));
  AOI21x1_ASAP7_75t_R g171(.A1(new_n88_), .A2(new_n229_), .B(new_n68_), .Y(new_n230_));
  OA21x2_ASAP7_75t_R  g172(.A1(new_n88_), .A2(new_n229_), .B(new_n230_), .Y(G1903));
  AND3x1_ASAP7_75t_R  g173(.A(new_n62_), .B(new_n214_), .C(G28), .Y(new_n232_));
  AOI21x1_ASAP7_75t_R g174(.A1(new_n97_), .A2(new_n232_), .B(new_n68_), .Y(new_n233_));
  OA21x2_ASAP7_75t_R  g175(.A1(new_n97_), .A2(new_n232_), .B(new_n233_), .Y(G1904));
  AND3x1_ASAP7_75t_R  g176(.A(new_n62_), .B(new_n214_), .C(new_n161_), .Y(new_n235_));
  AOI21x1_ASAP7_75t_R g177(.A1(new_n159_), .A2(new_n235_), .B(new_n68_), .Y(new_n236_));
  OA21x2_ASAP7_75t_R  g178(.A1(new_n159_), .A2(new_n235_), .B(new_n236_), .Y(G1905));
  AND3x1_ASAP7_75t_R  g179(.A(new_n192_), .B(new_n61_), .C(new_n190_), .Y(new_n238_));
  NOR2x1_ASAP7_75t_R  g180(.A(new_n187_), .B(new_n172_), .Y(new_n239_));
  OAI21x1_ASAP7_75t_R g181(.A1(new_n172_), .A2(new_n187_), .B(new_n238_), .Y(new_n240_));
  OAI21x1_ASAP7_75t_R g182(.A1(G33), .A2(new_n193_), .B(new_n239_), .Y(new_n241_));
  AOI21x1_ASAP7_75t_R g183(.A1(G21), .A2(G29), .B(G33), .Y(new_n242_));
  NAND3x1_ASAP7_75t_R g184(.A(new_n240_), .B(new_n241_), .C(new_n242_), .Y(new_n243_));
  AO21x1_ASAP7_75t_R  g185(.A1(new_n240_), .A2(new_n241_), .B(new_n242_), .Y(new_n244_));
  NAND2x1_ASAP7_75t_R g186(.A(new_n243_), .B(new_n244_), .Y(G1906));
  AND3x1_ASAP7_75t_R  g187(.A(new_n192_), .B(new_n61_), .C(new_n102_), .Y(new_n246_));
  AND3x1_ASAP7_75t_R  g188(.A(new_n80_), .B(new_n112_), .C(new_n113_), .Y(new_n247_));
  OAI21x1_ASAP7_75t_R g189(.A1(new_n80_), .A2(new_n114_), .B(new_n71_), .Y(new_n248_));
  NOR2x1_ASAP7_75t_R  g190(.A(new_n247_), .B(new_n248_), .Y(new_n249_));
  OAI21x1_ASAP7_75t_R g191(.A1(new_n247_), .A2(new_n248_), .B(new_n246_), .Y(new_n250_));
  OAI21x1_ASAP7_75t_R g192(.A1(G33), .A2(new_n199_), .B(new_n249_), .Y(new_n251_));
  AOI21x1_ASAP7_75t_R g193(.A1(G30), .A2(G22), .B(G33), .Y(new_n252_));
  NAND3x1_ASAP7_75t_R g194(.A(new_n250_), .B(new_n251_), .C(new_n252_), .Y(new_n253_));
  AO21x1_ASAP7_75t_R  g195(.A1(new_n250_), .A2(new_n251_), .B(new_n252_), .Y(new_n254_));
  NAND2x1_ASAP7_75t_R g196(.A(new_n253_), .B(new_n254_), .Y(G1907));
  AND3x1_ASAP7_75t_R  g197(.A(new_n62_), .B(new_n214_), .C(G26), .Y(new_n256_));
  AOI21x1_ASAP7_75t_R g198(.A1(new_n149_), .A2(new_n214_), .B(new_n68_), .Y(new_n257_));
  OA21x2_ASAP7_75t_R  g199(.A1(new_n256_), .A2(new_n147_), .B(new_n257_), .Y(G1908));
endmodule


