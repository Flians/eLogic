# Single-output independent component studies

Uniform configurations, same once-resyn2 EPFL input and original single-output libraries; cumulative20k nodes/cuts16/retainedpool100k/SAT16/cutrounds32/inclusive recovery2s/native60/mapping300 unchanged. Original baselines unchanged. No per-design profile or best-repeat selection. A tail-pass ablation does not ablate all sharing-aware seeds/local recovery. Witness-optional-cut restriction keeps identical saturation and mandatory source fallbacks but changes optional candidate coverage/ranking; not a no-egraph/no-saturation baseline. The2s timer is post-admission frozen-pool recovery; existing pre-admission finite/frontier ranking uses original5s subguards within native60/mapping300 and is not included in that2s timer. Do not call it whole-mapper/all-cover-work2s. Input-phase matching and atomic phase recovery are distinct factors. Phase/pin restriction probes remove legal matches as well as optimization choices; they are not function-preserving one-legal-assignment timing-only controls. NP matching itself is established, not a claimed new primitive. Module removal can change time available to subsequent passes and the recovery trajectory; counts are whole-pipeline effects, not isolated intrinsic module quality or statistical significance. SDC/phase/pin factors also affect admission under the same cap. AD gates are posthoc. Failed import prefixes remain failures.

```json
{
  "single_output_components_guard_full_20261017": {
    "complete": true,
    "attempts": 80,
    "expected": 80,
    "cec": 68,
    "summary": {
      "protected_area": {
        "area_outcome": {
          "equal": 25,
          "worse": 2,
          "better": 7
        },
        "delay_outcome": {
          "equal": 34
        }
      }
    },
    "reference": "legacy_control",
    "coverage": {
      "legacy_control": {
        "attempts": 40,
        "CEC": 34,
        "failures": {
          "import_budget": 6
        }
      },
      "protected_area": {
        "attempts": 40,
        "CEC": 34,
        "failures": {
          "import_budget": 6
        }
      }
    },
    "pair_coverage": {
      "protected_area": {
        "total": 40,
        "both_legal": 34,
        "reference_failure": 6,
        "candidate_only_failure": 0
      }
    }
  },
  "single_output_components_full_20261017": {
    "complete": true,
    "attempts": 320,
    "expected": 320,
    "cec": 254,
    "summary": {
      "single_structure": {
        "area_outcome": {
          "equal": 30,
          "worse": 3,
          "better": 1
        },
        "delay_outcome": {
          "equal": 34
        }
      },
      "no_input_phase": {
        "area_outcome": {
          "worse": 9,
          "better": 11,
          "equal": 2
        },
        "delay_outcome": {
          "worse": 20,
          "equal": 2
        }
      },
      "canonical_pins": {
        "area_outcome": {
          "better": 16,
          "worse": 11,
          "equal": 1
        },
        "delay_outcome": {
          "worse": 28
        }
      },
      "no_sdc": {
        "area_outcome": {
          "worse": 7,
          "equal": 24,
          "better": 3
        },
        "delay_outcome": {
          "worse": 1,
          "equal": 33
        }
      },
      "no_actual_area": {
        "area_outcome": {
          "worse": 12,
          "equal": 22
        },
        "delay_outcome": {
          "equal": 34
        }
      },
      "no_phase_recovery": {
        "area_outcome": {
          "equal": 31,
          "better": 2,
          "worse": 1
        },
        "delay_outcome": {
          "equal": 34
        }
      },
      "no_timing_area_module": {
        "area_outcome": {
          "worse": 30,
          "equal": 4
        },
        "delay_outcome": {
          "equal": 34
        }
      }
    },
    "reference": "protected_area",
    "coverage": {
      "protected_area": {
        "attempts": 40,
        "CEC": 34,
        "failures": {
          "import_budget": 6
        }
      },
      "single_structure": {
        "attempts": 40,
        "CEC": 34,
        "failures": {
          "import_budget": 6
        }
      },
      "no_input_phase": {
        "attempts": 40,
        "CEC": 22,
        "failures": {
          "import_budget": 6,
          "physical_cover_missing": 12
        }
      },
      "canonical_pins": {
        "attempts": 40,
        "CEC": 28,
        "failures": {
          "import_budget": 6,
          "physical_cover_missing": 6
        }
      },
      "no_sdc": {
        "attempts": 40,
        "CEC": 34,
        "failures": {
          "import_budget": 6
        }
      },
      "no_actual_area": {
        "attempts": 40,
        "CEC": 34,
        "failures": {
          "import_budget": 6
        }
      },
      "no_phase_recovery": {
        "attempts": 40,
        "CEC": 34,
        "failures": {
          "import_budget": 6
        }
      },
      "no_timing_area_module": {
        "attempts": 40,
        "CEC": 34,
        "failures": {
          "import_budget": 6
        }
      }
    },
    "pair_coverage": {
      "single_structure": {
        "total": 40,
        "both_legal": 34,
        "reference_failure": 6,
        "candidate_only_failure": 0
      },
      "no_input_phase": {
        "total": 40,
        "both_legal": 22,
        "reference_failure": 6,
        "candidate_only_failure": 12
      },
      "canonical_pins": {
        "total": 40,
        "both_legal": 28,
        "reference_failure": 6,
        "candidate_only_failure": 6
      },
      "no_sdc": {
        "total": 40,
        "both_legal": 34,
        "reference_failure": 6,
        "candidate_only_failure": 0
      },
      "no_actual_area": {
        "total": 40,
        "both_legal": 34,
        "reference_failure": 6,
        "candidate_only_failure": 0
      },
      "no_phase_recovery": {
        "total": 40,
        "both_legal": 34,
        "reference_failure": 6,
        "candidate_only_failure": 0
      },
      "no_timing_area_module": {
        "total": 40,
        "both_legal": 34,
        "reference_failure": 6,
        "candidate_only_failure": 0
      }
    }
  },
  "single_output_no_saturation_full_20261017": {
    "complete": true,
    "attempts": 80,
    "expected": 80,
    "cec": 68,
    "summary": {
      "no_saturation": {
        "area_outcome": {
          "equal": 30,
          "better": 3,
          "worse": 1
        },
        "delay_outcome": {
          "equal": 34
        }
      }
    },
    "reference": "protected_area",
    "coverage": {
      "protected_area": {
        "attempts": 40,
        "CEC": 34,
        "failures": {
          "import_budget": 6
        }
      },
      "no_saturation": {
        "attempts": 40,
        "CEC": 34,
        "failures": {
          "import_budget": 6
        }
      }
    },
    "pair_coverage": {
      "no_saturation": {
        "total": 40,
        "both_legal": 34,
        "reference_failure": 6,
        "candidate_only_failure": 0
      }
    }
  },
  "single_output_components_bar_sin_reverse_20261017": {
    "complete": true,
    "attempts": 32,
    "expected": 32,
    "cec": 32,
    "summary": {
      "single_structure": {
        "area_outcome": {
          "equal": 4
        },
        "delay_outcome": {
          "equal": 4
        }
      },
      "no_input_phase": {
        "area_outcome": {
          "worse": 1,
          "better": 3
        },
        "delay_outcome": {
          "worse": 4
        }
      },
      "canonical_pins": {
        "area_outcome": {
          "worse": 1,
          "better": 3
        },
        "delay_outcome": {
          "worse": 4
        }
      },
      "no_sdc": {
        "area_outcome": {
          "equal": 4
        },
        "delay_outcome": {
          "equal": 4
        }
      },
      "no_actual_area": {
        "area_outcome": {
          "worse": 1,
          "equal": 3
        },
        "delay_outcome": {
          "equal": 4
        }
      },
      "no_phase_recovery": {
        "area_outcome": {
          "equal": 4
        },
        "delay_outcome": {
          "equal": 4
        }
      },
      "no_timing_area_module": {
        "area_outcome": {
          "worse": 4
        },
        "delay_outcome": {
          "equal": 4
        }
      }
    },
    "reference": "protected_area",
    "coverage": {
      "protected_area": {
        "attempts": 4,
        "CEC": 4,
        "failures": {}
      },
      "single_structure": {
        "attempts": 4,
        "CEC": 4,
        "failures": {}
      },
      "no_input_phase": {
        "attempts": 4,
        "CEC": 4,
        "failures": {}
      },
      "canonical_pins": {
        "attempts": 4,
        "CEC": 4,
        "failures": {}
      },
      "no_sdc": {
        "attempts": 4,
        "CEC": 4,
        "failures": {}
      },
      "no_actual_area": {
        "attempts": 4,
        "CEC": 4,
        "failures": {}
      },
      "no_phase_recovery": {
        "attempts": 4,
        "CEC": 4,
        "failures": {}
      },
      "no_timing_area_module": {
        "attempts": 4,
        "CEC": 4,
        "failures": {}
      }
    },
    "pair_coverage": {
      "single_structure": {
        "total": 4,
        "both_legal": 4,
        "reference_failure": 0,
        "candidate_only_failure": 0
      },
      "no_input_phase": {
        "total": 4,
        "both_legal": 4,
        "reference_failure": 0,
        "candidate_only_failure": 0
      },
      "canonical_pins": {
        "total": 4,
        "both_legal": 4,
        "reference_failure": 0,
        "candidate_only_failure": 0
      },
      "no_sdc": {
        "total": 4,
        "both_legal": 4,
        "reference_failure": 0,
        "candidate_only_failure": 0
      },
      "no_actual_area": {
        "total": 4,
        "both_legal": 4,
        "reference_failure": 0,
        "candidate_only_failure": 0
      },
      "no_phase_recovery": {
        "total": 4,
        "both_legal": 4,
        "reference_failure": 0,
        "candidate_only_failure": 0
      },
      "no_timing_area_module": {
        "total": 4,
        "both_legal": 4,
        "reference_failure": 0,
        "candidate_only_failure": 0
      }
    }
  },
  "single_output_components_sqrt_reverse_20261017": {
    "complete": true,
    "attempts": 12,
    "expected": 12,
    "cec": 12,
    "summary": {
      "single_structure": {
        "area_outcome": {
          "better": 1,
          "worse": 1
        },
        "delay_outcome": {
          "equal": 2
        }
      },
      "no_sdc": {
        "area_outcome": {
          "worse": 2
        },
        "delay_outcome": {
          "equal": 2
        }
      },
      "no_actual_area": {
        "area_outcome": {
          "worse": 2
        },
        "delay_outcome": {
          "equal": 2
        }
      },
      "no_phase_recovery": {
        "area_outcome": {
          "better": 2
        },
        "delay_outcome": {
          "equal": 2
        }
      },
      "no_timing_area_module": {
        "area_outcome": {
          "worse": 2
        },
        "delay_outcome": {
          "equal": 2
        }
      }
    },
    "reference": "protected_area",
    "coverage": {
      "protected_area": {
        "attempts": 2,
        "CEC": 2,
        "failures": {}
      },
      "single_structure": {
        "attempts": 2,
        "CEC": 2,
        "failures": {}
      },
      "no_sdc": {
        "attempts": 2,
        "CEC": 2,
        "failures": {}
      },
      "no_actual_area": {
        "attempts": 2,
        "CEC": 2,
        "failures": {}
      },
      "no_phase_recovery": {
        "attempts": 2,
        "CEC": 2,
        "failures": {}
      },
      "no_timing_area_module": {
        "attempts": 2,
        "CEC": 2,
        "failures": {}
      }
    },
    "pair_coverage": {
      "single_structure": {
        "total": 2,
        "both_legal": 2,
        "reference_failure": 0,
        "candidate_only_failure": 0
      },
      "no_sdc": {
        "total": 2,
        "both_legal": 2,
        "reference_failure": 0,
        "candidate_only_failure": 0
      },
      "no_actual_area": {
        "total": 2,
        "both_legal": 2,
        "reference_failure": 0,
        "candidate_only_failure": 0
      },
      "no_phase_recovery": {
        "total": 2,
        "both_legal": 2,
        "reference_failure": 0,
        "candidate_only_failure": 0
      },
      "no_timing_area_module": {
        "total": 2,
        "both_legal": 2,
        "reference_failure": 0,
        "candidate_only_failure": 0
      }
    }
  },
  "single_output_guard_repeats_reverse_20261017": {
    "complete": true,
    "attempts": 16,
    "expected": 16,
    "cec": 16,
    "summary": {
      "protected_area": {
        "area_outcome": {
          "worse": 2,
          "equal": 4,
          "better": 2
        },
        "delay_outcome": {
          "equal": 8
        }
      }
    },
    "reference": "legacy_control",
    "coverage": {
      "legacy_control": {
        "attempts": 8,
        "CEC": 8,
        "failures": {}
      },
      "protected_area": {
        "attempts": 8,
        "CEC": 8,
        "failures": {}
      }
    },
    "pair_coverage": {
      "protected_area": {
        "total": 8,
        "both_legal": 8,
        "reference_failure": 0,
        "candidate_only_failure": 0
      }
    }
  },
  "single_output_components_bar_sin_forward_20261017": {
    "complete": true,
    "attempts": 32,
    "expected": 32,
    "cec": 32,
    "summary": {
      "single_structure": {
        "area_outcome": {
          "equal": 4
        },
        "delay_outcome": {
          "equal": 4
        }
      },
      "no_input_phase": {
        "area_outcome": {
          "worse": 1,
          "better": 3
        },
        "delay_outcome": {
          "worse": 4
        }
      },
      "canonical_pins": {
        "area_outcome": {
          "worse": 1,
          "better": 3
        },
        "delay_outcome": {
          "worse": 4
        }
      },
      "no_sdc": {
        "area_outcome": {
          "equal": 4
        },
        "delay_outcome": {
          "equal": 4
        }
      },
      "no_actual_area": {
        "area_outcome": {
          "worse": 1,
          "equal": 3
        },
        "delay_outcome": {
          "equal": 4
        }
      },
      "no_phase_recovery": {
        "area_outcome": {
          "equal": 4
        },
        "delay_outcome": {
          "equal": 4
        }
      },
      "no_timing_area_module": {
        "area_outcome": {
          "worse": 4
        },
        "delay_outcome": {
          "equal": 4
        }
      }
    },
    "reference": "protected_area",
    "coverage": {
      "protected_area": {
        "attempts": 4,
        "CEC": 4,
        "failures": {}
      },
      "single_structure": {
        "attempts": 4,
        "CEC": 4,
        "failures": {}
      },
      "no_input_phase": {
        "attempts": 4,
        "CEC": 4,
        "failures": {}
      },
      "canonical_pins": {
        "attempts": 4,
        "CEC": 4,
        "failures": {}
      },
      "no_sdc": {
        "attempts": 4,
        "CEC": 4,
        "failures": {}
      },
      "no_actual_area": {
        "attempts": 4,
        "CEC": 4,
        "failures": {}
      },
      "no_phase_recovery": {
        "attempts": 4,
        "CEC": 4,
        "failures": {}
      },
      "no_timing_area_module": {
        "attempts": 4,
        "CEC": 4,
        "failures": {}
      }
    },
    "pair_coverage": {
      "single_structure": {
        "total": 4,
        "both_legal": 4,
        "reference_failure": 0,
        "candidate_only_failure": 0
      },
      "no_input_phase": {
        "total": 4,
        "both_legal": 4,
        "reference_failure": 0,
        "candidate_only_failure": 0
      },
      "canonical_pins": {
        "total": 4,
        "both_legal": 4,
        "reference_failure": 0,
        "candidate_only_failure": 0
      },
      "no_sdc": {
        "total": 4,
        "both_legal": 4,
        "reference_failure": 0,
        "candidate_only_failure": 0
      },
      "no_actual_area": {
        "total": 4,
        "both_legal": 4,
        "reference_failure": 0,
        "candidate_only_failure": 0
      },
      "no_phase_recovery": {
        "total": 4,
        "both_legal": 4,
        "reference_failure": 0,
        "candidate_only_failure": 0
      },
      "no_timing_area_module": {
        "total": 4,
        "both_legal": 4,
        "reference_failure": 0,
        "candidate_only_failure": 0
      }
    }
  },
  "single_output_components_sqrt_forward_20261017": {
    "complete": true,
    "attempts": 12,
    "expected": 12,
    "cec": 12,
    "summary": {
      "single_structure": {
        "area_outcome": {
          "worse": 1,
          "equal": 1
        },
        "delay_outcome": {
          "equal": 2
        }
      },
      "no_sdc": {
        "area_outcome": {
          "equal": 1,
          "worse": 1
        },
        "delay_outcome": {
          "equal": 2
        }
      },
      "no_actual_area": {
        "area_outcome": {
          "worse": 2
        },
        "delay_outcome": {
          "equal": 2
        }
      },
      "no_phase_recovery": {
        "area_outcome": {
          "better": 2
        },
        "delay_outcome": {
          "equal": 2
        }
      },
      "no_timing_area_module": {
        "area_outcome": {
          "worse": 2
        },
        "delay_outcome": {
          "equal": 2
        }
      }
    },
    "reference": "protected_area",
    "coverage": {
      "protected_area": {
        "attempts": 2,
        "CEC": 2,
        "failures": {}
      },
      "single_structure": {
        "attempts": 2,
        "CEC": 2,
        "failures": {}
      },
      "no_sdc": {
        "attempts": 2,
        "CEC": 2,
        "failures": {}
      },
      "no_actual_area": {
        "attempts": 2,
        "CEC": 2,
        "failures": {}
      },
      "no_phase_recovery": {
        "attempts": 2,
        "CEC": 2,
        "failures": {}
      },
      "no_timing_area_module": {
        "attempts": 2,
        "CEC": 2,
        "failures": {}
      }
    },
    "pair_coverage": {
      "single_structure": {
        "total": 2,
        "both_legal": 2,
        "reference_failure": 0,
        "candidate_only_failure": 0
      },
      "no_sdc": {
        "total": 2,
        "both_legal": 2,
        "reference_failure": 0,
        "candidate_only_failure": 0
      },
      "no_actual_area": {
        "total": 2,
        "both_legal": 2,
        "reference_failure": 0,
        "candidate_only_failure": 0
      },
      "no_phase_recovery": {
        "total": 2,
        "both_legal": 2,
        "reference_failure": 0,
        "candidate_only_failure": 0
      },
      "no_timing_area_module": {
        "total": 2,
        "both_legal": 2,
        "reference_failure": 0,
        "candidate_only_failure": 0
      }
    }
  },
  "single_output_guard_repeats_forward_20261017": {
    "complete": true,
    "attempts": 16,
    "expected": 16,
    "cec": 16,
    "summary": {
      "protected_area": {
        "area_outcome": {
          "better": 2,
          "equal": 3,
          "worse": 3
        },
        "delay_outcome": {
          "equal": 8
        }
      }
    },
    "reference": "legacy_control",
    "coverage": {
      "legacy_control": {
        "attempts": 8,
        "CEC": 8,
        "failures": {}
      },
      "protected_area": {
        "attempts": 8,
        "CEC": 8,
        "failures": {}
      }
    },
    "pair_coverage": {
      "protected_area": {
        "total": 8,
        "both_legal": 8,
        "reference_failure": 0,
        "candidate_only_failure": 0
      }
    }
  },
  "main_promoted": false,
  "baseline_algorithms_changed": false,
  "unconnected": [
    "MtM"
  ],
  "area_delay_objective_not_optimized": true,
  "gate_reference": "Uniform full-method component reference (tail0) if full320 available; rejected tail1 guard otherwise. No per-design profile selection.",
  "reference_mechanism_active_case_counts": {
    "single_output_components_guard_full_20261017": {
      "phase_trials": 7,
      "phase_accepted": 3,
      "dc_with_unreachable": 28,
      "dc_bindings": 28,
      "slack_attempts": 34,
      "slack_accepted": 15,
      "slack_local_scored": 19,
      "slack_local_accepted": 12,
      "online_area_updates": 2
    },
    "single_output_components_full_20261017": {
      "phase_trials": 7,
      "phase_accepted": 4,
      "dc_with_unreachable": 28,
      "dc_bindings": 28,
      "slack_attempts": 34,
      "slack_accepted": 15,
      "slack_local_scored": 19,
      "slack_local_accepted": 12,
      "online_area_updates": 2
    },
    "single_output_no_saturation_full_20261017": {
      "phase_trials": 7,
      "phase_accepted": 4,
      "dc_with_unreachable": 28,
      "dc_bindings": 28,
      "slack_attempts": 34,
      "slack_accepted": 15,
      "slack_local_scored": 19,
      "slack_local_accepted": 12,
      "online_area_updates": 2
    },
    "single_output_components_bar_sin_reverse_20261017": {
      "phase_trials": 1,
      "phase_accepted": 0,
      "dc_with_unreachable": 4,
      "dc_bindings": 4,
      "slack_attempts": 4,
      "slack_accepted": 1,
      "slack_local_scored": 2,
      "slack_local_accepted": 0,
      "online_area_updates": 0
    },
    "single_output_components_sqrt_reverse_20261017": {
      "phase_trials": 2,
      "phase_accepted": 2,
      "dc_with_unreachable": 2,
      "dc_bindings": 2,
      "slack_attempts": 2,
      "slack_accepted": 2,
      "slack_local_scored": 2,
      "slack_local_accepted": 0,
      "online_area_updates": 2
    },
    "single_output_guard_repeats_reverse_20261017": {
      "phase_trials": 2,
      "phase_accepted": 2,
      "dc_with_unreachable": 4,
      "dc_bindings": 4,
      "slack_attempts": 8,
      "slack_accepted": 7,
      "slack_local_scored": 6,
      "slack_local_accepted": 3,
      "online_area_updates": 2
    },
    "single_output_components_bar_sin_forward_20261017": {
      "phase_trials": 1,
      "phase_accepted": 0,
      "dc_with_unreachable": 4,
      "dc_bindings": 4,
      "slack_attempts": 4,
      "slack_accepted": 1,
      "slack_local_scored": 2,
      "slack_local_accepted": 0,
      "online_area_updates": 0
    },
    "single_output_components_sqrt_forward_20261017": {
      "phase_trials": 2,
      "phase_accepted": 2,
      "dc_with_unreachable": 2,
      "dc_bindings": 2,
      "slack_attempts": 2,
      "slack_accepted": 2,
      "slack_local_scored": 2,
      "slack_local_accepted": 0,
      "online_area_updates": 2
    },
    "single_output_guard_repeats_forward_20261017": {
      "phase_trials": 2,
      "phase_accepted": 2,
      "dc_with_unreachable": 4,
      "dc_bindings": 4,
      "slack_attempts": 8,
      "slack_accepted": 7,
      "slack_local_scored": 6,
      "slack_local_accepted": 3,
      "online_area_updates": 2
    }
  },
  "activation_caveat": "Generated bindings and accepted/intermediate updates are not proof that those bindings or covers were selected in the final returned implementation.",
  "metadata_erratum": "V28 component controller frozen descriptive scope inherited a V27 label; authoritative V28 source/binary fingerprint and actual argv are unchanged, external scope_correction.json records this. All component runs tail0.",
  "gates": [
    {
      "k": 3,
      "objective": "delay-area",
      "passed": false,
      "argv": [
        "/home/flynn/miniconda3/bin/python3",
        "/home/flynn/workplace/MIGBalance/scripts/experiments/check_mapping_dominance.py",
        "--candidate",
        "/home/flynn/workplace/MIGBalance/results_v2/single_output_components_evidence_20261017/baseline_scope/candidate_3in.json",
        "--baselines",
        "/home/flynn/workplace/MIGBalance/results_v2/guarded_joint_evidence_20261016/baseline_scope/baselines_3in.json",
        "--required-baselines",
        "abc_map_area_resyn2",
        "abc_map_delay_resyn2",
        "mockturtle_emap_area_resyn2",
        "mockturtle_emap_delay_resyn2",
        "eqmap_lut_amap",
        "esyn_frozen_model_amap_bounded_dag",
        "emorphic_final_sa",
        "--objective",
        "delay-area",
        "--output",
        "/home/flynn/workplace/MIGBalance/results_v2/single_output_components_evidence_20261017/baseline_scope/3in_delay-area.json"
      ],
      "exit_code": 1,
      "baseline_sha256": "191654e6990f763211e61d436f88f8988f865171ef3f168ae669b29d12c9daf7"
    },
    {
      "k": 3,
      "objective": "area-delay",
      "passed": false,
      "argv": [
        "/home/flynn/miniconda3/bin/python3",
        "/home/flynn/workplace/MIGBalance/scripts/experiments/check_mapping_dominance.py",
        "--candidate",
        "/home/flynn/workplace/MIGBalance/results_v2/single_output_components_evidence_20261017/baseline_scope/candidate_3in.json",
        "--baselines",
        "/home/flynn/workplace/MIGBalance/results_v2/guarded_joint_evidence_20261016/baseline_scope/baselines_3in.json",
        "--required-baselines",
        "abc_map_area_resyn2",
        "abc_map_delay_resyn2",
        "mockturtle_emap_area_resyn2",
        "mockturtle_emap_delay_resyn2",
        "eqmap_lut_amap",
        "esyn_frozen_model_amap_bounded_dag",
        "emorphic_final_sa",
        "--objective",
        "area-delay",
        "--output",
        "/home/flynn/workplace/MIGBalance/results_v2/single_output_components_evidence_20261017/baseline_scope/3in_area-delay.json"
      ],
      "exit_code": 1,
      "baseline_sha256": "191654e6990f763211e61d436f88f8988f865171ef3f168ae669b29d12c9daf7"
    },
    {
      "k": 3,
      "objective": "pareto",
      "passed": false,
      "argv": [
        "/home/flynn/miniconda3/bin/python3",
        "/home/flynn/workplace/MIGBalance/scripts/experiments/check_mapping_dominance.py",
        "--candidate",
        "/home/flynn/workplace/MIGBalance/results_v2/single_output_components_evidence_20261017/baseline_scope/candidate_3in.json",
        "--baselines",
        "/home/flynn/workplace/MIGBalance/results_v2/guarded_joint_evidence_20261016/baseline_scope/baselines_3in.json",
        "--required-baselines",
        "abc_map_area_resyn2",
        "abc_map_delay_resyn2",
        "mockturtle_emap_area_resyn2",
        "mockturtle_emap_delay_resyn2",
        "eqmap_lut_amap",
        "esyn_frozen_model_amap_bounded_dag",
        "emorphic_final_sa",
        "--objective",
        "pareto",
        "--output",
        "/home/flynn/workplace/MIGBalance/results_v2/single_output_components_evidence_20261017/baseline_scope/3in_pareto.json"
      ],
      "exit_code": 1,
      "baseline_sha256": "191654e6990f763211e61d436f88f8988f865171ef3f168ae669b29d12c9daf7"
    },
    {
      "k": 4,
      "objective": "delay-area",
      "passed": false,
      "argv": [
        "/home/flynn/miniconda3/bin/python3",
        "/home/flynn/workplace/MIGBalance/scripts/experiments/check_mapping_dominance.py",
        "--candidate",
        "/home/flynn/workplace/MIGBalance/results_v2/single_output_components_evidence_20261017/baseline_scope/candidate_4in.json",
        "--baselines",
        "/home/flynn/workplace/MIGBalance/results_v2/guarded_joint_evidence_20261016/baseline_scope/baselines_4in.json",
        "--required-baselines",
        "abc_map_area_resyn2",
        "abc_map_delay_resyn2",
        "mockturtle_emap_area_resyn2",
        "mockturtle_emap_delay_resyn2",
        "eqmap_lut_amap",
        "esyn_frozen_model_amap_bounded_dag",
        "emorphic_final_sa",
        "--objective",
        "delay-area",
        "--output",
        "/home/flynn/workplace/MIGBalance/results_v2/single_output_components_evidence_20261017/baseline_scope/4in_delay-area.json"
      ],
      "exit_code": 1,
      "baseline_sha256": "8e4fd08b844011ddf8857166c2997d007074d57133c1ecc5d4c543bdeba215e9"
    },
    {
      "k": 4,
      "objective": "area-delay",
      "passed": false,
      "argv": [
        "/home/flynn/miniconda3/bin/python3",
        "/home/flynn/workplace/MIGBalance/scripts/experiments/check_mapping_dominance.py",
        "--candidate",
        "/home/flynn/workplace/MIGBalance/results_v2/single_output_components_evidence_20261017/baseline_scope/candidate_4in.json",
        "--baselines",
        "/home/flynn/workplace/MIGBalance/results_v2/guarded_joint_evidence_20261016/baseline_scope/baselines_4in.json",
        "--required-baselines",
        "abc_map_area_resyn2",
        "abc_map_delay_resyn2",
        "mockturtle_emap_area_resyn2",
        "mockturtle_emap_delay_resyn2",
        "eqmap_lut_amap",
        "esyn_frozen_model_amap_bounded_dag",
        "emorphic_final_sa",
        "--objective",
        "area-delay",
        "--output",
        "/home/flynn/workplace/MIGBalance/results_v2/single_output_components_evidence_20261017/baseline_scope/4in_area-delay.json"
      ],
      "exit_code": 1,
      "baseline_sha256": "8e4fd08b844011ddf8857166c2997d007074d57133c1ecc5d4c543bdeba215e9"
    },
    {
      "k": 4,
      "objective": "pareto",
      "passed": false,
      "argv": [
        "/home/flynn/miniconda3/bin/python3",
        "/home/flynn/workplace/MIGBalance/scripts/experiments/check_mapping_dominance.py",
        "--candidate",
        "/home/flynn/workplace/MIGBalance/results_v2/single_output_components_evidence_20261017/baseline_scope/candidate_4in.json",
        "--baselines",
        "/home/flynn/workplace/MIGBalance/results_v2/guarded_joint_evidence_20261016/baseline_scope/baselines_4in.json",
        "--required-baselines",
        "abc_map_area_resyn2",
        "abc_map_delay_resyn2",
        "mockturtle_emap_area_resyn2",
        "mockturtle_emap_delay_resyn2",
        "eqmap_lut_amap",
        "esyn_frozen_model_amap_bounded_dag",
        "emorphic_final_sa",
        "--objective",
        "pareto",
        "--output",
        "/home/flynn/workplace/MIGBalance/results_v2/single_output_components_evidence_20261017/baseline_scope/4in_pareto.json"
      ],
      "exit_code": 1,
      "baseline_sha256": "8e4fd08b844011ddf8857166c2997d007074d57133c1ecc5d4c543bdeba215e9"
    }
  ],
  "historical_reference_caveat": "Different frozen binary/run; historical comparison is not a paired independent factor or a guarantee. All same-delay losses retained.",
  "historical_reference": {
    "legacy_control": {
      "area_outcome": {
        "equal": 30,
        "worse": 3,
        "better": 1
      },
      "delay_outcome": {
        "equal": 34
      }
    },
    "protected_area": {
      "area_outcome": {
        "equal": 5,
        "worse": 25,
        "better": 4
      },
      "delay_outcome": {
        "equal": 34
      }
    }
  },
  "baseline_common_legal": {
    "abc_map_delay_resyn2": {
      "area_outcome": {
        "better": 6,
        "worse": 26,
        "equal": 2
      },
      "delay_outcome": {
        "better": 13,
        "worse": 4,
        "equal": 17
      }
    },
    "mockturtle_emap_delay_resyn2": {
      "area_outcome": {
        "worse": 28,
        "better": 4,
        "equal": 2
      },
      "delay_outcome": {
        "worse": 8,
        "better": 2,
        "equal": 24
      }
    }
  }
}
```
