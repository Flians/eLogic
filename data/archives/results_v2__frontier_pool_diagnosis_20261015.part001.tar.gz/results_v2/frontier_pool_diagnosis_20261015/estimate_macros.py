"""Exact syntactic recognition size estimate; NOT native mapping or budget proof."""
from pathlib import Path
import json,sys,hashlib,collections
ROOT=Path('/home/flynn/workplace/MIGBalance');sys.path.insert(0,str(ROOT/'scripts/experiments'))
from analyze_epfl_structural_budget import read_binary_aig
out=[]
for r in json.load(open(ROOT/'results_v2/epfl_resyn2_subjects_20261012/report.json'))['results']:
 b=r['bench'];p=ROOT/f'results_v2/epfl_resyn2_subjects_20261012/{b}.resyn2.aig';data=p.read_bytes();assert hashlib.sha256(data).hexdigest()==r['preprocessing']['sha256'];n,po,g=read_binary_aig(data);mac={}
 for v,(a,c) in g.items():
  if not(a&1 and c&1 and a//2 in g and c//2 in g):continue
  x,y=g[a//2],g[c//2]
  if set(x)=={z^1 for z in y}:mac[v]=('xor',tuple(sorted({z//2 for z in x})));continue
  for i,s in enumerate(x):
   for j,t in enumerate(y):
    if s==(t^1):mac[v]=('mux',tuple(sorted({s//2,x[1-i]//2,y[1-j]//2})));break
   if v in mac:break
 live=set();stack=[x//2 for x in po]
 while stack:
  v=stack.pop()
  if v<=n or v in live:continue
  live.add(v);stack.extend(mac[v][1] if v in mac else [x//2 for x in g[v]])
 out.append(dict(bench=b,source_sha256=hashlib.sha256(data).hexdigest(),original_ands=len(g),planned_gate_records=len(live),pi_records=n,constant_records=1,macro_kinds=dict(collections.Counter(mac[v][0] for v in live if v in mac)),estimated_total_without_output_not=len(live)+n+1,scope='Recognition/representation estimate only; no actual egraph import, cut generation, physical mapping or CEC; input source unchanged; not budget success'))
 print(b,len(g),out[-1]['estimated_total_without_output_not'],out[-1]['macro_kinds'])
Path(__file__).with_name('macro_estimate.json').write_text(json.dumps(out,indent=2))
