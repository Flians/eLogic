"""Explicit reuse of every same-version pilot slot, including failed controls."""
import json,copy,hashlib,sys
from pathlib import Path
ROOT=Path('/home/flynn/workplace/MIGBalance');sys.path.insert(0,str(ROOT/'scripts/experiments'));from benchmark_suites import EPFL
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
p=ROOT/'results_v2/xor_import_pilot_20261015/campaign.json';old=json.loads(p.read_text());assert old['status']=='attempted' and len(old['jobs'])==old['expected_jobs']==4
assert all(sha(Path(f))==h for f,h in old['fingerprint'].items())
out=ROOT/'results_v2/xor_import_full_20261015';out.mkdir(exist_ok=False);new=copy.deepcopy(old);new.update(designs=EPFL,expected_jobs=80,status='checkpointed')
for j in new['jobs']:
 for k in ['report','audit','pool','candidates','trace','diagnostic_profile']:
  if k in j:assert sha(Path(j[k]))==j[k+'_sha256']
 j.update(adopted_from=str(p),new_mapper_run=False)
(out/'campaign.json').write_text(json.dumps(new,indent=2)+'\n');(out/'adoption.json').write_text(json.dumps(dict(source=str(p),source_sha256=sha(p),source_slots=4,all_source_successes_and_failures_retained=True,executed_dependencies_identical=True,design_scope_extended_without_source_or_parameter_change=True,new_mapper_attempts_required=76,adoption_script_sha256=sha(Path(__file__))),indent=2)+'\n')
