"""Size-only exact two-AND cone contraction plan; no mapped/budget proof."""
import json,sys,collections,hashlib
from pathlib import Path
ROOT=Path('/home/flynn/workplace/MIGBalance');sys.path.insert(0,str(ROOT/'scripts/experiments'))
from analyze_epfl_structural_budget import read_binary_aig
out=[]
for r in json.load(open(ROOT/'results_v2/epfl_resyn2_subjects_20261012/report.json'))['results']:
 b=r['bench'];p=ROOT/f'results_v2/epfl_resyn2_subjects_20261012/{b}.resyn2.aig';data=p.read_bytes();assert hashlib.sha256(data).hexdigest()==r['preprocessing']['sha256'];n,po,g=read_binary_aig(data);mac={};uses=collections.Counter(x//2 for v in g.values() for x in v);uses.update(x//2 for x in po)
 for v,(a,c) in g.items():
  if a&1 and c&1 and a//2 in g and c//2 in g:
   x,y=g[a//2],g[c//2]
   if sorted(x)==sorted(z^1 for z in y):mac[v]=('xor',tuple(sorted({z//2 for z in x})));continue
  for child,other in [(a//2,c//2),(c//2,a//2)]:
   if child in g and uses[child]==1 and mac.get(child,('',))[0]!='xor':
    leaves=tuple(sorted({other,*[x//2 for x in g[child]]}))
    if len(leaves)<=3:mac[v]=('tt3',leaves);break
 live=set();stack=[x//2 for x in po]
 while stack:
  v=stack.pop()
  if v<=n or v in live:continue
  live.add(v);stack.extend(mac[v][1] if v in mac else [x//2 for x in g[v]])
 row=dict(bench=b,source_sha256=hashlib.sha256(data).hexdigest(),original_ands=len(g),planned_operators=len(live),pi=n,zero=1,output_not_upper=len({x//2 for x in po if x&1}),macro_kinds=dict(collections.Counter(mac[v][0] for v in live if v in mac)),scope='Plan estimate, not actual import/cuts/CEC/PPA; TT3 exact truth evaluation and compatible cell fallback not yet implemented')
 row['upper']=len(live)+n+1+row['output_not_upper'];out.append(row);print(b,row['upper'],row['macro_kinds'])
Path(__file__).with_name('xor_tt3_estimate.json').write_text(json.dumps(out,indent=2))
