"""Archive immutable research sources/binaries and clarify diagnostic counters."""
from pathlib import Path
import hashlib,json,shutil,difflib
ROOT=Path('/home/flynn/workplace/MIGBalance');OUT=ROOT/'results_v2/cone_import_implementation_20261015';OUT.mkdir(exist_ok=False);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();manifest={}
for name in ['frontier-pool','frontier-tail','frontier-fast','frontier-dag-tail','xor-import','tt3-import','tt3-witness','tt3-helpers']:
 src=Path('/tmp/emapper-'+name+'-20261015');out=OUT/name;out.mkdir();files=['Cargo.toml','Cargo.lock','emapper/Cargo.toml','src/bin/bench_rs_egraph_map.rs',*[str(p.relative_to(src)) for p in sorted((src/'emapper/src').glob('*.rs'))],*[str(p.relative_to(src)) for p in sorted((src/'emapper/tests/fixtures').glob('*')) if p.is_file()]]
 for rel in files:
  dst=out/'source'/rel;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src/rel,dst)
 shutil.copy2(src/'target/release/bench_rs_egraph_map',out/'mapper.bin')
 for rel in ['emapper/src/egraph_map.rs','emapper/src/egraph_sat.rs','emapper/src/egraph_regions.rs']:
  (out/(Path(rel).stem+'.patch')).write_text(''.join(difflib.unified_diff((ROOT/rel).read_text().splitlines(True),(src/rel).read_text().splitlines(True),fromfile='validated-main/'+rel,tofile=name+'/'+rel)))
 hashes={str(p.relative_to(out)):sha(p) for p in out.rglob('*') if p.is_file()};(out/'hashes.json').write_text(json.dumps(hashes,indent=2)+'\n');manifest[name]=dict(source=str(src),mapper_sha256=sha(out/'mapper.bin'),hash_manifest_sha256=sha(out/'hashes.json'))
script_dir=OUT/'implementation_scripts';script_dir.mkdir()
for name in ['edit_frontier_pool.py','implement_xor_import.py','prepare_frontier_tail.py','prepare_frontier_fast.py','prepare_frontier_dag_tail.py','implement_tt3_import.py','implement_tt3_witness.py','implement_tt3_helpers.py']:
 shutil.copy2(Path('/tmp')/name,script_dir/name)
for path in (ROOT/'results_v2/frontier_pool_diagnosis_20261015').glob('*.log'):shutil.copy2(path,script_dir/path.name)
errata=[]
for name in ['frontier_pool_pilot','frontier_tail_pilot','frontier_fast_pilot','frontier_dag_tail_pilot','xor_import_pilot','xor_import_full','tt3_import_pilot','tt3_witness_pilot','tt3_helpers_pilot','tt3_helpers_full']:
 p=ROOT/f'results_v2/{name}_20261015/campaign.json';c=json.loads(p.read_text());proof=[]
 for j in c['jobs']:
  if 'report' not in j:continue
  row=json.loads(Path(j['report']).read_text())['results'][0]
  assert all(row['settings'][k]=='1' for k in ['EGM_FAST_DELAY_SEED','EGM_REQUIRED_AREA_DAG','EGM_DEFER_AREA_DAG','EGM_PRESERVE_LEGACY_SEEDS','EGM_METRIC_EPOCHS'])
  proof.append(dict(job=j['name'],report=j['report'],report_sha256=sha(Path(j['report']))))
 errata.append(dict(campaign=str(p),campaign_sha256=sha(p),control_is_current_validated_protected_recovery=True,original_prose_not_authoritative_for_flags=True,proof=proof))
(OUT/'scope_errata.json').write_text(json.dumps(errata,indent=2)+'\n')
(OUT/'counter_semantics.json').write_text(json.dumps(dict(actual_budget_fields=['native.imported_enodes','native.enodes','native.max_cuts_per_class','native.instances','native.heuristic_secs'],legacy_diagnostic_label_errata={'actual_helpers':'selected source helper occurrences, each materialized/hash-consed; not necessarily distinct final classes','retained_xor_operators':'source XOR occurrences, not unique e-nodes','retained_tt3_operators':'source TT3 occurrences, not unique e-nodes'},no_budget_limit_uses_occurrence_counters=True,main_binary_unchanged=sha(ROOT/'target/release/bench_rs_egraph_map'),baseline_algorithms_changed=False),indent=2)+'\n')
(OUT/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print('Archived',len(manifest),'versions; main unchanged',sha(ROOT/'target/release/bench_rs_egraph_map'))
