"""Reuse all four same-source pilot observations, without outcome selection."""
import copy,hashlib,json,sys
from pathlib import Path
ROOT=Path('/home/flynn/workplace/MIGBalance');sys.path.insert(0,str(ROOT/'scripts/experiments'));from benchmark_suites import EPFL
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
p=ROOT/'results_v2/tt3_helpers_pilot_20261015/campaign.json';old=json.loads(p.read_text());assert old['status']=='attempted' and len(old['jobs'])==old['expected_jobs']==4
assert all(sha(Path(p))==h for p,h in old['fingerprint'].items())
out=ROOT/'results_v2/tt3_helpers_full_20261015';out.mkdir(exist_ok=False);new=copy.deepcopy(old);new.update(designs=EPFL,expected_jobs=80,status='checkpointed',scope='Current validated protected-incumbent control versus exact bounded cone import with structural-slack helper groups quota2048 and10% preimport optional-helper reserve. Both profiles keep fast frontier/DAG/legacy-seed preservation/epoch flags ON. Only EGM_XOR_IMPORT differs (plus diagnostic/output paths). Same input/library/node/cut/retained-pool/SAT/recovery/mapping limits; no baseline algorithm changes.')
for j in new['jobs']:
 for k in ['report','audit','pool','candidates','trace','diagnostic_profile']:
  if k in j:assert sha(Path(j[k]))==j[k+'_sha256']
 row=json.loads(Path(j['report']).read_text())['results'][0]
 assert all(row['settings'][k]=='1' for k in ['EGM_FAST_DELAY_SEED','EGM_REQUIRED_AREA_DAG','EGM_DEFER_AREA_DAG','EGM_PRESERVE_LEGACY_SEEDS','EGM_METRIC_EPOCHS'])
 j.update(adopted_from=str(p),new_mapper_run=False)
(out/'campaign.json').write_text(json.dumps(new,indent=2)+'\n');(out/'adoption.json').write_text(json.dumps(dict(source=str(p),source_sha256=sha(p),source_slots=4,all_source_outcomes_retained=True,executed_dependencies_identical=True,new_mapper_attempts_required=76,metadata_erratum='Inherited pilot scope prose incorrectly described a disabled frontier control. Actual fixed_profiles/argv/settings show both profiles use the validated protected recovery. This new scope corrects prose without modifying original pilot records or algorithms.',adoption_script_sha256=sha(Path(__file__))),indent=2)+'\n')
