// Benchmark "/home/flynn/workplace/MIGBalance/results_v2/emorphic_random_delay_20261012/c1908/rewritten_egraph_with_weight_cost_serd_random-based-faster-bottom-up_2/logic" written by ABC on Mon Oct 12 14:25:24 2026

module \/home/flynn/workplace/MIGBalance/results_v2/emorphic_random_delay_20261012/c1908/rewritten_egraph_with_weight_cost_serd_random-based-faster-bottom-up_2/logic  ( 
    G24, G33, G31, G30, G32, G8, G6, G3, G15, G10, G12, G19, G28, G9, G14,
    G16, G18, G11, G5, G2, G27, G7, G4, G20, G13, G1, G17, G26, G22, G25,
    G21, G29, G23,
    G1899, G1884, G1885, G1898, G1886, G1887, G1888, G1889, G1890, G1891,
    G1892, G1893, G1894, G1895, G1896, G1897, G1900, G1901, G1902, G1903,
    G1904, G1905, G1906, G1907, G1908  );
  input  G24, G33, G31, G30, G32, G8, G6, G3, G15, G10, G12, G19, G28,
    G9, G14, G16, G18, G11, G5, G2, G27, G7, G4, G20, G13, G1, G17, G26,
    G22, G25, G21, G29, G23;
  output G1899, G1884, G1885, G1898, G1886, G1887, G1888, G1889, G1890, G1891,
    G1892, G1893, G1894, G1895, G1896, G1897, G1900, G1901, G1902, G1903,
    G1904, G1905, G1906, G1907, G1908;
  wire new_n59_, new_n60_, new_n61_, new_n62_, new_n63_, new_n64_, new_n65_,
    new_n66_, new_n67_, new_n68_, new_n69_, new_n70_, new_n71_, new_n72_,
    new_n73_, new_n74_, new_n75_, new_n76_, new_n77_, new_n78_, new_n79_,
    new_n80_, new_n81_, new_n82_, new_n83_, new_n84_, new_n85_, new_n86_,
    new_n87_, new_n88_, new_n89_, new_n90_, new_n91_, new_n92_, new_n93_,
    new_n94_, new_n95_, new_n96_, new_n97_, new_n98_, new_n99_, new_n100_,
    new_n101_, new_n102_, new_n103_, new_n104_, new_n105_, new_n106_,
    new_n107_, new_n108_, new_n109_, new_n110_, new_n111_, new_n112_,
    new_n113_, new_n114_, new_n115_, new_n116_, new_n117_, new_n118_,
    new_n119_, new_n120_, new_n121_, new_n122_, new_n123_, new_n124_,
    new_n125_, new_n126_, new_n127_, new_n128_, new_n129_, new_n130_,
    new_n131_, new_n132_, new_n133_, new_n134_, new_n135_, new_n136_,
    new_n137_, new_n138_, new_n139_, new_n140_, new_n141_, new_n142_,
    new_n143_, new_n144_, new_n145_, new_n146_, new_n147_, new_n148_,
    new_n149_, new_n150_, new_n151_, new_n152_, new_n153_, new_n154_,
    new_n155_, new_n156_, new_n157_, new_n158_, new_n159_, new_n160_,
    new_n161_, new_n162_, new_n163_, new_n164_, new_n165_, new_n166_,
    new_n167_, new_n168_, new_n169_, new_n170_, new_n171_, new_n172_,
    new_n173_, new_n174_, new_n175_, new_n176_, new_n177_, new_n178_,
    new_n179_, new_n180_, new_n181_, new_n182_, new_n183_, new_n184_,
    new_n185_, new_n186_, new_n187_, new_n188_, new_n189_, new_n190_,
    new_n191_, new_n192_, new_n193_, new_n194_, new_n195_, new_n196_,
    new_n197_, new_n198_, new_n199_, new_n200_, new_n201_, new_n202_,
    new_n203_, new_n204_, new_n205_, new_n206_, new_n207_, new_n208_,
    new_n209_, new_n210_, new_n211_, new_n212_, new_n213_, new_n214_,
    new_n215_, new_n216_, new_n217_, new_n218_, new_n219_, new_n220_,
    new_n221_, new_n222_, new_n223_, new_n224_, new_n225_, new_n226_,
    new_n227_, new_n228_, new_n229_, new_n230_, new_n231_, new_n232_,
    new_n233_, new_n234_, new_n235_, new_n236_, new_n237_, new_n238_,
    new_n239_, new_n240_, new_n241_, new_n242_, new_n243_, new_n244_,
    new_n245_, new_n246_, new_n247_, new_n248_, new_n249_, new_n250_,
    new_n251_, new_n252_, new_n253_, new_n254_, new_n255_, new_n256_,
    new_n257_, new_n258_, new_n259_, new_n260_, new_n261_, new_n262_,
    new_n263_, new_n264_, new_n265_, new_n266_, new_n267_, new_n268_,
    new_n269_, new_n270_, new_n271_, new_n272_, new_n273_, new_n274_,
    new_n275_, new_n276_, new_n277_, new_n278_, new_n279_, new_n280_,
    new_n281_, new_n282_, new_n283_, new_n284_, new_n285_, new_n286_,
    new_n287_, new_n288_, new_n289_, new_n290_, new_n291_, new_n292_,
    new_n293_, new_n294_, new_n295_, new_n296_, new_n297_, new_n298_,
    new_n299_, new_n300_, new_n301_, new_n302_, new_n303_, new_n304_,
    new_n305_, new_n306_, new_n307_, new_n308_, new_n309_, new_n310_,
    new_n311_, new_n312_, new_n313_, new_n314_, new_n315_, new_n316_,
    new_n317_, new_n318_, new_n319_, new_n320_, new_n321_, new_n322_,
    new_n323_, new_n324_, new_n325_, new_n326_, new_n327_, new_n328_,
    new_n329_, new_n330_, new_n331_, new_n333_, new_n334_, new_n335_,
    new_n336_, new_n337_, new_n338_, new_n339_, new_n340_, new_n341_,
    new_n342_, new_n343_, new_n344_, new_n345_, new_n346_, new_n347_,
    new_n348_, new_n349_, new_n350_, new_n351_, new_n352_, new_n353_,
    new_n354_, new_n355_, new_n356_, new_n357_, new_n358_, new_n359_,
    new_n360_, new_n361_, new_n362_, new_n363_, new_n364_, new_n365_,
    new_n367_, new_n368_, new_n369_, new_n371_, new_n372_, new_n374_,
    new_n375_, new_n376_, new_n378_, new_n379_, new_n380_, new_n382_,
    new_n383_, new_n384_, new_n385_, new_n386_, new_n387_, new_n389_,
    new_n390_, new_n392_, new_n393_, new_n395_, new_n396_, new_n397_,
    new_n398_, new_n399_, new_n400_, new_n401_, new_n402_, new_n404_,
    new_n405_, new_n406_, new_n407_, new_n409_, new_n410_, new_n412_,
    new_n413_, new_n414_, new_n416_, new_n417_, new_n418_, new_n419_,
    new_n421_, new_n422_, new_n424_, new_n425_, new_n427_, new_n428_,
    new_n429_, new_n430_, new_n431_, new_n432_, new_n433_, new_n434_,
    new_n435_, new_n436_, new_n437_, new_n438_, new_n439_, new_n440_,
    new_n441_, new_n442_, new_n443_, new_n444_, new_n445_, new_n446_,
    new_n447_, new_n448_, new_n449_, new_n450_, new_n451_, new_n452_,
    new_n453_, new_n454_, new_n455_, new_n456_, new_n457_, new_n458_,
    new_n459_, new_n460_, new_n461_, new_n463_, new_n464_, new_n465_,
    new_n466_, new_n467_, new_n468_, new_n469_, new_n470_, new_n471_,
    new_n473_, new_n474_, new_n475_, new_n476_, new_n478_, new_n479_,
    new_n480_, new_n481_, new_n482_, new_n484_, new_n485_, new_n486_,
    new_n487_, new_n488_, new_n490_, new_n491_, new_n492_, new_n493_,
    new_n494_, new_n496_, new_n497_, new_n498_, new_n499_, new_n500_,
    new_n501_, new_n502_, new_n503_, new_n504_, new_n505_, new_n506_,
    new_n507_, new_n508_, new_n509_, new_n510_, new_n512_, new_n513_,
    new_n514_, new_n515_, new_n516_, new_n517_, new_n518_, new_n519_,
    new_n520_, new_n521_, new_n522_, new_n523_, new_n524_, new_n525_,
    new_n526_, new_n527_, new_n529_, new_n530_, new_n531_, new_n532_,
    new_n533_, new_n534_, new_n535_, new_n536_, new_n537_;
  INVx1_ASAP7_75t_R   g000(.A(G24), .Y(new_n59_));
  INVx1_ASAP7_75t_R   g001(.A(G33), .Y(new_n60_));
  INVx1_ASAP7_75t_R   g002(.A(G31), .Y(new_n61_));
  INVx1_ASAP7_75t_R   g003(.A(G8), .Y(new_n62_));
  INVx1_ASAP7_75t_R   g004(.A(G6), .Y(new_n63_));
  INVx1_ASAP7_75t_R   g005(.A(G3), .Y(new_n64_));
  INVx1_ASAP7_75t_R   g006(.A(G15), .Y(new_n65_));
  INVx1_ASAP7_75t_R   g007(.A(G10), .Y(new_n66_));
  INVx1_ASAP7_75t_R   g008(.A(G12), .Y(new_n67_));
  INVx1_ASAP7_75t_R   g009(.A(G19), .Y(new_n68_));
  INVx1_ASAP7_75t_R   g010(.A(G28), .Y(new_n69_));
  INVx1_ASAP7_75t_R   g011(.A(G9), .Y(new_n70_));
  INVx1_ASAP7_75t_R   g012(.A(G14), .Y(new_n71_));
  INVx1_ASAP7_75t_R   g013(.A(G16), .Y(new_n72_));
  INVx1_ASAP7_75t_R   g014(.A(G18), .Y(new_n73_));
  INVx1_ASAP7_75t_R   g015(.A(G11), .Y(new_n74_));
  INVx1_ASAP7_75t_R   g016(.A(G5), .Y(new_n75_));
  INVx1_ASAP7_75t_R   g017(.A(G2), .Y(new_n76_));
  INVx1_ASAP7_75t_R   g018(.A(G27), .Y(new_n77_));
  INVx1_ASAP7_75t_R   g019(.A(G7), .Y(new_n78_));
  INVx1_ASAP7_75t_R   g020(.A(G4), .Y(new_n79_));
  INVx1_ASAP7_75t_R   g021(.A(G20), .Y(new_n80_));
  INVx1_ASAP7_75t_R   g022(.A(G13), .Y(new_n81_));
  INVx1_ASAP7_75t_R   g023(.A(G1), .Y(new_n82_));
  INVx1_ASAP7_75t_R   g024(.A(G17), .Y(new_n83_));
  INVx1_ASAP7_75t_R   g025(.A(G26), .Y(new_n84_));
  INVx1_ASAP7_75t_R   g026(.A(G25), .Y(new_n85_));
  INVx1_ASAP7_75t_R   g027(.A(G23), .Y(new_n86_));
  XOR2x2_ASAP7_75t_R  g028(.A(G8), .B(new_n79_), .Y(new_n87_));
  INVx1_ASAP7_75t_R   g029(.A(new_n87_), .Y(new_n88_));
  NOR2x1_ASAP7_75t_R  g030(.A(new_n63_), .B(new_n78_), .Y(new_n89_));
  NOR2x1_ASAP7_75t_R  g031(.A(G6), .B(G7), .Y(new_n90_));
  OR3x1_ASAP7_75t_R   g032(.A(G5), .B(new_n90_), .C(new_n89_), .Y(new_n91_));
  INVx1_ASAP7_75t_R   g033(.A(new_n91_), .Y(new_n92_));
  AND3x1_ASAP7_75t_R  g034(.A(G6), .B(G7), .C(G5), .Y(new_n93_));
  AO21x1_ASAP7_75t_R  g035(.A1(G5), .A2(new_n90_), .B(new_n93_), .Y(new_n94_));
  NOR2x1_ASAP7_75t_R  g036(.A(new_n92_), .B(new_n94_), .Y(new_n95_));
  NAND2x1_ASAP7_75t_R g037(.A(new_n64_), .B(new_n76_), .Y(new_n96_));
  NAND2x1_ASAP7_75t_R g038(.A(G3), .B(G2), .Y(new_n97_));
  AOI21x1_ASAP7_75t_R g039(.A1(new_n96_), .A2(new_n97_), .B(new_n82_), .Y(new_n98_));
  AND2x2_ASAP7_75t_R  g040(.A(new_n82_), .B(new_n96_), .Y(new_n99_));
  AO21x1_ASAP7_75t_R  g041(.A1(new_n97_), .A2(new_n99_), .B(new_n98_), .Y(new_n100_));
  OA21x2_ASAP7_75t_R  g042(.A1(new_n92_), .A2(new_n94_), .B(new_n100_), .Y(new_n101_));
  OR3x1_ASAP7_75t_R   g043(.A(G5), .B(new_n89_), .C(new_n90_), .Y(new_n102_));
  INVx1_ASAP7_75t_R   g044(.A(new_n102_), .Y(new_n103_));
  AO21x1_ASAP7_75t_R  g045(.A1(G6), .A2(G7), .B(new_n90_), .Y(new_n104_));
  AO21x1_ASAP7_75t_R  g046(.A1(G5), .A2(new_n104_), .B(new_n103_), .Y(new_n105_));
  INVx1_ASAP7_75t_R   g047(.A(new_n105_), .Y(new_n106_));
  AND2x2_ASAP7_75t_R  g048(.A(new_n82_), .B(new_n97_), .Y(new_n107_));
  AO21x1_ASAP7_75t_R  g049(.A1(new_n96_), .A2(new_n107_), .B(new_n98_), .Y(new_n108_));
  INVx1_ASAP7_75t_R   g050(.A(new_n108_), .Y(new_n109_));
  NOR2x1_ASAP7_75t_R  g051(.A(new_n105_), .B(new_n108_), .Y(new_n110_));
  OA21x2_ASAP7_75t_R  g052(.A1(new_n101_), .A2(new_n110_), .B(new_n87_), .Y(new_n111_));
  OR3x1_ASAP7_75t_R   g053(.A(new_n92_), .B(new_n94_), .C(new_n100_), .Y(new_n112_));
  NAND2x1_ASAP7_75t_R g054(.A(new_n105_), .B(new_n108_), .Y(new_n113_));
  AND3x1_ASAP7_75t_R  g055(.A(new_n88_), .B(new_n112_), .C(new_n113_), .Y(new_n114_));
  NOR2x1_ASAP7_75t_R  g056(.A(new_n111_), .B(new_n114_), .Y(new_n115_));
  NAND2x1_ASAP7_75t_R g057(.A(new_n60_), .B(G21), .Y(new_n116_));
  INVx1_ASAP7_75t_R   g058(.A(new_n116_), .Y(new_n117_));
  NOR2x1_ASAP7_75t_R  g059(.A(new_n65_), .B(new_n72_), .Y(new_n118_));
  INVx1_ASAP7_75t_R   g060(.A(new_n118_), .Y(new_n119_));
  NOR2x1_ASAP7_75t_R  g061(.A(G15), .B(G16), .Y(new_n120_));
  INVx1_ASAP7_75t_R   g062(.A(new_n120_), .Y(new_n121_));
  AND3x1_ASAP7_75t_R  g063(.A(new_n66_), .B(new_n119_), .C(new_n121_), .Y(new_n122_));
  OA21x2_ASAP7_75t_R  g064(.A1(new_n118_), .A2(new_n120_), .B(G10), .Y(new_n123_));
  NOR2x1_ASAP7_75t_R  g065(.A(new_n122_), .B(new_n123_), .Y(new_n124_));
  NOR2x1_ASAP7_75t_R  g066(.A(G9), .B(new_n124_), .Y(new_n125_));
  AND3x1_ASAP7_75t_R  g067(.A(new_n66_), .B(new_n121_), .C(new_n119_), .Y(new_n126_));
  OR3x1_ASAP7_75t_R   g068(.A(new_n70_), .B(new_n126_), .C(new_n123_), .Y(new_n127_));
  INVx1_ASAP7_75t_R   g069(.A(new_n127_), .Y(new_n128_));
  OA21x2_ASAP7_75t_R  g070(.A1(new_n125_), .A2(new_n128_), .B(new_n117_), .Y(new_n129_));
  OR3x1_ASAP7_75t_R   g071(.A(new_n70_), .B(new_n122_), .C(new_n123_), .Y(new_n130_));
  AO21x1_ASAP7_75t_R  g072(.A1(new_n70_), .A2(new_n126_), .B(new_n117_), .Y(new_n131_));
  AOI21x1_ASAP7_75t_R g073(.A1(new_n70_), .A2(new_n123_), .B(new_n131_), .Y(new_n132_));
  AO21x1_ASAP7_75t_R  g074(.A1(new_n130_), .A2(new_n132_), .B(new_n129_), .Y(new_n133_));
  AND2x2_ASAP7_75t_R  g075(.A(new_n115_), .B(new_n133_), .Y(new_n134_));
  OR3x1_ASAP7_75t_R   g076(.A(new_n117_), .B(new_n128_), .C(new_n125_), .Y(new_n135_));
  INVx1_ASAP7_75t_R   g077(.A(new_n135_), .Y(new_n136_));
  NOR2x1_ASAP7_75t_R  g078(.A(new_n116_), .B(new_n130_), .Y(new_n137_));
  NOR2x1_ASAP7_75t_R  g079(.A(new_n123_), .B(new_n126_), .Y(new_n138_));
  INVx1_ASAP7_75t_R   g080(.A(new_n138_), .Y(new_n139_));
  AND3x1_ASAP7_75t_R  g081(.A(new_n70_), .B(new_n139_), .C(new_n117_), .Y(new_n140_));
  OR3x1_ASAP7_75t_R   g082(.A(new_n137_), .B(new_n140_), .C(new_n136_), .Y(new_n141_));
  INVx1_ASAP7_75t_R   g083(.A(new_n141_), .Y(new_n142_));
  OR3x1_ASAP7_75t_R   g084(.A(new_n87_), .B(new_n101_), .C(new_n110_), .Y(new_n143_));
  AO21x1_ASAP7_75t_R  g085(.A1(new_n112_), .A2(new_n113_), .B(new_n88_), .Y(new_n144_));
  NAND2x1_ASAP7_75t_R g086(.A(new_n143_), .B(new_n144_), .Y(new_n145_));
  INVx1_ASAP7_75t_R   g087(.A(new_n145_), .Y(new_n146_));
  NOR2x1_ASAP7_75t_R  g088(.A(new_n141_), .B(new_n146_), .Y(new_n147_));
  OR3x1_ASAP7_75t_R   g089(.A(G31), .B(new_n147_), .C(new_n134_), .Y(new_n148_));
  INVx1_ASAP7_75t_R   g090(.A(new_n148_), .Y(new_n149_));
  NOR2x1_ASAP7_75t_R  g091(.A(G24), .B(G31), .Y(new_n150_));
  AO21x1_ASAP7_75t_R  g092(.A1(new_n59_), .A2(new_n61_), .B(new_n83_), .Y(new_n151_));
  INVx1_ASAP7_75t_R   g093(.A(new_n151_), .Y(new_n152_));
  NOR2x1_ASAP7_75t_R  g094(.A(new_n149_), .B(new_n151_), .Y(new_n153_));
  NOR2x1_ASAP7_75t_R  g095(.A(new_n115_), .B(new_n133_), .Y(new_n154_));
  AO21x1_ASAP7_75t_R  g096(.A1(new_n141_), .A2(new_n146_), .B(new_n152_), .Y(new_n155_));
  OR3x1_ASAP7_75t_R   g097(.A(G31), .B(new_n154_), .C(new_n155_), .Y(new_n156_));
  INVx1_ASAP7_75t_R   g098(.A(new_n156_), .Y(new_n157_));
  AO21x1_ASAP7_75t_R  g099(.A1(new_n59_), .A2(new_n61_), .B(new_n73_), .Y(new_n158_));
  INVx1_ASAP7_75t_R   g100(.A(new_n158_), .Y(new_n159_));
  OR3x1_ASAP7_75t_R   g101(.A(new_n157_), .B(new_n158_), .C(new_n153_), .Y(new_n160_));
  NOR2x1_ASAP7_75t_R  g102(.A(G31), .B(G23), .Y(new_n161_));
  AO21x1_ASAP7_75t_R  g103(.A1(new_n61_), .A2(new_n86_), .B(new_n80_), .Y(new_n162_));
  INVx1_ASAP7_75t_R   g104(.A(new_n162_), .Y(new_n163_));
  NAND2x1_ASAP7_75t_R g105(.A(new_n60_), .B(G22), .Y(new_n164_));
  XOR2x2_ASAP7_75t_R  g106(.A(new_n71_), .B(new_n79_), .Y(new_n165_));
  XOR2x2_ASAP7_75t_R  g107(.A(new_n164_), .B(new_n165_), .Y(new_n166_));
  INVx1_ASAP7_75t_R   g108(.A(new_n166_), .Y(new_n167_));
  NAND2x1_ASAP7_75t_R g109(.A(G12), .B(G13), .Y(new_n168_));
  NAND2x1_ASAP7_75t_R g110(.A(new_n67_), .B(new_n81_), .Y(new_n169_));
  AOI21x1_ASAP7_75t_R g111(.A1(new_n168_), .A2(new_n169_), .B(new_n74_), .Y(new_n170_));
  AND2x2_ASAP7_75t_R  g112(.A(new_n74_), .B(new_n169_), .Y(new_n171_));
  AO21x1_ASAP7_75t_R  g113(.A1(new_n168_), .A2(new_n171_), .B(new_n170_), .Y(new_n172_));
  NOR2x1_ASAP7_75t_R  g114(.A(new_n108_), .B(new_n138_), .Y(new_n173_));
  AND3x1_ASAP7_75t_R  g115(.A(new_n100_), .B(new_n124_), .C(new_n172_), .Y(new_n174_));
  AO21x1_ASAP7_75t_R  g116(.A1(new_n172_), .A2(new_n173_), .B(new_n174_), .Y(new_n175_));
  NOR2x1_ASAP7_75t_R  g117(.A(new_n100_), .B(new_n124_), .Y(new_n176_));
  AND2x2_ASAP7_75t_R  g118(.A(new_n74_), .B(new_n168_), .Y(new_n177_));
  AO21x1_ASAP7_75t_R  g119(.A1(new_n169_), .A2(new_n177_), .B(new_n170_), .Y(new_n178_));
  NOR2x1_ASAP7_75t_R  g120(.A(new_n176_), .B(new_n178_), .Y(new_n179_));
  OA21x2_ASAP7_75t_R  g121(.A1(new_n109_), .A2(new_n139_), .B(new_n179_), .Y(new_n180_));
  AND2x2_ASAP7_75t_R  g122(.A(new_n167_), .B(new_n180_), .Y(new_n181_));
  AO21x1_ASAP7_75t_R  g123(.A1(new_n167_), .A2(new_n175_), .B(new_n181_), .Y(new_n182_));
  AO21x1_ASAP7_75t_R  g124(.A1(new_n109_), .A2(new_n139_), .B(new_n172_), .Y(new_n183_));
  AOI21x1_ASAP7_75t_R g125(.A1(new_n100_), .A2(new_n124_), .B(new_n183_), .Y(new_n184_));
  AO21x1_ASAP7_75t_R  g126(.A1(new_n108_), .A2(new_n138_), .B(new_n176_), .Y(new_n185_));
  AOI21x1_ASAP7_75t_R g127(.A1(new_n178_), .A2(new_n185_), .B(new_n184_), .Y(new_n186_));
  AO21x1_ASAP7_75t_R  g128(.A1(new_n166_), .A2(new_n186_), .B(new_n182_), .Y(new_n187_));
  AOI21x1_ASAP7_75t_R g129(.A1(new_n61_), .A2(new_n187_), .B(new_n85_), .Y(new_n188_));
  NOR2x1_ASAP7_75t_R  g130(.A(G31), .B(G25), .Y(new_n189_));
  OR3x1_ASAP7_75t_R   g131(.A(new_n167_), .B(new_n175_), .C(new_n180_), .Y(new_n190_));
  OA21x2_ASAP7_75t_R  g132(.A1(new_n166_), .A2(new_n186_), .B(new_n190_), .Y(new_n191_));
  OR3x1_ASAP7_75t_R   g133(.A(G31), .B(G25), .C(new_n191_), .Y(new_n192_));
  INVx1_ASAP7_75t_R   g134(.A(new_n192_), .Y(new_n193_));
  OA21x2_ASAP7_75t_R  g135(.A1(new_n188_), .A2(new_n193_), .B(new_n163_), .Y(new_n194_));
  OR2x4_ASAP7_75t_R   g136(.A(new_n160_), .B(new_n194_), .Y(new_n195_));
  NOR2x1_ASAP7_75t_R  g137(.A(G24), .B(G33), .Y(new_n196_));
  INVx1_ASAP7_75t_R   g138(.A(new_n196_), .Y(new_n197_));
  AND3x1_ASAP7_75t_R  g139(.A(G1), .B(G17), .C(new_n196_), .Y(new_n198_));
  OA21x2_ASAP7_75t_R  g140(.A1(new_n83_), .A2(new_n197_), .B(new_n82_), .Y(new_n199_));
  NOR2x1_ASAP7_75t_R  g141(.A(new_n198_), .B(new_n199_), .Y(new_n200_));
  NOR2x1_ASAP7_75t_R  g142(.A(new_n138_), .B(new_n178_), .Y(new_n201_));
  AO21x1_ASAP7_75t_R  g143(.A1(new_n124_), .A2(new_n172_), .B(new_n201_), .Y(new_n202_));
  NOR2x1_ASAP7_75t_R  g144(.A(new_n106_), .B(new_n202_), .Y(new_n203_));
  NOR2x1_ASAP7_75t_R  g145(.A(new_n124_), .B(new_n172_), .Y(new_n204_));
  AO21x1_ASAP7_75t_R  g146(.A1(new_n138_), .A2(new_n178_), .B(new_n204_), .Y(new_n205_));
  AO21x1_ASAP7_75t_R  g147(.A1(new_n95_), .A2(new_n205_), .B(new_n203_), .Y(new_n206_));
  AND3x1_ASAP7_75t_R  g148(.A(new_n124_), .B(new_n172_), .C(new_n106_), .Y(new_n207_));
  AO21x1_ASAP7_75t_R  g149(.A1(new_n106_), .A2(new_n201_), .B(new_n207_), .Y(new_n208_));
  NOR2x1_ASAP7_75t_R  g150(.A(new_n95_), .B(new_n205_), .Y(new_n209_));
  NOR2x1_ASAP7_75t_R  g151(.A(G24), .B(new_n83_), .Y(new_n210_));
  AND3x1_ASAP7_75t_R  g152(.A(new_n60_), .B(G1), .C(new_n210_), .Y(new_n211_));
  NOR2x1_ASAP7_75t_R  g153(.A(new_n199_), .B(new_n211_), .Y(new_n212_));
  INVx1_ASAP7_75t_R   g154(.A(new_n212_), .Y(new_n213_));
  OR3x1_ASAP7_75t_R   g155(.A(new_n209_), .B(new_n212_), .C(new_n208_), .Y(new_n214_));
  INVx1_ASAP7_75t_R   g156(.A(new_n214_), .Y(new_n215_));
  AO21x1_ASAP7_75t_R  g157(.A1(new_n200_), .A2(new_n206_), .B(new_n215_), .Y(new_n216_));
  AOI21x1_ASAP7_75t_R g158(.A1(new_n61_), .A2(new_n216_), .B(new_n84_), .Y(new_n217_));
  NOR2x1_ASAP7_75t_R  g159(.A(new_n208_), .B(new_n209_), .Y(new_n218_));
  NOR2x1_ASAP7_75t_R  g160(.A(new_n213_), .B(new_n218_), .Y(new_n219_));
  NOR2x1_ASAP7_75t_R  g161(.A(new_n200_), .B(new_n206_), .Y(new_n220_));
  INVx1_ASAP7_75t_R   g162(.A(new_n220_), .Y(new_n221_));
  NOR2x1_ASAP7_75t_R  g163(.A(G31), .B(G26), .Y(new_n222_));
  OA21x2_ASAP7_75t_R  g164(.A1(new_n219_), .A2(new_n220_), .B(new_n222_), .Y(new_n223_));
  AO21x1_ASAP7_75t_R  g165(.A1(new_n61_), .A2(new_n86_), .B(new_n68_), .Y(new_n224_));
  INVx1_ASAP7_75t_R   g166(.A(new_n224_), .Y(new_n225_));
  XNOR2x2_ASAP7_75t_R g167(.A(new_n66_), .B(G7), .Y(new_n226_));
  XOR2x2_ASAP7_75t_R  g168(.A(new_n79_), .B(new_n226_), .Y(new_n227_));
  NAND2x1_ASAP7_75t_R g169(.A(G9), .B(G14), .Y(new_n228_));
  NAND2x1_ASAP7_75t_R g170(.A(new_n70_), .B(new_n71_), .Y(new_n229_));
  AOI21x1_ASAP7_75t_R g171(.A1(new_n228_), .A2(new_n229_), .B(new_n72_), .Y(new_n230_));
  AND2x2_ASAP7_75t_R  g172(.A(new_n72_), .B(new_n229_), .Y(new_n231_));
  AO21x1_ASAP7_75t_R  g173(.A1(new_n228_), .A2(new_n231_), .B(new_n230_), .Y(new_n232_));
  AND2x2_ASAP7_75t_R  g174(.A(new_n227_), .B(new_n232_), .Y(new_n233_));
  AND2x2_ASAP7_75t_R  g175(.A(new_n72_), .B(new_n228_), .Y(new_n234_));
  AO21x1_ASAP7_75t_R  g176(.A1(new_n229_), .A2(new_n234_), .B(new_n230_), .Y(new_n235_));
  INVx1_ASAP7_75t_R   g177(.A(new_n235_), .Y(new_n236_));
  NOR2x1_ASAP7_75t_R  g178(.A(new_n227_), .B(new_n235_), .Y(new_n237_));
  NOR2x1_ASAP7_75t_R  g179(.A(new_n80_), .B(G13), .Y(new_n238_));
  AND3x1_ASAP7_75t_R  g180(.A(new_n60_), .B(new_n86_), .C(new_n238_), .Y(new_n239_));
  INVx1_ASAP7_75t_R   g181(.A(new_n239_), .Y(new_n240_));
  OR3x1_ASAP7_75t_R   g182(.A(G33), .B(G23), .C(new_n80_), .Y(new_n241_));
  AO21x1_ASAP7_75t_R  g183(.A1(G13), .A2(new_n241_), .B(new_n239_), .Y(new_n242_));
  OR3x1_ASAP7_75t_R   g184(.A(new_n237_), .B(new_n242_), .C(new_n233_), .Y(new_n243_));
  NOR2x1_ASAP7_75t_R  g185(.A(new_n227_), .B(new_n232_), .Y(new_n244_));
  INVx1_ASAP7_75t_R   g186(.A(new_n244_), .Y(new_n245_));
  AOI21x1_ASAP7_75t_R g187(.A1(new_n227_), .A2(new_n235_), .B(new_n244_), .Y(new_n246_));
  NOR2x1_ASAP7_75t_R  g188(.A(new_n239_), .B(new_n241_), .Y(new_n247_));
  AO21x1_ASAP7_75t_R  g189(.A1(new_n81_), .A2(new_n240_), .B(new_n247_), .Y(new_n248_));
  INVx1_ASAP7_75t_R   g190(.A(new_n248_), .Y(new_n249_));
  OA21x2_ASAP7_75t_R  g191(.A1(new_n246_), .A2(new_n248_), .B(new_n243_), .Y(new_n250_));
  AND3x1_ASAP7_75t_R  g192(.A(new_n227_), .B(new_n232_), .C(new_n242_), .Y(new_n251_));
  AO21x1_ASAP7_75t_R  g193(.A1(new_n237_), .A2(new_n242_), .B(new_n251_), .Y(new_n252_));
  NOR2x1_ASAP7_75t_R  g194(.A(new_n227_), .B(new_n249_), .Y(new_n253_));
  AO21x1_ASAP7_75t_R  g195(.A1(new_n236_), .A2(new_n248_), .B(new_n253_), .Y(new_n254_));
  AO21x1_ASAP7_75t_R  g196(.A1(new_n245_), .A2(new_n254_), .B(new_n252_), .Y(new_n255_));
  INVx1_ASAP7_75t_R   g197(.A(new_n255_), .Y(new_n256_));
  AND3x1_ASAP7_75t_R  g198(.A(new_n61_), .B(new_n224_), .C(new_n255_), .Y(new_n257_));
  AO21x1_ASAP7_75t_R  g199(.A1(new_n225_), .A2(new_n250_), .B(new_n257_), .Y(new_n258_));
  AO21x1_ASAP7_75t_R  g200(.A1(G31), .A2(new_n225_), .B(new_n258_), .Y(new_n259_));
  OR3x1_ASAP7_75t_R   g201(.A(new_n223_), .B(new_n259_), .C(new_n217_), .Y(new_n260_));
  NAND2x1_ASAP7_75t_R g202(.A(G8), .B(new_n75_), .Y(new_n261_));
  NAND2x1_ASAP7_75t_R g203(.A(new_n62_), .B(G5), .Y(new_n262_));
  AND3x1_ASAP7_75t_R  g204(.A(G2), .B(new_n262_), .C(new_n261_), .Y(new_n263_));
  NAND2x1_ASAP7_75t_R g205(.A(new_n261_), .B(new_n262_), .Y(new_n264_));
  AO21x1_ASAP7_75t_R  g206(.A1(new_n76_), .A2(new_n264_), .B(new_n263_), .Y(new_n265_));
  AND3x1_ASAP7_75t_R  g207(.A(new_n59_), .B(new_n60_), .C(G18), .Y(new_n266_));
  NOR2x1_ASAP7_75t_R  g208(.A(new_n65_), .B(new_n266_), .Y(new_n267_));
  OR3x1_ASAP7_75t_R   g209(.A(G15), .B(new_n73_), .C(new_n197_), .Y(new_n268_));
  INVx1_ASAP7_75t_R   g210(.A(new_n268_), .Y(new_n269_));
  OR3x1_ASAP7_75t_R   g211(.A(new_n267_), .B(new_n269_), .C(new_n74_), .Y(new_n270_));
  NAND2x1_ASAP7_75t_R g212(.A(new_n59_), .B(G18), .Y(new_n271_));
  OR3x1_ASAP7_75t_R   g213(.A(G33), .B(G15), .C(new_n271_), .Y(new_n272_));
  INVx1_ASAP7_75t_R   g214(.A(new_n272_), .Y(new_n273_));
  AO21x1_ASAP7_75t_R  g215(.A1(new_n266_), .A2(new_n272_), .B(G11), .Y(new_n274_));
  AO21x1_ASAP7_75t_R  g216(.A1(new_n65_), .A2(new_n272_), .B(new_n274_), .Y(new_n275_));
  AND3x1_ASAP7_75t_R  g217(.A(new_n232_), .B(new_n270_), .C(new_n275_), .Y(new_n276_));
  INVx1_ASAP7_75t_R   g218(.A(new_n276_), .Y(new_n277_));
  NOR2x1_ASAP7_75t_R  g219(.A(G11), .B(new_n268_), .Y(new_n278_));
  AO21x1_ASAP7_75t_R  g220(.A1(new_n74_), .A2(new_n267_), .B(new_n278_), .Y(new_n279_));
  OR3x1_ASAP7_75t_R   g221(.A(new_n74_), .B(new_n273_), .C(new_n267_), .Y(new_n280_));
  INVx1_ASAP7_75t_R   g222(.A(new_n280_), .Y(new_n281_));
  OAI21x1_ASAP7_75t_R g223(.A1(new_n279_), .A2(new_n281_), .B(new_n236_), .Y(new_n282_));
  AOI21x1_ASAP7_75t_R g224(.A1(new_n277_), .A2(new_n282_), .B(new_n265_), .Y(new_n283_));
  OR3x1_ASAP7_75t_R   g225(.A(new_n236_), .B(new_n281_), .C(new_n279_), .Y(new_n284_));
  AO21x1_ASAP7_75t_R  g226(.A1(new_n270_), .A2(new_n275_), .B(new_n232_), .Y(new_n285_));
  AND3x1_ASAP7_75t_R  g227(.A(new_n265_), .B(new_n284_), .C(new_n285_), .Y(new_n286_));
  AO21x1_ASAP7_75t_R  g228(.A1(new_n61_), .A2(new_n286_), .B(new_n77_), .Y(new_n287_));
  AOI21x1_ASAP7_75t_R g229(.A1(new_n61_), .A2(new_n283_), .B(new_n287_), .Y(new_n288_));
  OAI21x1_ASAP7_75t_R g230(.A1(new_n235_), .A2(new_n280_), .B(new_n265_), .Y(new_n289_));
  AOI21x1_ASAP7_75t_R g231(.A1(new_n236_), .A2(new_n279_), .B(new_n289_), .Y(new_n290_));
  AOI21x1_ASAP7_75t_R g232(.A1(new_n284_), .A2(new_n285_), .B(new_n265_), .Y(new_n291_));
  AO21x1_ASAP7_75t_R  g233(.A1(new_n277_), .A2(new_n290_), .B(new_n291_), .Y(new_n292_));
  AND3x1_ASAP7_75t_R  g234(.A(new_n61_), .B(new_n77_), .C(new_n292_), .Y(new_n293_));
  OR2x4_ASAP7_75t_R   g235(.A(new_n288_), .B(new_n293_), .Y(new_n294_));
  OR3x1_ASAP7_75t_R   g236(.A(G33), .B(G23), .C(new_n68_), .Y(new_n295_));
  NAND2x1_ASAP7_75t_R g237(.A(new_n65_), .B(G10), .Y(new_n296_));
  OA21x2_ASAP7_75t_R  g238(.A1(new_n65_), .A2(G10), .B(G12), .Y(new_n297_));
  OA21x2_ASAP7_75t_R  g239(.A1(new_n65_), .A2(G10), .B(new_n296_), .Y(new_n298_));
  NOR2x1_ASAP7_75t_R  g240(.A(G12), .B(new_n298_), .Y(new_n299_));
  AOI21x1_ASAP7_75t_R g241(.A1(new_n296_), .A2(new_n297_), .B(new_n299_), .Y(new_n300_));
  NAND2x1_ASAP7_75t_R g242(.A(G8), .B(new_n63_), .Y(new_n301_));
  OA21x2_ASAP7_75t_R  g243(.A1(G8), .A2(new_n63_), .B(new_n301_), .Y(new_n302_));
  NOR2x1_ASAP7_75t_R  g244(.A(G3), .B(new_n302_), .Y(new_n303_));
  AO21x1_ASAP7_75t_R  g245(.A1(G3), .A2(new_n302_), .B(new_n303_), .Y(new_n304_));
  AND2x2_ASAP7_75t_R  g246(.A(new_n300_), .B(new_n304_), .Y(new_n305_));
  AO21x1_ASAP7_75t_R  g247(.A1(G12), .A2(new_n298_), .B(new_n299_), .Y(new_n306_));
  OA21x2_ASAP7_75t_R  g248(.A1(G8), .A2(new_n63_), .B(G3), .Y(new_n307_));
  AOI21x1_ASAP7_75t_R g249(.A1(new_n301_), .A2(new_n307_), .B(new_n303_), .Y(new_n308_));
  NAND2x1_ASAP7_75t_R g250(.A(new_n306_), .B(new_n308_), .Y(new_n309_));
  AND3x1_ASAP7_75t_R  g251(.A(new_n306_), .B(new_n308_), .C(new_n295_), .Y(new_n310_));
  AO21x1_ASAP7_75t_R  g252(.A1(new_n295_), .A2(new_n305_), .B(new_n310_), .Y(new_n311_));
  NOR2x1_ASAP7_75t_R  g253(.A(new_n306_), .B(new_n308_), .Y(new_n312_));
  NOR2x1_ASAP7_75t_R  g254(.A(new_n300_), .B(new_n304_), .Y(new_n313_));
  OR3x1_ASAP7_75t_R   g255(.A(new_n295_), .B(new_n312_), .C(new_n313_), .Y(new_n314_));
  INVx1_ASAP7_75t_R   g256(.A(new_n314_), .Y(new_n315_));
  AO21x1_ASAP7_75t_R  g257(.A1(new_n61_), .A2(new_n315_), .B(new_n69_), .Y(new_n316_));
  AOI21x1_ASAP7_75t_R g258(.A1(new_n61_), .A2(new_n311_), .B(new_n316_), .Y(new_n317_));
  NOR2x1_ASAP7_75t_R  g259(.A(new_n295_), .B(new_n305_), .Y(new_n318_));
  OA21x2_ASAP7_75t_R  g260(.A1(new_n312_), .A2(new_n313_), .B(new_n295_), .Y(new_n319_));
  AOI21x1_ASAP7_75t_R g261(.A1(new_n309_), .A2(new_n318_), .B(new_n319_), .Y(new_n320_));
  OR3x1_ASAP7_75t_R   g262(.A(G31), .B(G28), .C(new_n320_), .Y(new_n321_));
  INVx1_ASAP7_75t_R   g263(.A(new_n321_), .Y(new_n322_));
  NOR2x1_ASAP7_75t_R  g264(.A(new_n59_), .B(G23), .Y(new_n323_));
  OA21x2_ASAP7_75t_R  g265(.A1(G31), .A2(G30), .B(G32), .Y(new_n324_));
  OR3x1_ASAP7_75t_R   g266(.A(G33), .B(new_n323_), .C(new_n324_), .Y(new_n325_));
  OR3x1_ASAP7_75t_R   g267(.A(new_n322_), .B(new_n325_), .C(new_n317_), .Y(new_n326_));
  OR3x1_ASAP7_75t_R   g268(.A(new_n71_), .B(new_n326_), .C(new_n294_), .Y(new_n327_));
  OR3x1_ASAP7_75t_R   g269(.A(new_n260_), .B(new_n327_), .C(new_n195_), .Y(new_n328_));
  OR3x1_ASAP7_75t_R   g270(.A(new_n288_), .B(new_n293_), .C(new_n326_), .Y(new_n329_));
  OR3x1_ASAP7_75t_R   g271(.A(new_n260_), .B(new_n329_), .C(new_n195_), .Y(new_n330_));
  INVx1_ASAP7_75t_R   g272(.A(new_n330_), .Y(new_n331_));
  OAI21x1_ASAP7_75t_R g273(.A1(G14), .A2(new_n331_), .B(new_n328_), .Y(G1899));
  AO21x1_ASAP7_75t_R  g274(.A1(new_n151_), .A2(new_n156_), .B(new_n158_), .Y(new_n333_));
  AOI21x1_ASAP7_75t_R g275(.A1(new_n149_), .A2(new_n156_), .B(new_n333_), .Y(new_n334_));
  NOR2x1_ASAP7_75t_R  g276(.A(new_n194_), .B(new_n334_), .Y(new_n335_));
  INVx1_ASAP7_75t_R   g277(.A(new_n335_), .Y(new_n336_));
  OA21x2_ASAP7_75t_R  g278(.A1(G31), .A2(G29), .B(G32), .Y(new_n337_));
  OR3x1_ASAP7_75t_R   g279(.A(G33), .B(new_n323_), .C(new_n337_), .Y(new_n338_));
  OR3x1_ASAP7_75t_R   g280(.A(new_n293_), .B(new_n338_), .C(new_n288_), .Y(new_n339_));
  OR2x4_ASAP7_75t_R   g281(.A(new_n317_), .B(new_n322_), .Y(new_n340_));
  OR3x1_ASAP7_75t_R   g282(.A(new_n82_), .B(new_n340_), .C(new_n339_), .Y(new_n341_));
  OR3x1_ASAP7_75t_R   g283(.A(new_n260_), .B(new_n341_), .C(new_n336_), .Y(new_n342_));
  INVx1_ASAP7_75t_R   g284(.A(new_n342_), .Y(new_n343_));
  AO21x1_ASAP7_75t_R  g285(.A1(new_n142_), .A2(new_n145_), .B(new_n134_), .Y(new_n344_));
  OR3x1_ASAP7_75t_R   g286(.A(G31), .B(new_n152_), .C(new_n344_), .Y(new_n345_));
  AO21x1_ASAP7_75t_R  g287(.A1(new_n141_), .A2(new_n146_), .B(new_n154_), .Y(new_n346_));
  NOR2x1_ASAP7_75t_R  g288(.A(G31), .B(new_n346_), .Y(new_n347_));
  OR3x1_ASAP7_75t_R   g289(.A(new_n151_), .B(new_n347_), .C(new_n158_), .Y(new_n348_));
  OAI21x1_ASAP7_75t_R g290(.A1(new_n158_), .A2(new_n345_), .B(new_n348_), .Y(new_n349_));
  OA21x2_ASAP7_75t_R  g291(.A1(G31), .A2(new_n191_), .B(G25), .Y(new_n350_));
  AO21x1_ASAP7_75t_R  g292(.A1(new_n187_), .A2(new_n189_), .B(new_n350_), .Y(new_n351_));
  AO21x1_ASAP7_75t_R  g293(.A1(new_n163_), .A2(new_n351_), .B(new_n349_), .Y(new_n352_));
  NOR2x1_ASAP7_75t_R  g294(.A(new_n77_), .B(new_n292_), .Y(new_n353_));
  AO21x1_ASAP7_75t_R  g295(.A1(G31), .A2(G27), .B(new_n353_), .Y(new_n354_));
  NOR2x1_ASAP7_75t_R  g296(.A(new_n283_), .B(new_n286_), .Y(new_n355_));
  INVx1_ASAP7_75t_R   g297(.A(new_n355_), .Y(new_n356_));
  AND3x1_ASAP7_75t_R  g298(.A(new_n61_), .B(new_n77_), .C(new_n356_), .Y(new_n357_));
  NOR2x1_ASAP7_75t_R  g299(.A(new_n311_), .B(new_n315_), .Y(new_n358_));
  INVx1_ASAP7_75t_R   g300(.A(new_n358_), .Y(new_n359_));
  AND3x1_ASAP7_75t_R  g301(.A(new_n61_), .B(new_n69_), .C(new_n359_), .Y(new_n360_));
  AO21x1_ASAP7_75t_R  g302(.A1(G28), .A2(new_n320_), .B(new_n360_), .Y(new_n361_));
  AO21x1_ASAP7_75t_R  g303(.A1(G31), .A2(G28), .B(new_n361_), .Y(new_n362_));
  OR3x1_ASAP7_75t_R   g304(.A(new_n357_), .B(new_n362_), .C(new_n354_), .Y(new_n363_));
  OR3x1_ASAP7_75t_R   g305(.A(new_n338_), .B(new_n363_), .C(new_n260_), .Y(new_n364_));
  OR2x4_ASAP7_75t_R   g306(.A(new_n352_), .B(new_n364_), .Y(new_n365_));
  AO21x1_ASAP7_75t_R  g307(.A1(new_n82_), .A2(new_n365_), .B(new_n343_), .Y(G1884));
  OR3x1_ASAP7_75t_R   g308(.A(new_n76_), .B(new_n340_), .C(new_n339_), .Y(new_n367_));
  OR3x1_ASAP7_75t_R   g309(.A(new_n260_), .B(new_n367_), .C(new_n336_), .Y(new_n368_));
  INVx1_ASAP7_75t_R   g310(.A(new_n368_), .Y(new_n369_));
  AO21x1_ASAP7_75t_R  g311(.A1(new_n76_), .A2(new_n365_), .B(new_n369_), .Y(G1885));
  OR3x1_ASAP7_75t_R   g312(.A(new_n81_), .B(new_n326_), .C(new_n294_), .Y(new_n371_));
  OR3x1_ASAP7_75t_R   g313(.A(new_n260_), .B(new_n371_), .C(new_n195_), .Y(new_n372_));
  OAI21x1_ASAP7_75t_R g314(.A1(G13), .A2(new_n331_), .B(new_n372_), .Y(G1898));
  OR3x1_ASAP7_75t_R   g315(.A(new_n64_), .B(new_n340_), .C(new_n339_), .Y(new_n374_));
  OR3x1_ASAP7_75t_R   g316(.A(new_n260_), .B(new_n374_), .C(new_n336_), .Y(new_n375_));
  INVx1_ASAP7_75t_R   g317(.A(new_n375_), .Y(new_n376_));
  AO21x1_ASAP7_75t_R  g318(.A1(new_n64_), .A2(new_n365_), .B(new_n376_), .Y(G1886));
  OR3x1_ASAP7_75t_R   g319(.A(new_n79_), .B(new_n340_), .C(new_n339_), .Y(new_n378_));
  OR3x1_ASAP7_75t_R   g320(.A(new_n260_), .B(new_n378_), .C(new_n336_), .Y(new_n379_));
  INVx1_ASAP7_75t_R   g321(.A(new_n379_), .Y(new_n380_));
  AO21x1_ASAP7_75t_R  g322(.A1(new_n79_), .A2(new_n365_), .B(new_n380_), .Y(G1887));
  OR3x1_ASAP7_75t_R   g323(.A(new_n66_), .B(new_n326_), .C(new_n294_), .Y(new_n382_));
  OR3x1_ASAP7_75t_R   g324(.A(new_n260_), .B(new_n382_), .C(new_n336_), .Y(new_n383_));
  OR2x4_ASAP7_75t_R   g325(.A(new_n354_), .B(new_n357_), .Y(new_n384_));
  OR3x1_ASAP7_75t_R   g326(.A(new_n325_), .B(new_n362_), .C(new_n384_), .Y(new_n385_));
  OR3x1_ASAP7_75t_R   g327(.A(new_n260_), .B(new_n385_), .C(new_n352_), .Y(new_n386_));
  INVx1_ASAP7_75t_R   g328(.A(new_n386_), .Y(new_n387_));
  OAI21x1_ASAP7_75t_R g329(.A1(G10), .A2(new_n387_), .B(new_n383_), .Y(G1888));
  OR3x1_ASAP7_75t_R   g330(.A(new_n65_), .B(new_n326_), .C(new_n294_), .Y(new_n389_));
  OR3x1_ASAP7_75t_R   g331(.A(new_n260_), .B(new_n389_), .C(new_n336_), .Y(new_n390_));
  OAI21x1_ASAP7_75t_R g332(.A1(G15), .A2(new_n387_), .B(new_n390_), .Y(G1889));
  OR3x1_ASAP7_75t_R   g333(.A(new_n72_), .B(new_n326_), .C(new_n294_), .Y(new_n392_));
  OR3x1_ASAP7_75t_R   g334(.A(new_n260_), .B(new_n392_), .C(new_n336_), .Y(new_n393_));
  OAI21x1_ASAP7_75t_R g335(.A1(G16), .A2(new_n387_), .B(new_n393_), .Y(G1890));
  OR3x1_ASAP7_75t_R   g336(.A(new_n162_), .B(new_n193_), .C(new_n188_), .Y(new_n395_));
  NOR2x1_ASAP7_75t_R  g337(.A(new_n334_), .B(new_n395_), .Y(new_n396_));
  INVx1_ASAP7_75t_R   g338(.A(new_n396_), .Y(new_n397_));
  OR3x1_ASAP7_75t_R   g339(.A(new_n75_), .B(new_n340_), .C(new_n339_), .Y(new_n398_));
  OR3x1_ASAP7_75t_R   g340(.A(new_n260_), .B(new_n398_), .C(new_n397_), .Y(new_n399_));
  OR3x1_ASAP7_75t_R   g341(.A(new_n338_), .B(new_n340_), .C(new_n294_), .Y(new_n400_));
  OR3x1_ASAP7_75t_R   g342(.A(new_n260_), .B(new_n400_), .C(new_n397_), .Y(new_n401_));
  INVx1_ASAP7_75t_R   g343(.A(new_n401_), .Y(new_n402_));
  OAI21x1_ASAP7_75t_R g344(.A1(G5), .A2(new_n402_), .B(new_n399_), .Y(G1891));
  OR3x1_ASAP7_75t_R   g345(.A(new_n63_), .B(new_n340_), .C(new_n339_), .Y(new_n404_));
  OR3x1_ASAP7_75t_R   g346(.A(new_n260_), .B(new_n404_), .C(new_n397_), .Y(new_n405_));
  INVx1_ASAP7_75t_R   g347(.A(new_n405_), .Y(new_n406_));
  OR3x1_ASAP7_75t_R   g348(.A(new_n334_), .B(new_n395_), .C(new_n364_), .Y(new_n407_));
  AO21x1_ASAP7_75t_R  g349(.A1(new_n63_), .A2(new_n407_), .B(new_n406_), .Y(G1892));
  OR3x1_ASAP7_75t_R   g350(.A(new_n78_), .B(new_n340_), .C(new_n339_), .Y(new_n409_));
  OR3x1_ASAP7_75t_R   g351(.A(new_n260_), .B(new_n409_), .C(new_n397_), .Y(new_n410_));
  OAI21x1_ASAP7_75t_R g352(.A1(G7), .A2(new_n402_), .B(new_n410_), .Y(G1893));
  OR3x1_ASAP7_75t_R   g353(.A(new_n62_), .B(new_n340_), .C(new_n339_), .Y(new_n412_));
  OR3x1_ASAP7_75t_R   g354(.A(new_n260_), .B(new_n412_), .C(new_n397_), .Y(new_n413_));
  INVx1_ASAP7_75t_R   g355(.A(new_n413_), .Y(new_n414_));
  AO21x1_ASAP7_75t_R  g356(.A1(new_n62_), .A2(new_n407_), .B(new_n414_), .Y(G1894));
  OR3x1_ASAP7_75t_R   g357(.A(new_n70_), .B(new_n326_), .C(new_n294_), .Y(new_n416_));
  OR3x1_ASAP7_75t_R   g358(.A(new_n260_), .B(new_n416_), .C(new_n397_), .Y(new_n417_));
  INVx1_ASAP7_75t_R   g359(.A(new_n417_), .Y(new_n418_));
  OR3x1_ASAP7_75t_R   g360(.A(new_n260_), .B(new_n385_), .C(new_n397_), .Y(new_n419_));
  AO21x1_ASAP7_75t_R  g361(.A1(new_n70_), .A2(new_n419_), .B(new_n418_), .Y(G1895));
  OR3x1_ASAP7_75t_R   g362(.A(new_n74_), .B(new_n326_), .C(new_n294_), .Y(new_n421_));
  OR3x1_ASAP7_75t_R   g363(.A(new_n260_), .B(new_n421_), .C(new_n195_), .Y(new_n422_));
  OAI21x1_ASAP7_75t_R g364(.A1(G11), .A2(new_n331_), .B(new_n422_), .Y(G1896));
  OR3x1_ASAP7_75t_R   g365(.A(new_n67_), .B(new_n326_), .C(new_n294_), .Y(new_n424_));
  OR3x1_ASAP7_75t_R   g366(.A(new_n260_), .B(new_n424_), .C(new_n195_), .Y(new_n425_));
  OAI21x1_ASAP7_75t_R g367(.A1(G12), .A2(new_n331_), .B(new_n425_), .Y(G1897));
  NOR2x1_ASAP7_75t_R  g368(.A(G33), .B(G32), .Y(new_n427_));
  INVx1_ASAP7_75t_R   g369(.A(new_n427_), .Y(new_n428_));
  OA21x2_ASAP7_75t_R  g370(.A1(G31), .A2(new_n256_), .B(new_n225_), .Y(new_n429_));
  OR3x1_ASAP7_75t_R   g371(.A(G31), .B(new_n225_), .C(new_n250_), .Y(new_n430_));
  INVx1_ASAP7_75t_R   g372(.A(new_n430_), .Y(new_n431_));
  OR3x1_ASAP7_75t_R   g373(.A(new_n429_), .B(new_n431_), .C(new_n340_), .Y(new_n432_));
  NAND2x1_ASAP7_75t_R g374(.A(new_n61_), .B(new_n219_), .Y(new_n433_));
  OA21x2_ASAP7_75t_R  g375(.A1(G31), .A2(new_n221_), .B(new_n433_), .Y(new_n434_));
  AO21x1_ASAP7_75t_R  g376(.A1(G26), .A2(new_n434_), .B(new_n432_), .Y(new_n435_));
  AO21x1_ASAP7_75t_R  g377(.A1(new_n216_), .A2(new_n222_), .B(new_n293_), .Y(new_n436_));
  OR3x1_ASAP7_75t_R   g378(.A(new_n288_), .B(new_n436_), .C(new_n435_), .Y(new_n437_));
  OR3x1_ASAP7_75t_R   g379(.A(new_n159_), .B(new_n193_), .C(new_n188_), .Y(new_n438_));
  OR3x1_ASAP7_75t_R   g380(.A(new_n157_), .B(new_n163_), .C(new_n153_), .Y(new_n439_));
  OR3x1_ASAP7_75t_R   g381(.A(new_n438_), .B(new_n439_), .C(new_n437_), .Y(new_n440_));
  INVx1_ASAP7_75t_R   g382(.A(new_n440_), .Y(new_n441_));
  OR2x4_ASAP7_75t_R   g383(.A(new_n260_), .B(new_n334_), .Y(new_n442_));
  OR3x1_ASAP7_75t_R   g384(.A(new_n323_), .B(new_n428_), .C(new_n322_), .Y(new_n443_));
  OR3x1_ASAP7_75t_R   g385(.A(new_n317_), .B(new_n443_), .C(new_n384_), .Y(new_n444_));
  OR3x1_ASAP7_75t_R   g386(.A(new_n395_), .B(new_n444_), .C(new_n442_), .Y(new_n445_));
  OR2x4_ASAP7_75t_R   g387(.A(new_n260_), .B(new_n444_), .Y(new_n446_));
  OA21x2_ASAP7_75t_R  g388(.A1(new_n195_), .A2(new_n446_), .B(new_n445_), .Y(new_n447_));
  OR3x1_ASAP7_75t_R   g389(.A(new_n160_), .B(new_n395_), .C(new_n446_), .Y(new_n448_));
  AND3x1_ASAP7_75t_R  g390(.A(G32), .B(new_n448_), .C(new_n447_), .Y(new_n449_));
  OR3x1_ASAP7_75t_R   g391(.A(new_n260_), .B(new_n329_), .C(new_n336_), .Y(new_n450_));
  OR3x1_ASAP7_75t_R   g392(.A(new_n294_), .B(new_n326_), .C(new_n160_), .Y(new_n451_));
  OR3x1_ASAP7_75t_R   g393(.A(new_n194_), .B(new_n260_), .C(new_n451_), .Y(new_n452_));
  AND2x2_ASAP7_75t_R  g394(.A(new_n450_), .B(new_n452_), .Y(new_n453_));
  NOR2x1_ASAP7_75t_R  g395(.A(new_n335_), .B(new_n396_), .Y(new_n454_));
  OR3x1_ASAP7_75t_R   g396(.A(new_n260_), .B(new_n329_), .C(new_n454_), .Y(new_n455_));
  OR3x1_ASAP7_75t_R   g397(.A(new_n260_), .B(new_n400_), .C(new_n454_), .Y(new_n456_));
  INVx1_ASAP7_75t_R   g398(.A(new_n456_), .Y(new_n457_));
  AND3x1_ASAP7_75t_R  g399(.A(new_n455_), .B(new_n456_), .C(new_n453_), .Y(new_n458_));
  INVx1_ASAP7_75t_R   g400(.A(new_n458_), .Y(new_n459_));
  AND3x1_ASAP7_75t_R  g401(.A(new_n60_), .B(new_n440_), .C(new_n458_), .Y(new_n460_));
  NAND2x1_ASAP7_75t_R g402(.A(new_n449_), .B(new_n460_), .Y(new_n461_));
  OA21x2_ASAP7_75t_R  g403(.A1(new_n428_), .A2(new_n441_), .B(new_n461_), .Y(G1900));
  OR3x1_ASAP7_75t_R   g404(.A(G31), .B(new_n83_), .C(new_n150_), .Y(new_n463_));
  INVx1_ASAP7_75t_R   g405(.A(new_n463_), .Y(new_n464_));
  OR3x1_ASAP7_75t_R   g406(.A(new_n329_), .B(new_n395_), .C(new_n442_), .Y(new_n465_));
  NAND2x1_ASAP7_75t_R g407(.A(new_n453_), .B(new_n465_), .Y(new_n466_));
  AND2x2_ASAP7_75t_R  g408(.A(new_n133_), .B(new_n145_), .Y(new_n467_));
  AO21x1_ASAP7_75t_R  g409(.A1(new_n115_), .A2(new_n142_), .B(new_n467_), .Y(new_n468_));
  OAI21x1_ASAP7_75t_R g410(.A1(new_n456_), .A2(new_n463_), .B(new_n468_), .Y(new_n469_));
  AO21x1_ASAP7_75t_R  g411(.A1(new_n464_), .A2(new_n466_), .B(new_n469_), .Y(new_n470_));
  OR3x1_ASAP7_75t_R   g412(.A(new_n463_), .B(new_n468_), .C(new_n458_), .Y(new_n471_));
  AOI21x1_ASAP7_75t_R g413(.A1(new_n470_), .A2(new_n471_), .B(new_n427_), .Y(G1901));
  NOR2x1_ASAP7_75t_R  g414(.A(G31), .B(new_n85_), .Y(new_n473_));
  AND3x1_ASAP7_75t_R  g415(.A(new_n191_), .B(new_n473_), .C(new_n459_), .Y(new_n474_));
  AO21x1_ASAP7_75t_R  g416(.A1(new_n457_), .A2(new_n473_), .B(new_n191_), .Y(new_n475_));
  AOI21x1_ASAP7_75t_R g417(.A1(new_n466_), .A2(new_n473_), .B(new_n475_), .Y(new_n476_));
  OA21x2_ASAP7_75t_R  g418(.A1(new_n474_), .A2(new_n476_), .B(new_n428_), .Y(G1902));
  NOR2x1_ASAP7_75t_R  g419(.A(G31), .B(new_n77_), .Y(new_n478_));
  INVx1_ASAP7_75t_R   g420(.A(new_n478_), .Y(new_n479_));
  AO21x1_ASAP7_75t_R  g421(.A1(new_n457_), .A2(new_n478_), .B(new_n356_), .Y(new_n480_));
  AO21x1_ASAP7_75t_R  g422(.A1(new_n466_), .A2(new_n478_), .B(new_n480_), .Y(new_n481_));
  OR3x1_ASAP7_75t_R   g423(.A(new_n355_), .B(new_n479_), .C(new_n458_), .Y(new_n482_));
  AOI21x1_ASAP7_75t_R g424(.A1(new_n481_), .A2(new_n482_), .B(new_n427_), .Y(G1903));
  NOR2x1_ASAP7_75t_R  g425(.A(G31), .B(new_n69_), .Y(new_n484_));
  INVx1_ASAP7_75t_R   g426(.A(new_n484_), .Y(new_n485_));
  AO21x1_ASAP7_75t_R  g427(.A1(new_n457_), .A2(new_n484_), .B(new_n359_), .Y(new_n486_));
  AO21x1_ASAP7_75t_R  g428(.A1(new_n466_), .A2(new_n484_), .B(new_n486_), .Y(new_n487_));
  OR3x1_ASAP7_75t_R   g429(.A(new_n358_), .B(new_n485_), .C(new_n458_), .Y(new_n488_));
  AOI21x1_ASAP7_75t_R g430(.A1(new_n487_), .A2(new_n488_), .B(new_n427_), .Y(G1904));
  OR3x1_ASAP7_75t_R   g431(.A(G31), .B(new_n68_), .C(new_n161_), .Y(new_n490_));
  INVx1_ASAP7_75t_R   g432(.A(new_n490_), .Y(new_n491_));
  AO21x1_ASAP7_75t_R  g433(.A1(new_n457_), .A2(new_n491_), .B(new_n255_), .Y(new_n492_));
  AO21x1_ASAP7_75t_R  g434(.A1(new_n466_), .A2(new_n491_), .B(new_n492_), .Y(new_n493_));
  OR3x1_ASAP7_75t_R   g435(.A(new_n256_), .B(new_n490_), .C(new_n458_), .Y(new_n494_));
  AOI21x1_ASAP7_75t_R g436(.A1(new_n493_), .A2(new_n494_), .B(new_n427_), .Y(G1905));
  NOR2x1_ASAP7_75t_R  g437(.A(G33), .B(G29), .Y(new_n496_));
  OR3x1_ASAP7_75t_R   g438(.A(new_n114_), .B(new_n496_), .C(new_n111_), .Y(new_n497_));
  INVx1_ASAP7_75t_R   g439(.A(new_n497_), .Y(new_n498_));
  OR3x1_ASAP7_75t_R   g440(.A(G33), .B(new_n498_), .C(new_n456_), .Y(new_n499_));
  OR3x1_ASAP7_75t_R   g441(.A(new_n260_), .B(new_n400_), .C(new_n336_), .Y(new_n500_));
  INVx1_ASAP7_75t_R   g442(.A(new_n500_), .Y(new_n501_));
  AO21x1_ASAP7_75t_R  g443(.A1(new_n60_), .A2(new_n402_), .B(new_n497_), .Y(new_n502_));
  AO21x1_ASAP7_75t_R  g444(.A1(new_n60_), .A2(new_n501_), .B(new_n502_), .Y(new_n503_));
  AO21x1_ASAP7_75t_R  g445(.A1(G21), .A2(G29), .B(G33), .Y(new_n504_));
  INVx1_ASAP7_75t_R   g446(.A(new_n504_), .Y(new_n505_));
  AOI21x1_ASAP7_75t_R g447(.A1(new_n499_), .A2(new_n503_), .B(new_n505_), .Y(new_n506_));
  AOI21x1_ASAP7_75t_R g448(.A1(new_n352_), .A2(new_n397_), .B(new_n364_), .Y(new_n507_));
  OA21x2_ASAP7_75t_R  g449(.A1(G33), .A2(G29), .B(new_n143_), .Y(new_n508_));
  AOI21x1_ASAP7_75t_R g450(.A1(new_n144_), .A2(new_n508_), .B(G33), .Y(new_n509_));
  AOI21x1_ASAP7_75t_R g451(.A1(new_n507_), .A2(new_n509_), .B(new_n504_), .Y(new_n510_));
  AO21x1_ASAP7_75t_R  g452(.A1(new_n503_), .A2(new_n510_), .B(new_n506_), .Y(G1906));
  XNOR2x2_ASAP7_75t_R g453(.A(G9), .B(new_n71_), .Y(new_n512_));
  AO21x1_ASAP7_75t_R  g454(.A1(new_n138_), .A2(new_n178_), .B(new_n512_), .Y(new_n513_));
  OR2x4_ASAP7_75t_R   g455(.A(G33), .B(G30), .Y(new_n514_));
  OAI21x1_ASAP7_75t_R g456(.A1(new_n204_), .A2(new_n513_), .B(new_n514_), .Y(new_n515_));
  AO21x1_ASAP7_75t_R  g457(.A1(new_n202_), .A2(new_n512_), .B(new_n515_), .Y(new_n516_));
  AO21x1_ASAP7_75t_R  g458(.A1(new_n60_), .A2(new_n466_), .B(new_n516_), .Y(new_n517_));
  INVx1_ASAP7_75t_R   g459(.A(new_n517_), .Y(new_n518_));
  AND3x1_ASAP7_75t_R  g460(.A(new_n386_), .B(new_n419_), .C(new_n330_), .Y(new_n519_));
  AO21x1_ASAP7_75t_R  g461(.A1(new_n124_), .A2(new_n172_), .B(new_n512_), .Y(new_n520_));
  OAI21x1_ASAP7_75t_R g462(.A1(new_n201_), .A2(new_n520_), .B(new_n514_), .Y(new_n521_));
  AOI21x1_ASAP7_75t_R g463(.A1(new_n205_), .A2(new_n512_), .B(new_n521_), .Y(new_n522_));
  OR3x1_ASAP7_75t_R   g464(.A(G33), .B(new_n522_), .C(new_n519_), .Y(new_n523_));
  INVx1_ASAP7_75t_R   g465(.A(new_n523_), .Y(new_n524_));
  OA21x2_ASAP7_75t_R  g466(.A1(G33), .A2(G22), .B(new_n514_), .Y(new_n525_));
  OA21x2_ASAP7_75t_R  g467(.A1(new_n518_), .A2(new_n524_), .B(new_n525_), .Y(new_n526_));
  NOR2x1_ASAP7_75t_R  g468(.A(new_n524_), .B(new_n525_), .Y(new_n527_));
  AO21x1_ASAP7_75t_R  g469(.A1(new_n517_), .A2(new_n527_), .B(new_n526_), .Y(G1907));
  NOR2x1_ASAP7_75t_R  g470(.A(G31), .B(new_n84_), .Y(new_n529_));
  INVx1_ASAP7_75t_R   g471(.A(new_n529_), .Y(new_n530_));
  OAI21x1_ASAP7_75t_R g472(.A1(new_n456_), .A2(new_n530_), .B(new_n206_), .Y(new_n531_));
  AOI21x1_ASAP7_75t_R g473(.A1(new_n466_), .A2(new_n529_), .B(new_n531_), .Y(new_n532_));
  NOR2x1_ASAP7_75t_R  g474(.A(new_n206_), .B(new_n530_), .Y(new_n533_));
  AOI21x1_ASAP7_75t_R g475(.A1(new_n459_), .A2(new_n533_), .B(new_n532_), .Y(new_n534_));
  OR3x1_ASAP7_75t_R   g476(.A(new_n213_), .B(new_n534_), .C(new_n427_), .Y(new_n535_));
  AND3x1_ASAP7_75t_R  g477(.A(new_n218_), .B(new_n529_), .C(new_n459_), .Y(new_n536_));
  OR3x1_ASAP7_75t_R   g478(.A(new_n200_), .B(new_n532_), .C(new_n536_), .Y(new_n537_));
  OAI21x1_ASAP7_75t_R g479(.A1(new_n427_), .A2(new_n537_), .B(new_n535_), .Y(G1908));
endmodule


