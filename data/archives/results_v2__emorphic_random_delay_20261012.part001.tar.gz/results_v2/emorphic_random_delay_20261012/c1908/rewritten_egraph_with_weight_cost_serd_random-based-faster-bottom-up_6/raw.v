// Benchmark "/home/flynn/workplace/MIGBalance/results_v2/emorphic_random_delay_20261012/c1908/rewritten_egraph_with_weight_cost_serd_random-based-faster-bottom-up_6/logic" written by ABC on Mon Oct 12 14:25:26 2026

module \/home/flynn/workplace/MIGBalance/results_v2/emorphic_random_delay_20261012/c1908/rewritten_egraph_with_weight_cost_serd_random-based-faster-bottom-up_6/logic  ( 
    G24, G33, G31, G30, G32, G8, G6, G3, G15, G10, G12, G19, G28, G9, G14,
    G16, G18, G11, G5, G2, G27, G7, G4, G20, G13, G1, G17, G26, G22, G25,
    G21, G29, G23,
    G1899, G1884, G1885, G1898, G1886, G1887, G1888, G1889, G1890, G1891,
    G1892, G1893, G1894, G1895, G1896, G1897, G1900, G1901, G1902, G1903,
    G1904, G1905, G1906, G1907, G1908  );
  input  G24, G33, G31, G30, G32, G8, G6, G3, G15, G10, G12, G19, G28,
    G9, G14, G16, G18, G11, G5, G2, G27, G7, G4, G20, G13, G1, G17, G26,
    G22, G25, G21, G29, G23;
  output G1899, G1884, G1885, G1898, G1886, G1887, G1888, G1889, G1890, G1891,
    G1892, G1893, G1894, G1895, G1896, G1897, G1900, G1901, G1902, G1903,
    G1904, G1905, G1906, G1907, G1908;
  wire new_n59_, new_n60_, new_n61_, new_n62_, new_n63_, new_n64_, new_n65_,
    new_n66_, new_n67_, new_n68_, new_n69_, new_n70_, new_n71_, new_n72_,
    new_n73_, new_n74_, new_n75_, new_n76_, new_n77_, new_n78_, new_n79_,
    new_n80_, new_n81_, new_n82_, new_n83_, new_n84_, new_n85_, new_n86_,
    new_n87_, new_n88_, new_n89_, new_n90_, new_n91_, new_n92_, new_n93_,
    new_n94_, new_n95_, new_n96_, new_n97_, new_n98_, new_n99_, new_n100_,
    new_n101_, new_n102_, new_n103_, new_n104_, new_n105_, new_n106_,
    new_n107_, new_n108_, new_n109_, new_n110_, new_n111_, new_n112_,
    new_n113_, new_n114_, new_n115_, new_n116_, new_n117_, new_n118_,
    new_n119_, new_n120_, new_n121_, new_n122_, new_n123_, new_n124_,
    new_n125_, new_n126_, new_n127_, new_n128_, new_n129_, new_n130_,
    new_n131_, new_n132_, new_n133_, new_n134_, new_n135_, new_n136_,
    new_n137_, new_n138_, new_n139_, new_n140_, new_n141_, new_n142_,
    new_n143_, new_n144_, new_n145_, new_n146_, new_n147_, new_n148_,
    new_n149_, new_n150_, new_n151_, new_n152_, new_n153_, new_n154_,
    new_n155_, new_n156_, new_n157_, new_n158_, new_n159_, new_n160_,
    new_n161_, new_n162_, new_n163_, new_n164_, new_n165_, new_n166_,
    new_n167_, new_n168_, new_n169_, new_n170_, new_n171_, new_n172_,
    new_n173_, new_n174_, new_n175_, new_n176_, new_n177_, new_n178_,
    new_n179_, new_n180_, new_n181_, new_n182_, new_n183_, new_n184_,
    new_n185_, new_n186_, new_n187_, new_n188_, new_n189_, new_n190_,
    new_n191_, new_n192_, new_n193_, new_n194_, new_n195_, new_n196_,
    new_n197_, new_n198_, new_n199_, new_n200_, new_n201_, new_n202_,
    new_n203_, new_n204_, new_n205_, new_n206_, new_n207_, new_n208_,
    new_n209_, new_n210_, new_n211_, new_n212_, new_n213_, new_n214_,
    new_n215_, new_n216_, new_n217_, new_n218_, new_n219_, new_n220_,
    new_n221_, new_n222_, new_n223_, new_n224_, new_n225_, new_n226_,
    new_n227_, new_n228_, new_n229_, new_n230_, new_n231_, new_n232_,
    new_n233_, new_n234_, new_n235_, new_n236_, new_n237_, new_n238_,
    new_n239_, new_n240_, new_n241_, new_n242_, new_n243_, new_n244_,
    new_n245_, new_n246_, new_n247_, new_n248_, new_n249_, new_n250_,
    new_n251_, new_n252_, new_n253_, new_n254_, new_n255_, new_n256_,
    new_n257_, new_n258_, new_n259_, new_n260_, new_n261_, new_n262_,
    new_n263_, new_n264_, new_n265_, new_n266_, new_n267_, new_n268_,
    new_n269_, new_n270_, new_n271_, new_n272_, new_n273_, new_n274_,
    new_n275_, new_n276_, new_n277_, new_n278_, new_n279_, new_n280_,
    new_n281_, new_n282_, new_n283_, new_n284_, new_n285_, new_n286_,
    new_n287_, new_n288_, new_n289_, new_n290_, new_n291_, new_n292_,
    new_n293_, new_n294_, new_n295_, new_n296_, new_n297_, new_n298_,
    new_n299_, new_n300_, new_n301_, new_n302_, new_n303_, new_n304_,
    new_n305_, new_n306_, new_n307_, new_n308_, new_n309_, new_n310_,
    new_n311_, new_n312_, new_n313_, new_n314_, new_n315_, new_n316_,
    new_n317_, new_n318_, new_n319_, new_n320_, new_n321_, new_n322_,
    new_n323_, new_n324_, new_n325_, new_n326_, new_n327_, new_n328_,
    new_n329_, new_n330_, new_n331_, new_n332_, new_n333_, new_n334_,
    new_n335_, new_n336_, new_n337_, new_n338_, new_n339_, new_n340_,
    new_n341_, new_n342_, new_n343_, new_n344_, new_n345_, new_n347_,
    new_n348_, new_n349_, new_n350_, new_n351_, new_n352_, new_n353_,
    new_n354_, new_n355_, new_n356_, new_n357_, new_n358_, new_n359_,
    new_n360_, new_n361_, new_n362_, new_n363_, new_n364_, new_n365_,
    new_n366_, new_n367_, new_n368_, new_n369_, new_n370_, new_n371_,
    new_n372_, new_n373_, new_n374_, new_n375_, new_n376_, new_n377_,
    new_n378_, new_n379_, new_n380_, new_n381_, new_n382_, new_n383_,
    new_n384_, new_n385_, new_n387_, new_n388_, new_n389_, new_n391_,
    new_n392_, new_n394_, new_n395_, new_n396_, new_n398_, new_n399_,
    new_n400_, new_n402_, new_n403_, new_n404_, new_n405_, new_n406_,
    new_n408_, new_n409_, new_n411_, new_n412_, new_n414_, new_n415_,
    new_n416_, new_n417_, new_n418_, new_n419_, new_n420_, new_n421_,
    new_n422_, new_n423_, new_n425_, new_n426_, new_n427_, new_n428_,
    new_n430_, new_n431_, new_n433_, new_n434_, new_n435_, new_n437_,
    new_n438_, new_n439_, new_n440_, new_n442_, new_n443_, new_n445_,
    new_n446_, new_n448_, new_n449_, new_n450_, new_n451_, new_n452_,
    new_n453_, new_n454_, new_n455_, new_n456_, new_n457_, new_n458_,
    new_n459_, new_n460_, new_n461_, new_n462_, new_n463_, new_n464_,
    new_n465_, new_n466_, new_n467_, new_n468_, new_n469_, new_n470_,
    new_n471_, new_n472_, new_n473_, new_n474_, new_n475_, new_n477_,
    new_n478_, new_n479_, new_n480_, new_n481_, new_n482_, new_n483_,
    new_n484_, new_n485_, new_n487_, new_n488_, new_n489_, new_n490_,
    new_n491_, new_n493_, new_n494_, new_n495_, new_n496_, new_n497_,
    new_n499_, new_n500_, new_n501_, new_n502_, new_n503_, new_n505_,
    new_n506_, new_n507_, new_n508_, new_n509_, new_n511_, new_n512_,
    new_n513_, new_n514_, new_n515_, new_n516_, new_n517_, new_n518_,
    new_n519_, new_n520_, new_n521_, new_n522_, new_n523_, new_n524_,
    new_n526_, new_n527_, new_n528_, new_n529_, new_n530_, new_n531_,
    new_n532_, new_n533_, new_n534_, new_n535_, new_n536_, new_n537_,
    new_n538_, new_n539_, new_n540_, new_n541_, new_n542_, new_n543_,
    new_n544_, new_n545_, new_n546_, new_n547_, new_n548_, new_n550_,
    new_n551_, new_n552_, new_n553_, new_n554_, new_n555_, new_n556_,
    new_n557_, new_n558_;
  INVx1_ASAP7_75t_R   g000(.A(G24), .Y(new_n59_));
  INVx1_ASAP7_75t_R   g001(.A(G33), .Y(new_n60_));
  INVx1_ASAP7_75t_R   g002(.A(G31), .Y(new_n61_));
  INVx1_ASAP7_75t_R   g003(.A(G8), .Y(new_n62_));
  INVx1_ASAP7_75t_R   g004(.A(G6), .Y(new_n63_));
  INVx1_ASAP7_75t_R   g005(.A(G3), .Y(new_n64_));
  INVx1_ASAP7_75t_R   g006(.A(G15), .Y(new_n65_));
  INVx1_ASAP7_75t_R   g007(.A(G10), .Y(new_n66_));
  INVx1_ASAP7_75t_R   g008(.A(G12), .Y(new_n67_));
  INVx1_ASAP7_75t_R   g009(.A(G19), .Y(new_n68_));
  INVx1_ASAP7_75t_R   g010(.A(G28), .Y(new_n69_));
  INVx1_ASAP7_75t_R   g011(.A(G9), .Y(new_n70_));
  INVx1_ASAP7_75t_R   g012(.A(G14), .Y(new_n71_));
  INVx1_ASAP7_75t_R   g013(.A(G16), .Y(new_n72_));
  INVx1_ASAP7_75t_R   g014(.A(G11), .Y(new_n73_));
  INVx1_ASAP7_75t_R   g015(.A(G5), .Y(new_n74_));
  INVx1_ASAP7_75t_R   g016(.A(G2), .Y(new_n75_));
  INVx1_ASAP7_75t_R   g017(.A(G27), .Y(new_n76_));
  INVx1_ASAP7_75t_R   g018(.A(G7), .Y(new_n77_));
  INVx1_ASAP7_75t_R   g019(.A(G4), .Y(new_n78_));
  INVx1_ASAP7_75t_R   g020(.A(G20), .Y(new_n79_));
  INVx1_ASAP7_75t_R   g021(.A(G13), .Y(new_n80_));
  INVx1_ASAP7_75t_R   g022(.A(G1), .Y(new_n81_));
  INVx1_ASAP7_75t_R   g023(.A(G17), .Y(new_n82_));
  INVx1_ASAP7_75t_R   g024(.A(G26), .Y(new_n83_));
  INVx1_ASAP7_75t_R   g025(.A(G25), .Y(new_n84_));
  INVx1_ASAP7_75t_R   g026(.A(G21), .Y(new_n85_));
  INVx1_ASAP7_75t_R   g027(.A(G23), .Y(new_n86_));
  NOR2x1_ASAP7_75t_R  g028(.A(G24), .B(G31), .Y(new_n87_));
  AO21x1_ASAP7_75t_R  g029(.A1(new_n59_), .A2(new_n61_), .B(new_n82_), .Y(new_n88_));
  XOR2x2_ASAP7_75t_R  g030(.A(G8), .B(new_n78_), .Y(new_n89_));
  NOR2x1_ASAP7_75t_R  g031(.A(new_n64_), .B(new_n75_), .Y(new_n90_));
  NOR2x1_ASAP7_75t_R  g032(.A(G3), .B(G2), .Y(new_n91_));
  AO21x1_ASAP7_75t_R  g033(.A1(new_n64_), .A2(new_n75_), .B(new_n90_), .Y(new_n92_));
  OR3x1_ASAP7_75t_R   g034(.A(G1), .B(new_n90_), .C(new_n91_), .Y(new_n93_));
  INVx1_ASAP7_75t_R   g035(.A(new_n93_), .Y(new_n94_));
  AO21x1_ASAP7_75t_R  g036(.A1(G1), .A2(new_n92_), .B(new_n94_), .Y(new_n95_));
  INVx1_ASAP7_75t_R   g037(.A(new_n95_), .Y(new_n96_));
  NAND2x1_ASAP7_75t_R g038(.A(new_n63_), .B(new_n77_), .Y(new_n97_));
  NAND2x1_ASAP7_75t_R g039(.A(G6), .B(G7), .Y(new_n98_));
  AOI21x1_ASAP7_75t_R g040(.A1(new_n97_), .A2(new_n98_), .B(new_n74_), .Y(new_n99_));
  AND2x2_ASAP7_75t_R  g041(.A(new_n74_), .B(new_n98_), .Y(new_n100_));
  AO21x1_ASAP7_75t_R  g042(.A1(new_n97_), .A2(new_n100_), .B(new_n99_), .Y(new_n101_));
  INVx1_ASAP7_75t_R   g043(.A(new_n101_), .Y(new_n102_));
  NOR2x1_ASAP7_75t_R  g044(.A(new_n95_), .B(new_n101_), .Y(new_n103_));
  AND3x1_ASAP7_75t_R  g045(.A(new_n64_), .B(new_n75_), .C(G1), .Y(new_n104_));
  AO21x1_ASAP7_75t_R  g046(.A1(G1), .A2(new_n90_), .B(new_n104_), .Y(new_n105_));
  OR3x1_ASAP7_75t_R   g047(.A(G1), .B(new_n91_), .C(new_n90_), .Y(new_n106_));
  INVx1_ASAP7_75t_R   g048(.A(new_n106_), .Y(new_n107_));
  NOR2x1_ASAP7_75t_R  g049(.A(new_n105_), .B(new_n107_), .Y(new_n108_));
  INVx1_ASAP7_75t_R   g050(.A(new_n108_), .Y(new_n109_));
  AND2x2_ASAP7_75t_R  g051(.A(new_n74_), .B(new_n97_), .Y(new_n110_));
  AO21x1_ASAP7_75t_R  g052(.A1(new_n98_), .A2(new_n110_), .B(new_n99_), .Y(new_n111_));
  INVx1_ASAP7_75t_R   g053(.A(new_n111_), .Y(new_n112_));
  NOR2x1_ASAP7_75t_R  g054(.A(new_n108_), .B(new_n112_), .Y(new_n113_));
  OA21x2_ASAP7_75t_R  g055(.A1(new_n103_), .A2(new_n113_), .B(new_n89_), .Y(new_n114_));
  NOR2x1_ASAP7_75t_R  g056(.A(new_n96_), .B(new_n102_), .Y(new_n115_));
  NOR2x1_ASAP7_75t_R  g057(.A(new_n109_), .B(new_n111_), .Y(new_n116_));
  OR3x1_ASAP7_75t_R   g058(.A(new_n89_), .B(new_n116_), .C(new_n115_), .Y(new_n117_));
  INVx1_ASAP7_75t_R   g059(.A(new_n117_), .Y(new_n118_));
  NOR2x1_ASAP7_75t_R  g060(.A(new_n114_), .B(new_n118_), .Y(new_n119_));
  NOR2x1_ASAP7_75t_R  g061(.A(G33), .B(new_n85_), .Y(new_n120_));
  INVx1_ASAP7_75t_R   g062(.A(new_n120_), .Y(new_n121_));
  NOR2x1_ASAP7_75t_R  g063(.A(new_n65_), .B(new_n72_), .Y(new_n122_));
  INVx1_ASAP7_75t_R   g064(.A(new_n122_), .Y(new_n123_));
  NOR2x1_ASAP7_75t_R  g065(.A(G15), .B(G16), .Y(new_n124_));
  INVx1_ASAP7_75t_R   g066(.A(new_n124_), .Y(new_n125_));
  AND3x1_ASAP7_75t_R  g067(.A(new_n66_), .B(new_n123_), .C(new_n125_), .Y(new_n126_));
  OA21x2_ASAP7_75t_R  g068(.A1(new_n122_), .A2(new_n124_), .B(G10), .Y(new_n127_));
  NOR2x1_ASAP7_75t_R  g069(.A(new_n126_), .B(new_n127_), .Y(new_n128_));
  INVx1_ASAP7_75t_R   g070(.A(new_n128_), .Y(new_n129_));
  AND3x1_ASAP7_75t_R  g071(.A(new_n66_), .B(new_n125_), .C(new_n123_), .Y(new_n130_));
  OR3x1_ASAP7_75t_R   g072(.A(new_n70_), .B(new_n130_), .C(new_n127_), .Y(new_n131_));
  INVx1_ASAP7_75t_R   g073(.A(new_n131_), .Y(new_n132_));
  AO21x1_ASAP7_75t_R  g074(.A1(new_n70_), .A2(new_n129_), .B(new_n132_), .Y(new_n133_));
  NOR2x1_ASAP7_75t_R  g075(.A(new_n127_), .B(new_n130_), .Y(new_n134_));
  INVx1_ASAP7_75t_R   g076(.A(new_n134_), .Y(new_n135_));
  NOR2x1_ASAP7_75t_R  g077(.A(G9), .B(new_n134_), .Y(new_n136_));
  INVx1_ASAP7_75t_R   g078(.A(new_n136_), .Y(new_n137_));
  OR3x1_ASAP7_75t_R   g079(.A(new_n70_), .B(new_n126_), .C(new_n127_), .Y(new_n138_));
  AND3x1_ASAP7_75t_R  g080(.A(new_n121_), .B(new_n138_), .C(new_n137_), .Y(new_n139_));
  AO21x1_ASAP7_75t_R  g081(.A1(new_n120_), .A2(new_n133_), .B(new_n139_), .Y(new_n140_));
  AND2x2_ASAP7_75t_R  g082(.A(new_n119_), .B(new_n140_), .Y(new_n141_));
  NOR2x1_ASAP7_75t_R  g083(.A(new_n121_), .B(new_n138_), .Y(new_n142_));
  AO21x1_ASAP7_75t_R  g084(.A1(new_n120_), .A2(new_n136_), .B(new_n142_), .Y(new_n143_));
  AO21x1_ASAP7_75t_R  g085(.A1(new_n60_), .A2(G21), .B(new_n132_), .Y(new_n144_));
  AOI21x1_ASAP7_75t_R g086(.A1(new_n70_), .A2(new_n129_), .B(new_n144_), .Y(new_n145_));
  NOR2x1_ASAP7_75t_R  g087(.A(new_n143_), .B(new_n145_), .Y(new_n146_));
  OR3x1_ASAP7_75t_R   g088(.A(new_n89_), .B(new_n113_), .C(new_n103_), .Y(new_n147_));
  INVx1_ASAP7_75t_R   g089(.A(new_n147_), .Y(new_n148_));
  OA21x2_ASAP7_75t_R  g090(.A1(new_n115_), .A2(new_n116_), .B(new_n89_), .Y(new_n149_));
  OR2x4_ASAP7_75t_R   g091(.A(new_n148_), .B(new_n149_), .Y(new_n150_));
  AND2x2_ASAP7_75t_R  g092(.A(new_n146_), .B(new_n150_), .Y(new_n151_));
  OR3x1_ASAP7_75t_R   g093(.A(G31), .B(new_n141_), .C(new_n151_), .Y(new_n152_));
  INVx1_ASAP7_75t_R   g094(.A(new_n152_), .Y(new_n153_));
  NOR2x1_ASAP7_75t_R  g095(.A(new_n88_), .B(new_n153_), .Y(new_n154_));
  NOR2x1_ASAP7_75t_R  g096(.A(new_n119_), .B(new_n140_), .Y(new_n155_));
  NOR2x1_ASAP7_75t_R  g097(.A(new_n146_), .B(new_n150_), .Y(new_n156_));
  NOR2x1_ASAP7_75t_R  g098(.A(new_n59_), .B(new_n82_), .Y(new_n157_));
  AO21x1_ASAP7_75t_R  g099(.A1(G31), .A2(G17), .B(new_n157_), .Y(new_n158_));
  OR2x4_ASAP7_75t_R   g100(.A(new_n156_), .B(new_n158_), .Y(new_n159_));
  OR3x1_ASAP7_75t_R   g101(.A(G31), .B(new_n155_), .C(new_n159_), .Y(new_n160_));
  INVx1_ASAP7_75t_R   g102(.A(new_n160_), .Y(new_n161_));
  OA21x2_ASAP7_75t_R  g103(.A1(G24), .A2(G31), .B(G18), .Y(new_n162_));
  INVx1_ASAP7_75t_R   g104(.A(new_n162_), .Y(new_n163_));
  OR3x1_ASAP7_75t_R   g105(.A(new_n161_), .B(new_n163_), .C(new_n154_), .Y(new_n164_));
  INVx1_ASAP7_75t_R   g106(.A(new_n164_), .Y(new_n165_));
  NOR2x1_ASAP7_75t_R  g107(.A(G31), .B(G23), .Y(new_n166_));
  AO21x1_ASAP7_75t_R  g108(.A1(new_n61_), .A2(new_n86_), .B(new_n79_), .Y(new_n167_));
  INVx1_ASAP7_75t_R   g109(.A(new_n167_), .Y(new_n168_));
  NOR2x1_ASAP7_75t_R  g110(.A(new_n67_), .B(new_n80_), .Y(new_n169_));
  AND3x1_ASAP7_75t_R  g111(.A(G12), .B(G13), .C(G11), .Y(new_n170_));
  NOR2x1_ASAP7_75t_R  g112(.A(G12), .B(G13), .Y(new_n171_));
  AO21x1_ASAP7_75t_R  g113(.A1(G11), .A2(new_n171_), .B(new_n170_), .Y(new_n172_));
  OR3x1_ASAP7_75t_R   g114(.A(G11), .B(new_n171_), .C(new_n169_), .Y(new_n173_));
  INVx1_ASAP7_75t_R   g115(.A(new_n173_), .Y(new_n174_));
  NOR2x1_ASAP7_75t_R  g116(.A(new_n172_), .B(new_n174_), .Y(new_n175_));
  INVx1_ASAP7_75t_R   g117(.A(new_n175_), .Y(new_n176_));
  NOR2x1_ASAP7_75t_R  g118(.A(new_n95_), .B(new_n134_), .Y(new_n177_));
  AO21x1_ASAP7_75t_R  g119(.A1(new_n109_), .A2(new_n128_), .B(new_n177_), .Y(new_n178_));
  NAND2x1_ASAP7_75t_R g120(.A(new_n95_), .B(new_n134_), .Y(new_n179_));
  NAND2x1_ASAP7_75t_R g121(.A(new_n108_), .B(new_n129_), .Y(new_n180_));
  OR3x1_ASAP7_75t_R   g122(.A(G11), .B(new_n169_), .C(new_n171_), .Y(new_n181_));
  INVx1_ASAP7_75t_R   g123(.A(new_n181_), .Y(new_n182_));
  AO21x1_ASAP7_75t_R  g124(.A1(G12), .A2(G13), .B(new_n171_), .Y(new_n183_));
  AO21x1_ASAP7_75t_R  g125(.A1(G11), .A2(new_n183_), .B(new_n182_), .Y(new_n184_));
  INVx1_ASAP7_75t_R   g126(.A(new_n184_), .Y(new_n185_));
  AND3x1_ASAP7_75t_R  g127(.A(new_n180_), .B(new_n185_), .C(new_n179_), .Y(new_n186_));
  AO21x1_ASAP7_75t_R  g128(.A1(new_n176_), .A2(new_n178_), .B(new_n186_), .Y(new_n187_));
  NAND2x1_ASAP7_75t_R g129(.A(new_n60_), .B(G22), .Y(new_n188_));
  NAND2x1_ASAP7_75t_R g130(.A(G14), .B(G4), .Y(new_n189_));
  OA21x2_ASAP7_75t_R  g131(.A1(G14), .A2(G4), .B(new_n189_), .Y(new_n190_));
  NOR2x1_ASAP7_75t_R  g132(.A(new_n188_), .B(new_n190_), .Y(new_n191_));
  OA21x2_ASAP7_75t_R  g133(.A1(G14), .A2(G4), .B(new_n188_), .Y(new_n192_));
  AO21x1_ASAP7_75t_R  g134(.A1(new_n189_), .A2(new_n192_), .B(new_n191_), .Y(new_n193_));
  AO21x1_ASAP7_75t_R  g135(.A1(new_n188_), .A2(new_n190_), .B(new_n191_), .Y(new_n194_));
  AOI21x1_ASAP7_75t_R g136(.A1(new_n179_), .A2(new_n180_), .B(new_n185_), .Y(new_n195_));
  AO21x1_ASAP7_75t_R  g137(.A1(new_n96_), .A2(new_n135_), .B(new_n176_), .Y(new_n196_));
  AOI21x1_ASAP7_75t_R g138(.A1(new_n109_), .A2(new_n128_), .B(new_n196_), .Y(new_n197_));
  OAI21x1_ASAP7_75t_R g139(.A1(new_n195_), .A2(new_n197_), .B(new_n194_), .Y(new_n198_));
  OA21x2_ASAP7_75t_R  g140(.A1(new_n187_), .A2(new_n193_), .B(new_n198_), .Y(new_n199_));
  INVx1_ASAP7_75t_R   g141(.A(new_n199_), .Y(new_n200_));
  OR3x1_ASAP7_75t_R   g142(.A(G31), .B(G25), .C(new_n199_), .Y(new_n201_));
  INVx1_ASAP7_75t_R   g143(.A(new_n201_), .Y(new_n202_));
  OR3x1_ASAP7_75t_R   g144(.A(new_n194_), .B(new_n197_), .C(new_n195_), .Y(new_n203_));
  INVx1_ASAP7_75t_R   g145(.A(new_n203_), .Y(new_n204_));
  AOI21x1_ASAP7_75t_R g146(.A1(new_n187_), .A2(new_n193_), .B(new_n204_), .Y(new_n205_));
  NOR2x1_ASAP7_75t_R  g147(.A(G31), .B(new_n205_), .Y(new_n206_));
  AND2x2_ASAP7_75t_R  g148(.A(new_n201_), .B(new_n206_), .Y(new_n207_));
  AO21x1_ASAP7_75t_R  g149(.A1(new_n84_), .A2(new_n201_), .B(new_n207_), .Y(new_n208_));
  AND2x2_ASAP7_75t_R  g150(.A(new_n165_), .B(new_n208_), .Y(new_n209_));
  AOI21x1_ASAP7_75t_R g151(.A1(new_n165_), .A2(new_n167_), .B(new_n209_), .Y(new_n210_));
  OR3x1_ASAP7_75t_R   g152(.A(G24), .B(G33), .C(new_n82_), .Y(new_n211_));
  NOR2x1_ASAP7_75t_R  g153(.A(new_n81_), .B(new_n82_), .Y(new_n212_));
  AND3x1_ASAP7_75t_R  g154(.A(new_n59_), .B(new_n60_), .C(new_n212_), .Y(new_n213_));
  AO21x1_ASAP7_75t_R  g155(.A1(new_n81_), .A2(new_n211_), .B(new_n213_), .Y(new_n214_));
  INVx1_ASAP7_75t_R   g156(.A(new_n214_), .Y(new_n215_));
  NOR2x1_ASAP7_75t_R  g157(.A(new_n134_), .B(new_n184_), .Y(new_n216_));
  NOR2x1_ASAP7_75t_R  g158(.A(new_n129_), .B(new_n175_), .Y(new_n217_));
  NOR2x1_ASAP7_75t_R  g159(.A(new_n216_), .B(new_n217_), .Y(new_n218_));
  NOR2x1_ASAP7_75t_R  g160(.A(new_n101_), .B(new_n218_), .Y(new_n219_));
  NOR2x1_ASAP7_75t_R  g161(.A(new_n135_), .B(new_n185_), .Y(new_n220_));
  INVx1_ASAP7_75t_R   g162(.A(new_n220_), .Y(new_n221_));
  AO21x1_ASAP7_75t_R  g163(.A1(new_n134_), .A2(new_n184_), .B(new_n112_), .Y(new_n222_));
  AOI21x1_ASAP7_75t_R g164(.A1(new_n129_), .A2(new_n175_), .B(new_n222_), .Y(new_n223_));
  NOR2x1_ASAP7_75t_R  g165(.A(new_n219_), .B(new_n223_), .Y(new_n224_));
  NOR2x1_ASAP7_75t_R  g166(.A(new_n214_), .B(new_n224_), .Y(new_n225_));
  OR3x1_ASAP7_75t_R   g167(.A(new_n102_), .B(new_n217_), .C(new_n216_), .Y(new_n226_));
  INVx1_ASAP7_75t_R   g168(.A(new_n226_), .Y(new_n227_));
  AO21x1_ASAP7_75t_R  g169(.A1(new_n129_), .A2(new_n175_), .B(new_n220_), .Y(new_n228_));
  AO21x1_ASAP7_75t_R  g170(.A1(new_n112_), .A2(new_n228_), .B(new_n227_), .Y(new_n229_));
  INVx1_ASAP7_75t_R   g171(.A(new_n229_), .Y(new_n230_));
  NOR2x1_ASAP7_75t_R  g172(.A(new_n215_), .B(new_n229_), .Y(new_n231_));
  AO21x1_ASAP7_75t_R  g173(.A1(new_n61_), .A2(new_n231_), .B(new_n83_), .Y(new_n232_));
  AOI21x1_ASAP7_75t_R g174(.A1(new_n61_), .A2(new_n225_), .B(new_n232_), .Y(new_n233_));
  OR3x1_ASAP7_75t_R   g175(.A(new_n215_), .B(new_n219_), .C(new_n223_), .Y(new_n234_));
  OAI21x1_ASAP7_75t_R g176(.A1(new_n214_), .A2(new_n230_), .B(new_n234_), .Y(new_n235_));
  AND3x1_ASAP7_75t_R  g177(.A(new_n61_), .B(new_n83_), .C(new_n235_), .Y(new_n236_));
  XOR2x2_ASAP7_75t_R  g178(.A(new_n66_), .B(G7), .Y(new_n237_));
  XOR2x2_ASAP7_75t_R  g179(.A(G4), .B(new_n237_), .Y(new_n238_));
  NAND2x1_ASAP7_75t_R g180(.A(G9), .B(G14), .Y(new_n239_));
  AND2x2_ASAP7_75t_R  g181(.A(new_n72_), .B(new_n239_), .Y(new_n240_));
  NAND2x1_ASAP7_75t_R g182(.A(new_n70_), .B(new_n71_), .Y(new_n241_));
  AOI21x1_ASAP7_75t_R g183(.A1(new_n239_), .A2(new_n241_), .B(new_n72_), .Y(new_n242_));
  AO21x1_ASAP7_75t_R  g184(.A1(new_n240_), .A2(new_n241_), .B(new_n242_), .Y(new_n243_));
  INVx1_ASAP7_75t_R   g185(.A(new_n243_), .Y(new_n244_));
  NOR2x1_ASAP7_75t_R  g186(.A(new_n238_), .B(new_n243_), .Y(new_n245_));
  AND2x2_ASAP7_75t_R  g187(.A(new_n72_), .B(new_n241_), .Y(new_n246_));
  AO21x1_ASAP7_75t_R  g188(.A1(new_n239_), .A2(new_n246_), .B(new_n242_), .Y(new_n247_));
  AND2x2_ASAP7_75t_R  g189(.A(new_n238_), .B(new_n247_), .Y(new_n248_));
  OR3x1_ASAP7_75t_R   g190(.A(G33), .B(G23), .C(new_n79_), .Y(new_n249_));
  NAND2x1_ASAP7_75t_R g191(.A(G20), .B(new_n86_), .Y(new_n250_));
  OR3x1_ASAP7_75t_R   g192(.A(G33), .B(G13), .C(new_n250_), .Y(new_n251_));
  INVx1_ASAP7_75t_R   g193(.A(new_n251_), .Y(new_n252_));
  AO21x1_ASAP7_75t_R  g194(.A1(G13), .A2(new_n249_), .B(new_n252_), .Y(new_n253_));
  OR3x1_ASAP7_75t_R   g195(.A(new_n248_), .B(new_n253_), .C(new_n245_), .Y(new_n254_));
  INVx1_ASAP7_75t_R   g196(.A(new_n254_), .Y(new_n255_));
  NOR2x1_ASAP7_75t_R  g197(.A(new_n238_), .B(new_n247_), .Y(new_n256_));
  AO21x1_ASAP7_75t_R  g198(.A1(new_n238_), .A2(new_n243_), .B(new_n256_), .Y(new_n257_));
  NOR2x1_ASAP7_75t_R  g199(.A(new_n249_), .B(new_n252_), .Y(new_n258_));
  AOI21x1_ASAP7_75t_R g200(.A1(new_n80_), .A2(new_n251_), .B(new_n258_), .Y(new_n259_));
  AO21x1_ASAP7_75t_R  g201(.A1(new_n257_), .A2(new_n259_), .B(new_n255_), .Y(new_n260_));
  AO21x1_ASAP7_75t_R  g202(.A1(new_n61_), .A2(new_n86_), .B(new_n68_), .Y(new_n261_));
  AND2x2_ASAP7_75t_R  g203(.A(new_n61_), .B(new_n261_), .Y(new_n262_));
  NAND2x1_ASAP7_75t_R g204(.A(new_n260_), .B(new_n262_), .Y(new_n263_));
  OAI21x1_ASAP7_75t_R g205(.A1(new_n245_), .A2(new_n248_), .B(new_n253_), .Y(new_n264_));
  AO21x1_ASAP7_75t_R  g206(.A1(new_n238_), .A2(new_n243_), .B(new_n259_), .Y(new_n265_));
  OA21x2_ASAP7_75t_R  g207(.A1(new_n256_), .A2(new_n265_), .B(new_n264_), .Y(new_n266_));
  INVx1_ASAP7_75t_R   g208(.A(new_n266_), .Y(new_n267_));
  AND3x1_ASAP7_75t_R  g209(.A(new_n61_), .B(new_n267_), .C(new_n263_), .Y(new_n268_));
  AOI21x1_ASAP7_75t_R g210(.A1(new_n261_), .A2(new_n263_), .B(new_n268_), .Y(new_n269_));
  OR3x1_ASAP7_75t_R   g211(.A(new_n236_), .B(new_n269_), .C(new_n233_), .Y(new_n270_));
  NOR2x1_ASAP7_75t_R  g212(.A(G31), .B(G27), .Y(new_n271_));
  NAND2x1_ASAP7_75t_R g213(.A(new_n59_), .B(G18), .Y(new_n272_));
  OR3x1_ASAP7_75t_R   g214(.A(G33), .B(G15), .C(new_n272_), .Y(new_n273_));
  INVx1_ASAP7_75t_R   g215(.A(new_n273_), .Y(new_n274_));
  AND3x1_ASAP7_75t_R  g216(.A(new_n59_), .B(new_n60_), .C(G18), .Y(new_n275_));
  AO21x1_ASAP7_75t_R  g217(.A1(new_n273_), .A2(new_n275_), .B(G11), .Y(new_n276_));
  AO21x1_ASAP7_75t_R  g218(.A1(new_n65_), .A2(new_n273_), .B(new_n276_), .Y(new_n277_));
  NOR2x1_ASAP7_75t_R  g219(.A(new_n65_), .B(new_n275_), .Y(new_n278_));
  OR3x1_ASAP7_75t_R   g220(.A(new_n274_), .B(new_n278_), .C(new_n73_), .Y(new_n279_));
  AND3x1_ASAP7_75t_R  g221(.A(new_n247_), .B(new_n279_), .C(new_n277_), .Y(new_n280_));
  NOR2x1_ASAP7_75t_R  g222(.A(G11), .B(new_n273_), .Y(new_n281_));
  AO21x1_ASAP7_75t_R  g223(.A1(new_n73_), .A2(new_n278_), .B(new_n281_), .Y(new_n282_));
  OR3x1_ASAP7_75t_R   g224(.A(new_n73_), .B(new_n274_), .C(new_n278_), .Y(new_n283_));
  INVx1_ASAP7_75t_R   g225(.A(new_n283_), .Y(new_n284_));
  NAND2x1_ASAP7_75t_R g226(.A(G8), .B(new_n74_), .Y(new_n285_));
  NAND2x1_ASAP7_75t_R g227(.A(new_n62_), .B(G5), .Y(new_n286_));
  AND2x2_ASAP7_75t_R  g228(.A(G2), .B(new_n286_), .Y(new_n287_));
  AOI21x1_ASAP7_75t_R g229(.A1(new_n285_), .A2(new_n286_), .B(G2), .Y(new_n288_));
  AO21x1_ASAP7_75t_R  g230(.A1(new_n285_), .A2(new_n287_), .B(new_n288_), .Y(new_n289_));
  OAI21x1_ASAP7_75t_R g231(.A1(new_n243_), .A2(new_n283_), .B(new_n289_), .Y(new_n290_));
  AO21x1_ASAP7_75t_R  g232(.A1(new_n244_), .A2(new_n282_), .B(new_n290_), .Y(new_n291_));
  NOR2x1_ASAP7_75t_R  g233(.A(new_n280_), .B(new_n291_), .Y(new_n292_));
  INVx1_ASAP7_75t_R   g234(.A(new_n292_), .Y(new_n293_));
  OA21x2_ASAP7_75t_R  g235(.A1(new_n282_), .A2(new_n284_), .B(new_n244_), .Y(new_n294_));
  NOR2x1_ASAP7_75t_R  g236(.A(new_n280_), .B(new_n294_), .Y(new_n295_));
  AND3x1_ASAP7_75t_R  g237(.A(G2), .B(new_n285_), .C(new_n286_), .Y(new_n296_));
  NOR2x1_ASAP7_75t_R  g238(.A(new_n288_), .B(new_n296_), .Y(new_n297_));
  NOR2x1_ASAP7_75t_R  g239(.A(new_n292_), .B(new_n297_), .Y(new_n298_));
  AO21x1_ASAP7_75t_R  g240(.A1(new_n293_), .A2(new_n295_), .B(new_n298_), .Y(new_n299_));
  INVx1_ASAP7_75t_R   g241(.A(new_n299_), .Y(new_n300_));
  AND3x1_ASAP7_75t_R  g242(.A(new_n61_), .B(new_n76_), .C(new_n300_), .Y(new_n301_));
  NOR2x1_ASAP7_75t_R  g243(.A(new_n289_), .B(new_n295_), .Y(new_n302_));
  AOI21x1_ASAP7_75t_R g244(.A1(new_n277_), .A2(new_n279_), .B(new_n247_), .Y(new_n303_));
  OR3x1_ASAP7_75t_R   g245(.A(new_n244_), .B(new_n284_), .C(new_n282_), .Y(new_n304_));
  INVx1_ASAP7_75t_R   g246(.A(new_n304_), .Y(new_n305_));
  OR3x1_ASAP7_75t_R   g247(.A(new_n297_), .B(new_n305_), .C(new_n303_), .Y(new_n306_));
  INVx1_ASAP7_75t_R   g248(.A(new_n306_), .Y(new_n307_));
  AO21x1_ASAP7_75t_R  g249(.A1(new_n61_), .A2(new_n307_), .B(new_n76_), .Y(new_n308_));
  AOI21x1_ASAP7_75t_R g250(.A1(new_n61_), .A2(new_n302_), .B(new_n308_), .Y(new_n309_));
  AO21x1_ASAP7_75t_R  g251(.A1(new_n271_), .A2(new_n300_), .B(new_n309_), .Y(new_n310_));
  NAND2x1_ASAP7_75t_R g252(.A(new_n65_), .B(G10), .Y(new_n311_));
  NAND2x1_ASAP7_75t_R g253(.A(G15), .B(new_n66_), .Y(new_n312_));
  AND2x2_ASAP7_75t_R  g254(.A(G12), .B(new_n312_), .Y(new_n313_));
  AOI21x1_ASAP7_75t_R g255(.A1(new_n311_), .A2(new_n312_), .B(G12), .Y(new_n314_));
  AO21x1_ASAP7_75t_R  g256(.A1(new_n311_), .A2(new_n313_), .B(new_n314_), .Y(new_n315_));
  NAND2x1_ASAP7_75t_R g257(.A(new_n62_), .B(G6), .Y(new_n316_));
  OA21x2_ASAP7_75t_R  g258(.A1(new_n62_), .A2(G6), .B(new_n316_), .Y(new_n317_));
  NOR2x1_ASAP7_75t_R  g259(.A(G3), .B(new_n317_), .Y(new_n318_));
  AOI21x1_ASAP7_75t_R g260(.A1(G3), .A2(new_n317_), .B(new_n318_), .Y(new_n319_));
  NOR2x1_ASAP7_75t_R  g261(.A(new_n315_), .B(new_n319_), .Y(new_n320_));
  AND2x2_ASAP7_75t_R  g262(.A(G12), .B(new_n311_), .Y(new_n321_));
  AO21x1_ASAP7_75t_R  g263(.A1(new_n312_), .A2(new_n321_), .B(new_n314_), .Y(new_n322_));
  OA21x2_ASAP7_75t_R  g264(.A1(new_n62_), .A2(G6), .B(G3), .Y(new_n323_));
  AOI21x1_ASAP7_75t_R g265(.A1(new_n316_), .A2(new_n323_), .B(new_n318_), .Y(new_n324_));
  AO21x1_ASAP7_75t_R  g266(.A1(new_n322_), .A2(new_n324_), .B(new_n320_), .Y(new_n325_));
  OR3x1_ASAP7_75t_R   g267(.A(G33), .B(G23), .C(new_n68_), .Y(new_n326_));
  NOR2x1_ASAP7_75t_R  g268(.A(new_n322_), .B(new_n324_), .Y(new_n327_));
  AO21x1_ASAP7_75t_R  g269(.A1(new_n315_), .A2(new_n319_), .B(new_n327_), .Y(new_n328_));
  NOR2x1_ASAP7_75t_R  g270(.A(new_n326_), .B(new_n328_), .Y(new_n329_));
  AO21x1_ASAP7_75t_R  g271(.A1(new_n325_), .A2(new_n326_), .B(new_n329_), .Y(new_n330_));
  INVx1_ASAP7_75t_R   g272(.A(new_n330_), .Y(new_n331_));
  OA21x2_ASAP7_75t_R  g273(.A1(G31), .A2(new_n331_), .B(G28), .Y(new_n332_));
  NOR2x1_ASAP7_75t_R  g274(.A(G31), .B(G28), .Y(new_n333_));
  NOR2x1_ASAP7_75t_R  g275(.A(new_n325_), .B(new_n326_), .Y(new_n334_));
  AO21x1_ASAP7_75t_R  g276(.A1(new_n326_), .A2(new_n328_), .B(new_n334_), .Y(new_n335_));
  AND3x1_ASAP7_75t_R  g277(.A(new_n61_), .B(new_n69_), .C(new_n335_), .Y(new_n336_));
  NOR2x1_ASAP7_75t_R  g278(.A(new_n59_), .B(G23), .Y(new_n337_));
  OA21x2_ASAP7_75t_R  g279(.A1(G31), .A2(G30), .B(G32), .Y(new_n338_));
  OR3x1_ASAP7_75t_R   g280(.A(G33), .B(new_n337_), .C(new_n338_), .Y(new_n339_));
  OR3x1_ASAP7_75t_R   g281(.A(new_n336_), .B(new_n339_), .C(new_n332_), .Y(new_n340_));
  OR3x1_ASAP7_75t_R   g282(.A(new_n301_), .B(new_n309_), .C(new_n340_), .Y(new_n341_));
  OR3x1_ASAP7_75t_R   g283(.A(new_n270_), .B(new_n341_), .C(new_n210_), .Y(new_n342_));
  INVx1_ASAP7_75t_R   g284(.A(new_n342_), .Y(new_n343_));
  OR3x1_ASAP7_75t_R   g285(.A(new_n71_), .B(new_n340_), .C(new_n310_), .Y(new_n344_));
  OR3x1_ASAP7_75t_R   g286(.A(new_n270_), .B(new_n344_), .C(new_n210_), .Y(new_n345_));
  OAI21x1_ASAP7_75t_R g287(.A1(G14), .A2(new_n343_), .B(new_n345_), .Y(G1899));
  NOR2x1_ASAP7_75t_R  g288(.A(new_n167_), .B(new_n208_), .Y(new_n347_));
  AO21x1_ASAP7_75t_R  g289(.A1(new_n88_), .A2(new_n160_), .B(new_n163_), .Y(new_n348_));
  AOI21x1_ASAP7_75t_R g290(.A1(new_n153_), .A2(new_n160_), .B(new_n348_), .Y(new_n349_));
  OR2x4_ASAP7_75t_R   g291(.A(new_n347_), .B(new_n349_), .Y(new_n350_));
  OA21x2_ASAP7_75t_R  g292(.A1(G31), .A2(G29), .B(G32), .Y(new_n351_));
  OR3x1_ASAP7_75t_R   g293(.A(G33), .B(new_n337_), .C(new_n351_), .Y(new_n352_));
  OR3x1_ASAP7_75t_R   g294(.A(new_n301_), .B(new_n352_), .C(new_n309_), .Y(new_n353_));
  AO21x1_ASAP7_75t_R  g295(.A1(new_n333_), .A2(new_n335_), .B(new_n332_), .Y(new_n354_));
  OR3x1_ASAP7_75t_R   g296(.A(new_n81_), .B(new_n354_), .C(new_n353_), .Y(new_n355_));
  OR3x1_ASAP7_75t_R   g297(.A(new_n270_), .B(new_n355_), .C(new_n350_), .Y(new_n356_));
  INVx1_ASAP7_75t_R   g298(.A(new_n356_), .Y(new_n357_));
  OR3x1_ASAP7_75t_R   g299(.A(G31), .B(G25), .C(new_n205_), .Y(new_n358_));
  OAI21x1_ASAP7_75t_R g300(.A1(new_n84_), .A2(new_n200_), .B(new_n358_), .Y(new_n359_));
  AO21x1_ASAP7_75t_R  g301(.A1(G31), .A2(G25), .B(new_n359_), .Y(new_n360_));
  NOR2x1_ASAP7_75t_R  g302(.A(new_n79_), .B(new_n86_), .Y(new_n361_));
  AO21x1_ASAP7_75t_R  g303(.A1(G31), .A2(G20), .B(new_n361_), .Y(new_n362_));
  INVx1_ASAP7_75t_R   g304(.A(new_n362_), .Y(new_n363_));
  NOR2x1_ASAP7_75t_R  g305(.A(new_n141_), .B(new_n151_), .Y(new_n364_));
  AND3x1_ASAP7_75t_R  g306(.A(new_n61_), .B(new_n88_), .C(new_n364_), .Y(new_n365_));
  OR3x1_ASAP7_75t_R   g307(.A(new_n155_), .B(new_n156_), .C(G31), .Y(new_n366_));
  AND3x1_ASAP7_75t_R  g308(.A(new_n158_), .B(new_n366_), .C(new_n162_), .Y(new_n367_));
  AO21x1_ASAP7_75t_R  g309(.A1(new_n162_), .A2(new_n365_), .B(new_n367_), .Y(new_n368_));
  AO21x1_ASAP7_75t_R  g310(.A1(new_n360_), .A2(new_n362_), .B(new_n368_), .Y(new_n369_));
  NOR2x1_ASAP7_75t_R  g311(.A(new_n83_), .B(new_n235_), .Y(new_n370_));
  AO21x1_ASAP7_75t_R  g312(.A1(G31), .A2(G26), .B(new_n370_), .Y(new_n371_));
  AO21x1_ASAP7_75t_R  g313(.A1(new_n214_), .A2(new_n230_), .B(new_n225_), .Y(new_n372_));
  AND3x1_ASAP7_75t_R  g314(.A(new_n61_), .B(new_n83_), .C(new_n372_), .Y(new_n373_));
  AOI21x1_ASAP7_75t_R g315(.A1(new_n61_), .A2(new_n260_), .B(new_n261_), .Y(new_n374_));
  AO21x1_ASAP7_75t_R  g316(.A1(new_n262_), .A2(new_n267_), .B(new_n374_), .Y(new_n375_));
  OR3x1_ASAP7_75t_R   g317(.A(new_n373_), .B(new_n375_), .C(new_n371_), .Y(new_n376_));
  OA21x2_ASAP7_75t_R  g318(.A1(G31), .A2(new_n299_), .B(G27), .Y(new_n377_));
  NOR2x1_ASAP7_75t_R  g319(.A(new_n302_), .B(new_n307_), .Y(new_n378_));
  INVx1_ASAP7_75t_R   g320(.A(new_n378_), .Y(new_n379_));
  AOI21x1_ASAP7_75t_R g321(.A1(new_n61_), .A2(new_n335_), .B(new_n69_), .Y(new_n380_));
  AO21x1_ASAP7_75t_R  g322(.A1(new_n330_), .A2(new_n333_), .B(new_n380_), .Y(new_n381_));
  AO21x1_ASAP7_75t_R  g323(.A1(new_n271_), .A2(new_n379_), .B(new_n381_), .Y(new_n382_));
  OR3x1_ASAP7_75t_R   g324(.A(new_n377_), .B(new_n382_), .C(new_n352_), .Y(new_n383_));
  OR2x4_ASAP7_75t_R   g325(.A(new_n376_), .B(new_n383_), .Y(new_n384_));
  OR3x1_ASAP7_75t_R   g326(.A(new_n376_), .B(new_n383_), .C(new_n369_), .Y(new_n385_));
  AO21x1_ASAP7_75t_R  g327(.A1(new_n81_), .A2(new_n385_), .B(new_n357_), .Y(G1884));
  OR3x1_ASAP7_75t_R   g328(.A(new_n75_), .B(new_n354_), .C(new_n353_), .Y(new_n387_));
  OR3x1_ASAP7_75t_R   g329(.A(new_n270_), .B(new_n387_), .C(new_n350_), .Y(new_n388_));
  INVx1_ASAP7_75t_R   g330(.A(new_n388_), .Y(new_n389_));
  AO21x1_ASAP7_75t_R  g331(.A1(new_n75_), .A2(new_n385_), .B(new_n389_), .Y(G1885));
  OR3x1_ASAP7_75t_R   g332(.A(new_n80_), .B(new_n340_), .C(new_n310_), .Y(new_n391_));
  OR3x1_ASAP7_75t_R   g333(.A(new_n270_), .B(new_n391_), .C(new_n210_), .Y(new_n392_));
  OAI21x1_ASAP7_75t_R g334(.A1(G13), .A2(new_n343_), .B(new_n392_), .Y(G1898));
  OR3x1_ASAP7_75t_R   g335(.A(new_n64_), .B(new_n354_), .C(new_n353_), .Y(new_n394_));
  OR3x1_ASAP7_75t_R   g336(.A(new_n270_), .B(new_n394_), .C(new_n350_), .Y(new_n395_));
  INVx1_ASAP7_75t_R   g337(.A(new_n395_), .Y(new_n396_));
  AO21x1_ASAP7_75t_R  g338(.A1(new_n64_), .A2(new_n385_), .B(new_n396_), .Y(G1886));
  OR3x1_ASAP7_75t_R   g339(.A(new_n78_), .B(new_n354_), .C(new_n353_), .Y(new_n398_));
  OR3x1_ASAP7_75t_R   g340(.A(new_n270_), .B(new_n398_), .C(new_n350_), .Y(new_n399_));
  INVx1_ASAP7_75t_R   g341(.A(new_n399_), .Y(new_n400_));
  AO21x1_ASAP7_75t_R  g342(.A1(new_n78_), .A2(new_n385_), .B(new_n400_), .Y(G1887));
  OR3x1_ASAP7_75t_R   g343(.A(new_n339_), .B(new_n381_), .C(new_n310_), .Y(new_n402_));
  OR3x1_ASAP7_75t_R   g344(.A(new_n376_), .B(new_n402_), .C(new_n369_), .Y(new_n403_));
  INVx1_ASAP7_75t_R   g345(.A(new_n403_), .Y(new_n404_));
  OR3x1_ASAP7_75t_R   g346(.A(new_n66_), .B(new_n340_), .C(new_n310_), .Y(new_n405_));
  OR3x1_ASAP7_75t_R   g347(.A(new_n270_), .B(new_n405_), .C(new_n350_), .Y(new_n406_));
  OAI21x1_ASAP7_75t_R g348(.A1(G10), .A2(new_n404_), .B(new_n406_), .Y(G1888));
  OR3x1_ASAP7_75t_R   g349(.A(new_n65_), .B(new_n340_), .C(new_n310_), .Y(new_n408_));
  OR3x1_ASAP7_75t_R   g350(.A(new_n270_), .B(new_n408_), .C(new_n350_), .Y(new_n409_));
  OAI21x1_ASAP7_75t_R g351(.A1(G15), .A2(new_n404_), .B(new_n409_), .Y(G1889));
  OR3x1_ASAP7_75t_R   g352(.A(new_n72_), .B(new_n340_), .C(new_n310_), .Y(new_n411_));
  OR3x1_ASAP7_75t_R   g353(.A(new_n270_), .B(new_n411_), .C(new_n350_), .Y(new_n412_));
  OAI21x1_ASAP7_75t_R g354(.A1(G16), .A2(new_n404_), .B(new_n412_), .Y(G1890));
  NOR2x1_ASAP7_75t_R  g355(.A(new_n84_), .B(new_n206_), .Y(new_n414_));
  OR3x1_ASAP7_75t_R   g356(.A(new_n202_), .B(new_n363_), .C(new_n414_), .Y(new_n415_));
  OR2x4_ASAP7_75t_R   g357(.A(new_n349_), .B(new_n415_), .Y(new_n416_));
  OR3x1_ASAP7_75t_R   g358(.A(new_n74_), .B(new_n354_), .C(new_n353_), .Y(new_n417_));
  OR3x1_ASAP7_75t_R   g359(.A(new_n270_), .B(new_n417_), .C(new_n416_), .Y(new_n418_));
  AO21x1_ASAP7_75t_R  g360(.A1(new_n271_), .A2(new_n300_), .B(new_n354_), .Y(new_n419_));
  OR3x1_ASAP7_75t_R   g361(.A(new_n309_), .B(new_n352_), .C(new_n419_), .Y(new_n420_));
  OR2x4_ASAP7_75t_R   g362(.A(new_n270_), .B(new_n349_), .Y(new_n421_));
  OR3x1_ASAP7_75t_R   g363(.A(new_n415_), .B(new_n420_), .C(new_n421_), .Y(new_n422_));
  INVx1_ASAP7_75t_R   g364(.A(new_n422_), .Y(new_n423_));
  OAI21x1_ASAP7_75t_R g365(.A1(G5), .A2(new_n423_), .B(new_n418_), .Y(G1891));
  OR3x1_ASAP7_75t_R   g366(.A(new_n63_), .B(new_n354_), .C(new_n353_), .Y(new_n425_));
  OR3x1_ASAP7_75t_R   g367(.A(new_n270_), .B(new_n425_), .C(new_n416_), .Y(new_n426_));
  INVx1_ASAP7_75t_R   g368(.A(new_n426_), .Y(new_n427_));
  OR3x1_ASAP7_75t_R   g369(.A(new_n383_), .B(new_n415_), .C(new_n421_), .Y(new_n428_));
  AO21x1_ASAP7_75t_R  g370(.A1(new_n63_), .A2(new_n428_), .B(new_n427_), .Y(G1892));
  OR3x1_ASAP7_75t_R   g371(.A(new_n77_), .B(new_n354_), .C(new_n353_), .Y(new_n430_));
  OR3x1_ASAP7_75t_R   g372(.A(new_n270_), .B(new_n430_), .C(new_n416_), .Y(new_n431_));
  OAI21x1_ASAP7_75t_R g373(.A1(G7), .A2(new_n423_), .B(new_n431_), .Y(G1893));
  OR3x1_ASAP7_75t_R   g374(.A(new_n62_), .B(new_n354_), .C(new_n353_), .Y(new_n433_));
  OR3x1_ASAP7_75t_R   g375(.A(new_n270_), .B(new_n433_), .C(new_n416_), .Y(new_n434_));
  INVx1_ASAP7_75t_R   g376(.A(new_n434_), .Y(new_n435_));
  AO21x1_ASAP7_75t_R  g377(.A1(new_n62_), .A2(new_n428_), .B(new_n435_), .Y(G1894));
  OR3x1_ASAP7_75t_R   g378(.A(new_n402_), .B(new_n415_), .C(new_n421_), .Y(new_n437_));
  INVx1_ASAP7_75t_R   g379(.A(new_n437_), .Y(new_n438_));
  OR3x1_ASAP7_75t_R   g380(.A(new_n70_), .B(new_n340_), .C(new_n310_), .Y(new_n439_));
  OR3x1_ASAP7_75t_R   g381(.A(new_n270_), .B(new_n439_), .C(new_n416_), .Y(new_n440_));
  OAI21x1_ASAP7_75t_R g382(.A1(G9), .A2(new_n438_), .B(new_n440_), .Y(G1895));
  OR3x1_ASAP7_75t_R   g383(.A(new_n73_), .B(new_n340_), .C(new_n310_), .Y(new_n442_));
  OR3x1_ASAP7_75t_R   g384(.A(new_n270_), .B(new_n442_), .C(new_n210_), .Y(new_n443_));
  OAI21x1_ASAP7_75t_R g385(.A1(G11), .A2(new_n343_), .B(new_n443_), .Y(G1896));
  OR3x1_ASAP7_75t_R   g386(.A(new_n67_), .B(new_n340_), .C(new_n310_), .Y(new_n445_));
  OR3x1_ASAP7_75t_R   g387(.A(new_n270_), .B(new_n445_), .C(new_n210_), .Y(new_n446_));
  OAI21x1_ASAP7_75t_R g388(.A1(G12), .A2(new_n343_), .B(new_n446_), .Y(G1897));
  OR2x4_ASAP7_75t_R   g389(.A(new_n270_), .B(new_n347_), .Y(new_n448_));
  NOR2x1_ASAP7_75t_R  g390(.A(G33), .B(G32), .Y(new_n449_));
  INVx1_ASAP7_75t_R   g391(.A(new_n449_), .Y(new_n450_));
  OR3x1_ASAP7_75t_R   g392(.A(new_n337_), .B(new_n450_), .C(new_n336_), .Y(new_n451_));
  OR3x1_ASAP7_75t_R   g393(.A(new_n332_), .B(new_n451_), .C(new_n310_), .Y(new_n452_));
  OR3x1_ASAP7_75t_R   g394(.A(new_n164_), .B(new_n452_), .C(new_n448_), .Y(new_n453_));
  OR3x1_ASAP7_75t_R   g395(.A(new_n415_), .B(new_n452_), .C(new_n421_), .Y(new_n454_));
  OR2x4_ASAP7_75t_R   g396(.A(new_n376_), .B(new_n452_), .Y(new_n455_));
  OR3x1_ASAP7_75t_R   g397(.A(new_n164_), .B(new_n415_), .C(new_n455_), .Y(new_n456_));
  AND2x2_ASAP7_75t_R  g398(.A(G32), .B(new_n456_), .Y(new_n457_));
  AND3x1_ASAP7_75t_R  g399(.A(new_n453_), .B(new_n454_), .C(new_n457_), .Y(new_n458_));
  OR3x1_ASAP7_75t_R   g400(.A(new_n341_), .B(new_n349_), .C(new_n448_), .Y(new_n459_));
  NAND2x1_ASAP7_75t_R g401(.A(new_n342_), .B(new_n459_), .Y(new_n460_));
  OR3x1_ASAP7_75t_R   g402(.A(new_n270_), .B(new_n341_), .C(new_n416_), .Y(new_n461_));
  INVx1_ASAP7_75t_R   g403(.A(new_n461_), .Y(new_n462_));
  OR3x1_ASAP7_75t_R   g404(.A(new_n270_), .B(new_n420_), .C(new_n350_), .Y(new_n463_));
  INVx1_ASAP7_75t_R   g405(.A(new_n463_), .Y(new_n464_));
  NOR2x1_ASAP7_75t_R  g406(.A(new_n423_), .B(new_n464_), .Y(new_n465_));
  INVx1_ASAP7_75t_R   g407(.A(new_n465_), .Y(new_n466_));
  OR3x1_ASAP7_75t_R   g408(.A(new_n462_), .B(new_n466_), .C(new_n460_), .Y(new_n467_));
  INVx1_ASAP7_75t_R   g409(.A(new_n467_), .Y(new_n468_));
  OR3x1_ASAP7_75t_R   g410(.A(new_n269_), .B(new_n354_), .C(new_n310_), .Y(new_n469_));
  OR3x1_ASAP7_75t_R   g411(.A(new_n233_), .B(new_n236_), .C(new_n469_), .Y(new_n470_));
  OR3x1_ASAP7_75t_R   g412(.A(new_n161_), .B(new_n168_), .C(new_n154_), .Y(new_n471_));
  OR3x1_ASAP7_75t_R   g413(.A(new_n162_), .B(new_n202_), .C(new_n414_), .Y(new_n472_));
  OR3x1_ASAP7_75t_R   g414(.A(new_n471_), .B(new_n472_), .C(new_n470_), .Y(new_n473_));
  AND3x1_ASAP7_75t_R  g415(.A(new_n60_), .B(new_n473_), .C(new_n468_), .Y(new_n474_));
  AND2x2_ASAP7_75t_R  g416(.A(new_n449_), .B(new_n473_), .Y(new_n475_));
  AOI21x1_ASAP7_75t_R g417(.A1(new_n458_), .A2(new_n474_), .B(new_n475_), .Y(G1900));
  AND2x2_ASAP7_75t_R  g418(.A(new_n140_), .B(new_n150_), .Y(new_n477_));
  AO21x1_ASAP7_75t_R  g419(.A1(new_n119_), .A2(new_n146_), .B(new_n477_), .Y(new_n478_));
  OR3x1_ASAP7_75t_R   g420(.A(G31), .B(new_n82_), .C(new_n87_), .Y(new_n479_));
  INVx1_ASAP7_75t_R   g421(.A(new_n479_), .Y(new_n480_));
  OR3x1_ASAP7_75t_R   g422(.A(new_n478_), .B(new_n479_), .C(new_n468_), .Y(new_n481_));
  AND3x1_ASAP7_75t_R  g423(.A(new_n342_), .B(new_n459_), .C(new_n461_), .Y(new_n482_));
  INVx1_ASAP7_75t_R   g424(.A(new_n482_), .Y(new_n483_));
  OAI21x1_ASAP7_75t_R g425(.A1(new_n465_), .A2(new_n479_), .B(new_n478_), .Y(new_n484_));
  AO21x1_ASAP7_75t_R  g426(.A1(new_n480_), .A2(new_n483_), .B(new_n484_), .Y(new_n485_));
  AOI21x1_ASAP7_75t_R g427(.A1(new_n481_), .A2(new_n485_), .B(new_n449_), .Y(G1901));
  NOR2x1_ASAP7_75t_R  g428(.A(G31), .B(new_n84_), .Y(new_n487_));
  INVx1_ASAP7_75t_R   g429(.A(new_n487_), .Y(new_n488_));
  AO21x1_ASAP7_75t_R  g430(.A1(new_n466_), .A2(new_n487_), .B(new_n199_), .Y(new_n489_));
  AO21x1_ASAP7_75t_R  g431(.A1(new_n483_), .A2(new_n487_), .B(new_n489_), .Y(new_n490_));
  OR3x1_ASAP7_75t_R   g432(.A(new_n200_), .B(new_n488_), .C(new_n468_), .Y(new_n491_));
  AOI21x1_ASAP7_75t_R g433(.A1(new_n490_), .A2(new_n491_), .B(new_n449_), .Y(G1902));
  NOR2x1_ASAP7_75t_R  g434(.A(G31), .B(new_n76_), .Y(new_n493_));
  INVx1_ASAP7_75t_R   g435(.A(new_n493_), .Y(new_n494_));
  AO21x1_ASAP7_75t_R  g436(.A1(new_n466_), .A2(new_n493_), .B(new_n379_), .Y(new_n495_));
  AO21x1_ASAP7_75t_R  g437(.A1(new_n483_), .A2(new_n493_), .B(new_n495_), .Y(new_n496_));
  OR3x1_ASAP7_75t_R   g438(.A(new_n378_), .B(new_n494_), .C(new_n468_), .Y(new_n497_));
  AOI21x1_ASAP7_75t_R g439(.A1(new_n496_), .A2(new_n497_), .B(new_n449_), .Y(G1903));
  NOR2x1_ASAP7_75t_R  g440(.A(G31), .B(new_n69_), .Y(new_n499_));
  INVx1_ASAP7_75t_R   g441(.A(new_n499_), .Y(new_n500_));
  AO21x1_ASAP7_75t_R  g442(.A1(new_n466_), .A2(new_n499_), .B(new_n330_), .Y(new_n501_));
  AO21x1_ASAP7_75t_R  g443(.A1(new_n483_), .A2(new_n499_), .B(new_n501_), .Y(new_n502_));
  OR3x1_ASAP7_75t_R   g444(.A(new_n331_), .B(new_n500_), .C(new_n468_), .Y(new_n503_));
  AOI21x1_ASAP7_75t_R g445(.A1(new_n502_), .A2(new_n503_), .B(new_n449_), .Y(G1904));
  OR3x1_ASAP7_75t_R   g446(.A(G31), .B(new_n68_), .C(new_n166_), .Y(new_n505_));
  INVx1_ASAP7_75t_R   g447(.A(new_n505_), .Y(new_n506_));
  AO21x1_ASAP7_75t_R  g448(.A1(new_n466_), .A2(new_n506_), .B(new_n267_), .Y(new_n507_));
  AO21x1_ASAP7_75t_R  g449(.A1(new_n483_), .A2(new_n506_), .B(new_n507_), .Y(new_n508_));
  OR3x1_ASAP7_75t_R   g450(.A(new_n266_), .B(new_n505_), .C(new_n468_), .Y(new_n509_));
  AOI21x1_ASAP7_75t_R g451(.A1(new_n508_), .A2(new_n509_), .B(new_n449_), .Y(G1905));
  NOR2x1_ASAP7_75t_R  g452(.A(G33), .B(G29), .Y(new_n511_));
  OR3x1_ASAP7_75t_R   g453(.A(new_n118_), .B(new_n511_), .C(new_n114_), .Y(new_n512_));
  INVx1_ASAP7_75t_R   g454(.A(new_n512_), .Y(new_n513_));
  AO21x1_ASAP7_75t_R  g455(.A1(new_n60_), .A2(new_n423_), .B(new_n512_), .Y(new_n514_));
  AOI21x1_ASAP7_75t_R g456(.A1(new_n60_), .A2(new_n464_), .B(new_n514_), .Y(new_n515_));
  AOI21x1_ASAP7_75t_R g457(.A1(new_n369_), .A2(new_n416_), .B(new_n384_), .Y(new_n516_));
  OR3x1_ASAP7_75t_R   g458(.A(new_n148_), .B(new_n511_), .C(new_n149_), .Y(new_n517_));
  AND3x1_ASAP7_75t_R  g459(.A(new_n60_), .B(new_n517_), .C(new_n516_), .Y(new_n518_));
  AOI21x1_ASAP7_75t_R g460(.A1(new_n60_), .A2(new_n85_), .B(new_n511_), .Y(new_n519_));
  OR3x1_ASAP7_75t_R   g461(.A(new_n518_), .B(new_n519_), .C(new_n515_), .Y(new_n520_));
  AO21x1_ASAP7_75t_R  g462(.A1(new_n60_), .A2(new_n516_), .B(new_n517_), .Y(new_n521_));
  OR3x1_ASAP7_75t_R   g463(.A(G33), .B(new_n513_), .C(new_n465_), .Y(new_n522_));
  AOI21x1_ASAP7_75t_R g464(.A1(G21), .A2(G29), .B(G33), .Y(new_n523_));
  AO21x1_ASAP7_75t_R  g465(.A1(new_n521_), .A2(new_n522_), .B(new_n523_), .Y(new_n524_));
  NAND2x1_ASAP7_75t_R g466(.A(new_n520_), .B(new_n524_), .Y(G1906));
  AO21x1_ASAP7_75t_R  g467(.A1(G30), .A2(G22), .B(G33), .Y(new_n526_));
  XOR2x2_ASAP7_75t_R  g468(.A(G9), .B(new_n71_), .Y(new_n527_));
  INVx1_ASAP7_75t_R   g469(.A(new_n527_), .Y(new_n528_));
  AND3x1_ASAP7_75t_R  g470(.A(new_n135_), .B(new_n185_), .C(new_n528_), .Y(new_n529_));
  AO21x1_ASAP7_75t_R  g471(.A1(new_n217_), .A2(new_n528_), .B(new_n529_), .Y(new_n530_));
  NOR2x1_ASAP7_75t_R  g472(.A(new_n175_), .B(new_n528_), .Y(new_n531_));
  AO21x1_ASAP7_75t_R  g473(.A1(new_n128_), .A2(new_n527_), .B(new_n531_), .Y(new_n532_));
  NOR2x1_ASAP7_75t_R  g474(.A(G33), .B(G30), .Y(new_n533_));
  AO21x1_ASAP7_75t_R  g475(.A1(new_n221_), .A2(new_n532_), .B(new_n533_), .Y(new_n534_));
  NOR2x1_ASAP7_75t_R  g476(.A(new_n530_), .B(new_n534_), .Y(new_n535_));
  OR3x1_ASAP7_75t_R   g477(.A(G33), .B(new_n535_), .C(new_n482_), .Y(new_n536_));
  INVx1_ASAP7_75t_R   g478(.A(new_n536_), .Y(new_n537_));
  AO21x1_ASAP7_75t_R  g479(.A1(new_n218_), .A2(new_n527_), .B(new_n533_), .Y(new_n538_));
  AO21x1_ASAP7_75t_R  g480(.A1(new_n228_), .A2(new_n528_), .B(new_n538_), .Y(new_n539_));
  INVx1_ASAP7_75t_R   g481(.A(new_n539_), .Y(new_n540_));
  OR3x1_ASAP7_75t_R   g482(.A(new_n404_), .B(new_n438_), .C(new_n343_), .Y(new_n541_));
  NOR2x1_ASAP7_75t_R  g483(.A(new_n539_), .B(new_n541_), .Y(new_n542_));
  AO21x1_ASAP7_75t_R  g484(.A1(G33), .A2(new_n540_), .B(new_n542_), .Y(new_n543_));
  OA21x2_ASAP7_75t_R  g485(.A1(G33), .A2(new_n482_), .B(new_n535_), .Y(new_n544_));
  AND3x1_ASAP7_75t_R  g486(.A(new_n60_), .B(new_n539_), .C(new_n541_), .Y(new_n545_));
  OR3x1_ASAP7_75t_R   g487(.A(new_n526_), .B(new_n545_), .C(new_n544_), .Y(new_n546_));
  INVx1_ASAP7_75t_R   g488(.A(new_n546_), .Y(new_n547_));
  AO21x1_ASAP7_75t_R  g489(.A1(new_n526_), .A2(new_n543_), .B(new_n547_), .Y(new_n548_));
  AO21x1_ASAP7_75t_R  g490(.A1(new_n526_), .A2(new_n537_), .B(new_n548_), .Y(G1907));
  NOR2x1_ASAP7_75t_R  g491(.A(G31), .B(new_n83_), .Y(new_n550_));
  INVx1_ASAP7_75t_R   g492(.A(new_n550_), .Y(new_n551_));
  OR3x1_ASAP7_75t_R   g493(.A(new_n229_), .B(new_n551_), .C(new_n468_), .Y(new_n552_));
  AO21x1_ASAP7_75t_R  g494(.A1(new_n466_), .A2(new_n550_), .B(new_n230_), .Y(new_n553_));
  AO21x1_ASAP7_75t_R  g495(.A1(new_n483_), .A2(new_n550_), .B(new_n553_), .Y(new_n554_));
  INVx1_ASAP7_75t_R   g496(.A(new_n554_), .Y(new_n555_));
  AO21x1_ASAP7_75t_R  g497(.A1(new_n552_), .A2(new_n554_), .B(new_n214_), .Y(new_n556_));
  AND3x1_ASAP7_75t_R  g498(.A(new_n224_), .B(new_n550_), .C(new_n467_), .Y(new_n557_));
  OR3x1_ASAP7_75t_R   g499(.A(new_n215_), .B(new_n555_), .C(new_n557_), .Y(new_n558_));
  AOI21x1_ASAP7_75t_R g500(.A1(new_n556_), .A2(new_n558_), .B(new_n449_), .Y(G1908));
endmodule


