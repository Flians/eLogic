module mapped(G3,G2,G4,G5,G1,G16,G17);
input G3,G2,G4,G5,G1;
output G16,G17;
wire __emorphic_0,__emorphic_1,__emorphic_2,__emorphic_3,__emorphic_4,__emorphic_5,__emorphic_6,__emorphic_7,__emorphic_8;
assign __emorphic_0 = ~G4;
assign __emorphic_1 = ~G3;
assign __emorphic_2 = (__emorphic_0 | __emorphic_1);
assign __emorphic_3 = (G3 & G1);
assign __emorphic_4 = (__emorphic_2 | __emorphic_3);
assign __emorphic_5 = (__emorphic_3 | G2);
assign __emorphic_6 = (__emorphic_4 & __emorphic_5);
assign __emorphic_7 = (G2 | G5);
assign __emorphic_8 = (__emorphic_2 & __emorphic_7);
assign G16 = __emorphic_6;
assign G17 = __emorphic_8;
endmodule
