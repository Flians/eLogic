// Benchmark "/home/flynn/workplace/MIGBalance/results_v2/emorphic_random_delay_20261012/c17/rewritten_egraph_with_weight_cost_serd_random-based-faster-bottom-up_6/logic" written by ABC on Mon Oct 12 14:25:16 2026

module \/home/flynn/workplace/MIGBalance/results_v2/emorphic_random_delay_20261012/c17/rewritten_egraph_with_weight_cost_serd_random-based-faster-bottom-up_6/logic  ( 
    G3, G2, G4, G5, G1,
    G16, G17  );
  input  G3, G2, G4, G5, G1;
  output G16, G17;
  wire new_n8_, new_n9_, new_n10_, new_n11_, new_n13_;
  INVx1_ASAP7_75t_R   g0(.A(G3), .Y(new_n8_));
  INVx1_ASAP7_75t_R   g1(.A(G2), .Y(new_n9_));
  NOR2x1_ASAP7_75t_R  g2(.A(new_n9_), .B(G4), .Y(new_n10_));
  AO21x1_ASAP7_75t_R  g3(.A1(G3), .A2(G1), .B(new_n10_), .Y(new_n11_));
  AO21x1_ASAP7_75t_R  g4(.A1(new_n8_), .A2(G2), .B(new_n11_), .Y(G16));
  NAND2x1_ASAP7_75t_R g5(.A(G3), .B(G4), .Y(new_n13_));
  OA21x2_ASAP7_75t_R  g6(.A1(G2), .A2(G5), .B(new_n13_), .Y(G17));
endmodule


