"""Persist external proof/dependency files as verified content-addressed objects."""
import fcntl
import json
import shutil
from pathlib import Path

from archive_study import ROOT, HERE, archive, sha


def main():
    lock = (ROOT / "results_v2/independent_components_20261019/global.lock").open("a")
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    expected = {}

    def add(files):
        for path, checksum in files.items():
            assert path not in expected or expected[path] == checksum
            expected[path] = checksum

    cache = json.loads((HERE / "verification_cache.json").read_text())
    for entry in cache["entries"].values():
        add(entry["proof_files"])
    for campaign in [Path("/tmp/emapper-baseline-verification-20261019/campaign.json"),
                     Path("/tmp/emapper-proportional-full-reserved-v3-20261020/campaign.json")]:
        doc = json.loads(campaign.read_text())
        add(doc["fingerprint"])
        if "baseline-verification" in str(campaign):
            for job in doc["jobs"]:
                add(job["sha256"])
        add({str(campaign): sha(campaign)})
    subjects = ROOT / "results_v2/epfl_resyn2_subjects_20261012/report.json"
    add({str(subjects): sha(subjects)})
    # Actual prepared/original paths are recorded in audited per-case reports.
    full = json.loads(Path("/tmp/emapper-proportional-full-reserved-v3-20261020/validation.json").read_text())
    for row in full["rows"]:
        record = json.loads(Path(row["report"]).read_text())["results"][0]
        path = ROOT / "tools/mockturtle/experiments/benchmarks" / (row["bench"] + ".aig")
        add({str(path): record["input_sha256"], record["preprocessing"]["reused_from"]: record["preprocessing"]["sha256"]})
    folder = Path("/tmp/emapper-proportional-proof-dependencies-20261020")
    folder.mkdir(exist_ok=True)
    objects = folder / "objects"
    objects.mkdir(exist_ok=True)
    manifest = {}
    for path, checksum in expected.items():
        assert sha(path) == checksum, path
        target = objects / checksum
        if not target.exists():
            shutil.copyfile(path, target)
        assert sha(target) == checksum
        manifest[path] = dict(sha256=checksum, object="objects/" + checksum, bytes=target.stat().st_size)
    (folder / "paths.json").write_text(json.dumps(dict(files=manifest,
        original_files_not_modified=True, content_addressed=True,
        restore_policy="Review destination paths before restoring; never overwrite dirty sources or .git.",
        includes_original_AIGs_shared_resyn2_and_independent_CEC_artifacts=True), indent=2))
    result = archive(folder, "proportional_proof_dependencies_20261020")
    result.update(original_paths=len(manifest), distinct_objects=len(list(objects.iterdir())))
    (HERE / "proof_dependencies.json").write_text(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
