"""Read-only diagnosis of the completed sweep; never supplies mapper feedback."""
import argparse
import collections
import json
from pathlib import Path


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("campaign", type=Path)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    campaign = json.loads(args.campaign.read_text())
    assert campaign["status"] == "attempted"
    assert len(campaign["jobs"]) == campaign["expected_jobs"]
    rows = []
    for job in campaign["jobs"]:
        report = json.loads(Path(job["report"]).read_text())
        result = report["results"][0]
        native = result.get("scalability")
        item = {key: job[key] for key in ["name", "bench", "k", "ratio"]}
        item.update(status=result["status"], report=job["report"])
        if native is None:
            item.update(selected="unreturned", failure=result.get("error"))
            rows.append(item)
            continue
        attempt = native["attempts"][0]
        stage_path = Path(attempt["stdout_path"]).parent / "attempt0.stages.jsonl"
        marks = [json.loads(line) for line in stage_path.read_text().splitlines()] if stage_path.exists() else []
        elapsed = collections.defaultdict(float)
        intervals = []
        for start, end in zip(marks, marks[1:]):
            seconds = end["unix_secs"] - start["unix_secs"]
            assert seconds >= 0
            stage = start["stage"]
            if stage.startswith("cut_round_") or stage == "cuts_start":
                group = "cut_propagation"
            else:
                group = {
                    "saturation_start": "saturation",
                    "cuts_done_generate_start": "physical_generation",
                    "generate_done": "physical_alias_normalization",
                    "cone_prune_start": "cone_pruning",
                    "cone_prune_done": "retained_pool_selection",
                }.get(stage, stage)
            elapsed[group] += seconds
            intervals.append(dict(start=stage, end=end["stage"], seconds=seconds))
        measured = result.get("measured", {})
        item.update(selected=native["selected"],
                    optimized_selected_and_verified=result["status"] == "ok" and native["selected"] == "egraph_cover",
                    native_returned_cover=attempt["complete_returned_cover"],
                    native_timeout=attempt["timeout"], native_exit=attempt["exit_code"],
                    native_guard_seconds=native["optimizer_shared_window_secs"],
                    native_elapsed_including_cleanup=attempt["wall_secs"],
                    mapping_seconds=native["total_mapping_frontend_secs"],
                    imported=attempt.get("admission", {}).get("cumulative_imported_enodes") if attempt.get("admission") else None,
                    admitted=native["cumulative_accounted_enode_upper"],
                    allowance=native["global_cumulative_node_allowance"],
                    last_stage=marks[-1]["stage"] if marks else None,
                    completed_intervals=dict(elapsed), intervals=intervals,
                    last_interval_incomplete=attempt["timeout"],
                    area=measured.get("area"), delay=measured.get("delay"))
        rows.append(item)
    args.output.write_text(json.dumps(dict(
        complete=True, attempts=len(rows), rows=rows,
        last_stage_does_not_identify_every_prior_bottleneck=True,
        timeout_last_interval_not_presented_as_completed_measurement=True,
        timestamps_include_in_process_stage_overhead=True,
        independent_report_not_mapper_feedback=True), indent=2))


if __name__ == "__main__":
    main()
