"""Update the paper only after the complete, audited proportional study."""
import csv
import hashlib
import json
import math
import re
import shutil
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
PAPER = ROOT / "epmapping_paper/DAC-eGraphMap-draft"


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    qual_path = HERE / "qualification/qualification.json"
    q = json.loads(qual_path.read_text())
    assert q["complete"] and q["full_scope"] == 120
    assert q["repetitions"] == 54 and q["large_repeat_attempts"] == 18
    full_path = Path("/tmp/emapper-proportional-full-reserved-v3-20261020/validation.json")
    full = json.loads(full_path.read_text())
    ratio = q["selected_ratio"]
    points = {(r["bench"], r["k"]): r for r in full["rows"] if r["ratio"] == ratio}
    assert len(points) == 40
    count = q["summary"][ratio]
    source = PAPER / "main.tex"
    backup = HERE / "paper_before"
    backup.mkdir(exist_ok=True)
    for name in ["main.tex", "main.pdf", "all_results.csv", "table_provenance.json"]:
        destination = backup / name
        if not destination.exists():
            shutil.copy2(PAPER / name, destination)
    text = (backup / "main.tex").read_text()
    text = text.replace("The mapper omits optional\npool proxy rows while retaining exact counts and selected-binding proofs;",
                        "Full optional candidate diagnostics are disabled uniformly; exact counts,\nadmission records and recovery traces remain available;")
    supplements = json.loads(Path("/tmp/emapper-baseline-verification-20261019/campaign.json").read_text())
    selected_baseline_updates = {(j["original"]["k"], j["original"]["method"]): j
                                for j in supplements["jobs"] if j["status"] == "ok"}
    baseline_docs = {k: json.loads((HERE / f"qualification/baseline_scope/baselines_{k}in.json").read_text()) for k in [3, 4]}
    method_ids = ["abc_map_delay_resyn2", "mockturtle_emap_delay_resyn2", "eqmap_lut_amap",
                  "esyn_frozen_model_amap_bounded_dag", "emorphic_final_sa", "eGraphMap"]
    begin, end = "% BEGIN EPFL COMPLETE TABLES", "% END EPFL COMPLETE TABLES"
    left, tail = text.split(begin)
    tables, right = tail.split(end)
    all_rows = []
    inventory = None
    lines = []
    for line in tables.splitlines():
        if "EPFL 3-input" in line:
            inventory = 3
        if "EPFL 4-input" in line:
            inventory = 4
        if line.count(" & ") == 18 and line.endswith(r"\\") and not line.startswith(("Design", " &")):
            cells = line[:-2].rstrip().split(" & ")
            bench = cells[0].replace(r"\_", "_")
            if (bench, inventory) in points:
                point = points[bench, inventory]
                if point["status"] == "ok":
                    source_flag = point["selected"] == "source_witness"
                    cells[-3:] = [f"{point['area']:.2f}" + (r"$^{s}$" if source_flag else ""),
                                  f"{point['delay']:.2f}",
                                  r"$\leq$" + f"{math.ceil(point['mapping_secs'] * 100) / 100:.2f}"]
                else:
                    cells[-3:] = ["F", "F", "--"]
                if bench == "hyp":
                    for group, method in [(0, "abc_map_delay_resyn2"), (1, "mockturtle_emap_delay_resyn2")]:
                        update = selected_baseline_updates.get((inventory, method))
                        if update:
                            assert update["original"]["bench"] == bench
                            m = update["measured"]
                            assert m["cec"] == 1
                            t = update["original"]["mapping_wall_secs"]
                            cells[1+3*group:4+3*group] = [f"{m['area']:.2f}", f"{m['delay']:.2f}", f"{math.ceil(t*100)/100:.2f}"]
                for group, method in enumerate(["ABC map", "emap", "EqMap", "E-Syn", "E-morphic", "eGraphMap"]):
                    a, d, t = cells[1+3*group:4+3*group]
                    if group == 5:
                        record = dict(status=point["status"], measured=dict(area=point["area"], delay=point["delay"], cec=1 if point["status"] == "ok" else None))
                        seconds, exact_time = point["mapping_secs"], False
                    else:
                        records = [r for r in baseline_docs[inventory]["results"] if r["bench"] == bench
                                   and r["method"] == method_ids[group] and r.get("source_objective") in [None, "delay-area"]]
                        assert len(records) == 1, (bench, method, inventory)
                        record = records[0]
                        seconds = record.get("mapping_wall_secs", record.get("mapping_budget_upper_bound_secs"))
                        exact_time = record.get("mapping_time_exact", "mapping_wall_secs" in record)
                        if seconds is None and t != "--":
                            seconds, exact_time = float(t.replace(r"$\leq$", "")), False
                    measured = record.get("measured", {}) if record["status"] == "ok" else {}
                    assert (a not in ["F", "N"]) == (record["status"] == "ok")
                    if record["status"] == "ok":
                        assert abs(float(a.split("$")[0]) - measured["area"]) <= .00501
                        assert abs(float(d) - measured["delay"]) <= .00501
                    all_rows.append(dict(library_max_inputs=inventory, design=bench, method=method_ids[group],
                                         status=record["status"], area=measured.get("area"), delay=measured.get("delay"),
                                         cec=measured.get("cec"), mapping_seconds=seconds, mapping_time_exact=exact_time,
                                         method_display=method, area_display=a, delay_display=d,
                                         mapping_seconds_display=t, source_only=method == "eGraphMap" and point.get("selected") == "source_witness"))
                line = " & ".join(cells) + r" \\"
        line = line.replace(r"\fontsize{8}{9.5}", r"\fontsize{7.4}{9}")
        line = line.replace(r"\tabcolsep}{1.1pt}", r"\tabcolsep}{1.6pt}")
        line = line.replace("Fixed method configurations; F/N retain failure/node-rejection status.",
                            r"One uniform eGraphMap profile at $\rho=" + ratio + r"$; $s$ marks its basic source cover, not successful optimization. F retains failure status.")
        lines.append(line)
    assert len(all_rows) == 240
    text = left + begin + "\n".join(lines) + end + right
    abstract_start = text.index("One uniformly selected delay-area configuration")
    abstract_end = text.index(r"\end{abstract}", abstract_start)
    text = text.replace("Boolean AIG + physical cell library", "Boolean AIG + library + complete source cover")
    text = text.replace("Exact equality saturation + e-graph cuts", "Optional exact saturation + e-graph cuts")
    abstract_start = text.index("One uniformly selected delay-area configuration")
    abstract_end = text.index(r"\end{abstract}", abstract_start)
    text = text[:abstract_start] + (
        f"A complete 120-case proportional-capacity study compares three search ratios.\n"
        f"The single selected ratio produces {count['verified']} verified covers across 40 circuit/library cases,\n"
        f"of which {count['optimized_selected']} select an optimized e-graph cover and {count['source_only']} retain a basic source implementation.\n"
        "Targeted repetitions retain failures and area or timing regressions.\n"
        "The new capacity policy removes fixed-size import rejection but does not\n"
        "eliminate subsequent search timeouts or establish full-suite dominance.\n"
    ) + text[abstract_end:]
    old = "The importer hash-conses Boolean operators into the e-graph. Above a\nfixed 90\\% capacity threshold, exact XOR and three-input truth-table\noperators replace expanded cones; all operands and admitted\nhelper classes count globally (default helper quota: 2048)."
    new = "The importer hash-conses Boolean operators into the e-graph. The proportional\nprofile uniformly enables exact XOR and three-input truth-table cone\ncompression, independently of capacity. All operands and admitted helpers\ncount globally; the mandatory helper quota is 2048 and optional fill is disabled."
    assert old in text
    text = text.replace(old, new)
    start = text.index("Helpers stop at 18,000 counted nodes.")
    stop = text.index("The evaluator charges all physical instances", start)
    text = text[:start] + r"""Capacity is determined before mapping from the common input AIG:
\begin{equation}
 B=2(|P|+|\mathrm{AND}|)+2,\qquad G=B+\lceil\rho B\rceil.
 \label{eq:capacity}
\end{equation}
The three fixed ratios are $1/2$, 1 and 2. PIs, operators, helpers and
rewrite additions share the cumulative ledger; rebuild and retirement
refund nothing. Unused input reservation remains available in this ledger,
rather than constituting a separate saturation counter. This is a new
resource protocol, not an unchanged 20,000-node comparison.

A direct AND/NAND/INV source cover is constructed before optional search.
The native retained bank remains limited to 100,000 candidates; the
separately retained complete source incumbent has a conservative global
bound of $B+100{,}000$. Retained counts do not bound transient generation
memory. The other limits remain 16 cuts/class, 16 saturation iterations,
32 cut rounds and four recovery rounds of 2,000 local trials.
Synchronous dependency notifications avoid unchanged cut recomputation;
streamed physical normalization removes duplicates on emission. Root-cover
retention protects recursive dependencies of the complete output witness,
without reserving witnesses for every unselected internal signal.

The global two-second recovery window includes mandatory post-cap
availability reconstruction, index remapping and final validation. A
0.25-second return reserve and the existing 0.25 phase fraction remain
inside that window. Earlier retention ranking remains within the original
native guard, outside recovery. CBC is disabled. The search profile retains
functional cuts, phase/pin matching, SDC and fixed-bound shared-area
recovery. Final export compares complete source and optimized covers under
delay-area priority; source fallback is not counted as optimization success.

""" + text[stop:]
    start = text.index("Every tabulated numeric record passes named-port CEC")
    stop = text.index("Manifests retain", start)
    text = text[:start] + r"""Every numeric record has named-port CEC against the original AIG.
Fresh optimized outputs use independent functional Verilog cell models,
with Boolean normalization confined to verification after physical metrics
are measured. Exact source-netlist/input/library/evaluator hashes permit
reuse of an existing CEC proof; reused proofs are not fresh CEC runs.
Verification has a separate 600-second guard and never supplies candidates
or scores to the mapper. Seven of eight verification-only baseline
supplements succeed; their original mapping netlists, times, algorithms
and failed reports remain unchanged.
""" + text[stop:]
    start = text.index(r"\subsection{Coverage and standard-cell results}")
    stop = text.index(r"\subsection{Baseline adaptations}", start)
    table = r"""\begin{table}[t]\centering\footnotesize
\setlength{\tabcolsep}{3pt}
\caption{Proportional-capacity sweep, both inventories. V is verified coverage;
O selects an optimized cover; S retains the basic source cover. Geometric
area and delay ratios use the common verified scope and $\rho=1/2$ as reference.}
\label{tab:rho}\begin{tabular}{lrrrrr}\toprule
$\rho$ & V & O & S & $A/A_{1/2}$ & $D/D_{1/2}$ \\ \midrule
"""
    reference = q["summary"]["1/2"]
    for rho in ["1/2", "1", "2"]:
        x = q["summary"][rho]
        table += f"${rho}$ & {x['verified']}/40 & {x['optimized_selected']} & {x['source_only']} & {x['area_geomean']/reference['area_geomean']:.6f} & {x['delay_geomean']/reference['delay_geomean']:.6f}" + r" \\" + "\n"
    table += r"\bottomrule\end{tabular}\end{table}" + "\n"
    coverage = r"""\subsection{Coverage and standard-cell results}
All 240 original baseline groups were attempted. With seven additional
verification passes, their 520 method/status slots contain 379 CEC passes,
117 reported failures and 24 unmeasured slots. An eighth verification
supplement still times out; no mapping is rerun or baseline optimized.
Commands distinguish conversion guards, mapping timeouts, native exits
and verification failures. Attempted coverage is not valid PPA coverage.

""" + table + (
        f"All 120 proportional cases are retained in Table~\\ref{{tab:rho}}.\n"
        f"The selected global ratio is $\\rho={ratio}$, shared by both inventories\n"
        "and all 20 designs. Selection first maximizes verified coverage, then\n"
        "minimizes common-scope geometric delay, area and finally the ratio,\n"
        "using relative $10^{-6}$ ties. This is an in-suite configuration study,\n"
        "not evidence of out-of-suite generalization. Actual admissions are identical\n"
        "across ratios in all 40 cases; no node cap is exhausted. Small area\n"
        "differences do not establish a repeatable benefit from extra capacity.\n\n"
        "Tables~\\ref{tab:epfl3area} and~\\ref{tab:epfl4area} retain horizontal A/D/T\n"
        "columns for ABC map, delay-mode emap, depth-oriented EqMap, delay-oriented\n"
        "E-Syn, native final E-morphic SA and this one eGraphMap configuration.\n"
        "Only first full-sweep points enter these tables; repeated best points\n"
        "never replace them. Superscript $s$ distinguishes basic source fallback\n"
        "from successful optimization. Area-oriented baselines, staging controls\n"
        "and every failure remain in the machine-readable comparison. Full-scope\n"
        "delay-area and Pareto gates remain false.\n\n"
    )
    assert not any(g["passed"] for g in q["gates"])
    text = text[:start] + coverage + text[stop:]
    text = text.replace("Independent removals from the fixed configuration, both inventories.",
                        "Historical independent removals under the fixed 20,000-node profile, both inventories; these are not ablations of the proportional profile.")
    text = text.replace("Table~\\ref{tab:ablation} uses all 20 designs and both inventories for\neach setting.",
                        "Table~\\ref{tab:ablation} preserves the earlier 20,000-node study,\nusing all 20 designs and both inventories for each setting. Its executable\nand resource policy differ from the new proportional sweep; it does not\nisolate the effects of compaction, root retention or proportional capacity.")
    start = text.index(r"\section{Discussion and Conclusion}")
    stop = text.index(r"\clearpage", start)
    discussion = r"""\section{Discussion and Conclusion}
The capacity split distinguishes input representability from extra search
allowance. Removing fixed-size rejection permits a complete physical source
implementation, but search can still exhaust its process guard after
import. A verified fallback therefore answers a different question from
finding a better mapped network. Larger nominal capacity need not improve
delay when actual admissions are unchanged or another stage dominates.

"""
    for k in [3, 4]:
        point = points["sqrt", k]
        baseline = json.loads((HERE / f"qualification/baseline_scope/baselines_{k}in.json").read_text())
        ref = next(r for r in baseline["results"] if r["bench"] == "sqrt" and r["method"] == "mockturtle_emap_delay_resyn2")
        m = ref["measured"]
        discussion += (f"For the {k}-input inventory, sqrt has area {point['area']:.2f} and\n"
                       f"delay {point['delay']:.2f}; relative to emap, area changes by\n"
                       f"{100*(point['area']/m['area']-1):+.2f}\\% and delay by {100*(point['delay']/m['delay']-1):+.3f}\\%.\n")
    discussion += r"""These points are not replaced by better historical configurations.
The new profile is not automatically promoted to the main native default:
basic coverage, conditional delay improvement and simultaneous area-delay
dominance are separate claims.

The targeted study contains 54 fresh attempts on sqrt, sin and bar
(three ratios, two inventories, three rounds), plus 18 attempts on div,
hyp and mem\_ctrl at the one selected ratio. All ranges and failure stages
are retained. Reused source CEC proofs are identified separately from fresh
optimized-output checks. These repeats test a small scope and do not prove
machine-independent stability. The fixed-ratio full-suite observations,
not the best repetition, determine the reported comparison.

Historical component removals support phase/pin matching and shared-area
recovery within their older bounded profile. They do not prove that the
new composition preserves every old shared cover or isolates each new
scalability change. Subsequent work must reduce cut/index maintenance,
physical candidate generation and pruning costs while retaining complete
dependencies, cumulative accounting and independent equivalence checks.
Industrial multi-output mapping, richer timing models and full-suite
dominance remain unestablished.

"""
    text = text[:start] + discussion + text[stop:]
    discussion_position = text.index("The targeted study contains 54 fresh attempts")
    diagnosis = r"""Div and mem\_ctrl select optimized covers in all three repetitions in
both inventories. Hyp instead reaches the unchanged 60-second native guard
in all six repeated attempts and retains only its verified source cover.
At the selected ratio, K4 hyp stops during cut propagation; K3 reaches
pruning after approximately 25.7 seconds of saturation, 15.4 seconds of
physical generation and 9.7 seconds of alias normalization. These are
completed stage intervals, not a claim that all pruning work finished.

"""
    text = text[:discussion_position] + diagnosis + text[discussion_position:]
    historical_start = text.index(r"\subsection{Independent component removals}")
    historical_end = text.index(r"\section{Discussion and Conclusion}", historical_start)
    historical = r"""\subsection{Independent component removals}
Table~\ref{tab:ablation} preserves the older 20,000-node study over all
20 designs and both inventories. Its executable and resource policy differ
from the proportional sweep; it does not isolate compaction, root retention
or proportional capacity. The seven removals are independent.
Functional quotients are disabled in both initial cuts and exchange.
One-witness cuts restrict optional structural enumeration while preserving
mandatory source fallbacks. Input-phase removal rejects complemented
assignments but retains explicit inverters. Canonical pin assignment
restricts assignment freedom, not pin-delay lookup alone. SDC removal sets
the boundary-support allowance to zero without introducing unions.

Area-recovery removal omits post-phase required-time flow and actual-area
substitution; seed initialization remains. Incumbent removal disables the
dual-metric envelope, seed-area ceiling and bound-feasible DA cache, while
ordinary selection, cycle checks and generator proofs remain. Neither
removal changes correctness checks. All settings retain the same node,
cut, pool and total-time limits. No replacement stage is added, although
earlier completion changes the time available to later stages.

Three rounds use sqrt, sin and priority in both inventories with rotated
setting order and alternating circuit/library order. Per-case values,
failures and ranges remain archived. Paired counts require two valid
covers; coverage is separate. These targeted results do not establish
full-suite stability or additive component effects.

"""
    text = text[:historical_start] + historical + text[historical_end:]
    # Queue the historical full-width float before the remaining body so it
    # does not spill onto a dedicated seventh body page at clearpage.
    ablation_start = text.index(r"\begin{table*}", text.index(r"\subsection{Baseline adaptations}"))
    ablation_end = text.index(r"\end{table*}", ablation_start) + len(r"\end{table*}")
    ablation_float = text[ablation_start:ablation_end]
    text = text[:ablation_start] + text[ablation_end:]
    position = text.index("% END EPFL COMPLETE TABLES") + len("% END EPFL COMPLETE TABLES")
    text = text[:position] + "\n" + ablation_float + "\n" + text[position:]
    source.write_text(text)
    with (PAPER / "all_results.csv").open("w") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(all_rows[0]))
        writer.writeheader()
        writer.writerows(all_rows)
    provenance = dict(qualification=str(qual_path), qualification_sha256=sha(qual_path),
                      full_validation=str(full_path), full_validation_sha256=sha(full_path),
                      selected_ratio=ratio, no_per_case_selection=True,
                      old_table_backup=str(backup / "main.tex"), old_table_sha256=sha(backup / "main.tex"),
                      old_baseline_data_retained_except_verified_hyp_supplements=True,
                      historical_ablation_not_new_profile_ablation=True,
                      table_entries=all_rows, source_tex_sha256=sha(source))
    (PAPER / "table_provenance.json").write_text(json.dumps(provenance, indent=2))
    (HERE / "paper_data.json").write_text(json.dumps(provenance, indent=2))
    print(json.dumps(dict(selected_ratio=ratio, table_records=len(all_rows), verified=count["verified"])))


if __name__ == "__main__":
    main()
