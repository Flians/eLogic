"""Archive immutable runtime data after all timed jobs end, checking every member."""
import fcntl
import hashlib
import json
import os
import subprocess
import tarfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent


def digest(stream):
    result = hashlib.sha256()
    for chunk in iter(lambda: stream.read(1024 * 1024), b""):
        result.update(chunk)
    return result.hexdigest()


def sha(path):
    with Path(path).open("rb") as stream:
        return digest(stream)


def archive(folder, label):
    dest = ROOT / "results_v2/archives"
    dest.mkdir(exist_ok=True)
    packed, manifest, verified = [dest / (label + suffix) for suffix in [".tar.zst", ".manifest.json", ".verified.json"]]
    if verified.exists():
        old = json.loads(verified.read_text())
        assert sha(packed) == old["archive_sha256"] and sha(manifest) == old["manifest_sha256"]
        return old
    assert not packed.exists() and not manifest.exists(), "preserve interrupted archive; use a new label after audit"
    files = {}
    for path in folder.rglob("*"):
        relative = str(Path(folder.name) / path.relative_to(folder))
        if path.is_symlink():
            files[relative] = dict(kind="symlink", target=os.readlink(path))
        elif path.is_file():
            files[relative] = dict(kind="file", sha256=sha(path), bytes=path.stat().st_size)
    manifest.write_text(json.dumps(dict(folder=str(folder), files=files), indent=2))
    tar = subprocess.Popen(["tar", "-C", str(folder.parent), "-cf", "-", folder.name], stdout=subprocess.PIPE)
    zstd = subprocess.run(["zstd", "-T1", "-3", "-q", "-o", str(packed)], stdin=tar.stdout)
    tar.stdout.close()
    assert zstd.returncode == 0 and tar.wait() == 0
    dec = subprocess.Popen(["zstd", "-q", "-d", "-c", str(packed)], stdout=subprocess.PIPE)
    seen = set()
    with tarfile.open(fileobj=dec.stdout, mode="r|") as stream:
        for member in stream:
            if member.isdir():
                continue
            item = files[member.name]
            assert member.name not in seen
            seen.add(member.name)
            if member.isfile():
                assert item["kind"] == "file" and member.size == item["bytes"]
                assert digest(stream.extractfile(member)) == item["sha256"]
            else:
                assert member.issym() and item["kind"] == "symlink" and member.linkname == item["target"]
    dec.stdout.read()
    dec.stdout.close()
    assert dec.wait() == 0 and seen == set(files)
    result = dict(archive=str(packed), archive_sha256=sha(packed), manifest=str(manifest),
                  manifest_sha256=sha(manifest), original_folder=str(folder), files=len(files),
                  compressed_bytes=packed.stat().st_size, every_member_hash_verified=True,
                  failures_and_partials_preserved=True, symlinks_preserved_not_followed=True)
    verified.write_text(json.dumps(result, indent=2))
    print(json.dumps(result), flush=True)
    return result


def main():
    execution = json.loads((HERE / "execution.json").read_text())
    assert execution["status"] == "study-finished-paper-pending"
    lock = (ROOT / "results_v2/independent_components_20261019/global.lock").open("a")
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    folders = [
        ("emapper-proportional-full-reserved-v3-20261020", "proportional_full_v3_20261020"),
        ("emapper-proportional-target-repeats-v3-20261020", "proportional_small_repeats_v3_20261020"),
        ("emapper-proportional-large-repeats-v3-20261020", "proportional_large_repeats_v3_20261020"),
        ("emapper-proportional-v3-div-probe-20261020", "proportional_div_preflight_v3_20261020"),
        ("emapper-proportional-research-v3-20261020", "proportional_source_v3_20261020"),
        ("emapper-proportional-research-20261019", "proportional_source_v2_20261020"),
        ("emapper-proportional-full-v2-20261019", "proportional_partial_v2_20261020"),
        ("emapper-proportional-reserve-probe-20261019", "proportional_unqualified_probe_v2_20261020"),
        ("emapper-baseline-verification-20261019", "proportional_baseline_verification_20261020"),
        ("emapper-scaled-hyp-verification-20261019", "proportional_source_hyp_supplements_20261020"),
        ("emapper-source-constructor-20261019", "proportional_source_proof_cache_20261020"),
        ("emapper-scale-stage-probe-20261019", "proportional_stage_diagnostic_20261020"),
        ("emapper-scale-dirty-probe-20261019", "proportional_dirty_diagnostic_20261020"),
        ("emapper-scale-stream-probe-20261019", "proportional_stream_diagnostic_20261020"),
        ("emapper-scale-compact-probe-20261019", "proportional_compact_diagnostic_20261020"),
    ]
    result = []
    for name, label in folders:
        folder = Path("/tmp") / name
        assert folder.is_dir(), str(folder)
        result.append(archive(folder, label))
        (HERE / "archives.json").write_text(json.dumps(result, indent=2))
    print("Runtime archives completed; external proof artifacts still need a dependency bundle.", flush=True)


if __name__ == "__main__":
    main()
