# Three-part constrained-area experiments

Every ePMapping output satisfies its own initial area/delay bounds and passes CEC.
ABC raw area-mode outputs are preserved. The guarded comparison reverts an infeasible completed output to its native initial mapping; it is an external output-selection policy, not an internal mfs3 timing constraint. Timeouts are excluded from paired means.

{
  "whole_window_synthesis": false,
  "engine_cec_outputs": 160,
  "baseline_cec_outputs": 16,
  "main_own_area": -4.598081565401683,
  "main_own_delay": -6.41154879268278,
  "main_one_area": -3.015081954903255,
  "main_one_delay": -4.4985872878442565,
  "main_other_area": -0.9112186294787383,
  "main_other_delay": -1.915145279648734,
  "main_area_wins": 16,
  "reference_area": -6.721958901013625,
  "reference_delay": -5.857826994304032,
  "reference_wins": 14,
  "mfs_ours_area": -5.040276040098358,
  "mfs_ours_delay": -5.062489298052411,
  "abc_completed": 13,
  "abc_timeouts": 3,
  "abc_feasible": 6,
  "abc_delay_violations": 7,
  "cut_oracle_times": {
    "secs_stage1": 268.09284113900003,
    "secs_stage2": 102.782521773,
    "secs_synth": 762.244474885,
    "secs_egg": 1182.52898806,
    "secs_care": 57.630870118000004,
    "secs_window": 0.0,
    "secs_chain": 0.286522638
  },
  "abc_raw_area": -3.575691302200082,
  "abc_guarded_area": -1.5940348664441888,
  "paired_ours_area": -5.0072051936994075,
  "abc_raw_delay": 11.018744353868293,
  "abc_guarded_delay": -0.14558063949823968,
  "paired_ours_delay": -6.144396581965269,
  "paired_area_wins": 4,
  "guarded_paired_area_wins": 9,
  "ablation": {
    "full": {
      "area": 0.0,
      "worse": 0,
      "better": 0,
      "own_area": -4.598081565401683,
      "own_delay": -6.41154879268278,
      "optimizer_seconds": 2501.50442245,
      "time_ratio": 1.0
    },
    "noSYN": {
      "area": 116.77000000000024,
      "worse": 14,
      "better": 0,
      "own_area": -3.837184907250167,
      "own_delay": -5.481534964341803,
      "optimizer_seconds": 1576.8574288199998,
      "time_ratio": 0.6303636382443845
    },
    "noEGG": {
      "area": 1.840000000000483,
      "worse": 11,
      "better": 0,
      "own_area": -4.582147323605786,
      "own_delay": -6.357121810072237,
      "optimizer_seconds": 1264.529082895,
      "time_ratio": 0.5055074344647797
    },
    "noDB": {
      "area": 0.5800000000002612,
      "worse": 6,
      "better": 2,
      "own_area": -4.592480092085114,
      "own_delay": -6.325500462457368,
      "optimizer_seconds": 1982.1188015899997,
      "time_ratio": 0.792370696530167
    },
    "noCARE": {
      "area": 11.320000000000043,
      "worse": 13,
      "better": 0,
      "own_area": -4.509059186346911,
      "own_delay": -6.152472071435637,
      "optimizer_seconds": 2321.08731743,
      "time_ratio": 0.9278765596411388
    },
    "noCHAIN": {
      "area": 334.08000000000004,
      "worse": 1,
      "better": 0,
      "own_area": -0.8542674651363171,
      "own_delay": -1.7954486996706882,
      "optimizer_seconds": 2508.47244889,
      "time_ratio": 1.0027855343278487
    },
    "noSHARE": {
      "area": 334.08000000000004,
      "worse": 1,
      "better": 0,
      "own_area": -0.8542674651363171,
      "own_delay": -1.7954486996706882,
      "optimizer_seconds": 2566.6874033599997,
      "time_ratio": 1.0260575117617257
    }
  },
  "chain_activity": {
    "aes_core": {
      "chain_wins": 0,
      "secs_chain": 0.0
    },
    "arbiter": {
      "chain_wins": 384,
      "secs_chain": 0.059479863
    },
    "div": {
      "chain_wins": 0,
      "secs_chain": 0.0
    },
    "ethernet": {
      "chain_wins": 0,
      "secs_chain": 0.0
    },
    "iwls05_i2c": {
      "chain_wins": 0,
      "secs_chain": 0.0
    },
    "mem_ctrl": {
      "chain_wins": 0,
      "secs_chain": 0.229634054
    },
    "RISC": {
      "chain_wins": 0,
      "secs_chain": 0.0
    },
    "sasc": {
      "chain_wins": 0,
      "secs_chain": 0.0
    },
    "simple_spi": {
      "chain_wins": 0,
      "secs_chain": 0.0
    },
    "spi": {
      "chain_wins": 0,
      "secs_chain": 0.0
    },
    "sqrt": {
      "chain_wins": 0,
      "secs_chain": 0.0
    },
    "systemcaes": {
      "chain_wins": 0,
      "secs_chain": 0.0
    },
    "systemcdes": {
      "chain_wins": 0,
      "secs_chain": 0.0
    },
    "tv80": {
      "chain_wins": 0,
      "secs_chain": 0.0
    },
    "usb_funct": {
      "chain_wins": 0,
      "secs_chain": 0.0
    },
    "usb_phy": {
      "chain_wins": 0,
      "secs_chain": 0.0
    }
  }
}

## Per-design fully preprocessed results

| Design | A0 | D0 | A | D | dA % | dD % |
| --- | --- | --- | --- | --- | --- | --- |
| aes_core | 1029.98 | 410.72 | 1010.38 | 410.72 | -1.90 | +0.00 |
| arbiter | 557.72 | 999.87 | 223.64 | 261.39 | -59.90 | -73.86 |
| div | 1184.5 | 53105.06 | 1183.25 | 53041.21 | -0.11 | -0.12 |
| ethernet | 2541.41 | 543.88 | 2539.28 | 540.76 | -0.08 | -0.57 |
| iwls05_i2c | 47.66 | 303.61 | 47.45 | 303.61 | -0.44 | +0.00 |
| mem_ctrl | 1895.4 | 1519.75 | 1879.31 | 1486.98 | -0.85 | -2.16 |
| RISC | 2927.19 | 1453.77 | 2917.74 | 1428.82 | -0.32 | -1.72 |
| sasc | 27.28 | 191.2 | 27.17 | 191.2 | -0.40 | +0.00 |
| simple_spi | 36.96 | 308.22 | 36.79 | 291.82 | -0.46 | -5.32 |
| spi | 149.43 | 500.98 | 149.3 | 480.72 | -0.09 | -4.04 |
| sqrt | 1157.38 | 88015.07 | 1094.87 | 81535.14 | -5.40 | -7.36 |
| systemcaes | 483.75 | 709.03 | 474.07 | 682.83 | -2.00 | -3.70 |
| systemcdes | 131.06 | 488.85 | 130.64 | 487.83 | -0.32 | -0.21 |
| tv80 | 340.61 | 846.12 | 338.85 | 846.12 | -0.52 | +0.00 |
| usb_funct | 646.23 | 668.08 | 641.8 | 663.36 | -0.69 | -0.71 |
| usb_phy | 22.54 | 163.29 | 22.52 | 158.68 | -0.09 | -2.82 |
