# Frozen complete three-part campaign

This archive reruns all 16 paper circuits and all 7 ablation arms (112 ablation outputs). The integrated configuration enables two-step positive AO21 chain blocks and cross-root factor sharing, with feasible-cover filtering. The other experimental dependency, global-divisor and observability modes remain off. The four existing cut oracles remain enabled except in their respective ablations.

The original AIGs, libraries, database and ABC executable are byte-identical to the v10 archive. All initial mapped netlists also match their original cohort; the reference hashes are in manifest.json. The objective is minimum area under the fixed initial worst-output pin-delay bound. Whole-window synthesis and unmap/remap exploration are off. Both optimizers have a 1000-second post-mapping budget; AIG preprocessing, input mapping and CEC are recorded separately; the native post timer includes optimizer preparation and final rebuilding.

All 160 method outputs and 16 initial baselines pass CEC. All 112 ablations complete, and every full ablation reproduces the corresponding main QoR. Native and serialized PPA are independently checked; duplicate-output serialization buffers are recorded separately. Fresh ABC mfs3 runs complete on 13 designs; div, mem_ctrl and sqrt time out. Seven completed ABC outputs violate the native initial-delay bound, so raw and externally guarded results are both preserved. Paired means exclude timeouts.

The full six-round-cap method reduces mean own-start area by 4.60% and delay by 6.41%, with area gains on all 16 circuits. New chain gains occur on arbiter: 557.72/999.87 becomes 223.64/261.39. Disabling chain blocks or cross-root sharing restores the original arbiter result; both cumulative area penalties are 334.08 and must not be added. The other 15 full main PPA results match v10, averaging -0.91% area and -1.92% delay. Comparison against published ASPDAC final values is contextual because mapped starts differ.

Batches use up to 16 workers. Cooperative stops finished in-flight jobs and prevented duplicate launches before resumption; execution_plan.json and the ablation manifests record this history. Every admitted engine row has rc=0 and CEC=1. The final primary driver completes with all rows available.

Audit and regenerate data:

    python3 scripts/experiments/report_three_parts.py --root results_v20_three_parts_chain

Use the archived reporting implementation independently:

    PYTHONPATH=results_v20_three_parts_chain/inputs python3 results_v20_three_parts_chain/inputs/reporting/report_three_parts.py --root results_v20_three_parts_chain

Build the paper:

    make -C epmapping_paper/DATE27-ePMapping-sub all

Raw logs, netlists and environments are in tab_mfs3, tab_main and ablation. verified_metrics.json binds frozen inputs and raw results. paper_snapshot contains the exact seven-page paper and active source files.
