# V9 exact complete-score/provenance prefilter ablation

One frozen binary; only complete-score/provenance prefilter differs; certificate period1 in both. Missing/failure rows remain in full20 scope.600s mapping-related search, independentCEC excluded.

|Design|Prefilter off A/D/T|Prefilter on A/D/T|
|---|---|---|
|adder|87.10/2569.15/32.49|87.10/2569.15/32.76|
|div|9598.12/43058.72/600.00|9598.32/43058.72/600.11|
|log2|6349.19/4009.14/600.01|6324.35/3989.77/600.04|

Every eligible period1 assignment receives the same complete physical score. Only states provably nonimproving against the valid global DA incumbent AND all relevant valid pure-delay/batch seed archives skip source proof. Potential improvements still require full provenance and compact-graph validation before publication. Unreachable chosen bindings are excluded by the fused root traversal; tree costs are not used as actual area. A borrowed-pool structural score is not a source certificate. Source-provenance request counts are separate from the older generic flow-certificate-attempt trace. No speedup or main adoption follows from unit tests.

The older V2 online log2 control D3852.82 remains a separate stronger reference; this report must not hide a regression by comparing only against source fallback. V6 results, including div/hyp, are a distinct frozen version, not merged into the V9 candidate. All raw600 timeouts and predeadline receipts remain. Full20 independent factors and repeats are unfinished.
