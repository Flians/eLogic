# Paired lexicographic objectives

Both modes use the same serialized area-oriented direct mapping and 40-cell ASAP7 library. Each has one round by default. Whole-window synthesis is off. Secondary regression is permitted on primary improvement; the measured whole-network pair is guarded per round.

| Design | Initial A | Initial D | (delay, area) A | D | (area, delay) A | D |
|---|---:|---:|---:|---:|---:|---:|
| RISC | 3586.23 | 696.43 | 7197.3 | 554.21 | 3528.53 | 681.98 |
| aes_core | 1113.13 | 410.49 | 2313.2 | 353.3 | 1095.29 | 485.97 |
| arbiter | 557.72 | 999.87 | 1000.88 | 942.42 | 557.72 | 999.87 |
| div | 3609.46 | 52450.59 | 12110.76 | 46317.58 | 3525.94 | 52380.77 |
| ethernet | 3739.33 | 557.03 | 10653.98 | 471.21 | 3710.63 | 543.75 |
| iwls05_i2c | 59.39 | 237.61 | 97.13 | 195.37 | 57.74 | 240.89 |
| mem_ctrl | 2323.92 | 1726.27 | 5474.28 | 1455.9 | 2302.22 | 1712.48 |
| sasc | 35.85 | 140.61 | 91.93 | 120.35 | 35.55 | 140.61 |
| simple_spi | 49.64 | 214.5 | 112.18 | 180.54 | 49.35 | 207.94 |
| spi | 183.08 | 472.43 | 428.7 | 399.07 | 175.72 | 482.92 |
| sqrt | 1355.08 | 101970.36 | 4580.42 | 56338.33 | 1229.93 | 101879.28 |
| systemcaes | 559.33 | 775.42 | 1551.96 | 553.92 | 549.53 | 682.53 |
| systemcdes | 151.07 | 416.79 | 339.16 | 359.98 | 147.42 | 442.85 |
| tv80 | 462.39 | 799.99 | 959.03 | 669.42 | 451.5 | 808.09 |
| usb_funct | 801.3 | 421.38 | 1546.03 | 334.65 | 770.42 | 401.97 |
| usb_phy | 27.15 | 155.17 | 41.22 | 126.24 | 26.28 | 161.15 |

Complete CEC-verified pairs: 16/16.

| Objective | Mean area change (%) | Mean delay change (%) | Rolled-back rounds |
|---|---:|---:|---:|
| delay_area | +132.27 | -18.06 | 0 |
| area_delay | -2.39 | +0.50 | 0 |

Means use the identical complete design subset and average per-design percentages. Area is cell area; delay is worst output arrival. Runtime is observational. Lexicographic acceptance does not imply globally optimal search.

Failed/timeout configurations: []
