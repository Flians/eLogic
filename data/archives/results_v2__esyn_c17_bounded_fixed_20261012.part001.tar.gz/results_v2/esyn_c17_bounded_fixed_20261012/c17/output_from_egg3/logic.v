module mapped(G3,G2,G4,G5,G1,G16,G17);
input G3,G2,G4,G5,G1;
output G16,G17;
assign G16 = (~((~(G3 & G1)) & ((~G2) | (G3 & G4))));
assign G17 = ((~(G3 & G4)) & (G2 | G5));
endmodule
