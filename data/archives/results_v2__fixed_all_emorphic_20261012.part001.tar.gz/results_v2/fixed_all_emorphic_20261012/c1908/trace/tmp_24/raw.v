// Benchmark "/tmp/" written by ABC on Mon Oct 12 15:05:24 2026

module \/tmp/  ( 
    p17, p0, p3, p19, p26, p16, p15, p27, p2, p23, p25, p12, p13, p7, p8,
    p29, p5, p31, p14, p4, p11, p28, p30, p22, p24, p6, p32, p20, p1, p9,
    p10, p21, p18,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24  );
  input  p17, p0, p3, p19, p26, p16, p15, p27, p2, p23, p25, p12, p13,
    p7, p8, p29, p5, p31, p14, p4, p11, p28, p30, p22, p24, p6, p32, p20,
    p1, p9, p10, p21, p18;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24;
  wire new_n59_, new_n60_, new_n61_, new_n62_, new_n63_, new_n64_, new_n65_,
    new_n66_, new_n67_, new_n68_, new_n69_, new_n70_, new_n71_, new_n72_,
    new_n73_, new_n74_, new_n75_, new_n76_, new_n77_, new_n78_, new_n79_,
    new_n80_, new_n81_, new_n82_, new_n83_, new_n84_, new_n85_, new_n86_,
    new_n87_, new_n88_, new_n89_, new_n90_, new_n91_, new_n92_, new_n93_,
    new_n94_, new_n95_, new_n96_, new_n97_, new_n98_, new_n99_, new_n100_,
    new_n101_, new_n102_, new_n103_, new_n104_, new_n105_, new_n106_,
    new_n107_, new_n108_, new_n109_, new_n110_, new_n111_, new_n112_,
    new_n113_, new_n114_, new_n115_, new_n116_, new_n117_, new_n118_,
    new_n119_, new_n120_, new_n121_, new_n122_, new_n123_, new_n124_,
    new_n125_, new_n126_, new_n127_, new_n128_, new_n129_, new_n130_,
    new_n131_, new_n132_, new_n133_, new_n134_, new_n135_, new_n136_,
    new_n137_, new_n138_, new_n139_, new_n140_, new_n141_, new_n142_,
    new_n143_, new_n144_, new_n145_, new_n146_, new_n147_, new_n148_,
    new_n149_, new_n150_, new_n151_, new_n152_, new_n153_, new_n154_,
    new_n155_, new_n156_, new_n157_, new_n158_, new_n159_, new_n160_,
    new_n161_, new_n162_, new_n163_, new_n164_, new_n165_, new_n166_,
    new_n167_, new_n168_, new_n169_, new_n170_, new_n171_, new_n172_,
    new_n173_, new_n174_, new_n175_, new_n176_, new_n177_, new_n178_,
    new_n179_, new_n180_, new_n181_, new_n182_, new_n183_, new_n184_,
    new_n185_, new_n186_, new_n187_, new_n188_, new_n189_, new_n190_,
    new_n191_, new_n192_, new_n193_, new_n194_, new_n195_, new_n196_,
    new_n197_, new_n198_, new_n199_, new_n200_, new_n201_, new_n202_,
    new_n203_, new_n204_, new_n205_, new_n206_, new_n207_, new_n208_,
    new_n209_, new_n210_, new_n211_, new_n212_, new_n213_, new_n214_,
    new_n215_, new_n216_, new_n217_, new_n218_, new_n219_, new_n220_,
    new_n221_, new_n222_, new_n223_, new_n224_, new_n225_, new_n226_,
    new_n227_, new_n228_, new_n229_, new_n230_, new_n231_, new_n232_,
    new_n233_, new_n234_, new_n235_, new_n236_, new_n237_, new_n238_,
    new_n239_, new_n240_, new_n241_, new_n242_, new_n243_, new_n244_,
    new_n245_, new_n246_, new_n247_, new_n248_, new_n249_, new_n250_,
    new_n251_, new_n252_, new_n253_, new_n254_, new_n255_, new_n256_,
    new_n257_, new_n258_, new_n259_, new_n260_, new_n261_, new_n262_,
    new_n263_, new_n264_, new_n265_, new_n266_, new_n267_, new_n269_,
    new_n270_, new_n271_, new_n272_, new_n273_, new_n274_, new_n275_,
    new_n276_, new_n277_, new_n278_, new_n279_, new_n285_, new_n286_,
    new_n290_, new_n291_, new_n292_, new_n293_, new_n294_, new_n295_,
    new_n296_, new_n297_, new_n298_, new_n299_, new_n300_, new_n302_,
    new_n303_, new_n305_, new_n306_, new_n308_, new_n309_, new_n311_,
    new_n312_, new_n313_, new_n314_, new_n315_, new_n316_, new_n320_,
    new_n321_, new_n322_, new_n323_, new_n324_, new_n325_, new_n326_,
    new_n327_, new_n328_, new_n329_, new_n331_, new_n332_, new_n333_,
    new_n334_, new_n335_, new_n336_, new_n338_, new_n339_, new_n340_,
    new_n341_, new_n342_, new_n344_, new_n345_, new_n346_, new_n348_,
    new_n349_, new_n351_, new_n352_, new_n354_, new_n355_, new_n356_,
    new_n357_, new_n358_, new_n359_, new_n360_, new_n361_, new_n362_,
    new_n363_, new_n364_, new_n366_, new_n367_, new_n368_, new_n369_,
    new_n370_, new_n372_;
  INVx1_ASAP7_75t_R   g000(.A(p26), .Y(new_n59_));
  NOR2x1_ASAP7_75t_R  g001(.A(p0), .B(p2), .Y(new_n60_));
  NOR2x1_ASAP7_75t_R  g002(.A(new_n59_), .B(new_n60_), .Y(new_n61_));
  INVx1_ASAP7_75t_R   g003(.A(p7), .Y(new_n62_));
  NOR2x1_ASAP7_75t_R  g004(.A(p19), .B(new_n62_), .Y(new_n63_));
  INVx1_ASAP7_75t_R   g005(.A(p25), .Y(new_n64_));
  AO21x1_ASAP7_75t_R  g006(.A1(p19), .A2(new_n62_), .B(new_n64_), .Y(new_n65_));
  INVx1_ASAP7_75t_R   g007(.A(p19), .Y(new_n66_));
  NOR2x1_ASAP7_75t_R  g008(.A(p7), .B(new_n66_), .Y(new_n67_));
  OAI21x1_ASAP7_75t_R g009(.A1(new_n63_), .A2(new_n67_), .B(new_n64_), .Y(new_n68_));
  OAI21x1_ASAP7_75t_R g010(.A1(new_n63_), .A2(new_n65_), .B(new_n68_), .Y(new_n69_));
  INVx1_ASAP7_75t_R   g011(.A(p18), .Y(new_n70_));
  NOR2x1_ASAP7_75t_R  g012(.A(p21), .B(new_n70_), .Y(new_n71_));
  INVx1_ASAP7_75t_R   g013(.A(p21), .Y(new_n72_));
  NOR2x1_ASAP7_75t_R  g014(.A(p18), .B(new_n72_), .Y(new_n73_));
  OAI21x1_ASAP7_75t_R g015(.A1(new_n71_), .A2(new_n73_), .B(p6), .Y(new_n74_));
  NAND2x1_ASAP7_75t_R g016(.A(p18), .B(new_n72_), .Y(new_n75_));
  NAND2x1_ASAP7_75t_R g017(.A(p21), .B(new_n70_), .Y(new_n76_));
  INVx1_ASAP7_75t_R   g018(.A(p6), .Y(new_n77_));
  NAND3x1_ASAP7_75t_R g019(.A(new_n75_), .B(new_n76_), .C(new_n77_), .Y(new_n78_));
  NAND2x1_ASAP7_75t_R g020(.A(new_n74_), .B(new_n78_), .Y(new_n79_));
  NAND2x1_ASAP7_75t_R g021(.A(new_n69_), .B(new_n79_), .Y(new_n80_));
  XOR2x2_ASAP7_75t_R  g022(.A(p25), .B(p7), .Y(new_n81_));
  AND2x2_ASAP7_75t_R  g023(.A(p19), .B(new_n81_), .Y(new_n82_));
  NOR2x1_ASAP7_75t_R  g024(.A(p19), .B(new_n81_), .Y(new_n83_));
  NOR2x1_ASAP7_75t_R  g025(.A(p6), .B(new_n72_), .Y(new_n84_));
  AO21x1_ASAP7_75t_R  g026(.A1(p6), .A2(new_n72_), .B(new_n70_), .Y(new_n85_));
  NOR2x1_ASAP7_75t_R  g027(.A(p21), .B(new_n77_), .Y(new_n86_));
  OAI21x1_ASAP7_75t_R g028(.A1(new_n84_), .A2(new_n86_), .B(new_n70_), .Y(new_n87_));
  OAI21x1_ASAP7_75t_R g029(.A1(new_n84_), .A2(new_n85_), .B(new_n87_), .Y(new_n88_));
  OAI21x1_ASAP7_75t_R g030(.A1(new_n82_), .A2(new_n83_), .B(new_n88_), .Y(new_n89_));
  XNOR2x2_ASAP7_75t_R g031(.A(p5), .B(p22), .Y(new_n90_));
  NAND3x1_ASAP7_75t_R g032(.A(new_n80_), .B(new_n89_), .C(new_n90_), .Y(new_n91_));
  NOR2x1_ASAP7_75t_R  g033(.A(p25), .B(new_n62_), .Y(new_n92_));
  NOR2x1_ASAP7_75t_R  g034(.A(p7), .B(new_n64_), .Y(new_n93_));
  OAI21x1_ASAP7_75t_R g035(.A1(new_n92_), .A2(new_n93_), .B(p19), .Y(new_n94_));
  NAND2x1_ASAP7_75t_R g036(.A(p7), .B(new_n64_), .Y(new_n95_));
  NAND2x1_ASAP7_75t_R g037(.A(p25), .B(new_n62_), .Y(new_n96_));
  NAND3x1_ASAP7_75t_R g038(.A(new_n95_), .B(new_n96_), .C(new_n66_), .Y(new_n97_));
  NAND2x1_ASAP7_75t_R g039(.A(new_n94_), .B(new_n97_), .Y(new_n98_));
  NOR2x1_ASAP7_75t_R  g040(.A(new_n88_), .B(new_n98_), .Y(new_n99_));
  NOR2x1_ASAP7_75t_R  g041(.A(new_n69_), .B(new_n79_), .Y(new_n100_));
  INVx1_ASAP7_75t_R   g042(.A(new_n90_), .Y(new_n101_));
  OAI21x1_ASAP7_75t_R g043(.A1(new_n99_), .A2(new_n100_), .B(new_n101_), .Y(new_n102_));
  NOR2x1_ASAP7_75t_R  g044(.A(p8), .B(p9), .Y(new_n103_));
  AND2x2_ASAP7_75t_R  g045(.A(p8), .B(p9), .Y(new_n104_));
  INVx1_ASAP7_75t_R   g046(.A(p15), .Y(new_n105_));
  OAI21x1_ASAP7_75t_R g047(.A1(new_n103_), .A2(new_n104_), .B(new_n105_), .Y(new_n106_));
  OR3x1_ASAP7_75t_R   g048(.A(new_n104_), .B(new_n105_), .C(new_n103_), .Y(new_n107_));
  NAND2x1_ASAP7_75t_R g049(.A(new_n106_), .B(new_n107_), .Y(new_n108_));
  INVx1_ASAP7_75t_R   g050(.A(p1), .Y(new_n109_));
  NAND2x1_ASAP7_75t_R g051(.A(p30), .B(new_n109_), .Y(new_n110_));
  XOR2x2_ASAP7_75t_R  g052(.A(new_n110_), .B(p13), .Y(new_n111_));
  XOR2x2_ASAP7_75t_R  g053(.A(new_n108_), .B(new_n111_), .Y(new_n112_));
  AOI21x1_ASAP7_75t_R g054(.A1(new_n91_), .A2(new_n102_), .B(new_n112_), .Y(new_n113_));
  NAND3x1_ASAP7_75t_R g055(.A(new_n80_), .B(new_n89_), .C(new_n101_), .Y(new_n114_));
  OAI21x1_ASAP7_75t_R g056(.A1(new_n99_), .A2(new_n100_), .B(new_n90_), .Y(new_n115_));
  XNOR2x2_ASAP7_75t_R g057(.A(new_n111_), .B(new_n108_), .Y(new_n116_));
  AOI21x1_ASAP7_75t_R g058(.A1(new_n114_), .A2(new_n115_), .B(new_n116_), .Y(new_n117_));
  INVx1_ASAP7_75t_R   g059(.A(p2), .Y(new_n118_));
  OAI21x1_ASAP7_75t_R g060(.A1(new_n113_), .A2(new_n117_), .B(new_n118_), .Y(new_n119_));
  AND2x2_ASAP7_75t_R  g061(.A(new_n61_), .B(new_n119_), .Y(new_n120_));
  OA21x2_ASAP7_75t_R  g062(.A1(p0), .A2(p2), .B(p16), .Y(new_n121_));
  INVx1_ASAP7_75t_R   g063(.A(new_n121_), .Y(new_n122_));
  INVx1_ASAP7_75t_R   g064(.A(p0), .Y(new_n123_));
  OA21x2_ASAP7_75t_R  g065(.A1(new_n123_), .A2(new_n59_), .B(new_n118_), .Y(new_n124_));
  OAI21x1_ASAP7_75t_R g066(.A1(new_n113_), .A2(new_n117_), .B(new_n124_), .Y(new_n125_));
  INVx1_ASAP7_75t_R   g067(.A(new_n125_), .Y(new_n126_));
  OR3x1_ASAP7_75t_R   g068(.A(new_n120_), .B(new_n122_), .C(new_n126_), .Y(new_n127_));
  NAND2x1_ASAP7_75t_R g069(.A(p13), .B(p14), .Y(new_n128_));
  OR3x1_ASAP7_75t_R   g070(.A(p15), .B(p13), .C(p14), .Y(new_n129_));
  OAI21x1_ASAP7_75t_R g071(.A1(p15), .A2(new_n128_), .B(new_n129_), .Y(new_n130_));
  AND3x1_ASAP7_75t_R  g072(.A(new_n123_), .B(new_n109_), .C(p16), .Y(new_n131_));
  OAI21x1_ASAP7_75t_R g073(.A1(p13), .A2(p14), .B(p15), .Y(new_n132_));
  AND2x2_ASAP7_75t_R  g074(.A(p13), .B(p14), .Y(new_n133_));
  NOR2x1_ASAP7_75t_R  g075(.A(new_n132_), .B(new_n133_), .Y(new_n134_));
  OR3x1_ASAP7_75t_R   g076(.A(new_n130_), .B(new_n131_), .C(new_n134_), .Y(new_n135_));
  INVx1_ASAP7_75t_R   g077(.A(new_n135_), .Y(new_n136_));
  NOR2x1_ASAP7_75t_R  g078(.A(p13), .B(p14), .Y(new_n137_));
  OAI21x1_ASAP7_75t_R g079(.A1(new_n137_), .A2(new_n133_), .B(new_n105_), .Y(new_n138_));
  AO21x1_ASAP7_75t_R  g080(.A1(p13), .A2(p14), .B(new_n132_), .Y(new_n139_));
  NAND2x1_ASAP7_75t_R g081(.A(new_n138_), .B(new_n139_), .Y(new_n140_));
  AND2x2_ASAP7_75t_R  g082(.A(new_n131_), .B(new_n140_), .Y(new_n141_));
  NOR2x1_ASAP7_75t_R  g083(.A(p5), .B(p18), .Y(new_n142_));
  AND2x2_ASAP7_75t_R  g084(.A(p5), .B(p18), .Y(new_n143_));
  NOR2x1_ASAP7_75t_R  g085(.A(new_n142_), .B(new_n143_), .Y(new_n144_));
  OR3x1_ASAP7_75t_R   g086(.A(new_n143_), .B(p19), .C(new_n142_), .Y(new_n145_));
  OAI21x1_ASAP7_75t_R g087(.A1(new_n66_), .A2(new_n144_), .B(new_n145_), .Y(new_n146_));
  INVx1_ASAP7_75t_R   g088(.A(new_n146_), .Y(new_n147_));
  OAI21x1_ASAP7_75t_R g089(.A1(new_n136_), .A2(new_n141_), .B(new_n147_), .Y(new_n148_));
  OR3x1_ASAP7_75t_R   g090(.A(new_n141_), .B(new_n147_), .C(new_n136_), .Y(new_n149_));
  XOR2x2_ASAP7_75t_R  g091(.A(p17), .B(p8), .Y(new_n150_));
  INVx1_ASAP7_75t_R   g092(.A(new_n150_), .Y(new_n151_));
  AO21x1_ASAP7_75t_R  g093(.A1(new_n148_), .A2(new_n149_), .B(new_n151_), .Y(new_n152_));
  NAND2x1_ASAP7_75t_R g094(.A(new_n146_), .B(new_n135_), .Y(new_n153_));
  OAI21x1_ASAP7_75t_R g095(.A1(new_n141_), .A2(new_n153_), .B(new_n151_), .Y(new_n154_));
  OA21x2_ASAP7_75t_R  g096(.A1(new_n136_), .A2(new_n141_), .B(new_n147_), .Y(new_n155_));
  NOR2x1_ASAP7_75t_R  g097(.A(p2), .B(p20), .Y(new_n156_));
  OA21x2_ASAP7_75t_R  g098(.A1(new_n154_), .A2(new_n155_), .B(new_n156_), .Y(new_n157_));
  OR3x1_ASAP7_75t_R   g099(.A(p3), .B(p2), .C(p1), .Y(new_n158_));
  NOR2x1_ASAP7_75t_R  g100(.A(p4), .B(p1), .Y(new_n159_));
  INVx1_ASAP7_75t_R   g101(.A(new_n159_), .Y(new_n160_));
  NOR2x1_ASAP7_75t_R  g102(.A(p32), .B(new_n123_), .Y(new_n161_));
  AO21x1_ASAP7_75t_R  g103(.A1(new_n158_), .A2(new_n160_), .B(new_n161_), .Y(new_n162_));
  AOI21x1_ASAP7_75t_R g104(.A1(new_n152_), .A2(new_n157_), .B(new_n162_), .Y(new_n163_));
  AOI21x1_ASAP7_75t_R g105(.A1(new_n148_), .A2(new_n149_), .B(new_n151_), .Y(new_n164_));
  OA21x2_ASAP7_75t_R  g106(.A1(new_n141_), .A2(new_n153_), .B(new_n151_), .Y(new_n165_));
  AO21x1_ASAP7_75t_R  g107(.A1(new_n148_), .A2(new_n165_), .B(p2), .Y(new_n166_));
  OAI21x1_ASAP7_75t_R g108(.A1(new_n164_), .A2(new_n166_), .B(p20), .Y(new_n167_));
  XOR2x2_ASAP7_75t_R  g109(.A(p6), .B(p10), .Y(new_n168_));
  XOR2x2_ASAP7_75t_R  g110(.A(p7), .B(p5), .Y(new_n169_));
  XOR2x2_ASAP7_75t_R  g111(.A(new_n168_), .B(new_n169_), .Y(new_n170_));
  XOR2x2_ASAP7_75t_R  g112(.A(p8), .B(p9), .Y(new_n171_));
  NOR2x1_ASAP7_75t_R  g113(.A(p32), .B(p1), .Y(new_n172_));
  NAND2x1_ASAP7_75t_R g114(.A(p11), .B(new_n172_), .Y(new_n173_));
  XOR2x2_ASAP7_75t_R  g115(.A(new_n171_), .B(new_n173_), .Y(new_n174_));
  XOR2x2_ASAP7_75t_R  g116(.A(new_n170_), .B(new_n174_), .Y(new_n175_));
  OAI21x1_ASAP7_75t_R g117(.A1(p2), .A2(new_n175_), .B(p12), .Y(new_n176_));
  OR3x1_ASAP7_75t_R   g118(.A(new_n175_), .B(p2), .C(p12), .Y(new_n177_));
  AND2x2_ASAP7_75t_R  g119(.A(new_n176_), .B(new_n177_), .Y(new_n178_));
  NAND3x1_ASAP7_75t_R g120(.A(new_n163_), .B(new_n167_), .C(new_n178_), .Y(new_n179_));
  INVx1_ASAP7_75t_R   g121(.A(p23), .Y(new_n180_));
  NOR2x1_ASAP7_75t_R  g122(.A(p2), .B(p32), .Y(new_n181_));
  NOR2x1_ASAP7_75t_R  g123(.A(new_n180_), .B(new_n181_), .Y(new_n182_));
  INVx1_ASAP7_75t_R   g124(.A(new_n182_), .Y(new_n183_));
  NOR2x1_ASAP7_75t_R  g125(.A(p14), .B(p22), .Y(new_n184_));
  AND2x2_ASAP7_75t_R  g126(.A(p14), .B(p22), .Y(new_n185_));
  INVx1_ASAP7_75t_R   g127(.A(p28), .Y(new_n186_));
  NOR2x1_ASAP7_75t_R  g128(.A(p1), .B(new_n186_), .Y(new_n187_));
  OAI21x1_ASAP7_75t_R g129(.A1(new_n184_), .A2(new_n185_), .B(new_n187_), .Y(new_n188_));
  NAND2x1_ASAP7_75t_R g130(.A(p28), .B(new_n109_), .Y(new_n189_));
  XOR2x2_ASAP7_75t_R  g131(.A(p14), .B(p22), .Y(new_n190_));
  NAND2x1_ASAP7_75t_R g132(.A(new_n189_), .B(new_n190_), .Y(new_n191_));
  NAND2x1_ASAP7_75t_R g133(.A(new_n188_), .B(new_n191_), .Y(new_n192_));
  XOR2x2_ASAP7_75t_R  g134(.A(new_n192_), .B(new_n98_), .Y(new_n193_));
  NOR2x1_ASAP7_75t_R  g135(.A(p17), .B(p24), .Y(new_n194_));
  AND2x2_ASAP7_75t_R  g136(.A(p17), .B(p24), .Y(new_n195_));
  OAI21x1_ASAP7_75t_R g137(.A1(new_n194_), .A2(new_n195_), .B(p10), .Y(new_n196_));
  OR3x1_ASAP7_75t_R   g138(.A(new_n195_), .B(p10), .C(new_n194_), .Y(new_n197_));
  NAND2x1_ASAP7_75t_R g139(.A(new_n196_), .B(new_n197_), .Y(new_n198_));
  XNOR2x2_ASAP7_75t_R g140(.A(new_n108_), .B(new_n198_), .Y(new_n199_));
  OR3x1_ASAP7_75t_R   g141(.A(new_n193_), .B(new_n199_), .C(p2), .Y(new_n200_));
  XOR2x2_ASAP7_75t_R  g142(.A(new_n108_), .B(new_n198_), .Y(new_n201_));
  XOR2x2_ASAP7_75t_R  g143(.A(new_n192_), .B(new_n69_), .Y(new_n202_));
  NOR2x1_ASAP7_75t_R  g144(.A(new_n201_), .B(new_n202_), .Y(new_n203_));
  INVx1_ASAP7_75t_R   g145(.A(p29), .Y(new_n204_));
  AOI21x1_ASAP7_75t_R g146(.A1(new_n118_), .A2(new_n203_), .B(new_n204_), .Y(new_n205_));
  NAND2x1_ASAP7_75t_R g147(.A(new_n201_), .B(new_n202_), .Y(new_n206_));
  NAND2x1_ASAP7_75t_R g148(.A(new_n199_), .B(new_n193_), .Y(new_n207_));
  NOR2x1_ASAP7_75t_R  g149(.A(p2), .B(p29), .Y(new_n208_));
  INVx1_ASAP7_75t_R   g150(.A(new_n208_), .Y(new_n209_));
  AOI21x1_ASAP7_75t_R g151(.A1(new_n206_), .A2(new_n207_), .B(new_n209_), .Y(new_n210_));
  AOI21x1_ASAP7_75t_R g152(.A1(new_n200_), .A2(new_n205_), .B(new_n210_), .Y(new_n211_));
  NOR2x1_ASAP7_75t_R  g153(.A(p0), .B(p1), .Y(new_n212_));
  NAND3x1_ASAP7_75t_R g154(.A(new_n212_), .B(p26), .C(new_n64_), .Y(new_n213_));
  AO21x1_ASAP7_75t_R  g155(.A1(p26), .A2(new_n212_), .B(new_n64_), .Y(new_n214_));
  NAND2x1_ASAP7_75t_R g156(.A(new_n213_), .B(new_n214_), .Y(new_n215_));
  XOR2x2_ASAP7_75t_R  g157(.A(new_n88_), .B(new_n215_), .Y(new_n216_));
  NAND3x1_ASAP7_75t_R g158(.A(new_n199_), .B(new_n216_), .C(new_n118_), .Y(new_n217_));
  AO21x1_ASAP7_75t_R  g159(.A1(new_n74_), .A2(new_n78_), .B(new_n215_), .Y(new_n218_));
  NAND2x1_ASAP7_75t_R g160(.A(new_n215_), .B(new_n88_), .Y(new_n219_));
  NAND2x1_ASAP7_75t_R g161(.A(new_n218_), .B(new_n219_), .Y(new_n220_));
  NAND3x1_ASAP7_75t_R g162(.A(new_n201_), .B(new_n220_), .C(new_n118_), .Y(new_n221_));
  INVx1_ASAP7_75t_R   g163(.A(p27), .Y(new_n222_));
  NAND3x1_ASAP7_75t_R g164(.A(new_n217_), .B(new_n221_), .C(new_n222_), .Y(new_n223_));
  NOR2x1_ASAP7_75t_R  g165(.A(new_n220_), .B(new_n201_), .Y(new_n224_));
  NOR2x1_ASAP7_75t_R  g166(.A(new_n216_), .B(new_n199_), .Y(new_n225_));
  NOR2x1_ASAP7_75t_R  g167(.A(p2), .B(new_n222_), .Y(new_n226_));
  OAI21x1_ASAP7_75t_R g168(.A1(new_n224_), .A2(new_n225_), .B(new_n226_), .Y(new_n227_));
  NOR3x1_ASAP7_75t_R  g169(.A(new_n130_), .B(p22), .C(new_n134_), .Y(new_n228_));
  INVx1_ASAP7_75t_R   g170(.A(p22), .Y(new_n229_));
  AOI21x1_ASAP7_75t_R g171(.A1(new_n138_), .A2(new_n139_), .B(new_n229_), .Y(new_n230_));
  NOR2x1_ASAP7_75t_R  g172(.A(p24), .B(new_n180_), .Y(new_n231_));
  INVx1_ASAP7_75t_R   g173(.A(p24), .Y(new_n232_));
  AOI21x1_ASAP7_75t_R g174(.A1(p23), .A2(new_n172_), .B(new_n232_), .Y(new_n233_));
  AOI21x1_ASAP7_75t_R g175(.A1(new_n172_), .A2(new_n231_), .B(new_n233_), .Y(new_n234_));
  OAI21x1_ASAP7_75t_R g176(.A1(new_n228_), .A2(new_n230_), .B(new_n234_), .Y(new_n235_));
  NAND3x1_ASAP7_75t_R g177(.A(new_n139_), .B(new_n138_), .C(new_n229_), .Y(new_n236_));
  OAI21x1_ASAP7_75t_R g178(.A1(new_n134_), .A2(new_n130_), .B(p22), .Y(new_n237_));
  AO21x1_ASAP7_75t_R  g179(.A1(new_n172_), .A2(new_n231_), .B(new_n233_), .Y(new_n238_));
  NAND3x1_ASAP7_75t_R g180(.A(new_n236_), .B(new_n237_), .C(new_n238_), .Y(new_n239_));
  XNOR2x2_ASAP7_75t_R g181(.A(p9), .B(p21), .Y(new_n240_));
  NAND3x1_ASAP7_75t_R g182(.A(new_n235_), .B(new_n239_), .C(new_n240_), .Y(new_n241_));
  OA21x2_ASAP7_75t_R  g183(.A1(p2), .A2(p32), .B(p11), .Y(new_n242_));
  XOR2x2_ASAP7_75t_R  g184(.A(p22), .B(p24), .Y(new_n243_));
  INVx1_ASAP7_75t_R   g185(.A(new_n172_), .Y(new_n244_));
  OR3x1_ASAP7_75t_R   g186(.A(new_n243_), .B(new_n180_), .C(new_n244_), .Y(new_n245_));
  XNOR2x2_ASAP7_75t_R g187(.A(p22), .B(p24), .Y(new_n246_));
  AO21x1_ASAP7_75t_R  g188(.A1(p23), .A2(new_n172_), .B(new_n246_), .Y(new_n247_));
  NOR2x1_ASAP7_75t_R  g189(.A(new_n134_), .B(new_n130_), .Y(new_n248_));
  AOI21x1_ASAP7_75t_R g190(.A1(new_n245_), .A2(new_n247_), .B(new_n248_), .Y(new_n249_));
  AND3x1_ASAP7_75t_R  g191(.A(new_n246_), .B(p23), .C(new_n172_), .Y(new_n250_));
  OA21x2_ASAP7_75t_R  g192(.A1(new_n180_), .A2(new_n244_), .B(new_n243_), .Y(new_n251_));
  NOR3x1_ASAP7_75t_R  g193(.A(new_n140_), .B(new_n250_), .C(new_n251_), .Y(new_n252_));
  INVx1_ASAP7_75t_R   g194(.A(new_n240_), .Y(new_n253_));
  OAI21x1_ASAP7_75t_R g195(.A1(new_n249_), .A2(new_n252_), .B(new_n253_), .Y(new_n254_));
  NAND3x1_ASAP7_75t_R g196(.A(new_n241_), .B(new_n242_), .C(new_n254_), .Y(new_n255_));
  OAI21x1_ASAP7_75t_R g197(.A1(new_n249_), .A2(new_n252_), .B(new_n240_), .Y(new_n256_));
  NAND3x1_ASAP7_75t_R g198(.A(new_n247_), .B(new_n248_), .C(new_n245_), .Y(new_n257_));
  OAI21x1_ASAP7_75t_R g199(.A1(new_n251_), .A2(new_n250_), .B(new_n140_), .Y(new_n258_));
  NAND3x1_ASAP7_75t_R g200(.A(new_n257_), .B(new_n258_), .C(new_n253_), .Y(new_n259_));
  NOR2x1_ASAP7_75t_R  g201(.A(p2), .B(new_n242_), .Y(new_n260_));
  NAND3x1_ASAP7_75t_R g202(.A(new_n256_), .B(new_n259_), .C(new_n260_), .Y(new_n261_));
  AND2x2_ASAP7_75t_R  g203(.A(p2), .B(p11), .Y(new_n262_));
  INVx1_ASAP7_75t_R   g204(.A(new_n262_), .Y(new_n263_));
  NAND3x1_ASAP7_75t_R g205(.A(new_n255_), .B(new_n261_), .C(new_n263_), .Y(new_n264_));
  AOI21x1_ASAP7_75t_R g206(.A1(new_n223_), .A2(new_n227_), .B(new_n264_), .Y(new_n265_));
  OAI21x1_ASAP7_75t_R g207(.A1(new_n183_), .A2(new_n211_), .B(new_n265_), .Y(new_n266_));
  OR3x1_ASAP7_75t_R   g208(.A(new_n127_), .B(new_n179_), .C(new_n266_), .Y(new_n267_));
  XOR2x2_ASAP7_75t_R  g209(.A(new_n267_), .B(p14), .Y(o0));
  INVx1_ASAP7_75t_R   g210(.A(new_n211_), .Y(new_n269_));
  OR3x1_ASAP7_75t_R   g211(.A(p2), .B(p31), .C(p1), .Y(new_n270_));
  AO21x1_ASAP7_75t_R  g212(.A1(new_n270_), .A2(new_n160_), .B(new_n161_), .Y(new_n271_));
  INVx1_ASAP7_75t_R   g213(.A(new_n271_), .Y(new_n272_));
  AND3x1_ASAP7_75t_R  g214(.A(new_n177_), .B(new_n176_), .C(new_n272_), .Y(new_n273_));
  NAND2x1_ASAP7_75t_R g215(.A(new_n152_), .B(new_n157_), .Y(new_n274_));
  NAND3x1_ASAP7_75t_R g216(.A(new_n167_), .B(new_n273_), .C(new_n274_), .Y(new_n275_));
  AOI21x1_ASAP7_75t_R g217(.A1(new_n182_), .A2(new_n269_), .B(new_n275_), .Y(new_n276_));
  NAND2x1_ASAP7_75t_R g218(.A(new_n61_), .B(new_n119_), .Y(new_n277_));
  AO21x1_ASAP7_75t_R  g219(.A1(new_n125_), .A2(new_n277_), .B(new_n122_), .Y(new_n278_));
  NAND3x1_ASAP7_75t_R g220(.A(new_n276_), .B(new_n265_), .C(new_n278_), .Y(new_n279_));
  XOR2x2_ASAP7_75t_R  g221(.A(new_n279_), .B(p25), .Y(o1));
  XOR2x2_ASAP7_75t_R  g222(.A(new_n279_), .B(p19), .Y(o2));
  XOR2x2_ASAP7_75t_R  g223(.A(new_n267_), .B(p24), .Y(o3));
  XOR2x2_ASAP7_75t_R  g224(.A(new_n279_), .B(p7), .Y(o4));
  XOR2x2_ASAP7_75t_R  g225(.A(new_n279_), .B(p22), .Y(o5));
  AOI21x1_ASAP7_75t_R g226(.A1(new_n182_), .A2(new_n269_), .B(new_n179_), .Y(new_n285_));
  NAND3x1_ASAP7_75t_R g227(.A(new_n285_), .B(new_n278_), .C(new_n265_), .Y(new_n286_));
  XOR2x2_ASAP7_75t_R  g228(.A(new_n286_), .B(p9), .Y(o6));
  XOR2x2_ASAP7_75t_R  g229(.A(new_n286_), .B(p8), .Y(o7));
  XOR2x2_ASAP7_75t_R  g230(.A(new_n286_), .B(p15), .Y(o8));
  AND2x2_ASAP7_75t_R  g231(.A(new_n265_), .B(new_n278_), .Y(new_n290_));
  AND3x1_ASAP7_75t_R  g232(.A(new_n167_), .B(new_n273_), .C(new_n274_), .Y(new_n291_));
  NAND2x1_ASAP7_75t_R g233(.A(new_n182_), .B(new_n211_), .Y(new_n292_));
  INVx1_ASAP7_75t_R   g234(.A(new_n292_), .Y(new_n293_));
  NAND3x1_ASAP7_75t_R g235(.A(new_n290_), .B(new_n291_), .C(new_n293_), .Y(new_n294_));
  NAND3x1_ASAP7_75t_R g236(.A(new_n167_), .B(new_n178_), .C(new_n274_), .Y(new_n295_));
  OR3x1_ASAP7_75t_R   g237(.A(new_n295_), .B(p18), .C(new_n271_), .Y(new_n296_));
  OA21x2_ASAP7_75t_R  g238(.A1(new_n126_), .A2(new_n120_), .B(new_n121_), .Y(new_n297_));
  INVx1_ASAP7_75t_R   g239(.A(new_n265_), .Y(new_n298_));
  OR3x1_ASAP7_75t_R   g240(.A(new_n297_), .B(new_n298_), .C(new_n292_), .Y(new_n299_));
  NOR2x1_ASAP7_75t_R  g241(.A(new_n296_), .B(new_n299_), .Y(new_n300_));
  AOI21x1_ASAP7_75t_R g242(.A1(p18), .A2(new_n294_), .B(new_n300_), .Y(o9));
  NOR2x1_ASAP7_75t_R  g243(.A(p6), .B(new_n275_), .Y(new_n302_));
  AND3x1_ASAP7_75t_R  g244(.A(new_n290_), .B(new_n293_), .C(new_n302_), .Y(new_n303_));
  AOI21x1_ASAP7_75t_R g245(.A1(p6), .A2(new_n294_), .B(new_n303_), .Y(o10));
  NOR2x1_ASAP7_75t_R  g246(.A(p21), .B(new_n275_), .Y(new_n305_));
  AND3x1_ASAP7_75t_R  g247(.A(new_n290_), .B(new_n293_), .C(new_n305_), .Y(new_n306_));
  AOI21x1_ASAP7_75t_R g248(.A1(p21), .A2(new_n294_), .B(new_n306_), .Y(o11));
  OR3x1_ASAP7_75t_R   g249(.A(new_n295_), .B(p5), .C(new_n271_), .Y(new_n308_));
  NOR2x1_ASAP7_75t_R  g250(.A(new_n308_), .B(new_n299_), .Y(new_n309_));
  AOI21x1_ASAP7_75t_R g251(.A1(p5), .A2(new_n294_), .B(new_n309_), .Y(o12));
  INVx1_ASAP7_75t_R   g252(.A(new_n179_), .Y(new_n311_));
  AND3x1_ASAP7_75t_R  g253(.A(new_n290_), .B(new_n311_), .C(new_n293_), .Y(new_n312_));
  AOI21x1_ASAP7_75t_R g254(.A1(new_n158_), .A2(new_n160_), .B(new_n161_), .Y(new_n313_));
  AND3x1_ASAP7_75t_R  g255(.A(new_n274_), .B(p13), .C(new_n313_), .Y(new_n314_));
  AND3x1_ASAP7_75t_R  g256(.A(new_n314_), .B(new_n167_), .C(new_n178_), .Y(new_n315_));
  NAND3x1_ASAP7_75t_R g257(.A(new_n290_), .B(new_n293_), .C(new_n315_), .Y(new_n316_));
  OAI21x1_ASAP7_75t_R g258(.A1(p13), .A2(new_n312_), .B(new_n316_), .Y(o13));
  XOR2x2_ASAP7_75t_R  g259(.A(new_n267_), .B(p17), .Y(o14));
  XOR2x2_ASAP7_75t_R  g260(.A(new_n267_), .B(p10), .Y(o15));
  INVx1_ASAP7_75t_R   g261(.A(p4), .Y(new_n320_));
  AND2x2_ASAP7_75t_R  g262(.A(new_n162_), .B(new_n271_), .Y(new_n321_));
  AOI21x1_ASAP7_75t_R g263(.A1(new_n152_), .A2(new_n157_), .B(new_n321_), .Y(new_n322_));
  NAND3x1_ASAP7_75t_R g264(.A(new_n322_), .B(new_n167_), .C(new_n178_), .Y(new_n323_));
  AOI21x1_ASAP7_75t_R g265(.A1(new_n182_), .A2(new_n269_), .B(new_n323_), .Y(new_n324_));
  NAND3x1_ASAP7_75t_R g266(.A(new_n324_), .B(new_n265_), .C(new_n278_), .Y(new_n325_));
  OR3x1_ASAP7_75t_R   g267(.A(new_n269_), .B(new_n121_), .C(new_n182_), .Y(new_n326_));
  NAND2x1_ASAP7_75t_R g268(.A(new_n125_), .B(new_n277_), .Y(new_n327_));
  OR3x1_ASAP7_75t_R   g269(.A(new_n327_), .B(new_n298_), .C(new_n295_), .Y(new_n328_));
  OA21x2_ASAP7_75t_R  g270(.A1(new_n326_), .A2(new_n328_), .B(new_n109_), .Y(new_n329_));
  OAI21x1_ASAP7_75t_R g271(.A1(new_n320_), .A2(new_n325_), .B(new_n329_), .Y(o16));
  NOR2x1_ASAP7_75t_R  g272(.A(new_n113_), .B(new_n117_), .Y(new_n331_));
  AND3x1_ASAP7_75t_R  g273(.A(new_n118_), .B(p0), .C(p26), .Y(new_n332_));
  NOR3x1_ASAP7_75t_R  g274(.A(new_n297_), .B(new_n266_), .C(new_n323_), .Y(new_n333_));
  NAND2x1_ASAP7_75t_R g275(.A(new_n332_), .B(new_n333_), .Y(new_n334_));
  OR3x1_ASAP7_75t_R   g276(.A(new_n331_), .B(p2), .C(new_n124_), .Y(new_n335_));
  OAI21x1_ASAP7_75t_R g277(.A1(new_n335_), .A2(new_n325_), .B(new_n160_), .Y(new_n336_));
  AOI21x1_ASAP7_75t_R g278(.A1(new_n331_), .A2(new_n334_), .B(new_n336_), .Y(o17));
  NOR2x1_ASAP7_75t_R  g279(.A(p2), .B(new_n204_), .Y(new_n338_));
  NAND2x1_ASAP7_75t_R g280(.A(new_n206_), .B(new_n207_), .Y(new_n339_));
  NAND2x1_ASAP7_75t_R g281(.A(new_n338_), .B(new_n339_), .Y(new_n340_));
  OAI21x1_ASAP7_75t_R g282(.A1(new_n340_), .A2(new_n325_), .B(new_n160_), .Y(new_n341_));
  AOI21x1_ASAP7_75t_R g283(.A1(new_n338_), .A2(new_n333_), .B(new_n339_), .Y(new_n342_));
  NOR2x1_ASAP7_75t_R  g284(.A(new_n341_), .B(new_n342_), .Y(o18));
  AO21x1_ASAP7_75t_R  g285(.A1(new_n148_), .A2(new_n165_), .B(new_n164_), .Y(new_n344_));
  INVx1_ASAP7_75t_R   g286(.A(new_n344_), .Y(new_n345_));
  NAND3x1_ASAP7_75t_R g287(.A(new_n290_), .B(p20), .C(new_n324_), .Y(new_n346_));
  AOI21x1_ASAP7_75t_R g288(.A1(new_n345_), .A2(new_n346_), .B(new_n159_), .Y(o19));
  INVx1_ASAP7_75t_R   g289(.A(new_n175_), .Y(new_n348_));
  NAND3x1_ASAP7_75t_R g290(.A(new_n290_), .B(p12), .C(new_n324_), .Y(new_n349_));
  AOI21x1_ASAP7_75t_R g291(.A1(new_n348_), .A2(new_n349_), .B(new_n159_), .Y(o20));
  NAND2x1_ASAP7_75t_R g292(.A(new_n254_), .B(new_n241_), .Y(new_n351_));
  NAND3x1_ASAP7_75t_R g293(.A(new_n333_), .B(new_n118_), .C(new_n242_), .Y(new_n352_));
  AOI21x1_ASAP7_75t_R g294(.A1(new_n351_), .A2(new_n352_), .B(new_n159_), .Y(o21));
  AOI21x1_ASAP7_75t_R g295(.A1(new_n121_), .A2(new_n327_), .B(new_n266_), .Y(new_n354_));
  NOR2x1_ASAP7_75t_R  g296(.A(p31), .B(p1), .Y(new_n355_));
  AO21x1_ASAP7_75t_R  g297(.A1(new_n114_), .A2(new_n115_), .B(new_n355_), .Y(new_n356_));
  AOI21x1_ASAP7_75t_R g298(.A1(new_n291_), .A2(new_n354_), .B(new_n356_), .Y(new_n357_));
  NAND2x1_ASAP7_75t_R g299(.A(new_n109_), .B(new_n356_), .Y(new_n358_));
  AO21x1_ASAP7_75t_R  g300(.A1(p31), .A2(p30), .B(p1), .Y(new_n359_));
  INVx1_ASAP7_75t_R   g301(.A(new_n359_), .Y(new_n360_));
  OAI21x1_ASAP7_75t_R g302(.A1(new_n358_), .A2(new_n279_), .B(new_n360_), .Y(new_n361_));
  NAND2x1_ASAP7_75t_R g303(.A(new_n356_), .B(new_n291_), .Y(new_n362_));
  NOR3x1_ASAP7_75t_R  g304(.A(new_n297_), .B(new_n362_), .C(new_n266_), .Y(new_n363_));
  OAI21x1_ASAP7_75t_R g305(.A1(new_n363_), .A2(new_n357_), .B(new_n359_), .Y(new_n364_));
  OAI21x1_ASAP7_75t_R g306(.A1(new_n357_), .A2(new_n361_), .B(new_n364_), .Y(o22));
  NOR2x1_ASAP7_75t_R  g307(.A(new_n137_), .B(new_n133_), .Y(new_n366_));
  XOR2x2_ASAP7_75t_R  g308(.A(new_n201_), .B(new_n366_), .Y(new_n367_));
  NOR2x1_ASAP7_75t_R  g309(.A(p28), .B(p1), .Y(new_n368_));
  XOR2x2_ASAP7_75t_R  g310(.A(new_n367_), .B(new_n368_), .Y(new_n369_));
  OA21x2_ASAP7_75t_R  g311(.A1(p3), .A2(p1), .B(new_n369_), .Y(new_n370_));
  XOR2x2_ASAP7_75t_R  g312(.A(new_n286_), .B(new_n370_), .Y(o23));
  OAI21x1_ASAP7_75t_R g313(.A1(new_n224_), .A2(new_n225_), .B(new_n160_), .Y(new_n372_));
  AOI21x1_ASAP7_75t_R g314(.A1(new_n226_), .A2(new_n333_), .B(new_n372_), .Y(o24));
endmodule


