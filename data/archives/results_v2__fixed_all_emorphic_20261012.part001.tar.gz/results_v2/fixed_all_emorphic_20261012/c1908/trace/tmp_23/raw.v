// Benchmark "/tmp/" written by ABC on Mon Oct 12 15:05:23 2026

module \/tmp/  ( 
    p19, p20, p25, p29, p7, p11, p23, p28, p5, p30, p10, p6, p16, p13, p22,
    p12, p2, p24, p3, p0, p17, p27, p15, p18, p21, p31, p1, p26, p8, p4,
    p14, p32, p9,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24  );
  input  p19, p20, p25, p29, p7, p11, p23, p28, p5, p30, p10, p6, p16,
    p13, p22, p12, p2, p24, p3, p0, p17, p27, p15, p18, p21, p31, p1, p26,
    p8, p4, p14, p32, p9;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24;
  wire new_n59_, new_n60_, new_n61_, new_n62_, new_n63_, new_n64_, new_n65_,
    new_n66_, new_n67_, new_n68_, new_n69_, new_n70_, new_n71_, new_n72_,
    new_n73_, new_n74_, new_n75_, new_n76_, new_n77_, new_n78_, new_n79_,
    new_n80_, new_n81_, new_n82_, new_n83_, new_n84_, new_n85_, new_n86_,
    new_n87_, new_n88_, new_n89_, new_n90_, new_n91_, new_n92_, new_n93_,
    new_n94_, new_n95_, new_n96_, new_n97_, new_n98_, new_n99_, new_n100_,
    new_n101_, new_n102_, new_n103_, new_n104_, new_n105_, new_n106_,
    new_n107_, new_n108_, new_n109_, new_n110_, new_n111_, new_n112_,
    new_n113_, new_n114_, new_n115_, new_n116_, new_n117_, new_n118_,
    new_n119_, new_n120_, new_n121_, new_n122_, new_n123_, new_n124_,
    new_n125_, new_n126_, new_n127_, new_n128_, new_n129_, new_n130_,
    new_n131_, new_n132_, new_n133_, new_n134_, new_n135_, new_n136_,
    new_n137_, new_n138_, new_n139_, new_n140_, new_n141_, new_n142_,
    new_n143_, new_n144_, new_n145_, new_n146_, new_n147_, new_n148_,
    new_n149_, new_n150_, new_n151_, new_n152_, new_n153_, new_n154_,
    new_n155_, new_n156_, new_n157_, new_n158_, new_n159_, new_n160_,
    new_n161_, new_n162_, new_n163_, new_n164_, new_n165_, new_n166_,
    new_n167_, new_n168_, new_n169_, new_n170_, new_n171_, new_n172_,
    new_n173_, new_n174_, new_n175_, new_n176_, new_n177_, new_n178_,
    new_n179_, new_n180_, new_n181_, new_n182_, new_n183_, new_n184_,
    new_n185_, new_n186_, new_n187_, new_n188_, new_n189_, new_n190_,
    new_n191_, new_n192_, new_n193_, new_n194_, new_n195_, new_n196_,
    new_n197_, new_n198_, new_n199_, new_n200_, new_n201_, new_n202_,
    new_n203_, new_n204_, new_n205_, new_n206_, new_n207_, new_n208_,
    new_n209_, new_n210_, new_n211_, new_n212_, new_n213_, new_n214_,
    new_n215_, new_n216_, new_n217_, new_n218_, new_n219_, new_n220_,
    new_n221_, new_n222_, new_n223_, new_n224_, new_n225_, new_n226_,
    new_n227_, new_n228_, new_n229_, new_n230_, new_n231_, new_n232_,
    new_n233_, new_n234_, new_n235_, new_n236_, new_n237_, new_n238_,
    new_n239_, new_n240_, new_n241_, new_n242_, new_n243_, new_n244_,
    new_n245_, new_n246_, new_n247_, new_n248_, new_n249_, new_n250_,
    new_n251_, new_n252_, new_n253_, new_n254_, new_n255_, new_n256_,
    new_n257_, new_n258_, new_n259_, new_n260_, new_n261_, new_n262_,
    new_n263_, new_n264_, new_n265_, new_n267_, new_n268_, new_n269_,
    new_n270_, new_n271_, new_n272_, new_n273_, new_n274_, new_n275_,
    new_n276_, new_n277_, new_n278_, new_n279_, new_n282_, new_n286_,
    new_n287_, new_n288_, new_n292_, new_n293_, new_n294_, new_n295_,
    new_n296_, new_n297_, new_n298_, new_n299_, new_n300_, new_n301_,
    new_n303_, new_n304_, new_n306_, new_n307_, new_n309_, new_n310_,
    new_n312_, new_n313_, new_n314_, new_n315_, new_n316_, new_n318_,
    new_n319_, new_n321_, new_n322_, new_n324_, new_n325_, new_n326_,
    new_n327_, new_n328_, new_n329_, new_n330_, new_n331_, new_n333_,
    new_n334_, new_n335_, new_n336_, new_n337_, new_n339_, new_n340_,
    new_n341_, new_n342_, new_n344_, new_n346_, new_n348_, new_n349_,
    new_n351_, new_n352_, new_n353_, new_n354_, new_n355_, new_n356_,
    new_n357_, new_n358_, new_n359_, new_n360_, new_n361_, new_n363_,
    new_n364_, new_n365_, new_n366_, new_n367_, new_n369_, new_n370_;
  INVx1_ASAP7_75t_R   g000(.A(p26), .Y(new_n59_));
  NOR2x1_ASAP7_75t_R  g001(.A(p2), .B(p0), .Y(new_n60_));
  NOR2x1_ASAP7_75t_R  g002(.A(new_n59_), .B(new_n60_), .Y(new_n61_));
  INVx1_ASAP7_75t_R   g003(.A(p21), .Y(new_n62_));
  NOR2x1_ASAP7_75t_R  g004(.A(p6), .B(new_n62_), .Y(new_n63_));
  INVx1_ASAP7_75t_R   g005(.A(p18), .Y(new_n64_));
  AO21x1_ASAP7_75t_R  g006(.A1(p6), .A2(new_n62_), .B(new_n64_), .Y(new_n65_));
  INVx1_ASAP7_75t_R   g007(.A(p6), .Y(new_n66_));
  NOR2x1_ASAP7_75t_R  g008(.A(p21), .B(new_n66_), .Y(new_n67_));
  OAI21x1_ASAP7_75t_R g009(.A1(new_n63_), .A2(new_n67_), .B(new_n64_), .Y(new_n68_));
  OAI21x1_ASAP7_75t_R g010(.A1(new_n63_), .A2(new_n65_), .B(new_n68_), .Y(new_n69_));
  INVx1_ASAP7_75t_R   g011(.A(p7), .Y(new_n70_));
  NOR2x1_ASAP7_75t_R  g012(.A(p25), .B(new_n70_), .Y(new_n71_));
  INVx1_ASAP7_75t_R   g013(.A(p25), .Y(new_n72_));
  NOR2x1_ASAP7_75t_R  g014(.A(p7), .B(new_n72_), .Y(new_n73_));
  OAI21x1_ASAP7_75t_R g015(.A1(new_n71_), .A2(new_n73_), .B(p19), .Y(new_n74_));
  NAND2x1_ASAP7_75t_R g016(.A(p7), .B(new_n72_), .Y(new_n75_));
  NAND2x1_ASAP7_75t_R g017(.A(p25), .B(new_n70_), .Y(new_n76_));
  INVx1_ASAP7_75t_R   g018(.A(p19), .Y(new_n77_));
  NAND3x1_ASAP7_75t_R g019(.A(new_n75_), .B(new_n76_), .C(new_n77_), .Y(new_n78_));
  NAND2x1_ASAP7_75t_R g020(.A(new_n74_), .B(new_n78_), .Y(new_n79_));
  NAND2x1_ASAP7_75t_R g021(.A(new_n69_), .B(new_n79_), .Y(new_n80_));
  XOR2x2_ASAP7_75t_R  g022(.A(p18), .B(p21), .Y(new_n81_));
  AND2x2_ASAP7_75t_R  g023(.A(p6), .B(new_n81_), .Y(new_n82_));
  NOR2x1_ASAP7_75t_R  g024(.A(p6), .B(new_n81_), .Y(new_n83_));
  NOR2x1_ASAP7_75t_R  g025(.A(p19), .B(new_n70_), .Y(new_n84_));
  AO21x1_ASAP7_75t_R  g026(.A1(p19), .A2(new_n70_), .B(new_n72_), .Y(new_n85_));
  NOR2x1_ASAP7_75t_R  g027(.A(p7), .B(new_n77_), .Y(new_n86_));
  OAI21x1_ASAP7_75t_R g028(.A1(new_n84_), .A2(new_n86_), .B(new_n72_), .Y(new_n87_));
  OAI21x1_ASAP7_75t_R g029(.A1(new_n84_), .A2(new_n85_), .B(new_n87_), .Y(new_n88_));
  OAI21x1_ASAP7_75t_R g030(.A1(new_n82_), .A2(new_n83_), .B(new_n88_), .Y(new_n89_));
  XNOR2x2_ASAP7_75t_R g031(.A(p5), .B(p22), .Y(new_n90_));
  NAND3x1_ASAP7_75t_R g032(.A(new_n80_), .B(new_n89_), .C(new_n90_), .Y(new_n91_));
  NOR2x1_ASAP7_75t_R  g033(.A(p18), .B(new_n62_), .Y(new_n92_));
  NOR2x1_ASAP7_75t_R  g034(.A(p21), .B(new_n64_), .Y(new_n93_));
  OAI21x1_ASAP7_75t_R g035(.A1(new_n92_), .A2(new_n93_), .B(p6), .Y(new_n94_));
  NAND2x1_ASAP7_75t_R g036(.A(p21), .B(new_n64_), .Y(new_n95_));
  NAND2x1_ASAP7_75t_R g037(.A(p18), .B(new_n62_), .Y(new_n96_));
  NAND3x1_ASAP7_75t_R g038(.A(new_n95_), .B(new_n96_), .C(new_n66_), .Y(new_n97_));
  NAND2x1_ASAP7_75t_R g039(.A(new_n94_), .B(new_n97_), .Y(new_n98_));
  NOR2x1_ASAP7_75t_R  g040(.A(new_n88_), .B(new_n98_), .Y(new_n99_));
  NOR2x1_ASAP7_75t_R  g041(.A(new_n69_), .B(new_n79_), .Y(new_n100_));
  INVx1_ASAP7_75t_R   g042(.A(new_n90_), .Y(new_n101_));
  OAI21x1_ASAP7_75t_R g043(.A1(new_n99_), .A2(new_n100_), .B(new_n101_), .Y(new_n102_));
  NOR2x1_ASAP7_75t_R  g044(.A(p8), .B(p9), .Y(new_n103_));
  AND2x2_ASAP7_75t_R  g045(.A(p8), .B(p9), .Y(new_n104_));
  INVx1_ASAP7_75t_R   g046(.A(p15), .Y(new_n105_));
  OAI21x1_ASAP7_75t_R g047(.A1(new_n103_), .A2(new_n104_), .B(new_n105_), .Y(new_n106_));
  OR3x1_ASAP7_75t_R   g048(.A(new_n104_), .B(new_n105_), .C(new_n103_), .Y(new_n107_));
  NAND2x1_ASAP7_75t_R g049(.A(new_n106_), .B(new_n107_), .Y(new_n108_));
  INVx1_ASAP7_75t_R   g050(.A(p1), .Y(new_n109_));
  NAND2x1_ASAP7_75t_R g051(.A(p30), .B(new_n109_), .Y(new_n110_));
  XOR2x2_ASAP7_75t_R  g052(.A(new_n110_), .B(p13), .Y(new_n111_));
  XOR2x2_ASAP7_75t_R  g053(.A(new_n108_), .B(new_n111_), .Y(new_n112_));
  AOI21x1_ASAP7_75t_R g054(.A1(new_n91_), .A2(new_n102_), .B(new_n112_), .Y(new_n113_));
  NAND3x1_ASAP7_75t_R g055(.A(new_n80_), .B(new_n89_), .C(new_n101_), .Y(new_n114_));
  OAI21x1_ASAP7_75t_R g056(.A1(new_n99_), .A2(new_n100_), .B(new_n90_), .Y(new_n115_));
  XNOR2x2_ASAP7_75t_R g057(.A(new_n111_), .B(new_n108_), .Y(new_n116_));
  AOI21x1_ASAP7_75t_R g058(.A1(new_n114_), .A2(new_n115_), .B(new_n116_), .Y(new_n117_));
  INVx1_ASAP7_75t_R   g059(.A(p2), .Y(new_n118_));
  OAI21x1_ASAP7_75t_R g060(.A1(new_n113_), .A2(new_n117_), .B(new_n118_), .Y(new_n119_));
  NAND2x1_ASAP7_75t_R g061(.A(new_n61_), .B(new_n119_), .Y(new_n120_));
  INVx1_ASAP7_75t_R   g062(.A(p16), .Y(new_n121_));
  NOR2x1_ASAP7_75t_R  g063(.A(new_n121_), .B(new_n60_), .Y(new_n122_));
  INVx1_ASAP7_75t_R   g064(.A(p0), .Y(new_n123_));
  OA21x2_ASAP7_75t_R  g065(.A1(new_n123_), .A2(new_n59_), .B(new_n118_), .Y(new_n124_));
  OAI21x1_ASAP7_75t_R g066(.A1(new_n113_), .A2(new_n117_), .B(new_n124_), .Y(new_n125_));
  AND3x1_ASAP7_75t_R  g067(.A(new_n120_), .B(new_n122_), .C(new_n125_), .Y(new_n126_));
  INVx1_ASAP7_75t_R   g068(.A(new_n126_), .Y(new_n127_));
  NAND2x1_ASAP7_75t_R g069(.A(p5), .B(p18), .Y(new_n128_));
  INVx1_ASAP7_75t_R   g070(.A(p5), .Y(new_n129_));
  NAND2x1_ASAP7_75t_R g071(.A(new_n129_), .B(new_n64_), .Y(new_n130_));
  AO21x1_ASAP7_75t_R  g072(.A1(new_n128_), .A2(new_n130_), .B(new_n77_), .Y(new_n131_));
  NAND3x1_ASAP7_75t_R g073(.A(new_n130_), .B(new_n77_), .C(new_n128_), .Y(new_n132_));
  XNOR2x2_ASAP7_75t_R g074(.A(p17), .B(p8), .Y(new_n133_));
  AND3x1_ASAP7_75t_R  g075(.A(new_n131_), .B(new_n132_), .C(new_n133_), .Y(new_n134_));
  INVx1_ASAP7_75t_R   g076(.A(new_n133_), .Y(new_n135_));
  NAND2x1_ASAP7_75t_R g077(.A(new_n132_), .B(new_n131_), .Y(new_n136_));
  AND2x2_ASAP7_75t_R  g078(.A(new_n135_), .B(new_n136_), .Y(new_n137_));
  OAI21x1_ASAP7_75t_R g079(.A1(p13), .A2(p14), .B(p15), .Y(new_n138_));
  AND2x2_ASAP7_75t_R  g080(.A(p13), .B(p14), .Y(new_n139_));
  NOR2x1_ASAP7_75t_R  g081(.A(new_n138_), .B(new_n139_), .Y(new_n140_));
  NAND2x1_ASAP7_75t_R g082(.A(p13), .B(p14), .Y(new_n141_));
  OR3x1_ASAP7_75t_R   g083(.A(p13), .B(p15), .C(p14), .Y(new_n142_));
  OAI21x1_ASAP7_75t_R g084(.A1(p15), .A2(new_n141_), .B(new_n142_), .Y(new_n143_));
  AND3x1_ASAP7_75t_R  g085(.A(new_n123_), .B(new_n109_), .C(p16), .Y(new_n144_));
  OAI21x1_ASAP7_75t_R g086(.A1(new_n140_), .A2(new_n143_), .B(new_n144_), .Y(new_n145_));
  OR3x1_ASAP7_75t_R   g087(.A(new_n143_), .B(new_n140_), .C(new_n144_), .Y(new_n146_));
  NAND2x1_ASAP7_75t_R g088(.A(new_n145_), .B(new_n146_), .Y(new_n147_));
  OAI21x1_ASAP7_75t_R g089(.A1(new_n134_), .A2(new_n137_), .B(new_n147_), .Y(new_n148_));
  AND3x1_ASAP7_75t_R  g090(.A(new_n131_), .B(new_n132_), .C(new_n135_), .Y(new_n149_));
  AND2x2_ASAP7_75t_R  g091(.A(new_n133_), .B(new_n136_), .Y(new_n150_));
  INVx1_ASAP7_75t_R   g092(.A(new_n147_), .Y(new_n151_));
  OAI21x1_ASAP7_75t_R g093(.A1(new_n149_), .A2(new_n150_), .B(new_n151_), .Y(new_n152_));
  NAND2x1_ASAP7_75t_R g094(.A(new_n148_), .B(new_n152_), .Y(new_n153_));
  INVx1_ASAP7_75t_R   g095(.A(p20), .Y(new_n154_));
  AO21x1_ASAP7_75t_R  g096(.A1(new_n118_), .A2(new_n153_), .B(new_n154_), .Y(new_n155_));
  NOR2x1_ASAP7_75t_R  g097(.A(p1), .B(p32), .Y(new_n156_));
  NAND2x1_ASAP7_75t_R g098(.A(p11), .B(new_n156_), .Y(new_n157_));
  XOR2x2_ASAP7_75t_R  g099(.A(p8), .B(p9), .Y(new_n158_));
  XNOR2x2_ASAP7_75t_R g100(.A(new_n157_), .B(new_n158_), .Y(new_n159_));
  XOR2x2_ASAP7_75t_R  g101(.A(p10), .B(p6), .Y(new_n160_));
  XOR2x2_ASAP7_75t_R  g102(.A(p7), .B(p5), .Y(new_n161_));
  XOR2x2_ASAP7_75t_R  g103(.A(new_n160_), .B(new_n161_), .Y(new_n162_));
  XOR2x2_ASAP7_75t_R  g104(.A(new_n159_), .B(new_n162_), .Y(new_n163_));
  NAND3x1_ASAP7_75t_R g105(.A(new_n163_), .B(p12), .C(new_n118_), .Y(new_n164_));
  AO21x1_ASAP7_75t_R  g106(.A1(new_n118_), .A2(new_n163_), .B(p12), .Y(new_n165_));
  NAND2x1_ASAP7_75t_R g107(.A(new_n164_), .B(new_n165_), .Y(new_n166_));
  NOR2x1_ASAP7_75t_R  g108(.A(p20), .B(p2), .Y(new_n167_));
  OR3x1_ASAP7_75t_R   g109(.A(p2), .B(p3), .C(p1), .Y(new_n168_));
  NOR2x1_ASAP7_75t_R  g110(.A(p1), .B(p4), .Y(new_n169_));
  INVx1_ASAP7_75t_R   g111(.A(new_n169_), .Y(new_n170_));
  NOR2x1_ASAP7_75t_R  g112(.A(p32), .B(new_n123_), .Y(new_n171_));
  AO21x1_ASAP7_75t_R  g113(.A1(new_n168_), .A2(new_n170_), .B(new_n171_), .Y(new_n172_));
  AOI21x1_ASAP7_75t_R g114(.A1(new_n167_), .A2(new_n153_), .B(new_n172_), .Y(new_n173_));
  AND3x1_ASAP7_75t_R  g115(.A(new_n155_), .B(new_n166_), .C(new_n173_), .Y(new_n174_));
  INVx1_ASAP7_75t_R   g116(.A(p32), .Y(new_n175_));
  INVx1_ASAP7_75t_R   g117(.A(p23), .Y(new_n176_));
  AO21x1_ASAP7_75t_R  g118(.A1(new_n118_), .A2(new_n175_), .B(new_n176_), .Y(new_n177_));
  INVx1_ASAP7_75t_R   g119(.A(new_n177_), .Y(new_n178_));
  NOR2x1_ASAP7_75t_R  g120(.A(p22), .B(p14), .Y(new_n179_));
  AND2x2_ASAP7_75t_R  g121(.A(p22), .B(p14), .Y(new_n180_));
  INVx1_ASAP7_75t_R   g122(.A(p28), .Y(new_n181_));
  NOR2x1_ASAP7_75t_R  g123(.A(p1), .B(new_n181_), .Y(new_n182_));
  OAI21x1_ASAP7_75t_R g124(.A1(new_n179_), .A2(new_n180_), .B(new_n182_), .Y(new_n183_));
  NAND2x1_ASAP7_75t_R g125(.A(p28), .B(new_n109_), .Y(new_n184_));
  XOR2x2_ASAP7_75t_R  g126(.A(p22), .B(p14), .Y(new_n185_));
  NAND2x1_ASAP7_75t_R g127(.A(new_n184_), .B(new_n185_), .Y(new_n186_));
  NAND2x1_ASAP7_75t_R g128(.A(new_n183_), .B(new_n186_), .Y(new_n187_));
  XOR2x2_ASAP7_75t_R  g129(.A(new_n187_), .B(new_n79_), .Y(new_n188_));
  NOR2x1_ASAP7_75t_R  g130(.A(p10), .B(p24), .Y(new_n189_));
  AND2x2_ASAP7_75t_R  g131(.A(p10), .B(p24), .Y(new_n190_));
  OAI21x1_ASAP7_75t_R g132(.A1(new_n189_), .A2(new_n190_), .B(p17), .Y(new_n191_));
  OR3x1_ASAP7_75t_R   g133(.A(new_n190_), .B(p17), .C(new_n189_), .Y(new_n192_));
  NAND2x1_ASAP7_75t_R g134(.A(new_n191_), .B(new_n192_), .Y(new_n193_));
  XNOR2x2_ASAP7_75t_R g135(.A(new_n108_), .B(new_n193_), .Y(new_n194_));
  OR3x1_ASAP7_75t_R   g136(.A(new_n188_), .B(new_n194_), .C(p2), .Y(new_n195_));
  XOR2x2_ASAP7_75t_R  g137(.A(new_n108_), .B(new_n193_), .Y(new_n196_));
  XOR2x2_ASAP7_75t_R  g138(.A(new_n187_), .B(new_n88_), .Y(new_n197_));
  NOR2x1_ASAP7_75t_R  g139(.A(new_n196_), .B(new_n197_), .Y(new_n198_));
  INVx1_ASAP7_75t_R   g140(.A(p29), .Y(new_n199_));
  AOI21x1_ASAP7_75t_R g141(.A1(new_n118_), .A2(new_n198_), .B(new_n199_), .Y(new_n200_));
  NAND2x1_ASAP7_75t_R g142(.A(new_n196_), .B(new_n197_), .Y(new_n201_));
  NAND2x1_ASAP7_75t_R g143(.A(new_n194_), .B(new_n188_), .Y(new_n202_));
  NAND2x1_ASAP7_75t_R g144(.A(new_n199_), .B(new_n118_), .Y(new_n203_));
  AOI21x1_ASAP7_75t_R g145(.A1(new_n201_), .A2(new_n202_), .B(new_n203_), .Y(new_n204_));
  AO21x1_ASAP7_75t_R  g146(.A1(new_n195_), .A2(new_n200_), .B(new_n204_), .Y(new_n205_));
  NAND2x1_ASAP7_75t_R g147(.A(new_n178_), .B(new_n205_), .Y(new_n206_));
  NAND2x1_ASAP7_75t_R g148(.A(new_n174_), .B(new_n206_), .Y(new_n207_));
  NOR2x1_ASAP7_75t_R  g149(.A(p0), .B(p1), .Y(new_n208_));
  AOI21x1_ASAP7_75t_R g150(.A1(p26), .A2(new_n208_), .B(new_n72_), .Y(new_n209_));
  AND3x1_ASAP7_75t_R  g151(.A(new_n208_), .B(new_n72_), .C(p26), .Y(new_n210_));
  NOR2x1_ASAP7_75t_R  g152(.A(new_n209_), .B(new_n210_), .Y(new_n211_));
  XOR2x2_ASAP7_75t_R  g153(.A(new_n69_), .B(new_n211_), .Y(new_n212_));
  NAND2x1_ASAP7_75t_R g154(.A(new_n212_), .B(new_n194_), .Y(new_n213_));
  XOR2x2_ASAP7_75t_R  g155(.A(new_n98_), .B(new_n211_), .Y(new_n214_));
  NAND2x1_ASAP7_75t_R g156(.A(new_n196_), .B(new_n214_), .Y(new_n215_));
  INVx1_ASAP7_75t_R   g157(.A(p27), .Y(new_n216_));
  NOR2x1_ASAP7_75t_R  g158(.A(p2), .B(new_n216_), .Y(new_n217_));
  NAND3x1_ASAP7_75t_R g159(.A(new_n213_), .B(new_n215_), .C(new_n217_), .Y(new_n218_));
  NAND3x1_ASAP7_75t_R g160(.A(new_n214_), .B(new_n194_), .C(new_n118_), .Y(new_n219_));
  NAND3x1_ASAP7_75t_R g161(.A(new_n212_), .B(new_n196_), .C(new_n118_), .Y(new_n220_));
  NAND3x1_ASAP7_75t_R g162(.A(new_n219_), .B(new_n220_), .C(new_n216_), .Y(new_n221_));
  NOR3x1_ASAP7_75t_R  g163(.A(new_n143_), .B(p22), .C(new_n140_), .Y(new_n222_));
  NOR2x1_ASAP7_75t_R  g164(.A(p13), .B(p14), .Y(new_n223_));
  OAI21x1_ASAP7_75t_R g165(.A1(new_n223_), .A2(new_n139_), .B(new_n105_), .Y(new_n224_));
  AO21x1_ASAP7_75t_R  g166(.A1(p13), .A2(p14), .B(new_n138_), .Y(new_n225_));
  INVx1_ASAP7_75t_R   g167(.A(p22), .Y(new_n226_));
  AOI21x1_ASAP7_75t_R g168(.A1(new_n224_), .A2(new_n225_), .B(new_n226_), .Y(new_n227_));
  NOR2x1_ASAP7_75t_R  g169(.A(p24), .B(new_n176_), .Y(new_n228_));
  INVx1_ASAP7_75t_R   g170(.A(p24), .Y(new_n229_));
  AOI21x1_ASAP7_75t_R g171(.A1(p23), .A2(new_n156_), .B(new_n229_), .Y(new_n230_));
  AOI21x1_ASAP7_75t_R g172(.A1(new_n156_), .A2(new_n228_), .B(new_n230_), .Y(new_n231_));
  OAI21x1_ASAP7_75t_R g173(.A1(new_n222_), .A2(new_n227_), .B(new_n231_), .Y(new_n232_));
  NAND3x1_ASAP7_75t_R g174(.A(new_n225_), .B(new_n224_), .C(new_n226_), .Y(new_n233_));
  OAI21x1_ASAP7_75t_R g175(.A1(new_n140_), .A2(new_n143_), .B(p22), .Y(new_n234_));
  AO21x1_ASAP7_75t_R  g176(.A1(new_n156_), .A2(new_n228_), .B(new_n230_), .Y(new_n235_));
  NAND3x1_ASAP7_75t_R g177(.A(new_n233_), .B(new_n234_), .C(new_n235_), .Y(new_n236_));
  XNOR2x2_ASAP7_75t_R g178(.A(p21), .B(p9), .Y(new_n237_));
  NAND3x1_ASAP7_75t_R g179(.A(new_n232_), .B(new_n236_), .C(new_n237_), .Y(new_n238_));
  OA21x2_ASAP7_75t_R  g180(.A1(p2), .A2(p32), .B(p11), .Y(new_n239_));
  NOR2x1_ASAP7_75t_R  g181(.A(new_n140_), .B(new_n143_), .Y(new_n240_));
  XOR2x2_ASAP7_75t_R  g182(.A(p22), .B(p24), .Y(new_n241_));
  AO21x1_ASAP7_75t_R  g183(.A1(p23), .A2(new_n156_), .B(new_n241_), .Y(new_n242_));
  AND3x1_ASAP7_75t_R  g184(.A(new_n109_), .B(new_n175_), .C(p23), .Y(new_n243_));
  NAND2x1_ASAP7_75t_R g185(.A(new_n241_), .B(new_n243_), .Y(new_n244_));
  NAND3x1_ASAP7_75t_R g186(.A(new_n240_), .B(new_n242_), .C(new_n244_), .Y(new_n245_));
  NOR2x1_ASAP7_75t_R  g187(.A(new_n241_), .B(new_n243_), .Y(new_n246_));
  AND3x1_ASAP7_75t_R  g188(.A(new_n241_), .B(p23), .C(new_n156_), .Y(new_n247_));
  NAND2x1_ASAP7_75t_R g189(.A(new_n224_), .B(new_n225_), .Y(new_n248_));
  OAI21x1_ASAP7_75t_R g190(.A1(new_n246_), .A2(new_n247_), .B(new_n248_), .Y(new_n249_));
  INVx1_ASAP7_75t_R   g191(.A(new_n237_), .Y(new_n250_));
  NAND3x1_ASAP7_75t_R g192(.A(new_n245_), .B(new_n249_), .C(new_n250_), .Y(new_n251_));
  NAND3x1_ASAP7_75t_R g193(.A(new_n238_), .B(new_n239_), .C(new_n251_), .Y(new_n252_));
  AO21x1_ASAP7_75t_R  g194(.A1(new_n249_), .A2(new_n245_), .B(new_n237_), .Y(new_n253_));
  NAND3x1_ASAP7_75t_R g195(.A(new_n245_), .B(new_n249_), .C(new_n237_), .Y(new_n254_));
  NOR2x1_ASAP7_75t_R  g196(.A(p2), .B(new_n239_), .Y(new_n255_));
  NAND3x1_ASAP7_75t_R g197(.A(new_n253_), .B(new_n254_), .C(new_n255_), .Y(new_n256_));
  AND2x2_ASAP7_75t_R  g198(.A(p11), .B(p2), .Y(new_n257_));
  INVx1_ASAP7_75t_R   g199(.A(new_n257_), .Y(new_n258_));
  NAND3x1_ASAP7_75t_R g200(.A(new_n252_), .B(new_n256_), .C(new_n258_), .Y(new_n259_));
  AOI21x1_ASAP7_75t_R g201(.A1(new_n218_), .A2(new_n221_), .B(new_n259_), .Y(new_n260_));
  INVx1_ASAP7_75t_R   g202(.A(new_n260_), .Y(new_n261_));
  OR3x1_ASAP7_75t_R   g203(.A(new_n127_), .B(new_n207_), .C(new_n261_), .Y(new_n262_));
  AND3x1_ASAP7_75t_R  g204(.A(new_n126_), .B(new_n260_), .C(new_n206_), .Y(new_n263_));
  INVx1_ASAP7_75t_R   g205(.A(p14), .Y(new_n264_));
  AND3x1_ASAP7_75t_R  g206(.A(new_n263_), .B(new_n264_), .C(new_n174_), .Y(new_n265_));
  AOI21x1_ASAP7_75t_R g207(.A1(p14), .A2(new_n262_), .B(new_n265_), .Y(o0));
  INVx1_ASAP7_75t_R   g208(.A(new_n122_), .Y(new_n267_));
  AOI21x1_ASAP7_75t_R g209(.A1(new_n125_), .A2(new_n120_), .B(new_n267_), .Y(new_n268_));
  AOI21x1_ASAP7_75t_R g210(.A1(new_n195_), .A2(new_n200_), .B(new_n204_), .Y(new_n269_));
  OAI21x1_ASAP7_75t_R g211(.A1(new_n177_), .A2(new_n269_), .B(new_n260_), .Y(new_n270_));
  NAND2x1_ASAP7_75t_R g212(.A(new_n167_), .B(new_n153_), .Y(new_n271_));
  OR3x1_ASAP7_75t_R   g213(.A(new_n171_), .B(p1), .C(p4), .Y(new_n272_));
  NOR2x1_ASAP7_75t_R  g214(.A(p31), .B(p1), .Y(new_n273_));
  INVx1_ASAP7_75t_R   g215(.A(new_n273_), .Y(new_n274_));
  OR3x1_ASAP7_75t_R   g216(.A(new_n274_), .B(new_n171_), .C(p2), .Y(new_n275_));
  AND2x2_ASAP7_75t_R  g217(.A(new_n272_), .B(new_n275_), .Y(new_n276_));
  AOI21x1_ASAP7_75t_R g218(.A1(new_n164_), .A2(new_n165_), .B(new_n276_), .Y(new_n277_));
  NAND3x1_ASAP7_75t_R g219(.A(new_n155_), .B(new_n271_), .C(new_n277_), .Y(new_n278_));
  NOR3x1_ASAP7_75t_R  g220(.A(new_n268_), .B(new_n270_), .C(new_n278_), .Y(new_n279_));
  XOR2x2_ASAP7_75t_R  g221(.A(new_n279_), .B(new_n72_), .Y(o1));
  XOR2x2_ASAP7_75t_R  g222(.A(new_n279_), .B(new_n77_), .Y(o2));
  AND3x1_ASAP7_75t_R  g223(.A(new_n263_), .B(new_n229_), .C(new_n174_), .Y(new_n282_));
  AOI21x1_ASAP7_75t_R g224(.A1(p24), .A2(new_n262_), .B(new_n282_), .Y(o3));
  XOR2x2_ASAP7_75t_R  g225(.A(new_n279_), .B(new_n70_), .Y(o4));
  XOR2x2_ASAP7_75t_R  g226(.A(new_n279_), .B(new_n226_), .Y(o5));
  NAND2x1_ASAP7_75t_R g227(.A(new_n125_), .B(new_n120_), .Y(new_n286_));
  AOI21x1_ASAP7_75t_R g228(.A1(new_n122_), .A2(new_n286_), .B(new_n270_), .Y(new_n287_));
  NAND2x1_ASAP7_75t_R g229(.A(new_n174_), .B(new_n287_), .Y(new_n288_));
  XOR2x2_ASAP7_75t_R  g230(.A(new_n288_), .B(p9), .Y(o6));
  XOR2x2_ASAP7_75t_R  g231(.A(new_n288_), .B(p8), .Y(o7));
  XOR2x2_ASAP7_75t_R  g232(.A(new_n288_), .B(p15), .Y(o8));
  AND3x1_ASAP7_75t_R  g233(.A(new_n155_), .B(new_n166_), .C(new_n271_), .Y(new_n292_));
  INVx1_ASAP7_75t_R   g234(.A(new_n276_), .Y(new_n293_));
  AND3x1_ASAP7_75t_R  g235(.A(new_n292_), .B(new_n64_), .C(new_n293_), .Y(new_n294_));
  NOR2x1_ASAP7_75t_R  g236(.A(new_n177_), .B(new_n205_), .Y(new_n295_));
  NOR2x1_ASAP7_75t_R  g237(.A(new_n261_), .B(new_n268_), .Y(new_n296_));
  AND2x2_ASAP7_75t_R  g238(.A(new_n295_), .B(new_n296_), .Y(new_n297_));
  AOI21x1_ASAP7_75t_R g239(.A1(new_n118_), .A2(new_n153_), .B(new_n154_), .Y(new_n298_));
  AOI21x1_ASAP7_75t_R g240(.A1(new_n153_), .A2(new_n167_), .B(new_n298_), .Y(new_n299_));
  AND3x1_ASAP7_75t_R  g241(.A(new_n295_), .B(new_n299_), .C(new_n277_), .Y(new_n300_));
  AOI21x1_ASAP7_75t_R g242(.A1(new_n296_), .A2(new_n300_), .B(new_n64_), .Y(new_n301_));
  AOI21x1_ASAP7_75t_R g243(.A1(new_n294_), .A2(new_n297_), .B(new_n301_), .Y(o9));
  NOR2x1_ASAP7_75t_R  g244(.A(p6), .B(new_n278_), .Y(new_n303_));
  AOI21x1_ASAP7_75t_R g245(.A1(new_n296_), .A2(new_n300_), .B(new_n66_), .Y(new_n304_));
  AOI21x1_ASAP7_75t_R g246(.A1(new_n303_), .A2(new_n297_), .B(new_n304_), .Y(o10));
  NOR2x1_ASAP7_75t_R  g247(.A(p21), .B(new_n278_), .Y(new_n306_));
  AOI21x1_ASAP7_75t_R g248(.A1(new_n296_), .A2(new_n300_), .B(new_n62_), .Y(new_n307_));
  AOI21x1_ASAP7_75t_R g249(.A1(new_n306_), .A2(new_n297_), .B(new_n307_), .Y(o11));
  AND3x1_ASAP7_75t_R  g250(.A(new_n292_), .B(new_n129_), .C(new_n293_), .Y(new_n309_));
  AOI21x1_ASAP7_75t_R g251(.A1(new_n296_), .A2(new_n300_), .B(new_n129_), .Y(new_n310_));
  AOI21x1_ASAP7_75t_R g252(.A1(new_n309_), .A2(new_n297_), .B(new_n310_), .Y(o12));
  AND3x1_ASAP7_75t_R  g253(.A(new_n296_), .B(new_n174_), .C(new_n295_), .Y(new_n312_));
  AND2x2_ASAP7_75t_R  g254(.A(new_n164_), .B(new_n165_), .Y(new_n313_));
  NOR2x1_ASAP7_75t_R  g255(.A(new_n298_), .B(new_n313_), .Y(new_n314_));
  AND3x1_ASAP7_75t_R  g256(.A(new_n314_), .B(p13), .C(new_n173_), .Y(new_n315_));
  NAND3x1_ASAP7_75t_R g257(.A(new_n296_), .B(new_n295_), .C(new_n315_), .Y(new_n316_));
  OAI21x1_ASAP7_75t_R g258(.A1(p13), .A2(new_n312_), .B(new_n316_), .Y(o13));
  INVx1_ASAP7_75t_R   g259(.A(p17), .Y(new_n318_));
  AND3x1_ASAP7_75t_R  g260(.A(new_n263_), .B(new_n318_), .C(new_n174_), .Y(new_n319_));
  AOI21x1_ASAP7_75t_R g261(.A1(p17), .A2(new_n262_), .B(new_n319_), .Y(o14));
  INVx1_ASAP7_75t_R   g262(.A(p10), .Y(new_n321_));
  AND3x1_ASAP7_75t_R  g263(.A(new_n263_), .B(new_n321_), .C(new_n174_), .Y(new_n322_));
  AOI21x1_ASAP7_75t_R g264(.A1(p10), .A2(new_n262_), .B(new_n322_), .Y(o15));
  AND3x1_ASAP7_75t_R  g265(.A(new_n275_), .B(new_n172_), .C(new_n272_), .Y(new_n324_));
  AO21x1_ASAP7_75t_R  g266(.A1(new_n167_), .A2(new_n153_), .B(new_n324_), .Y(new_n325_));
  OR3x1_ASAP7_75t_R   g267(.A(new_n325_), .B(new_n313_), .C(new_n298_), .Y(new_n326_));
  NOR3x1_ASAP7_75t_R  g268(.A(new_n268_), .B(new_n270_), .C(new_n326_), .Y(new_n327_));
  NAND2x1_ASAP7_75t_R g269(.A(p4), .B(new_n327_), .Y(new_n328_));
  AND3x1_ASAP7_75t_R  g270(.A(new_n269_), .B(new_n267_), .C(new_n177_), .Y(new_n329_));
  NAND3x1_ASAP7_75t_R g271(.A(new_n329_), .B(new_n292_), .C(new_n260_), .Y(new_n330_));
  OA21x2_ASAP7_75t_R  g272(.A1(new_n286_), .A2(new_n330_), .B(new_n109_), .Y(new_n331_));
  NAND2x1_ASAP7_75t_R g273(.A(new_n328_), .B(new_n331_), .Y(o16));
  AND3x1_ASAP7_75t_R  g274(.A(new_n118_), .B(p0), .C(p26), .Y(new_n333_));
  NOR2x1_ASAP7_75t_R  g275(.A(new_n113_), .B(new_n117_), .Y(new_n334_));
  INVx1_ASAP7_75t_R   g276(.A(new_n334_), .Y(new_n335_));
  AO21x1_ASAP7_75t_R  g277(.A1(new_n333_), .A2(new_n327_), .B(new_n335_), .Y(new_n336_));
  NAND3x1_ASAP7_75t_R g278(.A(new_n327_), .B(new_n335_), .C(new_n333_), .Y(new_n337_));
  AND3x1_ASAP7_75t_R  g279(.A(new_n336_), .B(new_n170_), .C(new_n337_), .Y(o17));
  NOR2x1_ASAP7_75t_R  g280(.A(p2), .B(new_n199_), .Y(new_n339_));
  NAND2x1_ASAP7_75t_R g281(.A(new_n201_), .B(new_n202_), .Y(new_n340_));
  AO21x1_ASAP7_75t_R  g282(.A1(new_n339_), .A2(new_n327_), .B(new_n340_), .Y(new_n341_));
  NAND3x1_ASAP7_75t_R g283(.A(new_n327_), .B(new_n340_), .C(new_n339_), .Y(new_n342_));
  AND3x1_ASAP7_75t_R  g284(.A(new_n341_), .B(new_n170_), .C(new_n342_), .Y(o18));
  NAND2x1_ASAP7_75t_R g285(.A(p20), .B(new_n327_), .Y(new_n344_));
  AOI21x1_ASAP7_75t_R g286(.A1(new_n153_), .A2(new_n344_), .B(new_n169_), .Y(o19));
  NAND2x1_ASAP7_75t_R g287(.A(p12), .B(new_n327_), .Y(new_n346_));
  AOI21x1_ASAP7_75t_R g288(.A1(new_n163_), .A2(new_n346_), .B(new_n169_), .Y(o20));
  NAND2x1_ASAP7_75t_R g289(.A(new_n254_), .B(new_n253_), .Y(new_n348_));
  AO21x1_ASAP7_75t_R  g290(.A1(new_n239_), .A2(new_n327_), .B(new_n348_), .Y(new_n349_));
  AND2x2_ASAP7_75t_R  g291(.A(new_n170_), .B(new_n349_), .Y(o21));
  AO21x1_ASAP7_75t_R  g292(.A1(p30), .A2(p31), .B(p1), .Y(new_n351_));
  INVx1_ASAP7_75t_R   g293(.A(new_n351_), .Y(new_n352_));
  OR3x1_ASAP7_75t_R   g294(.A(new_n268_), .B(new_n270_), .C(new_n278_), .Y(new_n353_));
  AND3x1_ASAP7_75t_R  g295(.A(new_n102_), .B(new_n91_), .C(new_n274_), .Y(new_n354_));
  INVx1_ASAP7_75t_R   g296(.A(new_n354_), .Y(new_n355_));
  NAND3x1_ASAP7_75t_R g297(.A(new_n299_), .B(new_n277_), .C(new_n355_), .Y(new_n356_));
  NOR3x1_ASAP7_75t_R  g298(.A(new_n356_), .B(new_n270_), .C(new_n268_), .Y(new_n357_));
  AOI21x1_ASAP7_75t_R g299(.A1(new_n353_), .A2(new_n354_), .B(new_n357_), .Y(new_n358_));
  NOR2x1_ASAP7_75t_R  g300(.A(new_n354_), .B(new_n278_), .Y(new_n359_));
  AOI21x1_ASAP7_75t_R g301(.A1(new_n359_), .A2(new_n287_), .B(new_n351_), .Y(new_n360_));
  OAI21x1_ASAP7_75t_R g302(.A1(new_n279_), .A2(new_n355_), .B(new_n360_), .Y(new_n361_));
  OAI21x1_ASAP7_75t_R g303(.A1(new_n352_), .A2(new_n358_), .B(new_n361_), .Y(o22));
  NOR2x1_ASAP7_75t_R  g304(.A(new_n223_), .B(new_n139_), .Y(new_n363_));
  XOR2x2_ASAP7_75t_R  g305(.A(new_n196_), .B(new_n363_), .Y(new_n364_));
  NOR2x1_ASAP7_75t_R  g306(.A(p28), .B(p1), .Y(new_n365_));
  XOR2x2_ASAP7_75t_R  g307(.A(new_n364_), .B(new_n365_), .Y(new_n366_));
  OA21x2_ASAP7_75t_R  g308(.A1(p3), .A2(p1), .B(new_n366_), .Y(new_n367_));
  XOR2x2_ASAP7_75t_R  g309(.A(new_n288_), .B(new_n367_), .Y(o23));
  AND3x1_ASAP7_75t_R  g310(.A(new_n213_), .B(new_n215_), .C(new_n170_), .Y(new_n369_));
  NAND2x1_ASAP7_75t_R g311(.A(new_n217_), .B(new_n327_), .Y(new_n370_));
  AND2x2_ASAP7_75t_R  g312(.A(new_n369_), .B(new_n370_), .Y(o24));
endmodule


