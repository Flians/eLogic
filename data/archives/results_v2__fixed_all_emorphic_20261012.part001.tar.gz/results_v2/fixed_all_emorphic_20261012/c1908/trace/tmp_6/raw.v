// Benchmark "/tmp/" written by ABC on Mon Oct 12 15:05:18 2026

module \/tmp/  ( 
    p19, p13, p0, p9, p32, p10, p17, p25, p26, p5, p11, p20, p28, p21, p1,
    p7, p31, p2, p23, p15, p18, p6, p22, p4, p30, p24, p29, p14, p16, p12,
    p3, p27, p8,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24  );
  input  p19, p13, p0, p9, p32, p10, p17, p25, p26, p5, p11, p20, p28,
    p21, p1, p7, p31, p2, p23, p15, p18, p6, p22, p4, p30, p24, p29, p14,
    p16, p12, p3, p27, p8;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24;
  wire new_n59_, new_n60_, new_n61_, new_n62_, new_n63_, new_n64_, new_n65_,
    new_n66_, new_n67_, new_n68_, new_n69_, new_n70_, new_n71_, new_n72_,
    new_n73_, new_n74_, new_n75_, new_n76_, new_n77_, new_n78_, new_n79_,
    new_n80_, new_n81_, new_n82_, new_n83_, new_n84_, new_n85_, new_n86_,
    new_n87_, new_n88_, new_n89_, new_n90_, new_n91_, new_n92_, new_n93_,
    new_n94_, new_n95_, new_n96_, new_n97_, new_n98_, new_n99_, new_n100_,
    new_n101_, new_n102_, new_n103_, new_n104_, new_n105_, new_n106_,
    new_n107_, new_n108_, new_n109_, new_n110_, new_n111_, new_n112_,
    new_n113_, new_n114_, new_n115_, new_n116_, new_n117_, new_n118_,
    new_n119_, new_n120_, new_n121_, new_n122_, new_n123_, new_n124_,
    new_n125_, new_n126_, new_n127_, new_n128_, new_n129_, new_n130_,
    new_n131_, new_n132_, new_n133_, new_n134_, new_n135_, new_n136_,
    new_n137_, new_n138_, new_n139_, new_n140_, new_n141_, new_n142_,
    new_n143_, new_n144_, new_n145_, new_n146_, new_n147_, new_n148_,
    new_n149_, new_n150_, new_n151_, new_n152_, new_n153_, new_n154_,
    new_n155_, new_n156_, new_n157_, new_n158_, new_n159_, new_n160_,
    new_n161_, new_n162_, new_n163_, new_n164_, new_n165_, new_n166_,
    new_n167_, new_n168_, new_n169_, new_n170_, new_n171_, new_n172_,
    new_n173_, new_n174_, new_n175_, new_n176_, new_n177_, new_n178_,
    new_n179_, new_n180_, new_n181_, new_n182_, new_n183_, new_n184_,
    new_n185_, new_n186_, new_n187_, new_n188_, new_n189_, new_n190_,
    new_n191_, new_n192_, new_n193_, new_n194_, new_n195_, new_n196_,
    new_n197_, new_n198_, new_n199_, new_n200_, new_n201_, new_n202_,
    new_n203_, new_n204_, new_n205_, new_n206_, new_n207_, new_n208_,
    new_n209_, new_n210_, new_n211_, new_n212_, new_n213_, new_n214_,
    new_n215_, new_n216_, new_n217_, new_n218_, new_n219_, new_n220_,
    new_n221_, new_n222_, new_n223_, new_n224_, new_n225_, new_n226_,
    new_n227_, new_n228_, new_n229_, new_n230_, new_n231_, new_n232_,
    new_n233_, new_n234_, new_n235_, new_n236_, new_n237_, new_n238_,
    new_n239_, new_n240_, new_n241_, new_n242_, new_n243_, new_n244_,
    new_n245_, new_n246_, new_n247_, new_n248_, new_n249_, new_n250_,
    new_n251_, new_n252_, new_n253_, new_n254_, new_n255_, new_n256_,
    new_n257_, new_n258_, new_n259_, new_n260_, new_n261_, new_n263_,
    new_n264_, new_n265_, new_n266_, new_n267_, new_n268_, new_n269_,
    new_n270_, new_n271_, new_n272_, new_n273_, new_n274_, new_n280_,
    new_n281_, new_n282_, new_n286_, new_n287_, new_n288_, new_n289_,
    new_n290_, new_n295_, new_n299_, new_n300_, new_n301_, new_n302_,
    new_n303_, new_n304_, new_n305_, new_n306_, new_n307_, new_n308_,
    new_n310_, new_n311_, new_n312_, new_n313_, new_n314_, new_n316_,
    new_n317_, new_n318_, new_n319_, new_n320_, new_n321_, new_n323_,
    new_n324_, new_n326_, new_n328_, new_n329_, new_n331_, new_n332_,
    new_n333_, new_n334_, new_n335_, new_n336_, new_n337_, new_n338_,
    new_n339_, new_n340_, new_n342_, new_n343_, new_n344_, new_n345_,
    new_n346_, new_n347_, new_n348_, new_n349_, new_n350_, new_n351_,
    new_n352_, new_n353_, new_n354_, new_n356_;
  XOR2x2_ASAP7_75t_R  g000(.A(p18), .B(p6), .Y(new_n59_));
  AND2x2_ASAP7_75t_R  g001(.A(p21), .B(new_n59_), .Y(new_n60_));
  NOR2x1_ASAP7_75t_R  g002(.A(p21), .B(new_n59_), .Y(new_n61_));
  XNOR2x2_ASAP7_75t_R g003(.A(p19), .B(p7), .Y(new_n62_));
  INVx1_ASAP7_75t_R   g004(.A(p7), .Y(new_n63_));
  NAND2x1_ASAP7_75t_R g005(.A(p19), .B(new_n63_), .Y(new_n64_));
  INVx1_ASAP7_75t_R   g006(.A(p19), .Y(new_n65_));
  INVx1_ASAP7_75t_R   g007(.A(p25), .Y(new_n66_));
  AOI21x1_ASAP7_75t_R g008(.A1(p7), .A2(new_n65_), .B(new_n66_), .Y(new_n67_));
  NAND2x1_ASAP7_75t_R g009(.A(new_n64_), .B(new_n67_), .Y(new_n68_));
  OAI21x1_ASAP7_75t_R g010(.A1(p25), .A2(new_n62_), .B(new_n68_), .Y(new_n69_));
  OAI21x1_ASAP7_75t_R g011(.A1(new_n60_), .A2(new_n61_), .B(new_n69_), .Y(new_n70_));
  XOR2x2_ASAP7_75t_R  g012(.A(p25), .B(p7), .Y(new_n71_));
  AND2x2_ASAP7_75t_R  g013(.A(p19), .B(new_n71_), .Y(new_n72_));
  NOR2x1_ASAP7_75t_R  g014(.A(p19), .B(new_n71_), .Y(new_n73_));
  XNOR2x2_ASAP7_75t_R g015(.A(p21), .B(p6), .Y(new_n74_));
  INVx1_ASAP7_75t_R   g016(.A(p6), .Y(new_n75_));
  NAND2x1_ASAP7_75t_R g017(.A(p21), .B(new_n75_), .Y(new_n76_));
  INVx1_ASAP7_75t_R   g018(.A(p21), .Y(new_n77_));
  INVx1_ASAP7_75t_R   g019(.A(p18), .Y(new_n78_));
  AOI21x1_ASAP7_75t_R g020(.A1(p6), .A2(new_n77_), .B(new_n78_), .Y(new_n79_));
  NAND2x1_ASAP7_75t_R g021(.A(new_n76_), .B(new_n79_), .Y(new_n80_));
  OAI21x1_ASAP7_75t_R g022(.A1(p18), .A2(new_n74_), .B(new_n80_), .Y(new_n81_));
  OAI21x1_ASAP7_75t_R g023(.A1(new_n72_), .A2(new_n73_), .B(new_n81_), .Y(new_n82_));
  XOR2x2_ASAP7_75t_R  g024(.A(p5), .B(p22), .Y(new_n83_));
  INVx1_ASAP7_75t_R   g025(.A(new_n83_), .Y(new_n84_));
  AO21x1_ASAP7_75t_R  g026(.A1(new_n70_), .A2(new_n82_), .B(new_n84_), .Y(new_n85_));
  NAND2x1_ASAP7_75t_R g027(.A(p6), .B(new_n77_), .Y(new_n86_));
  AND3x1_ASAP7_75t_R  g028(.A(new_n76_), .B(new_n86_), .C(p18), .Y(new_n87_));
  NOR2x1_ASAP7_75t_R  g029(.A(p18), .B(new_n74_), .Y(new_n88_));
  NOR2x1_ASAP7_75t_R  g030(.A(new_n87_), .B(new_n88_), .Y(new_n89_));
  AOI21x1_ASAP7_75t_R g031(.A1(new_n69_), .A2(new_n89_), .B(new_n83_), .Y(new_n90_));
  NOR2x1_ASAP7_75t_R  g032(.A(p9), .B(p8), .Y(new_n91_));
  AND2x2_ASAP7_75t_R  g033(.A(p9), .B(p8), .Y(new_n92_));
  INVx1_ASAP7_75t_R   g034(.A(p15), .Y(new_n93_));
  OAI21x1_ASAP7_75t_R g035(.A1(new_n91_), .A2(new_n92_), .B(new_n93_), .Y(new_n94_));
  OR3x1_ASAP7_75t_R   g036(.A(new_n92_), .B(new_n93_), .C(new_n91_), .Y(new_n95_));
  NAND2x1_ASAP7_75t_R g037(.A(new_n94_), .B(new_n95_), .Y(new_n96_));
  INVx1_ASAP7_75t_R   g038(.A(p1), .Y(new_n97_));
  NAND2x1_ASAP7_75t_R g039(.A(p30), .B(new_n97_), .Y(new_n98_));
  XOR2x2_ASAP7_75t_R  g040(.A(new_n98_), .B(p13), .Y(new_n99_));
  XOR2x2_ASAP7_75t_R  g041(.A(new_n96_), .B(new_n99_), .Y(new_n100_));
  AOI21x1_ASAP7_75t_R g042(.A1(new_n82_), .A2(new_n90_), .B(new_n100_), .Y(new_n101_));
  AND2x2_ASAP7_75t_R  g043(.A(new_n85_), .B(new_n101_), .Y(new_n102_));
  INVx1_ASAP7_75t_R   g044(.A(p2), .Y(new_n103_));
  NAND2x1_ASAP7_75t_R g045(.A(p7), .B(new_n65_), .Y(new_n104_));
  AO21x1_ASAP7_75t_R  g046(.A1(new_n64_), .A2(new_n104_), .B(p25), .Y(new_n105_));
  AOI21x1_ASAP7_75t_R g047(.A1(new_n105_), .A2(new_n68_), .B(new_n81_), .Y(new_n106_));
  AO21x1_ASAP7_75t_R  g048(.A1(new_n76_), .A2(new_n86_), .B(p18), .Y(new_n107_));
  AOI21x1_ASAP7_75t_R g049(.A1(new_n107_), .A2(new_n80_), .B(new_n69_), .Y(new_n108_));
  OAI21x1_ASAP7_75t_R g050(.A1(new_n106_), .A2(new_n108_), .B(new_n84_), .Y(new_n109_));
  NAND3x1_ASAP7_75t_R g051(.A(new_n70_), .B(new_n82_), .C(new_n83_), .Y(new_n110_));
  NAND3x1_ASAP7_75t_R g052(.A(new_n109_), .B(new_n110_), .C(new_n100_), .Y(new_n111_));
  NAND2x1_ASAP7_75t_R g053(.A(new_n103_), .B(new_n111_), .Y(new_n112_));
  INVx1_ASAP7_75t_R   g054(.A(p0), .Y(new_n113_));
  INVx1_ASAP7_75t_R   g055(.A(p26), .Y(new_n114_));
  AO21x1_ASAP7_75t_R  g056(.A1(new_n113_), .A2(new_n103_), .B(new_n114_), .Y(new_n115_));
  INVx1_ASAP7_75t_R   g057(.A(new_n115_), .Y(new_n116_));
  OAI21x1_ASAP7_75t_R g058(.A1(new_n102_), .A2(new_n112_), .B(new_n116_), .Y(new_n117_));
  OA21x2_ASAP7_75t_R  g059(.A1(p0), .A2(p2), .B(p16), .Y(new_n118_));
  NAND2x1_ASAP7_75t_R g060(.A(new_n82_), .B(new_n90_), .Y(new_n119_));
  AOI21x1_ASAP7_75t_R g061(.A1(new_n85_), .A2(new_n119_), .B(new_n100_), .Y(new_n120_));
  AND3x1_ASAP7_75t_R  g062(.A(new_n119_), .B(new_n85_), .C(new_n100_), .Y(new_n121_));
  AND2x2_ASAP7_75t_R  g063(.A(new_n103_), .B(new_n115_), .Y(new_n122_));
  OAI21x1_ASAP7_75t_R g064(.A1(new_n120_), .A2(new_n121_), .B(new_n122_), .Y(new_n123_));
  AND3x1_ASAP7_75t_R  g065(.A(new_n117_), .B(new_n118_), .C(new_n123_), .Y(new_n124_));
  NOR2x1_ASAP7_75t_R  g066(.A(new_n91_), .B(new_n92_), .Y(new_n125_));
  INVx1_ASAP7_75t_R   g067(.A(p32), .Y(new_n126_));
  AND3x1_ASAP7_75t_R  g068(.A(new_n126_), .B(new_n97_), .C(p11), .Y(new_n127_));
  XOR2x2_ASAP7_75t_R  g069(.A(new_n125_), .B(new_n127_), .Y(new_n128_));
  XOR2x2_ASAP7_75t_R  g070(.A(p10), .B(p5), .Y(new_n129_));
  XOR2x2_ASAP7_75t_R  g071(.A(p7), .B(p6), .Y(new_n130_));
  XOR2x2_ASAP7_75t_R  g072(.A(new_n129_), .B(new_n130_), .Y(new_n131_));
  XOR2x2_ASAP7_75t_R  g073(.A(new_n128_), .B(new_n131_), .Y(new_n132_));
  INVx1_ASAP7_75t_R   g074(.A(p12), .Y(new_n133_));
  NAND3x1_ASAP7_75t_R g075(.A(new_n132_), .B(new_n103_), .C(new_n133_), .Y(new_n134_));
  AO21x1_ASAP7_75t_R  g076(.A1(new_n103_), .A2(new_n132_), .B(new_n133_), .Y(new_n135_));
  AND2x2_ASAP7_75t_R  g077(.A(new_n134_), .B(new_n135_), .Y(new_n136_));
  AND2x2_ASAP7_75t_R  g078(.A(p13), .B(p14), .Y(new_n137_));
  OAI21x1_ASAP7_75t_R g079(.A1(p13), .A2(p14), .B(p15), .Y(new_n138_));
  NOR2x1_ASAP7_75t_R  g080(.A(p13), .B(p14), .Y(new_n139_));
  OAI21x1_ASAP7_75t_R g081(.A1(new_n139_), .A2(new_n137_), .B(new_n93_), .Y(new_n140_));
  OAI21x1_ASAP7_75t_R g082(.A1(new_n137_), .A2(new_n138_), .B(new_n140_), .Y(new_n141_));
  NOR2x1_ASAP7_75t_R  g083(.A(p0), .B(p1), .Y(new_n142_));
  NAND2x1_ASAP7_75t_R g084(.A(p16), .B(new_n142_), .Y(new_n143_));
  XOR2x2_ASAP7_75t_R  g085(.A(new_n143_), .B(new_n65_), .Y(new_n144_));
  NAND2x1_ASAP7_75t_R g086(.A(new_n141_), .B(new_n144_), .Y(new_n145_));
  NOR2x1_ASAP7_75t_R  g087(.A(new_n138_), .B(new_n137_), .Y(new_n146_));
  INVx1_ASAP7_75t_R   g088(.A(p13), .Y(new_n147_));
  INVx1_ASAP7_75t_R   g089(.A(p14), .Y(new_n148_));
  AND3x1_ASAP7_75t_R  g090(.A(new_n147_), .B(new_n93_), .C(new_n148_), .Y(new_n149_));
  AND3x1_ASAP7_75t_R  g091(.A(new_n93_), .B(p13), .C(p14), .Y(new_n150_));
  NOR3x1_ASAP7_75t_R  g092(.A(new_n146_), .B(new_n149_), .C(new_n150_), .Y(new_n151_));
  XOR2x2_ASAP7_75t_R  g093(.A(new_n143_), .B(p19), .Y(new_n152_));
  NAND2x1_ASAP7_75t_R g094(.A(new_n151_), .B(new_n152_), .Y(new_n153_));
  XNOR2x2_ASAP7_75t_R g095(.A(p17), .B(p8), .Y(new_n154_));
  XOR2x2_ASAP7_75t_R  g096(.A(p5), .B(p18), .Y(new_n155_));
  XOR2x2_ASAP7_75t_R  g097(.A(new_n154_), .B(new_n155_), .Y(new_n156_));
  INVx1_ASAP7_75t_R   g098(.A(new_n156_), .Y(new_n157_));
  NAND3x1_ASAP7_75t_R g099(.A(new_n145_), .B(new_n153_), .C(new_n157_), .Y(new_n158_));
  AO21x1_ASAP7_75t_R  g100(.A1(new_n145_), .A2(new_n153_), .B(new_n157_), .Y(new_n159_));
  NAND2x1_ASAP7_75t_R g101(.A(new_n158_), .B(new_n159_), .Y(new_n160_));
  INVx1_ASAP7_75t_R   g102(.A(p20), .Y(new_n161_));
  AO21x1_ASAP7_75t_R  g103(.A1(new_n103_), .A2(new_n160_), .B(new_n161_), .Y(new_n162_));
  AOI21x1_ASAP7_75t_R g104(.A1(new_n158_), .A2(new_n159_), .B(p2), .Y(new_n163_));
  NOR2x1_ASAP7_75t_R  g105(.A(p32), .B(new_n113_), .Y(new_n164_));
  NOR2x1_ASAP7_75t_R  g106(.A(p1), .B(p4), .Y(new_n165_));
  INVx1_ASAP7_75t_R   g107(.A(new_n165_), .Y(new_n166_));
  NOR2x1_ASAP7_75t_R  g108(.A(p1), .B(p3), .Y(new_n167_));
  INVx1_ASAP7_75t_R   g109(.A(new_n167_), .Y(new_n168_));
  OR3x1_ASAP7_75t_R   g110(.A(new_n168_), .B(new_n164_), .C(p2), .Y(new_n169_));
  OA21x2_ASAP7_75t_R  g111(.A1(new_n164_), .A2(new_n166_), .B(new_n169_), .Y(new_n170_));
  AOI21x1_ASAP7_75t_R g112(.A1(new_n161_), .A2(new_n163_), .B(new_n170_), .Y(new_n171_));
  AND3x1_ASAP7_75t_R  g113(.A(new_n136_), .B(new_n162_), .C(new_n171_), .Y(new_n172_));
  INVx1_ASAP7_75t_R   g114(.A(p17), .Y(new_n173_));
  XNOR2x2_ASAP7_75t_R g115(.A(p10), .B(p24), .Y(new_n174_));
  AND2x2_ASAP7_75t_R  g116(.A(new_n173_), .B(new_n174_), .Y(new_n175_));
  NOR2x1_ASAP7_75t_R  g117(.A(new_n173_), .B(new_n174_), .Y(new_n176_));
  OAI21x1_ASAP7_75t_R g118(.A1(new_n91_), .A2(new_n92_), .B(p15), .Y(new_n177_));
  OR3x1_ASAP7_75t_R   g119(.A(new_n92_), .B(p15), .C(new_n91_), .Y(new_n178_));
  NAND2x1_ASAP7_75t_R g120(.A(new_n177_), .B(new_n178_), .Y(new_n179_));
  OAI21x1_ASAP7_75t_R g121(.A1(new_n175_), .A2(new_n176_), .B(new_n179_), .Y(new_n180_));
  NOR2x1_ASAP7_75t_R  g122(.A(p10), .B(p17), .Y(new_n181_));
  AND2x2_ASAP7_75t_R  g123(.A(p10), .B(p17), .Y(new_n182_));
  OAI21x1_ASAP7_75t_R g124(.A1(new_n181_), .A2(new_n182_), .B(p24), .Y(new_n183_));
  OR3x1_ASAP7_75t_R   g125(.A(new_n182_), .B(p24), .C(new_n181_), .Y(new_n184_));
  NAND2x1_ASAP7_75t_R g126(.A(new_n183_), .B(new_n184_), .Y(new_n185_));
  NAND2x1_ASAP7_75t_R g127(.A(new_n96_), .B(new_n185_), .Y(new_n186_));
  NAND2x1_ASAP7_75t_R g128(.A(new_n180_), .B(new_n186_), .Y(new_n187_));
  AND2x2_ASAP7_75t_R  g129(.A(p22), .B(p14), .Y(new_n188_));
  NOR2x1_ASAP7_75t_R  g130(.A(p22), .B(p14), .Y(new_n189_));
  INVx1_ASAP7_75t_R   g131(.A(p28), .Y(new_n190_));
  NOR2x1_ASAP7_75t_R  g132(.A(p1), .B(new_n190_), .Y(new_n191_));
  OAI21x1_ASAP7_75t_R g133(.A1(new_n188_), .A2(new_n189_), .B(new_n191_), .Y(new_n192_));
  INVx1_ASAP7_75t_R   g134(.A(new_n189_), .Y(new_n193_));
  NAND2x1_ASAP7_75t_R g135(.A(p28), .B(new_n97_), .Y(new_n194_));
  NAND2x1_ASAP7_75t_R g136(.A(p22), .B(p14), .Y(new_n195_));
  NAND3x1_ASAP7_75t_R g137(.A(new_n193_), .B(new_n194_), .C(new_n195_), .Y(new_n196_));
  NAND2x1_ASAP7_75t_R g138(.A(new_n192_), .B(new_n196_), .Y(new_n197_));
  XOR2x2_ASAP7_75t_R  g139(.A(new_n197_), .B(new_n69_), .Y(new_n198_));
  NAND2x1_ASAP7_75t_R g140(.A(new_n187_), .B(new_n198_), .Y(new_n199_));
  XOR2x2_ASAP7_75t_R  g141(.A(new_n96_), .B(new_n185_), .Y(new_n200_));
  NAND2x1_ASAP7_75t_R g142(.A(new_n69_), .B(new_n197_), .Y(new_n201_));
  NAND2x1_ASAP7_75t_R g143(.A(p22), .B(new_n148_), .Y(new_n202_));
  INVx1_ASAP7_75t_R   g144(.A(p22), .Y(new_n203_));
  NAND2x1_ASAP7_75t_R g145(.A(p14), .B(new_n203_), .Y(new_n204_));
  AOI21x1_ASAP7_75t_R g146(.A1(new_n202_), .A2(new_n204_), .B(new_n191_), .Y(new_n205_));
  AOI21x1_ASAP7_75t_R g147(.A1(new_n195_), .A2(new_n193_), .B(new_n194_), .Y(new_n206_));
  NOR2x1_ASAP7_75t_R  g148(.A(new_n205_), .B(new_n206_), .Y(new_n207_));
  OAI21x1_ASAP7_75t_R g149(.A1(new_n72_), .A2(new_n73_), .B(new_n207_), .Y(new_n208_));
  NAND2x1_ASAP7_75t_R g150(.A(new_n201_), .B(new_n208_), .Y(new_n209_));
  NAND2x1_ASAP7_75t_R g151(.A(new_n200_), .B(new_n209_), .Y(new_n210_));
  NOR2x1_ASAP7_75t_R  g152(.A(p2), .B(p29), .Y(new_n211_));
  NAND3x1_ASAP7_75t_R g153(.A(new_n199_), .B(new_n210_), .C(new_n211_), .Y(new_n212_));
  NAND3x1_ASAP7_75t_R g154(.A(new_n198_), .B(new_n200_), .C(new_n103_), .Y(new_n213_));
  NAND3x1_ASAP7_75t_R g155(.A(new_n209_), .B(new_n187_), .C(new_n103_), .Y(new_n214_));
  NAND3x1_ASAP7_75t_R g156(.A(new_n213_), .B(new_n214_), .C(p29), .Y(new_n215_));
  INVx1_ASAP7_75t_R   g157(.A(p23), .Y(new_n216_));
  AO21x1_ASAP7_75t_R  g158(.A1(new_n126_), .A2(new_n103_), .B(new_n216_), .Y(new_n217_));
  AOI21x1_ASAP7_75t_R g159(.A1(new_n212_), .A2(new_n215_), .B(new_n217_), .Y(new_n218_));
  AOI21x1_ASAP7_75t_R g160(.A1(p26), .A2(new_n142_), .B(new_n66_), .Y(new_n219_));
  AND3x1_ASAP7_75t_R  g161(.A(new_n142_), .B(new_n66_), .C(p26), .Y(new_n220_));
  NOR2x1_ASAP7_75t_R  g162(.A(new_n219_), .B(new_n220_), .Y(new_n221_));
  OAI21x1_ASAP7_75t_R g163(.A1(new_n87_), .A2(new_n88_), .B(new_n221_), .Y(new_n222_));
  AOI21x1_ASAP7_75t_R g164(.A1(p26), .A2(new_n142_), .B(p25), .Y(new_n223_));
  AND3x1_ASAP7_75t_R  g165(.A(new_n142_), .B(p25), .C(p26), .Y(new_n224_));
  NOR2x1_ASAP7_75t_R  g166(.A(new_n223_), .B(new_n224_), .Y(new_n225_));
  OAI21x1_ASAP7_75t_R g167(.A1(new_n61_), .A2(new_n60_), .B(new_n225_), .Y(new_n226_));
  NAND2x1_ASAP7_75t_R g168(.A(new_n222_), .B(new_n226_), .Y(new_n227_));
  NAND2x1_ASAP7_75t_R g169(.A(new_n227_), .B(new_n187_), .Y(new_n228_));
  NAND3x1_ASAP7_75t_R g170(.A(new_n200_), .B(new_n222_), .C(new_n226_), .Y(new_n229_));
  INVx1_ASAP7_75t_R   g171(.A(p27), .Y(new_n230_));
  NOR2x1_ASAP7_75t_R  g172(.A(p2), .B(new_n230_), .Y(new_n231_));
  INVx1_ASAP7_75t_R   g173(.A(new_n231_), .Y(new_n232_));
  AOI21x1_ASAP7_75t_R g174(.A1(new_n228_), .A2(new_n229_), .B(new_n232_), .Y(new_n233_));
  AND3x1_ASAP7_75t_R  g175(.A(new_n187_), .B(new_n103_), .C(new_n227_), .Y(new_n234_));
  NOR3x1_ASAP7_75t_R  g176(.A(new_n187_), .B(p2), .C(new_n227_), .Y(new_n235_));
  NOR3x1_ASAP7_75t_R  g177(.A(new_n234_), .B(new_n235_), .C(p27), .Y(new_n236_));
  NOR2x1_ASAP7_75t_R  g178(.A(p32), .B(p1), .Y(new_n237_));
  NAND2x1_ASAP7_75t_R g179(.A(p23), .B(new_n237_), .Y(new_n238_));
  XOR2x2_ASAP7_75t_R  g180(.A(p22), .B(p24), .Y(new_n239_));
  NAND2x1_ASAP7_75t_R g181(.A(new_n238_), .B(new_n239_), .Y(new_n240_));
  INVx1_ASAP7_75t_R   g182(.A(new_n237_), .Y(new_n241_));
  OR3x1_ASAP7_75t_R   g183(.A(new_n239_), .B(new_n216_), .C(new_n241_), .Y(new_n242_));
  AOI21x1_ASAP7_75t_R g184(.A1(new_n240_), .A2(new_n242_), .B(new_n151_), .Y(new_n243_));
  AND2x2_ASAP7_75t_R  g185(.A(new_n238_), .B(new_n239_), .Y(new_n244_));
  NOR2x1_ASAP7_75t_R  g186(.A(new_n238_), .B(new_n239_), .Y(new_n245_));
  NOR3x1_ASAP7_75t_R  g187(.A(new_n141_), .B(new_n244_), .C(new_n245_), .Y(new_n246_));
  XNOR2x2_ASAP7_75t_R g188(.A(p9), .B(p21), .Y(new_n247_));
  INVx1_ASAP7_75t_R   g189(.A(new_n247_), .Y(new_n248_));
  OAI21x1_ASAP7_75t_R g190(.A1(new_n243_), .A2(new_n246_), .B(new_n248_), .Y(new_n249_));
  NAND3x1_ASAP7_75t_R g191(.A(new_n151_), .B(new_n242_), .C(new_n240_), .Y(new_n250_));
  OAI21x1_ASAP7_75t_R g192(.A1(new_n245_), .A2(new_n244_), .B(new_n141_), .Y(new_n251_));
  NAND3x1_ASAP7_75t_R g193(.A(new_n250_), .B(new_n251_), .C(new_n247_), .Y(new_n252_));
  AND2x2_ASAP7_75t_R  g194(.A(p11), .B(p2), .Y(new_n253_));
  AO21x1_ASAP7_75t_R  g195(.A1(p32), .A2(p11), .B(new_n253_), .Y(new_n254_));
  AND3x1_ASAP7_75t_R  g196(.A(new_n249_), .B(new_n252_), .C(new_n254_), .Y(new_n255_));
  AO21x1_ASAP7_75t_R  g197(.A1(p32), .A2(p11), .B(p2), .Y(new_n256_));
  AOI21x1_ASAP7_75t_R g198(.A1(new_n252_), .A2(new_n249_), .B(new_n256_), .Y(new_n257_));
  NOR3x1_ASAP7_75t_R  g199(.A(new_n255_), .B(new_n257_), .C(new_n253_), .Y(new_n258_));
  OAI21x1_ASAP7_75t_R g200(.A1(new_n233_), .A2(new_n236_), .B(new_n258_), .Y(new_n259_));
  NOR2x1_ASAP7_75t_R  g201(.A(new_n218_), .B(new_n259_), .Y(new_n260_));
  AND3x1_ASAP7_75t_R  g202(.A(new_n124_), .B(new_n172_), .C(new_n260_), .Y(new_n261_));
  XOR2x2_ASAP7_75t_R  g203(.A(new_n261_), .B(new_n148_), .Y(o0));
  OAI21x1_ASAP7_75t_R g204(.A1(new_n102_), .A2(new_n112_), .B(new_n115_), .Y(new_n263_));
  AOI21x1_ASAP7_75t_R g205(.A1(new_n85_), .A2(new_n101_), .B(new_n115_), .Y(new_n264_));
  NAND3x1_ASAP7_75t_R g206(.A(new_n264_), .B(new_n103_), .C(new_n111_), .Y(new_n265_));
  NAND3x1_ASAP7_75t_R g207(.A(new_n263_), .B(new_n118_), .C(new_n265_), .Y(new_n266_));
  OR3x1_ASAP7_75t_R   g208(.A(p1), .B(p31), .C(p2), .Y(new_n267_));
  AO21x1_ASAP7_75t_R  g209(.A1(new_n267_), .A2(new_n166_), .B(new_n164_), .Y(new_n268_));
  INVx1_ASAP7_75t_R   g210(.A(new_n268_), .Y(new_n269_));
  NAND3x1_ASAP7_75t_R g211(.A(new_n135_), .B(new_n134_), .C(new_n269_), .Y(new_n270_));
  AND3x1_ASAP7_75t_R  g212(.A(new_n160_), .B(new_n161_), .C(new_n103_), .Y(new_n271_));
  NOR2x1_ASAP7_75t_R  g213(.A(new_n161_), .B(new_n163_), .Y(new_n272_));
  NOR3x1_ASAP7_75t_R  g214(.A(new_n270_), .B(new_n271_), .C(new_n272_), .Y(new_n273_));
  NAND3x1_ASAP7_75t_R g215(.A(new_n266_), .B(new_n260_), .C(new_n273_), .Y(new_n274_));
  XOR2x2_ASAP7_75t_R  g216(.A(new_n274_), .B(p25), .Y(o1));
  XOR2x2_ASAP7_75t_R  g217(.A(new_n274_), .B(p19), .Y(o2));
  XNOR2x2_ASAP7_75t_R g218(.A(p24), .B(new_n261_), .Y(o3));
  XOR2x2_ASAP7_75t_R  g219(.A(new_n274_), .B(p7), .Y(o4));
  XOR2x2_ASAP7_75t_R  g220(.A(new_n274_), .B(p22), .Y(o5));
  NAND3x1_ASAP7_75t_R g221(.A(new_n136_), .B(new_n162_), .C(new_n171_), .Y(new_n280_));
  NOR3x1_ASAP7_75t_R  g222(.A(new_n280_), .B(new_n259_), .C(new_n218_), .Y(new_n281_));
  NAND2x1_ASAP7_75t_R g223(.A(new_n266_), .B(new_n281_), .Y(new_n282_));
  XOR2x2_ASAP7_75t_R  g224(.A(new_n282_), .B(p9), .Y(o6));
  XOR2x2_ASAP7_75t_R  g225(.A(new_n282_), .B(p8), .Y(o7));
  XOR2x2_ASAP7_75t_R  g226(.A(new_n282_), .B(p15), .Y(o8));
  OA21x2_ASAP7_75t_R  g227(.A1(new_n233_), .A2(new_n236_), .B(new_n258_), .Y(new_n286_));
  INVx1_ASAP7_75t_R   g228(.A(new_n217_), .Y(new_n287_));
  AND2x2_ASAP7_75t_R  g229(.A(new_n212_), .B(new_n215_), .Y(new_n288_));
  AND3x1_ASAP7_75t_R  g230(.A(new_n286_), .B(new_n287_), .C(new_n288_), .Y(new_n289_));
  AND3x1_ASAP7_75t_R  g231(.A(new_n289_), .B(new_n273_), .C(new_n266_), .Y(new_n290_));
  XOR2x2_ASAP7_75t_R  g232(.A(new_n290_), .B(new_n78_), .Y(o9));
  XOR2x2_ASAP7_75t_R  g233(.A(new_n290_), .B(new_n75_), .Y(o10));
  XOR2x2_ASAP7_75t_R  g234(.A(new_n290_), .B(new_n77_), .Y(o11));
  XNOR2x2_ASAP7_75t_R g235(.A(p5), .B(new_n290_), .Y(o12));
  AND3x1_ASAP7_75t_R  g236(.A(new_n289_), .B(new_n172_), .C(new_n266_), .Y(new_n295_));
  XOR2x2_ASAP7_75t_R  g237(.A(new_n295_), .B(new_n147_), .Y(o13));
  XOR2x2_ASAP7_75t_R  g238(.A(new_n261_), .B(new_n173_), .Y(o14));
  XNOR2x2_ASAP7_75t_R g239(.A(p10), .B(new_n261_), .Y(o15));
  NAND2x1_ASAP7_75t_R g240(.A(new_n123_), .B(new_n117_), .Y(new_n299_));
  NAND2x1_ASAP7_75t_R g241(.A(new_n134_), .B(new_n135_), .Y(new_n300_));
  OR3x1_ASAP7_75t_R   g242(.A(new_n300_), .B(new_n271_), .C(new_n272_), .Y(new_n301_));
  OR3x1_ASAP7_75t_R   g243(.A(new_n299_), .B(new_n301_), .C(new_n259_), .Y(new_n302_));
  NAND2x1_ASAP7_75t_R g244(.A(new_n217_), .B(new_n288_), .Y(new_n303_));
  NOR3x1_ASAP7_75t_R  g245(.A(new_n302_), .B(new_n118_), .C(new_n303_), .Y(new_n304_));
  AOI21x1_ASAP7_75t_R g246(.A1(new_n118_), .A2(new_n299_), .B(new_n259_), .Y(new_n305_));
  AND2x2_ASAP7_75t_R  g247(.A(new_n268_), .B(new_n169_), .Y(new_n306_));
  NOR3x1_ASAP7_75t_R  g248(.A(new_n301_), .B(new_n218_), .C(new_n306_), .Y(new_n307_));
  AND3x1_ASAP7_75t_R  g249(.A(new_n305_), .B(p4), .C(new_n307_), .Y(new_n308_));
  OR3x1_ASAP7_75t_R   g250(.A(new_n304_), .B(new_n308_), .C(p1), .Y(o16));
  NOR2x1_ASAP7_75t_R  g251(.A(new_n120_), .B(new_n121_), .Y(new_n310_));
  AND3x1_ASAP7_75t_R  g252(.A(new_n103_), .B(p0), .C(p26), .Y(new_n311_));
  NAND3x1_ASAP7_75t_R g253(.A(new_n305_), .B(new_n307_), .C(new_n311_), .Y(new_n312_));
  NAND2x1_ASAP7_75t_R g254(.A(new_n307_), .B(new_n305_), .Y(new_n313_));
  OAI21x1_ASAP7_75t_R g255(.A1(new_n265_), .A2(new_n313_), .B(new_n166_), .Y(new_n314_));
  AOI21x1_ASAP7_75t_R g256(.A1(new_n310_), .A2(new_n312_), .B(new_n314_), .Y(o17));
  NAND2x1_ASAP7_75t_R g257(.A(new_n210_), .B(new_n199_), .Y(new_n316_));
  INVx1_ASAP7_75t_R   g258(.A(p29), .Y(new_n317_));
  NOR2x1_ASAP7_75t_R  g259(.A(p2), .B(new_n317_), .Y(new_n318_));
  NAND3x1_ASAP7_75t_R g260(.A(new_n305_), .B(new_n307_), .C(new_n318_), .Y(new_n319_));
  OR3x1_ASAP7_75t_R   g261(.A(new_n316_), .B(p2), .C(new_n317_), .Y(new_n320_));
  OAI21x1_ASAP7_75t_R g262(.A1(new_n320_), .A2(new_n313_), .B(new_n166_), .Y(new_n321_));
  AOI21x1_ASAP7_75t_R g263(.A1(new_n316_), .A2(new_n319_), .B(new_n321_), .Y(o18));
  AND2x2_ASAP7_75t_R  g264(.A(new_n158_), .B(new_n159_), .Y(new_n323_));
  AND3x1_ASAP7_75t_R  g265(.A(new_n305_), .B(p20), .C(new_n307_), .Y(new_n324_));
  OA21x2_ASAP7_75t_R  g266(.A1(new_n323_), .A2(new_n324_), .B(new_n166_), .Y(o19));
  NAND3x1_ASAP7_75t_R g267(.A(new_n305_), .B(new_n307_), .C(p12), .Y(new_n326_));
  AOI21x1_ASAP7_75t_R g268(.A1(new_n132_), .A2(new_n326_), .B(new_n165_), .Y(o20));
  AND2x2_ASAP7_75t_R  g269(.A(new_n252_), .B(new_n249_), .Y(new_n328_));
  AND3x1_ASAP7_75t_R  g270(.A(new_n305_), .B(new_n254_), .C(new_n307_), .Y(new_n329_));
  OA21x2_ASAP7_75t_R  g271(.A1(new_n328_), .A2(new_n329_), .B(new_n166_), .Y(o21));
  OA21x2_ASAP7_75t_R  g272(.A1(new_n217_), .A2(new_n288_), .B(new_n273_), .Y(new_n331_));
  NOR2x1_ASAP7_75t_R  g273(.A(p1), .B(p31), .Y(new_n332_));
  AO21x1_ASAP7_75t_R  g274(.A1(new_n110_), .A2(new_n109_), .B(new_n332_), .Y(new_n333_));
  AOI21x1_ASAP7_75t_R g275(.A1(new_n331_), .A2(new_n305_), .B(new_n333_), .Y(new_n334_));
  NAND2x1_ASAP7_75t_R g276(.A(new_n97_), .B(new_n333_), .Y(new_n335_));
  AO21x1_ASAP7_75t_R  g277(.A1(p31), .A2(p30), .B(p1), .Y(new_n336_));
  INVx1_ASAP7_75t_R   g278(.A(new_n336_), .Y(new_n337_));
  OAI21x1_ASAP7_75t_R g279(.A1(new_n335_), .A2(new_n274_), .B(new_n337_), .Y(new_n338_));
  NOR2x1_ASAP7_75t_R  g280(.A(new_n335_), .B(new_n274_), .Y(new_n339_));
  OAI21x1_ASAP7_75t_R g281(.A1(new_n339_), .A2(new_n334_), .B(new_n336_), .Y(new_n340_));
  OAI21x1_ASAP7_75t_R g282(.A1(new_n334_), .A2(new_n338_), .B(new_n340_), .Y(o22));
  NOR2x1_ASAP7_75t_R  g283(.A(new_n139_), .B(new_n137_), .Y(new_n342_));
  INVx1_ASAP7_75t_R   g284(.A(new_n342_), .Y(new_n343_));
  AO21x1_ASAP7_75t_R  g285(.A1(new_n343_), .A2(new_n200_), .B(new_n167_), .Y(new_n344_));
  AO21x1_ASAP7_75t_R  g286(.A1(new_n342_), .A2(new_n187_), .B(new_n344_), .Y(new_n345_));
  AOI21x1_ASAP7_75t_R g287(.A1(new_n266_), .A2(new_n281_), .B(new_n345_), .Y(new_n346_));
  NAND2x1_ASAP7_75t_R g288(.A(new_n97_), .B(new_n345_), .Y(new_n347_));
  AO21x1_ASAP7_75t_R  g289(.A1(new_n190_), .A2(new_n97_), .B(new_n167_), .Y(new_n348_));
  OAI21x1_ASAP7_75t_R g290(.A1(new_n347_), .A2(new_n282_), .B(new_n348_), .Y(new_n349_));
  NAND2x1_ASAP7_75t_R g291(.A(new_n172_), .B(new_n260_), .Y(new_n350_));
  INVx1_ASAP7_75t_R   g292(.A(new_n266_), .Y(new_n351_));
  NOR3x1_ASAP7_75t_R  g293(.A(new_n350_), .B(new_n351_), .C(new_n347_), .Y(new_n352_));
  INVx1_ASAP7_75t_R   g294(.A(new_n348_), .Y(new_n353_));
  OAI21x1_ASAP7_75t_R g295(.A1(new_n346_), .A2(new_n352_), .B(new_n353_), .Y(new_n354_));
  OAI21x1_ASAP7_75t_R g296(.A1(new_n346_), .A2(new_n349_), .B(new_n354_), .Y(o23));
  OAI21x1_ASAP7_75t_R g297(.A1(new_n232_), .A2(new_n313_), .B(new_n166_), .Y(new_n356_));
  AOI21x1_ASAP7_75t_R g298(.A1(new_n228_), .A2(new_n229_), .B(new_n356_), .Y(o24));
endmodule


