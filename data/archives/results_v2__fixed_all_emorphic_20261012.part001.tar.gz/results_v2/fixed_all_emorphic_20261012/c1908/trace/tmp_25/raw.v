// Benchmark "/tmp/" written by ABC on Mon Oct 12 15:05:24 2026

module \/tmp/  ( 
    p2, p13, p11, p31, p21, p25, p32, p26, p9, p5, p8, p28, p20, p19, p14,
    p10, p16, p18, p7, p1, p24, p6, p27, p22, p12, p0, p29, p23, p3, p30,
    p17, p4, p15,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24  );
  input  p2, p13, p11, p31, p21, p25, p32, p26, p9, p5, p8, p28, p20,
    p19, p14, p10, p16, p18, p7, p1, p24, p6, p27, p22, p12, p0, p29, p23,
    p3, p30, p17, p4, p15;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24;
  wire new_n59_, new_n60_, new_n61_, new_n62_, new_n63_, new_n64_, new_n65_,
    new_n66_, new_n67_, new_n68_, new_n69_, new_n70_, new_n71_, new_n72_,
    new_n73_, new_n74_, new_n75_, new_n76_, new_n77_, new_n78_, new_n79_,
    new_n80_, new_n81_, new_n82_, new_n83_, new_n84_, new_n85_, new_n86_,
    new_n87_, new_n88_, new_n89_, new_n90_, new_n91_, new_n92_, new_n93_,
    new_n94_, new_n95_, new_n96_, new_n97_, new_n98_, new_n99_, new_n100_,
    new_n101_, new_n102_, new_n103_, new_n104_, new_n105_, new_n106_,
    new_n107_, new_n108_, new_n109_, new_n110_, new_n111_, new_n112_,
    new_n113_, new_n114_, new_n115_, new_n116_, new_n117_, new_n118_,
    new_n119_, new_n120_, new_n121_, new_n122_, new_n123_, new_n124_,
    new_n125_, new_n126_, new_n127_, new_n128_, new_n129_, new_n130_,
    new_n131_, new_n132_, new_n133_, new_n134_, new_n135_, new_n136_,
    new_n137_, new_n138_, new_n139_, new_n140_, new_n141_, new_n142_,
    new_n143_, new_n144_, new_n145_, new_n146_, new_n147_, new_n148_,
    new_n149_, new_n150_, new_n151_, new_n152_, new_n153_, new_n154_,
    new_n155_, new_n156_, new_n157_, new_n158_, new_n159_, new_n160_,
    new_n161_, new_n162_, new_n163_, new_n164_, new_n165_, new_n166_,
    new_n167_, new_n168_, new_n169_, new_n170_, new_n171_, new_n172_,
    new_n173_, new_n174_, new_n175_, new_n176_, new_n177_, new_n178_,
    new_n179_, new_n180_, new_n181_, new_n182_, new_n183_, new_n184_,
    new_n185_, new_n186_, new_n187_, new_n188_, new_n189_, new_n190_,
    new_n191_, new_n192_, new_n193_, new_n194_, new_n195_, new_n196_,
    new_n197_, new_n198_, new_n199_, new_n200_, new_n201_, new_n202_,
    new_n203_, new_n204_, new_n205_, new_n206_, new_n207_, new_n208_,
    new_n209_, new_n210_, new_n211_, new_n212_, new_n213_, new_n214_,
    new_n215_, new_n216_, new_n217_, new_n218_, new_n219_, new_n220_,
    new_n221_, new_n222_, new_n223_, new_n224_, new_n225_, new_n226_,
    new_n227_, new_n228_, new_n229_, new_n230_, new_n231_, new_n232_,
    new_n233_, new_n234_, new_n235_, new_n236_, new_n237_, new_n238_,
    new_n239_, new_n240_, new_n241_, new_n242_, new_n243_, new_n244_,
    new_n245_, new_n246_, new_n247_, new_n248_, new_n249_, new_n250_,
    new_n251_, new_n252_, new_n253_, new_n254_, new_n255_, new_n256_,
    new_n257_, new_n258_, new_n259_, new_n260_, new_n261_, new_n262_,
    new_n263_, new_n264_, new_n265_, new_n266_, new_n267_, new_n268_,
    new_n269_, new_n270_, new_n272_, new_n273_, new_n274_, new_n275_,
    new_n276_, new_n277_, new_n278_, new_n279_, new_n280_, new_n283_,
    new_n287_, new_n288_, new_n289_, new_n293_, new_n294_, new_n295_,
    new_n296_, new_n297_, new_n299_, new_n301_, new_n303_, new_n305_,
    new_n306_, new_n307_, new_n309_, new_n310_, new_n312_, new_n313_,
    new_n315_, new_n316_, new_n317_, new_n318_, new_n319_, new_n320_,
    new_n321_, new_n322_, new_n323_, new_n324_, new_n325_, new_n326_,
    new_n328_, new_n329_, new_n330_, new_n331_, new_n332_, new_n333_,
    new_n335_, new_n336_, new_n337_, new_n338_, new_n339_, new_n341_,
    new_n343_, new_n344_, new_n345_, new_n346_, new_n347_, new_n348_,
    new_n350_, new_n351_, new_n353_, new_n354_, new_n355_, new_n356_,
    new_n357_, new_n358_, new_n359_, new_n360_, new_n361_, new_n362_,
    new_n363_, new_n364_, new_n366_, new_n367_, new_n368_, new_n369_,
    new_n370_, new_n372_, new_n373_;
  INVx1_ASAP7_75t_R   g000(.A(p2), .Y(new_n59_));
  INVx1_ASAP7_75t_R   g001(.A(p0), .Y(new_n60_));
  INVx1_ASAP7_75t_R   g002(.A(p26), .Y(new_n61_));
  AO21x1_ASAP7_75t_R  g003(.A1(new_n59_), .A2(new_n60_), .B(new_n61_), .Y(new_n62_));
  INVx1_ASAP7_75t_R   g004(.A(new_n62_), .Y(new_n63_));
  INVx1_ASAP7_75t_R   g005(.A(p7), .Y(new_n64_));
  NOR2x1_ASAP7_75t_R  g006(.A(p19), .B(new_n64_), .Y(new_n65_));
  INVx1_ASAP7_75t_R   g007(.A(p25), .Y(new_n66_));
  AO21x1_ASAP7_75t_R  g008(.A1(p19), .A2(new_n64_), .B(new_n66_), .Y(new_n67_));
  INVx1_ASAP7_75t_R   g009(.A(p19), .Y(new_n68_));
  NOR2x1_ASAP7_75t_R  g010(.A(p7), .B(new_n68_), .Y(new_n69_));
  OAI21x1_ASAP7_75t_R g011(.A1(new_n65_), .A2(new_n69_), .B(new_n66_), .Y(new_n70_));
  OAI21x1_ASAP7_75t_R g012(.A1(new_n65_), .A2(new_n67_), .B(new_n70_), .Y(new_n71_));
  INVx1_ASAP7_75t_R   g013(.A(p6), .Y(new_n72_));
  NOR2x1_ASAP7_75t_R  g014(.A(p18), .B(new_n72_), .Y(new_n73_));
  INVx1_ASAP7_75t_R   g015(.A(p18), .Y(new_n74_));
  NOR2x1_ASAP7_75t_R  g016(.A(p6), .B(new_n74_), .Y(new_n75_));
  OAI21x1_ASAP7_75t_R g017(.A1(new_n73_), .A2(new_n75_), .B(p21), .Y(new_n76_));
  NAND2x1_ASAP7_75t_R g018(.A(p6), .B(new_n74_), .Y(new_n77_));
  NAND2x1_ASAP7_75t_R g019(.A(p18), .B(new_n72_), .Y(new_n78_));
  INVx1_ASAP7_75t_R   g020(.A(p21), .Y(new_n79_));
  NAND3x1_ASAP7_75t_R g021(.A(new_n77_), .B(new_n78_), .C(new_n79_), .Y(new_n80_));
  NAND2x1_ASAP7_75t_R g022(.A(new_n76_), .B(new_n80_), .Y(new_n81_));
  NAND2x1_ASAP7_75t_R g023(.A(new_n71_), .B(new_n81_), .Y(new_n82_));
  XOR2x2_ASAP7_75t_R  g024(.A(p19), .B(p7), .Y(new_n83_));
  AND2x2_ASAP7_75t_R  g025(.A(p25), .B(new_n83_), .Y(new_n84_));
  NOR2x1_ASAP7_75t_R  g026(.A(p25), .B(new_n83_), .Y(new_n85_));
  NOR2x1_ASAP7_75t_R  g027(.A(p6), .B(new_n79_), .Y(new_n86_));
  AO21x1_ASAP7_75t_R  g028(.A1(p6), .A2(new_n79_), .B(new_n74_), .Y(new_n87_));
  NOR2x1_ASAP7_75t_R  g029(.A(p21), .B(new_n72_), .Y(new_n88_));
  OAI21x1_ASAP7_75t_R g030(.A1(new_n86_), .A2(new_n88_), .B(new_n74_), .Y(new_n89_));
  OAI21x1_ASAP7_75t_R g031(.A1(new_n86_), .A2(new_n87_), .B(new_n89_), .Y(new_n90_));
  OAI21x1_ASAP7_75t_R g032(.A1(new_n84_), .A2(new_n85_), .B(new_n90_), .Y(new_n91_));
  XNOR2x2_ASAP7_75t_R g033(.A(p5), .B(p22), .Y(new_n92_));
  NAND3x1_ASAP7_75t_R g034(.A(new_n82_), .B(new_n91_), .C(new_n92_), .Y(new_n93_));
  OAI21x1_ASAP7_75t_R g035(.A1(new_n65_), .A2(new_n69_), .B(p25), .Y(new_n94_));
  NAND2x1_ASAP7_75t_R g036(.A(p7), .B(new_n68_), .Y(new_n95_));
  NAND2x1_ASAP7_75t_R g037(.A(p19), .B(new_n64_), .Y(new_n96_));
  NAND3x1_ASAP7_75t_R g038(.A(new_n95_), .B(new_n96_), .C(new_n66_), .Y(new_n97_));
  NAND2x1_ASAP7_75t_R g039(.A(new_n94_), .B(new_n97_), .Y(new_n98_));
  NOR2x1_ASAP7_75t_R  g040(.A(new_n90_), .B(new_n98_), .Y(new_n99_));
  NOR2x1_ASAP7_75t_R  g041(.A(new_n71_), .B(new_n81_), .Y(new_n100_));
  INVx1_ASAP7_75t_R   g042(.A(new_n92_), .Y(new_n101_));
  OAI21x1_ASAP7_75t_R g043(.A1(new_n99_), .A2(new_n100_), .B(new_n101_), .Y(new_n102_));
  NOR2x1_ASAP7_75t_R  g044(.A(p9), .B(p8), .Y(new_n103_));
  AND2x2_ASAP7_75t_R  g045(.A(p9), .B(p8), .Y(new_n104_));
  INVx1_ASAP7_75t_R   g046(.A(p15), .Y(new_n105_));
  OAI21x1_ASAP7_75t_R g047(.A1(new_n103_), .A2(new_n104_), .B(new_n105_), .Y(new_n106_));
  OR3x1_ASAP7_75t_R   g048(.A(new_n104_), .B(new_n105_), .C(new_n103_), .Y(new_n107_));
  NAND2x1_ASAP7_75t_R g049(.A(new_n106_), .B(new_n107_), .Y(new_n108_));
  INVx1_ASAP7_75t_R   g050(.A(p1), .Y(new_n109_));
  NAND2x1_ASAP7_75t_R g051(.A(p30), .B(new_n109_), .Y(new_n110_));
  XOR2x2_ASAP7_75t_R  g052(.A(new_n110_), .B(p13), .Y(new_n111_));
  XOR2x2_ASAP7_75t_R  g053(.A(new_n108_), .B(new_n111_), .Y(new_n112_));
  AOI21x1_ASAP7_75t_R g054(.A1(new_n93_), .A2(new_n102_), .B(new_n112_), .Y(new_n113_));
  NAND3x1_ASAP7_75t_R g055(.A(new_n82_), .B(new_n91_), .C(new_n101_), .Y(new_n114_));
  OAI21x1_ASAP7_75t_R g056(.A1(new_n99_), .A2(new_n100_), .B(new_n92_), .Y(new_n115_));
  XNOR2x2_ASAP7_75t_R g057(.A(new_n111_), .B(new_n108_), .Y(new_n116_));
  AOI21x1_ASAP7_75t_R g058(.A1(new_n114_), .A2(new_n115_), .B(new_n116_), .Y(new_n117_));
  OAI21x1_ASAP7_75t_R g059(.A1(new_n113_), .A2(new_n117_), .B(new_n59_), .Y(new_n118_));
  NAND2x1_ASAP7_75t_R g060(.A(new_n63_), .B(new_n118_), .Y(new_n119_));
  OA21x2_ASAP7_75t_R  g061(.A1(p2), .A2(p0), .B(p16), .Y(new_n120_));
  AO21x1_ASAP7_75t_R  g062(.A1(new_n93_), .A2(new_n102_), .B(new_n112_), .Y(new_n121_));
  AO21x1_ASAP7_75t_R  g063(.A1(new_n114_), .A2(new_n115_), .B(new_n116_), .Y(new_n122_));
  AO21x1_ASAP7_75t_R  g064(.A1(p26), .A2(p0), .B(p2), .Y(new_n123_));
  AO21x1_ASAP7_75t_R  g065(.A1(new_n121_), .A2(new_n122_), .B(new_n123_), .Y(new_n124_));
  AND3x1_ASAP7_75t_R  g066(.A(new_n119_), .B(new_n120_), .C(new_n124_), .Y(new_n125_));
  INVx1_ASAP7_75t_R   g067(.A(new_n125_), .Y(new_n126_));
  OAI21x1_ASAP7_75t_R g068(.A1(p13), .A2(p14), .B(p15), .Y(new_n127_));
  AND2x2_ASAP7_75t_R  g069(.A(p13), .B(p14), .Y(new_n128_));
  NOR2x1_ASAP7_75t_R  g070(.A(new_n127_), .B(new_n128_), .Y(new_n129_));
  NAND2x1_ASAP7_75t_R g071(.A(p13), .B(p14), .Y(new_n130_));
  OR3x1_ASAP7_75t_R   g072(.A(p13), .B(p14), .C(p15), .Y(new_n131_));
  OAI21x1_ASAP7_75t_R g073(.A1(p15), .A2(new_n130_), .B(new_n131_), .Y(new_n132_));
  NOR2x1_ASAP7_75t_R  g074(.A(new_n129_), .B(new_n132_), .Y(new_n133_));
  XOR2x2_ASAP7_75t_R  g075(.A(p8), .B(p17), .Y(new_n134_));
  XOR2x2_ASAP7_75t_R  g076(.A(new_n134_), .B(p5), .Y(new_n135_));
  NOR2x1_ASAP7_75t_R  g077(.A(new_n133_), .B(new_n135_), .Y(new_n136_));
  NOR2x1_ASAP7_75t_R  g078(.A(p13), .B(p14), .Y(new_n137_));
  OAI21x1_ASAP7_75t_R g079(.A1(new_n137_), .A2(new_n128_), .B(new_n105_), .Y(new_n138_));
  AO21x1_ASAP7_75t_R  g080(.A1(p13), .A2(p14), .B(new_n127_), .Y(new_n139_));
  NAND2x1_ASAP7_75t_R g081(.A(new_n138_), .B(new_n139_), .Y(new_n140_));
  INVx1_ASAP7_75t_R   g082(.A(p5), .Y(new_n141_));
  XOR2x2_ASAP7_75t_R  g083(.A(new_n134_), .B(new_n141_), .Y(new_n142_));
  NOR2x1_ASAP7_75t_R  g084(.A(new_n140_), .B(new_n142_), .Y(new_n143_));
  AND3x1_ASAP7_75t_R  g085(.A(new_n109_), .B(new_n60_), .C(p16), .Y(new_n144_));
  XOR2x2_ASAP7_75t_R  g086(.A(p19), .B(p18), .Y(new_n145_));
  XOR2x2_ASAP7_75t_R  g087(.A(new_n144_), .B(new_n145_), .Y(new_n146_));
  OAI21x1_ASAP7_75t_R g088(.A1(new_n136_), .A2(new_n143_), .B(new_n146_), .Y(new_n147_));
  OR3x1_ASAP7_75t_R   g089(.A(new_n143_), .B(new_n136_), .C(new_n146_), .Y(new_n148_));
  NAND2x1_ASAP7_75t_R g090(.A(new_n147_), .B(new_n148_), .Y(new_n149_));
  INVx1_ASAP7_75t_R   g091(.A(p20), .Y(new_n150_));
  AO21x1_ASAP7_75t_R  g092(.A1(new_n59_), .A2(new_n149_), .B(new_n150_), .Y(new_n151_));
  XNOR2x2_ASAP7_75t_R g093(.A(p10), .B(p7), .Y(new_n152_));
  XOR2x2_ASAP7_75t_R  g094(.A(p5), .B(p6), .Y(new_n153_));
  NOR2x1_ASAP7_75t_R  g095(.A(p32), .B(p1), .Y(new_n154_));
  NAND2x1_ASAP7_75t_R g096(.A(p11), .B(new_n154_), .Y(new_n155_));
  OR3x1_ASAP7_75t_R   g097(.A(new_n152_), .B(new_n153_), .C(new_n155_), .Y(new_n156_));
  XNOR2x2_ASAP7_75t_R g098(.A(p5), .B(p6), .Y(new_n157_));
  XOR2x2_ASAP7_75t_R  g099(.A(p10), .B(p7), .Y(new_n158_));
  OR3x1_ASAP7_75t_R   g100(.A(new_n157_), .B(new_n158_), .C(new_n155_), .Y(new_n159_));
  NOR2x1_ASAP7_75t_R  g101(.A(new_n103_), .B(new_n104_), .Y(new_n160_));
  AOI21x1_ASAP7_75t_R g102(.A1(new_n156_), .A2(new_n159_), .B(new_n160_), .Y(new_n161_));
  INVx1_ASAP7_75t_R   g103(.A(p32), .Y(new_n162_));
  AND3x1_ASAP7_75t_R  g104(.A(new_n162_), .B(new_n109_), .C(p11), .Y(new_n163_));
  AO21x1_ASAP7_75t_R  g105(.A1(new_n158_), .A2(new_n157_), .B(new_n163_), .Y(new_n164_));
  NOR2x1_ASAP7_75t_R  g106(.A(new_n158_), .B(new_n157_), .Y(new_n165_));
  NOR3x1_ASAP7_75t_R  g107(.A(new_n164_), .B(new_n165_), .C(new_n160_), .Y(new_n166_));
  NOR3x1_ASAP7_75t_R  g108(.A(new_n161_), .B(new_n166_), .C(p2), .Y(new_n167_));
  AND2x2_ASAP7_75t_R  g109(.A(new_n156_), .B(new_n159_), .Y(new_n168_));
  NOR2x1_ASAP7_75t_R  g110(.A(new_n153_), .B(new_n152_), .Y(new_n169_));
  OR3x1_ASAP7_75t_R   g111(.A(new_n165_), .B(new_n169_), .C(new_n163_), .Y(new_n170_));
  NAND3x1_ASAP7_75t_R g112(.A(new_n168_), .B(new_n160_), .C(new_n170_), .Y(new_n171_));
  INVx1_ASAP7_75t_R   g113(.A(p12), .Y(new_n172_));
  AOI21x1_ASAP7_75t_R g114(.A1(new_n167_), .A2(new_n171_), .B(new_n172_), .Y(new_n173_));
  AND3x1_ASAP7_75t_R  g115(.A(new_n171_), .B(new_n167_), .C(new_n172_), .Y(new_n174_));
  NOR2x1_ASAP7_75t_R  g116(.A(new_n173_), .B(new_n174_), .Y(new_n175_));
  NOR2x1_ASAP7_75t_R  g117(.A(p2), .B(p20), .Y(new_n176_));
  OR3x1_ASAP7_75t_R   g118(.A(p2), .B(p1), .C(p3), .Y(new_n177_));
  INVx1_ASAP7_75t_R   g119(.A(p4), .Y(new_n178_));
  NAND2x1_ASAP7_75t_R g120(.A(new_n109_), .B(new_n178_), .Y(new_n179_));
  NOR2x1_ASAP7_75t_R  g121(.A(p32), .B(new_n60_), .Y(new_n180_));
  AO21x1_ASAP7_75t_R  g122(.A1(new_n177_), .A2(new_n179_), .B(new_n180_), .Y(new_n181_));
  AOI21x1_ASAP7_75t_R g123(.A1(new_n176_), .A2(new_n149_), .B(new_n181_), .Y(new_n182_));
  AND3x1_ASAP7_75t_R  g124(.A(new_n151_), .B(new_n175_), .C(new_n182_), .Y(new_n183_));
  INVx1_ASAP7_75t_R   g125(.A(p23), .Y(new_n184_));
  AO21x1_ASAP7_75t_R  g126(.A1(new_n59_), .A2(new_n162_), .B(new_n184_), .Y(new_n185_));
  INVx1_ASAP7_75t_R   g127(.A(new_n185_), .Y(new_n186_));
  NOR2x1_ASAP7_75t_R  g128(.A(p14), .B(p22), .Y(new_n187_));
  AND2x2_ASAP7_75t_R  g129(.A(p14), .B(p22), .Y(new_n188_));
  INVx1_ASAP7_75t_R   g130(.A(p28), .Y(new_n189_));
  NOR2x1_ASAP7_75t_R  g131(.A(p1), .B(new_n189_), .Y(new_n190_));
  OAI21x1_ASAP7_75t_R g132(.A1(new_n187_), .A2(new_n188_), .B(new_n190_), .Y(new_n191_));
  NAND2x1_ASAP7_75t_R g133(.A(p28), .B(new_n109_), .Y(new_n192_));
  XOR2x2_ASAP7_75t_R  g134(.A(p14), .B(p22), .Y(new_n193_));
  NAND2x1_ASAP7_75t_R g135(.A(new_n192_), .B(new_n193_), .Y(new_n194_));
  NAND2x1_ASAP7_75t_R g136(.A(new_n191_), .B(new_n194_), .Y(new_n195_));
  XOR2x2_ASAP7_75t_R  g137(.A(new_n195_), .B(new_n98_), .Y(new_n196_));
  NOR2x1_ASAP7_75t_R  g138(.A(p10), .B(p24), .Y(new_n197_));
  AND2x2_ASAP7_75t_R  g139(.A(p10), .B(p24), .Y(new_n198_));
  OAI21x1_ASAP7_75t_R g140(.A1(new_n197_), .A2(new_n198_), .B(p17), .Y(new_n199_));
  OR3x1_ASAP7_75t_R   g141(.A(new_n198_), .B(p17), .C(new_n197_), .Y(new_n200_));
  NAND2x1_ASAP7_75t_R g142(.A(new_n199_), .B(new_n200_), .Y(new_n201_));
  XNOR2x2_ASAP7_75t_R g143(.A(new_n108_), .B(new_n201_), .Y(new_n202_));
  OR3x1_ASAP7_75t_R   g144(.A(new_n196_), .B(new_n202_), .C(p2), .Y(new_n203_));
  XOR2x2_ASAP7_75t_R  g145(.A(new_n108_), .B(new_n201_), .Y(new_n204_));
  XOR2x2_ASAP7_75t_R  g146(.A(new_n195_), .B(new_n71_), .Y(new_n205_));
  NOR2x1_ASAP7_75t_R  g147(.A(new_n204_), .B(new_n205_), .Y(new_n206_));
  INVx1_ASAP7_75t_R   g148(.A(p29), .Y(new_n207_));
  AOI21x1_ASAP7_75t_R g149(.A1(new_n59_), .A2(new_n206_), .B(new_n207_), .Y(new_n208_));
  NAND2x1_ASAP7_75t_R g150(.A(new_n204_), .B(new_n205_), .Y(new_n209_));
  NAND2x1_ASAP7_75t_R g151(.A(new_n202_), .B(new_n196_), .Y(new_n210_));
  NOR2x1_ASAP7_75t_R  g152(.A(p2), .B(p29), .Y(new_n211_));
  INVx1_ASAP7_75t_R   g153(.A(new_n211_), .Y(new_n212_));
  AOI21x1_ASAP7_75t_R g154(.A1(new_n209_), .A2(new_n210_), .B(new_n212_), .Y(new_n213_));
  AO21x1_ASAP7_75t_R  g155(.A1(new_n203_), .A2(new_n208_), .B(new_n213_), .Y(new_n214_));
  NAND2x1_ASAP7_75t_R g156(.A(new_n186_), .B(new_n214_), .Y(new_n215_));
  NAND2x1_ASAP7_75t_R g157(.A(new_n183_), .B(new_n215_), .Y(new_n216_));
  NOR2x1_ASAP7_75t_R  g158(.A(p1), .B(p0), .Y(new_n217_));
  AOI21x1_ASAP7_75t_R g159(.A1(p26), .A2(new_n217_), .B(new_n66_), .Y(new_n218_));
  AND3x1_ASAP7_75t_R  g160(.A(new_n217_), .B(new_n66_), .C(p26), .Y(new_n219_));
  NOR2x1_ASAP7_75t_R  g161(.A(new_n218_), .B(new_n219_), .Y(new_n220_));
  XOR2x2_ASAP7_75t_R  g162(.A(new_n90_), .B(new_n220_), .Y(new_n221_));
  NAND2x1_ASAP7_75t_R g163(.A(new_n221_), .B(new_n202_), .Y(new_n222_));
  XOR2x2_ASAP7_75t_R  g164(.A(new_n81_), .B(new_n220_), .Y(new_n223_));
  NAND2x1_ASAP7_75t_R g165(.A(new_n204_), .B(new_n223_), .Y(new_n224_));
  INVx1_ASAP7_75t_R   g166(.A(p27), .Y(new_n225_));
  NOR2x1_ASAP7_75t_R  g167(.A(p2), .B(new_n225_), .Y(new_n226_));
  NAND3x1_ASAP7_75t_R g168(.A(new_n222_), .B(new_n224_), .C(new_n226_), .Y(new_n227_));
  NAND3x1_ASAP7_75t_R g169(.A(new_n223_), .B(new_n202_), .C(new_n59_), .Y(new_n228_));
  NAND3x1_ASAP7_75t_R g170(.A(new_n221_), .B(new_n204_), .C(new_n59_), .Y(new_n229_));
  NAND3x1_ASAP7_75t_R g171(.A(new_n228_), .B(new_n229_), .C(new_n225_), .Y(new_n230_));
  NOR3x1_ASAP7_75t_R  g172(.A(new_n132_), .B(p22), .C(new_n129_), .Y(new_n231_));
  INVx1_ASAP7_75t_R   g173(.A(p22), .Y(new_n232_));
  AOI21x1_ASAP7_75t_R g174(.A1(new_n138_), .A2(new_n139_), .B(new_n232_), .Y(new_n233_));
  NOR2x1_ASAP7_75t_R  g175(.A(p24), .B(new_n184_), .Y(new_n234_));
  INVx1_ASAP7_75t_R   g176(.A(p24), .Y(new_n235_));
  AOI21x1_ASAP7_75t_R g177(.A1(p23), .A2(new_n154_), .B(new_n235_), .Y(new_n236_));
  AOI21x1_ASAP7_75t_R g178(.A1(new_n154_), .A2(new_n234_), .B(new_n236_), .Y(new_n237_));
  OAI21x1_ASAP7_75t_R g179(.A1(new_n231_), .A2(new_n233_), .B(new_n237_), .Y(new_n238_));
  NAND3x1_ASAP7_75t_R g180(.A(new_n139_), .B(new_n138_), .C(new_n232_), .Y(new_n239_));
  OAI21x1_ASAP7_75t_R g181(.A1(new_n129_), .A2(new_n132_), .B(p22), .Y(new_n240_));
  AO21x1_ASAP7_75t_R  g182(.A1(new_n154_), .A2(new_n234_), .B(new_n236_), .Y(new_n241_));
  NAND3x1_ASAP7_75t_R g183(.A(new_n239_), .B(new_n240_), .C(new_n241_), .Y(new_n242_));
  XOR2x2_ASAP7_75t_R  g184(.A(p21), .B(p9), .Y(new_n243_));
  INVx1_ASAP7_75t_R   g185(.A(new_n243_), .Y(new_n244_));
  NAND3x1_ASAP7_75t_R g186(.A(new_n238_), .B(new_n242_), .C(new_n244_), .Y(new_n245_));
  OA21x2_ASAP7_75t_R  g187(.A1(p2), .A2(p32), .B(p11), .Y(new_n246_));
  XOR2x2_ASAP7_75t_R  g188(.A(p24), .B(p22), .Y(new_n247_));
  INVx1_ASAP7_75t_R   g189(.A(new_n154_), .Y(new_n248_));
  OR3x1_ASAP7_75t_R   g190(.A(new_n247_), .B(new_n184_), .C(new_n248_), .Y(new_n249_));
  NAND2x1_ASAP7_75t_R g191(.A(p23), .B(new_n154_), .Y(new_n250_));
  NAND2x1_ASAP7_75t_R g192(.A(new_n250_), .B(new_n247_), .Y(new_n251_));
  NAND3x1_ASAP7_75t_R g193(.A(new_n140_), .B(new_n249_), .C(new_n251_), .Y(new_n252_));
  NOR2x1_ASAP7_75t_R  g194(.A(new_n250_), .B(new_n247_), .Y(new_n253_));
  AND2x2_ASAP7_75t_R  g195(.A(new_n250_), .B(new_n247_), .Y(new_n254_));
  OAI21x1_ASAP7_75t_R g196(.A1(new_n253_), .A2(new_n254_), .B(new_n133_), .Y(new_n255_));
  NAND3x1_ASAP7_75t_R g197(.A(new_n252_), .B(new_n255_), .C(new_n243_), .Y(new_n256_));
  NAND3x1_ASAP7_75t_R g198(.A(new_n245_), .B(new_n246_), .C(new_n256_), .Y(new_n257_));
  AO21x1_ASAP7_75t_R  g199(.A1(new_n255_), .A2(new_n252_), .B(new_n244_), .Y(new_n258_));
  NAND3x1_ASAP7_75t_R g200(.A(new_n252_), .B(new_n255_), .C(new_n244_), .Y(new_n259_));
  NOR2x1_ASAP7_75t_R  g201(.A(p2), .B(new_n246_), .Y(new_n260_));
  NAND3x1_ASAP7_75t_R g202(.A(new_n258_), .B(new_n259_), .C(new_n260_), .Y(new_n261_));
  AND2x2_ASAP7_75t_R  g203(.A(p2), .B(p11), .Y(new_n262_));
  INVx1_ASAP7_75t_R   g204(.A(new_n262_), .Y(new_n263_));
  NAND3x1_ASAP7_75t_R g205(.A(new_n257_), .B(new_n261_), .C(new_n263_), .Y(new_n264_));
  AOI21x1_ASAP7_75t_R g206(.A1(new_n227_), .A2(new_n230_), .B(new_n264_), .Y(new_n265_));
  INVx1_ASAP7_75t_R   g207(.A(new_n265_), .Y(new_n266_));
  OR3x1_ASAP7_75t_R   g208(.A(new_n126_), .B(new_n216_), .C(new_n266_), .Y(new_n267_));
  AND3x1_ASAP7_75t_R  g209(.A(new_n125_), .B(new_n265_), .C(new_n215_), .Y(new_n268_));
  INVx1_ASAP7_75t_R   g210(.A(p14), .Y(new_n269_));
  AND3x1_ASAP7_75t_R  g211(.A(new_n268_), .B(new_n269_), .C(new_n183_), .Y(new_n270_));
  AOI21x1_ASAP7_75t_R g212(.A1(p14), .A2(new_n267_), .B(new_n270_), .Y(o0));
  OR3x1_ASAP7_75t_R   g213(.A(p2), .B(p31), .C(p1), .Y(new_n272_));
  AO21x1_ASAP7_75t_R  g214(.A1(new_n272_), .A2(new_n179_), .B(new_n180_), .Y(new_n273_));
  NOR3x1_ASAP7_75t_R  g215(.A(new_n174_), .B(new_n173_), .C(new_n273_), .Y(new_n274_));
  NAND2x1_ASAP7_75t_R g216(.A(new_n176_), .B(new_n149_), .Y(new_n275_));
  NAND3x1_ASAP7_75t_R g217(.A(new_n151_), .B(new_n274_), .C(new_n275_), .Y(new_n276_));
  AOI21x1_ASAP7_75t_R g218(.A1(new_n186_), .A2(new_n214_), .B(new_n276_), .Y(new_n277_));
  INVx1_ASAP7_75t_R   g219(.A(new_n120_), .Y(new_n278_));
  AO21x1_ASAP7_75t_R  g220(.A1(new_n124_), .A2(new_n119_), .B(new_n278_), .Y(new_n279_));
  NAND3x1_ASAP7_75t_R g221(.A(new_n277_), .B(new_n265_), .C(new_n279_), .Y(new_n280_));
  XOR2x2_ASAP7_75t_R  g222(.A(new_n280_), .B(p25), .Y(o1));
  XOR2x2_ASAP7_75t_R  g223(.A(new_n280_), .B(p19), .Y(o2));
  AND3x1_ASAP7_75t_R  g224(.A(new_n268_), .B(new_n235_), .C(new_n183_), .Y(new_n283_));
  AOI21x1_ASAP7_75t_R g225(.A1(p24), .A2(new_n267_), .B(new_n283_), .Y(o3));
  XOR2x2_ASAP7_75t_R  g226(.A(new_n280_), .B(p7), .Y(o4));
  XOR2x2_ASAP7_75t_R  g227(.A(new_n280_), .B(p22), .Y(o5));
  AOI21x1_ASAP7_75t_R g228(.A1(new_n124_), .A2(new_n119_), .B(new_n278_), .Y(new_n287_));
  NOR2x1_ASAP7_75t_R  g229(.A(new_n266_), .B(new_n287_), .Y(new_n288_));
  NAND3x1_ASAP7_75t_R g230(.A(new_n288_), .B(new_n183_), .C(new_n215_), .Y(new_n289_));
  XOR2x2_ASAP7_75t_R  g231(.A(new_n289_), .B(p9), .Y(o6));
  XOR2x2_ASAP7_75t_R  g232(.A(new_n289_), .B(p8), .Y(o7));
  XOR2x2_ASAP7_75t_R  g233(.A(new_n289_), .B(p15), .Y(o8));
  AND3x1_ASAP7_75t_R  g234(.A(new_n151_), .B(new_n274_), .C(new_n275_), .Y(new_n293_));
  NOR2x1_ASAP7_75t_R  g235(.A(new_n185_), .B(new_n214_), .Y(new_n294_));
  NAND3x1_ASAP7_75t_R g236(.A(new_n288_), .B(new_n293_), .C(new_n294_), .Y(new_n295_));
  AND3x1_ASAP7_75t_R  g237(.A(new_n279_), .B(new_n265_), .C(new_n294_), .Y(new_n296_));
  AND3x1_ASAP7_75t_R  g238(.A(new_n296_), .B(new_n74_), .C(new_n293_), .Y(new_n297_));
  AOI21x1_ASAP7_75t_R g239(.A1(p18), .A2(new_n295_), .B(new_n297_), .Y(o9));
  AND3x1_ASAP7_75t_R  g240(.A(new_n296_), .B(new_n72_), .C(new_n293_), .Y(new_n299_));
  AOI21x1_ASAP7_75t_R g241(.A1(p6), .A2(new_n295_), .B(new_n299_), .Y(o10));
  AND3x1_ASAP7_75t_R  g242(.A(new_n296_), .B(new_n79_), .C(new_n293_), .Y(new_n301_));
  AOI21x1_ASAP7_75t_R g243(.A1(p21), .A2(new_n295_), .B(new_n301_), .Y(o11));
  AND3x1_ASAP7_75t_R  g244(.A(new_n296_), .B(new_n141_), .C(new_n293_), .Y(new_n303_));
  AOI21x1_ASAP7_75t_R g245(.A1(p5), .A2(new_n295_), .B(new_n303_), .Y(o12));
  INVx1_ASAP7_75t_R   g246(.A(p13), .Y(new_n305_));
  AOI21x1_ASAP7_75t_R g247(.A1(new_n183_), .A2(new_n296_), .B(new_n305_), .Y(new_n306_));
  AND3x1_ASAP7_75t_R  g248(.A(new_n296_), .B(new_n305_), .C(new_n183_), .Y(new_n307_));
  NOR2x1_ASAP7_75t_R  g249(.A(new_n306_), .B(new_n307_), .Y(o13));
  INVx1_ASAP7_75t_R   g250(.A(p17), .Y(new_n309_));
  AND3x1_ASAP7_75t_R  g251(.A(new_n268_), .B(new_n309_), .C(new_n183_), .Y(new_n310_));
  AOI21x1_ASAP7_75t_R g252(.A1(p17), .A2(new_n267_), .B(new_n310_), .Y(o14));
  INVx1_ASAP7_75t_R   g253(.A(p10), .Y(new_n312_));
  AND3x1_ASAP7_75t_R  g254(.A(new_n268_), .B(new_n312_), .C(new_n183_), .Y(new_n313_));
  AOI21x1_ASAP7_75t_R g255(.A1(p10), .A2(new_n267_), .B(new_n313_), .Y(o15));
  AND2x2_ASAP7_75t_R  g256(.A(new_n181_), .B(new_n273_), .Y(new_n315_));
  AOI21x1_ASAP7_75t_R g257(.A1(new_n176_), .A2(new_n149_), .B(new_n315_), .Y(new_n316_));
  NAND3x1_ASAP7_75t_R g258(.A(new_n151_), .B(new_n175_), .C(new_n316_), .Y(new_n317_));
  AOI21x1_ASAP7_75t_R g259(.A1(new_n186_), .A2(new_n214_), .B(new_n317_), .Y(new_n318_));
  AND3x1_ASAP7_75t_R  g260(.A(new_n318_), .B(new_n265_), .C(new_n279_), .Y(new_n319_));
  NAND2x1_ASAP7_75t_R g261(.A(new_n124_), .B(new_n119_), .Y(new_n320_));
  INVx1_ASAP7_75t_R   g262(.A(new_n320_), .Y(new_n321_));
  AOI21x1_ASAP7_75t_R g263(.A1(new_n203_), .A2(new_n208_), .B(new_n213_), .Y(new_n322_));
  AND3x1_ASAP7_75t_R  g264(.A(new_n322_), .B(new_n278_), .C(new_n185_), .Y(new_n323_));
  AND3x1_ASAP7_75t_R  g265(.A(new_n151_), .B(new_n175_), .C(new_n275_), .Y(new_n324_));
  AND3x1_ASAP7_75t_R  g266(.A(new_n323_), .B(new_n324_), .C(new_n265_), .Y(new_n325_));
  AO21x1_ASAP7_75t_R  g267(.A1(new_n321_), .A2(new_n325_), .B(p1), .Y(new_n326_));
  AO21x1_ASAP7_75t_R  g268(.A1(p4), .A2(new_n319_), .B(new_n326_), .Y(o16));
  AND3x1_ASAP7_75t_R  g269(.A(new_n59_), .B(p26), .C(p0), .Y(new_n328_));
  NAND2x1_ASAP7_75t_R g270(.A(new_n121_), .B(new_n122_), .Y(new_n329_));
  AOI21x1_ASAP7_75t_R g271(.A1(new_n328_), .A2(new_n319_), .B(new_n329_), .Y(new_n330_));
  NOR2x1_ASAP7_75t_R  g272(.A(new_n62_), .B(new_n118_), .Y(new_n331_));
  INVx1_ASAP7_75t_R   g273(.A(new_n179_), .Y(new_n332_));
  AO21x1_ASAP7_75t_R  g274(.A1(new_n331_), .A2(new_n319_), .B(new_n332_), .Y(new_n333_));
  NOR2x1_ASAP7_75t_R  g275(.A(new_n330_), .B(new_n333_), .Y(o17));
  NOR2x1_ASAP7_75t_R  g276(.A(p2), .B(new_n207_), .Y(new_n335_));
  NAND2x1_ASAP7_75t_R g277(.A(new_n209_), .B(new_n210_), .Y(new_n336_));
  AOI21x1_ASAP7_75t_R g278(.A1(new_n335_), .A2(new_n319_), .B(new_n336_), .Y(new_n337_));
  AND2x2_ASAP7_75t_R  g279(.A(new_n335_), .B(new_n336_), .Y(new_n338_));
  AO21x1_ASAP7_75t_R  g280(.A1(new_n338_), .A2(new_n319_), .B(new_n332_), .Y(new_n339_));
  NOR2x1_ASAP7_75t_R  g281(.A(new_n337_), .B(new_n339_), .Y(o18));
  NAND2x1_ASAP7_75t_R g282(.A(p20), .B(new_n319_), .Y(new_n341_));
  AOI21x1_ASAP7_75t_R g283(.A1(new_n149_), .A2(new_n341_), .B(new_n332_), .Y(o19));
  NOR2x1_ASAP7_75t_R  g284(.A(new_n165_), .B(new_n169_), .Y(new_n343_));
  XOR2x2_ASAP7_75t_R  g285(.A(new_n160_), .B(new_n163_), .Y(new_n344_));
  NAND2x1_ASAP7_75t_R g286(.A(new_n343_), .B(new_n344_), .Y(new_n345_));
  OR2x4_ASAP7_75t_R   g287(.A(new_n343_), .B(new_n344_), .Y(new_n346_));
  AND2x2_ASAP7_75t_R  g288(.A(new_n345_), .B(new_n346_), .Y(new_n347_));
  AND3x1_ASAP7_75t_R  g289(.A(new_n288_), .B(p12), .C(new_n318_), .Y(new_n348_));
  OA21x2_ASAP7_75t_R  g290(.A1(new_n347_), .A2(new_n348_), .B(new_n179_), .Y(o20));
  NAND2x1_ASAP7_75t_R g291(.A(new_n259_), .B(new_n258_), .Y(new_n350_));
  AND3x1_ASAP7_75t_R  g292(.A(new_n288_), .B(new_n246_), .C(new_n318_), .Y(new_n351_));
  OA21x2_ASAP7_75t_R  g293(.A1(new_n350_), .A2(new_n351_), .B(new_n179_), .Y(o21));
  OAI21x1_ASAP7_75t_R g294(.A1(new_n185_), .A2(new_n322_), .B(new_n265_), .Y(new_n353_));
  AOI21x1_ASAP7_75t_R g295(.A1(new_n120_), .A2(new_n320_), .B(new_n353_), .Y(new_n354_));
  NOR2x1_ASAP7_75t_R  g296(.A(p31), .B(p1), .Y(new_n355_));
  AO21x1_ASAP7_75t_R  g297(.A1(new_n114_), .A2(new_n115_), .B(new_n355_), .Y(new_n356_));
  AOI21x1_ASAP7_75t_R g298(.A1(new_n293_), .A2(new_n354_), .B(new_n356_), .Y(new_n357_));
  NAND2x1_ASAP7_75t_R g299(.A(new_n109_), .B(new_n356_), .Y(new_n358_));
  AO21x1_ASAP7_75t_R  g300(.A1(p31), .A2(p30), .B(p1), .Y(new_n359_));
  INVx1_ASAP7_75t_R   g301(.A(new_n359_), .Y(new_n360_));
  OAI21x1_ASAP7_75t_R g302(.A1(new_n358_), .A2(new_n280_), .B(new_n360_), .Y(new_n361_));
  NAND2x1_ASAP7_75t_R g303(.A(new_n356_), .B(new_n293_), .Y(new_n362_));
  NOR3x1_ASAP7_75t_R  g304(.A(new_n362_), .B(new_n353_), .C(new_n287_), .Y(new_n363_));
  OAI21x1_ASAP7_75t_R g305(.A1(new_n363_), .A2(new_n357_), .B(new_n359_), .Y(new_n364_));
  OAI21x1_ASAP7_75t_R g306(.A1(new_n357_), .A2(new_n361_), .B(new_n364_), .Y(o22));
  NOR2x1_ASAP7_75t_R  g307(.A(new_n137_), .B(new_n128_), .Y(new_n366_));
  XOR2x2_ASAP7_75t_R  g308(.A(new_n204_), .B(new_n366_), .Y(new_n367_));
  NOR2x1_ASAP7_75t_R  g309(.A(p28), .B(p1), .Y(new_n368_));
  XOR2x2_ASAP7_75t_R  g310(.A(new_n367_), .B(new_n368_), .Y(new_n369_));
  OA21x2_ASAP7_75t_R  g311(.A1(p1), .A2(p3), .B(new_n369_), .Y(new_n370_));
  XOR2x2_ASAP7_75t_R  g312(.A(new_n289_), .B(new_n370_), .Y(o23));
  NAND2x1_ASAP7_75t_R g313(.A(new_n226_), .B(new_n319_), .Y(new_n372_));
  AND2x2_ASAP7_75t_R  g314(.A(new_n224_), .B(new_n222_), .Y(new_n373_));
  AND3x1_ASAP7_75t_R  g315(.A(new_n372_), .B(new_n179_), .C(new_n373_), .Y(o24));
endmodule


