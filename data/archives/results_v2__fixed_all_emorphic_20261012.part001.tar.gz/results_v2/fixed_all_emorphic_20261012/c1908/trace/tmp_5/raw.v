// Benchmark "/tmp/" written by ABC on Mon Oct 12 15:05:18 2026

module \/tmp/  ( 
    p24, p6, p21, p20, p1, p4, p31, p25, p12, p23, p7, p27, p2, p10, p18,
    p8, p29, p16, p11, p5, p32, p22, p19, p17, p15, p3, p28, p0, p26, p13,
    p9, p30, p14,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24  );
  input  p24, p6, p21, p20, p1, p4, p31, p25, p12, p23, p7, p27, p2, p10,
    p18, p8, p29, p16, p11, p5, p32, p22, p19, p17, p15, p3, p28, p0, p26,
    p13, p9, p30, p14;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24;
  wire new_n59_, new_n60_, new_n61_, new_n62_, new_n63_, new_n64_, new_n65_,
    new_n66_, new_n67_, new_n68_, new_n69_, new_n70_, new_n71_, new_n72_,
    new_n73_, new_n74_, new_n75_, new_n76_, new_n77_, new_n78_, new_n79_,
    new_n80_, new_n81_, new_n82_, new_n83_, new_n84_, new_n85_, new_n86_,
    new_n87_, new_n88_, new_n89_, new_n90_, new_n91_, new_n92_, new_n93_,
    new_n94_, new_n95_, new_n96_, new_n97_, new_n98_, new_n99_, new_n100_,
    new_n101_, new_n102_, new_n103_, new_n104_, new_n105_, new_n106_,
    new_n107_, new_n108_, new_n109_, new_n110_, new_n111_, new_n112_,
    new_n113_, new_n114_, new_n115_, new_n116_, new_n117_, new_n118_,
    new_n119_, new_n120_, new_n121_, new_n122_, new_n123_, new_n124_,
    new_n125_, new_n126_, new_n127_, new_n128_, new_n129_, new_n130_,
    new_n131_, new_n132_, new_n133_, new_n134_, new_n135_, new_n136_,
    new_n137_, new_n138_, new_n139_, new_n140_, new_n141_, new_n142_,
    new_n143_, new_n144_, new_n145_, new_n146_, new_n147_, new_n148_,
    new_n149_, new_n150_, new_n151_, new_n152_, new_n153_, new_n154_,
    new_n155_, new_n156_, new_n157_, new_n158_, new_n159_, new_n160_,
    new_n161_, new_n162_, new_n163_, new_n164_, new_n165_, new_n166_,
    new_n167_, new_n168_, new_n169_, new_n170_, new_n171_, new_n172_,
    new_n173_, new_n174_, new_n175_, new_n176_, new_n177_, new_n178_,
    new_n179_, new_n180_, new_n181_, new_n182_, new_n183_, new_n184_,
    new_n185_, new_n186_, new_n187_, new_n188_, new_n189_, new_n190_,
    new_n191_, new_n192_, new_n193_, new_n194_, new_n195_, new_n196_,
    new_n197_, new_n198_, new_n199_, new_n200_, new_n201_, new_n202_,
    new_n203_, new_n204_, new_n205_, new_n206_, new_n207_, new_n208_,
    new_n209_, new_n210_, new_n211_, new_n212_, new_n213_, new_n214_,
    new_n215_, new_n216_, new_n217_, new_n218_, new_n219_, new_n220_,
    new_n221_, new_n222_, new_n223_, new_n224_, new_n225_, new_n226_,
    new_n227_, new_n228_, new_n229_, new_n230_, new_n231_, new_n232_,
    new_n233_, new_n234_, new_n235_, new_n236_, new_n237_, new_n238_,
    new_n239_, new_n240_, new_n241_, new_n242_, new_n243_, new_n244_,
    new_n245_, new_n246_, new_n247_, new_n248_, new_n249_, new_n250_,
    new_n251_, new_n252_, new_n253_, new_n254_, new_n255_, new_n256_,
    new_n257_, new_n259_, new_n260_, new_n261_, new_n262_, new_n263_,
    new_n264_, new_n265_, new_n266_, new_n269_, new_n270_, new_n274_,
    new_n278_, new_n279_, new_n280_, new_n281_, new_n286_, new_n287_,
    new_n288_, new_n290_, new_n291_, new_n293_, new_n294_, new_n296_,
    new_n297_, new_n298_, new_n299_, new_n300_, new_n301_, new_n302_,
    new_n303_, new_n304_, new_n305_, new_n307_, new_n308_, new_n309_,
    new_n310_, new_n311_, new_n312_, new_n314_, new_n315_, new_n316_,
    new_n317_, new_n318_, new_n320_, new_n322_, new_n324_, new_n325_,
    new_n327_, new_n328_, new_n329_, new_n330_, new_n331_, new_n332_,
    new_n333_, new_n334_, new_n335_, new_n336_, new_n337_, new_n338_,
    new_n339_, new_n340_, new_n341_, new_n343_, new_n344_, new_n345_,
    new_n346_, new_n347_, new_n349_, new_n350_;
  INVx1_ASAP7_75t_R   g000(.A(p2), .Y(new_n59_));
  INVx1_ASAP7_75t_R   g001(.A(p32), .Y(new_n60_));
  INVx1_ASAP7_75t_R   g002(.A(p23), .Y(new_n61_));
  AO21x1_ASAP7_75t_R  g003(.A1(new_n59_), .A2(new_n60_), .B(new_n61_), .Y(new_n62_));
  INVx1_ASAP7_75t_R   g004(.A(new_n62_), .Y(new_n63_));
  INVx1_ASAP7_75t_R   g005(.A(p19), .Y(new_n64_));
  NOR2x1_ASAP7_75t_R  g006(.A(p7), .B(new_n64_), .Y(new_n65_));
  INVx1_ASAP7_75t_R   g007(.A(p7), .Y(new_n66_));
  NOR2x1_ASAP7_75t_R  g008(.A(p19), .B(new_n66_), .Y(new_n67_));
  OAI21x1_ASAP7_75t_R g009(.A1(new_n65_), .A2(new_n67_), .B(p25), .Y(new_n68_));
  NAND2x1_ASAP7_75t_R g010(.A(p19), .B(new_n66_), .Y(new_n69_));
  NAND2x1_ASAP7_75t_R g011(.A(p7), .B(new_n64_), .Y(new_n70_));
  INVx1_ASAP7_75t_R   g012(.A(p25), .Y(new_n71_));
  NAND3x1_ASAP7_75t_R g013(.A(new_n69_), .B(new_n70_), .C(new_n71_), .Y(new_n72_));
  NAND2x1_ASAP7_75t_R g014(.A(new_n68_), .B(new_n72_), .Y(new_n73_));
  XOR2x2_ASAP7_75t_R  g015(.A(p22), .B(p14), .Y(new_n74_));
  INVx1_ASAP7_75t_R   g016(.A(p1), .Y(new_n75_));
  NAND2x1_ASAP7_75t_R g017(.A(p28), .B(new_n75_), .Y(new_n76_));
  XOR2x2_ASAP7_75t_R  g018(.A(new_n74_), .B(new_n76_), .Y(new_n77_));
  NAND2x1_ASAP7_75t_R g019(.A(new_n73_), .B(new_n77_), .Y(new_n78_));
  AO21x1_ASAP7_75t_R  g020(.A1(p19), .A2(new_n66_), .B(new_n71_), .Y(new_n79_));
  OAI21x1_ASAP7_75t_R g021(.A1(new_n65_), .A2(new_n67_), .B(new_n71_), .Y(new_n80_));
  OAI21x1_ASAP7_75t_R g022(.A1(new_n67_), .A2(new_n79_), .B(new_n80_), .Y(new_n81_));
  INVx1_ASAP7_75t_R   g023(.A(p28), .Y(new_n82_));
  NOR2x1_ASAP7_75t_R  g024(.A(p1), .B(new_n82_), .Y(new_n83_));
  XOR2x2_ASAP7_75t_R  g025(.A(new_n74_), .B(new_n83_), .Y(new_n84_));
  NAND2x1_ASAP7_75t_R g026(.A(new_n81_), .B(new_n84_), .Y(new_n85_));
  NAND2x1_ASAP7_75t_R g027(.A(new_n78_), .B(new_n85_), .Y(new_n86_));
  NOR2x1_ASAP7_75t_R  g028(.A(p8), .B(p9), .Y(new_n87_));
  AND2x2_ASAP7_75t_R  g029(.A(p8), .B(p9), .Y(new_n88_));
  OAI21x1_ASAP7_75t_R g030(.A1(new_n87_), .A2(new_n88_), .B(p15), .Y(new_n89_));
  OR3x1_ASAP7_75t_R   g031(.A(new_n88_), .B(p15), .C(new_n87_), .Y(new_n90_));
  NAND2x1_ASAP7_75t_R g032(.A(new_n89_), .B(new_n90_), .Y(new_n91_));
  NOR2x1_ASAP7_75t_R  g033(.A(p24), .B(p10), .Y(new_n92_));
  AND2x2_ASAP7_75t_R  g034(.A(p24), .B(p10), .Y(new_n93_));
  OAI21x1_ASAP7_75t_R g035(.A1(new_n92_), .A2(new_n93_), .B(p17), .Y(new_n94_));
  OR3x1_ASAP7_75t_R   g036(.A(new_n93_), .B(p17), .C(new_n92_), .Y(new_n95_));
  NAND2x1_ASAP7_75t_R g037(.A(new_n94_), .B(new_n95_), .Y(new_n96_));
  XOR2x2_ASAP7_75t_R  g038(.A(new_n91_), .B(new_n96_), .Y(new_n97_));
  OR3x1_ASAP7_75t_R   g039(.A(new_n86_), .B(p2), .C(new_n97_), .Y(new_n98_));
  INVx1_ASAP7_75t_R   g040(.A(p15), .Y(new_n99_));
  OAI21x1_ASAP7_75t_R g041(.A1(new_n87_), .A2(new_n88_), .B(new_n99_), .Y(new_n100_));
  OR3x1_ASAP7_75t_R   g042(.A(new_n88_), .B(new_n99_), .C(new_n87_), .Y(new_n101_));
  NAND2x1_ASAP7_75t_R g043(.A(new_n100_), .B(new_n101_), .Y(new_n102_));
  XOR2x2_ASAP7_75t_R  g044(.A(new_n102_), .B(new_n96_), .Y(new_n103_));
  AOI21x1_ASAP7_75t_R g045(.A1(new_n78_), .A2(new_n85_), .B(new_n103_), .Y(new_n104_));
  INVx1_ASAP7_75t_R   g046(.A(p29), .Y(new_n105_));
  AOI21x1_ASAP7_75t_R g047(.A1(new_n59_), .A2(new_n104_), .B(new_n105_), .Y(new_n106_));
  NAND3x1_ASAP7_75t_R g048(.A(new_n103_), .B(new_n78_), .C(new_n85_), .Y(new_n107_));
  NAND2x1_ASAP7_75t_R g049(.A(new_n97_), .B(new_n86_), .Y(new_n108_));
  NAND2x1_ASAP7_75t_R g050(.A(new_n59_), .B(new_n105_), .Y(new_n109_));
  AOI21x1_ASAP7_75t_R g051(.A1(new_n107_), .A2(new_n108_), .B(new_n109_), .Y(new_n110_));
  AOI21x1_ASAP7_75t_R g052(.A1(new_n98_), .A2(new_n106_), .B(new_n110_), .Y(new_n111_));
  INVx1_ASAP7_75t_R   g053(.A(new_n111_), .Y(new_n112_));
  NOR2x1_ASAP7_75t_R  g054(.A(p13), .B(p14), .Y(new_n113_));
  AND2x2_ASAP7_75t_R  g055(.A(p13), .B(p14), .Y(new_n114_));
  OAI21x1_ASAP7_75t_R g056(.A1(new_n113_), .A2(new_n114_), .B(new_n99_), .Y(new_n115_));
  OAI21x1_ASAP7_75t_R g057(.A1(p13), .A2(p14), .B(p15), .Y(new_n116_));
  AO21x1_ASAP7_75t_R  g058(.A1(p13), .A2(p14), .B(new_n116_), .Y(new_n117_));
  NOR2x1_ASAP7_75t_R  g059(.A(p1), .B(p0), .Y(new_n118_));
  NAND2x1_ASAP7_75t_R g060(.A(p16), .B(new_n118_), .Y(new_n119_));
  XOR2x2_ASAP7_75t_R  g061(.A(new_n119_), .B(p18), .Y(new_n120_));
  AO21x1_ASAP7_75t_R  g062(.A1(new_n115_), .A2(new_n117_), .B(new_n120_), .Y(new_n121_));
  XOR2x2_ASAP7_75t_R  g063(.A(p19), .B(p17), .Y(new_n122_));
  XOR2x2_ASAP7_75t_R  g064(.A(p8), .B(p5), .Y(new_n123_));
  XOR2x2_ASAP7_75t_R  g065(.A(new_n122_), .B(new_n123_), .Y(new_n124_));
  NOR2x1_ASAP7_75t_R  g066(.A(new_n116_), .B(new_n114_), .Y(new_n125_));
  NAND2x1_ASAP7_75t_R g067(.A(p13), .B(p14), .Y(new_n126_));
  OR3x1_ASAP7_75t_R   g068(.A(p15), .B(p13), .C(p14), .Y(new_n127_));
  OAI21x1_ASAP7_75t_R g069(.A1(p15), .A2(new_n126_), .B(new_n127_), .Y(new_n128_));
  NOR2x1_ASAP7_75t_R  g070(.A(new_n125_), .B(new_n128_), .Y(new_n129_));
  NAND2x1_ASAP7_75t_R g071(.A(new_n129_), .B(new_n120_), .Y(new_n130_));
  NAND3x1_ASAP7_75t_R g072(.A(new_n121_), .B(new_n124_), .C(new_n130_), .Y(new_n131_));
  AO21x1_ASAP7_75t_R  g073(.A1(new_n130_), .A2(new_n121_), .B(new_n124_), .Y(new_n132_));
  NAND2x1_ASAP7_75t_R g074(.A(new_n131_), .B(new_n132_), .Y(new_n133_));
  INVx1_ASAP7_75t_R   g075(.A(p20), .Y(new_n134_));
  AO21x1_ASAP7_75t_R  g076(.A1(new_n59_), .A2(new_n133_), .B(new_n134_), .Y(new_n135_));
  INVx1_ASAP7_75t_R   g077(.A(p12), .Y(new_n136_));
  NAND2x1_ASAP7_75t_R g078(.A(new_n136_), .B(new_n59_), .Y(new_n137_));
  NOR2x1_ASAP7_75t_R  g079(.A(new_n87_), .B(new_n88_), .Y(new_n138_));
  NOR2x1_ASAP7_75t_R  g080(.A(p1), .B(p32), .Y(new_n139_));
  NAND2x1_ASAP7_75t_R g081(.A(p11), .B(new_n139_), .Y(new_n140_));
  XOR2x2_ASAP7_75t_R  g082(.A(new_n138_), .B(new_n140_), .Y(new_n141_));
  XOR2x2_ASAP7_75t_R  g083(.A(p7), .B(p10), .Y(new_n142_));
  XOR2x2_ASAP7_75t_R  g084(.A(p6), .B(p5), .Y(new_n143_));
  XOR2x2_ASAP7_75t_R  g085(.A(new_n142_), .B(new_n143_), .Y(new_n144_));
  XOR2x2_ASAP7_75t_R  g086(.A(new_n141_), .B(new_n144_), .Y(new_n145_));
  NOR2x1_ASAP7_75t_R  g087(.A(new_n137_), .B(new_n145_), .Y(new_n146_));
  OA21x2_ASAP7_75t_R  g088(.A1(p2), .A2(new_n145_), .B(p12), .Y(new_n147_));
  NOR2x1_ASAP7_75t_R  g089(.A(new_n146_), .B(new_n147_), .Y(new_n148_));
  NOR2x1_ASAP7_75t_R  g090(.A(p20), .B(p2), .Y(new_n149_));
  OR3x1_ASAP7_75t_R   g091(.A(p1), .B(p2), .C(p3), .Y(new_n150_));
  NOR2x1_ASAP7_75t_R  g092(.A(p1), .B(p4), .Y(new_n151_));
  INVx1_ASAP7_75t_R   g093(.A(new_n151_), .Y(new_n152_));
  INVx1_ASAP7_75t_R   g094(.A(p0), .Y(new_n153_));
  NOR2x1_ASAP7_75t_R  g095(.A(p32), .B(new_n153_), .Y(new_n154_));
  AO21x1_ASAP7_75t_R  g096(.A1(new_n150_), .A2(new_n152_), .B(new_n154_), .Y(new_n155_));
  AOI21x1_ASAP7_75t_R g097(.A1(new_n149_), .A2(new_n133_), .B(new_n155_), .Y(new_n156_));
  NAND3x1_ASAP7_75t_R g098(.A(new_n135_), .B(new_n148_), .C(new_n156_), .Y(new_n157_));
  AO21x1_ASAP7_75t_R  g099(.A1(new_n63_), .A2(new_n112_), .B(new_n157_), .Y(new_n158_));
  INVx1_ASAP7_75t_R   g100(.A(p18), .Y(new_n159_));
  NOR2x1_ASAP7_75t_R  g101(.A(p21), .B(new_n159_), .Y(new_n160_));
  INVx1_ASAP7_75t_R   g102(.A(p21), .Y(new_n161_));
  NOR2x1_ASAP7_75t_R  g103(.A(p18), .B(new_n161_), .Y(new_n162_));
  OAI21x1_ASAP7_75t_R g104(.A1(new_n160_), .A2(new_n162_), .B(p6), .Y(new_n163_));
  NAND2x1_ASAP7_75t_R g105(.A(p18), .B(new_n161_), .Y(new_n164_));
  NAND2x1_ASAP7_75t_R g106(.A(p21), .B(new_n159_), .Y(new_n165_));
  INVx1_ASAP7_75t_R   g107(.A(p6), .Y(new_n166_));
  NAND3x1_ASAP7_75t_R g108(.A(new_n164_), .B(new_n165_), .C(new_n166_), .Y(new_n167_));
  NAND2x1_ASAP7_75t_R g109(.A(new_n163_), .B(new_n167_), .Y(new_n168_));
  NAND2x1_ASAP7_75t_R g110(.A(new_n81_), .B(new_n168_), .Y(new_n169_));
  XOR2x2_ASAP7_75t_R  g111(.A(p7), .B(p19), .Y(new_n170_));
  AND2x2_ASAP7_75t_R  g112(.A(p25), .B(new_n170_), .Y(new_n171_));
  NOR2x1_ASAP7_75t_R  g113(.A(p25), .B(new_n170_), .Y(new_n172_));
  NOR2x1_ASAP7_75t_R  g114(.A(p6), .B(new_n161_), .Y(new_n173_));
  AO21x1_ASAP7_75t_R  g115(.A1(p6), .A2(new_n161_), .B(new_n159_), .Y(new_n174_));
  NOR2x1_ASAP7_75t_R  g116(.A(p21), .B(new_n166_), .Y(new_n175_));
  OAI21x1_ASAP7_75t_R g117(.A1(new_n173_), .A2(new_n175_), .B(new_n159_), .Y(new_n176_));
  OAI21x1_ASAP7_75t_R g118(.A1(new_n173_), .A2(new_n174_), .B(new_n176_), .Y(new_n177_));
  OAI21x1_ASAP7_75t_R g119(.A1(new_n171_), .A2(new_n172_), .B(new_n177_), .Y(new_n178_));
  XNOR2x2_ASAP7_75t_R g120(.A(p5), .B(p22), .Y(new_n179_));
  NAND3x1_ASAP7_75t_R g121(.A(new_n169_), .B(new_n178_), .C(new_n179_), .Y(new_n180_));
  NOR2x1_ASAP7_75t_R  g122(.A(new_n177_), .B(new_n73_), .Y(new_n181_));
  NOR2x1_ASAP7_75t_R  g123(.A(new_n81_), .B(new_n168_), .Y(new_n182_));
  INVx1_ASAP7_75t_R   g124(.A(new_n179_), .Y(new_n183_));
  OAI21x1_ASAP7_75t_R g125(.A1(new_n181_), .A2(new_n182_), .B(new_n183_), .Y(new_n184_));
  NAND2x1_ASAP7_75t_R g126(.A(p30), .B(new_n75_), .Y(new_n185_));
  XOR2x2_ASAP7_75t_R  g127(.A(new_n185_), .B(p13), .Y(new_n186_));
  XOR2x2_ASAP7_75t_R  g128(.A(new_n102_), .B(new_n186_), .Y(new_n187_));
  AOI21x1_ASAP7_75t_R g129(.A1(new_n180_), .A2(new_n184_), .B(new_n187_), .Y(new_n188_));
  NAND3x1_ASAP7_75t_R g130(.A(new_n169_), .B(new_n178_), .C(new_n183_), .Y(new_n189_));
  OAI21x1_ASAP7_75t_R g131(.A1(new_n181_), .A2(new_n182_), .B(new_n179_), .Y(new_n190_));
  XOR2x2_ASAP7_75t_R  g132(.A(new_n91_), .B(new_n186_), .Y(new_n191_));
  AOI21x1_ASAP7_75t_R g133(.A1(new_n189_), .A2(new_n190_), .B(new_n191_), .Y(new_n192_));
  INVx1_ASAP7_75t_R   g134(.A(p26), .Y(new_n193_));
  OA21x2_ASAP7_75t_R  g135(.A1(new_n153_), .A2(new_n193_), .B(new_n59_), .Y(new_n194_));
  OAI21x1_ASAP7_75t_R g136(.A1(new_n188_), .A2(new_n192_), .B(new_n194_), .Y(new_n195_));
  AO21x1_ASAP7_75t_R  g137(.A1(new_n59_), .A2(new_n153_), .B(new_n193_), .Y(new_n196_));
  INVx1_ASAP7_75t_R   g138(.A(new_n196_), .Y(new_n197_));
  OAI21x1_ASAP7_75t_R g139(.A1(new_n188_), .A2(new_n192_), .B(new_n59_), .Y(new_n198_));
  NAND2x1_ASAP7_75t_R g140(.A(new_n197_), .B(new_n198_), .Y(new_n199_));
  NAND2x1_ASAP7_75t_R g141(.A(new_n195_), .B(new_n199_), .Y(new_n200_));
  NAND3x1_ASAP7_75t_R g142(.A(new_n118_), .B(new_n71_), .C(p26), .Y(new_n201_));
  AO21x1_ASAP7_75t_R  g143(.A1(p26), .A2(new_n118_), .B(new_n71_), .Y(new_n202_));
  AND2x2_ASAP7_75t_R  g144(.A(new_n201_), .B(new_n202_), .Y(new_n203_));
  XOR2x2_ASAP7_75t_R  g145(.A(new_n168_), .B(new_n203_), .Y(new_n204_));
  NAND2x1_ASAP7_75t_R g146(.A(new_n103_), .B(new_n204_), .Y(new_n205_));
  XOR2x2_ASAP7_75t_R  g147(.A(new_n177_), .B(new_n203_), .Y(new_n206_));
  NAND2x1_ASAP7_75t_R g148(.A(new_n97_), .B(new_n206_), .Y(new_n207_));
  INVx1_ASAP7_75t_R   g149(.A(p27), .Y(new_n208_));
  NOR2x1_ASAP7_75t_R  g150(.A(p2), .B(new_n208_), .Y(new_n209_));
  NAND3x1_ASAP7_75t_R g151(.A(new_n205_), .B(new_n207_), .C(new_n209_), .Y(new_n210_));
  NAND3x1_ASAP7_75t_R g152(.A(new_n204_), .B(new_n97_), .C(new_n59_), .Y(new_n211_));
  NAND3x1_ASAP7_75t_R g153(.A(new_n206_), .B(new_n103_), .C(new_n59_), .Y(new_n212_));
  NAND3x1_ASAP7_75t_R g154(.A(new_n211_), .B(new_n212_), .C(new_n208_), .Y(new_n213_));
  NOR3x1_ASAP7_75t_R  g155(.A(new_n128_), .B(p22), .C(new_n125_), .Y(new_n214_));
  INVx1_ASAP7_75t_R   g156(.A(p22), .Y(new_n215_));
  AOI21x1_ASAP7_75t_R g157(.A1(new_n115_), .A2(new_n117_), .B(new_n215_), .Y(new_n216_));
  NOR2x1_ASAP7_75t_R  g158(.A(p24), .B(new_n61_), .Y(new_n217_));
  INVx1_ASAP7_75t_R   g159(.A(p24), .Y(new_n218_));
  AOI21x1_ASAP7_75t_R g160(.A1(p23), .A2(new_n139_), .B(new_n218_), .Y(new_n219_));
  AOI21x1_ASAP7_75t_R g161(.A1(new_n139_), .A2(new_n217_), .B(new_n219_), .Y(new_n220_));
  OAI21x1_ASAP7_75t_R g162(.A1(new_n214_), .A2(new_n216_), .B(new_n220_), .Y(new_n221_));
  NAND3x1_ASAP7_75t_R g163(.A(new_n117_), .B(new_n115_), .C(new_n215_), .Y(new_n222_));
  OAI21x1_ASAP7_75t_R g164(.A1(new_n125_), .A2(new_n128_), .B(p22), .Y(new_n223_));
  AO21x1_ASAP7_75t_R  g165(.A1(new_n139_), .A2(new_n217_), .B(new_n219_), .Y(new_n224_));
  NAND3x1_ASAP7_75t_R g166(.A(new_n222_), .B(new_n223_), .C(new_n224_), .Y(new_n225_));
  XNOR2x2_ASAP7_75t_R g167(.A(p21), .B(p9), .Y(new_n226_));
  NAND3x1_ASAP7_75t_R g168(.A(new_n221_), .B(new_n225_), .C(new_n226_), .Y(new_n227_));
  OA21x2_ASAP7_75t_R  g169(.A1(p2), .A2(p32), .B(p11), .Y(new_n228_));
  XOR2x2_ASAP7_75t_R  g170(.A(p24), .B(p22), .Y(new_n229_));
  INVx1_ASAP7_75t_R   g171(.A(new_n139_), .Y(new_n230_));
  OR3x1_ASAP7_75t_R   g172(.A(new_n229_), .B(new_n61_), .C(new_n230_), .Y(new_n231_));
  XNOR2x2_ASAP7_75t_R g173(.A(p24), .B(p22), .Y(new_n232_));
  AO21x1_ASAP7_75t_R  g174(.A1(p23), .A2(new_n139_), .B(new_n232_), .Y(new_n233_));
  AOI21x1_ASAP7_75t_R g175(.A1(new_n231_), .A2(new_n233_), .B(new_n129_), .Y(new_n234_));
  NAND2x1_ASAP7_75t_R g176(.A(new_n115_), .B(new_n117_), .Y(new_n235_));
  AND3x1_ASAP7_75t_R  g177(.A(new_n232_), .B(p23), .C(new_n139_), .Y(new_n236_));
  OA21x2_ASAP7_75t_R  g178(.A1(new_n61_), .A2(new_n230_), .B(new_n229_), .Y(new_n237_));
  NOR3x1_ASAP7_75t_R  g179(.A(new_n235_), .B(new_n236_), .C(new_n237_), .Y(new_n238_));
  INVx1_ASAP7_75t_R   g180(.A(new_n226_), .Y(new_n239_));
  OAI21x1_ASAP7_75t_R g181(.A1(new_n234_), .A2(new_n238_), .B(new_n239_), .Y(new_n240_));
  NAND3x1_ASAP7_75t_R g182(.A(new_n227_), .B(new_n228_), .C(new_n240_), .Y(new_n241_));
  OAI21x1_ASAP7_75t_R g183(.A1(new_n234_), .A2(new_n238_), .B(new_n226_), .Y(new_n242_));
  NAND3x1_ASAP7_75t_R g184(.A(new_n233_), .B(new_n129_), .C(new_n231_), .Y(new_n243_));
  OAI21x1_ASAP7_75t_R g185(.A1(new_n237_), .A2(new_n236_), .B(new_n235_), .Y(new_n244_));
  NAND3x1_ASAP7_75t_R g186(.A(new_n243_), .B(new_n244_), .C(new_n239_), .Y(new_n245_));
  NOR2x1_ASAP7_75t_R  g187(.A(p2), .B(new_n228_), .Y(new_n246_));
  NAND3x1_ASAP7_75t_R g188(.A(new_n242_), .B(new_n245_), .C(new_n246_), .Y(new_n247_));
  AND2x2_ASAP7_75t_R  g189(.A(p2), .B(p11), .Y(new_n248_));
  INVx1_ASAP7_75t_R   g190(.A(new_n248_), .Y(new_n249_));
  NAND3x1_ASAP7_75t_R g191(.A(new_n241_), .B(new_n247_), .C(new_n249_), .Y(new_n250_));
  AOI21x1_ASAP7_75t_R g192(.A1(new_n210_), .A2(new_n213_), .B(new_n250_), .Y(new_n251_));
  INVx1_ASAP7_75t_R   g193(.A(new_n251_), .Y(new_n252_));
  OA21x2_ASAP7_75t_R  g194(.A1(p2), .A2(p0), .B(p16), .Y(new_n253_));
  INVx1_ASAP7_75t_R   g195(.A(new_n253_), .Y(new_n254_));
  OR3x1_ASAP7_75t_R   g196(.A(new_n200_), .B(new_n252_), .C(new_n254_), .Y(new_n255_));
  OAI21x1_ASAP7_75t_R g197(.A1(new_n158_), .A2(new_n255_), .B(p14), .Y(new_n256_));
  OR3x1_ASAP7_75t_R   g198(.A(new_n255_), .B(p14), .C(new_n158_), .Y(new_n257_));
  AND2x2_ASAP7_75t_R  g199(.A(new_n256_), .B(new_n257_), .Y(o0));
  AOI21x1_ASAP7_75t_R g200(.A1(new_n195_), .A2(new_n199_), .B(new_n254_), .Y(new_n259_));
  OAI21x1_ASAP7_75t_R g201(.A1(new_n62_), .A2(new_n111_), .B(new_n251_), .Y(new_n260_));
  OR3x1_ASAP7_75t_R   g202(.A(p1), .B(p31), .C(p2), .Y(new_n261_));
  AO21x1_ASAP7_75t_R  g203(.A1(new_n261_), .A2(new_n152_), .B(new_n154_), .Y(new_n262_));
  NOR3x1_ASAP7_75t_R  g204(.A(new_n147_), .B(new_n146_), .C(new_n262_), .Y(new_n263_));
  NAND2x1_ASAP7_75t_R g205(.A(new_n149_), .B(new_n133_), .Y(new_n264_));
  NAND3x1_ASAP7_75t_R g206(.A(new_n135_), .B(new_n263_), .C(new_n264_), .Y(new_n265_));
  NOR3x1_ASAP7_75t_R  g207(.A(new_n259_), .B(new_n260_), .C(new_n265_), .Y(new_n266_));
  XOR2x2_ASAP7_75t_R  g208(.A(new_n266_), .B(new_n71_), .Y(o1));
  XOR2x2_ASAP7_75t_R  g209(.A(new_n266_), .B(new_n64_), .Y(o2));
  OAI21x1_ASAP7_75t_R g210(.A1(new_n158_), .A2(new_n255_), .B(new_n218_), .Y(new_n269_));
  OR3x1_ASAP7_75t_R   g211(.A(new_n255_), .B(new_n218_), .C(new_n158_), .Y(new_n270_));
  NAND2x1_ASAP7_75t_R g212(.A(new_n269_), .B(new_n270_), .Y(o3));
  XOR2x2_ASAP7_75t_R  g213(.A(new_n266_), .B(new_n66_), .Y(o4));
  XOR2x2_ASAP7_75t_R  g214(.A(new_n266_), .B(new_n215_), .Y(o5));
  OR3x1_ASAP7_75t_R   g215(.A(new_n259_), .B(new_n260_), .C(new_n157_), .Y(new_n274_));
  XOR2x2_ASAP7_75t_R  g216(.A(new_n274_), .B(p9), .Y(o6));
  XOR2x2_ASAP7_75t_R  g217(.A(new_n274_), .B(p8), .Y(o7));
  XOR2x2_ASAP7_75t_R  g218(.A(new_n274_), .B(p15), .Y(o8));
  NAND2x1_ASAP7_75t_R g219(.A(new_n63_), .B(new_n111_), .Y(new_n278_));
  NOR2x1_ASAP7_75t_R  g220(.A(new_n278_), .B(new_n265_), .Y(new_n279_));
  AO21x1_ASAP7_75t_R  g221(.A1(new_n195_), .A2(new_n199_), .B(new_n254_), .Y(new_n280_));
  NAND3x1_ASAP7_75t_R g222(.A(new_n279_), .B(new_n251_), .C(new_n280_), .Y(new_n281_));
  XOR2x2_ASAP7_75t_R  g223(.A(new_n281_), .B(p18), .Y(o9));
  XOR2x2_ASAP7_75t_R  g224(.A(new_n281_), .B(p6), .Y(o10));
  XOR2x2_ASAP7_75t_R  g225(.A(new_n281_), .B(p21), .Y(o11));
  XOR2x2_ASAP7_75t_R  g226(.A(new_n281_), .B(p5), .Y(o12));
  NOR2x1_ASAP7_75t_R  g227(.A(new_n278_), .B(new_n157_), .Y(new_n286_));
  AND3x1_ASAP7_75t_R  g228(.A(new_n286_), .B(new_n251_), .C(new_n280_), .Y(new_n287_));
  INVx1_ASAP7_75t_R   g229(.A(p13), .Y(new_n288_));
  XOR2x2_ASAP7_75t_R  g230(.A(new_n287_), .B(new_n288_), .Y(o13));
  OAI21x1_ASAP7_75t_R g231(.A1(new_n158_), .A2(new_n255_), .B(p17), .Y(new_n290_));
  OR3x1_ASAP7_75t_R   g232(.A(new_n255_), .B(p17), .C(new_n158_), .Y(new_n291_));
  AND2x2_ASAP7_75t_R  g233(.A(new_n290_), .B(new_n291_), .Y(o14));
  OAI21x1_ASAP7_75t_R g234(.A1(new_n158_), .A2(new_n255_), .B(p10), .Y(new_n293_));
  OR3x1_ASAP7_75t_R   g235(.A(new_n255_), .B(p10), .C(new_n158_), .Y(new_n294_));
  AND2x2_ASAP7_75t_R  g236(.A(new_n293_), .B(new_n294_), .Y(o15));
  INVx1_ASAP7_75t_R   g237(.A(p4), .Y(new_n296_));
  AND2x2_ASAP7_75t_R  g238(.A(new_n155_), .B(new_n262_), .Y(new_n297_));
  AOI21x1_ASAP7_75t_R g239(.A1(new_n149_), .A2(new_n133_), .B(new_n297_), .Y(new_n298_));
  NAND3x1_ASAP7_75t_R g240(.A(new_n135_), .B(new_n148_), .C(new_n298_), .Y(new_n299_));
  OR3x1_ASAP7_75t_R   g241(.A(new_n259_), .B(new_n299_), .C(new_n260_), .Y(new_n300_));
  INVx1_ASAP7_75t_R   g242(.A(new_n200_), .Y(new_n301_));
  AND3x1_ASAP7_75t_R  g243(.A(new_n111_), .B(new_n254_), .C(new_n62_), .Y(new_n302_));
  AND3x1_ASAP7_75t_R  g244(.A(new_n135_), .B(new_n148_), .C(new_n264_), .Y(new_n303_));
  AND3x1_ASAP7_75t_R  g245(.A(new_n302_), .B(new_n303_), .C(new_n251_), .Y(new_n304_));
  AOI21x1_ASAP7_75t_R g246(.A1(new_n301_), .A2(new_n304_), .B(p1), .Y(new_n305_));
  OAI21x1_ASAP7_75t_R g247(.A1(new_n296_), .A2(new_n300_), .B(new_n305_), .Y(o16));
  NOR2x1_ASAP7_75t_R  g248(.A(new_n196_), .B(new_n198_), .Y(new_n307_));
  NOR3x1_ASAP7_75t_R  g249(.A(new_n259_), .B(new_n260_), .C(new_n299_), .Y(new_n308_));
  AO21x1_ASAP7_75t_R  g250(.A1(new_n307_), .A2(new_n308_), .B(new_n151_), .Y(new_n309_));
  OR3x1_ASAP7_75t_R   g251(.A(new_n153_), .B(new_n193_), .C(p2), .Y(new_n310_));
  NOR2x1_ASAP7_75t_R  g252(.A(new_n188_), .B(new_n192_), .Y(new_n311_));
  OA21x2_ASAP7_75t_R  g253(.A1(new_n310_), .A2(new_n300_), .B(new_n311_), .Y(new_n312_));
  NOR2x1_ASAP7_75t_R  g254(.A(new_n309_), .B(new_n312_), .Y(o17));
  NAND2x1_ASAP7_75t_R g255(.A(p29), .B(new_n59_), .Y(new_n314_));
  AND2x2_ASAP7_75t_R  g256(.A(new_n107_), .B(new_n108_), .Y(new_n315_));
  NOR2x1_ASAP7_75t_R  g257(.A(new_n314_), .B(new_n315_), .Y(new_n316_));
  AO21x1_ASAP7_75t_R  g258(.A1(new_n316_), .A2(new_n308_), .B(new_n151_), .Y(new_n317_));
  OA21x2_ASAP7_75t_R  g259(.A1(new_n314_), .A2(new_n300_), .B(new_n315_), .Y(new_n318_));
  NOR2x1_ASAP7_75t_R  g260(.A(new_n317_), .B(new_n318_), .Y(o18));
  NAND2x1_ASAP7_75t_R g261(.A(p20), .B(new_n308_), .Y(new_n320_));
  AOI21x1_ASAP7_75t_R g262(.A1(new_n133_), .A2(new_n320_), .B(new_n151_), .Y(o19));
  AO21x1_ASAP7_75t_R  g263(.A1(p12), .A2(new_n308_), .B(new_n145_), .Y(new_n322_));
  AND2x2_ASAP7_75t_R  g264(.A(new_n152_), .B(new_n322_), .Y(o20));
  NAND2x1_ASAP7_75t_R g265(.A(new_n245_), .B(new_n242_), .Y(new_n324_));
  AND2x2_ASAP7_75t_R  g266(.A(new_n228_), .B(new_n308_), .Y(new_n325_));
  OA21x2_ASAP7_75t_R  g267(.A1(new_n324_), .A2(new_n325_), .B(new_n152_), .Y(o21));
  AO21x1_ASAP7_75t_R  g268(.A1(p31), .A2(p30), .B(p1), .Y(new_n327_));
  INVx1_ASAP7_75t_R   g269(.A(new_n327_), .Y(new_n328_));
  OR3x1_ASAP7_75t_R   g270(.A(new_n259_), .B(new_n260_), .C(new_n265_), .Y(new_n329_));
  NOR2x1_ASAP7_75t_R  g271(.A(p1), .B(p31), .Y(new_n330_));
  AO21x1_ASAP7_75t_R  g272(.A1(new_n189_), .A2(new_n190_), .B(new_n330_), .Y(new_n331_));
  INVx1_ASAP7_75t_R   g273(.A(new_n331_), .Y(new_n332_));
  AOI21x1_ASAP7_75t_R g274(.A1(new_n59_), .A2(new_n133_), .B(new_n134_), .Y(new_n333_));
  AOI21x1_ASAP7_75t_R g275(.A1(new_n133_), .A2(new_n149_), .B(new_n333_), .Y(new_n334_));
  NAND3x1_ASAP7_75t_R g276(.A(new_n334_), .B(new_n263_), .C(new_n331_), .Y(new_n335_));
  NOR3x1_ASAP7_75t_R  g277(.A(new_n335_), .B(new_n260_), .C(new_n259_), .Y(new_n336_));
  AOI21x1_ASAP7_75t_R g278(.A1(new_n329_), .A2(new_n332_), .B(new_n336_), .Y(new_n337_));
  NOR2x1_ASAP7_75t_R  g279(.A(new_n332_), .B(new_n265_), .Y(new_n338_));
  AOI21x1_ASAP7_75t_R g280(.A1(new_n253_), .A2(new_n200_), .B(new_n260_), .Y(new_n339_));
  AOI21x1_ASAP7_75t_R g281(.A1(new_n338_), .A2(new_n339_), .B(new_n327_), .Y(new_n340_));
  OAI21x1_ASAP7_75t_R g282(.A1(new_n266_), .A2(new_n331_), .B(new_n340_), .Y(new_n341_));
  OAI21x1_ASAP7_75t_R g283(.A1(new_n328_), .A2(new_n337_), .B(new_n341_), .Y(o22));
  NOR2x1_ASAP7_75t_R  g284(.A(new_n113_), .B(new_n114_), .Y(new_n343_));
  XOR2x2_ASAP7_75t_R  g285(.A(new_n103_), .B(new_n343_), .Y(new_n344_));
  NOR2x1_ASAP7_75t_R  g286(.A(p1), .B(p28), .Y(new_n345_));
  XOR2x2_ASAP7_75t_R  g287(.A(new_n344_), .B(new_n345_), .Y(new_n346_));
  OA21x2_ASAP7_75t_R  g288(.A1(p1), .A2(p3), .B(new_n346_), .Y(new_n347_));
  XOR2x2_ASAP7_75t_R  g289(.A(new_n274_), .B(new_n347_), .Y(o23));
  AND3x1_ASAP7_75t_R  g290(.A(new_n205_), .B(new_n207_), .C(new_n152_), .Y(new_n349_));
  NAND2x1_ASAP7_75t_R g291(.A(new_n209_), .B(new_n308_), .Y(new_n350_));
  AND2x2_ASAP7_75t_R  g292(.A(new_n349_), .B(new_n350_), .Y(o24));
endmodule


