// Benchmark "/tmp/" written by ABC on Mon Oct 12 15:05:21 2026

module \/tmp/  ( 
    p1, p4, p3, p17, p8, p26, p32, p27, p7, p9, p18, p25, p24, p5, p19,
    p15, p20, p10, p16, p6, p31, p2, p11, p28, p12, p30, p14, p13, p22,
    p23, p29, p21, p0,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24  );
  input  p1, p4, p3, p17, p8, p26, p32, p27, p7, p9, p18, p25, p24, p5,
    p19, p15, p20, p10, p16, p6, p31, p2, p11, p28, p12, p30, p14, p13,
    p22, p23, p29, p21, p0;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24;
  wire new_n59_, new_n60_, new_n61_, new_n62_, new_n63_, new_n64_, new_n65_,
    new_n66_, new_n67_, new_n68_, new_n69_, new_n70_, new_n71_, new_n72_,
    new_n73_, new_n74_, new_n75_, new_n76_, new_n77_, new_n78_, new_n79_,
    new_n80_, new_n81_, new_n82_, new_n83_, new_n84_, new_n85_, new_n86_,
    new_n87_, new_n88_, new_n89_, new_n90_, new_n91_, new_n92_, new_n93_,
    new_n94_, new_n95_, new_n96_, new_n97_, new_n98_, new_n99_, new_n100_,
    new_n101_, new_n102_, new_n103_, new_n104_, new_n105_, new_n106_,
    new_n107_, new_n108_, new_n109_, new_n110_, new_n111_, new_n112_,
    new_n113_, new_n114_, new_n115_, new_n116_, new_n117_, new_n118_,
    new_n119_, new_n120_, new_n121_, new_n122_, new_n123_, new_n124_,
    new_n125_, new_n126_, new_n127_, new_n128_, new_n129_, new_n130_,
    new_n131_, new_n132_, new_n133_, new_n134_, new_n135_, new_n136_,
    new_n137_, new_n138_, new_n139_, new_n140_, new_n141_, new_n142_,
    new_n143_, new_n144_, new_n145_, new_n146_, new_n147_, new_n148_,
    new_n149_, new_n150_, new_n151_, new_n152_, new_n153_, new_n154_,
    new_n155_, new_n156_, new_n157_, new_n158_, new_n159_, new_n160_,
    new_n161_, new_n162_, new_n163_, new_n164_, new_n165_, new_n166_,
    new_n167_, new_n168_, new_n169_, new_n170_, new_n171_, new_n172_,
    new_n173_, new_n174_, new_n175_, new_n176_, new_n177_, new_n178_,
    new_n179_, new_n180_, new_n181_, new_n182_, new_n183_, new_n184_,
    new_n185_, new_n186_, new_n187_, new_n188_, new_n189_, new_n190_,
    new_n191_, new_n192_, new_n193_, new_n194_, new_n195_, new_n196_,
    new_n197_, new_n198_, new_n199_, new_n200_, new_n201_, new_n202_,
    new_n203_, new_n204_, new_n205_, new_n206_, new_n207_, new_n208_,
    new_n209_, new_n210_, new_n211_, new_n212_, new_n213_, new_n214_,
    new_n215_, new_n216_, new_n217_, new_n218_, new_n219_, new_n220_,
    new_n221_, new_n222_, new_n223_, new_n224_, new_n225_, new_n226_,
    new_n227_, new_n228_, new_n229_, new_n230_, new_n231_, new_n232_,
    new_n233_, new_n234_, new_n235_, new_n236_, new_n237_, new_n238_,
    new_n239_, new_n240_, new_n241_, new_n242_, new_n243_, new_n244_,
    new_n245_, new_n246_, new_n247_, new_n248_, new_n249_, new_n250_,
    new_n251_, new_n252_, new_n253_, new_n254_, new_n255_, new_n256_,
    new_n257_, new_n258_, new_n260_, new_n261_, new_n262_, new_n263_,
    new_n264_, new_n265_, new_n266_, new_n267_, new_n268_, new_n269_,
    new_n270_, new_n273_, new_n277_, new_n281_, new_n282_, new_n283_,
    new_n284_, new_n285_, new_n286_, new_n287_, new_n288_, new_n289_,
    new_n290_, new_n291_, new_n293_, new_n294_, new_n295_, new_n297_,
    new_n298_, new_n299_, new_n301_, new_n302_, new_n304_, new_n305_,
    new_n306_, new_n308_, new_n310_, new_n312_, new_n313_, new_n314_,
    new_n315_, new_n316_, new_n317_, new_n318_, new_n319_, new_n320_,
    new_n321_, new_n322_, new_n324_, new_n325_, new_n326_, new_n327_,
    new_n328_, new_n329_, new_n331_, new_n332_, new_n333_, new_n334_,
    new_n335_, new_n337_, new_n339_, new_n341_, new_n342_, new_n343_,
    new_n345_, new_n346_, new_n347_, new_n348_, new_n349_, new_n350_,
    new_n351_, new_n352_, new_n353_, new_n354_, new_n355_, new_n356_,
    new_n358_, new_n359_, new_n360_, new_n361_, new_n362_, new_n364_;
  XOR2x2_ASAP7_75t_R  g000(.A(p8), .B(p9), .Y(new_n59_));
  INVx1_ASAP7_75t_R   g001(.A(p15), .Y(new_n60_));
  XOR2x2_ASAP7_75t_R  g002(.A(new_n59_), .B(new_n60_), .Y(new_n61_));
  XOR2x2_ASAP7_75t_R  g003(.A(p17), .B(p24), .Y(new_n62_));
  XOR2x2_ASAP7_75t_R  g004(.A(new_n62_), .B(p10), .Y(new_n63_));
  NAND2x1_ASAP7_75t_R g005(.A(new_n61_), .B(new_n63_), .Y(new_n64_));
  XOR2x2_ASAP7_75t_R  g006(.A(new_n59_), .B(p15), .Y(new_n65_));
  XNOR2x2_ASAP7_75t_R g007(.A(p10), .B(new_n62_), .Y(new_n66_));
  NAND2x1_ASAP7_75t_R g008(.A(new_n65_), .B(new_n66_), .Y(new_n67_));
  NAND2x1_ASAP7_75t_R g009(.A(new_n64_), .B(new_n67_), .Y(new_n68_));
  INVx1_ASAP7_75t_R   g010(.A(p1), .Y(new_n69_));
  AND2x2_ASAP7_75t_R  g011(.A(p28), .B(new_n69_), .Y(new_n70_));
  XOR2x2_ASAP7_75t_R  g012(.A(p14), .B(p22), .Y(new_n71_));
  XOR2x2_ASAP7_75t_R  g013(.A(new_n70_), .B(new_n71_), .Y(new_n72_));
  XOR2x2_ASAP7_75t_R  g014(.A(p25), .B(p19), .Y(new_n73_));
  INVx1_ASAP7_75t_R   g015(.A(p7), .Y(new_n74_));
  XOR2x2_ASAP7_75t_R  g016(.A(new_n73_), .B(new_n74_), .Y(new_n75_));
  XOR2x2_ASAP7_75t_R  g017(.A(new_n72_), .B(new_n75_), .Y(new_n76_));
  NAND2x1_ASAP7_75t_R g018(.A(new_n68_), .B(new_n76_), .Y(new_n77_));
  XOR2x2_ASAP7_75t_R  g019(.A(new_n73_), .B(p7), .Y(new_n78_));
  XOR2x2_ASAP7_75t_R  g020(.A(new_n72_), .B(new_n78_), .Y(new_n79_));
  NOR2x1_ASAP7_75t_R  g021(.A(new_n61_), .B(new_n63_), .Y(new_n80_));
  NOR2x1_ASAP7_75t_R  g022(.A(new_n65_), .B(new_n66_), .Y(new_n81_));
  NOR2x1_ASAP7_75t_R  g023(.A(new_n80_), .B(new_n81_), .Y(new_n82_));
  NAND2x1_ASAP7_75t_R g024(.A(new_n79_), .B(new_n82_), .Y(new_n83_));
  INVx1_ASAP7_75t_R   g025(.A(p2), .Y(new_n84_));
  INVx1_ASAP7_75t_R   g026(.A(p29), .Y(new_n85_));
  NAND2x1_ASAP7_75t_R g027(.A(new_n84_), .B(new_n85_), .Y(new_n86_));
  AO21x1_ASAP7_75t_R  g028(.A1(new_n77_), .A2(new_n83_), .B(new_n86_), .Y(new_n87_));
  OR3x1_ASAP7_75t_R   g029(.A(new_n82_), .B(new_n79_), .C(p2), .Y(new_n88_));
  OR3x1_ASAP7_75t_R   g030(.A(new_n76_), .B(new_n68_), .C(p2), .Y(new_n89_));
  NAND3x1_ASAP7_75t_R g031(.A(new_n88_), .B(new_n89_), .C(p29), .Y(new_n90_));
  INVx1_ASAP7_75t_R   g032(.A(p32), .Y(new_n91_));
  INVx1_ASAP7_75t_R   g033(.A(p23), .Y(new_n92_));
  AO21x1_ASAP7_75t_R  g034(.A1(new_n91_), .A2(new_n84_), .B(new_n92_), .Y(new_n93_));
  AO21x1_ASAP7_75t_R  g035(.A1(new_n87_), .A2(new_n90_), .B(new_n93_), .Y(new_n94_));
  NAND2x1_ASAP7_75t_R g036(.A(p14), .B(p13), .Y(new_n95_));
  OR3x1_ASAP7_75t_R   g037(.A(p15), .B(p14), .C(p13), .Y(new_n96_));
  OAI21x1_ASAP7_75t_R g038(.A1(p15), .A2(new_n95_), .B(new_n96_), .Y(new_n97_));
  INVx1_ASAP7_75t_R   g039(.A(p0), .Y(new_n98_));
  AND3x1_ASAP7_75t_R  g040(.A(new_n69_), .B(new_n98_), .C(p16), .Y(new_n99_));
  OAI21x1_ASAP7_75t_R g041(.A1(p14), .A2(p13), .B(p15), .Y(new_n100_));
  AND2x2_ASAP7_75t_R  g042(.A(p14), .B(p13), .Y(new_n101_));
  NOR2x1_ASAP7_75t_R  g043(.A(new_n100_), .B(new_n101_), .Y(new_n102_));
  OR3x1_ASAP7_75t_R   g044(.A(new_n97_), .B(new_n99_), .C(new_n102_), .Y(new_n103_));
  NOR2x1_ASAP7_75t_R  g045(.A(p14), .B(p13), .Y(new_n104_));
  OAI21x1_ASAP7_75t_R g046(.A1(new_n104_), .A2(new_n101_), .B(new_n60_), .Y(new_n105_));
  AO21x1_ASAP7_75t_R  g047(.A1(p14), .A2(p13), .B(new_n100_), .Y(new_n106_));
  NAND2x1_ASAP7_75t_R g048(.A(new_n105_), .B(new_n106_), .Y(new_n107_));
  NAND2x1_ASAP7_75t_R g049(.A(new_n99_), .B(new_n107_), .Y(new_n108_));
  XNOR2x2_ASAP7_75t_R g050(.A(p18), .B(p5), .Y(new_n109_));
  INVx1_ASAP7_75t_R   g051(.A(p18), .Y(new_n110_));
  INVx1_ASAP7_75t_R   g052(.A(p5), .Y(new_n111_));
  AO21x1_ASAP7_75t_R  g053(.A1(p18), .A2(p5), .B(p19), .Y(new_n112_));
  AOI21x1_ASAP7_75t_R g054(.A1(new_n110_), .A2(new_n111_), .B(new_n112_), .Y(new_n113_));
  AO21x1_ASAP7_75t_R  g055(.A1(p19), .A2(new_n109_), .B(new_n113_), .Y(new_n114_));
  AOI21x1_ASAP7_75t_R g056(.A1(new_n103_), .A2(new_n108_), .B(new_n114_), .Y(new_n115_));
  AND2x2_ASAP7_75t_R  g057(.A(new_n99_), .B(new_n107_), .Y(new_n116_));
  NAND2x1_ASAP7_75t_R g058(.A(new_n114_), .B(new_n103_), .Y(new_n117_));
  XOR2x2_ASAP7_75t_R  g059(.A(p17), .B(p8), .Y(new_n118_));
  INVx1_ASAP7_75t_R   g060(.A(new_n118_), .Y(new_n119_));
  OAI21x1_ASAP7_75t_R g061(.A1(new_n116_), .A2(new_n117_), .B(new_n119_), .Y(new_n120_));
  OAI21x1_ASAP7_75t_R g062(.A1(new_n115_), .A2(new_n120_), .B(new_n84_), .Y(new_n121_));
  AND3x1_ASAP7_75t_R  g063(.A(new_n108_), .B(new_n114_), .C(new_n103_), .Y(new_n122_));
  OA21x2_ASAP7_75t_R  g064(.A1(new_n115_), .A2(new_n122_), .B(new_n118_), .Y(new_n123_));
  OAI21x1_ASAP7_75t_R g065(.A1(new_n121_), .A2(new_n123_), .B(p20), .Y(new_n124_));
  XOR2x2_ASAP7_75t_R  g066(.A(p7), .B(p5), .Y(new_n125_));
  XOR2x2_ASAP7_75t_R  g067(.A(p10), .B(p6), .Y(new_n126_));
  XOR2x2_ASAP7_75t_R  g068(.A(new_n125_), .B(new_n126_), .Y(new_n127_));
  NOR2x1_ASAP7_75t_R  g069(.A(p1), .B(p32), .Y(new_n128_));
  NAND2x1_ASAP7_75t_R g070(.A(p11), .B(new_n128_), .Y(new_n129_));
  XOR2x2_ASAP7_75t_R  g071(.A(new_n59_), .B(new_n129_), .Y(new_n130_));
  XOR2x2_ASAP7_75t_R  g072(.A(new_n127_), .B(new_n130_), .Y(new_n131_));
  OR3x1_ASAP7_75t_R   g073(.A(new_n131_), .B(p2), .C(p12), .Y(new_n132_));
  OAI21x1_ASAP7_75t_R g074(.A1(p2), .A2(new_n131_), .B(p12), .Y(new_n133_));
  AND3x1_ASAP7_75t_R  g075(.A(new_n124_), .B(new_n132_), .C(new_n133_), .Y(new_n134_));
  OR3x1_ASAP7_75t_R   g076(.A(p1), .B(p3), .C(p2), .Y(new_n135_));
  NOR2x1_ASAP7_75t_R  g077(.A(p1), .B(p4), .Y(new_n136_));
  INVx1_ASAP7_75t_R   g078(.A(new_n136_), .Y(new_n137_));
  NOR2x1_ASAP7_75t_R  g079(.A(p32), .B(new_n98_), .Y(new_n138_));
  AOI21x1_ASAP7_75t_R g080(.A1(new_n135_), .A2(new_n137_), .B(new_n138_), .Y(new_n139_));
  NOR2x1_ASAP7_75t_R  g081(.A(p20), .B(p2), .Y(new_n140_));
  NOR2x1_ASAP7_75t_R  g082(.A(new_n102_), .B(new_n97_), .Y(new_n141_));
  XOR2x2_ASAP7_75t_R  g083(.A(new_n118_), .B(p18), .Y(new_n142_));
  NAND2x1_ASAP7_75t_R g084(.A(new_n141_), .B(new_n142_), .Y(new_n143_));
  XOR2x2_ASAP7_75t_R  g085(.A(new_n118_), .B(new_n110_), .Y(new_n144_));
  NAND2x1_ASAP7_75t_R g086(.A(new_n107_), .B(new_n144_), .Y(new_n145_));
  XNOR2x2_ASAP7_75t_R g087(.A(p5), .B(p19), .Y(new_n146_));
  XOR2x2_ASAP7_75t_R  g088(.A(new_n146_), .B(new_n99_), .Y(new_n147_));
  NAND3x1_ASAP7_75t_R g089(.A(new_n143_), .B(new_n145_), .C(new_n147_), .Y(new_n148_));
  AO21x1_ASAP7_75t_R  g090(.A1(new_n143_), .A2(new_n145_), .B(new_n147_), .Y(new_n149_));
  NAND2x1_ASAP7_75t_R g091(.A(new_n148_), .B(new_n149_), .Y(new_n150_));
  NAND2x1_ASAP7_75t_R g092(.A(new_n140_), .B(new_n150_), .Y(new_n151_));
  AND2x2_ASAP7_75t_R  g093(.A(new_n139_), .B(new_n151_), .Y(new_n152_));
  AND3x1_ASAP7_75t_R  g094(.A(new_n94_), .B(new_n134_), .C(new_n152_), .Y(new_n153_));
  INVx1_ASAP7_75t_R   g095(.A(p22), .Y(new_n154_));
  NAND3x1_ASAP7_75t_R g096(.A(new_n106_), .B(new_n105_), .C(new_n154_), .Y(new_n155_));
  OAI21x1_ASAP7_75t_R g097(.A1(new_n102_), .A2(new_n97_), .B(p22), .Y(new_n156_));
  INVx1_ASAP7_75t_R   g098(.A(new_n128_), .Y(new_n157_));
  INVx1_ASAP7_75t_R   g099(.A(p24), .Y(new_n158_));
  NAND2x1_ASAP7_75t_R g100(.A(p23), .B(new_n158_), .Y(new_n159_));
  AO21x1_ASAP7_75t_R  g101(.A1(p23), .A2(new_n128_), .B(new_n158_), .Y(new_n160_));
  OAI21x1_ASAP7_75t_R g102(.A1(new_n157_), .A2(new_n159_), .B(new_n160_), .Y(new_n161_));
  AND3x1_ASAP7_75t_R  g103(.A(new_n155_), .B(new_n156_), .C(new_n161_), .Y(new_n162_));
  XOR2x2_ASAP7_75t_R  g104(.A(p9), .B(p21), .Y(new_n163_));
  AOI21x1_ASAP7_75t_R g105(.A1(new_n156_), .A2(new_n155_), .B(new_n161_), .Y(new_n164_));
  NOR3x1_ASAP7_75t_R  g106(.A(new_n162_), .B(new_n163_), .C(new_n164_), .Y(new_n165_));
  INVx1_ASAP7_75t_R   g107(.A(p11), .Y(new_n166_));
  AO21x1_ASAP7_75t_R  g108(.A1(new_n91_), .A2(new_n84_), .B(new_n166_), .Y(new_n167_));
  XOR2x2_ASAP7_75t_R  g109(.A(p24), .B(p22), .Y(new_n168_));
  OR3x1_ASAP7_75t_R   g110(.A(new_n168_), .B(new_n92_), .C(new_n157_), .Y(new_n169_));
  NAND2x1_ASAP7_75t_R g111(.A(p23), .B(new_n128_), .Y(new_n170_));
  NAND2x1_ASAP7_75t_R g112(.A(new_n170_), .B(new_n168_), .Y(new_n171_));
  AO21x1_ASAP7_75t_R  g113(.A1(new_n169_), .A2(new_n171_), .B(new_n141_), .Y(new_n172_));
  NOR2x1_ASAP7_75t_R  g114(.A(new_n170_), .B(new_n168_), .Y(new_n173_));
  AND2x2_ASAP7_75t_R  g115(.A(new_n170_), .B(new_n168_), .Y(new_n174_));
  OR3x1_ASAP7_75t_R   g116(.A(new_n107_), .B(new_n173_), .C(new_n174_), .Y(new_n175_));
  INVx1_ASAP7_75t_R   g117(.A(new_n163_), .Y(new_n176_));
  AOI21x1_ASAP7_75t_R g118(.A1(new_n172_), .A2(new_n175_), .B(new_n176_), .Y(new_n177_));
  NOR3x1_ASAP7_75t_R  g119(.A(new_n165_), .B(new_n167_), .C(new_n177_), .Y(new_n178_));
  AOI21x1_ASAP7_75t_R g120(.A1(new_n172_), .A2(new_n175_), .B(new_n163_), .Y(new_n179_));
  OR3x1_ASAP7_75t_R   g121(.A(new_n141_), .B(new_n174_), .C(new_n173_), .Y(new_n180_));
  AO21x1_ASAP7_75t_R  g122(.A1(new_n169_), .A2(new_n171_), .B(new_n107_), .Y(new_n181_));
  AOI21x1_ASAP7_75t_R g123(.A1(new_n180_), .A2(new_n181_), .B(new_n176_), .Y(new_n182_));
  AO21x1_ASAP7_75t_R  g124(.A1(p32), .A2(p11), .B(p2), .Y(new_n183_));
  NOR3x1_ASAP7_75t_R  g125(.A(new_n179_), .B(new_n182_), .C(new_n183_), .Y(new_n184_));
  NOR2x1_ASAP7_75t_R  g126(.A(new_n84_), .B(new_n167_), .Y(new_n185_));
  NOR3x1_ASAP7_75t_R  g127(.A(new_n178_), .B(new_n184_), .C(new_n185_), .Y(new_n186_));
  XOR2x2_ASAP7_75t_R  g128(.A(p6), .B(p21), .Y(new_n187_));
  NAND2x1_ASAP7_75t_R g129(.A(new_n110_), .B(new_n187_), .Y(new_n188_));
  XNOR2x2_ASAP7_75t_R g130(.A(p6), .B(p21), .Y(new_n189_));
  NAND2x1_ASAP7_75t_R g131(.A(p18), .B(new_n189_), .Y(new_n190_));
  NOR2x1_ASAP7_75t_R  g132(.A(p1), .B(p0), .Y(new_n191_));
  INVx1_ASAP7_75t_R   g133(.A(p25), .Y(new_n192_));
  AOI21x1_ASAP7_75t_R g134(.A1(p26), .A2(new_n191_), .B(new_n192_), .Y(new_n193_));
  AND3x1_ASAP7_75t_R  g135(.A(new_n191_), .B(p26), .C(new_n192_), .Y(new_n194_));
  NOR2x1_ASAP7_75t_R  g136(.A(new_n193_), .B(new_n194_), .Y(new_n195_));
  AOI21x1_ASAP7_75t_R g137(.A1(new_n188_), .A2(new_n190_), .B(new_n195_), .Y(new_n196_));
  NAND2x1_ASAP7_75t_R g138(.A(p18), .B(new_n187_), .Y(new_n197_));
  NAND2x1_ASAP7_75t_R g139(.A(new_n110_), .B(new_n189_), .Y(new_n198_));
  NAND3x1_ASAP7_75t_R g140(.A(new_n191_), .B(p26), .C(new_n192_), .Y(new_n199_));
  AO21x1_ASAP7_75t_R  g141(.A1(p26), .A2(new_n191_), .B(new_n192_), .Y(new_n200_));
  NAND2x1_ASAP7_75t_R g142(.A(new_n199_), .B(new_n200_), .Y(new_n201_));
  AOI21x1_ASAP7_75t_R g143(.A1(new_n197_), .A2(new_n198_), .B(new_n201_), .Y(new_n202_));
  NOR2x1_ASAP7_75t_R  g144(.A(new_n196_), .B(new_n202_), .Y(new_n203_));
  NAND3x1_ASAP7_75t_R g145(.A(new_n203_), .B(new_n64_), .C(new_n67_), .Y(new_n204_));
  NOR2x1_ASAP7_75t_R  g146(.A(p18), .B(new_n187_), .Y(new_n205_));
  NOR2x1_ASAP7_75t_R  g147(.A(new_n110_), .B(new_n189_), .Y(new_n206_));
  OAI21x1_ASAP7_75t_R g148(.A1(new_n205_), .A2(new_n206_), .B(new_n195_), .Y(new_n207_));
  NOR2x1_ASAP7_75t_R  g149(.A(new_n110_), .B(new_n187_), .Y(new_n208_));
  NOR2x1_ASAP7_75t_R  g150(.A(p18), .B(new_n189_), .Y(new_n209_));
  OAI21x1_ASAP7_75t_R g151(.A1(new_n208_), .A2(new_n209_), .B(new_n201_), .Y(new_n210_));
  NAND2x1_ASAP7_75t_R g152(.A(new_n207_), .B(new_n210_), .Y(new_n211_));
  OAI21x1_ASAP7_75t_R g153(.A1(new_n80_), .A2(new_n81_), .B(new_n211_), .Y(new_n212_));
  INVx1_ASAP7_75t_R   g154(.A(p27), .Y(new_n213_));
  NOR2x1_ASAP7_75t_R  g155(.A(p2), .B(new_n213_), .Y(new_n214_));
  NAND3x1_ASAP7_75t_R g156(.A(new_n204_), .B(new_n212_), .C(new_n214_), .Y(new_n215_));
  NAND3x1_ASAP7_75t_R g157(.A(new_n211_), .B(new_n64_), .C(new_n67_), .Y(new_n216_));
  OAI21x1_ASAP7_75t_R g158(.A1(new_n81_), .A2(new_n80_), .B(new_n203_), .Y(new_n217_));
  NAND3x1_ASAP7_75t_R g159(.A(new_n216_), .B(new_n217_), .C(new_n213_), .Y(new_n218_));
  NAND2x1_ASAP7_75t_R g160(.A(p2), .B(new_n213_), .Y(new_n219_));
  NAND3x1_ASAP7_75t_R g161(.A(new_n215_), .B(new_n218_), .C(new_n219_), .Y(new_n220_));
  AND2x2_ASAP7_75t_R  g162(.A(new_n186_), .B(new_n220_), .Y(new_n221_));
  AND2x2_ASAP7_75t_R  g163(.A(p26), .B(p0), .Y(new_n222_));
  AO21x1_ASAP7_75t_R  g164(.A1(p26), .A2(p2), .B(new_n222_), .Y(new_n223_));
  NAND2x1_ASAP7_75t_R g165(.A(new_n197_), .B(new_n198_), .Y(new_n224_));
  NOR2x1_ASAP7_75t_R  g166(.A(new_n78_), .B(new_n224_), .Y(new_n225_));
  NAND2x1_ASAP7_75t_R g167(.A(new_n188_), .B(new_n190_), .Y(new_n226_));
  NOR2x1_ASAP7_75t_R  g168(.A(new_n75_), .B(new_n226_), .Y(new_n227_));
  XNOR2x2_ASAP7_75t_R g169(.A(p5), .B(p22), .Y(new_n228_));
  INVx1_ASAP7_75t_R   g170(.A(new_n228_), .Y(new_n229_));
  OAI21x1_ASAP7_75t_R g171(.A1(new_n225_), .A2(new_n227_), .B(new_n229_), .Y(new_n230_));
  NAND2x1_ASAP7_75t_R g172(.A(new_n75_), .B(new_n226_), .Y(new_n231_));
  NAND2x1_ASAP7_75t_R g173(.A(new_n78_), .B(new_n224_), .Y(new_n232_));
  NAND3x1_ASAP7_75t_R g174(.A(new_n231_), .B(new_n232_), .C(new_n228_), .Y(new_n233_));
  NAND2x1_ASAP7_75t_R g175(.A(p30), .B(new_n69_), .Y(new_n234_));
  XNOR2x2_ASAP7_75t_R g176(.A(p13), .B(new_n234_), .Y(new_n235_));
  XOR2x2_ASAP7_75t_R  g177(.A(new_n65_), .B(new_n235_), .Y(new_n236_));
  AOI21x1_ASAP7_75t_R g178(.A1(new_n230_), .A2(new_n233_), .B(new_n236_), .Y(new_n237_));
  OAI21x1_ASAP7_75t_R g179(.A1(new_n225_), .A2(new_n227_), .B(new_n228_), .Y(new_n238_));
  NAND3x1_ASAP7_75t_R g180(.A(new_n231_), .B(new_n232_), .C(new_n229_), .Y(new_n239_));
  XOR2x2_ASAP7_75t_R  g181(.A(new_n61_), .B(new_n235_), .Y(new_n240_));
  AOI21x1_ASAP7_75t_R g182(.A1(new_n238_), .A2(new_n239_), .B(new_n240_), .Y(new_n241_));
  OAI21x1_ASAP7_75t_R g183(.A1(new_n237_), .A2(new_n241_), .B(new_n84_), .Y(new_n242_));
  NAND2x1_ASAP7_75t_R g184(.A(new_n223_), .B(new_n242_), .Y(new_n243_));
  NOR2x1_ASAP7_75t_R  g185(.A(p2), .B(new_n222_), .Y(new_n244_));
  OAI21x1_ASAP7_75t_R g186(.A1(new_n237_), .A2(new_n241_), .B(new_n244_), .Y(new_n245_));
  OA21x2_ASAP7_75t_R  g187(.A1(p2), .A2(p0), .B(p16), .Y(new_n246_));
  AND3x1_ASAP7_75t_R  g188(.A(new_n243_), .B(new_n245_), .C(new_n246_), .Y(new_n247_));
  NAND3x1_ASAP7_75t_R g189(.A(new_n153_), .B(new_n221_), .C(new_n247_), .Y(new_n248_));
  AO21x1_ASAP7_75t_R  g190(.A1(new_n230_), .A2(new_n233_), .B(new_n240_), .Y(new_n249_));
  NAND2x1_ASAP7_75t_R g191(.A(new_n238_), .B(new_n239_), .Y(new_n250_));
  AOI21x1_ASAP7_75t_R g192(.A1(new_n240_), .A2(new_n250_), .B(p2), .Y(new_n251_));
  INVx1_ASAP7_75t_R   g193(.A(new_n223_), .Y(new_n252_));
  AOI21x1_ASAP7_75t_R g194(.A1(new_n249_), .A2(new_n251_), .B(new_n252_), .Y(new_n253_));
  NAND3x1_ASAP7_75t_R g195(.A(new_n220_), .B(new_n186_), .C(new_n245_), .Y(new_n254_));
  NOR2x1_ASAP7_75t_R  g196(.A(new_n253_), .B(new_n254_), .Y(new_n255_));
  NAND3x1_ASAP7_75t_R g197(.A(new_n255_), .B(new_n246_), .C(new_n94_), .Y(new_n256_));
  NAND2x1_ASAP7_75t_R g198(.A(new_n152_), .B(new_n134_), .Y(new_n257_));
  NOR3x1_ASAP7_75t_R  g199(.A(new_n256_), .B(p14), .C(new_n257_), .Y(new_n258_));
  AOI21x1_ASAP7_75t_R g200(.A1(p14), .A2(new_n248_), .B(new_n258_), .Y(o0));
  AOI21x1_ASAP7_75t_R g201(.A1(new_n87_), .A2(new_n90_), .B(new_n93_), .Y(new_n260_));
  OR3x1_ASAP7_75t_R   g202(.A(p1), .B(p31), .C(p2), .Y(new_n261_));
  AO21x1_ASAP7_75t_R  g203(.A1(new_n261_), .A2(new_n137_), .B(new_n138_), .Y(new_n262_));
  INVx1_ASAP7_75t_R   g204(.A(new_n262_), .Y(new_n263_));
  AND3x1_ASAP7_75t_R  g205(.A(new_n132_), .B(new_n133_), .C(new_n263_), .Y(new_n264_));
  NAND3x1_ASAP7_75t_R g206(.A(new_n264_), .B(new_n124_), .C(new_n151_), .Y(new_n265_));
  NOR2x1_ASAP7_75t_R  g207(.A(new_n260_), .B(new_n265_), .Y(new_n266_));
  INVx1_ASAP7_75t_R   g208(.A(new_n246_), .Y(new_n267_));
  NAND3x1_ASAP7_75t_R g209(.A(new_n220_), .B(new_n186_), .C(new_n267_), .Y(new_n268_));
  OAI21x1_ASAP7_75t_R g210(.A1(new_n253_), .A2(new_n254_), .B(new_n268_), .Y(new_n269_));
  NAND2x1_ASAP7_75t_R g211(.A(new_n266_), .B(new_n269_), .Y(new_n270_));
  XOR2x2_ASAP7_75t_R  g212(.A(new_n270_), .B(p25), .Y(o1));
  XOR2x2_ASAP7_75t_R  g213(.A(new_n270_), .B(p19), .Y(o2));
  NOR3x1_ASAP7_75t_R  g214(.A(new_n256_), .B(p24), .C(new_n257_), .Y(new_n273_));
  AOI21x1_ASAP7_75t_R g215(.A1(p24), .A2(new_n248_), .B(new_n273_), .Y(o3));
  XOR2x2_ASAP7_75t_R  g216(.A(new_n270_), .B(p7), .Y(o4));
  XOR2x2_ASAP7_75t_R  g217(.A(new_n270_), .B(p22), .Y(o5));
  NAND2x1_ASAP7_75t_R g218(.A(new_n269_), .B(new_n153_), .Y(new_n277_));
  XOR2x2_ASAP7_75t_R  g219(.A(new_n277_), .B(p9), .Y(o6));
  XOR2x2_ASAP7_75t_R  g220(.A(new_n277_), .B(p8), .Y(o7));
  XOR2x2_ASAP7_75t_R  g221(.A(new_n277_), .B(p15), .Y(o8));
  OR2x4_ASAP7_75t_R   g222(.A(p2), .B(p12), .Y(new_n281_));
  OA21x2_ASAP7_75t_R  g223(.A1(new_n131_), .A2(new_n281_), .B(new_n133_), .Y(new_n282_));
  AND3x1_ASAP7_75t_R  g224(.A(new_n282_), .B(new_n124_), .C(new_n151_), .Y(new_n283_));
  AND3x1_ASAP7_75t_R  g225(.A(new_n283_), .B(new_n110_), .C(new_n263_), .Y(new_n284_));
  AND3x1_ASAP7_75t_R  g226(.A(new_n88_), .B(new_n89_), .C(p29), .Y(new_n285_));
  AOI21x1_ASAP7_75t_R g227(.A1(new_n77_), .A2(new_n83_), .B(new_n86_), .Y(new_n286_));
  OR3x1_ASAP7_75t_R   g228(.A(new_n285_), .B(new_n93_), .C(new_n286_), .Y(new_n287_));
  INVx1_ASAP7_75t_R   g229(.A(new_n269_), .Y(new_n288_));
  NOR2x1_ASAP7_75t_R  g230(.A(new_n287_), .B(new_n288_), .Y(new_n289_));
  NOR2x1_ASAP7_75t_R  g231(.A(new_n265_), .B(new_n287_), .Y(new_n290_));
  AOI21x1_ASAP7_75t_R g232(.A1(new_n269_), .A2(new_n290_), .B(new_n110_), .Y(new_n291_));
  AOI21x1_ASAP7_75t_R g233(.A1(new_n284_), .A2(new_n289_), .B(new_n291_), .Y(o9));
  NOR2x1_ASAP7_75t_R  g234(.A(p6), .B(new_n265_), .Y(new_n293_));
  INVx1_ASAP7_75t_R   g235(.A(p6), .Y(new_n294_));
  AOI21x1_ASAP7_75t_R g236(.A1(new_n269_), .A2(new_n290_), .B(new_n294_), .Y(new_n295_));
  AOI21x1_ASAP7_75t_R g237(.A1(new_n293_), .A2(new_n289_), .B(new_n295_), .Y(o10));
  NOR2x1_ASAP7_75t_R  g238(.A(p21), .B(new_n265_), .Y(new_n297_));
  INVx1_ASAP7_75t_R   g239(.A(p21), .Y(new_n298_));
  AOI21x1_ASAP7_75t_R g240(.A1(new_n269_), .A2(new_n290_), .B(new_n298_), .Y(new_n299_));
  AOI21x1_ASAP7_75t_R g241(.A1(new_n297_), .A2(new_n289_), .B(new_n299_), .Y(o11));
  AND3x1_ASAP7_75t_R  g242(.A(new_n283_), .B(new_n111_), .C(new_n263_), .Y(new_n301_));
  AOI21x1_ASAP7_75t_R g243(.A1(new_n269_), .A2(new_n290_), .B(new_n111_), .Y(new_n302_));
  AOI21x1_ASAP7_75t_R g244(.A1(new_n301_), .A2(new_n289_), .B(new_n302_), .Y(o12));
  NOR3x1_ASAP7_75t_R  g245(.A(new_n288_), .B(new_n257_), .C(new_n287_), .Y(new_n304_));
  NAND3x1_ASAP7_75t_R g246(.A(new_n134_), .B(p13), .C(new_n152_), .Y(new_n305_));
  OR3x1_ASAP7_75t_R   g247(.A(new_n288_), .B(new_n287_), .C(new_n305_), .Y(new_n306_));
  OAI21x1_ASAP7_75t_R g248(.A1(p13), .A2(new_n304_), .B(new_n306_), .Y(o13));
  NOR3x1_ASAP7_75t_R  g249(.A(new_n256_), .B(p17), .C(new_n257_), .Y(new_n308_));
  AOI21x1_ASAP7_75t_R g250(.A1(p17), .A2(new_n248_), .B(new_n308_), .Y(o14));
  NOR3x1_ASAP7_75t_R  g251(.A(new_n256_), .B(p10), .C(new_n257_), .Y(new_n310_));
  AOI21x1_ASAP7_75t_R g252(.A1(p10), .A2(new_n248_), .B(new_n310_), .Y(o15));
  NOR2x1_ASAP7_75t_R  g253(.A(new_n139_), .B(new_n263_), .Y(new_n312_));
  AOI21x1_ASAP7_75t_R g254(.A1(new_n140_), .A2(new_n150_), .B(new_n312_), .Y(new_n313_));
  NAND3x1_ASAP7_75t_R g255(.A(new_n282_), .B(new_n313_), .C(new_n124_), .Y(new_n314_));
  NOR2x1_ASAP7_75t_R  g256(.A(new_n314_), .B(new_n260_), .Y(new_n315_));
  INVx1_ASAP7_75t_R   g257(.A(new_n245_), .Y(new_n316_));
  OAI21x1_ASAP7_75t_R g258(.A1(new_n316_), .A2(new_n253_), .B(new_n246_), .Y(new_n317_));
  AND3x1_ASAP7_75t_R  g259(.A(new_n315_), .B(new_n221_), .C(new_n317_), .Y(new_n318_));
  NOR2x1_ASAP7_75t_R  g260(.A(new_n286_), .B(new_n285_), .Y(new_n319_));
  AND2x2_ASAP7_75t_R  g261(.A(new_n93_), .B(new_n267_), .Y(new_n320_));
  AND3x1_ASAP7_75t_R  g262(.A(new_n283_), .B(new_n319_), .C(new_n320_), .Y(new_n321_));
  AO21x1_ASAP7_75t_R  g263(.A1(new_n255_), .A2(new_n321_), .B(p1), .Y(new_n322_));
  AO21x1_ASAP7_75t_R  g264(.A1(p4), .A2(new_n318_), .B(new_n322_), .Y(o16));
  OR2x4_ASAP7_75t_R   g265(.A(new_n237_), .B(new_n241_), .Y(new_n324_));
  AO21x1_ASAP7_75t_R  g266(.A1(new_n244_), .A2(new_n324_), .B(new_n242_), .Y(new_n325_));
  NAND2x1_ASAP7_75t_R g267(.A(new_n315_), .B(new_n269_), .Y(new_n326_));
  OAI21x1_ASAP7_75t_R g268(.A1(new_n325_), .A2(new_n326_), .B(new_n137_), .Y(new_n327_));
  AND3x1_ASAP7_75t_R  g269(.A(new_n84_), .B(p26), .C(p0), .Y(new_n328_));
  AOI21x1_ASAP7_75t_R g270(.A1(new_n328_), .A2(new_n318_), .B(new_n324_), .Y(new_n329_));
  NOR2x1_ASAP7_75t_R  g271(.A(new_n327_), .B(new_n329_), .Y(o17));
  NOR2x1_ASAP7_75t_R  g272(.A(p2), .B(new_n85_), .Y(new_n331_));
  NAND2x1_ASAP7_75t_R g273(.A(new_n77_), .B(new_n83_), .Y(new_n332_));
  NAND2x1_ASAP7_75t_R g274(.A(new_n331_), .B(new_n332_), .Y(new_n333_));
  OAI21x1_ASAP7_75t_R g275(.A1(new_n333_), .A2(new_n326_), .B(new_n137_), .Y(new_n334_));
  AOI21x1_ASAP7_75t_R g276(.A1(new_n331_), .A2(new_n318_), .B(new_n332_), .Y(new_n335_));
  NOR2x1_ASAP7_75t_R  g277(.A(new_n334_), .B(new_n335_), .Y(o18));
  NAND2x1_ASAP7_75t_R g278(.A(p20), .B(new_n318_), .Y(new_n337_));
  AOI21x1_ASAP7_75t_R g279(.A1(new_n150_), .A2(new_n337_), .B(new_n136_), .Y(o19));
  AND3x1_ASAP7_75t_R  g280(.A(new_n269_), .B(p12), .C(new_n315_), .Y(new_n339_));
  OA21x2_ASAP7_75t_R  g281(.A1(new_n131_), .A2(new_n339_), .B(new_n137_), .Y(o20));
  NOR2x1_ASAP7_75t_R  g282(.A(new_n177_), .B(new_n165_), .Y(new_n341_));
  INVx1_ASAP7_75t_R   g283(.A(new_n167_), .Y(new_n342_));
  AND3x1_ASAP7_75t_R  g284(.A(new_n269_), .B(new_n342_), .C(new_n315_), .Y(new_n343_));
  OA21x2_ASAP7_75t_R  g285(.A1(new_n341_), .A2(new_n343_), .B(new_n137_), .Y(o21));
  OAI21x1_ASAP7_75t_R g286(.A1(p1), .A2(p31), .B(new_n250_), .Y(new_n345_));
  AOI21x1_ASAP7_75t_R g287(.A1(new_n266_), .A2(new_n269_), .B(new_n345_), .Y(new_n346_));
  AND2x2_ASAP7_75t_R  g288(.A(new_n151_), .B(new_n124_), .Y(new_n347_));
  NAND3x1_ASAP7_75t_R g289(.A(new_n347_), .B(new_n264_), .C(new_n345_), .Y(new_n348_));
  NAND3x1_ASAP7_75t_R g290(.A(new_n317_), .B(new_n94_), .C(new_n221_), .Y(new_n349_));
  AO21x1_ASAP7_75t_R  g291(.A1(p31), .A2(p30), .B(p1), .Y(new_n350_));
  INVx1_ASAP7_75t_R   g292(.A(new_n350_), .Y(new_n351_));
  OAI21x1_ASAP7_75t_R g293(.A1(new_n348_), .A2(new_n349_), .B(new_n351_), .Y(new_n352_));
  OAI21x1_ASAP7_75t_R g294(.A1(new_n93_), .A2(new_n319_), .B(new_n221_), .Y(new_n353_));
  AOI21x1_ASAP7_75t_R g295(.A1(new_n245_), .A2(new_n243_), .B(new_n267_), .Y(new_n354_));
  NOR3x1_ASAP7_75t_R  g296(.A(new_n353_), .B(new_n354_), .C(new_n348_), .Y(new_n355_));
  OAI21x1_ASAP7_75t_R g297(.A1(new_n355_), .A2(new_n346_), .B(new_n350_), .Y(new_n356_));
  OAI21x1_ASAP7_75t_R g298(.A1(new_n346_), .A2(new_n352_), .B(new_n356_), .Y(o22));
  NOR2x1_ASAP7_75t_R  g299(.A(p1), .B(p28), .Y(new_n358_));
  NOR2x1_ASAP7_75t_R  g300(.A(new_n104_), .B(new_n101_), .Y(new_n359_));
  XOR2x2_ASAP7_75t_R  g301(.A(new_n68_), .B(new_n359_), .Y(new_n360_));
  XNOR2x2_ASAP7_75t_R g302(.A(new_n358_), .B(new_n360_), .Y(new_n361_));
  OA21x2_ASAP7_75t_R  g303(.A1(p1), .A2(p3), .B(new_n361_), .Y(new_n362_));
  XOR2x2_ASAP7_75t_R  g304(.A(new_n277_), .B(new_n362_), .Y(o23));
  OAI21x1_ASAP7_75t_R g305(.A1(new_n215_), .A2(new_n326_), .B(new_n137_), .Y(new_n364_));
  AOI21x1_ASAP7_75t_R g306(.A1(new_n217_), .A2(new_n216_), .B(new_n364_), .Y(o24));
endmodule


