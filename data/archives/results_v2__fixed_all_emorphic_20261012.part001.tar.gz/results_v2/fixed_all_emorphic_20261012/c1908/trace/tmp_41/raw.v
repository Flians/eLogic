// Benchmark "/tmp/" written by ABC on Mon Oct 12 15:05:29 2026

module \/tmp/  ( 
    p13, p2, p29, p31, p10, p17, p28, p23, p24, p19, p11, p6, p27, p8, p25,
    p14, p9, p21, p22, p5, p18, p20, p32, p7, p30, p0, p3, p15, p4, p12,
    p26, p1, p16,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24  );
  input  p13, p2, p29, p31, p10, p17, p28, p23, p24, p19, p11, p6, p27,
    p8, p25, p14, p9, p21, p22, p5, p18, p20, p32, p7, p30, p0, p3, p15,
    p4, p12, p26, p1, p16;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24;
  wire new_n59_, new_n60_, new_n61_, new_n62_, new_n63_, new_n64_, new_n65_,
    new_n66_, new_n67_, new_n68_, new_n69_, new_n70_, new_n71_, new_n72_,
    new_n73_, new_n74_, new_n75_, new_n76_, new_n77_, new_n78_, new_n79_,
    new_n80_, new_n81_, new_n82_, new_n83_, new_n84_, new_n85_, new_n86_,
    new_n87_, new_n88_, new_n89_, new_n90_, new_n91_, new_n92_, new_n93_,
    new_n94_, new_n95_, new_n96_, new_n97_, new_n98_, new_n99_, new_n100_,
    new_n101_, new_n102_, new_n103_, new_n104_, new_n105_, new_n106_,
    new_n107_, new_n108_, new_n109_, new_n110_, new_n111_, new_n112_,
    new_n113_, new_n114_, new_n115_, new_n116_, new_n117_, new_n118_,
    new_n119_, new_n120_, new_n121_, new_n122_, new_n123_, new_n124_,
    new_n125_, new_n126_, new_n127_, new_n128_, new_n129_, new_n130_,
    new_n131_, new_n132_, new_n133_, new_n134_, new_n135_, new_n136_,
    new_n137_, new_n138_, new_n139_, new_n140_, new_n141_, new_n142_,
    new_n143_, new_n144_, new_n145_, new_n146_, new_n147_, new_n148_,
    new_n149_, new_n150_, new_n151_, new_n152_, new_n153_, new_n154_,
    new_n155_, new_n156_, new_n157_, new_n158_, new_n159_, new_n160_,
    new_n161_, new_n162_, new_n163_, new_n164_, new_n165_, new_n166_,
    new_n167_, new_n168_, new_n169_, new_n170_, new_n171_, new_n172_,
    new_n173_, new_n174_, new_n175_, new_n176_, new_n177_, new_n178_,
    new_n179_, new_n180_, new_n181_, new_n182_, new_n183_, new_n184_,
    new_n185_, new_n186_, new_n187_, new_n188_, new_n189_, new_n190_,
    new_n191_, new_n192_, new_n193_, new_n194_, new_n195_, new_n196_,
    new_n197_, new_n198_, new_n199_, new_n200_, new_n201_, new_n202_,
    new_n203_, new_n204_, new_n205_, new_n206_, new_n207_, new_n208_,
    new_n209_, new_n210_, new_n211_, new_n212_, new_n213_, new_n214_,
    new_n215_, new_n216_, new_n217_, new_n218_, new_n219_, new_n220_,
    new_n221_, new_n222_, new_n223_, new_n224_, new_n225_, new_n226_,
    new_n227_, new_n228_, new_n229_, new_n230_, new_n231_, new_n232_,
    new_n233_, new_n234_, new_n235_, new_n236_, new_n237_, new_n238_,
    new_n239_, new_n240_, new_n241_, new_n242_, new_n243_, new_n244_,
    new_n245_, new_n246_, new_n247_, new_n248_, new_n249_, new_n250_,
    new_n252_, new_n253_, new_n254_, new_n255_, new_n256_, new_n257_,
    new_n258_, new_n259_, new_n260_, new_n261_, new_n262_, new_n263_,
    new_n266_, new_n267_, new_n271_, new_n272_, new_n273_, new_n277_,
    new_n278_, new_n279_, new_n280_, new_n281_, new_n282_, new_n283_,
    new_n284_, new_n285_, new_n286_, new_n288_, new_n289_, new_n291_,
    new_n292_, new_n294_, new_n295_, new_n296_, new_n298_, new_n299_,
    new_n300_, new_n301_, new_n303_, new_n304_, new_n305_, new_n307_,
    new_n308_, new_n309_, new_n311_, new_n312_, new_n313_, new_n314_,
    new_n315_, new_n316_, new_n317_, new_n318_, new_n320_, new_n321_,
    new_n322_, new_n323_, new_n324_, new_n325_, new_n327_, new_n328_,
    new_n329_, new_n330_, new_n332_, new_n334_, new_n336_, new_n337_,
    new_n339_, new_n340_, new_n341_, new_n342_, new_n343_, new_n344_,
    new_n345_, new_n346_, new_n347_, new_n348_, new_n349_, new_n351_,
    new_n352_, new_n353_, new_n354_, new_n355_, new_n357_, new_n358_;
  INVx1_ASAP7_75t_R   g000(.A(p23), .Y(new_n59_));
  NOR2x1_ASAP7_75t_R  g001(.A(p2), .B(p32), .Y(new_n60_));
  NOR2x1_ASAP7_75t_R  g002(.A(new_n59_), .B(new_n60_), .Y(new_n61_));
  INVx1_ASAP7_75t_R   g003(.A(new_n61_), .Y(new_n62_));
  XOR2x2_ASAP7_75t_R  g004(.A(p14), .B(p22), .Y(new_n63_));
  INVx1_ASAP7_75t_R   g005(.A(p28), .Y(new_n64_));
  NOR2x1_ASAP7_75t_R  g006(.A(p1), .B(new_n64_), .Y(new_n65_));
  XOR2x2_ASAP7_75t_R  g007(.A(new_n63_), .B(new_n65_), .Y(new_n66_));
  INVx1_ASAP7_75t_R   g008(.A(p7), .Y(new_n67_));
  NOR2x1_ASAP7_75t_R  g009(.A(p25), .B(new_n67_), .Y(new_n68_));
  INVx1_ASAP7_75t_R   g010(.A(p25), .Y(new_n69_));
  NOR2x1_ASAP7_75t_R  g011(.A(p7), .B(new_n69_), .Y(new_n70_));
  OAI21x1_ASAP7_75t_R g012(.A1(new_n68_), .A2(new_n70_), .B(p19), .Y(new_n71_));
  NAND2x1_ASAP7_75t_R g013(.A(p7), .B(new_n69_), .Y(new_n72_));
  NAND2x1_ASAP7_75t_R g014(.A(p25), .B(new_n67_), .Y(new_n73_));
  INVx1_ASAP7_75t_R   g015(.A(p19), .Y(new_n74_));
  NAND3x1_ASAP7_75t_R g016(.A(new_n72_), .B(new_n73_), .C(new_n74_), .Y(new_n75_));
  NAND2x1_ASAP7_75t_R g017(.A(new_n71_), .B(new_n75_), .Y(new_n76_));
  XOR2x2_ASAP7_75t_R  g018(.A(new_n66_), .B(new_n76_), .Y(new_n77_));
  NOR2x1_ASAP7_75t_R  g019(.A(p10), .B(p17), .Y(new_n78_));
  AND2x2_ASAP7_75t_R  g020(.A(p10), .B(p17), .Y(new_n79_));
  OAI21x1_ASAP7_75t_R g021(.A1(new_n78_), .A2(new_n79_), .B(p24), .Y(new_n80_));
  OR3x1_ASAP7_75t_R   g022(.A(new_n79_), .B(p24), .C(new_n78_), .Y(new_n81_));
  NAND2x1_ASAP7_75t_R g023(.A(new_n80_), .B(new_n81_), .Y(new_n82_));
  AND2x2_ASAP7_75t_R  g024(.A(p8), .B(p9), .Y(new_n83_));
  NOR2x1_ASAP7_75t_R  g025(.A(p8), .B(p9), .Y(new_n84_));
  NOR3x1_ASAP7_75t_R  g026(.A(new_n83_), .B(p15), .C(new_n84_), .Y(new_n85_));
  OA21x2_ASAP7_75t_R  g027(.A1(new_n84_), .A2(new_n83_), .B(p15), .Y(new_n86_));
  NOR2x1_ASAP7_75t_R  g028(.A(new_n85_), .B(new_n86_), .Y(new_n87_));
  XNOR2x2_ASAP7_75t_R g029(.A(new_n82_), .B(new_n87_), .Y(new_n88_));
  OR3x1_ASAP7_75t_R   g030(.A(new_n77_), .B(new_n88_), .C(p2), .Y(new_n89_));
  INVx1_ASAP7_75t_R   g031(.A(p2), .Y(new_n90_));
  AO21x1_ASAP7_75t_R  g032(.A1(new_n71_), .A2(new_n75_), .B(new_n66_), .Y(new_n91_));
  NOR2x1_ASAP7_75t_R  g033(.A(p19), .B(new_n67_), .Y(new_n92_));
  AO21x1_ASAP7_75t_R  g034(.A1(p19), .A2(new_n67_), .B(new_n69_), .Y(new_n93_));
  NOR2x1_ASAP7_75t_R  g035(.A(p7), .B(new_n74_), .Y(new_n94_));
  OAI21x1_ASAP7_75t_R g036(.A1(new_n92_), .A2(new_n94_), .B(new_n69_), .Y(new_n95_));
  OAI21x1_ASAP7_75t_R g037(.A1(new_n92_), .A2(new_n93_), .B(new_n95_), .Y(new_n96_));
  NAND2x1_ASAP7_75t_R g038(.A(new_n96_), .B(new_n66_), .Y(new_n97_));
  XOR2x2_ASAP7_75t_R  g039(.A(new_n87_), .B(new_n82_), .Y(new_n98_));
  AOI21x1_ASAP7_75t_R g040(.A1(new_n91_), .A2(new_n97_), .B(new_n98_), .Y(new_n99_));
  INVx1_ASAP7_75t_R   g041(.A(p29), .Y(new_n100_));
  AOI21x1_ASAP7_75t_R g042(.A1(new_n90_), .A2(new_n99_), .B(new_n100_), .Y(new_n101_));
  NAND3x1_ASAP7_75t_R g043(.A(new_n98_), .B(new_n91_), .C(new_n97_), .Y(new_n102_));
  NAND2x1_ASAP7_75t_R g044(.A(new_n88_), .B(new_n77_), .Y(new_n103_));
  NAND2x1_ASAP7_75t_R g045(.A(new_n90_), .B(new_n100_), .Y(new_n104_));
  AOI21x1_ASAP7_75t_R g046(.A1(new_n102_), .A2(new_n103_), .B(new_n104_), .Y(new_n105_));
  AOI21x1_ASAP7_75t_R g047(.A1(new_n89_), .A2(new_n101_), .B(new_n105_), .Y(new_n106_));
  OAI21x1_ASAP7_75t_R g048(.A1(p13), .A2(p14), .B(p15), .Y(new_n107_));
  AND2x2_ASAP7_75t_R  g049(.A(p13), .B(p14), .Y(new_n108_));
  NOR2x1_ASAP7_75t_R  g050(.A(new_n107_), .B(new_n108_), .Y(new_n109_));
  NAND2x1_ASAP7_75t_R g051(.A(p13), .B(p14), .Y(new_n110_));
  OR3x1_ASAP7_75t_R   g052(.A(p13), .B(p14), .C(p15), .Y(new_n111_));
  OAI21x1_ASAP7_75t_R g053(.A1(p15), .A2(new_n110_), .B(new_n111_), .Y(new_n112_));
  NOR2x1_ASAP7_75t_R  g054(.A(new_n109_), .B(new_n112_), .Y(new_n113_));
  NOR2x1_ASAP7_75t_R  g055(.A(p0), .B(p1), .Y(new_n114_));
  NAND2x1_ASAP7_75t_R g056(.A(p16), .B(new_n114_), .Y(new_n115_));
  XOR2x2_ASAP7_75t_R  g057(.A(new_n115_), .B(p19), .Y(new_n116_));
  NAND2x1_ASAP7_75t_R g058(.A(new_n113_), .B(new_n116_), .Y(new_n117_));
  NOR2x1_ASAP7_75t_R  g059(.A(p13), .B(p14), .Y(new_n118_));
  INVx1_ASAP7_75t_R   g060(.A(p15), .Y(new_n119_));
  OAI21x1_ASAP7_75t_R g061(.A1(new_n118_), .A2(new_n108_), .B(new_n119_), .Y(new_n120_));
  AO21x1_ASAP7_75t_R  g062(.A1(p13), .A2(p14), .B(new_n107_), .Y(new_n121_));
  NAND2x1_ASAP7_75t_R g063(.A(new_n120_), .B(new_n121_), .Y(new_n122_));
  XOR2x2_ASAP7_75t_R  g064(.A(new_n115_), .B(new_n74_), .Y(new_n123_));
  NAND2x1_ASAP7_75t_R g065(.A(new_n122_), .B(new_n123_), .Y(new_n124_));
  XOR2x2_ASAP7_75t_R  g066(.A(p5), .B(p18), .Y(new_n125_));
  XOR2x2_ASAP7_75t_R  g067(.A(p17), .B(p8), .Y(new_n126_));
  XOR2x2_ASAP7_75t_R  g068(.A(new_n125_), .B(new_n126_), .Y(new_n127_));
  NAND3x1_ASAP7_75t_R g069(.A(new_n117_), .B(new_n124_), .C(new_n127_), .Y(new_n128_));
  AO21x1_ASAP7_75t_R  g070(.A1(new_n117_), .A2(new_n124_), .B(new_n127_), .Y(new_n129_));
  NAND2x1_ASAP7_75t_R g071(.A(new_n128_), .B(new_n129_), .Y(new_n130_));
  INVx1_ASAP7_75t_R   g072(.A(p20), .Y(new_n131_));
  AO21x1_ASAP7_75t_R  g073(.A1(new_n90_), .A2(new_n130_), .B(new_n131_), .Y(new_n132_));
  XNOR2x2_ASAP7_75t_R g074(.A(p10), .B(p7), .Y(new_n133_));
  XOR2x2_ASAP7_75t_R  g075(.A(p6), .B(p5), .Y(new_n134_));
  XOR2x2_ASAP7_75t_R  g076(.A(new_n133_), .B(new_n134_), .Y(new_n135_));
  XOR2x2_ASAP7_75t_R  g077(.A(p8), .B(p9), .Y(new_n136_));
  NOR2x1_ASAP7_75t_R  g078(.A(p32), .B(p1), .Y(new_n137_));
  NAND2x1_ASAP7_75t_R g079(.A(p11), .B(new_n137_), .Y(new_n138_));
  XOR2x2_ASAP7_75t_R  g080(.A(new_n136_), .B(new_n138_), .Y(new_n139_));
  XOR2x2_ASAP7_75t_R  g081(.A(new_n135_), .B(new_n139_), .Y(new_n140_));
  NAND3x1_ASAP7_75t_R g082(.A(new_n140_), .B(new_n90_), .C(p12), .Y(new_n141_));
  AO21x1_ASAP7_75t_R  g083(.A1(new_n90_), .A2(new_n140_), .B(p12), .Y(new_n142_));
  NAND2x1_ASAP7_75t_R g084(.A(new_n141_), .B(new_n142_), .Y(new_n143_));
  NOR2x1_ASAP7_75t_R  g085(.A(p2), .B(p20), .Y(new_n144_));
  OR3x1_ASAP7_75t_R   g086(.A(p2), .B(p3), .C(p1), .Y(new_n145_));
  NOR2x1_ASAP7_75t_R  g087(.A(p4), .B(p1), .Y(new_n146_));
  INVx1_ASAP7_75t_R   g088(.A(new_n146_), .Y(new_n147_));
  INVx1_ASAP7_75t_R   g089(.A(p0), .Y(new_n148_));
  NOR2x1_ASAP7_75t_R  g090(.A(p32), .B(new_n148_), .Y(new_n149_));
  AO21x1_ASAP7_75t_R  g091(.A1(new_n145_), .A2(new_n147_), .B(new_n149_), .Y(new_n150_));
  AOI21x1_ASAP7_75t_R g092(.A1(new_n144_), .A2(new_n130_), .B(new_n150_), .Y(new_n151_));
  AND3x1_ASAP7_75t_R  g093(.A(new_n132_), .B(new_n143_), .C(new_n151_), .Y(new_n152_));
  OA21x2_ASAP7_75t_R  g094(.A1(new_n62_), .A2(new_n106_), .B(new_n152_), .Y(new_n153_));
  INVx1_ASAP7_75t_R   g095(.A(p21), .Y(new_n154_));
  NOR2x1_ASAP7_75t_R  g096(.A(p6), .B(new_n154_), .Y(new_n155_));
  INVx1_ASAP7_75t_R   g097(.A(p18), .Y(new_n156_));
  AO21x1_ASAP7_75t_R  g098(.A1(p6), .A2(new_n154_), .B(new_n156_), .Y(new_n157_));
  INVx1_ASAP7_75t_R   g099(.A(p6), .Y(new_n158_));
  NOR2x1_ASAP7_75t_R  g100(.A(p21), .B(new_n158_), .Y(new_n159_));
  OAI21x1_ASAP7_75t_R g101(.A1(new_n155_), .A2(new_n159_), .B(new_n156_), .Y(new_n160_));
  OAI21x1_ASAP7_75t_R g102(.A1(new_n155_), .A2(new_n157_), .B(new_n160_), .Y(new_n161_));
  NAND2x1_ASAP7_75t_R g103(.A(new_n161_), .B(new_n76_), .Y(new_n162_));
  NOR2x1_ASAP7_75t_R  g104(.A(p21), .B(new_n156_), .Y(new_n163_));
  NOR2x1_ASAP7_75t_R  g105(.A(p18), .B(new_n154_), .Y(new_n164_));
  OA21x2_ASAP7_75t_R  g106(.A1(new_n163_), .A2(new_n164_), .B(p6), .Y(new_n165_));
  NAND2x1_ASAP7_75t_R g107(.A(p18), .B(new_n154_), .Y(new_n166_));
  NAND2x1_ASAP7_75t_R g108(.A(p21), .B(new_n156_), .Y(new_n167_));
  AND3x1_ASAP7_75t_R  g109(.A(new_n166_), .B(new_n167_), .C(new_n158_), .Y(new_n168_));
  OAI21x1_ASAP7_75t_R g110(.A1(new_n165_), .A2(new_n168_), .B(new_n96_), .Y(new_n169_));
  XNOR2x2_ASAP7_75t_R g111(.A(p22), .B(p5), .Y(new_n170_));
  NAND3x1_ASAP7_75t_R g112(.A(new_n162_), .B(new_n169_), .C(new_n170_), .Y(new_n171_));
  OAI21x1_ASAP7_75t_R g113(.A1(new_n163_), .A2(new_n164_), .B(p6), .Y(new_n172_));
  NAND3x1_ASAP7_75t_R g114(.A(new_n166_), .B(new_n167_), .C(new_n158_), .Y(new_n173_));
  NAND2x1_ASAP7_75t_R g115(.A(new_n172_), .B(new_n173_), .Y(new_n174_));
  NOR2x1_ASAP7_75t_R  g116(.A(new_n96_), .B(new_n174_), .Y(new_n175_));
  NOR2x1_ASAP7_75t_R  g117(.A(new_n161_), .B(new_n76_), .Y(new_n176_));
  INVx1_ASAP7_75t_R   g118(.A(new_n170_), .Y(new_n177_));
  OAI21x1_ASAP7_75t_R g119(.A1(new_n175_), .A2(new_n176_), .B(new_n177_), .Y(new_n178_));
  INVx1_ASAP7_75t_R   g120(.A(p1), .Y(new_n179_));
  NAND2x1_ASAP7_75t_R g121(.A(p30), .B(new_n179_), .Y(new_n180_));
  XOR2x2_ASAP7_75t_R  g122(.A(new_n180_), .B(p13), .Y(new_n181_));
  XOR2x2_ASAP7_75t_R  g123(.A(new_n87_), .B(new_n181_), .Y(new_n182_));
  AOI21x1_ASAP7_75t_R g124(.A1(new_n171_), .A2(new_n178_), .B(new_n182_), .Y(new_n183_));
  NAND3x1_ASAP7_75t_R g125(.A(new_n162_), .B(new_n169_), .C(new_n177_), .Y(new_n184_));
  OAI21x1_ASAP7_75t_R g126(.A1(new_n175_), .A2(new_n176_), .B(new_n170_), .Y(new_n185_));
  XNOR2x2_ASAP7_75t_R g127(.A(new_n181_), .B(new_n87_), .Y(new_n186_));
  AOI21x1_ASAP7_75t_R g128(.A1(new_n184_), .A2(new_n185_), .B(new_n186_), .Y(new_n187_));
  INVx1_ASAP7_75t_R   g129(.A(p26), .Y(new_n188_));
  OA21x2_ASAP7_75t_R  g130(.A1(new_n148_), .A2(new_n188_), .B(new_n90_), .Y(new_n189_));
  OAI21x1_ASAP7_75t_R g131(.A1(new_n183_), .A2(new_n187_), .B(new_n189_), .Y(new_n190_));
  AO21x1_ASAP7_75t_R  g132(.A1(new_n90_), .A2(new_n148_), .B(new_n188_), .Y(new_n191_));
  INVx1_ASAP7_75t_R   g133(.A(new_n191_), .Y(new_n192_));
  OAI21x1_ASAP7_75t_R g134(.A1(new_n183_), .A2(new_n187_), .B(new_n90_), .Y(new_n193_));
  NAND2x1_ASAP7_75t_R g135(.A(new_n192_), .B(new_n193_), .Y(new_n194_));
  AND2x2_ASAP7_75t_R  g136(.A(new_n190_), .B(new_n194_), .Y(new_n195_));
  OA21x2_ASAP7_75t_R  g137(.A1(p2), .A2(p0), .B(p16), .Y(new_n196_));
  AOI21x1_ASAP7_75t_R g138(.A1(p26), .A2(new_n114_), .B(new_n69_), .Y(new_n197_));
  AND3x1_ASAP7_75t_R  g139(.A(new_n114_), .B(new_n69_), .C(p26), .Y(new_n198_));
  NOR2x1_ASAP7_75t_R  g140(.A(new_n197_), .B(new_n198_), .Y(new_n199_));
  XOR2x2_ASAP7_75t_R  g141(.A(new_n161_), .B(new_n199_), .Y(new_n200_));
  NAND2x1_ASAP7_75t_R g142(.A(new_n200_), .B(new_n88_), .Y(new_n201_));
  XOR2x2_ASAP7_75t_R  g143(.A(new_n174_), .B(new_n199_), .Y(new_n202_));
  NAND2x1_ASAP7_75t_R g144(.A(new_n98_), .B(new_n202_), .Y(new_n203_));
  INVx1_ASAP7_75t_R   g145(.A(p27), .Y(new_n204_));
  NOR2x1_ASAP7_75t_R  g146(.A(p2), .B(new_n204_), .Y(new_n205_));
  NAND3x1_ASAP7_75t_R g147(.A(new_n201_), .B(new_n203_), .C(new_n205_), .Y(new_n206_));
  NAND3x1_ASAP7_75t_R g148(.A(new_n88_), .B(new_n202_), .C(new_n90_), .Y(new_n207_));
  NAND3x1_ASAP7_75t_R g149(.A(new_n200_), .B(new_n98_), .C(new_n90_), .Y(new_n208_));
  NAND3x1_ASAP7_75t_R g150(.A(new_n207_), .B(new_n208_), .C(new_n204_), .Y(new_n209_));
  NOR3x1_ASAP7_75t_R  g151(.A(new_n112_), .B(p22), .C(new_n109_), .Y(new_n210_));
  INVx1_ASAP7_75t_R   g152(.A(p22), .Y(new_n211_));
  AOI21x1_ASAP7_75t_R g153(.A1(new_n120_), .A2(new_n121_), .B(new_n211_), .Y(new_n212_));
  NOR2x1_ASAP7_75t_R  g154(.A(p24), .B(new_n59_), .Y(new_n213_));
  INVx1_ASAP7_75t_R   g155(.A(p24), .Y(new_n214_));
  AOI21x1_ASAP7_75t_R g156(.A1(p23), .A2(new_n137_), .B(new_n214_), .Y(new_n215_));
  AOI21x1_ASAP7_75t_R g157(.A1(new_n137_), .A2(new_n213_), .B(new_n215_), .Y(new_n216_));
  OAI21x1_ASAP7_75t_R g158(.A1(new_n210_), .A2(new_n212_), .B(new_n216_), .Y(new_n217_));
  NAND3x1_ASAP7_75t_R g159(.A(new_n121_), .B(new_n120_), .C(new_n211_), .Y(new_n218_));
  OAI21x1_ASAP7_75t_R g160(.A1(new_n109_), .A2(new_n112_), .B(p22), .Y(new_n219_));
  AO21x1_ASAP7_75t_R  g161(.A1(new_n137_), .A2(new_n213_), .B(new_n215_), .Y(new_n220_));
  NAND3x1_ASAP7_75t_R g162(.A(new_n218_), .B(new_n219_), .C(new_n220_), .Y(new_n221_));
  XNOR2x2_ASAP7_75t_R g163(.A(p9), .B(p21), .Y(new_n222_));
  NAND3x1_ASAP7_75t_R g164(.A(new_n217_), .B(new_n221_), .C(new_n222_), .Y(new_n223_));
  OA21x2_ASAP7_75t_R  g165(.A1(p2), .A2(p32), .B(p11), .Y(new_n224_));
  NAND2x1_ASAP7_75t_R g166(.A(p23), .B(new_n137_), .Y(new_n225_));
  XOR2x2_ASAP7_75t_R  g167(.A(p24), .B(p22), .Y(new_n226_));
  NAND2x1_ASAP7_75t_R g168(.A(new_n225_), .B(new_n226_), .Y(new_n227_));
  INVx1_ASAP7_75t_R   g169(.A(new_n137_), .Y(new_n228_));
  OR3x1_ASAP7_75t_R   g170(.A(new_n226_), .B(new_n59_), .C(new_n228_), .Y(new_n229_));
  AOI21x1_ASAP7_75t_R g171(.A1(new_n227_), .A2(new_n229_), .B(new_n113_), .Y(new_n230_));
  NOR2x1_ASAP7_75t_R  g172(.A(new_n225_), .B(new_n226_), .Y(new_n231_));
  AND2x2_ASAP7_75t_R  g173(.A(new_n225_), .B(new_n226_), .Y(new_n232_));
  NOR3x1_ASAP7_75t_R  g174(.A(new_n122_), .B(new_n231_), .C(new_n232_), .Y(new_n233_));
  INVx1_ASAP7_75t_R   g175(.A(new_n222_), .Y(new_n234_));
  OAI21x1_ASAP7_75t_R g176(.A1(new_n230_), .A2(new_n233_), .B(new_n234_), .Y(new_n235_));
  NAND3x1_ASAP7_75t_R g177(.A(new_n223_), .B(new_n224_), .C(new_n235_), .Y(new_n236_));
  OAI21x1_ASAP7_75t_R g178(.A1(new_n231_), .A2(new_n232_), .B(new_n122_), .Y(new_n237_));
  NAND3x1_ASAP7_75t_R g179(.A(new_n113_), .B(new_n229_), .C(new_n227_), .Y(new_n238_));
  AO21x1_ASAP7_75t_R  g180(.A1(new_n237_), .A2(new_n238_), .B(new_n234_), .Y(new_n239_));
  NAND3x1_ASAP7_75t_R g181(.A(new_n238_), .B(new_n237_), .C(new_n234_), .Y(new_n240_));
  NOR2x1_ASAP7_75t_R  g182(.A(p2), .B(new_n224_), .Y(new_n241_));
  NAND3x1_ASAP7_75t_R g183(.A(new_n239_), .B(new_n240_), .C(new_n241_), .Y(new_n242_));
  AND2x2_ASAP7_75t_R  g184(.A(p2), .B(p11), .Y(new_n243_));
  INVx1_ASAP7_75t_R   g185(.A(new_n243_), .Y(new_n244_));
  NAND3x1_ASAP7_75t_R g186(.A(new_n236_), .B(new_n242_), .C(new_n244_), .Y(new_n245_));
  AOI21x1_ASAP7_75t_R g187(.A1(new_n206_), .A2(new_n209_), .B(new_n245_), .Y(new_n246_));
  AND3x1_ASAP7_75t_R  g188(.A(new_n195_), .B(new_n196_), .C(new_n246_), .Y(new_n247_));
  INVx1_ASAP7_75t_R   g189(.A(p14), .Y(new_n248_));
  AOI21x1_ASAP7_75t_R g190(.A1(new_n153_), .A2(new_n247_), .B(new_n248_), .Y(new_n249_));
  AND3x1_ASAP7_75t_R  g191(.A(new_n247_), .B(new_n248_), .C(new_n153_), .Y(new_n250_));
  NOR2x1_ASAP7_75t_R  g192(.A(new_n249_), .B(new_n250_), .Y(o0));
  INVx1_ASAP7_75t_R   g193(.A(new_n196_), .Y(new_n252_));
  AOI21x1_ASAP7_75t_R g194(.A1(new_n190_), .A2(new_n194_), .B(new_n252_), .Y(new_n253_));
  OAI21x1_ASAP7_75t_R g195(.A1(new_n62_), .A2(new_n106_), .B(new_n246_), .Y(new_n254_));
  OR3x1_ASAP7_75t_R   g196(.A(new_n149_), .B(p4), .C(p1), .Y(new_n255_));
  NOR2x1_ASAP7_75t_R  g197(.A(p31), .B(p1), .Y(new_n256_));
  INVx1_ASAP7_75t_R   g198(.A(new_n256_), .Y(new_n257_));
  OR3x1_ASAP7_75t_R   g199(.A(new_n257_), .B(new_n149_), .C(p2), .Y(new_n258_));
  AND2x2_ASAP7_75t_R  g200(.A(new_n255_), .B(new_n258_), .Y(new_n259_));
  AOI21x1_ASAP7_75t_R g201(.A1(new_n141_), .A2(new_n142_), .B(new_n259_), .Y(new_n260_));
  NAND2x1_ASAP7_75t_R g202(.A(new_n144_), .B(new_n130_), .Y(new_n261_));
  NAND3x1_ASAP7_75t_R g203(.A(new_n260_), .B(new_n132_), .C(new_n261_), .Y(new_n262_));
  NOR3x1_ASAP7_75t_R  g204(.A(new_n253_), .B(new_n254_), .C(new_n262_), .Y(new_n263_));
  XOR2x2_ASAP7_75t_R  g205(.A(new_n263_), .B(new_n69_), .Y(o1));
  XOR2x2_ASAP7_75t_R  g206(.A(new_n263_), .B(new_n74_), .Y(o2));
  AOI21x1_ASAP7_75t_R g207(.A1(new_n153_), .A2(new_n247_), .B(new_n214_), .Y(new_n266_));
  AND3x1_ASAP7_75t_R  g208(.A(new_n247_), .B(new_n214_), .C(new_n153_), .Y(new_n267_));
  NOR2x1_ASAP7_75t_R  g209(.A(new_n266_), .B(new_n267_), .Y(o3));
  XOR2x2_ASAP7_75t_R  g210(.A(new_n263_), .B(new_n67_), .Y(o4));
  XOR2x2_ASAP7_75t_R  g211(.A(new_n263_), .B(new_n211_), .Y(o5));
  NAND2x1_ASAP7_75t_R g212(.A(new_n190_), .B(new_n194_), .Y(new_n271_));
  AOI21x1_ASAP7_75t_R g213(.A1(new_n196_), .A2(new_n271_), .B(new_n254_), .Y(new_n272_));
  NAND2x1_ASAP7_75t_R g214(.A(new_n152_), .B(new_n272_), .Y(new_n273_));
  XOR2x2_ASAP7_75t_R  g215(.A(new_n273_), .B(p9), .Y(o6));
  XOR2x2_ASAP7_75t_R  g216(.A(new_n273_), .B(p8), .Y(o7));
  XOR2x2_ASAP7_75t_R  g217(.A(new_n273_), .B(p15), .Y(o8));
  AND3x1_ASAP7_75t_R  g218(.A(new_n132_), .B(new_n143_), .C(new_n261_), .Y(new_n277_));
  INVx1_ASAP7_75t_R   g219(.A(new_n259_), .Y(new_n278_));
  AND3x1_ASAP7_75t_R  g220(.A(new_n277_), .B(new_n156_), .C(new_n278_), .Y(new_n279_));
  AND2x2_ASAP7_75t_R  g221(.A(new_n61_), .B(new_n106_), .Y(new_n280_));
  INVx1_ASAP7_75t_R   g222(.A(new_n246_), .Y(new_n281_));
  NOR2x1_ASAP7_75t_R  g223(.A(new_n281_), .B(new_n253_), .Y(new_n282_));
  AND2x2_ASAP7_75t_R  g224(.A(new_n280_), .B(new_n282_), .Y(new_n283_));
  AND3x1_ASAP7_75t_R  g225(.A(new_n260_), .B(new_n132_), .C(new_n261_), .Y(new_n284_));
  AND3x1_ASAP7_75t_R  g226(.A(new_n284_), .B(new_n61_), .C(new_n106_), .Y(new_n285_));
  AOI21x1_ASAP7_75t_R g227(.A1(new_n285_), .A2(new_n282_), .B(new_n156_), .Y(new_n286_));
  AOI21x1_ASAP7_75t_R g228(.A1(new_n279_), .A2(new_n283_), .B(new_n286_), .Y(o9));
  NOR2x1_ASAP7_75t_R  g229(.A(p6), .B(new_n262_), .Y(new_n288_));
  AOI21x1_ASAP7_75t_R g230(.A1(new_n285_), .A2(new_n282_), .B(new_n158_), .Y(new_n289_));
  AOI21x1_ASAP7_75t_R g231(.A1(new_n288_), .A2(new_n283_), .B(new_n289_), .Y(o10));
  NOR2x1_ASAP7_75t_R  g232(.A(p21), .B(new_n262_), .Y(new_n291_));
  AOI21x1_ASAP7_75t_R g233(.A1(new_n285_), .A2(new_n282_), .B(new_n154_), .Y(new_n292_));
  AOI21x1_ASAP7_75t_R g234(.A1(new_n291_), .A2(new_n283_), .B(new_n292_), .Y(o11));
  INVx1_ASAP7_75t_R   g235(.A(p5), .Y(new_n294_));
  AND3x1_ASAP7_75t_R  g236(.A(new_n277_), .B(new_n294_), .C(new_n278_), .Y(new_n295_));
  AOI21x1_ASAP7_75t_R g237(.A1(new_n285_), .A2(new_n282_), .B(new_n294_), .Y(new_n296_));
  AOI21x1_ASAP7_75t_R g238(.A1(new_n295_), .A2(new_n283_), .B(new_n296_), .Y(o12));
  AND3x1_ASAP7_75t_R  g239(.A(new_n282_), .B(new_n152_), .C(new_n280_), .Y(new_n298_));
  AND2x2_ASAP7_75t_R  g240(.A(p13), .B(new_n151_), .Y(new_n299_));
  AND3x1_ASAP7_75t_R  g241(.A(new_n299_), .B(new_n132_), .C(new_n143_), .Y(new_n300_));
  NAND3x1_ASAP7_75t_R g242(.A(new_n282_), .B(new_n280_), .C(new_n300_), .Y(new_n301_));
  OAI21x1_ASAP7_75t_R g243(.A1(p13), .A2(new_n298_), .B(new_n301_), .Y(o13));
  INVx1_ASAP7_75t_R   g244(.A(p17), .Y(new_n303_));
  AOI21x1_ASAP7_75t_R g245(.A1(new_n153_), .A2(new_n247_), .B(new_n303_), .Y(new_n304_));
  AND3x1_ASAP7_75t_R  g246(.A(new_n247_), .B(new_n303_), .C(new_n153_), .Y(new_n305_));
  NOR2x1_ASAP7_75t_R  g247(.A(new_n304_), .B(new_n305_), .Y(o14));
  INVx1_ASAP7_75t_R   g248(.A(p10), .Y(new_n307_));
  AOI21x1_ASAP7_75t_R g249(.A1(new_n153_), .A2(new_n247_), .B(new_n307_), .Y(new_n308_));
  AND3x1_ASAP7_75t_R  g250(.A(new_n247_), .B(new_n307_), .C(new_n153_), .Y(new_n309_));
  NOR2x1_ASAP7_75t_R  g251(.A(new_n308_), .B(new_n309_), .Y(o15));
  INVx1_ASAP7_75t_R   g252(.A(p4), .Y(new_n311_));
  AND3x1_ASAP7_75t_R  g253(.A(new_n258_), .B(new_n150_), .C(new_n255_), .Y(new_n312_));
  AOI21x1_ASAP7_75t_R g254(.A1(new_n144_), .A2(new_n130_), .B(new_n312_), .Y(new_n313_));
  NAND3x1_ASAP7_75t_R g255(.A(new_n132_), .B(new_n143_), .C(new_n313_), .Y(new_n314_));
  OR3x1_ASAP7_75t_R   g256(.A(new_n253_), .B(new_n254_), .C(new_n314_), .Y(new_n315_));
  AND3x1_ASAP7_75t_R  g257(.A(new_n106_), .B(new_n252_), .C(new_n62_), .Y(new_n316_));
  AND3x1_ASAP7_75t_R  g258(.A(new_n316_), .B(new_n277_), .C(new_n246_), .Y(new_n317_));
  AOI21x1_ASAP7_75t_R g259(.A1(new_n195_), .A2(new_n317_), .B(p1), .Y(new_n318_));
  OAI21x1_ASAP7_75t_R g260(.A1(new_n311_), .A2(new_n315_), .B(new_n318_), .Y(o16));
  NOR2x1_ASAP7_75t_R  g261(.A(new_n191_), .B(new_n193_), .Y(new_n320_));
  NOR3x1_ASAP7_75t_R  g262(.A(new_n253_), .B(new_n254_), .C(new_n314_), .Y(new_n321_));
  AO21x1_ASAP7_75t_R  g263(.A1(new_n320_), .A2(new_n321_), .B(new_n146_), .Y(new_n322_));
  OR3x1_ASAP7_75t_R   g264(.A(new_n148_), .B(new_n188_), .C(p2), .Y(new_n323_));
  NOR2x1_ASAP7_75t_R  g265(.A(new_n183_), .B(new_n187_), .Y(new_n324_));
  OA21x2_ASAP7_75t_R  g266(.A1(new_n323_), .A2(new_n315_), .B(new_n324_), .Y(new_n325_));
  NOR2x1_ASAP7_75t_R  g267(.A(new_n322_), .B(new_n325_), .Y(o17));
  NOR2x1_ASAP7_75t_R  g268(.A(p2), .B(new_n100_), .Y(new_n327_));
  NAND2x1_ASAP7_75t_R g269(.A(new_n102_), .B(new_n103_), .Y(new_n328_));
  AO21x1_ASAP7_75t_R  g270(.A1(new_n327_), .A2(new_n321_), .B(new_n328_), .Y(new_n329_));
  NAND3x1_ASAP7_75t_R g271(.A(new_n321_), .B(new_n328_), .C(new_n327_), .Y(new_n330_));
  AND3x1_ASAP7_75t_R  g272(.A(new_n329_), .B(new_n147_), .C(new_n330_), .Y(o18));
  NAND2x1_ASAP7_75t_R g273(.A(p20), .B(new_n321_), .Y(new_n332_));
  AOI21x1_ASAP7_75t_R g274(.A1(new_n130_), .A2(new_n332_), .B(new_n146_), .Y(o19));
  NAND2x1_ASAP7_75t_R g275(.A(p12), .B(new_n321_), .Y(new_n334_));
  AOI21x1_ASAP7_75t_R g276(.A1(new_n140_), .A2(new_n334_), .B(new_n146_), .Y(o20));
  NAND2x1_ASAP7_75t_R g277(.A(new_n240_), .B(new_n239_), .Y(new_n336_));
  AO21x1_ASAP7_75t_R  g278(.A1(new_n224_), .A2(new_n321_), .B(new_n336_), .Y(new_n337_));
  AND2x2_ASAP7_75t_R  g279(.A(new_n147_), .B(new_n337_), .Y(o21));
  AO21x1_ASAP7_75t_R  g280(.A1(p31), .A2(p30), .B(p1), .Y(new_n339_));
  INVx1_ASAP7_75t_R   g281(.A(new_n339_), .Y(new_n340_));
  OR3x1_ASAP7_75t_R   g282(.A(new_n253_), .B(new_n254_), .C(new_n262_), .Y(new_n341_));
  AND3x1_ASAP7_75t_R  g283(.A(new_n178_), .B(new_n171_), .C(new_n257_), .Y(new_n342_));
  INVx1_ASAP7_75t_R   g284(.A(new_n342_), .Y(new_n343_));
  NAND2x1_ASAP7_75t_R g285(.A(new_n343_), .B(new_n284_), .Y(new_n344_));
  NOR3x1_ASAP7_75t_R  g286(.A(new_n344_), .B(new_n254_), .C(new_n253_), .Y(new_n345_));
  AOI21x1_ASAP7_75t_R g287(.A1(new_n341_), .A2(new_n342_), .B(new_n345_), .Y(new_n346_));
  NOR2x1_ASAP7_75t_R  g288(.A(new_n342_), .B(new_n262_), .Y(new_n347_));
  AOI21x1_ASAP7_75t_R g289(.A1(new_n347_), .A2(new_n272_), .B(new_n339_), .Y(new_n348_));
  OAI21x1_ASAP7_75t_R g290(.A1(new_n263_), .A2(new_n343_), .B(new_n348_), .Y(new_n349_));
  OAI21x1_ASAP7_75t_R g291(.A1(new_n340_), .A2(new_n346_), .B(new_n349_), .Y(o22));
  NOR2x1_ASAP7_75t_R  g292(.A(new_n118_), .B(new_n108_), .Y(new_n351_));
  XOR2x2_ASAP7_75t_R  g293(.A(new_n98_), .B(new_n351_), .Y(new_n352_));
  NOR2x1_ASAP7_75t_R  g294(.A(p28), .B(p1), .Y(new_n353_));
  XOR2x2_ASAP7_75t_R  g295(.A(new_n352_), .B(new_n353_), .Y(new_n354_));
  OA21x2_ASAP7_75t_R  g296(.A1(p3), .A2(p1), .B(new_n354_), .Y(new_n355_));
  XOR2x2_ASAP7_75t_R  g297(.A(new_n273_), .B(new_n355_), .Y(o23));
  AND3x1_ASAP7_75t_R  g298(.A(new_n201_), .B(new_n203_), .C(new_n147_), .Y(new_n357_));
  NAND2x1_ASAP7_75t_R g299(.A(new_n205_), .B(new_n321_), .Y(new_n358_));
  AND2x2_ASAP7_75t_R  g300(.A(new_n357_), .B(new_n358_), .Y(o24));
endmodule


