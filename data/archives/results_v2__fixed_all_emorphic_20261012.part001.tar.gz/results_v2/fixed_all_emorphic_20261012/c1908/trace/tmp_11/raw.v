// Benchmark "/tmp/" written by ABC on Mon Oct 12 15:05:20 2026

module \/tmp/  ( 
    p23, p2, p5, p11, p18, p21, p30, p7, p10, p19, p31, p25, p0, p1, p17,
    p24, p20, p14, p28, p3, p4, p26, p13, p12, p22, p8, p6, p32, p27, p16,
    p29, p9, p15,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24  );
  input  p23, p2, p5, p11, p18, p21, p30, p7, p10, p19, p31, p25, p0, p1,
    p17, p24, p20, p14, p28, p3, p4, p26, p13, p12, p22, p8, p6, p32, p27,
    p16, p29, p9, p15;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24;
  wire new_n59_, new_n60_, new_n61_, new_n62_, new_n63_, new_n64_, new_n65_,
    new_n66_, new_n67_, new_n68_, new_n69_, new_n70_, new_n71_, new_n72_,
    new_n73_, new_n74_, new_n75_, new_n76_, new_n77_, new_n78_, new_n79_,
    new_n80_, new_n81_, new_n82_, new_n83_, new_n84_, new_n85_, new_n86_,
    new_n87_, new_n88_, new_n89_, new_n90_, new_n91_, new_n92_, new_n93_,
    new_n94_, new_n95_, new_n96_, new_n97_, new_n98_, new_n99_, new_n100_,
    new_n101_, new_n102_, new_n103_, new_n104_, new_n105_, new_n106_,
    new_n107_, new_n108_, new_n109_, new_n110_, new_n111_, new_n112_,
    new_n113_, new_n114_, new_n115_, new_n116_, new_n117_, new_n118_,
    new_n119_, new_n120_, new_n121_, new_n122_, new_n123_, new_n124_,
    new_n125_, new_n126_, new_n127_, new_n128_, new_n129_, new_n130_,
    new_n131_, new_n132_, new_n133_, new_n134_, new_n135_, new_n136_,
    new_n137_, new_n138_, new_n139_, new_n140_, new_n141_, new_n142_,
    new_n143_, new_n144_, new_n145_, new_n146_, new_n147_, new_n148_,
    new_n149_, new_n150_, new_n151_, new_n152_, new_n153_, new_n154_,
    new_n155_, new_n156_, new_n157_, new_n158_, new_n159_, new_n160_,
    new_n161_, new_n162_, new_n163_, new_n164_, new_n165_, new_n166_,
    new_n167_, new_n168_, new_n169_, new_n170_, new_n171_, new_n172_,
    new_n173_, new_n174_, new_n175_, new_n176_, new_n177_, new_n178_,
    new_n179_, new_n180_, new_n181_, new_n182_, new_n183_, new_n184_,
    new_n185_, new_n186_, new_n187_, new_n188_, new_n189_, new_n190_,
    new_n191_, new_n192_, new_n193_, new_n194_, new_n195_, new_n196_,
    new_n197_, new_n198_, new_n199_, new_n200_, new_n201_, new_n202_,
    new_n203_, new_n204_, new_n205_, new_n206_, new_n207_, new_n208_,
    new_n209_, new_n210_, new_n211_, new_n212_, new_n213_, new_n214_,
    new_n215_, new_n216_, new_n217_, new_n218_, new_n219_, new_n220_,
    new_n221_, new_n222_, new_n223_, new_n224_, new_n225_, new_n226_,
    new_n227_, new_n228_, new_n229_, new_n230_, new_n231_, new_n232_,
    new_n233_, new_n234_, new_n235_, new_n236_, new_n237_, new_n238_,
    new_n239_, new_n240_, new_n241_, new_n243_, new_n244_, new_n245_,
    new_n246_, new_n247_, new_n248_, new_n249_, new_n250_, new_n251_,
    new_n252_, new_n253_, new_n254_, new_n255_, new_n256_, new_n257_,
    new_n260_, new_n261_, new_n265_, new_n266_, new_n270_, new_n271_,
    new_n272_, new_n273_, new_n274_, new_n275_, new_n276_, new_n277_,
    new_n278_, new_n279_, new_n280_, new_n282_, new_n283_, new_n285_,
    new_n286_, new_n288_, new_n289_, new_n291_, new_n292_, new_n293_,
    new_n294_, new_n296_, new_n297_, new_n299_, new_n300_, new_n302_,
    new_n303_, new_n304_, new_n305_, new_n306_, new_n307_, new_n308_,
    new_n310_, new_n311_, new_n312_, new_n313_, new_n314_, new_n315_,
    new_n317_, new_n318_, new_n319_, new_n320_, new_n321_, new_n322_,
    new_n324_, new_n326_, new_n328_, new_n330_, new_n331_, new_n332_,
    new_n333_, new_n334_, new_n335_, new_n336_, new_n337_, new_n338_,
    new_n339_, new_n341_, new_n342_, new_n343_, new_n344_, new_n345_,
    new_n347_, new_n348_;
  OA21x2_ASAP7_75t_R  g000(.A1(p2), .A2(p0), .B(p16), .Y(new_n59_));
  INVx1_ASAP7_75t_R   g001(.A(p7), .Y(new_n60_));
  NOR2x1_ASAP7_75t_R  g002(.A(p19), .B(new_n60_), .Y(new_n61_));
  INVx1_ASAP7_75t_R   g003(.A(p25), .Y(new_n62_));
  AO21x1_ASAP7_75t_R  g004(.A1(p19), .A2(new_n60_), .B(new_n62_), .Y(new_n63_));
  INVx1_ASAP7_75t_R   g005(.A(p19), .Y(new_n64_));
  NOR2x1_ASAP7_75t_R  g006(.A(p7), .B(new_n64_), .Y(new_n65_));
  OAI21x1_ASAP7_75t_R g007(.A1(new_n61_), .A2(new_n65_), .B(new_n62_), .Y(new_n66_));
  OAI21x1_ASAP7_75t_R g008(.A1(new_n61_), .A2(new_n63_), .B(new_n66_), .Y(new_n67_));
  INVx1_ASAP7_75t_R   g009(.A(p6), .Y(new_n68_));
  NOR2x1_ASAP7_75t_R  g010(.A(p21), .B(new_n68_), .Y(new_n69_));
  INVx1_ASAP7_75t_R   g011(.A(p21), .Y(new_n70_));
  NOR2x1_ASAP7_75t_R  g012(.A(p6), .B(new_n70_), .Y(new_n71_));
  OAI21x1_ASAP7_75t_R g013(.A1(new_n69_), .A2(new_n71_), .B(p18), .Y(new_n72_));
  NAND2x1_ASAP7_75t_R g014(.A(p6), .B(new_n70_), .Y(new_n73_));
  NAND2x1_ASAP7_75t_R g015(.A(p21), .B(new_n68_), .Y(new_n74_));
  INVx1_ASAP7_75t_R   g016(.A(p18), .Y(new_n75_));
  NAND3x1_ASAP7_75t_R g017(.A(new_n73_), .B(new_n74_), .C(new_n75_), .Y(new_n76_));
  NAND2x1_ASAP7_75t_R g018(.A(new_n72_), .B(new_n76_), .Y(new_n77_));
  NAND2x1_ASAP7_75t_R g019(.A(new_n67_), .B(new_n77_), .Y(new_n78_));
  XOR2x2_ASAP7_75t_R  g020(.A(p19), .B(p25), .Y(new_n79_));
  AND2x2_ASAP7_75t_R  g021(.A(p7), .B(new_n79_), .Y(new_n80_));
  NOR2x1_ASAP7_75t_R  g022(.A(p7), .B(new_n79_), .Y(new_n81_));
  AO21x1_ASAP7_75t_R  g023(.A1(p6), .A2(new_n70_), .B(new_n75_), .Y(new_n82_));
  OAI21x1_ASAP7_75t_R g024(.A1(new_n69_), .A2(new_n71_), .B(new_n75_), .Y(new_n83_));
  OAI21x1_ASAP7_75t_R g025(.A1(new_n71_), .A2(new_n82_), .B(new_n83_), .Y(new_n84_));
  OAI21x1_ASAP7_75t_R g026(.A1(new_n80_), .A2(new_n81_), .B(new_n84_), .Y(new_n85_));
  XNOR2x2_ASAP7_75t_R g027(.A(p5), .B(p22), .Y(new_n86_));
  NAND3x1_ASAP7_75t_R g028(.A(new_n78_), .B(new_n85_), .C(new_n86_), .Y(new_n87_));
  NOR2x1_ASAP7_75t_R  g029(.A(p19), .B(new_n62_), .Y(new_n88_));
  NOR2x1_ASAP7_75t_R  g030(.A(p25), .B(new_n64_), .Y(new_n89_));
  OAI21x1_ASAP7_75t_R g031(.A1(new_n88_), .A2(new_n89_), .B(p7), .Y(new_n90_));
  NAND2x1_ASAP7_75t_R g032(.A(p25), .B(new_n64_), .Y(new_n91_));
  NAND2x1_ASAP7_75t_R g033(.A(p19), .B(new_n62_), .Y(new_n92_));
  NAND3x1_ASAP7_75t_R g034(.A(new_n91_), .B(new_n92_), .C(new_n60_), .Y(new_n93_));
  NAND2x1_ASAP7_75t_R g035(.A(new_n90_), .B(new_n93_), .Y(new_n94_));
  NOR2x1_ASAP7_75t_R  g036(.A(new_n84_), .B(new_n94_), .Y(new_n95_));
  NOR2x1_ASAP7_75t_R  g037(.A(new_n67_), .B(new_n77_), .Y(new_n96_));
  INVx1_ASAP7_75t_R   g038(.A(new_n86_), .Y(new_n97_));
  OAI21x1_ASAP7_75t_R g039(.A1(new_n95_), .A2(new_n96_), .B(new_n97_), .Y(new_n98_));
  NOR2x1_ASAP7_75t_R  g040(.A(p8), .B(p9), .Y(new_n99_));
  AND2x2_ASAP7_75t_R  g041(.A(p8), .B(p9), .Y(new_n100_));
  INVx1_ASAP7_75t_R   g042(.A(p15), .Y(new_n101_));
  OAI21x1_ASAP7_75t_R g043(.A1(new_n99_), .A2(new_n100_), .B(new_n101_), .Y(new_n102_));
  OR3x1_ASAP7_75t_R   g044(.A(new_n100_), .B(new_n101_), .C(new_n99_), .Y(new_n103_));
  NAND2x1_ASAP7_75t_R g045(.A(new_n102_), .B(new_n103_), .Y(new_n104_));
  INVx1_ASAP7_75t_R   g046(.A(p1), .Y(new_n105_));
  NAND2x1_ASAP7_75t_R g047(.A(p30), .B(new_n105_), .Y(new_n106_));
  XOR2x2_ASAP7_75t_R  g048(.A(new_n106_), .B(p13), .Y(new_n107_));
  XOR2x2_ASAP7_75t_R  g049(.A(new_n104_), .B(new_n107_), .Y(new_n108_));
  AOI21x1_ASAP7_75t_R g050(.A1(new_n87_), .A2(new_n98_), .B(new_n108_), .Y(new_n109_));
  NAND3x1_ASAP7_75t_R g051(.A(new_n78_), .B(new_n85_), .C(new_n97_), .Y(new_n110_));
  OAI21x1_ASAP7_75t_R g052(.A1(new_n95_), .A2(new_n96_), .B(new_n86_), .Y(new_n111_));
  XNOR2x2_ASAP7_75t_R g053(.A(new_n107_), .B(new_n104_), .Y(new_n112_));
  AOI21x1_ASAP7_75t_R g054(.A1(new_n110_), .A2(new_n111_), .B(new_n112_), .Y(new_n113_));
  AO21x1_ASAP7_75t_R  g055(.A1(p0), .A2(p26), .B(p2), .Y(new_n114_));
  INVx1_ASAP7_75t_R   g056(.A(new_n114_), .Y(new_n115_));
  OAI21x1_ASAP7_75t_R g057(.A1(new_n109_), .A2(new_n113_), .B(new_n115_), .Y(new_n116_));
  AND2x2_ASAP7_75t_R  g058(.A(new_n59_), .B(new_n116_), .Y(new_n117_));
  INVx1_ASAP7_75t_R   g059(.A(p2), .Y(new_n118_));
  INVx1_ASAP7_75t_R   g060(.A(p0), .Y(new_n119_));
  INVx1_ASAP7_75t_R   g061(.A(p26), .Y(new_n120_));
  AO21x1_ASAP7_75t_R  g062(.A1(new_n118_), .A2(new_n119_), .B(new_n120_), .Y(new_n121_));
  INVx1_ASAP7_75t_R   g063(.A(new_n121_), .Y(new_n122_));
  OAI21x1_ASAP7_75t_R g064(.A1(new_n109_), .A2(new_n113_), .B(new_n118_), .Y(new_n123_));
  NAND2x1_ASAP7_75t_R g065(.A(new_n122_), .B(new_n123_), .Y(new_n124_));
  NOR2x1_ASAP7_75t_R  g066(.A(p0), .B(p1), .Y(new_n125_));
  NAND3x1_ASAP7_75t_R g067(.A(new_n125_), .B(new_n62_), .C(p26), .Y(new_n126_));
  AO21x1_ASAP7_75t_R  g068(.A1(p26), .A2(new_n125_), .B(new_n62_), .Y(new_n127_));
  NAND2x1_ASAP7_75t_R g069(.A(new_n126_), .B(new_n127_), .Y(new_n128_));
  AO21x1_ASAP7_75t_R  g070(.A1(new_n72_), .A2(new_n76_), .B(new_n128_), .Y(new_n129_));
  NAND2x1_ASAP7_75t_R g071(.A(new_n128_), .B(new_n84_), .Y(new_n130_));
  NAND2x1_ASAP7_75t_R g072(.A(new_n129_), .B(new_n130_), .Y(new_n131_));
  NOR2x1_ASAP7_75t_R  g073(.A(p10), .B(p17), .Y(new_n132_));
  AND2x2_ASAP7_75t_R  g074(.A(p10), .B(p17), .Y(new_n133_));
  OAI21x1_ASAP7_75t_R g075(.A1(new_n132_), .A2(new_n133_), .B(p24), .Y(new_n134_));
  OR3x1_ASAP7_75t_R   g076(.A(new_n133_), .B(p24), .C(new_n132_), .Y(new_n135_));
  NAND2x1_ASAP7_75t_R g077(.A(new_n134_), .B(new_n135_), .Y(new_n136_));
  XNOR2x2_ASAP7_75t_R g078(.A(new_n104_), .B(new_n136_), .Y(new_n137_));
  NAND2x1_ASAP7_75t_R g079(.A(new_n131_), .B(new_n137_), .Y(new_n138_));
  XOR2x2_ASAP7_75t_R  g080(.A(new_n104_), .B(new_n136_), .Y(new_n139_));
  XOR2x2_ASAP7_75t_R  g081(.A(new_n84_), .B(new_n128_), .Y(new_n140_));
  NAND2x1_ASAP7_75t_R g082(.A(new_n139_), .B(new_n140_), .Y(new_n141_));
  INVx1_ASAP7_75t_R   g083(.A(p27), .Y(new_n142_));
  NOR2x1_ASAP7_75t_R  g084(.A(p2), .B(new_n142_), .Y(new_n143_));
  NAND3x1_ASAP7_75t_R g085(.A(new_n138_), .B(new_n141_), .C(new_n143_), .Y(new_n144_));
  NAND3x1_ASAP7_75t_R g086(.A(new_n137_), .B(new_n140_), .C(new_n118_), .Y(new_n145_));
  NAND3x1_ASAP7_75t_R g087(.A(new_n139_), .B(new_n131_), .C(new_n118_), .Y(new_n146_));
  NAND3x1_ASAP7_75t_R g088(.A(new_n145_), .B(new_n146_), .C(new_n142_), .Y(new_n147_));
  OAI21x1_ASAP7_75t_R g089(.A1(p14), .A2(p13), .B(p15), .Y(new_n148_));
  AO21x1_ASAP7_75t_R  g090(.A1(p14), .A2(p13), .B(new_n148_), .Y(new_n149_));
  NOR2x1_ASAP7_75t_R  g091(.A(p14), .B(p13), .Y(new_n150_));
  AND2x2_ASAP7_75t_R  g092(.A(p14), .B(p13), .Y(new_n151_));
  OAI21x1_ASAP7_75t_R g093(.A1(new_n150_), .A2(new_n151_), .B(new_n101_), .Y(new_n152_));
  XNOR2x2_ASAP7_75t_R g094(.A(p21), .B(p9), .Y(new_n153_));
  NAND3x1_ASAP7_75t_R g095(.A(new_n149_), .B(new_n152_), .C(new_n153_), .Y(new_n154_));
  AO21x1_ASAP7_75t_R  g096(.A1(new_n152_), .A2(new_n149_), .B(new_n153_), .Y(new_n155_));
  XOR2x2_ASAP7_75t_R  g097(.A(p24), .B(p22), .Y(new_n156_));
  INVx1_ASAP7_75t_R   g098(.A(p32), .Y(new_n157_));
  AND3x1_ASAP7_75t_R  g099(.A(new_n105_), .B(new_n157_), .C(p23), .Y(new_n158_));
  XNOR2x2_ASAP7_75t_R g100(.A(new_n156_), .B(new_n158_), .Y(new_n159_));
  AOI21x1_ASAP7_75t_R g101(.A1(new_n154_), .A2(new_n155_), .B(new_n159_), .Y(new_n160_));
  XOR2x2_ASAP7_75t_R  g102(.A(new_n158_), .B(new_n156_), .Y(new_n161_));
  AND3x1_ASAP7_75t_R  g103(.A(new_n149_), .B(new_n152_), .C(new_n153_), .Y(new_n162_));
  AOI21x1_ASAP7_75t_R g104(.A1(new_n152_), .A2(new_n149_), .B(new_n153_), .Y(new_n163_));
  NOR3x1_ASAP7_75t_R  g105(.A(new_n161_), .B(new_n162_), .C(new_n163_), .Y(new_n164_));
  NOR2x1_ASAP7_75t_R  g106(.A(new_n160_), .B(new_n164_), .Y(new_n165_));
  AO21x1_ASAP7_75t_R  g107(.A1(p11), .A2(p32), .B(p2), .Y(new_n166_));
  OA21x2_ASAP7_75t_R  g108(.A1(p2), .A2(p32), .B(p11), .Y(new_n167_));
  OAI21x1_ASAP7_75t_R g109(.A1(new_n160_), .A2(new_n164_), .B(new_n118_), .Y(new_n168_));
  NAND2x1_ASAP7_75t_R g110(.A(new_n167_), .B(new_n168_), .Y(new_n169_));
  OAI21x1_ASAP7_75t_R g111(.A1(new_n165_), .A2(new_n166_), .B(new_n169_), .Y(new_n170_));
  AOI21x1_ASAP7_75t_R g112(.A1(new_n144_), .A2(new_n147_), .B(new_n170_), .Y(new_n171_));
  AND3x1_ASAP7_75t_R  g113(.A(new_n117_), .B(new_n124_), .C(new_n171_), .Y(new_n172_));
  INVx1_ASAP7_75t_R   g114(.A(p23), .Y(new_n173_));
  NOR2x1_ASAP7_75t_R  g115(.A(p2), .B(p32), .Y(new_n174_));
  NOR2x1_ASAP7_75t_R  g116(.A(new_n173_), .B(new_n174_), .Y(new_n175_));
  INVx1_ASAP7_75t_R   g117(.A(new_n175_), .Y(new_n176_));
  NOR2x1_ASAP7_75t_R  g118(.A(p14), .B(p22), .Y(new_n177_));
  AND2x2_ASAP7_75t_R  g119(.A(p14), .B(p22), .Y(new_n178_));
  INVx1_ASAP7_75t_R   g120(.A(p28), .Y(new_n179_));
  NOR2x1_ASAP7_75t_R  g121(.A(p1), .B(new_n179_), .Y(new_n180_));
  OAI21x1_ASAP7_75t_R g122(.A1(new_n177_), .A2(new_n178_), .B(new_n180_), .Y(new_n181_));
  NAND2x1_ASAP7_75t_R g123(.A(p28), .B(new_n105_), .Y(new_n182_));
  XOR2x2_ASAP7_75t_R  g124(.A(p14), .B(p22), .Y(new_n183_));
  NAND2x1_ASAP7_75t_R g125(.A(new_n182_), .B(new_n183_), .Y(new_n184_));
  NAND2x1_ASAP7_75t_R g126(.A(new_n181_), .B(new_n184_), .Y(new_n185_));
  XOR2x2_ASAP7_75t_R  g127(.A(new_n185_), .B(new_n94_), .Y(new_n186_));
  OR3x1_ASAP7_75t_R   g128(.A(new_n186_), .B(new_n137_), .C(p2), .Y(new_n187_));
  XOR2x2_ASAP7_75t_R  g129(.A(new_n185_), .B(new_n67_), .Y(new_n188_));
  NOR2x1_ASAP7_75t_R  g130(.A(new_n139_), .B(new_n188_), .Y(new_n189_));
  INVx1_ASAP7_75t_R   g131(.A(p29), .Y(new_n190_));
  AOI21x1_ASAP7_75t_R g132(.A1(new_n118_), .A2(new_n189_), .B(new_n190_), .Y(new_n191_));
  NAND2x1_ASAP7_75t_R g133(.A(new_n139_), .B(new_n188_), .Y(new_n192_));
  NAND2x1_ASAP7_75t_R g134(.A(new_n137_), .B(new_n186_), .Y(new_n193_));
  NAND2x1_ASAP7_75t_R g135(.A(new_n118_), .B(new_n190_), .Y(new_n194_));
  AOI21x1_ASAP7_75t_R g136(.A1(new_n192_), .A2(new_n193_), .B(new_n194_), .Y(new_n195_));
  AOI21x1_ASAP7_75t_R g137(.A1(new_n187_), .A2(new_n191_), .B(new_n195_), .Y(new_n196_));
  AND3x1_ASAP7_75t_R  g138(.A(new_n105_), .B(new_n157_), .C(p11), .Y(new_n197_));
  XOR2x2_ASAP7_75t_R  g139(.A(p8), .B(p9), .Y(new_n198_));
  XOR2x2_ASAP7_75t_R  g140(.A(new_n197_), .B(new_n198_), .Y(new_n199_));
  XNOR2x2_ASAP7_75t_R g141(.A(p5), .B(p7), .Y(new_n200_));
  XOR2x2_ASAP7_75t_R  g142(.A(p10), .B(p6), .Y(new_n201_));
  XOR2x2_ASAP7_75t_R  g143(.A(new_n200_), .B(new_n201_), .Y(new_n202_));
  NAND2x1_ASAP7_75t_R g144(.A(new_n199_), .B(new_n202_), .Y(new_n203_));
  OR2x4_ASAP7_75t_R   g145(.A(new_n199_), .B(new_n202_), .Y(new_n204_));
  OR2x4_ASAP7_75t_R   g146(.A(p2), .B(p12), .Y(new_n205_));
  AO21x1_ASAP7_75t_R  g147(.A1(new_n203_), .A2(new_n204_), .B(new_n205_), .Y(new_n206_));
  AND2x2_ASAP7_75t_R  g148(.A(new_n203_), .B(new_n204_), .Y(new_n207_));
  OAI21x1_ASAP7_75t_R g149(.A1(p2), .A2(new_n207_), .B(p12), .Y(new_n208_));
  NAND2x1_ASAP7_75t_R g150(.A(new_n206_), .B(new_n208_), .Y(new_n209_));
  NOR2x1_ASAP7_75t_R  g151(.A(p2), .B(p20), .Y(new_n210_));
  XOR2x2_ASAP7_75t_R  g152(.A(p5), .B(p18), .Y(new_n211_));
  OAI21x1_ASAP7_75t_R g153(.A1(p5), .A2(p18), .B(new_n64_), .Y(new_n212_));
  AO21x1_ASAP7_75t_R  g154(.A1(p5), .A2(p18), .B(new_n212_), .Y(new_n213_));
  OAI21x1_ASAP7_75t_R g155(.A1(new_n64_), .A2(new_n211_), .B(new_n213_), .Y(new_n214_));
  NAND2x1_ASAP7_75t_R g156(.A(p16), .B(new_n125_), .Y(new_n215_));
  AO21x1_ASAP7_75t_R  g157(.A1(new_n152_), .A2(new_n149_), .B(new_n215_), .Y(new_n216_));
  NAND3x1_ASAP7_75t_R g158(.A(new_n149_), .B(new_n152_), .C(new_n215_), .Y(new_n217_));
  NAND3x1_ASAP7_75t_R g159(.A(new_n214_), .B(new_n216_), .C(new_n217_), .Y(new_n218_));
  AO21x1_ASAP7_75t_R  g160(.A1(new_n216_), .A2(new_n217_), .B(new_n214_), .Y(new_n219_));
  XNOR2x2_ASAP7_75t_R g161(.A(p17), .B(p8), .Y(new_n220_));
  AOI21x1_ASAP7_75t_R g162(.A1(new_n218_), .A2(new_n219_), .B(new_n220_), .Y(new_n221_));
  AND3x1_ASAP7_75t_R  g163(.A(new_n219_), .B(new_n220_), .C(new_n218_), .Y(new_n222_));
  NOR2x1_ASAP7_75t_R  g164(.A(new_n221_), .B(new_n222_), .Y(new_n223_));
  OR3x1_ASAP7_75t_R   g165(.A(p2), .B(p1), .C(p3), .Y(new_n224_));
  NOR2x1_ASAP7_75t_R  g166(.A(p1), .B(p4), .Y(new_n225_));
  INVx1_ASAP7_75t_R   g167(.A(new_n225_), .Y(new_n226_));
  NOR2x1_ASAP7_75t_R  g168(.A(p32), .B(new_n119_), .Y(new_n227_));
  AO21x1_ASAP7_75t_R  g169(.A1(new_n224_), .A2(new_n226_), .B(new_n227_), .Y(new_n228_));
  AO21x1_ASAP7_75t_R  g170(.A1(new_n210_), .A2(new_n223_), .B(new_n228_), .Y(new_n229_));
  NAND3x1_ASAP7_75t_R g171(.A(new_n219_), .B(new_n220_), .C(new_n218_), .Y(new_n230_));
  NAND2x1_ASAP7_75t_R g172(.A(new_n118_), .B(new_n230_), .Y(new_n231_));
  OA21x2_ASAP7_75t_R  g173(.A1(new_n221_), .A2(new_n231_), .B(p20), .Y(new_n232_));
  NOR3x1_ASAP7_75t_R  g174(.A(new_n209_), .B(new_n229_), .C(new_n232_), .Y(new_n233_));
  OA21x2_ASAP7_75t_R  g175(.A1(new_n176_), .A2(new_n196_), .B(new_n233_), .Y(new_n234_));
  NAND2x1_ASAP7_75t_R g176(.A(new_n172_), .B(new_n234_), .Y(new_n235_));
  OAI21x1_ASAP7_75t_R g177(.A1(new_n176_), .A2(new_n196_), .B(new_n171_), .Y(new_n236_));
  NAND2x1_ASAP7_75t_R g178(.A(new_n116_), .B(new_n124_), .Y(new_n237_));
  INVx1_ASAP7_75t_R   g179(.A(new_n59_), .Y(new_n238_));
  NOR3x1_ASAP7_75t_R  g180(.A(new_n236_), .B(new_n237_), .C(new_n238_), .Y(new_n239_));
  INVx1_ASAP7_75t_R   g181(.A(p14), .Y(new_n240_));
  AND3x1_ASAP7_75t_R  g182(.A(new_n239_), .B(new_n240_), .C(new_n233_), .Y(new_n241_));
  AOI21x1_ASAP7_75t_R g183(.A1(p14), .A2(new_n235_), .B(new_n241_), .Y(o0));
  OA21x2_ASAP7_75t_R  g184(.A1(new_n176_), .A2(new_n196_), .B(new_n171_), .Y(new_n243_));
  AO21x1_ASAP7_75t_R  g185(.A1(new_n116_), .A2(new_n124_), .B(new_n238_), .Y(new_n244_));
  OR3x1_ASAP7_75t_R   g186(.A(new_n227_), .B(p1), .C(p4), .Y(new_n245_));
  NOR2x1_ASAP7_75t_R  g187(.A(p31), .B(p1), .Y(new_n246_));
  INVx1_ASAP7_75t_R   g188(.A(new_n246_), .Y(new_n247_));
  OR3x1_ASAP7_75t_R   g189(.A(new_n247_), .B(new_n227_), .C(p2), .Y(new_n248_));
  AND2x2_ASAP7_75t_R  g190(.A(new_n245_), .B(new_n248_), .Y(new_n249_));
  INVx1_ASAP7_75t_R   g191(.A(new_n249_), .Y(new_n250_));
  NAND3x1_ASAP7_75t_R g192(.A(new_n208_), .B(new_n206_), .C(new_n250_), .Y(new_n251_));
  INVx1_ASAP7_75t_R   g193(.A(new_n221_), .Y(new_n252_));
  NAND3x1_ASAP7_75t_R g194(.A(new_n252_), .B(new_n230_), .C(new_n210_), .Y(new_n253_));
  OAI21x1_ASAP7_75t_R g195(.A1(new_n221_), .A2(new_n231_), .B(p20), .Y(new_n254_));
  NAND2x1_ASAP7_75t_R g196(.A(new_n253_), .B(new_n254_), .Y(new_n255_));
  NOR2x1_ASAP7_75t_R  g197(.A(new_n251_), .B(new_n255_), .Y(new_n256_));
  NAND3x1_ASAP7_75t_R g198(.A(new_n243_), .B(new_n244_), .C(new_n256_), .Y(new_n257_));
  XOR2x2_ASAP7_75t_R  g199(.A(new_n257_), .B(p25), .Y(o1));
  XOR2x2_ASAP7_75t_R  g200(.A(new_n257_), .B(p19), .Y(o2));
  INVx1_ASAP7_75t_R   g201(.A(p24), .Y(new_n260_));
  AND3x1_ASAP7_75t_R  g202(.A(new_n239_), .B(new_n260_), .C(new_n233_), .Y(new_n261_));
  AOI21x1_ASAP7_75t_R g203(.A1(p24), .A2(new_n235_), .B(new_n261_), .Y(o3));
  XOR2x2_ASAP7_75t_R  g204(.A(new_n257_), .B(p7), .Y(o4));
  XOR2x2_ASAP7_75t_R  g205(.A(new_n257_), .B(p22), .Y(o5));
  AOI21x1_ASAP7_75t_R g206(.A1(new_n59_), .A2(new_n237_), .B(new_n236_), .Y(new_n265_));
  NAND2x1_ASAP7_75t_R g207(.A(new_n233_), .B(new_n265_), .Y(new_n266_));
  XOR2x2_ASAP7_75t_R  g208(.A(new_n266_), .B(p9), .Y(o6));
  XOR2x2_ASAP7_75t_R  g209(.A(new_n266_), .B(p8), .Y(o7));
  XOR2x2_ASAP7_75t_R  g210(.A(new_n266_), .B(p15), .Y(o8));
  AO21x1_ASAP7_75t_R  g211(.A1(new_n144_), .A2(new_n147_), .B(new_n170_), .Y(new_n270_));
  AOI21x1_ASAP7_75t_R g212(.A1(new_n116_), .A2(new_n124_), .B(new_n238_), .Y(new_n271_));
  NOR2x1_ASAP7_75t_R  g213(.A(new_n270_), .B(new_n271_), .Y(new_n272_));
  NAND2x1_ASAP7_75t_R g214(.A(new_n175_), .B(new_n196_), .Y(new_n273_));
  INVx1_ASAP7_75t_R   g215(.A(new_n273_), .Y(new_n274_));
  NAND3x1_ASAP7_75t_R g216(.A(new_n272_), .B(new_n256_), .C(new_n274_), .Y(new_n275_));
  OR3x1_ASAP7_75t_R   g217(.A(new_n271_), .B(new_n270_), .C(new_n273_), .Y(new_n276_));
  INVx1_ASAP7_75t_R   g218(.A(new_n253_), .Y(new_n277_));
  OR3x1_ASAP7_75t_R   g219(.A(new_n209_), .B(new_n277_), .C(new_n232_), .Y(new_n278_));
  OR3x1_ASAP7_75t_R   g220(.A(new_n278_), .B(p18), .C(new_n249_), .Y(new_n279_));
  NOR2x1_ASAP7_75t_R  g221(.A(new_n276_), .B(new_n279_), .Y(new_n280_));
  AOI21x1_ASAP7_75t_R g222(.A1(p18), .A2(new_n275_), .B(new_n280_), .Y(o9));
  OR3x1_ASAP7_75t_R   g223(.A(new_n255_), .B(new_n251_), .C(p6), .Y(new_n282_));
  NOR2x1_ASAP7_75t_R  g224(.A(new_n282_), .B(new_n276_), .Y(new_n283_));
  AOI21x1_ASAP7_75t_R g225(.A1(p6), .A2(new_n275_), .B(new_n283_), .Y(o10));
  OR3x1_ASAP7_75t_R   g226(.A(new_n255_), .B(new_n251_), .C(p21), .Y(new_n285_));
  NOR2x1_ASAP7_75t_R  g227(.A(new_n285_), .B(new_n276_), .Y(new_n286_));
  AOI21x1_ASAP7_75t_R g228(.A1(p21), .A2(new_n275_), .B(new_n286_), .Y(o11));
  OR3x1_ASAP7_75t_R   g229(.A(new_n278_), .B(p5), .C(new_n249_), .Y(new_n288_));
  NOR2x1_ASAP7_75t_R  g230(.A(new_n276_), .B(new_n288_), .Y(new_n289_));
  AOI21x1_ASAP7_75t_R g231(.A1(p5), .A2(new_n275_), .B(new_n289_), .Y(o12));
  INVx1_ASAP7_75t_R   g232(.A(new_n233_), .Y(new_n291_));
  INVx1_ASAP7_75t_R   g233(.A(p13), .Y(new_n292_));
  OAI21x1_ASAP7_75t_R g234(.A1(new_n291_), .A2(new_n276_), .B(new_n292_), .Y(new_n293_));
  OR3x1_ASAP7_75t_R   g235(.A(new_n276_), .B(new_n292_), .C(new_n291_), .Y(new_n294_));
  NAND2x1_ASAP7_75t_R g236(.A(new_n293_), .B(new_n294_), .Y(o13));
  INVx1_ASAP7_75t_R   g237(.A(p17), .Y(new_n296_));
  AND3x1_ASAP7_75t_R  g238(.A(new_n239_), .B(new_n296_), .C(new_n233_), .Y(new_n297_));
  AOI21x1_ASAP7_75t_R g239(.A1(p17), .A2(new_n235_), .B(new_n297_), .Y(o14));
  INVx1_ASAP7_75t_R   g240(.A(p10), .Y(new_n299_));
  AND3x1_ASAP7_75t_R  g241(.A(new_n239_), .B(new_n299_), .C(new_n233_), .Y(new_n300_));
  AOI21x1_ASAP7_75t_R g242(.A1(p10), .A2(new_n235_), .B(new_n300_), .Y(o15));
  AND3x1_ASAP7_75t_R  g243(.A(new_n116_), .B(new_n238_), .C(new_n176_), .Y(new_n302_));
  AND3x1_ASAP7_75t_R  g244(.A(new_n302_), .B(new_n124_), .C(new_n196_), .Y(new_n303_));
  NAND2x1_ASAP7_75t_R g245(.A(new_n171_), .B(new_n303_), .Y(new_n304_));
  NOR2x1_ASAP7_75t_R  g246(.A(new_n278_), .B(new_n304_), .Y(new_n305_));
  AND3x1_ASAP7_75t_R  g247(.A(new_n248_), .B(new_n228_), .C(new_n245_), .Y(new_n306_));
  NOR3x1_ASAP7_75t_R  g248(.A(new_n255_), .B(new_n209_), .C(new_n306_), .Y(new_n307_));
  AND3x1_ASAP7_75t_R  g249(.A(new_n265_), .B(p4), .C(new_n307_), .Y(new_n308_));
  OR3x1_ASAP7_75t_R   g250(.A(new_n305_), .B(p1), .C(new_n308_), .Y(o16));
  NOR2x1_ASAP7_75t_R  g251(.A(new_n109_), .B(new_n113_), .Y(new_n310_));
  OR3x1_ASAP7_75t_R   g252(.A(new_n310_), .B(p2), .C(new_n121_), .Y(new_n311_));
  NAND3x1_ASAP7_75t_R g253(.A(new_n307_), .B(new_n243_), .C(new_n244_), .Y(new_n312_));
  OAI21x1_ASAP7_75t_R g254(.A1(new_n311_), .A2(new_n312_), .B(new_n226_), .Y(new_n313_));
  OR3x1_ASAP7_75t_R   g255(.A(new_n119_), .B(new_n120_), .C(p2), .Y(new_n314_));
  OA21x2_ASAP7_75t_R  g256(.A1(new_n314_), .A2(new_n312_), .B(new_n310_), .Y(new_n315_));
  NOR2x1_ASAP7_75t_R  g257(.A(new_n313_), .B(new_n315_), .Y(o17));
  NOR2x1_ASAP7_75t_R  g258(.A(p2), .B(new_n190_), .Y(new_n317_));
  NAND2x1_ASAP7_75t_R g259(.A(new_n192_), .B(new_n193_), .Y(new_n318_));
  NAND2x1_ASAP7_75t_R g260(.A(new_n317_), .B(new_n318_), .Y(new_n319_));
  OAI21x1_ASAP7_75t_R g261(.A1(new_n319_), .A2(new_n312_), .B(new_n226_), .Y(new_n320_));
  AND3x1_ASAP7_75t_R  g262(.A(new_n307_), .B(new_n243_), .C(new_n244_), .Y(new_n321_));
  AOI21x1_ASAP7_75t_R g263(.A1(new_n317_), .A2(new_n321_), .B(new_n318_), .Y(new_n322_));
  NOR2x1_ASAP7_75t_R  g264(.A(new_n320_), .B(new_n322_), .Y(o18));
  NAND2x1_ASAP7_75t_R g265(.A(p20), .B(new_n321_), .Y(new_n324_));
  AOI21x1_ASAP7_75t_R g266(.A1(new_n223_), .A2(new_n324_), .B(new_n225_), .Y(o19));
  AND3x1_ASAP7_75t_R  g267(.A(new_n265_), .B(p12), .C(new_n307_), .Y(new_n326_));
  OA21x2_ASAP7_75t_R  g268(.A1(new_n207_), .A2(new_n326_), .B(new_n226_), .Y(o20));
  AND3x1_ASAP7_75t_R  g269(.A(new_n265_), .B(new_n167_), .C(new_n307_), .Y(new_n328_));
  OA21x2_ASAP7_75t_R  g270(.A1(new_n165_), .A2(new_n328_), .B(new_n226_), .Y(o21));
  AO21x1_ASAP7_75t_R  g271(.A1(p30), .A2(p31), .B(p1), .Y(new_n330_));
  INVx1_ASAP7_75t_R   g272(.A(new_n330_), .Y(new_n331_));
  AND3x1_ASAP7_75t_R  g273(.A(new_n98_), .B(new_n87_), .C(new_n247_), .Y(new_n332_));
  NOR3x1_ASAP7_75t_R  g274(.A(new_n255_), .B(new_n251_), .C(new_n332_), .Y(new_n333_));
  AND3x1_ASAP7_75t_R  g275(.A(new_n333_), .B(new_n243_), .C(new_n244_), .Y(new_n334_));
  AOI21x1_ASAP7_75t_R g276(.A1(new_n332_), .A2(new_n257_), .B(new_n334_), .Y(new_n335_));
  AND3x1_ASAP7_75t_R  g277(.A(new_n243_), .B(new_n244_), .C(new_n256_), .Y(new_n336_));
  INVx1_ASAP7_75t_R   g278(.A(new_n332_), .Y(new_n337_));
  AOI21x1_ASAP7_75t_R g279(.A1(new_n333_), .A2(new_n265_), .B(new_n330_), .Y(new_n338_));
  OAI21x1_ASAP7_75t_R g280(.A1(new_n336_), .A2(new_n337_), .B(new_n338_), .Y(new_n339_));
  OAI21x1_ASAP7_75t_R g281(.A1(new_n331_), .A2(new_n335_), .B(new_n339_), .Y(o22));
  NOR2x1_ASAP7_75t_R  g282(.A(new_n150_), .B(new_n151_), .Y(new_n341_));
  XOR2x2_ASAP7_75t_R  g283(.A(new_n137_), .B(new_n341_), .Y(new_n342_));
  NAND2x1_ASAP7_75t_R g284(.A(new_n105_), .B(new_n179_), .Y(new_n343_));
  XOR2x2_ASAP7_75t_R  g285(.A(new_n342_), .B(new_n343_), .Y(new_n344_));
  OA21x2_ASAP7_75t_R  g286(.A1(p1), .A2(p3), .B(new_n344_), .Y(new_n345_));
  XOR2x2_ASAP7_75t_R  g287(.A(new_n266_), .B(new_n345_), .Y(o23));
  NAND2x1_ASAP7_75t_R g288(.A(new_n143_), .B(new_n321_), .Y(new_n347_));
  AND2x2_ASAP7_75t_R  g289(.A(new_n141_), .B(new_n138_), .Y(new_n348_));
  AND3x1_ASAP7_75t_R  g290(.A(new_n347_), .B(new_n226_), .C(new_n348_), .Y(o24));
endmodule


