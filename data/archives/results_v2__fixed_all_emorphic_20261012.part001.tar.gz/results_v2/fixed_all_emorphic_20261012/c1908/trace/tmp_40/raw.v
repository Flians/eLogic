// Benchmark "/tmp/" written by ABC on Mon Oct 12 15:05:29 2026

module \/tmp/  ( 
    p11, p23, p20, p32, p10, p26, p5, p19, p6, p3, p0, p27, p9, p24, p4,
    p28, p22, p29, p8, p15, p25, p7, p18, p16, p14, p21, p1, p12, p31, p30,
    p13, p17, p2,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24  );
  input  p11, p23, p20, p32, p10, p26, p5, p19, p6, p3, p0, p27, p9, p24,
    p4, p28, p22, p29, p8, p15, p25, p7, p18, p16, p14, p21, p1, p12, p31,
    p30, p13, p17, p2;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24;
  wire new_n59_, new_n60_, new_n61_, new_n62_, new_n63_, new_n64_, new_n65_,
    new_n66_, new_n67_, new_n68_, new_n69_, new_n70_, new_n71_, new_n72_,
    new_n73_, new_n74_, new_n75_, new_n76_, new_n77_, new_n78_, new_n79_,
    new_n80_, new_n81_, new_n82_, new_n83_, new_n84_, new_n85_, new_n86_,
    new_n87_, new_n88_, new_n89_, new_n90_, new_n91_, new_n92_, new_n93_,
    new_n94_, new_n95_, new_n96_, new_n97_, new_n98_, new_n99_, new_n100_,
    new_n101_, new_n102_, new_n103_, new_n104_, new_n105_, new_n106_,
    new_n107_, new_n108_, new_n109_, new_n110_, new_n111_, new_n112_,
    new_n113_, new_n114_, new_n115_, new_n116_, new_n117_, new_n118_,
    new_n119_, new_n120_, new_n121_, new_n122_, new_n123_, new_n124_,
    new_n125_, new_n126_, new_n127_, new_n128_, new_n129_, new_n130_,
    new_n131_, new_n132_, new_n133_, new_n134_, new_n135_, new_n136_,
    new_n137_, new_n138_, new_n139_, new_n140_, new_n141_, new_n142_,
    new_n143_, new_n144_, new_n145_, new_n146_, new_n147_, new_n148_,
    new_n149_, new_n150_, new_n151_, new_n152_, new_n153_, new_n154_,
    new_n155_, new_n156_, new_n157_, new_n158_, new_n159_, new_n160_,
    new_n161_, new_n162_, new_n163_, new_n164_, new_n165_, new_n166_,
    new_n167_, new_n168_, new_n169_, new_n170_, new_n171_, new_n172_,
    new_n173_, new_n174_, new_n175_, new_n176_, new_n177_, new_n178_,
    new_n179_, new_n180_, new_n181_, new_n182_, new_n183_, new_n184_,
    new_n185_, new_n186_, new_n187_, new_n188_, new_n189_, new_n190_,
    new_n191_, new_n192_, new_n193_, new_n194_, new_n195_, new_n196_,
    new_n197_, new_n198_, new_n199_, new_n200_, new_n201_, new_n202_,
    new_n203_, new_n204_, new_n205_, new_n206_, new_n207_, new_n208_,
    new_n209_, new_n210_, new_n211_, new_n212_, new_n213_, new_n214_,
    new_n215_, new_n216_, new_n217_, new_n218_, new_n219_, new_n220_,
    new_n221_, new_n222_, new_n223_, new_n224_, new_n225_, new_n226_,
    new_n227_, new_n228_, new_n229_, new_n230_, new_n231_, new_n232_,
    new_n233_, new_n234_, new_n235_, new_n236_, new_n237_, new_n238_,
    new_n239_, new_n240_, new_n241_, new_n242_, new_n243_, new_n244_,
    new_n245_, new_n246_, new_n247_, new_n248_, new_n249_, new_n250_,
    new_n251_, new_n252_, new_n253_, new_n254_, new_n255_, new_n256_,
    new_n257_, new_n258_, new_n259_, new_n260_, new_n261_, new_n263_,
    new_n264_, new_n265_, new_n266_, new_n267_, new_n268_, new_n269_,
    new_n272_, new_n273_, new_n277_, new_n278_, new_n282_, new_n283_,
    new_n284_, new_n285_, new_n286_, new_n287_, new_n288_, new_n290_,
    new_n291_, new_n292_, new_n294_, new_n295_, new_n297_, new_n298_,
    new_n300_, new_n301_, new_n302_, new_n303_, new_n304_, new_n305_,
    new_n307_, new_n308_, new_n310_, new_n311_, new_n313_, new_n314_,
    new_n315_, new_n316_, new_n317_, new_n318_, new_n319_, new_n320_,
    new_n321_, new_n323_, new_n324_, new_n325_, new_n326_, new_n327_,
    new_n328_, new_n330_, new_n331_, new_n332_, new_n333_, new_n335_,
    new_n337_, new_n339_, new_n340_, new_n342_, new_n343_, new_n344_,
    new_n345_, new_n346_, new_n347_, new_n348_, new_n349_, new_n350_,
    new_n351_, new_n352_, new_n353_, new_n355_, new_n356_, new_n357_,
    new_n358_, new_n359_, new_n361_, new_n362_;
  INVx1_ASAP7_75t_R   g000(.A(p23), .Y(new_n59_));
  NOR2x1_ASAP7_75t_R  g001(.A(p32), .B(p2), .Y(new_n60_));
  NOR2x1_ASAP7_75t_R  g002(.A(new_n59_), .B(new_n60_), .Y(new_n61_));
  INVx1_ASAP7_75t_R   g003(.A(new_n61_), .Y(new_n62_));
  NOR2x1_ASAP7_75t_R  g004(.A(p22), .B(p14), .Y(new_n63_));
  AND2x2_ASAP7_75t_R  g005(.A(p22), .B(p14), .Y(new_n64_));
  INVx1_ASAP7_75t_R   g006(.A(p28), .Y(new_n65_));
  NOR2x1_ASAP7_75t_R  g007(.A(p1), .B(new_n65_), .Y(new_n66_));
  OAI21x1_ASAP7_75t_R g008(.A1(new_n63_), .A2(new_n64_), .B(new_n66_), .Y(new_n67_));
  INVx1_ASAP7_75t_R   g009(.A(p1), .Y(new_n68_));
  NAND2x1_ASAP7_75t_R g010(.A(p28), .B(new_n68_), .Y(new_n69_));
  XOR2x2_ASAP7_75t_R  g011(.A(p22), .B(p14), .Y(new_n70_));
  NAND2x1_ASAP7_75t_R g012(.A(new_n69_), .B(new_n70_), .Y(new_n71_));
  NAND2x1_ASAP7_75t_R g013(.A(new_n67_), .B(new_n71_), .Y(new_n72_));
  INVx1_ASAP7_75t_R   g014(.A(p7), .Y(new_n73_));
  NOR2x1_ASAP7_75t_R  g015(.A(p25), .B(new_n73_), .Y(new_n74_));
  INVx1_ASAP7_75t_R   g016(.A(p25), .Y(new_n75_));
  NOR2x1_ASAP7_75t_R  g017(.A(p7), .B(new_n75_), .Y(new_n76_));
  OAI21x1_ASAP7_75t_R g018(.A1(new_n74_), .A2(new_n76_), .B(p19), .Y(new_n77_));
  NAND2x1_ASAP7_75t_R g019(.A(p7), .B(new_n75_), .Y(new_n78_));
  NAND2x1_ASAP7_75t_R g020(.A(p25), .B(new_n73_), .Y(new_n79_));
  INVx1_ASAP7_75t_R   g021(.A(p19), .Y(new_n80_));
  NAND3x1_ASAP7_75t_R g022(.A(new_n78_), .B(new_n79_), .C(new_n80_), .Y(new_n81_));
  NAND2x1_ASAP7_75t_R g023(.A(new_n77_), .B(new_n81_), .Y(new_n82_));
  XOR2x2_ASAP7_75t_R  g024(.A(new_n72_), .B(new_n82_), .Y(new_n83_));
  NOR2x1_ASAP7_75t_R  g025(.A(p9), .B(p8), .Y(new_n84_));
  AND2x2_ASAP7_75t_R  g026(.A(p9), .B(p8), .Y(new_n85_));
  INVx1_ASAP7_75t_R   g027(.A(p15), .Y(new_n86_));
  OAI21x1_ASAP7_75t_R g028(.A1(new_n84_), .A2(new_n85_), .B(new_n86_), .Y(new_n87_));
  OR3x1_ASAP7_75t_R   g029(.A(new_n85_), .B(new_n86_), .C(new_n84_), .Y(new_n88_));
  NAND2x1_ASAP7_75t_R g030(.A(new_n87_), .B(new_n88_), .Y(new_n89_));
  NOR2x1_ASAP7_75t_R  g031(.A(p10), .B(p24), .Y(new_n90_));
  AND2x2_ASAP7_75t_R  g032(.A(p10), .B(p24), .Y(new_n91_));
  OAI21x1_ASAP7_75t_R g033(.A1(new_n90_), .A2(new_n91_), .B(p17), .Y(new_n92_));
  OR3x1_ASAP7_75t_R   g034(.A(new_n91_), .B(p17), .C(new_n90_), .Y(new_n93_));
  NAND2x1_ASAP7_75t_R g035(.A(new_n92_), .B(new_n93_), .Y(new_n94_));
  XNOR2x2_ASAP7_75t_R g036(.A(new_n89_), .B(new_n94_), .Y(new_n95_));
  OR3x1_ASAP7_75t_R   g037(.A(new_n83_), .B(new_n95_), .C(p2), .Y(new_n96_));
  INVx1_ASAP7_75t_R   g038(.A(p2), .Y(new_n97_));
  XOR2x2_ASAP7_75t_R  g039(.A(new_n89_), .B(new_n94_), .Y(new_n98_));
  NOR2x1_ASAP7_75t_R  g040(.A(p19), .B(new_n73_), .Y(new_n99_));
  AO21x1_ASAP7_75t_R  g041(.A1(p19), .A2(new_n73_), .B(new_n75_), .Y(new_n100_));
  NOR2x1_ASAP7_75t_R  g042(.A(p7), .B(new_n80_), .Y(new_n101_));
  OAI21x1_ASAP7_75t_R g043(.A1(new_n99_), .A2(new_n101_), .B(new_n75_), .Y(new_n102_));
  OAI21x1_ASAP7_75t_R g044(.A1(new_n99_), .A2(new_n100_), .B(new_n102_), .Y(new_n103_));
  XOR2x2_ASAP7_75t_R  g045(.A(new_n72_), .B(new_n103_), .Y(new_n104_));
  NOR2x1_ASAP7_75t_R  g046(.A(new_n98_), .B(new_n104_), .Y(new_n105_));
  INVx1_ASAP7_75t_R   g047(.A(p29), .Y(new_n106_));
  AOI21x1_ASAP7_75t_R g048(.A1(new_n97_), .A2(new_n105_), .B(new_n106_), .Y(new_n107_));
  NAND2x1_ASAP7_75t_R g049(.A(new_n98_), .B(new_n104_), .Y(new_n108_));
  NAND2x1_ASAP7_75t_R g050(.A(new_n95_), .B(new_n83_), .Y(new_n109_));
  NAND2x1_ASAP7_75t_R g051(.A(new_n106_), .B(new_n97_), .Y(new_n110_));
  AOI21x1_ASAP7_75t_R g052(.A1(new_n108_), .A2(new_n109_), .B(new_n110_), .Y(new_n111_));
  AOI21x1_ASAP7_75t_R g053(.A1(new_n96_), .A2(new_n107_), .B(new_n111_), .Y(new_n112_));
  INVx1_ASAP7_75t_R   g054(.A(p32), .Y(new_n113_));
  AND3x1_ASAP7_75t_R  g055(.A(new_n113_), .B(new_n68_), .C(p11), .Y(new_n114_));
  XOR2x2_ASAP7_75t_R  g056(.A(p9), .B(p8), .Y(new_n115_));
  XOR2x2_ASAP7_75t_R  g057(.A(new_n114_), .B(new_n115_), .Y(new_n116_));
  XOR2x2_ASAP7_75t_R  g058(.A(p10), .B(p5), .Y(new_n117_));
  XOR2x2_ASAP7_75t_R  g059(.A(p6), .B(p7), .Y(new_n118_));
  XOR2x2_ASAP7_75t_R  g060(.A(new_n117_), .B(new_n118_), .Y(new_n119_));
  XOR2x2_ASAP7_75t_R  g061(.A(new_n116_), .B(new_n119_), .Y(new_n120_));
  NAND3x1_ASAP7_75t_R g062(.A(new_n120_), .B(p12), .C(new_n97_), .Y(new_n121_));
  AO21x1_ASAP7_75t_R  g063(.A1(new_n97_), .A2(new_n120_), .B(p12), .Y(new_n122_));
  NAND2x1_ASAP7_75t_R g064(.A(new_n121_), .B(new_n122_), .Y(new_n123_));
  OAI21x1_ASAP7_75t_R g065(.A1(p14), .A2(p13), .B(p15), .Y(new_n124_));
  AND2x2_ASAP7_75t_R  g066(.A(p14), .B(p13), .Y(new_n125_));
  NOR2x1_ASAP7_75t_R  g067(.A(new_n124_), .B(new_n125_), .Y(new_n126_));
  NAND2x1_ASAP7_75t_R g068(.A(p14), .B(p13), .Y(new_n127_));
  OR3x1_ASAP7_75t_R   g069(.A(p15), .B(p14), .C(p13), .Y(new_n128_));
  OAI21x1_ASAP7_75t_R g070(.A1(p15), .A2(new_n127_), .B(new_n128_), .Y(new_n129_));
  NOR2x1_ASAP7_75t_R  g071(.A(new_n126_), .B(new_n129_), .Y(new_n130_));
  INVx1_ASAP7_75t_R   g072(.A(p0), .Y(new_n131_));
  AND3x1_ASAP7_75t_R  g073(.A(new_n131_), .B(new_n68_), .C(p16), .Y(new_n132_));
  INVx1_ASAP7_75t_R   g074(.A(p5), .Y(new_n133_));
  XOR2x2_ASAP7_75t_R  g075(.A(new_n132_), .B(new_n133_), .Y(new_n134_));
  NAND2x1_ASAP7_75t_R g076(.A(new_n130_), .B(new_n134_), .Y(new_n135_));
  NOR2x1_ASAP7_75t_R  g077(.A(p14), .B(p13), .Y(new_n136_));
  OAI21x1_ASAP7_75t_R g078(.A1(new_n136_), .A2(new_n125_), .B(new_n86_), .Y(new_n137_));
  AO21x1_ASAP7_75t_R  g079(.A1(p14), .A2(p13), .B(new_n124_), .Y(new_n138_));
  NAND2x1_ASAP7_75t_R g080(.A(new_n137_), .B(new_n138_), .Y(new_n139_));
  XOR2x2_ASAP7_75t_R  g081(.A(new_n132_), .B(p5), .Y(new_n140_));
  NAND2x1_ASAP7_75t_R g082(.A(new_n139_), .B(new_n140_), .Y(new_n141_));
  XNOR2x2_ASAP7_75t_R g083(.A(p18), .B(p17), .Y(new_n142_));
  XOR2x2_ASAP7_75t_R  g084(.A(p19), .B(p8), .Y(new_n143_));
  XOR2x2_ASAP7_75t_R  g085(.A(new_n142_), .B(new_n143_), .Y(new_n144_));
  AO21x1_ASAP7_75t_R  g086(.A1(new_n135_), .A2(new_n141_), .B(new_n144_), .Y(new_n145_));
  NAND3x1_ASAP7_75t_R g087(.A(new_n135_), .B(new_n141_), .C(new_n144_), .Y(new_n146_));
  NAND3x1_ASAP7_75t_R g088(.A(new_n145_), .B(new_n97_), .C(new_n146_), .Y(new_n147_));
  NAND2x1_ASAP7_75t_R g089(.A(p20), .B(new_n147_), .Y(new_n148_));
  NAND2x1_ASAP7_75t_R g090(.A(new_n123_), .B(new_n148_), .Y(new_n149_));
  OR3x1_ASAP7_75t_R   g091(.A(p3), .B(p1), .C(p2), .Y(new_n150_));
  NOR2x1_ASAP7_75t_R  g092(.A(p4), .B(p1), .Y(new_n151_));
  INVx1_ASAP7_75t_R   g093(.A(new_n151_), .Y(new_n152_));
  NOR2x1_ASAP7_75t_R  g094(.A(p32), .B(new_n131_), .Y(new_n153_));
  AOI21x1_ASAP7_75t_R g095(.A1(new_n150_), .A2(new_n152_), .B(new_n153_), .Y(new_n154_));
  NOR2x1_ASAP7_75t_R  g096(.A(p20), .B(p2), .Y(new_n155_));
  AND2x2_ASAP7_75t_R  g097(.A(new_n146_), .B(new_n145_), .Y(new_n156_));
  NAND2x1_ASAP7_75t_R g098(.A(new_n155_), .B(new_n156_), .Y(new_n157_));
  NAND2x1_ASAP7_75t_R g099(.A(new_n154_), .B(new_n157_), .Y(new_n158_));
  NOR2x1_ASAP7_75t_R  g100(.A(new_n149_), .B(new_n158_), .Y(new_n159_));
  OAI21x1_ASAP7_75t_R g101(.A1(new_n62_), .A2(new_n112_), .B(new_n159_), .Y(new_n160_));
  INVx1_ASAP7_75t_R   g102(.A(p21), .Y(new_n161_));
  NOR2x1_ASAP7_75t_R  g103(.A(p18), .B(new_n161_), .Y(new_n162_));
  INVx1_ASAP7_75t_R   g104(.A(p18), .Y(new_n163_));
  NOR2x1_ASAP7_75t_R  g105(.A(p21), .B(new_n163_), .Y(new_n164_));
  OAI21x1_ASAP7_75t_R g106(.A1(new_n162_), .A2(new_n164_), .B(p6), .Y(new_n165_));
  NAND2x1_ASAP7_75t_R g107(.A(p21), .B(new_n163_), .Y(new_n166_));
  NAND2x1_ASAP7_75t_R g108(.A(p18), .B(new_n161_), .Y(new_n167_));
  INVx1_ASAP7_75t_R   g109(.A(p6), .Y(new_n168_));
  NAND3x1_ASAP7_75t_R g110(.A(new_n166_), .B(new_n167_), .C(new_n168_), .Y(new_n169_));
  NAND2x1_ASAP7_75t_R g111(.A(new_n165_), .B(new_n169_), .Y(new_n170_));
  NAND2x1_ASAP7_75t_R g112(.A(new_n103_), .B(new_n170_), .Y(new_n171_));
  XOR2x2_ASAP7_75t_R  g113(.A(p25), .B(p7), .Y(new_n172_));
  AND2x2_ASAP7_75t_R  g114(.A(p19), .B(new_n172_), .Y(new_n173_));
  NOR2x1_ASAP7_75t_R  g115(.A(p19), .B(new_n172_), .Y(new_n174_));
  NOR2x1_ASAP7_75t_R  g116(.A(p6), .B(new_n161_), .Y(new_n175_));
  AO21x1_ASAP7_75t_R  g117(.A1(p6), .A2(new_n161_), .B(new_n163_), .Y(new_n176_));
  NOR2x1_ASAP7_75t_R  g118(.A(p21), .B(new_n168_), .Y(new_n177_));
  OAI21x1_ASAP7_75t_R g119(.A1(new_n175_), .A2(new_n177_), .B(new_n163_), .Y(new_n178_));
  OAI21x1_ASAP7_75t_R g120(.A1(new_n175_), .A2(new_n176_), .B(new_n178_), .Y(new_n179_));
  OAI21x1_ASAP7_75t_R g121(.A1(new_n173_), .A2(new_n174_), .B(new_n179_), .Y(new_n180_));
  XNOR2x2_ASAP7_75t_R g122(.A(p5), .B(p22), .Y(new_n181_));
  NAND3x1_ASAP7_75t_R g123(.A(new_n171_), .B(new_n180_), .C(new_n181_), .Y(new_n182_));
  NOR2x1_ASAP7_75t_R  g124(.A(new_n179_), .B(new_n82_), .Y(new_n183_));
  NOR2x1_ASAP7_75t_R  g125(.A(new_n103_), .B(new_n170_), .Y(new_n184_));
  INVx1_ASAP7_75t_R   g126(.A(new_n181_), .Y(new_n185_));
  OAI21x1_ASAP7_75t_R g127(.A1(new_n183_), .A2(new_n184_), .B(new_n185_), .Y(new_n186_));
  NAND2x1_ASAP7_75t_R g128(.A(p30), .B(new_n68_), .Y(new_n187_));
  XOR2x2_ASAP7_75t_R  g129(.A(new_n187_), .B(p13), .Y(new_n188_));
  XOR2x2_ASAP7_75t_R  g130(.A(new_n89_), .B(new_n188_), .Y(new_n189_));
  AOI21x1_ASAP7_75t_R g131(.A1(new_n182_), .A2(new_n186_), .B(new_n189_), .Y(new_n190_));
  NAND3x1_ASAP7_75t_R g132(.A(new_n171_), .B(new_n180_), .C(new_n185_), .Y(new_n191_));
  OAI21x1_ASAP7_75t_R g133(.A1(new_n183_), .A2(new_n184_), .B(new_n181_), .Y(new_n192_));
  XNOR2x2_ASAP7_75t_R g134(.A(new_n188_), .B(new_n89_), .Y(new_n193_));
  AOI21x1_ASAP7_75t_R g135(.A1(new_n191_), .A2(new_n192_), .B(new_n193_), .Y(new_n194_));
  INVx1_ASAP7_75t_R   g136(.A(p26), .Y(new_n195_));
  OA21x2_ASAP7_75t_R  g137(.A1(new_n195_), .A2(new_n131_), .B(new_n97_), .Y(new_n196_));
  OAI21x1_ASAP7_75t_R g138(.A1(new_n190_), .A2(new_n194_), .B(new_n196_), .Y(new_n197_));
  AO21x1_ASAP7_75t_R  g139(.A1(new_n131_), .A2(new_n97_), .B(new_n195_), .Y(new_n198_));
  INVx1_ASAP7_75t_R   g140(.A(new_n198_), .Y(new_n199_));
  OAI21x1_ASAP7_75t_R g141(.A1(new_n190_), .A2(new_n194_), .B(new_n97_), .Y(new_n200_));
  NAND2x1_ASAP7_75t_R g142(.A(new_n199_), .B(new_n200_), .Y(new_n201_));
  NAND2x1_ASAP7_75t_R g143(.A(new_n197_), .B(new_n201_), .Y(new_n202_));
  NOR2x1_ASAP7_75t_R  g144(.A(p0), .B(p1), .Y(new_n203_));
  NAND3x1_ASAP7_75t_R g145(.A(new_n203_), .B(p26), .C(new_n75_), .Y(new_n204_));
  AO21x1_ASAP7_75t_R  g146(.A1(p26), .A2(new_n203_), .B(new_n75_), .Y(new_n205_));
  NAND2x1_ASAP7_75t_R g147(.A(new_n204_), .B(new_n205_), .Y(new_n206_));
  XOR2x2_ASAP7_75t_R  g148(.A(new_n179_), .B(new_n206_), .Y(new_n207_));
  NAND3x1_ASAP7_75t_R g149(.A(new_n95_), .B(new_n207_), .C(new_n97_), .Y(new_n208_));
  AO21x1_ASAP7_75t_R  g150(.A1(new_n165_), .A2(new_n169_), .B(new_n206_), .Y(new_n209_));
  NAND2x1_ASAP7_75t_R g151(.A(new_n206_), .B(new_n179_), .Y(new_n210_));
  NAND2x1_ASAP7_75t_R g152(.A(new_n209_), .B(new_n210_), .Y(new_n211_));
  NAND3x1_ASAP7_75t_R g153(.A(new_n98_), .B(new_n211_), .C(new_n97_), .Y(new_n212_));
  INVx1_ASAP7_75t_R   g154(.A(p27), .Y(new_n213_));
  NAND3x1_ASAP7_75t_R g155(.A(new_n208_), .B(new_n212_), .C(new_n213_), .Y(new_n214_));
  NOR2x1_ASAP7_75t_R  g156(.A(new_n211_), .B(new_n98_), .Y(new_n215_));
  NOR2x1_ASAP7_75t_R  g157(.A(new_n207_), .B(new_n95_), .Y(new_n216_));
  NOR2x1_ASAP7_75t_R  g158(.A(p2), .B(new_n213_), .Y(new_n217_));
  OAI21x1_ASAP7_75t_R g159(.A1(new_n215_), .A2(new_n216_), .B(new_n217_), .Y(new_n218_));
  NOR3x1_ASAP7_75t_R  g160(.A(new_n129_), .B(p22), .C(new_n126_), .Y(new_n219_));
  INVx1_ASAP7_75t_R   g161(.A(p22), .Y(new_n220_));
  AOI21x1_ASAP7_75t_R g162(.A1(new_n137_), .A2(new_n138_), .B(new_n220_), .Y(new_n221_));
  NOR2x1_ASAP7_75t_R  g163(.A(p32), .B(p1), .Y(new_n222_));
  NOR2x1_ASAP7_75t_R  g164(.A(p24), .B(new_n59_), .Y(new_n223_));
  INVx1_ASAP7_75t_R   g165(.A(p24), .Y(new_n224_));
  AOI21x1_ASAP7_75t_R g166(.A1(p23), .A2(new_n222_), .B(new_n224_), .Y(new_n225_));
  AOI21x1_ASAP7_75t_R g167(.A1(new_n222_), .A2(new_n223_), .B(new_n225_), .Y(new_n226_));
  OAI21x1_ASAP7_75t_R g168(.A1(new_n219_), .A2(new_n221_), .B(new_n226_), .Y(new_n227_));
  NAND3x1_ASAP7_75t_R g169(.A(new_n138_), .B(new_n137_), .C(new_n220_), .Y(new_n228_));
  OAI21x1_ASAP7_75t_R g170(.A1(new_n126_), .A2(new_n129_), .B(p22), .Y(new_n229_));
  AO21x1_ASAP7_75t_R  g171(.A1(new_n222_), .A2(new_n223_), .B(new_n225_), .Y(new_n230_));
  NAND3x1_ASAP7_75t_R g172(.A(new_n228_), .B(new_n229_), .C(new_n230_), .Y(new_n231_));
  XOR2x2_ASAP7_75t_R  g173(.A(p9), .B(p21), .Y(new_n232_));
  INVx1_ASAP7_75t_R   g174(.A(new_n232_), .Y(new_n233_));
  NAND3x1_ASAP7_75t_R g175(.A(new_n227_), .B(new_n231_), .C(new_n233_), .Y(new_n234_));
  OA21x2_ASAP7_75t_R  g176(.A1(p32), .A2(p2), .B(p11), .Y(new_n235_));
  AND3x1_ASAP7_75t_R  g177(.A(new_n113_), .B(new_n68_), .C(p23), .Y(new_n236_));
  XNOR2x2_ASAP7_75t_R g178(.A(p24), .B(p22), .Y(new_n237_));
  NAND2x1_ASAP7_75t_R g179(.A(new_n236_), .B(new_n237_), .Y(new_n238_));
  NAND2x1_ASAP7_75t_R g180(.A(p23), .B(new_n222_), .Y(new_n239_));
  XOR2x2_ASAP7_75t_R  g181(.A(p24), .B(p22), .Y(new_n240_));
  NAND2x1_ASAP7_75t_R g182(.A(new_n239_), .B(new_n240_), .Y(new_n241_));
  NAND3x1_ASAP7_75t_R g183(.A(new_n139_), .B(new_n238_), .C(new_n241_), .Y(new_n242_));
  NOR2x1_ASAP7_75t_R  g184(.A(new_n236_), .B(new_n237_), .Y(new_n243_));
  NOR2x1_ASAP7_75t_R  g185(.A(new_n239_), .B(new_n240_), .Y(new_n244_));
  OAI21x1_ASAP7_75t_R g186(.A1(new_n243_), .A2(new_n244_), .B(new_n130_), .Y(new_n245_));
  NAND3x1_ASAP7_75t_R g187(.A(new_n242_), .B(new_n245_), .C(new_n232_), .Y(new_n246_));
  NAND3x1_ASAP7_75t_R g188(.A(new_n234_), .B(new_n235_), .C(new_n246_), .Y(new_n247_));
  AO21x1_ASAP7_75t_R  g189(.A1(new_n245_), .A2(new_n242_), .B(new_n233_), .Y(new_n248_));
  NAND3x1_ASAP7_75t_R g190(.A(new_n242_), .B(new_n245_), .C(new_n233_), .Y(new_n249_));
  NOR2x1_ASAP7_75t_R  g191(.A(p2), .B(new_n235_), .Y(new_n250_));
  NAND3x1_ASAP7_75t_R g192(.A(new_n248_), .B(new_n249_), .C(new_n250_), .Y(new_n251_));
  AND2x2_ASAP7_75t_R  g193(.A(p2), .B(new_n235_), .Y(new_n252_));
  INVx1_ASAP7_75t_R   g194(.A(new_n252_), .Y(new_n253_));
  NAND3x1_ASAP7_75t_R g195(.A(new_n247_), .B(new_n251_), .C(new_n253_), .Y(new_n254_));
  AOI21x1_ASAP7_75t_R g196(.A1(new_n214_), .A2(new_n218_), .B(new_n254_), .Y(new_n255_));
  INVx1_ASAP7_75t_R   g197(.A(new_n255_), .Y(new_n256_));
  OA21x2_ASAP7_75t_R  g198(.A1(p0), .A2(p2), .B(p16), .Y(new_n257_));
  INVx1_ASAP7_75t_R   g199(.A(new_n257_), .Y(new_n258_));
  OR3x1_ASAP7_75t_R   g200(.A(new_n202_), .B(new_n256_), .C(new_n258_), .Y(new_n259_));
  OAI21x1_ASAP7_75t_R g201(.A1(new_n160_), .A2(new_n259_), .B(p14), .Y(new_n260_));
  OR3x1_ASAP7_75t_R   g202(.A(new_n259_), .B(new_n160_), .C(p14), .Y(new_n261_));
  AND2x2_ASAP7_75t_R  g203(.A(new_n260_), .B(new_n261_), .Y(o0));
  AOI21x1_ASAP7_75t_R g204(.A1(new_n197_), .A2(new_n201_), .B(new_n258_), .Y(new_n263_));
  OAI21x1_ASAP7_75t_R g205(.A1(new_n62_), .A2(new_n112_), .B(new_n255_), .Y(new_n264_));
  OR3x1_ASAP7_75t_R   g206(.A(p1), .B(p31), .C(p2), .Y(new_n265_));
  AO21x1_ASAP7_75t_R  g207(.A1(new_n265_), .A2(new_n152_), .B(new_n153_), .Y(new_n266_));
  AOI21x1_ASAP7_75t_R g208(.A1(new_n121_), .A2(new_n122_), .B(new_n266_), .Y(new_n267_));
  NAND3x1_ASAP7_75t_R g209(.A(new_n157_), .B(new_n267_), .C(new_n148_), .Y(new_n268_));
  NOR3x1_ASAP7_75t_R  g210(.A(new_n263_), .B(new_n264_), .C(new_n268_), .Y(new_n269_));
  XOR2x2_ASAP7_75t_R  g211(.A(new_n269_), .B(new_n75_), .Y(o1));
  XOR2x2_ASAP7_75t_R  g212(.A(new_n269_), .B(new_n80_), .Y(o2));
  OAI21x1_ASAP7_75t_R g213(.A1(new_n160_), .A2(new_n259_), .B(new_n224_), .Y(new_n272_));
  OR3x1_ASAP7_75t_R   g214(.A(new_n259_), .B(new_n160_), .C(new_n224_), .Y(new_n273_));
  NAND2x1_ASAP7_75t_R g215(.A(new_n272_), .B(new_n273_), .Y(o3));
  XOR2x2_ASAP7_75t_R  g216(.A(new_n269_), .B(new_n73_), .Y(o4));
  XOR2x2_ASAP7_75t_R  g217(.A(new_n269_), .B(new_n220_), .Y(o5));
  AOI21x1_ASAP7_75t_R g218(.A1(new_n257_), .A2(new_n202_), .B(new_n264_), .Y(new_n277_));
  NAND2x1_ASAP7_75t_R g219(.A(new_n159_), .B(new_n277_), .Y(new_n278_));
  XOR2x2_ASAP7_75t_R  g220(.A(new_n278_), .B(p9), .Y(o6));
  XOR2x2_ASAP7_75t_R  g221(.A(new_n278_), .B(p8), .Y(o7));
  XOR2x2_ASAP7_75t_R  g222(.A(new_n278_), .B(p15), .Y(o8));
  NAND2x1_ASAP7_75t_R g223(.A(new_n61_), .B(new_n112_), .Y(new_n282_));
  OR3x1_ASAP7_75t_R   g224(.A(new_n263_), .B(new_n256_), .C(new_n282_), .Y(new_n283_));
  AO21x1_ASAP7_75t_R  g225(.A1(new_n156_), .A2(new_n155_), .B(new_n149_), .Y(new_n284_));
  OR3x1_ASAP7_75t_R   g226(.A(new_n284_), .B(p18), .C(new_n266_), .Y(new_n285_));
  NOR2x1_ASAP7_75t_R  g227(.A(new_n268_), .B(new_n282_), .Y(new_n286_));
  NOR2x1_ASAP7_75t_R  g228(.A(new_n256_), .B(new_n263_), .Y(new_n287_));
  AO21x1_ASAP7_75t_R  g229(.A1(new_n286_), .A2(new_n287_), .B(new_n163_), .Y(new_n288_));
  OA21x2_ASAP7_75t_R  g230(.A1(new_n283_), .A2(new_n285_), .B(new_n288_), .Y(o9));
  AND3x1_ASAP7_75t_R  g231(.A(new_n157_), .B(new_n267_), .C(new_n148_), .Y(new_n290_));
  NAND2x1_ASAP7_75t_R g232(.A(new_n168_), .B(new_n290_), .Y(new_n291_));
  AO21x1_ASAP7_75t_R  g233(.A1(new_n286_), .A2(new_n287_), .B(new_n168_), .Y(new_n292_));
  OA21x2_ASAP7_75t_R  g234(.A1(new_n283_), .A2(new_n291_), .B(new_n292_), .Y(o10));
  NAND2x1_ASAP7_75t_R g235(.A(new_n161_), .B(new_n290_), .Y(new_n294_));
  AO21x1_ASAP7_75t_R  g236(.A1(new_n286_), .A2(new_n287_), .B(new_n161_), .Y(new_n295_));
  OA21x2_ASAP7_75t_R  g237(.A1(new_n283_), .A2(new_n294_), .B(new_n295_), .Y(o11));
  OR3x1_ASAP7_75t_R   g238(.A(new_n284_), .B(p5), .C(new_n266_), .Y(new_n297_));
  AO21x1_ASAP7_75t_R  g239(.A1(new_n286_), .A2(new_n287_), .B(new_n133_), .Y(new_n298_));
  OA21x2_ASAP7_75t_R  g240(.A1(new_n283_), .A2(new_n297_), .B(new_n298_), .Y(o12));
  INVx1_ASAP7_75t_R   g241(.A(new_n282_), .Y(new_n300_));
  AND3x1_ASAP7_75t_R  g242(.A(new_n287_), .B(new_n159_), .C(new_n300_), .Y(new_n301_));
  INVx1_ASAP7_75t_R   g243(.A(new_n149_), .Y(new_n302_));
  AND3x1_ASAP7_75t_R  g244(.A(new_n157_), .B(p13), .C(new_n154_), .Y(new_n303_));
  AND3x1_ASAP7_75t_R  g245(.A(new_n300_), .B(new_n302_), .C(new_n303_), .Y(new_n304_));
  NAND2x1_ASAP7_75t_R g246(.A(new_n287_), .B(new_n304_), .Y(new_n305_));
  OAI21x1_ASAP7_75t_R g247(.A1(p13), .A2(new_n301_), .B(new_n305_), .Y(o13));
  OAI21x1_ASAP7_75t_R g248(.A1(new_n160_), .A2(new_n259_), .B(p17), .Y(new_n307_));
  OR3x1_ASAP7_75t_R   g249(.A(new_n259_), .B(new_n160_), .C(p17), .Y(new_n308_));
  AND2x2_ASAP7_75t_R  g250(.A(new_n307_), .B(new_n308_), .Y(o14));
  OAI21x1_ASAP7_75t_R g251(.A1(new_n160_), .A2(new_n259_), .B(p10), .Y(new_n310_));
  OR3x1_ASAP7_75t_R   g252(.A(new_n259_), .B(new_n160_), .C(p10), .Y(new_n311_));
  AND2x2_ASAP7_75t_R  g253(.A(new_n310_), .B(new_n311_), .Y(o15));
  INVx1_ASAP7_75t_R   g254(.A(p4), .Y(new_n313_));
  OA21x2_ASAP7_75t_R  g255(.A1(new_n153_), .A2(new_n150_), .B(new_n266_), .Y(new_n314_));
  AOI21x1_ASAP7_75t_R g256(.A1(new_n155_), .A2(new_n156_), .B(new_n314_), .Y(new_n315_));
  NAND3x1_ASAP7_75t_R g257(.A(new_n315_), .B(new_n148_), .C(new_n123_), .Y(new_n316_));
  OR3x1_ASAP7_75t_R   g258(.A(new_n263_), .B(new_n264_), .C(new_n316_), .Y(new_n317_));
  AND3x1_ASAP7_75t_R  g259(.A(new_n197_), .B(new_n258_), .C(new_n62_), .Y(new_n318_));
  AND3x1_ASAP7_75t_R  g260(.A(new_n318_), .B(new_n201_), .C(new_n112_), .Y(new_n319_));
  NAND2x1_ASAP7_75t_R g261(.A(new_n255_), .B(new_n319_), .Y(new_n320_));
  OA21x2_ASAP7_75t_R  g262(.A1(new_n284_), .A2(new_n320_), .B(new_n68_), .Y(new_n321_));
  OAI21x1_ASAP7_75t_R g263(.A1(new_n313_), .A2(new_n317_), .B(new_n321_), .Y(o16));
  NOR2x1_ASAP7_75t_R  g264(.A(new_n198_), .B(new_n200_), .Y(new_n323_));
  NOR3x1_ASAP7_75t_R  g265(.A(new_n263_), .B(new_n264_), .C(new_n316_), .Y(new_n324_));
  AO21x1_ASAP7_75t_R  g266(.A1(new_n323_), .A2(new_n324_), .B(new_n151_), .Y(new_n325_));
  OR3x1_ASAP7_75t_R   g267(.A(new_n195_), .B(new_n131_), .C(p2), .Y(new_n326_));
  NOR2x1_ASAP7_75t_R  g268(.A(new_n190_), .B(new_n194_), .Y(new_n327_));
  OA21x2_ASAP7_75t_R  g269(.A1(new_n326_), .A2(new_n317_), .B(new_n327_), .Y(new_n328_));
  NOR2x1_ASAP7_75t_R  g270(.A(new_n325_), .B(new_n328_), .Y(o17));
  NAND2x1_ASAP7_75t_R g271(.A(new_n108_), .B(new_n109_), .Y(new_n330_));
  AND3x1_ASAP7_75t_R  g272(.A(new_n324_), .B(p29), .C(new_n97_), .Y(new_n331_));
  AND3x1_ASAP7_75t_R  g273(.A(new_n330_), .B(p29), .C(new_n97_), .Y(new_n332_));
  AOI21x1_ASAP7_75t_R g274(.A1(new_n332_), .A2(new_n324_), .B(new_n151_), .Y(new_n333_));
  OA21x2_ASAP7_75t_R  g275(.A1(new_n330_), .A2(new_n331_), .B(new_n333_), .Y(o18));
  NAND2x1_ASAP7_75t_R g276(.A(p20), .B(new_n324_), .Y(new_n335_));
  AOI21x1_ASAP7_75t_R g277(.A1(new_n156_), .A2(new_n335_), .B(new_n151_), .Y(o19));
  NAND2x1_ASAP7_75t_R g278(.A(p12), .B(new_n324_), .Y(new_n337_));
  AOI21x1_ASAP7_75t_R g279(.A1(new_n120_), .A2(new_n337_), .B(new_n151_), .Y(o20));
  NAND2x1_ASAP7_75t_R g280(.A(new_n249_), .B(new_n248_), .Y(new_n339_));
  AO21x1_ASAP7_75t_R  g281(.A1(new_n235_), .A2(new_n324_), .B(new_n339_), .Y(new_n340_));
  AND2x2_ASAP7_75t_R  g282(.A(new_n152_), .B(new_n340_), .Y(o21));
  AO21x1_ASAP7_75t_R  g283(.A1(p31), .A2(p30), .B(p1), .Y(new_n342_));
  INVx1_ASAP7_75t_R   g284(.A(new_n342_), .Y(new_n343_));
  NOR2x1_ASAP7_75t_R  g285(.A(p1), .B(p31), .Y(new_n344_));
  AO21x1_ASAP7_75t_R  g286(.A1(new_n191_), .A2(new_n192_), .B(new_n344_), .Y(new_n345_));
  INVx1_ASAP7_75t_R   g287(.A(new_n345_), .Y(new_n346_));
  OR3x1_ASAP7_75t_R   g288(.A(new_n263_), .B(new_n264_), .C(new_n268_), .Y(new_n347_));
  NAND2x1_ASAP7_75t_R g289(.A(new_n345_), .B(new_n290_), .Y(new_n348_));
  NOR3x1_ASAP7_75t_R  g290(.A(new_n348_), .B(new_n264_), .C(new_n263_), .Y(new_n349_));
  AOI21x1_ASAP7_75t_R g291(.A1(new_n346_), .A2(new_n347_), .B(new_n349_), .Y(new_n350_));
  NOR2x1_ASAP7_75t_R  g292(.A(new_n346_), .B(new_n268_), .Y(new_n351_));
  AOI21x1_ASAP7_75t_R g293(.A1(new_n351_), .A2(new_n277_), .B(new_n342_), .Y(new_n352_));
  OAI21x1_ASAP7_75t_R g294(.A1(new_n269_), .A2(new_n345_), .B(new_n352_), .Y(new_n353_));
  OAI21x1_ASAP7_75t_R g295(.A1(new_n343_), .A2(new_n350_), .B(new_n353_), .Y(o22));
  NOR2x1_ASAP7_75t_R  g296(.A(new_n136_), .B(new_n125_), .Y(new_n355_));
  XOR2x2_ASAP7_75t_R  g297(.A(new_n98_), .B(new_n355_), .Y(new_n356_));
  NOR2x1_ASAP7_75t_R  g298(.A(p28), .B(p1), .Y(new_n357_));
  XOR2x2_ASAP7_75t_R  g299(.A(new_n356_), .B(new_n357_), .Y(new_n358_));
  OA21x2_ASAP7_75t_R  g300(.A1(p3), .A2(p1), .B(new_n358_), .Y(new_n359_));
  XOR2x2_ASAP7_75t_R  g301(.A(new_n278_), .B(new_n359_), .Y(o23));
  NOR2x1_ASAP7_75t_R  g302(.A(new_n215_), .B(new_n216_), .Y(new_n361_));
  AO21x1_ASAP7_75t_R  g303(.A1(p27), .A2(new_n324_), .B(new_n151_), .Y(new_n362_));
  NOR2x1_ASAP7_75t_R  g304(.A(new_n361_), .B(new_n362_), .Y(o24));
endmodule


