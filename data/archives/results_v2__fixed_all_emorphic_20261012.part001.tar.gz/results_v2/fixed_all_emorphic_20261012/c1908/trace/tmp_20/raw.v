// Benchmark "/tmp/" written by ABC on Mon Oct 12 15:05:23 2026

module \/tmp/  ( 
    p2, p29, p20, p19, p8, p16, p18, p9, p11, p12, p3, p22, p26, p14, p6,
    p25, p23, p24, p28, p5, p1, p13, p32, p10, p31, p30, p0, p15, p7, p21,
    p4, p17, p27,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24  );
  input  p2, p29, p20, p19, p8, p16, p18, p9, p11, p12, p3, p22, p26,
    p14, p6, p25, p23, p24, p28, p5, p1, p13, p32, p10, p31, p30, p0, p15,
    p7, p21, p4, p17, p27;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24;
  wire new_n59_, new_n60_, new_n61_, new_n62_, new_n63_, new_n64_, new_n65_,
    new_n66_, new_n67_, new_n68_, new_n69_, new_n70_, new_n71_, new_n72_,
    new_n73_, new_n74_, new_n75_, new_n76_, new_n77_, new_n78_, new_n79_,
    new_n80_, new_n81_, new_n82_, new_n83_, new_n84_, new_n85_, new_n86_,
    new_n87_, new_n88_, new_n89_, new_n90_, new_n91_, new_n92_, new_n93_,
    new_n94_, new_n95_, new_n96_, new_n97_, new_n98_, new_n99_, new_n100_,
    new_n101_, new_n102_, new_n103_, new_n104_, new_n105_, new_n106_,
    new_n107_, new_n108_, new_n109_, new_n110_, new_n111_, new_n112_,
    new_n113_, new_n114_, new_n115_, new_n116_, new_n117_, new_n118_,
    new_n119_, new_n120_, new_n121_, new_n122_, new_n123_, new_n124_,
    new_n125_, new_n126_, new_n127_, new_n128_, new_n129_, new_n130_,
    new_n131_, new_n132_, new_n133_, new_n134_, new_n135_, new_n136_,
    new_n137_, new_n138_, new_n139_, new_n140_, new_n141_, new_n142_,
    new_n143_, new_n144_, new_n145_, new_n146_, new_n147_, new_n148_,
    new_n149_, new_n150_, new_n151_, new_n152_, new_n153_, new_n154_,
    new_n155_, new_n156_, new_n157_, new_n158_, new_n159_, new_n160_,
    new_n161_, new_n162_, new_n163_, new_n164_, new_n165_, new_n166_,
    new_n167_, new_n168_, new_n169_, new_n170_, new_n171_, new_n172_,
    new_n173_, new_n174_, new_n175_, new_n176_, new_n177_, new_n178_,
    new_n179_, new_n180_, new_n181_, new_n182_, new_n183_, new_n184_,
    new_n185_, new_n186_, new_n187_, new_n188_, new_n189_, new_n190_,
    new_n191_, new_n192_, new_n193_, new_n194_, new_n195_, new_n196_,
    new_n197_, new_n198_, new_n199_, new_n200_, new_n201_, new_n202_,
    new_n203_, new_n204_, new_n205_, new_n206_, new_n207_, new_n208_,
    new_n209_, new_n210_, new_n211_, new_n212_, new_n213_, new_n214_,
    new_n215_, new_n216_, new_n217_, new_n218_, new_n219_, new_n220_,
    new_n221_, new_n222_, new_n223_, new_n224_, new_n225_, new_n226_,
    new_n227_, new_n228_, new_n229_, new_n230_, new_n231_, new_n232_,
    new_n233_, new_n234_, new_n235_, new_n236_, new_n237_, new_n238_,
    new_n239_, new_n240_, new_n241_, new_n242_, new_n243_, new_n244_,
    new_n245_, new_n246_, new_n247_, new_n248_, new_n249_, new_n250_,
    new_n251_, new_n252_, new_n253_, new_n254_, new_n255_, new_n256_,
    new_n257_, new_n258_, new_n259_, new_n260_, new_n261_, new_n263_,
    new_n264_, new_n265_, new_n266_, new_n267_, new_n268_, new_n269_,
    new_n270_, new_n273_, new_n274_, new_n278_, new_n279_, new_n280_,
    new_n284_, new_n285_, new_n286_, new_n287_, new_n288_, new_n289_,
    new_n290_, new_n291_, new_n292_, new_n294_, new_n295_, new_n296_,
    new_n298_, new_n299_, new_n301_, new_n302_, new_n304_, new_n305_,
    new_n306_, new_n307_, new_n308_, new_n309_, new_n311_, new_n312_,
    new_n314_, new_n315_, new_n317_, new_n318_, new_n319_, new_n320_,
    new_n321_, new_n322_, new_n323_, new_n324_, new_n325_, new_n327_,
    new_n328_, new_n329_, new_n330_, new_n331_, new_n332_, new_n334_,
    new_n335_, new_n336_, new_n337_, new_n338_, new_n340_, new_n341_,
    new_n343_, new_n345_, new_n346_, new_n348_, new_n349_, new_n350_,
    new_n351_, new_n352_, new_n353_, new_n354_, new_n355_, new_n356_,
    new_n357_, new_n358_, new_n359_, new_n361_, new_n362_, new_n363_,
    new_n364_, new_n365_, new_n367_;
  INVx1_ASAP7_75t_R   g000(.A(p23), .Y(new_n59_));
  NOR2x1_ASAP7_75t_R  g001(.A(p2), .B(p32), .Y(new_n60_));
  NOR2x1_ASAP7_75t_R  g002(.A(new_n59_), .B(new_n60_), .Y(new_n61_));
  INVx1_ASAP7_75t_R   g003(.A(new_n61_), .Y(new_n62_));
  NOR2x1_ASAP7_75t_R  g004(.A(p22), .B(p14), .Y(new_n63_));
  AND2x2_ASAP7_75t_R  g005(.A(p22), .B(p14), .Y(new_n64_));
  INVx1_ASAP7_75t_R   g006(.A(p28), .Y(new_n65_));
  NOR2x1_ASAP7_75t_R  g007(.A(p1), .B(new_n65_), .Y(new_n66_));
  OAI21x1_ASAP7_75t_R g008(.A1(new_n63_), .A2(new_n64_), .B(new_n66_), .Y(new_n67_));
  INVx1_ASAP7_75t_R   g009(.A(p1), .Y(new_n68_));
  NAND2x1_ASAP7_75t_R g010(.A(p28), .B(new_n68_), .Y(new_n69_));
  XOR2x2_ASAP7_75t_R  g011(.A(p22), .B(p14), .Y(new_n70_));
  NAND2x1_ASAP7_75t_R g012(.A(new_n69_), .B(new_n70_), .Y(new_n71_));
  NAND2x1_ASAP7_75t_R g013(.A(new_n67_), .B(new_n71_), .Y(new_n72_));
  INVx1_ASAP7_75t_R   g014(.A(p7), .Y(new_n73_));
  NOR2x1_ASAP7_75t_R  g015(.A(p25), .B(new_n73_), .Y(new_n74_));
  INVx1_ASAP7_75t_R   g016(.A(p25), .Y(new_n75_));
  NOR2x1_ASAP7_75t_R  g017(.A(p7), .B(new_n75_), .Y(new_n76_));
  OAI21x1_ASAP7_75t_R g018(.A1(new_n74_), .A2(new_n76_), .B(p19), .Y(new_n77_));
  NAND2x1_ASAP7_75t_R g019(.A(p7), .B(new_n75_), .Y(new_n78_));
  NAND2x1_ASAP7_75t_R g020(.A(p25), .B(new_n73_), .Y(new_n79_));
  INVx1_ASAP7_75t_R   g021(.A(p19), .Y(new_n80_));
  NAND3x1_ASAP7_75t_R g022(.A(new_n78_), .B(new_n79_), .C(new_n80_), .Y(new_n81_));
  NAND2x1_ASAP7_75t_R g023(.A(new_n77_), .B(new_n81_), .Y(new_n82_));
  XOR2x2_ASAP7_75t_R  g024(.A(new_n72_), .B(new_n82_), .Y(new_n83_));
  NOR2x1_ASAP7_75t_R  g025(.A(p8), .B(p9), .Y(new_n84_));
  AND2x2_ASAP7_75t_R  g026(.A(p8), .B(p9), .Y(new_n85_));
  INVx1_ASAP7_75t_R   g027(.A(p15), .Y(new_n86_));
  OAI21x1_ASAP7_75t_R g028(.A1(new_n84_), .A2(new_n85_), .B(new_n86_), .Y(new_n87_));
  OR3x1_ASAP7_75t_R   g029(.A(new_n85_), .B(new_n86_), .C(new_n84_), .Y(new_n88_));
  NAND2x1_ASAP7_75t_R g030(.A(new_n87_), .B(new_n88_), .Y(new_n89_));
  NOR2x1_ASAP7_75t_R  g031(.A(p24), .B(p10), .Y(new_n90_));
  AND2x2_ASAP7_75t_R  g032(.A(p24), .B(p10), .Y(new_n91_));
  OAI21x1_ASAP7_75t_R g033(.A1(new_n90_), .A2(new_n91_), .B(p17), .Y(new_n92_));
  OR3x1_ASAP7_75t_R   g034(.A(new_n91_), .B(p17), .C(new_n90_), .Y(new_n93_));
  NAND2x1_ASAP7_75t_R g035(.A(new_n92_), .B(new_n93_), .Y(new_n94_));
  XNOR2x2_ASAP7_75t_R g036(.A(new_n89_), .B(new_n94_), .Y(new_n95_));
  OR3x1_ASAP7_75t_R   g037(.A(new_n83_), .B(new_n95_), .C(p2), .Y(new_n96_));
  INVx1_ASAP7_75t_R   g038(.A(p2), .Y(new_n97_));
  XOR2x2_ASAP7_75t_R  g039(.A(new_n89_), .B(new_n94_), .Y(new_n98_));
  NOR2x1_ASAP7_75t_R  g040(.A(p19), .B(new_n73_), .Y(new_n99_));
  AO21x1_ASAP7_75t_R  g041(.A1(p19), .A2(new_n73_), .B(new_n75_), .Y(new_n100_));
  NOR2x1_ASAP7_75t_R  g042(.A(p7), .B(new_n80_), .Y(new_n101_));
  OAI21x1_ASAP7_75t_R g043(.A1(new_n99_), .A2(new_n101_), .B(new_n75_), .Y(new_n102_));
  OAI21x1_ASAP7_75t_R g044(.A1(new_n99_), .A2(new_n100_), .B(new_n102_), .Y(new_n103_));
  XOR2x2_ASAP7_75t_R  g045(.A(new_n72_), .B(new_n103_), .Y(new_n104_));
  NOR2x1_ASAP7_75t_R  g046(.A(new_n98_), .B(new_n104_), .Y(new_n105_));
  INVx1_ASAP7_75t_R   g047(.A(p29), .Y(new_n106_));
  AOI21x1_ASAP7_75t_R g048(.A1(new_n97_), .A2(new_n105_), .B(new_n106_), .Y(new_n107_));
  NAND2x1_ASAP7_75t_R g049(.A(new_n98_), .B(new_n104_), .Y(new_n108_));
  NAND2x1_ASAP7_75t_R g050(.A(new_n95_), .B(new_n83_), .Y(new_n109_));
  NAND2x1_ASAP7_75t_R g051(.A(new_n97_), .B(new_n106_), .Y(new_n110_));
  AOI21x1_ASAP7_75t_R g052(.A1(new_n108_), .A2(new_n109_), .B(new_n110_), .Y(new_n111_));
  AOI21x1_ASAP7_75t_R g053(.A1(new_n96_), .A2(new_n107_), .B(new_n111_), .Y(new_n112_));
  OR3x1_ASAP7_75t_R   g054(.A(p2), .B(p3), .C(p1), .Y(new_n113_));
  NOR2x1_ASAP7_75t_R  g055(.A(p1), .B(p4), .Y(new_n114_));
  INVx1_ASAP7_75t_R   g056(.A(new_n114_), .Y(new_n115_));
  INVx1_ASAP7_75t_R   g057(.A(p0), .Y(new_n116_));
  NOR2x1_ASAP7_75t_R  g058(.A(p32), .B(new_n116_), .Y(new_n117_));
  AOI21x1_ASAP7_75t_R g059(.A1(new_n113_), .A2(new_n115_), .B(new_n117_), .Y(new_n118_));
  NAND2x1_ASAP7_75t_R g060(.A(p14), .B(p13), .Y(new_n119_));
  OR3x1_ASAP7_75t_R   g061(.A(p14), .B(p13), .C(p15), .Y(new_n120_));
  OAI21x1_ASAP7_75t_R g062(.A1(p15), .A2(new_n119_), .B(new_n120_), .Y(new_n121_));
  AND3x1_ASAP7_75t_R  g063(.A(new_n68_), .B(new_n116_), .C(p16), .Y(new_n122_));
  OAI21x1_ASAP7_75t_R g064(.A1(p14), .A2(p13), .B(p15), .Y(new_n123_));
  AND2x2_ASAP7_75t_R  g065(.A(p14), .B(p13), .Y(new_n124_));
  NOR2x1_ASAP7_75t_R  g066(.A(new_n123_), .B(new_n124_), .Y(new_n125_));
  OR3x1_ASAP7_75t_R   g067(.A(new_n121_), .B(new_n122_), .C(new_n125_), .Y(new_n126_));
  NOR2x1_ASAP7_75t_R  g068(.A(p14), .B(p13), .Y(new_n127_));
  OAI21x1_ASAP7_75t_R g069(.A1(new_n127_), .A2(new_n124_), .B(new_n86_), .Y(new_n128_));
  AO21x1_ASAP7_75t_R  g070(.A1(p14), .A2(p13), .B(new_n123_), .Y(new_n129_));
  NAND2x1_ASAP7_75t_R g071(.A(new_n128_), .B(new_n129_), .Y(new_n130_));
  NAND2x1_ASAP7_75t_R g072(.A(new_n122_), .B(new_n130_), .Y(new_n131_));
  NOR2x1_ASAP7_75t_R  g073(.A(p18), .B(p5), .Y(new_n132_));
  AND2x2_ASAP7_75t_R  g074(.A(p18), .B(p5), .Y(new_n133_));
  OAI21x1_ASAP7_75t_R g075(.A1(new_n132_), .A2(new_n133_), .B(p19), .Y(new_n134_));
  OR3x1_ASAP7_75t_R   g076(.A(new_n133_), .B(p19), .C(new_n132_), .Y(new_n135_));
  NAND2x1_ASAP7_75t_R g077(.A(new_n134_), .B(new_n135_), .Y(new_n136_));
  AOI21x1_ASAP7_75t_R g078(.A1(new_n126_), .A2(new_n131_), .B(new_n136_), .Y(new_n137_));
  AND3x1_ASAP7_75t_R  g079(.A(new_n131_), .B(new_n136_), .C(new_n126_), .Y(new_n138_));
  XNOR2x2_ASAP7_75t_R g080(.A(p8), .B(p17), .Y(new_n139_));
  INVx1_ASAP7_75t_R   g081(.A(new_n139_), .Y(new_n140_));
  OAI21x1_ASAP7_75t_R g082(.A1(new_n137_), .A2(new_n138_), .B(new_n140_), .Y(new_n141_));
  AND2x2_ASAP7_75t_R  g083(.A(new_n122_), .B(new_n130_), .Y(new_n142_));
  NAND2x1_ASAP7_75t_R g084(.A(new_n136_), .B(new_n126_), .Y(new_n143_));
  OAI21x1_ASAP7_75t_R g085(.A1(new_n142_), .A2(new_n143_), .B(new_n139_), .Y(new_n144_));
  NOR2x1_ASAP7_75t_R  g086(.A(p2), .B(p20), .Y(new_n145_));
  OA21x2_ASAP7_75t_R  g087(.A1(new_n137_), .A2(new_n144_), .B(new_n145_), .Y(new_n146_));
  NAND2x1_ASAP7_75t_R g088(.A(new_n141_), .B(new_n146_), .Y(new_n147_));
  NAND2x1_ASAP7_75t_R g089(.A(new_n118_), .B(new_n147_), .Y(new_n148_));
  OAI21x1_ASAP7_75t_R g090(.A1(new_n137_), .A2(new_n144_), .B(new_n97_), .Y(new_n149_));
  OA21x2_ASAP7_75t_R  g091(.A1(new_n137_), .A2(new_n138_), .B(new_n140_), .Y(new_n150_));
  OAI21x1_ASAP7_75t_R g092(.A1(new_n149_), .A2(new_n150_), .B(p20), .Y(new_n151_));
  NOR2x1_ASAP7_75t_R  g093(.A(p1), .B(p32), .Y(new_n152_));
  NAND2x1_ASAP7_75t_R g094(.A(p11), .B(new_n152_), .Y(new_n153_));
  XOR2x2_ASAP7_75t_R  g095(.A(p8), .B(p9), .Y(new_n154_));
  XNOR2x2_ASAP7_75t_R g096(.A(new_n153_), .B(new_n154_), .Y(new_n155_));
  XOR2x2_ASAP7_75t_R  g097(.A(p6), .B(p5), .Y(new_n156_));
  XOR2x2_ASAP7_75t_R  g098(.A(p10), .B(p7), .Y(new_n157_));
  XOR2x2_ASAP7_75t_R  g099(.A(new_n156_), .B(new_n157_), .Y(new_n158_));
  XOR2x2_ASAP7_75t_R  g100(.A(new_n155_), .B(new_n158_), .Y(new_n159_));
  NAND3x1_ASAP7_75t_R g101(.A(new_n159_), .B(new_n97_), .C(p12), .Y(new_n160_));
  AO21x1_ASAP7_75t_R  g102(.A1(new_n97_), .A2(new_n159_), .B(p12), .Y(new_n161_));
  NAND2x1_ASAP7_75t_R g103(.A(new_n160_), .B(new_n161_), .Y(new_n162_));
  NAND2x1_ASAP7_75t_R g104(.A(new_n151_), .B(new_n162_), .Y(new_n163_));
  NOR2x1_ASAP7_75t_R  g105(.A(new_n148_), .B(new_n163_), .Y(new_n164_));
  OAI21x1_ASAP7_75t_R g106(.A1(new_n62_), .A2(new_n112_), .B(new_n164_), .Y(new_n165_));
  INVx1_ASAP7_75t_R   g107(.A(p21), .Y(new_n166_));
  NOR2x1_ASAP7_75t_R  g108(.A(p6), .B(new_n166_), .Y(new_n167_));
  INVx1_ASAP7_75t_R   g109(.A(p18), .Y(new_n168_));
  AO21x1_ASAP7_75t_R  g110(.A1(p6), .A2(new_n166_), .B(new_n168_), .Y(new_n169_));
  INVx1_ASAP7_75t_R   g111(.A(p6), .Y(new_n170_));
  NOR2x1_ASAP7_75t_R  g112(.A(p21), .B(new_n170_), .Y(new_n171_));
  OAI21x1_ASAP7_75t_R g113(.A1(new_n167_), .A2(new_n171_), .B(new_n168_), .Y(new_n172_));
  OAI21x1_ASAP7_75t_R g114(.A1(new_n167_), .A2(new_n169_), .B(new_n172_), .Y(new_n173_));
  NOR2x1_ASAP7_75t_R  g115(.A(p1), .B(p0), .Y(new_n174_));
  NAND3x1_ASAP7_75t_R g116(.A(new_n174_), .B(p26), .C(new_n75_), .Y(new_n175_));
  AO21x1_ASAP7_75t_R  g117(.A1(p26), .A2(new_n174_), .B(new_n75_), .Y(new_n176_));
  NAND2x1_ASAP7_75t_R g118(.A(new_n175_), .B(new_n176_), .Y(new_n177_));
  XOR2x2_ASAP7_75t_R  g119(.A(new_n173_), .B(new_n177_), .Y(new_n178_));
  NAND3x1_ASAP7_75t_R g120(.A(new_n95_), .B(new_n178_), .C(new_n97_), .Y(new_n179_));
  OAI21x1_ASAP7_75t_R g121(.A1(new_n167_), .A2(new_n171_), .B(p18), .Y(new_n180_));
  NAND2x1_ASAP7_75t_R g122(.A(p21), .B(new_n170_), .Y(new_n181_));
  NAND2x1_ASAP7_75t_R g123(.A(p6), .B(new_n166_), .Y(new_n182_));
  NAND3x1_ASAP7_75t_R g124(.A(new_n181_), .B(new_n182_), .C(new_n168_), .Y(new_n183_));
  NAND2x1_ASAP7_75t_R g125(.A(new_n180_), .B(new_n183_), .Y(new_n184_));
  XOR2x2_ASAP7_75t_R  g126(.A(new_n184_), .B(new_n177_), .Y(new_n185_));
  NAND3x1_ASAP7_75t_R g127(.A(new_n185_), .B(new_n98_), .C(new_n97_), .Y(new_n186_));
  INVx1_ASAP7_75t_R   g128(.A(p27), .Y(new_n187_));
  NAND3x1_ASAP7_75t_R g129(.A(new_n179_), .B(new_n186_), .C(new_n187_), .Y(new_n188_));
  NAND2x1_ASAP7_75t_R g130(.A(new_n98_), .B(new_n185_), .Y(new_n189_));
  NAND2x1_ASAP7_75t_R g131(.A(new_n178_), .B(new_n95_), .Y(new_n190_));
  NAND2x1_ASAP7_75t_R g132(.A(p27), .B(new_n97_), .Y(new_n191_));
  AO21x1_ASAP7_75t_R  g133(.A1(new_n189_), .A2(new_n190_), .B(new_n191_), .Y(new_n192_));
  NOR3x1_ASAP7_75t_R  g134(.A(new_n121_), .B(p22), .C(new_n125_), .Y(new_n193_));
  INVx1_ASAP7_75t_R   g135(.A(p22), .Y(new_n194_));
  AOI21x1_ASAP7_75t_R g136(.A1(new_n128_), .A2(new_n129_), .B(new_n194_), .Y(new_n195_));
  NOR2x1_ASAP7_75t_R  g137(.A(p24), .B(new_n59_), .Y(new_n196_));
  INVx1_ASAP7_75t_R   g138(.A(p24), .Y(new_n197_));
  AOI21x1_ASAP7_75t_R g139(.A1(p23), .A2(new_n152_), .B(new_n197_), .Y(new_n198_));
  AOI21x1_ASAP7_75t_R g140(.A1(new_n152_), .A2(new_n196_), .B(new_n198_), .Y(new_n199_));
  OAI21x1_ASAP7_75t_R g141(.A1(new_n193_), .A2(new_n195_), .B(new_n199_), .Y(new_n200_));
  NAND3x1_ASAP7_75t_R g142(.A(new_n129_), .B(new_n128_), .C(new_n194_), .Y(new_n201_));
  OAI21x1_ASAP7_75t_R g143(.A1(new_n125_), .A2(new_n121_), .B(p22), .Y(new_n202_));
  AO21x1_ASAP7_75t_R  g144(.A1(new_n152_), .A2(new_n196_), .B(new_n198_), .Y(new_n203_));
  NAND3x1_ASAP7_75t_R g145(.A(new_n201_), .B(new_n202_), .C(new_n203_), .Y(new_n204_));
  XOR2x2_ASAP7_75t_R  g146(.A(p9), .B(p21), .Y(new_n205_));
  INVx1_ASAP7_75t_R   g147(.A(new_n205_), .Y(new_n206_));
  NAND3x1_ASAP7_75t_R g148(.A(new_n200_), .B(new_n204_), .C(new_n206_), .Y(new_n207_));
  OA21x2_ASAP7_75t_R  g149(.A1(p2), .A2(p32), .B(p11), .Y(new_n208_));
  XNOR2x2_ASAP7_75t_R g150(.A(p22), .B(p24), .Y(new_n209_));
  AO21x1_ASAP7_75t_R  g151(.A1(p23), .A2(new_n152_), .B(new_n209_), .Y(new_n210_));
  INVx1_ASAP7_75t_R   g152(.A(p32), .Y(new_n211_));
  AND3x1_ASAP7_75t_R  g153(.A(new_n68_), .B(new_n211_), .C(p23), .Y(new_n212_));
  NAND2x1_ASAP7_75t_R g154(.A(new_n212_), .B(new_n209_), .Y(new_n213_));
  NAND3x1_ASAP7_75t_R g155(.A(new_n210_), .B(new_n130_), .C(new_n213_), .Y(new_n214_));
  NOR2x1_ASAP7_75t_R  g156(.A(new_n212_), .B(new_n209_), .Y(new_n215_));
  AND3x1_ASAP7_75t_R  g157(.A(new_n209_), .B(p23), .C(new_n152_), .Y(new_n216_));
  NOR2x1_ASAP7_75t_R  g158(.A(new_n125_), .B(new_n121_), .Y(new_n217_));
  OAI21x1_ASAP7_75t_R g159(.A1(new_n215_), .A2(new_n216_), .B(new_n217_), .Y(new_n218_));
  NAND3x1_ASAP7_75t_R g160(.A(new_n214_), .B(new_n218_), .C(new_n205_), .Y(new_n219_));
  NAND3x1_ASAP7_75t_R g161(.A(new_n207_), .B(new_n208_), .C(new_n219_), .Y(new_n220_));
  NAND3x1_ASAP7_75t_R g162(.A(new_n214_), .B(new_n218_), .C(new_n206_), .Y(new_n221_));
  NAND3x1_ASAP7_75t_R g163(.A(new_n210_), .B(new_n217_), .C(new_n213_), .Y(new_n222_));
  OAI21x1_ASAP7_75t_R g164(.A1(new_n215_), .A2(new_n216_), .B(new_n130_), .Y(new_n223_));
  NAND3x1_ASAP7_75t_R g165(.A(new_n222_), .B(new_n223_), .C(new_n205_), .Y(new_n224_));
  NOR2x1_ASAP7_75t_R  g166(.A(p2), .B(new_n208_), .Y(new_n225_));
  NAND3x1_ASAP7_75t_R g167(.A(new_n221_), .B(new_n224_), .C(new_n225_), .Y(new_n226_));
  AND2x2_ASAP7_75t_R  g168(.A(p2), .B(p11), .Y(new_n227_));
  INVx1_ASAP7_75t_R   g169(.A(new_n227_), .Y(new_n228_));
  NAND3x1_ASAP7_75t_R g170(.A(new_n220_), .B(new_n226_), .C(new_n228_), .Y(new_n229_));
  AOI21x1_ASAP7_75t_R g171(.A1(new_n188_), .A2(new_n192_), .B(new_n229_), .Y(new_n230_));
  INVx1_ASAP7_75t_R   g172(.A(p26), .Y(new_n231_));
  AO21x1_ASAP7_75t_R  g173(.A1(new_n97_), .A2(new_n116_), .B(new_n231_), .Y(new_n232_));
  INVx1_ASAP7_75t_R   g174(.A(new_n232_), .Y(new_n233_));
  NAND2x1_ASAP7_75t_R g175(.A(new_n173_), .B(new_n82_), .Y(new_n234_));
  XOR2x2_ASAP7_75t_R  g176(.A(p6), .B(p21), .Y(new_n235_));
  AND2x2_ASAP7_75t_R  g177(.A(p18), .B(new_n235_), .Y(new_n236_));
  NOR2x1_ASAP7_75t_R  g178(.A(p18), .B(new_n235_), .Y(new_n237_));
  OAI21x1_ASAP7_75t_R g179(.A1(new_n236_), .A2(new_n237_), .B(new_n103_), .Y(new_n238_));
  XNOR2x2_ASAP7_75t_R g180(.A(p22), .B(p5), .Y(new_n239_));
  NAND3x1_ASAP7_75t_R g181(.A(new_n234_), .B(new_n238_), .C(new_n239_), .Y(new_n240_));
  NOR2x1_ASAP7_75t_R  g182(.A(new_n103_), .B(new_n184_), .Y(new_n241_));
  NOR2x1_ASAP7_75t_R  g183(.A(new_n173_), .B(new_n82_), .Y(new_n242_));
  INVx1_ASAP7_75t_R   g184(.A(new_n239_), .Y(new_n243_));
  OAI21x1_ASAP7_75t_R g185(.A1(new_n241_), .A2(new_n242_), .B(new_n243_), .Y(new_n244_));
  NAND2x1_ASAP7_75t_R g186(.A(p30), .B(new_n68_), .Y(new_n245_));
  XOR2x2_ASAP7_75t_R  g187(.A(new_n245_), .B(p13), .Y(new_n246_));
  XOR2x2_ASAP7_75t_R  g188(.A(new_n89_), .B(new_n246_), .Y(new_n247_));
  AOI21x1_ASAP7_75t_R g189(.A1(new_n240_), .A2(new_n244_), .B(new_n247_), .Y(new_n248_));
  NAND3x1_ASAP7_75t_R g190(.A(new_n234_), .B(new_n238_), .C(new_n243_), .Y(new_n249_));
  OAI21x1_ASAP7_75t_R g191(.A1(new_n241_), .A2(new_n242_), .B(new_n239_), .Y(new_n250_));
  XNOR2x2_ASAP7_75t_R g192(.A(new_n246_), .B(new_n89_), .Y(new_n251_));
  AOI21x1_ASAP7_75t_R g193(.A1(new_n249_), .A2(new_n250_), .B(new_n251_), .Y(new_n252_));
  OAI21x1_ASAP7_75t_R g194(.A1(new_n248_), .A2(new_n252_), .B(new_n97_), .Y(new_n253_));
  NAND2x1_ASAP7_75t_R g195(.A(new_n233_), .B(new_n253_), .Y(new_n254_));
  OA21x2_ASAP7_75t_R  g196(.A1(new_n231_), .A2(new_n116_), .B(new_n97_), .Y(new_n255_));
  OAI21x1_ASAP7_75t_R g197(.A1(new_n248_), .A2(new_n252_), .B(new_n255_), .Y(new_n256_));
  OA21x2_ASAP7_75t_R  g198(.A1(p2), .A2(p0), .B(p16), .Y(new_n257_));
  AND3x1_ASAP7_75t_R  g199(.A(new_n254_), .B(new_n256_), .C(new_n257_), .Y(new_n258_));
  NAND2x1_ASAP7_75t_R g200(.A(new_n230_), .B(new_n258_), .Y(new_n259_));
  OAI21x1_ASAP7_75t_R g201(.A1(new_n165_), .A2(new_n259_), .B(p14), .Y(new_n260_));
  OR3x1_ASAP7_75t_R   g202(.A(new_n259_), .B(new_n165_), .C(p14), .Y(new_n261_));
  AND2x2_ASAP7_75t_R  g203(.A(new_n260_), .B(new_n261_), .Y(o0));
  INVx1_ASAP7_75t_R   g204(.A(new_n257_), .Y(new_n263_));
  AOI21x1_ASAP7_75t_R g205(.A1(new_n256_), .A2(new_n254_), .B(new_n263_), .Y(new_n264_));
  OAI21x1_ASAP7_75t_R g206(.A1(new_n62_), .A2(new_n112_), .B(new_n230_), .Y(new_n265_));
  OR3x1_ASAP7_75t_R   g207(.A(p2), .B(p1), .C(p31), .Y(new_n266_));
  AO21x1_ASAP7_75t_R  g208(.A1(new_n266_), .A2(new_n115_), .B(new_n117_), .Y(new_n267_));
  AOI21x1_ASAP7_75t_R g209(.A1(new_n160_), .A2(new_n161_), .B(new_n267_), .Y(new_n268_));
  NAND3x1_ASAP7_75t_R g210(.A(new_n268_), .B(new_n151_), .C(new_n147_), .Y(new_n269_));
  NOR3x1_ASAP7_75t_R  g211(.A(new_n264_), .B(new_n265_), .C(new_n269_), .Y(new_n270_));
  XOR2x2_ASAP7_75t_R  g212(.A(new_n270_), .B(new_n75_), .Y(o1));
  XOR2x2_ASAP7_75t_R  g213(.A(new_n270_), .B(new_n80_), .Y(o2));
  OAI21x1_ASAP7_75t_R g214(.A1(new_n165_), .A2(new_n259_), .B(new_n197_), .Y(new_n273_));
  OR3x1_ASAP7_75t_R   g215(.A(new_n259_), .B(new_n165_), .C(new_n197_), .Y(new_n274_));
  NAND2x1_ASAP7_75t_R g216(.A(new_n273_), .B(new_n274_), .Y(o3));
  XOR2x2_ASAP7_75t_R  g217(.A(new_n270_), .B(new_n73_), .Y(o4));
  XOR2x2_ASAP7_75t_R  g218(.A(new_n270_), .B(new_n194_), .Y(o5));
  NAND2x1_ASAP7_75t_R g219(.A(new_n256_), .B(new_n254_), .Y(new_n278_));
  AOI21x1_ASAP7_75t_R g220(.A1(new_n257_), .A2(new_n278_), .B(new_n265_), .Y(new_n279_));
  NAND2x1_ASAP7_75t_R g221(.A(new_n164_), .B(new_n279_), .Y(new_n280_));
  XOR2x2_ASAP7_75t_R  g222(.A(new_n280_), .B(p9), .Y(o6));
  XOR2x2_ASAP7_75t_R  g223(.A(new_n280_), .B(p8), .Y(o7));
  XOR2x2_ASAP7_75t_R  g224(.A(new_n280_), .B(p15), .Y(o8));
  INVx1_ASAP7_75t_R   g225(.A(new_n230_), .Y(new_n284_));
  NAND2x1_ASAP7_75t_R g226(.A(new_n61_), .B(new_n112_), .Y(new_n285_));
  OR3x1_ASAP7_75t_R   g227(.A(new_n264_), .B(new_n284_), .C(new_n285_), .Y(new_n286_));
  NAND2x1_ASAP7_75t_R g228(.A(new_n151_), .B(new_n147_), .Y(new_n287_));
  AO21x1_ASAP7_75t_R  g229(.A1(new_n160_), .A2(new_n161_), .B(new_n287_), .Y(new_n288_));
  OR3x1_ASAP7_75t_R   g230(.A(new_n288_), .B(p18), .C(new_n267_), .Y(new_n289_));
  NOR2x1_ASAP7_75t_R  g231(.A(new_n269_), .B(new_n285_), .Y(new_n290_));
  NOR2x1_ASAP7_75t_R  g232(.A(new_n284_), .B(new_n264_), .Y(new_n291_));
  AO21x1_ASAP7_75t_R  g233(.A1(new_n290_), .A2(new_n291_), .B(new_n168_), .Y(new_n292_));
  OA21x2_ASAP7_75t_R  g234(.A1(new_n286_), .A2(new_n289_), .B(new_n292_), .Y(o9));
  INVx1_ASAP7_75t_R   g235(.A(new_n268_), .Y(new_n294_));
  OR3x1_ASAP7_75t_R   g236(.A(new_n287_), .B(new_n294_), .C(p6), .Y(new_n295_));
  AO21x1_ASAP7_75t_R  g237(.A1(new_n290_), .A2(new_n291_), .B(new_n170_), .Y(new_n296_));
  OA21x2_ASAP7_75t_R  g238(.A1(new_n286_), .A2(new_n295_), .B(new_n296_), .Y(o10));
  OR3x1_ASAP7_75t_R   g239(.A(new_n287_), .B(new_n294_), .C(p21), .Y(new_n298_));
  AO21x1_ASAP7_75t_R  g240(.A1(new_n290_), .A2(new_n291_), .B(new_n166_), .Y(new_n299_));
  OA21x2_ASAP7_75t_R  g241(.A1(new_n286_), .A2(new_n298_), .B(new_n299_), .Y(o11));
  OR3x1_ASAP7_75t_R   g242(.A(new_n288_), .B(p5), .C(new_n267_), .Y(new_n301_));
  OAI21x1_ASAP7_75t_R g243(.A1(new_n269_), .A2(new_n286_), .B(p5), .Y(new_n302_));
  OA21x2_ASAP7_75t_R  g244(.A1(new_n286_), .A2(new_n301_), .B(new_n302_), .Y(o12));
  INVx1_ASAP7_75t_R   g245(.A(new_n285_), .Y(new_n304_));
  AND3x1_ASAP7_75t_R  g246(.A(new_n291_), .B(new_n164_), .C(new_n304_), .Y(new_n305_));
  AO21x1_ASAP7_75t_R  g247(.A1(new_n257_), .A2(new_n278_), .B(new_n284_), .Y(new_n306_));
  INVx1_ASAP7_75t_R   g248(.A(p13), .Y(new_n307_));
  OR3x1_ASAP7_75t_R   g249(.A(new_n163_), .B(new_n148_), .C(new_n307_), .Y(new_n308_));
  OR3x1_ASAP7_75t_R   g250(.A(new_n306_), .B(new_n285_), .C(new_n308_), .Y(new_n309_));
  OAI21x1_ASAP7_75t_R g251(.A1(p13), .A2(new_n305_), .B(new_n309_), .Y(o13));
  OAI21x1_ASAP7_75t_R g252(.A1(new_n165_), .A2(new_n259_), .B(p17), .Y(new_n311_));
  OR3x1_ASAP7_75t_R   g253(.A(new_n259_), .B(new_n165_), .C(p17), .Y(new_n312_));
  AND2x2_ASAP7_75t_R  g254(.A(new_n311_), .B(new_n312_), .Y(o14));
  OAI21x1_ASAP7_75t_R g255(.A1(new_n165_), .A2(new_n259_), .B(p10), .Y(new_n314_));
  OR3x1_ASAP7_75t_R   g256(.A(new_n259_), .B(new_n165_), .C(p10), .Y(new_n315_));
  AND2x2_ASAP7_75t_R  g257(.A(new_n314_), .B(new_n315_), .Y(o15));
  INVx1_ASAP7_75t_R   g258(.A(p4), .Y(new_n317_));
  OA21x2_ASAP7_75t_R  g259(.A1(new_n117_), .A2(new_n113_), .B(new_n267_), .Y(new_n318_));
  AOI21x1_ASAP7_75t_R g260(.A1(new_n141_), .A2(new_n146_), .B(new_n318_), .Y(new_n319_));
  NAND3x1_ASAP7_75t_R g261(.A(new_n319_), .B(new_n162_), .C(new_n151_), .Y(new_n320_));
  OR3x1_ASAP7_75t_R   g262(.A(new_n264_), .B(new_n265_), .C(new_n320_), .Y(new_n321_));
  AND3x1_ASAP7_75t_R  g263(.A(new_n256_), .B(new_n263_), .C(new_n62_), .Y(new_n322_));
  AND3x1_ASAP7_75t_R  g264(.A(new_n322_), .B(new_n254_), .C(new_n112_), .Y(new_n323_));
  NAND2x1_ASAP7_75t_R g265(.A(new_n230_), .B(new_n323_), .Y(new_n324_));
  OA21x2_ASAP7_75t_R  g266(.A1(new_n288_), .A2(new_n324_), .B(new_n68_), .Y(new_n325_));
  OAI21x1_ASAP7_75t_R g267(.A1(new_n317_), .A2(new_n321_), .B(new_n325_), .Y(o16));
  NOR2x1_ASAP7_75t_R  g268(.A(new_n248_), .B(new_n252_), .Y(new_n327_));
  AND3x1_ASAP7_75t_R  g269(.A(new_n97_), .B(p26), .C(p0), .Y(new_n328_));
  NOR3x1_ASAP7_75t_R  g270(.A(new_n264_), .B(new_n265_), .C(new_n320_), .Y(new_n329_));
  NAND2x1_ASAP7_75t_R g271(.A(new_n328_), .B(new_n329_), .Y(new_n330_));
  NOR2x1_ASAP7_75t_R  g272(.A(new_n232_), .B(new_n253_), .Y(new_n331_));
  AO21x1_ASAP7_75t_R  g273(.A1(new_n331_), .A2(new_n329_), .B(new_n114_), .Y(new_n332_));
  AOI21x1_ASAP7_75t_R g274(.A1(new_n327_), .A2(new_n330_), .B(new_n332_), .Y(o17));
  NAND2x1_ASAP7_75t_R g275(.A(new_n108_), .B(new_n109_), .Y(new_n334_));
  INVx1_ASAP7_75t_R   g276(.A(new_n334_), .Y(new_n335_));
  OR3x1_ASAP7_75t_R   g277(.A(new_n321_), .B(p2), .C(new_n106_), .Y(new_n336_));
  AND3x1_ASAP7_75t_R  g278(.A(new_n334_), .B(new_n97_), .C(p29), .Y(new_n337_));
  AO21x1_ASAP7_75t_R  g279(.A1(new_n337_), .A2(new_n329_), .B(new_n114_), .Y(new_n338_));
  AOI21x1_ASAP7_75t_R g280(.A1(new_n335_), .A2(new_n336_), .B(new_n338_), .Y(o18));
  OAI21x1_ASAP7_75t_R g281(.A1(new_n137_), .A2(new_n144_), .B(new_n141_), .Y(new_n340_));
  AO21x1_ASAP7_75t_R  g282(.A1(p20), .A2(new_n329_), .B(new_n340_), .Y(new_n341_));
  AND2x2_ASAP7_75t_R  g283(.A(new_n115_), .B(new_n341_), .Y(o19));
  NAND2x1_ASAP7_75t_R g284(.A(p12), .B(new_n329_), .Y(new_n343_));
  AOI21x1_ASAP7_75t_R g285(.A1(new_n159_), .A2(new_n343_), .B(new_n114_), .Y(o20));
  NAND2x1_ASAP7_75t_R g286(.A(new_n224_), .B(new_n221_), .Y(new_n345_));
  AO21x1_ASAP7_75t_R  g287(.A1(new_n208_), .A2(new_n329_), .B(new_n345_), .Y(new_n346_));
  AND2x2_ASAP7_75t_R  g288(.A(new_n115_), .B(new_n346_), .Y(o21));
  AO21x1_ASAP7_75t_R  g289(.A1(p31), .A2(p30), .B(p1), .Y(new_n348_));
  INVx1_ASAP7_75t_R   g290(.A(new_n348_), .Y(new_n349_));
  NOR2x1_ASAP7_75t_R  g291(.A(p1), .B(p31), .Y(new_n350_));
  AOI21x1_ASAP7_75t_R g292(.A1(new_n249_), .A2(new_n250_), .B(new_n350_), .Y(new_n351_));
  OR3x1_ASAP7_75t_R   g293(.A(new_n264_), .B(new_n265_), .C(new_n269_), .Y(new_n352_));
  OR3x1_ASAP7_75t_R   g294(.A(new_n287_), .B(new_n294_), .C(new_n351_), .Y(new_n353_));
  NOR3x1_ASAP7_75t_R  g295(.A(new_n353_), .B(new_n265_), .C(new_n264_), .Y(new_n354_));
  AOI21x1_ASAP7_75t_R g296(.A1(new_n351_), .A2(new_n352_), .B(new_n354_), .Y(new_n355_));
  INVx1_ASAP7_75t_R   g297(.A(new_n351_), .Y(new_n356_));
  NOR2x1_ASAP7_75t_R  g298(.A(new_n351_), .B(new_n269_), .Y(new_n357_));
  AOI21x1_ASAP7_75t_R g299(.A1(new_n357_), .A2(new_n279_), .B(new_n348_), .Y(new_n358_));
  OAI21x1_ASAP7_75t_R g300(.A1(new_n270_), .A2(new_n356_), .B(new_n358_), .Y(new_n359_));
  OAI21x1_ASAP7_75t_R g301(.A1(new_n349_), .A2(new_n355_), .B(new_n359_), .Y(o22));
  NOR2x1_ASAP7_75t_R  g302(.A(new_n127_), .B(new_n124_), .Y(new_n361_));
  XOR2x2_ASAP7_75t_R  g303(.A(new_n98_), .B(new_n361_), .Y(new_n362_));
  NOR2x1_ASAP7_75t_R  g304(.A(p28), .B(p1), .Y(new_n363_));
  XOR2x2_ASAP7_75t_R  g305(.A(new_n362_), .B(new_n363_), .Y(new_n364_));
  OA21x2_ASAP7_75t_R  g306(.A1(p3), .A2(p1), .B(new_n364_), .Y(new_n365_));
  XOR2x2_ASAP7_75t_R  g307(.A(new_n280_), .B(new_n365_), .Y(o23));
  AO21x1_ASAP7_75t_R  g308(.A1(p27), .A2(new_n329_), .B(new_n114_), .Y(new_n367_));
  AOI21x1_ASAP7_75t_R g309(.A1(new_n189_), .A2(new_n190_), .B(new_n367_), .Y(o24));
endmodule


