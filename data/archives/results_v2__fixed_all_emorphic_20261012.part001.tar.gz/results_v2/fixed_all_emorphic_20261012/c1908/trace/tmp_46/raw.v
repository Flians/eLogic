// Benchmark "/tmp/" written by ABC on Mon Oct 12 15:05:30 2026

module \/tmp/  ( 
    p9, p28, p27, p20, p15, p22, p24, p11, p14, p29, p25, p5, p23, p16, p6,
    p0, p17, p31, p1, p19, p30, p8, p13, p7, p3, p2, p18, p26, p32, p10,
    p4, p21, p12,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24  );
  input  p9, p28, p27, p20, p15, p22, p24, p11, p14, p29, p25, p5, p23,
    p16, p6, p0, p17, p31, p1, p19, p30, p8, p13, p7, p3, p2, p18, p26,
    p32, p10, p4, p21, p12;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24;
  wire new_n59_, new_n60_, new_n61_, new_n62_, new_n63_, new_n64_, new_n65_,
    new_n66_, new_n67_, new_n68_, new_n69_, new_n70_, new_n71_, new_n72_,
    new_n73_, new_n74_, new_n75_, new_n76_, new_n77_, new_n78_, new_n79_,
    new_n80_, new_n81_, new_n82_, new_n83_, new_n84_, new_n85_, new_n86_,
    new_n87_, new_n88_, new_n89_, new_n90_, new_n91_, new_n92_, new_n93_,
    new_n94_, new_n95_, new_n96_, new_n97_, new_n98_, new_n99_, new_n100_,
    new_n101_, new_n102_, new_n103_, new_n104_, new_n105_, new_n106_,
    new_n107_, new_n108_, new_n109_, new_n110_, new_n111_, new_n112_,
    new_n113_, new_n114_, new_n115_, new_n116_, new_n117_, new_n118_,
    new_n119_, new_n120_, new_n121_, new_n122_, new_n123_, new_n124_,
    new_n125_, new_n126_, new_n127_, new_n128_, new_n129_, new_n130_,
    new_n131_, new_n132_, new_n133_, new_n134_, new_n135_, new_n136_,
    new_n137_, new_n138_, new_n139_, new_n140_, new_n141_, new_n142_,
    new_n143_, new_n144_, new_n145_, new_n146_, new_n147_, new_n148_,
    new_n149_, new_n150_, new_n151_, new_n152_, new_n153_, new_n154_,
    new_n155_, new_n156_, new_n157_, new_n158_, new_n159_, new_n160_,
    new_n161_, new_n162_, new_n163_, new_n164_, new_n165_, new_n166_,
    new_n167_, new_n168_, new_n169_, new_n170_, new_n171_, new_n172_,
    new_n173_, new_n174_, new_n175_, new_n176_, new_n177_, new_n178_,
    new_n179_, new_n180_, new_n181_, new_n182_, new_n183_, new_n184_,
    new_n185_, new_n186_, new_n187_, new_n188_, new_n189_, new_n190_,
    new_n191_, new_n192_, new_n193_, new_n194_, new_n195_, new_n196_,
    new_n197_, new_n198_, new_n199_, new_n200_, new_n201_, new_n202_,
    new_n203_, new_n204_, new_n205_, new_n206_, new_n207_, new_n208_,
    new_n209_, new_n210_, new_n211_, new_n212_, new_n213_, new_n214_,
    new_n215_, new_n216_, new_n217_, new_n218_, new_n219_, new_n220_,
    new_n221_, new_n222_, new_n223_, new_n224_, new_n225_, new_n226_,
    new_n227_, new_n228_, new_n229_, new_n230_, new_n231_, new_n232_,
    new_n233_, new_n234_, new_n235_, new_n236_, new_n237_, new_n238_,
    new_n239_, new_n240_, new_n241_, new_n242_, new_n243_, new_n244_,
    new_n245_, new_n246_, new_n247_, new_n248_, new_n249_, new_n250_,
    new_n251_, new_n252_, new_n253_, new_n254_, new_n255_, new_n256_,
    new_n258_, new_n259_, new_n260_, new_n261_, new_n262_, new_n263_,
    new_n264_, new_n265_, new_n266_, new_n267_, new_n268_, new_n269_,
    new_n270_, new_n271_, new_n272_, new_n275_, new_n279_, new_n280_,
    new_n281_, new_n285_, new_n286_, new_n287_, new_n288_, new_n289_,
    new_n290_, new_n291_, new_n292_, new_n293_, new_n294_, new_n295_,
    new_n297_, new_n298_, new_n300_, new_n301_, new_n303_, new_n304_,
    new_n305_, new_n307_, new_n308_, new_n309_, new_n310_, new_n311_,
    new_n313_, new_n314_, new_n316_, new_n317_, new_n319_, new_n320_,
    new_n321_, new_n322_, new_n323_, new_n324_, new_n325_, new_n326_,
    new_n328_, new_n329_, new_n330_, new_n331_, new_n332_, new_n333_,
    new_n335_, new_n336_, new_n337_, new_n338_, new_n339_, new_n341_,
    new_n343_, new_n345_, new_n346_, new_n348_, new_n349_, new_n350_,
    new_n351_, new_n352_, new_n353_, new_n354_, new_n355_, new_n356_,
    new_n357_, new_n358_, new_n360_, new_n361_, new_n362_, new_n363_,
    new_n364_, new_n366_;
  NOR2x1_ASAP7_75t_R  g000(.A(p20), .B(p2), .Y(new_n59_));
  NOR2x1_ASAP7_75t_R  g001(.A(p14), .B(p13), .Y(new_n60_));
  AND2x2_ASAP7_75t_R  g002(.A(p14), .B(p13), .Y(new_n61_));
  INVx1_ASAP7_75t_R   g003(.A(p15), .Y(new_n62_));
  OAI21x1_ASAP7_75t_R g004(.A1(new_n60_), .A2(new_n61_), .B(new_n62_), .Y(new_n63_));
  OAI21x1_ASAP7_75t_R g005(.A1(p14), .A2(p13), .B(p15), .Y(new_n64_));
  AO21x1_ASAP7_75t_R  g006(.A1(p14), .A2(p13), .B(new_n64_), .Y(new_n65_));
  NAND2x1_ASAP7_75t_R g007(.A(new_n63_), .B(new_n65_), .Y(new_n66_));
  XOR2x2_ASAP7_75t_R  g008(.A(p17), .B(p8), .Y(new_n67_));
  XNOR2x2_ASAP7_75t_R g009(.A(p5), .B(new_n67_), .Y(new_n68_));
  NAND2x1_ASAP7_75t_R g010(.A(new_n66_), .B(new_n68_), .Y(new_n69_));
  NOR2x1_ASAP7_75t_R  g011(.A(new_n64_), .B(new_n61_), .Y(new_n70_));
  NAND2x1_ASAP7_75t_R g012(.A(p14), .B(p13), .Y(new_n71_));
  OR3x1_ASAP7_75t_R   g013(.A(p15), .B(p14), .C(p13), .Y(new_n72_));
  OAI21x1_ASAP7_75t_R g014(.A1(p15), .A2(new_n71_), .B(new_n72_), .Y(new_n73_));
  NOR2x1_ASAP7_75t_R  g015(.A(new_n70_), .B(new_n73_), .Y(new_n74_));
  XOR2x2_ASAP7_75t_R  g016(.A(new_n67_), .B(p5), .Y(new_n75_));
  NAND2x1_ASAP7_75t_R g017(.A(new_n74_), .B(new_n75_), .Y(new_n76_));
  XOR2x2_ASAP7_75t_R  g018(.A(p19), .B(p18), .Y(new_n77_));
  NOR2x1_ASAP7_75t_R  g019(.A(p0), .B(p1), .Y(new_n78_));
  NAND2x1_ASAP7_75t_R g020(.A(p16), .B(new_n78_), .Y(new_n79_));
  XOR2x2_ASAP7_75t_R  g021(.A(new_n77_), .B(new_n79_), .Y(new_n80_));
  NAND3x1_ASAP7_75t_R g022(.A(new_n69_), .B(new_n76_), .C(new_n80_), .Y(new_n81_));
  AO21x1_ASAP7_75t_R  g023(.A1(new_n76_), .A2(new_n69_), .B(new_n80_), .Y(new_n82_));
  NAND2x1_ASAP7_75t_R g024(.A(new_n81_), .B(new_n82_), .Y(new_n83_));
  OR3x1_ASAP7_75t_R   g025(.A(p1), .B(p3), .C(p2), .Y(new_n84_));
  NOR2x1_ASAP7_75t_R  g026(.A(p1), .B(p4), .Y(new_n85_));
  INVx1_ASAP7_75t_R   g027(.A(new_n85_), .Y(new_n86_));
  INVx1_ASAP7_75t_R   g028(.A(p0), .Y(new_n87_));
  NOR2x1_ASAP7_75t_R  g029(.A(p32), .B(new_n87_), .Y(new_n88_));
  AO21x1_ASAP7_75t_R  g030(.A1(new_n84_), .A2(new_n86_), .B(new_n88_), .Y(new_n89_));
  AO21x1_ASAP7_75t_R  g031(.A1(new_n59_), .A2(new_n83_), .B(new_n89_), .Y(new_n90_));
  NOR2x1_ASAP7_75t_R  g032(.A(p9), .B(p8), .Y(new_n91_));
  AND2x2_ASAP7_75t_R  g033(.A(p9), .B(p8), .Y(new_n92_));
  NOR2x1_ASAP7_75t_R  g034(.A(new_n91_), .B(new_n92_), .Y(new_n93_));
  NOR2x1_ASAP7_75t_R  g035(.A(p1), .B(p32), .Y(new_n94_));
  NAND2x1_ASAP7_75t_R g036(.A(p11), .B(new_n94_), .Y(new_n95_));
  XOR2x2_ASAP7_75t_R  g037(.A(new_n93_), .B(new_n95_), .Y(new_n96_));
  XOR2x2_ASAP7_75t_R  g038(.A(p5), .B(p6), .Y(new_n97_));
  XOR2x2_ASAP7_75t_R  g039(.A(p7), .B(p10), .Y(new_n98_));
  XOR2x2_ASAP7_75t_R  g040(.A(new_n97_), .B(new_n98_), .Y(new_n99_));
  XOR2x2_ASAP7_75t_R  g041(.A(new_n96_), .B(new_n99_), .Y(new_n100_));
  OAI21x1_ASAP7_75t_R g042(.A1(p2), .A2(new_n100_), .B(p12), .Y(new_n101_));
  OR3x1_ASAP7_75t_R   g043(.A(new_n100_), .B(p2), .C(p12), .Y(new_n102_));
  NAND2x1_ASAP7_75t_R g044(.A(new_n101_), .B(new_n102_), .Y(new_n103_));
  INVx1_ASAP7_75t_R   g045(.A(p2), .Y(new_n104_));
  INVx1_ASAP7_75t_R   g046(.A(p20), .Y(new_n105_));
  AOI21x1_ASAP7_75t_R g047(.A1(new_n104_), .A2(new_n83_), .B(new_n105_), .Y(new_n106_));
  NOR3x1_ASAP7_75t_R  g048(.A(new_n90_), .B(new_n103_), .C(new_n106_), .Y(new_n107_));
  INVx1_ASAP7_75t_R   g049(.A(p7), .Y(new_n108_));
  NOR2x1_ASAP7_75t_R  g050(.A(p19), .B(new_n108_), .Y(new_n109_));
  INVx1_ASAP7_75t_R   g051(.A(p19), .Y(new_n110_));
  NOR2x1_ASAP7_75t_R  g052(.A(p7), .B(new_n110_), .Y(new_n111_));
  OAI21x1_ASAP7_75t_R g053(.A1(new_n109_), .A2(new_n111_), .B(p25), .Y(new_n112_));
  NAND2x1_ASAP7_75t_R g054(.A(p7), .B(new_n110_), .Y(new_n113_));
  NAND2x1_ASAP7_75t_R g055(.A(p19), .B(new_n108_), .Y(new_n114_));
  INVx1_ASAP7_75t_R   g056(.A(p25), .Y(new_n115_));
  NAND3x1_ASAP7_75t_R g057(.A(new_n113_), .B(new_n114_), .C(new_n115_), .Y(new_n116_));
  NAND2x1_ASAP7_75t_R g058(.A(new_n112_), .B(new_n116_), .Y(new_n117_));
  XOR2x2_ASAP7_75t_R  g059(.A(p22), .B(p14), .Y(new_n118_));
  INVx1_ASAP7_75t_R   g060(.A(p1), .Y(new_n119_));
  NAND2x1_ASAP7_75t_R g061(.A(p28), .B(new_n119_), .Y(new_n120_));
  XOR2x2_ASAP7_75t_R  g062(.A(new_n118_), .B(new_n120_), .Y(new_n121_));
  NAND2x1_ASAP7_75t_R g063(.A(new_n117_), .B(new_n121_), .Y(new_n122_));
  AO21x1_ASAP7_75t_R  g064(.A1(p19), .A2(new_n108_), .B(new_n115_), .Y(new_n123_));
  OAI21x1_ASAP7_75t_R g065(.A1(new_n109_), .A2(new_n111_), .B(new_n115_), .Y(new_n124_));
  OAI21x1_ASAP7_75t_R g066(.A1(new_n109_), .A2(new_n123_), .B(new_n124_), .Y(new_n125_));
  INVx1_ASAP7_75t_R   g067(.A(p28), .Y(new_n126_));
  NOR2x1_ASAP7_75t_R  g068(.A(p1), .B(new_n126_), .Y(new_n127_));
  XOR2x2_ASAP7_75t_R  g069(.A(new_n118_), .B(new_n127_), .Y(new_n128_));
  NAND2x1_ASAP7_75t_R g070(.A(new_n125_), .B(new_n128_), .Y(new_n129_));
  NAND2x1_ASAP7_75t_R g071(.A(new_n122_), .B(new_n129_), .Y(new_n130_));
  OAI21x1_ASAP7_75t_R g072(.A1(new_n91_), .A2(new_n92_), .B(p15), .Y(new_n131_));
  OR3x1_ASAP7_75t_R   g073(.A(new_n92_), .B(p15), .C(new_n91_), .Y(new_n132_));
  NAND2x1_ASAP7_75t_R g074(.A(new_n131_), .B(new_n132_), .Y(new_n133_));
  NOR2x1_ASAP7_75t_R  g075(.A(p24), .B(p17), .Y(new_n134_));
  AND2x2_ASAP7_75t_R  g076(.A(p24), .B(p17), .Y(new_n135_));
  OAI21x1_ASAP7_75t_R g077(.A1(new_n134_), .A2(new_n135_), .B(p10), .Y(new_n136_));
  OR3x1_ASAP7_75t_R   g078(.A(new_n135_), .B(p10), .C(new_n134_), .Y(new_n137_));
  NAND2x1_ASAP7_75t_R g079(.A(new_n136_), .B(new_n137_), .Y(new_n138_));
  XOR2x2_ASAP7_75t_R  g080(.A(new_n133_), .B(new_n138_), .Y(new_n139_));
  OR3x1_ASAP7_75t_R   g081(.A(new_n130_), .B(p2), .C(new_n139_), .Y(new_n140_));
  OAI21x1_ASAP7_75t_R g082(.A1(new_n91_), .A2(new_n92_), .B(new_n62_), .Y(new_n141_));
  OR3x1_ASAP7_75t_R   g083(.A(new_n92_), .B(new_n62_), .C(new_n91_), .Y(new_n142_));
  NAND2x1_ASAP7_75t_R g084(.A(new_n141_), .B(new_n142_), .Y(new_n143_));
  XOR2x2_ASAP7_75t_R  g085(.A(new_n143_), .B(new_n138_), .Y(new_n144_));
  AOI21x1_ASAP7_75t_R g086(.A1(new_n122_), .A2(new_n129_), .B(new_n144_), .Y(new_n145_));
  INVx1_ASAP7_75t_R   g087(.A(p29), .Y(new_n146_));
  AOI21x1_ASAP7_75t_R g088(.A1(new_n104_), .A2(new_n145_), .B(new_n146_), .Y(new_n147_));
  NAND3x1_ASAP7_75t_R g089(.A(new_n144_), .B(new_n122_), .C(new_n129_), .Y(new_n148_));
  NAND2x1_ASAP7_75t_R g090(.A(new_n139_), .B(new_n130_), .Y(new_n149_));
  NAND2x1_ASAP7_75t_R g091(.A(new_n146_), .B(new_n104_), .Y(new_n150_));
  AOI21x1_ASAP7_75t_R g092(.A1(new_n148_), .A2(new_n149_), .B(new_n150_), .Y(new_n151_));
  AOI21x1_ASAP7_75t_R g093(.A1(new_n140_), .A2(new_n147_), .B(new_n151_), .Y(new_n152_));
  INVx1_ASAP7_75t_R   g094(.A(p23), .Y(new_n153_));
  NOR2x1_ASAP7_75t_R  g095(.A(p2), .B(p32), .Y(new_n154_));
  OR3x1_ASAP7_75t_R   g096(.A(new_n152_), .B(new_n153_), .C(new_n154_), .Y(new_n155_));
  NAND2x1_ASAP7_75t_R g097(.A(new_n107_), .B(new_n155_), .Y(new_n156_));
  INVx1_ASAP7_75t_R   g098(.A(p26), .Y(new_n157_));
  NOR2x1_ASAP7_75t_R  g099(.A(p0), .B(p2), .Y(new_n158_));
  NOR2x1_ASAP7_75t_R  g100(.A(new_n157_), .B(new_n158_), .Y(new_n159_));
  INVx1_ASAP7_75t_R   g101(.A(p21), .Y(new_n160_));
  NOR2x1_ASAP7_75t_R  g102(.A(p18), .B(new_n160_), .Y(new_n161_));
  INVx1_ASAP7_75t_R   g103(.A(p18), .Y(new_n162_));
  NOR2x1_ASAP7_75t_R  g104(.A(p21), .B(new_n162_), .Y(new_n163_));
  OAI21x1_ASAP7_75t_R g105(.A1(new_n161_), .A2(new_n163_), .B(p6), .Y(new_n164_));
  NAND2x1_ASAP7_75t_R g106(.A(p21), .B(new_n162_), .Y(new_n165_));
  NAND2x1_ASAP7_75t_R g107(.A(p18), .B(new_n160_), .Y(new_n166_));
  INVx1_ASAP7_75t_R   g108(.A(p6), .Y(new_n167_));
  NAND3x1_ASAP7_75t_R g109(.A(new_n165_), .B(new_n166_), .C(new_n167_), .Y(new_n168_));
  NAND2x1_ASAP7_75t_R g110(.A(new_n164_), .B(new_n168_), .Y(new_n169_));
  NAND2x1_ASAP7_75t_R g111(.A(new_n125_), .B(new_n169_), .Y(new_n170_));
  XOR2x2_ASAP7_75t_R  g112(.A(p19), .B(p7), .Y(new_n171_));
  AND2x2_ASAP7_75t_R  g113(.A(p25), .B(new_n171_), .Y(new_n172_));
  NOR2x1_ASAP7_75t_R  g114(.A(p25), .B(new_n171_), .Y(new_n173_));
  NOR2x1_ASAP7_75t_R  g115(.A(p6), .B(new_n160_), .Y(new_n174_));
  AO21x1_ASAP7_75t_R  g116(.A1(p6), .A2(new_n160_), .B(new_n162_), .Y(new_n175_));
  NOR2x1_ASAP7_75t_R  g117(.A(p21), .B(new_n167_), .Y(new_n176_));
  OAI21x1_ASAP7_75t_R g118(.A1(new_n174_), .A2(new_n176_), .B(new_n162_), .Y(new_n177_));
  OAI21x1_ASAP7_75t_R g119(.A1(new_n174_), .A2(new_n175_), .B(new_n177_), .Y(new_n178_));
  OAI21x1_ASAP7_75t_R g120(.A1(new_n172_), .A2(new_n173_), .B(new_n178_), .Y(new_n179_));
  XNOR2x2_ASAP7_75t_R g121(.A(p22), .B(p5), .Y(new_n180_));
  NAND3x1_ASAP7_75t_R g122(.A(new_n170_), .B(new_n179_), .C(new_n180_), .Y(new_n181_));
  NOR2x1_ASAP7_75t_R  g123(.A(new_n178_), .B(new_n117_), .Y(new_n182_));
  NOR2x1_ASAP7_75t_R  g124(.A(new_n125_), .B(new_n169_), .Y(new_n183_));
  INVx1_ASAP7_75t_R   g125(.A(new_n180_), .Y(new_n184_));
  OAI21x1_ASAP7_75t_R g126(.A1(new_n182_), .A2(new_n183_), .B(new_n184_), .Y(new_n185_));
  NAND2x1_ASAP7_75t_R g127(.A(p30), .B(new_n119_), .Y(new_n186_));
  XOR2x2_ASAP7_75t_R  g128(.A(new_n186_), .B(p13), .Y(new_n187_));
  XOR2x2_ASAP7_75t_R  g129(.A(new_n143_), .B(new_n187_), .Y(new_n188_));
  AOI21x1_ASAP7_75t_R g130(.A1(new_n181_), .A2(new_n185_), .B(new_n188_), .Y(new_n189_));
  NAND3x1_ASAP7_75t_R g131(.A(new_n170_), .B(new_n179_), .C(new_n184_), .Y(new_n190_));
  OAI21x1_ASAP7_75t_R g132(.A1(new_n182_), .A2(new_n183_), .B(new_n180_), .Y(new_n191_));
  XOR2x2_ASAP7_75t_R  g133(.A(new_n133_), .B(new_n187_), .Y(new_n192_));
  AOI21x1_ASAP7_75t_R g134(.A1(new_n190_), .A2(new_n191_), .B(new_n192_), .Y(new_n193_));
  OAI21x1_ASAP7_75t_R g135(.A1(new_n189_), .A2(new_n193_), .B(new_n104_), .Y(new_n194_));
  NAND2x1_ASAP7_75t_R g136(.A(new_n159_), .B(new_n194_), .Y(new_n195_));
  INVx1_ASAP7_75t_R   g137(.A(p16), .Y(new_n196_));
  NOR2x1_ASAP7_75t_R  g138(.A(new_n196_), .B(new_n158_), .Y(new_n197_));
  OA21x2_ASAP7_75t_R  g139(.A1(new_n87_), .A2(new_n157_), .B(new_n104_), .Y(new_n198_));
  OAI21x1_ASAP7_75t_R g140(.A1(new_n189_), .A2(new_n193_), .B(new_n198_), .Y(new_n199_));
  AND3x1_ASAP7_75t_R  g141(.A(new_n195_), .B(new_n197_), .C(new_n199_), .Y(new_n200_));
  INVx1_ASAP7_75t_R   g142(.A(new_n200_), .Y(new_n201_));
  NAND3x1_ASAP7_75t_R g143(.A(new_n78_), .B(new_n115_), .C(p26), .Y(new_n202_));
  AO21x1_ASAP7_75t_R  g144(.A1(p26), .A2(new_n78_), .B(new_n115_), .Y(new_n203_));
  AND2x2_ASAP7_75t_R  g145(.A(new_n202_), .B(new_n203_), .Y(new_n204_));
  XOR2x2_ASAP7_75t_R  g146(.A(new_n169_), .B(new_n204_), .Y(new_n205_));
  NAND2x1_ASAP7_75t_R g147(.A(new_n144_), .B(new_n205_), .Y(new_n206_));
  XOR2x2_ASAP7_75t_R  g148(.A(new_n178_), .B(new_n204_), .Y(new_n207_));
  NAND2x1_ASAP7_75t_R g149(.A(new_n139_), .B(new_n207_), .Y(new_n208_));
  INVx1_ASAP7_75t_R   g150(.A(p27), .Y(new_n209_));
  NOR2x1_ASAP7_75t_R  g151(.A(p2), .B(new_n209_), .Y(new_n210_));
  NAND3x1_ASAP7_75t_R g152(.A(new_n206_), .B(new_n208_), .C(new_n210_), .Y(new_n211_));
  NAND3x1_ASAP7_75t_R g153(.A(new_n205_), .B(new_n139_), .C(new_n104_), .Y(new_n212_));
  NAND3x1_ASAP7_75t_R g154(.A(new_n207_), .B(new_n144_), .C(new_n104_), .Y(new_n213_));
  NAND3x1_ASAP7_75t_R g155(.A(new_n212_), .B(new_n213_), .C(new_n209_), .Y(new_n214_));
  NOR3x1_ASAP7_75t_R  g156(.A(new_n73_), .B(p22), .C(new_n70_), .Y(new_n215_));
  INVx1_ASAP7_75t_R   g157(.A(p22), .Y(new_n216_));
  AOI21x1_ASAP7_75t_R g158(.A1(new_n63_), .A2(new_n65_), .B(new_n216_), .Y(new_n217_));
  NOR2x1_ASAP7_75t_R  g159(.A(p24), .B(new_n153_), .Y(new_n218_));
  INVx1_ASAP7_75t_R   g160(.A(p24), .Y(new_n219_));
  AOI21x1_ASAP7_75t_R g161(.A1(p23), .A2(new_n94_), .B(new_n219_), .Y(new_n220_));
  AOI21x1_ASAP7_75t_R g162(.A1(new_n94_), .A2(new_n218_), .B(new_n220_), .Y(new_n221_));
  OAI21x1_ASAP7_75t_R g163(.A1(new_n215_), .A2(new_n217_), .B(new_n221_), .Y(new_n222_));
  NAND3x1_ASAP7_75t_R g164(.A(new_n65_), .B(new_n63_), .C(new_n216_), .Y(new_n223_));
  OAI21x1_ASAP7_75t_R g165(.A1(new_n70_), .A2(new_n73_), .B(p22), .Y(new_n224_));
  AO21x1_ASAP7_75t_R  g166(.A1(new_n94_), .A2(new_n218_), .B(new_n220_), .Y(new_n225_));
  NAND3x1_ASAP7_75t_R g167(.A(new_n223_), .B(new_n224_), .C(new_n225_), .Y(new_n226_));
  XNOR2x2_ASAP7_75t_R g168(.A(p9), .B(p21), .Y(new_n227_));
  NAND3x1_ASAP7_75t_R g169(.A(new_n222_), .B(new_n226_), .C(new_n227_), .Y(new_n228_));
  OA21x2_ASAP7_75t_R  g170(.A1(p2), .A2(p32), .B(p11), .Y(new_n229_));
  NAND2x1_ASAP7_75t_R g171(.A(p23), .B(new_n94_), .Y(new_n230_));
  XOR2x2_ASAP7_75t_R  g172(.A(p22), .B(p24), .Y(new_n231_));
  NAND2x1_ASAP7_75t_R g173(.A(new_n230_), .B(new_n231_), .Y(new_n232_));
  INVx1_ASAP7_75t_R   g174(.A(new_n94_), .Y(new_n233_));
  OR3x1_ASAP7_75t_R   g175(.A(new_n231_), .B(new_n153_), .C(new_n233_), .Y(new_n234_));
  AOI21x1_ASAP7_75t_R g176(.A1(new_n232_), .A2(new_n234_), .B(new_n74_), .Y(new_n235_));
  NOR2x1_ASAP7_75t_R  g177(.A(new_n230_), .B(new_n231_), .Y(new_n236_));
  AND2x2_ASAP7_75t_R  g178(.A(new_n230_), .B(new_n231_), .Y(new_n237_));
  NOR3x1_ASAP7_75t_R  g179(.A(new_n66_), .B(new_n236_), .C(new_n237_), .Y(new_n238_));
  INVx1_ASAP7_75t_R   g180(.A(new_n227_), .Y(new_n239_));
  OAI21x1_ASAP7_75t_R g181(.A1(new_n235_), .A2(new_n238_), .B(new_n239_), .Y(new_n240_));
  NAND3x1_ASAP7_75t_R g182(.A(new_n228_), .B(new_n229_), .C(new_n240_), .Y(new_n241_));
  OAI21x1_ASAP7_75t_R g183(.A1(new_n236_), .A2(new_n237_), .B(new_n66_), .Y(new_n242_));
  NAND3x1_ASAP7_75t_R g184(.A(new_n74_), .B(new_n234_), .C(new_n232_), .Y(new_n243_));
  AO21x1_ASAP7_75t_R  g185(.A1(new_n242_), .A2(new_n243_), .B(new_n239_), .Y(new_n244_));
  NAND3x1_ASAP7_75t_R g186(.A(new_n243_), .B(new_n242_), .C(new_n239_), .Y(new_n245_));
  NOR2x1_ASAP7_75t_R  g187(.A(p2), .B(new_n229_), .Y(new_n246_));
  NAND3x1_ASAP7_75t_R g188(.A(new_n244_), .B(new_n245_), .C(new_n246_), .Y(new_n247_));
  AND2x2_ASAP7_75t_R  g189(.A(p11), .B(p2), .Y(new_n248_));
  INVx1_ASAP7_75t_R   g190(.A(new_n248_), .Y(new_n249_));
  NAND3x1_ASAP7_75t_R g191(.A(new_n241_), .B(new_n247_), .C(new_n249_), .Y(new_n250_));
  AOI21x1_ASAP7_75t_R g192(.A1(new_n211_), .A2(new_n214_), .B(new_n250_), .Y(new_n251_));
  INVx1_ASAP7_75t_R   g193(.A(new_n251_), .Y(new_n252_));
  OR3x1_ASAP7_75t_R   g194(.A(new_n156_), .B(new_n201_), .C(new_n252_), .Y(new_n253_));
  AND3x1_ASAP7_75t_R  g195(.A(new_n200_), .B(new_n251_), .C(new_n155_), .Y(new_n254_));
  INVx1_ASAP7_75t_R   g196(.A(p14), .Y(new_n255_));
  AND3x1_ASAP7_75t_R  g197(.A(new_n254_), .B(new_n255_), .C(new_n107_), .Y(new_n256_));
  AOI21x1_ASAP7_75t_R g198(.A1(p14), .A2(new_n253_), .B(new_n256_), .Y(o0));
  OR3x1_ASAP7_75t_R   g199(.A(new_n88_), .B(p1), .C(p4), .Y(new_n258_));
  NOR2x1_ASAP7_75t_R  g200(.A(p31), .B(p1), .Y(new_n259_));
  INVx1_ASAP7_75t_R   g201(.A(new_n259_), .Y(new_n260_));
  OR3x1_ASAP7_75t_R   g202(.A(new_n260_), .B(new_n88_), .C(p2), .Y(new_n261_));
  AND2x2_ASAP7_75t_R  g203(.A(new_n258_), .B(new_n261_), .Y(new_n262_));
  INVx1_ASAP7_75t_R   g204(.A(new_n262_), .Y(new_n263_));
  AND3x1_ASAP7_75t_R  g205(.A(new_n102_), .B(new_n101_), .C(new_n263_), .Y(new_n264_));
  AOI21x1_ASAP7_75t_R g206(.A1(new_n83_), .A2(new_n59_), .B(new_n106_), .Y(new_n265_));
  NAND2x1_ASAP7_75t_R g207(.A(new_n264_), .B(new_n265_), .Y(new_n266_));
  INVx1_ASAP7_75t_R   g208(.A(new_n197_), .Y(new_n267_));
  AOI21x1_ASAP7_75t_R g209(.A1(new_n199_), .A2(new_n195_), .B(new_n267_), .Y(new_n268_));
  NOR2x1_ASAP7_75t_R  g210(.A(new_n153_), .B(new_n154_), .Y(new_n269_));
  INVx1_ASAP7_75t_R   g211(.A(new_n269_), .Y(new_n270_));
  OAI21x1_ASAP7_75t_R g212(.A1(new_n270_), .A2(new_n152_), .B(new_n251_), .Y(new_n271_));
  NOR3x1_ASAP7_75t_R  g213(.A(new_n266_), .B(new_n268_), .C(new_n271_), .Y(new_n272_));
  XOR2x2_ASAP7_75t_R  g214(.A(new_n272_), .B(new_n115_), .Y(o1));
  XOR2x2_ASAP7_75t_R  g215(.A(new_n272_), .B(new_n110_), .Y(o2));
  AND3x1_ASAP7_75t_R  g216(.A(new_n254_), .B(new_n219_), .C(new_n107_), .Y(new_n275_));
  AOI21x1_ASAP7_75t_R g217(.A1(p24), .A2(new_n253_), .B(new_n275_), .Y(o3));
  XOR2x2_ASAP7_75t_R  g218(.A(new_n272_), .B(new_n108_), .Y(o4));
  XOR2x2_ASAP7_75t_R  g219(.A(new_n272_), .B(new_n216_), .Y(o5));
  NAND2x1_ASAP7_75t_R g220(.A(new_n199_), .B(new_n195_), .Y(new_n279_));
  AOI21x1_ASAP7_75t_R g221(.A1(new_n197_), .A2(new_n279_), .B(new_n271_), .Y(new_n280_));
  NAND2x1_ASAP7_75t_R g222(.A(new_n107_), .B(new_n280_), .Y(new_n281_));
  XOR2x2_ASAP7_75t_R  g223(.A(new_n281_), .B(p9), .Y(o6));
  XOR2x2_ASAP7_75t_R  g224(.A(new_n281_), .B(p8), .Y(o7));
  XOR2x2_ASAP7_75t_R  g225(.A(new_n281_), .B(p15), .Y(o8));
  AND2x2_ASAP7_75t_R  g226(.A(new_n269_), .B(new_n152_), .Y(new_n285_));
  NOR2x1_ASAP7_75t_R  g227(.A(new_n252_), .B(new_n268_), .Y(new_n286_));
  NAND2x1_ASAP7_75t_R g228(.A(new_n285_), .B(new_n286_), .Y(new_n287_));
  NAND2x1_ASAP7_75t_R g229(.A(new_n59_), .B(new_n83_), .Y(new_n288_));
  NOR2x1_ASAP7_75t_R  g230(.A(new_n106_), .B(new_n103_), .Y(new_n289_));
  NAND2x1_ASAP7_75t_R g231(.A(new_n288_), .B(new_n289_), .Y(new_n290_));
  OR3x1_ASAP7_75t_R   g232(.A(new_n290_), .B(p18), .C(new_n262_), .Y(new_n291_));
  AO21x1_ASAP7_75t_R  g233(.A1(new_n104_), .A2(new_n83_), .B(new_n105_), .Y(new_n292_));
  AND3x1_ASAP7_75t_R  g234(.A(new_n264_), .B(new_n292_), .C(new_n288_), .Y(new_n293_));
  AND3x1_ASAP7_75t_R  g235(.A(new_n293_), .B(new_n269_), .C(new_n152_), .Y(new_n294_));
  AO21x1_ASAP7_75t_R  g236(.A1(new_n286_), .A2(new_n294_), .B(new_n162_), .Y(new_n295_));
  OA21x2_ASAP7_75t_R  g237(.A1(new_n287_), .A2(new_n291_), .B(new_n295_), .Y(o9));
  NAND2x1_ASAP7_75t_R g238(.A(new_n167_), .B(new_n293_), .Y(new_n297_));
  AO21x1_ASAP7_75t_R  g239(.A1(new_n286_), .A2(new_n294_), .B(new_n167_), .Y(new_n298_));
  OA21x2_ASAP7_75t_R  g240(.A1(new_n287_), .A2(new_n297_), .B(new_n298_), .Y(o10));
  NAND2x1_ASAP7_75t_R g241(.A(new_n160_), .B(new_n293_), .Y(new_n300_));
  AO21x1_ASAP7_75t_R  g242(.A1(new_n286_), .A2(new_n294_), .B(new_n160_), .Y(new_n301_));
  OA21x2_ASAP7_75t_R  g243(.A1(new_n287_), .A2(new_n300_), .B(new_n301_), .Y(o11));
  NAND2x1_ASAP7_75t_R g244(.A(new_n286_), .B(new_n294_), .Y(new_n303_));
  OR3x1_ASAP7_75t_R   g245(.A(new_n290_), .B(p5), .C(new_n262_), .Y(new_n304_));
  NOR2x1_ASAP7_75t_R  g246(.A(new_n304_), .B(new_n287_), .Y(new_n305_));
  AOI21x1_ASAP7_75t_R g247(.A1(p5), .A2(new_n303_), .B(new_n305_), .Y(o12));
  AND3x1_ASAP7_75t_R  g248(.A(new_n286_), .B(new_n107_), .C(new_n285_), .Y(new_n307_));
  INVx1_ASAP7_75t_R   g249(.A(new_n89_), .Y(new_n308_));
  AND3x1_ASAP7_75t_R  g250(.A(new_n288_), .B(p13), .C(new_n308_), .Y(new_n309_));
  AND3x1_ASAP7_75t_R  g251(.A(new_n285_), .B(new_n289_), .C(new_n309_), .Y(new_n310_));
  NAND2x1_ASAP7_75t_R g252(.A(new_n286_), .B(new_n310_), .Y(new_n311_));
  OAI21x1_ASAP7_75t_R g253(.A1(p13), .A2(new_n307_), .B(new_n311_), .Y(o13));
  INVx1_ASAP7_75t_R   g254(.A(p17), .Y(new_n313_));
  AND3x1_ASAP7_75t_R  g255(.A(new_n254_), .B(new_n313_), .C(new_n107_), .Y(new_n314_));
  AOI21x1_ASAP7_75t_R g256(.A1(p17), .A2(new_n253_), .B(new_n314_), .Y(o14));
  INVx1_ASAP7_75t_R   g257(.A(p10), .Y(new_n316_));
  AND3x1_ASAP7_75t_R  g258(.A(new_n254_), .B(new_n316_), .C(new_n107_), .Y(new_n317_));
  AOI21x1_ASAP7_75t_R g259(.A1(p10), .A2(new_n253_), .B(new_n317_), .Y(o15));
  INVx1_ASAP7_75t_R   g260(.A(p4), .Y(new_n319_));
  AND3x1_ASAP7_75t_R  g261(.A(new_n261_), .B(new_n89_), .C(new_n258_), .Y(new_n320_));
  AO21x1_ASAP7_75t_R  g262(.A1(new_n59_), .A2(new_n83_), .B(new_n320_), .Y(new_n321_));
  OR3x1_ASAP7_75t_R   g263(.A(new_n321_), .B(new_n103_), .C(new_n106_), .Y(new_n322_));
  OR3x1_ASAP7_75t_R   g264(.A(new_n268_), .B(new_n271_), .C(new_n322_), .Y(new_n323_));
  NAND3x1_ASAP7_75t_R g265(.A(new_n152_), .B(new_n267_), .C(new_n270_), .Y(new_n324_));
  OR3x1_ASAP7_75t_R   g266(.A(new_n290_), .B(new_n252_), .C(new_n324_), .Y(new_n325_));
  OA21x2_ASAP7_75t_R  g267(.A1(new_n279_), .A2(new_n325_), .B(new_n119_), .Y(new_n326_));
  OAI21x1_ASAP7_75t_R g268(.A1(new_n319_), .A2(new_n323_), .B(new_n326_), .Y(o16));
  AND3x1_ASAP7_75t_R  g269(.A(new_n104_), .B(p0), .C(p26), .Y(new_n328_));
  NOR3x1_ASAP7_75t_R  g270(.A(new_n268_), .B(new_n271_), .C(new_n322_), .Y(new_n329_));
  NOR2x1_ASAP7_75t_R  g271(.A(new_n189_), .B(new_n193_), .Y(new_n330_));
  INVx1_ASAP7_75t_R   g272(.A(new_n330_), .Y(new_n331_));
  AO21x1_ASAP7_75t_R  g273(.A1(new_n328_), .A2(new_n329_), .B(new_n331_), .Y(new_n332_));
  NAND3x1_ASAP7_75t_R g274(.A(new_n329_), .B(new_n331_), .C(new_n328_), .Y(new_n333_));
  AND3x1_ASAP7_75t_R  g275(.A(new_n332_), .B(new_n86_), .C(new_n333_), .Y(o17));
  NAND2x1_ASAP7_75t_R g276(.A(new_n148_), .B(new_n149_), .Y(new_n335_));
  INVx1_ASAP7_75t_R   g277(.A(new_n335_), .Y(new_n336_));
  OR3x1_ASAP7_75t_R   g278(.A(new_n323_), .B(new_n146_), .C(p2), .Y(new_n337_));
  AND3x1_ASAP7_75t_R  g279(.A(new_n335_), .B(p29), .C(new_n104_), .Y(new_n338_));
  AO21x1_ASAP7_75t_R  g280(.A1(new_n338_), .A2(new_n329_), .B(new_n85_), .Y(new_n339_));
  AOI21x1_ASAP7_75t_R g281(.A1(new_n336_), .A2(new_n337_), .B(new_n339_), .Y(o18));
  NAND2x1_ASAP7_75t_R g282(.A(p20), .B(new_n329_), .Y(new_n341_));
  AOI21x1_ASAP7_75t_R g283(.A1(new_n83_), .A2(new_n341_), .B(new_n85_), .Y(o19));
  AO21x1_ASAP7_75t_R  g284(.A1(p12), .A2(new_n329_), .B(new_n100_), .Y(new_n343_));
  AND2x2_ASAP7_75t_R  g285(.A(new_n86_), .B(new_n343_), .Y(o20));
  NAND2x1_ASAP7_75t_R g286(.A(new_n245_), .B(new_n244_), .Y(new_n345_));
  AO21x1_ASAP7_75t_R  g287(.A1(new_n229_), .A2(new_n329_), .B(new_n345_), .Y(new_n346_));
  AND2x2_ASAP7_75t_R  g288(.A(new_n86_), .B(new_n346_), .Y(o21));
  AO21x1_ASAP7_75t_R  g289(.A1(p31), .A2(p30), .B(p1), .Y(new_n348_));
  INVx1_ASAP7_75t_R   g290(.A(new_n348_), .Y(new_n349_));
  AND3x1_ASAP7_75t_R  g291(.A(new_n185_), .B(new_n181_), .C(new_n260_), .Y(new_n350_));
  OR3x1_ASAP7_75t_R   g292(.A(new_n266_), .B(new_n268_), .C(new_n271_), .Y(new_n351_));
  INVx1_ASAP7_75t_R   g293(.A(new_n350_), .Y(new_n352_));
  NAND3x1_ASAP7_75t_R g294(.A(new_n265_), .B(new_n264_), .C(new_n352_), .Y(new_n353_));
  NOR3x1_ASAP7_75t_R  g295(.A(new_n353_), .B(new_n271_), .C(new_n268_), .Y(new_n354_));
  AOI21x1_ASAP7_75t_R g296(.A1(new_n350_), .A2(new_n351_), .B(new_n354_), .Y(new_n355_));
  AND3x1_ASAP7_75t_R  g297(.A(new_n265_), .B(new_n264_), .C(new_n352_), .Y(new_n356_));
  AOI21x1_ASAP7_75t_R g298(.A1(new_n356_), .A2(new_n280_), .B(new_n348_), .Y(new_n357_));
  OAI21x1_ASAP7_75t_R g299(.A1(new_n272_), .A2(new_n352_), .B(new_n357_), .Y(new_n358_));
  OAI21x1_ASAP7_75t_R g300(.A1(new_n349_), .A2(new_n355_), .B(new_n358_), .Y(o22));
  NOR2x1_ASAP7_75t_R  g301(.A(new_n60_), .B(new_n61_), .Y(new_n360_));
  XOR2x2_ASAP7_75t_R  g302(.A(new_n144_), .B(new_n360_), .Y(new_n361_));
  NOR2x1_ASAP7_75t_R  g303(.A(p28), .B(p1), .Y(new_n362_));
  XOR2x2_ASAP7_75t_R  g304(.A(new_n361_), .B(new_n362_), .Y(new_n363_));
  OA21x2_ASAP7_75t_R  g305(.A1(p1), .A2(p3), .B(new_n363_), .Y(new_n364_));
  XOR2x2_ASAP7_75t_R  g306(.A(new_n281_), .B(new_n364_), .Y(o23));
  AND3x1_ASAP7_75t_R  g307(.A(new_n206_), .B(new_n208_), .C(new_n86_), .Y(new_n366_));
  OA21x2_ASAP7_75t_R  g308(.A1(new_n211_), .A2(new_n323_), .B(new_n366_), .Y(o24));
endmodule


