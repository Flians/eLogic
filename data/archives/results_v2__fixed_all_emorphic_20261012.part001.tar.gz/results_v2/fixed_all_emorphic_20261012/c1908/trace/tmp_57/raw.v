// Benchmark "/tmp/" written by ABC on Mon Oct 12 15:05:32 2026

module \/tmp/  ( 
    p7, p22, p26, p28, p29, p5, p21, p17, p11, p10, p16, p8, p31, p24, p32,
    p19, p12, p15, p30, p4, p6, p1, p20, p18, p9, p0, p2, p3, p13, p23,
    p14, p27, p25,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24  );
  input  p7, p22, p26, p28, p29, p5, p21, p17, p11, p10, p16, p8, p31,
    p24, p32, p19, p12, p15, p30, p4, p6, p1, p20, p18, p9, p0, p2, p3,
    p13, p23, p14, p27, p25;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24;
  wire new_n59_, new_n60_, new_n61_, new_n62_, new_n63_, new_n64_, new_n65_,
    new_n66_, new_n67_, new_n68_, new_n69_, new_n70_, new_n71_, new_n72_,
    new_n73_, new_n74_, new_n75_, new_n76_, new_n77_, new_n78_, new_n79_,
    new_n80_, new_n81_, new_n82_, new_n83_, new_n84_, new_n85_, new_n86_,
    new_n87_, new_n88_, new_n89_, new_n90_, new_n91_, new_n92_, new_n93_,
    new_n94_, new_n95_, new_n96_, new_n97_, new_n98_, new_n99_, new_n100_,
    new_n101_, new_n102_, new_n103_, new_n104_, new_n105_, new_n106_,
    new_n107_, new_n108_, new_n109_, new_n110_, new_n111_, new_n112_,
    new_n113_, new_n114_, new_n115_, new_n116_, new_n117_, new_n118_,
    new_n119_, new_n120_, new_n121_, new_n122_, new_n123_, new_n124_,
    new_n125_, new_n126_, new_n127_, new_n128_, new_n129_, new_n130_,
    new_n131_, new_n132_, new_n133_, new_n134_, new_n135_, new_n136_,
    new_n137_, new_n138_, new_n139_, new_n140_, new_n141_, new_n142_,
    new_n143_, new_n144_, new_n145_, new_n146_, new_n147_, new_n148_,
    new_n149_, new_n150_, new_n151_, new_n152_, new_n153_, new_n154_,
    new_n155_, new_n156_, new_n157_, new_n158_, new_n159_, new_n160_,
    new_n161_, new_n162_, new_n163_, new_n164_, new_n165_, new_n166_,
    new_n167_, new_n168_, new_n169_, new_n170_, new_n171_, new_n172_,
    new_n173_, new_n174_, new_n175_, new_n176_, new_n177_, new_n178_,
    new_n179_, new_n180_, new_n181_, new_n182_, new_n183_, new_n184_,
    new_n185_, new_n186_, new_n187_, new_n188_, new_n189_, new_n190_,
    new_n191_, new_n192_, new_n193_, new_n194_, new_n195_, new_n196_,
    new_n197_, new_n198_, new_n199_, new_n200_, new_n201_, new_n202_,
    new_n203_, new_n204_, new_n205_, new_n206_, new_n207_, new_n208_,
    new_n209_, new_n210_, new_n211_, new_n212_, new_n213_, new_n214_,
    new_n215_, new_n216_, new_n217_, new_n218_, new_n219_, new_n220_,
    new_n221_, new_n222_, new_n223_, new_n224_, new_n225_, new_n226_,
    new_n227_, new_n228_, new_n229_, new_n230_, new_n231_, new_n232_,
    new_n233_, new_n234_, new_n235_, new_n236_, new_n237_, new_n238_,
    new_n239_, new_n240_, new_n241_, new_n242_, new_n243_, new_n244_,
    new_n245_, new_n246_, new_n247_, new_n248_, new_n249_, new_n250_,
    new_n251_, new_n252_, new_n253_, new_n254_, new_n255_, new_n256_,
    new_n257_, new_n258_, new_n259_, new_n260_, new_n261_, new_n262_,
    new_n263_, new_n264_, new_n266_, new_n267_, new_n268_, new_n269_,
    new_n270_, new_n271_, new_n272_, new_n273_, new_n274_, new_n275_,
    new_n278_, new_n282_, new_n283_, new_n284_, new_n288_, new_n289_,
    new_n290_, new_n291_, new_n296_, new_n297_, new_n298_, new_n299_,
    new_n300_, new_n301_, new_n302_, new_n304_, new_n305_, new_n307_,
    new_n308_, new_n310_, new_n311_, new_n312_, new_n313_, new_n314_,
    new_n315_, new_n316_, new_n317_, new_n318_, new_n320_, new_n321_,
    new_n322_, new_n323_, new_n324_, new_n325_, new_n327_, new_n328_,
    new_n329_, new_n330_, new_n331_, new_n333_, new_n335_, new_n337_,
    new_n338_, new_n340_, new_n341_, new_n342_, new_n343_, new_n344_,
    new_n345_, new_n346_, new_n347_, new_n348_, new_n349_, new_n350_,
    new_n351_, new_n353_, new_n354_, new_n355_, new_n356_, new_n357_,
    new_n359_, new_n360_;
  INVx1_ASAP7_75t_R   g000(.A(p32), .Y(new_n59_));
  INVx1_ASAP7_75t_R   g001(.A(p2), .Y(new_n60_));
  INVx1_ASAP7_75t_R   g002(.A(p23), .Y(new_n61_));
  AO21x1_ASAP7_75t_R  g003(.A1(new_n59_), .A2(new_n60_), .B(new_n61_), .Y(new_n62_));
  INVx1_ASAP7_75t_R   g004(.A(new_n62_), .Y(new_n63_));
  INVx1_ASAP7_75t_R   g005(.A(p25), .Y(new_n64_));
  NOR2x1_ASAP7_75t_R  g006(.A(p19), .B(new_n64_), .Y(new_n65_));
  INVx1_ASAP7_75t_R   g007(.A(p19), .Y(new_n66_));
  NOR2x1_ASAP7_75t_R  g008(.A(p25), .B(new_n66_), .Y(new_n67_));
  OAI21x1_ASAP7_75t_R g009(.A1(new_n65_), .A2(new_n67_), .B(p7), .Y(new_n68_));
  NAND2x1_ASAP7_75t_R g010(.A(p25), .B(new_n66_), .Y(new_n69_));
  NAND2x1_ASAP7_75t_R g011(.A(p19), .B(new_n64_), .Y(new_n70_));
  INVx1_ASAP7_75t_R   g012(.A(p7), .Y(new_n71_));
  NAND3x1_ASAP7_75t_R g013(.A(new_n69_), .B(new_n70_), .C(new_n71_), .Y(new_n72_));
  NAND2x1_ASAP7_75t_R g014(.A(new_n68_), .B(new_n72_), .Y(new_n73_));
  XOR2x2_ASAP7_75t_R  g015(.A(p22), .B(p14), .Y(new_n74_));
  INVx1_ASAP7_75t_R   g016(.A(p1), .Y(new_n75_));
  NAND2x1_ASAP7_75t_R g017(.A(p28), .B(new_n75_), .Y(new_n76_));
  XOR2x2_ASAP7_75t_R  g018(.A(new_n74_), .B(new_n76_), .Y(new_n77_));
  NAND2x1_ASAP7_75t_R g019(.A(new_n73_), .B(new_n77_), .Y(new_n78_));
  NOR2x1_ASAP7_75t_R  g020(.A(p19), .B(new_n71_), .Y(new_n79_));
  AO21x1_ASAP7_75t_R  g021(.A1(p19), .A2(new_n71_), .B(new_n64_), .Y(new_n80_));
  NOR2x1_ASAP7_75t_R  g022(.A(p7), .B(new_n66_), .Y(new_n81_));
  OAI21x1_ASAP7_75t_R g023(.A1(new_n79_), .A2(new_n81_), .B(new_n64_), .Y(new_n82_));
  OAI21x1_ASAP7_75t_R g024(.A1(new_n79_), .A2(new_n80_), .B(new_n82_), .Y(new_n83_));
  INVx1_ASAP7_75t_R   g025(.A(p28), .Y(new_n84_));
  NOR2x1_ASAP7_75t_R  g026(.A(p1), .B(new_n84_), .Y(new_n85_));
  XOR2x2_ASAP7_75t_R  g027(.A(new_n74_), .B(new_n85_), .Y(new_n86_));
  NAND2x1_ASAP7_75t_R g028(.A(new_n83_), .B(new_n86_), .Y(new_n87_));
  NOR2x1_ASAP7_75t_R  g029(.A(p8), .B(p9), .Y(new_n88_));
  AND2x2_ASAP7_75t_R  g030(.A(p8), .B(p9), .Y(new_n89_));
  INVx1_ASAP7_75t_R   g031(.A(p15), .Y(new_n90_));
  OAI21x1_ASAP7_75t_R g032(.A1(new_n88_), .A2(new_n89_), .B(new_n90_), .Y(new_n91_));
  OR3x1_ASAP7_75t_R   g033(.A(new_n89_), .B(new_n90_), .C(new_n88_), .Y(new_n92_));
  NAND2x1_ASAP7_75t_R g034(.A(new_n91_), .B(new_n92_), .Y(new_n93_));
  NOR2x1_ASAP7_75t_R  g035(.A(p17), .B(p10), .Y(new_n94_));
  AND2x2_ASAP7_75t_R  g036(.A(p17), .B(p10), .Y(new_n95_));
  OAI21x1_ASAP7_75t_R g037(.A1(new_n94_), .A2(new_n95_), .B(p24), .Y(new_n96_));
  OR3x1_ASAP7_75t_R   g038(.A(new_n95_), .B(p24), .C(new_n94_), .Y(new_n97_));
  NAND2x1_ASAP7_75t_R g039(.A(new_n96_), .B(new_n97_), .Y(new_n98_));
  XOR2x2_ASAP7_75t_R  g040(.A(new_n93_), .B(new_n98_), .Y(new_n99_));
  AOI21x1_ASAP7_75t_R g041(.A1(new_n78_), .A2(new_n87_), .B(new_n99_), .Y(new_n100_));
  INVx1_ASAP7_75t_R   g042(.A(p29), .Y(new_n101_));
  AOI21x1_ASAP7_75t_R g043(.A1(new_n60_), .A2(new_n100_), .B(new_n101_), .Y(new_n102_));
  NAND2x1_ASAP7_75t_R g044(.A(new_n78_), .B(new_n87_), .Y(new_n103_));
  OAI21x1_ASAP7_75t_R g045(.A1(new_n88_), .A2(new_n89_), .B(p15), .Y(new_n104_));
  OR3x1_ASAP7_75t_R   g046(.A(new_n89_), .B(p15), .C(new_n88_), .Y(new_n105_));
  NAND2x1_ASAP7_75t_R g047(.A(new_n104_), .B(new_n105_), .Y(new_n106_));
  XOR2x2_ASAP7_75t_R  g048(.A(new_n106_), .B(new_n98_), .Y(new_n107_));
  OR3x1_ASAP7_75t_R   g049(.A(new_n103_), .B(p2), .C(new_n107_), .Y(new_n108_));
  NAND3x1_ASAP7_75t_R g050(.A(new_n99_), .B(new_n78_), .C(new_n87_), .Y(new_n109_));
  NAND2x1_ASAP7_75t_R g051(.A(new_n107_), .B(new_n103_), .Y(new_n110_));
  NAND2x1_ASAP7_75t_R g052(.A(new_n101_), .B(new_n60_), .Y(new_n111_));
  AOI21x1_ASAP7_75t_R g053(.A1(new_n109_), .A2(new_n110_), .B(new_n111_), .Y(new_n112_));
  AO21x1_ASAP7_75t_R  g054(.A1(new_n102_), .A2(new_n108_), .B(new_n112_), .Y(new_n113_));
  NAND2x1_ASAP7_75t_R g055(.A(new_n63_), .B(new_n113_), .Y(new_n114_));
  OR3x1_ASAP7_75t_R   g056(.A(p1), .B(p2), .C(p3), .Y(new_n115_));
  NOR2x1_ASAP7_75t_R  g057(.A(p4), .B(p1), .Y(new_n116_));
  INVx1_ASAP7_75t_R   g058(.A(new_n116_), .Y(new_n117_));
  INVx1_ASAP7_75t_R   g059(.A(p0), .Y(new_n118_));
  NOR2x1_ASAP7_75t_R  g060(.A(p32), .B(new_n118_), .Y(new_n119_));
  AO21x1_ASAP7_75t_R  g061(.A1(new_n115_), .A2(new_n117_), .B(new_n119_), .Y(new_n120_));
  NOR2x1_ASAP7_75t_R  g062(.A(p20), .B(p2), .Y(new_n121_));
  AND3x1_ASAP7_75t_R  g063(.A(new_n75_), .B(new_n118_), .C(p16), .Y(new_n122_));
  NAND2x1_ASAP7_75t_R g064(.A(p5), .B(new_n122_), .Y(new_n123_));
  NOR2x1_ASAP7_75t_R  g065(.A(p1), .B(p0), .Y(new_n124_));
  AO21x1_ASAP7_75t_R  g066(.A1(p16), .A2(new_n124_), .B(p5), .Y(new_n125_));
  NOR2x1_ASAP7_75t_R  g067(.A(p13), .B(p14), .Y(new_n126_));
  AND2x2_ASAP7_75t_R  g068(.A(p13), .B(p14), .Y(new_n127_));
  OAI21x1_ASAP7_75t_R g069(.A1(new_n126_), .A2(new_n127_), .B(new_n90_), .Y(new_n128_));
  OAI21x1_ASAP7_75t_R g070(.A1(p13), .A2(p14), .B(p15), .Y(new_n129_));
  AO21x1_ASAP7_75t_R  g071(.A1(p13), .A2(p14), .B(new_n129_), .Y(new_n130_));
  NAND2x1_ASAP7_75t_R g072(.A(new_n128_), .B(new_n130_), .Y(new_n131_));
  AO21x1_ASAP7_75t_R  g073(.A1(new_n123_), .A2(new_n125_), .B(new_n131_), .Y(new_n132_));
  NAND3x1_ASAP7_75t_R g074(.A(new_n131_), .B(new_n123_), .C(new_n125_), .Y(new_n133_));
  XNOR2x2_ASAP7_75t_R g075(.A(p17), .B(p8), .Y(new_n134_));
  XOR2x2_ASAP7_75t_R  g076(.A(p19), .B(p18), .Y(new_n135_));
  XOR2x2_ASAP7_75t_R  g077(.A(new_n134_), .B(new_n135_), .Y(new_n136_));
  NAND3x1_ASAP7_75t_R g078(.A(new_n132_), .B(new_n133_), .C(new_n136_), .Y(new_n137_));
  AO21x1_ASAP7_75t_R  g079(.A1(new_n133_), .A2(new_n132_), .B(new_n136_), .Y(new_n138_));
  AND2x2_ASAP7_75t_R  g080(.A(new_n137_), .B(new_n138_), .Y(new_n139_));
  NAND2x1_ASAP7_75t_R g081(.A(new_n121_), .B(new_n139_), .Y(new_n140_));
  NOR2x1_ASAP7_75t_R  g082(.A(new_n88_), .B(new_n89_), .Y(new_n141_));
  AND3x1_ASAP7_75t_R  g083(.A(new_n59_), .B(new_n75_), .C(p11), .Y(new_n142_));
  XOR2x2_ASAP7_75t_R  g084(.A(new_n141_), .B(new_n142_), .Y(new_n143_));
  XNOR2x2_ASAP7_75t_R g085(.A(p7), .B(p5), .Y(new_n144_));
  XOR2x2_ASAP7_75t_R  g086(.A(p10), .B(p6), .Y(new_n145_));
  XOR2x2_ASAP7_75t_R  g087(.A(new_n144_), .B(new_n145_), .Y(new_n146_));
  XOR2x2_ASAP7_75t_R  g088(.A(new_n143_), .B(new_n146_), .Y(new_n147_));
  INVx1_ASAP7_75t_R   g089(.A(p12), .Y(new_n148_));
  OAI21x1_ASAP7_75t_R g090(.A1(p2), .A2(new_n147_), .B(new_n148_), .Y(new_n149_));
  XNOR2x2_ASAP7_75t_R g091(.A(new_n146_), .B(new_n143_), .Y(new_n150_));
  NAND3x1_ASAP7_75t_R g092(.A(new_n150_), .B(p12), .C(new_n60_), .Y(new_n151_));
  NAND2x1_ASAP7_75t_R g093(.A(new_n149_), .B(new_n151_), .Y(new_n152_));
  NAND3x1_ASAP7_75t_R g094(.A(new_n138_), .B(new_n60_), .C(new_n137_), .Y(new_n153_));
  NAND2x1_ASAP7_75t_R g095(.A(p20), .B(new_n153_), .Y(new_n154_));
  NAND3x1_ASAP7_75t_R g096(.A(new_n140_), .B(new_n152_), .C(new_n154_), .Y(new_n155_));
  NOR2x1_ASAP7_75t_R  g097(.A(new_n120_), .B(new_n155_), .Y(new_n156_));
  NAND2x1_ASAP7_75t_R g098(.A(new_n114_), .B(new_n156_), .Y(new_n157_));
  INVx1_ASAP7_75t_R   g099(.A(p26), .Y(new_n158_));
  AO21x1_ASAP7_75t_R  g100(.A1(new_n118_), .A2(new_n60_), .B(new_n158_), .Y(new_n159_));
  INVx1_ASAP7_75t_R   g101(.A(new_n159_), .Y(new_n160_));
  INVx1_ASAP7_75t_R   g102(.A(p18), .Y(new_n161_));
  NOR2x1_ASAP7_75t_R  g103(.A(p6), .B(new_n161_), .Y(new_n162_));
  INVx1_ASAP7_75t_R   g104(.A(p6), .Y(new_n163_));
  NOR2x1_ASAP7_75t_R  g105(.A(p18), .B(new_n163_), .Y(new_n164_));
  OAI21x1_ASAP7_75t_R g106(.A1(new_n162_), .A2(new_n164_), .B(p21), .Y(new_n165_));
  NAND2x1_ASAP7_75t_R g107(.A(p18), .B(new_n163_), .Y(new_n166_));
  NAND2x1_ASAP7_75t_R g108(.A(p6), .B(new_n161_), .Y(new_n167_));
  INVx1_ASAP7_75t_R   g109(.A(p21), .Y(new_n168_));
  NAND3x1_ASAP7_75t_R g110(.A(new_n166_), .B(new_n167_), .C(new_n168_), .Y(new_n169_));
  NAND2x1_ASAP7_75t_R g111(.A(new_n165_), .B(new_n169_), .Y(new_n170_));
  NAND2x1_ASAP7_75t_R g112(.A(new_n83_), .B(new_n170_), .Y(new_n171_));
  XOR2x2_ASAP7_75t_R  g113(.A(p19), .B(p25), .Y(new_n172_));
  AND2x2_ASAP7_75t_R  g114(.A(p7), .B(new_n172_), .Y(new_n173_));
  NOR2x1_ASAP7_75t_R  g115(.A(p7), .B(new_n172_), .Y(new_n174_));
  NOR2x1_ASAP7_75t_R  g116(.A(p6), .B(new_n168_), .Y(new_n175_));
  AO21x1_ASAP7_75t_R  g117(.A1(p6), .A2(new_n168_), .B(new_n161_), .Y(new_n176_));
  NOR2x1_ASAP7_75t_R  g118(.A(p21), .B(new_n163_), .Y(new_n177_));
  OAI21x1_ASAP7_75t_R g119(.A1(new_n175_), .A2(new_n177_), .B(new_n161_), .Y(new_n178_));
  OAI21x1_ASAP7_75t_R g120(.A1(new_n175_), .A2(new_n176_), .B(new_n178_), .Y(new_n179_));
  OAI21x1_ASAP7_75t_R g121(.A1(new_n173_), .A2(new_n174_), .B(new_n179_), .Y(new_n180_));
  XNOR2x2_ASAP7_75t_R g122(.A(p22), .B(p5), .Y(new_n181_));
  NAND3x1_ASAP7_75t_R g123(.A(new_n171_), .B(new_n180_), .C(new_n181_), .Y(new_n182_));
  NOR2x1_ASAP7_75t_R  g124(.A(new_n179_), .B(new_n73_), .Y(new_n183_));
  NOR2x1_ASAP7_75t_R  g125(.A(new_n83_), .B(new_n170_), .Y(new_n184_));
  INVx1_ASAP7_75t_R   g126(.A(new_n181_), .Y(new_n185_));
  OAI21x1_ASAP7_75t_R g127(.A1(new_n183_), .A2(new_n184_), .B(new_n185_), .Y(new_n186_));
  NAND2x1_ASAP7_75t_R g128(.A(p30), .B(new_n75_), .Y(new_n187_));
  XOR2x2_ASAP7_75t_R  g129(.A(new_n187_), .B(p13), .Y(new_n188_));
  XOR2x2_ASAP7_75t_R  g130(.A(new_n93_), .B(new_n188_), .Y(new_n189_));
  AOI21x1_ASAP7_75t_R g131(.A1(new_n182_), .A2(new_n186_), .B(new_n189_), .Y(new_n190_));
  NAND3x1_ASAP7_75t_R g132(.A(new_n171_), .B(new_n180_), .C(new_n185_), .Y(new_n191_));
  OAI21x1_ASAP7_75t_R g133(.A1(new_n183_), .A2(new_n184_), .B(new_n181_), .Y(new_n192_));
  XOR2x2_ASAP7_75t_R  g134(.A(new_n106_), .B(new_n188_), .Y(new_n193_));
  AOI21x1_ASAP7_75t_R g135(.A1(new_n191_), .A2(new_n192_), .B(new_n193_), .Y(new_n194_));
  OAI21x1_ASAP7_75t_R g136(.A1(new_n190_), .A2(new_n194_), .B(new_n60_), .Y(new_n195_));
  NAND2x1_ASAP7_75t_R g137(.A(new_n160_), .B(new_n195_), .Y(new_n196_));
  OA21x2_ASAP7_75t_R  g138(.A1(p0), .A2(p2), .B(p16), .Y(new_n197_));
  OA21x2_ASAP7_75t_R  g139(.A1(new_n158_), .A2(new_n118_), .B(new_n60_), .Y(new_n198_));
  OAI21x1_ASAP7_75t_R g140(.A1(new_n190_), .A2(new_n194_), .B(new_n198_), .Y(new_n199_));
  AND3x1_ASAP7_75t_R  g141(.A(new_n196_), .B(new_n197_), .C(new_n199_), .Y(new_n200_));
  INVx1_ASAP7_75t_R   g142(.A(new_n200_), .Y(new_n201_));
  NAND3x1_ASAP7_75t_R g143(.A(new_n124_), .B(p26), .C(new_n64_), .Y(new_n202_));
  AO21x1_ASAP7_75t_R  g144(.A1(p26), .A2(new_n124_), .B(new_n64_), .Y(new_n203_));
  AND2x2_ASAP7_75t_R  g145(.A(new_n202_), .B(new_n203_), .Y(new_n204_));
  XOR2x2_ASAP7_75t_R  g146(.A(new_n170_), .B(new_n204_), .Y(new_n205_));
  NAND2x1_ASAP7_75t_R g147(.A(new_n99_), .B(new_n205_), .Y(new_n206_));
  XOR2x2_ASAP7_75t_R  g148(.A(new_n179_), .B(new_n204_), .Y(new_n207_));
  NAND2x1_ASAP7_75t_R g149(.A(new_n107_), .B(new_n207_), .Y(new_n208_));
  INVx1_ASAP7_75t_R   g150(.A(p27), .Y(new_n209_));
  NOR2x1_ASAP7_75t_R  g151(.A(p2), .B(new_n209_), .Y(new_n210_));
  NAND3x1_ASAP7_75t_R g152(.A(new_n206_), .B(new_n208_), .C(new_n210_), .Y(new_n211_));
  NAND3x1_ASAP7_75t_R g153(.A(new_n205_), .B(new_n107_), .C(new_n60_), .Y(new_n212_));
  NAND3x1_ASAP7_75t_R g154(.A(new_n207_), .B(new_n99_), .C(new_n60_), .Y(new_n213_));
  NAND3x1_ASAP7_75t_R g155(.A(new_n212_), .B(new_n213_), .C(new_n209_), .Y(new_n214_));
  NAND2x1_ASAP7_75t_R g156(.A(p13), .B(p14), .Y(new_n215_));
  OR3x1_ASAP7_75t_R   g157(.A(p15), .B(p13), .C(p14), .Y(new_n216_));
  OAI21x1_ASAP7_75t_R g158(.A1(p15), .A2(new_n215_), .B(new_n216_), .Y(new_n217_));
  NOR2x1_ASAP7_75t_R  g159(.A(new_n129_), .B(new_n127_), .Y(new_n218_));
  NOR3x1_ASAP7_75t_R  g160(.A(new_n217_), .B(p22), .C(new_n218_), .Y(new_n219_));
  INVx1_ASAP7_75t_R   g161(.A(p22), .Y(new_n220_));
  AOI21x1_ASAP7_75t_R g162(.A1(new_n128_), .A2(new_n130_), .B(new_n220_), .Y(new_n221_));
  NOR2x1_ASAP7_75t_R  g163(.A(p32), .B(p1), .Y(new_n222_));
  NOR2x1_ASAP7_75t_R  g164(.A(p24), .B(new_n61_), .Y(new_n223_));
  INVx1_ASAP7_75t_R   g165(.A(p24), .Y(new_n224_));
  AOI21x1_ASAP7_75t_R g166(.A1(p23), .A2(new_n222_), .B(new_n224_), .Y(new_n225_));
  AOI21x1_ASAP7_75t_R g167(.A1(new_n222_), .A2(new_n223_), .B(new_n225_), .Y(new_n226_));
  OAI21x1_ASAP7_75t_R g168(.A1(new_n219_), .A2(new_n221_), .B(new_n226_), .Y(new_n227_));
  NAND3x1_ASAP7_75t_R g169(.A(new_n130_), .B(new_n128_), .C(new_n220_), .Y(new_n228_));
  OAI21x1_ASAP7_75t_R g170(.A1(new_n218_), .A2(new_n217_), .B(p22), .Y(new_n229_));
  AO21x1_ASAP7_75t_R  g171(.A1(new_n222_), .A2(new_n223_), .B(new_n225_), .Y(new_n230_));
  NAND3x1_ASAP7_75t_R g172(.A(new_n228_), .B(new_n229_), .C(new_n230_), .Y(new_n231_));
  XNOR2x2_ASAP7_75t_R g173(.A(p21), .B(p9), .Y(new_n232_));
  NAND3x1_ASAP7_75t_R g174(.A(new_n227_), .B(new_n231_), .C(new_n232_), .Y(new_n233_));
  INVx1_ASAP7_75t_R   g175(.A(p11), .Y(new_n234_));
  AO21x1_ASAP7_75t_R  g176(.A1(new_n59_), .A2(new_n60_), .B(new_n234_), .Y(new_n235_));
  INVx1_ASAP7_75t_R   g177(.A(new_n235_), .Y(new_n236_));
  NAND2x1_ASAP7_75t_R g178(.A(p23), .B(new_n222_), .Y(new_n237_));
  XOR2x2_ASAP7_75t_R  g179(.A(p22), .B(p24), .Y(new_n238_));
  NAND2x1_ASAP7_75t_R g180(.A(new_n237_), .B(new_n238_), .Y(new_n239_));
  INVx1_ASAP7_75t_R   g181(.A(new_n222_), .Y(new_n240_));
  OR3x1_ASAP7_75t_R   g182(.A(new_n238_), .B(new_n61_), .C(new_n240_), .Y(new_n241_));
  NOR2x1_ASAP7_75t_R  g183(.A(new_n218_), .B(new_n217_), .Y(new_n242_));
  AOI21x1_ASAP7_75t_R g184(.A1(new_n239_), .A2(new_n241_), .B(new_n242_), .Y(new_n243_));
  NOR2x1_ASAP7_75t_R  g185(.A(new_n237_), .B(new_n238_), .Y(new_n244_));
  AND2x2_ASAP7_75t_R  g186(.A(new_n237_), .B(new_n238_), .Y(new_n245_));
  NOR3x1_ASAP7_75t_R  g187(.A(new_n131_), .B(new_n244_), .C(new_n245_), .Y(new_n246_));
  INVx1_ASAP7_75t_R   g188(.A(new_n232_), .Y(new_n247_));
  OAI21x1_ASAP7_75t_R g189(.A1(new_n243_), .A2(new_n246_), .B(new_n247_), .Y(new_n248_));
  NAND3x1_ASAP7_75t_R g190(.A(new_n233_), .B(new_n236_), .C(new_n248_), .Y(new_n249_));
  OAI21x1_ASAP7_75t_R g191(.A1(new_n244_), .A2(new_n245_), .B(new_n131_), .Y(new_n250_));
  NAND3x1_ASAP7_75t_R g192(.A(new_n242_), .B(new_n241_), .C(new_n239_), .Y(new_n251_));
  AO21x1_ASAP7_75t_R  g193(.A1(new_n250_), .A2(new_n251_), .B(new_n247_), .Y(new_n252_));
  NAND3x1_ASAP7_75t_R g194(.A(new_n251_), .B(new_n250_), .C(new_n247_), .Y(new_n253_));
  AND2x2_ASAP7_75t_R  g195(.A(new_n60_), .B(new_n235_), .Y(new_n254_));
  NAND3x1_ASAP7_75t_R g196(.A(new_n252_), .B(new_n253_), .C(new_n254_), .Y(new_n255_));
  NOR2x1_ASAP7_75t_R  g197(.A(new_n60_), .B(new_n235_), .Y(new_n256_));
  INVx1_ASAP7_75t_R   g198(.A(new_n256_), .Y(new_n257_));
  NAND3x1_ASAP7_75t_R g199(.A(new_n249_), .B(new_n255_), .C(new_n257_), .Y(new_n258_));
  AOI21x1_ASAP7_75t_R g200(.A1(new_n211_), .A2(new_n214_), .B(new_n258_), .Y(new_n259_));
  INVx1_ASAP7_75t_R   g201(.A(new_n259_), .Y(new_n260_));
  OR3x1_ASAP7_75t_R   g202(.A(new_n157_), .B(new_n201_), .C(new_n260_), .Y(new_n261_));
  AND3x1_ASAP7_75t_R  g203(.A(new_n200_), .B(new_n259_), .C(new_n114_), .Y(new_n262_));
  INVx1_ASAP7_75t_R   g204(.A(p14), .Y(new_n263_));
  AND3x1_ASAP7_75t_R  g205(.A(new_n262_), .B(new_n263_), .C(new_n156_), .Y(new_n264_));
  AOI21x1_ASAP7_75t_R g206(.A1(p14), .A2(new_n261_), .B(new_n264_), .Y(o0));
  INVx1_ASAP7_75t_R   g207(.A(new_n197_), .Y(new_n266_));
  AOI21x1_ASAP7_75t_R g208(.A1(new_n199_), .A2(new_n196_), .B(new_n266_), .Y(new_n267_));
  AOI21x1_ASAP7_75t_R g209(.A1(new_n108_), .A2(new_n102_), .B(new_n112_), .Y(new_n268_));
  OAI21x1_ASAP7_75t_R g210(.A1(new_n62_), .A2(new_n268_), .B(new_n259_), .Y(new_n269_));
  OR3x1_ASAP7_75t_R   g211(.A(p31), .B(p1), .C(p2), .Y(new_n270_));
  AOI21x1_ASAP7_75t_R g212(.A1(new_n270_), .A2(new_n117_), .B(new_n119_), .Y(new_n271_));
  INVx1_ASAP7_75t_R   g213(.A(new_n271_), .Y(new_n272_));
  AOI21x1_ASAP7_75t_R g214(.A1(new_n149_), .A2(new_n151_), .B(new_n272_), .Y(new_n273_));
  NAND3x1_ASAP7_75t_R g215(.A(new_n273_), .B(new_n154_), .C(new_n140_), .Y(new_n274_));
  NOR3x1_ASAP7_75t_R  g216(.A(new_n267_), .B(new_n269_), .C(new_n274_), .Y(new_n275_));
  XOR2x2_ASAP7_75t_R  g217(.A(new_n275_), .B(new_n64_), .Y(o1));
  XOR2x2_ASAP7_75t_R  g218(.A(new_n275_), .B(new_n66_), .Y(o2));
  AND3x1_ASAP7_75t_R  g219(.A(new_n262_), .B(new_n224_), .C(new_n156_), .Y(new_n278_));
  AOI21x1_ASAP7_75t_R g220(.A1(p24), .A2(new_n261_), .B(new_n278_), .Y(o3));
  XOR2x2_ASAP7_75t_R  g221(.A(new_n275_), .B(new_n71_), .Y(o4));
  XOR2x2_ASAP7_75t_R  g222(.A(new_n275_), .B(new_n220_), .Y(o5));
  NAND2x1_ASAP7_75t_R g223(.A(new_n199_), .B(new_n196_), .Y(new_n282_));
  AOI21x1_ASAP7_75t_R g224(.A1(new_n197_), .A2(new_n282_), .B(new_n269_), .Y(new_n283_));
  NAND2x1_ASAP7_75t_R g225(.A(new_n156_), .B(new_n283_), .Y(new_n284_));
  XOR2x2_ASAP7_75t_R  g226(.A(new_n284_), .B(p9), .Y(o6));
  XOR2x2_ASAP7_75t_R  g227(.A(new_n284_), .B(p8), .Y(o7));
  XOR2x2_ASAP7_75t_R  g228(.A(new_n284_), .B(p15), .Y(o8));
  AND3x1_ASAP7_75t_R  g229(.A(new_n273_), .B(new_n154_), .C(new_n140_), .Y(new_n288_));
  AND3x1_ASAP7_75t_R  g230(.A(new_n288_), .B(new_n63_), .C(new_n268_), .Y(new_n289_));
  NOR2x1_ASAP7_75t_R  g231(.A(new_n260_), .B(new_n267_), .Y(new_n290_));
  NAND2x1_ASAP7_75t_R g232(.A(new_n289_), .B(new_n290_), .Y(new_n291_));
  XOR2x2_ASAP7_75t_R  g233(.A(new_n291_), .B(p18), .Y(o9));
  XOR2x2_ASAP7_75t_R  g234(.A(new_n291_), .B(p6), .Y(o10));
  XOR2x2_ASAP7_75t_R  g235(.A(new_n291_), .B(p21), .Y(o11));
  XOR2x2_ASAP7_75t_R  g236(.A(new_n291_), .B(p5), .Y(o12));
  AND2x2_ASAP7_75t_R  g237(.A(new_n63_), .B(new_n268_), .Y(new_n296_));
  AND3x1_ASAP7_75t_R  g238(.A(new_n290_), .B(new_n156_), .C(new_n296_), .Y(new_n297_));
  AND2x2_ASAP7_75t_R  g239(.A(new_n154_), .B(new_n152_), .Y(new_n298_));
  INVx1_ASAP7_75t_R   g240(.A(new_n120_), .Y(new_n299_));
  AND3x1_ASAP7_75t_R  g241(.A(new_n140_), .B(p13), .C(new_n299_), .Y(new_n300_));
  AND3x1_ASAP7_75t_R  g242(.A(new_n296_), .B(new_n298_), .C(new_n300_), .Y(new_n301_));
  NAND2x1_ASAP7_75t_R g243(.A(new_n290_), .B(new_n301_), .Y(new_n302_));
  OAI21x1_ASAP7_75t_R g244(.A1(p13), .A2(new_n297_), .B(new_n302_), .Y(o13));
  INVx1_ASAP7_75t_R   g245(.A(p17), .Y(new_n304_));
  AND3x1_ASAP7_75t_R  g246(.A(new_n262_), .B(new_n304_), .C(new_n156_), .Y(new_n305_));
  AOI21x1_ASAP7_75t_R g247(.A1(p17), .A2(new_n261_), .B(new_n305_), .Y(o14));
  INVx1_ASAP7_75t_R   g248(.A(p10), .Y(new_n307_));
  AND3x1_ASAP7_75t_R  g249(.A(new_n262_), .B(new_n307_), .C(new_n156_), .Y(new_n308_));
  AOI21x1_ASAP7_75t_R g250(.A1(p10), .A2(new_n261_), .B(new_n308_), .Y(o15));
  INVx1_ASAP7_75t_R   g251(.A(p4), .Y(new_n310_));
  NAND2x1_ASAP7_75t_R g252(.A(new_n120_), .B(new_n272_), .Y(new_n311_));
  OA21x2_ASAP7_75t_R  g253(.A1(p20), .A2(new_n153_), .B(new_n311_), .Y(new_n312_));
  NAND3x1_ASAP7_75t_R g254(.A(new_n312_), .B(new_n154_), .C(new_n152_), .Y(new_n313_));
  OR3x1_ASAP7_75t_R   g255(.A(new_n267_), .B(new_n269_), .C(new_n313_), .Y(new_n314_));
  AND3x1_ASAP7_75t_R  g256(.A(new_n199_), .B(new_n266_), .C(new_n62_), .Y(new_n315_));
  AND3x1_ASAP7_75t_R  g257(.A(new_n315_), .B(new_n196_), .C(new_n268_), .Y(new_n316_));
  NAND2x1_ASAP7_75t_R g258(.A(new_n259_), .B(new_n316_), .Y(new_n317_));
  OA21x2_ASAP7_75t_R  g259(.A1(new_n155_), .A2(new_n317_), .B(new_n75_), .Y(new_n318_));
  OAI21x1_ASAP7_75t_R g260(.A1(new_n310_), .A2(new_n314_), .B(new_n318_), .Y(o16));
  NOR2x1_ASAP7_75t_R  g261(.A(new_n159_), .B(new_n195_), .Y(new_n320_));
  NOR3x1_ASAP7_75t_R  g262(.A(new_n267_), .B(new_n269_), .C(new_n313_), .Y(new_n321_));
  AO21x1_ASAP7_75t_R  g263(.A1(new_n320_), .A2(new_n321_), .B(new_n116_), .Y(new_n322_));
  OR3x1_ASAP7_75t_R   g264(.A(new_n158_), .B(new_n118_), .C(p2), .Y(new_n323_));
  NOR2x1_ASAP7_75t_R  g265(.A(new_n190_), .B(new_n194_), .Y(new_n324_));
  OA21x2_ASAP7_75t_R  g266(.A1(new_n323_), .A2(new_n314_), .B(new_n324_), .Y(new_n325_));
  NOR2x1_ASAP7_75t_R  g267(.A(new_n322_), .B(new_n325_), .Y(o17));
  NAND2x1_ASAP7_75t_R g268(.A(p29), .B(new_n60_), .Y(new_n327_));
  AND2x2_ASAP7_75t_R  g269(.A(new_n109_), .B(new_n110_), .Y(new_n328_));
  NOR2x1_ASAP7_75t_R  g270(.A(new_n327_), .B(new_n328_), .Y(new_n329_));
  AO21x1_ASAP7_75t_R  g271(.A1(new_n329_), .A2(new_n321_), .B(new_n116_), .Y(new_n330_));
  OA21x2_ASAP7_75t_R  g272(.A1(new_n327_), .A2(new_n314_), .B(new_n328_), .Y(new_n331_));
  NOR2x1_ASAP7_75t_R  g273(.A(new_n330_), .B(new_n331_), .Y(o18));
  NAND2x1_ASAP7_75t_R g274(.A(p20), .B(new_n321_), .Y(new_n333_));
  AOI21x1_ASAP7_75t_R g275(.A1(new_n139_), .A2(new_n333_), .B(new_n116_), .Y(o19));
  AO21x1_ASAP7_75t_R  g276(.A1(p12), .A2(new_n321_), .B(new_n147_), .Y(new_n335_));
  AND2x2_ASAP7_75t_R  g277(.A(new_n117_), .B(new_n335_), .Y(o20));
  NAND2x1_ASAP7_75t_R g278(.A(new_n253_), .B(new_n252_), .Y(new_n337_));
  AO21x1_ASAP7_75t_R  g279(.A1(new_n236_), .A2(new_n321_), .B(new_n337_), .Y(new_n338_));
  AND2x2_ASAP7_75t_R  g280(.A(new_n117_), .B(new_n338_), .Y(o21));
  AO21x1_ASAP7_75t_R  g281(.A1(p31), .A2(p30), .B(p1), .Y(new_n340_));
  INVx1_ASAP7_75t_R   g282(.A(new_n340_), .Y(new_n341_));
  NOR2x1_ASAP7_75t_R  g283(.A(p31), .B(p1), .Y(new_n342_));
  AO21x1_ASAP7_75t_R  g284(.A1(new_n191_), .A2(new_n192_), .B(new_n342_), .Y(new_n343_));
  INVx1_ASAP7_75t_R   g285(.A(new_n343_), .Y(new_n344_));
  OR3x1_ASAP7_75t_R   g286(.A(new_n267_), .B(new_n269_), .C(new_n274_), .Y(new_n345_));
  NAND2x1_ASAP7_75t_R g287(.A(new_n343_), .B(new_n288_), .Y(new_n346_));
  NOR3x1_ASAP7_75t_R  g288(.A(new_n346_), .B(new_n269_), .C(new_n267_), .Y(new_n347_));
  AOI21x1_ASAP7_75t_R g289(.A1(new_n344_), .A2(new_n345_), .B(new_n347_), .Y(new_n348_));
  NOR2x1_ASAP7_75t_R  g290(.A(new_n344_), .B(new_n274_), .Y(new_n349_));
  AOI21x1_ASAP7_75t_R g291(.A1(new_n349_), .A2(new_n283_), .B(new_n340_), .Y(new_n350_));
  OAI21x1_ASAP7_75t_R g292(.A1(new_n275_), .A2(new_n343_), .B(new_n350_), .Y(new_n351_));
  OAI21x1_ASAP7_75t_R g293(.A1(new_n341_), .A2(new_n348_), .B(new_n351_), .Y(o22));
  NOR2x1_ASAP7_75t_R  g294(.A(new_n126_), .B(new_n127_), .Y(new_n353_));
  XOR2x2_ASAP7_75t_R  g295(.A(new_n99_), .B(new_n353_), .Y(new_n354_));
  NOR2x1_ASAP7_75t_R  g296(.A(p28), .B(p1), .Y(new_n355_));
  XOR2x2_ASAP7_75t_R  g297(.A(new_n354_), .B(new_n355_), .Y(new_n356_));
  OA21x2_ASAP7_75t_R  g298(.A1(p1), .A2(p3), .B(new_n356_), .Y(new_n357_));
  XOR2x2_ASAP7_75t_R  g299(.A(new_n284_), .B(new_n357_), .Y(o23));
  AND3x1_ASAP7_75t_R  g300(.A(new_n206_), .B(new_n208_), .C(new_n117_), .Y(new_n359_));
  NAND2x1_ASAP7_75t_R g301(.A(new_n210_), .B(new_n321_), .Y(new_n360_));
  AND2x2_ASAP7_75t_R  g302(.A(new_n359_), .B(new_n360_), .Y(o24));
endmodule


