// Benchmark "/tmp/" written by ABC on Mon Oct 12 15:05:31 2026

module \/tmp/  ( 
    p17, p18, p9, p20, p13, p7, p5, p30, p32, p16, p0, p21, p19, p14, p12,
    p3, p26, p8, p6, p31, p15, p25, p10, p1, p29, p22, p24, p2, p28, p11,
    p4, p27, p23,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24  );
  input  p17, p18, p9, p20, p13, p7, p5, p30, p32, p16, p0, p21, p19,
    p14, p12, p3, p26, p8, p6, p31, p15, p25, p10, p1, p29, p22, p24, p2,
    p28, p11, p4, p27, p23;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24;
  wire new_n59_, new_n60_, new_n61_, new_n62_, new_n63_, new_n64_, new_n65_,
    new_n66_, new_n67_, new_n68_, new_n69_, new_n70_, new_n71_, new_n72_,
    new_n73_, new_n74_, new_n75_, new_n76_, new_n77_, new_n78_, new_n79_,
    new_n80_, new_n81_, new_n82_, new_n83_, new_n84_, new_n85_, new_n86_,
    new_n87_, new_n88_, new_n89_, new_n90_, new_n91_, new_n92_, new_n93_,
    new_n94_, new_n95_, new_n96_, new_n97_, new_n98_, new_n99_, new_n100_,
    new_n101_, new_n102_, new_n103_, new_n104_, new_n105_, new_n106_,
    new_n107_, new_n108_, new_n109_, new_n110_, new_n111_, new_n112_,
    new_n113_, new_n114_, new_n115_, new_n116_, new_n117_, new_n118_,
    new_n119_, new_n120_, new_n121_, new_n122_, new_n123_, new_n124_,
    new_n125_, new_n126_, new_n127_, new_n128_, new_n129_, new_n130_,
    new_n131_, new_n132_, new_n133_, new_n134_, new_n135_, new_n136_,
    new_n137_, new_n138_, new_n139_, new_n140_, new_n141_, new_n142_,
    new_n143_, new_n144_, new_n145_, new_n146_, new_n147_, new_n148_,
    new_n149_, new_n150_, new_n151_, new_n152_, new_n153_, new_n154_,
    new_n155_, new_n156_, new_n157_, new_n158_, new_n159_, new_n160_,
    new_n161_, new_n162_, new_n163_, new_n164_, new_n165_, new_n166_,
    new_n167_, new_n168_, new_n169_, new_n170_, new_n171_, new_n172_,
    new_n173_, new_n174_, new_n175_, new_n176_, new_n177_, new_n178_,
    new_n179_, new_n180_, new_n181_, new_n182_, new_n183_, new_n184_,
    new_n185_, new_n186_, new_n187_, new_n188_, new_n189_, new_n190_,
    new_n191_, new_n192_, new_n193_, new_n194_, new_n195_, new_n196_,
    new_n197_, new_n198_, new_n199_, new_n200_, new_n201_, new_n202_,
    new_n203_, new_n204_, new_n205_, new_n206_, new_n207_, new_n208_,
    new_n209_, new_n210_, new_n211_, new_n212_, new_n213_, new_n214_,
    new_n215_, new_n216_, new_n217_, new_n218_, new_n219_, new_n220_,
    new_n221_, new_n222_, new_n223_, new_n224_, new_n225_, new_n226_,
    new_n227_, new_n228_, new_n229_, new_n230_, new_n231_, new_n232_,
    new_n233_, new_n234_, new_n235_, new_n236_, new_n237_, new_n238_,
    new_n239_, new_n240_, new_n241_, new_n242_, new_n243_, new_n244_,
    new_n245_, new_n246_, new_n247_, new_n248_, new_n249_, new_n250_,
    new_n251_, new_n252_, new_n253_, new_n254_, new_n255_, new_n256_,
    new_n257_, new_n258_, new_n260_, new_n261_, new_n262_, new_n263_,
    new_n264_, new_n265_, new_n266_, new_n267_, new_n268_, new_n269_,
    new_n270_, new_n271_, new_n274_, new_n278_, new_n279_, new_n280_,
    new_n284_, new_n285_, new_n286_, new_n287_, new_n292_, new_n293_,
    new_n294_, new_n295_, new_n296_, new_n298_, new_n299_, new_n301_,
    new_n302_, new_n304_, new_n305_, new_n306_, new_n307_, new_n308_,
    new_n309_, new_n310_, new_n311_, new_n312_, new_n314_, new_n315_,
    new_n316_, new_n317_, new_n318_, new_n319_, new_n321_, new_n322_,
    new_n323_, new_n324_, new_n326_, new_n328_, new_n330_, new_n331_,
    new_n333_, new_n334_, new_n335_, new_n336_, new_n337_, new_n338_,
    new_n339_, new_n340_, new_n341_, new_n342_, new_n343_, new_n344_,
    new_n346_, new_n347_, new_n348_, new_n349_, new_n350_, new_n352_,
    new_n353_;
  INVx1_ASAP7_75t_R   g000(.A(p32), .Y(new_n59_));
  INVx1_ASAP7_75t_R   g001(.A(p2), .Y(new_n60_));
  INVx1_ASAP7_75t_R   g002(.A(p23), .Y(new_n61_));
  AO21x1_ASAP7_75t_R  g003(.A1(new_n59_), .A2(new_n60_), .B(new_n61_), .Y(new_n62_));
  INVx1_ASAP7_75t_R   g004(.A(new_n62_), .Y(new_n63_));
  NOR2x1_ASAP7_75t_R  g005(.A(p14), .B(p22), .Y(new_n64_));
  AND2x2_ASAP7_75t_R  g006(.A(p14), .B(p22), .Y(new_n65_));
  INVx1_ASAP7_75t_R   g007(.A(p28), .Y(new_n66_));
  NOR2x1_ASAP7_75t_R  g008(.A(p1), .B(new_n66_), .Y(new_n67_));
  OAI21x1_ASAP7_75t_R g009(.A1(new_n64_), .A2(new_n65_), .B(new_n67_), .Y(new_n68_));
  INVx1_ASAP7_75t_R   g010(.A(p1), .Y(new_n69_));
  NAND2x1_ASAP7_75t_R g011(.A(p28), .B(new_n69_), .Y(new_n70_));
  XOR2x2_ASAP7_75t_R  g012(.A(p14), .B(p22), .Y(new_n71_));
  NAND2x1_ASAP7_75t_R g013(.A(new_n70_), .B(new_n71_), .Y(new_n72_));
  NAND2x1_ASAP7_75t_R g014(.A(new_n68_), .B(new_n72_), .Y(new_n73_));
  INVx1_ASAP7_75t_R   g015(.A(p25), .Y(new_n74_));
  NOR2x1_ASAP7_75t_R  g016(.A(p19), .B(new_n74_), .Y(new_n75_));
  INVx1_ASAP7_75t_R   g017(.A(p19), .Y(new_n76_));
  NOR2x1_ASAP7_75t_R  g018(.A(p25), .B(new_n76_), .Y(new_n77_));
  OAI21x1_ASAP7_75t_R g019(.A1(new_n75_), .A2(new_n77_), .B(p7), .Y(new_n78_));
  NAND2x1_ASAP7_75t_R g020(.A(p25), .B(new_n76_), .Y(new_n79_));
  NAND2x1_ASAP7_75t_R g021(.A(p19), .B(new_n74_), .Y(new_n80_));
  INVx1_ASAP7_75t_R   g022(.A(p7), .Y(new_n81_));
  NAND3x1_ASAP7_75t_R g023(.A(new_n79_), .B(new_n80_), .C(new_n81_), .Y(new_n82_));
  NAND2x1_ASAP7_75t_R g024(.A(new_n78_), .B(new_n82_), .Y(new_n83_));
  XOR2x2_ASAP7_75t_R  g025(.A(new_n73_), .B(new_n83_), .Y(new_n84_));
  NOR2x1_ASAP7_75t_R  g026(.A(p9), .B(p8), .Y(new_n85_));
  AND2x2_ASAP7_75t_R  g027(.A(p9), .B(p8), .Y(new_n86_));
  INVx1_ASAP7_75t_R   g028(.A(p15), .Y(new_n87_));
  OAI21x1_ASAP7_75t_R g029(.A1(new_n85_), .A2(new_n86_), .B(new_n87_), .Y(new_n88_));
  OR3x1_ASAP7_75t_R   g030(.A(new_n86_), .B(new_n87_), .C(new_n85_), .Y(new_n89_));
  NAND2x1_ASAP7_75t_R g031(.A(new_n88_), .B(new_n89_), .Y(new_n90_));
  NOR2x1_ASAP7_75t_R  g032(.A(p17), .B(p10), .Y(new_n91_));
  AND2x2_ASAP7_75t_R  g033(.A(p17), .B(p10), .Y(new_n92_));
  OAI21x1_ASAP7_75t_R g034(.A1(new_n91_), .A2(new_n92_), .B(p24), .Y(new_n93_));
  OR3x1_ASAP7_75t_R   g035(.A(new_n92_), .B(p24), .C(new_n91_), .Y(new_n94_));
  NAND2x1_ASAP7_75t_R g036(.A(new_n93_), .B(new_n94_), .Y(new_n95_));
  XNOR2x2_ASAP7_75t_R g037(.A(new_n90_), .B(new_n95_), .Y(new_n96_));
  OR3x1_ASAP7_75t_R   g038(.A(new_n84_), .B(new_n96_), .C(p2), .Y(new_n97_));
  XOR2x2_ASAP7_75t_R  g039(.A(new_n90_), .B(new_n95_), .Y(new_n98_));
  NOR2x1_ASAP7_75t_R  g040(.A(p19), .B(new_n81_), .Y(new_n99_));
  AO21x1_ASAP7_75t_R  g041(.A1(p19), .A2(new_n81_), .B(new_n74_), .Y(new_n100_));
  NOR2x1_ASAP7_75t_R  g042(.A(p7), .B(new_n76_), .Y(new_n101_));
  OAI21x1_ASAP7_75t_R g043(.A1(new_n99_), .A2(new_n101_), .B(new_n74_), .Y(new_n102_));
  OAI21x1_ASAP7_75t_R g044(.A1(new_n99_), .A2(new_n100_), .B(new_n102_), .Y(new_n103_));
  XOR2x2_ASAP7_75t_R  g045(.A(new_n73_), .B(new_n103_), .Y(new_n104_));
  NOR2x1_ASAP7_75t_R  g046(.A(new_n98_), .B(new_n104_), .Y(new_n105_));
  INVx1_ASAP7_75t_R   g047(.A(p29), .Y(new_n106_));
  AOI21x1_ASAP7_75t_R g048(.A1(new_n60_), .A2(new_n105_), .B(new_n106_), .Y(new_n107_));
  NAND2x1_ASAP7_75t_R g049(.A(new_n98_), .B(new_n104_), .Y(new_n108_));
  NAND2x1_ASAP7_75t_R g050(.A(new_n96_), .B(new_n84_), .Y(new_n109_));
  NAND2x1_ASAP7_75t_R g051(.A(new_n106_), .B(new_n60_), .Y(new_n110_));
  AOI21x1_ASAP7_75t_R g052(.A1(new_n108_), .A2(new_n109_), .B(new_n110_), .Y(new_n111_));
  AO21x1_ASAP7_75t_R  g053(.A1(new_n97_), .A2(new_n107_), .B(new_n111_), .Y(new_n112_));
  NAND2x1_ASAP7_75t_R g054(.A(new_n63_), .B(new_n112_), .Y(new_n113_));
  XOR2x2_ASAP7_75t_R  g055(.A(p7), .B(p10), .Y(new_n114_));
  XOR2x2_ASAP7_75t_R  g056(.A(p5), .B(p6), .Y(new_n115_));
  XOR2x2_ASAP7_75t_R  g057(.A(new_n114_), .B(new_n115_), .Y(new_n116_));
  XOR2x2_ASAP7_75t_R  g058(.A(p9), .B(p8), .Y(new_n117_));
  NOR2x1_ASAP7_75t_R  g059(.A(p32), .B(p1), .Y(new_n118_));
  NAND2x1_ASAP7_75t_R g060(.A(p11), .B(new_n118_), .Y(new_n119_));
  XOR2x2_ASAP7_75t_R  g061(.A(new_n117_), .B(new_n119_), .Y(new_n120_));
  XOR2x2_ASAP7_75t_R  g062(.A(new_n116_), .B(new_n120_), .Y(new_n121_));
  INVx1_ASAP7_75t_R   g063(.A(p12), .Y(new_n122_));
  NAND2x1_ASAP7_75t_R g064(.A(new_n122_), .B(new_n60_), .Y(new_n123_));
  OAI21x1_ASAP7_75t_R g065(.A1(p2), .A2(new_n121_), .B(p12), .Y(new_n124_));
  OAI21x1_ASAP7_75t_R g066(.A1(new_n121_), .A2(new_n123_), .B(new_n124_), .Y(new_n125_));
  OAI21x1_ASAP7_75t_R g067(.A1(p13), .A2(p14), .B(p15), .Y(new_n126_));
  AND2x2_ASAP7_75t_R  g068(.A(p13), .B(p14), .Y(new_n127_));
  NOR2x1_ASAP7_75t_R  g069(.A(new_n126_), .B(new_n127_), .Y(new_n128_));
  NAND2x1_ASAP7_75t_R g070(.A(p13), .B(p14), .Y(new_n129_));
  OR3x1_ASAP7_75t_R   g071(.A(p13), .B(p14), .C(p15), .Y(new_n130_));
  OAI21x1_ASAP7_75t_R g072(.A1(p15), .A2(new_n129_), .B(new_n130_), .Y(new_n131_));
  NOR2x1_ASAP7_75t_R  g073(.A(new_n128_), .B(new_n131_), .Y(new_n132_));
  NOR2x1_ASAP7_75t_R  g074(.A(p0), .B(p1), .Y(new_n133_));
  NAND2x1_ASAP7_75t_R g075(.A(p16), .B(new_n133_), .Y(new_n134_));
  XOR2x2_ASAP7_75t_R  g076(.A(new_n134_), .B(p18), .Y(new_n135_));
  NAND2x1_ASAP7_75t_R g077(.A(new_n132_), .B(new_n135_), .Y(new_n136_));
  NOR2x1_ASAP7_75t_R  g078(.A(p13), .B(p14), .Y(new_n137_));
  OAI21x1_ASAP7_75t_R g079(.A1(new_n137_), .A2(new_n127_), .B(new_n87_), .Y(new_n138_));
  AO21x1_ASAP7_75t_R  g080(.A1(p13), .A2(p14), .B(new_n126_), .Y(new_n139_));
  NAND2x1_ASAP7_75t_R g081(.A(new_n138_), .B(new_n139_), .Y(new_n140_));
  INVx1_ASAP7_75t_R   g082(.A(p18), .Y(new_n141_));
  XOR2x2_ASAP7_75t_R  g083(.A(new_n134_), .B(new_n141_), .Y(new_n142_));
  NAND2x1_ASAP7_75t_R g084(.A(new_n140_), .B(new_n142_), .Y(new_n143_));
  XOR2x2_ASAP7_75t_R  g085(.A(p19), .B(p8), .Y(new_n144_));
  XOR2x2_ASAP7_75t_R  g086(.A(p17), .B(p5), .Y(new_n145_));
  XOR2x2_ASAP7_75t_R  g087(.A(new_n144_), .B(new_n145_), .Y(new_n146_));
  NAND3x1_ASAP7_75t_R g088(.A(new_n136_), .B(new_n143_), .C(new_n146_), .Y(new_n147_));
  AO21x1_ASAP7_75t_R  g089(.A1(new_n136_), .A2(new_n143_), .B(new_n146_), .Y(new_n148_));
  NAND2x1_ASAP7_75t_R g090(.A(new_n147_), .B(new_n148_), .Y(new_n149_));
  INVx1_ASAP7_75t_R   g091(.A(p20), .Y(new_n150_));
  AOI21x1_ASAP7_75t_R g092(.A1(new_n60_), .A2(new_n149_), .B(new_n150_), .Y(new_n151_));
  NOR2x1_ASAP7_75t_R  g093(.A(new_n125_), .B(new_n151_), .Y(new_n152_));
  NOR2x1_ASAP7_75t_R  g094(.A(p20), .B(p2), .Y(new_n153_));
  NAND2x1_ASAP7_75t_R g095(.A(new_n153_), .B(new_n149_), .Y(new_n154_));
  OR3x1_ASAP7_75t_R   g096(.A(p3), .B(p1), .C(p2), .Y(new_n155_));
  NOR2x1_ASAP7_75t_R  g097(.A(p1), .B(p4), .Y(new_n156_));
  INVx1_ASAP7_75t_R   g098(.A(new_n156_), .Y(new_n157_));
  AND2x2_ASAP7_75t_R  g099(.A(p0), .B(new_n59_), .Y(new_n158_));
  AO21x1_ASAP7_75t_R  g100(.A1(new_n155_), .A2(new_n157_), .B(new_n158_), .Y(new_n159_));
  INVx1_ASAP7_75t_R   g101(.A(new_n159_), .Y(new_n160_));
  AND3x1_ASAP7_75t_R  g102(.A(new_n152_), .B(new_n154_), .C(new_n160_), .Y(new_n161_));
  NAND2x1_ASAP7_75t_R g103(.A(new_n113_), .B(new_n161_), .Y(new_n162_));
  OA21x2_ASAP7_75t_R  g104(.A1(p0), .A2(p2), .B(p26), .Y(new_n163_));
  INVx1_ASAP7_75t_R   g105(.A(p6), .Y(new_n164_));
  NOR2x1_ASAP7_75t_R  g106(.A(p21), .B(new_n164_), .Y(new_n165_));
  INVx1_ASAP7_75t_R   g107(.A(p21), .Y(new_n166_));
  NOR2x1_ASAP7_75t_R  g108(.A(p6), .B(new_n166_), .Y(new_n167_));
  OAI21x1_ASAP7_75t_R g109(.A1(new_n165_), .A2(new_n167_), .B(p18), .Y(new_n168_));
  NAND2x1_ASAP7_75t_R g110(.A(p6), .B(new_n166_), .Y(new_n169_));
  NAND2x1_ASAP7_75t_R g111(.A(p21), .B(new_n164_), .Y(new_n170_));
  NAND3x1_ASAP7_75t_R g112(.A(new_n169_), .B(new_n170_), .C(new_n141_), .Y(new_n171_));
  NAND2x1_ASAP7_75t_R g113(.A(new_n168_), .B(new_n171_), .Y(new_n172_));
  NAND2x1_ASAP7_75t_R g114(.A(new_n103_), .B(new_n172_), .Y(new_n173_));
  XOR2x2_ASAP7_75t_R  g115(.A(p19), .B(p25), .Y(new_n174_));
  AND2x2_ASAP7_75t_R  g116(.A(p7), .B(new_n174_), .Y(new_n175_));
  NOR2x1_ASAP7_75t_R  g117(.A(p7), .B(new_n174_), .Y(new_n176_));
  AO21x1_ASAP7_75t_R  g118(.A1(p6), .A2(new_n166_), .B(new_n141_), .Y(new_n177_));
  OAI21x1_ASAP7_75t_R g119(.A1(new_n165_), .A2(new_n167_), .B(new_n141_), .Y(new_n178_));
  OAI21x1_ASAP7_75t_R g120(.A1(new_n167_), .A2(new_n177_), .B(new_n178_), .Y(new_n179_));
  OAI21x1_ASAP7_75t_R g121(.A1(new_n175_), .A2(new_n176_), .B(new_n179_), .Y(new_n180_));
  XNOR2x2_ASAP7_75t_R g122(.A(p5), .B(p22), .Y(new_n181_));
  NAND3x1_ASAP7_75t_R g123(.A(new_n173_), .B(new_n180_), .C(new_n181_), .Y(new_n182_));
  NOR2x1_ASAP7_75t_R  g124(.A(new_n179_), .B(new_n83_), .Y(new_n183_));
  NOR2x1_ASAP7_75t_R  g125(.A(new_n103_), .B(new_n172_), .Y(new_n184_));
  INVx1_ASAP7_75t_R   g126(.A(new_n181_), .Y(new_n185_));
  OAI21x1_ASAP7_75t_R g127(.A1(new_n183_), .A2(new_n184_), .B(new_n185_), .Y(new_n186_));
  NAND2x1_ASAP7_75t_R g128(.A(p30), .B(new_n69_), .Y(new_n187_));
  XOR2x2_ASAP7_75t_R  g129(.A(new_n187_), .B(p13), .Y(new_n188_));
  XOR2x2_ASAP7_75t_R  g130(.A(new_n90_), .B(new_n188_), .Y(new_n189_));
  AOI21x1_ASAP7_75t_R g131(.A1(new_n182_), .A2(new_n186_), .B(new_n189_), .Y(new_n190_));
  NAND3x1_ASAP7_75t_R g132(.A(new_n173_), .B(new_n180_), .C(new_n185_), .Y(new_n191_));
  OAI21x1_ASAP7_75t_R g133(.A1(new_n183_), .A2(new_n184_), .B(new_n181_), .Y(new_n192_));
  XNOR2x2_ASAP7_75t_R g134(.A(new_n188_), .B(new_n90_), .Y(new_n193_));
  AOI21x1_ASAP7_75t_R g135(.A1(new_n191_), .A2(new_n192_), .B(new_n193_), .Y(new_n194_));
  OAI21x1_ASAP7_75t_R g136(.A1(new_n190_), .A2(new_n194_), .B(new_n60_), .Y(new_n195_));
  NAND2x1_ASAP7_75t_R g137(.A(new_n163_), .B(new_n195_), .Y(new_n196_));
  INVx1_ASAP7_75t_R   g138(.A(p16), .Y(new_n197_));
  NOR2x1_ASAP7_75t_R  g139(.A(p0), .B(p2), .Y(new_n198_));
  NOR2x1_ASAP7_75t_R  g140(.A(new_n197_), .B(new_n198_), .Y(new_n199_));
  NAND2x1_ASAP7_75t_R g141(.A(p0), .B(p26), .Y(new_n200_));
  AND2x2_ASAP7_75t_R  g142(.A(new_n60_), .B(new_n200_), .Y(new_n201_));
  OAI21x1_ASAP7_75t_R g143(.A1(new_n190_), .A2(new_n194_), .B(new_n201_), .Y(new_n202_));
  AND3x1_ASAP7_75t_R  g144(.A(new_n196_), .B(new_n199_), .C(new_n202_), .Y(new_n203_));
  INVx1_ASAP7_75t_R   g145(.A(new_n203_), .Y(new_n204_));
  NAND3x1_ASAP7_75t_R g146(.A(new_n133_), .B(p26), .C(new_n74_), .Y(new_n205_));
  AO21x1_ASAP7_75t_R  g147(.A1(p26), .A2(new_n133_), .B(new_n74_), .Y(new_n206_));
  NAND2x1_ASAP7_75t_R g148(.A(new_n205_), .B(new_n206_), .Y(new_n207_));
  XOR2x2_ASAP7_75t_R  g149(.A(new_n172_), .B(new_n207_), .Y(new_n208_));
  NAND2x1_ASAP7_75t_R g150(.A(new_n96_), .B(new_n208_), .Y(new_n209_));
  XOR2x2_ASAP7_75t_R  g151(.A(new_n179_), .B(new_n207_), .Y(new_n210_));
  NAND2x1_ASAP7_75t_R g152(.A(new_n98_), .B(new_n210_), .Y(new_n211_));
  INVx1_ASAP7_75t_R   g153(.A(p27), .Y(new_n212_));
  NOR2x1_ASAP7_75t_R  g154(.A(p2), .B(new_n212_), .Y(new_n213_));
  NAND3x1_ASAP7_75t_R g155(.A(new_n209_), .B(new_n211_), .C(new_n213_), .Y(new_n214_));
  NAND3x1_ASAP7_75t_R g156(.A(new_n96_), .B(new_n210_), .C(new_n60_), .Y(new_n215_));
  NAND3x1_ASAP7_75t_R g157(.A(new_n208_), .B(new_n98_), .C(new_n60_), .Y(new_n216_));
  NAND3x1_ASAP7_75t_R g158(.A(new_n215_), .B(new_n216_), .C(new_n212_), .Y(new_n217_));
  NOR3x1_ASAP7_75t_R  g159(.A(new_n131_), .B(p22), .C(new_n128_), .Y(new_n218_));
  INVx1_ASAP7_75t_R   g160(.A(p22), .Y(new_n219_));
  AOI21x1_ASAP7_75t_R g161(.A1(new_n138_), .A2(new_n139_), .B(new_n219_), .Y(new_n220_));
  NOR2x1_ASAP7_75t_R  g162(.A(p24), .B(new_n61_), .Y(new_n221_));
  INVx1_ASAP7_75t_R   g163(.A(p24), .Y(new_n222_));
  AOI21x1_ASAP7_75t_R g164(.A1(p23), .A2(new_n118_), .B(new_n222_), .Y(new_n223_));
  AOI21x1_ASAP7_75t_R g165(.A1(new_n118_), .A2(new_n221_), .B(new_n223_), .Y(new_n224_));
  OAI21x1_ASAP7_75t_R g166(.A1(new_n218_), .A2(new_n220_), .B(new_n224_), .Y(new_n225_));
  NAND3x1_ASAP7_75t_R g167(.A(new_n139_), .B(new_n138_), .C(new_n219_), .Y(new_n226_));
  OAI21x1_ASAP7_75t_R g168(.A1(new_n128_), .A2(new_n131_), .B(p22), .Y(new_n227_));
  AO21x1_ASAP7_75t_R  g169(.A1(new_n118_), .A2(new_n221_), .B(new_n223_), .Y(new_n228_));
  NAND3x1_ASAP7_75t_R g170(.A(new_n226_), .B(new_n227_), .C(new_n228_), .Y(new_n229_));
  XOR2x2_ASAP7_75t_R  g171(.A(p9), .B(p21), .Y(new_n230_));
  INVx1_ASAP7_75t_R   g172(.A(new_n230_), .Y(new_n231_));
  NAND3x1_ASAP7_75t_R g173(.A(new_n225_), .B(new_n229_), .C(new_n231_), .Y(new_n232_));
  OA21x2_ASAP7_75t_R  g174(.A1(p32), .A2(p2), .B(p11), .Y(new_n233_));
  XNOR2x2_ASAP7_75t_R g175(.A(p22), .B(p24), .Y(new_n234_));
  AO21x1_ASAP7_75t_R  g176(.A1(p23), .A2(new_n118_), .B(new_n234_), .Y(new_n235_));
  AND3x1_ASAP7_75t_R  g177(.A(new_n59_), .B(new_n69_), .C(p23), .Y(new_n236_));
  NAND2x1_ASAP7_75t_R g178(.A(new_n236_), .B(new_n234_), .Y(new_n237_));
  NAND3x1_ASAP7_75t_R g179(.A(new_n235_), .B(new_n140_), .C(new_n237_), .Y(new_n238_));
  NOR2x1_ASAP7_75t_R  g180(.A(new_n236_), .B(new_n234_), .Y(new_n239_));
  AND3x1_ASAP7_75t_R  g181(.A(new_n234_), .B(p23), .C(new_n118_), .Y(new_n240_));
  OAI21x1_ASAP7_75t_R g182(.A1(new_n239_), .A2(new_n240_), .B(new_n132_), .Y(new_n241_));
  NAND3x1_ASAP7_75t_R g183(.A(new_n238_), .B(new_n241_), .C(new_n230_), .Y(new_n242_));
  NAND3x1_ASAP7_75t_R g184(.A(new_n232_), .B(new_n233_), .C(new_n242_), .Y(new_n243_));
  NAND3x1_ASAP7_75t_R g185(.A(new_n238_), .B(new_n241_), .C(new_n231_), .Y(new_n244_));
  NAND3x1_ASAP7_75t_R g186(.A(new_n235_), .B(new_n132_), .C(new_n237_), .Y(new_n245_));
  OAI21x1_ASAP7_75t_R g187(.A1(new_n239_), .A2(new_n240_), .B(new_n140_), .Y(new_n246_));
  NAND3x1_ASAP7_75t_R g188(.A(new_n245_), .B(new_n246_), .C(new_n230_), .Y(new_n247_));
  NOR2x1_ASAP7_75t_R  g189(.A(p2), .B(new_n233_), .Y(new_n248_));
  NAND3x1_ASAP7_75t_R g190(.A(new_n244_), .B(new_n247_), .C(new_n248_), .Y(new_n249_));
  AND2x2_ASAP7_75t_R  g191(.A(p2), .B(new_n233_), .Y(new_n250_));
  INVx1_ASAP7_75t_R   g192(.A(new_n250_), .Y(new_n251_));
  NAND3x1_ASAP7_75t_R g193(.A(new_n243_), .B(new_n249_), .C(new_n251_), .Y(new_n252_));
  AOI21x1_ASAP7_75t_R g194(.A1(new_n214_), .A2(new_n217_), .B(new_n252_), .Y(new_n253_));
  INVx1_ASAP7_75t_R   g195(.A(new_n253_), .Y(new_n254_));
  OR3x1_ASAP7_75t_R   g196(.A(new_n162_), .B(new_n204_), .C(new_n254_), .Y(new_n255_));
  AND3x1_ASAP7_75t_R  g197(.A(new_n203_), .B(new_n253_), .C(new_n113_), .Y(new_n256_));
  INVx1_ASAP7_75t_R   g198(.A(p14), .Y(new_n257_));
  AND3x1_ASAP7_75t_R  g199(.A(new_n256_), .B(new_n257_), .C(new_n161_), .Y(new_n258_));
  AOI21x1_ASAP7_75t_R g200(.A1(p14), .A2(new_n255_), .B(new_n258_), .Y(o0));
  INVx1_ASAP7_75t_R   g201(.A(new_n199_), .Y(new_n260_));
  AOI21x1_ASAP7_75t_R g202(.A1(new_n202_), .A2(new_n196_), .B(new_n260_), .Y(new_n261_));
  AOI21x1_ASAP7_75t_R g203(.A1(new_n97_), .A2(new_n107_), .B(new_n111_), .Y(new_n262_));
  OAI21x1_ASAP7_75t_R g204(.A1(new_n62_), .A2(new_n262_), .B(new_n253_), .Y(new_n263_));
  OA21x2_ASAP7_75t_R  g205(.A1(p2), .A2(new_n121_), .B(p12), .Y(new_n264_));
  NOR2x1_ASAP7_75t_R  g206(.A(new_n123_), .B(new_n121_), .Y(new_n265_));
  OR3x1_ASAP7_75t_R   g207(.A(p31), .B(p1), .C(p2), .Y(new_n266_));
  AO21x1_ASAP7_75t_R  g208(.A1(new_n266_), .A2(new_n157_), .B(new_n158_), .Y(new_n267_));
  NOR3x1_ASAP7_75t_R  g209(.A(new_n264_), .B(new_n265_), .C(new_n267_), .Y(new_n268_));
  AO21x1_ASAP7_75t_R  g210(.A1(new_n60_), .A2(new_n149_), .B(new_n150_), .Y(new_n269_));
  NAND3x1_ASAP7_75t_R g211(.A(new_n268_), .B(new_n269_), .C(new_n154_), .Y(new_n270_));
  NOR3x1_ASAP7_75t_R  g212(.A(new_n261_), .B(new_n263_), .C(new_n270_), .Y(new_n271_));
  XOR2x2_ASAP7_75t_R  g213(.A(new_n271_), .B(new_n74_), .Y(o1));
  XOR2x2_ASAP7_75t_R  g214(.A(new_n271_), .B(new_n76_), .Y(o2));
  AND3x1_ASAP7_75t_R  g215(.A(new_n256_), .B(new_n222_), .C(new_n161_), .Y(new_n274_));
  AOI21x1_ASAP7_75t_R g216(.A1(p24), .A2(new_n255_), .B(new_n274_), .Y(o3));
  XOR2x2_ASAP7_75t_R  g217(.A(new_n271_), .B(new_n81_), .Y(o4));
  XOR2x2_ASAP7_75t_R  g218(.A(new_n271_), .B(new_n219_), .Y(o5));
  NAND2x1_ASAP7_75t_R g219(.A(new_n202_), .B(new_n196_), .Y(new_n278_));
  AOI21x1_ASAP7_75t_R g220(.A1(new_n199_), .A2(new_n278_), .B(new_n263_), .Y(new_n279_));
  NAND2x1_ASAP7_75t_R g221(.A(new_n161_), .B(new_n279_), .Y(new_n280_));
  XOR2x2_ASAP7_75t_R  g222(.A(new_n280_), .B(p9), .Y(o6));
  XOR2x2_ASAP7_75t_R  g223(.A(new_n280_), .B(p8), .Y(o7));
  XOR2x2_ASAP7_75t_R  g224(.A(new_n280_), .B(p15), .Y(o8));
  AND3x1_ASAP7_75t_R  g225(.A(new_n268_), .B(new_n269_), .C(new_n154_), .Y(new_n284_));
  AND3x1_ASAP7_75t_R  g226(.A(new_n284_), .B(new_n63_), .C(new_n262_), .Y(new_n285_));
  NOR2x1_ASAP7_75t_R  g227(.A(new_n254_), .B(new_n261_), .Y(new_n286_));
  NAND2x1_ASAP7_75t_R g228(.A(new_n285_), .B(new_n286_), .Y(new_n287_));
  XOR2x2_ASAP7_75t_R  g229(.A(new_n287_), .B(p18), .Y(o9));
  XOR2x2_ASAP7_75t_R  g230(.A(new_n287_), .B(p6), .Y(o10));
  XOR2x2_ASAP7_75t_R  g231(.A(new_n287_), .B(p21), .Y(o11));
  XOR2x2_ASAP7_75t_R  g232(.A(new_n287_), .B(p5), .Y(o12));
  NOR2x1_ASAP7_75t_R  g233(.A(new_n62_), .B(new_n112_), .Y(new_n292_));
  AND3x1_ASAP7_75t_R  g234(.A(new_n286_), .B(new_n161_), .C(new_n292_), .Y(new_n293_));
  AND3x1_ASAP7_75t_R  g235(.A(new_n154_), .B(p13), .C(new_n160_), .Y(new_n294_));
  AND3x1_ASAP7_75t_R  g236(.A(new_n292_), .B(new_n152_), .C(new_n294_), .Y(new_n295_));
  NAND2x1_ASAP7_75t_R g237(.A(new_n286_), .B(new_n295_), .Y(new_n296_));
  OAI21x1_ASAP7_75t_R g238(.A1(p13), .A2(new_n293_), .B(new_n296_), .Y(o13));
  INVx1_ASAP7_75t_R   g239(.A(p17), .Y(new_n298_));
  AND3x1_ASAP7_75t_R  g240(.A(new_n256_), .B(new_n298_), .C(new_n161_), .Y(new_n299_));
  AOI21x1_ASAP7_75t_R g241(.A1(p17), .A2(new_n255_), .B(new_n299_), .Y(o14));
  INVx1_ASAP7_75t_R   g242(.A(p10), .Y(new_n301_));
  AND3x1_ASAP7_75t_R  g243(.A(new_n256_), .B(new_n301_), .C(new_n161_), .Y(new_n302_));
  AOI21x1_ASAP7_75t_R g244(.A1(p10), .A2(new_n255_), .B(new_n302_), .Y(o15));
  AND2x2_ASAP7_75t_R  g245(.A(new_n159_), .B(new_n267_), .Y(new_n304_));
  AO21x1_ASAP7_75t_R  g246(.A1(new_n153_), .A2(new_n149_), .B(new_n304_), .Y(new_n305_));
  OR3x1_ASAP7_75t_R   g247(.A(new_n305_), .B(new_n125_), .C(new_n151_), .Y(new_n306_));
  NOR3x1_ASAP7_75t_R  g248(.A(new_n261_), .B(new_n263_), .C(new_n306_), .Y(new_n307_));
  AND2x2_ASAP7_75t_R  g249(.A(p4), .B(new_n307_), .Y(new_n308_));
  INVx1_ASAP7_75t_R   g250(.A(new_n278_), .Y(new_n309_));
  AND3x1_ASAP7_75t_R  g251(.A(new_n262_), .B(new_n260_), .C(new_n62_), .Y(new_n310_));
  AND3x1_ASAP7_75t_R  g252(.A(new_n253_), .B(new_n152_), .C(new_n154_), .Y(new_n311_));
  AND3x1_ASAP7_75t_R  g253(.A(new_n309_), .B(new_n310_), .C(new_n311_), .Y(new_n312_));
  OR3x1_ASAP7_75t_R   g254(.A(new_n308_), .B(p1), .C(new_n312_), .Y(o16));
  NOR2x1_ASAP7_75t_R  g255(.A(new_n190_), .B(new_n194_), .Y(new_n314_));
  NOR2x1_ASAP7_75t_R  g256(.A(p2), .B(new_n200_), .Y(new_n315_));
  NAND2x1_ASAP7_75t_R g257(.A(new_n315_), .B(new_n307_), .Y(new_n316_));
  INVx1_ASAP7_75t_R   g258(.A(new_n202_), .Y(new_n317_));
  NOR2x1_ASAP7_75t_R  g259(.A(new_n195_), .B(new_n317_), .Y(new_n318_));
  AO21x1_ASAP7_75t_R  g260(.A1(new_n318_), .A2(new_n307_), .B(new_n156_), .Y(new_n319_));
  AOI21x1_ASAP7_75t_R g261(.A1(new_n314_), .A2(new_n316_), .B(new_n319_), .Y(o17));
  NOR2x1_ASAP7_75t_R  g262(.A(p2), .B(new_n106_), .Y(new_n321_));
  NAND2x1_ASAP7_75t_R g263(.A(new_n108_), .B(new_n109_), .Y(new_n322_));
  AO21x1_ASAP7_75t_R  g264(.A1(new_n321_), .A2(new_n307_), .B(new_n322_), .Y(new_n323_));
  NAND3x1_ASAP7_75t_R g265(.A(new_n307_), .B(new_n322_), .C(new_n321_), .Y(new_n324_));
  AND3x1_ASAP7_75t_R  g266(.A(new_n323_), .B(new_n157_), .C(new_n324_), .Y(o18));
  NAND2x1_ASAP7_75t_R g267(.A(p20), .B(new_n307_), .Y(new_n326_));
  AOI21x1_ASAP7_75t_R g268(.A1(new_n149_), .A2(new_n326_), .B(new_n156_), .Y(o19));
  AO21x1_ASAP7_75t_R  g269(.A1(p12), .A2(new_n307_), .B(new_n121_), .Y(new_n328_));
  AND2x2_ASAP7_75t_R  g270(.A(new_n157_), .B(new_n328_), .Y(o20));
  NAND2x1_ASAP7_75t_R g271(.A(new_n247_), .B(new_n244_), .Y(new_n330_));
  AO21x1_ASAP7_75t_R  g272(.A1(new_n233_), .A2(new_n307_), .B(new_n330_), .Y(new_n331_));
  AND2x2_ASAP7_75t_R  g273(.A(new_n157_), .B(new_n331_), .Y(o21));
  AO21x1_ASAP7_75t_R  g274(.A1(p30), .A2(p31), .B(p1), .Y(new_n333_));
  INVx1_ASAP7_75t_R   g275(.A(new_n333_), .Y(new_n334_));
  OR3x1_ASAP7_75t_R   g276(.A(new_n261_), .B(new_n263_), .C(new_n270_), .Y(new_n335_));
  NOR2x1_ASAP7_75t_R  g277(.A(p31), .B(p1), .Y(new_n336_));
  AO21x1_ASAP7_75t_R  g278(.A1(new_n191_), .A2(new_n192_), .B(new_n336_), .Y(new_n337_));
  INVx1_ASAP7_75t_R   g279(.A(new_n337_), .Y(new_n338_));
  NAND2x1_ASAP7_75t_R g280(.A(new_n337_), .B(new_n284_), .Y(new_n339_));
  NOR3x1_ASAP7_75t_R  g281(.A(new_n339_), .B(new_n263_), .C(new_n261_), .Y(new_n340_));
  AOI21x1_ASAP7_75t_R g282(.A1(new_n335_), .A2(new_n338_), .B(new_n340_), .Y(new_n341_));
  NOR2x1_ASAP7_75t_R  g283(.A(new_n338_), .B(new_n270_), .Y(new_n342_));
  AOI21x1_ASAP7_75t_R g284(.A1(new_n342_), .A2(new_n279_), .B(new_n333_), .Y(new_n343_));
  OAI21x1_ASAP7_75t_R g285(.A1(new_n271_), .A2(new_n337_), .B(new_n343_), .Y(new_n344_));
  OAI21x1_ASAP7_75t_R g286(.A1(new_n334_), .A2(new_n341_), .B(new_n344_), .Y(o22));
  NOR2x1_ASAP7_75t_R  g287(.A(new_n137_), .B(new_n127_), .Y(new_n346_));
  XOR2x2_ASAP7_75t_R  g288(.A(new_n98_), .B(new_n346_), .Y(new_n347_));
  NOR2x1_ASAP7_75t_R  g289(.A(p1), .B(p28), .Y(new_n348_));
  XOR2x2_ASAP7_75t_R  g290(.A(new_n347_), .B(new_n348_), .Y(new_n349_));
  OA21x2_ASAP7_75t_R  g291(.A1(p3), .A2(p1), .B(new_n349_), .Y(new_n350_));
  XOR2x2_ASAP7_75t_R  g292(.A(new_n280_), .B(new_n350_), .Y(o23));
  AND3x1_ASAP7_75t_R  g293(.A(new_n209_), .B(new_n211_), .C(new_n157_), .Y(new_n352_));
  NAND2x1_ASAP7_75t_R g294(.A(new_n213_), .B(new_n307_), .Y(new_n353_));
  AND2x2_ASAP7_75t_R  g295(.A(new_n352_), .B(new_n353_), .Y(o24));
endmodule


