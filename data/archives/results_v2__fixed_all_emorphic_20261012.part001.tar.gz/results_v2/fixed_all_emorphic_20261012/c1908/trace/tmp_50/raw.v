// Benchmark "/tmp/" written by ABC on Mon Oct 12 15:05:31 2026

module \/tmp/  ( 
    p28, p26, p16, p4, p20, p10, p9, p15, p14, p24, p30, p31, p8, p23, p29,
    p5, p25, p18, p0, p32, p11, p13, p27, p12, p22, p21, p3, p2, p1, p19,
    p17, p7, p6,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24  );
  input  p28, p26, p16, p4, p20, p10, p9, p15, p14, p24, p30, p31, p8,
    p23, p29, p5, p25, p18, p0, p32, p11, p13, p27, p12, p22, p21, p3, p2,
    p1, p19, p17, p7, p6;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24;
  wire new_n59_, new_n60_, new_n61_, new_n62_, new_n63_, new_n64_, new_n65_,
    new_n66_, new_n67_, new_n68_, new_n69_, new_n70_, new_n71_, new_n72_,
    new_n73_, new_n74_, new_n75_, new_n76_, new_n77_, new_n78_, new_n79_,
    new_n80_, new_n81_, new_n82_, new_n83_, new_n84_, new_n85_, new_n86_,
    new_n87_, new_n88_, new_n89_, new_n90_, new_n91_, new_n92_, new_n93_,
    new_n94_, new_n95_, new_n96_, new_n97_, new_n98_, new_n99_, new_n100_,
    new_n101_, new_n102_, new_n103_, new_n104_, new_n105_, new_n106_,
    new_n107_, new_n108_, new_n109_, new_n110_, new_n111_, new_n112_,
    new_n113_, new_n114_, new_n115_, new_n116_, new_n117_, new_n118_,
    new_n119_, new_n120_, new_n121_, new_n122_, new_n123_, new_n124_,
    new_n125_, new_n126_, new_n127_, new_n128_, new_n129_, new_n130_,
    new_n131_, new_n132_, new_n133_, new_n134_, new_n135_, new_n136_,
    new_n137_, new_n138_, new_n139_, new_n140_, new_n141_, new_n142_,
    new_n143_, new_n144_, new_n145_, new_n146_, new_n147_, new_n148_,
    new_n149_, new_n150_, new_n151_, new_n152_, new_n153_, new_n154_,
    new_n155_, new_n156_, new_n157_, new_n158_, new_n159_, new_n160_,
    new_n161_, new_n162_, new_n163_, new_n164_, new_n165_, new_n166_,
    new_n167_, new_n168_, new_n169_, new_n170_, new_n171_, new_n172_,
    new_n173_, new_n174_, new_n175_, new_n176_, new_n177_, new_n178_,
    new_n179_, new_n180_, new_n181_, new_n182_, new_n183_, new_n184_,
    new_n185_, new_n186_, new_n187_, new_n188_, new_n189_, new_n190_,
    new_n191_, new_n192_, new_n193_, new_n194_, new_n195_, new_n196_,
    new_n197_, new_n198_, new_n199_, new_n200_, new_n201_, new_n202_,
    new_n203_, new_n204_, new_n205_, new_n206_, new_n207_, new_n208_,
    new_n209_, new_n210_, new_n211_, new_n212_, new_n213_, new_n214_,
    new_n215_, new_n216_, new_n217_, new_n218_, new_n219_, new_n220_,
    new_n221_, new_n222_, new_n223_, new_n224_, new_n225_, new_n226_,
    new_n227_, new_n228_, new_n229_, new_n230_, new_n231_, new_n232_,
    new_n233_, new_n234_, new_n235_, new_n236_, new_n237_, new_n238_,
    new_n239_, new_n240_, new_n241_, new_n242_, new_n243_, new_n244_,
    new_n245_, new_n246_, new_n247_, new_n248_, new_n249_, new_n250_,
    new_n251_, new_n252_, new_n253_, new_n254_, new_n255_, new_n256_,
    new_n257_, new_n258_, new_n259_, new_n261_, new_n262_, new_n263_,
    new_n264_, new_n265_, new_n266_, new_n267_, new_n268_, new_n269_,
    new_n270_, new_n271_, new_n272_, new_n275_, new_n279_, new_n280_,
    new_n281_, new_n285_, new_n286_, new_n287_, new_n288_, new_n289_,
    new_n290_, new_n291_, new_n292_, new_n293_, new_n294_, new_n296_,
    new_n297_, new_n299_, new_n300_, new_n302_, new_n303_, new_n305_,
    new_n306_, new_n307_, new_n308_, new_n309_, new_n311_, new_n312_,
    new_n314_, new_n315_, new_n317_, new_n318_, new_n319_, new_n320_,
    new_n321_, new_n322_, new_n323_, new_n324_, new_n326_, new_n327_,
    new_n328_, new_n329_, new_n330_, new_n331_, new_n333_, new_n334_,
    new_n335_, new_n336_, new_n337_, new_n339_, new_n341_, new_n343_,
    new_n344_, new_n346_, new_n347_, new_n348_, new_n349_, new_n350_,
    new_n351_, new_n352_, new_n353_, new_n354_, new_n355_, new_n356_,
    new_n358_, new_n359_, new_n360_, new_n361_, new_n362_, new_n364_,
    new_n365_;
  INVx1_ASAP7_75t_R   g000(.A(p0), .Y(new_n59_));
  INVx1_ASAP7_75t_R   g001(.A(p2), .Y(new_n60_));
  INVx1_ASAP7_75t_R   g002(.A(p26), .Y(new_n61_));
  AO21x1_ASAP7_75t_R  g003(.A1(new_n59_), .A2(new_n60_), .B(new_n61_), .Y(new_n62_));
  INVx1_ASAP7_75t_R   g004(.A(new_n62_), .Y(new_n63_));
  INVx1_ASAP7_75t_R   g005(.A(p7), .Y(new_n64_));
  NOR2x1_ASAP7_75t_R  g006(.A(p19), .B(new_n64_), .Y(new_n65_));
  INVx1_ASAP7_75t_R   g007(.A(p25), .Y(new_n66_));
  AO21x1_ASAP7_75t_R  g008(.A1(p19), .A2(new_n64_), .B(new_n66_), .Y(new_n67_));
  INVx1_ASAP7_75t_R   g009(.A(p19), .Y(new_n68_));
  NOR2x1_ASAP7_75t_R  g010(.A(p7), .B(new_n68_), .Y(new_n69_));
  OAI21x1_ASAP7_75t_R g011(.A1(new_n65_), .A2(new_n69_), .B(new_n66_), .Y(new_n70_));
  OAI21x1_ASAP7_75t_R g012(.A1(new_n65_), .A2(new_n67_), .B(new_n70_), .Y(new_n71_));
  INVx1_ASAP7_75t_R   g013(.A(p6), .Y(new_n72_));
  NOR2x1_ASAP7_75t_R  g014(.A(p21), .B(new_n72_), .Y(new_n73_));
  INVx1_ASAP7_75t_R   g015(.A(p21), .Y(new_n74_));
  NOR2x1_ASAP7_75t_R  g016(.A(p6), .B(new_n74_), .Y(new_n75_));
  OAI21x1_ASAP7_75t_R g017(.A1(new_n73_), .A2(new_n75_), .B(p18), .Y(new_n76_));
  NAND2x1_ASAP7_75t_R g018(.A(p6), .B(new_n74_), .Y(new_n77_));
  NAND2x1_ASAP7_75t_R g019(.A(p21), .B(new_n72_), .Y(new_n78_));
  INVx1_ASAP7_75t_R   g020(.A(p18), .Y(new_n79_));
  NAND3x1_ASAP7_75t_R g021(.A(new_n77_), .B(new_n78_), .C(new_n79_), .Y(new_n80_));
  NAND2x1_ASAP7_75t_R g022(.A(new_n76_), .B(new_n80_), .Y(new_n81_));
  NAND2x1_ASAP7_75t_R g023(.A(new_n71_), .B(new_n81_), .Y(new_n82_));
  XOR2x2_ASAP7_75t_R  g024(.A(p19), .B(p7), .Y(new_n83_));
  AND2x2_ASAP7_75t_R  g025(.A(p25), .B(new_n83_), .Y(new_n84_));
  NOR2x1_ASAP7_75t_R  g026(.A(p25), .B(new_n83_), .Y(new_n85_));
  AO21x1_ASAP7_75t_R  g027(.A1(p6), .A2(new_n74_), .B(new_n79_), .Y(new_n86_));
  OAI21x1_ASAP7_75t_R g028(.A1(new_n73_), .A2(new_n75_), .B(new_n79_), .Y(new_n87_));
  OAI21x1_ASAP7_75t_R g029(.A1(new_n75_), .A2(new_n86_), .B(new_n87_), .Y(new_n88_));
  OAI21x1_ASAP7_75t_R g030(.A1(new_n84_), .A2(new_n85_), .B(new_n88_), .Y(new_n89_));
  XNOR2x2_ASAP7_75t_R g031(.A(p5), .B(p22), .Y(new_n90_));
  NAND3x1_ASAP7_75t_R g032(.A(new_n82_), .B(new_n89_), .C(new_n90_), .Y(new_n91_));
  OAI21x1_ASAP7_75t_R g033(.A1(new_n65_), .A2(new_n69_), .B(p25), .Y(new_n92_));
  NAND2x1_ASAP7_75t_R g034(.A(p7), .B(new_n68_), .Y(new_n93_));
  NAND2x1_ASAP7_75t_R g035(.A(p19), .B(new_n64_), .Y(new_n94_));
  NAND3x1_ASAP7_75t_R g036(.A(new_n93_), .B(new_n94_), .C(new_n66_), .Y(new_n95_));
  NAND2x1_ASAP7_75t_R g037(.A(new_n92_), .B(new_n95_), .Y(new_n96_));
  NOR2x1_ASAP7_75t_R  g038(.A(new_n88_), .B(new_n96_), .Y(new_n97_));
  NOR2x1_ASAP7_75t_R  g039(.A(new_n71_), .B(new_n81_), .Y(new_n98_));
  INVx1_ASAP7_75t_R   g040(.A(new_n90_), .Y(new_n99_));
  OAI21x1_ASAP7_75t_R g041(.A1(new_n97_), .A2(new_n98_), .B(new_n99_), .Y(new_n100_));
  NOR2x1_ASAP7_75t_R  g042(.A(p9), .B(p8), .Y(new_n101_));
  AND2x2_ASAP7_75t_R  g043(.A(p9), .B(p8), .Y(new_n102_));
  INVx1_ASAP7_75t_R   g044(.A(p15), .Y(new_n103_));
  OAI21x1_ASAP7_75t_R g045(.A1(new_n101_), .A2(new_n102_), .B(new_n103_), .Y(new_n104_));
  OR3x1_ASAP7_75t_R   g046(.A(new_n102_), .B(new_n103_), .C(new_n101_), .Y(new_n105_));
  NAND2x1_ASAP7_75t_R g047(.A(new_n104_), .B(new_n105_), .Y(new_n106_));
  INVx1_ASAP7_75t_R   g048(.A(p1), .Y(new_n107_));
  NAND2x1_ASAP7_75t_R g049(.A(p30), .B(new_n107_), .Y(new_n108_));
  XOR2x2_ASAP7_75t_R  g050(.A(new_n108_), .B(p13), .Y(new_n109_));
  XOR2x2_ASAP7_75t_R  g051(.A(new_n106_), .B(new_n109_), .Y(new_n110_));
  AOI21x1_ASAP7_75t_R g052(.A1(new_n91_), .A2(new_n100_), .B(new_n110_), .Y(new_n111_));
  NAND3x1_ASAP7_75t_R g053(.A(new_n82_), .B(new_n89_), .C(new_n99_), .Y(new_n112_));
  OAI21x1_ASAP7_75t_R g054(.A1(new_n97_), .A2(new_n98_), .B(new_n90_), .Y(new_n113_));
  OAI21x1_ASAP7_75t_R g055(.A1(new_n101_), .A2(new_n102_), .B(p15), .Y(new_n114_));
  OR3x1_ASAP7_75t_R   g056(.A(new_n102_), .B(p15), .C(new_n101_), .Y(new_n115_));
  NAND2x1_ASAP7_75t_R g057(.A(new_n114_), .B(new_n115_), .Y(new_n116_));
  XOR2x2_ASAP7_75t_R  g058(.A(new_n116_), .B(new_n109_), .Y(new_n117_));
  AOI21x1_ASAP7_75t_R g059(.A1(new_n112_), .A2(new_n113_), .B(new_n117_), .Y(new_n118_));
  OAI21x1_ASAP7_75t_R g060(.A1(new_n111_), .A2(new_n118_), .B(new_n60_), .Y(new_n119_));
  NAND2x1_ASAP7_75t_R g061(.A(new_n63_), .B(new_n119_), .Y(new_n120_));
  OA21x2_ASAP7_75t_R  g062(.A1(p0), .A2(p2), .B(p16), .Y(new_n121_));
  OA21x2_ASAP7_75t_R  g063(.A1(new_n61_), .A2(new_n59_), .B(new_n60_), .Y(new_n122_));
  OAI21x1_ASAP7_75t_R g064(.A1(new_n111_), .A2(new_n118_), .B(new_n122_), .Y(new_n123_));
  AND3x1_ASAP7_75t_R  g065(.A(new_n120_), .B(new_n121_), .C(new_n123_), .Y(new_n124_));
  INVx1_ASAP7_75t_R   g066(.A(new_n124_), .Y(new_n125_));
  NOR2x1_ASAP7_75t_R  g067(.A(p20), .B(p2), .Y(new_n126_));
  OAI21x1_ASAP7_75t_R g068(.A1(p14), .A2(p13), .B(p15), .Y(new_n127_));
  AND2x2_ASAP7_75t_R  g069(.A(p14), .B(p13), .Y(new_n128_));
  NOR2x1_ASAP7_75t_R  g070(.A(new_n127_), .B(new_n128_), .Y(new_n129_));
  NAND2x1_ASAP7_75t_R g071(.A(p14), .B(p13), .Y(new_n130_));
  OR3x1_ASAP7_75t_R   g072(.A(p15), .B(p14), .C(p13), .Y(new_n131_));
  OAI21x1_ASAP7_75t_R g073(.A1(p15), .A2(new_n130_), .B(new_n131_), .Y(new_n132_));
  NOR2x1_ASAP7_75t_R  g074(.A(new_n129_), .B(new_n132_), .Y(new_n133_));
  AND3x1_ASAP7_75t_R  g075(.A(new_n59_), .B(new_n107_), .C(p16), .Y(new_n134_));
  INVx1_ASAP7_75t_R   g076(.A(p5), .Y(new_n135_));
  XOR2x2_ASAP7_75t_R  g077(.A(new_n134_), .B(new_n135_), .Y(new_n136_));
  NAND2x1_ASAP7_75t_R g078(.A(new_n133_), .B(new_n136_), .Y(new_n137_));
  NOR2x1_ASAP7_75t_R  g079(.A(p14), .B(p13), .Y(new_n138_));
  OAI21x1_ASAP7_75t_R g080(.A1(new_n138_), .A2(new_n128_), .B(new_n103_), .Y(new_n139_));
  AO21x1_ASAP7_75t_R  g081(.A1(p14), .A2(p13), .B(new_n127_), .Y(new_n140_));
  NAND2x1_ASAP7_75t_R g082(.A(new_n139_), .B(new_n140_), .Y(new_n141_));
  XOR2x2_ASAP7_75t_R  g083(.A(new_n134_), .B(p5), .Y(new_n142_));
  NAND2x1_ASAP7_75t_R g084(.A(new_n141_), .B(new_n142_), .Y(new_n143_));
  XNOR2x2_ASAP7_75t_R g085(.A(p19), .B(p17), .Y(new_n144_));
  XOR2x2_ASAP7_75t_R  g086(.A(p8), .B(p18), .Y(new_n145_));
  XOR2x2_ASAP7_75t_R  g087(.A(new_n144_), .B(new_n145_), .Y(new_n146_));
  AOI21x1_ASAP7_75t_R g088(.A1(new_n137_), .A2(new_n143_), .B(new_n146_), .Y(new_n147_));
  AND3x1_ASAP7_75t_R  g089(.A(new_n137_), .B(new_n143_), .C(new_n146_), .Y(new_n148_));
  NOR2x1_ASAP7_75t_R  g090(.A(new_n147_), .B(new_n148_), .Y(new_n149_));
  OR3x1_ASAP7_75t_R   g091(.A(p3), .B(p2), .C(p1), .Y(new_n150_));
  NOR2x1_ASAP7_75t_R  g092(.A(p4), .B(p1), .Y(new_n151_));
  INVx1_ASAP7_75t_R   g093(.A(new_n151_), .Y(new_n152_));
  NOR2x1_ASAP7_75t_R  g094(.A(p32), .B(new_n59_), .Y(new_n153_));
  AO21x1_ASAP7_75t_R  g095(.A1(new_n150_), .A2(new_n152_), .B(new_n153_), .Y(new_n154_));
  AO21x1_ASAP7_75t_R  g096(.A1(new_n126_), .A2(new_n149_), .B(new_n154_), .Y(new_n155_));
  NOR2x1_ASAP7_75t_R  g097(.A(new_n101_), .B(new_n102_), .Y(new_n156_));
  INVx1_ASAP7_75t_R   g098(.A(p32), .Y(new_n157_));
  AND3x1_ASAP7_75t_R  g099(.A(new_n157_), .B(new_n107_), .C(p11), .Y(new_n158_));
  XOR2x2_ASAP7_75t_R  g100(.A(new_n156_), .B(new_n158_), .Y(new_n159_));
  XNOR2x2_ASAP7_75t_R g101(.A(p10), .B(p7), .Y(new_n160_));
  XOR2x2_ASAP7_75t_R  g102(.A(p5), .B(p6), .Y(new_n161_));
  XOR2x2_ASAP7_75t_R  g103(.A(new_n160_), .B(new_n161_), .Y(new_n162_));
  XOR2x2_ASAP7_75t_R  g104(.A(new_n159_), .B(new_n162_), .Y(new_n163_));
  INVx1_ASAP7_75t_R   g105(.A(p12), .Y(new_n164_));
  NAND2x1_ASAP7_75t_R g106(.A(new_n164_), .B(new_n60_), .Y(new_n165_));
  OAI21x1_ASAP7_75t_R g107(.A1(p2), .A2(new_n163_), .B(p12), .Y(new_n166_));
  OAI21x1_ASAP7_75t_R g108(.A1(new_n163_), .A2(new_n165_), .B(new_n166_), .Y(new_n167_));
  INVx1_ASAP7_75t_R   g109(.A(p20), .Y(new_n168_));
  AOI21x1_ASAP7_75t_R g110(.A1(new_n60_), .A2(new_n149_), .B(new_n168_), .Y(new_n169_));
  NOR3x1_ASAP7_75t_R  g111(.A(new_n155_), .B(new_n167_), .C(new_n169_), .Y(new_n170_));
  INVx1_ASAP7_75t_R   g112(.A(p23), .Y(new_n171_));
  AO21x1_ASAP7_75t_R  g113(.A1(new_n157_), .A2(new_n60_), .B(new_n171_), .Y(new_n172_));
  INVx1_ASAP7_75t_R   g114(.A(new_n172_), .Y(new_n173_));
  XOR2x2_ASAP7_75t_R  g115(.A(p14), .B(p22), .Y(new_n174_));
  NAND2x1_ASAP7_75t_R g116(.A(p28), .B(new_n107_), .Y(new_n175_));
  XOR2x2_ASAP7_75t_R  g117(.A(new_n174_), .B(new_n175_), .Y(new_n176_));
  NAND2x1_ASAP7_75t_R g118(.A(new_n96_), .B(new_n176_), .Y(new_n177_));
  INVx1_ASAP7_75t_R   g119(.A(p28), .Y(new_n178_));
  NOR2x1_ASAP7_75t_R  g120(.A(p1), .B(new_n178_), .Y(new_n179_));
  XOR2x2_ASAP7_75t_R  g121(.A(new_n174_), .B(new_n179_), .Y(new_n180_));
  NAND2x1_ASAP7_75t_R g122(.A(new_n71_), .B(new_n180_), .Y(new_n181_));
  NOR2x1_ASAP7_75t_R  g123(.A(p10), .B(p24), .Y(new_n182_));
  AND2x2_ASAP7_75t_R  g124(.A(p10), .B(p24), .Y(new_n183_));
  OAI21x1_ASAP7_75t_R g125(.A1(new_n182_), .A2(new_n183_), .B(p17), .Y(new_n184_));
  OR3x1_ASAP7_75t_R   g126(.A(new_n183_), .B(p17), .C(new_n182_), .Y(new_n185_));
  NAND2x1_ASAP7_75t_R g127(.A(new_n184_), .B(new_n185_), .Y(new_n186_));
  XOR2x2_ASAP7_75t_R  g128(.A(new_n106_), .B(new_n186_), .Y(new_n187_));
  AOI21x1_ASAP7_75t_R g129(.A1(new_n177_), .A2(new_n181_), .B(new_n187_), .Y(new_n188_));
  INVx1_ASAP7_75t_R   g130(.A(p29), .Y(new_n189_));
  AOI21x1_ASAP7_75t_R g131(.A1(new_n60_), .A2(new_n188_), .B(new_n189_), .Y(new_n190_));
  NAND2x1_ASAP7_75t_R g132(.A(new_n177_), .B(new_n181_), .Y(new_n191_));
  XOR2x2_ASAP7_75t_R  g133(.A(new_n116_), .B(new_n186_), .Y(new_n192_));
  OR3x1_ASAP7_75t_R   g134(.A(new_n191_), .B(p2), .C(new_n192_), .Y(new_n193_));
  NAND3x1_ASAP7_75t_R g135(.A(new_n187_), .B(new_n177_), .C(new_n181_), .Y(new_n194_));
  NAND2x1_ASAP7_75t_R g136(.A(new_n192_), .B(new_n191_), .Y(new_n195_));
  NAND2x1_ASAP7_75t_R g137(.A(new_n189_), .B(new_n60_), .Y(new_n196_));
  AOI21x1_ASAP7_75t_R g138(.A1(new_n194_), .A2(new_n195_), .B(new_n196_), .Y(new_n197_));
  AO21x1_ASAP7_75t_R  g139(.A1(new_n190_), .A2(new_n193_), .B(new_n197_), .Y(new_n198_));
  NAND2x1_ASAP7_75t_R g140(.A(new_n173_), .B(new_n198_), .Y(new_n199_));
  NAND2x1_ASAP7_75t_R g141(.A(new_n170_), .B(new_n199_), .Y(new_n200_));
  NOR2x1_ASAP7_75t_R  g142(.A(p0), .B(p1), .Y(new_n201_));
  NAND3x1_ASAP7_75t_R g143(.A(new_n201_), .B(p26), .C(new_n66_), .Y(new_n202_));
  AO21x1_ASAP7_75t_R  g144(.A1(p26), .A2(new_n201_), .B(new_n66_), .Y(new_n203_));
  AND2x2_ASAP7_75t_R  g145(.A(new_n202_), .B(new_n203_), .Y(new_n204_));
  XOR2x2_ASAP7_75t_R  g146(.A(new_n81_), .B(new_n204_), .Y(new_n205_));
  NAND2x1_ASAP7_75t_R g147(.A(new_n187_), .B(new_n205_), .Y(new_n206_));
  XOR2x2_ASAP7_75t_R  g148(.A(new_n88_), .B(new_n204_), .Y(new_n207_));
  NAND2x1_ASAP7_75t_R g149(.A(new_n192_), .B(new_n207_), .Y(new_n208_));
  INVx1_ASAP7_75t_R   g150(.A(p27), .Y(new_n209_));
  NOR2x1_ASAP7_75t_R  g151(.A(p2), .B(new_n209_), .Y(new_n210_));
  NAND3x1_ASAP7_75t_R g152(.A(new_n206_), .B(new_n208_), .C(new_n210_), .Y(new_n211_));
  NAND3x1_ASAP7_75t_R g153(.A(new_n205_), .B(new_n192_), .C(new_n60_), .Y(new_n212_));
  NAND3x1_ASAP7_75t_R g154(.A(new_n207_), .B(new_n187_), .C(new_n60_), .Y(new_n213_));
  NAND3x1_ASAP7_75t_R g155(.A(new_n212_), .B(new_n213_), .C(new_n209_), .Y(new_n214_));
  NOR3x1_ASAP7_75t_R  g156(.A(new_n132_), .B(p22), .C(new_n129_), .Y(new_n215_));
  INVx1_ASAP7_75t_R   g157(.A(p22), .Y(new_n216_));
  AOI21x1_ASAP7_75t_R g158(.A1(new_n139_), .A2(new_n140_), .B(new_n216_), .Y(new_n217_));
  NOR2x1_ASAP7_75t_R  g159(.A(p32), .B(p1), .Y(new_n218_));
  NOR2x1_ASAP7_75t_R  g160(.A(p24), .B(new_n171_), .Y(new_n219_));
  INVx1_ASAP7_75t_R   g161(.A(p24), .Y(new_n220_));
  AOI21x1_ASAP7_75t_R g162(.A1(p23), .A2(new_n218_), .B(new_n220_), .Y(new_n221_));
  AOI21x1_ASAP7_75t_R g163(.A1(new_n218_), .A2(new_n219_), .B(new_n221_), .Y(new_n222_));
  OAI21x1_ASAP7_75t_R g164(.A1(new_n215_), .A2(new_n217_), .B(new_n222_), .Y(new_n223_));
  NAND3x1_ASAP7_75t_R g165(.A(new_n140_), .B(new_n139_), .C(new_n216_), .Y(new_n224_));
  OAI21x1_ASAP7_75t_R g166(.A1(new_n129_), .A2(new_n132_), .B(p22), .Y(new_n225_));
  AO21x1_ASAP7_75t_R  g167(.A1(new_n218_), .A2(new_n219_), .B(new_n221_), .Y(new_n226_));
  NAND3x1_ASAP7_75t_R g168(.A(new_n224_), .B(new_n225_), .C(new_n226_), .Y(new_n227_));
  XNOR2x2_ASAP7_75t_R g169(.A(p9), .B(p21), .Y(new_n228_));
  NAND3x1_ASAP7_75t_R g170(.A(new_n223_), .B(new_n227_), .C(new_n228_), .Y(new_n229_));
  INVx1_ASAP7_75t_R   g171(.A(p11), .Y(new_n230_));
  AO21x1_ASAP7_75t_R  g172(.A1(new_n157_), .A2(new_n60_), .B(new_n230_), .Y(new_n231_));
  INVx1_ASAP7_75t_R   g173(.A(new_n231_), .Y(new_n232_));
  NAND2x1_ASAP7_75t_R g174(.A(p23), .B(new_n218_), .Y(new_n233_));
  XOR2x2_ASAP7_75t_R  g175(.A(p24), .B(p22), .Y(new_n234_));
  NAND2x1_ASAP7_75t_R g176(.A(new_n233_), .B(new_n234_), .Y(new_n235_));
  INVx1_ASAP7_75t_R   g177(.A(new_n218_), .Y(new_n236_));
  OR3x1_ASAP7_75t_R   g178(.A(new_n234_), .B(new_n171_), .C(new_n236_), .Y(new_n237_));
  AOI21x1_ASAP7_75t_R g179(.A1(new_n235_), .A2(new_n237_), .B(new_n133_), .Y(new_n238_));
  NOR2x1_ASAP7_75t_R  g180(.A(new_n233_), .B(new_n234_), .Y(new_n239_));
  AND2x2_ASAP7_75t_R  g181(.A(new_n233_), .B(new_n234_), .Y(new_n240_));
  NOR3x1_ASAP7_75t_R  g182(.A(new_n141_), .B(new_n239_), .C(new_n240_), .Y(new_n241_));
  INVx1_ASAP7_75t_R   g183(.A(new_n228_), .Y(new_n242_));
  OAI21x1_ASAP7_75t_R g184(.A1(new_n238_), .A2(new_n241_), .B(new_n242_), .Y(new_n243_));
  NAND3x1_ASAP7_75t_R g185(.A(new_n229_), .B(new_n232_), .C(new_n243_), .Y(new_n244_));
  OAI21x1_ASAP7_75t_R g186(.A1(new_n239_), .A2(new_n240_), .B(new_n141_), .Y(new_n245_));
  NAND3x1_ASAP7_75t_R g187(.A(new_n133_), .B(new_n237_), .C(new_n235_), .Y(new_n246_));
  AO21x1_ASAP7_75t_R  g188(.A1(new_n245_), .A2(new_n246_), .B(new_n242_), .Y(new_n247_));
  NAND3x1_ASAP7_75t_R g189(.A(new_n246_), .B(new_n245_), .C(new_n242_), .Y(new_n248_));
  AND2x2_ASAP7_75t_R  g190(.A(new_n60_), .B(new_n231_), .Y(new_n249_));
  NAND3x1_ASAP7_75t_R g191(.A(new_n247_), .B(new_n248_), .C(new_n249_), .Y(new_n250_));
  NOR2x1_ASAP7_75t_R  g192(.A(new_n60_), .B(new_n231_), .Y(new_n251_));
  INVx1_ASAP7_75t_R   g193(.A(new_n251_), .Y(new_n252_));
  NAND3x1_ASAP7_75t_R g194(.A(new_n244_), .B(new_n250_), .C(new_n252_), .Y(new_n253_));
  AOI21x1_ASAP7_75t_R g195(.A1(new_n211_), .A2(new_n214_), .B(new_n253_), .Y(new_n254_));
  INVx1_ASAP7_75t_R   g196(.A(new_n254_), .Y(new_n255_));
  OR3x1_ASAP7_75t_R   g197(.A(new_n125_), .B(new_n200_), .C(new_n255_), .Y(new_n256_));
  AND3x1_ASAP7_75t_R  g198(.A(new_n124_), .B(new_n254_), .C(new_n199_), .Y(new_n257_));
  INVx1_ASAP7_75t_R   g199(.A(p14), .Y(new_n258_));
  AND3x1_ASAP7_75t_R  g200(.A(new_n257_), .B(new_n258_), .C(new_n170_), .Y(new_n259_));
  AOI21x1_ASAP7_75t_R g201(.A1(p14), .A2(new_n256_), .B(new_n259_), .Y(o0));
  OR3x1_ASAP7_75t_R   g202(.A(new_n153_), .B(p4), .C(p1), .Y(new_n261_));
  NOR2x1_ASAP7_75t_R  g203(.A(p31), .B(p1), .Y(new_n262_));
  INVx1_ASAP7_75t_R   g204(.A(new_n262_), .Y(new_n263_));
  OR3x1_ASAP7_75t_R   g205(.A(new_n263_), .B(new_n153_), .C(p2), .Y(new_n264_));
  AOI21x1_ASAP7_75t_R g206(.A1(new_n261_), .A2(new_n264_), .B(new_n167_), .Y(new_n265_));
  AOI21x1_ASAP7_75t_R g207(.A1(new_n149_), .A2(new_n126_), .B(new_n169_), .Y(new_n266_));
  NAND2x1_ASAP7_75t_R g208(.A(new_n265_), .B(new_n266_), .Y(new_n267_));
  INVx1_ASAP7_75t_R   g209(.A(new_n121_), .Y(new_n268_));
  AOI21x1_ASAP7_75t_R g210(.A1(new_n123_), .A2(new_n120_), .B(new_n268_), .Y(new_n269_));
  AOI21x1_ASAP7_75t_R g211(.A1(new_n193_), .A2(new_n190_), .B(new_n197_), .Y(new_n270_));
  OAI21x1_ASAP7_75t_R g212(.A1(new_n172_), .A2(new_n270_), .B(new_n254_), .Y(new_n271_));
  NOR3x1_ASAP7_75t_R  g213(.A(new_n267_), .B(new_n269_), .C(new_n271_), .Y(new_n272_));
  XOR2x2_ASAP7_75t_R  g214(.A(new_n272_), .B(new_n66_), .Y(o1));
  XOR2x2_ASAP7_75t_R  g215(.A(new_n272_), .B(new_n68_), .Y(o2));
  AND3x1_ASAP7_75t_R  g216(.A(new_n257_), .B(new_n220_), .C(new_n170_), .Y(new_n275_));
  AOI21x1_ASAP7_75t_R g217(.A1(p24), .A2(new_n256_), .B(new_n275_), .Y(o3));
  XOR2x2_ASAP7_75t_R  g218(.A(new_n272_), .B(new_n64_), .Y(o4));
  XOR2x2_ASAP7_75t_R  g219(.A(new_n272_), .B(new_n216_), .Y(o5));
  NAND2x1_ASAP7_75t_R g220(.A(new_n123_), .B(new_n120_), .Y(new_n279_));
  AOI21x1_ASAP7_75t_R g221(.A1(new_n121_), .A2(new_n279_), .B(new_n271_), .Y(new_n280_));
  NAND2x1_ASAP7_75t_R g222(.A(new_n170_), .B(new_n280_), .Y(new_n281_));
  XOR2x2_ASAP7_75t_R  g223(.A(new_n281_), .B(p9), .Y(o6));
  XOR2x2_ASAP7_75t_R  g224(.A(new_n281_), .B(p8), .Y(o7));
  XOR2x2_ASAP7_75t_R  g225(.A(new_n281_), .B(p15), .Y(o8));
  NAND2x1_ASAP7_75t_R g226(.A(new_n126_), .B(new_n149_), .Y(new_n285_));
  NOR2x1_ASAP7_75t_R  g227(.A(new_n167_), .B(new_n169_), .Y(new_n286_));
  AND2x2_ASAP7_75t_R  g228(.A(new_n285_), .B(new_n286_), .Y(new_n287_));
  NAND2x1_ASAP7_75t_R g229(.A(new_n261_), .B(new_n264_), .Y(new_n288_));
  AND3x1_ASAP7_75t_R  g230(.A(new_n287_), .B(new_n79_), .C(new_n288_), .Y(new_n289_));
  AND2x2_ASAP7_75t_R  g231(.A(new_n173_), .B(new_n270_), .Y(new_n290_));
  NOR2x1_ASAP7_75t_R  g232(.A(new_n255_), .B(new_n269_), .Y(new_n291_));
  AND2x2_ASAP7_75t_R  g233(.A(new_n290_), .B(new_n291_), .Y(new_n292_));
  AND3x1_ASAP7_75t_R  g234(.A(new_n290_), .B(new_n266_), .C(new_n265_), .Y(new_n293_));
  AOI21x1_ASAP7_75t_R g235(.A1(new_n291_), .A2(new_n293_), .B(new_n79_), .Y(new_n294_));
  AOI21x1_ASAP7_75t_R g236(.A1(new_n289_), .A2(new_n292_), .B(new_n294_), .Y(o9));
  AND3x1_ASAP7_75t_R  g237(.A(new_n266_), .B(new_n72_), .C(new_n265_), .Y(new_n296_));
  AOI21x1_ASAP7_75t_R g238(.A1(new_n291_), .A2(new_n293_), .B(new_n72_), .Y(new_n297_));
  AOI21x1_ASAP7_75t_R g239(.A1(new_n296_), .A2(new_n292_), .B(new_n297_), .Y(o10));
  AND3x1_ASAP7_75t_R  g240(.A(new_n266_), .B(new_n74_), .C(new_n265_), .Y(new_n299_));
  AOI21x1_ASAP7_75t_R g241(.A1(new_n291_), .A2(new_n293_), .B(new_n74_), .Y(new_n300_));
  AOI21x1_ASAP7_75t_R g242(.A1(new_n299_), .A2(new_n292_), .B(new_n300_), .Y(o11));
  AND3x1_ASAP7_75t_R  g243(.A(new_n287_), .B(new_n135_), .C(new_n288_), .Y(new_n302_));
  AOI21x1_ASAP7_75t_R g244(.A1(new_n291_), .A2(new_n293_), .B(new_n135_), .Y(new_n303_));
  AOI21x1_ASAP7_75t_R g245(.A1(new_n302_), .A2(new_n292_), .B(new_n303_), .Y(o12));
  AND3x1_ASAP7_75t_R  g246(.A(new_n291_), .B(new_n170_), .C(new_n290_), .Y(new_n305_));
  INVx1_ASAP7_75t_R   g247(.A(new_n154_), .Y(new_n306_));
  AND3x1_ASAP7_75t_R  g248(.A(new_n285_), .B(p13), .C(new_n306_), .Y(new_n307_));
  AND3x1_ASAP7_75t_R  g249(.A(new_n290_), .B(new_n286_), .C(new_n307_), .Y(new_n308_));
  NAND2x1_ASAP7_75t_R g250(.A(new_n291_), .B(new_n308_), .Y(new_n309_));
  OAI21x1_ASAP7_75t_R g251(.A1(p13), .A2(new_n305_), .B(new_n309_), .Y(o13));
  INVx1_ASAP7_75t_R   g252(.A(p17), .Y(new_n311_));
  AND3x1_ASAP7_75t_R  g253(.A(new_n257_), .B(new_n311_), .C(new_n170_), .Y(new_n312_));
  AOI21x1_ASAP7_75t_R g254(.A1(p17), .A2(new_n256_), .B(new_n312_), .Y(o14));
  INVx1_ASAP7_75t_R   g255(.A(p10), .Y(new_n314_));
  AND3x1_ASAP7_75t_R  g256(.A(new_n257_), .B(new_n314_), .C(new_n170_), .Y(new_n315_));
  AOI21x1_ASAP7_75t_R g257(.A1(p10), .A2(new_n256_), .B(new_n315_), .Y(o15));
  INVx1_ASAP7_75t_R   g258(.A(p4), .Y(new_n317_));
  AND3x1_ASAP7_75t_R  g259(.A(new_n264_), .B(new_n154_), .C(new_n261_), .Y(new_n318_));
  AO21x1_ASAP7_75t_R  g260(.A1(new_n126_), .A2(new_n149_), .B(new_n318_), .Y(new_n319_));
  OR3x1_ASAP7_75t_R   g261(.A(new_n319_), .B(new_n169_), .C(new_n167_), .Y(new_n320_));
  OR3x1_ASAP7_75t_R   g262(.A(new_n269_), .B(new_n271_), .C(new_n320_), .Y(new_n321_));
  AND3x1_ASAP7_75t_R  g263(.A(new_n270_), .B(new_n268_), .C(new_n172_), .Y(new_n322_));
  NAND3x1_ASAP7_75t_R g264(.A(new_n287_), .B(new_n254_), .C(new_n322_), .Y(new_n323_));
  OA21x2_ASAP7_75t_R  g265(.A1(new_n279_), .A2(new_n323_), .B(new_n107_), .Y(new_n324_));
  OAI21x1_ASAP7_75t_R g266(.A1(new_n317_), .A2(new_n321_), .B(new_n324_), .Y(o16));
  NOR2x1_ASAP7_75t_R  g267(.A(new_n62_), .B(new_n119_), .Y(new_n326_));
  NOR3x1_ASAP7_75t_R  g268(.A(new_n269_), .B(new_n271_), .C(new_n320_), .Y(new_n327_));
  AO21x1_ASAP7_75t_R  g269(.A1(new_n326_), .A2(new_n327_), .B(new_n151_), .Y(new_n328_));
  OR3x1_ASAP7_75t_R   g270(.A(new_n61_), .B(new_n59_), .C(p2), .Y(new_n329_));
  NOR2x1_ASAP7_75t_R  g271(.A(new_n111_), .B(new_n118_), .Y(new_n330_));
  OA21x2_ASAP7_75t_R  g272(.A1(new_n329_), .A2(new_n321_), .B(new_n330_), .Y(new_n331_));
  NOR2x1_ASAP7_75t_R  g273(.A(new_n328_), .B(new_n331_), .Y(o17));
  NAND2x1_ASAP7_75t_R g274(.A(new_n194_), .B(new_n195_), .Y(new_n333_));
  INVx1_ASAP7_75t_R   g275(.A(new_n333_), .Y(new_n334_));
  OR3x1_ASAP7_75t_R   g276(.A(new_n321_), .B(new_n189_), .C(p2), .Y(new_n335_));
  AND3x1_ASAP7_75t_R  g277(.A(new_n333_), .B(p29), .C(new_n60_), .Y(new_n336_));
  AO21x1_ASAP7_75t_R  g278(.A1(new_n336_), .A2(new_n327_), .B(new_n151_), .Y(new_n337_));
  AOI21x1_ASAP7_75t_R g279(.A1(new_n334_), .A2(new_n335_), .B(new_n337_), .Y(o18));
  NAND2x1_ASAP7_75t_R g280(.A(p20), .B(new_n327_), .Y(new_n339_));
  AOI21x1_ASAP7_75t_R g281(.A1(new_n149_), .A2(new_n339_), .B(new_n151_), .Y(o19));
  AO21x1_ASAP7_75t_R  g282(.A1(p12), .A2(new_n327_), .B(new_n163_), .Y(new_n341_));
  AND2x2_ASAP7_75t_R  g283(.A(new_n152_), .B(new_n341_), .Y(o20));
  NAND2x1_ASAP7_75t_R g284(.A(new_n248_), .B(new_n247_), .Y(new_n343_));
  AO21x1_ASAP7_75t_R  g285(.A1(new_n232_), .A2(new_n327_), .B(new_n343_), .Y(new_n344_));
  AND2x2_ASAP7_75t_R  g286(.A(new_n152_), .B(new_n344_), .Y(o21));
  AO21x1_ASAP7_75t_R  g287(.A1(p30), .A2(p31), .B(p1), .Y(new_n346_));
  INVx1_ASAP7_75t_R   g288(.A(new_n346_), .Y(new_n347_));
  AND3x1_ASAP7_75t_R  g289(.A(new_n100_), .B(new_n91_), .C(new_n263_), .Y(new_n348_));
  OR3x1_ASAP7_75t_R   g290(.A(new_n267_), .B(new_n269_), .C(new_n271_), .Y(new_n349_));
  INVx1_ASAP7_75t_R   g291(.A(new_n348_), .Y(new_n350_));
  NAND3x1_ASAP7_75t_R g292(.A(new_n266_), .B(new_n265_), .C(new_n350_), .Y(new_n351_));
  NOR3x1_ASAP7_75t_R  g293(.A(new_n351_), .B(new_n271_), .C(new_n269_), .Y(new_n352_));
  AOI21x1_ASAP7_75t_R g294(.A1(new_n348_), .A2(new_n349_), .B(new_n352_), .Y(new_n353_));
  AND3x1_ASAP7_75t_R  g295(.A(new_n266_), .B(new_n265_), .C(new_n350_), .Y(new_n354_));
  AOI21x1_ASAP7_75t_R g296(.A1(new_n354_), .A2(new_n280_), .B(new_n346_), .Y(new_n355_));
  OAI21x1_ASAP7_75t_R g297(.A1(new_n272_), .A2(new_n350_), .B(new_n355_), .Y(new_n356_));
  OAI21x1_ASAP7_75t_R g298(.A1(new_n347_), .A2(new_n353_), .B(new_n356_), .Y(o22));
  NOR2x1_ASAP7_75t_R  g299(.A(new_n138_), .B(new_n128_), .Y(new_n358_));
  XOR2x2_ASAP7_75t_R  g300(.A(new_n187_), .B(new_n358_), .Y(new_n359_));
  NOR2x1_ASAP7_75t_R  g301(.A(p28), .B(p1), .Y(new_n360_));
  XOR2x2_ASAP7_75t_R  g302(.A(new_n359_), .B(new_n360_), .Y(new_n361_));
  OA21x2_ASAP7_75t_R  g303(.A1(p3), .A2(p1), .B(new_n361_), .Y(new_n362_));
  XOR2x2_ASAP7_75t_R  g304(.A(new_n281_), .B(new_n362_), .Y(o23));
  AND3x1_ASAP7_75t_R  g305(.A(new_n206_), .B(new_n208_), .C(new_n152_), .Y(new_n364_));
  NAND2x1_ASAP7_75t_R g306(.A(new_n210_), .B(new_n327_), .Y(new_n365_));
  AND2x2_ASAP7_75t_R  g307(.A(new_n364_), .B(new_n365_), .Y(o24));
endmodule


