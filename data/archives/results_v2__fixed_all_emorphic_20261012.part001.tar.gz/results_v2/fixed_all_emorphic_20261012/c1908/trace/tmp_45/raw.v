// Benchmark "/tmp/" written by ABC on Mon Oct 12 15:05:30 2026

module \/tmp/  ( 
    p10, p18, p8, p12, p4, p6, p28, p16, p5, p21, p15, p9, p26, p25, p27,
    p22, p20, p24, p23, p7, p19, p13, p2, p17, p11, p30, p14, p31, p0, p3,
    p32, p29, p1,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24  );
  input  p10, p18, p8, p12, p4, p6, p28, p16, p5, p21, p15, p9, p26, p25,
    p27, p22, p20, p24, p23, p7, p19, p13, p2, p17, p11, p30, p14, p31, p0,
    p3, p32, p29, p1;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24;
  wire new_n59_, new_n60_, new_n61_, new_n62_, new_n63_, new_n64_, new_n65_,
    new_n66_, new_n67_, new_n68_, new_n69_, new_n70_, new_n71_, new_n72_,
    new_n73_, new_n74_, new_n75_, new_n76_, new_n77_, new_n78_, new_n79_,
    new_n80_, new_n81_, new_n82_, new_n83_, new_n84_, new_n85_, new_n86_,
    new_n87_, new_n88_, new_n89_, new_n90_, new_n91_, new_n92_, new_n93_,
    new_n94_, new_n95_, new_n96_, new_n97_, new_n98_, new_n99_, new_n100_,
    new_n101_, new_n102_, new_n103_, new_n104_, new_n105_, new_n106_,
    new_n107_, new_n108_, new_n109_, new_n110_, new_n111_, new_n112_,
    new_n113_, new_n114_, new_n115_, new_n116_, new_n117_, new_n118_,
    new_n119_, new_n120_, new_n121_, new_n122_, new_n123_, new_n124_,
    new_n125_, new_n126_, new_n127_, new_n128_, new_n129_, new_n130_,
    new_n131_, new_n132_, new_n133_, new_n134_, new_n135_, new_n136_,
    new_n137_, new_n138_, new_n139_, new_n140_, new_n141_, new_n142_,
    new_n143_, new_n144_, new_n145_, new_n146_, new_n147_, new_n148_,
    new_n149_, new_n150_, new_n151_, new_n152_, new_n153_, new_n154_,
    new_n155_, new_n156_, new_n157_, new_n158_, new_n159_, new_n160_,
    new_n161_, new_n162_, new_n163_, new_n164_, new_n165_, new_n166_,
    new_n167_, new_n168_, new_n169_, new_n170_, new_n171_, new_n172_,
    new_n173_, new_n174_, new_n175_, new_n176_, new_n177_, new_n178_,
    new_n179_, new_n180_, new_n181_, new_n182_, new_n183_, new_n184_,
    new_n185_, new_n186_, new_n187_, new_n188_, new_n189_, new_n190_,
    new_n191_, new_n192_, new_n193_, new_n194_, new_n195_, new_n196_,
    new_n197_, new_n198_, new_n199_, new_n200_, new_n201_, new_n202_,
    new_n203_, new_n204_, new_n205_, new_n206_, new_n207_, new_n208_,
    new_n209_, new_n210_, new_n211_, new_n212_, new_n213_, new_n214_,
    new_n215_, new_n216_, new_n217_, new_n218_, new_n219_, new_n220_,
    new_n221_, new_n222_, new_n223_, new_n224_, new_n225_, new_n226_,
    new_n227_, new_n228_, new_n229_, new_n230_, new_n231_, new_n232_,
    new_n233_, new_n234_, new_n235_, new_n236_, new_n237_, new_n238_,
    new_n239_, new_n240_, new_n241_, new_n242_, new_n243_, new_n244_,
    new_n245_, new_n246_, new_n247_, new_n248_, new_n249_, new_n250_,
    new_n251_, new_n252_, new_n253_, new_n254_, new_n255_, new_n256_,
    new_n257_, new_n258_, new_n259_, new_n260_, new_n261_, new_n262_,
    new_n263_, new_n264_, new_n265_, new_n266_, new_n267_, new_n268_,
    new_n269_, new_n271_, new_n272_, new_n273_, new_n274_, new_n275_,
    new_n276_, new_n277_, new_n278_, new_n279_, new_n285_, new_n286_,
    new_n290_, new_n291_, new_n292_, new_n293_, new_n294_, new_n295_,
    new_n296_, new_n297_, new_n298_, new_n300_, new_n301_, new_n303_,
    new_n304_, new_n306_, new_n307_, new_n308_, new_n310_, new_n311_,
    new_n312_, new_n316_, new_n317_, new_n318_, new_n319_, new_n320_,
    new_n321_, new_n322_, new_n323_, new_n324_, new_n325_, new_n327_,
    new_n328_, new_n329_, new_n330_, new_n331_, new_n332_, new_n334_,
    new_n335_, new_n336_, new_n337_, new_n339_, new_n341_, new_n343_,
    new_n344_, new_n346_, new_n347_, new_n348_, new_n349_, new_n350_,
    new_n351_, new_n352_, new_n353_, new_n354_, new_n355_, new_n356_,
    new_n357_, new_n358_, new_n359_, new_n361_, new_n362_, new_n363_,
    new_n364_, new_n365_, new_n367_, new_n368_;
  INVx1_ASAP7_75t_R   g000(.A(p16), .Y(new_n59_));
  NOR2x1_ASAP7_75t_R  g001(.A(p2), .B(p0), .Y(new_n60_));
  NOR2x1_ASAP7_75t_R  g002(.A(new_n59_), .B(new_n60_), .Y(new_n61_));
  INVx1_ASAP7_75t_R   g003(.A(p7), .Y(new_n62_));
  NOR2x1_ASAP7_75t_R  g004(.A(p19), .B(new_n62_), .Y(new_n63_));
  INVx1_ASAP7_75t_R   g005(.A(p25), .Y(new_n64_));
  AO21x1_ASAP7_75t_R  g006(.A1(p19), .A2(new_n62_), .B(new_n64_), .Y(new_n65_));
  INVx1_ASAP7_75t_R   g007(.A(p19), .Y(new_n66_));
  NOR2x1_ASAP7_75t_R  g008(.A(p7), .B(new_n66_), .Y(new_n67_));
  OAI21x1_ASAP7_75t_R g009(.A1(new_n67_), .A2(new_n63_), .B(new_n64_), .Y(new_n68_));
  OAI21x1_ASAP7_75t_R g010(.A1(new_n63_), .A2(new_n65_), .B(new_n68_), .Y(new_n69_));
  INVx1_ASAP7_75t_R   g011(.A(p21), .Y(new_n70_));
  NOR2x1_ASAP7_75t_R  g012(.A(p6), .B(new_n70_), .Y(new_n71_));
  INVx1_ASAP7_75t_R   g013(.A(p6), .Y(new_n72_));
  NOR2x1_ASAP7_75t_R  g014(.A(p21), .B(new_n72_), .Y(new_n73_));
  OAI21x1_ASAP7_75t_R g015(.A1(new_n71_), .A2(new_n73_), .B(p18), .Y(new_n74_));
  NAND2x1_ASAP7_75t_R g016(.A(p21), .B(new_n72_), .Y(new_n75_));
  NAND2x1_ASAP7_75t_R g017(.A(p6), .B(new_n70_), .Y(new_n76_));
  INVx1_ASAP7_75t_R   g018(.A(p18), .Y(new_n77_));
  NAND3x1_ASAP7_75t_R g019(.A(new_n75_), .B(new_n76_), .C(new_n77_), .Y(new_n78_));
  NAND2x1_ASAP7_75t_R g020(.A(new_n74_), .B(new_n78_), .Y(new_n79_));
  NAND2x1_ASAP7_75t_R g021(.A(new_n69_), .B(new_n79_), .Y(new_n80_));
  XOR2x2_ASAP7_75t_R  g022(.A(p7), .B(p19), .Y(new_n81_));
  AND2x2_ASAP7_75t_R  g023(.A(p25), .B(new_n81_), .Y(new_n82_));
  NOR2x1_ASAP7_75t_R  g024(.A(p25), .B(new_n81_), .Y(new_n83_));
  AO21x1_ASAP7_75t_R  g025(.A1(p6), .A2(new_n70_), .B(new_n77_), .Y(new_n84_));
  OAI21x1_ASAP7_75t_R g026(.A1(new_n71_), .A2(new_n73_), .B(new_n77_), .Y(new_n85_));
  OAI21x1_ASAP7_75t_R g027(.A1(new_n71_), .A2(new_n84_), .B(new_n85_), .Y(new_n86_));
  OAI21x1_ASAP7_75t_R g028(.A1(new_n82_), .A2(new_n83_), .B(new_n86_), .Y(new_n87_));
  XNOR2x2_ASAP7_75t_R g029(.A(p5), .B(p22), .Y(new_n88_));
  NAND3x1_ASAP7_75t_R g030(.A(new_n80_), .B(new_n87_), .C(new_n88_), .Y(new_n89_));
  OAI21x1_ASAP7_75t_R g031(.A1(new_n67_), .A2(new_n63_), .B(p25), .Y(new_n90_));
  NAND2x1_ASAP7_75t_R g032(.A(p19), .B(new_n62_), .Y(new_n91_));
  NAND2x1_ASAP7_75t_R g033(.A(p7), .B(new_n66_), .Y(new_n92_));
  NAND3x1_ASAP7_75t_R g034(.A(new_n91_), .B(new_n92_), .C(new_n64_), .Y(new_n93_));
  NAND2x1_ASAP7_75t_R g035(.A(new_n90_), .B(new_n93_), .Y(new_n94_));
  NOR2x1_ASAP7_75t_R  g036(.A(new_n86_), .B(new_n94_), .Y(new_n95_));
  NOR2x1_ASAP7_75t_R  g037(.A(new_n69_), .B(new_n79_), .Y(new_n96_));
  INVx1_ASAP7_75t_R   g038(.A(new_n88_), .Y(new_n97_));
  OAI21x1_ASAP7_75t_R g039(.A1(new_n95_), .A2(new_n96_), .B(new_n97_), .Y(new_n98_));
  NOR2x1_ASAP7_75t_R  g040(.A(p8), .B(p9), .Y(new_n99_));
  AND2x2_ASAP7_75t_R  g041(.A(p8), .B(p9), .Y(new_n100_));
  INVx1_ASAP7_75t_R   g042(.A(p15), .Y(new_n101_));
  OAI21x1_ASAP7_75t_R g043(.A1(new_n99_), .A2(new_n100_), .B(new_n101_), .Y(new_n102_));
  OR3x1_ASAP7_75t_R   g044(.A(new_n100_), .B(new_n101_), .C(new_n99_), .Y(new_n103_));
  NAND2x1_ASAP7_75t_R g045(.A(new_n102_), .B(new_n103_), .Y(new_n104_));
  INVx1_ASAP7_75t_R   g046(.A(p1), .Y(new_n105_));
  NAND2x1_ASAP7_75t_R g047(.A(p30), .B(new_n105_), .Y(new_n106_));
  XOR2x2_ASAP7_75t_R  g048(.A(new_n106_), .B(p13), .Y(new_n107_));
  XOR2x2_ASAP7_75t_R  g049(.A(new_n104_), .B(new_n107_), .Y(new_n108_));
  AOI21x1_ASAP7_75t_R g050(.A1(new_n89_), .A2(new_n98_), .B(new_n108_), .Y(new_n109_));
  NAND3x1_ASAP7_75t_R g051(.A(new_n80_), .B(new_n87_), .C(new_n97_), .Y(new_n110_));
  OAI21x1_ASAP7_75t_R g052(.A1(new_n95_), .A2(new_n96_), .B(new_n88_), .Y(new_n111_));
  OAI21x1_ASAP7_75t_R g053(.A1(new_n99_), .A2(new_n100_), .B(p15), .Y(new_n112_));
  OR3x1_ASAP7_75t_R   g054(.A(new_n100_), .B(p15), .C(new_n99_), .Y(new_n113_));
  NAND2x1_ASAP7_75t_R g055(.A(new_n112_), .B(new_n113_), .Y(new_n114_));
  XOR2x2_ASAP7_75t_R  g056(.A(new_n114_), .B(new_n107_), .Y(new_n115_));
  AOI21x1_ASAP7_75t_R g057(.A1(new_n110_), .A2(new_n111_), .B(new_n115_), .Y(new_n116_));
  AND2x2_ASAP7_75t_R  g058(.A(p26), .B(p0), .Y(new_n117_));
  NOR2x1_ASAP7_75t_R  g059(.A(p2), .B(new_n117_), .Y(new_n118_));
  OAI21x1_ASAP7_75t_R g060(.A1(new_n109_), .A2(new_n116_), .B(new_n118_), .Y(new_n119_));
  AND2x2_ASAP7_75t_R  g061(.A(new_n61_), .B(new_n119_), .Y(new_n120_));
  AO21x1_ASAP7_75t_R  g062(.A1(p26), .A2(p2), .B(new_n117_), .Y(new_n121_));
  INVx1_ASAP7_75t_R   g063(.A(p2), .Y(new_n122_));
  OAI21x1_ASAP7_75t_R g064(.A1(new_n109_), .A2(new_n116_), .B(new_n122_), .Y(new_n123_));
  NAND2x1_ASAP7_75t_R g065(.A(new_n121_), .B(new_n123_), .Y(new_n124_));
  NOR2x1_ASAP7_75t_R  g066(.A(p10), .B(p24), .Y(new_n125_));
  AND2x2_ASAP7_75t_R  g067(.A(p10), .B(p24), .Y(new_n126_));
  OAI21x1_ASAP7_75t_R g068(.A1(new_n125_), .A2(new_n126_), .B(p17), .Y(new_n127_));
  OR3x1_ASAP7_75t_R   g069(.A(new_n126_), .B(p17), .C(new_n125_), .Y(new_n128_));
  NAND2x1_ASAP7_75t_R g070(.A(new_n127_), .B(new_n128_), .Y(new_n129_));
  XOR2x2_ASAP7_75t_R  g071(.A(new_n104_), .B(new_n129_), .Y(new_n130_));
  NOR2x1_ASAP7_75t_R  g072(.A(p0), .B(p1), .Y(new_n131_));
  NAND3x1_ASAP7_75t_R g073(.A(new_n131_), .B(p26), .C(new_n64_), .Y(new_n132_));
  AO21x1_ASAP7_75t_R  g074(.A1(p26), .A2(new_n131_), .B(new_n64_), .Y(new_n133_));
  AND2x2_ASAP7_75t_R  g075(.A(new_n132_), .B(new_n133_), .Y(new_n134_));
  XOR2x2_ASAP7_75t_R  g076(.A(new_n79_), .B(new_n134_), .Y(new_n135_));
  NAND2x1_ASAP7_75t_R g077(.A(new_n130_), .B(new_n135_), .Y(new_n136_));
  XOR2x2_ASAP7_75t_R  g078(.A(new_n114_), .B(new_n129_), .Y(new_n137_));
  XOR2x2_ASAP7_75t_R  g079(.A(new_n86_), .B(new_n134_), .Y(new_n138_));
  NAND2x1_ASAP7_75t_R g080(.A(new_n137_), .B(new_n138_), .Y(new_n139_));
  INVx1_ASAP7_75t_R   g081(.A(p27), .Y(new_n140_));
  NOR2x1_ASAP7_75t_R  g082(.A(p2), .B(new_n140_), .Y(new_n141_));
  NAND3x1_ASAP7_75t_R g083(.A(new_n136_), .B(new_n139_), .C(new_n141_), .Y(new_n142_));
  NAND3x1_ASAP7_75t_R g084(.A(new_n135_), .B(new_n137_), .C(new_n122_), .Y(new_n143_));
  NAND3x1_ASAP7_75t_R g085(.A(new_n138_), .B(new_n130_), .C(new_n122_), .Y(new_n144_));
  NAND3x1_ASAP7_75t_R g086(.A(new_n143_), .B(new_n144_), .C(new_n140_), .Y(new_n145_));
  NAND2x1_ASAP7_75t_R g087(.A(p13), .B(p14), .Y(new_n146_));
  OR3x1_ASAP7_75t_R   g088(.A(p15), .B(p13), .C(p14), .Y(new_n147_));
  OAI21x1_ASAP7_75t_R g089(.A1(p15), .A2(new_n146_), .B(new_n147_), .Y(new_n148_));
  OAI21x1_ASAP7_75t_R g090(.A1(p13), .A2(p14), .B(p15), .Y(new_n149_));
  AND2x2_ASAP7_75t_R  g091(.A(p13), .B(p14), .Y(new_n150_));
  NOR2x1_ASAP7_75t_R  g092(.A(new_n149_), .B(new_n150_), .Y(new_n151_));
  NOR3x1_ASAP7_75t_R  g093(.A(new_n148_), .B(p22), .C(new_n151_), .Y(new_n152_));
  NOR2x1_ASAP7_75t_R  g094(.A(p13), .B(p14), .Y(new_n153_));
  OAI21x1_ASAP7_75t_R g095(.A1(new_n153_), .A2(new_n150_), .B(new_n101_), .Y(new_n154_));
  AO21x1_ASAP7_75t_R  g096(.A1(p13), .A2(p14), .B(new_n149_), .Y(new_n155_));
  INVx1_ASAP7_75t_R   g097(.A(p22), .Y(new_n156_));
  AOI21x1_ASAP7_75t_R g098(.A1(new_n154_), .A2(new_n155_), .B(new_n156_), .Y(new_n157_));
  NOR2x1_ASAP7_75t_R  g099(.A(p32), .B(p1), .Y(new_n158_));
  INVx1_ASAP7_75t_R   g100(.A(p23), .Y(new_n159_));
  NOR2x1_ASAP7_75t_R  g101(.A(p24), .B(new_n159_), .Y(new_n160_));
  INVx1_ASAP7_75t_R   g102(.A(p24), .Y(new_n161_));
  AOI21x1_ASAP7_75t_R g103(.A1(p23), .A2(new_n158_), .B(new_n161_), .Y(new_n162_));
  AOI21x1_ASAP7_75t_R g104(.A1(new_n158_), .A2(new_n160_), .B(new_n162_), .Y(new_n163_));
  OAI21x1_ASAP7_75t_R g105(.A1(new_n152_), .A2(new_n157_), .B(new_n163_), .Y(new_n164_));
  NAND3x1_ASAP7_75t_R g106(.A(new_n155_), .B(new_n154_), .C(new_n156_), .Y(new_n165_));
  OAI21x1_ASAP7_75t_R g107(.A1(new_n151_), .A2(new_n148_), .B(p22), .Y(new_n166_));
  AO21x1_ASAP7_75t_R  g108(.A1(new_n158_), .A2(new_n160_), .B(new_n162_), .Y(new_n167_));
  NAND3x1_ASAP7_75t_R g109(.A(new_n165_), .B(new_n166_), .C(new_n167_), .Y(new_n168_));
  XNOR2x2_ASAP7_75t_R g110(.A(p21), .B(p9), .Y(new_n169_));
  NAND3x1_ASAP7_75t_R g111(.A(new_n164_), .B(new_n168_), .C(new_n169_), .Y(new_n170_));
  OA21x2_ASAP7_75t_R  g112(.A1(p2), .A2(p32), .B(p11), .Y(new_n171_));
  NAND2x1_ASAP7_75t_R g113(.A(p23), .B(new_n158_), .Y(new_n172_));
  XOR2x2_ASAP7_75t_R  g114(.A(p22), .B(p24), .Y(new_n173_));
  NAND2x1_ASAP7_75t_R g115(.A(new_n172_), .B(new_n173_), .Y(new_n174_));
  INVx1_ASAP7_75t_R   g116(.A(new_n158_), .Y(new_n175_));
  OR3x1_ASAP7_75t_R   g117(.A(new_n173_), .B(new_n159_), .C(new_n175_), .Y(new_n176_));
  NOR2x1_ASAP7_75t_R  g118(.A(new_n151_), .B(new_n148_), .Y(new_n177_));
  AOI21x1_ASAP7_75t_R g119(.A1(new_n174_), .A2(new_n176_), .B(new_n177_), .Y(new_n178_));
  NAND2x1_ASAP7_75t_R g120(.A(new_n154_), .B(new_n155_), .Y(new_n179_));
  NOR2x1_ASAP7_75t_R  g121(.A(new_n172_), .B(new_n173_), .Y(new_n180_));
  AND2x2_ASAP7_75t_R  g122(.A(new_n172_), .B(new_n173_), .Y(new_n181_));
  NOR3x1_ASAP7_75t_R  g123(.A(new_n179_), .B(new_n180_), .C(new_n181_), .Y(new_n182_));
  INVx1_ASAP7_75t_R   g124(.A(new_n169_), .Y(new_n183_));
  OAI21x1_ASAP7_75t_R g125(.A1(new_n178_), .A2(new_n182_), .B(new_n183_), .Y(new_n184_));
  NAND3x1_ASAP7_75t_R g126(.A(new_n170_), .B(new_n171_), .C(new_n184_), .Y(new_n185_));
  OAI21x1_ASAP7_75t_R g127(.A1(new_n180_), .A2(new_n181_), .B(new_n179_), .Y(new_n186_));
  NAND3x1_ASAP7_75t_R g128(.A(new_n177_), .B(new_n176_), .C(new_n174_), .Y(new_n187_));
  AO21x1_ASAP7_75t_R  g129(.A1(new_n186_), .A2(new_n187_), .B(new_n183_), .Y(new_n188_));
  NAND3x1_ASAP7_75t_R g130(.A(new_n187_), .B(new_n186_), .C(new_n183_), .Y(new_n189_));
  NOR2x1_ASAP7_75t_R  g131(.A(p2), .B(new_n171_), .Y(new_n190_));
  NAND3x1_ASAP7_75t_R g132(.A(new_n188_), .B(new_n189_), .C(new_n190_), .Y(new_n191_));
  AND2x2_ASAP7_75t_R  g133(.A(p2), .B(p11), .Y(new_n192_));
  INVx1_ASAP7_75t_R   g134(.A(new_n192_), .Y(new_n193_));
  NAND3x1_ASAP7_75t_R g135(.A(new_n185_), .B(new_n191_), .C(new_n193_), .Y(new_n194_));
  AOI21x1_ASAP7_75t_R g136(.A1(new_n142_), .A2(new_n145_), .B(new_n194_), .Y(new_n195_));
  AND3x1_ASAP7_75t_R  g137(.A(new_n120_), .B(new_n124_), .C(new_n195_), .Y(new_n196_));
  NOR2x1_ASAP7_75t_R  g138(.A(p2), .B(p32), .Y(new_n197_));
  NOR2x1_ASAP7_75t_R  g139(.A(new_n159_), .B(new_n197_), .Y(new_n198_));
  INVx1_ASAP7_75t_R   g140(.A(new_n198_), .Y(new_n199_));
  XOR2x2_ASAP7_75t_R  g141(.A(p22), .B(p14), .Y(new_n200_));
  NAND2x1_ASAP7_75t_R g142(.A(p28), .B(new_n105_), .Y(new_n201_));
  XOR2x2_ASAP7_75t_R  g143(.A(new_n200_), .B(new_n201_), .Y(new_n202_));
  NAND2x1_ASAP7_75t_R g144(.A(new_n94_), .B(new_n202_), .Y(new_n203_));
  INVx1_ASAP7_75t_R   g145(.A(p28), .Y(new_n204_));
  NOR2x1_ASAP7_75t_R  g146(.A(p1), .B(new_n204_), .Y(new_n205_));
  XOR2x2_ASAP7_75t_R  g147(.A(new_n200_), .B(new_n205_), .Y(new_n206_));
  NAND2x1_ASAP7_75t_R g148(.A(new_n69_), .B(new_n206_), .Y(new_n207_));
  NAND2x1_ASAP7_75t_R g149(.A(new_n203_), .B(new_n207_), .Y(new_n208_));
  OR3x1_ASAP7_75t_R   g150(.A(new_n208_), .B(p2), .C(new_n137_), .Y(new_n209_));
  AOI21x1_ASAP7_75t_R g151(.A1(new_n203_), .A2(new_n207_), .B(new_n130_), .Y(new_n210_));
  INVx1_ASAP7_75t_R   g152(.A(p29), .Y(new_n211_));
  AOI21x1_ASAP7_75t_R g153(.A1(new_n122_), .A2(new_n210_), .B(new_n211_), .Y(new_n212_));
  NAND3x1_ASAP7_75t_R g154(.A(new_n130_), .B(new_n203_), .C(new_n207_), .Y(new_n213_));
  NAND2x1_ASAP7_75t_R g155(.A(new_n137_), .B(new_n208_), .Y(new_n214_));
  NAND2x1_ASAP7_75t_R g156(.A(new_n122_), .B(new_n211_), .Y(new_n215_));
  AOI21x1_ASAP7_75t_R g157(.A1(new_n213_), .A2(new_n214_), .B(new_n215_), .Y(new_n216_));
  AOI21x1_ASAP7_75t_R g158(.A1(new_n209_), .A2(new_n212_), .B(new_n216_), .Y(new_n217_));
  INVx1_ASAP7_75t_R   g159(.A(p0), .Y(new_n218_));
  AND3x1_ASAP7_75t_R  g160(.A(new_n218_), .B(new_n105_), .C(p16), .Y(new_n219_));
  OR3x1_ASAP7_75t_R   g161(.A(new_n148_), .B(new_n219_), .C(new_n151_), .Y(new_n220_));
  NAND2x1_ASAP7_75t_R g162(.A(p16), .B(new_n131_), .Y(new_n221_));
  AO21x1_ASAP7_75t_R  g163(.A1(new_n154_), .A2(new_n155_), .B(new_n221_), .Y(new_n222_));
  XOR2x2_ASAP7_75t_R  g164(.A(p18), .B(p5), .Y(new_n223_));
  OAI21x1_ASAP7_75t_R g165(.A1(p18), .A2(p5), .B(new_n66_), .Y(new_n224_));
  AO21x1_ASAP7_75t_R  g166(.A1(p18), .A2(p5), .B(new_n224_), .Y(new_n225_));
  OAI21x1_ASAP7_75t_R g167(.A1(new_n66_), .A2(new_n223_), .B(new_n225_), .Y(new_n226_));
  AO21x1_ASAP7_75t_R  g168(.A1(new_n220_), .A2(new_n222_), .B(new_n226_), .Y(new_n227_));
  AND3x1_ASAP7_75t_R  g169(.A(new_n226_), .B(new_n220_), .C(new_n222_), .Y(new_n228_));
  INVx1_ASAP7_75t_R   g170(.A(new_n228_), .Y(new_n229_));
  XNOR2x2_ASAP7_75t_R g171(.A(p8), .B(p17), .Y(new_n230_));
  AO21x1_ASAP7_75t_R  g172(.A1(new_n227_), .A2(new_n229_), .B(new_n230_), .Y(new_n231_));
  INVx1_ASAP7_75t_R   g173(.A(new_n230_), .Y(new_n232_));
  NOR2x1_ASAP7_75t_R  g174(.A(new_n232_), .B(new_n228_), .Y(new_n233_));
  NOR2x1_ASAP7_75t_R  g175(.A(p20), .B(p2), .Y(new_n234_));
  INVx1_ASAP7_75t_R   g176(.A(new_n234_), .Y(new_n235_));
  AOI21x1_ASAP7_75t_R g177(.A1(new_n227_), .A2(new_n233_), .B(new_n235_), .Y(new_n236_));
  OR3x1_ASAP7_75t_R   g178(.A(p2), .B(p3), .C(p1), .Y(new_n237_));
  NOR2x1_ASAP7_75t_R  g179(.A(p4), .B(p1), .Y(new_n238_));
  INVx1_ASAP7_75t_R   g180(.A(new_n238_), .Y(new_n239_));
  NOR2x1_ASAP7_75t_R  g181(.A(p32), .B(new_n218_), .Y(new_n240_));
  AO21x1_ASAP7_75t_R  g182(.A1(new_n237_), .A2(new_n239_), .B(new_n240_), .Y(new_n241_));
  AOI21x1_ASAP7_75t_R g183(.A1(new_n231_), .A2(new_n236_), .B(new_n241_), .Y(new_n242_));
  XOR2x2_ASAP7_75t_R  g184(.A(new_n177_), .B(p18), .Y(new_n243_));
  XOR2x2_ASAP7_75t_R  g185(.A(p5), .B(p19), .Y(new_n244_));
  XOR2x2_ASAP7_75t_R  g186(.A(new_n244_), .B(new_n221_), .Y(new_n245_));
  NAND2x1_ASAP7_75t_R g187(.A(new_n230_), .B(new_n245_), .Y(new_n246_));
  XOR2x2_ASAP7_75t_R  g188(.A(new_n219_), .B(new_n244_), .Y(new_n247_));
  NAND2x1_ASAP7_75t_R g189(.A(new_n232_), .B(new_n247_), .Y(new_n248_));
  NAND3x1_ASAP7_75t_R g190(.A(new_n243_), .B(new_n246_), .C(new_n248_), .Y(new_n249_));
  NOR2x1_ASAP7_75t_R  g191(.A(new_n232_), .B(new_n247_), .Y(new_n250_));
  NOR2x1_ASAP7_75t_R  g192(.A(new_n230_), .B(new_n245_), .Y(new_n251_));
  XOR2x2_ASAP7_75t_R  g193(.A(new_n177_), .B(new_n77_), .Y(new_n252_));
  OAI21x1_ASAP7_75t_R g194(.A1(new_n250_), .A2(new_n251_), .B(new_n252_), .Y(new_n253_));
  NAND3x1_ASAP7_75t_R g195(.A(new_n249_), .B(new_n122_), .C(new_n253_), .Y(new_n254_));
  NAND2x1_ASAP7_75t_R g196(.A(p20), .B(new_n254_), .Y(new_n255_));
  NOR2x1_ASAP7_75t_R  g197(.A(new_n99_), .B(new_n100_), .Y(new_n256_));
  NAND2x1_ASAP7_75t_R g198(.A(p11), .B(new_n158_), .Y(new_n257_));
  XOR2x2_ASAP7_75t_R  g199(.A(new_n256_), .B(new_n257_), .Y(new_n258_));
  XOR2x2_ASAP7_75t_R  g200(.A(p5), .B(p7), .Y(new_n259_));
  XOR2x2_ASAP7_75t_R  g201(.A(p10), .B(p6), .Y(new_n260_));
  XOR2x2_ASAP7_75t_R  g202(.A(new_n259_), .B(new_n260_), .Y(new_n261_));
  XOR2x2_ASAP7_75t_R  g203(.A(new_n258_), .B(new_n261_), .Y(new_n262_));
  INVx1_ASAP7_75t_R   g204(.A(p12), .Y(new_n263_));
  OAI21x1_ASAP7_75t_R g205(.A1(p2), .A2(new_n262_), .B(new_n263_), .Y(new_n264_));
  OR3x1_ASAP7_75t_R   g206(.A(new_n262_), .B(new_n263_), .C(p2), .Y(new_n265_));
  NAND2x1_ASAP7_75t_R g207(.A(new_n264_), .B(new_n265_), .Y(new_n266_));
  AND3x1_ASAP7_75t_R  g208(.A(new_n242_), .B(new_n255_), .C(new_n266_), .Y(new_n267_));
  OA21x2_ASAP7_75t_R  g209(.A1(new_n199_), .A2(new_n217_), .B(new_n267_), .Y(new_n268_));
  NAND2x1_ASAP7_75t_R g210(.A(new_n196_), .B(new_n268_), .Y(new_n269_));
  XOR2x2_ASAP7_75t_R  g211(.A(new_n269_), .B(p14), .Y(o0));
  INVx1_ASAP7_75t_R   g212(.A(new_n61_), .Y(new_n271_));
  AOI21x1_ASAP7_75t_R g213(.A1(new_n119_), .A2(new_n124_), .B(new_n271_), .Y(new_n272_));
  OAI21x1_ASAP7_75t_R g214(.A1(new_n199_), .A2(new_n217_), .B(new_n195_), .Y(new_n273_));
  OR3x1_ASAP7_75t_R   g215(.A(p2), .B(p31), .C(p1), .Y(new_n274_));
  AO21x1_ASAP7_75t_R  g216(.A1(new_n274_), .A2(new_n239_), .B(new_n240_), .Y(new_n275_));
  AOI21x1_ASAP7_75t_R g217(.A1(new_n264_), .A2(new_n265_), .B(new_n275_), .Y(new_n276_));
  NAND2x1_ASAP7_75t_R g218(.A(new_n231_), .B(new_n236_), .Y(new_n277_));
  NAND3x1_ASAP7_75t_R g219(.A(new_n276_), .B(new_n255_), .C(new_n277_), .Y(new_n278_));
  NOR3x1_ASAP7_75t_R  g220(.A(new_n272_), .B(new_n273_), .C(new_n278_), .Y(new_n279_));
  XOR2x2_ASAP7_75t_R  g221(.A(new_n279_), .B(new_n64_), .Y(o1));
  XOR2x2_ASAP7_75t_R  g222(.A(new_n279_), .B(new_n66_), .Y(o2));
  XOR2x2_ASAP7_75t_R  g223(.A(new_n269_), .B(p24), .Y(o3));
  XOR2x2_ASAP7_75t_R  g224(.A(new_n279_), .B(new_n62_), .Y(o4));
  XOR2x2_ASAP7_75t_R  g225(.A(new_n279_), .B(new_n156_), .Y(o5));
  INVx1_ASAP7_75t_R   g226(.A(new_n267_), .Y(new_n285_));
  OR3x1_ASAP7_75t_R   g227(.A(new_n285_), .B(new_n273_), .C(new_n272_), .Y(new_n286_));
  XOR2x2_ASAP7_75t_R  g228(.A(new_n286_), .B(p9), .Y(o6));
  XOR2x2_ASAP7_75t_R  g229(.A(new_n286_), .B(p8), .Y(o7));
  XOR2x2_ASAP7_75t_R  g230(.A(new_n286_), .B(p15), .Y(o8));
  INVx1_ASAP7_75t_R   g231(.A(new_n195_), .Y(new_n290_));
  NAND2x1_ASAP7_75t_R g232(.A(new_n198_), .B(new_n217_), .Y(new_n291_));
  OR3x1_ASAP7_75t_R   g233(.A(new_n272_), .B(new_n290_), .C(new_n291_), .Y(new_n292_));
  AND2x2_ASAP7_75t_R  g234(.A(new_n277_), .B(new_n255_), .Y(new_n293_));
  NAND2x1_ASAP7_75t_R g235(.A(new_n266_), .B(new_n293_), .Y(new_n294_));
  OR3x1_ASAP7_75t_R   g236(.A(new_n294_), .B(p18), .C(new_n275_), .Y(new_n295_));
  NOR2x1_ASAP7_75t_R  g237(.A(new_n278_), .B(new_n291_), .Y(new_n296_));
  NOR2x1_ASAP7_75t_R  g238(.A(new_n290_), .B(new_n272_), .Y(new_n297_));
  AO21x1_ASAP7_75t_R  g239(.A1(new_n296_), .A2(new_n297_), .B(new_n77_), .Y(new_n298_));
  OA21x2_ASAP7_75t_R  g240(.A1(new_n292_), .A2(new_n295_), .B(new_n298_), .Y(o9));
  OR3x1_ASAP7_75t_R   g241(.A(new_n294_), .B(p6), .C(new_n275_), .Y(new_n300_));
  AO21x1_ASAP7_75t_R  g242(.A1(new_n296_), .A2(new_n297_), .B(new_n72_), .Y(new_n301_));
  OA21x2_ASAP7_75t_R  g243(.A1(new_n292_), .A2(new_n300_), .B(new_n301_), .Y(o10));
  OR3x1_ASAP7_75t_R   g244(.A(new_n294_), .B(p21), .C(new_n275_), .Y(new_n303_));
  AO21x1_ASAP7_75t_R  g245(.A1(new_n296_), .A2(new_n297_), .B(new_n70_), .Y(new_n304_));
  OA21x2_ASAP7_75t_R  g246(.A1(new_n292_), .A2(new_n303_), .B(new_n304_), .Y(o11));
  INVx1_ASAP7_75t_R   g247(.A(p5), .Y(new_n306_));
  OAI21x1_ASAP7_75t_R g248(.A1(new_n278_), .A2(new_n292_), .B(new_n306_), .Y(new_n307_));
  OR3x1_ASAP7_75t_R   g249(.A(new_n292_), .B(new_n306_), .C(new_n278_), .Y(new_n308_));
  NAND2x1_ASAP7_75t_R g250(.A(new_n307_), .B(new_n308_), .Y(o12));
  INVx1_ASAP7_75t_R   g251(.A(p13), .Y(new_n310_));
  OAI21x1_ASAP7_75t_R g252(.A1(new_n285_), .A2(new_n292_), .B(new_n310_), .Y(new_n311_));
  OR3x1_ASAP7_75t_R   g253(.A(new_n292_), .B(new_n310_), .C(new_n285_), .Y(new_n312_));
  NAND2x1_ASAP7_75t_R g254(.A(new_n311_), .B(new_n312_), .Y(o13));
  XOR2x2_ASAP7_75t_R  g255(.A(new_n269_), .B(p17), .Y(o14));
  XOR2x2_ASAP7_75t_R  g256(.A(new_n269_), .B(p10), .Y(o15));
  INVx1_ASAP7_75t_R   g257(.A(p4), .Y(new_n316_));
  NAND2x1_ASAP7_75t_R g258(.A(new_n253_), .B(new_n249_), .Y(new_n317_));
  NAND2x1_ASAP7_75t_R g259(.A(new_n241_), .B(new_n275_), .Y(new_n318_));
  OA21x2_ASAP7_75t_R  g260(.A1(new_n235_), .A2(new_n317_), .B(new_n318_), .Y(new_n319_));
  NAND3x1_ASAP7_75t_R g261(.A(new_n319_), .B(new_n255_), .C(new_n266_), .Y(new_n320_));
  OR3x1_ASAP7_75t_R   g262(.A(new_n272_), .B(new_n273_), .C(new_n320_), .Y(new_n321_));
  AND3x1_ASAP7_75t_R  g263(.A(new_n119_), .B(new_n271_), .C(new_n199_), .Y(new_n322_));
  AND3x1_ASAP7_75t_R  g264(.A(new_n322_), .B(new_n124_), .C(new_n217_), .Y(new_n323_));
  NAND2x1_ASAP7_75t_R g265(.A(new_n195_), .B(new_n323_), .Y(new_n324_));
  OA21x2_ASAP7_75t_R  g266(.A1(new_n294_), .A2(new_n324_), .B(new_n105_), .Y(new_n325_));
  OAI21x1_ASAP7_75t_R g267(.A1(new_n316_), .A2(new_n321_), .B(new_n325_), .Y(o16));
  AND3x1_ASAP7_75t_R  g268(.A(new_n122_), .B(p26), .C(p0), .Y(new_n327_));
  NOR3x1_ASAP7_75t_R  g269(.A(new_n272_), .B(new_n273_), .C(new_n320_), .Y(new_n328_));
  NOR2x1_ASAP7_75t_R  g270(.A(new_n109_), .B(new_n116_), .Y(new_n329_));
  INVx1_ASAP7_75t_R   g271(.A(new_n329_), .Y(new_n330_));
  AO21x1_ASAP7_75t_R  g272(.A1(new_n327_), .A2(new_n328_), .B(new_n330_), .Y(new_n331_));
  NAND3x1_ASAP7_75t_R g273(.A(new_n328_), .B(new_n330_), .C(new_n327_), .Y(new_n332_));
  AND3x1_ASAP7_75t_R  g274(.A(new_n331_), .B(new_n239_), .C(new_n332_), .Y(o17));
  NAND2x1_ASAP7_75t_R g275(.A(new_n213_), .B(new_n214_), .Y(new_n334_));
  AND3x1_ASAP7_75t_R  g276(.A(new_n328_), .B(new_n122_), .C(p29), .Y(new_n335_));
  AND3x1_ASAP7_75t_R  g277(.A(new_n334_), .B(new_n122_), .C(p29), .Y(new_n336_));
  AOI21x1_ASAP7_75t_R g278(.A1(new_n336_), .A2(new_n328_), .B(new_n238_), .Y(new_n337_));
  OA21x2_ASAP7_75t_R  g279(.A1(new_n334_), .A2(new_n335_), .B(new_n337_), .Y(o18));
  AO21x1_ASAP7_75t_R  g280(.A1(p20), .A2(new_n328_), .B(new_n317_), .Y(new_n339_));
  AND2x2_ASAP7_75t_R  g281(.A(new_n239_), .B(new_n339_), .Y(o19));
  AO21x1_ASAP7_75t_R  g282(.A1(p12), .A2(new_n328_), .B(new_n262_), .Y(new_n341_));
  AND2x2_ASAP7_75t_R  g283(.A(new_n239_), .B(new_n341_), .Y(o20));
  NAND2x1_ASAP7_75t_R g284(.A(new_n189_), .B(new_n188_), .Y(new_n343_));
  AO21x1_ASAP7_75t_R  g285(.A1(new_n171_), .A2(new_n328_), .B(new_n343_), .Y(new_n344_));
  AND2x2_ASAP7_75t_R  g286(.A(new_n239_), .B(new_n344_), .Y(o21));
  AO21x1_ASAP7_75t_R  g287(.A1(p30), .A2(p31), .B(p1), .Y(new_n346_));
  INVx1_ASAP7_75t_R   g288(.A(new_n346_), .Y(new_n347_));
  OR3x1_ASAP7_75t_R   g289(.A(new_n272_), .B(new_n273_), .C(new_n278_), .Y(new_n348_));
  NOR2x1_ASAP7_75t_R  g290(.A(p31), .B(p1), .Y(new_n349_));
  AO21x1_ASAP7_75t_R  g291(.A1(new_n110_), .A2(new_n111_), .B(new_n349_), .Y(new_n350_));
  INVx1_ASAP7_75t_R   g292(.A(new_n350_), .Y(new_n351_));
  NAND3x1_ASAP7_75t_R g293(.A(new_n293_), .B(new_n276_), .C(new_n350_), .Y(new_n352_));
  NOR3x1_ASAP7_75t_R  g294(.A(new_n352_), .B(new_n273_), .C(new_n272_), .Y(new_n353_));
  AOI21x1_ASAP7_75t_R g295(.A1(new_n348_), .A2(new_n351_), .B(new_n353_), .Y(new_n354_));
  NOR2x1_ASAP7_75t_R  g296(.A(new_n351_), .B(new_n278_), .Y(new_n355_));
  NAND2x1_ASAP7_75t_R g297(.A(new_n119_), .B(new_n124_), .Y(new_n356_));
  AOI21x1_ASAP7_75t_R g298(.A1(new_n61_), .A2(new_n356_), .B(new_n273_), .Y(new_n357_));
  AOI21x1_ASAP7_75t_R g299(.A1(new_n355_), .A2(new_n357_), .B(new_n346_), .Y(new_n358_));
  OAI21x1_ASAP7_75t_R g300(.A1(new_n279_), .A2(new_n350_), .B(new_n358_), .Y(new_n359_));
  OAI21x1_ASAP7_75t_R g301(.A1(new_n347_), .A2(new_n354_), .B(new_n359_), .Y(o22));
  NOR2x1_ASAP7_75t_R  g302(.A(new_n153_), .B(new_n150_), .Y(new_n361_));
  XOR2x2_ASAP7_75t_R  g303(.A(new_n130_), .B(new_n361_), .Y(new_n362_));
  NOR2x1_ASAP7_75t_R  g304(.A(p28), .B(p1), .Y(new_n363_));
  XOR2x2_ASAP7_75t_R  g305(.A(new_n362_), .B(new_n363_), .Y(new_n364_));
  OA21x2_ASAP7_75t_R  g306(.A1(p3), .A2(p1), .B(new_n364_), .Y(new_n365_));
  XOR2x2_ASAP7_75t_R  g307(.A(new_n286_), .B(new_n365_), .Y(o23));
  NAND2x1_ASAP7_75t_R g308(.A(new_n141_), .B(new_n328_), .Y(new_n367_));
  AND2x2_ASAP7_75t_R  g309(.A(new_n139_), .B(new_n136_), .Y(new_n368_));
  AND3x1_ASAP7_75t_R  g310(.A(new_n367_), .B(new_n239_), .C(new_n368_), .Y(o24));
endmodule


