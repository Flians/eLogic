// Benchmark "/tmp/" written by ABC on Mon Oct 12 15:05:27 2026

module \/tmp/  ( 
    p15, p12, p29, p6, p30, p5, p10, p2, p31, p8, p4, p9, p1, p21, p27,
    p17, p24, p18, p7, p32, p11, p13, p3, p20, p0, p14, p26, p23, p16, p28,
    p25, p22, p19,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24  );
  input  p15, p12, p29, p6, p30, p5, p10, p2, p31, p8, p4, p9, p1, p21,
    p27, p17, p24, p18, p7, p32, p11, p13, p3, p20, p0, p14, p26, p23, p16,
    p28, p25, p22, p19;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24;
  wire new_n59_, new_n60_, new_n61_, new_n62_, new_n63_, new_n64_, new_n65_,
    new_n66_, new_n67_, new_n68_, new_n69_, new_n70_, new_n71_, new_n72_,
    new_n73_, new_n74_, new_n75_, new_n76_, new_n77_, new_n78_, new_n79_,
    new_n80_, new_n81_, new_n82_, new_n83_, new_n84_, new_n85_, new_n86_,
    new_n87_, new_n88_, new_n89_, new_n90_, new_n91_, new_n92_, new_n93_,
    new_n94_, new_n95_, new_n96_, new_n97_, new_n98_, new_n99_, new_n100_,
    new_n101_, new_n102_, new_n103_, new_n104_, new_n105_, new_n106_,
    new_n107_, new_n108_, new_n109_, new_n110_, new_n111_, new_n112_,
    new_n113_, new_n114_, new_n115_, new_n116_, new_n117_, new_n118_,
    new_n119_, new_n120_, new_n121_, new_n122_, new_n123_, new_n124_,
    new_n125_, new_n126_, new_n127_, new_n128_, new_n129_, new_n130_,
    new_n131_, new_n132_, new_n133_, new_n134_, new_n135_, new_n136_,
    new_n137_, new_n138_, new_n139_, new_n140_, new_n141_, new_n142_,
    new_n143_, new_n144_, new_n145_, new_n146_, new_n147_, new_n148_,
    new_n149_, new_n150_, new_n151_, new_n152_, new_n153_, new_n154_,
    new_n155_, new_n156_, new_n157_, new_n158_, new_n159_, new_n160_,
    new_n161_, new_n162_, new_n163_, new_n164_, new_n165_, new_n166_,
    new_n167_, new_n168_, new_n169_, new_n170_, new_n171_, new_n172_,
    new_n173_, new_n174_, new_n175_, new_n176_, new_n177_, new_n178_,
    new_n179_, new_n180_, new_n181_, new_n182_, new_n183_, new_n184_,
    new_n185_, new_n186_, new_n187_, new_n188_, new_n189_, new_n190_,
    new_n191_, new_n192_, new_n193_, new_n194_, new_n195_, new_n196_,
    new_n197_, new_n198_, new_n199_, new_n200_, new_n201_, new_n202_,
    new_n203_, new_n204_, new_n205_, new_n206_, new_n207_, new_n208_,
    new_n209_, new_n210_, new_n211_, new_n212_, new_n213_, new_n214_,
    new_n215_, new_n216_, new_n217_, new_n218_, new_n219_, new_n220_,
    new_n221_, new_n222_, new_n223_, new_n224_, new_n225_, new_n226_,
    new_n227_, new_n228_, new_n229_, new_n230_, new_n231_, new_n232_,
    new_n233_, new_n234_, new_n235_, new_n236_, new_n237_, new_n238_,
    new_n239_, new_n240_, new_n241_, new_n242_, new_n243_, new_n244_,
    new_n245_, new_n246_, new_n247_, new_n248_, new_n249_, new_n250_,
    new_n251_, new_n252_, new_n253_, new_n254_, new_n255_, new_n256_,
    new_n257_, new_n258_, new_n259_, new_n260_, new_n261_, new_n262_,
    new_n263_, new_n264_, new_n265_, new_n266_, new_n267_, new_n268_,
    new_n269_, new_n270_, new_n271_, new_n272_, new_n273_, new_n274_,
    new_n275_, new_n276_, new_n277_, new_n278_, new_n279_, new_n280_,
    new_n281_, new_n283_, new_n284_, new_n285_, new_n286_, new_n287_,
    new_n288_, new_n289_, new_n290_, new_n291_, new_n292_, new_n293_,
    new_n294_, new_n295_, new_n296_, new_n297_, new_n300_, new_n304_,
    new_n305_, new_n309_, new_n310_, new_n311_, new_n312_, new_n313_,
    new_n314_, new_n315_, new_n317_, new_n318_, new_n319_, new_n320_,
    new_n321_, new_n322_, new_n324_, new_n325_, new_n327_, new_n328_,
    new_n330_, new_n331_, new_n333_, new_n335_, new_n337_, new_n338_,
    new_n339_, new_n340_, new_n341_, new_n342_, new_n343_, new_n345_,
    new_n346_, new_n347_, new_n348_, new_n349_, new_n351_, new_n352_,
    new_n353_, new_n354_, new_n356_, new_n357_, new_n358_, new_n360_,
    new_n362_, new_n363_, new_n365_, new_n366_, new_n367_, new_n368_,
    new_n369_, new_n370_, new_n371_, new_n372_, new_n373_, new_n374_,
    new_n375_, new_n376_, new_n378_, new_n379_, new_n380_, new_n381_,
    new_n382_, new_n384_;
  INVx1_ASAP7_75t_R   g000(.A(p1), .Y(new_n59_));
  INVx1_ASAP7_75t_R   g001(.A(p0), .Y(new_n60_));
  AND3x1_ASAP7_75t_R  g002(.A(new_n59_), .B(new_n60_), .C(p16), .Y(new_n61_));
  INVx1_ASAP7_75t_R   g003(.A(new_n61_), .Y(new_n62_));
  NOR2x1_ASAP7_75t_R  g004(.A(p13), .B(p14), .Y(new_n63_));
  AND2x2_ASAP7_75t_R  g005(.A(p13), .B(p14), .Y(new_n64_));
  INVx1_ASAP7_75t_R   g006(.A(p15), .Y(new_n65_));
  OAI21x1_ASAP7_75t_R g007(.A1(new_n63_), .A2(new_n64_), .B(new_n65_), .Y(new_n66_));
  OAI21x1_ASAP7_75t_R g008(.A1(p13), .A2(p14), .B(p15), .Y(new_n67_));
  AO21x1_ASAP7_75t_R  g009(.A1(p13), .A2(p14), .B(new_n67_), .Y(new_n68_));
  AND3x1_ASAP7_75t_R  g010(.A(new_n62_), .B(new_n66_), .C(new_n68_), .Y(new_n69_));
  NOR2x1_ASAP7_75t_R  g011(.A(new_n67_), .B(new_n64_), .Y(new_n70_));
  NAND2x1_ASAP7_75t_R g012(.A(p13), .B(p14), .Y(new_n71_));
  OR3x1_ASAP7_75t_R   g013(.A(p15), .B(p13), .C(p14), .Y(new_n72_));
  OAI21x1_ASAP7_75t_R g014(.A1(p15), .A2(new_n71_), .B(new_n72_), .Y(new_n73_));
  NOR2x1_ASAP7_75t_R  g015(.A(new_n70_), .B(new_n73_), .Y(new_n74_));
  NOR2x1_ASAP7_75t_R  g016(.A(new_n62_), .B(new_n74_), .Y(new_n75_));
  INVx1_ASAP7_75t_R   g017(.A(p19), .Y(new_n76_));
  XOR2x2_ASAP7_75t_R  g018(.A(p5), .B(p18), .Y(new_n77_));
  INVx1_ASAP7_75t_R   g019(.A(p5), .Y(new_n78_));
  INVx1_ASAP7_75t_R   g020(.A(p18), .Y(new_n79_));
  AO21x1_ASAP7_75t_R  g021(.A1(p5), .A2(p18), .B(p19), .Y(new_n80_));
  AO21x1_ASAP7_75t_R  g022(.A1(new_n78_), .A2(new_n79_), .B(new_n80_), .Y(new_n81_));
  OAI21x1_ASAP7_75t_R g023(.A1(new_n76_), .A2(new_n77_), .B(new_n81_), .Y(new_n82_));
  INVx1_ASAP7_75t_R   g024(.A(new_n82_), .Y(new_n83_));
  OAI21x1_ASAP7_75t_R g025(.A1(new_n69_), .A2(new_n75_), .B(new_n83_), .Y(new_n84_));
  OR3x1_ASAP7_75t_R   g026(.A(new_n83_), .B(new_n75_), .C(new_n69_), .Y(new_n85_));
  XOR2x2_ASAP7_75t_R  g027(.A(p8), .B(p17), .Y(new_n86_));
  INVx1_ASAP7_75t_R   g028(.A(new_n86_), .Y(new_n87_));
  AO21x1_ASAP7_75t_R  g029(.A1(new_n84_), .A2(new_n85_), .B(new_n87_), .Y(new_n88_));
  OA21x2_ASAP7_75t_R  g030(.A1(new_n69_), .A2(new_n75_), .B(new_n83_), .Y(new_n89_));
  OR3x1_ASAP7_75t_R   g031(.A(new_n73_), .B(new_n61_), .C(new_n70_), .Y(new_n90_));
  NAND2x1_ASAP7_75t_R g032(.A(new_n82_), .B(new_n90_), .Y(new_n91_));
  OAI21x1_ASAP7_75t_R g033(.A1(new_n75_), .A2(new_n91_), .B(new_n87_), .Y(new_n92_));
  INVx1_ASAP7_75t_R   g034(.A(p2), .Y(new_n93_));
  OA21x2_ASAP7_75t_R  g035(.A1(new_n89_), .A2(new_n92_), .B(new_n93_), .Y(new_n94_));
  INVx1_ASAP7_75t_R   g036(.A(p20), .Y(new_n95_));
  AO21x1_ASAP7_75t_R  g037(.A1(new_n88_), .A2(new_n94_), .B(new_n95_), .Y(new_n96_));
  XOR2x2_ASAP7_75t_R  g038(.A(p6), .B(p5), .Y(new_n97_));
  XNOR2x2_ASAP7_75t_R g039(.A(p10), .B(p7), .Y(new_n98_));
  NAND2x1_ASAP7_75t_R g040(.A(new_n97_), .B(new_n98_), .Y(new_n99_));
  XOR2x2_ASAP7_75t_R  g041(.A(p10), .B(p7), .Y(new_n100_));
  XNOR2x2_ASAP7_75t_R g042(.A(p6), .B(p5), .Y(new_n101_));
  NAND2x1_ASAP7_75t_R g043(.A(new_n100_), .B(new_n101_), .Y(new_n102_));
  NAND2x1_ASAP7_75t_R g044(.A(new_n99_), .B(new_n102_), .Y(new_n103_));
  XOR2x2_ASAP7_75t_R  g045(.A(p8), .B(p9), .Y(new_n104_));
  NOR2x1_ASAP7_75t_R  g046(.A(p1), .B(p32), .Y(new_n105_));
  NAND2x1_ASAP7_75t_R g047(.A(p11), .B(new_n105_), .Y(new_n106_));
  XOR2x2_ASAP7_75t_R  g048(.A(new_n104_), .B(new_n106_), .Y(new_n107_));
  XOR2x2_ASAP7_75t_R  g049(.A(new_n103_), .B(new_n107_), .Y(new_n108_));
  INVx1_ASAP7_75t_R   g050(.A(p12), .Y(new_n109_));
  OAI21x1_ASAP7_75t_R g051(.A1(p2), .A2(new_n108_), .B(new_n109_), .Y(new_n110_));
  OR3x1_ASAP7_75t_R   g052(.A(new_n108_), .B(new_n109_), .C(p2), .Y(new_n111_));
  NAND2x1_ASAP7_75t_R g053(.A(new_n110_), .B(new_n111_), .Y(new_n112_));
  NOR2x1_ASAP7_75t_R  g054(.A(p2), .B(p20), .Y(new_n113_));
  OA21x2_ASAP7_75t_R  g055(.A1(new_n89_), .A2(new_n92_), .B(new_n113_), .Y(new_n114_));
  INVx1_ASAP7_75t_R   g056(.A(p32), .Y(new_n115_));
  OR3x1_ASAP7_75t_R   g057(.A(p2), .B(p1), .C(p3), .Y(new_n116_));
  AO21x1_ASAP7_75t_R  g058(.A1(new_n115_), .A2(p0), .B(new_n116_), .Y(new_n117_));
  NOR2x1_ASAP7_75t_R  g059(.A(p32), .B(new_n60_), .Y(new_n118_));
  OR3x1_ASAP7_75t_R   g060(.A(new_n118_), .B(p4), .C(p1), .Y(new_n119_));
  AND2x2_ASAP7_75t_R  g061(.A(new_n117_), .B(new_n119_), .Y(new_n120_));
  AOI21x1_ASAP7_75t_R g062(.A1(new_n88_), .A2(new_n114_), .B(new_n120_), .Y(new_n121_));
  NAND3x1_ASAP7_75t_R g063(.A(new_n96_), .B(new_n112_), .C(new_n121_), .Y(new_n122_));
  INVx1_ASAP7_75t_R   g064(.A(p23), .Y(new_n123_));
  AO21x1_ASAP7_75t_R  g065(.A1(new_n93_), .A2(new_n115_), .B(new_n123_), .Y(new_n124_));
  NOR2x1_ASAP7_75t_R  g066(.A(p14), .B(p22), .Y(new_n125_));
  AND2x2_ASAP7_75t_R  g067(.A(p14), .B(p22), .Y(new_n126_));
  INVx1_ASAP7_75t_R   g068(.A(p28), .Y(new_n127_));
  NOR2x1_ASAP7_75t_R  g069(.A(p1), .B(new_n127_), .Y(new_n128_));
  OAI21x1_ASAP7_75t_R g070(.A1(new_n125_), .A2(new_n126_), .B(new_n128_), .Y(new_n129_));
  NAND2x1_ASAP7_75t_R g071(.A(p28), .B(new_n59_), .Y(new_n130_));
  XOR2x2_ASAP7_75t_R  g072(.A(p14), .B(p22), .Y(new_n131_));
  NAND2x1_ASAP7_75t_R g073(.A(new_n130_), .B(new_n131_), .Y(new_n132_));
  NAND2x1_ASAP7_75t_R g074(.A(new_n129_), .B(new_n132_), .Y(new_n133_));
  NOR2x1_ASAP7_75t_R  g075(.A(p25), .B(new_n76_), .Y(new_n134_));
  INVx1_ASAP7_75t_R   g076(.A(p25), .Y(new_n135_));
  NOR2x1_ASAP7_75t_R  g077(.A(p19), .B(new_n135_), .Y(new_n136_));
  OAI21x1_ASAP7_75t_R g078(.A1(new_n134_), .A2(new_n136_), .B(p7), .Y(new_n137_));
  NAND2x1_ASAP7_75t_R g079(.A(p19), .B(new_n135_), .Y(new_n138_));
  NAND2x1_ASAP7_75t_R g080(.A(p25), .B(new_n76_), .Y(new_n139_));
  INVx1_ASAP7_75t_R   g081(.A(p7), .Y(new_n140_));
  NAND3x1_ASAP7_75t_R g082(.A(new_n138_), .B(new_n139_), .C(new_n140_), .Y(new_n141_));
  NAND2x1_ASAP7_75t_R g083(.A(new_n137_), .B(new_n141_), .Y(new_n142_));
  XOR2x2_ASAP7_75t_R  g084(.A(new_n133_), .B(new_n142_), .Y(new_n143_));
  NOR2x1_ASAP7_75t_R  g085(.A(p8), .B(p9), .Y(new_n144_));
  AND2x2_ASAP7_75t_R  g086(.A(p8), .B(p9), .Y(new_n145_));
  OAI21x1_ASAP7_75t_R g087(.A1(new_n144_), .A2(new_n145_), .B(new_n65_), .Y(new_n146_));
  OR3x1_ASAP7_75t_R   g088(.A(new_n145_), .B(new_n65_), .C(new_n144_), .Y(new_n147_));
  NAND2x1_ASAP7_75t_R g089(.A(new_n146_), .B(new_n147_), .Y(new_n148_));
  NOR2x1_ASAP7_75t_R  g090(.A(p10), .B(p17), .Y(new_n149_));
  AND2x2_ASAP7_75t_R  g091(.A(p10), .B(p17), .Y(new_n150_));
  OAI21x1_ASAP7_75t_R g092(.A1(new_n149_), .A2(new_n150_), .B(p24), .Y(new_n151_));
  OR3x1_ASAP7_75t_R   g093(.A(new_n150_), .B(p24), .C(new_n149_), .Y(new_n152_));
  NAND2x1_ASAP7_75t_R g094(.A(new_n151_), .B(new_n152_), .Y(new_n153_));
  XNOR2x2_ASAP7_75t_R g095(.A(new_n148_), .B(new_n153_), .Y(new_n154_));
  OR3x1_ASAP7_75t_R   g096(.A(new_n143_), .B(new_n154_), .C(p2), .Y(new_n155_));
  XOR2x2_ASAP7_75t_R  g097(.A(new_n148_), .B(new_n153_), .Y(new_n156_));
  NOR2x1_ASAP7_75t_R  g098(.A(p19), .B(new_n140_), .Y(new_n157_));
  AO21x1_ASAP7_75t_R  g099(.A1(p19), .A2(new_n140_), .B(new_n135_), .Y(new_n158_));
  NOR2x1_ASAP7_75t_R  g100(.A(p7), .B(new_n76_), .Y(new_n159_));
  OAI21x1_ASAP7_75t_R g101(.A1(new_n157_), .A2(new_n159_), .B(new_n135_), .Y(new_n160_));
  OAI21x1_ASAP7_75t_R g102(.A1(new_n157_), .A2(new_n158_), .B(new_n160_), .Y(new_n161_));
  XOR2x2_ASAP7_75t_R  g103(.A(new_n133_), .B(new_n161_), .Y(new_n162_));
  NOR2x1_ASAP7_75t_R  g104(.A(new_n156_), .B(new_n162_), .Y(new_n163_));
  INVx1_ASAP7_75t_R   g105(.A(p29), .Y(new_n164_));
  AOI21x1_ASAP7_75t_R g106(.A1(new_n93_), .A2(new_n163_), .B(new_n164_), .Y(new_n165_));
  NAND2x1_ASAP7_75t_R g107(.A(new_n156_), .B(new_n162_), .Y(new_n166_));
  NAND2x1_ASAP7_75t_R g108(.A(new_n154_), .B(new_n143_), .Y(new_n167_));
  NAND2x1_ASAP7_75t_R g109(.A(new_n164_), .B(new_n93_), .Y(new_n168_));
  AOI21x1_ASAP7_75t_R g110(.A1(new_n166_), .A2(new_n167_), .B(new_n168_), .Y(new_n169_));
  AOI21x1_ASAP7_75t_R g111(.A1(new_n155_), .A2(new_n165_), .B(new_n169_), .Y(new_n170_));
  NOR2x1_ASAP7_75t_R  g112(.A(new_n124_), .B(new_n170_), .Y(new_n171_));
  NOR2x1_ASAP7_75t_R  g113(.A(new_n122_), .B(new_n171_), .Y(new_n172_));
  INVx1_ASAP7_75t_R   g114(.A(new_n172_), .Y(new_n173_));
  INVx1_ASAP7_75t_R   g115(.A(p21), .Y(new_n174_));
  NOR2x1_ASAP7_75t_R  g116(.A(p6), .B(new_n174_), .Y(new_n175_));
  AO21x1_ASAP7_75t_R  g117(.A1(p6), .A2(new_n174_), .B(new_n79_), .Y(new_n176_));
  INVx1_ASAP7_75t_R   g118(.A(p6), .Y(new_n177_));
  NOR2x1_ASAP7_75t_R  g119(.A(p21), .B(new_n177_), .Y(new_n178_));
  OAI21x1_ASAP7_75t_R g120(.A1(new_n175_), .A2(new_n178_), .B(new_n79_), .Y(new_n179_));
  OAI21x1_ASAP7_75t_R g121(.A1(new_n175_), .A2(new_n176_), .B(new_n179_), .Y(new_n180_));
  NOR2x1_ASAP7_75t_R  g122(.A(p1), .B(p0), .Y(new_n181_));
  NAND3x1_ASAP7_75t_R g123(.A(new_n181_), .B(p26), .C(new_n135_), .Y(new_n182_));
  AO21x1_ASAP7_75t_R  g124(.A1(p26), .A2(new_n181_), .B(new_n135_), .Y(new_n183_));
  NAND2x1_ASAP7_75t_R g125(.A(new_n182_), .B(new_n183_), .Y(new_n184_));
  XOR2x2_ASAP7_75t_R  g126(.A(new_n180_), .B(new_n184_), .Y(new_n185_));
  NAND3x1_ASAP7_75t_R g127(.A(new_n154_), .B(new_n185_), .C(new_n93_), .Y(new_n186_));
  NOR2x1_ASAP7_75t_R  g128(.A(p21), .B(new_n79_), .Y(new_n187_));
  NOR2x1_ASAP7_75t_R  g129(.A(p18), .B(new_n174_), .Y(new_n188_));
  OAI21x1_ASAP7_75t_R g130(.A1(new_n187_), .A2(new_n188_), .B(p6), .Y(new_n189_));
  NAND2x1_ASAP7_75t_R g131(.A(p18), .B(new_n174_), .Y(new_n190_));
  NAND2x1_ASAP7_75t_R g132(.A(p21), .B(new_n79_), .Y(new_n191_));
  NAND3x1_ASAP7_75t_R g133(.A(new_n190_), .B(new_n191_), .C(new_n177_), .Y(new_n192_));
  AO21x1_ASAP7_75t_R  g134(.A1(new_n189_), .A2(new_n192_), .B(new_n184_), .Y(new_n193_));
  NAND2x1_ASAP7_75t_R g135(.A(new_n184_), .B(new_n180_), .Y(new_n194_));
  NAND2x1_ASAP7_75t_R g136(.A(new_n193_), .B(new_n194_), .Y(new_n195_));
  NAND3x1_ASAP7_75t_R g137(.A(new_n156_), .B(new_n195_), .C(new_n93_), .Y(new_n196_));
  INVx1_ASAP7_75t_R   g138(.A(p27), .Y(new_n197_));
  NAND3x1_ASAP7_75t_R g139(.A(new_n186_), .B(new_n196_), .C(new_n197_), .Y(new_n198_));
  NAND2x1_ASAP7_75t_R g140(.A(new_n195_), .B(new_n156_), .Y(new_n199_));
  NAND2x1_ASAP7_75t_R g141(.A(new_n185_), .B(new_n154_), .Y(new_n200_));
  NAND2x1_ASAP7_75t_R g142(.A(p27), .B(new_n93_), .Y(new_n201_));
  AO21x1_ASAP7_75t_R  g143(.A1(new_n199_), .A2(new_n200_), .B(new_n201_), .Y(new_n202_));
  NOR3x1_ASAP7_75t_R  g144(.A(new_n73_), .B(p22), .C(new_n70_), .Y(new_n203_));
  INVx1_ASAP7_75t_R   g145(.A(p22), .Y(new_n204_));
  AOI21x1_ASAP7_75t_R g146(.A1(new_n66_), .A2(new_n68_), .B(new_n204_), .Y(new_n205_));
  NOR2x1_ASAP7_75t_R  g147(.A(p24), .B(new_n123_), .Y(new_n206_));
  INVx1_ASAP7_75t_R   g148(.A(p24), .Y(new_n207_));
  AOI21x1_ASAP7_75t_R g149(.A1(p23), .A2(new_n105_), .B(new_n207_), .Y(new_n208_));
  AOI21x1_ASAP7_75t_R g150(.A1(new_n105_), .A2(new_n206_), .B(new_n208_), .Y(new_n209_));
  OAI21x1_ASAP7_75t_R g151(.A1(new_n203_), .A2(new_n205_), .B(new_n209_), .Y(new_n210_));
  NAND3x1_ASAP7_75t_R g152(.A(new_n68_), .B(new_n66_), .C(new_n204_), .Y(new_n211_));
  OAI21x1_ASAP7_75t_R g153(.A1(new_n70_), .A2(new_n73_), .B(p22), .Y(new_n212_));
  AO21x1_ASAP7_75t_R  g154(.A1(new_n105_), .A2(new_n206_), .B(new_n208_), .Y(new_n213_));
  NAND3x1_ASAP7_75t_R g155(.A(new_n211_), .B(new_n212_), .C(new_n213_), .Y(new_n214_));
  XNOR2x2_ASAP7_75t_R g156(.A(p9), .B(p21), .Y(new_n215_));
  NAND3x1_ASAP7_75t_R g157(.A(new_n210_), .B(new_n214_), .C(new_n215_), .Y(new_n216_));
  INVx1_ASAP7_75t_R   g158(.A(p11), .Y(new_n217_));
  AO21x1_ASAP7_75t_R  g159(.A1(new_n93_), .A2(new_n115_), .B(new_n217_), .Y(new_n218_));
  INVx1_ASAP7_75t_R   g160(.A(new_n218_), .Y(new_n219_));
  NAND2x1_ASAP7_75t_R g161(.A(p23), .B(new_n105_), .Y(new_n220_));
  XOR2x2_ASAP7_75t_R  g162(.A(p24), .B(p22), .Y(new_n221_));
  NAND2x1_ASAP7_75t_R g163(.A(new_n220_), .B(new_n221_), .Y(new_n222_));
  INVx1_ASAP7_75t_R   g164(.A(new_n105_), .Y(new_n223_));
  OR3x1_ASAP7_75t_R   g165(.A(new_n221_), .B(new_n123_), .C(new_n223_), .Y(new_n224_));
  AOI21x1_ASAP7_75t_R g166(.A1(new_n222_), .A2(new_n224_), .B(new_n74_), .Y(new_n225_));
  NAND2x1_ASAP7_75t_R g167(.A(new_n66_), .B(new_n68_), .Y(new_n226_));
  NOR2x1_ASAP7_75t_R  g168(.A(new_n220_), .B(new_n221_), .Y(new_n227_));
  AND2x2_ASAP7_75t_R  g169(.A(new_n220_), .B(new_n221_), .Y(new_n228_));
  NOR3x1_ASAP7_75t_R  g170(.A(new_n226_), .B(new_n227_), .C(new_n228_), .Y(new_n229_));
  INVx1_ASAP7_75t_R   g171(.A(new_n215_), .Y(new_n230_));
  OAI21x1_ASAP7_75t_R g172(.A1(new_n225_), .A2(new_n229_), .B(new_n230_), .Y(new_n231_));
  NAND3x1_ASAP7_75t_R g173(.A(new_n216_), .B(new_n219_), .C(new_n231_), .Y(new_n232_));
  OAI21x1_ASAP7_75t_R g174(.A1(new_n227_), .A2(new_n228_), .B(new_n226_), .Y(new_n233_));
  NAND3x1_ASAP7_75t_R g175(.A(new_n74_), .B(new_n224_), .C(new_n222_), .Y(new_n234_));
  AO21x1_ASAP7_75t_R  g176(.A1(new_n233_), .A2(new_n234_), .B(new_n230_), .Y(new_n235_));
  NAND3x1_ASAP7_75t_R g177(.A(new_n234_), .B(new_n233_), .C(new_n230_), .Y(new_n236_));
  AND2x2_ASAP7_75t_R  g178(.A(new_n93_), .B(new_n218_), .Y(new_n237_));
  NAND3x1_ASAP7_75t_R g179(.A(new_n235_), .B(new_n236_), .C(new_n237_), .Y(new_n238_));
  NOR2x1_ASAP7_75t_R  g180(.A(new_n93_), .B(new_n218_), .Y(new_n239_));
  INVx1_ASAP7_75t_R   g181(.A(new_n239_), .Y(new_n240_));
  NAND3x1_ASAP7_75t_R g182(.A(new_n232_), .B(new_n238_), .C(new_n240_), .Y(new_n241_));
  AOI21x1_ASAP7_75t_R g183(.A1(new_n198_), .A2(new_n202_), .B(new_n241_), .Y(new_n242_));
  INVx1_ASAP7_75t_R   g184(.A(new_n242_), .Y(new_n243_));
  INVx1_ASAP7_75t_R   g185(.A(p26), .Y(new_n244_));
  NOR2x1_ASAP7_75t_R  g186(.A(p2), .B(p0), .Y(new_n245_));
  NOR2x1_ASAP7_75t_R  g187(.A(new_n244_), .B(new_n245_), .Y(new_n246_));
  NAND2x1_ASAP7_75t_R g188(.A(new_n189_), .B(new_n192_), .Y(new_n247_));
  NAND2x1_ASAP7_75t_R g189(.A(new_n161_), .B(new_n247_), .Y(new_n248_));
  XOR2x2_ASAP7_75t_R  g190(.A(p25), .B(p19), .Y(new_n249_));
  AND2x2_ASAP7_75t_R  g191(.A(p7), .B(new_n249_), .Y(new_n250_));
  NOR2x1_ASAP7_75t_R  g192(.A(p7), .B(new_n249_), .Y(new_n251_));
  OAI21x1_ASAP7_75t_R g193(.A1(new_n250_), .A2(new_n251_), .B(new_n180_), .Y(new_n252_));
  XNOR2x2_ASAP7_75t_R g194(.A(p5), .B(p22), .Y(new_n253_));
  NAND3x1_ASAP7_75t_R g195(.A(new_n248_), .B(new_n252_), .C(new_n253_), .Y(new_n254_));
  NOR2x1_ASAP7_75t_R  g196(.A(new_n180_), .B(new_n142_), .Y(new_n255_));
  NOR2x1_ASAP7_75t_R  g197(.A(new_n161_), .B(new_n247_), .Y(new_n256_));
  INVx1_ASAP7_75t_R   g198(.A(new_n253_), .Y(new_n257_));
  OAI21x1_ASAP7_75t_R g199(.A1(new_n255_), .A2(new_n256_), .B(new_n257_), .Y(new_n258_));
  NAND2x1_ASAP7_75t_R g200(.A(p30), .B(new_n59_), .Y(new_n259_));
  XOR2x2_ASAP7_75t_R  g201(.A(new_n259_), .B(p13), .Y(new_n260_));
  XOR2x2_ASAP7_75t_R  g202(.A(new_n148_), .B(new_n260_), .Y(new_n261_));
  AOI21x1_ASAP7_75t_R g203(.A1(new_n254_), .A2(new_n258_), .B(new_n261_), .Y(new_n262_));
  NAND3x1_ASAP7_75t_R g204(.A(new_n248_), .B(new_n252_), .C(new_n257_), .Y(new_n263_));
  OAI21x1_ASAP7_75t_R g205(.A1(new_n255_), .A2(new_n256_), .B(new_n253_), .Y(new_n264_));
  XNOR2x2_ASAP7_75t_R g206(.A(new_n260_), .B(new_n148_), .Y(new_n265_));
  AOI21x1_ASAP7_75t_R g207(.A1(new_n263_), .A2(new_n264_), .B(new_n265_), .Y(new_n266_));
  OAI21x1_ASAP7_75t_R g208(.A1(new_n262_), .A2(new_n266_), .B(new_n93_), .Y(new_n267_));
  NAND2x1_ASAP7_75t_R g209(.A(new_n246_), .B(new_n267_), .Y(new_n268_));
  INVx1_ASAP7_75t_R   g210(.A(new_n268_), .Y(new_n269_));
  OA21x2_ASAP7_75t_R  g211(.A1(new_n60_), .A2(new_n244_), .B(new_n93_), .Y(new_n270_));
  OAI21x1_ASAP7_75t_R g212(.A1(new_n262_), .A2(new_n266_), .B(new_n270_), .Y(new_n271_));
  INVx1_ASAP7_75t_R   g213(.A(new_n271_), .Y(new_n272_));
  INVx1_ASAP7_75t_R   g214(.A(p16), .Y(new_n273_));
  NOR2x1_ASAP7_75t_R  g215(.A(new_n273_), .B(new_n245_), .Y(new_n274_));
  INVx1_ASAP7_75t_R   g216(.A(new_n274_), .Y(new_n275_));
  OR3x1_ASAP7_75t_R   g217(.A(new_n269_), .B(new_n272_), .C(new_n275_), .Y(new_n276_));
  OR3x1_ASAP7_75t_R   g218(.A(new_n173_), .B(new_n243_), .C(new_n276_), .Y(new_n277_));
  OAI21x1_ASAP7_75t_R g219(.A1(new_n124_), .A2(new_n170_), .B(new_n242_), .Y(new_n278_));
  NAND2x1_ASAP7_75t_R g220(.A(new_n271_), .B(new_n268_), .Y(new_n279_));
  OR3x1_ASAP7_75t_R   g221(.A(new_n278_), .B(new_n279_), .C(new_n275_), .Y(new_n280_));
  NOR3x1_ASAP7_75t_R  g222(.A(new_n280_), .B(p14), .C(new_n122_), .Y(new_n281_));
  AOI21x1_ASAP7_75t_R g223(.A1(p14), .A2(new_n277_), .B(new_n281_), .Y(o0));
  INVx1_ASAP7_75t_R   g224(.A(new_n124_), .Y(new_n283_));
  AO21x1_ASAP7_75t_R  g225(.A1(new_n155_), .A2(new_n165_), .B(new_n169_), .Y(new_n284_));
  OAI21x1_ASAP7_75t_R g226(.A1(new_n89_), .A2(new_n92_), .B(new_n93_), .Y(new_n285_));
  AOI21x1_ASAP7_75t_R g227(.A1(new_n84_), .A2(new_n85_), .B(new_n87_), .Y(new_n286_));
  NOR3x1_ASAP7_75t_R  g228(.A(new_n285_), .B(new_n286_), .C(new_n95_), .Y(new_n287_));
  OA21x2_ASAP7_75t_R  g229(.A1(new_n286_), .A2(new_n285_), .B(new_n95_), .Y(new_n288_));
  NOR2x1_ASAP7_75t_R  g230(.A(p31), .B(p1), .Y(new_n289_));
  INVx1_ASAP7_75t_R   g231(.A(new_n289_), .Y(new_n290_));
  OR3x1_ASAP7_75t_R   g232(.A(new_n290_), .B(new_n118_), .C(p2), .Y(new_n291_));
  AND2x2_ASAP7_75t_R  g233(.A(new_n119_), .B(new_n291_), .Y(new_n292_));
  AOI21x1_ASAP7_75t_R g234(.A1(new_n110_), .A2(new_n111_), .B(new_n292_), .Y(new_n293_));
  OAI21x1_ASAP7_75t_R g235(.A1(new_n287_), .A2(new_n288_), .B(new_n293_), .Y(new_n294_));
  AOI21x1_ASAP7_75t_R g236(.A1(new_n283_), .A2(new_n284_), .B(new_n294_), .Y(new_n295_));
  AO21x1_ASAP7_75t_R  g237(.A1(new_n271_), .A2(new_n268_), .B(new_n275_), .Y(new_n296_));
  NAND3x1_ASAP7_75t_R g238(.A(new_n295_), .B(new_n242_), .C(new_n296_), .Y(new_n297_));
  XOR2x2_ASAP7_75t_R  g239(.A(new_n297_), .B(p25), .Y(o1));
  XOR2x2_ASAP7_75t_R  g240(.A(new_n297_), .B(p19), .Y(o2));
  NOR3x1_ASAP7_75t_R  g241(.A(new_n280_), .B(p24), .C(new_n122_), .Y(new_n300_));
  AOI21x1_ASAP7_75t_R g242(.A1(p24), .A2(new_n277_), .B(new_n300_), .Y(o3));
  XOR2x2_ASAP7_75t_R  g243(.A(new_n297_), .B(p7), .Y(o4));
  XOR2x2_ASAP7_75t_R  g244(.A(new_n297_), .B(p22), .Y(o5));
  AOI21x1_ASAP7_75t_R g245(.A1(new_n271_), .A2(new_n268_), .B(new_n275_), .Y(new_n304_));
  OR3x1_ASAP7_75t_R   g246(.A(new_n304_), .B(new_n278_), .C(new_n122_), .Y(new_n305_));
  XOR2x2_ASAP7_75t_R  g247(.A(new_n305_), .B(p9), .Y(o6));
  XOR2x2_ASAP7_75t_R  g248(.A(new_n305_), .B(p8), .Y(o7));
  XOR2x2_ASAP7_75t_R  g249(.A(new_n305_), .B(p15), .Y(o8));
  NAND2x1_ASAP7_75t_R g250(.A(new_n283_), .B(new_n170_), .Y(new_n309_));
  OR3x1_ASAP7_75t_R   g251(.A(new_n304_), .B(new_n243_), .C(new_n309_), .Y(new_n310_));
  OAI21x1_ASAP7_75t_R g252(.A1(new_n287_), .A2(new_n288_), .B(new_n112_), .Y(new_n311_));
  OR3x1_ASAP7_75t_R   g253(.A(new_n311_), .B(p18), .C(new_n292_), .Y(new_n312_));
  NOR2x1_ASAP7_75t_R  g254(.A(new_n294_), .B(new_n309_), .Y(new_n313_));
  NOR2x1_ASAP7_75t_R  g255(.A(new_n243_), .B(new_n304_), .Y(new_n314_));
  AO21x1_ASAP7_75t_R  g256(.A1(new_n313_), .A2(new_n314_), .B(new_n79_), .Y(new_n315_));
  OA21x2_ASAP7_75t_R  g257(.A1(new_n310_), .A2(new_n312_), .B(new_n315_), .Y(o9));
  OR3x1_ASAP7_75t_R   g258(.A(new_n285_), .B(new_n286_), .C(new_n95_), .Y(new_n317_));
  AO21x1_ASAP7_75t_R  g259(.A1(new_n88_), .A2(new_n94_), .B(p20), .Y(new_n318_));
  AO21x1_ASAP7_75t_R  g260(.A1(new_n110_), .A2(new_n111_), .B(new_n292_), .Y(new_n319_));
  AOI21x1_ASAP7_75t_R g261(.A1(new_n317_), .A2(new_n318_), .B(new_n319_), .Y(new_n320_));
  NAND2x1_ASAP7_75t_R g262(.A(new_n177_), .B(new_n320_), .Y(new_n321_));
  AO21x1_ASAP7_75t_R  g263(.A1(new_n313_), .A2(new_n314_), .B(new_n177_), .Y(new_n322_));
  OA21x2_ASAP7_75t_R  g264(.A1(new_n310_), .A2(new_n321_), .B(new_n322_), .Y(o10));
  NAND2x1_ASAP7_75t_R g265(.A(new_n174_), .B(new_n320_), .Y(new_n324_));
  AO21x1_ASAP7_75t_R  g266(.A1(new_n313_), .A2(new_n314_), .B(new_n174_), .Y(new_n325_));
  OA21x2_ASAP7_75t_R  g267(.A1(new_n310_), .A2(new_n324_), .B(new_n325_), .Y(o11));
  OR3x1_ASAP7_75t_R   g268(.A(new_n311_), .B(p5), .C(new_n292_), .Y(new_n327_));
  AO21x1_ASAP7_75t_R  g269(.A1(new_n313_), .A2(new_n314_), .B(new_n78_), .Y(new_n328_));
  OA21x2_ASAP7_75t_R  g270(.A1(new_n310_), .A2(new_n327_), .B(new_n328_), .Y(o12));
  NOR2x1_ASAP7_75t_R  g271(.A(new_n122_), .B(new_n309_), .Y(new_n330_));
  NAND2x1_ASAP7_75t_R g272(.A(new_n330_), .B(new_n314_), .Y(new_n331_));
  XOR2x2_ASAP7_75t_R  g273(.A(new_n331_), .B(p13), .Y(o13));
  NOR3x1_ASAP7_75t_R  g274(.A(new_n280_), .B(p17), .C(new_n122_), .Y(new_n333_));
  AOI21x1_ASAP7_75t_R g275(.A1(p17), .A2(new_n277_), .B(new_n333_), .Y(o14));
  NOR3x1_ASAP7_75t_R  g276(.A(new_n280_), .B(p10), .C(new_n122_), .Y(new_n335_));
  AOI21x1_ASAP7_75t_R g277(.A1(p10), .A2(new_n277_), .B(new_n335_), .Y(o15));
  AND3x1_ASAP7_75t_R  g278(.A(new_n291_), .B(new_n119_), .C(new_n117_), .Y(new_n337_));
  AOI21x1_ASAP7_75t_R g279(.A1(new_n88_), .A2(new_n114_), .B(new_n337_), .Y(new_n338_));
  NAND3x1_ASAP7_75t_R g280(.A(new_n96_), .B(new_n112_), .C(new_n338_), .Y(new_n339_));
  NOR3x1_ASAP7_75t_R  g281(.A(new_n304_), .B(new_n278_), .C(new_n339_), .Y(new_n340_));
  OR3x1_ASAP7_75t_R   g282(.A(new_n284_), .B(new_n274_), .C(new_n283_), .Y(new_n341_));
  OR3x1_ASAP7_75t_R   g283(.A(new_n279_), .B(new_n243_), .C(new_n311_), .Y(new_n342_));
  OAI21x1_ASAP7_75t_R g284(.A1(new_n341_), .A2(new_n342_), .B(new_n59_), .Y(new_n343_));
  AO21x1_ASAP7_75t_R  g285(.A1(p4), .A2(new_n340_), .B(new_n343_), .Y(o16));
  OR2x4_ASAP7_75t_R   g286(.A(new_n262_), .B(new_n266_), .Y(new_n345_));
  AND3x1_ASAP7_75t_R  g287(.A(new_n93_), .B(p0), .C(p26), .Y(new_n346_));
  AND3x1_ASAP7_75t_R  g288(.A(new_n340_), .B(new_n345_), .C(new_n346_), .Y(new_n347_));
  NOR2x1_ASAP7_75t_R  g289(.A(p4), .B(p1), .Y(new_n348_));
  AOI21x1_ASAP7_75t_R g290(.A1(new_n346_), .A2(new_n340_), .B(new_n345_), .Y(new_n349_));
  NOR3x1_ASAP7_75t_R  g291(.A(new_n347_), .B(new_n348_), .C(new_n349_), .Y(o17));
  NAND2x1_ASAP7_75t_R g292(.A(new_n166_), .B(new_n167_), .Y(new_n351_));
  AND3x1_ASAP7_75t_R  g293(.A(new_n340_), .B(p29), .C(new_n93_), .Y(new_n352_));
  AND3x1_ASAP7_75t_R  g294(.A(new_n351_), .B(p29), .C(new_n93_), .Y(new_n353_));
  AOI21x1_ASAP7_75t_R g295(.A1(new_n353_), .A2(new_n340_), .B(new_n348_), .Y(new_n354_));
  OA21x2_ASAP7_75t_R  g296(.A1(new_n351_), .A2(new_n352_), .B(new_n354_), .Y(o18));
  OAI21x1_ASAP7_75t_R g297(.A1(new_n89_), .A2(new_n92_), .B(new_n88_), .Y(new_n356_));
  AND2x2_ASAP7_75t_R  g298(.A(p20), .B(new_n340_), .Y(new_n357_));
  INVx1_ASAP7_75t_R   g299(.A(new_n348_), .Y(new_n358_));
  OA21x2_ASAP7_75t_R  g300(.A1(new_n356_), .A2(new_n357_), .B(new_n358_), .Y(o19));
  AO21x1_ASAP7_75t_R  g301(.A1(p12), .A2(new_n340_), .B(new_n108_), .Y(new_n360_));
  AND2x2_ASAP7_75t_R  g302(.A(new_n358_), .B(new_n360_), .Y(o20));
  NAND2x1_ASAP7_75t_R g303(.A(new_n236_), .B(new_n235_), .Y(new_n362_));
  AND2x2_ASAP7_75t_R  g304(.A(new_n219_), .B(new_n340_), .Y(new_n363_));
  OA21x2_ASAP7_75t_R  g305(.A1(new_n362_), .A2(new_n363_), .B(new_n358_), .Y(o21));
  AO21x1_ASAP7_75t_R  g306(.A1(p30), .A2(p31), .B(p1), .Y(new_n365_));
  INVx1_ASAP7_75t_R   g307(.A(new_n365_), .Y(new_n366_));
  AO21x1_ASAP7_75t_R  g308(.A1(new_n263_), .A2(new_n264_), .B(new_n289_), .Y(new_n367_));
  INVx1_ASAP7_75t_R   g309(.A(new_n367_), .Y(new_n368_));
  NAND2x1_ASAP7_75t_R g310(.A(new_n367_), .B(new_n320_), .Y(new_n369_));
  NOR3x1_ASAP7_75t_R  g311(.A(new_n369_), .B(new_n278_), .C(new_n304_), .Y(new_n370_));
  AOI21x1_ASAP7_75t_R g312(.A1(new_n368_), .A2(new_n297_), .B(new_n370_), .Y(new_n371_));
  AND3x1_ASAP7_75t_R  g313(.A(new_n295_), .B(new_n242_), .C(new_n296_), .Y(new_n372_));
  NOR2x1_ASAP7_75t_R  g314(.A(new_n368_), .B(new_n294_), .Y(new_n373_));
  AOI21x1_ASAP7_75t_R g315(.A1(new_n274_), .A2(new_n279_), .B(new_n278_), .Y(new_n374_));
  AOI21x1_ASAP7_75t_R g316(.A1(new_n373_), .A2(new_n374_), .B(new_n365_), .Y(new_n375_));
  OAI21x1_ASAP7_75t_R g317(.A1(new_n372_), .A2(new_n367_), .B(new_n375_), .Y(new_n376_));
  OAI21x1_ASAP7_75t_R g318(.A1(new_n366_), .A2(new_n371_), .B(new_n376_), .Y(o22));
  NOR2x1_ASAP7_75t_R  g319(.A(new_n63_), .B(new_n64_), .Y(new_n378_));
  XOR2x2_ASAP7_75t_R  g320(.A(new_n156_), .B(new_n378_), .Y(new_n379_));
  NOR2x1_ASAP7_75t_R  g321(.A(p1), .B(p28), .Y(new_n380_));
  XOR2x2_ASAP7_75t_R  g322(.A(new_n379_), .B(new_n380_), .Y(new_n381_));
  OA21x2_ASAP7_75t_R  g323(.A1(p1), .A2(p3), .B(new_n381_), .Y(new_n382_));
  XOR2x2_ASAP7_75t_R  g324(.A(new_n305_), .B(new_n382_), .Y(o23));
  AO21x1_ASAP7_75t_R  g325(.A1(p27), .A2(new_n340_), .B(new_n348_), .Y(new_n384_));
  AOI21x1_ASAP7_75t_R g326(.A1(new_n199_), .A2(new_n200_), .B(new_n384_), .Y(o24));
endmodule


