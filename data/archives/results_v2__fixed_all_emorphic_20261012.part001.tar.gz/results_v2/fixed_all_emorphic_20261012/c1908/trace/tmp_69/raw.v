// Benchmark "/tmp/" written by ABC on Mon Oct 12 15:05:34 2026

module \/tmp/  ( 
    p18, p30, p3, p24, p14, p10, p31, p13, p20, p12, p17, p23, p28, p0,
    p19, p1, p6, p4, p8, p25, p7, p29, p9, p27, p26, p21, p11, p2, p15, p5,
    p32, p22, p16,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24  );
  input  p18, p30, p3, p24, p14, p10, p31, p13, p20, p12, p17, p23, p28,
    p0, p19, p1, p6, p4, p8, p25, p7, p29, p9, p27, p26, p21, p11, p2, p15,
    p5, p32, p22, p16;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24;
  wire new_n59_, new_n60_, new_n61_, new_n62_, new_n63_, new_n64_, new_n65_,
    new_n66_, new_n67_, new_n68_, new_n69_, new_n70_, new_n71_, new_n72_,
    new_n73_, new_n74_, new_n75_, new_n76_, new_n77_, new_n78_, new_n79_,
    new_n80_, new_n81_, new_n82_, new_n83_, new_n84_, new_n85_, new_n86_,
    new_n87_, new_n88_, new_n89_, new_n90_, new_n91_, new_n92_, new_n93_,
    new_n94_, new_n95_, new_n96_, new_n97_, new_n98_, new_n99_, new_n100_,
    new_n101_, new_n102_, new_n103_, new_n104_, new_n105_, new_n106_,
    new_n107_, new_n108_, new_n109_, new_n110_, new_n111_, new_n112_,
    new_n113_, new_n114_, new_n115_, new_n116_, new_n117_, new_n118_,
    new_n119_, new_n120_, new_n121_, new_n122_, new_n123_, new_n124_,
    new_n125_, new_n126_, new_n127_, new_n128_, new_n129_, new_n130_,
    new_n131_, new_n132_, new_n133_, new_n134_, new_n135_, new_n136_,
    new_n137_, new_n138_, new_n139_, new_n140_, new_n141_, new_n142_,
    new_n143_, new_n144_, new_n145_, new_n146_, new_n147_, new_n148_,
    new_n149_, new_n150_, new_n151_, new_n152_, new_n153_, new_n154_,
    new_n155_, new_n156_, new_n157_, new_n158_, new_n159_, new_n160_,
    new_n161_, new_n162_, new_n163_, new_n164_, new_n165_, new_n166_,
    new_n167_, new_n168_, new_n169_, new_n170_, new_n171_, new_n172_,
    new_n173_, new_n174_, new_n175_, new_n176_, new_n177_, new_n178_,
    new_n179_, new_n180_, new_n181_, new_n182_, new_n183_, new_n184_,
    new_n185_, new_n186_, new_n187_, new_n188_, new_n189_, new_n190_,
    new_n191_, new_n192_, new_n193_, new_n194_, new_n195_, new_n196_,
    new_n197_, new_n198_, new_n199_, new_n200_, new_n201_, new_n202_,
    new_n203_, new_n204_, new_n205_, new_n206_, new_n207_, new_n208_,
    new_n209_, new_n210_, new_n211_, new_n212_, new_n213_, new_n214_,
    new_n215_, new_n216_, new_n217_, new_n218_, new_n219_, new_n220_,
    new_n221_, new_n222_, new_n223_, new_n224_, new_n225_, new_n226_,
    new_n227_, new_n228_, new_n229_, new_n230_, new_n231_, new_n232_,
    new_n233_, new_n234_, new_n235_, new_n236_, new_n237_, new_n238_,
    new_n239_, new_n240_, new_n241_, new_n242_, new_n243_, new_n244_,
    new_n245_, new_n246_, new_n247_, new_n248_, new_n249_, new_n250_,
    new_n251_, new_n252_, new_n253_, new_n254_, new_n255_, new_n256_,
    new_n257_, new_n258_, new_n259_, new_n260_, new_n261_, new_n262_,
    new_n263_, new_n264_, new_n265_, new_n267_, new_n268_, new_n269_,
    new_n270_, new_n271_, new_n272_, new_n273_, new_n274_, new_n275_,
    new_n276_, new_n277_, new_n278_, new_n279_, new_n280_, new_n286_,
    new_n287_, new_n288_, new_n292_, new_n293_, new_n294_, new_n295_,
    new_n296_, new_n297_, new_n298_, new_n299_, new_n300_, new_n301_,
    new_n303_, new_n304_, new_n306_, new_n307_, new_n309_, new_n310_,
    new_n312_, new_n313_, new_n314_, new_n315_, new_n316_, new_n317_,
    new_n321_, new_n322_, new_n323_, new_n324_, new_n325_, new_n326_,
    new_n327_, new_n328_, new_n330_, new_n331_, new_n332_, new_n333_,
    new_n334_, new_n335_, new_n337_, new_n338_, new_n339_, new_n340_,
    new_n341_, new_n343_, new_n345_, new_n347_, new_n348_, new_n350_,
    new_n351_, new_n352_, new_n353_, new_n354_, new_n355_, new_n356_,
    new_n357_, new_n358_, new_n359_, new_n360_, new_n362_, new_n363_,
    new_n364_, new_n365_, new_n366_, new_n368_, new_n369_;
  OA21x2_ASAP7_75t_R  g000(.A1(p0), .A2(p2), .B(p16), .Y(new_n59_));
  INVx1_ASAP7_75t_R   g001(.A(p7), .Y(new_n60_));
  NOR2x1_ASAP7_75t_R  g002(.A(p19), .B(new_n60_), .Y(new_n61_));
  INVx1_ASAP7_75t_R   g003(.A(p25), .Y(new_n62_));
  AO21x1_ASAP7_75t_R  g004(.A1(p19), .A2(new_n60_), .B(new_n62_), .Y(new_n63_));
  INVx1_ASAP7_75t_R   g005(.A(p19), .Y(new_n64_));
  NOR2x1_ASAP7_75t_R  g006(.A(p7), .B(new_n64_), .Y(new_n65_));
  OAI21x1_ASAP7_75t_R g007(.A1(new_n61_), .A2(new_n65_), .B(new_n62_), .Y(new_n66_));
  OAI21x1_ASAP7_75t_R g008(.A1(new_n61_), .A2(new_n63_), .B(new_n66_), .Y(new_n67_));
  INVx1_ASAP7_75t_R   g009(.A(p21), .Y(new_n68_));
  NOR2x1_ASAP7_75t_R  g010(.A(p6), .B(new_n68_), .Y(new_n69_));
  INVx1_ASAP7_75t_R   g011(.A(p6), .Y(new_n70_));
  NOR2x1_ASAP7_75t_R  g012(.A(p21), .B(new_n70_), .Y(new_n71_));
  OAI21x1_ASAP7_75t_R g013(.A1(new_n69_), .A2(new_n71_), .B(p18), .Y(new_n72_));
  NAND2x1_ASAP7_75t_R g014(.A(p21), .B(new_n70_), .Y(new_n73_));
  NAND2x1_ASAP7_75t_R g015(.A(p6), .B(new_n68_), .Y(new_n74_));
  INVx1_ASAP7_75t_R   g016(.A(p18), .Y(new_n75_));
  NAND3x1_ASAP7_75t_R g017(.A(new_n73_), .B(new_n74_), .C(new_n75_), .Y(new_n76_));
  NAND2x1_ASAP7_75t_R g018(.A(new_n72_), .B(new_n76_), .Y(new_n77_));
  NAND2x1_ASAP7_75t_R g019(.A(new_n67_), .B(new_n77_), .Y(new_n78_));
  XOR2x2_ASAP7_75t_R  g020(.A(p25), .B(p7), .Y(new_n79_));
  AND2x2_ASAP7_75t_R  g021(.A(p19), .B(new_n79_), .Y(new_n80_));
  NOR2x1_ASAP7_75t_R  g022(.A(p19), .B(new_n79_), .Y(new_n81_));
  AO21x1_ASAP7_75t_R  g023(.A1(p6), .A2(new_n68_), .B(new_n75_), .Y(new_n82_));
  OAI21x1_ASAP7_75t_R g024(.A1(new_n69_), .A2(new_n71_), .B(new_n75_), .Y(new_n83_));
  OAI21x1_ASAP7_75t_R g025(.A1(new_n69_), .A2(new_n82_), .B(new_n83_), .Y(new_n84_));
  OAI21x1_ASAP7_75t_R g026(.A1(new_n80_), .A2(new_n81_), .B(new_n84_), .Y(new_n85_));
  XNOR2x2_ASAP7_75t_R g027(.A(p5), .B(p22), .Y(new_n86_));
  NAND3x1_ASAP7_75t_R g028(.A(new_n78_), .B(new_n85_), .C(new_n86_), .Y(new_n87_));
  NOR2x1_ASAP7_75t_R  g029(.A(p25), .B(new_n60_), .Y(new_n88_));
  NOR2x1_ASAP7_75t_R  g030(.A(p7), .B(new_n62_), .Y(new_n89_));
  OAI21x1_ASAP7_75t_R g031(.A1(new_n88_), .A2(new_n89_), .B(p19), .Y(new_n90_));
  NAND2x1_ASAP7_75t_R g032(.A(p7), .B(new_n62_), .Y(new_n91_));
  NAND2x1_ASAP7_75t_R g033(.A(p25), .B(new_n60_), .Y(new_n92_));
  NAND3x1_ASAP7_75t_R g034(.A(new_n91_), .B(new_n92_), .C(new_n64_), .Y(new_n93_));
  NAND2x1_ASAP7_75t_R g035(.A(new_n90_), .B(new_n93_), .Y(new_n94_));
  NOR2x1_ASAP7_75t_R  g036(.A(new_n84_), .B(new_n94_), .Y(new_n95_));
  NOR2x1_ASAP7_75t_R  g037(.A(new_n67_), .B(new_n77_), .Y(new_n96_));
  INVx1_ASAP7_75t_R   g038(.A(new_n86_), .Y(new_n97_));
  OAI21x1_ASAP7_75t_R g039(.A1(new_n95_), .A2(new_n96_), .B(new_n97_), .Y(new_n98_));
  AND2x2_ASAP7_75t_R  g040(.A(p8), .B(p9), .Y(new_n99_));
  NOR2x1_ASAP7_75t_R  g041(.A(p8), .B(p9), .Y(new_n100_));
  NOR3x1_ASAP7_75t_R  g042(.A(new_n99_), .B(p15), .C(new_n100_), .Y(new_n101_));
  OA21x2_ASAP7_75t_R  g043(.A1(new_n100_), .A2(new_n99_), .B(p15), .Y(new_n102_));
  NOR2x1_ASAP7_75t_R  g044(.A(new_n101_), .B(new_n102_), .Y(new_n103_));
  INVx1_ASAP7_75t_R   g045(.A(p1), .Y(new_n104_));
  NAND2x1_ASAP7_75t_R g046(.A(p30), .B(new_n104_), .Y(new_n105_));
  XOR2x2_ASAP7_75t_R  g047(.A(new_n105_), .B(p13), .Y(new_n106_));
  XOR2x2_ASAP7_75t_R  g048(.A(new_n103_), .B(new_n106_), .Y(new_n107_));
  AOI21x1_ASAP7_75t_R g049(.A1(new_n87_), .A2(new_n98_), .B(new_n107_), .Y(new_n108_));
  NAND3x1_ASAP7_75t_R g050(.A(new_n78_), .B(new_n85_), .C(new_n97_), .Y(new_n109_));
  OAI21x1_ASAP7_75t_R g051(.A1(new_n95_), .A2(new_n96_), .B(new_n86_), .Y(new_n110_));
  XNOR2x2_ASAP7_75t_R g052(.A(new_n106_), .B(new_n103_), .Y(new_n111_));
  AOI21x1_ASAP7_75t_R g053(.A1(new_n109_), .A2(new_n110_), .B(new_n111_), .Y(new_n112_));
  INVx1_ASAP7_75t_R   g054(.A(p0), .Y(new_n113_));
  INVx1_ASAP7_75t_R   g055(.A(p26), .Y(new_n114_));
  INVx1_ASAP7_75t_R   g056(.A(p2), .Y(new_n115_));
  OA21x2_ASAP7_75t_R  g057(.A1(new_n113_), .A2(new_n114_), .B(new_n115_), .Y(new_n116_));
  OAI21x1_ASAP7_75t_R g058(.A1(new_n108_), .A2(new_n112_), .B(new_n116_), .Y(new_n117_));
  AND2x2_ASAP7_75t_R  g059(.A(new_n59_), .B(new_n117_), .Y(new_n118_));
  AO21x1_ASAP7_75t_R  g060(.A1(new_n113_), .A2(new_n115_), .B(new_n114_), .Y(new_n119_));
  INVx1_ASAP7_75t_R   g061(.A(new_n119_), .Y(new_n120_));
  OAI21x1_ASAP7_75t_R g062(.A1(new_n108_), .A2(new_n112_), .B(new_n115_), .Y(new_n121_));
  NAND2x1_ASAP7_75t_R g063(.A(new_n120_), .B(new_n121_), .Y(new_n122_));
  NOR2x1_ASAP7_75t_R  g064(.A(p0), .B(p1), .Y(new_n123_));
  NAND3x1_ASAP7_75t_R g065(.A(new_n123_), .B(new_n62_), .C(p26), .Y(new_n124_));
  AO21x1_ASAP7_75t_R  g066(.A1(p26), .A2(new_n123_), .B(new_n62_), .Y(new_n125_));
  NAND2x1_ASAP7_75t_R g067(.A(new_n124_), .B(new_n125_), .Y(new_n126_));
  XOR2x2_ASAP7_75t_R  g068(.A(new_n77_), .B(new_n126_), .Y(new_n127_));
  NOR2x1_ASAP7_75t_R  g069(.A(p24), .B(p10), .Y(new_n128_));
  AND2x2_ASAP7_75t_R  g070(.A(p24), .B(p10), .Y(new_n129_));
  OAI21x1_ASAP7_75t_R g071(.A1(new_n128_), .A2(new_n129_), .B(p17), .Y(new_n130_));
  OR3x1_ASAP7_75t_R   g072(.A(new_n129_), .B(p17), .C(new_n128_), .Y(new_n131_));
  NAND2x1_ASAP7_75t_R g073(.A(new_n130_), .B(new_n131_), .Y(new_n132_));
  XNOR2x2_ASAP7_75t_R g074(.A(new_n132_), .B(new_n103_), .Y(new_n133_));
  NAND2x1_ASAP7_75t_R g075(.A(new_n127_), .B(new_n133_), .Y(new_n134_));
  XOR2x2_ASAP7_75t_R  g076(.A(new_n103_), .B(new_n132_), .Y(new_n135_));
  XOR2x2_ASAP7_75t_R  g077(.A(new_n84_), .B(new_n126_), .Y(new_n136_));
  NAND2x1_ASAP7_75t_R g078(.A(new_n135_), .B(new_n136_), .Y(new_n137_));
  INVx1_ASAP7_75t_R   g079(.A(p27), .Y(new_n138_));
  NOR2x1_ASAP7_75t_R  g080(.A(p2), .B(new_n138_), .Y(new_n139_));
  NAND3x1_ASAP7_75t_R g081(.A(new_n134_), .B(new_n137_), .C(new_n139_), .Y(new_n140_));
  NAND3x1_ASAP7_75t_R g082(.A(new_n133_), .B(new_n136_), .C(new_n115_), .Y(new_n141_));
  NAND3x1_ASAP7_75t_R g083(.A(new_n127_), .B(new_n135_), .C(new_n115_), .Y(new_n142_));
  NAND3x1_ASAP7_75t_R g084(.A(new_n141_), .B(new_n142_), .C(new_n138_), .Y(new_n143_));
  NAND2x1_ASAP7_75t_R g085(.A(p14), .B(p13), .Y(new_n144_));
  OR3x1_ASAP7_75t_R   g086(.A(p14), .B(p13), .C(p15), .Y(new_n145_));
  OAI21x1_ASAP7_75t_R g087(.A1(p15), .A2(new_n144_), .B(new_n145_), .Y(new_n146_));
  OAI21x1_ASAP7_75t_R g088(.A1(p14), .A2(p13), .B(p15), .Y(new_n147_));
  AND2x2_ASAP7_75t_R  g089(.A(p14), .B(p13), .Y(new_n148_));
  NOR2x1_ASAP7_75t_R  g090(.A(new_n147_), .B(new_n148_), .Y(new_n149_));
  NOR3x1_ASAP7_75t_R  g091(.A(new_n146_), .B(p22), .C(new_n149_), .Y(new_n150_));
  NOR2x1_ASAP7_75t_R  g092(.A(p14), .B(p13), .Y(new_n151_));
  INVx1_ASAP7_75t_R   g093(.A(p15), .Y(new_n152_));
  OAI21x1_ASAP7_75t_R g094(.A1(new_n151_), .A2(new_n148_), .B(new_n152_), .Y(new_n153_));
  AO21x1_ASAP7_75t_R  g095(.A1(p14), .A2(p13), .B(new_n147_), .Y(new_n154_));
  INVx1_ASAP7_75t_R   g096(.A(p22), .Y(new_n155_));
  AOI21x1_ASAP7_75t_R g097(.A1(new_n153_), .A2(new_n154_), .B(new_n155_), .Y(new_n156_));
  NOR2x1_ASAP7_75t_R  g098(.A(p1), .B(p32), .Y(new_n157_));
  INVx1_ASAP7_75t_R   g099(.A(p23), .Y(new_n158_));
  NOR2x1_ASAP7_75t_R  g100(.A(p24), .B(new_n158_), .Y(new_n159_));
  INVx1_ASAP7_75t_R   g101(.A(p24), .Y(new_n160_));
  AOI21x1_ASAP7_75t_R g102(.A1(p23), .A2(new_n157_), .B(new_n160_), .Y(new_n161_));
  AOI21x1_ASAP7_75t_R g103(.A1(new_n157_), .A2(new_n159_), .B(new_n161_), .Y(new_n162_));
  OAI21x1_ASAP7_75t_R g104(.A1(new_n150_), .A2(new_n156_), .B(new_n162_), .Y(new_n163_));
  NAND3x1_ASAP7_75t_R g105(.A(new_n154_), .B(new_n153_), .C(new_n155_), .Y(new_n164_));
  OAI21x1_ASAP7_75t_R g106(.A1(new_n149_), .A2(new_n146_), .B(p22), .Y(new_n165_));
  AO21x1_ASAP7_75t_R  g107(.A1(new_n157_), .A2(new_n159_), .B(new_n161_), .Y(new_n166_));
  NAND3x1_ASAP7_75t_R g108(.A(new_n164_), .B(new_n165_), .C(new_n166_), .Y(new_n167_));
  XNOR2x2_ASAP7_75t_R g109(.A(p9), .B(p21), .Y(new_n168_));
  NAND3x1_ASAP7_75t_R g110(.A(new_n163_), .B(new_n167_), .C(new_n168_), .Y(new_n169_));
  OA21x2_ASAP7_75t_R  g111(.A1(p2), .A2(p32), .B(p11), .Y(new_n170_));
  XOR2x2_ASAP7_75t_R  g112(.A(p24), .B(p22), .Y(new_n171_));
  INVx1_ASAP7_75t_R   g113(.A(new_n157_), .Y(new_n172_));
  OR3x1_ASAP7_75t_R   g114(.A(new_n171_), .B(new_n158_), .C(new_n172_), .Y(new_n173_));
  XNOR2x2_ASAP7_75t_R g115(.A(p24), .B(p22), .Y(new_n174_));
  AO21x1_ASAP7_75t_R  g116(.A1(p23), .A2(new_n157_), .B(new_n174_), .Y(new_n175_));
  NOR2x1_ASAP7_75t_R  g117(.A(new_n149_), .B(new_n146_), .Y(new_n176_));
  AOI21x1_ASAP7_75t_R g118(.A1(new_n173_), .A2(new_n175_), .B(new_n176_), .Y(new_n177_));
  NAND2x1_ASAP7_75t_R g119(.A(new_n153_), .B(new_n154_), .Y(new_n178_));
  AND3x1_ASAP7_75t_R  g120(.A(new_n174_), .B(p23), .C(new_n157_), .Y(new_n179_));
  OA21x2_ASAP7_75t_R  g121(.A1(new_n158_), .A2(new_n172_), .B(new_n171_), .Y(new_n180_));
  NOR3x1_ASAP7_75t_R  g122(.A(new_n178_), .B(new_n179_), .C(new_n180_), .Y(new_n181_));
  INVx1_ASAP7_75t_R   g123(.A(new_n168_), .Y(new_n182_));
  OAI21x1_ASAP7_75t_R g124(.A1(new_n177_), .A2(new_n181_), .B(new_n182_), .Y(new_n183_));
  NAND3x1_ASAP7_75t_R g125(.A(new_n169_), .B(new_n170_), .C(new_n183_), .Y(new_n184_));
  OAI21x1_ASAP7_75t_R g126(.A1(new_n177_), .A2(new_n181_), .B(new_n168_), .Y(new_n185_));
  NAND3x1_ASAP7_75t_R g127(.A(new_n175_), .B(new_n176_), .C(new_n173_), .Y(new_n186_));
  OAI21x1_ASAP7_75t_R g128(.A1(new_n180_), .A2(new_n179_), .B(new_n178_), .Y(new_n187_));
  NAND3x1_ASAP7_75t_R g129(.A(new_n186_), .B(new_n187_), .C(new_n182_), .Y(new_n188_));
  NOR2x1_ASAP7_75t_R  g130(.A(p2), .B(new_n170_), .Y(new_n189_));
  NAND3x1_ASAP7_75t_R g131(.A(new_n185_), .B(new_n188_), .C(new_n189_), .Y(new_n190_));
  AND2x2_ASAP7_75t_R  g132(.A(p11), .B(p2), .Y(new_n191_));
  INVx1_ASAP7_75t_R   g133(.A(new_n191_), .Y(new_n192_));
  NAND3x1_ASAP7_75t_R g134(.A(new_n184_), .B(new_n190_), .C(new_n192_), .Y(new_n193_));
  AOI21x1_ASAP7_75t_R g135(.A1(new_n140_), .A2(new_n143_), .B(new_n193_), .Y(new_n194_));
  AND3x1_ASAP7_75t_R  g136(.A(new_n118_), .B(new_n122_), .C(new_n194_), .Y(new_n195_));
  NOR2x1_ASAP7_75t_R  g137(.A(p20), .B(p2), .Y(new_n196_));
  XOR2x2_ASAP7_75t_R  g138(.A(p17), .B(p8), .Y(new_n197_));
  XOR2x2_ASAP7_75t_R  g139(.A(new_n197_), .B(p18), .Y(new_n198_));
  AO21x1_ASAP7_75t_R  g140(.A1(new_n153_), .A2(new_n154_), .B(new_n198_), .Y(new_n199_));
  XNOR2x2_ASAP7_75t_R g141(.A(p19), .B(p5), .Y(new_n200_));
  AND3x1_ASAP7_75t_R  g142(.A(new_n113_), .B(new_n104_), .C(p16), .Y(new_n201_));
  XOR2x2_ASAP7_75t_R  g143(.A(new_n200_), .B(new_n201_), .Y(new_n202_));
  NAND2x1_ASAP7_75t_R g144(.A(new_n176_), .B(new_n198_), .Y(new_n203_));
  NAND3x1_ASAP7_75t_R g145(.A(new_n199_), .B(new_n202_), .C(new_n203_), .Y(new_n204_));
  AO21x1_ASAP7_75t_R  g146(.A1(new_n203_), .A2(new_n199_), .B(new_n202_), .Y(new_n205_));
  NAND2x1_ASAP7_75t_R g147(.A(new_n204_), .B(new_n205_), .Y(new_n206_));
  OR3x1_ASAP7_75t_R   g148(.A(p3), .B(p1), .C(p2), .Y(new_n207_));
  NOR2x1_ASAP7_75t_R  g149(.A(p1), .B(p4), .Y(new_n208_));
  INVx1_ASAP7_75t_R   g150(.A(new_n208_), .Y(new_n209_));
  NOR2x1_ASAP7_75t_R  g151(.A(p32), .B(new_n113_), .Y(new_n210_));
  AO21x1_ASAP7_75t_R  g152(.A1(new_n207_), .A2(new_n209_), .B(new_n210_), .Y(new_n211_));
  AO21x1_ASAP7_75t_R  g153(.A1(new_n196_), .A2(new_n206_), .B(new_n211_), .Y(new_n212_));
  XNOR2x2_ASAP7_75t_R g154(.A(p10), .B(p7), .Y(new_n213_));
  XOR2x2_ASAP7_75t_R  g155(.A(p6), .B(p5), .Y(new_n214_));
  XOR2x2_ASAP7_75t_R  g156(.A(new_n213_), .B(new_n214_), .Y(new_n215_));
  XOR2x2_ASAP7_75t_R  g157(.A(p8), .B(p9), .Y(new_n216_));
  NAND2x1_ASAP7_75t_R g158(.A(p11), .B(new_n157_), .Y(new_n217_));
  XOR2x2_ASAP7_75t_R  g159(.A(new_n216_), .B(new_n217_), .Y(new_n218_));
  XOR2x2_ASAP7_75t_R  g160(.A(new_n215_), .B(new_n218_), .Y(new_n219_));
  NAND3x1_ASAP7_75t_R g161(.A(new_n219_), .B(p12), .C(new_n115_), .Y(new_n220_));
  AO21x1_ASAP7_75t_R  g162(.A1(new_n115_), .A2(new_n219_), .B(p12), .Y(new_n221_));
  NAND2x1_ASAP7_75t_R g163(.A(new_n220_), .B(new_n221_), .Y(new_n222_));
  OR3x1_ASAP7_75t_R   g164(.A(new_n146_), .B(new_n201_), .C(new_n149_), .Y(new_n223_));
  INVx1_ASAP7_75t_R   g165(.A(new_n201_), .Y(new_n224_));
  AO21x1_ASAP7_75t_R  g166(.A1(new_n153_), .A2(new_n154_), .B(new_n224_), .Y(new_n225_));
  XOR2x2_ASAP7_75t_R  g167(.A(p18), .B(p5), .Y(new_n226_));
  INVx1_ASAP7_75t_R   g168(.A(p5), .Y(new_n227_));
  AO21x1_ASAP7_75t_R  g169(.A1(p18), .A2(p5), .B(p19), .Y(new_n228_));
  AO21x1_ASAP7_75t_R  g170(.A1(new_n75_), .A2(new_n227_), .B(new_n228_), .Y(new_n229_));
  OAI21x1_ASAP7_75t_R g171(.A1(new_n64_), .A2(new_n226_), .B(new_n229_), .Y(new_n230_));
  AOI21x1_ASAP7_75t_R g172(.A1(new_n223_), .A2(new_n225_), .B(new_n230_), .Y(new_n231_));
  AND3x1_ASAP7_75t_R  g173(.A(new_n225_), .B(new_n223_), .C(new_n230_), .Y(new_n232_));
  OA21x2_ASAP7_75t_R  g174(.A1(new_n231_), .A2(new_n232_), .B(new_n197_), .Y(new_n233_));
  NAND2x1_ASAP7_75t_R g175(.A(new_n230_), .B(new_n223_), .Y(new_n234_));
  INVx1_ASAP7_75t_R   g176(.A(new_n225_), .Y(new_n235_));
  INVx1_ASAP7_75t_R   g177(.A(new_n197_), .Y(new_n236_));
  OAI21x1_ASAP7_75t_R g178(.A1(new_n234_), .A2(new_n235_), .B(new_n236_), .Y(new_n237_));
  OAI21x1_ASAP7_75t_R g179(.A1(new_n231_), .A2(new_n237_), .B(new_n115_), .Y(new_n238_));
  OAI21x1_ASAP7_75t_R g180(.A1(new_n233_), .A2(new_n238_), .B(p20), .Y(new_n239_));
  NAND2x1_ASAP7_75t_R g181(.A(new_n222_), .B(new_n239_), .Y(new_n240_));
  NOR2x1_ASAP7_75t_R  g182(.A(new_n212_), .B(new_n240_), .Y(new_n241_));
  XOR2x2_ASAP7_75t_R  g183(.A(p14), .B(p22), .Y(new_n242_));
  NAND2x1_ASAP7_75t_R g184(.A(p28), .B(new_n104_), .Y(new_n243_));
  XOR2x2_ASAP7_75t_R  g185(.A(new_n242_), .B(new_n243_), .Y(new_n244_));
  XOR2x2_ASAP7_75t_R  g186(.A(new_n244_), .B(new_n67_), .Y(new_n245_));
  OR3x1_ASAP7_75t_R   g187(.A(new_n245_), .B(new_n133_), .C(p2), .Y(new_n246_));
  OR3x1_ASAP7_75t_R   g188(.A(new_n61_), .B(new_n65_), .C(new_n62_), .Y(new_n247_));
  AO21x1_ASAP7_75t_R  g189(.A1(new_n66_), .A2(new_n247_), .B(new_n243_), .Y(new_n248_));
  NAND3x1_ASAP7_75t_R g190(.A(new_n247_), .B(new_n66_), .C(new_n243_), .Y(new_n249_));
  NAND3x1_ASAP7_75t_R g191(.A(new_n248_), .B(new_n242_), .C(new_n249_), .Y(new_n250_));
  AOI21x1_ASAP7_75t_R g192(.A1(new_n66_), .A2(new_n247_), .B(new_n243_), .Y(new_n251_));
  AND3x1_ASAP7_75t_R  g193(.A(new_n247_), .B(new_n66_), .C(new_n243_), .Y(new_n252_));
  INVx1_ASAP7_75t_R   g194(.A(new_n242_), .Y(new_n253_));
  OAI21x1_ASAP7_75t_R g195(.A1(new_n251_), .A2(new_n252_), .B(new_n253_), .Y(new_n254_));
  AOI21x1_ASAP7_75t_R g196(.A1(new_n250_), .A2(new_n254_), .B(new_n135_), .Y(new_n255_));
  INVx1_ASAP7_75t_R   g197(.A(p29), .Y(new_n256_));
  AOI21x1_ASAP7_75t_R g198(.A1(new_n115_), .A2(new_n255_), .B(new_n256_), .Y(new_n257_));
  NAND2x1_ASAP7_75t_R g199(.A(new_n133_), .B(new_n245_), .Y(new_n258_));
  NAND3x1_ASAP7_75t_R g200(.A(new_n135_), .B(new_n254_), .C(new_n250_), .Y(new_n259_));
  NAND2x1_ASAP7_75t_R g201(.A(new_n256_), .B(new_n115_), .Y(new_n260_));
  AOI21x1_ASAP7_75t_R g202(.A1(new_n258_), .A2(new_n259_), .B(new_n260_), .Y(new_n261_));
  AOI21x1_ASAP7_75t_R g203(.A1(new_n246_), .A2(new_n257_), .B(new_n261_), .Y(new_n262_));
  NOR2x1_ASAP7_75t_R  g204(.A(p2), .B(p32), .Y(new_n263_));
  OR3x1_ASAP7_75t_R   g205(.A(new_n262_), .B(new_n158_), .C(new_n263_), .Y(new_n264_));
  NAND3x1_ASAP7_75t_R g206(.A(new_n195_), .B(new_n241_), .C(new_n264_), .Y(new_n265_));
  XOR2x2_ASAP7_75t_R  g207(.A(new_n265_), .B(p14), .Y(o0));
  INVx1_ASAP7_75t_R   g208(.A(new_n59_), .Y(new_n267_));
  AOI21x1_ASAP7_75t_R g209(.A1(new_n117_), .A2(new_n122_), .B(new_n267_), .Y(new_n268_));
  NOR2x1_ASAP7_75t_R  g210(.A(new_n158_), .B(new_n263_), .Y(new_n269_));
  INVx1_ASAP7_75t_R   g211(.A(new_n269_), .Y(new_n270_));
  OAI21x1_ASAP7_75t_R g212(.A1(new_n270_), .A2(new_n262_), .B(new_n194_), .Y(new_n271_));
  NAND2x1_ASAP7_75t_R g213(.A(new_n196_), .B(new_n206_), .Y(new_n272_));
  OR3x1_ASAP7_75t_R   g214(.A(new_n210_), .B(p1), .C(p4), .Y(new_n273_));
  NOR2x1_ASAP7_75t_R  g215(.A(p31), .B(p1), .Y(new_n274_));
  INVx1_ASAP7_75t_R   g216(.A(new_n274_), .Y(new_n275_));
  OR3x1_ASAP7_75t_R   g217(.A(new_n275_), .B(new_n210_), .C(p2), .Y(new_n276_));
  AND2x2_ASAP7_75t_R  g218(.A(new_n273_), .B(new_n276_), .Y(new_n277_));
  AOI21x1_ASAP7_75t_R g219(.A1(new_n220_), .A2(new_n221_), .B(new_n277_), .Y(new_n278_));
  NAND3x1_ASAP7_75t_R g220(.A(new_n272_), .B(new_n278_), .C(new_n239_), .Y(new_n279_));
  NOR3x1_ASAP7_75t_R  g221(.A(new_n268_), .B(new_n271_), .C(new_n279_), .Y(new_n280_));
  XOR2x2_ASAP7_75t_R  g222(.A(new_n280_), .B(new_n62_), .Y(o1));
  XOR2x2_ASAP7_75t_R  g223(.A(new_n280_), .B(new_n64_), .Y(o2));
  XOR2x2_ASAP7_75t_R  g224(.A(new_n265_), .B(p24), .Y(o3));
  XOR2x2_ASAP7_75t_R  g225(.A(new_n280_), .B(new_n60_), .Y(o4));
  XOR2x2_ASAP7_75t_R  g226(.A(new_n280_), .B(new_n155_), .Y(o5));
  NAND2x1_ASAP7_75t_R g227(.A(new_n117_), .B(new_n122_), .Y(new_n286_));
  AOI21x1_ASAP7_75t_R g228(.A1(new_n59_), .A2(new_n286_), .B(new_n271_), .Y(new_n287_));
  NAND2x1_ASAP7_75t_R g229(.A(new_n241_), .B(new_n287_), .Y(new_n288_));
  XOR2x2_ASAP7_75t_R  g230(.A(new_n288_), .B(p9), .Y(o6));
  XOR2x2_ASAP7_75t_R  g231(.A(new_n288_), .B(p8), .Y(o7));
  XOR2x2_ASAP7_75t_R  g232(.A(new_n288_), .B(p15), .Y(o8));
  AND3x1_ASAP7_75t_R  g233(.A(new_n272_), .B(new_n222_), .C(new_n239_), .Y(new_n292_));
  INVx1_ASAP7_75t_R   g234(.A(new_n277_), .Y(new_n293_));
  AND3x1_ASAP7_75t_R  g235(.A(new_n292_), .B(new_n75_), .C(new_n293_), .Y(new_n294_));
  AND2x2_ASAP7_75t_R  g236(.A(new_n269_), .B(new_n262_), .Y(new_n295_));
  INVx1_ASAP7_75t_R   g237(.A(new_n194_), .Y(new_n296_));
  NOR2x1_ASAP7_75t_R  g238(.A(new_n296_), .B(new_n268_), .Y(new_n297_));
  AND2x2_ASAP7_75t_R  g239(.A(new_n295_), .B(new_n297_), .Y(new_n298_));
  AND3x1_ASAP7_75t_R  g240(.A(new_n272_), .B(new_n278_), .C(new_n239_), .Y(new_n299_));
  AND3x1_ASAP7_75t_R  g241(.A(new_n299_), .B(new_n269_), .C(new_n262_), .Y(new_n300_));
  AOI21x1_ASAP7_75t_R g242(.A1(new_n300_), .A2(new_n297_), .B(new_n75_), .Y(new_n301_));
  AOI21x1_ASAP7_75t_R g243(.A1(new_n294_), .A2(new_n298_), .B(new_n301_), .Y(o9));
  NOR2x1_ASAP7_75t_R  g244(.A(p6), .B(new_n279_), .Y(new_n303_));
  AOI21x1_ASAP7_75t_R g245(.A1(new_n300_), .A2(new_n297_), .B(new_n70_), .Y(new_n304_));
  AOI21x1_ASAP7_75t_R g246(.A1(new_n303_), .A2(new_n298_), .B(new_n304_), .Y(o10));
  NOR2x1_ASAP7_75t_R  g247(.A(p21), .B(new_n279_), .Y(new_n306_));
  AOI21x1_ASAP7_75t_R g248(.A1(new_n300_), .A2(new_n297_), .B(new_n68_), .Y(new_n307_));
  AOI21x1_ASAP7_75t_R g249(.A1(new_n306_), .A2(new_n298_), .B(new_n307_), .Y(o11));
  AND3x1_ASAP7_75t_R  g250(.A(new_n292_), .B(new_n227_), .C(new_n293_), .Y(new_n309_));
  AOI21x1_ASAP7_75t_R g251(.A1(new_n300_), .A2(new_n297_), .B(new_n227_), .Y(new_n310_));
  AOI21x1_ASAP7_75t_R g252(.A1(new_n309_), .A2(new_n298_), .B(new_n310_), .Y(o12));
  AND3x1_ASAP7_75t_R  g253(.A(new_n297_), .B(new_n241_), .C(new_n295_), .Y(new_n312_));
  INVx1_ASAP7_75t_R   g254(.A(new_n240_), .Y(new_n313_));
  INVx1_ASAP7_75t_R   g255(.A(new_n211_), .Y(new_n314_));
  AND3x1_ASAP7_75t_R  g256(.A(new_n272_), .B(p13), .C(new_n314_), .Y(new_n315_));
  AND3x1_ASAP7_75t_R  g257(.A(new_n295_), .B(new_n313_), .C(new_n315_), .Y(new_n316_));
  NAND2x1_ASAP7_75t_R g258(.A(new_n297_), .B(new_n316_), .Y(new_n317_));
  OAI21x1_ASAP7_75t_R g259(.A1(p13), .A2(new_n312_), .B(new_n317_), .Y(o13));
  XOR2x2_ASAP7_75t_R  g260(.A(new_n265_), .B(p17), .Y(o14));
  XOR2x2_ASAP7_75t_R  g261(.A(new_n265_), .B(p10), .Y(o15));
  AND3x1_ASAP7_75t_R  g262(.A(new_n276_), .B(new_n211_), .C(new_n273_), .Y(new_n321_));
  AOI21x1_ASAP7_75t_R g263(.A1(new_n196_), .A2(new_n206_), .B(new_n321_), .Y(new_n322_));
  NAND3x1_ASAP7_75t_R g264(.A(new_n322_), .B(new_n222_), .C(new_n239_), .Y(new_n323_));
  NOR3x1_ASAP7_75t_R  g265(.A(new_n268_), .B(new_n271_), .C(new_n323_), .Y(new_n324_));
  AND2x2_ASAP7_75t_R  g266(.A(p4), .B(new_n324_), .Y(new_n325_));
  AND3x1_ASAP7_75t_R  g267(.A(new_n117_), .B(new_n267_), .C(new_n270_), .Y(new_n326_));
  AND3x1_ASAP7_75t_R  g268(.A(new_n326_), .B(new_n122_), .C(new_n262_), .Y(new_n327_));
  AND3x1_ASAP7_75t_R  g269(.A(new_n327_), .B(new_n292_), .C(new_n194_), .Y(new_n328_));
  OR3x1_ASAP7_75t_R   g270(.A(new_n325_), .B(p1), .C(new_n328_), .Y(o16));
  NOR2x1_ASAP7_75t_R  g271(.A(new_n119_), .B(new_n121_), .Y(new_n330_));
  AO21x1_ASAP7_75t_R  g272(.A1(new_n330_), .A2(new_n324_), .B(new_n208_), .Y(new_n331_));
  OR3x1_ASAP7_75t_R   g273(.A(new_n113_), .B(new_n114_), .C(p2), .Y(new_n332_));
  OR3x1_ASAP7_75t_R   g274(.A(new_n268_), .B(new_n271_), .C(new_n323_), .Y(new_n333_));
  NOR2x1_ASAP7_75t_R  g275(.A(new_n108_), .B(new_n112_), .Y(new_n334_));
  OA21x2_ASAP7_75t_R  g276(.A1(new_n332_), .A2(new_n333_), .B(new_n334_), .Y(new_n335_));
  NOR2x1_ASAP7_75t_R  g277(.A(new_n331_), .B(new_n335_), .Y(o17));
  NAND2x1_ASAP7_75t_R g278(.A(new_n258_), .B(new_n259_), .Y(new_n337_));
  INVx1_ASAP7_75t_R   g279(.A(new_n337_), .Y(new_n338_));
  OR3x1_ASAP7_75t_R   g280(.A(new_n333_), .B(new_n256_), .C(p2), .Y(new_n339_));
  AND3x1_ASAP7_75t_R  g281(.A(new_n337_), .B(p29), .C(new_n115_), .Y(new_n340_));
  AO21x1_ASAP7_75t_R  g282(.A1(new_n340_), .A2(new_n324_), .B(new_n208_), .Y(new_n341_));
  AOI21x1_ASAP7_75t_R g283(.A1(new_n338_), .A2(new_n339_), .B(new_n341_), .Y(o18));
  NAND2x1_ASAP7_75t_R g284(.A(p20), .B(new_n324_), .Y(new_n343_));
  AOI21x1_ASAP7_75t_R g285(.A1(new_n206_), .A2(new_n343_), .B(new_n208_), .Y(o19));
  NAND2x1_ASAP7_75t_R g286(.A(p12), .B(new_n324_), .Y(new_n345_));
  AOI21x1_ASAP7_75t_R g287(.A1(new_n219_), .A2(new_n345_), .B(new_n208_), .Y(o20));
  NAND2x1_ASAP7_75t_R g288(.A(new_n188_), .B(new_n185_), .Y(new_n347_));
  AO21x1_ASAP7_75t_R  g289(.A1(new_n170_), .A2(new_n324_), .B(new_n347_), .Y(new_n348_));
  AND2x2_ASAP7_75t_R  g290(.A(new_n209_), .B(new_n348_), .Y(o21));
  AO21x1_ASAP7_75t_R  g291(.A1(p30), .A2(p31), .B(p1), .Y(new_n350_));
  INVx1_ASAP7_75t_R   g292(.A(new_n350_), .Y(new_n351_));
  OR3x1_ASAP7_75t_R   g293(.A(new_n268_), .B(new_n271_), .C(new_n279_), .Y(new_n352_));
  AND3x1_ASAP7_75t_R  g294(.A(new_n98_), .B(new_n87_), .C(new_n275_), .Y(new_n353_));
  INVx1_ASAP7_75t_R   g295(.A(new_n353_), .Y(new_n354_));
  NAND2x1_ASAP7_75t_R g296(.A(new_n354_), .B(new_n299_), .Y(new_n355_));
  NOR3x1_ASAP7_75t_R  g297(.A(new_n355_), .B(new_n271_), .C(new_n268_), .Y(new_n356_));
  AOI21x1_ASAP7_75t_R g298(.A1(new_n352_), .A2(new_n353_), .B(new_n356_), .Y(new_n357_));
  NOR2x1_ASAP7_75t_R  g299(.A(new_n353_), .B(new_n279_), .Y(new_n358_));
  AOI21x1_ASAP7_75t_R g300(.A1(new_n358_), .A2(new_n287_), .B(new_n350_), .Y(new_n359_));
  OAI21x1_ASAP7_75t_R g301(.A1(new_n280_), .A2(new_n354_), .B(new_n359_), .Y(new_n360_));
  OAI21x1_ASAP7_75t_R g302(.A1(new_n351_), .A2(new_n357_), .B(new_n360_), .Y(o22));
  NOR2x1_ASAP7_75t_R  g303(.A(p28), .B(p1), .Y(new_n362_));
  NOR2x1_ASAP7_75t_R  g304(.A(new_n151_), .B(new_n148_), .Y(new_n363_));
  XOR2x2_ASAP7_75t_R  g305(.A(new_n133_), .B(new_n363_), .Y(new_n364_));
  XNOR2x2_ASAP7_75t_R g306(.A(new_n362_), .B(new_n364_), .Y(new_n365_));
  OA21x2_ASAP7_75t_R  g307(.A1(p3), .A2(p1), .B(new_n365_), .Y(new_n366_));
  XOR2x2_ASAP7_75t_R  g308(.A(new_n288_), .B(new_n366_), .Y(o23));
  NAND2x1_ASAP7_75t_R g309(.A(new_n139_), .B(new_n324_), .Y(new_n368_));
  AND2x2_ASAP7_75t_R  g310(.A(new_n137_), .B(new_n134_), .Y(new_n369_));
  AND3x1_ASAP7_75t_R  g311(.A(new_n368_), .B(new_n209_), .C(new_n369_), .Y(o24));
endmodule


