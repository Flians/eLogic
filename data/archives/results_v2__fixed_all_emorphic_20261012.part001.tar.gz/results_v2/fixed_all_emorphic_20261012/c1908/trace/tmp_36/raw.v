// Benchmark "/tmp/" written by ABC on Mon Oct 12 15:05:27 2026

module \/tmp/  ( 
    p23, p14, p30, p1, p28, p11, p10, p7, p0, p8, p20, p29, p25, p9, p21,
    p27, p4, p17, p26, p19, p22, p16, p31, p32, p24, p15, p2, p3, p18, p13,
    p6, p5, p12,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24  );
  input  p23, p14, p30, p1, p28, p11, p10, p7, p0, p8, p20, p29, p25, p9,
    p21, p27, p4, p17, p26, p19, p22, p16, p31, p32, p24, p15, p2, p3, p18,
    p13, p6, p5, p12;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24;
  wire new_n59_, new_n60_, new_n61_, new_n62_, new_n63_, new_n64_, new_n65_,
    new_n66_, new_n67_, new_n68_, new_n69_, new_n70_, new_n71_, new_n72_,
    new_n73_, new_n74_, new_n75_, new_n76_, new_n77_, new_n78_, new_n79_,
    new_n80_, new_n81_, new_n82_, new_n83_, new_n84_, new_n85_, new_n86_,
    new_n87_, new_n88_, new_n89_, new_n90_, new_n91_, new_n92_, new_n93_,
    new_n94_, new_n95_, new_n96_, new_n97_, new_n98_, new_n99_, new_n100_,
    new_n101_, new_n102_, new_n103_, new_n104_, new_n105_, new_n106_,
    new_n107_, new_n108_, new_n109_, new_n110_, new_n111_, new_n112_,
    new_n113_, new_n114_, new_n115_, new_n116_, new_n117_, new_n118_,
    new_n119_, new_n120_, new_n121_, new_n122_, new_n123_, new_n124_,
    new_n125_, new_n126_, new_n127_, new_n128_, new_n129_, new_n130_,
    new_n131_, new_n132_, new_n133_, new_n134_, new_n135_, new_n136_,
    new_n137_, new_n138_, new_n139_, new_n140_, new_n141_, new_n142_,
    new_n143_, new_n144_, new_n145_, new_n146_, new_n147_, new_n148_,
    new_n149_, new_n150_, new_n151_, new_n152_, new_n153_, new_n154_,
    new_n155_, new_n156_, new_n157_, new_n158_, new_n159_, new_n160_,
    new_n161_, new_n162_, new_n163_, new_n164_, new_n165_, new_n166_,
    new_n167_, new_n168_, new_n169_, new_n170_, new_n171_, new_n172_,
    new_n173_, new_n174_, new_n175_, new_n176_, new_n177_, new_n178_,
    new_n179_, new_n180_, new_n181_, new_n182_, new_n183_, new_n184_,
    new_n185_, new_n186_, new_n187_, new_n188_, new_n189_, new_n190_,
    new_n191_, new_n192_, new_n193_, new_n194_, new_n195_, new_n196_,
    new_n197_, new_n198_, new_n199_, new_n200_, new_n201_, new_n202_,
    new_n203_, new_n204_, new_n205_, new_n206_, new_n207_, new_n208_,
    new_n209_, new_n210_, new_n211_, new_n212_, new_n213_, new_n214_,
    new_n215_, new_n216_, new_n217_, new_n218_, new_n219_, new_n220_,
    new_n221_, new_n222_, new_n223_, new_n224_, new_n225_, new_n226_,
    new_n227_, new_n228_, new_n229_, new_n230_, new_n231_, new_n232_,
    new_n233_, new_n234_, new_n235_, new_n236_, new_n237_, new_n238_,
    new_n239_, new_n240_, new_n241_, new_n242_, new_n243_, new_n244_,
    new_n245_, new_n246_, new_n247_, new_n248_, new_n249_, new_n250_,
    new_n251_, new_n252_, new_n253_, new_n254_, new_n255_, new_n256_,
    new_n257_, new_n258_, new_n259_, new_n260_, new_n261_, new_n262_,
    new_n263_, new_n265_, new_n266_, new_n267_, new_n268_, new_n269_,
    new_n270_, new_n271_, new_n272_, new_n273_, new_n274_, new_n275_,
    new_n276_, new_n279_, new_n280_, new_n284_, new_n285_, new_n289_,
    new_n290_, new_n291_, new_n292_, new_n293_, new_n294_, new_n295_,
    new_n296_, new_n298_, new_n299_, new_n300_, new_n302_, new_n303_,
    new_n305_, new_n306_, new_n307_, new_n309_, new_n310_, new_n311_,
    new_n312_, new_n314_, new_n315_, new_n317_, new_n318_, new_n320_,
    new_n321_, new_n322_, new_n323_, new_n324_, new_n325_, new_n326_,
    new_n327_, new_n328_, new_n330_, new_n331_, new_n332_, new_n333_,
    new_n334_, new_n335_, new_n337_, new_n338_, new_n339_, new_n340_,
    new_n342_, new_n344_, new_n346_, new_n347_, new_n349_, new_n350_,
    new_n351_, new_n352_, new_n353_, new_n354_, new_n355_, new_n356_,
    new_n357_, new_n358_, new_n359_, new_n361_, new_n362_, new_n363_,
    new_n364_, new_n365_, new_n367_, new_n368_;
  INVx1_ASAP7_75t_R   g000(.A(p23), .Y(new_n59_));
  NOR2x1_ASAP7_75t_R  g001(.A(p32), .B(p2), .Y(new_n60_));
  NOR2x1_ASAP7_75t_R  g002(.A(new_n59_), .B(new_n60_), .Y(new_n61_));
  INVx1_ASAP7_75t_R   g003(.A(new_n61_), .Y(new_n62_));
  XOR2x2_ASAP7_75t_R  g004(.A(p14), .B(p22), .Y(new_n63_));
  INVx1_ASAP7_75t_R   g005(.A(p28), .Y(new_n64_));
  NOR2x1_ASAP7_75t_R  g006(.A(p1), .B(new_n64_), .Y(new_n65_));
  XOR2x2_ASAP7_75t_R  g007(.A(new_n63_), .B(new_n65_), .Y(new_n66_));
  INVx1_ASAP7_75t_R   g008(.A(p19), .Y(new_n67_));
  NOR2x1_ASAP7_75t_R  g009(.A(p25), .B(new_n67_), .Y(new_n68_));
  INVx1_ASAP7_75t_R   g010(.A(p25), .Y(new_n69_));
  NOR2x1_ASAP7_75t_R  g011(.A(p19), .B(new_n69_), .Y(new_n70_));
  OAI21x1_ASAP7_75t_R g012(.A1(new_n68_), .A2(new_n70_), .B(p7), .Y(new_n71_));
  NAND2x1_ASAP7_75t_R g013(.A(p19), .B(new_n69_), .Y(new_n72_));
  NAND2x1_ASAP7_75t_R g014(.A(p25), .B(new_n67_), .Y(new_n73_));
  INVx1_ASAP7_75t_R   g015(.A(p7), .Y(new_n74_));
  NAND3x1_ASAP7_75t_R g016(.A(new_n72_), .B(new_n73_), .C(new_n74_), .Y(new_n75_));
  NAND2x1_ASAP7_75t_R g017(.A(new_n71_), .B(new_n75_), .Y(new_n76_));
  XOR2x2_ASAP7_75t_R  g018(.A(new_n66_), .B(new_n76_), .Y(new_n77_));
  NOR2x1_ASAP7_75t_R  g019(.A(p10), .B(p17), .Y(new_n78_));
  AND2x2_ASAP7_75t_R  g020(.A(p10), .B(p17), .Y(new_n79_));
  OAI21x1_ASAP7_75t_R g021(.A1(new_n78_), .A2(new_n79_), .B(p24), .Y(new_n80_));
  OR3x1_ASAP7_75t_R   g022(.A(new_n79_), .B(p24), .C(new_n78_), .Y(new_n81_));
  NAND2x1_ASAP7_75t_R g023(.A(new_n80_), .B(new_n81_), .Y(new_n82_));
  AND2x2_ASAP7_75t_R  g024(.A(p8), .B(p9), .Y(new_n83_));
  NOR2x1_ASAP7_75t_R  g025(.A(p8), .B(p9), .Y(new_n84_));
  NOR3x1_ASAP7_75t_R  g026(.A(new_n83_), .B(p15), .C(new_n84_), .Y(new_n85_));
  OA21x2_ASAP7_75t_R  g027(.A1(new_n84_), .A2(new_n83_), .B(p15), .Y(new_n86_));
  NOR2x1_ASAP7_75t_R  g028(.A(new_n85_), .B(new_n86_), .Y(new_n87_));
  XNOR2x2_ASAP7_75t_R g029(.A(new_n82_), .B(new_n87_), .Y(new_n88_));
  OR3x1_ASAP7_75t_R   g030(.A(new_n77_), .B(new_n88_), .C(p2), .Y(new_n89_));
  INVx1_ASAP7_75t_R   g031(.A(p2), .Y(new_n90_));
  AO21x1_ASAP7_75t_R  g032(.A1(new_n71_), .A2(new_n75_), .B(new_n66_), .Y(new_n91_));
  NOR2x1_ASAP7_75t_R  g033(.A(p19), .B(new_n74_), .Y(new_n92_));
  AO21x1_ASAP7_75t_R  g034(.A1(p19), .A2(new_n74_), .B(new_n69_), .Y(new_n93_));
  NOR2x1_ASAP7_75t_R  g035(.A(p7), .B(new_n67_), .Y(new_n94_));
  OAI21x1_ASAP7_75t_R g036(.A1(new_n92_), .A2(new_n94_), .B(new_n69_), .Y(new_n95_));
  OAI21x1_ASAP7_75t_R g037(.A1(new_n92_), .A2(new_n93_), .B(new_n95_), .Y(new_n96_));
  NAND2x1_ASAP7_75t_R g038(.A(new_n96_), .B(new_n66_), .Y(new_n97_));
  XOR2x2_ASAP7_75t_R  g039(.A(new_n87_), .B(new_n82_), .Y(new_n98_));
  AOI21x1_ASAP7_75t_R g040(.A1(new_n91_), .A2(new_n97_), .B(new_n98_), .Y(new_n99_));
  INVx1_ASAP7_75t_R   g041(.A(p29), .Y(new_n100_));
  AOI21x1_ASAP7_75t_R g042(.A1(new_n90_), .A2(new_n99_), .B(new_n100_), .Y(new_n101_));
  NAND3x1_ASAP7_75t_R g043(.A(new_n98_), .B(new_n91_), .C(new_n97_), .Y(new_n102_));
  NAND2x1_ASAP7_75t_R g044(.A(new_n88_), .B(new_n77_), .Y(new_n103_));
  NAND2x1_ASAP7_75t_R g045(.A(new_n100_), .B(new_n90_), .Y(new_n104_));
  AOI21x1_ASAP7_75t_R g046(.A1(new_n102_), .A2(new_n103_), .B(new_n104_), .Y(new_n105_));
  AOI21x1_ASAP7_75t_R g047(.A1(new_n89_), .A2(new_n101_), .B(new_n105_), .Y(new_n106_));
  NOR2x1_ASAP7_75t_R  g048(.A(p20), .B(p2), .Y(new_n107_));
  NAND2x1_ASAP7_75t_R g049(.A(p18), .B(p5), .Y(new_n108_));
  OR2x4_ASAP7_75t_R   g050(.A(p18), .B(p5), .Y(new_n109_));
  AO21x1_ASAP7_75t_R  g051(.A1(new_n108_), .A2(new_n109_), .B(new_n67_), .Y(new_n110_));
  NAND3x1_ASAP7_75t_R g052(.A(new_n109_), .B(new_n67_), .C(new_n108_), .Y(new_n111_));
  XNOR2x2_ASAP7_75t_R g053(.A(p8), .B(p17), .Y(new_n112_));
  AND3x1_ASAP7_75t_R  g054(.A(new_n110_), .B(new_n111_), .C(new_n112_), .Y(new_n113_));
  INVx1_ASAP7_75t_R   g055(.A(new_n112_), .Y(new_n114_));
  NAND2x1_ASAP7_75t_R g056(.A(new_n111_), .B(new_n110_), .Y(new_n115_));
  AND2x2_ASAP7_75t_R  g057(.A(new_n114_), .B(new_n115_), .Y(new_n116_));
  NAND2x1_ASAP7_75t_R g058(.A(p14), .B(p13), .Y(new_n117_));
  OR3x1_ASAP7_75t_R   g059(.A(p14), .B(p15), .C(p13), .Y(new_n118_));
  OAI21x1_ASAP7_75t_R g060(.A1(p15), .A2(new_n117_), .B(new_n118_), .Y(new_n119_));
  OAI21x1_ASAP7_75t_R g061(.A1(p14), .A2(p13), .B(p15), .Y(new_n120_));
  AND2x2_ASAP7_75t_R  g062(.A(p14), .B(p13), .Y(new_n121_));
  NOR2x1_ASAP7_75t_R  g063(.A(new_n120_), .B(new_n121_), .Y(new_n122_));
  INVx1_ASAP7_75t_R   g064(.A(p1), .Y(new_n123_));
  INVx1_ASAP7_75t_R   g065(.A(p0), .Y(new_n124_));
  AND3x1_ASAP7_75t_R  g066(.A(new_n123_), .B(new_n124_), .C(p16), .Y(new_n125_));
  OR3x1_ASAP7_75t_R   g067(.A(new_n119_), .B(new_n122_), .C(new_n125_), .Y(new_n126_));
  NOR2x1_ASAP7_75t_R  g068(.A(p14), .B(p13), .Y(new_n127_));
  INVx1_ASAP7_75t_R   g069(.A(p15), .Y(new_n128_));
  OAI21x1_ASAP7_75t_R g070(.A1(new_n127_), .A2(new_n121_), .B(new_n128_), .Y(new_n129_));
  AO21x1_ASAP7_75t_R  g071(.A1(p14), .A2(p13), .B(new_n120_), .Y(new_n130_));
  INVx1_ASAP7_75t_R   g072(.A(new_n125_), .Y(new_n131_));
  AO21x1_ASAP7_75t_R  g073(.A1(new_n129_), .A2(new_n130_), .B(new_n131_), .Y(new_n132_));
  NAND2x1_ASAP7_75t_R g074(.A(new_n126_), .B(new_n132_), .Y(new_n133_));
  OAI21x1_ASAP7_75t_R g075(.A1(new_n113_), .A2(new_n116_), .B(new_n133_), .Y(new_n134_));
  OR3x1_ASAP7_75t_R   g076(.A(new_n116_), .B(new_n133_), .C(new_n113_), .Y(new_n135_));
  NAND2x1_ASAP7_75t_R g077(.A(new_n134_), .B(new_n135_), .Y(new_n136_));
  OR3x1_ASAP7_75t_R   g078(.A(p1), .B(p2), .C(p3), .Y(new_n137_));
  NOR2x1_ASAP7_75t_R  g079(.A(p1), .B(p4), .Y(new_n138_));
  INVx1_ASAP7_75t_R   g080(.A(new_n138_), .Y(new_n139_));
  NOR2x1_ASAP7_75t_R  g081(.A(p32), .B(new_n124_), .Y(new_n140_));
  AO21x1_ASAP7_75t_R  g082(.A1(new_n137_), .A2(new_n139_), .B(new_n140_), .Y(new_n141_));
  AOI21x1_ASAP7_75t_R g083(.A1(new_n107_), .A2(new_n136_), .B(new_n141_), .Y(new_n142_));
  AOI21x1_ASAP7_75t_R g084(.A1(new_n126_), .A2(new_n132_), .B(new_n115_), .Y(new_n143_));
  AND3x1_ASAP7_75t_R  g085(.A(new_n132_), .B(new_n126_), .C(new_n115_), .Y(new_n144_));
  OA21x2_ASAP7_75t_R  g086(.A1(new_n143_), .A2(new_n144_), .B(new_n114_), .Y(new_n145_));
  NOR2x1_ASAP7_75t_R  g087(.A(new_n122_), .B(new_n119_), .Y(new_n146_));
  NOR2x1_ASAP7_75t_R  g088(.A(new_n131_), .B(new_n146_), .Y(new_n147_));
  NAND2x1_ASAP7_75t_R g089(.A(new_n126_), .B(new_n115_), .Y(new_n148_));
  OAI21x1_ASAP7_75t_R g090(.A1(new_n147_), .A2(new_n148_), .B(new_n112_), .Y(new_n149_));
  OAI21x1_ASAP7_75t_R g091(.A1(new_n143_), .A2(new_n149_), .B(new_n90_), .Y(new_n150_));
  OAI21x1_ASAP7_75t_R g092(.A1(new_n145_), .A2(new_n150_), .B(p20), .Y(new_n151_));
  INVx1_ASAP7_75t_R   g093(.A(p32), .Y(new_n152_));
  AND3x1_ASAP7_75t_R  g094(.A(new_n123_), .B(new_n152_), .C(p11), .Y(new_n153_));
  XOR2x2_ASAP7_75t_R  g095(.A(p8), .B(p9), .Y(new_n154_));
  XOR2x2_ASAP7_75t_R  g096(.A(new_n153_), .B(new_n154_), .Y(new_n155_));
  XOR2x2_ASAP7_75t_R  g097(.A(p6), .B(p5), .Y(new_n156_));
  XOR2x2_ASAP7_75t_R  g098(.A(p10), .B(p7), .Y(new_n157_));
  XOR2x2_ASAP7_75t_R  g099(.A(new_n156_), .B(new_n157_), .Y(new_n158_));
  XOR2x2_ASAP7_75t_R  g100(.A(new_n155_), .B(new_n158_), .Y(new_n159_));
  INVx1_ASAP7_75t_R   g101(.A(p12), .Y(new_n160_));
  AOI21x1_ASAP7_75t_R g102(.A1(new_n90_), .A2(new_n159_), .B(new_n160_), .Y(new_n161_));
  AND3x1_ASAP7_75t_R  g103(.A(new_n159_), .B(new_n90_), .C(new_n160_), .Y(new_n162_));
  NOR2x1_ASAP7_75t_R  g104(.A(new_n161_), .B(new_n162_), .Y(new_n163_));
  AND3x1_ASAP7_75t_R  g105(.A(new_n142_), .B(new_n151_), .C(new_n163_), .Y(new_n164_));
  OAI21x1_ASAP7_75t_R g106(.A1(new_n62_), .A2(new_n106_), .B(new_n164_), .Y(new_n165_));
  INVx1_ASAP7_75t_R   g107(.A(p6), .Y(new_n166_));
  NOR2x1_ASAP7_75t_R  g108(.A(p18), .B(new_n166_), .Y(new_n167_));
  INVx1_ASAP7_75t_R   g109(.A(p18), .Y(new_n168_));
  NOR2x1_ASAP7_75t_R  g110(.A(p6), .B(new_n168_), .Y(new_n169_));
  OAI21x1_ASAP7_75t_R g111(.A1(new_n167_), .A2(new_n169_), .B(p21), .Y(new_n170_));
  NAND2x1_ASAP7_75t_R g112(.A(p6), .B(new_n168_), .Y(new_n171_));
  NAND2x1_ASAP7_75t_R g113(.A(p18), .B(new_n166_), .Y(new_n172_));
  INVx1_ASAP7_75t_R   g114(.A(p21), .Y(new_n173_));
  NAND3x1_ASAP7_75t_R g115(.A(new_n171_), .B(new_n172_), .C(new_n173_), .Y(new_n174_));
  NAND2x1_ASAP7_75t_R g116(.A(new_n170_), .B(new_n174_), .Y(new_n175_));
  NAND2x1_ASAP7_75t_R g117(.A(new_n96_), .B(new_n175_), .Y(new_n176_));
  XOR2x2_ASAP7_75t_R  g118(.A(p25), .B(p19), .Y(new_n177_));
  AND2x2_ASAP7_75t_R  g119(.A(p7), .B(new_n177_), .Y(new_n178_));
  NOR2x1_ASAP7_75t_R  g120(.A(p7), .B(new_n177_), .Y(new_n179_));
  NOR2x1_ASAP7_75t_R  g121(.A(p6), .B(new_n173_), .Y(new_n180_));
  AO21x1_ASAP7_75t_R  g122(.A1(p6), .A2(new_n173_), .B(new_n168_), .Y(new_n181_));
  NOR2x1_ASAP7_75t_R  g123(.A(p21), .B(new_n166_), .Y(new_n182_));
  OAI21x1_ASAP7_75t_R g124(.A1(new_n180_), .A2(new_n182_), .B(new_n168_), .Y(new_n183_));
  OAI21x1_ASAP7_75t_R g125(.A1(new_n180_), .A2(new_n181_), .B(new_n183_), .Y(new_n184_));
  OAI21x1_ASAP7_75t_R g126(.A1(new_n178_), .A2(new_n179_), .B(new_n184_), .Y(new_n185_));
  XNOR2x2_ASAP7_75t_R g127(.A(p22), .B(p5), .Y(new_n186_));
  NAND3x1_ASAP7_75t_R g128(.A(new_n176_), .B(new_n185_), .C(new_n186_), .Y(new_n187_));
  NOR2x1_ASAP7_75t_R  g129(.A(new_n184_), .B(new_n76_), .Y(new_n188_));
  NOR2x1_ASAP7_75t_R  g130(.A(new_n96_), .B(new_n175_), .Y(new_n189_));
  INVx1_ASAP7_75t_R   g131(.A(new_n186_), .Y(new_n190_));
  OAI21x1_ASAP7_75t_R g132(.A1(new_n188_), .A2(new_n189_), .B(new_n190_), .Y(new_n191_));
  NAND2x1_ASAP7_75t_R g133(.A(p30), .B(new_n123_), .Y(new_n192_));
  XOR2x2_ASAP7_75t_R  g134(.A(new_n192_), .B(p13), .Y(new_n193_));
  XOR2x2_ASAP7_75t_R  g135(.A(new_n87_), .B(new_n193_), .Y(new_n194_));
  AOI21x1_ASAP7_75t_R g136(.A1(new_n187_), .A2(new_n191_), .B(new_n194_), .Y(new_n195_));
  NAND3x1_ASAP7_75t_R g137(.A(new_n176_), .B(new_n185_), .C(new_n190_), .Y(new_n196_));
  OAI21x1_ASAP7_75t_R g138(.A1(new_n188_), .A2(new_n189_), .B(new_n186_), .Y(new_n197_));
  XNOR2x2_ASAP7_75t_R g139(.A(new_n193_), .B(new_n87_), .Y(new_n198_));
  AOI21x1_ASAP7_75t_R g140(.A1(new_n196_), .A2(new_n197_), .B(new_n198_), .Y(new_n199_));
  INVx1_ASAP7_75t_R   g141(.A(p26), .Y(new_n200_));
  OA21x2_ASAP7_75t_R  g142(.A1(new_n124_), .A2(new_n200_), .B(new_n90_), .Y(new_n201_));
  OAI21x1_ASAP7_75t_R g143(.A1(new_n195_), .A2(new_n199_), .B(new_n201_), .Y(new_n202_));
  AO21x1_ASAP7_75t_R  g144(.A1(new_n124_), .A2(new_n90_), .B(new_n200_), .Y(new_n203_));
  INVx1_ASAP7_75t_R   g145(.A(new_n203_), .Y(new_n204_));
  OAI21x1_ASAP7_75t_R g146(.A1(new_n195_), .A2(new_n199_), .B(new_n90_), .Y(new_n205_));
  NAND2x1_ASAP7_75t_R g147(.A(new_n204_), .B(new_n205_), .Y(new_n206_));
  NAND2x1_ASAP7_75t_R g148(.A(new_n202_), .B(new_n206_), .Y(new_n207_));
  NOR2x1_ASAP7_75t_R  g149(.A(p1), .B(p0), .Y(new_n208_));
  AOI21x1_ASAP7_75t_R g150(.A1(p26), .A2(new_n208_), .B(new_n69_), .Y(new_n209_));
  AND3x1_ASAP7_75t_R  g151(.A(new_n208_), .B(new_n69_), .C(p26), .Y(new_n210_));
  NOR2x1_ASAP7_75t_R  g152(.A(new_n209_), .B(new_n210_), .Y(new_n211_));
  XOR2x2_ASAP7_75t_R  g153(.A(new_n184_), .B(new_n211_), .Y(new_n212_));
  NAND2x1_ASAP7_75t_R g154(.A(new_n212_), .B(new_n88_), .Y(new_n213_));
  XOR2x2_ASAP7_75t_R  g155(.A(new_n175_), .B(new_n211_), .Y(new_n214_));
  NAND2x1_ASAP7_75t_R g156(.A(new_n98_), .B(new_n214_), .Y(new_n215_));
  INVx1_ASAP7_75t_R   g157(.A(p27), .Y(new_n216_));
  NOR2x1_ASAP7_75t_R  g158(.A(p2), .B(new_n216_), .Y(new_n217_));
  NAND3x1_ASAP7_75t_R g159(.A(new_n213_), .B(new_n215_), .C(new_n217_), .Y(new_n218_));
  NAND3x1_ASAP7_75t_R g160(.A(new_n88_), .B(new_n214_), .C(new_n90_), .Y(new_n219_));
  NAND3x1_ASAP7_75t_R g161(.A(new_n212_), .B(new_n98_), .C(new_n90_), .Y(new_n220_));
  NAND3x1_ASAP7_75t_R g162(.A(new_n219_), .B(new_n220_), .C(new_n216_), .Y(new_n221_));
  NOR3x1_ASAP7_75t_R  g163(.A(new_n119_), .B(p22), .C(new_n122_), .Y(new_n222_));
  INVx1_ASAP7_75t_R   g164(.A(p22), .Y(new_n223_));
  AOI21x1_ASAP7_75t_R g165(.A1(new_n129_), .A2(new_n130_), .B(new_n223_), .Y(new_n224_));
  NOR2x1_ASAP7_75t_R  g166(.A(p1), .B(p32), .Y(new_n225_));
  NOR2x1_ASAP7_75t_R  g167(.A(p24), .B(new_n59_), .Y(new_n226_));
  INVx1_ASAP7_75t_R   g168(.A(p24), .Y(new_n227_));
  AOI21x1_ASAP7_75t_R g169(.A1(p23), .A2(new_n225_), .B(new_n227_), .Y(new_n228_));
  AOI21x1_ASAP7_75t_R g170(.A1(new_n225_), .A2(new_n226_), .B(new_n228_), .Y(new_n229_));
  OAI21x1_ASAP7_75t_R g171(.A1(new_n222_), .A2(new_n224_), .B(new_n229_), .Y(new_n230_));
  NAND3x1_ASAP7_75t_R g172(.A(new_n130_), .B(new_n129_), .C(new_n223_), .Y(new_n231_));
  OAI21x1_ASAP7_75t_R g173(.A1(new_n122_), .A2(new_n119_), .B(p22), .Y(new_n232_));
  AO21x1_ASAP7_75t_R  g174(.A1(new_n225_), .A2(new_n226_), .B(new_n228_), .Y(new_n233_));
  NAND3x1_ASAP7_75t_R g175(.A(new_n231_), .B(new_n232_), .C(new_n233_), .Y(new_n234_));
  XNOR2x2_ASAP7_75t_R g176(.A(p9), .B(p21), .Y(new_n235_));
  NAND3x1_ASAP7_75t_R g177(.A(new_n230_), .B(new_n234_), .C(new_n235_), .Y(new_n236_));
  OA21x2_ASAP7_75t_R  g178(.A1(p32), .A2(p2), .B(p11), .Y(new_n237_));
  XOR2x2_ASAP7_75t_R  g179(.A(p22), .B(p24), .Y(new_n238_));
  AO21x1_ASAP7_75t_R  g180(.A1(p23), .A2(new_n225_), .B(new_n238_), .Y(new_n239_));
  AND3x1_ASAP7_75t_R  g181(.A(new_n123_), .B(new_n152_), .C(p23), .Y(new_n240_));
  NAND2x1_ASAP7_75t_R g182(.A(new_n238_), .B(new_n240_), .Y(new_n241_));
  NAND3x1_ASAP7_75t_R g183(.A(new_n146_), .B(new_n239_), .C(new_n241_), .Y(new_n242_));
  NOR2x1_ASAP7_75t_R  g184(.A(new_n238_), .B(new_n240_), .Y(new_n243_));
  AND3x1_ASAP7_75t_R  g185(.A(new_n238_), .B(p23), .C(new_n225_), .Y(new_n244_));
  NAND2x1_ASAP7_75t_R g186(.A(new_n129_), .B(new_n130_), .Y(new_n245_));
  OAI21x1_ASAP7_75t_R g187(.A1(new_n243_), .A2(new_n244_), .B(new_n245_), .Y(new_n246_));
  INVx1_ASAP7_75t_R   g188(.A(new_n235_), .Y(new_n247_));
  NAND3x1_ASAP7_75t_R g189(.A(new_n242_), .B(new_n246_), .C(new_n247_), .Y(new_n248_));
  NAND3x1_ASAP7_75t_R g190(.A(new_n236_), .B(new_n237_), .C(new_n248_), .Y(new_n249_));
  AO21x1_ASAP7_75t_R  g191(.A1(new_n246_), .A2(new_n242_), .B(new_n235_), .Y(new_n250_));
  NAND3x1_ASAP7_75t_R g192(.A(new_n242_), .B(new_n246_), .C(new_n235_), .Y(new_n251_));
  NOR2x1_ASAP7_75t_R  g193(.A(p2), .B(new_n237_), .Y(new_n252_));
  NAND3x1_ASAP7_75t_R g194(.A(new_n250_), .B(new_n251_), .C(new_n252_), .Y(new_n253_));
  AND2x2_ASAP7_75t_R  g195(.A(p2), .B(new_n237_), .Y(new_n254_));
  INVx1_ASAP7_75t_R   g196(.A(new_n254_), .Y(new_n255_));
  NAND3x1_ASAP7_75t_R g197(.A(new_n249_), .B(new_n253_), .C(new_n255_), .Y(new_n256_));
  AOI21x1_ASAP7_75t_R g198(.A1(new_n218_), .A2(new_n221_), .B(new_n256_), .Y(new_n257_));
  INVx1_ASAP7_75t_R   g199(.A(new_n257_), .Y(new_n258_));
  OA21x2_ASAP7_75t_R  g200(.A1(p0), .A2(p2), .B(p16), .Y(new_n259_));
  INVx1_ASAP7_75t_R   g201(.A(new_n259_), .Y(new_n260_));
  OR3x1_ASAP7_75t_R   g202(.A(new_n207_), .B(new_n258_), .C(new_n260_), .Y(new_n261_));
  OAI21x1_ASAP7_75t_R g203(.A1(new_n165_), .A2(new_n261_), .B(p14), .Y(new_n262_));
  OR3x1_ASAP7_75t_R   g204(.A(new_n261_), .B(p14), .C(new_n165_), .Y(new_n263_));
  AND2x2_ASAP7_75t_R  g205(.A(new_n262_), .B(new_n263_), .Y(o0));
  AOI21x1_ASAP7_75t_R g206(.A1(new_n202_), .A2(new_n206_), .B(new_n260_), .Y(new_n265_));
  OAI21x1_ASAP7_75t_R g207(.A1(new_n62_), .A2(new_n106_), .B(new_n257_), .Y(new_n266_));
  OR3x1_ASAP7_75t_R   g208(.A(new_n140_), .B(p1), .C(p4), .Y(new_n267_));
  NOR2x1_ASAP7_75t_R  g209(.A(p1), .B(p31), .Y(new_n268_));
  INVx1_ASAP7_75t_R   g210(.A(new_n268_), .Y(new_n269_));
  OR3x1_ASAP7_75t_R   g211(.A(new_n269_), .B(new_n140_), .C(p2), .Y(new_n270_));
  AND2x2_ASAP7_75t_R  g212(.A(new_n267_), .B(new_n270_), .Y(new_n271_));
  NOR3x1_ASAP7_75t_R  g213(.A(new_n162_), .B(new_n161_), .C(new_n271_), .Y(new_n272_));
  INVx1_ASAP7_75t_R   g214(.A(new_n107_), .Y(new_n273_));
  AO21x1_ASAP7_75t_R  g215(.A1(new_n134_), .A2(new_n135_), .B(new_n273_), .Y(new_n274_));
  NAND3x1_ASAP7_75t_R g216(.A(new_n272_), .B(new_n151_), .C(new_n274_), .Y(new_n275_));
  NOR3x1_ASAP7_75t_R  g217(.A(new_n265_), .B(new_n266_), .C(new_n275_), .Y(new_n276_));
  XOR2x2_ASAP7_75t_R  g218(.A(new_n276_), .B(new_n69_), .Y(o1));
  XOR2x2_ASAP7_75t_R  g219(.A(new_n276_), .B(new_n67_), .Y(o2));
  OAI21x1_ASAP7_75t_R g220(.A1(new_n165_), .A2(new_n261_), .B(new_n227_), .Y(new_n279_));
  OR3x1_ASAP7_75t_R   g221(.A(new_n261_), .B(new_n227_), .C(new_n165_), .Y(new_n280_));
  NAND2x1_ASAP7_75t_R g222(.A(new_n279_), .B(new_n280_), .Y(o3));
  XOR2x2_ASAP7_75t_R  g223(.A(new_n276_), .B(new_n74_), .Y(o4));
  XOR2x2_ASAP7_75t_R  g224(.A(new_n276_), .B(new_n223_), .Y(o5));
  AOI21x1_ASAP7_75t_R g225(.A1(new_n259_), .A2(new_n207_), .B(new_n266_), .Y(new_n284_));
  NAND2x1_ASAP7_75t_R g226(.A(new_n164_), .B(new_n284_), .Y(new_n285_));
  XOR2x2_ASAP7_75t_R  g227(.A(new_n285_), .B(p9), .Y(o6));
  XOR2x2_ASAP7_75t_R  g228(.A(new_n285_), .B(p8), .Y(o7));
  XOR2x2_ASAP7_75t_R  g229(.A(new_n285_), .B(p15), .Y(o8));
  NAND2x1_ASAP7_75t_R g230(.A(new_n61_), .B(new_n106_), .Y(new_n289_));
  OR3x1_ASAP7_75t_R   g231(.A(new_n265_), .B(new_n258_), .C(new_n289_), .Y(new_n290_));
  AND2x2_ASAP7_75t_R  g232(.A(new_n163_), .B(new_n151_), .Y(new_n291_));
  NAND2x1_ASAP7_75t_R g233(.A(new_n274_), .B(new_n291_), .Y(new_n292_));
  OR3x1_ASAP7_75t_R   g234(.A(new_n292_), .B(p18), .C(new_n271_), .Y(new_n293_));
  NOR2x1_ASAP7_75t_R  g235(.A(new_n275_), .B(new_n289_), .Y(new_n294_));
  NOR2x1_ASAP7_75t_R  g236(.A(new_n258_), .B(new_n265_), .Y(new_n295_));
  AO21x1_ASAP7_75t_R  g237(.A1(new_n294_), .A2(new_n295_), .B(new_n168_), .Y(new_n296_));
  OA21x2_ASAP7_75t_R  g238(.A1(new_n290_), .A2(new_n293_), .B(new_n296_), .Y(o9));
  AND3x1_ASAP7_75t_R  g239(.A(new_n272_), .B(new_n151_), .C(new_n274_), .Y(new_n298_));
  NAND2x1_ASAP7_75t_R g240(.A(new_n166_), .B(new_n298_), .Y(new_n299_));
  AO21x1_ASAP7_75t_R  g241(.A1(new_n294_), .A2(new_n295_), .B(new_n166_), .Y(new_n300_));
  OA21x2_ASAP7_75t_R  g242(.A1(new_n290_), .A2(new_n299_), .B(new_n300_), .Y(o10));
  NAND2x1_ASAP7_75t_R g243(.A(new_n173_), .B(new_n298_), .Y(new_n302_));
  AO21x1_ASAP7_75t_R  g244(.A1(new_n294_), .A2(new_n295_), .B(new_n173_), .Y(new_n303_));
  OA21x2_ASAP7_75t_R  g245(.A1(new_n290_), .A2(new_n302_), .B(new_n303_), .Y(o11));
  INVx1_ASAP7_75t_R   g246(.A(p5), .Y(new_n305_));
  OAI21x1_ASAP7_75t_R g247(.A1(new_n275_), .A2(new_n290_), .B(new_n305_), .Y(new_n306_));
  OR3x1_ASAP7_75t_R   g248(.A(new_n290_), .B(new_n305_), .C(new_n275_), .Y(new_n307_));
  NAND2x1_ASAP7_75t_R g249(.A(new_n306_), .B(new_n307_), .Y(o12));
  INVx1_ASAP7_75t_R   g250(.A(new_n289_), .Y(new_n309_));
  AND3x1_ASAP7_75t_R  g251(.A(new_n295_), .B(new_n164_), .C(new_n309_), .Y(new_n310_));
  AND3x1_ASAP7_75t_R  g252(.A(new_n291_), .B(p13), .C(new_n142_), .Y(new_n311_));
  NAND3x1_ASAP7_75t_R g253(.A(new_n295_), .B(new_n309_), .C(new_n311_), .Y(new_n312_));
  OAI21x1_ASAP7_75t_R g254(.A1(p13), .A2(new_n310_), .B(new_n312_), .Y(o13));
  OAI21x1_ASAP7_75t_R g255(.A1(new_n165_), .A2(new_n261_), .B(p17), .Y(new_n314_));
  OR3x1_ASAP7_75t_R   g256(.A(new_n261_), .B(p17), .C(new_n165_), .Y(new_n315_));
  AND2x2_ASAP7_75t_R  g257(.A(new_n314_), .B(new_n315_), .Y(o14));
  OAI21x1_ASAP7_75t_R g258(.A1(new_n165_), .A2(new_n261_), .B(p10), .Y(new_n317_));
  OR3x1_ASAP7_75t_R   g259(.A(new_n261_), .B(p10), .C(new_n165_), .Y(new_n318_));
  AND2x2_ASAP7_75t_R  g260(.A(new_n317_), .B(new_n318_), .Y(o15));
  INVx1_ASAP7_75t_R   g261(.A(p4), .Y(new_n320_));
  AND3x1_ASAP7_75t_R  g262(.A(new_n270_), .B(new_n141_), .C(new_n267_), .Y(new_n321_));
  AOI21x1_ASAP7_75t_R g263(.A1(new_n107_), .A2(new_n136_), .B(new_n321_), .Y(new_n322_));
  NAND3x1_ASAP7_75t_R g264(.A(new_n322_), .B(new_n151_), .C(new_n163_), .Y(new_n323_));
  OR3x1_ASAP7_75t_R   g265(.A(new_n265_), .B(new_n266_), .C(new_n323_), .Y(new_n324_));
  AND3x1_ASAP7_75t_R  g266(.A(new_n202_), .B(new_n260_), .C(new_n62_), .Y(new_n325_));
  AND3x1_ASAP7_75t_R  g267(.A(new_n325_), .B(new_n206_), .C(new_n106_), .Y(new_n326_));
  NAND2x1_ASAP7_75t_R g268(.A(new_n257_), .B(new_n326_), .Y(new_n327_));
  OA21x2_ASAP7_75t_R  g269(.A1(new_n292_), .A2(new_n327_), .B(new_n123_), .Y(new_n328_));
  OAI21x1_ASAP7_75t_R g270(.A1(new_n320_), .A2(new_n324_), .B(new_n328_), .Y(o16));
  NOR2x1_ASAP7_75t_R  g271(.A(new_n203_), .B(new_n205_), .Y(new_n330_));
  NOR3x1_ASAP7_75t_R  g272(.A(new_n265_), .B(new_n266_), .C(new_n323_), .Y(new_n331_));
  AO21x1_ASAP7_75t_R  g273(.A1(new_n330_), .A2(new_n331_), .B(new_n138_), .Y(new_n332_));
  OR3x1_ASAP7_75t_R   g274(.A(new_n124_), .B(new_n200_), .C(p2), .Y(new_n333_));
  NOR2x1_ASAP7_75t_R  g275(.A(new_n195_), .B(new_n199_), .Y(new_n334_));
  OA21x2_ASAP7_75t_R  g276(.A1(new_n333_), .A2(new_n324_), .B(new_n334_), .Y(new_n335_));
  NOR2x1_ASAP7_75t_R  g277(.A(new_n332_), .B(new_n335_), .Y(o17));
  NOR2x1_ASAP7_75t_R  g278(.A(p2), .B(new_n100_), .Y(new_n337_));
  NAND2x1_ASAP7_75t_R g279(.A(new_n102_), .B(new_n103_), .Y(new_n338_));
  AO21x1_ASAP7_75t_R  g280(.A1(new_n337_), .A2(new_n331_), .B(new_n338_), .Y(new_n339_));
  NAND3x1_ASAP7_75t_R g281(.A(new_n331_), .B(new_n338_), .C(new_n337_), .Y(new_n340_));
  AND3x1_ASAP7_75t_R  g282(.A(new_n339_), .B(new_n139_), .C(new_n340_), .Y(o18));
  NAND2x1_ASAP7_75t_R g283(.A(p20), .B(new_n331_), .Y(new_n342_));
  AOI21x1_ASAP7_75t_R g284(.A1(new_n136_), .A2(new_n342_), .B(new_n138_), .Y(o19));
  NAND2x1_ASAP7_75t_R g285(.A(p12), .B(new_n331_), .Y(new_n344_));
  AOI21x1_ASAP7_75t_R g286(.A1(new_n159_), .A2(new_n344_), .B(new_n138_), .Y(o20));
  NAND2x1_ASAP7_75t_R g287(.A(new_n251_), .B(new_n250_), .Y(new_n346_));
  AO21x1_ASAP7_75t_R  g288(.A1(new_n237_), .A2(new_n331_), .B(new_n346_), .Y(new_n347_));
  AND2x2_ASAP7_75t_R  g289(.A(new_n139_), .B(new_n347_), .Y(o21));
  AO21x1_ASAP7_75t_R  g290(.A1(p30), .A2(p31), .B(p1), .Y(new_n349_));
  INVx1_ASAP7_75t_R   g291(.A(new_n349_), .Y(new_n350_));
  OR3x1_ASAP7_75t_R   g292(.A(new_n265_), .B(new_n266_), .C(new_n275_), .Y(new_n351_));
  AND3x1_ASAP7_75t_R  g293(.A(new_n191_), .B(new_n187_), .C(new_n269_), .Y(new_n352_));
  INVx1_ASAP7_75t_R   g294(.A(new_n352_), .Y(new_n353_));
  NAND2x1_ASAP7_75t_R g295(.A(new_n353_), .B(new_n298_), .Y(new_n354_));
  NOR3x1_ASAP7_75t_R  g296(.A(new_n354_), .B(new_n266_), .C(new_n265_), .Y(new_n355_));
  AOI21x1_ASAP7_75t_R g297(.A1(new_n351_), .A2(new_n352_), .B(new_n355_), .Y(new_n356_));
  NOR2x1_ASAP7_75t_R  g298(.A(new_n352_), .B(new_n275_), .Y(new_n357_));
  AOI21x1_ASAP7_75t_R g299(.A1(new_n357_), .A2(new_n284_), .B(new_n349_), .Y(new_n358_));
  OAI21x1_ASAP7_75t_R g300(.A1(new_n276_), .A2(new_n353_), .B(new_n358_), .Y(new_n359_));
  OAI21x1_ASAP7_75t_R g301(.A1(new_n350_), .A2(new_n356_), .B(new_n359_), .Y(o22));
  NOR2x1_ASAP7_75t_R  g302(.A(new_n127_), .B(new_n121_), .Y(new_n361_));
  XOR2x2_ASAP7_75t_R  g303(.A(new_n98_), .B(new_n361_), .Y(new_n362_));
  NOR2x1_ASAP7_75t_R  g304(.A(p1), .B(p28), .Y(new_n363_));
  XOR2x2_ASAP7_75t_R  g305(.A(new_n362_), .B(new_n363_), .Y(new_n364_));
  OA21x2_ASAP7_75t_R  g306(.A1(p1), .A2(p3), .B(new_n364_), .Y(new_n365_));
  XOR2x2_ASAP7_75t_R  g307(.A(new_n285_), .B(new_n365_), .Y(o23));
  NAND2x1_ASAP7_75t_R g308(.A(new_n217_), .B(new_n331_), .Y(new_n367_));
  AND2x2_ASAP7_75t_R  g309(.A(new_n215_), .B(new_n213_), .Y(new_n368_));
  AND3x1_ASAP7_75t_R  g310(.A(new_n367_), .B(new_n139_), .C(new_n368_), .Y(o24));
endmodule


