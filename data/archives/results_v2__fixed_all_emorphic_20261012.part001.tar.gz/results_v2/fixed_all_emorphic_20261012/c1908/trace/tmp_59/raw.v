// Benchmark "/tmp/" written by ABC on Mon Oct 12 15:05:32 2026

module \/tmp/  ( 
    p8, p28, p26, p3, p14, p31, p22, p2, p0, p17, p11, p24, p12, p20, p6,
    p30, p5, p19, p1, p4, p27, p21, p15, p16, p9, p32, p23, p7, p18, p25,
    p13, p10, p29,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24  );
  input  p8, p28, p26, p3, p14, p31, p22, p2, p0, p17, p11, p24, p12,
    p20, p6, p30, p5, p19, p1, p4, p27, p21, p15, p16, p9, p32, p23, p7,
    p18, p25, p13, p10, p29;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24;
  wire new_n59_, new_n60_, new_n61_, new_n62_, new_n63_, new_n64_, new_n65_,
    new_n66_, new_n67_, new_n68_, new_n69_, new_n70_, new_n71_, new_n72_,
    new_n73_, new_n74_, new_n75_, new_n76_, new_n77_, new_n78_, new_n79_,
    new_n80_, new_n81_, new_n82_, new_n83_, new_n84_, new_n85_, new_n86_,
    new_n87_, new_n88_, new_n89_, new_n90_, new_n91_, new_n92_, new_n93_,
    new_n94_, new_n95_, new_n96_, new_n97_, new_n98_, new_n99_, new_n100_,
    new_n101_, new_n102_, new_n103_, new_n104_, new_n105_, new_n106_,
    new_n107_, new_n108_, new_n109_, new_n110_, new_n111_, new_n112_,
    new_n113_, new_n114_, new_n115_, new_n116_, new_n117_, new_n118_,
    new_n119_, new_n120_, new_n121_, new_n122_, new_n123_, new_n124_,
    new_n125_, new_n126_, new_n127_, new_n128_, new_n129_, new_n130_,
    new_n131_, new_n132_, new_n133_, new_n134_, new_n135_, new_n136_,
    new_n137_, new_n138_, new_n139_, new_n140_, new_n141_, new_n142_,
    new_n143_, new_n144_, new_n145_, new_n146_, new_n147_, new_n148_,
    new_n149_, new_n150_, new_n151_, new_n152_, new_n153_, new_n154_,
    new_n155_, new_n156_, new_n157_, new_n158_, new_n159_, new_n160_,
    new_n161_, new_n162_, new_n163_, new_n164_, new_n165_, new_n166_,
    new_n167_, new_n168_, new_n169_, new_n170_, new_n171_, new_n172_,
    new_n173_, new_n174_, new_n175_, new_n176_, new_n177_, new_n178_,
    new_n179_, new_n180_, new_n181_, new_n182_, new_n183_, new_n184_,
    new_n185_, new_n186_, new_n187_, new_n188_, new_n189_, new_n190_,
    new_n191_, new_n192_, new_n193_, new_n194_, new_n195_, new_n196_,
    new_n197_, new_n198_, new_n199_, new_n200_, new_n201_, new_n202_,
    new_n203_, new_n204_, new_n205_, new_n206_, new_n207_, new_n208_,
    new_n209_, new_n210_, new_n211_, new_n212_, new_n213_, new_n214_,
    new_n215_, new_n216_, new_n217_, new_n218_, new_n219_, new_n220_,
    new_n221_, new_n222_, new_n223_, new_n224_, new_n225_, new_n226_,
    new_n227_, new_n228_, new_n229_, new_n230_, new_n231_, new_n232_,
    new_n233_, new_n234_, new_n235_, new_n236_, new_n237_, new_n238_,
    new_n239_, new_n240_, new_n241_, new_n242_, new_n243_, new_n244_,
    new_n245_, new_n246_, new_n247_, new_n248_, new_n249_, new_n250_,
    new_n251_, new_n252_, new_n253_, new_n254_, new_n255_, new_n257_,
    new_n258_, new_n259_, new_n260_, new_n261_, new_n262_, new_n263_,
    new_n264_, new_n265_, new_n266_, new_n267_, new_n268_, new_n269_,
    new_n270_, new_n273_, new_n274_, new_n278_, new_n279_, new_n283_,
    new_n284_, new_n285_, new_n286_, new_n287_, new_n288_, new_n289_,
    new_n290_, new_n291_, new_n293_, new_n294_, new_n295_, new_n296_,
    new_n298_, new_n299_, new_n301_, new_n302_, new_n304_, new_n305_,
    new_n306_, new_n308_, new_n309_, new_n311_, new_n312_, new_n314_,
    new_n315_, new_n316_, new_n317_, new_n318_, new_n319_, new_n320_,
    new_n321_, new_n323_, new_n324_, new_n325_, new_n326_, new_n327_,
    new_n328_, new_n330_, new_n331_, new_n332_, new_n333_, new_n334_,
    new_n335_, new_n337_, new_n339_, new_n340_, new_n342_, new_n343_,
    new_n345_, new_n346_, new_n347_, new_n348_, new_n349_, new_n350_,
    new_n351_, new_n352_, new_n353_, new_n354_, new_n355_, new_n357_,
    new_n358_, new_n359_, new_n360_, new_n361_, new_n363_;
  NOR2x1_ASAP7_75t_R  g000(.A(p8), .B(p9), .Y(new_n59_));
  AND2x2_ASAP7_75t_R  g001(.A(p8), .B(p9), .Y(new_n60_));
  INVx1_ASAP7_75t_R   g002(.A(p15), .Y(new_n61_));
  OAI21x1_ASAP7_75t_R g003(.A1(new_n59_), .A2(new_n60_), .B(new_n61_), .Y(new_n62_));
  OR3x1_ASAP7_75t_R   g004(.A(new_n60_), .B(new_n61_), .C(new_n59_), .Y(new_n63_));
  NAND2x1_ASAP7_75t_R g005(.A(new_n62_), .B(new_n63_), .Y(new_n64_));
  NOR2x1_ASAP7_75t_R  g006(.A(p17), .B(p24), .Y(new_n65_));
  AND2x2_ASAP7_75t_R  g007(.A(p17), .B(p24), .Y(new_n66_));
  OAI21x1_ASAP7_75t_R g008(.A1(new_n65_), .A2(new_n66_), .B(p10), .Y(new_n67_));
  OR3x1_ASAP7_75t_R   g009(.A(new_n66_), .B(p10), .C(new_n65_), .Y(new_n68_));
  NAND2x1_ASAP7_75t_R g010(.A(new_n67_), .B(new_n68_), .Y(new_n69_));
  XOR2x2_ASAP7_75t_R  g011(.A(new_n64_), .B(new_n69_), .Y(new_n70_));
  INVx1_ASAP7_75t_R   g012(.A(p21), .Y(new_n71_));
  NOR2x1_ASAP7_75t_R  g013(.A(p6), .B(new_n71_), .Y(new_n72_));
  INVx1_ASAP7_75t_R   g014(.A(p18), .Y(new_n73_));
  AO21x1_ASAP7_75t_R  g015(.A1(p6), .A2(new_n71_), .B(new_n73_), .Y(new_n74_));
  INVx1_ASAP7_75t_R   g016(.A(p6), .Y(new_n75_));
  NOR2x1_ASAP7_75t_R  g017(.A(p21), .B(new_n75_), .Y(new_n76_));
  OAI21x1_ASAP7_75t_R g018(.A1(new_n72_), .A2(new_n76_), .B(new_n73_), .Y(new_n77_));
  OAI21x1_ASAP7_75t_R g019(.A1(new_n72_), .A2(new_n74_), .B(new_n77_), .Y(new_n78_));
  NOR2x1_ASAP7_75t_R  g020(.A(p0), .B(p1), .Y(new_n79_));
  INVx1_ASAP7_75t_R   g021(.A(p25), .Y(new_n80_));
  NAND3x1_ASAP7_75t_R g022(.A(new_n79_), .B(p26), .C(new_n80_), .Y(new_n81_));
  AO21x1_ASAP7_75t_R  g023(.A1(p26), .A2(new_n79_), .B(new_n80_), .Y(new_n82_));
  AND2x2_ASAP7_75t_R  g024(.A(new_n81_), .B(new_n82_), .Y(new_n83_));
  XOR2x2_ASAP7_75t_R  g025(.A(new_n78_), .B(new_n83_), .Y(new_n84_));
  NOR2x1_ASAP7_75t_R  g026(.A(new_n70_), .B(new_n84_), .Y(new_n85_));
  XNOR2x2_ASAP7_75t_R g027(.A(new_n64_), .B(new_n69_), .Y(new_n86_));
  NOR2x1_ASAP7_75t_R  g028(.A(p21), .B(new_n73_), .Y(new_n87_));
  NOR2x1_ASAP7_75t_R  g029(.A(p18), .B(new_n71_), .Y(new_n88_));
  OAI21x1_ASAP7_75t_R g030(.A1(new_n87_), .A2(new_n88_), .B(p6), .Y(new_n89_));
  NAND2x1_ASAP7_75t_R g031(.A(p18), .B(new_n71_), .Y(new_n90_));
  NAND2x1_ASAP7_75t_R g032(.A(p21), .B(new_n73_), .Y(new_n91_));
  NAND3x1_ASAP7_75t_R g033(.A(new_n90_), .B(new_n91_), .C(new_n75_), .Y(new_n92_));
  NAND2x1_ASAP7_75t_R g034(.A(new_n89_), .B(new_n92_), .Y(new_n93_));
  XOR2x2_ASAP7_75t_R  g035(.A(new_n93_), .B(new_n83_), .Y(new_n94_));
  NOR2x1_ASAP7_75t_R  g036(.A(new_n86_), .B(new_n94_), .Y(new_n95_));
  INVx1_ASAP7_75t_R   g037(.A(p27), .Y(new_n96_));
  NOR2x1_ASAP7_75t_R  g038(.A(p2), .B(new_n96_), .Y(new_n97_));
  OAI21x1_ASAP7_75t_R g039(.A1(new_n85_), .A2(new_n95_), .B(new_n97_), .Y(new_n98_));
  INVx1_ASAP7_75t_R   g040(.A(p2), .Y(new_n99_));
  NAND3x1_ASAP7_75t_R g041(.A(new_n94_), .B(new_n86_), .C(new_n99_), .Y(new_n100_));
  NAND3x1_ASAP7_75t_R g042(.A(new_n84_), .B(new_n70_), .C(new_n99_), .Y(new_n101_));
  NAND3x1_ASAP7_75t_R g043(.A(new_n100_), .B(new_n101_), .C(new_n96_), .Y(new_n102_));
  INVx1_ASAP7_75t_R   g044(.A(p23), .Y(new_n103_));
  NOR2x1_ASAP7_75t_R  g045(.A(p1), .B(p32), .Y(new_n104_));
  INVx1_ASAP7_75t_R   g046(.A(new_n104_), .Y(new_n105_));
  XOR2x2_ASAP7_75t_R  g047(.A(p22), .B(p24), .Y(new_n106_));
  OA21x2_ASAP7_75t_R  g048(.A1(new_n103_), .A2(new_n105_), .B(new_n106_), .Y(new_n107_));
  XNOR2x2_ASAP7_75t_R g049(.A(p22), .B(p24), .Y(new_n108_));
  AND3x1_ASAP7_75t_R  g050(.A(new_n108_), .B(p23), .C(new_n104_), .Y(new_n109_));
  AND2x2_ASAP7_75t_R  g051(.A(p14), .B(p13), .Y(new_n110_));
  OAI21x1_ASAP7_75t_R g052(.A1(p14), .A2(p13), .B(p15), .Y(new_n111_));
  NOR3x1_ASAP7_75t_R  g053(.A(p14), .B(p15), .C(p13), .Y(new_n112_));
  AOI21x1_ASAP7_75t_R g054(.A1(new_n61_), .A2(new_n110_), .B(new_n112_), .Y(new_n113_));
  OAI21x1_ASAP7_75t_R g055(.A1(new_n110_), .A2(new_n111_), .B(new_n113_), .Y(new_n114_));
  OAI21x1_ASAP7_75t_R g056(.A1(new_n107_), .A2(new_n109_), .B(new_n114_), .Y(new_n115_));
  AO21x1_ASAP7_75t_R  g057(.A1(p23), .A2(new_n104_), .B(new_n108_), .Y(new_n116_));
  NOR2x1_ASAP7_75t_R  g058(.A(new_n111_), .B(new_n110_), .Y(new_n117_));
  AND3x1_ASAP7_75t_R  g059(.A(new_n61_), .B(p14), .C(p13), .Y(new_n118_));
  NOR3x1_ASAP7_75t_R  g060(.A(new_n117_), .B(new_n118_), .C(new_n112_), .Y(new_n119_));
  OR3x1_ASAP7_75t_R   g061(.A(new_n106_), .B(new_n103_), .C(new_n105_), .Y(new_n120_));
  NAND3x1_ASAP7_75t_R g062(.A(new_n116_), .B(new_n119_), .C(new_n120_), .Y(new_n121_));
  XNOR2x2_ASAP7_75t_R g063(.A(p21), .B(p9), .Y(new_n122_));
  AO21x1_ASAP7_75t_R  g064(.A1(new_n115_), .A2(new_n121_), .B(new_n122_), .Y(new_n123_));
  OA21x2_ASAP7_75t_R  g065(.A1(p2), .A2(p32), .B(p11), .Y(new_n124_));
  NAND3x1_ASAP7_75t_R g066(.A(new_n121_), .B(new_n115_), .C(new_n122_), .Y(new_n125_));
  NAND3x1_ASAP7_75t_R g067(.A(new_n123_), .B(new_n124_), .C(new_n125_), .Y(new_n126_));
  AOI21x1_ASAP7_75t_R g068(.A1(new_n120_), .A2(new_n116_), .B(new_n119_), .Y(new_n127_));
  NOR3x1_ASAP7_75t_R  g069(.A(new_n114_), .B(new_n109_), .C(new_n107_), .Y(new_n128_));
  OAI21x1_ASAP7_75t_R g070(.A1(new_n127_), .A2(new_n128_), .B(new_n122_), .Y(new_n129_));
  INVx1_ASAP7_75t_R   g071(.A(new_n122_), .Y(new_n130_));
  NAND3x1_ASAP7_75t_R g072(.A(new_n121_), .B(new_n115_), .C(new_n130_), .Y(new_n131_));
  NOR2x1_ASAP7_75t_R  g073(.A(p2), .B(new_n124_), .Y(new_n132_));
  NAND3x1_ASAP7_75t_R g074(.A(new_n129_), .B(new_n131_), .C(new_n132_), .Y(new_n133_));
  AND2x2_ASAP7_75t_R  g075(.A(p2), .B(p11), .Y(new_n134_));
  INVx1_ASAP7_75t_R   g076(.A(new_n134_), .Y(new_n135_));
  NAND3x1_ASAP7_75t_R g077(.A(new_n126_), .B(new_n133_), .C(new_n135_), .Y(new_n136_));
  AOI21x1_ASAP7_75t_R g078(.A1(new_n98_), .A2(new_n102_), .B(new_n136_), .Y(new_n137_));
  INVx1_ASAP7_75t_R   g079(.A(p26), .Y(new_n138_));
  NOR2x1_ASAP7_75t_R  g080(.A(p2), .B(p0), .Y(new_n139_));
  NOR2x1_ASAP7_75t_R  g081(.A(new_n138_), .B(new_n139_), .Y(new_n140_));
  INVx1_ASAP7_75t_R   g082(.A(p7), .Y(new_n141_));
  NOR2x1_ASAP7_75t_R  g083(.A(p19), .B(new_n141_), .Y(new_n142_));
  AO21x1_ASAP7_75t_R  g084(.A1(p19), .A2(new_n141_), .B(new_n80_), .Y(new_n143_));
  INVx1_ASAP7_75t_R   g085(.A(p19), .Y(new_n144_));
  NOR2x1_ASAP7_75t_R  g086(.A(p7), .B(new_n144_), .Y(new_n145_));
  OAI21x1_ASAP7_75t_R g087(.A1(new_n142_), .A2(new_n145_), .B(new_n80_), .Y(new_n146_));
  OAI21x1_ASAP7_75t_R g088(.A1(new_n142_), .A2(new_n143_), .B(new_n146_), .Y(new_n147_));
  NAND2x1_ASAP7_75t_R g089(.A(new_n147_), .B(new_n93_), .Y(new_n148_));
  XOR2x2_ASAP7_75t_R  g090(.A(p7), .B(p25), .Y(new_n149_));
  AND2x2_ASAP7_75t_R  g091(.A(p19), .B(new_n149_), .Y(new_n150_));
  NOR2x1_ASAP7_75t_R  g092(.A(p19), .B(new_n149_), .Y(new_n151_));
  OAI21x1_ASAP7_75t_R g093(.A1(new_n150_), .A2(new_n151_), .B(new_n78_), .Y(new_n152_));
  XNOR2x2_ASAP7_75t_R g094(.A(p22), .B(p5), .Y(new_n153_));
  NAND3x1_ASAP7_75t_R g095(.A(new_n148_), .B(new_n152_), .C(new_n153_), .Y(new_n154_));
  NOR2x1_ASAP7_75t_R  g096(.A(p7), .B(new_n80_), .Y(new_n155_));
  NOR2x1_ASAP7_75t_R  g097(.A(p25), .B(new_n141_), .Y(new_n156_));
  OAI21x1_ASAP7_75t_R g098(.A1(new_n155_), .A2(new_n156_), .B(p19), .Y(new_n157_));
  NAND2x1_ASAP7_75t_R g099(.A(p25), .B(new_n141_), .Y(new_n158_));
  NAND2x1_ASAP7_75t_R g100(.A(p7), .B(new_n80_), .Y(new_n159_));
  NAND3x1_ASAP7_75t_R g101(.A(new_n158_), .B(new_n159_), .C(new_n144_), .Y(new_n160_));
  NAND2x1_ASAP7_75t_R g102(.A(new_n157_), .B(new_n160_), .Y(new_n161_));
  NOR2x1_ASAP7_75t_R  g103(.A(new_n78_), .B(new_n161_), .Y(new_n162_));
  NOR2x1_ASAP7_75t_R  g104(.A(new_n147_), .B(new_n93_), .Y(new_n163_));
  INVx1_ASAP7_75t_R   g105(.A(new_n153_), .Y(new_n164_));
  OAI21x1_ASAP7_75t_R g106(.A1(new_n162_), .A2(new_n163_), .B(new_n164_), .Y(new_n165_));
  INVx1_ASAP7_75t_R   g107(.A(p1), .Y(new_n166_));
  NAND2x1_ASAP7_75t_R g108(.A(p30), .B(new_n166_), .Y(new_n167_));
  XOR2x2_ASAP7_75t_R  g109(.A(new_n167_), .B(p13), .Y(new_n168_));
  XOR2x2_ASAP7_75t_R  g110(.A(new_n64_), .B(new_n168_), .Y(new_n169_));
  AOI21x1_ASAP7_75t_R g111(.A1(new_n154_), .A2(new_n165_), .B(new_n169_), .Y(new_n170_));
  NAND3x1_ASAP7_75t_R g112(.A(new_n148_), .B(new_n152_), .C(new_n164_), .Y(new_n171_));
  OAI21x1_ASAP7_75t_R g113(.A1(new_n162_), .A2(new_n163_), .B(new_n153_), .Y(new_n172_));
  XNOR2x2_ASAP7_75t_R g114(.A(new_n168_), .B(new_n64_), .Y(new_n173_));
  AOI21x1_ASAP7_75t_R g115(.A1(new_n171_), .A2(new_n172_), .B(new_n173_), .Y(new_n174_));
  OAI21x1_ASAP7_75t_R g116(.A1(new_n170_), .A2(new_n174_), .B(new_n99_), .Y(new_n175_));
  NAND2x1_ASAP7_75t_R g117(.A(new_n140_), .B(new_n175_), .Y(new_n176_));
  INVx1_ASAP7_75t_R   g118(.A(p0), .Y(new_n177_));
  OA21x2_ASAP7_75t_R  g119(.A1(new_n138_), .A2(new_n177_), .B(new_n99_), .Y(new_n178_));
  OAI21x1_ASAP7_75t_R g120(.A1(new_n170_), .A2(new_n174_), .B(new_n178_), .Y(new_n179_));
  INVx1_ASAP7_75t_R   g121(.A(p16), .Y(new_n180_));
  NOR2x1_ASAP7_75t_R  g122(.A(new_n180_), .B(new_n139_), .Y(new_n181_));
  AND3x1_ASAP7_75t_R  g123(.A(new_n176_), .B(new_n179_), .C(new_n181_), .Y(new_n182_));
  NAND2x1_ASAP7_75t_R g124(.A(new_n137_), .B(new_n182_), .Y(new_n183_));
  NOR2x1_ASAP7_75t_R  g125(.A(new_n59_), .B(new_n60_), .Y(new_n184_));
  INVx1_ASAP7_75t_R   g126(.A(new_n184_), .Y(new_n185_));
  INVx1_ASAP7_75t_R   g127(.A(p32), .Y(new_n186_));
  AND3x1_ASAP7_75t_R  g128(.A(new_n166_), .B(new_n186_), .C(p11), .Y(new_n187_));
  XOR2x2_ASAP7_75t_R  g129(.A(p6), .B(p5), .Y(new_n188_));
  XOR2x2_ASAP7_75t_R  g130(.A(p7), .B(p10), .Y(new_n189_));
  XOR2x2_ASAP7_75t_R  g131(.A(new_n188_), .B(new_n189_), .Y(new_n190_));
  XNOR2x2_ASAP7_75t_R g132(.A(new_n187_), .B(new_n190_), .Y(new_n191_));
  NAND2x1_ASAP7_75t_R g133(.A(new_n185_), .B(new_n191_), .Y(new_n192_));
  XOR2x2_ASAP7_75t_R  g134(.A(new_n190_), .B(new_n187_), .Y(new_n193_));
  NAND2x1_ASAP7_75t_R g135(.A(new_n184_), .B(new_n193_), .Y(new_n194_));
  NOR2x1_ASAP7_75t_R  g136(.A(p2), .B(p12), .Y(new_n195_));
  NAND3x1_ASAP7_75t_R g137(.A(new_n192_), .B(new_n194_), .C(new_n195_), .Y(new_n196_));
  NOR2x1_ASAP7_75t_R  g138(.A(new_n185_), .B(new_n191_), .Y(new_n197_));
  OAI21x1_ASAP7_75t_R g139(.A1(new_n184_), .A2(new_n193_), .B(new_n99_), .Y(new_n198_));
  OAI21x1_ASAP7_75t_R g140(.A1(new_n197_), .A2(new_n198_), .B(p12), .Y(new_n199_));
  NAND2x1_ASAP7_75t_R g141(.A(new_n196_), .B(new_n199_), .Y(new_n200_));
  XNOR2x2_ASAP7_75t_R g142(.A(p8), .B(p17), .Y(new_n201_));
  INVx1_ASAP7_75t_R   g143(.A(new_n201_), .Y(new_n202_));
  XOR2x2_ASAP7_75t_R  g144(.A(p5), .B(p19), .Y(new_n203_));
  XOR2x2_ASAP7_75t_R  g145(.A(new_n203_), .B(p18), .Y(new_n204_));
  NOR2x1_ASAP7_75t_R  g146(.A(new_n202_), .B(new_n204_), .Y(new_n205_));
  AND2x2_ASAP7_75t_R  g147(.A(new_n202_), .B(new_n204_), .Y(new_n206_));
  AO21x1_ASAP7_75t_R  g148(.A1(new_n61_), .A2(new_n110_), .B(new_n112_), .Y(new_n207_));
  AND3x1_ASAP7_75t_R  g149(.A(new_n177_), .B(new_n166_), .C(p16), .Y(new_n208_));
  OR3x1_ASAP7_75t_R   g150(.A(new_n207_), .B(new_n117_), .C(new_n208_), .Y(new_n209_));
  NAND2x1_ASAP7_75t_R g151(.A(new_n208_), .B(new_n114_), .Y(new_n210_));
  NAND2x1_ASAP7_75t_R g152(.A(new_n209_), .B(new_n210_), .Y(new_n211_));
  OAI21x1_ASAP7_75t_R g153(.A1(new_n205_), .A2(new_n206_), .B(new_n211_), .Y(new_n212_));
  OR3x1_ASAP7_75t_R   g154(.A(new_n211_), .B(new_n206_), .C(new_n205_), .Y(new_n213_));
  NAND2x1_ASAP7_75t_R g155(.A(new_n212_), .B(new_n213_), .Y(new_n214_));
  INVx1_ASAP7_75t_R   g156(.A(p20), .Y(new_n215_));
  AOI21x1_ASAP7_75t_R g157(.A1(new_n99_), .A2(new_n214_), .B(new_n215_), .Y(new_n216_));
  NOR2x1_ASAP7_75t_R  g158(.A(p2), .B(p20), .Y(new_n217_));
  OR3x1_ASAP7_75t_R   g159(.A(p3), .B(p2), .C(p1), .Y(new_n218_));
  NOR2x1_ASAP7_75t_R  g160(.A(p1), .B(p4), .Y(new_n219_));
  INVx1_ASAP7_75t_R   g161(.A(new_n219_), .Y(new_n220_));
  NOR2x1_ASAP7_75t_R  g162(.A(p32), .B(new_n177_), .Y(new_n221_));
  AO21x1_ASAP7_75t_R  g163(.A1(new_n218_), .A2(new_n220_), .B(new_n221_), .Y(new_n222_));
  AO21x1_ASAP7_75t_R  g164(.A1(new_n217_), .A2(new_n214_), .B(new_n222_), .Y(new_n223_));
  OR3x1_ASAP7_75t_R   g165(.A(new_n200_), .B(new_n216_), .C(new_n223_), .Y(new_n224_));
  XOR2x2_ASAP7_75t_R  g166(.A(p14), .B(p22), .Y(new_n225_));
  INVx1_ASAP7_75t_R   g167(.A(p28), .Y(new_n226_));
  NOR2x1_ASAP7_75t_R  g168(.A(p1), .B(new_n226_), .Y(new_n227_));
  XOR2x2_ASAP7_75t_R  g169(.A(new_n225_), .B(new_n227_), .Y(new_n228_));
  XOR2x2_ASAP7_75t_R  g170(.A(new_n228_), .B(new_n147_), .Y(new_n229_));
  NAND2x1_ASAP7_75t_R g171(.A(new_n70_), .B(new_n229_), .Y(new_n230_));
  NAND2x1_ASAP7_75t_R g172(.A(new_n147_), .B(new_n228_), .Y(new_n231_));
  XNOR2x2_ASAP7_75t_R g173(.A(new_n227_), .B(new_n225_), .Y(new_n232_));
  NAND2x1_ASAP7_75t_R g174(.A(new_n161_), .B(new_n232_), .Y(new_n233_));
  NAND2x1_ASAP7_75t_R g175(.A(new_n231_), .B(new_n233_), .Y(new_n234_));
  NAND2x1_ASAP7_75t_R g176(.A(new_n86_), .B(new_n234_), .Y(new_n235_));
  INVx1_ASAP7_75t_R   g177(.A(p29), .Y(new_n236_));
  NAND2x1_ASAP7_75t_R g178(.A(new_n99_), .B(new_n236_), .Y(new_n237_));
  AO21x1_ASAP7_75t_R  g179(.A1(new_n230_), .A2(new_n235_), .B(new_n237_), .Y(new_n238_));
  OR3x1_ASAP7_75t_R   g180(.A(new_n234_), .B(p2), .C(new_n86_), .Y(new_n239_));
  OR3x1_ASAP7_75t_R   g181(.A(new_n229_), .B(p2), .C(new_n70_), .Y(new_n240_));
  NAND3x1_ASAP7_75t_R g182(.A(new_n239_), .B(new_n240_), .C(p29), .Y(new_n241_));
  AO21x1_ASAP7_75t_R  g183(.A1(new_n99_), .A2(new_n186_), .B(new_n103_), .Y(new_n242_));
  AOI21x1_ASAP7_75t_R g184(.A1(new_n238_), .A2(new_n241_), .B(new_n242_), .Y(new_n243_));
  OR3x1_ASAP7_75t_R   g185(.A(new_n183_), .B(new_n224_), .C(new_n243_), .Y(new_n244_));
  AOI21x1_ASAP7_75t_R g186(.A1(new_n233_), .A2(new_n231_), .B(new_n70_), .Y(new_n245_));
  AOI21x1_ASAP7_75t_R g187(.A1(new_n99_), .A2(new_n245_), .B(new_n236_), .Y(new_n246_));
  AOI21x1_ASAP7_75t_R g188(.A1(new_n230_), .A2(new_n235_), .B(new_n237_), .Y(new_n247_));
  AOI21x1_ASAP7_75t_R g189(.A1(new_n246_), .A2(new_n239_), .B(new_n247_), .Y(new_n248_));
  OAI21x1_ASAP7_75t_R g190(.A1(new_n242_), .A2(new_n248_), .B(new_n137_), .Y(new_n249_));
  NAND2x1_ASAP7_75t_R g191(.A(new_n179_), .B(new_n176_), .Y(new_n250_));
  INVx1_ASAP7_75t_R   g192(.A(new_n181_), .Y(new_n251_));
  NOR3x1_ASAP7_75t_R  g193(.A(new_n249_), .B(new_n250_), .C(new_n251_), .Y(new_n252_));
  INVx1_ASAP7_75t_R   g194(.A(new_n224_), .Y(new_n253_));
  INVx1_ASAP7_75t_R   g195(.A(p14), .Y(new_n254_));
  AND3x1_ASAP7_75t_R  g196(.A(new_n252_), .B(new_n253_), .C(new_n254_), .Y(new_n255_));
  AOI21x1_ASAP7_75t_R g197(.A1(p14), .A2(new_n244_), .B(new_n255_), .Y(o0));
  AO21x1_ASAP7_75t_R  g198(.A1(new_n98_), .A2(new_n102_), .B(new_n136_), .Y(new_n257_));
  NOR2x1_ASAP7_75t_R  g199(.A(new_n257_), .B(new_n243_), .Y(new_n258_));
  OR3x1_ASAP7_75t_R   g200(.A(new_n221_), .B(p1), .C(p4), .Y(new_n259_));
  NOR2x1_ASAP7_75t_R  g201(.A(p31), .B(p1), .Y(new_n260_));
  INVx1_ASAP7_75t_R   g202(.A(new_n260_), .Y(new_n261_));
  OR3x1_ASAP7_75t_R   g203(.A(new_n261_), .B(new_n221_), .C(p2), .Y(new_n262_));
  AND2x2_ASAP7_75t_R  g204(.A(new_n259_), .B(new_n262_), .Y(new_n263_));
  INVx1_ASAP7_75t_R   g205(.A(new_n263_), .Y(new_n264_));
  NAND3x1_ASAP7_75t_R g206(.A(new_n199_), .B(new_n196_), .C(new_n264_), .Y(new_n265_));
  INVx1_ASAP7_75t_R   g207(.A(new_n217_), .Y(new_n266_));
  AOI21x1_ASAP7_75t_R g208(.A1(new_n212_), .A2(new_n213_), .B(new_n266_), .Y(new_n267_));
  NOR3x1_ASAP7_75t_R  g209(.A(new_n265_), .B(new_n216_), .C(new_n267_), .Y(new_n268_));
  AO21x1_ASAP7_75t_R  g210(.A1(new_n179_), .A2(new_n176_), .B(new_n251_), .Y(new_n269_));
  NAND3x1_ASAP7_75t_R g211(.A(new_n258_), .B(new_n268_), .C(new_n269_), .Y(new_n270_));
  XOR2x2_ASAP7_75t_R  g212(.A(new_n270_), .B(p25), .Y(o1));
  XOR2x2_ASAP7_75t_R  g213(.A(new_n270_), .B(p19), .Y(o2));
  INVx1_ASAP7_75t_R   g214(.A(p24), .Y(new_n273_));
  AND3x1_ASAP7_75t_R  g215(.A(new_n252_), .B(new_n253_), .C(new_n273_), .Y(new_n274_));
  AOI21x1_ASAP7_75t_R g216(.A1(p24), .A2(new_n244_), .B(new_n274_), .Y(o3));
  XOR2x2_ASAP7_75t_R  g217(.A(new_n270_), .B(p7), .Y(o4));
  XOR2x2_ASAP7_75t_R  g218(.A(new_n270_), .B(p22), .Y(o5));
  AOI21x1_ASAP7_75t_R g219(.A1(new_n179_), .A2(new_n176_), .B(new_n251_), .Y(new_n278_));
  OR3x1_ASAP7_75t_R   g220(.A(new_n224_), .B(new_n249_), .C(new_n278_), .Y(new_n279_));
  XOR2x2_ASAP7_75t_R  g221(.A(new_n279_), .B(p9), .Y(o6));
  XOR2x2_ASAP7_75t_R  g222(.A(new_n279_), .B(p8), .Y(o7));
  XOR2x2_ASAP7_75t_R  g223(.A(new_n279_), .B(p15), .Y(o8));
  NOR2x1_ASAP7_75t_R  g224(.A(new_n257_), .B(new_n278_), .Y(new_n283_));
  INVx1_ASAP7_75t_R   g225(.A(new_n242_), .Y(new_n284_));
  NAND2x1_ASAP7_75t_R g226(.A(new_n284_), .B(new_n248_), .Y(new_n285_));
  INVx1_ASAP7_75t_R   g227(.A(new_n285_), .Y(new_n286_));
  NAND3x1_ASAP7_75t_R g228(.A(new_n283_), .B(new_n268_), .C(new_n286_), .Y(new_n287_));
  OR3x1_ASAP7_75t_R   g229(.A(new_n278_), .B(new_n257_), .C(new_n285_), .Y(new_n288_));
  OR3x1_ASAP7_75t_R   g230(.A(new_n200_), .B(new_n216_), .C(new_n267_), .Y(new_n289_));
  OR3x1_ASAP7_75t_R   g231(.A(new_n289_), .B(p18), .C(new_n263_), .Y(new_n290_));
  NOR2x1_ASAP7_75t_R  g232(.A(new_n288_), .B(new_n290_), .Y(new_n291_));
  AOI21x1_ASAP7_75t_R g233(.A1(p18), .A2(new_n287_), .B(new_n291_), .Y(o9));
  NOR2x1_ASAP7_75t_R  g234(.A(new_n267_), .B(new_n216_), .Y(new_n293_));
  AND3x1_ASAP7_75t_R  g235(.A(new_n199_), .B(new_n196_), .C(new_n264_), .Y(new_n294_));
  AND3x1_ASAP7_75t_R  g236(.A(new_n293_), .B(new_n75_), .C(new_n294_), .Y(new_n295_));
  AND3x1_ASAP7_75t_R  g237(.A(new_n283_), .B(new_n286_), .C(new_n295_), .Y(new_n296_));
  AOI21x1_ASAP7_75t_R g238(.A1(p6), .A2(new_n287_), .B(new_n296_), .Y(o10));
  AND3x1_ASAP7_75t_R  g239(.A(new_n293_), .B(new_n71_), .C(new_n294_), .Y(new_n298_));
  AND3x1_ASAP7_75t_R  g240(.A(new_n283_), .B(new_n286_), .C(new_n298_), .Y(new_n299_));
  AOI21x1_ASAP7_75t_R g241(.A1(p21), .A2(new_n287_), .B(new_n299_), .Y(o11));
  OR3x1_ASAP7_75t_R   g242(.A(new_n289_), .B(p5), .C(new_n263_), .Y(new_n301_));
  NOR2x1_ASAP7_75t_R  g243(.A(new_n288_), .B(new_n301_), .Y(new_n302_));
  AOI21x1_ASAP7_75t_R g244(.A1(p5), .A2(new_n287_), .B(new_n302_), .Y(o12));
  INVx1_ASAP7_75t_R   g245(.A(p13), .Y(new_n304_));
  OAI21x1_ASAP7_75t_R g246(.A1(new_n224_), .A2(new_n288_), .B(new_n304_), .Y(new_n305_));
  OR3x1_ASAP7_75t_R   g247(.A(new_n288_), .B(new_n304_), .C(new_n224_), .Y(new_n306_));
  NAND2x1_ASAP7_75t_R g248(.A(new_n305_), .B(new_n306_), .Y(o13));
  INVx1_ASAP7_75t_R   g249(.A(p17), .Y(new_n308_));
  AND3x1_ASAP7_75t_R  g250(.A(new_n252_), .B(new_n253_), .C(new_n308_), .Y(new_n309_));
  AOI21x1_ASAP7_75t_R g251(.A1(p17), .A2(new_n244_), .B(new_n309_), .Y(o14));
  INVx1_ASAP7_75t_R   g252(.A(p10), .Y(new_n311_));
  AND3x1_ASAP7_75t_R  g253(.A(new_n252_), .B(new_n253_), .C(new_n311_), .Y(new_n312_));
  AOI21x1_ASAP7_75t_R g254(.A1(p10), .A2(new_n244_), .B(new_n312_), .Y(o15));
  AND3x1_ASAP7_75t_R  g255(.A(new_n179_), .B(new_n251_), .C(new_n242_), .Y(new_n314_));
  AND3x1_ASAP7_75t_R  g256(.A(new_n314_), .B(new_n176_), .C(new_n248_), .Y(new_n315_));
  NAND2x1_ASAP7_75t_R g257(.A(new_n137_), .B(new_n315_), .Y(new_n316_));
  NOR2x1_ASAP7_75t_R  g258(.A(new_n289_), .B(new_n316_), .Y(new_n317_));
  AOI21x1_ASAP7_75t_R g259(.A1(new_n181_), .A2(new_n250_), .B(new_n249_), .Y(new_n318_));
  AO21x1_ASAP7_75t_R  g260(.A1(new_n222_), .A2(new_n263_), .B(new_n267_), .Y(new_n319_));
  NOR3x1_ASAP7_75t_R  g261(.A(new_n319_), .B(new_n200_), .C(new_n216_), .Y(new_n320_));
  AND3x1_ASAP7_75t_R  g262(.A(new_n318_), .B(p4), .C(new_n320_), .Y(new_n321_));
  OR3x1_ASAP7_75t_R   g263(.A(new_n317_), .B(p1), .C(new_n321_), .Y(o16));
  NOR2x1_ASAP7_75t_R  g264(.A(new_n170_), .B(new_n174_), .Y(new_n323_));
  OR3x1_ASAP7_75t_R   g265(.A(new_n323_), .B(p2), .C(new_n178_), .Y(new_n324_));
  NAND3x1_ASAP7_75t_R g266(.A(new_n258_), .B(new_n269_), .C(new_n320_), .Y(new_n325_));
  OAI21x1_ASAP7_75t_R g267(.A1(new_n324_), .A2(new_n325_), .B(new_n220_), .Y(new_n326_));
  OR3x1_ASAP7_75t_R   g268(.A(new_n138_), .B(new_n177_), .C(p2), .Y(new_n327_));
  OA21x2_ASAP7_75t_R  g269(.A1(new_n327_), .A2(new_n325_), .B(new_n323_), .Y(new_n328_));
  NOR2x1_ASAP7_75t_R  g270(.A(new_n326_), .B(new_n328_), .Y(o17));
  NOR2x1_ASAP7_75t_R  g271(.A(p2), .B(new_n236_), .Y(new_n330_));
  AND3x1_ASAP7_75t_R  g272(.A(new_n258_), .B(new_n269_), .C(new_n320_), .Y(new_n331_));
  NAND2x1_ASAP7_75t_R g273(.A(new_n230_), .B(new_n235_), .Y(new_n332_));
  AOI21x1_ASAP7_75t_R g274(.A1(new_n330_), .A2(new_n331_), .B(new_n332_), .Y(new_n333_));
  AND2x2_ASAP7_75t_R  g275(.A(new_n330_), .B(new_n332_), .Y(new_n334_));
  AO21x1_ASAP7_75t_R  g276(.A1(new_n334_), .A2(new_n331_), .B(new_n219_), .Y(new_n335_));
  NOR2x1_ASAP7_75t_R  g277(.A(new_n333_), .B(new_n335_), .Y(o18));
  OA21x2_ASAP7_75t_R  g278(.A1(new_n215_), .A2(new_n325_), .B(new_n214_), .Y(new_n337_));
  NOR2x1_ASAP7_75t_R  g279(.A(new_n219_), .B(new_n337_), .Y(o19));
  NAND2x1_ASAP7_75t_R g280(.A(new_n194_), .B(new_n192_), .Y(new_n339_));
  AND3x1_ASAP7_75t_R  g281(.A(new_n318_), .B(p12), .C(new_n320_), .Y(new_n340_));
  OA21x2_ASAP7_75t_R  g282(.A1(new_n339_), .A2(new_n340_), .B(new_n220_), .Y(o20));
  NAND2x1_ASAP7_75t_R g283(.A(new_n131_), .B(new_n129_), .Y(new_n342_));
  AND3x1_ASAP7_75t_R  g284(.A(new_n318_), .B(new_n124_), .C(new_n320_), .Y(new_n343_));
  OA21x2_ASAP7_75t_R  g285(.A1(new_n342_), .A2(new_n343_), .B(new_n220_), .Y(o21));
  AO21x1_ASAP7_75t_R  g286(.A1(p31), .A2(p30), .B(p1), .Y(new_n345_));
  INVx1_ASAP7_75t_R   g287(.A(new_n345_), .Y(new_n346_));
  AO21x1_ASAP7_75t_R  g288(.A1(new_n171_), .A2(new_n172_), .B(new_n260_), .Y(new_n347_));
  INVx1_ASAP7_75t_R   g289(.A(new_n347_), .Y(new_n348_));
  NAND3x1_ASAP7_75t_R g290(.A(new_n293_), .B(new_n294_), .C(new_n347_), .Y(new_n349_));
  NOR3x1_ASAP7_75t_R  g291(.A(new_n349_), .B(new_n249_), .C(new_n278_), .Y(new_n350_));
  AOI21x1_ASAP7_75t_R g292(.A1(new_n348_), .A2(new_n270_), .B(new_n350_), .Y(new_n351_));
  AND3x1_ASAP7_75t_R  g293(.A(new_n258_), .B(new_n268_), .C(new_n269_), .Y(new_n352_));
  AND3x1_ASAP7_75t_R  g294(.A(new_n293_), .B(new_n294_), .C(new_n347_), .Y(new_n353_));
  AOI21x1_ASAP7_75t_R g295(.A1(new_n353_), .A2(new_n318_), .B(new_n345_), .Y(new_n354_));
  OAI21x1_ASAP7_75t_R g296(.A1(new_n352_), .A2(new_n347_), .B(new_n354_), .Y(new_n355_));
  OAI21x1_ASAP7_75t_R g297(.A1(new_n346_), .A2(new_n351_), .B(new_n355_), .Y(o22));
  XOR2x2_ASAP7_75t_R  g298(.A(p14), .B(p13), .Y(new_n357_));
  XOR2x2_ASAP7_75t_R  g299(.A(new_n70_), .B(new_n357_), .Y(new_n358_));
  NOR2x1_ASAP7_75t_R  g300(.A(p28), .B(p1), .Y(new_n359_));
  XOR2x2_ASAP7_75t_R  g301(.A(new_n358_), .B(new_n359_), .Y(new_n360_));
  OA21x2_ASAP7_75t_R  g302(.A1(p3), .A2(p1), .B(new_n360_), .Y(new_n361_));
  XOR2x2_ASAP7_75t_R  g303(.A(new_n279_), .B(new_n361_), .Y(o23));
  OA21x2_ASAP7_75t_R  g304(.A1(new_n85_), .A2(new_n95_), .B(new_n220_), .Y(new_n363_));
  OA21x2_ASAP7_75t_R  g305(.A1(new_n98_), .A2(new_n325_), .B(new_n363_), .Y(o24));
endmodule


