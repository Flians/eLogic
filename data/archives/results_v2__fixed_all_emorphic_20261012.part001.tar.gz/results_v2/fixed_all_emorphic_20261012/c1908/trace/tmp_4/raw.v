// Benchmark "/tmp/" written by ABC on Mon Oct 12 15:05:18 2026

module \/tmp/  ( 
    p17, p8, p6, p14, p15, p4, p0, p32, p25, p20, p16, p2, p23, p28, p9,
    p22, p10, p12, p7, p30, p21, p26, p24, p31, p11, p18, p27, p5, p13,
    p29, p19, p1, p3,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24  );
  input  p17, p8, p6, p14, p15, p4, p0, p32, p25, p20, p16, p2, p23, p28,
    p9, p22, p10, p12, p7, p30, p21, p26, p24, p31, p11, p18, p27, p5, p13,
    p29, p19, p1, p3;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24;
  wire new_n59_, new_n60_, new_n61_, new_n62_, new_n63_, new_n64_, new_n65_,
    new_n66_, new_n67_, new_n68_, new_n69_, new_n70_, new_n71_, new_n72_,
    new_n73_, new_n74_, new_n75_, new_n76_, new_n77_, new_n78_, new_n79_,
    new_n80_, new_n81_, new_n82_, new_n83_, new_n84_, new_n85_, new_n86_,
    new_n87_, new_n88_, new_n89_, new_n90_, new_n91_, new_n92_, new_n93_,
    new_n94_, new_n95_, new_n96_, new_n97_, new_n98_, new_n99_, new_n100_,
    new_n101_, new_n102_, new_n103_, new_n104_, new_n105_, new_n106_,
    new_n107_, new_n108_, new_n109_, new_n110_, new_n111_, new_n112_,
    new_n113_, new_n114_, new_n115_, new_n116_, new_n117_, new_n118_,
    new_n119_, new_n120_, new_n121_, new_n122_, new_n123_, new_n124_,
    new_n125_, new_n126_, new_n127_, new_n128_, new_n129_, new_n130_,
    new_n131_, new_n132_, new_n133_, new_n134_, new_n135_, new_n136_,
    new_n137_, new_n138_, new_n139_, new_n140_, new_n141_, new_n142_,
    new_n143_, new_n144_, new_n145_, new_n146_, new_n147_, new_n148_,
    new_n149_, new_n150_, new_n151_, new_n152_, new_n153_, new_n154_,
    new_n155_, new_n156_, new_n157_, new_n158_, new_n159_, new_n160_,
    new_n161_, new_n162_, new_n163_, new_n164_, new_n165_, new_n166_,
    new_n167_, new_n168_, new_n169_, new_n170_, new_n171_, new_n172_,
    new_n173_, new_n174_, new_n175_, new_n176_, new_n177_, new_n178_,
    new_n179_, new_n180_, new_n181_, new_n182_, new_n183_, new_n184_,
    new_n185_, new_n186_, new_n187_, new_n188_, new_n189_, new_n190_,
    new_n191_, new_n192_, new_n193_, new_n194_, new_n195_, new_n196_,
    new_n197_, new_n198_, new_n199_, new_n200_, new_n201_, new_n202_,
    new_n203_, new_n204_, new_n205_, new_n206_, new_n207_, new_n208_,
    new_n209_, new_n210_, new_n211_, new_n212_, new_n213_, new_n214_,
    new_n215_, new_n216_, new_n217_, new_n218_, new_n219_, new_n220_,
    new_n221_, new_n222_, new_n223_, new_n224_, new_n225_, new_n226_,
    new_n227_, new_n228_, new_n229_, new_n230_, new_n231_, new_n232_,
    new_n233_, new_n234_, new_n235_, new_n236_, new_n237_, new_n238_,
    new_n239_, new_n240_, new_n241_, new_n242_, new_n243_, new_n244_,
    new_n245_, new_n246_, new_n247_, new_n248_, new_n249_, new_n250_,
    new_n251_, new_n252_, new_n253_, new_n254_, new_n256_, new_n257_,
    new_n258_, new_n259_, new_n260_, new_n261_, new_n262_, new_n263_,
    new_n264_, new_n265_, new_n266_, new_n267_, new_n268_, new_n269_,
    new_n270_, new_n271_, new_n272_, new_n273_, new_n274_, new_n275_,
    new_n276_, new_n277_, new_n278_, new_n284_, new_n285_, new_n286_,
    new_n287_, new_n288_, new_n289_, new_n290_, new_n291_, new_n292_,
    new_n293_, new_n294_, new_n295_, new_n299_, new_n300_, new_n301_,
    new_n302_, new_n307_, new_n308_, new_n309_, new_n313_, new_n314_,
    new_n315_, new_n316_, new_n317_, new_n318_, new_n319_, new_n320_,
    new_n321_, new_n323_, new_n324_, new_n325_, new_n326_, new_n327_,
    new_n328_, new_n329_, new_n331_, new_n332_, new_n333_, new_n334_,
    new_n335_, new_n337_, new_n338_, new_n340_, new_n341_, new_n343_,
    new_n344_, new_n346_, new_n347_, new_n348_, new_n349_, new_n351_,
    new_n352_, new_n353_, new_n354_, new_n355_, new_n356_, new_n357_,
    new_n358_, new_n359_, new_n360_, new_n361_, new_n362_, new_n363_,
    new_n364_, new_n365_, new_n366_, new_n367_, new_n369_, new_n370_;
  INVx1_ASAP7_75t_R   g000(.A(p19), .Y(new_n59_));
  NOR2x1_ASAP7_75t_R  g001(.A(p7), .B(new_n59_), .Y(new_n60_));
  INVx1_ASAP7_75t_R   g002(.A(p7), .Y(new_n61_));
  NOR2x1_ASAP7_75t_R  g003(.A(p19), .B(new_n61_), .Y(new_n62_));
  INVx1_ASAP7_75t_R   g004(.A(p25), .Y(new_n63_));
  OAI21x1_ASAP7_75t_R g005(.A1(new_n60_), .A2(new_n62_), .B(new_n63_), .Y(new_n64_));
  NAND2x1_ASAP7_75t_R g006(.A(p19), .B(new_n61_), .Y(new_n65_));
  NAND2x1_ASAP7_75t_R g007(.A(p7), .B(new_n59_), .Y(new_n66_));
  NAND3x1_ASAP7_75t_R g008(.A(new_n65_), .B(new_n66_), .C(p25), .Y(new_n67_));
  NAND2x1_ASAP7_75t_R g009(.A(new_n64_), .B(new_n67_), .Y(new_n68_));
  INVx1_ASAP7_75t_R   g010(.A(p21), .Y(new_n69_));
  NAND2x1_ASAP7_75t_R g011(.A(p18), .B(new_n69_), .Y(new_n70_));
  INVx1_ASAP7_75t_R   g012(.A(p18), .Y(new_n71_));
  NAND2x1_ASAP7_75t_R g013(.A(p21), .B(new_n71_), .Y(new_n72_));
  INVx1_ASAP7_75t_R   g014(.A(p6), .Y(new_n73_));
  NAND3x1_ASAP7_75t_R g015(.A(new_n70_), .B(new_n72_), .C(new_n73_), .Y(new_n74_));
  XOR2x2_ASAP7_75t_R  g016(.A(p21), .B(p18), .Y(new_n75_));
  NAND2x1_ASAP7_75t_R g017(.A(p6), .B(new_n75_), .Y(new_n76_));
  NAND2x1_ASAP7_75t_R g018(.A(new_n74_), .B(new_n76_), .Y(new_n77_));
  NOR2x1_ASAP7_75t_R  g019(.A(new_n68_), .B(new_n77_), .Y(new_n78_));
  AOI21x1_ASAP7_75t_R g020(.A1(new_n70_), .A2(new_n72_), .B(new_n73_), .Y(new_n79_));
  NOR2x1_ASAP7_75t_R  g021(.A(p6), .B(new_n75_), .Y(new_n80_));
  NOR2x1_ASAP7_75t_R  g022(.A(new_n79_), .B(new_n80_), .Y(new_n81_));
  NAND3x1_ASAP7_75t_R g023(.A(new_n65_), .B(new_n66_), .C(new_n63_), .Y(new_n82_));
  AO21x1_ASAP7_75t_R  g024(.A1(new_n65_), .A2(new_n66_), .B(new_n63_), .Y(new_n83_));
  NAND2x1_ASAP7_75t_R g025(.A(new_n82_), .B(new_n83_), .Y(new_n84_));
  NOR2x1_ASAP7_75t_R  g026(.A(new_n81_), .B(new_n84_), .Y(new_n85_));
  XNOR2x2_ASAP7_75t_R g027(.A(p22), .B(p5), .Y(new_n86_));
  INVx1_ASAP7_75t_R   g028(.A(new_n86_), .Y(new_n87_));
  OAI21x1_ASAP7_75t_R g029(.A1(new_n78_), .A2(new_n85_), .B(new_n87_), .Y(new_n88_));
  NAND2x1_ASAP7_75t_R g030(.A(new_n68_), .B(new_n77_), .Y(new_n89_));
  AOI21x1_ASAP7_75t_R g031(.A1(new_n81_), .A2(new_n84_), .B(new_n87_), .Y(new_n90_));
  AND2x2_ASAP7_75t_R  g032(.A(p8), .B(p9), .Y(new_n91_));
  INVx1_ASAP7_75t_R   g033(.A(p15), .Y(new_n92_));
  NOR2x1_ASAP7_75t_R  g034(.A(p8), .B(p9), .Y(new_n93_));
  OR3x1_ASAP7_75t_R   g035(.A(new_n91_), .B(new_n92_), .C(new_n93_), .Y(new_n94_));
  OAI21x1_ASAP7_75t_R g036(.A1(new_n93_), .A2(new_n91_), .B(new_n92_), .Y(new_n95_));
  INVx1_ASAP7_75t_R   g037(.A(p1), .Y(new_n96_));
  INVx1_ASAP7_75t_R   g038(.A(p13), .Y(new_n97_));
  AO21x1_ASAP7_75t_R  g039(.A1(p30), .A2(new_n96_), .B(new_n97_), .Y(new_n98_));
  INVx1_ASAP7_75t_R   g040(.A(p30), .Y(new_n99_));
  OR3x1_ASAP7_75t_R   g041(.A(new_n99_), .B(p13), .C(p1), .Y(new_n100_));
  NAND2x1_ASAP7_75t_R g042(.A(new_n98_), .B(new_n100_), .Y(new_n101_));
  AOI21x1_ASAP7_75t_R g043(.A1(new_n94_), .A2(new_n95_), .B(new_n101_), .Y(new_n102_));
  OAI21x1_ASAP7_75t_R g044(.A1(new_n93_), .A2(new_n91_), .B(p15), .Y(new_n103_));
  OR3x1_ASAP7_75t_R   g045(.A(new_n91_), .B(p15), .C(new_n93_), .Y(new_n104_));
  AND3x1_ASAP7_75t_R  g046(.A(new_n97_), .B(new_n96_), .C(p30), .Y(new_n105_));
  OA21x2_ASAP7_75t_R  g047(.A1(p1), .A2(new_n99_), .B(p13), .Y(new_n106_));
  NOR2x1_ASAP7_75t_R  g048(.A(new_n105_), .B(new_n106_), .Y(new_n107_));
  AOI21x1_ASAP7_75t_R g049(.A1(new_n103_), .A2(new_n104_), .B(new_n107_), .Y(new_n108_));
  NOR2x1_ASAP7_75t_R  g050(.A(new_n102_), .B(new_n108_), .Y(new_n109_));
  AOI21x1_ASAP7_75t_R g051(.A1(new_n89_), .A2(new_n90_), .B(new_n109_), .Y(new_n110_));
  NAND2x1_ASAP7_75t_R g052(.A(new_n88_), .B(new_n110_), .Y(new_n111_));
  NAND2x1_ASAP7_75t_R g053(.A(new_n89_), .B(new_n90_), .Y(new_n112_));
  NAND3x1_ASAP7_75t_R g054(.A(new_n101_), .B(new_n94_), .C(new_n95_), .Y(new_n113_));
  NAND3x1_ASAP7_75t_R g055(.A(new_n107_), .B(new_n103_), .C(new_n104_), .Y(new_n114_));
  NAND2x1_ASAP7_75t_R g056(.A(new_n113_), .B(new_n114_), .Y(new_n115_));
  AOI21x1_ASAP7_75t_R g057(.A1(new_n112_), .A2(new_n88_), .B(new_n115_), .Y(new_n116_));
  NOR2x1_ASAP7_75t_R  g058(.A(p2), .B(new_n116_), .Y(new_n117_));
  OAI21x1_ASAP7_75t_R g059(.A1(p0), .A2(p2), .B(p26), .Y(new_n118_));
  AOI21x1_ASAP7_75t_R g060(.A1(new_n111_), .A2(new_n117_), .B(new_n118_), .Y(new_n119_));
  NAND2x1_ASAP7_75t_R g061(.A(new_n103_), .B(new_n104_), .Y(new_n120_));
  XNOR2x2_ASAP7_75t_R g062(.A(p10), .B(p24), .Y(new_n121_));
  XOR2x2_ASAP7_75t_R  g063(.A(new_n121_), .B(p17), .Y(new_n122_));
  NOR2x1_ASAP7_75t_R  g064(.A(new_n120_), .B(new_n122_), .Y(new_n123_));
  NAND2x1_ASAP7_75t_R g065(.A(new_n95_), .B(new_n94_), .Y(new_n124_));
  INVx1_ASAP7_75t_R   g066(.A(p17), .Y(new_n125_));
  XOR2x2_ASAP7_75t_R  g067(.A(new_n121_), .B(new_n125_), .Y(new_n126_));
  NOR2x1_ASAP7_75t_R  g068(.A(new_n124_), .B(new_n126_), .Y(new_n127_));
  NAND2x1_ASAP7_75t_R g069(.A(p21), .B(new_n73_), .Y(new_n128_));
  NAND2x1_ASAP7_75t_R g070(.A(p6), .B(new_n69_), .Y(new_n129_));
  AO21x1_ASAP7_75t_R  g071(.A1(new_n128_), .A2(new_n129_), .B(p18), .Y(new_n130_));
  NAND3x1_ASAP7_75t_R g072(.A(new_n128_), .B(new_n129_), .C(p18), .Y(new_n131_));
  NOR2x1_ASAP7_75t_R  g073(.A(p0), .B(p1), .Y(new_n132_));
  AOI21x1_ASAP7_75t_R g074(.A1(p26), .A2(new_n132_), .B(new_n63_), .Y(new_n133_));
  AND3x1_ASAP7_75t_R  g075(.A(new_n132_), .B(new_n63_), .C(p26), .Y(new_n134_));
  NOR2x1_ASAP7_75t_R  g076(.A(new_n133_), .B(new_n134_), .Y(new_n135_));
  AOI21x1_ASAP7_75t_R g077(.A1(new_n130_), .A2(new_n131_), .B(new_n135_), .Y(new_n136_));
  NAND3x1_ASAP7_75t_R g078(.A(new_n132_), .B(new_n63_), .C(p26), .Y(new_n137_));
  AO21x1_ASAP7_75t_R  g079(.A1(p26), .A2(new_n132_), .B(new_n63_), .Y(new_n138_));
  NAND2x1_ASAP7_75t_R g080(.A(new_n137_), .B(new_n138_), .Y(new_n139_));
  AOI21x1_ASAP7_75t_R g081(.A1(new_n76_), .A2(new_n74_), .B(new_n139_), .Y(new_n140_));
  NOR2x1_ASAP7_75t_R  g082(.A(new_n136_), .B(new_n140_), .Y(new_n141_));
  OAI21x1_ASAP7_75t_R g083(.A1(new_n123_), .A2(new_n127_), .B(new_n141_), .Y(new_n142_));
  INVx1_ASAP7_75t_R   g084(.A(p27), .Y(new_n143_));
  OAI21x1_ASAP7_75t_R g085(.A1(p2), .A2(new_n142_), .B(new_n143_), .Y(new_n144_));
  OAI21x1_ASAP7_75t_R g086(.A1(new_n79_), .A2(new_n80_), .B(new_n135_), .Y(new_n145_));
  AOI21x1_ASAP7_75t_R g087(.A1(new_n128_), .A2(new_n129_), .B(p18), .Y(new_n146_));
  AND3x1_ASAP7_75t_R  g088(.A(new_n128_), .B(new_n129_), .C(p18), .Y(new_n147_));
  OAI21x1_ASAP7_75t_R g089(.A1(new_n146_), .A2(new_n147_), .B(new_n139_), .Y(new_n148_));
  NAND2x1_ASAP7_75t_R g090(.A(new_n145_), .B(new_n148_), .Y(new_n149_));
  NAND2x1_ASAP7_75t_R g091(.A(new_n124_), .B(new_n126_), .Y(new_n150_));
  NAND2x1_ASAP7_75t_R g092(.A(new_n120_), .B(new_n122_), .Y(new_n151_));
  NAND3x1_ASAP7_75t_R g093(.A(new_n149_), .B(new_n150_), .C(new_n151_), .Y(new_n152_));
  NOR2x1_ASAP7_75t_R  g094(.A(p2), .B(new_n152_), .Y(new_n153_));
  INVx1_ASAP7_75t_R   g095(.A(p2), .Y(new_n154_));
  NAND2x1_ASAP7_75t_R g096(.A(p27), .B(new_n154_), .Y(new_n155_));
  AO21x1_ASAP7_75t_R  g097(.A1(new_n142_), .A2(new_n152_), .B(new_n155_), .Y(new_n156_));
  OAI21x1_ASAP7_75t_R g098(.A1(new_n144_), .A2(new_n153_), .B(new_n156_), .Y(new_n157_));
  AND2x2_ASAP7_75t_R  g099(.A(p14), .B(p13), .Y(new_n158_));
  OAI21x1_ASAP7_75t_R g100(.A1(p14), .A2(p13), .B(p15), .Y(new_n159_));
  NOR2x1_ASAP7_75t_R  g101(.A(p14), .B(p13), .Y(new_n160_));
  OAI21x1_ASAP7_75t_R g102(.A1(new_n160_), .A2(new_n158_), .B(new_n92_), .Y(new_n161_));
  OAI21x1_ASAP7_75t_R g103(.A1(new_n158_), .A2(new_n159_), .B(new_n161_), .Y(new_n162_));
  XOR2x2_ASAP7_75t_R  g104(.A(p22), .B(p24), .Y(new_n163_));
  INVx1_ASAP7_75t_R   g105(.A(p23), .Y(new_n164_));
  OR3x1_ASAP7_75t_R   g106(.A(new_n164_), .B(p32), .C(p1), .Y(new_n165_));
  AND2x2_ASAP7_75t_R  g107(.A(new_n163_), .B(new_n165_), .Y(new_n166_));
  NOR2x1_ASAP7_75t_R  g108(.A(new_n163_), .B(new_n165_), .Y(new_n167_));
  NOR3x1_ASAP7_75t_R  g109(.A(new_n162_), .B(new_n166_), .C(new_n167_), .Y(new_n168_));
  OA21x2_ASAP7_75t_R  g110(.A1(new_n167_), .A2(new_n166_), .B(new_n162_), .Y(new_n169_));
  XNOR2x2_ASAP7_75t_R g111(.A(p9), .B(p21), .Y(new_n170_));
  INVx1_ASAP7_75t_R   g112(.A(new_n170_), .Y(new_n171_));
  OAI21x1_ASAP7_75t_R g113(.A1(new_n168_), .A2(new_n169_), .B(new_n171_), .Y(new_n172_));
  OR3x1_ASAP7_75t_R   g114(.A(new_n162_), .B(new_n166_), .C(new_n167_), .Y(new_n173_));
  OAI21x1_ASAP7_75t_R g115(.A1(new_n167_), .A2(new_n166_), .B(new_n162_), .Y(new_n174_));
  NAND3x1_ASAP7_75t_R g116(.A(new_n173_), .B(new_n174_), .C(new_n170_), .Y(new_n175_));
  INVx1_ASAP7_75t_R   g117(.A(p32), .Y(new_n176_));
  INVx1_ASAP7_75t_R   g118(.A(p11), .Y(new_n177_));
  AO21x1_ASAP7_75t_R  g119(.A1(new_n176_), .A2(new_n154_), .B(new_n177_), .Y(new_n178_));
  INVx1_ASAP7_75t_R   g120(.A(new_n178_), .Y(new_n179_));
  AND3x1_ASAP7_75t_R  g121(.A(new_n172_), .B(new_n175_), .C(new_n179_), .Y(new_n180_));
  NOR2x1_ASAP7_75t_R  g122(.A(new_n154_), .B(new_n178_), .Y(new_n181_));
  AO21x1_ASAP7_75t_R  g123(.A1(p32), .A2(p11), .B(p2), .Y(new_n182_));
  AOI21x1_ASAP7_75t_R g124(.A1(new_n175_), .A2(new_n172_), .B(new_n182_), .Y(new_n183_));
  NOR3x1_ASAP7_75t_R  g125(.A(new_n180_), .B(new_n181_), .C(new_n183_), .Y(new_n184_));
  AO21x1_ASAP7_75t_R  g126(.A1(p0), .A2(p26), .B(p2), .Y(new_n185_));
  AOI21x1_ASAP7_75t_R g127(.A1(new_n88_), .A2(new_n110_), .B(new_n185_), .Y(new_n186_));
  AO21x1_ASAP7_75t_R  g128(.A1(new_n112_), .A2(new_n88_), .B(new_n115_), .Y(new_n187_));
  NAND2x1_ASAP7_75t_R g129(.A(new_n186_), .B(new_n187_), .Y(new_n188_));
  NAND3x1_ASAP7_75t_R g130(.A(new_n157_), .B(new_n184_), .C(new_n188_), .Y(new_n189_));
  NOR2x1_ASAP7_75t_R  g131(.A(new_n119_), .B(new_n189_), .Y(new_n190_));
  OA21x2_ASAP7_75t_R  g132(.A1(p0), .A2(p2), .B(p16), .Y(new_n191_));
  INVx1_ASAP7_75t_R   g133(.A(new_n191_), .Y(new_n192_));
  NAND2x1_ASAP7_75t_R g134(.A(new_n150_), .B(new_n151_), .Y(new_n193_));
  XOR2x2_ASAP7_75t_R  g135(.A(p14), .B(p22), .Y(new_n194_));
  INVx1_ASAP7_75t_R   g136(.A(p28), .Y(new_n195_));
  NOR2x1_ASAP7_75t_R  g137(.A(p1), .B(new_n195_), .Y(new_n196_));
  XOR2x2_ASAP7_75t_R  g138(.A(new_n194_), .B(new_n196_), .Y(new_n197_));
  XOR2x2_ASAP7_75t_R  g139(.A(new_n84_), .B(new_n197_), .Y(new_n198_));
  NOR2x1_ASAP7_75t_R  g140(.A(new_n193_), .B(new_n198_), .Y(new_n199_));
  XOR2x2_ASAP7_75t_R  g141(.A(new_n197_), .B(new_n68_), .Y(new_n200_));
  NOR2x1_ASAP7_75t_R  g142(.A(new_n123_), .B(new_n127_), .Y(new_n201_));
  NOR2x1_ASAP7_75t_R  g143(.A(new_n200_), .B(new_n201_), .Y(new_n202_));
  NOR2x1_ASAP7_75t_R  g144(.A(p2), .B(p29), .Y(new_n203_));
  OAI21x1_ASAP7_75t_R g145(.A1(new_n199_), .A2(new_n202_), .B(new_n203_), .Y(new_n204_));
  NAND3x1_ASAP7_75t_R g146(.A(new_n198_), .B(new_n193_), .C(new_n154_), .Y(new_n205_));
  NAND3x1_ASAP7_75t_R g147(.A(new_n201_), .B(new_n200_), .C(new_n154_), .Y(new_n206_));
  NAND3x1_ASAP7_75t_R g148(.A(new_n205_), .B(new_n206_), .C(p29), .Y(new_n207_));
  AO21x1_ASAP7_75t_R  g149(.A1(new_n176_), .A2(new_n154_), .B(new_n164_), .Y(new_n208_));
  AOI21x1_ASAP7_75t_R g150(.A1(new_n204_), .A2(new_n207_), .B(new_n208_), .Y(new_n209_));
  NOR2x1_ASAP7_75t_R  g151(.A(new_n192_), .B(new_n209_), .Y(new_n210_));
  INVx1_ASAP7_75t_R   g152(.A(p20), .Y(new_n211_));
  OA21x2_ASAP7_75t_R  g153(.A1(new_n160_), .A2(new_n158_), .B(new_n92_), .Y(new_n212_));
  NOR2x1_ASAP7_75t_R  g154(.A(new_n159_), .B(new_n158_), .Y(new_n213_));
  AND2x2_ASAP7_75t_R  g155(.A(p16), .B(new_n132_), .Y(new_n214_));
  OR3x1_ASAP7_75t_R   g156(.A(new_n212_), .B(new_n213_), .C(new_n214_), .Y(new_n215_));
  OAI21x1_ASAP7_75t_R g157(.A1(new_n213_), .A2(new_n212_), .B(new_n214_), .Y(new_n216_));
  AND2x2_ASAP7_75t_R  g158(.A(p18), .B(p5), .Y(new_n217_));
  NOR2x1_ASAP7_75t_R  g159(.A(p18), .B(p5), .Y(new_n218_));
  OR3x1_ASAP7_75t_R   g160(.A(new_n217_), .B(p19), .C(new_n218_), .Y(new_n219_));
  OAI21x1_ASAP7_75t_R g161(.A1(new_n218_), .A2(new_n217_), .B(p19), .Y(new_n220_));
  XNOR2x2_ASAP7_75t_R g162(.A(p17), .B(p8), .Y(new_n221_));
  NAND3x1_ASAP7_75t_R g163(.A(new_n219_), .B(new_n220_), .C(new_n221_), .Y(new_n222_));
  AO21x1_ASAP7_75t_R  g164(.A1(new_n220_), .A2(new_n219_), .B(new_n221_), .Y(new_n223_));
  NAND2x1_ASAP7_75t_R g165(.A(new_n222_), .B(new_n223_), .Y(new_n224_));
  AOI21x1_ASAP7_75t_R g166(.A1(new_n215_), .A2(new_n216_), .B(new_n224_), .Y(new_n225_));
  AO21x1_ASAP7_75t_R  g167(.A1(p16), .A2(new_n132_), .B(new_n213_), .Y(new_n226_));
  OAI21x1_ASAP7_75t_R g168(.A1(new_n212_), .A2(new_n226_), .B(new_n216_), .Y(new_n227_));
  AOI21x1_ASAP7_75t_R g169(.A1(new_n222_), .A2(new_n223_), .B(new_n227_), .Y(new_n228_));
  NOR3x1_ASAP7_75t_R  g170(.A(new_n225_), .B(new_n228_), .C(p2), .Y(new_n229_));
  NOR2x1_ASAP7_75t_R  g171(.A(p4), .B(p1), .Y(new_n230_));
  INVx1_ASAP7_75t_R   g172(.A(p3), .Y(new_n231_));
  AND3x1_ASAP7_75t_R  g173(.A(new_n154_), .B(new_n96_), .C(new_n231_), .Y(new_n232_));
  NAND2x1_ASAP7_75t_R g174(.A(p0), .B(new_n176_), .Y(new_n233_));
  OA21x2_ASAP7_75t_R  g175(.A1(new_n230_), .A2(new_n232_), .B(new_n233_), .Y(new_n234_));
  INVx1_ASAP7_75t_R   g176(.A(new_n234_), .Y(new_n235_));
  AOI21x1_ASAP7_75t_R g177(.A1(new_n211_), .A2(new_n229_), .B(new_n235_), .Y(new_n236_));
  XOR2x2_ASAP7_75t_R  g178(.A(new_n224_), .B(new_n227_), .Y(new_n237_));
  OAI21x1_ASAP7_75t_R g179(.A1(p2), .A2(new_n237_), .B(p20), .Y(new_n238_));
  XOR2x2_ASAP7_75t_R  g180(.A(p6), .B(p5), .Y(new_n239_));
  XNOR2x2_ASAP7_75t_R g181(.A(p10), .B(p7), .Y(new_n240_));
  OR2x4_ASAP7_75t_R   g182(.A(new_n239_), .B(new_n240_), .Y(new_n241_));
  NAND2x1_ASAP7_75t_R g183(.A(new_n239_), .B(new_n240_), .Y(new_n242_));
  NOR2x1_ASAP7_75t_R  g184(.A(new_n93_), .B(new_n91_), .Y(new_n243_));
  AND3x1_ASAP7_75t_R  g185(.A(new_n176_), .B(new_n96_), .C(p11), .Y(new_n244_));
  XOR2x2_ASAP7_75t_R  g186(.A(new_n243_), .B(new_n244_), .Y(new_n245_));
  AO21x1_ASAP7_75t_R  g187(.A1(new_n241_), .A2(new_n242_), .B(new_n245_), .Y(new_n246_));
  NAND3x1_ASAP7_75t_R g188(.A(new_n245_), .B(new_n241_), .C(new_n242_), .Y(new_n247_));
  AND3x1_ASAP7_75t_R  g189(.A(new_n246_), .B(p12), .C(new_n247_), .Y(new_n248_));
  OR2x4_ASAP7_75t_R   g190(.A(p2), .B(p12), .Y(new_n249_));
  AOI21x1_ASAP7_75t_R g191(.A1(new_n247_), .A2(new_n246_), .B(new_n249_), .Y(new_n250_));
  AND2x2_ASAP7_75t_R  g192(.A(p2), .B(p12), .Y(new_n251_));
  NOR3x1_ASAP7_75t_R  g193(.A(new_n248_), .B(new_n250_), .C(new_n251_), .Y(new_n252_));
  AND3x1_ASAP7_75t_R  g194(.A(new_n236_), .B(new_n238_), .C(new_n252_), .Y(new_n253_));
  AND3x1_ASAP7_75t_R  g195(.A(new_n190_), .B(new_n210_), .C(new_n253_), .Y(new_n254_));
  XNOR2x2_ASAP7_75t_R g196(.A(p14), .B(new_n254_), .Y(o0));
  NAND3x1_ASAP7_75t_R g197(.A(new_n201_), .B(new_n154_), .C(new_n149_), .Y(new_n256_));
  AOI21x1_ASAP7_75t_R g198(.A1(new_n150_), .A2(new_n151_), .B(new_n149_), .Y(new_n257_));
  AOI21x1_ASAP7_75t_R g199(.A1(new_n154_), .A2(new_n257_), .B(p27), .Y(new_n258_));
  AOI21x1_ASAP7_75t_R g200(.A1(new_n142_), .A2(new_n152_), .B(new_n155_), .Y(new_n259_));
  AOI21x1_ASAP7_75t_R g201(.A1(new_n256_), .A2(new_n258_), .B(new_n259_), .Y(new_n260_));
  NAND3x1_ASAP7_75t_R g202(.A(new_n172_), .B(new_n175_), .C(new_n179_), .Y(new_n261_));
  OAI21x1_ASAP7_75t_R g203(.A1(new_n168_), .A2(new_n169_), .B(new_n170_), .Y(new_n262_));
  NAND3x1_ASAP7_75t_R g204(.A(new_n173_), .B(new_n174_), .C(new_n171_), .Y(new_n263_));
  INVx1_ASAP7_75t_R   g205(.A(new_n182_), .Y(new_n264_));
  NAND3x1_ASAP7_75t_R g206(.A(new_n262_), .B(new_n263_), .C(new_n264_), .Y(new_n265_));
  INVx1_ASAP7_75t_R   g207(.A(new_n181_), .Y(new_n266_));
  NAND3x1_ASAP7_75t_R g208(.A(new_n261_), .B(new_n265_), .C(new_n266_), .Y(new_n267_));
  OR3x1_ASAP7_75t_R   g209(.A(new_n260_), .B(new_n267_), .C(new_n191_), .Y(new_n268_));
  OAI21x1_ASAP7_75t_R g210(.A1(new_n119_), .A2(new_n189_), .B(new_n268_), .Y(new_n269_));
  AO21x1_ASAP7_75t_R  g211(.A1(new_n204_), .A2(new_n207_), .B(new_n208_), .Y(new_n270_));
  AND2x2_ASAP7_75t_R  g212(.A(new_n238_), .B(new_n252_), .Y(new_n271_));
  NOR2x1_ASAP7_75t_R  g213(.A(p31), .B(p1), .Y(new_n272_));
  AND3x1_ASAP7_75t_R  g214(.A(new_n233_), .B(new_n154_), .C(new_n272_), .Y(new_n273_));
  AO21x1_ASAP7_75t_R  g215(.A1(new_n233_), .A2(new_n230_), .B(new_n273_), .Y(new_n274_));
  NAND2x1_ASAP7_75t_R g216(.A(new_n211_), .B(new_n229_), .Y(new_n275_));
  AND2x2_ASAP7_75t_R  g217(.A(new_n274_), .B(new_n275_), .Y(new_n276_));
  AND3x1_ASAP7_75t_R  g218(.A(new_n270_), .B(new_n271_), .C(new_n276_), .Y(new_n277_));
  NAND2x1_ASAP7_75t_R g219(.A(new_n269_), .B(new_n277_), .Y(new_n278_));
  XOR2x2_ASAP7_75t_R  g220(.A(new_n278_), .B(p25), .Y(o1));
  XOR2x2_ASAP7_75t_R  g221(.A(new_n278_), .B(p19), .Y(o2));
  XNOR2x2_ASAP7_75t_R g222(.A(p24), .B(new_n254_), .Y(o3));
  XOR2x2_ASAP7_75t_R  g223(.A(new_n278_), .B(p7), .Y(o4));
  XOR2x2_ASAP7_75t_R  g224(.A(new_n278_), .B(p22), .Y(o5));
  NAND2x1_ASAP7_75t_R g225(.A(new_n81_), .B(new_n84_), .Y(new_n284_));
  AOI21x1_ASAP7_75t_R g226(.A1(new_n89_), .A2(new_n284_), .B(new_n86_), .Y(new_n285_));
  OAI21x1_ASAP7_75t_R g227(.A1(new_n68_), .A2(new_n77_), .B(new_n86_), .Y(new_n286_));
  OAI21x1_ASAP7_75t_R g228(.A1(new_n85_), .A2(new_n286_), .B(new_n115_), .Y(new_n287_));
  INVx1_ASAP7_75t_R   g229(.A(new_n185_), .Y(new_n288_));
  OAI21x1_ASAP7_75t_R g230(.A1(new_n285_), .A2(new_n287_), .B(new_n288_), .Y(new_n289_));
  NOR2x1_ASAP7_75t_R  g231(.A(new_n116_), .B(new_n289_), .Y(new_n290_));
  OAI21x1_ASAP7_75t_R g232(.A1(new_n290_), .A2(new_n119_), .B(new_n191_), .Y(new_n291_));
  NAND3x1_ASAP7_75t_R g233(.A(new_n236_), .B(new_n238_), .C(new_n252_), .Y(new_n292_));
  NOR2x1_ASAP7_75t_R  g234(.A(new_n292_), .B(new_n209_), .Y(new_n293_));
  NOR2x1_ASAP7_75t_R  g235(.A(new_n267_), .B(new_n260_), .Y(new_n294_));
  NAND3x1_ASAP7_75t_R g236(.A(new_n291_), .B(new_n293_), .C(new_n294_), .Y(new_n295_));
  XOR2x2_ASAP7_75t_R  g237(.A(new_n295_), .B(p9), .Y(o6));
  XOR2x2_ASAP7_75t_R  g238(.A(new_n295_), .B(p8), .Y(o7));
  XOR2x2_ASAP7_75t_R  g239(.A(new_n295_), .B(p15), .Y(o8));
  AND3x1_ASAP7_75t_R  g240(.A(new_n294_), .B(new_n276_), .C(new_n271_), .Y(new_n299_));
  INVx1_ASAP7_75t_R   g241(.A(new_n208_), .Y(new_n300_));
  AND3x1_ASAP7_75t_R  g242(.A(new_n207_), .B(new_n300_), .C(new_n204_), .Y(new_n301_));
  NAND3x1_ASAP7_75t_R g243(.A(new_n299_), .B(new_n291_), .C(new_n301_), .Y(new_n302_));
  XOR2x2_ASAP7_75t_R  g244(.A(new_n302_), .B(p18), .Y(o9));
  XOR2x2_ASAP7_75t_R  g245(.A(new_n302_), .B(p6), .Y(o10));
  XOR2x2_ASAP7_75t_R  g246(.A(new_n302_), .B(p21), .Y(o11));
  XOR2x2_ASAP7_75t_R  g247(.A(new_n302_), .B(p5), .Y(o12));
  AND3x1_ASAP7_75t_R  g248(.A(new_n301_), .B(new_n271_), .C(new_n236_), .Y(new_n307_));
  AOI21x1_ASAP7_75t_R g249(.A1(new_n269_), .A2(new_n307_), .B(new_n97_), .Y(new_n308_));
  AND3x1_ASAP7_75t_R  g250(.A(new_n307_), .B(new_n269_), .C(new_n97_), .Y(new_n309_));
  NOR2x1_ASAP7_75t_R  g251(.A(new_n308_), .B(new_n309_), .Y(o13));
  XOR2x2_ASAP7_75t_R  g252(.A(new_n254_), .B(new_n125_), .Y(o14));
  XNOR2x2_ASAP7_75t_R g253(.A(p10), .B(new_n254_), .Y(o15));
  NOR2x1_ASAP7_75t_R  g254(.A(new_n273_), .B(new_n234_), .Y(new_n313_));
  AOI21x1_ASAP7_75t_R g255(.A1(new_n211_), .A2(new_n229_), .B(new_n313_), .Y(new_n314_));
  NAND3x1_ASAP7_75t_R g256(.A(new_n314_), .B(new_n238_), .C(new_n252_), .Y(new_n315_));
  NOR2x1_ASAP7_75t_R  g257(.A(new_n315_), .B(new_n209_), .Y(new_n316_));
  AND3x1_ASAP7_75t_R  g258(.A(new_n291_), .B(new_n316_), .C(new_n294_), .Y(new_n317_));
  AND3x1_ASAP7_75t_R  g259(.A(new_n207_), .B(new_n208_), .C(new_n204_), .Y(new_n318_));
  AND3x1_ASAP7_75t_R  g260(.A(new_n252_), .B(new_n275_), .C(new_n238_), .Y(new_n319_));
  AND3x1_ASAP7_75t_R  g261(.A(new_n318_), .B(new_n192_), .C(new_n319_), .Y(new_n320_));
  AO21x1_ASAP7_75t_R  g262(.A1(new_n190_), .A2(new_n320_), .B(p1), .Y(new_n321_));
  AO21x1_ASAP7_75t_R  g263(.A1(p4), .A2(new_n317_), .B(new_n321_), .Y(o16));
  NAND2x1_ASAP7_75t_R g264(.A(new_n111_), .B(new_n187_), .Y(new_n323_));
  AND3x1_ASAP7_75t_R  g265(.A(new_n154_), .B(p0), .C(p26), .Y(new_n324_));
  NAND2x1_ASAP7_75t_R g266(.A(new_n324_), .B(new_n317_), .Y(new_n325_));
  OR3x1_ASAP7_75t_R   g267(.A(new_n323_), .B(p2), .C(new_n118_), .Y(new_n326_));
  NAND2x1_ASAP7_75t_R g268(.A(new_n316_), .B(new_n269_), .Y(new_n327_));
  INVx1_ASAP7_75t_R   g269(.A(new_n230_), .Y(new_n328_));
  OAI21x1_ASAP7_75t_R g270(.A1(new_n326_), .A2(new_n327_), .B(new_n328_), .Y(new_n329_));
  AOI21x1_ASAP7_75t_R g271(.A1(new_n323_), .A2(new_n325_), .B(new_n329_), .Y(o17));
  AND2x2_ASAP7_75t_R  g272(.A(p29), .B(new_n154_), .Y(new_n331_));
  OR2x4_ASAP7_75t_R   g273(.A(new_n199_), .B(new_n202_), .Y(new_n332_));
  NAND2x1_ASAP7_75t_R g274(.A(new_n331_), .B(new_n332_), .Y(new_n333_));
  OAI21x1_ASAP7_75t_R g275(.A1(new_n333_), .A2(new_n327_), .B(new_n328_), .Y(new_n334_));
  AOI21x1_ASAP7_75t_R g276(.A1(new_n331_), .A2(new_n317_), .B(new_n332_), .Y(new_n335_));
  NOR2x1_ASAP7_75t_R  g277(.A(new_n334_), .B(new_n335_), .Y(o18));
  INVx1_ASAP7_75t_R   g278(.A(new_n237_), .Y(new_n337_));
  NAND3x1_ASAP7_75t_R g279(.A(new_n317_), .B(p20), .C(new_n154_), .Y(new_n338_));
  AOI21x1_ASAP7_75t_R g280(.A1(new_n337_), .A2(new_n338_), .B(new_n230_), .Y(o19));
  NAND2x1_ASAP7_75t_R g281(.A(new_n247_), .B(new_n246_), .Y(new_n340_));
  NAND3x1_ASAP7_75t_R g282(.A(new_n317_), .B(new_n154_), .C(p12), .Y(new_n341_));
  AOI21x1_ASAP7_75t_R g283(.A1(new_n340_), .A2(new_n341_), .B(new_n230_), .Y(o20));
  NAND2x1_ASAP7_75t_R g284(.A(new_n175_), .B(new_n172_), .Y(new_n343_));
  NAND3x1_ASAP7_75t_R g285(.A(new_n317_), .B(new_n154_), .C(new_n179_), .Y(new_n344_));
  AOI21x1_ASAP7_75t_R g286(.A1(new_n343_), .A2(new_n344_), .B(new_n230_), .Y(o21));
  AND2x2_ASAP7_75t_R  g287(.A(new_n112_), .B(new_n88_), .Y(new_n346_));
  NAND3x1_ASAP7_75t_R g288(.A(new_n346_), .B(new_n99_), .C(new_n96_), .Y(new_n347_));
  AO21x1_ASAP7_75t_R  g289(.A1(new_n99_), .A2(new_n96_), .B(new_n346_), .Y(new_n348_));
  AO21x1_ASAP7_75t_R  g290(.A1(new_n347_), .A2(new_n348_), .B(new_n272_), .Y(new_n349_));
  XNOR2x2_ASAP7_75t_R g291(.A(new_n349_), .B(new_n278_), .Y(o22));
  NOR2x1_ASAP7_75t_R  g292(.A(new_n160_), .B(new_n158_), .Y(new_n351_));
  INVx1_ASAP7_75t_R   g293(.A(new_n351_), .Y(new_n352_));
  NOR2x1_ASAP7_75t_R  g294(.A(p1), .B(p3), .Y(new_n353_));
  AO21x1_ASAP7_75t_R  g295(.A1(new_n352_), .A2(new_n201_), .B(new_n353_), .Y(new_n354_));
  AO21x1_ASAP7_75t_R  g296(.A1(new_n193_), .A2(new_n351_), .B(new_n354_), .Y(new_n355_));
  AOI21x1_ASAP7_75t_R g297(.A1(new_n293_), .A2(new_n269_), .B(new_n355_), .Y(new_n356_));
  NAND2x1_ASAP7_75t_R g298(.A(new_n96_), .B(new_n355_), .Y(new_n357_));
  AO21x1_ASAP7_75t_R  g299(.A1(new_n195_), .A2(new_n96_), .B(new_n353_), .Y(new_n358_));
  OAI21x1_ASAP7_75t_R g300(.A1(new_n357_), .A2(new_n295_), .B(new_n358_), .Y(new_n359_));
  AO21x1_ASAP7_75t_R  g301(.A1(new_n111_), .A2(new_n117_), .B(new_n118_), .Y(new_n360_));
  NOR3x1_ASAP7_75t_R  g302(.A(new_n260_), .B(new_n267_), .C(new_n290_), .Y(new_n361_));
  NOR3x1_ASAP7_75t_R  g303(.A(new_n260_), .B(new_n267_), .C(new_n191_), .Y(new_n362_));
  AOI21x1_ASAP7_75t_R g304(.A1(new_n360_), .A2(new_n361_), .B(new_n362_), .Y(new_n363_));
  NAND2x1_ASAP7_75t_R g305(.A(new_n253_), .B(new_n270_), .Y(new_n364_));
  NOR3x1_ASAP7_75t_R  g306(.A(new_n363_), .B(new_n364_), .C(new_n357_), .Y(new_n365_));
  INVx1_ASAP7_75t_R   g307(.A(new_n358_), .Y(new_n366_));
  OAI21x1_ASAP7_75t_R g308(.A1(new_n356_), .A2(new_n365_), .B(new_n366_), .Y(new_n367_));
  OAI21x1_ASAP7_75t_R g309(.A1(new_n356_), .A2(new_n359_), .B(new_n367_), .Y(o23));
  NAND2x1_ASAP7_75t_R g310(.A(new_n259_), .B(new_n317_), .Y(new_n369_));
  NAND2x1_ASAP7_75t_R g311(.A(new_n142_), .B(new_n152_), .Y(new_n370_));
  AND3x1_ASAP7_75t_R  g312(.A(new_n369_), .B(new_n370_), .C(new_n328_), .Y(o24));
endmodule


