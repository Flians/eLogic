// Benchmark "/tmp/" written by ABC on Mon Oct 12 15:05:20 2026

module \/tmp/  ( 
    p25, p13, p11, p32, p5, p24, p21, p6, p31, p4, p1, p29, p28, p20, p0,
    p27, p15, p10, p12, p2, p7, p19, p30, p3, p14, p23, p16, p8, p9, p22,
    p18, p26, p17,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24  );
  input  p25, p13, p11, p32, p5, p24, p21, p6, p31, p4, p1, p29, p28,
    p20, p0, p27, p15, p10, p12, p2, p7, p19, p30, p3, p14, p23, p16, p8,
    p9, p22, p18, p26, p17;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24;
  wire new_n59_, new_n60_, new_n61_, new_n62_, new_n63_, new_n64_, new_n65_,
    new_n66_, new_n67_, new_n68_, new_n69_, new_n70_, new_n71_, new_n72_,
    new_n73_, new_n74_, new_n75_, new_n76_, new_n77_, new_n78_, new_n79_,
    new_n80_, new_n81_, new_n82_, new_n83_, new_n84_, new_n85_, new_n86_,
    new_n87_, new_n88_, new_n89_, new_n90_, new_n91_, new_n92_, new_n93_,
    new_n94_, new_n95_, new_n96_, new_n97_, new_n98_, new_n99_, new_n100_,
    new_n101_, new_n102_, new_n103_, new_n104_, new_n105_, new_n106_,
    new_n107_, new_n108_, new_n109_, new_n110_, new_n111_, new_n112_,
    new_n113_, new_n114_, new_n115_, new_n116_, new_n117_, new_n118_,
    new_n119_, new_n120_, new_n121_, new_n122_, new_n123_, new_n124_,
    new_n125_, new_n126_, new_n127_, new_n128_, new_n129_, new_n130_,
    new_n131_, new_n132_, new_n133_, new_n134_, new_n135_, new_n136_,
    new_n137_, new_n138_, new_n139_, new_n140_, new_n141_, new_n142_,
    new_n143_, new_n144_, new_n145_, new_n146_, new_n147_, new_n148_,
    new_n149_, new_n150_, new_n151_, new_n152_, new_n153_, new_n154_,
    new_n155_, new_n156_, new_n157_, new_n158_, new_n159_, new_n160_,
    new_n161_, new_n162_, new_n163_, new_n164_, new_n165_, new_n166_,
    new_n167_, new_n168_, new_n169_, new_n170_, new_n171_, new_n172_,
    new_n173_, new_n174_, new_n175_, new_n176_, new_n177_, new_n178_,
    new_n179_, new_n180_, new_n181_, new_n182_, new_n183_, new_n184_,
    new_n185_, new_n186_, new_n187_, new_n188_, new_n189_, new_n190_,
    new_n191_, new_n192_, new_n193_, new_n194_, new_n195_, new_n196_,
    new_n197_, new_n198_, new_n199_, new_n200_, new_n201_, new_n202_,
    new_n203_, new_n204_, new_n205_, new_n206_, new_n207_, new_n208_,
    new_n209_, new_n210_, new_n211_, new_n212_, new_n213_, new_n214_,
    new_n215_, new_n216_, new_n217_, new_n218_, new_n219_, new_n220_,
    new_n221_, new_n222_, new_n223_, new_n224_, new_n225_, new_n226_,
    new_n227_, new_n228_, new_n229_, new_n230_, new_n231_, new_n232_,
    new_n233_, new_n234_, new_n235_, new_n236_, new_n237_, new_n238_,
    new_n239_, new_n240_, new_n241_, new_n242_, new_n243_, new_n244_,
    new_n245_, new_n246_, new_n247_, new_n248_, new_n249_, new_n250_,
    new_n251_, new_n252_, new_n253_, new_n254_, new_n255_, new_n256_,
    new_n257_, new_n258_, new_n259_, new_n260_, new_n261_, new_n262_,
    new_n263_, new_n264_, new_n265_, new_n266_, new_n267_, new_n268_,
    new_n269_, new_n270_, new_n271_, new_n272_, new_n273_, new_n274_,
    new_n275_, new_n276_, new_n277_, new_n278_, new_n279_, new_n280_,
    new_n281_, new_n283_, new_n284_, new_n285_, new_n286_, new_n287_,
    new_n288_, new_n289_, new_n290_, new_n291_, new_n292_, new_n293_,
    new_n296_, new_n297_, new_n301_, new_n302_, new_n306_, new_n307_,
    new_n308_, new_n309_, new_n310_, new_n315_, new_n316_, new_n317_,
    new_n318_, new_n320_, new_n321_, new_n322_, new_n324_, new_n325_,
    new_n327_, new_n328_, new_n329_, new_n330_, new_n331_, new_n332_,
    new_n333_, new_n334_, new_n335_, new_n336_, new_n337_, new_n338_,
    new_n339_, new_n340_, new_n341_, new_n342_, new_n343_, new_n344_,
    new_n345_, new_n347_, new_n348_, new_n349_, new_n350_, new_n351_,
    new_n353_, new_n354_, new_n355_, new_n356_, new_n357_, new_n358_,
    new_n360_, new_n362_, new_n363_, new_n364_, new_n366_, new_n367_,
    new_n369_, new_n370_, new_n371_, new_n372_, new_n373_, new_n374_,
    new_n375_, new_n376_, new_n377_, new_n378_, new_n379_, new_n380_,
    new_n382_, new_n383_, new_n384_, new_n385_, new_n386_, new_n388_,
    new_n389_;
  INVx1_ASAP7_75t_R   g000(.A(p16), .Y(new_n59_));
  NOR2x1_ASAP7_75t_R  g001(.A(p0), .B(p2), .Y(new_n60_));
  NOR2x1_ASAP7_75t_R  g002(.A(new_n59_), .B(new_n60_), .Y(new_n61_));
  INVx1_ASAP7_75t_R   g003(.A(p21), .Y(new_n62_));
  NOR2x1_ASAP7_75t_R  g004(.A(p6), .B(new_n62_), .Y(new_n63_));
  INVx1_ASAP7_75t_R   g005(.A(p18), .Y(new_n64_));
  AO21x1_ASAP7_75t_R  g006(.A1(p6), .A2(new_n62_), .B(new_n64_), .Y(new_n65_));
  INVx1_ASAP7_75t_R   g007(.A(p6), .Y(new_n66_));
  NOR2x1_ASAP7_75t_R  g008(.A(p21), .B(new_n66_), .Y(new_n67_));
  OAI21x1_ASAP7_75t_R g009(.A1(new_n63_), .A2(new_n67_), .B(new_n64_), .Y(new_n68_));
  OAI21x1_ASAP7_75t_R g010(.A1(new_n63_), .A2(new_n65_), .B(new_n68_), .Y(new_n69_));
  INVx1_ASAP7_75t_R   g011(.A(p19), .Y(new_n70_));
  NOR2x1_ASAP7_75t_R  g012(.A(p7), .B(new_n70_), .Y(new_n71_));
  INVx1_ASAP7_75t_R   g013(.A(p7), .Y(new_n72_));
  NOR2x1_ASAP7_75t_R  g014(.A(p19), .B(new_n72_), .Y(new_n73_));
  OAI21x1_ASAP7_75t_R g015(.A1(new_n71_), .A2(new_n73_), .B(p25), .Y(new_n74_));
  NAND2x1_ASAP7_75t_R g016(.A(p19), .B(new_n72_), .Y(new_n75_));
  NAND2x1_ASAP7_75t_R g017(.A(p7), .B(new_n70_), .Y(new_n76_));
  INVx1_ASAP7_75t_R   g018(.A(p25), .Y(new_n77_));
  NAND3x1_ASAP7_75t_R g019(.A(new_n75_), .B(new_n76_), .C(new_n77_), .Y(new_n78_));
  NAND2x1_ASAP7_75t_R g020(.A(new_n74_), .B(new_n78_), .Y(new_n79_));
  NAND2x1_ASAP7_75t_R g021(.A(new_n69_), .B(new_n79_), .Y(new_n80_));
  XOR2x2_ASAP7_75t_R  g022(.A(p6), .B(p18), .Y(new_n81_));
  AND2x2_ASAP7_75t_R  g023(.A(p21), .B(new_n81_), .Y(new_n82_));
  NOR2x1_ASAP7_75t_R  g024(.A(p21), .B(new_n81_), .Y(new_n83_));
  AO21x1_ASAP7_75t_R  g025(.A1(p19), .A2(new_n72_), .B(new_n77_), .Y(new_n84_));
  OAI21x1_ASAP7_75t_R g026(.A1(new_n71_), .A2(new_n73_), .B(new_n77_), .Y(new_n85_));
  OAI21x1_ASAP7_75t_R g027(.A1(new_n73_), .A2(new_n84_), .B(new_n85_), .Y(new_n86_));
  OAI21x1_ASAP7_75t_R g028(.A1(new_n82_), .A2(new_n83_), .B(new_n86_), .Y(new_n87_));
  XNOR2x2_ASAP7_75t_R g029(.A(p5), .B(p22), .Y(new_n88_));
  NAND3x1_ASAP7_75t_R g030(.A(new_n80_), .B(new_n87_), .C(new_n88_), .Y(new_n89_));
  NOR2x1_ASAP7_75t_R  g031(.A(p6), .B(new_n64_), .Y(new_n90_));
  NOR2x1_ASAP7_75t_R  g032(.A(p18), .B(new_n66_), .Y(new_n91_));
  OAI21x1_ASAP7_75t_R g033(.A1(new_n90_), .A2(new_n91_), .B(p21), .Y(new_n92_));
  NAND2x1_ASAP7_75t_R g034(.A(p18), .B(new_n66_), .Y(new_n93_));
  NAND2x1_ASAP7_75t_R g035(.A(p6), .B(new_n64_), .Y(new_n94_));
  NAND3x1_ASAP7_75t_R g036(.A(new_n93_), .B(new_n94_), .C(new_n62_), .Y(new_n95_));
  NAND2x1_ASAP7_75t_R g037(.A(new_n92_), .B(new_n95_), .Y(new_n96_));
  NOR2x1_ASAP7_75t_R  g038(.A(new_n86_), .B(new_n96_), .Y(new_n97_));
  NOR2x1_ASAP7_75t_R  g039(.A(new_n69_), .B(new_n79_), .Y(new_n98_));
  INVx1_ASAP7_75t_R   g040(.A(new_n88_), .Y(new_n99_));
  OAI21x1_ASAP7_75t_R g041(.A1(new_n97_), .A2(new_n98_), .B(new_n99_), .Y(new_n100_));
  NOR2x1_ASAP7_75t_R  g042(.A(p8), .B(p9), .Y(new_n101_));
  AND2x2_ASAP7_75t_R  g043(.A(p8), .B(p9), .Y(new_n102_));
  INVx1_ASAP7_75t_R   g044(.A(p15), .Y(new_n103_));
  OAI21x1_ASAP7_75t_R g045(.A1(new_n101_), .A2(new_n102_), .B(new_n103_), .Y(new_n104_));
  OR3x1_ASAP7_75t_R   g046(.A(new_n102_), .B(new_n103_), .C(new_n101_), .Y(new_n105_));
  NAND2x1_ASAP7_75t_R g047(.A(new_n104_), .B(new_n105_), .Y(new_n106_));
  INVx1_ASAP7_75t_R   g048(.A(p1), .Y(new_n107_));
  NAND2x1_ASAP7_75t_R g049(.A(p30), .B(new_n107_), .Y(new_n108_));
  XOR2x2_ASAP7_75t_R  g050(.A(new_n108_), .B(p13), .Y(new_n109_));
  XOR2x2_ASAP7_75t_R  g051(.A(new_n106_), .B(new_n109_), .Y(new_n110_));
  AOI21x1_ASAP7_75t_R g052(.A1(new_n89_), .A2(new_n100_), .B(new_n110_), .Y(new_n111_));
  NAND3x1_ASAP7_75t_R g053(.A(new_n80_), .B(new_n87_), .C(new_n99_), .Y(new_n112_));
  OAI21x1_ASAP7_75t_R g054(.A1(new_n97_), .A2(new_n98_), .B(new_n88_), .Y(new_n113_));
  XNOR2x2_ASAP7_75t_R g055(.A(new_n109_), .B(new_n106_), .Y(new_n114_));
  AOI21x1_ASAP7_75t_R g056(.A1(new_n112_), .A2(new_n113_), .B(new_n114_), .Y(new_n115_));
  INVx1_ASAP7_75t_R   g057(.A(p0), .Y(new_n116_));
  INVx1_ASAP7_75t_R   g058(.A(p26), .Y(new_n117_));
  INVx1_ASAP7_75t_R   g059(.A(p2), .Y(new_n118_));
  OA21x2_ASAP7_75t_R  g060(.A1(new_n116_), .A2(new_n117_), .B(new_n118_), .Y(new_n119_));
  OAI21x1_ASAP7_75t_R g061(.A1(new_n111_), .A2(new_n115_), .B(new_n119_), .Y(new_n120_));
  AND2x2_ASAP7_75t_R  g062(.A(new_n61_), .B(new_n120_), .Y(new_n121_));
  NOR2x1_ASAP7_75t_R  g063(.A(new_n117_), .B(new_n60_), .Y(new_n122_));
  OAI21x1_ASAP7_75t_R g064(.A1(new_n111_), .A2(new_n115_), .B(new_n118_), .Y(new_n123_));
  NAND2x1_ASAP7_75t_R g065(.A(new_n122_), .B(new_n123_), .Y(new_n124_));
  NOR2x1_ASAP7_75t_R  g066(.A(p1), .B(p0), .Y(new_n125_));
  AOI21x1_ASAP7_75t_R g067(.A1(p26), .A2(new_n125_), .B(new_n77_), .Y(new_n126_));
  AND3x1_ASAP7_75t_R  g068(.A(new_n125_), .B(new_n77_), .C(p26), .Y(new_n127_));
  NOR2x1_ASAP7_75t_R  g069(.A(new_n126_), .B(new_n127_), .Y(new_n128_));
  XOR2x2_ASAP7_75t_R  g070(.A(new_n69_), .B(new_n128_), .Y(new_n129_));
  NOR2x1_ASAP7_75t_R  g071(.A(p24), .B(p10), .Y(new_n130_));
  AND2x2_ASAP7_75t_R  g072(.A(p24), .B(p10), .Y(new_n131_));
  OAI21x1_ASAP7_75t_R g073(.A1(new_n130_), .A2(new_n131_), .B(p17), .Y(new_n132_));
  OR3x1_ASAP7_75t_R   g074(.A(new_n131_), .B(p17), .C(new_n130_), .Y(new_n133_));
  NAND2x1_ASAP7_75t_R g075(.A(new_n132_), .B(new_n133_), .Y(new_n134_));
  XNOR2x2_ASAP7_75t_R g076(.A(new_n106_), .B(new_n134_), .Y(new_n135_));
  NAND2x1_ASAP7_75t_R g077(.A(new_n129_), .B(new_n135_), .Y(new_n136_));
  XOR2x2_ASAP7_75t_R  g078(.A(new_n106_), .B(new_n134_), .Y(new_n137_));
  XOR2x2_ASAP7_75t_R  g079(.A(new_n96_), .B(new_n128_), .Y(new_n138_));
  NAND2x1_ASAP7_75t_R g080(.A(new_n137_), .B(new_n138_), .Y(new_n139_));
  INVx1_ASAP7_75t_R   g081(.A(p27), .Y(new_n140_));
  NOR2x1_ASAP7_75t_R  g082(.A(p2), .B(new_n140_), .Y(new_n141_));
  NAND3x1_ASAP7_75t_R g083(.A(new_n136_), .B(new_n139_), .C(new_n141_), .Y(new_n142_));
  NAND3x1_ASAP7_75t_R g084(.A(new_n138_), .B(new_n135_), .C(new_n118_), .Y(new_n143_));
  NAND3x1_ASAP7_75t_R g085(.A(new_n129_), .B(new_n137_), .C(new_n118_), .Y(new_n144_));
  NAND3x1_ASAP7_75t_R g086(.A(new_n143_), .B(new_n144_), .C(new_n140_), .Y(new_n145_));
  NAND2x1_ASAP7_75t_R g087(.A(p13), .B(p14), .Y(new_n146_));
  OR3x1_ASAP7_75t_R   g088(.A(p13), .B(p15), .C(p14), .Y(new_n147_));
  OAI21x1_ASAP7_75t_R g089(.A1(p15), .A2(new_n146_), .B(new_n147_), .Y(new_n148_));
  OAI21x1_ASAP7_75t_R g090(.A1(p13), .A2(p14), .B(p15), .Y(new_n149_));
  AND2x2_ASAP7_75t_R  g091(.A(p13), .B(p14), .Y(new_n150_));
  NOR2x1_ASAP7_75t_R  g092(.A(new_n149_), .B(new_n150_), .Y(new_n151_));
  NOR3x1_ASAP7_75t_R  g093(.A(new_n148_), .B(p22), .C(new_n151_), .Y(new_n152_));
  NOR2x1_ASAP7_75t_R  g094(.A(p13), .B(p14), .Y(new_n153_));
  OAI21x1_ASAP7_75t_R g095(.A1(new_n153_), .A2(new_n150_), .B(new_n103_), .Y(new_n154_));
  AO21x1_ASAP7_75t_R  g096(.A1(p13), .A2(p14), .B(new_n149_), .Y(new_n155_));
  INVx1_ASAP7_75t_R   g097(.A(p22), .Y(new_n156_));
  AOI21x1_ASAP7_75t_R g098(.A1(new_n154_), .A2(new_n155_), .B(new_n156_), .Y(new_n157_));
  NOR2x1_ASAP7_75t_R  g099(.A(p32), .B(p1), .Y(new_n158_));
  INVx1_ASAP7_75t_R   g100(.A(p23), .Y(new_n159_));
  NOR2x1_ASAP7_75t_R  g101(.A(p24), .B(new_n159_), .Y(new_n160_));
  INVx1_ASAP7_75t_R   g102(.A(p24), .Y(new_n161_));
  AOI21x1_ASAP7_75t_R g103(.A1(p23), .A2(new_n158_), .B(new_n161_), .Y(new_n162_));
  AOI21x1_ASAP7_75t_R g104(.A1(new_n158_), .A2(new_n160_), .B(new_n162_), .Y(new_n163_));
  OAI21x1_ASAP7_75t_R g105(.A1(new_n152_), .A2(new_n157_), .B(new_n163_), .Y(new_n164_));
  NAND3x1_ASAP7_75t_R g106(.A(new_n155_), .B(new_n154_), .C(new_n156_), .Y(new_n165_));
  OAI21x1_ASAP7_75t_R g107(.A1(new_n151_), .A2(new_n148_), .B(p22), .Y(new_n166_));
  AO21x1_ASAP7_75t_R  g108(.A1(new_n158_), .A2(new_n160_), .B(new_n162_), .Y(new_n167_));
  NAND3x1_ASAP7_75t_R g109(.A(new_n165_), .B(new_n166_), .C(new_n167_), .Y(new_n168_));
  XNOR2x2_ASAP7_75t_R g110(.A(p21), .B(p9), .Y(new_n169_));
  NAND3x1_ASAP7_75t_R g111(.A(new_n164_), .B(new_n168_), .C(new_n169_), .Y(new_n170_));
  INVx1_ASAP7_75t_R   g112(.A(p32), .Y(new_n171_));
  INVx1_ASAP7_75t_R   g113(.A(p11), .Y(new_n172_));
  AO21x1_ASAP7_75t_R  g114(.A1(new_n171_), .A2(new_n118_), .B(new_n172_), .Y(new_n173_));
  INVx1_ASAP7_75t_R   g115(.A(new_n173_), .Y(new_n174_));
  NOR2x1_ASAP7_75t_R  g116(.A(new_n151_), .B(new_n148_), .Y(new_n175_));
  XOR2x2_ASAP7_75t_R  g117(.A(p24), .B(p22), .Y(new_n176_));
  AO21x1_ASAP7_75t_R  g118(.A1(p23), .A2(new_n158_), .B(new_n176_), .Y(new_n177_));
  AND3x1_ASAP7_75t_R  g119(.A(new_n171_), .B(new_n107_), .C(p23), .Y(new_n178_));
  NAND2x1_ASAP7_75t_R g120(.A(new_n176_), .B(new_n178_), .Y(new_n179_));
  NAND3x1_ASAP7_75t_R g121(.A(new_n175_), .B(new_n177_), .C(new_n179_), .Y(new_n180_));
  NOR2x1_ASAP7_75t_R  g122(.A(new_n176_), .B(new_n178_), .Y(new_n181_));
  AND3x1_ASAP7_75t_R  g123(.A(new_n176_), .B(p23), .C(new_n158_), .Y(new_n182_));
  NAND2x1_ASAP7_75t_R g124(.A(new_n154_), .B(new_n155_), .Y(new_n183_));
  OAI21x1_ASAP7_75t_R g125(.A1(new_n181_), .A2(new_n182_), .B(new_n183_), .Y(new_n184_));
  INVx1_ASAP7_75t_R   g126(.A(new_n169_), .Y(new_n185_));
  NAND3x1_ASAP7_75t_R g127(.A(new_n180_), .B(new_n184_), .C(new_n185_), .Y(new_n186_));
  NAND3x1_ASAP7_75t_R g128(.A(new_n170_), .B(new_n174_), .C(new_n186_), .Y(new_n187_));
  AO21x1_ASAP7_75t_R  g129(.A1(new_n184_), .A2(new_n180_), .B(new_n169_), .Y(new_n188_));
  NAND3x1_ASAP7_75t_R g130(.A(new_n180_), .B(new_n184_), .C(new_n169_), .Y(new_n189_));
  AND2x2_ASAP7_75t_R  g131(.A(new_n118_), .B(new_n173_), .Y(new_n190_));
  NAND3x1_ASAP7_75t_R g132(.A(new_n188_), .B(new_n189_), .C(new_n190_), .Y(new_n191_));
  NOR2x1_ASAP7_75t_R  g133(.A(new_n118_), .B(new_n173_), .Y(new_n192_));
  INVx1_ASAP7_75t_R   g134(.A(new_n192_), .Y(new_n193_));
  NAND3x1_ASAP7_75t_R g135(.A(new_n187_), .B(new_n191_), .C(new_n193_), .Y(new_n194_));
  AOI21x1_ASAP7_75t_R g136(.A1(new_n142_), .A2(new_n145_), .B(new_n194_), .Y(new_n195_));
  AND3x1_ASAP7_75t_R  g137(.A(new_n121_), .B(new_n124_), .C(new_n195_), .Y(new_n196_));
  AO21x1_ASAP7_75t_R  g138(.A1(new_n171_), .A2(new_n118_), .B(new_n159_), .Y(new_n197_));
  INVx1_ASAP7_75t_R   g139(.A(new_n197_), .Y(new_n198_));
  NOR2x1_ASAP7_75t_R  g140(.A(p14), .B(p22), .Y(new_n199_));
  AND2x2_ASAP7_75t_R  g141(.A(p14), .B(p22), .Y(new_n200_));
  INVx1_ASAP7_75t_R   g142(.A(p28), .Y(new_n201_));
  NOR2x1_ASAP7_75t_R  g143(.A(p1), .B(new_n201_), .Y(new_n202_));
  OAI21x1_ASAP7_75t_R g144(.A1(new_n199_), .A2(new_n200_), .B(new_n202_), .Y(new_n203_));
  NAND2x1_ASAP7_75t_R g145(.A(p28), .B(new_n107_), .Y(new_n204_));
  XOR2x2_ASAP7_75t_R  g146(.A(p14), .B(p22), .Y(new_n205_));
  NAND2x1_ASAP7_75t_R g147(.A(new_n204_), .B(new_n205_), .Y(new_n206_));
  NAND2x1_ASAP7_75t_R g148(.A(new_n203_), .B(new_n206_), .Y(new_n207_));
  XOR2x2_ASAP7_75t_R  g149(.A(new_n207_), .B(new_n79_), .Y(new_n208_));
  OR3x1_ASAP7_75t_R   g150(.A(new_n208_), .B(new_n135_), .C(p2), .Y(new_n209_));
  XOR2x2_ASAP7_75t_R  g151(.A(new_n207_), .B(new_n86_), .Y(new_n210_));
  NOR2x1_ASAP7_75t_R  g152(.A(new_n137_), .B(new_n210_), .Y(new_n211_));
  INVx1_ASAP7_75t_R   g153(.A(p29), .Y(new_n212_));
  AOI21x1_ASAP7_75t_R g154(.A1(new_n118_), .A2(new_n211_), .B(new_n212_), .Y(new_n213_));
  NAND2x1_ASAP7_75t_R g155(.A(new_n137_), .B(new_n210_), .Y(new_n214_));
  NAND2x1_ASAP7_75t_R g156(.A(new_n135_), .B(new_n208_), .Y(new_n215_));
  NAND2x1_ASAP7_75t_R g157(.A(new_n212_), .B(new_n118_), .Y(new_n216_));
  AOI21x1_ASAP7_75t_R g158(.A1(new_n214_), .A2(new_n215_), .B(new_n216_), .Y(new_n217_));
  AOI21x1_ASAP7_75t_R g159(.A1(new_n209_), .A2(new_n213_), .B(new_n217_), .Y(new_n218_));
  INVx1_ASAP7_75t_R   g160(.A(new_n218_), .Y(new_n219_));
  NAND2x1_ASAP7_75t_R g161(.A(new_n198_), .B(new_n219_), .Y(new_n220_));
  NAND2x1_ASAP7_75t_R g162(.A(p5), .B(p18), .Y(new_n221_));
  OR2x4_ASAP7_75t_R   g163(.A(p5), .B(p18), .Y(new_n222_));
  AO21x1_ASAP7_75t_R  g164(.A1(new_n221_), .A2(new_n222_), .B(new_n70_), .Y(new_n223_));
  NAND3x1_ASAP7_75t_R g165(.A(new_n222_), .B(new_n70_), .C(new_n221_), .Y(new_n224_));
  XNOR2x2_ASAP7_75t_R g166(.A(p8), .B(p17), .Y(new_n225_));
  AND3x1_ASAP7_75t_R  g167(.A(new_n223_), .B(new_n224_), .C(new_n225_), .Y(new_n226_));
  INVx1_ASAP7_75t_R   g168(.A(new_n225_), .Y(new_n227_));
  NAND2x1_ASAP7_75t_R g169(.A(new_n224_), .B(new_n223_), .Y(new_n228_));
  AND2x2_ASAP7_75t_R  g170(.A(new_n227_), .B(new_n228_), .Y(new_n229_));
  AND3x1_ASAP7_75t_R  g171(.A(new_n107_), .B(new_n116_), .C(p16), .Y(new_n230_));
  OR3x1_ASAP7_75t_R   g172(.A(new_n148_), .B(new_n151_), .C(new_n230_), .Y(new_n231_));
  INVx1_ASAP7_75t_R   g173(.A(new_n230_), .Y(new_n232_));
  AO21x1_ASAP7_75t_R  g174(.A1(new_n154_), .A2(new_n155_), .B(new_n232_), .Y(new_n233_));
  NAND2x1_ASAP7_75t_R g175(.A(new_n231_), .B(new_n233_), .Y(new_n234_));
  OAI21x1_ASAP7_75t_R g176(.A1(new_n226_), .A2(new_n229_), .B(new_n234_), .Y(new_n235_));
  AND3x1_ASAP7_75t_R  g177(.A(new_n223_), .B(new_n224_), .C(new_n227_), .Y(new_n236_));
  AND2x2_ASAP7_75t_R  g178(.A(new_n225_), .B(new_n228_), .Y(new_n237_));
  AND3x1_ASAP7_75t_R  g179(.A(new_n232_), .B(new_n154_), .C(new_n155_), .Y(new_n238_));
  NOR2x1_ASAP7_75t_R  g180(.A(new_n232_), .B(new_n175_), .Y(new_n239_));
  NOR2x1_ASAP7_75t_R  g181(.A(new_n238_), .B(new_n239_), .Y(new_n240_));
  OAI21x1_ASAP7_75t_R g182(.A1(new_n236_), .A2(new_n237_), .B(new_n240_), .Y(new_n241_));
  NAND2x1_ASAP7_75t_R g183(.A(new_n235_), .B(new_n241_), .Y(new_n242_));
  INVx1_ASAP7_75t_R   g184(.A(p20), .Y(new_n243_));
  AOI21x1_ASAP7_75t_R g185(.A1(new_n118_), .A2(new_n242_), .B(new_n243_), .Y(new_n244_));
  XOR2x2_ASAP7_75t_R  g186(.A(p5), .B(p6), .Y(new_n245_));
  XNOR2x2_ASAP7_75t_R g187(.A(p10), .B(p7), .Y(new_n246_));
  NAND2x1_ASAP7_75t_R g188(.A(p11), .B(new_n158_), .Y(new_n247_));
  OA21x2_ASAP7_75t_R  g189(.A1(new_n245_), .A2(new_n246_), .B(new_n247_), .Y(new_n248_));
  NAND2x1_ASAP7_75t_R g190(.A(new_n245_), .B(new_n246_), .Y(new_n249_));
  NOR2x1_ASAP7_75t_R  g191(.A(new_n101_), .B(new_n102_), .Y(new_n250_));
  INVx1_ASAP7_75t_R   g192(.A(new_n250_), .Y(new_n251_));
  AND3x1_ASAP7_75t_R  g193(.A(new_n248_), .B(new_n249_), .C(new_n251_), .Y(new_n252_));
  OR3x1_ASAP7_75t_R   g194(.A(new_n246_), .B(new_n245_), .C(new_n247_), .Y(new_n253_));
  XNOR2x2_ASAP7_75t_R g195(.A(p5), .B(p6), .Y(new_n254_));
  XOR2x2_ASAP7_75t_R  g196(.A(p10), .B(p7), .Y(new_n255_));
  OR3x1_ASAP7_75t_R   g197(.A(new_n254_), .B(new_n255_), .C(new_n247_), .Y(new_n256_));
  AOI21x1_ASAP7_75t_R g198(.A1(new_n253_), .A2(new_n256_), .B(new_n250_), .Y(new_n257_));
  NOR3x1_ASAP7_75t_R  g199(.A(new_n252_), .B(new_n257_), .C(p2), .Y(new_n258_));
  NAND2x1_ASAP7_75t_R g200(.A(new_n253_), .B(new_n256_), .Y(new_n259_));
  NAND2x1_ASAP7_75t_R g201(.A(new_n255_), .B(new_n254_), .Y(new_n260_));
  AND3x1_ASAP7_75t_R  g202(.A(new_n249_), .B(new_n260_), .C(new_n247_), .Y(new_n261_));
  OR3x1_ASAP7_75t_R   g203(.A(new_n259_), .B(new_n261_), .C(new_n251_), .Y(new_n262_));
  NAND3x1_ASAP7_75t_R g204(.A(new_n258_), .B(p12), .C(new_n262_), .Y(new_n263_));
  AO21x1_ASAP7_75t_R  g205(.A1(new_n262_), .A2(new_n258_), .B(p12), .Y(new_n264_));
  AND2x2_ASAP7_75t_R  g206(.A(new_n263_), .B(new_n264_), .Y(new_n265_));
  NOR2x1_ASAP7_75t_R  g207(.A(new_n244_), .B(new_n265_), .Y(new_n266_));
  OR3x1_ASAP7_75t_R   g208(.A(p1), .B(p2), .C(p3), .Y(new_n267_));
  NOR2x1_ASAP7_75t_R  g209(.A(p4), .B(p1), .Y(new_n268_));
  INVx1_ASAP7_75t_R   g210(.A(new_n268_), .Y(new_n269_));
  NOR2x1_ASAP7_75t_R  g211(.A(p32), .B(new_n116_), .Y(new_n270_));
  AO21x1_ASAP7_75t_R  g212(.A1(new_n267_), .A2(new_n269_), .B(new_n270_), .Y(new_n271_));
  NOR2x1_ASAP7_75t_R  g213(.A(p20), .B(p2), .Y(new_n272_));
  INVx1_ASAP7_75t_R   g214(.A(new_n272_), .Y(new_n273_));
  AO21x1_ASAP7_75t_R  g215(.A1(new_n235_), .A2(new_n241_), .B(new_n273_), .Y(new_n274_));
  INVx1_ASAP7_75t_R   g216(.A(new_n274_), .Y(new_n275_));
  NOR2x1_ASAP7_75t_R  g217(.A(new_n271_), .B(new_n275_), .Y(new_n276_));
  AND3x1_ASAP7_75t_R  g218(.A(new_n220_), .B(new_n266_), .C(new_n276_), .Y(new_n277_));
  NAND2x1_ASAP7_75t_R g219(.A(new_n196_), .B(new_n277_), .Y(new_n278_));
  INVx1_ASAP7_75t_R   g220(.A(p14), .Y(new_n279_));
  AND3x1_ASAP7_75t_R  g221(.A(new_n266_), .B(new_n276_), .C(new_n279_), .Y(new_n280_));
  AND3x1_ASAP7_75t_R  g222(.A(new_n280_), .B(new_n196_), .C(new_n220_), .Y(new_n281_));
  AOI21x1_ASAP7_75t_R g223(.A1(p14), .A2(new_n278_), .B(new_n281_), .Y(o0));
  INVx1_ASAP7_75t_R   g224(.A(new_n61_), .Y(new_n283_));
  AOI21x1_ASAP7_75t_R g225(.A1(new_n120_), .A2(new_n124_), .B(new_n283_), .Y(new_n284_));
  OAI21x1_ASAP7_75t_R g226(.A1(new_n197_), .A2(new_n218_), .B(new_n195_), .Y(new_n285_));
  OR3x1_ASAP7_75t_R   g227(.A(new_n270_), .B(p4), .C(p1), .Y(new_n286_));
  NOR2x1_ASAP7_75t_R  g228(.A(p31), .B(p1), .Y(new_n287_));
  INVx1_ASAP7_75t_R   g229(.A(new_n287_), .Y(new_n288_));
  OR3x1_ASAP7_75t_R   g230(.A(new_n288_), .B(new_n270_), .C(p2), .Y(new_n289_));
  AND2x2_ASAP7_75t_R  g231(.A(new_n286_), .B(new_n289_), .Y(new_n290_));
  AO21x1_ASAP7_75t_R  g232(.A1(new_n263_), .A2(new_n264_), .B(new_n290_), .Y(new_n291_));
  OR3x1_ASAP7_75t_R   g233(.A(new_n291_), .B(new_n275_), .C(new_n244_), .Y(new_n292_));
  NOR3x1_ASAP7_75t_R  g234(.A(new_n284_), .B(new_n285_), .C(new_n292_), .Y(new_n293_));
  XOR2x2_ASAP7_75t_R  g235(.A(new_n293_), .B(new_n77_), .Y(o1));
  XOR2x2_ASAP7_75t_R  g236(.A(new_n293_), .B(new_n70_), .Y(o2));
  AND3x1_ASAP7_75t_R  g237(.A(new_n266_), .B(new_n276_), .C(new_n161_), .Y(new_n296_));
  AND3x1_ASAP7_75t_R  g238(.A(new_n296_), .B(new_n196_), .C(new_n220_), .Y(new_n297_));
  AOI21x1_ASAP7_75t_R g239(.A1(p24), .A2(new_n278_), .B(new_n297_), .Y(o3));
  XOR2x2_ASAP7_75t_R  g240(.A(new_n293_), .B(new_n72_), .Y(o4));
  XOR2x2_ASAP7_75t_R  g241(.A(new_n293_), .B(new_n156_), .Y(o5));
  NAND2x1_ASAP7_75t_R g242(.A(new_n276_), .B(new_n266_), .Y(new_n301_));
  OR3x1_ASAP7_75t_R   g243(.A(new_n301_), .B(new_n285_), .C(new_n284_), .Y(new_n302_));
  XOR2x2_ASAP7_75t_R  g244(.A(new_n302_), .B(p9), .Y(o6));
  XOR2x2_ASAP7_75t_R  g245(.A(new_n302_), .B(p8), .Y(o7));
  XOR2x2_ASAP7_75t_R  g246(.A(new_n302_), .B(p15), .Y(o8));
  NAND2x1_ASAP7_75t_R g247(.A(new_n198_), .B(new_n218_), .Y(new_n306_));
  NOR2x1_ASAP7_75t_R  g248(.A(new_n306_), .B(new_n292_), .Y(new_n307_));
  INVx1_ASAP7_75t_R   g249(.A(new_n195_), .Y(new_n308_));
  NOR2x1_ASAP7_75t_R  g250(.A(new_n308_), .B(new_n284_), .Y(new_n309_));
  NAND2x1_ASAP7_75t_R g251(.A(new_n307_), .B(new_n309_), .Y(new_n310_));
  XOR2x2_ASAP7_75t_R  g252(.A(new_n310_), .B(p18), .Y(o9));
  XOR2x2_ASAP7_75t_R  g253(.A(new_n310_), .B(p6), .Y(o10));
  XOR2x2_ASAP7_75t_R  g254(.A(new_n310_), .B(p21), .Y(o11));
  XOR2x2_ASAP7_75t_R  g255(.A(new_n310_), .B(p5), .Y(o12));
  NOR2x1_ASAP7_75t_R  g256(.A(new_n306_), .B(new_n301_), .Y(new_n315_));
  INVx1_ASAP7_75t_R   g257(.A(p13), .Y(new_n316_));
  AOI21x1_ASAP7_75t_R g258(.A1(new_n309_), .A2(new_n315_), .B(new_n316_), .Y(new_n317_));
  AND3x1_ASAP7_75t_R  g259(.A(new_n315_), .B(new_n316_), .C(new_n309_), .Y(new_n318_));
  NOR2x1_ASAP7_75t_R  g260(.A(new_n317_), .B(new_n318_), .Y(o13));
  INVx1_ASAP7_75t_R   g261(.A(p17), .Y(new_n320_));
  AND3x1_ASAP7_75t_R  g262(.A(new_n266_), .B(new_n276_), .C(new_n320_), .Y(new_n321_));
  AND3x1_ASAP7_75t_R  g263(.A(new_n321_), .B(new_n196_), .C(new_n220_), .Y(new_n322_));
  AOI21x1_ASAP7_75t_R g264(.A1(p17), .A2(new_n278_), .B(new_n322_), .Y(o14));
  NOR2x1_ASAP7_75t_R  g265(.A(p10), .B(new_n301_), .Y(new_n324_));
  AND3x1_ASAP7_75t_R  g266(.A(new_n324_), .B(new_n220_), .C(new_n196_), .Y(new_n325_));
  AOI21x1_ASAP7_75t_R g267(.A1(p10), .A2(new_n278_), .B(new_n325_), .Y(o15));
  INVx1_ASAP7_75t_R   g268(.A(p4), .Y(new_n327_));
  AND3x1_ASAP7_75t_R  g269(.A(new_n289_), .B(new_n271_), .C(new_n286_), .Y(new_n328_));
  AO21x1_ASAP7_75t_R  g270(.A1(new_n272_), .A2(new_n242_), .B(new_n328_), .Y(new_n329_));
  OR3x1_ASAP7_75t_R   g271(.A(new_n329_), .B(new_n265_), .C(new_n244_), .Y(new_n330_));
  OR3x1_ASAP7_75t_R   g272(.A(new_n284_), .B(new_n285_), .C(new_n330_), .Y(new_n331_));
  NAND2x1_ASAP7_75t_R g273(.A(new_n120_), .B(new_n124_), .Y(new_n332_));
  INVx1_ASAP7_75t_R   g274(.A(new_n332_), .Y(new_n333_));
  AND3x1_ASAP7_75t_R  g275(.A(new_n218_), .B(new_n283_), .C(new_n197_), .Y(new_n334_));
  AOI21x1_ASAP7_75t_R g276(.A1(new_n231_), .A2(new_n233_), .B(new_n228_), .Y(new_n335_));
  AND3x1_ASAP7_75t_R  g277(.A(new_n233_), .B(new_n231_), .C(new_n228_), .Y(new_n336_));
  OA21x2_ASAP7_75t_R  g278(.A1(new_n335_), .A2(new_n336_), .B(new_n227_), .Y(new_n337_));
  NAND2x1_ASAP7_75t_R g279(.A(new_n231_), .B(new_n228_), .Y(new_n338_));
  OAI21x1_ASAP7_75t_R g280(.A1(new_n239_), .A2(new_n338_), .B(new_n225_), .Y(new_n339_));
  OAI21x1_ASAP7_75t_R g281(.A1(new_n335_), .A2(new_n339_), .B(new_n118_), .Y(new_n340_));
  OAI21x1_ASAP7_75t_R g282(.A1(new_n337_), .A2(new_n340_), .B(p20), .Y(new_n341_));
  NAND2x1_ASAP7_75t_R g283(.A(new_n274_), .B(new_n341_), .Y(new_n342_));
  NOR2x1_ASAP7_75t_R  g284(.A(new_n265_), .B(new_n342_), .Y(new_n343_));
  AND3x1_ASAP7_75t_R  g285(.A(new_n334_), .B(new_n343_), .C(new_n195_), .Y(new_n344_));
  AOI21x1_ASAP7_75t_R g286(.A1(new_n333_), .A2(new_n344_), .B(p1), .Y(new_n345_));
  OAI21x1_ASAP7_75t_R g287(.A1(new_n327_), .A2(new_n331_), .B(new_n345_), .Y(o16));
  NOR2x1_ASAP7_75t_R  g288(.A(new_n111_), .B(new_n115_), .Y(new_n347_));
  OR3x1_ASAP7_75t_R   g289(.A(new_n347_), .B(p2), .C(new_n119_), .Y(new_n348_));
  OAI21x1_ASAP7_75t_R g290(.A1(new_n348_), .A2(new_n331_), .B(new_n269_), .Y(new_n349_));
  OR3x1_ASAP7_75t_R   g291(.A(new_n116_), .B(new_n117_), .C(p2), .Y(new_n350_));
  OA21x2_ASAP7_75t_R  g292(.A1(new_n350_), .A2(new_n331_), .B(new_n347_), .Y(new_n351_));
  NOR2x1_ASAP7_75t_R  g293(.A(new_n349_), .B(new_n351_), .Y(o17));
  NAND2x1_ASAP7_75t_R g294(.A(new_n214_), .B(new_n215_), .Y(new_n353_));
  INVx1_ASAP7_75t_R   g295(.A(new_n353_), .Y(new_n354_));
  OR3x1_ASAP7_75t_R   g296(.A(new_n331_), .B(new_n212_), .C(p2), .Y(new_n355_));
  AND3x1_ASAP7_75t_R  g297(.A(new_n353_), .B(p29), .C(new_n118_), .Y(new_n356_));
  NOR3x1_ASAP7_75t_R  g298(.A(new_n284_), .B(new_n285_), .C(new_n330_), .Y(new_n357_));
  AO21x1_ASAP7_75t_R  g299(.A1(new_n356_), .A2(new_n357_), .B(new_n268_), .Y(new_n358_));
  AOI21x1_ASAP7_75t_R g300(.A1(new_n354_), .A2(new_n355_), .B(new_n358_), .Y(o18));
  NAND2x1_ASAP7_75t_R g301(.A(p20), .B(new_n357_), .Y(new_n360_));
  AOI21x1_ASAP7_75t_R g302(.A1(new_n242_), .A2(new_n360_), .B(new_n268_), .Y(o19));
  NOR2x1_ASAP7_75t_R  g303(.A(new_n257_), .B(new_n252_), .Y(new_n362_));
  NAND2x1_ASAP7_75t_R g304(.A(new_n362_), .B(new_n262_), .Y(new_n363_));
  AO21x1_ASAP7_75t_R  g305(.A1(p12), .A2(new_n357_), .B(new_n363_), .Y(new_n364_));
  AND2x2_ASAP7_75t_R  g306(.A(new_n269_), .B(new_n364_), .Y(o20));
  NAND2x1_ASAP7_75t_R g307(.A(new_n189_), .B(new_n188_), .Y(new_n366_));
  AO21x1_ASAP7_75t_R  g308(.A1(new_n174_), .A2(new_n357_), .B(new_n366_), .Y(new_n367_));
  AND2x2_ASAP7_75t_R  g309(.A(new_n269_), .B(new_n367_), .Y(o21));
  AO21x1_ASAP7_75t_R  g310(.A1(p31), .A2(p30), .B(p1), .Y(new_n369_));
  INVx1_ASAP7_75t_R   g311(.A(new_n369_), .Y(new_n370_));
  OR3x1_ASAP7_75t_R   g312(.A(new_n284_), .B(new_n285_), .C(new_n292_), .Y(new_n371_));
  AND3x1_ASAP7_75t_R  g313(.A(new_n100_), .B(new_n89_), .C(new_n288_), .Y(new_n372_));
  OR3x1_ASAP7_75t_R   g314(.A(new_n342_), .B(new_n291_), .C(new_n372_), .Y(new_n373_));
  NOR3x1_ASAP7_75t_R  g315(.A(new_n373_), .B(new_n285_), .C(new_n284_), .Y(new_n374_));
  AOI21x1_ASAP7_75t_R g316(.A1(new_n371_), .A2(new_n372_), .B(new_n374_), .Y(new_n375_));
  INVx1_ASAP7_75t_R   g317(.A(new_n372_), .Y(new_n376_));
  NOR2x1_ASAP7_75t_R  g318(.A(new_n372_), .B(new_n292_), .Y(new_n377_));
  AOI21x1_ASAP7_75t_R g319(.A1(new_n61_), .A2(new_n332_), .B(new_n285_), .Y(new_n378_));
  AOI21x1_ASAP7_75t_R g320(.A1(new_n377_), .A2(new_n378_), .B(new_n369_), .Y(new_n379_));
  OAI21x1_ASAP7_75t_R g321(.A1(new_n293_), .A2(new_n376_), .B(new_n379_), .Y(new_n380_));
  OAI21x1_ASAP7_75t_R g322(.A1(new_n370_), .A2(new_n375_), .B(new_n380_), .Y(o22));
  NOR2x1_ASAP7_75t_R  g323(.A(p1), .B(p28), .Y(new_n382_));
  NOR2x1_ASAP7_75t_R  g324(.A(new_n153_), .B(new_n150_), .Y(new_n383_));
  XOR2x2_ASAP7_75t_R  g325(.A(new_n135_), .B(new_n383_), .Y(new_n384_));
  XNOR2x2_ASAP7_75t_R g326(.A(new_n382_), .B(new_n384_), .Y(new_n385_));
  OA21x2_ASAP7_75t_R  g327(.A1(p1), .A2(p3), .B(new_n385_), .Y(new_n386_));
  XOR2x2_ASAP7_75t_R  g328(.A(new_n302_), .B(new_n386_), .Y(o23));
  NAND2x1_ASAP7_75t_R g329(.A(new_n141_), .B(new_n357_), .Y(new_n388_));
  AND2x2_ASAP7_75t_R  g330(.A(new_n139_), .B(new_n136_), .Y(new_n389_));
  AND3x1_ASAP7_75t_R  g331(.A(new_n388_), .B(new_n269_), .C(new_n389_), .Y(o24));
endmodule


