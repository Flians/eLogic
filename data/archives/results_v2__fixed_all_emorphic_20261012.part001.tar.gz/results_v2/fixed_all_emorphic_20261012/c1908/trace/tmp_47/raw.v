// Benchmark "/tmp/" written by ABC on Mon Oct 12 15:05:30 2026

module \/tmp/  ( 
    p13, p17, p7, p24, p4, p21, p27, p19, p30, p14, p26, p2, p15, p0, p31,
    p6, p3, p11, p8, p1, p9, p32, p20, p28, p25, p12, p23, p5, p10, p16,
    p29, p18, p22,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24  );
  input  p13, p17, p7, p24, p4, p21, p27, p19, p30, p14, p26, p2, p15,
    p0, p31, p6, p3, p11, p8, p1, p9, p32, p20, p28, p25, p12, p23, p5,
    p10, p16, p29, p18, p22;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24;
  wire new_n59_, new_n60_, new_n61_, new_n62_, new_n63_, new_n64_, new_n65_,
    new_n66_, new_n67_, new_n68_, new_n69_, new_n70_, new_n71_, new_n72_,
    new_n73_, new_n74_, new_n75_, new_n76_, new_n77_, new_n78_, new_n79_,
    new_n80_, new_n81_, new_n82_, new_n83_, new_n84_, new_n85_, new_n86_,
    new_n87_, new_n88_, new_n89_, new_n90_, new_n91_, new_n92_, new_n93_,
    new_n94_, new_n95_, new_n96_, new_n97_, new_n98_, new_n99_, new_n100_,
    new_n101_, new_n102_, new_n103_, new_n104_, new_n105_, new_n106_,
    new_n107_, new_n108_, new_n109_, new_n110_, new_n111_, new_n112_,
    new_n113_, new_n114_, new_n115_, new_n116_, new_n117_, new_n118_,
    new_n119_, new_n120_, new_n121_, new_n122_, new_n123_, new_n124_,
    new_n125_, new_n126_, new_n127_, new_n128_, new_n129_, new_n130_,
    new_n131_, new_n132_, new_n133_, new_n134_, new_n135_, new_n136_,
    new_n137_, new_n138_, new_n139_, new_n140_, new_n141_, new_n142_,
    new_n143_, new_n144_, new_n145_, new_n146_, new_n147_, new_n148_,
    new_n149_, new_n150_, new_n151_, new_n152_, new_n153_, new_n154_,
    new_n155_, new_n156_, new_n157_, new_n158_, new_n159_, new_n160_,
    new_n161_, new_n162_, new_n163_, new_n164_, new_n165_, new_n166_,
    new_n167_, new_n168_, new_n169_, new_n170_, new_n171_, new_n172_,
    new_n173_, new_n174_, new_n175_, new_n176_, new_n177_, new_n178_,
    new_n179_, new_n180_, new_n181_, new_n182_, new_n183_, new_n184_,
    new_n185_, new_n186_, new_n187_, new_n188_, new_n189_, new_n190_,
    new_n191_, new_n192_, new_n193_, new_n194_, new_n195_, new_n196_,
    new_n197_, new_n198_, new_n199_, new_n200_, new_n201_, new_n202_,
    new_n203_, new_n204_, new_n205_, new_n206_, new_n207_, new_n208_,
    new_n209_, new_n210_, new_n211_, new_n212_, new_n213_, new_n214_,
    new_n215_, new_n216_, new_n217_, new_n218_, new_n219_, new_n220_,
    new_n221_, new_n222_, new_n223_, new_n224_, new_n225_, new_n226_,
    new_n227_, new_n228_, new_n229_, new_n230_, new_n231_, new_n232_,
    new_n233_, new_n234_, new_n235_, new_n236_, new_n237_, new_n238_,
    new_n239_, new_n240_, new_n241_, new_n242_, new_n243_, new_n244_,
    new_n245_, new_n246_, new_n247_, new_n248_, new_n249_, new_n250_,
    new_n251_, new_n252_, new_n253_, new_n255_, new_n256_, new_n257_,
    new_n258_, new_n259_, new_n260_, new_n261_, new_n262_, new_n263_,
    new_n264_, new_n265_, new_n266_, new_n272_, new_n276_, new_n277_,
    new_n278_, new_n279_, new_n280_, new_n285_, new_n286_, new_n287_,
    new_n291_, new_n292_, new_n293_, new_n294_, new_n295_, new_n296_,
    new_n297_, new_n298_, new_n299_, new_n300_, new_n301_, new_n303_,
    new_n304_, new_n305_, new_n306_, new_n307_, new_n309_, new_n310_,
    new_n311_, new_n312_, new_n313_, new_n314_, new_n316_, new_n318_,
    new_n320_, new_n321_, new_n323_, new_n324_, new_n325_, new_n326_,
    new_n327_, new_n328_, new_n329_, new_n330_, new_n331_, new_n332_,
    new_n333_, new_n334_, new_n335_, new_n337_, new_n338_, new_n339_,
    new_n340_, new_n341_, new_n343_, new_n344_;
  OA21x2_ASAP7_75t_R  g000(.A1(p2), .A2(p0), .B(p16), .Y(new_n59_));
  INVx1_ASAP7_75t_R   g001(.A(p7), .Y(new_n60_));
  NOR2x1_ASAP7_75t_R  g002(.A(p19), .B(new_n60_), .Y(new_n61_));
  INVx1_ASAP7_75t_R   g003(.A(p25), .Y(new_n62_));
  AO21x1_ASAP7_75t_R  g004(.A1(p19), .A2(new_n60_), .B(new_n62_), .Y(new_n63_));
  INVx1_ASAP7_75t_R   g005(.A(p19), .Y(new_n64_));
  NOR2x1_ASAP7_75t_R  g006(.A(p7), .B(new_n64_), .Y(new_n65_));
  OAI21x1_ASAP7_75t_R g007(.A1(new_n61_), .A2(new_n65_), .B(new_n62_), .Y(new_n66_));
  OAI21x1_ASAP7_75t_R g008(.A1(new_n61_), .A2(new_n63_), .B(new_n66_), .Y(new_n67_));
  INVx1_ASAP7_75t_R   g009(.A(p18), .Y(new_n68_));
  NOR2x1_ASAP7_75t_R  g010(.A(p6), .B(new_n68_), .Y(new_n69_));
  INVx1_ASAP7_75t_R   g011(.A(p6), .Y(new_n70_));
  NOR2x1_ASAP7_75t_R  g012(.A(p18), .B(new_n70_), .Y(new_n71_));
  OAI21x1_ASAP7_75t_R g013(.A1(new_n69_), .A2(new_n71_), .B(p21), .Y(new_n72_));
  NAND2x1_ASAP7_75t_R g014(.A(p18), .B(new_n70_), .Y(new_n73_));
  NAND2x1_ASAP7_75t_R g015(.A(p6), .B(new_n68_), .Y(new_n74_));
  INVx1_ASAP7_75t_R   g016(.A(p21), .Y(new_n75_));
  NAND3x1_ASAP7_75t_R g017(.A(new_n73_), .B(new_n74_), .C(new_n75_), .Y(new_n76_));
  NAND2x1_ASAP7_75t_R g018(.A(new_n72_), .B(new_n76_), .Y(new_n77_));
  NAND2x1_ASAP7_75t_R g019(.A(new_n67_), .B(new_n77_), .Y(new_n78_));
  XOR2x2_ASAP7_75t_R  g020(.A(p19), .B(p25), .Y(new_n79_));
  AND2x2_ASAP7_75t_R  g021(.A(p7), .B(new_n79_), .Y(new_n80_));
  NOR2x1_ASAP7_75t_R  g022(.A(p7), .B(new_n79_), .Y(new_n81_));
  NOR2x1_ASAP7_75t_R  g023(.A(p6), .B(new_n75_), .Y(new_n82_));
  AO21x1_ASAP7_75t_R  g024(.A1(p6), .A2(new_n75_), .B(new_n68_), .Y(new_n83_));
  NOR2x1_ASAP7_75t_R  g025(.A(p21), .B(new_n70_), .Y(new_n84_));
  OAI21x1_ASAP7_75t_R g026(.A1(new_n82_), .A2(new_n84_), .B(new_n68_), .Y(new_n85_));
  OAI21x1_ASAP7_75t_R g027(.A1(new_n82_), .A2(new_n83_), .B(new_n85_), .Y(new_n86_));
  OAI21x1_ASAP7_75t_R g028(.A1(new_n80_), .A2(new_n81_), .B(new_n86_), .Y(new_n87_));
  XNOR2x2_ASAP7_75t_R g029(.A(p5), .B(p22), .Y(new_n88_));
  NAND3x1_ASAP7_75t_R g030(.A(new_n78_), .B(new_n87_), .C(new_n88_), .Y(new_n89_));
  NOR2x1_ASAP7_75t_R  g031(.A(p19), .B(new_n62_), .Y(new_n90_));
  NOR2x1_ASAP7_75t_R  g032(.A(p25), .B(new_n64_), .Y(new_n91_));
  OAI21x1_ASAP7_75t_R g033(.A1(new_n90_), .A2(new_n91_), .B(p7), .Y(new_n92_));
  NAND2x1_ASAP7_75t_R g034(.A(p25), .B(new_n64_), .Y(new_n93_));
  NAND2x1_ASAP7_75t_R g035(.A(p19), .B(new_n62_), .Y(new_n94_));
  NAND3x1_ASAP7_75t_R g036(.A(new_n93_), .B(new_n94_), .C(new_n60_), .Y(new_n95_));
  NAND2x1_ASAP7_75t_R g037(.A(new_n92_), .B(new_n95_), .Y(new_n96_));
  NOR2x1_ASAP7_75t_R  g038(.A(new_n86_), .B(new_n96_), .Y(new_n97_));
  NOR2x1_ASAP7_75t_R  g039(.A(new_n67_), .B(new_n77_), .Y(new_n98_));
  INVx1_ASAP7_75t_R   g040(.A(new_n88_), .Y(new_n99_));
  OAI21x1_ASAP7_75t_R g041(.A1(new_n97_), .A2(new_n98_), .B(new_n99_), .Y(new_n100_));
  NOR2x1_ASAP7_75t_R  g042(.A(p8), .B(p9), .Y(new_n101_));
  AND2x2_ASAP7_75t_R  g043(.A(p8), .B(p9), .Y(new_n102_));
  INVx1_ASAP7_75t_R   g044(.A(p15), .Y(new_n103_));
  OAI21x1_ASAP7_75t_R g045(.A1(new_n101_), .A2(new_n102_), .B(new_n103_), .Y(new_n104_));
  OR3x1_ASAP7_75t_R   g046(.A(new_n102_), .B(new_n103_), .C(new_n101_), .Y(new_n105_));
  NAND2x1_ASAP7_75t_R g047(.A(new_n104_), .B(new_n105_), .Y(new_n106_));
  INVx1_ASAP7_75t_R   g048(.A(p1), .Y(new_n107_));
  NAND2x1_ASAP7_75t_R g049(.A(p30), .B(new_n107_), .Y(new_n108_));
  XOR2x2_ASAP7_75t_R  g050(.A(new_n108_), .B(p13), .Y(new_n109_));
  XOR2x2_ASAP7_75t_R  g051(.A(new_n106_), .B(new_n109_), .Y(new_n110_));
  AOI21x1_ASAP7_75t_R g052(.A1(new_n89_), .A2(new_n100_), .B(new_n110_), .Y(new_n111_));
  NAND3x1_ASAP7_75t_R g053(.A(new_n78_), .B(new_n87_), .C(new_n99_), .Y(new_n112_));
  OAI21x1_ASAP7_75t_R g054(.A1(new_n97_), .A2(new_n98_), .B(new_n88_), .Y(new_n113_));
  XNOR2x2_ASAP7_75t_R g055(.A(new_n109_), .B(new_n106_), .Y(new_n114_));
  AOI21x1_ASAP7_75t_R g056(.A1(new_n112_), .A2(new_n113_), .B(new_n114_), .Y(new_n115_));
  AND2x2_ASAP7_75t_R  g057(.A(p26), .B(p0), .Y(new_n116_));
  NOR2x1_ASAP7_75t_R  g058(.A(p2), .B(new_n116_), .Y(new_n117_));
  OAI21x1_ASAP7_75t_R g059(.A1(new_n111_), .A2(new_n115_), .B(new_n117_), .Y(new_n118_));
  AND2x2_ASAP7_75t_R  g060(.A(new_n59_), .B(new_n118_), .Y(new_n119_));
  AO21x1_ASAP7_75t_R  g061(.A1(p26), .A2(p2), .B(new_n116_), .Y(new_n120_));
  INVx1_ASAP7_75t_R   g062(.A(p2), .Y(new_n121_));
  OAI21x1_ASAP7_75t_R g063(.A1(new_n111_), .A2(new_n115_), .B(new_n121_), .Y(new_n122_));
  NAND2x1_ASAP7_75t_R g064(.A(new_n120_), .B(new_n122_), .Y(new_n123_));
  NOR2x1_ASAP7_75t_R  g065(.A(p0), .B(p1), .Y(new_n124_));
  AOI21x1_ASAP7_75t_R g066(.A1(p26), .A2(new_n124_), .B(new_n62_), .Y(new_n125_));
  AND3x1_ASAP7_75t_R  g067(.A(new_n124_), .B(p26), .C(new_n62_), .Y(new_n126_));
  NOR2x1_ASAP7_75t_R  g068(.A(new_n125_), .B(new_n126_), .Y(new_n127_));
  XOR2x2_ASAP7_75t_R  g069(.A(new_n86_), .B(new_n127_), .Y(new_n128_));
  NOR2x1_ASAP7_75t_R  g070(.A(p17), .B(p24), .Y(new_n129_));
  AND2x2_ASAP7_75t_R  g071(.A(p17), .B(p24), .Y(new_n130_));
  OAI21x1_ASAP7_75t_R g072(.A1(new_n129_), .A2(new_n130_), .B(p10), .Y(new_n131_));
  OR3x1_ASAP7_75t_R   g073(.A(new_n130_), .B(p10), .C(new_n129_), .Y(new_n132_));
  NAND2x1_ASAP7_75t_R g074(.A(new_n131_), .B(new_n132_), .Y(new_n133_));
  XNOR2x2_ASAP7_75t_R g075(.A(new_n106_), .B(new_n133_), .Y(new_n134_));
  NAND2x1_ASAP7_75t_R g076(.A(new_n128_), .B(new_n134_), .Y(new_n135_));
  XOR2x2_ASAP7_75t_R  g077(.A(new_n106_), .B(new_n133_), .Y(new_n136_));
  XOR2x2_ASAP7_75t_R  g078(.A(new_n77_), .B(new_n127_), .Y(new_n137_));
  NAND2x1_ASAP7_75t_R g079(.A(new_n136_), .B(new_n137_), .Y(new_n138_));
  INVx1_ASAP7_75t_R   g080(.A(p27), .Y(new_n139_));
  NOR2x1_ASAP7_75t_R  g081(.A(p2), .B(new_n139_), .Y(new_n140_));
  NAND3x1_ASAP7_75t_R g082(.A(new_n135_), .B(new_n138_), .C(new_n140_), .Y(new_n141_));
  NAND3x1_ASAP7_75t_R g083(.A(new_n137_), .B(new_n134_), .C(new_n121_), .Y(new_n142_));
  NAND3x1_ASAP7_75t_R g084(.A(new_n128_), .B(new_n136_), .C(new_n121_), .Y(new_n143_));
  NAND3x1_ASAP7_75t_R g085(.A(new_n142_), .B(new_n143_), .C(new_n139_), .Y(new_n144_));
  NAND2x1_ASAP7_75t_R g086(.A(p13), .B(p14), .Y(new_n145_));
  OR3x1_ASAP7_75t_R   g087(.A(p13), .B(p14), .C(p15), .Y(new_n146_));
  OAI21x1_ASAP7_75t_R g088(.A1(p15), .A2(new_n145_), .B(new_n146_), .Y(new_n147_));
  OAI21x1_ASAP7_75t_R g089(.A1(p13), .A2(p14), .B(p15), .Y(new_n148_));
  AND2x2_ASAP7_75t_R  g090(.A(p13), .B(p14), .Y(new_n149_));
  NOR2x1_ASAP7_75t_R  g091(.A(new_n148_), .B(new_n149_), .Y(new_n150_));
  NOR3x1_ASAP7_75t_R  g092(.A(new_n147_), .B(p22), .C(new_n150_), .Y(new_n151_));
  NOR2x1_ASAP7_75t_R  g093(.A(p13), .B(p14), .Y(new_n152_));
  OAI21x1_ASAP7_75t_R g094(.A1(new_n152_), .A2(new_n149_), .B(new_n103_), .Y(new_n153_));
  AO21x1_ASAP7_75t_R  g095(.A1(p13), .A2(p14), .B(new_n148_), .Y(new_n154_));
  INVx1_ASAP7_75t_R   g096(.A(p22), .Y(new_n155_));
  AOI21x1_ASAP7_75t_R g097(.A1(new_n153_), .A2(new_n154_), .B(new_n155_), .Y(new_n156_));
  NOR2x1_ASAP7_75t_R  g098(.A(p1), .B(p32), .Y(new_n157_));
  INVx1_ASAP7_75t_R   g099(.A(p23), .Y(new_n158_));
  NOR2x1_ASAP7_75t_R  g100(.A(p24), .B(new_n158_), .Y(new_n159_));
  INVx1_ASAP7_75t_R   g101(.A(p24), .Y(new_n160_));
  AOI21x1_ASAP7_75t_R g102(.A1(p23), .A2(new_n157_), .B(new_n160_), .Y(new_n161_));
  AOI21x1_ASAP7_75t_R g103(.A1(new_n157_), .A2(new_n159_), .B(new_n161_), .Y(new_n162_));
  OAI21x1_ASAP7_75t_R g104(.A1(new_n151_), .A2(new_n156_), .B(new_n162_), .Y(new_n163_));
  NAND3x1_ASAP7_75t_R g105(.A(new_n154_), .B(new_n153_), .C(new_n155_), .Y(new_n164_));
  OAI21x1_ASAP7_75t_R g106(.A1(new_n150_), .A2(new_n147_), .B(p22), .Y(new_n165_));
  AO21x1_ASAP7_75t_R  g107(.A1(new_n157_), .A2(new_n159_), .B(new_n161_), .Y(new_n166_));
  NAND3x1_ASAP7_75t_R g108(.A(new_n164_), .B(new_n165_), .C(new_n166_), .Y(new_n167_));
  XNOR2x2_ASAP7_75t_R g109(.A(p21), .B(p9), .Y(new_n168_));
  NAND3x1_ASAP7_75t_R g110(.A(new_n163_), .B(new_n167_), .C(new_n168_), .Y(new_n169_));
  INVx1_ASAP7_75t_R   g111(.A(p32), .Y(new_n170_));
  INVx1_ASAP7_75t_R   g112(.A(p11), .Y(new_n171_));
  AO21x1_ASAP7_75t_R  g113(.A1(new_n121_), .A2(new_n170_), .B(new_n171_), .Y(new_n172_));
  INVx1_ASAP7_75t_R   g114(.A(new_n172_), .Y(new_n173_));
  NAND2x1_ASAP7_75t_R g115(.A(p23), .B(new_n157_), .Y(new_n174_));
  XOR2x2_ASAP7_75t_R  g116(.A(p24), .B(p22), .Y(new_n175_));
  NAND2x1_ASAP7_75t_R g117(.A(new_n174_), .B(new_n175_), .Y(new_n176_));
  INVx1_ASAP7_75t_R   g118(.A(new_n157_), .Y(new_n177_));
  OR3x1_ASAP7_75t_R   g119(.A(new_n175_), .B(new_n158_), .C(new_n177_), .Y(new_n178_));
  NOR2x1_ASAP7_75t_R  g120(.A(new_n150_), .B(new_n147_), .Y(new_n179_));
  AOI21x1_ASAP7_75t_R g121(.A1(new_n176_), .A2(new_n178_), .B(new_n179_), .Y(new_n180_));
  NAND2x1_ASAP7_75t_R g122(.A(new_n153_), .B(new_n154_), .Y(new_n181_));
  NOR2x1_ASAP7_75t_R  g123(.A(new_n174_), .B(new_n175_), .Y(new_n182_));
  AND2x2_ASAP7_75t_R  g124(.A(new_n174_), .B(new_n175_), .Y(new_n183_));
  NOR3x1_ASAP7_75t_R  g125(.A(new_n181_), .B(new_n182_), .C(new_n183_), .Y(new_n184_));
  INVx1_ASAP7_75t_R   g126(.A(new_n168_), .Y(new_n185_));
  OAI21x1_ASAP7_75t_R g127(.A1(new_n180_), .A2(new_n184_), .B(new_n185_), .Y(new_n186_));
  NAND3x1_ASAP7_75t_R g128(.A(new_n169_), .B(new_n173_), .C(new_n186_), .Y(new_n187_));
  OAI21x1_ASAP7_75t_R g129(.A1(new_n182_), .A2(new_n183_), .B(new_n181_), .Y(new_n188_));
  NAND3x1_ASAP7_75t_R g130(.A(new_n179_), .B(new_n178_), .C(new_n176_), .Y(new_n189_));
  AO21x1_ASAP7_75t_R  g131(.A1(new_n188_), .A2(new_n189_), .B(new_n185_), .Y(new_n190_));
  NAND3x1_ASAP7_75t_R g132(.A(new_n189_), .B(new_n188_), .C(new_n185_), .Y(new_n191_));
  AND2x2_ASAP7_75t_R  g133(.A(new_n121_), .B(new_n172_), .Y(new_n192_));
  NAND3x1_ASAP7_75t_R g134(.A(new_n190_), .B(new_n191_), .C(new_n192_), .Y(new_n193_));
  AND2x2_ASAP7_75t_R  g135(.A(p2), .B(p11), .Y(new_n194_));
  INVx1_ASAP7_75t_R   g136(.A(new_n194_), .Y(new_n195_));
  NAND3x1_ASAP7_75t_R g137(.A(new_n187_), .B(new_n193_), .C(new_n195_), .Y(new_n196_));
  AOI21x1_ASAP7_75t_R g138(.A1(new_n141_), .A2(new_n144_), .B(new_n196_), .Y(new_n197_));
  AND3x1_ASAP7_75t_R  g139(.A(new_n119_), .B(new_n123_), .C(new_n197_), .Y(new_n198_));
  AO21x1_ASAP7_75t_R  g140(.A1(new_n121_), .A2(new_n170_), .B(new_n158_), .Y(new_n199_));
  NOR2x1_ASAP7_75t_R  g141(.A(p14), .B(p22), .Y(new_n200_));
  AND2x2_ASAP7_75t_R  g142(.A(p14), .B(p22), .Y(new_n201_));
  INVx1_ASAP7_75t_R   g143(.A(p28), .Y(new_n202_));
  NOR2x1_ASAP7_75t_R  g144(.A(p1), .B(new_n202_), .Y(new_n203_));
  OAI21x1_ASAP7_75t_R g145(.A1(new_n200_), .A2(new_n201_), .B(new_n203_), .Y(new_n204_));
  NAND2x1_ASAP7_75t_R g146(.A(p28), .B(new_n107_), .Y(new_n205_));
  XOR2x2_ASAP7_75t_R  g147(.A(p14), .B(p22), .Y(new_n206_));
  NAND2x1_ASAP7_75t_R g148(.A(new_n205_), .B(new_n206_), .Y(new_n207_));
  NAND2x1_ASAP7_75t_R g149(.A(new_n204_), .B(new_n207_), .Y(new_n208_));
  XOR2x2_ASAP7_75t_R  g150(.A(new_n208_), .B(new_n96_), .Y(new_n209_));
  OR3x1_ASAP7_75t_R   g151(.A(new_n209_), .B(new_n134_), .C(p2), .Y(new_n210_));
  XOR2x2_ASAP7_75t_R  g152(.A(new_n208_), .B(new_n67_), .Y(new_n211_));
  NOR2x1_ASAP7_75t_R  g153(.A(new_n136_), .B(new_n211_), .Y(new_n212_));
  INVx1_ASAP7_75t_R   g154(.A(p29), .Y(new_n213_));
  AOI21x1_ASAP7_75t_R g155(.A1(new_n121_), .A2(new_n212_), .B(new_n213_), .Y(new_n214_));
  NAND2x1_ASAP7_75t_R g156(.A(new_n136_), .B(new_n211_), .Y(new_n215_));
  NAND2x1_ASAP7_75t_R g157(.A(new_n134_), .B(new_n209_), .Y(new_n216_));
  NAND2x1_ASAP7_75t_R g158(.A(new_n121_), .B(new_n213_), .Y(new_n217_));
  AOI21x1_ASAP7_75t_R g159(.A1(new_n215_), .A2(new_n216_), .B(new_n217_), .Y(new_n218_));
  AOI21x1_ASAP7_75t_R g160(.A1(new_n210_), .A2(new_n214_), .B(new_n218_), .Y(new_n219_));
  OR2x4_ASAP7_75t_R   g161(.A(new_n199_), .B(new_n219_), .Y(new_n220_));
  NAND2x1_ASAP7_75t_R g162(.A(p16), .B(new_n124_), .Y(new_n221_));
  XOR2x2_ASAP7_75t_R  g163(.A(new_n221_), .B(p19), .Y(new_n222_));
  NAND2x1_ASAP7_75t_R g164(.A(new_n179_), .B(new_n222_), .Y(new_n223_));
  XOR2x2_ASAP7_75t_R  g165(.A(new_n221_), .B(new_n64_), .Y(new_n224_));
  NAND2x1_ASAP7_75t_R g166(.A(new_n181_), .B(new_n224_), .Y(new_n225_));
  XOR2x2_ASAP7_75t_R  g167(.A(p5), .B(p18), .Y(new_n226_));
  XOR2x2_ASAP7_75t_R  g168(.A(p17), .B(p8), .Y(new_n227_));
  XOR2x2_ASAP7_75t_R  g169(.A(new_n226_), .B(new_n227_), .Y(new_n228_));
  NAND3x1_ASAP7_75t_R g170(.A(new_n223_), .B(new_n225_), .C(new_n228_), .Y(new_n229_));
  AO21x1_ASAP7_75t_R  g171(.A1(new_n223_), .A2(new_n225_), .B(new_n228_), .Y(new_n230_));
  NAND2x1_ASAP7_75t_R g172(.A(new_n229_), .B(new_n230_), .Y(new_n231_));
  INVx1_ASAP7_75t_R   g173(.A(p20), .Y(new_n232_));
  AO21x1_ASAP7_75t_R  g174(.A1(new_n121_), .A2(new_n231_), .B(new_n232_), .Y(new_n233_));
  AND3x1_ASAP7_75t_R  g175(.A(new_n107_), .B(new_n170_), .C(p11), .Y(new_n234_));
  XOR2x2_ASAP7_75t_R  g176(.A(p8), .B(p9), .Y(new_n235_));
  XOR2x2_ASAP7_75t_R  g177(.A(new_n234_), .B(new_n235_), .Y(new_n236_));
  XOR2x2_ASAP7_75t_R  g178(.A(p5), .B(p10), .Y(new_n237_));
  XOR2x2_ASAP7_75t_R  g179(.A(p7), .B(p6), .Y(new_n238_));
  XOR2x2_ASAP7_75t_R  g180(.A(new_n237_), .B(new_n238_), .Y(new_n239_));
  XOR2x2_ASAP7_75t_R  g181(.A(new_n236_), .B(new_n239_), .Y(new_n240_));
  NAND3x1_ASAP7_75t_R g182(.A(new_n240_), .B(new_n121_), .C(p12), .Y(new_n241_));
  AO21x1_ASAP7_75t_R  g183(.A1(new_n121_), .A2(new_n240_), .B(p12), .Y(new_n242_));
  NAND2x1_ASAP7_75t_R g184(.A(new_n241_), .B(new_n242_), .Y(new_n243_));
  NOR2x1_ASAP7_75t_R  g185(.A(p2), .B(p20), .Y(new_n244_));
  OR3x1_ASAP7_75t_R   g186(.A(p2), .B(p3), .C(p1), .Y(new_n245_));
  NOR2x1_ASAP7_75t_R  g187(.A(p4), .B(p1), .Y(new_n246_));
  INVx1_ASAP7_75t_R   g188(.A(new_n246_), .Y(new_n247_));
  AND2x2_ASAP7_75t_R  g189(.A(p0), .B(new_n170_), .Y(new_n248_));
  AO21x1_ASAP7_75t_R  g190(.A1(new_n245_), .A2(new_n247_), .B(new_n248_), .Y(new_n249_));
  AOI21x1_ASAP7_75t_R g191(.A1(new_n244_), .A2(new_n231_), .B(new_n249_), .Y(new_n250_));
  NAND3x1_ASAP7_75t_R g192(.A(new_n233_), .B(new_n243_), .C(new_n250_), .Y(new_n251_));
  INVx1_ASAP7_75t_R   g193(.A(new_n251_), .Y(new_n252_));
  AND3x1_ASAP7_75t_R  g194(.A(new_n198_), .B(new_n220_), .C(new_n252_), .Y(new_n253_));
  XNOR2x2_ASAP7_75t_R g195(.A(p14), .B(new_n253_), .Y(o0));
  INVx1_ASAP7_75t_R   g196(.A(new_n59_), .Y(new_n255_));
  AOI21x1_ASAP7_75t_R g197(.A1(new_n118_), .A2(new_n123_), .B(new_n255_), .Y(new_n256_));
  OAI21x1_ASAP7_75t_R g198(.A1(new_n199_), .A2(new_n219_), .B(new_n197_), .Y(new_n257_));
  AO21x1_ASAP7_75t_R  g199(.A1(p0), .A2(new_n170_), .B(new_n247_), .Y(new_n258_));
  NOR2x1_ASAP7_75t_R  g200(.A(p31), .B(p1), .Y(new_n259_));
  INVx1_ASAP7_75t_R   g201(.A(new_n259_), .Y(new_n260_));
  OR3x1_ASAP7_75t_R   g202(.A(new_n248_), .B(p2), .C(new_n260_), .Y(new_n261_));
  AND2x2_ASAP7_75t_R  g203(.A(new_n258_), .B(new_n261_), .Y(new_n262_));
  AOI21x1_ASAP7_75t_R g204(.A1(new_n241_), .A2(new_n242_), .B(new_n262_), .Y(new_n263_));
  NAND2x1_ASAP7_75t_R g205(.A(new_n244_), .B(new_n231_), .Y(new_n264_));
  NAND3x1_ASAP7_75t_R g206(.A(new_n263_), .B(new_n233_), .C(new_n264_), .Y(new_n265_));
  NOR3x1_ASAP7_75t_R  g207(.A(new_n256_), .B(new_n257_), .C(new_n265_), .Y(new_n266_));
  XOR2x2_ASAP7_75t_R  g208(.A(new_n266_), .B(new_n62_), .Y(o1));
  XOR2x2_ASAP7_75t_R  g209(.A(new_n266_), .B(new_n64_), .Y(o2));
  XOR2x2_ASAP7_75t_R  g210(.A(new_n253_), .B(new_n160_), .Y(o3));
  XOR2x2_ASAP7_75t_R  g211(.A(new_n266_), .B(new_n60_), .Y(o4));
  XOR2x2_ASAP7_75t_R  g212(.A(new_n266_), .B(new_n155_), .Y(o5));
  OR3x1_ASAP7_75t_R   g213(.A(new_n256_), .B(new_n257_), .C(new_n251_), .Y(new_n272_));
  XOR2x2_ASAP7_75t_R  g214(.A(new_n272_), .B(p9), .Y(o6));
  XOR2x2_ASAP7_75t_R  g215(.A(new_n272_), .B(p8), .Y(o7));
  XOR2x2_ASAP7_75t_R  g216(.A(new_n272_), .B(p15), .Y(o8));
  INVx1_ASAP7_75t_R   g217(.A(new_n199_), .Y(new_n276_));
  NAND2x1_ASAP7_75t_R g218(.A(new_n276_), .B(new_n219_), .Y(new_n277_));
  NOR2x1_ASAP7_75t_R  g219(.A(new_n265_), .B(new_n277_), .Y(new_n278_));
  AO21x1_ASAP7_75t_R  g220(.A1(new_n118_), .A2(new_n123_), .B(new_n255_), .Y(new_n279_));
  NAND3x1_ASAP7_75t_R g221(.A(new_n278_), .B(new_n197_), .C(new_n279_), .Y(new_n280_));
  XOR2x2_ASAP7_75t_R  g222(.A(new_n280_), .B(p18), .Y(o9));
  XOR2x2_ASAP7_75t_R  g223(.A(new_n280_), .B(p6), .Y(o10));
  XOR2x2_ASAP7_75t_R  g224(.A(new_n280_), .B(p21), .Y(o11));
  XOR2x2_ASAP7_75t_R  g225(.A(new_n280_), .B(p5), .Y(o12));
  NOR2x1_ASAP7_75t_R  g226(.A(new_n251_), .B(new_n277_), .Y(new_n285_));
  AND3x1_ASAP7_75t_R  g227(.A(new_n285_), .B(new_n197_), .C(new_n279_), .Y(new_n286_));
  INVx1_ASAP7_75t_R   g228(.A(p13), .Y(new_n287_));
  XOR2x2_ASAP7_75t_R  g229(.A(new_n286_), .B(new_n287_), .Y(o13));
  XNOR2x2_ASAP7_75t_R g230(.A(p17), .B(new_n253_), .Y(o14));
  XNOR2x2_ASAP7_75t_R g231(.A(p10), .B(new_n253_), .Y(o15));
  INVx1_ASAP7_75t_R   g232(.A(p4), .Y(new_n291_));
  AND3x1_ASAP7_75t_R  g233(.A(new_n261_), .B(new_n249_), .C(new_n258_), .Y(new_n292_));
  AOI21x1_ASAP7_75t_R g234(.A1(new_n244_), .A2(new_n231_), .B(new_n292_), .Y(new_n293_));
  NAND3x1_ASAP7_75t_R g235(.A(new_n233_), .B(new_n243_), .C(new_n293_), .Y(new_n294_));
  OR3x1_ASAP7_75t_R   g236(.A(new_n256_), .B(new_n257_), .C(new_n294_), .Y(new_n295_));
  NAND2x1_ASAP7_75t_R g237(.A(new_n118_), .B(new_n123_), .Y(new_n296_));
  INVx1_ASAP7_75t_R   g238(.A(new_n296_), .Y(new_n297_));
  AND3x1_ASAP7_75t_R  g239(.A(new_n219_), .B(new_n255_), .C(new_n199_), .Y(new_n298_));
  AND3x1_ASAP7_75t_R  g240(.A(new_n233_), .B(new_n243_), .C(new_n264_), .Y(new_n299_));
  AND3x1_ASAP7_75t_R  g241(.A(new_n298_), .B(new_n299_), .C(new_n197_), .Y(new_n300_));
  AOI21x1_ASAP7_75t_R g242(.A1(new_n297_), .A2(new_n300_), .B(p1), .Y(new_n301_));
  OAI21x1_ASAP7_75t_R g243(.A1(new_n291_), .A2(new_n295_), .B(new_n301_), .Y(o16));
  NOR2x1_ASAP7_75t_R  g244(.A(new_n111_), .B(new_n115_), .Y(new_n303_));
  OR3x1_ASAP7_75t_R   g245(.A(new_n303_), .B(p2), .C(new_n117_), .Y(new_n304_));
  OAI21x1_ASAP7_75t_R g246(.A1(new_n304_), .A2(new_n295_), .B(new_n247_), .Y(new_n305_));
  NAND2x1_ASAP7_75t_R g247(.A(new_n121_), .B(new_n116_), .Y(new_n306_));
  OA21x2_ASAP7_75t_R  g248(.A1(new_n306_), .A2(new_n295_), .B(new_n303_), .Y(new_n307_));
  NOR2x1_ASAP7_75t_R  g249(.A(new_n305_), .B(new_n307_), .Y(o17));
  NAND2x1_ASAP7_75t_R g250(.A(new_n215_), .B(new_n216_), .Y(new_n309_));
  INVx1_ASAP7_75t_R   g251(.A(new_n309_), .Y(new_n310_));
  OR3x1_ASAP7_75t_R   g252(.A(new_n295_), .B(p2), .C(new_n213_), .Y(new_n311_));
  AND3x1_ASAP7_75t_R  g253(.A(new_n309_), .B(new_n121_), .C(p29), .Y(new_n312_));
  NOR3x1_ASAP7_75t_R  g254(.A(new_n256_), .B(new_n257_), .C(new_n294_), .Y(new_n313_));
  AO21x1_ASAP7_75t_R  g255(.A1(new_n312_), .A2(new_n313_), .B(new_n246_), .Y(new_n314_));
  AOI21x1_ASAP7_75t_R g256(.A1(new_n310_), .A2(new_n311_), .B(new_n314_), .Y(o18));
  NAND2x1_ASAP7_75t_R g257(.A(p20), .B(new_n313_), .Y(new_n316_));
  AOI21x1_ASAP7_75t_R g258(.A1(new_n231_), .A2(new_n316_), .B(new_n246_), .Y(o19));
  NAND2x1_ASAP7_75t_R g259(.A(p12), .B(new_n313_), .Y(new_n318_));
  AOI21x1_ASAP7_75t_R g260(.A1(new_n240_), .A2(new_n318_), .B(new_n246_), .Y(o20));
  NAND2x1_ASAP7_75t_R g261(.A(new_n191_), .B(new_n190_), .Y(new_n320_));
  AO21x1_ASAP7_75t_R  g262(.A1(new_n173_), .A2(new_n313_), .B(new_n320_), .Y(new_n321_));
  AND2x2_ASAP7_75t_R  g263(.A(new_n247_), .B(new_n321_), .Y(o21));
  AO21x1_ASAP7_75t_R  g264(.A1(p30), .A2(p31), .B(p1), .Y(new_n323_));
  INVx1_ASAP7_75t_R   g265(.A(new_n323_), .Y(new_n324_));
  OR3x1_ASAP7_75t_R   g266(.A(new_n256_), .B(new_n257_), .C(new_n265_), .Y(new_n325_));
  AND3x1_ASAP7_75t_R  g267(.A(new_n100_), .B(new_n89_), .C(new_n260_), .Y(new_n326_));
  INVx1_ASAP7_75t_R   g268(.A(new_n326_), .Y(new_n327_));
  AND3x1_ASAP7_75t_R  g269(.A(new_n263_), .B(new_n233_), .C(new_n264_), .Y(new_n328_));
  NAND2x1_ASAP7_75t_R g270(.A(new_n327_), .B(new_n328_), .Y(new_n329_));
  NOR3x1_ASAP7_75t_R  g271(.A(new_n329_), .B(new_n257_), .C(new_n256_), .Y(new_n330_));
  AOI21x1_ASAP7_75t_R g272(.A1(new_n325_), .A2(new_n326_), .B(new_n330_), .Y(new_n331_));
  NOR2x1_ASAP7_75t_R  g273(.A(new_n326_), .B(new_n265_), .Y(new_n332_));
  AOI21x1_ASAP7_75t_R g274(.A1(new_n59_), .A2(new_n296_), .B(new_n257_), .Y(new_n333_));
  AOI21x1_ASAP7_75t_R g275(.A1(new_n332_), .A2(new_n333_), .B(new_n323_), .Y(new_n334_));
  OAI21x1_ASAP7_75t_R g276(.A1(new_n266_), .A2(new_n327_), .B(new_n334_), .Y(new_n335_));
  OAI21x1_ASAP7_75t_R g277(.A1(new_n324_), .A2(new_n331_), .B(new_n335_), .Y(o22));
  NOR2x1_ASAP7_75t_R  g278(.A(p1), .B(p28), .Y(new_n337_));
  NOR2x1_ASAP7_75t_R  g279(.A(new_n152_), .B(new_n149_), .Y(new_n338_));
  XOR2x2_ASAP7_75t_R  g280(.A(new_n134_), .B(new_n338_), .Y(new_n339_));
  XNOR2x2_ASAP7_75t_R g281(.A(new_n337_), .B(new_n339_), .Y(new_n340_));
  OA21x2_ASAP7_75t_R  g282(.A1(p3), .A2(p1), .B(new_n340_), .Y(new_n341_));
  XOR2x2_ASAP7_75t_R  g283(.A(new_n272_), .B(new_n341_), .Y(o23));
  NAND2x1_ASAP7_75t_R g284(.A(new_n140_), .B(new_n313_), .Y(new_n343_));
  AND2x2_ASAP7_75t_R  g285(.A(new_n138_), .B(new_n135_), .Y(new_n344_));
  AND3x1_ASAP7_75t_R  g286(.A(new_n343_), .B(new_n247_), .C(new_n344_), .Y(o24));
endmodule


