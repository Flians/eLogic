// Benchmark "/tmp/" written by ABC on Mon Oct 12 15:05:27 2026

module \/tmp/  ( 
    p0, p29, p13, p30, p18, p15, p1, p3, p4, p24, p26, p32, p27, p17, p6,
    p8, p11, p16, p14, p20, p5, p21, p7, p25, p23, p28, p12, p10, p31, p9,
    p2, p19, p22,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24  );
  input  p0, p29, p13, p30, p18, p15, p1, p3, p4, p24, p26, p32, p27,
    p17, p6, p8, p11, p16, p14, p20, p5, p21, p7, p25, p23, p28, p12, p10,
    p31, p9, p2, p19, p22;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24;
  wire new_n59_, new_n60_, new_n61_, new_n62_, new_n63_, new_n64_, new_n65_,
    new_n66_, new_n67_, new_n68_, new_n69_, new_n70_, new_n71_, new_n72_,
    new_n73_, new_n74_, new_n75_, new_n76_, new_n77_, new_n78_, new_n79_,
    new_n80_, new_n81_, new_n82_, new_n83_, new_n84_, new_n85_, new_n86_,
    new_n87_, new_n88_, new_n89_, new_n90_, new_n91_, new_n92_, new_n93_,
    new_n94_, new_n95_, new_n96_, new_n97_, new_n98_, new_n99_, new_n100_,
    new_n101_, new_n102_, new_n103_, new_n104_, new_n105_, new_n106_,
    new_n107_, new_n108_, new_n109_, new_n110_, new_n111_, new_n112_,
    new_n113_, new_n114_, new_n115_, new_n116_, new_n117_, new_n118_,
    new_n119_, new_n120_, new_n121_, new_n122_, new_n123_, new_n124_,
    new_n125_, new_n126_, new_n127_, new_n128_, new_n129_, new_n130_,
    new_n131_, new_n132_, new_n133_, new_n134_, new_n135_, new_n136_,
    new_n137_, new_n138_, new_n139_, new_n140_, new_n141_, new_n142_,
    new_n143_, new_n144_, new_n145_, new_n146_, new_n147_, new_n148_,
    new_n149_, new_n150_, new_n151_, new_n152_, new_n153_, new_n154_,
    new_n155_, new_n156_, new_n157_, new_n158_, new_n159_, new_n160_,
    new_n161_, new_n162_, new_n163_, new_n164_, new_n165_, new_n166_,
    new_n167_, new_n168_, new_n169_, new_n170_, new_n171_, new_n172_,
    new_n173_, new_n174_, new_n175_, new_n176_, new_n177_, new_n178_,
    new_n179_, new_n180_, new_n181_, new_n182_, new_n183_, new_n184_,
    new_n185_, new_n186_, new_n187_, new_n188_, new_n189_, new_n190_,
    new_n191_, new_n192_, new_n193_, new_n194_, new_n195_, new_n196_,
    new_n197_, new_n198_, new_n199_, new_n200_, new_n201_, new_n202_,
    new_n203_, new_n204_, new_n205_, new_n206_, new_n207_, new_n208_,
    new_n209_, new_n210_, new_n211_, new_n212_, new_n213_, new_n214_,
    new_n215_, new_n216_, new_n217_, new_n218_, new_n219_, new_n220_,
    new_n221_, new_n222_, new_n223_, new_n224_, new_n225_, new_n226_,
    new_n227_, new_n228_, new_n229_, new_n230_, new_n231_, new_n232_,
    new_n233_, new_n234_, new_n235_, new_n236_, new_n237_, new_n238_,
    new_n239_, new_n240_, new_n241_, new_n242_, new_n243_, new_n244_,
    new_n245_, new_n246_, new_n247_, new_n248_, new_n249_, new_n250_,
    new_n251_, new_n252_, new_n253_, new_n254_, new_n255_, new_n256_,
    new_n257_, new_n258_, new_n259_, new_n260_, new_n261_, new_n262_,
    new_n263_, new_n264_, new_n265_, new_n266_, new_n267_, new_n268_,
    new_n269_, new_n270_, new_n271_, new_n272_, new_n274_, new_n275_,
    new_n276_, new_n277_, new_n278_, new_n279_, new_n280_, new_n281_,
    new_n282_, new_n285_, new_n289_, new_n293_, new_n294_, new_n295_,
    new_n296_, new_n297_, new_n298_, new_n300_, new_n302_, new_n304_,
    new_n305_, new_n307_, new_n308_, new_n309_, new_n311_, new_n312_,
    new_n314_, new_n315_, new_n317_, new_n318_, new_n319_, new_n320_,
    new_n321_, new_n322_, new_n323_, new_n324_, new_n325_, new_n326_,
    new_n327_, new_n328_, new_n330_, new_n331_, new_n332_, new_n333_,
    new_n334_, new_n335_, new_n337_, new_n338_, new_n339_, new_n340_,
    new_n341_, new_n343_, new_n344_, new_n346_, new_n347_, new_n349_,
    new_n350_, new_n352_, new_n353_, new_n354_, new_n355_, new_n356_,
    new_n357_, new_n358_, new_n359_, new_n360_, new_n361_, new_n362_,
    new_n363_, new_n364_, new_n366_, new_n367_, new_n368_, new_n369_,
    new_n370_, new_n372_, new_n373_;
  INVx1_ASAP7_75t_R   g000(.A(p23), .Y(new_n59_));
  NOR2x1_ASAP7_75t_R  g001(.A(p32), .B(p2), .Y(new_n60_));
  NOR2x1_ASAP7_75t_R  g002(.A(new_n59_), .B(new_n60_), .Y(new_n61_));
  INVx1_ASAP7_75t_R   g003(.A(new_n61_), .Y(new_n62_));
  NOR2x1_ASAP7_75t_R  g004(.A(p14), .B(p22), .Y(new_n63_));
  AND2x2_ASAP7_75t_R  g005(.A(p14), .B(p22), .Y(new_n64_));
  INVx1_ASAP7_75t_R   g006(.A(p28), .Y(new_n65_));
  NOR2x1_ASAP7_75t_R  g007(.A(p1), .B(new_n65_), .Y(new_n66_));
  OAI21x1_ASAP7_75t_R g008(.A1(new_n63_), .A2(new_n64_), .B(new_n66_), .Y(new_n67_));
  INVx1_ASAP7_75t_R   g009(.A(p1), .Y(new_n68_));
  NAND2x1_ASAP7_75t_R g010(.A(p28), .B(new_n68_), .Y(new_n69_));
  XOR2x2_ASAP7_75t_R  g011(.A(p14), .B(p22), .Y(new_n70_));
  NAND2x1_ASAP7_75t_R g012(.A(new_n69_), .B(new_n70_), .Y(new_n71_));
  NAND2x1_ASAP7_75t_R g013(.A(new_n67_), .B(new_n71_), .Y(new_n72_));
  INVx1_ASAP7_75t_R   g014(.A(p19), .Y(new_n73_));
  NOR2x1_ASAP7_75t_R  g015(.A(p25), .B(new_n73_), .Y(new_n74_));
  INVx1_ASAP7_75t_R   g016(.A(p25), .Y(new_n75_));
  NOR2x1_ASAP7_75t_R  g017(.A(p19), .B(new_n75_), .Y(new_n76_));
  OAI21x1_ASAP7_75t_R g018(.A1(new_n74_), .A2(new_n76_), .B(p7), .Y(new_n77_));
  NAND2x1_ASAP7_75t_R g019(.A(p19), .B(new_n75_), .Y(new_n78_));
  NAND2x1_ASAP7_75t_R g020(.A(p25), .B(new_n73_), .Y(new_n79_));
  INVx1_ASAP7_75t_R   g021(.A(p7), .Y(new_n80_));
  NAND3x1_ASAP7_75t_R g022(.A(new_n78_), .B(new_n79_), .C(new_n80_), .Y(new_n81_));
  NAND2x1_ASAP7_75t_R g023(.A(new_n77_), .B(new_n81_), .Y(new_n82_));
  XOR2x2_ASAP7_75t_R  g024(.A(new_n72_), .B(new_n82_), .Y(new_n83_));
  NOR2x1_ASAP7_75t_R  g025(.A(p8), .B(p9), .Y(new_n84_));
  AND2x2_ASAP7_75t_R  g026(.A(p8), .B(p9), .Y(new_n85_));
  INVx1_ASAP7_75t_R   g027(.A(p15), .Y(new_n86_));
  OAI21x1_ASAP7_75t_R g028(.A1(new_n84_), .A2(new_n85_), .B(new_n86_), .Y(new_n87_));
  OR3x1_ASAP7_75t_R   g029(.A(new_n85_), .B(new_n86_), .C(new_n84_), .Y(new_n88_));
  NAND2x1_ASAP7_75t_R g030(.A(new_n87_), .B(new_n88_), .Y(new_n89_));
  NOR2x1_ASAP7_75t_R  g031(.A(p24), .B(p17), .Y(new_n90_));
  AND2x2_ASAP7_75t_R  g032(.A(p24), .B(p17), .Y(new_n91_));
  OAI21x1_ASAP7_75t_R g033(.A1(new_n90_), .A2(new_n91_), .B(p10), .Y(new_n92_));
  OR3x1_ASAP7_75t_R   g034(.A(new_n91_), .B(p10), .C(new_n90_), .Y(new_n93_));
  NAND2x1_ASAP7_75t_R g035(.A(new_n92_), .B(new_n93_), .Y(new_n94_));
  XNOR2x2_ASAP7_75t_R g036(.A(new_n89_), .B(new_n94_), .Y(new_n95_));
  OR3x1_ASAP7_75t_R   g037(.A(new_n83_), .B(new_n95_), .C(p2), .Y(new_n96_));
  INVx1_ASAP7_75t_R   g038(.A(p2), .Y(new_n97_));
  XOR2x2_ASAP7_75t_R  g039(.A(new_n89_), .B(new_n94_), .Y(new_n98_));
  NOR2x1_ASAP7_75t_R  g040(.A(p19), .B(new_n80_), .Y(new_n99_));
  AO21x1_ASAP7_75t_R  g041(.A1(p19), .A2(new_n80_), .B(new_n75_), .Y(new_n100_));
  NOR2x1_ASAP7_75t_R  g042(.A(p7), .B(new_n73_), .Y(new_n101_));
  OAI21x1_ASAP7_75t_R g043(.A1(new_n99_), .A2(new_n101_), .B(new_n75_), .Y(new_n102_));
  OAI21x1_ASAP7_75t_R g044(.A1(new_n99_), .A2(new_n100_), .B(new_n102_), .Y(new_n103_));
  XOR2x2_ASAP7_75t_R  g045(.A(new_n72_), .B(new_n103_), .Y(new_n104_));
  NOR2x1_ASAP7_75t_R  g046(.A(new_n98_), .B(new_n104_), .Y(new_n105_));
  INVx1_ASAP7_75t_R   g047(.A(p29), .Y(new_n106_));
  AOI21x1_ASAP7_75t_R g048(.A1(new_n97_), .A2(new_n105_), .B(new_n106_), .Y(new_n107_));
  NAND2x1_ASAP7_75t_R g049(.A(new_n98_), .B(new_n104_), .Y(new_n108_));
  NAND2x1_ASAP7_75t_R g050(.A(new_n95_), .B(new_n83_), .Y(new_n109_));
  NOR2x1_ASAP7_75t_R  g051(.A(p29), .B(p2), .Y(new_n110_));
  INVx1_ASAP7_75t_R   g052(.A(new_n110_), .Y(new_n111_));
  AOI21x1_ASAP7_75t_R g053(.A1(new_n108_), .A2(new_n109_), .B(new_n111_), .Y(new_n112_));
  AOI21x1_ASAP7_75t_R g054(.A1(new_n96_), .A2(new_n107_), .B(new_n112_), .Y(new_n113_));
  NOR2x1_ASAP7_75t_R  g055(.A(new_n62_), .B(new_n113_), .Y(new_n114_));
  XNOR2x2_ASAP7_75t_R g056(.A(p17), .B(p8), .Y(new_n115_));
  XOR2x2_ASAP7_75t_R  g057(.A(p18), .B(p5), .Y(new_n116_));
  XOR2x2_ASAP7_75t_R  g058(.A(new_n116_), .B(p19), .Y(new_n117_));
  NOR2x1_ASAP7_75t_R  g059(.A(new_n115_), .B(new_n117_), .Y(new_n118_));
  INVx1_ASAP7_75t_R   g060(.A(new_n115_), .Y(new_n119_));
  XOR2x2_ASAP7_75t_R  g061(.A(new_n116_), .B(new_n73_), .Y(new_n120_));
  NOR2x1_ASAP7_75t_R  g062(.A(new_n119_), .B(new_n120_), .Y(new_n121_));
  OAI21x1_ASAP7_75t_R g063(.A1(p13), .A2(p14), .B(p15), .Y(new_n122_));
  AND2x2_ASAP7_75t_R  g064(.A(p13), .B(p14), .Y(new_n123_));
  NOR2x1_ASAP7_75t_R  g065(.A(new_n122_), .B(new_n123_), .Y(new_n124_));
  NAND2x1_ASAP7_75t_R g066(.A(p13), .B(p14), .Y(new_n125_));
  OR3x1_ASAP7_75t_R   g067(.A(p13), .B(p15), .C(p14), .Y(new_n126_));
  OAI21x1_ASAP7_75t_R g068(.A1(p15), .A2(new_n125_), .B(new_n126_), .Y(new_n127_));
  NOR2x1_ASAP7_75t_R  g069(.A(new_n124_), .B(new_n127_), .Y(new_n128_));
  NOR2x1_ASAP7_75t_R  g070(.A(p0), .B(p1), .Y(new_n129_));
  NAND2x1_ASAP7_75t_R g071(.A(p16), .B(new_n129_), .Y(new_n130_));
  XOR2x2_ASAP7_75t_R  g072(.A(new_n128_), .B(new_n130_), .Y(new_n131_));
  OAI21x1_ASAP7_75t_R g073(.A1(new_n118_), .A2(new_n121_), .B(new_n131_), .Y(new_n132_));
  NOR2x1_ASAP7_75t_R  g074(.A(new_n119_), .B(new_n117_), .Y(new_n133_));
  NOR2x1_ASAP7_75t_R  g075(.A(new_n115_), .B(new_n120_), .Y(new_n134_));
  NOR2x1_ASAP7_75t_R  g076(.A(p13), .B(p14), .Y(new_n135_));
  OAI21x1_ASAP7_75t_R g077(.A1(new_n135_), .A2(new_n123_), .B(new_n86_), .Y(new_n136_));
  AO21x1_ASAP7_75t_R  g078(.A1(p13), .A2(p14), .B(new_n122_), .Y(new_n137_));
  NAND2x1_ASAP7_75t_R g079(.A(new_n136_), .B(new_n137_), .Y(new_n138_));
  XOR2x2_ASAP7_75t_R  g080(.A(new_n138_), .B(new_n130_), .Y(new_n139_));
  OAI21x1_ASAP7_75t_R g081(.A1(new_n133_), .A2(new_n134_), .B(new_n139_), .Y(new_n140_));
  NAND2x1_ASAP7_75t_R g082(.A(new_n132_), .B(new_n140_), .Y(new_n141_));
  INVx1_ASAP7_75t_R   g083(.A(p20), .Y(new_n142_));
  AO21x1_ASAP7_75t_R  g084(.A1(new_n97_), .A2(new_n141_), .B(new_n142_), .Y(new_n143_));
  NOR2x1_ASAP7_75t_R  g085(.A(p20), .B(p2), .Y(new_n144_));
  INVx1_ASAP7_75t_R   g086(.A(new_n144_), .Y(new_n145_));
  AO21x1_ASAP7_75t_R  g087(.A1(new_n132_), .A2(new_n140_), .B(new_n145_), .Y(new_n146_));
  XOR2x2_ASAP7_75t_R  g088(.A(p6), .B(p5), .Y(new_n147_));
  XNOR2x2_ASAP7_75t_R g089(.A(p7), .B(p10), .Y(new_n148_));
  NAND2x1_ASAP7_75t_R g090(.A(new_n147_), .B(new_n148_), .Y(new_n149_));
  XOR2x2_ASAP7_75t_R  g091(.A(p7), .B(p10), .Y(new_n150_));
  XNOR2x2_ASAP7_75t_R g092(.A(p6), .B(p5), .Y(new_n151_));
  NAND2x1_ASAP7_75t_R g093(.A(new_n150_), .B(new_n151_), .Y(new_n152_));
  NAND2x1_ASAP7_75t_R g094(.A(new_n149_), .B(new_n152_), .Y(new_n153_));
  OR2x4_ASAP7_75t_R   g095(.A(new_n84_), .B(new_n85_), .Y(new_n154_));
  NOR2x1_ASAP7_75t_R  g096(.A(p1), .B(p32), .Y(new_n155_));
  NAND2x1_ASAP7_75t_R g097(.A(p11), .B(new_n155_), .Y(new_n156_));
  INVx1_ASAP7_75t_R   g098(.A(new_n156_), .Y(new_n157_));
  NAND3x1_ASAP7_75t_R g099(.A(new_n153_), .B(new_n154_), .C(new_n157_), .Y(new_n158_));
  OA21x2_ASAP7_75t_R  g100(.A1(new_n147_), .A2(new_n148_), .B(new_n156_), .Y(new_n159_));
  NAND3x1_ASAP7_75t_R g101(.A(new_n159_), .B(new_n149_), .C(new_n154_), .Y(new_n160_));
  AND3x1_ASAP7_75t_R  g102(.A(new_n158_), .B(new_n97_), .C(new_n160_), .Y(new_n161_));
  NAND3x1_ASAP7_75t_R g103(.A(new_n149_), .B(new_n152_), .C(new_n157_), .Y(new_n162_));
  AO21x1_ASAP7_75t_R  g104(.A1(new_n149_), .A2(new_n152_), .B(new_n157_), .Y(new_n163_));
  AOI21x1_ASAP7_75t_R g105(.A1(new_n162_), .A2(new_n163_), .B(new_n154_), .Y(new_n164_));
  INVx1_ASAP7_75t_R   g106(.A(new_n164_), .Y(new_n165_));
  INVx1_ASAP7_75t_R   g107(.A(p12), .Y(new_n166_));
  NAND3x1_ASAP7_75t_R g108(.A(new_n161_), .B(new_n165_), .C(new_n166_), .Y(new_n167_));
  NAND3x1_ASAP7_75t_R g109(.A(new_n158_), .B(new_n97_), .C(new_n160_), .Y(new_n168_));
  OAI21x1_ASAP7_75t_R g110(.A1(new_n164_), .A2(new_n168_), .B(p12), .Y(new_n169_));
  AND3x1_ASAP7_75t_R  g111(.A(new_n146_), .B(new_n167_), .C(new_n169_), .Y(new_n170_));
  NAND2x1_ASAP7_75t_R g112(.A(new_n143_), .B(new_n170_), .Y(new_n171_));
  OR3x1_ASAP7_75t_R   g113(.A(p1), .B(p3), .C(p2), .Y(new_n172_));
  OR2x4_ASAP7_75t_R   g114(.A(p1), .B(p4), .Y(new_n173_));
  INVx1_ASAP7_75t_R   g115(.A(p0), .Y(new_n174_));
  NOR2x1_ASAP7_75t_R  g116(.A(p32), .B(new_n174_), .Y(new_n175_));
  AO21x1_ASAP7_75t_R  g117(.A1(new_n172_), .A2(new_n173_), .B(new_n175_), .Y(new_n176_));
  NOR3x1_ASAP7_75t_R  g118(.A(new_n114_), .B(new_n171_), .C(new_n176_), .Y(new_n177_));
  INVx1_ASAP7_75t_R   g119(.A(p26), .Y(new_n178_));
  NOR2x1_ASAP7_75t_R  g120(.A(p0), .B(p2), .Y(new_n179_));
  NOR2x1_ASAP7_75t_R  g121(.A(new_n178_), .B(new_n179_), .Y(new_n180_));
  INVx1_ASAP7_75t_R   g122(.A(p21), .Y(new_n181_));
  NOR2x1_ASAP7_75t_R  g123(.A(p6), .B(new_n181_), .Y(new_n182_));
  INVx1_ASAP7_75t_R   g124(.A(p6), .Y(new_n183_));
  NOR2x1_ASAP7_75t_R  g125(.A(p21), .B(new_n183_), .Y(new_n184_));
  OAI21x1_ASAP7_75t_R g126(.A1(new_n182_), .A2(new_n184_), .B(p18), .Y(new_n185_));
  NAND2x1_ASAP7_75t_R g127(.A(p21), .B(new_n183_), .Y(new_n186_));
  NAND2x1_ASAP7_75t_R g128(.A(p6), .B(new_n181_), .Y(new_n187_));
  INVx1_ASAP7_75t_R   g129(.A(p18), .Y(new_n188_));
  NAND3x1_ASAP7_75t_R g130(.A(new_n186_), .B(new_n187_), .C(new_n188_), .Y(new_n189_));
  NAND2x1_ASAP7_75t_R g131(.A(new_n185_), .B(new_n189_), .Y(new_n190_));
  NAND2x1_ASAP7_75t_R g132(.A(new_n103_), .B(new_n190_), .Y(new_n191_));
  XOR2x2_ASAP7_75t_R  g133(.A(p25), .B(p19), .Y(new_n192_));
  AND2x2_ASAP7_75t_R  g134(.A(p7), .B(new_n192_), .Y(new_n193_));
  NOR2x1_ASAP7_75t_R  g135(.A(p7), .B(new_n192_), .Y(new_n194_));
  AO21x1_ASAP7_75t_R  g136(.A1(p6), .A2(new_n181_), .B(new_n188_), .Y(new_n195_));
  OAI21x1_ASAP7_75t_R g137(.A1(new_n182_), .A2(new_n184_), .B(new_n188_), .Y(new_n196_));
  OAI21x1_ASAP7_75t_R g138(.A1(new_n182_), .A2(new_n195_), .B(new_n196_), .Y(new_n197_));
  OAI21x1_ASAP7_75t_R g139(.A1(new_n193_), .A2(new_n194_), .B(new_n197_), .Y(new_n198_));
  XNOR2x2_ASAP7_75t_R g140(.A(p5), .B(p22), .Y(new_n199_));
  NAND3x1_ASAP7_75t_R g141(.A(new_n191_), .B(new_n198_), .C(new_n199_), .Y(new_n200_));
  NOR2x1_ASAP7_75t_R  g142(.A(new_n197_), .B(new_n82_), .Y(new_n201_));
  NOR2x1_ASAP7_75t_R  g143(.A(new_n103_), .B(new_n190_), .Y(new_n202_));
  INVx1_ASAP7_75t_R   g144(.A(new_n199_), .Y(new_n203_));
  OAI21x1_ASAP7_75t_R g145(.A1(new_n201_), .A2(new_n202_), .B(new_n203_), .Y(new_n204_));
  NAND2x1_ASAP7_75t_R g146(.A(p30), .B(new_n68_), .Y(new_n205_));
  XOR2x2_ASAP7_75t_R  g147(.A(new_n205_), .B(p13), .Y(new_n206_));
  XOR2x2_ASAP7_75t_R  g148(.A(new_n89_), .B(new_n206_), .Y(new_n207_));
  AOI21x1_ASAP7_75t_R g149(.A1(new_n200_), .A2(new_n204_), .B(new_n207_), .Y(new_n208_));
  NAND3x1_ASAP7_75t_R g150(.A(new_n191_), .B(new_n198_), .C(new_n203_), .Y(new_n209_));
  OAI21x1_ASAP7_75t_R g151(.A1(new_n201_), .A2(new_n202_), .B(new_n199_), .Y(new_n210_));
  XNOR2x2_ASAP7_75t_R g152(.A(new_n206_), .B(new_n89_), .Y(new_n211_));
  AOI21x1_ASAP7_75t_R g153(.A1(new_n209_), .A2(new_n210_), .B(new_n211_), .Y(new_n212_));
  OAI21x1_ASAP7_75t_R g154(.A1(new_n208_), .A2(new_n212_), .B(new_n97_), .Y(new_n213_));
  NAND2x1_ASAP7_75t_R g155(.A(new_n180_), .B(new_n213_), .Y(new_n214_));
  OA21x2_ASAP7_75t_R  g156(.A1(p0), .A2(p2), .B(p16), .Y(new_n215_));
  OA21x2_ASAP7_75t_R  g157(.A1(new_n174_), .A2(new_n178_), .B(new_n97_), .Y(new_n216_));
  OAI21x1_ASAP7_75t_R g158(.A1(new_n208_), .A2(new_n212_), .B(new_n216_), .Y(new_n217_));
  AND3x1_ASAP7_75t_R  g159(.A(new_n214_), .B(new_n215_), .C(new_n217_), .Y(new_n218_));
  NAND3x1_ASAP7_75t_R g160(.A(new_n129_), .B(p26), .C(new_n75_), .Y(new_n219_));
  AO21x1_ASAP7_75t_R  g161(.A1(p26), .A2(new_n129_), .B(new_n75_), .Y(new_n220_));
  AND2x2_ASAP7_75t_R  g162(.A(new_n219_), .B(new_n220_), .Y(new_n221_));
  XOR2x2_ASAP7_75t_R  g163(.A(new_n190_), .B(new_n221_), .Y(new_n222_));
  NAND3x1_ASAP7_75t_R g164(.A(new_n222_), .B(new_n95_), .C(new_n97_), .Y(new_n223_));
  XOR2x2_ASAP7_75t_R  g165(.A(new_n197_), .B(new_n221_), .Y(new_n224_));
  NAND3x1_ASAP7_75t_R g166(.A(new_n224_), .B(new_n98_), .C(new_n97_), .Y(new_n225_));
  INVx1_ASAP7_75t_R   g167(.A(p27), .Y(new_n226_));
  NAND3x1_ASAP7_75t_R g168(.A(new_n223_), .B(new_n225_), .C(new_n226_), .Y(new_n227_));
  NAND2x1_ASAP7_75t_R g169(.A(new_n98_), .B(new_n224_), .Y(new_n228_));
  NAND2x1_ASAP7_75t_R g170(.A(new_n95_), .B(new_n222_), .Y(new_n229_));
  NAND2x1_ASAP7_75t_R g171(.A(p27), .B(new_n97_), .Y(new_n230_));
  AO21x1_ASAP7_75t_R  g172(.A1(new_n228_), .A2(new_n229_), .B(new_n230_), .Y(new_n231_));
  NOR3x1_ASAP7_75t_R  g173(.A(new_n127_), .B(p22), .C(new_n124_), .Y(new_n232_));
  INVx1_ASAP7_75t_R   g174(.A(p22), .Y(new_n233_));
  AOI21x1_ASAP7_75t_R g175(.A1(new_n136_), .A2(new_n137_), .B(new_n233_), .Y(new_n234_));
  NOR2x1_ASAP7_75t_R  g176(.A(p24), .B(new_n59_), .Y(new_n235_));
  INVx1_ASAP7_75t_R   g177(.A(p24), .Y(new_n236_));
  AOI21x1_ASAP7_75t_R g178(.A1(p23), .A2(new_n155_), .B(new_n236_), .Y(new_n237_));
  AOI21x1_ASAP7_75t_R g179(.A1(new_n155_), .A2(new_n235_), .B(new_n237_), .Y(new_n238_));
  OAI21x1_ASAP7_75t_R g180(.A1(new_n232_), .A2(new_n234_), .B(new_n238_), .Y(new_n239_));
  NAND3x1_ASAP7_75t_R g181(.A(new_n137_), .B(new_n136_), .C(new_n233_), .Y(new_n240_));
  OAI21x1_ASAP7_75t_R g182(.A1(new_n124_), .A2(new_n127_), .B(p22), .Y(new_n241_));
  AO21x1_ASAP7_75t_R  g183(.A1(new_n155_), .A2(new_n235_), .B(new_n237_), .Y(new_n242_));
  NAND3x1_ASAP7_75t_R g184(.A(new_n240_), .B(new_n241_), .C(new_n242_), .Y(new_n243_));
  XNOR2x2_ASAP7_75t_R g185(.A(p21), .B(p9), .Y(new_n244_));
  NAND3x1_ASAP7_75t_R g186(.A(new_n239_), .B(new_n243_), .C(new_n244_), .Y(new_n245_));
  OA21x2_ASAP7_75t_R  g187(.A1(p32), .A2(p2), .B(p11), .Y(new_n246_));
  XOR2x2_ASAP7_75t_R  g188(.A(p24), .B(p22), .Y(new_n247_));
  AOI21x1_ASAP7_75t_R g189(.A1(p23), .A2(new_n155_), .B(new_n247_), .Y(new_n248_));
  AND3x1_ASAP7_75t_R  g190(.A(new_n247_), .B(p23), .C(new_n155_), .Y(new_n249_));
  OAI21x1_ASAP7_75t_R g191(.A1(new_n248_), .A2(new_n249_), .B(new_n138_), .Y(new_n250_));
  NAND2x1_ASAP7_75t_R g192(.A(p23), .B(new_n155_), .Y(new_n251_));
  NOR2x1_ASAP7_75t_R  g193(.A(new_n251_), .B(new_n247_), .Y(new_n252_));
  AND2x2_ASAP7_75t_R  g194(.A(new_n251_), .B(new_n247_), .Y(new_n253_));
  OAI21x1_ASAP7_75t_R g195(.A1(new_n252_), .A2(new_n253_), .B(new_n128_), .Y(new_n254_));
  INVx1_ASAP7_75t_R   g196(.A(new_n244_), .Y(new_n255_));
  NAND3x1_ASAP7_75t_R g197(.A(new_n250_), .B(new_n254_), .C(new_n255_), .Y(new_n256_));
  NAND3x1_ASAP7_75t_R g198(.A(new_n245_), .B(new_n246_), .C(new_n256_), .Y(new_n257_));
  AO21x1_ASAP7_75t_R  g199(.A1(new_n254_), .A2(new_n250_), .B(new_n244_), .Y(new_n258_));
  NAND3x1_ASAP7_75t_R g200(.A(new_n250_), .B(new_n254_), .C(new_n244_), .Y(new_n259_));
  NOR2x1_ASAP7_75t_R  g201(.A(p2), .B(new_n246_), .Y(new_n260_));
  NAND3x1_ASAP7_75t_R g202(.A(new_n258_), .B(new_n259_), .C(new_n260_), .Y(new_n261_));
  AND2x2_ASAP7_75t_R  g203(.A(p2), .B(new_n246_), .Y(new_n262_));
  INVx1_ASAP7_75t_R   g204(.A(new_n262_), .Y(new_n263_));
  NAND3x1_ASAP7_75t_R g205(.A(new_n257_), .B(new_n261_), .C(new_n263_), .Y(new_n264_));
  AOI21x1_ASAP7_75t_R g206(.A1(new_n227_), .A2(new_n231_), .B(new_n264_), .Y(new_n265_));
  NAND3x1_ASAP7_75t_R g207(.A(new_n177_), .B(new_n218_), .C(new_n265_), .Y(new_n266_));
  AO21x1_ASAP7_75t_R  g208(.A1(new_n96_), .A2(new_n107_), .B(new_n112_), .Y(new_n267_));
  NAND2x1_ASAP7_75t_R g209(.A(new_n61_), .B(new_n267_), .Y(new_n268_));
  AND3x1_ASAP7_75t_R  g210(.A(new_n218_), .B(new_n265_), .C(new_n268_), .Y(new_n269_));
  INVx1_ASAP7_75t_R   g211(.A(p14), .Y(new_n270_));
  NOR2x1_ASAP7_75t_R  g212(.A(new_n176_), .B(new_n171_), .Y(new_n271_));
  AND3x1_ASAP7_75t_R  g213(.A(new_n269_), .B(new_n270_), .C(new_n271_), .Y(new_n272_));
  AOI21x1_ASAP7_75t_R g214(.A1(p14), .A2(new_n266_), .B(new_n272_), .Y(o0));
  OR3x1_ASAP7_75t_R   g215(.A(p1), .B(p31), .C(p2), .Y(new_n274_));
  AO21x1_ASAP7_75t_R  g216(.A1(new_n274_), .A2(new_n173_), .B(new_n175_), .Y(new_n275_));
  INVx1_ASAP7_75t_R   g217(.A(new_n275_), .Y(new_n276_));
  AND3x1_ASAP7_75t_R  g218(.A(new_n167_), .B(new_n169_), .C(new_n276_), .Y(new_n277_));
  NAND3x1_ASAP7_75t_R g219(.A(new_n277_), .B(new_n143_), .C(new_n146_), .Y(new_n278_));
  NOR2x1_ASAP7_75t_R  g220(.A(new_n278_), .B(new_n114_), .Y(new_n279_));
  INVx1_ASAP7_75t_R   g221(.A(new_n215_), .Y(new_n280_));
  AO21x1_ASAP7_75t_R  g222(.A1(new_n217_), .A2(new_n214_), .B(new_n280_), .Y(new_n281_));
  NAND3x1_ASAP7_75t_R g223(.A(new_n279_), .B(new_n265_), .C(new_n281_), .Y(new_n282_));
  XOR2x2_ASAP7_75t_R  g224(.A(new_n282_), .B(p25), .Y(o1));
  XOR2x2_ASAP7_75t_R  g225(.A(new_n282_), .B(p19), .Y(o2));
  AND3x1_ASAP7_75t_R  g226(.A(new_n269_), .B(new_n236_), .C(new_n271_), .Y(new_n285_));
  AOI21x1_ASAP7_75t_R g227(.A1(p24), .A2(new_n266_), .B(new_n285_), .Y(o3));
  XOR2x2_ASAP7_75t_R  g228(.A(new_n282_), .B(p7), .Y(o4));
  XOR2x2_ASAP7_75t_R  g229(.A(new_n282_), .B(p22), .Y(o5));
  NAND3x1_ASAP7_75t_R g230(.A(new_n177_), .B(new_n265_), .C(new_n281_), .Y(new_n289_));
  XOR2x2_ASAP7_75t_R  g231(.A(new_n289_), .B(p9), .Y(o6));
  XOR2x2_ASAP7_75t_R  g232(.A(new_n289_), .B(p8), .Y(o7));
  XOR2x2_ASAP7_75t_R  g233(.A(new_n289_), .B(p15), .Y(o8));
  AND3x1_ASAP7_75t_R  g234(.A(new_n277_), .B(new_n143_), .C(new_n146_), .Y(new_n293_));
  AND3x1_ASAP7_75t_R  g235(.A(new_n293_), .B(new_n61_), .C(new_n113_), .Y(new_n294_));
  NAND3x1_ASAP7_75t_R g236(.A(new_n294_), .B(new_n265_), .C(new_n281_), .Y(new_n295_));
  NOR2x1_ASAP7_75t_R  g237(.A(new_n62_), .B(new_n267_), .Y(new_n296_));
  AND3x1_ASAP7_75t_R  g238(.A(new_n281_), .B(new_n265_), .C(new_n296_), .Y(new_n297_));
  AND3x1_ASAP7_75t_R  g239(.A(new_n297_), .B(new_n188_), .C(new_n293_), .Y(new_n298_));
  AOI21x1_ASAP7_75t_R g240(.A1(p18), .A2(new_n295_), .B(new_n298_), .Y(o9));
  AND3x1_ASAP7_75t_R  g241(.A(new_n297_), .B(new_n183_), .C(new_n293_), .Y(new_n300_));
  AOI21x1_ASAP7_75t_R g242(.A1(p6), .A2(new_n295_), .B(new_n300_), .Y(o10));
  AND3x1_ASAP7_75t_R  g243(.A(new_n297_), .B(new_n181_), .C(new_n293_), .Y(new_n302_));
  AOI21x1_ASAP7_75t_R g244(.A1(p21), .A2(new_n295_), .B(new_n302_), .Y(o11));
  INVx1_ASAP7_75t_R   g245(.A(p5), .Y(new_n304_));
  AND3x1_ASAP7_75t_R  g246(.A(new_n297_), .B(new_n304_), .C(new_n293_), .Y(new_n305_));
  AOI21x1_ASAP7_75t_R g247(.A1(p5), .A2(new_n295_), .B(new_n305_), .Y(o12));
  INVx1_ASAP7_75t_R   g248(.A(p13), .Y(new_n307_));
  AOI21x1_ASAP7_75t_R g249(.A1(new_n271_), .A2(new_n297_), .B(new_n307_), .Y(new_n308_));
  AND3x1_ASAP7_75t_R  g250(.A(new_n297_), .B(new_n307_), .C(new_n271_), .Y(new_n309_));
  NOR2x1_ASAP7_75t_R  g251(.A(new_n308_), .B(new_n309_), .Y(o13));
  INVx1_ASAP7_75t_R   g252(.A(p17), .Y(new_n311_));
  AND3x1_ASAP7_75t_R  g253(.A(new_n269_), .B(new_n311_), .C(new_n271_), .Y(new_n312_));
  AOI21x1_ASAP7_75t_R g254(.A1(p17), .A2(new_n266_), .B(new_n312_), .Y(o14));
  INVx1_ASAP7_75t_R   g255(.A(p10), .Y(new_n314_));
  AND3x1_ASAP7_75t_R  g256(.A(new_n269_), .B(new_n314_), .C(new_n271_), .Y(new_n315_));
  AOI21x1_ASAP7_75t_R g257(.A1(p10), .A2(new_n266_), .B(new_n315_), .Y(o15));
  INVx1_ASAP7_75t_R   g258(.A(new_n176_), .Y(new_n317_));
  OAI21x1_ASAP7_75t_R g259(.A1(new_n317_), .A2(new_n276_), .B(new_n146_), .Y(new_n318_));
  AOI21x1_ASAP7_75t_R g260(.A1(new_n97_), .A2(new_n141_), .B(new_n142_), .Y(new_n319_));
  NAND2x1_ASAP7_75t_R g261(.A(new_n169_), .B(new_n167_), .Y(new_n320_));
  OR3x1_ASAP7_75t_R   g262(.A(new_n318_), .B(new_n319_), .C(new_n320_), .Y(new_n321_));
  NOR2x1_ASAP7_75t_R  g263(.A(new_n321_), .B(new_n114_), .Y(new_n322_));
  AND3x1_ASAP7_75t_R  g264(.A(new_n322_), .B(new_n265_), .C(new_n281_), .Y(new_n323_));
  OR3x1_ASAP7_75t_R   g265(.A(new_n267_), .B(new_n215_), .C(new_n61_), .Y(new_n324_));
  NAND2x1_ASAP7_75t_R g266(.A(new_n217_), .B(new_n214_), .Y(new_n325_));
  AO21x1_ASAP7_75t_R  g267(.A1(new_n231_), .A2(new_n227_), .B(new_n264_), .Y(new_n326_));
  OR3x1_ASAP7_75t_R   g268(.A(new_n325_), .B(new_n171_), .C(new_n326_), .Y(new_n327_));
  OAI21x1_ASAP7_75t_R g269(.A1(new_n324_), .A2(new_n327_), .B(new_n68_), .Y(new_n328_));
  AO21x1_ASAP7_75t_R  g270(.A1(p4), .A2(new_n323_), .B(new_n328_), .Y(o16));
  NOR2x1_ASAP7_75t_R  g271(.A(new_n208_), .B(new_n212_), .Y(new_n330_));
  AND3x1_ASAP7_75t_R  g272(.A(new_n97_), .B(p0), .C(p26), .Y(new_n331_));
  NAND2x1_ASAP7_75t_R g273(.A(new_n331_), .B(new_n323_), .Y(new_n332_));
  OR3x1_ASAP7_75t_R   g274(.A(new_n330_), .B(p2), .C(new_n216_), .Y(new_n333_));
  NAND3x1_ASAP7_75t_R g275(.A(new_n322_), .B(new_n265_), .C(new_n281_), .Y(new_n334_));
  OAI21x1_ASAP7_75t_R g276(.A1(new_n333_), .A2(new_n334_), .B(new_n173_), .Y(new_n335_));
  AOI21x1_ASAP7_75t_R g277(.A1(new_n330_), .A2(new_n332_), .B(new_n335_), .Y(o17));
  NOR2x1_ASAP7_75t_R  g278(.A(p2), .B(new_n106_), .Y(new_n337_));
  NAND2x1_ASAP7_75t_R g279(.A(new_n108_), .B(new_n109_), .Y(new_n338_));
  NAND2x1_ASAP7_75t_R g280(.A(new_n337_), .B(new_n338_), .Y(new_n339_));
  OAI21x1_ASAP7_75t_R g281(.A1(new_n339_), .A2(new_n334_), .B(new_n173_), .Y(new_n340_));
  AOI21x1_ASAP7_75t_R g282(.A1(new_n337_), .A2(new_n323_), .B(new_n338_), .Y(new_n341_));
  NOR2x1_ASAP7_75t_R  g283(.A(new_n340_), .B(new_n341_), .Y(o18));
  NAND2x1_ASAP7_75t_R g284(.A(p20), .B(new_n323_), .Y(new_n343_));
  INVx1_ASAP7_75t_R   g285(.A(new_n173_), .Y(new_n344_));
  AOI21x1_ASAP7_75t_R g286(.A1(new_n141_), .A2(new_n343_), .B(new_n344_), .Y(o19));
  AND3x1_ASAP7_75t_R  g287(.A(new_n165_), .B(new_n160_), .C(new_n158_), .Y(new_n346_));
  NAND2x1_ASAP7_75t_R g288(.A(p12), .B(new_n323_), .Y(new_n347_));
  AOI21x1_ASAP7_75t_R g289(.A1(new_n346_), .A2(new_n347_), .B(new_n344_), .Y(o20));
  NAND2x1_ASAP7_75t_R g290(.A(new_n256_), .B(new_n245_), .Y(new_n349_));
  NAND2x1_ASAP7_75t_R g291(.A(new_n246_), .B(new_n323_), .Y(new_n350_));
  AOI21x1_ASAP7_75t_R g292(.A1(new_n349_), .A2(new_n350_), .B(new_n344_), .Y(o21));
  OAI21x1_ASAP7_75t_R g293(.A1(new_n62_), .A2(new_n113_), .B(new_n265_), .Y(new_n352_));
  AOI21x1_ASAP7_75t_R g294(.A1(new_n215_), .A2(new_n325_), .B(new_n352_), .Y(new_n353_));
  NOR2x1_ASAP7_75t_R  g295(.A(p1), .B(p31), .Y(new_n354_));
  AO21x1_ASAP7_75t_R  g296(.A1(new_n209_), .A2(new_n210_), .B(new_n354_), .Y(new_n355_));
  AOI21x1_ASAP7_75t_R g297(.A1(new_n293_), .A2(new_n353_), .B(new_n355_), .Y(new_n356_));
  NAND2x1_ASAP7_75t_R g298(.A(new_n68_), .B(new_n355_), .Y(new_n357_));
  AO21x1_ASAP7_75t_R  g299(.A1(p30), .A2(p31), .B(p1), .Y(new_n358_));
  INVx1_ASAP7_75t_R   g300(.A(new_n358_), .Y(new_n359_));
  OAI21x1_ASAP7_75t_R g301(.A1(new_n357_), .A2(new_n282_), .B(new_n359_), .Y(new_n360_));
  NAND2x1_ASAP7_75t_R g302(.A(new_n355_), .B(new_n293_), .Y(new_n361_));
  AOI21x1_ASAP7_75t_R g303(.A1(new_n217_), .A2(new_n214_), .B(new_n280_), .Y(new_n362_));
  NOR3x1_ASAP7_75t_R  g304(.A(new_n361_), .B(new_n362_), .C(new_n352_), .Y(new_n363_));
  OAI21x1_ASAP7_75t_R g305(.A1(new_n363_), .A2(new_n356_), .B(new_n358_), .Y(new_n364_));
  OAI21x1_ASAP7_75t_R g306(.A1(new_n356_), .A2(new_n360_), .B(new_n364_), .Y(o22));
  NOR2x1_ASAP7_75t_R  g307(.A(new_n135_), .B(new_n123_), .Y(new_n366_));
  XOR2x2_ASAP7_75t_R  g308(.A(new_n98_), .B(new_n366_), .Y(new_n367_));
  NOR2x1_ASAP7_75t_R  g309(.A(p1), .B(p28), .Y(new_n368_));
  XOR2x2_ASAP7_75t_R  g310(.A(new_n367_), .B(new_n368_), .Y(new_n369_));
  OA21x2_ASAP7_75t_R  g311(.A1(p1), .A2(p3), .B(new_n369_), .Y(new_n370_));
  XOR2x2_ASAP7_75t_R  g312(.A(new_n289_), .B(new_n370_), .Y(o23));
  NAND2x1_ASAP7_75t_R g313(.A(new_n228_), .B(new_n229_), .Y(new_n372_));
  OAI21x1_ASAP7_75t_R g314(.A1(new_n230_), .A2(new_n334_), .B(new_n372_), .Y(new_n373_));
  NOR2x1_ASAP7_75t_R  g315(.A(new_n344_), .B(new_n373_), .Y(o24));
endmodule


