// Benchmark "/tmp/" written by ABC on Mon Oct 12 15:05:21 2026

module \/tmp/  ( 
    p27, p24, p14, p25, p18, p4, p29, p13, p11, p19, p20, p2, p26, p28, p5,
    p6, p17, p1, p10, p7, p3, p16, p15, p21, p32, p23, p30, p8, p0, p22,
    p12, p31, p9,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24  );
  input  p27, p24, p14, p25, p18, p4, p29, p13, p11, p19, p20, p2, p26,
    p28, p5, p6, p17, p1, p10, p7, p3, p16, p15, p21, p32, p23, p30, p8,
    p0, p22, p12, p31, p9;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24;
  wire new_n59_, new_n60_, new_n61_, new_n62_, new_n63_, new_n64_, new_n65_,
    new_n66_, new_n67_, new_n68_, new_n69_, new_n70_, new_n71_, new_n72_,
    new_n73_, new_n74_, new_n75_, new_n76_, new_n77_, new_n78_, new_n79_,
    new_n80_, new_n81_, new_n82_, new_n83_, new_n84_, new_n85_, new_n86_,
    new_n87_, new_n88_, new_n89_, new_n90_, new_n91_, new_n92_, new_n93_,
    new_n94_, new_n95_, new_n96_, new_n97_, new_n98_, new_n99_, new_n100_,
    new_n101_, new_n102_, new_n103_, new_n104_, new_n105_, new_n106_,
    new_n107_, new_n108_, new_n109_, new_n110_, new_n111_, new_n112_,
    new_n113_, new_n114_, new_n115_, new_n116_, new_n117_, new_n118_,
    new_n119_, new_n120_, new_n121_, new_n122_, new_n123_, new_n124_,
    new_n125_, new_n126_, new_n127_, new_n128_, new_n129_, new_n130_,
    new_n131_, new_n132_, new_n133_, new_n134_, new_n135_, new_n136_,
    new_n137_, new_n138_, new_n139_, new_n140_, new_n141_, new_n142_,
    new_n143_, new_n144_, new_n145_, new_n146_, new_n147_, new_n148_,
    new_n149_, new_n150_, new_n151_, new_n152_, new_n153_, new_n154_,
    new_n155_, new_n156_, new_n157_, new_n158_, new_n159_, new_n160_,
    new_n161_, new_n162_, new_n163_, new_n164_, new_n165_, new_n166_,
    new_n167_, new_n168_, new_n169_, new_n170_, new_n171_, new_n172_,
    new_n173_, new_n174_, new_n175_, new_n176_, new_n177_, new_n178_,
    new_n179_, new_n180_, new_n181_, new_n182_, new_n183_, new_n184_,
    new_n185_, new_n186_, new_n187_, new_n188_, new_n189_, new_n190_,
    new_n191_, new_n192_, new_n193_, new_n194_, new_n195_, new_n196_,
    new_n197_, new_n198_, new_n199_, new_n200_, new_n201_, new_n202_,
    new_n203_, new_n204_, new_n205_, new_n206_, new_n207_, new_n208_,
    new_n209_, new_n210_, new_n211_, new_n212_, new_n213_, new_n214_,
    new_n215_, new_n216_, new_n217_, new_n218_, new_n219_, new_n220_,
    new_n221_, new_n222_, new_n223_, new_n224_, new_n225_, new_n226_,
    new_n227_, new_n228_, new_n229_, new_n230_, new_n231_, new_n232_,
    new_n233_, new_n234_, new_n235_, new_n236_, new_n237_, new_n238_,
    new_n239_, new_n240_, new_n241_, new_n242_, new_n243_, new_n244_,
    new_n245_, new_n246_, new_n248_, new_n249_, new_n250_, new_n251_,
    new_n252_, new_n253_, new_n254_, new_n255_, new_n256_, new_n257_,
    new_n258_, new_n264_, new_n265_, new_n266_, new_n267_, new_n268_,
    new_n269_, new_n270_, new_n271_, new_n272_, new_n273_, new_n274_,
    new_n275_, new_n276_, new_n277_, new_n281_, new_n282_, new_n283_,
    new_n284_, new_n289_, new_n290_, new_n291_, new_n292_, new_n296_,
    new_n297_, new_n298_, new_n299_, new_n300_, new_n301_, new_n302_,
    new_n303_, new_n304_, new_n305_, new_n307_, new_n308_, new_n309_,
    new_n310_, new_n311_, new_n312_, new_n314_, new_n315_, new_n316_,
    new_n317_, new_n318_, new_n320_, new_n321_, new_n323_, new_n325_,
    new_n326_, new_n328_, new_n329_, new_n330_, new_n331_, new_n332_,
    new_n333_, new_n334_, new_n335_, new_n336_, new_n337_, new_n339_,
    new_n340_, new_n341_, new_n342_, new_n343_, new_n345_;
  XOR2x2_ASAP7_75t_R  g000(.A(p19), .B(p7), .Y(new_n59_));
  XOR2x2_ASAP7_75t_R  g001(.A(new_n59_), .B(p25), .Y(new_n60_));
  XOR2x2_ASAP7_75t_R  g002(.A(p6), .B(p21), .Y(new_n61_));
  NAND2x1_ASAP7_75t_R g003(.A(p18), .B(new_n61_), .Y(new_n62_));
  INVx1_ASAP7_75t_R   g004(.A(p18), .Y(new_n63_));
  XNOR2x2_ASAP7_75t_R g005(.A(p6), .B(p21), .Y(new_n64_));
  NAND2x1_ASAP7_75t_R g006(.A(new_n63_), .B(new_n64_), .Y(new_n65_));
  NAND2x1_ASAP7_75t_R g007(.A(new_n62_), .B(new_n65_), .Y(new_n66_));
  NOR2x1_ASAP7_75t_R  g008(.A(new_n60_), .B(new_n66_), .Y(new_n67_));
  INVx1_ASAP7_75t_R   g009(.A(p25), .Y(new_n68_));
  XOR2x2_ASAP7_75t_R  g010(.A(new_n59_), .B(new_n68_), .Y(new_n69_));
  NAND2x1_ASAP7_75t_R g011(.A(new_n63_), .B(new_n61_), .Y(new_n70_));
  NAND2x1_ASAP7_75t_R g012(.A(p18), .B(new_n64_), .Y(new_n71_));
  NAND2x1_ASAP7_75t_R g013(.A(new_n70_), .B(new_n71_), .Y(new_n72_));
  NOR2x1_ASAP7_75t_R  g014(.A(new_n69_), .B(new_n72_), .Y(new_n73_));
  XNOR2x2_ASAP7_75t_R g015(.A(p5), .B(p22), .Y(new_n74_));
  INVx1_ASAP7_75t_R   g016(.A(new_n74_), .Y(new_n75_));
  OAI21x1_ASAP7_75t_R g017(.A1(new_n67_), .A2(new_n73_), .B(new_n75_), .Y(new_n76_));
  NAND2x1_ASAP7_75t_R g018(.A(new_n69_), .B(new_n72_), .Y(new_n77_));
  NAND2x1_ASAP7_75t_R g019(.A(new_n60_), .B(new_n66_), .Y(new_n78_));
  NAND3x1_ASAP7_75t_R g020(.A(new_n77_), .B(new_n78_), .C(new_n74_), .Y(new_n79_));
  XOR2x2_ASAP7_75t_R  g021(.A(p8), .B(p9), .Y(new_n80_));
  INVx1_ASAP7_75t_R   g022(.A(p15), .Y(new_n81_));
  XOR2x2_ASAP7_75t_R  g023(.A(new_n80_), .B(new_n81_), .Y(new_n82_));
  INVx1_ASAP7_75t_R   g024(.A(p1), .Y(new_n83_));
  NAND2x1_ASAP7_75t_R g025(.A(p30), .B(new_n83_), .Y(new_n84_));
  XNOR2x2_ASAP7_75t_R g026(.A(p13), .B(new_n84_), .Y(new_n85_));
  XOR2x2_ASAP7_75t_R  g027(.A(new_n82_), .B(new_n85_), .Y(new_n86_));
  AO21x1_ASAP7_75t_R  g028(.A1(new_n76_), .A2(new_n79_), .B(new_n86_), .Y(new_n87_));
  OAI21x1_ASAP7_75t_R g029(.A1(new_n67_), .A2(new_n73_), .B(new_n74_), .Y(new_n88_));
  NAND3x1_ASAP7_75t_R g030(.A(new_n77_), .B(new_n78_), .C(new_n75_), .Y(new_n89_));
  NAND2x1_ASAP7_75t_R g031(.A(new_n88_), .B(new_n89_), .Y(new_n90_));
  AOI21x1_ASAP7_75t_R g032(.A1(new_n86_), .A2(new_n90_), .B(p2), .Y(new_n91_));
  INVx1_ASAP7_75t_R   g033(.A(p2), .Y(new_n92_));
  INVx1_ASAP7_75t_R   g034(.A(p0), .Y(new_n93_));
  INVx1_ASAP7_75t_R   g035(.A(p26), .Y(new_n94_));
  AO21x1_ASAP7_75t_R  g036(.A1(new_n92_), .A2(new_n93_), .B(new_n94_), .Y(new_n95_));
  AOI21x1_ASAP7_75t_R g037(.A1(new_n87_), .A2(new_n91_), .B(new_n95_), .Y(new_n96_));
  NOR2x1_ASAP7_75t_R  g038(.A(p1), .B(p0), .Y(new_n97_));
  AOI21x1_ASAP7_75t_R g039(.A1(p26), .A2(new_n97_), .B(new_n68_), .Y(new_n98_));
  AND3x1_ASAP7_75t_R  g040(.A(new_n97_), .B(new_n68_), .C(p26), .Y(new_n99_));
  NOR2x1_ASAP7_75t_R  g041(.A(new_n98_), .B(new_n99_), .Y(new_n100_));
  AOI21x1_ASAP7_75t_R g042(.A1(new_n70_), .A2(new_n71_), .B(new_n100_), .Y(new_n101_));
  NAND3x1_ASAP7_75t_R g043(.A(new_n97_), .B(new_n68_), .C(p26), .Y(new_n102_));
  AO21x1_ASAP7_75t_R  g044(.A1(p26), .A2(new_n97_), .B(new_n68_), .Y(new_n103_));
  NAND2x1_ASAP7_75t_R g045(.A(new_n102_), .B(new_n103_), .Y(new_n104_));
  AOI21x1_ASAP7_75t_R g046(.A1(new_n62_), .A2(new_n65_), .B(new_n104_), .Y(new_n105_));
  NOR2x1_ASAP7_75t_R  g047(.A(new_n101_), .B(new_n105_), .Y(new_n106_));
  XOR2x2_ASAP7_75t_R  g048(.A(p24), .B(p17), .Y(new_n107_));
  XOR2x2_ASAP7_75t_R  g049(.A(new_n107_), .B(p10), .Y(new_n108_));
  NAND2x1_ASAP7_75t_R g050(.A(new_n82_), .B(new_n108_), .Y(new_n109_));
  XOR2x2_ASAP7_75t_R  g051(.A(new_n80_), .B(p15), .Y(new_n110_));
  XNOR2x2_ASAP7_75t_R g052(.A(p10), .B(new_n107_), .Y(new_n111_));
  NAND2x1_ASAP7_75t_R g053(.A(new_n110_), .B(new_n111_), .Y(new_n112_));
  NAND3x1_ASAP7_75t_R g054(.A(new_n106_), .B(new_n109_), .C(new_n112_), .Y(new_n113_));
  NOR2x1_ASAP7_75t_R  g055(.A(new_n82_), .B(new_n108_), .Y(new_n114_));
  NOR2x1_ASAP7_75t_R  g056(.A(new_n110_), .B(new_n111_), .Y(new_n115_));
  NOR2x1_ASAP7_75t_R  g057(.A(p18), .B(new_n61_), .Y(new_n116_));
  NOR2x1_ASAP7_75t_R  g058(.A(new_n63_), .B(new_n64_), .Y(new_n117_));
  OAI21x1_ASAP7_75t_R g059(.A1(new_n116_), .A2(new_n117_), .B(new_n100_), .Y(new_n118_));
  NOR2x1_ASAP7_75t_R  g060(.A(new_n63_), .B(new_n61_), .Y(new_n119_));
  NOR2x1_ASAP7_75t_R  g061(.A(p18), .B(new_n64_), .Y(new_n120_));
  OAI21x1_ASAP7_75t_R g062(.A1(new_n119_), .A2(new_n120_), .B(new_n104_), .Y(new_n121_));
  NAND2x1_ASAP7_75t_R g063(.A(new_n118_), .B(new_n121_), .Y(new_n122_));
  OAI21x1_ASAP7_75t_R g064(.A1(new_n114_), .A2(new_n115_), .B(new_n122_), .Y(new_n123_));
  INVx1_ASAP7_75t_R   g065(.A(p27), .Y(new_n124_));
  NOR2x1_ASAP7_75t_R  g066(.A(p2), .B(new_n124_), .Y(new_n125_));
  NAND3x1_ASAP7_75t_R g067(.A(new_n113_), .B(new_n123_), .C(new_n125_), .Y(new_n126_));
  NAND3x1_ASAP7_75t_R g068(.A(new_n122_), .B(new_n109_), .C(new_n112_), .Y(new_n127_));
  OAI21x1_ASAP7_75t_R g069(.A1(new_n115_), .A2(new_n114_), .B(new_n106_), .Y(new_n128_));
  NAND3x1_ASAP7_75t_R g070(.A(new_n127_), .B(new_n128_), .C(new_n124_), .Y(new_n129_));
  NAND2x1_ASAP7_75t_R g071(.A(p2), .B(new_n124_), .Y(new_n130_));
  NAND3x1_ASAP7_75t_R g072(.A(new_n126_), .B(new_n129_), .C(new_n130_), .Y(new_n131_));
  OAI21x1_ASAP7_75t_R g073(.A1(p14), .A2(p13), .B(p15), .Y(new_n132_));
  AO21x1_ASAP7_75t_R  g074(.A1(p14), .A2(p13), .B(new_n132_), .Y(new_n133_));
  NOR2x1_ASAP7_75t_R  g075(.A(p14), .B(p13), .Y(new_n134_));
  AND2x2_ASAP7_75t_R  g076(.A(p14), .B(p13), .Y(new_n135_));
  OAI21x1_ASAP7_75t_R g077(.A1(new_n134_), .A2(new_n135_), .B(new_n81_), .Y(new_n136_));
  INVx1_ASAP7_75t_R   g078(.A(p22), .Y(new_n137_));
  NAND3x1_ASAP7_75t_R g079(.A(new_n133_), .B(new_n136_), .C(new_n137_), .Y(new_n138_));
  NOR2x1_ASAP7_75t_R  g080(.A(new_n132_), .B(new_n135_), .Y(new_n139_));
  NAND2x1_ASAP7_75t_R g081(.A(p14), .B(p13), .Y(new_n140_));
  OR3x1_ASAP7_75t_R   g082(.A(p14), .B(p13), .C(p15), .Y(new_n141_));
  OAI21x1_ASAP7_75t_R g083(.A1(p15), .A2(new_n140_), .B(new_n141_), .Y(new_n142_));
  OAI21x1_ASAP7_75t_R g084(.A1(new_n139_), .A2(new_n142_), .B(p22), .Y(new_n143_));
  NOR2x1_ASAP7_75t_R  g085(.A(p1), .B(p32), .Y(new_n144_));
  INVx1_ASAP7_75t_R   g086(.A(p24), .Y(new_n145_));
  AND2x2_ASAP7_75t_R  g087(.A(p23), .B(new_n145_), .Y(new_n146_));
  AOI21x1_ASAP7_75t_R g088(.A1(p23), .A2(new_n144_), .B(new_n145_), .Y(new_n147_));
  AO21x1_ASAP7_75t_R  g089(.A1(new_n144_), .A2(new_n146_), .B(new_n147_), .Y(new_n148_));
  AND3x1_ASAP7_75t_R  g090(.A(new_n138_), .B(new_n143_), .C(new_n148_), .Y(new_n149_));
  XNOR2x2_ASAP7_75t_R g091(.A(p21), .B(p9), .Y(new_n150_));
  INVx1_ASAP7_75t_R   g092(.A(new_n150_), .Y(new_n151_));
  AOI21x1_ASAP7_75t_R g093(.A1(new_n143_), .A2(new_n138_), .B(new_n148_), .Y(new_n152_));
  NOR3x1_ASAP7_75t_R  g094(.A(new_n149_), .B(new_n151_), .C(new_n152_), .Y(new_n153_));
  OA21x2_ASAP7_75t_R  g095(.A1(p2), .A2(p32), .B(p11), .Y(new_n154_));
  INVx1_ASAP7_75t_R   g096(.A(new_n154_), .Y(new_n155_));
  XNOR2x2_ASAP7_75t_R g097(.A(p24), .B(p22), .Y(new_n156_));
  AO21x1_ASAP7_75t_R  g098(.A1(p23), .A2(new_n144_), .B(new_n156_), .Y(new_n157_));
  NOR2x1_ASAP7_75t_R  g099(.A(new_n139_), .B(new_n142_), .Y(new_n158_));
  NAND3x1_ASAP7_75t_R g100(.A(new_n156_), .B(p23), .C(new_n144_), .Y(new_n159_));
  NAND3x1_ASAP7_75t_R g101(.A(new_n157_), .B(new_n158_), .C(new_n159_), .Y(new_n160_));
  AO21x1_ASAP7_75t_R  g102(.A1(new_n159_), .A2(new_n157_), .B(new_n158_), .Y(new_n161_));
  AOI21x1_ASAP7_75t_R g103(.A1(new_n160_), .A2(new_n161_), .B(new_n150_), .Y(new_n162_));
  NOR3x1_ASAP7_75t_R  g104(.A(new_n153_), .B(new_n155_), .C(new_n162_), .Y(new_n163_));
  AND3x1_ASAP7_75t_R  g105(.A(new_n157_), .B(new_n158_), .C(new_n159_), .Y(new_n164_));
  AOI21x1_ASAP7_75t_R g106(.A1(new_n159_), .A2(new_n157_), .B(new_n158_), .Y(new_n165_));
  NOR3x1_ASAP7_75t_R  g107(.A(new_n164_), .B(new_n150_), .C(new_n165_), .Y(new_n166_));
  AOI21x1_ASAP7_75t_R g108(.A1(new_n160_), .A2(new_n161_), .B(new_n151_), .Y(new_n167_));
  NOR2x1_ASAP7_75t_R  g109(.A(p2), .B(new_n154_), .Y(new_n168_));
  INVx1_ASAP7_75t_R   g110(.A(new_n168_), .Y(new_n169_));
  NOR3x1_ASAP7_75t_R  g111(.A(new_n166_), .B(new_n167_), .C(new_n169_), .Y(new_n170_));
  AND2x2_ASAP7_75t_R  g112(.A(p11), .B(p2), .Y(new_n171_));
  NOR3x1_ASAP7_75t_R  g113(.A(new_n163_), .B(new_n170_), .C(new_n171_), .Y(new_n172_));
  XOR2x2_ASAP7_75t_R  g114(.A(new_n110_), .B(new_n85_), .Y(new_n173_));
  AOI21x1_ASAP7_75t_R g115(.A1(new_n76_), .A2(new_n79_), .B(new_n173_), .Y(new_n174_));
  AOI21x1_ASAP7_75t_R g116(.A1(new_n88_), .A2(new_n89_), .B(new_n86_), .Y(new_n175_));
  OA21x2_ASAP7_75t_R  g117(.A1(new_n94_), .A2(new_n93_), .B(new_n92_), .Y(new_n176_));
  OAI21x1_ASAP7_75t_R g118(.A1(new_n174_), .A2(new_n175_), .B(new_n176_), .Y(new_n177_));
  NAND3x1_ASAP7_75t_R g119(.A(new_n131_), .B(new_n172_), .C(new_n177_), .Y(new_n178_));
  NOR2x1_ASAP7_75t_R  g120(.A(new_n96_), .B(new_n178_), .Y(new_n179_));
  OA21x2_ASAP7_75t_R  g121(.A1(p2), .A2(p0), .B(p16), .Y(new_n180_));
  INVx1_ASAP7_75t_R   g122(.A(new_n180_), .Y(new_n181_));
  NAND2x1_ASAP7_75t_R g123(.A(new_n109_), .B(new_n112_), .Y(new_n182_));
  XOR2x2_ASAP7_75t_R  g124(.A(p14), .B(p22), .Y(new_n183_));
  NAND2x1_ASAP7_75t_R g125(.A(p28), .B(new_n83_), .Y(new_n184_));
  XOR2x2_ASAP7_75t_R  g126(.A(new_n183_), .B(new_n184_), .Y(new_n185_));
  XOR2x2_ASAP7_75t_R  g127(.A(new_n185_), .B(new_n60_), .Y(new_n186_));
  NAND2x1_ASAP7_75t_R g128(.A(new_n182_), .B(new_n186_), .Y(new_n187_));
  XOR2x2_ASAP7_75t_R  g129(.A(new_n185_), .B(new_n69_), .Y(new_n188_));
  NOR2x1_ASAP7_75t_R  g130(.A(new_n114_), .B(new_n115_), .Y(new_n189_));
  NAND2x1_ASAP7_75t_R g131(.A(new_n188_), .B(new_n189_), .Y(new_n190_));
  INVx1_ASAP7_75t_R   g132(.A(p29), .Y(new_n191_));
  NAND2x1_ASAP7_75t_R g133(.A(new_n191_), .B(new_n92_), .Y(new_n192_));
  AO21x1_ASAP7_75t_R  g134(.A1(new_n187_), .A2(new_n190_), .B(new_n192_), .Y(new_n193_));
  OR3x1_ASAP7_75t_R   g135(.A(new_n189_), .B(new_n188_), .C(p2), .Y(new_n194_));
  OR3x1_ASAP7_75t_R   g136(.A(new_n186_), .B(new_n182_), .C(p2), .Y(new_n195_));
  NAND3x1_ASAP7_75t_R g137(.A(new_n194_), .B(new_n195_), .C(p29), .Y(new_n196_));
  OA21x2_ASAP7_75t_R  g138(.A1(p2), .A2(p32), .B(p23), .Y(new_n197_));
  INVx1_ASAP7_75t_R   g139(.A(new_n197_), .Y(new_n198_));
  AOI21x1_ASAP7_75t_R g140(.A1(new_n193_), .A2(new_n196_), .B(new_n198_), .Y(new_n199_));
  NOR2x1_ASAP7_75t_R  g141(.A(new_n181_), .B(new_n199_), .Y(new_n200_));
  OR3x1_ASAP7_75t_R   g142(.A(p2), .B(p1), .C(p3), .Y(new_n201_));
  NOR2x1_ASAP7_75t_R  g143(.A(p4), .B(p1), .Y(new_n202_));
  INVx1_ASAP7_75t_R   g144(.A(new_n202_), .Y(new_n203_));
  NOR2x1_ASAP7_75t_R  g145(.A(p32), .B(new_n93_), .Y(new_n204_));
  AOI21x1_ASAP7_75t_R g146(.A1(new_n201_), .A2(new_n203_), .B(new_n204_), .Y(new_n205_));
  AND3x1_ASAP7_75t_R  g147(.A(new_n83_), .B(new_n93_), .C(p16), .Y(new_n206_));
  OR3x1_ASAP7_75t_R   g148(.A(new_n142_), .B(new_n206_), .C(new_n139_), .Y(new_n207_));
  NAND2x1_ASAP7_75t_R g149(.A(new_n136_), .B(new_n133_), .Y(new_n208_));
  NAND2x1_ASAP7_75t_R g150(.A(new_n206_), .B(new_n208_), .Y(new_n209_));
  XNOR2x2_ASAP7_75t_R g151(.A(p18), .B(p5), .Y(new_n210_));
  INVx1_ASAP7_75t_R   g152(.A(p5), .Y(new_n211_));
  AO21x1_ASAP7_75t_R  g153(.A1(p18), .A2(p5), .B(p19), .Y(new_n212_));
  AOI21x1_ASAP7_75t_R g154(.A1(new_n63_), .A2(new_n211_), .B(new_n212_), .Y(new_n213_));
  AO21x1_ASAP7_75t_R  g155(.A1(p19), .A2(new_n210_), .B(new_n213_), .Y(new_n214_));
  AOI21x1_ASAP7_75t_R g156(.A1(new_n207_), .A2(new_n209_), .B(new_n214_), .Y(new_n215_));
  AND3x1_ASAP7_75t_R  g157(.A(new_n209_), .B(new_n214_), .C(new_n207_), .Y(new_n216_));
  XNOR2x2_ASAP7_75t_R g158(.A(p17), .B(p8), .Y(new_n217_));
  INVx1_ASAP7_75t_R   g159(.A(new_n217_), .Y(new_n218_));
  OAI21x1_ASAP7_75t_R g160(.A1(new_n215_), .A2(new_n216_), .B(new_n218_), .Y(new_n219_));
  AND2x2_ASAP7_75t_R  g161(.A(new_n206_), .B(new_n208_), .Y(new_n220_));
  NAND2x1_ASAP7_75t_R g162(.A(new_n214_), .B(new_n207_), .Y(new_n221_));
  OAI21x1_ASAP7_75t_R g163(.A1(new_n220_), .A2(new_n221_), .B(new_n217_), .Y(new_n222_));
  NOR2x1_ASAP7_75t_R  g164(.A(p20), .B(p2), .Y(new_n223_));
  OA21x2_ASAP7_75t_R  g165(.A1(new_n215_), .A2(new_n222_), .B(new_n223_), .Y(new_n224_));
  NAND2x1_ASAP7_75t_R g166(.A(new_n219_), .B(new_n224_), .Y(new_n225_));
  NAND2x1_ASAP7_75t_R g167(.A(new_n205_), .B(new_n225_), .Y(new_n226_));
  OAI21x1_ASAP7_75t_R g168(.A1(new_n215_), .A2(new_n222_), .B(new_n92_), .Y(new_n227_));
  OA21x2_ASAP7_75t_R  g169(.A1(new_n215_), .A2(new_n216_), .B(new_n218_), .Y(new_n228_));
  OAI21x1_ASAP7_75t_R g170(.A1(new_n227_), .A2(new_n228_), .B(p20), .Y(new_n229_));
  XOR2x2_ASAP7_75t_R  g171(.A(p10), .B(p7), .Y(new_n230_));
  XOR2x2_ASAP7_75t_R  g172(.A(p5), .B(p6), .Y(new_n231_));
  XOR2x2_ASAP7_75t_R  g173(.A(new_n230_), .B(new_n231_), .Y(new_n232_));
  NAND2x1_ASAP7_75t_R g174(.A(p11), .B(new_n144_), .Y(new_n233_));
  OR2x4_ASAP7_75t_R   g175(.A(new_n233_), .B(new_n80_), .Y(new_n234_));
  NAND2x1_ASAP7_75t_R g176(.A(new_n233_), .B(new_n80_), .Y(new_n235_));
  NAND3x1_ASAP7_75t_R g177(.A(new_n232_), .B(new_n234_), .C(new_n235_), .Y(new_n236_));
  AO21x1_ASAP7_75t_R  g178(.A1(new_n234_), .A2(new_n235_), .B(new_n232_), .Y(new_n237_));
  INVx1_ASAP7_75t_R   g179(.A(p12), .Y(new_n238_));
  NAND2x1_ASAP7_75t_R g180(.A(new_n92_), .B(new_n238_), .Y(new_n239_));
  AOI21x1_ASAP7_75t_R g181(.A1(new_n236_), .A2(new_n237_), .B(new_n239_), .Y(new_n240_));
  NAND2x1_ASAP7_75t_R g182(.A(new_n236_), .B(new_n237_), .Y(new_n241_));
  AOI21x1_ASAP7_75t_R g183(.A1(new_n92_), .A2(new_n241_), .B(new_n238_), .Y(new_n242_));
  NOR2x1_ASAP7_75t_R  g184(.A(new_n240_), .B(new_n242_), .Y(new_n243_));
  NAND2x1_ASAP7_75t_R g185(.A(new_n229_), .B(new_n243_), .Y(new_n244_));
  NOR2x1_ASAP7_75t_R  g186(.A(new_n226_), .B(new_n244_), .Y(new_n245_));
  NAND3x1_ASAP7_75t_R g187(.A(new_n179_), .B(new_n200_), .C(new_n245_), .Y(new_n246_));
  XOR2x2_ASAP7_75t_R  g188(.A(new_n246_), .B(p14), .Y(o0));
  OR3x1_ASAP7_75t_R   g189(.A(new_n204_), .B(p4), .C(p1), .Y(new_n248_));
  OR2x4_ASAP7_75t_R   g190(.A(p1), .B(p31), .Y(new_n249_));
  OR3x1_ASAP7_75t_R   g191(.A(new_n249_), .B(new_n204_), .C(p2), .Y(new_n250_));
  NAND2x1_ASAP7_75t_R g192(.A(new_n248_), .B(new_n250_), .Y(new_n251_));
  INVx1_ASAP7_75t_R   g193(.A(new_n251_), .Y(new_n252_));
  NOR3x1_ASAP7_75t_R  g194(.A(new_n242_), .B(new_n240_), .C(new_n252_), .Y(new_n253_));
  NAND3x1_ASAP7_75t_R g195(.A(new_n253_), .B(new_n229_), .C(new_n225_), .Y(new_n254_));
  NOR2x1_ASAP7_75t_R  g196(.A(new_n199_), .B(new_n254_), .Y(new_n255_));
  NAND3x1_ASAP7_75t_R g197(.A(new_n131_), .B(new_n172_), .C(new_n181_), .Y(new_n256_));
  OAI21x1_ASAP7_75t_R g198(.A1(new_n96_), .A2(new_n178_), .B(new_n256_), .Y(new_n257_));
  NAND2x1_ASAP7_75t_R g199(.A(new_n255_), .B(new_n257_), .Y(new_n258_));
  XOR2x2_ASAP7_75t_R  g200(.A(new_n258_), .B(p25), .Y(o1));
  XOR2x2_ASAP7_75t_R  g201(.A(new_n258_), .B(p19), .Y(o2));
  XOR2x2_ASAP7_75t_R  g202(.A(new_n246_), .B(p24), .Y(o3));
  XOR2x2_ASAP7_75t_R  g203(.A(new_n258_), .B(p7), .Y(o4));
  XOR2x2_ASAP7_75t_R  g204(.A(new_n258_), .B(p22), .Y(o5));
  OA21x2_ASAP7_75t_R  g205(.A1(p2), .A2(new_n187_), .B(p29), .Y(new_n264_));
  AOI21x1_ASAP7_75t_R g206(.A1(new_n187_), .A2(new_n190_), .B(new_n192_), .Y(new_n265_));
  AOI21x1_ASAP7_75t_R g207(.A1(new_n195_), .A2(new_n264_), .B(new_n265_), .Y(new_n266_));
  OR3x1_ASAP7_75t_R   g208(.A(new_n163_), .B(new_n170_), .C(new_n171_), .Y(new_n267_));
  AND3x1_ASAP7_75t_R  g209(.A(new_n126_), .B(new_n129_), .C(new_n130_), .Y(new_n268_));
  NOR2x1_ASAP7_75t_R  g210(.A(new_n267_), .B(new_n268_), .Y(new_n269_));
  OAI21x1_ASAP7_75t_R g211(.A1(new_n198_), .A2(new_n266_), .B(new_n269_), .Y(new_n270_));
  AND3x1_ASAP7_75t_R  g212(.A(new_n243_), .B(new_n225_), .C(new_n229_), .Y(new_n271_));
  NAND2x1_ASAP7_75t_R g213(.A(new_n205_), .B(new_n271_), .Y(new_n272_));
  INVx1_ASAP7_75t_R   g214(.A(new_n95_), .Y(new_n273_));
  OAI21x1_ASAP7_75t_R g215(.A1(new_n174_), .A2(new_n175_), .B(new_n92_), .Y(new_n274_));
  NAND2x1_ASAP7_75t_R g216(.A(new_n273_), .B(new_n274_), .Y(new_n275_));
  AOI21x1_ASAP7_75t_R g217(.A1(new_n177_), .A2(new_n275_), .B(new_n181_), .Y(new_n276_));
  OR3x1_ASAP7_75t_R   g218(.A(new_n270_), .B(new_n272_), .C(new_n276_), .Y(new_n277_));
  XOR2x2_ASAP7_75t_R  g219(.A(new_n277_), .B(p9), .Y(o6));
  XOR2x2_ASAP7_75t_R  g220(.A(new_n277_), .B(p8), .Y(o7));
  XOR2x2_ASAP7_75t_R  g221(.A(new_n277_), .B(p15), .Y(o8));
  AND3x1_ASAP7_75t_R  g222(.A(new_n196_), .B(new_n197_), .C(new_n193_), .Y(new_n281_));
  AND2x2_ASAP7_75t_R  g223(.A(new_n229_), .B(new_n225_), .Y(new_n282_));
  AND3x1_ASAP7_75t_R  g224(.A(new_n281_), .B(new_n282_), .C(new_n253_), .Y(new_n283_));
  NAND2x1_ASAP7_75t_R g225(.A(new_n257_), .B(new_n283_), .Y(new_n284_));
  XOR2x2_ASAP7_75t_R  g226(.A(new_n284_), .B(p18), .Y(o9));
  XOR2x2_ASAP7_75t_R  g227(.A(new_n284_), .B(p6), .Y(o10));
  XOR2x2_ASAP7_75t_R  g228(.A(new_n284_), .B(p21), .Y(o11));
  XOR2x2_ASAP7_75t_R  g229(.A(new_n284_), .B(p5), .Y(o12));
  INVx1_ASAP7_75t_R   g230(.A(new_n257_), .Y(new_n289_));
  NAND2x1_ASAP7_75t_R g231(.A(new_n281_), .B(new_n245_), .Y(new_n290_));
  NOR3x1_ASAP7_75t_R  g232(.A(new_n289_), .B(p13), .C(new_n290_), .Y(new_n291_));
  OA21x2_ASAP7_75t_R  g233(.A1(new_n290_), .A2(new_n289_), .B(p13), .Y(new_n292_));
  NOR2x1_ASAP7_75t_R  g234(.A(new_n291_), .B(new_n292_), .Y(o13));
  XOR2x2_ASAP7_75t_R  g235(.A(new_n246_), .B(p17), .Y(o14));
  XOR2x2_ASAP7_75t_R  g236(.A(new_n246_), .B(p10), .Y(o15));
  NOR2x1_ASAP7_75t_R  g237(.A(new_n205_), .B(new_n251_), .Y(new_n296_));
  AOI21x1_ASAP7_75t_R g238(.A1(new_n219_), .A2(new_n224_), .B(new_n296_), .Y(new_n297_));
  NAND3x1_ASAP7_75t_R g239(.A(new_n297_), .B(new_n243_), .C(new_n229_), .Y(new_n298_));
  NOR2x1_ASAP7_75t_R  g240(.A(new_n298_), .B(new_n199_), .Y(new_n299_));
  INVx1_ASAP7_75t_R   g241(.A(new_n177_), .Y(new_n300_));
  OAI21x1_ASAP7_75t_R g242(.A1(new_n300_), .A2(new_n96_), .B(new_n180_), .Y(new_n301_));
  AND3x1_ASAP7_75t_R  g243(.A(new_n299_), .B(new_n269_), .C(new_n301_), .Y(new_n302_));
  NOR2x1_ASAP7_75t_R  g244(.A(new_n180_), .B(new_n197_), .Y(new_n303_));
  AND3x1_ASAP7_75t_R  g245(.A(new_n271_), .B(new_n266_), .C(new_n303_), .Y(new_n304_));
  AO21x1_ASAP7_75t_R  g246(.A1(new_n179_), .A2(new_n304_), .B(p1), .Y(new_n305_));
  AO21x1_ASAP7_75t_R  g247(.A1(p4), .A2(new_n302_), .B(new_n305_), .Y(o16));
  OR2x4_ASAP7_75t_R   g248(.A(new_n174_), .B(new_n175_), .Y(new_n307_));
  AO21x1_ASAP7_75t_R  g249(.A1(new_n176_), .A2(new_n307_), .B(new_n274_), .Y(new_n308_));
  NAND2x1_ASAP7_75t_R g250(.A(new_n299_), .B(new_n257_), .Y(new_n309_));
  OAI21x1_ASAP7_75t_R g251(.A1(new_n308_), .A2(new_n309_), .B(new_n203_), .Y(new_n310_));
  AND3x1_ASAP7_75t_R  g252(.A(new_n92_), .B(p26), .C(p0), .Y(new_n311_));
  AOI21x1_ASAP7_75t_R g253(.A1(new_n311_), .A2(new_n302_), .B(new_n307_), .Y(new_n312_));
  NOR2x1_ASAP7_75t_R  g254(.A(new_n310_), .B(new_n312_), .Y(o17));
  NOR2x1_ASAP7_75t_R  g255(.A(p2), .B(new_n191_), .Y(new_n314_));
  NAND2x1_ASAP7_75t_R g256(.A(new_n187_), .B(new_n190_), .Y(new_n315_));
  NAND2x1_ASAP7_75t_R g257(.A(new_n314_), .B(new_n315_), .Y(new_n316_));
  OAI21x1_ASAP7_75t_R g258(.A1(new_n316_), .A2(new_n309_), .B(new_n203_), .Y(new_n317_));
  AOI21x1_ASAP7_75t_R g259(.A1(new_n314_), .A2(new_n302_), .B(new_n315_), .Y(new_n318_));
  NOR2x1_ASAP7_75t_R  g260(.A(new_n317_), .B(new_n318_), .Y(o18));
  OA21x2_ASAP7_75t_R  g261(.A1(new_n215_), .A2(new_n222_), .B(new_n219_), .Y(new_n320_));
  NAND2x1_ASAP7_75t_R g262(.A(p20), .B(new_n302_), .Y(new_n321_));
  AOI21x1_ASAP7_75t_R g263(.A1(new_n320_), .A2(new_n321_), .B(new_n202_), .Y(o19));
  NAND2x1_ASAP7_75t_R g264(.A(p12), .B(new_n302_), .Y(new_n323_));
  AOI21x1_ASAP7_75t_R g265(.A1(new_n241_), .A2(new_n323_), .B(new_n202_), .Y(o20));
  NOR2x1_ASAP7_75t_R  g266(.A(new_n162_), .B(new_n153_), .Y(new_n325_));
  AND3x1_ASAP7_75t_R  g267(.A(new_n257_), .B(new_n154_), .C(new_n299_), .Y(new_n326_));
  OA21x2_ASAP7_75t_R  g268(.A1(new_n325_), .A2(new_n326_), .B(new_n203_), .Y(o21));
  NAND2x1_ASAP7_75t_R g269(.A(new_n249_), .B(new_n90_), .Y(new_n328_));
  AOI21x1_ASAP7_75t_R g270(.A1(new_n255_), .A2(new_n257_), .B(new_n328_), .Y(new_n329_));
  NAND3x1_ASAP7_75t_R g271(.A(new_n282_), .B(new_n253_), .C(new_n328_), .Y(new_n330_));
  INVx1_ASAP7_75t_R   g272(.A(new_n199_), .Y(new_n331_));
  NAND3x1_ASAP7_75t_R g273(.A(new_n301_), .B(new_n331_), .C(new_n269_), .Y(new_n332_));
  AO21x1_ASAP7_75t_R  g274(.A1(p30), .A2(p31), .B(p1), .Y(new_n333_));
  INVx1_ASAP7_75t_R   g275(.A(new_n333_), .Y(new_n334_));
  OAI21x1_ASAP7_75t_R g276(.A1(new_n330_), .A2(new_n332_), .B(new_n334_), .Y(new_n335_));
  NOR3x1_ASAP7_75t_R  g277(.A(new_n270_), .B(new_n330_), .C(new_n276_), .Y(new_n336_));
  OAI21x1_ASAP7_75t_R g278(.A1(new_n336_), .A2(new_n329_), .B(new_n333_), .Y(new_n337_));
  OAI21x1_ASAP7_75t_R g279(.A1(new_n329_), .A2(new_n335_), .B(new_n337_), .Y(o22));
  NOR2x1_ASAP7_75t_R  g280(.A(p28), .B(p1), .Y(new_n339_));
  NOR2x1_ASAP7_75t_R  g281(.A(new_n134_), .B(new_n135_), .Y(new_n340_));
  XNOR2x2_ASAP7_75t_R g282(.A(new_n339_), .B(new_n340_), .Y(new_n341_));
  XOR2x2_ASAP7_75t_R  g283(.A(new_n182_), .B(new_n341_), .Y(new_n342_));
  OA21x2_ASAP7_75t_R  g284(.A1(p1), .A2(p3), .B(new_n342_), .Y(new_n343_));
  XOR2x2_ASAP7_75t_R  g285(.A(new_n277_), .B(new_n343_), .Y(o23));
  AO21x1_ASAP7_75t_R  g286(.A1(new_n128_), .A2(new_n127_), .B(new_n202_), .Y(new_n345_));
  AOI21x1_ASAP7_75t_R g287(.A1(new_n125_), .A2(new_n302_), .B(new_n345_), .Y(o24));
endmodule


