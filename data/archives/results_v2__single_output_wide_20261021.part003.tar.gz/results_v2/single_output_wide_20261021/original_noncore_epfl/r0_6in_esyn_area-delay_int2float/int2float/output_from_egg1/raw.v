// Benchmark "/home/flynn/workplace/MIGBalance/results_v2/single_output_wide_20261021/original_noncore_epfl/r0_6in_esyn_area-delay_int2float/int2float/output_from_egg1/logic" written by ABC on Wed Oct 21 14:41:55 2026

module \/home/flynn/workplace/MIGBalance/results_v2/single_output_wide_20261021/original_noncore_epfl/r0_6in_esyn_area-delay_int2float/int2float/output_from_egg1/logic  ( 
    \B[1] , \B[2] , \B[3] , \B[4] , \B[5] , \B[6] , \B[7] , \B[8] , \B[9] ,
    \B[10] , \B[0] ,
    \M[0] , \M[1] , \M[2] , \M[3] , \E[0] , \E[1] , \E[2]   );
  input  \B[1] , \B[2] , \B[3] , \B[4] , \B[5] , \B[6] , \B[7] , \B[8] ,
    \B[9] , \B[10] , \B[0] ;
  output \M[0] , \M[1] , \M[2] , \M[3] , \E[0] , \E[1] , \E[2] ;
  wire new_n19_, new_n20_, new_n21_, new_n22_, new_n23_, new_n24_, new_n25_,
    new_n26_, new_n27_, new_n28_, new_n29_, new_n30_, new_n31_, new_n32_,
    new_n33_, new_n34_, new_n35_, new_n36_, new_n37_, new_n38_, new_n39_,
    new_n40_, new_n41_, new_n42_, new_n43_, new_n44_, new_n45_, new_n46_,
    new_n47_, new_n48_, new_n49_, new_n50_, new_n51_, new_n52_, new_n53_,
    new_n55_, new_n56_, new_n57_, new_n58_, new_n59_, new_n60_, new_n61_,
    new_n62_, new_n63_, new_n64_, new_n65_, new_n66_, new_n67_, new_n68_,
    new_n69_, new_n70_, new_n71_, new_n72_, new_n73_, new_n74_, new_n75_,
    new_n76_, new_n77_, new_n78_, new_n79_, new_n80_, new_n82_, new_n83_,
    new_n84_, new_n85_, new_n86_, new_n87_, new_n88_, new_n89_, new_n90_,
    new_n91_, new_n92_, new_n93_, new_n94_, new_n95_, new_n96_, new_n97_,
    new_n98_, new_n99_, new_n100_, new_n101_, new_n102_, new_n103_,
    new_n105_, new_n106_, new_n107_, new_n108_, new_n109_, new_n110_,
    new_n112_, new_n113_, new_n114_, new_n115_, new_n116_, new_n117_,
    new_n118_, new_n119_, new_n120_, new_n122_, new_n123_, new_n124_,
    new_n125_, new_n126_, new_n127_, new_n128_;
  INVx1_ASAP7_75t_R    g000(.A(\B[1] ), .Y(new_n19_));
  INVx1_ASAP7_75t_R    g001(.A(\B[2] ), .Y(new_n20_));
  INVx1_ASAP7_75t_R    g002(.A(\B[3] ), .Y(new_n21_));
  INVx1_ASAP7_75t_R    g003(.A(\B[4] ), .Y(new_n22_));
  INVx1_ASAP7_75t_R    g004(.A(\B[5] ), .Y(new_n23_));
  INVx1_ASAP7_75t_R    g005(.A(\B[6] ), .Y(new_n24_));
  INVx1_ASAP7_75t_R    g006(.A(\B[7] ), .Y(new_n25_));
  INVx1_ASAP7_75t_R    g007(.A(\B[8] ), .Y(new_n26_));
  INVx1_ASAP7_75t_R    g008(.A(\B[9] ), .Y(new_n27_));
  INVx1_ASAP7_75t_R    g009(.A(\B[10] ), .Y(new_n28_));
  INVx1_ASAP7_75t_R    g010(.A(\B[0] ), .Y(new_n29_));
  NOR2x1_ASAP7_75t_R   g011(.A(\B[8] ), .B(\B[9] ), .Y(new_n30_));
  INVx1_ASAP7_75t_R    g012(.A(new_n30_), .Y(new_n31_));
  AO22x1_ASAP7_75t_R   g013(.A1(\B[2] ), .A2(new_n21_), .B1(new_n20_), .B2(\B[3] ), .Y(new_n32_));
  AO21x1_ASAP7_75t_R   g014(.A1(new_n30_), .A2(new_n32_), .B(\B[10] ), .Y(new_n33_));
  AO32x1_ASAP7_75t_R   g015(.A1(\B[8] ), .A2(\B[10] ), .A3(\B[9] ), .B1(new_n25_), .B2(new_n33_), .Y(new_n34_));
  NOR2x1_ASAP7_75t_R   g016(.A(\B[6] ), .B(new_n25_), .Y(new_n35_));
  NAND2x1_ASAP7_75t_R  g017(.A(new_n25_), .B(new_n26_), .Y(new_n36_));
  OA211x2_ASAP7_75t_R  g018(.A1(\B[4] ), .A2(new_n25_), .B(\B[1] ), .C(new_n20_), .Y(new_n37_));
  INVx1_ASAP7_75t_R    g019(.A(new_n37_), .Y(new_n38_));
  NOR2x1_ASAP7_75t_R   g020(.A(new_n21_), .B(new_n22_), .Y(new_n39_));
  NOR2x1_ASAP7_75t_R   g021(.A(new_n22_), .B(new_n26_), .Y(new_n40_));
  OA331x2_ASAP7_75t_R  g022(.A1(\B[1] ), .A2(new_n20_), .A3(new_n36_), .B1(new_n39_), .B2(new_n40_), .B3(new_n38_), .C1(new_n27_), .Y(new_n41_));
  NOR2x1_ASAP7_75t_R   g023(.A(new_n19_), .B(new_n23_), .Y(new_n42_));
  AO32x1_ASAP7_75t_R   g024(.A1(new_n20_), .A2(new_n25_), .A3(new_n42_), .B1(new_n22_), .B2(\B[7] ), .Y(new_n43_));
  AO32x1_ASAP7_75t_R   g025(.A1(new_n21_), .A2(\B[4] ), .A3(\B[7] ), .B1(\B[3] ), .B2(new_n43_), .Y(new_n44_));
  AO32x1_ASAP7_75t_R   g026(.A1(new_n22_), .A2(\B[5] ), .A3(\B[8] ), .B1(new_n26_), .B2(new_n44_), .Y(new_n45_));
  NOR2x1_ASAP7_75t_R   g027(.A(new_n19_), .B(new_n22_), .Y(new_n46_));
  OA211x2_ASAP7_75t_R  g028(.A1(\B[0] ), .A2(new_n46_), .B(new_n24_), .C(new_n25_), .Y(new_n47_));
  AO21x1_ASAP7_75t_R   g029(.A1(new_n22_), .A2(\B[8] ), .B(new_n46_), .Y(new_n48_));
  NAND2x1_ASAP7_75t_R  g030(.A(\B[0] ), .B(new_n48_), .Y(new_n49_));
  AO21x1_ASAP7_75t_R   g031(.A1(new_n47_), .A2(new_n49_), .B(new_n40_), .Y(new_n50_));
  AOI21x1_ASAP7_75t_R  g032(.A1(new_n23_), .A2(new_n50_), .B(new_n45_), .Y(new_n51_));
  OA332x2_ASAP7_75t_R  g033(.A1(new_n23_), .A2(\B[6] ), .A3(new_n41_), .B1(\B[5] ), .B2(new_n24_), .B3(new_n27_), .C1(\B[9] ), .C2(new_n51_), .Y(new_n52_));
  INVx1_ASAP7_75t_R    g034(.A(new_n52_), .Y(new_n53_));
  AO222x2_ASAP7_75t_R  g035(.A1(\B[6] ), .A2(new_n34_), .B1(\B[10] ), .B2(new_n35_), .C1(new_n28_), .C2(new_n53_), .Y(\M[0] ));
  NOR2x1_ASAP7_75t_R   g036(.A(new_n24_), .B(new_n25_), .Y(new_n55_));
  AND3x1_ASAP7_75t_R   g037(.A(\B[3] ), .B(\B[4] ), .C(\B[2] ), .Y(new_n56_));
  AO33x2_ASAP7_75t_R   g038(.A1(new_n21_), .A2(\B[5] ), .A3(new_n24_), .B1(\B[6] ), .B2(new_n27_), .B3(new_n22_), .Y(new_n57_));
  AO32x1_ASAP7_75t_R   g039(.A1(\B[6] ), .A2(new_n27_), .A3(new_n56_), .B1(new_n20_), .B2(new_n57_), .Y(new_n58_));
  AO33x2_ASAP7_75t_R   g040(.A1(\B[6] ), .A2(new_n27_), .A3(new_n22_), .B1(\B[5] ), .B2(new_n24_), .B3(new_n19_), .Y(new_n59_));
  AO21x1_ASAP7_75t_R   g041(.A1(new_n21_), .A2(new_n59_), .B(new_n58_), .Y(new_n60_));
  AOI21x1_ASAP7_75t_R  g042(.A1(new_n25_), .A2(new_n60_), .B(\B[10] ), .Y(new_n61_));
  OR3x1_ASAP7_75t_R    g043(.A(new_n24_), .B(new_n25_), .C(\B[9] ), .Y(new_n62_));
  INVx1_ASAP7_75t_R    g044(.A(new_n62_), .Y(new_n63_));
  AO32x1_ASAP7_75t_R   g045(.A1(new_n22_), .A2(\B[8] ), .A3(new_n27_), .B1(new_n25_), .B2(\B[9] ), .Y(new_n64_));
  INVx1_ASAP7_75t_R    g046(.A(new_n64_), .Y(new_n65_));
  AOI22x1_ASAP7_75t_R  g047(.A1(new_n25_), .A2(\B[9] ), .B1(new_n22_), .B2(new_n27_), .Y(new_n66_));
  OA21x2_ASAP7_75t_R   g048(.A1(new_n19_), .A2(new_n20_), .B(new_n25_), .Y(new_n67_));
  OR3x1_ASAP7_75t_R    g049(.A(new_n19_), .B(new_n20_), .C(\B[7] ), .Y(new_n68_));
  OA33x2_ASAP7_75t_R   g050(.A1(new_n22_), .A2(new_n31_), .A3(new_n67_), .B1(\B[4] ), .B2(\B[6] ), .B3(new_n68_), .Y(new_n69_));
  INVx1_ASAP7_75t_R    g051(.A(new_n69_), .Y(new_n70_));
  AO32x1_ASAP7_75t_R   g052(.A1(\B[6] ), .A2(new_n31_), .A3(new_n66_), .B1(\B[3] ), .B2(new_n70_), .Y(new_n71_));
  INVx1_ASAP7_75t_R    g053(.A(new_n71_), .Y(new_n72_));
  OR3x1_ASAP7_75t_R    g054(.A(\B[8] ), .B(\B[9] ), .C(new_n25_), .Y(new_n73_));
  AOI22x1_ASAP7_75t_R  g055(.A1(new_n20_), .A2(new_n25_), .B1(new_n22_), .B2(new_n27_), .Y(new_n74_));
  OA211x2_ASAP7_75t_R  g056(.A1(new_n20_), .A2(\B[0] ), .B(\B[4] ), .C(new_n25_), .Y(new_n75_));
  INVx1_ASAP7_75t_R    g057(.A(new_n75_), .Y(new_n76_));
  OA21x2_ASAP7_75t_R   g058(.A1(new_n19_), .A2(new_n20_), .B(\B[0] ), .Y(new_n77_));
  OA222x2_ASAP7_75t_R  g059(.A1(\B[1] ), .A2(new_n74_), .B1(new_n26_), .B2(\B[9] ), .C1(new_n76_), .C2(new_n77_), .Y(new_n78_));
  OA222x2_ASAP7_75t_R  g060(.A1(\B[7] ), .A2(new_n27_), .B1(new_n39_), .B2(new_n73_), .C1(\B[6] ), .C2(new_n78_), .Y(new_n79_));
  OA222x2_ASAP7_75t_R  g061(.A1(\B[6] ), .A2(new_n65_), .B1(new_n23_), .B2(new_n72_), .C1(\B[5] ), .C2(new_n79_), .Y(new_n80_));
  OA332x2_ASAP7_75t_R  g062(.A1(\B[8] ), .A2(new_n55_), .A3(new_n61_), .B1(new_n26_), .B2(new_n28_), .B3(new_n62_), .C1(\B[10] ), .C2(new_n80_), .Y(\M[1] ));
  AO21x1_ASAP7_75t_R   g063(.A1(\B[5] ), .A2(\B[7] ), .B(new_n26_), .Y(new_n82_));
  NAND2x1_ASAP7_75t_R  g064(.A(new_n28_), .B(new_n82_), .Y(new_n83_));
  AO32x1_ASAP7_75t_R   g065(.A1(\B[5] ), .A2(new_n26_), .A3(\B[9] ), .B1(\B[8] ), .B2(\B[10] ), .Y(new_n84_));
  NOR2x1_ASAP7_75t_R   g066(.A(new_n22_), .B(new_n23_), .Y(new_n85_));
  NAND2x1_ASAP7_75t_R  g067(.A(\B[6] ), .B(new_n25_), .Y(new_n86_));
  AND3x1_ASAP7_75t_R   g068(.A(\B[6] ), .B(new_n25_), .C(new_n85_), .Y(new_n87_));
  OA21x2_ASAP7_75t_R   g069(.A1(new_n35_), .A2(new_n87_), .B(\B[8] ), .Y(new_n88_));
  OA33x2_ASAP7_75t_R   g070(.A1(new_n24_), .A2(\B[7] ), .A3(\B[2] ), .B1(\B[6] ), .B2(new_n25_), .B3(new_n21_), .Y(new_n89_));
  OA33x2_ASAP7_75t_R   g071(.A1(new_n23_), .A2(\B[6] ), .A3(\B[1] ), .B1(\B[5] ), .B2(new_n24_), .B3(new_n20_), .Y(new_n90_));
  NAND2x1_ASAP7_75t_R  g072(.A(\B[5] ), .B(\B[6] ), .Y(new_n91_));
  AO32x1_ASAP7_75t_R   g073(.A1(new_n20_), .A2(\B[3] ), .A3(new_n24_), .B1(new_n21_), .B2(\B[5] ), .Y(new_n92_));
  NOR2x1_ASAP7_75t_R   g074(.A(new_n19_), .B(new_n29_), .Y(new_n93_));
  INVx1_ASAP7_75t_R    g075(.A(new_n93_), .Y(new_n94_));
  AO32x1_ASAP7_75t_R   g076(.A1(\B[3] ), .A2(\B[4] ), .A3(new_n94_), .B1(new_n22_), .B2(new_n24_), .Y(new_n95_));
  NOR2x1_ASAP7_75t_R   g077(.A(\B[6] ), .B(new_n29_), .Y(new_n96_));
  AO33x2_ASAP7_75t_R   g078(.A1(new_n22_), .A2(\B[5] ), .A3(\B[3] ), .B1(new_n21_), .B2(\B[4] ), .B3(new_n96_), .Y(new_n97_));
  AO22x1_ASAP7_75t_R   g079(.A1(new_n23_), .A2(new_n95_), .B1(\B[1] ), .B2(new_n97_), .Y(new_n98_));
  AOI22x1_ASAP7_75t_R  g080(.A1(\B[4] ), .A2(new_n92_), .B1(\B[2] ), .B2(new_n98_), .Y(new_n99_));
  OA332x2_ASAP7_75t_R  g081(.A1(new_n21_), .A2(new_n22_), .A3(new_n90_), .B1(new_n23_), .B2(new_n24_), .B3(new_n39_), .C1(\B[7] ), .C2(new_n99_), .Y(new_n100_));
  OA332x2_ASAP7_75t_R  g082(.A1(new_n22_), .A2(new_n23_), .A3(new_n89_), .B1(new_n24_), .B2(new_n25_), .B3(new_n85_), .C1(\B[8] ), .C2(new_n100_), .Y(new_n101_));
  INVx1_ASAP7_75t_R    g083(.A(new_n101_), .Y(new_n102_));
  AO21x1_ASAP7_75t_R   g084(.A1(new_n27_), .A2(new_n102_), .B(new_n88_), .Y(new_n103_));
  AO222x2_ASAP7_75t_R  g085(.A1(\B[9] ), .A2(new_n83_), .B1(new_n55_), .B2(new_n84_), .C1(new_n28_), .C2(new_n103_), .Y(\M[2] ));
  NOR2x1_ASAP7_75t_R   g086(.A(\B[9] ), .B(\B[10] ), .Y(new_n105_));
  NOR2x1_ASAP7_75t_R   g087(.A(\B[5] ), .B(\B[6] ), .Y(new_n106_));
  AND5x1_ASAP7_75t_R   g088(.A(new_n22_), .B(new_n25_), .C(new_n26_), .D(new_n23_), .E(new_n24_), .Y(new_n107_));
  AND3x1_ASAP7_75t_R   g089(.A(\B[5] ), .B(\B[6] ), .C(\B[7] ), .Y(new_n108_));
  AND3x1_ASAP7_75t_R   g090(.A(new_n20_), .B(new_n40_), .C(new_n108_), .Y(new_n109_));
  OA211x2_ASAP7_75t_R  g091(.A1(new_n107_), .A2(new_n109_), .B(new_n21_), .C(new_n105_), .Y(new_n110_));
  INVx1_ASAP7_75t_R    g092(.A(new_n110_), .Y(\M[3] ));
  AO22x1_ASAP7_75t_R   g093(.A1(\B[2] ), .A2(new_n21_), .B1(\B[3] ), .B2(\B[8] ), .Y(new_n112_));
  OR3x1_ASAP7_75t_R    g094(.A(new_n25_), .B(new_n91_), .C(new_n26_), .Y(new_n113_));
  AO32x1_ASAP7_75t_R   g095(.A1(new_n63_), .A2(new_n85_), .A3(new_n112_), .B1(\B[9] ), .B2(new_n113_), .Y(new_n114_));
  AO21x1_ASAP7_75t_R   g096(.A1(new_n93_), .A2(new_n106_), .B(new_n87_), .Y(new_n115_));
  NAND2x1_ASAP7_75t_R  g097(.A(new_n23_), .B(new_n25_), .Y(new_n116_));
  AO21x1_ASAP7_75t_R   g098(.A1(new_n68_), .A2(new_n91_), .B(new_n21_), .Y(new_n117_));
  AO21x1_ASAP7_75t_R   g099(.A1(new_n116_), .A2(new_n117_), .B(new_n22_), .Y(new_n118_));
  AO32x1_ASAP7_75t_R   g100(.A1(\B[2] ), .A2(\B[3] ), .A3(new_n115_), .B1(new_n86_), .B2(new_n118_), .Y(new_n119_));
  AO21x1_ASAP7_75t_R   g101(.A1(new_n26_), .A2(new_n119_), .B(new_n114_), .Y(new_n120_));
  NAND2x1_ASAP7_75t_R  g102(.A(new_n28_), .B(new_n120_), .Y(\E[0] ));
  AND3x1_ASAP7_75t_R   g103(.A(\B[5] ), .B(\B[6] ), .C(new_n56_), .Y(new_n122_));
  OR3x1_ASAP7_75t_R    g104(.A(new_n36_), .B(new_n106_), .C(new_n122_), .Y(new_n123_));
  AND5x1_ASAP7_75t_R   g105(.A(\B[3] ), .B(new_n26_), .C(new_n93_), .D(new_n23_), .E(new_n25_), .Y(new_n124_));
  AO21x1_ASAP7_75t_R   g106(.A1(\B[8] ), .A2(new_n108_), .B(new_n124_), .Y(new_n125_));
  AO32x1_ASAP7_75t_R   g107(.A1(\B[3] ), .A2(\B[8] ), .A3(new_n108_), .B1(\B[2] ), .B2(new_n125_), .Y(new_n126_));
  INVx1_ASAP7_75t_R    g108(.A(new_n126_), .Y(new_n127_));
  OA211x2_ASAP7_75t_R  g109(.A1(new_n22_), .A2(new_n127_), .B(new_n105_), .C(new_n123_), .Y(new_n128_));
  INVx1_ASAP7_75t_R    g110(.A(new_n128_), .Y(\E[1] ));
  OR5x1_ASAP7_75t_R    g111(.A(\B[7] ), .B(\B[8] ), .C(\B[9] ), .D(\B[10] ), .E(new_n122_), .Y(\E[2] ));
endmodule


