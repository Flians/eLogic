// Benchmark "/home/flynn/workplace/MIGBalance/results_v2/single_output_wide_20261021/original_noncore_epfl/r0_6in_esyn_area-delay_int2float/int2float/output_from_egg28/logic" written by ABC on Wed Oct 21 14:42:23 2026

module \/home/flynn/workplace/MIGBalance/results_v2/single_output_wide_20261021/original_noncore_epfl/r0_6in_esyn_area-delay_int2float/int2float/output_from_egg28/logic  ( 
    \B[1] , \B[2] , \B[3] , \B[4] , \B[5] , \B[6] , \B[7] , \B[8] , \B[9] ,
    \B[10] , \B[0] ,
    \M[0] , \M[1] , \M[2] , \M[3] , \E[0] , \E[1] , \E[2]   );
  input  \B[1] , \B[2] , \B[3] , \B[4] , \B[5] , \B[6] , \B[7] , \B[8] ,
    \B[9] , \B[10] , \B[0] ;
  output \M[0] , \M[1] , \M[2] , \M[3] , \E[0] , \E[1] , \E[2] ;
  wire new_n19_, new_n20_, new_n21_, new_n22_, new_n23_, new_n24_, new_n25_,
    new_n26_, new_n27_, new_n28_, new_n29_, new_n30_, new_n31_, new_n32_,
    new_n33_, new_n34_, new_n35_, new_n36_, new_n37_, new_n38_, new_n39_,
    new_n40_, new_n41_, new_n42_, new_n43_, new_n44_, new_n45_, new_n46_,
    new_n47_, new_n48_, new_n49_, new_n50_, new_n51_, new_n52_, new_n53_,
    new_n55_, new_n56_, new_n57_, new_n58_, new_n59_, new_n60_, new_n61_,
    new_n62_, new_n63_, new_n64_, new_n65_, new_n66_, new_n67_, new_n68_,
    new_n69_, new_n70_, new_n71_, new_n72_, new_n73_, new_n74_, new_n75_,
    new_n76_, new_n77_, new_n78_, new_n79_, new_n80_, new_n81_, new_n83_,
    new_n84_, new_n85_, new_n86_, new_n87_, new_n88_, new_n89_, new_n90_,
    new_n91_, new_n92_, new_n93_, new_n94_, new_n95_, new_n96_, new_n97_,
    new_n98_, new_n99_, new_n100_, new_n101_, new_n102_, new_n103_,
    new_n104_, new_n106_, new_n107_, new_n108_, new_n109_, new_n110_,
    new_n111_, new_n113_, new_n114_, new_n115_, new_n116_, new_n117_,
    new_n118_, new_n119_, new_n120_, new_n121_, new_n123_, new_n124_,
    new_n125_, new_n126_, new_n127_, new_n128_, new_n129_;
  INVx1_ASAP7_75t_R    g000(.A(\B[1] ), .Y(new_n19_));
  INVx1_ASAP7_75t_R    g001(.A(\B[2] ), .Y(new_n20_));
  INVx1_ASAP7_75t_R    g002(.A(\B[3] ), .Y(new_n21_));
  INVx1_ASAP7_75t_R    g003(.A(\B[4] ), .Y(new_n22_));
  INVx1_ASAP7_75t_R    g004(.A(\B[5] ), .Y(new_n23_));
  INVx1_ASAP7_75t_R    g005(.A(\B[6] ), .Y(new_n24_));
  INVx1_ASAP7_75t_R    g006(.A(\B[7] ), .Y(new_n25_));
  INVx1_ASAP7_75t_R    g007(.A(\B[8] ), .Y(new_n26_));
  INVx1_ASAP7_75t_R    g008(.A(\B[9] ), .Y(new_n27_));
  INVx1_ASAP7_75t_R    g009(.A(\B[10] ), .Y(new_n28_));
  INVx1_ASAP7_75t_R    g010(.A(\B[0] ), .Y(new_n29_));
  NOR2x1_ASAP7_75t_R   g011(.A(new_n22_), .B(new_n26_), .Y(new_n30_));
  NOR2x1_ASAP7_75t_R   g012(.A(new_n21_), .B(new_n22_), .Y(new_n31_));
  OA211x2_ASAP7_75t_R  g013(.A1(\B[4] ), .A2(new_n25_), .B(\B[1] ), .C(new_n20_), .Y(new_n32_));
  INVx1_ASAP7_75t_R    g014(.A(new_n32_), .Y(new_n33_));
  NAND2x1_ASAP7_75t_R  g015(.A(new_n25_), .B(new_n26_), .Y(new_n34_));
  OA331x2_ASAP7_75t_R  g016(.A1(\B[1] ), .A2(new_n20_), .A3(new_n34_), .B1(new_n30_), .B2(new_n31_), .B3(new_n33_), .C1(new_n27_), .Y(new_n35_));
  NOR2x1_ASAP7_75t_R   g017(.A(new_n19_), .B(new_n23_), .Y(new_n36_));
  AO32x1_ASAP7_75t_R   g018(.A1(new_n20_), .A2(new_n25_), .A3(new_n36_), .B1(new_n22_), .B2(\B[7] ), .Y(new_n37_));
  AO32x1_ASAP7_75t_R   g019(.A1(new_n21_), .A2(\B[4] ), .A3(\B[7] ), .B1(\B[3] ), .B2(new_n37_), .Y(new_n38_));
  AO32x1_ASAP7_75t_R   g020(.A1(new_n22_), .A2(\B[5] ), .A3(\B[8] ), .B1(new_n26_), .B2(new_n38_), .Y(new_n39_));
  NOR2x1_ASAP7_75t_R   g021(.A(new_n19_), .B(new_n22_), .Y(new_n40_));
  AO21x1_ASAP7_75t_R   g022(.A1(new_n22_), .A2(\B[8] ), .B(new_n40_), .Y(new_n41_));
  NAND2x1_ASAP7_75t_R  g023(.A(\B[0] ), .B(new_n41_), .Y(new_n42_));
  OA211x2_ASAP7_75t_R  g024(.A1(\B[0] ), .A2(new_n40_), .B(new_n24_), .C(new_n25_), .Y(new_n43_));
  AO21x1_ASAP7_75t_R   g025(.A1(new_n42_), .A2(new_n43_), .B(new_n30_), .Y(new_n44_));
  AOI21x1_ASAP7_75t_R  g026(.A1(new_n23_), .A2(new_n44_), .B(new_n39_), .Y(new_n45_));
  OA332x2_ASAP7_75t_R  g027(.A1(new_n23_), .A2(\B[6] ), .A3(new_n35_), .B1(\B[5] ), .B2(new_n24_), .B3(new_n27_), .C1(\B[9] ), .C2(new_n45_), .Y(new_n46_));
  INVx1_ASAP7_75t_R    g028(.A(new_n46_), .Y(new_n47_));
  NOR2x1_ASAP7_75t_R   g029(.A(\B[6] ), .B(new_n25_), .Y(new_n48_));
  NOR2x1_ASAP7_75t_R   g030(.A(\B[8] ), .B(\B[9] ), .Y(new_n49_));
  INVx1_ASAP7_75t_R    g031(.A(new_n49_), .Y(new_n50_));
  AO22x1_ASAP7_75t_R   g032(.A1(\B[2] ), .A2(new_n21_), .B1(new_n20_), .B2(\B[3] ), .Y(new_n51_));
  AO21x1_ASAP7_75t_R   g033(.A1(new_n49_), .A2(new_n51_), .B(\B[10] ), .Y(new_n52_));
  AO32x1_ASAP7_75t_R   g034(.A1(\B[8] ), .A2(\B[10] ), .A3(\B[9] ), .B1(new_n25_), .B2(new_n52_), .Y(new_n53_));
  AO222x2_ASAP7_75t_R  g035(.A1(\B[10] ), .A2(new_n48_), .B1(\B[6] ), .B2(new_n53_), .C1(new_n28_), .C2(new_n47_), .Y(\M[0] ));
  AO33x2_ASAP7_75t_R   g036(.A1(\B[5] ), .A2(new_n24_), .A3(new_n19_), .B1(\B[6] ), .B2(new_n27_), .B3(new_n22_), .Y(new_n55_));
  AND3x1_ASAP7_75t_R   g037(.A(\B[3] ), .B(\B[4] ), .C(\B[2] ), .Y(new_n56_));
  AO33x2_ASAP7_75t_R   g038(.A1(\B[6] ), .A2(new_n27_), .A3(new_n22_), .B1(new_n21_), .B2(\B[5] ), .B3(new_n24_), .Y(new_n57_));
  AO32x1_ASAP7_75t_R   g039(.A1(\B[6] ), .A2(new_n27_), .A3(new_n56_), .B1(new_n20_), .B2(new_n57_), .Y(new_n58_));
  AO21x1_ASAP7_75t_R   g040(.A1(new_n21_), .A2(new_n55_), .B(new_n58_), .Y(new_n59_));
  AOI21x1_ASAP7_75t_R  g041(.A1(new_n25_), .A2(new_n59_), .B(\B[10] ), .Y(new_n60_));
  NOR2x1_ASAP7_75t_R   g042(.A(new_n24_), .B(new_n25_), .Y(new_n61_));
  OR3x1_ASAP7_75t_R    g043(.A(new_n24_), .B(new_n25_), .C(\B[9] ), .Y(new_n62_));
  INVx1_ASAP7_75t_R    g044(.A(new_n62_), .Y(new_n63_));
  AOI22x1_ASAP7_75t_R  g045(.A1(new_n20_), .A2(new_n25_), .B1(new_n22_), .B2(new_n27_), .Y(new_n64_));
  OA211x2_ASAP7_75t_R  g046(.A1(new_n20_), .A2(\B[0] ), .B(\B[4] ), .C(new_n25_), .Y(new_n65_));
  INVx1_ASAP7_75t_R    g047(.A(new_n65_), .Y(new_n66_));
  OA21x2_ASAP7_75t_R   g048(.A1(new_n19_), .A2(new_n20_), .B(\B[0] ), .Y(new_n67_));
  OA222x2_ASAP7_75t_R  g049(.A1(new_n26_), .A2(\B[9] ), .B1(\B[1] ), .B2(new_n64_), .C1(new_n66_), .C2(new_n67_), .Y(new_n68_));
  NAND2x1_ASAP7_75t_R  g050(.A(new_n25_), .B(\B[9] ), .Y(new_n69_));
  OR3x1_ASAP7_75t_R    g051(.A(new_n25_), .B(new_n50_), .C(new_n31_), .Y(new_n70_));
  OA211x2_ASAP7_75t_R  g052(.A1(\B[6] ), .A2(new_n68_), .B(new_n69_), .C(new_n70_), .Y(new_n71_));
  OR3x1_ASAP7_75t_R    g053(.A(new_n19_), .B(new_n20_), .C(\B[7] ), .Y(new_n72_));
  OA21x2_ASAP7_75t_R   g054(.A1(new_n19_), .A2(new_n20_), .B(new_n25_), .Y(new_n73_));
  OA33x2_ASAP7_75t_R   g055(.A1(\B[4] ), .A2(\B[6] ), .A3(new_n72_), .B1(new_n22_), .B2(new_n50_), .B3(new_n73_), .Y(new_n74_));
  INVx1_ASAP7_75t_R    g056(.A(new_n74_), .Y(new_n75_));
  OA21x2_ASAP7_75t_R   g057(.A1(\B[4] ), .A2(\B[9] ), .B(new_n69_), .Y(new_n76_));
  AO32x1_ASAP7_75t_R   g058(.A1(\B[6] ), .A2(new_n50_), .A3(new_n76_), .B1(\B[3] ), .B2(new_n75_), .Y(new_n77_));
  INVx1_ASAP7_75t_R    g059(.A(new_n77_), .Y(new_n78_));
  AO32x1_ASAP7_75t_R   g060(.A1(new_n22_), .A2(\B[8] ), .A3(new_n27_), .B1(new_n25_), .B2(\B[9] ), .Y(new_n79_));
  INVx1_ASAP7_75t_R    g061(.A(new_n79_), .Y(new_n80_));
  OA222x2_ASAP7_75t_R  g062(.A1(new_n23_), .A2(new_n78_), .B1(\B[6] ), .B2(new_n80_), .C1(\B[5] ), .C2(new_n71_), .Y(new_n81_));
  OA332x2_ASAP7_75t_R  g063(.A1(\B[8] ), .A2(new_n61_), .A3(new_n60_), .B1(new_n26_), .B2(new_n28_), .B3(new_n62_), .C1(\B[10] ), .C2(new_n81_), .Y(\M[1] ));
  AO21x1_ASAP7_75t_R   g064(.A1(\B[5] ), .A2(\B[7] ), .B(new_n26_), .Y(new_n83_));
  NAND2x1_ASAP7_75t_R  g065(.A(new_n28_), .B(new_n83_), .Y(new_n84_));
  AO32x1_ASAP7_75t_R   g066(.A1(\B[5] ), .A2(new_n26_), .A3(\B[9] ), .B1(\B[8] ), .B2(\B[10] ), .Y(new_n85_));
  NOR2x1_ASAP7_75t_R   g067(.A(new_n22_), .B(new_n23_), .Y(new_n86_));
  NAND2x1_ASAP7_75t_R  g068(.A(\B[6] ), .B(new_n25_), .Y(new_n87_));
  OA33x2_ASAP7_75t_R   g069(.A1(new_n24_), .A2(\B[7] ), .A3(\B[2] ), .B1(\B[6] ), .B2(new_n25_), .B3(new_n21_), .Y(new_n88_));
  NOR2x1_ASAP7_75t_R   g070(.A(\B[6] ), .B(new_n29_), .Y(new_n89_));
  AO33x2_ASAP7_75t_R   g071(.A1(new_n22_), .A2(\B[5] ), .A3(\B[3] ), .B1(new_n21_), .B2(\B[4] ), .B3(new_n89_), .Y(new_n90_));
  NOR2x1_ASAP7_75t_R   g072(.A(new_n19_), .B(new_n29_), .Y(new_n91_));
  INVx1_ASAP7_75t_R    g073(.A(new_n91_), .Y(new_n92_));
  AO32x1_ASAP7_75t_R   g074(.A1(\B[3] ), .A2(\B[4] ), .A3(new_n92_), .B1(new_n22_), .B2(new_n24_), .Y(new_n93_));
  AO22x1_ASAP7_75t_R   g075(.A1(\B[1] ), .A2(new_n90_), .B1(new_n23_), .B2(new_n93_), .Y(new_n94_));
  AO32x1_ASAP7_75t_R   g076(.A1(new_n20_), .A2(\B[3] ), .A3(new_n24_), .B1(new_n21_), .B2(\B[5] ), .Y(new_n95_));
  AOI22x1_ASAP7_75t_R  g077(.A1(\B[2] ), .A2(new_n94_), .B1(\B[4] ), .B2(new_n95_), .Y(new_n96_));
  NAND2x1_ASAP7_75t_R  g078(.A(\B[5] ), .B(\B[6] ), .Y(new_n97_));
  OA33x2_ASAP7_75t_R   g079(.A1(new_n23_), .A2(\B[6] ), .A3(\B[1] ), .B1(\B[5] ), .B2(new_n24_), .B3(new_n20_), .Y(new_n98_));
  OA332x2_ASAP7_75t_R  g080(.A1(new_n23_), .A2(new_n24_), .A3(new_n31_), .B1(new_n21_), .B2(new_n22_), .B3(new_n98_), .C1(\B[7] ), .C2(new_n96_), .Y(new_n99_));
  OA332x2_ASAP7_75t_R  g081(.A1(new_n24_), .A2(new_n25_), .A3(new_n86_), .B1(new_n22_), .B2(new_n23_), .B3(new_n88_), .C1(\B[8] ), .C2(new_n99_), .Y(new_n100_));
  INVx1_ASAP7_75t_R    g082(.A(new_n100_), .Y(new_n101_));
  AND3x1_ASAP7_75t_R   g083(.A(\B[6] ), .B(new_n25_), .C(new_n86_), .Y(new_n102_));
  OA21x2_ASAP7_75t_R   g084(.A1(new_n48_), .A2(new_n102_), .B(\B[8] ), .Y(new_n103_));
  AO21x1_ASAP7_75t_R   g085(.A1(new_n27_), .A2(new_n101_), .B(new_n103_), .Y(new_n104_));
  AO222x2_ASAP7_75t_R  g086(.A1(\B[9] ), .A2(new_n84_), .B1(new_n61_), .B2(new_n85_), .C1(new_n28_), .C2(new_n104_), .Y(\M[2] ));
  AND3x1_ASAP7_75t_R   g087(.A(\B[5] ), .B(\B[6] ), .C(\B[7] ), .Y(new_n106_));
  AND3x1_ASAP7_75t_R   g088(.A(new_n20_), .B(new_n30_), .C(new_n106_), .Y(new_n107_));
  NOR2x1_ASAP7_75t_R   g089(.A(\B[5] ), .B(\B[6] ), .Y(new_n108_));
  AND5x1_ASAP7_75t_R   g090(.A(new_n22_), .B(new_n25_), .C(new_n26_), .D(new_n23_), .E(new_n24_), .Y(new_n109_));
  NOR2x1_ASAP7_75t_R   g091(.A(\B[9] ), .B(\B[10] ), .Y(new_n110_));
  OA211x2_ASAP7_75t_R  g092(.A1(new_n107_), .A2(new_n109_), .B(new_n21_), .C(new_n110_), .Y(new_n111_));
  INVx1_ASAP7_75t_R    g093(.A(new_n111_), .Y(\M[3] ));
  AO21x1_ASAP7_75t_R   g094(.A1(new_n91_), .A2(new_n108_), .B(new_n102_), .Y(new_n113_));
  AO21x1_ASAP7_75t_R   g095(.A1(new_n72_), .A2(new_n97_), .B(new_n21_), .Y(new_n114_));
  NAND2x1_ASAP7_75t_R  g096(.A(new_n23_), .B(new_n25_), .Y(new_n115_));
  AO21x1_ASAP7_75t_R   g097(.A1(new_n114_), .A2(new_n115_), .B(new_n22_), .Y(new_n116_));
  AO32x1_ASAP7_75t_R   g098(.A1(\B[2] ), .A2(\B[3] ), .A3(new_n113_), .B1(new_n87_), .B2(new_n116_), .Y(new_n117_));
  AO22x1_ASAP7_75t_R   g099(.A1(\B[2] ), .A2(new_n21_), .B1(\B[3] ), .B2(\B[8] ), .Y(new_n118_));
  OR3x1_ASAP7_75t_R    g100(.A(new_n25_), .B(new_n97_), .C(new_n26_), .Y(new_n119_));
  AO32x1_ASAP7_75t_R   g101(.A1(new_n63_), .A2(new_n86_), .A3(new_n118_), .B1(\B[9] ), .B2(new_n119_), .Y(new_n120_));
  AO21x1_ASAP7_75t_R   g102(.A1(new_n26_), .A2(new_n117_), .B(new_n120_), .Y(new_n121_));
  NAND2x1_ASAP7_75t_R  g103(.A(new_n28_), .B(new_n121_), .Y(\E[0] ));
  AND5x1_ASAP7_75t_R   g104(.A(\B[3] ), .B(new_n26_), .C(new_n91_), .D(new_n23_), .E(new_n25_), .Y(new_n123_));
  AO21x1_ASAP7_75t_R   g105(.A1(\B[8] ), .A2(new_n106_), .B(new_n123_), .Y(new_n124_));
  AO32x1_ASAP7_75t_R   g106(.A1(\B[3] ), .A2(\B[8] ), .A3(new_n106_), .B1(\B[2] ), .B2(new_n124_), .Y(new_n125_));
  INVx1_ASAP7_75t_R    g107(.A(new_n125_), .Y(new_n126_));
  AND3x1_ASAP7_75t_R   g108(.A(\B[5] ), .B(\B[6] ), .C(new_n56_), .Y(new_n127_));
  OR3x1_ASAP7_75t_R    g109(.A(new_n34_), .B(new_n108_), .C(new_n127_), .Y(new_n128_));
  OA211x2_ASAP7_75t_R  g110(.A1(new_n22_), .A2(new_n126_), .B(new_n110_), .C(new_n128_), .Y(new_n129_));
  INVx1_ASAP7_75t_R    g111(.A(new_n129_), .Y(\E[1] ));
  OR5x1_ASAP7_75t_R    g112(.A(\B[7] ), .B(\B[8] ), .C(\B[9] ), .D(\B[10] ), .E(new_n127_), .Y(\E[2] ));
endmodule


