// Benchmark "/home/flynn/workplace/MIGBalance/results_v2/single_output_wide_20261021/original_noncore_epfl/r0_6in_esyn_area-delay_ctrl/ctrl/output_from_egg18/logic" written by ABC on Wed Oct 21 14:28:35 2026

module \/home/flynn/workplace/MIGBalance/results_v2/single_output_wide_20261021/original_noncore_epfl/r0_6in_esyn_area-delay_ctrl/ctrl/output_from_egg18/logic  ( 
    \opcode[1] , \opcode[2] , \opcode[3] , \opcode[4] , \op_ext[0] ,
    \op_ext[1] , \opcode[0] ,
    \sel_reg_dst[0] , \sel_reg_dst[1] , \sel_alu_opB[0] , \sel_alu_opB[1] ,
    \alu_op[0] , \alu_op[1] , \alu_op[2] , \alu_op_ext[0] ,
    \alu_op_ext[1] , \alu_op_ext[2] , \alu_op_ext[3] , halt, reg_write,
    sel_pc_opA, sel_pc_opB, beqz, bnez, bgez, bltz, jump, Cin, invA, invB,
    sign, mem_write, sel_wb  );
  input  \opcode[1] , \opcode[2] , \opcode[3] , \opcode[4] , \op_ext[0] ,
    \op_ext[1] , \opcode[0] ;
  output \sel_reg_dst[0] , \sel_reg_dst[1] , \sel_alu_opB[0] ,
    \sel_alu_opB[1] , \alu_op[0] , \alu_op[1] , \alu_op[2] ,
    \alu_op_ext[0] , \alu_op_ext[1] , \alu_op_ext[2] , \alu_op_ext[3] ,
    halt, reg_write, sel_pc_opA, sel_pc_opB, beqz, bnez, bgez, bltz, jump,
    Cin, invA, invB, sign, mem_write, sel_wb;
  wire new_n34_, new_n35_, new_n36_, new_n37_, new_n38_, new_n39_, new_n40_,
    new_n41_, new_n42_, new_n43_, new_n44_, new_n45_, new_n46_, new_n47_,
    new_n49_, new_n50_, new_n51_, new_n52_, new_n53_, new_n55_, new_n56_,
    new_n58_, new_n59_, new_n61_, new_n62_, new_n63_, new_n64_, new_n65_,
    new_n66_, new_n67_, new_n68_, new_n71_, new_n72_, new_n74_, new_n76_,
    new_n79_, new_n80_, new_n81_, new_n84_, new_n85_, new_n90_, new_n92_,
    new_n96_, new_n97_, new_n99_, new_n101_, new_n103_;
  INVx1_ASAP7_75t_R    g00(.A(\opcode[1] ), .Y(new_n34_));
  INVx1_ASAP7_75t_R    g01(.A(\opcode[2] ), .Y(new_n35_));
  INVx1_ASAP7_75t_R    g02(.A(\opcode[3] ), .Y(new_n36_));
  INVx1_ASAP7_75t_R    g03(.A(\opcode[4] ), .Y(new_n37_));
  INVx1_ASAP7_75t_R    g04(.A(\op_ext[1] ), .Y(new_n38_));
  INVx1_ASAP7_75t_R    g05(.A(\opcode[0] ), .Y(new_n39_));
  NOR2x1_ASAP7_75t_R   g06(.A(\opcode[3] ), .B(\opcode[4] ), .Y(new_n40_));
  INVx1_ASAP7_75t_R    g07(.A(new_n40_), .Y(new_n41_));
  AND3x1_ASAP7_75t_R   g08(.A(new_n36_), .B(new_n37_), .C(\opcode[1] ), .Y(new_n42_));
  NOR2x1_ASAP7_75t_R   g09(.A(new_n36_), .B(new_n37_), .Y(new_n43_));
  INVx1_ASAP7_75t_R    g10(.A(new_n43_), .Y(new_n44_));
  OA21x2_ASAP7_75t_R   g11(.A1(new_n42_), .A2(new_n43_), .B(\opcode[2] ), .Y(new_n45_));
  NOR2x1_ASAP7_75t_R   g12(.A(\opcode[1] ), .B(\opcode[0] ), .Y(new_n46_));
  INVx1_ASAP7_75t_R    g13(.A(new_n46_), .Y(new_n47_));
  AO21x1_ASAP7_75t_R   g14(.A1(new_n43_), .A2(new_n47_), .B(new_n45_), .Y(\sel_reg_dst[0] ));
  AND3x1_ASAP7_75t_R   g15(.A(\opcode[3] ), .B(new_n39_), .C(\opcode[4] ), .Y(new_n49_));
  NOR2x1_ASAP7_75t_R   g16(.A(\opcode[3] ), .B(new_n37_), .Y(new_n50_));
  INVx1_ASAP7_75t_R    g17(.A(new_n50_), .Y(new_n51_));
  OA22x2_ASAP7_75t_R   g18(.A1(\opcode[1] ), .A2(new_n49_), .B1(new_n34_), .B2(new_n50_), .Y(new_n52_));
  AO21x1_ASAP7_75t_R   g19(.A1(\opcode[1] ), .A2(new_n40_), .B(new_n35_), .Y(new_n53_));
  OA21x2_ASAP7_75t_R   g20(.A1(\opcode[2] ), .A2(new_n52_), .B(new_n53_), .Y(\sel_reg_dst[1] ));
  AO21x1_ASAP7_75t_R   g21(.A1(new_n39_), .A2(new_n50_), .B(new_n34_), .Y(new_n55_));
  AO21x1_ASAP7_75t_R   g22(.A1(\opcode[3] ), .A2(new_n37_), .B(new_n55_), .Y(new_n56_));
  OA211x2_ASAP7_75t_R  g23(.A1(\opcode[1] ), .A2(new_n49_), .B(new_n35_), .C(new_n56_), .Y(\sel_alu_opB[0] ));
  NOR2x1_ASAP7_75t_R   g24(.A(\opcode[1] ), .B(\opcode[2] ), .Y(new_n58_));
  INVx1_ASAP7_75t_R    g25(.A(new_n58_), .Y(new_n59_));
  OA222x2_ASAP7_75t_R  g26(.A1(\opcode[3] ), .A2(\opcode[4] ), .B1(new_n36_), .B2(new_n58_), .C1(new_n39_), .C2(new_n44_), .Y(\sel_alu_opB[1] ));
  AO21x1_ASAP7_75t_R   g27(.A1(\opcode[4] ), .A2(new_n38_), .B(new_n36_), .Y(new_n61_));
  INVx1_ASAP7_75t_R    g28(.A(new_n61_), .Y(new_n62_));
  NOR2x1_ASAP7_75t_R   g29(.A(new_n37_), .B(\op_ext[0] ), .Y(new_n63_));
  AO21x1_ASAP7_75t_R   g30(.A1(\op_ext[1] ), .A2(new_n63_), .B(new_n61_), .Y(new_n64_));
  INVx1_ASAP7_75t_R    g31(.A(new_n64_), .Y(new_n65_));
  AO22x1_ASAP7_75t_R   g32(.A1(\opcode[0] ), .A2(new_n65_), .B1(\op_ext[0] ), .B2(new_n49_), .Y(new_n66_));
  AO21x1_ASAP7_75t_R   g33(.A1(\opcode[1] ), .A2(new_n66_), .B(\opcode[2] ), .Y(new_n67_));
  AO21x1_ASAP7_75t_R   g34(.A1(new_n36_), .A2(\opcode[4] ), .B(new_n35_), .Y(new_n68_));
  OA211x2_ASAP7_75t_R  g35(.A1(new_n35_), .A2(\opcode[0] ), .B(new_n68_), .C(new_n67_), .Y(\alu_op[0] ));
  OA211x2_ASAP7_75t_R  g36(.A1(\opcode[2] ), .A2(new_n62_), .B(\opcode[1] ), .C(new_n68_), .Y(\alu_op[1] ));
  AO21x1_ASAP7_75t_R   g37(.A1(\opcode[3] ), .A2(\opcode[4] ), .B(new_n35_), .Y(new_n71_));
  AO21x1_ASAP7_75t_R   g38(.A1(\opcode[1] ), .A2(\opcode[0] ), .B(new_n44_), .Y(new_n72_));
  OA211x2_ASAP7_75t_R  g39(.A1(\opcode[2] ), .A2(new_n72_), .B(new_n41_), .C(new_n71_), .Y(\alu_op[2] ));
  AO21x1_ASAP7_75t_R   g40(.A1(\opcode[0] ), .A2(new_n43_), .B(new_n42_), .Y(new_n74_));
  AO32x1_ASAP7_75t_R   g41(.A1(new_n34_), .A2(new_n35_), .A3(new_n49_), .B1(\opcode[2] ), .B2(new_n74_), .Y(\alu_op_ext[0] ));
  OR2x4_ASAP7_75t_R    g42(.A(\opcode[2] ), .B(new_n55_), .Y(new_n76_));
  OA211x2_ASAP7_75t_R  g43(.A1(new_n40_), .A2(new_n71_), .B(\opcode[1] ), .C(new_n76_), .Y(\alu_op_ext[1] ));
  OA211x2_ASAP7_75t_R  g44(.A1(new_n43_), .A2(new_n59_), .B(new_n53_), .C(new_n76_), .Y(\alu_op_ext[2] ));
  AO21x1_ASAP7_75t_R   g45(.A1(new_n34_), .A2(\opcode[4] ), .B(new_n36_), .Y(new_n79_));
  AO21x1_ASAP7_75t_R   g46(.A1(\opcode[1] ), .A2(new_n39_), .B(new_n51_), .Y(new_n80_));
  AO32x1_ASAP7_75t_R   g47(.A1(new_n35_), .A2(new_n80_), .A3(new_n79_), .B1(\opcode[2] ), .B2(new_n51_), .Y(new_n81_));
  INVx1_ASAP7_75t_R    g48(.A(new_n81_), .Y(\alu_op_ext[3] ));
  AND3x1_ASAP7_75t_R   g49(.A(new_n39_), .B(new_n40_), .C(new_n58_), .Y(halt));
  AO21x1_ASAP7_75t_R   g50(.A1(\opcode[4] ), .A2(new_n47_), .B(\opcode[3] ), .Y(new_n84_));
  AO21x1_ASAP7_75t_R   g51(.A1(\opcode[1] ), .A2(new_n36_), .B(\opcode[4] ), .Y(new_n85_));
  AO22x1_ASAP7_75t_R   g52(.A1(new_n35_), .A2(new_n84_), .B1(\opcode[2] ), .B2(new_n85_), .Y(reg_write));
  AND3x1_ASAP7_75t_R   g53(.A(new_n36_), .B(new_n37_), .C(\opcode[2] ), .Y(jump));
  AND3x1_ASAP7_75t_R   g54(.A(\opcode[2] ), .B(new_n40_), .C(\opcode[0] ), .Y(sel_pc_opA));
  AND3x1_ASAP7_75t_R   g55(.A(\opcode[2] ), .B(new_n39_), .C(new_n40_), .Y(sel_pc_opB));
  AND3x1_ASAP7_75t_R   g56(.A(\opcode[3] ), .B(new_n37_), .C(new_n34_), .Y(new_n90_));
  AND3x1_ASAP7_75t_R   g57(.A(\opcode[2] ), .B(new_n39_), .C(new_n90_), .Y(beqz));
  NAND2x1_ASAP7_75t_R  g58(.A(\opcode[0] ), .B(new_n90_), .Y(new_n92_));
  AND3x1_ASAP7_75t_R   g59(.A(\opcode[0] ), .B(new_n90_), .C(\opcode[2] ), .Y(bnez));
  AND5x1_ASAP7_75t_R   g60(.A(\opcode[3] ), .B(new_n37_), .C(\opcode[2] ), .D(\opcode[1] ), .E(\opcode[0] ), .Y(bgez));
  AND5x1_ASAP7_75t_R   g61(.A(\opcode[3] ), .B(new_n37_), .C(\opcode[2] ), .D(\opcode[1] ), .E(new_n39_), .Y(bltz));
  OR4x2_ASAP7_75t_R    g62(.A(new_n34_), .B(new_n39_), .C(new_n36_), .D(new_n63_), .Y(new_n96_));
  AO32x1_ASAP7_75t_R   g63(.A1(new_n35_), .A2(new_n92_), .A3(new_n96_), .B1(\opcode[2] ), .B2(new_n72_), .Y(new_n97_));
  INVx1_ASAP7_75t_R    g64(.A(new_n97_), .Y(Cin));
  AND5x1_ASAP7_75t_R   g65(.A(\opcode[1] ), .B(\op_ext[0] ), .C(new_n38_), .D(\opcode[3] ), .E(\opcode[4] ), .Y(new_n99_));
  OA211x2_ASAP7_75t_R  g66(.A1(new_n90_), .A2(new_n99_), .B(new_n35_), .C(\opcode[0] ), .Y(invA));
  OR3x1_ASAP7_75t_R    g67(.A(new_n34_), .B(new_n39_), .C(new_n64_), .Y(new_n101_));
  AOI22x1_ASAP7_75t_R  g68(.A1(\opcode[2] ), .A2(new_n72_), .B1(new_n35_), .B2(new_n101_), .Y(invB));
  AO21x1_ASAP7_75t_R   g69(.A1(\opcode[1] ), .A2(\opcode[0] ), .B(new_n46_), .Y(new_n103_));
  AND3x1_ASAP7_75t_R   g70(.A(new_n35_), .B(new_n50_), .C(new_n103_), .Y(mem_write));
  AND5x1_ASAP7_75t_R   g71(.A(new_n36_), .B(\opcode[4] ), .C(new_n34_), .D(new_n35_), .E(\opcode[0] ), .Y(sel_wb));
  assign               sign = 1'b1;
endmodule


