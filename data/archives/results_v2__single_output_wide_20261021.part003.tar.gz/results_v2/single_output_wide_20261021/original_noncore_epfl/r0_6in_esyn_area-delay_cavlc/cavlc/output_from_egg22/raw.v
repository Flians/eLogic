// Benchmark "/home/flynn/workplace/MIGBalance/results_v2/single_output_wide_20261021/original_noncore_epfl/r0_6in_esyn_area-delay_cavlc/cavlc/output_from_egg22/logic" written by ABC on Wed Oct 21 14:23:47 2026

module \/home/flynn/workplace/MIGBalance/results_v2/single_output_wide_20261021/original_noncore_epfl/r0_6in_esyn_area-delay_cavlc/cavlc/output_from_egg22/logic  ( 
    \totalcoeffs[1] , \totalcoeffs[2] , \totalcoeffs[3] , \totalcoeffs[4] ,
    \ctable[0] , \ctable[1] , \ctable[2] , \trailingones[0] ,
    \trailingones[1] , \totalcoeffs[0] ,
    \coeff_token[0] , \coeff_token[1] , \coeff_token[2] , \coeff_token[3] ,
    \coeff_token[4] , \coeff_token[5] , \ctoken_len[0] , \ctoken_len[1] ,
    \ctoken_len[2] , \ctoken_len[3] , \ctoken_len[4]   );
  input  \totalcoeffs[1] , \totalcoeffs[2] , \totalcoeffs[3] ,
    \totalcoeffs[4] , \ctable[0] , \ctable[1] , \ctable[2] ,
    \trailingones[0] , \trailingones[1] , \totalcoeffs[0] ;
  output \coeff_token[0] , \coeff_token[1] , \coeff_token[2] ,
    \coeff_token[3] , \coeff_token[4] , \coeff_token[5] , \ctoken_len[0] ,
    \ctoken_len[1] , \ctoken_len[2] , \ctoken_len[3] , \ctoken_len[4] ;
  wire new_n22_, new_n23_, new_n24_, new_n25_, new_n26_, new_n27_, new_n28_,
    new_n29_, new_n30_, new_n31_, new_n32_, new_n33_, new_n34_, new_n35_,
    new_n36_, new_n37_, new_n38_, new_n39_, new_n40_, new_n41_, new_n42_,
    new_n43_, new_n44_, new_n45_, new_n46_, new_n47_, new_n48_, new_n49_,
    new_n50_, new_n51_, new_n52_, new_n53_, new_n54_, new_n55_, new_n56_,
    new_n57_, new_n58_, new_n59_, new_n60_, new_n61_, new_n62_, new_n63_,
    new_n64_, new_n65_, new_n66_, new_n67_, new_n68_, new_n69_, new_n70_,
    new_n71_, new_n72_, new_n73_, new_n74_, new_n75_, new_n76_, new_n77_,
    new_n78_, new_n79_, new_n80_, new_n81_, new_n82_, new_n83_, new_n84_,
    new_n85_, new_n86_, new_n87_, new_n88_, new_n89_, new_n90_, new_n91_,
    new_n92_, new_n93_, new_n94_, new_n95_, new_n96_, new_n97_, new_n98_,
    new_n99_, new_n100_, new_n101_, new_n103_, new_n104_, new_n105_,
    new_n106_, new_n107_, new_n108_, new_n109_, new_n110_, new_n111_,
    new_n112_, new_n113_, new_n114_, new_n115_, new_n116_, new_n117_,
    new_n118_, new_n119_, new_n120_, new_n121_, new_n122_, new_n123_,
    new_n124_, new_n125_, new_n126_, new_n127_, new_n128_, new_n129_,
    new_n130_, new_n131_, new_n132_, new_n133_, new_n134_, new_n135_,
    new_n136_, new_n137_, new_n138_, new_n139_, new_n140_, new_n141_,
    new_n142_, new_n143_, new_n144_, new_n145_, new_n146_, new_n147_,
    new_n148_, new_n149_, new_n150_, new_n151_, new_n152_, new_n153_,
    new_n154_, new_n155_, new_n156_, new_n157_, new_n158_, new_n159_,
    new_n160_, new_n162_, new_n163_, new_n164_, new_n165_, new_n166_,
    new_n167_, new_n168_, new_n169_, new_n170_, new_n171_, new_n172_,
    new_n173_, new_n174_, new_n175_, new_n176_, new_n177_, new_n178_,
    new_n179_, new_n180_, new_n181_, new_n182_, new_n183_, new_n184_,
    new_n185_, new_n186_, new_n187_, new_n188_, new_n189_, new_n190_,
    new_n191_, new_n192_, new_n193_, new_n194_, new_n195_, new_n196_,
    new_n197_, new_n198_, new_n199_, new_n200_, new_n201_, new_n202_,
    new_n203_, new_n204_, new_n205_, new_n206_, new_n207_, new_n208_,
    new_n209_, new_n210_, new_n211_, new_n212_, new_n213_, new_n214_,
    new_n216_, new_n217_, new_n218_, new_n219_, new_n220_, new_n221_,
    new_n222_, new_n223_, new_n224_, new_n225_, new_n226_, new_n227_,
    new_n228_, new_n229_, new_n230_, new_n231_, new_n232_, new_n233_,
    new_n234_, new_n235_, new_n236_, new_n237_, new_n238_, new_n239_,
    new_n240_, new_n241_, new_n242_, new_n243_, new_n244_, new_n245_,
    new_n246_, new_n247_, new_n248_, new_n249_, new_n250_, new_n251_,
    new_n252_, new_n253_, new_n254_, new_n256_, new_n257_, new_n258_,
    new_n260_, new_n261_, new_n262_, new_n264_, new_n265_, new_n266_,
    new_n267_, new_n268_, new_n269_, new_n270_, new_n271_, new_n272_,
    new_n273_, new_n274_, new_n275_, new_n276_, new_n277_, new_n278_,
    new_n279_, new_n280_, new_n281_, new_n282_, new_n283_, new_n284_,
    new_n285_, new_n286_, new_n287_, new_n288_, new_n289_, new_n290_,
    new_n291_, new_n292_, new_n293_, new_n294_, new_n295_, new_n297_,
    new_n298_, new_n299_, new_n300_, new_n301_, new_n302_, new_n303_,
    new_n304_, new_n305_, new_n306_, new_n307_, new_n308_, new_n309_,
    new_n310_, new_n311_, new_n312_, new_n313_, new_n314_, new_n315_,
    new_n316_, new_n317_, new_n318_, new_n319_, new_n320_, new_n321_,
    new_n322_, new_n323_, new_n324_, new_n325_, new_n326_, new_n327_,
    new_n328_, new_n330_, new_n331_, new_n332_, new_n333_, new_n334_,
    new_n335_, new_n336_, new_n337_, new_n338_, new_n339_, new_n340_,
    new_n341_, new_n342_, new_n343_, new_n344_, new_n345_, new_n346_,
    new_n347_, new_n348_, new_n349_, new_n350_, new_n351_, new_n353_,
    new_n354_, new_n355_, new_n356_, new_n357_, new_n358_, new_n359_,
    new_n360_, new_n361_, new_n362_, new_n363_, new_n364_, new_n365_,
    new_n366_, new_n368_, new_n369_, new_n370_;
  INVx1_ASAP7_75t_R    g000(.A(\totalcoeffs[1] ), .Y(new_n22_));
  INVx1_ASAP7_75t_R    g001(.A(\totalcoeffs[2] ), .Y(new_n23_));
  INVx1_ASAP7_75t_R    g002(.A(\totalcoeffs[3] ), .Y(new_n24_));
  INVx1_ASAP7_75t_R    g003(.A(\totalcoeffs[4] ), .Y(new_n25_));
  INVx1_ASAP7_75t_R    g004(.A(\ctable[0] ), .Y(new_n26_));
  INVx1_ASAP7_75t_R    g005(.A(\ctable[1] ), .Y(new_n27_));
  INVx1_ASAP7_75t_R    g006(.A(\ctable[2] ), .Y(new_n28_));
  INVx1_ASAP7_75t_R    g007(.A(\trailingones[0] ), .Y(new_n29_));
  INVx1_ASAP7_75t_R    g008(.A(\trailingones[1] ), .Y(new_n30_));
  INVx1_ASAP7_75t_R    g009(.A(\totalcoeffs[0] ), .Y(new_n31_));
  NOR2x1_ASAP7_75t_R   g010(.A(\totalcoeffs[1] ), .B(\totalcoeffs[3] ), .Y(new_n32_));
  NOR2x1_ASAP7_75t_R   g011(.A(\totalcoeffs[2] ), .B(\totalcoeffs[0] ), .Y(new_n33_));
  NAND2x1_ASAP7_75t_R  g012(.A(new_n27_), .B(\trailingones[0] ), .Y(new_n34_));
  AND2x2_ASAP7_75t_R   g013(.A(\ctable[0] ), .B(new_n34_), .Y(new_n35_));
  NOR2x1_ASAP7_75t_R   g014(.A(\ctable[1] ), .B(\trailingones[1] ), .Y(new_n36_));
  AO21x1_ASAP7_75t_R   g015(.A1(\totalcoeffs[4] ), .A2(\trailingones[0] ), .B(new_n36_), .Y(new_n37_));
  NOR2x1_ASAP7_75t_R   g016(.A(new_n27_), .B(\trailingones[1] ), .Y(new_n38_));
  AO21x1_ASAP7_75t_R   g017(.A1(\totalcoeffs[4] ), .A2(\trailingones[1] ), .B(new_n38_), .Y(new_n39_));
  NAND2x1_ASAP7_75t_R  g018(.A(\ctable[0] ), .B(\ctable[1] ), .Y(new_n40_));
  AO32x1_ASAP7_75t_R   g019(.A1(new_n29_), .A2(new_n40_), .A3(new_n39_), .B1(new_n35_), .B2(new_n37_), .Y(new_n41_));
  AND5x1_ASAP7_75t_R   g020(.A(new_n23_), .B(new_n31_), .C(new_n28_), .D(new_n32_), .E(new_n41_), .Y(new_n42_));
  NOR2x1_ASAP7_75t_R   g021(.A(\trailingones[1] ), .B(new_n31_), .Y(new_n43_));
  AO21x1_ASAP7_75t_R   g022(.A1(new_n30_), .A2(\totalcoeffs[0] ), .B(\totalcoeffs[2] ), .Y(new_n44_));
  NOR2x1_ASAP7_75t_R   g023(.A(new_n30_), .B(\totalcoeffs[0] ), .Y(new_n45_));
  INVx1_ASAP7_75t_R    g024(.A(new_n45_), .Y(new_n46_));
  NOR2x1_ASAP7_75t_R   g025(.A(new_n22_), .B(new_n45_), .Y(new_n47_));
  AO21x1_ASAP7_75t_R   g026(.A1(new_n24_), .A2(new_n47_), .B(new_n44_), .Y(new_n48_));
  NAND2x1_ASAP7_75t_R  g027(.A(new_n27_), .B(new_n44_), .Y(new_n49_));
  NOR2x1_ASAP7_75t_R   g028(.A(new_n23_), .B(new_n30_), .Y(new_n50_));
  INVx1_ASAP7_75t_R    g029(.A(new_n50_), .Y(new_n51_));
  NOR2x1_ASAP7_75t_R   g030(.A(new_n22_), .B(\trailingones[1] ), .Y(new_n52_));
  INVx1_ASAP7_75t_R    g031(.A(new_n52_), .Y(new_n53_));
  AO21x1_ASAP7_75t_R   g032(.A1(new_n23_), .A2(new_n52_), .B(new_n50_), .Y(new_n54_));
  NOR2x1_ASAP7_75t_R   g033(.A(\totalcoeffs[3] ), .B(\totalcoeffs[0] ), .Y(new_n55_));
  AO33x2_ASAP7_75t_R   g034(.A1(\ctable[0] ), .A2(new_n49_), .A3(new_n48_), .B1(\ctable[1] ), .B2(new_n55_), .B3(new_n54_), .Y(new_n56_));
  NOR2x1_ASAP7_75t_R   g035(.A(new_n23_), .B(\totalcoeffs[3] ), .Y(new_n57_));
  INVx1_ASAP7_75t_R    g036(.A(new_n57_), .Y(new_n58_));
  NOR2x1_ASAP7_75t_R   g037(.A(\totalcoeffs[1] ), .B(new_n30_), .Y(new_n59_));
  NOR2x1_ASAP7_75t_R   g038(.A(new_n22_), .B(\trailingones[0] ), .Y(new_n60_));
  AO21x1_ASAP7_75t_R   g039(.A1(new_n57_), .A2(new_n59_), .B(new_n60_), .Y(new_n61_));
  NOR2x1_ASAP7_75t_R   g040(.A(\totalcoeffs[1] ), .B(\trailingones[1] ), .Y(new_n62_));
  AO21x1_ASAP7_75t_R   g041(.A1(new_n23_), .A2(\ctable[1] ), .B(new_n24_), .Y(new_n63_));
  AO21x1_ASAP7_75t_R   g042(.A1(new_n62_), .A2(new_n63_), .B(new_n50_), .Y(new_n64_));
  AO22x1_ASAP7_75t_R   g043(.A1(new_n31_), .A2(new_n61_), .B1(new_n29_), .B2(new_n64_), .Y(new_n65_));
  AND3x1_ASAP7_75t_R   g044(.A(new_n22_), .B(new_n30_), .C(new_n29_), .Y(new_n66_));
  NOR2x1_ASAP7_75t_R   g045(.A(\totalcoeffs[2] ), .B(\totalcoeffs[3] ), .Y(new_n67_));
  INVx1_ASAP7_75t_R    g046(.A(new_n67_), .Y(new_n68_));
  AO32x1_ASAP7_75t_R   g047(.A1(new_n31_), .A2(new_n67_), .A3(new_n66_), .B1(new_n26_), .B2(new_n65_), .Y(new_n69_));
  AO21x1_ASAP7_75t_R   g048(.A1(new_n33_), .A2(new_n59_), .B(\ctable[0] ), .Y(new_n70_));
  NOR2x1_ASAP7_75t_R   g049(.A(new_n22_), .B(new_n26_), .Y(new_n71_));
  NOR2x1_ASAP7_75t_R   g050(.A(new_n43_), .B(new_n45_), .Y(new_n72_));
  AO32x1_ASAP7_75t_R   g051(.A1(\totalcoeffs[2] ), .A2(new_n71_), .A3(new_n72_), .B1(\ctable[1] ), .B2(new_n70_), .Y(new_n73_));
  AO21x1_ASAP7_75t_R   g052(.A1(\trailingones[1] ), .A2(new_n31_), .B(\totalcoeffs[1] ), .Y(new_n74_));
  AO32x1_ASAP7_75t_R   g053(.A1(new_n22_), .A2(\totalcoeffs[2] ), .A3(new_n43_), .B1(new_n29_), .B2(new_n74_), .Y(new_n75_));
  AO22x1_ASAP7_75t_R   g054(.A1(\trailingones[0] ), .A2(new_n73_), .B1(new_n26_), .B2(new_n75_), .Y(new_n76_));
  AO221x2_ASAP7_75t_R  g055(.A1(\trailingones[0] ), .A2(new_n56_), .B1(\totalcoeffs[3] ), .B2(new_n76_), .C(new_n69_), .Y(new_n77_));
  NOR2x1_ASAP7_75t_R   g056(.A(\totalcoeffs[3] ), .B(\ctable[0] ), .Y(new_n78_));
  INVx1_ASAP7_75t_R    g057(.A(new_n78_), .Y(new_n79_));
  NOR2x1_ASAP7_75t_R   g058(.A(\totalcoeffs[1] ), .B(new_n43_), .Y(new_n80_));
  OA33x2_ASAP7_75t_R   g059(.A1(new_n59_), .A2(new_n79_), .A3(new_n47_), .B1(\ctable[2] ), .B2(new_n52_), .B3(new_n80_), .Y(new_n81_));
  NOR2x1_ASAP7_75t_R   g060(.A(new_n24_), .B(new_n31_), .Y(new_n82_));
  AO21x1_ASAP7_75t_R   g061(.A1(new_n23_), .A2(new_n24_), .B(new_n30_), .Y(new_n83_));
  OA21x2_ASAP7_75t_R   g062(.A1(new_n24_), .A2(new_n31_), .B(new_n83_), .Y(new_n84_));
  NOR2x1_ASAP7_75t_R   g063(.A(new_n22_), .B(new_n23_), .Y(new_n85_));
  OA21x2_ASAP7_75t_R   g064(.A1(\totalcoeffs[2] ), .A2(\ctable[0] ), .B(new_n31_), .Y(new_n86_));
  NOR2x1_ASAP7_75t_R   g065(.A(new_n85_), .B(new_n86_), .Y(new_n87_));
  OA222x2_ASAP7_75t_R  g066(.A1(\totalcoeffs[1] ), .A2(new_n84_), .B1(new_n22_), .B2(\totalcoeffs[3] ), .C1(\trailingones[1] ), .C2(new_n87_), .Y(new_n88_));
  OAI22x1_ASAP7_75t_R  g067(.A1(\totalcoeffs[2] ), .A2(new_n81_), .B1(\ctable[2] ), .B2(new_n88_), .Y(new_n89_));
  NOR2x1_ASAP7_75t_R   g068(.A(\totalcoeffs[1] ), .B(\totalcoeffs[0] ), .Y(new_n90_));
  NOR2x1_ASAP7_75t_R   g069(.A(new_n23_), .B(\trailingones[1] ), .Y(new_n91_));
  INVx1_ASAP7_75t_R    g070(.A(new_n91_), .Y(new_n92_));
  AND3x1_ASAP7_75t_R   g071(.A(new_n26_), .B(\ctable[2] ), .C(\trailingones[0] ), .Y(new_n93_));
  NOR2x1_ASAP7_75t_R   g072(.A(\ctable[0] ), .B(\trailingones[1] ), .Y(new_n94_));
  INVx1_ASAP7_75t_R    g073(.A(new_n94_), .Y(new_n95_));
  OA21x2_ASAP7_75t_R   g074(.A1(new_n22_), .A2(\ctable[2] ), .B(new_n94_), .Y(new_n96_));
  AO21x1_ASAP7_75t_R   g075(.A1(new_n28_), .A2(\trailingones[1] ), .B(new_n93_), .Y(new_n97_));
  AO21x1_ASAP7_75t_R   g076(.A1(\totalcoeffs[1] ), .A2(new_n97_), .B(new_n96_), .Y(new_n98_));
  AO33x2_ASAP7_75t_R   g077(.A1(new_n90_), .A2(new_n91_), .A3(new_n93_), .B1(new_n23_), .B2(\totalcoeffs[0] ), .B3(new_n98_), .Y(new_n99_));
  AO22x1_ASAP7_75t_R   g078(.A1(new_n29_), .A2(new_n89_), .B1(new_n24_), .B2(new_n99_), .Y(new_n100_));
  AO22x1_ASAP7_75t_R   g079(.A1(new_n28_), .A2(new_n77_), .B1(new_n27_), .B2(new_n100_), .Y(new_n101_));
  AO21x1_ASAP7_75t_R   g080(.A1(new_n25_), .A2(new_n101_), .B(new_n42_), .Y(\coeff_token[0] ));
  AND3x1_ASAP7_75t_R   g081(.A(new_n24_), .B(new_n26_), .C(new_n27_), .Y(new_n103_));
  NOR2x1_ASAP7_75t_R   g082(.A(\totalcoeffs[2] ), .B(new_n29_), .Y(new_n104_));
  INVx1_ASAP7_75t_R    g083(.A(new_n104_), .Y(new_n105_));
  AO21x1_ASAP7_75t_R   g084(.A1(\totalcoeffs[1] ), .A2(\totalcoeffs[0] ), .B(new_n44_), .Y(new_n106_));
  AO21x1_ASAP7_75t_R   g085(.A1(new_n22_), .A2(new_n31_), .B(new_n23_), .Y(new_n107_));
  INVx1_ASAP7_75t_R    g086(.A(new_n107_), .Y(new_n108_));
  AO32x1_ASAP7_75t_R   g087(.A1(new_n29_), .A2(new_n107_), .A3(new_n106_), .B1(new_n52_), .B2(new_n104_), .Y(new_n109_));
  AO32x1_ASAP7_75t_R   g088(.A1(\totalcoeffs[2] ), .A2(new_n30_), .A3(new_n90_), .B1(\ctable[2] ), .B2(new_n109_), .Y(new_n110_));
  NOR2x1_ASAP7_75t_R   g089(.A(\totalcoeffs[3] ), .B(\trailingones[0] ), .Y(new_n111_));
  AO21x1_ASAP7_75t_R   g090(.A1(new_n26_), .A2(\trailingones[0] ), .B(new_n111_), .Y(new_n112_));
  NOR2x1_ASAP7_75t_R   g091(.A(\totalcoeffs[2] ), .B(\trailingones[0] ), .Y(new_n113_));
  OR3x1_ASAP7_75t_R    g092(.A(\totalcoeffs[2] ), .B(\trailingones[0] ), .C(new_n26_), .Y(new_n114_));
  INVx1_ASAP7_75t_R    g093(.A(new_n114_), .Y(new_n115_));
  OA21x2_ASAP7_75t_R   g094(.A1(new_n31_), .A2(new_n112_), .B(new_n114_), .Y(new_n116_));
  AO21x1_ASAP7_75t_R   g095(.A1(\totalcoeffs[3] ), .A2(\trailingones[0] ), .B(\totalcoeffs[2] ), .Y(new_n117_));
  INVx1_ASAP7_75t_R    g096(.A(new_n117_), .Y(new_n118_));
  NOR2x1_ASAP7_75t_R   g097(.A(new_n26_), .B(\totalcoeffs[0] ), .Y(new_n119_));
  INVx1_ASAP7_75t_R    g098(.A(new_n119_), .Y(new_n120_));
  NOR2x1_ASAP7_75t_R   g099(.A(\ctable[0] ), .B(new_n31_), .Y(new_n121_));
  INVx1_ASAP7_75t_R    g100(.A(new_n121_), .Y(new_n122_));
  OA211x2_ASAP7_75t_R  g101(.A1(new_n31_), .A2(new_n105_), .B(new_n120_), .C(new_n122_), .Y(new_n123_));
  OA222x2_ASAP7_75t_R  g102(.A1(\totalcoeffs[0] ), .A2(new_n118_), .B1(new_n22_), .B2(new_n123_), .C1(\totalcoeffs[1] ), .C2(new_n116_), .Y(new_n124_));
  INVx1_ASAP7_75t_R    g103(.A(new_n124_), .Y(new_n125_));
  NOR2x1_ASAP7_75t_R   g104(.A(\totalcoeffs[1] ), .B(\trailingones[0] ), .Y(new_n126_));
  INVx1_ASAP7_75t_R    g105(.A(new_n126_), .Y(new_n127_));
  AO32x1_ASAP7_75t_R   g106(.A1(new_n22_), .A2(\trailingones[0] ), .A3(\ctable[1] ), .B1(new_n23_), .B2(new_n127_), .Y(new_n128_));
  AOI22x1_ASAP7_75t_R  g107(.A1(\totalcoeffs[1] ), .A2(\totalcoeffs[0] ), .B1(new_n22_), .B2(new_n27_), .Y(new_n129_));
  NOR2x1_ASAP7_75t_R   g108(.A(new_n29_), .B(\totalcoeffs[0] ), .Y(new_n130_));
  INVx1_ASAP7_75t_R    g109(.A(new_n130_), .Y(new_n131_));
  AO32x1_ASAP7_75t_R   g110(.A1(new_n23_), .A2(new_n131_), .A3(new_n129_), .B1(\totalcoeffs[3] ), .B2(new_n128_), .Y(new_n132_));
  AO221x2_ASAP7_75t_R  g111(.A1(new_n26_), .A2(new_n132_), .B1(new_n27_), .B2(new_n125_), .C(\trailingones[1] ), .Y(new_n133_));
  AND3x1_ASAP7_75t_R   g112(.A(\totalcoeffs[1] ), .B(\totalcoeffs[2] ), .C(\totalcoeffs[3] ), .Y(new_n134_));
  OA21x2_ASAP7_75t_R   g113(.A1(\ctable[0] ), .A2(new_n134_), .B(new_n68_), .Y(new_n135_));
  NAND2x1_ASAP7_75t_R  g114(.A(new_n22_), .B(\totalcoeffs[3] ), .Y(new_n136_));
  AO32x1_ASAP7_75t_R   g115(.A1(new_n22_), .A2(\totalcoeffs[3] ), .A3(new_n113_), .B1(\totalcoeffs[1] ), .B2(\ctable[0] ), .Y(new_n137_));
  AO21x1_ASAP7_75t_R   g116(.A1(\totalcoeffs[0] ), .A2(new_n137_), .B(new_n135_), .Y(new_n138_));
  NOR2x1_ASAP7_75t_R   g117(.A(new_n26_), .B(\trailingones[0] ), .Y(new_n139_));
  AO221x2_ASAP7_75t_R  g118(.A1(new_n134_), .A2(new_n139_), .B1(\ctable[1] ), .B2(new_n138_), .C(new_n30_), .Y(new_n140_));
  AND3x1_ASAP7_75t_R   g119(.A(\trailingones[0] ), .B(\totalcoeffs[0] ), .C(\trailingones[1] ), .Y(new_n141_));
  AO32x1_ASAP7_75t_R   g120(.A1(new_n30_), .A2(new_n31_), .A3(new_n113_), .B1(\totalcoeffs[2] ), .B2(new_n141_), .Y(new_n142_));
  NOR2x1_ASAP7_75t_R   g121(.A(new_n27_), .B(new_n29_), .Y(new_n143_));
  NAND2x1_ASAP7_75t_R  g122(.A(\ctable[1] ), .B(\trailingones[1] ), .Y(new_n144_));
  OA21x2_ASAP7_75t_R   g123(.A1(\ctable[0] ), .A2(new_n29_), .B(new_n144_), .Y(new_n145_));
  OA332x2_ASAP7_75t_R  g124(.A1(new_n27_), .A2(new_n29_), .A3(new_n30_), .B1(\ctable[0] ), .B2(\trailingones[1] ), .B3(\trailingones[0] ), .C1(\totalcoeffs[0] ), .C2(new_n145_), .Y(new_n146_));
  INVx1_ASAP7_75t_R    g125(.A(new_n146_), .Y(new_n147_));
  AOI22x1_ASAP7_75t_R  g126(.A1(\ctable[0] ), .A2(new_n142_), .B1(\totalcoeffs[2] ), .B2(new_n147_), .Y(new_n148_));
  OA33x2_ASAP7_75t_R   g127(.A1(\trailingones[0] ), .A2(new_n30_), .A3(new_n120_), .B1(new_n31_), .B2(new_n143_), .B3(new_n145_), .Y(new_n149_));
  INVx1_ASAP7_75t_R    g128(.A(new_n149_), .Y(new_n150_));
  AO21x1_ASAP7_75t_R   g129(.A1(\ctable[1] ), .A2(new_n31_), .B(\totalcoeffs[2] ), .Y(new_n151_));
  AO32x1_ASAP7_75t_R   g130(.A1(new_n26_), .A2(\trailingones[0] ), .A3(new_n151_), .B1(new_n27_), .B2(new_n29_), .Y(new_n152_));
  AOI22x1_ASAP7_75t_R  g131(.A1(new_n23_), .A2(new_n150_), .B1(new_n30_), .B2(new_n152_), .Y(new_n153_));
  OA222x2_ASAP7_75t_R  g132(.A1(\totalcoeffs[1] ), .A2(new_n148_), .B1(new_n34_), .B2(new_n92_), .C1(new_n22_), .C2(new_n153_), .Y(new_n154_));
  INVx1_ASAP7_75t_R    g133(.A(new_n154_), .Y(new_n155_));
  AO21x1_ASAP7_75t_R   g134(.A1(\totalcoeffs[4] ), .A2(\trailingones[0] ), .B(new_n139_), .Y(new_n156_));
  AO32x1_ASAP7_75t_R   g135(.A1(\ctable[1] ), .A2(\trailingones[1] ), .A3(\totalcoeffs[4] ), .B1(new_n36_), .B2(new_n156_), .Y(new_n157_));
  AND3x1_ASAP7_75t_R   g136(.A(new_n22_), .B(new_n31_), .C(new_n23_), .Y(new_n158_));
  AO32x1_ASAP7_75t_R   g137(.A1(new_n23_), .A2(new_n90_), .A3(new_n157_), .B1(new_n25_), .B2(new_n155_), .Y(new_n159_));
  AO32x1_ASAP7_75t_R   g138(.A1(new_n25_), .A2(new_n140_), .A3(new_n133_), .B1(new_n24_), .B2(new_n159_), .Y(new_n160_));
  AO32x1_ASAP7_75t_R   g139(.A1(new_n25_), .A2(new_n103_), .A3(new_n110_), .B1(new_n28_), .B2(new_n160_), .Y(\coeff_token[1] ));
  NOR2x1_ASAP7_75t_R   g140(.A(new_n29_), .B(new_n30_), .Y(new_n162_));
  INVx1_ASAP7_75t_R    g141(.A(new_n162_), .Y(new_n163_));
  AO21x1_ASAP7_75t_R   g142(.A1(\ctable[2] ), .A2(new_n162_), .B(new_n31_), .Y(new_n164_));
  AO32x1_ASAP7_75t_R   g143(.A1(new_n22_), .A2(new_n29_), .A3(new_n43_), .B1(new_n47_), .B2(new_n164_), .Y(new_n165_));
  NOR2x1_ASAP7_75t_R   g144(.A(\ctable[0] ), .B(\ctable[1] ), .Y(new_n166_));
  AND5x1_ASAP7_75t_R   g145(.A(new_n23_), .B(new_n24_), .C(new_n25_), .D(new_n166_), .E(new_n165_), .Y(new_n167_));
  NOR2x1_ASAP7_75t_R   g146(.A(\trailingones[0] ), .B(\trailingones[1] ), .Y(new_n168_));
  INVx1_ASAP7_75t_R    g147(.A(new_n168_), .Y(new_n169_));
  OR3x1_ASAP7_75t_R    g148(.A(new_n26_), .B(new_n168_), .C(new_n141_), .Y(new_n170_));
  OA211x2_ASAP7_75t_R  g149(.A1(\ctable[0] ), .A2(new_n50_), .B(\totalcoeffs[1] ), .C(new_n170_), .Y(new_n171_));
  AO21x1_ASAP7_75t_R   g150(.A1(\trailingones[0] ), .A2(\trailingones[1] ), .B(new_n168_), .Y(new_n172_));
  INVx1_ASAP7_75t_R    g151(.A(new_n172_), .Y(new_n173_));
  OA21x2_ASAP7_75t_R   g152(.A1(new_n62_), .A2(new_n173_), .B(\totalcoeffs[2] ), .Y(new_n174_));
  OA21x2_ASAP7_75t_R   g153(.A1(new_n171_), .A2(new_n174_), .B(new_n24_), .Y(new_n175_));
  AND2x2_ASAP7_75t_R   g154(.A(\ctable[0] ), .B(new_n136_), .Y(new_n176_));
  OA33x2_ASAP7_75t_R   g155(.A1(\totalcoeffs[1] ), .A2(new_n29_), .A3(new_n83_), .B1(\totalcoeffs[2] ), .B2(new_n169_), .B3(new_n176_), .Y(new_n177_));
  INVx1_ASAP7_75t_R    g156(.A(new_n177_), .Y(new_n178_));
  AO21x1_ASAP7_75t_R   g157(.A1(\totalcoeffs[0] ), .A2(new_n178_), .B(new_n175_), .Y(new_n179_));
  NOR2x1_ASAP7_75t_R   g158(.A(new_n22_), .B(new_n30_), .Y(new_n180_));
  AOI22x1_ASAP7_75t_R  g159(.A1(new_n22_), .A2(\trailingones[0] ), .B1(\totalcoeffs[2] ), .B2(new_n180_), .Y(new_n181_));
  OA222x2_ASAP7_75t_R  g160(.A1(new_n23_), .A2(new_n169_), .B1(new_n29_), .B2(new_n91_), .C1(new_n27_), .C2(new_n181_), .Y(new_n182_));
  INVx1_ASAP7_75t_R    g161(.A(new_n182_), .Y(new_n183_));
  AO21x1_ASAP7_75t_R   g162(.A1(\totalcoeffs[1] ), .A2(\trailingones[1] ), .B(new_n62_), .Y(new_n184_));
  INVx1_ASAP7_75t_R    g163(.A(new_n184_), .Y(new_n185_));
  NOR2x1_ASAP7_75t_R   g164(.A(new_n27_), .B(new_n59_), .Y(new_n186_));
  AO21x1_ASAP7_75t_R   g165(.A1(\totalcoeffs[1] ), .A2(new_n30_), .B(new_n186_), .Y(new_n187_));
  AO32x1_ASAP7_75t_R   g166(.A1(new_n24_), .A2(new_n29_), .A3(new_n184_), .B1(\trailingones[0] ), .B2(new_n187_), .Y(new_n188_));
  AO22x1_ASAP7_75t_R   g167(.A1(\totalcoeffs[3] ), .A2(new_n183_), .B1(new_n23_), .B2(new_n188_), .Y(new_n189_));
  AO32x1_ASAP7_75t_R   g168(.A1(new_n26_), .A2(\totalcoeffs[0] ), .A3(new_n189_), .B1(new_n27_), .B2(new_n179_), .Y(new_n190_));
  OR3x1_ASAP7_75t_R    g169(.A(\totalcoeffs[1] ), .B(\totalcoeffs[3] ), .C(\totalcoeffs[2] ), .Y(new_n191_));
  INVx1_ASAP7_75t_R    g170(.A(new_n191_), .Y(new_n192_));
  NOR2x1_ASAP7_75t_R   g171(.A(new_n27_), .B(\trailingones[0] ), .Y(new_n193_));
  INVx1_ASAP7_75t_R    g172(.A(new_n193_), .Y(new_n194_));
  AO21x1_ASAP7_75t_R   g173(.A1(new_n163_), .A2(new_n194_), .B(\ctable[0] ), .Y(new_n195_));
  AO21x1_ASAP7_75t_R   g174(.A1(new_n192_), .A2(new_n195_), .B(new_n25_), .Y(new_n196_));
  AO21x1_ASAP7_75t_R   g175(.A1(\totalcoeffs[2] ), .A2(new_n26_), .B(new_n24_), .Y(new_n197_));
  AO21x1_ASAP7_75t_R   g176(.A1(new_n23_), .A2(\trailingones[0] ), .B(new_n24_), .Y(new_n198_));
  INVx1_ASAP7_75t_R    g177(.A(new_n198_), .Y(new_n199_));
  AO22x1_ASAP7_75t_R   g178(.A1(\trailingones[0] ), .A2(new_n197_), .B1(\ctable[0] ), .B2(new_n198_), .Y(new_n200_));
  NOR2x1_ASAP7_75t_R   g179(.A(\ctable[0] ), .B(new_n27_), .Y(new_n201_));
  INVx1_ASAP7_75t_R    g180(.A(new_n201_), .Y(new_n202_));
  AO32x1_ASAP7_75t_R   g181(.A1(new_n24_), .A2(new_n201_), .A3(new_n126_), .B1(\totalcoeffs[1] ), .B2(new_n200_), .Y(new_n203_));
  AND3x1_ASAP7_75t_R   g182(.A(new_n24_), .B(\trailingones[1] ), .C(\totalcoeffs[1] ), .Y(new_n204_));
  AO21x1_ASAP7_75t_R   g183(.A1(new_n193_), .A2(new_n204_), .B(\totalcoeffs[4] ), .Y(new_n205_));
  NAND2x1_ASAP7_75t_R  g184(.A(\totalcoeffs[3] ), .B(new_n30_), .Y(new_n206_));
  AO21x1_ASAP7_75t_R   g185(.A1(\totalcoeffs[3] ), .A2(new_n29_), .B(new_n52_), .Y(new_n207_));
  AO21x1_ASAP7_75t_R   g186(.A1(\totalcoeffs[2] ), .A2(new_n34_), .B(new_n22_), .Y(new_n208_));
  AO331x2_ASAP7_75t_R  g187(.A1(new_n27_), .A2(new_n206_), .A3(new_n207_), .B1(\ctable[0] ), .B2(new_n117_), .B3(new_n208_), .C(new_n205_), .Y(new_n209_));
  NAND2x1_ASAP7_75t_R  g188(.A(\totalcoeffs[1] ), .B(\trailingones[0] ), .Y(new_n210_));
  AO21x1_ASAP7_75t_R   g189(.A1(\ctable[1] ), .A2(new_n210_), .B(\trailingones[1] ), .Y(new_n211_));
  AO32x1_ASAP7_75t_R   g190(.A1(new_n22_), .A2(\trailingones[1] ), .A3(new_n29_), .B1(new_n23_), .B2(new_n211_), .Y(new_n212_));
  AO221x2_ASAP7_75t_R  g191(.A1(\totalcoeffs[3] ), .A2(new_n212_), .B1(new_n30_), .B2(new_n203_), .C(new_n209_), .Y(new_n213_));
  AO32x1_ASAP7_75t_R   g192(.A1(new_n31_), .A2(new_n196_), .A3(new_n213_), .B1(new_n25_), .B2(new_n190_), .Y(new_n214_));
  AO21x1_ASAP7_75t_R   g193(.A1(new_n28_), .A2(new_n214_), .B(new_n167_), .Y(\coeff_token[2] ));
  AO21x1_ASAP7_75t_R   g194(.A1(\ctable[0] ), .A2(\ctable[1] ), .B(new_n166_), .Y(new_n216_));
  NOR2x1_ASAP7_75t_R   g195(.A(\totalcoeffs[3] ), .B(new_n25_), .Y(new_n217_));
  AO21x1_ASAP7_75t_R   g196(.A1(\trailingones[0] ), .A2(\trailingones[1] ), .B(\ctable[0] ), .Y(new_n218_));
  INVx1_ASAP7_75t_R    g197(.A(new_n218_), .Y(new_n219_));
  AND5x1_ASAP7_75t_R   g198(.A(new_n22_), .B(new_n23_), .C(new_n217_), .D(new_n218_), .E(new_n216_), .Y(new_n220_));
  OA21x2_ASAP7_75t_R   g199(.A1(new_n27_), .A2(new_n67_), .B(new_n206_), .Y(new_n221_));
  AOI21x1_ASAP7_75t_R  g200(.A1(new_n24_), .A2(new_n194_), .B(new_n35_), .Y(new_n222_));
  AND3x1_ASAP7_75t_R   g201(.A(\ctable[0] ), .B(\trailingones[1] ), .C(\trailingones[0] ), .Y(new_n223_));
  AO32x1_ASAP7_75t_R   g202(.A1(new_n26_), .A2(new_n30_), .A3(new_n29_), .B1(new_n27_), .B2(new_n223_), .Y(new_n224_));
  AOI21x1_ASAP7_75t_R  g203(.A1(\totalcoeffs[2] ), .A2(new_n224_), .B(new_n222_), .Y(new_n225_));
  OA222x2_ASAP7_75t_R  g204(.A1(\totalcoeffs[1] ), .A2(new_n221_), .B1(new_n23_), .B2(new_n202_), .C1(new_n22_), .C2(new_n225_), .Y(new_n226_));
  INVx1_ASAP7_75t_R    g205(.A(new_n226_), .Y(new_n227_));
  AO21x1_ASAP7_75t_R   g206(.A1(new_n25_), .A2(new_n227_), .B(new_n220_), .Y(new_n228_));
  OR3x1_ASAP7_75t_R    g207(.A(\ctable[0] ), .B(new_n27_), .C(\trailingones[1] ), .Y(new_n229_));
  INVx1_ASAP7_75t_R    g208(.A(new_n229_), .Y(new_n230_));
  NAND2x1_ASAP7_75t_R  g209(.A(\totalcoeffs[3] ), .B(new_n27_), .Y(new_n231_));
  AOI21x1_ASAP7_75t_R  g210(.A1(new_n229_), .A2(new_n231_), .B(\trailingones[0] ), .Y(new_n232_));
  AND3x1_ASAP7_75t_R   g211(.A(\totalcoeffs[3] ), .B(new_n27_), .C(\totalcoeffs[2] ), .Y(new_n233_));
  AO21x1_ASAP7_75t_R   g212(.A1(new_n68_), .A2(new_n201_), .B(new_n233_), .Y(new_n234_));
  AO21x1_ASAP7_75t_R   g213(.A1(\trailingones[1] ), .A2(new_n234_), .B(new_n232_), .Y(new_n235_));
  AO21x1_ASAP7_75t_R   g214(.A1(new_n27_), .A2(new_n29_), .B(new_n94_), .Y(new_n236_));
  AO21x1_ASAP7_75t_R   g215(.A1(\ctable[0] ), .A2(\trailingones[1] ), .B(\ctable[1] ), .Y(new_n237_));
  INVx1_ASAP7_75t_R    g216(.A(new_n237_), .Y(new_n238_));
  NOR2x1_ASAP7_75t_R   g217(.A(new_n26_), .B(new_n29_), .Y(new_n239_));
  AO21x1_ASAP7_75t_R   g218(.A1(\ctable[0] ), .A2(\trailingones[0] ), .B(new_n180_), .Y(new_n240_));
  AO22x1_ASAP7_75t_R   g219(.A1(new_n23_), .A2(new_n236_), .B1(new_n238_), .B2(new_n240_), .Y(new_n241_));
  AO32x1_ASAP7_75t_R   g220(.A1(\totalcoeffs[1] ), .A2(\trailingones[0] ), .A3(new_n230_), .B1(\totalcoeffs[3] ), .B2(new_n241_), .Y(new_n242_));
  AO32x1_ASAP7_75t_R   g221(.A1(new_n22_), .A2(new_n27_), .A3(new_n115_), .B1(new_n24_), .B2(new_n201_), .Y(new_n243_));
  NOR2x1_ASAP7_75t_R   g222(.A(\totalcoeffs[2] ), .B(new_n26_), .Y(new_n244_));
  AOI22x1_ASAP7_75t_R  g223(.A1(\trailingones[0] ), .A2(new_n244_), .B1(\totalcoeffs[2] ), .B2(new_n112_), .Y(new_n245_));
  OR3x1_ASAP7_75t_R    g224(.A(\trailingones[0] ), .B(new_n30_), .C(new_n26_), .Y(new_n246_));
  AND2x2_ASAP7_75t_R   g225(.A(new_n24_), .B(new_n246_), .Y(new_n247_));
  NOR2x1_ASAP7_75t_R   g226(.A(new_n24_), .B(\ctable[0] ), .Y(new_n248_));
  OA21x2_ASAP7_75t_R   g227(.A1(new_n24_), .A2(\trailingones[0] ), .B(new_n27_), .Y(new_n249_));
  OA222x2_ASAP7_75t_R  g228(.A1(\totalcoeffs[2] ), .A2(new_n247_), .B1(new_n248_), .B2(new_n249_), .C1(\trailingones[1] ), .C2(new_n245_), .Y(new_n250_));
  INVx1_ASAP7_75t_R    g229(.A(new_n250_), .Y(new_n251_));
  AO22x1_ASAP7_75t_R   g230(.A1(new_n30_), .A2(new_n243_), .B1(\totalcoeffs[1] ), .B2(new_n251_), .Y(new_n252_));
  AO221x2_ASAP7_75t_R  g231(.A1(new_n22_), .A2(new_n235_), .B1(\totalcoeffs[0] ), .B2(new_n252_), .C(new_n242_), .Y(new_n253_));
  AOI22x1_ASAP7_75t_R  g232(.A1(new_n31_), .A2(new_n228_), .B1(new_n25_), .B2(new_n253_), .Y(new_n254_));
  NOR2x1_ASAP7_75t_R   g233(.A(\ctable[2] ), .B(new_n254_), .Y(\coeff_token[3] ));
  AO21x1_ASAP7_75t_R   g234(.A1(\totalcoeffs[3] ), .A2(new_n25_), .B(new_n217_), .Y(new_n256_));
  AOI22x1_ASAP7_75t_R  g235(.A1(new_n25_), .A2(new_n108_), .B1(new_n158_), .B2(new_n256_), .Y(new_n257_));
  OR3x1_ASAP7_75t_R    g236(.A(new_n26_), .B(new_n27_), .C(\ctable[2] ), .Y(new_n258_));
  NOR2x1_ASAP7_75t_R   g237(.A(new_n257_), .B(new_n258_), .Y(\coeff_token[4] ));
  AND3x1_ASAP7_75t_R   g238(.A(new_n24_), .B(\totalcoeffs[4] ), .C(new_n158_), .Y(new_n260_));
  INVx1_ASAP7_75t_R    g239(.A(new_n260_), .Y(new_n261_));
  OR3x1_ASAP7_75t_R    g240(.A(new_n24_), .B(\totalcoeffs[4] ), .C(new_n158_), .Y(new_n262_));
  AOI21x1_ASAP7_75t_R  g241(.A1(new_n261_), .A2(new_n262_), .B(new_n258_), .Y(\coeff_token[5] ));
  AO21x1_ASAP7_75t_R   g242(.A1(\ctable[2] ), .A2(new_n30_), .B(new_n29_), .Y(new_n264_));
  AO32x1_ASAP7_75t_R   g243(.A1(new_n22_), .A2(\totalcoeffs[2] ), .A3(new_n264_), .B1(new_n23_), .B2(new_n52_), .Y(new_n265_));
  AO21x1_ASAP7_75t_R   g244(.A1(\totalcoeffs[1] ), .A2(new_n141_), .B(new_n168_), .Y(new_n266_));
  AO32x1_ASAP7_75t_R   g245(.A1(new_n23_), .A2(\ctable[2] ), .A3(new_n266_), .B1(new_n31_), .B2(new_n265_), .Y(new_n267_));
  NOR2x1_ASAP7_75t_R   g246(.A(new_n23_), .B(\totalcoeffs[0] ), .Y(new_n268_));
  INVx1_ASAP7_75t_R    g247(.A(new_n268_), .Y(new_n269_));
  AO21x1_ASAP7_75t_R   g248(.A1(new_n22_), .A2(new_n26_), .B(new_n23_), .Y(new_n270_));
  AO32x1_ASAP7_75t_R   g249(.A1(\totalcoeffs[1] ), .A2(\trailingones[1] ), .A3(\ctable[0] ), .B1(new_n36_), .B2(new_n270_), .Y(new_n271_));
  AO32x1_ASAP7_75t_R   g250(.A1(\totalcoeffs[2] ), .A2(new_n31_), .A3(new_n95_), .B1(\totalcoeffs[0] ), .B2(new_n271_), .Y(new_n272_));
  AO21x1_ASAP7_75t_R   g251(.A1(\totalcoeffs[2] ), .A2(\trailingones[0] ), .B(new_n113_), .Y(new_n273_));
  AO21x1_ASAP7_75t_R   g252(.A1(\trailingones[1] ), .A2(new_n268_), .B(new_n66_), .Y(new_n274_));
  AO32x1_ASAP7_75t_R   g253(.A1(\ctable[1] ), .A2(new_n172_), .A3(new_n273_), .B1(\ctable[0] ), .B2(new_n274_), .Y(new_n275_));
  AO21x1_ASAP7_75t_R   g254(.A1(\trailingones[0] ), .A2(new_n272_), .B(new_n275_), .Y(new_n276_));
  AO32x1_ASAP7_75t_R   g255(.A1(new_n26_), .A2(new_n27_), .A3(new_n267_), .B1(new_n28_), .B2(new_n276_), .Y(new_n277_));
  AO21x1_ASAP7_75t_R   g256(.A1(\totalcoeffs[2] ), .A2(new_n26_), .B(\ctable[1] ), .Y(new_n278_));
  AO32x1_ASAP7_75t_R   g257(.A1(new_n23_), .A2(\ctable[0] ), .A3(new_n72_), .B1(new_n45_), .B2(new_n278_), .Y(new_n279_));
  AO21x1_ASAP7_75t_R   g258(.A1(new_n29_), .A2(new_n30_), .B(new_n23_), .Y(new_n280_));
  AO21x1_ASAP7_75t_R   g259(.A1(\totalcoeffs[2] ), .A2(new_n169_), .B(new_n141_), .Y(new_n281_));
  AOI22x1_ASAP7_75t_R  g260(.A1(new_n29_), .A2(new_n279_), .B1(\ctable[1] ), .B2(new_n281_), .Y(new_n282_));
  NAND2x1_ASAP7_75t_R  g261(.A(new_n23_), .B(new_n30_), .Y(new_n283_));
  NOR2x1_ASAP7_75t_R   g262(.A(\totalcoeffs[0] ), .B(new_n193_), .Y(new_n284_));
  OA33x2_ASAP7_75t_R   g263(.A1(new_n23_), .A2(new_n29_), .A3(new_n46_), .B1(new_n239_), .B2(new_n283_), .B3(new_n284_), .Y(new_n285_));
  AO32x1_ASAP7_75t_R   g264(.A1(\totalcoeffs[0] ), .A2(new_n143_), .A3(new_n23_), .B1(new_n60_), .B2(new_n269_), .Y(new_n286_));
  OA211x2_ASAP7_75t_R  g265(.A1(\trailingones[0] ), .A2(\totalcoeffs[0] ), .B(new_n52_), .C(new_n122_), .Y(new_n287_));
  AO32x1_ASAP7_75t_R   g266(.A1(new_n27_), .A2(new_n31_), .A3(new_n127_), .B1(\totalcoeffs[1] ), .B2(\totalcoeffs[2] ), .Y(new_n288_));
  AO21x1_ASAP7_75t_R   g267(.A1(new_n29_), .A2(new_n30_), .B(\totalcoeffs[1] ), .Y(new_n289_));
  AO32x1_ASAP7_75t_R   g268(.A1(\totalcoeffs[0] ), .A2(new_n289_), .A3(new_n53_), .B1(new_n185_), .B2(new_n288_), .Y(new_n290_));
  AOI221x1_ASAP7_75t_R g269(.A1(\trailingones[1] ), .A2(new_n286_), .B1(new_n26_), .B2(new_n290_), .C(new_n287_), .Y(new_n291_));
  OA222x2_ASAP7_75t_R  g270(.A1(new_n22_), .A2(new_n282_), .B1(\totalcoeffs[1] ), .B2(new_n285_), .C1(new_n24_), .C2(new_n291_), .Y(new_n292_));
  INVx1_ASAP7_75t_R    g271(.A(new_n292_), .Y(new_n293_));
  AO22x1_ASAP7_75t_R   g272(.A1(new_n24_), .A2(new_n277_), .B1(new_n28_), .B2(new_n293_), .Y(new_n294_));
  AO32x1_ASAP7_75t_R   g273(.A1(\totalcoeffs[4] ), .A2(new_n90_), .A3(new_n67_), .B1(\ctable[0] ), .B2(\ctable[1] ), .Y(new_n295_));
  AOI22x1_ASAP7_75t_R  g274(.A1(new_n25_), .A2(new_n294_), .B1(new_n28_), .B2(new_n295_), .Y(\ctoken_len[0] ));
  AND3x1_ASAP7_75t_R   g275(.A(new_n26_), .B(new_n28_), .C(new_n260_), .Y(new_n297_));
  AND5x1_ASAP7_75t_R   g276(.A(new_n23_), .B(\totalcoeffs[0] ), .C(\trailingones[0] ), .D(\ctable[2] ), .E(new_n30_), .Y(new_n298_));
  AO21x1_ASAP7_75t_R   g277(.A1(new_n173_), .A2(new_n268_), .B(new_n298_), .Y(new_n299_));
  AO32x1_ASAP7_75t_R   g278(.A1(\totalcoeffs[0] ), .A2(new_n51_), .A3(new_n283_), .B1(new_n30_), .B2(new_n119_), .Y(new_n300_));
  AOI22x1_ASAP7_75t_R  g279(.A1(\trailingones[0] ), .A2(new_n300_), .B1(new_n50_), .B2(new_n139_), .Y(new_n301_));
  NOR2x1_ASAP7_75t_R   g280(.A(new_n24_), .B(new_n26_), .Y(new_n302_));
  INVx1_ASAP7_75t_R    g281(.A(new_n302_), .Y(new_n303_));
  AO21x1_ASAP7_75t_R   g282(.A1(\totalcoeffs[2] ), .A2(new_n30_), .B(new_n302_), .Y(new_n304_));
  AOI22x1_ASAP7_75t_R  g283(.A1(new_n31_), .A2(new_n304_), .B1(\totalcoeffs[3] ), .B2(new_n244_), .Y(new_n305_));
  OA222x2_ASAP7_75t_R  g284(.A1(\trailingones[0] ), .A2(new_n305_), .B1(new_n283_), .B2(new_n303_), .C1(\totalcoeffs[3] ), .C2(new_n301_), .Y(new_n306_));
  INVx1_ASAP7_75t_R    g285(.A(new_n306_), .Y(new_n307_));
  AO21x1_ASAP7_75t_R   g286(.A1(\totalcoeffs[2] ), .A2(\totalcoeffs[3] ), .B(new_n172_), .Y(new_n308_));
  OA21x2_ASAP7_75t_R   g287(.A1(\totalcoeffs[2] ), .A2(new_n82_), .B(\ctable[0] ), .Y(new_n309_));
  AO32x1_ASAP7_75t_R   g288(.A1(\totalcoeffs[2] ), .A2(new_n168_), .A3(new_n82_), .B1(new_n308_), .B2(new_n309_), .Y(new_n310_));
  AO32x1_ASAP7_75t_R   g289(.A1(\totalcoeffs[2] ), .A2(\totalcoeffs[3] ), .A3(new_n223_), .B1(new_n22_), .B2(new_n310_), .Y(new_n311_));
  AO21x1_ASAP7_75t_R   g290(.A1(\totalcoeffs[1] ), .A2(new_n307_), .B(new_n311_), .Y(new_n312_));
  OA33x2_ASAP7_75t_R   g291(.A1(new_n27_), .A2(\totalcoeffs[0] ), .A3(new_n173_), .B1(\ctable[1] ), .B2(new_n162_), .B3(new_n44_), .Y(new_n313_));
  OA33x2_ASAP7_75t_R   g292(.A1(new_n27_), .A2(new_n29_), .A3(new_n31_), .B1(\totalcoeffs[2] ), .B2(\trailingones[0] ), .B3(\totalcoeffs[0] ), .Y(new_n314_));
  NOR2x1_ASAP7_75t_R   g293(.A(\ctable[1] ), .B(new_n111_), .Y(new_n315_));
  OA222x2_ASAP7_75t_R  g294(.A1(\trailingones[1] ), .A2(new_n314_), .B1(new_n280_), .B2(new_n315_), .C1(new_n24_), .C2(new_n313_), .Y(new_n316_));
  INVx1_ASAP7_75t_R    g295(.A(new_n316_), .Y(new_n317_));
  AO32x1_ASAP7_75t_R   g296(.A1(\totalcoeffs[3] ), .A2(new_n113_), .A3(new_n38_), .B1(new_n22_), .B2(new_n317_), .Y(new_n318_));
  AOI21x1_ASAP7_75t_R  g297(.A1(\totalcoeffs[0] ), .A2(new_n231_), .B(new_n38_), .Y(new_n319_));
  AOI21x1_ASAP7_75t_R  g298(.A1(new_n29_), .A2(new_n144_), .B(new_n319_), .Y(new_n320_));
  AO32x1_ASAP7_75t_R   g299(.A1(\totalcoeffs[3] ), .A2(new_n27_), .A3(new_n130_), .B1(\ctable[1] ), .B2(new_n29_), .Y(new_n321_));
  AO21x1_ASAP7_75t_R   g300(.A1(\trailingones[1] ), .A2(new_n321_), .B(new_n320_), .Y(new_n322_));
  AO22x1_ASAP7_75t_R   g301(.A1(\trailingones[0] ), .A2(\totalcoeffs[0] ), .B1(\totalcoeffs[3] ), .B2(new_n163_), .Y(new_n323_));
  AO32x1_ASAP7_75t_R   g302(.A1(\trailingones[0] ), .A2(\trailingones[1] ), .A3(new_n24_), .B1(new_n27_), .B2(new_n323_), .Y(new_n324_));
  AO222x2_ASAP7_75t_R  g303(.A1(new_n23_), .A2(new_n322_), .B1(new_n36_), .B2(new_n111_), .C1(\totalcoeffs[2] ), .C2(new_n324_), .Y(new_n325_));
  AO21x1_ASAP7_75t_R   g304(.A1(\totalcoeffs[1] ), .A2(new_n325_), .B(new_n318_), .Y(new_n326_));
  AO22x1_ASAP7_75t_R   g305(.A1(new_n27_), .A2(new_n312_), .B1(new_n26_), .B2(new_n326_), .Y(new_n327_));
  AO32x1_ASAP7_75t_R   g306(.A1(new_n32_), .A2(new_n166_), .A3(new_n299_), .B1(new_n28_), .B2(new_n327_), .Y(new_n328_));
  AOI22x1_ASAP7_75t_R  g307(.A1(new_n27_), .A2(new_n297_), .B1(new_n25_), .B2(new_n328_), .Y(\ctoken_len[1] ));
  AO221x2_ASAP7_75t_R  g308(.A1(\totalcoeffs[1] ), .A2(new_n29_), .B1(\totalcoeffs[0] ), .B2(new_n289_), .C(\ctable[1] ), .Y(new_n330_));
  OR3x1_ASAP7_75t_R    g309(.A(new_n29_), .B(\totalcoeffs[0] ), .C(new_n52_), .Y(new_n331_));
  AO21x1_ASAP7_75t_R   g310(.A1(new_n186_), .A2(new_n331_), .B(\totalcoeffs[2] ), .Y(new_n332_));
  AO21x1_ASAP7_75t_R   g311(.A1(\trailingones[0] ), .A2(new_n31_), .B(\ctable[0] ), .Y(new_n333_));
  AO21x1_ASAP7_75t_R   g312(.A1(\totalcoeffs[1] ), .A2(\ctable[0] ), .B(new_n248_), .Y(new_n334_));
  OA33x2_ASAP7_75t_R   g313(.A1(\totalcoeffs[1] ), .A2(\totalcoeffs[3] ), .A3(new_n122_), .B1(\totalcoeffs[2] ), .B2(new_n55_), .B3(new_n334_), .Y(new_n335_));
  INVx1_ASAP7_75t_R    g314(.A(new_n335_), .Y(new_n336_));
  AO32x1_ASAP7_75t_R   g315(.A1(new_n85_), .A2(new_n303_), .A3(new_n333_), .B1(\trailingones[0] ), .B2(new_n336_), .Y(new_n337_));
  INVx1_ASAP7_75t_R    g316(.A(new_n337_), .Y(new_n338_));
  OA21x2_ASAP7_75t_R   g317(.A1(new_n23_), .A2(\ctable[0] ), .B(new_n303_), .Y(new_n339_));
  OA33x2_ASAP7_75t_R   g318(.A1(new_n22_), .A2(new_n199_), .A3(new_n339_), .B1(new_n105_), .B2(new_n119_), .B3(new_n136_), .Y(new_n340_));
  OA21x2_ASAP7_75t_R   g319(.A1(\totalcoeffs[1] ), .A2(\ctable[0] ), .B(new_n185_), .Y(new_n341_));
  AOI21x1_ASAP7_75t_R  g320(.A1(new_n62_), .A2(new_n244_), .B(new_n204_), .Y(new_n342_));
  AO221x2_ASAP7_75t_R  g321(.A1(new_n22_), .A2(new_n30_), .B1(new_n24_), .B2(\trailingones[1] ), .C(\totalcoeffs[2] ), .Y(new_n343_));
  OA222x2_ASAP7_75t_R  g322(.A1(new_n58_), .A2(new_n341_), .B1(\totalcoeffs[0] ), .B2(new_n342_), .C1(new_n334_), .C2(new_n343_), .Y(new_n344_));
  OA222x2_ASAP7_75t_R  g323(.A1(\trailingones[1] ), .A2(new_n338_), .B1(new_n30_), .B2(new_n340_), .C1(\trailingones[0] ), .C2(new_n344_), .Y(new_n345_));
  INVx1_ASAP7_75t_R    g324(.A(new_n345_), .Y(new_n346_));
  AO32x1_ASAP7_75t_R   g325(.A1(new_n248_), .A2(new_n332_), .A3(new_n330_), .B1(new_n27_), .B2(new_n346_), .Y(new_n347_));
  AO32x1_ASAP7_75t_R   g326(.A1(new_n23_), .A2(\trailingones[0] ), .A3(\totalcoeffs[0] ), .B1(new_n31_), .B2(new_n273_), .Y(new_n348_));
  AO32x1_ASAP7_75t_R   g327(.A1(\trailingones[1] ), .A2(new_n268_), .A3(new_n29_), .B1(new_n30_), .B2(new_n348_), .Y(new_n349_));
  AO32x1_ASAP7_75t_R   g328(.A1(new_n31_), .A2(new_n113_), .A3(new_n180_), .B1(new_n22_), .B2(new_n349_), .Y(new_n350_));
  AO32x1_ASAP7_75t_R   g329(.A1(new_n27_), .A2(new_n78_), .A3(new_n350_), .B1(new_n28_), .B2(new_n347_), .Y(new_n351_));
  AOI21x1_ASAP7_75t_R  g330(.A1(new_n25_), .A2(new_n351_), .B(new_n297_), .Y(\ctoken_len[2] ));
  AO21x1_ASAP7_75t_R   g331(.A1(\ctable[1] ), .A2(\trailingones[1] ), .B(new_n24_), .Y(new_n353_));
  AO21x1_ASAP7_75t_R   g332(.A1(new_n130_), .A2(new_n237_), .B(new_n353_), .Y(new_n354_));
  OR3x1_ASAP7_75t_R    g333(.A(\totalcoeffs[3] ), .B(new_n25_), .C(new_n166_), .Y(new_n355_));
  AO33x2_ASAP7_75t_R   g334(.A1(new_n57_), .A2(new_n169_), .A3(new_n218_), .B1(new_n23_), .B2(new_n355_), .B3(new_n354_), .Y(new_n356_));
  NAND2x1_ASAP7_75t_R  g335(.A(new_n22_), .B(new_n356_), .Y(new_n357_));
  AO32x1_ASAP7_75t_R   g336(.A1(\trailingones[0] ), .A2(new_n31_), .A3(new_n353_), .B1(new_n24_), .B2(new_n95_), .Y(new_n358_));
  OA21x2_ASAP7_75t_R   g337(.A1(\ctable[1] ), .A2(new_n223_), .B(new_n24_), .Y(new_n359_));
  AO221x2_ASAP7_75t_R  g338(.A1(new_n219_), .A2(new_n233_), .B1(new_n23_), .B2(new_n358_), .C(new_n359_), .Y(new_n360_));
  NAND2x1_ASAP7_75t_R  g339(.A(\totalcoeffs[1] ), .B(new_n360_), .Y(new_n361_));
  AO21x1_ASAP7_75t_R   g340(.A1(new_n28_), .A2(new_n191_), .B(new_n31_), .Y(new_n362_));
  NOR2x1_ASAP7_75t_R   g341(.A(\ctable[0] ), .B(new_n57_), .Y(new_n363_));
  OA222x2_ASAP7_75t_R  g342(.A1(new_n25_), .A2(new_n192_), .B1(new_n28_), .B2(new_n57_), .C1(new_n27_), .C2(new_n363_), .Y(new_n364_));
  AOI21x1_ASAP7_75t_R  g343(.A1(new_n121_), .A2(new_n233_), .B(\ctable[2] ), .Y(new_n365_));
  AO21x1_ASAP7_75t_R   g344(.A1(new_n22_), .A2(new_n169_), .B(new_n365_), .Y(new_n366_));
  AND5x1_ASAP7_75t_R   g345(.A(new_n362_), .B(new_n364_), .C(new_n366_), .D(new_n361_), .E(new_n357_), .Y(\ctoken_len[3] ));
  NOR2x1_ASAP7_75t_R   g346(.A(new_n29_), .B(new_n47_), .Y(new_n368_));
  OR5x1_ASAP7_75t_R    g347(.A(new_n24_), .B(\totalcoeffs[4] ), .C(new_n23_), .D(new_n80_), .E(new_n368_), .Y(new_n369_));
  INVx1_ASAP7_75t_R    g348(.A(new_n369_), .Y(new_n370_));
  OA211x2_ASAP7_75t_R  g349(.A1(new_n260_), .A2(new_n370_), .B(new_n28_), .C(new_n166_), .Y(\ctoken_len[4] ));
endmodule


