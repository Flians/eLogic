// Benchmark "/home/flynn/workplace/MIGBalance/results_v2/single_output_wide_20261021/original_noncore_epfl/r0_6in_esyn_area-delay_cavlc/cavlc/output_from_egg12/logic" written by ABC on Wed Oct 21 14:23:28 2026

module \/home/flynn/workplace/MIGBalance/results_v2/single_output_wide_20261021/original_noncore_epfl/r0_6in_esyn_area-delay_cavlc/cavlc/output_from_egg12/logic  ( 
    \totalcoeffs[1] , \totalcoeffs[2] , \totalcoeffs[3] , \totalcoeffs[4] ,
    \ctable[0] , \ctable[1] , \ctable[2] , \trailingones[0] ,
    \trailingones[1] , \totalcoeffs[0] ,
    \coeff_token[0] , \coeff_token[1] , \coeff_token[2] , \coeff_token[3] ,
    \coeff_token[4] , \coeff_token[5] , \ctoken_len[0] , \ctoken_len[1] ,
    \ctoken_len[2] , \ctoken_len[3] , \ctoken_len[4]   );
  input  \totalcoeffs[1] , \totalcoeffs[2] , \totalcoeffs[3] ,
    \totalcoeffs[4] , \ctable[0] , \ctable[1] , \ctable[2] ,
    \trailingones[0] , \trailingones[1] , \totalcoeffs[0] ;
  output \coeff_token[0] , \coeff_token[1] , \coeff_token[2] ,
    \coeff_token[3] , \coeff_token[4] , \coeff_token[5] , \ctoken_len[0] ,
    \ctoken_len[1] , \ctoken_len[2] , \ctoken_len[3] , \ctoken_len[4] ;
  wire new_n22_, new_n23_, new_n24_, new_n25_, new_n26_, new_n27_, new_n28_,
    new_n29_, new_n30_, new_n31_, new_n32_, new_n33_, new_n34_, new_n35_,
    new_n36_, new_n37_, new_n38_, new_n39_, new_n40_, new_n41_, new_n42_,
    new_n43_, new_n44_, new_n45_, new_n46_, new_n47_, new_n48_, new_n49_,
    new_n50_, new_n51_, new_n52_, new_n53_, new_n54_, new_n55_, new_n56_,
    new_n57_, new_n58_, new_n59_, new_n60_, new_n61_, new_n62_, new_n63_,
    new_n64_, new_n65_, new_n66_, new_n67_, new_n68_, new_n69_, new_n70_,
    new_n71_, new_n72_, new_n73_, new_n74_, new_n75_, new_n76_, new_n77_,
    new_n78_, new_n79_, new_n80_, new_n81_, new_n82_, new_n83_, new_n84_,
    new_n85_, new_n86_, new_n87_, new_n88_, new_n89_, new_n90_, new_n91_,
    new_n92_, new_n93_, new_n94_, new_n95_, new_n96_, new_n97_, new_n98_,
    new_n99_, new_n100_, new_n102_, new_n103_, new_n104_, new_n105_,
    new_n106_, new_n107_, new_n108_, new_n109_, new_n110_, new_n111_,
    new_n112_, new_n113_, new_n114_, new_n115_, new_n116_, new_n117_,
    new_n118_, new_n119_, new_n120_, new_n121_, new_n122_, new_n123_,
    new_n124_, new_n125_, new_n126_, new_n127_, new_n128_, new_n129_,
    new_n130_, new_n131_, new_n132_, new_n133_, new_n134_, new_n135_,
    new_n136_, new_n137_, new_n138_, new_n139_, new_n140_, new_n141_,
    new_n142_, new_n143_, new_n144_, new_n145_, new_n146_, new_n147_,
    new_n148_, new_n149_, new_n150_, new_n151_, new_n152_, new_n153_,
    new_n154_, new_n155_, new_n156_, new_n157_, new_n159_, new_n160_,
    new_n161_, new_n162_, new_n163_, new_n164_, new_n165_, new_n166_,
    new_n167_, new_n168_, new_n169_, new_n170_, new_n171_, new_n172_,
    new_n173_, new_n174_, new_n175_, new_n176_, new_n177_, new_n178_,
    new_n179_, new_n180_, new_n181_, new_n182_, new_n183_, new_n184_,
    new_n185_, new_n186_, new_n187_, new_n188_, new_n189_, new_n190_,
    new_n191_, new_n192_, new_n193_, new_n194_, new_n195_, new_n196_,
    new_n197_, new_n198_, new_n199_, new_n200_, new_n201_, new_n202_,
    new_n203_, new_n204_, new_n205_, new_n206_, new_n207_, new_n208_,
    new_n209_, new_n210_, new_n211_, new_n213_, new_n214_, new_n215_,
    new_n216_, new_n217_, new_n218_, new_n219_, new_n220_, new_n221_,
    new_n222_, new_n223_, new_n224_, new_n225_, new_n226_, new_n227_,
    new_n228_, new_n229_, new_n230_, new_n231_, new_n232_, new_n233_,
    new_n234_, new_n235_, new_n236_, new_n237_, new_n238_, new_n239_,
    new_n240_, new_n241_, new_n242_, new_n243_, new_n244_, new_n245_,
    new_n246_, new_n247_, new_n248_, new_n249_, new_n250_, new_n251_,
    new_n253_, new_n254_, new_n255_, new_n257_, new_n258_, new_n259_,
    new_n261_, new_n262_, new_n263_, new_n264_, new_n265_, new_n266_,
    new_n267_, new_n268_, new_n269_, new_n270_, new_n271_, new_n272_,
    new_n273_, new_n274_, new_n275_, new_n276_, new_n277_, new_n278_,
    new_n279_, new_n280_, new_n281_, new_n282_, new_n283_, new_n284_,
    new_n285_, new_n286_, new_n287_, new_n288_, new_n289_, new_n290_,
    new_n291_, new_n292_, new_n293_, new_n295_, new_n296_, new_n297_,
    new_n298_, new_n299_, new_n300_, new_n301_, new_n302_, new_n303_,
    new_n304_, new_n305_, new_n306_, new_n307_, new_n308_, new_n309_,
    new_n310_, new_n311_, new_n312_, new_n313_, new_n314_, new_n315_,
    new_n316_, new_n317_, new_n318_, new_n319_, new_n320_, new_n321_,
    new_n322_, new_n323_, new_n324_, new_n325_, new_n326_, new_n328_,
    new_n329_, new_n330_, new_n331_, new_n332_, new_n333_, new_n334_,
    new_n335_, new_n336_, new_n337_, new_n338_, new_n339_, new_n340_,
    new_n341_, new_n342_, new_n343_, new_n344_, new_n345_, new_n346_,
    new_n347_, new_n348_, new_n349_, new_n351_, new_n352_, new_n353_,
    new_n354_, new_n355_, new_n356_, new_n357_, new_n358_, new_n359_,
    new_n360_, new_n361_, new_n362_, new_n363_, new_n364_, new_n366_,
    new_n367_, new_n368_;
  INVx1_ASAP7_75t_R    g000(.A(\totalcoeffs[1] ), .Y(new_n22_));
  INVx1_ASAP7_75t_R    g001(.A(\totalcoeffs[2] ), .Y(new_n23_));
  INVx1_ASAP7_75t_R    g002(.A(\totalcoeffs[3] ), .Y(new_n24_));
  INVx1_ASAP7_75t_R    g003(.A(\totalcoeffs[4] ), .Y(new_n25_));
  INVx1_ASAP7_75t_R    g004(.A(\ctable[0] ), .Y(new_n26_));
  INVx1_ASAP7_75t_R    g005(.A(\ctable[1] ), .Y(new_n27_));
  INVx1_ASAP7_75t_R    g006(.A(\ctable[2] ), .Y(new_n28_));
  INVx1_ASAP7_75t_R    g007(.A(\trailingones[0] ), .Y(new_n29_));
  INVx1_ASAP7_75t_R    g008(.A(\trailingones[1] ), .Y(new_n30_));
  INVx1_ASAP7_75t_R    g009(.A(\totalcoeffs[0] ), .Y(new_n31_));
  NOR2x1_ASAP7_75t_R   g010(.A(new_n23_), .B(new_n30_), .Y(new_n32_));
  INVx1_ASAP7_75t_R    g011(.A(new_n32_), .Y(new_n33_));
  NOR2x1_ASAP7_75t_R   g012(.A(new_n22_), .B(\trailingones[1] ), .Y(new_n34_));
  INVx1_ASAP7_75t_R    g013(.A(new_n34_), .Y(new_n35_));
  AO21x1_ASAP7_75t_R   g014(.A1(new_n23_), .A2(new_n34_), .B(new_n32_), .Y(new_n36_));
  NOR2x1_ASAP7_75t_R   g015(.A(\totalcoeffs[3] ), .B(\totalcoeffs[0] ), .Y(new_n37_));
  NOR2x1_ASAP7_75t_R   g016(.A(\trailingones[1] ), .B(new_n31_), .Y(new_n38_));
  AO21x1_ASAP7_75t_R   g017(.A1(new_n30_), .A2(\totalcoeffs[0] ), .B(\totalcoeffs[2] ), .Y(new_n39_));
  NOR2x1_ASAP7_75t_R   g018(.A(new_n30_), .B(\totalcoeffs[0] ), .Y(new_n40_));
  INVx1_ASAP7_75t_R    g019(.A(new_n40_), .Y(new_n41_));
  NOR2x1_ASAP7_75t_R   g020(.A(new_n22_), .B(new_n40_), .Y(new_n42_));
  AO21x1_ASAP7_75t_R   g021(.A1(new_n24_), .A2(new_n42_), .B(new_n39_), .Y(new_n43_));
  NAND2x1_ASAP7_75t_R  g022(.A(new_n27_), .B(new_n39_), .Y(new_n44_));
  AO33x2_ASAP7_75t_R   g023(.A1(\ctable[1] ), .A2(new_n37_), .A3(new_n36_), .B1(\ctable[0] ), .B2(new_n44_), .B3(new_n43_), .Y(new_n45_));
  NOR2x1_ASAP7_75t_R   g024(.A(new_n23_), .B(\totalcoeffs[3] ), .Y(new_n46_));
  INVx1_ASAP7_75t_R    g025(.A(new_n46_), .Y(new_n47_));
  NOR2x1_ASAP7_75t_R   g026(.A(\totalcoeffs[1] ), .B(new_n30_), .Y(new_n48_));
  AO32x1_ASAP7_75t_R   g027(.A1(\totalcoeffs[2] ), .A2(new_n24_), .A3(new_n48_), .B1(\totalcoeffs[1] ), .B2(new_n29_), .Y(new_n49_));
  NOR2x1_ASAP7_75t_R   g028(.A(\totalcoeffs[1] ), .B(\trailingones[1] ), .Y(new_n50_));
  AO21x1_ASAP7_75t_R   g029(.A1(new_n23_), .A2(\ctable[1] ), .B(new_n24_), .Y(new_n51_));
  AO21x1_ASAP7_75t_R   g030(.A1(new_n50_), .A2(new_n51_), .B(new_n32_), .Y(new_n52_));
  AO22x1_ASAP7_75t_R   g031(.A1(new_n31_), .A2(new_n49_), .B1(new_n29_), .B2(new_n52_), .Y(new_n53_));
  AND3x1_ASAP7_75t_R   g032(.A(new_n22_), .B(new_n30_), .C(new_n29_), .Y(new_n54_));
  NOR2x1_ASAP7_75t_R   g033(.A(\totalcoeffs[2] ), .B(\totalcoeffs[3] ), .Y(new_n55_));
  INVx1_ASAP7_75t_R    g034(.A(new_n55_), .Y(new_n56_));
  AO32x1_ASAP7_75t_R   g035(.A1(new_n31_), .A2(new_n55_), .A3(new_n54_), .B1(new_n26_), .B2(new_n53_), .Y(new_n57_));
  NOR2x1_ASAP7_75t_R   g036(.A(\totalcoeffs[2] ), .B(\totalcoeffs[0] ), .Y(new_n58_));
  AO21x1_ASAP7_75t_R   g037(.A1(new_n48_), .A2(new_n58_), .B(\ctable[0] ), .Y(new_n59_));
  NOR2x1_ASAP7_75t_R   g038(.A(new_n38_), .B(new_n40_), .Y(new_n60_));
  NOR2x1_ASAP7_75t_R   g039(.A(new_n22_), .B(new_n26_), .Y(new_n61_));
  AO32x1_ASAP7_75t_R   g040(.A1(\totalcoeffs[2] ), .A2(new_n61_), .A3(new_n60_), .B1(\ctable[1] ), .B2(new_n59_), .Y(new_n62_));
  AO21x1_ASAP7_75t_R   g041(.A1(\trailingones[1] ), .A2(new_n31_), .B(\totalcoeffs[1] ), .Y(new_n63_));
  AO32x1_ASAP7_75t_R   g042(.A1(new_n22_), .A2(\totalcoeffs[2] ), .A3(new_n38_), .B1(new_n29_), .B2(new_n63_), .Y(new_n64_));
  AO22x1_ASAP7_75t_R   g043(.A1(\trailingones[0] ), .A2(new_n62_), .B1(new_n26_), .B2(new_n64_), .Y(new_n65_));
  AO221x2_ASAP7_75t_R  g044(.A1(\trailingones[0] ), .A2(new_n45_), .B1(\totalcoeffs[3] ), .B2(new_n65_), .C(new_n57_), .Y(new_n66_));
  NOR2x1_ASAP7_75t_R   g045(.A(new_n24_), .B(new_n31_), .Y(new_n67_));
  AO21x1_ASAP7_75t_R   g046(.A1(new_n23_), .A2(new_n24_), .B(new_n30_), .Y(new_n68_));
  OA21x2_ASAP7_75t_R   g047(.A1(new_n24_), .A2(new_n31_), .B(new_n68_), .Y(new_n69_));
  NOR2x1_ASAP7_75t_R   g048(.A(new_n22_), .B(new_n23_), .Y(new_n70_));
  OA21x2_ASAP7_75t_R   g049(.A1(\totalcoeffs[2] ), .A2(\ctable[0] ), .B(new_n31_), .Y(new_n71_));
  NOR2x1_ASAP7_75t_R   g050(.A(new_n70_), .B(new_n71_), .Y(new_n72_));
  OA222x2_ASAP7_75t_R  g051(.A1(\totalcoeffs[1] ), .A2(new_n69_), .B1(new_n22_), .B2(\totalcoeffs[3] ), .C1(\trailingones[1] ), .C2(new_n72_), .Y(new_n73_));
  NOR2x1_ASAP7_75t_R   g052(.A(\totalcoeffs[1] ), .B(new_n38_), .Y(new_n74_));
  NOR2x1_ASAP7_75t_R   g053(.A(\totalcoeffs[3] ), .B(\ctable[0] ), .Y(new_n75_));
  INVx1_ASAP7_75t_R    g054(.A(new_n75_), .Y(new_n76_));
  OA33x2_ASAP7_75t_R   g055(.A1(\ctable[2] ), .A2(new_n34_), .A3(new_n74_), .B1(new_n48_), .B2(new_n76_), .B3(new_n42_), .Y(new_n77_));
  OAI22x1_ASAP7_75t_R  g056(.A1(\ctable[2] ), .A2(new_n73_), .B1(\totalcoeffs[2] ), .B2(new_n77_), .Y(new_n78_));
  NOR2x1_ASAP7_75t_R   g057(.A(\ctable[0] ), .B(\trailingones[1] ), .Y(new_n79_));
  INVx1_ASAP7_75t_R    g058(.A(new_n79_), .Y(new_n80_));
  OA21x2_ASAP7_75t_R   g059(.A1(new_n22_), .A2(\ctable[2] ), .B(new_n79_), .Y(new_n81_));
  AND3x1_ASAP7_75t_R   g060(.A(new_n26_), .B(\ctable[2] ), .C(\trailingones[0] ), .Y(new_n82_));
  AO21x1_ASAP7_75t_R   g061(.A1(new_n28_), .A2(\trailingones[1] ), .B(new_n82_), .Y(new_n83_));
  AO21x1_ASAP7_75t_R   g062(.A1(\totalcoeffs[1] ), .A2(new_n83_), .B(new_n81_), .Y(new_n84_));
  NOR2x1_ASAP7_75t_R   g063(.A(\totalcoeffs[1] ), .B(\totalcoeffs[0] ), .Y(new_n85_));
  NOR2x1_ASAP7_75t_R   g064(.A(new_n23_), .B(\trailingones[1] ), .Y(new_n86_));
  INVx1_ASAP7_75t_R    g065(.A(new_n86_), .Y(new_n87_));
  AO33x2_ASAP7_75t_R   g066(.A1(new_n23_), .A2(\totalcoeffs[0] ), .A3(new_n84_), .B1(new_n85_), .B2(new_n86_), .B3(new_n82_), .Y(new_n88_));
  AO22x1_ASAP7_75t_R   g067(.A1(new_n29_), .A2(new_n78_), .B1(new_n24_), .B2(new_n88_), .Y(new_n89_));
  AO22x1_ASAP7_75t_R   g068(.A1(new_n28_), .A2(new_n66_), .B1(new_n27_), .B2(new_n89_), .Y(new_n90_));
  NOR2x1_ASAP7_75t_R   g069(.A(\totalcoeffs[1] ), .B(\totalcoeffs[3] ), .Y(new_n91_));
  NOR2x1_ASAP7_75t_R   g070(.A(\ctable[1] ), .B(\trailingones[1] ), .Y(new_n92_));
  AO21x1_ASAP7_75t_R   g071(.A1(\totalcoeffs[4] ), .A2(\trailingones[0] ), .B(new_n92_), .Y(new_n93_));
  NAND2x1_ASAP7_75t_R  g072(.A(new_n27_), .B(\trailingones[0] ), .Y(new_n94_));
  AND2x2_ASAP7_75t_R   g073(.A(\ctable[0] ), .B(new_n94_), .Y(new_n95_));
  NAND2x1_ASAP7_75t_R  g074(.A(\ctable[0] ), .B(\ctable[1] ), .Y(new_n96_));
  NOR2x1_ASAP7_75t_R   g075(.A(new_n27_), .B(\trailingones[1] ), .Y(new_n97_));
  AO21x1_ASAP7_75t_R   g076(.A1(\totalcoeffs[4] ), .A2(\trailingones[1] ), .B(new_n97_), .Y(new_n98_));
  AO32x1_ASAP7_75t_R   g077(.A1(new_n29_), .A2(new_n96_), .A3(new_n98_), .B1(new_n93_), .B2(new_n95_), .Y(new_n99_));
  AND5x1_ASAP7_75t_R   g078(.A(new_n23_), .B(new_n31_), .C(new_n28_), .D(new_n91_), .E(new_n99_), .Y(new_n100_));
  AO21x1_ASAP7_75t_R   g079(.A1(new_n25_), .A2(new_n90_), .B(new_n100_), .Y(\coeff_token[0] ));
  AND3x1_ASAP7_75t_R   g080(.A(new_n24_), .B(new_n26_), .C(new_n27_), .Y(new_n102_));
  NOR2x1_ASAP7_75t_R   g081(.A(\totalcoeffs[2] ), .B(new_n29_), .Y(new_n103_));
  INVx1_ASAP7_75t_R    g082(.A(new_n103_), .Y(new_n104_));
  AO21x1_ASAP7_75t_R   g083(.A1(new_n22_), .A2(new_n31_), .B(new_n23_), .Y(new_n105_));
  INVx1_ASAP7_75t_R    g084(.A(new_n105_), .Y(new_n106_));
  AO21x1_ASAP7_75t_R   g085(.A1(\totalcoeffs[1] ), .A2(\totalcoeffs[0] ), .B(new_n39_), .Y(new_n107_));
  AO32x1_ASAP7_75t_R   g086(.A1(new_n29_), .A2(new_n105_), .A3(new_n107_), .B1(new_n34_), .B2(new_n103_), .Y(new_n108_));
  AO32x1_ASAP7_75t_R   g087(.A1(\totalcoeffs[2] ), .A2(new_n30_), .A3(new_n85_), .B1(\ctable[2] ), .B2(new_n108_), .Y(new_n109_));
  NAND2x1_ASAP7_75t_R  g088(.A(\ctable[1] ), .B(\trailingones[1] ), .Y(new_n110_));
  OAI21x1_ASAP7_75t_R  g089(.A1(\ctable[0] ), .A2(new_n29_), .B(new_n110_), .Y(new_n111_));
  AO332x2_ASAP7_75t_R  g090(.A1(new_n26_), .A2(new_n30_), .A3(new_n29_), .B1(\ctable[1] ), .B2(\trailingones[0] ), .B3(\trailingones[1] ), .C1(new_n31_), .C2(new_n111_), .Y(new_n112_));
  AND3x1_ASAP7_75t_R   g091(.A(\trailingones[0] ), .B(\totalcoeffs[0] ), .C(\trailingones[1] ), .Y(new_n113_));
  NOR2x1_ASAP7_75t_R   g092(.A(\totalcoeffs[2] ), .B(\trailingones[0] ), .Y(new_n114_));
  AO32x1_ASAP7_75t_R   g093(.A1(new_n30_), .A2(new_n31_), .A3(new_n114_), .B1(\totalcoeffs[2] ), .B2(new_n113_), .Y(new_n115_));
  AOI22x1_ASAP7_75t_R  g094(.A1(\totalcoeffs[2] ), .A2(new_n112_), .B1(\ctable[0] ), .B2(new_n115_), .Y(new_n116_));
  AO21x1_ASAP7_75t_R   g095(.A1(\ctable[1] ), .A2(new_n31_), .B(\totalcoeffs[2] ), .Y(new_n117_));
  AO32x1_ASAP7_75t_R   g096(.A1(new_n26_), .A2(\trailingones[0] ), .A3(new_n117_), .B1(new_n27_), .B2(new_n29_), .Y(new_n118_));
  NOR2x1_ASAP7_75t_R   g097(.A(new_n26_), .B(\totalcoeffs[0] ), .Y(new_n119_));
  INVx1_ASAP7_75t_R    g098(.A(new_n119_), .Y(new_n120_));
  OA21x2_ASAP7_75t_R   g099(.A1(new_n27_), .A2(new_n29_), .B(\totalcoeffs[0] ), .Y(new_n121_));
  AO32x1_ASAP7_75t_R   g100(.A1(new_n29_), .A2(\trailingones[1] ), .A3(new_n119_), .B1(new_n111_), .B2(new_n121_), .Y(new_n122_));
  AOI22x1_ASAP7_75t_R  g101(.A1(new_n30_), .A2(new_n118_), .B1(new_n23_), .B2(new_n122_), .Y(new_n123_));
  OA222x2_ASAP7_75t_R  g102(.A1(new_n87_), .A2(new_n94_), .B1(\totalcoeffs[1] ), .B2(new_n116_), .C1(new_n22_), .C2(new_n123_), .Y(new_n124_));
  INVx1_ASAP7_75t_R    g103(.A(new_n124_), .Y(new_n125_));
  AND3x1_ASAP7_75t_R   g104(.A(new_n22_), .B(new_n31_), .C(new_n23_), .Y(new_n126_));
  NOR2x1_ASAP7_75t_R   g105(.A(new_n26_), .B(\trailingones[0] ), .Y(new_n127_));
  AO21x1_ASAP7_75t_R   g106(.A1(\totalcoeffs[4] ), .A2(\trailingones[0] ), .B(new_n127_), .Y(new_n128_));
  AO32x1_ASAP7_75t_R   g107(.A1(\ctable[1] ), .A2(\trailingones[1] ), .A3(\totalcoeffs[4] ), .B1(new_n92_), .B2(new_n128_), .Y(new_n129_));
  AO32x1_ASAP7_75t_R   g108(.A1(new_n23_), .A2(new_n85_), .A3(new_n129_), .B1(new_n25_), .B2(new_n125_), .Y(new_n130_));
  NAND2x1_ASAP7_75t_R  g109(.A(new_n22_), .B(\totalcoeffs[3] ), .Y(new_n131_));
  AO32x1_ASAP7_75t_R   g110(.A1(new_n22_), .A2(\totalcoeffs[3] ), .A3(new_n114_), .B1(\totalcoeffs[1] ), .B2(\ctable[0] ), .Y(new_n132_));
  AND3x1_ASAP7_75t_R   g111(.A(\totalcoeffs[1] ), .B(\totalcoeffs[2] ), .C(\totalcoeffs[3] ), .Y(new_n133_));
  OA21x2_ASAP7_75t_R   g112(.A1(\ctable[0] ), .A2(new_n133_), .B(new_n56_), .Y(new_n134_));
  AO21x1_ASAP7_75t_R   g113(.A1(\totalcoeffs[0] ), .A2(new_n132_), .B(new_n134_), .Y(new_n135_));
  AO221x2_ASAP7_75t_R  g114(.A1(new_n127_), .A2(new_n133_), .B1(\ctable[1] ), .B2(new_n135_), .C(new_n30_), .Y(new_n136_));
  OR3x1_ASAP7_75t_R    g115(.A(\totalcoeffs[2] ), .B(\trailingones[0] ), .C(new_n26_), .Y(new_n137_));
  INVx1_ASAP7_75t_R    g116(.A(new_n137_), .Y(new_n138_));
  NOR2x1_ASAP7_75t_R   g117(.A(\totalcoeffs[3] ), .B(\trailingones[0] ), .Y(new_n139_));
  AO21x1_ASAP7_75t_R   g118(.A1(new_n26_), .A2(\trailingones[0] ), .B(new_n139_), .Y(new_n140_));
  OA21x2_ASAP7_75t_R   g119(.A1(new_n31_), .A2(new_n140_), .B(new_n137_), .Y(new_n141_));
  NOR2x1_ASAP7_75t_R   g120(.A(\ctable[0] ), .B(new_n31_), .Y(new_n142_));
  INVx1_ASAP7_75t_R    g121(.A(new_n142_), .Y(new_n143_));
  OA211x2_ASAP7_75t_R  g122(.A1(new_n31_), .A2(new_n104_), .B(new_n120_), .C(new_n143_), .Y(new_n144_));
  AO21x1_ASAP7_75t_R   g123(.A1(\totalcoeffs[3] ), .A2(\trailingones[0] ), .B(\totalcoeffs[2] ), .Y(new_n145_));
  INVx1_ASAP7_75t_R    g124(.A(new_n145_), .Y(new_n146_));
  OA222x2_ASAP7_75t_R  g125(.A1(new_n22_), .A2(new_n144_), .B1(\totalcoeffs[0] ), .B2(new_n146_), .C1(\totalcoeffs[1] ), .C2(new_n141_), .Y(new_n147_));
  INVx1_ASAP7_75t_R    g126(.A(new_n147_), .Y(new_n148_));
  NOR2x1_ASAP7_75t_R   g127(.A(new_n29_), .B(\totalcoeffs[0] ), .Y(new_n149_));
  INVx1_ASAP7_75t_R    g128(.A(new_n149_), .Y(new_n150_));
  AOI22x1_ASAP7_75t_R  g129(.A1(\totalcoeffs[1] ), .A2(\totalcoeffs[0] ), .B1(new_n22_), .B2(new_n27_), .Y(new_n151_));
  NOR2x1_ASAP7_75t_R   g130(.A(\totalcoeffs[1] ), .B(\trailingones[0] ), .Y(new_n152_));
  INVx1_ASAP7_75t_R    g131(.A(new_n152_), .Y(new_n153_));
  AO32x1_ASAP7_75t_R   g132(.A1(new_n22_), .A2(\trailingones[0] ), .A3(\ctable[1] ), .B1(new_n23_), .B2(new_n153_), .Y(new_n154_));
  AO32x1_ASAP7_75t_R   g133(.A1(new_n23_), .A2(new_n150_), .A3(new_n151_), .B1(\totalcoeffs[3] ), .B2(new_n154_), .Y(new_n155_));
  AO221x2_ASAP7_75t_R  g134(.A1(new_n26_), .A2(new_n155_), .B1(new_n27_), .B2(new_n148_), .C(\trailingones[1] ), .Y(new_n156_));
  AO32x1_ASAP7_75t_R   g135(.A1(new_n25_), .A2(new_n136_), .A3(new_n156_), .B1(new_n24_), .B2(new_n130_), .Y(new_n157_));
  AO32x1_ASAP7_75t_R   g136(.A1(new_n25_), .A2(new_n102_), .A3(new_n109_), .B1(new_n28_), .B2(new_n157_), .Y(\coeff_token[1] ));
  NOR2x1_ASAP7_75t_R   g137(.A(\ctable[0] ), .B(\ctable[1] ), .Y(new_n159_));
  NOR2x1_ASAP7_75t_R   g138(.A(new_n29_), .B(new_n30_), .Y(new_n160_));
  INVx1_ASAP7_75t_R    g139(.A(new_n160_), .Y(new_n161_));
  AO21x1_ASAP7_75t_R   g140(.A1(\ctable[2] ), .A2(new_n160_), .B(new_n31_), .Y(new_n162_));
  AO32x1_ASAP7_75t_R   g141(.A1(new_n22_), .A2(new_n29_), .A3(new_n38_), .B1(new_n42_), .B2(new_n162_), .Y(new_n163_));
  AND5x1_ASAP7_75t_R   g142(.A(new_n23_), .B(new_n24_), .C(new_n25_), .D(new_n159_), .E(new_n163_), .Y(new_n164_));
  NOR2x1_ASAP7_75t_R   g143(.A(\trailingones[0] ), .B(\trailingones[1] ), .Y(new_n165_));
  INVx1_ASAP7_75t_R    g144(.A(new_n165_), .Y(new_n166_));
  OR3x1_ASAP7_75t_R    g145(.A(new_n26_), .B(new_n165_), .C(new_n113_), .Y(new_n167_));
  OA211x2_ASAP7_75t_R  g146(.A1(\ctable[0] ), .A2(new_n32_), .B(\totalcoeffs[1] ), .C(new_n167_), .Y(new_n168_));
  AO21x1_ASAP7_75t_R   g147(.A1(\trailingones[0] ), .A2(\trailingones[1] ), .B(new_n165_), .Y(new_n169_));
  INVx1_ASAP7_75t_R    g148(.A(new_n169_), .Y(new_n170_));
  OA21x2_ASAP7_75t_R   g149(.A1(new_n50_), .A2(new_n170_), .B(\totalcoeffs[2] ), .Y(new_n171_));
  OA21x2_ASAP7_75t_R   g150(.A1(new_n168_), .A2(new_n171_), .B(new_n24_), .Y(new_n172_));
  AND2x2_ASAP7_75t_R   g151(.A(\ctable[0] ), .B(new_n131_), .Y(new_n173_));
  OA33x2_ASAP7_75t_R   g152(.A1(\totalcoeffs[1] ), .A2(new_n29_), .A3(new_n68_), .B1(\totalcoeffs[2] ), .B2(new_n166_), .B3(new_n173_), .Y(new_n174_));
  INVx1_ASAP7_75t_R    g153(.A(new_n174_), .Y(new_n175_));
  AO21x1_ASAP7_75t_R   g154(.A1(\totalcoeffs[0] ), .A2(new_n175_), .B(new_n172_), .Y(new_n176_));
  NOR2x1_ASAP7_75t_R   g155(.A(new_n27_), .B(new_n48_), .Y(new_n177_));
  AO21x1_ASAP7_75t_R   g156(.A1(\totalcoeffs[1] ), .A2(new_n30_), .B(new_n177_), .Y(new_n178_));
  NOR2x1_ASAP7_75t_R   g157(.A(new_n22_), .B(new_n30_), .Y(new_n179_));
  AO21x1_ASAP7_75t_R   g158(.A1(\totalcoeffs[1] ), .A2(\trailingones[1] ), .B(new_n50_), .Y(new_n180_));
  INVx1_ASAP7_75t_R    g159(.A(new_n180_), .Y(new_n181_));
  AO32x1_ASAP7_75t_R   g160(.A1(new_n24_), .A2(new_n29_), .A3(new_n180_), .B1(\trailingones[0] ), .B2(new_n178_), .Y(new_n182_));
  AOI22x1_ASAP7_75t_R  g161(.A1(new_n22_), .A2(\trailingones[0] ), .B1(\totalcoeffs[2] ), .B2(new_n179_), .Y(new_n183_));
  OA222x2_ASAP7_75t_R  g162(.A1(new_n23_), .A2(new_n166_), .B1(new_n29_), .B2(new_n86_), .C1(new_n27_), .C2(new_n183_), .Y(new_n184_));
  INVx1_ASAP7_75t_R    g163(.A(new_n184_), .Y(new_n185_));
  AO22x1_ASAP7_75t_R   g164(.A1(new_n23_), .A2(new_n182_), .B1(\totalcoeffs[3] ), .B2(new_n185_), .Y(new_n186_));
  AO32x1_ASAP7_75t_R   g165(.A1(new_n26_), .A2(\totalcoeffs[0] ), .A3(new_n186_), .B1(new_n27_), .B2(new_n176_), .Y(new_n187_));
  OR3x1_ASAP7_75t_R    g166(.A(\totalcoeffs[1] ), .B(\totalcoeffs[3] ), .C(\totalcoeffs[2] ), .Y(new_n188_));
  INVx1_ASAP7_75t_R    g167(.A(new_n188_), .Y(new_n189_));
  NOR2x1_ASAP7_75t_R   g168(.A(new_n27_), .B(\trailingones[0] ), .Y(new_n190_));
  INVx1_ASAP7_75t_R    g169(.A(new_n190_), .Y(new_n191_));
  AO21x1_ASAP7_75t_R   g170(.A1(new_n161_), .A2(new_n191_), .B(\ctable[0] ), .Y(new_n192_));
  AO21x1_ASAP7_75t_R   g171(.A1(new_n189_), .A2(new_n192_), .B(new_n25_), .Y(new_n193_));
  AO21x1_ASAP7_75t_R   g172(.A1(new_n23_), .A2(\trailingones[0] ), .B(new_n24_), .Y(new_n194_));
  INVx1_ASAP7_75t_R    g173(.A(new_n194_), .Y(new_n195_));
  AO21x1_ASAP7_75t_R   g174(.A1(\totalcoeffs[2] ), .A2(new_n26_), .B(new_n24_), .Y(new_n196_));
  AO22x1_ASAP7_75t_R   g175(.A1(\ctable[0] ), .A2(new_n194_), .B1(\trailingones[0] ), .B2(new_n196_), .Y(new_n197_));
  NOR2x1_ASAP7_75t_R   g176(.A(\ctable[0] ), .B(new_n27_), .Y(new_n198_));
  INVx1_ASAP7_75t_R    g177(.A(new_n198_), .Y(new_n199_));
  AO32x1_ASAP7_75t_R   g178(.A1(new_n24_), .A2(new_n198_), .A3(new_n152_), .B1(\totalcoeffs[1] ), .B2(new_n197_), .Y(new_n200_));
  NAND2x1_ASAP7_75t_R  g179(.A(\totalcoeffs[3] ), .B(new_n30_), .Y(new_n201_));
  AO21x1_ASAP7_75t_R   g180(.A1(\totalcoeffs[3] ), .A2(new_n29_), .B(new_n34_), .Y(new_n202_));
  AND3x1_ASAP7_75t_R   g181(.A(new_n24_), .B(\trailingones[1] ), .C(\totalcoeffs[1] ), .Y(new_n203_));
  AO21x1_ASAP7_75t_R   g182(.A1(new_n190_), .A2(new_n203_), .B(\totalcoeffs[4] ), .Y(new_n204_));
  AO21x1_ASAP7_75t_R   g183(.A1(\totalcoeffs[2] ), .A2(new_n94_), .B(new_n22_), .Y(new_n205_));
  AO331x2_ASAP7_75t_R  g184(.A1(new_n27_), .A2(new_n201_), .A3(new_n202_), .B1(\ctable[0] ), .B2(new_n145_), .B3(new_n205_), .C(new_n204_), .Y(new_n206_));
  NAND2x1_ASAP7_75t_R  g185(.A(\totalcoeffs[1] ), .B(\trailingones[0] ), .Y(new_n207_));
  AO21x1_ASAP7_75t_R   g186(.A1(\ctable[1] ), .A2(new_n207_), .B(\trailingones[1] ), .Y(new_n208_));
  AO32x1_ASAP7_75t_R   g187(.A1(new_n22_), .A2(\trailingones[1] ), .A3(new_n29_), .B1(new_n23_), .B2(new_n208_), .Y(new_n209_));
  AO221x2_ASAP7_75t_R  g188(.A1(\totalcoeffs[3] ), .A2(new_n209_), .B1(new_n30_), .B2(new_n200_), .C(new_n206_), .Y(new_n210_));
  AO32x1_ASAP7_75t_R   g189(.A1(new_n31_), .A2(new_n193_), .A3(new_n210_), .B1(new_n25_), .B2(new_n187_), .Y(new_n211_));
  AO21x1_ASAP7_75t_R   g190(.A1(new_n28_), .A2(new_n211_), .B(new_n164_), .Y(\coeff_token[2] ));
  AO32x1_ASAP7_75t_R   g191(.A1(new_n22_), .A2(new_n27_), .A3(new_n138_), .B1(new_n24_), .B2(new_n198_), .Y(new_n213_));
  NOR2x1_ASAP7_75t_R   g192(.A(new_n24_), .B(\ctable[0] ), .Y(new_n214_));
  OA21x2_ASAP7_75t_R   g193(.A1(new_n24_), .A2(\trailingones[0] ), .B(new_n27_), .Y(new_n215_));
  OR3x1_ASAP7_75t_R    g194(.A(\trailingones[0] ), .B(new_n30_), .C(new_n26_), .Y(new_n216_));
  AND2x2_ASAP7_75t_R   g195(.A(new_n24_), .B(new_n216_), .Y(new_n217_));
  NOR2x1_ASAP7_75t_R   g196(.A(\totalcoeffs[2] ), .B(new_n26_), .Y(new_n218_));
  AOI22x1_ASAP7_75t_R  g197(.A1(\totalcoeffs[2] ), .A2(new_n140_), .B1(\trailingones[0] ), .B2(new_n218_), .Y(new_n219_));
  OA222x2_ASAP7_75t_R  g198(.A1(new_n214_), .A2(new_n215_), .B1(\totalcoeffs[2] ), .B2(new_n217_), .C1(\trailingones[1] ), .C2(new_n219_), .Y(new_n220_));
  INVx1_ASAP7_75t_R    g199(.A(new_n220_), .Y(new_n221_));
  AO22x1_ASAP7_75t_R   g200(.A1(new_n30_), .A2(new_n213_), .B1(\totalcoeffs[1] ), .B2(new_n221_), .Y(new_n222_));
  NAND2x1_ASAP7_75t_R  g201(.A(\totalcoeffs[3] ), .B(new_n27_), .Y(new_n223_));
  OR3x1_ASAP7_75t_R    g202(.A(\ctable[0] ), .B(new_n27_), .C(\trailingones[1] ), .Y(new_n224_));
  INVx1_ASAP7_75t_R    g203(.A(new_n224_), .Y(new_n225_));
  AOI21x1_ASAP7_75t_R  g204(.A1(new_n223_), .A2(new_n224_), .B(\trailingones[0] ), .Y(new_n226_));
  AND3x1_ASAP7_75t_R   g205(.A(\totalcoeffs[3] ), .B(new_n27_), .C(\totalcoeffs[2] ), .Y(new_n227_));
  AO21x1_ASAP7_75t_R   g206(.A1(new_n56_), .A2(new_n198_), .B(new_n227_), .Y(new_n228_));
  AO21x1_ASAP7_75t_R   g207(.A1(\trailingones[1] ), .A2(new_n228_), .B(new_n226_), .Y(new_n229_));
  AO21x1_ASAP7_75t_R   g208(.A1(new_n27_), .A2(new_n29_), .B(new_n79_), .Y(new_n230_));
  NOR2x1_ASAP7_75t_R   g209(.A(new_n26_), .B(new_n29_), .Y(new_n231_));
  AO21x1_ASAP7_75t_R   g210(.A1(\ctable[0] ), .A2(\trailingones[0] ), .B(new_n179_), .Y(new_n232_));
  AO21x1_ASAP7_75t_R   g211(.A1(\ctable[0] ), .A2(\trailingones[1] ), .B(\ctable[1] ), .Y(new_n233_));
  INVx1_ASAP7_75t_R    g212(.A(new_n233_), .Y(new_n234_));
  AO22x1_ASAP7_75t_R   g213(.A1(new_n23_), .A2(new_n230_), .B1(new_n232_), .B2(new_n234_), .Y(new_n235_));
  AO32x1_ASAP7_75t_R   g214(.A1(\totalcoeffs[1] ), .A2(\trailingones[0] ), .A3(new_n225_), .B1(\totalcoeffs[3] ), .B2(new_n235_), .Y(new_n236_));
  AO221x2_ASAP7_75t_R  g215(.A1(new_n22_), .A2(new_n229_), .B1(\totalcoeffs[0] ), .B2(new_n222_), .C(new_n236_), .Y(new_n237_));
  NOR2x1_ASAP7_75t_R   g216(.A(\totalcoeffs[3] ), .B(new_n25_), .Y(new_n238_));
  AO21x1_ASAP7_75t_R   g217(.A1(\trailingones[0] ), .A2(\trailingones[1] ), .B(\ctable[0] ), .Y(new_n239_));
  INVx1_ASAP7_75t_R    g218(.A(new_n239_), .Y(new_n240_));
  AO21x1_ASAP7_75t_R   g219(.A1(\ctable[0] ), .A2(\ctable[1] ), .B(new_n159_), .Y(new_n241_));
  AND5x1_ASAP7_75t_R   g220(.A(new_n22_), .B(new_n23_), .C(new_n238_), .D(new_n239_), .E(new_n241_), .Y(new_n242_));
  OA21x2_ASAP7_75t_R   g221(.A1(new_n27_), .A2(new_n55_), .B(new_n201_), .Y(new_n243_));
  AOI21x1_ASAP7_75t_R  g222(.A1(new_n24_), .A2(new_n191_), .B(new_n95_), .Y(new_n244_));
  AND3x1_ASAP7_75t_R   g223(.A(\ctable[0] ), .B(\trailingones[1] ), .C(\trailingones[0] ), .Y(new_n245_));
  AO32x1_ASAP7_75t_R   g224(.A1(new_n26_), .A2(new_n30_), .A3(new_n29_), .B1(new_n27_), .B2(new_n245_), .Y(new_n246_));
  AOI21x1_ASAP7_75t_R  g225(.A1(\totalcoeffs[2] ), .A2(new_n246_), .B(new_n244_), .Y(new_n247_));
  OA222x2_ASAP7_75t_R  g226(.A1(new_n23_), .A2(new_n199_), .B1(\totalcoeffs[1] ), .B2(new_n243_), .C1(new_n22_), .C2(new_n247_), .Y(new_n248_));
  INVx1_ASAP7_75t_R    g227(.A(new_n248_), .Y(new_n249_));
  AO21x1_ASAP7_75t_R   g228(.A1(new_n25_), .A2(new_n249_), .B(new_n242_), .Y(new_n250_));
  AOI22x1_ASAP7_75t_R  g229(.A1(new_n25_), .A2(new_n237_), .B1(new_n31_), .B2(new_n250_), .Y(new_n251_));
  NOR2x1_ASAP7_75t_R   g230(.A(\ctable[2] ), .B(new_n251_), .Y(\coeff_token[3] ));
  OR3x1_ASAP7_75t_R    g231(.A(new_n26_), .B(new_n27_), .C(\ctable[2] ), .Y(new_n253_));
  AO21x1_ASAP7_75t_R   g232(.A1(\totalcoeffs[3] ), .A2(new_n25_), .B(new_n238_), .Y(new_n254_));
  AOI22x1_ASAP7_75t_R  g233(.A1(new_n126_), .A2(new_n254_), .B1(new_n25_), .B2(new_n106_), .Y(new_n255_));
  NOR2x1_ASAP7_75t_R   g234(.A(new_n253_), .B(new_n255_), .Y(\coeff_token[4] ));
  AND3x1_ASAP7_75t_R   g235(.A(new_n24_), .B(\totalcoeffs[4] ), .C(new_n126_), .Y(new_n257_));
  INVx1_ASAP7_75t_R    g236(.A(new_n257_), .Y(new_n258_));
  OR3x1_ASAP7_75t_R    g237(.A(new_n24_), .B(\totalcoeffs[4] ), .C(new_n126_), .Y(new_n259_));
  AOI21x1_ASAP7_75t_R  g238(.A1(new_n258_), .A2(new_n259_), .B(new_n253_), .Y(\coeff_token[5] ));
  AO21x1_ASAP7_75t_R   g239(.A1(\totalcoeffs[2] ), .A2(new_n26_), .B(\ctable[1] ), .Y(new_n261_));
  AO32x1_ASAP7_75t_R   g240(.A1(new_n23_), .A2(\ctable[0] ), .A3(new_n60_), .B1(new_n40_), .B2(new_n261_), .Y(new_n262_));
  AO21x1_ASAP7_75t_R   g241(.A1(new_n29_), .A2(new_n30_), .B(new_n23_), .Y(new_n263_));
  AO21x1_ASAP7_75t_R   g242(.A1(\totalcoeffs[2] ), .A2(new_n166_), .B(new_n113_), .Y(new_n264_));
  AOI22x1_ASAP7_75t_R  g243(.A1(new_n29_), .A2(new_n262_), .B1(\ctable[1] ), .B2(new_n264_), .Y(new_n265_));
  NOR2x1_ASAP7_75t_R   g244(.A(\totalcoeffs[0] ), .B(new_n190_), .Y(new_n266_));
  NAND2x1_ASAP7_75t_R  g245(.A(new_n23_), .B(new_n30_), .Y(new_n267_));
  OA33x2_ASAP7_75t_R   g246(.A1(new_n231_), .A2(new_n267_), .A3(new_n266_), .B1(new_n23_), .B2(new_n29_), .B3(new_n41_), .Y(new_n268_));
  OA211x2_ASAP7_75t_R  g247(.A1(\trailingones[0] ), .A2(\totalcoeffs[0] ), .B(new_n34_), .C(new_n143_), .Y(new_n269_));
  AND3x1_ASAP7_75t_R   g248(.A(\ctable[1] ), .B(\trailingones[0] ), .C(\totalcoeffs[0] ), .Y(new_n270_));
  NOR2x1_ASAP7_75t_R   g249(.A(new_n23_), .B(\totalcoeffs[0] ), .Y(new_n271_));
  INVx1_ASAP7_75t_R    g250(.A(new_n271_), .Y(new_n272_));
  AO32x1_ASAP7_75t_R   g251(.A1(\totalcoeffs[1] ), .A2(new_n29_), .A3(new_n272_), .B1(new_n23_), .B2(new_n270_), .Y(new_n273_));
  AO21x1_ASAP7_75t_R   g252(.A1(new_n29_), .A2(new_n30_), .B(\totalcoeffs[1] ), .Y(new_n274_));
  AO32x1_ASAP7_75t_R   g253(.A1(new_n27_), .A2(new_n31_), .A3(new_n153_), .B1(\totalcoeffs[1] ), .B2(\totalcoeffs[2] ), .Y(new_n275_));
  AO32x1_ASAP7_75t_R   g254(.A1(\totalcoeffs[0] ), .A2(new_n274_), .A3(new_n35_), .B1(new_n181_), .B2(new_n275_), .Y(new_n276_));
  AOI221x1_ASAP7_75t_R g255(.A1(\trailingones[1] ), .A2(new_n273_), .B1(new_n26_), .B2(new_n276_), .C(new_n269_), .Y(new_n277_));
  OA222x2_ASAP7_75t_R  g256(.A1(new_n22_), .A2(new_n265_), .B1(\totalcoeffs[1] ), .B2(new_n268_), .C1(new_n24_), .C2(new_n277_), .Y(new_n278_));
  INVx1_ASAP7_75t_R    g257(.A(new_n278_), .Y(new_n279_));
  AO21x1_ASAP7_75t_R   g258(.A1(new_n22_), .A2(new_n26_), .B(new_n23_), .Y(new_n280_));
  AO32x1_ASAP7_75t_R   g259(.A1(\totalcoeffs[1] ), .A2(\trailingones[1] ), .A3(\ctable[0] ), .B1(new_n92_), .B2(new_n280_), .Y(new_n281_));
  AO32x1_ASAP7_75t_R   g260(.A1(\totalcoeffs[2] ), .A2(new_n31_), .A3(new_n80_), .B1(\totalcoeffs[0] ), .B2(new_n281_), .Y(new_n282_));
  AO21x1_ASAP7_75t_R   g261(.A1(\totalcoeffs[2] ), .A2(\trailingones[0] ), .B(new_n114_), .Y(new_n283_));
  AO21x1_ASAP7_75t_R   g262(.A1(\trailingones[1] ), .A2(new_n271_), .B(new_n54_), .Y(new_n284_));
  AO32x1_ASAP7_75t_R   g263(.A1(\ctable[1] ), .A2(new_n169_), .A3(new_n283_), .B1(\ctable[0] ), .B2(new_n284_), .Y(new_n285_));
  AO21x1_ASAP7_75t_R   g264(.A1(\trailingones[0] ), .A2(new_n282_), .B(new_n285_), .Y(new_n286_));
  AO21x1_ASAP7_75t_R   g265(.A1(\totalcoeffs[1] ), .A2(new_n113_), .B(new_n165_), .Y(new_n287_));
  AO21x1_ASAP7_75t_R   g266(.A1(\ctable[2] ), .A2(new_n30_), .B(new_n29_), .Y(new_n288_));
  AO32x1_ASAP7_75t_R   g267(.A1(new_n22_), .A2(\totalcoeffs[2] ), .A3(new_n288_), .B1(new_n23_), .B2(new_n34_), .Y(new_n289_));
  AO32x1_ASAP7_75t_R   g268(.A1(new_n23_), .A2(\ctable[2] ), .A3(new_n287_), .B1(new_n31_), .B2(new_n289_), .Y(new_n290_));
  AO32x1_ASAP7_75t_R   g269(.A1(new_n26_), .A2(new_n27_), .A3(new_n290_), .B1(new_n28_), .B2(new_n286_), .Y(new_n291_));
  AO22x1_ASAP7_75t_R   g270(.A1(new_n28_), .A2(new_n279_), .B1(new_n24_), .B2(new_n291_), .Y(new_n292_));
  AO32x1_ASAP7_75t_R   g271(.A1(\totalcoeffs[4] ), .A2(new_n85_), .A3(new_n55_), .B1(\ctable[0] ), .B2(\ctable[1] ), .Y(new_n293_));
  AOI22x1_ASAP7_75t_R  g272(.A1(new_n25_), .A2(new_n292_), .B1(new_n28_), .B2(new_n293_), .Y(\ctoken_len[0] ));
  AND3x1_ASAP7_75t_R   g273(.A(new_n26_), .B(new_n28_), .C(new_n257_), .Y(new_n295_));
  AND5x1_ASAP7_75t_R   g274(.A(new_n23_), .B(\totalcoeffs[0] ), .C(\trailingones[0] ), .D(\ctable[2] ), .E(new_n30_), .Y(new_n296_));
  AO21x1_ASAP7_75t_R   g275(.A1(new_n170_), .A2(new_n271_), .B(new_n296_), .Y(new_n297_));
  NOR2x1_ASAP7_75t_R   g276(.A(new_n24_), .B(new_n26_), .Y(new_n298_));
  INVx1_ASAP7_75t_R    g277(.A(new_n298_), .Y(new_n299_));
  AO21x1_ASAP7_75t_R   g278(.A1(\totalcoeffs[2] ), .A2(new_n30_), .B(new_n298_), .Y(new_n300_));
  AOI22x1_ASAP7_75t_R  g279(.A1(\totalcoeffs[3] ), .A2(new_n218_), .B1(new_n31_), .B2(new_n300_), .Y(new_n301_));
  AO32x1_ASAP7_75t_R   g280(.A1(\totalcoeffs[0] ), .A2(new_n33_), .A3(new_n267_), .B1(new_n30_), .B2(new_n119_), .Y(new_n302_));
  AOI22x1_ASAP7_75t_R  g281(.A1(\trailingones[0] ), .A2(new_n302_), .B1(new_n32_), .B2(new_n127_), .Y(new_n303_));
  OA222x2_ASAP7_75t_R  g282(.A1(new_n267_), .A2(new_n299_), .B1(\trailingones[0] ), .B2(new_n301_), .C1(\totalcoeffs[3] ), .C2(new_n303_), .Y(new_n304_));
  INVx1_ASAP7_75t_R    g283(.A(new_n304_), .Y(new_n305_));
  OA21x2_ASAP7_75t_R   g284(.A1(\totalcoeffs[2] ), .A2(new_n67_), .B(\ctable[0] ), .Y(new_n306_));
  AO21x1_ASAP7_75t_R   g285(.A1(\totalcoeffs[2] ), .A2(\totalcoeffs[3] ), .B(new_n169_), .Y(new_n307_));
  AO32x1_ASAP7_75t_R   g286(.A1(\totalcoeffs[2] ), .A2(new_n165_), .A3(new_n67_), .B1(new_n306_), .B2(new_n307_), .Y(new_n308_));
  AO32x1_ASAP7_75t_R   g287(.A1(\totalcoeffs[2] ), .A2(\totalcoeffs[3] ), .A3(new_n245_), .B1(new_n22_), .B2(new_n308_), .Y(new_n309_));
  AO21x1_ASAP7_75t_R   g288(.A1(\totalcoeffs[1] ), .A2(new_n305_), .B(new_n309_), .Y(new_n310_));
  AOI21x1_ASAP7_75t_R  g289(.A1(new_n31_), .A2(new_n114_), .B(new_n270_), .Y(new_n311_));
  NOR2x1_ASAP7_75t_R   g290(.A(\ctable[1] ), .B(new_n139_), .Y(new_n312_));
  OA33x2_ASAP7_75t_R   g291(.A1(\ctable[1] ), .A2(new_n160_), .A3(new_n39_), .B1(new_n27_), .B2(\totalcoeffs[0] ), .B3(new_n170_), .Y(new_n313_));
  OA222x2_ASAP7_75t_R  g292(.A1(\trailingones[1] ), .A2(new_n311_), .B1(new_n263_), .B2(new_n312_), .C1(new_n24_), .C2(new_n313_), .Y(new_n314_));
  INVx1_ASAP7_75t_R    g293(.A(new_n314_), .Y(new_n315_));
  AO32x1_ASAP7_75t_R   g294(.A1(\totalcoeffs[3] ), .A2(new_n114_), .A3(new_n97_), .B1(new_n22_), .B2(new_n315_), .Y(new_n316_));
  AO22x1_ASAP7_75t_R   g295(.A1(\trailingones[0] ), .A2(\totalcoeffs[0] ), .B1(\totalcoeffs[3] ), .B2(new_n161_), .Y(new_n317_));
  AO32x1_ASAP7_75t_R   g296(.A1(\trailingones[0] ), .A2(\trailingones[1] ), .A3(new_n24_), .B1(new_n27_), .B2(new_n317_), .Y(new_n318_));
  AO32x1_ASAP7_75t_R   g297(.A1(\totalcoeffs[3] ), .A2(new_n27_), .A3(new_n149_), .B1(\ctable[1] ), .B2(new_n29_), .Y(new_n319_));
  AOI21x1_ASAP7_75t_R  g298(.A1(\totalcoeffs[0] ), .A2(new_n223_), .B(new_n97_), .Y(new_n320_));
  AOI21x1_ASAP7_75t_R  g299(.A1(new_n29_), .A2(new_n110_), .B(new_n320_), .Y(new_n321_));
  AO21x1_ASAP7_75t_R   g300(.A1(\trailingones[1] ), .A2(new_n319_), .B(new_n321_), .Y(new_n322_));
  AO222x2_ASAP7_75t_R  g301(.A1(new_n92_), .A2(new_n139_), .B1(new_n23_), .B2(new_n322_), .C1(\totalcoeffs[2] ), .C2(new_n318_), .Y(new_n323_));
  AO21x1_ASAP7_75t_R   g302(.A1(\totalcoeffs[1] ), .A2(new_n323_), .B(new_n316_), .Y(new_n324_));
  AO22x1_ASAP7_75t_R   g303(.A1(new_n27_), .A2(new_n310_), .B1(new_n26_), .B2(new_n324_), .Y(new_n325_));
  AO32x1_ASAP7_75t_R   g304(.A1(new_n91_), .A2(new_n159_), .A3(new_n297_), .B1(new_n28_), .B2(new_n325_), .Y(new_n326_));
  AOI22x1_ASAP7_75t_R  g305(.A1(new_n27_), .A2(new_n295_), .B1(new_n25_), .B2(new_n326_), .Y(\ctoken_len[1] ));
  AO32x1_ASAP7_75t_R   g306(.A1(new_n23_), .A2(\trailingones[0] ), .A3(\totalcoeffs[0] ), .B1(new_n31_), .B2(new_n283_), .Y(new_n328_));
  AO32x1_ASAP7_75t_R   g307(.A1(\trailingones[1] ), .A2(new_n271_), .A3(new_n29_), .B1(new_n30_), .B2(new_n328_), .Y(new_n329_));
  AO32x1_ASAP7_75t_R   g308(.A1(new_n31_), .A2(new_n114_), .A3(new_n179_), .B1(new_n22_), .B2(new_n329_), .Y(new_n330_));
  AOI21x1_ASAP7_75t_R  g309(.A1(new_n50_), .A2(new_n218_), .B(new_n203_), .Y(new_n331_));
  OA21x2_ASAP7_75t_R   g310(.A1(\totalcoeffs[1] ), .A2(\ctable[0] ), .B(new_n181_), .Y(new_n332_));
  AO221x2_ASAP7_75t_R  g311(.A1(new_n22_), .A2(new_n30_), .B1(new_n24_), .B2(\trailingones[1] ), .C(\totalcoeffs[2] ), .Y(new_n333_));
  AO21x1_ASAP7_75t_R   g312(.A1(\totalcoeffs[1] ), .A2(\ctable[0] ), .B(new_n214_), .Y(new_n334_));
  OA222x2_ASAP7_75t_R  g313(.A1(\totalcoeffs[0] ), .A2(new_n331_), .B1(new_n47_), .B2(new_n332_), .C1(new_n333_), .C2(new_n334_), .Y(new_n335_));
  OA21x2_ASAP7_75t_R   g314(.A1(new_n23_), .A2(\ctable[0] ), .B(new_n299_), .Y(new_n336_));
  OA33x2_ASAP7_75t_R   g315(.A1(new_n22_), .A2(new_n195_), .A3(new_n336_), .B1(new_n104_), .B2(new_n119_), .B3(new_n131_), .Y(new_n337_));
  OA33x2_ASAP7_75t_R   g316(.A1(\totalcoeffs[2] ), .A2(new_n37_), .A3(new_n334_), .B1(\totalcoeffs[1] ), .B2(\totalcoeffs[3] ), .B3(new_n143_), .Y(new_n338_));
  INVx1_ASAP7_75t_R    g317(.A(new_n338_), .Y(new_n339_));
  AO21x1_ASAP7_75t_R   g318(.A1(\trailingones[0] ), .A2(new_n31_), .B(\ctable[0] ), .Y(new_n340_));
  AO32x1_ASAP7_75t_R   g319(.A1(new_n70_), .A2(new_n299_), .A3(new_n340_), .B1(\trailingones[0] ), .B2(new_n339_), .Y(new_n341_));
  INVx1_ASAP7_75t_R    g320(.A(new_n341_), .Y(new_n342_));
  OA222x2_ASAP7_75t_R  g321(.A1(new_n30_), .A2(new_n337_), .B1(\trailingones[1] ), .B2(new_n342_), .C1(\trailingones[0] ), .C2(new_n335_), .Y(new_n343_));
  INVx1_ASAP7_75t_R    g322(.A(new_n343_), .Y(new_n344_));
  OR3x1_ASAP7_75t_R    g323(.A(new_n29_), .B(\totalcoeffs[0] ), .C(new_n34_), .Y(new_n345_));
  AO21x1_ASAP7_75t_R   g324(.A1(new_n177_), .A2(new_n345_), .B(\totalcoeffs[2] ), .Y(new_n346_));
  AO221x2_ASAP7_75t_R  g325(.A1(\totalcoeffs[1] ), .A2(new_n29_), .B1(\totalcoeffs[0] ), .B2(new_n274_), .C(\ctable[1] ), .Y(new_n347_));
  AO32x1_ASAP7_75t_R   g326(.A1(new_n214_), .A2(new_n346_), .A3(new_n347_), .B1(new_n27_), .B2(new_n344_), .Y(new_n348_));
  AO32x1_ASAP7_75t_R   g327(.A1(new_n27_), .A2(new_n75_), .A3(new_n330_), .B1(new_n28_), .B2(new_n348_), .Y(new_n349_));
  AOI21x1_ASAP7_75t_R  g328(.A1(new_n25_), .A2(new_n349_), .B(new_n295_), .Y(\ctoken_len[2] ));
  AO21x1_ASAP7_75t_R   g329(.A1(\ctable[1] ), .A2(\trailingones[1] ), .B(new_n24_), .Y(new_n351_));
  AO32x1_ASAP7_75t_R   g330(.A1(\trailingones[0] ), .A2(new_n31_), .A3(new_n351_), .B1(new_n24_), .B2(new_n80_), .Y(new_n352_));
  OA21x2_ASAP7_75t_R   g331(.A1(\ctable[1] ), .A2(new_n245_), .B(new_n24_), .Y(new_n353_));
  AO221x2_ASAP7_75t_R  g332(.A1(new_n227_), .A2(new_n240_), .B1(new_n23_), .B2(new_n352_), .C(new_n353_), .Y(new_n354_));
  NAND2x1_ASAP7_75t_R  g333(.A(\totalcoeffs[1] ), .B(new_n354_), .Y(new_n355_));
  AOI21x1_ASAP7_75t_R  g334(.A1(new_n142_), .A2(new_n227_), .B(\ctable[2] ), .Y(new_n356_));
  AO21x1_ASAP7_75t_R   g335(.A1(new_n22_), .A2(new_n166_), .B(new_n356_), .Y(new_n357_));
  NOR2x1_ASAP7_75t_R   g336(.A(\ctable[0] ), .B(new_n46_), .Y(new_n358_));
  OA222x2_ASAP7_75t_R  g337(.A1(new_n25_), .A2(new_n189_), .B1(new_n28_), .B2(new_n46_), .C1(new_n27_), .C2(new_n358_), .Y(new_n359_));
  AO21x1_ASAP7_75t_R   g338(.A1(new_n28_), .A2(new_n188_), .B(new_n31_), .Y(new_n360_));
  AO21x1_ASAP7_75t_R   g339(.A1(new_n149_), .A2(new_n233_), .B(new_n351_), .Y(new_n361_));
  OR3x1_ASAP7_75t_R    g340(.A(\totalcoeffs[3] ), .B(new_n25_), .C(new_n159_), .Y(new_n362_));
  AO33x2_ASAP7_75t_R   g341(.A1(new_n46_), .A2(new_n166_), .A3(new_n239_), .B1(new_n23_), .B2(new_n362_), .B3(new_n361_), .Y(new_n363_));
  NAND2x1_ASAP7_75t_R  g342(.A(new_n22_), .B(new_n363_), .Y(new_n364_));
  AND5x1_ASAP7_75t_R   g343(.A(new_n359_), .B(new_n360_), .C(new_n357_), .D(new_n355_), .E(new_n364_), .Y(\ctoken_len[3] ));
  NOR2x1_ASAP7_75t_R   g344(.A(new_n29_), .B(new_n42_), .Y(new_n366_));
  OR5x1_ASAP7_75t_R    g345(.A(new_n24_), .B(\totalcoeffs[4] ), .C(new_n23_), .D(new_n74_), .E(new_n366_), .Y(new_n367_));
  INVx1_ASAP7_75t_R    g346(.A(new_n367_), .Y(new_n368_));
  OA211x2_ASAP7_75t_R  g347(.A1(new_n257_), .A2(new_n368_), .B(new_n28_), .C(new_n159_), .Y(\ctoken_len[4] ));
endmodule


