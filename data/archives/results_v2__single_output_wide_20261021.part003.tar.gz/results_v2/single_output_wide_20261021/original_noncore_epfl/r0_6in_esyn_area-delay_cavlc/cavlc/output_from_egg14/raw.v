// Benchmark "/home/flynn/workplace/MIGBalance/results_v2/single_output_wide_20261021/original_noncore_epfl/r0_6in_esyn_area-delay_cavlc/cavlc/output_from_egg14/logic" written by ABC on Wed Oct 21 14:23:32 2026

module \/home/flynn/workplace/MIGBalance/results_v2/single_output_wide_20261021/original_noncore_epfl/r0_6in_esyn_area-delay_cavlc/cavlc/output_from_egg14/logic  ( 
    \totalcoeffs[1] , \totalcoeffs[2] , \totalcoeffs[3] , \totalcoeffs[4] ,
    \ctable[0] , \ctable[1] , \ctable[2] , \trailingones[0] ,
    \trailingones[1] , \totalcoeffs[0] ,
    \coeff_token[0] , \coeff_token[1] , \coeff_token[2] , \coeff_token[3] ,
    \coeff_token[4] , \coeff_token[5] , \ctoken_len[0] , \ctoken_len[1] ,
    \ctoken_len[2] , \ctoken_len[3] , \ctoken_len[4]   );
  input  \totalcoeffs[1] , \totalcoeffs[2] , \totalcoeffs[3] ,
    \totalcoeffs[4] , \ctable[0] , \ctable[1] , \ctable[2] ,
    \trailingones[0] , \trailingones[1] , \totalcoeffs[0] ;
  output \coeff_token[0] , \coeff_token[1] , \coeff_token[2] ,
    \coeff_token[3] , \coeff_token[4] , \coeff_token[5] , \ctoken_len[0] ,
    \ctoken_len[1] , \ctoken_len[2] , \ctoken_len[3] , \ctoken_len[4] ;
  wire new_n22_, new_n23_, new_n24_, new_n25_, new_n26_, new_n27_, new_n28_,
    new_n29_, new_n30_, new_n31_, new_n32_, new_n33_, new_n34_, new_n35_,
    new_n36_, new_n37_, new_n38_, new_n39_, new_n40_, new_n41_, new_n42_,
    new_n43_, new_n44_, new_n45_, new_n46_, new_n47_, new_n48_, new_n49_,
    new_n50_, new_n51_, new_n52_, new_n53_, new_n54_, new_n55_, new_n56_,
    new_n57_, new_n58_, new_n59_, new_n60_, new_n61_, new_n62_, new_n63_,
    new_n64_, new_n65_, new_n66_, new_n67_, new_n68_, new_n69_, new_n70_,
    new_n71_, new_n72_, new_n73_, new_n74_, new_n75_, new_n76_, new_n77_,
    new_n78_, new_n79_, new_n80_, new_n81_, new_n82_, new_n83_, new_n84_,
    new_n85_, new_n86_, new_n87_, new_n88_, new_n89_, new_n90_, new_n91_,
    new_n92_, new_n93_, new_n94_, new_n95_, new_n96_, new_n97_, new_n98_,
    new_n99_, new_n100_, new_n101_, new_n103_, new_n104_, new_n105_,
    new_n106_, new_n107_, new_n108_, new_n109_, new_n110_, new_n111_,
    new_n112_, new_n113_, new_n114_, new_n115_, new_n116_, new_n117_,
    new_n118_, new_n119_, new_n120_, new_n121_, new_n122_, new_n123_,
    new_n124_, new_n125_, new_n126_, new_n127_, new_n128_, new_n129_,
    new_n130_, new_n131_, new_n132_, new_n133_, new_n134_, new_n135_,
    new_n136_, new_n137_, new_n138_, new_n139_, new_n140_, new_n141_,
    new_n142_, new_n143_, new_n144_, new_n145_, new_n146_, new_n147_,
    new_n148_, new_n149_, new_n150_, new_n151_, new_n152_, new_n153_,
    new_n154_, new_n155_, new_n156_, new_n157_, new_n158_, new_n159_,
    new_n160_, new_n161_, new_n163_, new_n164_, new_n165_, new_n166_,
    new_n167_, new_n168_, new_n169_, new_n170_, new_n171_, new_n172_,
    new_n173_, new_n174_, new_n175_, new_n176_, new_n177_, new_n178_,
    new_n179_, new_n180_, new_n181_, new_n182_, new_n183_, new_n184_,
    new_n185_, new_n186_, new_n187_, new_n188_, new_n189_, new_n190_,
    new_n191_, new_n192_, new_n193_, new_n194_, new_n195_, new_n196_,
    new_n197_, new_n198_, new_n199_, new_n200_, new_n201_, new_n202_,
    new_n203_, new_n204_, new_n205_, new_n206_, new_n207_, new_n208_,
    new_n209_, new_n210_, new_n211_, new_n212_, new_n213_, new_n214_,
    new_n215_, new_n217_, new_n218_, new_n219_, new_n220_, new_n221_,
    new_n222_, new_n223_, new_n224_, new_n225_, new_n226_, new_n227_,
    new_n228_, new_n229_, new_n230_, new_n231_, new_n232_, new_n233_,
    new_n234_, new_n235_, new_n236_, new_n237_, new_n238_, new_n239_,
    new_n240_, new_n241_, new_n242_, new_n243_, new_n244_, new_n245_,
    new_n246_, new_n247_, new_n248_, new_n249_, new_n250_, new_n251_,
    new_n252_, new_n253_, new_n254_, new_n255_, new_n257_, new_n258_,
    new_n259_, new_n261_, new_n262_, new_n263_, new_n265_, new_n266_,
    new_n267_, new_n268_, new_n269_, new_n270_, new_n271_, new_n272_,
    new_n273_, new_n274_, new_n275_, new_n276_, new_n277_, new_n278_,
    new_n279_, new_n280_, new_n281_, new_n282_, new_n283_, new_n284_,
    new_n285_, new_n286_, new_n287_, new_n288_, new_n289_, new_n290_,
    new_n291_, new_n292_, new_n293_, new_n294_, new_n295_, new_n296_,
    new_n297_, new_n299_, new_n300_, new_n301_, new_n302_, new_n303_,
    new_n304_, new_n305_, new_n306_, new_n307_, new_n308_, new_n309_,
    new_n310_, new_n311_, new_n312_, new_n313_, new_n314_, new_n315_,
    new_n316_, new_n317_, new_n318_, new_n319_, new_n320_, new_n321_,
    new_n322_, new_n323_, new_n324_, new_n325_, new_n326_, new_n327_,
    new_n328_, new_n329_, new_n330_, new_n332_, new_n333_, new_n334_,
    new_n335_, new_n336_, new_n337_, new_n338_, new_n339_, new_n340_,
    new_n341_, new_n342_, new_n343_, new_n344_, new_n345_, new_n346_,
    new_n347_, new_n348_, new_n349_, new_n350_, new_n351_, new_n352_,
    new_n353_, new_n355_, new_n356_, new_n357_, new_n358_, new_n359_,
    new_n360_, new_n361_, new_n362_, new_n363_, new_n364_, new_n365_,
    new_n366_, new_n367_, new_n369_, new_n370_, new_n371_;
  INVx1_ASAP7_75t_R    g000(.A(\totalcoeffs[1] ), .Y(new_n22_));
  INVx1_ASAP7_75t_R    g001(.A(\totalcoeffs[2] ), .Y(new_n23_));
  INVx1_ASAP7_75t_R    g002(.A(\totalcoeffs[3] ), .Y(new_n24_));
  INVx1_ASAP7_75t_R    g003(.A(\totalcoeffs[4] ), .Y(new_n25_));
  INVx1_ASAP7_75t_R    g004(.A(\ctable[0] ), .Y(new_n26_));
  INVx1_ASAP7_75t_R    g005(.A(\ctable[1] ), .Y(new_n27_));
  INVx1_ASAP7_75t_R    g006(.A(\ctable[2] ), .Y(new_n28_));
  INVx1_ASAP7_75t_R    g007(.A(\trailingones[0] ), .Y(new_n29_));
  INVx1_ASAP7_75t_R    g008(.A(\trailingones[1] ), .Y(new_n30_));
  INVx1_ASAP7_75t_R    g009(.A(\totalcoeffs[0] ), .Y(new_n31_));
  NOR2x1_ASAP7_75t_R   g010(.A(new_n23_), .B(new_n30_), .Y(new_n32_));
  INVx1_ASAP7_75t_R    g011(.A(new_n32_), .Y(new_n33_));
  NOR2x1_ASAP7_75t_R   g012(.A(new_n22_), .B(\trailingones[1] ), .Y(new_n34_));
  INVx1_ASAP7_75t_R    g013(.A(new_n34_), .Y(new_n35_));
  AO21x1_ASAP7_75t_R   g014(.A1(new_n23_), .A2(new_n34_), .B(new_n32_), .Y(new_n36_));
  NOR2x1_ASAP7_75t_R   g015(.A(\totalcoeffs[3] ), .B(\totalcoeffs[0] ), .Y(new_n37_));
  NOR2x1_ASAP7_75t_R   g016(.A(\trailingones[1] ), .B(new_n31_), .Y(new_n38_));
  AO21x1_ASAP7_75t_R   g017(.A1(new_n30_), .A2(\totalcoeffs[0] ), .B(\totalcoeffs[2] ), .Y(new_n39_));
  NOR2x1_ASAP7_75t_R   g018(.A(new_n30_), .B(\totalcoeffs[0] ), .Y(new_n40_));
  INVx1_ASAP7_75t_R    g019(.A(new_n40_), .Y(new_n41_));
  NOR2x1_ASAP7_75t_R   g020(.A(new_n22_), .B(new_n40_), .Y(new_n42_));
  AO21x1_ASAP7_75t_R   g021(.A1(new_n24_), .A2(new_n42_), .B(new_n39_), .Y(new_n43_));
  NAND2x1_ASAP7_75t_R  g022(.A(new_n27_), .B(new_n39_), .Y(new_n44_));
  AO33x2_ASAP7_75t_R   g023(.A1(\ctable[1] ), .A2(new_n37_), .A3(new_n36_), .B1(\ctable[0] ), .B2(new_n44_), .B3(new_n43_), .Y(new_n45_));
  AO21x1_ASAP7_75t_R   g024(.A1(new_n23_), .A2(\ctable[1] ), .B(new_n24_), .Y(new_n46_));
  NOR2x1_ASAP7_75t_R   g025(.A(\totalcoeffs[1] ), .B(\trailingones[1] ), .Y(new_n47_));
  INVx1_ASAP7_75t_R    g026(.A(new_n47_), .Y(new_n48_));
  AO21x1_ASAP7_75t_R   g027(.A1(new_n46_), .A2(new_n47_), .B(new_n32_), .Y(new_n49_));
  NOR2x1_ASAP7_75t_R   g028(.A(new_n22_), .B(\trailingones[0] ), .Y(new_n50_));
  NOR2x1_ASAP7_75t_R   g029(.A(new_n23_), .B(\totalcoeffs[3] ), .Y(new_n51_));
  INVx1_ASAP7_75t_R    g030(.A(new_n51_), .Y(new_n52_));
  NOR2x1_ASAP7_75t_R   g031(.A(\totalcoeffs[1] ), .B(new_n30_), .Y(new_n53_));
  AO21x1_ASAP7_75t_R   g032(.A1(new_n51_), .A2(new_n53_), .B(new_n50_), .Y(new_n54_));
  AO22x1_ASAP7_75t_R   g033(.A1(new_n29_), .A2(new_n49_), .B1(new_n31_), .B2(new_n54_), .Y(new_n55_));
  AND3x1_ASAP7_75t_R   g034(.A(new_n22_), .B(new_n30_), .C(new_n29_), .Y(new_n56_));
  NOR2x1_ASAP7_75t_R   g035(.A(\totalcoeffs[2] ), .B(\totalcoeffs[3] ), .Y(new_n57_));
  INVx1_ASAP7_75t_R    g036(.A(new_n57_), .Y(new_n58_));
  AO32x1_ASAP7_75t_R   g037(.A1(new_n31_), .A2(new_n57_), .A3(new_n56_), .B1(new_n26_), .B2(new_n55_), .Y(new_n59_));
  AO21x1_ASAP7_75t_R   g038(.A1(\trailingones[1] ), .A2(new_n31_), .B(\totalcoeffs[1] ), .Y(new_n60_));
  AO32x1_ASAP7_75t_R   g039(.A1(new_n22_), .A2(\totalcoeffs[2] ), .A3(new_n38_), .B1(new_n29_), .B2(new_n60_), .Y(new_n61_));
  NOR2x1_ASAP7_75t_R   g040(.A(new_n38_), .B(new_n40_), .Y(new_n62_));
  NOR2x1_ASAP7_75t_R   g041(.A(new_n22_), .B(new_n26_), .Y(new_n63_));
  NOR2x1_ASAP7_75t_R   g042(.A(\totalcoeffs[2] ), .B(\totalcoeffs[0] ), .Y(new_n64_));
  AO21x1_ASAP7_75t_R   g043(.A1(new_n53_), .A2(new_n64_), .B(\ctable[0] ), .Y(new_n65_));
  AO32x1_ASAP7_75t_R   g044(.A1(\totalcoeffs[2] ), .A2(new_n63_), .A3(new_n62_), .B1(\ctable[1] ), .B2(new_n65_), .Y(new_n66_));
  AO22x1_ASAP7_75t_R   g045(.A1(new_n26_), .A2(new_n61_), .B1(\trailingones[0] ), .B2(new_n66_), .Y(new_n67_));
  AO221x2_ASAP7_75t_R  g046(.A1(\trailingones[0] ), .A2(new_n45_), .B1(\totalcoeffs[3] ), .B2(new_n67_), .C(new_n59_), .Y(new_n68_));
  NOR2x1_ASAP7_75t_R   g047(.A(new_n24_), .B(new_n31_), .Y(new_n69_));
  AOI21x1_ASAP7_75t_R  g048(.A1(\trailingones[1] ), .A2(new_n58_), .B(new_n69_), .Y(new_n70_));
  NOR2x1_ASAP7_75t_R   g049(.A(new_n22_), .B(new_n23_), .Y(new_n71_));
  OA21x2_ASAP7_75t_R   g050(.A1(\totalcoeffs[2] ), .A2(\ctable[0] ), .B(new_n31_), .Y(new_n72_));
  NOR2x1_ASAP7_75t_R   g051(.A(new_n71_), .B(new_n72_), .Y(new_n73_));
  OA222x2_ASAP7_75t_R  g052(.A1(\totalcoeffs[1] ), .A2(new_n70_), .B1(new_n22_), .B2(\totalcoeffs[3] ), .C1(\trailingones[1] ), .C2(new_n73_), .Y(new_n74_));
  NOR2x1_ASAP7_75t_R   g053(.A(\totalcoeffs[3] ), .B(\ctable[0] ), .Y(new_n75_));
  INVx1_ASAP7_75t_R    g054(.A(new_n75_), .Y(new_n76_));
  NOR2x1_ASAP7_75t_R   g055(.A(\totalcoeffs[1] ), .B(new_n38_), .Y(new_n77_));
  OA33x2_ASAP7_75t_R   g056(.A1(new_n53_), .A2(new_n76_), .A3(new_n42_), .B1(\ctable[2] ), .B2(new_n34_), .B3(new_n77_), .Y(new_n78_));
  OAI22x1_ASAP7_75t_R  g057(.A1(\ctable[2] ), .A2(new_n74_), .B1(\totalcoeffs[2] ), .B2(new_n78_), .Y(new_n79_));
  NOR2x1_ASAP7_75t_R   g058(.A(\ctable[0] ), .B(\trailingones[1] ), .Y(new_n80_));
  INVx1_ASAP7_75t_R    g059(.A(new_n80_), .Y(new_n81_));
  OA21x2_ASAP7_75t_R   g060(.A1(new_n22_), .A2(\ctable[2] ), .B(new_n80_), .Y(new_n82_));
  AND3x1_ASAP7_75t_R   g061(.A(new_n26_), .B(\ctable[2] ), .C(\trailingones[0] ), .Y(new_n83_));
  AO21x1_ASAP7_75t_R   g062(.A1(new_n28_), .A2(\trailingones[1] ), .B(new_n83_), .Y(new_n84_));
  AO21x1_ASAP7_75t_R   g063(.A1(\totalcoeffs[1] ), .A2(new_n84_), .B(new_n82_), .Y(new_n85_));
  NOR2x1_ASAP7_75t_R   g064(.A(new_n23_), .B(\trailingones[1] ), .Y(new_n86_));
  INVx1_ASAP7_75t_R    g065(.A(new_n86_), .Y(new_n87_));
  NOR2x1_ASAP7_75t_R   g066(.A(\totalcoeffs[1] ), .B(\totalcoeffs[0] ), .Y(new_n88_));
  AO33x2_ASAP7_75t_R   g067(.A1(new_n23_), .A2(\totalcoeffs[0] ), .A3(new_n85_), .B1(new_n86_), .B2(new_n88_), .B3(new_n83_), .Y(new_n89_));
  AO22x1_ASAP7_75t_R   g068(.A1(new_n29_), .A2(new_n79_), .B1(new_n24_), .B2(new_n89_), .Y(new_n90_));
  AO22x1_ASAP7_75t_R   g069(.A1(new_n28_), .A2(new_n68_), .B1(new_n27_), .B2(new_n90_), .Y(new_n91_));
  NOR2x1_ASAP7_75t_R   g070(.A(\totalcoeffs[1] ), .B(\totalcoeffs[3] ), .Y(new_n92_));
  NOR2x1_ASAP7_75t_R   g071(.A(\ctable[1] ), .B(\trailingones[1] ), .Y(new_n93_));
  AO21x1_ASAP7_75t_R   g072(.A1(\totalcoeffs[4] ), .A2(\trailingones[0] ), .B(new_n93_), .Y(new_n94_));
  NAND2x1_ASAP7_75t_R  g073(.A(new_n27_), .B(\trailingones[0] ), .Y(new_n95_));
  AND2x2_ASAP7_75t_R   g074(.A(\ctable[0] ), .B(new_n95_), .Y(new_n96_));
  NAND2x1_ASAP7_75t_R  g075(.A(\ctable[0] ), .B(\ctable[1] ), .Y(new_n97_));
  NOR2x1_ASAP7_75t_R   g076(.A(new_n27_), .B(\trailingones[1] ), .Y(new_n98_));
  AO21x1_ASAP7_75t_R   g077(.A1(\totalcoeffs[4] ), .A2(\trailingones[1] ), .B(new_n98_), .Y(new_n99_));
  AO32x1_ASAP7_75t_R   g078(.A1(new_n29_), .A2(new_n97_), .A3(new_n99_), .B1(new_n94_), .B2(new_n96_), .Y(new_n100_));
  AND5x1_ASAP7_75t_R   g079(.A(new_n23_), .B(new_n31_), .C(new_n28_), .D(new_n92_), .E(new_n100_), .Y(new_n101_));
  AO21x1_ASAP7_75t_R   g080(.A1(new_n25_), .A2(new_n91_), .B(new_n101_), .Y(\coeff_token[0] ));
  AO21x1_ASAP7_75t_R   g081(.A1(new_n22_), .A2(new_n31_), .B(new_n23_), .Y(new_n103_));
  INVx1_ASAP7_75t_R    g082(.A(new_n103_), .Y(new_n104_));
  AO21x1_ASAP7_75t_R   g083(.A1(\totalcoeffs[1] ), .A2(\totalcoeffs[0] ), .B(new_n39_), .Y(new_n105_));
  NOR2x1_ASAP7_75t_R   g084(.A(\totalcoeffs[2] ), .B(new_n29_), .Y(new_n106_));
  INVx1_ASAP7_75t_R    g085(.A(new_n106_), .Y(new_n107_));
  AO32x1_ASAP7_75t_R   g086(.A1(new_n29_), .A2(new_n103_), .A3(new_n105_), .B1(new_n34_), .B2(new_n106_), .Y(new_n108_));
  AO32x1_ASAP7_75t_R   g087(.A1(\totalcoeffs[2] ), .A2(new_n30_), .A3(new_n88_), .B1(\ctable[2] ), .B2(new_n108_), .Y(new_n109_));
  AND3x1_ASAP7_75t_R   g088(.A(new_n24_), .B(new_n26_), .C(new_n27_), .Y(new_n110_));
  NAND2x1_ASAP7_75t_R  g089(.A(new_n22_), .B(\totalcoeffs[3] ), .Y(new_n111_));
  NOR2x1_ASAP7_75t_R   g090(.A(\totalcoeffs[2] ), .B(\trailingones[0] ), .Y(new_n112_));
  AO32x1_ASAP7_75t_R   g091(.A1(new_n22_), .A2(\totalcoeffs[3] ), .A3(new_n112_), .B1(\totalcoeffs[1] ), .B2(\ctable[0] ), .Y(new_n113_));
  AND3x1_ASAP7_75t_R   g092(.A(\totalcoeffs[1] ), .B(\totalcoeffs[2] ), .C(\totalcoeffs[3] ), .Y(new_n114_));
  OA21x2_ASAP7_75t_R   g093(.A1(\ctable[0] ), .A2(new_n114_), .B(new_n58_), .Y(new_n115_));
  AO21x1_ASAP7_75t_R   g094(.A1(\totalcoeffs[0] ), .A2(new_n113_), .B(new_n115_), .Y(new_n116_));
  NOR2x1_ASAP7_75t_R   g095(.A(new_n26_), .B(\trailingones[0] ), .Y(new_n117_));
  AO221x2_ASAP7_75t_R  g096(.A1(new_n114_), .A2(new_n117_), .B1(\ctable[1] ), .B2(new_n116_), .C(new_n30_), .Y(new_n118_));
  NOR2x1_ASAP7_75t_R   g097(.A(\ctable[0] ), .B(new_n31_), .Y(new_n119_));
  INVx1_ASAP7_75t_R    g098(.A(new_n119_), .Y(new_n120_));
  NOR2x1_ASAP7_75t_R   g099(.A(new_n26_), .B(\totalcoeffs[0] ), .Y(new_n121_));
  INVx1_ASAP7_75t_R    g100(.A(new_n121_), .Y(new_n122_));
  OA211x2_ASAP7_75t_R  g101(.A1(new_n31_), .A2(new_n107_), .B(new_n120_), .C(new_n122_), .Y(new_n123_));
  AO21x1_ASAP7_75t_R   g102(.A1(\totalcoeffs[3] ), .A2(\trailingones[0] ), .B(\totalcoeffs[2] ), .Y(new_n124_));
  INVx1_ASAP7_75t_R    g103(.A(new_n124_), .Y(new_n125_));
  OR3x1_ASAP7_75t_R    g104(.A(\totalcoeffs[2] ), .B(\trailingones[0] ), .C(new_n26_), .Y(new_n126_));
  INVx1_ASAP7_75t_R    g105(.A(new_n126_), .Y(new_n127_));
  NOR2x1_ASAP7_75t_R   g106(.A(\totalcoeffs[3] ), .B(\trailingones[0] ), .Y(new_n128_));
  AO21x1_ASAP7_75t_R   g107(.A1(new_n26_), .A2(\trailingones[0] ), .B(new_n128_), .Y(new_n129_));
  OA21x2_ASAP7_75t_R   g108(.A1(new_n31_), .A2(new_n129_), .B(new_n126_), .Y(new_n130_));
  OA222x2_ASAP7_75t_R  g109(.A1(new_n22_), .A2(new_n123_), .B1(\totalcoeffs[0] ), .B2(new_n125_), .C1(\totalcoeffs[1] ), .C2(new_n130_), .Y(new_n131_));
  INVx1_ASAP7_75t_R    g110(.A(new_n131_), .Y(new_n132_));
  AOI22x1_ASAP7_75t_R  g111(.A1(\totalcoeffs[1] ), .A2(\totalcoeffs[0] ), .B1(new_n22_), .B2(new_n27_), .Y(new_n133_));
  NOR2x1_ASAP7_75t_R   g112(.A(new_n29_), .B(\totalcoeffs[0] ), .Y(new_n134_));
  INVx1_ASAP7_75t_R    g113(.A(new_n134_), .Y(new_n135_));
  NAND2x1_ASAP7_75t_R  g114(.A(new_n22_), .B(\trailingones[0] ), .Y(new_n136_));
  NOR2x1_ASAP7_75t_R   g115(.A(\totalcoeffs[1] ), .B(\trailingones[0] ), .Y(new_n137_));
  INVx1_ASAP7_75t_R    g116(.A(new_n137_), .Y(new_n138_));
  AO32x1_ASAP7_75t_R   g117(.A1(new_n22_), .A2(\trailingones[0] ), .A3(\ctable[1] ), .B1(new_n23_), .B2(new_n138_), .Y(new_n139_));
  AO32x1_ASAP7_75t_R   g118(.A1(new_n23_), .A2(new_n135_), .A3(new_n133_), .B1(\totalcoeffs[3] ), .B2(new_n139_), .Y(new_n140_));
  AO221x2_ASAP7_75t_R  g119(.A1(new_n26_), .A2(new_n140_), .B1(new_n27_), .B2(new_n132_), .C(\trailingones[1] ), .Y(new_n141_));
  AO21x1_ASAP7_75t_R   g120(.A1(\ctable[1] ), .A2(new_n31_), .B(\totalcoeffs[2] ), .Y(new_n142_));
  AO32x1_ASAP7_75t_R   g121(.A1(new_n26_), .A2(\trailingones[0] ), .A3(new_n142_), .B1(new_n27_), .B2(new_n29_), .Y(new_n143_));
  NOR2x1_ASAP7_75t_R   g122(.A(new_n27_), .B(new_n29_), .Y(new_n144_));
  NAND2x1_ASAP7_75t_R  g123(.A(\ctable[1] ), .B(\trailingones[1] ), .Y(new_n145_));
  OA21x2_ASAP7_75t_R   g124(.A1(\ctable[0] ), .A2(new_n29_), .B(new_n145_), .Y(new_n146_));
  OA33x2_ASAP7_75t_R   g125(.A1(\trailingones[0] ), .A2(new_n30_), .A3(new_n122_), .B1(new_n31_), .B2(new_n144_), .B3(new_n146_), .Y(new_n147_));
  INVx1_ASAP7_75t_R    g126(.A(new_n147_), .Y(new_n148_));
  AOI22x1_ASAP7_75t_R  g127(.A1(new_n30_), .A2(new_n143_), .B1(new_n23_), .B2(new_n148_), .Y(new_n149_));
  OA332x2_ASAP7_75t_R  g128(.A1(new_n27_), .A2(new_n29_), .A3(new_n30_), .B1(\ctable[0] ), .B2(\trailingones[1] ), .B3(\trailingones[0] ), .C1(\totalcoeffs[0] ), .C2(new_n146_), .Y(new_n150_));
  INVx1_ASAP7_75t_R    g129(.A(new_n150_), .Y(new_n151_));
  AND3x1_ASAP7_75t_R   g130(.A(\trailingones[0] ), .B(\totalcoeffs[0] ), .C(\trailingones[1] ), .Y(new_n152_));
  AO32x1_ASAP7_75t_R   g131(.A1(new_n30_), .A2(new_n31_), .A3(new_n112_), .B1(\totalcoeffs[2] ), .B2(new_n152_), .Y(new_n153_));
  AOI22x1_ASAP7_75t_R  g132(.A1(\totalcoeffs[2] ), .A2(new_n151_), .B1(\ctable[0] ), .B2(new_n153_), .Y(new_n154_));
  OA222x2_ASAP7_75t_R  g133(.A1(new_n87_), .A2(new_n95_), .B1(\totalcoeffs[1] ), .B2(new_n154_), .C1(new_n22_), .C2(new_n149_), .Y(new_n155_));
  INVx1_ASAP7_75t_R    g134(.A(new_n155_), .Y(new_n156_));
  AND3x1_ASAP7_75t_R   g135(.A(new_n22_), .B(new_n31_), .C(new_n23_), .Y(new_n157_));
  AO21x1_ASAP7_75t_R   g136(.A1(\totalcoeffs[4] ), .A2(\trailingones[0] ), .B(new_n117_), .Y(new_n158_));
  AO32x1_ASAP7_75t_R   g137(.A1(\ctable[1] ), .A2(\trailingones[1] ), .A3(\totalcoeffs[4] ), .B1(new_n93_), .B2(new_n158_), .Y(new_n159_));
  AO32x1_ASAP7_75t_R   g138(.A1(new_n23_), .A2(new_n88_), .A3(new_n159_), .B1(new_n25_), .B2(new_n156_), .Y(new_n160_));
  AO32x1_ASAP7_75t_R   g139(.A1(new_n25_), .A2(new_n118_), .A3(new_n141_), .B1(new_n24_), .B2(new_n160_), .Y(new_n161_));
  AO32x1_ASAP7_75t_R   g140(.A1(new_n25_), .A2(new_n110_), .A3(new_n109_), .B1(new_n28_), .B2(new_n161_), .Y(\coeff_token[1] ));
  NOR2x1_ASAP7_75t_R   g141(.A(\ctable[0] ), .B(\ctable[1] ), .Y(new_n163_));
  NOR2x1_ASAP7_75t_R   g142(.A(new_n29_), .B(new_n30_), .Y(new_n164_));
  INVx1_ASAP7_75t_R    g143(.A(new_n164_), .Y(new_n165_));
  AO21x1_ASAP7_75t_R   g144(.A1(\ctable[2] ), .A2(new_n164_), .B(new_n31_), .Y(new_n166_));
  AO32x1_ASAP7_75t_R   g145(.A1(new_n22_), .A2(new_n29_), .A3(new_n38_), .B1(new_n42_), .B2(new_n166_), .Y(new_n167_));
  AND5x1_ASAP7_75t_R   g146(.A(new_n23_), .B(new_n24_), .C(new_n25_), .D(new_n163_), .E(new_n167_), .Y(new_n168_));
  NOR2x1_ASAP7_75t_R   g147(.A(new_n27_), .B(new_n53_), .Y(new_n169_));
  AO21x1_ASAP7_75t_R   g148(.A1(\totalcoeffs[1] ), .A2(new_n30_), .B(new_n169_), .Y(new_n170_));
  NOR2x1_ASAP7_75t_R   g149(.A(new_n22_), .B(new_n30_), .Y(new_n171_));
  INVx1_ASAP7_75t_R    g150(.A(new_n171_), .Y(new_n172_));
  AO21x1_ASAP7_75t_R   g151(.A1(\totalcoeffs[1] ), .A2(\trailingones[1] ), .B(new_n47_), .Y(new_n173_));
  AO32x1_ASAP7_75t_R   g152(.A1(new_n24_), .A2(new_n29_), .A3(new_n173_), .B1(\trailingones[0] ), .B2(new_n170_), .Y(new_n174_));
  NOR2x1_ASAP7_75t_R   g153(.A(\trailingones[0] ), .B(\trailingones[1] ), .Y(new_n175_));
  INVx1_ASAP7_75t_R    g154(.A(new_n175_), .Y(new_n176_));
  OA21x2_ASAP7_75t_R   g155(.A1(new_n23_), .A2(new_n172_), .B(new_n136_), .Y(new_n177_));
  OA222x2_ASAP7_75t_R  g156(.A1(new_n23_), .A2(new_n176_), .B1(new_n29_), .B2(new_n86_), .C1(new_n27_), .C2(new_n177_), .Y(new_n178_));
  INVx1_ASAP7_75t_R    g157(.A(new_n178_), .Y(new_n179_));
  AO22x1_ASAP7_75t_R   g158(.A1(new_n23_), .A2(new_n174_), .B1(\totalcoeffs[3] ), .B2(new_n179_), .Y(new_n180_));
  AND2x2_ASAP7_75t_R   g159(.A(\ctable[0] ), .B(new_n111_), .Y(new_n181_));
  OA33x2_ASAP7_75t_R   g160(.A1(new_n30_), .A2(new_n57_), .A3(new_n136_), .B1(\totalcoeffs[2] ), .B2(new_n176_), .B3(new_n181_), .Y(new_n182_));
  INVx1_ASAP7_75t_R    g161(.A(new_n182_), .Y(new_n183_));
  AO21x1_ASAP7_75t_R   g162(.A1(\trailingones[0] ), .A2(\trailingones[1] ), .B(new_n175_), .Y(new_n184_));
  INVx1_ASAP7_75t_R    g163(.A(new_n184_), .Y(new_n185_));
  OA21x2_ASAP7_75t_R   g164(.A1(new_n47_), .A2(new_n185_), .B(\totalcoeffs[2] ), .Y(new_n186_));
  OR3x1_ASAP7_75t_R    g165(.A(new_n26_), .B(new_n175_), .C(new_n152_), .Y(new_n187_));
  OA211x2_ASAP7_75t_R  g166(.A1(\ctable[0] ), .A2(new_n32_), .B(\totalcoeffs[1] ), .C(new_n187_), .Y(new_n188_));
  OA21x2_ASAP7_75t_R   g167(.A1(new_n186_), .A2(new_n188_), .B(new_n24_), .Y(new_n189_));
  AO21x1_ASAP7_75t_R   g168(.A1(\totalcoeffs[0] ), .A2(new_n183_), .B(new_n189_), .Y(new_n190_));
  AO32x1_ASAP7_75t_R   g169(.A1(new_n26_), .A2(\totalcoeffs[0] ), .A3(new_n180_), .B1(new_n27_), .B2(new_n190_), .Y(new_n191_));
  NOR2x1_ASAP7_75t_R   g170(.A(new_n27_), .B(\trailingones[0] ), .Y(new_n192_));
  INVx1_ASAP7_75t_R    g171(.A(new_n192_), .Y(new_n193_));
  AO21x1_ASAP7_75t_R   g172(.A1(new_n165_), .A2(new_n193_), .B(\ctable[0] ), .Y(new_n194_));
  OR3x1_ASAP7_75t_R    g173(.A(\totalcoeffs[1] ), .B(\totalcoeffs[3] ), .C(\totalcoeffs[2] ), .Y(new_n195_));
  INVx1_ASAP7_75t_R    g174(.A(new_n195_), .Y(new_n196_));
  AO21x1_ASAP7_75t_R   g175(.A1(new_n194_), .A2(new_n196_), .B(new_n25_), .Y(new_n197_));
  AO21x1_ASAP7_75t_R   g176(.A1(new_n23_), .A2(\trailingones[0] ), .B(new_n24_), .Y(new_n198_));
  INVx1_ASAP7_75t_R    g177(.A(new_n198_), .Y(new_n199_));
  AO21x1_ASAP7_75t_R   g178(.A1(\totalcoeffs[2] ), .A2(new_n26_), .B(new_n24_), .Y(new_n200_));
  AO22x1_ASAP7_75t_R   g179(.A1(\ctable[0] ), .A2(new_n198_), .B1(\trailingones[0] ), .B2(new_n200_), .Y(new_n201_));
  NOR2x1_ASAP7_75t_R   g180(.A(\ctable[0] ), .B(new_n27_), .Y(new_n202_));
  INVx1_ASAP7_75t_R    g181(.A(new_n202_), .Y(new_n203_));
  AO32x1_ASAP7_75t_R   g182(.A1(new_n24_), .A2(new_n202_), .A3(new_n137_), .B1(\totalcoeffs[1] ), .B2(new_n201_), .Y(new_n204_));
  NAND2x1_ASAP7_75t_R  g183(.A(\totalcoeffs[3] ), .B(new_n30_), .Y(new_n205_));
  AO21x1_ASAP7_75t_R   g184(.A1(\totalcoeffs[3] ), .A2(new_n29_), .B(new_n34_), .Y(new_n206_));
  AND3x1_ASAP7_75t_R   g185(.A(new_n24_), .B(\trailingones[1] ), .C(\totalcoeffs[1] ), .Y(new_n207_));
  AO21x1_ASAP7_75t_R   g186(.A1(new_n192_), .A2(new_n207_), .B(\totalcoeffs[4] ), .Y(new_n208_));
  AO21x1_ASAP7_75t_R   g187(.A1(\totalcoeffs[2] ), .A2(new_n95_), .B(new_n22_), .Y(new_n209_));
  AO331x2_ASAP7_75t_R  g188(.A1(new_n27_), .A2(new_n205_), .A3(new_n206_), .B1(\ctable[0] ), .B2(new_n124_), .B3(new_n209_), .C(new_n208_), .Y(new_n210_));
  NAND2x1_ASAP7_75t_R  g189(.A(\totalcoeffs[1] ), .B(\trailingones[0] ), .Y(new_n211_));
  AO21x1_ASAP7_75t_R   g190(.A1(\ctable[1] ), .A2(new_n211_), .B(\trailingones[1] ), .Y(new_n212_));
  AO32x1_ASAP7_75t_R   g191(.A1(new_n22_), .A2(\trailingones[1] ), .A3(new_n29_), .B1(new_n23_), .B2(new_n212_), .Y(new_n213_));
  AO221x2_ASAP7_75t_R  g192(.A1(\totalcoeffs[3] ), .A2(new_n213_), .B1(new_n30_), .B2(new_n204_), .C(new_n210_), .Y(new_n214_));
  AO32x1_ASAP7_75t_R   g193(.A1(new_n31_), .A2(new_n197_), .A3(new_n214_), .B1(new_n25_), .B2(new_n191_), .Y(new_n215_));
  AO21x1_ASAP7_75t_R   g194(.A1(new_n28_), .A2(new_n215_), .B(new_n168_), .Y(\coeff_token[2] ));
  NOR2x1_ASAP7_75t_R   g195(.A(\totalcoeffs[3] ), .B(new_n25_), .Y(new_n217_));
  AO21x1_ASAP7_75t_R   g196(.A1(\trailingones[0] ), .A2(\trailingones[1] ), .B(\ctable[0] ), .Y(new_n218_));
  INVx1_ASAP7_75t_R    g197(.A(new_n218_), .Y(new_n219_));
  AO21x1_ASAP7_75t_R   g198(.A1(\ctable[0] ), .A2(\ctable[1] ), .B(new_n163_), .Y(new_n220_));
  AND5x1_ASAP7_75t_R   g199(.A(new_n22_), .B(new_n23_), .C(new_n217_), .D(new_n218_), .E(new_n220_), .Y(new_n221_));
  OA21x2_ASAP7_75t_R   g200(.A1(new_n27_), .A2(new_n57_), .B(new_n205_), .Y(new_n222_));
  AOI21x1_ASAP7_75t_R  g201(.A1(new_n24_), .A2(new_n193_), .B(new_n96_), .Y(new_n223_));
  AND3x1_ASAP7_75t_R   g202(.A(\ctable[0] ), .B(\trailingones[1] ), .C(\trailingones[0] ), .Y(new_n224_));
  AO32x1_ASAP7_75t_R   g203(.A1(new_n26_), .A2(new_n30_), .A3(new_n29_), .B1(new_n27_), .B2(new_n224_), .Y(new_n225_));
  AOI21x1_ASAP7_75t_R  g204(.A1(\totalcoeffs[2] ), .A2(new_n225_), .B(new_n223_), .Y(new_n226_));
  OA222x2_ASAP7_75t_R  g205(.A1(\totalcoeffs[1] ), .A2(new_n222_), .B1(new_n23_), .B2(new_n203_), .C1(new_n22_), .C2(new_n226_), .Y(new_n227_));
  INVx1_ASAP7_75t_R    g206(.A(new_n227_), .Y(new_n228_));
  AO21x1_ASAP7_75t_R   g207(.A1(new_n25_), .A2(new_n228_), .B(new_n221_), .Y(new_n229_));
  AO32x1_ASAP7_75t_R   g208(.A1(new_n22_), .A2(new_n27_), .A3(new_n127_), .B1(new_n24_), .B2(new_n202_), .Y(new_n230_));
  NOR2x1_ASAP7_75t_R   g209(.A(new_n24_), .B(\ctable[0] ), .Y(new_n231_));
  OA21x2_ASAP7_75t_R   g210(.A1(new_n24_), .A2(\trailingones[0] ), .B(new_n27_), .Y(new_n232_));
  OR3x1_ASAP7_75t_R    g211(.A(\trailingones[0] ), .B(new_n30_), .C(new_n26_), .Y(new_n233_));
  AND2x2_ASAP7_75t_R   g212(.A(new_n24_), .B(new_n233_), .Y(new_n234_));
  NOR2x1_ASAP7_75t_R   g213(.A(\totalcoeffs[2] ), .B(new_n26_), .Y(new_n235_));
  AOI22x1_ASAP7_75t_R  g214(.A1(\totalcoeffs[2] ), .A2(new_n129_), .B1(\trailingones[0] ), .B2(new_n235_), .Y(new_n236_));
  OA222x2_ASAP7_75t_R  g215(.A1(new_n231_), .A2(new_n232_), .B1(\totalcoeffs[2] ), .B2(new_n234_), .C1(\trailingones[1] ), .C2(new_n236_), .Y(new_n237_));
  INVx1_ASAP7_75t_R    g216(.A(new_n237_), .Y(new_n238_));
  AO22x1_ASAP7_75t_R   g217(.A1(new_n30_), .A2(new_n230_), .B1(\totalcoeffs[1] ), .B2(new_n238_), .Y(new_n239_));
  AO21x1_ASAP7_75t_R   g218(.A1(new_n27_), .A2(new_n29_), .B(new_n80_), .Y(new_n240_));
  NOR2x1_ASAP7_75t_R   g219(.A(new_n26_), .B(new_n29_), .Y(new_n241_));
  AO21x1_ASAP7_75t_R   g220(.A1(\ctable[0] ), .A2(\trailingones[0] ), .B(new_n171_), .Y(new_n242_));
  AO21x1_ASAP7_75t_R   g221(.A1(\ctable[0] ), .A2(\trailingones[1] ), .B(\ctable[1] ), .Y(new_n243_));
  INVx1_ASAP7_75t_R    g222(.A(new_n243_), .Y(new_n244_));
  AO22x1_ASAP7_75t_R   g223(.A1(new_n23_), .A2(new_n240_), .B1(new_n242_), .B2(new_n244_), .Y(new_n245_));
  OR3x1_ASAP7_75t_R    g224(.A(\ctable[0] ), .B(new_n27_), .C(\trailingones[1] ), .Y(new_n246_));
  INVx1_ASAP7_75t_R    g225(.A(new_n246_), .Y(new_n247_));
  AO32x1_ASAP7_75t_R   g226(.A1(\totalcoeffs[1] ), .A2(\trailingones[0] ), .A3(new_n247_), .B1(\totalcoeffs[3] ), .B2(new_n245_), .Y(new_n248_));
  NAND2x1_ASAP7_75t_R  g227(.A(\totalcoeffs[3] ), .B(new_n27_), .Y(new_n249_));
  AOI21x1_ASAP7_75t_R  g228(.A1(new_n246_), .A2(new_n249_), .B(\trailingones[0] ), .Y(new_n250_));
  AND3x1_ASAP7_75t_R   g229(.A(\totalcoeffs[3] ), .B(new_n27_), .C(\totalcoeffs[2] ), .Y(new_n251_));
  AO21x1_ASAP7_75t_R   g230(.A1(new_n58_), .A2(new_n202_), .B(new_n251_), .Y(new_n252_));
  AO21x1_ASAP7_75t_R   g231(.A1(\trailingones[1] ), .A2(new_n252_), .B(new_n250_), .Y(new_n253_));
  AO221x2_ASAP7_75t_R  g232(.A1(new_n22_), .A2(new_n253_), .B1(\totalcoeffs[0] ), .B2(new_n239_), .C(new_n248_), .Y(new_n254_));
  AOI22x1_ASAP7_75t_R  g233(.A1(new_n31_), .A2(new_n229_), .B1(new_n25_), .B2(new_n254_), .Y(new_n255_));
  NOR2x1_ASAP7_75t_R   g234(.A(\ctable[2] ), .B(new_n255_), .Y(\coeff_token[3] ));
  OR3x1_ASAP7_75t_R    g235(.A(new_n26_), .B(new_n27_), .C(\ctable[2] ), .Y(new_n257_));
  AO21x1_ASAP7_75t_R   g236(.A1(\totalcoeffs[3] ), .A2(new_n25_), .B(new_n217_), .Y(new_n258_));
  AOI22x1_ASAP7_75t_R  g237(.A1(new_n25_), .A2(new_n104_), .B1(new_n157_), .B2(new_n258_), .Y(new_n259_));
  NOR2x1_ASAP7_75t_R   g238(.A(new_n257_), .B(new_n259_), .Y(\coeff_token[4] ));
  AND3x1_ASAP7_75t_R   g239(.A(new_n24_), .B(\totalcoeffs[4] ), .C(new_n157_), .Y(new_n261_));
  INVx1_ASAP7_75t_R    g240(.A(new_n261_), .Y(new_n262_));
  OR3x1_ASAP7_75t_R    g241(.A(new_n24_), .B(\totalcoeffs[4] ), .C(new_n157_), .Y(new_n263_));
  AOI21x1_ASAP7_75t_R  g242(.A1(new_n262_), .A2(new_n263_), .B(new_n257_), .Y(\coeff_token[5] ));
  AO32x1_ASAP7_75t_R   g243(.A1(\totalcoeffs[4] ), .A2(new_n88_), .A3(new_n57_), .B1(\ctable[0] ), .B2(\ctable[1] ), .Y(new_n265_));
  AO21x1_ASAP7_75t_R   g244(.A1(\totalcoeffs[1] ), .A2(new_n152_), .B(new_n175_), .Y(new_n266_));
  AO21x1_ASAP7_75t_R   g245(.A1(\ctable[2] ), .A2(new_n30_), .B(new_n29_), .Y(new_n267_));
  AO32x1_ASAP7_75t_R   g246(.A1(new_n22_), .A2(\totalcoeffs[2] ), .A3(new_n267_), .B1(new_n23_), .B2(new_n34_), .Y(new_n268_));
  AO32x1_ASAP7_75t_R   g247(.A1(new_n23_), .A2(\ctable[2] ), .A3(new_n266_), .B1(new_n31_), .B2(new_n268_), .Y(new_n269_));
  AO21x1_ASAP7_75t_R   g248(.A1(\totalcoeffs[2] ), .A2(\trailingones[0] ), .B(new_n112_), .Y(new_n270_));
  NOR2x1_ASAP7_75t_R   g249(.A(new_n23_), .B(\totalcoeffs[0] ), .Y(new_n271_));
  INVx1_ASAP7_75t_R    g250(.A(new_n271_), .Y(new_n272_));
  AO21x1_ASAP7_75t_R   g251(.A1(\trailingones[1] ), .A2(new_n271_), .B(new_n56_), .Y(new_n273_));
  AO32x1_ASAP7_75t_R   g252(.A1(\ctable[1] ), .A2(new_n184_), .A3(new_n270_), .B1(\ctable[0] ), .B2(new_n273_), .Y(new_n274_));
  AO21x1_ASAP7_75t_R   g253(.A1(new_n22_), .A2(new_n26_), .B(new_n23_), .Y(new_n275_));
  AO32x1_ASAP7_75t_R   g254(.A1(\totalcoeffs[1] ), .A2(\trailingones[1] ), .A3(\ctable[0] ), .B1(new_n93_), .B2(new_n275_), .Y(new_n276_));
  AO32x1_ASAP7_75t_R   g255(.A1(\totalcoeffs[2] ), .A2(new_n31_), .A3(new_n81_), .B1(\totalcoeffs[0] ), .B2(new_n276_), .Y(new_n277_));
  AO21x1_ASAP7_75t_R   g256(.A1(\trailingones[0] ), .A2(new_n277_), .B(new_n274_), .Y(new_n278_));
  AO32x1_ASAP7_75t_R   g257(.A1(new_n26_), .A2(new_n27_), .A3(new_n269_), .B1(new_n28_), .B2(new_n278_), .Y(new_n279_));
  NOR2x1_ASAP7_75t_R   g258(.A(\totalcoeffs[0] ), .B(new_n192_), .Y(new_n280_));
  NAND2x1_ASAP7_75t_R  g259(.A(new_n23_), .B(new_n30_), .Y(new_n281_));
  OA33x2_ASAP7_75t_R   g260(.A1(new_n241_), .A2(new_n281_), .A3(new_n280_), .B1(new_n23_), .B2(new_n29_), .B3(new_n41_), .Y(new_n282_));
  AO21x1_ASAP7_75t_R   g261(.A1(\totalcoeffs[2] ), .A2(new_n26_), .B(\ctable[1] ), .Y(new_n283_));
  AO32x1_ASAP7_75t_R   g262(.A1(new_n23_), .A2(\ctable[0] ), .A3(new_n62_), .B1(new_n40_), .B2(new_n283_), .Y(new_n284_));
  AO21x1_ASAP7_75t_R   g263(.A1(new_n29_), .A2(new_n30_), .B(new_n23_), .Y(new_n285_));
  AO21x1_ASAP7_75t_R   g264(.A1(\totalcoeffs[2] ), .A2(new_n176_), .B(new_n152_), .Y(new_n286_));
  AOI22x1_ASAP7_75t_R  g265(.A1(new_n29_), .A2(new_n284_), .B1(\ctable[1] ), .B2(new_n286_), .Y(new_n287_));
  AO32x1_ASAP7_75t_R   g266(.A1(\totalcoeffs[0] ), .A2(new_n144_), .A3(new_n23_), .B1(new_n50_), .B2(new_n272_), .Y(new_n288_));
  OA211x2_ASAP7_75t_R  g267(.A1(\trailingones[0] ), .A2(\totalcoeffs[0] ), .B(new_n34_), .C(new_n120_), .Y(new_n289_));
  NOR2x1_ASAP7_75t_R   g268(.A(\totalcoeffs[1] ), .B(new_n175_), .Y(new_n290_));
  NOR2x1_ASAP7_75t_R   g269(.A(new_n31_), .B(new_n290_), .Y(new_n291_));
  AO32x1_ASAP7_75t_R   g270(.A1(new_n27_), .A2(new_n31_), .A3(new_n138_), .B1(\totalcoeffs[1] ), .B2(\totalcoeffs[2] ), .Y(new_n292_));
  AO32x1_ASAP7_75t_R   g271(.A1(new_n48_), .A2(new_n172_), .A3(new_n292_), .B1(new_n35_), .B2(new_n291_), .Y(new_n293_));
  AOI221x1_ASAP7_75t_R g272(.A1(\trailingones[1] ), .A2(new_n288_), .B1(new_n26_), .B2(new_n293_), .C(new_n289_), .Y(new_n294_));
  OA222x2_ASAP7_75t_R  g273(.A1(\totalcoeffs[1] ), .A2(new_n282_), .B1(new_n22_), .B2(new_n287_), .C1(new_n24_), .C2(new_n294_), .Y(new_n295_));
  INVx1_ASAP7_75t_R    g274(.A(new_n295_), .Y(new_n296_));
  AO22x1_ASAP7_75t_R   g275(.A1(new_n24_), .A2(new_n279_), .B1(new_n28_), .B2(new_n296_), .Y(new_n297_));
  AOI22x1_ASAP7_75t_R  g276(.A1(new_n28_), .A2(new_n265_), .B1(new_n25_), .B2(new_n297_), .Y(\ctoken_len[0] ));
  AND5x1_ASAP7_75t_R   g277(.A(new_n23_), .B(\totalcoeffs[0] ), .C(\trailingones[0] ), .D(\ctable[2] ), .E(new_n30_), .Y(new_n299_));
  AO21x1_ASAP7_75t_R   g278(.A1(new_n185_), .A2(new_n271_), .B(new_n299_), .Y(new_n300_));
  AO21x1_ASAP7_75t_R   g279(.A1(\totalcoeffs[2] ), .A2(\totalcoeffs[3] ), .B(new_n184_), .Y(new_n301_));
  OA21x2_ASAP7_75t_R   g280(.A1(\totalcoeffs[2] ), .A2(new_n69_), .B(\ctable[0] ), .Y(new_n302_));
  AO32x1_ASAP7_75t_R   g281(.A1(\totalcoeffs[2] ), .A2(new_n175_), .A3(new_n69_), .B1(new_n301_), .B2(new_n302_), .Y(new_n303_));
  AO32x1_ASAP7_75t_R   g282(.A1(\totalcoeffs[2] ), .A2(\totalcoeffs[3] ), .A3(new_n224_), .B1(new_n22_), .B2(new_n303_), .Y(new_n304_));
  NOR2x1_ASAP7_75t_R   g283(.A(new_n24_), .B(new_n26_), .Y(new_n305_));
  INVx1_ASAP7_75t_R    g284(.A(new_n305_), .Y(new_n306_));
  AO21x1_ASAP7_75t_R   g285(.A1(\totalcoeffs[2] ), .A2(new_n30_), .B(new_n305_), .Y(new_n307_));
  AOI22x1_ASAP7_75t_R  g286(.A1(\totalcoeffs[3] ), .A2(new_n235_), .B1(new_n31_), .B2(new_n307_), .Y(new_n308_));
  AO32x1_ASAP7_75t_R   g287(.A1(\totalcoeffs[0] ), .A2(new_n33_), .A3(new_n281_), .B1(new_n30_), .B2(new_n121_), .Y(new_n309_));
  AOI22x1_ASAP7_75t_R  g288(.A1(\trailingones[0] ), .A2(new_n309_), .B1(new_n32_), .B2(new_n117_), .Y(new_n310_));
  OA222x2_ASAP7_75t_R  g289(.A1(new_n281_), .A2(new_n306_), .B1(\trailingones[0] ), .B2(new_n308_), .C1(\totalcoeffs[3] ), .C2(new_n310_), .Y(new_n311_));
  INVx1_ASAP7_75t_R    g290(.A(new_n311_), .Y(new_n312_));
  AO21x1_ASAP7_75t_R   g291(.A1(\totalcoeffs[1] ), .A2(new_n312_), .B(new_n304_), .Y(new_n313_));
  AO22x1_ASAP7_75t_R   g292(.A1(\trailingones[0] ), .A2(\totalcoeffs[0] ), .B1(\totalcoeffs[3] ), .B2(new_n165_), .Y(new_n314_));
  AO32x1_ASAP7_75t_R   g293(.A1(\trailingones[0] ), .A2(\trailingones[1] ), .A3(new_n24_), .B1(new_n27_), .B2(new_n314_), .Y(new_n315_));
  AO32x1_ASAP7_75t_R   g294(.A1(\totalcoeffs[3] ), .A2(new_n27_), .A3(new_n134_), .B1(\ctable[1] ), .B2(new_n29_), .Y(new_n316_));
  AOI21x1_ASAP7_75t_R  g295(.A1(\totalcoeffs[0] ), .A2(new_n249_), .B(new_n98_), .Y(new_n317_));
  AOI21x1_ASAP7_75t_R  g296(.A1(new_n29_), .A2(new_n145_), .B(new_n317_), .Y(new_n318_));
  AO21x1_ASAP7_75t_R   g297(.A1(\trailingones[1] ), .A2(new_n316_), .B(new_n318_), .Y(new_n319_));
  AO222x2_ASAP7_75t_R  g298(.A1(new_n23_), .A2(new_n319_), .B1(new_n93_), .B2(new_n128_), .C1(\totalcoeffs[2] ), .C2(new_n315_), .Y(new_n320_));
  NOR2x1_ASAP7_75t_R   g299(.A(\ctable[1] ), .B(new_n128_), .Y(new_n321_));
  OA33x2_ASAP7_75t_R   g300(.A1(new_n27_), .A2(new_n29_), .A3(new_n31_), .B1(\totalcoeffs[2] ), .B2(\trailingones[0] ), .B3(\totalcoeffs[0] ), .Y(new_n322_));
  OA33x2_ASAP7_75t_R   g301(.A1(\ctable[1] ), .A2(new_n164_), .A3(new_n39_), .B1(new_n27_), .B2(\totalcoeffs[0] ), .B3(new_n185_), .Y(new_n323_));
  OA222x2_ASAP7_75t_R  g302(.A1(new_n285_), .A2(new_n321_), .B1(\trailingones[1] ), .B2(new_n322_), .C1(new_n24_), .C2(new_n323_), .Y(new_n324_));
  INVx1_ASAP7_75t_R    g303(.A(new_n324_), .Y(new_n325_));
  AO32x1_ASAP7_75t_R   g304(.A1(\totalcoeffs[3] ), .A2(new_n112_), .A3(new_n98_), .B1(new_n22_), .B2(new_n325_), .Y(new_n326_));
  AO21x1_ASAP7_75t_R   g305(.A1(\totalcoeffs[1] ), .A2(new_n320_), .B(new_n326_), .Y(new_n327_));
  AO22x1_ASAP7_75t_R   g306(.A1(new_n27_), .A2(new_n313_), .B1(new_n26_), .B2(new_n327_), .Y(new_n328_));
  AO32x1_ASAP7_75t_R   g307(.A1(new_n92_), .A2(new_n163_), .A3(new_n300_), .B1(new_n28_), .B2(new_n328_), .Y(new_n329_));
  AND3x1_ASAP7_75t_R   g308(.A(new_n26_), .B(new_n28_), .C(new_n261_), .Y(new_n330_));
  AOI22x1_ASAP7_75t_R  g309(.A1(new_n25_), .A2(new_n329_), .B1(new_n27_), .B2(new_n330_), .Y(\ctoken_len[1] ));
  AO32x1_ASAP7_75t_R   g310(.A1(new_n23_), .A2(\trailingones[0] ), .A3(\totalcoeffs[0] ), .B1(new_n31_), .B2(new_n270_), .Y(new_n332_));
  AO32x1_ASAP7_75t_R   g311(.A1(\trailingones[1] ), .A2(new_n271_), .A3(new_n29_), .B1(new_n30_), .B2(new_n332_), .Y(new_n333_));
  AO32x1_ASAP7_75t_R   g312(.A1(new_n31_), .A2(new_n112_), .A3(new_n171_), .B1(new_n22_), .B2(new_n333_), .Y(new_n334_));
  OA21x2_ASAP7_75t_R   g313(.A1(new_n23_), .A2(\ctable[0] ), .B(new_n306_), .Y(new_n335_));
  OA33x2_ASAP7_75t_R   g314(.A1(new_n22_), .A2(new_n199_), .A3(new_n335_), .B1(new_n107_), .B2(new_n121_), .B3(new_n111_), .Y(new_n336_));
  AO21x1_ASAP7_75t_R   g315(.A1(\totalcoeffs[1] ), .A2(\ctable[0] ), .B(new_n231_), .Y(new_n337_));
  OA33x2_ASAP7_75t_R   g316(.A1(\totalcoeffs[2] ), .A2(new_n37_), .A3(new_n337_), .B1(\totalcoeffs[1] ), .B2(\totalcoeffs[3] ), .B3(new_n120_), .Y(new_n338_));
  INVx1_ASAP7_75t_R    g317(.A(new_n338_), .Y(new_n339_));
  AO21x1_ASAP7_75t_R   g318(.A1(\trailingones[0] ), .A2(new_n31_), .B(\ctable[0] ), .Y(new_n340_));
  AO32x1_ASAP7_75t_R   g319(.A1(new_n71_), .A2(new_n306_), .A3(new_n340_), .B1(\trailingones[0] ), .B2(new_n339_), .Y(new_n341_));
  INVx1_ASAP7_75t_R    g320(.A(new_n341_), .Y(new_n342_));
  AO221x2_ASAP7_75t_R  g321(.A1(new_n22_), .A2(new_n30_), .B1(new_n24_), .B2(\trailingones[1] ), .C(\totalcoeffs[2] ), .Y(new_n343_));
  AOI21x1_ASAP7_75t_R  g322(.A1(new_n22_), .A2(new_n26_), .B(new_n173_), .Y(new_n344_));
  AOI21x1_ASAP7_75t_R  g323(.A1(new_n47_), .A2(new_n235_), .B(new_n207_), .Y(new_n345_));
  OA222x2_ASAP7_75t_R  g324(.A1(new_n52_), .A2(new_n344_), .B1(\totalcoeffs[0] ), .B2(new_n345_), .C1(new_n337_), .C2(new_n343_), .Y(new_n346_));
  OA222x2_ASAP7_75t_R  g325(.A1(new_n30_), .A2(new_n336_), .B1(\trailingones[1] ), .B2(new_n342_), .C1(\trailingones[0] ), .C2(new_n346_), .Y(new_n347_));
  INVx1_ASAP7_75t_R    g326(.A(new_n347_), .Y(new_n348_));
  OR3x1_ASAP7_75t_R    g327(.A(new_n29_), .B(\totalcoeffs[0] ), .C(new_n34_), .Y(new_n349_));
  AO21x1_ASAP7_75t_R   g328(.A1(new_n169_), .A2(new_n349_), .B(\totalcoeffs[2] ), .Y(new_n350_));
  OR3x1_ASAP7_75t_R    g329(.A(\ctable[1] ), .B(new_n50_), .C(new_n291_), .Y(new_n351_));
  AO32x1_ASAP7_75t_R   g330(.A1(new_n231_), .A2(new_n350_), .A3(new_n351_), .B1(new_n27_), .B2(new_n348_), .Y(new_n352_));
  AO32x1_ASAP7_75t_R   g331(.A1(new_n27_), .A2(new_n75_), .A3(new_n334_), .B1(new_n28_), .B2(new_n352_), .Y(new_n353_));
  AOI21x1_ASAP7_75t_R  g332(.A1(new_n25_), .A2(new_n353_), .B(new_n330_), .Y(\ctoken_len[2] ));
  AO21x1_ASAP7_75t_R   g333(.A1(\ctable[1] ), .A2(\trailingones[1] ), .B(new_n24_), .Y(new_n355_));
  AO32x1_ASAP7_75t_R   g334(.A1(\trailingones[0] ), .A2(new_n31_), .A3(new_n355_), .B1(new_n24_), .B2(new_n81_), .Y(new_n356_));
  OA21x2_ASAP7_75t_R   g335(.A1(\ctable[1] ), .A2(new_n224_), .B(new_n24_), .Y(new_n357_));
  AO221x2_ASAP7_75t_R  g336(.A1(new_n219_), .A2(new_n251_), .B1(new_n23_), .B2(new_n356_), .C(new_n357_), .Y(new_n358_));
  AOI21x1_ASAP7_75t_R  g337(.A1(new_n119_), .A2(new_n251_), .B(\ctable[2] ), .Y(new_n359_));
  NOR2x1_ASAP7_75t_R   g338(.A(\ctable[0] ), .B(new_n51_), .Y(new_n360_));
  OA222x2_ASAP7_75t_R  g339(.A1(new_n25_), .A2(new_n196_), .B1(new_n28_), .B2(new_n51_), .C1(new_n27_), .C2(new_n360_), .Y(new_n361_));
  AO21x1_ASAP7_75t_R   g340(.A1(new_n28_), .A2(new_n195_), .B(new_n31_), .Y(new_n362_));
  OA211x2_ASAP7_75t_R  g341(.A1(new_n290_), .A2(new_n359_), .B(new_n361_), .C(new_n362_), .Y(new_n363_));
  INVx1_ASAP7_75t_R    g342(.A(new_n363_), .Y(new_n364_));
  AO21x1_ASAP7_75t_R   g343(.A1(new_n134_), .A2(new_n243_), .B(new_n355_), .Y(new_n365_));
  OR3x1_ASAP7_75t_R    g344(.A(\totalcoeffs[3] ), .B(new_n25_), .C(new_n163_), .Y(new_n366_));
  AO33x2_ASAP7_75t_R   g345(.A1(new_n51_), .A2(new_n176_), .A3(new_n218_), .B1(new_n23_), .B2(new_n366_), .B3(new_n365_), .Y(new_n367_));
  AOI221x1_ASAP7_75t_R g346(.A1(\totalcoeffs[1] ), .A2(new_n358_), .B1(new_n22_), .B2(new_n367_), .C(new_n364_), .Y(\ctoken_len[3] ));
  NOR2x1_ASAP7_75t_R   g347(.A(new_n29_), .B(new_n42_), .Y(new_n369_));
  OR5x1_ASAP7_75t_R    g348(.A(new_n24_), .B(\totalcoeffs[4] ), .C(new_n23_), .D(new_n77_), .E(new_n369_), .Y(new_n370_));
  INVx1_ASAP7_75t_R    g349(.A(new_n370_), .Y(new_n371_));
  OA211x2_ASAP7_75t_R  g350(.A1(new_n261_), .A2(new_n371_), .B(new_n28_), .C(new_n163_), .Y(\ctoken_len[4] ));
endmodule


