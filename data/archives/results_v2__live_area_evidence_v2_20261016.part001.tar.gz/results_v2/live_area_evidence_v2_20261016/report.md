# Fixed-delay shared-area recovery: complete EPFL comparison and target repeats

## Outcome and scope

Production main source/defaults/binary8f6d45dc... remain unchanged. The fixed V13experiment improves three of34legal pairs in area and ties31, with34delay ties and no area regressions in its complete20EPFL/two-library comparison. Both profiles still fail div/hyp/mem_ctrl before saturation/cuts/recovery. No full-baseline dominance, new large-design cover or project-completion claim. The cumulative experimental profile has14delay gains versus canonical main,20ties, but11larger-area tradeoffs; none is a tied-delay area regression. Small controlled area gains are not enough to promote the entire experimental pipeline as simultaneous production delay/area improvement.

All original baseline algorithms/models/native parameters remain unchanged; original240groups/520status slots remain372CEC/124reported failures/24unmeasured. Same once-resyn2 subjects, two original restricted ASAP7 inventories, public all-physical-instance area and unloaded dependent-pin delay, original named-port independent CEC. One actual global20000enodes,16cuts/class,100000retainedphysicalinstances,16saturationiterations, inclusive recovery2s, originalnative60s guard and mapping-only300s policy. CEC/conversion/metrics excluded from mapping time. Generated transient candidates are not a retained-memory/RAM cap. Earlier13403dependency baseline audit reused bySHA, not freshly rerun. Six full20DA/AD-posthoc/Pareto baseline gates remain false; MtM unconnected. No per-design source/configuration winner selection or baseline renaming.

## V13 implementation and actual feedback

The old conservative sharing bound was disabled during online area recovery because refs/users/active-instance membership would become stale after a commit. EGM_ONLINE_SHARED_BOUND(defaultfalse, isolated source) refreshes all three from the actual validated cover after each accepted online commit, before the next pruning query. Unselected-input repair, acyclicity, unique physical area and pin delay still go through the full physical scorer. New bounds only skip a proposal whose optimistic reclaimed-area lower bound cannot improve the current actual area. No extra trial count or recovery deadline.

The minimized RED complete-score fixture becomes GREEN(score2->1 with identical area/delay); a separate shared-pin fixture demonstrates that stale active membership can falsely charge an already active cell and reject a real saving.64shared DAGs compare completed passes against unpruned whole-cover recovery, with identical final metrics/bindings.111debug/release egraph-related tests pass/5ignored. These tests establish bounded cases, not universal finite-walltime PPA identity.

Initial6-design two-library factor24fresh runs allCEC.12pairs allDties,A0better/9equal/3worse; the adverse sqrt/priority observations remain. Identical physical pool hashes within pairs. Priority's dynamic branch is disabled in the adverse4in case and local-stage elapsed times diverge before any new bound query, so do not attribute every finite-walltime difference to the new pruning operation. This first factor is not a robust PPA win.

A sqrt trace reaches the late area stage with about55ms, one snapshot, zero candidate scores or commits. The next independent factor reserves60% of the same post-seed remaining global window for the existing timing-constrained area pass, leaving the phase/local stages less time. It adds no global time, physical candidates or trials. Stage checks are nonpreemptive; only success cases whose inclusive final validation completes within2s are accepted. Existing fast and legacy validated incumbents remain available for final comparison, but that is not a universal preservation theorem for every prior final shared cover across a different pool.

## Full fixed20/two-library contrast

Both same V13binary/source/helperfill1/legacy-first phase1/all6V7flags1. Control area_fraction0/onlinebound0, candidate uniform area_fraction.6/onlinebound1.80fresh native attempts,68direct original named-portCEC,12actual20000-prefix import failures; no adopted or discarded cases.34legal pairs D0better/34equal/0worse,A3better/31equal/0worse.

| Inventory | Circuit | Control area | Candidate area | Common delay |
|---|---|---:|---:|---:|
|K4|sqrt|2249.05|2246.96|47047.28|
|K3|sqrt|2153.81|2153.43|60087.26|
|K3|arbiter|775.02|774.62|900.55|

Other legal pairs tie in both metrics. Every full-study successful source/artifact/global-budget check passes. Pools are identical per pair. This is a compound allocation+fresh-bound comparison; the24run bound-only factor is retained, not relabeled as a success. The arbiter gain is not independently repeated. Primary paper tables remain canonical main; the experimental results do not replace them.

## Balanced sqrt repetitions, without best-run selection

A separate6observation3-profile screen plus12new alternating-profile-order repeat observations give18unique observations and6matched triples (two libraries times screen/r0/r1). The full-study4sqrt observations above are separate and not counted again in these18. Combined allocation+bound improves area in all6matched pairs at exactly unchangedD; allocation-only improves5and regresses1(+0.20 in3inr0). Combined versus allocation-only improves6/6. This is small targeted repeat evidence, not full20 repetition/statistical stability.

| Inventory/order | Original area | Allocation only | Allocation + fresh bound | Common delay |
|---|---:|---:|---:|---:|
|K4 screen|2249.97|2249.02|2248.97|47047.28|
|K4 r0|2249.05|2248.56|2246.96|47047.28|
|K4 r1(reverse)|2249.05|2248.75|2247.33|47047.28|
|K3 screen|2155.83|2154.26|2153.85|60087.26|
|K3 r0|2153.81|2154.01|2153.43|60087.26|
|K3 r1(reverse)|2154.31|2154.20|2153.90|60087.26|

The area reduction0.38--2.09 remains small relative to same-library emap areas1562.46/1644.87. New allocation preserves the already achieved delay parity with emap to reported precision; it does not establish strict best-baseline delay superiority. Don't combine favorable observations into a new mapper or report tiny floating path differences as meaningful timing wins.

## V14 independent source compression, all failures retained

V14is based on V12/library-source planning, NOT V13. Existing positive-first paired changes run first; zero-cost/rank-worsening first moves use only leftover slots in the original16pair trials per source root. Old positive-pass whole-source count is preserved; every new joint commit strictly lowers it. No additional truth queries/banks, graph retirement, input exemption or resident/cumulative budget substitution. RED8->8(expected7), GREEN8->7;97debug/release related tests pass/4ignored, including256layered DAG independent reachability checks.

12fresh big3/two-library attempts,0CEC/12actual import failures. Planned import uppers after zero moves:K4div20523/hyp106472/mem_ctrl25437;K3div20700/hyp111557/mem_ctrl28479. Compared with the positive-only plan, zero moves reduce the source counts by5/1642/127 and1/64/115 respectively. Every actual next distinct admission still fails after20000; source/planned counts are not actual complete imports, physical PPA, lower bounds or impossibility proofs.

## V15 independent full-source retention: rejected

The complete literal source for sqrt fits the original global budget (actual19630). A uniform structural opt-in retains every live original AND/PI/constant/PO inversion when its proven upper fits20000, otherwise uses the existing contraction. This exchanges optional-helper rewrite reserve for actual mandatory functions, without treating18000as a mandatory cap.113debug/release relevant tests pass/5ignored. Initial diagnostic-insertion assertion and failed8page paper attempts remain archived.

Fourfresh native runs all independentCEC/budgetpass, but area worsens:K4control2248.00->2456.71, K3control2153.55->2249.37, with delays unchanged47047.28/60087.26. Thus more original functions do not alone yield a better physical cover under the same16cut/100000pool caps. Representation and retained bank also change, so this is not proof of one specific missing cut or global infeasibility. No full20 promotion of this rejected factor; never splice its cases into V13.

## Source-sharing diagnostic and next work

Read-only4096random-pattern plus structured-pattern signatures identify possible equal/complement source functions. They are NOT equivalence proofs and no class/input/baseline is changed. Div/mem_ctrl show many collision candidates; hyp only36possible DIRECT class coalescences in this diagnostic. Biased arithmetic functions can collide without being equal. Direct coalescences do not bound total import savings because a proven alias can also release a unique ancestor cone. No import lower bound or impossibility conclusion follows. Use these only to prioritize exact SAT proof before any canonical-source aliasing, and keep native/mapping budgets unchanged.

For area, next implement exact incremental physical ref/deref for already selected input cones, with reversible joint-output transactions and safe updated arrival/required-time envelopes. Full-cover clone/prune/score is still expensive. Detailed proof obligations and REDfixtures in live_shared_area_implementation_20261016/incremental_area_design.md. Keep original full-score fallback for unselected-input repairs, preserve the fast validatedD and old shared-area incumbent, and verify full20/target repeats before adoption. Industrial multioutput/ODC/independent regional saturation remain unfinished.

## Accounting and artifacts

Six independent studies:24boundfactor+6allocation screen+12zero-source+4full-source+80fullEPFL+12fresh sqrt repeats=138fresh attempts,114directCEC/24actualnode failures. This is resource accounting across versions, not a combined mapper result. Overlapping target views are not added. Source/patches/Cargo/native binaries/failing tests in the three implementation directories; exact argv/env/clock audits and logs in frozen campaigns. Every successful result has an independent original-input command/metric/budget proof in independent_command_audit.json; output/netlist hashes absent from checkpoints are explicitly first captured by this audit. Initial readonly library-basename resolution error retained in live_area_evidence_20261016; corrected final evidence is thisv2directory. Raw native data and original failures untouched.

Post-study exact diagnostic: nine source-function miters selected from simulation collision groups give seven SATcounterexamples, one unknown and one proved hyp pair. Four independent miter polarity/positive/negative checks pass. This strengthens the requirement for exact proof before alias merging; no input/class changes, no mapped PPA, no extra mappingCEC counted. See source_alias_proof_probe_20261016/diagnosis.md. Any future use must be inside the mapper budget, not free per-input advice.
