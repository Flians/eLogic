"""Read-only audit of typed-main settings, import ledger and scored-cover work."""
import json
from pathlib import Path
ROOT=Path('/home/flynn/workplace/MIGBalance')
load=lambda p:json.loads(p.read_text())
out=Path(__file__).resolve().parent
reports=[ROOT/'results_v2/scored_main_full_report_20261015',ROOT/'results_v2/scored_main_repeats_report_20261015']
observations=[]
for report in reports:
 summary=load(report/'validation.json')
 assert not summary['budget_errors'] and not summary['artifact_hash_errors']
 assert load(report/'import_gate.json')['pass_gate']
 for item in load(report/'all_rows.json'):
  row=item['row'];active=item['profile']=='protected_area';settings=row['settings']
  assert settings['EGM_CONE_IMPORT']==str(int(active))
  assert settings['EGM_SCORED_INCUMBENT']==str(int(active))
  if row['status']!='ok':continue
  assert row['measured']['cec']==1
  trace=item['trace']
  events=trace['events']
  scored=[e['data'] for e in events if e['stage']=='scored_incumbent']
  if active:
   assert len(scored)==1 and scored[0]['additional_evaluations']==0
  if not active:assert not scored
  plan=Path(settings['EGM_POOL_DIAG_PATH']).with_suffix('.import-plan.json')
  ledger=plan.with_name('pool-diagnostics.import.json')
  d=load(ledger)
  if load(plan)['xor_import']:
   assert d['schema_version']==2
   assert d['actual_imported_enodes']==row['native']['imported_enodes']
   assert d['actual_helpers']<=2048
  observations.append(dict(report=item['report'],profile=item['profile'],k=item['k'],bench=item['bench'],scored=scored))
# Reference observations in repeated summaries overlap the full report.
unique={r['report']:r for r in observations}
result=dict(unique_direct_cec_reports=len(unique),successful_status_observations=len(observations),
            scored_events_with_additional_evaluations=sum(bool(s['additional_evaluations']) for r in observations for s in r['scored']),
            source_operator_counter_schema=2,baseline_algorithms_changed=False,
            richer_enode_unit_is_not_expanded_AND_work_unit=True,
            report_paths=[str(p) for p in reports],observations=list(unique.values()))
(out/'typed_main_audit.json').write_text(json.dumps(result,indent=2)+'\n')
print({k:v for k,v in result.items() if k!='observations'})
