"""Verify frozen source and recorded artifacts after all finite native batches."""
import fcntl,hashlib,json,shutil
from pathlib import Path
ROOT=Path('/home/flynn/workplace/MIGBalance');OUT=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
errors=[];checked=0;campaigns=[]
for rel in ['scored_main_full_20261015','scored_main_repeats_20261015','epfl_original_baselines_resumed_checkpoint_20261013']:
 path=ROOT/'results_v2'/rel/'campaign.json';c=json.loads(path.read_text())
 lock=path.with_name('runner.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 if rel.startswith('scored_main_'):
  assert c['status']=='attempted' and len(c['jobs'])==c['expected_jobs']
  for p,h in c['fingerprint'].items():
   checked+=1
   if not Path(p).is_file() or sha(Path(p))!=h:errors.append(p)
 for j in c['jobs']:
  for key in ['report','audit','trace','pool','candidates','diagnostic_profile']:
   if key in j and key+'_sha256' in j:
    p=Path(j[key]);checked+=1
    if not p.is_file() or sha(p)!=j[key+'_sha256']:errors.append(str(p))
 campaigns.append(dict(path=str(path),sha256=sha(path),jobs=len(c['jobs'])))
 fcntl.flock(lock,fcntl.LOCK_UN);lock.close()
# Full source capsule for the previously qualified prototype.
proto=Path('/tmp/emapper-scored-incumbent-20261015/emapper/src')
dest=ROOT/'results_v2/scored_incumbent_implementation_20261015/source/all_emapper_src'
if not dest.exists():shutil.copytree(proto,dest)
assert {p.name:sha(p) for p in proto.glob('*.rs')}=={p.name:sha(p) for p in dest.glob('*.rs')}
main_source=OUT/'source/emapper/src'
assert {p.name:sha(p) for p in (ROOT/'emapper/src').glob('*.rs')}=={p.name:sha(p) for p in main_source.glob('*.rs')}
assert sha(ROOT/'target/release/bench_rs_egraph_map')==sha(OUT/'mapper.bin')
result=dict(artifact_checks=checked,errors=errors,campaigns=campaigns,checked_campaign_runner_locks_idle=True,
 mapper_sha256=sha(ROOT/'target/release/bench_rs_egraph_map'),evaluator_sha256=sha(ROOT/'target/release/bench_rs_netlist_eval'),
 complete_prototype_source_archived=True,baseline_algorithms_changed=False,defaults_unchanged=True)
(OUT/'final_audit.json').write_text(json.dumps(result,indent=2)+'\n');print(result);assert not errors
