# emapper recovery handoff

The current thread recovered after a remote-compaction failure. This does not establish a permanent service-side fix. Exact user request ID: 795d4efe-609f-40bd-a160-79dff60b8d5a. Related same-thread errors and checkpoint SHA are in diagnostic.json. No account tokens or full session text were exported.

Baseline checkpoint: results_v2/epfl_original_baselines_queuebridge_checkpoint_20261013/campaign.json. 175/240 jobs recorded at inspection. No runner process found; the JSON running status is stale. Current partial job: 4in_eqmap_area-delay_square. Its directory/log/audit must be audited before explicit recovery; do not overwrite or silently skip. Session 92977 is unavailable. Check all locks and dependencies before any continuation. Do not launch a duplicate campaign.

All methods use the one-resyn2 EPFL20 manifest results_v2/epfl_resyn2_subjects_20261012/report.json. Baseline algorithms/models/native parameters unchanged. Mapping-only 300s excludes conversion/CEC/metrics; preserve original native guards and failures. Same input/library/public physical area and pin delay plus named-port CEC.

Main queue-delay profile is opt-in; defaults remain legacy. Full same-binary coupled-queue comparison: 22 valid pairs, delay 6 better/16 equal, area 8 better/10 equal/4 worse including 2 delay-tie area regressions. Evidence: epfl_event_current_flow_full_20261013; repeated study epfl_event_repeats_full_20261013; main acceptance main_queue_profile_acceptance_20261013. No global Pareto victory.

Isolated compact phase-edge import: /tmp/emapper-literal-import-20261013. Three 3in delay-first CEC successes arbiter/voter/square, PPA still behind conventional baselines; sqrt failed global 2s recovery deadline. Not integrated into main. Sources/tests/failed trials preserved in literal_import_implementation_20261013. No node-budget increase or original-input exemption.

CEC script-file transport fixes OS argv limits without baseline optimization: cec_scriptfile_transport_20261013 and cec_scriptfile_mem_ctrl_replay_20261013. Preserve original failures and explicit verification-only replay provenance.

Paper epmapping_paper/DAC-eGraphMap-draft/main.tex and output/pdf/DAC-eGraphMap-draft.pdf have 6 body + 1 references, QA under queue_profile_main_integration_20261013. Full baseline coverage still pending; old tables remain labelled ISCAS pilot. Read emapper/BASELINES.md for provenance. Never mix per-design source/config winners or report missing/failed cases as successes.

If this long chat becomes unrecoverable, a fresh chat may use this handoff and the checkpoint files. Do not create a new chat without the user's request. Keep subsequent tool output concise.
