module AND2x2_ASAP7_75t_R(A, B, Y);
  input A;
  input B;
  output Y;
  assign Y = (A) & (B);
endmodule
module AND3x1_ASAP7_75t_R(A, B, C, Y);
  input A;
  input B;
  input C;
  output Y;
  assign Y = ((A) & (B)) & (C);
endmodule
module AND4x2_ASAP7_75t_R(A, B, C, D, Y);
  input A;
  input B;
  input C;
  input D;
  output Y;
  assign Y = (((A) & (B)) & (C)) & (D);
endmodule
module AO211x2_ASAP7_75t_R(A1, A2, B, C, Y);
  input A1;
  input A2;
  input B;
  input C;
  output Y;
  assign Y = (((A1) & (A2)) | (B)) | (C);
endmodule
module AO21x1_ASAP7_75t_R(A1, A2, B, Y);
  input A1;
  input A2;
  input B;
  output Y;
  assign Y = ((A1) & (A2)) | (B);
endmodule
module AO22x1_ASAP7_75t_R(A1, A2, B1, B2, Y);
  input A1;
  input A2;
  input B1;
  input B2;
  output Y;
  assign Y = ((A1) & (A2)) | ((B1) & (B2));
endmodule
module AO31x2_ASAP7_75t_R(A1, A2, A3, B, Y);
  input A1;
  input A2;
  input A3;
  input B;
  output Y;
  assign Y = (((A1) & (A2)) & (A3)) | (B);
endmodule
module AOI211x1_ASAP7_75t_R(A1, A2, B, C, Y);
  input A1;
  input A2;
  input B;
  input C;
  output Y;
  assign Y = (((~(A1)) & (~(B))) & (~(C))) | (((~(A2)) & (~(B))) & (~(C)));
endmodule
module AOI21x1_ASAP7_75t_R(A1, A2, B, Y);
  input A1;
  input A2;
  input B;
  output Y;
  assign Y = ((~(A1)) & (~(B))) | ((~(A2)) & (~(B)));
endmodule
module AOI22x1_ASAP7_75t_R(A1, A2, B1, B2, Y);
  input A1;
  input A2;
  input B1;
  input B2;
  output Y;
  assign Y = ((((~(A1)) & (~(B1))) | ((~(A1)) & (~(B2)))) | ((~(A2)) & (~(B1)))) | ((~(A2)) & (~(B2)));
endmodule
module BUFx2_ASAP7_75t_R(A, Y);
  input A;
  output Y;
  assign Y = A;
endmodule
module INVx1_ASAP7_75t_R(A, Y);
  input A;
  output Y;
  assign Y = ~(A);
endmodule
module MAJx2_ASAP7_75t_R(A, B, C, Y);
  input A;
  input B;
  input C;
  output Y;
  assign Y = (((A) & (B)) | ((A) & (C))) | ((B) & (C));
endmodule
module NAND2x1_ASAP7_75t_R(A, B, Y);
  input A;
  input B;
  output Y;
  assign Y = (~(A)) | (~(B));
endmodule
module NAND3x1_ASAP7_75t_R(A, B, C, Y);
  input A;
  input B;
  input C;
  output Y;
  assign Y = ((~(A)) | (~(B))) | (~(C));
endmodule
module NOR2x1_ASAP7_75t_R(A, B, Y);
  input A;
  input B;
  output Y;
  assign Y = (~(A)) & (~(B));
endmodule
module NOR3x1_ASAP7_75t_R(A, B, C, Y);
  input A;
  input B;
  input C;
  output Y;
  assign Y = ((~(A)) & (~(B))) & (~(C));
endmodule
module OA211x2_ASAP7_75t_R(A1, A2, B, C, Y);
  input A1;
  input A2;
  input B;
  input C;
  output Y;
  assign Y = (((A1) & (B)) & (C)) | (((A2) & (B)) & (C));
endmodule
module OA21x2_ASAP7_75t_R(A1, A2, B, Y);
  input A1;
  input A2;
  input B;
  output Y;
  assign Y = ((A1) & (B)) | ((A2) & (B));
endmodule
module OA22x2_ASAP7_75t_R(A1, A2, B1, B2, Y);
  input A1;
  input A2;
  input B1;
  input B2;
  output Y;
  assign Y = ((((A1) & (B1)) | ((A1) & (B2))) | ((A2) & (B1))) | ((A2) & (B2));
endmodule
module OA31x2_ASAP7_75t_R(A1, A2, A3, B1, Y);
  input A1;
  input A2;
  input A3;
  input B1;
  output Y;
  assign Y = (((A1) & (B1)) | ((A2) & (B1))) | ((A3) & (B1));
endmodule
module OAI21x1_ASAP7_75t_R(A1, A2, B, Y);
  input A1;
  input A2;
  input B;
  output Y;
  assign Y = ((~(A1)) & (~(A2))) | (~(B));
endmodule
module OAI22x1_ASAP7_75t_R(A1, A2, B1, B2, Y);
  input A1;
  input A2;
  input B1;
  input B2;
  output Y;
  assign Y = ((~(A1)) & (~(A2))) | ((~(B1)) & (~(B2)));
endmodule
module OR2x4_ASAP7_75t_R(A, B, Y);
  input A;
  input B;
  output Y;
  assign Y = (A) | (B);
endmodule
module OR3x1_ASAP7_75t_R(A, B, C, Y);
  input A;
  input B;
  input C;
  output Y;
  assign Y = ((A) | (B)) | (C);
endmodule
module OR4x2_ASAP7_75t_R(A, B, C, D, Y);
  input A;
  input B;
  input C;
  input D;
  output Y;
  assign Y = (((A) | (B)) | (C)) | (D);
endmodule
module XNOR2x2_ASAP7_75t_R(A, B, Y);
  input A;
  input B;
  output Y;
  assign Y = ((A) & (B)) | ((~(A)) & (~(B)));
endmodule
module XOR2x2_ASAP7_75t_R(A, B, Y);
  input A;
  input B;
  output Y;
  assign Y = ((A) & (~(B))) | ((~(A)) & (B));
endmodule
module _const0_(z);
  output z;
  assign z = 1'b0;
endmodule
module _const1_(z);
  output z;
  assign z = 1'b1;
endmodule
