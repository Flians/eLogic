module AND2x2_ASAP7_75t_R(A, B, Y);
  input A;
  input B;
  output Y;
  assign Y = (A) & (B);
endmodule
module AND3x1_ASAP7_75t_R(A, B, C, Y);
  input A;
  input B;
  input C;
  output Y;
  assign Y = ((A) & (B)) & (C);
endmodule
module AO21x1_ASAP7_75t_R(A1, A2, B, Y);
  input A1;
  input A2;
  input B;
  output Y;
  assign Y = ((A1) & (A2)) | (B);
endmodule
module AOI21x1_ASAP7_75t_R(A1, A2, B, Y);
  input A1;
  input A2;
  input B;
  output Y;
  assign Y = ((~(A1)) & (~(B))) | ((~(A2)) & (~(B)));
endmodule
module BUFx2_ASAP7_75t_R(A, Y);
  input A;
  output Y;
  assign Y = A;
endmodule
module INVx1_ASAP7_75t_R(A, Y);
  input A;
  output Y;
  assign Y = ~(A);
endmodule
module MAJx2_ASAP7_75t_R(A, B, C, Y);
  input A;
  input B;
  input C;
  output Y;
  assign Y = (((A) & (B)) | ((A) & (C))) | ((B) & (C));
endmodule
module NAND2x1_ASAP7_75t_R(A, B, Y);
  input A;
  input B;
  output Y;
  assign Y = (~(A)) | (~(B));
endmodule
module NAND3x1_ASAP7_75t_R(A, B, C, Y);
  input A;
  input B;
  input C;
  output Y;
  assign Y = ((~(A)) | (~(B))) | (~(C));
endmodule
module NOR2x1_ASAP7_75t_R(A, B, Y);
  input A;
  input B;
  output Y;
  assign Y = (~(A)) & (~(B));
endmodule
module NOR3x1_ASAP7_75t_R(A, B, C, Y);
  input A;
  input B;
  input C;
  output Y;
  assign Y = ((~(A)) & (~(B))) & (~(C));
endmodule
module OA21x2_ASAP7_75t_R(A1, A2, B, Y);
  input A1;
  input A2;
  input B;
  output Y;
  assign Y = ((A1) & (B)) | ((A2) & (B));
endmodule
module OAI21x1_ASAP7_75t_R(A1, A2, B, Y);
  input A1;
  input A2;
  input B;
  output Y;
  assign Y = ((~(A1)) & (~(A2))) | (~(B));
endmodule
module OR2x4_ASAP7_75t_R(A, B, Y);
  input A;
  input B;
  output Y;
  assign Y = (A) | (B);
endmodule
module OR3x1_ASAP7_75t_R(A, B, C, Y);
  input A;
  input B;
  input C;
  output Y;
  assign Y = ((A) | (B)) | (C);
endmodule
module XNOR2x2_ASAP7_75t_R(A, B, Y);
  input A;
  input B;
  output Y;
  assign Y = ((A) & (B)) | ((~(A)) & (~(B)));
endmodule
module XOR2x2_ASAP7_75t_R(A, B, Y);
  input A;
  input B;
  output Y;
  assign Y = ((A) & (~(B))) | ((~(A)) & (B));
endmodule
module _const0_(z);
  output z;
  assign z = 1'b0;
endmodule
module _const1_(z);
  output z;
  assign z = 1'b1;
endmodule
