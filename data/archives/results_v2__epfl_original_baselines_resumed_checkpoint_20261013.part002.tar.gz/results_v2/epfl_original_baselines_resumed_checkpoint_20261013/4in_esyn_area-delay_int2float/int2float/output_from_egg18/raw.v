// Benchmark "/home/flynn/workplace/MIGBalance/results_v2/epfl_original_baselines_resumed_checkpoint_20261013/4in_esyn_area-delay_int2float/int2float/output_from_egg18/logic" written by ABC on Tue Oct 13 18:58:44 2026

module \/home/flynn/workplace/MIGBalance/results_v2/epfl_original_baselines_resumed_checkpoint_20261013/4in_esyn_area-delay_int2float/int2float/output_from_egg18/logic  ( 
    \B[1] , \B[2] , \B[3] , \B[4] , \B[5] , \B[6] , \B[7] , \B[8] , \B[9] ,
    \B[10] , \B[0] ,
    \M[0] , \M[1] , \M[2] , \M[3] , \E[0] , \E[1] , \E[2]   );
  input  \B[1] , \B[2] , \B[3] , \B[4] , \B[5] , \B[6] , \B[7] , \B[8] ,
    \B[9] , \B[10] , \B[0] ;
  output \M[0] , \M[1] , \M[2] , \M[3] , \E[0] , \E[1] , \E[2] ;
  wire new_n19_, new_n20_, new_n21_, new_n22_, new_n23_, new_n24_, new_n25_,
    new_n26_, new_n27_, new_n28_, new_n29_, new_n30_, new_n31_, new_n32_,
    new_n33_, new_n34_, new_n35_, new_n36_, new_n37_, new_n38_, new_n39_,
    new_n40_, new_n41_, new_n42_, new_n43_, new_n44_, new_n45_, new_n46_,
    new_n47_, new_n48_, new_n49_, new_n50_, new_n51_, new_n52_, new_n53_,
    new_n54_, new_n55_, new_n56_, new_n57_, new_n58_, new_n59_, new_n60_,
    new_n61_, new_n62_, new_n63_, new_n64_, new_n65_, new_n66_, new_n68_,
    new_n69_, new_n70_, new_n71_, new_n72_, new_n73_, new_n74_, new_n75_,
    new_n76_, new_n77_, new_n78_, new_n79_, new_n80_, new_n81_, new_n82_,
    new_n83_, new_n84_, new_n85_, new_n86_, new_n87_, new_n88_, new_n89_,
    new_n90_, new_n91_, new_n92_, new_n93_, new_n94_, new_n95_, new_n96_,
    new_n97_, new_n98_, new_n99_, new_n101_, new_n102_, new_n103_,
    new_n104_, new_n105_, new_n106_, new_n107_, new_n108_, new_n109_,
    new_n110_, new_n111_, new_n112_, new_n113_, new_n114_, new_n115_,
    new_n116_, new_n117_, new_n118_, new_n119_, new_n120_, new_n121_,
    new_n122_, new_n123_, new_n124_, new_n125_, new_n126_, new_n128_,
    new_n129_, new_n130_, new_n131_, new_n132_, new_n133_, new_n135_,
    new_n136_, new_n137_, new_n138_, new_n139_, new_n140_, new_n141_,
    new_n142_, new_n143_, new_n144_, new_n145_, new_n146_, new_n148_,
    new_n149_, new_n150_, new_n151_, new_n152_, new_n153_;
  INVx1_ASAP7_75t_R    g000(.A(\B[1] ), .Y(new_n19_));
  INVx1_ASAP7_75t_R    g001(.A(\B[2] ), .Y(new_n20_));
  INVx1_ASAP7_75t_R    g002(.A(\B[3] ), .Y(new_n21_));
  INVx1_ASAP7_75t_R    g003(.A(\B[4] ), .Y(new_n22_));
  INVx1_ASAP7_75t_R    g004(.A(\B[5] ), .Y(new_n23_));
  INVx1_ASAP7_75t_R    g005(.A(\B[6] ), .Y(new_n24_));
  INVx1_ASAP7_75t_R    g006(.A(\B[7] ), .Y(new_n25_));
  INVx1_ASAP7_75t_R    g007(.A(\B[8] ), .Y(new_n26_));
  INVx1_ASAP7_75t_R    g008(.A(\B[9] ), .Y(new_n27_));
  INVx1_ASAP7_75t_R    g009(.A(\B[10] ), .Y(new_n28_));
  INVx1_ASAP7_75t_R    g010(.A(\B[0] ), .Y(new_n29_));
  NOR2x1_ASAP7_75t_R   g011(.A(new_n22_), .B(new_n26_), .Y(new_n30_));
  INVx1_ASAP7_75t_R    g012(.A(new_n30_), .Y(new_n31_));
  OA21x2_ASAP7_75t_R   g013(.A1(new_n19_), .A2(new_n22_), .B(new_n29_), .Y(new_n32_));
  OR3x1_ASAP7_75t_R    g014(.A(\B[6] ), .B(\B[7] ), .C(new_n32_), .Y(new_n33_));
  AO22x1_ASAP7_75t_R   g015(.A1(\B[1] ), .A2(\B[4] ), .B1(new_n22_), .B2(\B[8] ), .Y(new_n34_));
  AO21x1_ASAP7_75t_R   g016(.A1(\B[0] ), .A2(new_n34_), .B(new_n33_), .Y(new_n35_));
  AO21x1_ASAP7_75t_R   g017(.A1(new_n31_), .A2(new_n35_), .B(\B[5] ), .Y(new_n36_));
  NAND2x1_ASAP7_75t_R  g018(.A(new_n20_), .B(new_n25_), .Y(new_n37_));
  AND4x2_ASAP7_75t_R   g019(.A(\B[1] ), .B(\B[5] ), .C(new_n20_), .D(new_n25_), .Y(new_n38_));
  AOI21x1_ASAP7_75t_R  g020(.A1(new_n22_), .A2(\B[7] ), .B(new_n38_), .Y(new_n39_));
  OR3x1_ASAP7_75t_R    g021(.A(\B[3] ), .B(new_n22_), .C(new_n25_), .Y(new_n40_));
  OA21x2_ASAP7_75t_R   g022(.A1(new_n21_), .A2(new_n39_), .B(new_n40_), .Y(new_n41_));
  NOR2x1_ASAP7_75t_R   g023(.A(\B[4] ), .B(new_n23_), .Y(new_n42_));
  OR3x1_ASAP7_75t_R    g024(.A(\B[4] ), .B(new_n23_), .C(new_n26_), .Y(new_n43_));
  OA211x2_ASAP7_75t_R  g025(.A1(\B[8] ), .A2(new_n41_), .B(new_n43_), .C(new_n36_), .Y(new_n44_));
  OR3x1_ASAP7_75t_R    g026(.A(\B[5] ), .B(new_n24_), .C(new_n27_), .Y(new_n45_));
  NAND2x1_ASAP7_75t_R  g027(.A(new_n25_), .B(new_n26_), .Y(new_n46_));
  AND4x2_ASAP7_75t_R   g028(.A(new_n25_), .B(new_n26_), .C(new_n19_), .D(\B[2] ), .Y(new_n47_));
  OA211x2_ASAP7_75t_R  g029(.A1(\B[4] ), .A2(new_n25_), .B(\B[1] ), .C(new_n20_), .Y(new_n48_));
  NOR2x1_ASAP7_75t_R   g030(.A(new_n21_), .B(new_n22_), .Y(new_n49_));
  INVx1_ASAP7_75t_R    g031(.A(new_n49_), .Y(new_n50_));
  AND3x1_ASAP7_75t_R   g032(.A(new_n31_), .B(new_n50_), .C(new_n48_), .Y(new_n51_));
  OR3x1_ASAP7_75t_R    g033(.A(\B[9] ), .B(new_n47_), .C(new_n51_), .Y(new_n52_));
  INVx1_ASAP7_75t_R    g034(.A(new_n52_), .Y(new_n53_));
  OR3x1_ASAP7_75t_R    g035(.A(new_n23_), .B(\B[6] ), .C(new_n53_), .Y(new_n54_));
  OA211x2_ASAP7_75t_R  g036(.A1(\B[9] ), .A2(new_n44_), .B(new_n45_), .C(new_n54_), .Y(new_n55_));
  INVx1_ASAP7_75t_R    g037(.A(new_n55_), .Y(new_n56_));
  NOR2x1_ASAP7_75t_R   g038(.A(\B[6] ), .B(new_n25_), .Y(new_n57_));
  NOR2x1_ASAP7_75t_R   g039(.A(\B[8] ), .B(\B[9] ), .Y(new_n58_));
  INVx1_ASAP7_75t_R    g040(.A(new_n58_), .Y(new_n59_));
  NOR2x1_ASAP7_75t_R   g041(.A(\B[2] ), .B(new_n21_), .Y(new_n60_));
  AO21x1_ASAP7_75t_R   g042(.A1(\B[2] ), .A2(new_n21_), .B(new_n60_), .Y(new_n61_));
  AO21x1_ASAP7_75t_R   g043(.A1(new_n58_), .A2(new_n61_), .B(\B[10] ), .Y(new_n62_));
  NOR2x1_ASAP7_75t_R   g044(.A(new_n26_), .B(new_n28_), .Y(new_n63_));
  INVx1_ASAP7_75t_R    g045(.A(new_n63_), .Y(new_n64_));
  AO22x1_ASAP7_75t_R   g046(.A1(new_n25_), .A2(new_n62_), .B1(\B[9] ), .B2(new_n63_), .Y(new_n65_));
  AO22x1_ASAP7_75t_R   g047(.A1(\B[10] ), .A2(new_n57_), .B1(\B[6] ), .B2(new_n65_), .Y(new_n66_));
  AO21x1_ASAP7_75t_R   g048(.A1(new_n28_), .A2(new_n56_), .B(new_n66_), .Y(\M[0] ));
  NOR2x1_ASAP7_75t_R   g049(.A(new_n19_), .B(new_n20_), .Y(new_n68_));
  OA211x2_ASAP7_75t_R  g050(.A1(\B[7] ), .A2(new_n68_), .B(\B[4] ), .C(new_n58_), .Y(new_n69_));
  AND4x2_ASAP7_75t_R   g051(.A(new_n22_), .B(new_n24_), .C(new_n25_), .D(new_n68_), .Y(new_n70_));
  OAI21x1_ASAP7_75t_R  g052(.A1(new_n69_), .A2(new_n70_), .B(\B[3] ), .Y(new_n71_));
  NAND2x1_ASAP7_75t_R  g053(.A(new_n22_), .B(new_n27_), .Y(new_n72_));
  NAND2x1_ASAP7_75t_R  g054(.A(new_n25_), .B(\B[9] ), .Y(new_n73_));
  AND4x2_ASAP7_75t_R   g055(.A(\B[6] ), .B(new_n59_), .C(new_n72_), .D(new_n73_), .Y(new_n74_));
  INVx1_ASAP7_75t_R    g056(.A(new_n74_), .Y(new_n75_));
  AO21x1_ASAP7_75t_R   g057(.A1(new_n71_), .A2(new_n75_), .B(new_n23_), .Y(new_n76_));
  OR3x1_ASAP7_75t_R    g058(.A(\B[4] ), .B(new_n26_), .C(\B[9] ), .Y(new_n77_));
  AO21x1_ASAP7_75t_R   g059(.A1(new_n73_), .A2(new_n77_), .B(\B[6] ), .Y(new_n78_));
  OR3x1_ASAP7_75t_R    g060(.A(new_n25_), .B(new_n59_), .C(new_n49_), .Y(new_n79_));
  AO21x1_ASAP7_75t_R   g061(.A1(new_n37_), .A2(new_n72_), .B(\B[1] ), .Y(new_n80_));
  OA211x2_ASAP7_75t_R  g062(.A1(new_n20_), .A2(\B[0] ), .B(\B[4] ), .C(new_n25_), .Y(new_n81_));
  OAI21x1_ASAP7_75t_R  g063(.A1(new_n29_), .A2(new_n68_), .B(new_n81_), .Y(new_n82_));
  OA211x2_ASAP7_75t_R  g064(.A1(new_n26_), .A2(\B[9] ), .B(new_n80_), .C(new_n82_), .Y(new_n83_));
  OA211x2_ASAP7_75t_R  g065(.A1(\B[6] ), .A2(new_n83_), .B(new_n73_), .C(new_n79_), .Y(new_n84_));
  OA211x2_ASAP7_75t_R  g066(.A1(\B[5] ), .A2(new_n84_), .B(new_n76_), .C(new_n78_), .Y(new_n85_));
  NOR2x1_ASAP7_75t_R   g067(.A(new_n24_), .B(new_n25_), .Y(new_n86_));
  INVx1_ASAP7_75t_R    g068(.A(new_n86_), .Y(new_n87_));
  AND3x1_ASAP7_75t_R   g069(.A(\B[6] ), .B(\B[7] ), .C(new_n27_), .Y(new_n88_));
  OR3x1_ASAP7_75t_R    g070(.A(new_n24_), .B(\B[9] ), .C(\B[4] ), .Y(new_n89_));
  OR3x1_ASAP7_75t_R    g071(.A(\B[3] ), .B(new_n23_), .C(\B[6] ), .Y(new_n90_));
  NAND2x1_ASAP7_75t_R  g072(.A(new_n89_), .B(new_n90_), .Y(new_n91_));
  AND3x1_ASAP7_75t_R   g073(.A(\B[3] ), .B(\B[4] ), .C(\B[2] ), .Y(new_n92_));
  AND3x1_ASAP7_75t_R   g074(.A(\B[6] ), .B(new_n27_), .C(new_n92_), .Y(new_n93_));
  AOI21x1_ASAP7_75t_R  g075(.A1(new_n20_), .A2(new_n91_), .B(new_n93_), .Y(new_n94_));
  OR3x1_ASAP7_75t_R    g076(.A(new_n23_), .B(\B[6] ), .C(\B[1] ), .Y(new_n95_));
  AO21x1_ASAP7_75t_R   g077(.A1(new_n89_), .A2(new_n95_), .B(\B[3] ), .Y(new_n96_));
  AOI21x1_ASAP7_75t_R  g078(.A1(new_n94_), .A2(new_n96_), .B(\B[7] ), .Y(new_n97_));
  OA211x2_ASAP7_75t_R  g079(.A1(\B[10] ), .A2(new_n97_), .B(new_n26_), .C(new_n87_), .Y(new_n98_));
  AOI21x1_ASAP7_75t_R  g080(.A1(new_n63_), .A2(new_n88_), .B(new_n98_), .Y(new_n99_));
  OA21x2_ASAP7_75t_R   g081(.A1(\B[10] ), .A2(new_n85_), .B(new_n99_), .Y(\M[1] ));
  NOR2x1_ASAP7_75t_R   g082(.A(new_n24_), .B(\B[7] ), .Y(new_n101_));
  AO22x1_ASAP7_75t_R   g083(.A1(\B[3] ), .A2(new_n57_), .B1(new_n20_), .B2(new_n101_), .Y(new_n102_));
  NOR2x1_ASAP7_75t_R   g084(.A(new_n22_), .B(new_n23_), .Y(new_n103_));
  INVx1_ASAP7_75t_R    g085(.A(new_n103_), .Y(new_n104_));
  AO22x1_ASAP7_75t_R   g086(.A1(new_n102_), .A2(new_n103_), .B1(new_n86_), .B2(new_n104_), .Y(new_n105_));
  AND4x2_ASAP7_75t_R   g087(.A(new_n21_), .B(\B[4] ), .C(new_n24_), .D(\B[0] ), .Y(new_n106_));
  AO21x1_ASAP7_75t_R   g088(.A1(\B[3] ), .A2(new_n42_), .B(new_n106_), .Y(new_n107_));
  NOR2x1_ASAP7_75t_R   g089(.A(new_n19_), .B(new_n29_), .Y(new_n108_));
  OAI22x1_ASAP7_75t_R  g090(.A1(\B[4] ), .A2(\B[6] ), .B1(new_n50_), .B2(new_n108_), .Y(new_n109_));
  AO22x1_ASAP7_75t_R   g091(.A1(\B[1] ), .A2(new_n107_), .B1(new_n23_), .B2(new_n109_), .Y(new_n110_));
  AO22x1_ASAP7_75t_R   g092(.A1(new_n21_), .A2(\B[5] ), .B1(new_n24_), .B2(new_n60_), .Y(new_n111_));
  AO22x1_ASAP7_75t_R   g093(.A1(\B[2] ), .A2(new_n110_), .B1(\B[4] ), .B2(new_n111_), .Y(new_n112_));
  NOR2x1_ASAP7_75t_R   g094(.A(new_n23_), .B(new_n24_), .Y(new_n113_));
  OR3x1_ASAP7_75t_R    g095(.A(\B[5] ), .B(new_n24_), .C(new_n20_), .Y(new_n114_));
  NAND2x1_ASAP7_75t_R  g096(.A(new_n95_), .B(new_n114_), .Y(new_n115_));
  AO22x1_ASAP7_75t_R   g097(.A1(new_n50_), .A2(new_n113_), .B1(new_n49_), .B2(new_n115_), .Y(new_n116_));
  AO21x1_ASAP7_75t_R   g098(.A1(new_n25_), .A2(new_n112_), .B(new_n116_), .Y(new_n117_));
  AO21x1_ASAP7_75t_R   g099(.A1(new_n26_), .A2(new_n117_), .B(new_n105_), .Y(new_n118_));
  AND3x1_ASAP7_75t_R   g100(.A(\B[6] ), .B(new_n25_), .C(new_n103_), .Y(new_n119_));
  OA21x2_ASAP7_75t_R   g101(.A1(new_n57_), .A2(new_n119_), .B(\B[8] ), .Y(new_n120_));
  AOI21x1_ASAP7_75t_R  g102(.A1(new_n27_), .A2(new_n118_), .B(new_n120_), .Y(new_n121_));
  AO21x1_ASAP7_75t_R   g103(.A1(\B[5] ), .A2(\B[7] ), .B(new_n26_), .Y(new_n122_));
  AO21x1_ASAP7_75t_R   g104(.A1(new_n28_), .A2(new_n122_), .B(new_n27_), .Y(new_n123_));
  OR3x1_ASAP7_75t_R    g105(.A(new_n23_), .B(\B[8] ), .C(new_n27_), .Y(new_n124_));
  AO21x1_ASAP7_75t_R   g106(.A1(new_n64_), .A2(new_n124_), .B(new_n87_), .Y(new_n125_));
  OA211x2_ASAP7_75t_R  g107(.A1(\B[10] ), .A2(new_n121_), .B(new_n123_), .C(new_n125_), .Y(new_n126_));
  INVx1_ASAP7_75t_R    g108(.A(new_n126_), .Y(\M[2] ));
  NOR2x1_ASAP7_75t_R   g109(.A(\B[9] ), .B(\B[10] ), .Y(new_n128_));
  NOR2x1_ASAP7_75t_R   g110(.A(\B[5] ), .B(\B[6] ), .Y(new_n129_));
  AND4x2_ASAP7_75t_R   g111(.A(new_n22_), .B(new_n25_), .C(new_n26_), .D(new_n129_), .Y(new_n130_));
  AND3x1_ASAP7_75t_R   g112(.A(\B[5] ), .B(\B[6] ), .C(\B[7] ), .Y(new_n131_));
  AND3x1_ASAP7_75t_R   g113(.A(new_n20_), .B(new_n30_), .C(new_n131_), .Y(new_n132_));
  OA211x2_ASAP7_75t_R  g114(.A1(new_n130_), .A2(new_n132_), .B(new_n21_), .C(new_n128_), .Y(new_n133_));
  INVx1_ASAP7_75t_R    g115(.A(new_n133_), .Y(\M[3] ));
  AO21x1_ASAP7_75t_R   g116(.A1(new_n25_), .A2(new_n68_), .B(new_n113_), .Y(new_n135_));
  NOR2x1_ASAP7_75t_R   g117(.A(\B[5] ), .B(\B[7] ), .Y(new_n136_));
  AO21x1_ASAP7_75t_R   g118(.A1(\B[3] ), .A2(new_n135_), .B(new_n136_), .Y(new_n137_));
  AO21x1_ASAP7_75t_R   g119(.A1(\B[4] ), .A2(new_n137_), .B(new_n101_), .Y(new_n138_));
  AOI21x1_ASAP7_75t_R  g120(.A1(new_n108_), .A2(new_n129_), .B(new_n119_), .Y(new_n139_));
  OR3x1_ASAP7_75t_R    g121(.A(new_n20_), .B(new_n21_), .C(new_n139_), .Y(new_n140_));
  AO21x1_ASAP7_75t_R   g122(.A1(new_n138_), .A2(new_n140_), .B(\B[8] ), .Y(new_n141_));
  NAND2x1_ASAP7_75t_R  g123(.A(\B[8] ), .B(new_n131_), .Y(new_n142_));
  NOR2x1_ASAP7_75t_R   g124(.A(new_n21_), .B(new_n26_), .Y(new_n143_));
  AO21x1_ASAP7_75t_R   g125(.A1(\B[2] ), .A2(new_n21_), .B(new_n143_), .Y(new_n144_));
  AND3x1_ASAP7_75t_R   g126(.A(new_n88_), .B(new_n103_), .C(new_n144_), .Y(new_n145_));
  AOI21x1_ASAP7_75t_R  g127(.A1(\B[9] ), .A2(new_n142_), .B(new_n145_), .Y(new_n146_));
  AO21x1_ASAP7_75t_R   g128(.A1(new_n141_), .A2(new_n146_), .B(\B[10] ), .Y(\E[0] ));
  AND4x2_ASAP7_75t_R   g129(.A(\B[3] ), .B(new_n26_), .C(new_n108_), .D(new_n136_), .Y(new_n148_));
  AO21x1_ASAP7_75t_R   g130(.A1(\B[8] ), .A2(new_n131_), .B(new_n148_), .Y(new_n149_));
  AOI22x1_ASAP7_75t_R  g131(.A1(\B[2] ), .A2(new_n149_), .B1(new_n131_), .B2(new_n143_), .Y(new_n150_));
  AND3x1_ASAP7_75t_R   g132(.A(\B[5] ), .B(\B[6] ), .C(new_n92_), .Y(new_n151_));
  OR3x1_ASAP7_75t_R    g133(.A(new_n46_), .B(new_n129_), .C(new_n151_), .Y(new_n152_));
  OA211x2_ASAP7_75t_R  g134(.A1(new_n22_), .A2(new_n150_), .B(new_n128_), .C(new_n152_), .Y(new_n153_));
  INVx1_ASAP7_75t_R    g135(.A(new_n153_), .Y(\E[1] ));
  OR4x2_ASAP7_75t_R    g136(.A(\B[9] ), .B(\B[10] ), .C(new_n46_), .D(new_n151_), .Y(\E[2] ));
endmodule


