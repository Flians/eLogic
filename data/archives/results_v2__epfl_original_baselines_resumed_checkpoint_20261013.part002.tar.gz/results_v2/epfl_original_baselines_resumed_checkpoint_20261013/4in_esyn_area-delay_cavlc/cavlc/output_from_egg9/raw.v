// Benchmark "/home/flynn/workplace/MIGBalance/results_v2/epfl_original_baselines_resumed_checkpoint_20261013/4in_esyn_area-delay_cavlc/cavlc/output_from_egg9/logic" written by ABC on Tue Oct 13 18:48:52 2026

module \/home/flynn/workplace/MIGBalance/results_v2/epfl_original_baselines_resumed_checkpoint_20261013/4in_esyn_area-delay_cavlc/cavlc/output_from_egg9/logic  ( 
    \totalcoeffs[1] , \totalcoeffs[2] , \totalcoeffs[3] , \totalcoeffs[4] ,
    \ctable[0] , \ctable[1] , \ctable[2] , \trailingones[0] ,
    \trailingones[1] , \totalcoeffs[0] ,
    \coeff_token[0] , \coeff_token[1] , \coeff_token[2] , \coeff_token[3] ,
    \coeff_token[4] , \coeff_token[5] , \ctoken_len[0] , \ctoken_len[1] ,
    \ctoken_len[2] , \ctoken_len[3] , \ctoken_len[4]   );
  input  \totalcoeffs[1] , \totalcoeffs[2] , \totalcoeffs[3] ,
    \totalcoeffs[4] , \ctable[0] , \ctable[1] , \ctable[2] ,
    \trailingones[0] , \trailingones[1] , \totalcoeffs[0] ;
  output \coeff_token[0] , \coeff_token[1] , \coeff_token[2] ,
    \coeff_token[3] , \coeff_token[4] , \coeff_token[5] , \ctoken_len[0] ,
    \ctoken_len[1] , \ctoken_len[2] , \ctoken_len[3] , \ctoken_len[4] ;
  wire new_n22_, new_n23_, new_n24_, new_n25_, new_n26_, new_n27_, new_n28_,
    new_n29_, new_n30_, new_n31_, new_n32_, new_n33_, new_n34_, new_n35_,
    new_n36_, new_n37_, new_n38_, new_n39_, new_n40_, new_n41_, new_n42_,
    new_n43_, new_n44_, new_n45_, new_n46_, new_n47_, new_n48_, new_n49_,
    new_n50_, new_n51_, new_n52_, new_n53_, new_n54_, new_n55_, new_n56_,
    new_n57_, new_n58_, new_n59_, new_n60_, new_n61_, new_n62_, new_n63_,
    new_n64_, new_n65_, new_n66_, new_n67_, new_n68_, new_n69_, new_n70_,
    new_n71_, new_n72_, new_n73_, new_n74_, new_n75_, new_n76_, new_n77_,
    new_n78_, new_n79_, new_n80_, new_n81_, new_n82_, new_n83_, new_n84_,
    new_n85_, new_n86_, new_n87_, new_n88_, new_n89_, new_n90_, new_n91_,
    new_n92_, new_n93_, new_n94_, new_n95_, new_n96_, new_n97_, new_n98_,
    new_n99_, new_n100_, new_n101_, new_n102_, new_n103_, new_n104_,
    new_n105_, new_n106_, new_n107_, new_n108_, new_n109_, new_n110_,
    new_n111_, new_n112_, new_n113_, new_n114_, new_n116_, new_n117_,
    new_n118_, new_n119_, new_n120_, new_n121_, new_n122_, new_n123_,
    new_n124_, new_n125_, new_n126_, new_n127_, new_n128_, new_n129_,
    new_n130_, new_n131_, new_n132_, new_n133_, new_n134_, new_n135_,
    new_n136_, new_n137_, new_n138_, new_n139_, new_n140_, new_n141_,
    new_n142_, new_n143_, new_n144_, new_n145_, new_n146_, new_n147_,
    new_n148_, new_n149_, new_n150_, new_n151_, new_n152_, new_n153_,
    new_n154_, new_n155_, new_n156_, new_n157_, new_n158_, new_n159_,
    new_n160_, new_n161_, new_n162_, new_n163_, new_n164_, new_n165_,
    new_n166_, new_n167_, new_n168_, new_n169_, new_n170_, new_n171_,
    new_n172_, new_n173_, new_n174_, new_n175_, new_n176_, new_n177_,
    new_n178_, new_n179_, new_n180_, new_n181_, new_n182_, new_n183_,
    new_n184_, new_n185_, new_n186_, new_n187_, new_n188_, new_n190_,
    new_n191_, new_n192_, new_n193_, new_n194_, new_n195_, new_n196_,
    new_n197_, new_n198_, new_n199_, new_n200_, new_n201_, new_n202_,
    new_n203_, new_n204_, new_n205_, new_n206_, new_n207_, new_n208_,
    new_n209_, new_n210_, new_n211_, new_n212_, new_n213_, new_n214_,
    new_n215_, new_n216_, new_n217_, new_n218_, new_n219_, new_n220_,
    new_n221_, new_n222_, new_n223_, new_n224_, new_n225_, new_n226_,
    new_n227_, new_n228_, new_n229_, new_n230_, new_n231_, new_n232_,
    new_n233_, new_n234_, new_n235_, new_n236_, new_n237_, new_n238_,
    new_n239_, new_n240_, new_n241_, new_n242_, new_n243_, new_n244_,
    new_n245_, new_n246_, new_n248_, new_n249_, new_n250_, new_n251_,
    new_n252_, new_n253_, new_n254_, new_n255_, new_n256_, new_n257_,
    new_n258_, new_n259_, new_n260_, new_n261_, new_n262_, new_n263_,
    new_n264_, new_n265_, new_n266_, new_n267_, new_n268_, new_n269_,
    new_n270_, new_n271_, new_n272_, new_n273_, new_n274_, new_n275_,
    new_n276_, new_n277_, new_n278_, new_n279_, new_n280_, new_n281_,
    new_n282_, new_n283_, new_n284_, new_n285_, new_n287_, new_n288_,
    new_n289_, new_n291_, new_n292_, new_n294_, new_n295_, new_n296_,
    new_n297_, new_n298_, new_n299_, new_n300_, new_n301_, new_n302_,
    new_n303_, new_n304_, new_n305_, new_n306_, new_n307_, new_n308_,
    new_n309_, new_n310_, new_n311_, new_n312_, new_n313_, new_n314_,
    new_n315_, new_n316_, new_n317_, new_n318_, new_n319_, new_n320_,
    new_n321_, new_n322_, new_n323_, new_n324_, new_n325_, new_n326_,
    new_n327_, new_n328_, new_n329_, new_n330_, new_n331_, new_n332_,
    new_n333_, new_n334_, new_n335_, new_n337_, new_n338_, new_n339_,
    new_n340_, new_n341_, new_n342_, new_n343_, new_n344_, new_n345_,
    new_n346_, new_n347_, new_n348_, new_n349_, new_n350_, new_n351_,
    new_n352_, new_n353_, new_n354_, new_n355_, new_n356_, new_n357_,
    new_n358_, new_n359_, new_n360_, new_n361_, new_n362_, new_n363_,
    new_n364_, new_n365_, new_n366_, new_n367_, new_n368_, new_n369_,
    new_n370_, new_n371_, new_n372_, new_n373_, new_n374_, new_n375_,
    new_n376_, new_n377_, new_n378_, new_n379_, new_n380_, new_n382_,
    new_n383_, new_n384_, new_n385_, new_n386_, new_n387_, new_n388_,
    new_n389_, new_n390_, new_n391_, new_n392_, new_n393_, new_n394_,
    new_n395_, new_n396_, new_n397_, new_n398_, new_n399_, new_n400_,
    new_n401_, new_n402_, new_n403_, new_n404_, new_n405_, new_n406_,
    new_n407_, new_n409_, new_n410_, new_n411_, new_n412_, new_n413_,
    new_n414_, new_n415_, new_n416_, new_n417_, new_n418_, new_n419_,
    new_n420_, new_n421_, new_n422_, new_n423_, new_n424_, new_n426_,
    new_n427_;
  INVx1_ASAP7_75t_R    g000(.A(\totalcoeffs[1] ), .Y(new_n22_));
  INVx1_ASAP7_75t_R    g001(.A(\totalcoeffs[2] ), .Y(new_n23_));
  INVx1_ASAP7_75t_R    g002(.A(\totalcoeffs[3] ), .Y(new_n24_));
  INVx1_ASAP7_75t_R    g003(.A(\totalcoeffs[4] ), .Y(new_n25_));
  INVx1_ASAP7_75t_R    g004(.A(\ctable[0] ), .Y(new_n26_));
  INVx1_ASAP7_75t_R    g005(.A(\ctable[1] ), .Y(new_n27_));
  INVx1_ASAP7_75t_R    g006(.A(\ctable[2] ), .Y(new_n28_));
  INVx1_ASAP7_75t_R    g007(.A(\trailingones[0] ), .Y(new_n29_));
  INVx1_ASAP7_75t_R    g008(.A(\trailingones[1] ), .Y(new_n30_));
  INVx1_ASAP7_75t_R    g009(.A(\totalcoeffs[0] ), .Y(new_n31_));
  NOR2x1_ASAP7_75t_R   g010(.A(\totalcoeffs[1] ), .B(\trailingones[1] ), .Y(new_n32_));
  OR3x1_ASAP7_75t_R    g011(.A(\totalcoeffs[1] ), .B(\trailingones[1] ), .C(\trailingones[0] ), .Y(new_n33_));
  NOR2x1_ASAP7_75t_R   g012(.A(\totalcoeffs[2] ), .B(\totalcoeffs[3] ), .Y(new_n34_));
  INVx1_ASAP7_75t_R    g013(.A(new_n34_), .Y(new_n35_));
  OR3x1_ASAP7_75t_R    g014(.A(\totalcoeffs[0] ), .B(new_n35_), .C(new_n33_), .Y(new_n36_));
  NOR2x1_ASAP7_75t_R   g015(.A(new_n23_), .B(new_n30_), .Y(new_n37_));
  INVx1_ASAP7_75t_R    g016(.A(new_n37_), .Y(new_n38_));
  AO21x1_ASAP7_75t_R   g017(.A1(new_n23_), .A2(\ctable[1] ), .B(new_n24_), .Y(new_n39_));
  AO21x1_ASAP7_75t_R   g018(.A1(new_n32_), .A2(new_n39_), .B(new_n37_), .Y(new_n40_));
  NOR2x1_ASAP7_75t_R   g019(.A(new_n22_), .B(\trailingones[0] ), .Y(new_n41_));
  INVx1_ASAP7_75t_R    g020(.A(new_n41_), .Y(new_n42_));
  NOR2x1_ASAP7_75t_R   g021(.A(\totalcoeffs[1] ), .B(new_n30_), .Y(new_n43_));
  NOR2x1_ASAP7_75t_R   g022(.A(new_n23_), .B(\totalcoeffs[3] ), .Y(new_n44_));
  INVx1_ASAP7_75t_R    g023(.A(new_n44_), .Y(new_n45_));
  AO21x1_ASAP7_75t_R   g024(.A1(new_n43_), .A2(new_n44_), .B(new_n41_), .Y(new_n46_));
  AOI22x1_ASAP7_75t_R  g025(.A1(new_n29_), .A2(new_n40_), .B1(new_n31_), .B2(new_n46_), .Y(new_n47_));
  NOR2x1_ASAP7_75t_R   g026(.A(\trailingones[1] ), .B(new_n31_), .Y(new_n48_));
  AO21x1_ASAP7_75t_R   g027(.A1(new_n30_), .A2(\totalcoeffs[0] ), .B(\totalcoeffs[2] ), .Y(new_n49_));
  INVx1_ASAP7_75t_R    g028(.A(new_n49_), .Y(new_n50_));
  NOR2x1_ASAP7_75t_R   g029(.A(new_n30_), .B(\totalcoeffs[0] ), .Y(new_n51_));
  AO21x1_ASAP7_75t_R   g030(.A1(\trailingones[1] ), .A2(new_n31_), .B(new_n22_), .Y(new_n52_));
  INVx1_ASAP7_75t_R    g031(.A(new_n52_), .Y(new_n53_));
  AO21x1_ASAP7_75t_R   g032(.A1(new_n24_), .A2(new_n53_), .B(new_n49_), .Y(new_n54_));
  OA211x2_ASAP7_75t_R  g033(.A1(\ctable[1] ), .A2(new_n50_), .B(\ctable[0] ), .C(new_n54_), .Y(new_n55_));
  INVx1_ASAP7_75t_R    g034(.A(new_n55_), .Y(new_n56_));
  NOR2x1_ASAP7_75t_R   g035(.A(new_n22_), .B(\trailingones[1] ), .Y(new_n57_));
  INVx1_ASAP7_75t_R    g036(.A(new_n57_), .Y(new_n58_));
  OR3x1_ASAP7_75t_R    g037(.A(new_n22_), .B(\trailingones[1] ), .C(\totalcoeffs[2] ), .Y(new_n59_));
  OR3x1_ASAP7_75t_R    g038(.A(\totalcoeffs[3] ), .B(\totalcoeffs[0] ), .C(new_n27_), .Y(new_n60_));
  AO21x1_ASAP7_75t_R   g039(.A1(new_n38_), .A2(new_n59_), .B(new_n60_), .Y(new_n61_));
  AO21x1_ASAP7_75t_R   g040(.A1(new_n56_), .A2(new_n61_), .B(new_n29_), .Y(new_n62_));
  OA211x2_ASAP7_75t_R  g041(.A1(\ctable[0] ), .A2(new_n47_), .B(new_n36_), .C(new_n62_), .Y(new_n63_));
  INVx1_ASAP7_75t_R    g042(.A(new_n63_), .Y(new_n64_));
  AND3x1_ASAP7_75t_R   g043(.A(new_n22_), .B(\totalcoeffs[2] ), .C(new_n48_), .Y(new_n65_));
  AO21x1_ASAP7_75t_R   g044(.A1(\trailingones[1] ), .A2(new_n31_), .B(\totalcoeffs[1] ), .Y(new_n66_));
  AO21x1_ASAP7_75t_R   g045(.A1(new_n29_), .A2(new_n66_), .B(new_n65_), .Y(new_n67_));
  NOR2x1_ASAP7_75t_R   g046(.A(\totalcoeffs[2] ), .B(\totalcoeffs[0] ), .Y(new_n68_));
  AO21x1_ASAP7_75t_R   g047(.A1(new_n43_), .A2(new_n68_), .B(\ctable[0] ), .Y(new_n69_));
  NOR2x1_ASAP7_75t_R   g048(.A(new_n22_), .B(new_n26_), .Y(new_n70_));
  NOR2x1_ASAP7_75t_R   g049(.A(new_n48_), .B(new_n51_), .Y(new_n71_));
  AND3x1_ASAP7_75t_R   g050(.A(\totalcoeffs[2] ), .B(new_n70_), .C(new_n71_), .Y(new_n72_));
  AO21x1_ASAP7_75t_R   g051(.A1(\ctable[1] ), .A2(new_n69_), .B(new_n72_), .Y(new_n73_));
  AO22x1_ASAP7_75t_R   g052(.A1(new_n26_), .A2(new_n67_), .B1(\trailingones[0] ), .B2(new_n73_), .Y(new_n74_));
  AO21x1_ASAP7_75t_R   g053(.A1(\totalcoeffs[3] ), .A2(new_n74_), .B(new_n64_), .Y(new_n75_));
  AND3x1_ASAP7_75t_R   g054(.A(new_n26_), .B(\ctable[2] ), .C(\trailingones[0] ), .Y(new_n76_));
  NOR2x1_ASAP7_75t_R   g055(.A(new_n23_), .B(\trailingones[1] ), .Y(new_n77_));
  INVx1_ASAP7_75t_R    g056(.A(new_n77_), .Y(new_n78_));
  NAND2x1_ASAP7_75t_R  g057(.A(new_n22_), .B(new_n31_), .Y(new_n79_));
  AND3x1_ASAP7_75t_R   g058(.A(new_n22_), .B(new_n31_), .C(new_n77_), .Y(new_n80_));
  NAND2x1_ASAP7_75t_R  g059(.A(new_n26_), .B(new_n30_), .Y(new_n81_));
  OA211x2_ASAP7_75t_R  g060(.A1(new_n22_), .A2(\ctable[2] ), .B(new_n26_), .C(new_n30_), .Y(new_n82_));
  AO21x1_ASAP7_75t_R   g061(.A1(new_n28_), .A2(\trailingones[1] ), .B(new_n76_), .Y(new_n83_));
  AO21x1_ASAP7_75t_R   g062(.A1(\totalcoeffs[1] ), .A2(new_n83_), .B(new_n82_), .Y(new_n84_));
  AND3x1_ASAP7_75t_R   g063(.A(new_n23_), .B(\totalcoeffs[0] ), .C(new_n84_), .Y(new_n85_));
  AO21x1_ASAP7_75t_R   g064(.A1(new_n76_), .A2(new_n80_), .B(new_n85_), .Y(new_n86_));
  OR4x2_ASAP7_75t_R    g065(.A(\totalcoeffs[3] ), .B(\ctable[0] ), .C(new_n43_), .D(new_n53_), .Y(new_n87_));
  NOR2x1_ASAP7_75t_R   g066(.A(\totalcoeffs[1] ), .B(new_n48_), .Y(new_n88_));
  OR3x1_ASAP7_75t_R    g067(.A(\ctable[2] ), .B(new_n57_), .C(new_n88_), .Y(new_n89_));
  AOI21x1_ASAP7_75t_R  g068(.A1(new_n87_), .A2(new_n89_), .B(\totalcoeffs[2] ), .Y(new_n90_));
  AO21x1_ASAP7_75t_R   g069(.A1(new_n23_), .A2(new_n26_), .B(\totalcoeffs[0] ), .Y(new_n91_));
  NOR2x1_ASAP7_75t_R   g070(.A(new_n22_), .B(new_n23_), .Y(new_n92_));
  INVx1_ASAP7_75t_R    g071(.A(new_n92_), .Y(new_n93_));
  AO21x1_ASAP7_75t_R   g072(.A1(new_n91_), .A2(new_n93_), .B(\trailingones[1] ), .Y(new_n94_));
  NOR2x1_ASAP7_75t_R   g073(.A(new_n30_), .B(new_n34_), .Y(new_n95_));
  NOR2x1_ASAP7_75t_R   g074(.A(new_n24_), .B(new_n31_), .Y(new_n96_));
  OAI21x1_ASAP7_75t_R  g075(.A1(new_n95_), .A2(new_n96_), .B(new_n22_), .Y(new_n97_));
  OA211x2_ASAP7_75t_R  g076(.A1(new_n22_), .A2(\totalcoeffs[3] ), .B(new_n97_), .C(new_n94_), .Y(new_n98_));
  INVx1_ASAP7_75t_R    g077(.A(new_n98_), .Y(new_n99_));
  AO21x1_ASAP7_75t_R   g078(.A1(new_n28_), .A2(new_n99_), .B(new_n90_), .Y(new_n100_));
  AO22x1_ASAP7_75t_R   g079(.A1(new_n24_), .A2(new_n86_), .B1(new_n29_), .B2(new_n100_), .Y(new_n101_));
  AO22x1_ASAP7_75t_R   g080(.A1(new_n28_), .A2(new_n75_), .B1(new_n27_), .B2(new_n101_), .Y(new_n102_));
  NOR2x1_ASAP7_75t_R   g081(.A(\ctable[1] ), .B(new_n29_), .Y(new_n103_));
  NOR2x1_ASAP7_75t_R   g082(.A(new_n26_), .B(new_n103_), .Y(new_n104_));
  NOR2x1_ASAP7_75t_R   g083(.A(\ctable[1] ), .B(\trailingones[1] ), .Y(new_n105_));
  AO21x1_ASAP7_75t_R   g084(.A1(\totalcoeffs[4] ), .A2(\trailingones[0] ), .B(new_n105_), .Y(new_n106_));
  NOR2x1_ASAP7_75t_R   g085(.A(new_n27_), .B(\trailingones[1] ), .Y(new_n107_));
  NOR2x1_ASAP7_75t_R   g086(.A(new_n25_), .B(new_n30_), .Y(new_n108_));
  NOR2x1_ASAP7_75t_R   g087(.A(new_n26_), .B(new_n27_), .Y(new_n109_));
  INVx1_ASAP7_75t_R    g088(.A(new_n109_), .Y(new_n110_));
  OA211x2_ASAP7_75t_R  g089(.A1(new_n107_), .A2(new_n108_), .B(new_n29_), .C(new_n110_), .Y(new_n111_));
  AO21x1_ASAP7_75t_R   g090(.A1(new_n104_), .A2(new_n106_), .B(new_n111_), .Y(new_n112_));
  NOR2x1_ASAP7_75t_R   g091(.A(\totalcoeffs[1] ), .B(\totalcoeffs[3] ), .Y(new_n113_));
  AND3x1_ASAP7_75t_R   g092(.A(new_n28_), .B(new_n68_), .C(new_n113_), .Y(new_n114_));
  AO22x1_ASAP7_75t_R   g093(.A1(new_n25_), .A2(new_n102_), .B1(new_n112_), .B2(new_n114_), .Y(\coeff_token[0] ));
  NOR2x1_ASAP7_75t_R   g094(.A(\totalcoeffs[2] ), .B(new_n29_), .Y(new_n116_));
  NOR2x1_ASAP7_75t_R   g095(.A(new_n22_), .B(new_n31_), .Y(new_n117_));
  AO21x1_ASAP7_75t_R   g096(.A1(new_n22_), .A2(new_n31_), .B(new_n23_), .Y(new_n118_));
  OA211x2_ASAP7_75t_R  g097(.A1(new_n49_), .A2(new_n117_), .B(new_n29_), .C(new_n118_), .Y(new_n119_));
  AO21x1_ASAP7_75t_R   g098(.A1(new_n57_), .A2(new_n116_), .B(new_n119_), .Y(new_n120_));
  AOI21x1_ASAP7_75t_R  g099(.A1(\ctable[2] ), .A2(new_n120_), .B(new_n80_), .Y(new_n121_));
  OR3x1_ASAP7_75t_R    g100(.A(\totalcoeffs[3] ), .B(\ctable[0] ), .C(\ctable[1] ), .Y(new_n122_));
  INVx1_ASAP7_75t_R    g101(.A(new_n122_), .Y(new_n123_));
  OR3x1_ASAP7_75t_R    g102(.A(\totalcoeffs[4] ), .B(new_n122_), .C(new_n121_), .Y(new_n124_));
  OR3x1_ASAP7_75t_R    g103(.A(\totalcoeffs[1] ), .B(\totalcoeffs[0] ), .C(\totalcoeffs[2] ), .Y(new_n125_));
  INVx1_ASAP7_75t_R    g104(.A(new_n125_), .Y(new_n126_));
  NOR2x1_ASAP7_75t_R   g105(.A(new_n26_), .B(\trailingones[0] ), .Y(new_n127_));
  AO21x1_ASAP7_75t_R   g106(.A1(\totalcoeffs[4] ), .A2(\trailingones[0] ), .B(new_n127_), .Y(new_n128_));
  NOR2x1_ASAP7_75t_R   g107(.A(new_n27_), .B(new_n30_), .Y(new_n129_));
  AO22x1_ASAP7_75t_R   g108(.A1(new_n105_), .A2(new_n128_), .B1(\totalcoeffs[4] ), .B2(new_n129_), .Y(new_n130_));
  NOR2x1_ASAP7_75t_R   g109(.A(\totalcoeffs[2] ), .B(\trailingones[0] ), .Y(new_n131_));
  AND3x1_ASAP7_75t_R   g110(.A(new_n30_), .B(new_n31_), .C(new_n131_), .Y(new_n132_));
  OR3x1_ASAP7_75t_R    g111(.A(new_n29_), .B(new_n31_), .C(new_n30_), .Y(new_n133_));
  INVx1_ASAP7_75t_R    g112(.A(new_n133_), .Y(new_n134_));
  AO21x1_ASAP7_75t_R   g113(.A1(\totalcoeffs[2] ), .A2(new_n134_), .B(new_n132_), .Y(new_n135_));
  AO21x1_ASAP7_75t_R   g114(.A1(new_n26_), .A2(\trailingones[0] ), .B(new_n129_), .Y(new_n136_));
  AND3x1_ASAP7_75t_R   g115(.A(new_n26_), .B(new_n30_), .C(new_n29_), .Y(new_n137_));
  NOR2x1_ASAP7_75t_R   g116(.A(new_n27_), .B(new_n29_), .Y(new_n138_));
  AO21x1_ASAP7_75t_R   g117(.A1(\trailingones[1] ), .A2(new_n138_), .B(new_n137_), .Y(new_n139_));
  AO21x1_ASAP7_75t_R   g118(.A1(new_n31_), .A2(new_n136_), .B(new_n139_), .Y(new_n140_));
  AO22x1_ASAP7_75t_R   g119(.A1(\ctable[0] ), .A2(new_n135_), .B1(\totalcoeffs[2] ), .B2(new_n140_), .Y(new_n141_));
  AO22x1_ASAP7_75t_R   g120(.A1(new_n77_), .A2(new_n103_), .B1(new_n22_), .B2(new_n141_), .Y(new_n142_));
  OA211x2_ASAP7_75t_R  g121(.A1(new_n27_), .A2(new_n29_), .B(\totalcoeffs[0] ), .C(new_n136_), .Y(new_n143_));
  NOR2x1_ASAP7_75t_R   g122(.A(new_n26_), .B(\totalcoeffs[0] ), .Y(new_n144_));
  NOR2x1_ASAP7_75t_R   g123(.A(\trailingones[0] ), .B(new_n30_), .Y(new_n145_));
  AO21x1_ASAP7_75t_R   g124(.A1(new_n144_), .A2(new_n145_), .B(new_n143_), .Y(new_n146_));
  AO21x1_ASAP7_75t_R   g125(.A1(\ctable[1] ), .A2(new_n31_), .B(\totalcoeffs[2] ), .Y(new_n147_));
  AND3x1_ASAP7_75t_R   g126(.A(new_n26_), .B(\trailingones[0] ), .C(new_n147_), .Y(new_n148_));
  NAND2x1_ASAP7_75t_R  g127(.A(new_n27_), .B(new_n29_), .Y(new_n149_));
  AO21x1_ASAP7_75t_R   g128(.A1(new_n27_), .A2(new_n29_), .B(new_n148_), .Y(new_n150_));
  AO22x1_ASAP7_75t_R   g129(.A1(new_n23_), .A2(new_n146_), .B1(new_n30_), .B2(new_n150_), .Y(new_n151_));
  AO21x1_ASAP7_75t_R   g130(.A1(\totalcoeffs[1] ), .A2(new_n151_), .B(new_n142_), .Y(new_n152_));
  AO22x1_ASAP7_75t_R   g131(.A1(new_n126_), .A2(new_n130_), .B1(new_n25_), .B2(new_n152_), .Y(new_n153_));
  NAND2x1_ASAP7_75t_R  g132(.A(new_n24_), .B(new_n153_), .Y(new_n154_));
  NOR2x1_ASAP7_75t_R   g133(.A(new_n29_), .B(\totalcoeffs[0] ), .Y(new_n155_));
  NOR2x1_ASAP7_75t_R   g134(.A(\totalcoeffs[1] ), .B(\ctable[1] ), .Y(new_n156_));
  OR4x2_ASAP7_75t_R    g135(.A(\totalcoeffs[2] ), .B(new_n155_), .C(new_n117_), .D(new_n156_), .Y(new_n157_));
  INVx1_ASAP7_75t_R    g136(.A(new_n157_), .Y(new_n158_));
  NOR2x1_ASAP7_75t_R   g137(.A(\totalcoeffs[1] ), .B(new_n29_), .Y(new_n159_));
  NOR2x1_ASAP7_75t_R   g138(.A(\totalcoeffs[1] ), .B(\trailingones[0] ), .Y(new_n160_));
  INVx1_ASAP7_75t_R    g139(.A(new_n160_), .Y(new_n161_));
  AO22x1_ASAP7_75t_R   g140(.A1(\ctable[1] ), .A2(new_n159_), .B1(new_n23_), .B2(new_n161_), .Y(new_n162_));
  AO21x1_ASAP7_75t_R   g141(.A1(\totalcoeffs[3] ), .A2(new_n162_), .B(new_n158_), .Y(new_n163_));
  AO21x1_ASAP7_75t_R   g142(.A1(new_n26_), .A2(new_n163_), .B(\trailingones[1] ), .Y(new_n164_));
  NOR2x1_ASAP7_75t_R   g143(.A(\ctable[0] ), .B(new_n31_), .Y(new_n165_));
  INVx1_ASAP7_75t_R    g144(.A(new_n165_), .Y(new_n166_));
  AND3x1_ASAP7_75t_R   g145(.A(new_n23_), .B(\trailingones[0] ), .C(\totalcoeffs[0] ), .Y(new_n167_));
  OR3x1_ASAP7_75t_R    g146(.A(new_n144_), .B(new_n165_), .C(new_n167_), .Y(new_n168_));
  AO21x1_ASAP7_75t_R   g147(.A1(\totalcoeffs[3] ), .A2(\trailingones[0] ), .B(\totalcoeffs[2] ), .Y(new_n169_));
  INVx1_ASAP7_75t_R    g148(.A(new_n169_), .Y(new_n170_));
  AO22x1_ASAP7_75t_R   g149(.A1(\totalcoeffs[1] ), .A2(new_n168_), .B1(new_n31_), .B2(new_n169_), .Y(new_n171_));
  AND3x1_ASAP7_75t_R   g150(.A(new_n23_), .B(new_n29_), .C(\ctable[0] ), .Y(new_n172_));
  NOR2x1_ASAP7_75t_R   g151(.A(\totalcoeffs[3] ), .B(\trailingones[0] ), .Y(new_n173_));
  AO21x1_ASAP7_75t_R   g152(.A1(new_n26_), .A2(\trailingones[0] ), .B(new_n173_), .Y(new_n174_));
  INVx1_ASAP7_75t_R    g153(.A(new_n174_), .Y(new_n175_));
  AO21x1_ASAP7_75t_R   g154(.A1(\totalcoeffs[0] ), .A2(new_n175_), .B(new_n172_), .Y(new_n176_));
  AO21x1_ASAP7_75t_R   g155(.A1(new_n22_), .A2(new_n176_), .B(new_n171_), .Y(new_n177_));
  AOI21x1_ASAP7_75t_R  g156(.A1(new_n27_), .A2(new_n177_), .B(new_n164_), .Y(new_n178_));
  NOR2x1_ASAP7_75t_R   g157(.A(\totalcoeffs[1] ), .B(new_n24_), .Y(new_n179_));
  INVx1_ASAP7_75t_R    g158(.A(new_n179_), .Y(new_n180_));
  AO21x1_ASAP7_75t_R   g159(.A1(new_n131_), .A2(new_n179_), .B(new_n70_), .Y(new_n181_));
  AND3x1_ASAP7_75t_R   g160(.A(\totalcoeffs[1] ), .B(\totalcoeffs[2] ), .C(\totalcoeffs[3] ), .Y(new_n182_));
  OA21x2_ASAP7_75t_R   g161(.A1(\ctable[0] ), .A2(new_n182_), .B(new_n35_), .Y(new_n183_));
  AO21x1_ASAP7_75t_R   g162(.A1(\totalcoeffs[0] ), .A2(new_n181_), .B(new_n183_), .Y(new_n184_));
  AO21x1_ASAP7_75t_R   g163(.A1(new_n127_), .A2(new_n182_), .B(new_n30_), .Y(new_n185_));
  AOI21x1_ASAP7_75t_R  g164(.A1(\ctable[1] ), .A2(new_n184_), .B(new_n185_), .Y(new_n186_));
  OR3x1_ASAP7_75t_R    g165(.A(\totalcoeffs[4] ), .B(new_n186_), .C(new_n178_), .Y(new_n187_));
  AO21x1_ASAP7_75t_R   g166(.A1(new_n154_), .A2(new_n187_), .B(\ctable[2] ), .Y(new_n188_));
  NAND2x1_ASAP7_75t_R  g167(.A(new_n124_), .B(new_n188_), .Y(\coeff_token[1] ));
  NOR2x1_ASAP7_75t_R   g168(.A(new_n29_), .B(new_n30_), .Y(new_n190_));
  INVx1_ASAP7_75t_R    g169(.A(new_n190_), .Y(new_n191_));
  AO21x1_ASAP7_75t_R   g170(.A1(\ctable[2] ), .A2(new_n190_), .B(new_n31_), .Y(new_n192_));
  AO22x1_ASAP7_75t_R   g171(.A1(new_n48_), .A2(new_n160_), .B1(new_n53_), .B2(new_n192_), .Y(new_n193_));
  NOR2x1_ASAP7_75t_R   g172(.A(\ctable[0] ), .B(\ctable[1] ), .Y(new_n194_));
  INVx1_ASAP7_75t_R    g173(.A(new_n194_), .Y(new_n195_));
  AND4x2_ASAP7_75t_R   g174(.A(new_n25_), .B(new_n34_), .C(new_n194_), .D(new_n193_), .Y(new_n196_));
  NOR2x1_ASAP7_75t_R   g175(.A(new_n23_), .B(\ctable[0] ), .Y(new_n197_));
  OA21x2_ASAP7_75t_R   g176(.A1(new_n24_), .A2(new_n197_), .B(\trailingones[0] ), .Y(new_n198_));
  AO21x1_ASAP7_75t_R   g177(.A1(new_n23_), .A2(\trailingones[0] ), .B(new_n24_), .Y(new_n199_));
  AO21x1_ASAP7_75t_R   g178(.A1(\ctable[0] ), .A2(new_n199_), .B(new_n198_), .Y(new_n200_));
  NOR2x1_ASAP7_75t_R   g179(.A(\ctable[0] ), .B(new_n27_), .Y(new_n201_));
  AND3x1_ASAP7_75t_R   g180(.A(new_n26_), .B(\ctable[1] ), .C(new_n24_), .Y(new_n202_));
  AOI22x1_ASAP7_75t_R  g181(.A1(\totalcoeffs[1] ), .A2(new_n200_), .B1(new_n160_), .B2(new_n202_), .Y(new_n203_));
  NAND2x1_ASAP7_75t_R  g182(.A(\totalcoeffs[1] ), .B(\trailingones[0] ), .Y(new_n204_));
  AO21x1_ASAP7_75t_R   g183(.A1(\ctable[1] ), .A2(new_n204_), .B(\trailingones[1] ), .Y(new_n205_));
  AOI22x1_ASAP7_75t_R  g184(.A1(new_n29_), .A2(new_n43_), .B1(new_n23_), .B2(new_n205_), .Y(new_n206_));
  OA21x2_ASAP7_75t_R   g185(.A1(new_n23_), .A2(new_n103_), .B(\totalcoeffs[1] ), .Y(new_n207_));
  OR3x1_ASAP7_75t_R    g186(.A(new_n26_), .B(new_n170_), .C(new_n207_), .Y(new_n208_));
  OR3x1_ASAP7_75t_R    g187(.A(\totalcoeffs[3] ), .B(new_n30_), .C(new_n22_), .Y(new_n209_));
  INVx1_ASAP7_75t_R    g188(.A(new_n209_), .Y(new_n210_));
  NOR2x1_ASAP7_75t_R   g189(.A(new_n27_), .B(\trailingones[0] ), .Y(new_n211_));
  INVx1_ASAP7_75t_R    g190(.A(new_n211_), .Y(new_n212_));
  AO21x1_ASAP7_75t_R   g191(.A1(\totalcoeffs[3] ), .A2(new_n30_), .B(\ctable[1] ), .Y(new_n213_));
  NAND2x1_ASAP7_75t_R  g192(.A(\totalcoeffs[3] ), .B(new_n29_), .Y(new_n214_));
  AO21x1_ASAP7_75t_R   g193(.A1(new_n58_), .A2(new_n214_), .B(new_n213_), .Y(new_n215_));
  OA211x2_ASAP7_75t_R  g194(.A1(new_n209_), .A2(new_n212_), .B(new_n25_), .C(new_n215_), .Y(new_n216_));
  OA211x2_ASAP7_75t_R  g195(.A1(new_n24_), .A2(new_n206_), .B(new_n208_), .C(new_n216_), .Y(new_n217_));
  OAI21x1_ASAP7_75t_R  g196(.A1(\trailingones[1] ), .A2(new_n203_), .B(new_n217_), .Y(new_n218_));
  OR3x1_ASAP7_75t_R    g197(.A(\totalcoeffs[1] ), .B(\totalcoeffs[3] ), .C(\totalcoeffs[2] ), .Y(new_n219_));
  AO21x1_ASAP7_75t_R   g198(.A1(new_n191_), .A2(new_n212_), .B(\ctable[0] ), .Y(new_n220_));
  AND3x1_ASAP7_75t_R   g199(.A(new_n23_), .B(new_n113_), .C(new_n220_), .Y(new_n221_));
  OA211x2_ASAP7_75t_R  g200(.A1(new_n25_), .A2(new_n221_), .B(new_n31_), .C(new_n218_), .Y(new_n222_));
  NOR2x1_ASAP7_75t_R   g201(.A(\trailingones[0] ), .B(\trailingones[1] ), .Y(new_n223_));
  INVx1_ASAP7_75t_R    g202(.A(new_n223_), .Y(new_n224_));
  OA211x2_ASAP7_75t_R  g203(.A1(new_n26_), .A2(new_n179_), .B(new_n23_), .C(new_n223_), .Y(new_n225_));
  AO21x1_ASAP7_75t_R   g204(.A1(new_n95_), .A2(new_n159_), .B(new_n225_), .Y(new_n226_));
  OR3x1_ASAP7_75t_R    g205(.A(new_n26_), .B(new_n223_), .C(new_n134_), .Y(new_n227_));
  OA211x2_ASAP7_75t_R  g206(.A1(\ctable[0] ), .A2(new_n37_), .B(\totalcoeffs[1] ), .C(new_n227_), .Y(new_n228_));
  AO21x1_ASAP7_75t_R   g207(.A1(\trailingones[0] ), .A2(\trailingones[1] ), .B(new_n223_), .Y(new_n229_));
  INVx1_ASAP7_75t_R    g208(.A(new_n229_), .Y(new_n230_));
  OA21x2_ASAP7_75t_R   g209(.A1(new_n32_), .A2(new_n230_), .B(\totalcoeffs[2] ), .Y(new_n231_));
  OA21x2_ASAP7_75t_R   g210(.A1(new_n228_), .A2(new_n231_), .B(new_n24_), .Y(new_n232_));
  AO21x1_ASAP7_75t_R   g211(.A1(\totalcoeffs[0] ), .A2(new_n226_), .B(new_n232_), .Y(new_n233_));
  NOR2x1_ASAP7_75t_R   g212(.A(new_n22_), .B(new_n30_), .Y(new_n234_));
  INVx1_ASAP7_75t_R    g213(.A(new_n234_), .Y(new_n235_));
  AO21x1_ASAP7_75t_R   g214(.A1(\totalcoeffs[2] ), .A2(new_n234_), .B(new_n159_), .Y(new_n236_));
  AND3x1_ASAP7_75t_R   g215(.A(new_n29_), .B(new_n30_), .C(\totalcoeffs[2] ), .Y(new_n237_));
  AO21x1_ASAP7_75t_R   g216(.A1(\trailingones[0] ), .A2(new_n78_), .B(new_n237_), .Y(new_n238_));
  AO21x1_ASAP7_75t_R   g217(.A1(\ctable[1] ), .A2(new_n236_), .B(new_n238_), .Y(new_n239_));
  AO21x1_ASAP7_75t_R   g218(.A1(\totalcoeffs[1] ), .A2(\trailingones[1] ), .B(new_n32_), .Y(new_n240_));
  AO21x1_ASAP7_75t_R   g219(.A1(new_n22_), .A2(\trailingones[1] ), .B(new_n27_), .Y(new_n241_));
  AOI21x1_ASAP7_75t_R  g220(.A1(new_n58_), .A2(new_n241_), .B(new_n29_), .Y(new_n242_));
  AO21x1_ASAP7_75t_R   g221(.A1(new_n173_), .A2(new_n240_), .B(new_n242_), .Y(new_n243_));
  AO22x1_ASAP7_75t_R   g222(.A1(\totalcoeffs[3] ), .A2(new_n239_), .B1(new_n23_), .B2(new_n243_), .Y(new_n244_));
  AO22x1_ASAP7_75t_R   g223(.A1(new_n27_), .A2(new_n233_), .B1(new_n165_), .B2(new_n244_), .Y(new_n245_));
  AO21x1_ASAP7_75t_R   g224(.A1(new_n25_), .A2(new_n245_), .B(new_n222_), .Y(new_n246_));
  AO21x1_ASAP7_75t_R   g225(.A1(new_n28_), .A2(new_n246_), .B(new_n196_), .Y(\coeff_token[2] ));
  NAND2x1_ASAP7_75t_R  g226(.A(\ctable[0] ), .B(\trailingones[0] ), .Y(new_n248_));
  AO21x1_ASAP7_75t_R   g227(.A1(\ctable[0] ), .A2(\trailingones[1] ), .B(\ctable[1] ), .Y(new_n249_));
  AO21x1_ASAP7_75t_R   g228(.A1(new_n235_), .A2(new_n248_), .B(new_n249_), .Y(new_n250_));
  AO21x1_ASAP7_75t_R   g229(.A1(new_n81_), .A2(new_n149_), .B(\totalcoeffs[2] ), .Y(new_n251_));
  AO21x1_ASAP7_75t_R   g230(.A1(new_n250_), .A2(new_n251_), .B(new_n24_), .Y(new_n252_));
  OR4x2_ASAP7_75t_R    g231(.A(\ctable[0] ), .B(new_n27_), .C(\trailingones[1] ), .D(new_n204_), .Y(new_n253_));
  NOR2x1_ASAP7_75t_R   g232(.A(new_n24_), .B(\ctable[1] ), .Y(new_n254_));
  INVx1_ASAP7_75t_R    g233(.A(new_n254_), .Y(new_n255_));
  AO21x1_ASAP7_75t_R   g234(.A1(new_n30_), .A2(new_n201_), .B(new_n254_), .Y(new_n256_));
  AND3x1_ASAP7_75t_R   g235(.A(\totalcoeffs[3] ), .B(new_n27_), .C(\totalcoeffs[2] ), .Y(new_n257_));
  AO21x1_ASAP7_75t_R   g236(.A1(new_n35_), .A2(new_n201_), .B(new_n257_), .Y(new_n258_));
  AOI22x1_ASAP7_75t_R  g237(.A1(new_n29_), .A2(new_n256_), .B1(\trailingones[1] ), .B2(new_n258_), .Y(new_n259_));
  OA211x2_ASAP7_75t_R  g238(.A1(\totalcoeffs[1] ), .A2(new_n259_), .B(new_n252_), .C(new_n253_), .Y(new_n260_));
  INVx1_ASAP7_75t_R    g239(.A(new_n260_), .Y(new_n261_));
  AO21x1_ASAP7_75t_R   g240(.A1(new_n156_), .A2(new_n172_), .B(new_n202_), .Y(new_n262_));
  NOR2x1_ASAP7_75t_R   g241(.A(new_n24_), .B(\ctable[0] ), .Y(new_n263_));
  AO21x1_ASAP7_75t_R   g242(.A1(new_n27_), .A2(new_n214_), .B(new_n263_), .Y(new_n264_));
  OR3x1_ASAP7_75t_R    g243(.A(\trailingones[0] ), .B(new_n30_), .C(new_n26_), .Y(new_n265_));
  AO21x1_ASAP7_75t_R   g244(.A1(new_n24_), .A2(new_n265_), .B(\totalcoeffs[2] ), .Y(new_n266_));
  NOR2x1_ASAP7_75t_R   g245(.A(\totalcoeffs[2] ), .B(new_n26_), .Y(new_n267_));
  AOI22x1_ASAP7_75t_R  g246(.A1(\totalcoeffs[2] ), .A2(new_n174_), .B1(\trailingones[0] ), .B2(new_n267_), .Y(new_n268_));
  OA211x2_ASAP7_75t_R  g247(.A1(\trailingones[1] ), .A2(new_n268_), .B(new_n264_), .C(new_n266_), .Y(new_n269_));
  INVx1_ASAP7_75t_R    g248(.A(new_n269_), .Y(new_n270_));
  AO22x1_ASAP7_75t_R   g249(.A1(new_n30_), .A2(new_n262_), .B1(\totalcoeffs[1] ), .B2(new_n270_), .Y(new_n271_));
  AO21x1_ASAP7_75t_R   g250(.A1(\totalcoeffs[0] ), .A2(new_n271_), .B(new_n261_), .Y(new_n272_));
  AND3x1_ASAP7_75t_R   g251(.A(\ctable[0] ), .B(\trailingones[1] ), .C(\trailingones[0] ), .Y(new_n273_));
  AO21x1_ASAP7_75t_R   g252(.A1(new_n27_), .A2(new_n273_), .B(new_n137_), .Y(new_n274_));
  AOI21x1_ASAP7_75t_R  g253(.A1(new_n24_), .A2(new_n212_), .B(new_n104_), .Y(new_n275_));
  AO21x1_ASAP7_75t_R   g254(.A1(\totalcoeffs[2] ), .A2(new_n274_), .B(new_n275_), .Y(new_n276_));
  AO22x1_ASAP7_75t_R   g255(.A1(\totalcoeffs[3] ), .A2(new_n30_), .B1(\ctable[1] ), .B2(new_n35_), .Y(new_n277_));
  AO22x1_ASAP7_75t_R   g256(.A1(\totalcoeffs[2] ), .A2(new_n201_), .B1(new_n22_), .B2(new_n277_), .Y(new_n278_));
  AO21x1_ASAP7_75t_R   g257(.A1(\totalcoeffs[1] ), .A2(new_n276_), .B(new_n278_), .Y(new_n279_));
  NOR2x1_ASAP7_75t_R   g258(.A(\ctable[0] ), .B(new_n190_), .Y(new_n280_));
  NAND2x1_ASAP7_75t_R  g259(.A(new_n24_), .B(\totalcoeffs[4] ), .Y(new_n281_));
  OR4x2_ASAP7_75t_R    g260(.A(\totalcoeffs[1] ), .B(\totalcoeffs[2] ), .C(new_n281_), .D(new_n280_), .Y(new_n282_));
  AOI21x1_ASAP7_75t_R  g261(.A1(new_n110_), .A2(new_n195_), .B(new_n282_), .Y(new_n283_));
  AO21x1_ASAP7_75t_R   g262(.A1(new_n25_), .A2(new_n279_), .B(new_n283_), .Y(new_n284_));
  AOI22x1_ASAP7_75t_R  g263(.A1(new_n25_), .A2(new_n272_), .B1(new_n31_), .B2(new_n284_), .Y(new_n285_));
  NOR2x1_ASAP7_75t_R   g264(.A(\ctable[2] ), .B(new_n285_), .Y(\coeff_token[3] ));
  AND3x1_ASAP7_75t_R   g265(.A(\totalcoeffs[2] ), .B(new_n79_), .C(new_n25_), .Y(new_n287_));
  NAND2x1_ASAP7_75t_R  g266(.A(\totalcoeffs[3] ), .B(new_n25_), .Y(new_n288_));
  AOI21x1_ASAP7_75t_R  g267(.A1(new_n281_), .A2(new_n288_), .B(new_n125_), .Y(new_n289_));
  OA211x2_ASAP7_75t_R  g268(.A1(new_n287_), .A2(new_n289_), .B(new_n28_), .C(new_n109_), .Y(\coeff_token[4] ));
  AND3x1_ASAP7_75t_R   g269(.A(\totalcoeffs[3] ), .B(new_n25_), .C(new_n125_), .Y(new_n291_));
  AND3x1_ASAP7_75t_R   g270(.A(new_n24_), .B(\totalcoeffs[4] ), .C(new_n126_), .Y(new_n292_));
  OA211x2_ASAP7_75t_R  g271(.A1(new_n291_), .A2(new_n292_), .B(new_n28_), .C(new_n109_), .Y(\coeff_token[5] ));
  OR3x1_ASAP7_75t_R    g272(.A(new_n25_), .B(new_n79_), .C(new_n35_), .Y(new_n294_));
  NAND2x1_ASAP7_75t_R  g273(.A(new_n110_), .B(new_n294_), .Y(new_n295_));
  NOR2x1_ASAP7_75t_R   g274(.A(\totalcoeffs[2] ), .B(\trailingones[1] ), .Y(new_n296_));
  OA211x2_ASAP7_75t_R  g275(.A1(\totalcoeffs[0] ), .A2(new_n211_), .B(new_n248_), .C(new_n296_), .Y(new_n297_));
  NOR2x1_ASAP7_75t_R   g276(.A(new_n23_), .B(new_n29_), .Y(new_n298_));
  AO21x1_ASAP7_75t_R   g277(.A1(new_n51_), .A2(new_n298_), .B(new_n297_), .Y(new_n299_));
  AO21x1_ASAP7_75t_R   g278(.A1(\totalcoeffs[2] ), .A2(new_n224_), .B(new_n134_), .Y(new_n300_));
  OA21x2_ASAP7_75t_R   g279(.A1(\ctable[1] ), .A2(new_n197_), .B(new_n51_), .Y(new_n301_));
  AO21x1_ASAP7_75t_R   g280(.A1(new_n71_), .A2(new_n267_), .B(new_n301_), .Y(new_n302_));
  AO22x1_ASAP7_75t_R   g281(.A1(\ctable[1] ), .A2(new_n300_), .B1(new_n29_), .B2(new_n302_), .Y(new_n303_));
  AO22x1_ASAP7_75t_R   g282(.A1(new_n22_), .A2(new_n299_), .B1(\totalcoeffs[1] ), .B2(new_n303_), .Y(new_n304_));
  OR3x1_ASAP7_75t_R    g283(.A(\ctable[1] ), .B(\totalcoeffs[0] ), .C(new_n160_), .Y(new_n305_));
  AOI21x1_ASAP7_75t_R  g284(.A1(new_n93_), .A2(new_n305_), .B(new_n240_), .Y(new_n306_));
  OA21x2_ASAP7_75t_R   g285(.A1(\totalcoeffs[1] ), .A2(new_n223_), .B(\totalcoeffs[0] ), .Y(new_n307_));
  AO21x1_ASAP7_75t_R   g286(.A1(new_n58_), .A2(new_n307_), .B(new_n306_), .Y(new_n308_));
  OR3x1_ASAP7_75t_R    g287(.A(new_n27_), .B(new_n29_), .C(new_n31_), .Y(new_n309_));
  NOR2x1_ASAP7_75t_R   g288(.A(new_n23_), .B(\totalcoeffs[0] ), .Y(new_n310_));
  OAI22x1_ASAP7_75t_R  g289(.A1(\totalcoeffs[2] ), .A2(new_n309_), .B1(new_n42_), .B2(new_n310_), .Y(new_n311_));
  OA211x2_ASAP7_75t_R  g290(.A1(\trailingones[0] ), .A2(\totalcoeffs[0] ), .B(new_n57_), .C(new_n166_), .Y(new_n312_));
  AO21x1_ASAP7_75t_R   g291(.A1(\trailingones[1] ), .A2(new_n311_), .B(new_n312_), .Y(new_n313_));
  AO21x1_ASAP7_75t_R   g292(.A1(new_n26_), .A2(new_n308_), .B(new_n313_), .Y(new_n314_));
  AO21x1_ASAP7_75t_R   g293(.A1(\totalcoeffs[3] ), .A2(new_n314_), .B(new_n304_), .Y(new_n315_));
  AO21x1_ASAP7_75t_R   g294(.A1(\totalcoeffs[2] ), .A2(\trailingones[0] ), .B(new_n131_), .Y(new_n316_));
  INVx1_ASAP7_75t_R    g295(.A(new_n316_), .Y(new_n317_));
  OR3x1_ASAP7_75t_R    g296(.A(new_n27_), .B(new_n230_), .C(new_n317_), .Y(new_n318_));
  OR3x1_ASAP7_75t_R    g297(.A(new_n23_), .B(\totalcoeffs[0] ), .C(new_n30_), .Y(new_n319_));
  INVx1_ASAP7_75t_R    g298(.A(new_n319_), .Y(new_n320_));
  AO21x1_ASAP7_75t_R   g299(.A1(new_n33_), .A2(new_n319_), .B(new_n26_), .Y(new_n321_));
  AO21x1_ASAP7_75t_R   g300(.A1(new_n22_), .A2(new_n26_), .B(new_n23_), .Y(new_n322_));
  AO22x1_ASAP7_75t_R   g301(.A1(new_n105_), .A2(new_n322_), .B1(\ctable[0] ), .B2(new_n234_), .Y(new_n323_));
  AOI22x1_ASAP7_75t_R  g302(.A1(new_n81_), .A2(new_n310_), .B1(\totalcoeffs[0] ), .B2(new_n323_), .Y(new_n324_));
  OA211x2_ASAP7_75t_R  g303(.A1(new_n29_), .A2(new_n324_), .B(new_n318_), .C(new_n321_), .Y(new_n325_));
  INVx1_ASAP7_75t_R    g304(.A(new_n325_), .Y(new_n326_));
  OA21x2_ASAP7_75t_R   g305(.A1(new_n22_), .A2(new_n133_), .B(new_n224_), .Y(new_n327_));
  OR3x1_ASAP7_75t_R    g306(.A(\totalcoeffs[2] ), .B(new_n28_), .C(new_n327_), .Y(new_n328_));
  NOR2x1_ASAP7_75t_R   g307(.A(new_n28_), .B(\trailingones[1] ), .Y(new_n329_));
  OA211x2_ASAP7_75t_R  g308(.A1(new_n29_), .A2(new_n329_), .B(new_n22_), .C(\totalcoeffs[2] ), .Y(new_n330_));
  INVx1_ASAP7_75t_R    g309(.A(new_n330_), .Y(new_n331_));
  AO21x1_ASAP7_75t_R   g310(.A1(new_n59_), .A2(new_n331_), .B(\totalcoeffs[0] ), .Y(new_n332_));
  AOI21x1_ASAP7_75t_R  g311(.A1(new_n328_), .A2(new_n332_), .B(new_n195_), .Y(new_n333_));
  AO21x1_ASAP7_75t_R   g312(.A1(new_n28_), .A2(new_n326_), .B(new_n333_), .Y(new_n334_));
  AO22x1_ASAP7_75t_R   g313(.A1(new_n28_), .A2(new_n315_), .B1(new_n24_), .B2(new_n334_), .Y(new_n335_));
  AOI22x1_ASAP7_75t_R  g314(.A1(new_n28_), .A2(new_n295_), .B1(new_n25_), .B2(new_n335_), .Y(\ctoken_len[0] ));
  AND3x1_ASAP7_75t_R   g315(.A(new_n26_), .B(new_n28_), .C(new_n292_), .Y(new_n337_));
  INVx1_ASAP7_75t_R    g316(.A(new_n337_), .Y(new_n338_));
  OA21x2_ASAP7_75t_R   g317(.A1(\totalcoeffs[2] ), .A2(new_n96_), .B(\ctable[0] ), .Y(new_n339_));
  NOR2x1_ASAP7_75t_R   g318(.A(new_n23_), .B(new_n24_), .Y(new_n340_));
  OA21x2_ASAP7_75t_R   g319(.A1(new_n229_), .A2(new_n340_), .B(new_n339_), .Y(new_n341_));
  AO21x1_ASAP7_75t_R   g320(.A1(new_n96_), .A2(new_n237_), .B(new_n341_), .Y(new_n342_));
  AO22x1_ASAP7_75t_R   g321(.A1(new_n22_), .A2(new_n342_), .B1(new_n273_), .B2(new_n340_), .Y(new_n343_));
  OA211x2_ASAP7_75t_R  g322(.A1(\totalcoeffs[2] ), .A2(\trailingones[1] ), .B(\totalcoeffs[0] ), .C(new_n38_), .Y(new_n344_));
  AO21x1_ASAP7_75t_R   g323(.A1(new_n30_), .A2(new_n144_), .B(new_n344_), .Y(new_n345_));
  AO22x1_ASAP7_75t_R   g324(.A1(\trailingones[0] ), .A2(new_n345_), .B1(new_n37_), .B2(new_n127_), .Y(new_n346_));
  NOR2x1_ASAP7_75t_R   g325(.A(new_n24_), .B(new_n26_), .Y(new_n347_));
  INVx1_ASAP7_75t_R    g326(.A(new_n347_), .Y(new_n348_));
  OA21x2_ASAP7_75t_R   g327(.A1(new_n77_), .A2(new_n347_), .B(new_n31_), .Y(new_n349_));
  AO21x1_ASAP7_75t_R   g328(.A1(\totalcoeffs[3] ), .A2(new_n267_), .B(new_n349_), .Y(new_n350_));
  AO22x1_ASAP7_75t_R   g329(.A1(new_n296_), .A2(new_n347_), .B1(new_n29_), .B2(new_n350_), .Y(new_n351_));
  AO21x1_ASAP7_75t_R   g330(.A1(new_n24_), .A2(new_n346_), .B(new_n351_), .Y(new_n352_));
  AO21x1_ASAP7_75t_R   g331(.A1(\totalcoeffs[1] ), .A2(new_n352_), .B(new_n343_), .Y(new_n353_));
  AO22x1_ASAP7_75t_R   g332(.A1(\trailingones[0] ), .A2(\totalcoeffs[0] ), .B1(\totalcoeffs[3] ), .B2(new_n191_), .Y(new_n354_));
  AO22x1_ASAP7_75t_R   g333(.A1(new_n27_), .A2(new_n354_), .B1(new_n24_), .B2(new_n190_), .Y(new_n355_));
  AO21x1_ASAP7_75t_R   g334(.A1(new_n155_), .A2(new_n254_), .B(new_n211_), .Y(new_n356_));
  AO21x1_ASAP7_75t_R   g335(.A1(\totalcoeffs[0] ), .A2(new_n255_), .B(new_n107_), .Y(new_n357_));
  OA21x2_ASAP7_75t_R   g336(.A1(\trailingones[0] ), .A2(new_n129_), .B(new_n357_), .Y(new_n358_));
  AO21x1_ASAP7_75t_R   g337(.A1(\trailingones[1] ), .A2(new_n356_), .B(new_n358_), .Y(new_n359_));
  AO22x1_ASAP7_75t_R   g338(.A1(new_n23_), .A2(new_n359_), .B1(new_n105_), .B2(new_n173_), .Y(new_n360_));
  AO21x1_ASAP7_75t_R   g339(.A1(\totalcoeffs[2] ), .A2(new_n355_), .B(new_n360_), .Y(new_n361_));
  OA211x2_ASAP7_75t_R  g340(.A1(\ctable[1] ), .A2(new_n173_), .B(\totalcoeffs[2] ), .C(new_n224_), .Y(new_n362_));
  INVx1_ASAP7_75t_R    g341(.A(new_n362_), .Y(new_n363_));
  OR3x1_ASAP7_75t_R    g342(.A(\totalcoeffs[2] ), .B(\trailingones[0] ), .C(\totalcoeffs[0] ), .Y(new_n364_));
  INVx1_ASAP7_75t_R    g343(.A(new_n364_), .Y(new_n365_));
  AO21x1_ASAP7_75t_R   g344(.A1(new_n309_), .A2(new_n364_), .B(\trailingones[1] ), .Y(new_n366_));
  OR3x1_ASAP7_75t_R    g345(.A(new_n27_), .B(\totalcoeffs[0] ), .C(new_n230_), .Y(new_n367_));
  AO21x1_ASAP7_75t_R   g346(.A1(\trailingones[0] ), .A2(\trailingones[1] ), .B(\ctable[1] ), .Y(new_n368_));
  OA21x2_ASAP7_75t_R   g347(.A1(new_n49_), .A2(new_n368_), .B(new_n367_), .Y(new_n369_));
  OA211x2_ASAP7_75t_R  g348(.A1(new_n24_), .A2(new_n369_), .B(new_n363_), .C(new_n366_), .Y(new_n370_));
  INVx1_ASAP7_75t_R    g349(.A(new_n370_), .Y(new_n371_));
  AND3x1_ASAP7_75t_R   g350(.A(\totalcoeffs[3] ), .B(new_n131_), .C(new_n107_), .Y(new_n372_));
  AO21x1_ASAP7_75t_R   g351(.A1(new_n22_), .A2(new_n371_), .B(new_n372_), .Y(new_n373_));
  AO21x1_ASAP7_75t_R   g352(.A1(\totalcoeffs[1] ), .A2(new_n361_), .B(new_n373_), .Y(new_n374_));
  AO22x1_ASAP7_75t_R   g353(.A1(new_n27_), .A2(new_n353_), .B1(new_n26_), .B2(new_n374_), .Y(new_n375_));
  AND4x2_ASAP7_75t_R   g354(.A(new_n23_), .B(\totalcoeffs[0] ), .C(\trailingones[0] ), .D(new_n329_), .Y(new_n376_));
  AO21x1_ASAP7_75t_R   g355(.A1(new_n230_), .A2(new_n310_), .B(new_n376_), .Y(new_n377_));
  AND3x1_ASAP7_75t_R   g356(.A(new_n113_), .B(new_n194_), .C(new_n377_), .Y(new_n378_));
  AO21x1_ASAP7_75t_R   g357(.A1(new_n28_), .A2(new_n375_), .B(new_n378_), .Y(new_n379_));
  NAND2x1_ASAP7_75t_R  g358(.A(new_n25_), .B(new_n379_), .Y(new_n380_));
  OA21x2_ASAP7_75t_R   g359(.A1(\ctable[1] ), .A2(new_n338_), .B(new_n380_), .Y(\ctoken_len[1] ));
  AOI21x1_ASAP7_75t_R  g360(.A1(new_n58_), .A2(new_n155_), .B(new_n241_), .Y(new_n382_));
  OR3x1_ASAP7_75t_R    g361(.A(\ctable[1] ), .B(new_n41_), .C(new_n307_), .Y(new_n383_));
  OA211x2_ASAP7_75t_R  g362(.A1(\totalcoeffs[2] ), .A2(new_n382_), .B(new_n263_), .C(new_n383_), .Y(new_n384_));
  NOR2x1_ASAP7_75t_R   g363(.A(\totalcoeffs[2] ), .B(new_n32_), .Y(new_n385_));
  NOR2x1_ASAP7_75t_R   g364(.A(new_n70_), .B(new_n263_), .Y(new_n386_));
  OA211x2_ASAP7_75t_R  g365(.A1(\totalcoeffs[3] ), .A2(new_n30_), .B(new_n385_), .C(new_n386_), .Y(new_n387_));
  INVx1_ASAP7_75t_R    g366(.A(new_n387_), .Y(new_n388_));
  AO21x1_ASAP7_75t_R   g367(.A1(new_n32_), .A2(new_n267_), .B(new_n210_), .Y(new_n389_));
  AO21x1_ASAP7_75t_R   g368(.A1(new_n22_), .A2(new_n26_), .B(new_n240_), .Y(new_n390_));
  AOI22x1_ASAP7_75t_R  g369(.A1(new_n31_), .A2(new_n389_), .B1(new_n44_), .B2(new_n390_), .Y(new_n391_));
  AO21x1_ASAP7_75t_R   g370(.A1(new_n388_), .A2(new_n391_), .B(\trailingones[0] ), .Y(new_n392_));
  OA211x2_ASAP7_75t_R  g371(.A1(\ctable[0] ), .A2(new_n155_), .B(new_n92_), .C(new_n348_), .Y(new_n393_));
  OA211x2_ASAP7_75t_R  g372(.A1(\totalcoeffs[3] ), .A2(\totalcoeffs[0] ), .B(new_n23_), .C(new_n386_), .Y(new_n394_));
  AO21x1_ASAP7_75t_R   g373(.A1(new_n113_), .A2(new_n165_), .B(new_n394_), .Y(new_n395_));
  AOI21x1_ASAP7_75t_R  g374(.A1(\trailingones[0] ), .A2(new_n395_), .B(new_n393_), .Y(new_n396_));
  OA211x2_ASAP7_75t_R  g375(.A1(new_n197_), .A2(new_n347_), .B(\totalcoeffs[1] ), .C(new_n199_), .Y(new_n397_));
  INVx1_ASAP7_75t_R    g376(.A(new_n397_), .Y(new_n398_));
  OR4x2_ASAP7_75t_R    g377(.A(\totalcoeffs[2] ), .B(new_n29_), .C(new_n144_), .D(new_n180_), .Y(new_n399_));
  AO21x1_ASAP7_75t_R   g378(.A1(new_n398_), .A2(new_n399_), .B(new_n30_), .Y(new_n400_));
  OA211x2_ASAP7_75t_R  g379(.A1(\trailingones[1] ), .A2(new_n396_), .B(new_n400_), .C(new_n392_), .Y(new_n401_));
  INVx1_ASAP7_75t_R    g380(.A(new_n401_), .Y(new_n402_));
  AO21x1_ASAP7_75t_R   g381(.A1(new_n27_), .A2(new_n402_), .B(new_n384_), .Y(new_n403_));
  AO21x1_ASAP7_75t_R   g382(.A1(new_n31_), .A2(new_n316_), .B(new_n167_), .Y(new_n404_));
  AO22x1_ASAP7_75t_R   g383(.A1(new_n30_), .A2(new_n404_), .B1(new_n29_), .B2(new_n320_), .Y(new_n405_));
  AO22x1_ASAP7_75t_R   g384(.A1(new_n22_), .A2(new_n405_), .B1(new_n234_), .B2(new_n365_), .Y(new_n406_));
  AO22x1_ASAP7_75t_R   g385(.A1(new_n28_), .A2(new_n403_), .B1(new_n123_), .B2(new_n406_), .Y(new_n407_));
  AOI21x1_ASAP7_75t_R  g386(.A1(new_n25_), .A2(new_n407_), .B(new_n337_), .Y(\ctoken_len[2] ));
  OA21x2_ASAP7_75t_R   g387(.A1(\ctable[1] ), .A2(new_n273_), .B(new_n24_), .Y(new_n409_));
  AO21x1_ASAP7_75t_R   g388(.A1(new_n257_), .A2(new_n280_), .B(new_n409_), .Y(new_n410_));
  AO21x1_ASAP7_75t_R   g389(.A1(\ctable[1] ), .A2(\trailingones[1] ), .B(new_n24_), .Y(new_n411_));
  AO22x1_ASAP7_75t_R   g390(.A1(new_n24_), .A2(new_n81_), .B1(new_n155_), .B2(new_n411_), .Y(new_n412_));
  AOI21x1_ASAP7_75t_R  g391(.A1(new_n23_), .A2(new_n412_), .B(new_n410_), .Y(new_n413_));
  AOI21x1_ASAP7_75t_R  g392(.A1(new_n165_), .A2(new_n257_), .B(\ctable[2] ), .Y(new_n414_));
  AO21x1_ASAP7_75t_R   g393(.A1(new_n22_), .A2(new_n224_), .B(new_n414_), .Y(new_n415_));
  AOI22x1_ASAP7_75t_R  g394(.A1(\ctable[2] ), .A2(new_n45_), .B1(\totalcoeffs[4] ), .B2(new_n219_), .Y(new_n416_));
  AO21x1_ASAP7_75t_R   g395(.A1(new_n26_), .A2(new_n45_), .B(new_n27_), .Y(new_n417_));
  AO21x1_ASAP7_75t_R   g396(.A1(new_n28_), .A2(new_n219_), .B(new_n31_), .Y(new_n418_));
  AND4x2_ASAP7_75t_R   g397(.A(new_n416_), .B(new_n417_), .C(new_n418_), .D(new_n415_), .Y(new_n419_));
  OR3x1_ASAP7_75t_R    g398(.A(new_n45_), .B(new_n223_), .C(new_n280_), .Y(new_n420_));
  AO21x1_ASAP7_75t_R   g399(.A1(new_n155_), .A2(new_n249_), .B(new_n411_), .Y(new_n421_));
  OA211x2_ASAP7_75t_R  g400(.A1(new_n194_), .A2(new_n281_), .B(new_n23_), .C(new_n421_), .Y(new_n422_));
  INVx1_ASAP7_75t_R    g401(.A(new_n422_), .Y(new_n423_));
  AO21x1_ASAP7_75t_R   g402(.A1(new_n420_), .A2(new_n423_), .B(\totalcoeffs[1] ), .Y(new_n424_));
  OA211x2_ASAP7_75t_R  g403(.A1(new_n22_), .A2(new_n413_), .B(new_n419_), .C(new_n424_), .Y(\ctoken_len[3] ));
  OR3x1_ASAP7_75t_R    g404(.A(new_n23_), .B(new_n288_), .C(new_n88_), .Y(new_n426_));
  AOI21x1_ASAP7_75t_R  g405(.A1(\trailingones[0] ), .A2(new_n52_), .B(new_n426_), .Y(new_n427_));
  OA211x2_ASAP7_75t_R  g406(.A1(new_n292_), .A2(new_n427_), .B(new_n28_), .C(new_n194_), .Y(\ctoken_len[4] ));
endmodule


