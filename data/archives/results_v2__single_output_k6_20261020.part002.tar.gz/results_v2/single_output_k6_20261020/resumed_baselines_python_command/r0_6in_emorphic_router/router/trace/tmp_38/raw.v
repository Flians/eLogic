// Benchmark "/tmp/" written by ABC on Tue Oct 20 18:11:48 2026

module \/tmp/  ( 
    p6, p47, p46, p52, p35, p49, p4, p40, p45, p16, p15, p41, p21, p50,
    p23, p38, p56, p31, p2, p1, p44, p22, p19, p3, p5, p55, p17, p33, p26,
    p30, p36, p24, p51, p37, p43, p8, p58, p0, p59, p25, p32, p29, p42,
    p39, p12, p11, p10, p48, p14, p18, p13, p53, p34, p54, p7, p20, p57,
    p28, p9, p27,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25, o26, o27, o28, o29  );
  input  p6, p47, p46, p52, p35, p49, p4, p40, p45, p16, p15, p41, p21,
    p50, p23, p38, p56, p31, p2, p1, p44, p22, p19, p3, p5, p55, p17, p33,
    p26, p30, p36, p24, p51, p37, p43, p8, p58, p0, p59, p25, p32, p29,
    p42, p39, p12, p11, p10, p48, p14, p18, p13, p53, p34, p54, p7, p20,
    p57, p28, p9, p27;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25, o26, o27, o28, o29;
  wire new_n91_, new_n92_, new_n93_, new_n94_, new_n95_, new_n96_, new_n97_,
    new_n98_, new_n99_, new_n100_, new_n101_, new_n102_, new_n103_,
    new_n104_, new_n105_, new_n106_, new_n107_, new_n108_, new_n109_,
    new_n110_, new_n111_, new_n112_, new_n113_, new_n114_, new_n115_,
    new_n116_, new_n117_, new_n118_, new_n119_, new_n120_, new_n121_,
    new_n122_, new_n123_, new_n124_, new_n125_, new_n126_, new_n127_,
    new_n128_, new_n129_, new_n130_, new_n131_, new_n132_, new_n133_,
    new_n134_, new_n135_, new_n136_, new_n137_, new_n138_, new_n139_,
    new_n140_, new_n141_, new_n142_, new_n143_, new_n144_, new_n145_,
    new_n146_, new_n147_, new_n148_, new_n149_, new_n150_, new_n151_,
    new_n153_, new_n154_, new_n155_, new_n156_, new_n157_, new_n158_,
    new_n159_, new_n160_, new_n161_, new_n162_, new_n163_, new_n164_,
    new_n165_, new_n166_, new_n167_, new_n168_, new_n169_, new_n170_,
    new_n171_, new_n172_, new_n173_, new_n174_, new_n175_, new_n176_,
    new_n177_, new_n178_, new_n179_, new_n180_, new_n181_, new_n182_,
    new_n183_, new_n184_, new_n185_, new_n186_, new_n187_, new_n188_,
    new_n189_, new_n190_, new_n191_, new_n192_, new_n193_, new_n194_,
    new_n195_, new_n196_, new_n197_, new_n198_, new_n199_, new_n200_,
    new_n201_, new_n202_, new_n203_, new_n204_, new_n205_, new_n206_,
    new_n207_, new_n208_, new_n209_, new_n210_, new_n211_, new_n212_,
    new_n213_, new_n214_, new_n216_, new_n217_, new_n218_, new_n219_,
    new_n220_, new_n221_, new_n222_, new_n223_, new_n224_, new_n225_,
    new_n226_, new_n227_, new_n228_, new_n229_, new_n230_, new_n231_,
    new_n232_, new_n233_, new_n234_, new_n235_, new_n236_, new_n237_,
    new_n238_, new_n239_, new_n240_, new_n241_, new_n242_, new_n243_,
    new_n244_;
  AND2x2_ASAP7_75t_R   g000(.A(p23), .B(p24), .Y(new_n91_));
  NOR2x1_ASAP7_75t_R   g001(.A(p21), .B(p20), .Y(new_n92_));
  INVx1_ASAP7_75t_R    g002(.A(new_n92_), .Y(new_n93_));
  AO21x1_ASAP7_75t_R   g003(.A1(p16), .A2(p15), .B(p17), .Y(new_n94_));
  NOR2x1_ASAP7_75t_R   g004(.A(p12), .B(p11), .Y(new_n95_));
  OAI21x1_ASAP7_75t_R  g005(.A1(p8), .A2(p9), .B(p10), .Y(new_n96_));
  INVx1_ASAP7_75t_R    g006(.A(p16), .Y(new_n97_));
  NAND2x1_ASAP7_75t_R  g007(.A(p14), .B(p13), .Y(new_n98_));
  AOI211x1_ASAP7_75t_R g008(.A1(new_n95_), .A2(new_n96_), .B(new_n97_), .C(new_n98_), .Y(new_n99_));
  NAND2x1_ASAP7_75t_R  g009(.A(p19), .B(p18), .Y(new_n100_));
  INVx1_ASAP7_75t_R    g010(.A(p22), .Y(new_n101_));
  AOI21x1_ASAP7_75t_R  g011(.A1(new_n100_), .A2(new_n92_), .B(new_n101_), .Y(new_n102_));
  OA31x2_ASAP7_75t_R   g012(.A1(new_n93_), .A2(new_n94_), .A3(new_n99_), .B1(new_n102_), .Y(new_n103_));
  AOI21x1_ASAP7_75t_R  g013(.A1(new_n91_), .A2(new_n103_), .B(p25), .Y(new_n104_));
  INVx1_ASAP7_75t_R    g014(.A(new_n98_), .Y(new_n105_));
  NAND2x1_ASAP7_75t_R  g015(.A(new_n95_), .B(new_n96_), .Y(new_n106_));
  AND2x2_ASAP7_75t_R   g016(.A(new_n105_), .B(new_n106_), .Y(new_n107_));
  AOI21x1_ASAP7_75t_R  g017(.A1(p13), .A2(new_n106_), .B(p14), .Y(new_n108_));
  AND2x2_ASAP7_75t_R   g018(.A(p16), .B(p15), .Y(new_n109_));
  OAI22x1_ASAP7_75t_R  g019(.A1(new_n107_), .A2(new_n108_), .B1(new_n109_), .B2(new_n99_), .Y(new_n110_));
  INVx1_ASAP7_75t_R    g020(.A(p10), .Y(new_n111_));
  NAND2x1_ASAP7_75t_R  g021(.A(p11), .B(new_n111_), .Y(new_n112_));
  OA21x2_ASAP7_75t_R   g022(.A1(p8), .A2(p9), .B(p11), .Y(new_n113_));
  NAND3x1_ASAP7_75t_R  g023(.A(p15), .B(p14), .C(p13), .Y(new_n114_));
  AOI21x1_ASAP7_75t_R  g024(.A1(new_n95_), .A2(new_n96_), .B(new_n114_), .Y(new_n115_));
  AOI211x1_ASAP7_75t_R g025(.A1(new_n96_), .A2(new_n112_), .B(new_n113_), .C(new_n115_), .Y(new_n116_));
  INVx1_ASAP7_75t_R    g026(.A(p25), .Y(new_n117_));
  NOR2x1_ASAP7_75t_R   g027(.A(p4), .B(p5), .Y(new_n118_));
  NAND3x1_ASAP7_75t_R  g028(.A(new_n91_), .B(new_n117_), .C(new_n118_), .Y(new_n119_));
  NOR3x1_ASAP7_75t_R   g029(.A(p2), .B(p3), .C(p9), .Y(new_n120_));
  NOR2x1_ASAP7_75t_R   g030(.A(p6), .B(p7), .Y(new_n121_));
  NAND3x1_ASAP7_75t_R  g031(.A(new_n120_), .B(p8), .C(new_n121_), .Y(new_n122_));
  NOR2x1_ASAP7_75t_R   g032(.A(new_n119_), .B(new_n122_), .Y(new_n123_));
  NAND2x1_ASAP7_75t_R  g033(.A(p22), .B(p19), .Y(new_n124_));
  NOR2x1_ASAP7_75t_R   g034(.A(p21), .B(new_n124_), .Y(new_n125_));
  INVx1_ASAP7_75t_R    g035(.A(p18), .Y(new_n126_));
  NOR2x1_ASAP7_75t_R   g036(.A(p17), .B(new_n126_), .Y(new_n127_));
  INVx1_ASAP7_75t_R    g037(.A(p13), .Y(new_n128_));
  NOR2x1_ASAP7_75t_R   g038(.A(p12), .B(new_n128_), .Y(new_n129_));
  NOR3x1_ASAP7_75t_R   g039(.A(p1), .B(p0), .C(p20), .Y(new_n130_));
  AND4x2_ASAP7_75t_R   g040(.A(new_n125_), .B(new_n127_), .C(new_n129_), .D(new_n130_), .Y(new_n131_));
  NAND3x1_ASAP7_75t_R  g041(.A(new_n116_), .B(new_n123_), .C(new_n131_), .Y(new_n132_));
  AND3x1_ASAP7_75t_R   g042(.A(p26), .B(p28), .C(p27), .Y(new_n133_));
  OAI21x1_ASAP7_75t_R  g043(.A1(new_n110_), .A2(new_n132_), .B(new_n133_), .Y(new_n134_));
  INVx1_ASAP7_75t_R    g044(.A(new_n133_), .Y(new_n135_));
  OR3x1_ASAP7_75t_R    g045(.A(new_n99_), .B(p17), .C(new_n109_), .Y(new_n136_));
  INVx1_ASAP7_75t_R    g046(.A(p15), .Y(new_n137_));
  AND2x2_ASAP7_75t_R   g047(.A(p6), .B(p4), .Y(new_n138_));
  NOR2x1_ASAP7_75t_R   g048(.A(p8), .B(p9), .Y(new_n139_));
  AND5x1_ASAP7_75t_R   g049(.A(new_n137_), .B(new_n138_), .C(p2), .D(new_n139_), .E(new_n95_), .Y(new_n140_));
  AND2x2_ASAP7_75t_R   g050(.A(p0), .B(p59), .Y(new_n141_));
  AND2x2_ASAP7_75t_R   g051(.A(p1), .B(p3), .Y(new_n142_));
  AND2x2_ASAP7_75t_R   g052(.A(p5), .B(p24), .Y(new_n143_));
  AND5x1_ASAP7_75t_R   g053(.A(new_n117_), .B(new_n141_), .C(new_n142_), .D(new_n143_), .E(p10), .Y(new_n144_));
  NAND2x1_ASAP7_75t_R  g054(.A(new_n140_), .B(new_n144_), .Y(new_n145_));
  AOI21x1_ASAP7_75t_R  g055(.A1(p22), .A2(new_n93_), .B(p23), .Y(new_n146_));
  AOI211x1_ASAP7_75t_R g056(.A1(new_n105_), .A2(new_n106_), .B(p16), .C(p15), .Y(new_n147_));
  NAND2x1_ASAP7_75t_R  g057(.A(p18), .B(p7), .Y(new_n148_));
  OR5x1_ASAP7_75t_R    g058(.A(new_n135_), .B(new_n93_), .C(new_n98_), .D(new_n124_), .E(new_n148_), .Y(new_n149_));
  OR5x1_ASAP7_75t_R    g059(.A(new_n136_), .B(new_n145_), .C(new_n146_), .D(new_n147_), .E(new_n149_), .Y(new_n150_));
  OAI21x1_ASAP7_75t_R  g060(.A1(new_n135_), .A2(new_n104_), .B(new_n150_), .Y(new_n151_));
  OAI21x1_ASAP7_75t_R  g061(.A1(new_n104_), .A2(new_n134_), .B(new_n151_), .Y(o0));
  AO21x1_ASAP7_75t_R   g062(.A1(p46), .A2(p45), .B(p47), .Y(new_n153_));
  NOR2x1_ASAP7_75t_R   g063(.A(p41), .B(p42), .Y(new_n154_));
  OAI21x1_ASAP7_75t_R  g064(.A1(p38), .A2(p39), .B(p40), .Y(new_n155_));
  INVx1_ASAP7_75t_R    g065(.A(p46), .Y(new_n156_));
  NAND2x1_ASAP7_75t_R  g066(.A(p44), .B(p43), .Y(new_n157_));
  AOI211x1_ASAP7_75t_R g067(.A1(new_n154_), .A2(new_n155_), .B(new_n156_), .C(new_n157_), .Y(new_n158_));
  AND2x2_ASAP7_75t_R   g068(.A(p49), .B(p48), .Y(new_n159_));
  OAI21x1_ASAP7_75t_R  g069(.A1(new_n153_), .A2(new_n158_), .B(new_n159_), .Y(new_n160_));
  INVx1_ASAP7_75t_R    g070(.A(p51), .Y(new_n161_));
  NAND2x1_ASAP7_75t_R  g071(.A(p52), .B(new_n161_), .Y(new_n162_));
  INVx1_ASAP7_75t_R    g072(.A(p50), .Y(new_n163_));
  INVx1_ASAP7_75t_R    g073(.A(p55), .Y(new_n164_));
  AND3x1_ASAP7_75t_R   g074(.A(new_n163_), .B(new_n164_), .C(new_n161_), .Y(new_n165_));
  AND3x1_ASAP7_75t_R   g075(.A(p56), .B(p58), .C(p57), .Y(new_n166_));
  AND2x2_ASAP7_75t_R   g076(.A(p53), .B(p54), .Y(new_n167_));
  AO21x1_ASAP7_75t_R   g077(.A1(p52), .A2(new_n167_), .B(p55), .Y(new_n168_));
  NAND2x1_ASAP7_75t_R  g078(.A(new_n166_), .B(new_n168_), .Y(new_n169_));
  AO21x1_ASAP7_75t_R   g079(.A1(new_n165_), .A2(new_n160_), .B(new_n169_), .Y(new_n170_));
  OR2x4_ASAP7_75t_R    g080(.A(p50), .B(p59), .Y(new_n171_));
  NAND2x1_ASAP7_75t_R  g081(.A(new_n154_), .B(new_n155_), .Y(new_n172_));
  AND2x2_ASAP7_75t_R   g082(.A(p43), .B(new_n172_), .Y(new_n173_));
  INVx1_ASAP7_75t_R    g083(.A(p45), .Y(new_n174_));
  NAND2x1_ASAP7_75t_R  g084(.A(p40), .B(new_n174_), .Y(new_n175_));
  INVx1_ASAP7_75t_R    g085(.A(p33), .Y(new_n176_));
  NAND2x1_ASAP7_75t_R  g086(.A(p31), .B(p44), .Y(new_n177_));
  NAND2x1_ASAP7_75t_R  g087(.A(p35), .B(p49), .Y(new_n178_));
  OR5x1_ASAP7_75t_R    g088(.A(p55), .B(new_n175_), .C(new_n176_), .D(new_n177_), .E(new_n178_), .Y(new_n179_));
  AND2x2_ASAP7_75t_R   g089(.A(p41), .B(p42), .Y(new_n180_));
  INVx1_ASAP7_75t_R    g090(.A(new_n155_), .Y(new_n181_));
  AOI21x1_ASAP7_75t_R  g091(.A1(new_n180_), .A2(new_n181_), .B(p43), .Y(new_n182_));
  AND4x2_ASAP7_75t_R   g092(.A(p30), .B(p36), .C(p37), .D(p32), .Y(new_n183_));
  AND3x1_ASAP7_75t_R   g093(.A(p29), .B(p48), .C(p34), .Y(new_n184_));
  NAND3x1_ASAP7_75t_R  g094(.A(new_n183_), .B(new_n166_), .C(new_n184_), .Y(new_n185_));
  NOR2x1_ASAP7_75t_R   g095(.A(p38), .B(p39), .Y(new_n186_));
  INVx1_ASAP7_75t_R    g096(.A(p47), .Y(new_n187_));
  AND3x1_ASAP7_75t_R   g097(.A(new_n186_), .B(new_n187_), .C(p46), .Y(new_n188_));
  NAND2x1_ASAP7_75t_R  g098(.A(new_n167_), .B(new_n188_), .Y(new_n189_));
  OR5x1_ASAP7_75t_R    g099(.A(new_n173_), .B(new_n179_), .C(new_n182_), .D(new_n185_), .E(new_n189_), .Y(new_n190_));
  AOI221x1_ASAP7_75t_R g100(.A1(new_n160_), .A2(new_n162_), .B1(new_n170_), .B2(new_n171_), .C(new_n190_), .Y(new_n191_));
  INVx1_ASAP7_75t_R    g101(.A(new_n157_), .Y(new_n192_));
  AOI211x1_ASAP7_75t_R g102(.A1(new_n192_), .A2(new_n172_), .B(new_n187_), .C(p45), .Y(new_n193_));
  AO21x1_ASAP7_75t_R   g103(.A1(new_n154_), .A2(new_n155_), .B(new_n157_), .Y(new_n194_));
  AOI21x1_ASAP7_75t_R  g104(.A1(new_n174_), .A2(new_n194_), .B(new_n156_), .Y(new_n195_));
  NOR2x1_ASAP7_75t_R   g105(.A(p59), .B(p29), .Y(new_n196_));
  OAI21x1_ASAP7_75t_R  g106(.A1(new_n193_), .A2(new_n195_), .B(new_n196_), .Y(new_n197_));
  INVx1_ASAP7_75t_R    g107(.A(p40), .Y(new_n198_));
  OR3x1_ASAP7_75t_R    g108(.A(new_n157_), .B(new_n198_), .C(p45), .Y(new_n199_));
  NAND2x1_ASAP7_75t_R  g109(.A(p38), .B(p56), .Y(new_n200_));
  OR3x1_ASAP7_75t_R    g110(.A(new_n200_), .B(p50), .C(p55), .Y(new_n201_));
  OR4x2_ASAP7_75t_R    g111(.A(p36), .B(p37), .C(p42), .D(p39), .Y(new_n202_));
  NOR3x1_ASAP7_75t_R   g112(.A(new_n199_), .B(new_n201_), .C(new_n202_), .Y(new_n203_));
  INVx1_ASAP7_75t_R    g113(.A(p41), .Y(new_n204_));
  NAND2x1_ASAP7_75t_R  g114(.A(new_n204_), .B(new_n155_), .Y(new_n205_));
  NAND2x1_ASAP7_75t_R  g115(.A(p47), .B(p46), .Y(new_n206_));
  NOR2x1_ASAP7_75t_R   g116(.A(p35), .B(p31), .Y(new_n207_));
  AND5x1_ASAP7_75t_R   g117(.A(new_n205_), .B(new_n159_), .C(new_n167_), .D(new_n206_), .E(new_n207_), .Y(new_n208_));
  OR4x2_ASAP7_75t_R    g118(.A(p33), .B(p30), .C(p32), .D(p34), .Y(new_n209_));
  AOI211x1_ASAP7_75t_R g119(.A1(p41), .A2(new_n181_), .B(new_n162_), .C(new_n209_), .Y(new_n210_));
  NAND3x1_ASAP7_75t_R  g120(.A(new_n203_), .B(new_n208_), .C(new_n210_), .Y(new_n211_));
  AOI21x1_ASAP7_75t_R  g121(.A1(new_n165_), .A2(new_n160_), .B(new_n169_), .Y(new_n212_));
  OAI21x1_ASAP7_75t_R  g122(.A1(new_n197_), .A2(new_n211_), .B(new_n212_), .Y(new_n213_));
  OAI21x1_ASAP7_75t_R  g123(.A1(new_n104_), .A2(new_n134_), .B(new_n213_), .Y(new_n214_));
  OAI21x1_ASAP7_75t_R  g124(.A1(new_n191_), .A2(new_n214_), .B(new_n151_), .Y(o1));
  INVx1_ASAP7_75t_R    g125(.A(new_n91_), .Y(new_n216_));
  NAND3x1_ASAP7_75t_R  g126(.A(new_n106_), .B(p16), .C(new_n105_), .Y(new_n217_));
  INVx1_ASAP7_75t_R    g127(.A(new_n94_), .Y(new_n218_));
  INVx1_ASAP7_75t_R    g128(.A(new_n102_), .Y(new_n219_));
  AO31x2_ASAP7_75t_R   g129(.A1(new_n217_), .A2(new_n92_), .A3(new_n218_), .B(new_n219_), .Y(new_n220_));
  NAND2x1_ASAP7_75t_R  g130(.A(p25), .B(new_n133_), .Y(new_n221_));
  OA31x2_ASAP7_75t_R   g131(.A1(new_n135_), .A2(new_n216_), .A3(new_n220_), .B1(new_n221_), .Y(new_n222_));
  AND2x2_ASAP7_75t_R   g132(.A(p59), .B(p29), .Y(new_n223_));
  INVx1_ASAP7_75t_R    g133(.A(p35), .Y(new_n224_));
  AND3x1_ASAP7_75t_R   g134(.A(new_n167_), .B(new_n224_), .C(p40), .Y(new_n225_));
  AND3x1_ASAP7_75t_R   g135(.A(new_n159_), .B(p44), .C(p43), .Y(new_n226_));
  AND5x1_ASAP7_75t_R   g136(.A(p52), .B(new_n206_), .C(new_n163_), .D(new_n164_), .E(new_n161_), .Y(new_n227_));
  OR3x1_ASAP7_75t_R    g137(.A(new_n186_), .B(new_n198_), .C(new_n204_), .Y(new_n228_));
  AND5x1_ASAP7_75t_R   g138(.A(new_n205_), .B(new_n225_), .C(new_n226_), .D(new_n227_), .E(new_n228_), .Y(new_n229_));
  NOR2x1_ASAP7_75t_R   g139(.A(p45), .B(new_n187_), .Y(new_n230_));
  AND2x2_ASAP7_75t_R   g140(.A(p46), .B(p45), .Y(new_n231_));
  AO211x2_ASAP7_75t_R  g141(.A1(new_n194_), .A2(new_n230_), .B(new_n231_), .C(new_n158_), .Y(new_n232_));
  NOR2x1_ASAP7_75t_R   g142(.A(p32), .B(p42), .Y(new_n233_));
  NOR2x1_ASAP7_75t_R   g143(.A(p36), .B(p37), .Y(new_n234_));
  INVx1_ASAP7_75t_R    g144(.A(p30), .Y(new_n235_));
  AND3x1_ASAP7_75t_R   g145(.A(new_n234_), .B(new_n176_), .C(new_n235_), .Y(new_n236_));
  NOR2x1_ASAP7_75t_R   g146(.A(p39), .B(p34), .Y(new_n237_));
  AND2x2_ASAP7_75t_R   g147(.A(p38), .B(new_n174_), .Y(new_n238_));
  INVx1_ASAP7_75t_R    g148(.A(p56), .Y(new_n239_));
  NOR2x1_ASAP7_75t_R   g149(.A(p31), .B(new_n239_), .Y(new_n240_));
  AND5x1_ASAP7_75t_R   g150(.A(new_n233_), .B(new_n236_), .C(new_n237_), .D(new_n238_), .E(new_n240_), .Y(new_n241_));
  NAND3x1_ASAP7_75t_R  g151(.A(new_n229_), .B(new_n232_), .C(new_n241_), .Y(new_n242_));
  OAI21x1_ASAP7_75t_R  g152(.A1(new_n223_), .A2(new_n242_), .B(new_n212_), .Y(new_n243_));
  NOR2x1_ASAP7_75t_R   g153(.A(new_n104_), .B(new_n134_), .Y(new_n244_));
  AOI211x1_ASAP7_75t_R g154(.A1(new_n222_), .A2(new_n150_), .B(new_n243_), .C(new_n244_), .Y(o2));
  assign               o3 = 1'b0;
  assign               o4 = 1'b0;
  assign               o5 = 1'b0;
  assign               o6 = 1'b0;
  assign               o7 = 1'b0;
  assign               o8 = 1'b0;
  assign               o9 = 1'b0;
  assign               o10 = 1'b0;
  assign               o11 = 1'b0;
  assign               o12 = 1'b0;
  assign               o13 = 1'b0;
  assign               o14 = 1'b0;
  assign               o15 = 1'b0;
  assign               o16 = 1'b0;
  assign               o17 = 1'b0;
  assign               o18 = 1'b0;
  assign               o19 = 1'b0;
  assign               o20 = 1'b0;
  assign               o21 = 1'b0;
  assign               o22 = 1'b0;
  assign               o23 = 1'b0;
  assign               o24 = 1'b0;
  assign               o25 = 1'b0;
  assign               o26 = 1'b0;
  assign               o27 = 1'b0;
  assign               o28 = 1'b0;
  assign               o29 = 1'b0;
endmodule


