// Benchmark "/tmp/" written by ABC on Tue Oct 20 18:11:51 2026

module \/tmp/  ( 
    p8, p54, p29, p55, p16, p20, p21, p26, p51, p41, p49, p31, p9, p15,
    p42, p24, p5, p44, p39, p30, p47, p13, p38, p45, p58, p56, p3, p4, p18,
    p10, p52, p1, p19, p11, p34, p14, p53, p48, p36, p17, p43, p23, p33,
    p0, p25, p2, p22, p59, p6, p57, p28, p46, p50, p27, p7, p35, p12, p32,
    p37, p40,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25, o26, o27, o28, o29  );
  input  p8, p54, p29, p55, p16, p20, p21, p26, p51, p41, p49, p31, p9,
    p15, p42, p24, p5, p44, p39, p30, p47, p13, p38, p45, p58, p56, p3, p4,
    p18, p10, p52, p1, p19, p11, p34, p14, p53, p48, p36, p17, p43, p23,
    p33, p0, p25, p2, p22, p59, p6, p57, p28, p46, p50, p27, p7, p35, p12,
    p32, p37, p40;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25, o26, o27, o28, o29;
  wire new_n91_, new_n92_, new_n93_, new_n94_, new_n95_, new_n96_, new_n97_,
    new_n98_, new_n99_, new_n100_, new_n101_, new_n102_, new_n103_,
    new_n104_, new_n105_, new_n106_, new_n107_, new_n108_, new_n109_,
    new_n110_, new_n111_, new_n112_, new_n113_, new_n114_, new_n115_,
    new_n116_, new_n117_, new_n118_, new_n119_, new_n120_, new_n121_,
    new_n122_, new_n123_, new_n124_, new_n125_, new_n126_, new_n127_,
    new_n128_, new_n129_, new_n130_, new_n131_, new_n132_, new_n133_,
    new_n134_, new_n135_, new_n136_, new_n137_, new_n138_, new_n139_,
    new_n140_, new_n141_, new_n142_, new_n143_, new_n144_, new_n145_,
    new_n146_, new_n148_, new_n149_, new_n150_, new_n151_, new_n152_,
    new_n153_, new_n154_, new_n155_, new_n156_, new_n157_, new_n158_,
    new_n159_, new_n160_, new_n161_, new_n162_, new_n163_, new_n164_,
    new_n165_, new_n166_, new_n167_, new_n168_, new_n169_, new_n170_,
    new_n171_, new_n172_, new_n173_, new_n174_, new_n175_, new_n176_,
    new_n177_, new_n178_, new_n179_, new_n180_, new_n181_, new_n182_,
    new_n183_, new_n184_, new_n185_, new_n186_, new_n187_, new_n188_,
    new_n189_, new_n190_, new_n191_, new_n192_, new_n193_, new_n194_,
    new_n195_, new_n196_, new_n197_, new_n198_, new_n199_, new_n200_,
    new_n201_, new_n202_, new_n203_, new_n204_, new_n205_, new_n206_,
    new_n207_, new_n208_, new_n209_, new_n210_, new_n211_, new_n212_,
    new_n213_, new_n214_, new_n215_, new_n216_, new_n217_, new_n219_,
    new_n220_, new_n221_, new_n222_, new_n223_, new_n224_, new_n225_,
    new_n226_, new_n227_, new_n228_, new_n229_, new_n230_, new_n231_,
    new_n232_, new_n233_, new_n234_, new_n235_, new_n236_, new_n237_,
    new_n238_, new_n239_, new_n240_;
  AND3x1_ASAP7_75t_R   g000(.A(p26), .B(p28), .C(p27), .Y(new_n91_));
  NOR2x1_ASAP7_75t_R   g001(.A(p20), .B(p21), .Y(new_n92_));
  NOR2x1_ASAP7_75t_R   g002(.A(p11), .B(p12), .Y(new_n93_));
  OAI21x1_ASAP7_75t_R  g003(.A1(p8), .A2(p9), .B(p10), .Y(new_n94_));
  NAND2x1_ASAP7_75t_R  g004(.A(p13), .B(p14), .Y(new_n95_));
  AOI21x1_ASAP7_75t_R  g005(.A1(new_n93_), .A2(new_n94_), .B(new_n95_), .Y(new_n96_));
  AO21x1_ASAP7_75t_R   g006(.A1(p16), .A2(p15), .B(p17), .Y(new_n97_));
  AOI21x1_ASAP7_75t_R  g007(.A1(p16), .A2(new_n96_), .B(new_n97_), .Y(new_n98_));
  NAND2x1_ASAP7_75t_R  g008(.A(p24), .B(p23), .Y(new_n99_));
  AND2x2_ASAP7_75t_R   g009(.A(p18), .B(p19), .Y(new_n100_));
  INVx1_ASAP7_75t_R    g010(.A(new_n92_), .Y(new_n101_));
  OAI21x1_ASAP7_75t_R  g011(.A1(new_n100_), .A2(new_n101_), .B(p22), .Y(new_n102_));
  AOI211x1_ASAP7_75t_R g012(.A1(new_n92_), .A2(new_n98_), .B(new_n99_), .C(new_n102_), .Y(new_n103_));
  AND2x2_ASAP7_75t_R   g013(.A(p25), .B(new_n91_), .Y(new_n104_));
  INVx1_ASAP7_75t_R    g014(.A(p8), .Y(new_n105_));
  INVx1_ASAP7_75t_R    g015(.A(p9), .Y(new_n106_));
  AND3x1_ASAP7_75t_R   g016(.A(new_n93_), .B(new_n105_), .C(new_n106_), .Y(new_n107_));
  AND4x2_ASAP7_75t_R   g017(.A(p3), .B(p4), .C(p18), .D(p10), .Y(new_n108_));
  OR2x4_ASAP7_75t_R    g018(.A(p16), .B(p15), .Y(new_n109_));
  INVx1_ASAP7_75t_R    g019(.A(p24), .Y(new_n110_));
  NOR2x1_ASAP7_75t_R   g020(.A(p15), .B(new_n110_), .Y(new_n111_));
  AND2x2_ASAP7_75t_R   g021(.A(p5), .B(p13), .Y(new_n112_));
  AND5x1_ASAP7_75t_R   g022(.A(new_n107_), .B(new_n108_), .C(new_n109_), .D(new_n111_), .E(new_n112_), .Y(new_n113_));
  AO21x1_ASAP7_75t_R   g023(.A1(p22), .A2(new_n101_), .B(p23), .Y(new_n114_));
  AND3x1_ASAP7_75t_R   g024(.A(p2), .B(p59), .C(p6), .Y(new_n115_));
  AND2x2_ASAP7_75t_R   g025(.A(p1), .B(p14), .Y(new_n116_));
  INVx1_ASAP7_75t_R    g026(.A(p25), .Y(new_n117_));
  AND5x1_ASAP7_75t_R   g027(.A(p0), .B(new_n115_), .C(new_n116_), .D(new_n117_), .E(p7), .Y(new_n118_));
  AND2x2_ASAP7_75t_R   g028(.A(p19), .B(p22), .Y(new_n119_));
  AND3x1_ASAP7_75t_R   g029(.A(new_n91_), .B(new_n119_), .C(new_n92_), .Y(new_n120_));
  AND5x1_ASAP7_75t_R   g030(.A(new_n98_), .B(new_n113_), .C(new_n114_), .D(new_n118_), .E(new_n120_), .Y(new_n121_));
  AO211x2_ASAP7_75t_R  g031(.A1(new_n91_), .A2(new_n103_), .B(new_n104_), .C(new_n121_), .Y(new_n122_));
  AOI21x1_ASAP7_75t_R  g032(.A1(new_n92_), .A2(new_n98_), .B(new_n102_), .Y(new_n123_));
  INVx1_ASAP7_75t_R    g033(.A(new_n99_), .Y(new_n124_));
  NAND3x1_ASAP7_75t_R  g034(.A(new_n123_), .B(new_n91_), .C(new_n124_), .Y(new_n125_));
  INVx1_ASAP7_75t_R    g035(.A(new_n104_), .Y(new_n126_));
  OA21x2_ASAP7_75t_R   g036(.A1(p15), .A2(new_n96_), .B(p16), .Y(new_n127_));
  INVx1_ASAP7_75t_R    g037(.A(p13), .Y(new_n128_));
  OR5x1_ASAP7_75t_R    g038(.A(new_n105_), .B(new_n99_), .C(p9), .D(p5), .E(new_n128_), .Y(new_n129_));
  NAND2x1_ASAP7_75t_R  g039(.A(p19), .B(p22), .Y(new_n130_));
  OR5x1_ASAP7_75t_R    g040(.A(p20), .B(new_n130_), .C(p21), .D(p4), .E(p1), .Y(new_n131_));
  AOI211x1_ASAP7_75t_R g041(.A1(p15), .A2(new_n96_), .B(new_n129_), .C(new_n131_), .Y(new_n132_));
  INVx1_ASAP7_75t_R    g042(.A(p3), .Y(new_n133_));
  NOR3x1_ASAP7_75t_R   g043(.A(p6), .B(p7), .C(p12), .Y(new_n134_));
  NOR2x1_ASAP7_75t_R   g044(.A(p17), .B(p0), .Y(new_n135_));
  NOR2x1_ASAP7_75t_R   g045(.A(p25), .B(p2), .Y(new_n136_));
  AND5x1_ASAP7_75t_R   g046(.A(new_n133_), .B(new_n134_), .C(p18), .D(new_n135_), .E(new_n136_), .Y(new_n137_));
  INVx1_ASAP7_75t_R    g047(.A(p14), .Y(new_n138_));
  AO21x1_ASAP7_75t_R   g048(.A1(new_n93_), .A2(new_n94_), .B(new_n128_), .Y(new_n139_));
  AO21x1_ASAP7_75t_R   g049(.A1(new_n138_), .A2(new_n139_), .B(new_n96_), .Y(new_n140_));
  NAND2x1_ASAP7_75t_R  g050(.A(new_n105_), .B(new_n106_), .Y(new_n141_));
  INVx1_ASAP7_75t_R    g051(.A(p10), .Y(new_n142_));
  NAND2x1_ASAP7_75t_R  g052(.A(p11), .B(new_n142_), .Y(new_n143_));
  AOI22x1_ASAP7_75t_R  g053(.A1(new_n141_), .A2(p11), .B1(new_n143_), .B2(new_n94_), .Y(new_n144_));
  AND5x1_ASAP7_75t_R   g054(.A(new_n127_), .B(new_n132_), .C(new_n137_), .D(new_n140_), .E(new_n144_), .Y(new_n145_));
  AO21x1_ASAP7_75t_R   g055(.A1(new_n125_), .A2(new_n126_), .B(new_n145_), .Y(new_n146_));
  NAND2x1_ASAP7_75t_R  g056(.A(new_n122_), .B(new_n146_), .Y(o0));
  AOI21x1_ASAP7_75t_R  g057(.A1(new_n126_), .A2(new_n125_), .B(new_n145_), .Y(new_n148_));
  NAND2x1_ASAP7_75t_R  g058(.A(p49), .B(p48), .Y(new_n149_));
  NOR2x1_ASAP7_75t_R   g059(.A(p41), .B(p42), .Y(new_n150_));
  OAI21x1_ASAP7_75t_R  g060(.A1(p39), .A2(p38), .B(p40), .Y(new_n151_));
  NAND2x1_ASAP7_75t_R  g061(.A(p44), .B(p43), .Y(new_n152_));
  AOI21x1_ASAP7_75t_R  g062(.A1(new_n150_), .A2(new_n151_), .B(new_n152_), .Y(new_n153_));
  AO21x1_ASAP7_75t_R   g063(.A1(p45), .A2(p46), .B(p47), .Y(new_n154_));
  AOI21x1_ASAP7_75t_R  g064(.A1(p46), .A2(new_n153_), .B(new_n154_), .Y(new_n155_));
  INVx1_ASAP7_75t_R    g065(.A(p51), .Y(new_n156_));
  NAND2x1_ASAP7_75t_R  g066(.A(p52), .B(new_n156_), .Y(new_n157_));
  OAI21x1_ASAP7_75t_R  g067(.A1(new_n149_), .A2(new_n155_), .B(new_n157_), .Y(new_n158_));
  INVx1_ASAP7_75t_R    g068(.A(p43), .Y(new_n159_));
  AO21x1_ASAP7_75t_R   g069(.A1(new_n150_), .A2(new_n151_), .B(new_n159_), .Y(new_n160_));
  AND3x1_ASAP7_75t_R   g070(.A(p58), .B(p56), .C(p57), .Y(new_n161_));
  AND3x1_ASAP7_75t_R   g071(.A(p32), .B(p37), .C(p40), .Y(new_n162_));
  AND2x2_ASAP7_75t_R   g072(.A(p36), .B(p33), .Y(new_n163_));
  AND5x1_ASAP7_75t_R   g073(.A(p46), .B(new_n161_), .C(new_n162_), .D(new_n163_), .E(p35), .Y(new_n164_));
  AND2x2_ASAP7_75t_R   g074(.A(p49), .B(p48), .Y(new_n165_));
  AND2x2_ASAP7_75t_R   g075(.A(p31), .B(p34), .Y(new_n166_));
  NOR2x1_ASAP7_75t_R   g076(.A(p47), .B(p45), .Y(new_n167_));
  AND5x1_ASAP7_75t_R   g077(.A(p44), .B(new_n165_), .C(new_n166_), .D(p30), .E(new_n167_), .Y(new_n168_));
  NAND2x1_ASAP7_75t_R  g078(.A(p41), .B(p42), .Y(new_n169_));
  OAI21x1_ASAP7_75t_R  g079(.A1(new_n169_), .A2(new_n151_), .B(new_n159_), .Y(new_n170_));
  NOR2x1_ASAP7_75t_R   g080(.A(p39), .B(p38), .Y(new_n171_));
  INVx1_ASAP7_75t_R    g081(.A(p55), .Y(new_n172_));
  AND5x1_ASAP7_75t_R   g082(.A(p54), .B(new_n171_), .C(p29), .D(new_n172_), .E(p53), .Y(new_n173_));
  AND5x1_ASAP7_75t_R   g083(.A(new_n160_), .B(new_n164_), .C(new_n168_), .D(new_n170_), .E(new_n173_), .Y(new_n174_));
  NAND2x1_ASAP7_75t_R  g084(.A(new_n158_), .B(new_n174_), .Y(new_n175_));
  AND3x1_ASAP7_75t_R   g085(.A(p54), .B(p52), .C(p53), .Y(new_n176_));
  OA21x2_ASAP7_75t_R   g086(.A1(p55), .A2(new_n176_), .B(new_n161_), .Y(new_n177_));
  NOR2x1_ASAP7_75t_R   g087(.A(p51), .B(p50), .Y(new_n178_));
  AND2x2_ASAP7_75t_R   g088(.A(new_n172_), .B(new_n178_), .Y(new_n179_));
  OAI21x1_ASAP7_75t_R  g089(.A1(new_n149_), .A2(new_n155_), .B(new_n179_), .Y(new_n180_));
  NOR2x1_ASAP7_75t_R   g090(.A(p59), .B(p50), .Y(new_n181_));
  AOI21x1_ASAP7_75t_R  g091(.A1(new_n177_), .A2(new_n180_), .B(new_n181_), .Y(new_n182_));
  INVx1_ASAP7_75t_R    g092(.A(p41), .Y(new_n183_));
  NAND2x1_ASAP7_75t_R  g093(.A(new_n183_), .B(new_n151_), .Y(new_n184_));
  AND2x2_ASAP7_75t_R   g094(.A(p54), .B(p53), .Y(new_n185_));
  NAND2x1_ASAP7_75t_R  g095(.A(p47), .B(p46), .Y(new_n186_));
  NOR2x1_ASAP7_75t_R   g096(.A(p31), .B(p30), .Y(new_n187_));
  AND5x1_ASAP7_75t_R   g097(.A(new_n184_), .B(new_n165_), .C(new_n185_), .D(new_n186_), .E(new_n187_), .Y(new_n188_));
  NAND2x1_ASAP7_75t_R  g098(.A(p38), .B(p56), .Y(new_n189_));
  OR3x1_ASAP7_75t_R    g099(.A(new_n189_), .B(p39), .C(p45), .Y(new_n190_));
  NOR2x1_ASAP7_75t_R   g100(.A(p55), .B(p42), .Y(new_n191_));
  AND2x2_ASAP7_75t_R   g101(.A(p44), .B(p43), .Y(new_n192_));
  NAND2x1_ASAP7_75t_R  g102(.A(new_n191_), .B(new_n192_), .Y(new_n193_));
  NOR2x1_ASAP7_75t_R   g103(.A(p50), .B(p37), .Y(new_n194_));
  INVx1_ASAP7_75t_R    g104(.A(p36), .Y(new_n195_));
  NAND3x1_ASAP7_75t_R  g105(.A(new_n194_), .B(new_n195_), .C(p40), .Y(new_n196_));
  NOR3x1_ASAP7_75t_R   g106(.A(new_n190_), .B(new_n193_), .C(new_n196_), .Y(new_n197_));
  NOR2x1_ASAP7_75t_R   g107(.A(new_n183_), .B(new_n151_), .Y(new_n198_));
  NOR2x1_ASAP7_75t_R   g108(.A(p34), .B(p35), .Y(new_n199_));
  NOR2x1_ASAP7_75t_R   g109(.A(p33), .B(p32), .Y(new_n200_));
  NAND2x1_ASAP7_75t_R  g110(.A(new_n199_), .B(new_n200_), .Y(new_n201_));
  NOR3x1_ASAP7_75t_R   g111(.A(new_n198_), .B(new_n201_), .C(new_n157_), .Y(new_n202_));
  NAND3x1_ASAP7_75t_R  g112(.A(new_n188_), .B(new_n197_), .C(new_n202_), .Y(new_n203_));
  INVx1_ASAP7_75t_R    g113(.A(p47), .Y(new_n204_));
  OR2x4_ASAP7_75t_R    g114(.A(p45), .B(new_n204_), .Y(new_n205_));
  NOR2x1_ASAP7_75t_R   g115(.A(new_n153_), .B(new_n205_), .Y(new_n206_));
  AND2x2_ASAP7_75t_R   g116(.A(p45), .B(p46), .Y(new_n207_));
  AO21x1_ASAP7_75t_R   g117(.A1(p46), .A2(new_n153_), .B(new_n207_), .Y(new_n208_));
  NOR2x1_ASAP7_75t_R   g118(.A(p29), .B(p59), .Y(new_n209_));
  OAI21x1_ASAP7_75t_R  g119(.A1(new_n206_), .A2(new_n208_), .B(new_n209_), .Y(new_n210_));
  INVx1_ASAP7_75t_R    g120(.A(p46), .Y(new_n211_));
  AOI211x1_ASAP7_75t_R g121(.A1(new_n150_), .A2(new_n151_), .B(new_n211_), .C(new_n152_), .Y(new_n212_));
  OAI21x1_ASAP7_75t_R  g122(.A1(new_n154_), .A2(new_n212_), .B(new_n165_), .Y(new_n213_));
  INVx1_ASAP7_75t_R    g123(.A(new_n177_), .Y(new_n214_));
  AOI21x1_ASAP7_75t_R  g124(.A1(new_n179_), .A2(new_n213_), .B(new_n214_), .Y(new_n215_));
  OAI21x1_ASAP7_75t_R  g125(.A1(new_n203_), .A2(new_n210_), .B(new_n215_), .Y(new_n216_));
  OAI21x1_ASAP7_75t_R  g126(.A1(new_n175_), .A2(new_n182_), .B(new_n216_), .Y(new_n217_));
  OAI21x1_ASAP7_75t_R  g127(.A1(new_n148_), .A2(new_n217_), .B(new_n122_), .Y(o1));
  NOR2x1_ASAP7_75t_R   g128(.A(p45), .B(new_n153_), .Y(new_n219_));
  OAI22x1_ASAP7_75t_R  g129(.A1(new_n219_), .A2(new_n211_), .B1(new_n153_), .B2(new_n205_), .Y(new_n220_));
  AND5x1_ASAP7_75t_R   g130(.A(p54), .B(new_n199_), .C(new_n200_), .D(new_n187_), .E(p53), .Y(new_n221_));
  INVx1_ASAP7_75t_R    g131(.A(p40), .Y(new_n222_));
  OR3x1_ASAP7_75t_R    g132(.A(new_n171_), .B(new_n183_), .C(new_n222_), .Y(new_n223_));
  NOR2x1_ASAP7_75t_R   g133(.A(new_n149_), .B(new_n157_), .Y(new_n224_));
  AND5x1_ASAP7_75t_R   g134(.A(new_n184_), .B(new_n221_), .C(new_n223_), .D(new_n224_), .E(new_n186_), .Y(new_n225_));
  NOR2x1_ASAP7_75t_R   g135(.A(p45), .B(p50), .Y(new_n226_));
  AND3x1_ASAP7_75t_R   g136(.A(new_n226_), .B(new_n172_), .C(p56), .Y(new_n227_));
  INVx1_ASAP7_75t_R    g137(.A(p42), .Y(new_n228_));
  AND3x1_ASAP7_75t_R   g138(.A(new_n192_), .B(new_n228_), .C(p40), .Y(new_n229_));
  INVx1_ASAP7_75t_R    g139(.A(p38), .Y(new_n230_));
  NOR2x1_ASAP7_75t_R   g140(.A(p39), .B(new_n230_), .Y(new_n231_));
  NOR2x1_ASAP7_75t_R   g141(.A(p36), .B(p37), .Y(new_n232_));
  NAND2x1_ASAP7_75t_R  g142(.A(p29), .B(p59), .Y(new_n233_));
  AND5x1_ASAP7_75t_R   g143(.A(new_n227_), .B(new_n229_), .C(new_n231_), .D(new_n232_), .E(new_n233_), .Y(new_n234_));
  NAND3x1_ASAP7_75t_R  g144(.A(new_n220_), .B(new_n225_), .C(new_n234_), .Y(new_n235_));
  INVx1_ASAP7_75t_R    g145(.A(new_n176_), .Y(new_n236_));
  OA21x2_ASAP7_75t_R   g146(.A1(new_n178_), .A2(new_n236_), .B(new_n172_), .Y(new_n237_));
  OAI21x1_ASAP7_75t_R  g147(.A1(new_n236_), .A2(new_n213_), .B(new_n237_), .Y(new_n238_));
  NAND3x1_ASAP7_75t_R  g148(.A(new_n235_), .B(new_n161_), .C(new_n238_), .Y(new_n239_));
  AOI211x1_ASAP7_75t_R g149(.A1(new_n91_), .A2(new_n103_), .B(new_n104_), .C(new_n121_), .Y(new_n240_));
  NOR3x1_ASAP7_75t_R   g150(.A(new_n148_), .B(new_n239_), .C(new_n240_), .Y(o2));
  assign               o3 = 1'b0;
  assign               o4 = 1'b0;
  assign               o5 = 1'b0;
  assign               o6 = 1'b0;
  assign               o7 = 1'b0;
  assign               o8 = 1'b0;
  assign               o9 = 1'b0;
  assign               o10 = 1'b0;
  assign               o11 = 1'b0;
  assign               o12 = 1'b0;
  assign               o13 = 1'b0;
  assign               o14 = 1'b0;
  assign               o15 = 1'b0;
  assign               o16 = 1'b0;
  assign               o17 = 1'b0;
  assign               o18 = 1'b0;
  assign               o19 = 1'b0;
  assign               o20 = 1'b0;
  assign               o21 = 1'b0;
  assign               o22 = 1'b0;
  assign               o23 = 1'b0;
  assign               o24 = 1'b0;
  assign               o25 = 1'b0;
  assign               o26 = 1'b0;
  assign               o27 = 1'b0;
  assign               o28 = 1'b0;
  assign               o29 = 1'b0;
endmodule


