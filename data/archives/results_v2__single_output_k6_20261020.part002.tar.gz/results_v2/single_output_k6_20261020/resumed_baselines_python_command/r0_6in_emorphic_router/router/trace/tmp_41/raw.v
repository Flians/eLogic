// Benchmark "/tmp/" written by ABC on Tue Oct 20 18:11:48 2026

module \/tmp/  ( 
    p37, p57, p6, p58, p1, p42, p46, p54, p31, p23, p52, p0, p45, p14, p24,
    p13, p12, p40, p2, p17, p53, p43, p26, p59, p38, p21, p3, p4, p8, p7,
    p30, p28, p33, p56, p35, p15, p16, p20, p48, p5, p27, p50, p32, p49,
    p18, p51, p9, p34, p55, p11, p25, p10, p19, p39, p41, p22, p29, p47,
    p36, p44,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25, o26, o27, o28, o29  );
  input  p37, p57, p6, p58, p1, p42, p46, p54, p31, p23, p52, p0, p45,
    p14, p24, p13, p12, p40, p2, p17, p53, p43, p26, p59, p38, p21, p3, p4,
    p8, p7, p30, p28, p33, p56, p35, p15, p16, p20, p48, p5, p27, p50, p32,
    p49, p18, p51, p9, p34, p55, p11, p25, p10, p19, p39, p41, p22, p29,
    p47, p36, p44;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25, o26, o27, o28, o29;
  wire new_n91_, new_n92_, new_n93_, new_n94_, new_n95_, new_n96_, new_n97_,
    new_n98_, new_n99_, new_n100_, new_n101_, new_n102_, new_n103_,
    new_n104_, new_n105_, new_n106_, new_n107_, new_n108_, new_n109_,
    new_n110_, new_n111_, new_n112_, new_n113_, new_n114_, new_n115_,
    new_n116_, new_n117_, new_n118_, new_n119_, new_n120_, new_n121_,
    new_n122_, new_n123_, new_n124_, new_n125_, new_n126_, new_n127_,
    new_n128_, new_n129_, new_n130_, new_n131_, new_n132_, new_n133_,
    new_n134_, new_n135_, new_n136_, new_n138_, new_n139_, new_n140_,
    new_n141_, new_n142_, new_n143_, new_n144_, new_n145_, new_n146_,
    new_n147_, new_n148_, new_n149_, new_n150_, new_n151_, new_n152_,
    new_n153_, new_n154_, new_n155_, new_n156_, new_n157_, new_n158_,
    new_n159_, new_n160_, new_n161_, new_n162_, new_n163_, new_n164_,
    new_n165_, new_n166_, new_n167_, new_n168_, new_n169_, new_n170_,
    new_n171_, new_n172_, new_n173_, new_n174_, new_n175_, new_n176_,
    new_n177_, new_n178_, new_n179_, new_n180_, new_n181_, new_n182_,
    new_n183_, new_n184_, new_n185_, new_n186_, new_n187_, new_n188_,
    new_n189_, new_n190_, new_n191_, new_n192_, new_n193_, new_n194_,
    new_n195_, new_n196_, new_n197_, new_n198_, new_n199_, new_n200_,
    new_n201_, new_n202_, new_n203_, new_n204_, new_n205_, new_n206_,
    new_n207_, new_n208_, new_n209_, new_n210_, new_n211_, new_n212_,
    new_n213_, new_n214_, new_n215_, new_n216_, new_n218_, new_n219_,
    new_n220_, new_n221_, new_n222_, new_n223_, new_n224_, new_n225_,
    new_n226_, new_n227_, new_n228_, new_n229_, new_n230_, new_n231_,
    new_n232_, new_n233_, new_n234_, new_n235_;
  AND3x1_ASAP7_75t_R   g000(.A(p26), .B(p28), .C(p27), .Y(new_n91_));
  NOR2x1_ASAP7_75t_R   g001(.A(p21), .B(p20), .Y(new_n92_));
  NOR2x1_ASAP7_75t_R   g002(.A(p12), .B(p11), .Y(new_n93_));
  OAI21x1_ASAP7_75t_R  g003(.A1(p8), .A2(p9), .B(p10), .Y(new_n94_));
  NAND2x1_ASAP7_75t_R  g004(.A(p14), .B(p13), .Y(new_n95_));
  AOI21x1_ASAP7_75t_R  g005(.A1(new_n93_), .A2(new_n94_), .B(new_n95_), .Y(new_n96_));
  AO21x1_ASAP7_75t_R   g006(.A1(p15), .A2(p16), .B(p17), .Y(new_n97_));
  AOI21x1_ASAP7_75t_R  g007(.A1(p16), .A2(new_n96_), .B(new_n97_), .Y(new_n98_));
  AND2x2_ASAP7_75t_R   g008(.A(p23), .B(p24), .Y(new_n99_));
  INVx1_ASAP7_75t_R    g009(.A(new_n99_), .Y(new_n100_));
  AND2x2_ASAP7_75t_R   g010(.A(p18), .B(p19), .Y(new_n101_));
  INVx1_ASAP7_75t_R    g011(.A(new_n92_), .Y(new_n102_));
  OAI21x1_ASAP7_75t_R  g012(.A1(new_n101_), .A2(new_n102_), .B(p22), .Y(new_n103_));
  AOI211x1_ASAP7_75t_R g013(.A1(new_n92_), .A2(new_n98_), .B(new_n100_), .C(new_n103_), .Y(new_n104_));
  AND2x2_ASAP7_75t_R   g014(.A(p25), .B(new_n91_), .Y(new_n105_));
  AO21x1_ASAP7_75t_R   g015(.A1(new_n91_), .A2(new_n104_), .B(new_n105_), .Y(new_n106_));
  OA21x2_ASAP7_75t_R   g016(.A1(p15), .A2(new_n96_), .B(p16), .Y(new_n107_));
  AND3x1_ASAP7_75t_R   g017(.A(new_n92_), .B(p19), .C(p22), .Y(new_n108_));
  INVx1_ASAP7_75t_R    g018(.A(p4), .Y(new_n109_));
  INVx1_ASAP7_75t_R    g019(.A(p9), .Y(new_n110_));
  AND2x2_ASAP7_75t_R   g020(.A(p10), .B(new_n110_), .Y(new_n111_));
  NOR2x1_ASAP7_75t_R   g021(.A(p7), .B(p5), .Y(new_n112_));
  NOR2x1_ASAP7_75t_R   g022(.A(p17), .B(p3), .Y(new_n113_));
  AND5x1_ASAP7_75t_R   g023(.A(new_n109_), .B(new_n111_), .C(p8), .D(new_n112_), .E(new_n113_), .Y(new_n114_));
  INVx1_ASAP7_75t_R    g024(.A(p25), .Y(new_n115_));
  AND3x1_ASAP7_75t_R   g025(.A(new_n93_), .B(p18), .C(new_n115_), .Y(new_n116_));
  NAND2x1_ASAP7_75t_R  g026(.A(p15), .B(new_n96_), .Y(new_n117_));
  OR4x2_ASAP7_75t_R    g027(.A(p6), .B(p1), .C(p0), .D(p2), .Y(new_n118_));
  NOR3x1_ASAP7_75t_R   g028(.A(new_n100_), .B(new_n118_), .C(new_n95_), .Y(new_n119_));
  AND5x1_ASAP7_75t_R   g029(.A(new_n108_), .B(new_n114_), .C(new_n116_), .D(new_n117_), .E(new_n119_), .Y(new_n120_));
  NAND2x1_ASAP7_75t_R  g030(.A(new_n107_), .B(new_n120_), .Y(new_n121_));
  NOR2x1_ASAP7_75t_R   g031(.A(p8), .B(p9), .Y(new_n122_));
  AND3x1_ASAP7_75t_R   g032(.A(new_n122_), .B(p6), .C(p1), .Y(new_n123_));
  AND4x2_ASAP7_75t_R   g033(.A(p0), .B(p14), .C(p24), .D(p13), .Y(new_n124_));
  INVx1_ASAP7_75t_R    g034(.A(p7), .Y(new_n125_));
  NOR2x1_ASAP7_75t_R   g035(.A(p15), .B(new_n125_), .Y(new_n126_));
  AND2x2_ASAP7_75t_R   g036(.A(p5), .B(p10), .Y(new_n127_));
  AND4x2_ASAP7_75t_R   g037(.A(p2), .B(p59), .C(p3), .D(p4), .Y(new_n128_));
  AND5x1_ASAP7_75t_R   g038(.A(new_n123_), .B(new_n124_), .C(new_n126_), .D(new_n127_), .E(new_n128_), .Y(new_n129_));
  AO21x1_ASAP7_75t_R   g039(.A1(p22), .A2(new_n102_), .B(p23), .Y(new_n130_));
  AND3x1_ASAP7_75t_R   g040(.A(new_n108_), .B(new_n116_), .C(new_n91_), .Y(new_n131_));
  INVx1_ASAP7_75t_R    g041(.A(p16), .Y(new_n132_));
  AO21x1_ASAP7_75t_R   g042(.A1(new_n93_), .A2(new_n94_), .B(new_n95_), .Y(new_n133_));
  NAND2x1_ASAP7_75t_R  g043(.A(new_n132_), .B(new_n133_), .Y(new_n134_));
  AND5x1_ASAP7_75t_R   g044(.A(new_n98_), .B(new_n129_), .C(new_n130_), .D(new_n131_), .E(new_n134_), .Y(new_n135_));
  AOI211x1_ASAP7_75t_R g045(.A1(new_n91_), .A2(new_n104_), .B(new_n105_), .C(new_n135_), .Y(new_n136_));
  AO21x1_ASAP7_75t_R   g046(.A1(new_n106_), .A2(new_n121_), .B(new_n136_), .Y(o0));
  INVx1_ASAP7_75t_R    g047(.A(new_n91_), .Y(new_n138_));
  AOI21x1_ASAP7_75t_R  g048(.A1(new_n92_), .A2(new_n98_), .B(new_n103_), .Y(new_n139_));
  AOI21x1_ASAP7_75t_R  g049(.A1(new_n99_), .A2(new_n139_), .B(p25), .Y(new_n140_));
  AOI211x1_ASAP7_75t_R g050(.A1(new_n107_), .A2(new_n120_), .B(new_n138_), .C(new_n140_), .Y(new_n141_));
  AND2x2_ASAP7_75t_R   g051(.A(p48), .B(p49), .Y(new_n142_));
  INVx1_ASAP7_75t_R    g052(.A(new_n142_), .Y(new_n143_));
  NOR2x1_ASAP7_75t_R   g053(.A(p42), .B(p41), .Y(new_n144_));
  OAI21x1_ASAP7_75t_R  g054(.A1(p38), .A2(p39), .B(p40), .Y(new_n145_));
  NAND2x1_ASAP7_75t_R  g055(.A(p43), .B(p44), .Y(new_n146_));
  AOI21x1_ASAP7_75t_R  g056(.A1(new_n144_), .A2(new_n145_), .B(new_n146_), .Y(new_n147_));
  AO21x1_ASAP7_75t_R   g057(.A1(p46), .A2(p45), .B(p47), .Y(new_n148_));
  AOI21x1_ASAP7_75t_R  g058(.A1(p46), .A2(new_n147_), .B(new_n148_), .Y(new_n149_));
  INVx1_ASAP7_75t_R    g059(.A(p50), .Y(new_n150_));
  INVx1_ASAP7_75t_R    g060(.A(p51), .Y(new_n151_));
  INVx1_ASAP7_75t_R    g061(.A(p55), .Y(new_n152_));
  AND3x1_ASAP7_75t_R   g062(.A(new_n150_), .B(new_n151_), .C(new_n152_), .Y(new_n153_));
  OAI21x1_ASAP7_75t_R  g063(.A1(new_n143_), .A2(new_n149_), .B(new_n153_), .Y(new_n154_));
  AND3x1_ASAP7_75t_R   g064(.A(p54), .B(p52), .C(p53), .Y(new_n155_));
  AND3x1_ASAP7_75t_R   g065(.A(p57), .B(p58), .C(p56), .Y(new_n156_));
  OA21x2_ASAP7_75t_R   g066(.A1(p55), .A2(new_n155_), .B(new_n156_), .Y(new_n157_));
  INVx1_ASAP7_75t_R    g067(.A(p59), .Y(new_n158_));
  AOI22x1_ASAP7_75t_R  g068(.A1(new_n154_), .A2(new_n157_), .B1(new_n158_), .B2(new_n150_), .Y(new_n159_));
  INVx1_ASAP7_75t_R    g069(.A(p31), .Y(new_n160_));
  NOR2x1_ASAP7_75t_R   g070(.A(p45), .B(new_n160_), .Y(new_n161_));
  AND4x2_ASAP7_75t_R   g071(.A(p33), .B(p35), .C(p48), .D(p49), .Y(new_n162_));
  AND2x2_ASAP7_75t_R   g072(.A(p40), .B(p30), .Y(new_n163_));
  AND3x1_ASAP7_75t_R   g073(.A(new_n161_), .B(new_n162_), .C(new_n163_), .Y(new_n164_));
  INVx1_ASAP7_75t_R    g074(.A(p47), .Y(new_n165_));
  NAND3x1_ASAP7_75t_R  g075(.A(new_n165_), .B(p36), .C(p44), .Y(new_n166_));
  NAND2x1_ASAP7_75t_R  g076(.A(p32), .B(p34), .Y(new_n167_));
  NAND2x1_ASAP7_75t_R  g077(.A(p29), .B(new_n152_), .Y(new_n168_));
  NOR3x1_ASAP7_75t_R   g078(.A(new_n166_), .B(new_n167_), .C(new_n168_), .Y(new_n169_));
  NAND2x1_ASAP7_75t_R  g079(.A(p42), .B(p41), .Y(new_n170_));
  INVx1_ASAP7_75t_R    g080(.A(p43), .Y(new_n171_));
  OAI21x1_ASAP7_75t_R  g081(.A1(new_n170_), .A2(new_n145_), .B(new_n171_), .Y(new_n172_));
  NOR2x1_ASAP7_75t_R   g082(.A(p38), .B(p39), .Y(new_n173_));
  AND5x1_ASAP7_75t_R   g083(.A(p37), .B(new_n173_), .C(p46), .D(p54), .E(p53), .Y(new_n174_));
  AND5x1_ASAP7_75t_R   g084(.A(new_n156_), .B(new_n164_), .C(new_n169_), .D(new_n172_), .E(new_n174_), .Y(new_n175_));
  INVx1_ASAP7_75t_R    g085(.A(p52), .Y(new_n176_));
  OAI22x1_ASAP7_75t_R  g086(.A1(new_n149_), .A2(new_n143_), .B1(new_n176_), .B2(p51), .Y(new_n177_));
  AO21x1_ASAP7_75t_R   g087(.A1(new_n144_), .A2(new_n145_), .B(new_n171_), .Y(new_n178_));
  NAND3x1_ASAP7_75t_R  g088(.A(new_n175_), .B(new_n177_), .C(new_n178_), .Y(new_n179_));
  INVx1_ASAP7_75t_R    g089(.A(p40), .Y(new_n180_));
  INVx1_ASAP7_75t_R    g090(.A(p41), .Y(new_n181_));
  OR3x1_ASAP7_75t_R    g091(.A(new_n173_), .B(new_n180_), .C(new_n181_), .Y(new_n182_));
  NOR2x1_ASAP7_75t_R   g092(.A(p33), .B(p32), .Y(new_n183_));
  INVx1_ASAP7_75t_R    g093(.A(p35), .Y(new_n184_));
  INVx1_ASAP7_75t_R    g094(.A(p34), .Y(new_n185_));
  AND3x1_ASAP7_75t_R   g095(.A(new_n183_), .B(new_n184_), .C(new_n185_), .Y(new_n186_));
  NOR2x1_ASAP7_75t_R   g096(.A(p51), .B(new_n176_), .Y(new_n187_));
  AND3x1_ASAP7_75t_R   g097(.A(new_n182_), .B(new_n186_), .C(new_n187_), .Y(new_n188_));
  AND2x2_ASAP7_75t_R   g098(.A(p43), .B(p44), .Y(new_n189_));
  INVx1_ASAP7_75t_R    g099(.A(p39), .Y(new_n190_));
  NOR2x1_ASAP7_75t_R   g100(.A(p37), .B(p42), .Y(new_n191_));
  NAND3x1_ASAP7_75t_R  g101(.A(new_n189_), .B(new_n190_), .C(new_n191_), .Y(new_n192_));
  NAND2x1_ASAP7_75t_R  g102(.A(p40), .B(p56), .Y(new_n193_));
  INVx1_ASAP7_75t_R    g103(.A(p38), .Y(new_n194_));
  OR3x1_ASAP7_75t_R    g104(.A(new_n193_), .B(p45), .C(new_n194_), .Y(new_n195_));
  OR3x1_ASAP7_75t_R    g105(.A(p50), .B(p55), .C(p36), .Y(new_n196_));
  NOR3x1_ASAP7_75t_R   g106(.A(new_n192_), .B(new_n195_), .C(new_n196_), .Y(new_n197_));
  NAND2x1_ASAP7_75t_R  g107(.A(new_n181_), .B(new_n145_), .Y(new_n198_));
  AND2x2_ASAP7_75t_R   g108(.A(p54), .B(p53), .Y(new_n199_));
  NAND2x1_ASAP7_75t_R  g109(.A(p46), .B(p47), .Y(new_n200_));
  NOR2x1_ASAP7_75t_R   g110(.A(p31), .B(p30), .Y(new_n201_));
  AND5x1_ASAP7_75t_R   g111(.A(new_n198_), .B(new_n142_), .C(new_n199_), .D(new_n200_), .E(new_n201_), .Y(new_n202_));
  NAND3x1_ASAP7_75t_R  g112(.A(new_n188_), .B(new_n197_), .C(new_n202_), .Y(new_n203_));
  OR2x4_ASAP7_75t_R    g113(.A(p45), .B(new_n165_), .Y(new_n204_));
  NOR2x1_ASAP7_75t_R   g114(.A(new_n147_), .B(new_n204_), .Y(new_n205_));
  OA21x2_ASAP7_75t_R   g115(.A1(p45), .A2(new_n147_), .B(p46), .Y(new_n206_));
  NOR2x1_ASAP7_75t_R   g116(.A(p59), .B(p29), .Y(new_n207_));
  OAI21x1_ASAP7_75t_R  g117(.A1(new_n205_), .A2(new_n206_), .B(new_n207_), .Y(new_n208_));
  INVx1_ASAP7_75t_R    g118(.A(p46), .Y(new_n209_));
  AOI211x1_ASAP7_75t_R g119(.A1(new_n144_), .A2(new_n145_), .B(new_n209_), .C(new_n146_), .Y(new_n210_));
  OAI21x1_ASAP7_75t_R  g120(.A1(new_n148_), .A2(new_n210_), .B(new_n142_), .Y(new_n211_));
  INVx1_ASAP7_75t_R    g121(.A(new_n157_), .Y(new_n212_));
  AOI21x1_ASAP7_75t_R  g122(.A1(new_n153_), .A2(new_n211_), .B(new_n212_), .Y(new_n213_));
  OAI21x1_ASAP7_75t_R  g123(.A1(new_n203_), .A2(new_n208_), .B(new_n213_), .Y(new_n214_));
  OAI21x1_ASAP7_75t_R  g124(.A1(new_n159_), .A2(new_n179_), .B(new_n214_), .Y(new_n215_));
  AO211x2_ASAP7_75t_R  g125(.A1(new_n91_), .A2(new_n104_), .B(new_n105_), .C(new_n135_), .Y(new_n216_));
  OAI21x1_ASAP7_75t_R  g126(.A1(new_n141_), .A2(new_n215_), .B(new_n216_), .Y(o1));
  AND5x1_ASAP7_75t_R   g127(.A(new_n184_), .B(new_n199_), .C(new_n185_), .D(new_n183_), .E(new_n201_), .Y(new_n218_));
  AND3x1_ASAP7_75t_R   g128(.A(new_n142_), .B(p52), .C(new_n151_), .Y(new_n219_));
  AND5x1_ASAP7_75t_R   g129(.A(new_n198_), .B(new_n218_), .C(new_n182_), .D(new_n200_), .E(new_n219_), .Y(new_n220_));
  NOR2x1_ASAP7_75t_R   g130(.A(p45), .B(new_n147_), .Y(new_n221_));
  OAI22x1_ASAP7_75t_R  g131(.A1(new_n221_), .A2(new_n209_), .B1(new_n147_), .B2(new_n204_), .Y(new_n222_));
  NOR2x1_ASAP7_75t_R   g132(.A(p45), .B(p50), .Y(new_n223_));
  AND3x1_ASAP7_75t_R   g133(.A(new_n223_), .B(p56), .C(new_n152_), .Y(new_n224_));
  NOR2x1_ASAP7_75t_R   g134(.A(p37), .B(p36), .Y(new_n225_));
  AND3x1_ASAP7_75t_R   g135(.A(new_n225_), .B(p38), .C(new_n190_), .Y(new_n226_));
  NOR2x1_ASAP7_75t_R   g136(.A(p42), .B(new_n180_), .Y(new_n227_));
  NAND2x1_ASAP7_75t_R  g137(.A(p59), .B(p29), .Y(new_n228_));
  AND5x1_ASAP7_75t_R   g138(.A(new_n189_), .B(new_n224_), .C(new_n226_), .D(new_n227_), .E(new_n228_), .Y(new_n229_));
  NAND3x1_ASAP7_75t_R  g139(.A(new_n220_), .B(new_n222_), .C(new_n229_), .Y(new_n230_));
  INVx1_ASAP7_75t_R    g140(.A(new_n155_), .Y(new_n231_));
  NOR2x1_ASAP7_75t_R   g141(.A(p50), .B(p51), .Y(new_n232_));
  OA21x2_ASAP7_75t_R   g142(.A1(new_n232_), .A2(new_n231_), .B(new_n152_), .Y(new_n233_));
  OAI21x1_ASAP7_75t_R  g143(.A1(new_n231_), .A2(new_n211_), .B(new_n233_), .Y(new_n234_));
  NAND3x1_ASAP7_75t_R  g144(.A(new_n230_), .B(new_n156_), .C(new_n234_), .Y(new_n235_));
  NOR3x1_ASAP7_75t_R   g145(.A(new_n141_), .B(new_n235_), .C(new_n136_), .Y(o2));
  assign               o3 = 1'b0;
  assign               o4 = 1'b0;
  assign               o5 = 1'b0;
  assign               o6 = 1'b0;
  assign               o7 = 1'b0;
  assign               o8 = 1'b0;
  assign               o9 = 1'b0;
  assign               o10 = 1'b0;
  assign               o11 = 1'b0;
  assign               o12 = 1'b0;
  assign               o13 = 1'b0;
  assign               o14 = 1'b0;
  assign               o15 = 1'b0;
  assign               o16 = 1'b0;
  assign               o17 = 1'b0;
  assign               o18 = 1'b0;
  assign               o19 = 1'b0;
  assign               o20 = 1'b0;
  assign               o21 = 1'b0;
  assign               o22 = 1'b0;
  assign               o23 = 1'b0;
  assign               o24 = 1'b0;
  assign               o25 = 1'b0;
  assign               o26 = 1'b0;
  assign               o27 = 1'b0;
  assign               o28 = 1'b0;
  assign               o29 = 1'b0;
endmodule


