// Benchmark "/tmp/" written by ABC on Tue Oct 20 18:11:52 2026

module \/tmp/  ( 
    p16, p39, p28, p42, p50, p51, p27, p56, p8, p33, p34, p17, p1, p20,
    p29, p9, p53, p44, p13, p46, p47, p2, p26, p7, p52, p6, p5, p49, p35,
    p19, p55, p4, p24, p23, p57, p15, p25, p3, p0, p40, p18, p31, p22, p36,
    p12, p54, p14, p48, p37, p21, p30, p43, p58, p10, p32, p41, p59, p45,
    p11, p38,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25, o26, o27, o28, o29  );
  input  p16, p39, p28, p42, p50, p51, p27, p56, p8, p33, p34, p17, p1,
    p20, p29, p9, p53, p44, p13, p46, p47, p2, p26, p7, p52, p6, p5, p49,
    p35, p19, p55, p4, p24, p23, p57, p15, p25, p3, p0, p40, p18, p31, p22,
    p36, p12, p54, p14, p48, p37, p21, p30, p43, p58, p10, p32, p41, p59,
    p45, p11, p38;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25, o26, o27, o28, o29;
  wire new_n91_, new_n92_, new_n93_, new_n94_, new_n95_, new_n96_, new_n97_,
    new_n98_, new_n99_, new_n100_, new_n101_, new_n102_, new_n103_,
    new_n104_, new_n105_, new_n106_, new_n107_, new_n108_, new_n109_,
    new_n110_, new_n111_, new_n112_, new_n113_, new_n114_, new_n115_,
    new_n116_, new_n117_, new_n118_, new_n119_, new_n120_, new_n121_,
    new_n122_, new_n123_, new_n124_, new_n125_, new_n126_, new_n127_,
    new_n128_, new_n129_, new_n130_, new_n131_, new_n132_, new_n133_,
    new_n134_, new_n135_, new_n136_, new_n137_, new_n138_, new_n139_,
    new_n140_, new_n141_, new_n142_, new_n143_, new_n144_, new_n145_,
    new_n146_, new_n147_, new_n148_, new_n149_, new_n150_, new_n151_,
    new_n153_, new_n154_, new_n155_, new_n156_, new_n157_, new_n158_,
    new_n159_, new_n160_, new_n161_, new_n162_, new_n163_, new_n164_,
    new_n165_, new_n166_, new_n167_, new_n168_, new_n169_, new_n170_,
    new_n171_, new_n172_, new_n173_, new_n174_, new_n175_, new_n176_,
    new_n177_, new_n178_, new_n179_, new_n180_, new_n181_, new_n182_,
    new_n183_, new_n184_, new_n185_, new_n186_, new_n187_, new_n188_,
    new_n189_, new_n190_, new_n191_, new_n192_, new_n193_, new_n194_,
    new_n195_, new_n196_, new_n197_, new_n198_, new_n199_, new_n200_,
    new_n201_, new_n202_, new_n203_, new_n204_, new_n205_, new_n206_,
    new_n207_, new_n208_, new_n209_, new_n210_, new_n211_, new_n212_,
    new_n213_, new_n214_, new_n215_, new_n216_, new_n217_, new_n218_,
    new_n219_, new_n220_, new_n221_, new_n222_, new_n224_, new_n225_,
    new_n226_, new_n227_, new_n228_, new_n229_, new_n230_, new_n231_,
    new_n232_, new_n233_, new_n234_, new_n235_, new_n236_, new_n237_,
    new_n238_, new_n239_, new_n240_, new_n241_, new_n242_, new_n243_,
    new_n244_, new_n245_;
  AND3x1_ASAP7_75t_R   g000(.A(p28), .B(p27), .C(p26), .Y(new_n91_));
  INVx1_ASAP7_75t_R    g001(.A(new_n91_), .Y(new_n92_));
  AND2x2_ASAP7_75t_R   g002(.A(p24), .B(p23), .Y(new_n93_));
  INVx1_ASAP7_75t_R    g003(.A(new_n93_), .Y(new_n94_));
  NOR2x1_ASAP7_75t_R   g004(.A(p12), .B(p11), .Y(new_n95_));
  OAI21x1_ASAP7_75t_R  g005(.A1(p8), .A2(p9), .B(p10), .Y(new_n96_));
  NAND2x1_ASAP7_75t_R  g006(.A(new_n95_), .B(new_n96_), .Y(new_n97_));
  NAND2x1_ASAP7_75t_R  g007(.A(p13), .B(p14), .Y(new_n98_));
  INVx1_ASAP7_75t_R    g008(.A(new_n98_), .Y(new_n99_));
  NAND3x1_ASAP7_75t_R  g009(.A(new_n97_), .B(p16), .C(new_n99_), .Y(new_n100_));
  NOR2x1_ASAP7_75t_R   g010(.A(p20), .B(p21), .Y(new_n101_));
  AO21x1_ASAP7_75t_R   g011(.A1(p16), .A2(p15), .B(p17), .Y(new_n102_));
  INVx1_ASAP7_75t_R    g012(.A(new_n102_), .Y(new_n103_));
  NAND2x1_ASAP7_75t_R  g013(.A(p19), .B(p18), .Y(new_n104_));
  INVx1_ASAP7_75t_R    g014(.A(p22), .Y(new_n105_));
  AOI21x1_ASAP7_75t_R  g015(.A1(new_n104_), .A2(new_n101_), .B(new_n105_), .Y(new_n106_));
  INVx1_ASAP7_75t_R    g016(.A(new_n106_), .Y(new_n107_));
  AO31x2_ASAP7_75t_R   g017(.A1(new_n100_), .A2(new_n101_), .A3(new_n103_), .B(new_n107_), .Y(new_n108_));
  NAND2x1_ASAP7_75t_R  g018(.A(p25), .B(new_n91_), .Y(new_n109_));
  OA31x2_ASAP7_75t_R   g019(.A1(new_n92_), .A2(new_n94_), .A3(new_n108_), .B1(new_n109_), .Y(new_n110_));
  INVx1_ASAP7_75t_R    g020(.A(p16), .Y(new_n111_));
  AOI211x1_ASAP7_75t_R g021(.A1(new_n95_), .A2(new_n96_), .B(new_n111_), .C(new_n98_), .Y(new_n112_));
  AO21x1_ASAP7_75t_R   g022(.A1(p16), .A2(p15), .B(new_n112_), .Y(new_n113_));
  NOR2x1_ASAP7_75t_R   g023(.A(p5), .B(p4), .Y(new_n114_));
  NOR2x1_ASAP7_75t_R   g024(.A(p7), .B(p6), .Y(new_n115_));
  NOR2x1_ASAP7_75t_R   g025(.A(p1), .B(p9), .Y(new_n116_));
  INVx1_ASAP7_75t_R    g026(.A(p2), .Y(new_n117_));
  AND5x1_ASAP7_75t_R   g027(.A(p13), .B(new_n114_), .C(new_n115_), .D(new_n116_), .E(new_n117_), .Y(new_n118_));
  AND3x1_ASAP7_75t_R   g028(.A(new_n101_), .B(p19), .C(p22), .Y(new_n119_));
  INVx1_ASAP7_75t_R    g029(.A(p3), .Y(new_n120_));
  NOR2x1_ASAP7_75t_R   g030(.A(p0), .B(p12), .Y(new_n121_));
  AND3x1_ASAP7_75t_R   g031(.A(new_n119_), .B(new_n120_), .C(new_n121_), .Y(new_n122_));
  NOR2x1_ASAP7_75t_R   g032(.A(p13), .B(p14), .Y(new_n123_));
  NOR2x1_ASAP7_75t_R   g033(.A(p15), .B(new_n98_), .Y(new_n124_));
  OR3x1_ASAP7_75t_R    g034(.A(p8), .B(p9), .C(p10), .Y(new_n125_));
  NAND2x1_ASAP7_75t_R  g035(.A(p11), .B(new_n125_), .Y(new_n126_));
  OA21x2_ASAP7_75t_R   g036(.A1(new_n123_), .A2(new_n124_), .B(new_n126_), .Y(new_n127_));
  INVx1_ASAP7_75t_R    g037(.A(p11), .Y(new_n128_));
  NAND2x1_ASAP7_75t_R  g038(.A(new_n128_), .B(new_n96_), .Y(new_n129_));
  INVx1_ASAP7_75t_R    g039(.A(p18), .Y(new_n130_));
  NOR2x1_ASAP7_75t_R   g040(.A(p25), .B(new_n130_), .Y(new_n131_));
  INVx1_ASAP7_75t_R    g041(.A(p17), .Y(new_n132_));
  AND5x1_ASAP7_75t_R   g042(.A(p8), .B(new_n129_), .C(new_n131_), .D(new_n132_), .E(new_n93_), .Y(new_n133_));
  AND5x1_ASAP7_75t_R   g043(.A(new_n113_), .B(new_n118_), .C(new_n122_), .D(new_n127_), .E(new_n133_), .Y(new_n134_));
  NAND2x1_ASAP7_75t_R  g044(.A(new_n103_), .B(new_n100_), .Y(new_n135_));
  AND5x1_ASAP7_75t_R   g045(.A(p0), .B(new_n91_), .C(p14), .D(p10), .E(p59), .Y(new_n136_));
  NAND2x1_ASAP7_75t_R  g046(.A(new_n119_), .B(new_n136_), .Y(new_n137_));
  AOI211x1_ASAP7_75t_R g047(.A1(new_n99_), .A2(new_n97_), .B(p16), .C(p15), .Y(new_n138_));
  AND3x1_ASAP7_75t_R   g048(.A(new_n95_), .B(p1), .C(p13), .Y(new_n139_));
  NOR2x1_ASAP7_75t_R   g049(.A(p8), .B(p9), .Y(new_n140_));
  NAND3x1_ASAP7_75t_R  g050(.A(new_n139_), .B(new_n140_), .C(new_n131_), .Y(new_n141_));
  NAND2x1_ASAP7_75t_R  g051(.A(p4), .B(p24), .Y(new_n142_));
  NAND2x1_ASAP7_75t_R  g052(.A(p6), .B(p5), .Y(new_n143_));
  NAND2x1_ASAP7_75t_R  g053(.A(p2), .B(p7), .Y(new_n144_));
  OR5x1_ASAP7_75t_R    g054(.A(p15), .B(new_n142_), .C(new_n143_), .D(new_n144_), .E(new_n120_), .Y(new_n145_));
  OR5x1_ASAP7_75t_R    g055(.A(new_n135_), .B(new_n137_), .C(new_n138_), .D(new_n141_), .E(new_n145_), .Y(new_n146_));
  INVx1_ASAP7_75t_R    g056(.A(new_n101_), .Y(new_n147_));
  AOI21x1_ASAP7_75t_R  g057(.A1(p22), .A2(new_n147_), .B(p23), .Y(new_n148_));
  OA31x2_ASAP7_75t_R   g058(.A1(new_n147_), .A2(new_n102_), .A3(new_n112_), .B1(new_n106_), .Y(new_n149_));
  AOI21x1_ASAP7_75t_R  g059(.A1(new_n93_), .A2(new_n149_), .B(p25), .Y(new_n150_));
  OAI22x1_ASAP7_75t_R  g060(.A1(new_n146_), .A2(new_n148_), .B1(new_n92_), .B2(new_n150_), .Y(new_n151_));
  OAI21x1_ASAP7_75t_R  g061(.A1(new_n110_), .A2(new_n134_), .B(new_n151_), .Y(o0));
  NOR3x1_ASAP7_75t_R   g062(.A(new_n134_), .B(new_n150_), .C(new_n92_), .Y(new_n153_));
  AND3x1_ASAP7_75t_R   g063(.A(p53), .B(p52), .C(p54), .Y(new_n154_));
  AND3x1_ASAP7_75t_R   g064(.A(p56), .B(p57), .C(p58), .Y(new_n155_));
  OA21x2_ASAP7_75t_R   g065(.A1(p55), .A2(new_n154_), .B(new_n155_), .Y(new_n156_));
  NAND2x1_ASAP7_75t_R  g066(.A(p49), .B(p48), .Y(new_n157_));
  NOR2x1_ASAP7_75t_R   g067(.A(p42), .B(p41), .Y(new_n158_));
  OAI21x1_ASAP7_75t_R  g068(.A1(p39), .A2(p38), .B(p40), .Y(new_n159_));
  NAND2x1_ASAP7_75t_R  g069(.A(p44), .B(p43), .Y(new_n160_));
  AOI21x1_ASAP7_75t_R  g070(.A1(new_n158_), .A2(new_n159_), .B(new_n160_), .Y(new_n161_));
  AO21x1_ASAP7_75t_R   g071(.A1(p46), .A2(p45), .B(p47), .Y(new_n162_));
  AOI21x1_ASAP7_75t_R  g072(.A1(p46), .A2(new_n161_), .B(new_n162_), .Y(new_n163_));
  INVx1_ASAP7_75t_R    g073(.A(p51), .Y(new_n164_));
  NOR2x1_ASAP7_75t_R   g074(.A(p50), .B(p55), .Y(new_n165_));
  AND2x2_ASAP7_75t_R   g075(.A(new_n164_), .B(new_n165_), .Y(new_n166_));
  OAI21x1_ASAP7_75t_R  g076(.A1(new_n157_), .A2(new_n163_), .B(new_n166_), .Y(new_n167_));
  NOR2x1_ASAP7_75t_R   g077(.A(p50), .B(p59), .Y(new_n168_));
  AOI21x1_ASAP7_75t_R  g078(.A1(new_n156_), .A2(new_n167_), .B(new_n168_), .Y(new_n169_));
  NAND2x1_ASAP7_75t_R  g079(.A(p52), .B(new_n164_), .Y(new_n170_));
  OAI21x1_ASAP7_75t_R  g080(.A1(new_n157_), .A2(new_n163_), .B(new_n170_), .Y(new_n171_));
  INVx1_ASAP7_75t_R    g081(.A(p45), .Y(new_n172_));
  AND2x2_ASAP7_75t_R   g082(.A(p30), .B(p32), .Y(new_n173_));
  AND2x2_ASAP7_75t_R   g083(.A(p40), .B(p31), .Y(new_n174_));
  AND2x2_ASAP7_75t_R   g084(.A(p36), .B(p37), .Y(new_n175_));
  AND5x1_ASAP7_75t_R   g085(.A(new_n172_), .B(new_n155_), .C(new_n173_), .D(new_n174_), .E(new_n175_), .Y(new_n176_));
  INVx1_ASAP7_75t_R    g086(.A(p46), .Y(new_n177_));
  NOR2x1_ASAP7_75t_R   g087(.A(p55), .B(new_n177_), .Y(new_n178_));
  AND4x2_ASAP7_75t_R   g088(.A(p33), .B(p34), .C(p29), .D(p44), .Y(new_n179_));
  AND2x2_ASAP7_75t_R   g089(.A(p49), .B(p35), .Y(new_n180_));
  AND3x1_ASAP7_75t_R   g090(.A(new_n178_), .B(new_n179_), .C(new_n180_), .Y(new_n181_));
  NOR2x1_ASAP7_75t_R   g091(.A(p39), .B(p38), .Y(new_n182_));
  INVx1_ASAP7_75t_R    g092(.A(new_n182_), .Y(new_n183_));
  NAND2x1_ASAP7_75t_R  g093(.A(p53), .B(p54), .Y(new_n184_));
  NOR2x1_ASAP7_75t_R   g094(.A(p47), .B(p48), .Y(new_n185_));
  NOR3x1_ASAP7_75t_R   g095(.A(new_n183_), .B(new_n184_), .C(new_n185_), .Y(new_n186_));
  NAND2x1_ASAP7_75t_R  g096(.A(p46), .B(p45), .Y(new_n187_));
  OAI21x1_ASAP7_75t_R  g097(.A1(p48), .A2(new_n187_), .B(new_n162_), .Y(new_n188_));
  AND4x2_ASAP7_75t_R   g098(.A(new_n176_), .B(new_n181_), .C(new_n186_), .D(new_n188_), .Y(new_n189_));
  INVx1_ASAP7_75t_R    g099(.A(p41), .Y(new_n190_));
  NOR2x1_ASAP7_75t_R   g100(.A(new_n190_), .B(new_n159_), .Y(new_n191_));
  AOI21x1_ASAP7_75t_R  g101(.A1(p42), .A2(new_n191_), .B(p43), .Y(new_n192_));
  NAND2x1_ASAP7_75t_R  g102(.A(new_n190_), .B(new_n159_), .Y(new_n193_));
  OA21x2_ASAP7_75t_R   g103(.A1(p42), .A2(new_n193_), .B(p43), .Y(new_n194_));
  NOR2x1_ASAP7_75t_R   g104(.A(new_n192_), .B(new_n194_), .Y(new_n195_));
  NAND3x1_ASAP7_75t_R  g105(.A(new_n171_), .B(new_n189_), .C(new_n195_), .Y(new_n196_));
  NAND2x1_ASAP7_75t_R  g106(.A(p47), .B(new_n172_), .Y(new_n197_));
  NOR2x1_ASAP7_75t_R   g107(.A(new_n197_), .B(new_n161_), .Y(new_n198_));
  INVx1_ASAP7_75t_R    g108(.A(new_n187_), .Y(new_n199_));
  AO21x1_ASAP7_75t_R   g109(.A1(p46), .A2(new_n161_), .B(new_n199_), .Y(new_n200_));
  NOR2x1_ASAP7_75t_R   g110(.A(p29), .B(p59), .Y(new_n201_));
  OAI21x1_ASAP7_75t_R  g111(.A1(new_n198_), .A2(new_n200_), .B(new_n201_), .Y(new_n202_));
  AND3x1_ASAP7_75t_R   g112(.A(new_n165_), .B(p56), .C(p40), .Y(new_n203_));
  NOR2x1_ASAP7_75t_R   g113(.A(p37), .B(p45), .Y(new_n204_));
  INVx1_ASAP7_75t_R    g114(.A(p36), .Y(new_n205_));
  AND3x1_ASAP7_75t_R   g115(.A(new_n204_), .B(new_n205_), .C(p38), .Y(new_n206_));
  NOR3x1_ASAP7_75t_R   g116(.A(new_n160_), .B(p39), .C(p42), .Y(new_n207_));
  AND3x1_ASAP7_75t_R   g117(.A(new_n203_), .B(new_n206_), .C(new_n207_), .Y(new_n208_));
  INVx1_ASAP7_75t_R    g118(.A(new_n157_), .Y(new_n209_));
  INVx1_ASAP7_75t_R    g119(.A(new_n184_), .Y(new_n210_));
  NAND2x1_ASAP7_75t_R  g120(.A(p46), .B(p47), .Y(new_n211_));
  NOR2x1_ASAP7_75t_R   g121(.A(p33), .B(p34), .Y(new_n212_));
  AND5x1_ASAP7_75t_R   g122(.A(new_n193_), .B(new_n209_), .C(new_n210_), .D(new_n211_), .E(new_n212_), .Y(new_n213_));
  OR4x2_ASAP7_75t_R    g123(.A(p35), .B(p31), .C(p30), .D(p32), .Y(new_n214_));
  NOR3x1_ASAP7_75t_R   g124(.A(new_n191_), .B(new_n214_), .C(new_n170_), .Y(new_n215_));
  NAND3x1_ASAP7_75t_R  g125(.A(new_n208_), .B(new_n213_), .C(new_n215_), .Y(new_n216_));
  AOI211x1_ASAP7_75t_R g126(.A1(new_n158_), .A2(new_n159_), .B(new_n177_), .C(new_n160_), .Y(new_n217_));
  OAI21x1_ASAP7_75t_R  g127(.A1(new_n162_), .A2(new_n217_), .B(new_n209_), .Y(new_n218_));
  INVx1_ASAP7_75t_R    g128(.A(new_n156_), .Y(new_n219_));
  AOI21x1_ASAP7_75t_R  g129(.A1(new_n166_), .A2(new_n218_), .B(new_n219_), .Y(new_n220_));
  OAI21x1_ASAP7_75t_R  g130(.A1(new_n202_), .A2(new_n216_), .B(new_n220_), .Y(new_n221_));
  OAI21x1_ASAP7_75t_R  g131(.A1(new_n169_), .A2(new_n196_), .B(new_n221_), .Y(new_n222_));
  OAI21x1_ASAP7_75t_R  g132(.A1(new_n153_), .A2(new_n222_), .B(new_n151_), .Y(o1));
  INVx1_ASAP7_75t_R    g133(.A(new_n139_), .Y(new_n224_));
  NAND2x1_ASAP7_75t_R  g134(.A(new_n140_), .B(new_n131_), .Y(new_n225_));
  OR3x1_ASAP7_75t_R    g135(.A(new_n224_), .B(new_n145_), .C(new_n225_), .Y(new_n226_));
  OR5x1_ASAP7_75t_R    g136(.A(new_n135_), .B(new_n226_), .C(new_n148_), .D(new_n138_), .E(new_n137_), .Y(new_n227_));
  OR3x1_ASAP7_75t_R    g137(.A(new_n198_), .B(new_n199_), .C(new_n217_), .Y(new_n228_));
  NAND3x1_ASAP7_75t_R  g138(.A(new_n203_), .B(new_n206_), .C(new_n207_), .Y(new_n229_));
  AOI21x1_ASAP7_75t_R  g139(.A1(p29), .A2(p59), .B(new_n229_), .Y(new_n230_));
  NOR2x1_ASAP7_75t_R   g140(.A(p34), .B(p35), .Y(new_n231_));
  NOR2x1_ASAP7_75t_R   g141(.A(p31), .B(p30), .Y(new_n232_));
  NOR2x1_ASAP7_75t_R   g142(.A(p33), .B(p32), .Y(new_n233_));
  AND5x1_ASAP7_75t_R   g143(.A(p53), .B(new_n231_), .C(new_n232_), .D(new_n233_), .E(p54), .Y(new_n234_));
  INVx1_ASAP7_75t_R    g144(.A(p40), .Y(new_n235_));
  OR3x1_ASAP7_75t_R    g145(.A(new_n182_), .B(new_n235_), .C(new_n190_), .Y(new_n236_));
  NOR2x1_ASAP7_75t_R   g146(.A(new_n157_), .B(new_n170_), .Y(new_n237_));
  AND5x1_ASAP7_75t_R   g147(.A(new_n193_), .B(new_n234_), .C(new_n236_), .D(new_n237_), .E(new_n211_), .Y(new_n238_));
  NAND3x1_ASAP7_75t_R  g148(.A(new_n228_), .B(new_n230_), .C(new_n238_), .Y(new_n239_));
  INVx1_ASAP7_75t_R    g149(.A(new_n154_), .Y(new_n240_));
  NOR2x1_ASAP7_75t_R   g150(.A(p50), .B(p51), .Y(new_n241_));
  INVx1_ASAP7_75t_R    g151(.A(p55), .Y(new_n242_));
  OA21x2_ASAP7_75t_R   g152(.A1(new_n241_), .A2(new_n240_), .B(new_n242_), .Y(new_n243_));
  OAI21x1_ASAP7_75t_R  g153(.A1(new_n240_), .A2(new_n218_), .B(new_n243_), .Y(new_n244_));
  NAND3x1_ASAP7_75t_R  g154(.A(new_n239_), .B(new_n155_), .C(new_n244_), .Y(new_n245_));
  AOI211x1_ASAP7_75t_R g155(.A1(new_n110_), .A2(new_n227_), .B(new_n153_), .C(new_n245_), .Y(o2));
  assign               o3 = 1'b0;
  assign               o4 = 1'b0;
  assign               o5 = 1'b0;
  assign               o6 = 1'b0;
  assign               o7 = 1'b0;
  assign               o8 = 1'b0;
  assign               o9 = 1'b0;
  assign               o10 = 1'b0;
  assign               o11 = 1'b0;
  assign               o12 = 1'b0;
  assign               o13 = 1'b0;
  assign               o14 = 1'b0;
  assign               o15 = 1'b0;
  assign               o16 = 1'b0;
  assign               o17 = 1'b0;
  assign               o18 = 1'b0;
  assign               o19 = 1'b0;
  assign               o20 = 1'b0;
  assign               o21 = 1'b0;
  assign               o22 = 1'b0;
  assign               o23 = 1'b0;
  assign               o24 = 1'b0;
  assign               o25 = 1'b0;
  assign               o26 = 1'b0;
  assign               o27 = 1'b0;
  assign               o28 = 1'b0;
  assign               o29 = 1'b0;
endmodule


