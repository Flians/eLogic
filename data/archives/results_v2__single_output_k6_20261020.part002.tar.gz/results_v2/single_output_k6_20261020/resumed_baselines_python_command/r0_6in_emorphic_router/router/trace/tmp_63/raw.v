// Benchmark "/tmp/" written by ABC on Tue Oct 20 18:11:51 2026

module \/tmp/  ( 
    p44, p8, p46, p14, p48, p12, p35, p24, p29, p5, p13, p27, p28, p51,
    p55, p1, p25, p4, p0, p19, p18, p33, p21, p23, p54, p9, p36, p7, p17,
    p6, p31, p38, p37, p16, p39, p50, p26, p47, p43, p41, p34, p11, p59,
    p2, p20, p57, p49, p30, p52, p15, p40, p56, p42, p22, p53, p3, p10,
    p58, p45, p32,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25, o26, o27, o28, o29  );
  input  p44, p8, p46, p14, p48, p12, p35, p24, p29, p5, p13, p27, p28,
    p51, p55, p1, p25, p4, p0, p19, p18, p33, p21, p23, p54, p9, p36, p7,
    p17, p6, p31, p38, p37, p16, p39, p50, p26, p47, p43, p41, p34, p11,
    p59, p2, p20, p57, p49, p30, p52, p15, p40, p56, p42, p22, p53, p3,
    p10, p58, p45, p32;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25, o26, o27, o28, o29;
  wire new_n91_, new_n92_, new_n93_, new_n94_, new_n95_, new_n96_, new_n97_,
    new_n98_, new_n99_, new_n100_, new_n101_, new_n102_, new_n103_,
    new_n104_, new_n105_, new_n106_, new_n107_, new_n108_, new_n109_,
    new_n110_, new_n111_, new_n112_, new_n113_, new_n114_, new_n115_,
    new_n116_, new_n117_, new_n118_, new_n119_, new_n120_, new_n121_,
    new_n122_, new_n123_, new_n124_, new_n125_, new_n126_, new_n127_,
    new_n128_, new_n129_, new_n130_, new_n131_, new_n132_, new_n133_,
    new_n134_, new_n135_, new_n136_, new_n137_, new_n138_, new_n139_,
    new_n140_, new_n141_, new_n142_, new_n143_, new_n144_, new_n145_,
    new_n146_, new_n147_, new_n148_, new_n149_, new_n150_, new_n152_,
    new_n153_, new_n154_, new_n155_, new_n156_, new_n157_, new_n158_,
    new_n159_, new_n160_, new_n161_, new_n162_, new_n163_, new_n164_,
    new_n165_, new_n166_, new_n167_, new_n168_, new_n169_, new_n170_,
    new_n171_, new_n172_, new_n173_, new_n174_, new_n175_, new_n176_,
    new_n177_, new_n178_, new_n179_, new_n180_, new_n181_, new_n182_,
    new_n183_, new_n184_, new_n185_, new_n186_, new_n187_, new_n188_,
    new_n189_, new_n190_, new_n191_, new_n192_, new_n193_, new_n194_,
    new_n195_, new_n196_, new_n197_, new_n198_, new_n199_, new_n200_,
    new_n201_, new_n202_, new_n203_, new_n204_, new_n205_, new_n206_,
    new_n207_, new_n208_, new_n209_, new_n210_, new_n211_, new_n212_,
    new_n213_, new_n214_, new_n215_, new_n216_, new_n217_, new_n218_,
    new_n219_, new_n220_, new_n221_, new_n222_, new_n223_, new_n224_,
    new_n225_, new_n226_, new_n227_, new_n228_, new_n229_, new_n230_,
    new_n231_, new_n232_, new_n233_, new_n234_, new_n235_, new_n236_,
    new_n237_, new_n238_, new_n239_, new_n240_, new_n242_, new_n243_,
    new_n244_, new_n245_, new_n246_, new_n247_, new_n248_, new_n249_,
    new_n250_, new_n251_, new_n252_, new_n253_, new_n254_, new_n255_,
    new_n256_, new_n257_, new_n258_, new_n259_, new_n260_, new_n261_,
    new_n262_, new_n263_;
  AND3x1_ASAP7_75t_R   g000(.A(p27), .B(p28), .C(p26), .Y(new_n91_));
  NOR2x1_ASAP7_75t_R   g001(.A(p21), .B(p20), .Y(new_n92_));
  NOR2x1_ASAP7_75t_R   g002(.A(p12), .B(p11), .Y(new_n93_));
  OAI21x1_ASAP7_75t_R  g003(.A1(p8), .A2(p9), .B(p10), .Y(new_n94_));
  NAND2x1_ASAP7_75t_R  g004(.A(p14), .B(p13), .Y(new_n95_));
  AOI21x1_ASAP7_75t_R  g005(.A1(new_n93_), .A2(new_n94_), .B(new_n95_), .Y(new_n96_));
  AO21x1_ASAP7_75t_R   g006(.A1(p16), .A2(p15), .B(p17), .Y(new_n97_));
  AOI21x1_ASAP7_75t_R  g007(.A1(p16), .A2(new_n96_), .B(new_n97_), .Y(new_n98_));
  AND2x2_ASAP7_75t_R   g008(.A(p24), .B(p23), .Y(new_n99_));
  INVx1_ASAP7_75t_R    g009(.A(new_n99_), .Y(new_n100_));
  NAND2x1_ASAP7_75t_R  g010(.A(p19), .B(p18), .Y(new_n101_));
  INVx1_ASAP7_75t_R    g011(.A(p22), .Y(new_n102_));
  AO21x1_ASAP7_75t_R   g012(.A1(new_n101_), .A2(new_n92_), .B(new_n102_), .Y(new_n103_));
  AOI211x1_ASAP7_75t_R g013(.A1(new_n92_), .A2(new_n98_), .B(new_n100_), .C(new_n103_), .Y(new_n104_));
  AND2x2_ASAP7_75t_R   g014(.A(p25), .B(new_n91_), .Y(new_n105_));
  AO21x1_ASAP7_75t_R   g015(.A1(new_n91_), .A2(new_n104_), .B(new_n105_), .Y(new_n106_));
  NAND2x1_ASAP7_75t_R  g016(.A(new_n93_), .B(new_n94_), .Y(new_n107_));
  AOI21x1_ASAP7_75t_R  g017(.A1(p13), .A2(new_n107_), .B(p14), .Y(new_n108_));
  INVx1_ASAP7_75t_R    g018(.A(p8), .Y(new_n109_));
  INVx1_ASAP7_75t_R    g019(.A(p9), .Y(new_n110_));
  INVx1_ASAP7_75t_R    g020(.A(p11), .Y(new_n111_));
  NOR2x1_ASAP7_75t_R   g021(.A(p10), .B(new_n111_), .Y(new_n112_));
  INVx1_ASAP7_75t_R    g022(.A(new_n94_), .Y(new_n113_));
  AO32x1_ASAP7_75t_R   g023(.A1(new_n109_), .A2(new_n110_), .A3(new_n112_), .B1(new_n113_), .B2(new_n111_), .Y(new_n114_));
  OA21x2_ASAP7_75t_R   g024(.A1(new_n96_), .A2(new_n108_), .B(new_n114_), .Y(new_n115_));
  NAND2x1_ASAP7_75t_R  g025(.A(p15), .B(new_n96_), .Y(new_n116_));
  AND2x2_ASAP7_75t_R   g026(.A(p19), .B(p22), .Y(new_n117_));
  NAND2x1_ASAP7_75t_R  g027(.A(new_n92_), .B(new_n117_), .Y(new_n118_));
  INVx1_ASAP7_75t_R    g028(.A(new_n118_), .Y(new_n119_));
  INVx1_ASAP7_75t_R    g029(.A(p1), .Y(new_n120_));
  NOR2x1_ASAP7_75t_R   g030(.A(p9), .B(p7), .Y(new_n121_));
  NOR2x1_ASAP7_75t_R   g031(.A(p25), .B(p4), .Y(new_n122_));
  INVx1_ASAP7_75t_R    g032(.A(p17), .Y(new_n123_));
  AND5x1_ASAP7_75t_R   g033(.A(new_n120_), .B(new_n121_), .C(new_n122_), .D(p18), .E(new_n123_), .Y(new_n124_));
  INVx1_ASAP7_75t_R    g034(.A(p12), .Y(new_n125_));
  INVx1_ASAP7_75t_R    g035(.A(p5), .Y(new_n126_));
  AND5x1_ASAP7_75t_R   g036(.A(p8), .B(new_n99_), .C(new_n125_), .D(new_n126_), .E(p13), .Y(new_n127_));
  NOR2x1_ASAP7_75t_R   g037(.A(p2), .B(p3), .Y(new_n128_));
  INVx1_ASAP7_75t_R    g038(.A(p0), .Y(new_n129_));
  INVx1_ASAP7_75t_R    g039(.A(p6), .Y(new_n130_));
  AND3x1_ASAP7_75t_R   g040(.A(new_n128_), .B(new_n129_), .C(new_n130_), .Y(new_n131_));
  AND5x1_ASAP7_75t_R   g041(.A(new_n116_), .B(new_n119_), .C(new_n124_), .D(new_n127_), .E(new_n131_), .Y(new_n132_));
  OA21x2_ASAP7_75t_R   g042(.A1(p15), .A2(new_n96_), .B(p16), .Y(new_n133_));
  NAND3x1_ASAP7_75t_R  g043(.A(new_n115_), .B(new_n132_), .C(new_n133_), .Y(new_n134_));
  AND3x1_ASAP7_75t_R   g044(.A(new_n93_), .B(new_n109_), .C(new_n110_), .Y(new_n135_));
  NAND2x1_ASAP7_75t_R  g045(.A(p24), .B(p5), .Y(new_n136_));
  NOR2x1_ASAP7_75t_R   g046(.A(new_n95_), .B(new_n136_), .Y(new_n137_));
  AND4x2_ASAP7_75t_R   g047(.A(p18), .B(p7), .C(p6), .D(p59), .Y(new_n138_));
  NOR2x1_ASAP7_75t_R   g048(.A(p25), .B(new_n120_), .Y(new_n139_));
  AND2x2_ASAP7_75t_R   g049(.A(p4), .B(p0), .Y(new_n140_));
  AND5x1_ASAP7_75t_R   g050(.A(new_n135_), .B(new_n137_), .C(new_n138_), .D(new_n139_), .E(new_n140_), .Y(new_n141_));
  INVx1_ASAP7_75t_R    g051(.A(p23), .Y(new_n142_));
  OAI21x1_ASAP7_75t_R  g052(.A1(new_n102_), .A2(new_n92_), .B(new_n142_), .Y(new_n143_));
  OR3x1_ASAP7_75t_R    g053(.A(new_n96_), .B(p16), .C(p15), .Y(new_n144_));
  INVx1_ASAP7_75t_R    g054(.A(p2), .Y(new_n145_));
  NOR2x1_ASAP7_75t_R   g055(.A(p15), .B(new_n145_), .Y(new_n146_));
  AND2x2_ASAP7_75t_R   g056(.A(p3), .B(p10), .Y(new_n147_));
  AND5x1_ASAP7_75t_R   g057(.A(new_n91_), .B(new_n146_), .C(new_n92_), .D(new_n117_), .E(new_n147_), .Y(new_n148_));
  AND5x1_ASAP7_75t_R   g058(.A(new_n98_), .B(new_n141_), .C(new_n143_), .D(new_n144_), .E(new_n148_), .Y(new_n149_));
  AOI211x1_ASAP7_75t_R g059(.A1(new_n91_), .A2(new_n104_), .B(new_n105_), .C(new_n149_), .Y(new_n150_));
  AO21x1_ASAP7_75t_R   g060(.A1(new_n106_), .A2(new_n134_), .B(new_n150_), .Y(o0));
  INVx1_ASAP7_75t_R    g061(.A(p3), .Y(new_n152_));
  AND5x1_ASAP7_75t_R   g062(.A(p16), .B(new_n117_), .C(new_n145_), .D(new_n152_), .E(new_n92_), .Y(new_n153_));
  AND3x1_ASAP7_75t_R   g063(.A(new_n121_), .B(new_n123_), .C(new_n130_), .Y(new_n154_));
  AND3x1_ASAP7_75t_R   g064(.A(new_n122_), .B(new_n129_), .C(p18), .Y(new_n155_));
  AND2x2_ASAP7_75t_R   g065(.A(new_n154_), .B(new_n155_), .Y(new_n156_));
  NAND2x1_ASAP7_75t_R  g066(.A(new_n111_), .B(new_n94_), .Y(new_n157_));
  AND5x1_ASAP7_75t_R   g067(.A(p8), .B(new_n99_), .C(new_n126_), .D(p13), .E(new_n120_), .Y(new_n158_));
  NOR2x1_ASAP7_75t_R   g068(.A(p12), .B(p10), .Y(new_n159_));
  AO32x1_ASAP7_75t_R   g069(.A1(new_n159_), .A2(new_n109_), .A3(new_n110_), .B1(new_n125_), .B2(new_n111_), .Y(new_n160_));
  AND5x1_ASAP7_75t_R   g070(.A(new_n153_), .B(new_n156_), .C(new_n157_), .D(new_n158_), .E(new_n160_), .Y(new_n161_));
  OAI21x1_ASAP7_75t_R  g071(.A1(p14), .A2(new_n107_), .B(p15), .Y(new_n162_));
  AO21x1_ASAP7_75t_R   g072(.A1(p14), .A2(new_n107_), .B(p15), .Y(new_n163_));
  AND2x2_ASAP7_75t_R   g073(.A(new_n162_), .B(new_n163_), .Y(new_n164_));
  INVx1_ASAP7_75t_R    g074(.A(new_n91_), .Y(new_n165_));
  AOI21x1_ASAP7_75t_R  g075(.A1(new_n92_), .A2(new_n98_), .B(new_n103_), .Y(new_n166_));
  AOI21x1_ASAP7_75t_R  g076(.A1(new_n99_), .A2(new_n166_), .B(p25), .Y(new_n167_));
  AOI211x1_ASAP7_75t_R g077(.A1(new_n161_), .A2(new_n164_), .B(new_n165_), .C(new_n167_), .Y(new_n168_));
  AND3x1_ASAP7_75t_R   g078(.A(p54), .B(p52), .C(p53), .Y(new_n169_));
  AND3x1_ASAP7_75t_R   g079(.A(p57), .B(p56), .C(p58), .Y(new_n170_));
  OA21x2_ASAP7_75t_R   g080(.A1(p55), .A2(new_n169_), .B(new_n170_), .Y(new_n171_));
  NAND2x1_ASAP7_75t_R  g081(.A(p48), .B(p49), .Y(new_n172_));
  NOR2x1_ASAP7_75t_R   g082(.A(p41), .B(p42), .Y(new_n173_));
  OAI21x1_ASAP7_75t_R  g083(.A1(p38), .A2(p39), .B(p40), .Y(new_n174_));
  NAND2x1_ASAP7_75t_R  g084(.A(p44), .B(p43), .Y(new_n175_));
  AOI21x1_ASAP7_75t_R  g085(.A1(new_n173_), .A2(new_n174_), .B(new_n175_), .Y(new_n176_));
  AO21x1_ASAP7_75t_R   g086(.A1(p46), .A2(p45), .B(p47), .Y(new_n177_));
  AOI21x1_ASAP7_75t_R  g087(.A1(p46), .A2(new_n176_), .B(new_n177_), .Y(new_n178_));
  INVx1_ASAP7_75t_R    g088(.A(p55), .Y(new_n179_));
  NOR2x1_ASAP7_75t_R   g089(.A(p51), .B(p50), .Y(new_n180_));
  AND2x2_ASAP7_75t_R   g090(.A(new_n179_), .B(new_n180_), .Y(new_n181_));
  OAI21x1_ASAP7_75t_R  g091(.A1(new_n172_), .A2(new_n178_), .B(new_n181_), .Y(new_n182_));
  NOR2x1_ASAP7_75t_R   g092(.A(p50), .B(p59), .Y(new_n183_));
  AOI21x1_ASAP7_75t_R  g093(.A1(new_n171_), .A2(new_n182_), .B(new_n183_), .Y(new_n184_));
  INVx1_ASAP7_75t_R    g094(.A(p51), .Y(new_n185_));
  NAND2x1_ASAP7_75t_R  g095(.A(p52), .B(new_n185_), .Y(new_n186_));
  OAI21x1_ASAP7_75t_R  g096(.A1(new_n172_), .A2(new_n178_), .B(new_n186_), .Y(new_n187_));
  AND3x1_ASAP7_75t_R   g097(.A(p49), .B(p30), .C(p32), .Y(new_n188_));
  AND2x2_ASAP7_75t_R   g098(.A(p54), .B(p53), .Y(new_n189_));
  INVx1_ASAP7_75t_R    g099(.A(p45), .Y(new_n190_));
  AND5x1_ASAP7_75t_R   g100(.A(p40), .B(new_n170_), .C(new_n188_), .D(new_n189_), .E(new_n190_), .Y(new_n191_));
  INVx1_ASAP7_75t_R    g101(.A(p33), .Y(new_n192_));
  NOR2x1_ASAP7_75t_R   g102(.A(p55), .B(new_n192_), .Y(new_n193_));
  AND4x2_ASAP7_75t_R   g103(.A(p36), .B(p31), .C(p37), .D(p34), .Y(new_n194_));
  AND2x2_ASAP7_75t_R   g104(.A(p35), .B(p29), .Y(new_n195_));
  AND3x1_ASAP7_75t_R   g105(.A(new_n193_), .B(new_n194_), .C(new_n195_), .Y(new_n196_));
  NOR2x1_ASAP7_75t_R   g106(.A(p38), .B(p39), .Y(new_n197_));
  INVx1_ASAP7_75t_R    g107(.A(new_n197_), .Y(new_n198_));
  NAND2x1_ASAP7_75t_R  g108(.A(p44), .B(p46), .Y(new_n199_));
  NOR2x1_ASAP7_75t_R   g109(.A(p48), .B(p47), .Y(new_n200_));
  NOR3x1_ASAP7_75t_R   g110(.A(new_n198_), .B(new_n199_), .C(new_n200_), .Y(new_n201_));
  NAND2x1_ASAP7_75t_R  g111(.A(p46), .B(p45), .Y(new_n202_));
  OAI21x1_ASAP7_75t_R  g112(.A1(p48), .A2(new_n202_), .B(new_n177_), .Y(new_n203_));
  AND4x2_ASAP7_75t_R   g113(.A(new_n191_), .B(new_n196_), .C(new_n201_), .D(new_n203_), .Y(new_n204_));
  INVx1_ASAP7_75t_R    g114(.A(p41), .Y(new_n205_));
  NOR2x1_ASAP7_75t_R   g115(.A(new_n205_), .B(new_n174_), .Y(new_n206_));
  AOI21x1_ASAP7_75t_R  g116(.A1(p42), .A2(new_n206_), .B(p43), .Y(new_n207_));
  NAND2x1_ASAP7_75t_R  g117(.A(new_n205_), .B(new_n174_), .Y(new_n208_));
  OA21x2_ASAP7_75t_R   g118(.A1(p42), .A2(new_n208_), .B(p43), .Y(new_n209_));
  NOR2x1_ASAP7_75t_R   g119(.A(new_n207_), .B(new_n209_), .Y(new_n210_));
  NAND3x1_ASAP7_75t_R  g120(.A(new_n187_), .B(new_n204_), .C(new_n210_), .Y(new_n211_));
  NAND2x1_ASAP7_75t_R  g121(.A(p47), .B(new_n190_), .Y(new_n212_));
  NOR2x1_ASAP7_75t_R   g122(.A(new_n212_), .B(new_n176_), .Y(new_n213_));
  INVx1_ASAP7_75t_R    g123(.A(new_n202_), .Y(new_n214_));
  AO21x1_ASAP7_75t_R   g124(.A1(p46), .A2(new_n176_), .B(new_n214_), .Y(new_n215_));
  NOR2x1_ASAP7_75t_R   g125(.A(p29), .B(p59), .Y(new_n216_));
  OAI21x1_ASAP7_75t_R  g126(.A1(new_n213_), .A2(new_n215_), .B(new_n216_), .Y(new_n217_));
  NOR2x1_ASAP7_75t_R   g127(.A(p37), .B(p39), .Y(new_n218_));
  AND3x1_ASAP7_75t_R   g128(.A(new_n190_), .B(p40), .C(p56), .Y(new_n219_));
  INVx1_ASAP7_75t_R    g129(.A(p43), .Y(new_n220_));
  NOR3x1_ASAP7_75t_R   g130(.A(new_n220_), .B(p55), .C(p42), .Y(new_n221_));
  INVx1_ASAP7_75t_R    g131(.A(p38), .Y(new_n222_));
  NOR2x1_ASAP7_75t_R   g132(.A(p50), .B(new_n222_), .Y(new_n223_));
  INVx1_ASAP7_75t_R    g133(.A(p44), .Y(new_n224_));
  NOR2x1_ASAP7_75t_R   g134(.A(p36), .B(new_n224_), .Y(new_n225_));
  AND5x1_ASAP7_75t_R   g135(.A(new_n218_), .B(new_n219_), .C(new_n221_), .D(new_n223_), .E(new_n225_), .Y(new_n226_));
  INVx1_ASAP7_75t_R    g136(.A(new_n172_), .Y(new_n227_));
  NAND2x1_ASAP7_75t_R  g137(.A(p46), .B(p47), .Y(new_n228_));
  NOR2x1_ASAP7_75t_R   g138(.A(p35), .B(p33), .Y(new_n229_));
  AND5x1_ASAP7_75t_R   g139(.A(new_n208_), .B(new_n227_), .C(new_n189_), .D(new_n228_), .E(new_n229_), .Y(new_n230_));
  OR4x2_ASAP7_75t_R    g140(.A(p31), .B(p34), .C(p30), .D(p32), .Y(new_n231_));
  NOR3x1_ASAP7_75t_R   g141(.A(new_n206_), .B(new_n231_), .C(new_n186_), .Y(new_n232_));
  NAND3x1_ASAP7_75t_R  g142(.A(new_n226_), .B(new_n230_), .C(new_n232_), .Y(new_n233_));
  AOI211x1_ASAP7_75t_R g143(.A1(new_n173_), .A2(new_n174_), .B(new_n220_), .C(new_n199_), .Y(new_n234_));
  OAI21x1_ASAP7_75t_R  g144(.A1(new_n177_), .A2(new_n234_), .B(new_n227_), .Y(new_n235_));
  INVx1_ASAP7_75t_R    g145(.A(new_n171_), .Y(new_n236_));
  AOI21x1_ASAP7_75t_R  g146(.A1(new_n181_), .A2(new_n235_), .B(new_n236_), .Y(new_n237_));
  OAI21x1_ASAP7_75t_R  g147(.A1(new_n217_), .A2(new_n233_), .B(new_n237_), .Y(new_n238_));
  OAI21x1_ASAP7_75t_R  g148(.A1(new_n184_), .A2(new_n211_), .B(new_n238_), .Y(new_n239_));
  AO211x2_ASAP7_75t_R  g149(.A1(new_n91_), .A2(new_n104_), .B(new_n105_), .C(new_n149_), .Y(new_n240_));
  OAI21x1_ASAP7_75t_R  g150(.A1(new_n168_), .A2(new_n239_), .B(new_n240_), .Y(o1));
  INVx1_ASAP7_75t_R    g151(.A(p32), .Y(new_n242_));
  NOR2x1_ASAP7_75t_R   g152(.A(p31), .B(p30), .Y(new_n243_));
  NOR2x1_ASAP7_75t_R   g153(.A(p35), .B(p34), .Y(new_n244_));
  AND5x1_ASAP7_75t_R   g154(.A(new_n192_), .B(new_n189_), .C(new_n242_), .D(new_n243_), .E(new_n244_), .Y(new_n245_));
  INVx1_ASAP7_75t_R    g155(.A(new_n206_), .Y(new_n246_));
  NOR2x1_ASAP7_75t_R   g156(.A(new_n172_), .B(new_n186_), .Y(new_n247_));
  AND5x1_ASAP7_75t_R   g157(.A(new_n208_), .B(new_n245_), .C(new_n246_), .D(new_n228_), .E(new_n247_), .Y(new_n248_));
  NOR2x1_ASAP7_75t_R   g158(.A(new_n214_), .B(new_n234_), .Y(new_n249_));
  OAI21x1_ASAP7_75t_R  g159(.A1(new_n176_), .A2(new_n212_), .B(new_n249_), .Y(new_n250_));
  NOR2x1_ASAP7_75t_R   g160(.A(p50), .B(p45), .Y(new_n251_));
  AND3x1_ASAP7_75t_R   g161(.A(new_n251_), .B(new_n179_), .C(p56), .Y(new_n252_));
  INVx1_ASAP7_75t_R    g162(.A(p40), .Y(new_n253_));
  NOR3x1_ASAP7_75t_R   g163(.A(new_n175_), .B(new_n253_), .C(p42), .Y(new_n254_));
  NOR2x1_ASAP7_75t_R   g164(.A(p39), .B(new_n222_), .Y(new_n255_));
  NOR2x1_ASAP7_75t_R   g165(.A(p36), .B(p37), .Y(new_n256_));
  NAND2x1_ASAP7_75t_R  g166(.A(p29), .B(p59), .Y(new_n257_));
  AND5x1_ASAP7_75t_R   g167(.A(new_n252_), .B(new_n254_), .C(new_n255_), .D(new_n256_), .E(new_n257_), .Y(new_n258_));
  NAND3x1_ASAP7_75t_R  g168(.A(new_n248_), .B(new_n250_), .C(new_n258_), .Y(new_n259_));
  INVx1_ASAP7_75t_R    g169(.A(new_n169_), .Y(new_n260_));
  OA21x2_ASAP7_75t_R   g170(.A1(new_n180_), .A2(new_n260_), .B(new_n179_), .Y(new_n261_));
  OAI21x1_ASAP7_75t_R  g171(.A1(new_n260_), .A2(new_n235_), .B(new_n261_), .Y(new_n262_));
  NAND3x1_ASAP7_75t_R  g172(.A(new_n259_), .B(new_n170_), .C(new_n262_), .Y(new_n263_));
  AOI211x1_ASAP7_75t_R g173(.A1(new_n134_), .A2(new_n106_), .B(new_n150_), .C(new_n263_), .Y(o2));
  assign               o3 = 1'b0;
  assign               o4 = 1'b0;
  assign               o5 = 1'b0;
  assign               o6 = 1'b0;
  assign               o7 = 1'b0;
  assign               o8 = 1'b0;
  assign               o9 = 1'b0;
  assign               o10 = 1'b0;
  assign               o11 = 1'b0;
  assign               o12 = 1'b0;
  assign               o13 = 1'b0;
  assign               o14 = 1'b0;
  assign               o15 = 1'b0;
  assign               o16 = 1'b0;
  assign               o17 = 1'b0;
  assign               o18 = 1'b0;
  assign               o19 = 1'b0;
  assign               o20 = 1'b0;
  assign               o21 = 1'b0;
  assign               o22 = 1'b0;
  assign               o23 = 1'b0;
  assign               o24 = 1'b0;
  assign               o25 = 1'b0;
  assign               o26 = 1'b0;
  assign               o27 = 1'b0;
  assign               o28 = 1'b0;
  assign               o29 = 1'b0;
endmodule


