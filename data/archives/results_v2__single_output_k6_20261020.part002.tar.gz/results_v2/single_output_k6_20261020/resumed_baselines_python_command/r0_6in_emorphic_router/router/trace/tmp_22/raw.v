// Benchmark "/tmp/" written by ABC on Tue Oct 20 18:11:46 2026

module \/tmp/  ( 
    p6, p57, p1, p7, p8, p55, p33, p32, p44, p54, p27, p39, p24, p22, p28,
    p2, p41, p3, p16, p36, p34, p0, p21, p47, p49, p50, p12, p5, p52, p19,
    p48, p42, p37, p11, p40, p45, p13, p38, p15, p17, p10, p18, p4, p53,
    p35, p23, p31, p26, p51, p9, p29, p43, p56, p58, p14, p20, p59, p46,
    p25, p30,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25, o26, o27, o28, o29  );
  input  p6, p57, p1, p7, p8, p55, p33, p32, p44, p54, p27, p39, p24,
    p22, p28, p2, p41, p3, p16, p36, p34, p0, p21, p47, p49, p50, p12, p5,
    p52, p19, p48, p42, p37, p11, p40, p45, p13, p38, p15, p17, p10, p18,
    p4, p53, p35, p23, p31, p26, p51, p9, p29, p43, p56, p58, p14, p20,
    p59, p46, p25, p30;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25, o26, o27, o28, o29;
  wire new_n91_, new_n92_, new_n93_, new_n94_, new_n95_, new_n96_, new_n97_,
    new_n98_, new_n99_, new_n100_, new_n101_, new_n102_, new_n103_,
    new_n104_, new_n105_, new_n106_, new_n107_, new_n108_, new_n109_,
    new_n110_, new_n111_, new_n112_, new_n113_, new_n114_, new_n115_,
    new_n116_, new_n117_, new_n118_, new_n119_, new_n120_, new_n121_,
    new_n122_, new_n123_, new_n124_, new_n125_, new_n126_, new_n127_,
    new_n128_, new_n129_, new_n130_, new_n131_, new_n132_, new_n133_,
    new_n134_, new_n135_, new_n136_, new_n138_, new_n139_, new_n140_,
    new_n141_, new_n142_, new_n143_, new_n144_, new_n145_, new_n146_,
    new_n147_, new_n148_, new_n149_, new_n150_, new_n151_, new_n152_,
    new_n153_, new_n154_, new_n155_, new_n156_, new_n157_, new_n158_,
    new_n159_, new_n160_, new_n161_, new_n162_, new_n163_, new_n164_,
    new_n165_, new_n166_, new_n167_, new_n168_, new_n169_, new_n170_,
    new_n171_, new_n172_, new_n173_, new_n174_, new_n175_, new_n176_,
    new_n177_, new_n178_, new_n179_, new_n180_, new_n181_, new_n182_,
    new_n183_, new_n184_, new_n185_, new_n186_, new_n187_, new_n188_,
    new_n189_, new_n190_, new_n191_, new_n192_, new_n193_, new_n194_,
    new_n195_, new_n196_, new_n197_, new_n198_, new_n199_, new_n200_,
    new_n201_, new_n202_, new_n203_, new_n204_, new_n205_, new_n206_,
    new_n207_, new_n208_, new_n209_, new_n211_, new_n212_, new_n213_,
    new_n214_, new_n215_, new_n216_, new_n217_, new_n218_, new_n219_,
    new_n220_, new_n221_, new_n222_, new_n223_, new_n224_, new_n225_,
    new_n226_;
  AND3x1_ASAP7_75t_R   g000(.A(p27), .B(p28), .C(p26), .Y(new_n91_));
  NOR2x1_ASAP7_75t_R   g001(.A(p21), .B(p20), .Y(new_n92_));
  NOR2x1_ASAP7_75t_R   g002(.A(p12), .B(p11), .Y(new_n93_));
  OAI21x1_ASAP7_75t_R  g003(.A1(p8), .A2(p9), .B(p10), .Y(new_n94_));
  NAND2x1_ASAP7_75t_R  g004(.A(p13), .B(p14), .Y(new_n95_));
  AOI21x1_ASAP7_75t_R  g005(.A1(new_n93_), .A2(new_n94_), .B(new_n95_), .Y(new_n96_));
  AO21x1_ASAP7_75t_R   g006(.A1(p16), .A2(p15), .B(p17), .Y(new_n97_));
  AOI21x1_ASAP7_75t_R  g007(.A1(p16), .A2(new_n96_), .B(new_n97_), .Y(new_n98_));
  AND2x2_ASAP7_75t_R   g008(.A(p24), .B(p23), .Y(new_n99_));
  INVx1_ASAP7_75t_R    g009(.A(new_n99_), .Y(new_n100_));
  NAND2x1_ASAP7_75t_R  g010(.A(p19), .B(p18), .Y(new_n101_));
  INVx1_ASAP7_75t_R    g011(.A(p22), .Y(new_n102_));
  AO21x1_ASAP7_75t_R   g012(.A1(new_n101_), .A2(new_n92_), .B(new_n102_), .Y(new_n103_));
  AOI211x1_ASAP7_75t_R g013(.A1(new_n92_), .A2(new_n98_), .B(new_n100_), .C(new_n103_), .Y(new_n104_));
  AND2x2_ASAP7_75t_R   g014(.A(p25), .B(new_n91_), .Y(new_n105_));
  AO21x1_ASAP7_75t_R   g015(.A1(new_n91_), .A2(new_n104_), .B(new_n105_), .Y(new_n106_));
  OA21x2_ASAP7_75t_R   g016(.A1(p15), .A2(new_n96_), .B(p16), .Y(new_n107_));
  INVx1_ASAP7_75t_R    g017(.A(p10), .Y(new_n108_));
  OR4x2_ASAP7_75t_R    g018(.A(new_n108_), .B(p5), .C(p11), .D(p17), .Y(new_n109_));
  INVx1_ASAP7_75t_R    g019(.A(p18), .Y(new_n110_));
  OR3x1_ASAP7_75t_R    g020(.A(new_n110_), .B(p4), .C(p9), .Y(new_n111_));
  OR4x2_ASAP7_75t_R    g021(.A(p2), .B(p3), .C(p0), .D(p12), .Y(new_n112_));
  NOR3x1_ASAP7_75t_R   g022(.A(new_n109_), .B(new_n111_), .C(new_n112_), .Y(new_n113_));
  INVx1_ASAP7_75t_R    g023(.A(p8), .Y(new_n114_));
  OR4x2_ASAP7_75t_R    g024(.A(new_n114_), .B(p6), .C(p1), .D(p7), .Y(new_n115_));
  NOR3x1_ASAP7_75t_R   g025(.A(new_n115_), .B(new_n100_), .C(new_n95_), .Y(new_n116_));
  AND2x2_ASAP7_75t_R   g026(.A(p22), .B(p19), .Y(new_n117_));
  INVx1_ASAP7_75t_R    g027(.A(p25), .Y(new_n118_));
  AND3x1_ASAP7_75t_R   g028(.A(new_n117_), .B(new_n118_), .C(new_n92_), .Y(new_n119_));
  INVx1_ASAP7_75t_R    g029(.A(p15), .Y(new_n120_));
  AO21x1_ASAP7_75t_R   g030(.A1(new_n93_), .A2(new_n94_), .B(new_n120_), .Y(new_n121_));
  AND5x1_ASAP7_75t_R   g031(.A(new_n107_), .B(new_n113_), .C(new_n116_), .D(new_n119_), .E(new_n121_), .Y(new_n122_));
  INVx1_ASAP7_75t_R    g032(.A(new_n122_), .Y(new_n123_));
  INVx1_ASAP7_75t_R    g033(.A(p23), .Y(new_n124_));
  OAI21x1_ASAP7_75t_R  g034(.A1(new_n102_), .A2(new_n92_), .B(new_n124_), .Y(new_n125_));
  AND3x1_ASAP7_75t_R   g035(.A(p4), .B(p14), .C(p59), .Y(new_n126_));
  NOR2x1_ASAP7_75t_R   g036(.A(p15), .B(p17), .Y(new_n127_));
  AND5x1_ASAP7_75t_R   g037(.A(p10), .B(new_n91_), .C(new_n126_), .D(p18), .E(new_n127_), .Y(new_n128_));
  INVx1_ASAP7_75t_R    g038(.A(p9), .Y(new_n129_));
  AND5x1_ASAP7_75t_R   g039(.A(p6), .B(new_n93_), .C(p1), .D(new_n114_), .E(new_n129_), .Y(new_n130_));
  AND2x2_ASAP7_75t_R   g040(.A(p16), .B(p0), .Y(new_n131_));
  AND3x1_ASAP7_75t_R   g041(.A(new_n131_), .B(p5), .C(p13), .Y(new_n132_));
  AND2x2_ASAP7_75t_R   g042(.A(p2), .B(p3), .Y(new_n133_));
  AND3x1_ASAP7_75t_R   g043(.A(new_n133_), .B(p7), .C(p24), .Y(new_n134_));
  AND5x1_ASAP7_75t_R   g044(.A(new_n128_), .B(new_n119_), .C(new_n130_), .D(new_n132_), .E(new_n134_), .Y(new_n135_));
  AOI221x1_ASAP7_75t_R g045(.A1(new_n125_), .A2(new_n135_), .B1(new_n104_), .B2(new_n91_), .C(new_n105_), .Y(new_n136_));
  AO21x1_ASAP7_75t_R   g046(.A1(new_n106_), .A2(new_n123_), .B(new_n136_), .Y(o0));
  AO221x2_ASAP7_75t_R  g047(.A1(new_n125_), .A2(new_n135_), .B1(new_n104_), .B2(new_n91_), .C(new_n105_), .Y(new_n138_));
  AND2x2_ASAP7_75t_R   g048(.A(p49), .B(p48), .Y(new_n139_));
  INVx1_ASAP7_75t_R    g049(.A(new_n139_), .Y(new_n140_));
  NOR2x1_ASAP7_75t_R   g050(.A(p41), .B(p42), .Y(new_n141_));
  OAI21x1_ASAP7_75t_R  g051(.A1(p39), .A2(p38), .B(p40), .Y(new_n142_));
  NAND2x1_ASAP7_75t_R  g052(.A(p44), .B(p43), .Y(new_n143_));
  AOI21x1_ASAP7_75t_R  g053(.A1(new_n141_), .A2(new_n142_), .B(new_n143_), .Y(new_n144_));
  AO21x1_ASAP7_75t_R   g054(.A1(p45), .A2(p46), .B(p47), .Y(new_n145_));
  AOI21x1_ASAP7_75t_R  g055(.A1(p46), .A2(new_n144_), .B(new_n145_), .Y(new_n146_));
  INVx1_ASAP7_75t_R    g056(.A(p55), .Y(new_n147_));
  INVx1_ASAP7_75t_R    g057(.A(p50), .Y(new_n148_));
  INVx1_ASAP7_75t_R    g058(.A(p51), .Y(new_n149_));
  AND3x1_ASAP7_75t_R   g059(.A(new_n147_), .B(new_n148_), .C(new_n149_), .Y(new_n150_));
  OAI21x1_ASAP7_75t_R  g060(.A1(new_n140_), .A2(new_n146_), .B(new_n150_), .Y(new_n151_));
  AND2x2_ASAP7_75t_R   g061(.A(p54), .B(p53), .Y(new_n152_));
  NAND2x1_ASAP7_75t_R  g062(.A(p52), .B(new_n152_), .Y(new_n153_));
  AND3x1_ASAP7_75t_R   g063(.A(p57), .B(p56), .C(p58), .Y(new_n154_));
  INVx1_ASAP7_75t_R    g064(.A(new_n154_), .Y(new_n155_));
  AO21x1_ASAP7_75t_R   g065(.A1(new_n147_), .A2(new_n153_), .B(new_n155_), .Y(new_n156_));
  INVx1_ASAP7_75t_R    g066(.A(new_n156_), .Y(new_n157_));
  INVx1_ASAP7_75t_R    g067(.A(p59), .Y(new_n158_));
  AOI22x1_ASAP7_75t_R  g068(.A1(new_n151_), .A2(new_n157_), .B1(new_n148_), .B2(new_n158_), .Y(new_n159_));
  AND3x1_ASAP7_75t_R   g069(.A(p29), .B(p46), .C(p30), .Y(new_n160_));
  AND5x1_ASAP7_75t_R   g070(.A(p49), .B(new_n160_), .C(p37), .D(p35), .E(p31), .Y(new_n161_));
  AND2x2_ASAP7_75t_R   g071(.A(p32), .B(p44), .Y(new_n162_));
  AND2x2_ASAP7_75t_R   g072(.A(p36), .B(p34), .Y(new_n163_));
  NOR2x1_ASAP7_75t_R   g073(.A(p39), .B(p38), .Y(new_n164_));
  AND5x1_ASAP7_75t_R   g074(.A(new_n147_), .B(new_n162_), .C(new_n163_), .D(p33), .E(new_n164_), .Y(new_n165_));
  INVx1_ASAP7_75t_R    g075(.A(p45), .Y(new_n166_));
  AND4x2_ASAP7_75t_R   g076(.A(new_n154_), .B(new_n152_), .C(p40), .D(new_n166_), .Y(new_n167_));
  AND2x2_ASAP7_75t_R   g077(.A(p45), .B(p46), .Y(new_n168_));
  AO21x1_ASAP7_75t_R   g078(.A1(p47), .A2(new_n168_), .B(p48), .Y(new_n169_));
  NAND2x1_ASAP7_75t_R  g079(.A(p48), .B(new_n145_), .Y(new_n170_));
  AND5x1_ASAP7_75t_R   g080(.A(new_n161_), .B(new_n165_), .C(new_n167_), .D(new_n169_), .E(new_n170_), .Y(new_n171_));
  NAND2x1_ASAP7_75t_R  g081(.A(p52), .B(new_n149_), .Y(new_n172_));
  OAI21x1_ASAP7_75t_R  g082(.A1(new_n140_), .A2(new_n146_), .B(new_n172_), .Y(new_n173_));
  INVx1_ASAP7_75t_R    g083(.A(p41), .Y(new_n174_));
  NOR2x1_ASAP7_75t_R   g084(.A(new_n174_), .B(new_n142_), .Y(new_n175_));
  AOI21x1_ASAP7_75t_R  g085(.A1(p42), .A2(new_n175_), .B(p43), .Y(new_n176_));
  NAND2x1_ASAP7_75t_R  g086(.A(new_n174_), .B(new_n142_), .Y(new_n177_));
  OA21x2_ASAP7_75t_R   g087(.A1(p42), .A2(new_n177_), .B(p43), .Y(new_n178_));
  NOR2x1_ASAP7_75t_R   g088(.A(new_n176_), .B(new_n178_), .Y(new_n179_));
  NAND3x1_ASAP7_75t_R  g089(.A(new_n171_), .B(new_n173_), .C(new_n179_), .Y(new_n180_));
  NAND2x1_ASAP7_75t_R  g090(.A(p47), .B(p46), .Y(new_n181_));
  NOR2x1_ASAP7_75t_R   g091(.A(p33), .B(p32), .Y(new_n182_));
  AND5x1_ASAP7_75t_R   g092(.A(new_n177_), .B(new_n139_), .C(new_n152_), .D(new_n181_), .E(new_n182_), .Y(new_n183_));
  OR3x1_ASAP7_75t_R    g093(.A(new_n143_), .B(p55), .C(p39), .Y(new_n184_));
  INVx1_ASAP7_75t_R    g094(.A(p40), .Y(new_n185_));
  INVx1_ASAP7_75t_R    g095(.A(p38), .Y(new_n186_));
  OR3x1_ASAP7_75t_R    g096(.A(new_n185_), .B(new_n186_), .C(p45), .Y(new_n187_));
  NOR2x1_ASAP7_75t_R   g097(.A(p36), .B(p37), .Y(new_n188_));
  NOR2x1_ASAP7_75t_R   g098(.A(p50), .B(p42), .Y(new_n189_));
  NAND3x1_ASAP7_75t_R  g099(.A(new_n188_), .B(new_n189_), .C(p56), .Y(new_n190_));
  NOR3x1_ASAP7_75t_R   g100(.A(new_n184_), .B(new_n187_), .C(new_n190_), .Y(new_n191_));
  OR4x2_ASAP7_75t_R    g101(.A(p34), .B(p35), .C(p31), .D(p30), .Y(new_n192_));
  NOR3x1_ASAP7_75t_R   g102(.A(new_n175_), .B(new_n192_), .C(new_n172_), .Y(new_n193_));
  NAND3x1_ASAP7_75t_R  g103(.A(new_n183_), .B(new_n191_), .C(new_n193_), .Y(new_n194_));
  NAND2x1_ASAP7_75t_R  g104(.A(p47), .B(new_n166_), .Y(new_n195_));
  NOR2x1_ASAP7_75t_R   g105(.A(new_n195_), .B(new_n144_), .Y(new_n196_));
  AO21x1_ASAP7_75t_R   g106(.A1(p46), .A2(new_n144_), .B(new_n168_), .Y(new_n197_));
  NOR2x1_ASAP7_75t_R   g107(.A(p29), .B(p59), .Y(new_n198_));
  OAI21x1_ASAP7_75t_R  g108(.A1(new_n196_), .A2(new_n197_), .B(new_n198_), .Y(new_n199_));
  INVx1_ASAP7_75t_R    g109(.A(p46), .Y(new_n200_));
  AOI211x1_ASAP7_75t_R g110(.A1(new_n141_), .A2(new_n142_), .B(new_n200_), .C(new_n143_), .Y(new_n201_));
  OAI21x1_ASAP7_75t_R  g111(.A1(new_n145_), .A2(new_n201_), .B(new_n139_), .Y(new_n202_));
  AOI21x1_ASAP7_75t_R  g112(.A1(new_n150_), .A2(new_n202_), .B(new_n156_), .Y(new_n203_));
  OAI21x1_ASAP7_75t_R  g113(.A1(new_n194_), .A2(new_n199_), .B(new_n203_), .Y(new_n204_));
  OAI21x1_ASAP7_75t_R  g114(.A1(new_n159_), .A2(new_n180_), .B(new_n204_), .Y(new_n205_));
  INVx1_ASAP7_75t_R    g115(.A(new_n105_), .Y(new_n206_));
  AOI21x1_ASAP7_75t_R  g116(.A1(new_n92_), .A2(new_n98_), .B(new_n103_), .Y(new_n207_));
  NAND3x1_ASAP7_75t_R  g117(.A(new_n207_), .B(new_n91_), .C(new_n99_), .Y(new_n208_));
  AOI21x1_ASAP7_75t_R  g118(.A1(new_n206_), .A2(new_n208_), .B(new_n122_), .Y(new_n209_));
  AOI21x1_ASAP7_75t_R  g119(.A1(new_n138_), .A2(new_n205_), .B(new_n209_), .Y(o1));
  AND5x1_ASAP7_75t_R   g120(.A(p54), .B(new_n139_), .C(p53), .D(new_n181_), .E(new_n182_), .Y(new_n211_));
  AND3x1_ASAP7_75t_R   g121(.A(new_n193_), .B(new_n177_), .C(new_n211_), .Y(new_n212_));
  NOR2x1_ASAP7_75t_R   g122(.A(new_n168_), .B(new_n201_), .Y(new_n213_));
  OAI21x1_ASAP7_75t_R  g123(.A1(new_n144_), .A2(new_n195_), .B(new_n213_), .Y(new_n214_));
  OR3x1_ASAP7_75t_R    g124(.A(new_n143_), .B(p42), .C(new_n185_), .Y(new_n215_));
  NOR2x1_ASAP7_75t_R   g125(.A(p50), .B(p45), .Y(new_n216_));
  AND3x1_ASAP7_75t_R   g126(.A(new_n216_), .B(new_n147_), .C(p56), .Y(new_n217_));
  INVx1_ASAP7_75t_R    g127(.A(p39), .Y(new_n218_));
  AND3x1_ASAP7_75t_R   g128(.A(new_n188_), .B(new_n218_), .C(p38), .Y(new_n219_));
  NAND2x1_ASAP7_75t_R  g129(.A(new_n217_), .B(new_n219_), .Y(new_n220_));
  AOI211x1_ASAP7_75t_R g130(.A1(p29), .A2(p59), .B(new_n215_), .C(new_n220_), .Y(new_n221_));
  NAND3x1_ASAP7_75t_R  g131(.A(new_n212_), .B(new_n214_), .C(new_n221_), .Y(new_n222_));
  NOR2x1_ASAP7_75t_R   g132(.A(p50), .B(p51), .Y(new_n223_));
  OA21x2_ASAP7_75t_R   g133(.A1(new_n223_), .A2(new_n153_), .B(new_n147_), .Y(new_n224_));
  OAI21x1_ASAP7_75t_R  g134(.A1(new_n153_), .A2(new_n202_), .B(new_n224_), .Y(new_n225_));
  NAND3x1_ASAP7_75t_R  g135(.A(new_n222_), .B(new_n154_), .C(new_n225_), .Y(new_n226_));
  AOI211x1_ASAP7_75t_R g136(.A1(new_n123_), .A2(new_n106_), .B(new_n136_), .C(new_n226_), .Y(o2));
  assign               o3 = 1'b0;
  assign               o4 = 1'b0;
  assign               o5 = 1'b0;
  assign               o6 = 1'b0;
  assign               o7 = 1'b0;
  assign               o8 = 1'b0;
  assign               o9 = 1'b0;
  assign               o10 = 1'b0;
  assign               o11 = 1'b0;
  assign               o12 = 1'b0;
  assign               o13 = 1'b0;
  assign               o14 = 1'b0;
  assign               o15 = 1'b0;
  assign               o16 = 1'b0;
  assign               o17 = 1'b0;
  assign               o18 = 1'b0;
  assign               o19 = 1'b0;
  assign               o20 = 1'b0;
  assign               o21 = 1'b0;
  assign               o22 = 1'b0;
  assign               o23 = 1'b0;
  assign               o24 = 1'b0;
  assign               o25 = 1'b0;
  assign               o26 = 1'b0;
  assign               o27 = 1'b0;
  assign               o28 = 1'b0;
  assign               o29 = 1'b0;
endmodule


