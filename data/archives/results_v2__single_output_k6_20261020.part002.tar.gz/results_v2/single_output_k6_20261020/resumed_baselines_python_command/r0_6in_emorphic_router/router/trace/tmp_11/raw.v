// Benchmark "/tmp/" written by ABC on Tue Oct 20 18:11:45 2026

module \/tmp/  ( 
    p54, p56, p9, p41, p37, p30, p45, p51, p26, p14, p24, p21, p42, p58,
    p8, p55, p1, p40, p29, p34, p50, p33, p43, p52, p5, p10, p4, p32, p17,
    p6, p39, p23, p11, p18, p25, p49, p48, p28, p0, p27, p13, p57, p16,
    p15, p35, p3, p59, p53, p36, p12, p46, p20, p31, p22, p7, p19, p38,
    p44, p2, p47,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25, o26, o27, o28, o29  );
  input  p54, p56, p9, p41, p37, p30, p45, p51, p26, p14, p24, p21, p42,
    p58, p8, p55, p1, p40, p29, p34, p50, p33, p43, p52, p5, p10, p4, p32,
    p17, p6, p39, p23, p11, p18, p25, p49, p48, p28, p0, p27, p13, p57,
    p16, p15, p35, p3, p59, p53, p36, p12, p46, p20, p31, p22, p7, p19,
    p38, p44, p2, p47;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25, o26, o27, o28, o29;
  wire new_n91_, new_n92_, new_n93_, new_n94_, new_n95_, new_n96_, new_n97_,
    new_n98_, new_n99_, new_n100_, new_n101_, new_n102_, new_n103_,
    new_n104_, new_n105_, new_n106_, new_n107_, new_n108_, new_n109_,
    new_n110_, new_n111_, new_n112_, new_n113_, new_n114_, new_n115_,
    new_n116_, new_n117_, new_n118_, new_n119_, new_n120_, new_n121_,
    new_n122_, new_n123_, new_n124_, new_n125_, new_n126_, new_n127_,
    new_n128_, new_n129_, new_n130_, new_n131_, new_n132_, new_n133_,
    new_n134_, new_n135_, new_n136_, new_n137_, new_n139_, new_n140_,
    new_n141_, new_n142_, new_n143_, new_n144_, new_n145_, new_n146_,
    new_n147_, new_n148_, new_n149_, new_n150_, new_n151_, new_n152_,
    new_n153_, new_n154_, new_n155_, new_n156_, new_n157_, new_n158_,
    new_n159_, new_n160_, new_n161_, new_n162_, new_n163_, new_n164_,
    new_n165_, new_n166_, new_n167_, new_n168_, new_n169_, new_n170_,
    new_n171_, new_n172_, new_n173_, new_n174_, new_n175_, new_n176_,
    new_n177_, new_n178_, new_n179_, new_n180_, new_n181_, new_n182_,
    new_n183_, new_n184_, new_n185_, new_n186_, new_n187_, new_n188_,
    new_n189_, new_n190_, new_n191_, new_n192_, new_n193_, new_n194_,
    new_n195_, new_n196_, new_n197_, new_n198_, new_n199_, new_n200_,
    new_n201_, new_n202_, new_n203_, new_n204_, new_n205_, new_n206_,
    new_n207_, new_n208_, new_n210_, new_n211_, new_n212_, new_n213_,
    new_n214_, new_n215_, new_n216_, new_n217_, new_n218_, new_n219_,
    new_n220_, new_n221_, new_n222_, new_n223_, new_n224_, new_n225_,
    new_n226_, new_n227_, new_n228_, new_n229_, new_n230_, new_n231_;
  INVx1_ASAP7_75t_R    g000(.A(p22), .Y(new_n91_));
  NOR2x1_ASAP7_75t_R   g001(.A(p21), .B(p20), .Y(new_n92_));
  INVx1_ASAP7_75t_R    g002(.A(p23), .Y(new_n93_));
  OA21x2_ASAP7_75t_R   g003(.A1(new_n91_), .A2(new_n92_), .B(new_n93_), .Y(new_n94_));
  NOR2x1_ASAP7_75t_R   g004(.A(p11), .B(p12), .Y(new_n95_));
  NOR2x1_ASAP7_75t_R   g005(.A(p9), .B(p8), .Y(new_n96_));
  NOR2x1_ASAP7_75t_R   g006(.A(p25), .B(p15), .Y(new_n97_));
  AND5x1_ASAP7_75t_R   g007(.A(p14), .B(new_n95_), .C(new_n96_), .D(new_n97_), .E(p13), .Y(new_n98_));
  AND2x2_ASAP7_75t_R   g008(.A(p6), .B(p18), .Y(new_n99_));
  AND3x1_ASAP7_75t_R   g009(.A(new_n99_), .B(p24), .C(p0), .Y(new_n100_));
  AND2x2_ASAP7_75t_R   g010(.A(p1), .B(p5), .Y(new_n101_));
  AND3x1_ASAP7_75t_R   g011(.A(new_n101_), .B(p10), .C(p4), .Y(new_n102_));
  NAND3x1_ASAP7_75t_R  g012(.A(new_n98_), .B(new_n100_), .C(new_n102_), .Y(new_n103_));
  OAI21x1_ASAP7_75t_R  g013(.A1(p9), .A2(p8), .B(p10), .Y(new_n104_));
  NAND2x1_ASAP7_75t_R  g014(.A(p14), .B(p13), .Y(new_n105_));
  AOI21x1_ASAP7_75t_R  g015(.A1(new_n95_), .A2(new_n104_), .B(new_n105_), .Y(new_n106_));
  OA21x2_ASAP7_75t_R   g016(.A1(p15), .A2(new_n106_), .B(p16), .Y(new_n107_));
  NOR3x1_ASAP7_75t_R   g017(.A(new_n106_), .B(p16), .C(p15), .Y(new_n108_));
  AND3x1_ASAP7_75t_R   g018(.A(new_n92_), .B(p22), .C(p19), .Y(new_n109_));
  AND3x1_ASAP7_75t_R   g019(.A(p26), .B(p28), .C(p27), .Y(new_n110_));
  AND4x2_ASAP7_75t_R   g020(.A(p3), .B(p59), .C(p7), .D(p2), .Y(new_n111_));
  NAND3x1_ASAP7_75t_R  g021(.A(new_n109_), .B(new_n110_), .C(new_n111_), .Y(new_n112_));
  OR5x1_ASAP7_75t_R    g022(.A(p17), .B(new_n103_), .C(new_n107_), .D(new_n108_), .E(new_n112_), .Y(new_n113_));
  AND2x2_ASAP7_75t_R   g023(.A(p24), .B(p23), .Y(new_n114_));
  AO21x1_ASAP7_75t_R   g024(.A1(p16), .A2(p15), .B(p17), .Y(new_n115_));
  AOI21x1_ASAP7_75t_R  g025(.A1(p16), .A2(new_n106_), .B(new_n115_), .Y(new_n116_));
  NAND2x1_ASAP7_75t_R  g026(.A(p18), .B(p19), .Y(new_n117_));
  AO21x1_ASAP7_75t_R   g027(.A1(new_n117_), .A2(new_n92_), .B(new_n91_), .Y(new_n118_));
  AOI21x1_ASAP7_75t_R  g028(.A1(new_n92_), .A2(new_n116_), .B(new_n118_), .Y(new_n119_));
  AOI21x1_ASAP7_75t_R  g029(.A1(new_n114_), .A2(new_n119_), .B(p25), .Y(new_n120_));
  INVx1_ASAP7_75t_R    g030(.A(new_n110_), .Y(new_n121_));
  OAI22x1_ASAP7_75t_R  g031(.A1(new_n94_), .A2(new_n113_), .B1(new_n120_), .B2(new_n121_), .Y(new_n122_));
  NOR3x1_ASAP7_75t_R   g032(.A(p12), .B(p7), .C(p2), .Y(new_n123_));
  AND2x2_ASAP7_75t_R   g033(.A(new_n123_), .B(new_n109_), .Y(new_n124_));
  INVx1_ASAP7_75t_R    g034(.A(new_n96_), .Y(new_n125_));
  INVx1_ASAP7_75t_R    g035(.A(p10), .Y(new_n126_));
  NAND2x1_ASAP7_75t_R  g036(.A(p11), .B(new_n126_), .Y(new_n127_));
  OAI22x1_ASAP7_75t_R  g037(.A1(new_n125_), .A2(new_n127_), .B1(p11), .B2(new_n104_), .Y(new_n128_));
  INVx1_ASAP7_75t_R    g038(.A(p9), .Y(new_n129_));
  INVx1_ASAP7_75t_R    g039(.A(new_n105_), .Y(new_n130_));
  AND5x1_ASAP7_75t_R   g040(.A(new_n129_), .B(new_n130_), .C(p8), .D(new_n114_), .E(new_n97_), .Y(new_n131_));
  OR4x2_ASAP7_75t_R    g041(.A(p1), .B(p5), .C(p4), .D(p17), .Y(new_n132_));
  INVx1_ASAP7_75t_R    g042(.A(p18), .Y(new_n133_));
  OR4x2_ASAP7_75t_R    g043(.A(new_n133_), .B(p6), .C(p0), .D(p3), .Y(new_n134_));
  NOR2x1_ASAP7_75t_R   g044(.A(new_n132_), .B(new_n134_), .Y(new_n135_));
  AND5x1_ASAP7_75t_R   g045(.A(new_n107_), .B(new_n124_), .C(new_n128_), .D(new_n131_), .E(new_n135_), .Y(new_n136_));
  OR3x1_ASAP7_75t_R    g046(.A(new_n120_), .B(new_n121_), .C(new_n136_), .Y(new_n137_));
  NAND2x1_ASAP7_75t_R  g047(.A(new_n122_), .B(new_n137_), .Y(o0));
  AO21x1_ASAP7_75t_R   g048(.A1(p45), .A2(p46), .B(p47), .Y(new_n139_));
  NOR2x1_ASAP7_75t_R   g049(.A(p41), .B(p42), .Y(new_n140_));
  OAI21x1_ASAP7_75t_R  g050(.A1(p39), .A2(p38), .B(p40), .Y(new_n141_));
  INVx1_ASAP7_75t_R    g051(.A(p46), .Y(new_n142_));
  NAND2x1_ASAP7_75t_R  g052(.A(p43), .B(p44), .Y(new_n143_));
  AOI211x1_ASAP7_75t_R g053(.A1(new_n140_), .A2(new_n141_), .B(new_n142_), .C(new_n143_), .Y(new_n144_));
  AND2x2_ASAP7_75t_R   g054(.A(p49), .B(p48), .Y(new_n145_));
  INVx1_ASAP7_75t_R    g055(.A(p51), .Y(new_n146_));
  NOR2x1_ASAP7_75t_R   g056(.A(p52), .B(new_n146_), .Y(new_n147_));
  OA211x2_ASAP7_75t_R  g057(.A1(new_n139_), .A2(new_n144_), .B(new_n145_), .C(new_n147_), .Y(new_n148_));
  NAND2x1_ASAP7_75t_R  g058(.A(new_n140_), .B(new_n141_), .Y(new_n149_));
  INVx1_ASAP7_75t_R    g059(.A(new_n143_), .Y(new_n150_));
  AO31x2_ASAP7_75t_R   g060(.A1(new_n149_), .A2(p46), .A3(new_n150_), .B(new_n139_), .Y(new_n151_));
  NAND2x1_ASAP7_75t_R  g061(.A(p52), .B(new_n146_), .Y(new_n152_));
  AOI21x1_ASAP7_75t_R  g062(.A1(new_n145_), .A2(new_n151_), .B(new_n152_), .Y(new_n153_));
  NAND2x1_ASAP7_75t_R  g063(.A(p45), .B(p46), .Y(new_n154_));
  AND3x1_ASAP7_75t_R   g064(.A(p45), .B(p48), .C(p46), .Y(new_n155_));
  AND3x1_ASAP7_75t_R   g065(.A(p56), .B(p58), .C(p57), .Y(new_n156_));
  INVx1_ASAP7_75t_R    g066(.A(new_n156_), .Y(new_n157_));
  AOI211x1_ASAP7_75t_R g067(.A1(p47), .A2(new_n154_), .B(new_n155_), .C(new_n157_), .Y(new_n158_));
  AND2x2_ASAP7_75t_R   g068(.A(p35), .B(p36), .Y(new_n159_));
  AND2x2_ASAP7_75t_R   g069(.A(p34), .B(p33), .Y(new_n160_));
  AND2x2_ASAP7_75t_R   g070(.A(p32), .B(p49), .Y(new_n161_));
  AND5x1_ASAP7_75t_R   g071(.A(p46), .B(new_n159_), .C(new_n160_), .D(new_n161_), .E(p31), .Y(new_n162_));
  AND3x1_ASAP7_75t_R   g072(.A(new_n150_), .B(p54), .C(p53), .Y(new_n163_));
  AND2x2_ASAP7_75t_R   g073(.A(p37), .B(p30), .Y(new_n164_));
  NOR2x1_ASAP7_75t_R   g074(.A(p39), .B(p38), .Y(new_n165_));
  AND5x1_ASAP7_75t_R   g075(.A(p40), .B(new_n164_), .C(p29), .D(new_n165_), .E(new_n140_), .Y(new_n166_));
  INVx1_ASAP7_75t_R    g076(.A(p45), .Y(new_n167_));
  INVx1_ASAP7_75t_R    g077(.A(p55), .Y(new_n168_));
  OA211x2_ASAP7_75t_R  g078(.A1(p48), .A2(p47), .B(new_n167_), .C(new_n168_), .Y(new_n169_));
  AND5x1_ASAP7_75t_R   g079(.A(new_n158_), .B(new_n162_), .C(new_n163_), .D(new_n166_), .E(new_n169_), .Y(new_n170_));
  OAI21x1_ASAP7_75t_R  g080(.A1(new_n148_), .A2(new_n153_), .B(new_n170_), .Y(new_n171_));
  INVx1_ASAP7_75t_R    g081(.A(new_n145_), .Y(new_n172_));
  AOI21x1_ASAP7_75t_R  g082(.A1(new_n140_), .A2(new_n141_), .B(new_n143_), .Y(new_n173_));
  AOI21x1_ASAP7_75t_R  g083(.A1(p46), .A2(new_n173_), .B(new_n139_), .Y(new_n174_));
  INVx1_ASAP7_75t_R    g084(.A(p50), .Y(new_n175_));
  AND3x1_ASAP7_75t_R   g085(.A(new_n146_), .B(new_n168_), .C(new_n175_), .Y(new_n176_));
  OAI21x1_ASAP7_75t_R  g086(.A1(new_n172_), .A2(new_n174_), .B(new_n176_), .Y(new_n177_));
  AND3x1_ASAP7_75t_R   g087(.A(p54), .B(p52), .C(p53), .Y(new_n178_));
  OA21x2_ASAP7_75t_R   g088(.A1(p55), .A2(new_n178_), .B(new_n156_), .Y(new_n179_));
  INVx1_ASAP7_75t_R    g089(.A(p59), .Y(new_n180_));
  AOI22x1_ASAP7_75t_R  g090(.A1(new_n177_), .A2(new_n179_), .B1(new_n175_), .B2(new_n180_), .Y(new_n181_));
  OAI21x1_ASAP7_75t_R  g091(.A1(new_n139_), .A2(new_n144_), .B(new_n145_), .Y(new_n182_));
  INVx1_ASAP7_75t_R    g092(.A(new_n179_), .Y(new_n183_));
  AO21x1_ASAP7_75t_R   g093(.A1(new_n176_), .A2(new_n182_), .B(new_n183_), .Y(new_n184_));
  OAI21x1_ASAP7_75t_R  g094(.A1(p45), .A2(new_n173_), .B(p46), .Y(new_n185_));
  INVx1_ASAP7_75t_R    g095(.A(p47), .Y(new_n186_));
  OR3x1_ASAP7_75t_R    g096(.A(new_n173_), .B(p45), .C(new_n186_), .Y(new_n187_));
  INVx1_ASAP7_75t_R    g097(.A(p38), .Y(new_n188_));
  OR4x2_ASAP7_75t_R    g098(.A(new_n188_), .B(p50), .C(p39), .D(p36), .Y(new_n189_));
  INVx1_ASAP7_75t_R    g099(.A(p56), .Y(new_n190_));
  OR3x1_ASAP7_75t_R    g100(.A(new_n143_), .B(new_n190_), .C(p37), .Y(new_n191_));
  INVx1_ASAP7_75t_R    g101(.A(p40), .Y(new_n192_));
  OR3x1_ASAP7_75t_R    g102(.A(new_n192_), .B(p45), .C(p55), .Y(new_n193_));
  OR5x1_ASAP7_75t_R    g103(.A(p42), .B(new_n189_), .C(new_n191_), .D(p59), .E(new_n193_), .Y(new_n194_));
  INVx1_ASAP7_75t_R    g104(.A(p41), .Y(new_n195_));
  NAND2x1_ASAP7_75t_R  g105(.A(p46), .B(p47), .Y(new_n196_));
  NAND3x1_ASAP7_75t_R  g106(.A(new_n196_), .B(p49), .C(p48), .Y(new_n197_));
  NOR2x1_ASAP7_75t_R   g107(.A(p30), .B(p34), .Y(new_n198_));
  NAND3x1_ASAP7_75t_R  g108(.A(new_n198_), .B(p54), .C(p53), .Y(new_n199_));
  AOI211x1_ASAP7_75t_R g109(.A1(new_n195_), .A2(new_n141_), .B(new_n197_), .C(new_n199_), .Y(new_n200_));
  NOR2x1_ASAP7_75t_R   g110(.A(new_n195_), .B(new_n141_), .Y(new_n201_));
  OR4x2_ASAP7_75t_R    g111(.A(p33), .B(p32), .C(p35), .D(p31), .Y(new_n202_));
  NOR3x1_ASAP7_75t_R   g112(.A(new_n201_), .B(new_n202_), .C(new_n152_), .Y(new_n203_));
  INVx1_ASAP7_75t_R    g113(.A(p29), .Y(new_n204_));
  NAND3x1_ASAP7_75t_R  g114(.A(new_n200_), .B(new_n203_), .C(new_n204_), .Y(new_n205_));
  AOI211x1_ASAP7_75t_R g115(.A1(new_n185_), .A2(new_n187_), .B(new_n194_), .C(new_n205_), .Y(new_n206_));
  OAI22x1_ASAP7_75t_R  g116(.A1(new_n171_), .A2(new_n181_), .B1(new_n184_), .B2(new_n206_), .Y(new_n207_));
  NOR3x1_ASAP7_75t_R   g117(.A(new_n120_), .B(new_n121_), .C(new_n136_), .Y(new_n208_));
  AOI21x1_ASAP7_75t_R  g118(.A1(new_n122_), .A2(new_n207_), .B(new_n208_), .Y(o1));
  INVx1_ASAP7_75t_R    g119(.A(new_n114_), .Y(new_n210_));
  AOI211x1_ASAP7_75t_R g120(.A1(new_n92_), .A2(new_n116_), .B(new_n210_), .C(new_n118_), .Y(new_n211_));
  AND2x2_ASAP7_75t_R   g121(.A(p25), .B(new_n110_), .Y(new_n212_));
  AOI21x1_ASAP7_75t_R  g122(.A1(new_n110_), .A2(new_n211_), .B(new_n212_), .Y(new_n213_));
  INVx1_ASAP7_75t_R    g123(.A(new_n116_), .Y(new_n214_));
  OR5x1_ASAP7_75t_R    g124(.A(new_n214_), .B(new_n103_), .C(new_n112_), .D(new_n94_), .E(new_n108_), .Y(new_n215_));
  NAND2x1_ASAP7_75t_R  g125(.A(new_n185_), .B(new_n187_), .Y(new_n216_));
  NOR2x1_ASAP7_75t_R   g126(.A(p36), .B(p31), .Y(new_n217_));
  NOR2x1_ASAP7_75t_R   g127(.A(p33), .B(p32), .Y(new_n218_));
  NOR2x1_ASAP7_75t_R   g128(.A(p39), .B(p35), .Y(new_n219_));
  AND5x1_ASAP7_75t_R   g129(.A(new_n178_), .B(p38), .C(new_n217_), .D(new_n218_), .E(new_n219_), .Y(new_n220_));
  AND5x1_ASAP7_75t_R   g130(.A(new_n167_), .B(new_n150_), .C(new_n145_), .D(new_n168_), .E(new_n196_), .Y(new_n221_));
  XOR2x2_ASAP7_75t_R   g131(.A(new_n141_), .B(new_n195_), .Y(new_n222_));
  NOR2x1_ASAP7_75t_R   g132(.A(p34), .B(p50), .Y(new_n223_));
  INVx1_ASAP7_75t_R    g133(.A(p42), .Y(new_n224_));
  AND3x1_ASAP7_75t_R   g134(.A(new_n223_), .B(new_n224_), .C(p40), .Y(new_n225_));
  NOR2x1_ASAP7_75t_R   g135(.A(p30), .B(p51), .Y(new_n226_));
  INVx1_ASAP7_75t_R    g136(.A(p37), .Y(new_n227_));
  AND3x1_ASAP7_75t_R   g137(.A(new_n226_), .B(p56), .C(new_n227_), .Y(new_n228_));
  AND5x1_ASAP7_75t_R   g138(.A(new_n220_), .B(new_n221_), .C(new_n222_), .D(new_n225_), .E(new_n228_), .Y(new_n229_));
  NAND2x1_ASAP7_75t_R  g139(.A(p29), .B(p59), .Y(new_n230_));
  AO31x2_ASAP7_75t_R   g140(.A1(new_n216_), .A2(new_n229_), .A3(new_n230_), .B(new_n184_), .Y(new_n231_));
  AOI211x1_ASAP7_75t_R g141(.A1(new_n213_), .A2(new_n215_), .B(new_n208_), .C(new_n231_), .Y(o2));
  assign               o3 = 1'b0;
  assign               o4 = 1'b0;
  assign               o5 = 1'b0;
  assign               o6 = 1'b0;
  assign               o7 = 1'b0;
  assign               o8 = 1'b0;
  assign               o9 = 1'b0;
  assign               o10 = 1'b0;
  assign               o11 = 1'b0;
  assign               o12 = 1'b0;
  assign               o13 = 1'b0;
  assign               o14 = 1'b0;
  assign               o15 = 1'b0;
  assign               o16 = 1'b0;
  assign               o17 = 1'b0;
  assign               o18 = 1'b0;
  assign               o19 = 1'b0;
  assign               o20 = 1'b0;
  assign               o21 = 1'b0;
  assign               o22 = 1'b0;
  assign               o23 = 1'b0;
  assign               o24 = 1'b0;
  assign               o25 = 1'b0;
  assign               o26 = 1'b0;
  assign               o27 = 1'b0;
  assign               o28 = 1'b0;
  assign               o29 = 1'b0;
endmodule


