// Benchmark "/tmp/" written by ABC on Tue Oct 20 18:11:48 2026

module \/tmp/  ( 
    p37, p15, p26, p8, p44, p23, p49, p3, p48, p40, p9, p10, p36, p33, p52,
    p7, p46, p34, p11, p6, p20, p32, p1, p45, p24, p19, p58, p39, p51, p56,
    p59, p53, p13, p18, p2, p31, p27, p12, p16, p22, p29, p55, p42, p5,
    p43, p30, p14, p38, p47, p50, p4, p0, p57, p25, p54, p41, p21, p35,
    p17, p28,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25, o26, o27, o28, o29  );
  input  p37, p15, p26, p8, p44, p23, p49, p3, p48, p40, p9, p10, p36,
    p33, p52, p7, p46, p34, p11, p6, p20, p32, p1, p45, p24, p19, p58, p39,
    p51, p56, p59, p53, p13, p18, p2, p31, p27, p12, p16, p22, p29, p55,
    p42, p5, p43, p30, p14, p38, p47, p50, p4, p0, p57, p25, p54, p41, p21,
    p35, p17, p28;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25, o26, o27, o28, o29;
  wire new_n91_, new_n92_, new_n93_, new_n94_, new_n95_, new_n96_, new_n97_,
    new_n98_, new_n99_, new_n100_, new_n101_, new_n102_, new_n103_,
    new_n104_, new_n105_, new_n106_, new_n107_, new_n108_, new_n109_,
    new_n110_, new_n111_, new_n112_, new_n113_, new_n114_, new_n115_,
    new_n116_, new_n117_, new_n118_, new_n119_, new_n120_, new_n121_,
    new_n122_, new_n123_, new_n124_, new_n125_, new_n126_, new_n127_,
    new_n128_, new_n129_, new_n130_, new_n131_, new_n132_, new_n133_,
    new_n134_, new_n135_, new_n136_, new_n137_, new_n138_, new_n139_,
    new_n140_, new_n141_, new_n142_, new_n144_, new_n145_, new_n146_,
    new_n147_, new_n148_, new_n149_, new_n150_, new_n151_, new_n152_,
    new_n153_, new_n154_, new_n155_, new_n156_, new_n157_, new_n158_,
    new_n159_, new_n160_, new_n161_, new_n162_, new_n163_, new_n164_,
    new_n165_, new_n166_, new_n167_, new_n168_, new_n169_, new_n170_,
    new_n171_, new_n172_, new_n173_, new_n174_, new_n175_, new_n176_,
    new_n177_, new_n178_, new_n179_, new_n180_, new_n181_, new_n182_,
    new_n183_, new_n184_, new_n185_, new_n186_, new_n187_, new_n188_,
    new_n189_, new_n190_, new_n191_, new_n192_, new_n193_, new_n194_,
    new_n195_, new_n196_, new_n197_, new_n198_, new_n199_, new_n200_,
    new_n201_, new_n202_, new_n203_, new_n204_, new_n205_, new_n206_,
    new_n207_, new_n209_, new_n210_;
  AND3x1_ASAP7_75t_R   g000(.A(p26), .B(p27), .C(p28), .Y(new_n91_));
  OAI21x1_ASAP7_75t_R  g001(.A1(p20), .A2(p21), .B(p22), .Y(new_n92_));
  AO21x1_ASAP7_75t_R   g002(.A1(p15), .A2(p16), .B(p17), .Y(new_n93_));
  NOR2x1_ASAP7_75t_R   g003(.A(p11), .B(p12), .Y(new_n94_));
  OAI21x1_ASAP7_75t_R  g004(.A1(p8), .A2(p9), .B(p10), .Y(new_n95_));
  INVx1_ASAP7_75t_R    g005(.A(p16), .Y(new_n96_));
  NAND2x1_ASAP7_75t_R  g006(.A(p13), .B(p14), .Y(new_n97_));
  AOI211x1_ASAP7_75t_R g007(.A1(new_n94_), .A2(new_n95_), .B(new_n96_), .C(new_n97_), .Y(new_n98_));
  AND3x1_ASAP7_75t_R   g008(.A(p19), .B(p18), .C(p22), .Y(new_n99_));
  OAI21x1_ASAP7_75t_R  g009(.A1(new_n93_), .A2(new_n98_), .B(new_n99_), .Y(new_n100_));
  NAND2x1_ASAP7_75t_R  g010(.A(p23), .B(p24), .Y(new_n101_));
  AOI21x1_ASAP7_75t_R  g011(.A1(new_n92_), .A2(new_n100_), .B(new_n101_), .Y(new_n102_));
  AND2x2_ASAP7_75t_R   g012(.A(p25), .B(new_n91_), .Y(new_n103_));
  AO21x1_ASAP7_75t_R   g013(.A1(new_n91_), .A2(new_n102_), .B(new_n103_), .Y(new_n104_));
  INVx1_ASAP7_75t_R    g014(.A(p15), .Y(new_n105_));
  AO21x1_ASAP7_75t_R   g015(.A1(new_n94_), .A2(new_n95_), .B(new_n97_), .Y(new_n106_));
  AO21x1_ASAP7_75t_R   g016(.A1(new_n105_), .A2(new_n106_), .B(new_n96_), .Y(new_n107_));
  OR4x2_ASAP7_75t_R    g017(.A(p5), .B(p4), .C(p0), .D(p17), .Y(new_n108_));
  OR2x4_ASAP7_75t_R    g018(.A(p2), .B(p12), .Y(new_n109_));
  OR2x4_ASAP7_75t_R    g019(.A(p7), .B(p6), .Y(new_n110_));
  INVx1_ASAP7_75t_R    g020(.A(p3), .Y(new_n111_));
  INVx1_ASAP7_75t_R    g021(.A(p9), .Y(new_n112_));
  NAND2x1_ASAP7_75t_R  g022(.A(new_n111_), .B(new_n112_), .Y(new_n113_));
  INVx1_ASAP7_75t_R    g023(.A(p1), .Y(new_n114_));
  NAND2x1_ASAP7_75t_R  g024(.A(p18), .B(new_n114_), .Y(new_n115_));
  OR5x1_ASAP7_75t_R    g025(.A(new_n108_), .B(new_n109_), .C(new_n110_), .D(new_n113_), .E(new_n115_), .Y(new_n116_));
  NAND2x1_ASAP7_75t_R  g026(.A(p19), .B(p22), .Y(new_n117_));
  OR4x2_ASAP7_75t_R    g027(.A(new_n117_), .B(p20), .C(p25), .D(p21), .Y(new_n118_));
  INVx1_ASAP7_75t_R    g028(.A(p8), .Y(new_n119_));
  NAND2x1_ASAP7_75t_R  g029(.A(new_n119_), .B(new_n112_), .Y(new_n120_));
  INVx1_ASAP7_75t_R    g030(.A(p10), .Y(new_n121_));
  NAND2x1_ASAP7_75t_R  g031(.A(p11), .B(new_n121_), .Y(new_n122_));
  OA22x2_ASAP7_75t_R   g032(.A1(new_n120_), .A2(new_n122_), .B1(p11), .B2(new_n95_), .Y(new_n123_));
  OR4x2_ASAP7_75t_R    g033(.A(new_n101_), .B(new_n97_), .C(p15), .D(new_n119_), .Y(new_n124_));
  OR5x1_ASAP7_75t_R    g034(.A(new_n107_), .B(new_n116_), .C(new_n118_), .D(new_n123_), .E(new_n124_), .Y(new_n125_));
  INVx1_ASAP7_75t_R    g035(.A(p23), .Y(new_n126_));
  NAND2x1_ASAP7_75t_R  g036(.A(new_n126_), .B(new_n92_), .Y(new_n127_));
  AOI21x1_ASAP7_75t_R  g037(.A1(new_n94_), .A2(new_n95_), .B(new_n97_), .Y(new_n128_));
  AOI21x1_ASAP7_75t_R  g038(.A1(p16), .A2(new_n128_), .B(new_n93_), .Y(new_n129_));
  NAND2x1_ASAP7_75t_R  g039(.A(new_n96_), .B(new_n106_), .Y(new_n130_));
  AND4x2_ASAP7_75t_R   g040(.A(p24), .B(p59), .C(p18), .D(p2), .Y(new_n131_));
  AND4x2_ASAP7_75t_R   g041(.A(p10), .B(p7), .C(p6), .D(p1), .Y(new_n132_));
  AND4x2_ASAP7_75t_R   g042(.A(p5), .B(p14), .C(p4), .D(p0), .Y(new_n133_));
  AND4x2_ASAP7_75t_R   g043(.A(new_n131_), .B(new_n132_), .C(new_n133_), .D(new_n91_), .Y(new_n134_));
  AND5x1_ASAP7_75t_R   g044(.A(new_n105_), .B(new_n94_), .C(new_n119_), .D(p3), .E(new_n112_), .Y(new_n135_));
  INVx1_ASAP7_75t_R    g045(.A(p13), .Y(new_n136_));
  OR3x1_ASAP7_75t_R    g046(.A(p20), .B(p25), .C(p21), .Y(new_n137_));
  AOI211x1_ASAP7_75t_R g047(.A1(new_n136_), .A2(new_n95_), .B(new_n117_), .C(new_n137_), .Y(new_n138_));
  AND5x1_ASAP7_75t_R   g048(.A(new_n129_), .B(new_n130_), .C(new_n134_), .D(new_n135_), .E(new_n138_), .Y(new_n139_));
  INVx1_ASAP7_75t_R    g049(.A(new_n91_), .Y(new_n140_));
  AOI211x1_ASAP7_75t_R g050(.A1(new_n92_), .A2(new_n100_), .B(new_n140_), .C(new_n101_), .Y(new_n141_));
  AOI211x1_ASAP7_75t_R g051(.A1(new_n127_), .A2(new_n139_), .B(new_n103_), .C(new_n141_), .Y(new_n142_));
  AO21x1_ASAP7_75t_R   g052(.A1(new_n104_), .A2(new_n125_), .B(new_n142_), .Y(o0));
  INVx1_ASAP7_75t_R    g053(.A(p51), .Y(new_n144_));
  INVx1_ASAP7_75t_R    g054(.A(p55), .Y(new_n145_));
  INVx1_ASAP7_75t_R    g055(.A(p50), .Y(new_n146_));
  AND3x1_ASAP7_75t_R   g056(.A(new_n144_), .B(new_n145_), .C(new_n146_), .Y(new_n147_));
  AO21x1_ASAP7_75t_R   g057(.A1(p46), .A2(p45), .B(p47), .Y(new_n148_));
  NOR2x1_ASAP7_75t_R   g058(.A(p42), .B(p41), .Y(new_n149_));
  OAI21x1_ASAP7_75t_R  g059(.A1(p39), .A2(p38), .B(p40), .Y(new_n150_));
  NAND3x1_ASAP7_75t_R  g060(.A(p44), .B(p46), .C(p43), .Y(new_n151_));
  AOI21x1_ASAP7_75t_R  g061(.A1(new_n149_), .A2(new_n150_), .B(new_n151_), .Y(new_n152_));
  AND2x2_ASAP7_75t_R   g062(.A(p49), .B(p48), .Y(new_n153_));
  OAI21x1_ASAP7_75t_R  g063(.A1(new_n148_), .A2(new_n152_), .B(new_n153_), .Y(new_n154_));
  AND3x1_ASAP7_75t_R   g064(.A(p52), .B(p53), .C(p54), .Y(new_n155_));
  AND3x1_ASAP7_75t_R   g065(.A(p58), .B(p56), .C(p57), .Y(new_n156_));
  OAI21x1_ASAP7_75t_R  g066(.A1(p55), .A2(new_n155_), .B(new_n156_), .Y(new_n157_));
  AO21x1_ASAP7_75t_R   g067(.A1(new_n147_), .A2(new_n154_), .B(new_n157_), .Y(new_n158_));
  OR2x4_ASAP7_75t_R    g068(.A(p59), .B(p50), .Y(new_n159_));
  INVx1_ASAP7_75t_R    g069(.A(p52), .Y(new_n160_));
  OA21x2_ASAP7_75t_R   g070(.A1(new_n160_), .A2(p51), .B(new_n154_), .Y(new_n161_));
  NAND2x1_ASAP7_75t_R  g071(.A(p46), .B(p45), .Y(new_n162_));
  OAI21x1_ASAP7_75t_R  g072(.A1(p48), .A2(new_n162_), .B(new_n148_), .Y(new_n163_));
  NOR2x1_ASAP7_75t_R   g073(.A(p39), .B(p38), .Y(new_n164_));
  AND3x1_ASAP7_75t_R   g074(.A(new_n164_), .B(p53), .C(p54), .Y(new_n165_));
  OR2x4_ASAP7_75t_R    g075(.A(p48), .B(p47), .Y(new_n166_));
  AND4x2_ASAP7_75t_R   g076(.A(p36), .B(p33), .C(p46), .D(p34), .Y(new_n167_));
  AND4x2_ASAP7_75t_R   g077(.A(p37), .B(p44), .C(p49), .D(p40), .Y(new_n168_));
  AND5x1_ASAP7_75t_R   g078(.A(new_n163_), .B(new_n165_), .C(new_n166_), .D(new_n167_), .E(new_n168_), .Y(new_n169_));
  NAND2x1_ASAP7_75t_R  g079(.A(p42), .B(p41), .Y(new_n170_));
  NOR2x1_ASAP7_75t_R   g080(.A(new_n170_), .B(new_n150_), .Y(new_n171_));
  INVx1_ASAP7_75t_R    g081(.A(p43), .Y(new_n172_));
  AO21x1_ASAP7_75t_R   g082(.A1(new_n149_), .A2(new_n150_), .B(new_n172_), .Y(new_n173_));
  OA21x2_ASAP7_75t_R   g083(.A1(p43), .A2(new_n171_), .B(new_n173_), .Y(new_n174_));
  AND3x1_ASAP7_75t_R   g084(.A(new_n145_), .B(p30), .C(p35), .Y(new_n175_));
  INVx1_ASAP7_75t_R    g085(.A(p32), .Y(new_n176_));
  NOR2x1_ASAP7_75t_R   g086(.A(p45), .B(new_n176_), .Y(new_n177_));
  AND5x1_ASAP7_75t_R   g087(.A(p31), .B(new_n175_), .C(p29), .D(new_n156_), .E(new_n177_), .Y(new_n178_));
  NAND3x1_ASAP7_75t_R  g088(.A(new_n169_), .B(new_n174_), .C(new_n178_), .Y(new_n179_));
  AO211x2_ASAP7_75t_R  g089(.A1(new_n158_), .A2(new_n159_), .B(new_n161_), .C(new_n179_), .Y(new_n180_));
  OAI21x1_ASAP7_75t_R  g090(.A1(new_n103_), .A2(new_n141_), .B(new_n125_), .Y(new_n181_));
  OR2x4_ASAP7_75t_R    g091(.A(p59), .B(p29), .Y(new_n182_));
  AND2x2_ASAP7_75t_R   g092(.A(p44), .B(p43), .Y(new_n183_));
  INVx1_ASAP7_75t_R    g093(.A(new_n183_), .Y(new_n184_));
  OA21x2_ASAP7_75t_R   g094(.A1(p47), .A2(new_n183_), .B(new_n155_), .Y(new_n185_));
  OA21x2_ASAP7_75t_R   g095(.A1(p46), .A2(new_n184_), .B(new_n185_), .Y(new_n186_));
  INVx1_ASAP7_75t_R    g096(.A(p41), .Y(new_n187_));
  NAND2x1_ASAP7_75t_R  g097(.A(new_n187_), .B(new_n150_), .Y(new_n188_));
  INVx1_ASAP7_75t_R    g098(.A(p40), .Y(new_n189_));
  OR3x1_ASAP7_75t_R    g099(.A(new_n164_), .B(new_n189_), .C(new_n187_), .Y(new_n190_));
  NAND2x1_ASAP7_75t_R  g100(.A(p46), .B(p47), .Y(new_n191_));
  AND3x1_ASAP7_75t_R   g101(.A(new_n191_), .B(new_n144_), .C(new_n145_), .Y(new_n192_));
  AND5x1_ASAP7_75t_R   g102(.A(new_n188_), .B(new_n190_), .C(new_n192_), .D(new_n183_), .E(new_n153_), .Y(new_n193_));
  NOR2x1_ASAP7_75t_R   g103(.A(p45), .B(p39), .Y(new_n194_));
  INVx1_ASAP7_75t_R    g104(.A(p34), .Y(new_n195_));
  AND3x1_ASAP7_75t_R   g105(.A(new_n194_), .B(new_n195_), .C(new_n176_), .Y(new_n196_));
  NOR2x1_ASAP7_75t_R   g106(.A(p42), .B(p30), .Y(new_n197_));
  INVx1_ASAP7_75t_R    g107(.A(p31), .Y(new_n198_));
  AND3x1_ASAP7_75t_R   g108(.A(new_n197_), .B(p56), .C(new_n198_), .Y(new_n199_));
  NOR2x1_ASAP7_75t_R   g109(.A(p37), .B(new_n189_), .Y(new_n200_));
  NOR2x1_ASAP7_75t_R   g110(.A(p36), .B(p33), .Y(new_n201_));
  INVx1_ASAP7_75t_R    g111(.A(p35), .Y(new_n202_));
  AND3x1_ASAP7_75t_R   g112(.A(new_n146_), .B(new_n202_), .C(p38), .Y(new_n203_));
  AND5x1_ASAP7_75t_R   g113(.A(new_n196_), .B(new_n199_), .C(new_n200_), .D(new_n201_), .E(new_n203_), .Y(new_n204_));
  NAND3x1_ASAP7_75t_R  g114(.A(new_n186_), .B(new_n193_), .C(new_n204_), .Y(new_n205_));
  INVx1_ASAP7_75t_R    g115(.A(new_n158_), .Y(new_n206_));
  OAI21x1_ASAP7_75t_R  g116(.A1(new_n182_), .A2(new_n205_), .B(new_n206_), .Y(new_n207_));
  AO31x2_ASAP7_75t_R   g117(.A1(new_n180_), .A2(new_n181_), .A3(new_n207_), .B(new_n142_), .Y(o1));
  AND2x2_ASAP7_75t_R   g118(.A(p59), .B(p29), .Y(new_n209_));
  OAI21x1_ASAP7_75t_R  g119(.A1(new_n209_), .A2(new_n205_), .B(new_n206_), .Y(new_n210_));
  AOI211x1_ASAP7_75t_R g120(.A1(new_n125_), .A2(new_n104_), .B(new_n142_), .C(new_n210_), .Y(o2));
  assign               o3 = 1'b0;
  assign               o4 = 1'b0;
  assign               o5 = 1'b0;
  assign               o6 = 1'b0;
  assign               o7 = 1'b0;
  assign               o8 = 1'b0;
  assign               o9 = 1'b0;
  assign               o10 = 1'b0;
  assign               o11 = 1'b0;
  assign               o12 = 1'b0;
  assign               o13 = 1'b0;
  assign               o14 = 1'b0;
  assign               o15 = 1'b0;
  assign               o16 = 1'b0;
  assign               o17 = 1'b0;
  assign               o18 = 1'b0;
  assign               o19 = 1'b0;
  assign               o20 = 1'b0;
  assign               o21 = 1'b0;
  assign               o22 = 1'b0;
  assign               o23 = 1'b0;
  assign               o24 = 1'b0;
  assign               o25 = 1'b0;
  assign               o26 = 1'b0;
  assign               o27 = 1'b0;
  assign               o28 = 1'b0;
  assign               o29 = 1'b0;
endmodule


