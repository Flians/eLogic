// Benchmark "/tmp/" written by ABC on Tue Oct 20 18:11:45 2026

module \/tmp/  ( 
    p17, p49, p8, p20, p19, p23, p10, p3, p33, p30, p48, p27, p44, p40,
    p34, p0, p5, p36, p32, p16, p29, p9, p37, p14, p45, p59, p18, p28, p22,
    p6, p55, p39, p15, p35, p43, p57, p31, p24, p1, p21, p25, p52, p4, p42,
    p38, p12, p50, p51, p56, p47, p58, p41, p46, p53, p26, p11, p7, p13,
    p2, p54,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25, o26, o27, o28, o29  );
  input  p17, p49, p8, p20, p19, p23, p10, p3, p33, p30, p48, p27, p44,
    p40, p34, p0, p5, p36, p32, p16, p29, p9, p37, p14, p45, p59, p18, p28,
    p22, p6, p55, p39, p15, p35, p43, p57, p31, p24, p1, p21, p25, p52, p4,
    p42, p38, p12, p50, p51, p56, p47, p58, p41, p46, p53, p26, p11, p7,
    p13, p2, p54;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25, o26, o27, o28, o29;
  wire new_n91_, new_n92_, new_n93_, new_n94_, new_n95_, new_n96_, new_n97_,
    new_n98_, new_n99_, new_n100_, new_n101_, new_n102_, new_n103_,
    new_n104_, new_n105_, new_n106_, new_n107_, new_n108_, new_n109_,
    new_n110_, new_n111_, new_n112_, new_n113_, new_n114_, new_n115_,
    new_n116_, new_n117_, new_n118_, new_n119_, new_n120_, new_n121_,
    new_n122_, new_n123_, new_n124_, new_n125_, new_n126_, new_n127_,
    new_n128_, new_n129_, new_n130_, new_n131_, new_n132_, new_n133_,
    new_n134_, new_n135_, new_n136_, new_n137_, new_n138_, new_n139_,
    new_n140_, new_n141_, new_n142_, new_n143_, new_n144_, new_n145_,
    new_n146_, new_n148_, new_n149_, new_n150_, new_n151_, new_n152_,
    new_n153_, new_n154_, new_n155_, new_n156_, new_n157_, new_n158_,
    new_n159_, new_n160_, new_n161_, new_n162_, new_n163_, new_n164_,
    new_n165_, new_n166_, new_n167_, new_n168_, new_n169_, new_n170_,
    new_n171_, new_n172_, new_n173_, new_n174_, new_n175_, new_n176_,
    new_n177_, new_n178_, new_n179_, new_n180_, new_n181_, new_n182_,
    new_n183_, new_n184_, new_n185_, new_n186_, new_n187_, new_n188_,
    new_n189_, new_n190_, new_n191_, new_n192_, new_n193_, new_n194_,
    new_n195_, new_n196_, new_n197_, new_n198_, new_n199_, new_n200_,
    new_n201_, new_n202_, new_n203_, new_n204_, new_n205_, new_n206_,
    new_n207_, new_n208_, new_n209_, new_n210_, new_n211_, new_n212_,
    new_n213_, new_n214_, new_n215_, new_n216_, new_n217_, new_n218_,
    new_n219_, new_n221_, new_n222_, new_n223_, new_n224_, new_n225_,
    new_n226_, new_n227_, new_n228_, new_n229_, new_n230_, new_n231_,
    new_n232_, new_n233_, new_n234_, new_n235_, new_n236_, new_n237_,
    new_n238_;
  NOR2x1_ASAP7_75t_R   g000(.A(p20), .B(p21), .Y(new_n91_));
  NOR2x1_ASAP7_75t_R   g001(.A(p12), .B(p11), .Y(new_n92_));
  OAI21x1_ASAP7_75t_R  g002(.A1(p8), .A2(p9), .B(p10), .Y(new_n93_));
  NAND2x1_ASAP7_75t_R  g003(.A(p14), .B(p13), .Y(new_n94_));
  AOI21x1_ASAP7_75t_R  g004(.A1(new_n92_), .A2(new_n93_), .B(new_n94_), .Y(new_n95_));
  AO21x1_ASAP7_75t_R   g005(.A1(p16), .A2(p15), .B(p17), .Y(new_n96_));
  AOI21x1_ASAP7_75t_R  g006(.A1(p16), .A2(new_n95_), .B(new_n96_), .Y(new_n97_));
  AND2x2_ASAP7_75t_R   g007(.A(p23), .B(p24), .Y(new_n98_));
  INVx1_ASAP7_75t_R    g008(.A(new_n98_), .Y(new_n99_));
  NAND2x1_ASAP7_75t_R  g009(.A(p19), .B(p18), .Y(new_n100_));
  INVx1_ASAP7_75t_R    g010(.A(p22), .Y(new_n101_));
  AO21x1_ASAP7_75t_R   g011(.A1(new_n100_), .A2(new_n91_), .B(new_n101_), .Y(new_n102_));
  AOI211x1_ASAP7_75t_R g012(.A1(new_n91_), .A2(new_n97_), .B(new_n99_), .C(new_n102_), .Y(new_n103_));
  AND3x1_ASAP7_75t_R   g013(.A(p27), .B(p28), .C(p26), .Y(new_n104_));
  AND2x2_ASAP7_75t_R   g014(.A(p25), .B(new_n104_), .Y(new_n105_));
  NAND2x1_ASAP7_75t_R  g015(.A(p18), .B(p6), .Y(new_n106_));
  NOR2x1_ASAP7_75t_R   g016(.A(new_n94_), .B(new_n106_), .Y(new_n107_));
  NOR2x1_ASAP7_75t_R   g017(.A(p8), .B(p9), .Y(new_n108_));
  OR2x4_ASAP7_75t_R    g018(.A(p16), .B(p15), .Y(new_n109_));
  AND4x2_ASAP7_75t_R   g019(.A(p10), .B(p3), .C(p0), .D(p5), .Y(new_n110_));
  AND5x1_ASAP7_75t_R   g020(.A(new_n92_), .B(new_n107_), .C(new_n108_), .D(new_n109_), .E(new_n110_), .Y(new_n111_));
  INVx1_ASAP7_75t_R    g021(.A(p15), .Y(new_n112_));
  AND4x2_ASAP7_75t_R   g022(.A(p59), .B(p4), .C(p7), .D(p2), .Y(new_n113_));
  INVx1_ASAP7_75t_R    g023(.A(p25), .Y(new_n114_));
  AND5x1_ASAP7_75t_R   g024(.A(new_n112_), .B(new_n113_), .C(p24), .D(p1), .E(new_n114_), .Y(new_n115_));
  INVx1_ASAP7_75t_R    g025(.A(p23), .Y(new_n116_));
  OAI21x1_ASAP7_75t_R  g026(.A1(new_n101_), .A2(new_n91_), .B(new_n116_), .Y(new_n117_));
  AND2x2_ASAP7_75t_R   g027(.A(p19), .B(p22), .Y(new_n118_));
  AND3x1_ASAP7_75t_R   g028(.A(new_n104_), .B(new_n118_), .C(new_n91_), .Y(new_n119_));
  AND5x1_ASAP7_75t_R   g029(.A(new_n97_), .B(new_n111_), .C(new_n115_), .D(new_n117_), .E(new_n119_), .Y(new_n120_));
  AO211x2_ASAP7_75t_R  g030(.A1(new_n103_), .A2(new_n104_), .B(new_n105_), .C(new_n120_), .Y(new_n121_));
  AOI21x1_ASAP7_75t_R  g031(.A1(new_n91_), .A2(new_n97_), .B(new_n102_), .Y(new_n122_));
  NAND3x1_ASAP7_75t_R  g032(.A(new_n122_), .B(new_n104_), .C(new_n98_), .Y(new_n123_));
  INVx1_ASAP7_75t_R    g033(.A(new_n105_), .Y(new_n124_));
  OA21x2_ASAP7_75t_R   g034(.A1(p15), .A2(new_n95_), .B(p16), .Y(new_n125_));
  AND3x1_ASAP7_75t_R   g035(.A(new_n91_), .B(p19), .C(p22), .Y(new_n126_));
  NOR2x1_ASAP7_75t_R   g036(.A(p1), .B(p25), .Y(new_n127_));
  INVx1_ASAP7_75t_R    g037(.A(p6), .Y(new_n128_));
  AND3x1_ASAP7_75t_R   g038(.A(new_n127_), .B(p18), .C(new_n128_), .Y(new_n129_));
  NOR2x1_ASAP7_75t_R   g039(.A(p3), .B(p0), .Y(new_n130_));
  INVx1_ASAP7_75t_R    g040(.A(p5), .Y(new_n131_));
  INVx1_ASAP7_75t_R    g041(.A(p9), .Y(new_n132_));
  AND3x1_ASAP7_75t_R   g042(.A(new_n130_), .B(new_n131_), .C(new_n132_), .Y(new_n133_));
  NOR2x1_ASAP7_75t_R   g043(.A(p7), .B(p2), .Y(new_n134_));
  NOR2x1_ASAP7_75t_R   g044(.A(p4), .B(p12), .Y(new_n135_));
  AND5x1_ASAP7_75t_R   g045(.A(new_n126_), .B(new_n129_), .C(new_n133_), .D(new_n134_), .E(new_n135_), .Y(new_n136_));
  INVx1_ASAP7_75t_R    g046(.A(p17), .Y(new_n137_));
  INVx1_ASAP7_75t_R    g047(.A(p10), .Y(new_n138_));
  INVx1_ASAP7_75t_R    g048(.A(p11), .Y(new_n139_));
  AO21x1_ASAP7_75t_R   g049(.A1(new_n138_), .A2(new_n108_), .B(new_n139_), .Y(new_n140_));
  INVx1_ASAP7_75t_R    g050(.A(new_n94_), .Y(new_n141_));
  AND5x1_ASAP7_75t_R   g051(.A(new_n137_), .B(new_n140_), .C(p8), .D(new_n98_), .E(new_n141_), .Y(new_n142_));
  NAND2x1_ASAP7_75t_R  g052(.A(p15), .B(new_n95_), .Y(new_n143_));
  NAND2x1_ASAP7_75t_R  g053(.A(new_n139_), .B(new_n93_), .Y(new_n144_));
  AND5x1_ASAP7_75t_R   g054(.A(new_n125_), .B(new_n136_), .C(new_n142_), .D(new_n143_), .E(new_n144_), .Y(new_n145_));
  AO21x1_ASAP7_75t_R   g055(.A1(new_n123_), .A2(new_n124_), .B(new_n145_), .Y(new_n146_));
  NAND2x1_ASAP7_75t_R  g056(.A(new_n121_), .B(new_n146_), .Y(o0));
  AOI21x1_ASAP7_75t_R  g057(.A1(new_n124_), .A2(new_n123_), .B(new_n145_), .Y(new_n148_));
  AND2x2_ASAP7_75t_R   g058(.A(p49), .B(p48), .Y(new_n149_));
  INVx1_ASAP7_75t_R    g059(.A(new_n149_), .Y(new_n150_));
  NOR2x1_ASAP7_75t_R   g060(.A(p42), .B(p41), .Y(new_n151_));
  OAI21x1_ASAP7_75t_R  g061(.A1(p39), .A2(p38), .B(p40), .Y(new_n152_));
  NAND2x1_ASAP7_75t_R  g062(.A(p44), .B(p43), .Y(new_n153_));
  AOI21x1_ASAP7_75t_R  g063(.A1(new_n151_), .A2(new_n152_), .B(new_n153_), .Y(new_n154_));
  AO21x1_ASAP7_75t_R   g064(.A1(p45), .A2(p46), .B(p47), .Y(new_n155_));
  AOI21x1_ASAP7_75t_R  g065(.A1(p46), .A2(new_n154_), .B(new_n155_), .Y(new_n156_));
  INVx1_ASAP7_75t_R    g066(.A(p51), .Y(new_n157_));
  NAND2x1_ASAP7_75t_R  g067(.A(p52), .B(new_n157_), .Y(new_n158_));
  OAI21x1_ASAP7_75t_R  g068(.A1(new_n150_), .A2(new_n156_), .B(new_n158_), .Y(new_n159_));
  AND2x2_ASAP7_75t_R   g069(.A(p40), .B(p32), .Y(new_n160_));
  AND2x2_ASAP7_75t_R   g070(.A(p49), .B(p33), .Y(new_n161_));
  AND2x2_ASAP7_75t_R   g071(.A(p30), .B(p44), .Y(new_n162_));
  AND5x1_ASAP7_75t_R   g072(.A(p34), .B(new_n160_), .C(new_n161_), .D(new_n162_), .E(p36), .Y(new_n163_));
  AND3x1_ASAP7_75t_R   g073(.A(p57), .B(p56), .C(p58), .Y(new_n164_));
  AND3x1_ASAP7_75t_R   g074(.A(p35), .B(p31), .C(p46), .Y(new_n165_));
  AND2x2_ASAP7_75t_R   g075(.A(p29), .B(p37), .Y(new_n166_));
  NOR2x1_ASAP7_75t_R   g076(.A(p45), .B(p55), .Y(new_n167_));
  AND4x2_ASAP7_75t_R   g077(.A(new_n164_), .B(new_n165_), .C(new_n166_), .D(new_n167_), .Y(new_n168_));
  INVx1_ASAP7_75t_R    g078(.A(p48), .Y(new_n169_));
  INVx1_ASAP7_75t_R    g079(.A(p47), .Y(new_n170_));
  NAND2x1_ASAP7_75t_R  g080(.A(p53), .B(p54), .Y(new_n171_));
  INVx1_ASAP7_75t_R    g081(.A(p39), .Y(new_n172_));
  INVx1_ASAP7_75t_R    g082(.A(p38), .Y(new_n173_));
  NAND2x1_ASAP7_75t_R  g083(.A(new_n172_), .B(new_n173_), .Y(new_n174_));
  AOI211x1_ASAP7_75t_R g084(.A1(new_n169_), .A2(new_n170_), .B(new_n171_), .C(new_n174_), .Y(new_n175_));
  NAND2x1_ASAP7_75t_R  g085(.A(p45), .B(p46), .Y(new_n176_));
  OAI21x1_ASAP7_75t_R  g086(.A1(p48), .A2(new_n176_), .B(new_n155_), .Y(new_n177_));
  AND4x2_ASAP7_75t_R   g087(.A(new_n163_), .B(new_n168_), .C(new_n175_), .D(new_n177_), .Y(new_n178_));
  NAND2x1_ASAP7_75t_R  g088(.A(new_n151_), .B(new_n152_), .Y(new_n179_));
  INVx1_ASAP7_75t_R    g089(.A(p41), .Y(new_n180_));
  NOR2x1_ASAP7_75t_R   g090(.A(new_n180_), .B(new_n152_), .Y(new_n181_));
  AOI21x1_ASAP7_75t_R  g091(.A1(p42), .A2(new_n181_), .B(p43), .Y(new_n182_));
  AOI21x1_ASAP7_75t_R  g092(.A1(p43), .A2(new_n179_), .B(new_n182_), .Y(new_n183_));
  NAND3x1_ASAP7_75t_R  g093(.A(new_n159_), .B(new_n178_), .C(new_n183_), .Y(new_n184_));
  AND3x1_ASAP7_75t_R   g094(.A(p52), .B(p53), .C(p54), .Y(new_n185_));
  OA21x2_ASAP7_75t_R   g095(.A1(p55), .A2(new_n185_), .B(new_n164_), .Y(new_n186_));
  INVx1_ASAP7_75t_R    g096(.A(p55), .Y(new_n187_));
  INVx1_ASAP7_75t_R    g097(.A(p50), .Y(new_n188_));
  AND3x1_ASAP7_75t_R   g098(.A(new_n187_), .B(new_n188_), .C(new_n157_), .Y(new_n189_));
  OAI21x1_ASAP7_75t_R  g099(.A1(new_n150_), .A2(new_n156_), .B(new_n189_), .Y(new_n190_));
  NOR2x1_ASAP7_75t_R   g100(.A(p59), .B(p50), .Y(new_n191_));
  AOI21x1_ASAP7_75t_R  g101(.A1(new_n186_), .A2(new_n190_), .B(new_n191_), .Y(new_n192_));
  INVx1_ASAP7_75t_R    g102(.A(p40), .Y(new_n193_));
  OR3x1_ASAP7_75t_R    g103(.A(new_n153_), .B(new_n193_), .C(p36), .Y(new_n194_));
  OR4x2_ASAP7_75t_R    g104(.A(p37), .B(p45), .C(p55), .D(p39), .Y(new_n195_));
  NOR2x1_ASAP7_75t_R   g105(.A(p42), .B(p50), .Y(new_n196_));
  NAND3x1_ASAP7_75t_R  g106(.A(new_n196_), .B(p38), .C(p56), .Y(new_n197_));
  NOR3x1_ASAP7_75t_R   g107(.A(new_n194_), .B(new_n195_), .C(new_n197_), .Y(new_n198_));
  NOR2x1_ASAP7_75t_R   g108(.A(p33), .B(p30), .Y(new_n199_));
  NAND3x1_ASAP7_75t_R  g109(.A(new_n199_), .B(p53), .C(p54), .Y(new_n200_));
  NAND2x1_ASAP7_75t_R  g110(.A(p47), .B(p46), .Y(new_n201_));
  NAND2x1_ASAP7_75t_R  g111(.A(new_n201_), .B(new_n149_), .Y(new_n202_));
  AOI211x1_ASAP7_75t_R g112(.A1(new_n180_), .A2(new_n152_), .B(new_n200_), .C(new_n202_), .Y(new_n203_));
  OR4x2_ASAP7_75t_R    g113(.A(p34), .B(p32), .C(p35), .D(p31), .Y(new_n204_));
  NOR3x1_ASAP7_75t_R   g114(.A(new_n181_), .B(new_n204_), .C(new_n158_), .Y(new_n205_));
  NAND3x1_ASAP7_75t_R  g115(.A(new_n198_), .B(new_n203_), .C(new_n205_), .Y(new_n206_));
  OR2x4_ASAP7_75t_R    g116(.A(p45), .B(new_n170_), .Y(new_n207_));
  NOR2x1_ASAP7_75t_R   g117(.A(new_n154_), .B(new_n207_), .Y(new_n208_));
  INVx1_ASAP7_75t_R    g118(.A(new_n176_), .Y(new_n209_));
  AO21x1_ASAP7_75t_R   g119(.A1(p46), .A2(new_n154_), .B(new_n209_), .Y(new_n210_));
  NOR2x1_ASAP7_75t_R   g120(.A(p29), .B(p59), .Y(new_n211_));
  OAI21x1_ASAP7_75t_R  g121(.A1(new_n208_), .A2(new_n210_), .B(new_n211_), .Y(new_n212_));
  INVx1_ASAP7_75t_R    g122(.A(p46), .Y(new_n213_));
  AOI211x1_ASAP7_75t_R g123(.A1(new_n151_), .A2(new_n152_), .B(new_n213_), .C(new_n153_), .Y(new_n214_));
  OAI21x1_ASAP7_75t_R  g124(.A1(new_n155_), .A2(new_n214_), .B(new_n149_), .Y(new_n215_));
  INVx1_ASAP7_75t_R    g125(.A(new_n186_), .Y(new_n216_));
  AOI21x1_ASAP7_75t_R  g126(.A1(new_n189_), .A2(new_n215_), .B(new_n216_), .Y(new_n217_));
  OAI21x1_ASAP7_75t_R  g127(.A1(new_n206_), .A2(new_n212_), .B(new_n217_), .Y(new_n218_));
  OAI21x1_ASAP7_75t_R  g128(.A1(new_n184_), .A2(new_n192_), .B(new_n218_), .Y(new_n219_));
  OAI21x1_ASAP7_75t_R  g129(.A1(new_n148_), .A2(new_n219_), .B(new_n121_), .Y(o1));
  AND3x1_ASAP7_75t_R   g130(.A(new_n157_), .B(p38), .C(p56), .Y(new_n221_));
  INVx1_ASAP7_75t_R    g131(.A(p35), .Y(new_n222_));
  NOR2x1_ASAP7_75t_R   g132(.A(p31), .B(p42), .Y(new_n223_));
  AND5x1_ASAP7_75t_R   g133(.A(new_n172_), .B(new_n221_), .C(new_n222_), .D(new_n185_), .E(new_n223_), .Y(new_n224_));
  NAND2x1_ASAP7_75t_R  g134(.A(new_n180_), .B(new_n152_), .Y(new_n225_));
  INVx1_ASAP7_75t_R    g135(.A(new_n181_), .Y(new_n226_));
  INVx1_ASAP7_75t_R    g136(.A(new_n153_), .Y(new_n227_));
  AND5x1_ASAP7_75t_R   g137(.A(new_n187_), .B(new_n227_), .C(new_n149_), .D(new_n188_), .E(new_n201_), .Y(new_n228_));
  NOR2x1_ASAP7_75t_R   g138(.A(p36), .B(p32), .Y(new_n229_));
  NOR2x1_ASAP7_75t_R   g139(.A(p37), .B(p45), .Y(new_n230_));
  INVx1_ASAP7_75t_R    g140(.A(p34), .Y(new_n231_));
  AND5x1_ASAP7_75t_R   g141(.A(p40), .B(new_n229_), .C(new_n230_), .D(new_n199_), .E(new_n231_), .Y(new_n232_));
  AND5x1_ASAP7_75t_R   g142(.A(new_n224_), .B(new_n225_), .C(new_n226_), .D(new_n228_), .E(new_n232_), .Y(new_n233_));
  OR3x1_ASAP7_75t_R    g143(.A(new_n208_), .B(new_n209_), .C(new_n214_), .Y(new_n234_));
  NAND2x1_ASAP7_75t_R  g144(.A(p29), .B(p59), .Y(new_n235_));
  AO21x1_ASAP7_75t_R   g145(.A1(new_n189_), .A2(new_n215_), .B(new_n216_), .Y(new_n236_));
  AO31x2_ASAP7_75t_R   g146(.A1(new_n233_), .A2(new_n234_), .A3(new_n235_), .B(new_n236_), .Y(new_n237_));
  AOI211x1_ASAP7_75t_R g147(.A1(new_n104_), .A2(new_n103_), .B(new_n105_), .C(new_n120_), .Y(new_n238_));
  NOR3x1_ASAP7_75t_R   g148(.A(new_n148_), .B(new_n237_), .C(new_n238_), .Y(o2));
  assign               o3 = 1'b0;
  assign               o4 = 1'b0;
  assign               o5 = 1'b0;
  assign               o6 = 1'b0;
  assign               o7 = 1'b0;
  assign               o8 = 1'b0;
  assign               o9 = 1'b0;
  assign               o10 = 1'b0;
  assign               o11 = 1'b0;
  assign               o12 = 1'b0;
  assign               o13 = 1'b0;
  assign               o14 = 1'b0;
  assign               o15 = 1'b0;
  assign               o16 = 1'b0;
  assign               o17 = 1'b0;
  assign               o18 = 1'b0;
  assign               o19 = 1'b0;
  assign               o20 = 1'b0;
  assign               o21 = 1'b0;
  assign               o22 = 1'b0;
  assign               o23 = 1'b0;
  assign               o24 = 1'b0;
  assign               o25 = 1'b0;
  assign               o26 = 1'b0;
  assign               o27 = 1'b0;
  assign               o28 = 1'b0;
  assign               o29 = 1'b0;
endmodule


