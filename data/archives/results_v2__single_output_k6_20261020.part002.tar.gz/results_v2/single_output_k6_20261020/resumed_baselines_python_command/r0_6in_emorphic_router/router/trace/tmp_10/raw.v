// Benchmark "/tmp/" written by ABC on Tue Oct 20 18:11:45 2026

module \/tmp/  ( 
    p0, p40, p20, p16, p15, p54, p7, p2, p25, p5, p57, p41, p8, p24, p9,
    p39, p51, p19, p55, p56, p31, p3, p47, p37, p4, p12, p29, p26, p11,
    p14, p22, p59, p49, p30, p52, p17, p32, p1, p43, p6, p34, p44, p50,
    p58, p42, p35, p13, p33, p36, p21, p38, p53, p27, p18, p45, p46, p28,
    p10, p48, p23,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25, o26, o27, o28, o29  );
  input  p0, p40, p20, p16, p15, p54, p7, p2, p25, p5, p57, p41, p8, p24,
    p9, p39, p51, p19, p55, p56, p31, p3, p47, p37, p4, p12, p29, p26, p11,
    p14, p22, p59, p49, p30, p52, p17, p32, p1, p43, p6, p34, p44, p50,
    p58, p42, p35, p13, p33, p36, p21, p38, p53, p27, p18, p45, p46, p28,
    p10, p48, p23;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25, o26, o27, o28, o29;
  wire new_n91_, new_n92_, new_n93_, new_n94_, new_n95_, new_n96_, new_n97_,
    new_n98_, new_n99_, new_n100_, new_n101_, new_n102_, new_n103_,
    new_n104_, new_n105_, new_n106_, new_n107_, new_n108_, new_n109_,
    new_n110_, new_n111_, new_n112_, new_n113_, new_n114_, new_n115_,
    new_n116_, new_n117_, new_n118_, new_n119_, new_n120_, new_n121_,
    new_n122_, new_n123_, new_n124_, new_n125_, new_n126_, new_n127_,
    new_n128_, new_n129_, new_n130_, new_n131_, new_n132_, new_n133_,
    new_n134_, new_n135_, new_n136_, new_n137_, new_n138_, new_n139_,
    new_n140_, new_n141_, new_n143_, new_n144_, new_n145_, new_n146_,
    new_n147_, new_n148_, new_n149_, new_n150_, new_n151_, new_n152_,
    new_n153_, new_n154_, new_n155_, new_n156_, new_n157_, new_n158_,
    new_n159_, new_n160_, new_n161_, new_n162_, new_n163_, new_n164_,
    new_n165_, new_n166_, new_n167_, new_n168_, new_n169_, new_n170_,
    new_n171_, new_n172_, new_n173_, new_n174_, new_n175_, new_n176_,
    new_n177_, new_n178_, new_n179_, new_n180_, new_n181_, new_n182_,
    new_n183_, new_n184_, new_n185_, new_n186_, new_n187_, new_n188_,
    new_n189_, new_n190_, new_n191_, new_n192_, new_n193_, new_n194_,
    new_n195_, new_n196_, new_n197_, new_n198_, new_n199_, new_n200_,
    new_n201_, new_n202_, new_n203_, new_n204_, new_n205_, new_n206_,
    new_n207_, new_n208_, new_n209_, new_n210_, new_n211_, new_n212_,
    new_n213_, new_n214_, new_n215_, new_n217_, new_n218_, new_n219_,
    new_n220_, new_n221_, new_n222_, new_n223_, new_n224_, new_n225_,
    new_n226_, new_n227_, new_n228_, new_n229_, new_n230_, new_n231_,
    new_n232_, new_n233_, new_n234_, new_n235_, new_n236_, new_n237_,
    new_n238_;
  AND3x1_ASAP7_75t_R   g000(.A(p26), .B(p27), .C(p28), .Y(new_n91_));
  AND2x2_ASAP7_75t_R   g001(.A(p25), .B(new_n91_), .Y(new_n92_));
  INVx1_ASAP7_75t_R    g002(.A(new_n92_), .Y(new_n93_));
  NOR2x1_ASAP7_75t_R   g003(.A(p20), .B(p21), .Y(new_n94_));
  NOR2x1_ASAP7_75t_R   g004(.A(p12), .B(p11), .Y(new_n95_));
  OAI21x1_ASAP7_75t_R  g005(.A1(p8), .A2(p9), .B(p10), .Y(new_n96_));
  NAND2x1_ASAP7_75t_R  g006(.A(p14), .B(p13), .Y(new_n97_));
  AOI21x1_ASAP7_75t_R  g007(.A1(new_n95_), .A2(new_n96_), .B(new_n97_), .Y(new_n98_));
  AO21x1_ASAP7_75t_R   g008(.A1(p16), .A2(p15), .B(p17), .Y(new_n99_));
  AOI21x1_ASAP7_75t_R  g009(.A1(p16), .A2(new_n98_), .B(new_n99_), .Y(new_n100_));
  NAND2x1_ASAP7_75t_R  g010(.A(p19), .B(p18), .Y(new_n101_));
  INVx1_ASAP7_75t_R    g011(.A(p22), .Y(new_n102_));
  AO21x1_ASAP7_75t_R   g012(.A1(new_n101_), .A2(new_n94_), .B(new_n102_), .Y(new_n103_));
  AOI21x1_ASAP7_75t_R  g013(.A1(new_n94_), .A2(new_n100_), .B(new_n103_), .Y(new_n104_));
  AND2x2_ASAP7_75t_R   g014(.A(p24), .B(p23), .Y(new_n105_));
  NAND3x1_ASAP7_75t_R  g015(.A(new_n104_), .B(new_n91_), .C(new_n105_), .Y(new_n106_));
  OR2x4_ASAP7_75t_R    g016(.A(p15), .B(new_n98_), .Y(new_n107_));
  NOR2x1_ASAP7_75t_R   g017(.A(p3), .B(p4), .Y(new_n108_));
  NOR2x1_ASAP7_75t_R   g018(.A(p25), .B(p5), .Y(new_n109_));
  INVx1_ASAP7_75t_R    g019(.A(p9), .Y(new_n110_));
  AND5x1_ASAP7_75t_R   g020(.A(p8), .B(new_n95_), .C(new_n108_), .D(new_n109_), .E(new_n110_), .Y(new_n111_));
  INVx1_ASAP7_75t_R    g021(.A(p14), .Y(new_n112_));
  INVx1_ASAP7_75t_R    g022(.A(p13), .Y(new_n113_));
  AO21x1_ASAP7_75t_R   g023(.A1(new_n95_), .A2(new_n96_), .B(new_n113_), .Y(new_n114_));
  INVx1_ASAP7_75t_R    g024(.A(p15), .Y(new_n115_));
  AO21x1_ASAP7_75t_R   g025(.A1(new_n112_), .A2(new_n114_), .B(new_n115_), .Y(new_n116_));
  NOR2x1_ASAP7_75t_R   g026(.A(p6), .B(new_n113_), .Y(new_n117_));
  AND3x1_ASAP7_75t_R   g027(.A(p19), .B(p22), .C(p10), .Y(new_n118_));
  NOR2x1_ASAP7_75t_R   g028(.A(p17), .B(p1), .Y(new_n119_));
  AND5x1_ASAP7_75t_R   g029(.A(p18), .B(new_n117_), .C(new_n94_), .D(new_n118_), .E(new_n119_), .Y(new_n120_));
  INVx1_ASAP7_75t_R    g030(.A(p0), .Y(new_n121_));
  NOR2x1_ASAP7_75t_R   g031(.A(p7), .B(p2), .Y(new_n122_));
  AND5x1_ASAP7_75t_R   g032(.A(new_n121_), .B(new_n122_), .C(p16), .D(p24), .E(p23), .Y(new_n123_));
  AND5x1_ASAP7_75t_R   g033(.A(new_n107_), .B(new_n111_), .C(new_n116_), .D(new_n120_), .E(new_n123_), .Y(new_n124_));
  AO21x1_ASAP7_75t_R   g034(.A1(new_n93_), .A2(new_n106_), .B(new_n124_), .Y(new_n125_));
  INVx1_ASAP7_75t_R    g035(.A(new_n105_), .Y(new_n126_));
  AOI211x1_ASAP7_75t_R g036(.A1(new_n94_), .A2(new_n100_), .B(new_n126_), .C(new_n103_), .Y(new_n127_));
  INVx1_ASAP7_75t_R    g037(.A(p8), .Y(new_n128_));
  AND5x1_ASAP7_75t_R   g038(.A(p0), .B(new_n95_), .C(new_n115_), .D(new_n128_), .E(new_n110_), .Y(new_n129_));
  AND2x2_ASAP7_75t_R   g039(.A(p24), .B(p3), .Y(new_n130_));
  AND3x1_ASAP7_75t_R   g040(.A(new_n130_), .B(p4), .C(p14), .Y(new_n131_));
  INVx1_ASAP7_75t_R    g041(.A(p25), .Y(new_n132_));
  AND4x2_ASAP7_75t_R   g042(.A(new_n132_), .B(p7), .C(p2), .D(p5), .Y(new_n133_));
  AND3x1_ASAP7_75t_R   g043(.A(new_n129_), .B(new_n131_), .C(new_n133_), .Y(new_n134_));
  INVx1_ASAP7_75t_R    g044(.A(p23), .Y(new_n135_));
  OAI21x1_ASAP7_75t_R  g045(.A1(new_n102_), .A2(new_n94_), .B(new_n135_), .Y(new_n136_));
  OR3x1_ASAP7_75t_R    g046(.A(new_n98_), .B(p16), .C(p15), .Y(new_n137_));
  AND4x2_ASAP7_75t_R   g047(.A(p59), .B(p1), .C(p6), .D(p13), .Y(new_n138_));
  AND5x1_ASAP7_75t_R   g048(.A(p18), .B(new_n138_), .C(new_n91_), .D(new_n94_), .E(new_n118_), .Y(new_n139_));
  AND5x1_ASAP7_75t_R   g049(.A(new_n100_), .B(new_n134_), .C(new_n136_), .D(new_n137_), .E(new_n139_), .Y(new_n140_));
  AO211x2_ASAP7_75t_R  g050(.A1(new_n91_), .A2(new_n127_), .B(new_n92_), .C(new_n140_), .Y(new_n141_));
  NAND2x1_ASAP7_75t_R  g051(.A(new_n125_), .B(new_n141_), .Y(o0));
  AOI21x1_ASAP7_75t_R  g052(.A1(new_n93_), .A2(new_n106_), .B(new_n124_), .Y(new_n143_));
  NAND2x1_ASAP7_75t_R  g053(.A(p49), .B(p48), .Y(new_n144_));
  NOR2x1_ASAP7_75t_R   g054(.A(p41), .B(p42), .Y(new_n145_));
  OAI21x1_ASAP7_75t_R  g055(.A1(p39), .A2(p38), .B(p40), .Y(new_n146_));
  NAND2x1_ASAP7_75t_R  g056(.A(p43), .B(p44), .Y(new_n147_));
  AOI21x1_ASAP7_75t_R  g057(.A1(new_n145_), .A2(new_n146_), .B(new_n147_), .Y(new_n148_));
  AO21x1_ASAP7_75t_R   g058(.A1(p45), .A2(p46), .B(p47), .Y(new_n149_));
  AOI21x1_ASAP7_75t_R  g059(.A1(p46), .A2(new_n148_), .B(new_n149_), .Y(new_n150_));
  INVx1_ASAP7_75t_R    g060(.A(p51), .Y(new_n151_));
  INVx1_ASAP7_75t_R    g061(.A(p55), .Y(new_n152_));
  INVx1_ASAP7_75t_R    g062(.A(p50), .Y(new_n153_));
  AND3x1_ASAP7_75t_R   g063(.A(new_n151_), .B(new_n152_), .C(new_n153_), .Y(new_n154_));
  OAI21x1_ASAP7_75t_R  g064(.A1(new_n144_), .A2(new_n150_), .B(new_n154_), .Y(new_n155_));
  AND3x1_ASAP7_75t_R   g065(.A(p54), .B(p52), .C(p53), .Y(new_n156_));
  AND3x1_ASAP7_75t_R   g066(.A(p57), .B(p56), .C(p58), .Y(new_n157_));
  OA21x2_ASAP7_75t_R   g067(.A1(p55), .A2(new_n156_), .B(new_n157_), .Y(new_n158_));
  INVx1_ASAP7_75t_R    g068(.A(p59), .Y(new_n159_));
  AOI22x1_ASAP7_75t_R  g069(.A1(new_n155_), .A2(new_n158_), .B1(new_n159_), .B2(new_n153_), .Y(new_n160_));
  AND2x2_ASAP7_75t_R   g070(.A(p54), .B(p53), .Y(new_n161_));
  AND3x1_ASAP7_75t_R   g071(.A(new_n161_), .B(p40), .C(new_n152_), .Y(new_n162_));
  AND4x2_ASAP7_75t_R   g072(.A(p29), .B(p49), .C(p30), .D(p32), .Y(new_n163_));
  AND2x2_ASAP7_75t_R   g073(.A(p34), .B(p44), .Y(new_n164_));
  AND2x2_ASAP7_75t_R   g074(.A(p35), .B(p33), .Y(new_n165_));
  AND3x1_ASAP7_75t_R   g075(.A(new_n163_), .B(new_n164_), .C(new_n165_), .Y(new_n166_));
  NOR2x1_ASAP7_75t_R   g076(.A(p39), .B(p38), .Y(new_n167_));
  INVx1_ASAP7_75t_R    g077(.A(new_n167_), .Y(new_n168_));
  NOR2x1_ASAP7_75t_R   g078(.A(p47), .B(p48), .Y(new_n169_));
  NAND2x1_ASAP7_75t_R  g079(.A(p31), .B(p37), .Y(new_n170_));
  NOR3x1_ASAP7_75t_R   g080(.A(new_n168_), .B(new_n169_), .C(new_n170_), .Y(new_n171_));
  INVx1_ASAP7_75t_R    g081(.A(p45), .Y(new_n172_));
  AND4x2_ASAP7_75t_R   g082(.A(new_n157_), .B(p36), .C(new_n172_), .D(p46), .Y(new_n173_));
  NAND2x1_ASAP7_75t_R  g083(.A(p45), .B(p46), .Y(new_n174_));
  OAI21x1_ASAP7_75t_R  g084(.A1(p48), .A2(new_n174_), .B(new_n149_), .Y(new_n175_));
  AND5x1_ASAP7_75t_R   g085(.A(new_n162_), .B(new_n166_), .C(new_n171_), .D(new_n173_), .E(new_n175_), .Y(new_n176_));
  NAND2x1_ASAP7_75t_R  g086(.A(p52), .B(new_n151_), .Y(new_n177_));
  OAI21x1_ASAP7_75t_R  g087(.A1(new_n144_), .A2(new_n150_), .B(new_n177_), .Y(new_n178_));
  INVx1_ASAP7_75t_R    g088(.A(p41), .Y(new_n179_));
  NOR2x1_ASAP7_75t_R   g089(.A(new_n179_), .B(new_n146_), .Y(new_n180_));
  AOI21x1_ASAP7_75t_R  g090(.A1(p42), .A2(new_n180_), .B(p43), .Y(new_n181_));
  NAND2x1_ASAP7_75t_R  g091(.A(new_n179_), .B(new_n146_), .Y(new_n182_));
  OA21x2_ASAP7_75t_R   g092(.A1(p42), .A2(new_n182_), .B(p43), .Y(new_n183_));
  NOR2x1_ASAP7_75t_R   g093(.A(new_n181_), .B(new_n183_), .Y(new_n184_));
  NAND3x1_ASAP7_75t_R  g094(.A(new_n176_), .B(new_n178_), .C(new_n184_), .Y(new_n185_));
  INVx1_ASAP7_75t_R    g095(.A(new_n144_), .Y(new_n186_));
  NAND2x1_ASAP7_75t_R  g096(.A(p47), .B(p46), .Y(new_n187_));
  NOR2x1_ASAP7_75t_R   g097(.A(p31), .B(p30), .Y(new_n188_));
  AND5x1_ASAP7_75t_R   g098(.A(new_n182_), .B(new_n186_), .C(new_n161_), .D(new_n187_), .E(new_n188_), .Y(new_n189_));
  INVx1_ASAP7_75t_R    g099(.A(p56), .Y(new_n190_));
  OR3x1_ASAP7_75t_R    g100(.A(new_n147_), .B(new_n190_), .C(p50), .Y(new_n191_));
  NOR2x1_ASAP7_75t_R   g101(.A(p39), .B(p37), .Y(new_n192_));
  NAND3x1_ASAP7_75t_R  g102(.A(new_n192_), .B(p40), .C(new_n152_), .Y(new_n193_));
  NOR2x1_ASAP7_75t_R   g103(.A(p36), .B(p45), .Y(new_n194_));
  INVx1_ASAP7_75t_R    g104(.A(p42), .Y(new_n195_));
  NAND3x1_ASAP7_75t_R  g105(.A(new_n194_), .B(new_n195_), .C(p38), .Y(new_n196_));
  NOR3x1_ASAP7_75t_R   g106(.A(new_n191_), .B(new_n193_), .C(new_n196_), .Y(new_n197_));
  NOR2x1_ASAP7_75t_R   g107(.A(p34), .B(p35), .Y(new_n198_));
  NOR2x1_ASAP7_75t_R   g108(.A(p32), .B(p33), .Y(new_n199_));
  NAND2x1_ASAP7_75t_R  g109(.A(new_n198_), .B(new_n199_), .Y(new_n200_));
  NOR3x1_ASAP7_75t_R   g110(.A(new_n180_), .B(new_n200_), .C(new_n177_), .Y(new_n201_));
  NAND3x1_ASAP7_75t_R  g111(.A(new_n189_), .B(new_n197_), .C(new_n201_), .Y(new_n202_));
  NAND2x1_ASAP7_75t_R  g112(.A(p47), .B(new_n172_), .Y(new_n203_));
  NOR2x1_ASAP7_75t_R   g113(.A(new_n203_), .B(new_n148_), .Y(new_n204_));
  INVx1_ASAP7_75t_R    g114(.A(new_n174_), .Y(new_n205_));
  AO21x1_ASAP7_75t_R   g115(.A1(p46), .A2(new_n148_), .B(new_n205_), .Y(new_n206_));
  NOR2x1_ASAP7_75t_R   g116(.A(p29), .B(p59), .Y(new_n207_));
  OAI21x1_ASAP7_75t_R  g117(.A1(new_n204_), .A2(new_n206_), .B(new_n207_), .Y(new_n208_));
  INVx1_ASAP7_75t_R    g118(.A(p46), .Y(new_n209_));
  AOI211x1_ASAP7_75t_R g119(.A1(new_n145_), .A2(new_n146_), .B(new_n209_), .C(new_n147_), .Y(new_n210_));
  OAI21x1_ASAP7_75t_R  g120(.A1(new_n149_), .A2(new_n210_), .B(new_n186_), .Y(new_n211_));
  INVx1_ASAP7_75t_R    g121(.A(new_n158_), .Y(new_n212_));
  AOI21x1_ASAP7_75t_R  g122(.A1(new_n154_), .A2(new_n211_), .B(new_n212_), .Y(new_n213_));
  OAI21x1_ASAP7_75t_R  g123(.A1(new_n202_), .A2(new_n208_), .B(new_n213_), .Y(new_n214_));
  OAI21x1_ASAP7_75t_R  g124(.A1(new_n160_), .A2(new_n185_), .B(new_n214_), .Y(new_n215_));
  OAI21x1_ASAP7_75t_R  g125(.A1(new_n143_), .A2(new_n215_), .B(new_n141_), .Y(o1));
  AOI211x1_ASAP7_75t_R g126(.A1(new_n91_), .A2(new_n127_), .B(new_n92_), .C(new_n140_), .Y(new_n217_));
  NOR2x1_ASAP7_75t_R   g127(.A(p45), .B(new_n148_), .Y(new_n218_));
  OAI22x1_ASAP7_75t_R  g128(.A1(new_n218_), .A2(new_n209_), .B1(new_n148_), .B2(new_n203_), .Y(new_n219_));
  AND5x1_ASAP7_75t_R   g129(.A(p54), .B(new_n198_), .C(new_n199_), .D(new_n188_), .E(p53), .Y(new_n220_));
  INVx1_ASAP7_75t_R    g130(.A(p40), .Y(new_n221_));
  OR3x1_ASAP7_75t_R    g131(.A(new_n167_), .B(new_n221_), .C(new_n179_), .Y(new_n222_));
  NOR2x1_ASAP7_75t_R   g132(.A(new_n144_), .B(new_n177_), .Y(new_n223_));
  AND5x1_ASAP7_75t_R   g133(.A(new_n182_), .B(new_n220_), .C(new_n222_), .D(new_n223_), .E(new_n187_), .Y(new_n224_));
  NOR2x1_ASAP7_75t_R   g134(.A(p50), .B(p45), .Y(new_n225_));
  AND3x1_ASAP7_75t_R   g135(.A(new_n225_), .B(new_n152_), .C(p56), .Y(new_n226_));
  NOR3x1_ASAP7_75t_R   g136(.A(new_n147_), .B(new_n221_), .C(p42), .Y(new_n227_));
  INVx1_ASAP7_75t_R    g137(.A(p38), .Y(new_n228_));
  NOR2x1_ASAP7_75t_R   g138(.A(p39), .B(new_n228_), .Y(new_n229_));
  NOR2x1_ASAP7_75t_R   g139(.A(p37), .B(p36), .Y(new_n230_));
  NAND2x1_ASAP7_75t_R  g140(.A(p29), .B(p59), .Y(new_n231_));
  AND5x1_ASAP7_75t_R   g141(.A(new_n226_), .B(new_n227_), .C(new_n229_), .D(new_n230_), .E(new_n231_), .Y(new_n232_));
  NAND3x1_ASAP7_75t_R  g142(.A(new_n219_), .B(new_n224_), .C(new_n232_), .Y(new_n233_));
  INVx1_ASAP7_75t_R    g143(.A(new_n156_), .Y(new_n234_));
  NOR2x1_ASAP7_75t_R   g144(.A(p51), .B(p50), .Y(new_n235_));
  OA21x2_ASAP7_75t_R   g145(.A1(new_n235_), .A2(new_n234_), .B(new_n152_), .Y(new_n236_));
  OAI21x1_ASAP7_75t_R  g146(.A1(new_n234_), .A2(new_n211_), .B(new_n236_), .Y(new_n237_));
  NAND3x1_ASAP7_75t_R  g147(.A(new_n233_), .B(new_n157_), .C(new_n237_), .Y(new_n238_));
  NOR3x1_ASAP7_75t_R   g148(.A(new_n143_), .B(new_n217_), .C(new_n238_), .Y(o2));
  assign               o3 = 1'b0;
  assign               o4 = 1'b0;
  assign               o5 = 1'b0;
  assign               o6 = 1'b0;
  assign               o7 = 1'b0;
  assign               o8 = 1'b0;
  assign               o9 = 1'b0;
  assign               o10 = 1'b0;
  assign               o11 = 1'b0;
  assign               o12 = 1'b0;
  assign               o13 = 1'b0;
  assign               o14 = 1'b0;
  assign               o15 = 1'b0;
  assign               o16 = 1'b0;
  assign               o17 = 1'b0;
  assign               o18 = 1'b0;
  assign               o19 = 1'b0;
  assign               o20 = 1'b0;
  assign               o21 = 1'b0;
  assign               o22 = 1'b0;
  assign               o23 = 1'b0;
  assign               o24 = 1'b0;
  assign               o25 = 1'b0;
  assign               o26 = 1'b0;
  assign               o27 = 1'b0;
  assign               o28 = 1'b0;
  assign               o29 = 1'b0;
endmodule


