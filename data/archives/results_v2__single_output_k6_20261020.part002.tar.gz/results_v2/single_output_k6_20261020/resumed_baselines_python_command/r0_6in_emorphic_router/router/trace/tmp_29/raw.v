// Benchmark "/tmp/" written by ABC on Tue Oct 20 18:11:47 2026

module \/tmp/  ( 
    p9, p39, p53, p14, p57, p44, p11, p31, p16, p30, p21, p54, p42, p34,
    p38, p58, p22, p49, p19, p35, p45, p55, p17, p4, p18, p2, p37, p41,
    p43, p28, p25, p46, p52, p33, p20, p24, p3, p59, p1, p40, p51, p8, p32,
    p36, p23, p13, p12, p5, p6, p15, p10, p29, p7, p27, p26, p56, p50, p47,
    p0, p48,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25, o26, o27, o28, o29  );
  input  p9, p39, p53, p14, p57, p44, p11, p31, p16, p30, p21, p54, p42,
    p34, p38, p58, p22, p49, p19, p35, p45, p55, p17, p4, p18, p2, p37,
    p41, p43, p28, p25, p46, p52, p33, p20, p24, p3, p59, p1, p40, p51, p8,
    p32, p36, p23, p13, p12, p5, p6, p15, p10, p29, p7, p27, p26, p56, p50,
    p47, p0, p48;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25, o26, o27, o28, o29;
  wire new_n91_, new_n92_, new_n93_, new_n94_, new_n95_, new_n96_, new_n97_,
    new_n98_, new_n99_, new_n100_, new_n101_, new_n102_, new_n103_,
    new_n104_, new_n105_, new_n106_, new_n107_, new_n108_, new_n109_,
    new_n110_, new_n111_, new_n112_, new_n113_, new_n114_, new_n115_,
    new_n116_, new_n117_, new_n118_, new_n119_, new_n120_, new_n121_,
    new_n122_, new_n123_, new_n124_, new_n125_, new_n126_, new_n127_,
    new_n128_, new_n129_, new_n130_, new_n131_, new_n132_, new_n133_,
    new_n134_, new_n135_, new_n136_, new_n137_, new_n139_, new_n140_,
    new_n141_, new_n142_, new_n143_, new_n144_, new_n145_, new_n146_,
    new_n147_, new_n148_, new_n149_, new_n150_, new_n151_, new_n152_,
    new_n153_, new_n154_, new_n155_, new_n156_, new_n157_, new_n158_,
    new_n159_, new_n160_, new_n161_, new_n162_, new_n163_, new_n164_,
    new_n165_, new_n166_, new_n167_, new_n168_, new_n169_, new_n170_,
    new_n171_, new_n172_, new_n173_, new_n174_, new_n175_, new_n176_,
    new_n177_, new_n178_, new_n179_, new_n180_, new_n181_, new_n182_,
    new_n183_, new_n184_, new_n185_, new_n186_, new_n187_, new_n188_,
    new_n189_, new_n190_, new_n191_, new_n192_, new_n193_, new_n194_,
    new_n195_, new_n196_, new_n197_, new_n198_, new_n199_, new_n200_,
    new_n201_, new_n202_, new_n203_, new_n204_, new_n205_, new_n206_,
    new_n207_, new_n208_, new_n209_, new_n210_, new_n211_, new_n212_,
    new_n213_, new_n214_, new_n215_, new_n216_, new_n217_, new_n219_,
    new_n220_, new_n221_, new_n222_, new_n223_, new_n224_, new_n225_,
    new_n226_, new_n227_, new_n228_, new_n229_, new_n230_, new_n231_,
    new_n232_, new_n233_, new_n234_, new_n235_, new_n236_;
  AND3x1_ASAP7_75t_R   g000(.A(p28), .B(p27), .C(p26), .Y(new_n91_));
  NOR2x1_ASAP7_75t_R   g001(.A(p21), .B(p20), .Y(new_n92_));
  NOR2x1_ASAP7_75t_R   g002(.A(p11), .B(p12), .Y(new_n93_));
  OAI21x1_ASAP7_75t_R  g003(.A1(p9), .A2(p8), .B(p10), .Y(new_n94_));
  NAND2x1_ASAP7_75t_R  g004(.A(p14), .B(p13), .Y(new_n95_));
  AOI21x1_ASAP7_75t_R  g005(.A1(new_n93_), .A2(new_n94_), .B(new_n95_), .Y(new_n96_));
  AO21x1_ASAP7_75t_R   g006(.A1(p16), .A2(p15), .B(p17), .Y(new_n97_));
  AOI21x1_ASAP7_75t_R  g007(.A1(p16), .A2(new_n96_), .B(new_n97_), .Y(new_n98_));
  AND2x2_ASAP7_75t_R   g008(.A(p24), .B(p23), .Y(new_n99_));
  INVx1_ASAP7_75t_R    g009(.A(new_n99_), .Y(new_n100_));
  AND2x2_ASAP7_75t_R   g010(.A(p19), .B(p18), .Y(new_n101_));
  INVx1_ASAP7_75t_R    g011(.A(new_n92_), .Y(new_n102_));
  OAI21x1_ASAP7_75t_R  g012(.A1(new_n101_), .A2(new_n102_), .B(p22), .Y(new_n103_));
  AOI211x1_ASAP7_75t_R g013(.A1(new_n92_), .A2(new_n98_), .B(new_n100_), .C(new_n103_), .Y(new_n104_));
  AND2x2_ASAP7_75t_R   g014(.A(p25), .B(new_n91_), .Y(new_n105_));
  AO21x1_ASAP7_75t_R   g015(.A1(new_n91_), .A2(new_n104_), .B(new_n105_), .Y(new_n106_));
  OA21x2_ASAP7_75t_R   g016(.A1(p15), .A2(new_n96_), .B(p16), .Y(new_n107_));
  NAND2x1_ASAP7_75t_R  g017(.A(p15), .B(new_n96_), .Y(new_n108_));
  INVx1_ASAP7_75t_R    g018(.A(p9), .Y(new_n109_));
  AND2x2_ASAP7_75t_R   g019(.A(p14), .B(p13), .Y(new_n110_));
  INVx1_ASAP7_75t_R    g020(.A(p17), .Y(new_n111_));
  AND5x1_ASAP7_75t_R   g021(.A(new_n109_), .B(new_n99_), .C(new_n110_), .D(new_n111_), .E(new_n93_), .Y(new_n112_));
  INVx1_ASAP7_75t_R    g022(.A(p6), .Y(new_n113_));
  AND2x2_ASAP7_75t_R   g023(.A(p22), .B(p19), .Y(new_n114_));
  NOR2x1_ASAP7_75t_R   g024(.A(p7), .B(p0), .Y(new_n115_));
  AND5x1_ASAP7_75t_R   g025(.A(new_n113_), .B(new_n114_), .C(p10), .D(new_n92_), .E(new_n115_), .Y(new_n116_));
  NOR2x1_ASAP7_75t_R   g026(.A(p3), .B(p1), .Y(new_n117_));
  INVx1_ASAP7_75t_R    g027(.A(p5), .Y(new_n118_));
  AND3x1_ASAP7_75t_R   g028(.A(new_n117_), .B(p8), .C(new_n118_), .Y(new_n119_));
  NOR2x1_ASAP7_75t_R   g029(.A(p2), .B(p25), .Y(new_n120_));
  INVx1_ASAP7_75t_R    g030(.A(p4), .Y(new_n121_));
  AND3x1_ASAP7_75t_R   g031(.A(new_n120_), .B(new_n121_), .C(p18), .Y(new_n122_));
  AND5x1_ASAP7_75t_R   g032(.A(new_n108_), .B(new_n112_), .C(new_n116_), .D(new_n119_), .E(new_n122_), .Y(new_n123_));
  NAND2x1_ASAP7_75t_R  g033(.A(new_n107_), .B(new_n123_), .Y(new_n124_));
  AO21x1_ASAP7_75t_R   g034(.A1(p22), .A2(new_n102_), .B(p23), .Y(new_n125_));
  INVx1_ASAP7_75t_R    g035(.A(p15), .Y(new_n126_));
  AND5x1_ASAP7_75t_R   g036(.A(new_n126_), .B(new_n91_), .C(p10), .D(p7), .E(p0), .Y(new_n127_));
  AND5x1_ASAP7_75t_R   g037(.A(p16), .B(new_n110_), .C(new_n111_), .D(p4), .E(p18), .Y(new_n128_));
  INVx1_ASAP7_75t_R    g038(.A(p8), .Y(new_n129_));
  AND5x1_ASAP7_75t_R   g039(.A(new_n109_), .B(new_n114_), .C(new_n129_), .D(new_n92_), .E(new_n93_), .Y(new_n130_));
  AND2x2_ASAP7_75t_R   g040(.A(p5), .B(p6), .Y(new_n131_));
  AND3x1_ASAP7_75t_R   g041(.A(new_n131_), .B(p59), .C(p1), .Y(new_n132_));
  AND2x2_ASAP7_75t_R   g042(.A(p24), .B(p3), .Y(new_n133_));
  INVx1_ASAP7_75t_R    g043(.A(p25), .Y(new_n134_));
  AND3x1_ASAP7_75t_R   g044(.A(new_n133_), .B(p2), .C(new_n134_), .Y(new_n135_));
  AND5x1_ASAP7_75t_R   g045(.A(new_n127_), .B(new_n128_), .C(new_n130_), .D(new_n132_), .E(new_n135_), .Y(new_n136_));
  AOI221x1_ASAP7_75t_R g046(.A1(new_n125_), .A2(new_n136_), .B1(new_n104_), .B2(new_n91_), .C(new_n105_), .Y(new_n137_));
  AO21x1_ASAP7_75t_R   g047(.A1(new_n106_), .A2(new_n124_), .B(new_n137_), .Y(o0));
  AO221x2_ASAP7_75t_R  g048(.A1(new_n125_), .A2(new_n136_), .B1(new_n104_), .B2(new_n91_), .C(new_n105_), .Y(new_n139_));
  NAND2x1_ASAP7_75t_R  g049(.A(p49), .B(p48), .Y(new_n140_));
  NOR2x1_ASAP7_75t_R   g050(.A(p42), .B(p41), .Y(new_n141_));
  OAI21x1_ASAP7_75t_R  g051(.A1(p39), .A2(p38), .B(p40), .Y(new_n142_));
  NAND2x1_ASAP7_75t_R  g052(.A(p44), .B(p43), .Y(new_n143_));
  AOI21x1_ASAP7_75t_R  g053(.A1(new_n141_), .A2(new_n142_), .B(new_n143_), .Y(new_n144_));
  AO21x1_ASAP7_75t_R   g054(.A1(p45), .A2(p46), .B(p47), .Y(new_n145_));
  AOI21x1_ASAP7_75t_R  g055(.A1(p46), .A2(new_n144_), .B(new_n145_), .Y(new_n146_));
  INVx1_ASAP7_75t_R    g056(.A(p51), .Y(new_n147_));
  NAND2x1_ASAP7_75t_R  g057(.A(p52), .B(new_n147_), .Y(new_n148_));
  OAI21x1_ASAP7_75t_R  g058(.A1(new_n140_), .A2(new_n146_), .B(new_n148_), .Y(new_n149_));
  AND2x2_ASAP7_75t_R   g059(.A(p33), .B(p40), .Y(new_n150_));
  AND2x2_ASAP7_75t_R   g060(.A(p30), .B(p34), .Y(new_n151_));
  AND2x2_ASAP7_75t_R   g061(.A(p49), .B(p35), .Y(new_n152_));
  AND5x1_ASAP7_75t_R   g062(.A(p37), .B(new_n150_), .C(new_n151_), .D(new_n152_), .E(p46), .Y(new_n153_));
  AND3x1_ASAP7_75t_R   g063(.A(p57), .B(p58), .C(p56), .Y(new_n154_));
  AND3x1_ASAP7_75t_R   g064(.A(p32), .B(p36), .C(p29), .Y(new_n155_));
  AND2x2_ASAP7_75t_R   g065(.A(p53), .B(p54), .Y(new_n156_));
  NOR2x1_ASAP7_75t_R   g066(.A(p45), .B(p55), .Y(new_n157_));
  AND4x2_ASAP7_75t_R   g067(.A(new_n154_), .B(new_n155_), .C(new_n156_), .D(new_n157_), .Y(new_n158_));
  INVx1_ASAP7_75t_R    g068(.A(p47), .Y(new_n159_));
  INVx1_ASAP7_75t_R    g069(.A(p48), .Y(new_n160_));
  NAND2x1_ASAP7_75t_R  g070(.A(p44), .B(p31), .Y(new_n161_));
  INVx1_ASAP7_75t_R    g071(.A(p39), .Y(new_n162_));
  INVx1_ASAP7_75t_R    g072(.A(p38), .Y(new_n163_));
  NAND2x1_ASAP7_75t_R  g073(.A(new_n162_), .B(new_n163_), .Y(new_n164_));
  AOI211x1_ASAP7_75t_R g074(.A1(new_n159_), .A2(new_n160_), .B(new_n161_), .C(new_n164_), .Y(new_n165_));
  NAND2x1_ASAP7_75t_R  g075(.A(p45), .B(p46), .Y(new_n166_));
  OAI21x1_ASAP7_75t_R  g076(.A1(p48), .A2(new_n166_), .B(new_n145_), .Y(new_n167_));
  AND4x2_ASAP7_75t_R   g077(.A(new_n153_), .B(new_n158_), .C(new_n165_), .D(new_n167_), .Y(new_n168_));
  NAND2x1_ASAP7_75t_R  g078(.A(new_n141_), .B(new_n142_), .Y(new_n169_));
  INVx1_ASAP7_75t_R    g079(.A(p41), .Y(new_n170_));
  NOR2x1_ASAP7_75t_R   g080(.A(new_n170_), .B(new_n142_), .Y(new_n171_));
  AOI21x1_ASAP7_75t_R  g081(.A1(p42), .A2(new_n171_), .B(p43), .Y(new_n172_));
  AOI21x1_ASAP7_75t_R  g082(.A1(p43), .A2(new_n169_), .B(new_n172_), .Y(new_n173_));
  NAND3x1_ASAP7_75t_R  g083(.A(new_n149_), .B(new_n168_), .C(new_n173_), .Y(new_n174_));
  AND3x1_ASAP7_75t_R   g084(.A(p53), .B(p54), .C(p52), .Y(new_n175_));
  OA21x2_ASAP7_75t_R   g085(.A1(p55), .A2(new_n175_), .B(new_n154_), .Y(new_n176_));
  INVx1_ASAP7_75t_R    g086(.A(p55), .Y(new_n177_));
  NOR2x1_ASAP7_75t_R   g087(.A(p51), .B(p50), .Y(new_n178_));
  AND2x2_ASAP7_75t_R   g088(.A(new_n177_), .B(new_n178_), .Y(new_n179_));
  OAI21x1_ASAP7_75t_R  g089(.A1(new_n140_), .A2(new_n146_), .B(new_n179_), .Y(new_n180_));
  NOR2x1_ASAP7_75t_R   g090(.A(p59), .B(p50), .Y(new_n181_));
  AOI21x1_ASAP7_75t_R  g091(.A1(new_n176_), .A2(new_n180_), .B(new_n181_), .Y(new_n182_));
  OR4x2_ASAP7_75t_R    g092(.A(new_n163_), .B(p45), .C(p55), .D(p37), .Y(new_n183_));
  NOR2x1_ASAP7_75t_R   g093(.A(p36), .B(p50), .Y(new_n184_));
  NAND3x1_ASAP7_75t_R  g094(.A(new_n184_), .B(p40), .C(p56), .Y(new_n185_));
  NOR2x1_ASAP7_75t_R   g095(.A(p39), .B(p42), .Y(new_n186_));
  AND2x2_ASAP7_75t_R   g096(.A(p44), .B(p43), .Y(new_n187_));
  NAND2x1_ASAP7_75t_R  g097(.A(new_n186_), .B(new_n187_), .Y(new_n188_));
  NOR3x1_ASAP7_75t_R   g098(.A(new_n183_), .B(new_n185_), .C(new_n188_), .Y(new_n189_));
  NAND2x1_ASAP7_75t_R  g099(.A(p46), .B(p47), .Y(new_n190_));
  AND2x2_ASAP7_75t_R   g100(.A(p49), .B(p48), .Y(new_n191_));
  NAND2x1_ASAP7_75t_R  g101(.A(new_n190_), .B(new_n191_), .Y(new_n192_));
  NOR2x1_ASAP7_75t_R   g102(.A(p31), .B(p30), .Y(new_n193_));
  NAND2x1_ASAP7_75t_R  g103(.A(new_n193_), .B(new_n156_), .Y(new_n194_));
  AOI211x1_ASAP7_75t_R g104(.A1(new_n170_), .A2(new_n142_), .B(new_n192_), .C(new_n194_), .Y(new_n195_));
  NOR2x1_ASAP7_75t_R   g105(.A(p34), .B(p35), .Y(new_n196_));
  NOR2x1_ASAP7_75t_R   g106(.A(p33), .B(p32), .Y(new_n197_));
  NAND2x1_ASAP7_75t_R  g107(.A(new_n196_), .B(new_n197_), .Y(new_n198_));
  NOR3x1_ASAP7_75t_R   g108(.A(new_n171_), .B(new_n198_), .C(new_n148_), .Y(new_n199_));
  NAND3x1_ASAP7_75t_R  g109(.A(new_n189_), .B(new_n195_), .C(new_n199_), .Y(new_n200_));
  OR2x4_ASAP7_75t_R    g110(.A(p45), .B(new_n159_), .Y(new_n201_));
  NOR2x1_ASAP7_75t_R   g111(.A(new_n144_), .B(new_n201_), .Y(new_n202_));
  INVx1_ASAP7_75t_R    g112(.A(new_n166_), .Y(new_n203_));
  AO21x1_ASAP7_75t_R   g113(.A1(p46), .A2(new_n144_), .B(new_n203_), .Y(new_n204_));
  NOR2x1_ASAP7_75t_R   g114(.A(p59), .B(p29), .Y(new_n205_));
  OAI21x1_ASAP7_75t_R  g115(.A1(new_n202_), .A2(new_n204_), .B(new_n205_), .Y(new_n206_));
  INVx1_ASAP7_75t_R    g116(.A(p46), .Y(new_n207_));
  AOI211x1_ASAP7_75t_R g117(.A1(new_n141_), .A2(new_n142_), .B(new_n207_), .C(new_n143_), .Y(new_n208_));
  OAI21x1_ASAP7_75t_R  g118(.A1(new_n145_), .A2(new_n208_), .B(new_n191_), .Y(new_n209_));
  INVx1_ASAP7_75t_R    g119(.A(new_n176_), .Y(new_n210_));
  AOI21x1_ASAP7_75t_R  g120(.A1(new_n179_), .A2(new_n209_), .B(new_n210_), .Y(new_n211_));
  OAI21x1_ASAP7_75t_R  g121(.A1(new_n200_), .A2(new_n206_), .B(new_n211_), .Y(new_n212_));
  OAI21x1_ASAP7_75t_R  g122(.A1(new_n174_), .A2(new_n182_), .B(new_n212_), .Y(new_n213_));
  INVx1_ASAP7_75t_R    g123(.A(new_n91_), .Y(new_n214_));
  AOI21x1_ASAP7_75t_R  g124(.A1(new_n92_), .A2(new_n98_), .B(new_n103_), .Y(new_n215_));
  AOI21x1_ASAP7_75t_R  g125(.A1(new_n99_), .A2(new_n215_), .B(p25), .Y(new_n216_));
  AOI211x1_ASAP7_75t_R g126(.A1(new_n107_), .A2(new_n123_), .B(new_n214_), .C(new_n216_), .Y(new_n217_));
  AOI21x1_ASAP7_75t_R  g127(.A1(new_n139_), .A2(new_n213_), .B(new_n217_), .Y(o1));
  NOR2x1_ASAP7_75t_R   g128(.A(new_n203_), .B(new_n208_), .Y(new_n219_));
  OAI21x1_ASAP7_75t_R  g129(.A1(new_n144_), .A2(new_n201_), .B(new_n219_), .Y(new_n220_));
  NAND2x1_ASAP7_75t_R  g130(.A(new_n170_), .B(new_n142_), .Y(new_n221_));
  AND5x1_ASAP7_75t_R   g131(.A(p53), .B(new_n196_), .C(new_n197_), .D(new_n193_), .E(p54), .Y(new_n222_));
  NAND2x1_ASAP7_75t_R  g132(.A(p41), .B(p40), .Y(new_n223_));
  AO21x1_ASAP7_75t_R   g133(.A1(new_n162_), .A2(new_n163_), .B(new_n223_), .Y(new_n224_));
  NOR2x1_ASAP7_75t_R   g134(.A(new_n140_), .B(new_n148_), .Y(new_n225_));
  AND5x1_ASAP7_75t_R   g135(.A(new_n221_), .B(new_n222_), .C(new_n224_), .D(new_n225_), .E(new_n190_), .Y(new_n226_));
  INVx1_ASAP7_75t_R    g136(.A(p37), .Y(new_n227_));
  AND3x1_ASAP7_75t_R   g137(.A(new_n157_), .B(p38), .C(new_n227_), .Y(new_n228_));
  AND3x1_ASAP7_75t_R   g138(.A(new_n184_), .B(p40), .C(p56), .Y(new_n229_));
  NAND2x1_ASAP7_75t_R  g139(.A(p59), .B(p29), .Y(new_n230_));
  AND5x1_ASAP7_75t_R   g140(.A(new_n187_), .B(new_n228_), .C(new_n229_), .D(new_n186_), .E(new_n230_), .Y(new_n231_));
  NAND3x1_ASAP7_75t_R  g141(.A(new_n220_), .B(new_n226_), .C(new_n231_), .Y(new_n232_));
  INVx1_ASAP7_75t_R    g142(.A(new_n175_), .Y(new_n233_));
  OA21x2_ASAP7_75t_R   g143(.A1(new_n178_), .A2(new_n233_), .B(new_n177_), .Y(new_n234_));
  OAI21x1_ASAP7_75t_R  g144(.A1(new_n233_), .A2(new_n209_), .B(new_n234_), .Y(new_n235_));
  NAND3x1_ASAP7_75t_R  g145(.A(new_n232_), .B(new_n154_), .C(new_n235_), .Y(new_n236_));
  AOI211x1_ASAP7_75t_R g146(.A1(new_n124_), .A2(new_n106_), .B(new_n137_), .C(new_n236_), .Y(o2));
  assign               o3 = 1'b0;
  assign               o4 = 1'b0;
  assign               o5 = 1'b0;
  assign               o6 = 1'b0;
  assign               o7 = 1'b0;
  assign               o8 = 1'b0;
  assign               o9 = 1'b0;
  assign               o10 = 1'b0;
  assign               o11 = 1'b0;
  assign               o12 = 1'b0;
  assign               o13 = 1'b0;
  assign               o14 = 1'b0;
  assign               o15 = 1'b0;
  assign               o16 = 1'b0;
  assign               o17 = 1'b0;
  assign               o18 = 1'b0;
  assign               o19 = 1'b0;
  assign               o20 = 1'b0;
  assign               o21 = 1'b0;
  assign               o22 = 1'b0;
  assign               o23 = 1'b0;
  assign               o24 = 1'b0;
  assign               o25 = 1'b0;
  assign               o26 = 1'b0;
  assign               o27 = 1'b0;
  assign               o28 = 1'b0;
  assign               o29 = 1'b0;
endmodule


