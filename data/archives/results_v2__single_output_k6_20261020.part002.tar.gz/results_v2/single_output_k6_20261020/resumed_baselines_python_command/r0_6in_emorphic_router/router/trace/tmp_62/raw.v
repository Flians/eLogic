// Benchmark "/tmp/" written by ABC on Tue Oct 20 18:11:51 2026

module \/tmp/  ( 
    p20, p16, p1, p11, p52, p30, p50, p55, p41, p38, p4, p35, p22, p26,
    p40, p3, p56, p5, p59, p29, p47, p58, p27, p6, p24, p21, p19, p9, p37,
    p15, p18, p14, p12, p31, p44, p49, p45, p43, p57, p25, p8, p33, p13,
    p17, p54, p32, p46, p51, p42, p10, p34, p53, p36, p39, p48, p23, p28,
    p7, p2, p0,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25, o26, o27, o28, o29  );
  input  p20, p16, p1, p11, p52, p30, p50, p55, p41, p38, p4, p35, p22,
    p26, p40, p3, p56, p5, p59, p29, p47, p58, p27, p6, p24, p21, p19, p9,
    p37, p15, p18, p14, p12, p31, p44, p49, p45, p43, p57, p25, p8, p33,
    p13, p17, p54, p32, p46, p51, p42, p10, p34, p53, p36, p39, p48, p23,
    p28, p7, p2, p0;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25, o26, o27, o28, o29;
  wire new_n91_, new_n92_, new_n93_, new_n94_, new_n95_, new_n96_, new_n97_,
    new_n98_, new_n99_, new_n100_, new_n101_, new_n102_, new_n103_,
    new_n104_, new_n105_, new_n106_, new_n107_, new_n108_, new_n109_,
    new_n110_, new_n111_, new_n112_, new_n113_, new_n114_, new_n115_,
    new_n116_, new_n117_, new_n118_, new_n119_, new_n120_, new_n121_,
    new_n122_, new_n123_, new_n124_, new_n125_, new_n126_, new_n127_,
    new_n128_, new_n129_, new_n130_, new_n131_, new_n132_, new_n133_,
    new_n134_, new_n135_, new_n136_, new_n137_, new_n138_, new_n139_,
    new_n140_, new_n141_, new_n142_, new_n144_, new_n145_, new_n146_,
    new_n147_, new_n148_, new_n149_, new_n150_, new_n151_, new_n152_,
    new_n153_, new_n154_, new_n155_, new_n156_, new_n157_, new_n158_,
    new_n159_, new_n160_, new_n161_, new_n162_, new_n163_, new_n164_,
    new_n165_, new_n166_, new_n167_, new_n168_, new_n169_, new_n170_,
    new_n171_, new_n172_, new_n173_, new_n174_, new_n175_, new_n176_,
    new_n177_, new_n178_, new_n179_, new_n180_, new_n181_, new_n182_,
    new_n183_, new_n184_, new_n185_, new_n186_, new_n187_, new_n188_,
    new_n189_, new_n190_, new_n191_, new_n192_, new_n193_, new_n194_,
    new_n195_, new_n196_, new_n197_, new_n198_, new_n199_, new_n200_,
    new_n201_, new_n202_, new_n203_, new_n204_, new_n205_, new_n206_,
    new_n207_, new_n208_, new_n209_, new_n210_, new_n211_, new_n212_,
    new_n214_, new_n215_, new_n216_, new_n217_, new_n218_, new_n219_,
    new_n220_, new_n221_, new_n222_, new_n223_, new_n224_, new_n225_,
    new_n226_, new_n227_, new_n228_, new_n229_, new_n230_, new_n231_,
    new_n232_, new_n233_, new_n234_, new_n235_, new_n236_, new_n237_;
  AND3x1_ASAP7_75t_R   g000(.A(p26), .B(p27), .C(p28), .Y(new_n91_));
  INVx1_ASAP7_75t_R    g001(.A(new_n91_), .Y(new_n92_));
  AND2x2_ASAP7_75t_R   g002(.A(p24), .B(p23), .Y(new_n93_));
  INVx1_ASAP7_75t_R    g003(.A(new_n93_), .Y(new_n94_));
  NOR2x1_ASAP7_75t_R   g004(.A(p20), .B(p21), .Y(new_n95_));
  INVx1_ASAP7_75t_R    g005(.A(new_n95_), .Y(new_n96_));
  NOR2x1_ASAP7_75t_R   g006(.A(p11), .B(p12), .Y(new_n97_));
  OAI21x1_ASAP7_75t_R  g007(.A1(p9), .A2(p8), .B(p10), .Y(new_n98_));
  NAND2x1_ASAP7_75t_R  g008(.A(p14), .B(p13), .Y(new_n99_));
  AOI21x1_ASAP7_75t_R  g009(.A1(new_n97_), .A2(new_n98_), .B(new_n99_), .Y(new_n100_));
  AO21x1_ASAP7_75t_R   g010(.A1(p16), .A2(p15), .B(p17), .Y(new_n101_));
  AO21x1_ASAP7_75t_R   g011(.A1(p16), .A2(new_n100_), .B(new_n101_), .Y(new_n102_));
  NAND2x1_ASAP7_75t_R  g012(.A(p19), .B(p18), .Y(new_n103_));
  INVx1_ASAP7_75t_R    g013(.A(p22), .Y(new_n104_));
  AOI21x1_ASAP7_75t_R  g014(.A1(new_n103_), .A2(new_n95_), .B(new_n104_), .Y(new_n105_));
  OAI21x1_ASAP7_75t_R  g015(.A1(new_n96_), .A2(new_n102_), .B(new_n105_), .Y(new_n106_));
  NAND2x1_ASAP7_75t_R  g016(.A(p25), .B(new_n91_), .Y(new_n107_));
  OA31x2_ASAP7_75t_R   g017(.A1(new_n92_), .A2(new_n94_), .A3(new_n106_), .B1(new_n107_), .Y(new_n108_));
  INVx1_ASAP7_75t_R    g018(.A(p16), .Y(new_n109_));
  AOI211x1_ASAP7_75t_R g019(.A1(new_n97_), .A2(new_n98_), .B(new_n109_), .C(new_n99_), .Y(new_n110_));
  AO21x1_ASAP7_75t_R   g020(.A1(p16), .A2(p15), .B(new_n110_), .Y(new_n111_));
  OR4x2_ASAP7_75t_R    g021(.A(p5), .B(p6), .C(p9), .D(p12), .Y(new_n112_));
  OR4x2_ASAP7_75t_R    g022(.A(p1), .B(p11), .C(p4), .D(p3), .Y(new_n113_));
  NOR2x1_ASAP7_75t_R   g023(.A(new_n112_), .B(new_n113_), .Y(new_n114_));
  NAND2x1_ASAP7_75t_R  g024(.A(p15), .B(new_n100_), .Y(new_n115_));
  INVx1_ASAP7_75t_R    g025(.A(p17), .Y(new_n116_));
  INVx1_ASAP7_75t_R    g026(.A(p25), .Y(new_n117_));
  AND2x2_ASAP7_75t_R   g027(.A(p8), .B(new_n117_), .Y(new_n118_));
  AND3x1_ASAP7_75t_R   g028(.A(p22), .B(p19), .C(p18), .Y(new_n119_));
  NOR3x1_ASAP7_75t_R   g029(.A(p7), .B(p2), .C(p0), .Y(new_n120_));
  AND5x1_ASAP7_75t_R   g030(.A(new_n116_), .B(new_n118_), .C(p10), .D(new_n119_), .E(new_n120_), .Y(new_n121_));
  AND5x1_ASAP7_75t_R   g031(.A(p24), .B(new_n95_), .C(p14), .D(p13), .E(p23), .Y(new_n122_));
  AND5x1_ASAP7_75t_R   g032(.A(new_n111_), .B(new_n114_), .C(new_n115_), .D(new_n121_), .E(new_n122_), .Y(new_n123_));
  OA31x2_ASAP7_75t_R   g033(.A1(new_n96_), .A2(new_n101_), .A3(new_n110_), .B1(new_n105_), .Y(new_n124_));
  AOI21x1_ASAP7_75t_R  g034(.A1(new_n93_), .A2(new_n124_), .B(p25), .Y(new_n125_));
  NOR2x1_ASAP7_75t_R   g035(.A(p9), .B(p8), .Y(new_n126_));
  AND5x1_ASAP7_75t_R   g036(.A(p22), .B(new_n95_), .C(new_n97_), .D(new_n126_), .E(p19), .Y(new_n127_));
  AND2x2_ASAP7_75t_R   g037(.A(p59), .B(p6), .Y(new_n128_));
  INVx1_ASAP7_75t_R    g038(.A(p15), .Y(new_n129_));
  AND3x1_ASAP7_75t_R   g039(.A(new_n128_), .B(p24), .C(new_n129_), .Y(new_n130_));
  AND2x2_ASAP7_75t_R   g040(.A(p1), .B(p4), .Y(new_n131_));
  AND3x1_ASAP7_75t_R   g041(.A(new_n131_), .B(p3), .C(p5), .Y(new_n132_));
  NAND3x1_ASAP7_75t_R  g042(.A(new_n127_), .B(new_n130_), .C(new_n132_), .Y(new_n133_));
  NAND2x1_ASAP7_75t_R  g043(.A(p10), .B(p7), .Y(new_n134_));
  NAND2x1_ASAP7_75t_R  g044(.A(p2), .B(p0), .Y(new_n135_));
  NAND2x1_ASAP7_75t_R  g045(.A(p18), .B(p14), .Y(new_n136_));
  NAND2x1_ASAP7_75t_R  g046(.A(p13), .B(new_n117_), .Y(new_n137_));
  OR5x1_ASAP7_75t_R    g047(.A(new_n92_), .B(new_n134_), .C(new_n135_), .D(new_n136_), .E(new_n137_), .Y(new_n138_));
  AOI21x1_ASAP7_75t_R  g048(.A1(p22), .A2(new_n96_), .B(p23), .Y(new_n139_));
  NOR3x1_ASAP7_75t_R   g049(.A(new_n100_), .B(p16), .C(p15), .Y(new_n140_));
  OR5x1_ASAP7_75t_R    g050(.A(new_n102_), .B(new_n133_), .C(new_n138_), .D(new_n139_), .E(new_n140_), .Y(new_n141_));
  OAI21x1_ASAP7_75t_R  g051(.A1(new_n92_), .A2(new_n125_), .B(new_n141_), .Y(new_n142_));
  OAI21x1_ASAP7_75t_R  g052(.A1(new_n108_), .A2(new_n123_), .B(new_n142_), .Y(o0));
  AND3x1_ASAP7_75t_R   g053(.A(p52), .B(p54), .C(p53), .Y(new_n144_));
  AND3x1_ASAP7_75t_R   g054(.A(p56), .B(p58), .C(p57), .Y(new_n145_));
  OA21x2_ASAP7_75t_R   g055(.A1(p55), .A2(new_n144_), .B(new_n145_), .Y(new_n146_));
  NAND2x1_ASAP7_75t_R  g056(.A(p49), .B(p48), .Y(new_n147_));
  NOR2x1_ASAP7_75t_R   g057(.A(p41), .B(p42), .Y(new_n148_));
  OAI21x1_ASAP7_75t_R  g058(.A1(p38), .A2(p39), .B(p40), .Y(new_n149_));
  NAND2x1_ASAP7_75t_R  g059(.A(p44), .B(p43), .Y(new_n150_));
  AOI21x1_ASAP7_75t_R  g060(.A1(new_n148_), .A2(new_n149_), .B(new_n150_), .Y(new_n151_));
  AO21x1_ASAP7_75t_R   g061(.A1(p45), .A2(p46), .B(p47), .Y(new_n152_));
  AOI21x1_ASAP7_75t_R  g062(.A1(p46), .A2(new_n151_), .B(new_n152_), .Y(new_n153_));
  INVx1_ASAP7_75t_R    g063(.A(p51), .Y(new_n154_));
  NOR2x1_ASAP7_75t_R   g064(.A(p50), .B(p55), .Y(new_n155_));
  AND2x2_ASAP7_75t_R   g065(.A(new_n154_), .B(new_n155_), .Y(new_n156_));
  OAI21x1_ASAP7_75t_R  g066(.A1(new_n147_), .A2(new_n153_), .B(new_n156_), .Y(new_n157_));
  NOR2x1_ASAP7_75t_R   g067(.A(p50), .B(p59), .Y(new_n158_));
  AOI21x1_ASAP7_75t_R  g068(.A1(new_n146_), .A2(new_n157_), .B(new_n158_), .Y(new_n159_));
  NAND2x1_ASAP7_75t_R  g069(.A(p52), .B(new_n154_), .Y(new_n160_));
  OAI21x1_ASAP7_75t_R  g070(.A1(new_n147_), .A2(new_n153_), .B(new_n160_), .Y(new_n161_));
  AND3x1_ASAP7_75t_R   g071(.A(p46), .B(p34), .C(p36), .Y(new_n162_));
  AND2x2_ASAP7_75t_R   g072(.A(p33), .B(p32), .Y(new_n163_));
  INVx1_ASAP7_75t_R    g073(.A(p45), .Y(new_n164_));
  AND5x1_ASAP7_75t_R   g074(.A(p49), .B(new_n145_), .C(new_n162_), .D(new_n163_), .E(new_n164_), .Y(new_n165_));
  INVx1_ASAP7_75t_R    g075(.A(p30), .Y(new_n166_));
  NOR2x1_ASAP7_75t_R   g076(.A(p55), .B(new_n166_), .Y(new_n167_));
  AND4x2_ASAP7_75t_R   g077(.A(p29), .B(p37), .C(p31), .D(p44), .Y(new_n168_));
  AND2x2_ASAP7_75t_R   g078(.A(p35), .B(p40), .Y(new_n169_));
  AND3x1_ASAP7_75t_R   g079(.A(new_n167_), .B(new_n168_), .C(new_n169_), .Y(new_n170_));
  NOR2x1_ASAP7_75t_R   g080(.A(p38), .B(p39), .Y(new_n171_));
  INVx1_ASAP7_75t_R    g081(.A(new_n171_), .Y(new_n172_));
  NAND2x1_ASAP7_75t_R  g082(.A(p54), .B(p53), .Y(new_n173_));
  NOR2x1_ASAP7_75t_R   g083(.A(p47), .B(p48), .Y(new_n174_));
  NOR3x1_ASAP7_75t_R   g084(.A(new_n172_), .B(new_n173_), .C(new_n174_), .Y(new_n175_));
  NAND2x1_ASAP7_75t_R  g085(.A(p45), .B(p46), .Y(new_n176_));
  OAI21x1_ASAP7_75t_R  g086(.A1(p48), .A2(new_n176_), .B(new_n152_), .Y(new_n177_));
  AND4x2_ASAP7_75t_R   g087(.A(new_n165_), .B(new_n170_), .C(new_n175_), .D(new_n177_), .Y(new_n178_));
  INVx1_ASAP7_75t_R    g088(.A(p41), .Y(new_n179_));
  NOR2x1_ASAP7_75t_R   g089(.A(new_n179_), .B(new_n149_), .Y(new_n180_));
  AOI21x1_ASAP7_75t_R  g090(.A1(p42), .A2(new_n180_), .B(p43), .Y(new_n181_));
  NAND2x1_ASAP7_75t_R  g091(.A(new_n179_), .B(new_n149_), .Y(new_n182_));
  OA21x2_ASAP7_75t_R   g092(.A1(p42), .A2(new_n182_), .B(p43), .Y(new_n183_));
  NOR2x1_ASAP7_75t_R   g093(.A(new_n181_), .B(new_n183_), .Y(new_n184_));
  NAND3x1_ASAP7_75t_R  g094(.A(new_n161_), .B(new_n178_), .C(new_n184_), .Y(new_n185_));
  INVx1_ASAP7_75t_R    g095(.A(new_n147_), .Y(new_n186_));
  AND2x2_ASAP7_75t_R   g096(.A(p54), .B(p53), .Y(new_n187_));
  NAND2x1_ASAP7_75t_R  g097(.A(p47), .B(p46), .Y(new_n188_));
  NOR2x1_ASAP7_75t_R   g098(.A(p30), .B(p35), .Y(new_n189_));
  AND5x1_ASAP7_75t_R   g099(.A(new_n182_), .B(new_n186_), .C(new_n187_), .D(new_n188_), .E(new_n189_), .Y(new_n190_));
  INVx1_ASAP7_75t_R    g100(.A(p38), .Y(new_n191_));
  OR3x1_ASAP7_75t_R    g101(.A(new_n150_), .B(new_n191_), .C(p37), .Y(new_n192_));
  NAND3x1_ASAP7_75t_R  g102(.A(new_n155_), .B(p40), .C(p56), .Y(new_n193_));
  OR4x2_ASAP7_75t_R    g103(.A(p45), .B(p42), .C(p36), .D(p39), .Y(new_n194_));
  NOR3x1_ASAP7_75t_R   g104(.A(new_n192_), .B(new_n193_), .C(new_n194_), .Y(new_n195_));
  OR4x2_ASAP7_75t_R    g105(.A(p31), .B(p33), .C(p32), .D(p34), .Y(new_n196_));
  NOR3x1_ASAP7_75t_R   g106(.A(new_n180_), .B(new_n196_), .C(new_n160_), .Y(new_n197_));
  NAND3x1_ASAP7_75t_R  g107(.A(new_n190_), .B(new_n195_), .C(new_n197_), .Y(new_n198_));
  NAND2x1_ASAP7_75t_R  g108(.A(p47), .B(new_n164_), .Y(new_n199_));
  NOR2x1_ASAP7_75t_R   g109(.A(new_n199_), .B(new_n151_), .Y(new_n200_));
  INVx1_ASAP7_75t_R    g110(.A(new_n176_), .Y(new_n201_));
  AO21x1_ASAP7_75t_R   g111(.A1(p46), .A2(new_n151_), .B(new_n201_), .Y(new_n202_));
  NOR2x1_ASAP7_75t_R   g112(.A(p59), .B(p29), .Y(new_n203_));
  OAI21x1_ASAP7_75t_R  g113(.A1(new_n200_), .A2(new_n202_), .B(new_n203_), .Y(new_n204_));
  INVx1_ASAP7_75t_R    g114(.A(p46), .Y(new_n205_));
  AOI211x1_ASAP7_75t_R g115(.A1(new_n148_), .A2(new_n149_), .B(new_n205_), .C(new_n150_), .Y(new_n206_));
  OAI21x1_ASAP7_75t_R  g116(.A1(new_n152_), .A2(new_n206_), .B(new_n186_), .Y(new_n207_));
  INVx1_ASAP7_75t_R    g117(.A(new_n146_), .Y(new_n208_));
  AOI21x1_ASAP7_75t_R  g118(.A1(new_n156_), .A2(new_n207_), .B(new_n208_), .Y(new_n209_));
  OAI21x1_ASAP7_75t_R  g119(.A1(new_n198_), .A2(new_n204_), .B(new_n209_), .Y(new_n210_));
  OAI21x1_ASAP7_75t_R  g120(.A1(new_n159_), .A2(new_n185_), .B(new_n210_), .Y(new_n211_));
  NOR3x1_ASAP7_75t_R   g121(.A(new_n123_), .B(new_n125_), .C(new_n92_), .Y(new_n212_));
  AOI21x1_ASAP7_75t_R  g122(.A1(new_n142_), .A2(new_n211_), .B(new_n212_), .Y(o1));
  INVx1_ASAP7_75t_R    g123(.A(p31), .Y(new_n214_));
  NOR2x1_ASAP7_75t_R   g124(.A(p33), .B(p32), .Y(new_n215_));
  NOR2x1_ASAP7_75t_R   g125(.A(p35), .B(p34), .Y(new_n216_));
  AND5x1_ASAP7_75t_R   g126(.A(new_n166_), .B(new_n187_), .C(new_n214_), .D(new_n215_), .E(new_n216_), .Y(new_n217_));
  INVx1_ASAP7_75t_R    g127(.A(new_n180_), .Y(new_n218_));
  NOR2x1_ASAP7_75t_R   g128(.A(new_n147_), .B(new_n160_), .Y(new_n219_));
  AND5x1_ASAP7_75t_R   g129(.A(new_n182_), .B(new_n217_), .C(new_n218_), .D(new_n188_), .E(new_n219_), .Y(new_n220_));
  NOR2x1_ASAP7_75t_R   g130(.A(p45), .B(new_n151_), .Y(new_n221_));
  OAI22x1_ASAP7_75t_R  g131(.A1(new_n221_), .A2(new_n205_), .B1(new_n151_), .B2(new_n199_), .Y(new_n222_));
  NOR2x1_ASAP7_75t_R   g132(.A(p50), .B(p45), .Y(new_n223_));
  INVx1_ASAP7_75t_R    g133(.A(p55), .Y(new_n224_));
  AND3x1_ASAP7_75t_R   g134(.A(new_n223_), .B(new_n224_), .C(p56), .Y(new_n225_));
  INVx1_ASAP7_75t_R    g135(.A(p40), .Y(new_n226_));
  NOR3x1_ASAP7_75t_R   g136(.A(new_n150_), .B(new_n226_), .C(p42), .Y(new_n227_));
  NOR2x1_ASAP7_75t_R   g137(.A(p39), .B(new_n191_), .Y(new_n228_));
  NOR2x1_ASAP7_75t_R   g138(.A(p37), .B(p36), .Y(new_n229_));
  NAND2x1_ASAP7_75t_R  g139(.A(p59), .B(p29), .Y(new_n230_));
  AND5x1_ASAP7_75t_R   g140(.A(new_n225_), .B(new_n227_), .C(new_n228_), .D(new_n229_), .E(new_n230_), .Y(new_n231_));
  NAND3x1_ASAP7_75t_R  g141(.A(new_n220_), .B(new_n222_), .C(new_n231_), .Y(new_n232_));
  INVx1_ASAP7_75t_R    g142(.A(new_n144_), .Y(new_n233_));
  NOR2x1_ASAP7_75t_R   g143(.A(p50), .B(p51), .Y(new_n234_));
  OA21x2_ASAP7_75t_R   g144(.A1(new_n234_), .A2(new_n233_), .B(new_n224_), .Y(new_n235_));
  OAI21x1_ASAP7_75t_R  g145(.A1(new_n233_), .A2(new_n207_), .B(new_n235_), .Y(new_n236_));
  NAND3x1_ASAP7_75t_R  g146(.A(new_n232_), .B(new_n145_), .C(new_n236_), .Y(new_n237_));
  AOI211x1_ASAP7_75t_R g147(.A1(new_n108_), .A2(new_n141_), .B(new_n212_), .C(new_n237_), .Y(o2));
  assign               o3 = 1'b0;
  assign               o4 = 1'b0;
  assign               o5 = 1'b0;
  assign               o6 = 1'b0;
  assign               o7 = 1'b0;
  assign               o8 = 1'b0;
  assign               o9 = 1'b0;
  assign               o10 = 1'b0;
  assign               o11 = 1'b0;
  assign               o12 = 1'b0;
  assign               o13 = 1'b0;
  assign               o14 = 1'b0;
  assign               o15 = 1'b0;
  assign               o16 = 1'b0;
  assign               o17 = 1'b0;
  assign               o18 = 1'b0;
  assign               o19 = 1'b0;
  assign               o20 = 1'b0;
  assign               o21 = 1'b0;
  assign               o22 = 1'b0;
  assign               o23 = 1'b0;
  assign               o24 = 1'b0;
  assign               o25 = 1'b0;
  assign               o26 = 1'b0;
  assign               o27 = 1'b0;
  assign               o28 = 1'b0;
  assign               o29 = 1'b0;
endmodule


