// Benchmark "/tmp/" written by ABC on Tue Oct 20 18:11:49 2026

module \/tmp/  ( 
    p17, p47, p2, p35, p11, p5, p49, p51, p43, p31, p39, p28, p33, p41, p3,
    p4, p56, p34, p52, p32, p37, p0, p22, p54, p26, p19, p12, p20, p46, p8,
    p44, p53, p21, p15, p7, p24, p50, p59, p16, p40, p25, p14, p38, p30,
    p23, p58, p18, p42, p36, p48, p1, p57, p29, p6, p9, p27, p55, p45, p10,
    p13,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25, o26, o27, o28, o29  );
  input  p17, p47, p2, p35, p11, p5, p49, p51, p43, p31, p39, p28, p33,
    p41, p3, p4, p56, p34, p52, p32, p37, p0, p22, p54, p26, p19, p12, p20,
    p46, p8, p44, p53, p21, p15, p7, p24, p50, p59, p16, p40, p25, p14,
    p38, p30, p23, p58, p18, p42, p36, p48, p1, p57, p29, p6, p9, p27, p55,
    p45, p10, p13;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25, o26, o27, o28, o29;
  wire new_n91_, new_n92_, new_n93_, new_n94_, new_n95_, new_n96_, new_n97_,
    new_n98_, new_n99_, new_n100_, new_n101_, new_n102_, new_n103_,
    new_n104_, new_n105_, new_n106_, new_n107_, new_n108_, new_n109_,
    new_n110_, new_n111_, new_n112_, new_n113_, new_n114_, new_n115_,
    new_n116_, new_n117_, new_n118_, new_n119_, new_n120_, new_n121_,
    new_n122_, new_n123_, new_n124_, new_n125_, new_n126_, new_n127_,
    new_n128_, new_n129_, new_n130_, new_n131_, new_n132_, new_n133_,
    new_n134_, new_n135_, new_n136_, new_n137_, new_n138_, new_n139_,
    new_n140_, new_n141_, new_n142_, new_n143_, new_n144_, new_n145_,
    new_n146_, new_n148_, new_n149_, new_n150_, new_n151_, new_n152_,
    new_n153_, new_n154_, new_n155_, new_n156_, new_n157_, new_n158_,
    new_n159_, new_n160_, new_n161_, new_n162_, new_n163_, new_n164_,
    new_n165_, new_n166_, new_n167_, new_n168_, new_n169_, new_n170_,
    new_n171_, new_n172_, new_n173_, new_n174_, new_n175_, new_n176_,
    new_n177_, new_n178_, new_n179_, new_n180_, new_n181_, new_n182_,
    new_n183_, new_n184_, new_n185_, new_n186_, new_n187_, new_n188_,
    new_n189_, new_n190_, new_n191_, new_n192_, new_n193_, new_n194_,
    new_n195_, new_n196_, new_n197_, new_n198_, new_n199_, new_n200_,
    new_n201_, new_n202_, new_n203_, new_n204_, new_n205_, new_n206_,
    new_n207_, new_n208_, new_n209_, new_n210_, new_n211_, new_n212_,
    new_n213_, new_n214_, new_n215_, new_n217_, new_n218_, new_n219_,
    new_n220_, new_n221_, new_n222_, new_n223_, new_n224_, new_n225_,
    new_n226_, new_n227_, new_n228_, new_n229_, new_n230_, new_n231_,
    new_n232_, new_n233_, new_n234_, new_n235_, new_n236_, new_n237_,
    new_n238_, new_n239_, new_n240_, new_n241_, new_n242_, new_n243_,
    new_n244_;
  AND3x1_ASAP7_75t_R   g000(.A(p28), .B(p26), .C(p27), .Y(new_n91_));
  INVx1_ASAP7_75t_R    g001(.A(new_n91_), .Y(new_n92_));
  AND2x2_ASAP7_75t_R   g002(.A(p24), .B(p23), .Y(new_n93_));
  INVx1_ASAP7_75t_R    g003(.A(new_n93_), .Y(new_n94_));
  NOR2x1_ASAP7_75t_R   g004(.A(p11), .B(p12), .Y(new_n95_));
  OAI21x1_ASAP7_75t_R  g005(.A1(p8), .A2(p9), .B(p10), .Y(new_n96_));
  NAND2x1_ASAP7_75t_R  g006(.A(new_n95_), .B(new_n96_), .Y(new_n97_));
  NAND2x1_ASAP7_75t_R  g007(.A(p14), .B(p13), .Y(new_n98_));
  INVx1_ASAP7_75t_R    g008(.A(new_n98_), .Y(new_n99_));
  NAND3x1_ASAP7_75t_R  g009(.A(new_n97_), .B(p16), .C(new_n99_), .Y(new_n100_));
  NOR2x1_ASAP7_75t_R   g010(.A(p20), .B(p21), .Y(new_n101_));
  AO21x1_ASAP7_75t_R   g011(.A1(p15), .A2(p16), .B(p17), .Y(new_n102_));
  INVx1_ASAP7_75t_R    g012(.A(new_n102_), .Y(new_n103_));
  NAND2x1_ASAP7_75t_R  g013(.A(p19), .B(p18), .Y(new_n104_));
  INVx1_ASAP7_75t_R    g014(.A(p22), .Y(new_n105_));
  AOI21x1_ASAP7_75t_R  g015(.A1(new_n104_), .A2(new_n101_), .B(new_n105_), .Y(new_n106_));
  INVx1_ASAP7_75t_R    g016(.A(new_n106_), .Y(new_n107_));
  AO31x2_ASAP7_75t_R   g017(.A1(new_n100_), .A2(new_n101_), .A3(new_n103_), .B(new_n107_), .Y(new_n108_));
  NAND2x1_ASAP7_75t_R  g018(.A(p25), .B(new_n91_), .Y(new_n109_));
  OA31x2_ASAP7_75t_R   g019(.A1(new_n92_), .A2(new_n94_), .A3(new_n108_), .B1(new_n109_), .Y(new_n110_));
  INVx1_ASAP7_75t_R    g020(.A(p16), .Y(new_n111_));
  AOI211x1_ASAP7_75t_R g021(.A1(new_n95_), .A2(new_n96_), .B(new_n111_), .C(new_n98_), .Y(new_n112_));
  AO21x1_ASAP7_75t_R   g022(.A1(p15), .A2(p16), .B(new_n112_), .Y(new_n113_));
  INVx1_ASAP7_75t_R    g023(.A(p1), .Y(new_n114_));
  AND3x1_ASAP7_75t_R   g024(.A(new_n101_), .B(p22), .C(p19), .Y(new_n115_));
  INVx1_ASAP7_75t_R    g025(.A(p6), .Y(new_n116_));
  INVx1_ASAP7_75t_R    g026(.A(p9), .Y(new_n117_));
  AND5x1_ASAP7_75t_R   g027(.A(new_n114_), .B(new_n115_), .C(new_n116_), .D(new_n117_), .E(p10), .Y(new_n118_));
  NOR2x1_ASAP7_75t_R   g028(.A(p4), .B(p0), .Y(new_n119_));
  NOR2x1_ASAP7_75t_R   g029(.A(p17), .B(p2), .Y(new_n120_));
  NOR2x1_ASAP7_75t_R   g030(.A(p5), .B(p3), .Y(new_n121_));
  INVx1_ASAP7_75t_R    g031(.A(p7), .Y(new_n122_));
  AND5x1_ASAP7_75t_R   g032(.A(p8), .B(new_n119_), .C(new_n120_), .D(new_n121_), .E(new_n122_), .Y(new_n123_));
  OAI21x1_ASAP7_75t_R  g033(.A1(p8), .A2(p9), .B(p15), .Y(new_n124_));
  INVx1_ASAP7_75t_R    g034(.A(p25), .Y(new_n125_));
  AND5x1_ASAP7_75t_R   g035(.A(new_n125_), .B(new_n99_), .C(p18), .D(new_n93_), .E(new_n95_), .Y(new_n126_));
  AND5x1_ASAP7_75t_R   g036(.A(new_n113_), .B(new_n118_), .C(new_n123_), .D(new_n124_), .E(new_n126_), .Y(new_n127_));
  NAND2x1_ASAP7_75t_R  g037(.A(new_n103_), .B(new_n100_), .Y(new_n128_));
  AND3x1_ASAP7_75t_R   g038(.A(p1), .B(p6), .C(p10), .Y(new_n129_));
  AND5x1_ASAP7_75t_R   g039(.A(p24), .B(new_n129_), .C(p59), .D(p14), .E(p13), .Y(new_n130_));
  NAND2x1_ASAP7_75t_R  g040(.A(new_n115_), .B(new_n130_), .Y(new_n131_));
  AOI211x1_ASAP7_75t_R g041(.A1(new_n99_), .A2(new_n97_), .B(p15), .C(p16), .Y(new_n132_));
  NOR2x1_ASAP7_75t_R   g042(.A(p8), .B(p9), .Y(new_n133_));
  AND3x1_ASAP7_75t_R   g043(.A(new_n133_), .B(new_n125_), .C(p18), .Y(new_n134_));
  AND2x2_ASAP7_75t_R   g044(.A(p28), .B(p27), .Y(new_n135_));
  NAND3x1_ASAP7_75t_R  g045(.A(new_n134_), .B(new_n135_), .C(new_n95_), .Y(new_n136_));
  NAND2x1_ASAP7_75t_R  g046(.A(p0), .B(p26), .Y(new_n137_));
  NAND2x1_ASAP7_75t_R  g047(.A(p3), .B(p4), .Y(new_n138_));
  NAND2x1_ASAP7_75t_R  g048(.A(p2), .B(p5), .Y(new_n139_));
  OR5x1_ASAP7_75t_R    g049(.A(p15), .B(new_n137_), .C(new_n138_), .D(new_n139_), .E(new_n122_), .Y(new_n140_));
  OR5x1_ASAP7_75t_R    g050(.A(new_n128_), .B(new_n131_), .C(new_n132_), .D(new_n136_), .E(new_n140_), .Y(new_n141_));
  INVx1_ASAP7_75t_R    g051(.A(new_n101_), .Y(new_n142_));
  AOI21x1_ASAP7_75t_R  g052(.A1(p22), .A2(new_n142_), .B(p23), .Y(new_n143_));
  OA31x2_ASAP7_75t_R   g053(.A1(new_n142_), .A2(new_n102_), .A3(new_n112_), .B1(new_n106_), .Y(new_n144_));
  AOI21x1_ASAP7_75t_R  g054(.A1(new_n93_), .A2(new_n144_), .B(p25), .Y(new_n145_));
  OAI22x1_ASAP7_75t_R  g055(.A1(new_n141_), .A2(new_n143_), .B1(new_n92_), .B2(new_n145_), .Y(new_n146_));
  OAI21x1_ASAP7_75t_R  g056(.A1(new_n110_), .A2(new_n127_), .B(new_n146_), .Y(o0));
  NOR3x1_ASAP7_75t_R   g057(.A(new_n127_), .B(new_n145_), .C(new_n92_), .Y(new_n148_));
  NAND2x1_ASAP7_75t_R  g058(.A(p49), .B(p48), .Y(new_n149_));
  NOR2x1_ASAP7_75t_R   g059(.A(p41), .B(p42), .Y(new_n150_));
  OAI21x1_ASAP7_75t_R  g060(.A1(p39), .A2(p38), .B(p40), .Y(new_n151_));
  NAND2x1_ASAP7_75t_R  g061(.A(p43), .B(p44), .Y(new_n152_));
  AOI21x1_ASAP7_75t_R  g062(.A1(new_n150_), .A2(new_n151_), .B(new_n152_), .Y(new_n153_));
  AO21x1_ASAP7_75t_R   g063(.A1(p46), .A2(p45), .B(p47), .Y(new_n154_));
  AOI21x1_ASAP7_75t_R  g064(.A1(p46), .A2(new_n153_), .B(new_n154_), .Y(new_n155_));
  INVx1_ASAP7_75t_R    g065(.A(p51), .Y(new_n156_));
  INVx1_ASAP7_75t_R    g066(.A(p50), .Y(new_n157_));
  INVx1_ASAP7_75t_R    g067(.A(p55), .Y(new_n158_));
  AND3x1_ASAP7_75t_R   g068(.A(new_n156_), .B(new_n157_), .C(new_n158_), .Y(new_n159_));
  OAI21x1_ASAP7_75t_R  g069(.A1(new_n149_), .A2(new_n155_), .B(new_n159_), .Y(new_n160_));
  AND3x1_ASAP7_75t_R   g070(.A(p52), .B(p54), .C(p53), .Y(new_n161_));
  AND3x1_ASAP7_75t_R   g071(.A(p56), .B(p58), .C(p57), .Y(new_n162_));
  OA21x2_ASAP7_75t_R   g072(.A1(p55), .A2(new_n161_), .B(new_n162_), .Y(new_n163_));
  INVx1_ASAP7_75t_R    g073(.A(p59), .Y(new_n164_));
  AOI22x1_ASAP7_75t_R  g074(.A1(new_n160_), .A2(new_n163_), .B1(new_n157_), .B2(new_n164_), .Y(new_n165_));
  NAND2x1_ASAP7_75t_R  g075(.A(p52), .B(new_n156_), .Y(new_n166_));
  OAI21x1_ASAP7_75t_R  g076(.A1(new_n149_), .A2(new_n155_), .B(new_n166_), .Y(new_n167_));
  AND3x1_ASAP7_75t_R   g077(.A(p30), .B(p36), .C(p29), .Y(new_n168_));
  AND5x1_ASAP7_75t_R   g078(.A(p37), .B(new_n168_), .C(p46), .D(p44), .E(p40), .Y(new_n169_));
  AND2x2_ASAP7_75t_R   g079(.A(p33), .B(p34), .Y(new_n170_));
  AND2x2_ASAP7_75t_R   g080(.A(p31), .B(p32), .Y(new_n171_));
  AND2x2_ASAP7_75t_R   g081(.A(p35), .B(p49), .Y(new_n172_));
  NOR2x1_ASAP7_75t_R   g082(.A(p39), .B(p38), .Y(new_n173_));
  AND4x2_ASAP7_75t_R   g083(.A(new_n170_), .B(new_n171_), .C(new_n172_), .D(new_n173_), .Y(new_n174_));
  AND2x2_ASAP7_75t_R   g084(.A(p54), .B(p53), .Y(new_n175_));
  NOR2x1_ASAP7_75t_R   g085(.A(p55), .B(p45), .Y(new_n176_));
  AND3x1_ASAP7_75t_R   g086(.A(new_n162_), .B(new_n175_), .C(new_n176_), .Y(new_n177_));
  AND2x2_ASAP7_75t_R   g087(.A(p46), .B(p45), .Y(new_n178_));
  AO21x1_ASAP7_75t_R   g088(.A1(p47), .A2(new_n178_), .B(p48), .Y(new_n179_));
  NAND2x1_ASAP7_75t_R  g089(.A(p48), .B(new_n154_), .Y(new_n180_));
  AND5x1_ASAP7_75t_R   g090(.A(new_n169_), .B(new_n174_), .C(new_n177_), .D(new_n179_), .E(new_n180_), .Y(new_n181_));
  INVx1_ASAP7_75t_R    g091(.A(p41), .Y(new_n182_));
  NOR2x1_ASAP7_75t_R   g092(.A(new_n182_), .B(new_n151_), .Y(new_n183_));
  AOI21x1_ASAP7_75t_R  g093(.A1(p42), .A2(new_n183_), .B(p43), .Y(new_n184_));
  NAND2x1_ASAP7_75t_R  g094(.A(new_n182_), .B(new_n151_), .Y(new_n185_));
  OA21x2_ASAP7_75t_R   g095(.A1(p42), .A2(new_n185_), .B(p43), .Y(new_n186_));
  NOR2x1_ASAP7_75t_R   g096(.A(new_n184_), .B(new_n186_), .Y(new_n187_));
  NAND3x1_ASAP7_75t_R  g097(.A(new_n167_), .B(new_n181_), .C(new_n187_), .Y(new_n188_));
  INVx1_ASAP7_75t_R    g098(.A(p47), .Y(new_n189_));
  OR2x4_ASAP7_75t_R    g099(.A(p45), .B(new_n189_), .Y(new_n190_));
  NOR2x1_ASAP7_75t_R   g100(.A(new_n153_), .B(new_n190_), .Y(new_n191_));
  AO21x1_ASAP7_75t_R   g101(.A1(p46), .A2(new_n153_), .B(new_n178_), .Y(new_n192_));
  NOR2x1_ASAP7_75t_R   g102(.A(p59), .B(p29), .Y(new_n193_));
  OAI21x1_ASAP7_75t_R  g103(.A1(new_n191_), .A2(new_n192_), .B(new_n193_), .Y(new_n194_));
  INVx1_ASAP7_75t_R    g104(.A(p37), .Y(new_n195_));
  AND4x2_ASAP7_75t_R   g105(.A(new_n195_), .B(new_n157_), .C(p40), .D(p38), .Y(new_n196_));
  INVx1_ASAP7_75t_R    g106(.A(p56), .Y(new_n197_));
  NOR3x1_ASAP7_75t_R   g107(.A(new_n152_), .B(p39), .C(new_n197_), .Y(new_n198_));
  INVx1_ASAP7_75t_R    g108(.A(p42), .Y(new_n199_));
  NOR3x1_ASAP7_75t_R   g109(.A(p36), .B(p55), .C(p45), .Y(new_n200_));
  AND4x2_ASAP7_75t_R   g110(.A(new_n196_), .B(new_n198_), .C(new_n199_), .D(new_n200_), .Y(new_n201_));
  INVx1_ASAP7_75t_R    g111(.A(new_n149_), .Y(new_n202_));
  NAND2x1_ASAP7_75t_R  g112(.A(p47), .B(p46), .Y(new_n203_));
  NOR2x1_ASAP7_75t_R   g113(.A(p35), .B(p31), .Y(new_n204_));
  AND5x1_ASAP7_75t_R   g114(.A(new_n185_), .B(new_n202_), .C(new_n175_), .D(new_n203_), .E(new_n204_), .Y(new_n205_));
  OR4x2_ASAP7_75t_R    g115(.A(p33), .B(p34), .C(p32), .D(p30), .Y(new_n206_));
  NOR3x1_ASAP7_75t_R   g116(.A(new_n183_), .B(new_n206_), .C(new_n166_), .Y(new_n207_));
  NAND3x1_ASAP7_75t_R  g117(.A(new_n201_), .B(new_n205_), .C(new_n207_), .Y(new_n208_));
  INVx1_ASAP7_75t_R    g118(.A(p46), .Y(new_n209_));
  AOI211x1_ASAP7_75t_R g119(.A1(new_n150_), .A2(new_n151_), .B(new_n209_), .C(new_n152_), .Y(new_n210_));
  OAI21x1_ASAP7_75t_R  g120(.A1(new_n154_), .A2(new_n210_), .B(new_n202_), .Y(new_n211_));
  INVx1_ASAP7_75t_R    g121(.A(new_n163_), .Y(new_n212_));
  AOI21x1_ASAP7_75t_R  g122(.A1(new_n159_), .A2(new_n211_), .B(new_n212_), .Y(new_n213_));
  OAI21x1_ASAP7_75t_R  g123(.A1(new_n194_), .A2(new_n208_), .B(new_n213_), .Y(new_n214_));
  OAI21x1_ASAP7_75t_R  g124(.A1(new_n165_), .A2(new_n188_), .B(new_n214_), .Y(new_n215_));
  OAI21x1_ASAP7_75t_R  g125(.A1(new_n148_), .A2(new_n215_), .B(new_n146_), .Y(o1));
  AND3x1_ASAP7_75t_R   g126(.A(new_n134_), .B(new_n135_), .C(new_n95_), .Y(new_n217_));
  INVx1_ASAP7_75t_R    g127(.A(new_n140_), .Y(new_n218_));
  NAND2x1_ASAP7_75t_R  g128(.A(new_n217_), .B(new_n218_), .Y(new_n219_));
  OR5x1_ASAP7_75t_R    g129(.A(new_n128_), .B(new_n219_), .C(new_n143_), .D(new_n132_), .E(new_n131_), .Y(new_n220_));
  NOR2x1_ASAP7_75t_R   g130(.A(new_n178_), .B(new_n210_), .Y(new_n221_));
  OAI21x1_ASAP7_75t_R  g131(.A1(new_n153_), .A2(new_n190_), .B(new_n221_), .Y(new_n222_));
  NOR2x1_ASAP7_75t_R   g132(.A(p50), .B(p45), .Y(new_n223_));
  AND3x1_ASAP7_75t_R   g133(.A(new_n223_), .B(p56), .C(new_n158_), .Y(new_n224_));
  INVx1_ASAP7_75t_R    g134(.A(p40), .Y(new_n225_));
  NOR3x1_ASAP7_75t_R   g135(.A(new_n152_), .B(new_n225_), .C(p42), .Y(new_n226_));
  INVx1_ASAP7_75t_R    g136(.A(p38), .Y(new_n227_));
  NOR2x1_ASAP7_75t_R   g137(.A(p39), .B(new_n227_), .Y(new_n228_));
  NOR2x1_ASAP7_75t_R   g138(.A(p37), .B(p36), .Y(new_n229_));
  NAND2x1_ASAP7_75t_R  g139(.A(p59), .B(p29), .Y(new_n230_));
  AND5x1_ASAP7_75t_R   g140(.A(new_n224_), .B(new_n226_), .C(new_n228_), .D(new_n229_), .E(new_n230_), .Y(new_n231_));
  NOR2x1_ASAP7_75t_R   g141(.A(p31), .B(p30), .Y(new_n232_));
  NOR2x1_ASAP7_75t_R   g142(.A(p35), .B(p34), .Y(new_n233_));
  NOR2x1_ASAP7_75t_R   g143(.A(p33), .B(p32), .Y(new_n234_));
  AND5x1_ASAP7_75t_R   g144(.A(p54), .B(new_n232_), .C(new_n233_), .D(new_n234_), .E(p53), .Y(new_n235_));
  OR3x1_ASAP7_75t_R    g145(.A(new_n173_), .B(new_n182_), .C(new_n225_), .Y(new_n236_));
  NOR2x1_ASAP7_75t_R   g146(.A(new_n149_), .B(new_n166_), .Y(new_n237_));
  AND5x1_ASAP7_75t_R   g147(.A(new_n185_), .B(new_n235_), .C(new_n236_), .D(new_n237_), .E(new_n203_), .Y(new_n238_));
  NAND3x1_ASAP7_75t_R  g148(.A(new_n222_), .B(new_n231_), .C(new_n238_), .Y(new_n239_));
  INVx1_ASAP7_75t_R    g149(.A(new_n161_), .Y(new_n240_));
  NOR2x1_ASAP7_75t_R   g150(.A(p51), .B(p50), .Y(new_n241_));
  OA21x2_ASAP7_75t_R   g151(.A1(new_n241_), .A2(new_n240_), .B(new_n158_), .Y(new_n242_));
  OAI21x1_ASAP7_75t_R  g152(.A1(new_n240_), .A2(new_n211_), .B(new_n242_), .Y(new_n243_));
  NAND3x1_ASAP7_75t_R  g153(.A(new_n239_), .B(new_n162_), .C(new_n243_), .Y(new_n244_));
  AOI211x1_ASAP7_75t_R g154(.A1(new_n110_), .A2(new_n220_), .B(new_n148_), .C(new_n244_), .Y(o2));
  assign               o3 = 1'b0;
  assign               o4 = 1'b0;
  assign               o5 = 1'b0;
  assign               o6 = 1'b0;
  assign               o7 = 1'b0;
  assign               o8 = 1'b0;
  assign               o9 = 1'b0;
  assign               o10 = 1'b0;
  assign               o11 = 1'b0;
  assign               o12 = 1'b0;
  assign               o13 = 1'b0;
  assign               o14 = 1'b0;
  assign               o15 = 1'b0;
  assign               o16 = 1'b0;
  assign               o17 = 1'b0;
  assign               o18 = 1'b0;
  assign               o19 = 1'b0;
  assign               o20 = 1'b0;
  assign               o21 = 1'b0;
  assign               o22 = 1'b0;
  assign               o23 = 1'b0;
  assign               o24 = 1'b0;
  assign               o25 = 1'b0;
  assign               o26 = 1'b0;
  assign               o27 = 1'b0;
  assign               o28 = 1'b0;
  assign               o29 = 1'b0;
endmodule


