// Benchmark "/tmp/" written by ABC on Tue Oct 20 18:11:51 2026

module \/tmp/  ( 
    p18, p50, p56, p49, p31, p47, p2, p36, p0, p21, p38, p1, p54, p4, p9,
    p44, p10, p25, p5, p22, p48, p59, p41, p19, p12, p30, p13, p24, p53,
    p3, p15, p14, p32, p23, p37, p20, p40, p26, p27, p16, p8, p51, p39,
    p35, p11, p17, p7, p29, p6, p58, p52, p42, p45, p57, p43, p46, p34,
    p28, p55, p33,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25, o26, o27, o28, o29  );
  input  p18, p50, p56, p49, p31, p47, p2, p36, p0, p21, p38, p1, p54,
    p4, p9, p44, p10, p25, p5, p22, p48, p59, p41, p19, p12, p30, p13, p24,
    p53, p3, p15, p14, p32, p23, p37, p20, p40, p26, p27, p16, p8, p51,
    p39, p35, p11, p17, p7, p29, p6, p58, p52, p42, p45, p57, p43, p46,
    p34, p28, p55, p33;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25, o26, o27, o28, o29;
  wire new_n91_, new_n92_, new_n93_, new_n94_, new_n95_, new_n96_, new_n97_,
    new_n98_, new_n99_, new_n100_, new_n101_, new_n102_, new_n103_,
    new_n104_, new_n105_, new_n106_, new_n107_, new_n108_, new_n109_,
    new_n110_, new_n111_, new_n112_, new_n113_, new_n114_, new_n115_,
    new_n116_, new_n117_, new_n118_, new_n119_, new_n120_, new_n121_,
    new_n122_, new_n123_, new_n124_, new_n125_, new_n126_, new_n127_,
    new_n128_, new_n129_, new_n130_, new_n131_, new_n132_, new_n133_,
    new_n134_, new_n135_, new_n136_, new_n137_, new_n138_, new_n139_,
    new_n140_, new_n141_, new_n142_, new_n143_, new_n145_, new_n146_,
    new_n147_, new_n148_, new_n149_, new_n150_, new_n151_, new_n152_,
    new_n153_, new_n154_, new_n155_, new_n156_, new_n157_, new_n158_,
    new_n159_, new_n160_, new_n161_, new_n162_, new_n163_, new_n164_,
    new_n165_, new_n166_, new_n167_, new_n168_, new_n169_, new_n170_,
    new_n171_, new_n172_, new_n173_, new_n174_, new_n175_, new_n176_,
    new_n177_, new_n178_, new_n179_, new_n180_, new_n181_, new_n182_,
    new_n183_, new_n184_, new_n185_, new_n186_, new_n187_, new_n188_,
    new_n189_, new_n190_, new_n191_, new_n192_, new_n193_, new_n194_,
    new_n195_, new_n196_, new_n197_, new_n198_, new_n199_, new_n200_,
    new_n201_, new_n202_, new_n203_, new_n204_, new_n205_, new_n206_,
    new_n207_, new_n208_, new_n209_, new_n210_, new_n211_, new_n212_,
    new_n213_, new_n214_, new_n215_, new_n217_, new_n218_, new_n219_,
    new_n220_, new_n221_, new_n222_, new_n223_, new_n224_, new_n225_,
    new_n226_, new_n227_, new_n228_, new_n229_, new_n230_, new_n231_,
    new_n232_, new_n233_, new_n234_, new_n235_, new_n236_, new_n237_,
    new_n238_, new_n239_, new_n240_, new_n241_;
  AND3x1_ASAP7_75t_R   g000(.A(p26), .B(p27), .C(p28), .Y(new_n91_));
  INVx1_ASAP7_75t_R    g001(.A(new_n91_), .Y(new_n92_));
  AND2x2_ASAP7_75t_R   g002(.A(p24), .B(p23), .Y(new_n93_));
  INVx1_ASAP7_75t_R    g003(.A(new_n93_), .Y(new_n94_));
  NOR2x1_ASAP7_75t_R   g004(.A(p21), .B(p20), .Y(new_n95_));
  INVx1_ASAP7_75t_R    g005(.A(new_n95_), .Y(new_n96_));
  NOR2x1_ASAP7_75t_R   g006(.A(p12), .B(p11), .Y(new_n97_));
  OAI21x1_ASAP7_75t_R  g007(.A1(p9), .A2(p8), .B(p10), .Y(new_n98_));
  NAND2x1_ASAP7_75t_R  g008(.A(new_n97_), .B(new_n98_), .Y(new_n99_));
  NAND2x1_ASAP7_75t_R  g009(.A(p13), .B(p14), .Y(new_n100_));
  INVx1_ASAP7_75t_R    g010(.A(new_n100_), .Y(new_n101_));
  AO21x1_ASAP7_75t_R   g011(.A1(p15), .A2(p16), .B(p17), .Y(new_n102_));
  AO31x2_ASAP7_75t_R   g012(.A1(new_n99_), .A2(p16), .A3(new_n101_), .B(new_n102_), .Y(new_n103_));
  NAND2x1_ASAP7_75t_R  g013(.A(p18), .B(p19), .Y(new_n104_));
  INVx1_ASAP7_75t_R    g014(.A(p22), .Y(new_n105_));
  AOI21x1_ASAP7_75t_R  g015(.A1(new_n104_), .A2(new_n95_), .B(new_n105_), .Y(new_n106_));
  OAI21x1_ASAP7_75t_R  g016(.A1(new_n96_), .A2(new_n103_), .B(new_n106_), .Y(new_n107_));
  NAND2x1_ASAP7_75t_R  g017(.A(p25), .B(new_n91_), .Y(new_n108_));
  OA31x2_ASAP7_75t_R   g018(.A1(new_n92_), .A2(new_n94_), .A3(new_n107_), .B1(new_n108_), .Y(new_n109_));
  INVx1_ASAP7_75t_R    g019(.A(p16), .Y(new_n110_));
  AOI211x1_ASAP7_75t_R g020(.A1(new_n97_), .A2(new_n98_), .B(new_n110_), .C(new_n100_), .Y(new_n111_));
  AO21x1_ASAP7_75t_R   g021(.A1(p15), .A2(p16), .B(new_n111_), .Y(new_n112_));
  INVx1_ASAP7_75t_R    g022(.A(p3), .Y(new_n113_));
  INVx1_ASAP7_75t_R    g023(.A(p10), .Y(new_n114_));
  NOR2x1_ASAP7_75t_R   g024(.A(p9), .B(new_n114_), .Y(new_n115_));
  NOR2x1_ASAP7_75t_R   g025(.A(p5), .B(p12), .Y(new_n116_));
  NOR2x1_ASAP7_75t_R   g026(.A(p1), .B(p4), .Y(new_n117_));
  AND5x1_ASAP7_75t_R   g027(.A(new_n113_), .B(new_n115_), .C(p8), .D(new_n116_), .E(new_n117_), .Y(new_n118_));
  AND3x1_ASAP7_75t_R   g028(.A(new_n95_), .B(p22), .C(p19), .Y(new_n119_));
  NOR2x1_ASAP7_75t_R   g029(.A(p7), .B(p6), .Y(new_n120_));
  NOR2x1_ASAP7_75t_R   g030(.A(p11), .B(p17), .Y(new_n121_));
  AND3x1_ASAP7_75t_R   g031(.A(new_n119_), .B(new_n120_), .C(new_n121_), .Y(new_n122_));
  NOR2x1_ASAP7_75t_R   g032(.A(p9), .B(p8), .Y(new_n123_));
  INVx1_ASAP7_75t_R    g033(.A(p15), .Y(new_n124_));
  OR3x1_ASAP7_75t_R    g034(.A(new_n123_), .B(new_n114_), .C(new_n124_), .Y(new_n125_));
  INVx1_ASAP7_75t_R    g035(.A(p18), .Y(new_n126_));
  NOR2x1_ASAP7_75t_R   g036(.A(p25), .B(new_n126_), .Y(new_n127_));
  NOR2x1_ASAP7_75t_R   g037(.A(p2), .B(p0), .Y(new_n128_));
  AND5x1_ASAP7_75t_R   g038(.A(p13), .B(new_n127_), .C(p14), .D(new_n93_), .E(new_n128_), .Y(new_n129_));
  AND5x1_ASAP7_75t_R   g039(.A(new_n112_), .B(new_n118_), .C(new_n122_), .D(new_n125_), .E(new_n129_), .Y(new_n130_));
  OA31x2_ASAP7_75t_R   g040(.A1(new_n96_), .A2(new_n102_), .A3(new_n111_), .B1(new_n106_), .Y(new_n131_));
  AOI21x1_ASAP7_75t_R  g041(.A1(new_n93_), .A2(new_n131_), .B(p25), .Y(new_n132_));
  AOI211x1_ASAP7_75t_R g042(.A1(new_n101_), .A2(new_n99_), .B(p15), .C(p16), .Y(new_n133_));
  AND4x2_ASAP7_75t_R   g043(.A(new_n124_), .B(p14), .C(p7), .D(p6), .Y(new_n134_));
  NAND3x1_ASAP7_75t_R  g044(.A(new_n119_), .B(new_n91_), .C(new_n134_), .Y(new_n135_));
  AND3x1_ASAP7_75t_R   g045(.A(new_n97_), .B(p2), .C(p0), .Y(new_n136_));
  NAND3x1_ASAP7_75t_R  g046(.A(new_n136_), .B(new_n123_), .C(new_n127_), .Y(new_n137_));
  AND4x2_ASAP7_75t_R   g047(.A(p1), .B(p4), .C(p10), .D(p5), .Y(new_n138_));
  AND4x2_ASAP7_75t_R   g048(.A(p59), .B(p13), .C(p24), .D(p3), .Y(new_n139_));
  NAND2x1_ASAP7_75t_R  g049(.A(new_n138_), .B(new_n139_), .Y(new_n140_));
  OR5x1_ASAP7_75t_R    g050(.A(new_n133_), .B(new_n103_), .C(new_n135_), .D(new_n137_), .E(new_n140_), .Y(new_n141_));
  AOI21x1_ASAP7_75t_R  g051(.A1(p22), .A2(new_n96_), .B(p23), .Y(new_n142_));
  OAI22x1_ASAP7_75t_R  g052(.A1(new_n132_), .A2(new_n92_), .B1(new_n141_), .B2(new_n142_), .Y(new_n143_));
  OAI21x1_ASAP7_75t_R  g053(.A1(new_n109_), .A2(new_n130_), .B(new_n143_), .Y(o0));
  NAND2x1_ASAP7_75t_R  g054(.A(p49), .B(p48), .Y(new_n145_));
  AND3x1_ASAP7_75t_R   g055(.A(p44), .B(p43), .C(p46), .Y(new_n146_));
  NOR2x1_ASAP7_75t_R   g056(.A(p41), .B(p42), .Y(new_n147_));
  OAI21x1_ASAP7_75t_R  g057(.A1(p38), .A2(p39), .B(p40), .Y(new_n148_));
  NAND2x1_ASAP7_75t_R  g058(.A(new_n147_), .B(new_n148_), .Y(new_n149_));
  AO21x1_ASAP7_75t_R   g059(.A1(p45), .A2(p46), .B(p47), .Y(new_n150_));
  AOI21x1_ASAP7_75t_R  g060(.A1(new_n146_), .A2(new_n149_), .B(new_n150_), .Y(new_n151_));
  INVx1_ASAP7_75t_R    g061(.A(p50), .Y(new_n152_));
  INVx1_ASAP7_75t_R    g062(.A(p51), .Y(new_n153_));
  INVx1_ASAP7_75t_R    g063(.A(p55), .Y(new_n154_));
  AND3x1_ASAP7_75t_R   g064(.A(new_n152_), .B(new_n153_), .C(new_n154_), .Y(new_n155_));
  OAI21x1_ASAP7_75t_R  g065(.A1(new_n145_), .A2(new_n151_), .B(new_n155_), .Y(new_n156_));
  AND3x1_ASAP7_75t_R   g066(.A(p54), .B(p53), .C(p52), .Y(new_n157_));
  AND3x1_ASAP7_75t_R   g067(.A(p56), .B(p58), .C(p57), .Y(new_n158_));
  OA21x2_ASAP7_75t_R   g068(.A1(p55), .A2(new_n157_), .B(new_n158_), .Y(new_n159_));
  INVx1_ASAP7_75t_R    g069(.A(p59), .Y(new_n160_));
  AOI22x1_ASAP7_75t_R  g070(.A1(new_n156_), .A2(new_n159_), .B1(new_n152_), .B2(new_n160_), .Y(new_n161_));
  AND2x2_ASAP7_75t_R   g071(.A(p34), .B(p33), .Y(new_n162_));
  INVx1_ASAP7_75t_R    g072(.A(p45), .Y(new_n163_));
  AND3x1_ASAP7_75t_R   g073(.A(new_n162_), .B(p35), .C(new_n163_), .Y(new_n164_));
  AND4x2_ASAP7_75t_R   g074(.A(p30), .B(p32), .C(p37), .D(p40), .Y(new_n165_));
  AND2x2_ASAP7_75t_R   g075(.A(p49), .B(p31), .Y(new_n166_));
  AND2x2_ASAP7_75t_R   g076(.A(p36), .B(p44), .Y(new_n167_));
  AND3x1_ASAP7_75t_R   g077(.A(new_n165_), .B(new_n166_), .C(new_n167_), .Y(new_n168_));
  INVx1_ASAP7_75t_R    g078(.A(p47), .Y(new_n169_));
  INVx1_ASAP7_75t_R    g079(.A(p48), .Y(new_n170_));
  NAND2x1_ASAP7_75t_R  g080(.A(p54), .B(p53), .Y(new_n171_));
  INVx1_ASAP7_75t_R    g081(.A(p38), .Y(new_n172_));
  INVx1_ASAP7_75t_R    g082(.A(p39), .Y(new_n173_));
  NAND2x1_ASAP7_75t_R  g083(.A(new_n172_), .B(new_n173_), .Y(new_n174_));
  AOI211x1_ASAP7_75t_R g084(.A1(new_n169_), .A2(new_n170_), .B(new_n171_), .C(new_n174_), .Y(new_n175_));
  AND2x2_ASAP7_75t_R   g085(.A(p29), .B(p46), .Y(new_n176_));
  AND3x1_ASAP7_75t_R   g086(.A(new_n158_), .B(new_n176_), .C(new_n154_), .Y(new_n177_));
  NAND2x1_ASAP7_75t_R  g087(.A(p45), .B(p46), .Y(new_n178_));
  OAI21x1_ASAP7_75t_R  g088(.A1(p48), .A2(new_n178_), .B(new_n150_), .Y(new_n179_));
  AND5x1_ASAP7_75t_R   g089(.A(new_n164_), .B(new_n168_), .C(new_n175_), .D(new_n177_), .E(new_n179_), .Y(new_n180_));
  NAND2x1_ASAP7_75t_R  g090(.A(p52), .B(new_n153_), .Y(new_n181_));
  OAI21x1_ASAP7_75t_R  g091(.A1(new_n145_), .A2(new_n151_), .B(new_n181_), .Y(new_n182_));
  INVx1_ASAP7_75t_R    g092(.A(p41), .Y(new_n183_));
  NOR2x1_ASAP7_75t_R   g093(.A(new_n183_), .B(new_n148_), .Y(new_n184_));
  AOI21x1_ASAP7_75t_R  g094(.A1(p42), .A2(new_n184_), .B(p43), .Y(new_n185_));
  AOI21x1_ASAP7_75t_R  g095(.A1(p43), .A2(new_n149_), .B(new_n185_), .Y(new_n186_));
  NAND3x1_ASAP7_75t_R  g096(.A(new_n180_), .B(new_n182_), .C(new_n186_), .Y(new_n187_));
  NAND2x1_ASAP7_75t_R  g097(.A(p38), .B(p40), .Y(new_n188_));
  OR3x1_ASAP7_75t_R    g098(.A(new_n188_), .B(p36), .C(p37), .Y(new_n189_));
  NAND2x1_ASAP7_75t_R  g099(.A(p44), .B(p43), .Y(new_n190_));
  INVx1_ASAP7_75t_R    g100(.A(p56), .Y(new_n191_));
  OR3x1_ASAP7_75t_R    g101(.A(new_n190_), .B(p50), .C(new_n191_), .Y(new_n192_));
  OR4x2_ASAP7_75t_R    g102(.A(p39), .B(p42), .C(p45), .D(p55), .Y(new_n193_));
  NOR3x1_ASAP7_75t_R   g103(.A(new_n189_), .B(new_n192_), .C(new_n193_), .Y(new_n194_));
  NOR2x1_ASAP7_75t_R   g104(.A(p31), .B(p30), .Y(new_n195_));
  NAND3x1_ASAP7_75t_R  g105(.A(new_n195_), .B(p54), .C(p53), .Y(new_n196_));
  AO21x1_ASAP7_75t_R   g106(.A1(p47), .A2(p46), .B(new_n145_), .Y(new_n197_));
  AOI211x1_ASAP7_75t_R g107(.A1(new_n183_), .A2(new_n148_), .B(new_n196_), .C(new_n197_), .Y(new_n198_));
  OR4x2_ASAP7_75t_R    g108(.A(p32), .B(p35), .C(p34), .D(p33), .Y(new_n199_));
  NOR3x1_ASAP7_75t_R   g109(.A(new_n184_), .B(new_n199_), .C(new_n181_), .Y(new_n200_));
  NAND3x1_ASAP7_75t_R  g110(.A(new_n194_), .B(new_n198_), .C(new_n200_), .Y(new_n201_));
  AO22x1_ASAP7_75t_R   g111(.A1(p45), .A2(p46), .B1(new_n146_), .B2(new_n149_), .Y(new_n202_));
  INVx1_ASAP7_75t_R    g112(.A(new_n190_), .Y(new_n203_));
  AOI211x1_ASAP7_75t_R g113(.A1(new_n203_), .A2(new_n149_), .B(new_n169_), .C(p45), .Y(new_n204_));
  NOR2x1_ASAP7_75t_R   g114(.A(p59), .B(p29), .Y(new_n205_));
  OAI21x1_ASAP7_75t_R  g115(.A1(new_n202_), .A2(new_n204_), .B(new_n205_), .Y(new_n206_));
  INVx1_ASAP7_75t_R    g116(.A(p46), .Y(new_n207_));
  AOI211x1_ASAP7_75t_R g117(.A1(new_n147_), .A2(new_n148_), .B(new_n207_), .C(new_n190_), .Y(new_n208_));
  INVx1_ASAP7_75t_R    g118(.A(new_n145_), .Y(new_n209_));
  OAI21x1_ASAP7_75t_R  g119(.A1(new_n150_), .A2(new_n208_), .B(new_n209_), .Y(new_n210_));
  INVx1_ASAP7_75t_R    g120(.A(new_n159_), .Y(new_n211_));
  AOI21x1_ASAP7_75t_R  g121(.A1(new_n155_), .A2(new_n210_), .B(new_n211_), .Y(new_n212_));
  OAI21x1_ASAP7_75t_R  g122(.A1(new_n201_), .A2(new_n206_), .B(new_n212_), .Y(new_n213_));
  OAI21x1_ASAP7_75t_R  g123(.A1(new_n161_), .A2(new_n187_), .B(new_n213_), .Y(new_n214_));
  NOR3x1_ASAP7_75t_R   g124(.A(new_n130_), .B(new_n132_), .C(new_n92_), .Y(new_n215_));
  AOI21x1_ASAP7_75t_R  g125(.A1(new_n143_), .A2(new_n214_), .B(new_n215_), .Y(o1));
  INVx1_ASAP7_75t_R    g126(.A(new_n140_), .Y(new_n217_));
  AND3x1_ASAP7_75t_R   g127(.A(new_n136_), .B(new_n123_), .C(new_n127_), .Y(new_n218_));
  NAND2x1_ASAP7_75t_R  g128(.A(new_n217_), .B(new_n218_), .Y(new_n219_));
  OR5x1_ASAP7_75t_R    g129(.A(new_n103_), .B(new_n219_), .C(new_n142_), .D(new_n133_), .E(new_n135_), .Y(new_n220_));
  AND2x2_ASAP7_75t_R   g130(.A(p59), .B(p29), .Y(new_n221_));
  INVx1_ASAP7_75t_R    g131(.A(p36), .Y(new_n222_));
  INVx1_ASAP7_75t_R    g132(.A(p34), .Y(new_n223_));
  NOR2x1_ASAP7_75t_R   g133(.A(p42), .B(p45), .Y(new_n224_));
  NOR2x1_ASAP7_75t_R   g134(.A(p39), .B(p35), .Y(new_n225_));
  INVx1_ASAP7_75t_R    g135(.A(p33), .Y(new_n226_));
  AND5x1_ASAP7_75t_R   g136(.A(new_n223_), .B(new_n224_), .C(new_n225_), .D(new_n154_), .E(new_n226_), .Y(new_n227_));
  NOR2x1_ASAP7_75t_R   g137(.A(p30), .B(p32), .Y(new_n228_));
  INVx1_ASAP7_75t_R    g138(.A(p37), .Y(new_n229_));
  AND3x1_ASAP7_75t_R   g139(.A(new_n228_), .B(new_n229_), .C(p40), .Y(new_n230_));
  NOR2x1_ASAP7_75t_R   g140(.A(p31), .B(new_n191_), .Y(new_n231_));
  AND5x1_ASAP7_75t_R   g141(.A(new_n222_), .B(new_n227_), .C(p38), .D(new_n230_), .E(new_n231_), .Y(new_n232_));
  NAND2x1_ASAP7_75t_R  g142(.A(new_n183_), .B(new_n148_), .Y(new_n233_));
  NAND2x1_ASAP7_75t_R  g143(.A(p41), .B(p40), .Y(new_n234_));
  AO21x1_ASAP7_75t_R   g144(.A1(new_n172_), .A2(new_n173_), .B(new_n234_), .Y(new_n235_));
  AOI211x1_ASAP7_75t_R g145(.A1(p47), .A2(p46), .B(p50), .C(p51), .Y(new_n236_));
  AND5x1_ASAP7_75t_R   g146(.A(new_n233_), .B(new_n235_), .C(new_n236_), .D(new_n203_), .E(new_n209_), .Y(new_n237_));
  OA21x2_ASAP7_75t_R   g147(.A1(p46), .A2(new_n190_), .B(new_n157_), .Y(new_n238_));
  OA21x2_ASAP7_75t_R   g148(.A1(p47), .A2(new_n203_), .B(new_n238_), .Y(new_n239_));
  NAND3x1_ASAP7_75t_R  g149(.A(new_n232_), .B(new_n237_), .C(new_n239_), .Y(new_n240_));
  OAI21x1_ASAP7_75t_R  g150(.A1(new_n221_), .A2(new_n240_), .B(new_n212_), .Y(new_n241_));
  AOI211x1_ASAP7_75t_R g151(.A1(new_n109_), .A2(new_n220_), .B(new_n241_), .C(new_n215_), .Y(o2));
  assign               o3 = 1'b0;
  assign               o4 = 1'b0;
  assign               o5 = 1'b0;
  assign               o6 = 1'b0;
  assign               o7 = 1'b0;
  assign               o8 = 1'b0;
  assign               o9 = 1'b0;
  assign               o10 = 1'b0;
  assign               o11 = 1'b0;
  assign               o12 = 1'b0;
  assign               o13 = 1'b0;
  assign               o14 = 1'b0;
  assign               o15 = 1'b0;
  assign               o16 = 1'b0;
  assign               o17 = 1'b0;
  assign               o18 = 1'b0;
  assign               o19 = 1'b0;
  assign               o20 = 1'b0;
  assign               o21 = 1'b0;
  assign               o22 = 1'b0;
  assign               o23 = 1'b0;
  assign               o24 = 1'b0;
  assign               o25 = 1'b0;
  assign               o26 = 1'b0;
  assign               o27 = 1'b0;
  assign               o28 = 1'b0;
  assign               o29 = 1'b0;
endmodule


