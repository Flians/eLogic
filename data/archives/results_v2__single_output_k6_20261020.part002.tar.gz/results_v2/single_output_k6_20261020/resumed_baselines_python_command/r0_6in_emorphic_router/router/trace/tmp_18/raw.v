// Benchmark "/tmp/" written by ABC on Tue Oct 20 18:11:46 2026

module \/tmp/  ( 
    p47, p8, p0, p27, p28, p6, p26, p5, p44, p42, p31, p38, p21, p53, p30,
    p40, p34, p15, p16, p4, p12, p46, p25, p37, p29, p32, p10, p51, p49,
    p56, p43, p48, p24, p13, p59, p33, p1, p19, p7, p23, p14, p9, p54, p3,
    p52, p35, p55, p50, p39, p45, p36, p41, p57, p20, p11, p22, p58, p18,
    p2, p17,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25, o26, o27, o28, o29  );
  input  p47, p8, p0, p27, p28, p6, p26, p5, p44, p42, p31, p38, p21,
    p53, p30, p40, p34, p15, p16, p4, p12, p46, p25, p37, p29, p32, p10,
    p51, p49, p56, p43, p48, p24, p13, p59, p33, p1, p19, p7, p23, p14, p9,
    p54, p3, p52, p35, p55, p50, p39, p45, p36, p41, p57, p20, p11, p22,
    p58, p18, p2, p17;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25, o26, o27, o28, o29;
  wire new_n91_, new_n92_, new_n93_, new_n94_, new_n95_, new_n96_, new_n97_,
    new_n98_, new_n99_, new_n100_, new_n101_, new_n102_, new_n103_,
    new_n104_, new_n105_, new_n106_, new_n107_, new_n108_, new_n109_,
    new_n110_, new_n111_, new_n112_, new_n113_, new_n114_, new_n115_,
    new_n116_, new_n117_, new_n118_, new_n119_, new_n120_, new_n121_,
    new_n122_, new_n123_, new_n124_, new_n125_, new_n126_, new_n127_,
    new_n128_, new_n129_, new_n130_, new_n131_, new_n132_, new_n133_,
    new_n134_, new_n135_, new_n136_, new_n137_, new_n138_, new_n139_,
    new_n140_, new_n141_, new_n142_, new_n143_, new_n144_, new_n146_,
    new_n147_, new_n148_, new_n149_, new_n150_, new_n151_, new_n152_,
    new_n153_, new_n154_, new_n155_, new_n156_, new_n157_, new_n158_,
    new_n159_, new_n160_, new_n161_, new_n162_, new_n163_, new_n164_,
    new_n165_, new_n166_, new_n167_, new_n168_, new_n169_, new_n170_,
    new_n171_, new_n172_, new_n173_, new_n174_, new_n175_, new_n176_,
    new_n177_, new_n178_, new_n179_, new_n180_, new_n181_, new_n182_,
    new_n183_, new_n184_, new_n185_, new_n186_, new_n187_, new_n188_,
    new_n189_, new_n190_, new_n191_, new_n192_, new_n193_, new_n194_,
    new_n195_, new_n196_, new_n197_, new_n198_, new_n199_, new_n200_,
    new_n201_, new_n202_, new_n203_, new_n204_, new_n205_, new_n206_,
    new_n207_, new_n208_, new_n209_, new_n210_, new_n211_, new_n212_,
    new_n213_, new_n214_, new_n215_, new_n217_, new_n218_, new_n219_,
    new_n220_, new_n221_, new_n222_, new_n223_, new_n224_, new_n225_,
    new_n226_, new_n227_, new_n228_, new_n229_, new_n230_, new_n231_,
    new_n232_, new_n233_, new_n234_, new_n235_, new_n236_;
  NOR2x1_ASAP7_75t_R   g000(.A(p21), .B(p20), .Y(new_n91_));
  AO21x1_ASAP7_75t_R   g001(.A1(p15), .A2(p16), .B(p17), .Y(new_n92_));
  NOR2x1_ASAP7_75t_R   g002(.A(p12), .B(p11), .Y(new_n93_));
  OAI21x1_ASAP7_75t_R  g003(.A1(p8), .A2(p9), .B(p10), .Y(new_n94_));
  INVx1_ASAP7_75t_R    g004(.A(p16), .Y(new_n95_));
  NAND2x1_ASAP7_75t_R  g005(.A(p13), .B(p14), .Y(new_n96_));
  AOI211x1_ASAP7_75t_R g006(.A1(new_n93_), .A2(new_n94_), .B(new_n95_), .C(new_n96_), .Y(new_n97_));
  NOR2x1_ASAP7_75t_R   g007(.A(new_n92_), .B(new_n97_), .Y(new_n98_));
  AND2x2_ASAP7_75t_R   g008(.A(p24), .B(p23), .Y(new_n99_));
  INVx1_ASAP7_75t_R    g009(.A(new_n99_), .Y(new_n100_));
  NAND2x1_ASAP7_75t_R  g010(.A(p19), .B(p18), .Y(new_n101_));
  INVx1_ASAP7_75t_R    g011(.A(p22), .Y(new_n102_));
  AOI21x1_ASAP7_75t_R  g012(.A1(new_n101_), .A2(new_n91_), .B(new_n102_), .Y(new_n103_));
  INVx1_ASAP7_75t_R    g013(.A(new_n103_), .Y(new_n104_));
  AOI211x1_ASAP7_75t_R g014(.A1(new_n91_), .A2(new_n98_), .B(new_n100_), .C(new_n104_), .Y(new_n105_));
  AND3x1_ASAP7_75t_R   g015(.A(p27), .B(p28), .C(p26), .Y(new_n106_));
  OAI21x1_ASAP7_75t_R  g016(.A1(p25), .A2(new_n105_), .B(new_n106_), .Y(new_n107_));
  AO21x1_ASAP7_75t_R   g017(.A1(p15), .A2(p16), .B(new_n97_), .Y(new_n108_));
  INVx1_ASAP7_75t_R    g018(.A(p11), .Y(new_n109_));
  AND3x1_ASAP7_75t_R   g019(.A(new_n91_), .B(p19), .C(p22), .Y(new_n110_));
  INVx1_ASAP7_75t_R    g020(.A(p2), .Y(new_n111_));
  INVx1_ASAP7_75t_R    g021(.A(p17), .Y(new_n112_));
  AND5x1_ASAP7_75t_R   g022(.A(new_n109_), .B(new_n110_), .C(p18), .D(new_n111_), .E(new_n112_), .Y(new_n113_));
  INVx1_ASAP7_75t_R    g023(.A(p15), .Y(new_n114_));
  AO21x1_ASAP7_75t_R   g024(.A1(new_n93_), .A2(new_n94_), .B(new_n114_), .Y(new_n115_));
  AND2x2_ASAP7_75t_R   g025(.A(p13), .B(p14), .Y(new_n116_));
  INVx1_ASAP7_75t_R    g026(.A(p0), .Y(new_n117_));
  NOR2x1_ASAP7_75t_R   g027(.A(p6), .B(p5), .Y(new_n118_));
  AND5x1_ASAP7_75t_R   g028(.A(p8), .B(new_n99_), .C(new_n116_), .D(new_n117_), .E(new_n118_), .Y(new_n119_));
  OR4x2_ASAP7_75t_R    g029(.A(p1), .B(p7), .C(p9), .D(p3), .Y(new_n120_));
  INVx1_ASAP7_75t_R    g030(.A(p10), .Y(new_n121_));
  OR4x2_ASAP7_75t_R    g031(.A(new_n121_), .B(p4), .C(p12), .D(p25), .Y(new_n122_));
  NOR2x1_ASAP7_75t_R   g032(.A(new_n120_), .B(new_n122_), .Y(new_n123_));
  AND5x1_ASAP7_75t_R   g033(.A(new_n108_), .B(new_n113_), .C(new_n115_), .D(new_n119_), .E(new_n123_), .Y(new_n124_));
  INVx1_ASAP7_75t_R    g034(.A(new_n106_), .Y(new_n125_));
  INVx1_ASAP7_75t_R    g035(.A(new_n91_), .Y(new_n126_));
  OA31x2_ASAP7_75t_R   g036(.A1(new_n126_), .A2(new_n92_), .A3(new_n97_), .B1(new_n103_), .Y(new_n127_));
  AOI21x1_ASAP7_75t_R  g037(.A1(new_n99_), .A2(new_n127_), .B(p25), .Y(new_n128_));
  AND2x2_ASAP7_75t_R   g038(.A(p15), .B(p16), .Y(new_n129_));
  OR3x1_ASAP7_75t_R    g039(.A(new_n97_), .B(p17), .C(new_n129_), .Y(new_n130_));
  AND4x2_ASAP7_75t_R   g040(.A(p59), .B(p3), .C(p18), .D(p2), .Y(new_n131_));
  AND2x2_ASAP7_75t_R   g041(.A(p1), .B(p7), .Y(new_n132_));
  AND3x1_ASAP7_75t_R   g042(.A(new_n131_), .B(new_n116_), .C(new_n132_), .Y(new_n133_));
  NAND3x1_ASAP7_75t_R  g043(.A(new_n133_), .B(new_n106_), .C(new_n110_), .Y(new_n134_));
  AOI21x1_ASAP7_75t_R  g044(.A1(p22), .A2(new_n126_), .B(p23), .Y(new_n135_));
  INVx1_ASAP7_75t_R    g045(.A(p4), .Y(new_n136_));
  NAND2x1_ASAP7_75t_R  g046(.A(p5), .B(new_n114_), .Y(new_n137_));
  NAND2x1_ASAP7_75t_R  g047(.A(p10), .B(p24), .Y(new_n138_));
  NAND2x1_ASAP7_75t_R  g048(.A(p0), .B(p6), .Y(new_n139_));
  OR5x1_ASAP7_75t_R    g049(.A(new_n136_), .B(new_n137_), .C(p25), .D(new_n138_), .E(new_n139_), .Y(new_n140_));
  NOR2x1_ASAP7_75t_R   g050(.A(p15), .B(p16), .Y(new_n141_));
  OR5x1_ASAP7_75t_R    g051(.A(p8), .B(new_n141_), .C(p12), .D(p9), .E(p11), .Y(new_n142_));
  OR5x1_ASAP7_75t_R    g052(.A(new_n130_), .B(new_n134_), .C(new_n135_), .D(new_n140_), .E(new_n142_), .Y(new_n143_));
  OAI21x1_ASAP7_75t_R  g053(.A1(new_n125_), .A2(new_n128_), .B(new_n143_), .Y(new_n144_));
  OAI21x1_ASAP7_75t_R  g054(.A1(new_n107_), .A2(new_n124_), .B(new_n144_), .Y(o0));
  AND2x2_ASAP7_75t_R   g055(.A(p49), .B(p48), .Y(new_n146_));
  INVx1_ASAP7_75t_R    g056(.A(new_n146_), .Y(new_n147_));
  NOR2x1_ASAP7_75t_R   g057(.A(p42), .B(p41), .Y(new_n148_));
  OAI21x1_ASAP7_75t_R  g058(.A1(p38), .A2(p39), .B(p40), .Y(new_n149_));
  NAND2x1_ASAP7_75t_R  g059(.A(p44), .B(p43), .Y(new_n150_));
  AOI21x1_ASAP7_75t_R  g060(.A1(new_n148_), .A2(new_n149_), .B(new_n150_), .Y(new_n151_));
  AO21x1_ASAP7_75t_R   g061(.A1(p46), .A2(p45), .B(p47), .Y(new_n152_));
  AOI21x1_ASAP7_75t_R  g062(.A1(p46), .A2(new_n151_), .B(new_n152_), .Y(new_n153_));
  INVx1_ASAP7_75t_R    g063(.A(p51), .Y(new_n154_));
  NAND2x1_ASAP7_75t_R  g064(.A(p52), .B(new_n154_), .Y(new_n155_));
  OAI21x1_ASAP7_75t_R  g065(.A1(new_n147_), .A2(new_n153_), .B(new_n155_), .Y(new_n156_));
  NAND2x1_ASAP7_75t_R  g066(.A(p46), .B(p45), .Y(new_n157_));
  OAI21x1_ASAP7_75t_R  g067(.A1(p48), .A2(new_n157_), .B(new_n152_), .Y(new_n158_));
  AND2x2_ASAP7_75t_R   g068(.A(p34), .B(p46), .Y(new_n159_));
  AND3x1_ASAP7_75t_R   g069(.A(new_n159_), .B(p37), .C(p29), .Y(new_n160_));
  AND2x2_ASAP7_75t_R   g070(.A(p44), .B(p31), .Y(new_n161_));
  AND3x1_ASAP7_75t_R   g071(.A(new_n161_), .B(p30), .C(p40), .Y(new_n162_));
  OR2x4_ASAP7_75t_R    g072(.A(p47), .B(p48), .Y(new_n163_));
  NOR2x1_ASAP7_75t_R   g073(.A(p38), .B(p39), .Y(new_n164_));
  AND3x1_ASAP7_75t_R   g074(.A(new_n164_), .B(p53), .C(p54), .Y(new_n165_));
  AND5x1_ASAP7_75t_R   g075(.A(new_n158_), .B(new_n160_), .C(new_n162_), .D(new_n163_), .E(new_n165_), .Y(new_n166_));
  INVx1_ASAP7_75t_R    g076(.A(p43), .Y(new_n167_));
  AO21x1_ASAP7_75t_R   g077(.A1(new_n148_), .A2(new_n149_), .B(new_n167_), .Y(new_n168_));
  AND2x2_ASAP7_75t_R   g078(.A(p32), .B(p49), .Y(new_n169_));
  AND3x1_ASAP7_75t_R   g079(.A(new_n169_), .B(p33), .C(p35), .Y(new_n170_));
  AND3x1_ASAP7_75t_R   g080(.A(p56), .B(p57), .C(p58), .Y(new_n171_));
  NAND2x1_ASAP7_75t_R  g081(.A(p42), .B(p41), .Y(new_n172_));
  OAI21x1_ASAP7_75t_R  g082(.A1(new_n172_), .A2(new_n149_), .B(new_n167_), .Y(new_n173_));
  INVx1_ASAP7_75t_R    g083(.A(p55), .Y(new_n174_));
  INVx1_ASAP7_75t_R    g084(.A(p45), .Y(new_n175_));
  AND3x1_ASAP7_75t_R   g085(.A(new_n174_), .B(new_n175_), .C(p36), .Y(new_n176_));
  AND5x1_ASAP7_75t_R   g086(.A(new_n168_), .B(new_n170_), .C(new_n171_), .D(new_n173_), .E(new_n176_), .Y(new_n177_));
  NAND3x1_ASAP7_75t_R  g087(.A(new_n156_), .B(new_n166_), .C(new_n177_), .Y(new_n178_));
  AND3x1_ASAP7_75t_R   g088(.A(p53), .B(p54), .C(p52), .Y(new_n179_));
  OA21x2_ASAP7_75t_R   g089(.A1(p55), .A2(new_n179_), .B(new_n171_), .Y(new_n180_));
  INVx1_ASAP7_75t_R    g090(.A(p50), .Y(new_n181_));
  AND3x1_ASAP7_75t_R   g091(.A(new_n154_), .B(new_n174_), .C(new_n181_), .Y(new_n182_));
  OAI21x1_ASAP7_75t_R  g092(.A1(new_n147_), .A2(new_n153_), .B(new_n182_), .Y(new_n183_));
  NOR2x1_ASAP7_75t_R   g093(.A(p59), .B(p50), .Y(new_n184_));
  AOI21x1_ASAP7_75t_R  g094(.A1(new_n180_), .A2(new_n183_), .B(new_n184_), .Y(new_n185_));
  NAND2x1_ASAP7_75t_R  g095(.A(p40), .B(p56), .Y(new_n186_));
  OR3x1_ASAP7_75t_R    g096(.A(new_n186_), .B(p37), .C(p55), .Y(new_n187_));
  INVx1_ASAP7_75t_R    g097(.A(p38), .Y(new_n188_));
  OR3x1_ASAP7_75t_R    g098(.A(new_n150_), .B(p42), .C(new_n188_), .Y(new_n189_));
  OR4x2_ASAP7_75t_R    g099(.A(p50), .B(p39), .C(p45), .D(p36), .Y(new_n190_));
  NOR3x1_ASAP7_75t_R   g100(.A(new_n187_), .B(new_n189_), .C(new_n190_), .Y(new_n191_));
  INVx1_ASAP7_75t_R    g101(.A(p41), .Y(new_n192_));
  NOR2x1_ASAP7_75t_R   g102(.A(p31), .B(p30), .Y(new_n193_));
  NAND3x1_ASAP7_75t_R  g103(.A(new_n193_), .B(p53), .C(p54), .Y(new_n194_));
  NAND2x1_ASAP7_75t_R  g104(.A(p47), .B(p46), .Y(new_n195_));
  NAND2x1_ASAP7_75t_R  g105(.A(new_n195_), .B(new_n146_), .Y(new_n196_));
  AOI211x1_ASAP7_75t_R g106(.A1(new_n192_), .A2(new_n149_), .B(new_n194_), .C(new_n196_), .Y(new_n197_));
  NOR2x1_ASAP7_75t_R   g107(.A(new_n192_), .B(new_n149_), .Y(new_n198_));
  OR4x2_ASAP7_75t_R    g108(.A(p34), .B(p32), .C(p33), .D(p35), .Y(new_n199_));
  NOR3x1_ASAP7_75t_R   g109(.A(new_n198_), .B(new_n199_), .C(new_n155_), .Y(new_n200_));
  NAND3x1_ASAP7_75t_R  g110(.A(new_n191_), .B(new_n197_), .C(new_n200_), .Y(new_n201_));
  NAND2x1_ASAP7_75t_R  g111(.A(p47), .B(new_n175_), .Y(new_n202_));
  NOR2x1_ASAP7_75t_R   g112(.A(new_n202_), .B(new_n151_), .Y(new_n203_));
  INVx1_ASAP7_75t_R    g113(.A(new_n157_), .Y(new_n204_));
  AO21x1_ASAP7_75t_R   g114(.A1(p46), .A2(new_n151_), .B(new_n204_), .Y(new_n205_));
  NOR2x1_ASAP7_75t_R   g115(.A(p29), .B(p59), .Y(new_n206_));
  OAI21x1_ASAP7_75t_R  g116(.A1(new_n203_), .A2(new_n205_), .B(new_n206_), .Y(new_n207_));
  INVx1_ASAP7_75t_R    g117(.A(p46), .Y(new_n208_));
  AOI211x1_ASAP7_75t_R g118(.A1(new_n148_), .A2(new_n149_), .B(new_n208_), .C(new_n150_), .Y(new_n209_));
  OAI21x1_ASAP7_75t_R  g119(.A1(new_n152_), .A2(new_n209_), .B(new_n146_), .Y(new_n210_));
  INVx1_ASAP7_75t_R    g120(.A(new_n180_), .Y(new_n211_));
  AOI21x1_ASAP7_75t_R  g121(.A1(new_n182_), .A2(new_n210_), .B(new_n211_), .Y(new_n212_));
  OAI21x1_ASAP7_75t_R  g122(.A1(new_n201_), .A2(new_n207_), .B(new_n212_), .Y(new_n213_));
  OAI21x1_ASAP7_75t_R  g123(.A1(new_n178_), .A2(new_n185_), .B(new_n213_), .Y(new_n214_));
  NOR3x1_ASAP7_75t_R   g124(.A(new_n124_), .B(new_n128_), .C(new_n125_), .Y(new_n215_));
  AOI21x1_ASAP7_75t_R  g125(.A1(new_n144_), .A2(new_n214_), .B(new_n215_), .Y(o1));
  AND2x2_ASAP7_75t_R   g126(.A(p29), .B(p59), .Y(new_n217_));
  NOR2x1_ASAP7_75t_R   g127(.A(p45), .B(new_n151_), .Y(new_n218_));
  OAI22x1_ASAP7_75t_R  g128(.A1(new_n218_), .A2(new_n208_), .B1(new_n151_), .B2(new_n202_), .Y(new_n219_));
  INVx1_ASAP7_75t_R    g129(.A(p42), .Y(new_n220_));
  AND3x1_ASAP7_75t_R   g130(.A(new_n146_), .B(p44), .C(new_n220_), .Y(new_n221_));
  AND3x1_ASAP7_75t_R   g131(.A(new_n195_), .B(new_n154_), .C(new_n174_), .Y(new_n222_));
  NOR2x1_ASAP7_75t_R   g132(.A(p34), .B(p37), .Y(new_n223_));
  INVx1_ASAP7_75t_R    g133(.A(p32), .Y(new_n224_));
  AND3x1_ASAP7_75t_R   g134(.A(new_n223_), .B(new_n224_), .C(p56), .Y(new_n225_));
  NOR2x1_ASAP7_75t_R   g135(.A(p31), .B(new_n188_), .Y(new_n226_));
  INVx1_ASAP7_75t_R    g136(.A(p40), .Y(new_n227_));
  NOR2x1_ASAP7_75t_R   g137(.A(p30), .B(new_n227_), .Y(new_n228_));
  AND5x1_ASAP7_75t_R   g138(.A(new_n221_), .B(new_n222_), .C(new_n225_), .D(new_n226_), .E(new_n228_), .Y(new_n229_));
  NOR2x1_ASAP7_75t_R   g139(.A(p33), .B(new_n167_), .Y(new_n230_));
  NOR2x1_ASAP7_75t_R   g140(.A(p39), .B(p45), .Y(new_n231_));
  NOR2x1_ASAP7_75t_R   g141(.A(p36), .B(p41), .Y(new_n232_));
  NOR2x1_ASAP7_75t_R   g142(.A(p35), .B(p50), .Y(new_n233_));
  AND5x1_ASAP7_75t_R   g143(.A(new_n179_), .B(new_n230_), .C(new_n231_), .D(new_n232_), .E(new_n233_), .Y(new_n234_));
  NAND3x1_ASAP7_75t_R  g144(.A(new_n219_), .B(new_n229_), .C(new_n234_), .Y(new_n235_));
  OAI21x1_ASAP7_75t_R  g145(.A1(new_n217_), .A2(new_n235_), .B(new_n212_), .Y(new_n236_));
  AOI211x1_ASAP7_75t_R g146(.A1(new_n107_), .A2(new_n143_), .B(new_n236_), .C(new_n215_), .Y(o2));
  assign               o3 = 1'b0;
  assign               o4 = 1'b0;
  assign               o5 = 1'b0;
  assign               o6 = 1'b0;
  assign               o7 = 1'b0;
  assign               o8 = 1'b0;
  assign               o9 = 1'b0;
  assign               o10 = 1'b0;
  assign               o11 = 1'b0;
  assign               o12 = 1'b0;
  assign               o13 = 1'b0;
  assign               o14 = 1'b0;
  assign               o15 = 1'b0;
  assign               o16 = 1'b0;
  assign               o17 = 1'b0;
  assign               o18 = 1'b0;
  assign               o19 = 1'b0;
  assign               o20 = 1'b0;
  assign               o21 = 1'b0;
  assign               o22 = 1'b0;
  assign               o23 = 1'b0;
  assign               o24 = 1'b0;
  assign               o25 = 1'b0;
  assign               o26 = 1'b0;
  assign               o27 = 1'b0;
  assign               o28 = 1'b0;
  assign               o29 = 1'b0;
endmodule


