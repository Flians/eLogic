// Benchmark "/tmp/" written by ABC on Tue Oct 20 18:11:44 2026

module \/tmp/  ( 
    p13, p21, p9, p30, p38, p14, p10, p3, p15, p39, p47, p12, p24, p6, p34,
    p58, p32, p11, p17, p31, p48, p28, p44, p1, p5, p2, p55, p37, p59, p45,
    p4, p16, p36, p33, p23, p56, p52, p50, p40, p41, p57, p54, p22, p42,
    p35, p53, p7, p46, p18, p0, p49, p8, p19, p29, p43, p27, p20, p26, p25,
    p51,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25, o26, o27, o28, o29  );
  input  p13, p21, p9, p30, p38, p14, p10, p3, p15, p39, p47, p12, p24,
    p6, p34, p58, p32, p11, p17, p31, p48, p28, p44, p1, p5, p2, p55, p37,
    p59, p45, p4, p16, p36, p33, p23, p56, p52, p50, p40, p41, p57, p54,
    p22, p42, p35, p53, p7, p46, p18, p0, p49, p8, p19, p29, p43, p27, p20,
    p26, p25, p51;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25, o26, o27, o28, o29;
  wire new_n91_, new_n92_, new_n93_, new_n94_, new_n95_, new_n96_, new_n97_,
    new_n98_, new_n99_, new_n100_, new_n101_, new_n102_, new_n103_,
    new_n104_, new_n105_, new_n106_, new_n107_, new_n108_, new_n109_,
    new_n110_, new_n111_, new_n112_, new_n113_, new_n114_, new_n115_,
    new_n116_, new_n117_, new_n118_, new_n119_, new_n120_, new_n121_,
    new_n122_, new_n123_, new_n124_, new_n125_, new_n126_, new_n127_,
    new_n128_, new_n129_, new_n130_, new_n131_, new_n132_, new_n133_,
    new_n134_, new_n135_, new_n136_, new_n137_, new_n138_, new_n139_,
    new_n140_, new_n141_, new_n142_, new_n143_, new_n144_, new_n145_,
    new_n146_, new_n147_, new_n148_, new_n150_, new_n151_, new_n152_,
    new_n153_, new_n154_, new_n155_, new_n156_, new_n157_, new_n158_,
    new_n159_, new_n160_, new_n161_, new_n162_, new_n163_, new_n164_,
    new_n165_, new_n166_, new_n167_, new_n168_, new_n169_, new_n170_,
    new_n171_, new_n172_, new_n173_, new_n174_, new_n175_, new_n176_,
    new_n177_, new_n178_, new_n179_, new_n180_, new_n181_, new_n182_,
    new_n183_, new_n184_, new_n185_, new_n186_, new_n187_, new_n188_,
    new_n189_, new_n190_, new_n191_, new_n192_, new_n193_, new_n194_,
    new_n195_, new_n196_, new_n197_, new_n198_, new_n199_, new_n200_,
    new_n201_, new_n202_, new_n203_, new_n204_, new_n205_, new_n206_,
    new_n208_, new_n209_, new_n210_, new_n211_;
  INVx1_ASAP7_75t_R    g000(.A(p25), .Y(new_n91_));
  NOR2x1_ASAP7_75t_R   g001(.A(p21), .B(p20), .Y(new_n92_));
  NOR2x1_ASAP7_75t_R   g002(.A(p15), .B(p17), .Y(new_n93_));
  INVx1_ASAP7_75t_R    g003(.A(new_n93_), .Y(new_n94_));
  NOR2x1_ASAP7_75t_R   g004(.A(p12), .B(p11), .Y(new_n95_));
  OAI21x1_ASAP7_75t_R  g005(.A1(p9), .A2(p8), .B(p10), .Y(new_n96_));
  NAND2x1_ASAP7_75t_R  g006(.A(p13), .B(p14), .Y(new_n97_));
  AOI21x1_ASAP7_75t_R  g007(.A1(new_n95_), .A2(new_n96_), .B(new_n97_), .Y(new_n98_));
  OA211x2_ASAP7_75t_R  g008(.A1(p17), .A2(p16), .B(p18), .C(p19), .Y(new_n99_));
  OAI21x1_ASAP7_75t_R  g009(.A1(new_n94_), .A2(new_n98_), .B(new_n99_), .Y(new_n100_));
  AND2x2_ASAP7_75t_R   g010(.A(p24), .B(p23), .Y(new_n101_));
  NAND2x1_ASAP7_75t_R  g011(.A(p22), .B(new_n101_), .Y(new_n102_));
  AO21x1_ASAP7_75t_R   g012(.A1(new_n92_), .A2(new_n100_), .B(new_n102_), .Y(new_n103_));
  AND3x1_ASAP7_75t_R   g013(.A(p28), .B(p27), .C(p26), .Y(new_n104_));
  INVx1_ASAP7_75t_R    g014(.A(new_n104_), .Y(new_n105_));
  AO21x1_ASAP7_75t_R   g015(.A1(new_n91_), .A2(new_n103_), .B(new_n105_), .Y(new_n106_));
  INVx1_ASAP7_75t_R    g016(.A(p9), .Y(new_n107_));
  INVx1_ASAP7_75t_R    g017(.A(p8), .Y(new_n108_));
  AND3x1_ASAP7_75t_R   g018(.A(new_n95_), .B(new_n107_), .C(new_n108_), .Y(new_n109_));
  INVx1_ASAP7_75t_R    g019(.A(p13), .Y(new_n110_));
  XOR2x2_ASAP7_75t_R   g020(.A(new_n96_), .B(new_n110_), .Y(new_n111_));
  AND2x2_ASAP7_75t_R   g021(.A(p6), .B(p1), .Y(new_n112_));
  AND3x1_ASAP7_75t_R   g022(.A(new_n112_), .B(p5), .C(p2), .Y(new_n113_));
  AND2x2_ASAP7_75t_R   g023(.A(p14), .B(p10), .Y(new_n114_));
  AND3x1_ASAP7_75t_R   g024(.A(new_n114_), .B(p3), .C(p24), .Y(new_n115_));
  AND5x1_ASAP7_75t_R   g025(.A(new_n109_), .B(new_n111_), .C(new_n93_), .D(new_n113_), .E(new_n115_), .Y(new_n116_));
  INVx1_ASAP7_75t_R    g026(.A(p22), .Y(new_n117_));
  INVx1_ASAP7_75t_R    g027(.A(p23), .Y(new_n118_));
  OA21x2_ASAP7_75t_R   g028(.A1(new_n117_), .A2(new_n92_), .B(new_n118_), .Y(new_n119_));
  OAI21x1_ASAP7_75t_R  g029(.A1(new_n117_), .A2(new_n100_), .B(new_n119_), .Y(new_n120_));
  INVx1_ASAP7_75t_R    g030(.A(new_n98_), .Y(new_n121_));
  AND2x2_ASAP7_75t_R   g031(.A(p59), .B(p4), .Y(new_n122_));
  AND3x1_ASAP7_75t_R   g032(.A(new_n122_), .B(p16), .C(p7), .Y(new_n123_));
  AND3x1_ASAP7_75t_R   g033(.A(new_n92_), .B(p22), .C(p19), .Y(new_n124_));
  AND3x1_ASAP7_75t_R   g034(.A(new_n91_), .B(p18), .C(p0), .Y(new_n125_));
  AND5x1_ASAP7_75t_R   g035(.A(new_n121_), .B(new_n123_), .C(new_n104_), .D(new_n124_), .E(new_n125_), .Y(new_n126_));
  NAND3x1_ASAP7_75t_R  g036(.A(new_n116_), .B(new_n120_), .C(new_n126_), .Y(new_n127_));
  INVx1_ASAP7_75t_R    g037(.A(p14), .Y(new_n128_));
  NOR2x1_ASAP7_75t_R   g038(.A(p15), .B(new_n128_), .Y(new_n129_));
  AO21x1_ASAP7_75t_R   g039(.A1(new_n95_), .A2(new_n96_), .B(new_n110_), .Y(new_n130_));
  INVx1_ASAP7_75t_R    g040(.A(p4), .Y(new_n131_));
  NOR2x1_ASAP7_75t_R   g041(.A(p17), .B(p2), .Y(new_n132_));
  INVx1_ASAP7_75t_R    g042(.A(p7), .Y(new_n133_));
  AND5x1_ASAP7_75t_R   g043(.A(new_n131_), .B(new_n132_), .C(p16), .D(p23), .E(new_n133_), .Y(new_n134_));
  NOR2x1_ASAP7_75t_R   g044(.A(p0), .B(p25), .Y(new_n135_));
  AND3x1_ASAP7_75t_R   g045(.A(new_n135_), .B(p18), .C(p8), .Y(new_n136_));
  OA211x2_ASAP7_75t_R  g046(.A1(new_n129_), .A2(new_n130_), .B(new_n134_), .C(new_n136_), .Y(new_n137_));
  INVx1_ASAP7_75t_R    g047(.A(p1), .Y(new_n138_));
  NAND2x1_ASAP7_75t_R  g048(.A(new_n107_), .B(new_n108_), .Y(new_n139_));
  INVx1_ASAP7_75t_R    g049(.A(p10), .Y(new_n140_));
  NAND2x1_ASAP7_75t_R  g050(.A(p11), .B(new_n140_), .Y(new_n141_));
  OAI22x1_ASAP7_75t_R  g051(.A1(new_n139_), .A2(new_n141_), .B1(p11), .B2(new_n96_), .Y(new_n142_));
  INVx1_ASAP7_75t_R    g052(.A(p5), .Y(new_n143_));
  NOR2x1_ASAP7_75t_R   g053(.A(p12), .B(p6), .Y(new_n144_));
  INVx1_ASAP7_75t_R    g054(.A(p3), .Y(new_n145_));
  AND5x1_ASAP7_75t_R   g055(.A(p13), .B(new_n144_), .C(new_n107_), .D(new_n145_), .E(p24), .Y(new_n146_));
  AND5x1_ASAP7_75t_R   g056(.A(new_n138_), .B(new_n142_), .C(new_n143_), .D(new_n124_), .E(new_n146_), .Y(new_n147_));
  AOI221x1_ASAP7_75t_R g057(.A1(new_n137_), .A2(new_n147_), .B1(new_n103_), .B2(new_n91_), .C(new_n105_), .Y(new_n148_));
  AO21x1_ASAP7_75t_R   g058(.A1(new_n106_), .A2(new_n127_), .B(new_n148_), .Y(o0));
  AND3x1_ASAP7_75t_R   g059(.A(p52), .B(p54), .C(p53), .Y(new_n150_));
  AND3x1_ASAP7_75t_R   g060(.A(p58), .B(p56), .C(p57), .Y(new_n151_));
  OA21x2_ASAP7_75t_R   g061(.A1(p55), .A2(new_n150_), .B(new_n151_), .Y(new_n152_));
  AND2x2_ASAP7_75t_R   g062(.A(p48), .B(p49), .Y(new_n153_));
  INVx1_ASAP7_75t_R    g063(.A(new_n153_), .Y(new_n154_));
  AND3x1_ASAP7_75t_R   g064(.A(p44), .B(p46), .C(p43), .Y(new_n155_));
  NOR2x1_ASAP7_75t_R   g065(.A(p41), .B(p42), .Y(new_n156_));
  OAI21x1_ASAP7_75t_R  g066(.A1(p38), .A2(p39), .B(p40), .Y(new_n157_));
  NAND2x1_ASAP7_75t_R  g067(.A(new_n156_), .B(new_n157_), .Y(new_n158_));
  AO21x1_ASAP7_75t_R   g068(.A1(p45), .A2(p46), .B(p47), .Y(new_n159_));
  AOI21x1_ASAP7_75t_R  g069(.A1(new_n155_), .A2(new_n158_), .B(new_n159_), .Y(new_n160_));
  NOR3x1_ASAP7_75t_R   g070(.A(p55), .B(p50), .C(p51), .Y(new_n161_));
  OAI21x1_ASAP7_75t_R  g071(.A1(new_n154_), .A2(new_n160_), .B(new_n161_), .Y(new_n162_));
  NOR2x1_ASAP7_75t_R   g072(.A(p59), .B(p50), .Y(new_n163_));
  AOI21x1_ASAP7_75t_R  g073(.A1(new_n152_), .A2(new_n162_), .B(new_n163_), .Y(new_n164_));
  INVx1_ASAP7_75t_R    g074(.A(p52), .Y(new_n165_));
  OAI22x1_ASAP7_75t_R  g075(.A1(new_n160_), .A2(new_n154_), .B1(new_n165_), .B2(p51), .Y(new_n166_));
  NAND2x1_ASAP7_75t_R  g076(.A(p33), .B(p40), .Y(new_n167_));
  NOR3x1_ASAP7_75t_R   g077(.A(new_n167_), .B(p41), .C(p42), .Y(new_n168_));
  AND4x2_ASAP7_75t_R   g078(.A(p35), .B(p46), .C(p49), .D(p29), .Y(new_n169_));
  NAND3x1_ASAP7_75t_R  g079(.A(new_n168_), .B(new_n151_), .C(new_n169_), .Y(new_n170_));
  INVx1_ASAP7_75t_R    g080(.A(p47), .Y(new_n171_));
  AND4x2_ASAP7_75t_R   g081(.A(new_n171_), .B(p30), .C(p54), .D(p53), .Y(new_n172_));
  NAND2x1_ASAP7_75t_R  g082(.A(p44), .B(p43), .Y(new_n173_));
  NOR3x1_ASAP7_75t_R   g083(.A(new_n173_), .B(p38), .C(p39), .Y(new_n174_));
  NAND2x1_ASAP7_75t_R  g084(.A(new_n172_), .B(new_n174_), .Y(new_n175_));
  INVx1_ASAP7_75t_R    g085(.A(p37), .Y(new_n176_));
  NOR2x1_ASAP7_75t_R   g086(.A(p55), .B(new_n176_), .Y(new_n177_));
  INVx1_ASAP7_75t_R    g087(.A(p36), .Y(new_n178_));
  NOR2x1_ASAP7_75t_R   g088(.A(p45), .B(new_n178_), .Y(new_n179_));
  AND4x2_ASAP7_75t_R   g089(.A(p34), .B(p32), .C(p31), .D(p48), .Y(new_n180_));
  NAND3x1_ASAP7_75t_R  g090(.A(new_n177_), .B(new_n179_), .C(new_n180_), .Y(new_n181_));
  NOR3x1_ASAP7_75t_R   g091(.A(new_n170_), .B(new_n175_), .C(new_n181_), .Y(new_n182_));
  NAND2x1_ASAP7_75t_R  g092(.A(new_n166_), .B(new_n182_), .Y(new_n183_));
  INVx1_ASAP7_75t_R    g093(.A(p46), .Y(new_n184_));
  AOI211x1_ASAP7_75t_R g094(.A1(new_n156_), .A2(new_n157_), .B(new_n184_), .C(new_n173_), .Y(new_n185_));
  OAI21x1_ASAP7_75t_R  g095(.A1(new_n159_), .A2(new_n185_), .B(new_n153_), .Y(new_n186_));
  INVx1_ASAP7_75t_R    g096(.A(new_n152_), .Y(new_n187_));
  AO21x1_ASAP7_75t_R   g097(.A1(new_n161_), .A2(new_n186_), .B(new_n187_), .Y(new_n188_));
  NOR2x1_ASAP7_75t_R   g098(.A(p59), .B(p29), .Y(new_n189_));
  OR4x2_ASAP7_75t_R    g099(.A(p32), .B(p31), .C(p37), .D(p45), .Y(new_n190_));
  INVx1_ASAP7_75t_R    g100(.A(p38), .Y(new_n191_));
  OR4x2_ASAP7_75t_R    g101(.A(new_n191_), .B(p30), .C(p39), .D(p34), .Y(new_n192_));
  NOR2x1_ASAP7_75t_R   g102(.A(new_n190_), .B(new_n192_), .Y(new_n193_));
  AND2x2_ASAP7_75t_R   g103(.A(p56), .B(p40), .Y(new_n194_));
  NOR2x1_ASAP7_75t_R   g104(.A(p36), .B(p33), .Y(new_n195_));
  AND5x1_ASAP7_75t_R   g105(.A(new_n155_), .B(new_n150_), .C(new_n161_), .D(new_n194_), .E(new_n195_), .Y(new_n196_));
  XNOR2x2_ASAP7_75t_R  g106(.A(p41), .B(new_n157_), .Y(new_n197_));
  NAND2x1_ASAP7_75t_R  g107(.A(p47), .B(p46), .Y(new_n198_));
  INVx1_ASAP7_75t_R    g108(.A(p42), .Y(new_n199_));
  INVx1_ASAP7_75t_R    g109(.A(p35), .Y(new_n200_));
  AND5x1_ASAP7_75t_R   g110(.A(p48), .B(new_n198_), .C(new_n199_), .D(new_n200_), .E(p49), .Y(new_n201_));
  AND5x1_ASAP7_75t_R   g111(.A(new_n189_), .B(new_n193_), .C(new_n196_), .D(new_n197_), .E(new_n201_), .Y(new_n202_));
  OAI22x1_ASAP7_75t_R  g112(.A1(new_n164_), .A2(new_n183_), .B1(new_n188_), .B2(new_n202_), .Y(new_n203_));
  AOI21x1_ASAP7_75t_R  g113(.A1(new_n92_), .A2(new_n100_), .B(new_n117_), .Y(new_n204_));
  AOI21x1_ASAP7_75t_R  g114(.A1(new_n101_), .A2(new_n204_), .B(p25), .Y(new_n205_));
  OAI21x1_ASAP7_75t_R  g115(.A1(new_n105_), .A2(new_n205_), .B(new_n127_), .Y(new_n206_));
  OAI21x1_ASAP7_75t_R  g116(.A1(new_n148_), .A2(new_n203_), .B(new_n206_), .Y(o1));
  NAND2x1_ASAP7_75t_R  g117(.A(p59), .B(p29), .Y(new_n208_));
  AND3x1_ASAP7_75t_R   g118(.A(new_n153_), .B(new_n199_), .C(new_n200_), .Y(new_n209_));
  AND5x1_ASAP7_75t_R   g119(.A(new_n196_), .B(new_n193_), .C(new_n197_), .D(new_n198_), .E(new_n209_), .Y(new_n210_));
  AO21x1_ASAP7_75t_R   g120(.A1(new_n208_), .A2(new_n210_), .B(new_n188_), .Y(new_n211_));
  AOI211x1_ASAP7_75t_R g121(.A1(new_n106_), .A2(new_n127_), .B(new_n148_), .C(new_n211_), .Y(o2));
  assign               o3 = 1'b0;
  assign               o4 = 1'b0;
  assign               o5 = 1'b0;
  assign               o6 = 1'b0;
  assign               o7 = 1'b0;
  assign               o8 = 1'b0;
  assign               o9 = 1'b0;
  assign               o10 = 1'b0;
  assign               o11 = 1'b0;
  assign               o12 = 1'b0;
  assign               o13 = 1'b0;
  assign               o14 = 1'b0;
  assign               o15 = 1'b0;
  assign               o16 = 1'b0;
  assign               o17 = 1'b0;
  assign               o18 = 1'b0;
  assign               o19 = 1'b0;
  assign               o20 = 1'b0;
  assign               o21 = 1'b0;
  assign               o22 = 1'b0;
  assign               o23 = 1'b0;
  assign               o24 = 1'b0;
  assign               o25 = 1'b0;
  assign               o26 = 1'b0;
  assign               o27 = 1'b0;
  assign               o28 = 1'b0;
  assign               o29 = 1'b0;
endmodule


