// Benchmark "/tmp/" written by ABC on Tue Oct 20 18:11:47 2026

module \/tmp/  ( 
    p54, p26, p15, p33, p14, p34, p21, p28, p24, p2, p35, p25, p16, p42,
    p58, p10, p30, p23, p17, p19, p32, p13, p4, p29, p47, p18, p1, p43,
    p49, p20, p6, p45, p3, p46, p51, p31, p40, p5, p57, p22, p50, p0, p37,
    p27, p59, p12, p56, p48, p39, p38, p52, p44, p7, p8, p41, p9, p55, p11,
    p53, p36,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25, o26, o27, o28, o29  );
  input  p54, p26, p15, p33, p14, p34, p21, p28, p24, p2, p35, p25, p16,
    p42, p58, p10, p30, p23, p17, p19, p32, p13, p4, p29, p47, p18, p1,
    p43, p49, p20, p6, p45, p3, p46, p51, p31, p40, p5, p57, p22, p50, p0,
    p37, p27, p59, p12, p56, p48, p39, p38, p52, p44, p7, p8, p41, p9, p55,
    p11, p53, p36;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25, o26, o27, o28, o29;
  wire new_n91_, new_n92_, new_n93_, new_n94_, new_n95_, new_n96_, new_n97_,
    new_n98_, new_n99_, new_n100_, new_n101_, new_n102_, new_n103_,
    new_n104_, new_n105_, new_n106_, new_n107_, new_n108_, new_n109_,
    new_n110_, new_n111_, new_n112_, new_n113_, new_n114_, new_n115_,
    new_n116_, new_n117_, new_n118_, new_n119_, new_n120_, new_n121_,
    new_n122_, new_n123_, new_n124_, new_n125_, new_n126_, new_n127_,
    new_n128_, new_n129_, new_n130_, new_n131_, new_n132_, new_n133_,
    new_n134_, new_n135_, new_n136_, new_n137_, new_n138_, new_n139_,
    new_n140_, new_n141_, new_n142_, new_n143_, new_n144_, new_n145_,
    new_n147_, new_n148_, new_n149_, new_n150_, new_n151_, new_n152_,
    new_n153_, new_n154_, new_n155_, new_n156_, new_n157_, new_n158_,
    new_n159_, new_n160_, new_n161_, new_n162_, new_n163_, new_n164_,
    new_n165_, new_n166_, new_n167_, new_n168_, new_n169_, new_n170_,
    new_n171_, new_n172_, new_n173_, new_n174_, new_n175_, new_n176_,
    new_n177_, new_n178_, new_n179_, new_n180_, new_n181_, new_n182_,
    new_n183_, new_n184_, new_n185_, new_n186_, new_n187_, new_n188_,
    new_n189_, new_n190_, new_n191_, new_n192_, new_n193_, new_n194_,
    new_n195_, new_n196_, new_n197_, new_n198_, new_n199_, new_n200_,
    new_n201_, new_n202_, new_n203_, new_n204_, new_n205_, new_n206_,
    new_n207_, new_n208_, new_n209_, new_n210_, new_n211_, new_n212_,
    new_n213_, new_n214_, new_n215_, new_n216_, new_n217_, new_n218_,
    new_n219_, new_n221_, new_n222_, new_n223_, new_n224_, new_n225_,
    new_n226_, new_n227_, new_n228_, new_n229_, new_n230_, new_n231_,
    new_n232_, new_n233_, new_n234_, new_n235_, new_n236_, new_n237_,
    new_n238_, new_n239_, new_n240_, new_n241_, new_n242_, new_n243_,
    new_n244_, new_n245_;
  AND3x1_ASAP7_75t_R   g000(.A(p5), .B(p0), .C(p59), .Y(new_n91_));
  AND2x2_ASAP7_75t_R   g001(.A(p6), .B(p3), .Y(new_n92_));
  AND5x1_ASAP7_75t_R   g002(.A(p18), .B(new_n91_), .C(new_n92_), .D(p1), .E(p7), .Y(new_n93_));
  INVx1_ASAP7_75t_R    g003(.A(p10), .Y(new_n94_));
  NOR2x1_ASAP7_75t_R   g004(.A(p25), .B(new_n94_), .Y(new_n95_));
  NOR2x1_ASAP7_75t_R   g005(.A(p12), .B(p11), .Y(new_n96_));
  NOR2x1_ASAP7_75t_R   g006(.A(p8), .B(p9), .Y(new_n97_));
  AND3x1_ASAP7_75t_R   g007(.A(new_n95_), .B(new_n96_), .C(new_n97_), .Y(new_n98_));
  INVx1_ASAP7_75t_R    g008(.A(p14), .Y(new_n99_));
  NOR2x1_ASAP7_75t_R   g009(.A(p15), .B(new_n99_), .Y(new_n100_));
  AND3x1_ASAP7_75t_R   g010(.A(new_n100_), .B(p24), .C(p2), .Y(new_n101_));
  AND3x1_ASAP7_75t_R   g011(.A(p26), .B(p28), .C(p27), .Y(new_n102_));
  AND2x2_ASAP7_75t_R   g012(.A(p19), .B(p22), .Y(new_n103_));
  NOR2x1_ASAP7_75t_R   g013(.A(p21), .B(p20), .Y(new_n104_));
  AND3x1_ASAP7_75t_R   g014(.A(new_n102_), .B(new_n103_), .C(new_n104_), .Y(new_n105_));
  AND2x2_ASAP7_75t_R   g015(.A(p13), .B(p4), .Y(new_n106_));
  INVx1_ASAP7_75t_R    g016(.A(p17), .Y(new_n107_));
  AND3x1_ASAP7_75t_R   g017(.A(new_n106_), .B(p16), .C(new_n107_), .Y(new_n108_));
  AND5x1_ASAP7_75t_R   g018(.A(new_n93_), .B(new_n98_), .C(new_n101_), .D(new_n105_), .E(new_n108_), .Y(new_n109_));
  INVx1_ASAP7_75t_R    g019(.A(p22), .Y(new_n110_));
  INVx1_ASAP7_75t_R    g020(.A(p23), .Y(new_n111_));
  OAI21x1_ASAP7_75t_R  g021(.A1(new_n110_), .A2(new_n104_), .B(new_n111_), .Y(new_n112_));
  OAI21x1_ASAP7_75t_R  g022(.A1(p8), .A2(p9), .B(p10), .Y(new_n113_));
  NAND2x1_ASAP7_75t_R  g023(.A(p14), .B(p13), .Y(new_n114_));
  AOI21x1_ASAP7_75t_R  g024(.A1(new_n96_), .A2(new_n113_), .B(new_n114_), .Y(new_n115_));
  AO21x1_ASAP7_75t_R   g025(.A1(p15), .A2(p16), .B(p17), .Y(new_n116_));
  AOI21x1_ASAP7_75t_R  g026(.A1(p16), .A2(new_n115_), .B(new_n116_), .Y(new_n117_));
  AND2x2_ASAP7_75t_R   g027(.A(p24), .B(p23), .Y(new_n118_));
  INVx1_ASAP7_75t_R    g028(.A(new_n118_), .Y(new_n119_));
  NAND2x1_ASAP7_75t_R  g029(.A(p19), .B(p18), .Y(new_n120_));
  AO21x1_ASAP7_75t_R   g030(.A1(new_n120_), .A2(new_n104_), .B(new_n110_), .Y(new_n121_));
  AOI211x1_ASAP7_75t_R g031(.A1(new_n104_), .A2(new_n117_), .B(new_n119_), .C(new_n121_), .Y(new_n122_));
  AND2x2_ASAP7_75t_R   g032(.A(p25), .B(new_n102_), .Y(new_n123_));
  AO221x2_ASAP7_75t_R  g033(.A1(new_n109_), .A2(new_n112_), .B1(new_n122_), .B2(new_n102_), .C(new_n123_), .Y(new_n124_));
  AOI21x1_ASAP7_75t_R  g034(.A1(new_n104_), .A2(new_n117_), .B(new_n121_), .Y(new_n125_));
  AOI21x1_ASAP7_75t_R  g035(.A1(new_n118_), .A2(new_n125_), .B(p25), .Y(new_n126_));
  INVx1_ASAP7_75t_R    g036(.A(new_n102_), .Y(new_n127_));
  OR2x4_ASAP7_75t_R    g037(.A(p15), .B(new_n115_), .Y(new_n128_));
  NOR2x1_ASAP7_75t_R   g038(.A(p3), .B(p5), .Y(new_n129_));
  INVx1_ASAP7_75t_R    g039(.A(p1), .Y(new_n130_));
  INVx1_ASAP7_75t_R    g040(.A(p6), .Y(new_n131_));
  AND3x1_ASAP7_75t_R   g041(.A(new_n129_), .B(new_n130_), .C(new_n131_), .Y(new_n132_));
  INVx1_ASAP7_75t_R    g042(.A(p4), .Y(new_n133_));
  AND5x1_ASAP7_75t_R   g043(.A(new_n107_), .B(new_n132_), .C(p13), .D(new_n133_), .E(p18), .Y(new_n134_));
  INVx1_ASAP7_75t_R    g044(.A(p9), .Y(new_n135_));
  NOR2x1_ASAP7_75t_R   g045(.A(p0), .B(p7), .Y(new_n136_));
  AND5x1_ASAP7_75t_R   g046(.A(p8), .B(new_n103_), .C(new_n135_), .D(new_n104_), .E(new_n136_), .Y(new_n137_));
  INVx1_ASAP7_75t_R    g047(.A(p13), .Y(new_n138_));
  NOR2x1_ASAP7_75t_R   g048(.A(new_n138_), .B(new_n113_), .Y(new_n139_));
  OAI21x1_ASAP7_75t_R  g049(.A1(new_n138_), .A2(new_n96_), .B(new_n99_), .Y(new_n140_));
  OAI21x1_ASAP7_75t_R  g050(.A1(new_n139_), .A2(new_n140_), .B(p15), .Y(new_n141_));
  INVx1_ASAP7_75t_R    g051(.A(p2), .Y(new_n142_));
  AND5x1_ASAP7_75t_R   g052(.A(new_n142_), .B(new_n95_), .C(p16), .D(new_n118_), .E(new_n96_), .Y(new_n143_));
  AND5x1_ASAP7_75t_R   g053(.A(new_n128_), .B(new_n134_), .C(new_n137_), .D(new_n141_), .E(new_n143_), .Y(new_n144_));
  OR3x1_ASAP7_75t_R    g054(.A(new_n126_), .B(new_n127_), .C(new_n144_), .Y(new_n145_));
  NAND2x1_ASAP7_75t_R  g055(.A(new_n124_), .B(new_n145_), .Y(o0));
  NAND2x1_ASAP7_75t_R  g056(.A(p49), .B(p48), .Y(new_n147_));
  NOR2x1_ASAP7_75t_R   g057(.A(p42), .B(p41), .Y(new_n148_));
  OAI21x1_ASAP7_75t_R  g058(.A1(p39), .A2(p38), .B(p40), .Y(new_n149_));
  NAND2x1_ASAP7_75t_R  g059(.A(p43), .B(p44), .Y(new_n150_));
  AOI21x1_ASAP7_75t_R  g060(.A1(new_n148_), .A2(new_n149_), .B(new_n150_), .Y(new_n151_));
  AO21x1_ASAP7_75t_R   g061(.A1(p45), .A2(p46), .B(p47), .Y(new_n152_));
  AOI21x1_ASAP7_75t_R  g062(.A1(p46), .A2(new_n151_), .B(new_n152_), .Y(new_n153_));
  INVx1_ASAP7_75t_R    g063(.A(p51), .Y(new_n154_));
  INVx1_ASAP7_75t_R    g064(.A(p50), .Y(new_n155_));
  INVx1_ASAP7_75t_R    g065(.A(p55), .Y(new_n156_));
  AND3x1_ASAP7_75t_R   g066(.A(new_n154_), .B(new_n155_), .C(new_n156_), .Y(new_n157_));
  OAI21x1_ASAP7_75t_R  g067(.A1(new_n147_), .A2(new_n153_), .B(new_n157_), .Y(new_n158_));
  AND3x1_ASAP7_75t_R   g068(.A(p54), .B(p52), .C(p53), .Y(new_n159_));
  AND3x1_ASAP7_75t_R   g069(.A(p58), .B(p57), .C(p56), .Y(new_n160_));
  OA21x2_ASAP7_75t_R   g070(.A1(p55), .A2(new_n159_), .B(new_n160_), .Y(new_n161_));
  INVx1_ASAP7_75t_R    g071(.A(p59), .Y(new_n162_));
  AOI22x1_ASAP7_75t_R  g072(.A1(new_n158_), .A2(new_n161_), .B1(new_n155_), .B2(new_n162_), .Y(new_n163_));
  INVx1_ASAP7_75t_R    g073(.A(p44), .Y(new_n164_));
  NOR2x1_ASAP7_75t_R   g074(.A(p55), .B(new_n164_), .Y(new_n165_));
  AND4x2_ASAP7_75t_R   g075(.A(p46), .B(p31), .C(p40), .D(p37), .Y(new_n166_));
  AND4x2_ASAP7_75t_R   g076(.A(new_n165_), .B(new_n166_), .C(p36), .D(new_n160_), .Y(new_n167_));
  AND2x2_ASAP7_75t_R   g077(.A(p29), .B(p49), .Y(new_n168_));
  AND2x2_ASAP7_75t_R   g078(.A(p33), .B(p34), .Y(new_n169_));
  AND2x2_ASAP7_75t_R   g079(.A(p35), .B(p30), .Y(new_n170_));
  INVx1_ASAP7_75t_R    g080(.A(p45), .Y(new_n171_));
  AND5x1_ASAP7_75t_R   g081(.A(p32), .B(new_n168_), .C(new_n169_), .D(new_n170_), .E(new_n171_), .Y(new_n172_));
  NOR2x1_ASAP7_75t_R   g082(.A(p39), .B(p38), .Y(new_n173_));
  INVx1_ASAP7_75t_R    g083(.A(new_n173_), .Y(new_n174_));
  NAND2x1_ASAP7_75t_R  g084(.A(p54), .B(p53), .Y(new_n175_));
  NOR2x1_ASAP7_75t_R   g085(.A(p47), .B(p48), .Y(new_n176_));
  NOR3x1_ASAP7_75t_R   g086(.A(new_n174_), .B(new_n175_), .C(new_n176_), .Y(new_n177_));
  NAND2x1_ASAP7_75t_R  g087(.A(p45), .B(p46), .Y(new_n178_));
  OAI21x1_ASAP7_75t_R  g088(.A1(p48), .A2(new_n178_), .B(new_n152_), .Y(new_n179_));
  AND4x2_ASAP7_75t_R   g089(.A(new_n167_), .B(new_n172_), .C(new_n177_), .D(new_n179_), .Y(new_n180_));
  NAND2x1_ASAP7_75t_R  g090(.A(p52), .B(new_n154_), .Y(new_n181_));
  OAI21x1_ASAP7_75t_R  g091(.A1(new_n147_), .A2(new_n153_), .B(new_n181_), .Y(new_n182_));
  INVx1_ASAP7_75t_R    g092(.A(p41), .Y(new_n183_));
  NOR2x1_ASAP7_75t_R   g093(.A(new_n183_), .B(new_n149_), .Y(new_n184_));
  AOI21x1_ASAP7_75t_R  g094(.A1(p42), .A2(new_n184_), .B(p43), .Y(new_n185_));
  NAND2x1_ASAP7_75t_R  g095(.A(new_n183_), .B(new_n149_), .Y(new_n186_));
  OA21x2_ASAP7_75t_R   g096(.A1(p42), .A2(new_n186_), .B(p43), .Y(new_n187_));
  NOR2x1_ASAP7_75t_R   g097(.A(new_n185_), .B(new_n187_), .Y(new_n188_));
  NAND3x1_ASAP7_75t_R  g098(.A(new_n180_), .B(new_n182_), .C(new_n188_), .Y(new_n189_));
  NAND2x1_ASAP7_75t_R  g099(.A(p47), .B(new_n171_), .Y(new_n190_));
  NOR2x1_ASAP7_75t_R   g100(.A(new_n190_), .B(new_n151_), .Y(new_n191_));
  INVx1_ASAP7_75t_R    g101(.A(new_n178_), .Y(new_n192_));
  AO21x1_ASAP7_75t_R   g102(.A1(p46), .A2(new_n151_), .B(new_n192_), .Y(new_n193_));
  NOR2x1_ASAP7_75t_R   g103(.A(p29), .B(p59), .Y(new_n194_));
  OAI21x1_ASAP7_75t_R  g104(.A1(new_n191_), .A2(new_n193_), .B(new_n194_), .Y(new_n195_));
  NAND2x1_ASAP7_75t_R  g105(.A(p40), .B(p56), .Y(new_n196_));
  NOR3x1_ASAP7_75t_R   g106(.A(new_n196_), .B(p50), .C(p37), .Y(new_n197_));
  AND2x2_ASAP7_75t_R   g107(.A(p43), .B(p44), .Y(new_n198_));
  NOR2x1_ASAP7_75t_R   g108(.A(p39), .B(p55), .Y(new_n199_));
  INVx1_ASAP7_75t_R    g109(.A(p38), .Y(new_n200_));
  NOR2x1_ASAP7_75t_R   g110(.A(p36), .B(new_n200_), .Y(new_n201_));
  NOR2x1_ASAP7_75t_R   g111(.A(p42), .B(p45), .Y(new_n202_));
  AND5x1_ASAP7_75t_R   g112(.A(new_n197_), .B(new_n198_), .C(new_n199_), .D(new_n201_), .E(new_n202_), .Y(new_n203_));
  INVx1_ASAP7_75t_R    g113(.A(new_n147_), .Y(new_n204_));
  INVx1_ASAP7_75t_R    g114(.A(new_n175_), .Y(new_n205_));
  NAND2x1_ASAP7_75t_R  g115(.A(p47), .B(p46), .Y(new_n206_));
  NOR2x1_ASAP7_75t_R   g116(.A(p33), .B(p34), .Y(new_n207_));
  AND5x1_ASAP7_75t_R   g117(.A(new_n186_), .B(new_n204_), .C(new_n205_), .D(new_n206_), .E(new_n207_), .Y(new_n208_));
  OR4x2_ASAP7_75t_R    g118(.A(p35), .B(p30), .C(p32), .D(p31), .Y(new_n209_));
  NOR3x1_ASAP7_75t_R   g119(.A(new_n184_), .B(new_n209_), .C(new_n181_), .Y(new_n210_));
  NAND3x1_ASAP7_75t_R  g120(.A(new_n203_), .B(new_n208_), .C(new_n210_), .Y(new_n211_));
  INVx1_ASAP7_75t_R    g121(.A(p46), .Y(new_n212_));
  AOI211x1_ASAP7_75t_R g122(.A1(new_n148_), .A2(new_n149_), .B(new_n212_), .C(new_n150_), .Y(new_n213_));
  OAI21x1_ASAP7_75t_R  g123(.A1(new_n152_), .A2(new_n213_), .B(new_n204_), .Y(new_n214_));
  INVx1_ASAP7_75t_R    g124(.A(new_n161_), .Y(new_n215_));
  AOI21x1_ASAP7_75t_R  g125(.A1(new_n157_), .A2(new_n214_), .B(new_n215_), .Y(new_n216_));
  OAI21x1_ASAP7_75t_R  g126(.A1(new_n195_), .A2(new_n211_), .B(new_n216_), .Y(new_n217_));
  OAI21x1_ASAP7_75t_R  g127(.A1(new_n163_), .A2(new_n189_), .B(new_n217_), .Y(new_n218_));
  NOR3x1_ASAP7_75t_R   g128(.A(new_n126_), .B(new_n144_), .C(new_n127_), .Y(new_n219_));
  AOI21x1_ASAP7_75t_R  g129(.A1(new_n124_), .A2(new_n218_), .B(new_n219_), .Y(o1));
  NOR2x1_ASAP7_75t_R   g130(.A(new_n192_), .B(new_n213_), .Y(new_n221_));
  OAI21x1_ASAP7_75t_R  g131(.A1(new_n151_), .A2(new_n190_), .B(new_n221_), .Y(new_n222_));
  NOR2x1_ASAP7_75t_R   g132(.A(p39), .B(new_n200_), .Y(new_n223_));
  INVx1_ASAP7_75t_R    g133(.A(p42), .Y(new_n224_));
  AND3x1_ASAP7_75t_R   g134(.A(new_n198_), .B(new_n224_), .C(p40), .Y(new_n225_));
  NOR2x1_ASAP7_75t_R   g135(.A(p45), .B(p50), .Y(new_n226_));
  AND3x1_ASAP7_75t_R   g136(.A(new_n226_), .B(p56), .C(new_n156_), .Y(new_n227_));
  NOR2x1_ASAP7_75t_R   g137(.A(p37), .B(p36), .Y(new_n228_));
  NAND2x1_ASAP7_75t_R  g138(.A(p29), .B(p59), .Y(new_n229_));
  AND5x1_ASAP7_75t_R   g139(.A(new_n223_), .B(new_n225_), .C(new_n227_), .D(new_n228_), .E(new_n229_), .Y(new_n230_));
  NOR2x1_ASAP7_75t_R   g140(.A(p30), .B(p31), .Y(new_n231_));
  NOR2x1_ASAP7_75t_R   g141(.A(p34), .B(p35), .Y(new_n232_));
  NOR2x1_ASAP7_75t_R   g142(.A(p33), .B(p32), .Y(new_n233_));
  AND5x1_ASAP7_75t_R   g143(.A(p54), .B(new_n231_), .C(new_n232_), .D(new_n233_), .E(p53), .Y(new_n234_));
  INVx1_ASAP7_75t_R    g144(.A(p40), .Y(new_n235_));
  OR3x1_ASAP7_75t_R    g145(.A(new_n173_), .B(new_n235_), .C(new_n183_), .Y(new_n236_));
  NOR2x1_ASAP7_75t_R   g146(.A(new_n147_), .B(new_n181_), .Y(new_n237_));
  AND5x1_ASAP7_75t_R   g147(.A(new_n186_), .B(new_n234_), .C(new_n236_), .D(new_n237_), .E(new_n206_), .Y(new_n238_));
  NAND3x1_ASAP7_75t_R  g148(.A(new_n222_), .B(new_n230_), .C(new_n238_), .Y(new_n239_));
  INVx1_ASAP7_75t_R    g149(.A(new_n159_), .Y(new_n240_));
  NOR2x1_ASAP7_75t_R   g150(.A(p51), .B(p50), .Y(new_n241_));
  OA21x2_ASAP7_75t_R   g151(.A1(new_n241_), .A2(new_n240_), .B(new_n156_), .Y(new_n242_));
  OAI21x1_ASAP7_75t_R  g152(.A1(new_n240_), .A2(new_n214_), .B(new_n242_), .Y(new_n243_));
  NAND3x1_ASAP7_75t_R  g153(.A(new_n239_), .B(new_n160_), .C(new_n243_), .Y(new_n244_));
  AOI221x1_ASAP7_75t_R g154(.A1(new_n112_), .A2(new_n109_), .B1(new_n122_), .B2(new_n102_), .C(new_n123_), .Y(new_n245_));
  NOR3x1_ASAP7_75t_R   g155(.A(new_n219_), .B(new_n244_), .C(new_n245_), .Y(o2));
  assign               o3 = 1'b0;
  assign               o4 = 1'b0;
  assign               o5 = 1'b0;
  assign               o6 = 1'b0;
  assign               o7 = 1'b0;
  assign               o8 = 1'b0;
  assign               o9 = 1'b0;
  assign               o10 = 1'b0;
  assign               o11 = 1'b0;
  assign               o12 = 1'b0;
  assign               o13 = 1'b0;
  assign               o14 = 1'b0;
  assign               o15 = 1'b0;
  assign               o16 = 1'b0;
  assign               o17 = 1'b0;
  assign               o18 = 1'b0;
  assign               o19 = 1'b0;
  assign               o20 = 1'b0;
  assign               o21 = 1'b0;
  assign               o22 = 1'b0;
  assign               o23 = 1'b0;
  assign               o24 = 1'b0;
  assign               o25 = 1'b0;
  assign               o26 = 1'b0;
  assign               o27 = 1'b0;
  assign               o28 = 1'b0;
  assign               o29 = 1'b0;
endmodule


