// Benchmark "/tmp/" written by ABC on Tue Oct 20 18:11:47 2026

module \/tmp/  ( 
    p19, p2, p51, p39, p30, p15, p5, p7, p37, p38, p21, p17, p57, p22, p10,
    p36, p50, p18, p29, p3, p33, p42, p43, p52, p24, p16, p12, p0, p53,
    p41, p23, p25, p11, p28, p32, p59, p6, p58, p55, p49, p14, p44, p48,
    p46, p54, p31, p40, p26, p34, p9, p8, p20, p56, p4, p47, p1, p27, p45,
    p35, p13,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25, o26, o27, o28, o29  );
  input  p19, p2, p51, p39, p30, p15, p5, p7, p37, p38, p21, p17, p57,
    p22, p10, p36, p50, p18, p29, p3, p33, p42, p43, p52, p24, p16, p12,
    p0, p53, p41, p23, p25, p11, p28, p32, p59, p6, p58, p55, p49, p14,
    p44, p48, p46, p54, p31, p40, p26, p34, p9, p8, p20, p56, p4, p47, p1,
    p27, p45, p35, p13;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25, o26, o27, o28, o29;
  wire new_n91_, new_n92_, new_n93_, new_n94_, new_n95_, new_n96_, new_n97_,
    new_n98_, new_n99_, new_n100_, new_n101_, new_n102_, new_n103_,
    new_n104_, new_n105_, new_n106_, new_n107_, new_n108_, new_n109_,
    new_n110_, new_n111_, new_n112_, new_n113_, new_n114_, new_n115_,
    new_n116_, new_n117_, new_n118_, new_n119_, new_n120_, new_n121_,
    new_n122_, new_n123_, new_n124_, new_n125_, new_n126_, new_n127_,
    new_n128_, new_n129_, new_n130_, new_n131_, new_n132_, new_n133_,
    new_n134_, new_n135_, new_n136_, new_n137_, new_n138_, new_n139_,
    new_n140_, new_n141_, new_n142_, new_n143_, new_n144_, new_n145_,
    new_n147_, new_n148_, new_n149_, new_n150_, new_n151_, new_n152_,
    new_n153_, new_n154_, new_n155_, new_n156_, new_n157_, new_n158_,
    new_n159_, new_n160_, new_n161_, new_n162_, new_n163_, new_n164_,
    new_n165_, new_n166_, new_n167_, new_n168_, new_n169_, new_n170_,
    new_n171_, new_n172_, new_n173_, new_n174_, new_n175_, new_n176_,
    new_n177_, new_n178_, new_n179_, new_n180_, new_n181_, new_n182_,
    new_n183_, new_n184_, new_n185_, new_n186_, new_n187_, new_n188_,
    new_n189_, new_n190_, new_n191_, new_n192_, new_n193_, new_n194_,
    new_n195_, new_n196_, new_n197_, new_n198_, new_n199_, new_n200_,
    new_n201_, new_n202_, new_n203_, new_n204_, new_n205_, new_n206_,
    new_n207_, new_n208_, new_n209_, new_n210_, new_n211_, new_n212_,
    new_n213_, new_n214_, new_n215_, new_n216_, new_n217_, new_n219_,
    new_n220_, new_n221_, new_n222_, new_n223_, new_n224_, new_n225_,
    new_n226_, new_n227_, new_n228_, new_n229_, new_n230_, new_n231_,
    new_n232_, new_n233_, new_n234_, new_n235_, new_n236_, new_n237_,
    new_n238_, new_n239_, new_n240_, new_n241_;
  AND3x1_ASAP7_75t_R   g000(.A(p28), .B(p26), .C(p27), .Y(new_n91_));
  INVx1_ASAP7_75t_R    g001(.A(new_n91_), .Y(new_n92_));
  AND2x2_ASAP7_75t_R   g002(.A(p24), .B(p23), .Y(new_n93_));
  INVx1_ASAP7_75t_R    g003(.A(new_n93_), .Y(new_n94_));
  NOR2x1_ASAP7_75t_R   g004(.A(p12), .B(p11), .Y(new_n95_));
  OAI21x1_ASAP7_75t_R  g005(.A1(p9), .A2(p8), .B(p10), .Y(new_n96_));
  NAND2x1_ASAP7_75t_R  g006(.A(new_n95_), .B(new_n96_), .Y(new_n97_));
  AND2x2_ASAP7_75t_R   g007(.A(p14), .B(p13), .Y(new_n98_));
  NAND3x1_ASAP7_75t_R  g008(.A(new_n97_), .B(p16), .C(new_n98_), .Y(new_n99_));
  NOR2x1_ASAP7_75t_R   g009(.A(p21), .B(p20), .Y(new_n100_));
  AO21x1_ASAP7_75t_R   g010(.A1(p15), .A2(p16), .B(p17), .Y(new_n101_));
  INVx1_ASAP7_75t_R    g011(.A(new_n101_), .Y(new_n102_));
  NAND2x1_ASAP7_75t_R  g012(.A(p19), .B(p18), .Y(new_n103_));
  INVx1_ASAP7_75t_R    g013(.A(p22), .Y(new_n104_));
  AOI21x1_ASAP7_75t_R  g014(.A1(new_n103_), .A2(new_n100_), .B(new_n104_), .Y(new_n105_));
  INVx1_ASAP7_75t_R    g015(.A(new_n105_), .Y(new_n106_));
  AO31x2_ASAP7_75t_R   g016(.A1(new_n99_), .A2(new_n100_), .A3(new_n102_), .B(new_n106_), .Y(new_n107_));
  NAND2x1_ASAP7_75t_R  g017(.A(p25), .B(new_n91_), .Y(new_n108_));
  OA31x2_ASAP7_75t_R   g018(.A1(new_n92_), .A2(new_n94_), .A3(new_n107_), .B1(new_n108_), .Y(new_n109_));
  NAND2x1_ASAP7_75t_R  g019(.A(new_n102_), .B(new_n99_), .Y(new_n110_));
  AND2x2_ASAP7_75t_R   g020(.A(p10), .B(p18), .Y(new_n111_));
  NOR2x1_ASAP7_75t_R   g021(.A(p9), .B(p8), .Y(new_n112_));
  AND5x1_ASAP7_75t_R   g022(.A(p4), .B(new_n111_), .C(p1), .D(new_n95_), .E(new_n112_), .Y(new_n113_));
  AND2x2_ASAP7_75t_R   g023(.A(p3), .B(p24), .Y(new_n114_));
  INVx1_ASAP7_75t_R    g024(.A(p25), .Y(new_n115_));
  AND3x1_ASAP7_75t_R   g025(.A(new_n114_), .B(p0), .C(new_n115_), .Y(new_n116_));
  AND2x2_ASAP7_75t_R   g026(.A(p5), .B(p7), .Y(new_n117_));
  INVx1_ASAP7_75t_R    g027(.A(p15), .Y(new_n118_));
  AND3x1_ASAP7_75t_R   g028(.A(new_n117_), .B(p2), .C(new_n118_), .Y(new_n119_));
  NAND3x1_ASAP7_75t_R  g029(.A(new_n113_), .B(new_n116_), .C(new_n119_), .Y(new_n120_));
  INVx1_ASAP7_75t_R    g030(.A(new_n100_), .Y(new_n121_));
  AOI21x1_ASAP7_75t_R  g031(.A1(p22), .A2(new_n121_), .B(p23), .Y(new_n122_));
  AOI211x1_ASAP7_75t_R g032(.A1(new_n98_), .A2(new_n97_), .B(p15), .C(p16), .Y(new_n123_));
  AND3x1_ASAP7_75t_R   g033(.A(new_n98_), .B(p59), .C(p6), .Y(new_n124_));
  AND3x1_ASAP7_75t_R   g034(.A(new_n100_), .B(p19), .C(p22), .Y(new_n125_));
  NAND3x1_ASAP7_75t_R  g035(.A(new_n124_), .B(new_n91_), .C(new_n125_), .Y(new_n126_));
  OR5x1_ASAP7_75t_R    g036(.A(new_n110_), .B(new_n120_), .C(new_n122_), .D(new_n123_), .E(new_n126_), .Y(new_n127_));
  INVx1_ASAP7_75t_R    g037(.A(p16), .Y(new_n128_));
  NAND2x1_ASAP7_75t_R  g038(.A(p14), .B(p13), .Y(new_n129_));
  AOI211x1_ASAP7_75t_R g039(.A1(new_n95_), .A2(new_n96_), .B(new_n128_), .C(new_n129_), .Y(new_n130_));
  OA31x2_ASAP7_75t_R   g040(.A1(new_n121_), .A2(new_n101_), .A3(new_n130_), .B1(new_n105_), .Y(new_n131_));
  NAND3x1_ASAP7_75t_R  g041(.A(new_n131_), .B(new_n91_), .C(new_n93_), .Y(new_n132_));
  AO21x1_ASAP7_75t_R   g042(.A1(p15), .A2(p16), .B(new_n130_), .Y(new_n133_));
  INVx1_ASAP7_75t_R    g043(.A(p9), .Y(new_n134_));
  INVx1_ASAP7_75t_R    g044(.A(p4), .Y(new_n135_));
  INVx1_ASAP7_75t_R    g045(.A(p1), .Y(new_n136_));
  AND5x1_ASAP7_75t_R   g046(.A(new_n134_), .B(new_n125_), .C(p8), .D(new_n135_), .E(new_n136_), .Y(new_n137_));
  AO21x1_ASAP7_75t_R   g047(.A1(new_n95_), .A2(new_n96_), .B(new_n118_), .Y(new_n138_));
  NOR2x1_ASAP7_75t_R   g048(.A(p2), .B(p5), .Y(new_n139_));
  AND5x1_ASAP7_75t_R   g049(.A(p14), .B(new_n93_), .C(new_n111_), .D(p13), .E(new_n139_), .Y(new_n140_));
  OR4x2_ASAP7_75t_R    g050(.A(p0), .B(p25), .C(p11), .D(p6), .Y(new_n141_));
  OR4x2_ASAP7_75t_R    g051(.A(p7), .B(p17), .C(p3), .D(p12), .Y(new_n142_));
  NOR2x1_ASAP7_75t_R   g052(.A(new_n141_), .B(new_n142_), .Y(new_n143_));
  AND5x1_ASAP7_75t_R   g053(.A(new_n133_), .B(new_n137_), .C(new_n138_), .D(new_n140_), .E(new_n143_), .Y(new_n144_));
  AOI21x1_ASAP7_75t_R  g054(.A1(new_n132_), .A2(new_n108_), .B(new_n144_), .Y(new_n145_));
  AO21x1_ASAP7_75t_R   g055(.A1(new_n109_), .A2(new_n127_), .B(new_n145_), .Y(o0));
  NAND2x1_ASAP7_75t_R  g056(.A(p49), .B(p48), .Y(new_n147_));
  NOR2x1_ASAP7_75t_R   g057(.A(p42), .B(p41), .Y(new_n148_));
  OAI21x1_ASAP7_75t_R  g058(.A1(p39), .A2(p38), .B(p40), .Y(new_n149_));
  NAND2x1_ASAP7_75t_R  g059(.A(p43), .B(p44), .Y(new_n150_));
  AOI21x1_ASAP7_75t_R  g060(.A1(new_n148_), .A2(new_n149_), .B(new_n150_), .Y(new_n151_));
  AO21x1_ASAP7_75t_R   g061(.A1(p46), .A2(p45), .B(p47), .Y(new_n152_));
  AOI21x1_ASAP7_75t_R  g062(.A1(p46), .A2(new_n151_), .B(new_n152_), .Y(new_n153_));
  INVx1_ASAP7_75t_R    g063(.A(p51), .Y(new_n154_));
  INVx1_ASAP7_75t_R    g064(.A(p50), .Y(new_n155_));
  INVx1_ASAP7_75t_R    g065(.A(p55), .Y(new_n156_));
  AND3x1_ASAP7_75t_R   g066(.A(new_n154_), .B(new_n155_), .C(new_n156_), .Y(new_n157_));
  OAI21x1_ASAP7_75t_R  g067(.A1(new_n147_), .A2(new_n153_), .B(new_n157_), .Y(new_n158_));
  AND3x1_ASAP7_75t_R   g068(.A(p52), .B(p53), .C(p54), .Y(new_n159_));
  AND3x1_ASAP7_75t_R   g069(.A(p57), .B(p58), .C(p56), .Y(new_n160_));
  OA21x2_ASAP7_75t_R   g070(.A1(p55), .A2(new_n159_), .B(new_n160_), .Y(new_n161_));
  INVx1_ASAP7_75t_R    g071(.A(p59), .Y(new_n162_));
  AOI22x1_ASAP7_75t_R  g072(.A1(new_n158_), .A2(new_n161_), .B1(new_n155_), .B2(new_n162_), .Y(new_n163_));
  NAND2x1_ASAP7_75t_R  g073(.A(p52), .B(new_n154_), .Y(new_n164_));
  OAI21x1_ASAP7_75t_R  g074(.A1(new_n147_), .A2(new_n153_), .B(new_n164_), .Y(new_n165_));
  INVx1_ASAP7_75t_R    g075(.A(p48), .Y(new_n166_));
  INVx1_ASAP7_75t_R    g076(.A(p47), .Y(new_n167_));
  NAND2x1_ASAP7_75t_R  g077(.A(p44), .B(p46), .Y(new_n168_));
  NAND2x1_ASAP7_75t_R  g078(.A(p53), .B(p54), .Y(new_n169_));
  AOI211x1_ASAP7_75t_R g079(.A1(new_n166_), .A2(new_n167_), .B(new_n168_), .C(new_n169_), .Y(new_n170_));
  NAND2x1_ASAP7_75t_R  g080(.A(p30), .B(p37), .Y(new_n171_));
  NOR3x1_ASAP7_75t_R   g081(.A(new_n171_), .B(p39), .C(p38), .Y(new_n172_));
  AND4x2_ASAP7_75t_R   g082(.A(p36), .B(p29), .C(p33), .D(p32), .Y(new_n173_));
  NAND3x1_ASAP7_75t_R  g083(.A(new_n170_), .B(new_n172_), .C(new_n173_), .Y(new_n174_));
  AND4x2_ASAP7_75t_R   g084(.A(new_n156_), .B(p49), .C(p31), .D(p40), .Y(new_n175_));
  INVx1_ASAP7_75t_R    g085(.A(p45), .Y(new_n176_));
  AND3x1_ASAP7_75t_R   g086(.A(new_n176_), .B(p34), .C(p35), .Y(new_n177_));
  NAND3x1_ASAP7_75t_R  g087(.A(new_n175_), .B(new_n177_), .C(new_n160_), .Y(new_n178_));
  NAND2x1_ASAP7_75t_R  g088(.A(p46), .B(p45), .Y(new_n179_));
  OA21x2_ASAP7_75t_R   g089(.A1(p48), .A2(new_n179_), .B(new_n152_), .Y(new_n180_));
  NOR3x1_ASAP7_75t_R   g090(.A(new_n174_), .B(new_n178_), .C(new_n180_), .Y(new_n181_));
  INVx1_ASAP7_75t_R    g091(.A(p41), .Y(new_n182_));
  NOR2x1_ASAP7_75t_R   g092(.A(new_n182_), .B(new_n149_), .Y(new_n183_));
  AOI21x1_ASAP7_75t_R  g093(.A1(p42), .A2(new_n183_), .B(p43), .Y(new_n184_));
  NAND2x1_ASAP7_75t_R  g094(.A(new_n182_), .B(new_n149_), .Y(new_n185_));
  OA21x2_ASAP7_75t_R   g095(.A1(p42), .A2(new_n185_), .B(p43), .Y(new_n186_));
  NOR2x1_ASAP7_75t_R   g096(.A(new_n184_), .B(new_n186_), .Y(new_n187_));
  NAND3x1_ASAP7_75t_R  g097(.A(new_n165_), .B(new_n181_), .C(new_n187_), .Y(new_n188_));
  NAND2x1_ASAP7_75t_R  g098(.A(p47), .B(new_n176_), .Y(new_n189_));
  NOR2x1_ASAP7_75t_R   g099(.A(new_n189_), .B(new_n151_), .Y(new_n190_));
  INVx1_ASAP7_75t_R    g100(.A(new_n179_), .Y(new_n191_));
  AO21x1_ASAP7_75t_R   g101(.A1(p46), .A2(new_n151_), .B(new_n191_), .Y(new_n192_));
  NOR2x1_ASAP7_75t_R   g102(.A(p29), .B(p59), .Y(new_n193_));
  OAI21x1_ASAP7_75t_R  g103(.A1(new_n190_), .A2(new_n192_), .B(new_n193_), .Y(new_n194_));
  INVx1_ASAP7_75t_R    g104(.A(p38), .Y(new_n195_));
  OR5x1_ASAP7_75t_R    g105(.A(new_n195_), .B(p37), .C(p36), .D(p50), .E(p42), .Y(new_n196_));
  NAND2x1_ASAP7_75t_R  g106(.A(p40), .B(p56), .Y(new_n197_));
  OR3x1_ASAP7_75t_R    g107(.A(new_n197_), .B(p55), .C(p45), .Y(new_n198_));
  INVx1_ASAP7_75t_R    g108(.A(p43), .Y(new_n199_));
  INVx1_ASAP7_75t_R    g109(.A(p44), .Y(new_n200_));
  OR3x1_ASAP7_75t_R    g110(.A(new_n199_), .B(new_n200_), .C(p39), .Y(new_n201_));
  NOR3x1_ASAP7_75t_R   g111(.A(new_n196_), .B(new_n198_), .C(new_n201_), .Y(new_n202_));
  INVx1_ASAP7_75t_R    g112(.A(new_n147_), .Y(new_n203_));
  INVx1_ASAP7_75t_R    g113(.A(new_n169_), .Y(new_n204_));
  NAND2x1_ASAP7_75t_R  g114(.A(p46), .B(p47), .Y(new_n205_));
  NOR2x1_ASAP7_75t_R   g115(.A(p30), .B(p33), .Y(new_n206_));
  AND5x1_ASAP7_75t_R   g116(.A(new_n185_), .B(new_n203_), .C(new_n204_), .D(new_n205_), .E(new_n206_), .Y(new_n207_));
  OR4x2_ASAP7_75t_R    g117(.A(p32), .B(p31), .C(p34), .D(p35), .Y(new_n208_));
  NOR3x1_ASAP7_75t_R   g118(.A(new_n183_), .B(new_n208_), .C(new_n164_), .Y(new_n209_));
  NAND3x1_ASAP7_75t_R  g119(.A(new_n202_), .B(new_n207_), .C(new_n209_), .Y(new_n210_));
  AOI211x1_ASAP7_75t_R g120(.A1(new_n148_), .A2(new_n149_), .B(new_n199_), .C(new_n168_), .Y(new_n211_));
  OAI21x1_ASAP7_75t_R  g121(.A1(new_n152_), .A2(new_n211_), .B(new_n203_), .Y(new_n212_));
  INVx1_ASAP7_75t_R    g122(.A(new_n161_), .Y(new_n213_));
  AOI21x1_ASAP7_75t_R  g123(.A1(new_n157_), .A2(new_n212_), .B(new_n213_), .Y(new_n214_));
  OAI21x1_ASAP7_75t_R  g124(.A1(new_n194_), .A2(new_n210_), .B(new_n214_), .Y(new_n215_));
  OAI21x1_ASAP7_75t_R  g125(.A1(new_n163_), .A2(new_n188_), .B(new_n215_), .Y(new_n216_));
  NAND3x1_ASAP7_75t_R  g126(.A(new_n127_), .B(new_n132_), .C(new_n108_), .Y(new_n217_));
  OAI21x1_ASAP7_75t_R  g127(.A1(new_n145_), .A2(new_n216_), .B(new_n217_), .Y(o1));
  OR3x1_ASAP7_75t_R    g128(.A(new_n190_), .B(new_n191_), .C(new_n211_), .Y(new_n219_));
  NOR2x1_ASAP7_75t_R   g129(.A(p50), .B(p45), .Y(new_n220_));
  AND3x1_ASAP7_75t_R   g130(.A(new_n220_), .B(new_n156_), .C(p56), .Y(new_n221_));
  INVx1_ASAP7_75t_R    g131(.A(p40), .Y(new_n222_));
  NOR3x1_ASAP7_75t_R   g132(.A(new_n150_), .B(p42), .C(new_n222_), .Y(new_n223_));
  NOR2x1_ASAP7_75t_R   g133(.A(p39), .B(new_n195_), .Y(new_n224_));
  NOR2x1_ASAP7_75t_R   g134(.A(p37), .B(p36), .Y(new_n225_));
  NAND2x1_ASAP7_75t_R  g135(.A(p29), .B(p59), .Y(new_n226_));
  AND5x1_ASAP7_75t_R   g136(.A(new_n221_), .B(new_n223_), .C(new_n224_), .D(new_n225_), .E(new_n226_), .Y(new_n227_));
  NOR2x1_ASAP7_75t_R   g137(.A(p30), .B(p31), .Y(new_n228_));
  NOR2x1_ASAP7_75t_R   g138(.A(p34), .B(p35), .Y(new_n229_));
  NOR2x1_ASAP7_75t_R   g139(.A(p33), .B(p32), .Y(new_n230_));
  AND5x1_ASAP7_75t_R   g140(.A(p53), .B(new_n228_), .C(new_n229_), .D(new_n230_), .E(p54), .Y(new_n231_));
  NOR2x1_ASAP7_75t_R   g141(.A(p39), .B(p38), .Y(new_n232_));
  OR3x1_ASAP7_75t_R    g142(.A(new_n232_), .B(new_n182_), .C(new_n222_), .Y(new_n233_));
  NOR2x1_ASAP7_75t_R   g143(.A(new_n147_), .B(new_n164_), .Y(new_n234_));
  AND5x1_ASAP7_75t_R   g144(.A(new_n185_), .B(new_n231_), .C(new_n233_), .D(new_n234_), .E(new_n205_), .Y(new_n235_));
  NAND3x1_ASAP7_75t_R  g145(.A(new_n219_), .B(new_n227_), .C(new_n235_), .Y(new_n236_));
  INVx1_ASAP7_75t_R    g146(.A(new_n159_), .Y(new_n237_));
  NOR2x1_ASAP7_75t_R   g147(.A(p51), .B(p50), .Y(new_n238_));
  OA21x2_ASAP7_75t_R   g148(.A1(new_n238_), .A2(new_n237_), .B(new_n156_), .Y(new_n239_));
  OAI21x1_ASAP7_75t_R  g149(.A1(new_n237_), .A2(new_n212_), .B(new_n239_), .Y(new_n240_));
  NAND3x1_ASAP7_75t_R  g150(.A(new_n236_), .B(new_n160_), .C(new_n240_), .Y(new_n241_));
  AOI211x1_ASAP7_75t_R g151(.A1(new_n109_), .A2(new_n127_), .B(new_n145_), .C(new_n241_), .Y(o2));
  assign               o3 = 1'b0;
  assign               o4 = 1'b0;
  assign               o5 = 1'b0;
  assign               o6 = 1'b0;
  assign               o7 = 1'b0;
  assign               o8 = 1'b0;
  assign               o9 = 1'b0;
  assign               o10 = 1'b0;
  assign               o11 = 1'b0;
  assign               o12 = 1'b0;
  assign               o13 = 1'b0;
  assign               o14 = 1'b0;
  assign               o15 = 1'b0;
  assign               o16 = 1'b0;
  assign               o17 = 1'b0;
  assign               o18 = 1'b0;
  assign               o19 = 1'b0;
  assign               o20 = 1'b0;
  assign               o21 = 1'b0;
  assign               o22 = 1'b0;
  assign               o23 = 1'b0;
  assign               o24 = 1'b0;
  assign               o25 = 1'b0;
  assign               o26 = 1'b0;
  assign               o27 = 1'b0;
  assign               o28 = 1'b0;
  assign               o29 = 1'b0;
endmodule


