// Benchmark "/tmp/" written by ABC on Tue Oct 20 18:11:49 2026

module \/tmp/  ( 
    p24, p1, p57, p18, p53, p58, p2, p11, p40, p15, p35, p25, p31, p52,
    p47, p9, p59, p48, p44, p23, p55, p30, p0, p20, p43, p49, p28, p46,
    p45, p29, p51, p42, p37, p5, p50, p54, p56, p41, p21, p6, p34, p10,
    p32, p26, p17, p36, p12, p16, p39, p3, p4, p14, p22, p13, p27, p38, p7,
    p33, p19, p8,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25, o26, o27, o28, o29  );
  input  p24, p1, p57, p18, p53, p58, p2, p11, p40, p15, p35, p25, p31,
    p52, p47, p9, p59, p48, p44, p23, p55, p30, p0, p20, p43, p49, p28,
    p46, p45, p29, p51, p42, p37, p5, p50, p54, p56, p41, p21, p6, p34,
    p10, p32, p26, p17, p36, p12, p16, p39, p3, p4, p14, p22, p13, p27,
    p38, p7, p33, p19, p8;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25, o26, o27, o28, o29;
  wire new_n91_, new_n92_, new_n93_, new_n94_, new_n95_, new_n96_, new_n97_,
    new_n98_, new_n99_, new_n100_, new_n101_, new_n102_, new_n103_,
    new_n104_, new_n105_, new_n106_, new_n107_, new_n108_, new_n109_,
    new_n110_, new_n111_, new_n112_, new_n113_, new_n114_, new_n115_,
    new_n116_, new_n117_, new_n118_, new_n119_, new_n120_, new_n121_,
    new_n122_, new_n123_, new_n124_, new_n125_, new_n126_, new_n127_,
    new_n128_, new_n129_, new_n130_, new_n131_, new_n132_, new_n133_,
    new_n134_, new_n135_, new_n136_, new_n137_, new_n138_, new_n139_,
    new_n140_, new_n141_, new_n142_, new_n143_, new_n145_, new_n146_,
    new_n147_, new_n148_, new_n149_, new_n150_, new_n151_, new_n152_,
    new_n153_, new_n154_, new_n155_, new_n156_, new_n157_, new_n158_,
    new_n159_, new_n160_, new_n161_, new_n162_, new_n163_, new_n164_,
    new_n165_, new_n166_, new_n167_, new_n168_, new_n169_, new_n170_,
    new_n171_, new_n172_, new_n173_, new_n174_, new_n175_, new_n176_,
    new_n177_, new_n178_, new_n179_, new_n180_, new_n181_, new_n182_,
    new_n183_, new_n184_, new_n185_, new_n186_, new_n187_, new_n188_,
    new_n189_, new_n190_, new_n191_, new_n192_, new_n193_, new_n194_,
    new_n195_, new_n196_, new_n197_, new_n198_, new_n199_, new_n200_,
    new_n201_, new_n202_, new_n203_, new_n204_, new_n205_, new_n206_,
    new_n207_, new_n208_, new_n209_, new_n210_, new_n211_, new_n212_,
    new_n213_, new_n214_, new_n216_, new_n217_, new_n218_, new_n219_,
    new_n220_, new_n221_, new_n222_, new_n223_, new_n224_, new_n225_,
    new_n226_;
  NAND3x1_ASAP7_75t_R  g000(.A(p28), .B(p26), .C(p27), .Y(new_n91_));
  INVx1_ASAP7_75t_R    g001(.A(new_n91_), .Y(new_n92_));
  INVx1_ASAP7_75t_R    g002(.A(p20), .Y(new_n93_));
  INVx1_ASAP7_75t_R    g003(.A(p21), .Y(new_n94_));
  NAND2x1_ASAP7_75t_R  g004(.A(new_n93_), .B(new_n94_), .Y(new_n95_));
  NAND2x1_ASAP7_75t_R  g005(.A(p22), .B(new_n95_), .Y(new_n96_));
  AO21x1_ASAP7_75t_R   g006(.A1(p15), .A2(p16), .B(p17), .Y(new_n97_));
  NOR2x1_ASAP7_75t_R   g007(.A(p11), .B(p12), .Y(new_n98_));
  OAI21x1_ASAP7_75t_R  g008(.A1(p9), .A2(p8), .B(p10), .Y(new_n99_));
  INVx1_ASAP7_75t_R    g009(.A(p16), .Y(new_n100_));
  NAND2x1_ASAP7_75t_R  g010(.A(p14), .B(p13), .Y(new_n101_));
  AOI211x1_ASAP7_75t_R g011(.A1(new_n98_), .A2(new_n99_), .B(new_n100_), .C(new_n101_), .Y(new_n102_));
  AND3x1_ASAP7_75t_R   g012(.A(p18), .B(p22), .C(p19), .Y(new_n103_));
  OAI21x1_ASAP7_75t_R  g013(.A1(new_n97_), .A2(new_n102_), .B(new_n103_), .Y(new_n104_));
  NAND2x1_ASAP7_75t_R  g014(.A(p24), .B(p23), .Y(new_n105_));
  AOI21x1_ASAP7_75t_R  g015(.A1(new_n96_), .A2(new_n104_), .B(new_n105_), .Y(new_n106_));
  AND2x2_ASAP7_75t_R   g016(.A(p25), .B(new_n92_), .Y(new_n107_));
  AO21x1_ASAP7_75t_R   g017(.A1(new_n92_), .A2(new_n106_), .B(new_n107_), .Y(new_n108_));
  AOI21x1_ASAP7_75t_R  g018(.A1(new_n98_), .A2(new_n99_), .B(new_n101_), .Y(new_n109_));
  OAI21x1_ASAP7_75t_R  g019(.A1(p15), .A2(new_n109_), .B(p16), .Y(new_n110_));
  OR4x2_ASAP7_75t_R    g020(.A(p25), .B(p9), .C(p0), .D(p5), .Y(new_n111_));
  OR2x4_ASAP7_75t_R    g021(.A(p17), .B(p12), .Y(new_n112_));
  INVx1_ASAP7_75t_R    g022(.A(p10), .Y(new_n113_));
  OR4x2_ASAP7_75t_R    g023(.A(new_n111_), .B(new_n112_), .C(p6), .D(new_n113_), .Y(new_n114_));
  INVx1_ASAP7_75t_R    g024(.A(p7), .Y(new_n115_));
  NAND2x1_ASAP7_75t_R  g025(.A(p8), .B(new_n115_), .Y(new_n116_));
  NAND2x1_ASAP7_75t_R  g026(.A(p22), .B(p19), .Y(new_n117_));
  OR5x1_ASAP7_75t_R    g027(.A(p3), .B(new_n95_), .C(new_n116_), .D(p4), .E(new_n117_), .Y(new_n118_));
  INVx1_ASAP7_75t_R    g028(.A(p15), .Y(new_n119_));
  AOI211x1_ASAP7_75t_R g029(.A1(new_n98_), .A2(new_n99_), .B(new_n119_), .C(new_n101_), .Y(new_n120_));
  INVx1_ASAP7_75t_R    g030(.A(p1), .Y(new_n121_));
  NAND2x1_ASAP7_75t_R  g031(.A(p18), .B(new_n121_), .Y(new_n122_));
  OR5x1_ASAP7_75t_R    g032(.A(p2), .B(new_n122_), .C(p11), .D(new_n105_), .E(new_n101_), .Y(new_n123_));
  OR5x1_ASAP7_75t_R    g033(.A(new_n110_), .B(new_n114_), .C(new_n118_), .D(new_n120_), .E(new_n123_), .Y(new_n124_));
  AO21x1_ASAP7_75t_R   g034(.A1(p16), .A2(new_n109_), .B(new_n97_), .Y(new_n125_));
  NAND2x1_ASAP7_75t_R  g035(.A(p4), .B(p14), .Y(new_n126_));
  NAND2x1_ASAP7_75t_R  g036(.A(p13), .B(p7), .Y(new_n127_));
  NOR3x1_ASAP7_75t_R   g037(.A(new_n91_), .B(new_n126_), .C(new_n127_), .Y(new_n128_));
  INVx1_ASAP7_75t_R    g038(.A(p9), .Y(new_n129_));
  INVx1_ASAP7_75t_R    g039(.A(p8), .Y(new_n130_));
  AND3x1_ASAP7_75t_R   g040(.A(new_n98_), .B(new_n129_), .C(new_n130_), .Y(new_n131_));
  NOR3x1_ASAP7_75t_R   g041(.A(new_n117_), .B(p20), .C(p21), .Y(new_n132_));
  NAND3x1_ASAP7_75t_R  g042(.A(new_n128_), .B(new_n131_), .C(new_n132_), .Y(new_n133_));
  NOR2x1_ASAP7_75t_R   g043(.A(p15), .B(p25), .Y(new_n134_));
  AND3x1_ASAP7_75t_R   g044(.A(new_n134_), .B(p59), .C(p0), .Y(new_n135_));
  NAND2x1_ASAP7_75t_R  g045(.A(p24), .B(p1), .Y(new_n136_));
  NAND2x1_ASAP7_75t_R  g046(.A(p18), .B(p2), .Y(new_n137_));
  AOI211x1_ASAP7_75t_R g047(.A1(new_n119_), .A2(new_n100_), .B(new_n136_), .C(new_n137_), .Y(new_n138_));
  AND4x2_ASAP7_75t_R   g048(.A(p5), .B(p6), .C(p10), .D(p3), .Y(new_n139_));
  NAND3x1_ASAP7_75t_R  g049(.A(new_n135_), .B(new_n138_), .C(new_n139_), .Y(new_n140_));
  NOR3x1_ASAP7_75t_R   g050(.A(new_n125_), .B(new_n133_), .C(new_n140_), .Y(new_n141_));
  AO21x1_ASAP7_75t_R   g051(.A1(p22), .A2(new_n95_), .B(p23), .Y(new_n142_));
  AOI221x1_ASAP7_75t_R g052(.A1(new_n141_), .A2(new_n142_), .B1(new_n106_), .B2(new_n92_), .C(new_n107_), .Y(new_n143_));
  AO21x1_ASAP7_75t_R   g053(.A1(new_n108_), .A2(new_n124_), .B(new_n143_), .Y(o0));
  AOI211x1_ASAP7_75t_R g054(.A1(new_n96_), .A2(new_n104_), .B(new_n91_), .C(new_n105_), .Y(new_n145_));
  OAI21x1_ASAP7_75t_R  g055(.A1(new_n107_), .A2(new_n145_), .B(new_n124_), .Y(new_n146_));
  INVx1_ASAP7_75t_R    g056(.A(p42), .Y(new_n147_));
  NOR2x1_ASAP7_75t_R   g057(.A(p45), .B(p50), .Y(new_n148_));
  INVx1_ASAP7_75t_R    g058(.A(p55), .Y(new_n149_));
  AND3x1_ASAP7_75t_R   g059(.A(new_n148_), .B(new_n149_), .C(p43), .Y(new_n150_));
  NOR2x1_ASAP7_75t_R   g060(.A(p36), .B(p39), .Y(new_n151_));
  AND3x1_ASAP7_75t_R   g061(.A(new_n151_), .B(p56), .C(p38), .Y(new_n152_));
  INVx1_ASAP7_75t_R    g062(.A(p37), .Y(new_n153_));
  AND2x2_ASAP7_75t_R   g063(.A(p40), .B(p44), .Y(new_n154_));
  AND5x1_ASAP7_75t_R   g064(.A(new_n147_), .B(new_n150_), .C(new_n152_), .D(new_n153_), .E(new_n154_), .Y(new_n155_));
  NOR2x1_ASAP7_75t_R   g065(.A(p39), .B(p38), .Y(new_n156_));
  INVx1_ASAP7_75t_R    g066(.A(p40), .Y(new_n157_));
  INVx1_ASAP7_75t_R    g067(.A(p41), .Y(new_n158_));
  OR3x1_ASAP7_75t_R    g068(.A(new_n156_), .B(new_n157_), .C(new_n158_), .Y(new_n159_));
  NOR2x1_ASAP7_75t_R   g069(.A(p34), .B(p32), .Y(new_n160_));
  INVx1_ASAP7_75t_R    g070(.A(p30), .Y(new_n161_));
  INVx1_ASAP7_75t_R    g071(.A(p51), .Y(new_n162_));
  INVx1_ASAP7_75t_R    g072(.A(p33), .Y(new_n163_));
  AND5x1_ASAP7_75t_R   g073(.A(p52), .B(new_n160_), .C(new_n161_), .D(new_n162_), .E(new_n163_), .Y(new_n164_));
  AND2x2_ASAP7_75t_R   g074(.A(new_n159_), .B(new_n164_), .Y(new_n165_));
  OAI21x1_ASAP7_75t_R  g075(.A1(p39), .A2(p38), .B(p40), .Y(new_n166_));
  NAND2x1_ASAP7_75t_R  g076(.A(new_n158_), .B(new_n166_), .Y(new_n167_));
  AND2x2_ASAP7_75t_R   g077(.A(p48), .B(p49), .Y(new_n168_));
  AND2x2_ASAP7_75t_R   g078(.A(p53), .B(p54), .Y(new_n169_));
  NAND2x1_ASAP7_75t_R  g079(.A(p47), .B(p46), .Y(new_n170_));
  NOR2x1_ASAP7_75t_R   g080(.A(p35), .B(p31), .Y(new_n171_));
  AND5x1_ASAP7_75t_R   g081(.A(new_n167_), .B(new_n168_), .C(new_n169_), .D(new_n170_), .E(new_n171_), .Y(new_n172_));
  NAND3x1_ASAP7_75t_R  g082(.A(new_n155_), .B(new_n165_), .C(new_n172_), .Y(new_n173_));
  NOR2x1_ASAP7_75t_R   g083(.A(p59), .B(p29), .Y(new_n174_));
  NOR2x1_ASAP7_75t_R   g084(.A(p42), .B(p41), .Y(new_n175_));
  NAND2x1_ASAP7_75t_R  g085(.A(p44), .B(p43), .Y(new_n176_));
  AO21x1_ASAP7_75t_R   g086(.A1(new_n175_), .A2(new_n166_), .B(new_n176_), .Y(new_n177_));
  INVx1_ASAP7_75t_R    g087(.A(p47), .Y(new_n178_));
  NOR2x1_ASAP7_75t_R   g088(.A(p45), .B(new_n178_), .Y(new_n179_));
  NAND2x1_ASAP7_75t_R  g089(.A(p46), .B(p45), .Y(new_n180_));
  INVx1_ASAP7_75t_R    g090(.A(new_n180_), .Y(new_n181_));
  INVx1_ASAP7_75t_R    g091(.A(p46), .Y(new_n182_));
  AOI211x1_ASAP7_75t_R g092(.A1(new_n175_), .A2(new_n166_), .B(new_n182_), .C(new_n176_), .Y(new_n183_));
  AO211x2_ASAP7_75t_R  g093(.A1(new_n177_), .A2(new_n179_), .B(new_n181_), .C(new_n183_), .Y(new_n184_));
  NAND2x1_ASAP7_75t_R  g094(.A(new_n174_), .B(new_n184_), .Y(new_n185_));
  INVx1_ASAP7_75t_R    g095(.A(p50), .Y(new_n186_));
  AND3x1_ASAP7_75t_R   g096(.A(new_n149_), .B(new_n162_), .C(new_n186_), .Y(new_n187_));
  AO21x1_ASAP7_75t_R   g097(.A1(p46), .A2(p45), .B(p47), .Y(new_n188_));
  OAI21x1_ASAP7_75t_R  g098(.A1(new_n188_), .A2(new_n183_), .B(new_n168_), .Y(new_n189_));
  AND3x1_ASAP7_75t_R   g099(.A(p57), .B(p58), .C(p56), .Y(new_n190_));
  AO21x1_ASAP7_75t_R   g100(.A1(p52), .A2(new_n169_), .B(p55), .Y(new_n191_));
  NAND2x1_ASAP7_75t_R  g101(.A(new_n190_), .B(new_n191_), .Y(new_n192_));
  AOI21x1_ASAP7_75t_R  g102(.A1(new_n187_), .A2(new_n189_), .B(new_n192_), .Y(new_n193_));
  OAI21x1_ASAP7_75t_R  g103(.A1(new_n173_), .A2(new_n185_), .B(new_n193_), .Y(new_n194_));
  NOR2x1_ASAP7_75t_R   g104(.A(p59), .B(p50), .Y(new_n195_));
  NAND2x1_ASAP7_75t_R  g105(.A(p52), .B(new_n162_), .Y(new_n196_));
  NOR2x1_ASAP7_75t_R   g106(.A(p45), .B(new_n153_), .Y(new_n197_));
  AND3x1_ASAP7_75t_R   g107(.A(p29), .B(p34), .C(p36), .Y(new_n198_));
  AND2x2_ASAP7_75t_R   g108(.A(p32), .B(p33), .Y(new_n199_));
  AND4x2_ASAP7_75t_R   g109(.A(new_n197_), .B(new_n190_), .C(new_n198_), .D(new_n199_), .Y(new_n200_));
  NAND2x1_ASAP7_75t_R  g110(.A(p42), .B(p41), .Y(new_n201_));
  INVx1_ASAP7_75t_R    g111(.A(p43), .Y(new_n202_));
  OAI21x1_ASAP7_75t_R  g112(.A1(new_n201_), .A2(new_n166_), .B(new_n202_), .Y(new_n203_));
  AO21x1_ASAP7_75t_R   g113(.A1(new_n175_), .A2(new_n166_), .B(new_n202_), .Y(new_n204_));
  NAND3x1_ASAP7_75t_R  g114(.A(new_n200_), .B(new_n203_), .C(new_n204_), .Y(new_n205_));
  INVx1_ASAP7_75t_R    g115(.A(p48), .Y(new_n206_));
  NAND2x1_ASAP7_75t_R  g116(.A(new_n178_), .B(new_n206_), .Y(new_n207_));
  AND2x2_ASAP7_75t_R   g117(.A(p35), .B(p31), .Y(new_n208_));
  AND4x2_ASAP7_75t_R   g118(.A(new_n207_), .B(new_n156_), .C(new_n169_), .D(new_n208_), .Y(new_n209_));
  OAI21x1_ASAP7_75t_R  g119(.A1(p48), .A2(new_n180_), .B(new_n188_), .Y(new_n210_));
  AND5x1_ASAP7_75t_R   g120(.A(new_n149_), .B(new_n154_), .C(p30), .D(p49), .E(p46), .Y(new_n211_));
  NAND3x1_ASAP7_75t_R  g121(.A(new_n209_), .B(new_n210_), .C(new_n211_), .Y(new_n212_));
  AOI211x1_ASAP7_75t_R g122(.A1(new_n189_), .A2(new_n196_), .B(new_n205_), .C(new_n212_), .Y(new_n213_));
  OAI21x1_ASAP7_75t_R  g123(.A1(new_n193_), .A2(new_n195_), .B(new_n213_), .Y(new_n214_));
  AO31x2_ASAP7_75t_R   g124(.A1(new_n146_), .A2(new_n194_), .A3(new_n214_), .B(new_n143_), .Y(o1));
  AND2x2_ASAP7_75t_R   g125(.A(p59), .B(p29), .Y(new_n216_));
  AND3x1_ASAP7_75t_R   g126(.A(new_n168_), .B(p53), .C(p54), .Y(new_n217_));
  AND5x1_ASAP7_75t_R   g127(.A(p40), .B(new_n170_), .C(p52), .D(p44), .E(new_n162_), .Y(new_n218_));
  AND3x1_ASAP7_75t_R   g128(.A(new_n171_), .B(new_n149_), .C(new_n161_), .Y(new_n219_));
  AND5x1_ASAP7_75t_R   g129(.A(new_n167_), .B(new_n217_), .C(new_n218_), .D(new_n159_), .E(new_n219_), .Y(new_n220_));
  AND3x1_ASAP7_75t_R   g130(.A(new_n151_), .B(p38), .C(new_n163_), .Y(new_n221_));
  AND3x1_ASAP7_75t_R   g131(.A(new_n160_), .B(new_n186_), .C(p56), .Y(new_n222_));
  NOR2x1_ASAP7_75t_R   g132(.A(p45), .B(new_n202_), .Y(new_n223_));
  AND5x1_ASAP7_75t_R   g133(.A(new_n147_), .B(new_n221_), .C(new_n222_), .D(new_n153_), .E(new_n223_), .Y(new_n224_));
  NAND3x1_ASAP7_75t_R  g134(.A(new_n220_), .B(new_n184_), .C(new_n224_), .Y(new_n225_));
  OAI21x1_ASAP7_75t_R  g135(.A1(new_n216_), .A2(new_n225_), .B(new_n193_), .Y(new_n226_));
  AOI211x1_ASAP7_75t_R g136(.A1(new_n124_), .A2(new_n108_), .B(new_n143_), .C(new_n226_), .Y(o2));
  assign               o3 = 1'b0;
  assign               o4 = 1'b0;
  assign               o5 = 1'b0;
  assign               o6 = 1'b0;
  assign               o7 = 1'b0;
  assign               o8 = 1'b0;
  assign               o9 = 1'b0;
  assign               o10 = 1'b0;
  assign               o11 = 1'b0;
  assign               o12 = 1'b0;
  assign               o13 = 1'b0;
  assign               o14 = 1'b0;
  assign               o15 = 1'b0;
  assign               o16 = 1'b0;
  assign               o17 = 1'b0;
  assign               o18 = 1'b0;
  assign               o19 = 1'b0;
  assign               o20 = 1'b0;
  assign               o21 = 1'b0;
  assign               o22 = 1'b0;
  assign               o23 = 1'b0;
  assign               o24 = 1'b0;
  assign               o25 = 1'b0;
  assign               o26 = 1'b0;
  assign               o27 = 1'b0;
  assign               o28 = 1'b0;
  assign               o29 = 1'b0;
endmodule


