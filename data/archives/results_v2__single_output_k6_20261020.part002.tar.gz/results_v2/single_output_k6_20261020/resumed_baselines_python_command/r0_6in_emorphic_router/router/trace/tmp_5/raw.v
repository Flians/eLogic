// Benchmark "/tmp/" written by ABC on Tue Oct 20 18:11:44 2026

module \/tmp/  ( 
    p31, p40, p53, p1, p51, p34, p14, p4, p42, p59, p54, p3, p52, p11, p28,
    p32, p46, p58, p35, p5, p38, p55, p16, p0, p47, p30, p6, p37, p50, p12,
    p36, p33, p23, p48, p41, p39, p19, p13, p27, p25, p18, p57, p10, p7,
    p21, p20, p29, p26, p49, p43, p56, p24, p2, p15, p8, p22, p44, p45, p9,
    p17,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25, o26, o27, o28, o29  );
  input  p31, p40, p53, p1, p51, p34, p14, p4, p42, p59, p54, p3, p52,
    p11, p28, p32, p46, p58, p35, p5, p38, p55, p16, p0, p47, p30, p6, p37,
    p50, p12, p36, p33, p23, p48, p41, p39, p19, p13, p27, p25, p18, p57,
    p10, p7, p21, p20, p29, p26, p49, p43, p56, p24, p2, p15, p8, p22, p44,
    p45, p9, p17;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25, o26, o27, o28, o29;
  wire new_n91_, new_n92_, new_n93_, new_n94_, new_n95_, new_n96_, new_n97_,
    new_n98_, new_n99_, new_n100_, new_n101_, new_n102_, new_n103_,
    new_n104_, new_n105_, new_n106_, new_n107_, new_n108_, new_n109_,
    new_n110_, new_n111_, new_n112_, new_n113_, new_n114_, new_n115_,
    new_n116_, new_n117_, new_n118_, new_n119_, new_n120_, new_n121_,
    new_n122_, new_n123_, new_n124_, new_n125_, new_n126_, new_n127_,
    new_n128_, new_n129_, new_n130_, new_n131_, new_n132_, new_n133_,
    new_n134_, new_n135_, new_n136_, new_n137_, new_n138_, new_n139_,
    new_n140_, new_n142_, new_n143_, new_n144_, new_n145_, new_n146_,
    new_n147_, new_n148_, new_n149_, new_n150_, new_n151_, new_n152_,
    new_n153_, new_n154_, new_n155_, new_n156_, new_n157_, new_n158_,
    new_n159_, new_n160_, new_n161_, new_n162_, new_n163_, new_n164_,
    new_n165_, new_n166_, new_n167_, new_n168_, new_n169_, new_n170_,
    new_n171_, new_n172_, new_n173_, new_n174_, new_n175_, new_n176_,
    new_n177_, new_n178_, new_n179_, new_n180_, new_n181_, new_n182_,
    new_n183_, new_n184_, new_n185_, new_n186_, new_n187_, new_n188_,
    new_n189_, new_n190_, new_n191_, new_n192_, new_n193_, new_n194_,
    new_n195_, new_n196_, new_n197_, new_n198_, new_n199_, new_n200_,
    new_n201_, new_n202_, new_n204_, new_n205_, new_n206_, new_n207_,
    new_n208_, new_n209_, new_n210_, new_n211_, new_n212_, new_n213_,
    new_n214_, new_n215_, new_n216_, new_n217_, new_n218_;
  NOR2x1_ASAP7_75t_R   g000(.A(p21), .B(p20), .Y(new_n91_));
  NOR2x1_ASAP7_75t_R   g001(.A(p11), .B(p12), .Y(new_n92_));
  OAI21x1_ASAP7_75t_R  g002(.A1(p8), .A2(p9), .B(p10), .Y(new_n93_));
  NAND2x1_ASAP7_75t_R  g003(.A(p14), .B(p13), .Y(new_n94_));
  AOI21x1_ASAP7_75t_R  g004(.A1(new_n92_), .A2(new_n93_), .B(new_n94_), .Y(new_n95_));
  AO21x1_ASAP7_75t_R   g005(.A1(p16), .A2(p15), .B(p17), .Y(new_n96_));
  AOI21x1_ASAP7_75t_R  g006(.A1(p16), .A2(new_n95_), .B(new_n96_), .Y(new_n97_));
  AND2x2_ASAP7_75t_R   g007(.A(p23), .B(p24), .Y(new_n98_));
  INVx1_ASAP7_75t_R    g008(.A(new_n98_), .Y(new_n99_));
  NAND2x1_ASAP7_75t_R  g009(.A(p19), .B(p18), .Y(new_n100_));
  INVx1_ASAP7_75t_R    g010(.A(p22), .Y(new_n101_));
  AO21x1_ASAP7_75t_R   g011(.A1(new_n100_), .A2(new_n91_), .B(new_n101_), .Y(new_n102_));
  AOI211x1_ASAP7_75t_R g012(.A1(new_n91_), .A2(new_n97_), .B(new_n99_), .C(new_n102_), .Y(new_n103_));
  AND3x1_ASAP7_75t_R   g013(.A(p28), .B(p27), .C(p26), .Y(new_n104_));
  OAI21x1_ASAP7_75t_R  g014(.A1(p25), .A2(new_n103_), .B(new_n104_), .Y(new_n105_));
  OA21x2_ASAP7_75t_R   g015(.A1(p15), .A2(new_n95_), .B(p16), .Y(new_n106_));
  AND3x1_ASAP7_75t_R   g016(.A(new_n91_), .B(p19), .C(p22), .Y(new_n107_));
  INVx1_ASAP7_75t_R    g017(.A(p18), .Y(new_n108_));
  NOR2x1_ASAP7_75t_R   g018(.A(p25), .B(new_n108_), .Y(new_n109_));
  NOR2x1_ASAP7_75t_R   g019(.A(p1), .B(p4), .Y(new_n110_));
  AND5x1_ASAP7_75t_R   g020(.A(p14), .B(new_n109_), .C(p13), .D(new_n98_), .E(new_n110_), .Y(new_n111_));
  INVx1_ASAP7_75t_R    g021(.A(p15), .Y(new_n112_));
  AO21x1_ASAP7_75t_R   g022(.A1(new_n92_), .A2(new_n93_), .B(new_n112_), .Y(new_n113_));
  NOR2x1_ASAP7_75t_R   g023(.A(p6), .B(p12), .Y(new_n114_));
  NOR2x1_ASAP7_75t_R   g024(.A(p3), .B(p11), .Y(new_n115_));
  NOR2x1_ASAP7_75t_R   g025(.A(p5), .B(p0), .Y(new_n116_));
  INVx1_ASAP7_75t_R    g026(.A(p7), .Y(new_n117_));
  AND5x1_ASAP7_75t_R   g027(.A(p10), .B(new_n114_), .C(new_n115_), .D(new_n116_), .E(new_n117_), .Y(new_n118_));
  NOR2x1_ASAP7_75t_R   g028(.A(p9), .B(p17), .Y(new_n119_));
  INVx1_ASAP7_75t_R    g029(.A(p2), .Y(new_n120_));
  AND3x1_ASAP7_75t_R   g030(.A(new_n119_), .B(new_n120_), .C(p8), .Y(new_n121_));
  AND5x1_ASAP7_75t_R   g031(.A(new_n107_), .B(new_n111_), .C(new_n113_), .D(new_n118_), .E(new_n121_), .Y(new_n122_));
  AND2x2_ASAP7_75t_R   g032(.A(new_n106_), .B(new_n122_), .Y(new_n123_));
  AOI21x1_ASAP7_75t_R  g033(.A1(new_n91_), .A2(new_n97_), .B(new_n102_), .Y(new_n124_));
  AOI21x1_ASAP7_75t_R  g034(.A1(new_n98_), .A2(new_n124_), .B(p25), .Y(new_n125_));
  INVx1_ASAP7_75t_R    g035(.A(new_n104_), .Y(new_n126_));
  NOR2x1_ASAP7_75t_R   g036(.A(p23), .B(new_n124_), .Y(new_n127_));
  AO21x1_ASAP7_75t_R   g037(.A1(p16), .A2(new_n95_), .B(new_n96_), .Y(new_n128_));
  AND3x1_ASAP7_75t_R   g038(.A(new_n92_), .B(p1), .C(p14), .Y(new_n129_));
  NOR2x1_ASAP7_75t_R   g039(.A(p8), .B(p9), .Y(new_n130_));
  NAND3x1_ASAP7_75t_R  g040(.A(new_n129_), .B(new_n130_), .C(new_n109_), .Y(new_n131_));
  NOR3x1_ASAP7_75t_R   g041(.A(new_n95_), .B(p16), .C(p15), .Y(new_n132_));
  AND4x2_ASAP7_75t_R   g042(.A(new_n112_), .B(p7), .C(p24), .D(p2), .Y(new_n133_));
  NAND3x1_ASAP7_75t_R  g043(.A(new_n107_), .B(new_n104_), .C(new_n133_), .Y(new_n134_));
  AND4x2_ASAP7_75t_R   g044(.A(p0), .B(p6), .C(p13), .D(p10), .Y(new_n135_));
  AND2x2_ASAP7_75t_R   g045(.A(p3), .B(p5), .Y(new_n136_));
  AND2x2_ASAP7_75t_R   g046(.A(p4), .B(p59), .Y(new_n137_));
  NAND3x1_ASAP7_75t_R  g047(.A(new_n135_), .B(new_n136_), .C(new_n137_), .Y(new_n138_));
  OR5x1_ASAP7_75t_R    g048(.A(new_n128_), .B(new_n131_), .C(new_n132_), .D(new_n134_), .E(new_n138_), .Y(new_n139_));
  OAI22x1_ASAP7_75t_R  g049(.A1(new_n125_), .A2(new_n126_), .B1(new_n127_), .B2(new_n139_), .Y(new_n140_));
  OAI21x1_ASAP7_75t_R  g050(.A1(new_n105_), .A2(new_n123_), .B(new_n140_), .Y(o0));
  INVx1_ASAP7_75t_R    g051(.A(new_n91_), .Y(new_n142_));
  AO211x2_ASAP7_75t_R  g052(.A1(new_n95_), .A2(p16), .B(new_n142_), .C(new_n96_), .Y(new_n143_));
  INVx1_ASAP7_75t_R    g053(.A(new_n102_), .Y(new_n144_));
  NAND3x1_ASAP7_75t_R  g054(.A(new_n143_), .B(new_n98_), .C(new_n144_), .Y(new_n145_));
  INVx1_ASAP7_75t_R    g055(.A(p25), .Y(new_n146_));
  AOI221x1_ASAP7_75t_R g056(.A1(new_n106_), .A2(new_n122_), .B1(new_n145_), .B2(new_n146_), .C(new_n126_), .Y(new_n147_));
  AND3x1_ASAP7_75t_R   g057(.A(p53), .B(p54), .C(p52), .Y(new_n148_));
  AND3x1_ASAP7_75t_R   g058(.A(p58), .B(p57), .C(p56), .Y(new_n149_));
  OA21x2_ASAP7_75t_R   g059(.A1(p55), .A2(new_n148_), .B(new_n149_), .Y(new_n150_));
  NAND2x1_ASAP7_75t_R  g060(.A(p48), .B(p49), .Y(new_n151_));
  AND3x1_ASAP7_75t_R   g061(.A(p46), .B(p43), .C(p44), .Y(new_n152_));
  NOR2x1_ASAP7_75t_R   g062(.A(p42), .B(p41), .Y(new_n153_));
  OAI21x1_ASAP7_75t_R  g063(.A1(p38), .A2(p39), .B(p40), .Y(new_n154_));
  NAND2x1_ASAP7_75t_R  g064(.A(new_n153_), .B(new_n154_), .Y(new_n155_));
  AO21x1_ASAP7_75t_R   g065(.A1(p46), .A2(p45), .B(p47), .Y(new_n156_));
  AOI21x1_ASAP7_75t_R  g066(.A1(new_n152_), .A2(new_n155_), .B(new_n156_), .Y(new_n157_));
  NOR3x1_ASAP7_75t_R   g067(.A(p51), .B(p55), .C(p50), .Y(new_n158_));
  OAI21x1_ASAP7_75t_R  g068(.A1(new_n151_), .A2(new_n157_), .B(new_n158_), .Y(new_n159_));
  NOR2x1_ASAP7_75t_R   g069(.A(p59), .B(p50), .Y(new_n160_));
  AOI21x1_ASAP7_75t_R  g070(.A1(new_n150_), .A2(new_n159_), .B(new_n160_), .Y(new_n161_));
  INVx1_ASAP7_75t_R    g071(.A(p52), .Y(new_n162_));
  NOR2x1_ASAP7_75t_R   g072(.A(p51), .B(new_n162_), .Y(new_n163_));
  INVx1_ASAP7_75t_R    g073(.A(p46), .Y(new_n164_));
  NAND2x1_ASAP7_75t_R  g074(.A(p43), .B(p44), .Y(new_n165_));
  AOI211x1_ASAP7_75t_R g075(.A1(new_n153_), .A2(new_n154_), .B(new_n164_), .C(new_n165_), .Y(new_n166_));
  OAI21x1_ASAP7_75t_R  g076(.A1(p51), .A2(new_n162_), .B(new_n151_), .Y(new_n167_));
  OA31x2_ASAP7_75t_R   g077(.A1(new_n156_), .A2(new_n163_), .A3(new_n166_), .B1(new_n167_), .Y(new_n168_));
  INVx1_ASAP7_75t_R    g078(.A(p41), .Y(new_n169_));
  INVx1_ASAP7_75t_R    g079(.A(p49), .Y(new_n170_));
  NOR2x1_ASAP7_75t_R   g080(.A(p45), .B(new_n170_), .Y(new_n171_));
  AND4x2_ASAP7_75t_R   g081(.A(p30), .B(p37), .C(p36), .D(p33), .Y(new_n172_));
  AND5x1_ASAP7_75t_R   g082(.A(new_n169_), .B(new_n171_), .C(new_n172_), .D(p29), .E(new_n149_), .Y(new_n173_));
  NAND2x1_ASAP7_75t_R  g083(.A(p46), .B(p45), .Y(new_n174_));
  OAI21x1_ASAP7_75t_R  g084(.A1(p48), .A2(new_n174_), .B(new_n156_), .Y(new_n175_));
  NOR2x1_ASAP7_75t_R   g085(.A(p38), .B(p39), .Y(new_n176_));
  AND3x1_ASAP7_75t_R   g086(.A(new_n176_), .B(p53), .C(p54), .Y(new_n177_));
  INVx1_ASAP7_75t_R    g087(.A(p55), .Y(new_n178_));
  AND4x2_ASAP7_75t_R   g088(.A(new_n178_), .B(p32), .C(p46), .D(p35), .Y(new_n179_));
  INVx1_ASAP7_75t_R    g089(.A(p42), .Y(new_n180_));
  AND4x2_ASAP7_75t_R   g090(.A(new_n180_), .B(p31), .C(p40), .D(p34), .Y(new_n181_));
  OA211x2_ASAP7_75t_R  g091(.A1(p47), .A2(p48), .B(p43), .C(p44), .Y(new_n182_));
  AND5x1_ASAP7_75t_R   g092(.A(new_n175_), .B(new_n177_), .C(new_n179_), .D(new_n181_), .E(new_n182_), .Y(new_n183_));
  NAND3x1_ASAP7_75t_R  g093(.A(new_n168_), .B(new_n173_), .C(new_n183_), .Y(new_n184_));
  NAND2x1_ASAP7_75t_R  g094(.A(new_n150_), .B(new_n159_), .Y(new_n185_));
  INVx1_ASAP7_75t_R    g095(.A(p56), .Y(new_n186_));
  OR4x2_ASAP7_75t_R    g096(.A(new_n186_), .B(p33), .C(p39), .D(p45), .Y(new_n187_));
  INVx1_ASAP7_75t_R    g097(.A(p38), .Y(new_n188_));
  OR4x2_ASAP7_75t_R    g098(.A(new_n188_), .B(p35), .C(p55), .D(p47), .Y(new_n189_));
  OR4x2_ASAP7_75t_R    g099(.A(p30), .B(p37), .C(p50), .D(p36), .Y(new_n190_));
  NOR3x1_ASAP7_75t_R   g100(.A(new_n187_), .B(new_n189_), .C(new_n190_), .Y(new_n191_));
  NOR2x1_ASAP7_75t_R   g101(.A(p59), .B(p29), .Y(new_n192_));
  XOR2x2_ASAP7_75t_R   g102(.A(new_n154_), .B(new_n169_), .Y(new_n193_));
  NOR2x1_ASAP7_75t_R   g103(.A(new_n151_), .B(new_n165_), .Y(new_n194_));
  AND2x2_ASAP7_75t_R   g104(.A(new_n163_), .B(new_n194_), .Y(new_n195_));
  INVx1_ASAP7_75t_R    g105(.A(p31), .Y(new_n196_));
  NOR2x1_ASAP7_75t_R   g106(.A(p32), .B(new_n164_), .Y(new_n197_));
  AND2x2_ASAP7_75t_R   g107(.A(p53), .B(p54), .Y(new_n198_));
  NOR2x1_ASAP7_75t_R   g108(.A(p34), .B(p42), .Y(new_n199_));
  AND5x1_ASAP7_75t_R   g109(.A(new_n196_), .B(new_n197_), .C(p40), .D(new_n198_), .E(new_n199_), .Y(new_n200_));
  AND5x1_ASAP7_75t_R   g110(.A(new_n191_), .B(new_n192_), .C(new_n193_), .D(new_n195_), .E(new_n200_), .Y(new_n201_));
  OAI22x1_ASAP7_75t_R  g111(.A1(new_n161_), .A2(new_n184_), .B1(new_n185_), .B2(new_n201_), .Y(new_n202_));
  OAI21x1_ASAP7_75t_R  g112(.A1(new_n147_), .A2(new_n202_), .B(new_n140_), .Y(o1));
  OR3x1_ASAP7_75t_R    g113(.A(new_n95_), .B(p16), .C(p15), .Y(new_n204_));
  AND2x2_ASAP7_75t_R   g114(.A(new_n104_), .B(new_n133_), .Y(new_n205_));
  AND5x1_ASAP7_75t_R   g115(.A(p1), .B(new_n109_), .C(p14), .D(new_n92_), .E(new_n130_), .Y(new_n206_));
  AND3x1_ASAP7_75t_R   g116(.A(new_n135_), .B(new_n136_), .C(new_n137_), .Y(new_n207_));
  AND5x1_ASAP7_75t_R   g117(.A(new_n204_), .B(new_n107_), .C(new_n205_), .D(new_n206_), .E(new_n207_), .Y(new_n208_));
  AND3x1_ASAP7_75t_R   g118(.A(p19), .B(p18), .C(p22), .Y(new_n209_));
  AO21x1_ASAP7_75t_R   g119(.A1(p22), .A2(new_n142_), .B(p23), .Y(new_n210_));
  AO21x1_ASAP7_75t_R   g120(.A1(new_n209_), .A2(new_n128_), .B(new_n210_), .Y(new_n211_));
  NAND3x1_ASAP7_75t_R  g121(.A(new_n208_), .B(new_n97_), .C(new_n211_), .Y(new_n212_));
  AND2x2_ASAP7_75t_R   g122(.A(p59), .B(p29), .Y(new_n213_));
  AND3x1_ASAP7_75t_R   g123(.A(new_n198_), .B(new_n196_), .C(p40), .Y(new_n214_));
  AND5x1_ASAP7_75t_R   g124(.A(new_n163_), .B(new_n214_), .C(new_n194_), .D(new_n199_), .E(new_n197_), .Y(new_n215_));
  NAND3x1_ASAP7_75t_R  g125(.A(new_n215_), .B(new_n191_), .C(new_n193_), .Y(new_n216_));
  AND2x2_ASAP7_75t_R   g126(.A(new_n150_), .B(new_n159_), .Y(new_n217_));
  OAI21x1_ASAP7_75t_R  g127(.A1(new_n213_), .A2(new_n216_), .B(new_n217_), .Y(new_n218_));
  AOI211x1_ASAP7_75t_R g128(.A1(new_n105_), .A2(new_n212_), .B(new_n218_), .C(new_n147_), .Y(o2));
  assign               o3 = 1'b0;
  assign               o4 = 1'b0;
  assign               o5 = 1'b0;
  assign               o6 = 1'b0;
  assign               o7 = 1'b0;
  assign               o8 = 1'b0;
  assign               o9 = 1'b0;
  assign               o10 = 1'b0;
  assign               o11 = 1'b0;
  assign               o12 = 1'b0;
  assign               o13 = 1'b0;
  assign               o14 = 1'b0;
  assign               o15 = 1'b0;
  assign               o16 = 1'b0;
  assign               o17 = 1'b0;
  assign               o18 = 1'b0;
  assign               o19 = 1'b0;
  assign               o20 = 1'b0;
  assign               o21 = 1'b0;
  assign               o22 = 1'b0;
  assign               o23 = 1'b0;
  assign               o24 = 1'b0;
  assign               o25 = 1'b0;
  assign               o26 = 1'b0;
  assign               o27 = 1'b0;
  assign               o28 = 1'b0;
  assign               o29 = 1'b0;
endmodule


