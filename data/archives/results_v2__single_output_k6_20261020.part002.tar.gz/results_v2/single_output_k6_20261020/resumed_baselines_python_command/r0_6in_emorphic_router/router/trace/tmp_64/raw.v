// Benchmark "/tmp/" written by ABC on Tue Oct 20 18:11:52 2026

module \/tmp/  ( 
    p36, p52, p41, p40, p54, p24, p26, p39, p1, p43, p56, p37, p32, p8,
    p59, p27, p38, p49, p11, p51, p45, p3, p16, p58, p12, p47, p29, p13,
    p20, p17, p22, p50, p15, p4, p23, p35, p34, p10, p2, p7, p14, p33, p48,
    p44, p46, p55, p31, p18, p6, p28, p30, p57, p0, p42, p5, p25, p53, p19,
    p9, p21,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25, o26, o27, o28, o29  );
  input  p36, p52, p41, p40, p54, p24, p26, p39, p1, p43, p56, p37, p32,
    p8, p59, p27, p38, p49, p11, p51, p45, p3, p16, p58, p12, p47, p29,
    p13, p20, p17, p22, p50, p15, p4, p23, p35, p34, p10, p2, p7, p14, p33,
    p48, p44, p46, p55, p31, p18, p6, p28, p30, p57, p0, p42, p5, p25, p53,
    p19, p9, p21;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25, o26, o27, o28, o29;
  wire new_n91_, new_n92_, new_n93_, new_n94_, new_n95_, new_n96_, new_n97_,
    new_n98_, new_n99_, new_n100_, new_n101_, new_n102_, new_n103_,
    new_n104_, new_n105_, new_n106_, new_n107_, new_n108_, new_n109_,
    new_n110_, new_n111_, new_n112_, new_n113_, new_n114_, new_n115_,
    new_n116_, new_n117_, new_n118_, new_n119_, new_n120_, new_n121_,
    new_n122_, new_n123_, new_n124_, new_n125_, new_n126_, new_n127_,
    new_n128_, new_n129_, new_n130_, new_n131_, new_n132_, new_n133_,
    new_n134_, new_n135_, new_n136_, new_n137_, new_n138_, new_n139_,
    new_n140_, new_n142_, new_n143_, new_n144_, new_n145_, new_n146_,
    new_n147_, new_n148_, new_n149_, new_n150_, new_n151_, new_n152_,
    new_n153_, new_n154_, new_n155_, new_n156_, new_n157_, new_n158_,
    new_n159_, new_n160_, new_n161_, new_n162_, new_n163_, new_n164_,
    new_n165_, new_n166_, new_n167_, new_n168_, new_n169_, new_n170_,
    new_n171_, new_n172_, new_n173_, new_n174_, new_n175_, new_n176_,
    new_n177_, new_n178_, new_n179_, new_n180_, new_n181_, new_n182_,
    new_n183_, new_n184_, new_n185_, new_n186_, new_n187_, new_n188_,
    new_n189_, new_n190_, new_n191_, new_n192_, new_n193_, new_n194_,
    new_n195_, new_n196_, new_n197_, new_n198_, new_n199_, new_n200_,
    new_n201_, new_n202_, new_n203_, new_n204_, new_n205_, new_n206_,
    new_n207_, new_n208_, new_n209_, new_n210_, new_n211_, new_n213_,
    new_n214_, new_n215_, new_n216_, new_n217_, new_n218_, new_n219_,
    new_n220_, new_n221_, new_n222_, new_n223_, new_n224_, new_n225_,
    new_n226_, new_n227_, new_n228_, new_n229_, new_n230_, new_n231_,
    new_n232_, new_n233_, new_n234_, new_n235_;
  NOR2x1_ASAP7_75t_R   g000(.A(p20), .B(p21), .Y(new_n91_));
  NOR2x1_ASAP7_75t_R   g001(.A(p11), .B(p12), .Y(new_n92_));
  OAI21x1_ASAP7_75t_R  g002(.A1(p8), .A2(p9), .B(p10), .Y(new_n93_));
  NAND2x1_ASAP7_75t_R  g003(.A(p13), .B(p14), .Y(new_n94_));
  AOI21x1_ASAP7_75t_R  g004(.A1(new_n92_), .A2(new_n93_), .B(new_n94_), .Y(new_n95_));
  AO21x1_ASAP7_75t_R   g005(.A1(p16), .A2(p15), .B(p17), .Y(new_n96_));
  AOI21x1_ASAP7_75t_R  g006(.A1(p16), .A2(new_n95_), .B(new_n96_), .Y(new_n97_));
  NAND2x1_ASAP7_75t_R  g007(.A(p18), .B(p19), .Y(new_n98_));
  INVx1_ASAP7_75t_R    g008(.A(p22), .Y(new_n99_));
  AO21x1_ASAP7_75t_R   g009(.A1(new_n98_), .A2(new_n91_), .B(new_n99_), .Y(new_n100_));
  AOI21x1_ASAP7_75t_R  g010(.A1(new_n91_), .A2(new_n97_), .B(new_n100_), .Y(new_n101_));
  AND3x1_ASAP7_75t_R   g011(.A(p26), .B(p27), .C(p28), .Y(new_n102_));
  NAND2x1_ASAP7_75t_R  g012(.A(p24), .B(p23), .Y(new_n103_));
  INVx1_ASAP7_75t_R    g013(.A(new_n103_), .Y(new_n104_));
  NAND3x1_ASAP7_75t_R  g014(.A(new_n101_), .B(new_n102_), .C(new_n104_), .Y(new_n105_));
  AND2x2_ASAP7_75t_R   g015(.A(p25), .B(new_n102_), .Y(new_n106_));
  INVx1_ASAP7_75t_R    g016(.A(new_n106_), .Y(new_n107_));
  AND2x2_ASAP7_75t_R   g017(.A(p4), .B(p10), .Y(new_n108_));
  AND2x2_ASAP7_75t_R   g018(.A(p16), .B(p13), .Y(new_n109_));
  NOR2x1_ASAP7_75t_R   g019(.A(p17), .B(p15), .Y(new_n110_));
  AND5x1_ASAP7_75t_R   g020(.A(p59), .B(new_n108_), .C(new_n109_), .D(p3), .E(new_n110_), .Y(new_n111_));
  AND2x2_ASAP7_75t_R   g021(.A(p22), .B(p19), .Y(new_n112_));
  INVx1_ASAP7_75t_R    g022(.A(p25), .Y(new_n113_));
  AND3x1_ASAP7_75t_R   g023(.A(new_n112_), .B(new_n113_), .C(new_n91_), .Y(new_n114_));
  INVx1_ASAP7_75t_R    g024(.A(p8), .Y(new_n115_));
  INVx1_ASAP7_75t_R    g025(.A(p9), .Y(new_n116_));
  AND5x1_ASAP7_75t_R   g026(.A(p24), .B(new_n92_), .C(p1), .D(new_n115_), .E(new_n116_), .Y(new_n117_));
  AND3x1_ASAP7_75t_R   g027(.A(new_n111_), .B(new_n114_), .C(new_n117_), .Y(new_n118_));
  AND3x1_ASAP7_75t_R   g028(.A(p6), .B(p0), .C(p5), .Y(new_n119_));
  AND5x1_ASAP7_75t_R   g029(.A(p2), .B(new_n119_), .C(p7), .D(p14), .E(p18), .Y(new_n120_));
  AND2x2_ASAP7_75t_R   g030(.A(new_n102_), .B(new_n120_), .Y(new_n121_));
  INVx1_ASAP7_75t_R    g031(.A(p23), .Y(new_n122_));
  OAI21x1_ASAP7_75t_R  g032(.A1(new_n99_), .A2(new_n91_), .B(new_n122_), .Y(new_n123_));
  NAND3x1_ASAP7_75t_R  g033(.A(new_n118_), .B(new_n121_), .C(new_n123_), .Y(new_n124_));
  NAND3x1_ASAP7_75t_R  g034(.A(new_n105_), .B(new_n107_), .C(new_n124_), .Y(new_n125_));
  OA21x2_ASAP7_75t_R   g035(.A1(p15), .A2(new_n95_), .B(p16), .Y(new_n126_));
  INVx1_ASAP7_75t_R    g036(.A(p1), .Y(new_n127_));
  AND3x1_ASAP7_75t_R   g037(.A(new_n92_), .B(new_n127_), .C(p8), .Y(new_n128_));
  NOR2x1_ASAP7_75t_R   g038(.A(new_n103_), .B(new_n94_), .Y(new_n129_));
  AND3x1_ASAP7_75t_R   g039(.A(new_n114_), .B(new_n128_), .C(new_n129_), .Y(new_n130_));
  INVx1_ASAP7_75t_R    g040(.A(p15), .Y(new_n131_));
  AO21x1_ASAP7_75t_R   g041(.A1(new_n92_), .A2(new_n93_), .B(new_n131_), .Y(new_n132_));
  NOR3x1_ASAP7_75t_R   g042(.A(p0), .B(p5), .C(p9), .Y(new_n133_));
  INVx1_ASAP7_75t_R    g043(.A(p18), .Y(new_n134_));
  OR4x2_ASAP7_75t_R    g044(.A(new_n134_), .B(p2), .C(p7), .D(p6), .Y(new_n135_));
  INVx1_ASAP7_75t_R    g045(.A(p10), .Y(new_n136_));
  OR4x2_ASAP7_75t_R    g046(.A(new_n136_), .B(p3), .C(p17), .D(p4), .Y(new_n137_));
  NOR2x1_ASAP7_75t_R   g047(.A(new_n135_), .B(new_n137_), .Y(new_n138_));
  AND5x1_ASAP7_75t_R   g048(.A(new_n126_), .B(new_n130_), .C(new_n132_), .D(new_n133_), .E(new_n138_), .Y(new_n139_));
  AO21x1_ASAP7_75t_R   g049(.A1(new_n107_), .A2(new_n105_), .B(new_n139_), .Y(new_n140_));
  NAND2x1_ASAP7_75t_R  g050(.A(new_n125_), .B(new_n140_), .Y(o0));
  NAND2x1_ASAP7_75t_R  g051(.A(p49), .B(p48), .Y(new_n142_));
  NAND2x1_ASAP7_75t_R  g052(.A(p44), .B(p46), .Y(new_n143_));
  INVx1_ASAP7_75t_R    g053(.A(new_n143_), .Y(new_n144_));
  NOR2x1_ASAP7_75t_R   g054(.A(p41), .B(p42), .Y(new_n145_));
  OAI21x1_ASAP7_75t_R  g055(.A1(p39), .A2(p38), .B(p40), .Y(new_n146_));
  INVx1_ASAP7_75t_R    g056(.A(p43), .Y(new_n147_));
  AOI21x1_ASAP7_75t_R  g057(.A1(new_n145_), .A2(new_n146_), .B(new_n147_), .Y(new_n148_));
  AO21x1_ASAP7_75t_R   g058(.A1(p45), .A2(p46), .B(p47), .Y(new_n149_));
  AOI21x1_ASAP7_75t_R  g059(.A1(new_n144_), .A2(new_n148_), .B(new_n149_), .Y(new_n150_));
  INVx1_ASAP7_75t_R    g060(.A(p51), .Y(new_n151_));
  NAND2x1_ASAP7_75t_R  g061(.A(p52), .B(new_n151_), .Y(new_n152_));
  OAI21x1_ASAP7_75t_R  g062(.A1(new_n142_), .A2(new_n150_), .B(new_n152_), .Y(new_n153_));
  NAND3x1_ASAP7_75t_R  g063(.A(p56), .B(p58), .C(p57), .Y(new_n154_));
  NAND2x1_ASAP7_75t_R  g064(.A(p31), .B(p30), .Y(new_n155_));
  NAND2x1_ASAP7_75t_R  g065(.A(p34), .B(p33), .Y(new_n156_));
  OR5x1_ASAP7_75t_R    g066(.A(p55), .B(new_n154_), .C(new_n143_), .D(new_n155_), .E(new_n156_), .Y(new_n157_));
  NOR2x1_ASAP7_75t_R   g067(.A(p47), .B(p48), .Y(new_n158_));
  NAND2x1_ASAP7_75t_R  g068(.A(p54), .B(p53), .Y(new_n159_));
  OR4x2_ASAP7_75t_R    g069(.A(new_n158_), .B(new_n159_), .C(p39), .D(p38), .Y(new_n160_));
  INVx1_ASAP7_75t_R    g070(.A(p36), .Y(new_n161_));
  NAND2x1_ASAP7_75t_R  g071(.A(p49), .B(p35), .Y(new_n162_));
  INVx1_ASAP7_75t_R    g072(.A(p32), .Y(new_n163_));
  INVx1_ASAP7_75t_R    g073(.A(p29), .Y(new_n164_));
  OR5x1_ASAP7_75t_R    g074(.A(new_n161_), .B(new_n162_), .C(new_n163_), .D(p45), .E(new_n164_), .Y(new_n165_));
  NOR3x1_ASAP7_75t_R   g075(.A(new_n157_), .B(new_n160_), .C(new_n165_), .Y(new_n166_));
  AO21x1_ASAP7_75t_R   g076(.A1(new_n145_), .A2(new_n146_), .B(new_n147_), .Y(new_n167_));
  NAND2x1_ASAP7_75t_R  g077(.A(p45), .B(p46), .Y(new_n168_));
  OAI21x1_ASAP7_75t_R  g078(.A1(p48), .A2(new_n168_), .B(new_n149_), .Y(new_n169_));
  NAND2x1_ASAP7_75t_R  g079(.A(p41), .B(p42), .Y(new_n170_));
  OAI21x1_ASAP7_75t_R  g080(.A1(new_n170_), .A2(new_n146_), .B(new_n147_), .Y(new_n171_));
  AND5x1_ASAP7_75t_R   g081(.A(p40), .B(new_n167_), .C(p37), .D(new_n169_), .E(new_n171_), .Y(new_n172_));
  NAND3x1_ASAP7_75t_R  g082(.A(new_n153_), .B(new_n166_), .C(new_n172_), .Y(new_n173_));
  AND3x1_ASAP7_75t_R   g083(.A(p52), .B(p54), .C(p53), .Y(new_n174_));
  AND3x1_ASAP7_75t_R   g084(.A(p56), .B(p58), .C(p57), .Y(new_n175_));
  OA21x2_ASAP7_75t_R   g085(.A1(p55), .A2(new_n174_), .B(new_n175_), .Y(new_n176_));
  NOR2x1_ASAP7_75t_R   g086(.A(p50), .B(p55), .Y(new_n177_));
  AND2x2_ASAP7_75t_R   g087(.A(new_n151_), .B(new_n177_), .Y(new_n178_));
  OAI21x1_ASAP7_75t_R  g088(.A1(new_n142_), .A2(new_n150_), .B(new_n178_), .Y(new_n179_));
  NOR2x1_ASAP7_75t_R   g089(.A(p59), .B(p50), .Y(new_n180_));
  AOI21x1_ASAP7_75t_R  g090(.A1(new_n176_), .A2(new_n179_), .B(new_n180_), .Y(new_n181_));
  NAND2x1_ASAP7_75t_R  g091(.A(p56), .B(p38), .Y(new_n182_));
  NOR3x1_ASAP7_75t_R   g092(.A(new_n182_), .B(p39), .C(p37), .Y(new_n183_));
  AND2x2_ASAP7_75t_R   g093(.A(p40), .B(p44), .Y(new_n184_));
  NOR2x1_ASAP7_75t_R   g094(.A(p45), .B(p42), .Y(new_n185_));
  NOR2x1_ASAP7_75t_R   g095(.A(p36), .B(new_n147_), .Y(new_n186_));
  AND5x1_ASAP7_75t_R   g096(.A(new_n183_), .B(new_n177_), .C(new_n184_), .D(new_n185_), .E(new_n186_), .Y(new_n187_));
  INVx1_ASAP7_75t_R    g097(.A(p41), .Y(new_n188_));
  NOR2x1_ASAP7_75t_R   g098(.A(new_n188_), .B(new_n146_), .Y(new_n189_));
  OR4x2_ASAP7_75t_R    g099(.A(p34), .B(p33), .C(p31), .D(p30), .Y(new_n190_));
  NOR3x1_ASAP7_75t_R   g100(.A(new_n189_), .B(new_n190_), .C(new_n152_), .Y(new_n191_));
  NOR2x1_ASAP7_75t_R   g101(.A(p32), .B(p35), .Y(new_n192_));
  NAND3x1_ASAP7_75t_R  g102(.A(new_n192_), .B(p54), .C(p53), .Y(new_n193_));
  INVx1_ASAP7_75t_R    g103(.A(p47), .Y(new_n194_));
  INVx1_ASAP7_75t_R    g104(.A(p46), .Y(new_n195_));
  AND2x2_ASAP7_75t_R   g105(.A(p49), .B(p48), .Y(new_n196_));
  OAI21x1_ASAP7_75t_R  g106(.A1(new_n194_), .A2(new_n195_), .B(new_n196_), .Y(new_n197_));
  AOI211x1_ASAP7_75t_R g107(.A1(new_n188_), .A2(new_n146_), .B(new_n193_), .C(new_n197_), .Y(new_n198_));
  NAND3x1_ASAP7_75t_R  g108(.A(new_n187_), .B(new_n191_), .C(new_n198_), .Y(new_n199_));
  OR2x4_ASAP7_75t_R    g109(.A(p45), .B(new_n194_), .Y(new_n200_));
  AOI21x1_ASAP7_75t_R  g110(.A1(p44), .A2(new_n148_), .B(new_n200_), .Y(new_n201_));
  OAI21x1_ASAP7_75t_R  g111(.A1(new_n143_), .A2(new_n167_), .B(new_n168_), .Y(new_n202_));
  NOR2x1_ASAP7_75t_R   g112(.A(p59), .B(p29), .Y(new_n203_));
  OAI21x1_ASAP7_75t_R  g113(.A1(new_n201_), .A2(new_n202_), .B(new_n203_), .Y(new_n204_));
  AOI211x1_ASAP7_75t_R g114(.A1(new_n145_), .A2(new_n146_), .B(new_n147_), .C(new_n143_), .Y(new_n205_));
  OAI21x1_ASAP7_75t_R  g115(.A1(new_n149_), .A2(new_n205_), .B(new_n196_), .Y(new_n206_));
  INVx1_ASAP7_75t_R    g116(.A(new_n176_), .Y(new_n207_));
  AOI21x1_ASAP7_75t_R  g117(.A1(new_n178_), .A2(new_n206_), .B(new_n207_), .Y(new_n208_));
  OAI21x1_ASAP7_75t_R  g118(.A1(new_n199_), .A2(new_n204_), .B(new_n208_), .Y(new_n209_));
  OAI21x1_ASAP7_75t_R  g119(.A1(new_n173_), .A2(new_n181_), .B(new_n209_), .Y(new_n210_));
  AOI21x1_ASAP7_75t_R  g120(.A1(new_n107_), .A2(new_n105_), .B(new_n139_), .Y(new_n211_));
  AOI21x1_ASAP7_75t_R  g121(.A1(new_n125_), .A2(new_n210_), .B(new_n211_), .Y(o1));
  AND5x1_ASAP7_75t_R   g122(.A(new_n102_), .B(new_n111_), .C(new_n120_), .D(new_n114_), .E(new_n117_), .Y(new_n213_));
  AOI211x1_ASAP7_75t_R g123(.A1(new_n91_), .A2(new_n97_), .B(new_n103_), .C(new_n100_), .Y(new_n214_));
  AOI221x1_ASAP7_75t_R g124(.A1(new_n123_), .A2(new_n213_), .B1(new_n214_), .B2(new_n102_), .C(new_n106_), .Y(new_n215_));
  AND2x2_ASAP7_75t_R   g125(.A(p59), .B(p29), .Y(new_n216_));
  OA21x2_ASAP7_75t_R   g126(.A1(p45), .A2(new_n148_), .B(new_n195_), .Y(new_n217_));
  INVx1_ASAP7_75t_R    g127(.A(p33), .Y(new_n218_));
  NOR2x1_ASAP7_75t_R   g128(.A(p31), .B(p30), .Y(new_n219_));
  NOR2x1_ASAP7_75t_R   g129(.A(p35), .B(p34), .Y(new_n220_));
  INVx1_ASAP7_75t_R    g130(.A(p42), .Y(new_n221_));
  AND5x1_ASAP7_75t_R   g131(.A(new_n218_), .B(new_n219_), .C(new_n220_), .D(p44), .E(new_n221_), .Y(new_n222_));
  NAND2x1_ASAP7_75t_R  g132(.A(new_n174_), .B(new_n222_), .Y(new_n223_));
  NAND2x1_ASAP7_75t_R  g133(.A(p40), .B(new_n161_), .Y(new_n224_));
  AND2x2_ASAP7_75t_R   g134(.A(p47), .B(p46), .Y(new_n225_));
  OR5x1_ASAP7_75t_R    g135(.A(p50), .B(new_n224_), .C(p55), .D(new_n142_), .E(new_n225_), .Y(new_n226_));
  XOR2x2_ASAP7_75t_R   g136(.A(new_n146_), .B(p41), .Y(new_n227_));
  NOR2x1_ASAP7_75t_R   g137(.A(p51), .B(p45), .Y(new_n228_));
  AND3x1_ASAP7_75t_R   g138(.A(new_n228_), .B(new_n163_), .C(p38), .Y(new_n229_));
  NOR2x1_ASAP7_75t_R   g139(.A(p39), .B(new_n147_), .Y(new_n230_));
  INVx1_ASAP7_75t_R    g140(.A(p56), .Y(new_n231_));
  NOR2x1_ASAP7_75t_R   g141(.A(p37), .B(new_n231_), .Y(new_n232_));
  NAND3x1_ASAP7_75t_R  g142(.A(new_n229_), .B(new_n230_), .C(new_n232_), .Y(new_n233_));
  OR5x1_ASAP7_75t_R    g143(.A(new_n217_), .B(new_n223_), .C(new_n226_), .D(new_n227_), .E(new_n233_), .Y(new_n234_));
  OAI21x1_ASAP7_75t_R  g144(.A1(new_n216_), .A2(new_n234_), .B(new_n208_), .Y(new_n235_));
  NOR3x1_ASAP7_75t_R   g145(.A(new_n211_), .B(new_n215_), .C(new_n235_), .Y(o2));
  assign               o3 = 1'b0;
  assign               o4 = 1'b0;
  assign               o5 = 1'b0;
  assign               o6 = 1'b0;
  assign               o7 = 1'b0;
  assign               o8 = 1'b0;
  assign               o9 = 1'b0;
  assign               o10 = 1'b0;
  assign               o11 = 1'b0;
  assign               o12 = 1'b0;
  assign               o13 = 1'b0;
  assign               o14 = 1'b0;
  assign               o15 = 1'b0;
  assign               o16 = 1'b0;
  assign               o17 = 1'b0;
  assign               o18 = 1'b0;
  assign               o19 = 1'b0;
  assign               o20 = 1'b0;
  assign               o21 = 1'b0;
  assign               o22 = 1'b0;
  assign               o23 = 1'b0;
  assign               o24 = 1'b0;
  assign               o25 = 1'b0;
  assign               o26 = 1'b0;
  assign               o27 = 1'b0;
  assign               o28 = 1'b0;
  assign               o29 = 1'b0;
endmodule


