// Benchmark "/tmp/" written by ABC on Tue Oct 20 18:11:51 2026

module \/tmp/  ( 
    p0, p4, p46, p41, p11, p25, p8, p36, p45, p5, p24, p47, p49, p20, p2,
    p54, p16, p44, p59, p51, p6, p52, p37, p12, p34, p9, p30, p26, p32,
    p56, p19, p55, p27, p33, p53, p14, p1, p57, p3, p29, p40, p58, p28,
    p10, p23, p39, p21, p35, p43, p48, p7, p42, p18, p31, p38, p50, p17,
    p22, p13, p15,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25, o26, o27, o28, o29  );
  input  p0, p4, p46, p41, p11, p25, p8, p36, p45, p5, p24, p47, p49,
    p20, p2, p54, p16, p44, p59, p51, p6, p52, p37, p12, p34, p9, p30, p26,
    p32, p56, p19, p55, p27, p33, p53, p14, p1, p57, p3, p29, p40, p58,
    p28, p10, p23, p39, p21, p35, p43, p48, p7, p42, p18, p31, p38, p50,
    p17, p22, p13, p15;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25, o26, o27, o28, o29;
  wire new_n91_, new_n92_, new_n93_, new_n94_, new_n95_, new_n96_, new_n97_,
    new_n98_, new_n99_, new_n100_, new_n101_, new_n102_, new_n103_,
    new_n104_, new_n105_, new_n106_, new_n107_, new_n108_, new_n109_,
    new_n110_, new_n111_, new_n112_, new_n113_, new_n114_, new_n115_,
    new_n116_, new_n117_, new_n118_, new_n119_, new_n120_, new_n121_,
    new_n122_, new_n123_, new_n124_, new_n125_, new_n126_, new_n127_,
    new_n128_, new_n129_, new_n130_, new_n131_, new_n132_, new_n133_,
    new_n134_, new_n135_, new_n136_, new_n137_, new_n138_, new_n139_,
    new_n140_, new_n141_, new_n142_, new_n144_, new_n145_, new_n146_,
    new_n147_, new_n148_, new_n149_, new_n150_, new_n151_, new_n152_,
    new_n153_, new_n154_, new_n155_, new_n156_, new_n157_, new_n158_,
    new_n159_, new_n160_, new_n161_, new_n162_, new_n163_, new_n164_,
    new_n165_, new_n166_, new_n167_, new_n168_, new_n169_, new_n170_,
    new_n171_, new_n172_, new_n173_, new_n174_, new_n175_, new_n176_,
    new_n177_, new_n178_, new_n179_, new_n180_, new_n181_, new_n182_,
    new_n183_, new_n184_, new_n185_, new_n186_, new_n187_, new_n188_,
    new_n189_, new_n190_, new_n191_, new_n192_, new_n193_, new_n194_,
    new_n195_, new_n196_, new_n197_, new_n198_, new_n199_, new_n200_,
    new_n201_, new_n202_, new_n203_, new_n204_, new_n205_, new_n206_,
    new_n207_, new_n208_, new_n209_, new_n210_, new_n212_, new_n213_,
    new_n214_, new_n215_, new_n216_, new_n217_, new_n218_, new_n219_,
    new_n220_, new_n221_, new_n222_, new_n223_, new_n224_, new_n225_,
    new_n226_, new_n227_, new_n228_, new_n229_, new_n230_, new_n231_,
    new_n232_, new_n233_, new_n234_, new_n235_, new_n236_, new_n237_,
    new_n238_, new_n239_, new_n240_;
  NAND2x1_ASAP7_75t_R  g000(.A(p24), .B(p23), .Y(new_n91_));
  INVx1_ASAP7_75t_R    g001(.A(new_n91_), .Y(new_n92_));
  NOR2x1_ASAP7_75t_R   g002(.A(p20), .B(p21), .Y(new_n93_));
  INVx1_ASAP7_75t_R    g003(.A(new_n93_), .Y(new_n94_));
  AO21x1_ASAP7_75t_R   g004(.A1(p16), .A2(p15), .B(p17), .Y(new_n95_));
  NOR2x1_ASAP7_75t_R   g005(.A(p11), .B(p12), .Y(new_n96_));
  OAI21x1_ASAP7_75t_R  g006(.A1(p8), .A2(p9), .B(p10), .Y(new_n97_));
  INVx1_ASAP7_75t_R    g007(.A(p16), .Y(new_n98_));
  NAND2x1_ASAP7_75t_R  g008(.A(p14), .B(p13), .Y(new_n99_));
  AOI211x1_ASAP7_75t_R g009(.A1(new_n96_), .A2(new_n97_), .B(new_n98_), .C(new_n99_), .Y(new_n100_));
  NAND2x1_ASAP7_75t_R  g010(.A(p19), .B(p18), .Y(new_n101_));
  INVx1_ASAP7_75t_R    g011(.A(p22), .Y(new_n102_));
  AOI21x1_ASAP7_75t_R  g012(.A1(new_n101_), .A2(new_n93_), .B(new_n102_), .Y(new_n103_));
  OA31x2_ASAP7_75t_R   g013(.A1(new_n94_), .A2(new_n95_), .A3(new_n100_), .B1(new_n103_), .Y(new_n104_));
  AOI21x1_ASAP7_75t_R  g014(.A1(new_n92_), .A2(new_n104_), .B(p25), .Y(new_n105_));
  AND3x1_ASAP7_75t_R   g015(.A(p26), .B(p27), .C(p28), .Y(new_n106_));
  INVx1_ASAP7_75t_R    g016(.A(new_n106_), .Y(new_n107_));
  AOI21x1_ASAP7_75t_R  g017(.A1(new_n96_), .A2(new_n97_), .B(new_n99_), .Y(new_n108_));
  AO21x1_ASAP7_75t_R   g018(.A1(p16), .A2(new_n108_), .B(new_n95_), .Y(new_n109_));
  NOR3x1_ASAP7_75t_R   g019(.A(new_n108_), .B(p16), .C(p15), .Y(new_n110_));
  AND3x1_ASAP7_75t_R   g020(.A(new_n93_), .B(p19), .C(p22), .Y(new_n111_));
  INVx1_ASAP7_75t_R    g021(.A(p15), .Y(new_n112_));
  AND4x2_ASAP7_75t_R   g022(.A(new_n112_), .B(p1), .C(p7), .D(p18), .Y(new_n113_));
  NAND3x1_ASAP7_75t_R  g023(.A(new_n111_), .B(new_n106_), .C(new_n113_), .Y(new_n114_));
  INVx1_ASAP7_75t_R    g024(.A(p25), .Y(new_n115_));
  AND4x2_ASAP7_75t_R   g025(.A(new_n115_), .B(p0), .C(p4), .D(p5), .Y(new_n116_));
  INVx1_ASAP7_75t_R    g026(.A(p8), .Y(new_n117_));
  INVx1_ASAP7_75t_R    g027(.A(p9), .Y(new_n118_));
  AND3x1_ASAP7_75t_R   g028(.A(new_n96_), .B(new_n117_), .C(new_n118_), .Y(new_n119_));
  NAND2x1_ASAP7_75t_R  g029(.A(new_n116_), .B(new_n119_), .Y(new_n120_));
  INVx1_ASAP7_75t_R    g030(.A(p3), .Y(new_n121_));
  NAND2x1_ASAP7_75t_R  g031(.A(p24), .B(p2), .Y(new_n122_));
  NAND2x1_ASAP7_75t_R  g032(.A(p59), .B(p6), .Y(new_n123_));
  INVx1_ASAP7_75t_R    g033(.A(p10), .Y(new_n124_));
  OR5x1_ASAP7_75t_R    g034(.A(new_n121_), .B(new_n99_), .C(new_n122_), .D(new_n123_), .E(new_n124_), .Y(new_n125_));
  OR5x1_ASAP7_75t_R    g035(.A(new_n109_), .B(new_n110_), .C(new_n114_), .D(new_n120_), .E(new_n125_), .Y(new_n126_));
  NOR2x1_ASAP7_75t_R   g036(.A(p23), .B(new_n104_), .Y(new_n127_));
  OAI22x1_ASAP7_75t_R  g037(.A1(new_n105_), .A2(new_n107_), .B1(new_n126_), .B2(new_n127_), .Y(new_n128_));
  AO21x1_ASAP7_75t_R   g038(.A1(p16), .A2(p15), .B(new_n100_), .Y(new_n129_));
  OR4x2_ASAP7_75t_R    g039(.A(new_n91_), .B(new_n99_), .C(p0), .D(p4), .Y(new_n130_));
  OR4x2_ASAP7_75t_R    g040(.A(p6), .B(p12), .C(p9), .D(p1), .Y(new_n131_));
  OR4x2_ASAP7_75t_R    g041(.A(new_n117_), .B(p25), .C(p5), .D(p2), .Y(new_n132_));
  NOR3x1_ASAP7_75t_R   g042(.A(new_n130_), .B(new_n131_), .C(new_n132_), .Y(new_n133_));
  INVx1_ASAP7_75t_R    g043(.A(p7), .Y(new_n134_));
  INVx1_ASAP7_75t_R    g044(.A(p17), .Y(new_n135_));
  AND5x1_ASAP7_75t_R   g045(.A(new_n121_), .B(new_n111_), .C(new_n134_), .D(p18), .E(new_n135_), .Y(new_n136_));
  AO21x1_ASAP7_75t_R   g046(.A1(new_n96_), .A2(new_n97_), .B(new_n112_), .Y(new_n137_));
  NOR2x1_ASAP7_75t_R   g047(.A(p11), .B(new_n124_), .Y(new_n138_));
  AO21x1_ASAP7_75t_R   g048(.A1(p11), .A2(new_n124_), .B(p8), .Y(new_n139_));
  OA21x2_ASAP7_75t_R   g049(.A1(new_n117_), .A2(new_n138_), .B(new_n139_), .Y(new_n140_));
  AND5x1_ASAP7_75t_R   g050(.A(new_n129_), .B(new_n133_), .C(new_n136_), .D(new_n137_), .E(new_n140_), .Y(new_n141_));
  OR3x1_ASAP7_75t_R    g051(.A(new_n141_), .B(new_n107_), .C(new_n105_), .Y(new_n142_));
  NAND2x1_ASAP7_75t_R  g052(.A(new_n128_), .B(new_n142_), .Y(o0));
  NAND2x1_ASAP7_75t_R  g053(.A(p49), .B(p48), .Y(new_n144_));
  NOR2x1_ASAP7_75t_R   g054(.A(p41), .B(p42), .Y(new_n145_));
  OAI21x1_ASAP7_75t_R  g055(.A1(p39), .A2(p38), .B(p40), .Y(new_n146_));
  NAND2x1_ASAP7_75t_R  g056(.A(p44), .B(p43), .Y(new_n147_));
  AOI21x1_ASAP7_75t_R  g057(.A1(new_n145_), .A2(new_n146_), .B(new_n147_), .Y(new_n148_));
  AO21x1_ASAP7_75t_R   g058(.A1(p46), .A2(p45), .B(p47), .Y(new_n149_));
  AOI21x1_ASAP7_75t_R  g059(.A1(p46), .A2(new_n148_), .B(new_n149_), .Y(new_n150_));
  INVx1_ASAP7_75t_R    g060(.A(p51), .Y(new_n151_));
  NAND2x1_ASAP7_75t_R  g061(.A(p52), .B(new_n151_), .Y(new_n152_));
  OAI21x1_ASAP7_75t_R  g062(.A1(new_n144_), .A2(new_n150_), .B(new_n152_), .Y(new_n153_));
  AND2x2_ASAP7_75t_R   g063(.A(p37), .B(p34), .Y(new_n154_));
  AND3x1_ASAP7_75t_R   g064(.A(new_n154_), .B(p44), .C(p30), .Y(new_n155_));
  INVx1_ASAP7_75t_R    g065(.A(p46), .Y(new_n156_));
  NOR2x1_ASAP7_75t_R   g066(.A(p45), .B(new_n156_), .Y(new_n157_));
  NAND2x1_ASAP7_75t_R  g067(.A(p46), .B(p45), .Y(new_n158_));
  OAI21x1_ASAP7_75t_R  g068(.A1(p48), .A2(new_n158_), .B(new_n149_), .Y(new_n159_));
  NAND2x1_ASAP7_75t_R  g069(.A(p54), .B(p53), .Y(new_n160_));
  NOR3x1_ASAP7_75t_R   g070(.A(new_n160_), .B(p39), .C(p38), .Y(new_n161_));
  OA211x2_ASAP7_75t_R  g071(.A1(p47), .A2(p48), .B(p36), .C(p49), .Y(new_n162_));
  AND5x1_ASAP7_75t_R   g072(.A(new_n155_), .B(new_n157_), .C(new_n159_), .D(new_n161_), .E(new_n162_), .Y(new_n163_));
  AND3x1_ASAP7_75t_R   g073(.A(p56), .B(p57), .C(p58), .Y(new_n164_));
  AND2x2_ASAP7_75t_R   g074(.A(p40), .B(p31), .Y(new_n165_));
  INVx1_ASAP7_75t_R    g075(.A(p55), .Y(new_n166_));
  AND3x1_ASAP7_75t_R   g076(.A(new_n165_), .B(new_n166_), .C(p33), .Y(new_n167_));
  INVx1_ASAP7_75t_R    g077(.A(p43), .Y(new_n168_));
  AO21x1_ASAP7_75t_R   g078(.A1(new_n145_), .A2(new_n146_), .B(new_n168_), .Y(new_n169_));
  NAND2x1_ASAP7_75t_R  g079(.A(p41), .B(p42), .Y(new_n170_));
  OAI21x1_ASAP7_75t_R  g080(.A1(new_n170_), .A2(new_n146_), .B(new_n168_), .Y(new_n171_));
  AND3x1_ASAP7_75t_R   g081(.A(p32), .B(p29), .C(p35), .Y(new_n172_));
  AND5x1_ASAP7_75t_R   g082(.A(new_n164_), .B(new_n167_), .C(new_n169_), .D(new_n171_), .E(new_n172_), .Y(new_n173_));
  NAND3x1_ASAP7_75t_R  g083(.A(new_n153_), .B(new_n163_), .C(new_n173_), .Y(new_n174_));
  AND3x1_ASAP7_75t_R   g084(.A(p54), .B(p52), .C(p53), .Y(new_n175_));
  OA21x2_ASAP7_75t_R   g085(.A1(p55), .A2(new_n175_), .B(new_n164_), .Y(new_n176_));
  INVx1_ASAP7_75t_R    g086(.A(p50), .Y(new_n177_));
  AND3x1_ASAP7_75t_R   g087(.A(new_n151_), .B(new_n166_), .C(new_n177_), .Y(new_n178_));
  OAI21x1_ASAP7_75t_R  g088(.A1(new_n144_), .A2(new_n150_), .B(new_n178_), .Y(new_n179_));
  NOR2x1_ASAP7_75t_R   g089(.A(p59), .B(p50), .Y(new_n180_));
  AOI21x1_ASAP7_75t_R  g090(.A1(new_n176_), .A2(new_n179_), .B(new_n180_), .Y(new_n181_));
  NOR2x1_ASAP7_75t_R   g091(.A(p37), .B(p55), .Y(new_n182_));
  AND3x1_ASAP7_75t_R   g092(.A(new_n182_), .B(p56), .C(p40), .Y(new_n183_));
  NOR2x1_ASAP7_75t_R   g093(.A(p42), .B(p50), .Y(new_n184_));
  INVx1_ASAP7_75t_R    g094(.A(p39), .Y(new_n185_));
  AND3x1_ASAP7_75t_R   g095(.A(new_n184_), .B(new_n185_), .C(p38), .Y(new_n186_));
  NOR3x1_ASAP7_75t_R   g096(.A(new_n147_), .B(p36), .C(p45), .Y(new_n187_));
  AND3x1_ASAP7_75t_R   g097(.A(new_n183_), .B(new_n186_), .C(new_n187_), .Y(new_n188_));
  INVx1_ASAP7_75t_R    g098(.A(p41), .Y(new_n189_));
  INVx1_ASAP7_75t_R    g099(.A(p47), .Y(new_n190_));
  AND2x2_ASAP7_75t_R   g100(.A(p49), .B(p48), .Y(new_n191_));
  OAI21x1_ASAP7_75t_R  g101(.A1(new_n156_), .A2(new_n190_), .B(new_n191_), .Y(new_n192_));
  OR3x1_ASAP7_75t_R    g102(.A(new_n160_), .B(p34), .C(p30), .Y(new_n193_));
  AOI211x1_ASAP7_75t_R g103(.A1(new_n189_), .A2(new_n146_), .B(new_n192_), .C(new_n193_), .Y(new_n194_));
  NOR2x1_ASAP7_75t_R   g104(.A(new_n189_), .B(new_n146_), .Y(new_n195_));
  OR4x2_ASAP7_75t_R    g105(.A(p32), .B(p33), .C(p35), .D(p31), .Y(new_n196_));
  NOR3x1_ASAP7_75t_R   g106(.A(new_n195_), .B(new_n196_), .C(new_n152_), .Y(new_n197_));
  NAND3x1_ASAP7_75t_R  g107(.A(new_n188_), .B(new_n194_), .C(new_n197_), .Y(new_n198_));
  NOR3x1_ASAP7_75t_R   g108(.A(new_n148_), .B(p45), .C(new_n190_), .Y(new_n199_));
  INVx1_ASAP7_75t_R    g109(.A(new_n158_), .Y(new_n200_));
  AO21x1_ASAP7_75t_R   g110(.A1(p46), .A2(new_n148_), .B(new_n200_), .Y(new_n201_));
  NOR2x1_ASAP7_75t_R   g111(.A(p59), .B(p29), .Y(new_n202_));
  OAI21x1_ASAP7_75t_R  g112(.A1(new_n199_), .A2(new_n201_), .B(new_n202_), .Y(new_n203_));
  AOI211x1_ASAP7_75t_R g113(.A1(new_n145_), .A2(new_n146_), .B(new_n156_), .C(new_n147_), .Y(new_n204_));
  OAI21x1_ASAP7_75t_R  g114(.A1(new_n149_), .A2(new_n204_), .B(new_n191_), .Y(new_n205_));
  INVx1_ASAP7_75t_R    g115(.A(new_n176_), .Y(new_n206_));
  AOI21x1_ASAP7_75t_R  g116(.A1(new_n178_), .A2(new_n205_), .B(new_n206_), .Y(new_n207_));
  OAI21x1_ASAP7_75t_R  g117(.A1(new_n198_), .A2(new_n203_), .B(new_n207_), .Y(new_n208_));
  OAI21x1_ASAP7_75t_R  g118(.A1(new_n174_), .A2(new_n181_), .B(new_n208_), .Y(new_n209_));
  NOR3x1_ASAP7_75t_R   g119(.A(new_n141_), .B(new_n107_), .C(new_n105_), .Y(new_n210_));
  AOI21x1_ASAP7_75t_R  g120(.A1(new_n128_), .A2(new_n209_), .B(new_n210_), .Y(o1));
  NOR2x1_ASAP7_75t_R   g121(.A(new_n95_), .B(new_n100_), .Y(new_n212_));
  INVx1_ASAP7_75t_R    g122(.A(new_n103_), .Y(new_n213_));
  AOI211x1_ASAP7_75t_R g123(.A1(new_n93_), .A2(new_n212_), .B(new_n91_), .C(new_n213_), .Y(new_n214_));
  AND2x2_ASAP7_75t_R   g124(.A(p25), .B(new_n106_), .Y(new_n215_));
  INVx1_ASAP7_75t_R    g125(.A(new_n99_), .Y(new_n216_));
  AND2x2_ASAP7_75t_R   g126(.A(p3), .B(p10), .Y(new_n217_));
  NOR2x1_ASAP7_75t_R   g127(.A(new_n122_), .B(new_n123_), .Y(new_n218_));
  AND5x1_ASAP7_75t_R   g128(.A(new_n119_), .B(new_n216_), .C(new_n116_), .D(new_n217_), .E(new_n218_), .Y(new_n219_));
  AO21x1_ASAP7_75t_R   g129(.A1(p22), .A2(new_n94_), .B(p23), .Y(new_n220_));
  OR3x1_ASAP7_75t_R    g130(.A(new_n108_), .B(p16), .C(p15), .Y(new_n221_));
  AND3x1_ASAP7_75t_R   g131(.A(new_n111_), .B(new_n106_), .C(new_n113_), .Y(new_n222_));
  AND5x1_ASAP7_75t_R   g132(.A(new_n212_), .B(new_n219_), .C(new_n220_), .D(new_n221_), .E(new_n222_), .Y(new_n223_));
  AOI211x1_ASAP7_75t_R g133(.A1(new_n106_), .A2(new_n214_), .B(new_n215_), .C(new_n223_), .Y(new_n224_));
  AND2x2_ASAP7_75t_R   g134(.A(p59), .B(p29), .Y(new_n225_));
  OA21x2_ASAP7_75t_R   g135(.A1(p45), .A2(new_n148_), .B(new_n156_), .Y(new_n226_));
  NOR2x1_ASAP7_75t_R   g136(.A(p35), .B(p42), .Y(new_n227_));
  INVx1_ASAP7_75t_R    g137(.A(p31), .Y(new_n228_));
  AND3x1_ASAP7_75t_R   g138(.A(new_n227_), .B(new_n228_), .C(p38), .Y(new_n229_));
  NAND3x1_ASAP7_75t_R  g139(.A(new_n229_), .B(new_n178_), .C(new_n175_), .Y(new_n230_));
  XOR2x2_ASAP7_75t_R   g140(.A(new_n146_), .B(p41), .Y(new_n231_));
  AND2x2_ASAP7_75t_R   g141(.A(p46), .B(p47), .Y(new_n232_));
  OR5x1_ASAP7_75t_R    g142(.A(p36), .B(new_n232_), .C(p45), .D(new_n147_), .E(new_n144_), .Y(new_n233_));
  OR4x2_ASAP7_75t_R    g143(.A(p37), .B(p34), .C(p30), .D(p32), .Y(new_n234_));
  INVx1_ASAP7_75t_R    g144(.A(p33), .Y(new_n235_));
  NAND2x1_ASAP7_75t_R  g145(.A(p56), .B(new_n235_), .Y(new_n236_));
  NAND2x1_ASAP7_75t_R  g146(.A(p40), .B(new_n185_), .Y(new_n237_));
  OR3x1_ASAP7_75t_R    g147(.A(new_n234_), .B(new_n236_), .C(new_n237_), .Y(new_n238_));
  OR5x1_ASAP7_75t_R    g148(.A(new_n226_), .B(new_n230_), .C(new_n231_), .D(new_n233_), .E(new_n238_), .Y(new_n239_));
  OAI21x1_ASAP7_75t_R  g149(.A1(new_n225_), .A2(new_n239_), .B(new_n207_), .Y(new_n240_));
  NOR3x1_ASAP7_75t_R   g150(.A(new_n210_), .B(new_n224_), .C(new_n240_), .Y(o2));
  assign               o3 = 1'b0;
  assign               o4 = 1'b0;
  assign               o5 = 1'b0;
  assign               o6 = 1'b0;
  assign               o7 = 1'b0;
  assign               o8 = 1'b0;
  assign               o9 = 1'b0;
  assign               o10 = 1'b0;
  assign               o11 = 1'b0;
  assign               o12 = 1'b0;
  assign               o13 = 1'b0;
  assign               o14 = 1'b0;
  assign               o15 = 1'b0;
  assign               o16 = 1'b0;
  assign               o17 = 1'b0;
  assign               o18 = 1'b0;
  assign               o19 = 1'b0;
  assign               o20 = 1'b0;
  assign               o21 = 1'b0;
  assign               o22 = 1'b0;
  assign               o23 = 1'b0;
  assign               o24 = 1'b0;
  assign               o25 = 1'b0;
  assign               o26 = 1'b0;
  assign               o27 = 1'b0;
  assign               o28 = 1'b0;
  assign               o29 = 1'b0;
endmodule


