// Benchmark "/tmp/" written by ABC on Tue Oct 20 18:11:44 2026

module \/tmp/  ( 
    p5, p6, p1, p45, p50, p29, p24, p33, p2, p53, p39, p49, p4, p21, p3,
    p32, p16, p51, p55, p47, p18, p48, p27, p54, p56, p11, p58, p46, p9,
    p37, p28, p22, p12, p25, p38, p10, p20, p57, p31, p41, p44, p52, p30,
    p0, p14, p17, p40, p42, p43, p36, p19, p23, p35, p13, p59, p15, p26,
    p8, p7, p34,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25, o26, o27, o28, o29  );
  input  p5, p6, p1, p45, p50, p29, p24, p33, p2, p53, p39, p49, p4, p21,
    p3, p32, p16, p51, p55, p47, p18, p48, p27, p54, p56, p11, p58, p46,
    p9, p37, p28, p22, p12, p25, p38, p10, p20, p57, p31, p41, p44, p52,
    p30, p0, p14, p17, p40, p42, p43, p36, p19, p23, p35, p13, p59, p15,
    p26, p8, p7, p34;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25, o26, o27, o28, o29;
  wire new_n91_, new_n92_, new_n93_, new_n94_, new_n95_, new_n96_, new_n97_,
    new_n98_, new_n99_, new_n100_, new_n101_, new_n102_, new_n103_,
    new_n104_, new_n105_, new_n106_, new_n107_, new_n108_, new_n109_,
    new_n110_, new_n111_, new_n112_, new_n113_, new_n114_, new_n115_,
    new_n116_, new_n117_, new_n118_, new_n119_, new_n120_, new_n121_,
    new_n122_, new_n123_, new_n124_, new_n125_, new_n126_, new_n127_,
    new_n128_, new_n129_, new_n130_, new_n131_, new_n132_, new_n133_,
    new_n134_, new_n135_, new_n136_, new_n137_, new_n138_, new_n139_,
    new_n141_, new_n142_, new_n143_, new_n144_, new_n145_, new_n146_,
    new_n147_, new_n148_, new_n149_, new_n150_, new_n151_, new_n152_,
    new_n153_, new_n154_, new_n155_, new_n156_, new_n157_, new_n158_,
    new_n159_, new_n160_, new_n161_, new_n162_, new_n163_, new_n164_,
    new_n165_, new_n166_, new_n167_, new_n168_, new_n169_, new_n170_,
    new_n171_, new_n172_, new_n173_, new_n174_, new_n175_, new_n176_,
    new_n177_, new_n178_, new_n179_, new_n180_, new_n181_, new_n182_,
    new_n183_, new_n184_, new_n185_, new_n186_, new_n187_, new_n188_,
    new_n189_, new_n190_, new_n191_, new_n192_, new_n193_, new_n194_,
    new_n195_, new_n196_, new_n197_, new_n198_, new_n199_, new_n200_,
    new_n201_, new_n202_, new_n203_, new_n204_, new_n205_, new_n206_,
    new_n207_, new_n208_, new_n209_, new_n210_, new_n211_, new_n212_,
    new_n213_, new_n214_, new_n215_, new_n216_, new_n217_, new_n218_,
    new_n219_, new_n220_, new_n221_, new_n222_, new_n224_, new_n225_,
    new_n226_, new_n227_, new_n228_, new_n229_, new_n230_, new_n231_,
    new_n232_, new_n233_, new_n234_, new_n235_, new_n236_, new_n237_,
    new_n238_;
  AND3x1_ASAP7_75t_R   g000(.A(p27), .B(p28), .C(p26), .Y(new_n91_));
  INVx1_ASAP7_75t_R    g001(.A(new_n91_), .Y(new_n92_));
  AND2x2_ASAP7_75t_R   g002(.A(p24), .B(p23), .Y(new_n93_));
  INVx1_ASAP7_75t_R    g003(.A(new_n93_), .Y(new_n94_));
  NOR2x1_ASAP7_75t_R   g004(.A(p21), .B(p20), .Y(new_n95_));
  NOR2x1_ASAP7_75t_R   g005(.A(p11), .B(p12), .Y(new_n96_));
  OAI21x1_ASAP7_75t_R  g006(.A1(p9), .A2(p8), .B(p10), .Y(new_n97_));
  NAND2x1_ASAP7_75t_R  g007(.A(p14), .B(p13), .Y(new_n98_));
  AOI21x1_ASAP7_75t_R  g008(.A1(new_n96_), .A2(new_n97_), .B(new_n98_), .Y(new_n99_));
  AO21x1_ASAP7_75t_R   g009(.A1(p16), .A2(p15), .B(p17), .Y(new_n100_));
  AOI21x1_ASAP7_75t_R  g010(.A1(p16), .A2(new_n99_), .B(new_n100_), .Y(new_n101_));
  AND2x2_ASAP7_75t_R   g011(.A(p18), .B(p19), .Y(new_n102_));
  INVx1_ASAP7_75t_R    g012(.A(new_n95_), .Y(new_n103_));
  OAI21x1_ASAP7_75t_R  g013(.A1(new_n102_), .A2(new_n103_), .B(p22), .Y(new_n104_));
  AO21x1_ASAP7_75t_R   g014(.A1(new_n95_), .A2(new_n101_), .B(new_n104_), .Y(new_n105_));
  NAND2x1_ASAP7_75t_R  g015(.A(p25), .B(new_n91_), .Y(new_n106_));
  OA31x2_ASAP7_75t_R   g016(.A1(new_n92_), .A2(new_n94_), .A3(new_n105_), .B1(new_n106_), .Y(new_n107_));
  INVx1_ASAP7_75t_R    g017(.A(p23), .Y(new_n108_));
  AND2x2_ASAP7_75t_R   g018(.A(p22), .B(new_n95_), .Y(new_n109_));
  NOR2x1_ASAP7_75t_R   g019(.A(p9), .B(p8), .Y(new_n110_));
  AND5x1_ASAP7_75t_R   g020(.A(p0), .B(new_n109_), .C(p19), .D(p59), .E(new_n110_), .Y(new_n111_));
  INVx1_ASAP7_75t_R    g021(.A(p25), .Y(new_n112_));
  AND3x1_ASAP7_75t_R   g022(.A(new_n112_), .B(p24), .C(p18), .Y(new_n113_));
  INVx1_ASAP7_75t_R    g023(.A(p15), .Y(new_n114_));
  AND5x1_ASAP7_75t_R   g024(.A(p14), .B(new_n113_), .C(new_n114_), .D(new_n91_), .E(new_n96_), .Y(new_n115_));
  AND2x2_ASAP7_75t_R   g025(.A(p5), .B(p6), .Y(new_n116_));
  AND2x2_ASAP7_75t_R   g026(.A(p4), .B(p3), .Y(new_n117_));
  AND2x2_ASAP7_75t_R   g027(.A(p10), .B(p7), .Y(new_n118_));
  AND5x1_ASAP7_75t_R   g028(.A(p1), .B(new_n116_), .C(new_n117_), .D(new_n118_), .E(p2), .Y(new_n119_));
  NAND3x1_ASAP7_75t_R  g029(.A(new_n111_), .B(new_n115_), .C(new_n119_), .Y(new_n120_));
  NAND2x1_ASAP7_75t_R  g030(.A(new_n96_), .B(new_n97_), .Y(new_n121_));
  XOR2x2_ASAP7_75t_R   g031(.A(new_n121_), .B(p13), .Y(new_n122_));
  OR3x1_ASAP7_75t_R    g032(.A(new_n99_), .B(p16), .C(p15), .Y(new_n123_));
  NAND3x1_ASAP7_75t_R  g033(.A(new_n122_), .B(new_n101_), .C(new_n123_), .Y(new_n124_));
  AO211x2_ASAP7_75t_R  g034(.A1(new_n108_), .A2(new_n105_), .B(new_n120_), .C(new_n124_), .Y(new_n125_));
  AOI21x1_ASAP7_75t_R  g035(.A1(new_n95_), .A2(new_n101_), .B(new_n104_), .Y(new_n126_));
  AOI21x1_ASAP7_75t_R  g036(.A1(new_n93_), .A2(new_n126_), .B(p25), .Y(new_n127_));
  OA21x2_ASAP7_75t_R   g037(.A1(p15), .A2(new_n99_), .B(p16), .Y(new_n128_));
  INVx1_ASAP7_75t_R    g038(.A(p17), .Y(new_n129_));
  INVx1_ASAP7_75t_R    g039(.A(p7), .Y(new_n130_));
  AND3x1_ASAP7_75t_R   g040(.A(new_n129_), .B(new_n130_), .C(p8), .Y(new_n131_));
  AND5x1_ASAP7_75t_R   g041(.A(p22), .B(new_n131_), .C(new_n95_), .D(new_n96_), .E(new_n102_), .Y(new_n132_));
  OR4x2_ASAP7_75t_R    g042(.A(p4), .B(p3), .C(p9), .D(p0), .Y(new_n133_));
  OR4x2_ASAP7_75t_R    g043(.A(p5), .B(p6), .C(p1), .D(p2), .Y(new_n134_));
  NOR2x1_ASAP7_75t_R   g044(.A(new_n133_), .B(new_n134_), .Y(new_n135_));
  NAND2x1_ASAP7_75t_R  g045(.A(p15), .B(new_n99_), .Y(new_n136_));
  AND5x1_ASAP7_75t_R   g046(.A(new_n112_), .B(new_n93_), .C(p10), .D(p14), .E(p13), .Y(new_n137_));
  AND5x1_ASAP7_75t_R   g047(.A(new_n128_), .B(new_n132_), .C(new_n135_), .D(new_n136_), .E(new_n137_), .Y(new_n138_));
  NOR3x1_ASAP7_75t_R   g048(.A(new_n127_), .B(new_n138_), .C(new_n92_), .Y(new_n139_));
  AO21x1_ASAP7_75t_R   g049(.A1(new_n107_), .A2(new_n125_), .B(new_n139_), .Y(o0));
  INVx1_ASAP7_75t_R    g050(.A(p16), .Y(new_n141_));
  NAND2x1_ASAP7_75t_R  g051(.A(new_n141_), .B(new_n97_), .Y(new_n142_));
  AND2x2_ASAP7_75t_R   g052(.A(p2), .B(p4), .Y(new_n143_));
  AND3x1_ASAP7_75t_R   g053(.A(new_n143_), .B(p3), .C(p0), .Y(new_n144_));
  AND3x1_ASAP7_75t_R   g054(.A(new_n116_), .B(p1), .C(p24), .Y(new_n145_));
  AND2x2_ASAP7_75t_R   g055(.A(p10), .B(new_n112_), .Y(new_n146_));
  AND3x1_ASAP7_75t_R   g056(.A(new_n110_), .B(p14), .C(p13), .Y(new_n147_));
  AND5x1_ASAP7_75t_R   g057(.A(new_n142_), .B(new_n144_), .C(new_n145_), .D(new_n146_), .E(new_n147_), .Y(new_n148_));
  AND3x1_ASAP7_75t_R   g058(.A(new_n114_), .B(p59), .C(p7), .Y(new_n149_));
  AND5x1_ASAP7_75t_R   g059(.A(new_n91_), .B(new_n109_), .C(new_n149_), .D(new_n96_), .E(new_n102_), .Y(new_n150_));
  NAND3x1_ASAP7_75t_R  g060(.A(new_n148_), .B(new_n101_), .C(new_n150_), .Y(new_n151_));
  NOR2x1_ASAP7_75t_R   g061(.A(p23), .B(new_n126_), .Y(new_n152_));
  OAI22x1_ASAP7_75t_R  g062(.A1(new_n127_), .A2(new_n92_), .B1(new_n151_), .B2(new_n152_), .Y(new_n153_));
  NOR2x1_ASAP7_75t_R   g063(.A(p50), .B(p51), .Y(new_n154_));
  AND2x2_ASAP7_75t_R   g064(.A(p53), .B(p54), .Y(new_n155_));
  NAND2x1_ASAP7_75t_R  g065(.A(p52), .B(new_n155_), .Y(new_n156_));
  INVx1_ASAP7_75t_R    g066(.A(p55), .Y(new_n157_));
  OA21x2_ASAP7_75t_R   g067(.A1(new_n154_), .A2(new_n156_), .B(new_n157_), .Y(new_n158_));
  AND2x2_ASAP7_75t_R   g068(.A(p49), .B(p48), .Y(new_n159_));
  AND3x1_ASAP7_75t_R   g069(.A(new_n155_), .B(new_n159_), .C(p52), .Y(new_n160_));
  NOR2x1_ASAP7_75t_R   g070(.A(p41), .B(p42), .Y(new_n161_));
  OAI21x1_ASAP7_75t_R  g071(.A1(p39), .A2(p38), .B(p40), .Y(new_n162_));
  NAND2x1_ASAP7_75t_R  g072(.A(p44), .B(p43), .Y(new_n163_));
  AOI21x1_ASAP7_75t_R  g073(.A1(new_n161_), .A2(new_n162_), .B(new_n163_), .Y(new_n164_));
  AO21x1_ASAP7_75t_R   g074(.A1(p45), .A2(p46), .B(p47), .Y(new_n165_));
  AO21x1_ASAP7_75t_R   g075(.A1(p46), .A2(new_n164_), .B(new_n165_), .Y(new_n166_));
  NAND2x1_ASAP7_75t_R  g076(.A(new_n160_), .B(new_n166_), .Y(new_n167_));
  AND3x1_ASAP7_75t_R   g077(.A(p56), .B(p58), .C(p57), .Y(new_n168_));
  INVx1_ASAP7_75t_R    g078(.A(new_n168_), .Y(new_n169_));
  AO21x1_ASAP7_75t_R   g079(.A1(new_n158_), .A2(new_n167_), .B(new_n169_), .Y(new_n170_));
  INVx1_ASAP7_75t_R    g080(.A(p44), .Y(new_n171_));
  NOR2x1_ASAP7_75t_R   g081(.A(p44), .B(p43), .Y(new_n172_));
  AO31x2_ASAP7_75t_R   g082(.A1(new_n162_), .A2(new_n171_), .A3(new_n161_), .B(new_n172_), .Y(new_n173_));
  INVx1_ASAP7_75t_R    g083(.A(new_n173_), .Y(new_n174_));
  INVx1_ASAP7_75t_R    g084(.A(p32), .Y(new_n175_));
  NOR2x1_ASAP7_75t_R   g085(.A(p55), .B(new_n175_), .Y(new_n176_));
  INVx1_ASAP7_75t_R    g086(.A(p29), .Y(new_n177_));
  NOR2x1_ASAP7_75t_R   g087(.A(p45), .B(new_n177_), .Y(new_n178_));
  AND2x2_ASAP7_75t_R   g088(.A(p46), .B(p37), .Y(new_n179_));
  AND2x2_ASAP7_75t_R   g089(.A(p33), .B(p49), .Y(new_n180_));
  AND4x2_ASAP7_75t_R   g090(.A(new_n176_), .B(new_n178_), .C(new_n179_), .D(new_n180_), .Y(new_n181_));
  AND3x1_ASAP7_75t_R   g091(.A(p36), .B(p35), .C(p34), .Y(new_n182_));
  INVx1_ASAP7_75t_R    g092(.A(p41), .Y(new_n183_));
  AND5x1_ASAP7_75t_R   g093(.A(p31), .B(new_n182_), .C(new_n183_), .D(p30), .E(p43), .Y(new_n184_));
  INVx1_ASAP7_75t_R    g094(.A(p51), .Y(new_n185_));
  INVx1_ASAP7_75t_R    g095(.A(p42), .Y(new_n186_));
  AND5x1_ASAP7_75t_R   g096(.A(new_n185_), .B(new_n168_), .C(p52), .D(p40), .E(new_n186_), .Y(new_n187_));
  INVx1_ASAP7_75t_R    g097(.A(p47), .Y(new_n188_));
  INVx1_ASAP7_75t_R    g098(.A(p48), .Y(new_n189_));
  NAND2x1_ASAP7_75t_R  g099(.A(new_n188_), .B(new_n189_), .Y(new_n190_));
  NOR2x1_ASAP7_75t_R   g100(.A(p39), .B(p38), .Y(new_n191_));
  AND3x1_ASAP7_75t_R   g101(.A(new_n190_), .B(new_n191_), .C(new_n155_), .Y(new_n192_));
  AND5x1_ASAP7_75t_R   g102(.A(new_n174_), .B(new_n181_), .C(new_n184_), .D(new_n187_), .E(new_n192_), .Y(new_n193_));
  NOR2x1_ASAP7_75t_R   g103(.A(p50), .B(p59), .Y(new_n194_));
  OAI21x1_ASAP7_75t_R  g104(.A1(p45), .A2(new_n164_), .B(p46), .Y(new_n195_));
  OAI21x1_ASAP7_75t_R  g105(.A1(p48), .A2(new_n195_), .B(new_n166_), .Y(new_n196_));
  NAND3x1_ASAP7_75t_R  g106(.A(new_n193_), .B(new_n194_), .C(new_n196_), .Y(new_n197_));
  INVx1_ASAP7_75t_R    g107(.A(p40), .Y(new_n198_));
  OR3x1_ASAP7_75t_R    g108(.A(new_n191_), .B(new_n183_), .C(new_n198_), .Y(new_n199_));
  NAND2x1_ASAP7_75t_R  g109(.A(p47), .B(p46), .Y(new_n200_));
  AND3x1_ASAP7_75t_R   g110(.A(new_n155_), .B(new_n159_), .C(new_n200_), .Y(new_n201_));
  NOR3x1_ASAP7_75t_R   g111(.A(new_n163_), .B(p45), .C(p50), .Y(new_n202_));
  NAND2x1_ASAP7_75t_R  g112(.A(new_n183_), .B(new_n162_), .Y(new_n203_));
  NOR2x1_ASAP7_75t_R   g113(.A(p33), .B(p39), .Y(new_n204_));
  AND3x1_ASAP7_75t_R   g114(.A(new_n204_), .B(new_n175_), .C(new_n157_), .Y(new_n205_));
  AND5x1_ASAP7_75t_R   g115(.A(new_n199_), .B(new_n201_), .C(new_n202_), .D(new_n203_), .E(new_n205_), .Y(new_n206_));
  NOR2x1_ASAP7_75t_R   g116(.A(p29), .B(p59), .Y(new_n207_));
  INVx1_ASAP7_75t_R    g117(.A(p46), .Y(new_n208_));
  OAI21x1_ASAP7_75t_R  g118(.A1(p45), .A2(new_n164_), .B(new_n208_), .Y(new_n209_));
  NOR2x1_ASAP7_75t_R   g119(.A(p42), .B(new_n198_), .Y(new_n210_));
  NOR2x1_ASAP7_75t_R   g120(.A(p35), .B(p34), .Y(new_n211_));
  INVx1_ASAP7_75t_R    g121(.A(p30), .Y(new_n212_));
  INVx1_ASAP7_75t_R    g122(.A(p36), .Y(new_n213_));
  AND3x1_ASAP7_75t_R   g123(.A(new_n211_), .B(new_n212_), .C(new_n213_), .Y(new_n214_));
  AND2x2_ASAP7_75t_R   g124(.A(p52), .B(new_n185_), .Y(new_n215_));
  INVx1_ASAP7_75t_R    g125(.A(p56), .Y(new_n216_));
  NOR2x1_ASAP7_75t_R   g126(.A(p37), .B(new_n216_), .Y(new_n217_));
  INVx1_ASAP7_75t_R    g127(.A(p31), .Y(new_n218_));
  AND2x2_ASAP7_75t_R   g128(.A(p38), .B(new_n218_), .Y(new_n219_));
  AND5x1_ASAP7_75t_R   g129(.A(new_n210_), .B(new_n214_), .C(new_n215_), .D(new_n217_), .E(new_n219_), .Y(new_n220_));
  AND5x1_ASAP7_75t_R   g130(.A(new_n166_), .B(new_n206_), .C(new_n207_), .D(new_n209_), .E(new_n220_), .Y(new_n221_));
  AOI21x1_ASAP7_75t_R  g131(.A1(new_n170_), .A2(new_n197_), .B(new_n221_), .Y(new_n222_));
  AOI21x1_ASAP7_75t_R  g132(.A1(new_n153_), .A2(new_n222_), .B(new_n139_), .Y(o1));
  OR3x1_ASAP7_75t_R    g133(.A(new_n164_), .B(p45), .C(new_n188_), .Y(new_n224_));
  AO22x1_ASAP7_75t_R   g134(.A1(p29), .A2(p59), .B1(new_n195_), .B2(new_n224_), .Y(new_n225_));
  INVx1_ASAP7_75t_R    g135(.A(p35), .Y(new_n226_));
  INVx1_ASAP7_75t_R    g136(.A(p34), .Y(new_n227_));
  AND5x1_ASAP7_75t_R   g137(.A(new_n218_), .B(new_n159_), .C(new_n212_), .D(new_n226_), .E(new_n227_), .Y(new_n228_));
  NOR2x1_ASAP7_75t_R   g138(.A(p33), .B(p32), .Y(new_n229_));
  AND5x1_ASAP7_75t_R   g139(.A(new_n155_), .B(new_n228_), .C(new_n215_), .D(new_n200_), .E(new_n229_), .Y(new_n230_));
  AND2x2_ASAP7_75t_R   g140(.A(new_n203_), .B(new_n199_), .Y(new_n231_));
  NOR2x1_ASAP7_75t_R   g141(.A(p55), .B(p37), .Y(new_n232_));
  INVx1_ASAP7_75t_R    g142(.A(p39), .Y(new_n233_));
  AND3x1_ASAP7_75t_R   g143(.A(new_n232_), .B(new_n233_), .C(p56), .Y(new_n234_));
  AND5x1_ASAP7_75t_R   g144(.A(p38), .B(new_n234_), .C(new_n213_), .D(new_n202_), .E(new_n210_), .Y(new_n235_));
  NAND3x1_ASAP7_75t_R  g145(.A(new_n230_), .B(new_n231_), .C(new_n235_), .Y(new_n236_));
  AOI21x1_ASAP7_75t_R  g146(.A1(new_n158_), .A2(new_n167_), .B(new_n169_), .Y(new_n237_));
  OAI21x1_ASAP7_75t_R  g147(.A1(new_n225_), .A2(new_n236_), .B(new_n237_), .Y(new_n238_));
  AOI211x1_ASAP7_75t_R g148(.A1(new_n107_), .A2(new_n125_), .B(new_n238_), .C(new_n139_), .Y(o2));
  assign               o3 = 1'b0;
  assign               o4 = 1'b0;
  assign               o5 = 1'b0;
  assign               o6 = 1'b0;
  assign               o7 = 1'b0;
  assign               o8 = 1'b0;
  assign               o9 = 1'b0;
  assign               o10 = 1'b0;
  assign               o11 = 1'b0;
  assign               o12 = 1'b0;
  assign               o13 = 1'b0;
  assign               o14 = 1'b0;
  assign               o15 = 1'b0;
  assign               o16 = 1'b0;
  assign               o17 = 1'b0;
  assign               o18 = 1'b0;
  assign               o19 = 1'b0;
  assign               o20 = 1'b0;
  assign               o21 = 1'b0;
  assign               o22 = 1'b0;
  assign               o23 = 1'b0;
  assign               o24 = 1'b0;
  assign               o25 = 1'b0;
  assign               o26 = 1'b0;
  assign               o27 = 1'b0;
  assign               o28 = 1'b0;
  assign               o29 = 1'b0;
endmodule


