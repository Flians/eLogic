// Benchmark "/tmp/" written by ABC on Tue Oct 20 18:11:51 2026

module \/tmp/  ( 
    p39, p18, p12, p23, p21, p44, p17, p38, p24, p3, p20, p42, p49, p25,
    p59, p54, p41, p19, p52, p37, p45, p5, p33, p2, p57, p35, p11, p6, p48,
    p0, p29, p8, p22, p10, p58, p56, p31, p1, p26, p46, p30, p4, p43, p7,
    p16, p27, p47, p14, p9, p34, p53, p32, p51, p36, p28, p40, p55, p15,
    p13, p50,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25, o26, o27, o28, o29  );
  input  p39, p18, p12, p23, p21, p44, p17, p38, p24, p3, p20, p42, p49,
    p25, p59, p54, p41, p19, p52, p37, p45, p5, p33, p2, p57, p35, p11, p6,
    p48, p0, p29, p8, p22, p10, p58, p56, p31, p1, p26, p46, p30, p4, p43,
    p7, p16, p27, p47, p14, p9, p34, p53, p32, p51, p36, p28, p40, p55,
    p15, p13, p50;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25, o26, o27, o28, o29;
  wire new_n91_, new_n92_, new_n93_, new_n94_, new_n95_, new_n96_, new_n97_,
    new_n98_, new_n99_, new_n100_, new_n101_, new_n102_, new_n103_,
    new_n104_, new_n105_, new_n106_, new_n107_, new_n108_, new_n109_,
    new_n110_, new_n111_, new_n112_, new_n113_, new_n114_, new_n115_,
    new_n116_, new_n117_, new_n118_, new_n119_, new_n120_, new_n121_,
    new_n122_, new_n123_, new_n124_, new_n125_, new_n126_, new_n127_,
    new_n128_, new_n129_, new_n130_, new_n131_, new_n132_, new_n133_,
    new_n134_, new_n135_, new_n136_, new_n137_, new_n138_, new_n139_,
    new_n140_, new_n141_, new_n142_, new_n143_, new_n144_, new_n145_,
    new_n146_, new_n148_, new_n149_, new_n150_, new_n151_, new_n152_,
    new_n153_, new_n154_, new_n155_, new_n156_, new_n157_, new_n158_,
    new_n159_, new_n160_, new_n161_, new_n162_, new_n163_, new_n164_,
    new_n165_, new_n166_, new_n167_, new_n168_, new_n169_, new_n170_,
    new_n171_, new_n172_, new_n173_, new_n174_, new_n175_, new_n176_,
    new_n177_, new_n178_, new_n179_, new_n180_, new_n181_, new_n182_,
    new_n183_, new_n184_, new_n185_, new_n186_, new_n187_, new_n188_,
    new_n189_, new_n190_, new_n191_, new_n192_, new_n193_, new_n194_,
    new_n195_, new_n196_, new_n197_, new_n198_, new_n199_, new_n200_,
    new_n201_, new_n202_, new_n203_, new_n204_, new_n205_, new_n206_,
    new_n207_, new_n208_, new_n209_, new_n210_, new_n211_, new_n212_,
    new_n213_, new_n215_, new_n216_, new_n217_, new_n218_, new_n219_,
    new_n220_, new_n221_, new_n222_, new_n223_, new_n224_, new_n225_,
    new_n226_, new_n227_, new_n228_, new_n229_, new_n230_, new_n231_,
    new_n232_, new_n233_, new_n234_, new_n235_, new_n236_;
  AND3x1_ASAP7_75t_R   g000(.A(p26), .B(p27), .C(p28), .Y(new_n91_));
  INVx1_ASAP7_75t_R    g001(.A(new_n91_), .Y(new_n92_));
  AND2x2_ASAP7_75t_R   g002(.A(p23), .B(p24), .Y(new_n93_));
  INVx1_ASAP7_75t_R    g003(.A(new_n93_), .Y(new_n94_));
  NOR2x1_ASAP7_75t_R   g004(.A(p21), .B(p20), .Y(new_n95_));
  NOR2x1_ASAP7_75t_R   g005(.A(p12), .B(p11), .Y(new_n96_));
  OAI21x1_ASAP7_75t_R  g006(.A1(p8), .A2(p9), .B(p10), .Y(new_n97_));
  NAND2x1_ASAP7_75t_R  g007(.A(p14), .B(p13), .Y(new_n98_));
  AOI21x1_ASAP7_75t_R  g008(.A1(new_n96_), .A2(new_n97_), .B(new_n98_), .Y(new_n99_));
  AO21x1_ASAP7_75t_R   g009(.A1(p16), .A2(p15), .B(p17), .Y(new_n100_));
  AOI21x1_ASAP7_75t_R  g010(.A1(p16), .A2(new_n99_), .B(new_n100_), .Y(new_n101_));
  NAND2x1_ASAP7_75t_R  g011(.A(p18), .B(p19), .Y(new_n102_));
  INVx1_ASAP7_75t_R    g012(.A(p22), .Y(new_n103_));
  AO21x1_ASAP7_75t_R   g013(.A1(new_n102_), .A2(new_n95_), .B(new_n103_), .Y(new_n104_));
  AO21x1_ASAP7_75t_R   g014(.A1(new_n95_), .A2(new_n101_), .B(new_n104_), .Y(new_n105_));
  NAND2x1_ASAP7_75t_R  g015(.A(p25), .B(new_n91_), .Y(new_n106_));
  OA31x2_ASAP7_75t_R   g016(.A1(new_n92_), .A2(new_n94_), .A3(new_n105_), .B1(new_n106_), .Y(new_n107_));
  OA21x2_ASAP7_75t_R   g017(.A1(p15), .A2(new_n99_), .B(p16), .Y(new_n108_));
  AND3x1_ASAP7_75t_R   g018(.A(new_n95_), .B(p19), .C(p22), .Y(new_n109_));
  NOR2x1_ASAP7_75t_R   g019(.A(p7), .B(p9), .Y(new_n110_));
  NOR2x1_ASAP7_75t_R   g020(.A(p1), .B(p4), .Y(new_n111_));
  AND3x1_ASAP7_75t_R   g021(.A(new_n109_), .B(new_n110_), .C(new_n111_), .Y(new_n112_));
  INVx1_ASAP7_75t_R    g022(.A(p15), .Y(new_n113_));
  AO21x1_ASAP7_75t_R   g023(.A1(new_n96_), .A2(new_n97_), .B(new_n113_), .Y(new_n114_));
  INVx1_ASAP7_75t_R    g024(.A(new_n98_), .Y(new_n115_));
  INVx1_ASAP7_75t_R    g025(.A(p17), .Y(new_n116_));
  AND5x1_ASAP7_75t_R   g026(.A(p18), .B(new_n115_), .C(new_n116_), .D(new_n93_), .E(new_n96_), .Y(new_n117_));
  NOR2x1_ASAP7_75t_R   g027(.A(p6), .B(p0), .Y(new_n118_));
  NOR2x1_ASAP7_75t_R   g028(.A(p5), .B(p2), .Y(new_n119_));
  NOR2x1_ASAP7_75t_R   g029(.A(p3), .B(p25), .Y(new_n120_));
  AND5x1_ASAP7_75t_R   g030(.A(p8), .B(new_n118_), .C(new_n119_), .D(new_n120_), .E(p10), .Y(new_n121_));
  AND5x1_ASAP7_75t_R   g031(.A(new_n108_), .B(new_n112_), .C(new_n114_), .D(new_n117_), .E(new_n121_), .Y(new_n122_));
  AOI21x1_ASAP7_75t_R  g032(.A1(new_n95_), .A2(new_n101_), .B(new_n104_), .Y(new_n123_));
  AOI21x1_ASAP7_75t_R  g033(.A1(new_n93_), .A2(new_n123_), .B(p25), .Y(new_n124_));
  INVx1_ASAP7_75t_R    g034(.A(p23), .Y(new_n125_));
  OA21x2_ASAP7_75t_R   g035(.A1(new_n103_), .A2(new_n95_), .B(new_n125_), .Y(new_n126_));
  AO21x1_ASAP7_75t_R   g036(.A1(p16), .A2(new_n99_), .B(new_n100_), .Y(new_n127_));
  NAND2x1_ASAP7_75t_R  g037(.A(p24), .B(p3), .Y(new_n128_));
  INVx1_ASAP7_75t_R    g038(.A(p59), .Y(new_n129_));
  OR3x1_ASAP7_75t_R    g039(.A(new_n128_), .B(p25), .C(new_n129_), .Y(new_n130_));
  OR2x4_ASAP7_75t_R    g040(.A(p8), .B(p9), .Y(new_n131_));
  INVx1_ASAP7_75t_R    g041(.A(p12), .Y(new_n132_));
  NAND2x1_ASAP7_75t_R  g042(.A(p18), .B(new_n132_), .Y(new_n133_));
  OR3x1_ASAP7_75t_R    g043(.A(new_n130_), .B(new_n131_), .C(new_n133_), .Y(new_n134_));
  AND4x2_ASAP7_75t_R   g044(.A(p0), .B(p10), .C(p1), .D(p4), .Y(new_n135_));
  AND2x2_ASAP7_75t_R   g045(.A(p5), .B(p2), .Y(new_n136_));
  INVx1_ASAP7_75t_R    g046(.A(p11), .Y(new_n137_));
  AND3x1_ASAP7_75t_R   g047(.A(new_n136_), .B(new_n137_), .C(p6), .Y(new_n138_));
  NAND2x1_ASAP7_75t_R  g048(.A(new_n135_), .B(new_n138_), .Y(new_n139_));
  AOI21x1_ASAP7_75t_R  g049(.A1(new_n96_), .A2(new_n97_), .B(p13), .Y(new_n140_));
  AND3x1_ASAP7_75t_R   g050(.A(new_n97_), .B(p13), .C(new_n96_), .Y(new_n141_));
  NOR2x1_ASAP7_75t_R   g051(.A(new_n140_), .B(new_n141_), .Y(new_n142_));
  AND4x2_ASAP7_75t_R   g052(.A(new_n113_), .B(p7), .C(p16), .D(p14), .Y(new_n143_));
  NAND3x1_ASAP7_75t_R  g053(.A(new_n109_), .B(new_n91_), .C(new_n143_), .Y(new_n144_));
  OR5x1_ASAP7_75t_R    g054(.A(new_n127_), .B(new_n134_), .C(new_n139_), .D(new_n142_), .E(new_n144_), .Y(new_n145_));
  OAI22x1_ASAP7_75t_R  g055(.A1(new_n124_), .A2(new_n92_), .B1(new_n126_), .B2(new_n145_), .Y(new_n146_));
  OAI21x1_ASAP7_75t_R  g056(.A1(new_n107_), .A2(new_n122_), .B(new_n146_), .Y(o0));
  NAND2x1_ASAP7_75t_R  g057(.A(p49), .B(p48), .Y(new_n148_));
  NOR2x1_ASAP7_75t_R   g058(.A(p42), .B(p41), .Y(new_n149_));
  OAI21x1_ASAP7_75t_R  g059(.A1(p39), .A2(p38), .B(p40), .Y(new_n150_));
  NAND2x1_ASAP7_75t_R  g060(.A(p44), .B(p43), .Y(new_n151_));
  AOI21x1_ASAP7_75t_R  g061(.A1(new_n149_), .A2(new_n150_), .B(new_n151_), .Y(new_n152_));
  AO21x1_ASAP7_75t_R   g062(.A1(p45), .A2(p46), .B(p47), .Y(new_n153_));
  AOI21x1_ASAP7_75t_R  g063(.A1(p46), .A2(new_n152_), .B(new_n153_), .Y(new_n154_));
  INVx1_ASAP7_75t_R    g064(.A(p51), .Y(new_n155_));
  INVx1_ASAP7_75t_R    g065(.A(p55), .Y(new_n156_));
  INVx1_ASAP7_75t_R    g066(.A(p50), .Y(new_n157_));
  AND3x1_ASAP7_75t_R   g067(.A(new_n155_), .B(new_n156_), .C(new_n157_), .Y(new_n158_));
  OAI21x1_ASAP7_75t_R  g068(.A1(new_n148_), .A2(new_n154_), .B(new_n158_), .Y(new_n159_));
  AND3x1_ASAP7_75t_R   g069(.A(p54), .B(p52), .C(p53), .Y(new_n160_));
  AND3x1_ASAP7_75t_R   g070(.A(p57), .B(p58), .C(p56), .Y(new_n161_));
  OA21x2_ASAP7_75t_R   g071(.A1(p55), .A2(new_n160_), .B(new_n161_), .Y(new_n162_));
  AOI22x1_ASAP7_75t_R  g072(.A1(new_n159_), .A2(new_n162_), .B1(new_n129_), .B2(new_n157_), .Y(new_n163_));
  INVx1_ASAP7_75t_R    g073(.A(p46), .Y(new_n164_));
  AOI211x1_ASAP7_75t_R g074(.A1(new_n149_), .A2(new_n150_), .B(new_n164_), .C(new_n151_), .Y(new_n165_));
  INVx1_ASAP7_75t_R    g075(.A(new_n148_), .Y(new_n166_));
  NOR2x1_ASAP7_75t_R   g076(.A(p52), .B(new_n155_), .Y(new_n167_));
  OA211x2_ASAP7_75t_R  g077(.A1(new_n153_), .A2(new_n165_), .B(new_n166_), .C(new_n167_), .Y(new_n168_));
  NAND2x1_ASAP7_75t_R  g078(.A(new_n149_), .B(new_n150_), .Y(new_n169_));
  INVx1_ASAP7_75t_R    g079(.A(new_n151_), .Y(new_n170_));
  AO31x2_ASAP7_75t_R   g080(.A1(new_n169_), .A2(p46), .A3(new_n170_), .B(new_n153_), .Y(new_n171_));
  NAND2x1_ASAP7_75t_R  g081(.A(p52), .B(new_n155_), .Y(new_n172_));
  AOI21x1_ASAP7_75t_R  g082(.A1(new_n166_), .A2(new_n171_), .B(new_n172_), .Y(new_n173_));
  NOR2x1_ASAP7_75t_R   g083(.A(new_n151_), .B(new_n148_), .Y(new_n174_));
  AND5x1_ASAP7_75t_R   g084(.A(p32), .B(new_n161_), .C(p36), .D(p40), .E(new_n156_), .Y(new_n175_));
  AND2x2_ASAP7_75t_R   g085(.A(p54), .B(p53), .Y(new_n176_));
  INVx1_ASAP7_75t_R    g086(.A(p45), .Y(new_n177_));
  NOR2x1_ASAP7_75t_R   g087(.A(p39), .B(p38), .Y(new_n178_));
  AND5x1_ASAP7_75t_R   g088(.A(p37), .B(new_n176_), .C(new_n177_), .D(new_n178_), .E(new_n149_), .Y(new_n179_));
  AND2x2_ASAP7_75t_R   g089(.A(p33), .B(p35), .Y(new_n180_));
  AND3x1_ASAP7_75t_R   g090(.A(new_n180_), .B(p29), .C(p31), .Y(new_n181_));
  AND2x2_ASAP7_75t_R   g091(.A(p46), .B(p30), .Y(new_n182_));
  INVx1_ASAP7_75t_R    g092(.A(p47), .Y(new_n183_));
  AND3x1_ASAP7_75t_R   g093(.A(new_n182_), .B(new_n183_), .C(p34), .Y(new_n184_));
  AND5x1_ASAP7_75t_R   g094(.A(new_n174_), .B(new_n175_), .C(new_n179_), .D(new_n181_), .E(new_n184_), .Y(new_n185_));
  OAI21x1_ASAP7_75t_R  g095(.A1(new_n168_), .A2(new_n173_), .B(new_n185_), .Y(new_n186_));
  INVx1_ASAP7_75t_R    g096(.A(p41), .Y(new_n187_));
  NAND2x1_ASAP7_75t_R  g097(.A(new_n187_), .B(new_n150_), .Y(new_n188_));
  NAND2x1_ASAP7_75t_R  g098(.A(p46), .B(p47), .Y(new_n189_));
  NOR2x1_ASAP7_75t_R   g099(.A(p33), .B(p35), .Y(new_n190_));
  AND5x1_ASAP7_75t_R   g100(.A(new_n166_), .B(new_n188_), .C(new_n176_), .D(new_n189_), .E(new_n190_), .Y(new_n191_));
  INVx1_ASAP7_75t_R    g101(.A(p39), .Y(new_n192_));
  INVx1_ASAP7_75t_R    g102(.A(p36), .Y(new_n193_));
  AND5x1_ASAP7_75t_R   g103(.A(new_n192_), .B(new_n193_), .C(p44), .D(p38), .E(p43), .Y(new_n194_));
  NOR2x1_ASAP7_75t_R   g104(.A(p37), .B(p45), .Y(new_n195_));
  INVx1_ASAP7_75t_R    g105(.A(p42), .Y(new_n196_));
  AND3x1_ASAP7_75t_R   g106(.A(new_n195_), .B(new_n196_), .C(p56), .Y(new_n197_));
  AND3x1_ASAP7_75t_R   g107(.A(new_n156_), .B(new_n157_), .C(p40), .Y(new_n198_));
  AND3x1_ASAP7_75t_R   g108(.A(new_n194_), .B(new_n197_), .C(new_n198_), .Y(new_n199_));
  NOR2x1_ASAP7_75t_R   g109(.A(new_n187_), .B(new_n150_), .Y(new_n200_));
  OR4x2_ASAP7_75t_R    g110(.A(p31), .B(p30), .C(p34), .D(p32), .Y(new_n201_));
  NOR3x1_ASAP7_75t_R   g111(.A(new_n200_), .B(new_n201_), .C(new_n172_), .Y(new_n202_));
  NAND3x1_ASAP7_75t_R  g112(.A(new_n191_), .B(new_n199_), .C(new_n202_), .Y(new_n203_));
  NOR3x1_ASAP7_75t_R   g113(.A(new_n152_), .B(p45), .C(new_n183_), .Y(new_n204_));
  OA21x2_ASAP7_75t_R   g114(.A1(p45), .A2(new_n152_), .B(p46), .Y(new_n205_));
  NOR2x1_ASAP7_75t_R   g115(.A(p59), .B(p29), .Y(new_n206_));
  OAI21x1_ASAP7_75t_R  g116(.A1(new_n204_), .A2(new_n205_), .B(new_n206_), .Y(new_n207_));
  OAI21x1_ASAP7_75t_R  g117(.A1(new_n153_), .A2(new_n165_), .B(new_n166_), .Y(new_n208_));
  INVx1_ASAP7_75t_R    g118(.A(new_n162_), .Y(new_n209_));
  AOI21x1_ASAP7_75t_R  g119(.A1(new_n158_), .A2(new_n208_), .B(new_n209_), .Y(new_n210_));
  OAI21x1_ASAP7_75t_R  g120(.A1(new_n203_), .A2(new_n207_), .B(new_n210_), .Y(new_n211_));
  OAI21x1_ASAP7_75t_R  g121(.A1(new_n163_), .A2(new_n186_), .B(new_n211_), .Y(new_n212_));
  NOR3x1_ASAP7_75t_R   g122(.A(new_n124_), .B(new_n122_), .C(new_n92_), .Y(new_n213_));
  AOI21x1_ASAP7_75t_R  g123(.A1(new_n146_), .A2(new_n212_), .B(new_n213_), .Y(o1));
  NOR3x1_ASAP7_75t_R   g124(.A(new_n130_), .B(new_n131_), .C(new_n133_), .Y(new_n215_));
  NAND3x1_ASAP7_75t_R  g125(.A(new_n215_), .B(new_n135_), .C(new_n138_), .Y(new_n216_));
  OR5x1_ASAP7_75t_R    g126(.A(new_n127_), .B(new_n216_), .C(new_n126_), .D(new_n142_), .E(new_n144_), .Y(new_n217_));
  AND2x2_ASAP7_75t_R   g127(.A(p59), .B(p29), .Y(new_n218_));
  INVx1_ASAP7_75t_R    g128(.A(p40), .Y(new_n219_));
  OA21x2_ASAP7_75t_R   g129(.A1(new_n187_), .A2(new_n219_), .B(new_n176_), .Y(new_n220_));
  NAND2x1_ASAP7_75t_R  g130(.A(new_n187_), .B(new_n219_), .Y(new_n221_));
  INVx1_ASAP7_75t_R    g131(.A(new_n172_), .Y(new_n222_));
  NOR2x1_ASAP7_75t_R   g132(.A(p55), .B(p50), .Y(new_n223_));
  AND3x1_ASAP7_75t_R   g133(.A(new_n223_), .B(new_n192_), .C(p38), .Y(new_n224_));
  AND5x1_ASAP7_75t_R   g134(.A(new_n189_), .B(new_n220_), .C(new_n221_), .D(new_n222_), .E(new_n224_), .Y(new_n225_));
  NOR2x1_ASAP7_75t_R   g135(.A(p31), .B(p30), .Y(new_n226_));
  INVx1_ASAP7_75t_R    g136(.A(p35), .Y(new_n227_));
  AND3x1_ASAP7_75t_R   g137(.A(new_n226_), .B(new_n227_), .C(p56), .Y(new_n228_));
  NOR2x1_ASAP7_75t_R   g138(.A(p34), .B(p32), .Y(new_n229_));
  AND3x1_ASAP7_75t_R   g139(.A(new_n229_), .B(new_n193_), .C(p40), .Y(new_n230_));
  NOR2x1_ASAP7_75t_R   g140(.A(p42), .B(p37), .Y(new_n231_));
  NOR2x1_ASAP7_75t_R   g141(.A(p45), .B(p33), .Y(new_n232_));
  AND5x1_ASAP7_75t_R   g142(.A(new_n228_), .B(new_n230_), .C(new_n231_), .D(new_n232_), .E(new_n174_), .Y(new_n233_));
  OAI21x1_ASAP7_75t_R  g143(.A1(p45), .A2(new_n152_), .B(new_n164_), .Y(new_n234_));
  NAND3x1_ASAP7_75t_R  g144(.A(new_n225_), .B(new_n233_), .C(new_n234_), .Y(new_n235_));
  OAI21x1_ASAP7_75t_R  g145(.A1(new_n218_), .A2(new_n235_), .B(new_n210_), .Y(new_n236_));
  AOI211x1_ASAP7_75t_R g146(.A1(new_n107_), .A2(new_n217_), .B(new_n236_), .C(new_n213_), .Y(o2));
  assign               o3 = 1'b0;
  assign               o4 = 1'b0;
  assign               o5 = 1'b0;
  assign               o6 = 1'b0;
  assign               o7 = 1'b0;
  assign               o8 = 1'b0;
  assign               o9 = 1'b0;
  assign               o10 = 1'b0;
  assign               o11 = 1'b0;
  assign               o12 = 1'b0;
  assign               o13 = 1'b0;
  assign               o14 = 1'b0;
  assign               o15 = 1'b0;
  assign               o16 = 1'b0;
  assign               o17 = 1'b0;
  assign               o18 = 1'b0;
  assign               o19 = 1'b0;
  assign               o20 = 1'b0;
  assign               o21 = 1'b0;
  assign               o22 = 1'b0;
  assign               o23 = 1'b0;
  assign               o24 = 1'b0;
  assign               o25 = 1'b0;
  assign               o26 = 1'b0;
  assign               o27 = 1'b0;
  assign               o28 = 1'b0;
  assign               o29 = 1'b0;
endmodule


