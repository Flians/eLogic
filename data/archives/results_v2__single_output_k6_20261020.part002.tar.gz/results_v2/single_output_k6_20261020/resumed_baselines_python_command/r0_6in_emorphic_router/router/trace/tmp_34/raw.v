// Benchmark "/tmp/" written by ABC on Tue Oct 20 18:11:48 2026

module \/tmp/  ( 
    p16, p8, p2, p10, p32, p35, p19, p56, p20, p29, p46, p5, p48, p25, p40,
    p45, p43, p14, p51, p26, p6, p4, p37, p11, p9, p42, p27, p13, p49, p23,
    p58, p31, p22, p36, p54, p28, p47, p15, p3, p57, p12, p30, p33, p17,
    p39, p24, p18, p7, p1, p38, p59, p21, p44, p55, p50, p0, p34, p53, p52,
    p41,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25, o26, o27, o28, o29  );
  input  p16, p8, p2, p10, p32, p35, p19, p56, p20, p29, p46, p5, p48,
    p25, p40, p45, p43, p14, p51, p26, p6, p4, p37, p11, p9, p42, p27, p13,
    p49, p23, p58, p31, p22, p36, p54, p28, p47, p15, p3, p57, p12, p30,
    p33, p17, p39, p24, p18, p7, p1, p38, p59, p21, p44, p55, p50, p0, p34,
    p53, p52, p41;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25, o26, o27, o28, o29;
  wire new_n91_, new_n92_, new_n93_, new_n94_, new_n95_, new_n96_, new_n97_,
    new_n98_, new_n99_, new_n100_, new_n101_, new_n102_, new_n103_,
    new_n104_, new_n105_, new_n106_, new_n107_, new_n108_, new_n109_,
    new_n110_, new_n111_, new_n112_, new_n113_, new_n114_, new_n115_,
    new_n116_, new_n117_, new_n118_, new_n119_, new_n120_, new_n121_,
    new_n122_, new_n123_, new_n124_, new_n125_, new_n126_, new_n127_,
    new_n128_, new_n129_, new_n130_, new_n131_, new_n132_, new_n133_,
    new_n134_, new_n135_, new_n136_, new_n137_, new_n138_, new_n139_,
    new_n140_, new_n141_, new_n142_, new_n143_, new_n144_, new_n145_,
    new_n146_, new_n147_, new_n149_, new_n150_, new_n151_, new_n152_,
    new_n153_, new_n154_, new_n155_, new_n156_, new_n157_, new_n158_,
    new_n159_, new_n160_, new_n161_, new_n162_, new_n163_, new_n164_,
    new_n165_, new_n166_, new_n167_, new_n168_, new_n169_, new_n170_,
    new_n171_, new_n172_, new_n173_, new_n174_, new_n175_, new_n176_,
    new_n177_, new_n178_, new_n179_, new_n180_, new_n181_, new_n182_,
    new_n183_, new_n184_, new_n185_, new_n186_, new_n187_, new_n188_,
    new_n189_, new_n190_, new_n191_, new_n192_, new_n193_, new_n194_,
    new_n195_, new_n196_, new_n197_, new_n198_, new_n199_, new_n200_,
    new_n201_, new_n202_, new_n203_, new_n204_, new_n205_, new_n206_,
    new_n207_, new_n208_, new_n209_, new_n211_, new_n212_, new_n213_;
  AND3x1_ASAP7_75t_R   g000(.A(p26), .B(p27), .C(p28), .Y(new_n91_));
  INVx1_ASAP7_75t_R    g001(.A(new_n91_), .Y(new_n92_));
  AND2x2_ASAP7_75t_R   g002(.A(p23), .B(p24), .Y(new_n93_));
  INVx1_ASAP7_75t_R    g003(.A(new_n93_), .Y(new_n94_));
  OAI21x1_ASAP7_75t_R  g004(.A1(p8), .A2(p9), .B(p10), .Y(new_n95_));
  NOR2x1_ASAP7_75t_R   g005(.A(p11), .B(p12), .Y(new_n96_));
  INVx1_ASAP7_75t_R    g006(.A(p16), .Y(new_n97_));
  NAND2x1_ASAP7_75t_R  g007(.A(p14), .B(p13), .Y(new_n98_));
  AO211x2_ASAP7_75t_R  g008(.A1(new_n95_), .A2(new_n96_), .B(new_n97_), .C(new_n98_), .Y(new_n99_));
  NOR2x1_ASAP7_75t_R   g009(.A(p20), .B(p21), .Y(new_n100_));
  AO21x1_ASAP7_75t_R   g010(.A1(p16), .A2(p15), .B(p17), .Y(new_n101_));
  INVx1_ASAP7_75t_R    g011(.A(new_n101_), .Y(new_n102_));
  NAND2x1_ASAP7_75t_R  g012(.A(p19), .B(p18), .Y(new_n103_));
  INVx1_ASAP7_75t_R    g013(.A(p22), .Y(new_n104_));
  AOI21x1_ASAP7_75t_R  g014(.A1(new_n103_), .A2(new_n100_), .B(new_n104_), .Y(new_n105_));
  INVx1_ASAP7_75t_R    g015(.A(new_n105_), .Y(new_n106_));
  AO31x2_ASAP7_75t_R   g016(.A1(new_n99_), .A2(new_n100_), .A3(new_n102_), .B(new_n106_), .Y(new_n107_));
  NAND2x1_ASAP7_75t_R  g017(.A(p25), .B(new_n91_), .Y(new_n108_));
  OA31x2_ASAP7_75t_R   g018(.A1(new_n92_), .A2(new_n94_), .A3(new_n107_), .B1(new_n108_), .Y(new_n109_));
  INVx1_ASAP7_75t_R    g019(.A(p15), .Y(new_n110_));
  OAI21x1_ASAP7_75t_R  g020(.A1(new_n97_), .A2(new_n110_), .B(new_n99_), .Y(new_n111_));
  NOR3x1_ASAP7_75t_R   g021(.A(p7), .B(p1), .C(p0), .Y(new_n112_));
  AND2x2_ASAP7_75t_R   g022(.A(p19), .B(p22), .Y(new_n113_));
  AND3x1_ASAP7_75t_R   g023(.A(new_n112_), .B(new_n113_), .C(new_n100_), .Y(new_n114_));
  INVx1_ASAP7_75t_R    g024(.A(p10), .Y(new_n115_));
  NAND2x1_ASAP7_75t_R  g025(.A(p11), .B(new_n115_), .Y(new_n116_));
  OA21x2_ASAP7_75t_R   g026(.A1(p8), .A2(p9), .B(p11), .Y(new_n117_));
  AOI21x1_ASAP7_75t_R  g027(.A1(new_n95_), .A2(new_n116_), .B(new_n117_), .Y(new_n118_));
  OR4x2_ASAP7_75t_R    g028(.A(p6), .B(p4), .C(p9), .D(p15), .Y(new_n119_));
  INVx1_ASAP7_75t_R    g029(.A(p18), .Y(new_n120_));
  OR4x2_ASAP7_75t_R    g030(.A(new_n120_), .B(p3), .C(p12), .D(p17), .Y(new_n121_));
  NOR2x1_ASAP7_75t_R   g031(.A(new_n119_), .B(new_n121_), .Y(new_n122_));
  INVx1_ASAP7_75t_R    g032(.A(new_n98_), .Y(new_n123_));
  INVx1_ASAP7_75t_R    g033(.A(p2), .Y(new_n124_));
  NOR2x1_ASAP7_75t_R   g034(.A(p5), .B(p25), .Y(new_n125_));
  AND5x1_ASAP7_75t_R   g035(.A(p8), .B(new_n123_), .C(new_n124_), .D(new_n93_), .E(new_n125_), .Y(new_n126_));
  AND5x1_ASAP7_75t_R   g036(.A(new_n111_), .B(new_n114_), .C(new_n118_), .D(new_n122_), .E(new_n126_), .Y(new_n127_));
  INVx1_ASAP7_75t_R    g037(.A(new_n100_), .Y(new_n128_));
  AOI211x1_ASAP7_75t_R g038(.A1(new_n96_), .A2(new_n95_), .B(new_n97_), .C(new_n98_), .Y(new_n129_));
  OA31x2_ASAP7_75t_R   g039(.A1(new_n128_), .A2(new_n101_), .A3(new_n129_), .B1(new_n105_), .Y(new_n130_));
  AOI21x1_ASAP7_75t_R  g040(.A1(new_n93_), .A2(new_n130_), .B(p25), .Y(new_n131_));
  NAND2x1_ASAP7_75t_R  g041(.A(new_n102_), .B(new_n99_), .Y(new_n132_));
  AND3x1_ASAP7_75t_R   g042(.A(new_n91_), .B(new_n113_), .C(new_n100_), .Y(new_n133_));
  AND2x2_ASAP7_75t_R   g043(.A(p59), .B(p0), .Y(new_n134_));
  AND3x1_ASAP7_75t_R   g044(.A(new_n134_), .B(p7), .C(p1), .Y(new_n135_));
  AND2x2_ASAP7_75t_R   g045(.A(p24), .B(p18), .Y(new_n136_));
  AND3x1_ASAP7_75t_R   g046(.A(new_n136_), .B(new_n110_), .C(p3), .Y(new_n137_));
  NAND3x1_ASAP7_75t_R  g047(.A(new_n133_), .B(new_n135_), .C(new_n137_), .Y(new_n138_));
  AOI21x1_ASAP7_75t_R  g048(.A1(p22), .A2(new_n128_), .B(p23), .Y(new_n139_));
  NOR2x1_ASAP7_75t_R   g049(.A(p16), .B(p15), .Y(new_n140_));
  OR5x1_ASAP7_75t_R    g050(.A(p8), .B(new_n140_), .C(p11), .D(p9), .E(p12), .Y(new_n141_));
  INVx1_ASAP7_75t_R    g051(.A(p5), .Y(new_n142_));
  NAND2x1_ASAP7_75t_R  g052(.A(p6), .B(p4), .Y(new_n143_));
  NAND2x1_ASAP7_75t_R  g053(.A(p2), .B(p10), .Y(new_n144_));
  OR5x1_ASAP7_75t_R    g054(.A(new_n142_), .B(new_n98_), .C(new_n143_), .D(new_n144_), .E(p25), .Y(new_n145_));
  OR5x1_ASAP7_75t_R    g055(.A(new_n132_), .B(new_n138_), .C(new_n139_), .D(new_n141_), .E(new_n145_), .Y(new_n146_));
  OAI21x1_ASAP7_75t_R  g056(.A1(new_n92_), .A2(new_n131_), .B(new_n146_), .Y(new_n147_));
  OAI21x1_ASAP7_75t_R  g057(.A1(new_n109_), .A2(new_n127_), .B(new_n147_), .Y(o0));
  AND3x1_ASAP7_75t_R   g058(.A(p54), .B(p53), .C(p52), .Y(new_n149_));
  AND3x1_ASAP7_75t_R   g059(.A(p56), .B(p58), .C(p57), .Y(new_n150_));
  OA21x2_ASAP7_75t_R   g060(.A1(p55), .A2(new_n149_), .B(new_n150_), .Y(new_n151_));
  INVx1_ASAP7_75t_R    g061(.A(p51), .Y(new_n152_));
  INVx1_ASAP7_75t_R    g062(.A(p55), .Y(new_n153_));
  INVx1_ASAP7_75t_R    g063(.A(p50), .Y(new_n154_));
  AND3x1_ASAP7_75t_R   g064(.A(new_n152_), .B(new_n153_), .C(new_n154_), .Y(new_n155_));
  INVx1_ASAP7_75t_R    g065(.A(p45), .Y(new_n156_));
  INVx1_ASAP7_75t_R    g066(.A(p47), .Y(new_n157_));
  NAND2x1_ASAP7_75t_R  g067(.A(new_n156_), .B(new_n157_), .Y(new_n158_));
  NOR2x1_ASAP7_75t_R   g068(.A(p42), .B(p41), .Y(new_n159_));
  OAI21x1_ASAP7_75t_R  g069(.A1(p39), .A2(p38), .B(p40), .Y(new_n160_));
  NAND2x1_ASAP7_75t_R  g070(.A(p43), .B(p44), .Y(new_n161_));
  AOI21x1_ASAP7_75t_R  g071(.A1(new_n159_), .A2(new_n160_), .B(new_n161_), .Y(new_n162_));
  INVx1_ASAP7_75t_R    g072(.A(p46), .Y(new_n163_));
  NAND2x1_ASAP7_75t_R  g073(.A(p48), .B(p49), .Y(new_n164_));
  AOI21x1_ASAP7_75t_R  g074(.A1(new_n163_), .A2(new_n157_), .B(new_n164_), .Y(new_n165_));
  OAI21x1_ASAP7_75t_R  g075(.A1(new_n158_), .A2(new_n162_), .B(new_n165_), .Y(new_n166_));
  NAND2x1_ASAP7_75t_R  g076(.A(new_n155_), .B(new_n166_), .Y(new_n167_));
  NOR2x1_ASAP7_75t_R   g077(.A(p59), .B(p50), .Y(new_n168_));
  AOI21x1_ASAP7_75t_R  g078(.A1(new_n151_), .A2(new_n167_), .B(new_n168_), .Y(new_n169_));
  NAND2x1_ASAP7_75t_R  g079(.A(p52), .B(new_n152_), .Y(new_n170_));
  NAND2x1_ASAP7_75t_R  g080(.A(new_n170_), .B(new_n166_), .Y(new_n171_));
  NOR2x1_ASAP7_75t_R   g081(.A(p39), .B(p38), .Y(new_n172_));
  AND3x1_ASAP7_75t_R   g082(.A(new_n172_), .B(p54), .C(p53), .Y(new_n173_));
  OA211x2_ASAP7_75t_R  g083(.A1(p48), .A2(p47), .B(p35), .C(p29), .Y(new_n174_));
  AND3x1_ASAP7_75t_R   g084(.A(new_n153_), .B(p36), .C(p30), .Y(new_n175_));
  AND4x2_ASAP7_75t_R   g085(.A(p31), .B(p33), .C(p44), .D(p34), .Y(new_n176_));
  AND5x1_ASAP7_75t_R   g086(.A(new_n173_), .B(new_n150_), .C(new_n174_), .D(new_n175_), .E(new_n176_), .Y(new_n177_));
  INVx1_ASAP7_75t_R    g087(.A(p43), .Y(new_n178_));
  AO21x1_ASAP7_75t_R   g088(.A1(new_n159_), .A2(new_n160_), .B(new_n178_), .Y(new_n179_));
  NAND2x1_ASAP7_75t_R  g089(.A(p42), .B(p41), .Y(new_n180_));
  OAI21x1_ASAP7_75t_R  g090(.A1(new_n180_), .A2(new_n160_), .B(new_n178_), .Y(new_n181_));
  NAND2x1_ASAP7_75t_R  g091(.A(p46), .B(p45), .Y(new_n182_));
  AO21x1_ASAP7_75t_R   g092(.A1(p46), .A2(p45), .B(p47), .Y(new_n183_));
  OAI21x1_ASAP7_75t_R  g093(.A1(p48), .A2(new_n182_), .B(new_n183_), .Y(new_n184_));
  AND4x2_ASAP7_75t_R   g094(.A(new_n156_), .B(p40), .C(p37), .D(p49), .Y(new_n185_));
  AND2x2_ASAP7_75t_R   g095(.A(p32), .B(p46), .Y(new_n186_));
  AND5x1_ASAP7_75t_R   g096(.A(new_n179_), .B(new_n181_), .C(new_n184_), .D(new_n185_), .E(new_n186_), .Y(new_n187_));
  NAND3x1_ASAP7_75t_R  g097(.A(new_n171_), .B(new_n177_), .C(new_n187_), .Y(new_n188_));
  INVx1_ASAP7_75t_R    g098(.A(new_n151_), .Y(new_n189_));
  AO21x1_ASAP7_75t_R   g099(.A1(new_n155_), .A2(new_n166_), .B(new_n189_), .Y(new_n190_));
  NOR2x1_ASAP7_75t_R   g100(.A(p29), .B(p59), .Y(new_n191_));
  NOR2x1_ASAP7_75t_R   g101(.A(new_n161_), .B(new_n164_), .Y(new_n192_));
  NAND2x1_ASAP7_75t_R  g102(.A(p56), .B(p40), .Y(new_n193_));
  NOR3x1_ASAP7_75t_R   g103(.A(new_n193_), .B(p32), .C(p35), .Y(new_n194_));
  AOI211x1_ASAP7_75t_R g104(.A1(p46), .A2(p47), .B(p55), .C(p50), .Y(new_n195_));
  NOR2x1_ASAP7_75t_R   g105(.A(p37), .B(p42), .Y(new_n196_));
  NOR2x1_ASAP7_75t_R   g106(.A(p45), .B(p51), .Y(new_n197_));
  AND5x1_ASAP7_75t_R   g107(.A(new_n192_), .B(new_n194_), .C(new_n195_), .D(new_n196_), .E(new_n197_), .Y(new_n198_));
  OAI21x1_ASAP7_75t_R  g108(.A1(p45), .A2(new_n162_), .B(new_n163_), .Y(new_n199_));
  INVx1_ASAP7_75t_R    g109(.A(p34), .Y(new_n200_));
  INVx1_ASAP7_75t_R    g110(.A(p38), .Y(new_n201_));
  NOR2x1_ASAP7_75t_R   g111(.A(p39), .B(new_n201_), .Y(new_n202_));
  NOR2x1_ASAP7_75t_R   g112(.A(p30), .B(p33), .Y(new_n203_));
  NOR2x1_ASAP7_75t_R   g113(.A(p31), .B(p36), .Y(new_n204_));
  AND5x1_ASAP7_75t_R   g114(.A(new_n200_), .B(new_n202_), .C(new_n149_), .D(new_n203_), .E(new_n204_), .Y(new_n205_));
  XNOR2x2_ASAP7_75t_R  g115(.A(p41), .B(new_n160_), .Y(new_n206_));
  AND5x1_ASAP7_75t_R   g116(.A(new_n191_), .B(new_n198_), .C(new_n199_), .D(new_n205_), .E(new_n206_), .Y(new_n207_));
  OAI22x1_ASAP7_75t_R  g117(.A1(new_n169_), .A2(new_n188_), .B1(new_n190_), .B2(new_n207_), .Y(new_n208_));
  NOR3x1_ASAP7_75t_R   g118(.A(new_n131_), .B(new_n127_), .C(new_n92_), .Y(new_n209_));
  AOI21x1_ASAP7_75t_R  g119(.A1(new_n147_), .A2(new_n208_), .B(new_n209_), .Y(o1));
  NAND2x1_ASAP7_75t_R  g120(.A(p29), .B(p59), .Y(new_n211_));
  AND4x2_ASAP7_75t_R   g121(.A(new_n198_), .B(new_n199_), .C(new_n205_), .D(new_n206_), .Y(new_n212_));
  AO21x1_ASAP7_75t_R   g122(.A1(new_n211_), .A2(new_n212_), .B(new_n190_), .Y(new_n213_));
  AOI211x1_ASAP7_75t_R g123(.A1(new_n146_), .A2(new_n109_), .B(new_n213_), .C(new_n209_), .Y(o2));
  assign               o3 = 1'b0;
  assign               o4 = 1'b0;
  assign               o5 = 1'b0;
  assign               o6 = 1'b0;
  assign               o7 = 1'b0;
  assign               o8 = 1'b0;
  assign               o9 = 1'b0;
  assign               o10 = 1'b0;
  assign               o11 = 1'b0;
  assign               o12 = 1'b0;
  assign               o13 = 1'b0;
  assign               o14 = 1'b0;
  assign               o15 = 1'b0;
  assign               o16 = 1'b0;
  assign               o17 = 1'b0;
  assign               o18 = 1'b0;
  assign               o19 = 1'b0;
  assign               o20 = 1'b0;
  assign               o21 = 1'b0;
  assign               o22 = 1'b0;
  assign               o23 = 1'b0;
  assign               o24 = 1'b0;
  assign               o25 = 1'b0;
  assign               o26 = 1'b0;
  assign               o27 = 1'b0;
  assign               o28 = 1'b0;
  assign               o29 = 1'b0;
endmodule


