// Benchmark "/tmp/" written by ABC on Tue Oct 20 18:11:49 2026

module \/tmp/  ( 
    p43, p30, p35, p19, p28, p37, p5, p58, p36, p39, p59, p34, p44, p56,
    p9, p17, p31, p40, p14, p26, p49, p6, p3, p52, p47, p18, p10, p11, p55,
    p33, p21, p45, p25, p32, p22, p51, p46, p53, p2, p4, p27, p8, p48, p16,
    p1, p42, p13, p20, p54, p0, p41, p7, p23, p29, p38, p15, p57, p24, p50,
    p12,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25, o26, o27, o28, o29  );
  input  p43, p30, p35, p19, p28, p37, p5, p58, p36, p39, p59, p34, p44,
    p56, p9, p17, p31, p40, p14, p26, p49, p6, p3, p52, p47, p18, p10, p11,
    p55, p33, p21, p45, p25, p32, p22, p51, p46, p53, p2, p4, p27, p8, p48,
    p16, p1, p42, p13, p20, p54, p0, p41, p7, p23, p29, p38, p15, p57, p24,
    p50, p12;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25, o26, o27, o28, o29;
  wire new_n91_, new_n92_, new_n93_, new_n94_, new_n95_, new_n96_, new_n97_,
    new_n98_, new_n99_, new_n100_, new_n101_, new_n102_, new_n103_,
    new_n104_, new_n105_, new_n106_, new_n107_, new_n108_, new_n109_,
    new_n110_, new_n111_, new_n112_, new_n113_, new_n114_, new_n115_,
    new_n116_, new_n117_, new_n118_, new_n119_, new_n120_, new_n121_,
    new_n122_, new_n123_, new_n124_, new_n125_, new_n126_, new_n127_,
    new_n128_, new_n129_, new_n130_, new_n131_, new_n132_, new_n133_,
    new_n134_, new_n135_, new_n136_, new_n137_, new_n138_, new_n139_,
    new_n140_, new_n142_, new_n143_, new_n144_, new_n145_, new_n146_,
    new_n147_, new_n148_, new_n149_, new_n150_, new_n151_, new_n152_,
    new_n153_, new_n154_, new_n155_, new_n156_, new_n157_, new_n158_,
    new_n159_, new_n160_, new_n161_, new_n162_, new_n163_, new_n164_,
    new_n165_, new_n166_, new_n167_, new_n168_, new_n169_, new_n170_,
    new_n171_, new_n172_, new_n173_, new_n174_, new_n175_, new_n176_,
    new_n177_, new_n178_, new_n179_, new_n180_, new_n181_, new_n182_,
    new_n183_, new_n184_, new_n185_, new_n186_, new_n187_, new_n188_,
    new_n189_, new_n190_, new_n191_, new_n192_, new_n193_, new_n194_,
    new_n195_, new_n196_, new_n197_, new_n198_, new_n199_, new_n200_,
    new_n201_, new_n202_, new_n203_, new_n204_, new_n205_, new_n206_,
    new_n207_, new_n208_, new_n209_, new_n210_, new_n211_, new_n212_,
    new_n214_, new_n215_, new_n216_, new_n217_, new_n218_, new_n219_,
    new_n220_, new_n221_, new_n222_, new_n223_, new_n224_, new_n225_,
    new_n226_, new_n227_, new_n228_, new_n229_, new_n230_, new_n231_,
    new_n232_;
  AND3x1_ASAP7_75t_R   g000(.A(p28), .B(p26), .C(p27), .Y(new_n91_));
  INVx1_ASAP7_75t_R    g001(.A(new_n91_), .Y(new_n92_));
  AND2x2_ASAP7_75t_R   g002(.A(p23), .B(p24), .Y(new_n93_));
  INVx1_ASAP7_75t_R    g003(.A(new_n93_), .Y(new_n94_));
  NAND3x1_ASAP7_75t_R  g004(.A(p19), .B(p18), .C(p22), .Y(new_n95_));
  NOR2x1_ASAP7_75t_R   g005(.A(p11), .B(p12), .Y(new_n96_));
  OAI21x1_ASAP7_75t_R  g006(.A1(p9), .A2(p8), .B(p10), .Y(new_n97_));
  NAND2x1_ASAP7_75t_R  g007(.A(p14), .B(p13), .Y(new_n98_));
  AOI21x1_ASAP7_75t_R  g008(.A1(new_n96_), .A2(new_n97_), .B(new_n98_), .Y(new_n99_));
  AO21x1_ASAP7_75t_R   g009(.A1(p16), .A2(p15), .B(p17), .Y(new_n100_));
  AOI21x1_ASAP7_75t_R  g010(.A1(p16), .A2(new_n99_), .B(new_n100_), .Y(new_n101_));
  OAI21x1_ASAP7_75t_R  g011(.A1(p21), .A2(p20), .B(p22), .Y(new_n102_));
  OA21x2_ASAP7_75t_R   g012(.A1(new_n95_), .A2(new_n101_), .B(new_n102_), .Y(new_n103_));
  NAND2x1_ASAP7_75t_R  g013(.A(p25), .B(new_n91_), .Y(new_n104_));
  OA31x2_ASAP7_75t_R   g014(.A1(new_n92_), .A2(new_n94_), .A3(new_n103_), .B1(new_n104_), .Y(new_n105_));
  OA21x2_ASAP7_75t_R   g015(.A1(p15), .A2(new_n99_), .B(p16), .Y(new_n106_));
  INVx1_ASAP7_75t_R    g016(.A(p3), .Y(new_n107_));
  INVx1_ASAP7_75t_R    g017(.A(p8), .Y(new_n108_));
  NOR2x1_ASAP7_75t_R   g018(.A(p1), .B(new_n108_), .Y(new_n109_));
  NOR2x1_ASAP7_75t_R   g019(.A(p0), .B(p7), .Y(new_n110_));
  NOR2x1_ASAP7_75t_R   g020(.A(p2), .B(p4), .Y(new_n111_));
  AND5x1_ASAP7_75t_R   g021(.A(new_n107_), .B(new_n109_), .C(p18), .D(new_n110_), .E(new_n111_), .Y(new_n112_));
  NOR2x1_ASAP7_75t_R   g022(.A(p21), .B(p20), .Y(new_n113_));
  AND3x1_ASAP7_75t_R   g023(.A(new_n113_), .B(p19), .C(p22), .Y(new_n114_));
  INVx1_ASAP7_75t_R    g024(.A(p11), .Y(new_n115_));
  INVx1_ASAP7_75t_R    g025(.A(p25), .Y(new_n116_));
  INVx1_ASAP7_75t_R    g026(.A(p15), .Y(new_n117_));
  INVx1_ASAP7_75t_R    g027(.A(p12), .Y(new_n118_));
  AND5x1_ASAP7_75t_R   g028(.A(p10), .B(new_n115_), .C(new_n116_), .D(new_n117_), .E(new_n118_), .Y(new_n119_));
  OR4x2_ASAP7_75t_R    g029(.A(p5), .B(p9), .C(p17), .D(p6), .Y(new_n120_));
  NOR3x1_ASAP7_75t_R   g030(.A(new_n94_), .B(new_n120_), .C(new_n98_), .Y(new_n121_));
  AND5x1_ASAP7_75t_R   g031(.A(new_n106_), .B(new_n112_), .C(new_n114_), .D(new_n119_), .E(new_n121_), .Y(new_n122_));
  OAI21x1_ASAP7_75t_R  g032(.A1(new_n95_), .A2(new_n101_), .B(new_n102_), .Y(new_n123_));
  AOI21x1_ASAP7_75t_R  g033(.A1(new_n93_), .A2(new_n123_), .B(p25), .Y(new_n124_));
  NOR2x1_ASAP7_75t_R   g034(.A(p23), .B(new_n123_), .Y(new_n125_));
  AO21x1_ASAP7_75t_R   g035(.A1(p16), .A2(new_n99_), .B(new_n100_), .Y(new_n126_));
  NOR3x1_ASAP7_75t_R   g036(.A(new_n99_), .B(p16), .C(p15), .Y(new_n127_));
  AND3x1_ASAP7_75t_R   g037(.A(new_n117_), .B(p7), .C(p24), .Y(new_n128_));
  AND4x2_ASAP7_75t_R   g038(.A(p2), .B(p4), .C(p1), .D(p0), .Y(new_n129_));
  NAND3x1_ASAP7_75t_R  g039(.A(new_n114_), .B(new_n128_), .C(new_n129_), .Y(new_n130_));
  AND3x1_ASAP7_75t_R   g040(.A(new_n96_), .B(p14), .C(p13), .Y(new_n131_));
  NOR2x1_ASAP7_75t_R   g041(.A(p9), .B(p8), .Y(new_n132_));
  AND3x1_ASAP7_75t_R   g042(.A(new_n132_), .B(p10), .C(new_n116_), .Y(new_n133_));
  NAND2x1_ASAP7_75t_R  g043(.A(new_n131_), .B(new_n133_), .Y(new_n134_));
  AND4x2_ASAP7_75t_R   g044(.A(p26), .B(p6), .C(p3), .D(p18), .Y(new_n135_));
  AND2x2_ASAP7_75t_R   g045(.A(p28), .B(p27), .Y(new_n136_));
  AND2x2_ASAP7_75t_R   g046(.A(p5), .B(p59), .Y(new_n137_));
  NAND3x1_ASAP7_75t_R  g047(.A(new_n135_), .B(new_n136_), .C(new_n137_), .Y(new_n138_));
  OR5x1_ASAP7_75t_R    g048(.A(new_n126_), .B(new_n127_), .C(new_n130_), .D(new_n134_), .E(new_n138_), .Y(new_n139_));
  OAI22x1_ASAP7_75t_R  g049(.A1(new_n124_), .A2(new_n92_), .B1(new_n125_), .B2(new_n139_), .Y(new_n140_));
  OAI21x1_ASAP7_75t_R  g050(.A1(new_n105_), .A2(new_n122_), .B(new_n140_), .Y(o0));
  AND2x2_ASAP7_75t_R   g051(.A(p49), .B(p48), .Y(new_n142_));
  INVx1_ASAP7_75t_R    g052(.A(new_n142_), .Y(new_n143_));
  NOR2x1_ASAP7_75t_R   g053(.A(p42), .B(p41), .Y(new_n144_));
  OAI21x1_ASAP7_75t_R  g054(.A1(p39), .A2(p38), .B(p40), .Y(new_n145_));
  NAND2x1_ASAP7_75t_R  g055(.A(p43), .B(p44), .Y(new_n146_));
  AOI21x1_ASAP7_75t_R  g056(.A1(new_n144_), .A2(new_n145_), .B(new_n146_), .Y(new_n147_));
  AO21x1_ASAP7_75t_R   g057(.A1(p45), .A2(p46), .B(p47), .Y(new_n148_));
  AOI21x1_ASAP7_75t_R  g058(.A1(p46), .A2(new_n147_), .B(new_n148_), .Y(new_n149_));
  INVx1_ASAP7_75t_R    g059(.A(p55), .Y(new_n150_));
  INVx1_ASAP7_75t_R    g060(.A(p51), .Y(new_n151_));
  INVx1_ASAP7_75t_R    g061(.A(p50), .Y(new_n152_));
  AND3x1_ASAP7_75t_R   g062(.A(new_n150_), .B(new_n151_), .C(new_n152_), .Y(new_n153_));
  OAI21x1_ASAP7_75t_R  g063(.A1(new_n143_), .A2(new_n149_), .B(new_n153_), .Y(new_n154_));
  AND3x1_ASAP7_75t_R   g064(.A(p52), .B(p53), .C(p54), .Y(new_n155_));
  AND3x1_ASAP7_75t_R   g065(.A(p58), .B(p56), .C(p57), .Y(new_n156_));
  OA21x2_ASAP7_75t_R   g066(.A1(p55), .A2(new_n155_), .B(new_n156_), .Y(new_n157_));
  INVx1_ASAP7_75t_R    g067(.A(p59), .Y(new_n158_));
  AOI22x1_ASAP7_75t_R  g068(.A1(new_n154_), .A2(new_n157_), .B1(new_n158_), .B2(new_n152_), .Y(new_n159_));
  INVx1_ASAP7_75t_R    g069(.A(p46), .Y(new_n160_));
  AOI211x1_ASAP7_75t_R g070(.A1(new_n144_), .A2(new_n145_), .B(new_n160_), .C(new_n146_), .Y(new_n161_));
  NOR2x1_ASAP7_75t_R   g071(.A(p52), .B(new_n151_), .Y(new_n162_));
  OA211x2_ASAP7_75t_R  g072(.A1(new_n148_), .A2(new_n161_), .B(new_n142_), .C(new_n162_), .Y(new_n163_));
  NAND2x1_ASAP7_75t_R  g073(.A(new_n144_), .B(new_n145_), .Y(new_n164_));
  INVx1_ASAP7_75t_R    g074(.A(new_n146_), .Y(new_n165_));
  AO31x2_ASAP7_75t_R   g075(.A1(new_n164_), .A2(p46), .A3(new_n165_), .B(new_n148_), .Y(new_n166_));
  NAND2x1_ASAP7_75t_R  g076(.A(p52), .B(new_n151_), .Y(new_n167_));
  AOI21x1_ASAP7_75t_R  g077(.A1(new_n142_), .A2(new_n166_), .B(new_n167_), .Y(new_n168_));
  NAND2x1_ASAP7_75t_R  g078(.A(p42), .B(p41), .Y(new_n169_));
  INVx1_ASAP7_75t_R    g079(.A(p43), .Y(new_n170_));
  OAI21x1_ASAP7_75t_R  g080(.A1(new_n169_), .A2(new_n145_), .B(new_n170_), .Y(new_n171_));
  INVx1_ASAP7_75t_R    g081(.A(p47), .Y(new_n172_));
  AND3x1_ASAP7_75t_R   g082(.A(p32), .B(p46), .C(p29), .Y(new_n173_));
  AND2x2_ASAP7_75t_R   g083(.A(p31), .B(p40), .Y(new_n174_));
  AND5x1_ASAP7_75t_R   g084(.A(new_n172_), .B(new_n156_), .C(new_n173_), .D(new_n174_), .E(p33), .Y(new_n175_));
  AND2x2_ASAP7_75t_R   g085(.A(p34), .B(p44), .Y(new_n176_));
  AND2x2_ASAP7_75t_R   g086(.A(p30), .B(p35), .Y(new_n177_));
  NOR2x1_ASAP7_75t_R   g087(.A(p39), .B(p38), .Y(new_n178_));
  AND5x1_ASAP7_75t_R   g088(.A(p37), .B(new_n176_), .C(new_n177_), .D(p36), .E(new_n178_), .Y(new_n179_));
  INVx1_ASAP7_75t_R    g089(.A(p45), .Y(new_n180_));
  AND5x1_ASAP7_75t_R   g090(.A(new_n150_), .B(new_n142_), .C(new_n180_), .D(p53), .E(p54), .Y(new_n181_));
  AO21x1_ASAP7_75t_R   g091(.A1(new_n144_), .A2(new_n145_), .B(new_n170_), .Y(new_n182_));
  AND5x1_ASAP7_75t_R   g092(.A(new_n171_), .B(new_n175_), .C(new_n179_), .D(new_n181_), .E(new_n182_), .Y(new_n183_));
  OAI21x1_ASAP7_75t_R  g093(.A1(new_n163_), .A2(new_n168_), .B(new_n183_), .Y(new_n184_));
  INVx1_ASAP7_75t_R    g094(.A(p56), .Y(new_n185_));
  INVx1_ASAP7_75t_R    g095(.A(p40), .Y(new_n186_));
  OR4x2_ASAP7_75t_R    g096(.A(new_n185_), .B(new_n186_), .C(p39), .D(p55), .Y(new_n187_));
  INVx1_ASAP7_75t_R    g097(.A(p38), .Y(new_n188_));
  OR4x2_ASAP7_75t_R    g098(.A(new_n188_), .B(p45), .C(p42), .D(p50), .Y(new_n189_));
  OR3x1_ASAP7_75t_R    g099(.A(new_n146_), .B(p37), .C(p36), .Y(new_n190_));
  NOR3x1_ASAP7_75t_R   g100(.A(new_n187_), .B(new_n189_), .C(new_n190_), .Y(new_n191_));
  INVx1_ASAP7_75t_R    g101(.A(p41), .Y(new_n192_));
  NOR2x1_ASAP7_75t_R   g102(.A(new_n192_), .B(new_n145_), .Y(new_n193_));
  OR4x2_ASAP7_75t_R    g103(.A(p34), .B(p31), .C(p33), .D(p32), .Y(new_n194_));
  NOR3x1_ASAP7_75t_R   g104(.A(new_n193_), .B(new_n194_), .C(new_n167_), .Y(new_n195_));
  NAND2x1_ASAP7_75t_R  g105(.A(new_n192_), .B(new_n145_), .Y(new_n196_));
  AND2x2_ASAP7_75t_R   g106(.A(p53), .B(p54), .Y(new_n197_));
  NAND2x1_ASAP7_75t_R  g107(.A(p47), .B(p46), .Y(new_n198_));
  NOR2x1_ASAP7_75t_R   g108(.A(p30), .B(p35), .Y(new_n199_));
  AND5x1_ASAP7_75t_R   g109(.A(new_n196_), .B(new_n142_), .C(new_n197_), .D(new_n198_), .E(new_n199_), .Y(new_n200_));
  NAND3x1_ASAP7_75t_R  g110(.A(new_n191_), .B(new_n195_), .C(new_n200_), .Y(new_n201_));
  NAND2x1_ASAP7_75t_R  g111(.A(p47), .B(new_n180_), .Y(new_n202_));
  NOR2x1_ASAP7_75t_R   g112(.A(new_n202_), .B(new_n147_), .Y(new_n203_));
  OA21x2_ASAP7_75t_R   g113(.A1(p45), .A2(new_n147_), .B(p46), .Y(new_n204_));
  NOR2x1_ASAP7_75t_R   g114(.A(p59), .B(p29), .Y(new_n205_));
  OAI21x1_ASAP7_75t_R  g115(.A1(new_n203_), .A2(new_n204_), .B(new_n205_), .Y(new_n206_));
  OAI21x1_ASAP7_75t_R  g116(.A1(new_n148_), .A2(new_n161_), .B(new_n142_), .Y(new_n207_));
  INVx1_ASAP7_75t_R    g117(.A(new_n157_), .Y(new_n208_));
  AOI21x1_ASAP7_75t_R  g118(.A1(new_n153_), .A2(new_n207_), .B(new_n208_), .Y(new_n209_));
  OAI21x1_ASAP7_75t_R  g119(.A1(new_n201_), .A2(new_n206_), .B(new_n209_), .Y(new_n210_));
  OAI21x1_ASAP7_75t_R  g120(.A1(new_n159_), .A2(new_n184_), .B(new_n210_), .Y(new_n211_));
  NOR3x1_ASAP7_75t_R   g121(.A(new_n124_), .B(new_n92_), .C(new_n122_), .Y(new_n212_));
  AOI21x1_ASAP7_75t_R  g122(.A1(new_n140_), .A2(new_n211_), .B(new_n212_), .Y(o1));
  AND5x1_ASAP7_75t_R   g123(.A(new_n136_), .B(new_n131_), .C(new_n133_), .D(new_n135_), .E(new_n137_), .Y(new_n214_));
  OR3x1_ASAP7_75t_R    g124(.A(new_n99_), .B(p16), .C(p15), .Y(new_n215_));
  AND2x2_ASAP7_75t_R   g125(.A(new_n129_), .B(new_n128_), .Y(new_n216_));
  AND5x1_ASAP7_75t_R   g126(.A(new_n101_), .B(new_n214_), .C(new_n215_), .D(new_n114_), .E(new_n216_), .Y(new_n217_));
  OAI21x1_ASAP7_75t_R  g127(.A1(p23), .A2(new_n123_), .B(new_n217_), .Y(new_n218_));
  AND2x2_ASAP7_75t_R   g128(.A(p59), .B(p29), .Y(new_n219_));
  NOR2x1_ASAP7_75t_R   g129(.A(p45), .B(new_n147_), .Y(new_n220_));
  OAI22x1_ASAP7_75t_R  g130(.A1(new_n220_), .A2(new_n160_), .B1(new_n147_), .B2(new_n202_), .Y(new_n221_));
  AND3x1_ASAP7_75t_R   g131(.A(new_n142_), .B(p53), .C(p54), .Y(new_n222_));
  AND5x1_ASAP7_75t_R   g132(.A(p52), .B(new_n198_), .C(new_n150_), .D(new_n180_), .E(new_n151_), .Y(new_n223_));
  OR3x1_ASAP7_75t_R    g133(.A(new_n178_), .B(new_n186_), .C(new_n192_), .Y(new_n224_));
  AND3x1_ASAP7_75t_R   g134(.A(new_n199_), .B(p43), .C(p44), .Y(new_n225_));
  AND5x1_ASAP7_75t_R   g135(.A(new_n196_), .B(new_n222_), .C(new_n223_), .D(new_n224_), .E(new_n225_), .Y(new_n226_));
  OR4x2_ASAP7_75t_R    g136(.A(new_n185_), .B(new_n186_), .C(p31), .D(p33), .Y(new_n227_));
  OR4x2_ASAP7_75t_R    g137(.A(new_n188_), .B(p32), .C(p42), .D(p50), .Y(new_n228_));
  OR4x2_ASAP7_75t_R    g138(.A(p37), .B(p36), .C(p39), .D(p34), .Y(new_n229_));
  NOR3x1_ASAP7_75t_R   g139(.A(new_n227_), .B(new_n228_), .C(new_n229_), .Y(new_n230_));
  NAND3x1_ASAP7_75t_R  g140(.A(new_n221_), .B(new_n226_), .C(new_n230_), .Y(new_n231_));
  OAI21x1_ASAP7_75t_R  g141(.A1(new_n219_), .A2(new_n231_), .B(new_n209_), .Y(new_n232_));
  AOI211x1_ASAP7_75t_R g142(.A1(new_n105_), .A2(new_n218_), .B(new_n232_), .C(new_n212_), .Y(o2));
  assign               o3 = 1'b0;
  assign               o4 = 1'b0;
  assign               o5 = 1'b0;
  assign               o6 = 1'b0;
  assign               o7 = 1'b0;
  assign               o8 = 1'b0;
  assign               o9 = 1'b0;
  assign               o10 = 1'b0;
  assign               o11 = 1'b0;
  assign               o12 = 1'b0;
  assign               o13 = 1'b0;
  assign               o14 = 1'b0;
  assign               o15 = 1'b0;
  assign               o16 = 1'b0;
  assign               o17 = 1'b0;
  assign               o18 = 1'b0;
  assign               o19 = 1'b0;
  assign               o20 = 1'b0;
  assign               o21 = 1'b0;
  assign               o22 = 1'b0;
  assign               o23 = 1'b0;
  assign               o24 = 1'b0;
  assign               o25 = 1'b0;
  assign               o26 = 1'b0;
  assign               o27 = 1'b0;
  assign               o28 = 1'b0;
  assign               o29 = 1'b0;
endmodule


