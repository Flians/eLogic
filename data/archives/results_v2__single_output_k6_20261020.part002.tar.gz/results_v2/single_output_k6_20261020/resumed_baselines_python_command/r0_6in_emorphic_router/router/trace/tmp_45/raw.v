// Benchmark "/tmp/" written by ABC on Tue Oct 20 18:11:49 2026

module \/tmp/  ( 
    p25, p52, p32, p33, p4, p34, p37, p47, p8, p14, p45, p58, p24, p40,
    p17, p9, p55, p54, p43, p27, p49, p26, p2, p10, p11, p53, p6, p20, p28,
    p1, p59, p7, p50, p5, p13, p39, p0, p51, p48, p21, p12, p23, p22, p31,
    p41, p16, p38, p42, p36, p46, p30, p18, p44, p15, p29, p56, p57, p3,
    p35, p19,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25, o26, o27, o28, o29  );
  input  p25, p52, p32, p33, p4, p34, p37, p47, p8, p14, p45, p58, p24,
    p40, p17, p9, p55, p54, p43, p27, p49, p26, p2, p10, p11, p53, p6, p20,
    p28, p1, p59, p7, p50, p5, p13, p39, p0, p51, p48, p21, p12, p23, p22,
    p31, p41, p16, p38, p42, p36, p46, p30, p18, p44, p15, p29, p56, p57,
    p3, p35, p19;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25, o26, o27, o28, o29;
  wire new_n91_, new_n92_, new_n93_, new_n94_, new_n95_, new_n96_, new_n97_,
    new_n98_, new_n99_, new_n100_, new_n101_, new_n102_, new_n103_,
    new_n104_, new_n105_, new_n106_, new_n107_, new_n108_, new_n109_,
    new_n110_, new_n111_, new_n112_, new_n113_, new_n114_, new_n115_,
    new_n116_, new_n117_, new_n118_, new_n119_, new_n120_, new_n121_,
    new_n122_, new_n123_, new_n124_, new_n125_, new_n126_, new_n127_,
    new_n128_, new_n129_, new_n130_, new_n131_, new_n132_, new_n133_,
    new_n134_, new_n135_, new_n136_, new_n137_, new_n138_, new_n139_,
    new_n140_, new_n141_, new_n142_, new_n143_, new_n144_, new_n146_,
    new_n147_, new_n148_, new_n149_, new_n150_, new_n151_, new_n152_,
    new_n153_, new_n154_, new_n155_, new_n156_, new_n157_, new_n158_,
    new_n159_, new_n160_, new_n161_, new_n162_, new_n163_, new_n164_,
    new_n165_, new_n166_, new_n167_, new_n168_, new_n169_, new_n170_,
    new_n171_, new_n172_, new_n173_, new_n174_, new_n175_, new_n176_,
    new_n177_, new_n178_, new_n179_, new_n180_, new_n181_, new_n182_,
    new_n183_, new_n184_, new_n185_, new_n186_, new_n187_, new_n188_,
    new_n189_, new_n190_, new_n191_, new_n192_, new_n193_, new_n194_,
    new_n195_, new_n196_, new_n197_, new_n198_, new_n199_, new_n200_,
    new_n201_, new_n202_, new_n203_, new_n204_, new_n205_, new_n206_,
    new_n207_, new_n208_, new_n209_, new_n210_, new_n211_, new_n213_,
    new_n214_, new_n215_, new_n216_, new_n217_, new_n218_, new_n219_,
    new_n220_, new_n221_, new_n222_, new_n223_, new_n224_, new_n225_,
    new_n226_, new_n227_, new_n228_, new_n229_, new_n230_, new_n231_,
    new_n232_, new_n233_, new_n234_, new_n235_;
  NOR2x1_ASAP7_75t_R   g000(.A(p20), .B(p21), .Y(new_n91_));
  INVx1_ASAP7_75t_R    g001(.A(new_n91_), .Y(new_n92_));
  AO21x1_ASAP7_75t_R   g002(.A1(p22), .A2(new_n92_), .B(p23), .Y(new_n93_));
  AND3x1_ASAP7_75t_R   g003(.A(p27), .B(p26), .C(p28), .Y(new_n94_));
  INVx1_ASAP7_75t_R    g004(.A(p15), .Y(new_n95_));
  AND3x1_ASAP7_75t_R   g005(.A(new_n95_), .B(p18), .C(p3), .Y(new_n96_));
  AND2x2_ASAP7_75t_R   g006(.A(p22), .B(p19), .Y(new_n97_));
  AND4x2_ASAP7_75t_R   g007(.A(p24), .B(p5), .C(p0), .D(p16), .Y(new_n98_));
  AND5x1_ASAP7_75t_R   g008(.A(new_n94_), .B(new_n96_), .C(new_n91_), .D(new_n97_), .E(new_n98_), .Y(new_n99_));
  NOR2x1_ASAP7_75t_R   g009(.A(p11), .B(p12), .Y(new_n100_));
  OAI21x1_ASAP7_75t_R  g010(.A1(p8), .A2(p9), .B(p10), .Y(new_n101_));
  NAND2x1_ASAP7_75t_R  g011(.A(p14), .B(p13), .Y(new_n102_));
  AOI21x1_ASAP7_75t_R  g012(.A1(new_n100_), .A2(new_n101_), .B(new_n102_), .Y(new_n103_));
  AO21x1_ASAP7_75t_R   g013(.A1(p16), .A2(p15), .B(p17), .Y(new_n104_));
  AOI21x1_ASAP7_75t_R  g014(.A1(p16), .A2(new_n103_), .B(new_n104_), .Y(new_n105_));
  INVx1_ASAP7_75t_R    g015(.A(p4), .Y(new_n106_));
  NOR2x1_ASAP7_75t_R   g016(.A(p25), .B(new_n106_), .Y(new_n107_));
  AND4x2_ASAP7_75t_R   g017(.A(p6), .B(p1), .C(p59), .D(p7), .Y(new_n108_));
  AND4x2_ASAP7_75t_R   g018(.A(p14), .B(p2), .C(p10), .D(p13), .Y(new_n109_));
  NOR2x1_ASAP7_75t_R   g019(.A(p8), .B(p9), .Y(new_n110_));
  AND5x1_ASAP7_75t_R   g020(.A(new_n100_), .B(new_n107_), .C(new_n108_), .D(new_n109_), .E(new_n110_), .Y(new_n111_));
  AND3x1_ASAP7_75t_R   g021(.A(new_n99_), .B(new_n105_), .C(new_n111_), .Y(new_n112_));
  NAND2x1_ASAP7_75t_R  g022(.A(new_n93_), .B(new_n112_), .Y(new_n113_));
  AND2x2_ASAP7_75t_R   g023(.A(p18), .B(p19), .Y(new_n114_));
  OAI21x1_ASAP7_75t_R  g024(.A1(new_n114_), .A2(new_n92_), .B(p22), .Y(new_n115_));
  AOI21x1_ASAP7_75t_R  g025(.A1(new_n91_), .A2(new_n105_), .B(new_n115_), .Y(new_n116_));
  NAND2x1_ASAP7_75t_R  g026(.A(p24), .B(p23), .Y(new_n117_));
  INVx1_ASAP7_75t_R    g027(.A(new_n117_), .Y(new_n118_));
  NAND3x1_ASAP7_75t_R  g028(.A(new_n116_), .B(new_n94_), .C(new_n118_), .Y(new_n119_));
  AND2x2_ASAP7_75t_R   g029(.A(p25), .B(new_n94_), .Y(new_n120_));
  INVx1_ASAP7_75t_R    g030(.A(new_n120_), .Y(new_n121_));
  NAND3x1_ASAP7_75t_R  g031(.A(new_n113_), .B(new_n119_), .C(new_n121_), .Y(new_n122_));
  OA21x2_ASAP7_75t_R   g032(.A1(p15), .A2(new_n103_), .B(p16), .Y(new_n123_));
  NOR2x1_ASAP7_75t_R   g033(.A(p25), .B(p4), .Y(new_n124_));
  INVx1_ASAP7_75t_R    g034(.A(p17), .Y(new_n125_));
  AND3x1_ASAP7_75t_R   g035(.A(new_n124_), .B(p8), .C(new_n125_), .Y(new_n126_));
  NOR2x1_ASAP7_75t_R   g036(.A(p7), .B(p5), .Y(new_n127_));
  INVx1_ASAP7_75t_R    g037(.A(p0), .Y(new_n128_));
  AND3x1_ASAP7_75t_R   g038(.A(new_n127_), .B(p13), .C(new_n128_), .Y(new_n129_));
  NOR2x1_ASAP7_75t_R   g039(.A(p9), .B(p2), .Y(new_n130_));
  NOR2x1_ASAP7_75t_R   g040(.A(p6), .B(p1), .Y(new_n131_));
  AND5x1_ASAP7_75t_R   g041(.A(new_n118_), .B(new_n126_), .C(new_n129_), .D(new_n130_), .E(new_n131_), .Y(new_n132_));
  INVx1_ASAP7_75t_R    g042(.A(p14), .Y(new_n133_));
  INVx1_ASAP7_75t_R    g043(.A(p13), .Y(new_n134_));
  OR3x1_ASAP7_75t_R    g044(.A(new_n133_), .B(new_n134_), .C(new_n95_), .Y(new_n135_));
  NOR2x1_ASAP7_75t_R   g045(.A(p12), .B(p3), .Y(new_n136_));
  AND5x1_ASAP7_75t_R   g046(.A(p18), .B(new_n135_), .C(new_n91_), .D(new_n97_), .E(new_n136_), .Y(new_n137_));
  AO21x1_ASAP7_75t_R   g047(.A1(new_n100_), .A2(new_n101_), .B(new_n134_), .Y(new_n138_));
  AO21x1_ASAP7_75t_R   g048(.A1(new_n133_), .A2(new_n138_), .B(new_n103_), .Y(new_n139_));
  INVx1_ASAP7_75t_R    g049(.A(p11), .Y(new_n140_));
  OR4x2_ASAP7_75t_R    g050(.A(new_n140_), .B(p8), .C(p9), .D(p10), .Y(new_n141_));
  OAI21x1_ASAP7_75t_R  g051(.A1(p11), .A2(new_n101_), .B(new_n141_), .Y(new_n142_));
  AND5x1_ASAP7_75t_R   g052(.A(new_n123_), .B(new_n132_), .C(new_n137_), .D(new_n139_), .E(new_n142_), .Y(new_n143_));
  AO21x1_ASAP7_75t_R   g053(.A1(new_n121_), .A2(new_n119_), .B(new_n143_), .Y(new_n144_));
  NAND2x1_ASAP7_75t_R  g054(.A(new_n122_), .B(new_n144_), .Y(o0));
  AOI21x1_ASAP7_75t_R  g055(.A1(new_n121_), .A2(new_n119_), .B(new_n143_), .Y(new_n146_));
  AND2x2_ASAP7_75t_R   g056(.A(p49), .B(p48), .Y(new_n147_));
  INVx1_ASAP7_75t_R    g057(.A(new_n147_), .Y(new_n148_));
  NOR2x1_ASAP7_75t_R   g058(.A(p41), .B(p42), .Y(new_n149_));
  OAI21x1_ASAP7_75t_R  g059(.A1(p39), .A2(p38), .B(p40), .Y(new_n150_));
  NAND2x1_ASAP7_75t_R  g060(.A(p43), .B(p44), .Y(new_n151_));
  AOI21x1_ASAP7_75t_R  g061(.A1(new_n149_), .A2(new_n150_), .B(new_n151_), .Y(new_n152_));
  AO21x1_ASAP7_75t_R   g062(.A1(p45), .A2(p46), .B(p47), .Y(new_n153_));
  AOI21x1_ASAP7_75t_R  g063(.A1(p46), .A2(new_n152_), .B(new_n153_), .Y(new_n154_));
  INVx1_ASAP7_75t_R    g064(.A(p51), .Y(new_n155_));
  NAND2x1_ASAP7_75t_R  g065(.A(p52), .B(new_n155_), .Y(new_n156_));
  OAI21x1_ASAP7_75t_R  g066(.A1(new_n148_), .A2(new_n154_), .B(new_n156_), .Y(new_n157_));
  INVx1_ASAP7_75t_R    g067(.A(p43), .Y(new_n158_));
  AO21x1_ASAP7_75t_R   g068(.A1(new_n149_), .A2(new_n150_), .B(new_n158_), .Y(new_n159_));
  AND3x1_ASAP7_75t_R   g069(.A(p58), .B(p56), .C(p57), .Y(new_n160_));
  AND3x1_ASAP7_75t_R   g070(.A(p44), .B(p29), .C(p35), .Y(new_n161_));
  AND2x2_ASAP7_75t_R   g071(.A(p54), .B(p53), .Y(new_n162_));
  INVx1_ASAP7_75t_R    g072(.A(p55), .Y(new_n163_));
  AND5x1_ASAP7_75t_R   g073(.A(p40), .B(new_n160_), .C(new_n161_), .D(new_n162_), .E(new_n163_), .Y(new_n164_));
  NAND2x1_ASAP7_75t_R  g074(.A(p41), .B(p42), .Y(new_n165_));
  OAI21x1_ASAP7_75t_R  g075(.A1(new_n165_), .A2(new_n150_), .B(new_n158_), .Y(new_n166_));
  AND2x2_ASAP7_75t_R   g076(.A(p31), .B(p36), .Y(new_n167_));
  AND2x2_ASAP7_75t_R   g077(.A(p46), .B(p30), .Y(new_n168_));
  NOR2x1_ASAP7_75t_R   g078(.A(p47), .B(p45), .Y(new_n169_));
  AND4x2_ASAP7_75t_R   g079(.A(new_n147_), .B(new_n167_), .C(new_n168_), .D(new_n169_), .Y(new_n170_));
  NOR2x1_ASAP7_75t_R   g080(.A(p39), .B(p38), .Y(new_n171_));
  AND5x1_ASAP7_75t_R   g081(.A(p32), .B(new_n171_), .C(p33), .D(p34), .E(p37), .Y(new_n172_));
  AND5x1_ASAP7_75t_R   g082(.A(new_n159_), .B(new_n164_), .C(new_n166_), .D(new_n170_), .E(new_n172_), .Y(new_n173_));
  NAND2x1_ASAP7_75t_R  g083(.A(new_n157_), .B(new_n173_), .Y(new_n174_));
  AND3x1_ASAP7_75t_R   g084(.A(p52), .B(p54), .C(p53), .Y(new_n175_));
  OA21x2_ASAP7_75t_R   g085(.A1(p55), .A2(new_n175_), .B(new_n160_), .Y(new_n176_));
  INVx1_ASAP7_75t_R    g086(.A(p50), .Y(new_n177_));
  AND3x1_ASAP7_75t_R   g087(.A(new_n163_), .B(new_n177_), .C(new_n155_), .Y(new_n178_));
  OAI21x1_ASAP7_75t_R  g088(.A1(new_n148_), .A2(new_n154_), .B(new_n178_), .Y(new_n179_));
  NOR2x1_ASAP7_75t_R   g089(.A(p59), .B(p50), .Y(new_n180_));
  AOI21x1_ASAP7_75t_R  g090(.A1(new_n176_), .A2(new_n179_), .B(new_n180_), .Y(new_n181_));
  INVx1_ASAP7_75t_R    g091(.A(p40), .Y(new_n182_));
  OR4x2_ASAP7_75t_R    g092(.A(new_n182_), .B(p55), .C(p50), .D(p39), .Y(new_n183_));
  NAND2x1_ASAP7_75t_R  g093(.A(p38), .B(p56), .Y(new_n184_));
  OR3x1_ASAP7_75t_R    g094(.A(new_n184_), .B(p42), .C(p36), .Y(new_n185_));
  NOR2x1_ASAP7_75t_R   g095(.A(p37), .B(p45), .Y(new_n186_));
  NAND3x1_ASAP7_75t_R  g096(.A(new_n186_), .B(p43), .C(p44), .Y(new_n187_));
  NOR3x1_ASAP7_75t_R   g097(.A(new_n183_), .B(new_n185_), .C(new_n187_), .Y(new_n188_));
  INVx1_ASAP7_75t_R    g098(.A(p41), .Y(new_n189_));
  NOR2x1_ASAP7_75t_R   g099(.A(p32), .B(p33), .Y(new_n190_));
  NAND2x1_ASAP7_75t_R  g100(.A(new_n190_), .B(new_n162_), .Y(new_n191_));
  NAND2x1_ASAP7_75t_R  g101(.A(p47), .B(p46), .Y(new_n192_));
  NAND2x1_ASAP7_75t_R  g102(.A(new_n192_), .B(new_n147_), .Y(new_n193_));
  AOI211x1_ASAP7_75t_R g103(.A1(new_n189_), .A2(new_n150_), .B(new_n191_), .C(new_n193_), .Y(new_n194_));
  NOR2x1_ASAP7_75t_R   g104(.A(new_n189_), .B(new_n150_), .Y(new_n195_));
  OR4x2_ASAP7_75t_R    g105(.A(p34), .B(p31), .C(p30), .D(p35), .Y(new_n196_));
  NOR3x1_ASAP7_75t_R   g106(.A(new_n195_), .B(new_n196_), .C(new_n156_), .Y(new_n197_));
  NAND3x1_ASAP7_75t_R  g107(.A(new_n188_), .B(new_n194_), .C(new_n197_), .Y(new_n198_));
  INVx1_ASAP7_75t_R    g108(.A(p47), .Y(new_n199_));
  NOR3x1_ASAP7_75t_R   g109(.A(new_n152_), .B(new_n199_), .C(p45), .Y(new_n200_));
  AND2x2_ASAP7_75t_R   g110(.A(p45), .B(p46), .Y(new_n201_));
  AO21x1_ASAP7_75t_R   g111(.A1(p46), .A2(new_n152_), .B(new_n201_), .Y(new_n202_));
  NOR2x1_ASAP7_75t_R   g112(.A(p59), .B(p29), .Y(new_n203_));
  OAI21x1_ASAP7_75t_R  g113(.A1(new_n200_), .A2(new_n202_), .B(new_n203_), .Y(new_n204_));
  INVx1_ASAP7_75t_R    g114(.A(p46), .Y(new_n205_));
  AOI211x1_ASAP7_75t_R g115(.A1(new_n149_), .A2(new_n150_), .B(new_n205_), .C(new_n151_), .Y(new_n206_));
  OAI21x1_ASAP7_75t_R  g116(.A1(new_n153_), .A2(new_n206_), .B(new_n147_), .Y(new_n207_));
  INVx1_ASAP7_75t_R    g117(.A(new_n176_), .Y(new_n208_));
  AOI21x1_ASAP7_75t_R  g118(.A1(new_n178_), .A2(new_n207_), .B(new_n208_), .Y(new_n209_));
  OAI21x1_ASAP7_75t_R  g119(.A1(new_n198_), .A2(new_n204_), .B(new_n209_), .Y(new_n210_));
  OAI21x1_ASAP7_75t_R  g120(.A1(new_n174_), .A2(new_n181_), .B(new_n210_), .Y(new_n211_));
  OAI21x1_ASAP7_75t_R  g121(.A1(new_n146_), .A2(new_n211_), .B(new_n122_), .Y(o1));
  AND2x2_ASAP7_75t_R   g122(.A(p59), .B(p29), .Y(new_n213_));
  NOR2x1_ASAP7_75t_R   g123(.A(p45), .B(new_n152_), .Y(new_n214_));
  INVx1_ASAP7_75t_R    g124(.A(p45), .Y(new_n215_));
  NAND2x1_ASAP7_75t_R  g125(.A(p47), .B(new_n215_), .Y(new_n216_));
  OAI22x1_ASAP7_75t_R  g126(.A1(new_n214_), .A2(new_n205_), .B1(new_n152_), .B2(new_n216_), .Y(new_n217_));
  NAND2x1_ASAP7_75t_R  g127(.A(new_n189_), .B(new_n150_), .Y(new_n218_));
  AND5x1_ASAP7_75t_R   g128(.A(p52), .B(new_n192_), .C(p49), .D(new_n155_), .E(p48), .Y(new_n219_));
  OR3x1_ASAP7_75t_R    g129(.A(new_n171_), .B(new_n182_), .C(new_n189_), .Y(new_n220_));
  NOR2x1_ASAP7_75t_R   g130(.A(p34), .B(p37), .Y(new_n221_));
  AND3x1_ASAP7_75t_R   g131(.A(new_n221_), .B(new_n215_), .C(new_n177_), .Y(new_n222_));
  AND3x1_ASAP7_75t_R   g132(.A(new_n190_), .B(p43), .C(p44), .Y(new_n223_));
  AND5x1_ASAP7_75t_R   g133(.A(new_n218_), .B(new_n219_), .C(new_n220_), .D(new_n222_), .E(new_n223_), .Y(new_n224_));
  NOR2x1_ASAP7_75t_R   g134(.A(p36), .B(p30), .Y(new_n225_));
  INVx1_ASAP7_75t_R    g135(.A(p35), .Y(new_n226_));
  AND3x1_ASAP7_75t_R   g136(.A(new_n225_), .B(p56), .C(new_n226_), .Y(new_n227_));
  NOR2x1_ASAP7_75t_R   g137(.A(p39), .B(p31), .Y(new_n228_));
  INVx1_ASAP7_75t_R    g138(.A(p42), .Y(new_n229_));
  AND3x1_ASAP7_75t_R   g139(.A(new_n228_), .B(p38), .C(new_n229_), .Y(new_n230_));
  AND5x1_ASAP7_75t_R   g140(.A(p40), .B(new_n227_), .C(new_n230_), .D(new_n163_), .E(new_n162_), .Y(new_n231_));
  NAND3x1_ASAP7_75t_R  g141(.A(new_n217_), .B(new_n224_), .C(new_n231_), .Y(new_n232_));
  OAI21x1_ASAP7_75t_R  g142(.A1(new_n213_), .A2(new_n232_), .B(new_n209_), .Y(new_n233_));
  AOI211x1_ASAP7_75t_R g143(.A1(new_n91_), .A2(new_n105_), .B(new_n117_), .C(new_n115_), .Y(new_n234_));
  AOI221x1_ASAP7_75t_R g144(.A1(new_n234_), .A2(new_n94_), .B1(new_n93_), .B2(new_n112_), .C(new_n120_), .Y(new_n235_));
  NOR3x1_ASAP7_75t_R   g145(.A(new_n146_), .B(new_n233_), .C(new_n235_), .Y(o2));
  assign               o3 = 1'b0;
  assign               o4 = 1'b0;
  assign               o5 = 1'b0;
  assign               o6 = 1'b0;
  assign               o7 = 1'b0;
  assign               o8 = 1'b0;
  assign               o9 = 1'b0;
  assign               o10 = 1'b0;
  assign               o11 = 1'b0;
  assign               o12 = 1'b0;
  assign               o13 = 1'b0;
  assign               o14 = 1'b0;
  assign               o15 = 1'b0;
  assign               o16 = 1'b0;
  assign               o17 = 1'b0;
  assign               o18 = 1'b0;
  assign               o19 = 1'b0;
  assign               o20 = 1'b0;
  assign               o21 = 1'b0;
  assign               o22 = 1'b0;
  assign               o23 = 1'b0;
  assign               o24 = 1'b0;
  assign               o25 = 1'b0;
  assign               o26 = 1'b0;
  assign               o27 = 1'b0;
  assign               o28 = 1'b0;
  assign               o29 = 1'b0;
endmodule


