// Benchmark "/tmp/" written by ABC on Tue Oct 20 18:11:44 2026

module \/tmp/  ( 
    p53, p34, p8, p48, p49, p26, p36, p15, p13, p16, p38, p50, p22, p12,
    p5, p21, p27, p11, p51, p10, p52, p37, p20, p56, p57, p7, p32, p58,
    p44, p1, p29, p6, p35, p9, p42, p46, p24, p55, p45, p19, p31, p39, p30,
    p18, p2, p17, p23, p59, p54, p25, p0, p4, p43, p41, p14, p33, p47, p3,
    p40, p28,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25, o26, o27, o28, o29  );
  input  p53, p34, p8, p48, p49, p26, p36, p15, p13, p16, p38, p50, p22,
    p12, p5, p21, p27, p11, p51, p10, p52, p37, p20, p56, p57, p7, p32,
    p58, p44, p1, p29, p6, p35, p9, p42, p46, p24, p55, p45, p19, p31, p39,
    p30, p18, p2, p17, p23, p59, p54, p25, p0, p4, p43, p41, p14, p33, p47,
    p3, p40, p28;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25, o26, o27, o28, o29;
  wire new_n91_, new_n92_, new_n93_, new_n94_, new_n95_, new_n96_, new_n97_,
    new_n98_, new_n99_, new_n100_, new_n101_, new_n102_, new_n103_,
    new_n104_, new_n105_, new_n106_, new_n107_, new_n108_, new_n109_,
    new_n110_, new_n111_, new_n112_, new_n113_, new_n114_, new_n115_,
    new_n116_, new_n117_, new_n118_, new_n119_, new_n120_, new_n121_,
    new_n122_, new_n123_, new_n124_, new_n125_, new_n126_, new_n127_,
    new_n128_, new_n129_, new_n130_, new_n131_, new_n132_, new_n133_,
    new_n134_, new_n135_, new_n136_, new_n137_, new_n138_, new_n139_,
    new_n140_, new_n141_, new_n142_, new_n143_, new_n144_, new_n145_,
    new_n147_, new_n148_, new_n149_, new_n150_, new_n151_, new_n152_,
    new_n153_, new_n154_, new_n155_, new_n156_, new_n157_, new_n158_,
    new_n159_, new_n160_, new_n161_, new_n162_, new_n163_, new_n164_,
    new_n165_, new_n166_, new_n167_, new_n168_, new_n169_, new_n170_,
    new_n171_, new_n172_, new_n173_, new_n174_, new_n175_, new_n176_,
    new_n177_, new_n178_, new_n179_, new_n180_, new_n181_, new_n182_,
    new_n183_, new_n184_, new_n185_, new_n186_, new_n187_, new_n188_,
    new_n189_, new_n190_, new_n191_, new_n192_, new_n193_, new_n194_,
    new_n195_, new_n196_, new_n197_, new_n198_, new_n199_, new_n200_,
    new_n201_, new_n202_, new_n203_, new_n204_, new_n205_, new_n206_,
    new_n207_, new_n208_, new_n210_, new_n211_, new_n212_;
  NOR2x1_ASAP7_75t_R   g000(.A(p12), .B(p11), .Y(new_n91_));
  OAI21x1_ASAP7_75t_R  g001(.A1(p8), .A2(p9), .B(p10), .Y(new_n92_));
  INVx1_ASAP7_75t_R    g002(.A(p13), .Y(new_n93_));
  AO21x1_ASAP7_75t_R   g003(.A1(new_n91_), .A2(new_n92_), .B(new_n93_), .Y(new_n94_));
  INVx1_ASAP7_75t_R    g004(.A(p15), .Y(new_n95_));
  AOI21x1_ASAP7_75t_R  g005(.A1(new_n95_), .A2(p14), .B(new_n94_), .Y(new_n96_));
  AO21x1_ASAP7_75t_R   g006(.A1(p14), .A2(new_n94_), .B(new_n96_), .Y(new_n97_));
  INVx1_ASAP7_75t_R    g007(.A(p11), .Y(new_n98_));
  NAND2x1_ASAP7_75t_R  g008(.A(new_n98_), .B(new_n92_), .Y(new_n99_));
  INVx1_ASAP7_75t_R    g009(.A(p10), .Y(new_n100_));
  NOR2x1_ASAP7_75t_R   g010(.A(p8), .B(p9), .Y(new_n101_));
  AO21x1_ASAP7_75t_R   g011(.A1(new_n100_), .A2(new_n101_), .B(new_n98_), .Y(new_n102_));
  NOR2x1_ASAP7_75t_R   g012(.A(p2), .B(p17), .Y(new_n103_));
  INVx1_ASAP7_75t_R    g013(.A(p25), .Y(new_n104_));
  AND3x1_ASAP7_75t_R   g014(.A(new_n103_), .B(p18), .C(new_n104_), .Y(new_n105_));
  NOR2x1_ASAP7_75t_R   g015(.A(p7), .B(p9), .Y(new_n106_));
  NOR3x1_ASAP7_75t_R   g016(.A(p0), .B(p4), .C(p3), .Y(new_n107_));
  AND5x1_ASAP7_75t_R   g017(.A(new_n99_), .B(new_n102_), .C(new_n105_), .D(new_n106_), .E(new_n107_), .Y(new_n108_));
  INVx1_ASAP7_75t_R    g018(.A(p5), .Y(new_n109_));
  AND4x2_ASAP7_75t_R   g019(.A(new_n109_), .B(p8), .C(p24), .D(p23), .Y(new_n110_));
  INVx1_ASAP7_75t_R    g020(.A(p21), .Y(new_n111_));
  INVx1_ASAP7_75t_R    g021(.A(p20), .Y(new_n112_));
  AND3x1_ASAP7_75t_R   g022(.A(new_n111_), .B(new_n112_), .C(p22), .Y(new_n113_));
  NOR2x1_ASAP7_75t_R   g023(.A(p12), .B(new_n93_), .Y(new_n114_));
  NOR2x1_ASAP7_75t_R   g024(.A(p1), .B(p6), .Y(new_n115_));
  AND5x1_ASAP7_75t_R   g025(.A(p19), .B(new_n110_), .C(new_n113_), .D(new_n114_), .E(new_n115_), .Y(new_n116_));
  NAND2x1_ASAP7_75t_R  g026(.A(p13), .B(p14), .Y(new_n117_));
  AOI21x1_ASAP7_75t_R  g027(.A1(new_n91_), .A2(new_n92_), .B(new_n117_), .Y(new_n118_));
  OA21x2_ASAP7_75t_R   g028(.A1(p15), .A2(new_n118_), .B(p16), .Y(new_n119_));
  NAND3x1_ASAP7_75t_R  g029(.A(new_n108_), .B(new_n116_), .C(new_n119_), .Y(new_n120_));
  NAND2x1_ASAP7_75t_R  g030(.A(new_n111_), .B(new_n112_), .Y(new_n121_));
  AO21x1_ASAP7_75t_R   g031(.A1(p15), .A2(p16), .B(p17), .Y(new_n122_));
  AO211x2_ASAP7_75t_R  g032(.A1(new_n118_), .A2(p16), .B(new_n121_), .C(new_n122_), .Y(new_n123_));
  AND2x2_ASAP7_75t_R   g033(.A(p19), .B(p18), .Y(new_n124_));
  OA21x2_ASAP7_75t_R   g034(.A1(new_n124_), .A2(new_n121_), .B(p22), .Y(new_n125_));
  AND3x1_ASAP7_75t_R   g035(.A(p26), .B(p27), .C(p28), .Y(new_n126_));
  AND3x1_ASAP7_75t_R   g036(.A(new_n126_), .B(p24), .C(p23), .Y(new_n127_));
  AND2x2_ASAP7_75t_R   g037(.A(p25), .B(new_n126_), .Y(new_n128_));
  AO31x2_ASAP7_75t_R   g038(.A1(new_n123_), .A2(new_n125_), .A3(new_n127_), .B(new_n128_), .Y(new_n129_));
  OAI21x1_ASAP7_75t_R  g039(.A1(new_n97_), .A2(new_n120_), .B(new_n129_), .Y(new_n130_));
  AO21x1_ASAP7_75t_R   g040(.A1(new_n125_), .A2(new_n123_), .B(p23), .Y(new_n131_));
  AND3x1_ASAP7_75t_R   g041(.A(new_n124_), .B(new_n91_), .C(new_n101_), .Y(new_n132_));
  AND2x2_ASAP7_75t_R   g042(.A(p6), .B(p24), .Y(new_n133_));
  AND3x1_ASAP7_75t_R   g043(.A(new_n133_), .B(p7), .C(p1), .Y(new_n134_));
  AND2x2_ASAP7_75t_R   g044(.A(p5), .B(p10), .Y(new_n135_));
  AND3x1_ASAP7_75t_R   g045(.A(new_n135_), .B(new_n95_), .C(p13), .Y(new_n136_));
  AND3x1_ASAP7_75t_R   g046(.A(new_n132_), .B(new_n134_), .C(new_n136_), .Y(new_n137_));
  AOI21x1_ASAP7_75t_R  g047(.A1(p16), .A2(new_n118_), .B(new_n122_), .Y(new_n138_));
  OR3x1_ASAP7_75t_R    g048(.A(new_n118_), .B(p15), .C(p16), .Y(new_n139_));
  AND2x2_ASAP7_75t_R   g049(.A(p2), .B(new_n104_), .Y(new_n140_));
  AND3x1_ASAP7_75t_R   g050(.A(p4), .B(p14), .C(p3), .Y(new_n141_));
  AND2x2_ASAP7_75t_R   g051(.A(p59), .B(p0), .Y(new_n142_));
  AND5x1_ASAP7_75t_R   g052(.A(new_n126_), .B(new_n113_), .C(new_n140_), .D(new_n141_), .E(new_n142_), .Y(new_n143_));
  AND4x2_ASAP7_75t_R   g053(.A(new_n137_), .B(new_n138_), .C(new_n139_), .D(new_n143_), .Y(new_n144_));
  AO21x1_ASAP7_75t_R   g054(.A1(new_n131_), .A2(new_n144_), .B(new_n129_), .Y(new_n145_));
  NAND2x1_ASAP7_75t_R  g055(.A(new_n130_), .B(new_n145_), .Y(o0));
  INVx1_ASAP7_75t_R    g056(.A(p50), .Y(new_n147_));
  INVx1_ASAP7_75t_R    g057(.A(p51), .Y(new_n148_));
  INVx1_ASAP7_75t_R    g058(.A(p55), .Y(new_n149_));
  AND3x1_ASAP7_75t_R   g059(.A(new_n147_), .B(new_n148_), .C(new_n149_), .Y(new_n150_));
  NOR2x1_ASAP7_75t_R   g060(.A(p42), .B(p41), .Y(new_n151_));
  OAI21x1_ASAP7_75t_R  g061(.A1(p38), .A2(p39), .B(p40), .Y(new_n152_));
  NAND2x1_ASAP7_75t_R  g062(.A(p44), .B(p43), .Y(new_n153_));
  AO21x1_ASAP7_75t_R   g063(.A1(new_n151_), .A2(new_n152_), .B(new_n153_), .Y(new_n154_));
  INVx1_ASAP7_75t_R    g064(.A(p45), .Y(new_n155_));
  INVx1_ASAP7_75t_R    g065(.A(p47), .Y(new_n156_));
  AND2x2_ASAP7_75t_R   g066(.A(p48), .B(p49), .Y(new_n157_));
  OAI21x1_ASAP7_75t_R  g067(.A1(p46), .A2(p47), .B(new_n157_), .Y(new_n158_));
  AO31x2_ASAP7_75t_R   g068(.A1(new_n154_), .A2(new_n155_), .A3(new_n156_), .B(new_n158_), .Y(new_n159_));
  AND3x1_ASAP7_75t_R   g069(.A(p56), .B(p57), .C(p58), .Y(new_n160_));
  AND2x2_ASAP7_75t_R   g070(.A(p53), .B(p54), .Y(new_n161_));
  AO21x1_ASAP7_75t_R   g071(.A1(p52), .A2(new_n161_), .B(p55), .Y(new_n162_));
  NAND2x1_ASAP7_75t_R  g072(.A(new_n160_), .B(new_n162_), .Y(new_n163_));
  AOI21x1_ASAP7_75t_R  g073(.A1(new_n150_), .A2(new_n159_), .B(new_n163_), .Y(new_n164_));
  NOR2x1_ASAP7_75t_R   g074(.A(p50), .B(p59), .Y(new_n165_));
  INVx1_ASAP7_75t_R    g075(.A(p52), .Y(new_n166_));
  NOR2x1_ASAP7_75t_R   g076(.A(p51), .B(new_n166_), .Y(new_n167_));
  INVx1_ASAP7_75t_R    g077(.A(new_n167_), .Y(new_n168_));
  INVx1_ASAP7_75t_R    g078(.A(p43), .Y(new_n169_));
  AOI21x1_ASAP7_75t_R  g079(.A1(new_n151_), .A2(new_n152_), .B(new_n169_), .Y(new_n170_));
  NOR2x1_ASAP7_75t_R   g080(.A(p38), .B(p39), .Y(new_n171_));
  AND4x2_ASAP7_75t_R   g081(.A(p37), .B(p32), .C(p44), .D(p29), .Y(new_n172_));
  AND4x2_ASAP7_75t_R   g082(.A(p34), .B(p48), .C(p49), .D(p36), .Y(new_n173_));
  NOR2x1_ASAP7_75t_R   g083(.A(p55), .B(p45), .Y(new_n174_));
  AND5x1_ASAP7_75t_R   g084(.A(new_n171_), .B(new_n172_), .C(new_n173_), .D(new_n161_), .E(new_n174_), .Y(new_n175_));
  NAND2x1_ASAP7_75t_R  g085(.A(p42), .B(p41), .Y(new_n176_));
  OAI21x1_ASAP7_75t_R  g086(.A1(new_n176_), .A2(new_n152_), .B(new_n169_), .Y(new_n177_));
  INVx1_ASAP7_75t_R    g087(.A(p33), .Y(new_n178_));
  NOR2x1_ASAP7_75t_R   g088(.A(p47), .B(new_n178_), .Y(new_n179_));
  AND4x2_ASAP7_75t_R   g089(.A(p35), .B(p46), .C(p31), .D(p30), .Y(new_n180_));
  AND4x2_ASAP7_75t_R   g090(.A(new_n179_), .B(new_n180_), .C(p40), .D(new_n160_), .Y(new_n181_));
  NAND3x1_ASAP7_75t_R  g091(.A(new_n175_), .B(new_n177_), .C(new_n181_), .Y(new_n182_));
  AOI211x1_ASAP7_75t_R g092(.A1(new_n159_), .A2(new_n168_), .B(new_n170_), .C(new_n182_), .Y(new_n183_));
  OAI21x1_ASAP7_75t_R  g093(.A1(new_n164_), .A2(new_n165_), .B(new_n183_), .Y(new_n184_));
  OR2x4_ASAP7_75t_R    g094(.A(p29), .B(p59), .Y(new_n185_));
  INVx1_ASAP7_75t_R    g095(.A(new_n153_), .Y(new_n186_));
  AND4x2_ASAP7_75t_R   g096(.A(p53), .B(p48), .C(p49), .D(p54), .Y(new_n187_));
  NOR2x1_ASAP7_75t_R   g097(.A(p34), .B(p36), .Y(new_n188_));
  NAND3x1_ASAP7_75t_R  g098(.A(new_n186_), .B(new_n187_), .C(new_n188_), .Y(new_n189_));
  NAND2x1_ASAP7_75t_R  g099(.A(p46), .B(p47), .Y(new_n190_));
  NAND3x1_ASAP7_75t_R  g100(.A(new_n167_), .B(new_n174_), .C(new_n190_), .Y(new_n191_));
  AO21x1_ASAP7_75t_R   g101(.A1(p38), .A2(p40), .B(p41), .Y(new_n192_));
  AND2x2_ASAP7_75t_R   g102(.A(p39), .B(p40), .Y(new_n193_));
  NAND2x1_ASAP7_75t_R  g103(.A(p41), .B(p40), .Y(new_n194_));
  OAI22x1_ASAP7_75t_R  g104(.A1(new_n192_), .A2(new_n193_), .B1(new_n171_), .B2(new_n194_), .Y(new_n195_));
  NOR3x1_ASAP7_75t_R   g105(.A(new_n189_), .B(new_n191_), .C(new_n195_), .Y(new_n196_));
  NOR2x1_ASAP7_75t_R   g106(.A(p39), .B(p30), .Y(new_n197_));
  AND3x1_ASAP7_75t_R   g107(.A(new_n197_), .B(new_n178_), .C(p40), .Y(new_n198_));
  NOR2x1_ASAP7_75t_R   g108(.A(p32), .B(p35), .Y(new_n199_));
  NOR2x1_ASAP7_75t_R   g109(.A(p42), .B(p31), .Y(new_n200_));
  AND2x2_ASAP7_75t_R   g110(.A(p38), .B(new_n147_), .Y(new_n201_));
  INVx1_ASAP7_75t_R    g111(.A(p37), .Y(new_n202_));
  AND2x2_ASAP7_75t_R   g112(.A(p56), .B(new_n202_), .Y(new_n203_));
  AND5x1_ASAP7_75t_R   g113(.A(new_n198_), .B(new_n199_), .C(new_n200_), .D(new_n201_), .E(new_n203_), .Y(new_n204_));
  AO21x1_ASAP7_75t_R   g114(.A1(new_n155_), .A2(new_n154_), .B(p46), .Y(new_n205_));
  NAND3x1_ASAP7_75t_R  g115(.A(new_n196_), .B(new_n204_), .C(new_n205_), .Y(new_n206_));
  OAI21x1_ASAP7_75t_R  g116(.A1(new_n185_), .A2(new_n206_), .B(new_n164_), .Y(new_n207_));
  AOI21x1_ASAP7_75t_R  g117(.A1(new_n131_), .A2(new_n144_), .B(new_n129_), .Y(new_n208_));
  AO31x2_ASAP7_75t_R   g118(.A1(new_n184_), .A2(new_n130_), .A3(new_n207_), .B(new_n208_), .Y(o1));
  OA21x2_ASAP7_75t_R   g119(.A1(new_n97_), .A2(new_n120_), .B(new_n129_), .Y(new_n210_));
  AND2x2_ASAP7_75t_R   g120(.A(p29), .B(p59), .Y(new_n211_));
  OAI21x1_ASAP7_75t_R  g121(.A1(new_n211_), .A2(new_n206_), .B(new_n164_), .Y(new_n212_));
  NOR3x1_ASAP7_75t_R   g122(.A(new_n210_), .B(new_n212_), .C(new_n208_), .Y(o2));
  assign               o3 = 1'b0;
  assign               o4 = 1'b0;
  assign               o5 = 1'b0;
  assign               o6 = 1'b0;
  assign               o7 = 1'b0;
  assign               o8 = 1'b0;
  assign               o9 = 1'b0;
  assign               o10 = 1'b0;
  assign               o11 = 1'b0;
  assign               o12 = 1'b0;
  assign               o13 = 1'b0;
  assign               o14 = 1'b0;
  assign               o15 = 1'b0;
  assign               o16 = 1'b0;
  assign               o17 = 1'b0;
  assign               o18 = 1'b0;
  assign               o19 = 1'b0;
  assign               o20 = 1'b0;
  assign               o21 = 1'b0;
  assign               o22 = 1'b0;
  assign               o23 = 1'b0;
  assign               o24 = 1'b0;
  assign               o25 = 1'b0;
  assign               o26 = 1'b0;
  assign               o27 = 1'b0;
  assign               o28 = 1'b0;
  assign               o29 = 1'b0;
endmodule


