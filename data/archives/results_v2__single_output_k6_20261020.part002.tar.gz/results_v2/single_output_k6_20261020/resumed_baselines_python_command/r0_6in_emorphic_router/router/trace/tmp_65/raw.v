// Benchmark "/tmp/" written by ABC on Tue Oct 20 18:11:52 2026

module \/tmp/  ( 
    p47, p52, p49, p21, p25, p30, p10, p0, p8, p50, p57, p32, p56, p23,
    p31, p27, p7, p44, p13, p37, p54, p42, p28, p48, p36, p41, p20, p17,
    p35, p38, p15, p53, p11, p6, p45, p33, p16, p59, p12, p43, p22, p2,
    p51, p18, p14, p29, p4, p58, p39, p19, p1, p26, p24, p34, p46, p3, p55,
    p5, p9, p40,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25, o26, o27, o28, o29  );
  input  p47, p52, p49, p21, p25, p30, p10, p0, p8, p50, p57, p32, p56,
    p23, p31, p27, p7, p44, p13, p37, p54, p42, p28, p48, p36, p41, p20,
    p17, p35, p38, p15, p53, p11, p6, p45, p33, p16, p59, p12, p43, p22,
    p2, p51, p18, p14, p29, p4, p58, p39, p19, p1, p26, p24, p34, p46, p3,
    p55, p5, p9, p40;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25, o26, o27, o28, o29;
  wire new_n91_, new_n92_, new_n93_, new_n94_, new_n95_, new_n96_, new_n97_,
    new_n98_, new_n99_, new_n100_, new_n101_, new_n102_, new_n103_,
    new_n104_, new_n105_, new_n106_, new_n107_, new_n108_, new_n109_,
    new_n110_, new_n111_, new_n112_, new_n113_, new_n114_, new_n115_,
    new_n116_, new_n117_, new_n118_, new_n119_, new_n120_, new_n121_,
    new_n122_, new_n123_, new_n124_, new_n125_, new_n126_, new_n127_,
    new_n128_, new_n129_, new_n130_, new_n131_, new_n132_, new_n133_,
    new_n134_, new_n135_, new_n136_, new_n137_, new_n138_, new_n139_,
    new_n140_, new_n141_, new_n142_, new_n143_, new_n144_, new_n145_,
    new_n146_, new_n147_, new_n148_, new_n149_, new_n150_, new_n151_,
    new_n153_, new_n154_, new_n155_, new_n156_, new_n157_, new_n158_,
    new_n159_, new_n160_, new_n161_, new_n162_, new_n163_, new_n164_,
    new_n165_, new_n166_, new_n167_, new_n168_, new_n169_, new_n170_,
    new_n171_, new_n172_, new_n173_, new_n174_, new_n175_, new_n176_,
    new_n177_, new_n178_, new_n179_, new_n180_, new_n181_, new_n182_,
    new_n183_, new_n184_, new_n185_, new_n186_, new_n187_, new_n188_,
    new_n189_, new_n190_, new_n191_, new_n192_, new_n193_, new_n194_,
    new_n195_, new_n196_, new_n197_, new_n198_, new_n199_, new_n200_,
    new_n201_, new_n202_, new_n203_, new_n204_, new_n205_, new_n206_,
    new_n207_, new_n208_, new_n209_, new_n210_, new_n211_, new_n212_,
    new_n213_, new_n214_, new_n215_, new_n216_, new_n217_, new_n218_,
    new_n219_, new_n220_, new_n221_, new_n222_, new_n223_, new_n224_,
    new_n225_, new_n226_, new_n227_, new_n228_, new_n229_, new_n230_,
    new_n231_, new_n232_, new_n233_, new_n234_, new_n235_, new_n237_,
    new_n238_, new_n239_;
  NAND3x1_ASAP7_75t_R  g000(.A(p27), .B(p28), .C(p26), .Y(new_n91_));
  INVx1_ASAP7_75t_R    g001(.A(new_n91_), .Y(new_n92_));
  NOR2x1_ASAP7_75t_R   g002(.A(p21), .B(p20), .Y(new_n93_));
  NOR2x1_ASAP7_75t_R   g003(.A(p11), .B(p12), .Y(new_n94_));
  OAI21x1_ASAP7_75t_R  g004(.A1(p8), .A2(p9), .B(p10), .Y(new_n95_));
  NAND2x1_ASAP7_75t_R  g005(.A(p13), .B(p14), .Y(new_n96_));
  AOI21x1_ASAP7_75t_R  g006(.A1(new_n94_), .A2(new_n95_), .B(new_n96_), .Y(new_n97_));
  AO21x1_ASAP7_75t_R   g007(.A1(p15), .A2(p16), .B(p17), .Y(new_n98_));
  AOI21x1_ASAP7_75t_R  g008(.A1(p16), .A2(new_n97_), .B(new_n98_), .Y(new_n99_));
  NAND2x1_ASAP7_75t_R  g009(.A(p23), .B(p24), .Y(new_n100_));
  NAND2x1_ASAP7_75t_R  g010(.A(p18), .B(p19), .Y(new_n101_));
  INVx1_ASAP7_75t_R    g011(.A(p22), .Y(new_n102_));
  AO21x1_ASAP7_75t_R   g012(.A1(new_n101_), .A2(new_n93_), .B(new_n102_), .Y(new_n103_));
  AOI211x1_ASAP7_75t_R g013(.A1(new_n93_), .A2(new_n99_), .B(new_n100_), .C(new_n103_), .Y(new_n104_));
  INVx1_ASAP7_75t_R    g014(.A(p25), .Y(new_n105_));
  NOR2x1_ASAP7_75t_R   g015(.A(new_n105_), .B(new_n91_), .Y(new_n106_));
  AO21x1_ASAP7_75t_R   g016(.A1(new_n92_), .A2(new_n104_), .B(new_n106_), .Y(new_n107_));
  OA21x2_ASAP7_75t_R   g017(.A1(p15), .A2(new_n97_), .B(p16), .Y(new_n108_));
  INVx1_ASAP7_75t_R    g018(.A(new_n108_), .Y(new_n109_));
  INVx1_ASAP7_75t_R    g019(.A(new_n100_), .Y(new_n110_));
  INVx1_ASAP7_75t_R    g020(.A(p0), .Y(new_n111_));
  INVx1_ASAP7_75t_R    g021(.A(p7), .Y(new_n112_));
  AND5x1_ASAP7_75t_R   g022(.A(new_n105_), .B(new_n110_), .C(new_n111_), .D(p8), .E(new_n112_), .Y(new_n113_));
  NAND2x1_ASAP7_75t_R  g023(.A(p15), .B(new_n97_), .Y(new_n114_));
  AND2x2_ASAP7_75t_R   g024(.A(p22), .B(p19), .Y(new_n115_));
  NOR2x1_ASAP7_75t_R   g025(.A(p17), .B(p6), .Y(new_n116_));
  AND3x1_ASAP7_75t_R   g026(.A(new_n115_), .B(new_n93_), .C(new_n116_), .Y(new_n117_));
  NAND3x1_ASAP7_75t_R  g027(.A(new_n113_), .B(new_n114_), .C(new_n117_), .Y(new_n118_));
  INVx1_ASAP7_75t_R    g028(.A(p18), .Y(new_n119_));
  OR4x2_ASAP7_75t_R    g029(.A(new_n119_), .B(p2), .C(p4), .D(p1), .Y(new_n120_));
  INVx1_ASAP7_75t_R    g030(.A(p13), .Y(new_n121_));
  OR3x1_ASAP7_75t_R    g031(.A(p3), .B(p5), .C(p9), .Y(new_n122_));
  OR4x2_ASAP7_75t_R    g032(.A(new_n120_), .B(new_n121_), .C(p12), .D(new_n122_), .Y(new_n123_));
  INVx1_ASAP7_75t_R    g033(.A(p14), .Y(new_n124_));
  AO21x1_ASAP7_75t_R   g034(.A1(new_n94_), .A2(new_n95_), .B(new_n121_), .Y(new_n125_));
  AOI21x1_ASAP7_75t_R  g035(.A1(new_n124_), .A2(new_n125_), .B(new_n97_), .Y(new_n126_));
  INVx1_ASAP7_75t_R    g036(.A(p10), .Y(new_n127_));
  NAND2x1_ASAP7_75t_R  g037(.A(p11), .B(new_n127_), .Y(new_n128_));
  INVx1_ASAP7_75t_R    g038(.A(p8), .Y(new_n129_));
  INVx1_ASAP7_75t_R    g039(.A(p9), .Y(new_n130_));
  NAND2x1_ASAP7_75t_R  g040(.A(new_n129_), .B(new_n130_), .Y(new_n131_));
  AO22x1_ASAP7_75t_R   g041(.A1(new_n95_), .A2(new_n128_), .B1(p11), .B2(new_n131_), .Y(new_n132_));
  OR5x1_ASAP7_75t_R    g042(.A(new_n109_), .B(new_n118_), .C(new_n123_), .D(new_n126_), .E(new_n132_), .Y(new_n133_));
  NOR2x1_ASAP7_75t_R   g043(.A(p15), .B(p16), .Y(new_n134_));
  OR5x1_ASAP7_75t_R    g044(.A(p25), .B(new_n134_), .C(new_n127_), .D(new_n111_), .E(new_n112_), .Y(new_n135_));
  NAND2x1_ASAP7_75t_R  g045(.A(p2), .B(p18), .Y(new_n136_));
  NAND2x1_ASAP7_75t_R  g046(.A(p6), .B(p59), .Y(new_n137_));
  INVx1_ASAP7_75t_R    g047(.A(p4), .Y(new_n138_));
  OR5x1_ASAP7_75t_R    g048(.A(p15), .B(new_n96_), .C(new_n136_), .D(new_n137_), .E(new_n138_), .Y(new_n139_));
  NOR2x1_ASAP7_75t_R   g049(.A(new_n135_), .B(new_n139_), .Y(new_n140_));
  NAND2x1_ASAP7_75t_R  g050(.A(p1), .B(p24), .Y(new_n141_));
  NAND2x1_ASAP7_75t_R  g051(.A(p3), .B(p5), .Y(new_n142_));
  NOR3x1_ASAP7_75t_R   g052(.A(new_n91_), .B(new_n141_), .C(new_n142_), .Y(new_n143_));
  AND3x1_ASAP7_75t_R   g053(.A(new_n94_), .B(new_n129_), .C(new_n130_), .Y(new_n144_));
  AND3x1_ASAP7_75t_R   g054(.A(new_n93_), .B(p22), .C(p19), .Y(new_n145_));
  AND3x1_ASAP7_75t_R   g055(.A(new_n143_), .B(new_n144_), .C(new_n145_), .Y(new_n146_));
  INVx1_ASAP7_75t_R    g056(.A(p23), .Y(new_n147_));
  OA21x2_ASAP7_75t_R   g057(.A1(new_n102_), .A2(new_n93_), .B(new_n147_), .Y(new_n148_));
  INVx1_ASAP7_75t_R    g058(.A(new_n148_), .Y(new_n149_));
  AND4x2_ASAP7_75t_R   g059(.A(new_n140_), .B(new_n146_), .C(new_n99_), .D(new_n149_), .Y(new_n150_));
  AOI211x1_ASAP7_75t_R g060(.A1(new_n92_), .A2(new_n104_), .B(new_n106_), .C(new_n150_), .Y(new_n151_));
  AO21x1_ASAP7_75t_R   g061(.A1(new_n107_), .A2(new_n133_), .B(new_n151_), .Y(o0));
  AOI21x1_ASAP7_75t_R  g062(.A1(new_n93_), .A2(new_n99_), .B(new_n103_), .Y(new_n153_));
  NAND3x1_ASAP7_75t_R  g063(.A(new_n153_), .B(new_n92_), .C(new_n110_), .Y(new_n154_));
  INVx1_ASAP7_75t_R    g064(.A(new_n106_), .Y(new_n155_));
  AO21x1_ASAP7_75t_R   g065(.A1(p16), .A2(new_n97_), .B(new_n98_), .Y(new_n156_));
  NAND3x1_ASAP7_75t_R  g066(.A(new_n143_), .B(new_n144_), .C(new_n145_), .Y(new_n157_));
  OR5x1_ASAP7_75t_R    g067(.A(new_n156_), .B(new_n157_), .C(new_n148_), .D(new_n135_), .E(new_n139_), .Y(new_n158_));
  NAND3x1_ASAP7_75t_R  g068(.A(new_n154_), .B(new_n155_), .C(new_n158_), .Y(new_n159_));
  INVx1_ASAP7_75t_R    g069(.A(p55), .Y(new_n160_));
  AND3x1_ASAP7_75t_R   g070(.A(p57), .B(p56), .C(p58), .Y(new_n161_));
  AND3x1_ASAP7_75t_R   g071(.A(p29), .B(p34), .C(p46), .Y(new_n162_));
  AND2x2_ASAP7_75t_R   g072(.A(p54), .B(p53), .Y(new_n163_));
  AND5x1_ASAP7_75t_R   g073(.A(new_n160_), .B(new_n161_), .C(new_n162_), .D(new_n163_), .E(p40), .Y(new_n164_));
  INVx1_ASAP7_75t_R    g074(.A(p33), .Y(new_n165_));
  NOR2x1_ASAP7_75t_R   g075(.A(p45), .B(new_n165_), .Y(new_n166_));
  AND4x2_ASAP7_75t_R   g076(.A(p31), .B(p44), .C(p37), .D(p48), .Y(new_n167_));
  AND2x2_ASAP7_75t_R   g077(.A(p36), .B(p35), .Y(new_n168_));
  AND3x1_ASAP7_75t_R   g078(.A(new_n166_), .B(new_n167_), .C(new_n168_), .Y(new_n169_));
  NAND2x1_ASAP7_75t_R  g079(.A(p42), .B(p41), .Y(new_n170_));
  OAI21x1_ASAP7_75t_R  g080(.A1(p38), .A2(p39), .B(p40), .Y(new_n171_));
  INVx1_ASAP7_75t_R    g081(.A(p43), .Y(new_n172_));
  OAI21x1_ASAP7_75t_R  g082(.A1(new_n170_), .A2(new_n171_), .B(new_n172_), .Y(new_n173_));
  INVx1_ASAP7_75t_R    g083(.A(p47), .Y(new_n174_));
  NOR2x1_ASAP7_75t_R   g084(.A(p38), .B(p39), .Y(new_n175_));
  AND5x1_ASAP7_75t_R   g085(.A(new_n174_), .B(new_n175_), .C(p49), .D(p30), .E(p32), .Y(new_n176_));
  AND4x2_ASAP7_75t_R   g086(.A(new_n164_), .B(new_n169_), .C(new_n173_), .D(new_n176_), .Y(new_n177_));
  AND3x1_ASAP7_75t_R   g087(.A(p44), .B(p43), .C(p46), .Y(new_n178_));
  NOR2x1_ASAP7_75t_R   g088(.A(p42), .B(p41), .Y(new_n179_));
  NAND2x1_ASAP7_75t_R  g089(.A(new_n179_), .B(new_n171_), .Y(new_n180_));
  AO21x1_ASAP7_75t_R   g090(.A1(p45), .A2(p46), .B(p47), .Y(new_n181_));
  AOI21x1_ASAP7_75t_R  g091(.A1(new_n178_), .A2(new_n180_), .B(new_n181_), .Y(new_n182_));
  NAND2x1_ASAP7_75t_R  g092(.A(p49), .B(p48), .Y(new_n183_));
  INVx1_ASAP7_75t_R    g093(.A(p52), .Y(new_n184_));
  OAI22x1_ASAP7_75t_R  g094(.A1(new_n182_), .A2(new_n183_), .B1(new_n184_), .B2(p51), .Y(new_n185_));
  AO21x1_ASAP7_75t_R   g095(.A1(new_n179_), .A2(new_n171_), .B(new_n172_), .Y(new_n186_));
  NAND3x1_ASAP7_75t_R  g096(.A(new_n177_), .B(new_n185_), .C(new_n186_), .Y(new_n187_));
  INVx1_ASAP7_75t_R    g097(.A(p50), .Y(new_n188_));
  INVx1_ASAP7_75t_R    g098(.A(p51), .Y(new_n189_));
  AND3x1_ASAP7_75t_R   g099(.A(new_n188_), .B(new_n189_), .C(new_n160_), .Y(new_n190_));
  OAI21x1_ASAP7_75t_R  g100(.A1(new_n183_), .A2(new_n182_), .B(new_n190_), .Y(new_n191_));
  AO21x1_ASAP7_75t_R   g101(.A1(p52), .A2(new_n163_), .B(p55), .Y(new_n192_));
  AND2x2_ASAP7_75t_R   g102(.A(new_n161_), .B(new_n192_), .Y(new_n193_));
  INVx1_ASAP7_75t_R    g103(.A(p59), .Y(new_n194_));
  AOI22x1_ASAP7_75t_R  g104(.A1(new_n191_), .A2(new_n193_), .B1(new_n188_), .B2(new_n194_), .Y(new_n195_));
  NAND2x1_ASAP7_75t_R  g105(.A(new_n193_), .B(new_n191_), .Y(new_n196_));
  NOR2x1_ASAP7_75t_R   g106(.A(p59), .B(p29), .Y(new_n197_));
  NOR2x1_ASAP7_75t_R   g107(.A(p42), .B(p36), .Y(new_n198_));
  INVx1_ASAP7_75t_R    g108(.A(p35), .Y(new_n199_));
  AND3x1_ASAP7_75t_R   g109(.A(new_n198_), .B(new_n199_), .C(p38), .Y(new_n200_));
  NOR2x1_ASAP7_75t_R   g110(.A(p31), .B(p37), .Y(new_n201_));
  INVx1_ASAP7_75t_R    g111(.A(p32), .Y(new_n202_));
  AND3x1_ASAP7_75t_R   g112(.A(new_n201_), .B(new_n202_), .C(p56), .Y(new_n203_));
  AND4x2_ASAP7_75t_R   g113(.A(new_n160_), .B(p54), .C(p53), .D(p40), .Y(new_n204_));
  NOR2x1_ASAP7_75t_R   g114(.A(p45), .B(p33), .Y(new_n205_));
  NOR2x1_ASAP7_75t_R   g115(.A(p39), .B(p34), .Y(new_n206_));
  AND5x1_ASAP7_75t_R   g116(.A(new_n200_), .B(new_n203_), .C(new_n204_), .D(new_n205_), .E(new_n206_), .Y(new_n207_));
  INVx1_ASAP7_75t_R    g117(.A(p46), .Y(new_n208_));
  AO21x1_ASAP7_75t_R   g118(.A1(new_n174_), .A2(new_n180_), .B(new_n208_), .Y(new_n209_));
  AND2x2_ASAP7_75t_R   g119(.A(p41), .B(p40), .Y(new_n210_));
  OAI21x1_ASAP7_75t_R  g120(.A1(p38), .A2(p39), .B(new_n210_), .Y(new_n211_));
  NAND2x1_ASAP7_75t_R  g121(.A(p44), .B(p43), .Y(new_n212_));
  NOR3x1_ASAP7_75t_R   g122(.A(new_n212_), .B(p30), .C(p50), .Y(new_n213_));
  NOR3x1_ASAP7_75t_R   g123(.A(new_n183_), .B(new_n184_), .C(p51), .Y(new_n214_));
  INVx1_ASAP7_75t_R    g124(.A(p41), .Y(new_n215_));
  NAND2x1_ASAP7_75t_R  g125(.A(new_n215_), .B(new_n171_), .Y(new_n216_));
  AND4x2_ASAP7_75t_R   g126(.A(new_n211_), .B(new_n213_), .C(new_n214_), .D(new_n216_), .Y(new_n217_));
  OAI21x1_ASAP7_75t_R  g127(.A1(new_n174_), .A2(new_n180_), .B(new_n208_), .Y(new_n218_));
  AND5x1_ASAP7_75t_R   g128(.A(new_n197_), .B(new_n207_), .C(new_n209_), .D(new_n217_), .E(new_n218_), .Y(new_n219_));
  OAI22x1_ASAP7_75t_R  g129(.A1(new_n187_), .A2(new_n195_), .B1(new_n196_), .B2(new_n219_), .Y(new_n220_));
  INVx1_ASAP7_75t_R    g130(.A(p12), .Y(new_n221_));
  OA211x2_ASAP7_75t_R  g131(.A1(p8), .A2(p11), .B(new_n221_), .C(new_n130_), .Y(new_n222_));
  OA21x2_ASAP7_75t_R   g132(.A1(new_n127_), .A2(p8), .B(new_n222_), .Y(new_n223_));
  INVx1_ASAP7_75t_R    g133(.A(p15), .Y(new_n224_));
  AO21x1_ASAP7_75t_R   g134(.A1(new_n94_), .A2(new_n95_), .B(new_n224_), .Y(new_n225_));
  NOR2x1_ASAP7_75t_R   g135(.A(p3), .B(p5), .Y(new_n226_));
  INVx1_ASAP7_75t_R    g136(.A(p1), .Y(new_n227_));
  AND3x1_ASAP7_75t_R   g137(.A(new_n226_), .B(new_n138_), .C(new_n227_), .Y(new_n228_));
  NOR2x1_ASAP7_75t_R   g138(.A(p2), .B(new_n119_), .Y(new_n229_));
  OAI21x1_ASAP7_75t_R  g139(.A1(p11), .A2(new_n127_), .B(p8), .Y(new_n230_));
  AND5x1_ASAP7_75t_R   g140(.A(new_n145_), .B(new_n228_), .C(new_n116_), .D(new_n229_), .E(new_n230_), .Y(new_n231_));
  NOR2x1_ASAP7_75t_R   g141(.A(new_n100_), .B(new_n96_), .Y(new_n232_));
  AND5x1_ASAP7_75t_R   g142(.A(new_n105_), .B(new_n232_), .C(new_n111_), .D(p8), .E(new_n112_), .Y(new_n233_));
  AND5x1_ASAP7_75t_R   g143(.A(new_n108_), .B(new_n223_), .C(new_n225_), .D(new_n231_), .E(new_n233_), .Y(new_n234_));
  AOI21x1_ASAP7_75t_R  g144(.A1(new_n155_), .A2(new_n154_), .B(new_n234_), .Y(new_n235_));
  AOI21x1_ASAP7_75t_R  g145(.A1(new_n159_), .A2(new_n220_), .B(new_n235_), .Y(o1));
  AND3x1_ASAP7_75t_R   g146(.A(new_n207_), .B(new_n218_), .C(new_n217_), .Y(new_n237_));
  NAND2x1_ASAP7_75t_R  g147(.A(p59), .B(p29), .Y(new_n238_));
  AO31x2_ASAP7_75t_R   g148(.A1(new_n209_), .A2(new_n237_), .A3(new_n238_), .B(new_n196_), .Y(new_n239_));
  AOI211x1_ASAP7_75t_R g149(.A1(new_n133_), .A2(new_n107_), .B(new_n151_), .C(new_n239_), .Y(o2));
  assign               o3 = 1'b0;
  assign               o4 = 1'b0;
  assign               o5 = 1'b0;
  assign               o6 = 1'b0;
  assign               o7 = 1'b0;
  assign               o8 = 1'b0;
  assign               o9 = 1'b0;
  assign               o10 = 1'b0;
  assign               o11 = 1'b0;
  assign               o12 = 1'b0;
  assign               o13 = 1'b0;
  assign               o14 = 1'b0;
  assign               o15 = 1'b0;
  assign               o16 = 1'b0;
  assign               o17 = 1'b0;
  assign               o18 = 1'b0;
  assign               o19 = 1'b0;
  assign               o20 = 1'b0;
  assign               o21 = 1'b0;
  assign               o22 = 1'b0;
  assign               o23 = 1'b0;
  assign               o24 = 1'b0;
  assign               o25 = 1'b0;
  assign               o26 = 1'b0;
  assign               o27 = 1'b0;
  assign               o28 = 1'b0;
  assign               o29 = 1'b0;
endmodule


