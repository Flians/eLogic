// Benchmark "/tmp/" written by ABC on Tue Oct 20 18:11:48 2026

module \/tmp/  ( 
    p8, p10, p29, p47, p23, p32, p13, p48, p27, p11, p57, p52, p30, p14,
    p31, p34, p42, p46, p16, p9, p1, p28, p45, p7, p50, p58, p15, p24, p54,
    p0, p25, p55, p59, p19, p33, p20, p49, p22, p21, p26, p12, p40, p38,
    p53, p51, p37, p2, p43, p5, p56, p18, p39, p35, p44, p6, p4, p41, p17,
    p3, p36,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25, o26, o27, o28, o29  );
  input  p8, p10, p29, p47, p23, p32, p13, p48, p27, p11, p57, p52, p30,
    p14, p31, p34, p42, p46, p16, p9, p1, p28, p45, p7, p50, p58, p15, p24,
    p54, p0, p25, p55, p59, p19, p33, p20, p49, p22, p21, p26, p12, p40,
    p38, p53, p51, p37, p2, p43, p5, p56, p18, p39, p35, p44, p6, p4, p41,
    p17, p3, p36;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25, o26, o27, o28, o29;
  wire new_n91_, new_n92_, new_n93_, new_n94_, new_n95_, new_n96_, new_n97_,
    new_n98_, new_n99_, new_n100_, new_n101_, new_n102_, new_n103_,
    new_n104_, new_n105_, new_n106_, new_n107_, new_n108_, new_n109_,
    new_n110_, new_n111_, new_n112_, new_n113_, new_n114_, new_n115_,
    new_n116_, new_n117_, new_n118_, new_n119_, new_n120_, new_n121_,
    new_n122_, new_n123_, new_n124_, new_n125_, new_n126_, new_n127_,
    new_n128_, new_n129_, new_n130_, new_n131_, new_n132_, new_n133_,
    new_n134_, new_n135_, new_n136_, new_n137_, new_n138_, new_n139_,
    new_n140_, new_n141_, new_n142_, new_n143_, new_n144_, new_n145_,
    new_n146_, new_n147_, new_n148_, new_n150_, new_n151_, new_n152_,
    new_n153_, new_n154_, new_n155_, new_n156_, new_n157_, new_n158_,
    new_n159_, new_n160_, new_n161_, new_n162_, new_n163_, new_n164_,
    new_n165_, new_n166_, new_n167_, new_n168_, new_n169_, new_n170_,
    new_n171_, new_n172_, new_n173_, new_n174_, new_n175_, new_n176_,
    new_n177_, new_n178_, new_n179_, new_n180_, new_n181_, new_n182_,
    new_n183_, new_n184_, new_n185_, new_n186_, new_n187_, new_n188_,
    new_n189_, new_n190_, new_n191_, new_n192_, new_n193_, new_n194_,
    new_n195_, new_n196_, new_n197_, new_n198_, new_n199_, new_n200_,
    new_n201_, new_n202_, new_n203_, new_n204_, new_n205_, new_n206_,
    new_n207_, new_n208_, new_n209_, new_n210_, new_n211_, new_n212_,
    new_n213_, new_n214_, new_n215_, new_n216_, new_n217_, new_n218_,
    new_n219_, new_n220_, new_n221_, new_n223_, new_n224_, new_n225_,
    new_n226_, new_n227_, new_n228_, new_n229_, new_n230_, new_n231_,
    new_n232_, new_n233_, new_n234_, new_n235_, new_n236_, new_n237_,
    new_n238_, new_n239_, new_n240_;
  NOR2x1_ASAP7_75t_R   g000(.A(p20), .B(p21), .Y(new_n91_));
  INVx1_ASAP7_75t_R    g001(.A(new_n91_), .Y(new_n92_));
  NOR2x1_ASAP7_75t_R   g002(.A(p11), .B(p12), .Y(new_n93_));
  OAI21x1_ASAP7_75t_R  g003(.A1(p8), .A2(p9), .B(p10), .Y(new_n94_));
  NAND2x1_ASAP7_75t_R  g004(.A(p13), .B(p14), .Y(new_n95_));
  AOI21x1_ASAP7_75t_R  g005(.A1(new_n93_), .A2(new_n94_), .B(new_n95_), .Y(new_n96_));
  AO21x1_ASAP7_75t_R   g006(.A1(p16), .A2(p15), .B(p17), .Y(new_n97_));
  AO21x1_ASAP7_75t_R   g007(.A1(p16), .A2(new_n96_), .B(new_n97_), .Y(new_n98_));
  NAND2x1_ASAP7_75t_R  g008(.A(p23), .B(p24), .Y(new_n99_));
  INVx1_ASAP7_75t_R    g009(.A(new_n99_), .Y(new_n100_));
  NAND2x1_ASAP7_75t_R  g010(.A(p19), .B(p18), .Y(new_n101_));
  INVx1_ASAP7_75t_R    g011(.A(p22), .Y(new_n102_));
  AOI21x1_ASAP7_75t_R  g012(.A1(new_n101_), .A2(new_n91_), .B(new_n102_), .Y(new_n103_));
  OA211x2_ASAP7_75t_R  g013(.A1(new_n92_), .A2(new_n98_), .B(new_n100_), .C(new_n103_), .Y(new_n104_));
  AND3x1_ASAP7_75t_R   g014(.A(p27), .B(p28), .C(p26), .Y(new_n105_));
  OAI21x1_ASAP7_75t_R  g015(.A1(p25), .A2(new_n104_), .B(new_n105_), .Y(new_n106_));
  INVx1_ASAP7_75t_R    g016(.A(p16), .Y(new_n107_));
  AOI211x1_ASAP7_75t_R g017(.A1(new_n93_), .A2(new_n94_), .B(new_n107_), .C(new_n95_), .Y(new_n108_));
  AO21x1_ASAP7_75t_R   g018(.A1(p16), .A2(p15), .B(new_n108_), .Y(new_n109_));
  INVx1_ASAP7_75t_R    g019(.A(p8), .Y(new_n110_));
  INVx1_ASAP7_75t_R    g020(.A(p13), .Y(new_n111_));
  OR5x1_ASAP7_75t_R    g021(.A(new_n110_), .B(new_n99_), .C(new_n111_), .D(p9), .E(p1), .Y(new_n112_));
  NAND2x1_ASAP7_75t_R  g022(.A(p19), .B(p22), .Y(new_n113_));
  OR5x1_ASAP7_75t_R    g023(.A(p0), .B(new_n113_), .C(p25), .D(p20), .E(p21), .Y(new_n114_));
  AOI211x1_ASAP7_75t_R g024(.A1(p15), .A2(new_n96_), .B(new_n112_), .C(new_n114_), .Y(new_n115_));
  INVx1_ASAP7_75t_R    g025(.A(p14), .Y(new_n116_));
  AO21x1_ASAP7_75t_R   g026(.A1(new_n93_), .A2(new_n94_), .B(new_n111_), .Y(new_n117_));
  AO21x1_ASAP7_75t_R   g027(.A1(new_n116_), .A2(new_n117_), .B(new_n96_), .Y(new_n118_));
  INVx1_ASAP7_75t_R    g028(.A(p10), .Y(new_n119_));
  NAND2x1_ASAP7_75t_R  g029(.A(p11), .B(new_n119_), .Y(new_n120_));
  OA21x2_ASAP7_75t_R   g030(.A1(p8), .A2(p9), .B(p11), .Y(new_n121_));
  AOI21x1_ASAP7_75t_R  g031(.A1(new_n94_), .A2(new_n120_), .B(new_n121_), .Y(new_n122_));
  NOR3x1_ASAP7_75t_R   g032(.A(p4), .B(p17), .C(p3), .Y(new_n123_));
  INVx1_ASAP7_75t_R    g033(.A(p6), .Y(new_n124_));
  NOR2x1_ASAP7_75t_R   g034(.A(p2), .B(p5), .Y(new_n125_));
  NOR2x1_ASAP7_75t_R   g035(.A(p7), .B(p12), .Y(new_n126_));
  AND5x1_ASAP7_75t_R   g036(.A(p18), .B(new_n123_), .C(new_n124_), .D(new_n125_), .E(new_n126_), .Y(new_n127_));
  AND5x1_ASAP7_75t_R   g037(.A(new_n109_), .B(new_n115_), .C(new_n118_), .D(new_n122_), .E(new_n127_), .Y(new_n128_));
  INVx1_ASAP7_75t_R    g038(.A(new_n105_), .Y(new_n129_));
  OA31x2_ASAP7_75t_R   g039(.A1(new_n92_), .A2(new_n97_), .A3(new_n108_), .B1(new_n103_), .Y(new_n130_));
  AOI21x1_ASAP7_75t_R  g040(.A1(new_n100_), .A2(new_n130_), .B(p25), .Y(new_n131_));
  INVx1_ASAP7_75t_R    g041(.A(p25), .Y(new_n132_));
  AND2x2_ASAP7_75t_R   g042(.A(p4), .B(p3), .Y(new_n133_));
  AND2x2_ASAP7_75t_R   g043(.A(p18), .B(p6), .Y(new_n134_));
  AND2x2_ASAP7_75t_R   g044(.A(p2), .B(p5), .Y(new_n135_));
  AND5x1_ASAP7_75t_R   g045(.A(new_n132_), .B(new_n133_), .C(new_n134_), .D(new_n135_), .E(p59), .Y(new_n136_));
  AND3x1_ASAP7_75t_R   g046(.A(new_n91_), .B(p19), .C(p22), .Y(new_n137_));
  NAND3x1_ASAP7_75t_R  g047(.A(new_n136_), .B(new_n105_), .C(new_n137_), .Y(new_n138_));
  AOI21x1_ASAP7_75t_R  g048(.A1(p22), .A2(new_n92_), .B(p23), .Y(new_n139_));
  NOR2x1_ASAP7_75t_R   g049(.A(p16), .B(p15), .Y(new_n140_));
  OR5x1_ASAP7_75t_R    g050(.A(p8), .B(new_n140_), .C(p11), .D(p9), .E(p12), .Y(new_n141_));
  INVx1_ASAP7_75t_R    g051(.A(p7), .Y(new_n142_));
  NAND2x1_ASAP7_75t_R  g052(.A(p24), .B(p0), .Y(new_n143_));
  NAND2x1_ASAP7_75t_R  g053(.A(p10), .B(p13), .Y(new_n144_));
  NAND2x1_ASAP7_75t_R  g054(.A(p14), .B(p1), .Y(new_n145_));
  OR5x1_ASAP7_75t_R    g055(.A(new_n142_), .B(new_n143_), .C(new_n144_), .D(new_n145_), .E(p15), .Y(new_n146_));
  OR5x1_ASAP7_75t_R    g056(.A(new_n98_), .B(new_n138_), .C(new_n139_), .D(new_n141_), .E(new_n146_), .Y(new_n147_));
  OAI21x1_ASAP7_75t_R  g057(.A1(new_n129_), .A2(new_n131_), .B(new_n147_), .Y(new_n148_));
  OAI21x1_ASAP7_75t_R  g058(.A1(new_n106_), .A2(new_n128_), .B(new_n148_), .Y(o0));
  AND2x2_ASAP7_75t_R   g059(.A(p48), .B(p49), .Y(new_n150_));
  INVx1_ASAP7_75t_R    g060(.A(new_n150_), .Y(new_n151_));
  NOR2x1_ASAP7_75t_R   g061(.A(p42), .B(p41), .Y(new_n152_));
  OAI21x1_ASAP7_75t_R  g062(.A1(p38), .A2(p39), .B(p40), .Y(new_n153_));
  NAND2x1_ASAP7_75t_R  g063(.A(p43), .B(p44), .Y(new_n154_));
  AOI21x1_ASAP7_75t_R  g064(.A1(new_n152_), .A2(new_n153_), .B(new_n154_), .Y(new_n155_));
  AO21x1_ASAP7_75t_R   g065(.A1(p46), .A2(p45), .B(p47), .Y(new_n156_));
  AOI21x1_ASAP7_75t_R  g066(.A1(p46), .A2(new_n155_), .B(new_n156_), .Y(new_n157_));
  INVx1_ASAP7_75t_R    g067(.A(p50), .Y(new_n158_));
  INVx1_ASAP7_75t_R    g068(.A(p55), .Y(new_n159_));
  INVx1_ASAP7_75t_R    g069(.A(p51), .Y(new_n160_));
  AND3x1_ASAP7_75t_R   g070(.A(new_n158_), .B(new_n159_), .C(new_n160_), .Y(new_n161_));
  OAI21x1_ASAP7_75t_R  g071(.A1(new_n151_), .A2(new_n157_), .B(new_n161_), .Y(new_n162_));
  AND3x1_ASAP7_75t_R   g072(.A(p52), .B(p54), .C(p53), .Y(new_n163_));
  AND3x1_ASAP7_75t_R   g073(.A(p57), .B(p58), .C(p56), .Y(new_n164_));
  OA21x2_ASAP7_75t_R   g074(.A1(p55), .A2(new_n163_), .B(new_n164_), .Y(new_n165_));
  INVx1_ASAP7_75t_R    g075(.A(p59), .Y(new_n166_));
  AOI22x1_ASAP7_75t_R  g076(.A1(new_n162_), .A2(new_n165_), .B1(new_n158_), .B2(new_n166_), .Y(new_n167_));
  INVx1_ASAP7_75t_R    g077(.A(p46), .Y(new_n168_));
  AOI211x1_ASAP7_75t_R g078(.A1(new_n152_), .A2(new_n153_), .B(new_n168_), .C(new_n154_), .Y(new_n169_));
  NOR2x1_ASAP7_75t_R   g079(.A(p52), .B(new_n160_), .Y(new_n170_));
  OA211x2_ASAP7_75t_R  g080(.A1(new_n156_), .A2(new_n169_), .B(new_n150_), .C(new_n170_), .Y(new_n171_));
  NAND2x1_ASAP7_75t_R  g081(.A(new_n152_), .B(new_n153_), .Y(new_n172_));
  AND2x2_ASAP7_75t_R   g082(.A(p43), .B(p44), .Y(new_n173_));
  AO31x2_ASAP7_75t_R   g083(.A1(new_n172_), .A2(p46), .A3(new_n173_), .B(new_n156_), .Y(new_n174_));
  NAND2x1_ASAP7_75t_R  g084(.A(p52), .B(new_n160_), .Y(new_n175_));
  AOI21x1_ASAP7_75t_R  g085(.A1(new_n150_), .A2(new_n174_), .B(new_n175_), .Y(new_n176_));
  AND2x2_ASAP7_75t_R   g086(.A(p35), .B(p36), .Y(new_n177_));
  AND2x2_ASAP7_75t_R   g087(.A(p40), .B(p37), .Y(new_n178_));
  AND2x2_ASAP7_75t_R   g088(.A(p33), .B(p49), .Y(new_n179_));
  AND5x1_ASAP7_75t_R   g089(.A(new_n173_), .B(new_n164_), .C(new_n177_), .D(new_n178_), .E(new_n179_), .Y(new_n180_));
  INVx1_ASAP7_75t_R    g090(.A(p42), .Y(new_n181_));
  INVx1_ASAP7_75t_R    g091(.A(p41), .Y(new_n182_));
  OR3x1_ASAP7_75t_R    g092(.A(new_n181_), .B(new_n182_), .C(p43), .Y(new_n183_));
  NAND2x1_ASAP7_75t_R  g093(.A(new_n172_), .B(new_n183_), .Y(new_n184_));
  NOR2x1_ASAP7_75t_R   g094(.A(p45), .B(p55), .Y(new_n185_));
  AND3x1_ASAP7_75t_R   g095(.A(new_n185_), .B(p34), .C(p46), .Y(new_n186_));
  NOR2x1_ASAP7_75t_R   g096(.A(p38), .B(p39), .Y(new_n187_));
  INVx1_ASAP7_75t_R    g097(.A(p47), .Y(new_n188_));
  AND5x1_ASAP7_75t_R   g098(.A(p29), .B(new_n187_), .C(new_n188_), .D(p54), .E(p53), .Y(new_n189_));
  AND2x2_ASAP7_75t_R   g099(.A(p32), .B(p48), .Y(new_n190_));
  AND3x1_ASAP7_75t_R   g100(.A(new_n190_), .B(p30), .C(p31), .Y(new_n191_));
  AND5x1_ASAP7_75t_R   g101(.A(new_n180_), .B(new_n184_), .C(new_n186_), .D(new_n189_), .E(new_n191_), .Y(new_n192_));
  OAI21x1_ASAP7_75t_R  g102(.A1(new_n171_), .A2(new_n176_), .B(new_n192_), .Y(new_n193_));
  INVx1_ASAP7_75t_R    g103(.A(p40), .Y(new_n194_));
  INVx1_ASAP7_75t_R    g104(.A(p38), .Y(new_n195_));
  OR4x2_ASAP7_75t_R    g105(.A(new_n194_), .B(new_n195_), .C(p50), .D(p55), .Y(new_n196_));
  INVx1_ASAP7_75t_R    g106(.A(p56), .Y(new_n197_));
  OR4x2_ASAP7_75t_R    g107(.A(new_n197_), .B(p37), .C(p39), .D(p36), .Y(new_n198_));
  OR3x1_ASAP7_75t_R    g108(.A(new_n154_), .B(p42), .C(p45), .Y(new_n199_));
  NOR3x1_ASAP7_75t_R   g109(.A(new_n196_), .B(new_n198_), .C(new_n199_), .Y(new_n200_));
  NOR2x1_ASAP7_75t_R   g110(.A(p32), .B(p30), .Y(new_n201_));
  AND3x1_ASAP7_75t_R   g111(.A(new_n201_), .B(p54), .C(p53), .Y(new_n202_));
  NAND2x1_ASAP7_75t_R  g112(.A(p47), .B(p46), .Y(new_n203_));
  AND3x1_ASAP7_75t_R   g113(.A(new_n203_), .B(p48), .C(p49), .Y(new_n204_));
  NAND2x1_ASAP7_75t_R  g114(.A(new_n182_), .B(new_n153_), .Y(new_n205_));
  AND3x1_ASAP7_75t_R   g115(.A(new_n202_), .B(new_n204_), .C(new_n205_), .Y(new_n206_));
  NOR2x1_ASAP7_75t_R   g116(.A(new_n182_), .B(new_n153_), .Y(new_n207_));
  OR4x2_ASAP7_75t_R    g117(.A(p31), .B(p34), .C(p33), .D(p35), .Y(new_n208_));
  NOR3x1_ASAP7_75t_R   g118(.A(new_n207_), .B(new_n175_), .C(new_n208_), .Y(new_n209_));
  NAND3x1_ASAP7_75t_R  g119(.A(new_n200_), .B(new_n206_), .C(new_n209_), .Y(new_n210_));
  OR2x4_ASAP7_75t_R    g120(.A(p45), .B(new_n188_), .Y(new_n211_));
  NOR2x1_ASAP7_75t_R   g121(.A(new_n155_), .B(new_n211_), .Y(new_n212_));
  OA21x2_ASAP7_75t_R   g122(.A1(p45), .A2(new_n155_), .B(p46), .Y(new_n213_));
  NOR2x1_ASAP7_75t_R   g123(.A(p29), .B(p59), .Y(new_n214_));
  OAI21x1_ASAP7_75t_R  g124(.A1(new_n212_), .A2(new_n213_), .B(new_n214_), .Y(new_n215_));
  OAI21x1_ASAP7_75t_R  g125(.A1(new_n156_), .A2(new_n169_), .B(new_n150_), .Y(new_n216_));
  INVx1_ASAP7_75t_R    g126(.A(new_n165_), .Y(new_n217_));
  AOI21x1_ASAP7_75t_R  g127(.A1(new_n161_), .A2(new_n216_), .B(new_n217_), .Y(new_n218_));
  OAI21x1_ASAP7_75t_R  g128(.A1(new_n210_), .A2(new_n215_), .B(new_n218_), .Y(new_n219_));
  OAI21x1_ASAP7_75t_R  g129(.A1(new_n167_), .A2(new_n193_), .B(new_n219_), .Y(new_n220_));
  NOR3x1_ASAP7_75t_R   g130(.A(new_n128_), .B(new_n129_), .C(new_n131_), .Y(new_n221_));
  AOI21x1_ASAP7_75t_R  g131(.A1(new_n148_), .A2(new_n220_), .B(new_n221_), .Y(o1));
  NOR2x1_ASAP7_75t_R   g132(.A(new_n175_), .B(new_n208_), .Y(new_n223_));
  INVx1_ASAP7_75t_R    g133(.A(new_n207_), .Y(new_n224_));
  AND5x1_ASAP7_75t_R   g134(.A(new_n223_), .B(new_n224_), .C(new_n205_), .D(new_n204_), .E(new_n202_), .Y(new_n225_));
  NOR2x1_ASAP7_75t_R   g135(.A(p45), .B(new_n155_), .Y(new_n226_));
  OAI22x1_ASAP7_75t_R  g136(.A1(new_n226_), .A2(new_n168_), .B1(new_n155_), .B2(new_n211_), .Y(new_n227_));
  NOR2x1_ASAP7_75t_R   g137(.A(p45), .B(p50), .Y(new_n228_));
  AND3x1_ASAP7_75t_R   g138(.A(new_n228_), .B(new_n159_), .C(p56), .Y(new_n229_));
  AND3x1_ASAP7_75t_R   g139(.A(new_n173_), .B(new_n181_), .C(p40), .Y(new_n230_));
  NOR2x1_ASAP7_75t_R   g140(.A(p39), .B(new_n195_), .Y(new_n231_));
  NOR2x1_ASAP7_75t_R   g141(.A(p37), .B(p36), .Y(new_n232_));
  NAND2x1_ASAP7_75t_R  g142(.A(p29), .B(p59), .Y(new_n233_));
  AND5x1_ASAP7_75t_R   g143(.A(new_n229_), .B(new_n230_), .C(new_n231_), .D(new_n232_), .E(new_n233_), .Y(new_n234_));
  NAND3x1_ASAP7_75t_R  g144(.A(new_n225_), .B(new_n227_), .C(new_n234_), .Y(new_n235_));
  INVx1_ASAP7_75t_R    g145(.A(new_n163_), .Y(new_n236_));
  NOR2x1_ASAP7_75t_R   g146(.A(p50), .B(p51), .Y(new_n237_));
  OA21x2_ASAP7_75t_R   g147(.A1(new_n237_), .A2(new_n236_), .B(new_n159_), .Y(new_n238_));
  OAI21x1_ASAP7_75t_R  g148(.A1(new_n236_), .A2(new_n216_), .B(new_n238_), .Y(new_n239_));
  NAND3x1_ASAP7_75t_R  g149(.A(new_n235_), .B(new_n164_), .C(new_n239_), .Y(new_n240_));
  AOI211x1_ASAP7_75t_R g150(.A1(new_n147_), .A2(new_n106_), .B(new_n240_), .C(new_n221_), .Y(o2));
  assign               o3 = 1'b0;
  assign               o4 = 1'b0;
  assign               o5 = 1'b0;
  assign               o6 = 1'b0;
  assign               o7 = 1'b0;
  assign               o8 = 1'b0;
  assign               o9 = 1'b0;
  assign               o10 = 1'b0;
  assign               o11 = 1'b0;
  assign               o12 = 1'b0;
  assign               o13 = 1'b0;
  assign               o14 = 1'b0;
  assign               o15 = 1'b0;
  assign               o16 = 1'b0;
  assign               o17 = 1'b0;
  assign               o18 = 1'b0;
  assign               o19 = 1'b0;
  assign               o20 = 1'b0;
  assign               o21 = 1'b0;
  assign               o22 = 1'b0;
  assign               o23 = 1'b0;
  assign               o24 = 1'b0;
  assign               o25 = 1'b0;
  assign               o26 = 1'b0;
  assign               o27 = 1'b0;
  assign               o28 = 1'b0;
  assign               o29 = 1'b0;
endmodule


