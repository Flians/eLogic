// Benchmark "/tmp/" written by ABC on Tue Oct 20 18:11:50 2026

module \/tmp/  ( 
    p58, p46, p56, p26, p42, p47, p52, p16, p9, p11, p57, p44, p12, p38,
    p10, p15, p50, p49, p19, p2, p22, p20, p28, p40, p14, p18, p48, p4,
    p41, p23, p34, p35, p6, p24, p17, p54, p27, p51, p36, p33, p13, p43,
    p37, p39, p31, p29, p59, p45, p25, p53, p5, p30, p0, p7, p55, p8, p32,
    p1, p3, p21,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25, o26, o27, o28, o29  );
  input  p58, p46, p56, p26, p42, p47, p52, p16, p9, p11, p57, p44, p12,
    p38, p10, p15, p50, p49, p19, p2, p22, p20, p28, p40, p14, p18, p48,
    p4, p41, p23, p34, p35, p6, p24, p17, p54, p27, p51, p36, p33, p13,
    p43, p37, p39, p31, p29, p59, p45, p25, p53, p5, p30, p0, p7, p55, p8,
    p32, p1, p3, p21;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25, o26, o27, o28, o29;
  wire new_n91_, new_n92_, new_n93_, new_n94_, new_n95_, new_n96_, new_n97_,
    new_n98_, new_n99_, new_n100_, new_n101_, new_n102_, new_n103_,
    new_n104_, new_n105_, new_n106_, new_n107_, new_n108_, new_n109_,
    new_n110_, new_n111_, new_n112_, new_n113_, new_n114_, new_n115_,
    new_n116_, new_n117_, new_n118_, new_n119_, new_n120_, new_n121_,
    new_n122_, new_n123_, new_n124_, new_n125_, new_n126_, new_n127_,
    new_n128_, new_n129_, new_n130_, new_n131_, new_n132_, new_n133_,
    new_n134_, new_n135_, new_n136_, new_n137_, new_n138_, new_n139_,
    new_n140_, new_n142_, new_n143_, new_n144_, new_n145_, new_n146_,
    new_n147_, new_n148_, new_n149_, new_n150_, new_n151_, new_n152_,
    new_n153_, new_n154_, new_n155_, new_n156_, new_n157_, new_n158_,
    new_n159_, new_n160_, new_n161_, new_n162_, new_n163_, new_n164_,
    new_n165_, new_n166_, new_n167_, new_n168_, new_n169_, new_n170_,
    new_n171_, new_n172_, new_n173_, new_n174_, new_n175_, new_n176_,
    new_n177_, new_n178_, new_n179_, new_n180_, new_n181_, new_n182_,
    new_n183_, new_n184_, new_n185_, new_n186_, new_n187_, new_n188_,
    new_n189_, new_n190_, new_n191_, new_n192_, new_n193_, new_n194_,
    new_n195_, new_n196_, new_n197_, new_n198_, new_n199_, new_n200_,
    new_n201_, new_n202_, new_n203_, new_n204_, new_n205_, new_n206_,
    new_n207_, new_n208_, new_n209_, new_n210_, new_n211_, new_n212_,
    new_n213_, new_n214_, new_n215_, new_n216_, new_n217_, new_n219_,
    new_n220_, new_n221_, new_n222_, new_n223_, new_n224_, new_n225_,
    new_n226_, new_n227_, new_n228_, new_n229_, new_n230_, new_n231_;
  AND3x1_ASAP7_75t_R   g000(.A(p26), .B(p28), .C(p27), .Y(new_n91_));
  NOR2x1_ASAP7_75t_R   g001(.A(p20), .B(p21), .Y(new_n92_));
  NOR2x1_ASAP7_75t_R   g002(.A(p11), .B(p12), .Y(new_n93_));
  OAI21x1_ASAP7_75t_R  g003(.A1(p9), .A2(p8), .B(p10), .Y(new_n94_));
  NAND2x1_ASAP7_75t_R  g004(.A(p14), .B(p13), .Y(new_n95_));
  AOI21x1_ASAP7_75t_R  g005(.A1(new_n93_), .A2(new_n94_), .B(new_n95_), .Y(new_n96_));
  AO21x1_ASAP7_75t_R   g006(.A1(p16), .A2(p15), .B(p17), .Y(new_n97_));
  AOI21x1_ASAP7_75t_R  g007(.A1(p16), .A2(new_n96_), .B(new_n97_), .Y(new_n98_));
  AND2x2_ASAP7_75t_R   g008(.A(p23), .B(p24), .Y(new_n99_));
  INVx1_ASAP7_75t_R    g009(.A(new_n99_), .Y(new_n100_));
  AND2x2_ASAP7_75t_R   g010(.A(p19), .B(p18), .Y(new_n101_));
  INVx1_ASAP7_75t_R    g011(.A(new_n92_), .Y(new_n102_));
  OAI21x1_ASAP7_75t_R  g012(.A1(new_n101_), .A2(new_n102_), .B(p22), .Y(new_n103_));
  AOI211x1_ASAP7_75t_R g013(.A1(new_n92_), .A2(new_n98_), .B(new_n100_), .C(new_n103_), .Y(new_n104_));
  AND2x2_ASAP7_75t_R   g014(.A(p25), .B(new_n91_), .Y(new_n105_));
  AOI21x1_ASAP7_75t_R  g015(.A1(new_n91_), .A2(new_n104_), .B(new_n105_), .Y(new_n106_));
  OA21x2_ASAP7_75t_R   g016(.A1(p15), .A2(new_n96_), .B(p16), .Y(new_n107_));
  INVx1_ASAP7_75t_R    g017(.A(p7), .Y(new_n108_));
  AND3x1_ASAP7_75t_R   g018(.A(new_n92_), .B(p19), .C(p22), .Y(new_n109_));
  INVx1_ASAP7_75t_R    g019(.A(p1), .Y(new_n110_));
  INVx1_ASAP7_75t_R    g020(.A(p3), .Y(new_n111_));
  AND5x1_ASAP7_75t_R   g021(.A(new_n108_), .B(new_n109_), .C(p8), .D(new_n110_), .E(new_n111_), .Y(new_n112_));
  NAND2x1_ASAP7_75t_R  g022(.A(p15), .B(new_n96_), .Y(new_n113_));
  INVx1_ASAP7_75t_R    g023(.A(p9), .Y(new_n114_));
  INVx1_ASAP7_75t_R    g024(.A(new_n95_), .Y(new_n115_));
  AND5x1_ASAP7_75t_R   g025(.A(new_n114_), .B(new_n115_), .C(p10), .D(new_n99_), .E(new_n93_), .Y(new_n116_));
  INVx1_ASAP7_75t_R    g026(.A(p2), .Y(new_n117_));
  NOR2x1_ASAP7_75t_R   g027(.A(p5), .B(p0), .Y(new_n118_));
  NOR2x1_ASAP7_75t_R   g028(.A(p17), .B(p25), .Y(new_n119_));
  NOR2x1_ASAP7_75t_R   g029(.A(p4), .B(p6), .Y(new_n120_));
  AND5x1_ASAP7_75t_R   g030(.A(new_n117_), .B(new_n118_), .C(new_n119_), .D(new_n120_), .E(p18), .Y(new_n121_));
  AND5x1_ASAP7_75t_R   g031(.A(new_n107_), .B(new_n112_), .C(new_n113_), .D(new_n116_), .E(new_n121_), .Y(new_n122_));
  AO21x1_ASAP7_75t_R   g032(.A1(p22), .A2(new_n102_), .B(p23), .Y(new_n123_));
  AND3x1_ASAP7_75t_R   g033(.A(p0), .B(p7), .C(p1), .Y(new_n124_));
  AND3x1_ASAP7_75t_R   g034(.A(new_n91_), .B(new_n124_), .C(p3), .Y(new_n125_));
  INVx1_ASAP7_75t_R    g035(.A(p8), .Y(new_n126_));
  AND3x1_ASAP7_75t_R   g036(.A(new_n93_), .B(new_n114_), .C(new_n126_), .Y(new_n127_));
  NAND3x1_ASAP7_75t_R  g037(.A(new_n125_), .B(new_n127_), .C(new_n109_), .Y(new_n128_));
  AND2x2_ASAP7_75t_R   g038(.A(p13), .B(p59), .Y(new_n129_));
  INVx1_ASAP7_75t_R    g039(.A(p25), .Y(new_n130_));
  AND3x1_ASAP7_75t_R   g040(.A(new_n129_), .B(new_n130_), .C(p5), .Y(new_n131_));
  AND2x2_ASAP7_75t_R   g041(.A(p18), .B(p4), .Y(new_n132_));
  AND3x1_ASAP7_75t_R   g042(.A(new_n132_), .B(p6), .C(p24), .Y(new_n133_));
  INVx1_ASAP7_75t_R    g043(.A(p15), .Y(new_n134_));
  AND5x1_ASAP7_75t_R   g044(.A(p16), .B(new_n134_), .C(p10), .D(p2), .E(p14), .Y(new_n135_));
  NAND3x1_ASAP7_75t_R  g045(.A(new_n131_), .B(new_n133_), .C(new_n135_), .Y(new_n136_));
  AO21x1_ASAP7_75t_R   g046(.A1(p16), .A2(new_n96_), .B(new_n97_), .Y(new_n137_));
  NOR3x1_ASAP7_75t_R   g047(.A(new_n128_), .B(new_n136_), .C(new_n137_), .Y(new_n138_));
  NAND2x1_ASAP7_75t_R  g048(.A(new_n123_), .B(new_n138_), .Y(new_n139_));
  NAND2x1_ASAP7_75t_R  g049(.A(new_n139_), .B(new_n106_), .Y(new_n140_));
  OAI21x1_ASAP7_75t_R  g050(.A1(new_n106_), .A2(new_n122_), .B(new_n140_), .Y(o0));
  INVx1_ASAP7_75t_R    g051(.A(new_n105_), .Y(new_n142_));
  AOI21x1_ASAP7_75t_R  g052(.A1(new_n92_), .A2(new_n98_), .B(new_n103_), .Y(new_n143_));
  NAND3x1_ASAP7_75t_R  g053(.A(new_n143_), .B(new_n91_), .C(new_n99_), .Y(new_n144_));
  AOI21x1_ASAP7_75t_R  g054(.A1(new_n142_), .A2(new_n144_), .B(new_n122_), .Y(new_n145_));
  AND2x2_ASAP7_75t_R   g055(.A(p49), .B(p48), .Y(new_n146_));
  INVx1_ASAP7_75t_R    g056(.A(new_n146_), .Y(new_n147_));
  NOR2x1_ASAP7_75t_R   g057(.A(p42), .B(p41), .Y(new_n148_));
  OAI21x1_ASAP7_75t_R  g058(.A1(p38), .A2(p39), .B(p40), .Y(new_n149_));
  NAND2x1_ASAP7_75t_R  g059(.A(p44), .B(p43), .Y(new_n150_));
  AOI21x1_ASAP7_75t_R  g060(.A1(new_n148_), .A2(new_n149_), .B(new_n150_), .Y(new_n151_));
  AO21x1_ASAP7_75t_R   g061(.A1(p46), .A2(p45), .B(p47), .Y(new_n152_));
  AOI21x1_ASAP7_75t_R  g062(.A1(p46), .A2(new_n151_), .B(new_n152_), .Y(new_n153_));
  INVx1_ASAP7_75t_R    g063(.A(p51), .Y(new_n154_));
  NAND2x1_ASAP7_75t_R  g064(.A(p52), .B(new_n154_), .Y(new_n155_));
  OAI21x1_ASAP7_75t_R  g065(.A1(new_n147_), .A2(new_n153_), .B(new_n155_), .Y(new_n156_));
  NAND2x1_ASAP7_75t_R  g066(.A(p46), .B(p45), .Y(new_n157_));
  OAI21x1_ASAP7_75t_R  g067(.A1(p48), .A2(new_n157_), .B(new_n152_), .Y(new_n158_));
  AND2x2_ASAP7_75t_R   g068(.A(p46), .B(p44), .Y(new_n159_));
  AND3x1_ASAP7_75t_R   g069(.A(new_n159_), .B(p49), .C(p40), .Y(new_n160_));
  AND2x2_ASAP7_75t_R   g070(.A(p34), .B(p33), .Y(new_n161_));
  AND3x1_ASAP7_75t_R   g071(.A(new_n161_), .B(p35), .C(p36), .Y(new_n162_));
  OR2x4_ASAP7_75t_R    g072(.A(p47), .B(p48), .Y(new_n163_));
  NOR2x1_ASAP7_75t_R   g073(.A(p38), .B(p39), .Y(new_n164_));
  AND3x1_ASAP7_75t_R   g074(.A(new_n164_), .B(p54), .C(p53), .Y(new_n165_));
  AND5x1_ASAP7_75t_R   g075(.A(new_n158_), .B(new_n160_), .C(new_n162_), .D(new_n163_), .E(new_n165_), .Y(new_n166_));
  INVx1_ASAP7_75t_R    g076(.A(p43), .Y(new_n167_));
  AO21x1_ASAP7_75t_R   g077(.A1(new_n148_), .A2(new_n149_), .B(new_n167_), .Y(new_n168_));
  AND2x2_ASAP7_75t_R   g078(.A(p37), .B(p31), .Y(new_n169_));
  INVx1_ASAP7_75t_R    g079(.A(p45), .Y(new_n170_));
  AND3x1_ASAP7_75t_R   g080(.A(new_n169_), .B(p29), .C(new_n170_), .Y(new_n171_));
  AND3x1_ASAP7_75t_R   g081(.A(p58), .B(p56), .C(p57), .Y(new_n172_));
  NAND2x1_ASAP7_75t_R  g082(.A(p42), .B(p41), .Y(new_n173_));
  OAI21x1_ASAP7_75t_R  g083(.A1(new_n173_), .A2(new_n149_), .B(new_n167_), .Y(new_n174_));
  INVx1_ASAP7_75t_R    g084(.A(p55), .Y(new_n175_));
  AND3x1_ASAP7_75t_R   g085(.A(new_n175_), .B(p30), .C(p32), .Y(new_n176_));
  AND5x1_ASAP7_75t_R   g086(.A(new_n168_), .B(new_n171_), .C(new_n172_), .D(new_n174_), .E(new_n176_), .Y(new_n177_));
  NAND3x1_ASAP7_75t_R  g087(.A(new_n156_), .B(new_n166_), .C(new_n177_), .Y(new_n178_));
  AND3x1_ASAP7_75t_R   g088(.A(p52), .B(p54), .C(p53), .Y(new_n179_));
  OA21x2_ASAP7_75t_R   g089(.A1(p55), .A2(new_n179_), .B(new_n172_), .Y(new_n180_));
  NOR2x1_ASAP7_75t_R   g090(.A(p50), .B(p51), .Y(new_n181_));
  AND2x2_ASAP7_75t_R   g091(.A(new_n175_), .B(new_n181_), .Y(new_n182_));
  OAI21x1_ASAP7_75t_R  g092(.A1(new_n147_), .A2(new_n153_), .B(new_n182_), .Y(new_n183_));
  NOR2x1_ASAP7_75t_R   g093(.A(p50), .B(p59), .Y(new_n184_));
  AOI21x1_ASAP7_75t_R  g094(.A1(new_n180_), .A2(new_n183_), .B(new_n184_), .Y(new_n185_));
  NAND2x1_ASAP7_75t_R  g095(.A(p38), .B(p40), .Y(new_n186_));
  NOR3x1_ASAP7_75t_R   g096(.A(new_n186_), .B(p50), .C(p36), .Y(new_n187_));
  AND2x2_ASAP7_75t_R   g097(.A(p56), .B(p43), .Y(new_n188_));
  NOR2x1_ASAP7_75t_R   g098(.A(p39), .B(p45), .Y(new_n189_));
  NOR2x1_ASAP7_75t_R   g099(.A(p37), .B(p55), .Y(new_n190_));
  INVx1_ASAP7_75t_R    g100(.A(p44), .Y(new_n191_));
  NOR2x1_ASAP7_75t_R   g101(.A(p42), .B(new_n191_), .Y(new_n192_));
  AND5x1_ASAP7_75t_R   g102(.A(new_n187_), .B(new_n188_), .C(new_n189_), .D(new_n190_), .E(new_n192_), .Y(new_n193_));
  INVx1_ASAP7_75t_R    g103(.A(p41), .Y(new_n194_));
  NOR2x1_ASAP7_75t_R   g104(.A(new_n194_), .B(new_n149_), .Y(new_n195_));
  OR4x2_ASAP7_75t_R    g105(.A(p33), .B(p31), .C(p30), .D(p32), .Y(new_n196_));
  NOR3x1_ASAP7_75t_R   g106(.A(new_n195_), .B(new_n196_), .C(new_n155_), .Y(new_n197_));
  NOR2x1_ASAP7_75t_R   g107(.A(p34), .B(p35), .Y(new_n198_));
  AND2x2_ASAP7_75t_R   g108(.A(p54), .B(p53), .Y(new_n199_));
  NAND2x1_ASAP7_75t_R  g109(.A(new_n198_), .B(new_n199_), .Y(new_n200_));
  NAND2x1_ASAP7_75t_R  g110(.A(p46), .B(p47), .Y(new_n201_));
  NAND2x1_ASAP7_75t_R  g111(.A(new_n201_), .B(new_n146_), .Y(new_n202_));
  AOI211x1_ASAP7_75t_R g112(.A1(new_n194_), .A2(new_n149_), .B(new_n200_), .C(new_n202_), .Y(new_n203_));
  NAND3x1_ASAP7_75t_R  g113(.A(new_n193_), .B(new_n197_), .C(new_n203_), .Y(new_n204_));
  NAND2x1_ASAP7_75t_R  g114(.A(p47), .B(new_n170_), .Y(new_n205_));
  NOR2x1_ASAP7_75t_R   g115(.A(new_n205_), .B(new_n151_), .Y(new_n206_));
  INVx1_ASAP7_75t_R    g116(.A(new_n157_), .Y(new_n207_));
  AO21x1_ASAP7_75t_R   g117(.A1(p46), .A2(new_n151_), .B(new_n207_), .Y(new_n208_));
  NOR2x1_ASAP7_75t_R   g118(.A(p29), .B(p59), .Y(new_n209_));
  OAI21x1_ASAP7_75t_R  g119(.A1(new_n206_), .A2(new_n208_), .B(new_n209_), .Y(new_n210_));
  INVx1_ASAP7_75t_R    g120(.A(p46), .Y(new_n211_));
  AOI211x1_ASAP7_75t_R g121(.A1(new_n148_), .A2(new_n149_), .B(new_n211_), .C(new_n150_), .Y(new_n212_));
  OAI21x1_ASAP7_75t_R  g122(.A1(new_n152_), .A2(new_n212_), .B(new_n146_), .Y(new_n213_));
  INVx1_ASAP7_75t_R    g123(.A(new_n180_), .Y(new_n214_));
  AOI21x1_ASAP7_75t_R  g124(.A1(new_n182_), .A2(new_n213_), .B(new_n214_), .Y(new_n215_));
  OAI21x1_ASAP7_75t_R  g125(.A1(new_n204_), .A2(new_n210_), .B(new_n215_), .Y(new_n216_));
  OAI21x1_ASAP7_75t_R  g126(.A1(new_n178_), .A2(new_n185_), .B(new_n216_), .Y(new_n217_));
  OAI21x1_ASAP7_75t_R  g127(.A1(new_n145_), .A2(new_n217_), .B(new_n140_), .Y(o1));
  AND2x2_ASAP7_75t_R   g128(.A(p29), .B(p59), .Y(new_n219_));
  AND2x2_ASAP7_75t_R   g129(.A(p38), .B(p40), .Y(new_n220_));
  NOR2x1_ASAP7_75t_R   g130(.A(p36), .B(p33), .Y(new_n221_));
  AND5x1_ASAP7_75t_R   g131(.A(p56), .B(new_n220_), .C(p44), .D(new_n198_), .E(new_n221_), .Y(new_n222_));
  NOR2x1_ASAP7_75t_R   g132(.A(p45), .B(p30), .Y(new_n223_));
  NOR2x1_ASAP7_75t_R   g133(.A(p55), .B(p32), .Y(new_n224_));
  NOR2x1_ASAP7_75t_R   g134(.A(p39), .B(p31), .Y(new_n225_));
  INVx1_ASAP7_75t_R    g135(.A(p37), .Y(new_n226_));
  AND5x1_ASAP7_75t_R   g136(.A(p43), .B(new_n223_), .C(new_n224_), .D(new_n225_), .E(new_n226_), .Y(new_n227_));
  AND5x1_ASAP7_75t_R   g137(.A(p49), .B(new_n148_), .C(new_n181_), .D(new_n201_), .E(p48), .Y(new_n228_));
  AND5x1_ASAP7_75t_R   g138(.A(p52), .B(new_n222_), .C(new_n199_), .D(new_n227_), .E(new_n228_), .Y(new_n229_));
  OAI21x1_ASAP7_75t_R  g139(.A1(new_n206_), .A2(new_n208_), .B(new_n229_), .Y(new_n230_));
  OAI21x1_ASAP7_75t_R  g140(.A1(new_n219_), .A2(new_n230_), .B(new_n215_), .Y(new_n231_));
  AOI211x1_ASAP7_75t_R g141(.A1(new_n106_), .A2(new_n139_), .B(new_n231_), .C(new_n145_), .Y(o2));
  assign               o3 = 1'b0;
  assign               o4 = 1'b0;
  assign               o5 = 1'b0;
  assign               o6 = 1'b0;
  assign               o7 = 1'b0;
  assign               o8 = 1'b0;
  assign               o9 = 1'b0;
  assign               o10 = 1'b0;
  assign               o11 = 1'b0;
  assign               o12 = 1'b0;
  assign               o13 = 1'b0;
  assign               o14 = 1'b0;
  assign               o15 = 1'b0;
  assign               o16 = 1'b0;
  assign               o17 = 1'b0;
  assign               o18 = 1'b0;
  assign               o19 = 1'b0;
  assign               o20 = 1'b0;
  assign               o21 = 1'b0;
  assign               o22 = 1'b0;
  assign               o23 = 1'b0;
  assign               o24 = 1'b0;
  assign               o25 = 1'b0;
  assign               o26 = 1'b0;
  assign               o27 = 1'b0;
  assign               o28 = 1'b0;
  assign               o29 = 1'b0;
endmodule


