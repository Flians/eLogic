// Benchmark "/tmp/" written by ABC on Tue Oct 20 18:11:47 2026

module \/tmp/  ( 
    p8, p21, p13, p38, p23, p43, p47, p4, p31, p42, p54, p16, p36, p46,
    p29, p56, p34, p44, p2, p37, p11, p27, p45, p53, p39, p28, p25, p40,
    p58, p22, p59, p19, p50, p15, p32, p3, p49, p7, p35, p55, p9, p57, p24,
    p33, p10, p6, p26, p12, p0, p20, p18, p51, p1, p48, p30, p17, p41, p52,
    p5, p14,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25, o26, o27, o28, o29  );
  input  p8, p21, p13, p38, p23, p43, p47, p4, p31, p42, p54, p16, p36,
    p46, p29, p56, p34, p44, p2, p37, p11, p27, p45, p53, p39, p28, p25,
    p40, p58, p22, p59, p19, p50, p15, p32, p3, p49, p7, p35, p55, p9, p57,
    p24, p33, p10, p6, p26, p12, p0, p20, p18, p51, p1, p48, p30, p17, p41,
    p52, p5, p14;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25, o26, o27, o28, o29;
  wire new_n91_, new_n92_, new_n93_, new_n94_, new_n95_, new_n96_, new_n97_,
    new_n98_, new_n99_, new_n100_, new_n101_, new_n102_, new_n103_,
    new_n104_, new_n105_, new_n106_, new_n107_, new_n108_, new_n109_,
    new_n110_, new_n111_, new_n112_, new_n113_, new_n114_, new_n115_,
    new_n116_, new_n117_, new_n118_, new_n119_, new_n120_, new_n121_,
    new_n122_, new_n123_, new_n124_, new_n125_, new_n126_, new_n127_,
    new_n128_, new_n129_, new_n130_, new_n131_, new_n132_, new_n133_,
    new_n134_, new_n135_, new_n136_, new_n137_, new_n138_, new_n139_,
    new_n140_, new_n141_, new_n142_, new_n143_, new_n145_, new_n146_,
    new_n147_, new_n148_, new_n149_, new_n150_, new_n151_, new_n152_,
    new_n153_, new_n154_, new_n155_, new_n156_, new_n157_, new_n158_,
    new_n159_, new_n160_, new_n161_, new_n162_, new_n163_, new_n164_,
    new_n165_, new_n166_, new_n167_, new_n168_, new_n169_, new_n170_,
    new_n171_, new_n172_, new_n173_, new_n174_, new_n175_, new_n176_,
    new_n177_, new_n178_, new_n179_, new_n180_, new_n181_, new_n182_,
    new_n183_, new_n184_, new_n185_, new_n186_, new_n187_, new_n188_,
    new_n189_, new_n190_, new_n191_, new_n192_, new_n193_, new_n194_,
    new_n195_, new_n196_, new_n197_, new_n198_, new_n199_, new_n200_,
    new_n201_, new_n202_, new_n203_, new_n204_, new_n205_, new_n206_,
    new_n207_, new_n208_, new_n209_, new_n210_, new_n211_, new_n212_,
    new_n213_, new_n214_, new_n215_, new_n216_, new_n217_, new_n218_,
    new_n219_, new_n220_, new_n221_, new_n222_, new_n223_, new_n224_,
    new_n225_, new_n226_, new_n227_, new_n228_, new_n229_, new_n230_,
    new_n231_, new_n232_, new_n233_, new_n234_, new_n235_, new_n237_,
    new_n238_, new_n239_, new_n240_, new_n241_, new_n242_, new_n243_,
    new_n244_, new_n245_, new_n246_, new_n247_, new_n248_, new_n249_,
    new_n250_, new_n251_, new_n252_, new_n253_, new_n254_, new_n255_,
    new_n256_, new_n257_, new_n258_;
  AND3x1_ASAP7_75t_R   g000(.A(p27), .B(p28), .C(p26), .Y(new_n91_));
  NOR2x1_ASAP7_75t_R   g001(.A(p21), .B(p20), .Y(new_n92_));
  NOR2x1_ASAP7_75t_R   g002(.A(p11), .B(p12), .Y(new_n93_));
  OAI21x1_ASAP7_75t_R  g003(.A1(p8), .A2(p9), .B(p10), .Y(new_n94_));
  NAND2x1_ASAP7_75t_R  g004(.A(p13), .B(p14), .Y(new_n95_));
  AOI21x1_ASAP7_75t_R  g005(.A1(new_n93_), .A2(new_n94_), .B(new_n95_), .Y(new_n96_));
  AO21x1_ASAP7_75t_R   g006(.A1(p16), .A2(p15), .B(p17), .Y(new_n97_));
  AOI21x1_ASAP7_75t_R  g007(.A1(p16), .A2(new_n96_), .B(new_n97_), .Y(new_n98_));
  AND2x2_ASAP7_75t_R   g008(.A(p23), .B(p24), .Y(new_n99_));
  INVx1_ASAP7_75t_R    g009(.A(new_n99_), .Y(new_n100_));
  AND2x2_ASAP7_75t_R   g010(.A(p19), .B(p18), .Y(new_n101_));
  INVx1_ASAP7_75t_R    g011(.A(new_n92_), .Y(new_n102_));
  OAI21x1_ASAP7_75t_R  g012(.A1(new_n101_), .A2(new_n102_), .B(p22), .Y(new_n103_));
  AOI211x1_ASAP7_75t_R g013(.A1(new_n92_), .A2(new_n98_), .B(new_n100_), .C(new_n103_), .Y(new_n104_));
  AND2x2_ASAP7_75t_R   g014(.A(p25), .B(new_n91_), .Y(new_n105_));
  AO21x1_ASAP7_75t_R   g015(.A1(new_n91_), .A2(new_n104_), .B(new_n105_), .Y(new_n106_));
  INVx1_ASAP7_75t_R    g016(.A(p14), .Y(new_n107_));
  INVx1_ASAP7_75t_R    g017(.A(p13), .Y(new_n108_));
  AO21x1_ASAP7_75t_R   g018(.A1(new_n93_), .A2(new_n94_), .B(new_n108_), .Y(new_n109_));
  AO21x1_ASAP7_75t_R   g019(.A1(new_n107_), .A2(new_n109_), .B(new_n96_), .Y(new_n110_));
  INVx1_ASAP7_75t_R    g020(.A(p1), .Y(new_n111_));
  INVx1_ASAP7_75t_R    g021(.A(p25), .Y(new_n112_));
  NOR2x1_ASAP7_75t_R   g022(.A(p6), .B(p12), .Y(new_n113_));
  INVx1_ASAP7_75t_R    g023(.A(p9), .Y(new_n114_));
  INVx1_ASAP7_75t_R    g024(.A(p0), .Y(new_n115_));
  AND5x1_ASAP7_75t_R   g025(.A(new_n112_), .B(new_n113_), .C(new_n114_), .D(new_n115_), .E(p18), .Y(new_n116_));
  NOR2x1_ASAP7_75t_R   g026(.A(p17), .B(p5), .Y(new_n117_));
  OR2x4_ASAP7_75t_R    g027(.A(p8), .B(p9), .Y(new_n118_));
  INVx1_ASAP7_75t_R    g028(.A(p10), .Y(new_n119_));
  NAND2x1_ASAP7_75t_R  g029(.A(p11), .B(new_n119_), .Y(new_n120_));
  AOI22x1_ASAP7_75t_R  g030(.A1(new_n118_), .A2(p11), .B1(new_n120_), .B2(new_n94_), .Y(new_n121_));
  AND5x1_ASAP7_75t_R   g031(.A(new_n110_), .B(new_n111_), .C(new_n116_), .D(new_n117_), .E(new_n121_), .Y(new_n122_));
  OA21x2_ASAP7_75t_R   g032(.A1(p15), .A2(new_n96_), .B(p16), .Y(new_n123_));
  NAND2x1_ASAP7_75t_R  g033(.A(p15), .B(new_n96_), .Y(new_n124_));
  AND2x2_ASAP7_75t_R   g034(.A(p22), .B(p19), .Y(new_n125_));
  INVx1_ASAP7_75t_R    g035(.A(p4), .Y(new_n126_));
  INVx1_ASAP7_75t_R    g036(.A(p2), .Y(new_n127_));
  AND5x1_ASAP7_75t_R   g037(.A(p8), .B(new_n99_), .C(p13), .D(new_n126_), .E(new_n127_), .Y(new_n128_));
  NOR2x1_ASAP7_75t_R   g038(.A(p3), .B(p7), .Y(new_n129_));
  AND5x1_ASAP7_75t_R   g039(.A(new_n92_), .B(new_n124_), .C(new_n125_), .D(new_n128_), .E(new_n129_), .Y(new_n130_));
  NAND3x1_ASAP7_75t_R  g040(.A(new_n122_), .B(new_n123_), .C(new_n130_), .Y(new_n131_));
  AO21x1_ASAP7_75t_R   g041(.A1(p22), .A2(new_n102_), .B(p23), .Y(new_n132_));
  INVx1_ASAP7_75t_R    g042(.A(p3), .Y(new_n133_));
  NOR2x1_ASAP7_75t_R   g043(.A(p15), .B(new_n133_), .Y(new_n134_));
  AND2x2_ASAP7_75t_R   g044(.A(p4), .B(p2), .Y(new_n135_));
  AND5x1_ASAP7_75t_R   g045(.A(new_n112_), .B(new_n134_), .C(p59), .D(new_n93_), .E(new_n135_), .Y(new_n136_));
  AND4x2_ASAP7_75t_R   g046(.A(p0), .B(p18), .C(p1), .D(p5), .Y(new_n137_));
  AND5x1_ASAP7_75t_R   g047(.A(p7), .B(new_n137_), .C(p24), .D(p10), .E(p6), .Y(new_n138_));
  AND3x1_ASAP7_75t_R   g048(.A(new_n91_), .B(new_n125_), .C(new_n92_), .Y(new_n139_));
  NOR2x1_ASAP7_75t_R   g049(.A(p16), .B(p15), .Y(new_n140_));
  NOR3x1_ASAP7_75t_R   g050(.A(new_n118_), .B(new_n95_), .C(new_n140_), .Y(new_n141_));
  AND5x1_ASAP7_75t_R   g051(.A(new_n98_), .B(new_n136_), .C(new_n138_), .D(new_n139_), .E(new_n141_), .Y(new_n142_));
  AOI221x1_ASAP7_75t_R g052(.A1(new_n104_), .A2(new_n91_), .B1(new_n132_), .B2(new_n142_), .C(new_n105_), .Y(new_n143_));
  AO21x1_ASAP7_75t_R   g053(.A1(new_n106_), .A2(new_n131_), .B(new_n143_), .Y(o0));
  INVx1_ASAP7_75t_R    g054(.A(new_n91_), .Y(new_n145_));
  AOI21x1_ASAP7_75t_R  g055(.A1(new_n92_), .A2(new_n98_), .B(new_n103_), .Y(new_n146_));
  AOI21x1_ASAP7_75t_R  g056(.A1(new_n99_), .A2(new_n146_), .B(p25), .Y(new_n147_));
  NAND2x1_ASAP7_75t_R  g057(.A(new_n132_), .B(new_n142_), .Y(new_n148_));
  OAI21x1_ASAP7_75t_R  g058(.A1(new_n145_), .A2(new_n147_), .B(new_n148_), .Y(new_n149_));
  INVx1_ASAP7_75t_R    g059(.A(p55), .Y(new_n150_));
  AND2x2_ASAP7_75t_R   g060(.A(p54), .B(p53), .Y(new_n151_));
  NAND2x1_ASAP7_75t_R  g061(.A(p52), .B(new_n151_), .Y(new_n152_));
  NAND3x1_ASAP7_75t_R  g062(.A(p56), .B(p58), .C(p57), .Y(new_n153_));
  AO21x1_ASAP7_75t_R   g063(.A1(new_n150_), .A2(new_n152_), .B(new_n153_), .Y(new_n154_));
  INVx1_ASAP7_75t_R    g064(.A(new_n154_), .Y(new_n155_));
  NAND2x1_ASAP7_75t_R  g065(.A(p49), .B(p48), .Y(new_n156_));
  NOR2x1_ASAP7_75t_R   g066(.A(p42), .B(p41), .Y(new_n157_));
  OAI21x1_ASAP7_75t_R  g067(.A1(p38), .A2(p39), .B(p40), .Y(new_n158_));
  NAND2x1_ASAP7_75t_R  g068(.A(p43), .B(p44), .Y(new_n159_));
  AOI21x1_ASAP7_75t_R  g069(.A1(new_n157_), .A2(new_n158_), .B(new_n159_), .Y(new_n160_));
  AO21x1_ASAP7_75t_R   g070(.A1(p46), .A2(p45), .B(p47), .Y(new_n161_));
  AOI21x1_ASAP7_75t_R  g071(.A1(p46), .A2(new_n160_), .B(new_n161_), .Y(new_n162_));
  INVx1_ASAP7_75t_R    g072(.A(p50), .Y(new_n163_));
  INVx1_ASAP7_75t_R    g073(.A(p51), .Y(new_n164_));
  AND3x1_ASAP7_75t_R   g074(.A(new_n163_), .B(new_n150_), .C(new_n164_), .Y(new_n165_));
  OAI21x1_ASAP7_75t_R  g075(.A1(new_n156_), .A2(new_n162_), .B(new_n165_), .Y(new_n166_));
  NOR2x1_ASAP7_75t_R   g076(.A(p59), .B(p50), .Y(new_n167_));
  AOI21x1_ASAP7_75t_R  g077(.A1(new_n155_), .A2(new_n166_), .B(new_n167_), .Y(new_n168_));
  NAND2x1_ASAP7_75t_R  g078(.A(p52), .B(new_n164_), .Y(new_n169_));
  OAI21x1_ASAP7_75t_R  g079(.A1(new_n156_), .A2(new_n162_), .B(new_n169_), .Y(new_n170_));
  NAND2x1_ASAP7_75t_R  g080(.A(p33), .B(p30), .Y(new_n171_));
  NAND2x1_ASAP7_75t_R  g081(.A(p40), .B(p35), .Y(new_n172_));
  NAND2x1_ASAP7_75t_R  g082(.A(p32), .B(p49), .Y(new_n173_));
  OR5x1_ASAP7_75t_R    g083(.A(new_n153_), .B(p55), .C(new_n171_), .D(new_n172_), .E(new_n173_), .Y(new_n174_));
  NOR2x1_ASAP7_75t_R   g084(.A(p47), .B(p48), .Y(new_n175_));
  NAND2x1_ASAP7_75t_R  g085(.A(p54), .B(p53), .Y(new_n176_));
  OR4x2_ASAP7_75t_R    g086(.A(new_n175_), .B(new_n176_), .C(p38), .D(p39), .Y(new_n177_));
  INVx1_ASAP7_75t_R    g087(.A(p36), .Y(new_n178_));
  NAND2x1_ASAP7_75t_R  g088(.A(p44), .B(p37), .Y(new_n179_));
  INVx1_ASAP7_75t_R    g089(.A(p46), .Y(new_n180_));
  INVx1_ASAP7_75t_R    g090(.A(p34), .Y(new_n181_));
  OR5x1_ASAP7_75t_R    g091(.A(new_n178_), .B(new_n179_), .C(new_n180_), .D(new_n181_), .E(p45), .Y(new_n182_));
  NOR3x1_ASAP7_75t_R   g092(.A(new_n174_), .B(new_n177_), .C(new_n182_), .Y(new_n183_));
  INVx1_ASAP7_75t_R    g093(.A(p43), .Y(new_n184_));
  AO21x1_ASAP7_75t_R   g094(.A1(new_n157_), .A2(new_n158_), .B(new_n184_), .Y(new_n185_));
  NAND2x1_ASAP7_75t_R  g095(.A(p46), .B(p45), .Y(new_n186_));
  OAI21x1_ASAP7_75t_R  g096(.A1(p48), .A2(new_n186_), .B(new_n161_), .Y(new_n187_));
  NAND2x1_ASAP7_75t_R  g097(.A(p42), .B(p41), .Y(new_n188_));
  OAI21x1_ASAP7_75t_R  g098(.A1(new_n188_), .A2(new_n158_), .B(new_n184_), .Y(new_n189_));
  AND5x1_ASAP7_75t_R   g099(.A(p31), .B(new_n185_), .C(p29), .D(new_n187_), .E(new_n189_), .Y(new_n190_));
  NAND3x1_ASAP7_75t_R  g100(.A(new_n170_), .B(new_n183_), .C(new_n190_), .Y(new_n191_));
  INVx1_ASAP7_75t_R    g101(.A(p45), .Y(new_n192_));
  NAND2x1_ASAP7_75t_R  g102(.A(p47), .B(new_n192_), .Y(new_n193_));
  NOR2x1_ASAP7_75t_R   g103(.A(new_n193_), .B(new_n160_), .Y(new_n194_));
  INVx1_ASAP7_75t_R    g104(.A(new_n186_), .Y(new_n195_));
  AO21x1_ASAP7_75t_R   g105(.A1(p46), .A2(new_n160_), .B(new_n195_), .Y(new_n196_));
  NOR2x1_ASAP7_75t_R   g106(.A(p29), .B(p59), .Y(new_n197_));
  OAI21x1_ASAP7_75t_R  g107(.A1(new_n194_), .A2(new_n196_), .B(new_n197_), .Y(new_n198_));
  NOR2x1_ASAP7_75t_R   g108(.A(p36), .B(p37), .Y(new_n199_));
  AND3x1_ASAP7_75t_R   g109(.A(new_n199_), .B(p56), .C(new_n192_), .Y(new_n200_));
  INVx1_ASAP7_75t_R    g110(.A(p38), .Y(new_n201_));
  NOR3x1_ASAP7_75t_R   g111(.A(new_n159_), .B(new_n201_), .C(p42), .Y(new_n202_));
  INVx1_ASAP7_75t_R    g112(.A(p39), .Y(new_n203_));
  INVx1_ASAP7_75t_R    g113(.A(p40), .Y(new_n204_));
  NOR3x1_ASAP7_75t_R   g114(.A(new_n204_), .B(p50), .C(p55), .Y(new_n205_));
  AND4x2_ASAP7_75t_R   g115(.A(new_n200_), .B(new_n202_), .C(new_n203_), .D(new_n205_), .Y(new_n206_));
  INVx1_ASAP7_75t_R    g116(.A(p41), .Y(new_n207_));
  NOR2x1_ASAP7_75t_R   g117(.A(new_n207_), .B(new_n158_), .Y(new_n208_));
  OR4x2_ASAP7_75t_R    g118(.A(p32), .B(p35), .C(p33), .D(p30), .Y(new_n209_));
  NOR3x1_ASAP7_75t_R   g119(.A(new_n208_), .B(new_n169_), .C(new_n209_), .Y(new_n210_));
  NAND2x1_ASAP7_75t_R  g120(.A(p47), .B(p46), .Y(new_n211_));
  AND2x2_ASAP7_75t_R   g121(.A(p49), .B(p48), .Y(new_n212_));
  NAND2x1_ASAP7_75t_R  g122(.A(new_n211_), .B(new_n212_), .Y(new_n213_));
  OR3x1_ASAP7_75t_R    g123(.A(new_n176_), .B(p31), .C(p34), .Y(new_n214_));
  AOI211x1_ASAP7_75t_R g124(.A1(new_n207_), .A2(new_n158_), .B(new_n213_), .C(new_n214_), .Y(new_n215_));
  NAND3x1_ASAP7_75t_R  g125(.A(new_n206_), .B(new_n210_), .C(new_n215_), .Y(new_n216_));
  AOI211x1_ASAP7_75t_R g126(.A1(new_n157_), .A2(new_n158_), .B(new_n180_), .C(new_n159_), .Y(new_n217_));
  OAI21x1_ASAP7_75t_R  g127(.A1(new_n161_), .A2(new_n217_), .B(new_n212_), .Y(new_n218_));
  AOI21x1_ASAP7_75t_R  g128(.A1(new_n165_), .A2(new_n218_), .B(new_n154_), .Y(new_n219_));
  OAI21x1_ASAP7_75t_R  g129(.A1(new_n198_), .A2(new_n216_), .B(new_n219_), .Y(new_n220_));
  OAI21x1_ASAP7_75t_R  g130(.A1(new_n168_), .A2(new_n191_), .B(new_n220_), .Y(new_n221_));
  NOR2x1_ASAP7_75t_R   g131(.A(p12), .B(new_n108_), .Y(new_n222_));
  INVx1_ASAP7_75t_R    g132(.A(p17), .Y(new_n223_));
  AND3x1_ASAP7_75t_R   g133(.A(new_n222_), .B(p18), .C(new_n223_), .Y(new_n224_));
  INVx1_ASAP7_75t_R    g134(.A(p21), .Y(new_n225_));
  INVx1_ASAP7_75t_R    g135(.A(p20), .Y(new_n226_));
  AND5x1_ASAP7_75t_R   g136(.A(new_n225_), .B(new_n125_), .C(new_n115_), .D(new_n226_), .E(new_n111_), .Y(new_n227_));
  AND3x1_ASAP7_75t_R   g137(.A(new_n112_), .B(p23), .C(p24), .Y(new_n228_));
  NOR2x1_ASAP7_75t_R   g138(.A(p4), .B(p5), .Y(new_n229_));
  NOR2x1_ASAP7_75t_R   g139(.A(p2), .B(p3), .Y(new_n230_));
  NOR2x1_ASAP7_75t_R   g140(.A(p7), .B(p6), .Y(new_n231_));
  AND5x1_ASAP7_75t_R   g141(.A(p8), .B(new_n229_), .C(new_n230_), .D(new_n231_), .E(new_n114_), .Y(new_n232_));
  AND5x1_ASAP7_75t_R   g142(.A(new_n121_), .B(new_n224_), .C(new_n227_), .D(new_n228_), .E(new_n232_), .Y(new_n233_));
  AND3x1_ASAP7_75t_R   g143(.A(new_n110_), .B(new_n123_), .C(new_n124_), .Y(new_n234_));
  AOI211x1_ASAP7_75t_R g144(.A1(new_n233_), .A2(new_n234_), .B(new_n145_), .C(new_n147_), .Y(new_n235_));
  AOI21x1_ASAP7_75t_R  g145(.A1(new_n149_), .A2(new_n221_), .B(new_n235_), .Y(o1));
  NAND2x1_ASAP7_75t_R  g146(.A(new_n207_), .B(new_n158_), .Y(new_n237_));
  INVx1_ASAP7_75t_R    g147(.A(p35), .Y(new_n238_));
  NOR2x1_ASAP7_75t_R   g148(.A(p31), .B(p30), .Y(new_n239_));
  NOR2x1_ASAP7_75t_R   g149(.A(p32), .B(p33), .Y(new_n240_));
  AND5x1_ASAP7_75t_R   g150(.A(new_n181_), .B(new_n151_), .C(new_n238_), .D(new_n239_), .E(new_n240_), .Y(new_n241_));
  INVx1_ASAP7_75t_R    g151(.A(new_n208_), .Y(new_n242_));
  NOR2x1_ASAP7_75t_R   g152(.A(new_n156_), .B(new_n169_), .Y(new_n243_));
  AND5x1_ASAP7_75t_R   g153(.A(new_n237_), .B(new_n241_), .C(new_n242_), .D(new_n211_), .E(new_n243_), .Y(new_n244_));
  OR3x1_ASAP7_75t_R    g154(.A(new_n159_), .B(p42), .C(new_n204_), .Y(new_n245_));
  NOR2x1_ASAP7_75t_R   g155(.A(p45), .B(p50), .Y(new_n246_));
  AND3x1_ASAP7_75t_R   g156(.A(new_n246_), .B(p56), .C(new_n150_), .Y(new_n247_));
  AND3x1_ASAP7_75t_R   g157(.A(new_n199_), .B(p38), .C(new_n203_), .Y(new_n248_));
  NAND2x1_ASAP7_75t_R  g158(.A(new_n247_), .B(new_n248_), .Y(new_n249_));
  AOI211x1_ASAP7_75t_R g159(.A1(p29), .A2(p59), .B(new_n245_), .C(new_n249_), .Y(new_n250_));
  NOR2x1_ASAP7_75t_R   g160(.A(p45), .B(new_n160_), .Y(new_n251_));
  OAI22x1_ASAP7_75t_R  g161(.A1(new_n251_), .A2(new_n180_), .B1(new_n160_), .B2(new_n193_), .Y(new_n252_));
  NAND3x1_ASAP7_75t_R  g162(.A(new_n244_), .B(new_n250_), .C(new_n252_), .Y(new_n253_));
  INVx1_ASAP7_75t_R    g163(.A(new_n153_), .Y(new_n254_));
  NOR2x1_ASAP7_75t_R   g164(.A(p50), .B(p51), .Y(new_n255_));
  OA21x2_ASAP7_75t_R   g165(.A1(new_n255_), .A2(new_n152_), .B(new_n150_), .Y(new_n256_));
  OAI21x1_ASAP7_75t_R  g166(.A1(new_n152_), .A2(new_n218_), .B(new_n256_), .Y(new_n257_));
  NAND3x1_ASAP7_75t_R  g167(.A(new_n253_), .B(new_n254_), .C(new_n257_), .Y(new_n258_));
  AOI211x1_ASAP7_75t_R g168(.A1(new_n106_), .A2(new_n131_), .B(new_n143_), .C(new_n258_), .Y(o2));
  assign               o3 = 1'b0;
  assign               o4 = 1'b0;
  assign               o5 = 1'b0;
  assign               o6 = 1'b0;
  assign               o7 = 1'b0;
  assign               o8 = 1'b0;
  assign               o9 = 1'b0;
  assign               o10 = 1'b0;
  assign               o11 = 1'b0;
  assign               o12 = 1'b0;
  assign               o13 = 1'b0;
  assign               o14 = 1'b0;
  assign               o15 = 1'b0;
  assign               o16 = 1'b0;
  assign               o17 = 1'b0;
  assign               o18 = 1'b0;
  assign               o19 = 1'b0;
  assign               o20 = 1'b0;
  assign               o21 = 1'b0;
  assign               o22 = 1'b0;
  assign               o23 = 1'b0;
  assign               o24 = 1'b0;
  assign               o25 = 1'b0;
  assign               o26 = 1'b0;
  assign               o27 = 1'b0;
  assign               o28 = 1'b0;
  assign               o29 = 1'b0;
endmodule


