// Benchmark "/tmp/" written by ABC on Tue Oct 20 18:11:44 2026

module \/tmp/  ( 
    p29, p30, p59, p55, p5, p39, p50, p19, p13, p42, p21, p46, p6, p7, p48,
    p37, p33, p26, p15, p53, p23, p38, p52, p11, p51, p18, p22, p0, p43,
    p17, p10, p44, p27, p9, p20, p56, p32, p36, p47, p35, p12, p4, p14,
    p24, p1, p25, p41, p54, p57, p3, p8, p2, p49, p16, p28, p45, p40, p58,
    p34, p31,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25, o26, o27, o28, o29  );
  input  p29, p30, p59, p55, p5, p39, p50, p19, p13, p42, p21, p46, p6,
    p7, p48, p37, p33, p26, p15, p53, p23, p38, p52, p11, p51, p18, p22,
    p0, p43, p17, p10, p44, p27, p9, p20, p56, p32, p36, p47, p35, p12, p4,
    p14, p24, p1, p25, p41, p54, p57, p3, p8, p2, p49, p16, p28, p45, p40,
    p58, p34, p31;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25, o26, o27, o28, o29;
  wire new_n91_, new_n92_, new_n93_, new_n94_, new_n95_, new_n96_, new_n97_,
    new_n98_, new_n99_, new_n100_, new_n101_, new_n102_, new_n103_,
    new_n104_, new_n105_, new_n106_, new_n107_, new_n108_, new_n109_,
    new_n110_, new_n111_, new_n112_, new_n113_, new_n114_, new_n115_,
    new_n116_, new_n117_, new_n118_, new_n119_, new_n120_, new_n121_,
    new_n122_, new_n123_, new_n124_, new_n125_, new_n126_, new_n127_,
    new_n128_, new_n129_, new_n130_, new_n131_, new_n132_, new_n133_,
    new_n134_, new_n135_, new_n136_, new_n137_, new_n138_, new_n139_,
    new_n140_, new_n141_, new_n142_, new_n143_, new_n144_, new_n145_,
    new_n146_, new_n147_, new_n148_, new_n149_, new_n150_, new_n151_,
    new_n152_, new_n153_, new_n154_, new_n155_, new_n156_, new_n158_,
    new_n159_, new_n160_, new_n161_, new_n162_, new_n163_, new_n164_,
    new_n165_, new_n166_, new_n167_, new_n168_, new_n169_, new_n170_,
    new_n171_, new_n172_, new_n173_, new_n174_, new_n175_, new_n176_,
    new_n177_, new_n178_, new_n179_, new_n180_, new_n181_, new_n182_,
    new_n183_, new_n184_, new_n185_, new_n186_, new_n187_, new_n188_,
    new_n189_, new_n190_, new_n191_, new_n192_, new_n193_, new_n194_,
    new_n195_, new_n196_, new_n197_, new_n198_, new_n199_, new_n200_,
    new_n201_, new_n202_, new_n203_, new_n204_, new_n205_, new_n206_,
    new_n207_, new_n208_, new_n209_, new_n210_, new_n211_, new_n212_,
    new_n213_, new_n214_, new_n215_, new_n216_, new_n217_, new_n218_,
    new_n219_, new_n220_, new_n221_, new_n222_, new_n223_, new_n224_,
    new_n225_, new_n227_, new_n228_, new_n229_, new_n230_, new_n231_,
    new_n232_, new_n233_, new_n234_, new_n235_, new_n236_, new_n237_,
    new_n238_, new_n239_, new_n240_, new_n241_, new_n242_;
  AND3x1_ASAP7_75t_R   g000(.A(p23), .B(p22), .C(p24), .Y(new_n91_));
  AND2x2_ASAP7_75t_R   g001(.A(p19), .B(p18), .Y(new_n92_));
  INVx1_ASAP7_75t_R    g002(.A(new_n92_), .Y(new_n93_));
  NOR2x1_ASAP7_75t_R   g003(.A(p11), .B(p12), .Y(new_n94_));
  OAI21x1_ASAP7_75t_R  g004(.A1(p9), .A2(p8), .B(p10), .Y(new_n95_));
  NAND2x1_ASAP7_75t_R  g005(.A(p13), .B(p14), .Y(new_n96_));
  AOI21x1_ASAP7_75t_R  g006(.A1(new_n94_), .A2(new_n95_), .B(new_n96_), .Y(new_n97_));
  AO21x1_ASAP7_75t_R   g007(.A1(p15), .A2(p16), .B(p17), .Y(new_n98_));
  AOI21x1_ASAP7_75t_R  g008(.A1(p16), .A2(new_n97_), .B(new_n98_), .Y(new_n99_));
  NOR2x1_ASAP7_75t_R   g009(.A(p21), .B(p20), .Y(new_n100_));
  OAI21x1_ASAP7_75t_R  g010(.A1(new_n93_), .A2(new_n99_), .B(new_n100_), .Y(new_n101_));
  AOI21x1_ASAP7_75t_R  g011(.A1(new_n91_), .A2(new_n101_), .B(p25), .Y(new_n102_));
  INVx1_ASAP7_75t_R    g012(.A(p11), .Y(new_n103_));
  INVx1_ASAP7_75t_R    g013(.A(p10), .Y(new_n104_));
  NOR2x1_ASAP7_75t_R   g014(.A(p9), .B(p8), .Y(new_n105_));
  AOI21x1_ASAP7_75t_R  g015(.A1(new_n104_), .A2(new_n105_), .B(new_n103_), .Y(new_n106_));
  AOI21x1_ASAP7_75t_R  g016(.A1(new_n103_), .A2(new_n95_), .B(new_n106_), .Y(new_n107_));
  INVx1_ASAP7_75t_R    g017(.A(p18), .Y(new_n108_));
  NOR2x1_ASAP7_75t_R   g018(.A(p17), .B(new_n108_), .Y(new_n109_));
  INVx1_ASAP7_75t_R    g019(.A(p12), .Y(new_n110_));
  AND3x1_ASAP7_75t_R   g020(.A(new_n109_), .B(p13), .C(new_n110_), .Y(new_n111_));
  INVx1_ASAP7_75t_R    g021(.A(p25), .Y(new_n112_));
  AND3x1_ASAP7_75t_R   g022(.A(new_n112_), .B(p23), .C(p24), .Y(new_n113_));
  INVx1_ASAP7_75t_R    g023(.A(p9), .Y(new_n114_));
  NOR2x1_ASAP7_75t_R   g024(.A(p6), .B(p7), .Y(new_n115_));
  NOR2x1_ASAP7_75t_R   g025(.A(p3), .B(p2), .Y(new_n116_));
  NOR2x1_ASAP7_75t_R   g026(.A(p5), .B(p4), .Y(new_n117_));
  AND5x1_ASAP7_75t_R   g027(.A(new_n114_), .B(new_n115_), .C(new_n116_), .D(new_n117_), .E(p8), .Y(new_n118_));
  NOR2x1_ASAP7_75t_R   g028(.A(p0), .B(p1), .Y(new_n119_));
  INVx1_ASAP7_75t_R    g029(.A(p21), .Y(new_n120_));
  INVx1_ASAP7_75t_R    g030(.A(p20), .Y(new_n121_));
  AND5x1_ASAP7_75t_R   g031(.A(p19), .B(new_n119_), .C(new_n120_), .D(p22), .E(new_n121_), .Y(new_n122_));
  AND5x1_ASAP7_75t_R   g032(.A(new_n107_), .B(new_n111_), .C(new_n113_), .D(new_n118_), .E(new_n122_), .Y(new_n123_));
  INVx1_ASAP7_75t_R    g033(.A(p15), .Y(new_n124_));
  INVx1_ASAP7_75t_R    g034(.A(p13), .Y(new_n125_));
  AO21x1_ASAP7_75t_R   g035(.A1(new_n94_), .A2(new_n95_), .B(new_n125_), .Y(new_n126_));
  AO21x1_ASAP7_75t_R   g036(.A1(new_n124_), .A2(p14), .B(new_n126_), .Y(new_n127_));
  OA21x2_ASAP7_75t_R   g037(.A1(p15), .A2(new_n97_), .B(p16), .Y(new_n128_));
  NAND2x1_ASAP7_75t_R  g038(.A(p14), .B(new_n126_), .Y(new_n129_));
  AND3x1_ASAP7_75t_R   g039(.A(new_n127_), .B(new_n128_), .C(new_n129_), .Y(new_n130_));
  AND3x1_ASAP7_75t_R   g040(.A(p26), .B(p27), .C(p28), .Y(new_n131_));
  INVx1_ASAP7_75t_R    g041(.A(new_n131_), .Y(new_n132_));
  AO21x1_ASAP7_75t_R   g042(.A1(new_n123_), .A2(new_n130_), .B(new_n132_), .Y(new_n133_));
  AO21x1_ASAP7_75t_R   g043(.A1(p16), .A2(new_n97_), .B(new_n98_), .Y(new_n134_));
  AND3x1_ASAP7_75t_R   g044(.A(new_n95_), .B(p13), .C(new_n94_), .Y(new_n135_));
  AOI21x1_ASAP7_75t_R  g045(.A1(new_n94_), .A2(new_n95_), .B(p13), .Y(new_n136_));
  NOR2x1_ASAP7_75t_R   g046(.A(p15), .B(p16), .Y(new_n137_));
  INVx1_ASAP7_75t_R    g047(.A(new_n137_), .Y(new_n138_));
  OAI22x1_ASAP7_75t_R  g048(.A1(new_n135_), .A2(new_n136_), .B1(new_n97_), .B2(new_n138_), .Y(new_n139_));
  AND5x1_ASAP7_75t_R   g049(.A(new_n103_), .B(new_n110_), .C(new_n112_), .D(p18), .E(p24), .Y(new_n140_));
  AND2x2_ASAP7_75t_R   g050(.A(p14), .B(new_n124_), .Y(new_n141_));
  NAND3x1_ASAP7_75t_R  g051(.A(new_n140_), .B(new_n131_), .C(new_n141_), .Y(new_n142_));
  INVx1_ASAP7_75t_R    g052(.A(p7), .Y(new_n143_));
  NAND2x1_ASAP7_75t_R  g053(.A(p5), .B(p6), .Y(new_n144_));
  NAND2x1_ASAP7_75t_R  g054(.A(p4), .B(p3), .Y(new_n145_));
  NAND2x1_ASAP7_75t_R  g055(.A(p1), .B(p2), .Y(new_n146_));
  OR5x1_ASAP7_75t_R    g056(.A(new_n143_), .B(new_n144_), .C(new_n145_), .D(new_n146_), .E(new_n104_), .Y(new_n147_));
  AND3x1_ASAP7_75t_R   g057(.A(new_n105_), .B(p59), .C(p0), .Y(new_n148_));
  AND3x1_ASAP7_75t_R   g058(.A(new_n120_), .B(new_n121_), .C(p19), .Y(new_n149_));
  NAND3x1_ASAP7_75t_R  g059(.A(new_n148_), .B(p22), .C(new_n149_), .Y(new_n150_));
  OR5x1_ASAP7_75t_R    g060(.A(new_n134_), .B(new_n139_), .C(new_n142_), .D(new_n147_), .E(new_n150_), .Y(new_n151_));
  NOR2x1_ASAP7_75t_R   g061(.A(new_n93_), .B(new_n99_), .Y(new_n152_));
  INVx1_ASAP7_75t_R    g062(.A(new_n100_), .Y(new_n153_));
  AO21x1_ASAP7_75t_R   g063(.A1(p22), .A2(new_n153_), .B(p23), .Y(new_n154_));
  AOI21x1_ASAP7_75t_R  g064(.A1(p22), .A2(new_n152_), .B(new_n154_), .Y(new_n155_));
  OAI22x1_ASAP7_75t_R  g065(.A1(new_n102_), .A2(new_n132_), .B1(new_n151_), .B2(new_n155_), .Y(new_n156_));
  OAI21x1_ASAP7_75t_R  g066(.A1(new_n102_), .A2(new_n133_), .B(new_n156_), .Y(o0));
  INVx1_ASAP7_75t_R    g067(.A(p59), .Y(new_n158_));
  INVx1_ASAP7_75t_R    g068(.A(p50), .Y(new_n159_));
  INVx1_ASAP7_75t_R    g069(.A(p47), .Y(new_n160_));
  INVx1_ASAP7_75t_R    g070(.A(p45), .Y(new_n161_));
  NAND2x1_ASAP7_75t_R  g071(.A(new_n160_), .B(new_n161_), .Y(new_n162_));
  NOR2x1_ASAP7_75t_R   g072(.A(p42), .B(p41), .Y(new_n163_));
  OAI21x1_ASAP7_75t_R  g073(.A1(p39), .A2(p38), .B(p40), .Y(new_n164_));
  NAND2x1_ASAP7_75t_R  g074(.A(p43), .B(p44), .Y(new_n165_));
  AOI21x1_ASAP7_75t_R  g075(.A1(new_n163_), .A2(new_n164_), .B(new_n165_), .Y(new_n166_));
  INVx1_ASAP7_75t_R    g076(.A(p46), .Y(new_n167_));
  NAND2x1_ASAP7_75t_R  g077(.A(p48), .B(p49), .Y(new_n168_));
  AOI21x1_ASAP7_75t_R  g078(.A1(new_n167_), .A2(new_n160_), .B(new_n168_), .Y(new_n169_));
  OAI21x1_ASAP7_75t_R  g079(.A1(new_n162_), .A2(new_n166_), .B(new_n169_), .Y(new_n170_));
  INVx1_ASAP7_75t_R    g080(.A(p55), .Y(new_n171_));
  INVx1_ASAP7_75t_R    g081(.A(p51), .Y(new_n172_));
  AND3x1_ASAP7_75t_R   g082(.A(new_n171_), .B(new_n159_), .C(new_n172_), .Y(new_n173_));
  AND3x1_ASAP7_75t_R   g083(.A(p56), .B(p57), .C(p58), .Y(new_n174_));
  AND2x2_ASAP7_75t_R   g084(.A(p53), .B(p54), .Y(new_n175_));
  AO21x1_ASAP7_75t_R   g085(.A1(p52), .A2(new_n175_), .B(p55), .Y(new_n176_));
  NAND2x1_ASAP7_75t_R  g086(.A(new_n174_), .B(new_n176_), .Y(new_n177_));
  AOI21x1_ASAP7_75t_R  g087(.A1(new_n170_), .A2(new_n173_), .B(new_n177_), .Y(new_n178_));
  AOI21x1_ASAP7_75t_R  g088(.A1(new_n158_), .A2(new_n159_), .B(new_n178_), .Y(new_n179_));
  NAND2x1_ASAP7_75t_R  g089(.A(p42), .B(p41), .Y(new_n180_));
  INVx1_ASAP7_75t_R    g090(.A(p43), .Y(new_n181_));
  OAI21x1_ASAP7_75t_R  g091(.A1(new_n180_), .A2(new_n164_), .B(new_n181_), .Y(new_n182_));
  AND2x2_ASAP7_75t_R   g092(.A(p29), .B(p30), .Y(new_n183_));
  NOR2x1_ASAP7_75t_R   g093(.A(p39), .B(p38), .Y(new_n184_));
  AND5x1_ASAP7_75t_R   g094(.A(new_n171_), .B(new_n175_), .C(new_n183_), .D(p46), .E(new_n184_), .Y(new_n185_));
  INVx1_ASAP7_75t_R    g095(.A(p49), .Y(new_n186_));
  NOR2x1_ASAP7_75t_R   g096(.A(p45), .B(new_n186_), .Y(new_n187_));
  AND4x2_ASAP7_75t_R   g097(.A(p37), .B(p33), .C(p44), .D(p32), .Y(new_n188_));
  AND2x2_ASAP7_75t_R   g098(.A(p36), .B(p35), .Y(new_n189_));
  AND3x1_ASAP7_75t_R   g099(.A(new_n187_), .B(new_n188_), .C(new_n189_), .Y(new_n190_));
  AND2x2_ASAP7_75t_R   g100(.A(p40), .B(p34), .Y(new_n191_));
  AND3x1_ASAP7_75t_R   g101(.A(new_n174_), .B(new_n191_), .C(p31), .Y(new_n192_));
  AOI21x1_ASAP7_75t_R  g102(.A1(p48), .A2(new_n160_), .B(p45), .Y(new_n193_));
  INVx1_ASAP7_75t_R    g103(.A(p48), .Y(new_n194_));
  AOI21x1_ASAP7_75t_R  g104(.A1(p47), .A2(new_n194_), .B(new_n161_), .Y(new_n195_));
  NOR2x1_ASAP7_75t_R   g105(.A(new_n193_), .B(new_n195_), .Y(new_n196_));
  AND5x1_ASAP7_75t_R   g106(.A(new_n182_), .B(new_n185_), .C(new_n190_), .D(new_n192_), .E(new_n196_), .Y(new_n197_));
  INVx1_ASAP7_75t_R    g107(.A(p52), .Y(new_n198_));
  OAI21x1_ASAP7_75t_R  g108(.A1(new_n198_), .A2(p51), .B(new_n170_), .Y(new_n199_));
  AO21x1_ASAP7_75t_R   g109(.A1(new_n163_), .A2(new_n164_), .B(new_n181_), .Y(new_n200_));
  NAND3x1_ASAP7_75t_R  g110(.A(new_n197_), .B(new_n199_), .C(new_n200_), .Y(new_n201_));
  OAI21x1_ASAP7_75t_R  g111(.A1(p45), .A2(new_n166_), .B(new_n167_), .Y(new_n202_));
  INVx1_ASAP7_75t_R    g112(.A(new_n165_), .Y(new_n203_));
  NAND2x1_ASAP7_75t_R  g113(.A(new_n163_), .B(new_n164_), .Y(new_n204_));
  AO21x1_ASAP7_75t_R   g114(.A1(new_n203_), .A2(new_n204_), .B(new_n162_), .Y(new_n205_));
  NOR2x1_ASAP7_75t_R   g115(.A(p29), .B(p59), .Y(new_n206_));
  NAND3x1_ASAP7_75t_R  g116(.A(new_n202_), .B(new_n205_), .C(new_n206_), .Y(new_n207_));
  NOR2x1_ASAP7_75t_R   g117(.A(p45), .B(p34), .Y(new_n208_));
  AND4x2_ASAP7_75t_R   g118(.A(new_n172_), .B(p53), .C(p52), .D(p54), .Y(new_n209_));
  INVx1_ASAP7_75t_R    g119(.A(p37), .Y(new_n210_));
  INVx1_ASAP7_75t_R    g120(.A(p33), .Y(new_n211_));
  AND3x1_ASAP7_75t_R   g121(.A(new_n210_), .B(new_n211_), .C(p38), .Y(new_n212_));
  AOI21x1_ASAP7_75t_R  g122(.A1(p46), .A2(p47), .B(new_n165_), .Y(new_n213_));
  INVx1_ASAP7_75t_R    g123(.A(p40), .Y(new_n214_));
  NOR2x1_ASAP7_75t_R   g124(.A(p31), .B(new_n214_), .Y(new_n215_));
  AND5x1_ASAP7_75t_R   g125(.A(new_n208_), .B(new_n209_), .C(new_n212_), .D(new_n213_), .E(new_n215_), .Y(new_n216_));
  XNOR2x2_ASAP7_75t_R  g126(.A(p41), .B(new_n164_), .Y(new_n217_));
  INVx1_ASAP7_75t_R    g127(.A(p56), .Y(new_n218_));
  OR5x1_ASAP7_75t_R    g128(.A(new_n218_), .B(p42), .C(p32), .D(p36), .E(p35), .Y(new_n219_));
  OR4x2_ASAP7_75t_R    g129(.A(p30), .B(p55), .C(p39), .D(p50), .Y(new_n220_));
  NOR3x1_ASAP7_75t_R   g130(.A(new_n219_), .B(new_n168_), .C(new_n220_), .Y(new_n221_));
  NAND3x1_ASAP7_75t_R  g131(.A(new_n216_), .B(new_n217_), .C(new_n221_), .Y(new_n222_));
  OAI21x1_ASAP7_75t_R  g132(.A1(new_n207_), .A2(new_n222_), .B(new_n178_), .Y(new_n223_));
  OAI21x1_ASAP7_75t_R  g133(.A1(new_n179_), .A2(new_n201_), .B(new_n223_), .Y(new_n224_));
  AOI211x1_ASAP7_75t_R g134(.A1(new_n123_), .A2(new_n130_), .B(new_n132_), .C(new_n102_), .Y(new_n225_));
  AOI21x1_ASAP7_75t_R  g135(.A1(new_n156_), .A2(new_n224_), .B(new_n225_), .Y(o1));
  OR3x1_ASAP7_75t_R    g136(.A(new_n92_), .B(p21), .C(p20), .Y(new_n227_));
  OA211x2_ASAP7_75t_R  g137(.A1(new_n153_), .A2(new_n134_), .B(new_n227_), .C(new_n91_), .Y(new_n228_));
  OAI21x1_ASAP7_75t_R  g138(.A1(p25), .A2(new_n228_), .B(new_n131_), .Y(new_n229_));
  AND3x1_ASAP7_75t_R   g139(.A(new_n112_), .B(p3), .C(p2), .Y(new_n230_));
  AND5x1_ASAP7_75t_R   g140(.A(p10), .B(new_n230_), .C(p4), .D(p24), .E(p1), .Y(new_n231_));
  AND4x2_ASAP7_75t_R   g141(.A(p7), .B(p18), .C(p22), .D(p0), .Y(new_n232_));
  AND4x2_ASAP7_75t_R   g142(.A(p59), .B(p5), .C(p13), .D(p6), .Y(new_n233_));
  AND5x1_ASAP7_75t_R   g143(.A(new_n94_), .B(new_n141_), .C(new_n232_), .D(new_n233_), .E(new_n105_), .Y(new_n234_));
  AO21x1_ASAP7_75t_R   g144(.A1(new_n94_), .A2(new_n95_), .B(new_n96_), .Y(new_n235_));
  NAND2x1_ASAP7_75t_R  g145(.A(new_n137_), .B(new_n235_), .Y(new_n236_));
  AND5x1_ASAP7_75t_R   g146(.A(new_n131_), .B(new_n231_), .C(new_n234_), .D(new_n236_), .E(new_n149_), .Y(new_n237_));
  AO31x2_ASAP7_75t_R   g147(.A1(new_n134_), .A2(p22), .A3(new_n92_), .B(new_n154_), .Y(new_n238_));
  NAND3x1_ASAP7_75t_R  g148(.A(new_n237_), .B(new_n99_), .C(new_n238_), .Y(new_n239_));
  NAND2x1_ASAP7_75t_R  g149(.A(p29), .B(p59), .Y(new_n240_));
  NAND3x1_ASAP7_75t_R  g150(.A(new_n202_), .B(new_n205_), .C(new_n240_), .Y(new_n241_));
  OAI21x1_ASAP7_75t_R  g151(.A1(new_n241_), .A2(new_n222_), .B(new_n178_), .Y(new_n242_));
  AOI211x1_ASAP7_75t_R g152(.A1(new_n229_), .A2(new_n239_), .B(new_n242_), .C(new_n225_), .Y(o2));
  assign               o3 = 1'b0;
  assign               o4 = 1'b0;
  assign               o5 = 1'b0;
  assign               o6 = 1'b0;
  assign               o7 = 1'b0;
  assign               o8 = 1'b0;
  assign               o9 = 1'b0;
  assign               o10 = 1'b0;
  assign               o11 = 1'b0;
  assign               o12 = 1'b0;
  assign               o13 = 1'b0;
  assign               o14 = 1'b0;
  assign               o15 = 1'b0;
  assign               o16 = 1'b0;
  assign               o17 = 1'b0;
  assign               o18 = 1'b0;
  assign               o19 = 1'b0;
  assign               o20 = 1'b0;
  assign               o21 = 1'b0;
  assign               o22 = 1'b0;
  assign               o23 = 1'b0;
  assign               o24 = 1'b0;
  assign               o25 = 1'b0;
  assign               o26 = 1'b0;
  assign               o27 = 1'b0;
  assign               o28 = 1'b0;
  assign               o29 = 1'b0;
endmodule


