// Benchmark "/tmp/" written by ABC on Tue Oct 20 18:11:48 2026

module \/tmp/  ( 
    p33, p41, p9, p5, p50, p36, p16, p46, p54, p48, p59, p20, p12, p55,
    p17, p0, p24, p58, p21, p47, p57, p52, p43, p37, p19, p29, p15, p26,
    p22, p40, p3, p25, p53, p42, p28, p7, p44, p23, p35, p49, p13, p14, p8,
    p11, p34, p51, p45, p2, p1, p38, p18, p10, p31, p30, p32, p39, p6, p56,
    p4, p27,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25, o26, o27, o28, o29  );
  input  p33, p41, p9, p5, p50, p36, p16, p46, p54, p48, p59, p20, p12,
    p55, p17, p0, p24, p58, p21, p47, p57, p52, p43, p37, p19, p29, p15,
    p26, p22, p40, p3, p25, p53, p42, p28, p7, p44, p23, p35, p49, p13,
    p14, p8, p11, p34, p51, p45, p2, p1, p38, p18, p10, p31, p30, p32, p39,
    p6, p56, p4, p27;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25, o26, o27, o28, o29;
  wire new_n91_, new_n92_, new_n93_, new_n94_, new_n95_, new_n96_, new_n97_,
    new_n98_, new_n99_, new_n100_, new_n101_, new_n102_, new_n103_,
    new_n104_, new_n105_, new_n106_, new_n107_, new_n108_, new_n109_,
    new_n110_, new_n111_, new_n112_, new_n113_, new_n114_, new_n115_,
    new_n116_, new_n117_, new_n118_, new_n119_, new_n120_, new_n121_,
    new_n122_, new_n123_, new_n124_, new_n125_, new_n126_, new_n127_,
    new_n128_, new_n129_, new_n130_, new_n131_, new_n132_, new_n133_,
    new_n134_, new_n135_, new_n136_, new_n137_, new_n138_, new_n139_,
    new_n140_, new_n141_, new_n143_, new_n144_, new_n145_, new_n146_,
    new_n147_, new_n148_, new_n149_, new_n150_, new_n151_, new_n152_,
    new_n153_, new_n154_, new_n155_, new_n156_, new_n157_, new_n158_,
    new_n159_, new_n160_, new_n161_, new_n162_, new_n163_, new_n164_,
    new_n165_, new_n166_, new_n167_, new_n168_, new_n169_, new_n170_,
    new_n171_, new_n172_, new_n173_, new_n174_, new_n175_, new_n176_,
    new_n177_, new_n178_, new_n179_, new_n180_, new_n181_, new_n182_,
    new_n183_, new_n184_, new_n185_, new_n186_, new_n187_, new_n188_,
    new_n189_, new_n190_, new_n191_, new_n192_, new_n193_, new_n194_,
    new_n195_, new_n196_, new_n197_, new_n198_, new_n199_, new_n200_,
    new_n201_, new_n202_, new_n203_, new_n204_, new_n205_, new_n206_,
    new_n207_, new_n208_, new_n209_, new_n210_, new_n211_, new_n212_,
    new_n213_, new_n215_, new_n216_, new_n217_, new_n218_, new_n219_,
    new_n220_, new_n221_, new_n222_, new_n223_, new_n224_, new_n225_,
    new_n226_, new_n227_, new_n228_, new_n229_, new_n230_, new_n231_,
    new_n232_, new_n233_, new_n234_, new_n235_, new_n236_, new_n237_,
    new_n238_, new_n239_;
  NOR2x1_ASAP7_75t_R   g000(.A(p20), .B(p21), .Y(new_n91_));
  NOR2x1_ASAP7_75t_R   g001(.A(p12), .B(p11), .Y(new_n92_));
  OAI21x1_ASAP7_75t_R  g002(.A1(p9), .A2(p8), .B(p10), .Y(new_n93_));
  NAND2x1_ASAP7_75t_R  g003(.A(p13), .B(p14), .Y(new_n94_));
  AOI21x1_ASAP7_75t_R  g004(.A1(new_n92_), .A2(new_n93_), .B(new_n94_), .Y(new_n95_));
  AO21x1_ASAP7_75t_R   g005(.A1(p16), .A2(p15), .B(p17), .Y(new_n96_));
  AOI21x1_ASAP7_75t_R  g006(.A1(p16), .A2(new_n95_), .B(new_n96_), .Y(new_n97_));
  AND2x2_ASAP7_75t_R   g007(.A(p19), .B(p18), .Y(new_n98_));
  INVx1_ASAP7_75t_R    g008(.A(new_n91_), .Y(new_n99_));
  OAI21x1_ASAP7_75t_R  g009(.A1(new_n98_), .A2(new_n99_), .B(p22), .Y(new_n100_));
  AOI21x1_ASAP7_75t_R  g010(.A1(new_n91_), .A2(new_n97_), .B(new_n100_), .Y(new_n101_));
  NAND3x1_ASAP7_75t_R  g011(.A(p26), .B(p28), .C(p27), .Y(new_n102_));
  INVx1_ASAP7_75t_R    g012(.A(new_n102_), .Y(new_n103_));
  AND2x2_ASAP7_75t_R   g013(.A(p24), .B(p23), .Y(new_n104_));
  NAND3x1_ASAP7_75t_R  g014(.A(new_n101_), .B(new_n103_), .C(new_n104_), .Y(new_n105_));
  INVx1_ASAP7_75t_R    g015(.A(p25), .Y(new_n106_));
  NOR2x1_ASAP7_75t_R   g016(.A(new_n106_), .B(new_n102_), .Y(new_n107_));
  INVx1_ASAP7_75t_R    g017(.A(new_n107_), .Y(new_n108_));
  AO21x1_ASAP7_75t_R   g018(.A1(p16), .A2(new_n95_), .B(new_n96_), .Y(new_n109_));
  NAND2x1_ASAP7_75t_R  g019(.A(p18), .B(p10), .Y(new_n110_));
  NAND2x1_ASAP7_75t_R  g020(.A(p6), .B(p4), .Y(new_n111_));
  NOR3x1_ASAP7_75t_R   g021(.A(new_n102_), .B(new_n110_), .C(new_n111_), .Y(new_n112_));
  INVx1_ASAP7_75t_R    g022(.A(p9), .Y(new_n113_));
  INVx1_ASAP7_75t_R    g023(.A(p8), .Y(new_n114_));
  AND3x1_ASAP7_75t_R   g024(.A(new_n92_), .B(new_n113_), .C(new_n114_), .Y(new_n115_));
  AND3x1_ASAP7_75t_R   g025(.A(new_n91_), .B(p19), .C(p22), .Y(new_n116_));
  NAND3x1_ASAP7_75t_R  g026(.A(new_n112_), .B(new_n115_), .C(new_n116_), .Y(new_n117_));
  AOI21x1_ASAP7_75t_R  g027(.A1(p22), .A2(new_n99_), .B(p23), .Y(new_n118_));
  INVx1_ASAP7_75t_R    g028(.A(p16), .Y(new_n119_));
  INVx1_ASAP7_75t_R    g029(.A(p15), .Y(new_n120_));
  NAND2x1_ASAP7_75t_R  g030(.A(p5), .B(p59), .Y(new_n121_));
  NAND2x1_ASAP7_75t_R  g031(.A(p0), .B(p24), .Y(new_n122_));
  AOI211x1_ASAP7_75t_R g032(.A1(new_n119_), .A2(new_n120_), .B(new_n121_), .C(new_n122_), .Y(new_n123_));
  AND4x2_ASAP7_75t_R   g033(.A(new_n120_), .B(new_n106_), .C(p3), .D(p7), .Y(new_n124_));
  NAND2x1_ASAP7_75t_R  g034(.A(p2), .B(p1), .Y(new_n125_));
  NOR2x1_ASAP7_75t_R   g035(.A(new_n94_), .B(new_n125_), .Y(new_n126_));
  NAND3x1_ASAP7_75t_R  g036(.A(new_n123_), .B(new_n124_), .C(new_n126_), .Y(new_n127_));
  OR4x2_ASAP7_75t_R    g037(.A(new_n109_), .B(new_n117_), .C(new_n118_), .D(new_n127_), .Y(new_n128_));
  NAND3x1_ASAP7_75t_R  g038(.A(new_n105_), .B(new_n108_), .C(new_n128_), .Y(new_n129_));
  OA21x2_ASAP7_75t_R   g039(.A1(p15), .A2(new_n95_), .B(p16), .Y(new_n130_));
  INVx1_ASAP7_75t_R    g040(.A(p6), .Y(new_n131_));
  INVx1_ASAP7_75t_R    g041(.A(p4), .Y(new_n132_));
  AND5x1_ASAP7_75t_R   g042(.A(p18), .B(new_n116_), .C(p10), .D(new_n131_), .E(new_n132_), .Y(new_n133_));
  NAND2x1_ASAP7_75t_R  g043(.A(p15), .B(new_n95_), .Y(new_n134_));
  NOR2x1_ASAP7_75t_R   g044(.A(p9), .B(p5), .Y(new_n135_));
  AND5x1_ASAP7_75t_R   g045(.A(p13), .B(new_n104_), .C(p14), .D(new_n92_), .E(new_n135_), .Y(new_n136_));
  OR4x2_ASAP7_75t_R    g046(.A(p17), .B(p0), .C(p3), .D(p25), .Y(new_n137_));
  OR4x2_ASAP7_75t_R    g047(.A(new_n114_), .B(p7), .C(p2), .D(p1), .Y(new_n138_));
  NOR2x1_ASAP7_75t_R   g048(.A(new_n137_), .B(new_n138_), .Y(new_n139_));
  AND5x1_ASAP7_75t_R   g049(.A(new_n130_), .B(new_n133_), .C(new_n134_), .D(new_n136_), .E(new_n139_), .Y(new_n140_));
  AO21x1_ASAP7_75t_R   g050(.A1(new_n108_), .A2(new_n105_), .B(new_n140_), .Y(new_n141_));
  NAND2x1_ASAP7_75t_R  g051(.A(new_n129_), .B(new_n141_), .Y(o0));
  AO21x1_ASAP7_75t_R   g052(.A1(p46), .A2(p45), .B(p47), .Y(new_n143_));
  NOR2x1_ASAP7_75t_R   g053(.A(p41), .B(p42), .Y(new_n144_));
  OAI21x1_ASAP7_75t_R  g054(.A1(p38), .A2(p39), .B(p40), .Y(new_n145_));
  INVx1_ASAP7_75t_R    g055(.A(p46), .Y(new_n146_));
  NAND2x1_ASAP7_75t_R  g056(.A(p43), .B(p44), .Y(new_n147_));
  AOI211x1_ASAP7_75t_R g057(.A1(new_n144_), .A2(new_n145_), .B(new_n146_), .C(new_n147_), .Y(new_n148_));
  AND2x2_ASAP7_75t_R   g058(.A(p48), .B(p49), .Y(new_n149_));
  OAI21x1_ASAP7_75t_R  g059(.A1(new_n143_), .A2(new_n148_), .B(new_n149_), .Y(new_n150_));
  INVx1_ASAP7_75t_R    g060(.A(p51), .Y(new_n151_));
  NAND2x1_ASAP7_75t_R  g061(.A(p52), .B(new_n151_), .Y(new_n152_));
  AND3x1_ASAP7_75t_R   g062(.A(p58), .B(p57), .C(p56), .Y(new_n153_));
  AND2x2_ASAP7_75t_R   g063(.A(p30), .B(p32), .Y(new_n154_));
  INVx1_ASAP7_75t_R    g064(.A(p45), .Y(new_n155_));
  AND4x2_ASAP7_75t_R   g065(.A(new_n153_), .B(new_n154_), .C(new_n155_), .D(p31), .Y(new_n156_));
  AND2x2_ASAP7_75t_R   g066(.A(new_n144_), .B(new_n145_), .Y(new_n157_));
  NAND2x1_ASAP7_75t_R  g067(.A(p54), .B(p53), .Y(new_n158_));
  INVx1_ASAP7_75t_R    g068(.A(p40), .Y(new_n159_));
  NOR3x1_ASAP7_75t_R   g069(.A(new_n158_), .B(p55), .C(new_n159_), .Y(new_n160_));
  NAND3x1_ASAP7_75t_R  g070(.A(new_n156_), .B(new_n157_), .C(new_n160_), .Y(new_n161_));
  AND2x2_ASAP7_75t_R   g071(.A(p49), .B(p34), .Y(new_n162_));
  AND2x2_ASAP7_75t_R   g072(.A(p44), .B(p35), .Y(new_n163_));
  AND2x2_ASAP7_75t_R   g073(.A(p37), .B(p29), .Y(new_n164_));
  AND5x1_ASAP7_75t_R   g074(.A(p46), .B(new_n162_), .C(new_n163_), .D(new_n164_), .E(p43), .Y(new_n165_));
  NAND2x1_ASAP7_75t_R  g075(.A(p46), .B(p45), .Y(new_n166_));
  OAI21x1_ASAP7_75t_R  g076(.A1(p48), .A2(new_n166_), .B(new_n143_), .Y(new_n167_));
  NOR2x1_ASAP7_75t_R   g077(.A(p38), .B(p39), .Y(new_n168_));
  INVx1_ASAP7_75t_R    g078(.A(new_n168_), .Y(new_n169_));
  NOR2x1_ASAP7_75t_R   g079(.A(p48), .B(p47), .Y(new_n170_));
  NAND2x1_ASAP7_75t_R  g080(.A(p33), .B(p36), .Y(new_n171_));
  NOR3x1_ASAP7_75t_R   g081(.A(new_n169_), .B(new_n170_), .C(new_n171_), .Y(new_n172_));
  NAND3x1_ASAP7_75t_R  g082(.A(new_n165_), .B(new_n167_), .C(new_n172_), .Y(new_n173_));
  AO211x2_ASAP7_75t_R  g083(.A1(new_n150_), .A2(new_n152_), .B(new_n161_), .C(new_n173_), .Y(new_n174_));
  AND3x1_ASAP7_75t_R   g084(.A(p54), .B(p52), .C(p53), .Y(new_n175_));
  OA21x2_ASAP7_75t_R   g085(.A1(p55), .A2(new_n175_), .B(new_n153_), .Y(new_n176_));
  INVx1_ASAP7_75t_R    g086(.A(new_n149_), .Y(new_n177_));
  AOI21x1_ASAP7_75t_R  g087(.A1(new_n144_), .A2(new_n145_), .B(new_n147_), .Y(new_n178_));
  AOI21x1_ASAP7_75t_R  g088(.A1(p46), .A2(new_n178_), .B(new_n143_), .Y(new_n179_));
  INVx1_ASAP7_75t_R    g089(.A(p50), .Y(new_n180_));
  INVx1_ASAP7_75t_R    g090(.A(p55), .Y(new_n181_));
  AND3x1_ASAP7_75t_R   g091(.A(new_n180_), .B(new_n181_), .C(new_n151_), .Y(new_n182_));
  OAI21x1_ASAP7_75t_R  g092(.A1(new_n177_), .A2(new_n179_), .B(new_n182_), .Y(new_n183_));
  NOR2x1_ASAP7_75t_R   g093(.A(p50), .B(p59), .Y(new_n184_));
  AOI21x1_ASAP7_75t_R  g094(.A1(new_n176_), .A2(new_n183_), .B(new_n184_), .Y(new_n185_));
  OR4x2_ASAP7_75t_R    g095(.A(new_n159_), .B(p55), .C(p37), .D(p42), .Y(new_n186_));
  NAND2x1_ASAP7_75t_R  g096(.A(p38), .B(p56), .Y(new_n187_));
  OR3x1_ASAP7_75t_R    g097(.A(new_n187_), .B(p45), .C(p39), .Y(new_n188_));
  NOR2x1_ASAP7_75t_R   g098(.A(p50), .B(p36), .Y(new_n189_));
  AND2x2_ASAP7_75t_R   g099(.A(p43), .B(p44), .Y(new_n190_));
  NAND2x1_ASAP7_75t_R  g100(.A(new_n189_), .B(new_n190_), .Y(new_n191_));
  NOR3x1_ASAP7_75t_R   g101(.A(new_n186_), .B(new_n188_), .C(new_n191_), .Y(new_n192_));
  NAND2x1_ASAP7_75t_R  g102(.A(p46), .B(p47), .Y(new_n193_));
  AND3x1_ASAP7_75t_R   g103(.A(new_n193_), .B(p48), .C(p49), .Y(new_n194_));
  INVx1_ASAP7_75t_R    g104(.A(p41), .Y(new_n195_));
  NAND2x1_ASAP7_75t_R  g105(.A(new_n195_), .B(new_n145_), .Y(new_n196_));
  NOR3x1_ASAP7_75t_R   g106(.A(new_n158_), .B(p33), .C(p35), .Y(new_n197_));
  AND3x1_ASAP7_75t_R   g107(.A(new_n194_), .B(new_n196_), .C(new_n197_), .Y(new_n198_));
  NOR2x1_ASAP7_75t_R   g108(.A(new_n195_), .B(new_n145_), .Y(new_n199_));
  OR4x2_ASAP7_75t_R    g109(.A(p34), .B(p31), .C(p30), .D(p32), .Y(new_n200_));
  NOR3x1_ASAP7_75t_R   g110(.A(new_n199_), .B(new_n200_), .C(new_n152_), .Y(new_n201_));
  NAND3x1_ASAP7_75t_R  g111(.A(new_n192_), .B(new_n198_), .C(new_n201_), .Y(new_n202_));
  NAND2x1_ASAP7_75t_R  g112(.A(p47), .B(new_n155_), .Y(new_n203_));
  NOR2x1_ASAP7_75t_R   g113(.A(new_n203_), .B(new_n178_), .Y(new_n204_));
  INVx1_ASAP7_75t_R    g114(.A(new_n166_), .Y(new_n205_));
  AO21x1_ASAP7_75t_R   g115(.A1(p46), .A2(new_n178_), .B(new_n205_), .Y(new_n206_));
  NOR2x1_ASAP7_75t_R   g116(.A(p59), .B(p29), .Y(new_n207_));
  OAI21x1_ASAP7_75t_R  g117(.A1(new_n204_), .A2(new_n206_), .B(new_n207_), .Y(new_n208_));
  INVx1_ASAP7_75t_R    g118(.A(new_n176_), .Y(new_n209_));
  AOI21x1_ASAP7_75t_R  g119(.A1(new_n182_), .A2(new_n150_), .B(new_n209_), .Y(new_n210_));
  OAI21x1_ASAP7_75t_R  g120(.A1(new_n202_), .A2(new_n208_), .B(new_n210_), .Y(new_n211_));
  OAI21x1_ASAP7_75t_R  g121(.A1(new_n174_), .A2(new_n185_), .B(new_n211_), .Y(new_n212_));
  AOI21x1_ASAP7_75t_R  g122(.A1(new_n108_), .A2(new_n105_), .B(new_n140_), .Y(new_n213_));
  AOI21x1_ASAP7_75t_R  g123(.A1(new_n129_), .A2(new_n212_), .B(new_n213_), .Y(o1));
  AND2x2_ASAP7_75t_R   g124(.A(p59), .B(p29), .Y(new_n215_));
  NOR2x1_ASAP7_75t_R   g125(.A(p45), .B(new_n178_), .Y(new_n216_));
  OAI22x1_ASAP7_75t_R  g126(.A1(new_n216_), .A2(new_n146_), .B1(new_n178_), .B2(new_n203_), .Y(new_n217_));
  INVx1_ASAP7_75t_R    g127(.A(p33), .Y(new_n218_));
  AND3x1_ASAP7_75t_R   g128(.A(new_n190_), .B(new_n218_), .C(new_n180_), .Y(new_n219_));
  AND5x1_ASAP7_75t_R   g129(.A(p48), .B(new_n193_), .C(p52), .D(p49), .E(new_n151_), .Y(new_n220_));
  OR3x1_ASAP7_75t_R    g130(.A(new_n168_), .B(new_n195_), .C(new_n159_), .Y(new_n221_));
  NOR2x1_ASAP7_75t_R   g131(.A(p36), .B(p37), .Y(new_n222_));
  INVx1_ASAP7_75t_R    g132(.A(p42), .Y(new_n223_));
  INVx1_ASAP7_75t_R    g133(.A(p35), .Y(new_n224_));
  AND3x1_ASAP7_75t_R   g134(.A(new_n222_), .B(new_n223_), .C(new_n224_), .Y(new_n225_));
  AND5x1_ASAP7_75t_R   g135(.A(new_n196_), .B(new_n219_), .C(new_n220_), .D(new_n221_), .E(new_n225_), .Y(new_n226_));
  INVx1_ASAP7_75t_R    g136(.A(p39), .Y(new_n227_));
  NOR2x1_ASAP7_75t_R   g137(.A(p34), .B(p45), .Y(new_n228_));
  INVx1_ASAP7_75t_R    g138(.A(p31), .Y(new_n229_));
  AND3x1_ASAP7_75t_R   g139(.A(new_n228_), .B(p38), .C(new_n229_), .Y(new_n230_));
  NOR2x1_ASAP7_75t_R   g140(.A(p30), .B(p32), .Y(new_n231_));
  AND5x1_ASAP7_75t_R   g141(.A(new_n227_), .B(new_n230_), .C(p56), .D(new_n160_), .E(new_n231_), .Y(new_n232_));
  NAND3x1_ASAP7_75t_R  g142(.A(new_n217_), .B(new_n226_), .C(new_n232_), .Y(new_n233_));
  OAI21x1_ASAP7_75t_R  g143(.A1(new_n215_), .A2(new_n233_), .B(new_n210_), .Y(new_n234_));
  NOR3x1_ASAP7_75t_R   g144(.A(new_n109_), .B(new_n117_), .C(new_n127_), .Y(new_n235_));
  INVx1_ASAP7_75t_R    g145(.A(new_n118_), .Y(new_n236_));
  INVx1_ASAP7_75t_R    g146(.A(new_n104_), .Y(new_n237_));
  AOI211x1_ASAP7_75t_R g147(.A1(new_n91_), .A2(new_n97_), .B(new_n237_), .C(new_n100_), .Y(new_n238_));
  AOI221x1_ASAP7_75t_R g148(.A1(new_n235_), .A2(new_n236_), .B1(new_n238_), .B2(new_n103_), .C(new_n107_), .Y(new_n239_));
  NOR3x1_ASAP7_75t_R   g149(.A(new_n213_), .B(new_n234_), .C(new_n239_), .Y(o2));
  assign               o3 = 1'b0;
  assign               o4 = 1'b0;
  assign               o5 = 1'b0;
  assign               o6 = 1'b0;
  assign               o7 = 1'b0;
  assign               o8 = 1'b0;
  assign               o9 = 1'b0;
  assign               o10 = 1'b0;
  assign               o11 = 1'b0;
  assign               o12 = 1'b0;
  assign               o13 = 1'b0;
  assign               o14 = 1'b0;
  assign               o15 = 1'b0;
  assign               o16 = 1'b0;
  assign               o17 = 1'b0;
  assign               o18 = 1'b0;
  assign               o19 = 1'b0;
  assign               o20 = 1'b0;
  assign               o21 = 1'b0;
  assign               o22 = 1'b0;
  assign               o23 = 1'b0;
  assign               o24 = 1'b0;
  assign               o25 = 1'b0;
  assign               o26 = 1'b0;
  assign               o27 = 1'b0;
  assign               o28 = 1'b0;
  assign               o29 = 1'b0;
endmodule


