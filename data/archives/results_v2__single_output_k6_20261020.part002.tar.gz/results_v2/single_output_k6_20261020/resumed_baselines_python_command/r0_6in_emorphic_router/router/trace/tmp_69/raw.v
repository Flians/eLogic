// Benchmark "/tmp/" written by ABC on Tue Oct 20 18:11:52 2026

module \/tmp/  ( 
    p49, p48, p34, p37, p5, p24, p18, p21, p57, p30, p52, p23, p6, p4, p25,
    p38, p40, p9, p3, p42, p31, p0, p1, p51, p50, p29, p7, p20, p2, p47,
    p41, p36, p16, p28, p45, p26, p54, p53, p15, p39, p19, p17, p13, p8,
    p12, p43, p59, p35, p10, p58, p44, p56, p32, p27, p22, p33, p14, p55,
    p11, p46,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25, o26, o27, o28, o29  );
  input  p49, p48, p34, p37, p5, p24, p18, p21, p57, p30, p52, p23, p6,
    p4, p25, p38, p40, p9, p3, p42, p31, p0, p1, p51, p50, p29, p7, p20,
    p2, p47, p41, p36, p16, p28, p45, p26, p54, p53, p15, p39, p19, p17,
    p13, p8, p12, p43, p59, p35, p10, p58, p44, p56, p32, p27, p22, p33,
    p14, p55, p11, p46;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25, o26, o27, o28, o29;
  wire new_n91_, new_n92_, new_n93_, new_n94_, new_n95_, new_n96_, new_n97_,
    new_n98_, new_n99_, new_n100_, new_n101_, new_n102_, new_n103_,
    new_n104_, new_n105_, new_n106_, new_n107_, new_n108_, new_n109_,
    new_n110_, new_n111_, new_n112_, new_n113_, new_n114_, new_n115_,
    new_n116_, new_n117_, new_n118_, new_n119_, new_n120_, new_n121_,
    new_n122_, new_n123_, new_n124_, new_n125_, new_n126_, new_n127_,
    new_n128_, new_n129_, new_n130_, new_n131_, new_n132_, new_n133_,
    new_n134_, new_n135_, new_n136_, new_n137_, new_n138_, new_n139_,
    new_n140_, new_n141_, new_n142_, new_n143_, new_n144_, new_n145_,
    new_n146_, new_n147_, new_n148_, new_n149_, new_n151_, new_n152_,
    new_n153_, new_n154_, new_n155_, new_n156_, new_n157_, new_n158_,
    new_n159_, new_n160_, new_n161_, new_n162_, new_n163_, new_n164_,
    new_n165_, new_n166_, new_n167_, new_n168_, new_n169_, new_n170_,
    new_n171_, new_n172_, new_n173_, new_n174_, new_n175_, new_n176_,
    new_n177_, new_n178_, new_n179_, new_n180_, new_n181_, new_n182_,
    new_n183_, new_n184_, new_n185_, new_n186_, new_n187_, new_n188_,
    new_n189_, new_n190_, new_n191_, new_n192_, new_n193_, new_n194_,
    new_n195_, new_n196_, new_n197_, new_n198_, new_n199_, new_n200_,
    new_n201_, new_n202_, new_n203_, new_n204_, new_n205_, new_n206_,
    new_n207_, new_n208_, new_n209_, new_n210_, new_n211_, new_n212_,
    new_n213_, new_n214_, new_n215_, new_n216_, new_n217_, new_n218_,
    new_n219_, new_n220_, new_n221_, new_n222_, new_n223_, new_n225_,
    new_n226_, new_n227_, new_n228_, new_n229_, new_n230_, new_n231_,
    new_n232_, new_n233_, new_n234_, new_n235_, new_n236_, new_n237_,
    new_n238_, new_n239_, new_n240_, new_n241_, new_n242_, new_n243_,
    new_n244_, new_n245_, new_n246_, new_n247_;
  AND3x1_ASAP7_75t_R   g000(.A(p28), .B(p26), .C(p27), .Y(new_n91_));
  INVx1_ASAP7_75t_R    g001(.A(new_n91_), .Y(new_n92_));
  AND2x2_ASAP7_75t_R   g002(.A(p24), .B(p23), .Y(new_n93_));
  INVx1_ASAP7_75t_R    g003(.A(new_n93_), .Y(new_n94_));
  NOR2x1_ASAP7_75t_R   g004(.A(p21), .B(p20), .Y(new_n95_));
  INVx1_ASAP7_75t_R    g005(.A(new_n95_), .Y(new_n96_));
  NOR2x1_ASAP7_75t_R   g006(.A(p12), .B(p11), .Y(new_n97_));
  OAI21x1_ASAP7_75t_R  g007(.A1(p9), .A2(p8), .B(p10), .Y(new_n98_));
  NAND2x1_ASAP7_75t_R  g008(.A(p13), .B(p14), .Y(new_n99_));
  AOI21x1_ASAP7_75t_R  g009(.A1(new_n97_), .A2(new_n98_), .B(new_n99_), .Y(new_n100_));
  AO21x1_ASAP7_75t_R   g010(.A1(p16), .A2(p15), .B(p17), .Y(new_n101_));
  AO21x1_ASAP7_75t_R   g011(.A1(p16), .A2(new_n100_), .B(new_n101_), .Y(new_n102_));
  NAND2x1_ASAP7_75t_R  g012(.A(p18), .B(p19), .Y(new_n103_));
  INVx1_ASAP7_75t_R    g013(.A(p22), .Y(new_n104_));
  AOI21x1_ASAP7_75t_R  g014(.A1(new_n103_), .A2(new_n95_), .B(new_n104_), .Y(new_n105_));
  OAI21x1_ASAP7_75t_R  g015(.A1(new_n96_), .A2(new_n102_), .B(new_n105_), .Y(new_n106_));
  NAND2x1_ASAP7_75t_R  g016(.A(p25), .B(new_n91_), .Y(new_n107_));
  OA31x2_ASAP7_75t_R   g017(.A1(new_n92_), .A2(new_n94_), .A3(new_n106_), .B1(new_n107_), .Y(new_n108_));
  NAND2x1_ASAP7_75t_R  g018(.A(new_n97_), .B(new_n98_), .Y(new_n109_));
  OAI21x1_ASAP7_75t_R  g019(.A1(p14), .A2(new_n109_), .B(p15), .Y(new_n110_));
  AO21x1_ASAP7_75t_R   g020(.A1(p14), .A2(new_n109_), .B(p15), .Y(new_n111_));
  AND2x2_ASAP7_75t_R   g021(.A(new_n110_), .B(new_n111_), .Y(new_n112_));
  INVx1_ASAP7_75t_R    g022(.A(p13), .Y(new_n113_));
  INVx1_ASAP7_75t_R    g023(.A(p8), .Y(new_n114_));
  OR4x2_ASAP7_75t_R    g024(.A(new_n113_), .B(new_n114_), .C(p17), .D(p12), .Y(new_n115_));
  NAND2x1_ASAP7_75t_R  g025(.A(p19), .B(p22), .Y(new_n116_));
  INVx1_ASAP7_75t_R    g026(.A(p11), .Y(new_n117_));
  NOR2x1_ASAP7_75t_R   g027(.A(p9), .B(p8), .Y(new_n118_));
  NOR2x1_ASAP7_75t_R   g028(.A(new_n117_), .B(new_n118_), .Y(new_n119_));
  OR4x2_ASAP7_75t_R    g029(.A(new_n115_), .B(new_n96_), .C(new_n116_), .D(new_n119_), .Y(new_n120_));
  OA21x2_ASAP7_75t_R   g030(.A1(p10), .A2(new_n117_), .B(new_n98_), .Y(new_n121_));
  INVx1_ASAP7_75t_R    g031(.A(p18), .Y(new_n122_));
  OR4x2_ASAP7_75t_R    g032(.A(new_n122_), .B(p5), .C(p6), .D(p4), .Y(new_n123_));
  INVx1_ASAP7_75t_R    g033(.A(p16), .Y(new_n124_));
  OR4x2_ASAP7_75t_R    g034(.A(new_n124_), .B(p1), .C(p7), .D(p2), .Y(new_n125_));
  OR4x2_ASAP7_75t_R    g035(.A(p25), .B(p9), .C(p3), .D(p0), .Y(new_n126_));
  OR5x1_ASAP7_75t_R    g036(.A(new_n94_), .B(new_n121_), .C(new_n123_), .D(new_n125_), .E(new_n126_), .Y(new_n127_));
  NOR2x1_ASAP7_75t_R   g037(.A(new_n120_), .B(new_n127_), .Y(new_n128_));
  AND2x2_ASAP7_75t_R   g038(.A(new_n112_), .B(new_n128_), .Y(new_n129_));
  AOI211x1_ASAP7_75t_R g039(.A1(new_n97_), .A2(new_n98_), .B(new_n124_), .C(new_n99_), .Y(new_n130_));
  OA31x2_ASAP7_75t_R   g040(.A1(new_n96_), .A2(new_n101_), .A3(new_n130_), .B1(new_n105_), .Y(new_n131_));
  AOI21x1_ASAP7_75t_R  g041(.A1(new_n93_), .A2(new_n131_), .B(p25), .Y(new_n132_));
  AND2x2_ASAP7_75t_R   g042(.A(p3), .B(p0), .Y(new_n133_));
  AND2x2_ASAP7_75t_R   g043(.A(p1), .B(p7), .Y(new_n134_));
  AND2x2_ASAP7_75t_R   g044(.A(p18), .B(p6), .Y(new_n135_));
  INVx1_ASAP7_75t_R    g045(.A(p25), .Y(new_n136_));
  AND5x1_ASAP7_75t_R   g046(.A(p4), .B(new_n133_), .C(new_n134_), .D(new_n135_), .E(new_n136_), .Y(new_n137_));
  INVx1_ASAP7_75t_R    g047(.A(new_n99_), .Y(new_n138_));
  AND5x1_ASAP7_75t_R   g048(.A(p5), .B(new_n138_), .C(p24), .D(new_n97_), .E(new_n118_), .Y(new_n139_));
  NAND2x1_ASAP7_75t_R  g049(.A(new_n137_), .B(new_n139_), .Y(new_n140_));
  INVx1_ASAP7_75t_R    g050(.A(p15), .Y(new_n141_));
  NAND2x1_ASAP7_75t_R  g051(.A(p2), .B(new_n141_), .Y(new_n142_));
  NAND2x1_ASAP7_75t_R  g052(.A(p59), .B(p10), .Y(new_n143_));
  OR5x1_ASAP7_75t_R    g053(.A(new_n92_), .B(new_n96_), .C(new_n116_), .D(new_n142_), .E(new_n143_), .Y(new_n144_));
  AOI21x1_ASAP7_75t_R  g054(.A1(p22), .A2(new_n96_), .B(p23), .Y(new_n145_));
  NAND2x1_ASAP7_75t_R  g055(.A(new_n124_), .B(new_n141_), .Y(new_n146_));
  NOR2x1_ASAP7_75t_R   g056(.A(new_n146_), .B(new_n100_), .Y(new_n147_));
  OR5x1_ASAP7_75t_R    g057(.A(new_n102_), .B(new_n140_), .C(new_n144_), .D(new_n145_), .E(new_n147_), .Y(new_n148_));
  OAI21x1_ASAP7_75t_R  g058(.A1(new_n92_), .A2(new_n132_), .B(new_n148_), .Y(new_n149_));
  OAI21x1_ASAP7_75t_R  g059(.A1(new_n108_), .A2(new_n129_), .B(new_n149_), .Y(o0));
  NAND3x1_ASAP7_75t_R  g060(.A(new_n131_), .B(new_n91_), .C(new_n93_), .Y(new_n151_));
  AOI22x1_ASAP7_75t_R  g061(.A1(new_n128_), .A2(new_n112_), .B1(new_n151_), .B2(new_n107_), .Y(new_n152_));
  NAND2x1_ASAP7_75t_R  g062(.A(p49), .B(p48), .Y(new_n153_));
  NOR2x1_ASAP7_75t_R   g063(.A(p42), .B(p41), .Y(new_n154_));
  OAI21x1_ASAP7_75t_R  g064(.A1(p38), .A2(p39), .B(p40), .Y(new_n155_));
  NAND2x1_ASAP7_75t_R  g065(.A(p43), .B(p44), .Y(new_n156_));
  AOI21x1_ASAP7_75t_R  g066(.A1(new_n154_), .A2(new_n155_), .B(new_n156_), .Y(new_n157_));
  AO21x1_ASAP7_75t_R   g067(.A1(p45), .A2(p46), .B(p47), .Y(new_n158_));
  AOI21x1_ASAP7_75t_R  g068(.A1(p46), .A2(new_n157_), .B(new_n158_), .Y(new_n159_));
  INVx1_ASAP7_75t_R    g069(.A(p51), .Y(new_n160_));
  NAND2x1_ASAP7_75t_R  g070(.A(p52), .B(new_n160_), .Y(new_n161_));
  OAI21x1_ASAP7_75t_R  g071(.A1(new_n153_), .A2(new_n159_), .B(new_n161_), .Y(new_n162_));
  AND3x1_ASAP7_75t_R   g072(.A(p57), .B(p58), .C(p56), .Y(new_n163_));
  AND2x2_ASAP7_75t_R   g073(.A(p54), .B(p53), .Y(new_n164_));
  INVx1_ASAP7_75t_R    g074(.A(p38), .Y(new_n165_));
  INVx1_ASAP7_75t_R    g075(.A(p39), .Y(new_n166_));
  AND3x1_ASAP7_75t_R   g076(.A(new_n164_), .B(new_n165_), .C(new_n166_), .Y(new_n167_));
  AND2x2_ASAP7_75t_R   g077(.A(p33), .B(p46), .Y(new_n168_));
  AND3x1_ASAP7_75t_R   g078(.A(new_n168_), .B(p35), .C(p32), .Y(new_n169_));
  OA211x2_ASAP7_75t_R  g079(.A1(p48), .A2(p47), .B(p34), .C(p37), .Y(new_n170_));
  INVx1_ASAP7_75t_R    g080(.A(p45), .Y(new_n171_));
  INVx1_ASAP7_75t_R    g081(.A(p55), .Y(new_n172_));
  AND3x1_ASAP7_75t_R   g082(.A(new_n171_), .B(new_n172_), .C(p44), .Y(new_n173_));
  AND5x1_ASAP7_75t_R   g083(.A(new_n163_), .B(new_n167_), .C(new_n169_), .D(new_n170_), .E(new_n173_), .Y(new_n174_));
  AND2x2_ASAP7_75t_R   g084(.A(p40), .B(p31), .Y(new_n175_));
  AND3x1_ASAP7_75t_R   g085(.A(new_n175_), .B(p29), .C(p36), .Y(new_n176_));
  NAND2x1_ASAP7_75t_R  g086(.A(p45), .B(p46), .Y(new_n177_));
  OAI21x1_ASAP7_75t_R  g087(.A1(p48), .A2(new_n177_), .B(new_n158_), .Y(new_n178_));
  INVx1_ASAP7_75t_R    g088(.A(p43), .Y(new_n179_));
  AO21x1_ASAP7_75t_R   g089(.A1(new_n154_), .A2(new_n155_), .B(new_n179_), .Y(new_n180_));
  NAND2x1_ASAP7_75t_R  g090(.A(p42), .B(p41), .Y(new_n181_));
  OAI21x1_ASAP7_75t_R  g091(.A1(new_n181_), .A2(new_n155_), .B(new_n179_), .Y(new_n182_));
  AND2x2_ASAP7_75t_R   g092(.A(p49), .B(p30), .Y(new_n183_));
  AND5x1_ASAP7_75t_R   g093(.A(new_n176_), .B(new_n178_), .C(new_n180_), .D(new_n182_), .E(new_n183_), .Y(new_n184_));
  NAND3x1_ASAP7_75t_R  g094(.A(new_n162_), .B(new_n174_), .C(new_n184_), .Y(new_n185_));
  AND3x1_ASAP7_75t_R   g095(.A(p52), .B(p54), .C(p53), .Y(new_n186_));
  OA21x2_ASAP7_75t_R   g096(.A1(p55), .A2(new_n186_), .B(new_n163_), .Y(new_n187_));
  NOR2x1_ASAP7_75t_R   g097(.A(p51), .B(p50), .Y(new_n188_));
  AND2x2_ASAP7_75t_R   g098(.A(new_n172_), .B(new_n188_), .Y(new_n189_));
  OAI21x1_ASAP7_75t_R  g099(.A1(new_n153_), .A2(new_n159_), .B(new_n189_), .Y(new_n190_));
  NOR2x1_ASAP7_75t_R   g100(.A(p50), .B(p59), .Y(new_n191_));
  AOI21x1_ASAP7_75t_R  g101(.A1(new_n187_), .A2(new_n190_), .B(new_n191_), .Y(new_n192_));
  NOR2x1_ASAP7_75t_R   g102(.A(p42), .B(p50), .Y(new_n193_));
  INVx1_ASAP7_75t_R    g103(.A(p36), .Y(new_n194_));
  AND3x1_ASAP7_75t_R   g104(.A(new_n193_), .B(p40), .C(new_n194_), .Y(new_n195_));
  NOR2x1_ASAP7_75t_R   g105(.A(p39), .B(p55), .Y(new_n196_));
  AND3x1_ASAP7_75t_R   g106(.A(new_n196_), .B(new_n171_), .C(p56), .Y(new_n197_));
  NOR3x1_ASAP7_75t_R   g107(.A(new_n156_), .B(p37), .C(new_n165_), .Y(new_n198_));
  AND3x1_ASAP7_75t_R   g108(.A(new_n195_), .B(new_n197_), .C(new_n198_), .Y(new_n199_));
  INVx1_ASAP7_75t_R    g109(.A(p41), .Y(new_n200_));
  NOR2x1_ASAP7_75t_R   g110(.A(p34), .B(p30), .Y(new_n201_));
  NAND2x1_ASAP7_75t_R  g111(.A(new_n201_), .B(new_n164_), .Y(new_n202_));
  NAND2x1_ASAP7_75t_R  g112(.A(p47), .B(p46), .Y(new_n203_));
  AND2x2_ASAP7_75t_R   g113(.A(p49), .B(p48), .Y(new_n204_));
  NAND2x1_ASAP7_75t_R  g114(.A(new_n203_), .B(new_n204_), .Y(new_n205_));
  AOI211x1_ASAP7_75t_R g115(.A1(new_n200_), .A2(new_n155_), .B(new_n202_), .C(new_n205_), .Y(new_n206_));
  NOR2x1_ASAP7_75t_R   g116(.A(new_n200_), .B(new_n155_), .Y(new_n207_));
  OR4x2_ASAP7_75t_R    g117(.A(p31), .B(p35), .C(p32), .D(p33), .Y(new_n208_));
  NOR3x1_ASAP7_75t_R   g118(.A(new_n207_), .B(new_n161_), .C(new_n208_), .Y(new_n209_));
  NAND3x1_ASAP7_75t_R  g119(.A(new_n199_), .B(new_n206_), .C(new_n209_), .Y(new_n210_));
  NAND2x1_ASAP7_75t_R  g120(.A(p47), .B(new_n171_), .Y(new_n211_));
  NOR2x1_ASAP7_75t_R   g121(.A(new_n211_), .B(new_n157_), .Y(new_n212_));
  INVx1_ASAP7_75t_R    g122(.A(new_n177_), .Y(new_n213_));
  AO21x1_ASAP7_75t_R   g123(.A1(p46), .A2(new_n157_), .B(new_n213_), .Y(new_n214_));
  NOR2x1_ASAP7_75t_R   g124(.A(p29), .B(p59), .Y(new_n215_));
  OAI21x1_ASAP7_75t_R  g125(.A1(new_n212_), .A2(new_n214_), .B(new_n215_), .Y(new_n216_));
  INVx1_ASAP7_75t_R    g126(.A(p46), .Y(new_n217_));
  AOI211x1_ASAP7_75t_R g127(.A1(new_n154_), .A2(new_n155_), .B(new_n217_), .C(new_n156_), .Y(new_n218_));
  OAI21x1_ASAP7_75t_R  g128(.A1(new_n158_), .A2(new_n218_), .B(new_n204_), .Y(new_n219_));
  INVx1_ASAP7_75t_R    g129(.A(new_n187_), .Y(new_n220_));
  AOI21x1_ASAP7_75t_R  g130(.A1(new_n189_), .A2(new_n219_), .B(new_n220_), .Y(new_n221_));
  OAI21x1_ASAP7_75t_R  g131(.A1(new_n210_), .A2(new_n216_), .B(new_n221_), .Y(new_n222_));
  OAI21x1_ASAP7_75t_R  g132(.A1(new_n185_), .A2(new_n192_), .B(new_n222_), .Y(new_n223_));
  OAI21x1_ASAP7_75t_R  g133(.A1(new_n152_), .A2(new_n223_), .B(new_n149_), .Y(o1));
  INVx1_ASAP7_75t_R    g134(.A(new_n207_), .Y(new_n225_));
  NAND2x1_ASAP7_75t_R  g135(.A(new_n200_), .B(new_n155_), .Y(new_n226_));
  NOR2x1_ASAP7_75t_R   g136(.A(p32), .B(p33), .Y(new_n227_));
  NOR2x1_ASAP7_75t_R   g137(.A(p30), .B(p31), .Y(new_n228_));
  NOR2x1_ASAP7_75t_R   g138(.A(p34), .B(p35), .Y(new_n229_));
  AND5x1_ASAP7_75t_R   g139(.A(p54), .B(new_n227_), .C(new_n228_), .D(new_n229_), .E(p53), .Y(new_n230_));
  NOR2x1_ASAP7_75t_R   g140(.A(new_n153_), .B(new_n161_), .Y(new_n231_));
  AND5x1_ASAP7_75t_R   g141(.A(new_n225_), .B(new_n226_), .C(new_n230_), .D(new_n203_), .E(new_n231_), .Y(new_n232_));
  NOR2x1_ASAP7_75t_R   g142(.A(p45), .B(new_n157_), .Y(new_n233_));
  OAI22x1_ASAP7_75t_R  g143(.A1(new_n233_), .A2(new_n217_), .B1(new_n157_), .B2(new_n211_), .Y(new_n234_));
  NOR2x1_ASAP7_75t_R   g144(.A(p50), .B(p45), .Y(new_n235_));
  AND3x1_ASAP7_75t_R   g145(.A(new_n235_), .B(p56), .C(new_n172_), .Y(new_n236_));
  INVx1_ASAP7_75t_R    g146(.A(p40), .Y(new_n237_));
  NOR3x1_ASAP7_75t_R   g147(.A(new_n156_), .B(new_n237_), .C(p42), .Y(new_n238_));
  NOR2x1_ASAP7_75t_R   g148(.A(p39), .B(new_n165_), .Y(new_n239_));
  NOR2x1_ASAP7_75t_R   g149(.A(p37), .B(p36), .Y(new_n240_));
  NAND2x1_ASAP7_75t_R  g150(.A(p29), .B(p59), .Y(new_n241_));
  AND5x1_ASAP7_75t_R   g151(.A(new_n236_), .B(new_n238_), .C(new_n239_), .D(new_n240_), .E(new_n241_), .Y(new_n242_));
  NAND3x1_ASAP7_75t_R  g152(.A(new_n232_), .B(new_n234_), .C(new_n242_), .Y(new_n243_));
  INVx1_ASAP7_75t_R    g153(.A(new_n186_), .Y(new_n244_));
  OA21x2_ASAP7_75t_R   g154(.A1(new_n188_), .A2(new_n244_), .B(new_n172_), .Y(new_n245_));
  OAI21x1_ASAP7_75t_R  g155(.A1(new_n244_), .A2(new_n219_), .B(new_n245_), .Y(new_n246_));
  NAND3x1_ASAP7_75t_R  g156(.A(new_n243_), .B(new_n163_), .C(new_n246_), .Y(new_n247_));
  AOI211x1_ASAP7_75t_R g157(.A1(new_n148_), .A2(new_n108_), .B(new_n152_), .C(new_n247_), .Y(o2));
  assign               o3 = 1'b0;
  assign               o4 = 1'b0;
  assign               o5 = 1'b0;
  assign               o6 = 1'b0;
  assign               o7 = 1'b0;
  assign               o8 = 1'b0;
  assign               o9 = 1'b0;
  assign               o10 = 1'b0;
  assign               o11 = 1'b0;
  assign               o12 = 1'b0;
  assign               o13 = 1'b0;
  assign               o14 = 1'b0;
  assign               o15 = 1'b0;
  assign               o16 = 1'b0;
  assign               o17 = 1'b0;
  assign               o18 = 1'b0;
  assign               o19 = 1'b0;
  assign               o20 = 1'b0;
  assign               o21 = 1'b0;
  assign               o22 = 1'b0;
  assign               o23 = 1'b0;
  assign               o24 = 1'b0;
  assign               o25 = 1'b0;
  assign               o26 = 1'b0;
  assign               o27 = 1'b0;
  assign               o28 = 1'b0;
  assign               o29 = 1'b0;
endmodule


