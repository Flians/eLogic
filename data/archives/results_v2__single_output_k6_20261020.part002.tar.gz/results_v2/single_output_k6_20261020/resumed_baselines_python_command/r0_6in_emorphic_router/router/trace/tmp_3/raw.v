// Benchmark "/tmp/" written by ABC on Tue Oct 20 18:11:44 2026

module \/tmp/  ( 
    p34, p5, p49, p35, p55, p32, p37, p26, p51, p17, p40, p47, p0, p48,
    p14, p22, p25, p31, p9, p27, p23, p36, p33, p50, p29, p56, p13, p30,
    p46, p21, p39, p4, p8, p59, p16, p12, p19, p54, p43, p24, p41, p3, p11,
    p15, p18, p44, p6, p38, p45, p42, p53, p7, p58, p28, p2, p20, p52, p10,
    p1, p57,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25, o26, o27, o28, o29  );
  input  p34, p5, p49, p35, p55, p32, p37, p26, p51, p17, p40, p47, p0,
    p48, p14, p22, p25, p31, p9, p27, p23, p36, p33, p50, p29, p56, p13,
    p30, p46, p21, p39, p4, p8, p59, p16, p12, p19, p54, p43, p24, p41, p3,
    p11, p15, p18, p44, p6, p38, p45, p42, p53, p7, p58, p28, p2, p20, p52,
    p10, p1, p57;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25, o26, o27, o28, o29;
  wire new_n91_, new_n92_, new_n93_, new_n94_, new_n95_, new_n96_, new_n97_,
    new_n98_, new_n99_, new_n100_, new_n101_, new_n102_, new_n103_,
    new_n104_, new_n105_, new_n106_, new_n107_, new_n108_, new_n109_,
    new_n110_, new_n111_, new_n112_, new_n113_, new_n114_, new_n115_,
    new_n116_, new_n117_, new_n118_, new_n119_, new_n120_, new_n121_,
    new_n122_, new_n123_, new_n124_, new_n125_, new_n126_, new_n127_,
    new_n128_, new_n129_, new_n130_, new_n131_, new_n132_, new_n133_,
    new_n134_, new_n135_, new_n136_, new_n137_, new_n138_, new_n139_,
    new_n140_, new_n141_, new_n142_, new_n143_, new_n144_, new_n145_,
    new_n146_, new_n147_, new_n148_, new_n149_, new_n150_, new_n151_,
    new_n152_, new_n153_, new_n155_, new_n156_, new_n157_, new_n158_,
    new_n159_, new_n160_, new_n161_, new_n162_, new_n163_, new_n164_,
    new_n165_, new_n166_, new_n167_, new_n168_, new_n169_, new_n170_,
    new_n171_, new_n172_, new_n173_, new_n174_, new_n175_, new_n176_,
    new_n177_, new_n178_, new_n179_, new_n180_, new_n181_, new_n182_,
    new_n183_, new_n184_, new_n185_, new_n186_, new_n187_, new_n188_,
    new_n189_, new_n190_, new_n191_, new_n192_, new_n193_, new_n194_,
    new_n195_, new_n196_, new_n197_, new_n198_, new_n199_, new_n200_,
    new_n201_, new_n202_, new_n203_, new_n204_, new_n205_, new_n206_,
    new_n207_, new_n208_, new_n209_, new_n210_, new_n211_, new_n212_,
    new_n213_, new_n214_, new_n215_, new_n216_, new_n217_, new_n219_,
    new_n220_, new_n221_, new_n222_, new_n223_, new_n224_, new_n225_,
    new_n226_, new_n227_, new_n228_, new_n229_, new_n230_, new_n231_,
    new_n232_;
  AND3x1_ASAP7_75t_R   g000(.A(p22), .B(p23), .C(p24), .Y(new_n91_));
  NOR2x1_ASAP7_75t_R   g001(.A(p21), .B(p20), .Y(new_n92_));
  NOR2x1_ASAP7_75t_R   g002(.A(p12), .B(p11), .Y(new_n93_));
  OAI21x1_ASAP7_75t_R  g003(.A1(p9), .A2(p8), .B(p10), .Y(new_n94_));
  NAND2x1_ASAP7_75t_R  g004(.A(p14), .B(p13), .Y(new_n95_));
  AOI21x1_ASAP7_75t_R  g005(.A1(new_n93_), .A2(new_n94_), .B(new_n95_), .Y(new_n96_));
  AO21x1_ASAP7_75t_R   g006(.A1(p16), .A2(p15), .B(p17), .Y(new_n97_));
  AOI21x1_ASAP7_75t_R  g007(.A1(p16), .A2(new_n96_), .B(new_n97_), .Y(new_n98_));
  NAND2x1_ASAP7_75t_R  g008(.A(p19), .B(p18), .Y(new_n99_));
  INVx1_ASAP7_75t_R    g009(.A(p21), .Y(new_n100_));
  INVx1_ASAP7_75t_R    g010(.A(p20), .Y(new_n101_));
  AND3x1_ASAP7_75t_R   g011(.A(new_n99_), .B(new_n100_), .C(new_n101_), .Y(new_n102_));
  AOI21x1_ASAP7_75t_R  g012(.A1(new_n92_), .A2(new_n98_), .B(new_n102_), .Y(new_n103_));
  AO21x1_ASAP7_75t_R   g013(.A1(new_n91_), .A2(new_n103_), .B(p25), .Y(new_n104_));
  INVx1_ASAP7_75t_R    g014(.A(p11), .Y(new_n105_));
  INVx1_ASAP7_75t_R    g015(.A(p10), .Y(new_n106_));
  NOR2x1_ASAP7_75t_R   g016(.A(p9), .B(p8), .Y(new_n107_));
  AOI21x1_ASAP7_75t_R  g017(.A1(new_n106_), .A2(new_n107_), .B(new_n105_), .Y(new_n108_));
  AOI21x1_ASAP7_75t_R  g018(.A1(new_n105_), .A2(new_n94_), .B(new_n108_), .Y(new_n109_));
  INVx1_ASAP7_75t_R    g019(.A(p13), .Y(new_n110_));
  NOR2x1_ASAP7_75t_R   g020(.A(p12), .B(new_n110_), .Y(new_n111_));
  INVx1_ASAP7_75t_R    g021(.A(p17), .Y(new_n112_));
  AND3x1_ASAP7_75t_R   g022(.A(new_n111_), .B(new_n112_), .C(p18), .Y(new_n113_));
  INVx1_ASAP7_75t_R    g023(.A(p9), .Y(new_n114_));
  NOR2x1_ASAP7_75t_R   g024(.A(p5), .B(p4), .Y(new_n115_));
  NOR2x1_ASAP7_75t_R   g025(.A(p3), .B(p2), .Y(new_n116_));
  NOR2x1_ASAP7_75t_R   g026(.A(p6), .B(p7), .Y(new_n117_));
  AND5x1_ASAP7_75t_R   g027(.A(new_n114_), .B(new_n115_), .C(new_n116_), .D(new_n117_), .E(p8), .Y(new_n118_));
  INVx1_ASAP7_75t_R    g028(.A(p25), .Y(new_n119_));
  AND3x1_ASAP7_75t_R   g029(.A(new_n119_), .B(p23), .C(p24), .Y(new_n120_));
  NOR2x1_ASAP7_75t_R   g030(.A(p0), .B(p1), .Y(new_n121_));
  AND5x1_ASAP7_75t_R   g031(.A(p22), .B(new_n121_), .C(new_n100_), .D(p19), .E(new_n101_), .Y(new_n122_));
  AND5x1_ASAP7_75t_R   g032(.A(new_n109_), .B(new_n113_), .C(new_n118_), .D(new_n120_), .E(new_n122_), .Y(new_n123_));
  INVx1_ASAP7_75t_R    g033(.A(p14), .Y(new_n124_));
  AO21x1_ASAP7_75t_R   g034(.A1(new_n93_), .A2(new_n94_), .B(new_n124_), .Y(new_n125_));
  OR3x1_ASAP7_75t_R    g035(.A(new_n125_), .B(new_n110_), .C(p15), .Y(new_n126_));
  AO21x1_ASAP7_75t_R   g036(.A1(new_n93_), .A2(new_n94_), .B(new_n110_), .Y(new_n127_));
  NAND2x1_ASAP7_75t_R  g037(.A(new_n124_), .B(new_n127_), .Y(new_n128_));
  NAND2x1_ASAP7_75t_R  g038(.A(p16), .B(new_n96_), .Y(new_n129_));
  NAND2x1_ASAP7_75t_R  g039(.A(p16), .B(p15), .Y(new_n130_));
  AOI22x1_ASAP7_75t_R  g040(.A1(new_n126_), .A2(new_n128_), .B1(new_n129_), .B2(new_n130_), .Y(new_n131_));
  AND3x1_ASAP7_75t_R   g041(.A(p26), .B(p27), .C(p28), .Y(new_n132_));
  INVx1_ASAP7_75t_R    g042(.A(new_n132_), .Y(new_n133_));
  AOI21x1_ASAP7_75t_R  g043(.A1(new_n123_), .A2(new_n131_), .B(new_n133_), .Y(new_n134_));
  INVx1_ASAP7_75t_R    g044(.A(new_n92_), .Y(new_n135_));
  AOI21x1_ASAP7_75t_R  g045(.A1(p22), .A2(new_n135_), .B(p23), .Y(new_n136_));
  INVx1_ASAP7_75t_R    g046(.A(p22), .Y(new_n137_));
  OR3x1_ASAP7_75t_R    g047(.A(new_n98_), .B(new_n137_), .C(new_n99_), .Y(new_n138_));
  AND3x1_ASAP7_75t_R   g048(.A(new_n100_), .B(new_n101_), .C(p22), .Y(new_n139_));
  AND4x2_ASAP7_75t_R   g049(.A(p7), .B(p2), .C(p10), .D(p1), .Y(new_n140_));
  AND5x1_ASAP7_75t_R   g050(.A(new_n132_), .B(new_n139_), .C(new_n93_), .D(new_n107_), .E(new_n140_), .Y(new_n141_));
  NOR2x1_ASAP7_75t_R   g051(.A(p15), .B(new_n124_), .Y(new_n142_));
  NOR2x1_ASAP7_75t_R   g052(.A(p25), .B(new_n110_), .Y(new_n143_));
  AND4x2_ASAP7_75t_R   g053(.A(p24), .B(p3), .C(p18), .D(p6), .Y(new_n144_));
  AND4x2_ASAP7_75t_R   g054(.A(p4), .B(p59), .C(p16), .D(p19), .Y(new_n145_));
  AND2x2_ASAP7_75t_R   g055(.A(p5), .B(p0), .Y(new_n146_));
  AND5x1_ASAP7_75t_R   g056(.A(new_n142_), .B(new_n143_), .C(new_n144_), .D(new_n145_), .E(new_n146_), .Y(new_n147_));
  NAND3x1_ASAP7_75t_R  g057(.A(new_n141_), .B(new_n98_), .C(new_n147_), .Y(new_n148_));
  AO21x1_ASAP7_75t_R   g058(.A1(new_n136_), .A2(new_n138_), .B(new_n148_), .Y(new_n149_));
  AO21x1_ASAP7_75t_R   g059(.A1(p16), .A2(new_n96_), .B(new_n97_), .Y(new_n150_));
  INVx1_ASAP7_75t_R    g060(.A(new_n102_), .Y(new_n151_));
  OA211x2_ASAP7_75t_R  g061(.A1(new_n135_), .A2(new_n150_), .B(new_n151_), .C(new_n91_), .Y(new_n152_));
  OAI21x1_ASAP7_75t_R  g062(.A1(p25), .A2(new_n152_), .B(new_n132_), .Y(new_n153_));
  AO22x1_ASAP7_75t_R   g063(.A1(new_n104_), .A2(new_n134_), .B1(new_n149_), .B2(new_n153_), .Y(o0));
  AOI21x1_ASAP7_75t_R  g064(.A1(new_n91_), .A2(new_n103_), .B(p25), .Y(new_n155_));
  OA31x2_ASAP7_75t_R   g065(.A1(new_n137_), .A2(new_n99_), .A3(new_n98_), .B1(new_n136_), .Y(new_n156_));
  OAI22x1_ASAP7_75t_R  g066(.A1(new_n155_), .A2(new_n133_), .B1(new_n156_), .B2(new_n148_), .Y(new_n157_));
  INVx1_ASAP7_75t_R    g067(.A(p46), .Y(new_n158_));
  NOR2x1_ASAP7_75t_R   g068(.A(p45), .B(new_n158_), .Y(new_n159_));
  AND3x1_ASAP7_75t_R   g069(.A(p56), .B(p58), .C(p57), .Y(new_n160_));
  AND2x2_ASAP7_75t_R   g070(.A(p29), .B(p30), .Y(new_n161_));
  AND2x2_ASAP7_75t_R   g071(.A(p40), .B(p31), .Y(new_n162_));
  AND2x2_ASAP7_75t_R   g072(.A(p36), .B(p33), .Y(new_n163_));
  AND5x1_ASAP7_75t_R   g073(.A(new_n159_), .B(new_n160_), .C(new_n161_), .D(new_n162_), .E(new_n163_), .Y(new_n164_));
  INVx1_ASAP7_75t_R    g074(.A(p35), .Y(new_n165_));
  NOR2x1_ASAP7_75t_R   g075(.A(p55), .B(new_n165_), .Y(new_n166_));
  AND4x2_ASAP7_75t_R   g076(.A(p34), .B(p49), .C(p43), .D(p44), .Y(new_n167_));
  AND2x2_ASAP7_75t_R   g077(.A(p32), .B(p37), .Y(new_n168_));
  AND3x1_ASAP7_75t_R   g078(.A(new_n166_), .B(new_n167_), .C(new_n168_), .Y(new_n169_));
  INVx1_ASAP7_75t_R    g079(.A(p51), .Y(new_n170_));
  AND3x1_ASAP7_75t_R   g080(.A(p54), .B(p53), .C(p52), .Y(new_n171_));
  AND2x2_ASAP7_75t_R   g081(.A(new_n170_), .B(new_n171_), .Y(new_n172_));
  NOR2x1_ASAP7_75t_R   g082(.A(p47), .B(p48), .Y(new_n173_));
  OR4x2_ASAP7_75t_R    g083(.A(p39), .B(p41), .C(p38), .D(p42), .Y(new_n174_));
  NOR2x1_ASAP7_75t_R   g084(.A(new_n173_), .B(new_n174_), .Y(new_n175_));
  AND4x2_ASAP7_75t_R   g085(.A(new_n164_), .B(new_n169_), .C(new_n172_), .D(new_n175_), .Y(new_n176_));
  NOR2x1_ASAP7_75t_R   g086(.A(p50), .B(p59), .Y(new_n177_));
  NOR2x1_ASAP7_75t_R   g087(.A(p41), .B(p42), .Y(new_n178_));
  OAI21x1_ASAP7_75t_R  g088(.A1(p39), .A2(p38), .B(p40), .Y(new_n179_));
  NAND2x1_ASAP7_75t_R  g089(.A(p43), .B(p44), .Y(new_n180_));
  AOI211x1_ASAP7_75t_R g090(.A1(new_n178_), .A2(new_n179_), .B(new_n158_), .C(new_n180_), .Y(new_n181_));
  AO21x1_ASAP7_75t_R   g091(.A1(p46), .A2(p45), .B(p47), .Y(new_n182_));
  AOI21x1_ASAP7_75t_R  g092(.A1(new_n178_), .A2(new_n179_), .B(new_n180_), .Y(new_n183_));
  NOR2x1_ASAP7_75t_R   g093(.A(p48), .B(new_n158_), .Y(new_n184_));
  OAI21x1_ASAP7_75t_R  g094(.A1(p45), .A2(new_n183_), .B(new_n184_), .Y(new_n185_));
  OAI21x1_ASAP7_75t_R  g095(.A1(new_n181_), .A2(new_n182_), .B(new_n185_), .Y(new_n186_));
  NAND3x1_ASAP7_75t_R  g096(.A(new_n176_), .B(new_n177_), .C(new_n186_), .Y(new_n187_));
  OR3x1_ASAP7_75t_R    g097(.A(p55), .B(p51), .C(p50), .Y(new_n188_));
  NAND2x1_ASAP7_75t_R  g098(.A(p49), .B(p48), .Y(new_n189_));
  INVx1_ASAP7_75t_R    g099(.A(new_n189_), .Y(new_n190_));
  OA21x2_ASAP7_75t_R   g100(.A1(new_n182_), .A2(new_n181_), .B(new_n190_), .Y(new_n191_));
  OA21x2_ASAP7_75t_R   g101(.A1(p55), .A2(new_n171_), .B(new_n160_), .Y(new_n192_));
  OAI21x1_ASAP7_75t_R  g102(.A1(new_n188_), .A2(new_n191_), .B(new_n192_), .Y(new_n193_));
  AO21x1_ASAP7_75t_R   g103(.A1(p46), .A2(new_n183_), .B(new_n182_), .Y(new_n194_));
  NOR2x1_ASAP7_75t_R   g104(.A(p31), .B(p36), .Y(new_n195_));
  INVx1_ASAP7_75t_R    g105(.A(p37), .Y(new_n196_));
  AND3x1_ASAP7_75t_R   g106(.A(new_n195_), .B(new_n196_), .C(p40), .Y(new_n197_));
  NOR2x1_ASAP7_75t_R   g107(.A(p55), .B(p32), .Y(new_n198_));
  INVx1_ASAP7_75t_R    g108(.A(p34), .Y(new_n199_));
  AND3x1_ASAP7_75t_R   g109(.A(new_n198_), .B(new_n199_), .C(new_n165_), .Y(new_n200_));
  NOR2x1_ASAP7_75t_R   g110(.A(p45), .B(p42), .Y(new_n201_));
  INVx1_ASAP7_75t_R    g111(.A(p39), .Y(new_n202_));
  AND3x1_ASAP7_75t_R   g112(.A(new_n201_), .B(new_n202_), .C(p38), .Y(new_n203_));
  NOR2x1_ASAP7_75t_R   g113(.A(p33), .B(p50), .Y(new_n204_));
  INVx1_ASAP7_75t_R    g114(.A(p30), .Y(new_n205_));
  AND3x1_ASAP7_75t_R   g115(.A(new_n204_), .B(p56), .C(new_n205_), .Y(new_n206_));
  AND4x2_ASAP7_75t_R   g116(.A(new_n197_), .B(new_n200_), .C(new_n203_), .D(new_n206_), .Y(new_n207_));
  OAI21x1_ASAP7_75t_R  g117(.A1(p45), .A2(new_n183_), .B(new_n158_), .Y(new_n208_));
  XOR2x2_ASAP7_75t_R   g118(.A(new_n179_), .B(p41), .Y(new_n209_));
  INVx1_ASAP7_75t_R    g119(.A(new_n209_), .Y(new_n210_));
  AND2x2_ASAP7_75t_R   g120(.A(p47), .B(p46), .Y(new_n211_));
  NOR3x1_ASAP7_75t_R   g121(.A(new_n211_), .B(new_n189_), .C(new_n180_), .Y(new_n212_));
  AND3x1_ASAP7_75t_R   g122(.A(new_n212_), .B(new_n170_), .C(new_n171_), .Y(new_n213_));
  AND5x1_ASAP7_75t_R   g123(.A(new_n194_), .B(new_n207_), .C(new_n208_), .D(new_n210_), .E(new_n213_), .Y(new_n214_));
  NOR2x1_ASAP7_75t_R   g124(.A(p29), .B(p59), .Y(new_n215_));
  AOI22x1_ASAP7_75t_R  g125(.A1(new_n187_), .A2(new_n193_), .B1(new_n214_), .B2(new_n215_), .Y(new_n216_));
  AOI211x1_ASAP7_75t_R g126(.A1(new_n123_), .A2(new_n131_), .B(new_n133_), .C(new_n155_), .Y(new_n217_));
  AOI21x1_ASAP7_75t_R  g127(.A1(new_n157_), .A2(new_n216_), .B(new_n217_), .Y(o1));
  INVx1_ASAP7_75t_R    g128(.A(p36), .Y(new_n219_));
  NAND3x1_ASAP7_75t_R  g129(.A(new_n206_), .B(p40), .C(new_n219_), .Y(new_n220_));
  NOR2x1_ASAP7_75t_R   g130(.A(p37), .B(p31), .Y(new_n221_));
  NAND2x1_ASAP7_75t_R  g131(.A(new_n221_), .B(new_n203_), .Y(new_n222_));
  OR5x1_ASAP7_75t_R    g132(.A(p35), .B(new_n211_), .C(p55), .D(new_n189_), .E(new_n180_), .Y(new_n223_));
  NAND2x1_ASAP7_75t_R  g133(.A(p54), .B(p53), .Y(new_n224_));
  INVx1_ASAP7_75t_R    g134(.A(p52), .Y(new_n225_));
  OR5x1_ASAP7_75t_R    g135(.A(p34), .B(new_n224_), .C(p32), .D(p51), .E(new_n225_), .Y(new_n226_));
  OR5x1_ASAP7_75t_R    g136(.A(new_n209_), .B(new_n220_), .C(new_n222_), .D(new_n223_), .E(new_n226_), .Y(new_n227_));
  OR3x1_ASAP7_75t_R    g137(.A(new_n183_), .B(p47), .C(p45), .Y(new_n228_));
  NAND2x1_ASAP7_75t_R  g138(.A(p29), .B(p59), .Y(new_n229_));
  NAND3x1_ASAP7_75t_R  g139(.A(new_n228_), .B(new_n208_), .C(new_n229_), .Y(new_n230_));
  OA21x2_ASAP7_75t_R   g140(.A1(new_n188_), .A2(new_n191_), .B(new_n192_), .Y(new_n231_));
  OAI21x1_ASAP7_75t_R  g141(.A1(new_n227_), .A2(new_n230_), .B(new_n231_), .Y(new_n232_));
  AOI221x1_ASAP7_75t_R g142(.A1(new_n134_), .A2(new_n104_), .B1(new_n153_), .B2(new_n149_), .C(new_n232_), .Y(o2));
  assign               o3 = 1'b0;
  assign               o4 = 1'b0;
  assign               o5 = 1'b0;
  assign               o6 = 1'b0;
  assign               o7 = 1'b0;
  assign               o8 = 1'b0;
  assign               o9 = 1'b0;
  assign               o10 = 1'b0;
  assign               o11 = 1'b0;
  assign               o12 = 1'b0;
  assign               o13 = 1'b0;
  assign               o14 = 1'b0;
  assign               o15 = 1'b0;
  assign               o16 = 1'b0;
  assign               o17 = 1'b0;
  assign               o18 = 1'b0;
  assign               o19 = 1'b0;
  assign               o20 = 1'b0;
  assign               o21 = 1'b0;
  assign               o22 = 1'b0;
  assign               o23 = 1'b0;
  assign               o24 = 1'b0;
  assign               o25 = 1'b0;
  assign               o26 = 1'b0;
  assign               o27 = 1'b0;
  assign               o28 = 1'b0;
  assign               o29 = 1'b0;
endmodule


