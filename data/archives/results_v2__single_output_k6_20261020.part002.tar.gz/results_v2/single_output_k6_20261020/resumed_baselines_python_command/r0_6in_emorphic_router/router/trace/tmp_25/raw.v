// Benchmark "/tmp/" written by ABC on Tue Oct 20 18:11:46 2026

module \/tmp/  ( 
    p6, p51, p19, p4, p5, p9, p25, p22, p16, p31, p41, p26, p40, p29, p11,
    p57, p18, p55, p59, p12, p15, p14, p43, p0, p44, p58, p54, p27, p32,
    p35, p13, p53, p47, p48, p37, p52, p46, p49, p20, p36, p28, p45, p30,
    p34, p50, p7, p21, p1, p17, p33, p56, p38, p24, p39, p3, p23, p42, p2,
    p10, p8,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25, o26, o27, o28, o29  );
  input  p6, p51, p19, p4, p5, p9, p25, p22, p16, p31, p41, p26, p40,
    p29, p11, p57, p18, p55, p59, p12, p15, p14, p43, p0, p44, p58, p54,
    p27, p32, p35, p13, p53, p47, p48, p37, p52, p46, p49, p20, p36, p28,
    p45, p30, p34, p50, p7, p21, p1, p17, p33, p56, p38, p24, p39, p3, p23,
    p42, p2, p10, p8;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25, o26, o27, o28, o29;
  wire new_n91_, new_n92_, new_n93_, new_n94_, new_n95_, new_n96_, new_n97_,
    new_n98_, new_n99_, new_n100_, new_n101_, new_n102_, new_n103_,
    new_n104_, new_n105_, new_n106_, new_n107_, new_n108_, new_n109_,
    new_n110_, new_n111_, new_n112_, new_n113_, new_n114_, new_n115_,
    new_n116_, new_n117_, new_n118_, new_n119_, new_n120_, new_n121_,
    new_n122_, new_n123_, new_n124_, new_n125_, new_n126_, new_n127_,
    new_n128_, new_n129_, new_n130_, new_n131_, new_n132_, new_n133_,
    new_n134_, new_n135_, new_n136_, new_n137_, new_n138_, new_n139_,
    new_n140_, new_n141_, new_n142_, new_n143_, new_n144_, new_n145_,
    new_n146_, new_n147_, new_n148_, new_n149_, new_n151_, new_n152_,
    new_n153_, new_n154_, new_n155_, new_n156_, new_n157_, new_n158_,
    new_n159_, new_n160_, new_n161_, new_n162_, new_n163_, new_n164_,
    new_n165_, new_n166_, new_n167_, new_n168_, new_n169_, new_n170_,
    new_n171_, new_n172_, new_n173_, new_n174_, new_n175_, new_n176_,
    new_n177_, new_n178_, new_n179_, new_n180_, new_n181_, new_n182_,
    new_n183_, new_n184_, new_n185_, new_n186_, new_n187_, new_n188_,
    new_n189_, new_n190_, new_n191_, new_n192_, new_n193_, new_n194_,
    new_n195_, new_n196_, new_n197_, new_n198_, new_n199_, new_n200_,
    new_n201_, new_n202_, new_n203_, new_n204_, new_n205_, new_n206_,
    new_n207_, new_n208_, new_n209_, new_n210_, new_n211_, new_n212_,
    new_n213_, new_n214_, new_n216_, new_n217_, new_n218_, new_n219_,
    new_n220_, new_n221_, new_n222_, new_n223_, new_n224_, new_n225_,
    new_n226_, new_n227_, new_n228_, new_n229_, new_n230_, new_n231_,
    new_n232_, new_n233_, new_n234_, new_n235_, new_n236_, new_n237_,
    new_n238_;
  AND3x1_ASAP7_75t_R   g000(.A(p26), .B(p27), .C(p28), .Y(new_n91_));
  INVx1_ASAP7_75t_R    g001(.A(new_n91_), .Y(new_n92_));
  NAND2x1_ASAP7_75t_R  g002(.A(p24), .B(p23), .Y(new_n93_));
  NOR2x1_ASAP7_75t_R   g003(.A(p11), .B(p12), .Y(new_n94_));
  OAI21x1_ASAP7_75t_R  g004(.A1(p9), .A2(p8), .B(p10), .Y(new_n95_));
  NAND2x1_ASAP7_75t_R  g005(.A(new_n94_), .B(new_n95_), .Y(new_n96_));
  NAND2x1_ASAP7_75t_R  g006(.A(p14), .B(p13), .Y(new_n97_));
  INVx1_ASAP7_75t_R    g007(.A(new_n97_), .Y(new_n98_));
  NAND3x1_ASAP7_75t_R  g008(.A(new_n96_), .B(p16), .C(new_n98_), .Y(new_n99_));
  NOR2x1_ASAP7_75t_R   g009(.A(p20), .B(p21), .Y(new_n100_));
  AO21x1_ASAP7_75t_R   g010(.A1(p16), .A2(p15), .B(p17), .Y(new_n101_));
  INVx1_ASAP7_75t_R    g011(.A(new_n101_), .Y(new_n102_));
  NAND2x1_ASAP7_75t_R  g012(.A(p19), .B(p18), .Y(new_n103_));
  INVx1_ASAP7_75t_R    g013(.A(p22), .Y(new_n104_));
  AOI21x1_ASAP7_75t_R  g014(.A1(new_n103_), .A2(new_n100_), .B(new_n104_), .Y(new_n105_));
  INVx1_ASAP7_75t_R    g015(.A(new_n105_), .Y(new_n106_));
  AO31x2_ASAP7_75t_R   g016(.A1(new_n99_), .A2(new_n100_), .A3(new_n102_), .B(new_n106_), .Y(new_n107_));
  NAND2x1_ASAP7_75t_R  g017(.A(p25), .B(new_n91_), .Y(new_n108_));
  OA31x2_ASAP7_75t_R   g018(.A1(new_n92_), .A2(new_n93_), .A3(new_n107_), .B1(new_n108_), .Y(new_n109_));
  INVx1_ASAP7_75t_R    g019(.A(p16), .Y(new_n110_));
  AOI211x1_ASAP7_75t_R g020(.A1(new_n94_), .A2(new_n95_), .B(new_n110_), .C(new_n97_), .Y(new_n111_));
  AO21x1_ASAP7_75t_R   g021(.A1(p16), .A2(p15), .B(new_n111_), .Y(new_n112_));
  OR4x2_ASAP7_75t_R    g022(.A(p5), .B(p9), .C(p12), .D(p0), .Y(new_n113_));
  INVx1_ASAP7_75t_R    g023(.A(p13), .Y(new_n114_));
  OR4x2_ASAP7_75t_R    g024(.A(new_n114_), .B(p7), .C(p1), .D(p17), .Y(new_n115_));
  NOR2x1_ASAP7_75t_R   g025(.A(new_n113_), .B(new_n115_), .Y(new_n116_));
  INVx1_ASAP7_75t_R    g026(.A(p11), .Y(new_n117_));
  INVx1_ASAP7_75t_R    g027(.A(p18), .Y(new_n118_));
  OR5x1_ASAP7_75t_R    g028(.A(p6), .B(new_n93_), .C(p4), .D(p25), .E(new_n118_), .Y(new_n119_));
  AOI21x1_ASAP7_75t_R  g029(.A1(new_n117_), .A2(new_n95_), .B(new_n119_), .Y(new_n120_));
  AND3x1_ASAP7_75t_R   g030(.A(new_n100_), .B(p19), .C(p22), .Y(new_n121_));
  NOR2x1_ASAP7_75t_R   g031(.A(p3), .B(p2), .Y(new_n122_));
  AND3x1_ASAP7_75t_R   g032(.A(new_n121_), .B(p8), .C(new_n122_), .Y(new_n123_));
  INVx1_ASAP7_75t_R    g033(.A(p14), .Y(new_n124_));
  OR3x1_ASAP7_75t_R    g034(.A(new_n124_), .B(new_n114_), .C(p15), .Y(new_n125_));
  NAND2x1_ASAP7_75t_R  g035(.A(new_n124_), .B(new_n114_), .Y(new_n126_));
  OR3x1_ASAP7_75t_R    g036(.A(p9), .B(p10), .C(p8), .Y(new_n127_));
  AOI22x1_ASAP7_75t_R  g037(.A1(new_n125_), .A2(new_n126_), .B1(p11), .B2(new_n127_), .Y(new_n128_));
  AND5x1_ASAP7_75t_R   g038(.A(new_n112_), .B(new_n116_), .C(new_n120_), .D(new_n123_), .E(new_n128_), .Y(new_n129_));
  NAND2x1_ASAP7_75t_R  g039(.A(new_n102_), .B(new_n99_), .Y(new_n130_));
  AND5x1_ASAP7_75t_R   g040(.A(p24), .B(new_n91_), .C(p3), .D(p2), .E(p10), .Y(new_n131_));
  NAND2x1_ASAP7_75t_R  g041(.A(new_n121_), .B(new_n131_), .Y(new_n132_));
  AOI211x1_ASAP7_75t_R g042(.A1(new_n98_), .A2(new_n96_), .B(p16), .C(p15), .Y(new_n133_));
  NAND2x1_ASAP7_75t_R  g043(.A(p5), .B(p59), .Y(new_n134_));
  OR3x1_ASAP7_75t_R    g044(.A(new_n134_), .B(p15), .C(new_n124_), .Y(new_n135_));
  NAND2x1_ASAP7_75t_R  g045(.A(p0), .B(p13), .Y(new_n136_));
  NAND2x1_ASAP7_75t_R  g046(.A(p7), .B(p1), .Y(new_n137_));
  OR3x1_ASAP7_75t_R    g047(.A(new_n135_), .B(new_n136_), .C(new_n137_), .Y(new_n138_));
  AND3x1_ASAP7_75t_R   g048(.A(new_n94_), .B(p6), .C(p4), .Y(new_n139_));
  NOR2x1_ASAP7_75t_R   g049(.A(p9), .B(p8), .Y(new_n140_));
  NOR2x1_ASAP7_75t_R   g050(.A(p25), .B(new_n118_), .Y(new_n141_));
  NAND3x1_ASAP7_75t_R  g051(.A(new_n139_), .B(new_n140_), .C(new_n141_), .Y(new_n142_));
  OR5x1_ASAP7_75t_R    g052(.A(new_n130_), .B(new_n132_), .C(new_n133_), .D(new_n138_), .E(new_n142_), .Y(new_n143_));
  INVx1_ASAP7_75t_R    g053(.A(new_n100_), .Y(new_n144_));
  AOI21x1_ASAP7_75t_R  g054(.A1(p22), .A2(new_n144_), .B(p23), .Y(new_n145_));
  INVx1_ASAP7_75t_R    g055(.A(new_n93_), .Y(new_n146_));
  OA31x2_ASAP7_75t_R   g056(.A1(new_n144_), .A2(new_n101_), .A3(new_n111_), .B1(new_n105_), .Y(new_n147_));
  AOI21x1_ASAP7_75t_R  g057(.A1(new_n146_), .A2(new_n147_), .B(p25), .Y(new_n148_));
  OAI22x1_ASAP7_75t_R  g058(.A1(new_n143_), .A2(new_n145_), .B1(new_n92_), .B2(new_n148_), .Y(new_n149_));
  OAI21x1_ASAP7_75t_R  g059(.A1(new_n109_), .A2(new_n129_), .B(new_n149_), .Y(o0));
  NOR3x1_ASAP7_75t_R   g060(.A(new_n129_), .B(new_n148_), .C(new_n92_), .Y(new_n151_));
  AND2x2_ASAP7_75t_R   g061(.A(p48), .B(p49), .Y(new_n152_));
  INVx1_ASAP7_75t_R    g062(.A(new_n152_), .Y(new_n153_));
  NOR2x1_ASAP7_75t_R   g063(.A(p41), .B(p42), .Y(new_n154_));
  OAI21x1_ASAP7_75t_R  g064(.A1(p38), .A2(p39), .B(p40), .Y(new_n155_));
  NAND2x1_ASAP7_75t_R  g065(.A(p43), .B(p44), .Y(new_n156_));
  AOI21x1_ASAP7_75t_R  g066(.A1(new_n154_), .A2(new_n155_), .B(new_n156_), .Y(new_n157_));
  AO21x1_ASAP7_75t_R   g067(.A1(p46), .A2(p45), .B(p47), .Y(new_n158_));
  AOI21x1_ASAP7_75t_R  g068(.A1(p46), .A2(new_n157_), .B(new_n158_), .Y(new_n159_));
  INVx1_ASAP7_75t_R    g069(.A(p51), .Y(new_n160_));
  INVx1_ASAP7_75t_R    g070(.A(p55), .Y(new_n161_));
  INVx1_ASAP7_75t_R    g071(.A(p50), .Y(new_n162_));
  AND3x1_ASAP7_75t_R   g072(.A(new_n160_), .B(new_n161_), .C(new_n162_), .Y(new_n163_));
  OAI21x1_ASAP7_75t_R  g073(.A1(new_n153_), .A2(new_n159_), .B(new_n163_), .Y(new_n164_));
  AND3x1_ASAP7_75t_R   g074(.A(p54), .B(p53), .C(p52), .Y(new_n165_));
  AND3x1_ASAP7_75t_R   g075(.A(p57), .B(p58), .C(p56), .Y(new_n166_));
  OA21x2_ASAP7_75t_R   g076(.A1(p55), .A2(new_n165_), .B(new_n166_), .Y(new_n167_));
  INVx1_ASAP7_75t_R    g077(.A(p59), .Y(new_n168_));
  AOI22x1_ASAP7_75t_R  g078(.A1(new_n164_), .A2(new_n167_), .B1(new_n168_), .B2(new_n162_), .Y(new_n169_));
  AND3x1_ASAP7_75t_R   g079(.A(p30), .B(p34), .C(p33), .Y(new_n170_));
  AND2x2_ASAP7_75t_R   g080(.A(p54), .B(p53), .Y(new_n171_));
  AND5x1_ASAP7_75t_R   g081(.A(p40), .B(new_n166_), .C(new_n170_), .D(new_n171_), .E(new_n161_), .Y(new_n172_));
  NAND2x1_ASAP7_75t_R  g082(.A(p41), .B(p42), .Y(new_n173_));
  INVx1_ASAP7_75t_R    g083(.A(p43), .Y(new_n174_));
  OAI21x1_ASAP7_75t_R  g084(.A1(new_n173_), .A2(new_n155_), .B(new_n174_), .Y(new_n175_));
  NOR2x1_ASAP7_75t_R   g085(.A(p38), .B(p39), .Y(new_n176_));
  AND5x1_ASAP7_75t_R   g086(.A(p31), .B(new_n176_), .C(p29), .D(p44), .E(p32), .Y(new_n177_));
  AND2x2_ASAP7_75t_R   g087(.A(p37), .B(p46), .Y(new_n178_));
  INVx1_ASAP7_75t_R    g088(.A(p45), .Y(new_n179_));
  AND3x1_ASAP7_75t_R   g089(.A(new_n178_), .B(p36), .C(new_n179_), .Y(new_n180_));
  INVx1_ASAP7_75t_R    g090(.A(p47), .Y(new_n181_));
  AND3x1_ASAP7_75t_R   g091(.A(new_n152_), .B(p35), .C(new_n181_), .Y(new_n182_));
  AND5x1_ASAP7_75t_R   g092(.A(new_n172_), .B(new_n175_), .C(new_n177_), .D(new_n180_), .E(new_n182_), .Y(new_n183_));
  NAND2x1_ASAP7_75t_R  g093(.A(p52), .B(new_n160_), .Y(new_n184_));
  OAI21x1_ASAP7_75t_R  g094(.A1(new_n153_), .A2(new_n159_), .B(new_n184_), .Y(new_n185_));
  AO21x1_ASAP7_75t_R   g095(.A1(new_n154_), .A2(new_n155_), .B(new_n174_), .Y(new_n186_));
  NAND3x1_ASAP7_75t_R  g096(.A(new_n183_), .B(new_n185_), .C(new_n186_), .Y(new_n187_));
  NOR3x1_ASAP7_75t_R   g097(.A(new_n157_), .B(new_n181_), .C(p45), .Y(new_n188_));
  AND2x2_ASAP7_75t_R   g098(.A(p46), .B(p45), .Y(new_n189_));
  AO21x1_ASAP7_75t_R   g099(.A1(p46), .A2(new_n157_), .B(new_n189_), .Y(new_n190_));
  NOR2x1_ASAP7_75t_R   g100(.A(p29), .B(p59), .Y(new_n191_));
  OAI21x1_ASAP7_75t_R  g101(.A1(new_n188_), .A2(new_n190_), .B(new_n191_), .Y(new_n192_));
  NOR2x1_ASAP7_75t_R   g102(.A(p39), .B(p42), .Y(new_n193_));
  AND3x1_ASAP7_75t_R   g103(.A(new_n193_), .B(p56), .C(p38), .Y(new_n194_));
  NOR2x1_ASAP7_75t_R   g104(.A(p36), .B(p45), .Y(new_n195_));
  AND3x1_ASAP7_75t_R   g105(.A(new_n195_), .B(p40), .C(new_n161_), .Y(new_n196_));
  NOR3x1_ASAP7_75t_R   g106(.A(new_n156_), .B(p37), .C(p50), .Y(new_n197_));
  AND3x1_ASAP7_75t_R   g107(.A(new_n194_), .B(new_n196_), .C(new_n197_), .Y(new_n198_));
  INVx1_ASAP7_75t_R    g108(.A(p41), .Y(new_n199_));
  NAND2x1_ASAP7_75t_R  g109(.A(new_n199_), .B(new_n155_), .Y(new_n200_));
  NAND2x1_ASAP7_75t_R  g110(.A(p47), .B(p46), .Y(new_n201_));
  NOR2x1_ASAP7_75t_R   g111(.A(p31), .B(p32), .Y(new_n202_));
  AND5x1_ASAP7_75t_R   g112(.A(new_n200_), .B(new_n152_), .C(new_n171_), .D(new_n201_), .E(new_n202_), .Y(new_n203_));
  NOR2x1_ASAP7_75t_R   g113(.A(new_n199_), .B(new_n155_), .Y(new_n204_));
  OR4x2_ASAP7_75t_R    g114(.A(p35), .B(p30), .C(p34), .D(p33), .Y(new_n205_));
  NOR3x1_ASAP7_75t_R   g115(.A(new_n204_), .B(new_n205_), .C(new_n184_), .Y(new_n206_));
  NAND3x1_ASAP7_75t_R  g116(.A(new_n198_), .B(new_n203_), .C(new_n206_), .Y(new_n207_));
  INVx1_ASAP7_75t_R    g117(.A(p46), .Y(new_n208_));
  AOI211x1_ASAP7_75t_R g118(.A1(new_n154_), .A2(new_n155_), .B(new_n208_), .C(new_n156_), .Y(new_n209_));
  OAI21x1_ASAP7_75t_R  g119(.A1(new_n158_), .A2(new_n209_), .B(new_n152_), .Y(new_n210_));
  INVx1_ASAP7_75t_R    g120(.A(new_n167_), .Y(new_n211_));
  AOI21x1_ASAP7_75t_R  g121(.A1(new_n163_), .A2(new_n210_), .B(new_n211_), .Y(new_n212_));
  OAI21x1_ASAP7_75t_R  g122(.A1(new_n192_), .A2(new_n207_), .B(new_n212_), .Y(new_n213_));
  OAI21x1_ASAP7_75t_R  g123(.A1(new_n169_), .A2(new_n187_), .B(new_n213_), .Y(new_n214_));
  OAI21x1_ASAP7_75t_R  g124(.A1(new_n151_), .A2(new_n214_), .B(new_n149_), .Y(o1));
  NOR3x1_ASAP7_75t_R   g125(.A(new_n135_), .B(new_n136_), .C(new_n137_), .Y(new_n216_));
  AND3x1_ASAP7_75t_R   g126(.A(new_n139_), .B(new_n140_), .C(new_n141_), .Y(new_n217_));
  NAND2x1_ASAP7_75t_R  g127(.A(new_n216_), .B(new_n217_), .Y(new_n218_));
  OR5x1_ASAP7_75t_R    g128(.A(new_n130_), .B(new_n218_), .C(new_n145_), .D(new_n133_), .E(new_n132_), .Y(new_n219_));
  AND2x2_ASAP7_75t_R   g129(.A(p29), .B(p59), .Y(new_n220_));
  NOR2x1_ASAP7_75t_R   g130(.A(p45), .B(new_n157_), .Y(new_n221_));
  NAND2x1_ASAP7_75t_R  g131(.A(p47), .B(new_n179_), .Y(new_n222_));
  OAI22x1_ASAP7_75t_R  g132(.A1(new_n221_), .A2(new_n208_), .B1(new_n157_), .B2(new_n222_), .Y(new_n223_));
  AND3x1_ASAP7_75t_R   g133(.A(new_n171_), .B(p40), .C(new_n161_), .Y(new_n224_));
  AND2x2_ASAP7_75t_R   g134(.A(p56), .B(p38), .Y(new_n225_));
  NOR2x1_ASAP7_75t_R   g135(.A(p30), .B(p34), .Y(new_n226_));
  NOR2x1_ASAP7_75t_R   g136(.A(p50), .B(p33), .Y(new_n227_));
  AND5x1_ASAP7_75t_R   g137(.A(new_n224_), .B(new_n225_), .C(new_n193_), .D(new_n226_), .E(new_n227_), .Y(new_n228_));
  AND5x1_ASAP7_75t_R   g138(.A(new_n160_), .B(new_n201_), .C(p48), .D(p52), .E(p49), .Y(new_n229_));
  INVx1_ASAP7_75t_R    g139(.A(p40), .Y(new_n230_));
  OR3x1_ASAP7_75t_R    g140(.A(new_n176_), .B(new_n199_), .C(new_n230_), .Y(new_n231_));
  INVx1_ASAP7_75t_R    g141(.A(p35), .Y(new_n232_));
  INVx1_ASAP7_75t_R    g142(.A(p37), .Y(new_n233_));
  AND3x1_ASAP7_75t_R   g143(.A(new_n195_), .B(new_n232_), .C(new_n233_), .Y(new_n234_));
  AND3x1_ASAP7_75t_R   g144(.A(new_n202_), .B(p43), .C(p44), .Y(new_n235_));
  AND5x1_ASAP7_75t_R   g145(.A(new_n200_), .B(new_n229_), .C(new_n231_), .D(new_n234_), .E(new_n235_), .Y(new_n236_));
  NAND3x1_ASAP7_75t_R  g146(.A(new_n223_), .B(new_n228_), .C(new_n236_), .Y(new_n237_));
  OAI21x1_ASAP7_75t_R  g147(.A1(new_n220_), .A2(new_n237_), .B(new_n212_), .Y(new_n238_));
  AOI211x1_ASAP7_75t_R g148(.A1(new_n109_), .A2(new_n219_), .B(new_n238_), .C(new_n151_), .Y(o2));
  assign               o3 = 1'b0;
  assign               o4 = 1'b0;
  assign               o5 = 1'b0;
  assign               o6 = 1'b0;
  assign               o7 = 1'b0;
  assign               o8 = 1'b0;
  assign               o9 = 1'b0;
  assign               o10 = 1'b0;
  assign               o11 = 1'b0;
  assign               o12 = 1'b0;
  assign               o13 = 1'b0;
  assign               o14 = 1'b0;
  assign               o15 = 1'b0;
  assign               o16 = 1'b0;
  assign               o17 = 1'b0;
  assign               o18 = 1'b0;
  assign               o19 = 1'b0;
  assign               o20 = 1'b0;
  assign               o21 = 1'b0;
  assign               o22 = 1'b0;
  assign               o23 = 1'b0;
  assign               o24 = 1'b0;
  assign               o25 = 1'b0;
  assign               o26 = 1'b0;
  assign               o27 = 1'b0;
  assign               o28 = 1'b0;
  assign               o29 = 1'b0;
endmodule


