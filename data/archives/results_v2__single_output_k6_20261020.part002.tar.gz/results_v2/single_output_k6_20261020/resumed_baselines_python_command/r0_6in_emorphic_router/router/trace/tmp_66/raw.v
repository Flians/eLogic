// Benchmark "/tmp/" written by ABC on Tue Oct 20 18:11:52 2026

module \/tmp/  ( 
    p24, p37, p51, p26, p21, p42, p33, p50, p25, p44, p48, p34, p13, p14,
    p28, p23, p43, p15, p11, p39, p18, p22, p36, p7, p40, p32, p10, p8, p2,
    p41, p53, p20, p1, p47, p30, p45, p57, p0, p52, p27, p56, p31, p35,
    p54, p58, p5, p4, p38, p9, p46, p3, p12, p6, p29, p59, p55, p49, p16,
    p19, p17,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25, o26, o27, o28, o29  );
  input  p24, p37, p51, p26, p21, p42, p33, p50, p25, p44, p48, p34, p13,
    p14, p28, p23, p43, p15, p11, p39, p18, p22, p36, p7, p40, p32, p10,
    p8, p2, p41, p53, p20, p1, p47, p30, p45, p57, p0, p52, p27, p56, p31,
    p35, p54, p58, p5, p4, p38, p9, p46, p3, p12, p6, p29, p59, p55, p49,
    p16, p19, p17;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25, o26, o27, o28, o29;
  wire new_n91_, new_n92_, new_n93_, new_n94_, new_n95_, new_n96_, new_n97_,
    new_n98_, new_n99_, new_n100_, new_n101_, new_n102_, new_n103_,
    new_n104_, new_n105_, new_n106_, new_n107_, new_n108_, new_n109_,
    new_n110_, new_n111_, new_n112_, new_n113_, new_n114_, new_n115_,
    new_n116_, new_n117_, new_n118_, new_n119_, new_n120_, new_n121_,
    new_n122_, new_n123_, new_n124_, new_n125_, new_n126_, new_n127_,
    new_n128_, new_n129_, new_n130_, new_n131_, new_n132_, new_n133_,
    new_n134_, new_n135_, new_n136_, new_n137_, new_n138_, new_n139_,
    new_n140_, new_n141_, new_n142_, new_n143_, new_n144_, new_n145_,
    new_n146_, new_n147_, new_n148_, new_n149_, new_n150_, new_n151_,
    new_n152_, new_n153_, new_n155_, new_n156_, new_n157_, new_n158_,
    new_n159_, new_n160_, new_n161_, new_n162_, new_n163_, new_n164_,
    new_n165_, new_n166_, new_n167_, new_n168_, new_n169_, new_n170_,
    new_n171_, new_n172_, new_n173_, new_n174_, new_n175_, new_n176_,
    new_n177_, new_n178_, new_n179_, new_n180_, new_n181_, new_n182_,
    new_n183_, new_n184_, new_n185_, new_n186_, new_n187_, new_n188_,
    new_n189_, new_n190_, new_n191_, new_n192_, new_n193_, new_n194_,
    new_n195_, new_n196_, new_n197_, new_n198_, new_n199_, new_n200_,
    new_n201_, new_n202_, new_n203_, new_n204_, new_n205_, new_n206_,
    new_n207_, new_n208_, new_n209_, new_n210_, new_n211_, new_n212_,
    new_n213_, new_n214_, new_n215_, new_n216_, new_n217_, new_n218_,
    new_n219_, new_n221_, new_n222_, new_n223_, new_n224_, new_n225_,
    new_n226_, new_n227_, new_n228_, new_n229_, new_n230_, new_n231_,
    new_n232_, new_n233_, new_n234_, new_n235_, new_n236_, new_n237_,
    new_n238_, new_n239_, new_n240_, new_n241_;
  AND2x2_ASAP7_75t_R   g000(.A(p24), .B(p23), .Y(new_n91_));
  NOR2x1_ASAP7_75t_R   g001(.A(p21), .B(p20), .Y(new_n92_));
  INVx1_ASAP7_75t_R    g002(.A(new_n92_), .Y(new_n93_));
  AO21x1_ASAP7_75t_R   g003(.A1(p15), .A2(p16), .B(p17), .Y(new_n94_));
  NOR2x1_ASAP7_75t_R   g004(.A(p11), .B(p12), .Y(new_n95_));
  OAI21x1_ASAP7_75t_R  g005(.A1(p8), .A2(p9), .B(p10), .Y(new_n96_));
  INVx1_ASAP7_75t_R    g006(.A(p16), .Y(new_n97_));
  NAND2x1_ASAP7_75t_R  g007(.A(p13), .B(p14), .Y(new_n98_));
  AOI211x1_ASAP7_75t_R g008(.A1(new_n95_), .A2(new_n96_), .B(new_n97_), .C(new_n98_), .Y(new_n99_));
  NAND2x1_ASAP7_75t_R  g009(.A(p18), .B(p19), .Y(new_n100_));
  INVx1_ASAP7_75t_R    g010(.A(p22), .Y(new_n101_));
  AOI21x1_ASAP7_75t_R  g011(.A1(new_n100_), .A2(new_n92_), .B(new_n101_), .Y(new_n102_));
  OA31x2_ASAP7_75t_R   g012(.A1(new_n93_), .A2(new_n94_), .A3(new_n99_), .B1(new_n102_), .Y(new_n103_));
  AOI21x1_ASAP7_75t_R  g013(.A1(new_n91_), .A2(new_n103_), .B(p25), .Y(new_n104_));
  NAND2x1_ASAP7_75t_R  g014(.A(new_n95_), .B(new_n96_), .Y(new_n105_));
  AO21x1_ASAP7_75t_R   g015(.A1(p13), .A2(new_n105_), .B(p14), .Y(new_n106_));
  AO21x1_ASAP7_75t_R   g016(.A1(new_n95_), .A2(new_n96_), .B(new_n98_), .Y(new_n107_));
  NAND2x1_ASAP7_75t_R  g017(.A(p15), .B(p16), .Y(new_n108_));
  AO211x2_ASAP7_75t_R  g018(.A1(new_n96_), .A2(new_n95_), .B(new_n97_), .C(new_n98_), .Y(new_n109_));
  AOI22x1_ASAP7_75t_R  g019(.A1(new_n106_), .A2(new_n107_), .B1(new_n108_), .B2(new_n109_), .Y(new_n110_));
  INVx1_ASAP7_75t_R    g020(.A(p13), .Y(new_n111_));
  INVx1_ASAP7_75t_R    g021(.A(p18), .Y(new_n112_));
  OR4x2_ASAP7_75t_R    g022(.A(new_n111_), .B(new_n112_), .C(p12), .D(p17), .Y(new_n113_));
  OR3x1_ASAP7_75t_R    g023(.A(p20), .B(p1), .C(p0), .Y(new_n114_));
  INVx1_ASAP7_75t_R    g024(.A(p21), .Y(new_n115_));
  AND2x2_ASAP7_75t_R   g025(.A(p22), .B(p19), .Y(new_n116_));
  NAND2x1_ASAP7_75t_R  g026(.A(new_n115_), .B(new_n116_), .Y(new_n117_));
  OR3x1_ASAP7_75t_R    g027(.A(new_n113_), .B(new_n114_), .C(new_n117_), .Y(new_n118_));
  INVx1_ASAP7_75t_R    g028(.A(p15), .Y(new_n119_));
  OR2x4_ASAP7_75t_R    g029(.A(p8), .B(p9), .Y(new_n120_));
  INVx1_ASAP7_75t_R    g030(.A(p10), .Y(new_n121_));
  NAND2x1_ASAP7_75t_R  g031(.A(p11), .B(new_n121_), .Y(new_n122_));
  AOI22x1_ASAP7_75t_R  g032(.A1(new_n120_), .A2(p11), .B1(new_n122_), .B2(new_n96_), .Y(new_n123_));
  OAI21x1_ASAP7_75t_R  g033(.A1(new_n119_), .A2(new_n107_), .B(new_n123_), .Y(new_n124_));
  INVx1_ASAP7_75t_R    g034(.A(p25), .Y(new_n125_));
  NOR2x1_ASAP7_75t_R   g035(.A(p5), .B(p4), .Y(new_n126_));
  AND3x1_ASAP7_75t_R   g036(.A(new_n91_), .B(new_n125_), .C(new_n126_), .Y(new_n127_));
  NOR2x1_ASAP7_75t_R   g037(.A(p7), .B(p6), .Y(new_n128_));
  INVx1_ASAP7_75t_R    g038(.A(p2), .Y(new_n129_));
  INVx1_ASAP7_75t_R    g039(.A(p9), .Y(new_n130_));
  INVx1_ASAP7_75t_R    g040(.A(p3), .Y(new_n131_));
  AND5x1_ASAP7_75t_R   g041(.A(p8), .B(new_n128_), .C(new_n129_), .D(new_n130_), .E(new_n131_), .Y(new_n132_));
  NAND2x1_ASAP7_75t_R  g042(.A(new_n127_), .B(new_n132_), .Y(new_n133_));
  NOR3x1_ASAP7_75t_R   g043(.A(new_n118_), .B(new_n124_), .C(new_n133_), .Y(new_n134_));
  AND3x1_ASAP7_75t_R   g044(.A(p26), .B(p28), .C(p27), .Y(new_n135_));
  INVx1_ASAP7_75t_R    g045(.A(new_n135_), .Y(new_n136_));
  AO21x1_ASAP7_75t_R   g046(.A1(new_n110_), .A2(new_n134_), .B(new_n136_), .Y(new_n137_));
  INVx1_ASAP7_75t_R    g047(.A(new_n94_), .Y(new_n138_));
  NAND2x1_ASAP7_75t_R  g048(.A(new_n138_), .B(new_n109_), .Y(new_n139_));
  AND3x1_ASAP7_75t_R   g049(.A(new_n135_), .B(new_n116_), .C(new_n92_), .Y(new_n140_));
  AND2x2_ASAP7_75t_R   g050(.A(p4), .B(p3), .Y(new_n141_));
  AND3x1_ASAP7_75t_R   g051(.A(new_n141_), .B(p6), .C(p59), .Y(new_n142_));
  AND2x2_ASAP7_75t_R   g052(.A(p2), .B(p1), .Y(new_n143_));
  AND3x1_ASAP7_75t_R   g053(.A(new_n143_), .B(p0), .C(p5), .Y(new_n144_));
  NAND3x1_ASAP7_75t_R  g054(.A(new_n140_), .B(new_n142_), .C(new_n144_), .Y(new_n145_));
  AOI21x1_ASAP7_75t_R  g055(.A1(p22), .A2(new_n93_), .B(p23), .Y(new_n146_));
  NOR2x1_ASAP7_75t_R   g056(.A(p15), .B(p16), .Y(new_n147_));
  OR5x1_ASAP7_75t_R    g057(.A(p11), .B(new_n147_), .C(p8), .D(p9), .E(p12), .Y(new_n148_));
  NAND2x1_ASAP7_75t_R  g058(.A(p24), .B(new_n125_), .Y(new_n149_));
  NAND2x1_ASAP7_75t_R  g059(.A(p7), .B(p10), .Y(new_n150_));
  OR5x1_ASAP7_75t_R    g060(.A(p15), .B(new_n149_), .C(new_n112_), .D(new_n98_), .E(new_n150_), .Y(new_n151_));
  OR5x1_ASAP7_75t_R    g061(.A(new_n139_), .B(new_n145_), .C(new_n146_), .D(new_n148_), .E(new_n151_), .Y(new_n152_));
  OAI21x1_ASAP7_75t_R  g062(.A1(new_n136_), .A2(new_n104_), .B(new_n152_), .Y(new_n153_));
  OAI21x1_ASAP7_75t_R  g063(.A1(new_n104_), .A2(new_n137_), .B(new_n153_), .Y(o0));
  AND2x2_ASAP7_75t_R   g064(.A(p48), .B(p49), .Y(new_n155_));
  INVx1_ASAP7_75t_R    g065(.A(new_n155_), .Y(new_n156_));
  NOR2x1_ASAP7_75t_R   g066(.A(p42), .B(p41), .Y(new_n157_));
  OAI21x1_ASAP7_75t_R  g067(.A1(p39), .A2(p38), .B(p40), .Y(new_n158_));
  NAND2x1_ASAP7_75t_R  g068(.A(p44), .B(p43), .Y(new_n159_));
  AOI21x1_ASAP7_75t_R  g069(.A1(new_n157_), .A2(new_n158_), .B(new_n159_), .Y(new_n160_));
  AO21x1_ASAP7_75t_R   g070(.A1(p45), .A2(p46), .B(p47), .Y(new_n161_));
  AOI21x1_ASAP7_75t_R  g071(.A1(p46), .A2(new_n160_), .B(new_n161_), .Y(new_n162_));
  INVx1_ASAP7_75t_R    g072(.A(p51), .Y(new_n163_));
  INVx1_ASAP7_75t_R    g073(.A(p50), .Y(new_n164_));
  INVx1_ASAP7_75t_R    g074(.A(p55), .Y(new_n165_));
  AND3x1_ASAP7_75t_R   g075(.A(new_n163_), .B(new_n164_), .C(new_n165_), .Y(new_n166_));
  OAI21x1_ASAP7_75t_R  g076(.A1(new_n156_), .A2(new_n162_), .B(new_n166_), .Y(new_n167_));
  AND3x1_ASAP7_75t_R   g077(.A(p53), .B(p52), .C(p54), .Y(new_n168_));
  AND3x1_ASAP7_75t_R   g078(.A(p57), .B(p56), .C(p58), .Y(new_n169_));
  OA21x2_ASAP7_75t_R   g079(.A1(p55), .A2(new_n168_), .B(new_n169_), .Y(new_n170_));
  INVx1_ASAP7_75t_R    g080(.A(p59), .Y(new_n171_));
  AOI22x1_ASAP7_75t_R  g081(.A1(new_n167_), .A2(new_n170_), .B1(new_n164_), .B2(new_n171_), .Y(new_n172_));
  NAND2x1_ASAP7_75t_R  g082(.A(p52), .B(new_n163_), .Y(new_n173_));
  OAI21x1_ASAP7_75t_R  g083(.A1(new_n156_), .A2(new_n162_), .B(new_n173_), .Y(new_n174_));
  AND3x1_ASAP7_75t_R   g084(.A(p46), .B(p29), .C(p49), .Y(new_n175_));
  AND5x1_ASAP7_75t_R   g085(.A(p32), .B(new_n175_), .C(p30), .D(p31), .E(p35), .Y(new_n176_));
  AND2x2_ASAP7_75t_R   g086(.A(p44), .B(p34), .Y(new_n177_));
  AND2x2_ASAP7_75t_R   g087(.A(p36), .B(p40), .Y(new_n178_));
  AND2x2_ASAP7_75t_R   g088(.A(p37), .B(p33), .Y(new_n179_));
  NOR2x1_ASAP7_75t_R   g089(.A(p39), .B(p38), .Y(new_n180_));
  AND4x2_ASAP7_75t_R   g090(.A(new_n177_), .B(new_n178_), .C(new_n179_), .D(new_n180_), .Y(new_n181_));
  AND2x2_ASAP7_75t_R   g091(.A(p53), .B(p54), .Y(new_n182_));
  NOR2x1_ASAP7_75t_R   g092(.A(p45), .B(p55), .Y(new_n183_));
  AND3x1_ASAP7_75t_R   g093(.A(new_n169_), .B(new_n182_), .C(new_n183_), .Y(new_n184_));
  AND2x2_ASAP7_75t_R   g094(.A(p45), .B(p46), .Y(new_n185_));
  AO21x1_ASAP7_75t_R   g095(.A1(p47), .A2(new_n185_), .B(p48), .Y(new_n186_));
  NAND2x1_ASAP7_75t_R  g096(.A(p48), .B(new_n161_), .Y(new_n187_));
  AND5x1_ASAP7_75t_R   g097(.A(new_n176_), .B(new_n181_), .C(new_n184_), .D(new_n186_), .E(new_n187_), .Y(new_n188_));
  INVx1_ASAP7_75t_R    g098(.A(p41), .Y(new_n189_));
  NOR2x1_ASAP7_75t_R   g099(.A(new_n189_), .B(new_n158_), .Y(new_n190_));
  AOI21x1_ASAP7_75t_R  g100(.A1(p42), .A2(new_n190_), .B(p43), .Y(new_n191_));
  NAND2x1_ASAP7_75t_R  g101(.A(new_n189_), .B(new_n158_), .Y(new_n192_));
  OA21x2_ASAP7_75t_R   g102(.A1(p42), .A2(new_n192_), .B(p43), .Y(new_n193_));
  NOR2x1_ASAP7_75t_R   g103(.A(new_n191_), .B(new_n193_), .Y(new_n194_));
  NAND3x1_ASAP7_75t_R  g104(.A(new_n174_), .B(new_n188_), .C(new_n194_), .Y(new_n195_));
  INVx1_ASAP7_75t_R    g105(.A(p47), .Y(new_n196_));
  NOR3x1_ASAP7_75t_R   g106(.A(new_n160_), .B(new_n196_), .C(p45), .Y(new_n197_));
  AO21x1_ASAP7_75t_R   g107(.A1(p46), .A2(new_n160_), .B(new_n185_), .Y(new_n198_));
  NOR2x1_ASAP7_75t_R   g108(.A(p29), .B(p59), .Y(new_n199_));
  OAI21x1_ASAP7_75t_R  g109(.A1(new_n197_), .A2(new_n198_), .B(new_n199_), .Y(new_n200_));
  NOR2x1_ASAP7_75t_R   g110(.A(p39), .B(p36), .Y(new_n201_));
  AND3x1_ASAP7_75t_R   g111(.A(new_n201_), .B(new_n164_), .C(p40), .Y(new_n202_));
  AND3x1_ASAP7_75t_R   g112(.A(new_n183_), .B(p56), .C(p38), .Y(new_n203_));
  NOR3x1_ASAP7_75t_R   g113(.A(new_n159_), .B(p37), .C(p42), .Y(new_n204_));
  AND3x1_ASAP7_75t_R   g114(.A(new_n202_), .B(new_n203_), .C(new_n204_), .Y(new_n205_));
  NAND2x1_ASAP7_75t_R  g115(.A(p47), .B(p46), .Y(new_n206_));
  NOR2x1_ASAP7_75t_R   g116(.A(p33), .B(p34), .Y(new_n207_));
  AND5x1_ASAP7_75t_R   g117(.A(new_n192_), .B(new_n155_), .C(new_n182_), .D(new_n206_), .E(new_n207_), .Y(new_n208_));
  OR4x2_ASAP7_75t_R    g118(.A(p32), .B(p30), .C(p31), .D(p35), .Y(new_n209_));
  NOR3x1_ASAP7_75t_R   g119(.A(new_n190_), .B(new_n209_), .C(new_n173_), .Y(new_n210_));
  NAND3x1_ASAP7_75t_R  g120(.A(new_n205_), .B(new_n208_), .C(new_n210_), .Y(new_n211_));
  INVx1_ASAP7_75t_R    g121(.A(p46), .Y(new_n212_));
  AOI211x1_ASAP7_75t_R g122(.A1(new_n157_), .A2(new_n158_), .B(new_n212_), .C(new_n159_), .Y(new_n213_));
  OAI21x1_ASAP7_75t_R  g123(.A1(new_n161_), .A2(new_n213_), .B(new_n155_), .Y(new_n214_));
  INVx1_ASAP7_75t_R    g124(.A(new_n170_), .Y(new_n215_));
  AOI21x1_ASAP7_75t_R  g125(.A1(new_n166_), .A2(new_n214_), .B(new_n215_), .Y(new_n216_));
  OAI21x1_ASAP7_75t_R  g126(.A1(new_n200_), .A2(new_n211_), .B(new_n216_), .Y(new_n217_));
  OAI21x1_ASAP7_75t_R  g127(.A1(new_n172_), .A2(new_n195_), .B(new_n217_), .Y(new_n218_));
  AOI211x1_ASAP7_75t_R g128(.A1(new_n110_), .A2(new_n134_), .B(new_n136_), .C(new_n104_), .Y(new_n219_));
  AOI21x1_ASAP7_75t_R  g129(.A1(new_n153_), .A2(new_n218_), .B(new_n219_), .Y(o1));
  OR3x1_ASAP7_75t_R    g130(.A(new_n99_), .B(new_n93_), .C(new_n94_), .Y(new_n221_));
  AND3x1_ASAP7_75t_R   g131(.A(new_n221_), .B(new_n91_), .C(new_n102_), .Y(new_n222_));
  OAI21x1_ASAP7_75t_R  g132(.A1(p25), .A2(new_n222_), .B(new_n135_), .Y(new_n223_));
  AND2x2_ASAP7_75t_R   g133(.A(p29), .B(p59), .Y(new_n224_));
  INVx1_ASAP7_75t_R    g134(.A(new_n190_), .Y(new_n225_));
  AND5x1_ASAP7_75t_R   g135(.A(new_n163_), .B(new_n206_), .C(p48), .D(p52), .E(p49), .Y(new_n226_));
  NOR2x1_ASAP7_75t_R   g136(.A(p34), .B(p39), .Y(new_n227_));
  INVx1_ASAP7_75t_R    g137(.A(p33), .Y(new_n228_));
  AND3x1_ASAP7_75t_R   g138(.A(new_n227_), .B(new_n228_), .C(new_n164_), .Y(new_n229_));
  AND5x1_ASAP7_75t_R   g139(.A(new_n225_), .B(new_n192_), .C(new_n226_), .D(new_n204_), .E(new_n229_), .Y(new_n230_));
  NOR2x1_ASAP7_75t_R   g140(.A(p32), .B(p30), .Y(new_n231_));
  INVx1_ASAP7_75t_R    g141(.A(p36), .Y(new_n232_));
  AND3x1_ASAP7_75t_R   g142(.A(new_n231_), .B(new_n232_), .C(p40), .Y(new_n233_));
  INVx1_ASAP7_75t_R    g143(.A(p56), .Y(new_n234_));
  NOR2x1_ASAP7_75t_R   g144(.A(p31), .B(new_n234_), .Y(new_n235_));
  INVx1_ASAP7_75t_R    g145(.A(p38), .Y(new_n236_));
  NOR2x1_ASAP7_75t_R   g146(.A(p35), .B(new_n236_), .Y(new_n237_));
  AND5x1_ASAP7_75t_R   g147(.A(new_n182_), .B(new_n233_), .C(new_n183_), .D(new_n235_), .E(new_n237_), .Y(new_n238_));
  OAI21x1_ASAP7_75t_R  g148(.A1(p45), .A2(new_n160_), .B(new_n212_), .Y(new_n239_));
  NAND3x1_ASAP7_75t_R  g149(.A(new_n230_), .B(new_n238_), .C(new_n239_), .Y(new_n240_));
  OAI21x1_ASAP7_75t_R  g150(.A1(new_n224_), .A2(new_n240_), .B(new_n216_), .Y(new_n241_));
  AOI211x1_ASAP7_75t_R g151(.A1(new_n152_), .A2(new_n223_), .B(new_n219_), .C(new_n241_), .Y(o2));
  assign               o3 = 1'b0;
  assign               o4 = 1'b0;
  assign               o5 = 1'b0;
  assign               o6 = 1'b0;
  assign               o7 = 1'b0;
  assign               o8 = 1'b0;
  assign               o9 = 1'b0;
  assign               o10 = 1'b0;
  assign               o11 = 1'b0;
  assign               o12 = 1'b0;
  assign               o13 = 1'b0;
  assign               o14 = 1'b0;
  assign               o15 = 1'b0;
  assign               o16 = 1'b0;
  assign               o17 = 1'b0;
  assign               o18 = 1'b0;
  assign               o19 = 1'b0;
  assign               o20 = 1'b0;
  assign               o21 = 1'b0;
  assign               o22 = 1'b0;
  assign               o23 = 1'b0;
  assign               o24 = 1'b0;
  assign               o25 = 1'b0;
  assign               o26 = 1'b0;
  assign               o27 = 1'b0;
  assign               o28 = 1'b0;
  assign               o29 = 1'b0;
endmodule


