// Benchmark "/tmp/" written by ABC on Tue Oct 20 18:11:45 2026

module \/tmp/  ( 
    p43, p36, p37, p56, p2, p47, p33, p41, p16, p35, p52, p46, p17, p50,
    p1, p15, p7, p10, p42, p40, p6, p22, p13, p49, p54, p14, p55, p26, p34,
    p12, p39, p8, p23, p31, p57, p21, p32, p28, p11, p4, p3, p0, p38, p45,
    p53, p25, p44, p59, p58, p30, p9, p27, p24, p5, p19, p51, p20, p29,
    p18, p48,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25, o26, o27, o28, o29  );
  input  p43, p36, p37, p56, p2, p47, p33, p41, p16, p35, p52, p46, p17,
    p50, p1, p15, p7, p10, p42, p40, p6, p22, p13, p49, p54, p14, p55, p26,
    p34, p12, p39, p8, p23, p31, p57, p21, p32, p28, p11, p4, p3, p0, p38,
    p45, p53, p25, p44, p59, p58, p30, p9, p27, p24, p5, p19, p51, p20,
    p29, p18, p48;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25, o26, o27, o28, o29;
  wire new_n91_, new_n92_, new_n93_, new_n94_, new_n95_, new_n96_, new_n97_,
    new_n98_, new_n99_, new_n100_, new_n101_, new_n102_, new_n103_,
    new_n104_, new_n105_, new_n106_, new_n107_, new_n108_, new_n109_,
    new_n110_, new_n111_, new_n112_, new_n113_, new_n114_, new_n115_,
    new_n116_, new_n117_, new_n118_, new_n119_, new_n120_, new_n121_,
    new_n122_, new_n123_, new_n124_, new_n125_, new_n126_, new_n127_,
    new_n128_, new_n129_, new_n130_, new_n131_, new_n132_, new_n133_,
    new_n134_, new_n135_, new_n136_, new_n137_, new_n138_, new_n139_,
    new_n140_, new_n142_, new_n143_, new_n144_, new_n145_, new_n146_,
    new_n147_, new_n148_, new_n149_, new_n150_, new_n151_, new_n152_,
    new_n153_, new_n154_, new_n155_, new_n156_, new_n157_, new_n158_,
    new_n159_, new_n160_, new_n161_, new_n162_, new_n163_, new_n164_,
    new_n165_, new_n166_, new_n167_, new_n168_, new_n169_, new_n170_,
    new_n171_, new_n172_, new_n173_, new_n174_, new_n175_, new_n176_,
    new_n177_, new_n178_, new_n179_, new_n180_, new_n181_, new_n182_,
    new_n183_, new_n184_, new_n185_, new_n186_, new_n187_, new_n188_,
    new_n189_, new_n190_, new_n191_, new_n192_, new_n193_, new_n194_,
    new_n195_, new_n196_, new_n197_, new_n198_, new_n199_, new_n200_,
    new_n201_, new_n202_, new_n203_, new_n204_, new_n205_, new_n206_,
    new_n207_, new_n208_, new_n209_, new_n210_, new_n211_, new_n212_,
    new_n213_, new_n214_, new_n215_, new_n216_, new_n217_, new_n218_,
    new_n220_, new_n221_, new_n222_, new_n223_, new_n224_, new_n225_,
    new_n226_, new_n227_, new_n228_, new_n229_, new_n230_, new_n231_,
    new_n232_, new_n233_, new_n234_, new_n235_, new_n236_, new_n237_,
    new_n238_, new_n239_, new_n240_, new_n241_;
  AND3x1_ASAP7_75t_R   g000(.A(p26), .B(p28), .C(p27), .Y(new_n91_));
  NOR2x1_ASAP7_75t_R   g001(.A(p21), .B(p20), .Y(new_n92_));
  NOR2x1_ASAP7_75t_R   g002(.A(p12), .B(p11), .Y(new_n93_));
  OAI21x1_ASAP7_75t_R  g003(.A1(p8), .A2(p9), .B(p10), .Y(new_n94_));
  NAND2x1_ASAP7_75t_R  g004(.A(p13), .B(p14), .Y(new_n95_));
  AOI21x1_ASAP7_75t_R  g005(.A1(new_n93_), .A2(new_n94_), .B(new_n95_), .Y(new_n96_));
  AO21x1_ASAP7_75t_R   g006(.A1(p16), .A2(p15), .B(p17), .Y(new_n97_));
  AOI21x1_ASAP7_75t_R  g007(.A1(p16), .A2(new_n96_), .B(new_n97_), .Y(new_n98_));
  AND2x2_ASAP7_75t_R   g008(.A(p23), .B(p24), .Y(new_n99_));
  INVx1_ASAP7_75t_R    g009(.A(new_n99_), .Y(new_n100_));
  AND2x2_ASAP7_75t_R   g010(.A(p19), .B(p18), .Y(new_n101_));
  INVx1_ASAP7_75t_R    g011(.A(new_n92_), .Y(new_n102_));
  OAI21x1_ASAP7_75t_R  g012(.A1(new_n101_), .A2(new_n102_), .B(p22), .Y(new_n103_));
  AOI211x1_ASAP7_75t_R g013(.A1(new_n92_), .A2(new_n98_), .B(new_n100_), .C(new_n103_), .Y(new_n104_));
  AND2x2_ASAP7_75t_R   g014(.A(p25), .B(new_n91_), .Y(new_n105_));
  AO21x1_ASAP7_75t_R   g015(.A1(new_n91_), .A2(new_n104_), .B(new_n105_), .Y(new_n106_));
  INVx1_ASAP7_75t_R    g016(.A(p5), .Y(new_n107_));
  AND3x1_ASAP7_75t_R   g017(.A(new_n92_), .B(p22), .C(p19), .Y(new_n108_));
  INVx1_ASAP7_75t_R    g018(.A(p8), .Y(new_n109_));
  INVx1_ASAP7_75t_R    g019(.A(p9), .Y(new_n110_));
  INVx1_ASAP7_75t_R    g020(.A(p15), .Y(new_n111_));
  AO21x1_ASAP7_75t_R   g021(.A1(new_n109_), .A2(new_n110_), .B(new_n111_), .Y(new_n112_));
  NOR2x1_ASAP7_75t_R   g022(.A(p25), .B(p9), .Y(new_n113_));
  AND5x1_ASAP7_75t_R   g023(.A(new_n107_), .B(new_n108_), .C(p18), .D(new_n112_), .E(new_n113_), .Y(new_n114_));
  OA21x2_ASAP7_75t_R   g024(.A1(p15), .A2(new_n96_), .B(p16), .Y(new_n115_));
  NOR2x1_ASAP7_75t_R   g025(.A(p2), .B(p17), .Y(new_n116_));
  AND5x1_ASAP7_75t_R   g026(.A(p13), .B(new_n99_), .C(p14), .D(new_n93_), .E(new_n116_), .Y(new_n117_));
  NOR2x1_ASAP7_75t_R   g027(.A(p4), .B(new_n109_), .Y(new_n118_));
  INVx1_ASAP7_75t_R    g028(.A(p6), .Y(new_n119_));
  NOR2x1_ASAP7_75t_R   g029(.A(p3), .B(p0), .Y(new_n120_));
  NOR2x1_ASAP7_75t_R   g030(.A(p1), .B(p7), .Y(new_n121_));
  AND5x1_ASAP7_75t_R   g031(.A(p10), .B(new_n118_), .C(new_n119_), .D(new_n120_), .E(new_n121_), .Y(new_n122_));
  AND4x2_ASAP7_75t_R   g032(.A(new_n114_), .B(new_n115_), .C(new_n117_), .D(new_n122_), .Y(new_n123_));
  INVx1_ASAP7_75t_R    g033(.A(new_n123_), .Y(new_n124_));
  AO21x1_ASAP7_75t_R   g034(.A1(p22), .A2(new_n102_), .B(p23), .Y(new_n125_));
  AND2x2_ASAP7_75t_R   g035(.A(p59), .B(p24), .Y(new_n126_));
  AND2x2_ASAP7_75t_R   g036(.A(p5), .B(p18), .Y(new_n127_));
  AND3x1_ASAP7_75t_R   g037(.A(new_n91_), .B(new_n126_), .C(new_n127_), .Y(new_n128_));
  AND3x1_ASAP7_75t_R   g038(.A(new_n93_), .B(new_n109_), .C(new_n110_), .Y(new_n129_));
  NAND3x1_ASAP7_75t_R  g039(.A(new_n128_), .B(new_n129_), .C(new_n108_), .Y(new_n130_));
  AND2x2_ASAP7_75t_R   g040(.A(p4), .B(p3), .Y(new_n131_));
  INVx1_ASAP7_75t_R    g041(.A(p25), .Y(new_n132_));
  AND3x1_ASAP7_75t_R   g042(.A(new_n131_), .B(p0), .C(new_n132_), .Y(new_n133_));
  AND5x1_ASAP7_75t_R   g043(.A(p2), .B(new_n111_), .C(p16), .D(p1), .E(p7), .Y(new_n134_));
  NAND2x1_ASAP7_75t_R  g044(.A(p10), .B(p6), .Y(new_n135_));
  NOR2x1_ASAP7_75t_R   g045(.A(new_n95_), .B(new_n135_), .Y(new_n136_));
  NAND3x1_ASAP7_75t_R  g046(.A(new_n133_), .B(new_n134_), .C(new_n136_), .Y(new_n137_));
  AO21x1_ASAP7_75t_R   g047(.A1(p16), .A2(new_n96_), .B(new_n97_), .Y(new_n138_));
  NOR3x1_ASAP7_75t_R   g048(.A(new_n130_), .B(new_n137_), .C(new_n138_), .Y(new_n139_));
  AOI221x1_ASAP7_75t_R g049(.A1(new_n104_), .A2(new_n91_), .B1(new_n125_), .B2(new_n139_), .C(new_n105_), .Y(new_n140_));
  AO21x1_ASAP7_75t_R   g050(.A1(new_n106_), .A2(new_n124_), .B(new_n140_), .Y(o0));
  INVx1_ASAP7_75t_R    g051(.A(new_n105_), .Y(new_n142_));
  AOI21x1_ASAP7_75t_R  g052(.A1(new_n92_), .A2(new_n98_), .B(new_n103_), .Y(new_n143_));
  NAND3x1_ASAP7_75t_R  g053(.A(new_n143_), .B(new_n91_), .C(new_n99_), .Y(new_n144_));
  AOI21x1_ASAP7_75t_R  g054(.A1(new_n142_), .A2(new_n144_), .B(new_n123_), .Y(new_n145_));
  NAND2x1_ASAP7_75t_R  g055(.A(p49), .B(p48), .Y(new_n146_));
  NOR2x1_ASAP7_75t_R   g056(.A(p41), .B(p42), .Y(new_n147_));
  OAI21x1_ASAP7_75t_R  g057(.A1(p39), .A2(p38), .B(p40), .Y(new_n148_));
  NAND2x1_ASAP7_75t_R  g058(.A(p43), .B(p44), .Y(new_n149_));
  AOI21x1_ASAP7_75t_R  g059(.A1(new_n147_), .A2(new_n148_), .B(new_n149_), .Y(new_n150_));
  AO21x1_ASAP7_75t_R   g060(.A1(p46), .A2(p45), .B(p47), .Y(new_n151_));
  AOI21x1_ASAP7_75t_R  g061(.A1(p46), .A2(new_n150_), .B(new_n151_), .Y(new_n152_));
  INVx1_ASAP7_75t_R    g062(.A(p51), .Y(new_n153_));
  NAND2x1_ASAP7_75t_R  g063(.A(p52), .B(new_n153_), .Y(new_n154_));
  OAI21x1_ASAP7_75t_R  g064(.A1(new_n146_), .A2(new_n152_), .B(new_n154_), .Y(new_n155_));
  AND3x1_ASAP7_75t_R   g065(.A(p56), .B(p57), .C(p58), .Y(new_n156_));
  AND2x2_ASAP7_75t_R   g066(.A(p54), .B(p53), .Y(new_n157_));
  INVx1_ASAP7_75t_R    g067(.A(p39), .Y(new_n158_));
  INVx1_ASAP7_75t_R    g068(.A(p38), .Y(new_n159_));
  AND3x1_ASAP7_75t_R   g069(.A(new_n157_), .B(new_n158_), .C(new_n159_), .Y(new_n160_));
  AND2x2_ASAP7_75t_R   g070(.A(p31), .B(p32), .Y(new_n161_));
  AND3x1_ASAP7_75t_R   g071(.A(new_n161_), .B(p44), .C(p29), .Y(new_n162_));
  OA211x2_ASAP7_75t_R  g072(.A1(p47), .A2(p48), .B(p37), .C(p33), .Y(new_n163_));
  INVx1_ASAP7_75t_R    g073(.A(p45), .Y(new_n164_));
  AND3x1_ASAP7_75t_R   g074(.A(new_n164_), .B(p34), .C(p30), .Y(new_n165_));
  AND5x1_ASAP7_75t_R   g075(.A(new_n156_), .B(new_n160_), .C(new_n162_), .D(new_n163_), .E(new_n165_), .Y(new_n166_));
  AND2x2_ASAP7_75t_R   g076(.A(p46), .B(p40), .Y(new_n167_));
  INVx1_ASAP7_75t_R    g077(.A(p55), .Y(new_n168_));
  AND3x1_ASAP7_75t_R   g078(.A(new_n167_), .B(p49), .C(new_n168_), .Y(new_n169_));
  NAND2x1_ASAP7_75t_R  g079(.A(p46), .B(p45), .Y(new_n170_));
  OAI21x1_ASAP7_75t_R  g080(.A1(p48), .A2(new_n170_), .B(new_n151_), .Y(new_n171_));
  INVx1_ASAP7_75t_R    g081(.A(p43), .Y(new_n172_));
  AO21x1_ASAP7_75t_R   g082(.A1(new_n147_), .A2(new_n148_), .B(new_n172_), .Y(new_n173_));
  NAND2x1_ASAP7_75t_R  g083(.A(p41), .B(p42), .Y(new_n174_));
  OAI21x1_ASAP7_75t_R  g084(.A1(new_n174_), .A2(new_n148_), .B(new_n172_), .Y(new_n175_));
  AND2x2_ASAP7_75t_R   g085(.A(p36), .B(p35), .Y(new_n176_));
  AND5x1_ASAP7_75t_R   g086(.A(new_n169_), .B(new_n171_), .C(new_n173_), .D(new_n175_), .E(new_n176_), .Y(new_n177_));
  NAND3x1_ASAP7_75t_R  g087(.A(new_n155_), .B(new_n166_), .C(new_n177_), .Y(new_n178_));
  AND3x1_ASAP7_75t_R   g088(.A(p52), .B(p54), .C(p53), .Y(new_n179_));
  OA21x2_ASAP7_75t_R   g089(.A1(p55), .A2(new_n179_), .B(new_n156_), .Y(new_n180_));
  NOR2x1_ASAP7_75t_R   g090(.A(p50), .B(p51), .Y(new_n181_));
  AND2x2_ASAP7_75t_R   g091(.A(new_n168_), .B(new_n181_), .Y(new_n182_));
  OAI21x1_ASAP7_75t_R  g092(.A1(new_n146_), .A2(new_n152_), .B(new_n182_), .Y(new_n183_));
  NOR2x1_ASAP7_75t_R   g093(.A(p50), .B(p59), .Y(new_n184_));
  AOI21x1_ASAP7_75t_R  g094(.A1(new_n180_), .A2(new_n183_), .B(new_n184_), .Y(new_n185_));
  NOR2x1_ASAP7_75t_R   g095(.A(p36), .B(p37), .Y(new_n186_));
  AND3x1_ASAP7_75t_R   g096(.A(new_n186_), .B(p43), .C(p44), .Y(new_n187_));
  NOR2x1_ASAP7_75t_R   g097(.A(p39), .B(p45), .Y(new_n188_));
  AND3x1_ASAP7_75t_R   g098(.A(new_n188_), .B(new_n168_), .C(p38), .Y(new_n189_));
  NAND2x1_ASAP7_75t_R  g099(.A(p56), .B(p40), .Y(new_n190_));
  NOR3x1_ASAP7_75t_R   g100(.A(new_n190_), .B(p50), .C(p42), .Y(new_n191_));
  AND3x1_ASAP7_75t_R   g101(.A(new_n187_), .B(new_n189_), .C(new_n191_), .Y(new_n192_));
  INVx1_ASAP7_75t_R    g102(.A(p41), .Y(new_n193_));
  NAND2x1_ASAP7_75t_R  g103(.A(p47), .B(p46), .Y(new_n194_));
  AND2x2_ASAP7_75t_R   g104(.A(p49), .B(p48), .Y(new_n195_));
  NAND2x1_ASAP7_75t_R  g105(.A(new_n194_), .B(new_n195_), .Y(new_n196_));
  NOR2x1_ASAP7_75t_R   g106(.A(p33), .B(p35), .Y(new_n197_));
  NAND2x1_ASAP7_75t_R  g107(.A(new_n197_), .B(new_n157_), .Y(new_n198_));
  AOI211x1_ASAP7_75t_R g108(.A1(new_n193_), .A2(new_n148_), .B(new_n196_), .C(new_n198_), .Y(new_n199_));
  NOR2x1_ASAP7_75t_R   g109(.A(new_n193_), .B(new_n148_), .Y(new_n200_));
  OR4x2_ASAP7_75t_R    g110(.A(p34), .B(p31), .C(p32), .D(p30), .Y(new_n201_));
  NOR3x1_ASAP7_75t_R   g111(.A(new_n200_), .B(new_n154_), .C(new_n201_), .Y(new_n202_));
  NAND3x1_ASAP7_75t_R  g112(.A(new_n192_), .B(new_n199_), .C(new_n202_), .Y(new_n203_));
  NAND2x1_ASAP7_75t_R  g113(.A(p47), .B(new_n164_), .Y(new_n204_));
  NOR2x1_ASAP7_75t_R   g114(.A(new_n204_), .B(new_n150_), .Y(new_n205_));
  INVx1_ASAP7_75t_R    g115(.A(new_n170_), .Y(new_n206_));
  AO21x1_ASAP7_75t_R   g116(.A1(p46), .A2(new_n150_), .B(new_n206_), .Y(new_n207_));
  NOR2x1_ASAP7_75t_R   g117(.A(p59), .B(p29), .Y(new_n208_));
  OAI21x1_ASAP7_75t_R  g118(.A1(new_n205_), .A2(new_n207_), .B(new_n208_), .Y(new_n209_));
  INVx1_ASAP7_75t_R    g119(.A(p46), .Y(new_n210_));
  AOI211x1_ASAP7_75t_R g120(.A1(new_n147_), .A2(new_n148_), .B(new_n210_), .C(new_n149_), .Y(new_n211_));
  OAI21x1_ASAP7_75t_R  g121(.A1(new_n151_), .A2(new_n211_), .B(new_n195_), .Y(new_n212_));
  INVx1_ASAP7_75t_R    g122(.A(new_n180_), .Y(new_n213_));
  AOI21x1_ASAP7_75t_R  g123(.A1(new_n182_), .A2(new_n212_), .B(new_n213_), .Y(new_n214_));
  OAI21x1_ASAP7_75t_R  g124(.A1(new_n203_), .A2(new_n209_), .B(new_n214_), .Y(new_n215_));
  OAI21x1_ASAP7_75t_R  g125(.A1(new_n178_), .A2(new_n185_), .B(new_n215_), .Y(new_n216_));
  NAND2x1_ASAP7_75t_R  g126(.A(new_n125_), .B(new_n139_), .Y(new_n217_));
  NAND3x1_ASAP7_75t_R  g127(.A(new_n217_), .B(new_n144_), .C(new_n142_), .Y(new_n218_));
  OAI21x1_ASAP7_75t_R  g128(.A1(new_n145_), .A2(new_n216_), .B(new_n218_), .Y(o1));
  INVx1_ASAP7_75t_R    g129(.A(new_n200_), .Y(new_n220_));
  NAND2x1_ASAP7_75t_R  g130(.A(new_n193_), .B(new_n148_), .Y(new_n221_));
  NOR2x1_ASAP7_75t_R   g131(.A(p31), .B(p30), .Y(new_n222_));
  NOR2x1_ASAP7_75t_R   g132(.A(p35), .B(p34), .Y(new_n223_));
  NOR2x1_ASAP7_75t_R   g133(.A(p33), .B(p32), .Y(new_n224_));
  AND5x1_ASAP7_75t_R   g134(.A(p54), .B(new_n222_), .C(new_n223_), .D(new_n224_), .E(p53), .Y(new_n225_));
  NOR2x1_ASAP7_75t_R   g135(.A(new_n146_), .B(new_n154_), .Y(new_n226_));
  AND5x1_ASAP7_75t_R   g136(.A(new_n220_), .B(new_n221_), .C(new_n225_), .D(new_n194_), .E(new_n226_), .Y(new_n227_));
  INVx1_ASAP7_75t_R    g137(.A(p40), .Y(new_n228_));
  OR3x1_ASAP7_75t_R    g138(.A(new_n149_), .B(p42), .C(new_n228_), .Y(new_n229_));
  NOR2x1_ASAP7_75t_R   g139(.A(p50), .B(p45), .Y(new_n230_));
  AND3x1_ASAP7_75t_R   g140(.A(new_n230_), .B(p56), .C(new_n168_), .Y(new_n231_));
  AND3x1_ASAP7_75t_R   g141(.A(new_n186_), .B(new_n158_), .C(p38), .Y(new_n232_));
  NAND2x1_ASAP7_75t_R  g142(.A(new_n231_), .B(new_n232_), .Y(new_n233_));
  AOI211x1_ASAP7_75t_R g143(.A1(p59), .A2(p29), .B(new_n229_), .C(new_n233_), .Y(new_n234_));
  NOR2x1_ASAP7_75t_R   g144(.A(p45), .B(new_n150_), .Y(new_n235_));
  OAI22x1_ASAP7_75t_R  g145(.A1(new_n235_), .A2(new_n210_), .B1(new_n150_), .B2(new_n204_), .Y(new_n236_));
  NAND3x1_ASAP7_75t_R  g146(.A(new_n227_), .B(new_n234_), .C(new_n236_), .Y(new_n237_));
  INVx1_ASAP7_75t_R    g147(.A(new_n179_), .Y(new_n238_));
  OA21x2_ASAP7_75t_R   g148(.A1(new_n181_), .A2(new_n238_), .B(new_n168_), .Y(new_n239_));
  OAI21x1_ASAP7_75t_R  g149(.A1(new_n238_), .A2(new_n212_), .B(new_n239_), .Y(new_n240_));
  NAND3x1_ASAP7_75t_R  g150(.A(new_n237_), .B(new_n156_), .C(new_n240_), .Y(new_n241_));
  AOI211x1_ASAP7_75t_R g151(.A1(new_n124_), .A2(new_n106_), .B(new_n140_), .C(new_n241_), .Y(o2));
  assign               o3 = 1'b0;
  assign               o4 = 1'b0;
  assign               o5 = 1'b0;
  assign               o6 = 1'b0;
  assign               o7 = 1'b0;
  assign               o8 = 1'b0;
  assign               o9 = 1'b0;
  assign               o10 = 1'b0;
  assign               o11 = 1'b0;
  assign               o12 = 1'b0;
  assign               o13 = 1'b0;
  assign               o14 = 1'b0;
  assign               o15 = 1'b0;
  assign               o16 = 1'b0;
  assign               o17 = 1'b0;
  assign               o18 = 1'b0;
  assign               o19 = 1'b0;
  assign               o20 = 1'b0;
  assign               o21 = 1'b0;
  assign               o22 = 1'b0;
  assign               o23 = 1'b0;
  assign               o24 = 1'b0;
  assign               o25 = 1'b0;
  assign               o26 = 1'b0;
  assign               o27 = 1'b0;
  assign               o28 = 1'b0;
  assign               o29 = 1'b0;
endmodule


