// Benchmark "/tmp/" written by ABC on Tue Oct 20 18:11:45 2026

module \/tmp/  ( 
    p3, p4, p1, p31, p25, p42, p58, p14, p2, p8, p44, p13, p39, p37, p53,
    p48, p41, p23, p54, p38, p50, p27, p55, p46, p16, p19, p36, p15, p45,
    p12, p0, p59, p18, p34, p10, p5, p33, p11, p57, p52, p43, p6, p30, p51,
    p20, p29, p24, p26, p21, p17, p56, p22, p47, p40, p7, p9, p28, p49,
    p32, p35,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25, o26, o27, o28, o29  );
  input  p3, p4, p1, p31, p25, p42, p58, p14, p2, p8, p44, p13, p39, p37,
    p53, p48, p41, p23, p54, p38, p50, p27, p55, p46, p16, p19, p36, p15,
    p45, p12, p0, p59, p18, p34, p10, p5, p33, p11, p57, p52, p43, p6, p30,
    p51, p20, p29, p24, p26, p21, p17, p56, p22, p47, p40, p7, p9, p28,
    p49, p32, p35;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25, o26, o27, o28, o29;
  wire new_n91_, new_n92_, new_n93_, new_n94_, new_n95_, new_n96_, new_n97_,
    new_n98_, new_n99_, new_n100_, new_n101_, new_n102_, new_n103_,
    new_n104_, new_n105_, new_n106_, new_n107_, new_n108_, new_n109_,
    new_n110_, new_n111_, new_n112_, new_n113_, new_n114_, new_n115_,
    new_n116_, new_n117_, new_n118_, new_n119_, new_n120_, new_n121_,
    new_n122_, new_n123_, new_n124_, new_n125_, new_n126_, new_n127_,
    new_n128_, new_n129_, new_n130_, new_n131_, new_n132_, new_n133_,
    new_n134_, new_n135_, new_n136_, new_n137_, new_n138_, new_n139_,
    new_n140_, new_n141_, new_n142_, new_n143_, new_n144_, new_n145_,
    new_n147_, new_n148_, new_n149_, new_n150_, new_n151_, new_n152_,
    new_n153_, new_n154_, new_n155_, new_n156_, new_n157_, new_n158_,
    new_n159_, new_n160_, new_n161_, new_n162_, new_n163_, new_n164_,
    new_n165_, new_n166_, new_n167_, new_n168_, new_n169_, new_n170_,
    new_n171_, new_n172_, new_n173_, new_n174_, new_n175_, new_n176_,
    new_n177_, new_n178_, new_n179_, new_n180_, new_n181_, new_n182_,
    new_n183_, new_n184_, new_n185_, new_n186_, new_n187_, new_n188_,
    new_n189_, new_n190_, new_n191_, new_n192_, new_n193_, new_n194_,
    new_n195_, new_n196_, new_n197_, new_n198_, new_n199_, new_n200_,
    new_n201_, new_n202_, new_n203_, new_n204_, new_n205_, new_n206_,
    new_n207_, new_n208_, new_n209_, new_n210_, new_n211_, new_n212_,
    new_n213_, new_n214_, new_n215_, new_n216_, new_n217_, new_n218_,
    new_n220_, new_n221_, new_n222_, new_n223_, new_n224_, new_n225_,
    new_n226_, new_n227_, new_n228_, new_n229_, new_n230_, new_n231_,
    new_n232_, new_n233_, new_n234_, new_n235_, new_n236_, new_n237_,
    new_n238_, new_n239_, new_n240_, new_n241_, new_n242_, new_n243_,
    new_n244_, new_n245_, new_n246_;
  AND3x1_ASAP7_75t_R   g000(.A(p27), .B(p26), .C(p28), .Y(new_n91_));
  INVx1_ASAP7_75t_R    g001(.A(new_n91_), .Y(new_n92_));
  AND2x2_ASAP7_75t_R   g002(.A(p23), .B(p24), .Y(new_n93_));
  INVx1_ASAP7_75t_R    g003(.A(new_n93_), .Y(new_n94_));
  NOR2x1_ASAP7_75t_R   g004(.A(p20), .B(p21), .Y(new_n95_));
  INVx1_ASAP7_75t_R    g005(.A(new_n95_), .Y(new_n96_));
  NOR2x1_ASAP7_75t_R   g006(.A(p12), .B(p11), .Y(new_n97_));
  OAI21x1_ASAP7_75t_R  g007(.A1(p8), .A2(p9), .B(p10), .Y(new_n98_));
  NAND2x1_ASAP7_75t_R  g008(.A(p14), .B(p13), .Y(new_n99_));
  AOI21x1_ASAP7_75t_R  g009(.A1(new_n97_), .A2(new_n98_), .B(new_n99_), .Y(new_n100_));
  AO21x1_ASAP7_75t_R   g010(.A1(p16), .A2(p15), .B(p17), .Y(new_n101_));
  AO21x1_ASAP7_75t_R   g011(.A1(p16), .A2(new_n100_), .B(new_n101_), .Y(new_n102_));
  NAND2x1_ASAP7_75t_R  g012(.A(p19), .B(p18), .Y(new_n103_));
  INVx1_ASAP7_75t_R    g013(.A(p22), .Y(new_n104_));
  AOI21x1_ASAP7_75t_R  g014(.A1(new_n103_), .A2(new_n95_), .B(new_n104_), .Y(new_n105_));
  OAI21x1_ASAP7_75t_R  g015(.A1(new_n96_), .A2(new_n102_), .B(new_n105_), .Y(new_n106_));
  NAND2x1_ASAP7_75t_R  g016(.A(p25), .B(new_n91_), .Y(new_n107_));
  OA31x2_ASAP7_75t_R   g017(.A1(new_n92_), .A2(new_n94_), .A3(new_n106_), .B1(new_n107_), .Y(new_n108_));
  INVx1_ASAP7_75t_R    g018(.A(p16), .Y(new_n109_));
  AOI211x1_ASAP7_75t_R g019(.A1(new_n97_), .A2(new_n98_), .B(new_n109_), .C(new_n99_), .Y(new_n110_));
  AO21x1_ASAP7_75t_R   g020(.A1(p16), .A2(p15), .B(new_n110_), .Y(new_n111_));
  OR4x2_ASAP7_75t_R    g021(.A(p3), .B(p4), .C(p1), .D(p25), .Y(new_n112_));
  INVx1_ASAP7_75t_R    g022(.A(p8), .Y(new_n113_));
  OR4x2_ASAP7_75t_R    g023(.A(new_n113_), .B(p2), .C(p0), .D(p5), .Y(new_n114_));
  NOR2x1_ASAP7_75t_R   g024(.A(new_n112_), .B(new_n114_), .Y(new_n115_));
  NAND2x1_ASAP7_75t_R  g025(.A(p15), .B(new_n100_), .Y(new_n116_));
  INVx1_ASAP7_75t_R    g026(.A(new_n99_), .Y(new_n117_));
  AND5x1_ASAP7_75t_R   g027(.A(p18), .B(new_n117_), .C(p10), .D(new_n93_), .E(new_n97_), .Y(new_n118_));
  AND3x1_ASAP7_75t_R   g028(.A(new_n95_), .B(p19), .C(p22), .Y(new_n119_));
  NOR2x1_ASAP7_75t_R   g029(.A(p7), .B(p9), .Y(new_n120_));
  NOR2x1_ASAP7_75t_R   g030(.A(p6), .B(p17), .Y(new_n121_));
  AND3x1_ASAP7_75t_R   g031(.A(new_n119_), .B(new_n120_), .C(new_n121_), .Y(new_n122_));
  AND5x1_ASAP7_75t_R   g032(.A(new_n111_), .B(new_n115_), .C(new_n116_), .D(new_n118_), .E(new_n122_), .Y(new_n123_));
  OA31x2_ASAP7_75t_R   g033(.A1(new_n96_), .A2(new_n101_), .A3(new_n110_), .B1(new_n105_), .Y(new_n124_));
  AOI21x1_ASAP7_75t_R  g034(.A1(new_n93_), .A2(new_n124_), .B(p25), .Y(new_n125_));
  AO21x1_ASAP7_75t_R   g035(.A1(p22), .A2(new_n96_), .B(p23), .Y(new_n126_));
  INVx1_ASAP7_75t_R    g036(.A(new_n126_), .Y(new_n127_));
  NOR2x1_ASAP7_75t_R   g037(.A(p16), .B(p15), .Y(new_n128_));
  AO21x1_ASAP7_75t_R   g038(.A1(new_n97_), .A2(new_n98_), .B(new_n99_), .Y(new_n129_));
  INVx1_ASAP7_75t_R    g039(.A(p15), .Y(new_n130_));
  NAND3x1_ASAP7_75t_R  g040(.A(new_n91_), .B(p14), .C(new_n130_), .Y(new_n131_));
  INVx1_ASAP7_75t_R    g041(.A(p18), .Y(new_n132_));
  INVx1_ASAP7_75t_R    g042(.A(p24), .Y(new_n133_));
  OR5x1_ASAP7_75t_R    g043(.A(p25), .B(new_n132_), .C(new_n133_), .D(p12), .E(p11), .Y(new_n134_));
  AOI211x1_ASAP7_75t_R g044(.A1(new_n128_), .A2(new_n129_), .B(new_n131_), .C(new_n134_), .Y(new_n135_));
  NOR2x1_ASAP7_75t_R   g045(.A(p8), .B(p9), .Y(new_n136_));
  AND3x1_ASAP7_75t_R   g046(.A(new_n136_), .B(p3), .C(p4), .Y(new_n137_));
  AND3x1_ASAP7_75t_R   g047(.A(p10), .B(p5), .C(p6), .Y(new_n138_));
  AND4x2_ASAP7_75t_R   g048(.A(p1), .B(p2), .C(p0), .D(p59), .Y(new_n139_));
  AND5x1_ASAP7_75t_R   g049(.A(p7), .B(new_n119_), .C(new_n137_), .D(new_n138_), .E(new_n139_), .Y(new_n140_));
  NAND3x1_ASAP7_75t_R  g050(.A(new_n98_), .B(new_n97_), .C(p13), .Y(new_n141_));
  AO21x1_ASAP7_75t_R   g051(.A1(new_n97_), .A2(new_n98_), .B(p13), .Y(new_n142_));
  AOI211x1_ASAP7_75t_R g052(.A1(new_n141_), .A2(new_n142_), .B(new_n110_), .C(new_n101_), .Y(new_n143_));
  NAND3x1_ASAP7_75t_R  g053(.A(new_n135_), .B(new_n140_), .C(new_n143_), .Y(new_n144_));
  OAI22x1_ASAP7_75t_R  g054(.A1(new_n125_), .A2(new_n92_), .B1(new_n127_), .B2(new_n144_), .Y(new_n145_));
  OAI21x1_ASAP7_75t_R  g055(.A1(new_n108_), .A2(new_n123_), .B(new_n145_), .Y(o0));
  NAND2x1_ASAP7_75t_R  g056(.A(p48), .B(p49), .Y(new_n147_));
  NOR2x1_ASAP7_75t_R   g057(.A(p42), .B(p41), .Y(new_n148_));
  OAI21x1_ASAP7_75t_R  g058(.A1(p39), .A2(p38), .B(p40), .Y(new_n149_));
  NAND2x1_ASAP7_75t_R  g059(.A(p44), .B(p43), .Y(new_n150_));
  AOI21x1_ASAP7_75t_R  g060(.A1(new_n148_), .A2(new_n149_), .B(new_n150_), .Y(new_n151_));
  AO21x1_ASAP7_75t_R   g061(.A1(p46), .A2(p45), .B(p47), .Y(new_n152_));
  AOI21x1_ASAP7_75t_R  g062(.A1(p46), .A2(new_n151_), .B(new_n152_), .Y(new_n153_));
  INVx1_ASAP7_75t_R    g063(.A(p51), .Y(new_n154_));
  NAND2x1_ASAP7_75t_R  g064(.A(p52), .B(new_n154_), .Y(new_n155_));
  OAI21x1_ASAP7_75t_R  g065(.A1(new_n147_), .A2(new_n153_), .B(new_n155_), .Y(new_n156_));
  AND2x2_ASAP7_75t_R   g066(.A(p36), .B(p34), .Y(new_n157_));
  INVx1_ASAP7_75t_R    g067(.A(p55), .Y(new_n158_));
  INVx1_ASAP7_75t_R    g068(.A(p45), .Y(new_n159_));
  AND5x1_ASAP7_75t_R   g069(.A(p31), .B(new_n157_), .C(new_n158_), .D(p46), .E(new_n159_), .Y(new_n160_));
  INVx1_ASAP7_75t_R    g070(.A(p48), .Y(new_n161_));
  NAND3x1_ASAP7_75t_R  g071(.A(new_n161_), .B(p46), .C(p45), .Y(new_n162_));
  NAND2x1_ASAP7_75t_R  g072(.A(p44), .B(p37), .Y(new_n163_));
  AOI21x1_ASAP7_75t_R  g073(.A1(new_n152_), .A2(new_n162_), .B(new_n163_), .Y(new_n164_));
  INVx1_ASAP7_75t_R    g074(.A(p47), .Y(new_n165_));
  NAND2x1_ASAP7_75t_R  g075(.A(p53), .B(p54), .Y(new_n166_));
  INVx1_ASAP7_75t_R    g076(.A(p39), .Y(new_n167_));
  INVx1_ASAP7_75t_R    g077(.A(p38), .Y(new_n168_));
  NAND2x1_ASAP7_75t_R  g078(.A(new_n167_), .B(new_n168_), .Y(new_n169_));
  AOI211x1_ASAP7_75t_R g079(.A1(new_n161_), .A2(new_n165_), .B(new_n166_), .C(new_n169_), .Y(new_n170_));
  INVx1_ASAP7_75t_R    g080(.A(p43), .Y(new_n171_));
  AO21x1_ASAP7_75t_R   g081(.A1(new_n148_), .A2(new_n149_), .B(new_n171_), .Y(new_n172_));
  AND4x2_ASAP7_75t_R   g082(.A(new_n160_), .B(new_n164_), .C(new_n170_), .D(new_n172_), .Y(new_n173_));
  AND3x1_ASAP7_75t_R   g083(.A(p58), .B(p57), .C(p56), .Y(new_n174_));
  AND5x1_ASAP7_75t_R   g084(.A(p30), .B(new_n174_), .C(p29), .D(p49), .E(p35), .Y(new_n175_));
  NAND2x1_ASAP7_75t_R  g085(.A(p42), .B(p41), .Y(new_n176_));
  OAI21x1_ASAP7_75t_R  g086(.A1(new_n176_), .A2(new_n149_), .B(new_n171_), .Y(new_n177_));
  AND3x1_ASAP7_75t_R   g087(.A(p33), .B(p40), .C(p32), .Y(new_n178_));
  AND3x1_ASAP7_75t_R   g088(.A(new_n175_), .B(new_n177_), .C(new_n178_), .Y(new_n179_));
  NAND3x1_ASAP7_75t_R  g089(.A(new_n156_), .B(new_n173_), .C(new_n179_), .Y(new_n180_));
  AND3x1_ASAP7_75t_R   g090(.A(p53), .B(p54), .C(p52), .Y(new_n181_));
  OA21x2_ASAP7_75t_R   g091(.A1(p55), .A2(new_n181_), .B(new_n174_), .Y(new_n182_));
  NOR2x1_ASAP7_75t_R   g092(.A(p50), .B(p55), .Y(new_n183_));
  AND2x2_ASAP7_75t_R   g093(.A(new_n154_), .B(new_n183_), .Y(new_n184_));
  OAI21x1_ASAP7_75t_R  g094(.A1(new_n147_), .A2(new_n153_), .B(new_n184_), .Y(new_n185_));
  NOR2x1_ASAP7_75t_R   g095(.A(p50), .B(p59), .Y(new_n186_));
  AOI21x1_ASAP7_75t_R  g096(.A1(new_n182_), .A2(new_n185_), .B(new_n186_), .Y(new_n187_));
  INVx1_ASAP7_75t_R    g097(.A(p37), .Y(new_n188_));
  AND3x1_ASAP7_75t_R   g098(.A(new_n183_), .B(new_n188_), .C(p38), .Y(new_n189_));
  INVx1_ASAP7_75t_R    g099(.A(p36), .Y(new_n190_));
  AND4x2_ASAP7_75t_R   g100(.A(new_n190_), .B(new_n159_), .C(p56), .D(p40), .Y(new_n191_));
  NOR3x1_ASAP7_75t_R   g101(.A(new_n150_), .B(p42), .C(p39), .Y(new_n192_));
  AND3x1_ASAP7_75t_R   g102(.A(new_n189_), .B(new_n191_), .C(new_n192_), .Y(new_n193_));
  INVx1_ASAP7_75t_R    g103(.A(p41), .Y(new_n194_));
  NOR2x1_ASAP7_75t_R   g104(.A(p31), .B(p34), .Y(new_n195_));
  NAND3x1_ASAP7_75t_R  g105(.A(new_n195_), .B(p53), .C(p54), .Y(new_n196_));
  NAND2x1_ASAP7_75t_R  g106(.A(p46), .B(p47), .Y(new_n197_));
  AND2x2_ASAP7_75t_R   g107(.A(p48), .B(p49), .Y(new_n198_));
  NAND2x1_ASAP7_75t_R  g108(.A(new_n197_), .B(new_n198_), .Y(new_n199_));
  AOI211x1_ASAP7_75t_R g109(.A1(new_n194_), .A2(new_n149_), .B(new_n196_), .C(new_n199_), .Y(new_n200_));
  NOR2x1_ASAP7_75t_R   g110(.A(new_n194_), .B(new_n149_), .Y(new_n201_));
  OR4x2_ASAP7_75t_R    g111(.A(p33), .B(p30), .C(p32), .D(p35), .Y(new_n202_));
  NOR3x1_ASAP7_75t_R   g112(.A(new_n201_), .B(new_n202_), .C(new_n155_), .Y(new_n203_));
  NAND3x1_ASAP7_75t_R  g113(.A(new_n193_), .B(new_n200_), .C(new_n203_), .Y(new_n204_));
  NAND2x1_ASAP7_75t_R  g114(.A(p47), .B(new_n159_), .Y(new_n205_));
  NOR2x1_ASAP7_75t_R   g115(.A(new_n205_), .B(new_n151_), .Y(new_n206_));
  AND2x2_ASAP7_75t_R   g116(.A(p46), .B(p45), .Y(new_n207_));
  AO21x1_ASAP7_75t_R   g117(.A1(p46), .A2(new_n151_), .B(new_n207_), .Y(new_n208_));
  NOR2x1_ASAP7_75t_R   g118(.A(p59), .B(p29), .Y(new_n209_));
  OAI21x1_ASAP7_75t_R  g119(.A1(new_n206_), .A2(new_n208_), .B(new_n209_), .Y(new_n210_));
  INVx1_ASAP7_75t_R    g120(.A(p46), .Y(new_n211_));
  AOI211x1_ASAP7_75t_R g121(.A1(new_n148_), .A2(new_n149_), .B(new_n211_), .C(new_n150_), .Y(new_n212_));
  OAI21x1_ASAP7_75t_R  g122(.A1(new_n152_), .A2(new_n212_), .B(new_n198_), .Y(new_n213_));
  INVx1_ASAP7_75t_R    g123(.A(new_n182_), .Y(new_n214_));
  AOI21x1_ASAP7_75t_R  g124(.A1(new_n184_), .A2(new_n213_), .B(new_n214_), .Y(new_n215_));
  OAI21x1_ASAP7_75t_R  g125(.A1(new_n204_), .A2(new_n210_), .B(new_n215_), .Y(new_n216_));
  OAI21x1_ASAP7_75t_R  g126(.A1(new_n180_), .A2(new_n187_), .B(new_n216_), .Y(new_n217_));
  NOR3x1_ASAP7_75t_R   g127(.A(new_n123_), .B(new_n125_), .C(new_n92_), .Y(new_n218_));
  AOI21x1_ASAP7_75t_R  g128(.A1(new_n145_), .A2(new_n217_), .B(new_n218_), .Y(o1));
  AND3x1_ASAP7_75t_R   g129(.A(new_n143_), .B(new_n140_), .C(new_n135_), .Y(new_n220_));
  NAND2x1_ASAP7_75t_R  g130(.A(new_n126_), .B(new_n220_), .Y(new_n221_));
  NOR2x1_ASAP7_75t_R   g131(.A(p45), .B(new_n151_), .Y(new_n222_));
  OAI22x1_ASAP7_75t_R  g132(.A1(new_n222_), .A2(new_n211_), .B1(new_n151_), .B2(new_n205_), .Y(new_n223_));
  NAND2x1_ASAP7_75t_R  g133(.A(new_n194_), .B(new_n149_), .Y(new_n224_));
  NOR2x1_ASAP7_75t_R   g134(.A(p31), .B(p30), .Y(new_n225_));
  NOR2x1_ASAP7_75t_R   g135(.A(p34), .B(p35), .Y(new_n226_));
  NOR2x1_ASAP7_75t_R   g136(.A(p33), .B(p32), .Y(new_n227_));
  AND5x1_ASAP7_75t_R   g137(.A(p53), .B(new_n225_), .C(new_n226_), .D(new_n227_), .E(p54), .Y(new_n228_));
  NAND2x1_ASAP7_75t_R  g138(.A(p41), .B(p40), .Y(new_n229_));
  AO21x1_ASAP7_75t_R   g139(.A1(new_n167_), .A2(new_n168_), .B(new_n229_), .Y(new_n230_));
  NOR2x1_ASAP7_75t_R   g140(.A(new_n147_), .B(new_n155_), .Y(new_n231_));
  AND5x1_ASAP7_75t_R   g141(.A(new_n224_), .B(new_n228_), .C(new_n230_), .D(new_n231_), .E(new_n197_), .Y(new_n232_));
  NOR2x1_ASAP7_75t_R   g142(.A(p50), .B(p45), .Y(new_n233_));
  AND3x1_ASAP7_75t_R   g143(.A(new_n233_), .B(new_n158_), .C(p56), .Y(new_n234_));
  INVx1_ASAP7_75t_R    g144(.A(p40), .Y(new_n235_));
  NOR3x1_ASAP7_75t_R   g145(.A(new_n150_), .B(p42), .C(new_n235_), .Y(new_n236_));
  NOR2x1_ASAP7_75t_R   g146(.A(p39), .B(new_n168_), .Y(new_n237_));
  NOR2x1_ASAP7_75t_R   g147(.A(p37), .B(p36), .Y(new_n238_));
  NAND2x1_ASAP7_75t_R  g148(.A(p59), .B(p29), .Y(new_n239_));
  AND5x1_ASAP7_75t_R   g149(.A(new_n234_), .B(new_n236_), .C(new_n237_), .D(new_n238_), .E(new_n239_), .Y(new_n240_));
  NAND3x1_ASAP7_75t_R  g150(.A(new_n223_), .B(new_n232_), .C(new_n240_), .Y(new_n241_));
  INVx1_ASAP7_75t_R    g151(.A(new_n181_), .Y(new_n242_));
  NOR2x1_ASAP7_75t_R   g152(.A(p50), .B(p51), .Y(new_n243_));
  OA21x2_ASAP7_75t_R   g153(.A1(new_n243_), .A2(new_n242_), .B(new_n158_), .Y(new_n244_));
  OAI21x1_ASAP7_75t_R  g154(.A1(new_n242_), .A2(new_n213_), .B(new_n244_), .Y(new_n245_));
  NAND3x1_ASAP7_75t_R  g155(.A(new_n241_), .B(new_n174_), .C(new_n245_), .Y(new_n246_));
  AOI211x1_ASAP7_75t_R g156(.A1(new_n108_), .A2(new_n221_), .B(new_n246_), .C(new_n218_), .Y(o2));
  assign               o3 = 1'b0;
  assign               o4 = 1'b0;
  assign               o5 = 1'b0;
  assign               o6 = 1'b0;
  assign               o7 = 1'b0;
  assign               o8 = 1'b0;
  assign               o9 = 1'b0;
  assign               o10 = 1'b0;
  assign               o11 = 1'b0;
  assign               o12 = 1'b0;
  assign               o13 = 1'b0;
  assign               o14 = 1'b0;
  assign               o15 = 1'b0;
  assign               o16 = 1'b0;
  assign               o17 = 1'b0;
  assign               o18 = 1'b0;
  assign               o19 = 1'b0;
  assign               o20 = 1'b0;
  assign               o21 = 1'b0;
  assign               o22 = 1'b0;
  assign               o23 = 1'b0;
  assign               o24 = 1'b0;
  assign               o25 = 1'b0;
  assign               o26 = 1'b0;
  assign               o27 = 1'b0;
  assign               o28 = 1'b0;
  assign               o29 = 1'b0;
endmodule


