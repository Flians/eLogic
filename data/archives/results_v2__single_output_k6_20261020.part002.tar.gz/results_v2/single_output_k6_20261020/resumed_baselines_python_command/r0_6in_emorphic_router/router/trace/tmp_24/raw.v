// Benchmark "/tmp/" written by ABC on Tue Oct 20 18:11:46 2026

module \/tmp/  ( 
    p20, p58, p41, p30, p55, p14, p40, p7, p28, p22, p16, p11, p48, p27,
    p47, p52, p56, p2, p9, p6, p4, p3, p34, p57, p31, p24, p18, p15, p21,
    p43, p1, p37, p45, p38, p32, p12, p36, p44, p39, p33, p8, p26, p42,
    p50, p17, p0, p49, p23, p46, p29, p53, p25, p5, p54, p59, p19, p35,
    p13, p10, p51,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25, o26, o27, o28, o29  );
  input  p20, p58, p41, p30, p55, p14, p40, p7, p28, p22, p16, p11, p48,
    p27, p47, p52, p56, p2, p9, p6, p4, p3, p34, p57, p31, p24, p18, p15,
    p21, p43, p1, p37, p45, p38, p32, p12, p36, p44, p39, p33, p8, p26,
    p42, p50, p17, p0, p49, p23, p46, p29, p53, p25, p5, p54, p59, p19,
    p35, p13, p10, p51;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25, o26, o27, o28, o29;
  wire new_n91_, new_n92_, new_n93_, new_n94_, new_n95_, new_n96_, new_n97_,
    new_n98_, new_n99_, new_n100_, new_n101_, new_n102_, new_n103_,
    new_n104_, new_n105_, new_n106_, new_n107_, new_n108_, new_n109_,
    new_n110_, new_n111_, new_n112_, new_n113_, new_n114_, new_n115_,
    new_n116_, new_n117_, new_n118_, new_n119_, new_n120_, new_n121_,
    new_n122_, new_n123_, new_n124_, new_n125_, new_n126_, new_n127_,
    new_n128_, new_n129_, new_n130_, new_n131_, new_n132_, new_n133_,
    new_n134_, new_n135_, new_n136_, new_n137_, new_n138_, new_n140_,
    new_n141_, new_n142_, new_n143_, new_n144_, new_n145_, new_n146_,
    new_n147_, new_n148_, new_n149_, new_n150_, new_n151_, new_n152_,
    new_n153_, new_n154_, new_n155_, new_n156_, new_n157_, new_n158_,
    new_n159_, new_n160_, new_n161_, new_n162_, new_n163_, new_n164_,
    new_n165_, new_n166_, new_n167_, new_n168_, new_n169_, new_n170_,
    new_n171_, new_n172_, new_n173_, new_n174_, new_n175_, new_n176_,
    new_n177_, new_n178_, new_n179_, new_n180_, new_n181_, new_n182_,
    new_n183_, new_n184_, new_n185_, new_n186_, new_n187_, new_n188_,
    new_n189_, new_n190_, new_n191_, new_n192_, new_n193_, new_n194_,
    new_n195_, new_n196_, new_n197_, new_n198_, new_n199_, new_n200_,
    new_n201_, new_n202_, new_n203_, new_n204_, new_n205_, new_n206_,
    new_n208_, new_n209_, new_n210_, new_n211_, new_n212_, new_n213_,
    new_n214_, new_n215_, new_n216_, new_n217_, new_n218_, new_n219_,
    new_n220_, new_n221_, new_n222_, new_n223_, new_n224_, new_n225_;
  INVx1_ASAP7_75t_R    g000(.A(p25), .Y(new_n91_));
  NAND3x1_ASAP7_75t_R  g001(.A(p28), .B(p27), .C(p26), .Y(new_n92_));
  NOR2x1_ASAP7_75t_R   g002(.A(new_n91_), .B(new_n92_), .Y(new_n93_));
  INVx1_ASAP7_75t_R    g003(.A(new_n93_), .Y(new_n94_));
  NOR2x1_ASAP7_75t_R   g004(.A(p20), .B(p21), .Y(new_n95_));
  NOR2x1_ASAP7_75t_R   g005(.A(p11), .B(p12), .Y(new_n96_));
  OAI21x1_ASAP7_75t_R  g006(.A1(p9), .A2(p8), .B(p10), .Y(new_n97_));
  NAND2x1_ASAP7_75t_R  g007(.A(p14), .B(p13), .Y(new_n98_));
  AOI21x1_ASAP7_75t_R  g008(.A1(new_n96_), .A2(new_n97_), .B(new_n98_), .Y(new_n99_));
  AO21x1_ASAP7_75t_R   g009(.A1(p16), .A2(p15), .B(p17), .Y(new_n100_));
  AOI21x1_ASAP7_75t_R  g010(.A1(p16), .A2(new_n99_), .B(new_n100_), .Y(new_n101_));
  AND2x2_ASAP7_75t_R   g011(.A(p18), .B(p19), .Y(new_n102_));
  INVx1_ASAP7_75t_R    g012(.A(new_n95_), .Y(new_n103_));
  OAI21x1_ASAP7_75t_R  g013(.A1(new_n102_), .A2(new_n103_), .B(p22), .Y(new_n104_));
  AOI21x1_ASAP7_75t_R  g014(.A1(new_n95_), .A2(new_n101_), .B(new_n104_), .Y(new_n105_));
  INVx1_ASAP7_75t_R    g015(.A(new_n92_), .Y(new_n106_));
  NAND2x1_ASAP7_75t_R  g016(.A(p24), .B(p23), .Y(new_n107_));
  INVx1_ASAP7_75t_R    g017(.A(new_n107_), .Y(new_n108_));
  NAND3x1_ASAP7_75t_R  g018(.A(new_n105_), .B(new_n106_), .C(new_n108_), .Y(new_n109_));
  OA21x2_ASAP7_75t_R   g019(.A1(p15), .A2(new_n99_), .B(p16), .Y(new_n110_));
  INVx1_ASAP7_75t_R    g020(.A(p1), .Y(new_n111_));
  NOR2x1_ASAP7_75t_R   g021(.A(p25), .B(p5), .Y(new_n112_));
  NOR2x1_ASAP7_75t_R   g022(.A(p17), .B(p0), .Y(new_n113_));
  AND5x1_ASAP7_75t_R   g023(.A(new_n111_), .B(new_n112_), .C(new_n113_), .D(p8), .E(p10), .Y(new_n114_));
  AND3x1_ASAP7_75t_R   g024(.A(new_n95_), .B(p22), .C(p19), .Y(new_n115_));
  AND5x1_ASAP7_75t_R   g025(.A(p14), .B(new_n96_), .C(p24), .D(p23), .E(p13), .Y(new_n116_));
  OR4x2_ASAP7_75t_R    g026(.A(p7), .B(p2), .C(p9), .D(p6), .Y(new_n117_));
  INVx1_ASAP7_75t_R    g027(.A(p18), .Y(new_n118_));
  OR4x2_ASAP7_75t_R    g028(.A(new_n118_), .B(p4), .C(p3), .D(p15), .Y(new_n119_));
  NOR2x1_ASAP7_75t_R   g029(.A(new_n117_), .B(new_n119_), .Y(new_n120_));
  AND5x1_ASAP7_75t_R   g030(.A(new_n110_), .B(new_n114_), .C(new_n115_), .D(new_n116_), .E(new_n120_), .Y(new_n121_));
  AO21x1_ASAP7_75t_R   g031(.A1(new_n94_), .A2(new_n109_), .B(new_n121_), .Y(new_n122_));
  OR4x2_ASAP7_75t_R    g032(.A(p11), .B(p9), .C(p12), .D(p8), .Y(new_n123_));
  NAND2x1_ASAP7_75t_R  g033(.A(p22), .B(p19), .Y(new_n124_));
  NAND3x1_ASAP7_75t_R  g034(.A(p7), .B(p59), .C(p10), .Y(new_n125_));
  OR5x1_ASAP7_75t_R    g035(.A(new_n92_), .B(new_n123_), .C(new_n103_), .D(new_n124_), .E(new_n125_), .Y(new_n126_));
  AO21x1_ASAP7_75t_R   g036(.A1(p16), .A2(new_n99_), .B(new_n100_), .Y(new_n127_));
  NAND2x1_ASAP7_75t_R  g037(.A(p16), .B(p2), .Y(new_n128_));
  NAND2x1_ASAP7_75t_R  g038(.A(p6), .B(p4), .Y(new_n129_));
  NOR3x1_ASAP7_75t_R   g039(.A(new_n98_), .B(new_n128_), .C(new_n129_), .Y(new_n130_));
  NAND2x1_ASAP7_75t_R  g040(.A(p3), .B(p24), .Y(new_n131_));
  NOR3x1_ASAP7_75t_R   g041(.A(new_n131_), .B(new_n118_), .C(p15), .Y(new_n132_));
  AND4x2_ASAP7_75t_R   g042(.A(new_n91_), .B(p1), .C(p0), .D(p5), .Y(new_n133_));
  NAND3x1_ASAP7_75t_R  g043(.A(new_n130_), .B(new_n132_), .C(new_n133_), .Y(new_n134_));
  NOR3x1_ASAP7_75t_R   g044(.A(new_n126_), .B(new_n127_), .C(new_n134_), .Y(new_n135_));
  AO21x1_ASAP7_75t_R   g045(.A1(p22), .A2(new_n103_), .B(p23), .Y(new_n136_));
  AOI211x1_ASAP7_75t_R g046(.A1(new_n95_), .A2(new_n101_), .B(new_n107_), .C(new_n104_), .Y(new_n137_));
  AO221x2_ASAP7_75t_R  g047(.A1(new_n135_), .A2(new_n136_), .B1(new_n106_), .B2(new_n137_), .C(new_n93_), .Y(new_n138_));
  NAND2x1_ASAP7_75t_R  g048(.A(new_n122_), .B(new_n138_), .Y(o0));
  AOI21x1_ASAP7_75t_R  g049(.A1(new_n94_), .A2(new_n109_), .B(new_n121_), .Y(new_n140_));
  NAND2x1_ASAP7_75t_R  g050(.A(p48), .B(p49), .Y(new_n141_));
  NOR2x1_ASAP7_75t_R   g051(.A(p41), .B(p42), .Y(new_n142_));
  OAI21x1_ASAP7_75t_R  g052(.A1(p38), .A2(p39), .B(p40), .Y(new_n143_));
  NAND2x1_ASAP7_75t_R  g053(.A(p43), .B(p44), .Y(new_n144_));
  AOI21x1_ASAP7_75t_R  g054(.A1(new_n142_), .A2(new_n143_), .B(new_n144_), .Y(new_n145_));
  AO21x1_ASAP7_75t_R   g055(.A1(p45), .A2(p46), .B(p47), .Y(new_n146_));
  AOI21x1_ASAP7_75t_R  g056(.A1(p46), .A2(new_n145_), .B(new_n146_), .Y(new_n147_));
  INVx1_ASAP7_75t_R    g057(.A(p51), .Y(new_n148_));
  NAND2x1_ASAP7_75t_R  g058(.A(p52), .B(new_n148_), .Y(new_n149_));
  OAI21x1_ASAP7_75t_R  g059(.A1(new_n141_), .A2(new_n147_), .B(new_n149_), .Y(new_n150_));
  AND4x2_ASAP7_75t_R   g060(.A(p36), .B(p44), .C(p33), .D(p49), .Y(new_n151_));
  AND3x1_ASAP7_75t_R   g061(.A(p58), .B(p56), .C(p57), .Y(new_n152_));
  AND3x1_ASAP7_75t_R   g062(.A(p46), .B(p29), .C(p35), .Y(new_n153_));
  AND3x1_ASAP7_75t_R   g063(.A(new_n151_), .B(new_n152_), .C(new_n153_), .Y(new_n154_));
  INVx1_ASAP7_75t_R    g064(.A(p55), .Y(new_n155_));
  NAND2x1_ASAP7_75t_R  g065(.A(p40), .B(new_n155_), .Y(new_n156_));
  NAND2x1_ASAP7_75t_R  g066(.A(p53), .B(p54), .Y(new_n157_));
  OAI22x1_ASAP7_75t_R  g067(.A1(p48), .A2(p47), .B1(p43), .B2(p42), .Y(new_n158_));
  NOR3x1_ASAP7_75t_R   g068(.A(new_n156_), .B(new_n157_), .C(new_n158_), .Y(new_n159_));
  NAND2x1_ASAP7_75t_R  g069(.A(p45), .B(p46), .Y(new_n160_));
  OAI21x1_ASAP7_75t_R  g070(.A1(p48), .A2(new_n160_), .B(new_n146_), .Y(new_n161_));
  AND2x2_ASAP7_75t_R   g071(.A(p31), .B(p37), .Y(new_n162_));
  INVx1_ASAP7_75t_R    g072(.A(p45), .Y(new_n163_));
  AND3x1_ASAP7_75t_R   g073(.A(new_n162_), .B(new_n163_), .C(p32), .Y(new_n164_));
  NOR2x1_ASAP7_75t_R   g074(.A(p38), .B(p39), .Y(new_n165_));
  AND3x1_ASAP7_75t_R   g075(.A(new_n165_), .B(p30), .C(p34), .Y(new_n166_));
  AND5x1_ASAP7_75t_R   g076(.A(new_n154_), .B(new_n159_), .C(new_n161_), .D(new_n164_), .E(new_n166_), .Y(new_n167_));
  INVx1_ASAP7_75t_R    g077(.A(p43), .Y(new_n168_));
  INVx1_ASAP7_75t_R    g078(.A(p41), .Y(new_n169_));
  NOR2x1_ASAP7_75t_R   g079(.A(new_n169_), .B(new_n143_), .Y(new_n170_));
  AO22x1_ASAP7_75t_R   g080(.A1(new_n143_), .A2(new_n142_), .B1(new_n168_), .B2(new_n170_), .Y(new_n171_));
  NAND3x1_ASAP7_75t_R  g081(.A(new_n150_), .B(new_n167_), .C(new_n171_), .Y(new_n172_));
  AND3x1_ASAP7_75t_R   g082(.A(p52), .B(p53), .C(p54), .Y(new_n173_));
  OA21x2_ASAP7_75t_R   g083(.A1(p55), .A2(new_n173_), .B(new_n152_), .Y(new_n174_));
  INVx1_ASAP7_75t_R    g084(.A(p50), .Y(new_n175_));
  AND3x1_ASAP7_75t_R   g085(.A(new_n155_), .B(new_n175_), .C(new_n148_), .Y(new_n176_));
  OAI21x1_ASAP7_75t_R  g086(.A1(new_n141_), .A2(new_n147_), .B(new_n176_), .Y(new_n177_));
  NOR2x1_ASAP7_75t_R   g087(.A(p50), .B(p59), .Y(new_n178_));
  AOI21x1_ASAP7_75t_R  g088(.A1(new_n174_), .A2(new_n177_), .B(new_n178_), .Y(new_n179_));
  AO21x1_ASAP7_75t_R   g089(.A1(p47), .A2(p46), .B(new_n141_), .Y(new_n180_));
  OR3x1_ASAP7_75t_R    g090(.A(new_n157_), .B(p30), .C(p34), .Y(new_n181_));
  AOI211x1_ASAP7_75t_R g091(.A1(new_n169_), .A2(new_n143_), .B(new_n180_), .C(new_n181_), .Y(new_n182_));
  NOR2x1_ASAP7_75t_R   g092(.A(p37), .B(p45), .Y(new_n183_));
  INVx1_ASAP7_75t_R    g093(.A(p40), .Y(new_n184_));
  NOR2x1_ASAP7_75t_R   g094(.A(p55), .B(new_n184_), .Y(new_n185_));
  AND4x2_ASAP7_75t_R   g095(.A(p56), .B(p43), .C(p38), .D(p44), .Y(new_n186_));
  NOR2x1_ASAP7_75t_R   g096(.A(p39), .B(p42), .Y(new_n187_));
  NOR2x1_ASAP7_75t_R   g097(.A(p36), .B(p50), .Y(new_n188_));
  AND5x1_ASAP7_75t_R   g098(.A(new_n183_), .B(new_n185_), .C(new_n186_), .D(new_n187_), .E(new_n188_), .Y(new_n189_));
  OR4x2_ASAP7_75t_R    g099(.A(p31), .B(p32), .C(p33), .D(p35), .Y(new_n190_));
  NOR3x1_ASAP7_75t_R   g100(.A(new_n170_), .B(new_n149_), .C(new_n190_), .Y(new_n191_));
  NAND3x1_ASAP7_75t_R  g101(.A(new_n182_), .B(new_n189_), .C(new_n191_), .Y(new_n192_));
  INVx1_ASAP7_75t_R    g102(.A(p47), .Y(new_n193_));
  NOR3x1_ASAP7_75t_R   g103(.A(new_n145_), .B(new_n193_), .C(p45), .Y(new_n194_));
  INVx1_ASAP7_75t_R    g104(.A(new_n160_), .Y(new_n195_));
  AO21x1_ASAP7_75t_R   g105(.A1(p46), .A2(new_n145_), .B(new_n195_), .Y(new_n196_));
  NOR2x1_ASAP7_75t_R   g106(.A(p29), .B(p59), .Y(new_n197_));
  OAI21x1_ASAP7_75t_R  g107(.A1(new_n194_), .A2(new_n196_), .B(new_n197_), .Y(new_n198_));
  INVx1_ASAP7_75t_R    g108(.A(p46), .Y(new_n199_));
  AOI211x1_ASAP7_75t_R g109(.A1(new_n142_), .A2(new_n143_), .B(new_n199_), .C(new_n144_), .Y(new_n200_));
  INVx1_ASAP7_75t_R    g110(.A(new_n141_), .Y(new_n201_));
  OAI21x1_ASAP7_75t_R  g111(.A1(new_n146_), .A2(new_n200_), .B(new_n201_), .Y(new_n202_));
  INVx1_ASAP7_75t_R    g112(.A(new_n174_), .Y(new_n203_));
  AOI21x1_ASAP7_75t_R  g113(.A1(new_n176_), .A2(new_n202_), .B(new_n203_), .Y(new_n204_));
  OAI21x1_ASAP7_75t_R  g114(.A1(new_n192_), .A2(new_n198_), .B(new_n204_), .Y(new_n205_));
  OAI21x1_ASAP7_75t_R  g115(.A1(new_n172_), .A2(new_n179_), .B(new_n205_), .Y(new_n206_));
  OAI21x1_ASAP7_75t_R  g116(.A1(new_n140_), .A2(new_n206_), .B(new_n138_), .Y(o1));
  AOI221x1_ASAP7_75t_R g117(.A1(new_n135_), .A2(new_n136_), .B1(new_n106_), .B2(new_n137_), .C(new_n93_), .Y(new_n208_));
  AND2x2_ASAP7_75t_R   g118(.A(p29), .B(p59), .Y(new_n209_));
  AND2x2_ASAP7_75t_R   g119(.A(p47), .B(p46), .Y(new_n210_));
  OR3x1_ASAP7_75t_R    g120(.A(new_n149_), .B(new_n156_), .C(new_n210_), .Y(new_n211_));
  XOR2x2_ASAP7_75t_R   g121(.A(new_n143_), .B(p41), .Y(new_n212_));
  INVx1_ASAP7_75t_R    g122(.A(p56), .Y(new_n213_));
  OR5x1_ASAP7_75t_R    g123(.A(p30), .B(new_n144_), .C(new_n141_), .D(new_n157_), .E(new_n213_), .Y(new_n214_));
  NOR3x1_ASAP7_75t_R   g124(.A(new_n211_), .B(new_n212_), .C(new_n214_), .Y(new_n215_));
  AO21x1_ASAP7_75t_R   g125(.A1(new_n142_), .A2(new_n143_), .B(new_n144_), .Y(new_n216_));
  NOR2x1_ASAP7_75t_R   g126(.A(p45), .B(new_n193_), .Y(new_n217_));
  AO211x2_ASAP7_75t_R  g127(.A1(new_n216_), .A2(new_n217_), .B(new_n195_), .C(new_n200_), .Y(new_n218_));
  INVx1_ASAP7_75t_R    g128(.A(p38), .Y(new_n219_));
  OR4x2_ASAP7_75t_R    g129(.A(new_n219_), .B(p32), .C(p36), .D(p39), .Y(new_n220_));
  OR4x2_ASAP7_75t_R    g130(.A(p33), .B(p42), .C(p50), .D(p35), .Y(new_n221_));
  OR4x2_ASAP7_75t_R    g131(.A(p34), .B(p31), .C(p37), .D(p45), .Y(new_n222_));
  NOR3x1_ASAP7_75t_R   g132(.A(new_n220_), .B(new_n221_), .C(new_n222_), .Y(new_n223_));
  NAND3x1_ASAP7_75t_R  g133(.A(new_n215_), .B(new_n218_), .C(new_n223_), .Y(new_n224_));
  OAI21x1_ASAP7_75t_R  g134(.A1(new_n209_), .A2(new_n224_), .B(new_n204_), .Y(new_n225_));
  NOR3x1_ASAP7_75t_R   g135(.A(new_n140_), .B(new_n208_), .C(new_n225_), .Y(o2));
  assign               o3 = 1'b0;
  assign               o4 = 1'b0;
  assign               o5 = 1'b0;
  assign               o6 = 1'b0;
  assign               o7 = 1'b0;
  assign               o8 = 1'b0;
  assign               o9 = 1'b0;
  assign               o10 = 1'b0;
  assign               o11 = 1'b0;
  assign               o12 = 1'b0;
  assign               o13 = 1'b0;
  assign               o14 = 1'b0;
  assign               o15 = 1'b0;
  assign               o16 = 1'b0;
  assign               o17 = 1'b0;
  assign               o18 = 1'b0;
  assign               o19 = 1'b0;
  assign               o20 = 1'b0;
  assign               o21 = 1'b0;
  assign               o22 = 1'b0;
  assign               o23 = 1'b0;
  assign               o24 = 1'b0;
  assign               o25 = 1'b0;
  assign               o26 = 1'b0;
  assign               o27 = 1'b0;
  assign               o28 = 1'b0;
  assign               o29 = 1'b0;
endmodule


