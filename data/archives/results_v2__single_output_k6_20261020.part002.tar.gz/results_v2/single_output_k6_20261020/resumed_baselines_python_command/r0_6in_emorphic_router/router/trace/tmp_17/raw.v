// Benchmark "/tmp/" written by ABC on Tue Oct 20 18:11:45 2026

module \/tmp/  ( 
    p23, p15, p38, p28, p29, p59, p58, p26, p54, p24, p35, p37, p19, p44,
    p45, p12, p31, p53, p43, p41, p22, p6, p27, p21, p32, p0, p1, p49, p56,
    p16, p48, p10, p18, p4, p8, p13, p34, p20, p2, p3, p40, p7, p9, p52,
    p47, p50, p25, p42, p5, p30, p11, p51, p17, p55, p57, p36, p39, p46,
    p14, p33,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25, o26, o27, o28, o29  );
  input  p23, p15, p38, p28, p29, p59, p58, p26, p54, p24, p35, p37, p19,
    p44, p45, p12, p31, p53, p43, p41, p22, p6, p27, p21, p32, p0, p1, p49,
    p56, p16, p48, p10, p18, p4, p8, p13, p34, p20, p2, p3, p40, p7, p9,
    p52, p47, p50, p25, p42, p5, p30, p11, p51, p17, p55, p57, p36, p39,
    p46, p14, p33;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25, o26, o27, o28, o29;
  wire new_n91_, new_n92_, new_n93_, new_n94_, new_n95_, new_n96_, new_n97_,
    new_n98_, new_n99_, new_n100_, new_n101_, new_n102_, new_n103_,
    new_n104_, new_n105_, new_n106_, new_n107_, new_n108_, new_n109_,
    new_n110_, new_n111_, new_n112_, new_n113_, new_n114_, new_n115_,
    new_n116_, new_n117_, new_n118_, new_n119_, new_n120_, new_n121_,
    new_n122_, new_n123_, new_n124_, new_n125_, new_n126_, new_n127_,
    new_n128_, new_n129_, new_n130_, new_n131_, new_n132_, new_n133_,
    new_n134_, new_n135_, new_n136_, new_n137_, new_n138_, new_n139_,
    new_n140_, new_n141_, new_n142_, new_n143_, new_n144_, new_n145_,
    new_n146_, new_n147_, new_n148_, new_n149_, new_n150_, new_n152_,
    new_n153_, new_n154_, new_n155_, new_n156_, new_n157_, new_n158_,
    new_n159_, new_n160_, new_n161_, new_n162_, new_n163_, new_n164_,
    new_n165_, new_n166_, new_n167_, new_n168_, new_n169_, new_n170_,
    new_n171_, new_n172_, new_n173_, new_n174_, new_n175_, new_n176_,
    new_n177_, new_n178_, new_n179_, new_n180_, new_n181_, new_n182_,
    new_n183_, new_n184_, new_n185_, new_n186_, new_n187_, new_n188_,
    new_n189_, new_n190_, new_n191_, new_n192_, new_n193_, new_n194_,
    new_n195_, new_n196_, new_n197_, new_n198_, new_n199_, new_n200_,
    new_n201_, new_n202_, new_n203_, new_n204_, new_n205_, new_n206_,
    new_n207_, new_n208_, new_n209_, new_n210_, new_n211_, new_n212_,
    new_n213_, new_n214_, new_n215_, new_n217_, new_n218_, new_n219_,
    new_n220_, new_n221_, new_n222_, new_n223_, new_n224_, new_n225_,
    new_n226_, new_n227_, new_n228_, new_n229_, new_n230_, new_n231_,
    new_n232_, new_n233_, new_n234_, new_n235_, new_n236_, new_n237_,
    new_n238_, new_n239_, new_n240_, new_n241_;
  AND2x2_ASAP7_75t_R   g000(.A(p23), .B(p24), .Y(new_n91_));
  NOR2x1_ASAP7_75t_R   g001(.A(p21), .B(p20), .Y(new_n92_));
  INVx1_ASAP7_75t_R    g002(.A(new_n92_), .Y(new_n93_));
  AO21x1_ASAP7_75t_R   g003(.A1(p15), .A2(p16), .B(p17), .Y(new_n94_));
  NOR2x1_ASAP7_75t_R   g004(.A(p12), .B(p11), .Y(new_n95_));
  OAI21x1_ASAP7_75t_R  g005(.A1(p8), .A2(p9), .B(p10), .Y(new_n96_));
  INVx1_ASAP7_75t_R    g006(.A(p16), .Y(new_n97_));
  NAND2x1_ASAP7_75t_R  g007(.A(p13), .B(p14), .Y(new_n98_));
  AOI211x1_ASAP7_75t_R g008(.A1(new_n95_), .A2(new_n96_), .B(new_n97_), .C(new_n98_), .Y(new_n99_));
  NAND2x1_ASAP7_75t_R  g009(.A(p19), .B(p18), .Y(new_n100_));
  INVx1_ASAP7_75t_R    g010(.A(p22), .Y(new_n101_));
  AOI21x1_ASAP7_75t_R  g011(.A1(new_n100_), .A2(new_n92_), .B(new_n101_), .Y(new_n102_));
  OA31x2_ASAP7_75t_R   g012(.A1(new_n93_), .A2(new_n94_), .A3(new_n99_), .B1(new_n102_), .Y(new_n103_));
  AOI21x1_ASAP7_75t_R  g013(.A1(new_n91_), .A2(new_n103_), .B(p25), .Y(new_n104_));
  AO21x1_ASAP7_75t_R   g014(.A1(new_n95_), .A2(new_n96_), .B(new_n98_), .Y(new_n105_));
  NAND2x1_ASAP7_75t_R  g015(.A(new_n95_), .B(new_n96_), .Y(new_n106_));
  AO21x1_ASAP7_75t_R   g016(.A1(p13), .A2(new_n106_), .B(p14), .Y(new_n107_));
  INVx1_ASAP7_75t_R    g017(.A(p15), .Y(new_n108_));
  AO21x1_ASAP7_75t_R   g018(.A1(new_n108_), .A2(new_n105_), .B(new_n97_), .Y(new_n109_));
  AOI21x1_ASAP7_75t_R  g019(.A1(new_n105_), .A2(new_n107_), .B(new_n109_), .Y(new_n110_));
  INVx1_ASAP7_75t_R    g020(.A(p18), .Y(new_n111_));
  INVx1_ASAP7_75t_R    g021(.A(p13), .Y(new_n112_));
  OR4x2_ASAP7_75t_R    g022(.A(new_n111_), .B(new_n112_), .C(p12), .D(p17), .Y(new_n113_));
  OR3x1_ASAP7_75t_R    g023(.A(p0), .B(p1), .C(p20), .Y(new_n114_));
  INVx1_ASAP7_75t_R    g024(.A(p21), .Y(new_n115_));
  AND2x2_ASAP7_75t_R   g025(.A(p19), .B(p22), .Y(new_n116_));
  NAND2x1_ASAP7_75t_R  g026(.A(new_n115_), .B(new_n116_), .Y(new_n117_));
  OR3x1_ASAP7_75t_R    g027(.A(new_n113_), .B(new_n114_), .C(new_n117_), .Y(new_n118_));
  INVx1_ASAP7_75t_R    g028(.A(new_n91_), .Y(new_n119_));
  NOR2x1_ASAP7_75t_R   g029(.A(p6), .B(p7), .Y(new_n120_));
  NAND2x1_ASAP7_75t_R  g030(.A(p8), .B(new_n120_), .Y(new_n121_));
  OR2x4_ASAP7_75t_R    g031(.A(p4), .B(p5), .Y(new_n122_));
  OR3x1_ASAP7_75t_R    g032(.A(p2), .B(p3), .C(p9), .Y(new_n123_));
  OR5x1_ASAP7_75t_R    g033(.A(new_n119_), .B(p25), .C(new_n121_), .D(new_n122_), .E(new_n123_), .Y(new_n124_));
  NOR2x1_ASAP7_75t_R   g034(.A(p11), .B(new_n96_), .Y(new_n125_));
  NOR2x1_ASAP7_75t_R   g035(.A(p8), .B(p9), .Y(new_n126_));
  INVx1_ASAP7_75t_R    g036(.A(p10), .Y(new_n127_));
  AND3x1_ASAP7_75t_R   g037(.A(new_n126_), .B(new_n127_), .C(p11), .Y(new_n128_));
  OAI22x1_ASAP7_75t_R  g038(.A1(new_n105_), .A2(new_n108_), .B1(new_n125_), .B2(new_n128_), .Y(new_n129_));
  NOR3x1_ASAP7_75t_R   g039(.A(new_n118_), .B(new_n124_), .C(new_n129_), .Y(new_n130_));
  AND3x1_ASAP7_75t_R   g040(.A(p28), .B(p26), .C(p27), .Y(new_n131_));
  INVx1_ASAP7_75t_R    g041(.A(new_n131_), .Y(new_n132_));
  AO21x1_ASAP7_75t_R   g042(.A1(new_n110_), .A2(new_n130_), .B(new_n132_), .Y(new_n133_));
  INVx1_ASAP7_75t_R    g043(.A(new_n98_), .Y(new_n134_));
  AO31x2_ASAP7_75t_R   g044(.A1(new_n106_), .A2(p16), .A3(new_n134_), .B(new_n94_), .Y(new_n135_));
  AND3x1_ASAP7_75t_R   g045(.A(p2), .B(p3), .C(p7), .Y(new_n136_));
  AND3x1_ASAP7_75t_R   g046(.A(new_n131_), .B(new_n136_), .C(p5), .Y(new_n137_));
  NAND3x1_ASAP7_75t_R  g047(.A(new_n137_), .B(new_n92_), .C(new_n116_), .Y(new_n138_));
  AND3x1_ASAP7_75t_R   g048(.A(new_n95_), .B(new_n108_), .C(p59), .Y(new_n139_));
  NOR2x1_ASAP7_75t_R   g049(.A(p25), .B(new_n111_), .Y(new_n140_));
  NAND3x1_ASAP7_75t_R  g050(.A(new_n139_), .B(new_n126_), .C(new_n140_), .Y(new_n141_));
  AOI211x1_ASAP7_75t_R g051(.A1(new_n134_), .A2(new_n106_), .B(p15), .C(p16), .Y(new_n142_));
  INVx1_ASAP7_75t_R    g052(.A(p0), .Y(new_n143_));
  NAND2x1_ASAP7_75t_R  g053(.A(p10), .B(p4), .Y(new_n144_));
  NAND2x1_ASAP7_75t_R  g054(.A(p24), .B(p6), .Y(new_n145_));
  INVx1_ASAP7_75t_R    g055(.A(p1), .Y(new_n146_));
  OR5x1_ASAP7_75t_R    g056(.A(new_n143_), .B(new_n98_), .C(new_n144_), .D(new_n145_), .E(new_n146_), .Y(new_n147_));
  OR5x1_ASAP7_75t_R    g057(.A(new_n135_), .B(new_n138_), .C(new_n141_), .D(new_n142_), .E(new_n147_), .Y(new_n148_));
  AOI21x1_ASAP7_75t_R  g058(.A1(p22), .A2(new_n93_), .B(p23), .Y(new_n149_));
  OAI22x1_ASAP7_75t_R  g059(.A1(new_n148_), .A2(new_n149_), .B1(new_n132_), .B2(new_n104_), .Y(new_n150_));
  OAI21x1_ASAP7_75t_R  g060(.A1(new_n104_), .A2(new_n133_), .B(new_n150_), .Y(o0));
  INVx1_ASAP7_75t_R    g061(.A(p31), .Y(new_n152_));
  NOR2x1_ASAP7_75t_R   g062(.A(p45), .B(new_n152_), .Y(new_n153_));
  INVx1_ASAP7_75t_R    g063(.A(p41), .Y(new_n154_));
  AND2x2_ASAP7_75t_R   g064(.A(p32), .B(p49), .Y(new_n155_));
  AND2x2_ASAP7_75t_R   g065(.A(p37), .B(p44), .Y(new_n156_));
  AND5x1_ASAP7_75t_R   g066(.A(p43), .B(new_n153_), .C(new_n154_), .D(new_n155_), .E(new_n156_), .Y(new_n157_));
  AND4x2_ASAP7_75t_R   g067(.A(p56), .B(p48), .C(p34), .D(p40), .Y(new_n158_));
  INVx1_ASAP7_75t_R    g068(.A(p55), .Y(new_n159_));
  AND3x1_ASAP7_75t_R   g069(.A(p36), .B(p46), .C(p33), .Y(new_n160_));
  NOR2x1_ASAP7_75t_R   g070(.A(p47), .B(p42), .Y(new_n161_));
  AND5x1_ASAP7_75t_R   g071(.A(p30), .B(new_n158_), .C(new_n159_), .D(new_n160_), .E(new_n161_), .Y(new_n162_));
  AND2x2_ASAP7_75t_R   g072(.A(p58), .B(p57), .Y(new_n163_));
  AND2x2_ASAP7_75t_R   g073(.A(p54), .B(p53), .Y(new_n164_));
  NOR2x1_ASAP7_75t_R   g074(.A(p38), .B(p39), .Y(new_n165_));
  AND5x1_ASAP7_75t_R   g075(.A(p29), .B(new_n163_), .C(new_n164_), .D(p35), .E(new_n165_), .Y(new_n166_));
  AND3x1_ASAP7_75t_R   g076(.A(new_n157_), .B(new_n162_), .C(new_n166_), .Y(new_n167_));
  INVx1_ASAP7_75t_R    g077(.A(p51), .Y(new_n168_));
  NAND2x1_ASAP7_75t_R  g078(.A(p52), .B(new_n168_), .Y(new_n169_));
  AO21x1_ASAP7_75t_R   g079(.A1(p45), .A2(p46), .B(p47), .Y(new_n170_));
  NOR2x1_ASAP7_75t_R   g080(.A(p41), .B(p42), .Y(new_n171_));
  OAI21x1_ASAP7_75t_R  g081(.A1(p38), .A2(p39), .B(p40), .Y(new_n172_));
  INVx1_ASAP7_75t_R    g082(.A(p46), .Y(new_n173_));
  NAND2x1_ASAP7_75t_R  g083(.A(p44), .B(p43), .Y(new_n174_));
  AOI211x1_ASAP7_75t_R g084(.A1(new_n171_), .A2(new_n172_), .B(new_n173_), .C(new_n174_), .Y(new_n175_));
  NAND2x1_ASAP7_75t_R  g085(.A(p49), .B(p48), .Y(new_n176_));
  INVx1_ASAP7_75t_R    g086(.A(new_n176_), .Y(new_n177_));
  OAI21x1_ASAP7_75t_R  g087(.A1(new_n170_), .A2(new_n175_), .B(new_n177_), .Y(new_n178_));
  NAND2x1_ASAP7_75t_R  g088(.A(new_n169_), .B(new_n178_), .Y(new_n179_));
  NAND2x1_ASAP7_75t_R  g089(.A(new_n167_), .B(new_n179_), .Y(new_n180_));
  AND3x1_ASAP7_75t_R   g090(.A(p54), .B(p53), .C(p52), .Y(new_n181_));
  AND3x1_ASAP7_75t_R   g091(.A(p58), .B(p56), .C(p57), .Y(new_n182_));
  OA21x2_ASAP7_75t_R   g092(.A1(p55), .A2(new_n181_), .B(new_n182_), .Y(new_n183_));
  AOI21x1_ASAP7_75t_R  g093(.A1(new_n171_), .A2(new_n172_), .B(new_n174_), .Y(new_n184_));
  AOI21x1_ASAP7_75t_R  g094(.A1(p46), .A2(new_n184_), .B(new_n170_), .Y(new_n185_));
  INVx1_ASAP7_75t_R    g095(.A(p50), .Y(new_n186_));
  AND3x1_ASAP7_75t_R   g096(.A(new_n186_), .B(new_n168_), .C(new_n159_), .Y(new_n187_));
  OAI21x1_ASAP7_75t_R  g097(.A1(new_n176_), .A2(new_n185_), .B(new_n187_), .Y(new_n188_));
  NOR2x1_ASAP7_75t_R   g098(.A(p59), .B(p50), .Y(new_n189_));
  AOI21x1_ASAP7_75t_R  g099(.A1(new_n183_), .A2(new_n188_), .B(new_n189_), .Y(new_n190_));
  NAND2x1_ASAP7_75t_R  g100(.A(p56), .B(p40), .Y(new_n191_));
  OR3x1_ASAP7_75t_R    g101(.A(new_n191_), .B(p45), .C(p50), .Y(new_n192_));
  INVx1_ASAP7_75t_R    g102(.A(p38), .Y(new_n193_));
  OR3x1_ASAP7_75t_R    g103(.A(new_n174_), .B(new_n193_), .C(p37), .Y(new_n194_));
  OR4x2_ASAP7_75t_R    g104(.A(p42), .B(p55), .C(p36), .D(p39), .Y(new_n195_));
  NOR3x1_ASAP7_75t_R   g105(.A(new_n192_), .B(new_n194_), .C(new_n195_), .Y(new_n196_));
  NOR2x1_ASAP7_75t_R   g106(.A(p35), .B(p31), .Y(new_n197_));
  NAND2x1_ASAP7_75t_R  g107(.A(new_n197_), .B(new_n164_), .Y(new_n198_));
  AO21x1_ASAP7_75t_R   g108(.A1(p47), .A2(p46), .B(new_n176_), .Y(new_n199_));
  AOI211x1_ASAP7_75t_R g109(.A1(new_n154_), .A2(new_n172_), .B(new_n198_), .C(new_n199_), .Y(new_n200_));
  NOR2x1_ASAP7_75t_R   g110(.A(new_n154_), .B(new_n172_), .Y(new_n201_));
  OR4x2_ASAP7_75t_R    g111(.A(p32), .B(p34), .C(p30), .D(p33), .Y(new_n202_));
  NOR3x1_ASAP7_75t_R   g112(.A(new_n201_), .B(new_n202_), .C(new_n169_), .Y(new_n203_));
  NAND3x1_ASAP7_75t_R  g113(.A(new_n196_), .B(new_n200_), .C(new_n203_), .Y(new_n204_));
  INVx1_ASAP7_75t_R    g114(.A(p47), .Y(new_n205_));
  NOR3x1_ASAP7_75t_R   g115(.A(new_n184_), .B(p45), .C(new_n205_), .Y(new_n206_));
  AND2x2_ASAP7_75t_R   g116(.A(p45), .B(p46), .Y(new_n207_));
  AO21x1_ASAP7_75t_R   g117(.A1(p46), .A2(new_n184_), .B(new_n207_), .Y(new_n208_));
  NOR2x1_ASAP7_75t_R   g118(.A(p29), .B(p59), .Y(new_n209_));
  OAI21x1_ASAP7_75t_R  g119(.A1(new_n206_), .A2(new_n208_), .B(new_n209_), .Y(new_n210_));
  INVx1_ASAP7_75t_R    g120(.A(new_n183_), .Y(new_n211_));
  AOI21x1_ASAP7_75t_R  g121(.A1(new_n187_), .A2(new_n178_), .B(new_n211_), .Y(new_n212_));
  OAI21x1_ASAP7_75t_R  g122(.A1(new_n204_), .A2(new_n210_), .B(new_n212_), .Y(new_n213_));
  OAI21x1_ASAP7_75t_R  g123(.A1(new_n180_), .A2(new_n190_), .B(new_n213_), .Y(new_n214_));
  AOI211x1_ASAP7_75t_R g124(.A1(new_n110_), .A2(new_n130_), .B(new_n132_), .C(new_n104_), .Y(new_n215_));
  AOI21x1_ASAP7_75t_R  g125(.A1(new_n150_), .A2(new_n214_), .B(new_n215_), .Y(o1));
  INVx1_ASAP7_75t_R    g126(.A(new_n139_), .Y(new_n217_));
  NAND2x1_ASAP7_75t_R  g127(.A(new_n126_), .B(new_n140_), .Y(new_n218_));
  OR3x1_ASAP7_75t_R    g128(.A(new_n217_), .B(new_n147_), .C(new_n218_), .Y(new_n219_));
  OR5x1_ASAP7_75t_R    g129(.A(new_n135_), .B(new_n219_), .C(new_n149_), .D(new_n142_), .E(new_n138_), .Y(new_n220_));
  OAI21x1_ASAP7_75t_R  g130(.A1(new_n93_), .A2(new_n135_), .B(new_n102_), .Y(new_n221_));
  NAND2x1_ASAP7_75t_R  g131(.A(p25), .B(new_n131_), .Y(new_n222_));
  OA31x2_ASAP7_75t_R   g132(.A1(new_n132_), .A2(new_n119_), .A3(new_n221_), .B1(new_n222_), .Y(new_n223_));
  AND2x2_ASAP7_75t_R   g133(.A(p29), .B(p59), .Y(new_n224_));
  OA21x2_ASAP7_75t_R   g134(.A1(p45), .A2(new_n184_), .B(new_n173_), .Y(new_n225_));
  NOR2x1_ASAP7_75t_R   g135(.A(p42), .B(p30), .Y(new_n226_));
  AND3x1_ASAP7_75t_R   g136(.A(new_n226_), .B(p40), .C(new_n186_), .Y(new_n227_));
  NOR3x1_ASAP7_75t_R   g137(.A(p36), .B(p39), .C(p33), .Y(new_n228_));
  NAND3x1_ASAP7_75t_R  g138(.A(new_n227_), .B(new_n181_), .C(new_n228_), .Y(new_n229_));
  XOR2x2_ASAP7_75t_R   g139(.A(new_n172_), .B(p41), .Y(new_n230_));
  AND2x2_ASAP7_75t_R   g140(.A(p47), .B(p46), .Y(new_n231_));
  OR5x1_ASAP7_75t_R    g141(.A(p51), .B(new_n231_), .C(p55), .D(new_n174_), .E(new_n176_), .Y(new_n232_));
  NOR2x1_ASAP7_75t_R   g142(.A(p31), .B(p32), .Y(new_n233_));
  INVx1_ASAP7_75t_R    g143(.A(p34), .Y(new_n234_));
  AND3x1_ASAP7_75t_R   g144(.A(new_n233_), .B(p56), .C(new_n234_), .Y(new_n235_));
  NOR2x1_ASAP7_75t_R   g145(.A(p37), .B(p45), .Y(new_n236_));
  INVx1_ASAP7_75t_R    g146(.A(p35), .Y(new_n237_));
  AND3x1_ASAP7_75t_R   g147(.A(new_n236_), .B(p38), .C(new_n237_), .Y(new_n238_));
  NAND2x1_ASAP7_75t_R  g148(.A(new_n235_), .B(new_n238_), .Y(new_n239_));
  OR5x1_ASAP7_75t_R    g149(.A(new_n225_), .B(new_n229_), .C(new_n230_), .D(new_n232_), .E(new_n239_), .Y(new_n240_));
  OAI21x1_ASAP7_75t_R  g150(.A1(new_n224_), .A2(new_n240_), .B(new_n212_), .Y(new_n241_));
  AOI211x1_ASAP7_75t_R g151(.A1(new_n220_), .A2(new_n223_), .B(new_n241_), .C(new_n215_), .Y(o2));
  assign               o3 = 1'b0;
  assign               o4 = 1'b0;
  assign               o5 = 1'b0;
  assign               o6 = 1'b0;
  assign               o7 = 1'b0;
  assign               o8 = 1'b0;
  assign               o9 = 1'b0;
  assign               o10 = 1'b0;
  assign               o11 = 1'b0;
  assign               o12 = 1'b0;
  assign               o13 = 1'b0;
  assign               o14 = 1'b0;
  assign               o15 = 1'b0;
  assign               o16 = 1'b0;
  assign               o17 = 1'b0;
  assign               o18 = 1'b0;
  assign               o19 = 1'b0;
  assign               o20 = 1'b0;
  assign               o21 = 1'b0;
  assign               o22 = 1'b0;
  assign               o23 = 1'b0;
  assign               o24 = 1'b0;
  assign               o25 = 1'b0;
  assign               o26 = 1'b0;
  assign               o27 = 1'b0;
  assign               o28 = 1'b0;
  assign               o29 = 1'b0;
endmodule


