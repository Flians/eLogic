// Benchmark "/tmp/" written by ABC on Tue Oct 20 18:11:43 2026

module \/tmp/  ( 
    p18, p16, p53, p41, p28, p3, p37, p0, p14, p35, p32, p10, p6, p38, p45,
    p8, p20, p29, p49, p33, p52, p51, p54, p55, p19, p13, p12, p44, p26,
    p50, p40, p48, p57, p2, p25, p42, p47, p21, p5, p31, p7, p15, p23, p11,
    p17, p22, p34, p9, p46, p39, p58, p43, p59, p56, p27, p4, p1, p36, p24,
    p30,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25, o26, o27, o28, o29  );
  input  p18, p16, p53, p41, p28, p3, p37, p0, p14, p35, p32, p10, p6,
    p38, p45, p8, p20, p29, p49, p33, p52, p51, p54, p55, p19, p13, p12,
    p44, p26, p50, p40, p48, p57, p2, p25, p42, p47, p21, p5, p31, p7, p15,
    p23, p11, p17, p22, p34, p9, p46, p39, p58, p43, p59, p56, p27, p4, p1,
    p36, p24, p30;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25, o26, o27, o28, o29;
  wire new_n91_, new_n92_, new_n93_, new_n94_, new_n95_, new_n96_, new_n97_,
    new_n98_, new_n99_, new_n100_, new_n101_, new_n102_, new_n103_,
    new_n104_, new_n105_, new_n106_, new_n107_, new_n108_, new_n109_,
    new_n110_, new_n111_, new_n112_, new_n113_, new_n114_, new_n115_,
    new_n116_, new_n117_, new_n118_, new_n119_, new_n120_, new_n121_,
    new_n122_, new_n123_, new_n124_, new_n125_, new_n126_, new_n127_,
    new_n128_, new_n129_, new_n130_, new_n131_, new_n132_, new_n133_,
    new_n134_, new_n135_, new_n136_, new_n137_, new_n138_, new_n139_,
    new_n140_, new_n141_, new_n142_, new_n143_, new_n144_, new_n145_,
    new_n146_, new_n147_, new_n148_, new_n149_, new_n150_, new_n151_,
    new_n153_, new_n154_, new_n155_, new_n156_, new_n157_, new_n158_,
    new_n159_, new_n160_, new_n161_, new_n162_, new_n163_, new_n164_,
    new_n165_, new_n166_, new_n167_, new_n168_, new_n169_, new_n170_,
    new_n171_, new_n172_, new_n173_, new_n174_, new_n175_, new_n176_,
    new_n177_, new_n178_, new_n179_, new_n180_, new_n181_, new_n182_,
    new_n183_, new_n184_, new_n185_, new_n186_, new_n187_, new_n188_,
    new_n189_, new_n190_, new_n191_, new_n192_, new_n193_, new_n194_,
    new_n195_, new_n196_, new_n197_, new_n198_, new_n199_, new_n200_,
    new_n201_, new_n202_, new_n203_, new_n204_, new_n205_, new_n206_,
    new_n207_, new_n208_, new_n209_, new_n211_, new_n212_, new_n213_,
    new_n214_, new_n215_, new_n216_, new_n217_, new_n218_, new_n219_,
    new_n220_, new_n221_, new_n222_;
  AND3x1_ASAP7_75t_R   g000(.A(p23), .B(p22), .C(p24), .Y(new_n91_));
  NOR2x1_ASAP7_75t_R   g001(.A(p20), .B(p21), .Y(new_n92_));
  NOR2x1_ASAP7_75t_R   g002(.A(p12), .B(p11), .Y(new_n93_));
  OAI21x1_ASAP7_75t_R  g003(.A1(p8), .A2(p9), .B(p10), .Y(new_n94_));
  NAND2x1_ASAP7_75t_R  g004(.A(p14), .B(p13), .Y(new_n95_));
  AOI21x1_ASAP7_75t_R  g005(.A1(new_n93_), .A2(new_n94_), .B(new_n95_), .Y(new_n96_));
  AO21x1_ASAP7_75t_R   g006(.A1(p16), .A2(p15), .B(p17), .Y(new_n97_));
  AOI21x1_ASAP7_75t_R  g007(.A1(p16), .A2(new_n96_), .B(new_n97_), .Y(new_n98_));
  NAND2x1_ASAP7_75t_R  g008(.A(p18), .B(p19), .Y(new_n99_));
  INVx1_ASAP7_75t_R    g009(.A(p20), .Y(new_n100_));
  INVx1_ASAP7_75t_R    g010(.A(p21), .Y(new_n101_));
  AND3x1_ASAP7_75t_R   g011(.A(new_n99_), .B(new_n100_), .C(new_n101_), .Y(new_n102_));
  AOI21x1_ASAP7_75t_R  g012(.A1(new_n92_), .A2(new_n98_), .B(new_n102_), .Y(new_n103_));
  AO21x1_ASAP7_75t_R   g013(.A1(new_n91_), .A2(new_n103_), .B(p25), .Y(new_n104_));
  INVx1_ASAP7_75t_R    g014(.A(p25), .Y(new_n105_));
  INVx1_ASAP7_75t_R    g015(.A(p13), .Y(new_n106_));
  NOR2x1_ASAP7_75t_R   g016(.A(p12), .B(new_n106_), .Y(new_n107_));
  INVx1_ASAP7_75t_R    g017(.A(p18), .Y(new_n108_));
  NOR2x1_ASAP7_75t_R   g018(.A(p17), .B(new_n108_), .Y(new_n109_));
  AND5x1_ASAP7_75t_R   g019(.A(new_n105_), .B(new_n107_), .C(new_n109_), .D(p23), .E(p24), .Y(new_n110_));
  OR2x4_ASAP7_75t_R    g020(.A(p8), .B(p9), .Y(new_n111_));
  INVx1_ASAP7_75t_R    g021(.A(p10), .Y(new_n112_));
  NAND2x1_ASAP7_75t_R  g022(.A(p11), .B(new_n112_), .Y(new_n113_));
  AOI22x1_ASAP7_75t_R  g023(.A1(new_n111_), .A2(p11), .B1(new_n113_), .B2(new_n94_), .Y(new_n114_));
  NOR2x1_ASAP7_75t_R   g024(.A(p0), .B(p1), .Y(new_n115_));
  AND5x1_ASAP7_75t_R   g025(.A(new_n100_), .B(new_n115_), .C(p19), .D(new_n101_), .E(p22), .Y(new_n116_));
  NOR2x1_ASAP7_75t_R   g026(.A(p5), .B(p4), .Y(new_n117_));
  INVx1_ASAP7_75t_R    g027(.A(p3), .Y(new_n118_));
  INVx1_ASAP7_75t_R    g028(.A(p2), .Y(new_n119_));
  AND3x1_ASAP7_75t_R   g029(.A(new_n117_), .B(new_n118_), .C(new_n119_), .Y(new_n120_));
  NOR2x1_ASAP7_75t_R   g030(.A(p6), .B(p7), .Y(new_n121_));
  INVx1_ASAP7_75t_R    g031(.A(p9), .Y(new_n122_));
  AND3x1_ASAP7_75t_R   g032(.A(new_n121_), .B(p8), .C(new_n122_), .Y(new_n123_));
  AND5x1_ASAP7_75t_R   g033(.A(new_n110_), .B(new_n114_), .C(new_n116_), .D(new_n120_), .E(new_n123_), .Y(new_n124_));
  INVx1_ASAP7_75t_R    g034(.A(p14), .Y(new_n125_));
  AO21x1_ASAP7_75t_R   g035(.A1(new_n93_), .A2(new_n94_), .B(new_n106_), .Y(new_n126_));
  AO21x1_ASAP7_75t_R   g036(.A1(new_n125_), .A2(new_n126_), .B(new_n96_), .Y(new_n127_));
  OA21x2_ASAP7_75t_R   g037(.A1(p15), .A2(new_n96_), .B(p16), .Y(new_n128_));
  NAND2x1_ASAP7_75t_R  g038(.A(p15), .B(new_n96_), .Y(new_n129_));
  AND3x1_ASAP7_75t_R   g039(.A(new_n127_), .B(new_n128_), .C(new_n129_), .Y(new_n130_));
  AND3x1_ASAP7_75t_R   g040(.A(p28), .B(p26), .C(p27), .Y(new_n131_));
  INVx1_ASAP7_75t_R    g041(.A(new_n131_), .Y(new_n132_));
  AOI21x1_ASAP7_75t_R  g042(.A1(new_n124_), .A2(new_n130_), .B(new_n132_), .Y(new_n133_));
  INVx1_ASAP7_75t_R    g043(.A(new_n98_), .Y(new_n134_));
  AND5x1_ASAP7_75t_R   g044(.A(p59), .B(new_n131_), .C(p4), .D(p1), .E(p24), .Y(new_n135_));
  AND2x2_ASAP7_75t_R   g045(.A(p5), .B(p7), .Y(new_n136_));
  INVx1_ASAP7_75t_R    g046(.A(p15), .Y(new_n137_));
  AND3x1_ASAP7_75t_R   g047(.A(new_n136_), .B(new_n137_), .C(p22), .Y(new_n138_));
  AND2x2_ASAP7_75t_R   g048(.A(p6), .B(p2), .Y(new_n139_));
  AND3x1_ASAP7_75t_R   g049(.A(new_n139_), .B(p0), .C(p14), .Y(new_n140_));
  NAND3x1_ASAP7_75t_R  g050(.A(new_n135_), .B(new_n138_), .C(new_n140_), .Y(new_n141_));
  OR3x1_ASAP7_75t_R    g051(.A(new_n112_), .B(new_n106_), .C(p25), .Y(new_n142_));
  INVx1_ASAP7_75t_R    g052(.A(p19), .Y(new_n143_));
  INVx1_ASAP7_75t_R    g053(.A(p23), .Y(new_n144_));
  OR5x1_ASAP7_75t_R    g054(.A(p20), .B(new_n142_), .C(new_n143_), .D(p21), .E(new_n144_), .Y(new_n145_));
  NOR3x1_ASAP7_75t_R   g055(.A(new_n96_), .B(p16), .C(p15), .Y(new_n146_));
  OR5x1_ASAP7_75t_R    g056(.A(new_n108_), .B(new_n111_), .C(new_n118_), .D(p12), .E(p11), .Y(new_n147_));
  OR5x1_ASAP7_75t_R    g057(.A(new_n134_), .B(new_n141_), .C(new_n145_), .D(new_n146_), .E(new_n147_), .Y(new_n148_));
  INVx1_ASAP7_75t_R    g058(.A(new_n91_), .Y(new_n149_));
  AO211x2_ASAP7_75t_R  g059(.A1(new_n98_), .A2(new_n92_), .B(new_n102_), .C(new_n149_), .Y(new_n150_));
  AO21x1_ASAP7_75t_R   g060(.A1(new_n105_), .A2(new_n150_), .B(new_n132_), .Y(new_n151_));
  AO22x1_ASAP7_75t_R   g061(.A1(new_n104_), .A2(new_n133_), .B1(new_n148_), .B2(new_n151_), .Y(o0));
  AOI21x1_ASAP7_75t_R  g062(.A1(new_n91_), .A2(new_n103_), .B(p25), .Y(new_n153_));
  AOI211x1_ASAP7_75t_R g063(.A1(new_n124_), .A2(new_n130_), .B(new_n132_), .C(new_n153_), .Y(new_n154_));
  AND3x1_ASAP7_75t_R   g064(.A(p53), .B(p52), .C(p54), .Y(new_n155_));
  AND3x1_ASAP7_75t_R   g065(.A(p57), .B(p58), .C(p56), .Y(new_n156_));
  OA21x2_ASAP7_75t_R   g066(.A1(p55), .A2(new_n155_), .B(new_n156_), .Y(new_n157_));
  NAND2x1_ASAP7_75t_R  g067(.A(p49), .B(p48), .Y(new_n158_));
  NOR2x1_ASAP7_75t_R   g068(.A(p41), .B(p42), .Y(new_n159_));
  OAI21x1_ASAP7_75t_R  g069(.A1(p38), .A2(p39), .B(p40), .Y(new_n160_));
  NAND2x1_ASAP7_75t_R  g070(.A(p44), .B(p43), .Y(new_n161_));
  AOI21x1_ASAP7_75t_R  g071(.A1(new_n159_), .A2(new_n160_), .B(new_n161_), .Y(new_n162_));
  AO21x1_ASAP7_75t_R   g072(.A1(p45), .A2(p46), .B(p47), .Y(new_n163_));
  AOI21x1_ASAP7_75t_R  g073(.A1(p46), .A2(new_n162_), .B(new_n163_), .Y(new_n164_));
  INVx1_ASAP7_75t_R    g074(.A(p51), .Y(new_n165_));
  NOR2x1_ASAP7_75t_R   g075(.A(p55), .B(p50), .Y(new_n166_));
  AND2x2_ASAP7_75t_R   g076(.A(new_n165_), .B(new_n166_), .Y(new_n167_));
  OAI21x1_ASAP7_75t_R  g077(.A1(new_n158_), .A2(new_n164_), .B(new_n167_), .Y(new_n168_));
  NOR2x1_ASAP7_75t_R   g078(.A(p50), .B(p59), .Y(new_n169_));
  AOI21x1_ASAP7_75t_R  g079(.A1(new_n157_), .A2(new_n168_), .B(new_n169_), .Y(new_n170_));
  INVx1_ASAP7_75t_R    g080(.A(p52), .Y(new_n171_));
  OAI22x1_ASAP7_75t_R  g081(.A1(new_n164_), .A2(new_n158_), .B1(new_n171_), .B2(p51), .Y(new_n172_));
  INVx1_ASAP7_75t_R    g082(.A(p31), .Y(new_n173_));
  NOR2x1_ASAP7_75t_R   g083(.A(p47), .B(new_n173_), .Y(new_n174_));
  AND4x2_ASAP7_75t_R   g084(.A(p34), .B(p46), .C(p36), .D(p30), .Y(new_n175_));
  AND2x2_ASAP7_75t_R   g085(.A(p40), .B(p48), .Y(new_n176_));
  AND4x2_ASAP7_75t_R   g086(.A(new_n174_), .B(new_n175_), .C(new_n156_), .D(new_n176_), .Y(new_n177_));
  AND2x2_ASAP7_75t_R   g087(.A(new_n159_), .B(new_n160_), .Y(new_n178_));
  NOR2x1_ASAP7_75t_R   g088(.A(p38), .B(p39), .Y(new_n179_));
  AND5x1_ASAP7_75t_R   g089(.A(p53), .B(new_n179_), .C(p54), .D(p44), .E(p43), .Y(new_n180_));
  AND2x2_ASAP7_75t_R   g090(.A(p29), .B(p49), .Y(new_n181_));
  INVx1_ASAP7_75t_R    g091(.A(p55), .Y(new_n182_));
  AND3x1_ASAP7_75t_R   g092(.A(new_n181_), .B(p33), .C(new_n182_), .Y(new_n183_));
  AND2x2_ASAP7_75t_R   g093(.A(p37), .B(p35), .Y(new_n184_));
  INVx1_ASAP7_75t_R    g094(.A(p45), .Y(new_n185_));
  AND3x1_ASAP7_75t_R   g095(.A(new_n184_), .B(p32), .C(new_n185_), .Y(new_n186_));
  AND5x1_ASAP7_75t_R   g096(.A(new_n177_), .B(new_n178_), .C(new_n180_), .D(new_n183_), .E(new_n186_), .Y(new_n187_));
  NAND2x1_ASAP7_75t_R  g097(.A(new_n172_), .B(new_n187_), .Y(new_n188_));
  NAND2x1_ASAP7_75t_R  g098(.A(new_n157_), .B(new_n168_), .Y(new_n189_));
  NOR2x1_ASAP7_75t_R   g099(.A(p29), .B(p59), .Y(new_n190_));
  INVx1_ASAP7_75t_R    g100(.A(new_n158_), .Y(new_n191_));
  NOR3x1_ASAP7_75t_R   g101(.A(new_n161_), .B(p37), .C(p35), .Y(new_n192_));
  AND4x2_ASAP7_75t_R   g102(.A(new_n165_), .B(p53), .C(p52), .D(p54), .Y(new_n193_));
  NAND2x1_ASAP7_75t_R  g103(.A(p47), .B(p46), .Y(new_n194_));
  AND5x1_ASAP7_75t_R   g104(.A(new_n191_), .B(new_n192_), .C(new_n193_), .D(new_n166_), .E(new_n194_), .Y(new_n195_));
  AO21x1_ASAP7_75t_R   g105(.A1(new_n159_), .A2(new_n160_), .B(new_n161_), .Y(new_n196_));
  AO21x1_ASAP7_75t_R   g106(.A1(new_n185_), .A2(new_n196_), .B(p46), .Y(new_n197_));
  INVx1_ASAP7_75t_R    g107(.A(p40), .Y(new_n198_));
  OR4x2_ASAP7_75t_R    g108(.A(new_n198_), .B(p42), .C(p31), .D(p34), .Y(new_n199_));
  INVx1_ASAP7_75t_R    g109(.A(p38), .Y(new_n200_));
  OR4x2_ASAP7_75t_R    g110(.A(new_n200_), .B(p32), .C(p45), .D(p33), .Y(new_n201_));
  NOR2x1_ASAP7_75t_R   g111(.A(p36), .B(p30), .Y(new_n202_));
  INVx1_ASAP7_75t_R    g112(.A(p39), .Y(new_n203_));
  NAND3x1_ASAP7_75t_R  g113(.A(new_n202_), .B(new_n203_), .C(p56), .Y(new_n204_));
  NOR3x1_ASAP7_75t_R   g114(.A(new_n199_), .B(new_n201_), .C(new_n204_), .Y(new_n205_));
  XNOR2x2_ASAP7_75t_R  g115(.A(p41), .B(new_n160_), .Y(new_n206_));
  AND5x1_ASAP7_75t_R   g116(.A(new_n190_), .B(new_n195_), .C(new_n197_), .D(new_n205_), .E(new_n206_), .Y(new_n207_));
  OAI22x1_ASAP7_75t_R  g117(.A1(new_n170_), .A2(new_n188_), .B1(new_n189_), .B2(new_n207_), .Y(new_n208_));
  OAI21x1_ASAP7_75t_R  g118(.A1(new_n153_), .A2(new_n132_), .B(new_n148_), .Y(new_n209_));
  OAI21x1_ASAP7_75t_R  g119(.A1(new_n154_), .A2(new_n208_), .B(new_n209_), .Y(o1));
  INVx1_ASAP7_75t_R    g120(.A(new_n204_), .Y(new_n211_));
  NOR2x1_ASAP7_75t_R   g121(.A(p45), .B(p33), .Y(new_n212_));
  AND3x1_ASAP7_75t_R   g122(.A(new_n194_), .B(p44), .C(p43), .Y(new_n213_));
  AND5x1_ASAP7_75t_R   g123(.A(new_n211_), .B(new_n166_), .C(new_n212_), .D(new_n193_), .E(new_n213_), .Y(new_n214_));
  OR5x1_ASAP7_75t_R    g124(.A(p37), .B(new_n158_), .C(p35), .D(p32), .E(new_n200_), .Y(new_n215_));
  NOR2x1_ASAP7_75t_R   g125(.A(new_n199_), .B(new_n215_), .Y(new_n216_));
  NAND3x1_ASAP7_75t_R  g126(.A(new_n214_), .B(new_n206_), .C(new_n216_), .Y(new_n217_));
  OR3x1_ASAP7_75t_R    g127(.A(new_n162_), .B(p45), .C(p47), .Y(new_n218_));
  NAND2x1_ASAP7_75t_R  g128(.A(p29), .B(p59), .Y(new_n219_));
  NAND3x1_ASAP7_75t_R  g129(.A(new_n197_), .B(new_n218_), .C(new_n219_), .Y(new_n220_));
  AND2x2_ASAP7_75t_R   g130(.A(new_n157_), .B(new_n168_), .Y(new_n221_));
  OAI21x1_ASAP7_75t_R  g131(.A1(new_n217_), .A2(new_n220_), .B(new_n221_), .Y(new_n222_));
  AOI211x1_ASAP7_75t_R g132(.A1(new_n148_), .A2(new_n151_), .B(new_n222_), .C(new_n154_), .Y(o2));
  assign               o3 = 1'b0;
  assign               o4 = 1'b0;
  assign               o5 = 1'b0;
  assign               o6 = 1'b0;
  assign               o7 = 1'b0;
  assign               o8 = 1'b0;
  assign               o9 = 1'b0;
  assign               o10 = 1'b0;
  assign               o11 = 1'b0;
  assign               o12 = 1'b0;
  assign               o13 = 1'b0;
  assign               o14 = 1'b0;
  assign               o15 = 1'b0;
  assign               o16 = 1'b0;
  assign               o17 = 1'b0;
  assign               o18 = 1'b0;
  assign               o19 = 1'b0;
  assign               o20 = 1'b0;
  assign               o21 = 1'b0;
  assign               o22 = 1'b0;
  assign               o23 = 1'b0;
  assign               o24 = 1'b0;
  assign               o25 = 1'b0;
  assign               o26 = 1'b0;
  assign               o27 = 1'b0;
  assign               o28 = 1'b0;
  assign               o29 = 1'b0;
endmodule


