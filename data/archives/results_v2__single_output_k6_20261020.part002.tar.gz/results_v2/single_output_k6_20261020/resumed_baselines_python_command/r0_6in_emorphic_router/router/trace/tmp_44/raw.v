// Benchmark "/tmp/" written by ABC on Tue Oct 20 18:11:49 2026

module \/tmp/  ( 
    p46, p40, p23, p26, p58, p43, p34, p11, p35, p33, p27, p30, p54, p10,
    p19, p5, p50, p38, p18, p42, p9, p45, p41, p49, p48, p32, p0, p51, p16,
    p59, p8, p57, p1, p53, p21, p2, p17, p36, p3, p47, p55, p25, p15, p12,
    p37, p44, p52, p22, p14, p7, p24, p31, p4, p13, p29, p20, p6, p56, p39,
    p28,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25, o26, o27, o28, o29  );
  input  p46, p40, p23, p26, p58, p43, p34, p11, p35, p33, p27, p30, p54,
    p10, p19, p5, p50, p38, p18, p42, p9, p45, p41, p49, p48, p32, p0, p51,
    p16, p59, p8, p57, p1, p53, p21, p2, p17, p36, p3, p47, p55, p25, p15,
    p12, p37, p44, p52, p22, p14, p7, p24, p31, p4, p13, p29, p20, p6, p56,
    p39, p28;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25, o26, o27, o28, o29;
  wire new_n91_, new_n92_, new_n93_, new_n94_, new_n95_, new_n96_, new_n97_,
    new_n98_, new_n99_, new_n100_, new_n101_, new_n102_, new_n103_,
    new_n104_, new_n105_, new_n106_, new_n107_, new_n108_, new_n109_,
    new_n110_, new_n111_, new_n112_, new_n113_, new_n114_, new_n115_,
    new_n116_, new_n117_, new_n118_, new_n119_, new_n120_, new_n121_,
    new_n122_, new_n123_, new_n124_, new_n125_, new_n126_, new_n127_,
    new_n128_, new_n129_, new_n130_, new_n131_, new_n132_, new_n133_,
    new_n134_, new_n135_, new_n136_, new_n137_, new_n138_, new_n139_,
    new_n140_, new_n141_, new_n142_, new_n144_, new_n145_, new_n146_,
    new_n147_, new_n148_, new_n149_, new_n150_, new_n151_, new_n152_,
    new_n153_, new_n154_, new_n155_, new_n156_, new_n157_, new_n158_,
    new_n159_, new_n160_, new_n161_, new_n162_, new_n163_, new_n164_,
    new_n165_, new_n166_, new_n167_, new_n168_, new_n169_, new_n170_,
    new_n171_, new_n172_, new_n173_, new_n174_, new_n175_, new_n176_,
    new_n177_, new_n178_, new_n179_, new_n180_, new_n181_, new_n182_,
    new_n183_, new_n184_, new_n185_, new_n186_, new_n187_, new_n188_,
    new_n189_, new_n190_, new_n191_, new_n192_, new_n193_, new_n194_,
    new_n195_, new_n196_, new_n197_, new_n198_, new_n199_, new_n200_,
    new_n201_, new_n202_, new_n203_, new_n204_, new_n205_, new_n206_,
    new_n207_, new_n208_, new_n209_, new_n210_, new_n211_, new_n212_,
    new_n213_, new_n214_, new_n215_, new_n216_, new_n217_, new_n218_,
    new_n219_, new_n220_, new_n221_, new_n222_, new_n224_, new_n225_,
    new_n226_, new_n227_, new_n228_, new_n229_, new_n230_, new_n231_,
    new_n232_, new_n233_, new_n234_, new_n235_, new_n236_, new_n237_,
    new_n238_, new_n239_, new_n240_, new_n241_, new_n242_, new_n243_,
    new_n244_, new_n245_;
  NAND3x1_ASAP7_75t_R  g000(.A(p26), .B(p27), .C(p28), .Y(new_n91_));
  INVx1_ASAP7_75t_R    g001(.A(new_n91_), .Y(new_n92_));
  NOR2x1_ASAP7_75t_R   g002(.A(p21), .B(p20), .Y(new_n93_));
  NOR2x1_ASAP7_75t_R   g003(.A(p11), .B(p12), .Y(new_n94_));
  OAI21x1_ASAP7_75t_R  g004(.A1(p9), .A2(p8), .B(p10), .Y(new_n95_));
  NAND2x1_ASAP7_75t_R  g005(.A(p14), .B(p13), .Y(new_n96_));
  AOI21x1_ASAP7_75t_R  g006(.A1(new_n94_), .A2(new_n95_), .B(new_n96_), .Y(new_n97_));
  AO21x1_ASAP7_75t_R   g007(.A1(p16), .A2(p15), .B(p17), .Y(new_n98_));
  AOI21x1_ASAP7_75t_R  g008(.A1(p16), .A2(new_n97_), .B(new_n98_), .Y(new_n99_));
  AND2x2_ASAP7_75t_R   g009(.A(p23), .B(p24), .Y(new_n100_));
  INVx1_ASAP7_75t_R    g010(.A(new_n100_), .Y(new_n101_));
  AND2x2_ASAP7_75t_R   g011(.A(p19), .B(p18), .Y(new_n102_));
  INVx1_ASAP7_75t_R    g012(.A(new_n93_), .Y(new_n103_));
  OAI21x1_ASAP7_75t_R  g013(.A1(new_n102_), .A2(new_n103_), .B(p22), .Y(new_n104_));
  AOI211x1_ASAP7_75t_R g014(.A1(new_n93_), .A2(new_n99_), .B(new_n101_), .C(new_n104_), .Y(new_n105_));
  INVx1_ASAP7_75t_R    g015(.A(p25), .Y(new_n106_));
  NOR2x1_ASAP7_75t_R   g016(.A(new_n106_), .B(new_n91_), .Y(new_n107_));
  AO21x1_ASAP7_75t_R   g017(.A1(new_n92_), .A2(new_n105_), .B(new_n107_), .Y(new_n108_));
  OA21x2_ASAP7_75t_R   g018(.A1(p15), .A2(new_n97_), .B(p16), .Y(new_n109_));
  AND3x1_ASAP7_75t_R   g019(.A(new_n93_), .B(p19), .C(p22), .Y(new_n110_));
  INVx1_ASAP7_75t_R    g020(.A(p7), .Y(new_n111_));
  INVx1_ASAP7_75t_R    g021(.A(p4), .Y(new_n112_));
  INVx1_ASAP7_75t_R    g022(.A(p6), .Y(new_n113_));
  AND5x1_ASAP7_75t_R   g023(.A(new_n106_), .B(new_n110_), .C(new_n111_), .D(new_n112_), .E(new_n113_), .Y(new_n114_));
  NAND2x1_ASAP7_75t_R  g024(.A(p15), .B(new_n97_), .Y(new_n115_));
  INVx1_ASAP7_75t_R    g025(.A(new_n96_), .Y(new_n116_));
  INVx1_ASAP7_75t_R    g026(.A(p5), .Y(new_n117_));
  AND5x1_ASAP7_75t_R   g027(.A(p10), .B(new_n116_), .C(new_n117_), .D(new_n100_), .E(new_n94_), .Y(new_n118_));
  OR4x2_ASAP7_75t_R    g028(.A(p1), .B(p2), .C(p17), .D(p3), .Y(new_n119_));
  INVx1_ASAP7_75t_R    g029(.A(p18), .Y(new_n120_));
  INVx1_ASAP7_75t_R    g030(.A(p8), .Y(new_n121_));
  OR4x2_ASAP7_75t_R    g031(.A(new_n120_), .B(new_n121_), .C(p9), .D(p0), .Y(new_n122_));
  NOR2x1_ASAP7_75t_R   g032(.A(new_n119_), .B(new_n122_), .Y(new_n123_));
  AND5x1_ASAP7_75t_R   g033(.A(new_n109_), .B(new_n114_), .C(new_n115_), .D(new_n118_), .E(new_n123_), .Y(new_n124_));
  INVx1_ASAP7_75t_R    g034(.A(new_n124_), .Y(new_n125_));
  AO21x1_ASAP7_75t_R   g035(.A1(p22), .A2(new_n103_), .B(p23), .Y(new_n126_));
  AO21x1_ASAP7_75t_R   g036(.A1(p16), .A2(new_n97_), .B(new_n98_), .Y(new_n127_));
  INVx1_ASAP7_75t_R    g037(.A(p9), .Y(new_n128_));
  AND3x1_ASAP7_75t_R   g038(.A(new_n94_), .B(new_n128_), .C(new_n121_), .Y(new_n129_));
  NAND3x1_ASAP7_75t_R  g039(.A(p4), .B(p13), .C(p6), .Y(new_n130_));
  NOR2x1_ASAP7_75t_R   g040(.A(new_n91_), .B(new_n130_), .Y(new_n131_));
  NAND3x1_ASAP7_75t_R  g041(.A(new_n129_), .B(new_n110_), .C(new_n131_), .Y(new_n132_));
  NAND2x1_ASAP7_75t_R  g042(.A(p10), .B(p5), .Y(new_n133_));
  NAND2x1_ASAP7_75t_R  g043(.A(p18), .B(p0), .Y(new_n134_));
  NAND2x1_ASAP7_75t_R  g044(.A(p16), .B(p59), .Y(new_n135_));
  NOR3x1_ASAP7_75t_R   g045(.A(new_n133_), .B(new_n134_), .C(new_n135_), .Y(new_n136_));
  AND4x2_ASAP7_75t_R   g046(.A(new_n106_), .B(p1), .C(p2), .D(p3), .Y(new_n137_));
  INVx1_ASAP7_75t_R    g047(.A(p15), .Y(new_n138_));
  AND4x2_ASAP7_75t_R   g048(.A(new_n138_), .B(p14), .C(p7), .D(p24), .Y(new_n139_));
  NAND3x1_ASAP7_75t_R  g049(.A(new_n136_), .B(new_n137_), .C(new_n139_), .Y(new_n140_));
  NOR3x1_ASAP7_75t_R   g050(.A(new_n127_), .B(new_n132_), .C(new_n140_), .Y(new_n141_));
  AOI221x1_ASAP7_75t_R g051(.A1(new_n126_), .A2(new_n141_), .B1(new_n105_), .B2(new_n92_), .C(new_n107_), .Y(new_n142_));
  AO21x1_ASAP7_75t_R   g052(.A1(new_n108_), .A2(new_n125_), .B(new_n142_), .Y(o0));
  INVx1_ASAP7_75t_R    g053(.A(new_n107_), .Y(new_n144_));
  AOI21x1_ASAP7_75t_R  g054(.A1(new_n93_), .A2(new_n99_), .B(new_n104_), .Y(new_n145_));
  NAND3x1_ASAP7_75t_R  g055(.A(new_n145_), .B(new_n92_), .C(new_n100_), .Y(new_n146_));
  AOI21x1_ASAP7_75t_R  g056(.A1(new_n144_), .A2(new_n146_), .B(new_n124_), .Y(new_n147_));
  NAND2x1_ASAP7_75t_R  g057(.A(p49), .B(p48), .Y(new_n148_));
  NOR2x1_ASAP7_75t_R   g058(.A(p42), .B(p41), .Y(new_n149_));
  OAI21x1_ASAP7_75t_R  g059(.A1(p38), .A2(p39), .B(p40), .Y(new_n150_));
  NAND2x1_ASAP7_75t_R  g060(.A(p43), .B(p44), .Y(new_n151_));
  AOI21x1_ASAP7_75t_R  g061(.A1(new_n149_), .A2(new_n150_), .B(new_n151_), .Y(new_n152_));
  AO21x1_ASAP7_75t_R   g062(.A1(p46), .A2(p45), .B(p47), .Y(new_n153_));
  AOI21x1_ASAP7_75t_R  g063(.A1(p46), .A2(new_n152_), .B(new_n153_), .Y(new_n154_));
  INVx1_ASAP7_75t_R    g064(.A(p51), .Y(new_n155_));
  NAND2x1_ASAP7_75t_R  g065(.A(p52), .B(new_n155_), .Y(new_n156_));
  OAI21x1_ASAP7_75t_R  g066(.A1(new_n148_), .A2(new_n154_), .B(new_n156_), .Y(new_n157_));
  INVx1_ASAP7_75t_R    g067(.A(p43), .Y(new_n158_));
  AO21x1_ASAP7_75t_R   g068(.A1(new_n149_), .A2(new_n150_), .B(new_n158_), .Y(new_n159_));
  AND3x1_ASAP7_75t_R   g069(.A(p58), .B(p57), .C(p56), .Y(new_n160_));
  AND2x2_ASAP7_75t_R   g070(.A(p37), .B(p44), .Y(new_n161_));
  AND2x2_ASAP7_75t_R   g071(.A(p31), .B(p29), .Y(new_n162_));
  AND2x2_ASAP7_75t_R   g072(.A(p32), .B(p36), .Y(new_n163_));
  NOR2x1_ASAP7_75t_R   g073(.A(p47), .B(p55), .Y(new_n164_));
  AND5x1_ASAP7_75t_R   g074(.A(new_n160_), .B(new_n161_), .C(new_n162_), .D(new_n163_), .E(new_n164_), .Y(new_n165_));
  INVx1_ASAP7_75t_R    g075(.A(p33), .Y(new_n166_));
  NOR2x1_ASAP7_75t_R   g076(.A(p45), .B(new_n166_), .Y(new_n167_));
  AND4x2_ASAP7_75t_R   g077(.A(p46), .B(p40), .C(p34), .D(p35), .Y(new_n168_));
  AND2x2_ASAP7_75t_R   g078(.A(p30), .B(p49), .Y(new_n169_));
  AND3x1_ASAP7_75t_R   g079(.A(new_n167_), .B(new_n168_), .C(new_n169_), .Y(new_n170_));
  NAND2x1_ASAP7_75t_R  g080(.A(p42), .B(p41), .Y(new_n171_));
  OAI21x1_ASAP7_75t_R  g081(.A1(new_n171_), .A2(new_n150_), .B(new_n158_), .Y(new_n172_));
  INVx1_ASAP7_75t_R    g082(.A(p48), .Y(new_n173_));
  INVx1_ASAP7_75t_R    g083(.A(p47), .Y(new_n174_));
  NAND2x1_ASAP7_75t_R  g084(.A(p54), .B(p53), .Y(new_n175_));
  NOR2x1_ASAP7_75t_R   g085(.A(p38), .B(p39), .Y(new_n176_));
  INVx1_ASAP7_75t_R    g086(.A(new_n176_), .Y(new_n177_));
  AOI211x1_ASAP7_75t_R g087(.A1(new_n173_), .A2(new_n174_), .B(new_n175_), .C(new_n177_), .Y(new_n178_));
  AND5x1_ASAP7_75t_R   g088(.A(new_n159_), .B(new_n165_), .C(new_n170_), .D(new_n172_), .E(new_n178_), .Y(new_n179_));
  NAND2x1_ASAP7_75t_R  g089(.A(new_n157_), .B(new_n179_), .Y(new_n180_));
  AND3x1_ASAP7_75t_R   g090(.A(p54), .B(p53), .C(p52), .Y(new_n181_));
  OA21x2_ASAP7_75t_R   g091(.A1(p55), .A2(new_n181_), .B(new_n160_), .Y(new_n182_));
  INVx1_ASAP7_75t_R    g092(.A(p55), .Y(new_n183_));
  NOR2x1_ASAP7_75t_R   g093(.A(p50), .B(p51), .Y(new_n184_));
  AND2x2_ASAP7_75t_R   g094(.A(new_n183_), .B(new_n184_), .Y(new_n185_));
  OAI21x1_ASAP7_75t_R  g095(.A1(new_n148_), .A2(new_n154_), .B(new_n185_), .Y(new_n186_));
  NOR2x1_ASAP7_75t_R   g096(.A(p50), .B(p59), .Y(new_n187_));
  AOI21x1_ASAP7_75t_R  g097(.A1(new_n182_), .A2(new_n186_), .B(new_n187_), .Y(new_n188_));
  NOR2x1_ASAP7_75t_R   g098(.A(p42), .B(p45), .Y(new_n189_));
  INVx1_ASAP7_75t_R    g099(.A(p36), .Y(new_n190_));
  AND3x1_ASAP7_75t_R   g100(.A(new_n189_), .B(p38), .C(new_n190_), .Y(new_n191_));
  NOR2x1_ASAP7_75t_R   g101(.A(p37), .B(p39), .Y(new_n192_));
  AND3x1_ASAP7_75t_R   g102(.A(new_n192_), .B(new_n183_), .C(p56), .Y(new_n193_));
  INVx1_ASAP7_75t_R    g103(.A(p40), .Y(new_n194_));
  NOR3x1_ASAP7_75t_R   g104(.A(new_n151_), .B(new_n194_), .C(p50), .Y(new_n195_));
  AND3x1_ASAP7_75t_R   g105(.A(new_n191_), .B(new_n193_), .C(new_n195_), .Y(new_n196_));
  INVx1_ASAP7_75t_R    g106(.A(p41), .Y(new_n197_));
  NOR2x1_ASAP7_75t_R   g107(.A(p34), .B(p35), .Y(new_n198_));
  AND2x2_ASAP7_75t_R   g108(.A(p54), .B(p53), .Y(new_n199_));
  NAND2x1_ASAP7_75t_R  g109(.A(new_n198_), .B(new_n199_), .Y(new_n200_));
  NAND2x1_ASAP7_75t_R  g110(.A(p46), .B(p47), .Y(new_n201_));
  AND2x2_ASAP7_75t_R   g111(.A(p49), .B(p48), .Y(new_n202_));
  NAND2x1_ASAP7_75t_R  g112(.A(new_n201_), .B(new_n202_), .Y(new_n203_));
  AOI211x1_ASAP7_75t_R g113(.A1(new_n197_), .A2(new_n150_), .B(new_n200_), .C(new_n203_), .Y(new_n204_));
  NOR2x1_ASAP7_75t_R   g114(.A(new_n197_), .B(new_n150_), .Y(new_n205_));
  OR4x2_ASAP7_75t_R    g115(.A(p33), .B(p30), .C(p32), .D(p31), .Y(new_n206_));
  NOR3x1_ASAP7_75t_R   g116(.A(new_n205_), .B(new_n206_), .C(new_n156_), .Y(new_n207_));
  NAND3x1_ASAP7_75t_R  g117(.A(new_n196_), .B(new_n204_), .C(new_n207_), .Y(new_n208_));
  OR2x4_ASAP7_75t_R    g118(.A(p45), .B(new_n174_), .Y(new_n209_));
  NOR2x1_ASAP7_75t_R   g119(.A(new_n152_), .B(new_n209_), .Y(new_n210_));
  AND2x2_ASAP7_75t_R   g120(.A(p46), .B(p45), .Y(new_n211_));
  AO21x1_ASAP7_75t_R   g121(.A1(p46), .A2(new_n152_), .B(new_n211_), .Y(new_n212_));
  NOR2x1_ASAP7_75t_R   g122(.A(p59), .B(p29), .Y(new_n213_));
  OAI21x1_ASAP7_75t_R  g123(.A1(new_n210_), .A2(new_n212_), .B(new_n213_), .Y(new_n214_));
  INVx1_ASAP7_75t_R    g124(.A(p46), .Y(new_n215_));
  AOI211x1_ASAP7_75t_R g125(.A1(new_n149_), .A2(new_n150_), .B(new_n215_), .C(new_n151_), .Y(new_n216_));
  OAI21x1_ASAP7_75t_R  g126(.A1(new_n153_), .A2(new_n216_), .B(new_n202_), .Y(new_n217_));
  INVx1_ASAP7_75t_R    g127(.A(new_n182_), .Y(new_n218_));
  AOI21x1_ASAP7_75t_R  g128(.A1(new_n185_), .A2(new_n217_), .B(new_n218_), .Y(new_n219_));
  OAI21x1_ASAP7_75t_R  g129(.A1(new_n208_), .A2(new_n214_), .B(new_n219_), .Y(new_n220_));
  OAI21x1_ASAP7_75t_R  g130(.A1(new_n180_), .A2(new_n188_), .B(new_n220_), .Y(new_n221_));
  AO221x2_ASAP7_75t_R  g131(.A1(new_n141_), .A2(new_n126_), .B1(new_n92_), .B2(new_n105_), .C(new_n107_), .Y(new_n222_));
  OAI21x1_ASAP7_75t_R  g132(.A1(new_n147_), .A2(new_n221_), .B(new_n222_), .Y(o1));
  NAND2x1_ASAP7_75t_R  g133(.A(new_n197_), .B(new_n150_), .Y(new_n224_));
  INVx1_ASAP7_75t_R    g134(.A(p32), .Y(new_n225_));
  NOR2x1_ASAP7_75t_R   g135(.A(p30), .B(p31), .Y(new_n226_));
  AND5x1_ASAP7_75t_R   g136(.A(new_n166_), .B(new_n199_), .C(new_n225_), .D(new_n198_), .E(new_n226_), .Y(new_n227_));
  INVx1_ASAP7_75t_R    g137(.A(new_n205_), .Y(new_n228_));
  NOR2x1_ASAP7_75t_R   g138(.A(new_n148_), .B(new_n156_), .Y(new_n229_));
  AND5x1_ASAP7_75t_R   g139(.A(new_n224_), .B(new_n227_), .C(new_n228_), .D(new_n201_), .E(new_n229_), .Y(new_n230_));
  NOR2x1_ASAP7_75t_R   g140(.A(p45), .B(new_n152_), .Y(new_n231_));
  OAI22x1_ASAP7_75t_R  g141(.A1(new_n231_), .A2(new_n215_), .B1(new_n152_), .B2(new_n209_), .Y(new_n232_));
  NOR2x1_ASAP7_75t_R   g142(.A(p50), .B(p45), .Y(new_n233_));
  AND3x1_ASAP7_75t_R   g143(.A(new_n233_), .B(new_n183_), .C(p56), .Y(new_n234_));
  NOR3x1_ASAP7_75t_R   g144(.A(new_n151_), .B(new_n194_), .C(p42), .Y(new_n235_));
  INVx1_ASAP7_75t_R    g145(.A(p38), .Y(new_n236_));
  NOR2x1_ASAP7_75t_R   g146(.A(p39), .B(new_n236_), .Y(new_n237_));
  NOR2x1_ASAP7_75t_R   g147(.A(p36), .B(p37), .Y(new_n238_));
  NAND2x1_ASAP7_75t_R  g148(.A(p59), .B(p29), .Y(new_n239_));
  AND5x1_ASAP7_75t_R   g149(.A(new_n234_), .B(new_n235_), .C(new_n237_), .D(new_n238_), .E(new_n239_), .Y(new_n240_));
  NAND3x1_ASAP7_75t_R  g150(.A(new_n230_), .B(new_n232_), .C(new_n240_), .Y(new_n241_));
  INVx1_ASAP7_75t_R    g151(.A(new_n181_), .Y(new_n242_));
  OA21x2_ASAP7_75t_R   g152(.A1(new_n184_), .A2(new_n242_), .B(new_n183_), .Y(new_n243_));
  OAI21x1_ASAP7_75t_R  g153(.A1(new_n242_), .A2(new_n217_), .B(new_n243_), .Y(new_n244_));
  NAND3x1_ASAP7_75t_R  g154(.A(new_n241_), .B(new_n160_), .C(new_n244_), .Y(new_n245_));
  AOI211x1_ASAP7_75t_R g155(.A1(new_n125_), .A2(new_n108_), .B(new_n142_), .C(new_n245_), .Y(o2));
  assign               o3 = 1'b0;
  assign               o4 = 1'b0;
  assign               o5 = 1'b0;
  assign               o6 = 1'b0;
  assign               o7 = 1'b0;
  assign               o8 = 1'b0;
  assign               o9 = 1'b0;
  assign               o10 = 1'b0;
  assign               o11 = 1'b0;
  assign               o12 = 1'b0;
  assign               o13 = 1'b0;
  assign               o14 = 1'b0;
  assign               o15 = 1'b0;
  assign               o16 = 1'b0;
  assign               o17 = 1'b0;
  assign               o18 = 1'b0;
  assign               o19 = 1'b0;
  assign               o20 = 1'b0;
  assign               o21 = 1'b0;
  assign               o22 = 1'b0;
  assign               o23 = 1'b0;
  assign               o24 = 1'b0;
  assign               o25 = 1'b0;
  assign               o26 = 1'b0;
  assign               o27 = 1'b0;
  assign               o28 = 1'b0;
  assign               o29 = 1'b0;
endmodule


