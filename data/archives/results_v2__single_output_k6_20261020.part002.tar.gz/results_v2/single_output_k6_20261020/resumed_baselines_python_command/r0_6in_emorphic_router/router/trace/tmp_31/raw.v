// Benchmark "/tmp/" written by ABC on Tue Oct 20 18:11:47 2026

module \/tmp/  ( 
    p27, p2, p11, p52, p47, p30, p59, p28, p9, p4, p46, p6, p54, p42, p18,
    p10, p55, p41, p7, p21, p0, p13, p20, p34, p24, p36, p23, p45, p5, p31,
    p14, p32, p37, p22, p16, p12, p19, p15, p56, p53, p17, p1, p43, p29,
    p25, p35, p38, p40, p50, p8, p44, p3, p48, p39, p57, p58, p51, p26,
    p49, p33,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25, o26, o27, o28, o29  );
  input  p27, p2, p11, p52, p47, p30, p59, p28, p9, p4, p46, p6, p54,
    p42, p18, p10, p55, p41, p7, p21, p0, p13, p20, p34, p24, p36, p23,
    p45, p5, p31, p14, p32, p37, p22, p16, p12, p19, p15, p56, p53, p17,
    p1, p43, p29, p25, p35, p38, p40, p50, p8, p44, p3, p48, p39, p57, p58,
    p51, p26, p49, p33;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25, o26, o27, o28, o29;
  wire new_n91_, new_n92_, new_n93_, new_n94_, new_n95_, new_n96_, new_n97_,
    new_n98_, new_n99_, new_n100_, new_n101_, new_n102_, new_n103_,
    new_n104_, new_n105_, new_n106_, new_n107_, new_n108_, new_n109_,
    new_n110_, new_n111_, new_n112_, new_n113_, new_n114_, new_n115_,
    new_n116_, new_n117_, new_n118_, new_n119_, new_n120_, new_n121_,
    new_n122_, new_n123_, new_n124_, new_n125_, new_n126_, new_n127_,
    new_n128_, new_n129_, new_n130_, new_n131_, new_n132_, new_n133_,
    new_n134_, new_n135_, new_n136_, new_n137_, new_n138_, new_n139_,
    new_n140_, new_n141_, new_n142_, new_n144_, new_n145_, new_n146_,
    new_n147_, new_n148_, new_n149_, new_n150_, new_n151_, new_n152_,
    new_n153_, new_n154_, new_n155_, new_n156_, new_n157_, new_n158_,
    new_n159_, new_n160_, new_n161_, new_n162_, new_n163_, new_n164_,
    new_n165_, new_n166_, new_n167_, new_n168_, new_n169_, new_n170_,
    new_n171_, new_n172_, new_n173_, new_n174_, new_n175_, new_n176_,
    new_n177_, new_n178_, new_n179_, new_n180_, new_n181_, new_n182_,
    new_n183_, new_n184_, new_n185_, new_n186_, new_n187_, new_n188_,
    new_n189_, new_n190_, new_n191_, new_n192_, new_n193_, new_n194_,
    new_n195_, new_n196_, new_n197_, new_n198_, new_n199_, new_n200_,
    new_n201_, new_n202_, new_n203_, new_n204_, new_n205_, new_n206_,
    new_n207_, new_n208_, new_n210_, new_n211_, new_n212_, new_n213_,
    new_n214_, new_n215_, new_n216_, new_n217_, new_n218_, new_n219_,
    new_n220_, new_n221_, new_n222_, new_n223_, new_n224_, new_n225_,
    new_n226_, new_n227_, new_n228_, new_n229_, new_n230_, new_n231_,
    new_n232_, new_n233_, new_n234_, new_n235_, new_n236_, new_n237_,
    new_n238_, new_n239_, new_n240_, new_n241_, new_n242_, new_n243_;
  NOR2x1_ASAP7_75t_R   g000(.A(p11), .B(p12), .Y(new_n91_));
  OAI21x1_ASAP7_75t_R  g001(.A1(p9), .A2(p8), .B(p10), .Y(new_n92_));
  NAND2x1_ASAP7_75t_R  g002(.A(p13), .B(p14), .Y(new_n93_));
  AO21x1_ASAP7_75t_R   g003(.A1(new_n91_), .A2(new_n92_), .B(new_n93_), .Y(new_n94_));
  NOR2x1_ASAP7_75t_R   g004(.A(p16), .B(p15), .Y(new_n95_));
  AND3x1_ASAP7_75t_R   g005(.A(p27), .B(p28), .C(p26), .Y(new_n96_));
  INVx1_ASAP7_75t_R    g006(.A(new_n96_), .Y(new_n97_));
  INVx1_ASAP7_75t_R    g007(.A(p15), .Y(new_n98_));
  INVx1_ASAP7_75t_R    g008(.A(p25), .Y(new_n99_));
  AND3x1_ASAP7_75t_R   g009(.A(new_n98_), .B(new_n99_), .C(p14), .Y(new_n100_));
  AND3x1_ASAP7_75t_R   g010(.A(new_n91_), .B(p18), .C(p24), .Y(new_n101_));
  NAND2x1_ASAP7_75t_R  g011(.A(new_n100_), .B(new_n101_), .Y(new_n102_));
  AOI211x1_ASAP7_75t_R g012(.A1(new_n94_), .A2(new_n95_), .B(new_n97_), .C(new_n102_), .Y(new_n103_));
  NAND3x1_ASAP7_75t_R  g013(.A(new_n92_), .B(new_n91_), .C(p13), .Y(new_n104_));
  AO21x1_ASAP7_75t_R   g014(.A1(new_n91_), .A2(new_n92_), .B(p13), .Y(new_n105_));
  INVx1_ASAP7_75t_R    g015(.A(p16), .Y(new_n106_));
  AOI211x1_ASAP7_75t_R g016(.A1(new_n91_), .A2(new_n92_), .B(new_n106_), .C(new_n93_), .Y(new_n107_));
  AO21x1_ASAP7_75t_R   g017(.A1(p16), .A2(p15), .B(p17), .Y(new_n108_));
  AOI211x1_ASAP7_75t_R g018(.A1(new_n104_), .A2(new_n105_), .B(new_n107_), .C(new_n108_), .Y(new_n109_));
  NOR2x1_ASAP7_75t_R   g019(.A(p21), .B(p20), .Y(new_n110_));
  AND3x1_ASAP7_75t_R   g020(.A(new_n110_), .B(p22), .C(p19), .Y(new_n111_));
  NOR2x1_ASAP7_75t_R   g021(.A(p9), .B(p8), .Y(new_n112_));
  AND3x1_ASAP7_75t_R   g022(.A(new_n112_), .B(p2), .C(p59), .Y(new_n113_));
  AND3x1_ASAP7_75t_R   g023(.A(p0), .B(p5), .C(p1), .Y(new_n114_));
  AND4x2_ASAP7_75t_R   g024(.A(p4), .B(p6), .C(p10), .D(p7), .Y(new_n115_));
  AND5x1_ASAP7_75t_R   g025(.A(p3), .B(new_n111_), .C(new_n113_), .D(new_n114_), .E(new_n115_), .Y(new_n116_));
  NAND3x1_ASAP7_75t_R  g026(.A(new_n103_), .B(new_n109_), .C(new_n116_), .Y(new_n117_));
  INVx1_ASAP7_75t_R    g027(.A(new_n110_), .Y(new_n118_));
  NAND2x1_ASAP7_75t_R  g028(.A(p18), .B(p19), .Y(new_n119_));
  INVx1_ASAP7_75t_R    g029(.A(p22), .Y(new_n120_));
  AOI21x1_ASAP7_75t_R  g030(.A1(new_n119_), .A2(new_n110_), .B(new_n120_), .Y(new_n121_));
  OA31x2_ASAP7_75t_R   g031(.A1(new_n118_), .A2(new_n108_), .A3(new_n107_), .B1(new_n121_), .Y(new_n122_));
  NOR2x1_ASAP7_75t_R   g032(.A(p23), .B(new_n122_), .Y(new_n123_));
  AND2x2_ASAP7_75t_R   g033(.A(p24), .B(p23), .Y(new_n124_));
  AOI21x1_ASAP7_75t_R  g034(.A1(new_n124_), .A2(new_n122_), .B(p25), .Y(new_n125_));
  OAI22x1_ASAP7_75t_R  g035(.A1(new_n117_), .A2(new_n123_), .B1(new_n125_), .B2(new_n97_), .Y(new_n126_));
  AO21x1_ASAP7_75t_R   g036(.A1(p16), .A2(p15), .B(new_n107_), .Y(new_n127_));
  INVx1_ASAP7_75t_R    g037(.A(p1), .Y(new_n128_));
  INVx1_ASAP7_75t_R    g038(.A(p3), .Y(new_n129_));
  AND5x1_ASAP7_75t_R   g039(.A(new_n128_), .B(new_n111_), .C(new_n99_), .D(p8), .E(new_n129_), .Y(new_n130_));
  AO21x1_ASAP7_75t_R   g040(.A1(new_n91_), .A2(new_n92_), .B(new_n98_), .Y(new_n131_));
  AND2x2_ASAP7_75t_R   g041(.A(p18), .B(p10), .Y(new_n132_));
  NOR2x1_ASAP7_75t_R   g042(.A(p2), .B(p11), .Y(new_n133_));
  AND5x1_ASAP7_75t_R   g043(.A(p13), .B(new_n124_), .C(new_n132_), .D(p14), .E(new_n133_), .Y(new_n134_));
  INVx1_ASAP7_75t_R    g044(.A(p9), .Y(new_n135_));
  NOR2x1_ASAP7_75t_R   g045(.A(p12), .B(p17), .Y(new_n136_));
  NOR2x1_ASAP7_75t_R   g046(.A(p0), .B(p5), .Y(new_n137_));
  NOR2x1_ASAP7_75t_R   g047(.A(p6), .B(p7), .Y(new_n138_));
  INVx1_ASAP7_75t_R    g048(.A(p4), .Y(new_n139_));
  AND5x1_ASAP7_75t_R   g049(.A(new_n135_), .B(new_n136_), .C(new_n137_), .D(new_n138_), .E(new_n139_), .Y(new_n140_));
  AND5x1_ASAP7_75t_R   g050(.A(new_n127_), .B(new_n130_), .C(new_n131_), .D(new_n134_), .E(new_n140_), .Y(new_n141_));
  OR3x1_ASAP7_75t_R    g051(.A(new_n141_), .B(new_n125_), .C(new_n97_), .Y(new_n142_));
  NAND2x1_ASAP7_75t_R  g052(.A(new_n126_), .B(new_n142_), .Y(o0));
  AND2x2_ASAP7_75t_R   g053(.A(p43), .B(p44), .Y(new_n144_));
  AND2x2_ASAP7_75t_R   g054(.A(p48), .B(p49), .Y(new_n145_));
  AND3x1_ASAP7_75t_R   g055(.A(p56), .B(p57), .C(p58), .Y(new_n146_));
  AND2x2_ASAP7_75t_R   g056(.A(p29), .B(p35), .Y(new_n147_));
  AND2x2_ASAP7_75t_R   g057(.A(p40), .B(p33), .Y(new_n148_));
  AND5x1_ASAP7_75t_R   g058(.A(new_n144_), .B(new_n145_), .C(new_n146_), .D(new_n147_), .E(new_n148_), .Y(new_n149_));
  NOR2x1_ASAP7_75t_R   g059(.A(p42), .B(p41), .Y(new_n150_));
  OAI21x1_ASAP7_75t_R  g060(.A1(p38), .A2(p39), .B(p40), .Y(new_n151_));
  INVx1_ASAP7_75t_R    g061(.A(p43), .Y(new_n152_));
  AO21x1_ASAP7_75t_R   g062(.A1(new_n150_), .A2(new_n151_), .B(new_n152_), .Y(new_n153_));
  AND2x2_ASAP7_75t_R   g063(.A(p32), .B(p37), .Y(new_n154_));
  INVx1_ASAP7_75t_R    g064(.A(p45), .Y(new_n155_));
  AND3x1_ASAP7_75t_R   g065(.A(new_n154_), .B(new_n155_), .C(p31), .Y(new_n156_));
  INVx1_ASAP7_75t_R    g066(.A(p47), .Y(new_n157_));
  NOR2x1_ASAP7_75t_R   g067(.A(p38), .B(p39), .Y(new_n158_));
  AND5x1_ASAP7_75t_R   g068(.A(new_n157_), .B(new_n158_), .C(p30), .D(p54), .E(p53), .Y(new_n159_));
  AND2x2_ASAP7_75t_R   g069(.A(p34), .B(p36), .Y(new_n160_));
  INVx1_ASAP7_75t_R    g070(.A(p55), .Y(new_n161_));
  AND3x1_ASAP7_75t_R   g071(.A(new_n160_), .B(p46), .C(new_n161_), .Y(new_n162_));
  AND5x1_ASAP7_75t_R   g072(.A(new_n149_), .B(new_n153_), .C(new_n156_), .D(new_n159_), .E(new_n162_), .Y(new_n163_));
  INVx1_ASAP7_75t_R    g073(.A(p51), .Y(new_n164_));
  NAND2x1_ASAP7_75t_R  g074(.A(p52), .B(new_n164_), .Y(new_n165_));
  AO21x1_ASAP7_75t_R   g075(.A1(p46), .A2(p45), .B(p47), .Y(new_n166_));
  INVx1_ASAP7_75t_R    g076(.A(p46), .Y(new_n167_));
  NAND2x1_ASAP7_75t_R  g077(.A(p43), .B(p44), .Y(new_n168_));
  AOI211x1_ASAP7_75t_R g078(.A1(new_n150_), .A2(new_n151_), .B(new_n167_), .C(new_n168_), .Y(new_n169_));
  OAI21x1_ASAP7_75t_R  g079(.A1(new_n166_), .A2(new_n169_), .B(new_n145_), .Y(new_n170_));
  NAND2x1_ASAP7_75t_R  g080(.A(new_n165_), .B(new_n170_), .Y(new_n171_));
  NAND2x1_ASAP7_75t_R  g081(.A(new_n163_), .B(new_n171_), .Y(new_n172_));
  AND3x1_ASAP7_75t_R   g082(.A(p52), .B(p54), .C(p53), .Y(new_n173_));
  OA21x2_ASAP7_75t_R   g083(.A1(p55), .A2(new_n173_), .B(new_n146_), .Y(new_n174_));
  NAND2x1_ASAP7_75t_R  g084(.A(p48), .B(p49), .Y(new_n175_));
  AOI21x1_ASAP7_75t_R  g085(.A1(new_n150_), .A2(new_n151_), .B(new_n168_), .Y(new_n176_));
  AOI21x1_ASAP7_75t_R  g086(.A1(p46), .A2(new_n176_), .B(new_n166_), .Y(new_n177_));
  INVx1_ASAP7_75t_R    g087(.A(p50), .Y(new_n178_));
  AND3x1_ASAP7_75t_R   g088(.A(new_n161_), .B(new_n178_), .C(new_n164_), .Y(new_n179_));
  OAI21x1_ASAP7_75t_R  g089(.A1(new_n175_), .A2(new_n177_), .B(new_n179_), .Y(new_n180_));
  NOR2x1_ASAP7_75t_R   g090(.A(p59), .B(p50), .Y(new_n181_));
  AOI21x1_ASAP7_75t_R  g091(.A1(new_n174_), .A2(new_n180_), .B(new_n181_), .Y(new_n182_));
  NOR2x1_ASAP7_75t_R   g092(.A(p45), .B(p37), .Y(new_n183_));
  INVx1_ASAP7_75t_R    g093(.A(p36), .Y(new_n184_));
  AND3x1_ASAP7_75t_R   g094(.A(new_n183_), .B(new_n184_), .C(p56), .Y(new_n185_));
  INVx1_ASAP7_75t_R    g095(.A(p39), .Y(new_n186_));
  AND4x2_ASAP7_75t_R   g096(.A(new_n178_), .B(new_n186_), .C(p38), .D(p40), .Y(new_n187_));
  NOR3x1_ASAP7_75t_R   g097(.A(new_n168_), .B(p42), .C(p55), .Y(new_n188_));
  AND3x1_ASAP7_75t_R   g098(.A(new_n185_), .B(new_n187_), .C(new_n188_), .Y(new_n189_));
  INVx1_ASAP7_75t_R    g099(.A(p41), .Y(new_n190_));
  NOR2x1_ASAP7_75t_R   g100(.A(p30), .B(p34), .Y(new_n191_));
  NAND3x1_ASAP7_75t_R  g101(.A(new_n191_), .B(p54), .C(p53), .Y(new_n192_));
  AO21x1_ASAP7_75t_R   g102(.A1(p47), .A2(p46), .B(new_n175_), .Y(new_n193_));
  AOI211x1_ASAP7_75t_R g103(.A1(new_n190_), .A2(new_n151_), .B(new_n192_), .C(new_n193_), .Y(new_n194_));
  NOR2x1_ASAP7_75t_R   g104(.A(new_n190_), .B(new_n151_), .Y(new_n195_));
  OR4x2_ASAP7_75t_R    g105(.A(p31), .B(p32), .C(p35), .D(p33), .Y(new_n196_));
  NOR3x1_ASAP7_75t_R   g106(.A(new_n195_), .B(new_n196_), .C(new_n165_), .Y(new_n197_));
  NAND3x1_ASAP7_75t_R  g107(.A(new_n189_), .B(new_n194_), .C(new_n197_), .Y(new_n198_));
  NOR3x1_ASAP7_75t_R   g108(.A(new_n176_), .B(new_n157_), .C(p45), .Y(new_n199_));
  AND2x2_ASAP7_75t_R   g109(.A(p46), .B(p45), .Y(new_n200_));
  AO21x1_ASAP7_75t_R   g110(.A1(p46), .A2(new_n176_), .B(new_n200_), .Y(new_n201_));
  NOR2x1_ASAP7_75t_R   g111(.A(p59), .B(p29), .Y(new_n202_));
  OAI21x1_ASAP7_75t_R  g112(.A1(new_n199_), .A2(new_n201_), .B(new_n202_), .Y(new_n203_));
  INVx1_ASAP7_75t_R    g113(.A(new_n174_), .Y(new_n204_));
  AOI21x1_ASAP7_75t_R  g114(.A1(new_n179_), .A2(new_n170_), .B(new_n204_), .Y(new_n205_));
  OAI21x1_ASAP7_75t_R  g115(.A1(new_n198_), .A2(new_n203_), .B(new_n205_), .Y(new_n206_));
  OAI21x1_ASAP7_75t_R  g116(.A1(new_n172_), .A2(new_n182_), .B(new_n206_), .Y(new_n207_));
  NOR3x1_ASAP7_75t_R   g117(.A(new_n141_), .B(new_n125_), .C(new_n97_), .Y(new_n208_));
  AOI21x1_ASAP7_75t_R  g118(.A1(new_n126_), .A2(new_n207_), .B(new_n208_), .Y(o1));
  NOR2x1_ASAP7_75t_R   g119(.A(new_n108_), .B(new_n107_), .Y(new_n210_));
  INVx1_ASAP7_75t_R    g120(.A(new_n124_), .Y(new_n211_));
  INVx1_ASAP7_75t_R    g121(.A(new_n121_), .Y(new_n212_));
  AOI211x1_ASAP7_75t_R g122(.A1(new_n110_), .A2(new_n210_), .B(new_n211_), .C(new_n212_), .Y(new_n213_));
  AND2x2_ASAP7_75t_R   g123(.A(p25), .B(new_n96_), .Y(new_n214_));
  AND3x1_ASAP7_75t_R   g124(.A(new_n91_), .B(p27), .C(p26), .Y(new_n215_));
  AND4x2_ASAP7_75t_R   g125(.A(p2), .B(p59), .C(p28), .D(p4), .Y(new_n216_));
  AND4x2_ASAP7_75t_R   g126(.A(p6), .B(p7), .C(p0), .D(p13), .Y(new_n217_));
  AND5x1_ASAP7_75t_R   g127(.A(new_n215_), .B(new_n112_), .C(new_n216_), .D(new_n132_), .E(new_n217_), .Y(new_n218_));
  AO21x1_ASAP7_75t_R   g128(.A1(p22), .A2(new_n118_), .B(p23), .Y(new_n219_));
  NAND2x1_ASAP7_75t_R  g129(.A(new_n95_), .B(new_n94_), .Y(new_n220_));
  AND3x1_ASAP7_75t_R   g130(.A(new_n99_), .B(p1), .C(p3), .Y(new_n221_));
  AND4x2_ASAP7_75t_R   g131(.A(new_n98_), .B(p24), .C(p5), .D(p14), .Y(new_n222_));
  AND3x1_ASAP7_75t_R   g132(.A(new_n111_), .B(new_n221_), .C(new_n222_), .Y(new_n223_));
  AND5x1_ASAP7_75t_R   g133(.A(new_n210_), .B(new_n218_), .C(new_n219_), .D(new_n220_), .E(new_n223_), .Y(new_n224_));
  AOI211x1_ASAP7_75t_R g134(.A1(new_n96_), .A2(new_n213_), .B(new_n214_), .C(new_n224_), .Y(new_n225_));
  AND2x2_ASAP7_75t_R   g135(.A(p59), .B(p29), .Y(new_n226_));
  OA21x2_ASAP7_75t_R   g136(.A1(p45), .A2(new_n176_), .B(new_n167_), .Y(new_n227_));
  INVx1_ASAP7_75t_R    g137(.A(p52), .Y(new_n228_));
  OR3x1_ASAP7_75t_R    g138(.A(p39), .B(p51), .C(p33), .Y(new_n229_));
  NAND2x1_ASAP7_75t_R  g139(.A(p54), .B(p53), .Y(new_n230_));
  OR5x1_ASAP7_75t_R    g140(.A(new_n228_), .B(new_n229_), .C(new_n168_), .D(new_n175_), .E(new_n230_), .Y(new_n231_));
  XOR2x2_ASAP7_75t_R   g141(.A(new_n151_), .B(p41), .Y(new_n232_));
  OR4x2_ASAP7_75t_R    g142(.A(p30), .B(p42), .C(p34), .D(p36), .Y(new_n233_));
  NAND2x1_ASAP7_75t_R  g143(.A(new_n161_), .B(new_n178_), .Y(new_n234_));
  AND2x2_ASAP7_75t_R   g144(.A(p47), .B(p46), .Y(new_n235_));
  OR3x1_ASAP7_75t_R    g145(.A(new_n233_), .B(new_n234_), .C(new_n235_), .Y(new_n236_));
  OR4x2_ASAP7_75t_R    g146(.A(p45), .B(p31), .C(p32), .D(p37), .Y(new_n237_));
  INVx1_ASAP7_75t_R    g147(.A(p35), .Y(new_n238_));
  NAND2x1_ASAP7_75t_R  g148(.A(p56), .B(new_n238_), .Y(new_n239_));
  NAND2x1_ASAP7_75t_R  g149(.A(p38), .B(p40), .Y(new_n240_));
  OR3x1_ASAP7_75t_R    g150(.A(new_n237_), .B(new_n239_), .C(new_n240_), .Y(new_n241_));
  OR5x1_ASAP7_75t_R    g151(.A(new_n227_), .B(new_n231_), .C(new_n232_), .D(new_n236_), .E(new_n241_), .Y(new_n242_));
  OAI21x1_ASAP7_75t_R  g152(.A1(new_n226_), .A2(new_n242_), .B(new_n205_), .Y(new_n243_));
  NOR3x1_ASAP7_75t_R   g153(.A(new_n208_), .B(new_n225_), .C(new_n243_), .Y(o2));
  assign               o3 = 1'b0;
  assign               o4 = 1'b0;
  assign               o5 = 1'b0;
  assign               o6 = 1'b0;
  assign               o7 = 1'b0;
  assign               o8 = 1'b0;
  assign               o9 = 1'b0;
  assign               o10 = 1'b0;
  assign               o11 = 1'b0;
  assign               o12 = 1'b0;
  assign               o13 = 1'b0;
  assign               o14 = 1'b0;
  assign               o15 = 1'b0;
  assign               o16 = 1'b0;
  assign               o17 = 1'b0;
  assign               o18 = 1'b0;
  assign               o19 = 1'b0;
  assign               o20 = 1'b0;
  assign               o21 = 1'b0;
  assign               o22 = 1'b0;
  assign               o23 = 1'b0;
  assign               o24 = 1'b0;
  assign               o25 = 1'b0;
  assign               o26 = 1'b0;
  assign               o27 = 1'b0;
  assign               o28 = 1'b0;
  assign               o29 = 1'b0;
endmodule


