// Benchmark "/home/flynn/workplace/MIGBalance/results_v2/single_output_k6_20261020/resumed_baselines_python_command/r0_6in_eqmap_delay-area_int2float/int2float/subject" written by ABC on Tue Oct 20 17:45:04 2026

module \/home/flynn/workplace/MIGBalance/results_v2/single_output_k6_20261020/resumed_baselines_python_command/r0_6in_eqmap_delay-area_int2float/int2float/subject  ( 
    \B[0] , \B[1] , \B[2] , \B[3] , \B[4] , \B[5] , \B[6] , \B[7] , \B[8] ,
    \B[9] , \B[10] ,
    \M[0] , \M[1] , \M[2] , \M[3] , \E[0] , \E[1] , \E[2]   );
  input  \B[0] , \B[1] , \B[2] , \B[3] , \B[4] , \B[5] , \B[6] , \B[7] ,
    \B[8] , \B[9] , \B[10] ;
  output \M[0] , \M[1] , \M[2] , \M[3] , \E[0] , \E[1] , \E[2] ;
  wire new_n19_, new_n20_, new_n21_, new_n22_, new_n23_, new_n24_, new_n25_,
    new_n26_, new_n27_, new_n28_, new_n29_, new_n30_, new_n31_, new_n32_,
    new_n33_, new_n34_, new_n35_, new_n36_, new_n37_, new_n38_, new_n39_,
    new_n40_, new_n41_, new_n42_, new_n43_, new_n44_, new_n45_, new_n46_,
    new_n47_, new_n48_, new_n49_, new_n50_, new_n51_, new_n52_, new_n53_,
    new_n54_, new_n55_, new_n56_, new_n58_, new_n59_, new_n60_, new_n61_,
    new_n62_, new_n63_, new_n64_, new_n65_, new_n66_, new_n67_, new_n68_,
    new_n69_, new_n70_, new_n71_, new_n72_, new_n73_, new_n74_, new_n75_,
    new_n76_, new_n77_, new_n78_, new_n79_, new_n80_, new_n81_, new_n82_,
    new_n83_, new_n84_, new_n86_, new_n87_, new_n88_, new_n89_, new_n90_,
    new_n91_, new_n92_, new_n93_, new_n94_, new_n95_, new_n96_, new_n97_,
    new_n98_, new_n99_, new_n100_, new_n101_, new_n102_, new_n103_,
    new_n104_, new_n105_, new_n106_, new_n107_, new_n109_, new_n110_,
    new_n111_, new_n112_, new_n113_, new_n114_, new_n116_, new_n117_,
    new_n118_, new_n119_, new_n120_, new_n121_, new_n122_, new_n123_,
    new_n124_, new_n126_, new_n127_, new_n128_, new_n129_, new_n130_,
    new_n131_, new_n132_;
  INVx1_ASAP7_75t_R    g000(.A(\B[0] ), .Y(new_n19_));
  INVx1_ASAP7_75t_R    g001(.A(\B[1] ), .Y(new_n20_));
  INVx1_ASAP7_75t_R    g002(.A(\B[2] ), .Y(new_n21_));
  INVx1_ASAP7_75t_R    g003(.A(\B[3] ), .Y(new_n22_));
  INVx1_ASAP7_75t_R    g004(.A(\B[4] ), .Y(new_n23_));
  INVx1_ASAP7_75t_R    g005(.A(\B[5] ), .Y(new_n24_));
  INVx1_ASAP7_75t_R    g006(.A(\B[6] ), .Y(new_n25_));
  INVx1_ASAP7_75t_R    g007(.A(\B[7] ), .Y(new_n26_));
  INVx1_ASAP7_75t_R    g008(.A(\B[8] ), .Y(new_n27_));
  INVx1_ASAP7_75t_R    g009(.A(\B[9] ), .Y(new_n28_));
  INVx1_ASAP7_75t_R    g010(.A(\B[10] ), .Y(new_n29_));
  NOR2x1_ASAP7_75t_R   g011(.A(new_n23_), .B(new_n27_), .Y(new_n30_));
  NOR2x1_ASAP7_75t_R   g012(.A(new_n20_), .B(new_n23_), .Y(new_n31_));
  AO21x1_ASAP7_75t_R   g013(.A1(new_n23_), .A2(\B[8] ), .B(new_n31_), .Y(new_n32_));
  NAND2x1_ASAP7_75t_R  g014(.A(\B[0] ), .B(new_n32_), .Y(new_n33_));
  OA211x2_ASAP7_75t_R  g015(.A1(\B[0] ), .A2(new_n31_), .B(new_n25_), .C(new_n26_), .Y(new_n34_));
  AO21x1_ASAP7_75t_R   g016(.A1(new_n33_), .A2(new_n34_), .B(new_n30_), .Y(new_n35_));
  NOR2x1_ASAP7_75t_R   g017(.A(\B[4] ), .B(new_n26_), .Y(new_n36_));
  NOR2x1_ASAP7_75t_R   g018(.A(new_n20_), .B(new_n24_), .Y(new_n37_));
  AO32x1_ASAP7_75t_R   g019(.A1(new_n21_), .A2(new_n26_), .A3(new_n37_), .B1(new_n23_), .B2(\B[7] ), .Y(new_n38_));
  AO32x1_ASAP7_75t_R   g020(.A1(new_n22_), .A2(\B[4] ), .A3(\B[7] ), .B1(\B[3] ), .B2(new_n38_), .Y(new_n39_));
  AO32x1_ASAP7_75t_R   g021(.A1(new_n23_), .A2(\B[5] ), .A3(\B[8] ), .B1(new_n27_), .B2(new_n39_), .Y(new_n40_));
  AOI21x1_ASAP7_75t_R  g022(.A1(new_n24_), .A2(new_n35_), .B(new_n40_), .Y(new_n41_));
  NOR2x1_ASAP7_75t_R   g023(.A(new_n22_), .B(new_n23_), .Y(new_n42_));
  INVx1_ASAP7_75t_R    g024(.A(new_n42_), .Y(new_n43_));
  OR5x1_ASAP7_75t_R    g025(.A(new_n20_), .B(\B[2] ), .C(new_n36_), .D(new_n30_), .E(new_n42_), .Y(new_n44_));
  OR4x2_ASAP7_75t_R    g026(.A(\B[7] ), .B(\B[8] ), .C(\B[1] ), .D(new_n21_), .Y(new_n45_));
  AND3x1_ASAP7_75t_R   g027(.A(new_n28_), .B(new_n45_), .C(new_n44_), .Y(new_n46_));
  OA33x2_ASAP7_75t_R   g028(.A1(\B[5] ), .A2(new_n25_), .A3(new_n28_), .B1(new_n24_), .B2(\B[6] ), .B3(new_n46_), .Y(new_n47_));
  OA21x2_ASAP7_75t_R   g029(.A1(\B[9] ), .A2(new_n41_), .B(new_n47_), .Y(new_n48_));
  NAND2x1_ASAP7_75t_R  g030(.A(new_n25_), .B(\B[7] ), .Y(new_n49_));
  AO22x1_ASAP7_75t_R   g031(.A1(new_n21_), .A2(\B[3] ), .B1(\B[2] ), .B2(new_n22_), .Y(new_n50_));
  NOR2x1_ASAP7_75t_R   g032(.A(\B[8] ), .B(\B[9] ), .Y(new_n51_));
  INVx1_ASAP7_75t_R    g033(.A(new_n51_), .Y(new_n52_));
  AO21x1_ASAP7_75t_R   g034(.A1(new_n50_), .A2(new_n51_), .B(\B[10] ), .Y(new_n53_));
  NOR2x1_ASAP7_75t_R   g035(.A(new_n27_), .B(new_n29_), .Y(new_n54_));
  AOI22x1_ASAP7_75t_R  g036(.A1(new_n26_), .A2(new_n53_), .B1(\B[9] ), .B2(new_n54_), .Y(new_n55_));
  OA222x2_ASAP7_75t_R  g037(.A1(new_n29_), .A2(new_n49_), .B1(new_n25_), .B2(new_n55_), .C1(\B[10] ), .C2(new_n48_), .Y(new_n56_));
  INVx1_ASAP7_75t_R    g038(.A(new_n56_), .Y(\M[0] ));
  OA21x2_ASAP7_75t_R   g039(.A1(new_n20_), .A2(new_n21_), .B(\B[0] ), .Y(new_n58_));
  OA211x2_ASAP7_75t_R  g040(.A1(\B[0] ), .A2(new_n21_), .B(\B[4] ), .C(new_n26_), .Y(new_n59_));
  INVx1_ASAP7_75t_R    g041(.A(new_n59_), .Y(new_n60_));
  AOI22x1_ASAP7_75t_R  g042(.A1(new_n21_), .A2(new_n26_), .B1(new_n23_), .B2(new_n28_), .Y(new_n61_));
  OA222x2_ASAP7_75t_R  g043(.A1(new_n27_), .A2(\B[9] ), .B1(\B[1] ), .B2(new_n61_), .C1(new_n58_), .C2(new_n60_), .Y(new_n62_));
  NAND2x1_ASAP7_75t_R  g044(.A(new_n26_), .B(\B[9] ), .Y(new_n63_));
  OR3x1_ASAP7_75t_R    g045(.A(new_n26_), .B(new_n52_), .C(new_n42_), .Y(new_n64_));
  OA211x2_ASAP7_75t_R  g046(.A1(\B[6] ), .A2(new_n62_), .B(new_n63_), .C(new_n64_), .Y(new_n65_));
  INVx1_ASAP7_75t_R    g047(.A(new_n65_), .Y(new_n66_));
  OR3x1_ASAP7_75t_R    g048(.A(new_n20_), .B(new_n21_), .C(\B[7] ), .Y(new_n67_));
  OA21x2_ASAP7_75t_R   g049(.A1(new_n20_), .A2(new_n21_), .B(new_n26_), .Y(new_n68_));
  OA33x2_ASAP7_75t_R   g050(.A1(\B[4] ), .A2(\B[6] ), .A3(new_n67_), .B1(new_n23_), .B2(new_n52_), .B3(new_n68_), .Y(new_n69_));
  INVx1_ASAP7_75t_R    g051(.A(new_n69_), .Y(new_n70_));
  OA21x2_ASAP7_75t_R   g052(.A1(\B[4] ), .A2(\B[9] ), .B(new_n63_), .Y(new_n71_));
  AO32x1_ASAP7_75t_R   g053(.A1(\B[6] ), .A2(new_n52_), .A3(new_n71_), .B1(\B[3] ), .B2(new_n70_), .Y(new_n72_));
  AO32x1_ASAP7_75t_R   g054(.A1(new_n23_), .A2(\B[8] ), .A3(new_n28_), .B1(new_n26_), .B2(\B[9] ), .Y(new_n73_));
  AO222x2_ASAP7_75t_R  g055(.A1(\B[5] ), .A2(new_n72_), .B1(new_n25_), .B2(new_n73_), .C1(new_n24_), .C2(new_n66_), .Y(new_n74_));
  NOR2x1_ASAP7_75t_R   g056(.A(new_n25_), .B(new_n26_), .Y(new_n75_));
  INVx1_ASAP7_75t_R    g057(.A(new_n75_), .Y(new_n76_));
  AND3x1_ASAP7_75t_R   g058(.A(\B[6] ), .B(\B[7] ), .C(new_n28_), .Y(new_n77_));
  AO33x2_ASAP7_75t_R   g059(.A1(\B[6] ), .A2(new_n28_), .A3(new_n23_), .B1(\B[5] ), .B2(new_n25_), .B3(new_n20_), .Y(new_n78_));
  AO33x2_ASAP7_75t_R   g060(.A1(\B[6] ), .A2(new_n28_), .A3(new_n23_), .B1(new_n22_), .B2(\B[5] ), .B3(new_n25_), .Y(new_n79_));
  AND3x1_ASAP7_75t_R   g061(.A(\B[3] ), .B(\B[4] ), .C(\B[2] ), .Y(new_n80_));
  AO32x1_ASAP7_75t_R   g062(.A1(\B[6] ), .A2(new_n28_), .A3(new_n80_), .B1(new_n21_), .B2(new_n79_), .Y(new_n81_));
  AO21x1_ASAP7_75t_R   g063(.A1(new_n22_), .A2(new_n78_), .B(new_n81_), .Y(new_n82_));
  AO21x1_ASAP7_75t_R   g064(.A1(new_n26_), .A2(new_n82_), .B(\B[10] ), .Y(new_n83_));
  AO32x1_ASAP7_75t_R   g065(.A1(new_n27_), .A2(new_n76_), .A3(new_n83_), .B1(new_n54_), .B2(new_n77_), .Y(new_n84_));
  AOI21x1_ASAP7_75t_R  g066(.A1(new_n29_), .A2(new_n74_), .B(new_n84_), .Y(\M[1] ));
  NOR2x1_ASAP7_75t_R   g067(.A(new_n19_), .B(\B[6] ), .Y(new_n86_));
  AO33x2_ASAP7_75t_R   g068(.A1(new_n22_), .A2(\B[4] ), .A3(new_n86_), .B1(new_n23_), .B2(\B[5] ), .B3(\B[3] ), .Y(new_n87_));
  NOR2x1_ASAP7_75t_R   g069(.A(new_n19_), .B(new_n20_), .Y(new_n88_));
  OAI22x1_ASAP7_75t_R  g070(.A1(\B[4] ), .A2(\B[6] ), .B1(new_n43_), .B2(new_n88_), .Y(new_n89_));
  AO22x1_ASAP7_75t_R   g071(.A1(\B[1] ), .A2(new_n87_), .B1(new_n24_), .B2(new_n89_), .Y(new_n90_));
  AO32x1_ASAP7_75t_R   g072(.A1(new_n21_), .A2(\B[3] ), .A3(new_n25_), .B1(new_n22_), .B2(\B[5] ), .Y(new_n91_));
  AOI22x1_ASAP7_75t_R  g073(.A1(\B[2] ), .A2(new_n90_), .B1(\B[4] ), .B2(new_n91_), .Y(new_n92_));
  NAND2x1_ASAP7_75t_R  g074(.A(\B[5] ), .B(\B[6] ), .Y(new_n93_));
  OA33x2_ASAP7_75t_R   g075(.A1(new_n24_), .A2(\B[6] ), .A3(\B[1] ), .B1(\B[5] ), .B2(new_n25_), .B3(new_n21_), .Y(new_n94_));
  OA222x2_ASAP7_75t_R  g076(.A1(new_n42_), .A2(new_n93_), .B1(new_n43_), .B2(new_n94_), .C1(\B[7] ), .C2(new_n92_), .Y(new_n95_));
  NOR2x1_ASAP7_75t_R   g077(.A(new_n23_), .B(new_n24_), .Y(new_n96_));
  INVx1_ASAP7_75t_R    g078(.A(new_n96_), .Y(new_n97_));
  NAND2x1_ASAP7_75t_R  g079(.A(\B[6] ), .B(new_n26_), .Y(new_n98_));
  OA33x2_ASAP7_75t_R   g080(.A1(\B[6] ), .A2(new_n26_), .A3(new_n22_), .B1(new_n25_), .B2(\B[7] ), .B3(\B[2] ), .Y(new_n99_));
  OA222x2_ASAP7_75t_R  g081(.A1(new_n76_), .A2(new_n96_), .B1(new_n97_), .B2(new_n99_), .C1(\B[8] ), .C2(new_n95_), .Y(new_n100_));
  INVx1_ASAP7_75t_R    g082(.A(new_n100_), .Y(new_n101_));
  OR3x1_ASAP7_75t_R    g083(.A(new_n25_), .B(\B[7] ), .C(new_n97_), .Y(new_n102_));
  AOI21x1_ASAP7_75t_R  g084(.A1(new_n49_), .A2(new_n102_), .B(new_n27_), .Y(new_n103_));
  AO21x1_ASAP7_75t_R   g085(.A1(new_n28_), .A2(new_n101_), .B(new_n103_), .Y(new_n104_));
  AO32x1_ASAP7_75t_R   g086(.A1(\B[5] ), .A2(new_n27_), .A3(\B[9] ), .B1(\B[8] ), .B2(\B[10] ), .Y(new_n105_));
  AO21x1_ASAP7_75t_R   g087(.A1(\B[5] ), .A2(\B[7] ), .B(new_n27_), .Y(new_n106_));
  NAND2x1_ASAP7_75t_R  g088(.A(new_n29_), .B(new_n106_), .Y(new_n107_));
  AO222x2_ASAP7_75t_R  g089(.A1(new_n75_), .A2(new_n105_), .B1(\B[9] ), .B2(new_n107_), .C1(new_n29_), .C2(new_n104_), .Y(\M[2] ));
  AND3x1_ASAP7_75t_R   g090(.A(\B[5] ), .B(\B[6] ), .C(\B[7] ), .Y(new_n109_));
  AND3x1_ASAP7_75t_R   g091(.A(new_n21_), .B(new_n30_), .C(new_n109_), .Y(new_n110_));
  NOR2x1_ASAP7_75t_R   g092(.A(\B[5] ), .B(\B[6] ), .Y(new_n111_));
  AND5x1_ASAP7_75t_R   g093(.A(new_n23_), .B(new_n26_), .C(new_n27_), .D(new_n24_), .E(new_n25_), .Y(new_n112_));
  NOR2x1_ASAP7_75t_R   g094(.A(\B[9] ), .B(\B[10] ), .Y(new_n113_));
  OA211x2_ASAP7_75t_R  g095(.A1(new_n110_), .A2(new_n112_), .B(new_n22_), .C(new_n113_), .Y(new_n114_));
  INVx1_ASAP7_75t_R    g096(.A(new_n114_), .Y(\M[3] ));
  AO21x1_ASAP7_75t_R   g097(.A1(new_n67_), .A2(new_n93_), .B(new_n22_), .Y(new_n116_));
  NAND2x1_ASAP7_75t_R  g098(.A(new_n24_), .B(new_n26_), .Y(new_n117_));
  AO21x1_ASAP7_75t_R   g099(.A1(new_n116_), .A2(new_n117_), .B(new_n23_), .Y(new_n118_));
  AO32x1_ASAP7_75t_R   g100(.A1(\B[6] ), .A2(new_n26_), .A3(new_n96_), .B1(new_n88_), .B2(new_n111_), .Y(new_n119_));
  AO32x1_ASAP7_75t_R   g101(.A1(\B[2] ), .A2(\B[3] ), .A3(new_n119_), .B1(new_n98_), .B2(new_n118_), .Y(new_n120_));
  OR3x1_ASAP7_75t_R    g102(.A(new_n26_), .B(new_n93_), .C(new_n27_), .Y(new_n121_));
  AO22x1_ASAP7_75t_R   g103(.A1(\B[2] ), .A2(new_n22_), .B1(\B[3] ), .B2(\B[8] ), .Y(new_n122_));
  AO32x1_ASAP7_75t_R   g104(.A1(new_n77_), .A2(new_n96_), .A3(new_n122_), .B1(\B[9] ), .B2(new_n121_), .Y(new_n123_));
  AO21x1_ASAP7_75t_R   g105(.A1(new_n27_), .A2(new_n120_), .B(new_n123_), .Y(new_n124_));
  NAND2x1_ASAP7_75t_R  g106(.A(new_n29_), .B(new_n124_), .Y(\E[0] ));
  AND3x1_ASAP7_75t_R   g107(.A(\B[3] ), .B(new_n27_), .C(new_n88_), .Y(new_n126_));
  AO32x1_ASAP7_75t_R   g108(.A1(new_n24_), .A2(new_n26_), .A3(new_n126_), .B1(\B[8] ), .B2(new_n109_), .Y(new_n127_));
  AO32x1_ASAP7_75t_R   g109(.A1(\B[3] ), .A2(\B[8] ), .A3(new_n109_), .B1(\B[2] ), .B2(new_n127_), .Y(new_n128_));
  INVx1_ASAP7_75t_R    g110(.A(new_n128_), .Y(new_n129_));
  AND3x1_ASAP7_75t_R   g111(.A(\B[5] ), .B(\B[6] ), .C(new_n80_), .Y(new_n130_));
  OR4x2_ASAP7_75t_R    g112(.A(\B[7] ), .B(\B[8] ), .C(new_n111_), .D(new_n130_), .Y(new_n131_));
  OA211x2_ASAP7_75t_R  g113(.A1(new_n23_), .A2(new_n129_), .B(new_n113_), .C(new_n131_), .Y(new_n132_));
  INVx1_ASAP7_75t_R    g114(.A(new_n132_), .Y(\E[1] ));
  OR5x1_ASAP7_75t_R    g115(.A(\B[7] ), .B(\B[8] ), .C(\B[9] ), .D(\B[10] ), .E(new_n130_), .Y(\E[2] ));
endmodule


