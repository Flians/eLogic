// Benchmark "/tmp/" written by ABC on Tue Oct 20 17:46:20 2026

module \/tmp/  ( 
    p8, p6, p1, p4, p2, p9, p3, p5, p10, p7, p0,
    o0, o1, o2, o3, o4, o5, o6  );
  input  p8, p6, p1, p4, p2, p9, p3, p5, p10, p7, p0;
  output o0, o1, o2, o3, o4, o5, o6;
  wire new_n19_, new_n20_, new_n21_, new_n22_, new_n23_, new_n24_, new_n25_,
    new_n26_, new_n27_, new_n28_, new_n29_, new_n30_, new_n31_, new_n32_,
    new_n33_, new_n34_, new_n35_, new_n36_, new_n37_, new_n38_, new_n39_,
    new_n40_, new_n41_, new_n42_, new_n43_, new_n44_, new_n45_, new_n46_,
    new_n47_, new_n48_, new_n49_, new_n50_, new_n51_, new_n52_, new_n53_,
    new_n54_, new_n55_, new_n56_, new_n57_, new_n58_, new_n59_, new_n60_,
    new_n61_, new_n62_, new_n63_, new_n64_, new_n65_, new_n67_, new_n68_,
    new_n69_, new_n70_, new_n71_, new_n72_, new_n73_, new_n74_, new_n75_,
    new_n76_, new_n77_, new_n78_, new_n79_, new_n80_, new_n81_, new_n82_,
    new_n83_, new_n84_, new_n85_, new_n86_, new_n87_, new_n88_, new_n89_,
    new_n90_, new_n91_, new_n92_, new_n93_, new_n94_, new_n95_, new_n96_,
    new_n97_, new_n98_, new_n99_, new_n100_, new_n101_, new_n102_,
    new_n104_, new_n105_, new_n106_, new_n107_, new_n108_, new_n109_,
    new_n110_, new_n111_, new_n112_, new_n113_, new_n114_, new_n115_,
    new_n116_, new_n117_, new_n118_, new_n119_, new_n120_, new_n121_,
    new_n122_, new_n123_, new_n124_, new_n125_, new_n126_, new_n127_,
    new_n128_, new_n129_, new_n130_, new_n131_, new_n132_, new_n133_,
    new_n134_, new_n136_, new_n137_, new_n138_, new_n139_, new_n141_,
    new_n142_, new_n143_, new_n144_, new_n145_, new_n146_, new_n147_,
    new_n148_, new_n149_, new_n150_, new_n151_, new_n152_, new_n153_,
    new_n155_, new_n156_, new_n157_, new_n158_, new_n159_, new_n160_,
    new_n161_;
  INVx1_ASAP7_75t_R    g000(.A(p3), .Y(new_n19_));
  INVx1_ASAP7_75t_R    g001(.A(p4), .Y(new_n20_));
  AO21x1_ASAP7_75t_R   g002(.A1(p7), .A2(new_n19_), .B(new_n20_), .Y(new_n21_));
  NAND2x1_ASAP7_75t_R  g003(.A(p3), .B(p0), .Y(new_n22_));
  NAND2x1_ASAP7_75t_R  g004(.A(p7), .B(new_n19_), .Y(new_n23_));
  INVx1_ASAP7_75t_R    g005(.A(p10), .Y(new_n24_));
  AOI21x1_ASAP7_75t_R  g006(.A1(new_n22_), .A2(new_n23_), .B(new_n24_), .Y(new_n25_));
  INVx1_ASAP7_75t_R    g007(.A(p6), .Y(new_n26_));
  INVx1_ASAP7_75t_R    g008(.A(p5), .Y(new_n27_));
  NAND2x1_ASAP7_75t_R  g009(.A(new_n26_), .B(new_n27_), .Y(new_n28_));
  AO21x1_ASAP7_75t_R   g010(.A1(new_n24_), .A2(new_n22_), .B(new_n28_), .Y(new_n29_));
  INVx1_ASAP7_75t_R    g011(.A(p7), .Y(new_n30_));
  OA21x2_ASAP7_75t_R   g012(.A1(new_n19_), .A2(new_n30_), .B(new_n20_), .Y(new_n31_));
  OAI21x1_ASAP7_75t_R  g013(.A1(new_n25_), .A2(new_n29_), .B(new_n31_), .Y(new_n32_));
  NAND2x1_ASAP7_75t_R  g014(.A(p4), .B(p2), .Y(new_n33_));
  INVx1_ASAP7_75t_R    g015(.A(p0), .Y(new_n34_));
  OR4x2_ASAP7_75t_R    g016(.A(new_n33_), .B(p6), .C(p1), .D(new_n34_), .Y(new_n35_));
  INVx1_ASAP7_75t_R    g017(.A(p2), .Y(new_n36_));
  NAND2x1_ASAP7_75t_R  g018(.A(p2), .B(p3), .Y(new_n37_));
  NAND2x1_ASAP7_75t_R  g019(.A(p6), .B(new_n37_), .Y(new_n38_));
  AO21x1_ASAP7_75t_R   g020(.A1(new_n36_), .A2(new_n19_), .B(new_n38_), .Y(new_n39_));
  AOI21x1_ASAP7_75t_R  g021(.A1(new_n35_), .A2(new_n39_), .B(p7), .Y(new_n40_));
  AOI21x1_ASAP7_75t_R  g022(.A1(new_n21_), .A2(new_n32_), .B(new_n40_), .Y(new_n41_));
  NOR2x1_ASAP7_75t_R   g023(.A(p8), .B(p9), .Y(new_n42_));
  INVx1_ASAP7_75t_R    g024(.A(new_n42_), .Y(new_n43_));
  INVx1_ASAP7_75t_R    g025(.A(p9), .Y(new_n44_));
  AOI211x1_ASAP7_75t_R g026(.A1(p6), .A2(new_n19_), .B(p1), .C(new_n34_), .Y(new_n45_));
  AO21x1_ASAP7_75t_R   g027(.A1(new_n36_), .A2(new_n30_), .B(new_n19_), .Y(new_n46_));
  NOR2x1_ASAP7_75t_R   g028(.A(p5), .B(new_n20_), .Y(new_n47_));
  NAND3x1_ASAP7_75t_R  g029(.A(new_n45_), .B(new_n46_), .C(new_n47_), .Y(new_n48_));
  NOR2x1_ASAP7_75t_R   g030(.A(p6), .B(p7), .Y(new_n49_));
  AO31x2_ASAP7_75t_R   g031(.A1(new_n49_), .A2(p1), .A3(new_n34_), .B(p8), .Y(new_n50_));
  NAND2x1_ASAP7_75t_R  g032(.A(p8), .B(p5), .Y(new_n51_));
  NOR2x1_ASAP7_75t_R   g033(.A(p4), .B(new_n51_), .Y(new_n52_));
  AOI21x1_ASAP7_75t_R  g034(.A1(new_n47_), .A2(new_n50_), .B(new_n52_), .Y(new_n53_));
  NAND2x1_ASAP7_75t_R  g035(.A(new_n48_), .B(new_n53_), .Y(new_n54_));
  AND3x1_ASAP7_75t_R   g036(.A(p8), .B(p5), .C(p7), .Y(new_n55_));
  NOR2x1_ASAP7_75t_R   g037(.A(p5), .B(new_n26_), .Y(new_n56_));
  OAI21x1_ASAP7_75t_R  g038(.A1(new_n55_), .A2(new_n56_), .B(p9), .Y(new_n57_));
  NAND2x1_ASAP7_75t_R  g039(.A(p5), .B(new_n26_), .Y(new_n58_));
  INVx1_ASAP7_75t_R    g040(.A(p1), .Y(new_n59_));
  NAND2x1_ASAP7_75t_R  g041(.A(new_n59_), .B(new_n36_), .Y(new_n60_));
  NOR2x1_ASAP7_75t_R   g042(.A(p8), .B(p7), .Y(new_n61_));
  NAND2x1_ASAP7_75t_R  g043(.A(p1), .B(p2), .Y(new_n62_));
  NAND3x1_ASAP7_75t_R  g044(.A(new_n60_), .B(new_n61_), .C(new_n62_), .Y(new_n63_));
  AOI22x1_ASAP7_75t_R  g045(.A1(new_n57_), .A2(new_n58_), .B1(new_n63_), .B2(new_n44_), .Y(new_n64_));
  AOI21x1_ASAP7_75t_R  g046(.A1(new_n44_), .A2(new_n54_), .B(new_n64_), .Y(new_n65_));
  OAI21x1_ASAP7_75t_R  g047(.A1(new_n41_), .A2(new_n43_), .B(new_n65_), .Y(o0));
  INVx1_ASAP7_75t_R    g048(.A(new_n61_), .Y(new_n67_));
  NAND2x1_ASAP7_75t_R  g049(.A(p8), .B(new_n26_), .Y(new_n68_));
  OAI21x1_ASAP7_75t_R  g050(.A1(new_n67_), .A2(new_n38_), .B(new_n68_), .Y(new_n69_));
  NOR2x1_ASAP7_75t_R   g051(.A(p8), .B(p3), .Y(new_n70_));
  NAND2x1_ASAP7_75t_R  g052(.A(p7), .B(new_n70_), .Y(new_n71_));
  NAND2x1_ASAP7_75t_R  g053(.A(new_n68_), .B(new_n71_), .Y(new_n72_));
  AOI22x1_ASAP7_75t_R  g054(.A1(new_n69_), .A2(new_n20_), .B1(new_n27_), .B2(new_n72_), .Y(new_n73_));
  OAI21x1_ASAP7_75t_R  g055(.A1(p8), .A2(p7), .B(p5), .Y(new_n74_));
  AOI211x1_ASAP7_75t_R g056(.A1(p8), .A2(new_n26_), .B(new_n70_), .C(new_n74_), .Y(new_n75_));
  OAI21x1_ASAP7_75t_R  g057(.A1(p6), .A2(p5), .B(new_n19_), .Y(new_n76_));
  OAI21x1_ASAP7_75t_R  g058(.A1(p8), .A2(p7), .B(p3), .Y(new_n77_));
  AO21x1_ASAP7_75t_R   g059(.A1(p1), .A2(p0), .B(p6), .Y(new_n78_));
  AND4x2_ASAP7_75t_R   g060(.A(new_n76_), .B(p2), .C(new_n77_), .D(new_n78_), .Y(new_n79_));
  OAI21x1_ASAP7_75t_R  g061(.A1(new_n75_), .A2(new_n79_), .B(p4), .Y(new_n80_));
  INVx1_ASAP7_75t_R    g062(.A(p8), .Y(new_n81_));
  OAI22x1_ASAP7_75t_R  g063(.A1(p8), .A2(p3), .B1(p6), .B2(p1), .Y(new_n82_));
  AO22x1_ASAP7_75t_R   g064(.A1(new_n81_), .A2(p7), .B1(new_n34_), .B2(new_n82_), .Y(new_n83_));
  NAND2x1_ASAP7_75t_R  g065(.A(p1), .B(p0), .Y(new_n84_));
  NAND2x1_ASAP7_75t_R  g066(.A(p3), .B(new_n26_), .Y(new_n85_));
  NOR2x1_ASAP7_75t_R   g067(.A(p10), .B(new_n59_), .Y(new_n86_));
  AOI211x1_ASAP7_75t_R g068(.A1(p10), .A2(new_n84_), .B(new_n85_), .C(new_n86_), .Y(new_n87_));
  NOR2x1_ASAP7_75t_R   g069(.A(p4), .B(p5), .Y(new_n88_));
  OAI21x1_ASAP7_75t_R  g070(.A1(new_n83_), .A2(new_n87_), .B(new_n88_), .Y(new_n89_));
  NAND3x1_ASAP7_75t_R  g071(.A(new_n73_), .B(new_n80_), .C(new_n89_), .Y(new_n90_));
  AO21x1_ASAP7_75t_R   g072(.A1(p6), .A2(p5), .B(p7), .Y(new_n91_));
  OA21x2_ASAP7_75t_R   g073(.A1(p3), .A2(new_n62_), .B(new_n26_), .Y(new_n92_));
  NAND2x1_ASAP7_75t_R  g074(.A(p4), .B(new_n84_), .Y(new_n93_));
  NAND2x1_ASAP7_75t_R  g075(.A(new_n36_), .B(new_n27_), .Y(new_n94_));
  NAND2x1_ASAP7_75t_R  g076(.A(p5), .B(new_n81_), .Y(new_n95_));
  AOI21x1_ASAP7_75t_R  g077(.A1(p1), .A2(p2), .B(new_n19_), .Y(new_n96_));
  OAI22x1_ASAP7_75t_R  g078(.A1(new_n93_), .A2(new_n94_), .B1(new_n95_), .B2(new_n96_), .Y(new_n97_));
  AOI21x1_ASAP7_75t_R  g079(.A1(new_n92_), .A2(new_n97_), .B(p9), .Y(new_n98_));
  NAND2x1_ASAP7_75t_R  g080(.A(p9), .B(p7), .Y(new_n99_));
  NAND2x1_ASAP7_75t_R  g081(.A(p6), .B(p5), .Y(new_n100_));
  OR3x1_ASAP7_75t_R    g082(.A(new_n99_), .B(new_n100_), .C(p8), .Y(new_n101_));
  OAI21x1_ASAP7_75t_R  g083(.A1(new_n91_), .A2(new_n98_), .B(new_n101_), .Y(new_n102_));
  AOI21x1_ASAP7_75t_R  g084(.A1(new_n44_), .A2(new_n90_), .B(new_n102_), .Y(o1));
  INVx1_ASAP7_75t_R    g085(.A(new_n37_), .Y(new_n104_));
  NOR2x1_ASAP7_75t_R   g086(.A(p1), .B(p5), .Y(new_n105_));
  AND3x1_ASAP7_75t_R   g087(.A(new_n36_), .B(p4), .C(p3), .Y(new_n106_));
  AOI21x1_ASAP7_75t_R  g088(.A1(new_n104_), .A2(new_n105_), .B(new_n106_), .Y(new_n107_));
  INVx1_ASAP7_75t_R    g089(.A(new_n49_), .Y(new_n108_));
  AOI21x1_ASAP7_75t_R  g090(.A1(new_n59_), .A2(new_n107_), .B(new_n108_), .Y(new_n109_));
  NOR2x1_ASAP7_75t_R   g091(.A(p3), .B(p5), .Y(new_n110_));
  AOI21x1_ASAP7_75t_R  g092(.A1(p10), .A2(p0), .B(new_n37_), .Y(new_n111_));
  OAI21x1_ASAP7_75t_R  g093(.A1(new_n110_), .A2(new_n111_), .B(new_n20_), .Y(new_n112_));
  NOR3x1_ASAP7_75t_R   g094(.A(new_n24_), .B(p2), .C(p5), .Y(new_n113_));
  AOI21x1_ASAP7_75t_R  g095(.A1(new_n19_), .A2(new_n33_), .B(new_n34_), .Y(new_n114_));
  OAI21x1_ASAP7_75t_R  g096(.A1(new_n19_), .A2(new_n113_), .B(new_n114_), .Y(new_n115_));
  NAND3x1_ASAP7_75t_R  g097(.A(new_n112_), .B(new_n107_), .C(new_n115_), .Y(new_n116_));
  NAND2x1_ASAP7_75t_R  g098(.A(p4), .B(p5), .Y(new_n117_));
  AO21x1_ASAP7_75t_R   g099(.A1(new_n37_), .A2(new_n117_), .B(p7), .Y(new_n118_));
  AND3x1_ASAP7_75t_R   g100(.A(new_n20_), .B(p1), .C(p5), .Y(new_n119_));
  AOI211x1_ASAP7_75t_R g101(.A1(new_n34_), .A2(new_n47_), .B(new_n37_), .C(new_n119_), .Y(new_n120_));
  NOR2x1_ASAP7_75t_R   g102(.A(p6), .B(p1), .Y(new_n121_));
  AND3x1_ASAP7_75t_R   g103(.A(p4), .B(p3), .C(p5), .Y(new_n122_));
  AND3x1_ASAP7_75t_R   g104(.A(p4), .B(p2), .C(p3), .Y(new_n123_));
  AOI21x1_ASAP7_75t_R  g105(.A1(p4), .A2(p3), .B(new_n100_), .Y(new_n124_));
  AOI221x1_ASAP7_75t_R g106(.A1(new_n121_), .A2(new_n122_), .B1(new_n56_), .B2(new_n123_), .C(new_n124_), .Y(new_n125_));
  OAI21x1_ASAP7_75t_R  g107(.A1(new_n118_), .A2(new_n120_), .B(new_n125_), .Y(new_n126_));
  AOI21x1_ASAP7_75t_R  g108(.A1(new_n109_), .A2(new_n116_), .B(new_n126_), .Y(new_n127_));
  AO21x1_ASAP7_75t_R   g109(.A1(new_n26_), .A2(new_n122_), .B(new_n56_), .Y(new_n128_));
  OA21x2_ASAP7_75t_R   g110(.A1(new_n26_), .A2(new_n20_), .B(p8), .Y(new_n129_));
  AO21x1_ASAP7_75t_R   g111(.A1(new_n44_), .A2(new_n128_), .B(new_n129_), .Y(new_n130_));
  OR3x1_ASAP7_75t_R    g112(.A(new_n100_), .B(new_n20_), .C(p7), .Y(new_n131_));
  AO21x1_ASAP7_75t_R   g113(.A1(new_n44_), .A2(new_n131_), .B(new_n81_), .Y(new_n132_));
  OAI21x1_ASAP7_75t_R  g114(.A1(new_n99_), .A2(new_n100_), .B(new_n132_), .Y(new_n133_));
  AOI21x1_ASAP7_75t_R  g115(.A1(p7), .A2(new_n130_), .B(new_n133_), .Y(new_n134_));
  OAI21x1_ASAP7_75t_R  g116(.A1(new_n43_), .A2(new_n127_), .B(new_n134_), .Y(o2));
  OR5x1_ASAP7_75t_R    g117(.A(p6), .B(p4), .C(p3), .D(p5), .E(p7), .Y(new_n136_));
  OR3x1_ASAP7_75t_R    g118(.A(new_n117_), .B(new_n26_), .C(new_n30_), .Y(new_n137_));
  OR3x1_ASAP7_75t_R    g119(.A(new_n137_), .B(p1), .C(new_n19_), .Y(new_n138_));
  OR3x1_ASAP7_75t_R    g120(.A(p8), .B(p2), .C(p9), .Y(new_n139_));
  AO21x1_ASAP7_75t_R   g121(.A1(new_n136_), .A2(new_n138_), .B(new_n139_), .Y(o3));
  OR3x1_ASAP7_75t_R    g122(.A(new_n19_), .B(p6), .C(p4), .Y(new_n141_));
  AND3x1_ASAP7_75t_R   g123(.A(new_n141_), .B(new_n30_), .C(new_n58_), .Y(new_n142_));
  OR3x1_ASAP7_75t_R    g124(.A(new_n59_), .B(new_n34_), .C(p6), .Y(new_n143_));
  AO21x1_ASAP7_75t_R   g125(.A1(new_n117_), .A2(new_n143_), .B(new_n37_), .Y(new_n144_));
  AND2x2_ASAP7_75t_R   g126(.A(new_n142_), .B(new_n144_), .Y(new_n145_));
  AND2x2_ASAP7_75t_R   g127(.A(p2), .B(p7), .Y(new_n146_));
  AO21x1_ASAP7_75t_R   g128(.A1(p1), .A2(new_n36_), .B(new_n146_), .Y(new_n147_));
  AND5x1_ASAP7_75t_R   g129(.A(new_n81_), .B(p6), .C(p4), .D(p3), .E(p5), .Y(new_n148_));
  AOI22x1_ASAP7_75t_R  g130(.A1(new_n147_), .A2(new_n148_), .B1(p8), .B2(new_n137_), .Y(new_n149_));
  AND3x1_ASAP7_75t_R   g131(.A(new_n30_), .B(p1), .C(p2), .Y(new_n150_));
  AO32x1_ASAP7_75t_R   g132(.A1(p10), .A2(p0), .A3(new_n88_), .B1(new_n122_), .B2(new_n26_), .Y(new_n151_));
  NAND2x1_ASAP7_75t_R  g133(.A(new_n150_), .B(new_n151_), .Y(new_n152_));
  NAND2x1_ASAP7_75t_R  g134(.A(new_n149_), .B(new_n152_), .Y(new_n153_));
  OAI21x1_ASAP7_75t_R  g135(.A1(new_n145_), .A2(new_n153_), .B(new_n44_), .Y(o4));
  AND3x1_ASAP7_75t_R   g136(.A(p6), .B(p4), .C(p5), .Y(new_n155_));
  NOR2x1_ASAP7_75t_R   g137(.A(p6), .B(p4), .Y(new_n156_));
  AND5x1_ASAP7_75t_R   g138(.A(p2), .B(new_n156_), .C(p10), .D(new_n30_), .E(p0), .Y(new_n157_));
  AO32x1_ASAP7_75t_R   g139(.A1(p7), .A2(new_n60_), .A3(new_n155_), .B1(new_n157_), .B2(p1), .Y(new_n158_));
  AND3x1_ASAP7_75t_R   g140(.A(new_n122_), .B(p1), .C(p2), .Y(new_n159_));
  OR3x1_ASAP7_75t_R    g141(.A(new_n159_), .B(new_n108_), .C(new_n88_), .Y(new_n160_));
  NAND2x1_ASAP7_75t_R  g142(.A(new_n42_), .B(new_n160_), .Y(new_n161_));
  AO21x1_ASAP7_75t_R   g143(.A1(p3), .A2(new_n158_), .B(new_n161_), .Y(o5));
  OR3x1_ASAP7_75t_R    g144(.A(new_n159_), .B(new_n43_), .C(new_n108_), .Y(o6));
endmodule


