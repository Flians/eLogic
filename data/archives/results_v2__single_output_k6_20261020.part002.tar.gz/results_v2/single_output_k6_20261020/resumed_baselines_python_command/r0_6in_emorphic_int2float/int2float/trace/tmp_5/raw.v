// Benchmark "/tmp/" written by ABC on Tue Oct 20 17:46:14 2026

module \/tmp/  ( 
    p7, p4, p2, p10, p5, p8, p9, p3, p0, p6, p1,
    o0, o1, o2, o3, o4, o5, o6  );
  input  p7, p4, p2, p10, p5, p8, p9, p3, p0, p6, p1;
  output o0, o1, o2, o3, o4, o5, o6;
  wire new_n19_, new_n20_, new_n21_, new_n22_, new_n23_, new_n24_, new_n25_,
    new_n26_, new_n27_, new_n28_, new_n29_, new_n30_, new_n31_, new_n32_,
    new_n33_, new_n34_, new_n35_, new_n36_, new_n37_, new_n38_, new_n39_,
    new_n40_, new_n41_, new_n42_, new_n43_, new_n44_, new_n45_, new_n46_,
    new_n47_, new_n48_, new_n49_, new_n50_, new_n51_, new_n52_, new_n53_,
    new_n54_, new_n55_, new_n56_, new_n57_, new_n58_, new_n59_, new_n60_,
    new_n61_, new_n62_, new_n64_, new_n65_, new_n66_, new_n67_, new_n68_,
    new_n69_, new_n70_, new_n71_, new_n72_, new_n73_, new_n74_, new_n75_,
    new_n76_, new_n77_, new_n78_, new_n79_, new_n80_, new_n81_, new_n82_,
    new_n83_, new_n84_, new_n85_, new_n86_, new_n87_, new_n88_, new_n89_,
    new_n90_, new_n91_, new_n92_, new_n93_, new_n94_, new_n95_, new_n96_,
    new_n97_, new_n99_, new_n100_, new_n101_, new_n102_, new_n103_,
    new_n104_, new_n105_, new_n106_, new_n107_, new_n108_, new_n109_,
    new_n110_, new_n111_, new_n112_, new_n113_, new_n114_, new_n115_,
    new_n116_, new_n117_, new_n118_, new_n119_, new_n120_, new_n121_,
    new_n122_, new_n123_, new_n124_, new_n125_, new_n126_, new_n127_,
    new_n128_, new_n129_, new_n131_, new_n132_, new_n133_, new_n134_,
    new_n136_, new_n137_, new_n138_, new_n139_, new_n140_, new_n141_,
    new_n142_, new_n143_, new_n144_, new_n145_, new_n146_, new_n147_,
    new_n149_, new_n150_, new_n151_, new_n152_, new_n153_, new_n154_,
    new_n155_;
  NOR2x1_ASAP7_75t_R   g000(.A(p8), .B(p9), .Y(new_n19_));
  INVx1_ASAP7_75t_R    g001(.A(new_n19_), .Y(new_n20_));
  INVx1_ASAP7_75t_R    g002(.A(p4), .Y(new_n21_));
  AND2x2_ASAP7_75t_R   g003(.A(p3), .B(p0), .Y(new_n22_));
  NOR2x1_ASAP7_75t_R   g004(.A(p5), .B(p6), .Y(new_n23_));
  OA21x2_ASAP7_75t_R   g005(.A1(p10), .A2(new_n22_), .B(new_n23_), .Y(new_n24_));
  INVx1_ASAP7_75t_R    g006(.A(p7), .Y(new_n25_));
  NOR2x1_ASAP7_75t_R   g007(.A(p3), .B(new_n25_), .Y(new_n26_));
  OAI21x1_ASAP7_75t_R  g008(.A1(new_n22_), .A2(new_n26_), .B(p10), .Y(new_n27_));
  AND2x2_ASAP7_75t_R   g009(.A(p7), .B(p3), .Y(new_n28_));
  AO21x1_ASAP7_75t_R   g010(.A1(new_n24_), .A2(new_n27_), .B(new_n28_), .Y(new_n29_));
  INVx1_ASAP7_75t_R    g011(.A(p2), .Y(new_n30_));
  AND3x1_ASAP7_75t_R   g012(.A(new_n30_), .B(p3), .C(p6), .Y(new_n31_));
  NOR2x1_ASAP7_75t_R   g013(.A(p6), .B(p1), .Y(new_n32_));
  INVx1_ASAP7_75t_R    g014(.A(p3), .Y(new_n33_));
  AO32x1_ASAP7_75t_R   g015(.A1(new_n32_), .A2(p4), .A3(p0), .B1(new_n33_), .B2(p6), .Y(new_n34_));
  NOR2x1_ASAP7_75t_R   g016(.A(p7), .B(new_n30_), .Y(new_n35_));
  AND3x1_ASAP7_75t_R   g017(.A(new_n33_), .B(p7), .C(p4), .Y(new_n36_));
  AO221x2_ASAP7_75t_R  g018(.A1(new_n25_), .A2(new_n31_), .B1(new_n34_), .B2(new_n35_), .C(new_n36_), .Y(new_n37_));
  AOI21x1_ASAP7_75t_R  g019(.A1(new_n21_), .A2(new_n29_), .B(new_n37_), .Y(new_n38_));
  INVx1_ASAP7_75t_R    g020(.A(p9), .Y(new_n39_));
  NOR2x1_ASAP7_75t_R   g021(.A(p5), .B(new_n21_), .Y(new_n40_));
  INVx1_ASAP7_75t_R    g022(.A(new_n40_), .Y(new_n41_));
  INVx1_ASAP7_75t_R    g023(.A(p0), .Y(new_n42_));
  INVx1_ASAP7_75t_R    g024(.A(p6), .Y(new_n43_));
  NOR2x1_ASAP7_75t_R   g025(.A(p3), .B(new_n43_), .Y(new_n44_));
  AND2x2_ASAP7_75t_R   g026(.A(p2), .B(p3), .Y(new_n45_));
  OR5x1_ASAP7_75t_R    g027(.A(new_n42_), .B(new_n44_), .C(p1), .D(new_n28_), .E(new_n45_), .Y(new_n46_));
  NOR2x1_ASAP7_75t_R   g028(.A(p7), .B(p6), .Y(new_n47_));
  AO31x2_ASAP7_75t_R   g029(.A1(new_n47_), .A2(new_n42_), .A3(p1), .B(p8), .Y(new_n48_));
  AND3x1_ASAP7_75t_R   g030(.A(new_n21_), .B(p5), .C(p8), .Y(new_n49_));
  AOI21x1_ASAP7_75t_R  g031(.A1(new_n40_), .A2(new_n48_), .B(new_n49_), .Y(new_n50_));
  OAI21x1_ASAP7_75t_R  g032(.A1(new_n41_), .A2(new_n46_), .B(new_n50_), .Y(new_n51_));
  INVx1_ASAP7_75t_R    g033(.A(p5), .Y(new_n52_));
  NOR2x1_ASAP7_75t_R   g034(.A(p6), .B(new_n52_), .Y(new_n53_));
  INVx1_ASAP7_75t_R    g035(.A(p8), .Y(new_n54_));
  NAND2x1_ASAP7_75t_R  g036(.A(new_n25_), .B(new_n54_), .Y(new_n55_));
  XNOR2x2_ASAP7_75t_R  g037(.A(p2), .B(p1), .Y(new_n56_));
  OAI21x1_ASAP7_75t_R  g038(.A1(new_n55_), .A2(new_n56_), .B(new_n39_), .Y(new_n57_));
  AND3x1_ASAP7_75t_R   g039(.A(p7), .B(p5), .C(p8), .Y(new_n58_));
  NOR2x1_ASAP7_75t_R   g040(.A(p5), .B(new_n43_), .Y(new_n59_));
  OA21x2_ASAP7_75t_R   g041(.A1(new_n58_), .A2(new_n59_), .B(p9), .Y(new_n60_));
  AO21x1_ASAP7_75t_R   g042(.A1(new_n53_), .A2(new_n57_), .B(new_n60_), .Y(new_n61_));
  AOI21x1_ASAP7_75t_R  g043(.A1(new_n39_), .A2(new_n51_), .B(new_n61_), .Y(new_n62_));
  OAI21x1_ASAP7_75t_R  g044(.A1(new_n20_), .A2(new_n38_), .B(new_n62_), .Y(o0));
  OR3x1_ASAP7_75t_R    g045(.A(new_n43_), .B(p7), .C(p8), .Y(new_n64_));
  NAND2x1_ASAP7_75t_R  g046(.A(p8), .B(new_n43_), .Y(new_n65_));
  OAI21x1_ASAP7_75t_R  g047(.A1(new_n45_), .A2(new_n64_), .B(new_n65_), .Y(new_n66_));
  NOR2x1_ASAP7_75t_R   g048(.A(p5), .B(p3), .Y(new_n67_));
  AO32x1_ASAP7_75t_R   g049(.A1(new_n25_), .A2(new_n54_), .A3(p3), .B1(new_n67_), .B2(new_n43_), .Y(new_n68_));
  AND2x2_ASAP7_75t_R   g050(.A(p0), .B(p1), .Y(new_n69_));
  OA211x2_ASAP7_75t_R  g051(.A1(p6), .A2(new_n69_), .B(p4), .C(p2), .Y(new_n70_));
  AOI22x1_ASAP7_75t_R  g052(.A1(new_n66_), .A2(new_n21_), .B1(new_n68_), .B2(new_n70_), .Y(new_n71_));
  OAI22x1_ASAP7_75t_R  g053(.A1(p8), .A2(p3), .B1(p6), .B2(p1), .Y(new_n72_));
  AO22x1_ASAP7_75t_R   g054(.A1(p7), .A2(new_n54_), .B1(new_n42_), .B2(new_n72_), .Y(new_n73_));
  NAND2x1_ASAP7_75t_R  g055(.A(p10), .B(p0), .Y(new_n74_));
  NAND2x1_ASAP7_75t_R  g056(.A(p3), .B(new_n43_), .Y(new_n75_));
  INVx1_ASAP7_75t_R    g057(.A(p1), .Y(new_n76_));
  AND2x2_ASAP7_75t_R   g058(.A(p10), .B(new_n76_), .Y(new_n77_));
  AOI211x1_ASAP7_75t_R g059(.A1(p1), .A2(new_n74_), .B(new_n75_), .C(new_n77_), .Y(new_n78_));
  NOR2x1_ASAP7_75t_R   g060(.A(p4), .B(p5), .Y(new_n79_));
  OAI21x1_ASAP7_75t_R  g061(.A1(new_n73_), .A2(new_n78_), .B(new_n79_), .Y(new_n80_));
  NAND2x1_ASAP7_75t_R  g062(.A(new_n54_), .B(new_n33_), .Y(new_n81_));
  AOI21x1_ASAP7_75t_R  g063(.A1(new_n65_), .A2(new_n81_), .B(p5), .Y(new_n82_));
  AND2x2_ASAP7_75t_R   g064(.A(p4), .B(p5), .Y(new_n83_));
  AND3x1_ASAP7_75t_R   g065(.A(new_n81_), .B(new_n65_), .C(new_n83_), .Y(new_n84_));
  OAI21x1_ASAP7_75t_R  g066(.A1(new_n82_), .A2(new_n84_), .B(new_n55_), .Y(new_n85_));
  NAND3x1_ASAP7_75t_R  g067(.A(new_n71_), .B(new_n80_), .C(new_n85_), .Y(new_n86_));
  AO21x1_ASAP7_75t_R   g068(.A1(p5), .A2(p6), .B(p7), .Y(new_n87_));
  NOR2x1_ASAP7_75t_R   g069(.A(p6), .B(new_n69_), .Y(new_n88_));
  AND3x1_ASAP7_75t_R   g070(.A(new_n30_), .B(new_n52_), .C(p4), .Y(new_n89_));
  NAND2x1_ASAP7_75t_R  g071(.A(p2), .B(p1), .Y(new_n90_));
  XOR2x2_ASAP7_75t_R   g072(.A(new_n90_), .B(p3), .Y(new_n91_));
  AND3x1_ASAP7_75t_R   g073(.A(new_n54_), .B(new_n43_), .C(p5), .Y(new_n92_));
  AOI221x1_ASAP7_75t_R g074(.A1(new_n88_), .A2(new_n89_), .B1(new_n91_), .B2(new_n92_), .C(p9), .Y(new_n93_));
  NAND2x1_ASAP7_75t_R  g075(.A(p5), .B(p6), .Y(new_n94_));
  NAND2x1_ASAP7_75t_R  g076(.A(p7), .B(p9), .Y(new_n95_));
  OR3x1_ASAP7_75t_R    g077(.A(new_n94_), .B(new_n95_), .C(p8), .Y(new_n96_));
  OAI21x1_ASAP7_75t_R  g078(.A1(new_n87_), .A2(new_n93_), .B(new_n96_), .Y(new_n97_));
  AOI21x1_ASAP7_75t_R  g079(.A1(new_n39_), .A2(new_n86_), .B(new_n97_), .Y(o1));
  INVx1_ASAP7_75t_R    g080(.A(new_n47_), .Y(new_n99_));
  AO21x1_ASAP7_75t_R   g081(.A1(new_n74_), .A2(new_n45_), .B(new_n67_), .Y(new_n100_));
  NOR2x1_ASAP7_75t_R   g082(.A(p4), .B(new_n76_), .Y(new_n101_));
  NAND2x1_ASAP7_75t_R  g083(.A(p3), .B(new_n30_), .Y(new_n102_));
  NAND2x1_ASAP7_75t_R  g084(.A(p10), .B(new_n52_), .Y(new_n103_));
  NAND3x1_ASAP7_75t_R  g085(.A(new_n33_), .B(p4), .C(p2), .Y(new_n104_));
  OAI21x1_ASAP7_75t_R  g086(.A1(new_n102_), .A2(new_n103_), .B(new_n104_), .Y(new_n105_));
  NAND2x1_ASAP7_75t_R  g087(.A(new_n52_), .B(new_n76_), .Y(new_n106_));
  NAND2x1_ASAP7_75t_R  g088(.A(p2), .B(p3), .Y(new_n107_));
  OAI22x1_ASAP7_75t_R  g089(.A1(new_n106_), .A2(new_n107_), .B1(new_n102_), .B2(new_n21_), .Y(new_n108_));
  AOI221x1_ASAP7_75t_R g090(.A1(new_n100_), .A2(new_n101_), .B1(new_n105_), .B2(new_n69_), .C(new_n108_), .Y(new_n109_));
  AND3x1_ASAP7_75t_R   g091(.A(new_n83_), .B(p3), .C(new_n43_), .Y(new_n110_));
  NAND3x1_ASAP7_75t_R  g092(.A(new_n52_), .B(new_n42_), .C(p4), .Y(new_n111_));
  NAND3x1_ASAP7_75t_R  g093(.A(new_n21_), .B(p5), .C(p1), .Y(new_n112_));
  NAND3x1_ASAP7_75t_R  g094(.A(new_n111_), .B(new_n112_), .C(new_n45_), .Y(new_n113_));
  OA21x2_ASAP7_75t_R   g095(.A1(new_n45_), .A2(new_n83_), .B(new_n25_), .Y(new_n114_));
  AND2x2_ASAP7_75t_R   g096(.A(p5), .B(p6), .Y(new_n115_));
  NAND2x1_ASAP7_75t_R  g097(.A(p4), .B(p3), .Y(new_n116_));
  AND3x1_ASAP7_75t_R   g098(.A(p4), .B(p2), .C(p3), .Y(new_n117_));
  AO22x1_ASAP7_75t_R   g099(.A1(new_n115_), .A2(new_n116_), .B1(new_n117_), .B2(new_n59_), .Y(new_n118_));
  AOI221x1_ASAP7_75t_R g100(.A1(new_n76_), .A2(new_n110_), .B1(new_n113_), .B2(new_n114_), .C(new_n118_), .Y(new_n119_));
  OAI21x1_ASAP7_75t_R  g101(.A1(new_n99_), .A2(new_n109_), .B(new_n119_), .Y(new_n120_));
  INVx1_ASAP7_75t_R    g102(.A(new_n116_), .Y(new_n121_));
  OA21x2_ASAP7_75t_R   g103(.A1(new_n59_), .A2(new_n121_), .B(p7), .Y(new_n122_));
  OAI21x1_ASAP7_75t_R  g104(.A1(new_n59_), .A2(new_n53_), .B(new_n122_), .Y(new_n123_));
  OR3x1_ASAP7_75t_R    g105(.A(new_n21_), .B(new_n54_), .C(p7), .Y(new_n124_));
  NAND2x1_ASAP7_75t_R  g106(.A(new_n95_), .B(new_n124_), .Y(new_n125_));
  OR3x1_ASAP7_75t_R    g107(.A(new_n21_), .B(new_n43_), .C(p9), .Y(new_n126_));
  OA21x2_ASAP7_75t_R   g108(.A1(p7), .A2(p9), .B(p8), .Y(new_n127_));
  AOI22x1_ASAP7_75t_R  g109(.A1(new_n125_), .A2(new_n115_), .B1(new_n126_), .B2(new_n127_), .Y(new_n128_));
  OAI21x1_ASAP7_75t_R  g110(.A1(p9), .A2(new_n123_), .B(new_n128_), .Y(new_n129_));
  AO21x1_ASAP7_75t_R   g111(.A1(new_n19_), .A2(new_n120_), .B(new_n129_), .Y(o2));
  AND3x1_ASAP7_75t_R   g112(.A(new_n47_), .B(new_n79_), .C(new_n33_), .Y(new_n131_));
  AND3x1_ASAP7_75t_R   g113(.A(p4), .B(p5), .C(p6), .Y(new_n132_));
  AND3x1_ASAP7_75t_R   g114(.A(new_n132_), .B(new_n28_), .C(new_n76_), .Y(new_n133_));
  NOR2x1_ASAP7_75t_R   g115(.A(new_n131_), .B(new_n133_), .Y(new_n134_));
  OR3x1_ASAP7_75t_R    g116(.A(new_n134_), .B(p2), .C(new_n20_), .Y(o3));
  AND2x2_ASAP7_75t_R   g117(.A(p7), .B(p2), .Y(new_n136_));
  AO21x1_ASAP7_75t_R   g118(.A1(new_n30_), .A2(p1), .B(new_n136_), .Y(new_n137_));
  AND3x1_ASAP7_75t_R   g119(.A(new_n121_), .B(new_n54_), .C(new_n115_), .Y(new_n138_));
  AOI21x1_ASAP7_75t_R  g120(.A1(p7), .A2(new_n132_), .B(new_n54_), .Y(new_n139_));
  AO21x1_ASAP7_75t_R   g121(.A1(new_n137_), .A2(new_n138_), .B(new_n139_), .Y(new_n140_));
  INVx1_ASAP7_75t_R    g122(.A(new_n74_), .Y(new_n141_));
  AOI21x1_ASAP7_75t_R  g123(.A1(new_n79_), .A2(new_n141_), .B(new_n110_), .Y(new_n142_));
  NOR2x1_ASAP7_75t_R   g124(.A(p4), .B(p6), .Y(new_n143_));
  AO21x1_ASAP7_75t_R   g125(.A1(new_n43_), .A2(new_n69_), .B(new_n83_), .Y(new_n144_));
  AO221x2_ASAP7_75t_R  g126(.A1(p3), .A2(new_n143_), .B1(new_n144_), .B2(new_n45_), .C(new_n53_), .Y(new_n145_));
  OAI21x1_ASAP7_75t_R  g127(.A1(new_n90_), .A2(new_n142_), .B(new_n145_), .Y(new_n146_));
  OA21x2_ASAP7_75t_R   g128(.A1(new_n25_), .A2(new_n140_), .B(new_n39_), .Y(new_n147_));
  OAI21x1_ASAP7_75t_R  g129(.A1(new_n140_), .A2(new_n146_), .B(new_n147_), .Y(o4));
  AND3x1_ASAP7_75t_R   g130(.A(new_n141_), .B(new_n35_), .C(new_n143_), .Y(new_n149_));
  AO21x1_ASAP7_75t_R   g131(.A1(p7), .A2(new_n132_), .B(new_n149_), .Y(new_n150_));
  AO21x1_ASAP7_75t_R   g132(.A1(new_n136_), .A2(new_n132_), .B(p1), .Y(new_n151_));
  AND2x2_ASAP7_75t_R   g133(.A(p3), .B(new_n151_), .Y(new_n152_));
  AND3x1_ASAP7_75t_R   g134(.A(new_n45_), .B(new_n83_), .C(p1), .Y(new_n153_));
  OR3x1_ASAP7_75t_R    g135(.A(new_n153_), .B(new_n99_), .C(new_n79_), .Y(new_n154_));
  NAND2x1_ASAP7_75t_R  g136(.A(new_n19_), .B(new_n154_), .Y(new_n155_));
  AO21x1_ASAP7_75t_R   g137(.A1(new_n150_), .A2(new_n152_), .B(new_n155_), .Y(o5));
  OR3x1_ASAP7_75t_R    g138(.A(new_n153_), .B(new_n20_), .C(new_n99_), .Y(o6));
endmodule


