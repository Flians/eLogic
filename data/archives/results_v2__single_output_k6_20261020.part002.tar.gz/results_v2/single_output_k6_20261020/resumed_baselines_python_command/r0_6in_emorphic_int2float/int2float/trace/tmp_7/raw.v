// Benchmark "/tmp/" written by ABC on Tue Oct 20 17:46:14 2026

module \/tmp/  ( 
    p3, p5, p8, p0, p2, p4, p10, p1, p7, p9, p6,
    o0, o1, o2, o3, o4, o5, o6  );
  input  p3, p5, p8, p0, p2, p4, p10, p1, p7, p9, p6;
  output o0, o1, o2, o3, o4, o5, o6;
  wire new_n19_, new_n20_, new_n21_, new_n22_, new_n23_, new_n24_, new_n25_,
    new_n26_, new_n27_, new_n28_, new_n29_, new_n30_, new_n31_, new_n32_,
    new_n33_, new_n34_, new_n35_, new_n36_, new_n37_, new_n38_, new_n39_,
    new_n40_, new_n41_, new_n42_, new_n43_, new_n44_, new_n45_, new_n46_,
    new_n47_, new_n48_, new_n49_, new_n50_, new_n51_, new_n52_, new_n53_,
    new_n54_, new_n55_, new_n56_, new_n57_, new_n58_, new_n59_, new_n60_,
    new_n61_, new_n62_, new_n63_, new_n64_, new_n65_, new_n66_, new_n67_,
    new_n68_, new_n70_, new_n71_, new_n72_, new_n73_, new_n74_, new_n75_,
    new_n76_, new_n77_, new_n78_, new_n79_, new_n80_, new_n81_, new_n82_,
    new_n83_, new_n84_, new_n85_, new_n86_, new_n87_, new_n88_, new_n89_,
    new_n90_, new_n91_, new_n92_, new_n93_, new_n94_, new_n95_, new_n96_,
    new_n97_, new_n98_, new_n99_, new_n100_, new_n101_, new_n102_,
    new_n103_, new_n105_, new_n106_, new_n107_, new_n108_, new_n109_,
    new_n110_, new_n111_, new_n112_, new_n113_, new_n114_, new_n115_,
    new_n116_, new_n117_, new_n118_, new_n119_, new_n120_, new_n121_,
    new_n122_, new_n123_, new_n124_, new_n125_, new_n126_, new_n127_,
    new_n128_, new_n129_, new_n130_, new_n131_, new_n132_, new_n133_,
    new_n134_, new_n136_, new_n137_, new_n138_, new_n139_, new_n140_,
    new_n142_, new_n143_, new_n144_, new_n145_, new_n146_, new_n147_,
    new_n148_, new_n149_, new_n150_, new_n151_, new_n153_, new_n154_,
    new_n155_, new_n156_, new_n157_, new_n158_;
  INVx1_ASAP7_75t_R    g000(.A(p6), .Y(new_n19_));
  AOI21x1_ASAP7_75t_R  g001(.A1(p3), .A2(p2), .B(new_n19_), .Y(new_n20_));
  INVx1_ASAP7_75t_R    g002(.A(p3), .Y(new_n21_));
  INVx1_ASAP7_75t_R    g003(.A(p2), .Y(new_n22_));
  NAND2x1_ASAP7_75t_R  g004(.A(new_n21_), .B(new_n22_), .Y(new_n23_));
  NOR2x1_ASAP7_75t_R   g005(.A(p1), .B(p6), .Y(new_n24_));
  AND3x1_ASAP7_75t_R   g006(.A(p0), .B(p2), .C(p4), .Y(new_n25_));
  AOI22x1_ASAP7_75t_R  g007(.A1(new_n20_), .A2(new_n23_), .B1(new_n24_), .B2(new_n25_), .Y(new_n26_));
  INVx1_ASAP7_75t_R    g008(.A(p4), .Y(new_n27_));
  INVx1_ASAP7_75t_R    g009(.A(p7), .Y(new_n28_));
  OR3x1_ASAP7_75t_R    g010(.A(new_n27_), .B(new_n28_), .C(p3), .Y(new_n29_));
  OAI21x1_ASAP7_75t_R  g011(.A1(p7), .A2(new_n26_), .B(new_n29_), .Y(new_n30_));
  NAND2x1_ASAP7_75t_R  g012(.A(p3), .B(p0), .Y(new_n31_));
  OAI21x1_ASAP7_75t_R  g013(.A1(p3), .A2(new_n28_), .B(new_n31_), .Y(new_n32_));
  NAND2x1_ASAP7_75t_R  g014(.A(p10), .B(new_n32_), .Y(new_n33_));
  NOR2x1_ASAP7_75t_R   g015(.A(p5), .B(p6), .Y(new_n34_));
  AO21x1_ASAP7_75t_R   g016(.A1(p3), .A2(p0), .B(p10), .Y(new_n35_));
  AND2x2_ASAP7_75t_R   g017(.A(new_n34_), .B(new_n35_), .Y(new_n36_));
  AND3x1_ASAP7_75t_R   g018(.A(new_n27_), .B(p3), .C(p7), .Y(new_n37_));
  AO31x2_ASAP7_75t_R   g019(.A1(new_n33_), .A2(new_n27_), .A3(new_n36_), .B(new_n37_), .Y(new_n38_));
  NOR2x1_ASAP7_75t_R   g020(.A(p8), .B(p9), .Y(new_n39_));
  OAI21x1_ASAP7_75t_R  g021(.A1(new_n30_), .A2(new_n38_), .B(new_n39_), .Y(new_n40_));
  AND2x2_ASAP7_75t_R   g022(.A(p3), .B(p7), .Y(new_n41_));
  NAND2x1_ASAP7_75t_R  g023(.A(p3), .B(p2), .Y(new_n42_));
  INVx1_ASAP7_75t_R    g024(.A(new_n42_), .Y(new_n43_));
  NOR2x1_ASAP7_75t_R   g025(.A(p3), .B(new_n19_), .Y(new_n44_));
  INVx1_ASAP7_75t_R    g026(.A(p1), .Y(new_n45_));
  NAND2x1_ASAP7_75t_R  g027(.A(p0), .B(new_n45_), .Y(new_n46_));
  INVx1_ASAP7_75t_R    g028(.A(p5), .Y(new_n47_));
  NAND2x1_ASAP7_75t_R  g029(.A(p4), .B(new_n47_), .Y(new_n48_));
  OR5x1_ASAP7_75t_R    g030(.A(new_n41_), .B(new_n43_), .C(new_n44_), .D(new_n46_), .E(new_n48_), .Y(new_n49_));
  INVx1_ASAP7_75t_R    g031(.A(p8), .Y(new_n50_));
  OR3x1_ASAP7_75t_R    g032(.A(new_n47_), .B(new_n50_), .C(p4), .Y(new_n51_));
  NOR2x1_ASAP7_75t_R   g033(.A(p7), .B(p6), .Y(new_n52_));
  INVx1_ASAP7_75t_R    g034(.A(p0), .Y(new_n53_));
  AND3x1_ASAP7_75t_R   g035(.A(new_n52_), .B(new_n53_), .C(p1), .Y(new_n54_));
  INVx1_ASAP7_75t_R    g036(.A(new_n48_), .Y(new_n55_));
  OAI21x1_ASAP7_75t_R  g037(.A1(p8), .A2(new_n54_), .B(new_n55_), .Y(new_n56_));
  AO31x2_ASAP7_75t_R   g038(.A1(new_n49_), .A2(new_n51_), .A3(new_n56_), .B(p9), .Y(new_n57_));
  INVx1_ASAP7_75t_R    g039(.A(p9), .Y(new_n58_));
  NOR2x1_ASAP7_75t_R   g040(.A(p8), .B(p7), .Y(new_n59_));
  INVx1_ASAP7_75t_R    g041(.A(new_n59_), .Y(new_n60_));
  AND2x2_ASAP7_75t_R   g042(.A(p2), .B(p1), .Y(new_n61_));
  NOR2x1_ASAP7_75t_R   g043(.A(p2), .B(p1), .Y(new_n62_));
  OR3x1_ASAP7_75t_R    g044(.A(new_n60_), .B(new_n61_), .C(new_n62_), .Y(new_n63_));
  NAND2x1_ASAP7_75t_R  g045(.A(p5), .B(new_n19_), .Y(new_n64_));
  NAND2x1_ASAP7_75t_R  g046(.A(p6), .B(new_n47_), .Y(new_n65_));
  OR3x1_ASAP7_75t_R    g047(.A(new_n47_), .B(new_n50_), .C(new_n28_), .Y(new_n66_));
  AO21x1_ASAP7_75t_R   g048(.A1(new_n65_), .A2(new_n66_), .B(new_n58_), .Y(new_n67_));
  AO22x1_ASAP7_75t_R   g049(.A1(new_n58_), .A2(new_n63_), .B1(new_n64_), .B2(new_n67_), .Y(new_n68_));
  NAND3x1_ASAP7_75t_R  g050(.A(new_n40_), .B(new_n57_), .C(new_n68_), .Y(o0));
  NAND2x1_ASAP7_75t_R  g051(.A(p6), .B(new_n42_), .Y(new_n70_));
  NAND2x1_ASAP7_75t_R  g052(.A(p8), .B(new_n19_), .Y(new_n71_));
  OAI21x1_ASAP7_75t_R  g053(.A1(new_n60_), .A2(new_n70_), .B(new_n71_), .Y(new_n72_));
  OAI21x1_ASAP7_75t_R  g054(.A1(new_n47_), .A2(new_n72_), .B(new_n27_), .Y(new_n73_));
  NAND2x1_ASAP7_75t_R  g055(.A(p0), .B(p1), .Y(new_n74_));
  NAND2x1_ASAP7_75t_R  g056(.A(p3), .B(new_n19_), .Y(new_n75_));
  NOR2x1_ASAP7_75t_R   g057(.A(p10), .B(new_n45_), .Y(new_n76_));
  AOI211x1_ASAP7_75t_R g058(.A1(p10), .A2(new_n74_), .B(new_n75_), .C(new_n76_), .Y(new_n77_));
  OAI22x1_ASAP7_75t_R  g059(.A1(p3), .A2(p8), .B1(p1), .B2(p6), .Y(new_n78_));
  AO22x1_ASAP7_75t_R   g060(.A1(new_n50_), .A2(p7), .B1(new_n53_), .B2(new_n78_), .Y(new_n79_));
  NOR3x1_ASAP7_75t_R   g061(.A(new_n72_), .B(new_n77_), .C(new_n79_), .Y(new_n80_));
  AND2x2_ASAP7_75t_R   g062(.A(p5), .B(p4), .Y(new_n81_));
  NOR2x1_ASAP7_75t_R   g063(.A(p3), .B(p8), .Y(new_n82_));
  AOI211x1_ASAP7_75t_R g064(.A1(p8), .A2(new_n19_), .B(new_n59_), .C(new_n82_), .Y(new_n83_));
  AND2x2_ASAP7_75t_R   g065(.A(p0), .B(p1), .Y(new_n84_));
  AO21x1_ASAP7_75t_R   g066(.A1(new_n34_), .A2(new_n84_), .B(p3), .Y(new_n85_));
  OA21x2_ASAP7_75t_R   g067(.A1(p8), .A2(p7), .B(p3), .Y(new_n86_));
  NAND2x1_ASAP7_75t_R  g068(.A(p2), .B(p4), .Y(new_n87_));
  AOI21x1_ASAP7_75t_R  g069(.A1(p0), .A2(p1), .B(p6), .Y(new_n88_));
  NOR3x1_ASAP7_75t_R   g070(.A(new_n86_), .B(new_n87_), .C(new_n88_), .Y(new_n89_));
  NAND2x1_ASAP7_75t_R  g071(.A(p7), .B(new_n82_), .Y(new_n90_));
  AOI21x1_ASAP7_75t_R  g072(.A1(new_n71_), .A2(new_n90_), .B(p5), .Y(new_n91_));
  AOI221x1_ASAP7_75t_R g073(.A1(new_n81_), .A2(new_n83_), .B1(new_n85_), .B2(new_n89_), .C(new_n91_), .Y(new_n92_));
  OAI21x1_ASAP7_75t_R  g074(.A1(new_n73_), .A2(new_n80_), .B(new_n92_), .Y(new_n93_));
  AO21x1_ASAP7_75t_R   g075(.A1(p5), .A2(p6), .B(p7), .Y(new_n94_));
  AO32x1_ASAP7_75t_R   g076(.A1(new_n88_), .A2(new_n22_), .A3(p4), .B1(p5), .B2(new_n19_), .Y(new_n95_));
  NOR2x1_ASAP7_75t_R   g077(.A(new_n47_), .B(new_n82_), .Y(new_n96_));
  NAND3x1_ASAP7_75t_R  g078(.A(p3), .B(p2), .C(p1), .Y(new_n97_));
  OAI22x1_ASAP7_75t_R  g079(.A1(new_n96_), .A2(new_n61_), .B1(p8), .B2(new_n97_), .Y(new_n98_));
  AOI21x1_ASAP7_75t_R  g080(.A1(new_n95_), .A2(new_n98_), .B(p9), .Y(new_n99_));
  AND2x2_ASAP7_75t_R   g081(.A(p5), .B(p6), .Y(new_n100_));
  AND3x1_ASAP7_75t_R   g082(.A(new_n100_), .B(p7), .C(p9), .Y(new_n101_));
  NAND2x1_ASAP7_75t_R  g083(.A(new_n50_), .B(new_n101_), .Y(new_n102_));
  OAI21x1_ASAP7_75t_R  g084(.A1(new_n94_), .A2(new_n99_), .B(new_n102_), .Y(new_n103_));
  AOI21x1_ASAP7_75t_R  g085(.A1(new_n58_), .A2(new_n93_), .B(new_n103_), .Y(o1));
  AND2x2_ASAP7_75t_R   g086(.A(p0), .B(p10), .Y(new_n105_));
  OR3x1_ASAP7_75t_R    g087(.A(new_n105_), .B(p2), .C(p4), .Y(new_n106_));
  AO21x1_ASAP7_75t_R   g088(.A1(p10), .A2(new_n47_), .B(p4), .Y(new_n107_));
  AO21x1_ASAP7_75t_R   g089(.A1(p0), .A2(p1), .B(p5), .Y(new_n108_));
  NAND3x1_ASAP7_75t_R  g090(.A(new_n107_), .B(p2), .C(new_n108_), .Y(new_n109_));
  AO21x1_ASAP7_75t_R   g091(.A1(new_n106_), .A2(new_n109_), .B(new_n21_), .Y(new_n110_));
  AO21x1_ASAP7_75t_R   g092(.A1(p5), .A2(new_n97_), .B(new_n62_), .Y(new_n111_));
  NOR2x1_ASAP7_75t_R   g093(.A(p3), .B(p5), .Y(new_n112_));
  AND2x2_ASAP7_75t_R   g094(.A(p0), .B(p2), .Y(new_n113_));
  OAI21x1_ASAP7_75t_R  g095(.A1(new_n27_), .A2(new_n113_), .B(p1), .Y(new_n114_));
  NOR2x1_ASAP7_75t_R   g096(.A(p0), .B(new_n87_), .Y(new_n115_));
  AND3x1_ASAP7_75t_R   g097(.A(new_n50_), .B(new_n28_), .C(new_n58_), .Y(new_n116_));
  OAI21x1_ASAP7_75t_R  g098(.A1(new_n65_), .A2(new_n115_), .B(new_n116_), .Y(new_n117_));
  AOI221x1_ASAP7_75t_R g099(.A1(new_n27_), .A2(new_n111_), .B1(new_n112_), .B2(new_n114_), .C(new_n117_), .Y(new_n118_));
  NAND2x1_ASAP7_75t_R  g100(.A(p3), .B(p4), .Y(new_n119_));
  OA21x2_ASAP7_75t_R   g101(.A1(new_n119_), .A2(new_n64_), .B(new_n65_), .Y(new_n120_));
  NAND2x1_ASAP7_75t_R  g102(.A(p7), .B(new_n58_), .Y(new_n121_));
  OR3x1_ASAP7_75t_R    g103(.A(new_n27_), .B(new_n19_), .C(p9), .Y(new_n122_));
  NOR2x1_ASAP7_75t_R   g104(.A(p7), .B(p9), .Y(new_n123_));
  NOR2x1_ASAP7_75t_R   g105(.A(new_n50_), .B(new_n123_), .Y(new_n124_));
  AND5x1_ASAP7_75t_R   g106(.A(p5), .B(new_n28_), .C(p8), .D(p4), .E(p6), .Y(new_n125_));
  AOI211x1_ASAP7_75t_R g107(.A1(new_n122_), .A2(new_n124_), .B(new_n125_), .C(new_n101_), .Y(new_n126_));
  OAI21x1_ASAP7_75t_R  g108(.A1(new_n120_), .A2(new_n121_), .B(new_n126_), .Y(new_n127_));
  INVx1_ASAP7_75t_R    g109(.A(new_n39_), .Y(new_n128_));
  INVx1_ASAP7_75t_R    g110(.A(new_n119_), .Y(new_n129_));
  AND3x1_ASAP7_75t_R   g111(.A(new_n47_), .B(p2), .C(p6), .Y(new_n130_));
  AND3x1_ASAP7_75t_R   g112(.A(new_n119_), .B(p5), .C(p6), .Y(new_n131_));
  AND3x1_ASAP7_75t_R   g113(.A(new_n81_), .B(p3), .C(new_n24_), .Y(new_n132_));
  AOI211x1_ASAP7_75t_R g114(.A1(new_n129_), .A2(new_n130_), .B(new_n131_), .C(new_n132_), .Y(new_n133_));
  NOR2x1_ASAP7_75t_R   g115(.A(new_n128_), .B(new_n133_), .Y(new_n134_));
  AO211x2_ASAP7_75t_R  g116(.A1(new_n110_), .A2(new_n118_), .B(new_n127_), .C(new_n134_), .Y(o2));
  NOR2x1_ASAP7_75t_R   g117(.A(p5), .B(p4), .Y(new_n136_));
  AND3x1_ASAP7_75t_R   g118(.A(new_n136_), .B(new_n52_), .C(new_n21_), .Y(new_n137_));
  AND3x1_ASAP7_75t_R   g119(.A(p5), .B(p4), .C(p6), .Y(new_n138_));
  AND3x1_ASAP7_75t_R   g120(.A(new_n138_), .B(new_n41_), .C(new_n45_), .Y(new_n139_));
  NOR2x1_ASAP7_75t_R   g121(.A(new_n137_), .B(new_n139_), .Y(new_n140_));
  OR3x1_ASAP7_75t_R    g122(.A(new_n140_), .B(p2), .C(new_n128_), .Y(o3));
  AO21x1_ASAP7_75t_R   g123(.A1(new_n19_), .A2(new_n84_), .B(new_n81_), .Y(new_n142_));
  NAND2x1_ASAP7_75t_R  g124(.A(new_n43_), .B(new_n142_), .Y(new_n143_));
  NOR2x1_ASAP7_75t_R   g125(.A(p4), .B(p6), .Y(new_n144_));
  NAND2x1_ASAP7_75t_R  g126(.A(p3), .B(new_n144_), .Y(new_n145_));
  AO32x1_ASAP7_75t_R   g127(.A1(new_n81_), .A2(p3), .A3(new_n19_), .B1(new_n105_), .B2(new_n136_), .Y(new_n146_));
  AO32x1_ASAP7_75t_R   g128(.A1(new_n143_), .A2(new_n64_), .A3(new_n145_), .B1(new_n61_), .B2(new_n146_), .Y(new_n147_));
  NOR2x1_ASAP7_75t_R   g129(.A(p7), .B(new_n22_), .Y(new_n148_));
  OR5x1_ASAP7_75t_R    g130(.A(new_n47_), .B(new_n148_), .C(new_n19_), .D(new_n62_), .E(new_n119_), .Y(new_n149_));
  AO21x1_ASAP7_75t_R   g131(.A1(p7), .A2(new_n138_), .B(p9), .Y(new_n150_));
  AOI22x1_ASAP7_75t_R  g132(.A1(new_n149_), .A2(new_n50_), .B1(new_n128_), .B2(new_n150_), .Y(new_n151_));
  AOI21x1_ASAP7_75t_R  g133(.A1(new_n123_), .A2(new_n147_), .B(new_n151_), .Y(o4));
  AND5x1_ASAP7_75t_R   g134(.A(p10), .B(new_n113_), .C(p1), .D(new_n28_), .E(new_n144_), .Y(new_n153_));
  OA211x2_ASAP7_75t_R  g135(.A1(p2), .A2(p1), .B(new_n138_), .C(p7), .Y(new_n154_));
  OA21x2_ASAP7_75t_R   g136(.A1(new_n153_), .A2(new_n154_), .B(p3), .Y(new_n155_));
  AND3x1_ASAP7_75t_R   g137(.A(new_n81_), .B(new_n61_), .C(p3), .Y(new_n156_));
  INVx1_ASAP7_75t_R    g138(.A(new_n52_), .Y(new_n157_));
  NOR3x1_ASAP7_75t_R   g139(.A(new_n156_), .B(new_n136_), .C(new_n157_), .Y(new_n158_));
  OR3x1_ASAP7_75t_R    g140(.A(new_n155_), .B(new_n128_), .C(new_n158_), .Y(o5));
  OR3x1_ASAP7_75t_R    g141(.A(new_n156_), .B(new_n128_), .C(new_n157_), .Y(o6));
endmodule


