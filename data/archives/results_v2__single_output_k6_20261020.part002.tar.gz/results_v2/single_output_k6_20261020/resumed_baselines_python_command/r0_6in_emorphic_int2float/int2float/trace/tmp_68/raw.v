// Benchmark "/tmp/" written by ABC on Tue Oct 20 17:46:21 2026

module \/tmp/  ( 
    p9, p6, p0, p10, p7, p2, p3, p8, p1, p4, p5,
    o0, o1, o2, o3, o4, o5, o6  );
  input  p9, p6, p0, p10, p7, p2, p3, p8, p1, p4, p5;
  output o0, o1, o2, o3, o4, o5, o6;
  wire new_n19_, new_n20_, new_n21_, new_n22_, new_n23_, new_n24_, new_n25_,
    new_n26_, new_n27_, new_n28_, new_n29_, new_n30_, new_n31_, new_n32_,
    new_n33_, new_n34_, new_n35_, new_n36_, new_n37_, new_n38_, new_n39_,
    new_n40_, new_n41_, new_n42_, new_n43_, new_n44_, new_n45_, new_n46_,
    new_n47_, new_n48_, new_n49_, new_n50_, new_n51_, new_n52_, new_n53_,
    new_n54_, new_n55_, new_n56_, new_n57_, new_n58_, new_n59_, new_n60_,
    new_n61_, new_n62_, new_n63_, new_n65_, new_n66_, new_n67_, new_n68_,
    new_n69_, new_n70_, new_n71_, new_n72_, new_n73_, new_n74_, new_n75_,
    new_n76_, new_n77_, new_n78_, new_n79_, new_n80_, new_n81_, new_n82_,
    new_n83_, new_n84_, new_n85_, new_n86_, new_n87_, new_n88_, new_n89_,
    new_n90_, new_n91_, new_n92_, new_n93_, new_n94_, new_n95_, new_n96_,
    new_n97_, new_n98_, new_n100_, new_n101_, new_n102_, new_n103_,
    new_n104_, new_n105_, new_n106_, new_n107_, new_n108_, new_n109_,
    new_n110_, new_n111_, new_n112_, new_n113_, new_n114_, new_n115_,
    new_n116_, new_n117_, new_n118_, new_n119_, new_n120_, new_n121_,
    new_n122_, new_n123_, new_n124_, new_n125_, new_n126_, new_n127_,
    new_n128_, new_n130_, new_n131_, new_n132_, new_n133_, new_n135_,
    new_n136_, new_n137_, new_n138_, new_n139_, new_n140_, new_n141_,
    new_n142_, new_n143_, new_n144_, new_n145_, new_n147_, new_n148_,
    new_n149_, new_n150_, new_n151_;
  INVx1_ASAP7_75t_R    g000(.A(p3), .Y(new_n19_));
  INVx1_ASAP7_75t_R    g001(.A(p4), .Y(new_n20_));
  AO21x1_ASAP7_75t_R   g002(.A1(p7), .A2(new_n19_), .B(new_n20_), .Y(new_n21_));
  INVx1_ASAP7_75t_R    g003(.A(p10), .Y(new_n22_));
  NAND2x1_ASAP7_75t_R  g004(.A(p0), .B(p3), .Y(new_n23_));
  AOI211x1_ASAP7_75t_R g005(.A1(new_n22_), .A2(new_n23_), .B(p6), .C(p5), .Y(new_n24_));
  NAND2x1_ASAP7_75t_R  g006(.A(p7), .B(new_n19_), .Y(new_n25_));
  AO21x1_ASAP7_75t_R   g007(.A1(new_n23_), .A2(new_n25_), .B(new_n22_), .Y(new_n26_));
  AO21x1_ASAP7_75t_R   g008(.A1(p7), .A2(p3), .B(p4), .Y(new_n27_));
  AO21x1_ASAP7_75t_R   g009(.A1(new_n24_), .A2(new_n26_), .B(new_n27_), .Y(new_n28_));
  INVx1_ASAP7_75t_R    g010(.A(p6), .Y(new_n29_));
  INVx1_ASAP7_75t_R    g011(.A(p1), .Y(new_n30_));
  AND5x1_ASAP7_75t_R   g012(.A(new_n29_), .B(new_n30_), .C(p0), .D(p2), .E(p4), .Y(new_n31_));
  INVx1_ASAP7_75t_R    g013(.A(p2), .Y(new_n32_));
  NAND2x1_ASAP7_75t_R  g014(.A(p3), .B(new_n32_), .Y(new_n33_));
  NAND2x1_ASAP7_75t_R  g015(.A(p2), .B(new_n19_), .Y(new_n34_));
  AOI21x1_ASAP7_75t_R  g016(.A1(new_n33_), .A2(new_n34_), .B(new_n29_), .Y(new_n35_));
  INVx1_ASAP7_75t_R    g017(.A(p7), .Y(new_n36_));
  OA21x2_ASAP7_75t_R   g018(.A1(new_n31_), .A2(new_n35_), .B(new_n36_), .Y(new_n37_));
  AOI21x1_ASAP7_75t_R  g019(.A1(new_n21_), .A2(new_n28_), .B(new_n37_), .Y(new_n38_));
  NOR2x1_ASAP7_75t_R   g020(.A(p9), .B(p8), .Y(new_n39_));
  INVx1_ASAP7_75t_R    g021(.A(new_n39_), .Y(new_n40_));
  INVx1_ASAP7_75t_R    g022(.A(p9), .Y(new_n41_));
  NOR2x1_ASAP7_75t_R   g023(.A(p5), .B(new_n20_), .Y(new_n42_));
  INVx1_ASAP7_75t_R    g024(.A(new_n42_), .Y(new_n43_));
  INVx1_ASAP7_75t_R    g025(.A(p0), .Y(new_n44_));
  NOR2x1_ASAP7_75t_R   g026(.A(p3), .B(new_n29_), .Y(new_n45_));
  AND2x2_ASAP7_75t_R   g027(.A(p7), .B(p3), .Y(new_n46_));
  AND2x2_ASAP7_75t_R   g028(.A(p2), .B(p3), .Y(new_n47_));
  OR5x1_ASAP7_75t_R    g029(.A(new_n44_), .B(new_n45_), .C(p1), .D(new_n46_), .E(new_n47_), .Y(new_n48_));
  NOR2x1_ASAP7_75t_R   g030(.A(p6), .B(p7), .Y(new_n49_));
  AO31x2_ASAP7_75t_R   g031(.A1(new_n49_), .A2(new_n44_), .A3(p1), .B(p8), .Y(new_n50_));
  AND2x2_ASAP7_75t_R   g032(.A(p8), .B(p5), .Y(new_n51_));
  AOI22x1_ASAP7_75t_R  g033(.A1(new_n50_), .A2(new_n42_), .B1(new_n20_), .B2(new_n51_), .Y(new_n52_));
  OAI21x1_ASAP7_75t_R  g034(.A1(new_n43_), .A2(new_n48_), .B(new_n52_), .Y(new_n53_));
  NOR2x1_ASAP7_75t_R   g035(.A(p7), .B(p8), .Y(new_n54_));
  XOR2x2_ASAP7_75t_R   g036(.A(p2), .B(p1), .Y(new_n55_));
  AO21x1_ASAP7_75t_R   g037(.A1(new_n54_), .A2(new_n55_), .B(p9), .Y(new_n56_));
  INVx1_ASAP7_75t_R    g038(.A(p5), .Y(new_n57_));
  NOR2x1_ASAP7_75t_R   g039(.A(p6), .B(new_n57_), .Y(new_n58_));
  NAND2x1_ASAP7_75t_R  g040(.A(p6), .B(new_n57_), .Y(new_n59_));
  NAND2x1_ASAP7_75t_R  g041(.A(p7), .B(new_n51_), .Y(new_n60_));
  AOI21x1_ASAP7_75t_R  g042(.A1(new_n59_), .A2(new_n60_), .B(new_n41_), .Y(new_n61_));
  AO21x1_ASAP7_75t_R   g043(.A1(new_n56_), .A2(new_n58_), .B(new_n61_), .Y(new_n62_));
  AOI21x1_ASAP7_75t_R  g044(.A1(new_n41_), .A2(new_n53_), .B(new_n62_), .Y(new_n63_));
  OAI21x1_ASAP7_75t_R  g045(.A1(new_n38_), .A2(new_n40_), .B(new_n63_), .Y(o0));
  NAND2x1_ASAP7_75t_R  g046(.A(p2), .B(p3), .Y(new_n65_));
  INVx1_ASAP7_75t_R    g047(.A(p8), .Y(new_n66_));
  AND3x1_ASAP7_75t_R   g048(.A(new_n36_), .B(new_n66_), .C(p6), .Y(new_n67_));
  NOR2x1_ASAP7_75t_R   g049(.A(p6), .B(new_n66_), .Y(new_n68_));
  AO21x1_ASAP7_75t_R   g050(.A1(new_n65_), .A2(new_n67_), .B(new_n68_), .Y(new_n69_));
  OAI21x1_ASAP7_75t_R  g051(.A1(p6), .A2(p5), .B(new_n19_), .Y(new_n70_));
  OAI21x1_ASAP7_75t_R  g052(.A1(p7), .A2(p8), .B(p3), .Y(new_n71_));
  AO21x1_ASAP7_75t_R   g053(.A1(p0), .A2(p1), .B(p6), .Y(new_n72_));
  AND5x1_ASAP7_75t_R   g054(.A(p2), .B(new_n70_), .C(p4), .D(new_n71_), .E(new_n72_), .Y(new_n73_));
  AOI21x1_ASAP7_75t_R  g055(.A1(new_n20_), .A2(new_n69_), .B(new_n73_), .Y(new_n74_));
  NAND2x1_ASAP7_75t_R  g056(.A(p0), .B(p1), .Y(new_n75_));
  NAND2x1_ASAP7_75t_R  g057(.A(p3), .B(new_n29_), .Y(new_n76_));
  NOR2x1_ASAP7_75t_R   g058(.A(p10), .B(new_n30_), .Y(new_n77_));
  AOI211x1_ASAP7_75t_R g059(.A1(p10), .A2(new_n75_), .B(new_n76_), .C(new_n77_), .Y(new_n78_));
  NOR2x1_ASAP7_75t_R   g060(.A(p3), .B(p8), .Y(new_n79_));
  AOI21x1_ASAP7_75t_R  g061(.A1(new_n29_), .A2(new_n30_), .B(new_n79_), .Y(new_n80_));
  OAI22x1_ASAP7_75t_R  g062(.A1(new_n80_), .A2(p0), .B1(new_n36_), .B2(p8), .Y(new_n81_));
  NOR2x1_ASAP7_75t_R   g063(.A(p4), .B(p5), .Y(new_n82_));
  OAI21x1_ASAP7_75t_R  g064(.A1(new_n78_), .A2(new_n81_), .B(new_n82_), .Y(new_n83_));
  AND2x2_ASAP7_75t_R   g065(.A(p4), .B(p5), .Y(new_n84_));
  OR3x1_ASAP7_75t_R    g066(.A(new_n68_), .B(new_n84_), .C(new_n79_), .Y(new_n85_));
  OAI21x1_ASAP7_75t_R  g067(.A1(new_n79_), .A2(new_n68_), .B(p5), .Y(new_n86_));
  INVx1_ASAP7_75t_R    g068(.A(new_n54_), .Y(new_n87_));
  NAND3x1_ASAP7_75t_R  g069(.A(new_n85_), .B(new_n86_), .C(new_n87_), .Y(new_n88_));
  NAND3x1_ASAP7_75t_R  g070(.A(new_n74_), .B(new_n83_), .C(new_n88_), .Y(new_n89_));
  AND3x1_ASAP7_75t_R   g071(.A(new_n66_), .B(p2), .C(p1), .Y(new_n90_));
  OR3x1_ASAP7_75t_R    g072(.A(new_n90_), .B(new_n57_), .C(new_n79_), .Y(new_n91_));
  OA22x2_ASAP7_75t_R   g073(.A1(new_n34_), .A2(new_n30_), .B1(p5), .B2(new_n75_), .Y(new_n92_));
  AOI211x1_ASAP7_75t_R g074(.A1(p2), .A2(new_n57_), .B(p6), .C(new_n82_), .Y(new_n93_));
  NAND3x1_ASAP7_75t_R  g075(.A(new_n91_), .B(new_n92_), .C(new_n93_), .Y(new_n94_));
  AO21x1_ASAP7_75t_R   g076(.A1(p6), .A2(p5), .B(p7), .Y(new_n95_));
  NAND2x1_ASAP7_75t_R  g077(.A(p6), .B(p5), .Y(new_n96_));
  OR3x1_ASAP7_75t_R    g078(.A(new_n96_), .B(new_n36_), .C(p8), .Y(new_n97_));
  AOI22x1_ASAP7_75t_R  g079(.A1(new_n94_), .A2(new_n41_), .B1(new_n95_), .B2(new_n97_), .Y(new_n98_));
  AOI21x1_ASAP7_75t_R  g080(.A1(new_n41_), .A2(new_n89_), .B(new_n98_), .Y(o1));
  NAND3x1_ASAP7_75t_R  g081(.A(new_n57_), .B(p2), .C(p3), .Y(new_n100_));
  OAI22x1_ASAP7_75t_R  g082(.A1(new_n100_), .A2(p1), .B1(new_n20_), .B2(new_n33_), .Y(new_n101_));
  OAI21x1_ASAP7_75t_R  g083(.A1(p1), .A2(new_n101_), .B(new_n49_), .Y(new_n102_));
  AND2x2_ASAP7_75t_R   g084(.A(p0), .B(p10), .Y(new_n103_));
  OAI22x1_ASAP7_75t_R  g085(.A1(new_n103_), .A2(new_n65_), .B1(p3), .B2(p5), .Y(new_n104_));
  NAND2x1_ASAP7_75t_R  g086(.A(p10), .B(new_n57_), .Y(new_n105_));
  NAND3x1_ASAP7_75t_R  g087(.A(new_n19_), .B(p2), .C(p4), .Y(new_n106_));
  OAI21x1_ASAP7_75t_R  g088(.A1(new_n33_), .A2(new_n105_), .B(new_n106_), .Y(new_n107_));
  AOI221x1_ASAP7_75t_R g089(.A1(new_n20_), .A2(new_n104_), .B1(new_n107_), .B2(p0), .C(new_n101_), .Y(new_n108_));
  NAND2x1_ASAP7_75t_R  g090(.A(p4), .B(p5), .Y(new_n109_));
  NOR2x1_ASAP7_75t_R   g091(.A(new_n109_), .B(new_n76_), .Y(new_n110_));
  NAND3x1_ASAP7_75t_R  g092(.A(new_n44_), .B(new_n57_), .C(p4), .Y(new_n111_));
  NAND3x1_ASAP7_75t_R  g093(.A(new_n20_), .B(p1), .C(p5), .Y(new_n112_));
  NAND3x1_ASAP7_75t_R  g094(.A(new_n111_), .B(new_n112_), .C(new_n47_), .Y(new_n113_));
  OA21x2_ASAP7_75t_R   g095(.A1(new_n47_), .A2(new_n84_), .B(new_n36_), .Y(new_n114_));
  NAND2x1_ASAP7_75t_R  g096(.A(p6), .B(p4), .Y(new_n115_));
  AND2x2_ASAP7_75t_R   g097(.A(p3), .B(p4), .Y(new_n116_));
  OAI22x1_ASAP7_75t_R  g098(.A1(new_n100_), .A2(new_n115_), .B1(new_n96_), .B2(new_n116_), .Y(new_n117_));
  AOI221x1_ASAP7_75t_R g099(.A1(new_n30_), .A2(new_n110_), .B1(new_n113_), .B2(new_n114_), .C(new_n117_), .Y(new_n118_));
  OAI21x1_ASAP7_75t_R  g100(.A1(new_n102_), .A2(new_n108_), .B(new_n118_), .Y(new_n119_));
  OR3x1_ASAP7_75t_R    g101(.A(new_n109_), .B(p6), .C(new_n19_), .Y(new_n120_));
  AO21x1_ASAP7_75t_R   g102(.A1(new_n59_), .A2(new_n120_), .B(new_n36_), .Y(new_n121_));
  OR3x1_ASAP7_75t_R    g103(.A(new_n66_), .B(new_n20_), .C(p7), .Y(new_n122_));
  OAI21x1_ASAP7_75t_R  g104(.A1(new_n41_), .A2(new_n36_), .B(new_n122_), .Y(new_n123_));
  INVx1_ASAP7_75t_R    g105(.A(new_n96_), .Y(new_n124_));
  OR3x1_ASAP7_75t_R    g106(.A(new_n29_), .B(new_n20_), .C(p9), .Y(new_n125_));
  OA21x2_ASAP7_75t_R   g107(.A1(p9), .A2(p7), .B(p8), .Y(new_n126_));
  AOI22x1_ASAP7_75t_R  g108(.A1(new_n123_), .A2(new_n124_), .B1(new_n125_), .B2(new_n126_), .Y(new_n127_));
  OAI21x1_ASAP7_75t_R  g109(.A1(p9), .A2(new_n121_), .B(new_n127_), .Y(new_n128_));
  AO21x1_ASAP7_75t_R   g110(.A1(new_n39_), .A2(new_n119_), .B(new_n128_), .Y(o2));
  AND5x1_ASAP7_75t_R   g111(.A(new_n29_), .B(new_n36_), .C(new_n19_), .D(new_n20_), .E(new_n57_), .Y(new_n130_));
  AND3x1_ASAP7_75t_R   g112(.A(new_n84_), .B(p6), .C(p7), .Y(new_n131_));
  AND3x1_ASAP7_75t_R   g113(.A(new_n131_), .B(p3), .C(new_n30_), .Y(new_n132_));
  NOR2x1_ASAP7_75t_R   g114(.A(new_n130_), .B(new_n132_), .Y(new_n133_));
  OR3x1_ASAP7_75t_R    g115(.A(new_n133_), .B(p2), .C(new_n40_), .Y(o3));
  NOR2x1_ASAP7_75t_R   g116(.A(p6), .B(new_n75_), .Y(new_n135_));
  OA21x2_ASAP7_75t_R   g117(.A1(new_n84_), .A2(new_n135_), .B(new_n47_), .Y(new_n136_));
  AND3x1_ASAP7_75t_R   g118(.A(new_n29_), .B(new_n20_), .C(p3), .Y(new_n137_));
  OR4x2_ASAP7_75t_R    g119(.A(new_n136_), .B(p7), .C(new_n58_), .D(new_n137_), .Y(new_n138_));
  OA21x2_ASAP7_75t_R   g120(.A1(p2), .A2(p1), .B(new_n66_), .Y(new_n139_));
  OA211x2_ASAP7_75t_R  g121(.A1(p7), .A2(new_n32_), .B(new_n124_), .C(new_n116_), .Y(new_n140_));
  NOR2x1_ASAP7_75t_R   g122(.A(new_n66_), .B(new_n131_), .Y(new_n141_));
  AOI21x1_ASAP7_75t_R  g123(.A1(new_n139_), .A2(new_n140_), .B(new_n141_), .Y(new_n142_));
  NAND2x1_ASAP7_75t_R  g124(.A(new_n82_), .B(new_n103_), .Y(new_n143_));
  OR3x1_ASAP7_75t_R    g125(.A(new_n32_), .B(new_n30_), .C(p7), .Y(new_n144_));
  AO21x1_ASAP7_75t_R   g126(.A1(new_n143_), .A2(new_n120_), .B(new_n144_), .Y(new_n145_));
  AO31x2_ASAP7_75t_R   g127(.A1(new_n138_), .A2(new_n142_), .A3(new_n145_), .B(p9), .Y(o4));
  OAI21x1_ASAP7_75t_R  g128(.A1(p2), .A2(p1), .B(new_n131_), .Y(new_n147_));
  OR5x1_ASAP7_75t_R    g129(.A(p6), .B(new_n144_), .C(new_n44_), .D(new_n22_), .E(p4), .Y(new_n148_));
  AOI21x1_ASAP7_75t_R  g130(.A1(new_n147_), .A2(new_n148_), .B(new_n19_), .Y(new_n149_));
  OR3x1_ASAP7_75t_R    g131(.A(new_n65_), .B(new_n109_), .C(new_n30_), .Y(new_n150_));
  OA211x2_ASAP7_75t_R  g132(.A1(p4), .A2(p5), .B(new_n150_), .C(new_n49_), .Y(new_n151_));
  OR3x1_ASAP7_75t_R    g133(.A(new_n149_), .B(new_n40_), .C(new_n151_), .Y(o5));
  NAND3x1_ASAP7_75t_R  g134(.A(new_n150_), .B(new_n39_), .C(new_n49_), .Y(o6));
endmodule


