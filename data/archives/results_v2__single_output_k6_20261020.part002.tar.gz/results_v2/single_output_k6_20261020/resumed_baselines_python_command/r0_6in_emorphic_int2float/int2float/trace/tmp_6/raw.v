// Benchmark "/tmp/" written by ABC on Tue Oct 20 17:46:14 2026

module \/tmp/  ( 
    p6, p8, p4, p2, p0, p7, p5, p9, p1, p10, p3,
    o0, o1, o2, o3, o4, o5, o6  );
  input  p6, p8, p4, p2, p0, p7, p5, p9, p1, p10, p3;
  output o0, o1, o2, o3, o4, o5, o6;
  wire new_n19_, new_n20_, new_n21_, new_n22_, new_n23_, new_n24_, new_n25_,
    new_n26_, new_n27_, new_n28_, new_n29_, new_n30_, new_n31_, new_n32_,
    new_n33_, new_n34_, new_n35_, new_n36_, new_n37_, new_n38_, new_n39_,
    new_n40_, new_n41_, new_n42_, new_n43_, new_n44_, new_n45_, new_n46_,
    new_n47_, new_n48_, new_n49_, new_n50_, new_n51_, new_n52_, new_n53_,
    new_n54_, new_n55_, new_n56_, new_n57_, new_n58_, new_n59_, new_n60_,
    new_n61_, new_n62_, new_n64_, new_n65_, new_n66_, new_n67_, new_n68_,
    new_n69_, new_n70_, new_n71_, new_n72_, new_n73_, new_n74_, new_n75_,
    new_n76_, new_n77_, new_n78_, new_n79_, new_n80_, new_n81_, new_n82_,
    new_n83_, new_n84_, new_n85_, new_n86_, new_n87_, new_n88_, new_n89_,
    new_n90_, new_n91_, new_n92_, new_n93_, new_n94_, new_n95_, new_n96_,
    new_n98_, new_n99_, new_n100_, new_n101_, new_n102_, new_n103_,
    new_n104_, new_n105_, new_n106_, new_n107_, new_n108_, new_n109_,
    new_n110_, new_n111_, new_n112_, new_n113_, new_n114_, new_n115_,
    new_n116_, new_n117_, new_n118_, new_n119_, new_n120_, new_n121_,
    new_n122_, new_n123_, new_n124_, new_n125_, new_n126_, new_n128_,
    new_n129_, new_n130_, new_n131_, new_n133_, new_n134_, new_n135_,
    new_n136_, new_n137_, new_n138_, new_n139_, new_n140_, new_n141_,
    new_n142_, new_n143_, new_n144_, new_n146_, new_n147_, new_n148_,
    new_n149_, new_n150_, new_n151_;
  INVx1_ASAP7_75t_R    g000(.A(p3), .Y(new_n19_));
  INVx1_ASAP7_75t_R    g001(.A(p4), .Y(new_n20_));
  AO21x1_ASAP7_75t_R   g002(.A1(p7), .A2(new_n19_), .B(new_n20_), .Y(new_n21_));
  AND2x2_ASAP7_75t_R   g003(.A(p0), .B(p3), .Y(new_n22_));
  NOR2x1_ASAP7_75t_R   g004(.A(p6), .B(p5), .Y(new_n23_));
  OA21x2_ASAP7_75t_R   g005(.A1(p10), .A2(new_n22_), .B(new_n23_), .Y(new_n24_));
  INVx1_ASAP7_75t_R    g006(.A(p7), .Y(new_n25_));
  NOR2x1_ASAP7_75t_R   g007(.A(p3), .B(new_n25_), .Y(new_n26_));
  OAI21x1_ASAP7_75t_R  g008(.A1(new_n22_), .A2(new_n26_), .B(p10), .Y(new_n27_));
  AO21x1_ASAP7_75t_R   g009(.A1(p7), .A2(p3), .B(p4), .Y(new_n28_));
  AO21x1_ASAP7_75t_R   g010(.A1(new_n24_), .A2(new_n27_), .B(new_n28_), .Y(new_n29_));
  INVx1_ASAP7_75t_R    g011(.A(p6), .Y(new_n30_));
  INVx1_ASAP7_75t_R    g012(.A(p1), .Y(new_n31_));
  AND5x1_ASAP7_75t_R   g013(.A(new_n30_), .B(new_n31_), .C(p4), .D(p2), .E(p0), .Y(new_n32_));
  NOR2x1_ASAP7_75t_R   g014(.A(p2), .B(p3), .Y(new_n33_));
  NAND2x1_ASAP7_75t_R  g015(.A(p2), .B(p3), .Y(new_n34_));
  NAND2x1_ASAP7_75t_R  g016(.A(p6), .B(new_n34_), .Y(new_n35_));
  NOR2x1_ASAP7_75t_R   g017(.A(new_n33_), .B(new_n35_), .Y(new_n36_));
  OA21x2_ASAP7_75t_R   g018(.A1(new_n32_), .A2(new_n36_), .B(new_n25_), .Y(new_n37_));
  AOI21x1_ASAP7_75t_R  g019(.A1(new_n21_), .A2(new_n29_), .B(new_n37_), .Y(new_n38_));
  INVx1_ASAP7_75t_R    g020(.A(p8), .Y(new_n39_));
  INVx1_ASAP7_75t_R    g021(.A(p9), .Y(new_n40_));
  NAND2x1_ASAP7_75t_R  g022(.A(new_n39_), .B(new_n40_), .Y(new_n41_));
  INVx1_ASAP7_75t_R    g023(.A(p0), .Y(new_n42_));
  AOI211x1_ASAP7_75t_R g024(.A1(p6), .A2(new_n19_), .B(new_n42_), .C(p1), .Y(new_n43_));
  INVx1_ASAP7_75t_R    g025(.A(p2), .Y(new_n44_));
  AO21x1_ASAP7_75t_R   g026(.A1(new_n44_), .A2(new_n25_), .B(new_n19_), .Y(new_n45_));
  NOR2x1_ASAP7_75t_R   g027(.A(p5), .B(new_n20_), .Y(new_n46_));
  NAND3x1_ASAP7_75t_R  g028(.A(new_n43_), .B(new_n45_), .C(new_n46_), .Y(new_n47_));
  NOR2x1_ASAP7_75t_R   g029(.A(p6), .B(p7), .Y(new_n48_));
  AO31x2_ASAP7_75t_R   g030(.A1(new_n48_), .A2(new_n42_), .A3(p1), .B(p8), .Y(new_n49_));
  AND3x1_ASAP7_75t_R   g031(.A(new_n20_), .B(p8), .C(p5), .Y(new_n50_));
  AOI21x1_ASAP7_75t_R  g032(.A1(new_n46_), .A2(new_n49_), .B(new_n50_), .Y(new_n51_));
  NAND2x1_ASAP7_75t_R  g033(.A(new_n47_), .B(new_n51_), .Y(new_n52_));
  NAND2x1_ASAP7_75t_R  g034(.A(p5), .B(new_n30_), .Y(new_n53_));
  NAND2x1_ASAP7_75t_R  g035(.A(new_n39_), .B(new_n25_), .Y(new_n54_));
  XNOR2x2_ASAP7_75t_R  g036(.A(p2), .B(p1), .Y(new_n55_));
  OA21x2_ASAP7_75t_R   g037(.A1(new_n54_), .A2(new_n55_), .B(new_n40_), .Y(new_n56_));
  INVx1_ASAP7_75t_R    g038(.A(p5), .Y(new_n57_));
  NAND2x1_ASAP7_75t_R  g039(.A(p6), .B(new_n57_), .Y(new_n58_));
  OR3x1_ASAP7_75t_R    g040(.A(new_n39_), .B(new_n25_), .C(new_n57_), .Y(new_n59_));
  AO21x1_ASAP7_75t_R   g041(.A1(new_n58_), .A2(new_n59_), .B(new_n40_), .Y(new_n60_));
  OAI21x1_ASAP7_75t_R  g042(.A1(new_n53_), .A2(new_n56_), .B(new_n60_), .Y(new_n61_));
  AOI21x1_ASAP7_75t_R  g043(.A1(new_n40_), .A2(new_n52_), .B(new_n61_), .Y(new_n62_));
  OAI21x1_ASAP7_75t_R  g044(.A1(new_n38_), .A2(new_n41_), .B(new_n62_), .Y(o0));
  NAND2x1_ASAP7_75t_R  g045(.A(p0), .B(p1), .Y(new_n64_));
  NAND2x1_ASAP7_75t_R  g046(.A(p3), .B(new_n31_), .Y(new_n65_));
  NAND2x1_ASAP7_75t_R  g047(.A(p10), .B(p3), .Y(new_n66_));
  AOI221x1_ASAP7_75t_R g048(.A1(p10), .A2(new_n64_), .B1(new_n65_), .B2(new_n66_), .C(p6), .Y(new_n67_));
  NOR2x1_ASAP7_75t_R   g049(.A(p6), .B(p1), .Y(new_n68_));
  NOR2x1_ASAP7_75t_R   g050(.A(p8), .B(p3), .Y(new_n69_));
  NOR2x1_ASAP7_75t_R   g051(.A(new_n68_), .B(new_n69_), .Y(new_n70_));
  OAI22x1_ASAP7_75t_R  g052(.A1(new_n70_), .A2(p0), .B1(p8), .B2(new_n25_), .Y(new_n71_));
  NOR2x1_ASAP7_75t_R   g053(.A(p4), .B(p5), .Y(new_n72_));
  OAI21x1_ASAP7_75t_R  g054(.A1(new_n67_), .A2(new_n71_), .B(new_n72_), .Y(new_n73_));
  INVx1_ASAP7_75t_R    g055(.A(new_n69_), .Y(new_n74_));
  NAND2x1_ASAP7_75t_R  g056(.A(p8), .B(new_n30_), .Y(new_n75_));
  AND3x1_ASAP7_75t_R   g057(.A(new_n74_), .B(new_n54_), .C(new_n75_), .Y(new_n76_));
  AND2x2_ASAP7_75t_R   g058(.A(p4), .B(p5), .Y(new_n77_));
  OAI21x1_ASAP7_75t_R  g059(.A1(new_n25_), .A2(new_n74_), .B(new_n75_), .Y(new_n78_));
  AOI22x1_ASAP7_75t_R  g060(.A1(new_n76_), .A2(new_n77_), .B1(new_n57_), .B2(new_n78_), .Y(new_n79_));
  OAI21x1_ASAP7_75t_R  g061(.A1(new_n54_), .A2(new_n35_), .B(new_n75_), .Y(new_n80_));
  NOR2x1_ASAP7_75t_R   g062(.A(p5), .B(p3), .Y(new_n81_));
  AO32x1_ASAP7_75t_R   g063(.A1(new_n39_), .A2(new_n25_), .A3(p3), .B1(new_n81_), .B2(new_n30_), .Y(new_n82_));
  AOI21x1_ASAP7_75t_R  g064(.A1(p0), .A2(p1), .B(p6), .Y(new_n83_));
  NOR3x1_ASAP7_75t_R   g065(.A(new_n83_), .B(new_n20_), .C(new_n44_), .Y(new_n84_));
  AOI22x1_ASAP7_75t_R  g066(.A1(new_n80_), .A2(new_n20_), .B1(new_n82_), .B2(new_n84_), .Y(new_n85_));
  NAND3x1_ASAP7_75t_R  g067(.A(new_n73_), .B(new_n79_), .C(new_n85_), .Y(new_n86_));
  AO21x1_ASAP7_75t_R   g068(.A1(p6), .A2(p5), .B(p7), .Y(new_n87_));
  INVx1_ASAP7_75t_R    g069(.A(new_n34_), .Y(new_n88_));
  OR3x1_ASAP7_75t_R    g070(.A(new_n88_), .B(new_n31_), .C(new_n33_), .Y(new_n89_));
  NOR2x1_ASAP7_75t_R   g071(.A(p6), .B(new_n57_), .Y(new_n90_));
  AND3x1_ASAP7_75t_R   g072(.A(new_n90_), .B(new_n65_), .C(new_n39_), .Y(new_n91_));
  AND3x1_ASAP7_75t_R   g073(.A(new_n44_), .B(new_n57_), .C(p4), .Y(new_n92_));
  AO21x1_ASAP7_75t_R   g074(.A1(new_n83_), .A2(new_n92_), .B(p9), .Y(new_n93_));
  AOI21x1_ASAP7_75t_R  g075(.A1(new_n89_), .A2(new_n91_), .B(new_n93_), .Y(new_n94_));
  OR5x1_ASAP7_75t_R    g076(.A(new_n30_), .B(new_n25_), .C(new_n57_), .D(new_n40_), .E(p8), .Y(new_n95_));
  OAI21x1_ASAP7_75t_R  g077(.A1(new_n87_), .A2(new_n94_), .B(new_n95_), .Y(new_n96_));
  AOI21x1_ASAP7_75t_R  g078(.A1(new_n40_), .A2(new_n86_), .B(new_n96_), .Y(o1));
  OR3x1_ASAP7_75t_R    g079(.A(p8), .B(p7), .C(p9), .Y(new_n98_));
  NAND2x1_ASAP7_75t_R  g080(.A(p4), .B(p3), .Y(new_n99_));
  INVx1_ASAP7_75t_R    g081(.A(new_n99_), .Y(new_n100_));
  NOR2x1_ASAP7_75t_R   g082(.A(p5), .B(p1), .Y(new_n101_));
  AOI22x1_ASAP7_75t_R  g083(.A1(new_n44_), .A2(new_n100_), .B1(new_n88_), .B2(new_n101_), .Y(new_n102_));
  AOI21x1_ASAP7_75t_R  g084(.A1(new_n31_), .A2(new_n102_), .B(p6), .Y(new_n103_));
  AND3x1_ASAP7_75t_R   g085(.A(new_n19_), .B(p4), .C(p2), .Y(new_n104_));
  NOR3x1_ASAP7_75t_R   g086(.A(new_n66_), .B(p2), .C(p5), .Y(new_n105_));
  OAI21x1_ASAP7_75t_R  g087(.A1(new_n104_), .A2(new_n105_), .B(p0), .Y(new_n106_));
  AOI211x1_ASAP7_75t_R g088(.A1(p0), .A2(p10), .B(new_n44_), .C(new_n19_), .Y(new_n107_));
  OAI21x1_ASAP7_75t_R  g089(.A1(new_n81_), .A2(new_n107_), .B(new_n20_), .Y(new_n108_));
  NAND3x1_ASAP7_75t_R  g090(.A(new_n106_), .B(new_n102_), .C(new_n108_), .Y(new_n109_));
  NOR2x1_ASAP7_75t_R   g091(.A(new_n34_), .B(new_n72_), .Y(new_n110_));
  AO22x1_ASAP7_75t_R   g092(.A1(p1), .A2(new_n20_), .B1(new_n42_), .B2(new_n57_), .Y(new_n111_));
  AO22x1_ASAP7_75t_R   g093(.A1(new_n34_), .A2(new_n77_), .B1(new_n110_), .B2(new_n111_), .Y(new_n112_));
  AOI21x1_ASAP7_75t_R  g094(.A1(new_n103_), .A2(new_n109_), .B(new_n112_), .Y(new_n113_));
  NOR2x1_ASAP7_75t_R   g095(.A(p5), .B(new_n30_), .Y(new_n114_));
  AOI22x1_ASAP7_75t_R  g096(.A1(new_n114_), .A2(p2), .B1(p5), .B2(new_n68_), .Y(new_n115_));
  AND2x2_ASAP7_75t_R   g097(.A(p6), .B(p5), .Y(new_n116_));
  NOR2x1_ASAP7_75t_R   g098(.A(new_n116_), .B(new_n100_), .Y(new_n117_));
  AOI211x1_ASAP7_75t_R g099(.A1(new_n100_), .A2(new_n115_), .B(new_n41_), .C(new_n117_), .Y(new_n118_));
  NAND2x1_ASAP7_75t_R  g100(.A(p7), .B(new_n40_), .Y(new_n119_));
  OA21x2_ASAP7_75t_R   g101(.A1(new_n99_), .A2(new_n53_), .B(new_n58_), .Y(new_n120_));
  NOR2x1_ASAP7_75t_R   g102(.A(new_n119_), .B(new_n120_), .Y(new_n121_));
  AO21x1_ASAP7_75t_R   g103(.A1(p8), .A2(p4), .B(p7), .Y(new_n122_));
  NAND2x1_ASAP7_75t_R  g104(.A(p6), .B(p4), .Y(new_n123_));
  AO21x1_ASAP7_75t_R   g105(.A1(p7), .A2(new_n123_), .B(p9), .Y(new_n124_));
  AO32x1_ASAP7_75t_R   g106(.A1(new_n116_), .A2(new_n119_), .A3(new_n122_), .B1(new_n124_), .B2(p8), .Y(new_n125_));
  NOR3x1_ASAP7_75t_R   g107(.A(new_n118_), .B(new_n121_), .C(new_n125_), .Y(new_n126_));
  OAI21x1_ASAP7_75t_R  g108(.A1(new_n98_), .A2(new_n113_), .B(new_n126_), .Y(o2));
  INVx1_ASAP7_75t_R    g109(.A(new_n65_), .Y(new_n128_));
  AND3x1_ASAP7_75t_R   g110(.A(new_n77_), .B(p6), .C(p7), .Y(new_n129_));
  AND3x1_ASAP7_75t_R   g111(.A(new_n48_), .B(new_n81_), .C(new_n20_), .Y(new_n130_));
  AOI21x1_ASAP7_75t_R  g112(.A1(new_n128_), .A2(new_n129_), .B(new_n130_), .Y(new_n131_));
  OR3x1_ASAP7_75t_R    g113(.A(new_n131_), .B(p2), .C(new_n41_), .Y(o3));
  NOR2x1_ASAP7_75t_R   g114(.A(p6), .B(new_n64_), .Y(new_n133_));
  OA21x2_ASAP7_75t_R   g115(.A1(new_n77_), .A2(new_n133_), .B(new_n88_), .Y(new_n134_));
  AND3x1_ASAP7_75t_R   g116(.A(new_n30_), .B(new_n20_), .C(p3), .Y(new_n135_));
  OR4x2_ASAP7_75t_R    g117(.A(new_n134_), .B(p7), .C(new_n90_), .D(new_n135_), .Y(new_n136_));
  OR2x4_ASAP7_75t_R    g118(.A(new_n39_), .B(new_n129_), .Y(new_n137_));
  AND2x2_ASAP7_75t_R   g119(.A(p0), .B(p10), .Y(new_n138_));
  AO32x1_ASAP7_75t_R   g120(.A1(new_n77_), .A2(new_n30_), .A3(p3), .B1(new_n138_), .B2(new_n72_), .Y(new_n139_));
  AND3x1_ASAP7_75t_R   g121(.A(new_n25_), .B(p2), .C(p1), .Y(new_n140_));
  NAND2x1_ASAP7_75t_R  g122(.A(new_n44_), .B(new_n31_), .Y(new_n141_));
  NAND2x1_ASAP7_75t_R  g123(.A(p2), .B(new_n25_), .Y(new_n142_));
  AND5x1_ASAP7_75t_R   g124(.A(new_n39_), .B(new_n141_), .C(new_n100_), .D(new_n142_), .E(new_n116_), .Y(new_n143_));
  AOI21x1_ASAP7_75t_R  g125(.A1(new_n139_), .A2(new_n140_), .B(new_n143_), .Y(new_n144_));
  AO31x2_ASAP7_75t_R   g126(.A1(new_n136_), .A2(new_n137_), .A3(new_n144_), .B(p9), .Y(o4));
  INVx1_ASAP7_75t_R    g127(.A(new_n72_), .Y(new_n146_));
  INVx1_ASAP7_75t_R    g128(.A(new_n48_), .Y(new_n147_));
  AND3x1_ASAP7_75t_R   g129(.A(new_n88_), .B(new_n77_), .C(p1), .Y(new_n148_));
  NOR2x1_ASAP7_75t_R   g130(.A(new_n147_), .B(new_n148_), .Y(new_n149_));
  NOR2x1_ASAP7_75t_R   g131(.A(p6), .B(p4), .Y(new_n150_));
  AO32x1_ASAP7_75t_R   g132(.A1(new_n138_), .A2(new_n150_), .A3(new_n140_), .B1(new_n129_), .B2(new_n141_), .Y(new_n151_));
  AO221x2_ASAP7_75t_R  g133(.A1(new_n146_), .A2(new_n149_), .B1(new_n151_), .B2(p3), .C(new_n41_), .Y(o5));
  OR3x1_ASAP7_75t_R    g134(.A(new_n148_), .B(new_n41_), .C(new_n147_), .Y(o6));
endmodule


