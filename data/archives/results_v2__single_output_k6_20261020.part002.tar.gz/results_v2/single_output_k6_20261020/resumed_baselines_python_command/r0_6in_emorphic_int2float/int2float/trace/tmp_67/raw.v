// Benchmark "/tmp/" written by ABC on Tue Oct 20 17:46:21 2026

module \/tmp/  ( 
    p3, p5, p8, p2, p6, p1, p0, p10, p7, p4, p9,
    o0, o1, o2, o3, o4, o5, o6  );
  input  p3, p5, p8, p2, p6, p1, p0, p10, p7, p4, p9;
  output o0, o1, o2, o3, o4, o5, o6;
  wire new_n19_, new_n20_, new_n21_, new_n22_, new_n23_, new_n24_, new_n25_,
    new_n26_, new_n27_, new_n28_, new_n29_, new_n30_, new_n31_, new_n32_,
    new_n33_, new_n34_, new_n35_, new_n36_, new_n37_, new_n38_, new_n39_,
    new_n40_, new_n41_, new_n42_, new_n43_, new_n44_, new_n45_, new_n46_,
    new_n47_, new_n48_, new_n49_, new_n50_, new_n51_, new_n52_, new_n53_,
    new_n54_, new_n55_, new_n56_, new_n57_, new_n58_, new_n59_, new_n60_,
    new_n62_, new_n63_, new_n64_, new_n65_, new_n66_, new_n67_, new_n68_,
    new_n69_, new_n70_, new_n71_, new_n72_, new_n73_, new_n74_, new_n75_,
    new_n76_, new_n77_, new_n78_, new_n79_, new_n80_, new_n81_, new_n82_,
    new_n83_, new_n84_, new_n85_, new_n86_, new_n87_, new_n88_, new_n89_,
    new_n90_, new_n91_, new_n92_, new_n93_, new_n94_, new_n95_, new_n96_,
    new_n97_, new_n98_, new_n99_, new_n101_, new_n102_, new_n103_,
    new_n104_, new_n105_, new_n106_, new_n107_, new_n108_, new_n109_,
    new_n110_, new_n111_, new_n112_, new_n113_, new_n114_, new_n115_,
    new_n116_, new_n117_, new_n118_, new_n119_, new_n120_, new_n121_,
    new_n122_, new_n123_, new_n124_, new_n125_, new_n126_, new_n127_,
    new_n128_, new_n129_, new_n130_, new_n131_, new_n133_, new_n134_,
    new_n135_, new_n136_, new_n137_, new_n139_, new_n140_, new_n141_,
    new_n142_, new_n143_, new_n144_, new_n145_, new_n146_, new_n147_,
    new_n148_, new_n149_, new_n150_, new_n152_, new_n153_, new_n154_,
    new_n155_, new_n156_, new_n157_;
  NOR2x1_ASAP7_75t_R   g000(.A(p8), .B(p9), .Y(new_n19_));
  INVx1_ASAP7_75t_R    g001(.A(new_n19_), .Y(new_n20_));
  INVx1_ASAP7_75t_R    g002(.A(p3), .Y(new_n21_));
  NAND2x1_ASAP7_75t_R  g003(.A(p7), .B(new_n21_), .Y(new_n22_));
  AND2x2_ASAP7_75t_R   g004(.A(p4), .B(new_n22_), .Y(new_n23_));
  INVx1_ASAP7_75t_R    g005(.A(p10), .Y(new_n24_));
  NAND2x1_ASAP7_75t_R  g006(.A(p3), .B(p0), .Y(new_n25_));
  INVx1_ASAP7_75t_R    g007(.A(p5), .Y(new_n26_));
  INVx1_ASAP7_75t_R    g008(.A(p6), .Y(new_n27_));
  NAND2x1_ASAP7_75t_R  g009(.A(new_n26_), .B(new_n27_), .Y(new_n28_));
  AOI21x1_ASAP7_75t_R  g010(.A1(new_n24_), .A2(new_n25_), .B(new_n28_), .Y(new_n29_));
  AO21x1_ASAP7_75t_R   g011(.A1(new_n25_), .A2(new_n22_), .B(new_n24_), .Y(new_n30_));
  AO21x1_ASAP7_75t_R   g012(.A1(p3), .A2(p7), .B(p4), .Y(new_n31_));
  AOI21x1_ASAP7_75t_R  g013(.A1(new_n29_), .A2(new_n30_), .B(new_n31_), .Y(new_n32_));
  INVx1_ASAP7_75t_R    g014(.A(p2), .Y(new_n33_));
  INVx1_ASAP7_75t_R    g015(.A(p0), .Y(new_n34_));
  INVx1_ASAP7_75t_R    g016(.A(p4), .Y(new_n35_));
  OR5x1_ASAP7_75t_R    g017(.A(new_n33_), .B(new_n34_), .C(new_n35_), .D(p6), .E(p1), .Y(new_n36_));
  AND2x2_ASAP7_75t_R   g018(.A(p3), .B(p2), .Y(new_n37_));
  NOR2x1_ASAP7_75t_R   g019(.A(p3), .B(p2), .Y(new_n38_));
  OR3x1_ASAP7_75t_R    g020(.A(new_n37_), .B(new_n27_), .C(new_n38_), .Y(new_n39_));
  AO21x1_ASAP7_75t_R   g021(.A1(new_n36_), .A2(new_n39_), .B(p7), .Y(new_n40_));
  OA21x2_ASAP7_75t_R   g022(.A1(new_n23_), .A2(new_n32_), .B(new_n40_), .Y(new_n41_));
  NOR2x1_ASAP7_75t_R   g023(.A(p5), .B(new_n35_), .Y(new_n42_));
  INVx1_ASAP7_75t_R    g024(.A(new_n42_), .Y(new_n43_));
  NOR2x1_ASAP7_75t_R   g025(.A(p3), .B(new_n27_), .Y(new_n44_));
  AND2x2_ASAP7_75t_R   g026(.A(p3), .B(p7), .Y(new_n45_));
  OR5x1_ASAP7_75t_R    g027(.A(p1), .B(new_n44_), .C(new_n34_), .D(new_n45_), .E(new_n37_), .Y(new_n46_));
  NOR2x1_ASAP7_75t_R   g028(.A(p6), .B(p7), .Y(new_n47_));
  AO31x2_ASAP7_75t_R   g029(.A1(new_n47_), .A2(p1), .A3(new_n34_), .B(p8), .Y(new_n48_));
  AND3x1_ASAP7_75t_R   g030(.A(new_n35_), .B(p5), .C(p8), .Y(new_n49_));
  AOI21x1_ASAP7_75t_R  g031(.A1(new_n42_), .A2(new_n48_), .B(new_n49_), .Y(new_n50_));
  OAI21x1_ASAP7_75t_R  g032(.A1(new_n43_), .A2(new_n46_), .B(new_n50_), .Y(new_n51_));
  INVx1_ASAP7_75t_R    g033(.A(p9), .Y(new_n52_));
  NOR2x1_ASAP7_75t_R   g034(.A(p8), .B(p7), .Y(new_n53_));
  XOR2x2_ASAP7_75t_R   g035(.A(p2), .B(p1), .Y(new_n54_));
  AO21x1_ASAP7_75t_R   g036(.A1(new_n53_), .A2(new_n54_), .B(p9), .Y(new_n55_));
  AND3x1_ASAP7_75t_R   g037(.A(p5), .B(p8), .C(p7), .Y(new_n56_));
  NOR2x1_ASAP7_75t_R   g038(.A(p5), .B(new_n27_), .Y(new_n57_));
  OA21x2_ASAP7_75t_R   g039(.A1(new_n56_), .A2(new_n57_), .B(p9), .Y(new_n58_));
  AO21x1_ASAP7_75t_R   g040(.A1(p5), .A2(new_n27_), .B(new_n58_), .Y(new_n59_));
  AOI22x1_ASAP7_75t_R  g041(.A1(new_n51_), .A2(new_n52_), .B1(new_n55_), .B2(new_n59_), .Y(new_n60_));
  OAI21x1_ASAP7_75t_R  g042(.A1(new_n20_), .A2(new_n41_), .B(new_n60_), .Y(o0));
  INVx1_ASAP7_75t_R    g043(.A(p8), .Y(new_n62_));
  NAND2x1_ASAP7_75t_R  g044(.A(new_n21_), .B(new_n62_), .Y(new_n63_));
  NAND2x1_ASAP7_75t_R  g045(.A(p8), .B(new_n27_), .Y(new_n64_));
  NAND2x1_ASAP7_75t_R  g046(.A(p5), .B(p4), .Y(new_n65_));
  AND3x1_ASAP7_75t_R   g047(.A(new_n63_), .B(new_n64_), .C(new_n65_), .Y(new_n66_));
  AOI21x1_ASAP7_75t_R  g048(.A1(new_n64_), .A2(new_n63_), .B(new_n26_), .Y(new_n67_));
  OR3x1_ASAP7_75t_R    g049(.A(new_n66_), .B(new_n53_), .C(new_n67_), .Y(new_n68_));
  OAI22x1_ASAP7_75t_R  g050(.A1(p3), .A2(p8), .B1(p6), .B2(p1), .Y(new_n69_));
  AO22x1_ASAP7_75t_R   g051(.A1(new_n62_), .A2(p7), .B1(new_n34_), .B2(new_n69_), .Y(new_n70_));
  NAND2x1_ASAP7_75t_R  g052(.A(p1), .B(p0), .Y(new_n71_));
  AO21x1_ASAP7_75t_R   g053(.A1(p1), .A2(new_n24_), .B(p6), .Y(new_n72_));
  AOI211x1_ASAP7_75t_R g054(.A1(p10), .A2(new_n71_), .B(new_n21_), .C(new_n72_), .Y(new_n73_));
  NOR2x1_ASAP7_75t_R   g055(.A(p5), .B(p4), .Y(new_n74_));
  OAI21x1_ASAP7_75t_R  g056(.A1(new_n70_), .A2(new_n73_), .B(new_n74_), .Y(new_n75_));
  NAND2x1_ASAP7_75t_R  g057(.A(p6), .B(new_n53_), .Y(new_n76_));
  OAI21x1_ASAP7_75t_R  g058(.A1(new_n37_), .A2(new_n76_), .B(new_n64_), .Y(new_n77_));
  INVx1_ASAP7_75t_R    g059(.A(p7), .Y(new_n78_));
  NOR2x1_ASAP7_75t_R   g060(.A(p3), .B(p5), .Y(new_n79_));
  AO32x1_ASAP7_75t_R   g061(.A1(p3), .A2(new_n62_), .A3(new_n78_), .B1(new_n79_), .B2(new_n27_), .Y(new_n80_));
  NAND2x1_ASAP7_75t_R  g062(.A(p2), .B(p4), .Y(new_n81_));
  AOI21x1_ASAP7_75t_R  g063(.A1(new_n27_), .A2(new_n71_), .B(new_n81_), .Y(new_n82_));
  AOI22x1_ASAP7_75t_R  g064(.A1(new_n77_), .A2(new_n35_), .B1(new_n80_), .B2(new_n82_), .Y(new_n83_));
  NAND3x1_ASAP7_75t_R  g065(.A(new_n68_), .B(new_n75_), .C(new_n83_), .Y(new_n84_));
  AO21x1_ASAP7_75t_R   g066(.A1(p5), .A2(p6), .B(p7), .Y(new_n85_));
  AO21x1_ASAP7_75t_R   g067(.A1(p6), .A2(new_n52_), .B(new_n85_), .Y(new_n86_));
  NOR2x1_ASAP7_75t_R   g068(.A(p5), .B(p2), .Y(new_n87_));
  AO32x1_ASAP7_75t_R   g069(.A1(new_n21_), .A2(p5), .A3(new_n62_), .B1(new_n87_), .B2(p4), .Y(new_n88_));
  INVx1_ASAP7_75t_R    g070(.A(p1), .Y(new_n89_));
  NOR2x1_ASAP7_75t_R   g071(.A(p5), .B(p0), .Y(new_n90_));
  AO32x1_ASAP7_75t_R   g072(.A1(new_n21_), .A2(p5), .A3(new_n62_), .B1(new_n90_), .B2(p4), .Y(new_n91_));
  AND3x1_ASAP7_75t_R   g073(.A(p3), .B(p2), .C(p1), .Y(new_n92_));
  NOR2x1_ASAP7_75t_R   g074(.A(p8), .B(new_n26_), .Y(new_n93_));
  AO21x1_ASAP7_75t_R   g075(.A1(new_n92_), .A2(new_n93_), .B(p9), .Y(new_n94_));
  AOI221x1_ASAP7_75t_R g076(.A1(new_n88_), .A2(new_n89_), .B1(new_n33_), .B2(new_n91_), .C(new_n94_), .Y(new_n95_));
  NAND2x1_ASAP7_75t_R  g077(.A(p7), .B(p9), .Y(new_n96_));
  NAND2x1_ASAP7_75t_R  g078(.A(p5), .B(p6), .Y(new_n97_));
  OR3x1_ASAP7_75t_R    g079(.A(new_n96_), .B(new_n97_), .C(p8), .Y(new_n98_));
  OAI21x1_ASAP7_75t_R  g080(.A1(new_n86_), .A2(new_n95_), .B(new_n98_), .Y(new_n99_));
  AOI21x1_ASAP7_75t_R  g081(.A1(new_n52_), .A2(new_n84_), .B(new_n99_), .Y(o1));
  NOR2x1_ASAP7_75t_R   g082(.A(p2), .B(new_n35_), .Y(new_n101_));
  AND3x1_ASAP7_75t_R   g083(.A(new_n26_), .B(new_n89_), .C(p2), .Y(new_n102_));
  OAI21x1_ASAP7_75t_R  g084(.A1(new_n101_), .A2(new_n102_), .B(p3), .Y(new_n103_));
  INVx1_ASAP7_75t_R    g085(.A(new_n47_), .Y(new_n104_));
  AOI21x1_ASAP7_75t_R  g086(.A1(new_n89_), .A2(new_n103_), .B(new_n104_), .Y(new_n105_));
  NOR2x1_ASAP7_75t_R   g087(.A(p3), .B(new_n81_), .Y(new_n106_));
  AND4x2_ASAP7_75t_R   g088(.A(new_n26_), .B(new_n33_), .C(p3), .D(p10), .Y(new_n107_));
  OAI21x1_ASAP7_75t_R  g089(.A1(new_n106_), .A2(new_n107_), .B(p0), .Y(new_n108_));
  NAND2x1_ASAP7_75t_R  g090(.A(p3), .B(p2), .Y(new_n109_));
  AOI21x1_ASAP7_75t_R  g091(.A1(p0), .A2(p10), .B(new_n109_), .Y(new_n110_));
  OAI21x1_ASAP7_75t_R  g092(.A1(new_n79_), .A2(new_n110_), .B(new_n35_), .Y(new_n111_));
  NAND3x1_ASAP7_75t_R  g093(.A(new_n108_), .B(new_n103_), .C(new_n111_), .Y(new_n112_));
  AND3x1_ASAP7_75t_R   g094(.A(new_n35_), .B(p5), .C(p1), .Y(new_n113_));
  AOI211x1_ASAP7_75t_R g095(.A1(p4), .A2(new_n90_), .B(new_n109_), .C(new_n113_), .Y(new_n114_));
  AO21x1_ASAP7_75t_R   g096(.A1(new_n109_), .A2(new_n65_), .B(p7), .Y(new_n115_));
  AND3x1_ASAP7_75t_R   g097(.A(p3), .B(p2), .C(p4), .Y(new_n116_));
  NAND2x1_ASAP7_75t_R  g098(.A(p3), .B(p4), .Y(new_n117_));
  AND3x1_ASAP7_75t_R   g099(.A(new_n117_), .B(p5), .C(p6), .Y(new_n118_));
  AND5x1_ASAP7_75t_R   g100(.A(p3), .B(new_n27_), .C(new_n89_), .D(p5), .E(p4), .Y(new_n119_));
  AOI211x1_ASAP7_75t_R g101(.A1(new_n57_), .A2(new_n116_), .B(new_n118_), .C(new_n119_), .Y(new_n120_));
  OAI21x1_ASAP7_75t_R  g102(.A1(new_n114_), .A2(new_n115_), .B(new_n120_), .Y(new_n121_));
  AOI21x1_ASAP7_75t_R  g103(.A1(new_n105_), .A2(new_n112_), .B(new_n121_), .Y(new_n122_));
  AND2x2_ASAP7_75t_R   g104(.A(p5), .B(p4), .Y(new_n123_));
  AND3x1_ASAP7_75t_R   g105(.A(new_n123_), .B(p3), .C(new_n27_), .Y(new_n124_));
  OAI21x1_ASAP7_75t_R  g106(.A1(new_n57_), .A2(new_n124_), .B(p7), .Y(new_n125_));
  OR3x1_ASAP7_75t_R    g107(.A(new_n62_), .B(new_n35_), .C(p7), .Y(new_n126_));
  AO21x1_ASAP7_75t_R   g108(.A1(new_n96_), .A2(new_n126_), .B(new_n97_), .Y(new_n127_));
  AND3x1_ASAP7_75t_R   g109(.A(new_n52_), .B(p6), .C(p4), .Y(new_n128_));
  NOR2x1_ASAP7_75t_R   g110(.A(p7), .B(p9), .Y(new_n129_));
  OR3x1_ASAP7_75t_R    g111(.A(new_n128_), .B(new_n62_), .C(new_n129_), .Y(new_n130_));
  OA211x2_ASAP7_75t_R  g112(.A1(p9), .A2(new_n125_), .B(new_n127_), .C(new_n130_), .Y(new_n131_));
  OAI21x1_ASAP7_75t_R  g113(.A1(new_n20_), .A2(new_n122_), .B(new_n131_), .Y(o2));
  NAND2x1_ASAP7_75t_R  g114(.A(new_n27_), .B(new_n35_), .Y(new_n133_));
  OR3x1_ASAP7_75t_R    g115(.A(new_n133_), .B(p3), .C(p5), .Y(new_n134_));
  OR3x1_ASAP7_75t_R    g116(.A(new_n65_), .B(new_n27_), .C(new_n78_), .Y(new_n135_));
  OR3x1_ASAP7_75t_R    g117(.A(new_n135_), .B(new_n21_), .C(p1), .Y(new_n136_));
  OA21x2_ASAP7_75t_R   g118(.A1(p7), .A2(new_n134_), .B(new_n136_), .Y(new_n137_));
  OR3x1_ASAP7_75t_R    g119(.A(new_n137_), .B(p2), .C(new_n20_), .Y(o3));
  AND3x1_ASAP7_75t_R   g120(.A(new_n74_), .B(p0), .C(p10), .Y(new_n139_));
  AND3x1_ASAP7_75t_R   g121(.A(new_n78_), .B(p2), .C(p1), .Y(new_n140_));
  OA21x2_ASAP7_75t_R   g122(.A1(new_n139_), .A2(new_n124_), .B(new_n140_), .Y(new_n141_));
  NAND2x1_ASAP7_75t_R  g123(.A(p2), .B(p7), .Y(new_n142_));
  OAI21x1_ASAP7_75t_R  g124(.A1(p2), .A2(new_n89_), .B(new_n142_), .Y(new_n143_));
  AND5x1_ASAP7_75t_R   g125(.A(p3), .B(new_n143_), .C(p6), .D(p4), .E(new_n93_), .Y(new_n144_));
  AND2x2_ASAP7_75t_R   g126(.A(p8), .B(new_n135_), .Y(new_n145_));
  OR3x1_ASAP7_75t_R    g127(.A(new_n141_), .B(new_n144_), .C(new_n145_), .Y(new_n146_));
  OR3x1_ASAP7_75t_R    g128(.A(new_n89_), .B(new_n34_), .C(p6), .Y(new_n147_));
  AO21x1_ASAP7_75t_R   g129(.A1(new_n65_), .A2(new_n147_), .B(new_n109_), .Y(new_n148_));
  OA21x2_ASAP7_75t_R   g130(.A1(p6), .A2(new_n26_), .B(new_n78_), .Y(new_n149_));
  OA211x2_ASAP7_75t_R  g131(.A1(new_n21_), .A2(new_n133_), .B(new_n148_), .C(new_n149_), .Y(new_n150_));
  OAI21x1_ASAP7_75t_R  g132(.A1(new_n146_), .A2(new_n150_), .B(new_n52_), .Y(o4));
  OR5x1_ASAP7_75t_R    g133(.A(new_n33_), .B(new_n133_), .C(new_n34_), .D(new_n24_), .E(p7), .Y(new_n152_));
  AO21x1_ASAP7_75t_R   g134(.A1(new_n33_), .A2(new_n89_), .B(new_n135_), .Y(new_n153_));
  OAI21x1_ASAP7_75t_R  g135(.A1(new_n89_), .A2(new_n152_), .B(new_n153_), .Y(new_n154_));
  AND3x1_ASAP7_75t_R   g136(.A(new_n37_), .B(new_n123_), .C(p1), .Y(new_n155_));
  OR3x1_ASAP7_75t_R    g137(.A(new_n155_), .B(new_n104_), .C(new_n74_), .Y(new_n156_));
  NAND2x1_ASAP7_75t_R  g138(.A(new_n19_), .B(new_n156_), .Y(new_n157_));
  AO21x1_ASAP7_75t_R   g139(.A1(p3), .A2(new_n154_), .B(new_n157_), .Y(o5));
  OR3x1_ASAP7_75t_R    g140(.A(new_n155_), .B(new_n20_), .C(new_n104_), .Y(o6));
endmodule


