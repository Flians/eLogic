// Benchmark "/tmp/" written by ABC on Tue Oct 20 17:46:18 2026

module \/tmp/  ( 
    p8, p7, p9, p1, p10, p6, p4, p0, p5, p2, p3,
    o0, o1, o2, o3, o4, o5, o6  );
  input  p8, p7, p9, p1, p10, p6, p4, p0, p5, p2, p3;
  output o0, o1, o2, o3, o4, o5, o6;
  wire new_n19_, new_n20_, new_n21_, new_n22_, new_n23_, new_n24_, new_n25_,
    new_n26_, new_n27_, new_n28_, new_n29_, new_n30_, new_n31_, new_n32_,
    new_n33_, new_n34_, new_n35_, new_n36_, new_n37_, new_n38_, new_n39_,
    new_n40_, new_n41_, new_n42_, new_n43_, new_n44_, new_n45_, new_n46_,
    new_n47_, new_n48_, new_n49_, new_n50_, new_n51_, new_n52_, new_n53_,
    new_n54_, new_n55_, new_n56_, new_n57_, new_n58_, new_n59_, new_n60_,
    new_n61_, new_n62_, new_n64_, new_n65_, new_n66_, new_n67_, new_n68_,
    new_n69_, new_n70_, new_n71_, new_n72_, new_n73_, new_n74_, new_n75_,
    new_n76_, new_n77_, new_n78_, new_n79_, new_n80_, new_n81_, new_n82_,
    new_n83_, new_n84_, new_n85_, new_n86_, new_n87_, new_n88_, new_n89_,
    new_n90_, new_n91_, new_n92_, new_n93_, new_n94_, new_n95_, new_n96_,
    new_n97_, new_n98_, new_n99_, new_n101_, new_n102_, new_n103_,
    new_n104_, new_n105_, new_n106_, new_n107_, new_n108_, new_n109_,
    new_n110_, new_n111_, new_n112_, new_n113_, new_n114_, new_n115_,
    new_n116_, new_n117_, new_n118_, new_n119_, new_n120_, new_n121_,
    new_n122_, new_n123_, new_n124_, new_n125_, new_n126_, new_n127_,
    new_n128_, new_n129_, new_n130_, new_n131_, new_n133_, new_n134_,
    new_n135_, new_n136_, new_n138_, new_n139_, new_n140_, new_n141_,
    new_n142_, new_n143_, new_n144_, new_n145_, new_n146_, new_n147_,
    new_n149_, new_n150_, new_n151_, new_n152_, new_n153_, new_n154_,
    new_n155_;
  NOR2x1_ASAP7_75t_R   g000(.A(p8), .B(p9), .Y(new_n19_));
  INVx1_ASAP7_75t_R    g001(.A(new_n19_), .Y(new_n20_));
  INVx1_ASAP7_75t_R    g002(.A(p10), .Y(new_n21_));
  NAND2x1_ASAP7_75t_R  g003(.A(p0), .B(p3), .Y(new_n22_));
  AOI211x1_ASAP7_75t_R g004(.A1(new_n21_), .A2(new_n22_), .B(p6), .C(p5), .Y(new_n23_));
  INVx1_ASAP7_75t_R    g005(.A(p3), .Y(new_n24_));
  NAND2x1_ASAP7_75t_R  g006(.A(p7), .B(new_n24_), .Y(new_n25_));
  AO21x1_ASAP7_75t_R   g007(.A1(new_n22_), .A2(new_n25_), .B(new_n21_), .Y(new_n26_));
  AO21x1_ASAP7_75t_R   g008(.A1(p7), .A2(p3), .B(p4), .Y(new_n27_));
  AO21x1_ASAP7_75t_R   g009(.A1(new_n23_), .A2(new_n26_), .B(new_n27_), .Y(new_n28_));
  INVx1_ASAP7_75t_R    g010(.A(p4), .Y(new_n29_));
  AO21x1_ASAP7_75t_R   g011(.A1(p7), .A2(new_n24_), .B(new_n29_), .Y(new_n30_));
  INVx1_ASAP7_75t_R    g012(.A(p7), .Y(new_n31_));
  INVx1_ASAP7_75t_R    g013(.A(p0), .Y(new_n32_));
  INVx1_ASAP7_75t_R    g014(.A(p2), .Y(new_n33_));
  OR5x1_ASAP7_75t_R    g015(.A(p1), .B(new_n29_), .C(new_n32_), .D(new_n33_), .E(p6), .Y(new_n34_));
  NAND2x1_ASAP7_75t_R  g016(.A(p2), .B(p3), .Y(new_n35_));
  NAND2x1_ASAP7_75t_R  g017(.A(p6), .B(new_n35_), .Y(new_n36_));
  AO21x1_ASAP7_75t_R   g018(.A1(new_n33_), .A2(new_n24_), .B(new_n36_), .Y(new_n37_));
  NAND2x1_ASAP7_75t_R  g019(.A(new_n34_), .B(new_n37_), .Y(new_n38_));
  AOI22x1_ASAP7_75t_R  g020(.A1(new_n28_), .A2(new_n30_), .B1(new_n31_), .B2(new_n38_), .Y(new_n39_));
  INVx1_ASAP7_75t_R    g021(.A(p9), .Y(new_n40_));
  INVx1_ASAP7_75t_R    g022(.A(p6), .Y(new_n41_));
  NOR2x1_ASAP7_75t_R   g023(.A(p3), .B(new_n41_), .Y(new_n42_));
  INVx1_ASAP7_75t_R    g024(.A(p5), .Y(new_n43_));
  NAND2x1_ASAP7_75t_R  g025(.A(p4), .B(new_n43_), .Y(new_n44_));
  OA21x2_ASAP7_75t_R   g026(.A1(p7), .A2(p2), .B(p3), .Y(new_n45_));
  OR5x1_ASAP7_75t_R    g027(.A(p1), .B(new_n42_), .C(new_n44_), .D(new_n32_), .E(new_n45_), .Y(new_n46_));
  NOR2x1_ASAP7_75t_R   g028(.A(p5), .B(new_n29_), .Y(new_n47_));
  NOR2x1_ASAP7_75t_R   g029(.A(p7), .B(p6), .Y(new_n48_));
  AO31x2_ASAP7_75t_R   g030(.A1(new_n48_), .A2(p1), .A3(new_n32_), .B(p8), .Y(new_n49_));
  AND3x1_ASAP7_75t_R   g031(.A(new_n29_), .B(p8), .C(p5), .Y(new_n50_));
  AOI21x1_ASAP7_75t_R  g032(.A1(new_n47_), .A2(new_n49_), .B(new_n50_), .Y(new_n51_));
  NAND2x1_ASAP7_75t_R  g033(.A(new_n46_), .B(new_n51_), .Y(new_n52_));
  NOR2x1_ASAP7_75t_R   g034(.A(p6), .B(new_n43_), .Y(new_n53_));
  INVx1_ASAP7_75t_R    g035(.A(p8), .Y(new_n54_));
  NAND2x1_ASAP7_75t_R  g036(.A(new_n54_), .B(new_n31_), .Y(new_n55_));
  XNOR2x2_ASAP7_75t_R  g037(.A(p1), .B(p2), .Y(new_n56_));
  OAI21x1_ASAP7_75t_R  g038(.A1(new_n55_), .A2(new_n56_), .B(new_n40_), .Y(new_n57_));
  AND3x1_ASAP7_75t_R   g039(.A(p8), .B(p7), .C(p5), .Y(new_n58_));
  NOR2x1_ASAP7_75t_R   g040(.A(p5), .B(new_n41_), .Y(new_n59_));
  OA21x2_ASAP7_75t_R   g041(.A1(new_n58_), .A2(new_n59_), .B(p9), .Y(new_n60_));
  AO21x1_ASAP7_75t_R   g042(.A1(new_n53_), .A2(new_n57_), .B(new_n60_), .Y(new_n61_));
  AOI21x1_ASAP7_75t_R  g043(.A1(new_n40_), .A2(new_n52_), .B(new_n61_), .Y(new_n62_));
  OAI21x1_ASAP7_75t_R  g044(.A1(new_n20_), .A2(new_n39_), .B(new_n62_), .Y(o0));
  NAND2x1_ASAP7_75t_R  g045(.A(p8), .B(new_n41_), .Y(new_n64_));
  OAI21x1_ASAP7_75t_R  g046(.A1(new_n55_), .A2(new_n36_), .B(new_n64_), .Y(new_n65_));
  OAI21x1_ASAP7_75t_R  g047(.A1(p6), .A2(p5), .B(new_n24_), .Y(new_n66_));
  OAI21x1_ASAP7_75t_R  g048(.A1(p8), .A2(p7), .B(p3), .Y(new_n67_));
  AO21x1_ASAP7_75t_R   g049(.A1(p1), .A2(p0), .B(p6), .Y(new_n68_));
  AND5x1_ASAP7_75t_R   g050(.A(p4), .B(new_n66_), .C(p2), .D(new_n67_), .E(new_n68_), .Y(new_n69_));
  AOI21x1_ASAP7_75t_R  g051(.A1(new_n29_), .A2(new_n65_), .B(new_n69_), .Y(new_n70_));
  NAND2x1_ASAP7_75t_R  g052(.A(new_n54_), .B(new_n24_), .Y(new_n71_));
  AO21x1_ASAP7_75t_R   g053(.A1(new_n64_), .A2(new_n71_), .B(new_n43_), .Y(new_n72_));
  NAND2x1_ASAP7_75t_R  g054(.A(p4), .B(p5), .Y(new_n73_));
  NAND3x1_ASAP7_75t_R  g055(.A(new_n71_), .B(new_n64_), .C(new_n73_), .Y(new_n74_));
  NAND3x1_ASAP7_75t_R  g056(.A(new_n72_), .B(new_n55_), .C(new_n74_), .Y(new_n75_));
  OAI22x1_ASAP7_75t_R  g057(.A1(p8), .A2(p3), .B1(p1), .B2(p6), .Y(new_n76_));
  AO22x1_ASAP7_75t_R   g058(.A1(new_n54_), .A2(p7), .B1(new_n32_), .B2(new_n76_), .Y(new_n77_));
  NAND2x1_ASAP7_75t_R  g059(.A(p1), .B(p0), .Y(new_n78_));
  NAND2x1_ASAP7_75t_R  g060(.A(p3), .B(new_n41_), .Y(new_n79_));
  INVx1_ASAP7_75t_R    g061(.A(p1), .Y(new_n80_));
  NOR2x1_ASAP7_75t_R   g062(.A(p10), .B(new_n80_), .Y(new_n81_));
  AOI211x1_ASAP7_75t_R g063(.A1(p10), .A2(new_n78_), .B(new_n79_), .C(new_n81_), .Y(new_n82_));
  NOR2x1_ASAP7_75t_R   g064(.A(p4), .B(p5), .Y(new_n83_));
  OAI21x1_ASAP7_75t_R  g065(.A1(new_n77_), .A2(new_n82_), .B(new_n83_), .Y(new_n84_));
  NAND3x1_ASAP7_75t_R  g066(.A(new_n70_), .B(new_n75_), .C(new_n84_), .Y(new_n85_));
  AO21x1_ASAP7_75t_R   g067(.A1(p6), .A2(p5), .B(p7), .Y(new_n86_));
  AO21x1_ASAP7_75t_R   g068(.A1(new_n40_), .A2(p6), .B(new_n86_), .Y(new_n87_));
  NOR2x1_ASAP7_75t_R   g069(.A(p0), .B(p5), .Y(new_n88_));
  AO32x1_ASAP7_75t_R   g070(.A1(new_n54_), .A2(p5), .A3(new_n24_), .B1(new_n88_), .B2(p4), .Y(new_n89_));
  NOR2x1_ASAP7_75t_R   g071(.A(p5), .B(p2), .Y(new_n90_));
  AO32x1_ASAP7_75t_R   g072(.A1(new_n54_), .A2(p5), .A3(new_n24_), .B1(new_n90_), .B2(p4), .Y(new_n91_));
  AND3x1_ASAP7_75t_R   g073(.A(p1), .B(p2), .C(p3), .Y(new_n92_));
  NOR2x1_ASAP7_75t_R   g074(.A(p8), .B(new_n43_), .Y(new_n93_));
  AO21x1_ASAP7_75t_R   g075(.A1(new_n92_), .A2(new_n93_), .B(p9), .Y(new_n94_));
  AOI221x1_ASAP7_75t_R g076(.A1(new_n89_), .A2(new_n33_), .B1(new_n80_), .B2(new_n91_), .C(new_n94_), .Y(new_n95_));
  NAND2x1_ASAP7_75t_R  g077(.A(p7), .B(p9), .Y(new_n96_));
  NAND2x1_ASAP7_75t_R  g078(.A(p6), .B(p5), .Y(new_n97_));
  OR3x1_ASAP7_75t_R    g079(.A(new_n96_), .B(new_n97_), .C(p8), .Y(new_n98_));
  OAI21x1_ASAP7_75t_R  g080(.A1(new_n87_), .A2(new_n95_), .B(new_n98_), .Y(new_n99_));
  AOI21x1_ASAP7_75t_R  g081(.A1(new_n40_), .A2(new_n85_), .B(new_n99_), .Y(o1));
  AND2x2_ASAP7_75t_R   g082(.A(p4), .B(p3), .Y(new_n101_));
  AO21x1_ASAP7_75t_R   g083(.A1(new_n101_), .A2(new_n53_), .B(new_n59_), .Y(new_n102_));
  OA21x2_ASAP7_75t_R   g084(.A1(new_n41_), .A2(new_n29_), .B(p8), .Y(new_n103_));
  AO21x1_ASAP7_75t_R   g085(.A1(new_n40_), .A2(new_n102_), .B(new_n103_), .Y(new_n104_));
  OR3x1_ASAP7_75t_R    g086(.A(new_n97_), .B(p7), .C(new_n29_), .Y(new_n105_));
  AO21x1_ASAP7_75t_R   g087(.A1(new_n40_), .A2(new_n105_), .B(new_n54_), .Y(new_n106_));
  OAI21x1_ASAP7_75t_R  g088(.A1(new_n96_), .A2(new_n97_), .B(new_n106_), .Y(new_n107_));
  AOI21x1_ASAP7_75t_R  g089(.A1(p7), .A2(new_n104_), .B(new_n107_), .Y(new_n108_));
  AND3x1_ASAP7_75t_R   g090(.A(new_n24_), .B(p4), .C(p2), .Y(new_n109_));
  AND4x2_ASAP7_75t_R   g091(.A(new_n43_), .B(new_n33_), .C(p10), .D(p3), .Y(new_n110_));
  OAI21x1_ASAP7_75t_R  g092(.A1(new_n109_), .A2(new_n110_), .B(p0), .Y(new_n111_));
  NOR2x1_ASAP7_75t_R   g093(.A(p5), .B(p3), .Y(new_n112_));
  NAND2x1_ASAP7_75t_R  g094(.A(p10), .B(p0), .Y(new_n113_));
  AND3x1_ASAP7_75t_R   g095(.A(new_n113_), .B(p2), .C(p3), .Y(new_n114_));
  OAI21x1_ASAP7_75t_R  g096(.A1(new_n112_), .A2(new_n114_), .B(new_n29_), .Y(new_n115_));
  NAND2x1_ASAP7_75t_R  g097(.A(p1), .B(new_n48_), .Y(new_n116_));
  AOI21x1_ASAP7_75t_R  g098(.A1(new_n111_), .A2(new_n115_), .B(new_n116_), .Y(new_n117_));
  AND3x1_ASAP7_75t_R   g099(.A(new_n29_), .B(p1), .C(p5), .Y(new_n118_));
  AO21x1_ASAP7_75t_R   g100(.A1(p4), .A2(new_n88_), .B(new_n35_), .Y(new_n119_));
  AOI21x1_ASAP7_75t_R  g101(.A1(new_n35_), .A2(new_n73_), .B(p7), .Y(new_n120_));
  OAI21x1_ASAP7_75t_R  g102(.A1(new_n118_), .A2(new_n119_), .B(new_n120_), .Y(new_n121_));
  AND3x1_ASAP7_75t_R   g103(.A(p4), .B(p2), .C(p3), .Y(new_n122_));
  NOR3x1_ASAP7_75t_R   g104(.A(new_n43_), .B(p1), .C(p6), .Y(new_n123_));
  AOI21x1_ASAP7_75t_R  g105(.A1(p4), .A2(p3), .B(new_n97_), .Y(new_n124_));
  AOI221x1_ASAP7_75t_R g106(.A1(new_n59_), .A2(new_n122_), .B1(new_n123_), .B2(new_n101_), .C(new_n124_), .Y(new_n125_));
  NOR2x1_ASAP7_75t_R   g107(.A(p2), .B(new_n29_), .Y(new_n126_));
  AND3x1_ASAP7_75t_R   g108(.A(new_n80_), .B(new_n43_), .C(p2), .Y(new_n127_));
  AND3x1_ASAP7_75t_R   g109(.A(new_n31_), .B(new_n41_), .C(p3), .Y(new_n128_));
  OAI21x1_ASAP7_75t_R  g110(.A1(new_n126_), .A2(new_n127_), .B(new_n128_), .Y(new_n129_));
  NAND3x1_ASAP7_75t_R  g111(.A(new_n121_), .B(new_n125_), .C(new_n129_), .Y(new_n130_));
  OAI21x1_ASAP7_75t_R  g112(.A1(new_n117_), .A2(new_n130_), .B(new_n19_), .Y(new_n131_));
  NAND2x1_ASAP7_75t_R  g113(.A(new_n108_), .B(new_n131_), .Y(o2));
  OR5x1_ASAP7_75t_R    g114(.A(p7), .B(p6), .C(p4), .D(p5), .E(p3), .Y(new_n133_));
  OR3x1_ASAP7_75t_R    g115(.A(new_n73_), .B(new_n31_), .C(new_n41_), .Y(new_n134_));
  OR3x1_ASAP7_75t_R    g116(.A(new_n134_), .B(p1), .C(new_n24_), .Y(new_n135_));
  OR3x1_ASAP7_75t_R    g117(.A(p8), .B(p9), .C(p2), .Y(new_n136_));
  AO21x1_ASAP7_75t_R   g118(.A1(new_n133_), .A2(new_n135_), .B(new_n136_), .Y(o3));
  OR3x1_ASAP7_75t_R    g119(.A(new_n80_), .B(new_n32_), .C(p6), .Y(new_n138_));
  AOI21x1_ASAP7_75t_R  g120(.A1(new_n73_), .A2(new_n138_), .B(new_n35_), .Y(new_n139_));
  AND3x1_ASAP7_75t_R   g121(.A(new_n41_), .B(new_n29_), .C(p3), .Y(new_n140_));
  OR4x2_ASAP7_75t_R    g122(.A(new_n139_), .B(p7), .C(new_n53_), .D(new_n140_), .Y(new_n141_));
  OAI21x1_ASAP7_75t_R  g123(.A1(p1), .A2(p2), .B(new_n101_), .Y(new_n142_));
  AO21x1_ASAP7_75t_R   g124(.A1(new_n31_), .A2(p2), .B(new_n142_), .Y(new_n143_));
  OR3x1_ASAP7_75t_R    g125(.A(new_n143_), .B(p8), .C(new_n97_), .Y(new_n144_));
  AO32x1_ASAP7_75t_R   g126(.A1(p10), .A2(p0), .A3(new_n83_), .B1(new_n53_), .B2(new_n101_), .Y(new_n145_));
  AND3x1_ASAP7_75t_R   g127(.A(new_n31_), .B(p1), .C(p2), .Y(new_n146_));
  AOI22x1_ASAP7_75t_R  g128(.A1(new_n145_), .A2(new_n146_), .B1(p8), .B2(new_n134_), .Y(new_n147_));
  AO31x2_ASAP7_75t_R   g129(.A1(new_n141_), .A2(new_n144_), .A3(new_n147_), .B(p9), .Y(o4));
  OR5x1_ASAP7_75t_R    g130(.A(p7), .B(new_n113_), .C(p6), .D(p4), .E(new_n33_), .Y(new_n149_));
  AO21x1_ASAP7_75t_R   g131(.A1(new_n80_), .A2(new_n33_), .B(new_n134_), .Y(new_n150_));
  OAI21x1_ASAP7_75t_R  g132(.A1(new_n80_), .A2(new_n149_), .B(new_n150_), .Y(new_n151_));
  AND3x1_ASAP7_75t_R   g133(.A(new_n92_), .B(p4), .C(p5), .Y(new_n152_));
  INVx1_ASAP7_75t_R    g134(.A(new_n48_), .Y(new_n153_));
  OR3x1_ASAP7_75t_R    g135(.A(new_n152_), .B(new_n153_), .C(new_n83_), .Y(new_n154_));
  NAND2x1_ASAP7_75t_R  g136(.A(new_n19_), .B(new_n154_), .Y(new_n155_));
  AO21x1_ASAP7_75t_R   g137(.A1(p3), .A2(new_n151_), .B(new_n155_), .Y(o5));
  OR3x1_ASAP7_75t_R    g138(.A(new_n152_), .B(new_n20_), .C(new_n153_), .Y(o6));
endmodule


