// Benchmark "/tmp/" written by ABC on Tue Oct 20 17:46:19 2026

module \/tmp/  ( 
    p2, p4, p1, p3, p0, p7, p10, p9, p5, p6, p8,
    o0, o1, o2, o3, o4, o5, o6  );
  input  p2, p4, p1, p3, p0, p7, p10, p9, p5, p6, p8;
  output o0, o1, o2, o3, o4, o5, o6;
  wire new_n19_, new_n20_, new_n21_, new_n22_, new_n23_, new_n24_, new_n25_,
    new_n26_, new_n27_, new_n28_, new_n29_, new_n30_, new_n31_, new_n32_,
    new_n33_, new_n34_, new_n35_, new_n36_, new_n37_, new_n38_, new_n39_,
    new_n40_, new_n41_, new_n42_, new_n43_, new_n44_, new_n45_, new_n46_,
    new_n47_, new_n48_, new_n49_, new_n50_, new_n51_, new_n52_, new_n53_,
    new_n54_, new_n55_, new_n56_, new_n57_, new_n58_, new_n59_, new_n60_,
    new_n61_, new_n62_, new_n64_, new_n65_, new_n66_, new_n67_, new_n68_,
    new_n69_, new_n70_, new_n71_, new_n72_, new_n73_, new_n74_, new_n75_,
    new_n76_, new_n77_, new_n78_, new_n79_, new_n80_, new_n81_, new_n82_,
    new_n83_, new_n84_, new_n85_, new_n86_, new_n87_, new_n88_, new_n89_,
    new_n90_, new_n91_, new_n92_, new_n93_, new_n94_, new_n95_, new_n96_,
    new_n97_, new_n99_, new_n100_, new_n101_, new_n102_, new_n103_,
    new_n104_, new_n105_, new_n106_, new_n107_, new_n108_, new_n109_,
    new_n110_, new_n111_, new_n112_, new_n113_, new_n114_, new_n115_,
    new_n116_, new_n117_, new_n118_, new_n119_, new_n120_, new_n121_,
    new_n122_, new_n123_, new_n124_, new_n125_, new_n126_, new_n127_,
    new_n128_, new_n130_, new_n131_, new_n132_, new_n134_, new_n135_,
    new_n136_, new_n137_, new_n138_, new_n139_, new_n140_, new_n141_,
    new_n142_, new_n143_, new_n144_, new_n145_, new_n146_, new_n147_,
    new_n149_, new_n150_, new_n151_, new_n152_, new_n153_;
  INVx1_ASAP7_75t_R    g000(.A(p10), .Y(new_n19_));
  NAND2x1_ASAP7_75t_R  g001(.A(p3), .B(p0), .Y(new_n20_));
  AOI211x1_ASAP7_75t_R g002(.A1(new_n19_), .A2(new_n20_), .B(p5), .C(p6), .Y(new_n21_));
  INVx1_ASAP7_75t_R    g003(.A(p3), .Y(new_n22_));
  NAND2x1_ASAP7_75t_R  g004(.A(p7), .B(new_n22_), .Y(new_n23_));
  AO21x1_ASAP7_75t_R   g005(.A1(new_n20_), .A2(new_n23_), .B(new_n19_), .Y(new_n24_));
  AO21x1_ASAP7_75t_R   g006(.A1(p3), .A2(p7), .B(p4), .Y(new_n25_));
  AO21x1_ASAP7_75t_R   g007(.A1(new_n21_), .A2(new_n24_), .B(new_n25_), .Y(new_n26_));
  INVx1_ASAP7_75t_R    g008(.A(p4), .Y(new_n27_));
  AO21x1_ASAP7_75t_R   g009(.A1(p7), .A2(new_n22_), .B(new_n27_), .Y(new_n28_));
  INVx1_ASAP7_75t_R    g010(.A(p7), .Y(new_n29_));
  INVx1_ASAP7_75t_R    g011(.A(p2), .Y(new_n30_));
  INVx1_ASAP7_75t_R    g012(.A(p0), .Y(new_n31_));
  OR5x1_ASAP7_75t_R    g013(.A(new_n30_), .B(new_n27_), .C(new_n31_), .D(p1), .E(p6), .Y(new_n32_));
  NAND2x1_ASAP7_75t_R  g014(.A(p2), .B(p3), .Y(new_n33_));
  NAND2x1_ASAP7_75t_R  g015(.A(p6), .B(new_n33_), .Y(new_n34_));
  AO21x1_ASAP7_75t_R   g016(.A1(new_n30_), .A2(new_n22_), .B(new_n34_), .Y(new_n35_));
  NAND2x1_ASAP7_75t_R  g017(.A(new_n32_), .B(new_n35_), .Y(new_n36_));
  AOI22x1_ASAP7_75t_R  g018(.A1(new_n26_), .A2(new_n28_), .B1(new_n29_), .B2(new_n36_), .Y(new_n37_));
  NOR2x1_ASAP7_75t_R   g019(.A(p9), .B(p8), .Y(new_n38_));
  INVx1_ASAP7_75t_R    g020(.A(new_n38_), .Y(new_n39_));
  INVx1_ASAP7_75t_R    g021(.A(p9), .Y(new_n40_));
  NOR2x1_ASAP7_75t_R   g022(.A(p5), .B(new_n27_), .Y(new_n41_));
  INVx1_ASAP7_75t_R    g023(.A(new_n41_), .Y(new_n42_));
  INVx1_ASAP7_75t_R    g024(.A(p6), .Y(new_n43_));
  NOR2x1_ASAP7_75t_R   g025(.A(p3), .B(new_n43_), .Y(new_n44_));
  AND2x2_ASAP7_75t_R   g026(.A(p3), .B(p7), .Y(new_n45_));
  AND2x2_ASAP7_75t_R   g027(.A(p2), .B(p3), .Y(new_n46_));
  OR5x1_ASAP7_75t_R    g028(.A(p1), .B(new_n44_), .C(new_n31_), .D(new_n45_), .E(new_n46_), .Y(new_n47_));
  NOR2x1_ASAP7_75t_R   g029(.A(p7), .B(p6), .Y(new_n48_));
  AO31x2_ASAP7_75t_R   g030(.A1(new_n48_), .A2(p1), .A3(new_n31_), .B(p8), .Y(new_n49_));
  AND3x1_ASAP7_75t_R   g031(.A(new_n27_), .B(p5), .C(p8), .Y(new_n50_));
  AOI21x1_ASAP7_75t_R  g032(.A1(new_n41_), .A2(new_n49_), .B(new_n50_), .Y(new_n51_));
  OAI21x1_ASAP7_75t_R  g033(.A1(new_n42_), .A2(new_n47_), .B(new_n51_), .Y(new_n52_));
  NAND2x1_ASAP7_75t_R  g034(.A(p5), .B(new_n43_), .Y(new_n53_));
  INVx1_ASAP7_75t_R    g035(.A(p8), .Y(new_n54_));
  NAND2x1_ASAP7_75t_R  g036(.A(new_n29_), .B(new_n54_), .Y(new_n55_));
  XNOR2x2_ASAP7_75t_R  g037(.A(p2), .B(p1), .Y(new_n56_));
  OA21x2_ASAP7_75t_R   g038(.A1(new_n55_), .A2(new_n56_), .B(new_n40_), .Y(new_n57_));
  AND3x1_ASAP7_75t_R   g039(.A(p7), .B(p5), .C(p8), .Y(new_n58_));
  NOR2x1_ASAP7_75t_R   g040(.A(p5), .B(new_n43_), .Y(new_n59_));
  OAI21x1_ASAP7_75t_R  g041(.A1(new_n58_), .A2(new_n59_), .B(p9), .Y(new_n60_));
  OAI21x1_ASAP7_75t_R  g042(.A1(new_n53_), .A2(new_n57_), .B(new_n60_), .Y(new_n61_));
  AOI21x1_ASAP7_75t_R  g043(.A1(new_n40_), .A2(new_n52_), .B(new_n61_), .Y(new_n62_));
  OAI21x1_ASAP7_75t_R  g044(.A1(new_n37_), .A2(new_n39_), .B(new_n62_), .Y(o0));
  NOR2x1_ASAP7_75t_R   g045(.A(p3), .B(p8), .Y(new_n64_));
  INVx1_ASAP7_75t_R    g046(.A(p5), .Y(new_n65_));
  AO21x1_ASAP7_75t_R   g047(.A1(new_n29_), .A2(new_n54_), .B(new_n65_), .Y(new_n66_));
  AOI211x1_ASAP7_75t_R g048(.A1(new_n43_), .A2(p8), .B(new_n64_), .C(new_n66_), .Y(new_n67_));
  OR3x1_ASAP7_75t_R    g049(.A(new_n22_), .B(p7), .C(p8), .Y(new_n68_));
  OR3x1_ASAP7_75t_R    g050(.A(p3), .B(p5), .C(p6), .Y(new_n69_));
  NAND2x1_ASAP7_75t_R  g051(.A(p1), .B(p0), .Y(new_n70_));
  AO21x1_ASAP7_75t_R   g052(.A1(new_n43_), .A2(new_n70_), .B(new_n30_), .Y(new_n71_));
  AOI21x1_ASAP7_75t_R  g053(.A1(new_n68_), .A2(new_n69_), .B(new_n71_), .Y(new_n72_));
  OAI21x1_ASAP7_75t_R  g054(.A1(new_n67_), .A2(new_n72_), .B(p4), .Y(new_n73_));
  INVx1_ASAP7_75t_R    g055(.A(p1), .Y(new_n74_));
  AOI21x1_ASAP7_75t_R  g056(.A1(new_n74_), .A2(new_n43_), .B(new_n64_), .Y(new_n75_));
  OAI22x1_ASAP7_75t_R  g057(.A1(new_n75_), .A2(p0), .B1(new_n29_), .B2(p8), .Y(new_n76_));
  AO21x1_ASAP7_75t_R   g058(.A1(p1), .A2(new_n19_), .B(p6), .Y(new_n77_));
  AOI211x1_ASAP7_75t_R g059(.A1(p10), .A2(new_n70_), .B(new_n22_), .C(new_n77_), .Y(new_n78_));
  NOR2x1_ASAP7_75t_R   g060(.A(p4), .B(p5), .Y(new_n79_));
  OAI21x1_ASAP7_75t_R  g061(.A1(new_n76_), .A2(new_n78_), .B(new_n79_), .Y(new_n80_));
  NAND2x1_ASAP7_75t_R  g062(.A(p8), .B(new_n43_), .Y(new_n81_));
  OAI21x1_ASAP7_75t_R  g063(.A1(new_n55_), .A2(new_n34_), .B(new_n81_), .Y(new_n82_));
  NAND2x1_ASAP7_75t_R  g064(.A(p7), .B(new_n64_), .Y(new_n83_));
  NAND2x1_ASAP7_75t_R  g065(.A(new_n81_), .B(new_n83_), .Y(new_n84_));
  AOI22x1_ASAP7_75t_R  g066(.A1(new_n82_), .A2(new_n27_), .B1(new_n65_), .B2(new_n84_), .Y(new_n85_));
  NAND3x1_ASAP7_75t_R  g067(.A(new_n73_), .B(new_n80_), .C(new_n85_), .Y(new_n86_));
  NAND2x1_ASAP7_75t_R  g068(.A(p2), .B(p1), .Y(new_n87_));
  NOR2x1_ASAP7_75t_R   g069(.A(p8), .B(new_n87_), .Y(new_n88_));
  OR3x1_ASAP7_75t_R    g070(.A(new_n88_), .B(new_n65_), .C(new_n64_), .Y(new_n89_));
  INVx1_ASAP7_75t_R    g071(.A(new_n79_), .Y(new_n90_));
  NAND2x1_ASAP7_75t_R  g072(.A(p2), .B(new_n65_), .Y(new_n91_));
  AND3x1_ASAP7_75t_R   g073(.A(new_n90_), .B(new_n91_), .C(new_n43_), .Y(new_n92_));
  OA22x2_ASAP7_75t_R   g074(.A1(p3), .A2(new_n87_), .B1(p5), .B2(new_n70_), .Y(new_n93_));
  NAND3x1_ASAP7_75t_R  g075(.A(new_n89_), .B(new_n92_), .C(new_n93_), .Y(new_n94_));
  AO21x1_ASAP7_75t_R   g076(.A1(p5), .A2(p6), .B(p7), .Y(new_n95_));
  OR4x2_ASAP7_75t_R    g077(.A(new_n29_), .B(new_n65_), .C(new_n43_), .D(p8), .Y(new_n96_));
  AOI22x1_ASAP7_75t_R  g078(.A1(new_n94_), .A2(new_n40_), .B1(new_n95_), .B2(new_n96_), .Y(new_n97_));
  AOI21x1_ASAP7_75t_R  g079(.A1(new_n40_), .A2(new_n86_), .B(new_n97_), .Y(o1));
  NAND2x1_ASAP7_75t_R  g080(.A(p3), .B(new_n74_), .Y(new_n99_));
  NAND2x1_ASAP7_75t_R  g081(.A(p3), .B(new_n30_), .Y(new_n100_));
  OAI22x1_ASAP7_75t_R  g082(.A1(new_n91_), .A2(new_n99_), .B1(new_n100_), .B2(new_n27_), .Y(new_n101_));
  OAI21x1_ASAP7_75t_R  g083(.A1(p1), .A2(new_n101_), .B(new_n48_), .Y(new_n102_));
  NAND2x1_ASAP7_75t_R  g084(.A(p0), .B(p10), .Y(new_n103_));
  NOR2x1_ASAP7_75t_R   g085(.A(p3), .B(p5), .Y(new_n104_));
  AO21x1_ASAP7_75t_R   g086(.A1(new_n103_), .A2(new_n46_), .B(new_n104_), .Y(new_n105_));
  NAND2x1_ASAP7_75t_R  g087(.A(p10), .B(new_n65_), .Y(new_n106_));
  NAND3x1_ASAP7_75t_R  g088(.A(new_n22_), .B(p2), .C(p4), .Y(new_n107_));
  OAI21x1_ASAP7_75t_R  g089(.A1(new_n100_), .A2(new_n106_), .B(new_n107_), .Y(new_n108_));
  AOI221x1_ASAP7_75t_R g090(.A1(new_n27_), .A2(new_n105_), .B1(new_n108_), .B2(p0), .C(new_n101_), .Y(new_n109_));
  NAND2x1_ASAP7_75t_R  g091(.A(p4), .B(p3), .Y(new_n110_));
  NOR2x1_ASAP7_75t_R   g092(.A(new_n110_), .B(new_n53_), .Y(new_n111_));
  NAND3x1_ASAP7_75t_R  g093(.A(new_n31_), .B(new_n65_), .C(p4), .Y(new_n112_));
  NAND3x1_ASAP7_75t_R  g094(.A(new_n27_), .B(p1), .C(p5), .Y(new_n113_));
  NAND3x1_ASAP7_75t_R  g095(.A(new_n112_), .B(new_n113_), .C(new_n46_), .Y(new_n114_));
  NAND2x1_ASAP7_75t_R  g096(.A(p4), .B(p5), .Y(new_n115_));
  AOI21x1_ASAP7_75t_R  g097(.A1(new_n33_), .A2(new_n115_), .B(p7), .Y(new_n116_));
  AND2x2_ASAP7_75t_R   g098(.A(p5), .B(p6), .Y(new_n117_));
  AND3x1_ASAP7_75t_R   g099(.A(p2), .B(p4), .C(p3), .Y(new_n118_));
  AO22x1_ASAP7_75t_R   g100(.A1(new_n117_), .A2(new_n110_), .B1(new_n118_), .B2(new_n59_), .Y(new_n119_));
  AOI221x1_ASAP7_75t_R g101(.A1(new_n74_), .A2(new_n111_), .B1(new_n114_), .B2(new_n116_), .C(new_n119_), .Y(new_n120_));
  OAI21x1_ASAP7_75t_R  g102(.A1(new_n102_), .A2(new_n109_), .B(new_n120_), .Y(new_n121_));
  OAI21x1_ASAP7_75t_R  g103(.A1(new_n59_), .A2(new_n111_), .B(p7), .Y(new_n122_));
  OR3x1_ASAP7_75t_R    g104(.A(new_n27_), .B(new_n54_), .C(p7), .Y(new_n123_));
  OAI21x1_ASAP7_75t_R  g105(.A1(new_n29_), .A2(new_n40_), .B(new_n123_), .Y(new_n124_));
  OR3x1_ASAP7_75t_R    g106(.A(new_n27_), .B(new_n43_), .C(p9), .Y(new_n125_));
  OA21x2_ASAP7_75t_R   g107(.A1(p7), .A2(p9), .B(p8), .Y(new_n126_));
  AOI22x1_ASAP7_75t_R  g108(.A1(new_n124_), .A2(new_n117_), .B1(new_n125_), .B2(new_n126_), .Y(new_n127_));
  OAI21x1_ASAP7_75t_R  g109(.A1(p9), .A2(new_n122_), .B(new_n127_), .Y(new_n128_));
  AO21x1_ASAP7_75t_R   g110(.A1(new_n38_), .A2(new_n121_), .B(new_n128_), .Y(o2));
  OR3x1_ASAP7_75t_R    g111(.A(new_n115_), .B(new_n29_), .C(new_n43_), .Y(new_n130_));
  OR5x1_ASAP7_75t_R    g112(.A(p4), .B(p3), .C(p7), .D(p5), .E(p6), .Y(new_n131_));
  OA21x2_ASAP7_75t_R   g113(.A1(new_n99_), .A2(new_n130_), .B(new_n131_), .Y(new_n132_));
  OR3x1_ASAP7_75t_R    g114(.A(new_n132_), .B(p2), .C(new_n39_), .Y(o3));
  AND3x1_ASAP7_75t_R   g115(.A(new_n79_), .B(p0), .C(p10), .Y(new_n134_));
  NOR2x1_ASAP7_75t_R   g116(.A(p7), .B(new_n87_), .Y(new_n135_));
  OAI21x1_ASAP7_75t_R  g117(.A1(new_n134_), .A2(new_n111_), .B(new_n135_), .Y(new_n136_));
  NOR2x1_ASAP7_75t_R   g118(.A(p7), .B(new_n30_), .Y(new_n137_));
  NOR2x1_ASAP7_75t_R   g119(.A(p2), .B(p1), .Y(new_n138_));
  NAND2x1_ASAP7_75t_R  g120(.A(p5), .B(p6), .Y(new_n139_));
  OR5x1_ASAP7_75t_R    g121(.A(p8), .B(new_n137_), .C(new_n138_), .D(new_n139_), .E(new_n110_), .Y(new_n140_));
  NAND2x1_ASAP7_75t_R  g122(.A(p8), .B(new_n130_), .Y(new_n141_));
  AND3x1_ASAP7_75t_R   g123(.A(new_n136_), .B(new_n140_), .C(new_n141_), .Y(new_n142_));
  OR3x1_ASAP7_75t_R    g124(.A(new_n74_), .B(new_n31_), .C(p6), .Y(new_n143_));
  AOI21x1_ASAP7_75t_R  g125(.A1(new_n115_), .A2(new_n143_), .B(new_n33_), .Y(new_n144_));
  NOR2x1_ASAP7_75t_R   g126(.A(p6), .B(new_n65_), .Y(new_n145_));
  AND3x1_ASAP7_75t_R   g127(.A(new_n27_), .B(new_n43_), .C(p3), .Y(new_n146_));
  OR4x2_ASAP7_75t_R    g128(.A(new_n144_), .B(p7), .C(new_n145_), .D(new_n146_), .Y(new_n147_));
  AO21x1_ASAP7_75t_R   g129(.A1(new_n142_), .A2(new_n147_), .B(p9), .Y(o4));
  OR5x1_ASAP7_75t_R    g130(.A(p4), .B(new_n87_), .C(new_n103_), .D(p7), .E(p6), .Y(new_n149_));
  OA21x2_ASAP7_75t_R   g131(.A1(new_n138_), .A2(new_n130_), .B(new_n149_), .Y(new_n150_));
  NOR2x1_ASAP7_75t_R   g132(.A(new_n22_), .B(new_n150_), .Y(new_n151_));
  OR3x1_ASAP7_75t_R    g133(.A(new_n33_), .B(new_n115_), .C(new_n74_), .Y(new_n152_));
  AND3x1_ASAP7_75t_R   g134(.A(new_n152_), .B(new_n90_), .C(new_n48_), .Y(new_n153_));
  OR3x1_ASAP7_75t_R    g135(.A(new_n151_), .B(new_n39_), .C(new_n153_), .Y(o5));
  NAND3x1_ASAP7_75t_R  g136(.A(new_n152_), .B(new_n38_), .C(new_n48_), .Y(o6));
endmodule


