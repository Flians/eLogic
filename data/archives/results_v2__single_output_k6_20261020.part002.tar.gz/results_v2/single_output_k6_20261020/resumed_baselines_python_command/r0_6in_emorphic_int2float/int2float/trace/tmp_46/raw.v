// Benchmark "/tmp/" written by ABC on Tue Oct 20 17:46:18 2026

module \/tmp/  ( 
    p6, p5, p0, p10, p9, p8, p7, p1, p4, p3, p2,
    o0, o1, o2, o3, o4, o5, o6  );
  input  p6, p5, p0, p10, p9, p8, p7, p1, p4, p3, p2;
  output o0, o1, o2, o3, o4, o5, o6;
  wire new_n19_, new_n20_, new_n21_, new_n22_, new_n23_, new_n24_, new_n25_,
    new_n26_, new_n27_, new_n28_, new_n29_, new_n30_, new_n31_, new_n32_,
    new_n33_, new_n34_, new_n35_, new_n36_, new_n37_, new_n38_, new_n39_,
    new_n40_, new_n41_, new_n42_, new_n43_, new_n44_, new_n45_, new_n46_,
    new_n47_, new_n48_, new_n49_, new_n50_, new_n51_, new_n52_, new_n53_,
    new_n54_, new_n55_, new_n56_, new_n57_, new_n58_, new_n59_, new_n60_,
    new_n62_, new_n63_, new_n64_, new_n65_, new_n66_, new_n67_, new_n68_,
    new_n69_, new_n70_, new_n71_, new_n72_, new_n73_, new_n74_, new_n75_,
    new_n76_, new_n77_, new_n78_, new_n79_, new_n80_, new_n81_, new_n82_,
    new_n83_, new_n84_, new_n85_, new_n86_, new_n87_, new_n88_, new_n89_,
    new_n90_, new_n91_, new_n92_, new_n93_, new_n94_, new_n95_, new_n96_,
    new_n97_, new_n98_, new_n99_, new_n100_, new_n101_, new_n103_,
    new_n104_, new_n105_, new_n106_, new_n107_, new_n108_, new_n109_,
    new_n110_, new_n111_, new_n112_, new_n113_, new_n114_, new_n115_,
    new_n116_, new_n117_, new_n118_, new_n119_, new_n120_, new_n121_,
    new_n122_, new_n123_, new_n124_, new_n125_, new_n126_, new_n127_,
    new_n128_, new_n129_, new_n130_, new_n131_, new_n132_, new_n133_,
    new_n135_, new_n136_, new_n137_, new_n138_, new_n140_, new_n141_,
    new_n142_, new_n143_, new_n144_, new_n145_, new_n146_, new_n147_,
    new_n148_, new_n149_, new_n150_, new_n151_, new_n152_, new_n154_,
    new_n155_, new_n156_, new_n157_, new_n158_, new_n159_;
  INVx1_ASAP7_75t_R    g000(.A(p4), .Y(new_n19_));
  INVx1_ASAP7_75t_R    g001(.A(p10), .Y(new_n20_));
  NAND2x1_ASAP7_75t_R  g002(.A(p0), .B(p3), .Y(new_n21_));
  INVx1_ASAP7_75t_R    g003(.A(p6), .Y(new_n22_));
  INVx1_ASAP7_75t_R    g004(.A(p5), .Y(new_n23_));
  NAND2x1_ASAP7_75t_R  g005(.A(new_n22_), .B(new_n23_), .Y(new_n24_));
  AO21x1_ASAP7_75t_R   g006(.A1(new_n20_), .A2(new_n21_), .B(new_n24_), .Y(new_n25_));
  INVx1_ASAP7_75t_R    g007(.A(p3), .Y(new_n26_));
  NAND2x1_ASAP7_75t_R  g008(.A(p7), .B(new_n26_), .Y(new_n27_));
  AOI21x1_ASAP7_75t_R  g009(.A1(new_n21_), .A2(new_n27_), .B(new_n20_), .Y(new_n28_));
  INVx1_ASAP7_75t_R    g010(.A(p7), .Y(new_n29_));
  OAI22x1_ASAP7_75t_R  g011(.A1(new_n25_), .A2(new_n28_), .B1(new_n29_), .B2(new_n26_), .Y(new_n30_));
  AND3x1_ASAP7_75t_R   g012(.A(new_n22_), .B(p4), .C(p2), .Y(new_n31_));
  INVx1_ASAP7_75t_R    g013(.A(p0), .Y(new_n32_));
  NOR2x1_ASAP7_75t_R   g014(.A(p1), .B(new_n32_), .Y(new_n33_));
  AOI21x1_ASAP7_75t_R  g015(.A1(p3), .A2(p2), .B(new_n22_), .Y(new_n34_));
  INVx1_ASAP7_75t_R    g016(.A(p2), .Y(new_n35_));
  NAND2x1_ASAP7_75t_R  g017(.A(new_n26_), .B(new_n35_), .Y(new_n36_));
  AOI22x1_ASAP7_75t_R  g018(.A1(new_n31_), .A2(new_n33_), .B1(new_n34_), .B2(new_n36_), .Y(new_n37_));
  OAI22x1_ASAP7_75t_R  g019(.A1(new_n37_), .A2(p7), .B1(new_n19_), .B2(new_n27_), .Y(new_n38_));
  AOI21x1_ASAP7_75t_R  g020(.A1(new_n19_), .A2(new_n30_), .B(new_n38_), .Y(new_n39_));
  NOR2x1_ASAP7_75t_R   g021(.A(p9), .B(p8), .Y(new_n40_));
  INVx1_ASAP7_75t_R    g022(.A(new_n40_), .Y(new_n41_));
  INVx1_ASAP7_75t_R    g023(.A(p9), .Y(new_n42_));
  AOI211x1_ASAP7_75t_R g024(.A1(p6), .A2(new_n26_), .B(new_n32_), .C(p1), .Y(new_n43_));
  AO21x1_ASAP7_75t_R   g025(.A1(new_n29_), .A2(new_n35_), .B(new_n26_), .Y(new_n44_));
  NOR2x1_ASAP7_75t_R   g026(.A(p5), .B(new_n19_), .Y(new_n45_));
  NAND3x1_ASAP7_75t_R  g027(.A(new_n43_), .B(new_n44_), .C(new_n45_), .Y(new_n46_));
  NOR2x1_ASAP7_75t_R   g028(.A(p6), .B(p7), .Y(new_n47_));
  AO31x2_ASAP7_75t_R   g029(.A1(new_n47_), .A2(new_n32_), .A3(p1), .B(p8), .Y(new_n48_));
  AND3x1_ASAP7_75t_R   g030(.A(new_n19_), .B(p5), .C(p8), .Y(new_n49_));
  AOI21x1_ASAP7_75t_R  g031(.A1(new_n45_), .A2(new_n48_), .B(new_n49_), .Y(new_n50_));
  NAND2x1_ASAP7_75t_R  g032(.A(new_n46_), .B(new_n50_), .Y(new_n51_));
  NAND2x1_ASAP7_75t_R  g033(.A(p5), .B(new_n22_), .Y(new_n52_));
  NOR2x1_ASAP7_75t_R   g034(.A(p8), .B(p7), .Y(new_n53_));
  XOR2x2_ASAP7_75t_R   g035(.A(p1), .B(p2), .Y(new_n54_));
  AOI21x1_ASAP7_75t_R  g036(.A1(new_n53_), .A2(new_n54_), .B(p9), .Y(new_n55_));
  NOR2x1_ASAP7_75t_R   g037(.A(p5), .B(new_n22_), .Y(new_n56_));
  AND3x1_ASAP7_75t_R   g038(.A(p9), .B(p8), .C(p7), .Y(new_n57_));
  AOI22x1_ASAP7_75t_R  g039(.A1(new_n56_), .A2(p9), .B1(p5), .B2(new_n57_), .Y(new_n58_));
  OAI21x1_ASAP7_75t_R  g040(.A1(new_n52_), .A2(new_n55_), .B(new_n58_), .Y(new_n59_));
  AOI21x1_ASAP7_75t_R  g041(.A1(new_n42_), .A2(new_n51_), .B(new_n59_), .Y(new_n60_));
  OAI21x1_ASAP7_75t_R  g042(.A1(new_n39_), .A2(new_n41_), .B(new_n60_), .Y(o0));
  INVx1_ASAP7_75t_R    g043(.A(p8), .Y(new_n62_));
  NOR2x1_ASAP7_75t_R   g044(.A(p6), .B(new_n62_), .Y(new_n63_));
  AO21x1_ASAP7_75t_R   g045(.A1(new_n53_), .A2(new_n34_), .B(new_n63_), .Y(new_n64_));
  OAI21x1_ASAP7_75t_R  g046(.A1(p6), .A2(p5), .B(new_n26_), .Y(new_n65_));
  OAI21x1_ASAP7_75t_R  g047(.A1(p8), .A2(p7), .B(p3), .Y(new_n66_));
  AO21x1_ASAP7_75t_R   g048(.A1(p0), .A2(p1), .B(p6), .Y(new_n67_));
  AND5x1_ASAP7_75t_R   g049(.A(p4), .B(new_n65_), .C(p2), .D(new_n66_), .E(new_n67_), .Y(new_n68_));
  AOI21x1_ASAP7_75t_R  g050(.A1(new_n19_), .A2(new_n64_), .B(new_n68_), .Y(new_n69_));
  OAI22x1_ASAP7_75t_R  g051(.A1(p6), .A2(p1), .B1(p8), .B2(p3), .Y(new_n70_));
  AO22x1_ASAP7_75t_R   g052(.A1(new_n62_), .A2(p7), .B1(new_n32_), .B2(new_n70_), .Y(new_n71_));
  NAND2x1_ASAP7_75t_R  g053(.A(p0), .B(p10), .Y(new_n72_));
  NAND2x1_ASAP7_75t_R  g054(.A(p3), .B(new_n22_), .Y(new_n73_));
  NOR2x1_ASAP7_75t_R   g055(.A(p1), .B(new_n20_), .Y(new_n74_));
  AOI211x1_ASAP7_75t_R g056(.A1(p1), .A2(new_n72_), .B(new_n73_), .C(new_n74_), .Y(new_n75_));
  NOR2x1_ASAP7_75t_R   g057(.A(p5), .B(p4), .Y(new_n76_));
  OAI21x1_ASAP7_75t_R  g058(.A1(new_n71_), .A2(new_n75_), .B(new_n76_), .Y(new_n77_));
  NAND2x1_ASAP7_75t_R  g059(.A(p8), .B(new_n22_), .Y(new_n78_));
  NAND2x1_ASAP7_75t_R  g060(.A(new_n62_), .B(new_n26_), .Y(new_n79_));
  AO21x1_ASAP7_75t_R   g061(.A1(new_n78_), .A2(new_n79_), .B(new_n23_), .Y(new_n80_));
  INVx1_ASAP7_75t_R    g062(.A(new_n53_), .Y(new_n81_));
  NAND2x1_ASAP7_75t_R  g063(.A(p5), .B(p4), .Y(new_n82_));
  NAND3x1_ASAP7_75t_R  g064(.A(new_n79_), .B(new_n78_), .C(new_n82_), .Y(new_n83_));
  NAND3x1_ASAP7_75t_R  g065(.A(new_n80_), .B(new_n81_), .C(new_n83_), .Y(new_n84_));
  NAND3x1_ASAP7_75t_R  g066(.A(new_n69_), .B(new_n77_), .C(new_n84_), .Y(new_n85_));
  AO21x1_ASAP7_75t_R   g067(.A1(p6), .A2(p5), .B(p7), .Y(new_n86_));
  AO21x1_ASAP7_75t_R   g068(.A1(p6), .A2(new_n42_), .B(new_n86_), .Y(new_n87_));
  NOR2x1_ASAP7_75t_R   g069(.A(p5), .B(p2), .Y(new_n88_));
  AO32x1_ASAP7_75t_R   g070(.A1(p5), .A2(new_n62_), .A3(new_n26_), .B1(new_n88_), .B2(p4), .Y(new_n89_));
  INVx1_ASAP7_75t_R    g071(.A(p1), .Y(new_n90_));
  NOR2x1_ASAP7_75t_R   g072(.A(p5), .B(p0), .Y(new_n91_));
  AO32x1_ASAP7_75t_R   g073(.A1(p5), .A2(new_n62_), .A3(new_n26_), .B1(new_n91_), .B2(p4), .Y(new_n92_));
  AND3x1_ASAP7_75t_R   g074(.A(p1), .B(p3), .C(p2), .Y(new_n93_));
  NOR2x1_ASAP7_75t_R   g075(.A(p8), .B(new_n23_), .Y(new_n94_));
  AO21x1_ASAP7_75t_R   g076(.A1(new_n93_), .A2(new_n94_), .B(p9), .Y(new_n95_));
  AOI221x1_ASAP7_75t_R g077(.A1(new_n89_), .A2(new_n90_), .B1(new_n35_), .B2(new_n92_), .C(new_n95_), .Y(new_n96_));
  AND2x2_ASAP7_75t_R   g078(.A(p6), .B(p5), .Y(new_n97_));
  INVx1_ASAP7_75t_R    g079(.A(new_n97_), .Y(new_n98_));
  NAND2x1_ASAP7_75t_R  g080(.A(p9), .B(p7), .Y(new_n99_));
  OR3x1_ASAP7_75t_R    g081(.A(new_n98_), .B(p8), .C(new_n99_), .Y(new_n100_));
  OAI21x1_ASAP7_75t_R  g082(.A1(new_n87_), .A2(new_n96_), .B(new_n100_), .Y(new_n101_));
  AOI21x1_ASAP7_75t_R  g083(.A1(new_n42_), .A2(new_n85_), .B(new_n101_), .Y(o1));
  AND3x1_ASAP7_75t_R   g084(.A(new_n22_), .B(new_n29_), .C(p1), .Y(new_n103_));
  AND2x2_ASAP7_75t_R   g085(.A(p3), .B(p2), .Y(new_n104_));
  AOI22x1_ASAP7_75t_R  g086(.A1(new_n104_), .A2(new_n72_), .B1(new_n23_), .B2(new_n26_), .Y(new_n105_));
  OA31x2_ASAP7_75t_R   g087(.A1(p5), .A2(p2), .A3(new_n20_), .B1(p3), .Y(new_n106_));
  NAND2x1_ASAP7_75t_R  g088(.A(p4), .B(p2), .Y(new_n107_));
  AO21x1_ASAP7_75t_R   g089(.A1(new_n26_), .A2(new_n107_), .B(new_n32_), .Y(new_n108_));
  OAI22x1_ASAP7_75t_R  g090(.A1(new_n105_), .A2(p4), .B1(new_n106_), .B2(new_n108_), .Y(new_n109_));
  NOR2x1_ASAP7_75t_R   g091(.A(p2), .B(new_n19_), .Y(new_n110_));
  NOR3x1_ASAP7_75t_R   g092(.A(new_n35_), .B(p5), .C(p1), .Y(new_n111_));
  AND3x1_ASAP7_75t_R   g093(.A(new_n22_), .B(new_n29_), .C(p3), .Y(new_n112_));
  OAI21x1_ASAP7_75t_R  g094(.A1(new_n110_), .A2(new_n111_), .B(new_n112_), .Y(new_n113_));
  OR4x2_ASAP7_75t_R    g095(.A(new_n82_), .B(p6), .C(p1), .D(new_n26_), .Y(new_n114_));
  AND3x1_ASAP7_75t_R   g096(.A(p4), .B(p3), .C(p2), .Y(new_n115_));
  NAND2x1_ASAP7_75t_R  g097(.A(p4), .B(p3), .Y(new_n116_));
  AOI22x1_ASAP7_75t_R  g098(.A1(new_n56_), .A2(new_n115_), .B1(new_n97_), .B2(new_n116_), .Y(new_n117_));
  NAND3x1_ASAP7_75t_R  g099(.A(new_n113_), .B(new_n114_), .C(new_n117_), .Y(new_n118_));
  AND3x1_ASAP7_75t_R   g100(.A(new_n19_), .B(p5), .C(p1), .Y(new_n119_));
  NAND2x1_ASAP7_75t_R  g101(.A(p3), .B(p2), .Y(new_n120_));
  AO21x1_ASAP7_75t_R   g102(.A1(p4), .A2(new_n91_), .B(new_n120_), .Y(new_n121_));
  AND2x2_ASAP7_75t_R   g103(.A(p5), .B(p4), .Y(new_n122_));
  OA21x2_ASAP7_75t_R   g104(.A1(new_n104_), .A2(new_n122_), .B(new_n29_), .Y(new_n123_));
  OA21x2_ASAP7_75t_R   g105(.A1(new_n119_), .A2(new_n121_), .B(new_n123_), .Y(new_n124_));
  AOI211x1_ASAP7_75t_R g106(.A1(new_n103_), .A2(new_n109_), .B(new_n118_), .C(new_n124_), .Y(new_n125_));
  NOR2x1_ASAP7_75t_R   g107(.A(new_n116_), .B(new_n52_), .Y(new_n126_));
  OAI21x1_ASAP7_75t_R  g108(.A1(new_n56_), .A2(new_n126_), .B(p7), .Y(new_n127_));
  OR3x1_ASAP7_75t_R    g109(.A(new_n62_), .B(new_n19_), .C(p7), .Y(new_n128_));
  AO21x1_ASAP7_75t_R   g110(.A1(new_n99_), .A2(new_n128_), .B(new_n98_), .Y(new_n129_));
  AND3x1_ASAP7_75t_R   g111(.A(new_n42_), .B(p6), .C(p4), .Y(new_n130_));
  NOR2x1_ASAP7_75t_R   g112(.A(p9), .B(p7), .Y(new_n131_));
  OR3x1_ASAP7_75t_R    g113(.A(new_n130_), .B(new_n62_), .C(new_n131_), .Y(new_n132_));
  OA211x2_ASAP7_75t_R  g114(.A1(p9), .A2(new_n127_), .B(new_n129_), .C(new_n132_), .Y(new_n133_));
  OAI21x1_ASAP7_75t_R  g115(.A1(new_n41_), .A2(new_n125_), .B(new_n133_), .Y(o2));
  OR5x1_ASAP7_75t_R    g116(.A(p6), .B(p5), .C(p7), .D(p4), .E(p3), .Y(new_n135_));
  OR3x1_ASAP7_75t_R    g117(.A(new_n82_), .B(new_n22_), .C(new_n29_), .Y(new_n136_));
  OR3x1_ASAP7_75t_R    g118(.A(new_n136_), .B(p1), .C(new_n26_), .Y(new_n137_));
  OR3x1_ASAP7_75t_R    g119(.A(p9), .B(p8), .C(p2), .Y(new_n138_));
  AO21x1_ASAP7_75t_R   g120(.A1(new_n135_), .A2(new_n137_), .B(new_n138_), .Y(o3));
  OR3x1_ASAP7_75t_R    g121(.A(new_n26_), .B(p6), .C(p4), .Y(new_n140_));
  AND3x1_ASAP7_75t_R   g122(.A(new_n140_), .B(new_n29_), .C(new_n52_), .Y(new_n141_));
  OR3x1_ASAP7_75t_R    g123(.A(new_n32_), .B(new_n90_), .C(p6), .Y(new_n142_));
  AO21x1_ASAP7_75t_R   g124(.A1(new_n82_), .A2(new_n142_), .B(new_n120_), .Y(new_n143_));
  NAND2x1_ASAP7_75t_R  g125(.A(new_n141_), .B(new_n143_), .Y(new_n144_));
  NOR2x1_ASAP7_75t_R   g126(.A(p1), .B(p2), .Y(new_n145_));
  NOR2x1_ASAP7_75t_R   g127(.A(p7), .B(new_n35_), .Y(new_n146_));
  OR5x1_ASAP7_75t_R    g128(.A(p8), .B(new_n98_), .C(new_n145_), .D(new_n116_), .E(new_n146_), .Y(new_n147_));
  NAND2x1_ASAP7_75t_R  g129(.A(p8), .B(new_n136_), .Y(new_n148_));
  AND3x1_ASAP7_75t_R   g130(.A(new_n76_), .B(p0), .C(p10), .Y(new_n149_));
  AND3x1_ASAP7_75t_R   g131(.A(new_n29_), .B(p1), .C(p2), .Y(new_n150_));
  OAI21x1_ASAP7_75t_R  g132(.A1(new_n149_), .A2(new_n126_), .B(new_n150_), .Y(new_n151_));
  AND3x1_ASAP7_75t_R   g133(.A(new_n147_), .B(new_n148_), .C(new_n151_), .Y(new_n152_));
  AO21x1_ASAP7_75t_R   g134(.A1(new_n144_), .A2(new_n152_), .B(p9), .Y(o4));
  OR5x1_ASAP7_75t_R    g135(.A(p6), .B(new_n72_), .C(p7), .D(p4), .E(new_n35_), .Y(new_n154_));
  OAI22x1_ASAP7_75t_R  g136(.A1(new_n154_), .A2(new_n90_), .B1(new_n145_), .B2(new_n136_), .Y(new_n155_));
  AND3x1_ASAP7_75t_R   g137(.A(new_n104_), .B(new_n122_), .C(p1), .Y(new_n156_));
  INVx1_ASAP7_75t_R    g138(.A(new_n47_), .Y(new_n157_));
  OR3x1_ASAP7_75t_R    g139(.A(new_n156_), .B(new_n157_), .C(new_n76_), .Y(new_n158_));
  NAND2x1_ASAP7_75t_R  g140(.A(new_n40_), .B(new_n158_), .Y(new_n159_));
  AO21x1_ASAP7_75t_R   g141(.A1(p3), .A2(new_n155_), .B(new_n159_), .Y(o5));
  OR3x1_ASAP7_75t_R    g142(.A(new_n156_), .B(new_n41_), .C(new_n157_), .Y(o6));
endmodule


