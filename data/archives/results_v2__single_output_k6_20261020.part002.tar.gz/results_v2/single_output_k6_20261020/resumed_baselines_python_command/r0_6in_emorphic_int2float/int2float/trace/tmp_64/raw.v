// Benchmark "/tmp/" written by ABC on Tue Oct 20 17:46:20 2026

module \/tmp/  ( 
    p1, p3, p6, p10, p7, p5, p8, p0, p9, p4, p2,
    o0, o1, o2, o3, o4, o5, o6  );
  input  p1, p3, p6, p10, p7, p5, p8, p0, p9, p4, p2;
  output o0, o1, o2, o3, o4, o5, o6;
  wire new_n19_, new_n20_, new_n21_, new_n22_, new_n23_, new_n24_, new_n25_,
    new_n26_, new_n27_, new_n28_, new_n29_, new_n30_, new_n31_, new_n32_,
    new_n33_, new_n34_, new_n35_, new_n36_, new_n37_, new_n38_, new_n39_,
    new_n40_, new_n41_, new_n42_, new_n43_, new_n44_, new_n45_, new_n46_,
    new_n47_, new_n48_, new_n49_, new_n50_, new_n51_, new_n52_, new_n53_,
    new_n54_, new_n55_, new_n56_, new_n57_, new_n58_, new_n59_, new_n60_,
    new_n62_, new_n63_, new_n64_, new_n65_, new_n66_, new_n67_, new_n68_,
    new_n69_, new_n70_, new_n71_, new_n72_, new_n73_, new_n74_, new_n75_,
    new_n76_, new_n77_, new_n78_, new_n79_, new_n80_, new_n81_, new_n82_,
    new_n83_, new_n84_, new_n85_, new_n86_, new_n87_, new_n88_, new_n89_,
    new_n90_, new_n91_, new_n92_, new_n93_, new_n94_, new_n95_, new_n96_,
    new_n97_, new_n99_, new_n100_, new_n101_, new_n102_, new_n103_,
    new_n104_, new_n105_, new_n106_, new_n107_, new_n108_, new_n109_,
    new_n110_, new_n111_, new_n112_, new_n113_, new_n114_, new_n115_,
    new_n116_, new_n117_, new_n118_, new_n119_, new_n120_, new_n121_,
    new_n122_, new_n123_, new_n124_, new_n125_, new_n126_, new_n127_,
    new_n128_, new_n130_, new_n131_, new_n132_, new_n133_, new_n135_,
    new_n136_, new_n137_, new_n138_, new_n139_, new_n140_, new_n141_,
    new_n142_, new_n143_, new_n144_, new_n145_, new_n146_, new_n148_,
    new_n149_, new_n150_, new_n151_, new_n152_, new_n153_, new_n154_;
  INVx1_ASAP7_75t_R    g000(.A(p4), .Y(new_n19_));
  NAND2x1_ASAP7_75t_R  g001(.A(p3), .B(p0), .Y(new_n20_));
  INVx1_ASAP7_75t_R    g002(.A(p3), .Y(new_n21_));
  NAND2x1_ASAP7_75t_R  g003(.A(p7), .B(new_n21_), .Y(new_n22_));
  INVx1_ASAP7_75t_R    g004(.A(p10), .Y(new_n23_));
  AOI21x1_ASAP7_75t_R  g005(.A1(new_n20_), .A2(new_n22_), .B(new_n23_), .Y(new_n24_));
  AO211x2_ASAP7_75t_R  g006(.A1(new_n20_), .A2(new_n23_), .B(p6), .C(p5), .Y(new_n25_));
  INVx1_ASAP7_75t_R    g007(.A(p7), .Y(new_n26_));
  OAI22x1_ASAP7_75t_R  g008(.A1(new_n24_), .A2(new_n25_), .B1(new_n21_), .B2(new_n26_), .Y(new_n27_));
  INVx1_ASAP7_75t_R    g009(.A(p0), .Y(new_n28_));
  INVx1_ASAP7_75t_R    g010(.A(p2), .Y(new_n29_));
  OR5x1_ASAP7_75t_R    g011(.A(p1), .B(new_n28_), .C(new_n19_), .D(new_n29_), .E(p6), .Y(new_n30_));
  NAND2x1_ASAP7_75t_R  g012(.A(p3), .B(new_n29_), .Y(new_n31_));
  NAND2x1_ASAP7_75t_R  g013(.A(p2), .B(new_n21_), .Y(new_n32_));
  INVx1_ASAP7_75t_R    g014(.A(p6), .Y(new_n33_));
  AO21x1_ASAP7_75t_R   g015(.A1(new_n31_), .A2(new_n32_), .B(new_n33_), .Y(new_n34_));
  AOI21x1_ASAP7_75t_R  g016(.A1(new_n30_), .A2(new_n34_), .B(p7), .Y(new_n35_));
  AND3x1_ASAP7_75t_R   g017(.A(new_n21_), .B(p7), .C(p4), .Y(new_n36_));
  AOI211x1_ASAP7_75t_R g018(.A1(new_n19_), .A2(new_n27_), .B(new_n35_), .C(new_n36_), .Y(new_n37_));
  NOR2x1_ASAP7_75t_R   g019(.A(p8), .B(p9), .Y(new_n38_));
  INVx1_ASAP7_75t_R    g020(.A(new_n38_), .Y(new_n39_));
  INVx1_ASAP7_75t_R    g021(.A(p9), .Y(new_n40_));
  NAND2x1_ASAP7_75t_R  g022(.A(p5), .B(p4), .Y(new_n41_));
  AND2x2_ASAP7_75t_R   g023(.A(new_n40_), .B(new_n41_), .Y(new_n42_));
  NOR2x1_ASAP7_75t_R   g024(.A(p6), .B(p7), .Y(new_n43_));
  AO31x2_ASAP7_75t_R   g025(.A1(new_n43_), .A2(p1), .A3(new_n28_), .B(p8), .Y(new_n44_));
  AND2x2_ASAP7_75t_R   g026(.A(p3), .B(p7), .Y(new_n45_));
  OAI22x1_ASAP7_75t_R  g027(.A1(new_n31_), .A2(new_n45_), .B1(p3), .B2(p6), .Y(new_n46_));
  INVx1_ASAP7_75t_R    g028(.A(p1), .Y(new_n47_));
  AND3x1_ASAP7_75t_R   g029(.A(new_n47_), .B(p0), .C(p4), .Y(new_n48_));
  AND2x2_ASAP7_75t_R   g030(.A(p5), .B(p8), .Y(new_n49_));
  AO221x2_ASAP7_75t_R  g031(.A1(p4), .A2(new_n44_), .B1(new_n46_), .B2(new_n48_), .C(new_n49_), .Y(new_n50_));
  INVx1_ASAP7_75t_R    g032(.A(p5), .Y(new_n51_));
  NOR2x1_ASAP7_75t_R   g033(.A(p6), .B(new_n51_), .Y(new_n52_));
  NOR2x1_ASAP7_75t_R   g034(.A(p7), .B(p8), .Y(new_n53_));
  XOR2x2_ASAP7_75t_R   g035(.A(p1), .B(p2), .Y(new_n54_));
  AO21x1_ASAP7_75t_R   g036(.A1(new_n53_), .A2(new_n54_), .B(p9), .Y(new_n55_));
  AND3x1_ASAP7_75t_R   g037(.A(p7), .B(p5), .C(p8), .Y(new_n56_));
  NOR2x1_ASAP7_75t_R   g038(.A(p5), .B(new_n33_), .Y(new_n57_));
  OA21x2_ASAP7_75t_R   g039(.A1(new_n56_), .A2(new_n57_), .B(p9), .Y(new_n58_));
  AO21x1_ASAP7_75t_R   g040(.A1(new_n52_), .A2(new_n55_), .B(new_n58_), .Y(new_n59_));
  AOI21x1_ASAP7_75t_R  g041(.A1(new_n42_), .A2(new_n50_), .B(new_n59_), .Y(new_n60_));
  OAI21x1_ASAP7_75t_R  g042(.A1(new_n37_), .A2(new_n39_), .B(new_n60_), .Y(o0));
  INVx1_ASAP7_75t_R    g043(.A(p8), .Y(new_n62_));
  NAND2x1_ASAP7_75t_R  g044(.A(new_n21_), .B(new_n62_), .Y(new_n63_));
  NAND2x1_ASAP7_75t_R  g045(.A(p8), .B(new_n33_), .Y(new_n64_));
  AND3x1_ASAP7_75t_R   g046(.A(new_n63_), .B(new_n64_), .C(new_n41_), .Y(new_n65_));
  AOI21x1_ASAP7_75t_R  g047(.A1(new_n64_), .A2(new_n63_), .B(new_n51_), .Y(new_n66_));
  OR3x1_ASAP7_75t_R    g048(.A(new_n65_), .B(new_n53_), .C(new_n66_), .Y(new_n67_));
  OAI22x1_ASAP7_75t_R  g049(.A1(p1), .A2(p6), .B1(p3), .B2(p8), .Y(new_n68_));
  AO22x1_ASAP7_75t_R   g050(.A1(p7), .A2(new_n62_), .B1(new_n28_), .B2(new_n68_), .Y(new_n69_));
  NAND2x1_ASAP7_75t_R  g051(.A(p1), .B(p0), .Y(new_n70_));
  AO21x1_ASAP7_75t_R   g052(.A1(p1), .A2(new_n23_), .B(p6), .Y(new_n71_));
  AOI211x1_ASAP7_75t_R g053(.A1(p10), .A2(new_n70_), .B(new_n21_), .C(new_n71_), .Y(new_n72_));
  NOR2x1_ASAP7_75t_R   g054(.A(p5), .B(p4), .Y(new_n73_));
  OAI21x1_ASAP7_75t_R  g055(.A1(new_n69_), .A2(new_n72_), .B(new_n73_), .Y(new_n74_));
  NAND2x1_ASAP7_75t_R  g056(.A(p3), .B(p2), .Y(new_n75_));
  INVx1_ASAP7_75t_R    g057(.A(new_n75_), .Y(new_n76_));
  NAND2x1_ASAP7_75t_R  g058(.A(p6), .B(new_n53_), .Y(new_n77_));
  OAI21x1_ASAP7_75t_R  g059(.A1(new_n76_), .A2(new_n77_), .B(new_n64_), .Y(new_n78_));
  NOR2x1_ASAP7_75t_R   g060(.A(p3), .B(p5), .Y(new_n79_));
  AO32x1_ASAP7_75t_R   g061(.A1(p3), .A2(new_n26_), .A3(new_n62_), .B1(new_n79_), .B2(new_n33_), .Y(new_n80_));
  AOI211x1_ASAP7_75t_R g062(.A1(new_n33_), .A2(new_n70_), .B(new_n19_), .C(new_n29_), .Y(new_n81_));
  AOI22x1_ASAP7_75t_R  g063(.A1(new_n78_), .A2(new_n19_), .B1(new_n80_), .B2(new_n81_), .Y(new_n82_));
  NAND3x1_ASAP7_75t_R  g064(.A(new_n67_), .B(new_n74_), .C(new_n82_), .Y(new_n83_));
  AO21x1_ASAP7_75t_R   g065(.A1(p6), .A2(p5), .B(p7), .Y(new_n84_));
  AO21x1_ASAP7_75t_R   g066(.A1(p6), .A2(new_n40_), .B(new_n84_), .Y(new_n85_));
  NOR2x1_ASAP7_75t_R   g067(.A(p5), .B(p0), .Y(new_n86_));
  AO32x1_ASAP7_75t_R   g068(.A1(new_n21_), .A2(p5), .A3(new_n62_), .B1(new_n86_), .B2(p4), .Y(new_n87_));
  NOR2x1_ASAP7_75t_R   g069(.A(p5), .B(p2), .Y(new_n88_));
  AO32x1_ASAP7_75t_R   g070(.A1(new_n21_), .A2(p5), .A3(new_n62_), .B1(new_n88_), .B2(p4), .Y(new_n89_));
  AND3x1_ASAP7_75t_R   g071(.A(p1), .B(p3), .C(p2), .Y(new_n90_));
  NOR2x1_ASAP7_75t_R   g072(.A(p8), .B(new_n51_), .Y(new_n91_));
  AO21x1_ASAP7_75t_R   g073(.A1(new_n90_), .A2(new_n91_), .B(p9), .Y(new_n92_));
  AOI221x1_ASAP7_75t_R g074(.A1(new_n87_), .A2(new_n29_), .B1(new_n47_), .B2(new_n89_), .C(new_n92_), .Y(new_n93_));
  NAND2x1_ASAP7_75t_R  g075(.A(p7), .B(p9), .Y(new_n94_));
  NAND2x1_ASAP7_75t_R  g076(.A(p6), .B(p5), .Y(new_n95_));
  OR3x1_ASAP7_75t_R    g077(.A(new_n94_), .B(new_n95_), .C(p8), .Y(new_n96_));
  OAI21x1_ASAP7_75t_R  g078(.A1(new_n85_), .A2(new_n93_), .B(new_n96_), .Y(new_n97_));
  AOI21x1_ASAP7_75t_R  g079(.A1(new_n40_), .A2(new_n83_), .B(new_n97_), .Y(o1));
  NOR2x1_ASAP7_75t_R   g080(.A(p2), .B(new_n19_), .Y(new_n99_));
  AND3x1_ASAP7_75t_R   g081(.A(new_n47_), .B(new_n51_), .C(p2), .Y(new_n100_));
  OAI21x1_ASAP7_75t_R  g082(.A1(new_n99_), .A2(new_n100_), .B(p3), .Y(new_n101_));
  INVx1_ASAP7_75t_R    g083(.A(new_n43_), .Y(new_n102_));
  AOI21x1_ASAP7_75t_R  g084(.A1(new_n47_), .A2(new_n101_), .B(new_n102_), .Y(new_n103_));
  AND3x1_ASAP7_75t_R   g085(.A(new_n21_), .B(p4), .C(p2), .Y(new_n104_));
  AND4x2_ASAP7_75t_R   g086(.A(new_n51_), .B(new_n29_), .C(p3), .D(p10), .Y(new_n105_));
  OAI21x1_ASAP7_75t_R  g087(.A1(new_n104_), .A2(new_n105_), .B(p0), .Y(new_n106_));
  AOI21x1_ASAP7_75t_R  g088(.A1(p10), .A2(p0), .B(new_n75_), .Y(new_n107_));
  OAI21x1_ASAP7_75t_R  g089(.A1(new_n79_), .A2(new_n107_), .B(new_n19_), .Y(new_n108_));
  NAND3x1_ASAP7_75t_R  g090(.A(new_n106_), .B(new_n101_), .C(new_n108_), .Y(new_n109_));
  AO21x1_ASAP7_75t_R   g091(.A1(new_n75_), .A2(new_n41_), .B(p7), .Y(new_n110_));
  AND3x1_ASAP7_75t_R   g092(.A(new_n19_), .B(p1), .C(p5), .Y(new_n111_));
  AOI211x1_ASAP7_75t_R g093(.A1(p4), .A2(new_n86_), .B(new_n75_), .C(new_n111_), .Y(new_n112_));
  AND3x1_ASAP7_75t_R   g094(.A(p3), .B(p4), .C(p2), .Y(new_n113_));
  NAND2x1_ASAP7_75t_R  g095(.A(p3), .B(p4), .Y(new_n114_));
  AND3x1_ASAP7_75t_R   g096(.A(new_n114_), .B(p6), .C(p5), .Y(new_n115_));
  AND5x1_ASAP7_75t_R   g097(.A(new_n47_), .B(new_n33_), .C(p3), .D(p5), .E(p4), .Y(new_n116_));
  AOI211x1_ASAP7_75t_R g098(.A1(new_n57_), .A2(new_n113_), .B(new_n115_), .C(new_n116_), .Y(new_n117_));
  OAI21x1_ASAP7_75t_R  g099(.A1(new_n110_), .A2(new_n112_), .B(new_n117_), .Y(new_n118_));
  AOI21x1_ASAP7_75t_R  g100(.A1(new_n103_), .A2(new_n109_), .B(new_n118_), .Y(new_n119_));
  AND2x2_ASAP7_75t_R   g101(.A(p5), .B(p4), .Y(new_n120_));
  AND3x1_ASAP7_75t_R   g102(.A(new_n120_), .B(p3), .C(new_n33_), .Y(new_n121_));
  OAI21x1_ASAP7_75t_R  g103(.A1(new_n57_), .A2(new_n121_), .B(p7), .Y(new_n122_));
  OR3x1_ASAP7_75t_R    g104(.A(new_n62_), .B(new_n19_), .C(p7), .Y(new_n123_));
  AO21x1_ASAP7_75t_R   g105(.A1(new_n94_), .A2(new_n123_), .B(new_n95_), .Y(new_n124_));
  AND3x1_ASAP7_75t_R   g106(.A(new_n40_), .B(p6), .C(p4), .Y(new_n125_));
  NOR2x1_ASAP7_75t_R   g107(.A(p7), .B(p9), .Y(new_n126_));
  OR3x1_ASAP7_75t_R    g108(.A(new_n125_), .B(new_n62_), .C(new_n126_), .Y(new_n127_));
  OA211x2_ASAP7_75t_R  g109(.A1(p9), .A2(new_n122_), .B(new_n124_), .C(new_n127_), .Y(new_n128_));
  OAI21x1_ASAP7_75t_R  g110(.A1(new_n39_), .A2(new_n119_), .B(new_n128_), .Y(o2));
  OR5x1_ASAP7_75t_R    g111(.A(p3), .B(p6), .C(p7), .D(p5), .E(p4), .Y(new_n130_));
  OR3x1_ASAP7_75t_R    g112(.A(new_n41_), .B(new_n33_), .C(new_n26_), .Y(new_n131_));
  OR3x1_ASAP7_75t_R    g113(.A(new_n131_), .B(p1), .C(new_n21_), .Y(new_n132_));
  OR3x1_ASAP7_75t_R    g114(.A(p8), .B(p9), .C(p2), .Y(new_n133_));
  AO21x1_ASAP7_75t_R   g115(.A1(new_n130_), .A2(new_n132_), .B(new_n133_), .Y(o3));
  NOR2x1_ASAP7_75t_R   g116(.A(p6), .B(new_n70_), .Y(new_n135_));
  OA21x2_ASAP7_75t_R   g117(.A1(new_n120_), .A2(new_n135_), .B(new_n76_), .Y(new_n136_));
  AND3x1_ASAP7_75t_R   g118(.A(new_n33_), .B(new_n19_), .C(p3), .Y(new_n137_));
  OR4x2_ASAP7_75t_R    g119(.A(new_n136_), .B(p7), .C(new_n52_), .D(new_n137_), .Y(new_n138_));
  NAND2x1_ASAP7_75t_R  g120(.A(p7), .B(p2), .Y(new_n139_));
  OA21x2_ASAP7_75t_R   g121(.A1(new_n47_), .A2(p2), .B(new_n139_), .Y(new_n140_));
  OR5x1_ASAP7_75t_R    g122(.A(new_n33_), .B(new_n140_), .C(new_n51_), .D(p8), .E(new_n114_), .Y(new_n141_));
  NAND2x1_ASAP7_75t_R  g123(.A(p8), .B(new_n131_), .Y(new_n142_));
  AND3x1_ASAP7_75t_R   g124(.A(new_n73_), .B(p10), .C(p0), .Y(new_n143_));
  AND3x1_ASAP7_75t_R   g125(.A(new_n26_), .B(p1), .C(p2), .Y(new_n144_));
  OAI21x1_ASAP7_75t_R  g126(.A1(new_n143_), .A2(new_n121_), .B(new_n144_), .Y(new_n145_));
  AND3x1_ASAP7_75t_R   g127(.A(new_n141_), .B(new_n142_), .C(new_n145_), .Y(new_n146_));
  AO21x1_ASAP7_75t_R   g128(.A1(new_n138_), .A2(new_n146_), .B(p9), .Y(o4));
  NAND2x1_ASAP7_75t_R  g129(.A(p10), .B(p0), .Y(new_n148_));
  OR5x1_ASAP7_75t_R    g130(.A(p6), .B(new_n148_), .C(p7), .D(p4), .E(new_n29_), .Y(new_n149_));
  AO21x1_ASAP7_75t_R   g131(.A1(new_n47_), .A2(new_n29_), .B(new_n131_), .Y(new_n150_));
  OAI21x1_ASAP7_75t_R  g132(.A1(new_n47_), .A2(new_n149_), .B(new_n150_), .Y(new_n151_));
  AND2x2_ASAP7_75t_R   g133(.A(new_n120_), .B(new_n90_), .Y(new_n152_));
  OR3x1_ASAP7_75t_R    g134(.A(new_n152_), .B(new_n102_), .C(new_n73_), .Y(new_n153_));
  NAND2x1_ASAP7_75t_R  g135(.A(new_n38_), .B(new_n153_), .Y(new_n154_));
  AO21x1_ASAP7_75t_R   g136(.A1(p3), .A2(new_n151_), .B(new_n154_), .Y(o5));
  OR3x1_ASAP7_75t_R    g137(.A(new_n152_), .B(new_n39_), .C(new_n102_), .Y(o6));
endmodule


