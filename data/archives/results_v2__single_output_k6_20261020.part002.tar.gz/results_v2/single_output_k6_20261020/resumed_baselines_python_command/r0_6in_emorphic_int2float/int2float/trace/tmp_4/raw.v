// Benchmark "/tmp/" written by ABC on Tue Oct 20 17:46:14 2026

module \/tmp/  ( 
    p0, p4, p2, p1, p8, p7, p10, p9, p6, p3, p5,
    o0, o1, o2, o3, o4, o5, o6  );
  input  p0, p4, p2, p1, p8, p7, p10, p9, p6, p3, p5;
  output o0, o1, o2, o3, o4, o5, o6;
  wire new_n19_, new_n20_, new_n21_, new_n22_, new_n23_, new_n24_, new_n25_,
    new_n26_, new_n27_, new_n28_, new_n29_, new_n30_, new_n31_, new_n32_,
    new_n33_, new_n34_, new_n35_, new_n36_, new_n37_, new_n38_, new_n39_,
    new_n40_, new_n41_, new_n42_, new_n43_, new_n44_, new_n45_, new_n46_,
    new_n47_, new_n48_, new_n49_, new_n50_, new_n51_, new_n52_, new_n53_,
    new_n54_, new_n55_, new_n56_, new_n57_, new_n58_, new_n59_, new_n60_,
    new_n61_, new_n62_, new_n63_, new_n65_, new_n66_, new_n67_, new_n68_,
    new_n69_, new_n70_, new_n71_, new_n72_, new_n73_, new_n74_, new_n75_,
    new_n76_, new_n77_, new_n78_, new_n79_, new_n80_, new_n81_, new_n82_,
    new_n83_, new_n84_, new_n85_, new_n86_, new_n87_, new_n88_, new_n89_,
    new_n90_, new_n91_, new_n92_, new_n93_, new_n94_, new_n95_, new_n96_,
    new_n97_, new_n98_, new_n99_, new_n101_, new_n102_, new_n103_,
    new_n104_, new_n105_, new_n106_, new_n107_, new_n108_, new_n109_,
    new_n110_, new_n111_, new_n112_, new_n113_, new_n114_, new_n115_,
    new_n116_, new_n117_, new_n118_, new_n119_, new_n120_, new_n121_,
    new_n122_, new_n123_, new_n124_, new_n125_, new_n126_, new_n127_,
    new_n128_, new_n129_, new_n130_, new_n132_, new_n133_, new_n134_,
    new_n135_, new_n137_, new_n138_, new_n139_, new_n140_, new_n141_,
    new_n142_, new_n143_, new_n144_, new_n145_, new_n146_, new_n147_,
    new_n148_, new_n149_, new_n151_, new_n152_, new_n153_, new_n154_,
    new_n155_;
  INVx1_ASAP7_75t_R    g000(.A(p10), .Y(new_n19_));
  NAND2x1_ASAP7_75t_R  g001(.A(p0), .B(p3), .Y(new_n20_));
  INVx1_ASAP7_75t_R    g002(.A(p6), .Y(new_n21_));
  INVx1_ASAP7_75t_R    g003(.A(p5), .Y(new_n22_));
  NAND2x1_ASAP7_75t_R  g004(.A(new_n21_), .B(new_n22_), .Y(new_n23_));
  AO21x1_ASAP7_75t_R   g005(.A1(new_n19_), .A2(new_n20_), .B(new_n23_), .Y(new_n24_));
  INVx1_ASAP7_75t_R    g006(.A(p3), .Y(new_n25_));
  NAND2x1_ASAP7_75t_R  g007(.A(p7), .B(new_n25_), .Y(new_n26_));
  AOI21x1_ASAP7_75t_R  g008(.A1(new_n20_), .A2(new_n26_), .B(new_n19_), .Y(new_n27_));
  INVx1_ASAP7_75t_R    g009(.A(p7), .Y(new_n28_));
  OAI22x1_ASAP7_75t_R  g010(.A1(new_n24_), .A2(new_n27_), .B1(new_n28_), .B2(new_n25_), .Y(new_n29_));
  NOR2x1_ASAP7_75t_R   g011(.A(p4), .B(p8), .Y(new_n30_));
  AOI21x1_ASAP7_75t_R  g012(.A1(p2), .A2(p3), .B(new_n21_), .Y(new_n31_));
  INVx1_ASAP7_75t_R    g013(.A(p2), .Y(new_n32_));
  NAND2x1_ASAP7_75t_R  g014(.A(new_n32_), .B(new_n25_), .Y(new_n33_));
  NOR2x1_ASAP7_75t_R   g015(.A(p1), .B(p6), .Y(new_n34_));
  AND3x1_ASAP7_75t_R   g016(.A(p0), .B(p4), .C(p2), .Y(new_n35_));
  AOI22x1_ASAP7_75t_R  g017(.A1(new_n31_), .A2(new_n33_), .B1(new_n34_), .B2(new_n35_), .Y(new_n36_));
  INVx1_ASAP7_75t_R    g018(.A(p4), .Y(new_n37_));
  OR3x1_ASAP7_75t_R    g019(.A(new_n37_), .B(new_n28_), .C(p3), .Y(new_n38_));
  OAI21x1_ASAP7_75t_R  g020(.A1(p7), .A2(new_n36_), .B(new_n38_), .Y(new_n39_));
  INVx1_ASAP7_75t_R    g021(.A(p8), .Y(new_n40_));
  AOI22x1_ASAP7_75t_R  g022(.A1(new_n29_), .A2(new_n30_), .B1(new_n39_), .B2(new_n40_), .Y(new_n41_));
  INVx1_ASAP7_75t_R    g023(.A(p0), .Y(new_n42_));
  AOI211x1_ASAP7_75t_R g024(.A1(p6), .A2(new_n25_), .B(new_n42_), .C(p1), .Y(new_n43_));
  AO21x1_ASAP7_75t_R   g025(.A1(new_n32_), .A2(new_n28_), .B(new_n25_), .Y(new_n44_));
  NOR2x1_ASAP7_75t_R   g026(.A(p5), .B(new_n37_), .Y(new_n45_));
  NAND3x1_ASAP7_75t_R  g027(.A(new_n43_), .B(new_n44_), .C(new_n45_), .Y(new_n46_));
  NOR2x1_ASAP7_75t_R   g028(.A(p7), .B(p6), .Y(new_n47_));
  AO31x2_ASAP7_75t_R   g029(.A1(new_n47_), .A2(new_n42_), .A3(p1), .B(p8), .Y(new_n48_));
  AND3x1_ASAP7_75t_R   g030(.A(new_n37_), .B(p8), .C(p5), .Y(new_n49_));
  AOI21x1_ASAP7_75t_R  g031(.A1(new_n45_), .A2(new_n48_), .B(new_n49_), .Y(new_n50_));
  NAND2x1_ASAP7_75t_R  g032(.A(new_n46_), .B(new_n50_), .Y(new_n51_));
  INVx1_ASAP7_75t_R    g033(.A(p9), .Y(new_n52_));
  INVx1_ASAP7_75t_R    g034(.A(p1), .Y(new_n53_));
  NAND2x1_ASAP7_75t_R  g035(.A(new_n32_), .B(new_n53_), .Y(new_n54_));
  NAND2x1_ASAP7_75t_R  g036(.A(p2), .B(p1), .Y(new_n55_));
  AND3x1_ASAP7_75t_R   g037(.A(new_n55_), .B(new_n40_), .C(new_n28_), .Y(new_n56_));
  AO21x1_ASAP7_75t_R   g038(.A1(new_n54_), .A2(new_n56_), .B(p9), .Y(new_n57_));
  NAND2x1_ASAP7_75t_R  g039(.A(p5), .B(new_n21_), .Y(new_n58_));
  AND3x1_ASAP7_75t_R   g040(.A(p8), .B(p7), .C(p5), .Y(new_n59_));
  NOR2x1_ASAP7_75t_R   g041(.A(p5), .B(new_n21_), .Y(new_n60_));
  OAI21x1_ASAP7_75t_R  g042(.A1(new_n59_), .A2(new_n60_), .B(p9), .Y(new_n61_));
  NAND2x1_ASAP7_75t_R  g043(.A(new_n58_), .B(new_n61_), .Y(new_n62_));
  AOI22x1_ASAP7_75t_R  g044(.A1(new_n51_), .A2(new_n52_), .B1(new_n57_), .B2(new_n62_), .Y(new_n63_));
  OAI21x1_ASAP7_75t_R  g045(.A1(p9), .A2(new_n41_), .B(new_n63_), .Y(o0));
  NAND2x1_ASAP7_75t_R  g046(.A(p0), .B(p1), .Y(new_n65_));
  NAND2x1_ASAP7_75t_R  g047(.A(p10), .B(new_n65_), .Y(new_n66_));
  OA211x2_ASAP7_75t_R  g048(.A1(new_n53_), .A2(p10), .B(new_n21_), .C(p3), .Y(new_n67_));
  OAI22x1_ASAP7_75t_R  g049(.A1(p1), .A2(p6), .B1(p8), .B2(p3), .Y(new_n68_));
  AO22x1_ASAP7_75t_R   g050(.A1(new_n40_), .A2(p7), .B1(new_n42_), .B2(new_n68_), .Y(new_n69_));
  NOR2x1_ASAP7_75t_R   g051(.A(p8), .B(p7), .Y(new_n70_));
  NOR2x1_ASAP7_75t_R   g052(.A(p6), .B(new_n40_), .Y(new_n71_));
  AO21x1_ASAP7_75t_R   g053(.A1(new_n70_), .A2(new_n31_), .B(new_n71_), .Y(new_n72_));
  AOI211x1_ASAP7_75t_R g054(.A1(new_n66_), .A2(new_n67_), .B(new_n69_), .C(new_n72_), .Y(new_n73_));
  OAI21x1_ASAP7_75t_R  g055(.A1(new_n22_), .A2(new_n72_), .B(new_n37_), .Y(new_n74_));
  NAND2x1_ASAP7_75t_R  g056(.A(p4), .B(p5), .Y(new_n75_));
  NOR2x1_ASAP7_75t_R   g057(.A(p8), .B(p3), .Y(new_n76_));
  AOI21x1_ASAP7_75t_R  g058(.A1(p8), .A2(new_n21_), .B(new_n76_), .Y(new_n77_));
  NAND2x1_ASAP7_75t_R  g059(.A(new_n75_), .B(new_n77_), .Y(new_n78_));
  INVx1_ASAP7_75t_R    g060(.A(new_n70_), .Y(new_n79_));
  OA21x2_ASAP7_75t_R   g061(.A1(new_n22_), .A2(new_n77_), .B(new_n79_), .Y(new_n80_));
  NAND2x1_ASAP7_75t_R  g062(.A(p3), .B(new_n70_), .Y(new_n81_));
  AND2x2_ASAP7_75t_R   g063(.A(p0), .B(p1), .Y(new_n82_));
  NOR2x1_ASAP7_75t_R   g064(.A(p3), .B(p5), .Y(new_n83_));
  NAND3x1_ASAP7_75t_R  g065(.A(new_n82_), .B(new_n21_), .C(new_n83_), .Y(new_n84_));
  NAND2x1_ASAP7_75t_R  g066(.A(p4), .B(p2), .Y(new_n85_));
  AO21x1_ASAP7_75t_R   g067(.A1(new_n21_), .A2(new_n65_), .B(new_n85_), .Y(new_n86_));
  AOI21x1_ASAP7_75t_R  g068(.A1(new_n81_), .A2(new_n84_), .B(new_n86_), .Y(new_n87_));
  AOI21x1_ASAP7_75t_R  g069(.A1(new_n78_), .A2(new_n80_), .B(new_n87_), .Y(new_n88_));
  OAI21x1_ASAP7_75t_R  g070(.A1(new_n73_), .A2(new_n74_), .B(new_n88_), .Y(new_n89_));
  OR4x2_ASAP7_75t_R    g071(.A(new_n82_), .B(new_n37_), .C(p2), .D(p5), .Y(new_n90_));
  OR4x2_ASAP7_75t_R    g072(.A(new_n55_), .B(p8), .C(new_n25_), .D(new_n22_), .Y(new_n91_));
  NAND3x1_ASAP7_75t_R  g073(.A(new_n76_), .B(new_n55_), .C(p5), .Y(new_n92_));
  AND4x2_ASAP7_75t_R   g074(.A(new_n90_), .B(new_n91_), .C(new_n52_), .D(new_n92_), .Y(new_n93_));
  AO21x1_ASAP7_75t_R   g075(.A1(p6), .A2(p5), .B(p7), .Y(new_n94_));
  AO21x1_ASAP7_75t_R   g076(.A1(new_n52_), .A2(p6), .B(new_n94_), .Y(new_n95_));
  AND2x2_ASAP7_75t_R   g077(.A(p6), .B(p5), .Y(new_n96_));
  AND3x1_ASAP7_75t_R   g078(.A(new_n96_), .B(p7), .C(p9), .Y(new_n97_));
  INVx1_ASAP7_75t_R    g079(.A(new_n97_), .Y(new_n98_));
  OAI22x1_ASAP7_75t_R  g080(.A1(new_n93_), .A2(new_n95_), .B1(p8), .B2(new_n98_), .Y(new_n99_));
  AOI21x1_ASAP7_75t_R  g081(.A1(new_n52_), .A2(new_n89_), .B(new_n99_), .Y(o1));
  NAND2x1_ASAP7_75t_R  g082(.A(new_n40_), .B(new_n52_), .Y(new_n101_));
  NAND2x1_ASAP7_75t_R  g083(.A(p4), .B(p3), .Y(new_n102_));
  INVx1_ASAP7_75t_R    g084(.A(new_n102_), .Y(new_n103_));
  AND2x2_ASAP7_75t_R   g085(.A(p2), .B(p3), .Y(new_n104_));
  NOR2x1_ASAP7_75t_R   g086(.A(p1), .B(p5), .Y(new_n105_));
  AOI22x1_ASAP7_75t_R  g087(.A1(new_n103_), .A2(new_n32_), .B1(new_n104_), .B2(new_n105_), .Y(new_n106_));
  INVx1_ASAP7_75t_R    g088(.A(new_n47_), .Y(new_n107_));
  AOI21x1_ASAP7_75t_R  g089(.A1(new_n53_), .A2(new_n106_), .B(new_n107_), .Y(new_n108_));
  NOR2x1_ASAP7_75t_R   g090(.A(p3), .B(new_n85_), .Y(new_n109_));
  NAND2x1_ASAP7_75t_R  g091(.A(p10), .B(p3), .Y(new_n110_));
  NOR3x1_ASAP7_75t_R   g092(.A(new_n110_), .B(p2), .C(p5), .Y(new_n111_));
  OAI21x1_ASAP7_75t_R  g093(.A1(new_n109_), .A2(new_n111_), .B(p0), .Y(new_n112_));
  NAND2x1_ASAP7_75t_R  g094(.A(p2), .B(p3), .Y(new_n113_));
  AOI21x1_ASAP7_75t_R  g095(.A1(p0), .A2(p10), .B(new_n113_), .Y(new_n114_));
  OAI21x1_ASAP7_75t_R  g096(.A1(new_n83_), .A2(new_n114_), .B(new_n37_), .Y(new_n115_));
  NAND3x1_ASAP7_75t_R  g097(.A(new_n112_), .B(new_n115_), .C(new_n106_), .Y(new_n116_));
  AND2x2_ASAP7_75t_R   g098(.A(p1), .B(p5), .Y(new_n117_));
  AOI221x1_ASAP7_75t_R g099(.A1(new_n37_), .A2(new_n117_), .B1(new_n45_), .B2(new_n42_), .C(new_n113_), .Y(new_n118_));
  AO21x1_ASAP7_75t_R   g100(.A1(new_n113_), .A2(new_n75_), .B(p7), .Y(new_n119_));
  AOI221x1_ASAP7_75t_R g101(.A1(p5), .A2(new_n34_), .B1(new_n60_), .B2(p2), .C(new_n102_), .Y(new_n120_));
  NAND2x1_ASAP7_75t_R  g102(.A(p6), .B(p5), .Y(new_n121_));
  AND2x2_ASAP7_75t_R   g103(.A(new_n121_), .B(new_n102_), .Y(new_n122_));
  OAI22x1_ASAP7_75t_R  g104(.A1(new_n118_), .A2(new_n119_), .B1(new_n120_), .B2(new_n122_), .Y(new_n123_));
  AOI21x1_ASAP7_75t_R  g105(.A1(new_n108_), .A2(new_n116_), .B(new_n123_), .Y(new_n124_));
  OR3x1_ASAP7_75t_R    g106(.A(new_n37_), .B(new_n28_), .C(new_n21_), .Y(new_n125_));
  AO21x1_ASAP7_75t_R   g107(.A1(p4), .A2(new_n96_), .B(p7), .Y(new_n126_));
  AO21x1_ASAP7_75t_R   g108(.A1(new_n125_), .A2(new_n126_), .B(p9), .Y(new_n127_));
  NOR2x1_ASAP7_75t_R   g109(.A(new_n102_), .B(new_n58_), .Y(new_n128_));
  OA211x2_ASAP7_75t_R  g110(.A1(new_n60_), .A2(new_n128_), .B(p7), .C(new_n52_), .Y(new_n129_));
  AOI211x1_ASAP7_75t_R g111(.A1(p8), .A2(new_n127_), .B(new_n97_), .C(new_n129_), .Y(new_n130_));
  OAI21x1_ASAP7_75t_R  g112(.A1(new_n101_), .A2(new_n124_), .B(new_n130_), .Y(o2));
  NAND2x1_ASAP7_75t_R  g113(.A(new_n37_), .B(new_n21_), .Y(new_n132_));
  OR3x1_ASAP7_75t_R    g114(.A(p7), .B(p3), .C(p5), .Y(new_n133_));
  OR5x1_ASAP7_75t_R    g115(.A(new_n37_), .B(new_n121_), .C(p1), .D(new_n28_), .E(new_n25_), .Y(new_n134_));
  OA21x2_ASAP7_75t_R   g116(.A1(new_n132_), .A2(new_n133_), .B(new_n134_), .Y(new_n135_));
  OR3x1_ASAP7_75t_R    g117(.A(new_n135_), .B(p2), .C(new_n101_), .Y(o3));
  AND3x1_ASAP7_75t_R   g118(.A(new_n103_), .B(new_n40_), .C(new_n96_), .Y(new_n137_));
  NAND2x1_ASAP7_75t_R  g119(.A(p2), .B(new_n28_), .Y(new_n138_));
  OR3x1_ASAP7_75t_R    g120(.A(new_n121_), .B(new_n37_), .C(new_n28_), .Y(new_n139_));
  AO32x1_ASAP7_75t_R   g121(.A1(new_n137_), .A2(new_n54_), .A3(new_n138_), .B1(p8), .B2(new_n139_), .Y(new_n140_));
  NAND2x1_ASAP7_75t_R  g122(.A(new_n37_), .B(new_n22_), .Y(new_n141_));
  NOR3x1_ASAP7_75t_R   g123(.A(new_n141_), .B(new_n42_), .C(new_n19_), .Y(new_n142_));
  INVx1_ASAP7_75t_R    g124(.A(new_n55_), .Y(new_n143_));
  OAI21x1_ASAP7_75t_R  g125(.A1(new_n128_), .A2(new_n142_), .B(new_n143_), .Y(new_n144_));
  AND2x2_ASAP7_75t_R   g126(.A(p4), .B(p5), .Y(new_n145_));
  AO21x1_ASAP7_75t_R   g127(.A1(new_n21_), .A2(new_n82_), .B(new_n145_), .Y(new_n146_));
  OAI21x1_ASAP7_75t_R  g128(.A1(new_n25_), .A2(new_n132_), .B(new_n58_), .Y(new_n147_));
  AO21x1_ASAP7_75t_R   g129(.A1(new_n104_), .A2(new_n146_), .B(new_n147_), .Y(new_n148_));
  AOI21x1_ASAP7_75t_R  g130(.A1(new_n144_), .A2(new_n148_), .B(p7), .Y(new_n149_));
  OAI21x1_ASAP7_75t_R  g131(.A1(new_n140_), .A2(new_n149_), .B(new_n52_), .Y(o4));
  AND3x1_ASAP7_75t_R   g132(.A(new_n104_), .B(new_n145_), .C(p1), .Y(new_n151_));
  NOR2x1_ASAP7_75t_R   g133(.A(new_n107_), .B(new_n151_), .Y(new_n152_));
  AND5x1_ASAP7_75t_R   g134(.A(p0), .B(new_n28_), .C(p2), .D(p1), .E(p10), .Y(new_n153_));
  AND3x1_ASAP7_75t_R   g135(.A(new_n96_), .B(p4), .C(p7), .Y(new_n154_));
  AO32x1_ASAP7_75t_R   g136(.A1(new_n37_), .A2(new_n21_), .A3(new_n153_), .B1(new_n154_), .B2(new_n54_), .Y(new_n155_));
  AO221x2_ASAP7_75t_R  g137(.A1(new_n141_), .A2(new_n152_), .B1(new_n155_), .B2(p3), .C(new_n101_), .Y(o5));
  OR3x1_ASAP7_75t_R    g138(.A(new_n151_), .B(new_n107_), .C(new_n101_), .Y(o6));
endmodule


