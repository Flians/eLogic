// Benchmark "/tmp/" written by ABC on Tue Oct 20 17:46:21 2026

module \/tmp/  ( 
    p3, p7, p0, p9, p2, p4, p10, p6, p5, p8, p1,
    o0, o1, o2, o3, o4, o5, o6  );
  input  p3, p7, p0, p9, p2, p4, p10, p6, p5, p8, p1;
  output o0, o1, o2, o3, o4, o5, o6;
  wire new_n19_, new_n20_, new_n21_, new_n22_, new_n23_, new_n24_, new_n25_,
    new_n26_, new_n27_, new_n28_, new_n29_, new_n30_, new_n31_, new_n32_,
    new_n33_, new_n34_, new_n35_, new_n36_, new_n37_, new_n38_, new_n39_,
    new_n40_, new_n41_, new_n42_, new_n43_, new_n44_, new_n45_, new_n46_,
    new_n47_, new_n48_, new_n49_, new_n50_, new_n51_, new_n52_, new_n53_,
    new_n54_, new_n55_, new_n56_, new_n57_, new_n58_, new_n59_, new_n60_,
    new_n62_, new_n63_, new_n64_, new_n65_, new_n66_, new_n67_, new_n68_,
    new_n69_, new_n70_, new_n71_, new_n72_, new_n73_, new_n74_, new_n75_,
    new_n76_, new_n77_, new_n78_, new_n79_, new_n80_, new_n81_, new_n82_,
    new_n83_, new_n84_, new_n85_, new_n86_, new_n87_, new_n88_, new_n89_,
    new_n90_, new_n91_, new_n92_, new_n93_, new_n94_, new_n96_, new_n97_,
    new_n98_, new_n99_, new_n100_, new_n101_, new_n102_, new_n103_,
    new_n104_, new_n105_, new_n106_, new_n107_, new_n108_, new_n109_,
    new_n110_, new_n111_, new_n112_, new_n113_, new_n114_, new_n115_,
    new_n116_, new_n117_, new_n118_, new_n119_, new_n120_, new_n121_,
    new_n122_, new_n123_, new_n124_, new_n126_, new_n127_, new_n128_,
    new_n130_, new_n131_, new_n132_, new_n133_, new_n134_, new_n135_,
    new_n136_, new_n137_, new_n138_, new_n139_, new_n140_, new_n142_,
    new_n143_, new_n144_, new_n145_, new_n146_, new_n147_;
  AND2x2_ASAP7_75t_R   g000(.A(p3), .B(p0), .Y(new_n19_));
  NOR2x1_ASAP7_75t_R   g001(.A(p6), .B(p5), .Y(new_n20_));
  OA21x2_ASAP7_75t_R   g002(.A1(p10), .A2(new_n19_), .B(new_n20_), .Y(new_n21_));
  INVx1_ASAP7_75t_R    g003(.A(p7), .Y(new_n22_));
  NOR2x1_ASAP7_75t_R   g004(.A(p3), .B(new_n22_), .Y(new_n23_));
  OAI21x1_ASAP7_75t_R  g005(.A1(new_n19_), .A2(new_n23_), .B(p10), .Y(new_n24_));
  AO21x1_ASAP7_75t_R   g006(.A1(p3), .A2(p7), .B(p4), .Y(new_n25_));
  AO21x1_ASAP7_75t_R   g007(.A1(new_n21_), .A2(new_n24_), .B(new_n25_), .Y(new_n26_));
  INVx1_ASAP7_75t_R    g008(.A(p3), .Y(new_n27_));
  INVx1_ASAP7_75t_R    g009(.A(p4), .Y(new_n28_));
  AO21x1_ASAP7_75t_R   g010(.A1(p7), .A2(new_n27_), .B(new_n28_), .Y(new_n29_));
  INVx1_ASAP7_75t_R    g011(.A(p0), .Y(new_n30_));
  INVx1_ASAP7_75t_R    g012(.A(p2), .Y(new_n31_));
  OR5x1_ASAP7_75t_R    g013(.A(new_n30_), .B(new_n31_), .C(new_n28_), .D(p6), .E(p1), .Y(new_n32_));
  NAND2x1_ASAP7_75t_R  g014(.A(p3), .B(new_n31_), .Y(new_n33_));
  NAND2x1_ASAP7_75t_R  g015(.A(p2), .B(new_n27_), .Y(new_n34_));
  INVx1_ASAP7_75t_R    g016(.A(p6), .Y(new_n35_));
  AO21x1_ASAP7_75t_R   g017(.A1(new_n33_), .A2(new_n34_), .B(new_n35_), .Y(new_n36_));
  NAND2x1_ASAP7_75t_R  g018(.A(new_n32_), .B(new_n36_), .Y(new_n37_));
  AOI22x1_ASAP7_75t_R  g019(.A1(new_n26_), .A2(new_n29_), .B1(new_n22_), .B2(new_n37_), .Y(new_n38_));
  NOR2x1_ASAP7_75t_R   g020(.A(p9), .B(p8), .Y(new_n39_));
  INVx1_ASAP7_75t_R    g021(.A(new_n39_), .Y(new_n40_));
  NOR2x1_ASAP7_75t_R   g022(.A(p5), .B(new_n28_), .Y(new_n41_));
  INVx1_ASAP7_75t_R    g023(.A(new_n41_), .Y(new_n42_));
  NOR2x1_ASAP7_75t_R   g024(.A(p3), .B(new_n35_), .Y(new_n43_));
  AND2x2_ASAP7_75t_R   g025(.A(p3), .B(p7), .Y(new_n44_));
  AND2x2_ASAP7_75t_R   g026(.A(p3), .B(p2), .Y(new_n45_));
  OR5x1_ASAP7_75t_R    g027(.A(new_n30_), .B(new_n43_), .C(p1), .D(new_n44_), .E(new_n45_), .Y(new_n46_));
  NOR2x1_ASAP7_75t_R   g028(.A(p7), .B(p6), .Y(new_n47_));
  AO31x2_ASAP7_75t_R   g029(.A1(new_n47_), .A2(new_n30_), .A3(p1), .B(p8), .Y(new_n48_));
  AND2x2_ASAP7_75t_R   g030(.A(p5), .B(p8), .Y(new_n49_));
  AOI22x1_ASAP7_75t_R  g031(.A1(new_n48_), .A2(new_n41_), .B1(new_n28_), .B2(new_n49_), .Y(new_n50_));
  OAI21x1_ASAP7_75t_R  g032(.A1(new_n42_), .A2(new_n46_), .B(new_n50_), .Y(new_n51_));
  INVx1_ASAP7_75t_R    g033(.A(p9), .Y(new_n52_));
  NOR2x1_ASAP7_75t_R   g034(.A(p5), .B(new_n35_), .Y(new_n53_));
  AO21x1_ASAP7_75t_R   g035(.A1(p7), .A2(new_n49_), .B(new_n53_), .Y(new_n54_));
  AO22x1_ASAP7_75t_R   g036(.A1(new_n35_), .A2(p5), .B1(p9), .B2(new_n54_), .Y(new_n55_));
  NOR2x1_ASAP7_75t_R   g037(.A(p7), .B(p8), .Y(new_n56_));
  INVx1_ASAP7_75t_R    g038(.A(new_n56_), .Y(new_n57_));
  XNOR2x2_ASAP7_75t_R  g039(.A(p2), .B(p1), .Y(new_n58_));
  OAI21x1_ASAP7_75t_R  g040(.A1(new_n57_), .A2(new_n58_), .B(new_n52_), .Y(new_n59_));
  AOI22x1_ASAP7_75t_R  g041(.A1(new_n51_), .A2(new_n52_), .B1(new_n55_), .B2(new_n59_), .Y(new_n60_));
  OAI21x1_ASAP7_75t_R  g042(.A1(new_n38_), .A2(new_n40_), .B(new_n60_), .Y(o0));
  NAND2x1_ASAP7_75t_R  g043(.A(p6), .B(new_n56_), .Y(new_n62_));
  INVx1_ASAP7_75t_R    g044(.A(p8), .Y(new_n63_));
  OAI22x1_ASAP7_75t_R  g045(.A1(new_n62_), .A2(new_n45_), .B1(p6), .B2(new_n63_), .Y(new_n64_));
  OA211x2_ASAP7_75t_R  g046(.A1(new_n27_), .A2(new_n56_), .B(p2), .C(p4), .Y(new_n65_));
  AND2x2_ASAP7_75t_R   g047(.A(p0), .B(p1), .Y(new_n66_));
  OA22x2_ASAP7_75t_R   g048(.A1(new_n66_), .A2(p6), .B1(p3), .B2(new_n20_), .Y(new_n67_));
  AOI22x1_ASAP7_75t_R  g049(.A1(new_n64_), .A2(new_n28_), .B1(new_n65_), .B2(new_n67_), .Y(new_n68_));
  NOR2x1_ASAP7_75t_R   g050(.A(p6), .B(new_n63_), .Y(new_n69_));
  AND2x2_ASAP7_75t_R   g051(.A(p4), .B(p5), .Y(new_n70_));
  NOR2x1_ASAP7_75t_R   g052(.A(p3), .B(p8), .Y(new_n71_));
  OR3x1_ASAP7_75t_R    g053(.A(new_n69_), .B(new_n70_), .C(new_n71_), .Y(new_n72_));
  OAI21x1_ASAP7_75t_R  g054(.A1(new_n71_), .A2(new_n69_), .B(p5), .Y(new_n73_));
  NAND3x1_ASAP7_75t_R  g055(.A(new_n72_), .B(new_n57_), .C(new_n73_), .Y(new_n74_));
  NOR2x1_ASAP7_75t_R   g056(.A(p3), .B(p0), .Y(new_n75_));
  OA21x2_ASAP7_75t_R   g057(.A1(p7), .A2(new_n75_), .B(new_n63_), .Y(new_n76_));
  AO21x1_ASAP7_75t_R   g058(.A1(p0), .A2(p10), .B(p1), .Y(new_n77_));
  NAND3x1_ASAP7_75t_R  g059(.A(p0), .B(p10), .C(p1), .Y(new_n78_));
  AOI221x1_ASAP7_75t_R g060(.A1(new_n27_), .A2(p0), .B1(new_n77_), .B2(new_n78_), .C(p6), .Y(new_n79_));
  NOR2x1_ASAP7_75t_R   g061(.A(p4), .B(p5), .Y(new_n80_));
  OAI21x1_ASAP7_75t_R  g062(.A1(new_n76_), .A2(new_n79_), .B(new_n80_), .Y(new_n81_));
  NAND3x1_ASAP7_75t_R  g063(.A(new_n68_), .B(new_n74_), .C(new_n81_), .Y(new_n82_));
  AND3x1_ASAP7_75t_R   g064(.A(new_n63_), .B(p2), .C(p1), .Y(new_n83_));
  INVx1_ASAP7_75t_R    g065(.A(p5), .Y(new_n84_));
  NOR3x1_ASAP7_75t_R   g066(.A(new_n83_), .B(new_n84_), .C(new_n71_), .Y(new_n85_));
  NAND2x1_ASAP7_75t_R  g067(.A(p2), .B(new_n84_), .Y(new_n86_));
  NOR2x1_ASAP7_75t_R   g068(.A(p6), .B(new_n80_), .Y(new_n87_));
  NAND2x1_ASAP7_75t_R  g069(.A(new_n86_), .B(new_n87_), .Y(new_n88_));
  AO32x1_ASAP7_75t_R   g070(.A1(new_n27_), .A2(p2), .A3(p1), .B1(new_n66_), .B2(new_n84_), .Y(new_n89_));
  OR3x1_ASAP7_75t_R    g071(.A(new_n85_), .B(new_n88_), .C(new_n89_), .Y(new_n90_));
  OR3x1_ASAP7_75t_R    g072(.A(new_n35_), .B(new_n84_), .C(p8), .Y(new_n91_));
  AND3x1_ASAP7_75t_R   g073(.A(new_n22_), .B(p6), .C(p5), .Y(new_n92_));
  AO21x1_ASAP7_75t_R   g074(.A1(p7), .A2(new_n91_), .B(new_n92_), .Y(new_n93_));
  AOI21x1_ASAP7_75t_R  g075(.A1(new_n52_), .A2(new_n90_), .B(new_n93_), .Y(new_n94_));
  AOI21x1_ASAP7_75t_R  g076(.A1(new_n52_), .A2(new_n82_), .B(new_n94_), .Y(o1));
  INVx1_ASAP7_75t_R    g077(.A(p1), .Y(new_n96_));
  NAND2x1_ASAP7_75t_R  g078(.A(p3), .B(new_n96_), .Y(new_n97_));
  OAI22x1_ASAP7_75t_R  g079(.A1(new_n86_), .A2(new_n97_), .B1(new_n33_), .B2(new_n28_), .Y(new_n98_));
  OAI21x1_ASAP7_75t_R  g080(.A1(p1), .A2(new_n98_), .B(new_n47_), .Y(new_n99_));
  NAND2x1_ASAP7_75t_R  g081(.A(p0), .B(p10), .Y(new_n100_));
  NOR2x1_ASAP7_75t_R   g082(.A(p3), .B(p5), .Y(new_n101_));
  AO21x1_ASAP7_75t_R   g083(.A1(new_n100_), .A2(new_n45_), .B(new_n101_), .Y(new_n102_));
  NAND2x1_ASAP7_75t_R  g084(.A(p10), .B(new_n84_), .Y(new_n103_));
  NAND3x1_ASAP7_75t_R  g085(.A(new_n27_), .B(p2), .C(p4), .Y(new_n104_));
  OAI21x1_ASAP7_75t_R  g086(.A1(new_n33_), .A2(new_n103_), .B(new_n104_), .Y(new_n105_));
  AOI221x1_ASAP7_75t_R g087(.A1(new_n28_), .A2(new_n102_), .B1(new_n105_), .B2(p0), .C(new_n98_), .Y(new_n106_));
  AND3x1_ASAP7_75t_R   g088(.A(new_n70_), .B(p3), .C(new_n35_), .Y(new_n107_));
  NAND3x1_ASAP7_75t_R  g089(.A(new_n30_), .B(new_n84_), .C(p4), .Y(new_n108_));
  NAND3x1_ASAP7_75t_R  g090(.A(new_n28_), .B(p5), .C(p1), .Y(new_n109_));
  NAND3x1_ASAP7_75t_R  g091(.A(new_n108_), .B(new_n109_), .C(new_n45_), .Y(new_n110_));
  OA21x2_ASAP7_75t_R   g092(.A1(new_n45_), .A2(new_n70_), .B(new_n22_), .Y(new_n111_));
  AND2x2_ASAP7_75t_R   g093(.A(p6), .B(p5), .Y(new_n112_));
  NAND2x1_ASAP7_75t_R  g094(.A(p3), .B(p4), .Y(new_n113_));
  AND3x1_ASAP7_75t_R   g095(.A(p3), .B(p2), .C(p4), .Y(new_n114_));
  AO22x1_ASAP7_75t_R   g096(.A1(new_n112_), .A2(new_n113_), .B1(new_n114_), .B2(new_n53_), .Y(new_n115_));
  AOI221x1_ASAP7_75t_R g097(.A1(new_n96_), .A2(new_n107_), .B1(new_n110_), .B2(new_n111_), .C(new_n115_), .Y(new_n116_));
  OAI21x1_ASAP7_75t_R  g098(.A1(new_n99_), .A2(new_n106_), .B(new_n116_), .Y(new_n117_));
  OAI21x1_ASAP7_75t_R  g099(.A1(new_n53_), .A2(new_n107_), .B(p7), .Y(new_n118_));
  OR3x1_ASAP7_75t_R    g100(.A(new_n28_), .B(new_n63_), .C(p7), .Y(new_n119_));
  OAI21x1_ASAP7_75t_R  g101(.A1(new_n22_), .A2(new_n52_), .B(new_n119_), .Y(new_n120_));
  OR3x1_ASAP7_75t_R    g102(.A(new_n28_), .B(new_n35_), .C(p9), .Y(new_n121_));
  OA21x2_ASAP7_75t_R   g103(.A1(p7), .A2(p9), .B(p8), .Y(new_n122_));
  AOI22x1_ASAP7_75t_R  g104(.A1(new_n120_), .A2(new_n112_), .B1(new_n121_), .B2(new_n122_), .Y(new_n123_));
  OAI21x1_ASAP7_75t_R  g105(.A1(p9), .A2(new_n118_), .B(new_n123_), .Y(new_n124_));
  AO21x1_ASAP7_75t_R   g106(.A1(new_n39_), .A2(new_n117_), .B(new_n124_), .Y(o2));
  OR4x2_ASAP7_75t_R    g107(.A(new_n22_), .B(new_n28_), .C(new_n35_), .D(new_n84_), .Y(new_n126_));
  OR5x1_ASAP7_75t_R    g108(.A(p3), .B(p7), .C(p4), .D(p6), .E(p5), .Y(new_n127_));
  OA21x2_ASAP7_75t_R   g109(.A1(new_n97_), .A2(new_n126_), .B(new_n127_), .Y(new_n128_));
  OR3x1_ASAP7_75t_R    g110(.A(new_n128_), .B(p2), .C(new_n40_), .Y(o3));
  AO21x1_ASAP7_75t_R   g111(.A1(new_n35_), .A2(new_n66_), .B(new_n70_), .Y(new_n130_));
  AND3x1_ASAP7_75t_R   g112(.A(new_n28_), .B(new_n35_), .C(p3), .Y(new_n131_));
  AO21x1_ASAP7_75t_R   g113(.A1(p5), .A2(new_n35_), .B(p7), .Y(new_n132_));
  AOI211x1_ASAP7_75t_R g114(.A1(new_n45_), .A2(new_n130_), .B(new_n131_), .C(new_n132_), .Y(new_n133_));
  AND3x1_ASAP7_75t_R   g115(.A(new_n80_), .B(p0), .C(p10), .Y(new_n134_));
  AND3x1_ASAP7_75t_R   g116(.A(new_n22_), .B(p2), .C(p1), .Y(new_n135_));
  OA21x2_ASAP7_75t_R   g117(.A1(new_n134_), .A2(new_n107_), .B(new_n135_), .Y(new_n136_));
  AND2x2_ASAP7_75t_R   g118(.A(p8), .B(new_n126_), .Y(new_n137_));
  AO21x1_ASAP7_75t_R   g119(.A1(new_n31_), .A2(new_n96_), .B(new_n113_), .Y(new_n138_));
  AOI211x1_ASAP7_75t_R g120(.A1(new_n22_), .A2(p2), .B(new_n91_), .C(new_n138_), .Y(new_n139_));
  OR3x1_ASAP7_75t_R    g121(.A(new_n136_), .B(new_n137_), .C(new_n139_), .Y(new_n140_));
  OAI21x1_ASAP7_75t_R  g122(.A1(new_n133_), .A2(new_n140_), .B(new_n52_), .Y(o4));
  OR5x1_ASAP7_75t_R    g123(.A(p7), .B(new_n78_), .C(new_n31_), .D(p4), .E(p6), .Y(new_n142_));
  AO21x1_ASAP7_75t_R   g124(.A1(new_n31_), .A2(new_n96_), .B(new_n126_), .Y(new_n143_));
  AO21x1_ASAP7_75t_R   g125(.A1(new_n142_), .A2(new_n143_), .B(new_n27_), .Y(new_n144_));
  AND3x1_ASAP7_75t_R   g126(.A(new_n45_), .B(new_n70_), .C(p1), .Y(new_n145_));
  INVx1_ASAP7_75t_R    g127(.A(new_n47_), .Y(new_n146_));
  OR3x1_ASAP7_75t_R    g128(.A(new_n145_), .B(new_n146_), .C(new_n80_), .Y(new_n147_));
  NAND3x1_ASAP7_75t_R  g129(.A(new_n144_), .B(new_n39_), .C(new_n147_), .Y(o5));
  OR3x1_ASAP7_75t_R    g130(.A(new_n145_), .B(new_n40_), .C(new_n146_), .Y(o6));
endmodule


