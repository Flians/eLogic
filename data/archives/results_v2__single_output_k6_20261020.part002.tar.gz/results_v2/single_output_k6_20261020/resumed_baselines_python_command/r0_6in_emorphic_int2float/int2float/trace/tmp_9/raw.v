// Benchmark "/tmp/" written by ABC on Tue Oct 20 17:46:14 2026

module \/tmp/  ( 
    p3, p4, p10, p7, p9, p1, p2, p5, p8, p6, p0,
    o0, o1, o2, o3, o4, o5, o6  );
  input  p3, p4, p10, p7, p9, p1, p2, p5, p8, p6, p0;
  output o0, o1, o2, o3, o4, o5, o6;
  wire new_n19_, new_n20_, new_n21_, new_n22_, new_n23_, new_n24_, new_n25_,
    new_n26_, new_n27_, new_n28_, new_n29_, new_n30_, new_n31_, new_n32_,
    new_n33_, new_n34_, new_n35_, new_n36_, new_n37_, new_n38_, new_n39_,
    new_n40_, new_n41_, new_n42_, new_n43_, new_n44_, new_n45_, new_n46_,
    new_n47_, new_n48_, new_n49_, new_n50_, new_n51_, new_n52_, new_n53_,
    new_n54_, new_n55_, new_n56_, new_n57_, new_n58_, new_n59_, new_n60_,
    new_n61_, new_n62_, new_n63_, new_n64_, new_n65_, new_n67_, new_n68_,
    new_n69_, new_n70_, new_n71_, new_n72_, new_n73_, new_n74_, new_n75_,
    new_n76_, new_n77_, new_n78_, new_n79_, new_n80_, new_n81_, new_n82_,
    new_n83_, new_n84_, new_n85_, new_n86_, new_n87_, new_n88_, new_n89_,
    new_n90_, new_n91_, new_n92_, new_n93_, new_n94_, new_n95_, new_n96_,
    new_n97_, new_n98_, new_n99_, new_n101_, new_n102_, new_n103_,
    new_n104_, new_n105_, new_n106_, new_n107_, new_n108_, new_n109_,
    new_n110_, new_n111_, new_n112_, new_n113_, new_n114_, new_n115_,
    new_n116_, new_n117_, new_n118_, new_n119_, new_n120_, new_n121_,
    new_n122_, new_n123_, new_n124_, new_n125_, new_n126_, new_n127_,
    new_n128_, new_n129_, new_n130_, new_n131_, new_n133_, new_n134_,
    new_n135_, new_n136_, new_n137_, new_n139_, new_n140_, new_n141_,
    new_n142_, new_n143_, new_n144_, new_n145_, new_n146_, new_n147_,
    new_n148_, new_n149_, new_n151_, new_n152_, new_n153_, new_n154_,
    new_n155_, new_n156_;
  NOR2x1_ASAP7_75t_R   g000(.A(p9), .B(p8), .Y(new_n19_));
  INVx1_ASAP7_75t_R    g001(.A(new_n19_), .Y(new_n20_));
  INVx1_ASAP7_75t_R    g002(.A(p4), .Y(new_n21_));
  INVx1_ASAP7_75t_R    g003(.A(p10), .Y(new_n22_));
  NAND2x1_ASAP7_75t_R  g004(.A(p3), .B(p0), .Y(new_n23_));
  INVx1_ASAP7_75t_R    g005(.A(p5), .Y(new_n24_));
  INVx1_ASAP7_75t_R    g006(.A(p6), .Y(new_n25_));
  NAND2x1_ASAP7_75t_R  g007(.A(new_n24_), .B(new_n25_), .Y(new_n26_));
  AOI21x1_ASAP7_75t_R  g008(.A1(new_n22_), .A2(new_n23_), .B(new_n26_), .Y(new_n27_));
  INVx1_ASAP7_75t_R    g009(.A(p3), .Y(new_n28_));
  NAND2x1_ASAP7_75t_R  g010(.A(p7), .B(new_n28_), .Y(new_n29_));
  AO21x1_ASAP7_75t_R   g011(.A1(new_n23_), .A2(new_n29_), .B(new_n22_), .Y(new_n30_));
  AND2x2_ASAP7_75t_R   g012(.A(p3), .B(p7), .Y(new_n31_));
  AO21x1_ASAP7_75t_R   g013(.A1(new_n27_), .A2(new_n30_), .B(new_n31_), .Y(new_n32_));
  INVx1_ASAP7_75t_R    g014(.A(p7), .Y(new_n33_));
  INVx1_ASAP7_75t_R    g015(.A(p2), .Y(new_n34_));
  AND3x1_ASAP7_75t_R   g016(.A(new_n34_), .B(p3), .C(p6), .Y(new_n35_));
  NOR2x1_ASAP7_75t_R   g017(.A(p1), .B(p6), .Y(new_n36_));
  AO32x1_ASAP7_75t_R   g018(.A1(new_n36_), .A2(p4), .A3(p0), .B1(new_n28_), .B2(p6), .Y(new_n37_));
  NOR2x1_ASAP7_75t_R   g019(.A(p7), .B(new_n34_), .Y(new_n38_));
  AND3x1_ASAP7_75t_R   g020(.A(new_n28_), .B(p4), .C(p7), .Y(new_n39_));
  AO221x2_ASAP7_75t_R  g021(.A1(new_n33_), .A2(new_n35_), .B1(new_n37_), .B2(new_n38_), .C(new_n39_), .Y(new_n40_));
  AOI21x1_ASAP7_75t_R  g022(.A1(new_n21_), .A2(new_n32_), .B(new_n40_), .Y(new_n41_));
  INVx1_ASAP7_75t_R    g023(.A(p9), .Y(new_n42_));
  NOR2x1_ASAP7_75t_R   g024(.A(p5), .B(new_n21_), .Y(new_n43_));
  INVx1_ASAP7_75t_R    g025(.A(new_n43_), .Y(new_n44_));
  NOR2x1_ASAP7_75t_R   g026(.A(p3), .B(new_n25_), .Y(new_n45_));
  INVx1_ASAP7_75t_R    g027(.A(p0), .Y(new_n46_));
  AND2x2_ASAP7_75t_R   g028(.A(p3), .B(p2), .Y(new_n47_));
  OR5x1_ASAP7_75t_R    g029(.A(p1), .B(new_n45_), .C(new_n46_), .D(new_n31_), .E(new_n47_), .Y(new_n48_));
  NOR2x1_ASAP7_75t_R   g030(.A(p7), .B(p6), .Y(new_n49_));
  AO31x2_ASAP7_75t_R   g031(.A1(new_n49_), .A2(p1), .A3(new_n46_), .B(p8), .Y(new_n50_));
  AND3x1_ASAP7_75t_R   g032(.A(new_n21_), .B(p5), .C(p8), .Y(new_n51_));
  AOI21x1_ASAP7_75t_R  g033(.A1(new_n43_), .A2(new_n50_), .B(new_n51_), .Y(new_n52_));
  OAI21x1_ASAP7_75t_R  g034(.A1(new_n44_), .A2(new_n48_), .B(new_n52_), .Y(new_n53_));
  NAND2x1_ASAP7_75t_R  g035(.A(p5), .B(new_n25_), .Y(new_n54_));
  NAND2x1_ASAP7_75t_R  g036(.A(p1), .B(p2), .Y(new_n55_));
  INVx1_ASAP7_75t_R    g037(.A(new_n55_), .Y(new_n56_));
  NOR2x1_ASAP7_75t_R   g038(.A(p7), .B(p8), .Y(new_n57_));
  OAI21x1_ASAP7_75t_R  g039(.A1(p1), .A2(p2), .B(new_n57_), .Y(new_n58_));
  OA21x2_ASAP7_75t_R   g040(.A1(new_n56_), .A2(new_n58_), .B(new_n42_), .Y(new_n59_));
  NAND2x1_ASAP7_75t_R  g041(.A(p6), .B(new_n24_), .Y(new_n60_));
  INVx1_ASAP7_75t_R    g042(.A(p8), .Y(new_n61_));
  OR3x1_ASAP7_75t_R    g043(.A(new_n33_), .B(new_n24_), .C(new_n61_), .Y(new_n62_));
  AO21x1_ASAP7_75t_R   g044(.A1(new_n60_), .A2(new_n62_), .B(new_n42_), .Y(new_n63_));
  OAI21x1_ASAP7_75t_R  g045(.A1(new_n54_), .A2(new_n59_), .B(new_n63_), .Y(new_n64_));
  AOI21x1_ASAP7_75t_R  g046(.A1(new_n42_), .A2(new_n53_), .B(new_n64_), .Y(new_n65_));
  OAI21x1_ASAP7_75t_R  g047(.A1(new_n20_), .A2(new_n41_), .B(new_n65_), .Y(o0));
  NAND2x1_ASAP7_75t_R  g048(.A(p6), .B(new_n57_), .Y(new_n67_));
  NAND2x1_ASAP7_75t_R  g049(.A(p8), .B(new_n25_), .Y(new_n68_));
  OAI21x1_ASAP7_75t_R  g050(.A1(new_n47_), .A2(new_n67_), .B(new_n68_), .Y(new_n69_));
  OAI21x1_ASAP7_75t_R  g051(.A1(new_n24_), .A2(new_n69_), .B(new_n21_), .Y(new_n70_));
  INVx1_ASAP7_75t_R    g052(.A(p1), .Y(new_n71_));
  AO21x1_ASAP7_75t_R   g053(.A1(p10), .A2(p0), .B(new_n71_), .Y(new_n72_));
  OA211x2_ASAP7_75t_R  g054(.A1(new_n22_), .A2(p1), .B(new_n25_), .C(p3), .Y(new_n73_));
  NOR2x1_ASAP7_75t_R   g055(.A(p3), .B(p8), .Y(new_n74_));
  NOR2x1_ASAP7_75t_R   g056(.A(new_n36_), .B(new_n74_), .Y(new_n75_));
  OAI22x1_ASAP7_75t_R  g057(.A1(new_n75_), .A2(p0), .B1(new_n33_), .B2(p8), .Y(new_n76_));
  AOI211x1_ASAP7_75t_R g058(.A1(new_n72_), .A2(new_n73_), .B(new_n69_), .C(new_n76_), .Y(new_n77_));
  AOI21x1_ASAP7_75t_R  g059(.A1(p8), .A2(new_n25_), .B(new_n74_), .Y(new_n78_));
  AND2x2_ASAP7_75t_R   g060(.A(p4), .B(p5), .Y(new_n79_));
  INVx1_ASAP7_75t_R    g061(.A(new_n79_), .Y(new_n80_));
  AOI21x1_ASAP7_75t_R  g062(.A1(new_n78_), .A2(new_n80_), .B(new_n57_), .Y(new_n81_));
  INVx1_ASAP7_75t_R    g063(.A(new_n74_), .Y(new_n82_));
  AO21x1_ASAP7_75t_R   g064(.A1(new_n68_), .A2(new_n82_), .B(new_n24_), .Y(new_n83_));
  NAND2x1_ASAP7_75t_R  g065(.A(p4), .B(p2), .Y(new_n84_));
  AOI21x1_ASAP7_75t_R  g066(.A1(new_n28_), .A2(new_n26_), .B(new_n84_), .Y(new_n85_));
  AO21x1_ASAP7_75t_R   g067(.A1(p1), .A2(p0), .B(p6), .Y(new_n86_));
  OA21x2_ASAP7_75t_R   g068(.A1(new_n28_), .A2(new_n57_), .B(new_n86_), .Y(new_n87_));
  AOI22x1_ASAP7_75t_R  g069(.A1(new_n81_), .A2(new_n83_), .B1(new_n85_), .B2(new_n87_), .Y(new_n88_));
  OAI21x1_ASAP7_75t_R  g070(.A1(new_n70_), .A2(new_n77_), .B(new_n88_), .Y(new_n89_));
  AO21x1_ASAP7_75t_R   g071(.A1(p5), .A2(p6), .B(p7), .Y(new_n90_));
  INVx1_ASAP7_75t_R    g072(.A(new_n86_), .Y(new_n91_));
  AND3x1_ASAP7_75t_R   g073(.A(new_n34_), .B(new_n24_), .C(p4), .Y(new_n92_));
  XOR2x2_ASAP7_75t_R   g074(.A(new_n55_), .B(p3), .Y(new_n93_));
  AND3x1_ASAP7_75t_R   g075(.A(new_n61_), .B(new_n25_), .C(p5), .Y(new_n94_));
  AOI221x1_ASAP7_75t_R g076(.A1(new_n91_), .A2(new_n92_), .B1(new_n93_), .B2(new_n94_), .C(p9), .Y(new_n95_));
  NAND2x1_ASAP7_75t_R  g077(.A(p7), .B(p9), .Y(new_n96_));
  NAND2x1_ASAP7_75t_R  g078(.A(p5), .B(p6), .Y(new_n97_));
  OR3x1_ASAP7_75t_R    g079(.A(new_n96_), .B(new_n97_), .C(p8), .Y(new_n98_));
  OAI21x1_ASAP7_75t_R  g080(.A1(new_n90_), .A2(new_n95_), .B(new_n98_), .Y(new_n99_));
  AOI21x1_ASAP7_75t_R  g081(.A1(new_n42_), .A2(new_n89_), .B(new_n99_), .Y(o1));
  AND3x1_ASAP7_75t_R   g082(.A(new_n33_), .B(new_n42_), .C(new_n61_), .Y(new_n101_));
  AND2x2_ASAP7_75t_R   g083(.A(p3), .B(p4), .Y(new_n102_));
  AO32x1_ASAP7_75t_R   g084(.A1(new_n47_), .A2(new_n71_), .A3(new_n24_), .B1(new_n102_), .B2(new_n34_), .Y(new_n103_));
  OAI21x1_ASAP7_75t_R  g085(.A1(p1), .A2(new_n103_), .B(new_n25_), .Y(new_n104_));
  AND2x2_ASAP7_75t_R   g086(.A(p10), .B(p0), .Y(new_n105_));
  NAND2x1_ASAP7_75t_R  g087(.A(p3), .B(p2), .Y(new_n106_));
  OAI22x1_ASAP7_75t_R  g088(.A1(new_n105_), .A2(new_n106_), .B1(p3), .B2(p5), .Y(new_n107_));
  NAND2x1_ASAP7_75t_R  g089(.A(p3), .B(new_n34_), .Y(new_n108_));
  NAND2x1_ASAP7_75t_R  g090(.A(p10), .B(new_n24_), .Y(new_n109_));
  NAND3x1_ASAP7_75t_R  g091(.A(new_n28_), .B(p4), .C(p2), .Y(new_n110_));
  OAI21x1_ASAP7_75t_R  g092(.A1(new_n108_), .A2(new_n109_), .B(new_n110_), .Y(new_n111_));
  AOI221x1_ASAP7_75t_R g093(.A1(new_n21_), .A2(new_n107_), .B1(new_n111_), .B2(p0), .C(new_n103_), .Y(new_n112_));
  AND3x1_ASAP7_75t_R   g094(.A(new_n106_), .B(p4), .C(p5), .Y(new_n113_));
  AO22x1_ASAP7_75t_R   g095(.A1(p1), .A2(p5), .B1(p4), .B2(new_n46_), .Y(new_n114_));
  AND3x1_ASAP7_75t_R   g096(.A(new_n114_), .B(new_n47_), .C(new_n80_), .Y(new_n115_));
  NOR2x1_ASAP7_75t_R   g097(.A(new_n113_), .B(new_n115_), .Y(new_n116_));
  OAI21x1_ASAP7_75t_R  g098(.A1(new_n104_), .A2(new_n112_), .B(new_n116_), .Y(new_n117_));
  NAND2x1_ASAP7_75t_R  g099(.A(p3), .B(p4), .Y(new_n118_));
  NAND3x1_ASAP7_75t_R  g100(.A(new_n24_), .B(p2), .C(p6), .Y(new_n119_));
  NAND2x1_ASAP7_75t_R  g101(.A(p5), .B(new_n36_), .Y(new_n120_));
  NAND2x1_ASAP7_75t_R  g102(.A(new_n119_), .B(new_n120_), .Y(new_n121_));
  NAND2x1_ASAP7_75t_R  g103(.A(new_n97_), .B(new_n118_), .Y(new_n122_));
  OAI21x1_ASAP7_75t_R  g104(.A1(new_n118_), .A2(new_n121_), .B(new_n122_), .Y(new_n123_));
  NAND2x1_ASAP7_75t_R  g105(.A(p4), .B(p6), .Y(new_n124_));
  AO21x1_ASAP7_75t_R   g106(.A1(p7), .A2(new_n124_), .B(p9), .Y(new_n125_));
  OAI21x1_ASAP7_75t_R  g107(.A1(new_n118_), .A2(new_n54_), .B(new_n60_), .Y(new_n126_));
  NOR2x1_ASAP7_75t_R   g108(.A(p9), .B(new_n33_), .Y(new_n127_));
  NAND3x1_ASAP7_75t_R  g109(.A(new_n33_), .B(p4), .C(p8), .Y(new_n128_));
  AOI21x1_ASAP7_75t_R  g110(.A1(new_n96_), .A2(new_n128_), .B(new_n97_), .Y(new_n129_));
  AOI221x1_ASAP7_75t_R g111(.A1(p8), .A2(new_n125_), .B1(new_n126_), .B2(new_n127_), .C(new_n129_), .Y(new_n130_));
  OAI21x1_ASAP7_75t_R  g112(.A1(new_n20_), .A2(new_n123_), .B(new_n130_), .Y(new_n131_));
  AO21x1_ASAP7_75t_R   g113(.A1(new_n101_), .A2(new_n117_), .B(new_n131_), .Y(o2));
  NOR2x1_ASAP7_75t_R   g114(.A(p4), .B(p5), .Y(new_n133_));
  AND3x1_ASAP7_75t_R   g115(.A(new_n133_), .B(new_n49_), .C(new_n28_), .Y(new_n134_));
  AND3x1_ASAP7_75t_R   g116(.A(p4), .B(p5), .C(p6), .Y(new_n135_));
  AND3x1_ASAP7_75t_R   g117(.A(new_n135_), .B(new_n31_), .C(new_n71_), .Y(new_n136_));
  NOR2x1_ASAP7_75t_R   g118(.A(new_n134_), .B(new_n136_), .Y(new_n137_));
  OR3x1_ASAP7_75t_R    g119(.A(new_n137_), .B(p2), .C(new_n20_), .Y(o3));
  AO21x1_ASAP7_75t_R   g120(.A1(new_n71_), .A2(new_n34_), .B(new_n38_), .Y(new_n139_));
  OR3x1_ASAP7_75t_R    g121(.A(new_n97_), .B(new_n118_), .C(p8), .Y(new_n140_));
  AND3x1_ASAP7_75t_R   g122(.A(new_n79_), .B(p7), .C(p6), .Y(new_n141_));
  OAI22x1_ASAP7_75t_R  g123(.A1(new_n139_), .A2(new_n140_), .B1(new_n61_), .B2(new_n141_), .Y(new_n142_));
  OR3x1_ASAP7_75t_R    g124(.A(new_n71_), .B(new_n46_), .C(p6), .Y(new_n143_));
  AO21x1_ASAP7_75t_R   g125(.A1(new_n80_), .A2(new_n143_), .B(new_n106_), .Y(new_n144_));
  NOR2x1_ASAP7_75t_R   g126(.A(p4), .B(p6), .Y(new_n145_));
  NAND2x1_ASAP7_75t_R  g127(.A(p3), .B(new_n145_), .Y(new_n146_));
  AO32x1_ASAP7_75t_R   g128(.A1(new_n79_), .A2(p3), .A3(new_n25_), .B1(new_n105_), .B2(new_n133_), .Y(new_n147_));
  AO32x1_ASAP7_75t_R   g129(.A1(new_n144_), .A2(new_n54_), .A3(new_n146_), .B1(new_n56_), .B2(new_n147_), .Y(new_n148_));
  OA21x2_ASAP7_75t_R   g130(.A1(new_n33_), .A2(new_n142_), .B(new_n42_), .Y(new_n149_));
  OAI21x1_ASAP7_75t_R  g131(.A1(new_n142_), .A2(new_n148_), .B(new_n149_), .Y(o4));
  AO21x1_ASAP7_75t_R   g132(.A1(p2), .A2(new_n141_), .B(p1), .Y(new_n151_));
  AND3x1_ASAP7_75t_R   g133(.A(new_n38_), .B(new_n105_), .C(new_n145_), .Y(new_n152_));
  OA21x2_ASAP7_75t_R   g134(.A1(new_n141_), .A2(new_n152_), .B(p3), .Y(new_n153_));
  OR3x1_ASAP7_75t_R    g135(.A(new_n133_), .B(p7), .C(p6), .Y(new_n154_));
  AND3x1_ASAP7_75t_R   g136(.A(new_n56_), .B(new_n102_), .C(p5), .Y(new_n155_));
  OAI21x1_ASAP7_75t_R  g137(.A1(new_n154_), .A2(new_n155_), .B(new_n19_), .Y(new_n156_));
  AO21x1_ASAP7_75t_R   g138(.A1(new_n151_), .A2(new_n153_), .B(new_n156_), .Y(o5));
  OR4x2_ASAP7_75t_R    g139(.A(new_n155_), .B(p7), .C(p6), .D(new_n20_), .Y(o6));
endmodule


