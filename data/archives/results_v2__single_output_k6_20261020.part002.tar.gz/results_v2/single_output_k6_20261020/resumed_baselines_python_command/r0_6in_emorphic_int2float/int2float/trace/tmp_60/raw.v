// Benchmark "/tmp/" written by ABC on Tue Oct 20 17:46:20 2026

module \/tmp/  ( 
    p5, p3, p0, p7, p10, p9, p2, p8, p1, p6, p4,
    o0, o1, o2, o3, o4, o5, o6  );
  input  p5, p3, p0, p7, p10, p9, p2, p8, p1, p6, p4;
  output o0, o1, o2, o3, o4, o5, o6;
  wire new_n19_, new_n20_, new_n21_, new_n22_, new_n23_, new_n24_, new_n25_,
    new_n26_, new_n27_, new_n28_, new_n29_, new_n30_, new_n31_, new_n32_,
    new_n33_, new_n34_, new_n35_, new_n36_, new_n37_, new_n38_, new_n39_,
    new_n40_, new_n41_, new_n42_, new_n43_, new_n44_, new_n45_, new_n46_,
    new_n47_, new_n48_, new_n49_, new_n50_, new_n51_, new_n52_, new_n53_,
    new_n54_, new_n55_, new_n56_, new_n57_, new_n58_, new_n59_, new_n60_,
    new_n61_, new_n62_, new_n64_, new_n65_, new_n66_, new_n67_, new_n68_,
    new_n69_, new_n70_, new_n71_, new_n72_, new_n73_, new_n74_, new_n75_,
    new_n76_, new_n77_, new_n78_, new_n79_, new_n80_, new_n81_, new_n82_,
    new_n83_, new_n84_, new_n85_, new_n86_, new_n87_, new_n88_, new_n89_,
    new_n90_, new_n91_, new_n92_, new_n93_, new_n94_, new_n95_, new_n96_,
    new_n97_, new_n98_, new_n99_, new_n101_, new_n102_, new_n103_,
    new_n104_, new_n105_, new_n106_, new_n107_, new_n108_, new_n109_,
    new_n110_, new_n111_, new_n112_, new_n113_, new_n114_, new_n115_,
    new_n116_, new_n117_, new_n118_, new_n119_, new_n120_, new_n121_,
    new_n122_, new_n123_, new_n124_, new_n125_, new_n126_, new_n127_,
    new_n128_, new_n129_, new_n130_, new_n131_, new_n133_, new_n134_,
    new_n135_, new_n136_, new_n137_, new_n138_, new_n140_, new_n141_,
    new_n142_, new_n143_, new_n144_, new_n145_, new_n146_, new_n147_,
    new_n148_, new_n149_, new_n150_, new_n151_, new_n153_, new_n154_,
    new_n155_, new_n156_, new_n157_;
  INVx1_ASAP7_75t_R    g000(.A(p10), .Y(new_n19_));
  NAND2x1_ASAP7_75t_R  g001(.A(p3), .B(p0), .Y(new_n20_));
  AOI211x1_ASAP7_75t_R g002(.A1(new_n19_), .A2(new_n20_), .B(p5), .C(p6), .Y(new_n21_));
  INVx1_ASAP7_75t_R    g003(.A(p3), .Y(new_n22_));
  NAND2x1_ASAP7_75t_R  g004(.A(p7), .B(new_n22_), .Y(new_n23_));
  AO21x1_ASAP7_75t_R   g005(.A1(new_n20_), .A2(new_n23_), .B(new_n19_), .Y(new_n24_));
  AO21x1_ASAP7_75t_R   g006(.A1(p3), .A2(p7), .B(p4), .Y(new_n25_));
  AO21x1_ASAP7_75t_R   g007(.A1(new_n21_), .A2(new_n24_), .B(new_n25_), .Y(new_n26_));
  INVx1_ASAP7_75t_R    g008(.A(p4), .Y(new_n27_));
  AO21x1_ASAP7_75t_R   g009(.A1(p7), .A2(new_n22_), .B(new_n27_), .Y(new_n28_));
  INVx1_ASAP7_75t_R    g010(.A(p7), .Y(new_n29_));
  INVx1_ASAP7_75t_R    g011(.A(p0), .Y(new_n30_));
  INVx1_ASAP7_75t_R    g012(.A(p2), .Y(new_n31_));
  OR5x1_ASAP7_75t_R    g013(.A(new_n30_), .B(new_n31_), .C(new_n27_), .D(p1), .E(p6), .Y(new_n32_));
  NAND2x1_ASAP7_75t_R  g014(.A(p3), .B(p2), .Y(new_n33_));
  NAND2x1_ASAP7_75t_R  g015(.A(p6), .B(new_n33_), .Y(new_n34_));
  AO21x1_ASAP7_75t_R   g016(.A1(new_n22_), .A2(new_n31_), .B(new_n34_), .Y(new_n35_));
  NAND2x1_ASAP7_75t_R  g017(.A(new_n32_), .B(new_n35_), .Y(new_n36_));
  AOI22x1_ASAP7_75t_R  g018(.A1(new_n26_), .A2(new_n28_), .B1(new_n29_), .B2(new_n36_), .Y(new_n37_));
  NOR2x1_ASAP7_75t_R   g019(.A(p9), .B(p8), .Y(new_n38_));
  INVx1_ASAP7_75t_R    g020(.A(new_n38_), .Y(new_n39_));
  NOR2x1_ASAP7_75t_R   g021(.A(p5), .B(new_n27_), .Y(new_n40_));
  INVx1_ASAP7_75t_R    g022(.A(new_n40_), .Y(new_n41_));
  INVx1_ASAP7_75t_R    g023(.A(p6), .Y(new_n42_));
  NOR2x1_ASAP7_75t_R   g024(.A(p3), .B(new_n42_), .Y(new_n43_));
  AND2x2_ASAP7_75t_R   g025(.A(p3), .B(p7), .Y(new_n44_));
  AND2x2_ASAP7_75t_R   g026(.A(p3), .B(p2), .Y(new_n45_));
  OR5x1_ASAP7_75t_R    g027(.A(new_n30_), .B(new_n43_), .C(p1), .D(new_n44_), .E(new_n45_), .Y(new_n46_));
  NOR2x1_ASAP7_75t_R   g028(.A(p7), .B(p6), .Y(new_n47_));
  AO31x2_ASAP7_75t_R   g029(.A1(new_n47_), .A2(new_n30_), .A3(p1), .B(p8), .Y(new_n48_));
  AND3x1_ASAP7_75t_R   g030(.A(new_n27_), .B(p5), .C(p8), .Y(new_n49_));
  AOI21x1_ASAP7_75t_R  g031(.A1(new_n40_), .A2(new_n48_), .B(new_n49_), .Y(new_n50_));
  OAI21x1_ASAP7_75t_R  g032(.A1(new_n41_), .A2(new_n46_), .B(new_n50_), .Y(new_n51_));
  INVx1_ASAP7_75t_R    g033(.A(p9), .Y(new_n52_));
  NOR2x1_ASAP7_75t_R   g034(.A(p2), .B(p1), .Y(new_n53_));
  INVx1_ASAP7_75t_R    g035(.A(p8), .Y(new_n54_));
  NAND2x1_ASAP7_75t_R  g036(.A(new_n29_), .B(new_n54_), .Y(new_n55_));
  AO21x1_ASAP7_75t_R   g037(.A1(p2), .A2(p1), .B(new_n55_), .Y(new_n56_));
  OAI21x1_ASAP7_75t_R  g038(.A1(new_n53_), .A2(new_n56_), .B(new_n52_), .Y(new_n57_));
  AND3x1_ASAP7_75t_R   g039(.A(p5), .B(p7), .C(p8), .Y(new_n58_));
  NOR2x1_ASAP7_75t_R   g040(.A(p5), .B(new_n42_), .Y(new_n59_));
  OA21x2_ASAP7_75t_R   g041(.A1(new_n58_), .A2(new_n59_), .B(p9), .Y(new_n60_));
  AO21x1_ASAP7_75t_R   g042(.A1(p5), .A2(new_n42_), .B(new_n60_), .Y(new_n61_));
  AOI22x1_ASAP7_75t_R  g043(.A1(new_n51_), .A2(new_n52_), .B1(new_n57_), .B2(new_n61_), .Y(new_n62_));
  OAI21x1_ASAP7_75t_R  g044(.A1(new_n37_), .A2(new_n39_), .B(new_n62_), .Y(o0));
  NOR3x1_ASAP7_75t_R   g045(.A(p5), .B(p3), .C(p6), .Y(new_n64_));
  NOR3x1_ASAP7_75t_R   g046(.A(new_n22_), .B(p7), .C(p8), .Y(new_n65_));
  NAND2x1_ASAP7_75t_R  g047(.A(p0), .B(p1), .Y(new_n66_));
  AOI21x1_ASAP7_75t_R  g048(.A1(new_n42_), .A2(new_n66_), .B(new_n31_), .Y(new_n67_));
  OAI21x1_ASAP7_75t_R  g049(.A1(new_n64_), .A2(new_n65_), .B(new_n67_), .Y(new_n68_));
  NOR2x1_ASAP7_75t_R   g050(.A(p6), .B(new_n54_), .Y(new_n69_));
  NOR2x1_ASAP7_75t_R   g051(.A(p3), .B(p8), .Y(new_n70_));
  OAI21x1_ASAP7_75t_R  g052(.A1(p7), .A2(p8), .B(p5), .Y(new_n71_));
  OR3x1_ASAP7_75t_R    g053(.A(new_n69_), .B(new_n70_), .C(new_n71_), .Y(new_n72_));
  AO21x1_ASAP7_75t_R   g054(.A1(new_n68_), .A2(new_n72_), .B(new_n27_), .Y(new_n73_));
  OAI22x1_ASAP7_75t_R  g055(.A1(new_n34_), .A2(new_n55_), .B1(new_n54_), .B2(p6), .Y(new_n74_));
  AO21x1_ASAP7_75t_R   g056(.A1(p7), .A2(new_n70_), .B(new_n69_), .Y(new_n75_));
  INVx1_ASAP7_75t_R    g057(.A(p5), .Y(new_n76_));
  AOI22x1_ASAP7_75t_R  g058(.A1(new_n74_), .A2(new_n27_), .B1(new_n75_), .B2(new_n76_), .Y(new_n77_));
  NOR2x1_ASAP7_75t_R   g059(.A(p3), .B(p0), .Y(new_n78_));
  OA21x2_ASAP7_75t_R   g060(.A1(p7), .A2(new_n78_), .B(new_n54_), .Y(new_n79_));
  AO21x1_ASAP7_75t_R   g061(.A1(p0), .A2(p10), .B(p1), .Y(new_n80_));
  NAND3x1_ASAP7_75t_R  g062(.A(p0), .B(p10), .C(p1), .Y(new_n81_));
  AOI221x1_ASAP7_75t_R g063(.A1(new_n22_), .A2(p0), .B1(new_n80_), .B2(new_n81_), .C(p6), .Y(new_n82_));
  NOR2x1_ASAP7_75t_R   g064(.A(p5), .B(p4), .Y(new_n83_));
  OAI21x1_ASAP7_75t_R  g065(.A1(new_n79_), .A2(new_n82_), .B(new_n83_), .Y(new_n84_));
  NAND3x1_ASAP7_75t_R  g066(.A(new_n73_), .B(new_n77_), .C(new_n84_), .Y(new_n85_));
  NAND2x1_ASAP7_75t_R  g067(.A(p7), .B(p9), .Y(new_n86_));
  NAND2x1_ASAP7_75t_R  g068(.A(p5), .B(p6), .Y(new_n87_));
  OR3x1_ASAP7_75t_R    g069(.A(new_n86_), .B(new_n87_), .C(p8), .Y(new_n88_));
  NOR2x1_ASAP7_75t_R   g070(.A(p5), .B(p0), .Y(new_n89_));
  AOI22x1_ASAP7_75t_R  g071(.A1(p5), .A2(new_n70_), .B1(new_n89_), .B2(p4), .Y(new_n90_));
  INVx1_ASAP7_75t_R    g072(.A(p1), .Y(new_n91_));
  OR4x2_ASAP7_75t_R    g073(.A(new_n33_), .B(new_n76_), .C(p8), .D(new_n91_), .Y(new_n92_));
  OAI21x1_ASAP7_75t_R  g074(.A1(p2), .A2(new_n90_), .B(new_n92_), .Y(new_n93_));
  OR4x2_ASAP7_75t_R    g075(.A(new_n76_), .B(p3), .C(p8), .D(p1), .Y(new_n94_));
  OR4x2_ASAP7_75t_R    g076(.A(new_n27_), .B(p5), .C(p2), .D(p1), .Y(new_n95_));
  NAND3x1_ASAP7_75t_R  g077(.A(new_n94_), .B(new_n95_), .C(new_n52_), .Y(new_n96_));
  OA211x2_ASAP7_75t_R  g078(.A1(p9), .A2(new_n42_), .B(new_n87_), .C(new_n29_), .Y(new_n97_));
  OAI21x1_ASAP7_75t_R  g079(.A1(new_n93_), .A2(new_n96_), .B(new_n97_), .Y(new_n98_));
  NAND2x1_ASAP7_75t_R  g080(.A(new_n88_), .B(new_n98_), .Y(new_n99_));
  AOI21x1_ASAP7_75t_R  g081(.A1(new_n52_), .A2(new_n85_), .B(new_n99_), .Y(o1));
  NAND2x1_ASAP7_75t_R  g082(.A(new_n76_), .B(new_n91_), .Y(new_n101_));
  NAND2x1_ASAP7_75t_R  g083(.A(p4), .B(new_n31_), .Y(new_n102_));
  OAI22x1_ASAP7_75t_R  g084(.A1(new_n101_), .A2(new_n33_), .B1(new_n102_), .B2(new_n22_), .Y(new_n103_));
  OAI21x1_ASAP7_75t_R  g085(.A1(p1), .A2(new_n103_), .B(new_n47_), .Y(new_n104_));
  NAND2x1_ASAP7_75t_R  g086(.A(p0), .B(p10), .Y(new_n105_));
  NOR2x1_ASAP7_75t_R   g087(.A(p5), .B(p3), .Y(new_n106_));
  AO21x1_ASAP7_75t_R   g088(.A1(new_n105_), .A2(new_n45_), .B(new_n106_), .Y(new_n107_));
  NAND2x1_ASAP7_75t_R  g089(.A(p3), .B(new_n31_), .Y(new_n108_));
  NAND2x1_ASAP7_75t_R  g090(.A(p10), .B(new_n76_), .Y(new_n109_));
  NAND3x1_ASAP7_75t_R  g091(.A(new_n22_), .B(p2), .C(p4), .Y(new_n110_));
  OAI21x1_ASAP7_75t_R  g092(.A1(new_n108_), .A2(new_n109_), .B(new_n110_), .Y(new_n111_));
  AOI221x1_ASAP7_75t_R g093(.A1(new_n27_), .A2(new_n107_), .B1(new_n111_), .B2(p0), .C(new_n103_), .Y(new_n112_));
  AND2x2_ASAP7_75t_R   g094(.A(p5), .B(p4), .Y(new_n113_));
  AND3x1_ASAP7_75t_R   g095(.A(new_n113_), .B(p3), .C(new_n42_), .Y(new_n114_));
  NAND3x1_ASAP7_75t_R  g096(.A(new_n76_), .B(new_n30_), .C(p4), .Y(new_n115_));
  NAND3x1_ASAP7_75t_R  g097(.A(new_n27_), .B(p5), .C(p1), .Y(new_n116_));
  NAND3x1_ASAP7_75t_R  g098(.A(new_n115_), .B(new_n116_), .C(new_n45_), .Y(new_n117_));
  OA21x2_ASAP7_75t_R   g099(.A1(new_n45_), .A2(new_n113_), .B(new_n29_), .Y(new_n118_));
  AND2x2_ASAP7_75t_R   g100(.A(p5), .B(p6), .Y(new_n119_));
  NAND2x1_ASAP7_75t_R  g101(.A(p3), .B(p4), .Y(new_n120_));
  AND3x1_ASAP7_75t_R   g102(.A(p3), .B(p2), .C(p4), .Y(new_n121_));
  AO22x1_ASAP7_75t_R   g103(.A1(new_n119_), .A2(new_n120_), .B1(new_n121_), .B2(new_n59_), .Y(new_n122_));
  AOI221x1_ASAP7_75t_R g104(.A1(new_n91_), .A2(new_n114_), .B1(new_n117_), .B2(new_n118_), .C(new_n122_), .Y(new_n123_));
  OAI21x1_ASAP7_75t_R  g105(.A1(new_n104_), .A2(new_n112_), .B(new_n123_), .Y(new_n124_));
  OAI21x1_ASAP7_75t_R  g106(.A1(new_n59_), .A2(new_n114_), .B(p7), .Y(new_n125_));
  OR3x1_ASAP7_75t_R    g107(.A(new_n54_), .B(new_n27_), .C(p7), .Y(new_n126_));
  NAND2x1_ASAP7_75t_R  g108(.A(new_n86_), .B(new_n126_), .Y(new_n127_));
  OR3x1_ASAP7_75t_R    g109(.A(new_n42_), .B(new_n27_), .C(p9), .Y(new_n128_));
  OA21x2_ASAP7_75t_R   g110(.A1(p7), .A2(p9), .B(p8), .Y(new_n129_));
  AOI22x1_ASAP7_75t_R  g111(.A1(new_n127_), .A2(new_n119_), .B1(new_n128_), .B2(new_n129_), .Y(new_n130_));
  OAI21x1_ASAP7_75t_R  g112(.A1(p9), .A2(new_n125_), .B(new_n130_), .Y(new_n131_));
  AO21x1_ASAP7_75t_R   g113(.A1(new_n38_), .A2(new_n124_), .B(new_n131_), .Y(o2));
  NAND2x1_ASAP7_75t_R  g114(.A(new_n42_), .B(new_n27_), .Y(new_n133_));
  OR3x1_ASAP7_75t_R    g115(.A(p5), .B(p3), .C(p7), .Y(new_n134_));
  NAND2x1_ASAP7_75t_R  g116(.A(p5), .B(p4), .Y(new_n135_));
  OR3x1_ASAP7_75t_R    g117(.A(new_n135_), .B(new_n29_), .C(new_n42_), .Y(new_n136_));
  OR3x1_ASAP7_75t_R    g118(.A(new_n136_), .B(new_n22_), .C(p1), .Y(new_n137_));
  OA21x2_ASAP7_75t_R   g119(.A1(new_n133_), .A2(new_n134_), .B(new_n137_), .Y(new_n138_));
  OR3x1_ASAP7_75t_R    g120(.A(new_n138_), .B(p2), .C(new_n39_), .Y(o3));
  OA21x2_ASAP7_75t_R   g121(.A1(p6), .A2(new_n76_), .B(new_n29_), .Y(new_n140_));
  OA21x2_ASAP7_75t_R   g122(.A1(new_n22_), .A2(new_n133_), .B(new_n140_), .Y(new_n141_));
  OR3x1_ASAP7_75t_R    g123(.A(new_n30_), .B(new_n91_), .C(p6), .Y(new_n142_));
  AO21x1_ASAP7_75t_R   g124(.A1(new_n135_), .A2(new_n142_), .B(new_n33_), .Y(new_n143_));
  NAND2x1_ASAP7_75t_R  g125(.A(new_n141_), .B(new_n143_), .Y(new_n144_));
  AND3x1_ASAP7_75t_R   g126(.A(new_n83_), .B(p0), .C(p10), .Y(new_n145_));
  AND3x1_ASAP7_75t_R   g127(.A(new_n29_), .B(p2), .C(p1), .Y(new_n146_));
  OAI21x1_ASAP7_75t_R  g128(.A1(new_n145_), .A2(new_n114_), .B(new_n146_), .Y(new_n147_));
  NOR2x1_ASAP7_75t_R   g129(.A(p7), .B(new_n31_), .Y(new_n148_));
  OR5x1_ASAP7_75t_R    g130(.A(p8), .B(new_n148_), .C(new_n53_), .D(new_n87_), .E(new_n120_), .Y(new_n149_));
  NAND2x1_ASAP7_75t_R  g131(.A(p8), .B(new_n136_), .Y(new_n150_));
  AND3x1_ASAP7_75t_R   g132(.A(new_n147_), .B(new_n149_), .C(new_n150_), .Y(new_n151_));
  AO21x1_ASAP7_75t_R   g133(.A1(new_n144_), .A2(new_n151_), .B(p9), .Y(o4));
  OR3x1_ASAP7_75t_R    g134(.A(new_n133_), .B(p7), .C(new_n31_), .Y(new_n153_));
  OAI22x1_ASAP7_75t_R  g135(.A1(new_n153_), .A2(new_n81_), .B1(new_n53_), .B2(new_n136_), .Y(new_n154_));
  OR3x1_ASAP7_75t_R    g136(.A(new_n83_), .B(p7), .C(p6), .Y(new_n155_));
  AND3x1_ASAP7_75t_R   g137(.A(new_n45_), .B(new_n113_), .C(p1), .Y(new_n156_));
  OAI21x1_ASAP7_75t_R  g138(.A1(new_n155_), .A2(new_n156_), .B(new_n38_), .Y(new_n157_));
  AO21x1_ASAP7_75t_R   g139(.A1(p3), .A2(new_n154_), .B(new_n157_), .Y(o5));
  OR4x2_ASAP7_75t_R    g140(.A(new_n156_), .B(p7), .C(p6), .D(new_n39_), .Y(o6));
endmodule


