// Benchmark "/tmp/" written by ABC on Tue Oct 20 17:46:14 2026

module \/tmp/  ( 
    p2, p4, p5, p0, p7, p8, p3, p10, p1, p9, p6,
    o0, o1, o2, o3, o4, o5, o6  );
  input  p2, p4, p5, p0, p7, p8, p3, p10, p1, p9, p6;
  output o0, o1, o2, o3, o4, o5, o6;
  wire new_n19_, new_n20_, new_n21_, new_n22_, new_n23_, new_n24_, new_n25_,
    new_n26_, new_n27_, new_n28_, new_n29_, new_n30_, new_n31_, new_n32_,
    new_n33_, new_n34_, new_n35_, new_n36_, new_n37_, new_n38_, new_n39_,
    new_n40_, new_n41_, new_n42_, new_n43_, new_n44_, new_n45_, new_n46_,
    new_n47_, new_n48_, new_n49_, new_n50_, new_n51_, new_n52_, new_n53_,
    new_n54_, new_n55_, new_n56_, new_n57_, new_n58_, new_n59_, new_n60_,
    new_n61_, new_n62_, new_n63_, new_n65_, new_n66_, new_n67_, new_n68_,
    new_n69_, new_n70_, new_n71_, new_n72_, new_n73_, new_n74_, new_n75_,
    new_n76_, new_n77_, new_n78_, new_n79_, new_n80_, new_n81_, new_n82_,
    new_n83_, new_n84_, new_n85_, new_n86_, new_n87_, new_n88_, new_n89_,
    new_n90_, new_n91_, new_n92_, new_n93_, new_n94_, new_n95_, new_n96_,
    new_n97_, new_n98_, new_n99_, new_n100_, new_n101_, new_n103_,
    new_n104_, new_n105_, new_n106_, new_n107_, new_n108_, new_n109_,
    new_n110_, new_n111_, new_n112_, new_n113_, new_n114_, new_n115_,
    new_n116_, new_n117_, new_n118_, new_n119_, new_n120_, new_n121_,
    new_n122_, new_n123_, new_n124_, new_n125_, new_n126_, new_n127_,
    new_n128_, new_n129_, new_n130_, new_n131_, new_n132_, new_n134_,
    new_n135_, new_n136_, new_n138_, new_n139_, new_n140_, new_n141_,
    new_n142_, new_n143_, new_n144_, new_n145_, new_n146_, new_n147_,
    new_n148_, new_n150_, new_n151_, new_n152_, new_n153_, new_n154_;
  NOR2x1_ASAP7_75t_R   g000(.A(p8), .B(p9), .Y(new_n19_));
  INVx1_ASAP7_75t_R    g001(.A(new_n19_), .Y(new_n20_));
  INVx1_ASAP7_75t_R    g002(.A(p4), .Y(new_n21_));
  AND2x2_ASAP7_75t_R   g003(.A(p0), .B(p3), .Y(new_n22_));
  NOR2x1_ASAP7_75t_R   g004(.A(p5), .B(p6), .Y(new_n23_));
  OA21x2_ASAP7_75t_R   g005(.A1(p10), .A2(new_n22_), .B(new_n23_), .Y(new_n24_));
  INVx1_ASAP7_75t_R    g006(.A(p7), .Y(new_n25_));
  NOR2x1_ASAP7_75t_R   g007(.A(p3), .B(new_n25_), .Y(new_n26_));
  OAI21x1_ASAP7_75t_R  g008(.A1(new_n22_), .A2(new_n26_), .B(p10), .Y(new_n27_));
  AND2x2_ASAP7_75t_R   g009(.A(p7), .B(p3), .Y(new_n28_));
  AO21x1_ASAP7_75t_R   g010(.A1(new_n24_), .A2(new_n27_), .B(new_n28_), .Y(new_n29_));
  NOR2x1_ASAP7_75t_R   g011(.A(p1), .B(p6), .Y(new_n30_));
  AND3x1_ASAP7_75t_R   g012(.A(p2), .B(p4), .C(p0), .Y(new_n31_));
  INVx1_ASAP7_75t_R    g013(.A(p6), .Y(new_n32_));
  NOR2x1_ASAP7_75t_R   g014(.A(p3), .B(new_n32_), .Y(new_n33_));
  INVx1_ASAP7_75t_R    g015(.A(p2), .Y(new_n34_));
  AND3x1_ASAP7_75t_R   g016(.A(new_n34_), .B(p3), .C(p6), .Y(new_n35_));
  AOI221x1_ASAP7_75t_R g017(.A1(new_n30_), .A2(new_n31_), .B1(p2), .B2(new_n33_), .C(new_n35_), .Y(new_n36_));
  OR3x1_ASAP7_75t_R    g018(.A(new_n21_), .B(new_n25_), .C(p3), .Y(new_n37_));
  OAI21x1_ASAP7_75t_R  g019(.A1(p7), .A2(new_n36_), .B(new_n37_), .Y(new_n38_));
  AOI21x1_ASAP7_75t_R  g020(.A1(new_n21_), .A2(new_n29_), .B(new_n38_), .Y(new_n39_));
  NOR2x1_ASAP7_75t_R   g021(.A(p5), .B(new_n21_), .Y(new_n40_));
  INVx1_ASAP7_75t_R    g022(.A(new_n40_), .Y(new_n41_));
  INVx1_ASAP7_75t_R    g023(.A(p0), .Y(new_n42_));
  AND2x2_ASAP7_75t_R   g024(.A(p2), .B(p3), .Y(new_n43_));
  OR5x1_ASAP7_75t_R    g025(.A(new_n42_), .B(new_n33_), .C(p1), .D(new_n28_), .E(new_n43_), .Y(new_n44_));
  NOR2x1_ASAP7_75t_R   g026(.A(p7), .B(p6), .Y(new_n45_));
  AO31x2_ASAP7_75t_R   g027(.A1(new_n45_), .A2(new_n42_), .A3(p1), .B(p8), .Y(new_n46_));
  AND3x1_ASAP7_75t_R   g028(.A(new_n21_), .B(p5), .C(p8), .Y(new_n47_));
  AOI21x1_ASAP7_75t_R  g029(.A1(new_n40_), .A2(new_n46_), .B(new_n47_), .Y(new_n48_));
  OAI21x1_ASAP7_75t_R  g030(.A1(new_n41_), .A2(new_n44_), .B(new_n48_), .Y(new_n49_));
  INVx1_ASAP7_75t_R    g031(.A(p9), .Y(new_n50_));
  NOR2x1_ASAP7_75t_R   g032(.A(p2), .B(p1), .Y(new_n51_));
  INVx1_ASAP7_75t_R    g033(.A(new_n51_), .Y(new_n52_));
  INVx1_ASAP7_75t_R    g034(.A(p8), .Y(new_n53_));
  NAND2x1_ASAP7_75t_R  g035(.A(new_n25_), .B(new_n53_), .Y(new_n54_));
  AOI21x1_ASAP7_75t_R  g036(.A1(p2), .A2(p1), .B(new_n54_), .Y(new_n55_));
  AO21x1_ASAP7_75t_R   g037(.A1(new_n52_), .A2(new_n55_), .B(p9), .Y(new_n56_));
  NAND2x1_ASAP7_75t_R  g038(.A(p5), .B(new_n32_), .Y(new_n57_));
  INVx1_ASAP7_75t_R    g039(.A(p5), .Y(new_n58_));
  NAND2x1_ASAP7_75t_R  g040(.A(p6), .B(new_n58_), .Y(new_n59_));
  OR3x1_ASAP7_75t_R    g041(.A(new_n58_), .B(new_n25_), .C(new_n53_), .Y(new_n60_));
  AO21x1_ASAP7_75t_R   g042(.A1(new_n59_), .A2(new_n60_), .B(new_n50_), .Y(new_n61_));
  NAND2x1_ASAP7_75t_R  g043(.A(new_n57_), .B(new_n61_), .Y(new_n62_));
  AOI22x1_ASAP7_75t_R  g044(.A1(new_n49_), .A2(new_n50_), .B1(new_n56_), .B2(new_n62_), .Y(new_n63_));
  OAI21x1_ASAP7_75t_R  g045(.A1(new_n20_), .A2(new_n39_), .B(new_n63_), .Y(o0));
  NAND2x1_ASAP7_75t_R  g046(.A(p0), .B(p1), .Y(new_n65_));
  NAND2x1_ASAP7_75t_R  g047(.A(p3), .B(new_n32_), .Y(new_n66_));
  INVx1_ASAP7_75t_R    g048(.A(p1), .Y(new_n67_));
  NOR2x1_ASAP7_75t_R   g049(.A(p10), .B(new_n67_), .Y(new_n68_));
  AOI211x1_ASAP7_75t_R g050(.A1(p10), .A2(new_n65_), .B(new_n66_), .C(new_n68_), .Y(new_n69_));
  NOR2x1_ASAP7_75t_R   g051(.A(p8), .B(p3), .Y(new_n70_));
  NOR2x1_ASAP7_75t_R   g052(.A(new_n30_), .B(new_n70_), .Y(new_n71_));
  OAI22x1_ASAP7_75t_R  g053(.A1(new_n71_), .A2(p0), .B1(new_n25_), .B2(p8), .Y(new_n72_));
  NOR2x1_ASAP7_75t_R   g054(.A(p4), .B(p5), .Y(new_n73_));
  OAI21x1_ASAP7_75t_R  g055(.A1(new_n69_), .A2(new_n72_), .B(new_n73_), .Y(new_n74_));
  NAND2x1_ASAP7_75t_R  g056(.A(p2), .B(p3), .Y(new_n75_));
  NAND2x1_ASAP7_75t_R  g057(.A(p6), .B(new_n75_), .Y(new_n76_));
  NAND2x1_ASAP7_75t_R  g058(.A(p8), .B(new_n32_), .Y(new_n77_));
  OAI21x1_ASAP7_75t_R  g059(.A1(new_n54_), .A2(new_n76_), .B(new_n77_), .Y(new_n78_));
  NOR2x1_ASAP7_75t_R   g060(.A(p5), .B(p3), .Y(new_n79_));
  AO32x1_ASAP7_75t_R   g061(.A1(new_n25_), .A2(new_n53_), .A3(p3), .B1(new_n79_), .B2(new_n32_), .Y(new_n80_));
  AOI211x1_ASAP7_75t_R g062(.A1(new_n32_), .A2(new_n65_), .B(new_n34_), .C(new_n21_), .Y(new_n81_));
  AOI22x1_ASAP7_75t_R  g063(.A1(new_n78_), .A2(new_n21_), .B1(new_n80_), .B2(new_n81_), .Y(new_n82_));
  INVx1_ASAP7_75t_R    g064(.A(new_n70_), .Y(new_n83_));
  AOI21x1_ASAP7_75t_R  g065(.A1(new_n77_), .A2(new_n83_), .B(p5), .Y(new_n84_));
  AND2x2_ASAP7_75t_R   g066(.A(p4), .B(p5), .Y(new_n85_));
  AND3x1_ASAP7_75t_R   g067(.A(new_n83_), .B(new_n77_), .C(new_n85_), .Y(new_n86_));
  OAI21x1_ASAP7_75t_R  g068(.A1(new_n84_), .A2(new_n86_), .B(new_n54_), .Y(new_n87_));
  NAND3x1_ASAP7_75t_R  g069(.A(new_n74_), .B(new_n82_), .C(new_n87_), .Y(new_n88_));
  AO21x1_ASAP7_75t_R   g070(.A1(p5), .A2(p6), .B(p7), .Y(new_n89_));
  AO21x1_ASAP7_75t_R   g071(.A1(new_n50_), .A2(p6), .B(new_n89_), .Y(new_n90_));
  NOR3x1_ASAP7_75t_R   g072(.A(new_n58_), .B(p8), .C(p3), .Y(new_n91_));
  NOR3x1_ASAP7_75t_R   g073(.A(new_n21_), .B(p5), .C(p0), .Y(new_n92_));
  OAI21x1_ASAP7_75t_R  g074(.A1(new_n91_), .A2(new_n92_), .B(new_n34_), .Y(new_n93_));
  NAND2x1_ASAP7_75t_R  g075(.A(new_n67_), .B(new_n91_), .Y(new_n94_));
  OR4x2_ASAP7_75t_R    g076(.A(new_n75_), .B(new_n58_), .C(p8), .D(new_n67_), .Y(new_n95_));
  NAND2x1_ASAP7_75t_R  g077(.A(new_n51_), .B(new_n40_), .Y(new_n96_));
  AND5x1_ASAP7_75t_R   g078(.A(new_n93_), .B(new_n50_), .C(new_n94_), .D(new_n95_), .E(new_n96_), .Y(new_n97_));
  AND2x2_ASAP7_75t_R   g079(.A(p5), .B(p6), .Y(new_n98_));
  AND3x1_ASAP7_75t_R   g080(.A(new_n98_), .B(p7), .C(p9), .Y(new_n99_));
  NAND2x1_ASAP7_75t_R  g081(.A(new_n53_), .B(new_n99_), .Y(new_n100_));
  OAI21x1_ASAP7_75t_R  g082(.A1(new_n90_), .A2(new_n97_), .B(new_n100_), .Y(new_n101_));
  AOI21x1_ASAP7_75t_R  g083(.A1(new_n50_), .A2(new_n88_), .B(new_n101_), .Y(o1));
  AND3x1_ASAP7_75t_R   g084(.A(new_n25_), .B(new_n53_), .C(new_n50_), .Y(new_n103_));
  NAND2x1_ASAP7_75t_R  g085(.A(new_n58_), .B(new_n67_), .Y(new_n104_));
  NAND2x1_ASAP7_75t_R  g086(.A(p3), .B(new_n34_), .Y(new_n105_));
  OAI22x1_ASAP7_75t_R  g087(.A1(new_n104_), .A2(new_n75_), .B1(new_n105_), .B2(new_n21_), .Y(new_n106_));
  OAI21x1_ASAP7_75t_R  g088(.A1(p1), .A2(new_n106_), .B(new_n32_), .Y(new_n107_));
  AND2x2_ASAP7_75t_R   g089(.A(p0), .B(p10), .Y(new_n108_));
  OAI22x1_ASAP7_75t_R  g090(.A1(new_n108_), .A2(new_n75_), .B1(p5), .B2(p3), .Y(new_n109_));
  NAND2x1_ASAP7_75t_R  g091(.A(p10), .B(new_n58_), .Y(new_n110_));
  INVx1_ASAP7_75t_R    g092(.A(p3), .Y(new_n111_));
  NAND3x1_ASAP7_75t_R  g093(.A(new_n111_), .B(p2), .C(p4), .Y(new_n112_));
  OAI21x1_ASAP7_75t_R  g094(.A1(new_n105_), .A2(new_n110_), .B(new_n112_), .Y(new_n113_));
  AOI221x1_ASAP7_75t_R g095(.A1(new_n21_), .A2(new_n109_), .B1(new_n113_), .B2(p0), .C(new_n106_), .Y(new_n114_));
  AND3x1_ASAP7_75t_R   g096(.A(new_n21_), .B(p5), .C(p1), .Y(new_n115_));
  OR3x1_ASAP7_75t_R    g097(.A(new_n115_), .B(new_n92_), .C(new_n75_), .Y(new_n116_));
  OAI21x1_ASAP7_75t_R  g098(.A1(new_n43_), .A2(new_n85_), .B(new_n116_), .Y(new_n117_));
  OAI21x1_ASAP7_75t_R  g099(.A1(new_n107_), .A2(new_n114_), .B(new_n117_), .Y(new_n118_));
  NAND2x1_ASAP7_75t_R  g100(.A(p4), .B(p3), .Y(new_n119_));
  INVx1_ASAP7_75t_R    g101(.A(new_n119_), .Y(new_n120_));
  AND3x1_ASAP7_75t_R   g102(.A(new_n58_), .B(p2), .C(p6), .Y(new_n121_));
  NOR2x1_ASAP7_75t_R   g103(.A(new_n119_), .B(new_n57_), .Y(new_n122_));
  AND3x1_ASAP7_75t_R   g104(.A(new_n119_), .B(p5), .C(p6), .Y(new_n123_));
  AOI221x1_ASAP7_75t_R g105(.A1(new_n120_), .A2(new_n121_), .B1(new_n122_), .B2(new_n67_), .C(new_n123_), .Y(new_n124_));
  OAI21x1_ASAP7_75t_R  g106(.A1(new_n119_), .A2(new_n57_), .B(new_n59_), .Y(new_n125_));
  NOR2x1_ASAP7_75t_R   g107(.A(p9), .B(new_n25_), .Y(new_n126_));
  AND3x1_ASAP7_75t_R   g108(.A(p4), .B(p5), .C(p6), .Y(new_n127_));
  OR3x1_ASAP7_75t_R    g109(.A(new_n127_), .B(p7), .C(p9), .Y(new_n128_));
  AND2x2_ASAP7_75t_R   g110(.A(p4), .B(p6), .Y(new_n129_));
  AOI21x1_ASAP7_75t_R  g111(.A1(new_n129_), .A2(new_n126_), .B(new_n53_), .Y(new_n130_));
  AOI221x1_ASAP7_75t_R g112(.A1(new_n125_), .A2(new_n126_), .B1(new_n128_), .B2(new_n130_), .C(new_n99_), .Y(new_n131_));
  OAI21x1_ASAP7_75t_R  g113(.A1(new_n20_), .A2(new_n124_), .B(new_n131_), .Y(new_n132_));
  AO21x1_ASAP7_75t_R   g114(.A1(new_n103_), .A2(new_n118_), .B(new_n132_), .Y(o2));
  AND3x1_ASAP7_75t_R   g115(.A(new_n45_), .B(new_n73_), .C(new_n111_), .Y(new_n134_));
  AND3x1_ASAP7_75t_R   g116(.A(new_n127_), .B(new_n28_), .C(new_n67_), .Y(new_n135_));
  NOR2x1_ASAP7_75t_R   g117(.A(new_n134_), .B(new_n135_), .Y(new_n136_));
  OR3x1_ASAP7_75t_R    g118(.A(new_n136_), .B(p2), .C(new_n20_), .Y(o3));
  NAND2x1_ASAP7_75t_R  g119(.A(p7), .B(new_n127_), .Y(new_n138_));
  AO32x1_ASAP7_75t_R   g120(.A1(new_n85_), .A2(p3), .A3(new_n32_), .B1(new_n108_), .B2(new_n73_), .Y(new_n139_));
  AND3x1_ASAP7_75t_R   g121(.A(new_n25_), .B(p2), .C(p1), .Y(new_n140_));
  NAND2x1_ASAP7_75t_R  g122(.A(p2), .B(new_n25_), .Y(new_n141_));
  AND3x1_ASAP7_75t_R   g123(.A(p4), .B(p3), .C(p6), .Y(new_n142_));
  AND5x1_ASAP7_75t_R   g124(.A(p5), .B(new_n52_), .C(new_n141_), .D(new_n53_), .E(new_n142_), .Y(new_n143_));
  AO221x2_ASAP7_75t_R  g125(.A1(p8), .A2(new_n138_), .B1(new_n139_), .B2(new_n140_), .C(new_n143_), .Y(new_n144_));
  NOR2x1_ASAP7_75t_R   g126(.A(p6), .B(new_n65_), .Y(new_n145_));
  OAI21x1_ASAP7_75t_R  g127(.A1(new_n85_), .A2(new_n145_), .B(new_n43_), .Y(new_n146_));
  OR3x1_ASAP7_75t_R    g128(.A(new_n111_), .B(p4), .C(p6), .Y(new_n147_));
  AND5x1_ASAP7_75t_R   g129(.A(new_n25_), .B(new_n146_), .C(new_n50_), .D(new_n57_), .E(new_n147_), .Y(new_n148_));
  AOI21x1_ASAP7_75t_R  g130(.A1(new_n50_), .A2(new_n144_), .B(new_n148_), .Y(o4));
  AND3x1_ASAP7_75t_R   g131(.A(new_n108_), .B(new_n21_), .C(new_n32_), .Y(new_n150_));
  AO32x1_ASAP7_75t_R   g132(.A1(p7), .A2(new_n52_), .A3(new_n127_), .B1(new_n150_), .B2(new_n140_), .Y(new_n151_));
  OR3x1_ASAP7_75t_R    g133(.A(new_n73_), .B(p7), .C(p6), .Y(new_n152_));
  AND3x1_ASAP7_75t_R   g134(.A(new_n43_), .B(new_n85_), .C(p1), .Y(new_n153_));
  OAI21x1_ASAP7_75t_R  g135(.A1(new_n152_), .A2(new_n153_), .B(new_n19_), .Y(new_n154_));
  AO21x1_ASAP7_75t_R   g136(.A1(p3), .A2(new_n151_), .B(new_n154_), .Y(o5));
  OR4x2_ASAP7_75t_R    g137(.A(new_n153_), .B(p7), .C(p6), .D(new_n20_), .Y(o6));
endmodule


