// Benchmark "/tmp/" written by ABC on Tue Oct 20 17:46:18 2026

module \/tmp/  ( 
    p8, p10, p3, p9, p1, p6, p5, p2, p7, p4, p0,
    o0, o1, o2, o3, o4, o5, o6  );
  input  p8, p10, p3, p9, p1, p6, p5, p2, p7, p4, p0;
  output o0, o1, o2, o3, o4, o5, o6;
  wire new_n19_, new_n20_, new_n21_, new_n22_, new_n23_, new_n24_, new_n25_,
    new_n26_, new_n27_, new_n28_, new_n29_, new_n30_, new_n31_, new_n32_,
    new_n33_, new_n34_, new_n35_, new_n36_, new_n37_, new_n38_, new_n39_,
    new_n40_, new_n41_, new_n42_, new_n43_, new_n44_, new_n45_, new_n46_,
    new_n47_, new_n48_, new_n49_, new_n50_, new_n51_, new_n52_, new_n53_,
    new_n54_, new_n55_, new_n56_, new_n57_, new_n58_, new_n59_, new_n60_,
    new_n61_, new_n62_, new_n63_, new_n65_, new_n66_, new_n67_, new_n68_,
    new_n69_, new_n70_, new_n71_, new_n72_, new_n73_, new_n74_, new_n75_,
    new_n76_, new_n77_, new_n78_, new_n79_, new_n80_, new_n81_, new_n82_,
    new_n83_, new_n84_, new_n85_, new_n86_, new_n87_, new_n88_, new_n89_,
    new_n90_, new_n91_, new_n92_, new_n93_, new_n94_, new_n95_, new_n96_,
    new_n97_, new_n98_, new_n99_, new_n100_, new_n102_, new_n103_,
    new_n104_, new_n105_, new_n106_, new_n107_, new_n108_, new_n109_,
    new_n110_, new_n111_, new_n112_, new_n113_, new_n114_, new_n115_,
    new_n116_, new_n117_, new_n118_, new_n119_, new_n120_, new_n121_,
    new_n122_, new_n123_, new_n124_, new_n125_, new_n126_, new_n127_,
    new_n128_, new_n129_, new_n130_, new_n131_, new_n132_, new_n133_,
    new_n135_, new_n136_, new_n137_, new_n138_, new_n139_, new_n141_,
    new_n142_, new_n143_, new_n144_, new_n145_, new_n146_, new_n147_,
    new_n148_, new_n149_, new_n150_, new_n152_, new_n153_, new_n154_,
    new_n155_, new_n156_;
  NAND2x1_ASAP7_75t_R  g000(.A(p3), .B(p0), .Y(new_n19_));
  INVx1_ASAP7_75t_R    g001(.A(p3), .Y(new_n20_));
  NAND2x1_ASAP7_75t_R  g002(.A(p7), .B(new_n20_), .Y(new_n21_));
  INVx1_ASAP7_75t_R    g003(.A(p10), .Y(new_n22_));
  AOI21x1_ASAP7_75t_R  g004(.A1(new_n19_), .A2(new_n21_), .B(new_n22_), .Y(new_n23_));
  INVx1_ASAP7_75t_R    g005(.A(p6), .Y(new_n24_));
  INVx1_ASAP7_75t_R    g006(.A(p5), .Y(new_n25_));
  NAND2x1_ASAP7_75t_R  g007(.A(new_n24_), .B(new_n25_), .Y(new_n26_));
  AO21x1_ASAP7_75t_R   g008(.A1(new_n22_), .A2(new_n19_), .B(new_n26_), .Y(new_n27_));
  INVx1_ASAP7_75t_R    g009(.A(p7), .Y(new_n28_));
  INVx1_ASAP7_75t_R    g010(.A(p4), .Y(new_n29_));
  OA21x2_ASAP7_75t_R   g011(.A1(new_n20_), .A2(new_n28_), .B(new_n29_), .Y(new_n30_));
  OAI21x1_ASAP7_75t_R  g012(.A1(new_n23_), .A2(new_n27_), .B(new_n30_), .Y(new_n31_));
  AO21x1_ASAP7_75t_R   g013(.A1(p7), .A2(new_n20_), .B(new_n29_), .Y(new_n32_));
  INVx1_ASAP7_75t_R    g014(.A(p2), .Y(new_n33_));
  INVx1_ASAP7_75t_R    g015(.A(p0), .Y(new_n34_));
  OR5x1_ASAP7_75t_R    g016(.A(p1), .B(new_n33_), .C(new_n29_), .D(new_n34_), .E(p6), .Y(new_n35_));
  NAND2x1_ASAP7_75t_R  g017(.A(p3), .B(p2), .Y(new_n36_));
  NAND2x1_ASAP7_75t_R  g018(.A(p6), .B(new_n36_), .Y(new_n37_));
  AO21x1_ASAP7_75t_R   g019(.A1(new_n20_), .A2(new_n33_), .B(new_n37_), .Y(new_n38_));
  AOI21x1_ASAP7_75t_R  g020(.A1(new_n35_), .A2(new_n38_), .B(p7), .Y(new_n39_));
  AOI21x1_ASAP7_75t_R  g021(.A1(new_n31_), .A2(new_n32_), .B(new_n39_), .Y(new_n40_));
  NOR2x1_ASAP7_75t_R   g022(.A(p8), .B(p9), .Y(new_n41_));
  INVx1_ASAP7_75t_R    g023(.A(new_n41_), .Y(new_n42_));
  INVx1_ASAP7_75t_R    g024(.A(p9), .Y(new_n43_));
  AOI211x1_ASAP7_75t_R g025(.A1(p6), .A2(new_n20_), .B(p1), .C(new_n34_), .Y(new_n44_));
  AO21x1_ASAP7_75t_R   g026(.A1(new_n33_), .A2(new_n28_), .B(new_n20_), .Y(new_n45_));
  NOR2x1_ASAP7_75t_R   g027(.A(p5), .B(new_n29_), .Y(new_n46_));
  NAND3x1_ASAP7_75t_R  g028(.A(new_n44_), .B(new_n45_), .C(new_n46_), .Y(new_n47_));
  NOR2x1_ASAP7_75t_R   g029(.A(p6), .B(p7), .Y(new_n48_));
  AO31x2_ASAP7_75t_R   g030(.A1(new_n48_), .A2(p1), .A3(new_n34_), .B(p8), .Y(new_n49_));
  AND3x1_ASAP7_75t_R   g031(.A(new_n29_), .B(p8), .C(p5), .Y(new_n50_));
  AOI21x1_ASAP7_75t_R  g032(.A1(new_n46_), .A2(new_n49_), .B(new_n50_), .Y(new_n51_));
  NAND2x1_ASAP7_75t_R  g033(.A(new_n47_), .B(new_n51_), .Y(new_n52_));
  NAND2x1_ASAP7_75t_R  g034(.A(p5), .B(new_n24_), .Y(new_n53_));
  NOR2x1_ASAP7_75t_R   g035(.A(p1), .B(p2), .Y(new_n54_));
  AND2x2_ASAP7_75t_R   g036(.A(p1), .B(p2), .Y(new_n55_));
  INVx1_ASAP7_75t_R    g037(.A(p8), .Y(new_n56_));
  NAND2x1_ASAP7_75t_R  g038(.A(new_n56_), .B(new_n28_), .Y(new_n57_));
  OA31x2_ASAP7_75t_R   g039(.A1(new_n54_), .A2(new_n55_), .A3(new_n57_), .B1(new_n43_), .Y(new_n58_));
  NOR2x1_ASAP7_75t_R   g040(.A(p5), .B(new_n24_), .Y(new_n59_));
  AND3x1_ASAP7_75t_R   g041(.A(p8), .B(p9), .C(p7), .Y(new_n60_));
  AOI22x1_ASAP7_75t_R  g042(.A1(new_n59_), .A2(p9), .B1(p5), .B2(new_n60_), .Y(new_n61_));
  OAI21x1_ASAP7_75t_R  g043(.A1(new_n53_), .A2(new_n58_), .B(new_n61_), .Y(new_n62_));
  AOI21x1_ASAP7_75t_R  g044(.A1(new_n43_), .A2(new_n52_), .B(new_n62_), .Y(new_n63_));
  OAI21x1_ASAP7_75t_R  g045(.A1(new_n40_), .A2(new_n42_), .B(new_n63_), .Y(o0));
  NAND2x1_ASAP7_75t_R  g046(.A(p8), .B(new_n24_), .Y(new_n65_));
  OAI21x1_ASAP7_75t_R  g047(.A1(new_n57_), .A2(new_n37_), .B(new_n65_), .Y(new_n66_));
  OAI21x1_ASAP7_75t_R  g048(.A1(p6), .A2(p5), .B(new_n20_), .Y(new_n67_));
  OAI21x1_ASAP7_75t_R  g049(.A1(p8), .A2(p7), .B(p3), .Y(new_n68_));
  AO21x1_ASAP7_75t_R   g050(.A1(p1), .A2(p0), .B(p6), .Y(new_n69_));
  AND5x1_ASAP7_75t_R   g051(.A(p2), .B(new_n67_), .C(p4), .D(new_n68_), .E(new_n69_), .Y(new_n70_));
  AOI21x1_ASAP7_75t_R  g052(.A1(new_n29_), .A2(new_n66_), .B(new_n70_), .Y(new_n71_));
  NOR2x1_ASAP7_75t_R   g053(.A(p3), .B(p0), .Y(new_n72_));
  OA21x2_ASAP7_75t_R   g054(.A1(p7), .A2(new_n72_), .B(new_n56_), .Y(new_n73_));
  NAND3x1_ASAP7_75t_R  g055(.A(p10), .B(p1), .C(p0), .Y(new_n74_));
  AO21x1_ASAP7_75t_R   g056(.A1(p10), .A2(p0), .B(p1), .Y(new_n75_));
  NOR2x1_ASAP7_75t_R   g057(.A(p3), .B(new_n34_), .Y(new_n76_));
  AOI211x1_ASAP7_75t_R g058(.A1(new_n74_), .A2(new_n75_), .B(p6), .C(new_n76_), .Y(new_n77_));
  NOR2x1_ASAP7_75t_R   g059(.A(p5), .B(p4), .Y(new_n78_));
  OAI21x1_ASAP7_75t_R  g060(.A1(new_n73_), .A2(new_n77_), .B(new_n78_), .Y(new_n79_));
  NAND2x1_ASAP7_75t_R  g061(.A(new_n56_), .B(new_n20_), .Y(new_n80_));
  AO21x1_ASAP7_75t_R   g062(.A1(new_n65_), .A2(new_n80_), .B(new_n25_), .Y(new_n81_));
  NAND2x1_ASAP7_75t_R  g063(.A(p5), .B(p4), .Y(new_n82_));
  NAND3x1_ASAP7_75t_R  g064(.A(new_n80_), .B(new_n65_), .C(new_n82_), .Y(new_n83_));
  NAND3x1_ASAP7_75t_R  g065(.A(new_n81_), .B(new_n57_), .C(new_n83_), .Y(new_n84_));
  NAND3x1_ASAP7_75t_R  g066(.A(new_n71_), .B(new_n79_), .C(new_n84_), .Y(new_n85_));
  AO21x1_ASAP7_75t_R   g067(.A1(p6), .A2(p5), .B(p7), .Y(new_n86_));
  AO21x1_ASAP7_75t_R   g068(.A1(new_n43_), .A2(p6), .B(new_n86_), .Y(new_n87_));
  NOR2x1_ASAP7_75t_R   g069(.A(p5), .B(p2), .Y(new_n88_));
  AO32x1_ASAP7_75t_R   g070(.A1(new_n56_), .A2(new_n20_), .A3(p5), .B1(new_n88_), .B2(p4), .Y(new_n89_));
  INVx1_ASAP7_75t_R    g071(.A(p1), .Y(new_n90_));
  NOR2x1_ASAP7_75t_R   g072(.A(p5), .B(p0), .Y(new_n91_));
  AO32x1_ASAP7_75t_R   g073(.A1(new_n56_), .A2(new_n20_), .A3(p5), .B1(new_n91_), .B2(p4), .Y(new_n92_));
  AND3x1_ASAP7_75t_R   g074(.A(p3), .B(p1), .C(p2), .Y(new_n93_));
  NOR2x1_ASAP7_75t_R   g075(.A(p8), .B(new_n25_), .Y(new_n94_));
  AO21x1_ASAP7_75t_R   g076(.A1(new_n93_), .A2(new_n94_), .B(p9), .Y(new_n95_));
  AOI221x1_ASAP7_75t_R g077(.A1(new_n89_), .A2(new_n90_), .B1(new_n33_), .B2(new_n92_), .C(new_n95_), .Y(new_n96_));
  NAND2x1_ASAP7_75t_R  g078(.A(p9), .B(p7), .Y(new_n97_));
  NAND2x1_ASAP7_75t_R  g079(.A(p6), .B(p5), .Y(new_n98_));
  OR3x1_ASAP7_75t_R    g080(.A(new_n97_), .B(new_n98_), .C(p8), .Y(new_n99_));
  OAI21x1_ASAP7_75t_R  g081(.A1(new_n87_), .A2(new_n96_), .B(new_n99_), .Y(new_n100_));
  AOI21x1_ASAP7_75t_R  g082(.A1(new_n43_), .A2(new_n85_), .B(new_n100_), .Y(o1));
  NOR2x1_ASAP7_75t_R   g083(.A(p2), .B(new_n29_), .Y(new_n102_));
  NOR3x1_ASAP7_75t_R   g084(.A(new_n33_), .B(p1), .C(p5), .Y(new_n103_));
  OAI21x1_ASAP7_75t_R  g085(.A1(new_n102_), .A2(new_n103_), .B(p3), .Y(new_n104_));
  INVx1_ASAP7_75t_R    g086(.A(new_n48_), .Y(new_n105_));
  AOI21x1_ASAP7_75t_R  g087(.A1(new_n90_), .A2(new_n104_), .B(new_n105_), .Y(new_n106_));
  NOR2x1_ASAP7_75t_R   g088(.A(p3), .B(p5), .Y(new_n107_));
  AOI21x1_ASAP7_75t_R  g089(.A1(p10), .A2(p0), .B(new_n36_), .Y(new_n108_));
  OAI21x1_ASAP7_75t_R  g090(.A1(new_n107_), .A2(new_n108_), .B(new_n29_), .Y(new_n109_));
  NOR3x1_ASAP7_75t_R   g091(.A(new_n20_), .B(p5), .C(p2), .Y(new_n110_));
  AND2x2_ASAP7_75t_R   g092(.A(p10), .B(p0), .Y(new_n111_));
  AND2x2_ASAP7_75t_R   g093(.A(p2), .B(p4), .Y(new_n112_));
  AOI22x1_ASAP7_75t_R  g094(.A1(new_n110_), .A2(new_n111_), .B1(new_n112_), .B2(new_n76_), .Y(new_n113_));
  NAND3x1_ASAP7_75t_R  g095(.A(new_n109_), .B(new_n113_), .C(new_n104_), .Y(new_n114_));
  AO21x1_ASAP7_75t_R   g096(.A1(new_n36_), .A2(new_n82_), .B(p7), .Y(new_n115_));
  AND3x1_ASAP7_75t_R   g097(.A(new_n29_), .B(p1), .C(p5), .Y(new_n116_));
  AOI211x1_ASAP7_75t_R g098(.A1(p4), .A2(new_n91_), .B(new_n36_), .C(new_n116_), .Y(new_n117_));
  AND3x1_ASAP7_75t_R   g099(.A(p3), .B(p2), .C(p4), .Y(new_n118_));
  NOR3x1_ASAP7_75t_R   g100(.A(new_n25_), .B(p1), .C(p6), .Y(new_n119_));
  NAND2x1_ASAP7_75t_R  g101(.A(p3), .B(p4), .Y(new_n120_));
  INVx1_ASAP7_75t_R    g102(.A(new_n120_), .Y(new_n121_));
  AOI21x1_ASAP7_75t_R  g103(.A1(p3), .A2(p4), .B(new_n98_), .Y(new_n122_));
  AOI221x1_ASAP7_75t_R g104(.A1(new_n59_), .A2(new_n118_), .B1(new_n119_), .B2(new_n121_), .C(new_n122_), .Y(new_n123_));
  OAI21x1_ASAP7_75t_R  g105(.A1(new_n115_), .A2(new_n117_), .B(new_n123_), .Y(new_n124_));
  AOI21x1_ASAP7_75t_R  g106(.A1(new_n106_), .A2(new_n114_), .B(new_n124_), .Y(new_n125_));
  NOR2x1_ASAP7_75t_R   g107(.A(new_n120_), .B(new_n53_), .Y(new_n126_));
  OAI21x1_ASAP7_75t_R  g108(.A1(new_n59_), .A2(new_n126_), .B(p7), .Y(new_n127_));
  OR3x1_ASAP7_75t_R    g109(.A(new_n56_), .B(new_n29_), .C(p7), .Y(new_n128_));
  AO21x1_ASAP7_75t_R   g110(.A1(new_n97_), .A2(new_n128_), .B(new_n98_), .Y(new_n129_));
  AND3x1_ASAP7_75t_R   g111(.A(new_n43_), .B(p6), .C(p4), .Y(new_n130_));
  NOR2x1_ASAP7_75t_R   g112(.A(p9), .B(p7), .Y(new_n131_));
  OR3x1_ASAP7_75t_R    g113(.A(new_n130_), .B(new_n56_), .C(new_n131_), .Y(new_n132_));
  OA211x2_ASAP7_75t_R  g114(.A1(p9), .A2(new_n127_), .B(new_n129_), .C(new_n132_), .Y(new_n133_));
  OAI21x1_ASAP7_75t_R  g115(.A1(new_n42_), .A2(new_n125_), .B(new_n133_), .Y(o2));
  NAND2x1_ASAP7_75t_R  g116(.A(new_n24_), .B(new_n29_), .Y(new_n135_));
  OR3x1_ASAP7_75t_R    g117(.A(new_n135_), .B(p3), .C(p5), .Y(new_n136_));
  OR3x1_ASAP7_75t_R    g118(.A(new_n82_), .B(new_n24_), .C(new_n28_), .Y(new_n137_));
  OR3x1_ASAP7_75t_R    g119(.A(new_n137_), .B(new_n20_), .C(p1), .Y(new_n138_));
  OA21x2_ASAP7_75t_R   g120(.A1(p7), .A2(new_n136_), .B(new_n138_), .Y(new_n139_));
  OR3x1_ASAP7_75t_R    g121(.A(new_n139_), .B(p2), .C(new_n42_), .Y(o3));
  AO21x1_ASAP7_75t_R   g122(.A1(new_n78_), .A2(new_n111_), .B(new_n126_), .Y(new_n141_));
  NOR2x1_ASAP7_75t_R   g123(.A(p7), .B(new_n33_), .Y(new_n142_));
  NAND3x1_ASAP7_75t_R  g124(.A(new_n141_), .B(p1), .C(new_n142_), .Y(new_n143_));
  NAND2x1_ASAP7_75t_R  g125(.A(p8), .B(new_n137_), .Y(new_n144_));
  OR5x1_ASAP7_75t_R    g126(.A(p8), .B(new_n142_), .C(new_n54_), .D(new_n98_), .E(new_n120_), .Y(new_n145_));
  AND2x2_ASAP7_75t_R   g127(.A(new_n144_), .B(new_n145_), .Y(new_n146_));
  OR3x1_ASAP7_75t_R    g128(.A(new_n90_), .B(new_n34_), .C(p6), .Y(new_n147_));
  AO21x1_ASAP7_75t_R   g129(.A1(new_n82_), .A2(new_n147_), .B(new_n36_), .Y(new_n148_));
  OA211x2_ASAP7_75t_R  g130(.A1(new_n20_), .A2(new_n135_), .B(new_n53_), .C(new_n28_), .Y(new_n149_));
  NAND2x1_ASAP7_75t_R  g131(.A(new_n148_), .B(new_n149_), .Y(new_n150_));
  AO31x2_ASAP7_75t_R   g132(.A1(new_n143_), .A2(new_n146_), .A3(new_n150_), .B(p9), .Y(o4));
  OR3x1_ASAP7_75t_R    g133(.A(new_n135_), .B(new_n33_), .C(p7), .Y(new_n152_));
  OAI22x1_ASAP7_75t_R  g134(.A1(new_n152_), .A2(new_n74_), .B1(new_n54_), .B2(new_n137_), .Y(new_n153_));
  AND3x1_ASAP7_75t_R   g135(.A(new_n93_), .B(p5), .C(p4), .Y(new_n154_));
  OR3x1_ASAP7_75t_R    g136(.A(new_n154_), .B(new_n105_), .C(new_n78_), .Y(new_n155_));
  NAND2x1_ASAP7_75t_R  g137(.A(new_n41_), .B(new_n155_), .Y(new_n156_));
  AO21x1_ASAP7_75t_R   g138(.A1(p3), .A2(new_n153_), .B(new_n156_), .Y(o5));
  OR3x1_ASAP7_75t_R    g139(.A(new_n154_), .B(new_n42_), .C(new_n105_), .Y(o6));
endmodule


