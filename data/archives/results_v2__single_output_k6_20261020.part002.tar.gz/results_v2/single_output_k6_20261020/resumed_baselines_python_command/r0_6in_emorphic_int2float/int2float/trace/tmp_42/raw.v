// Benchmark "/tmp/" written by ABC on Tue Oct 20 17:46:18 2026

module \/tmp/  ( 
    p7, p2, p3, p8, p1, p10, p5, p0, p4, p6, p9,
    o0, o1, o2, o3, o4, o5, o6  );
  input  p7, p2, p3, p8, p1, p10, p5, p0, p4, p6, p9;
  output o0, o1, o2, o3, o4, o5, o6;
  wire new_n19_, new_n20_, new_n21_, new_n22_, new_n23_, new_n24_, new_n25_,
    new_n26_, new_n27_, new_n28_, new_n29_, new_n30_, new_n31_, new_n32_,
    new_n33_, new_n34_, new_n35_, new_n36_, new_n37_, new_n38_, new_n39_,
    new_n40_, new_n41_, new_n42_, new_n43_, new_n44_, new_n45_, new_n46_,
    new_n47_, new_n48_, new_n49_, new_n50_, new_n51_, new_n52_, new_n53_,
    new_n54_, new_n55_, new_n56_, new_n57_, new_n58_, new_n59_, new_n60_,
    new_n61_, new_n62_, new_n63_, new_n65_, new_n66_, new_n67_, new_n68_,
    new_n69_, new_n70_, new_n71_, new_n72_, new_n73_, new_n74_, new_n75_,
    new_n76_, new_n77_, new_n78_, new_n79_, new_n80_, new_n81_, new_n82_,
    new_n83_, new_n84_, new_n85_, new_n86_, new_n87_, new_n88_, new_n89_,
    new_n90_, new_n91_, new_n92_, new_n93_, new_n94_, new_n95_, new_n96_,
    new_n97_, new_n98_, new_n99_, new_n100_, new_n101_, new_n103_,
    new_n104_, new_n105_, new_n106_, new_n107_, new_n108_, new_n109_,
    new_n110_, new_n111_, new_n112_, new_n113_, new_n114_, new_n115_,
    new_n116_, new_n117_, new_n118_, new_n119_, new_n120_, new_n121_,
    new_n122_, new_n123_, new_n124_, new_n125_, new_n126_, new_n127_,
    new_n128_, new_n129_, new_n131_, new_n132_, new_n133_, new_n134_,
    new_n136_, new_n137_, new_n138_, new_n139_, new_n140_, new_n141_,
    new_n142_, new_n143_, new_n144_, new_n145_, new_n146_, new_n147_,
    new_n149_, new_n150_, new_n151_, new_n152_, new_n153_;
  INVx1_ASAP7_75t_R    g000(.A(p10), .Y(new_n19_));
  NAND2x1_ASAP7_75t_R  g001(.A(p3), .B(p0), .Y(new_n20_));
  AOI211x1_ASAP7_75t_R g002(.A1(new_n19_), .A2(new_n20_), .B(p5), .C(p6), .Y(new_n21_));
  INVx1_ASAP7_75t_R    g003(.A(p3), .Y(new_n22_));
  NAND2x1_ASAP7_75t_R  g004(.A(p7), .B(new_n22_), .Y(new_n23_));
  AO21x1_ASAP7_75t_R   g005(.A1(new_n20_), .A2(new_n23_), .B(new_n19_), .Y(new_n24_));
  AO21x1_ASAP7_75t_R   g006(.A1(p7), .A2(p3), .B(p4), .Y(new_n25_));
  AO21x1_ASAP7_75t_R   g007(.A1(new_n21_), .A2(new_n24_), .B(new_n25_), .Y(new_n26_));
  INVx1_ASAP7_75t_R    g008(.A(p4), .Y(new_n27_));
  AO21x1_ASAP7_75t_R   g009(.A1(p7), .A2(new_n22_), .B(new_n27_), .Y(new_n28_));
  INVx1_ASAP7_75t_R    g010(.A(p7), .Y(new_n29_));
  INVx1_ASAP7_75t_R    g011(.A(p2), .Y(new_n30_));
  NAND2x1_ASAP7_75t_R  g012(.A(p3), .B(new_n30_), .Y(new_n31_));
  NAND2x1_ASAP7_75t_R  g013(.A(p2), .B(new_n22_), .Y(new_n32_));
  NAND2x1_ASAP7_75t_R  g014(.A(new_n31_), .B(new_n32_), .Y(new_n33_));
  INVx1_ASAP7_75t_R    g015(.A(p1), .Y(new_n34_));
  INVx1_ASAP7_75t_R    g016(.A(p6), .Y(new_n35_));
  AND5x1_ASAP7_75t_R   g017(.A(p2), .B(new_n34_), .C(new_n35_), .D(p0), .E(p4), .Y(new_n36_));
  AO21x1_ASAP7_75t_R   g018(.A1(p6), .A2(new_n33_), .B(new_n36_), .Y(new_n37_));
  AOI22x1_ASAP7_75t_R  g019(.A1(new_n26_), .A2(new_n28_), .B1(new_n29_), .B2(new_n37_), .Y(new_n38_));
  NOR2x1_ASAP7_75t_R   g020(.A(p8), .B(p9), .Y(new_n39_));
  INVx1_ASAP7_75t_R    g021(.A(new_n39_), .Y(new_n40_));
  NOR2x1_ASAP7_75t_R   g022(.A(p5), .B(new_n27_), .Y(new_n41_));
  INVx1_ASAP7_75t_R    g023(.A(new_n41_), .Y(new_n42_));
  NOR2x1_ASAP7_75t_R   g024(.A(p3), .B(new_n35_), .Y(new_n43_));
  INVx1_ASAP7_75t_R    g025(.A(p0), .Y(new_n44_));
  AND2x2_ASAP7_75t_R   g026(.A(p7), .B(p3), .Y(new_n45_));
  AND2x2_ASAP7_75t_R   g027(.A(p2), .B(p3), .Y(new_n46_));
  OR5x1_ASAP7_75t_R    g028(.A(p1), .B(new_n43_), .C(new_n44_), .D(new_n45_), .E(new_n46_), .Y(new_n47_));
  NOR2x1_ASAP7_75t_R   g029(.A(p7), .B(p6), .Y(new_n48_));
  AO31x2_ASAP7_75t_R   g030(.A1(new_n48_), .A2(p1), .A3(new_n44_), .B(p8), .Y(new_n49_));
  AND3x1_ASAP7_75t_R   g031(.A(new_n27_), .B(p8), .C(p5), .Y(new_n50_));
  AOI21x1_ASAP7_75t_R  g032(.A1(new_n41_), .A2(new_n49_), .B(new_n50_), .Y(new_n51_));
  OAI21x1_ASAP7_75t_R  g033(.A1(new_n42_), .A2(new_n47_), .B(new_n51_), .Y(new_n52_));
  INVx1_ASAP7_75t_R    g034(.A(p9), .Y(new_n53_));
  NOR2x1_ASAP7_75t_R   g035(.A(p2), .B(p1), .Y(new_n54_));
  INVx1_ASAP7_75t_R    g036(.A(p8), .Y(new_n55_));
  NAND2x1_ASAP7_75t_R  g037(.A(new_n29_), .B(new_n55_), .Y(new_n56_));
  AO21x1_ASAP7_75t_R   g038(.A1(p2), .A2(p1), .B(new_n56_), .Y(new_n57_));
  OAI21x1_ASAP7_75t_R  g039(.A1(new_n54_), .A2(new_n57_), .B(new_n53_), .Y(new_n58_));
  AND3x1_ASAP7_75t_R   g040(.A(p7), .B(p8), .C(p5), .Y(new_n59_));
  NOR2x1_ASAP7_75t_R   g041(.A(p5), .B(new_n35_), .Y(new_n60_));
  OA21x2_ASAP7_75t_R   g042(.A1(new_n59_), .A2(new_n60_), .B(p9), .Y(new_n61_));
  AO21x1_ASAP7_75t_R   g043(.A1(p5), .A2(new_n35_), .B(new_n61_), .Y(new_n62_));
  AOI22x1_ASAP7_75t_R  g044(.A1(new_n52_), .A2(new_n53_), .B1(new_n58_), .B2(new_n62_), .Y(new_n63_));
  OAI21x1_ASAP7_75t_R  g045(.A1(new_n38_), .A2(new_n40_), .B(new_n63_), .Y(o0));
  NOR2x1_ASAP7_75t_R   g046(.A(p3), .B(p8), .Y(new_n65_));
  INVx1_ASAP7_75t_R    g047(.A(p5), .Y(new_n66_));
  AO21x1_ASAP7_75t_R   g048(.A1(new_n29_), .A2(new_n55_), .B(new_n66_), .Y(new_n67_));
  AOI211x1_ASAP7_75t_R g049(.A1(p8), .A2(new_n35_), .B(new_n65_), .C(new_n67_), .Y(new_n68_));
  OR3x1_ASAP7_75t_R    g050(.A(new_n22_), .B(p7), .C(p8), .Y(new_n69_));
  OR3x1_ASAP7_75t_R    g051(.A(p3), .B(p5), .C(p6), .Y(new_n70_));
  NAND2x1_ASAP7_75t_R  g052(.A(p1), .B(p0), .Y(new_n71_));
  AO21x1_ASAP7_75t_R   g053(.A1(new_n35_), .A2(new_n71_), .B(new_n30_), .Y(new_n72_));
  AOI21x1_ASAP7_75t_R  g054(.A1(new_n69_), .A2(new_n70_), .B(new_n72_), .Y(new_n73_));
  OAI21x1_ASAP7_75t_R  g055(.A1(new_n68_), .A2(new_n73_), .B(p4), .Y(new_n74_));
  NAND2x1_ASAP7_75t_R  g056(.A(p2), .B(p3), .Y(new_n75_));
  NAND2x1_ASAP7_75t_R  g057(.A(p6), .B(new_n75_), .Y(new_n76_));
  NAND2x1_ASAP7_75t_R  g058(.A(p8), .B(new_n35_), .Y(new_n77_));
  OAI21x1_ASAP7_75t_R  g059(.A1(new_n56_), .A2(new_n76_), .B(new_n77_), .Y(new_n78_));
  NAND2x1_ASAP7_75t_R  g060(.A(p7), .B(new_n65_), .Y(new_n79_));
  NAND2x1_ASAP7_75t_R  g061(.A(new_n77_), .B(new_n79_), .Y(new_n80_));
  AOI22x1_ASAP7_75t_R  g062(.A1(new_n78_), .A2(new_n27_), .B1(new_n66_), .B2(new_n80_), .Y(new_n81_));
  NOR2x1_ASAP7_75t_R   g063(.A(p3), .B(p0), .Y(new_n82_));
  OA21x2_ASAP7_75t_R   g064(.A1(p7), .A2(new_n82_), .B(new_n55_), .Y(new_n83_));
  AO21x1_ASAP7_75t_R   g065(.A1(p10), .A2(p0), .B(p1), .Y(new_n84_));
  NAND3x1_ASAP7_75t_R  g066(.A(p1), .B(p10), .C(p0), .Y(new_n85_));
  AOI221x1_ASAP7_75t_R g067(.A1(new_n22_), .A2(p0), .B1(new_n84_), .B2(new_n85_), .C(p6), .Y(new_n86_));
  NOR2x1_ASAP7_75t_R   g068(.A(p5), .B(p4), .Y(new_n87_));
  OAI21x1_ASAP7_75t_R  g069(.A1(new_n83_), .A2(new_n86_), .B(new_n87_), .Y(new_n88_));
  NAND3x1_ASAP7_75t_R  g070(.A(new_n74_), .B(new_n81_), .C(new_n88_), .Y(new_n89_));
  AND3x1_ASAP7_75t_R   g071(.A(new_n55_), .B(p2), .C(p1), .Y(new_n90_));
  OR3x1_ASAP7_75t_R    g072(.A(new_n90_), .B(new_n66_), .C(new_n65_), .Y(new_n91_));
  OA22x2_ASAP7_75t_R   g073(.A1(new_n32_), .A2(new_n34_), .B1(p5), .B2(new_n71_), .Y(new_n92_));
  INVx1_ASAP7_75t_R    g074(.A(new_n87_), .Y(new_n93_));
  NAND2x1_ASAP7_75t_R  g075(.A(p2), .B(new_n66_), .Y(new_n94_));
  AND3x1_ASAP7_75t_R   g076(.A(new_n93_), .B(new_n94_), .C(new_n35_), .Y(new_n95_));
  NAND3x1_ASAP7_75t_R  g077(.A(new_n91_), .B(new_n92_), .C(new_n95_), .Y(new_n96_));
  AND2x2_ASAP7_75t_R   g078(.A(p5), .B(p6), .Y(new_n97_));
  NAND2x1_ASAP7_75t_R  g079(.A(p5), .B(p6), .Y(new_n98_));
  OA21x2_ASAP7_75t_R   g080(.A1(p8), .A2(new_n98_), .B(p7), .Y(new_n99_));
  AO21x1_ASAP7_75t_R   g081(.A1(new_n29_), .A2(new_n97_), .B(new_n99_), .Y(new_n100_));
  AOI21x1_ASAP7_75t_R  g082(.A1(new_n53_), .A2(new_n96_), .B(new_n100_), .Y(new_n101_));
  AOI21x1_ASAP7_75t_R  g083(.A1(new_n53_), .A2(new_n89_), .B(new_n101_), .Y(o1));
  NAND2x1_ASAP7_75t_R  g084(.A(p3), .B(new_n34_), .Y(new_n103_));
  OAI22x1_ASAP7_75t_R  g085(.A1(new_n94_), .A2(new_n103_), .B1(new_n31_), .B2(new_n27_), .Y(new_n104_));
  OAI21x1_ASAP7_75t_R  g086(.A1(p1), .A2(new_n104_), .B(new_n48_), .Y(new_n105_));
  AND2x2_ASAP7_75t_R   g087(.A(p10), .B(p0), .Y(new_n106_));
  OAI22x1_ASAP7_75t_R  g088(.A1(new_n106_), .A2(new_n75_), .B1(p3), .B2(p5), .Y(new_n107_));
  NAND2x1_ASAP7_75t_R  g089(.A(p10), .B(new_n66_), .Y(new_n108_));
  NAND3x1_ASAP7_75t_R  g090(.A(new_n22_), .B(p2), .C(p4), .Y(new_n109_));
  OAI21x1_ASAP7_75t_R  g091(.A1(new_n31_), .A2(new_n108_), .B(new_n109_), .Y(new_n110_));
  AOI221x1_ASAP7_75t_R g092(.A1(new_n27_), .A2(new_n107_), .B1(new_n110_), .B2(p0), .C(new_n104_), .Y(new_n111_));
  AND2x2_ASAP7_75t_R   g093(.A(p5), .B(p4), .Y(new_n112_));
  AND3x1_ASAP7_75t_R   g094(.A(new_n112_), .B(p3), .C(new_n35_), .Y(new_n113_));
  NAND3x1_ASAP7_75t_R  g095(.A(new_n66_), .B(new_n44_), .C(p4), .Y(new_n114_));
  NAND3x1_ASAP7_75t_R  g096(.A(new_n27_), .B(p1), .C(p5), .Y(new_n115_));
  NAND3x1_ASAP7_75t_R  g097(.A(new_n114_), .B(new_n115_), .C(new_n46_), .Y(new_n116_));
  OA21x2_ASAP7_75t_R   g098(.A1(new_n46_), .A2(new_n112_), .B(new_n29_), .Y(new_n117_));
  NAND2x1_ASAP7_75t_R  g099(.A(p3), .B(p4), .Y(new_n118_));
  AND3x1_ASAP7_75t_R   g100(.A(p2), .B(p3), .C(p4), .Y(new_n119_));
  AO22x1_ASAP7_75t_R   g101(.A1(new_n97_), .A2(new_n118_), .B1(new_n119_), .B2(new_n60_), .Y(new_n120_));
  AOI221x1_ASAP7_75t_R g102(.A1(new_n34_), .A2(new_n113_), .B1(new_n116_), .B2(new_n117_), .C(new_n120_), .Y(new_n121_));
  OAI21x1_ASAP7_75t_R  g103(.A1(new_n105_), .A2(new_n111_), .B(new_n121_), .Y(new_n122_));
  OAI21x1_ASAP7_75t_R  g104(.A1(new_n60_), .A2(new_n113_), .B(p7), .Y(new_n123_));
  OR3x1_ASAP7_75t_R    g105(.A(new_n55_), .B(new_n27_), .C(p7), .Y(new_n124_));
  OAI21x1_ASAP7_75t_R  g106(.A1(new_n29_), .A2(new_n53_), .B(new_n124_), .Y(new_n125_));
  OR3x1_ASAP7_75t_R    g107(.A(new_n27_), .B(new_n35_), .C(p9), .Y(new_n126_));
  OA21x2_ASAP7_75t_R   g108(.A1(p7), .A2(p9), .B(p8), .Y(new_n127_));
  AOI22x1_ASAP7_75t_R  g109(.A1(new_n125_), .A2(new_n97_), .B1(new_n126_), .B2(new_n127_), .Y(new_n128_));
  OAI21x1_ASAP7_75t_R  g110(.A1(p9), .A2(new_n123_), .B(new_n128_), .Y(new_n129_));
  AO21x1_ASAP7_75t_R   g111(.A1(new_n39_), .A2(new_n122_), .B(new_n129_), .Y(o2));
  NAND2x1_ASAP7_75t_R  g112(.A(p5), .B(p4), .Y(new_n131_));
  OR3x1_ASAP7_75t_R    g113(.A(new_n131_), .B(new_n29_), .C(new_n35_), .Y(new_n132_));
  OR5x1_ASAP7_75t_R    g114(.A(p7), .B(p3), .C(p5), .D(p4), .E(p6), .Y(new_n133_));
  OA21x2_ASAP7_75t_R   g115(.A1(new_n103_), .A2(new_n132_), .B(new_n133_), .Y(new_n134_));
  OR3x1_ASAP7_75t_R    g116(.A(new_n134_), .B(p2), .C(new_n40_), .Y(o3));
  OR3x1_ASAP7_75t_R    g117(.A(new_n34_), .B(new_n44_), .C(p6), .Y(new_n136_));
  AO21x1_ASAP7_75t_R   g118(.A1(new_n131_), .A2(new_n136_), .B(new_n75_), .Y(new_n137_));
  OR3x1_ASAP7_75t_R    g119(.A(new_n22_), .B(p4), .C(p6), .Y(new_n138_));
  OA211x2_ASAP7_75t_R  g120(.A1(new_n66_), .A2(p6), .B(new_n138_), .C(new_n29_), .Y(new_n139_));
  NAND2x1_ASAP7_75t_R  g121(.A(new_n137_), .B(new_n139_), .Y(new_n140_));
  AND3x1_ASAP7_75t_R   g122(.A(new_n87_), .B(p10), .C(p0), .Y(new_n141_));
  AND3x1_ASAP7_75t_R   g123(.A(new_n29_), .B(p2), .C(p1), .Y(new_n142_));
  OAI21x1_ASAP7_75t_R  g124(.A1(new_n141_), .A2(new_n113_), .B(new_n142_), .Y(new_n143_));
  NOR2x1_ASAP7_75t_R   g125(.A(p7), .B(new_n30_), .Y(new_n144_));
  OR5x1_ASAP7_75t_R    g126(.A(p8), .B(new_n144_), .C(new_n54_), .D(new_n98_), .E(new_n118_), .Y(new_n145_));
  NAND2x1_ASAP7_75t_R  g127(.A(p8), .B(new_n132_), .Y(new_n146_));
  AND3x1_ASAP7_75t_R   g128(.A(new_n143_), .B(new_n145_), .C(new_n146_), .Y(new_n147_));
  AO21x1_ASAP7_75t_R   g129(.A1(new_n140_), .A2(new_n147_), .B(p9), .Y(o4));
  NOR2x1_ASAP7_75t_R   g130(.A(new_n54_), .B(new_n132_), .Y(new_n149_));
  AND5x1_ASAP7_75t_R   g131(.A(p1), .B(new_n144_), .C(new_n27_), .D(new_n35_), .E(new_n106_), .Y(new_n150_));
  OA21x2_ASAP7_75t_R   g132(.A1(new_n149_), .A2(new_n150_), .B(p3), .Y(new_n151_));
  OR3x1_ASAP7_75t_R    g133(.A(new_n75_), .B(new_n131_), .C(new_n34_), .Y(new_n152_));
  AND3x1_ASAP7_75t_R   g134(.A(new_n152_), .B(new_n93_), .C(new_n48_), .Y(new_n153_));
  OR3x1_ASAP7_75t_R    g135(.A(new_n151_), .B(new_n40_), .C(new_n153_), .Y(o5));
  NAND3x1_ASAP7_75t_R  g136(.A(new_n152_), .B(new_n39_), .C(new_n48_), .Y(o6));
endmodule


