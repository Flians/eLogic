// Benchmark "/tmp/" written by ABC on Tue Oct 20 17:46:17 2026

module \/tmp/  ( 
    p2, p9, p3, p5, p8, p6, p10, p7, p0, p4, p1,
    o0, o1, o2, o3, o4, o5, o6  );
  input  p2, p9, p3, p5, p8, p6, p10, p7, p0, p4, p1;
  output o0, o1, o2, o3, o4, o5, o6;
  wire new_n19_, new_n20_, new_n21_, new_n22_, new_n23_, new_n24_, new_n25_,
    new_n26_, new_n27_, new_n28_, new_n29_, new_n30_, new_n31_, new_n32_,
    new_n33_, new_n34_, new_n35_, new_n36_, new_n37_, new_n38_, new_n39_,
    new_n40_, new_n41_, new_n42_, new_n43_, new_n44_, new_n45_, new_n46_,
    new_n47_, new_n48_, new_n49_, new_n50_, new_n51_, new_n52_, new_n53_,
    new_n54_, new_n55_, new_n56_, new_n57_, new_n58_, new_n59_, new_n60_,
    new_n61_, new_n62_, new_n63_, new_n64_, new_n66_, new_n67_, new_n68_,
    new_n69_, new_n70_, new_n71_, new_n72_, new_n73_, new_n74_, new_n75_,
    new_n76_, new_n77_, new_n78_, new_n79_, new_n80_, new_n81_, new_n82_,
    new_n83_, new_n84_, new_n85_, new_n86_, new_n87_, new_n88_, new_n89_,
    new_n90_, new_n91_, new_n92_, new_n93_, new_n94_, new_n95_, new_n96_,
    new_n97_, new_n99_, new_n100_, new_n101_, new_n102_, new_n103_,
    new_n104_, new_n105_, new_n106_, new_n107_, new_n108_, new_n109_,
    new_n110_, new_n111_, new_n112_, new_n113_, new_n114_, new_n115_,
    new_n116_, new_n117_, new_n118_, new_n119_, new_n120_, new_n121_,
    new_n122_, new_n123_, new_n124_, new_n125_, new_n126_, new_n127_,
    new_n129_, new_n130_, new_n131_, new_n132_, new_n134_, new_n135_,
    new_n136_, new_n137_, new_n138_, new_n139_, new_n140_, new_n141_,
    new_n142_, new_n143_, new_n144_, new_n145_, new_n147_, new_n148_,
    new_n149_, new_n150_, new_n151_, new_n152_;
  INVx1_ASAP7_75t_R    g000(.A(p10), .Y(new_n19_));
  NAND2x1_ASAP7_75t_R  g001(.A(p3), .B(p0), .Y(new_n20_));
  AOI211x1_ASAP7_75t_R g002(.A1(new_n19_), .A2(new_n20_), .B(p5), .C(p6), .Y(new_n21_));
  INVx1_ASAP7_75t_R    g003(.A(p3), .Y(new_n22_));
  NAND2x1_ASAP7_75t_R  g004(.A(p7), .B(new_n22_), .Y(new_n23_));
  AO21x1_ASAP7_75t_R   g005(.A1(new_n20_), .A2(new_n23_), .B(new_n19_), .Y(new_n24_));
  AO21x1_ASAP7_75t_R   g006(.A1(p3), .A2(p7), .B(p4), .Y(new_n25_));
  AO21x1_ASAP7_75t_R   g007(.A1(new_n21_), .A2(new_n24_), .B(new_n25_), .Y(new_n26_));
  INVx1_ASAP7_75t_R    g008(.A(p4), .Y(new_n27_));
  AO21x1_ASAP7_75t_R   g009(.A1(p7), .A2(new_n22_), .B(new_n27_), .Y(new_n28_));
  INVx1_ASAP7_75t_R    g010(.A(p7), .Y(new_n29_));
  INVx1_ASAP7_75t_R    g011(.A(p2), .Y(new_n30_));
  INVx1_ASAP7_75t_R    g012(.A(p0), .Y(new_n31_));
  OR5x1_ASAP7_75t_R    g013(.A(new_n30_), .B(new_n31_), .C(new_n27_), .D(p6), .E(p1), .Y(new_n32_));
  NAND2x1_ASAP7_75t_R  g014(.A(p3), .B(new_n30_), .Y(new_n33_));
  NAND2x1_ASAP7_75t_R  g015(.A(p2), .B(new_n22_), .Y(new_n34_));
  INVx1_ASAP7_75t_R    g016(.A(p6), .Y(new_n35_));
  AO21x1_ASAP7_75t_R   g017(.A1(new_n33_), .A2(new_n34_), .B(new_n35_), .Y(new_n36_));
  NAND2x1_ASAP7_75t_R  g018(.A(new_n32_), .B(new_n36_), .Y(new_n37_));
  AOI22x1_ASAP7_75t_R  g019(.A1(new_n26_), .A2(new_n28_), .B1(new_n29_), .B2(new_n37_), .Y(new_n38_));
  NOR2x1_ASAP7_75t_R   g020(.A(p9), .B(p8), .Y(new_n39_));
  INVx1_ASAP7_75t_R    g021(.A(new_n39_), .Y(new_n40_));
  INVx1_ASAP7_75t_R    g022(.A(p9), .Y(new_n41_));
  NOR2x1_ASAP7_75t_R   g023(.A(p5), .B(new_n27_), .Y(new_n42_));
  INVx1_ASAP7_75t_R    g024(.A(new_n42_), .Y(new_n43_));
  NOR2x1_ASAP7_75t_R   g025(.A(p3), .B(new_n35_), .Y(new_n44_));
  AND2x2_ASAP7_75t_R   g026(.A(p3), .B(p7), .Y(new_n45_));
  AND2x2_ASAP7_75t_R   g027(.A(p2), .B(p3), .Y(new_n46_));
  OR5x1_ASAP7_75t_R    g028(.A(new_n31_), .B(new_n44_), .C(p1), .D(new_n45_), .E(new_n46_), .Y(new_n47_));
  NOR2x1_ASAP7_75t_R   g029(.A(p6), .B(p7), .Y(new_n48_));
  AO31x2_ASAP7_75t_R   g030(.A1(new_n48_), .A2(new_n31_), .A3(p1), .B(p8), .Y(new_n49_));
  AND2x2_ASAP7_75t_R   g031(.A(p5), .B(p8), .Y(new_n50_));
  AOI22x1_ASAP7_75t_R  g032(.A1(new_n49_), .A2(new_n42_), .B1(new_n27_), .B2(new_n50_), .Y(new_n51_));
  OAI21x1_ASAP7_75t_R  g033(.A1(new_n43_), .A2(new_n47_), .B(new_n51_), .Y(new_n52_));
  NAND2x1_ASAP7_75t_R  g034(.A(p2), .B(p1), .Y(new_n53_));
  INVx1_ASAP7_75t_R    g035(.A(p1), .Y(new_n54_));
  NAND2x1_ASAP7_75t_R  g036(.A(new_n30_), .B(new_n54_), .Y(new_n55_));
  AO21x1_ASAP7_75t_R   g037(.A1(new_n53_), .A2(new_n55_), .B(p9), .Y(new_n56_));
  INVx1_ASAP7_75t_R    g038(.A(p8), .Y(new_n57_));
  NAND2x1_ASAP7_75t_R  g039(.A(new_n57_), .B(new_n29_), .Y(new_n58_));
  AOI21x1_ASAP7_75t_R  g040(.A1(new_n41_), .A2(new_n58_), .B(p6), .Y(new_n59_));
  AND2x2_ASAP7_75t_R   g041(.A(p9), .B(p6), .Y(new_n60_));
  INVx1_ASAP7_75t_R    g042(.A(p5), .Y(new_n61_));
  AO32x1_ASAP7_75t_R   g043(.A1(new_n50_), .A2(p9), .A3(p7), .B1(new_n60_), .B2(new_n61_), .Y(new_n62_));
  AO31x2_ASAP7_75t_R   g044(.A1(new_n56_), .A2(p5), .A3(new_n59_), .B(new_n62_), .Y(new_n63_));
  AOI21x1_ASAP7_75t_R  g045(.A1(new_n41_), .A2(new_n52_), .B(new_n63_), .Y(new_n64_));
  OAI21x1_ASAP7_75t_R  g046(.A1(new_n38_), .A2(new_n40_), .B(new_n64_), .Y(o0));
  OR3x1_ASAP7_75t_R    g047(.A(new_n35_), .B(p8), .C(p7), .Y(new_n66_));
  OAI22x1_ASAP7_75t_R  g048(.A1(new_n66_), .A2(new_n46_), .B1(new_n57_), .B2(p6), .Y(new_n67_));
  OAI21x1_ASAP7_75t_R  g049(.A1(p5), .A2(p6), .B(new_n22_), .Y(new_n68_));
  OAI21x1_ASAP7_75t_R  g050(.A1(p8), .A2(p7), .B(p3), .Y(new_n69_));
  AO21x1_ASAP7_75t_R   g051(.A1(p0), .A2(p1), .B(p6), .Y(new_n70_));
  AND5x1_ASAP7_75t_R   g052(.A(p2), .B(new_n68_), .C(p4), .D(new_n69_), .E(new_n70_), .Y(new_n71_));
  AOI21x1_ASAP7_75t_R  g053(.A1(new_n27_), .A2(new_n67_), .B(new_n71_), .Y(new_n72_));
  NOR2x1_ASAP7_75t_R   g054(.A(p3), .B(p0), .Y(new_n73_));
  OA21x2_ASAP7_75t_R   g055(.A1(p7), .A2(new_n73_), .B(new_n57_), .Y(new_n74_));
  AO21x1_ASAP7_75t_R   g056(.A1(p10), .A2(p0), .B(p1), .Y(new_n75_));
  NAND3x1_ASAP7_75t_R  g057(.A(p10), .B(p0), .C(p1), .Y(new_n76_));
  AOI221x1_ASAP7_75t_R g058(.A1(new_n22_), .A2(p0), .B1(new_n75_), .B2(new_n76_), .C(p6), .Y(new_n77_));
  NOR2x1_ASAP7_75t_R   g059(.A(p5), .B(p4), .Y(new_n78_));
  OAI21x1_ASAP7_75t_R  g060(.A1(new_n74_), .A2(new_n77_), .B(new_n78_), .Y(new_n79_));
  NOR2x1_ASAP7_75t_R   g061(.A(p6), .B(new_n57_), .Y(new_n80_));
  NOR2x1_ASAP7_75t_R   g062(.A(p3), .B(p8), .Y(new_n81_));
  AND2x2_ASAP7_75t_R   g063(.A(p5), .B(p4), .Y(new_n82_));
  OR3x1_ASAP7_75t_R    g064(.A(new_n80_), .B(new_n81_), .C(new_n82_), .Y(new_n83_));
  OAI21x1_ASAP7_75t_R  g065(.A1(new_n81_), .A2(new_n80_), .B(p5), .Y(new_n84_));
  NAND3x1_ASAP7_75t_R  g066(.A(new_n83_), .B(new_n84_), .C(new_n58_), .Y(new_n85_));
  NAND3x1_ASAP7_75t_R  g067(.A(new_n72_), .B(new_n79_), .C(new_n85_), .Y(new_n86_));
  OA21x2_ASAP7_75t_R   g068(.A1(new_n54_), .A2(new_n34_), .B(new_n35_), .Y(new_n87_));
  AND2x2_ASAP7_75t_R   g069(.A(p3), .B(new_n53_), .Y(new_n88_));
  NAND2x1_ASAP7_75t_R  g070(.A(p5), .B(new_n57_), .Y(new_n89_));
  AND2x2_ASAP7_75t_R   g071(.A(p0), .B(p1), .Y(new_n90_));
  OR3x1_ASAP7_75t_R    g072(.A(new_n27_), .B(p2), .C(p5), .Y(new_n91_));
  OAI22x1_ASAP7_75t_R  g073(.A1(new_n88_), .A2(new_n89_), .B1(new_n90_), .B2(new_n91_), .Y(new_n92_));
  AOI21x1_ASAP7_75t_R  g074(.A1(new_n87_), .A2(new_n92_), .B(p9), .Y(new_n93_));
  AO21x1_ASAP7_75t_R   g075(.A1(p5), .A2(p6), .B(p7), .Y(new_n94_));
  NAND2x1_ASAP7_75t_R  g076(.A(p9), .B(p7), .Y(new_n95_));
  OR3x1_ASAP7_75t_R    g077(.A(new_n95_), .B(new_n61_), .C(new_n35_), .Y(new_n96_));
  OAI22x1_ASAP7_75t_R  g078(.A1(new_n93_), .A2(new_n94_), .B1(p8), .B2(new_n96_), .Y(new_n97_));
  AOI21x1_ASAP7_75t_R  g079(.A1(new_n41_), .A2(new_n86_), .B(new_n97_), .Y(o1));
  AND2x2_ASAP7_75t_R   g080(.A(p3), .B(p4), .Y(new_n99_));
  AO32x1_ASAP7_75t_R   g081(.A1(new_n46_), .A2(new_n61_), .A3(new_n54_), .B1(new_n99_), .B2(new_n30_), .Y(new_n100_));
  OAI21x1_ASAP7_75t_R  g082(.A1(p1), .A2(new_n100_), .B(new_n48_), .Y(new_n101_));
  NAND2x1_ASAP7_75t_R  g083(.A(p10), .B(p0), .Y(new_n102_));
  NOR2x1_ASAP7_75t_R   g084(.A(p3), .B(p5), .Y(new_n103_));
  AO21x1_ASAP7_75t_R   g085(.A1(new_n102_), .A2(new_n46_), .B(new_n103_), .Y(new_n104_));
  NAND2x1_ASAP7_75t_R  g086(.A(p10), .B(new_n61_), .Y(new_n105_));
  NAND3x1_ASAP7_75t_R  g087(.A(new_n22_), .B(p2), .C(p4), .Y(new_n106_));
  OAI21x1_ASAP7_75t_R  g088(.A1(new_n33_), .A2(new_n105_), .B(new_n106_), .Y(new_n107_));
  AOI221x1_ASAP7_75t_R g089(.A1(new_n27_), .A2(new_n104_), .B1(new_n107_), .B2(p0), .C(new_n100_), .Y(new_n108_));
  AND3x1_ASAP7_75t_R   g090(.A(new_n82_), .B(p3), .C(new_n35_), .Y(new_n109_));
  NAND3x1_ASAP7_75t_R  g091(.A(new_n61_), .B(new_n31_), .C(p4), .Y(new_n110_));
  NAND3x1_ASAP7_75t_R  g092(.A(new_n27_), .B(p5), .C(p1), .Y(new_n111_));
  NAND3x1_ASAP7_75t_R  g093(.A(new_n110_), .B(new_n111_), .C(new_n46_), .Y(new_n112_));
  OA21x2_ASAP7_75t_R   g094(.A1(new_n46_), .A2(new_n82_), .B(new_n29_), .Y(new_n113_));
  AND2x2_ASAP7_75t_R   g095(.A(p5), .B(p6), .Y(new_n114_));
  NAND2x1_ASAP7_75t_R  g096(.A(p3), .B(p4), .Y(new_n115_));
  AND3x1_ASAP7_75t_R   g097(.A(p2), .B(p3), .C(p4), .Y(new_n116_));
  NOR2x1_ASAP7_75t_R   g098(.A(p5), .B(new_n35_), .Y(new_n117_));
  AO22x1_ASAP7_75t_R   g099(.A1(new_n114_), .A2(new_n115_), .B1(new_n116_), .B2(new_n117_), .Y(new_n118_));
  AOI221x1_ASAP7_75t_R g100(.A1(new_n54_), .A2(new_n109_), .B1(new_n112_), .B2(new_n113_), .C(new_n118_), .Y(new_n119_));
  OAI21x1_ASAP7_75t_R  g101(.A1(new_n101_), .A2(new_n108_), .B(new_n119_), .Y(new_n120_));
  OAI21x1_ASAP7_75t_R  g102(.A1(new_n117_), .A2(new_n109_), .B(p7), .Y(new_n121_));
  OR3x1_ASAP7_75t_R    g103(.A(new_n57_), .B(new_n27_), .C(p7), .Y(new_n122_));
  NAND2x1_ASAP7_75t_R  g104(.A(new_n95_), .B(new_n122_), .Y(new_n123_));
  OR3x1_ASAP7_75t_R    g105(.A(new_n35_), .B(new_n27_), .C(p9), .Y(new_n124_));
  OA21x2_ASAP7_75t_R   g106(.A1(p9), .A2(p7), .B(p8), .Y(new_n125_));
  AOI22x1_ASAP7_75t_R  g107(.A1(new_n123_), .A2(new_n114_), .B1(new_n124_), .B2(new_n125_), .Y(new_n126_));
  OAI21x1_ASAP7_75t_R  g108(.A1(p9), .A2(new_n121_), .B(new_n126_), .Y(new_n127_));
  AO21x1_ASAP7_75t_R   g109(.A1(new_n39_), .A2(new_n120_), .B(new_n127_), .Y(o2));
  OR5x1_ASAP7_75t_R    g110(.A(p3), .B(p5), .C(p6), .D(p7), .E(p4), .Y(new_n129_));
  OR4x2_ASAP7_75t_R    g111(.A(new_n61_), .B(new_n35_), .C(new_n29_), .D(new_n27_), .Y(new_n130_));
  OR3x1_ASAP7_75t_R    g112(.A(new_n130_), .B(new_n22_), .C(p1), .Y(new_n131_));
  OR3x1_ASAP7_75t_R    g113(.A(p2), .B(p9), .C(p8), .Y(new_n132_));
  AO21x1_ASAP7_75t_R   g114(.A1(new_n129_), .A2(new_n131_), .B(new_n132_), .Y(o3));
  AND2x2_ASAP7_75t_R   g115(.A(p2), .B(p7), .Y(new_n134_));
  AO21x1_ASAP7_75t_R   g116(.A1(new_n30_), .A2(p1), .B(new_n134_), .Y(new_n135_));
  AND3x1_ASAP7_75t_R   g117(.A(new_n114_), .B(new_n99_), .C(new_n57_), .Y(new_n136_));
  AOI22x1_ASAP7_75t_R  g118(.A1(new_n135_), .A2(new_n136_), .B1(new_n130_), .B2(p8), .Y(new_n137_));
  AND3x1_ASAP7_75t_R   g119(.A(new_n78_), .B(p10), .C(p0), .Y(new_n138_));
  NOR2x1_ASAP7_75t_R   g120(.A(new_n138_), .B(new_n109_), .Y(new_n139_));
  AO21x1_ASAP7_75t_R   g121(.A1(new_n35_), .A2(new_n90_), .B(new_n82_), .Y(new_n140_));
  NOR2x1_ASAP7_75t_R   g122(.A(p6), .B(p4), .Y(new_n141_));
  AO22x1_ASAP7_75t_R   g123(.A1(p5), .A2(new_n35_), .B1(p3), .B2(new_n141_), .Y(new_n142_));
  AO21x1_ASAP7_75t_R   g124(.A1(new_n46_), .A2(new_n140_), .B(new_n142_), .Y(new_n143_));
  OA21x2_ASAP7_75t_R   g125(.A1(new_n53_), .A2(new_n139_), .B(new_n143_), .Y(new_n144_));
  AO21x1_ASAP7_75t_R   g126(.A1(p7), .A2(new_n137_), .B(p9), .Y(new_n145_));
  AO21x1_ASAP7_75t_R   g127(.A1(new_n137_), .A2(new_n144_), .B(new_n145_), .Y(o4));
  OR5x1_ASAP7_75t_R    g128(.A(p6), .B(new_n53_), .C(new_n102_), .D(p7), .E(p4), .Y(new_n147_));
  AO21x1_ASAP7_75t_R   g129(.A1(new_n30_), .A2(new_n54_), .B(new_n130_), .Y(new_n148_));
  AO21x1_ASAP7_75t_R   g130(.A1(new_n147_), .A2(new_n148_), .B(new_n22_), .Y(new_n149_));
  AND3x1_ASAP7_75t_R   g131(.A(new_n46_), .B(new_n82_), .C(p1), .Y(new_n150_));
  INVx1_ASAP7_75t_R    g132(.A(new_n48_), .Y(new_n151_));
  OR3x1_ASAP7_75t_R    g133(.A(new_n150_), .B(new_n151_), .C(new_n78_), .Y(new_n152_));
  NAND3x1_ASAP7_75t_R  g134(.A(new_n149_), .B(new_n39_), .C(new_n152_), .Y(o5));
  OR3x1_ASAP7_75t_R    g135(.A(new_n150_), .B(new_n40_), .C(new_n151_), .Y(o6));
endmodule


