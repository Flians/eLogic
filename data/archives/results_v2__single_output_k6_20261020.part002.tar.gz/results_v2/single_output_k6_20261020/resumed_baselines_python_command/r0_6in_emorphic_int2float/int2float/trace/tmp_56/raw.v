// Benchmark "/tmp/" written by ABC on Tue Oct 20 17:46:19 2026

module \/tmp/  ( 
    p2, p1, p3, p9, p10, p6, p5, p4, p8, p0, p7,
    o0, o1, o2, o3, o4, o5, o6  );
  input  p2, p1, p3, p9, p10, p6, p5, p4, p8, p0, p7;
  output o0, o1, o2, o3, o4, o5, o6;
  wire new_n19_, new_n20_, new_n21_, new_n22_, new_n23_, new_n24_, new_n25_,
    new_n26_, new_n27_, new_n28_, new_n29_, new_n30_, new_n31_, new_n32_,
    new_n33_, new_n34_, new_n35_, new_n36_, new_n37_, new_n38_, new_n39_,
    new_n40_, new_n41_, new_n42_, new_n43_, new_n44_, new_n45_, new_n46_,
    new_n47_, new_n48_, new_n49_, new_n50_, new_n51_, new_n52_, new_n53_,
    new_n54_, new_n55_, new_n56_, new_n57_, new_n58_, new_n59_, new_n60_,
    new_n61_, new_n62_, new_n63_, new_n64_, new_n66_, new_n67_, new_n68_,
    new_n69_, new_n70_, new_n71_, new_n72_, new_n73_, new_n74_, new_n75_,
    new_n76_, new_n77_, new_n78_, new_n79_, new_n80_, new_n81_, new_n82_,
    new_n83_, new_n84_, new_n85_, new_n86_, new_n87_, new_n88_, new_n89_,
    new_n90_, new_n91_, new_n92_, new_n93_, new_n94_, new_n95_, new_n96_,
    new_n97_, new_n98_, new_n99_, new_n101_, new_n102_, new_n103_,
    new_n104_, new_n105_, new_n106_, new_n107_, new_n108_, new_n109_,
    new_n110_, new_n111_, new_n112_, new_n113_, new_n114_, new_n115_,
    new_n116_, new_n117_, new_n118_, new_n119_, new_n120_, new_n121_,
    new_n122_, new_n123_, new_n124_, new_n125_, new_n126_, new_n127_,
    new_n128_, new_n129_, new_n130_, new_n131_, new_n132_, new_n134_,
    new_n135_, new_n136_, new_n137_, new_n138_, new_n140_, new_n141_,
    new_n142_, new_n143_, new_n144_, new_n145_, new_n146_, new_n147_,
    new_n148_, new_n149_, new_n151_, new_n152_, new_n153_, new_n154_,
    new_n155_, new_n157_;
  INVx1_ASAP7_75t_R    g000(.A(p3), .Y(new_n19_));
  NAND2x1_ASAP7_75t_R  g001(.A(p7), .B(new_n19_), .Y(new_n20_));
  AND2x2_ASAP7_75t_R   g002(.A(p4), .B(new_n20_), .Y(new_n21_));
  INVx1_ASAP7_75t_R    g003(.A(p10), .Y(new_n22_));
  NAND2x1_ASAP7_75t_R  g004(.A(p3), .B(p0), .Y(new_n23_));
  AOI211x1_ASAP7_75t_R g005(.A1(new_n22_), .A2(new_n23_), .B(p6), .C(p5), .Y(new_n24_));
  AO21x1_ASAP7_75t_R   g006(.A1(new_n23_), .A2(new_n20_), .B(new_n22_), .Y(new_n25_));
  AO21x1_ASAP7_75t_R   g007(.A1(p3), .A2(p7), .B(p4), .Y(new_n26_));
  AOI21x1_ASAP7_75t_R  g008(.A1(new_n24_), .A2(new_n25_), .B(new_n26_), .Y(new_n27_));
  INVx1_ASAP7_75t_R    g009(.A(p2), .Y(new_n28_));
  INVx1_ASAP7_75t_R    g010(.A(p4), .Y(new_n29_));
  INVx1_ASAP7_75t_R    g011(.A(p0), .Y(new_n30_));
  OR5x1_ASAP7_75t_R    g012(.A(new_n28_), .B(new_n29_), .C(new_n30_), .D(p1), .E(p6), .Y(new_n31_));
  AND2x2_ASAP7_75t_R   g013(.A(p2), .B(p3), .Y(new_n32_));
  INVx1_ASAP7_75t_R    g014(.A(p6), .Y(new_n33_));
  NOR2x1_ASAP7_75t_R   g015(.A(p2), .B(p3), .Y(new_n34_));
  OR3x1_ASAP7_75t_R    g016(.A(new_n32_), .B(new_n33_), .C(new_n34_), .Y(new_n35_));
  AO21x1_ASAP7_75t_R   g017(.A1(new_n31_), .A2(new_n35_), .B(p7), .Y(new_n36_));
  OA21x2_ASAP7_75t_R   g018(.A1(new_n21_), .A2(new_n27_), .B(new_n36_), .Y(new_n37_));
  NOR2x1_ASAP7_75t_R   g019(.A(p9), .B(p8), .Y(new_n38_));
  INVx1_ASAP7_75t_R    g020(.A(new_n38_), .Y(new_n39_));
  INVx1_ASAP7_75t_R    g021(.A(p9), .Y(new_n40_));
  INVx1_ASAP7_75t_R    g022(.A(p5), .Y(new_n41_));
  NAND2x1_ASAP7_75t_R  g023(.A(p4), .B(new_n41_), .Y(new_n42_));
  NOR2x1_ASAP7_75t_R   g024(.A(p3), .B(new_n33_), .Y(new_n43_));
  AND2x2_ASAP7_75t_R   g025(.A(p3), .B(p7), .Y(new_n44_));
  OR5x1_ASAP7_75t_R    g026(.A(p1), .B(new_n43_), .C(new_n30_), .D(new_n32_), .E(new_n44_), .Y(new_n45_));
  INVx1_ASAP7_75t_R    g027(.A(new_n42_), .Y(new_n46_));
  NOR2x1_ASAP7_75t_R   g028(.A(p6), .B(p7), .Y(new_n47_));
  AO31x2_ASAP7_75t_R   g029(.A1(new_n47_), .A2(p1), .A3(new_n30_), .B(p8), .Y(new_n48_));
  AND3x1_ASAP7_75t_R   g030(.A(new_n29_), .B(p5), .C(p8), .Y(new_n49_));
  AOI21x1_ASAP7_75t_R  g031(.A1(new_n46_), .A2(new_n48_), .B(new_n49_), .Y(new_n50_));
  OAI21x1_ASAP7_75t_R  g032(.A1(new_n42_), .A2(new_n45_), .B(new_n50_), .Y(new_n51_));
  NAND2x1_ASAP7_75t_R  g033(.A(p6), .B(new_n41_), .Y(new_n52_));
  INVx1_ASAP7_75t_R    g034(.A(p8), .Y(new_n53_));
  INVx1_ASAP7_75t_R    g035(.A(p7), .Y(new_n54_));
  OR3x1_ASAP7_75t_R    g036(.A(new_n41_), .B(new_n53_), .C(new_n54_), .Y(new_n55_));
  AO21x1_ASAP7_75t_R   g037(.A1(new_n52_), .A2(new_n55_), .B(new_n40_), .Y(new_n56_));
  NAND2x1_ASAP7_75t_R  g038(.A(p5), .B(new_n33_), .Y(new_n57_));
  INVx1_ASAP7_75t_R    g039(.A(p1), .Y(new_n58_));
  NAND2x1_ASAP7_75t_R  g040(.A(new_n28_), .B(new_n58_), .Y(new_n59_));
  NOR2x1_ASAP7_75t_R   g041(.A(p8), .B(p7), .Y(new_n60_));
  NAND2x1_ASAP7_75t_R  g042(.A(p2), .B(p1), .Y(new_n61_));
  NAND3x1_ASAP7_75t_R  g043(.A(new_n59_), .B(new_n60_), .C(new_n61_), .Y(new_n62_));
  AOI22x1_ASAP7_75t_R  g044(.A1(new_n56_), .A2(new_n57_), .B1(new_n40_), .B2(new_n62_), .Y(new_n63_));
  AOI21x1_ASAP7_75t_R  g045(.A1(new_n40_), .A2(new_n51_), .B(new_n63_), .Y(new_n64_));
  OAI21x1_ASAP7_75t_R  g046(.A1(new_n37_), .A2(new_n39_), .B(new_n64_), .Y(o0));
  NAND2x1_ASAP7_75t_R  g047(.A(p2), .B(p3), .Y(new_n66_));
  AND3x1_ASAP7_75t_R   g048(.A(new_n53_), .B(new_n54_), .C(p6), .Y(new_n67_));
  NOR2x1_ASAP7_75t_R   g049(.A(p6), .B(new_n53_), .Y(new_n68_));
  AO21x1_ASAP7_75t_R   g050(.A1(new_n66_), .A2(new_n67_), .B(new_n68_), .Y(new_n69_));
  OAI21x1_ASAP7_75t_R  g051(.A1(p6), .A2(p5), .B(new_n19_), .Y(new_n70_));
  OAI21x1_ASAP7_75t_R  g052(.A1(p8), .A2(p7), .B(p3), .Y(new_n71_));
  AO21x1_ASAP7_75t_R   g053(.A1(p1), .A2(p0), .B(p6), .Y(new_n72_));
  AND5x1_ASAP7_75t_R   g054(.A(p2), .B(new_n70_), .C(p4), .D(new_n71_), .E(new_n72_), .Y(new_n73_));
  AOI21x1_ASAP7_75t_R  g055(.A1(new_n29_), .A2(new_n69_), .B(new_n73_), .Y(new_n74_));
  NOR2x1_ASAP7_75t_R   g056(.A(p3), .B(p8), .Y(new_n75_));
  AOI21x1_ASAP7_75t_R  g057(.A1(new_n58_), .A2(new_n33_), .B(new_n75_), .Y(new_n76_));
  OAI22x1_ASAP7_75t_R  g058(.A1(new_n76_), .A2(p0), .B1(p8), .B2(new_n54_), .Y(new_n77_));
  NAND2x1_ASAP7_75t_R  g059(.A(p1), .B(p0), .Y(new_n78_));
  AO21x1_ASAP7_75t_R   g060(.A1(p1), .A2(new_n22_), .B(p6), .Y(new_n79_));
  AOI211x1_ASAP7_75t_R g061(.A1(p10), .A2(new_n78_), .B(new_n19_), .C(new_n79_), .Y(new_n80_));
  NOR2x1_ASAP7_75t_R   g062(.A(p5), .B(p4), .Y(new_n81_));
  OAI21x1_ASAP7_75t_R  g063(.A1(new_n77_), .A2(new_n80_), .B(new_n81_), .Y(new_n82_));
  AND2x2_ASAP7_75t_R   g064(.A(p5), .B(p4), .Y(new_n83_));
  OR3x1_ASAP7_75t_R    g065(.A(new_n68_), .B(new_n83_), .C(new_n75_), .Y(new_n84_));
  OAI21x1_ASAP7_75t_R  g066(.A1(new_n75_), .A2(new_n68_), .B(p5), .Y(new_n85_));
  INVx1_ASAP7_75t_R    g067(.A(new_n60_), .Y(new_n86_));
  NAND3x1_ASAP7_75t_R  g068(.A(new_n84_), .B(new_n85_), .C(new_n86_), .Y(new_n87_));
  NAND3x1_ASAP7_75t_R  g069(.A(new_n74_), .B(new_n82_), .C(new_n87_), .Y(new_n88_));
  NAND2x1_ASAP7_75t_R  g070(.A(p2), .B(new_n19_), .Y(new_n89_));
  OA21x2_ASAP7_75t_R   g071(.A1(new_n58_), .A2(new_n89_), .B(new_n33_), .Y(new_n90_));
  AND2x2_ASAP7_75t_R   g072(.A(p3), .B(new_n61_), .Y(new_n91_));
  NAND2x1_ASAP7_75t_R  g073(.A(p5), .B(new_n53_), .Y(new_n92_));
  AO21x1_ASAP7_75t_R   g074(.A1(p1), .A2(p0), .B(p2), .Y(new_n93_));
  OAI22x1_ASAP7_75t_R  g075(.A1(new_n91_), .A2(new_n92_), .B1(new_n42_), .B2(new_n93_), .Y(new_n94_));
  AOI21x1_ASAP7_75t_R  g076(.A1(new_n90_), .A2(new_n94_), .B(p9), .Y(new_n95_));
  AO21x1_ASAP7_75t_R   g077(.A1(p6), .A2(p5), .B(p7), .Y(new_n96_));
  NAND2x1_ASAP7_75t_R  g078(.A(p9), .B(p7), .Y(new_n97_));
  OR3x1_ASAP7_75t_R    g079(.A(new_n97_), .B(new_n33_), .C(new_n41_), .Y(new_n98_));
  OAI22x1_ASAP7_75t_R  g080(.A1(new_n95_), .A2(new_n96_), .B1(p8), .B2(new_n98_), .Y(new_n99_));
  AOI21x1_ASAP7_75t_R  g081(.A1(new_n40_), .A2(new_n88_), .B(new_n99_), .Y(o1));
  AND2x2_ASAP7_75t_R   g082(.A(p3), .B(p4), .Y(new_n101_));
  AO32x1_ASAP7_75t_R   g083(.A1(new_n32_), .A2(new_n58_), .A3(new_n41_), .B1(new_n101_), .B2(new_n28_), .Y(new_n102_));
  OAI21x1_ASAP7_75t_R  g084(.A1(p1), .A2(new_n102_), .B(new_n47_), .Y(new_n103_));
  NAND2x1_ASAP7_75t_R  g085(.A(p10), .B(p0), .Y(new_n104_));
  NOR2x1_ASAP7_75t_R   g086(.A(p3), .B(p5), .Y(new_n105_));
  AO21x1_ASAP7_75t_R   g087(.A1(new_n104_), .A2(new_n32_), .B(new_n105_), .Y(new_n106_));
  NAND2x1_ASAP7_75t_R  g088(.A(p3), .B(new_n28_), .Y(new_n107_));
  NAND2x1_ASAP7_75t_R  g089(.A(p10), .B(new_n41_), .Y(new_n108_));
  NAND3x1_ASAP7_75t_R  g090(.A(new_n19_), .B(p2), .C(p4), .Y(new_n109_));
  OAI21x1_ASAP7_75t_R  g091(.A1(new_n107_), .A2(new_n108_), .B(new_n109_), .Y(new_n110_));
  AOI221x1_ASAP7_75t_R g092(.A1(new_n29_), .A2(new_n106_), .B1(new_n110_), .B2(p0), .C(new_n102_), .Y(new_n111_));
  NAND2x1_ASAP7_75t_R  g093(.A(p3), .B(p4), .Y(new_n112_));
  NOR2x1_ASAP7_75t_R   g094(.A(new_n112_), .B(new_n57_), .Y(new_n113_));
  NAND3x1_ASAP7_75t_R  g095(.A(new_n41_), .B(new_n30_), .C(p4), .Y(new_n114_));
  NAND3x1_ASAP7_75t_R  g096(.A(new_n29_), .B(p1), .C(p5), .Y(new_n115_));
  NAND3x1_ASAP7_75t_R  g097(.A(new_n114_), .B(new_n115_), .C(new_n32_), .Y(new_n116_));
  OA21x2_ASAP7_75t_R   g098(.A1(new_n32_), .A2(new_n83_), .B(new_n54_), .Y(new_n117_));
  AND2x2_ASAP7_75t_R   g099(.A(p6), .B(p5), .Y(new_n118_));
  AND3x1_ASAP7_75t_R   g100(.A(p2), .B(p3), .C(p4), .Y(new_n119_));
  NOR2x1_ASAP7_75t_R   g101(.A(p5), .B(new_n33_), .Y(new_n120_));
  AO22x1_ASAP7_75t_R   g102(.A1(new_n118_), .A2(new_n112_), .B1(new_n119_), .B2(new_n120_), .Y(new_n121_));
  AOI221x1_ASAP7_75t_R g103(.A1(new_n58_), .A2(new_n113_), .B1(new_n116_), .B2(new_n117_), .C(new_n121_), .Y(new_n122_));
  OAI21x1_ASAP7_75t_R  g104(.A1(new_n103_), .A2(new_n111_), .B(new_n122_), .Y(new_n123_));
  NAND2x1_ASAP7_75t_R  g105(.A(p5), .B(p4), .Y(new_n124_));
  OR3x1_ASAP7_75t_R    g106(.A(new_n124_), .B(new_n19_), .C(p6), .Y(new_n125_));
  AO21x1_ASAP7_75t_R   g107(.A1(new_n52_), .A2(new_n125_), .B(new_n54_), .Y(new_n126_));
  OR3x1_ASAP7_75t_R    g108(.A(new_n29_), .B(new_n53_), .C(p7), .Y(new_n127_));
  NAND2x1_ASAP7_75t_R  g109(.A(new_n97_), .B(new_n127_), .Y(new_n128_));
  OR3x1_ASAP7_75t_R    g110(.A(new_n33_), .B(new_n29_), .C(p9), .Y(new_n129_));
  OA21x2_ASAP7_75t_R   g111(.A1(p9), .A2(p7), .B(p8), .Y(new_n130_));
  AOI22x1_ASAP7_75t_R  g112(.A1(new_n128_), .A2(new_n118_), .B1(new_n129_), .B2(new_n130_), .Y(new_n131_));
  OAI21x1_ASAP7_75t_R  g113(.A1(p9), .A2(new_n126_), .B(new_n131_), .Y(new_n132_));
  AO21x1_ASAP7_75t_R   g114(.A1(new_n38_), .A2(new_n123_), .B(new_n132_), .Y(o2));
  NOR2x1_ASAP7_75t_R   g115(.A(p6), .B(p4), .Y(new_n134_));
  AND3x1_ASAP7_75t_R   g116(.A(new_n105_), .B(new_n134_), .C(new_n54_), .Y(new_n135_));
  AND3x1_ASAP7_75t_R   g117(.A(new_n83_), .B(p6), .C(p7), .Y(new_n136_));
  AND3x1_ASAP7_75t_R   g118(.A(new_n136_), .B(new_n58_), .C(p3), .Y(new_n137_));
  NOR2x1_ASAP7_75t_R   g119(.A(new_n135_), .B(new_n137_), .Y(new_n138_));
  OR3x1_ASAP7_75t_R    g120(.A(new_n138_), .B(p2), .C(new_n39_), .Y(o3));
  OA21x2_ASAP7_75t_R   g121(.A1(new_n28_), .A2(p7), .B(new_n101_), .Y(new_n140_));
  AND3x1_ASAP7_75t_R   g122(.A(new_n140_), .B(new_n59_), .C(new_n118_), .Y(new_n141_));
  OR3x1_ASAP7_75t_R    g123(.A(new_n55_), .B(new_n33_), .C(new_n29_), .Y(new_n142_));
  OAI21x1_ASAP7_75t_R  g124(.A1(p8), .A2(new_n141_), .B(new_n142_), .Y(new_n143_));
  INVx1_ASAP7_75t_R    g125(.A(new_n81_), .Y(new_n144_));
  OA21x2_ASAP7_75t_R   g126(.A1(new_n144_), .A2(new_n104_), .B(new_n125_), .Y(new_n145_));
  OR3x1_ASAP7_75t_R    g127(.A(new_n145_), .B(p7), .C(new_n61_), .Y(new_n146_));
  OAI21x1_ASAP7_75t_R  g128(.A1(p6), .A2(new_n78_), .B(new_n124_), .Y(new_n147_));
  AO21x1_ASAP7_75t_R   g129(.A1(p5), .A2(new_n33_), .B(p7), .Y(new_n148_));
  AO221x2_ASAP7_75t_R  g130(.A1(p3), .A2(new_n134_), .B1(new_n147_), .B2(new_n32_), .C(new_n148_), .Y(new_n149_));
  AO31x2_ASAP7_75t_R   g131(.A1(new_n143_), .A2(new_n146_), .A3(new_n149_), .B(p9), .Y(o4));
  OR3x1_ASAP7_75t_R    g132(.A(new_n66_), .B(new_n124_), .C(new_n58_), .Y(new_n151_));
  INVx1_ASAP7_75t_R    g133(.A(new_n47_), .Y(new_n152_));
  NOR2x1_ASAP7_75t_R   g134(.A(new_n81_), .B(new_n152_), .Y(new_n153_));
  AND5x1_ASAP7_75t_R   g135(.A(p2), .B(new_n33_), .C(new_n29_), .D(p10), .E(p0), .Y(new_n154_));
  AO32x1_ASAP7_75t_R   g136(.A1(p1), .A2(new_n154_), .A3(new_n54_), .B1(new_n136_), .B2(new_n59_), .Y(new_n155_));
  AO221x2_ASAP7_75t_R  g137(.A1(new_n151_), .A2(new_n153_), .B1(new_n155_), .B2(p3), .C(new_n39_), .Y(o5));
  INVx1_ASAP7_75t_R    g138(.A(new_n151_), .Y(new_n157_));
  OR3x1_ASAP7_75t_R    g139(.A(new_n157_), .B(new_n39_), .C(new_n152_), .Y(o6));
endmodule


