// Benchmark "/home/flynn/workplace/MIGBalance/results_v2/single_output_k6_20261020/resumed_baselines_python_command/r0_6in_eqmap_area-delay_router/router/eqmap_lut_amap/stage" written by ABC on Tue Oct 20 18:09:46 2026

module \/home/flynn/workplace/MIGBalance/results_v2/single_output_k6_20261020/resumed_baselines_python_command/r0_6in_eqmap_area-delay_router/router/eqmap_lut_amap/stage  ( 
    \dest_x[0] , \dest_x[10] , \dest_x[11] , \dest_x[12] , \dest_x[13] ,
    \dest_x[14] , \dest_x[15] , \dest_x[16] , \dest_x[17] , \dest_x[18] ,
    \dest_x[19] , \dest_x[1] , \dest_x[20] , \dest_x[21] , \dest_x[22] ,
    \dest_x[23] , \dest_x[24] , \dest_x[25] , \dest_x[26] , \dest_x[27] ,
    \dest_x[28] , \dest_x[29] , \dest_x[2] , \dest_x[3] , \dest_x[4] ,
    \dest_x[5] , \dest_x[6] , \dest_x[7] , \dest_x[8] , \dest_x[9] ,
    \dest_y[0] , \dest_y[10] , \dest_y[11] , \dest_y[12] , \dest_y[13] ,
    \dest_y[14] , \dest_y[15] , \dest_y[16] , \dest_y[17] , \dest_y[18] ,
    \dest_y[19] , \dest_y[1] , \dest_y[20] , \dest_y[21] , \dest_y[22] ,
    \dest_y[23] , \dest_y[24] , \dest_y[25] , \dest_y[26] , \dest_y[27] ,
    \dest_y[28] , \dest_y[29] , \dest_y[2] , \dest_y[3] , \dest_y[4] ,
    \dest_y[5] , \dest_y[6] , \dest_y[7] , \dest_y[8] , \dest_y[9] ,
    \outport[0] , \outport[10] , \outport[11] , \outport[12] ,
    \outport[13] , \outport[14] , \outport[15] , \outport[16] ,
    \outport[17] , \outport[18] , \outport[19] , \outport[1] ,
    \outport[20] , \outport[21] , \outport[22] , \outport[23] ,
    \outport[24] , \outport[25] , \outport[26] , \outport[27] ,
    \outport[28] , \outport[29] , \outport[2] , \outport[3] , \outport[4] ,
    \outport[5] , \outport[6] , \outport[7] , \outport[8] , \outport[9]   );
  input  \dest_x[0] , \dest_x[10] , \dest_x[11] , \dest_x[12] ,
    \dest_x[13] , \dest_x[14] , \dest_x[15] , \dest_x[16] , \dest_x[17] ,
    \dest_x[18] , \dest_x[19] , \dest_x[1] , \dest_x[20] , \dest_x[21] ,
    \dest_x[22] , \dest_x[23] , \dest_x[24] , \dest_x[25] , \dest_x[26] ,
    \dest_x[27] , \dest_x[28] , \dest_x[29] , \dest_x[2] , \dest_x[3] ,
    \dest_x[4] , \dest_x[5] , \dest_x[6] , \dest_x[7] , \dest_x[8] ,
    \dest_x[9] , \dest_y[0] , \dest_y[10] , \dest_y[11] , \dest_y[12] ,
    \dest_y[13] , \dest_y[14] , \dest_y[15] , \dest_y[16] , \dest_y[17] ,
    \dest_y[18] , \dest_y[19] , \dest_y[1] , \dest_y[20] , \dest_y[21] ,
    \dest_y[22] , \dest_y[23] , \dest_y[24] , \dest_y[25] , \dest_y[26] ,
    \dest_y[27] , \dest_y[28] , \dest_y[29] , \dest_y[2] , \dest_y[3] ,
    \dest_y[4] , \dest_y[5] , \dest_y[6] , \dest_y[7] , \dest_y[8] ,
    \dest_y[9] ;
  output \outport[0] , \outport[10] , \outport[11] , \outport[12] ,
    \outport[13] , \outport[14] , \outport[15] , \outport[16] ,
    \outport[17] , \outport[18] , \outport[19] , \outport[1] ,
    \outport[20] , \outport[21] , \outport[22] , \outport[23] ,
    \outport[24] , \outport[25] , \outport[26] , \outport[27] ,
    \outport[28] , \outport[29] , \outport[2] , \outport[3] , \outport[4] ,
    \outport[5] , \outport[6] , \outport[7] , \outport[8] , \outport[9] ;
  wire new_n91_, new_n92_, new_n93_, new_n94_, new_n95_, new_n96_, new_n97_,
    new_n98_, new_n99_, new_n100_, new_n101_, new_n102_, new_n103_,
    new_n104_, new_n105_, new_n106_, new_n107_, new_n108_, new_n109_,
    new_n110_, new_n111_, new_n112_, new_n113_, new_n114_, new_n115_,
    new_n116_, new_n117_, new_n118_, new_n119_, new_n120_, new_n121_,
    new_n122_, new_n123_, new_n124_, new_n125_, new_n126_, new_n127_,
    new_n128_, new_n129_, new_n130_, new_n131_, new_n132_, new_n133_,
    new_n134_, new_n135_, new_n136_, new_n137_, new_n138_, new_n139_,
    new_n140_, new_n141_, new_n142_, new_n143_, new_n144_, new_n145_,
    new_n146_, new_n147_, new_n148_, new_n149_, new_n150_, new_n151_,
    new_n152_, new_n153_, new_n154_, new_n155_, new_n156_, new_n157_,
    new_n158_, new_n159_, new_n160_, new_n162_, new_n163_, new_n164_,
    new_n165_, new_n166_, new_n167_, new_n168_, new_n169_, new_n170_,
    new_n171_, new_n172_, new_n173_, new_n174_, new_n175_, new_n176_,
    new_n177_, new_n178_, new_n179_, new_n180_, new_n181_, new_n182_,
    new_n183_, new_n184_, new_n185_, new_n186_, new_n187_, new_n188_,
    new_n189_, new_n190_, new_n191_, new_n192_, new_n193_, new_n194_,
    new_n195_, new_n196_, new_n197_, new_n198_, new_n199_, new_n201_,
    new_n202_, new_n203_, new_n204_;
  INVx1_ASAP7_75t_R    g000(.A(\dest_x[0] ), .Y(new_n91_));
  INVx1_ASAP7_75t_R    g001(.A(\dest_x[10] ), .Y(new_n92_));
  INVx1_ASAP7_75t_R    g002(.A(\dest_x[11] ), .Y(new_n93_));
  INVx1_ASAP7_75t_R    g003(.A(\dest_x[12] ), .Y(new_n94_));
  INVx1_ASAP7_75t_R    g004(.A(\dest_x[13] ), .Y(new_n95_));
  INVx1_ASAP7_75t_R    g005(.A(\dest_x[14] ), .Y(new_n96_));
  INVx1_ASAP7_75t_R    g006(.A(\dest_x[15] ), .Y(new_n97_));
  INVx1_ASAP7_75t_R    g007(.A(\dest_x[16] ), .Y(new_n98_));
  INVx1_ASAP7_75t_R    g008(.A(\dest_x[17] ), .Y(new_n99_));
  INVx1_ASAP7_75t_R    g009(.A(\dest_x[19] ), .Y(new_n100_));
  INVx1_ASAP7_75t_R    g010(.A(\dest_x[20] ), .Y(new_n101_));
  INVx1_ASAP7_75t_R    g011(.A(\dest_x[23] ), .Y(new_n102_));
  INVx1_ASAP7_75t_R    g012(.A(\dest_x[24] ), .Y(new_n103_));
  INVx1_ASAP7_75t_R    g013(.A(\dest_x[25] ), .Y(new_n104_));
  INVx1_ASAP7_75t_R    g014(.A(\dest_x[26] ), .Y(new_n105_));
  INVx1_ASAP7_75t_R    g015(.A(\dest_x[9] ), .Y(new_n106_));
  INVx1_ASAP7_75t_R    g016(.A(\dest_y[0] ), .Y(new_n107_));
  INVx1_ASAP7_75t_R    g017(.A(\dest_y[11] ), .Y(new_n108_));
  INVx1_ASAP7_75t_R    g018(.A(\dest_y[16] ), .Y(new_n109_));
  INVx1_ASAP7_75t_R    g019(.A(\dest_y[17] ), .Y(new_n110_));
  INVx1_ASAP7_75t_R    g020(.A(\dest_y[18] ), .Y(new_n111_));
  INVx1_ASAP7_75t_R    g021(.A(\dest_y[19] ), .Y(new_n112_));
  INVx1_ASAP7_75t_R    g022(.A(\dest_y[1] ), .Y(new_n113_));
  INVx1_ASAP7_75t_R    g023(.A(\dest_y[20] ), .Y(new_n114_));
  INVx1_ASAP7_75t_R    g024(.A(\dest_y[22] ), .Y(new_n115_));
  INVx1_ASAP7_75t_R    g025(.A(\dest_y[23] ), .Y(new_n116_));
  INVx1_ASAP7_75t_R    g026(.A(\dest_y[9] ), .Y(new_n117_));
  NAND2x1_ASAP7_75t_R  g027(.A(\dest_x[24] ), .B(\dest_x[25] ), .Y(new_n118_));
  AO21x1_ASAP7_75t_R   g028(.A1(new_n92_), .A2(\dest_x[9] ), .B(\dest_x[10] ), .Y(new_n119_));
  AND4x2_ASAP7_75t_R   g029(.A(\dest_x[11] ), .B(new_n119_), .C(\dest_x[14] ), .D(new_n94_), .Y(new_n120_));
  AO21x1_ASAP7_75t_R   g030(.A1(\dest_x[12] ), .A2(\dest_x[14] ), .B(new_n120_), .Y(new_n121_));
  AOI22x1_ASAP7_75t_R  g031(.A1(\dest_x[13] ), .A2(\dest_x[14] ), .B1(new_n95_), .B2(new_n121_), .Y(new_n122_));
  OR3x1_ASAP7_75t_R    g032(.A(new_n97_), .B(new_n122_), .C(\dest_x[16] ), .Y(new_n123_));
  AOI21x1_ASAP7_75t_R  g033(.A1(new_n98_), .A2(new_n123_), .B(\dest_x[18] ), .Y(new_n124_));
  OA21x2_ASAP7_75t_R   g034(.A1(\dest_x[18] ), .A2(new_n124_), .B(\dest_x[17] ), .Y(new_n125_));
  AOI21x1_ASAP7_75t_R  g035(.A1(new_n99_), .A2(\dest_x[18] ), .B(new_n125_), .Y(new_n126_));
  OR3x1_ASAP7_75t_R    g036(.A(new_n100_), .B(new_n101_), .C(new_n126_), .Y(new_n127_));
  OAI21x1_ASAP7_75t_R  g037(.A1(\dest_x[21] ), .A2(\dest_x[22] ), .B(new_n127_), .Y(new_n128_));
  NAND2x1_ASAP7_75t_R  g038(.A(new_n127_), .B(new_n128_), .Y(new_n129_));
  AO21x1_ASAP7_75t_R   g039(.A1(new_n105_), .A2(new_n129_), .B(\dest_x[26] ), .Y(new_n130_));
  AND2x2_ASAP7_75t_R   g040(.A(\dest_x[23] ), .B(new_n130_), .Y(new_n131_));
  AO21x1_ASAP7_75t_R   g041(.A1(new_n102_), .A2(\dest_x[26] ), .B(new_n131_), .Y(new_n132_));
  AND3x1_ASAP7_75t_R   g042(.A(\dest_x[24] ), .B(\dest_x[25] ), .C(new_n132_), .Y(new_n133_));
  AO21x1_ASAP7_75t_R   g043(.A1(\dest_x[26] ), .A2(new_n118_), .B(new_n133_), .Y(new_n134_));
  AND4x2_ASAP7_75t_R   g044(.A(\dest_x[27] ), .B(\dest_x[28] ), .C(\dest_x[29] ), .D(new_n134_), .Y(new_n135_));
  OR4x2_ASAP7_75t_R    g045(.A(new_n101_), .B(new_n102_), .C(\dest_x[21] ), .D(\dest_x[22] ), .Y(new_n136_));
  INVx1_ASAP7_75t_R    g046(.A(new_n136_), .Y(new_n137_));
  AND5x1_ASAP7_75t_R   g047(.A(\dest_x[2] ), .B(\dest_x[8] ), .C(\dest_x[5] ), .D(\dest_x[4] ), .E(\dest_x[7] ), .Y(new_n138_));
  AND5x1_ASAP7_75t_R   g048(.A(\dest_x[0] ), .B(new_n94_), .C(\dest_x[6] ), .D(\dest_x[1] ), .E(\dest_x[11] ), .Y(new_n139_));
  AND5x1_ASAP7_75t_R   g049(.A(\dest_x[3] ), .B(new_n138_), .C(new_n95_), .D(new_n139_), .E(\dest_x[17] ), .Y(new_n140_));
  INVx1_ASAP7_75t_R    g050(.A(new_n140_), .Y(new_n141_));
  AND5x1_ASAP7_75t_R   g051(.A(\dest_x[15] ), .B(new_n98_), .C(\dest_x[19] ), .D(\dest_x[25] ), .E(\dest_x[29] ), .Y(new_n142_));
  INVx1_ASAP7_75t_R    g052(.A(new_n142_), .Y(new_n143_));
  AND3x1_ASAP7_75t_R   g053(.A(\dest_x[14] ), .B(\dest_x[28] ), .C(\dest_x[27] ), .Y(new_n144_));
  AO21x1_ASAP7_75t_R   g054(.A1(new_n105_), .A2(new_n144_), .B(new_n143_), .Y(new_n145_));
  AO21x1_ASAP7_75t_R   g055(.A1(new_n142_), .A2(new_n145_), .B(new_n141_), .Y(new_n146_));
  AO21x1_ASAP7_75t_R   g056(.A1(new_n140_), .A2(new_n146_), .B(new_n136_), .Y(new_n147_));
  AO21x1_ASAP7_75t_R   g057(.A1(new_n137_), .A2(new_n147_), .B(new_n103_), .Y(new_n148_));
  AO21x1_ASAP7_75t_R   g058(.A1(\dest_x[24] ), .A2(new_n148_), .B(new_n135_), .Y(new_n149_));
  INVx1_ASAP7_75t_R    g059(.A(new_n149_), .Y(new_n150_));
  NOR2x1_ASAP7_75t_R   g060(.A(new_n135_), .B(new_n149_), .Y(new_n151_));
  OA21x2_ASAP7_75t_R   g061(.A1(new_n135_), .A2(new_n151_), .B(\dest_x[16] ), .Y(new_n152_));
  OR5x1_ASAP7_75t_R    g062(.A(new_n96_), .B(\dest_x[1] ), .C(new_n100_), .D(new_n104_), .E(new_n103_), .Y(new_n153_));
  OR5x1_ASAP7_75t_R    g063(.A(\dest_x[2] ), .B(\dest_x[5] ), .C(\dest_x[4] ), .D(\dest_x[7] ), .E(new_n106_), .Y(new_n154_));
  OR5x1_ASAP7_75t_R    g064(.A(\dest_x[3] ), .B(new_n153_), .C(new_n154_), .D(\dest_x[6] ), .E(\dest_x[8] ), .Y(new_n155_));
  OR4x2_ASAP7_75t_R    g065(.A(\dest_x[13] ), .B(\dest_x[18] ), .C(\dest_x[26] ), .D(\dest_x[12] ), .Y(new_n156_));
  OR5x1_ASAP7_75t_R    g066(.A(\dest_x[10] ), .B(new_n155_), .C(new_n136_), .D(new_n156_), .E(new_n93_), .Y(new_n157_));
  INVx1_ASAP7_75t_R    g067(.A(new_n157_), .Y(new_n158_));
  AO21x1_ASAP7_75t_R   g068(.A1(new_n150_), .A2(new_n158_), .B(new_n157_), .Y(new_n159_));
  AO21x1_ASAP7_75t_R   g069(.A1(new_n135_), .A2(new_n159_), .B(new_n151_), .Y(new_n160_));
  AO21x1_ASAP7_75t_R   g070(.A1(new_n98_), .A2(new_n160_), .B(new_n152_), .Y(\outport[0] ));
  AO21x1_ASAP7_75t_R   g071(.A1(\dest_x[16] ), .A2(new_n158_), .B(new_n157_), .Y(new_n162_));
  NAND2x1_ASAP7_75t_R  g072(.A(new_n135_), .B(new_n162_), .Y(new_n163_));
  AND3x1_ASAP7_75t_R   g073(.A(\dest_y[27] ), .B(\dest_y[28] ), .C(\dest_y[29] ), .Y(new_n164_));
  AND4x2_ASAP7_75t_R   g074(.A(\dest_y[4] ), .B(\dest_y[8] ), .C(\dest_y[7] ), .D(\dest_y[6] ), .Y(new_n165_));
  AND5x1_ASAP7_75t_R   g075(.A(\dest_y[14] ), .B(\dest_y[15] ), .C(\dest_y[25] ), .D(\dest_y[24] ), .E(new_n165_), .Y(new_n166_));
  AND5x1_ASAP7_75t_R   g076(.A(\dest_y[3] ), .B(new_n166_), .C(\dest_y[2] ), .D(\dest_y[5] ), .E(new_n164_), .Y(new_n167_));
  INVx1_ASAP7_75t_R    g077(.A(new_n167_), .Y(new_n168_));
  OR5x1_ASAP7_75t_R    g078(.A(\dest_y[16] ), .B(new_n112_), .C(new_n116_), .D(\dest_y[22] ), .E(\dest_y[26] ), .Y(new_n169_));
  OR3x1_ASAP7_75t_R    g079(.A(\dest_y[13] ), .B(new_n113_), .C(new_n169_), .Y(new_n170_));
  OR5x1_ASAP7_75t_R    g080(.A(new_n108_), .B(new_n170_), .C(new_n110_), .D(new_n114_), .E(new_n168_), .Y(new_n171_));
  OR5x1_ASAP7_75t_R    g081(.A(\dest_y[4] ), .B(\dest_y[5] ), .C(\dest_y[7] ), .D(\dest_y[6] ), .E(new_n117_), .Y(new_n172_));
  OR4x2_ASAP7_75t_R    g082(.A(\dest_y[8] ), .B(new_n172_), .C(\dest_y[10] ), .D(\dest_y[21] ), .Y(new_n173_));
  OR4x2_ASAP7_75t_R    g083(.A(\dest_y[1] ), .B(\dest_y[3] ), .C(\dest_y[2] ), .D(\dest_y[13] ), .Y(new_n174_));
  AND4x2_ASAP7_75t_R   g084(.A(\dest_y[11] ), .B(\dest_y[20] ), .C(\dest_y[19] ), .D(\dest_y[27] ), .Y(new_n175_));
  INVx1_ASAP7_75t_R    g085(.A(new_n175_), .Y(new_n176_));
  OR5x1_ASAP7_75t_R    g086(.A(new_n174_), .B(new_n176_), .C(new_n169_), .D(\dest_y[18] ), .E(new_n173_), .Y(new_n177_));
  OA33x2_ASAP7_75t_R   g087(.A1(\dest_y[12] ), .A2(new_n171_), .A3(new_n107_), .B1(\dest_y[12] ), .B2(new_n177_), .B3(\dest_y[0] ), .Y(new_n178_));
  INVx1_ASAP7_75t_R    g088(.A(new_n178_), .Y(new_n179_));
  OR3x1_ASAP7_75t_R    g089(.A(\dest_y[10] ), .B(\dest_y[9] ), .C(new_n108_), .Y(new_n180_));
  AOI211x1_ASAP7_75t_R g090(.A1(\dest_y[11] ), .A2(new_n180_), .B(\dest_y[12] ), .C(\dest_y[13] ), .Y(new_n181_));
  INVx1_ASAP7_75t_R    g091(.A(new_n181_), .Y(new_n182_));
  AND4x2_ASAP7_75t_R   g092(.A(\dest_y[14] ), .B(\dest_y[15] ), .C(new_n182_), .D(new_n109_), .Y(new_n183_));
  OAI21x1_ASAP7_75t_R  g093(.A1(\dest_y[16] ), .A2(new_n183_), .B(new_n111_), .Y(new_n184_));
  AOI21x1_ASAP7_75t_R  g094(.A1(new_n111_), .A2(new_n184_), .B(new_n110_), .Y(new_n185_));
  AO21x1_ASAP7_75t_R   g095(.A1(new_n110_), .A2(\dest_y[18] ), .B(new_n185_), .Y(new_n186_));
  AND3x1_ASAP7_75t_R   g096(.A(\dest_y[19] ), .B(\dest_y[20] ), .C(new_n186_), .Y(new_n187_));
  AOI21x1_ASAP7_75t_R  g097(.A1(new_n115_), .A2(new_n187_), .B(\dest_y[22] ), .Y(new_n188_));
  NOR2x1_ASAP7_75t_R   g098(.A(\dest_y[21] ), .B(new_n188_), .Y(new_n189_));
  OR2x4_ASAP7_75t_R    g099(.A(\dest_y[21] ), .B(new_n189_), .Y(new_n190_));
  AND4x2_ASAP7_75t_R   g100(.A(\dest_y[24] ), .B(\dest_y[25] ), .C(\dest_y[23] ), .D(new_n190_), .Y(new_n191_));
  NAND2x1_ASAP7_75t_R  g101(.A(new_n164_), .B(new_n191_), .Y(new_n192_));
  NOR2x1_ASAP7_75t_R   g102(.A(\dest_y[26] ), .B(new_n192_), .Y(new_n193_));
  AO21x1_ASAP7_75t_R   g103(.A1(\dest_y[26] ), .A2(new_n164_), .B(new_n193_), .Y(new_n194_));
  INVx1_ASAP7_75t_R    g104(.A(new_n194_), .Y(new_n195_));
  AO21x1_ASAP7_75t_R   g105(.A1(new_n150_), .A2(new_n194_), .B(new_n195_), .Y(new_n196_));
  AO21x1_ASAP7_75t_R   g106(.A1(new_n107_), .A2(new_n149_), .B(new_n150_), .Y(new_n197_));
  AO22x1_ASAP7_75t_R   g107(.A1(\dest_x[0] ), .A2(new_n196_), .B1(new_n91_), .B2(new_n197_), .Y(new_n198_));
  AO22x1_ASAP7_75t_R   g108(.A1(new_n179_), .A2(new_n198_), .B1(new_n178_), .B2(new_n196_), .Y(new_n199_));
  AO32x1_ASAP7_75t_R   g109(.A1(new_n135_), .A2(new_n162_), .A3(new_n150_), .B1(new_n163_), .B2(new_n199_), .Y(\outport[1] ));
  OR5x1_ASAP7_75t_R    g110(.A(\dest_y[12] ), .B(new_n176_), .C(new_n174_), .D(new_n169_), .E(new_n173_), .Y(new_n201_));
  INVx1_ASAP7_75t_R    g111(.A(new_n201_), .Y(new_n202_));
  AND4x2_ASAP7_75t_R   g112(.A(new_n111_), .B(new_n202_), .C(\dest_x[0] ), .D(\dest_y[0] ), .Y(new_n203_));
  OR3x1_ASAP7_75t_R    g113(.A(\dest_y[18] ), .B(new_n201_), .C(new_n203_), .Y(new_n204_));
  AND4x2_ASAP7_75t_R   g114(.A(new_n149_), .B(new_n204_), .C(new_n163_), .D(new_n194_), .Y(\outport[2] ));
  assign               \outport[10]  = 1'b0;
  assign               \outport[11]  = 1'b0;
  assign               \outport[12]  = 1'b0;
  assign               \outport[13]  = 1'b0;
  assign               \outport[14]  = 1'b0;
  assign               \outport[15]  = 1'b0;
  assign               \outport[16]  = 1'b0;
  assign               \outport[17]  = 1'b0;
  assign               \outport[18]  = 1'b0;
  assign               \outport[19]  = 1'b0;
  assign               \outport[20]  = 1'b0;
  assign               \outport[21]  = 1'b0;
  assign               \outport[22]  = 1'b0;
  assign               \outport[23]  = 1'b0;
  assign               \outport[24]  = 1'b0;
  assign               \outport[25]  = 1'b0;
  assign               \outport[26]  = 1'b0;
  assign               \outport[27]  = 1'b0;
  assign               \outport[28]  = 1'b0;
  assign               \outport[29]  = 1'b0;
  assign               \outport[3]  = 1'b0;
  assign               \outport[4]  = 1'b0;
  assign               \outport[5]  = 1'b0;
  assign               \outport[6]  = 1'b0;
  assign               \outport[7]  = 1'b0;
  assign               \outport[8]  = 1'b0;
  assign               \outport[9]  = 1'b0;
endmodule


