// Benchmark "/home/flynn/workplace/MIGBalance/results_v2/single_output_k6_20261020/resumed_baselines_python_command/r0_6in_eqmap_area-delay_int2float/int2float/lut_stage_amap/stage" written by ABC on Tue Oct 20 17:44:06 2026

module \/home/flynn/workplace/MIGBalance/results_v2/single_output_k6_20261020/resumed_baselines_python_command/r0_6in_eqmap_area-delay_int2float/int2float/lut_stage_amap/stage  ( 
    \B[0] , \B[10] , \B[1] , \B[2] , \B[3] , \B[4] , \B[5] , \B[6] ,
    \B[7] , \B[8] , \B[9] ,
    \E[0] , \E[1] , \E[2] , \M[0] , \M[1] , \M[2] , \M[3]   );
  input  \B[0] , \B[10] , \B[1] , \B[2] , \B[3] , \B[4] , \B[5] , \B[6] ,
    \B[7] , \B[8] , \B[9] ;
  output \E[0] , \E[1] , \E[2] , \M[0] , \M[1] , \M[2] , \M[3] ;
  wire new_n19_, new_n20_, new_n21_, new_n22_, new_n23_, new_n24_, new_n25_,
    new_n26_, new_n27_, new_n28_, new_n29_, new_n30_, new_n31_, new_n32_,
    new_n33_, new_n34_, new_n35_, new_n36_, new_n37_, new_n38_, new_n39_,
    new_n40_, new_n41_, new_n42_, new_n43_, new_n44_, new_n45_, new_n46_,
    new_n47_, new_n48_, new_n49_, new_n50_, new_n51_, new_n52_, new_n54_,
    new_n55_, new_n56_, new_n57_, new_n58_, new_n59_, new_n60_, new_n61_,
    new_n62_, new_n63_, new_n64_, new_n65_, new_n66_, new_n67_, new_n69_,
    new_n70_, new_n71_, new_n73_, new_n74_, new_n75_, new_n76_, new_n77_,
    new_n78_, new_n79_, new_n80_, new_n81_, new_n82_, new_n83_, new_n84_,
    new_n85_, new_n86_, new_n87_, new_n88_, new_n89_, new_n90_, new_n91_,
    new_n92_, new_n93_, new_n94_, new_n95_, new_n96_, new_n97_, new_n98_,
    new_n99_, new_n100_, new_n101_, new_n102_, new_n103_, new_n104_,
    new_n105_, new_n106_, new_n107_, new_n108_, new_n110_, new_n111_,
    new_n112_, new_n113_, new_n114_, new_n115_, new_n116_, new_n117_,
    new_n118_, new_n119_, new_n120_, new_n121_, new_n122_, new_n123_,
    new_n124_, new_n125_, new_n126_, new_n127_, new_n128_, new_n129_,
    new_n130_, new_n131_, new_n132_, new_n133_, new_n134_, new_n135_,
    new_n136_, new_n137_, new_n138_, new_n139_, new_n140_, new_n141_,
    new_n142_, new_n143_, new_n145_, new_n146_, new_n147_, new_n148_,
    new_n149_, new_n150_, new_n151_, new_n152_, new_n153_, new_n154_,
    new_n155_, new_n156_, new_n157_, new_n158_, new_n159_, new_n160_,
    new_n161_, new_n162_, new_n163_, new_n164_, new_n165_, new_n166_,
    new_n167_, new_n168_, new_n169_, new_n170_, new_n171_, new_n172_,
    new_n173_, new_n174_, new_n175_, new_n176_, new_n177_, new_n178_,
    new_n179_, new_n180_, new_n181_, new_n182_, new_n183_, new_n184_,
    new_n185_, new_n186_, new_n187_, new_n188_, new_n189_, new_n191_,
    new_n192_, new_n193_, new_n194_, new_n195_, new_n196_, new_n197_,
    new_n198_;
  INVx1_ASAP7_75t_R    g000(.A(\B[0] ), .Y(new_n19_));
  INVx1_ASAP7_75t_R    g001(.A(\B[10] ), .Y(new_n20_));
  INVx1_ASAP7_75t_R    g002(.A(\B[1] ), .Y(new_n21_));
  INVx1_ASAP7_75t_R    g003(.A(\B[2] ), .Y(new_n22_));
  INVx1_ASAP7_75t_R    g004(.A(\B[3] ), .Y(new_n23_));
  INVx1_ASAP7_75t_R    g005(.A(\B[4] ), .Y(new_n24_));
  INVx1_ASAP7_75t_R    g006(.A(\B[5] ), .Y(new_n25_));
  INVx1_ASAP7_75t_R    g007(.A(\B[6] ), .Y(new_n26_));
  INVx1_ASAP7_75t_R    g008(.A(\B[7] ), .Y(new_n27_));
  INVx1_ASAP7_75t_R    g009(.A(\B[8] ), .Y(new_n28_));
  INVx1_ASAP7_75t_R    g010(.A(\B[9] ), .Y(new_n29_));
  NOR2x1_ASAP7_75t_R   g011(.A(new_n26_), .B(new_n27_), .Y(new_n30_));
  INVx1_ASAP7_75t_R    g012(.A(new_n30_), .Y(new_n31_));
  NOR2x1_ASAP7_75t_R   g013(.A(new_n25_), .B(new_n28_), .Y(new_n32_));
  AOI22x1_ASAP7_75t_R  g014(.A1(\B[3] ), .A2(\B[8] ), .B1(\B[2] ), .B2(new_n23_), .Y(new_n33_));
  OR3x1_ASAP7_75t_R    g015(.A(new_n24_), .B(new_n33_), .C(new_n25_), .Y(new_n34_));
  AO21x1_ASAP7_75t_R   g016(.A1(new_n30_), .A2(new_n34_), .B(new_n31_), .Y(new_n35_));
  AO32x1_ASAP7_75t_R   g017(.A1(new_n30_), .A2(new_n32_), .A3(\B[9] ), .B1(new_n29_), .B2(new_n35_), .Y(new_n36_));
  INVx1_ASAP7_75t_R    g018(.A(new_n36_), .Y(new_n37_));
  NOR2x1_ASAP7_75t_R   g019(.A(new_n25_), .B(\B[6] ), .Y(new_n38_));
  AO21x1_ASAP7_75t_R   g020(.A1(\B[5] ), .A2(new_n26_), .B(new_n25_), .Y(new_n39_));
  AO21x1_ASAP7_75t_R   g021(.A1(\B[3] ), .A2(new_n39_), .B(new_n23_), .Y(new_n40_));
  OA21x2_ASAP7_75t_R   g022(.A1(new_n21_), .A2(new_n22_), .B(new_n26_), .Y(new_n41_));
  AO32x1_ASAP7_75t_R   g023(.A1(\B[5] ), .A2(new_n41_), .A3(\B[3] ), .B1(new_n23_), .B2(new_n38_), .Y(new_n42_));
  AOI22x1_ASAP7_75t_R  g024(.A1(\B[7] ), .A2(new_n40_), .B1(new_n27_), .B2(new_n42_), .Y(new_n43_));
  OA21x2_ASAP7_75t_R   g025(.A1(\B[6] ), .A2(\B[7] ), .B(new_n27_), .Y(new_n44_));
  AO21x1_ASAP7_75t_R   g026(.A1(\B[4] ), .A2(\B[7] ), .B(new_n24_), .Y(new_n45_));
  AO21x1_ASAP7_75t_R   g027(.A1(\B[5] ), .A2(new_n45_), .B(new_n25_), .Y(new_n46_));
  AO21x1_ASAP7_75t_R   g028(.A1(new_n19_), .A2(\B[1] ), .B(new_n21_), .Y(new_n47_));
  AO21x1_ASAP7_75t_R   g029(.A1(new_n25_), .A2(new_n47_), .B(\B[5] ), .Y(new_n48_));
  AO221x2_ASAP7_75t_R  g030(.A1(\B[6] ), .A2(new_n46_), .B1(new_n26_), .B2(new_n48_), .C(new_n22_), .Y(new_n49_));
  OA222x2_ASAP7_75t_R  g031(.A1(new_n24_), .A2(new_n43_), .B1(\B[4] ), .B2(new_n44_), .C1(new_n23_), .C2(new_n49_), .Y(new_n50_));
  AO21x1_ASAP7_75t_R   g032(.A1(new_n28_), .A2(new_n50_), .B(\B[8] ), .Y(new_n51_));
  AO21x1_ASAP7_75t_R   g033(.A1(new_n20_), .A2(new_n51_), .B(\B[10] ), .Y(new_n52_));
  AO22x1_ASAP7_75t_R   g034(.A1(new_n36_), .A2(new_n52_), .B1(\B[10] ), .B2(new_n37_), .Y(\E[0] ));
  NOR2x1_ASAP7_75t_R   g035(.A(\B[10] ), .B(\B[9] ), .Y(new_n54_));
  INVx1_ASAP7_75t_R    g036(.A(new_n54_), .Y(new_n55_));
  NOR2x1_ASAP7_75t_R   g037(.A(new_n23_), .B(new_n24_), .Y(new_n56_));
  INVx1_ASAP7_75t_R    g038(.A(new_n56_), .Y(new_n57_));
  OR3x1_ASAP7_75t_R    g039(.A(new_n23_), .B(new_n24_), .C(\B[2] ), .Y(new_n58_));
  AO21x1_ASAP7_75t_R   g040(.A1(new_n56_), .A2(new_n58_), .B(new_n26_), .Y(new_n59_));
  AOI21x1_ASAP7_75t_R  g041(.A1(\B[6] ), .A2(new_n59_), .B(\B[7] ), .Y(new_n60_));
  AND3x1_ASAP7_75t_R   g042(.A(\B[6] ), .B(new_n27_), .C(new_n28_), .Y(new_n61_));
  AO32x1_ASAP7_75t_R   g043(.A1(new_n28_), .A2(new_n60_), .A3(\B[5] ), .B1(new_n25_), .B2(new_n61_), .Y(new_n62_));
  INVx1_ASAP7_75t_R    g044(.A(new_n62_), .Y(new_n63_));
  NAND2x1_ASAP7_75t_R  g045(.A(new_n25_), .B(new_n27_), .Y(new_n64_));
  OR5x1_ASAP7_75t_R    g046(.A(new_n22_), .B(new_n64_), .C(new_n19_), .D(new_n23_), .E(new_n21_), .Y(new_n65_));
  OA33x2_ASAP7_75t_R   g047(.A1(new_n24_), .A2(new_n36_), .A3(new_n28_), .B1(new_n24_), .B2(new_n65_), .B3(\B[8] ), .Y(new_n66_));
  OAI21x1_ASAP7_75t_R  g048(.A1(new_n62_), .A2(new_n66_), .B(new_n63_), .Y(new_n67_));
  AO21x1_ASAP7_75t_R   g049(.A1(new_n54_), .A2(new_n67_), .B(new_n55_), .Y(\E[1] ));
  AND5x1_ASAP7_75t_R   g050(.A(\B[3] ), .B(\B[4] ), .C(\B[6] ), .D(\B[5] ), .E(\B[2] ), .Y(new_n69_));
  AO21x1_ASAP7_75t_R   g051(.A1(new_n27_), .A2(new_n69_), .B(\B[7] ), .Y(new_n70_));
  AO21x1_ASAP7_75t_R   g052(.A1(new_n28_), .A2(new_n70_), .B(\B[8] ), .Y(new_n71_));
  AO21x1_ASAP7_75t_R   g053(.A1(new_n54_), .A2(new_n71_), .B(new_n55_), .Y(\E[2] ));
  OR3x1_ASAP7_75t_R    g054(.A(\B[7] ), .B(\B[8] ), .C(\B[9] ), .Y(new_n73_));
  OA33x2_ASAP7_75t_R   g055(.A1(\B[2] ), .A2(new_n73_), .A3(new_n23_), .B1(new_n22_), .B2(new_n73_), .B3(\B[3] ), .Y(new_n74_));
  INVx1_ASAP7_75t_R    g056(.A(new_n74_), .Y(new_n75_));
  AO21x1_ASAP7_75t_R   g057(.A1(\B[8] ), .A2(new_n29_), .B(new_n28_), .Y(new_n76_));
  AO21x1_ASAP7_75t_R   g058(.A1(\B[10] ), .A2(new_n76_), .B(new_n20_), .Y(new_n77_));
  AO22x1_ASAP7_75t_R   g059(.A1(\B[7] ), .A2(new_n77_), .B1(new_n20_), .B2(new_n27_), .Y(new_n78_));
  AO21x1_ASAP7_75t_R   g060(.A1(new_n20_), .A2(\B[7] ), .B(new_n27_), .Y(new_n79_));
  AOI22x1_ASAP7_75t_R  g061(.A1(\B[6] ), .A2(new_n78_), .B1(new_n26_), .B2(new_n79_), .Y(new_n80_));
  AO21x1_ASAP7_75t_R   g062(.A1(\B[6] ), .A2(new_n75_), .B(new_n80_), .Y(new_n81_));
  INVx1_ASAP7_75t_R    g063(.A(new_n81_), .Y(new_n82_));
  AO21x1_ASAP7_75t_R   g064(.A1(\B[7] ), .A2(new_n28_), .B(\B[8] ), .Y(new_n83_));
  AO21x1_ASAP7_75t_R   g065(.A1(new_n22_), .A2(new_n83_), .B(\B[2] ), .Y(new_n84_));
  AO21x1_ASAP7_75t_R   g066(.A1(\B[2] ), .A2(new_n83_), .B(new_n22_), .Y(new_n85_));
  AOI221x1_ASAP7_75t_R g067(.A1(\B[1] ), .A2(new_n84_), .B1(new_n21_), .B2(new_n85_), .C(\B[9] ), .Y(new_n86_));
  OA211x2_ASAP7_75t_R  g068(.A1(\B[9] ), .A2(new_n86_), .B(new_n20_), .C(new_n26_), .Y(new_n87_));
  NOR2x1_ASAP7_75t_R   g069(.A(\B[10] ), .B(new_n29_), .Y(new_n88_));
  AO32x1_ASAP7_75t_R   g070(.A1(\B[6] ), .A2(new_n88_), .A3(new_n25_), .B1(\B[5] ), .B2(new_n87_), .Y(new_n89_));
  INVx1_ASAP7_75t_R    g071(.A(new_n89_), .Y(new_n90_));
  AND3x1_ASAP7_75t_R   g072(.A(new_n21_), .B(new_n26_), .C(new_n27_), .Y(new_n91_));
  NOR2x1_ASAP7_75t_R   g073(.A(new_n21_), .B(\B[6] ), .Y(new_n92_));
  AO32x1_ASAP7_75t_R   g074(.A1(new_n27_), .A2(new_n92_), .A3(new_n19_), .B1(\B[0] ), .B2(new_n91_), .Y(new_n93_));
  AND5x1_ASAP7_75t_R   g075(.A(new_n26_), .B(new_n28_), .C(new_n27_), .D(\B[0] ), .E(new_n24_), .Y(new_n94_));
  AO21x1_ASAP7_75t_R   g076(.A1(\B[4] ), .A2(new_n93_), .B(new_n94_), .Y(new_n95_));
  INVx1_ASAP7_75t_R    g077(.A(new_n95_), .Y(new_n96_));
  AO21x1_ASAP7_75t_R   g078(.A1(new_n24_), .A2(new_n95_), .B(\B[4] ), .Y(new_n97_));
  AO22x1_ASAP7_75t_R   g079(.A1(new_n24_), .A2(\B[5] ), .B1(new_n25_), .B2(new_n97_), .Y(new_n98_));
  AO21x1_ASAP7_75t_R   g080(.A1(\B[2] ), .A2(\B[5] ), .B(new_n25_), .Y(new_n99_));
  AO21x1_ASAP7_75t_R   g081(.A1(\B[1] ), .A2(new_n99_), .B(new_n21_), .Y(new_n100_));
  AO22x1_ASAP7_75t_R   g082(.A1(\B[4] ), .A2(\B[7] ), .B1(new_n27_), .B2(new_n100_), .Y(new_n101_));
  AO21x1_ASAP7_75t_R   g083(.A1(new_n24_), .A2(\B[7] ), .B(new_n27_), .Y(new_n102_));
  AOI22x1_ASAP7_75t_R  g084(.A1(\B[3] ), .A2(new_n101_), .B1(new_n23_), .B2(new_n102_), .Y(new_n103_));
  AO21x1_ASAP7_75t_R   g085(.A1(new_n96_), .A2(new_n103_), .B(new_n95_), .Y(new_n104_));
  AO22x1_ASAP7_75t_R   g086(.A1(\B[5] ), .A2(new_n103_), .B1(new_n25_), .B2(new_n104_), .Y(new_n105_));
  AOI22x1_ASAP7_75t_R  g087(.A1(\B[8] ), .A2(new_n98_), .B1(new_n28_), .B2(new_n105_), .Y(new_n106_));
  OR3x1_ASAP7_75t_R    g088(.A(new_n55_), .B(new_n106_), .C(new_n89_), .Y(new_n107_));
  AO21x1_ASAP7_75t_R   g089(.A1(new_n90_), .A2(new_n107_), .B(new_n81_), .Y(new_n108_));
  NAND2x1_ASAP7_75t_R  g090(.A(new_n82_), .B(new_n108_), .Y(\M[0] ));
  AO21x1_ASAP7_75t_R   g091(.A1(\B[6] ), .A2(\B[9] ), .B(new_n26_), .Y(new_n110_));
  AO21x1_ASAP7_75t_R   g092(.A1(\B[7] ), .A2(new_n110_), .B(new_n27_), .Y(new_n111_));
  AO32x1_ASAP7_75t_R   g093(.A1(\B[6] ), .A2(\B[7] ), .A3(new_n28_), .B1(\B[8] ), .B2(new_n111_), .Y(new_n112_));
  OA21x2_ASAP7_75t_R   g094(.A1(\B[6] ), .A2(new_n38_), .B(new_n27_), .Y(new_n113_));
  AO32x1_ASAP7_75t_R   g095(.A1(new_n28_), .A2(new_n113_), .A3(new_n20_), .B1(\B[10] ), .B2(new_n112_), .Y(new_n114_));
  INVx1_ASAP7_75t_R    g096(.A(new_n114_), .Y(new_n115_));
  AO21x1_ASAP7_75t_R   g097(.A1(\B[8] ), .A2(new_n29_), .B(\B[9] ), .Y(new_n116_));
  AO21x1_ASAP7_75t_R   g098(.A1(new_n26_), .A2(\B[7] ), .B(\B[6] ), .Y(new_n117_));
  AO22x1_ASAP7_75t_R   g099(.A1(\B[4] ), .A2(new_n116_), .B1(new_n24_), .B2(new_n117_), .Y(new_n118_));
  INVx1_ASAP7_75t_R    g100(.A(new_n118_), .Y(new_n119_));
  AND3x1_ASAP7_75t_R   g101(.A(\B[4] ), .B(\B[5] ), .C(\B[8] ), .Y(new_n120_));
  AO32x1_ASAP7_75t_R   g102(.A1(\B[5] ), .A2(\B[7] ), .A3(\B[9] ), .B1(new_n29_), .B2(new_n120_), .Y(new_n121_));
  AO32x1_ASAP7_75t_R   g103(.A1(new_n24_), .A2(\B[8] ), .A3(new_n29_), .B1(new_n27_), .B2(\B[9] ), .Y(new_n122_));
  AOI22x1_ASAP7_75t_R  g104(.A1(\B[6] ), .A2(new_n121_), .B1(new_n26_), .B2(new_n122_), .Y(new_n123_));
  OA21x2_ASAP7_75t_R   g105(.A1(new_n21_), .A2(new_n22_), .B(new_n27_), .Y(new_n124_));
  AO32x1_ASAP7_75t_R   g106(.A1(new_n123_), .A2(new_n124_), .A3(new_n119_), .B1(new_n118_), .B2(new_n123_), .Y(new_n125_));
  AO22x1_ASAP7_75t_R   g107(.A1(\B[5] ), .A2(new_n125_), .B1(new_n25_), .B2(new_n123_), .Y(new_n126_));
  AO22x1_ASAP7_75t_R   g108(.A1(\B[3] ), .A2(new_n126_), .B1(new_n23_), .B2(new_n123_), .Y(new_n127_));
  AO22x1_ASAP7_75t_R   g109(.A1(new_n19_), .A2(\B[2] ), .B1(\B[0] ), .B2(new_n22_), .Y(new_n128_));
  NOR2x1_ASAP7_75t_R   g110(.A(\B[1] ), .B(new_n22_), .Y(new_n129_));
  AO21x1_ASAP7_75t_R   g111(.A1(\B[1] ), .A2(new_n128_), .B(new_n129_), .Y(new_n130_));
  AO22x1_ASAP7_75t_R   g112(.A1(\B[4] ), .A2(new_n130_), .B1(\B[1] ), .B2(new_n24_), .Y(new_n131_));
  AOI22x1_ASAP7_75t_R  g113(.A1(\B[7] ), .A2(new_n56_), .B1(new_n27_), .B2(new_n131_), .Y(new_n132_));
  AO22x1_ASAP7_75t_R   g114(.A1(new_n26_), .A2(\B[8] ), .B1(new_n28_), .B2(new_n132_), .Y(new_n133_));
  AO32x1_ASAP7_75t_R   g115(.A1(new_n26_), .A2(new_n132_), .A3(new_n28_), .B1(new_n26_), .B2(\B[8] ), .Y(new_n134_));
  AOI22x1_ASAP7_75t_R  g116(.A1(\B[7] ), .A2(new_n133_), .B1(new_n27_), .B2(new_n134_), .Y(new_n135_));
  OA33x2_ASAP7_75t_R   g117(.A1(\B[5] ), .A2(\B[7] ), .A3(new_n29_), .B1(\B[5] ), .B2(new_n135_), .B3(\B[9] ), .Y(new_n136_));
  AO33x2_ASAP7_75t_R   g118(.A1(\B[2] ), .A2(new_n29_), .A3(\B[4] ), .B1(new_n22_), .B2(new_n29_), .B3(new_n24_), .Y(new_n137_));
  AO32x1_ASAP7_75t_R   g119(.A1(new_n24_), .A2(new_n29_), .A3(new_n23_), .B1(\B[3] ), .B2(new_n137_), .Y(new_n138_));
  OA21x2_ASAP7_75t_R   g120(.A1(new_n22_), .A2(new_n129_), .B(new_n23_), .Y(new_n139_));
  AOI221x1_ASAP7_75t_R g121(.A1(\B[6] ), .A2(new_n138_), .B1(new_n26_), .B2(new_n139_), .C(new_n115_), .Y(new_n140_));
  OA21x2_ASAP7_75t_R   g122(.A1(new_n115_), .A2(new_n140_), .B(new_n136_), .Y(new_n141_));
  NAND2x1_ASAP7_75t_R  g123(.A(new_n127_), .B(new_n141_), .Y(new_n142_));
  NOR2x1_ASAP7_75t_R   g124(.A(\B[10] ), .B(new_n142_), .Y(new_n143_));
  AO21x1_ASAP7_75t_R   g125(.A1(\B[10] ), .A2(new_n114_), .B(new_n143_), .Y(\M[1] ));
  AO21x1_ASAP7_75t_R   g126(.A1(new_n25_), .A2(new_n29_), .B(\B[5] ), .Y(new_n145_));
  AO32x1_ASAP7_75t_R   g127(.A1(\B[10] ), .A2(new_n29_), .A3(new_n25_), .B1(\B[10] ), .B2(\B[5] ), .Y(new_n146_));
  AO22x1_ASAP7_75t_R   g128(.A1(\B[6] ), .A2(new_n145_), .B1(new_n26_), .B2(new_n146_), .Y(new_n147_));
  AO32x1_ASAP7_75t_R   g129(.A1(new_n24_), .A2(new_n29_), .A3(new_n20_), .B1(\B[10] ), .B2(new_n29_), .Y(new_n148_));
  AO22x1_ASAP7_75t_R   g130(.A1(new_n25_), .A2(new_n29_), .B1(\B[5] ), .B2(new_n148_), .Y(new_n149_));
  AO22x1_ASAP7_75t_R   g131(.A1(\B[6] ), .A2(new_n149_), .B1(new_n26_), .B2(new_n29_), .Y(new_n150_));
  AO22x1_ASAP7_75t_R   g132(.A1(\B[7] ), .A2(new_n147_), .B1(new_n27_), .B2(new_n150_), .Y(new_n151_));
  INVx1_ASAP7_75t_R    g133(.A(new_n151_), .Y(new_n152_));
  AO21x1_ASAP7_75t_R   g134(.A1(new_n20_), .A2(\B[9] ), .B(new_n29_), .Y(new_n153_));
  AO33x2_ASAP7_75t_R   g135(.A1(new_n20_), .A2(new_n151_), .A3(new_n30_), .B1(new_n151_), .B2(new_n153_), .B3(new_n31_), .Y(new_n154_));
  AO22x1_ASAP7_75t_R   g136(.A1(new_n29_), .A2(new_n151_), .B1(new_n152_), .B2(new_n153_), .Y(new_n155_));
  AO32x1_ASAP7_75t_R   g137(.A1(\B[6] ), .A2(\B[7] ), .A3(new_n155_), .B1(new_n31_), .B2(new_n153_), .Y(new_n156_));
  AO22x1_ASAP7_75t_R   g138(.A1(\B[8] ), .A2(new_n154_), .B1(new_n28_), .B2(new_n156_), .Y(new_n157_));
  AO21x1_ASAP7_75t_R   g139(.A1(\B[4] ), .A2(new_n25_), .B(new_n24_), .Y(new_n158_));
  AND4x2_ASAP7_75t_R   g140(.A(new_n22_), .B(\B[5] ), .C(\B[4] ), .D(new_n27_), .Y(new_n159_));
  AOI21x1_ASAP7_75t_R  g141(.A1(\B[7] ), .A2(new_n158_), .B(new_n159_), .Y(new_n160_));
  OR5x1_ASAP7_75t_R    g142(.A(new_n23_), .B(new_n25_), .C(new_n24_), .D(new_n27_), .E(\B[6] ), .Y(new_n161_));
  OR3x1_ASAP7_75t_R    g143(.A(new_n19_), .B(new_n21_), .C(\B[5] ), .Y(new_n162_));
  AOI21x1_ASAP7_75t_R  g144(.A1(new_n25_), .A2(new_n162_), .B(new_n23_), .Y(new_n163_));
  AO21x1_ASAP7_75t_R   g145(.A1(\B[0] ), .A2(\B[6] ), .B(new_n19_), .Y(new_n164_));
  AO21x1_ASAP7_75t_R   g146(.A1(\B[1] ), .A2(new_n164_), .B(new_n21_), .Y(new_n165_));
  AO21x1_ASAP7_75t_R   g147(.A1(new_n23_), .A2(new_n165_), .B(new_n163_), .Y(new_n166_));
  AO22x1_ASAP7_75t_R   g148(.A1(new_n21_), .A2(\B[5] ), .B1(new_n25_), .B2(\B[6] ), .Y(new_n167_));
  AO21x1_ASAP7_75t_R   g149(.A1(new_n25_), .A2(\B[6] ), .B(\B[5] ), .Y(new_n168_));
  AO22x1_ASAP7_75t_R   g150(.A1(\B[3] ), .A2(new_n167_), .B1(new_n23_), .B2(new_n168_), .Y(new_n169_));
  AO22x1_ASAP7_75t_R   g151(.A1(\B[4] ), .A2(new_n166_), .B1(new_n24_), .B2(new_n169_), .Y(new_n170_));
  INVx1_ASAP7_75t_R    g152(.A(new_n170_), .Y(new_n171_));
  AO21x1_ASAP7_75t_R   g153(.A1(\B[8] ), .A2(new_n171_), .B(new_n170_), .Y(new_n172_));
  AO21x1_ASAP7_75t_R   g154(.A1(new_n27_), .A2(new_n172_), .B(\B[7] ), .Y(new_n173_));
  AO21x1_ASAP7_75t_R   g155(.A1(\B[2] ), .A2(new_n173_), .B(new_n22_), .Y(new_n174_));
  OA211x2_ASAP7_75t_R  g156(.A1(new_n26_), .A2(new_n160_), .B(new_n161_), .C(new_n174_), .Y(new_n175_));
  AO21x1_ASAP7_75t_R   g157(.A1(\B[1] ), .A2(new_n26_), .B(\B[6] ), .Y(new_n176_));
  AO21x1_ASAP7_75t_R   g158(.A1(new_n22_), .A2(\B[6] ), .B(new_n26_), .Y(new_n177_));
  AO22x1_ASAP7_75t_R   g159(.A1(\B[5] ), .A2(new_n176_), .B1(new_n25_), .B2(new_n177_), .Y(new_n178_));
  AO32x1_ASAP7_75t_R   g160(.A1(\B[3] ), .A2(\B[4] ), .A3(new_n178_), .B1(new_n39_), .B2(new_n57_), .Y(new_n179_));
  INVx1_ASAP7_75t_R    g161(.A(new_n179_), .Y(new_n180_));
  AND3x1_ASAP7_75t_R   g162(.A(new_n22_), .B(new_n26_), .C(new_n27_), .Y(new_n181_));
  AO32x1_ASAP7_75t_R   g163(.A1(\B[5] ), .A2(new_n27_), .A3(new_n23_), .B1(\B[3] ), .B2(new_n181_), .Y(new_n182_));
  AND3x1_ASAP7_75t_R   g164(.A(\B[4] ), .B(new_n182_), .C(new_n179_), .Y(new_n183_));
  OA21x2_ASAP7_75t_R   g165(.A1(new_n180_), .A2(new_n183_), .B(new_n28_), .Y(new_n184_));
  AND3x1_ASAP7_75t_R   g166(.A(new_n54_), .B(new_n184_), .C(new_n175_), .Y(new_n185_));
  INVx1_ASAP7_75t_R    g167(.A(new_n185_), .Y(new_n186_));
  OR3x1_ASAP7_75t_R    g168(.A(\B[10] ), .B(\B[9] ), .C(new_n175_), .Y(new_n187_));
  NAND2x1_ASAP7_75t_R  g169(.A(new_n186_), .B(new_n187_), .Y(new_n188_));
  NAND2x1_ASAP7_75t_R  g170(.A(new_n157_), .B(new_n188_), .Y(new_n189_));
  NAND2x1_ASAP7_75t_R  g171(.A(new_n157_), .B(new_n189_), .Y(\M[2] ));
  AO21x1_ASAP7_75t_R   g172(.A1(\B[2] ), .A2(\B[6] ), .B(new_n26_), .Y(new_n191_));
  AO21x1_ASAP7_75t_R   g173(.A1(\B[5] ), .A2(new_n191_), .B(new_n25_), .Y(new_n192_));
  AO21x1_ASAP7_75t_R   g174(.A1(\B[7] ), .A2(new_n192_), .B(new_n27_), .Y(new_n193_));
  AO21x1_ASAP7_75t_R   g175(.A1(\B[4] ), .A2(new_n193_), .B(new_n24_), .Y(new_n194_));
  AO21x1_ASAP7_75t_R   g176(.A1(new_n27_), .A2(new_n168_), .B(\B[7] ), .Y(new_n195_));
  AO21x1_ASAP7_75t_R   g177(.A1(new_n24_), .A2(new_n195_), .B(\B[4] ), .Y(new_n196_));
  AO22x1_ASAP7_75t_R   g178(.A1(\B[8] ), .A2(new_n194_), .B1(new_n28_), .B2(new_n196_), .Y(new_n197_));
  AO21x1_ASAP7_75t_R   g179(.A1(new_n23_), .A2(new_n197_), .B(\B[3] ), .Y(new_n198_));
  AO21x1_ASAP7_75t_R   g180(.A1(new_n54_), .A2(new_n198_), .B(new_n55_), .Y(\M[3] ));
endmodule


