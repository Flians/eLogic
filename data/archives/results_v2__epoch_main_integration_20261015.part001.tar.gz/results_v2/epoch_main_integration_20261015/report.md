# Protected shared incumbent: main-binary validation

The same fixed delay-area configuration is used for every design and inventory. Main source/binary are archived here; legacy defaults stay unchanged. The complete baseline dataset remains original and unchanged.

## Scope and outcomes

- Full: 80 fresh mapper attempts, 60 direct original-input named-port CEC passes, 20 import-node failures; no adopted prototype results. Thirty legal pairs: delay 2 better / 28 equal / 0 worse; area 20 better / 10 equal / 0 worse.
- Repeats: 32 additional fresh attempts, all direct CEC passes. Including the 16 corresponding full observations: 48 observations / 24 pairs; delay 6 better / 18 equal / 0 worse; area 12 better / 12 equal / 0 worse. Profile order reverses on the second repetition.
- All successful cases satisfy actual global nodes/cuts/retained-pool/recovery/mapping limits; paired retained-pool fingerprints match; saved artifacts match their recorded hashes. No repeat-best selection.
- Main full and repeats both pass check_recovery_nonregression.py. All six sqrt pairs strictly improve delay. Small repetitions are not a statistical-confidence or deterministic-runtime claim.

## Full-run physical metrics

|Inventory|Design|Old area|New area|Old delay|New delay|
|---|---|---:|---:|---:|---:|
|3|adder|72.55000|72.55000|2585.47999|2585.47999|
|3|arbiter|767.02999|755.41999|905.89000|905.89000|
|3|bar|289.64000|264.71000|190.87000|190.87000|
|3|cavlc|44.93000|44.03000|197.59000|197.59000|
|3|ctrl|7.33000|7.33000|108.06000|108.06000|
|3|dec|27.68000|27.68000|82.92000|82.92000|
|3|div|N|N|N|N|
|3|hyp|N|N|N|N|
|3|i2c|82.87000|76.65000|166.78000|166.78000|
|3|int2float|14.40000|14.15000|183.34000|183.34000|
|3|log2|N|N|N|N|
|3|max|284.96000|249.37000|2111.03000|2111.03000|
|3|mem_ctrl|N|N|N|N|
|3|multiplier|N|N|N|N|
|3|priority|68.54000|68.54000|2062.18000|2062.18000|
|3|router|13.75000|13.75000|216.40000|216.40000|
|3|sin|623.01000|451.15000|2095.27001|2095.27001|
|3|sqrt|2929.43998|2159.10999|72930.20034|68523.99045|
|3|square|2586.11000|1695.25000|2707.67996|2707.67996|
|3|voter|1382.65999|1051.53000|817.57001|817.57001|
|4|adder|84.49000|83.88000|2585.23000|2585.23000|
|4|arbiter|728.71999|718.79999|925.93000|925.93000|
|4|bar|304.71000|291.50000|188.34000|188.34000|
|4|cavlc|44.60000|42.04000|194.95000|194.95000|
|4|ctrl|7.19000|7.19000|103.17000|103.17000|
|4|dec|29.18000|29.18000|66.15000|66.15000|
|4|div|N|N|N|N|
|4|hyp|N|N|N|N|
|4|i2c|80.69000|75.42000|165.79000|165.79000|
|4|int2float|13.22000|13.22000|181.28000|181.28000|
|4|log2|N|N|N|N|
|4|max|278.12000|221.30000|2098.34000|2098.34000|
|4|mem_ctrl|N|N|N|N|
|4|multiplier|N|N|N|N|
|4|priority|52.55000|52.55000|2047.24000|2047.24000|
|4|router|13.07000|13.07000|199.00000|199.00000|
|4|sin|718.56000|462.87000|2029.35002|2029.35002|
|4|sqrt|3818.23000|2743.80000|70473.09060|66924.64062|
|4|square|2943.52001|1835.55001|2772.81997|2772.81997|
|4|voter|1688.03000|1319.94000|758.00001|758.00001|

## Repeated ranges (all observations, not best runs)

|Inventory|Design|Old area range|New area range|Old delay range|New delay range|
|---|---|---:|---:|---:|---:|
|3|adder|72.55000–72.55000|72.55000–72.55000|2585.47999–2585.47999|2585.47999–2585.47999|
|3|priority|68.54000–68.56000|68.54000–68.54000|2062.18000–2062.18000|2062.18000–2062.18000|
|3|int2float|14.40000–14.40000|14.15000–14.15000|183.34000–183.34000|183.34000–183.34000|
|3|sqrt|2927.74998–2929.43998|2159.10999–2159.10999|72757.96035–72930.20034|68523.99045–68523.99045|
|4|adder|83.75000–84.49000|83.75000–83.88000|2585.23000–2585.23000|2585.23000–2585.23000|
|4|priority|52.55000–52.55000|52.55000–52.55000|2047.24000–2047.24000|2047.24000–2047.24000|
|4|int2float|13.22000–13.22000|13.22000–13.22000|181.28000–181.28000|181.28000–181.28000|
|4|sqrt|3818.00000–3837.41000|2743.80000–2743.80000|70288.46060–71938.82062|66924.64062–66924.64062|

## Mechanism and limitations

The original cold seed/tie/witness/structural-reference trajectory is preserved. Frontier and required-time DAG covers are separately validated alternatives and deferred until final whole-cover comparison. Epoch-invalidated exact metric scratch reduces repeated clearing while preserving ascending physical-instance area summation and dependent-pin timing arithmetic. Read-only diagnostic memo/index changes preserve contents/order and avoid native diagnostic timeouts. One imported e-graph, one candidate pool and one global recovery window are shared by all alternatives. No extra rewrite/trial/iteration budget is added.

The configured two-second window includes mandatory setup and final validation. Stage checks cannot preempt a single trial; actual overruns fail. Retained 100k is not a transient-memory cap. Process clock conservatively includes diagnostics, so no exact mapping-runtime improvement is claimed. A valid discovered incumbent is protected, not the hypothetical result of an independent legacy run under every OS load.

Five designs still fail the original cumulative node allowance: div/hyp/log2/multiplier/mem_ctrl in both inventories. Industrial multi-output/ODC and independent regional saturation are incomplete. All six full-20 baseline gates (two inventories × DA/AD/Pareto) are false, with all 520 original status slots retained; AD is only posthoc on DA covers, MtM is unconnected. Baseline native source/commits/models/binaries/actual dependencies: 13,403 files, zero drift. Baseline mapping algorithms/parameters are unchanged.

Supplementary original→fixed-resyn2→mapped verification was tested explicitly on isolated diagnostic failures, keeping original timeouts immutable; eight eligible original-baseline hyp attempts all failed again under the same verifier guard. No supplemental certificate was needed in either fresh main matrix; all 92 successful fresh main maps pass direct original-input CEC.

Negative deferred-only, cold-seed, progress-only, pre-diagnostic epoch variants and their repeat regressions/timeouts remain archived. This main configuration is not a per-design mixture of them.

## Next experiments

Certified pre-import functional reduction or a separately accounted representation is needed for the five large inputs; resident-node retirement is not a cumulative-import repair. Analyze sqrt critical whole-cover compound/phase choices against common pin timing, with immutable baseline algorithms and the same budgets. Any new configuration requires a new full-scope matrix and adverse-case repetitions.
