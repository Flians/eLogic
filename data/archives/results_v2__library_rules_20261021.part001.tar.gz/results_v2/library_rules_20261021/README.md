# AIG饱和后单向库规则：独立对照

## 当前结论：V4独立全EPFL对照未达到接入条件

正式最新版本为 `source_signed`，全20×三固定配置60次已完成，60最终CEC、51次原生优化覆盖被选：控制18、替换17、组合16。预算审计全部通过。替换组 `(D,A)` 为5好/3平/12差；组合组7好/4平/9差。仅看D，替换为1好/14平/5差，组合0好/16平/4差。全范围baseline九个lex/Pareto gate均false；未接入工具与baseline失败继续保留。不能将不同配置按设计拼成赢家。

五个预定设计的30次额外重复已完成，全部原生优化、CEC与预算通过；替换组10个配对全差，组合4好/6差。与首轮合看，每设计均三次配对；Sqrt、Bar组合组的同延迟面积下降可重复，Sin/Multiplier的回退也可重复；Adder首轮小幅面积收益在两次额外重复中翻转。Mem_ctrl是首轮唯一严格D改善的替换组案例，后验定向重复单独存于 `signed_mem_ctrl_repeats/`，不冒充预先指定的全20重复。

主数据：`signed_full_report/A_D_T.csv`、`signed_full_report/validation.json`；预算：`signed_full_budget_audit/`；baseline：`signed_baseline_scope/`；重复：`signed_repeats_report/`、`signed_repeats_budget_audit/`、`signed_repeated_summary.json`。源/二进制/全部命令与旧失败均保留。`recovery_reuse_proof.json`确认恢复/提取代码及cover-exchange与对照一致。主版本未采用本实验。

关键候选覆盖见 `signed_coverage/coverage.json`、`signed_key_path_summary.json`：20×两规则配置均执行到七个宽单元模式，记录宽匹配/新增独立条目均为0。规则直接新增独立条目主要为窄单元；生成计数在公共截断之前，不能充当最终保留或选中证明。所有60个输出网表的关键路径及全实例面积/引脚延迟都与公共测量重建一致；不同图不按dense ID认定同一个AIG边界，门型交集也不证明来自同一个新绑定。

本对照保留相同小cut枚举算法和上限，而不是冻结完全相同的小cut银行：补出的逻辑Not类及严格等价union会影响后续cut枚举。即使库规则直接新增条目为0，整个候选池仍可能变化。组合组还将固定匹配记账额度分配给两条路线，因此不能把其所有回退单独归因于一种规则。当前证据支持继续以函数边界覆盖为主，尚不支持用该有界结构模式编译器替换原匹配。

当前为隔离实验，未合入主版本；baseline作者算法、模型及参数未改动。

## 三个固定配置

- 0：当前小cuts＋原有宽单元定向匹配。
- 1：相同小cuts＋第二阶段库规则，不调用原宽匹配。
- 2：相同小cuts＋两种匹配，分配同一匹配额度；不是按设计选择配置。

三组使用同一 `source_strict` 源码/二进制及同一47单输出库，复用一次resyn2后的全部20个EPFL输入。当前完整矩阵为 `full_epfl/campaign.json`，计划60次。只以该检查点实际完成数为准；不宣称后台跨turn存活。

## 实现

`source_strict/emapper/src/egraph_library_rules.rs` 编译库表达式和有界分解模式，调用egg Pattern e-matching，然后只执行“匹配的逻辑表达式 → 物理Cell节点”的add/union。第二阶段不运行Boolean规则、不展开Cell回AIG。实际支持集决定TT3/TT4紧凑算子模式，双重反相按AIG边极性规范化。每单元最多32个精确模式，不能声称匹配完备。

物理Cell节点使用保留命名空间，不成为逻辑reachability witness；导出为原有Instance/BindingSource，继续使用原有候选截断、完整共享覆盖、(D,A)恢复和独立CEC。没有采用旧S3的树面积提取器。

所有Cell节点进入同一累计NodeAdmission。Boolean阶段实际轮数与库阶段轮数之和不超过16；节点合并不退款。除总G外，导入后的Boolean＋库节点新增也不超过单独的 `EGM_SEARCH_NODE_ALLOWANCE`。库模式实现不占普通cut槽位（窄单元也如此），它们的实际Cell节点计入G与单独搜索额度，物理实例共用retained100000；不能声称每class全部隐式边界也最多16个。仍为rho=1/2、每class16个普通cuts、原生retained100000、全局恢复2秒、原生共用60秒窗口、完整映射300秒、地址空间16GiB。基础覆盖按原工程政策保留，报告明确区分原生成功、原生被选及基础覆盖返回。

组合配置给原宽匹配800000次递归访问额度，给库匹配800000个记账单位。库匹配单位是每次search的max(1,返回substitution数)，egg内部VM工作未暴露，不能将其等同于原递归访问，也不能据此声称严格相同的机器操作数；外层时间、节点、保留池和恢复限额保持一致。第二阶段每轮暂存绑定最多100000；保留池上限不等于整个生成阶段RAM上限。

## 核验与历史试运行

- `pattern_cost_red.log`：37节点模式重复递归473次的最小反例；修复后计数测试通过。
- `pattern_cost_green.log`：所有已生成库模式与完整库真值表逐赋值比较通过。
- `library_cell_cec_normalized.log`、`library_rule_cell_cec/report.json`：七个真实宽单元候选存在、穷举功能及独立named-port CEC通过。
- `strict_extra_test.log`：总节点额度还有空间但单独搜索额度为1时，只允许新增一个Cell节点。
- `strict_regression_final.log`：247个相关回归通过，7 ignored、16 filtered；显式宽单元CEC与额外额度测试另行运行。
- `strict-source-freeze.json`：正式源码和二进制指纹。
- `pilot/`、`pilot_audit.json`：旧G-only原型六个试运行全部CEC，但部分超过独立搜索额度，完整保留，**不纳入严格正式对照**。`source/`和`pilot-source-freeze.json`保存该原型。

## 结果与后续

`full_epfl.log` 和checkpoint为进度来源。完整后用 `report_library_rules_study.py` 导出A/D/T、原生/基础覆盖状态、逐单元新增候选和所选关键路径候选描述；使用公共baseline报告检查两字典序与Pareto。不同图的dense class ID不直接拼接，关键路径门型统计本身不证明对应原AIG边界上的候选缺失。

必须保留所有失败、超时和回退。观察到的改善需要交替顺序重复验证；在全范围与重复证据完成之前，不更新主版本或宣称优于baselines。


## V2已完成结果与V3后续隔离版本（2026-10-22）

V2 `source_strict` 的全20三组60次与五设计两次额外重复30次均完成：90个最终网表CEC通过、82个原生优化覆盖被选，失败返回基础覆盖的状态明确保留。控制/替换/组合首轮原生覆盖分别18/17/17；替换组DA6好8平6差，组合组5好10平5差。D没有严格改善：替换18平2差、组合19平1差。全部预算审计通过；同库baseline九个lex/Pareto gate全false。见 `full_report/`、`full_budget_audit/`、`baseline_scope/`、`repeats_report/`、`repeats_budget_audit/`、`strict_repeated_summary.json`。五设计三次配对中，替换组adder/bar/sin/sqrt面积收益与multiplier回退均三次出现；组合组adder有波动。上述重复是目标子集，不冒充全20重复。

V2全部40个库阶段都执行了七个宽单元的模式搜索，但记录的宽匹配数均为0；38个生成阶段报告中仅8个有新增独立实例条目，均为窄单元。`wide_match_scope.json`与`first_round_metrics_summary.json`保留原始计数。这是当前有界模式编译器在紧凑表示上的结果，不是所有e-graph库规则方法不可能成功的证明。面积变化不能直接归因为宽单元候选增加。

V3为新的 `source_compound`，没有覆盖V2：固定的OR3(AND3,AND3,AND3)计数图先在 `compound_red.log` 失败，新增库模版的复合边界cuts后在 `compound_green.log` 通过。每个库子树最多64个模版cuts，每单元最多32个精确模式；它们是静态库模式元数据，不是额外电路cut银行。新增Cell节点仍计入G、独立搜索额度及全局保留池。宽单元优先准入，并排除导出时必然同信号自依赖的identity BUF规则。这两项是V3候选生成方案的一部分，不能把V2/V3差异仅归因于模版cuts。

V3通过248个相关回归、七个真实宽单元独立CEC、独立搜索额度测试；指纹见 `compound-source-freeze.json`。新的三组全20矩阵为 `compound_full_epfl/campaign.json`，以实际完成数为准，控制组也重新运行同一新二进制。V2、V3不按设计挑值拼接。主版本仍未采用这些新规则。

原计划的small-cuts-only第四诊断未执行：关闭现有宽匹配开关还会把实际面积flow时间比例从0.65改为硬编码0.30，不能作为单因素证据；提案隔离在 `unexecuted_narrow_diagnostic/`，没有任何对应结果。


## V4：输出相位与符号编码修复（独立、未接入主版本）

`source_signed`、`signed-source-freeze.json` 保存新的冻结源码和二进制。每单元仍最多32个精确模式，正函数和反函数各最多16个；反函数匹配后为物理Cell建立对应的逻辑Not输出类。Not helper与Cell先共同检查累计G和独立搜索S，额度不足时均不插入，实际新增数等于两者之和。TT3/TT4符号使用与导入器一致的补零十六进制编码。V2/V3保留原样，存在旧编码及未命名负相位的已知覆盖限制，不能据其宽匹配为零否定所有库规则方案。

250项相关回归通过，显式七个宽单元CEC通过；虚拟负相位九输入AO333用例确实选中新增单元，512个赋值与独立named-port CEC通过；Not+Cell联合预算拒绝测试通过。证据见 `signed_correctness_validation.json`，并保留此前失败日志。

新全20三组检查点为 `signed_full_epfl/campaign.json`；五个预先选定设计sin/sqrt/adder/bar/multiplier的两次额外重复计划见 `signed_repeat_plan.json`。实际进度只看检查点，不混用V2/V3结果，不挑设计或重复中的最好值。普通cut银行、公共候选截断与覆盖恢复器保持原实现。模式执行、生成独立实例条目、公共池保留和最终选中是不同层次；现有运行审计不提供不同图dense ID的原AIG边界等同证明，也不提供选中绑定的生成器归因。


最终报告见 [signed_final_report.md](signed_final_report.md)：三个campaign均结束、锁空闲，96个最终CEC通过、85次原生优化覆盖，全部预算核验通过。Mem_ctrl后验重复复现约0.30%延迟收益，面积代价约0.22%–2.41%；组合组三次原生超时。全范围仍有回退，未接入主版本。完整状态为 `signed_execution.json`。
