module mapped(\A1[0] , \A2[0] , \A3[0] , \B1[0] , \B2[0] , \B3[0] , \C1[0] , \C2[0] , \C3[0] , \result[0] );
  input \A1[0] ;
  input \A2[0] ;
  input \A3[0] ;
  input \B1[0] ;
  input \B2[0] ;
  input \B3[0] ;
  input \C1[0] ;
  input \C2[0] ;
  input \C3[0] ;
  output \result[0] ;
  wire __egm_s65;
  AO333x1_ASAP7_75t_R __egm_g517 (.A1(\C3[0] ), .A2(\C2[0] ), .A3(\C1[0] ), .B1(\B3[0] ), .B2(\B2[0] ), .B3(\B1[0] ), .C1(\A3[0] ), .C2(\A2[0] ), .C3(\A1[0] ), .Y(__egm_s65));
  assign \result[0]  = __egm_s65;
endmodule
