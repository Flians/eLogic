module mapped(\A1[0] , \A2[0] , \A3[0] , \B1[0] , \B2[0] , \B3[0] , \C1[0] , \C2[0] , \C3[0] , \result[0] );
  input \A1[0] ;
  input \A2[0] ;
  input \A3[0] ;
  input \B1[0] ;
  input \B2[0] ;
  input \B3[0] ;
  input \C1[0] ;
  input \C2[0] ;
  input \C3[0] ;
  output \result[0] ;
  wire __egm_s281;
  OA333x2_ASAP7_75t_R __egm_g3542 (.A1(\A1[0] ), .A2(\A2[0] ), .A3(\A3[0] ), .B1(\B1[0] ), .B2(\B2[0] ), .B3(\B3[0] ), .C1(\C1[0] ), .C2(\C2[0] ), .C3(\C3[0] ), .Y(__egm_s281));
  assign \result[0]  = __egm_s281;
endmodule
