# Shared incumbent recovery (isolated)

Single-factor change relative to delay-area-DAG: EGM_DEFER_AREA_DAG=1 saves a validated required-time DAG area cover, preserves the phase/local recovery trajectory, and chooses the lexicographically better already-valid cover on return. The old incumbent is not replaced on invalid/expired sweeps. No second recovery clock, candidate graph, iteration or trial allowance is created. Production and baselines unchanged. End-to-end pilots/full scope/repeats determine whether this fixes earlier area regressions; no assumed or guaranteed improvement.
