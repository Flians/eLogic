// Benchmark "/tmp/" written by ABC on Mon Oct 12 14:43:24 2026

module \/tmp/  ( 
    p3, p2, p1, p0, p4,
    o0, o1  );
  input  p3, p2, p1, p0, p4;
  output o0, o1;
  wire new_n8_, new_n9_, new_n10_, new_n12_;
  NAND2x1_ASAP7_75t_R g0(.A(p0), .B(p4), .Y(new_n8_));
  AND2x2_ASAP7_75t_R  g1(.A(p2), .B(p0), .Y(new_n9_));
  AOI21x1_ASAP7_75t_R g2(.A1(p0), .A2(p4), .B(p1), .Y(new_n10_));
  AOI21x1_ASAP7_75t_R g3(.A1(new_n8_), .A2(new_n9_), .B(new_n10_), .Y(o0));
  NOR2x1_ASAP7_75t_R  g4(.A(p3), .B(p1), .Y(new_n12_));
  NOR2x1_ASAP7_75t_R  g5(.A(new_n12_), .B(new_n9_), .Y(o1));
endmodule


