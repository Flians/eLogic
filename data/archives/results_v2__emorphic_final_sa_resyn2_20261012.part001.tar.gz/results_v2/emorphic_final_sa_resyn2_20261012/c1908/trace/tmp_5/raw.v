// Benchmark "/tmp/" written by ABC on Mon Oct 12 14:44:05 2026

module \/tmp/  ( 
    p32, p20, p18, p26, p30, p10, p29, p11, p9, p27, p4, p14, p13, p12, p8,
    p23, p3, p15, p17, p19, p5, p21, p31, p28, p1, p25, p16, p7, p24, p6,
    p0, p22, p2,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24  );
  input  p32, p20, p18, p26, p30, p10, p29, p11, p9, p27, p4, p14, p13,
    p12, p8, p23, p3, p15, p17, p19, p5, p21, p31, p28, p1, p25, p16, p7,
    p24, p6, p0, p22, p2;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24;
  wire new_n59_, new_n60_, new_n61_, new_n62_, new_n63_, new_n64_, new_n65_,
    new_n66_, new_n67_, new_n68_, new_n69_, new_n70_, new_n71_, new_n72_,
    new_n73_, new_n74_, new_n75_, new_n76_, new_n77_, new_n78_, new_n79_,
    new_n80_, new_n81_, new_n82_, new_n83_, new_n84_, new_n85_, new_n86_,
    new_n87_, new_n88_, new_n89_, new_n90_, new_n91_, new_n92_, new_n93_,
    new_n94_, new_n95_, new_n96_, new_n97_, new_n98_, new_n99_, new_n100_,
    new_n101_, new_n102_, new_n103_, new_n104_, new_n105_, new_n106_,
    new_n107_, new_n108_, new_n109_, new_n110_, new_n111_, new_n112_,
    new_n113_, new_n114_, new_n115_, new_n116_, new_n117_, new_n118_,
    new_n119_, new_n120_, new_n121_, new_n122_, new_n123_, new_n124_,
    new_n125_, new_n126_, new_n127_, new_n128_, new_n129_, new_n130_,
    new_n131_, new_n132_, new_n133_, new_n134_, new_n135_, new_n136_,
    new_n137_, new_n138_, new_n139_, new_n140_, new_n141_, new_n142_,
    new_n143_, new_n144_, new_n145_, new_n146_, new_n147_, new_n148_,
    new_n149_, new_n150_, new_n151_, new_n152_, new_n153_, new_n154_,
    new_n155_, new_n156_, new_n157_, new_n158_, new_n159_, new_n160_,
    new_n161_, new_n162_, new_n163_, new_n164_, new_n165_, new_n166_,
    new_n167_, new_n168_, new_n169_, new_n170_, new_n171_, new_n172_,
    new_n173_, new_n174_, new_n175_, new_n176_, new_n177_, new_n178_,
    new_n179_, new_n180_, new_n181_, new_n182_, new_n183_, new_n184_,
    new_n185_, new_n186_, new_n187_, new_n188_, new_n189_, new_n190_,
    new_n191_, new_n192_, new_n193_, new_n194_, new_n195_, new_n196_,
    new_n197_, new_n198_, new_n199_, new_n200_, new_n201_, new_n202_,
    new_n203_, new_n204_, new_n205_, new_n206_, new_n207_, new_n208_,
    new_n209_, new_n210_, new_n211_, new_n212_, new_n213_, new_n214_,
    new_n215_, new_n216_, new_n217_, new_n218_, new_n219_, new_n220_,
    new_n221_, new_n222_, new_n223_, new_n224_, new_n225_, new_n226_,
    new_n227_, new_n228_, new_n229_, new_n230_, new_n231_, new_n232_,
    new_n233_, new_n234_, new_n235_, new_n236_, new_n237_, new_n238_,
    new_n239_, new_n240_, new_n241_, new_n242_, new_n243_, new_n244_,
    new_n245_, new_n246_, new_n247_, new_n248_, new_n249_, new_n250_,
    new_n251_, new_n252_, new_n253_, new_n254_, new_n255_, new_n256_,
    new_n257_, new_n258_, new_n260_, new_n261_, new_n262_, new_n263_,
    new_n264_, new_n265_, new_n266_, new_n267_, new_n268_, new_n269_,
    new_n270_, new_n271_, new_n272_, new_n273_, new_n275_, new_n276_,
    new_n278_, new_n279_, new_n280_, new_n282_, new_n283_, new_n285_,
    new_n286_, new_n288_, new_n289_, new_n290_, new_n291_, new_n292_,
    new_n294_, new_n295_, new_n296_, new_n298_, new_n299_, new_n301_,
    new_n302_, new_n303_, new_n304_, new_n305_, new_n306_, new_n307_,
    new_n308_, new_n310_, new_n311_, new_n312_, new_n314_, new_n315_,
    new_n316_, new_n317_, new_n318_, new_n319_, new_n321_, new_n322_,
    new_n323_, new_n324_, new_n326_, new_n327_, new_n328_, new_n329_,
    new_n330_, new_n332_, new_n333_, new_n334_, new_n336_, new_n337_,
    new_n338_, new_n340_, new_n341_, new_n342_, new_n343_, new_n344_,
    new_n345_, new_n346_, new_n347_, new_n348_, new_n349_, new_n350_,
    new_n351_, new_n352_, new_n354_, new_n355_, new_n357_, new_n358_,
    new_n360_, new_n361_, new_n362_, new_n364_, new_n365_, new_n367_,
    new_n368_, new_n369_, new_n371_, new_n372_, new_n373_, new_n374_,
    new_n375_, new_n376_, new_n377_, new_n379_, new_n380_, new_n381_,
    new_n382_, new_n383_, new_n384_, new_n385_, new_n386_, new_n387_,
    new_n388_, new_n389_, new_n391_;
  INVx1_ASAP7_75t_R   g000(.A(p29), .Y(new_n59_));
  NOR2x1_ASAP7_75t_R  g001(.A(p2), .B(new_n59_), .Y(new_n60_));
  XNOR2x2_ASAP7_75t_R g002(.A(p19), .B(p7), .Y(new_n61_));
  INVx1_ASAP7_75t_R   g003(.A(p19), .Y(new_n62_));
  NAND2x1_ASAP7_75t_R g004(.A(p7), .B(new_n62_), .Y(new_n63_));
  INVx1_ASAP7_75t_R   g005(.A(p7), .Y(new_n64_));
  NAND2x1_ASAP7_75t_R g006(.A(p19), .B(new_n64_), .Y(new_n65_));
  NAND3x1_ASAP7_75t_R g007(.A(new_n63_), .B(new_n65_), .C(p25), .Y(new_n66_));
  OAI21x1_ASAP7_75t_R g008(.A1(p25), .A2(new_n61_), .B(new_n66_), .Y(new_n67_));
  XOR2x2_ASAP7_75t_R  g009(.A(p14), .B(p22), .Y(new_n68_));
  INVx1_ASAP7_75t_R   g010(.A(p28), .Y(new_n69_));
  NOR2x1_ASAP7_75t_R  g011(.A(p1), .B(new_n69_), .Y(new_n70_));
  XOR2x2_ASAP7_75t_R  g012(.A(new_n68_), .B(new_n70_), .Y(new_n71_));
  NOR2x1_ASAP7_75t_R  g013(.A(new_n67_), .B(new_n71_), .Y(new_n72_));
  AND2x2_ASAP7_75t_R  g014(.A(new_n67_), .B(new_n71_), .Y(new_n73_));
  NOR2x1_ASAP7_75t_R  g015(.A(p9), .B(p8), .Y(new_n74_));
  AND2x2_ASAP7_75t_R  g016(.A(p9), .B(p8), .Y(new_n75_));
  INVx1_ASAP7_75t_R   g017(.A(p15), .Y(new_n76_));
  OAI21x1_ASAP7_75t_R g018(.A1(new_n74_), .A2(new_n75_), .B(new_n76_), .Y(new_n77_));
  OR3x1_ASAP7_75t_R   g019(.A(new_n75_), .B(new_n76_), .C(new_n74_), .Y(new_n78_));
  NAND2x1_ASAP7_75t_R g020(.A(new_n77_), .B(new_n78_), .Y(new_n79_));
  NOR2x1_ASAP7_75t_R  g021(.A(p10), .B(p17), .Y(new_n80_));
  AND2x2_ASAP7_75t_R  g022(.A(p10), .B(p17), .Y(new_n81_));
  OAI21x1_ASAP7_75t_R g023(.A1(new_n80_), .A2(new_n81_), .B(p24), .Y(new_n82_));
  OR3x1_ASAP7_75t_R   g024(.A(new_n81_), .B(p24), .C(new_n80_), .Y(new_n83_));
  NAND2x1_ASAP7_75t_R g025(.A(new_n82_), .B(new_n83_), .Y(new_n84_));
  XNOR2x2_ASAP7_75t_R g026(.A(new_n79_), .B(new_n84_), .Y(new_n85_));
  OAI21x1_ASAP7_75t_R g027(.A1(new_n72_), .A2(new_n73_), .B(new_n85_), .Y(new_n86_));
  XOR2x2_ASAP7_75t_R  g028(.A(new_n79_), .B(new_n84_), .Y(new_n87_));
  XOR2x2_ASAP7_75t_R  g029(.A(new_n71_), .B(new_n67_), .Y(new_n88_));
  NAND2x1_ASAP7_75t_R g030(.A(new_n87_), .B(new_n88_), .Y(new_n89_));
  NAND2x1_ASAP7_75t_R g031(.A(new_n86_), .B(new_n89_), .Y(new_n90_));
  INVx1_ASAP7_75t_R   g032(.A(p32), .Y(new_n91_));
  INVx1_ASAP7_75t_R   g033(.A(p2), .Y(new_n92_));
  INVx1_ASAP7_75t_R   g034(.A(p23), .Y(new_n93_));
  AO21x1_ASAP7_75t_R  g035(.A1(new_n91_), .A2(new_n92_), .B(new_n93_), .Y(new_n94_));
  AOI21x1_ASAP7_75t_R g036(.A1(new_n60_), .A2(new_n90_), .B(new_n94_), .Y(new_n95_));
  INVx1_ASAP7_75t_R   g037(.A(new_n95_), .Y(new_n96_));
  OAI21x1_ASAP7_75t_R g038(.A1(new_n72_), .A2(new_n73_), .B(new_n87_), .Y(new_n97_));
  NAND2x1_ASAP7_75t_R g039(.A(new_n85_), .B(new_n88_), .Y(new_n98_));
  NAND2x1_ASAP7_75t_R g040(.A(new_n97_), .B(new_n98_), .Y(new_n99_));
  OAI21x1_ASAP7_75t_R g041(.A1(p2), .A2(new_n99_), .B(new_n59_), .Y(new_n100_));
  INVx1_ASAP7_75t_R   g042(.A(new_n100_), .Y(new_n101_));
  OR3x1_ASAP7_75t_R   g043(.A(p3), .B(p1), .C(p2), .Y(new_n102_));
  NOR2x1_ASAP7_75t_R  g044(.A(p4), .B(p1), .Y(new_n103_));
  INVx1_ASAP7_75t_R   g045(.A(new_n103_), .Y(new_n104_));
  AND2x2_ASAP7_75t_R  g046(.A(p0), .B(new_n91_), .Y(new_n105_));
  AOI21x1_ASAP7_75t_R g047(.A1(new_n102_), .A2(new_n104_), .B(new_n105_), .Y(new_n106_));
  INVx1_ASAP7_75t_R   g048(.A(new_n106_), .Y(new_n107_));
  INVx1_ASAP7_75t_R   g049(.A(p1), .Y(new_n108_));
  AND3x1_ASAP7_75t_R  g050(.A(new_n91_), .B(new_n108_), .C(p11), .Y(new_n109_));
  XOR2x2_ASAP7_75t_R  g051(.A(p9), .B(p8), .Y(new_n110_));
  XOR2x2_ASAP7_75t_R  g052(.A(new_n109_), .B(new_n110_), .Y(new_n111_));
  XOR2x2_ASAP7_75t_R  g053(.A(p10), .B(p7), .Y(new_n112_));
  XNOR2x2_ASAP7_75t_R g054(.A(p5), .B(p6), .Y(new_n113_));
  NAND2x1_ASAP7_75t_R g055(.A(new_n112_), .B(new_n113_), .Y(new_n114_));
  XOR2x2_ASAP7_75t_R  g056(.A(p5), .B(p6), .Y(new_n115_));
  XNOR2x2_ASAP7_75t_R g057(.A(p10), .B(p7), .Y(new_n116_));
  NAND2x1_ASAP7_75t_R g058(.A(new_n115_), .B(new_n116_), .Y(new_n117_));
  NAND2x1_ASAP7_75t_R g059(.A(new_n114_), .B(new_n117_), .Y(new_n118_));
  XOR2x2_ASAP7_75t_R  g060(.A(new_n111_), .B(new_n118_), .Y(new_n119_));
  NOR2x1_ASAP7_75t_R  g061(.A(p12), .B(p2), .Y(new_n120_));
  INVx1_ASAP7_75t_R   g062(.A(p11), .Y(new_n121_));
  OR3x1_ASAP7_75t_R   g063(.A(new_n121_), .B(p32), .C(p1), .Y(new_n122_));
  AOI21x1_ASAP7_75t_R g064(.A1(new_n114_), .A2(new_n117_), .B(new_n122_), .Y(new_n123_));
  AND3x1_ASAP7_75t_R  g065(.A(new_n114_), .B(new_n117_), .C(new_n122_), .Y(new_n124_));
  XNOR2x2_ASAP7_75t_R g066(.A(p9), .B(p8), .Y(new_n125_));
  OAI21x1_ASAP7_75t_R g067(.A1(new_n123_), .A2(new_n124_), .B(new_n125_), .Y(new_n126_));
  AOI21x1_ASAP7_75t_R g068(.A1(new_n112_), .A2(new_n113_), .B(new_n109_), .Y(new_n127_));
  AOI21x1_ASAP7_75t_R g069(.A1(new_n117_), .A2(new_n127_), .B(new_n125_), .Y(new_n128_));
  AO21x1_ASAP7_75t_R  g070(.A1(new_n114_), .A2(new_n117_), .B(new_n122_), .Y(new_n129_));
  AOI21x1_ASAP7_75t_R g071(.A1(new_n128_), .A2(new_n129_), .B(p2), .Y(new_n130_));
  INVx1_ASAP7_75t_R   g072(.A(p12), .Y(new_n131_));
  AOI21x1_ASAP7_75t_R g073(.A1(new_n126_), .A2(new_n130_), .B(new_n131_), .Y(new_n132_));
  AOI21x1_ASAP7_75t_R g074(.A1(new_n119_), .A2(new_n120_), .B(new_n132_), .Y(new_n133_));
  NOR2x1_ASAP7_75t_R  g075(.A(p14), .B(p13), .Y(new_n134_));
  AND2x2_ASAP7_75t_R  g076(.A(p14), .B(p13), .Y(new_n135_));
  OAI21x1_ASAP7_75t_R g077(.A1(new_n134_), .A2(new_n135_), .B(new_n76_), .Y(new_n136_));
  OAI21x1_ASAP7_75t_R g078(.A1(p14), .A2(p13), .B(p15), .Y(new_n137_));
  AO21x1_ASAP7_75t_R  g079(.A1(p14), .A2(p13), .B(new_n137_), .Y(new_n138_));
  NOR2x1_ASAP7_75t_R  g080(.A(p1), .B(p0), .Y(new_n139_));
  NAND2x1_ASAP7_75t_R g081(.A(p16), .B(new_n139_), .Y(new_n140_));
  AOI21x1_ASAP7_75t_R g082(.A1(new_n136_), .A2(new_n138_), .B(new_n140_), .Y(new_n141_));
  AND3x1_ASAP7_75t_R  g083(.A(new_n138_), .B(new_n136_), .C(new_n140_), .Y(new_n142_));
  XOR2x2_ASAP7_75t_R  g084(.A(p18), .B(p5), .Y(new_n143_));
  AOI21x1_ASAP7_75t_R g085(.A1(p18), .A2(p5), .B(p19), .Y(new_n144_));
  OAI21x1_ASAP7_75t_R g086(.A1(p18), .A2(p5), .B(new_n144_), .Y(new_n145_));
  OA21x2_ASAP7_75t_R  g087(.A1(new_n62_), .A2(new_n143_), .B(new_n145_), .Y(new_n146_));
  OAI21x1_ASAP7_75t_R g088(.A1(new_n141_), .A2(new_n142_), .B(new_n146_), .Y(new_n147_));
  OR3x1_ASAP7_75t_R   g089(.A(new_n142_), .B(new_n146_), .C(new_n141_), .Y(new_n148_));
  XNOR2x2_ASAP7_75t_R g090(.A(p8), .B(p17), .Y(new_n149_));
  AO21x1_ASAP7_75t_R  g091(.A1(new_n147_), .A2(new_n148_), .B(new_n149_), .Y(new_n150_));
  OA21x2_ASAP7_75t_R  g092(.A1(new_n134_), .A2(new_n135_), .B(new_n76_), .Y(new_n151_));
  OAI21x1_ASAP7_75t_R g093(.A1(new_n135_), .A2(new_n137_), .B(new_n140_), .Y(new_n152_));
  OAI21x1_ASAP7_75t_R g094(.A1(new_n62_), .A2(new_n143_), .B(new_n145_), .Y(new_n153_));
  OAI21x1_ASAP7_75t_R g095(.A1(new_n151_), .A2(new_n152_), .B(new_n153_), .Y(new_n154_));
  OAI21x1_ASAP7_75t_R g096(.A1(new_n141_), .A2(new_n154_), .B(new_n149_), .Y(new_n155_));
  OA21x2_ASAP7_75t_R  g097(.A1(new_n141_), .A2(new_n142_), .B(new_n146_), .Y(new_n156_));
  NOR2x1_ASAP7_75t_R  g098(.A(p20), .B(p2), .Y(new_n157_));
  OA21x2_ASAP7_75t_R  g099(.A1(new_n155_), .A2(new_n156_), .B(new_n157_), .Y(new_n158_));
  NAND2x1_ASAP7_75t_R g100(.A(new_n150_), .B(new_n158_), .Y(new_n159_));
  AOI21x1_ASAP7_75t_R g101(.A1(new_n147_), .A2(new_n148_), .B(new_n149_), .Y(new_n160_));
  OAI21x1_ASAP7_75t_R g102(.A1(new_n155_), .A2(new_n156_), .B(new_n92_), .Y(new_n161_));
  OAI21x1_ASAP7_75t_R g103(.A1(new_n160_), .A2(new_n161_), .B(p20), .Y(new_n162_));
  NAND3x1_ASAP7_75t_R g104(.A(new_n133_), .B(new_n159_), .C(new_n162_), .Y(new_n163_));
  NOR2x1_ASAP7_75t_R  g105(.A(new_n107_), .B(new_n163_), .Y(new_n164_));
  OAI21x1_ASAP7_75t_R g106(.A1(new_n96_), .A2(new_n101_), .B(new_n164_), .Y(new_n165_));
  INVx1_ASAP7_75t_R   g107(.A(p6), .Y(new_n166_));
  NOR2x1_ASAP7_75t_R  g108(.A(p21), .B(new_n166_), .Y(new_n167_));
  INVx1_ASAP7_75t_R   g109(.A(p18), .Y(new_n168_));
  AO21x1_ASAP7_75t_R  g110(.A1(p21), .A2(new_n166_), .B(new_n168_), .Y(new_n169_));
  INVx1_ASAP7_75t_R   g111(.A(p21), .Y(new_n170_));
  NOR2x1_ASAP7_75t_R  g112(.A(p6), .B(new_n170_), .Y(new_n171_));
  OAI21x1_ASAP7_75t_R g113(.A1(new_n167_), .A2(new_n171_), .B(new_n168_), .Y(new_n172_));
  OAI21x1_ASAP7_75t_R g114(.A1(new_n167_), .A2(new_n169_), .B(new_n172_), .Y(new_n173_));
  XOR2x2_ASAP7_75t_R  g115(.A(p25), .B(p7), .Y(new_n174_));
  XOR2x2_ASAP7_75t_R  g116(.A(new_n174_), .B(new_n62_), .Y(new_n175_));
  NOR2x1_ASAP7_75t_R  g117(.A(new_n173_), .B(new_n175_), .Y(new_n176_));
  OAI21x1_ASAP7_75t_R g118(.A1(new_n167_), .A2(new_n171_), .B(p18), .Y(new_n177_));
  NAND2x1_ASAP7_75t_R g119(.A(p6), .B(new_n170_), .Y(new_n178_));
  NAND2x1_ASAP7_75t_R g120(.A(p21), .B(new_n166_), .Y(new_n179_));
  NAND3x1_ASAP7_75t_R g121(.A(new_n178_), .B(new_n179_), .C(new_n168_), .Y(new_n180_));
  NAND2x1_ASAP7_75t_R g122(.A(new_n177_), .B(new_n180_), .Y(new_n181_));
  XNOR2x2_ASAP7_75t_R g123(.A(p5), .B(p22), .Y(new_n182_));
  OAI21x1_ASAP7_75t_R g124(.A1(new_n67_), .A2(new_n181_), .B(new_n182_), .Y(new_n183_));
  NOR2x1_ASAP7_75t_R  g125(.A(new_n176_), .B(new_n183_), .Y(new_n184_));
  AND2x2_ASAP7_75t_R  g126(.A(p19), .B(new_n174_), .Y(new_n185_));
  NOR2x1_ASAP7_75t_R  g127(.A(p19), .B(new_n174_), .Y(new_n186_));
  OAI21x1_ASAP7_75t_R g128(.A1(new_n185_), .A2(new_n186_), .B(new_n173_), .Y(new_n187_));
  NAND2x1_ASAP7_75t_R g129(.A(new_n67_), .B(new_n181_), .Y(new_n188_));
  AOI21x1_ASAP7_75t_R g130(.A1(new_n187_), .A2(new_n188_), .B(new_n182_), .Y(new_n189_));
  AO21x1_ASAP7_75t_R  g131(.A1(p30), .A2(new_n108_), .B(p13), .Y(new_n190_));
  INVx1_ASAP7_75t_R   g132(.A(p30), .Y(new_n191_));
  INVx1_ASAP7_75t_R   g133(.A(p13), .Y(new_n192_));
  OR3x1_ASAP7_75t_R   g134(.A(new_n191_), .B(new_n192_), .C(p1), .Y(new_n193_));
  NAND2x1_ASAP7_75t_R g135(.A(new_n190_), .B(new_n193_), .Y(new_n194_));
  NAND2x1_ASAP7_75t_R g136(.A(new_n194_), .B(new_n79_), .Y(new_n195_));
  AND2x2_ASAP7_75t_R  g137(.A(new_n190_), .B(new_n193_), .Y(new_n196_));
  NAND3x1_ASAP7_75t_R g138(.A(new_n196_), .B(new_n78_), .C(new_n77_), .Y(new_n197_));
  AND2x2_ASAP7_75t_R  g139(.A(new_n195_), .B(new_n197_), .Y(new_n198_));
  OR3x1_ASAP7_75t_R   g140(.A(new_n184_), .B(new_n189_), .C(new_n198_), .Y(new_n199_));
  OAI21x1_ASAP7_75t_R g141(.A1(new_n189_), .A2(new_n184_), .B(new_n198_), .Y(new_n200_));
  AND3x1_ASAP7_75t_R  g142(.A(new_n92_), .B(p26), .C(p0), .Y(new_n201_));
  NAND3x1_ASAP7_75t_R g143(.A(new_n199_), .B(new_n200_), .C(new_n201_), .Y(new_n202_));
  NAND2x1_ASAP7_75t_R g144(.A(new_n195_), .B(new_n197_), .Y(new_n203_));
  OR3x1_ASAP7_75t_R   g145(.A(new_n175_), .B(new_n182_), .C(new_n173_), .Y(new_n204_));
  OR3x1_ASAP7_75t_R   g146(.A(new_n181_), .B(new_n67_), .C(new_n182_), .Y(new_n205_));
  NAND3x1_ASAP7_75t_R g147(.A(new_n203_), .B(new_n204_), .C(new_n205_), .Y(new_n206_));
  OAI21x1_ASAP7_75t_R g148(.A1(new_n184_), .A2(new_n206_), .B(new_n200_), .Y(new_n207_));
  AND2x2_ASAP7_75t_R  g149(.A(p26), .B(p0), .Y(new_n208_));
  AO21x1_ASAP7_75t_R  g150(.A1(p26), .A2(p2), .B(new_n208_), .Y(new_n209_));
  INVx1_ASAP7_75t_R   g151(.A(new_n209_), .Y(new_n210_));
  OAI21x1_ASAP7_75t_R g152(.A1(p2), .A2(new_n207_), .B(new_n210_), .Y(new_n211_));
  NAND2x1_ASAP7_75t_R g153(.A(new_n202_), .B(new_n211_), .Y(new_n212_));
  INVx1_ASAP7_75t_R   g154(.A(p25), .Y(new_n213_));
  AOI21x1_ASAP7_75t_R g155(.A1(p26), .A2(new_n139_), .B(new_n213_), .Y(new_n214_));
  AND3x1_ASAP7_75t_R  g156(.A(new_n139_), .B(p26), .C(new_n213_), .Y(new_n215_));
  NOR2x1_ASAP7_75t_R  g157(.A(new_n214_), .B(new_n215_), .Y(new_n216_));
  XOR2x2_ASAP7_75t_R  g158(.A(new_n173_), .B(new_n216_), .Y(new_n217_));
  NAND2x1_ASAP7_75t_R g159(.A(new_n217_), .B(new_n85_), .Y(new_n218_));
  XOR2x2_ASAP7_75t_R  g160(.A(new_n181_), .B(new_n216_), .Y(new_n219_));
  NAND2x1_ASAP7_75t_R g161(.A(new_n87_), .B(new_n219_), .Y(new_n220_));
  INVx1_ASAP7_75t_R   g162(.A(p27), .Y(new_n221_));
  NOR2x1_ASAP7_75t_R  g163(.A(p2), .B(new_n221_), .Y(new_n222_));
  NAND3x1_ASAP7_75t_R g164(.A(new_n218_), .B(new_n220_), .C(new_n222_), .Y(new_n223_));
  NAND2x1_ASAP7_75t_R g165(.A(new_n220_), .B(new_n218_), .Y(new_n224_));
  OAI21x1_ASAP7_75t_R g166(.A1(p2), .A2(new_n224_), .B(new_n221_), .Y(new_n225_));
  NAND2x1_ASAP7_75t_R g167(.A(new_n91_), .B(new_n108_), .Y(new_n226_));
  OAI21x1_ASAP7_75t_R g168(.A1(new_n93_), .A2(new_n226_), .B(p24), .Y(new_n227_));
  OR3x1_ASAP7_75t_R   g169(.A(new_n226_), .B(new_n93_), .C(p24), .Y(new_n228_));
  NAND2x1_ASAP7_75t_R g170(.A(new_n227_), .B(new_n228_), .Y(new_n229_));
  INVx1_ASAP7_75t_R   g171(.A(p22), .Y(new_n230_));
  AO21x1_ASAP7_75t_R  g172(.A1(new_n136_), .A2(new_n138_), .B(new_n230_), .Y(new_n231_));
  NAND3x1_ASAP7_75t_R g173(.A(new_n138_), .B(new_n136_), .C(new_n230_), .Y(new_n232_));
  AND3x1_ASAP7_75t_R  g174(.A(new_n229_), .B(new_n231_), .C(new_n232_), .Y(new_n233_));
  XOR2x2_ASAP7_75t_R  g175(.A(p9), .B(p21), .Y(new_n234_));
  AOI21x1_ASAP7_75t_R g176(.A1(new_n231_), .A2(new_n232_), .B(new_n229_), .Y(new_n235_));
  OR3x1_ASAP7_75t_R   g177(.A(new_n233_), .B(new_n234_), .C(new_n235_), .Y(new_n236_));
  OA21x2_ASAP7_75t_R  g178(.A1(p32), .A2(p2), .B(p11), .Y(new_n237_));
  XOR2x2_ASAP7_75t_R  g179(.A(p24), .B(p22), .Y(new_n238_));
  OR3x1_ASAP7_75t_R   g180(.A(new_n238_), .B(new_n93_), .C(new_n226_), .Y(new_n239_));
  OAI21x1_ASAP7_75t_R g181(.A1(new_n93_), .A2(new_n226_), .B(new_n238_), .Y(new_n240_));
  NAND2x1_ASAP7_75t_R g182(.A(new_n136_), .B(new_n138_), .Y(new_n241_));
  AO21x1_ASAP7_75t_R  g183(.A1(new_n239_), .A2(new_n240_), .B(new_n241_), .Y(new_n242_));
  NAND3x1_ASAP7_75t_R g184(.A(new_n241_), .B(new_n239_), .C(new_n240_), .Y(new_n243_));
  NAND3x1_ASAP7_75t_R g185(.A(new_n242_), .B(new_n234_), .C(new_n243_), .Y(new_n244_));
  NAND3x1_ASAP7_75t_R g186(.A(new_n236_), .B(new_n237_), .C(new_n244_), .Y(new_n245_));
  INVx1_ASAP7_75t_R   g187(.A(new_n234_), .Y(new_n246_));
  AO21x1_ASAP7_75t_R  g188(.A1(new_n243_), .A2(new_n242_), .B(new_n246_), .Y(new_n247_));
  NAND3x1_ASAP7_75t_R g189(.A(new_n242_), .B(new_n246_), .C(new_n243_), .Y(new_n248_));
  NOR2x1_ASAP7_75t_R  g190(.A(p2), .B(new_n237_), .Y(new_n249_));
  NAND3x1_ASAP7_75t_R g191(.A(new_n247_), .B(new_n248_), .C(new_n249_), .Y(new_n250_));
  NAND2x1_ASAP7_75t_R g192(.A(p11), .B(p2), .Y(new_n251_));
  NAND3x1_ASAP7_75t_R g193(.A(new_n245_), .B(new_n250_), .C(new_n251_), .Y(new_n252_));
  AOI21x1_ASAP7_75t_R g194(.A1(new_n223_), .A2(new_n225_), .B(new_n252_), .Y(new_n253_));
  OA21x2_ASAP7_75t_R  g195(.A1(p0), .A2(p2), .B(p16), .Y(new_n254_));
  NAND3x1_ASAP7_75t_R g196(.A(new_n212_), .B(new_n253_), .C(new_n254_), .Y(new_n255_));
  INVx1_ASAP7_75t_R   g197(.A(p14), .Y(new_n256_));
  OAI21x1_ASAP7_75t_R g198(.A1(new_n165_), .A2(new_n255_), .B(new_n256_), .Y(new_n257_));
  OR3x1_ASAP7_75t_R   g199(.A(new_n255_), .B(new_n256_), .C(new_n165_), .Y(new_n258_));
  NAND2x1_ASAP7_75t_R g200(.A(new_n257_), .B(new_n258_), .Y(o0));
  OR3x1_ASAP7_75t_R   g201(.A(p31), .B(p1), .C(p2), .Y(new_n260_));
  AO21x1_ASAP7_75t_R  g202(.A1(new_n91_), .A2(p0), .B(new_n260_), .Y(new_n261_));
  AO21x1_ASAP7_75t_R  g203(.A1(new_n91_), .A2(p0), .B(new_n104_), .Y(new_n262_));
  NAND2x1_ASAP7_75t_R g204(.A(new_n261_), .B(new_n262_), .Y(new_n263_));
  INVx1_ASAP7_75t_R   g205(.A(new_n263_), .Y(new_n264_));
  NOR2x1_ASAP7_75t_R  g206(.A(new_n264_), .B(new_n163_), .Y(new_n265_));
  OA21x2_ASAP7_75t_R  g207(.A1(new_n96_), .A2(new_n101_), .B(new_n265_), .Y(new_n266_));
  NAND3x1_ASAP7_75t_R g208(.A(new_n199_), .B(new_n92_), .C(new_n200_), .Y(new_n267_));
  INVx1_ASAP7_75t_R   g209(.A(new_n254_), .Y(new_n268_));
  OR3x1_ASAP7_75t_R   g210(.A(new_n267_), .B(new_n208_), .C(new_n268_), .Y(new_n269_));
  NAND3x1_ASAP7_75t_R g211(.A(new_n267_), .B(new_n209_), .C(new_n254_), .Y(new_n270_));
  AND3x1_ASAP7_75t_R  g212(.A(new_n253_), .B(new_n269_), .C(new_n270_), .Y(new_n271_));
  AOI21x1_ASAP7_75t_R g213(.A1(new_n266_), .A2(new_n271_), .B(new_n213_), .Y(new_n272_));
  AND3x1_ASAP7_75t_R  g214(.A(new_n271_), .B(new_n213_), .C(new_n266_), .Y(new_n273_));
  NOR2x1_ASAP7_75t_R  g215(.A(new_n272_), .B(new_n273_), .Y(o1));
  AOI21x1_ASAP7_75t_R g216(.A1(new_n266_), .A2(new_n271_), .B(new_n62_), .Y(new_n275_));
  AND3x1_ASAP7_75t_R  g217(.A(new_n271_), .B(new_n62_), .C(new_n266_), .Y(new_n276_));
  NOR2x1_ASAP7_75t_R  g218(.A(new_n275_), .B(new_n276_), .Y(o2));
  INVx1_ASAP7_75t_R   g219(.A(p24), .Y(new_n278_));
  OAI21x1_ASAP7_75t_R g220(.A1(new_n165_), .A2(new_n255_), .B(new_n278_), .Y(new_n279_));
  OR3x1_ASAP7_75t_R   g221(.A(new_n255_), .B(new_n278_), .C(new_n165_), .Y(new_n280_));
  NAND2x1_ASAP7_75t_R g222(.A(new_n279_), .B(new_n280_), .Y(o3));
  AOI21x1_ASAP7_75t_R g223(.A1(new_n266_), .A2(new_n271_), .B(new_n64_), .Y(new_n282_));
  AND3x1_ASAP7_75t_R  g224(.A(new_n271_), .B(new_n64_), .C(new_n266_), .Y(new_n283_));
  NOR2x1_ASAP7_75t_R  g225(.A(new_n282_), .B(new_n283_), .Y(o4));
  AOI21x1_ASAP7_75t_R g226(.A1(new_n266_), .A2(new_n271_), .B(new_n230_), .Y(new_n285_));
  AND3x1_ASAP7_75t_R  g227(.A(new_n271_), .B(new_n230_), .C(new_n266_), .Y(new_n286_));
  NOR2x1_ASAP7_75t_R  g228(.A(new_n285_), .B(new_n286_), .Y(o5));
  NAND3x1_ASAP7_75t_R g229(.A(new_n211_), .B(new_n202_), .C(new_n254_), .Y(new_n288_));
  NAND2x1_ASAP7_75t_R g230(.A(new_n253_), .B(new_n288_), .Y(new_n289_));
  INVx1_ASAP7_75t_R   g231(.A(p9), .Y(new_n290_));
  OAI21x1_ASAP7_75t_R g232(.A1(new_n165_), .A2(new_n289_), .B(new_n290_), .Y(new_n291_));
  OR3x1_ASAP7_75t_R   g233(.A(new_n289_), .B(new_n290_), .C(new_n165_), .Y(new_n292_));
  NAND2x1_ASAP7_75t_R g234(.A(new_n291_), .B(new_n292_), .Y(o6));
  INVx1_ASAP7_75t_R   g235(.A(p8), .Y(new_n294_));
  OAI21x1_ASAP7_75t_R g236(.A1(new_n165_), .A2(new_n289_), .B(new_n294_), .Y(new_n295_));
  OR3x1_ASAP7_75t_R   g237(.A(new_n289_), .B(new_n294_), .C(new_n165_), .Y(new_n296_));
  NAND2x1_ASAP7_75t_R g238(.A(new_n295_), .B(new_n296_), .Y(o7));
  OAI21x1_ASAP7_75t_R g239(.A1(new_n165_), .A2(new_n289_), .B(new_n76_), .Y(new_n298_));
  OR3x1_ASAP7_75t_R   g240(.A(new_n289_), .B(new_n76_), .C(new_n165_), .Y(new_n299_));
  NAND2x1_ASAP7_75t_R g241(.A(new_n298_), .B(new_n299_), .Y(o8));
  NAND2x1_ASAP7_75t_R g242(.A(new_n60_), .B(new_n90_), .Y(new_n301_));
  AO21x1_ASAP7_75t_R  g243(.A1(new_n301_), .A2(new_n100_), .B(new_n94_), .Y(new_n302_));
  OR3x1_ASAP7_75t_R   g244(.A(new_n163_), .B(p18), .C(new_n264_), .Y(new_n303_));
  NOR3x1_ASAP7_75t_R  g245(.A(new_n289_), .B(new_n302_), .C(new_n303_), .Y(new_n304_));
  AND2x2_ASAP7_75t_R  g246(.A(new_n265_), .B(new_n253_), .Y(new_n305_));
  AND3x1_ASAP7_75t_R  g247(.A(new_n211_), .B(new_n202_), .C(new_n254_), .Y(new_n306_));
  NOR2x1_ASAP7_75t_R  g248(.A(new_n302_), .B(new_n306_), .Y(new_n307_));
  AOI21x1_ASAP7_75t_R g249(.A1(new_n305_), .A2(new_n307_), .B(new_n168_), .Y(new_n308_));
  NOR2x1_ASAP7_75t_R  g250(.A(new_n304_), .B(new_n308_), .Y(o9));
  OR3x1_ASAP7_75t_R   g251(.A(new_n163_), .B(p6), .C(new_n264_), .Y(new_n310_));
  NOR3x1_ASAP7_75t_R  g252(.A(new_n289_), .B(new_n302_), .C(new_n310_), .Y(new_n311_));
  AOI21x1_ASAP7_75t_R g253(.A1(new_n305_), .A2(new_n307_), .B(new_n166_), .Y(new_n312_));
  NOR2x1_ASAP7_75t_R  g254(.A(new_n311_), .B(new_n312_), .Y(o10));
  NAND2x1_ASAP7_75t_R g255(.A(new_n301_), .B(new_n100_), .Y(new_n314_));
  INVx1_ASAP7_75t_R   g256(.A(new_n94_), .Y(new_n315_));
  NAND3x1_ASAP7_75t_R g257(.A(new_n314_), .B(new_n170_), .C(new_n315_), .Y(new_n316_));
  AO21x1_ASAP7_75t_R  g258(.A1(new_n262_), .A2(new_n261_), .B(new_n163_), .Y(new_n317_));
  NOR3x1_ASAP7_75t_R  g259(.A(new_n289_), .B(new_n316_), .C(new_n317_), .Y(new_n318_));
  AOI21x1_ASAP7_75t_R g260(.A1(new_n305_), .A2(new_n307_), .B(new_n170_), .Y(new_n319_));
  NOR2x1_ASAP7_75t_R  g261(.A(new_n318_), .B(new_n319_), .Y(o11));
  OR3x1_ASAP7_75t_R   g262(.A(new_n163_), .B(p5), .C(new_n264_), .Y(new_n321_));
  NOR3x1_ASAP7_75t_R  g263(.A(new_n289_), .B(new_n302_), .C(new_n321_), .Y(new_n322_));
  INVx1_ASAP7_75t_R   g264(.A(p5), .Y(new_n323_));
  AOI21x1_ASAP7_75t_R g265(.A1(new_n305_), .A2(new_n307_), .B(new_n323_), .Y(new_n324_));
  NOR2x1_ASAP7_75t_R  g266(.A(new_n322_), .B(new_n324_), .Y(o12));
  NAND3x1_ASAP7_75t_R g267(.A(new_n314_), .B(new_n164_), .C(new_n315_), .Y(new_n326_));
  OAI21x1_ASAP7_75t_R g268(.A1(new_n326_), .A2(new_n289_), .B(new_n192_), .Y(new_n327_));
  AND3x1_ASAP7_75t_R  g269(.A(new_n159_), .B(p13), .C(new_n106_), .Y(new_n328_));
  NAND3x1_ASAP7_75t_R g270(.A(new_n328_), .B(new_n162_), .C(new_n133_), .Y(new_n329_));
  OR3x1_ASAP7_75t_R   g271(.A(new_n289_), .B(new_n302_), .C(new_n329_), .Y(new_n330_));
  NAND2x1_ASAP7_75t_R g272(.A(new_n327_), .B(new_n330_), .Y(o13));
  INVx1_ASAP7_75t_R   g273(.A(p17), .Y(new_n332_));
  OAI21x1_ASAP7_75t_R g274(.A1(new_n165_), .A2(new_n255_), .B(new_n332_), .Y(new_n333_));
  OR3x1_ASAP7_75t_R   g275(.A(new_n255_), .B(new_n332_), .C(new_n165_), .Y(new_n334_));
  NAND2x1_ASAP7_75t_R g276(.A(new_n333_), .B(new_n334_), .Y(o14));
  INVx1_ASAP7_75t_R   g277(.A(p10), .Y(new_n336_));
  OAI21x1_ASAP7_75t_R g278(.A1(new_n165_), .A2(new_n255_), .B(new_n336_), .Y(new_n337_));
  OR3x1_ASAP7_75t_R   g279(.A(new_n255_), .B(new_n336_), .C(new_n165_), .Y(new_n338_));
  NAND2x1_ASAP7_75t_R g280(.A(new_n337_), .B(new_n338_), .Y(o15));
  INVx1_ASAP7_75t_R   g281(.A(p4), .Y(new_n340_));
  NOR2x1_ASAP7_75t_R  g282(.A(new_n106_), .B(new_n263_), .Y(new_n341_));
  AOI21x1_ASAP7_75t_R g283(.A1(new_n150_), .A2(new_n158_), .B(new_n341_), .Y(new_n342_));
  NAND3x1_ASAP7_75t_R g284(.A(new_n342_), .B(new_n133_), .C(new_n162_), .Y(new_n343_));
  AOI21x1_ASAP7_75t_R g285(.A1(new_n95_), .A2(new_n100_), .B(new_n343_), .Y(new_n344_));
  NAND3x1_ASAP7_75t_R g286(.A(new_n288_), .B(new_n253_), .C(new_n344_), .Y(new_n345_));
  AND3x1_ASAP7_75t_R  g287(.A(new_n133_), .B(new_n159_), .C(new_n162_), .Y(new_n346_));
  AND2x2_ASAP7_75t_R  g288(.A(new_n346_), .B(new_n253_), .Y(new_n347_));
  AND2x2_ASAP7_75t_R  g289(.A(new_n94_), .B(new_n268_), .Y(new_n348_));
  OA21x2_ASAP7_75t_R  g290(.A1(new_n208_), .A2(new_n267_), .B(new_n348_), .Y(new_n349_));
  NAND2x1_ASAP7_75t_R g291(.A(new_n209_), .B(new_n267_), .Y(new_n350_));
  AND3x1_ASAP7_75t_R  g292(.A(new_n349_), .B(new_n314_), .C(new_n350_), .Y(new_n351_));
  AOI21x1_ASAP7_75t_R g293(.A1(new_n347_), .A2(new_n351_), .B(p1), .Y(new_n352_));
  OAI21x1_ASAP7_75t_R g294(.A1(new_n340_), .A2(new_n345_), .B(new_n352_), .Y(o16));
  NAND3x1_ASAP7_75t_R g295(.A(new_n271_), .B(new_n201_), .C(new_n344_), .Y(new_n354_));
  OAI21x1_ASAP7_75t_R g296(.A1(new_n202_), .A2(new_n345_), .B(new_n104_), .Y(new_n355_));
  AOI21x1_ASAP7_75t_R g297(.A1(new_n207_), .A2(new_n354_), .B(new_n355_), .Y(o17));
  NAND3x1_ASAP7_75t_R g298(.A(new_n271_), .B(new_n60_), .C(new_n344_), .Y(new_n357_));
  OAI21x1_ASAP7_75t_R g299(.A1(new_n301_), .A2(new_n345_), .B(new_n104_), .Y(new_n358_));
  AOI21x1_ASAP7_75t_R g300(.A1(new_n99_), .A2(new_n357_), .B(new_n358_), .Y(o18));
  OA21x2_ASAP7_75t_R  g301(.A1(new_n156_), .A2(new_n155_), .B(new_n150_), .Y(new_n360_));
  AND2x2_ASAP7_75t_R  g302(.A(p20), .B(new_n92_), .Y(new_n361_));
  NAND3x1_ASAP7_75t_R g303(.A(new_n271_), .B(new_n344_), .C(new_n361_), .Y(new_n362_));
  AOI21x1_ASAP7_75t_R g304(.A1(new_n360_), .A2(new_n362_), .B(new_n103_), .Y(o19));
  NOR2x1_ASAP7_75t_R  g305(.A(p2), .B(new_n131_), .Y(new_n364_));
  NAND3x1_ASAP7_75t_R g306(.A(new_n271_), .B(new_n344_), .C(new_n364_), .Y(new_n365_));
  AOI21x1_ASAP7_75t_R g307(.A1(new_n119_), .A2(new_n365_), .B(new_n103_), .Y(o20));
  AND2x2_ASAP7_75t_R  g308(.A(new_n248_), .B(new_n247_), .Y(new_n367_));
  AND3x1_ASAP7_75t_R  g309(.A(new_n92_), .B(p32), .C(p11), .Y(new_n368_));
  NAND3x1_ASAP7_75t_R g310(.A(new_n271_), .B(new_n344_), .C(new_n368_), .Y(new_n369_));
  AOI21x1_ASAP7_75t_R g311(.A1(new_n367_), .A2(new_n369_), .B(new_n103_), .Y(o21));
  OAI21x1_ASAP7_75t_R g312(.A1(new_n96_), .A2(new_n101_), .B(new_n265_), .Y(new_n371_));
  NOR2x1_ASAP7_75t_R  g313(.A(p31), .B(p1), .Y(new_n372_));
  OR3x1_ASAP7_75t_R   g314(.A(new_n184_), .B(new_n189_), .C(new_n372_), .Y(new_n373_));
  AO21x1_ASAP7_75t_R  g315(.A1(p30), .A2(p31), .B(p1), .Y(new_n374_));
  XOR2x2_ASAP7_75t_R  g316(.A(new_n373_), .B(new_n374_), .Y(new_n375_));
  OAI21x1_ASAP7_75t_R g317(.A1(new_n371_), .A2(new_n289_), .B(new_n375_), .Y(new_n376_));
  OR3x1_ASAP7_75t_R   g318(.A(new_n289_), .B(new_n371_), .C(new_n375_), .Y(new_n377_));
  NAND2x1_ASAP7_75t_R g319(.A(new_n376_), .B(new_n377_), .Y(o22));
  AO21x1_ASAP7_75t_R  g320(.A1(p3), .A2(p28), .B(p1), .Y(new_n379_));
  NOR2x1_ASAP7_75t_R  g321(.A(new_n134_), .B(new_n135_), .Y(new_n380_));
  AND2x2_ASAP7_75t_R  g322(.A(new_n380_), .B(new_n85_), .Y(new_n381_));
  NOR2x1_ASAP7_75t_R  g323(.A(p3), .B(p1), .Y(new_n382_));
  NOR2x1_ASAP7_75t_R  g324(.A(new_n380_), .B(new_n85_), .Y(new_n383_));
  OR3x1_ASAP7_75t_R   g325(.A(new_n381_), .B(new_n382_), .C(new_n383_), .Y(new_n384_));
  XNOR2x2_ASAP7_75t_R g326(.A(new_n379_), .B(new_n384_), .Y(new_n385_));
  NOR3x1_ASAP7_75t_R  g327(.A(new_n289_), .B(new_n165_), .C(new_n385_), .Y(new_n386_));
  OA21x2_ASAP7_75t_R  g328(.A1(new_n101_), .A2(new_n96_), .B(new_n164_), .Y(new_n387_));
  INVx1_ASAP7_75t_R   g329(.A(new_n385_), .Y(new_n388_));
  AOI21x1_ASAP7_75t_R g330(.A1(new_n387_), .A2(new_n271_), .B(new_n388_), .Y(new_n389_));
  NOR2x1_ASAP7_75t_R  g331(.A(new_n386_), .B(new_n389_), .Y(o23));
  AND3x1_ASAP7_75t_R  g332(.A(new_n218_), .B(new_n220_), .C(new_n104_), .Y(new_n391_));
  OA21x2_ASAP7_75t_R  g333(.A1(new_n223_), .A2(new_n345_), .B(new_n391_), .Y(o24));
endmodule


