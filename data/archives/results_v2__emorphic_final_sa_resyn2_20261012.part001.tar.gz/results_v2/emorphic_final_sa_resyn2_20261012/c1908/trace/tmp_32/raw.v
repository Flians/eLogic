// Benchmark "/tmp/" written by ABC on Mon Oct 12 14:44:08 2026

module \/tmp/  ( 
    p23, p11, p21, p1, p5, p4, p31, p22, p18, p16, p13, p8, p9, p27, p10,
    p0, p12, p7, p6, p26, p32, p2, p28, p29, p17, p20, p3, p25, p30, p14,
    p15, p24, p19,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24  );
  input  p23, p11, p21, p1, p5, p4, p31, p22, p18, p16, p13, p8, p9, p27,
    p10, p0, p12, p7, p6, p26, p32, p2, p28, p29, p17, p20, p3, p25, p30,
    p14, p15, p24, p19;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24;
  wire new_n59_, new_n60_, new_n61_, new_n62_, new_n63_, new_n64_, new_n65_,
    new_n66_, new_n67_, new_n68_, new_n69_, new_n70_, new_n71_, new_n72_,
    new_n73_, new_n74_, new_n75_, new_n76_, new_n77_, new_n78_, new_n79_,
    new_n80_, new_n81_, new_n82_, new_n83_, new_n84_, new_n85_, new_n86_,
    new_n87_, new_n88_, new_n89_, new_n90_, new_n91_, new_n92_, new_n93_,
    new_n94_, new_n95_, new_n96_, new_n97_, new_n98_, new_n99_, new_n100_,
    new_n101_, new_n102_, new_n103_, new_n104_, new_n105_, new_n106_,
    new_n107_, new_n108_, new_n109_, new_n110_, new_n111_, new_n112_,
    new_n113_, new_n114_, new_n115_, new_n116_, new_n117_, new_n118_,
    new_n119_, new_n120_, new_n121_, new_n122_, new_n123_, new_n124_,
    new_n125_, new_n126_, new_n127_, new_n128_, new_n129_, new_n130_,
    new_n131_, new_n132_, new_n133_, new_n134_, new_n135_, new_n136_,
    new_n137_, new_n138_, new_n139_, new_n140_, new_n141_, new_n142_,
    new_n143_, new_n144_, new_n145_, new_n146_, new_n147_, new_n148_,
    new_n149_, new_n150_, new_n151_, new_n152_, new_n153_, new_n154_,
    new_n155_, new_n156_, new_n157_, new_n158_, new_n159_, new_n160_,
    new_n161_, new_n162_, new_n163_, new_n164_, new_n165_, new_n166_,
    new_n167_, new_n168_, new_n169_, new_n170_, new_n171_, new_n172_,
    new_n173_, new_n174_, new_n175_, new_n176_, new_n177_, new_n178_,
    new_n179_, new_n180_, new_n181_, new_n182_, new_n183_, new_n184_,
    new_n185_, new_n186_, new_n187_, new_n188_, new_n189_, new_n190_,
    new_n191_, new_n192_, new_n193_, new_n194_, new_n195_, new_n196_,
    new_n197_, new_n198_, new_n199_, new_n200_, new_n201_, new_n202_,
    new_n203_, new_n204_, new_n205_, new_n206_, new_n207_, new_n208_,
    new_n209_, new_n210_, new_n211_, new_n212_, new_n213_, new_n214_,
    new_n215_, new_n216_, new_n217_, new_n218_, new_n219_, new_n220_,
    new_n221_, new_n222_, new_n223_, new_n224_, new_n225_, new_n226_,
    new_n227_, new_n228_, new_n229_, new_n230_, new_n231_, new_n232_,
    new_n233_, new_n234_, new_n235_, new_n236_, new_n237_, new_n238_,
    new_n239_, new_n240_, new_n241_, new_n242_, new_n243_, new_n244_,
    new_n245_, new_n246_, new_n247_, new_n248_, new_n249_, new_n250_,
    new_n251_, new_n252_, new_n253_, new_n254_, new_n255_, new_n256_,
    new_n257_, new_n258_, new_n259_, new_n260_, new_n261_, new_n262_,
    new_n263_, new_n264_, new_n265_, new_n266_, new_n267_, new_n268_,
    new_n269_, new_n270_, new_n271_, new_n272_, new_n273_, new_n274_,
    new_n275_, new_n276_, new_n277_, new_n278_, new_n279_, new_n280_,
    new_n281_, new_n282_, new_n283_, new_n284_, new_n285_, new_n286_,
    new_n287_, new_n288_, new_n289_, new_n290_, new_n291_, new_n292_,
    new_n293_, new_n294_, new_n295_, new_n296_, new_n297_, new_n298_,
    new_n299_, new_n300_, new_n302_, new_n303_, new_n304_, new_n305_,
    new_n306_, new_n307_, new_n308_, new_n309_, new_n310_, new_n311_,
    new_n312_, new_n313_, new_n316_, new_n317_, new_n318_, new_n319_,
    new_n320_, new_n321_, new_n322_, new_n323_, new_n324_, new_n325_,
    new_n326_, new_n330_, new_n331_, new_n335_, new_n336_, new_n337_,
    new_n338_, new_n339_, new_n340_, new_n341_, new_n342_, new_n343_,
    new_n344_, new_n345_, new_n346_, new_n347_, new_n348_, new_n350_,
    new_n352_, new_n353_, new_n355_, new_n356_, new_n357_, new_n359_,
    new_n361_, new_n362_, new_n364_, new_n365_, new_n367_, new_n368_,
    new_n369_, new_n370_, new_n371_, new_n372_, new_n373_, new_n374_,
    new_n376_, new_n377_, new_n378_, new_n379_, new_n380_, new_n381_,
    new_n382_, new_n384_, new_n385_, new_n386_, new_n387_, new_n388_,
    new_n389_, new_n390_, new_n392_, new_n393_, new_n395_, new_n396_,
    new_n398_, new_n400_, new_n401_, new_n402_, new_n403_, new_n404_,
    new_n405_, new_n406_, new_n407_, new_n408_, new_n409_, new_n410_,
    new_n411_, new_n413_, new_n414_, new_n415_, new_n416_, new_n417_,
    new_n418_, new_n419_, new_n420_, new_n421_, new_n422_, new_n423_,
    new_n425_;
  INVx1_ASAP7_75t_R   g000(.A(p7), .Y(new_n59_));
  INVx1_ASAP7_75t_R   g001(.A(p25), .Y(new_n60_));
  AOI21x1_ASAP7_75t_R g002(.A1(p19), .A2(new_n59_), .B(new_n60_), .Y(new_n61_));
  OAI21x1_ASAP7_75t_R g003(.A1(new_n59_), .A2(p19), .B(new_n61_), .Y(new_n62_));
  INVx1_ASAP7_75t_R   g004(.A(p19), .Y(new_n63_));
  NOR2x1_ASAP7_75t_R  g005(.A(p7), .B(new_n63_), .Y(new_n64_));
  NOR2x1_ASAP7_75t_R  g006(.A(p19), .B(new_n59_), .Y(new_n65_));
  OAI21x1_ASAP7_75t_R g007(.A1(new_n64_), .A2(new_n65_), .B(new_n60_), .Y(new_n66_));
  NAND2x1_ASAP7_75t_R g008(.A(new_n62_), .B(new_n66_), .Y(new_n67_));
  INVx1_ASAP7_75t_R   g009(.A(p1), .Y(new_n68_));
  NAND2x1_ASAP7_75t_R g010(.A(p28), .B(new_n68_), .Y(new_n69_));
  XOR2x2_ASAP7_75t_R  g011(.A(p22), .B(p14), .Y(new_n70_));
  XNOR2x2_ASAP7_75t_R g012(.A(new_n69_), .B(new_n70_), .Y(new_n71_));
  NOR2x1_ASAP7_75t_R  g013(.A(new_n67_), .B(new_n71_), .Y(new_n72_));
  XOR2x2_ASAP7_75t_R  g014(.A(new_n70_), .B(new_n69_), .Y(new_n73_));
  AND2x2_ASAP7_75t_R  g015(.A(new_n62_), .B(new_n66_), .Y(new_n74_));
  NOR2x1_ASAP7_75t_R  g016(.A(new_n73_), .B(new_n74_), .Y(new_n75_));
  XOR2x2_ASAP7_75t_R  g017(.A(p8), .B(p17), .Y(new_n76_));
  XNOR2x2_ASAP7_75t_R g018(.A(p9), .B(p15), .Y(new_n77_));
  NAND2x1_ASAP7_75t_R g019(.A(new_n76_), .B(new_n77_), .Y(new_n78_));
  XOR2x2_ASAP7_75t_R  g020(.A(p9), .B(p15), .Y(new_n79_));
  XNOR2x2_ASAP7_75t_R g021(.A(p8), .B(p17), .Y(new_n80_));
  NAND2x1_ASAP7_75t_R g022(.A(new_n79_), .B(new_n80_), .Y(new_n81_));
  XNOR2x2_ASAP7_75t_R g023(.A(p10), .B(p24), .Y(new_n82_));
  AOI21x1_ASAP7_75t_R g024(.A1(new_n78_), .A2(new_n81_), .B(new_n82_), .Y(new_n83_));
  AND3x1_ASAP7_75t_R  g025(.A(new_n78_), .B(new_n81_), .C(new_n82_), .Y(new_n84_));
  NOR2x1_ASAP7_75t_R  g026(.A(new_n83_), .B(new_n84_), .Y(new_n85_));
  OAI21x1_ASAP7_75t_R g027(.A1(new_n72_), .A2(new_n75_), .B(new_n85_), .Y(new_n86_));
  NAND3x1_ASAP7_75t_R g028(.A(new_n78_), .B(new_n81_), .C(new_n82_), .Y(new_n87_));
  AO21x1_ASAP7_75t_R  g029(.A1(new_n78_), .A2(new_n81_), .B(new_n82_), .Y(new_n88_));
  NAND2x1_ASAP7_75t_R g030(.A(new_n87_), .B(new_n88_), .Y(new_n89_));
  NAND2x1_ASAP7_75t_R g031(.A(new_n73_), .B(new_n74_), .Y(new_n90_));
  NAND2x1_ASAP7_75t_R g032(.A(new_n67_), .B(new_n71_), .Y(new_n91_));
  NAND3x1_ASAP7_75t_R g033(.A(new_n89_), .B(new_n90_), .C(new_n91_), .Y(new_n92_));
  NOR2x1_ASAP7_75t_R  g034(.A(p2), .B(p29), .Y(new_n93_));
  INVx1_ASAP7_75t_R   g035(.A(new_n93_), .Y(new_n94_));
  AO21x1_ASAP7_75t_R  g036(.A1(new_n86_), .A2(new_n92_), .B(new_n94_), .Y(new_n95_));
  OAI21x1_ASAP7_75t_R g037(.A1(new_n72_), .A2(new_n75_), .B(new_n89_), .Y(new_n96_));
  NAND3x1_ASAP7_75t_R g038(.A(new_n85_), .B(new_n90_), .C(new_n91_), .Y(new_n97_));
  INVx1_ASAP7_75t_R   g039(.A(p29), .Y(new_n98_));
  AO21x1_ASAP7_75t_R  g040(.A1(new_n96_), .A2(new_n97_), .B(new_n98_), .Y(new_n99_));
  AND2x2_ASAP7_75t_R  g041(.A(p2), .B(p29), .Y(new_n100_));
  INVx1_ASAP7_75t_R   g042(.A(new_n100_), .Y(new_n101_));
  NAND3x1_ASAP7_75t_R g043(.A(new_n95_), .B(new_n99_), .C(new_n101_), .Y(new_n102_));
  INVx1_ASAP7_75t_R   g044(.A(p32), .Y(new_n103_));
  INVx1_ASAP7_75t_R   g045(.A(p2), .Y(new_n104_));
  INVx1_ASAP7_75t_R   g046(.A(p23), .Y(new_n105_));
  AO21x1_ASAP7_75t_R  g047(.A1(new_n103_), .A2(new_n104_), .B(new_n105_), .Y(new_n106_));
  INVx1_ASAP7_75t_R   g048(.A(new_n106_), .Y(new_n107_));
  INVx1_ASAP7_75t_R   g049(.A(p6), .Y(new_n108_));
  NAND2x1_ASAP7_75t_R g050(.A(p21), .B(new_n108_), .Y(new_n109_));
  INVx1_ASAP7_75t_R   g051(.A(p21), .Y(new_n110_));
  NAND2x1_ASAP7_75t_R g052(.A(p6), .B(new_n110_), .Y(new_n111_));
  AND3x1_ASAP7_75t_R  g053(.A(new_n109_), .B(new_n111_), .C(p18), .Y(new_n112_));
  NOR2x1_ASAP7_75t_R  g054(.A(p6), .B(new_n110_), .Y(new_n113_));
  NOR2x1_ASAP7_75t_R  g055(.A(p21), .B(new_n108_), .Y(new_n114_));
  INVx1_ASAP7_75t_R   g056(.A(p18), .Y(new_n115_));
  OA21x2_ASAP7_75t_R  g057(.A1(new_n113_), .A2(new_n114_), .B(new_n115_), .Y(new_n116_));
  NOR2x1_ASAP7_75t_R  g058(.A(p1), .B(p0), .Y(new_n117_));
  AOI21x1_ASAP7_75t_R g059(.A1(p26), .A2(new_n117_), .B(new_n60_), .Y(new_n118_));
  AND3x1_ASAP7_75t_R  g060(.A(new_n117_), .B(p26), .C(new_n60_), .Y(new_n119_));
  NOR2x1_ASAP7_75t_R  g061(.A(new_n118_), .B(new_n119_), .Y(new_n120_));
  OAI21x1_ASAP7_75t_R g062(.A1(new_n112_), .A2(new_n116_), .B(new_n120_), .Y(new_n121_));
  AOI21x1_ASAP7_75t_R g063(.A1(p26), .A2(new_n117_), .B(p25), .Y(new_n122_));
  AND3x1_ASAP7_75t_R  g064(.A(new_n117_), .B(p26), .C(p25), .Y(new_n123_));
  NOR2x1_ASAP7_75t_R  g065(.A(new_n122_), .B(new_n123_), .Y(new_n124_));
  OR3x1_ASAP7_75t_R   g066(.A(new_n113_), .B(new_n114_), .C(new_n115_), .Y(new_n125_));
  AO21x1_ASAP7_75t_R  g067(.A1(new_n109_), .A2(new_n111_), .B(p18), .Y(new_n126_));
  NAND3x1_ASAP7_75t_R g068(.A(new_n124_), .B(new_n125_), .C(new_n126_), .Y(new_n127_));
  NAND2x1_ASAP7_75t_R g069(.A(new_n121_), .B(new_n127_), .Y(new_n128_));
  NAND2x1_ASAP7_75t_R g070(.A(new_n128_), .B(new_n85_), .Y(new_n129_));
  OAI21x1_ASAP7_75t_R g071(.A1(new_n112_), .A2(new_n116_), .B(new_n124_), .Y(new_n130_));
  NAND3x1_ASAP7_75t_R g072(.A(new_n120_), .B(new_n125_), .C(new_n126_), .Y(new_n131_));
  NAND2x1_ASAP7_75t_R g073(.A(new_n130_), .B(new_n131_), .Y(new_n132_));
  NAND2x1_ASAP7_75t_R g074(.A(new_n132_), .B(new_n89_), .Y(new_n133_));
  INVx1_ASAP7_75t_R   g075(.A(p27), .Y(new_n134_));
  NOR2x1_ASAP7_75t_R  g076(.A(p2), .B(new_n134_), .Y(new_n135_));
  INVx1_ASAP7_75t_R   g077(.A(new_n135_), .Y(new_n136_));
  AOI21x1_ASAP7_75t_R g078(.A1(new_n129_), .A2(new_n133_), .B(new_n136_), .Y(new_n137_));
  NAND3x1_ASAP7_75t_R g079(.A(new_n85_), .B(new_n128_), .C(new_n104_), .Y(new_n138_));
  NAND3x1_ASAP7_75t_R g080(.A(new_n89_), .B(new_n132_), .C(new_n104_), .Y(new_n139_));
  AND3x1_ASAP7_75t_R  g081(.A(new_n138_), .B(new_n139_), .C(new_n134_), .Y(new_n140_));
  OAI21x1_ASAP7_75t_R g082(.A1(p13), .A2(p14), .B(p15), .Y(new_n141_));
  AO21x1_ASAP7_75t_R  g083(.A1(p13), .A2(p14), .B(new_n141_), .Y(new_n142_));
  NOR2x1_ASAP7_75t_R  g084(.A(p13), .B(p14), .Y(new_n143_));
  AND2x2_ASAP7_75t_R  g085(.A(p13), .B(p14), .Y(new_n144_));
  INVx1_ASAP7_75t_R   g086(.A(p15), .Y(new_n145_));
  OAI21x1_ASAP7_75t_R g087(.A1(new_n143_), .A2(new_n144_), .B(new_n145_), .Y(new_n146_));
  XNOR2x2_ASAP7_75t_R g088(.A(p21), .B(p9), .Y(new_n147_));
  NAND3x1_ASAP7_75t_R g089(.A(new_n142_), .B(new_n146_), .C(new_n147_), .Y(new_n148_));
  AO21x1_ASAP7_75t_R  g090(.A1(new_n146_), .A2(new_n142_), .B(new_n147_), .Y(new_n149_));
  XOR2x2_ASAP7_75t_R  g091(.A(p22), .B(p24), .Y(new_n150_));
  NOR2x1_ASAP7_75t_R  g092(.A(p1), .B(p32), .Y(new_n151_));
  NAND2x1_ASAP7_75t_R g093(.A(p23), .B(new_n151_), .Y(new_n152_));
  XOR2x2_ASAP7_75t_R  g094(.A(new_n150_), .B(new_n152_), .Y(new_n153_));
  AOI21x1_ASAP7_75t_R g095(.A1(new_n148_), .A2(new_n149_), .B(new_n153_), .Y(new_n154_));
  NOR3x1_ASAP7_75t_R  g096(.A(new_n105_), .B(p1), .C(p32), .Y(new_n155_));
  XOR2x2_ASAP7_75t_R  g097(.A(new_n150_), .B(new_n155_), .Y(new_n156_));
  AND3x1_ASAP7_75t_R  g098(.A(new_n142_), .B(new_n146_), .C(new_n147_), .Y(new_n157_));
  AOI21x1_ASAP7_75t_R g099(.A1(new_n146_), .A2(new_n142_), .B(new_n147_), .Y(new_n158_));
  NOR3x1_ASAP7_75t_R  g100(.A(new_n156_), .B(new_n157_), .C(new_n158_), .Y(new_n159_));
  INVx1_ASAP7_75t_R   g101(.A(p11), .Y(new_n160_));
  AO21x1_ASAP7_75t_R  g102(.A1(new_n103_), .A2(new_n104_), .B(new_n160_), .Y(new_n161_));
  AND2x2_ASAP7_75t_R  g103(.A(new_n104_), .B(new_n161_), .Y(new_n162_));
  OA21x2_ASAP7_75t_R  g104(.A1(new_n154_), .A2(new_n159_), .B(new_n162_), .Y(new_n163_));
  OAI21x1_ASAP7_75t_R g105(.A1(new_n158_), .A2(new_n157_), .B(new_n156_), .Y(new_n164_));
  NAND3x1_ASAP7_75t_R g106(.A(new_n153_), .B(new_n149_), .C(new_n148_), .Y(new_n165_));
  NAND2x1_ASAP7_75t_R g107(.A(new_n164_), .B(new_n165_), .Y(new_n166_));
  AOI21x1_ASAP7_75t_R g108(.A1(new_n104_), .A2(new_n166_), .B(new_n161_), .Y(new_n167_));
  NOR2x1_ASAP7_75t_R  g109(.A(new_n163_), .B(new_n167_), .Y(new_n168_));
  OAI21x1_ASAP7_75t_R g110(.A1(new_n137_), .A2(new_n140_), .B(new_n168_), .Y(new_n169_));
  AO21x1_ASAP7_75t_R  g111(.A1(new_n102_), .A2(new_n107_), .B(new_n169_), .Y(new_n170_));
  NAND2x1_ASAP7_75t_R g112(.A(p16), .B(new_n117_), .Y(new_n171_));
  AOI21x1_ASAP7_75t_R g113(.A1(new_n146_), .A2(new_n142_), .B(new_n171_), .Y(new_n172_));
  OA21x2_ASAP7_75t_R  g114(.A1(new_n143_), .A2(new_n144_), .B(new_n145_), .Y(new_n173_));
  OAI21x1_ASAP7_75t_R g115(.A1(new_n144_), .A2(new_n141_), .B(new_n171_), .Y(new_n174_));
  XOR2x2_ASAP7_75t_R  g116(.A(p5), .B(p18), .Y(new_n175_));
  AOI21x1_ASAP7_75t_R g117(.A1(p5), .A2(p18), .B(p19), .Y(new_n176_));
  OAI21x1_ASAP7_75t_R g118(.A1(p5), .A2(p18), .B(new_n176_), .Y(new_n177_));
  OAI21x1_ASAP7_75t_R g119(.A1(new_n63_), .A2(new_n175_), .B(new_n177_), .Y(new_n178_));
  OAI21x1_ASAP7_75t_R g120(.A1(new_n173_), .A2(new_n174_), .B(new_n178_), .Y(new_n179_));
  OAI21x1_ASAP7_75t_R g121(.A1(new_n172_), .A2(new_n179_), .B(new_n80_), .Y(new_n180_));
  AND3x1_ASAP7_75t_R  g122(.A(new_n142_), .B(new_n146_), .C(new_n171_), .Y(new_n181_));
  INVx1_ASAP7_75t_R   g123(.A(new_n178_), .Y(new_n182_));
  OA21x2_ASAP7_75t_R  g124(.A1(new_n172_), .A2(new_n181_), .B(new_n182_), .Y(new_n183_));
  NOR2x1_ASAP7_75t_R  g125(.A(p2), .B(p20), .Y(new_n184_));
  OAI21x1_ASAP7_75t_R g126(.A1(new_n180_), .A2(new_n183_), .B(new_n184_), .Y(new_n185_));
  OAI21x1_ASAP7_75t_R g127(.A1(new_n172_), .A2(new_n181_), .B(new_n182_), .Y(new_n186_));
  OR3x1_ASAP7_75t_R   g128(.A(new_n182_), .B(new_n181_), .C(new_n172_), .Y(new_n187_));
  AOI21x1_ASAP7_75t_R g129(.A1(new_n186_), .A2(new_n187_), .B(new_n80_), .Y(new_n188_));
  INVx1_ASAP7_75t_R   g130(.A(p4), .Y(new_n189_));
  NAND2x1_ASAP7_75t_R g131(.A(new_n68_), .B(new_n189_), .Y(new_n190_));
  AO21x1_ASAP7_75t_R  g132(.A1(p0), .A2(new_n103_), .B(new_n190_), .Y(new_n191_));
  AND2x2_ASAP7_75t_R  g133(.A(p0), .B(new_n103_), .Y(new_n192_));
  NOR2x1_ASAP7_75t_R  g134(.A(p1), .B(p3), .Y(new_n193_));
  INVx1_ASAP7_75t_R   g135(.A(new_n193_), .Y(new_n194_));
  OR3x1_ASAP7_75t_R   g136(.A(new_n192_), .B(p2), .C(new_n194_), .Y(new_n195_));
  AND2x2_ASAP7_75t_R  g137(.A(new_n191_), .B(new_n195_), .Y(new_n196_));
  INVx1_ASAP7_75t_R   g138(.A(new_n196_), .Y(new_n197_));
  OA21x2_ASAP7_75t_R  g139(.A1(new_n185_), .A2(new_n188_), .B(new_n197_), .Y(new_n198_));
  XOR2x2_ASAP7_75t_R  g140(.A(p5), .B(p10), .Y(new_n199_));
  XOR2x2_ASAP7_75t_R  g141(.A(p7), .B(p6), .Y(new_n200_));
  NOR2x1_ASAP7_75t_R  g142(.A(new_n199_), .B(new_n200_), .Y(new_n201_));
  XNOR2x2_ASAP7_75t_R g143(.A(p5), .B(p10), .Y(new_n202_));
  XNOR2x2_ASAP7_75t_R g144(.A(p7), .B(p6), .Y(new_n203_));
  NOR2x1_ASAP7_75t_R  g145(.A(new_n202_), .B(new_n203_), .Y(new_n204_));
  NAND2x1_ASAP7_75t_R g146(.A(p11), .B(new_n151_), .Y(new_n205_));
  OAI21x1_ASAP7_75t_R g147(.A1(new_n201_), .A2(new_n204_), .B(new_n205_), .Y(new_n206_));
  NOR2x1_ASAP7_75t_R  g148(.A(new_n200_), .B(new_n202_), .Y(new_n207_));
  NOR2x1_ASAP7_75t_R  g149(.A(new_n199_), .B(new_n203_), .Y(new_n208_));
  NOR3x1_ASAP7_75t_R  g150(.A(new_n160_), .B(p1), .C(p32), .Y(new_n209_));
  OAI21x1_ASAP7_75t_R g151(.A1(new_n207_), .A2(new_n208_), .B(new_n209_), .Y(new_n210_));
  NOR2x1_ASAP7_75t_R  g152(.A(p8), .B(p9), .Y(new_n211_));
  AND2x2_ASAP7_75t_R  g153(.A(p8), .B(p9), .Y(new_n212_));
  NOR2x1_ASAP7_75t_R  g154(.A(new_n211_), .B(new_n212_), .Y(new_n213_));
  AND3x1_ASAP7_75t_R  g155(.A(new_n206_), .B(new_n210_), .C(new_n213_), .Y(new_n214_));
  AOI21x1_ASAP7_75t_R g156(.A1(new_n210_), .A2(new_n206_), .B(new_n213_), .Y(new_n215_));
  INVx1_ASAP7_75t_R   g157(.A(p12), .Y(new_n216_));
  NAND2x1_ASAP7_75t_R g158(.A(new_n216_), .B(new_n104_), .Y(new_n217_));
  NOR3x1_ASAP7_75t_R  g159(.A(new_n214_), .B(new_n215_), .C(new_n217_), .Y(new_n218_));
  OAI21x1_ASAP7_75t_R g160(.A1(new_n211_), .A2(new_n212_), .B(new_n209_), .Y(new_n219_));
  INVx1_ASAP7_75t_R   g161(.A(p8), .Y(new_n220_));
  NOR2x1_ASAP7_75t_R  g162(.A(p9), .B(new_n220_), .Y(new_n221_));
  INVx1_ASAP7_75t_R   g163(.A(p9), .Y(new_n222_));
  NOR2x1_ASAP7_75t_R  g164(.A(p8), .B(new_n222_), .Y(new_n223_));
  OAI21x1_ASAP7_75t_R g165(.A1(new_n221_), .A2(new_n223_), .B(new_n205_), .Y(new_n224_));
  NAND2x1_ASAP7_75t_R g166(.A(new_n219_), .B(new_n224_), .Y(new_n225_));
  OAI21x1_ASAP7_75t_R g167(.A1(new_n204_), .A2(new_n201_), .B(new_n225_), .Y(new_n226_));
  OAI21x1_ASAP7_75t_R g168(.A1(new_n221_), .A2(new_n223_), .B(new_n209_), .Y(new_n227_));
  OAI21x1_ASAP7_75t_R g169(.A1(new_n211_), .A2(new_n212_), .B(new_n205_), .Y(new_n228_));
  NAND2x1_ASAP7_75t_R g170(.A(new_n227_), .B(new_n228_), .Y(new_n229_));
  OAI21x1_ASAP7_75t_R g171(.A1(new_n207_), .A2(new_n208_), .B(new_n229_), .Y(new_n230_));
  AOI21x1_ASAP7_75t_R g172(.A1(new_n226_), .A2(new_n230_), .B(p2), .Y(new_n231_));
  NOR2x1_ASAP7_75t_R  g173(.A(new_n216_), .B(new_n231_), .Y(new_n232_));
  NOR2x1_ASAP7_75t_R  g174(.A(new_n218_), .B(new_n232_), .Y(new_n233_));
  OAI21x1_ASAP7_75t_R g175(.A1(new_n180_), .A2(new_n183_), .B(new_n104_), .Y(new_n234_));
  OAI21x1_ASAP7_75t_R g176(.A1(new_n234_), .A2(new_n188_), .B(p20), .Y(new_n235_));
  NAND3x1_ASAP7_75t_R g177(.A(new_n198_), .B(new_n233_), .C(new_n235_), .Y(new_n236_));
  OA21x2_ASAP7_75t_R  g178(.A1(p0), .A2(p2), .B(p16), .Y(new_n237_));
  XOR2x2_ASAP7_75t_R  g179(.A(p5), .B(p22), .Y(new_n238_));
  AND3x1_ASAP7_75t_R  g180(.A(new_n66_), .B(new_n62_), .C(new_n238_), .Y(new_n239_));
  NAND2x1_ASAP7_75t_R g181(.A(new_n126_), .B(new_n125_), .Y(new_n240_));
  AOI21x1_ASAP7_75t_R g182(.A1(new_n62_), .A2(new_n66_), .B(new_n238_), .Y(new_n241_));
  NOR3x1_ASAP7_75t_R  g183(.A(new_n239_), .B(new_n240_), .C(new_n241_), .Y(new_n242_));
  NAND3x1_ASAP7_75t_R g184(.A(new_n66_), .B(new_n62_), .C(new_n238_), .Y(new_n243_));
  AO21x1_ASAP7_75t_R  g185(.A1(new_n62_), .A2(new_n66_), .B(new_n238_), .Y(new_n244_));
  NAND2x1_ASAP7_75t_R g186(.A(new_n109_), .B(new_n111_), .Y(new_n245_));
  AOI21x1_ASAP7_75t_R g187(.A1(new_n115_), .A2(new_n245_), .B(new_n112_), .Y(new_n246_));
  AOI21x1_ASAP7_75t_R g188(.A1(new_n243_), .A2(new_n244_), .B(new_n246_), .Y(new_n247_));
  NAND2x1_ASAP7_75t_R g189(.A(p8), .B(new_n145_), .Y(new_n248_));
  NAND2x1_ASAP7_75t_R g190(.A(p15), .B(new_n220_), .Y(new_n249_));
  AOI21x1_ASAP7_75t_R g191(.A1(new_n248_), .A2(new_n249_), .B(p9), .Y(new_n250_));
  AND3x1_ASAP7_75t_R  g192(.A(new_n248_), .B(new_n249_), .C(p9), .Y(new_n251_));
  INVx1_ASAP7_75t_R   g193(.A(p13), .Y(new_n252_));
  AO21x1_ASAP7_75t_R  g194(.A1(p30), .A2(new_n68_), .B(new_n252_), .Y(new_n253_));
  INVx1_ASAP7_75t_R   g195(.A(p30), .Y(new_n254_));
  OR3x1_ASAP7_75t_R   g196(.A(new_n254_), .B(p1), .C(p13), .Y(new_n255_));
  NAND2x1_ASAP7_75t_R g197(.A(new_n253_), .B(new_n255_), .Y(new_n256_));
  OAI21x1_ASAP7_75t_R g198(.A1(new_n250_), .A2(new_n251_), .B(new_n256_), .Y(new_n257_));
  AO21x1_ASAP7_75t_R  g199(.A1(p30), .A2(new_n68_), .B(p13), .Y(new_n258_));
  OR3x1_ASAP7_75t_R   g200(.A(new_n252_), .B(new_n254_), .C(p1), .Y(new_n259_));
  NAND2x1_ASAP7_75t_R g201(.A(new_n258_), .B(new_n259_), .Y(new_n260_));
  AO21x1_ASAP7_75t_R  g202(.A1(new_n248_), .A2(new_n249_), .B(p9), .Y(new_n261_));
  NAND3x1_ASAP7_75t_R g203(.A(new_n248_), .B(new_n249_), .C(p9), .Y(new_n262_));
  NAND3x1_ASAP7_75t_R g204(.A(new_n260_), .B(new_n261_), .C(new_n262_), .Y(new_n263_));
  NAND2x1_ASAP7_75t_R g205(.A(new_n257_), .B(new_n263_), .Y(new_n264_));
  NOR3x1_ASAP7_75t_R  g206(.A(new_n242_), .B(new_n247_), .C(new_n264_), .Y(new_n265_));
  AND2x2_ASAP7_75t_R  g207(.A(p26), .B(p2), .Y(new_n266_));
  AO21x1_ASAP7_75t_R  g208(.A1(p0), .A2(p26), .B(new_n266_), .Y(new_n267_));
  INVx1_ASAP7_75t_R   g209(.A(new_n267_), .Y(new_n268_));
  NAND3x1_ASAP7_75t_R g210(.A(new_n244_), .B(new_n246_), .C(new_n243_), .Y(new_n269_));
  OAI21x1_ASAP7_75t_R g211(.A1(new_n241_), .A2(new_n239_), .B(new_n240_), .Y(new_n270_));
  NAND2x1_ASAP7_75t_R g212(.A(new_n262_), .B(new_n256_), .Y(new_n271_));
  OAI21x1_ASAP7_75t_R g213(.A1(new_n250_), .A2(new_n251_), .B(new_n260_), .Y(new_n272_));
  OAI21x1_ASAP7_75t_R g214(.A1(new_n250_), .A2(new_n271_), .B(new_n272_), .Y(new_n273_));
  AOI21x1_ASAP7_75t_R g215(.A1(new_n269_), .A2(new_n270_), .B(new_n273_), .Y(new_n274_));
  NOR3x1_ASAP7_75t_R  g216(.A(new_n265_), .B(new_n268_), .C(new_n274_), .Y(new_n275_));
  NAND3x1_ASAP7_75t_R g217(.A(new_n270_), .B(new_n269_), .C(new_n273_), .Y(new_n276_));
  OAI21x1_ASAP7_75t_R g218(.A1(new_n247_), .A2(new_n242_), .B(new_n264_), .Y(new_n277_));
  NOR2x1_ASAP7_75t_R  g219(.A(p2), .B(new_n267_), .Y(new_n278_));
  INVx1_ASAP7_75t_R   g220(.A(new_n278_), .Y(new_n279_));
  AOI21x1_ASAP7_75t_R g221(.A1(new_n276_), .A2(new_n277_), .B(new_n279_), .Y(new_n280_));
  NOR3x1_ASAP7_75t_R  g222(.A(new_n275_), .B(new_n280_), .C(new_n266_), .Y(new_n281_));
  NAND2x1_ASAP7_75t_R g223(.A(new_n237_), .B(new_n281_), .Y(new_n282_));
  OR3x1_ASAP7_75t_R   g224(.A(new_n170_), .B(new_n236_), .C(new_n282_), .Y(new_n283_));
  XOR2x2_ASAP7_75t_R  g225(.A(new_n231_), .B(p12), .Y(new_n284_));
  NOR2x1_ASAP7_75t_R  g226(.A(new_n141_), .B(new_n144_), .Y(new_n285_));
  OA21x2_ASAP7_75t_R  g227(.A1(new_n173_), .A2(new_n285_), .B(new_n178_), .Y(new_n286_));
  NOR3x1_ASAP7_75t_R  g228(.A(new_n178_), .B(new_n285_), .C(new_n173_), .Y(new_n287_));
  XOR2x2_ASAP7_75t_R  g229(.A(new_n80_), .B(new_n171_), .Y(new_n288_));
  NOR3x1_ASAP7_75t_R  g230(.A(new_n286_), .B(new_n287_), .C(new_n288_), .Y(new_n289_));
  OAI21x1_ASAP7_75t_R g231(.A1(new_n173_), .A2(new_n285_), .B(new_n178_), .Y(new_n290_));
  OR3x1_ASAP7_75t_R   g232(.A(new_n178_), .B(new_n285_), .C(new_n173_), .Y(new_n291_));
  XOR2x2_ASAP7_75t_R  g233(.A(new_n76_), .B(new_n171_), .Y(new_n292_));
  AOI21x1_ASAP7_75t_R g234(.A1(new_n290_), .A2(new_n291_), .B(new_n292_), .Y(new_n293_));
  NOR2x1_ASAP7_75t_R  g235(.A(new_n289_), .B(new_n293_), .Y(new_n294_));
  INVx1_ASAP7_75t_R   g236(.A(p20), .Y(new_n295_));
  AOI21x1_ASAP7_75t_R g237(.A1(new_n104_), .A2(new_n294_), .B(new_n295_), .Y(new_n296_));
  NOR2x1_ASAP7_75t_R  g238(.A(new_n185_), .B(new_n188_), .Y(new_n297_));
  OR3x1_ASAP7_75t_R   g239(.A(new_n284_), .B(new_n296_), .C(new_n297_), .Y(new_n298_));
  OR3x1_ASAP7_75t_R   g240(.A(new_n298_), .B(p14), .C(new_n196_), .Y(new_n299_));
  NOR3x1_ASAP7_75t_R  g241(.A(new_n299_), .B(new_n170_), .C(new_n282_), .Y(new_n300_));
  AOI21x1_ASAP7_75t_R g242(.A1(p14), .A2(new_n283_), .B(new_n300_), .Y(o0));
  OAI21x1_ASAP7_75t_R g243(.A1(new_n274_), .A2(new_n265_), .B(new_n278_), .Y(new_n302_));
  NAND3x1_ASAP7_75t_R g244(.A(new_n277_), .B(new_n276_), .C(new_n267_), .Y(new_n303_));
  INVx1_ASAP7_75t_R   g245(.A(new_n266_), .Y(new_n304_));
  NAND3x1_ASAP7_75t_R g246(.A(new_n302_), .B(new_n303_), .C(new_n304_), .Y(new_n305_));
  AOI21x1_ASAP7_75t_R g247(.A1(new_n237_), .A2(new_n305_), .B(new_n169_), .Y(new_n306_));
  OR3x1_ASAP7_75t_R   g248(.A(p1), .B(p31), .C(p2), .Y(new_n307_));
  AO21x1_ASAP7_75t_R  g249(.A1(new_n307_), .A2(new_n190_), .B(new_n192_), .Y(new_n308_));
  NOR3x1_ASAP7_75t_R  g250(.A(new_n232_), .B(new_n218_), .C(new_n308_), .Y(new_n309_));
  NAND2x1_ASAP7_75t_R g251(.A(new_n184_), .B(new_n294_), .Y(new_n310_));
  NAND3x1_ASAP7_75t_R g252(.A(new_n309_), .B(new_n235_), .C(new_n310_), .Y(new_n311_));
  AOI21x1_ASAP7_75t_R g253(.A1(new_n102_), .A2(new_n107_), .B(new_n311_), .Y(new_n312_));
  NAND2x1_ASAP7_75t_R g254(.A(new_n306_), .B(new_n312_), .Y(new_n313_));
  XOR2x2_ASAP7_75t_R  g255(.A(new_n313_), .B(p25), .Y(o1));
  XOR2x2_ASAP7_75t_R  g256(.A(new_n313_), .B(p19), .Y(o2));
  INVx1_ASAP7_75t_R   g257(.A(p24), .Y(new_n316_));
  AOI21x1_ASAP7_75t_R g258(.A1(new_n86_), .A2(new_n92_), .B(new_n94_), .Y(new_n317_));
  AOI21x1_ASAP7_75t_R g259(.A1(new_n96_), .A2(new_n97_), .B(new_n98_), .Y(new_n318_));
  NOR3x1_ASAP7_75t_R  g260(.A(new_n317_), .B(new_n318_), .C(new_n100_), .Y(new_n319_));
  OAI21x1_ASAP7_75t_R g261(.A1(new_n185_), .A2(new_n188_), .B(new_n197_), .Y(new_n320_));
  NOR3x1_ASAP7_75t_R  g262(.A(new_n284_), .B(new_n296_), .C(new_n320_), .Y(new_n321_));
  OAI21x1_ASAP7_75t_R g263(.A1(new_n106_), .A2(new_n319_), .B(new_n321_), .Y(new_n322_));
  NOR3x1_ASAP7_75t_R  g264(.A(new_n322_), .B(new_n282_), .C(new_n169_), .Y(new_n323_));
  INVx1_ASAP7_75t_R   g265(.A(new_n237_), .Y(new_n324_));
  OR3x1_ASAP7_75t_R   g266(.A(new_n236_), .B(new_n305_), .C(new_n324_), .Y(new_n325_));
  OA21x2_ASAP7_75t_R  g267(.A1(new_n170_), .A2(new_n325_), .B(p24), .Y(new_n326_));
  AOI21x1_ASAP7_75t_R g268(.A1(new_n316_), .A2(new_n323_), .B(new_n326_), .Y(o3));
  XOR2x2_ASAP7_75t_R  g269(.A(new_n313_), .B(p7), .Y(o4));
  XOR2x2_ASAP7_75t_R  g270(.A(new_n313_), .B(p22), .Y(o5));
  AOI21x1_ASAP7_75t_R g271(.A1(new_n107_), .A2(new_n102_), .B(new_n236_), .Y(new_n330_));
  NAND2x1_ASAP7_75t_R g272(.A(new_n306_), .B(new_n330_), .Y(new_n331_));
  XOR2x2_ASAP7_75t_R  g273(.A(new_n331_), .B(p9), .Y(o6));
  XOR2x2_ASAP7_75t_R  g274(.A(new_n331_), .B(p8), .Y(o7));
  XOR2x2_ASAP7_75t_R  g275(.A(new_n331_), .B(p15), .Y(o8));
  NOR2x1_ASAP7_75t_R  g276(.A(new_n106_), .B(new_n102_), .Y(new_n335_));
  INVx1_ASAP7_75t_R   g277(.A(new_n335_), .Y(new_n336_));
  AO21x1_ASAP7_75t_R  g278(.A1(new_n129_), .A2(new_n133_), .B(new_n136_), .Y(new_n337_));
  NAND3x1_ASAP7_75t_R g279(.A(new_n138_), .B(new_n139_), .C(new_n134_), .Y(new_n338_));
  NAND2x1_ASAP7_75t_R g280(.A(new_n162_), .B(new_n166_), .Y(new_n339_));
  INVx1_ASAP7_75t_R   g281(.A(new_n161_), .Y(new_n340_));
  OAI21x1_ASAP7_75t_R g282(.A1(new_n154_), .A2(new_n159_), .B(new_n104_), .Y(new_n341_));
  NAND2x1_ASAP7_75t_R g283(.A(new_n340_), .B(new_n341_), .Y(new_n342_));
  NAND2x1_ASAP7_75t_R g284(.A(new_n339_), .B(new_n342_), .Y(new_n343_));
  AOI21x1_ASAP7_75t_R g285(.A1(new_n337_), .A2(new_n338_), .B(new_n343_), .Y(new_n344_));
  OAI21x1_ASAP7_75t_R g286(.A1(new_n324_), .A2(new_n281_), .B(new_n344_), .Y(new_n345_));
  OR3x1_ASAP7_75t_R   g287(.A(new_n336_), .B(new_n311_), .C(new_n345_), .Y(new_n346_));
  NAND2x1_ASAP7_75t_R g288(.A(new_n335_), .B(new_n306_), .Y(new_n347_));
  NOR3x1_ASAP7_75t_R  g289(.A(new_n347_), .B(p18), .C(new_n311_), .Y(new_n348_));
  AOI21x1_ASAP7_75t_R g290(.A1(p18), .A2(new_n346_), .B(new_n348_), .Y(o9));
  NOR3x1_ASAP7_75t_R  g291(.A(new_n347_), .B(p6), .C(new_n311_), .Y(new_n350_));
  AOI21x1_ASAP7_75t_R g292(.A1(p6), .A2(new_n346_), .B(new_n350_), .Y(o10));
  OR3x1_ASAP7_75t_R   g293(.A(new_n298_), .B(p21), .C(new_n308_), .Y(new_n352_));
  NOR2x1_ASAP7_75t_R  g294(.A(new_n352_), .B(new_n347_), .Y(new_n353_));
  AOI21x1_ASAP7_75t_R g295(.A1(p21), .A2(new_n346_), .B(new_n353_), .Y(o11));
  INVx1_ASAP7_75t_R   g296(.A(p5), .Y(new_n355_));
  OAI21x1_ASAP7_75t_R g297(.A1(new_n311_), .A2(new_n347_), .B(new_n355_), .Y(new_n356_));
  OR3x1_ASAP7_75t_R   g298(.A(new_n347_), .B(new_n355_), .C(new_n311_), .Y(new_n357_));
  NAND2x1_ASAP7_75t_R g299(.A(new_n356_), .B(new_n357_), .Y(o12));
  AND3x1_ASAP7_75t_R  g300(.A(new_n306_), .B(new_n321_), .C(new_n335_), .Y(new_n359_));
  XOR2x2_ASAP7_75t_R  g301(.A(new_n359_), .B(new_n252_), .Y(o13));
  OR3x1_ASAP7_75t_R   g302(.A(new_n298_), .B(p17), .C(new_n196_), .Y(new_n361_));
  NOR3x1_ASAP7_75t_R  g303(.A(new_n361_), .B(new_n170_), .C(new_n282_), .Y(new_n362_));
  AOI21x1_ASAP7_75t_R g304(.A1(p17), .A2(new_n283_), .B(new_n362_), .Y(o14));
  OR3x1_ASAP7_75t_R   g305(.A(new_n298_), .B(p10), .C(new_n196_), .Y(new_n364_));
  NOR3x1_ASAP7_75t_R  g306(.A(new_n364_), .B(new_n170_), .C(new_n282_), .Y(new_n365_));
  AOI21x1_ASAP7_75t_R g307(.A1(p10), .A2(new_n283_), .B(new_n365_), .Y(o15));
  NOR2x1_ASAP7_75t_R  g308(.A(new_n106_), .B(new_n319_), .Y(new_n367_));
  NAND2x1_ASAP7_75t_R g309(.A(new_n308_), .B(new_n195_), .Y(new_n368_));
  OA21x2_ASAP7_75t_R  g310(.A1(new_n188_), .A2(new_n185_), .B(new_n368_), .Y(new_n369_));
  NAND3x1_ASAP7_75t_R g311(.A(new_n369_), .B(new_n233_), .C(new_n235_), .Y(new_n370_));
  NOR3x1_ASAP7_75t_R  g312(.A(new_n345_), .B(new_n367_), .C(new_n370_), .Y(new_n371_));
  OR3x1_ASAP7_75t_R   g313(.A(new_n102_), .B(new_n107_), .C(new_n237_), .Y(new_n372_));
  OR3x1_ASAP7_75t_R   g314(.A(new_n298_), .B(new_n169_), .C(new_n305_), .Y(new_n373_));
  OAI21x1_ASAP7_75t_R g315(.A1(new_n372_), .A2(new_n373_), .B(new_n68_), .Y(new_n374_));
  AO21x1_ASAP7_75t_R  g316(.A1(p4), .A2(new_n371_), .B(new_n374_), .Y(o16));
  AND3x1_ASAP7_75t_R  g317(.A(new_n104_), .B(p0), .C(p26), .Y(new_n376_));
  NAND2x1_ASAP7_75t_R g318(.A(new_n276_), .B(new_n277_), .Y(new_n377_));
  NAND2x1_ASAP7_75t_R g319(.A(new_n376_), .B(new_n377_), .Y(new_n378_));
  AOI21x1_ASAP7_75t_R g320(.A1(new_n107_), .A2(new_n102_), .B(new_n370_), .Y(new_n379_));
  NAND2x1_ASAP7_75t_R g321(.A(new_n306_), .B(new_n379_), .Y(new_n380_));
  OAI21x1_ASAP7_75t_R g322(.A1(new_n378_), .A2(new_n380_), .B(new_n190_), .Y(new_n381_));
  AOI21x1_ASAP7_75t_R g323(.A1(new_n376_), .A2(new_n371_), .B(new_n377_), .Y(new_n382_));
  NOR2x1_ASAP7_75t_R  g324(.A(new_n381_), .B(new_n382_), .Y(o17));
  NAND2x1_ASAP7_75t_R g325(.A(new_n96_), .B(new_n97_), .Y(new_n384_));
  NOR2x1_ASAP7_75t_R  g326(.A(new_n367_), .B(new_n345_), .Y(new_n385_));
  INVx1_ASAP7_75t_R   g327(.A(new_n370_), .Y(new_n386_));
  NOR2x1_ASAP7_75t_R  g328(.A(p2), .B(new_n98_), .Y(new_n387_));
  NAND3x1_ASAP7_75t_R g329(.A(new_n385_), .B(new_n386_), .C(new_n387_), .Y(new_n388_));
  OR3x1_ASAP7_75t_R   g330(.A(new_n384_), .B(p2), .C(new_n98_), .Y(new_n389_));
  OAI21x1_ASAP7_75t_R g331(.A1(new_n389_), .A2(new_n380_), .B(new_n190_), .Y(new_n390_));
  AOI21x1_ASAP7_75t_R g332(.A1(new_n384_), .A2(new_n388_), .B(new_n390_), .Y(o18));
  NAND2x1_ASAP7_75t_R g333(.A(p20), .B(new_n371_), .Y(new_n392_));
  INVx1_ASAP7_75t_R   g334(.A(new_n190_), .Y(new_n393_));
  AOI21x1_ASAP7_75t_R g335(.A1(new_n294_), .A2(new_n392_), .B(new_n393_), .Y(o19));
  AND2x2_ASAP7_75t_R  g336(.A(new_n226_), .B(new_n230_), .Y(new_n395_));
  AND3x1_ASAP7_75t_R  g337(.A(new_n379_), .B(new_n306_), .C(p12), .Y(new_n396_));
  OA21x2_ASAP7_75t_R  g338(.A1(new_n395_), .A2(new_n396_), .B(new_n190_), .Y(o20));
  NAND2x1_ASAP7_75t_R g339(.A(new_n340_), .B(new_n371_), .Y(new_n398_));
  AOI21x1_ASAP7_75t_R g340(.A1(new_n166_), .A2(new_n398_), .B(new_n393_), .Y(o21));
  NOR2x1_ASAP7_75t_R  g341(.A(new_n247_), .B(new_n242_), .Y(new_n400_));
  OAI21x1_ASAP7_75t_R g342(.A1(p1), .A2(p31), .B(new_n400_), .Y(new_n401_));
  AOI21x1_ASAP7_75t_R g343(.A1(new_n306_), .A2(new_n312_), .B(new_n401_), .Y(new_n402_));
  AO21x1_ASAP7_75t_R  g344(.A1(p31), .A2(p30), .B(p1), .Y(new_n403_));
  INVx1_ASAP7_75t_R   g345(.A(new_n403_), .Y(new_n404_));
  AND2x2_ASAP7_75t_R  g346(.A(new_n68_), .B(new_n401_), .Y(new_n405_));
  NAND3x1_ASAP7_75t_R g347(.A(new_n312_), .B(new_n306_), .C(new_n405_), .Y(new_n406_));
  NAND2x1_ASAP7_75t_R g348(.A(new_n404_), .B(new_n406_), .Y(new_n407_));
  NOR2x1_ASAP7_75t_R  g349(.A(new_n297_), .B(new_n296_), .Y(new_n408_));
  NAND3x1_ASAP7_75t_R g350(.A(new_n408_), .B(new_n309_), .C(new_n401_), .Y(new_n409_));
  NOR3x1_ASAP7_75t_R  g351(.A(new_n345_), .B(new_n367_), .C(new_n409_), .Y(new_n410_));
  OAI21x1_ASAP7_75t_R g352(.A1(new_n410_), .A2(new_n402_), .B(new_n403_), .Y(new_n411_));
  OAI21x1_ASAP7_75t_R g353(.A1(new_n402_), .A2(new_n407_), .B(new_n411_), .Y(o22));
  OR2x4_ASAP7_75t_R   g354(.A(new_n143_), .B(new_n144_), .Y(new_n413_));
  INVx1_ASAP7_75t_R   g355(.A(new_n413_), .Y(new_n414_));
  AO21x1_ASAP7_75t_R  g356(.A1(new_n413_), .A2(new_n89_), .B(new_n193_), .Y(new_n415_));
  AO21x1_ASAP7_75t_R  g357(.A1(new_n414_), .A2(new_n85_), .B(new_n415_), .Y(new_n416_));
  AOI21x1_ASAP7_75t_R g358(.A1(new_n306_), .A2(new_n330_), .B(new_n416_), .Y(new_n417_));
  NAND2x1_ASAP7_75t_R g359(.A(new_n68_), .B(new_n416_), .Y(new_n418_));
  AO21x1_ASAP7_75t_R  g360(.A1(p28), .A2(p3), .B(p1), .Y(new_n419_));
  INVx1_ASAP7_75t_R   g361(.A(new_n419_), .Y(new_n420_));
  OAI21x1_ASAP7_75t_R g362(.A1(new_n418_), .A2(new_n331_), .B(new_n420_), .Y(new_n421_));
  NOR3x1_ASAP7_75t_R  g363(.A(new_n345_), .B(new_n322_), .C(new_n418_), .Y(new_n422_));
  OAI21x1_ASAP7_75t_R g364(.A1(new_n417_), .A2(new_n422_), .B(new_n419_), .Y(new_n423_));
  OAI21x1_ASAP7_75t_R g365(.A1(new_n417_), .A2(new_n421_), .B(new_n423_), .Y(o23));
  AO21x1_ASAP7_75t_R  g366(.A1(new_n129_), .A2(new_n133_), .B(new_n393_), .Y(new_n425_));
  AOI21x1_ASAP7_75t_R g367(.A1(new_n135_), .A2(new_n371_), .B(new_n425_), .Y(o24));
endmodule


