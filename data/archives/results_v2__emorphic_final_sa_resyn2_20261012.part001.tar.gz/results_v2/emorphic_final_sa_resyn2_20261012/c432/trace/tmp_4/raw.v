// Benchmark "/tmp/" written by ABC on Mon Oct 12 14:43:37 2026

module \/tmp/  ( 
    p6, p25, p27, p24, p14, p21, p4, p0, p1, p3, p35, p16, p32, p18, p13,
    p2, p19, p29, p7, p33, p10, p17, p20, p15, p22, p9, p26, p34, p5, p12,
    p30, p8, p23, p28, p31, p11,
    o0, o1, o2, o3, o4, o5, o6  );
  input  p6, p25, p27, p24, p14, p21, p4, p0, p1, p3, p35, p16, p32, p18,
    p13, p2, p19, p29, p7, p33, p10, p17, p20, p15, p22, p9, p26, p34, p5,
    p12, p30, p8, p23, p28, p31, p11;
  output o0, o1, o2, o3, o4, o5, o6;
  wire new_n44_, new_n45_, new_n46_, new_n47_, new_n48_, new_n49_, new_n50_,
    new_n51_, new_n52_, new_n53_, new_n54_, new_n55_, new_n56_, new_n57_,
    new_n58_, new_n59_, new_n60_, new_n61_, new_n62_, new_n63_, new_n64_,
    new_n66_, new_n67_, new_n68_, new_n69_, new_n70_, new_n71_, new_n72_,
    new_n73_, new_n74_, new_n75_, new_n76_, new_n77_, new_n78_, new_n79_,
    new_n80_, new_n81_, new_n82_, new_n83_, new_n84_, new_n85_, new_n86_,
    new_n87_, new_n88_, new_n89_, new_n90_, new_n91_, new_n92_, new_n93_,
    new_n94_, new_n95_, new_n96_, new_n97_, new_n98_, new_n99_, new_n100_,
    new_n101_, new_n102_, new_n103_, new_n104_, new_n105_, new_n106_,
    new_n107_, new_n108_, new_n109_, new_n111_, new_n112_, new_n113_,
    new_n114_, new_n115_, new_n116_, new_n117_, new_n118_, new_n119_,
    new_n120_, new_n121_, new_n122_, new_n123_, new_n124_, new_n125_,
    new_n126_, new_n127_, new_n128_, new_n129_, new_n130_, new_n131_,
    new_n132_, new_n133_, new_n134_, new_n135_, new_n136_, new_n137_,
    new_n138_, new_n139_, new_n140_, new_n141_, new_n142_, new_n143_,
    new_n144_, new_n145_, new_n146_, new_n147_, new_n148_, new_n149_,
    new_n150_, new_n151_, new_n152_, new_n153_, new_n154_, new_n155_,
    new_n156_, new_n157_, new_n158_, new_n159_, new_n160_, new_n161_,
    new_n162_, new_n163_, new_n165_, new_n166_, new_n167_, new_n168_,
    new_n169_, new_n170_, new_n171_, new_n172_, new_n173_, new_n174_,
    new_n175_, new_n176_, new_n177_, new_n178_, new_n179_, new_n180_,
    new_n181_, new_n182_, new_n183_, new_n184_, new_n185_, new_n186_,
    new_n187_, new_n188_, new_n189_, new_n190_, new_n191_, new_n192_,
    new_n193_, new_n194_, new_n195_, new_n196_, new_n197_, new_n198_,
    new_n199_, new_n200_, new_n201_, new_n202_, new_n203_, new_n204_,
    new_n205_, new_n206_, new_n207_, new_n208_, new_n209_, new_n210_,
    new_n211_, new_n212_, new_n213_, new_n214_, new_n215_, new_n216_,
    new_n217_, new_n218_, new_n219_, new_n220_, new_n221_, new_n222_,
    new_n223_, new_n224_, new_n225_, new_n226_, new_n229_, new_n230_,
    new_n231_, new_n232_, new_n233_, new_n234_, new_n235_, new_n236_,
    new_n237_, new_n238_, new_n239_, new_n241_, new_n242_, new_n243_,
    new_n244_, new_n245_, new_n246_, new_n247_;
  INVx1_ASAP7_75t_R   g000(.A(p14), .Y(new_n44_));
  INVx1_ASAP7_75t_R   g001(.A(p15), .Y(new_n45_));
  NAND2x1_ASAP7_75t_R g002(.A(p16), .B(new_n45_), .Y(new_n46_));
  OAI21x1_ASAP7_75t_R g003(.A1(new_n44_), .A2(p13), .B(new_n46_), .Y(new_n47_));
  INVx1_ASAP7_75t_R   g004(.A(p12), .Y(new_n48_));
  INVx1_ASAP7_75t_R   g005(.A(p3), .Y(new_n49_));
  NAND2x1_ASAP7_75t_R g006(.A(p4), .B(new_n49_), .Y(new_n50_));
  OAI21x1_ASAP7_75t_R g007(.A1(new_n48_), .A2(p11), .B(new_n50_), .Y(new_n51_));
  NOR2x1_ASAP7_75t_R  g008(.A(new_n47_), .B(new_n51_), .Y(new_n52_));
  INVx1_ASAP7_75t_R   g009(.A(p0), .Y(new_n53_));
  NOR2x1_ASAP7_75t_R  g010(.A(p35), .B(new_n53_), .Y(new_n54_));
  INVx1_ASAP7_75t_R   g011(.A(p2), .Y(new_n55_));
  NOR2x1_ASAP7_75t_R  g012(.A(p1), .B(new_n55_), .Y(new_n56_));
  NOR2x1_ASAP7_75t_R  g013(.A(new_n54_), .B(new_n56_), .Y(new_n57_));
  INVx1_ASAP7_75t_R   g014(.A(p8), .Y(new_n58_));
  NOR2x1_ASAP7_75t_R  g015(.A(p7), .B(new_n58_), .Y(new_n59_));
  INVx1_ASAP7_75t_R   g016(.A(p6), .Y(new_n60_));
  NOR2x1_ASAP7_75t_R  g017(.A(p5), .B(new_n60_), .Y(new_n61_));
  INVx1_ASAP7_75t_R   g018(.A(p10), .Y(new_n62_));
  NOR2x1_ASAP7_75t_R  g019(.A(p9), .B(new_n62_), .Y(new_n63_));
  NOR3x1_ASAP7_75t_R  g020(.A(new_n59_), .B(new_n61_), .C(new_n63_), .Y(new_n64_));
  NAND3x1_ASAP7_75t_R g021(.A(new_n52_), .B(new_n57_), .C(new_n64_), .Y(o0));
  OA21x2_ASAP7_75t_R  g022(.A1(new_n44_), .A2(p13), .B(new_n46_), .Y(new_n66_));
  INVx1_ASAP7_75t_R   g023(.A(p11), .Y(new_n67_));
  INVx1_ASAP7_75t_R   g024(.A(p4), .Y(new_n68_));
  NOR2x1_ASAP7_75t_R  g025(.A(p3), .B(new_n68_), .Y(new_n69_));
  AOI21x1_ASAP7_75t_R g026(.A1(p12), .A2(new_n67_), .B(new_n69_), .Y(new_n70_));
  AND3x1_ASAP7_75t_R  g027(.A(new_n66_), .B(new_n57_), .C(new_n70_), .Y(new_n71_));
  INVx1_ASAP7_75t_R   g028(.A(p35), .Y(new_n72_));
  AOI21x1_ASAP7_75t_R g029(.A1(new_n64_), .A2(new_n71_), .B(new_n72_), .Y(new_n73_));
  OR2x4_ASAP7_75t_R   g030(.A(p17), .B(new_n53_), .Y(new_n74_));
  NAND2x1_ASAP7_75t_R g031(.A(new_n57_), .B(new_n70_), .Y(new_n75_));
  OAI21x1_ASAP7_75t_R g032(.A1(new_n47_), .A2(new_n75_), .B(p13), .Y(new_n76_));
  INVx1_ASAP7_75t_R   g033(.A(new_n61_), .Y(new_n77_));
  NOR2x1_ASAP7_75t_R  g034(.A(new_n59_), .B(new_n63_), .Y(new_n78_));
  INVx1_ASAP7_75t_R   g035(.A(p13), .Y(new_n79_));
  AO21x1_ASAP7_75t_R  g036(.A1(new_n77_), .A2(new_n78_), .B(new_n79_), .Y(new_n80_));
  NOR2x1_ASAP7_75t_R  g037(.A(p24), .B(new_n44_), .Y(new_n81_));
  NAND3x1_ASAP7_75t_R g038(.A(new_n76_), .B(new_n80_), .C(new_n81_), .Y(new_n82_));
  OAI21x1_ASAP7_75t_R g039(.A1(new_n73_), .A2(new_n74_), .B(new_n82_), .Y(new_n83_));
  AND3x1_ASAP7_75t_R  g040(.A(new_n78_), .B(new_n50_), .C(new_n77_), .Y(new_n84_));
  INVx1_ASAP7_75t_R   g041(.A(p7), .Y(new_n85_));
  AOI21x1_ASAP7_75t_R g042(.A1(new_n84_), .A2(new_n71_), .B(new_n85_), .Y(new_n86_));
  INVx1_ASAP7_75t_R   g043(.A(p21), .Y(new_n87_));
  NAND2x1_ASAP7_75t_R g044(.A(p8), .B(new_n87_), .Y(new_n88_));
  OAI21x1_ASAP7_75t_R g045(.A1(new_n47_), .A2(new_n75_), .B(p15), .Y(new_n89_));
  AO21x1_ASAP7_75t_R  g046(.A1(new_n77_), .A2(new_n78_), .B(new_n45_), .Y(new_n90_));
  INVx1_ASAP7_75t_R   g047(.A(p16), .Y(new_n91_));
  NOR2x1_ASAP7_75t_R  g048(.A(p25), .B(new_n91_), .Y(new_n92_));
  NAND3x1_ASAP7_75t_R g049(.A(new_n89_), .B(new_n90_), .C(new_n92_), .Y(new_n93_));
  OAI21x1_ASAP7_75t_R g050(.A1(new_n86_), .A2(new_n88_), .B(new_n93_), .Y(new_n94_));
  NOR2x1_ASAP7_75t_R  g051(.A(new_n83_), .B(new_n94_), .Y(new_n95_));
  NAND2x1_ASAP7_75t_R g052(.A(p5), .B(o0), .Y(new_n96_));
  NOR2x1_ASAP7_75t_R  g053(.A(p20), .B(new_n60_), .Y(new_n97_));
  OR2x4_ASAP7_75t_R   g054(.A(p22), .B(new_n62_), .Y(new_n98_));
  AOI21x1_ASAP7_75t_R g055(.A1(p9), .A2(o0), .B(new_n98_), .Y(new_n99_));
  AOI21x1_ASAP7_75t_R g056(.A1(new_n96_), .A2(new_n97_), .B(new_n99_), .Y(new_n100_));
  OR2x4_ASAP7_75t_R   g057(.A(p18), .B(new_n55_), .Y(new_n101_));
  AOI21x1_ASAP7_75t_R g058(.A1(p1), .A2(o0), .B(new_n101_), .Y(new_n102_));
  INVx1_ASAP7_75t_R   g059(.A(p23), .Y(new_n103_));
  NAND2x1_ASAP7_75t_R g060(.A(p12), .B(new_n103_), .Y(new_n104_));
  AOI21x1_ASAP7_75t_R g061(.A1(p11), .A2(o0), .B(new_n104_), .Y(new_n105_));
  INVx1_ASAP7_75t_R   g062(.A(p19), .Y(new_n106_));
  NAND2x1_ASAP7_75t_R g063(.A(p4), .B(new_n106_), .Y(new_n107_));
  AOI21x1_ASAP7_75t_R g064(.A1(new_n50_), .A2(o0), .B(new_n107_), .Y(new_n108_));
  NOR3x1_ASAP7_75t_R  g065(.A(new_n102_), .B(new_n105_), .C(new_n108_), .Y(new_n109_));
  NAND3x1_ASAP7_75t_R g066(.A(new_n95_), .B(new_n100_), .C(new_n109_), .Y(o1));
  NAND2x1_ASAP7_75t_R g067(.A(p15), .B(o0), .Y(new_n111_));
  INVx1_ASAP7_75t_R   g068(.A(p34), .Y(new_n112_));
  NAND3x1_ASAP7_75t_R g069(.A(new_n111_), .B(p16), .C(new_n112_), .Y(new_n113_));
  AO21x1_ASAP7_75t_R  g070(.A1(p25), .A2(o1), .B(new_n113_), .Y(new_n114_));
  AOI21x1_ASAP7_75t_R g071(.A1(p7), .A2(o0), .B(new_n88_), .Y(new_n115_));
  AOI21x1_ASAP7_75t_R g072(.A1(new_n111_), .A2(new_n92_), .B(new_n115_), .Y(new_n116_));
  AO21x1_ASAP7_75t_R  g073(.A1(p35), .A2(o0), .B(new_n74_), .Y(new_n117_));
  NAND3x1_ASAP7_75t_R g074(.A(new_n116_), .B(new_n82_), .C(new_n117_), .Y(new_n118_));
  NAND2x1_ASAP7_75t_R g075(.A(new_n100_), .B(new_n109_), .Y(new_n119_));
  NOR2x1_ASAP7_75t_R  g076(.A(new_n118_), .B(new_n119_), .Y(new_n120_));
  AO21x1_ASAP7_75t_R  g077(.A1(p11), .A2(o0), .B(new_n48_), .Y(new_n121_));
  NOR2x1_ASAP7_75t_R  g078(.A(p32), .B(new_n121_), .Y(new_n122_));
  OAI21x1_ASAP7_75t_R g079(.A1(new_n103_), .A2(new_n120_), .B(new_n122_), .Y(new_n123_));
  NAND2x1_ASAP7_75t_R g080(.A(new_n100_), .B(new_n116_), .Y(new_n124_));
  OAI21x1_ASAP7_75t_R g081(.A1(new_n83_), .A2(new_n124_), .B(p18), .Y(new_n125_));
  OR2x4_ASAP7_75t_R   g082(.A(new_n102_), .B(new_n105_), .Y(new_n126_));
  OAI21x1_ASAP7_75t_R g083(.A1(new_n108_), .A2(new_n126_), .B(p18), .Y(new_n127_));
  AO21x1_ASAP7_75t_R  g084(.A1(p1), .A2(o0), .B(new_n55_), .Y(new_n128_));
  NOR2x1_ASAP7_75t_R  g085(.A(p27), .B(new_n128_), .Y(new_n129_));
  NAND3x1_ASAP7_75t_R g086(.A(new_n125_), .B(new_n127_), .C(new_n129_), .Y(new_n130_));
  NAND3x1_ASAP7_75t_R g087(.A(new_n114_), .B(new_n123_), .C(new_n130_), .Y(new_n131_));
  AND3x1_ASAP7_75t_R  g088(.A(new_n52_), .B(new_n57_), .C(new_n64_), .Y(new_n132_));
  AO21x1_ASAP7_75t_R  g089(.A1(p4), .A2(new_n132_), .B(new_n69_), .Y(new_n133_));
  INVx1_ASAP7_75t_R   g090(.A(new_n133_), .Y(new_n134_));
  OR2x4_ASAP7_75t_R   g091(.A(p28), .B(new_n134_), .Y(new_n135_));
  AO21x1_ASAP7_75t_R  g092(.A1(p19), .A2(o1), .B(new_n135_), .Y(new_n136_));
  NAND2x1_ASAP7_75t_R g093(.A(p13), .B(o0), .Y(new_n137_));
  INVx1_ASAP7_75t_R   g094(.A(p33), .Y(new_n138_));
  AND3x1_ASAP7_75t_R  g095(.A(new_n137_), .B(p14), .C(new_n138_), .Y(new_n139_));
  OAI21x1_ASAP7_75t_R g096(.A1(new_n118_), .A2(new_n119_), .B(p24), .Y(new_n140_));
  NAND2x1_ASAP7_75t_R g097(.A(new_n139_), .B(new_n140_), .Y(new_n141_));
  OAI21x1_ASAP7_75t_R g098(.A1(new_n83_), .A2(new_n124_), .B(p17), .Y(new_n142_));
  OAI21x1_ASAP7_75t_R g099(.A1(new_n108_), .A2(new_n126_), .B(p17), .Y(new_n143_));
  INVx1_ASAP7_75t_R   g100(.A(p26), .Y(new_n144_));
  NOR2x1_ASAP7_75t_R  g101(.A(new_n53_), .B(new_n73_), .Y(new_n145_));
  AND2x2_ASAP7_75t_R  g102(.A(new_n144_), .B(new_n145_), .Y(new_n146_));
  NAND3x1_ASAP7_75t_R g103(.A(new_n142_), .B(new_n143_), .C(new_n146_), .Y(new_n147_));
  NAND3x1_ASAP7_75t_R g104(.A(new_n136_), .B(new_n141_), .C(new_n147_), .Y(new_n148_));
  AO21x1_ASAP7_75t_R  g105(.A1(p7), .A2(o0), .B(new_n58_), .Y(new_n149_));
  NOR2x1_ASAP7_75t_R  g106(.A(p30), .B(new_n149_), .Y(new_n150_));
  OAI21x1_ASAP7_75t_R g107(.A1(new_n87_), .A2(new_n120_), .B(new_n150_), .Y(new_n151_));
  OAI21x1_ASAP7_75t_R g108(.A1(new_n83_), .A2(new_n124_), .B(p22), .Y(new_n152_));
  OAI21x1_ASAP7_75t_R g109(.A1(new_n108_), .A2(new_n126_), .B(p22), .Y(new_n153_));
  NAND2x1_ASAP7_75t_R g110(.A(p9), .B(o0), .Y(new_n154_));
  INVx1_ASAP7_75t_R   g111(.A(p31), .Y(new_n155_));
  AND3x1_ASAP7_75t_R  g112(.A(new_n154_), .B(p10), .C(new_n155_), .Y(new_n156_));
  NAND3x1_ASAP7_75t_R g113(.A(new_n152_), .B(new_n153_), .C(new_n156_), .Y(new_n157_));
  OAI21x1_ASAP7_75t_R g114(.A1(new_n83_), .A2(new_n124_), .B(p20), .Y(new_n158_));
  OAI21x1_ASAP7_75t_R g115(.A1(new_n108_), .A2(new_n126_), .B(p20), .Y(new_n159_));
  AO21x1_ASAP7_75t_R  g116(.A1(p5), .A2(o0), .B(new_n60_), .Y(new_n160_));
  NOR2x1_ASAP7_75t_R  g117(.A(p29), .B(new_n160_), .Y(new_n161_));
  NAND3x1_ASAP7_75t_R g118(.A(new_n158_), .B(new_n159_), .C(new_n161_), .Y(new_n162_));
  NAND3x1_ASAP7_75t_R g119(.A(new_n151_), .B(new_n157_), .C(new_n162_), .Y(new_n163_));
  OR3x1_ASAP7_75t_R   g120(.A(new_n131_), .B(new_n148_), .C(new_n163_), .Y(o2));
  OA21x2_ASAP7_75t_R  g121(.A1(new_n131_), .A2(new_n148_), .B(p30), .Y(new_n165_));
  AOI21x1_ASAP7_75t_R g122(.A1(p21), .A2(o1), .B(new_n149_), .Y(new_n166_));
  INVx1_ASAP7_75t_R   g123(.A(new_n156_), .Y(new_n167_));
  AOI21x1_ASAP7_75t_R g124(.A1(p22), .A2(o1), .B(new_n167_), .Y(new_n168_));
  INVx1_ASAP7_75t_R   g125(.A(new_n161_), .Y(new_n169_));
  AOI21x1_ASAP7_75t_R g126(.A1(p20), .A2(o1), .B(new_n169_), .Y(new_n170_));
  OAI21x1_ASAP7_75t_R g127(.A1(new_n168_), .A2(new_n170_), .B(p30), .Y(new_n171_));
  NAND2x1_ASAP7_75t_R g128(.A(new_n166_), .B(new_n171_), .Y(new_n172_));
  NAND2x1_ASAP7_75t_R g129(.A(new_n162_), .B(new_n151_), .Y(new_n173_));
  AO21x1_ASAP7_75t_R  g130(.A1(p9), .A2(o0), .B(new_n62_), .Y(new_n174_));
  AO21x1_ASAP7_75t_R  g131(.A1(p22), .A2(o1), .B(new_n174_), .Y(new_n175_));
  AOI21x1_ASAP7_75t_R g132(.A1(p31), .A2(new_n173_), .B(new_n175_), .Y(new_n176_));
  OAI21x1_ASAP7_75t_R g133(.A1(new_n131_), .A2(new_n148_), .B(p31), .Y(new_n177_));
  NAND2x1_ASAP7_75t_R g134(.A(new_n176_), .B(new_n177_), .Y(new_n178_));
  OAI21x1_ASAP7_75t_R g135(.A1(new_n165_), .A2(new_n172_), .B(new_n178_), .Y(new_n179_));
  OA21x2_ASAP7_75t_R  g136(.A1(new_n131_), .A2(new_n148_), .B(p33), .Y(new_n180_));
  INVx1_ASAP7_75t_R   g137(.A(new_n150_), .Y(new_n181_));
  AOI21x1_ASAP7_75t_R g138(.A1(p21), .A2(o1), .B(new_n181_), .Y(new_n182_));
  NOR3x1_ASAP7_75t_R  g139(.A(new_n168_), .B(new_n170_), .C(new_n182_), .Y(new_n183_));
  AND3x1_ASAP7_75t_R  g140(.A(new_n140_), .B(p14), .C(new_n137_), .Y(new_n184_));
  OAI21x1_ASAP7_75t_R g141(.A1(new_n138_), .A2(new_n183_), .B(new_n184_), .Y(new_n185_));
  AO21x1_ASAP7_75t_R  g142(.A1(p23), .A2(o1), .B(new_n121_), .Y(new_n186_));
  AOI21x1_ASAP7_75t_R g143(.A1(p32), .A2(new_n163_), .B(new_n186_), .Y(new_n187_));
  OAI21x1_ASAP7_75t_R g144(.A1(new_n131_), .A2(new_n148_), .B(p32), .Y(new_n188_));
  NAND2x1_ASAP7_75t_R g145(.A(new_n187_), .B(new_n188_), .Y(new_n189_));
  OAI21x1_ASAP7_75t_R g146(.A1(new_n180_), .A2(new_n185_), .B(new_n189_), .Y(new_n190_));
  NOR2x1_ASAP7_75t_R  g147(.A(new_n179_), .B(new_n190_), .Y(new_n191_));
  OA21x2_ASAP7_75t_R  g148(.A1(new_n131_), .A2(new_n148_), .B(p26), .Y(new_n192_));
  AND3x1_ASAP7_75t_R  g149(.A(new_n142_), .B(new_n143_), .C(new_n145_), .Y(new_n193_));
  OAI21x1_ASAP7_75t_R g150(.A1(new_n144_), .A2(new_n183_), .B(new_n193_), .Y(new_n194_));
  AO21x1_ASAP7_75t_R  g151(.A1(p20), .A2(o1), .B(new_n160_), .Y(new_n195_));
  AOI21x1_ASAP7_75t_R g152(.A1(p29), .A2(new_n163_), .B(new_n195_), .Y(new_n196_));
  OAI21x1_ASAP7_75t_R g153(.A1(new_n131_), .A2(new_n148_), .B(p29), .Y(new_n197_));
  NAND2x1_ASAP7_75t_R g154(.A(new_n196_), .B(new_n197_), .Y(new_n198_));
  OAI21x1_ASAP7_75t_R g155(.A1(new_n192_), .A2(new_n194_), .B(new_n198_), .Y(new_n199_));
  AO21x1_ASAP7_75t_R  g156(.A1(p18), .A2(o1), .B(new_n128_), .Y(new_n200_));
  AOI21x1_ASAP7_75t_R g157(.A1(p27), .A2(new_n163_), .B(new_n200_), .Y(new_n201_));
  OAI21x1_ASAP7_75t_R g158(.A1(new_n131_), .A2(new_n148_), .B(p27), .Y(new_n202_));
  NAND2x1_ASAP7_75t_R g159(.A(new_n201_), .B(new_n202_), .Y(new_n203_));
  AO21x1_ASAP7_75t_R  g160(.A1(p19), .A2(o1), .B(new_n134_), .Y(new_n204_));
  NOR2x1_ASAP7_75t_R  g161(.A(new_n204_), .B(new_n163_), .Y(new_n205_));
  NOR2x1_ASAP7_75t_R  g162(.A(new_n131_), .B(new_n148_), .Y(new_n206_));
  AOI21x1_ASAP7_75t_R g163(.A1(p19), .A2(o1), .B(new_n135_), .Y(new_n207_));
  AOI21x1_ASAP7_75t_R g164(.A1(new_n205_), .A2(new_n206_), .B(new_n207_), .Y(new_n208_));
  NAND2x1_ASAP7_75t_R g165(.A(new_n203_), .B(new_n208_), .Y(new_n209_));
  NOR2x1_ASAP7_75t_R  g166(.A(new_n199_), .B(new_n209_), .Y(new_n210_));
  NAND2x1_ASAP7_75t_R g167(.A(p23), .B(o1), .Y(new_n211_));
  AOI21x1_ASAP7_75t_R g168(.A1(new_n211_), .A2(new_n122_), .B(new_n207_), .Y(new_n212_));
  NAND2x1_ASAP7_75t_R g169(.A(p17), .B(o1), .Y(new_n213_));
  INVx1_ASAP7_75t_R   g170(.A(new_n129_), .Y(new_n214_));
  AOI21x1_ASAP7_75t_R g171(.A1(p18), .A2(o1), .B(new_n214_), .Y(new_n215_));
  AOI21x1_ASAP7_75t_R g172(.A1(new_n213_), .A2(new_n146_), .B(new_n215_), .Y(new_n216_));
  AOI21x1_ASAP7_75t_R g173(.A1(p25), .A2(o1), .B(new_n113_), .Y(new_n217_));
  INVx1_ASAP7_75t_R   g174(.A(new_n139_), .Y(new_n218_));
  AOI21x1_ASAP7_75t_R g175(.A1(p24), .A2(o1), .B(new_n218_), .Y(new_n219_));
  NOR2x1_ASAP7_75t_R  g176(.A(new_n217_), .B(new_n219_), .Y(new_n220_));
  NAND3x1_ASAP7_75t_R g177(.A(new_n212_), .B(new_n216_), .C(new_n220_), .Y(new_n221_));
  NAND2x1_ASAP7_75t_R g178(.A(p25), .B(o1), .Y(new_n222_));
  AND3x1_ASAP7_75t_R  g179(.A(new_n222_), .B(p16), .C(new_n111_), .Y(new_n223_));
  OAI21x1_ASAP7_75t_R g180(.A1(new_n112_), .A2(new_n183_), .B(new_n223_), .Y(new_n224_));
  AO21x1_ASAP7_75t_R  g181(.A1(p34), .A2(new_n221_), .B(new_n224_), .Y(new_n225_));
  INVx1_ASAP7_75t_R   g182(.A(new_n225_), .Y(new_n226_));
  AOI21x1_ASAP7_75t_R g183(.A1(new_n191_), .A2(new_n210_), .B(new_n226_), .Y(o3));
  INVx1_ASAP7_75t_R   g184(.A(new_n191_), .Y(o4));
  INVx1_ASAP7_75t_R   g185(.A(new_n186_), .Y(new_n229_));
  NAND2x1_ASAP7_75t_R g186(.A(new_n229_), .B(new_n183_), .Y(new_n230_));
  OAI21x1_ASAP7_75t_R g187(.A1(new_n230_), .A2(new_n221_), .B(new_n123_), .Y(new_n231_));
  NOR2x1_ASAP7_75t_R  g188(.A(new_n198_), .B(new_n231_), .Y(new_n232_));
  AO21x1_ASAP7_75t_R  g189(.A1(p31), .A2(new_n173_), .B(new_n175_), .Y(new_n233_));
  AOI21x1_ASAP7_75t_R g190(.A1(p31), .A2(new_n221_), .B(new_n233_), .Y(new_n234_));
  AOI21x1_ASAP7_75t_R g191(.A1(p30), .A2(new_n221_), .B(new_n172_), .Y(new_n235_));
  NOR2x1_ASAP7_75t_R  g192(.A(new_n234_), .B(new_n235_), .Y(new_n236_));
  NAND2x1_ASAP7_75t_R g193(.A(new_n232_), .B(new_n236_), .Y(new_n237_));
  INVx1_ASAP7_75t_R   g194(.A(new_n190_), .Y(new_n238_));
  OR3x1_ASAP7_75t_R   g195(.A(new_n208_), .B(new_n234_), .C(new_n235_), .Y(new_n239_));
  NAND3x1_ASAP7_75t_R g196(.A(new_n237_), .B(new_n238_), .C(new_n239_), .Y(o5));
  INVx1_ASAP7_75t_R   g197(.A(new_n204_), .Y(new_n241_));
  NAND2x1_ASAP7_75t_R g198(.A(new_n241_), .B(new_n183_), .Y(new_n242_));
  OAI21x1_ASAP7_75t_R g199(.A1(new_n242_), .A2(new_n221_), .B(new_n136_), .Y(new_n243_));
  OAI21x1_ASAP7_75t_R g200(.A1(new_n203_), .A2(new_n243_), .B(new_n178_), .Y(new_n244_));
  NAND2x1_ASAP7_75t_R g201(.A(new_n189_), .B(new_n244_), .Y(new_n245_));
  NOR2x1_ASAP7_75t_R  g202(.A(new_n185_), .B(new_n180_), .Y(new_n246_));
  AOI21x1_ASAP7_75t_R g203(.A1(new_n232_), .A2(new_n236_), .B(new_n246_), .Y(new_n247_));
  NAND2x1_ASAP7_75t_R g204(.A(new_n245_), .B(new_n247_), .Y(o6));
endmodule


