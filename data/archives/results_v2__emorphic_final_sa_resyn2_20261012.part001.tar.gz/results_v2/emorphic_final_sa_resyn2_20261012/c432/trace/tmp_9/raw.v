// Benchmark "/tmp/" written by ABC on Mon Oct 12 14:43:37 2026

module \/tmp/  ( 
    p32, p2, p3, p4, p29, p12, p27, p19, p1, p21, p26, p13, p14, p28, p17,
    p11, p5, p22, p7, p18, p6, p16, p23, p25, p33, p34, p9, p24, p31, p30,
    p10, p8, p15, p0, p20, p35,
    o0, o1, o2, o3, o4, o5, o6  );
  input  p32, p2, p3, p4, p29, p12, p27, p19, p1, p21, p26, p13, p14,
    p28, p17, p11, p5, p22, p7, p18, p6, p16, p23, p25, p33, p34, p9, p24,
    p31, p30, p10, p8, p15, p0, p20, p35;
  output o0, o1, o2, o3, o4, o5, o6;
  wire new_n44_, new_n45_, new_n46_, new_n47_, new_n48_, new_n49_, new_n50_,
    new_n51_, new_n52_, new_n53_, new_n54_, new_n55_, new_n56_, new_n57_,
    new_n58_, new_n59_, new_n60_, new_n61_, new_n62_, new_n63_, new_n64_,
    new_n66_, new_n67_, new_n68_, new_n69_, new_n70_, new_n71_, new_n72_,
    new_n73_, new_n74_, new_n75_, new_n76_, new_n77_, new_n78_, new_n79_,
    new_n80_, new_n81_, new_n82_, new_n83_, new_n84_, new_n85_, new_n86_,
    new_n87_, new_n88_, new_n89_, new_n90_, new_n91_, new_n92_, new_n93_,
    new_n94_, new_n95_, new_n96_, new_n97_, new_n98_, new_n99_, new_n100_,
    new_n101_, new_n102_, new_n103_, new_n104_, new_n105_, new_n106_,
    new_n107_, new_n109_, new_n110_, new_n111_, new_n112_, new_n113_,
    new_n114_, new_n115_, new_n116_, new_n117_, new_n118_, new_n119_,
    new_n120_, new_n121_, new_n122_, new_n123_, new_n124_, new_n125_,
    new_n126_, new_n127_, new_n128_, new_n129_, new_n130_, new_n131_,
    new_n132_, new_n133_, new_n134_, new_n135_, new_n136_, new_n137_,
    new_n138_, new_n139_, new_n140_, new_n141_, new_n142_, new_n143_,
    new_n144_, new_n145_, new_n146_, new_n147_, new_n148_, new_n149_,
    new_n150_, new_n151_, new_n152_, new_n153_, new_n154_, new_n155_,
    new_n156_, new_n157_, new_n158_, new_n159_, new_n160_, new_n161_,
    new_n162_, new_n163_, new_n164_, new_n165_, new_n166_, new_n167_,
    new_n168_, new_n170_, new_n171_, new_n172_, new_n173_, new_n174_,
    new_n175_, new_n176_, new_n177_, new_n178_, new_n179_, new_n180_,
    new_n181_, new_n182_, new_n183_, new_n184_, new_n185_, new_n186_,
    new_n187_, new_n188_, new_n189_, new_n190_, new_n191_, new_n192_,
    new_n193_, new_n194_, new_n195_, new_n196_, new_n197_, new_n198_,
    new_n199_, new_n200_, new_n201_, new_n202_, new_n203_, new_n204_,
    new_n205_, new_n206_, new_n207_, new_n208_, new_n209_, new_n210_,
    new_n211_, new_n212_, new_n213_, new_n214_, new_n215_, new_n216_,
    new_n217_, new_n218_, new_n219_, new_n220_, new_n221_, new_n222_,
    new_n223_, new_n224_, new_n225_, new_n226_, new_n227_, new_n230_,
    new_n231_, new_n232_, new_n233_, new_n234_, new_n235_, new_n236_,
    new_n237_, new_n238_, new_n239_, new_n240_, new_n241_, new_n242_,
    new_n244_, new_n245_, new_n246_, new_n247_, new_n248_, new_n249_;
  INVx1_ASAP7_75t_R   g000(.A(p16), .Y(new_n44_));
  INVx1_ASAP7_75t_R   g001(.A(p13), .Y(new_n45_));
  NAND2x1_ASAP7_75t_R g002(.A(p14), .B(new_n45_), .Y(new_n46_));
  OAI21x1_ASAP7_75t_R g003(.A1(new_n44_), .A2(p15), .B(new_n46_), .Y(new_n47_));
  INVx1_ASAP7_75t_R   g004(.A(p12), .Y(new_n48_));
  INVx1_ASAP7_75t_R   g005(.A(p3), .Y(new_n49_));
  NAND2x1_ASAP7_75t_R g006(.A(p4), .B(new_n49_), .Y(new_n50_));
  OAI21x1_ASAP7_75t_R g007(.A1(new_n48_), .A2(p11), .B(new_n50_), .Y(new_n51_));
  NOR2x1_ASAP7_75t_R  g008(.A(new_n47_), .B(new_n51_), .Y(new_n52_));
  INVx1_ASAP7_75t_R   g009(.A(p7), .Y(new_n53_));
  NAND2x1_ASAP7_75t_R g010(.A(p8), .B(new_n53_), .Y(new_n54_));
  INVx1_ASAP7_75t_R   g011(.A(p5), .Y(new_n55_));
  NAND2x1_ASAP7_75t_R g012(.A(p6), .B(new_n55_), .Y(new_n56_));
  INVx1_ASAP7_75t_R   g013(.A(p9), .Y(new_n57_));
  NAND2x1_ASAP7_75t_R g014(.A(p10), .B(new_n57_), .Y(new_n58_));
  AND3x1_ASAP7_75t_R  g015(.A(new_n54_), .B(new_n56_), .C(new_n58_), .Y(new_n59_));
  INVx1_ASAP7_75t_R   g016(.A(p0), .Y(new_n60_));
  NOR2x1_ASAP7_75t_R  g017(.A(p35), .B(new_n60_), .Y(new_n61_));
  INVx1_ASAP7_75t_R   g018(.A(p2), .Y(new_n62_));
  NOR2x1_ASAP7_75t_R  g019(.A(p1), .B(new_n62_), .Y(new_n63_));
  NOR2x1_ASAP7_75t_R  g020(.A(new_n61_), .B(new_n63_), .Y(new_n64_));
  NAND3x1_ASAP7_75t_R g021(.A(new_n52_), .B(new_n59_), .C(new_n64_), .Y(o0));
  NOR2x1_ASAP7_75t_R  g022(.A(p11), .B(new_n48_), .Y(new_n66_));
  AOI21x1_ASAP7_75t_R g023(.A1(new_n49_), .A2(p4), .B(new_n66_), .Y(new_n67_));
  INVx1_ASAP7_75t_R   g024(.A(p15), .Y(new_n68_));
  NAND2x1_ASAP7_75t_R g025(.A(p16), .B(new_n68_), .Y(new_n69_));
  NAND3x1_ASAP7_75t_R g026(.A(new_n67_), .B(new_n46_), .C(new_n69_), .Y(new_n70_));
  INVx1_ASAP7_75t_R   g027(.A(p10), .Y(new_n71_));
  NOR2x1_ASAP7_75t_R  g028(.A(p9), .B(new_n71_), .Y(new_n72_));
  AOI21x1_ASAP7_75t_R g029(.A1(new_n53_), .A2(p8), .B(new_n72_), .Y(new_n73_));
  NAND3x1_ASAP7_75t_R g030(.A(new_n73_), .B(new_n64_), .C(new_n56_), .Y(new_n74_));
  OA21x2_ASAP7_75t_R  g031(.A1(new_n70_), .A2(new_n74_), .B(p7), .Y(new_n75_));
  INVx1_ASAP7_75t_R   g032(.A(p21), .Y(new_n76_));
  NAND2x1_ASAP7_75t_R g033(.A(p8), .B(new_n76_), .Y(new_n77_));
  NAND2x1_ASAP7_75t_R g034(.A(new_n64_), .B(new_n67_), .Y(new_n78_));
  OAI21x1_ASAP7_75t_R g035(.A1(new_n47_), .A2(new_n78_), .B(p15), .Y(new_n79_));
  AO21x1_ASAP7_75t_R  g036(.A1(new_n56_), .A2(new_n73_), .B(new_n68_), .Y(new_n80_));
  NOR2x1_ASAP7_75t_R  g037(.A(p25), .B(new_n44_), .Y(new_n81_));
  NAND3x1_ASAP7_75t_R g038(.A(new_n79_), .B(new_n80_), .C(new_n81_), .Y(new_n82_));
  OAI21x1_ASAP7_75t_R g039(.A1(new_n75_), .A2(new_n77_), .B(new_n82_), .Y(new_n83_));
  OA21x2_ASAP7_75t_R  g040(.A1(new_n70_), .A2(new_n74_), .B(p5), .Y(new_n84_));
  INVx1_ASAP7_75t_R   g041(.A(p20), .Y(new_n85_));
  NAND2x1_ASAP7_75t_R g042(.A(p6), .B(new_n85_), .Y(new_n86_));
  NOR2x1_ASAP7_75t_R  g043(.A(p22), .B(new_n71_), .Y(new_n87_));
  OAI21x1_ASAP7_75t_R g044(.A1(new_n70_), .A2(new_n74_), .B(p9), .Y(new_n88_));
  NAND2x1_ASAP7_75t_R g045(.A(new_n87_), .B(new_n88_), .Y(new_n89_));
  OAI21x1_ASAP7_75t_R g046(.A1(new_n84_), .A2(new_n86_), .B(new_n89_), .Y(new_n90_));
  NOR2x1_ASAP7_75t_R  g047(.A(new_n83_), .B(new_n90_), .Y(new_n91_));
  INVx1_ASAP7_75t_R   g048(.A(p18), .Y(new_n92_));
  NAND2x1_ASAP7_75t_R g049(.A(p2), .B(new_n92_), .Y(new_n93_));
  AOI21x1_ASAP7_75t_R g050(.A1(p1), .A2(o0), .B(new_n93_), .Y(new_n94_));
  INVx1_ASAP7_75t_R   g051(.A(p19), .Y(new_n95_));
  NAND2x1_ASAP7_75t_R g052(.A(p4), .B(new_n95_), .Y(new_n96_));
  AOI21x1_ASAP7_75t_R g053(.A1(new_n50_), .A2(o0), .B(new_n96_), .Y(new_n97_));
  INVx1_ASAP7_75t_R   g054(.A(p23), .Y(new_n98_));
  NAND2x1_ASAP7_75t_R g055(.A(p12), .B(new_n98_), .Y(new_n99_));
  AOI21x1_ASAP7_75t_R g056(.A1(p11), .A2(o0), .B(new_n99_), .Y(new_n100_));
  NOR3x1_ASAP7_75t_R  g057(.A(new_n94_), .B(new_n97_), .C(new_n100_), .Y(new_n101_));
  OR2x4_ASAP7_75t_R   g058(.A(p17), .B(new_n60_), .Y(new_n102_));
  AOI21x1_ASAP7_75t_R g059(.A1(p35), .A2(o0), .B(new_n102_), .Y(new_n103_));
  INVx1_ASAP7_75t_R   g060(.A(p24), .Y(new_n104_));
  NAND2x1_ASAP7_75t_R g061(.A(p14), .B(new_n104_), .Y(new_n105_));
  AOI21x1_ASAP7_75t_R g062(.A1(p13), .A2(o0), .B(new_n105_), .Y(new_n106_));
  NOR2x1_ASAP7_75t_R  g063(.A(new_n103_), .B(new_n106_), .Y(new_n107_));
  NAND3x1_ASAP7_75t_R g064(.A(new_n91_), .B(new_n101_), .C(new_n107_), .Y(o1));
  AOI21x1_ASAP7_75t_R g065(.A1(p7), .A2(o0), .B(new_n77_), .Y(new_n109_));
  NOR2x1_ASAP7_75t_R  g066(.A(new_n109_), .B(new_n106_), .Y(new_n110_));
  NOR2x1_ASAP7_75t_R  g067(.A(new_n97_), .B(new_n100_), .Y(new_n111_));
  NAND2x1_ASAP7_75t_R g068(.A(new_n110_), .B(new_n111_), .Y(new_n112_));
  AOI21x1_ASAP7_75t_R g069(.A1(p5), .A2(o0), .B(new_n86_), .Y(new_n113_));
  NOR2x1_ASAP7_75t_R  g070(.A(new_n113_), .B(new_n103_), .Y(new_n114_));
  INVx1_ASAP7_75t_R   g071(.A(new_n81_), .Y(new_n115_));
  AOI21x1_ASAP7_75t_R g072(.A1(p15), .A2(o0), .B(new_n115_), .Y(new_n116_));
  NOR2x1_ASAP7_75t_R  g073(.A(new_n94_), .B(new_n116_), .Y(new_n117_));
  NAND3x1_ASAP7_75t_R g074(.A(new_n114_), .B(new_n117_), .C(new_n89_), .Y(new_n118_));
  NOR2x1_ASAP7_75t_R  g075(.A(new_n112_), .B(new_n118_), .Y(new_n119_));
  INVx1_ASAP7_75t_R   g076(.A(p6), .Y(new_n120_));
  NOR3x1_ASAP7_75t_R  g077(.A(new_n84_), .B(p29), .C(new_n120_), .Y(new_n121_));
  OAI21x1_ASAP7_75t_R g078(.A1(new_n85_), .A2(new_n119_), .B(new_n121_), .Y(new_n122_));
  NOR2x1_ASAP7_75t_R  g079(.A(new_n70_), .B(new_n74_), .Y(new_n123_));
  OAI21x1_ASAP7_75t_R g080(.A1(new_n53_), .A2(new_n123_), .B(p8), .Y(new_n124_));
  NOR2x1_ASAP7_75t_R  g081(.A(p30), .B(new_n124_), .Y(new_n125_));
  OAI21x1_ASAP7_75t_R g082(.A1(new_n76_), .A2(new_n119_), .B(new_n125_), .Y(new_n126_));
  INVx1_ASAP7_75t_R   g083(.A(new_n107_), .Y(new_n127_));
  NOR2x1_ASAP7_75t_R  g084(.A(new_n109_), .B(new_n116_), .Y(new_n128_));
  AOI21x1_ASAP7_75t_R g085(.A1(new_n88_), .A2(new_n87_), .B(new_n113_), .Y(new_n129_));
  NAND2x1_ASAP7_75t_R g086(.A(new_n128_), .B(new_n129_), .Y(new_n130_));
  OAI21x1_ASAP7_75t_R g087(.A1(new_n127_), .A2(new_n130_), .B(p22), .Y(new_n131_));
  AO21x1_ASAP7_75t_R  g088(.A1(p2), .A2(new_n123_), .B(new_n63_), .Y(new_n132_));
  AO21x1_ASAP7_75t_R  g089(.A1(new_n92_), .A2(new_n132_), .B(new_n100_), .Y(new_n133_));
  OAI21x1_ASAP7_75t_R g090(.A1(new_n97_), .A2(new_n133_), .B(p22), .Y(new_n134_));
  NAND2x1_ASAP7_75t_R g091(.A(p10), .B(new_n88_), .Y(new_n135_));
  NOR2x1_ASAP7_75t_R  g092(.A(p31), .B(new_n135_), .Y(new_n136_));
  NAND3x1_ASAP7_75t_R g093(.A(new_n131_), .B(new_n134_), .C(new_n136_), .Y(new_n137_));
  NAND3x1_ASAP7_75t_R g094(.A(new_n122_), .B(new_n126_), .C(new_n137_), .Y(new_n138_));
  NAND2x1_ASAP7_75t_R g095(.A(p23), .B(o1), .Y(new_n139_));
  AO21x1_ASAP7_75t_R  g096(.A1(p11), .A2(o0), .B(new_n48_), .Y(new_n140_));
  NOR2x1_ASAP7_75t_R  g097(.A(p32), .B(new_n140_), .Y(new_n141_));
  OAI21x1_ASAP7_75t_R g098(.A1(new_n49_), .A2(new_n123_), .B(p4), .Y(new_n142_));
  NOR2x1_ASAP7_75t_R  g099(.A(p28), .B(new_n142_), .Y(new_n143_));
  INVx1_ASAP7_75t_R   g100(.A(new_n143_), .Y(new_n144_));
  AOI21x1_ASAP7_75t_R g101(.A1(p19), .A2(o1), .B(new_n144_), .Y(new_n145_));
  AOI21x1_ASAP7_75t_R g102(.A1(new_n139_), .A2(new_n141_), .B(new_n145_), .Y(new_n146_));
  NAND2x1_ASAP7_75t_R g103(.A(p18), .B(o1), .Y(new_n147_));
  INVx1_ASAP7_75t_R   g104(.A(p27), .Y(new_n148_));
  AND2x2_ASAP7_75t_R  g105(.A(new_n148_), .B(new_n132_), .Y(new_n149_));
  NAND2x1_ASAP7_75t_R g106(.A(p35), .B(o0), .Y(new_n150_));
  INVx1_ASAP7_75t_R   g107(.A(p26), .Y(new_n151_));
  AND3x1_ASAP7_75t_R  g108(.A(new_n150_), .B(new_n151_), .C(p0), .Y(new_n152_));
  INVx1_ASAP7_75t_R   g109(.A(new_n152_), .Y(new_n153_));
  AOI21x1_ASAP7_75t_R g110(.A1(p17), .A2(o1), .B(new_n153_), .Y(new_n154_));
  AOI21x1_ASAP7_75t_R g111(.A1(new_n147_), .A2(new_n149_), .B(new_n154_), .Y(new_n155_));
  NAND2x1_ASAP7_75t_R g112(.A(p15), .B(o0), .Y(new_n156_));
  INVx1_ASAP7_75t_R   g113(.A(p34), .Y(new_n157_));
  AND3x1_ASAP7_75t_R  g114(.A(new_n156_), .B(p16), .C(new_n157_), .Y(new_n158_));
  INVx1_ASAP7_75t_R   g115(.A(new_n158_), .Y(new_n159_));
  AOI21x1_ASAP7_75t_R g116(.A1(p25), .A2(o1), .B(new_n159_), .Y(new_n160_));
  NAND2x1_ASAP7_75t_R g117(.A(p13), .B(o0), .Y(new_n161_));
  INVx1_ASAP7_75t_R   g118(.A(p33), .Y(new_n162_));
  AND3x1_ASAP7_75t_R  g119(.A(new_n161_), .B(p14), .C(new_n162_), .Y(new_n163_));
  INVx1_ASAP7_75t_R   g120(.A(new_n163_), .Y(new_n164_));
  AOI21x1_ASAP7_75t_R g121(.A1(p24), .A2(o1), .B(new_n164_), .Y(new_n165_));
  NOR2x1_ASAP7_75t_R  g122(.A(new_n160_), .B(new_n165_), .Y(new_n166_));
  NAND3x1_ASAP7_75t_R g123(.A(new_n146_), .B(new_n155_), .C(new_n166_), .Y(new_n167_));
  NOR2x1_ASAP7_75t_R  g124(.A(new_n138_), .B(new_n167_), .Y(new_n168_));
  INVx1_ASAP7_75t_R   g125(.A(new_n168_), .Y(o2));
  OAI21x1_ASAP7_75t_R g126(.A1(new_n127_), .A2(new_n130_), .B(p25), .Y(new_n170_));
  OAI21x1_ASAP7_75t_R g127(.A1(new_n97_), .A2(new_n133_), .B(p25), .Y(new_n171_));
  NAND3x1_ASAP7_75t_R g128(.A(new_n170_), .B(new_n171_), .C(new_n158_), .Y(new_n172_));
  OAI21x1_ASAP7_75t_R g129(.A1(new_n112_), .A2(new_n118_), .B(p17), .Y(new_n173_));
  NAND2x1_ASAP7_75t_R g130(.A(new_n152_), .B(new_n173_), .Y(new_n174_));
  INVx1_ASAP7_75t_R   g131(.A(new_n97_), .Y(new_n175_));
  OAI21x1_ASAP7_75t_R g132(.A1(new_n127_), .A2(new_n130_), .B(new_n175_), .Y(new_n176_));
  NAND2x1_ASAP7_75t_R g133(.A(new_n175_), .B(new_n133_), .Y(new_n177_));
  NAND3x1_ASAP7_75t_R g134(.A(new_n176_), .B(new_n143_), .C(new_n177_), .Y(new_n178_));
  NAND3x1_ASAP7_75t_R g135(.A(new_n172_), .B(new_n174_), .C(new_n178_), .Y(new_n179_));
  OAI21x1_ASAP7_75t_R g136(.A1(new_n98_), .A2(new_n119_), .B(new_n141_), .Y(new_n180_));
  OAI21x1_ASAP7_75t_R g137(.A1(new_n104_), .A2(new_n119_), .B(new_n163_), .Y(new_n181_));
  OAI21x1_ASAP7_75t_R g138(.A1(new_n127_), .A2(new_n130_), .B(p18), .Y(new_n182_));
  OAI21x1_ASAP7_75t_R g139(.A1(new_n97_), .A2(new_n133_), .B(p18), .Y(new_n183_));
  NAND3x1_ASAP7_75t_R g140(.A(new_n182_), .B(new_n183_), .C(new_n149_), .Y(new_n184_));
  NAND3x1_ASAP7_75t_R g141(.A(new_n180_), .B(new_n181_), .C(new_n184_), .Y(new_n185_));
  OA21x2_ASAP7_75t_R  g142(.A1(new_n179_), .A2(new_n185_), .B(p26), .Y(new_n186_));
  AND3x1_ASAP7_75t_R  g143(.A(new_n122_), .B(new_n126_), .C(new_n137_), .Y(new_n187_));
  AND3x1_ASAP7_75t_R  g144(.A(new_n173_), .B(p0), .C(new_n150_), .Y(new_n188_));
  OAI21x1_ASAP7_75t_R g145(.A1(new_n151_), .A2(new_n187_), .B(new_n188_), .Y(new_n189_));
  NAND2x1_ASAP7_75t_R g146(.A(new_n137_), .B(new_n126_), .Y(new_n190_));
  AO21x1_ASAP7_75t_R  g147(.A1(p5), .A2(o0), .B(new_n120_), .Y(new_n191_));
  AO21x1_ASAP7_75t_R  g148(.A1(p20), .A2(o1), .B(new_n191_), .Y(new_n192_));
  AOI21x1_ASAP7_75t_R g149(.A1(p29), .A2(new_n190_), .B(new_n192_), .Y(new_n193_));
  OAI21x1_ASAP7_75t_R g150(.A1(new_n179_), .A2(new_n185_), .B(p29), .Y(new_n194_));
  NAND2x1_ASAP7_75t_R g151(.A(new_n193_), .B(new_n194_), .Y(new_n195_));
  OAI21x1_ASAP7_75t_R g152(.A1(new_n186_), .A2(new_n189_), .B(new_n195_), .Y(new_n196_));
  OA21x2_ASAP7_75t_R  g153(.A1(new_n179_), .A2(new_n185_), .B(p27), .Y(new_n197_));
  AND3x1_ASAP7_75t_R  g154(.A(new_n182_), .B(new_n132_), .C(new_n183_), .Y(new_n198_));
  OAI21x1_ASAP7_75t_R g155(.A1(new_n148_), .A2(new_n187_), .B(new_n198_), .Y(new_n199_));
  AO21x1_ASAP7_75t_R  g156(.A1(p19), .A2(o1), .B(new_n142_), .Y(new_n200_));
  NOR2x1_ASAP7_75t_R  g157(.A(new_n200_), .B(new_n138_), .Y(new_n201_));
  NOR2x1_ASAP7_75t_R  g158(.A(new_n179_), .B(new_n185_), .Y(new_n202_));
  AOI21x1_ASAP7_75t_R g159(.A1(new_n201_), .A2(new_n202_), .B(new_n145_), .Y(new_n203_));
  OAI21x1_ASAP7_75t_R g160(.A1(new_n197_), .A2(new_n199_), .B(new_n203_), .Y(new_n204_));
  NOR2x1_ASAP7_75t_R  g161(.A(new_n196_), .B(new_n204_), .Y(new_n205_));
  OA21x2_ASAP7_75t_R  g162(.A1(new_n179_), .A2(new_n185_), .B(p30), .Y(new_n206_));
  INVx1_ASAP7_75t_R   g163(.A(p30), .Y(new_n207_));
  AOI21x1_ASAP7_75t_R g164(.A1(p21), .A2(o1), .B(new_n124_), .Y(new_n208_));
  OAI21x1_ASAP7_75t_R g165(.A1(new_n207_), .A2(new_n187_), .B(new_n208_), .Y(new_n209_));
  AO21x1_ASAP7_75t_R  g166(.A1(p22), .A2(o1), .B(new_n135_), .Y(new_n210_));
  AOI21x1_ASAP7_75t_R g167(.A1(p31), .A2(new_n138_), .B(new_n210_), .Y(new_n211_));
  OAI21x1_ASAP7_75t_R g168(.A1(new_n179_), .A2(new_n185_), .B(p31), .Y(new_n212_));
  NAND2x1_ASAP7_75t_R g169(.A(new_n211_), .B(new_n212_), .Y(new_n213_));
  OAI21x1_ASAP7_75t_R g170(.A1(new_n206_), .A2(new_n209_), .B(new_n213_), .Y(new_n214_));
  OA21x2_ASAP7_75t_R  g171(.A1(new_n179_), .A2(new_n185_), .B(p33), .Y(new_n215_));
  AND2x2_ASAP7_75t_R  g172(.A(p14), .B(new_n161_), .Y(new_n216_));
  AOI21x1_ASAP7_75t_R g173(.A1(new_n216_), .A2(new_n119_), .B(new_n106_), .Y(new_n217_));
  AO21x1_ASAP7_75t_R  g174(.A1(p33), .A2(new_n138_), .B(new_n217_), .Y(new_n218_));
  AO21x1_ASAP7_75t_R  g175(.A1(p23), .A2(o1), .B(new_n140_), .Y(new_n219_));
  AOI21x1_ASAP7_75t_R g176(.A1(p32), .A2(new_n138_), .B(new_n219_), .Y(new_n220_));
  OAI21x1_ASAP7_75t_R g177(.A1(new_n179_), .A2(new_n185_), .B(p32), .Y(new_n221_));
  NAND2x1_ASAP7_75t_R g178(.A(new_n220_), .B(new_n221_), .Y(new_n222_));
  OAI21x1_ASAP7_75t_R g179(.A1(new_n215_), .A2(new_n218_), .B(new_n222_), .Y(new_n223_));
  NOR2x1_ASAP7_75t_R  g180(.A(new_n214_), .B(new_n223_), .Y(new_n224_));
  AND3x1_ASAP7_75t_R  g181(.A(new_n79_), .B(p16), .C(new_n80_), .Y(new_n225_));
  AND3x1_ASAP7_75t_R  g182(.A(new_n170_), .B(new_n225_), .C(new_n171_), .Y(new_n226_));
  AO21x1_ASAP7_75t_R  g183(.A1(new_n226_), .A2(new_n168_), .B(new_n160_), .Y(new_n227_));
  AOI21x1_ASAP7_75t_R g184(.A1(new_n205_), .A2(new_n224_), .B(new_n227_), .Y(o3));
  INVx1_ASAP7_75t_R   g185(.A(new_n224_), .Y(o4));
  AOI21x1_ASAP7_75t_R g186(.A1(new_n221_), .A2(new_n220_), .B(new_n195_), .Y(new_n230_));
  NAND2x1_ASAP7_75t_R g187(.A(new_n208_), .B(new_n187_), .Y(new_n231_));
  NOR2x1_ASAP7_75t_R  g188(.A(new_n167_), .B(new_n231_), .Y(new_n232_));
  INVx1_ASAP7_75t_R   g189(.A(new_n136_), .Y(new_n233_));
  AOI21x1_ASAP7_75t_R g190(.A1(p22), .A2(o1), .B(new_n233_), .Y(new_n234_));
  AOI21x1_ASAP7_75t_R g191(.A1(new_n207_), .A2(new_n208_), .B(new_n234_), .Y(new_n235_));
  INVx1_ASAP7_75t_R   g192(.A(new_n210_), .Y(new_n236_));
  NAND3x1_ASAP7_75t_R g193(.A(new_n235_), .B(new_n122_), .C(new_n236_), .Y(new_n237_));
  OAI21x1_ASAP7_75t_R g194(.A1(new_n237_), .A2(new_n167_), .B(new_n235_), .Y(new_n238_));
  NOR2x1_ASAP7_75t_R  g195(.A(new_n232_), .B(new_n238_), .Y(new_n239_));
  NAND2x1_ASAP7_75t_R g196(.A(new_n230_), .B(new_n239_), .Y(new_n240_));
  INVx1_ASAP7_75t_R   g197(.A(new_n223_), .Y(new_n241_));
  OR3x1_ASAP7_75t_R   g198(.A(new_n238_), .B(new_n203_), .C(new_n232_), .Y(new_n242_));
  NAND3x1_ASAP7_75t_R g199(.A(new_n240_), .B(new_n241_), .C(new_n242_), .Y(o5));
  INVx1_ASAP7_75t_R   g200(.A(new_n222_), .Y(new_n244_));
  NOR2x1_ASAP7_75t_R  g201(.A(new_n199_), .B(new_n197_), .Y(new_n245_));
  INVx1_ASAP7_75t_R   g202(.A(new_n213_), .Y(new_n246_));
  AOI21x1_ASAP7_75t_R g203(.A1(new_n203_), .A2(new_n245_), .B(new_n246_), .Y(new_n247_));
  NOR2x1_ASAP7_75t_R  g204(.A(new_n218_), .B(new_n215_), .Y(new_n248_));
  AOI21x1_ASAP7_75t_R g205(.A1(new_n230_), .A2(new_n239_), .B(new_n248_), .Y(new_n249_));
  OAI21x1_ASAP7_75t_R g206(.A1(new_n244_), .A2(new_n247_), .B(new_n249_), .Y(o6));
endmodule


