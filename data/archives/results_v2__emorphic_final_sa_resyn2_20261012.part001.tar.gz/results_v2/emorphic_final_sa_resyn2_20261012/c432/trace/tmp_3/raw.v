// Benchmark "/tmp/" written by ABC on Mon Oct 12 14:43:37 2026

module \/tmp/  ( 
    p35, p12, p14, p17, p33, p10, p4, p3, p5, p32, p16, p13, p1, p25, p26,
    p28, p30, p6, p20, p15, p21, p8, p29, p22, p19, p11, p23, p31, p0, p27,
    p7, p2, p24, p34, p18, p9,
    o0, o1, o2, o3, o4, o5, o6  );
  input  p35, p12, p14, p17, p33, p10, p4, p3, p5, p32, p16, p13, p1,
    p25, p26, p28, p30, p6, p20, p15, p21, p8, p29, p22, p19, p11, p23,
    p31, p0, p27, p7, p2, p24, p34, p18, p9;
  output o0, o1, o2, o3, o4, o5, o6;
  wire new_n44_, new_n45_, new_n46_, new_n47_, new_n48_, new_n49_, new_n50_,
    new_n51_, new_n52_, new_n53_, new_n54_, new_n55_, new_n56_, new_n57_,
    new_n58_, new_n59_, new_n60_, new_n61_, new_n62_, new_n63_, new_n65_,
    new_n66_, new_n67_, new_n68_, new_n69_, new_n70_, new_n71_, new_n72_,
    new_n73_, new_n74_, new_n75_, new_n76_, new_n77_, new_n78_, new_n79_,
    new_n80_, new_n81_, new_n82_, new_n83_, new_n84_, new_n85_, new_n86_,
    new_n87_, new_n88_, new_n89_, new_n90_, new_n91_, new_n92_, new_n93_,
    new_n94_, new_n95_, new_n96_, new_n97_, new_n98_, new_n99_, new_n100_,
    new_n101_, new_n102_, new_n103_, new_n104_, new_n105_, new_n106_,
    new_n108_, new_n109_, new_n110_, new_n111_, new_n112_, new_n113_,
    new_n114_, new_n115_, new_n116_, new_n117_, new_n118_, new_n119_,
    new_n120_, new_n121_, new_n122_, new_n123_, new_n124_, new_n125_,
    new_n126_, new_n127_, new_n128_, new_n129_, new_n130_, new_n131_,
    new_n132_, new_n133_, new_n134_, new_n135_, new_n136_, new_n137_,
    new_n138_, new_n139_, new_n140_, new_n141_, new_n142_, new_n143_,
    new_n144_, new_n145_, new_n146_, new_n147_, new_n148_, new_n149_,
    new_n150_, new_n151_, new_n152_, new_n153_, new_n154_, new_n155_,
    new_n156_, new_n157_, new_n158_, new_n159_, new_n160_, new_n161_,
    new_n162_, new_n163_, new_n164_, new_n166_, new_n167_, new_n168_,
    new_n169_, new_n170_, new_n171_, new_n172_, new_n173_, new_n174_,
    new_n175_, new_n176_, new_n177_, new_n178_, new_n179_, new_n180_,
    new_n181_, new_n182_, new_n183_, new_n184_, new_n185_, new_n186_,
    new_n187_, new_n188_, new_n189_, new_n190_, new_n191_, new_n192_,
    new_n193_, new_n194_, new_n195_, new_n196_, new_n197_, new_n198_,
    new_n199_, new_n200_, new_n201_, new_n202_, new_n203_, new_n204_,
    new_n205_, new_n206_, new_n207_, new_n208_, new_n209_, new_n210_,
    new_n211_, new_n212_, new_n213_, new_n214_, new_n215_, new_n218_,
    new_n219_, new_n220_, new_n221_, new_n222_, new_n223_, new_n224_,
    new_n225_, new_n226_, new_n227_, new_n228_, new_n229_, new_n230_,
    new_n231_, new_n232_, new_n233_, new_n234_, new_n235_, new_n236_,
    new_n237_, new_n239_, new_n240_, new_n241_, new_n242_, new_n243_,
    new_n244_, new_n245_, new_n246_;
  INVx1_ASAP7_75t_R   g000(.A(p16), .Y(new_n44_));
  INVx1_ASAP7_75t_R   g001(.A(p13), .Y(new_n45_));
  NAND2x1_ASAP7_75t_R g002(.A(p14), .B(new_n45_), .Y(new_n46_));
  OAI21x1_ASAP7_75t_R g003(.A1(new_n44_), .A2(p15), .B(new_n46_), .Y(new_n47_));
  INVx1_ASAP7_75t_R   g004(.A(p12), .Y(new_n48_));
  INVx1_ASAP7_75t_R   g005(.A(p3), .Y(new_n49_));
  NAND2x1_ASAP7_75t_R g006(.A(p4), .B(new_n49_), .Y(new_n50_));
  OAI21x1_ASAP7_75t_R g007(.A1(new_n48_), .A2(p11), .B(new_n50_), .Y(new_n51_));
  NOR2x1_ASAP7_75t_R  g008(.A(new_n47_), .B(new_n51_), .Y(new_n52_));
  INVx1_ASAP7_75t_R   g009(.A(p35), .Y(new_n53_));
  INVx1_ASAP7_75t_R   g010(.A(p2), .Y(new_n54_));
  NOR2x1_ASAP7_75t_R  g011(.A(p1), .B(new_n54_), .Y(new_n55_));
  AOI21x1_ASAP7_75t_R g012(.A1(new_n53_), .A2(p0), .B(new_n55_), .Y(new_n56_));
  INVx1_ASAP7_75t_R   g013(.A(p8), .Y(new_n57_));
  NOR2x1_ASAP7_75t_R  g014(.A(p7), .B(new_n57_), .Y(new_n58_));
  INVx1_ASAP7_75t_R   g015(.A(p6), .Y(new_n59_));
  NOR2x1_ASAP7_75t_R  g016(.A(p5), .B(new_n59_), .Y(new_n60_));
  INVx1_ASAP7_75t_R   g017(.A(p10), .Y(new_n61_));
  NOR2x1_ASAP7_75t_R  g018(.A(p9), .B(new_n61_), .Y(new_n62_));
  NOR3x1_ASAP7_75t_R  g019(.A(new_n58_), .B(new_n60_), .C(new_n62_), .Y(new_n63_));
  NAND3x1_ASAP7_75t_R g020(.A(new_n52_), .B(new_n56_), .C(new_n63_), .Y(o0));
  OA21x2_ASAP7_75t_R  g021(.A1(new_n44_), .A2(p15), .B(new_n46_), .Y(new_n65_));
  INVx1_ASAP7_75t_R   g022(.A(p4), .Y(new_n66_));
  NOR2x1_ASAP7_75t_R  g023(.A(p3), .B(new_n66_), .Y(new_n67_));
  NOR2x1_ASAP7_75t_R  g024(.A(p11), .B(new_n48_), .Y(new_n68_));
  NOR2x1_ASAP7_75t_R  g025(.A(new_n67_), .B(new_n68_), .Y(new_n69_));
  AND3x1_ASAP7_75t_R  g026(.A(new_n63_), .B(new_n65_), .C(new_n69_), .Y(new_n70_));
  INVx1_ASAP7_75t_R   g027(.A(p1), .Y(new_n71_));
  AOI21x1_ASAP7_75t_R g028(.A1(new_n56_), .A2(new_n70_), .B(new_n71_), .Y(new_n72_));
  INVx1_ASAP7_75t_R   g029(.A(p18), .Y(new_n73_));
  NAND2x1_ASAP7_75t_R g030(.A(p2), .B(new_n73_), .Y(new_n74_));
  NAND2x1_ASAP7_75t_R g031(.A(new_n69_), .B(new_n56_), .Y(new_n75_));
  OAI21x1_ASAP7_75t_R g032(.A1(new_n47_), .A2(new_n75_), .B(p13), .Y(new_n76_));
  INVx1_ASAP7_75t_R   g033(.A(new_n63_), .Y(new_n77_));
  NAND2x1_ASAP7_75t_R g034(.A(p13), .B(new_n77_), .Y(new_n78_));
  INVx1_ASAP7_75t_R   g035(.A(p14), .Y(new_n79_));
  NOR2x1_ASAP7_75t_R  g036(.A(p24), .B(new_n79_), .Y(new_n80_));
  NAND3x1_ASAP7_75t_R g037(.A(new_n76_), .B(new_n78_), .C(new_n80_), .Y(new_n81_));
  OAI21x1_ASAP7_75t_R g038(.A1(new_n72_), .A2(new_n74_), .B(new_n81_), .Y(new_n82_));
  INVx1_ASAP7_75t_R   g039(.A(p9), .Y(new_n83_));
  AOI21x1_ASAP7_75t_R g040(.A1(new_n56_), .A2(new_n70_), .B(new_n83_), .Y(new_n84_));
  OR2x4_ASAP7_75t_R   g041(.A(p22), .B(new_n61_), .Y(new_n85_));
  OAI21x1_ASAP7_75t_R g042(.A1(new_n47_), .A2(new_n75_), .B(p11), .Y(new_n86_));
  NAND2x1_ASAP7_75t_R g043(.A(p11), .B(new_n77_), .Y(new_n87_));
  NOR2x1_ASAP7_75t_R  g044(.A(p23), .B(new_n48_), .Y(new_n88_));
  NAND3x1_ASAP7_75t_R g045(.A(new_n86_), .B(new_n87_), .C(new_n88_), .Y(new_n89_));
  OAI21x1_ASAP7_75t_R g046(.A1(new_n84_), .A2(new_n85_), .B(new_n89_), .Y(new_n90_));
  NOR2x1_ASAP7_75t_R  g047(.A(new_n82_), .B(new_n90_), .Y(new_n91_));
  INVx1_ASAP7_75t_R   g048(.A(p20), .Y(new_n92_));
  NAND2x1_ASAP7_75t_R g049(.A(p6), .B(new_n92_), .Y(new_n93_));
  AOI21x1_ASAP7_75t_R g050(.A1(p5), .A2(o0), .B(new_n93_), .Y(new_n94_));
  OR2x4_ASAP7_75t_R   g051(.A(p19), .B(new_n66_), .Y(new_n95_));
  AOI21x1_ASAP7_75t_R g052(.A1(new_n50_), .A2(o0), .B(new_n95_), .Y(new_n96_));
  NOR2x1_ASAP7_75t_R  g053(.A(new_n94_), .B(new_n96_), .Y(new_n97_));
  OR2x4_ASAP7_75t_R   g054(.A(p25), .B(new_n44_), .Y(new_n98_));
  AOI21x1_ASAP7_75t_R g055(.A1(p15), .A2(o0), .B(new_n98_), .Y(new_n99_));
  INVx1_ASAP7_75t_R   g056(.A(p21), .Y(new_n100_));
  NAND2x1_ASAP7_75t_R g057(.A(p8), .B(new_n100_), .Y(new_n101_));
  AOI21x1_ASAP7_75t_R g058(.A1(p7), .A2(o0), .B(new_n101_), .Y(new_n102_));
  INVx1_ASAP7_75t_R   g059(.A(p0), .Y(new_n103_));
  OR2x4_ASAP7_75t_R   g060(.A(p17), .B(new_n103_), .Y(new_n104_));
  AOI21x1_ASAP7_75t_R g061(.A1(p35), .A2(o0), .B(new_n104_), .Y(new_n105_));
  NOR3x1_ASAP7_75t_R  g062(.A(new_n99_), .B(new_n102_), .C(new_n105_), .Y(new_n106_));
  NAND3x1_ASAP7_75t_R g063(.A(new_n91_), .B(new_n97_), .C(new_n106_), .Y(o1));
  NOR2x1_ASAP7_75t_R  g064(.A(new_n99_), .B(new_n102_), .Y(new_n108_));
  NAND2x1_ASAP7_75t_R g065(.A(p13), .B(o0), .Y(new_n109_));
  AOI21x1_ASAP7_75t_R g066(.A1(new_n109_), .A2(new_n80_), .B(new_n105_), .Y(new_n110_));
  NAND2x1_ASAP7_75t_R g067(.A(new_n108_), .B(new_n110_), .Y(new_n111_));
  NAND2x1_ASAP7_75t_R g068(.A(p11), .B(o0), .Y(new_n112_));
  AOI21x1_ASAP7_75t_R g069(.A1(new_n112_), .A2(new_n88_), .B(new_n96_), .Y(new_n113_));
  AOI21x1_ASAP7_75t_R g070(.A1(p9), .A2(o0), .B(new_n85_), .Y(new_n114_));
  NOR2x1_ASAP7_75t_R  g071(.A(new_n114_), .B(new_n94_), .Y(new_n115_));
  AO21x1_ASAP7_75t_R  g072(.A1(p1), .A2(o0), .B(new_n74_), .Y(new_n116_));
  NAND3x1_ASAP7_75t_R g073(.A(new_n113_), .B(new_n115_), .C(new_n116_), .Y(new_n117_));
  NOR2x1_ASAP7_75t_R  g074(.A(new_n111_), .B(new_n117_), .Y(new_n118_));
  NAND2x1_ASAP7_75t_R g075(.A(p7), .B(o0), .Y(new_n119_));
  INVx1_ASAP7_75t_R   g076(.A(p30), .Y(new_n120_));
  AND3x1_ASAP7_75t_R  g077(.A(new_n119_), .B(new_n120_), .C(p8), .Y(new_n121_));
  OAI21x1_ASAP7_75t_R g078(.A1(new_n100_), .A2(new_n118_), .B(new_n121_), .Y(new_n122_));
  INVx1_ASAP7_75t_R   g079(.A(p29), .Y(new_n123_));
  AND3x1_ASAP7_75t_R  g080(.A(new_n52_), .B(new_n56_), .C(new_n63_), .Y(new_n124_));
  AO21x1_ASAP7_75t_R  g081(.A1(p6), .A2(new_n124_), .B(new_n60_), .Y(new_n125_));
  AND2x2_ASAP7_75t_R  g082(.A(new_n123_), .B(new_n125_), .Y(new_n126_));
  OAI21x1_ASAP7_75t_R g083(.A1(new_n111_), .A2(new_n117_), .B(p20), .Y(new_n127_));
  NAND2x1_ASAP7_75t_R g084(.A(new_n126_), .B(new_n127_), .Y(new_n128_));
  INVx1_ASAP7_75t_R   g085(.A(new_n115_), .Y(new_n129_));
  OAI21x1_ASAP7_75t_R g086(.A1(new_n129_), .A2(new_n111_), .B(p22), .Y(new_n130_));
  NAND2x1_ASAP7_75t_R g087(.A(new_n89_), .B(new_n116_), .Y(new_n131_));
  OAI21x1_ASAP7_75t_R g088(.A1(new_n96_), .A2(new_n131_), .B(p22), .Y(new_n132_));
  AO21x1_ASAP7_75t_R  g089(.A1(p9), .A2(o0), .B(new_n61_), .Y(new_n133_));
  NOR2x1_ASAP7_75t_R  g090(.A(p31), .B(new_n133_), .Y(new_n134_));
  NAND3x1_ASAP7_75t_R g091(.A(new_n130_), .B(new_n132_), .C(new_n134_), .Y(new_n135_));
  NAND3x1_ASAP7_75t_R g092(.A(new_n122_), .B(new_n128_), .C(new_n135_), .Y(new_n136_));
  INVx1_ASAP7_75t_R   g093(.A(p25), .Y(new_n137_));
  AO21x1_ASAP7_75t_R  g094(.A1(p15), .A2(o0), .B(new_n44_), .Y(new_n138_));
  NOR2x1_ASAP7_75t_R  g095(.A(p34), .B(new_n138_), .Y(new_n139_));
  OAI21x1_ASAP7_75t_R g096(.A1(new_n137_), .A2(new_n118_), .B(new_n139_), .Y(new_n140_));
  INVx1_ASAP7_75t_R   g097(.A(p28), .Y(new_n141_));
  AO21x1_ASAP7_75t_R  g098(.A1(p4), .A2(new_n124_), .B(new_n67_), .Y(new_n142_));
  AND2x2_ASAP7_75t_R  g099(.A(new_n141_), .B(new_n142_), .Y(new_n143_));
  OAI21x1_ASAP7_75t_R g100(.A1(new_n111_), .A2(new_n117_), .B(p19), .Y(new_n144_));
  NAND2x1_ASAP7_75t_R g101(.A(new_n143_), .B(new_n144_), .Y(new_n145_));
  OAI21x1_ASAP7_75t_R g102(.A1(new_n129_), .A2(new_n111_), .B(p23), .Y(new_n146_));
  OAI21x1_ASAP7_75t_R g103(.A1(new_n96_), .A2(new_n131_), .B(p23), .Y(new_n147_));
  INVx1_ASAP7_75t_R   g104(.A(p32), .Y(new_n148_));
  AND3x1_ASAP7_75t_R  g105(.A(new_n112_), .B(p12), .C(new_n148_), .Y(new_n149_));
  NAND3x1_ASAP7_75t_R g106(.A(new_n146_), .B(new_n147_), .C(new_n149_), .Y(new_n150_));
  NAND3x1_ASAP7_75t_R g107(.A(new_n140_), .B(new_n145_), .C(new_n150_), .Y(new_n151_));
  OR3x1_ASAP7_75t_R   g108(.A(new_n72_), .B(p27), .C(new_n54_), .Y(new_n152_));
  INVx1_ASAP7_75t_R   g109(.A(new_n152_), .Y(new_n153_));
  OAI21x1_ASAP7_75t_R g110(.A1(new_n73_), .A2(new_n118_), .B(new_n153_), .Y(new_n154_));
  AO21x1_ASAP7_75t_R  g111(.A1(p35), .A2(o0), .B(new_n103_), .Y(new_n155_));
  NOR2x1_ASAP7_75t_R  g112(.A(p26), .B(new_n155_), .Y(new_n156_));
  OAI21x1_ASAP7_75t_R g113(.A1(new_n111_), .A2(new_n117_), .B(p17), .Y(new_n157_));
  NAND2x1_ASAP7_75t_R g114(.A(new_n156_), .B(new_n157_), .Y(new_n158_));
  OAI21x1_ASAP7_75t_R g115(.A1(new_n129_), .A2(new_n111_), .B(p24), .Y(new_n159_));
  OAI21x1_ASAP7_75t_R g116(.A1(new_n96_), .A2(new_n131_), .B(p24), .Y(new_n160_));
  INVx1_ASAP7_75t_R   g117(.A(p33), .Y(new_n161_));
  AND3x1_ASAP7_75t_R  g118(.A(new_n109_), .B(p14), .C(new_n161_), .Y(new_n162_));
  NAND3x1_ASAP7_75t_R g119(.A(new_n159_), .B(new_n160_), .C(new_n162_), .Y(new_n163_));
  NAND3x1_ASAP7_75t_R g120(.A(new_n154_), .B(new_n158_), .C(new_n163_), .Y(new_n164_));
  OR3x1_ASAP7_75t_R   g121(.A(new_n136_), .B(new_n151_), .C(new_n164_), .Y(o2));
  OA21x2_ASAP7_75t_R  g122(.A1(new_n151_), .A2(new_n164_), .B(p32), .Y(new_n166_));
  AO21x1_ASAP7_75t_R  g123(.A1(p11), .A2(o0), .B(new_n48_), .Y(new_n167_));
  AO21x1_ASAP7_75t_R  g124(.A1(p23), .A2(o1), .B(new_n167_), .Y(new_n168_));
  AO21x1_ASAP7_75t_R  g125(.A1(p32), .A2(new_n136_), .B(new_n168_), .Y(new_n169_));
  INVx1_ASAP7_75t_R   g126(.A(new_n162_), .Y(new_n170_));
  AOI21x1_ASAP7_75t_R g127(.A1(p24), .A2(o1), .B(new_n170_), .Y(new_n171_));
  AO21x1_ASAP7_75t_R  g128(.A1(p13), .A2(o0), .B(new_n79_), .Y(new_n172_));
  AO21x1_ASAP7_75t_R  g129(.A1(p24), .A2(o1), .B(new_n172_), .Y(new_n173_));
  NOR2x1_ASAP7_75t_R  g130(.A(new_n173_), .B(new_n136_), .Y(new_n174_));
  OAI21x1_ASAP7_75t_R g131(.A1(new_n151_), .A2(new_n164_), .B(p33), .Y(new_n175_));
  OAI21x1_ASAP7_75t_R g132(.A1(new_n171_), .A2(new_n174_), .B(new_n175_), .Y(new_n176_));
  OAI21x1_ASAP7_75t_R g133(.A1(new_n166_), .A2(new_n169_), .B(new_n176_), .Y(new_n177_));
  OA21x2_ASAP7_75t_R  g134(.A1(new_n151_), .A2(new_n164_), .B(p30), .Y(new_n178_));
  INVx1_ASAP7_75t_R   g135(.A(p31), .Y(new_n179_));
  AOI21x1_ASAP7_75t_R g136(.A1(p22), .A2(o1), .B(new_n133_), .Y(new_n180_));
  INVx1_ASAP7_75t_R   g137(.A(new_n126_), .Y(new_n181_));
  AOI21x1_ASAP7_75t_R g138(.A1(p20), .A2(o1), .B(new_n181_), .Y(new_n182_));
  AOI21x1_ASAP7_75t_R g139(.A1(new_n179_), .A2(new_n180_), .B(new_n182_), .Y(new_n183_));
  AO21x1_ASAP7_75t_R  g140(.A1(p7), .A2(o0), .B(new_n57_), .Y(new_n184_));
  AOI21x1_ASAP7_75t_R g141(.A1(p21), .A2(o1), .B(new_n184_), .Y(new_n185_));
  OAI21x1_ASAP7_75t_R g142(.A1(new_n120_), .A2(new_n183_), .B(new_n185_), .Y(new_n186_));
  INVx1_ASAP7_75t_R   g143(.A(new_n180_), .Y(new_n187_));
  AOI21x1_ASAP7_75t_R g144(.A1(p31), .A2(new_n136_), .B(new_n187_), .Y(new_n188_));
  OAI21x1_ASAP7_75t_R g145(.A1(new_n151_), .A2(new_n164_), .B(p31), .Y(new_n189_));
  NAND2x1_ASAP7_75t_R g146(.A(new_n188_), .B(new_n189_), .Y(new_n190_));
  OAI21x1_ASAP7_75t_R g147(.A1(new_n178_), .A2(new_n186_), .B(new_n190_), .Y(new_n191_));
  NOR2x1_ASAP7_75t_R  g148(.A(new_n177_), .B(new_n191_), .Y(new_n192_));
  OA21x2_ASAP7_75t_R  g149(.A1(new_n151_), .A2(new_n164_), .B(p26), .Y(new_n193_));
  AO21x1_ASAP7_75t_R  g150(.A1(p17), .A2(o1), .B(new_n155_), .Y(new_n194_));
  AO21x1_ASAP7_75t_R  g151(.A1(p26), .A2(new_n136_), .B(new_n194_), .Y(new_n195_));
  AND2x2_ASAP7_75t_R  g152(.A(new_n142_), .B(new_n144_), .Y(new_n196_));
  INVx1_ASAP7_75t_R   g153(.A(new_n196_), .Y(new_n197_));
  AOI21x1_ASAP7_75t_R g154(.A1(p28), .A2(new_n136_), .B(new_n197_), .Y(new_n198_));
  OAI21x1_ASAP7_75t_R g155(.A1(new_n151_), .A2(new_n164_), .B(p28), .Y(new_n199_));
  NAND2x1_ASAP7_75t_R g156(.A(new_n198_), .B(new_n199_), .Y(new_n200_));
  OAI21x1_ASAP7_75t_R g157(.A1(new_n193_), .A2(new_n195_), .B(new_n200_), .Y(new_n201_));
  NAND2x1_ASAP7_75t_R g158(.A(new_n135_), .B(new_n122_), .Y(new_n202_));
  NAND2x1_ASAP7_75t_R g159(.A(new_n125_), .B(new_n127_), .Y(new_n203_));
  AOI21x1_ASAP7_75t_R g160(.A1(p29), .A2(new_n202_), .B(new_n203_), .Y(new_n204_));
  OAI21x1_ASAP7_75t_R g161(.A1(new_n151_), .A2(new_n164_), .B(p29), .Y(new_n205_));
  NAND2x1_ASAP7_75t_R g162(.A(new_n204_), .B(new_n205_), .Y(new_n206_));
  AO21x1_ASAP7_75t_R  g163(.A1(p1), .A2(o0), .B(new_n54_), .Y(new_n207_));
  AO21x1_ASAP7_75t_R  g164(.A1(p18), .A2(o1), .B(new_n207_), .Y(new_n208_));
  AOI21x1_ASAP7_75t_R g165(.A1(p27), .A2(new_n136_), .B(new_n208_), .Y(new_n209_));
  OAI21x1_ASAP7_75t_R g166(.A1(new_n151_), .A2(new_n164_), .B(p27), .Y(new_n210_));
  NAND2x1_ASAP7_75t_R g167(.A(new_n209_), .B(new_n210_), .Y(new_n211_));
  NAND2x1_ASAP7_75t_R g168(.A(new_n206_), .B(new_n211_), .Y(new_n212_));
  NOR2x1_ASAP7_75t_R  g169(.A(new_n201_), .B(new_n212_), .Y(new_n213_));
  AO21x1_ASAP7_75t_R  g170(.A1(p25), .A2(o1), .B(new_n138_), .Y(new_n214_));
  AOI21x1_ASAP7_75t_R g171(.A1(p34), .A2(o2), .B(new_n214_), .Y(new_n215_));
  AOI21x1_ASAP7_75t_R g172(.A1(new_n192_), .A2(new_n213_), .B(new_n215_), .Y(o3));
  INVx1_ASAP7_75t_R   g173(.A(new_n192_), .Y(o4));
  AOI21x1_ASAP7_75t_R g174(.A1(p32), .A2(new_n136_), .B(new_n168_), .Y(new_n218_));
  AOI21x1_ASAP7_75t_R g175(.A1(p18), .A2(o1), .B(new_n152_), .Y(new_n219_));
  AOI21x1_ASAP7_75t_R g176(.A1(new_n157_), .A2(new_n156_), .B(new_n219_), .Y(new_n220_));
  INVx1_ASAP7_75t_R   g177(.A(new_n149_), .Y(new_n221_));
  AOI21x1_ASAP7_75t_R g178(.A1(p23), .A2(o1), .B(new_n221_), .Y(new_n222_));
  AOI21x1_ASAP7_75t_R g179(.A1(new_n144_), .A2(new_n143_), .B(new_n222_), .Y(new_n223_));
  INVx1_ASAP7_75t_R   g180(.A(new_n139_), .Y(new_n224_));
  AOI21x1_ASAP7_75t_R g181(.A1(p25), .A2(o1), .B(new_n224_), .Y(new_n225_));
  NOR2x1_ASAP7_75t_R  g182(.A(new_n225_), .B(new_n171_), .Y(new_n226_));
  NAND3x1_ASAP7_75t_R g183(.A(new_n220_), .B(new_n223_), .C(new_n226_), .Y(new_n227_));
  NAND2x1_ASAP7_75t_R g184(.A(p32), .B(new_n227_), .Y(new_n228_));
  AOI21x1_ASAP7_75t_R g185(.A1(new_n218_), .A2(new_n228_), .B(new_n206_), .Y(new_n229_));
  AO21x1_ASAP7_75t_R  g186(.A1(new_n128_), .A2(new_n122_), .B(new_n179_), .Y(new_n230_));
  NAND2x1_ASAP7_75t_R g187(.A(new_n180_), .B(new_n230_), .Y(new_n231_));
  AOI21x1_ASAP7_75t_R g188(.A1(p31), .A2(new_n227_), .B(new_n231_), .Y(new_n232_));
  AOI21x1_ASAP7_75t_R g189(.A1(p30), .A2(new_n227_), .B(new_n186_), .Y(new_n233_));
  NOR2x1_ASAP7_75t_R  g190(.A(new_n232_), .B(new_n233_), .Y(new_n234_));
  NAND2x1_ASAP7_75t_R g191(.A(new_n229_), .B(new_n234_), .Y(new_n235_));
  INVx1_ASAP7_75t_R   g192(.A(new_n177_), .Y(new_n236_));
  OR3x1_ASAP7_75t_R   g193(.A(new_n232_), .B(new_n233_), .C(new_n200_), .Y(new_n237_));
  NAND3x1_ASAP7_75t_R g194(.A(new_n235_), .B(new_n236_), .C(new_n237_), .Y(o5));
  AOI21x1_ASAP7_75t_R g195(.A1(p32), .A2(new_n227_), .B(new_n169_), .Y(new_n239_));
  OA21x2_ASAP7_75t_R  g196(.A1(new_n190_), .A2(new_n239_), .B(new_n176_), .Y(new_n240_));
  NOR2x1_ASAP7_75t_R  g197(.A(new_n206_), .B(new_n233_), .Y(new_n241_));
  NAND3x1_ASAP7_75t_R g198(.A(new_n183_), .B(new_n122_), .C(new_n196_), .Y(new_n242_));
  OAI21x1_ASAP7_75t_R g199(.A1(new_n242_), .A2(new_n227_), .B(new_n145_), .Y(new_n243_));
  NOR2x1_ASAP7_75t_R  g200(.A(new_n211_), .B(new_n243_), .Y(new_n244_));
  NOR2x1_ASAP7_75t_R  g201(.A(new_n232_), .B(new_n239_), .Y(new_n245_));
  OAI21x1_ASAP7_75t_R g202(.A1(new_n241_), .A2(new_n244_), .B(new_n245_), .Y(new_n246_));
  NAND2x1_ASAP7_75t_R g203(.A(new_n240_), .B(new_n246_), .Y(o6));
endmodule


