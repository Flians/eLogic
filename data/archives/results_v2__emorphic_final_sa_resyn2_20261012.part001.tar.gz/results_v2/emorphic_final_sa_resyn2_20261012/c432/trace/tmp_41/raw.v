// Benchmark "/tmp/" written by ABC on Mon Oct 12 14:43:40 2026

module \/tmp/  ( 
    p27, p7, p31, p18, p26, p28, p5, p22, p1, p16, p34, p19, p17, p15, p14,
    p20, p3, p23, p2, p8, p13, p32, p9, p4, p30, p12, p6, p11, p29, p35,
    p33, p21, p25, p24, p0, p10,
    o0, o1, o2, o3, o4, o5, o6  );
  input  p27, p7, p31, p18, p26, p28, p5, p22, p1, p16, p34, p19, p17,
    p15, p14, p20, p3, p23, p2, p8, p13, p32, p9, p4, p30, p12, p6, p11,
    p29, p35, p33, p21, p25, p24, p0, p10;
  output o0, o1, o2, o3, o4, o5, o6;
  wire new_n44_, new_n45_, new_n46_, new_n47_, new_n48_, new_n49_, new_n50_,
    new_n51_, new_n52_, new_n53_, new_n54_, new_n55_, new_n56_, new_n57_,
    new_n58_, new_n59_, new_n60_, new_n61_, new_n62_, new_n63_, new_n64_,
    new_n66_, new_n67_, new_n68_, new_n69_, new_n70_, new_n71_, new_n72_,
    new_n73_, new_n74_, new_n75_, new_n76_, new_n77_, new_n78_, new_n79_,
    new_n80_, new_n81_, new_n82_, new_n83_, new_n84_, new_n85_, new_n86_,
    new_n87_, new_n88_, new_n89_, new_n90_, new_n91_, new_n92_, new_n93_,
    new_n94_, new_n95_, new_n96_, new_n97_, new_n99_, new_n100_, new_n101_,
    new_n102_, new_n103_, new_n104_, new_n105_, new_n106_, new_n107_,
    new_n108_, new_n109_, new_n110_, new_n111_, new_n112_, new_n113_,
    new_n114_, new_n115_, new_n116_, new_n117_, new_n118_, new_n119_,
    new_n120_, new_n121_, new_n122_, new_n123_, new_n124_, new_n125_,
    new_n126_, new_n127_, new_n128_, new_n129_, new_n130_, new_n131_,
    new_n132_, new_n133_, new_n134_, new_n135_, new_n136_, new_n137_,
    new_n138_, new_n139_, new_n140_, new_n141_, new_n142_, new_n143_,
    new_n144_, new_n145_, new_n146_, new_n147_, new_n148_, new_n149_,
    new_n150_, new_n151_, new_n152_, new_n153_, new_n154_, new_n155_,
    new_n156_, new_n157_, new_n158_, new_n159_, new_n160_, new_n161_,
    new_n162_, new_n163_, new_n164_, new_n165_, new_n166_, new_n167_,
    new_n168_, new_n169_, new_n170_, new_n171_, new_n172_, new_n174_,
    new_n175_, new_n176_, new_n177_, new_n178_, new_n179_, new_n180_,
    new_n181_, new_n182_, new_n183_, new_n184_, new_n185_, new_n186_,
    new_n187_, new_n188_, new_n189_, new_n190_, new_n191_, new_n192_,
    new_n193_, new_n194_, new_n195_, new_n196_, new_n197_, new_n198_,
    new_n199_, new_n200_, new_n201_, new_n202_, new_n203_, new_n204_,
    new_n205_, new_n206_, new_n207_, new_n208_, new_n209_, new_n210_,
    new_n211_, new_n212_, new_n213_, new_n214_, new_n215_, new_n216_,
    new_n217_, new_n218_, new_n219_, new_n220_, new_n221_, new_n222_,
    new_n223_, new_n224_, new_n225_, new_n226_, new_n227_, new_n228_,
    new_n229_, new_n230_, new_n231_, new_n232_, new_n233_, new_n234_,
    new_n235_, new_n236_, new_n237_, new_n238_, new_n239_, new_n240_,
    new_n241_, new_n242_, new_n243_, new_n246_, new_n247_, new_n248_,
    new_n249_, new_n250_, new_n251_, new_n252_, new_n253_, new_n254_,
    new_n255_, new_n256_, new_n257_, new_n258_, new_n260_, new_n261_,
    new_n262_;
  INVx1_ASAP7_75t_R   g000(.A(p12), .Y(new_n44_));
  INVx1_ASAP7_75t_R   g001(.A(p3), .Y(new_n45_));
  NAND2x1_ASAP7_75t_R g002(.A(p4), .B(new_n45_), .Y(new_n46_));
  OAI21x1_ASAP7_75t_R g003(.A1(new_n44_), .A2(p11), .B(new_n46_), .Y(new_n47_));
  INVx1_ASAP7_75t_R   g004(.A(p14), .Y(new_n48_));
  INVx1_ASAP7_75t_R   g005(.A(p15), .Y(new_n49_));
  NAND2x1_ASAP7_75t_R g006(.A(p16), .B(new_n49_), .Y(new_n50_));
  OAI21x1_ASAP7_75t_R g007(.A1(new_n48_), .A2(p13), .B(new_n50_), .Y(new_n51_));
  NOR2x1_ASAP7_75t_R  g008(.A(new_n47_), .B(new_n51_), .Y(new_n52_));
  INVx1_ASAP7_75t_R   g009(.A(p0), .Y(new_n53_));
  NOR2x1_ASAP7_75t_R  g010(.A(p35), .B(new_n53_), .Y(new_n54_));
  INVx1_ASAP7_75t_R   g011(.A(p2), .Y(new_n55_));
  NOR2x1_ASAP7_75t_R  g012(.A(p1), .B(new_n55_), .Y(new_n56_));
  NOR2x1_ASAP7_75t_R  g013(.A(new_n54_), .B(new_n56_), .Y(new_n57_));
  INVx1_ASAP7_75t_R   g014(.A(p5), .Y(new_n58_));
  NAND2x1_ASAP7_75t_R g015(.A(p6), .B(new_n58_), .Y(new_n59_));
  INVx1_ASAP7_75t_R   g016(.A(p9), .Y(new_n60_));
  NAND2x1_ASAP7_75t_R g017(.A(p10), .B(new_n60_), .Y(new_n61_));
  INVx1_ASAP7_75t_R   g018(.A(p7), .Y(new_n62_));
  NAND2x1_ASAP7_75t_R g019(.A(p8), .B(new_n62_), .Y(new_n63_));
  AND3x1_ASAP7_75t_R  g020(.A(new_n59_), .B(new_n61_), .C(new_n63_), .Y(new_n64_));
  NAND3x1_ASAP7_75t_R g021(.A(new_n52_), .B(new_n57_), .C(new_n64_), .Y(o0));
  INVx1_ASAP7_75t_R   g022(.A(p19), .Y(new_n66_));
  NAND2x1_ASAP7_75t_R g023(.A(p4), .B(new_n66_), .Y(new_n67_));
  AOI21x1_ASAP7_75t_R g024(.A1(new_n46_), .A2(o0), .B(new_n67_), .Y(new_n68_));
  INVx1_ASAP7_75t_R   g025(.A(p23), .Y(new_n69_));
  NAND2x1_ASAP7_75t_R g026(.A(p12), .B(new_n69_), .Y(new_n70_));
  AOI21x1_ASAP7_75t_R g027(.A1(p11), .A2(o0), .B(new_n70_), .Y(new_n71_));
  OR2x4_ASAP7_75t_R   g028(.A(p18), .B(new_n55_), .Y(new_n72_));
  AOI21x1_ASAP7_75t_R g029(.A1(p1), .A2(o0), .B(new_n72_), .Y(new_n73_));
  NOR3x1_ASAP7_75t_R  g030(.A(new_n68_), .B(new_n71_), .C(new_n73_), .Y(new_n74_));
  NOR2x1_ASAP7_75t_R  g031(.A(p17), .B(new_n53_), .Y(new_n75_));
  INVx1_ASAP7_75t_R   g032(.A(new_n75_), .Y(new_n76_));
  AOI21x1_ASAP7_75t_R g033(.A1(p35), .A2(o0), .B(new_n76_), .Y(new_n77_));
  INVx1_ASAP7_75t_R   g034(.A(p24), .Y(new_n78_));
  NAND2x1_ASAP7_75t_R g035(.A(p14), .B(new_n78_), .Y(new_n79_));
  AOI21x1_ASAP7_75t_R g036(.A1(p13), .A2(o0), .B(new_n79_), .Y(new_n80_));
  INVx1_ASAP7_75t_R   g037(.A(p16), .Y(new_n81_));
  NOR2x1_ASAP7_75t_R  g038(.A(p25), .B(new_n81_), .Y(new_n82_));
  INVx1_ASAP7_75t_R   g039(.A(new_n82_), .Y(new_n83_));
  AOI21x1_ASAP7_75t_R g040(.A1(p15), .A2(o0), .B(new_n83_), .Y(new_n84_));
  NOR3x1_ASAP7_75t_R  g041(.A(new_n77_), .B(new_n80_), .C(new_n84_), .Y(new_n85_));
  INVx1_ASAP7_75t_R   g042(.A(p22), .Y(new_n86_));
  NAND2x1_ASAP7_75t_R g043(.A(p10), .B(new_n86_), .Y(new_n87_));
  AOI21x1_ASAP7_75t_R g044(.A1(p9), .A2(o0), .B(new_n87_), .Y(new_n88_));
  INVx1_ASAP7_75t_R   g045(.A(p6), .Y(new_n89_));
  NOR2x1_ASAP7_75t_R  g046(.A(p20), .B(new_n89_), .Y(new_n90_));
  INVx1_ASAP7_75t_R   g047(.A(new_n90_), .Y(new_n91_));
  AOI21x1_ASAP7_75t_R g048(.A1(p5), .A2(o0), .B(new_n91_), .Y(new_n92_));
  INVx1_ASAP7_75t_R   g049(.A(p8), .Y(new_n93_));
  NOR2x1_ASAP7_75t_R  g050(.A(p21), .B(new_n93_), .Y(new_n94_));
  INVx1_ASAP7_75t_R   g051(.A(new_n94_), .Y(new_n95_));
  AOI21x1_ASAP7_75t_R g052(.A1(p7), .A2(o0), .B(new_n95_), .Y(new_n96_));
  NOR3x1_ASAP7_75t_R  g053(.A(new_n88_), .B(new_n92_), .C(new_n96_), .Y(new_n97_));
  NAND3x1_ASAP7_75t_R g054(.A(new_n74_), .B(new_n85_), .C(new_n97_), .Y(o1));
  NOR2x1_ASAP7_75t_R  g055(.A(p29), .B(new_n89_), .Y(new_n99_));
  NOR2x1_ASAP7_75t_R  g056(.A(p11), .B(new_n44_), .Y(new_n100_));
  INVx1_ASAP7_75t_R   g057(.A(p4), .Y(new_n101_));
  NOR2x1_ASAP7_75t_R  g058(.A(p3), .B(new_n101_), .Y(new_n102_));
  NOR2x1_ASAP7_75t_R  g059(.A(new_n100_), .B(new_n102_), .Y(new_n103_));
  NOR2x1_ASAP7_75t_R  g060(.A(p13), .B(new_n48_), .Y(new_n104_));
  AOI21x1_ASAP7_75t_R g061(.A1(p16), .A2(new_n49_), .B(new_n104_), .Y(new_n105_));
  NAND2x1_ASAP7_75t_R g062(.A(new_n103_), .B(new_n105_), .Y(new_n106_));
  INVx1_ASAP7_75t_R   g063(.A(p10), .Y(new_n107_));
  NOR2x1_ASAP7_75t_R  g064(.A(p9), .B(new_n107_), .Y(new_n108_));
  AOI21x1_ASAP7_75t_R g065(.A1(new_n62_), .A2(p8), .B(new_n108_), .Y(new_n109_));
  NAND3x1_ASAP7_75t_R g066(.A(new_n109_), .B(new_n57_), .C(new_n59_), .Y(new_n110_));
  OAI21x1_ASAP7_75t_R g067(.A1(new_n106_), .A2(new_n110_), .B(p5), .Y(new_n111_));
  NAND2x1_ASAP7_75t_R g068(.A(new_n99_), .B(new_n111_), .Y(new_n112_));
  AOI21x1_ASAP7_75t_R g069(.A1(p20), .A2(o1), .B(new_n112_), .Y(new_n113_));
  AO21x1_ASAP7_75t_R  g070(.A1(p7), .A2(o0), .B(new_n93_), .Y(new_n114_));
  NOR2x1_ASAP7_75t_R  g071(.A(p30), .B(new_n114_), .Y(new_n115_));
  INVx1_ASAP7_75t_R   g072(.A(new_n115_), .Y(new_n116_));
  AOI21x1_ASAP7_75t_R g073(.A1(p21), .A2(o1), .B(new_n116_), .Y(new_n117_));
  INVx1_ASAP7_75t_R   g074(.A(p31), .Y(new_n118_));
  NOR2x1_ASAP7_75t_R  g075(.A(new_n106_), .B(new_n110_), .Y(new_n119_));
  AO21x1_ASAP7_75t_R  g076(.A1(p10), .A2(new_n119_), .B(new_n108_), .Y(new_n120_));
  NAND2x1_ASAP7_75t_R g077(.A(new_n118_), .B(new_n120_), .Y(new_n121_));
  AOI21x1_ASAP7_75t_R g078(.A1(p22), .A2(o1), .B(new_n121_), .Y(new_n122_));
  OR3x1_ASAP7_75t_R   g079(.A(new_n113_), .B(new_n117_), .C(new_n122_), .Y(new_n123_));
  INVx1_ASAP7_75t_R   g080(.A(p27), .Y(new_n124_));
  OA21x2_ASAP7_75t_R  g081(.A1(new_n106_), .A2(new_n110_), .B(p11), .Y(new_n125_));
  AO21x1_ASAP7_75t_R  g082(.A1(p1), .A2(o0), .B(new_n72_), .Y(new_n126_));
  OAI21x1_ASAP7_75t_R g083(.A1(new_n125_), .A2(new_n70_), .B(new_n126_), .Y(new_n127_));
  AO21x1_ASAP7_75t_R  g084(.A1(p1), .A2(o0), .B(new_n55_), .Y(new_n128_));
  NOR3x1_ASAP7_75t_R  g085(.A(new_n127_), .B(new_n68_), .C(new_n128_), .Y(new_n129_));
  AO21x1_ASAP7_75t_R  g086(.A1(p13), .A2(o0), .B(new_n79_), .Y(new_n130_));
  NAND2x1_ASAP7_75t_R g087(.A(new_n103_), .B(new_n57_), .Y(new_n131_));
  OAI21x1_ASAP7_75t_R g088(.A1(new_n51_), .A2(new_n131_), .B(p35), .Y(new_n132_));
  INVx1_ASAP7_75t_R   g089(.A(p35), .Y(new_n133_));
  AO21x1_ASAP7_75t_R  g090(.A1(new_n59_), .A2(new_n109_), .B(new_n133_), .Y(new_n134_));
  NAND3x1_ASAP7_75t_R g091(.A(new_n132_), .B(new_n134_), .C(new_n75_), .Y(new_n135_));
  OAI21x1_ASAP7_75t_R g092(.A1(new_n51_), .A2(new_n131_), .B(p15), .Y(new_n136_));
  AO21x1_ASAP7_75t_R  g093(.A1(new_n59_), .A2(new_n109_), .B(new_n49_), .Y(new_n137_));
  NAND3x1_ASAP7_75t_R g094(.A(new_n136_), .B(new_n137_), .C(new_n82_), .Y(new_n138_));
  NAND3x1_ASAP7_75t_R g095(.A(new_n130_), .B(new_n135_), .C(new_n138_), .Y(new_n139_));
  AO21x1_ASAP7_75t_R  g096(.A1(p9), .A2(o0), .B(new_n87_), .Y(new_n140_));
  NAND2x1_ASAP7_75t_R g097(.A(new_n90_), .B(new_n111_), .Y(new_n141_));
  OAI21x1_ASAP7_75t_R g098(.A1(new_n51_), .A2(new_n131_), .B(p7), .Y(new_n142_));
  AO21x1_ASAP7_75t_R  g099(.A1(new_n59_), .A2(new_n109_), .B(new_n62_), .Y(new_n143_));
  NAND3x1_ASAP7_75t_R g100(.A(new_n142_), .B(new_n143_), .C(new_n94_), .Y(new_n144_));
  NAND3x1_ASAP7_75t_R g101(.A(new_n140_), .B(new_n141_), .C(new_n144_), .Y(new_n145_));
  NOR2x1_ASAP7_75t_R  g102(.A(new_n139_), .B(new_n145_), .Y(new_n146_));
  AO21x1_ASAP7_75t_R  g103(.A1(new_n129_), .A2(new_n146_), .B(new_n73_), .Y(new_n147_));
  AO21x1_ASAP7_75t_R  g104(.A1(p11), .A2(o0), .B(new_n44_), .Y(new_n148_));
  NOR2x1_ASAP7_75t_R  g105(.A(p32), .B(new_n148_), .Y(new_n149_));
  INVx1_ASAP7_75t_R   g106(.A(new_n149_), .Y(new_n150_));
  AOI21x1_ASAP7_75t_R g107(.A1(p23), .A2(o1), .B(new_n150_), .Y(new_n151_));
  AOI21x1_ASAP7_75t_R g108(.A1(new_n124_), .A2(new_n147_), .B(new_n151_), .Y(new_n152_));
  NAND2x1_ASAP7_75t_R g109(.A(new_n137_), .B(new_n136_), .Y(new_n153_));
  OR3x1_ASAP7_75t_R   g110(.A(new_n153_), .B(new_n81_), .C(p34), .Y(new_n154_));
  AOI21x1_ASAP7_75t_R g111(.A1(p25), .A2(o1), .B(new_n154_), .Y(new_n155_));
  INVx1_ASAP7_75t_R   g112(.A(p28), .Y(new_n156_));
  AO21x1_ASAP7_75t_R  g113(.A1(p4), .A2(new_n119_), .B(new_n102_), .Y(new_n157_));
  NAND2x1_ASAP7_75t_R g114(.A(new_n156_), .B(new_n157_), .Y(new_n158_));
  AOI21x1_ASAP7_75t_R g115(.A1(p19), .A2(o1), .B(new_n158_), .Y(new_n159_));
  NOR2x1_ASAP7_75t_R  g116(.A(new_n155_), .B(new_n159_), .Y(new_n160_));
  NAND2x1_ASAP7_75t_R g117(.A(p17), .B(o1), .Y(new_n161_));
  NAND2x1_ASAP7_75t_R g118(.A(p35), .B(o0), .Y(new_n162_));
  INVx1_ASAP7_75t_R   g119(.A(p26), .Y(new_n163_));
  AND3x1_ASAP7_75t_R  g120(.A(new_n162_), .B(new_n163_), .C(p0), .Y(new_n164_));
  AOI21x1_ASAP7_75t_R g121(.A1(new_n85_), .A2(new_n97_), .B(new_n78_), .Y(new_n165_));
  NOR2x1_ASAP7_75t_R  g122(.A(new_n78_), .B(new_n74_), .Y(new_n166_));
  OA21x2_ASAP7_75t_R  g123(.A1(new_n106_), .A2(new_n110_), .B(p13), .Y(new_n167_));
  OR3x1_ASAP7_75t_R   g124(.A(new_n167_), .B(new_n48_), .C(p33), .Y(new_n168_));
  NOR3x1_ASAP7_75t_R  g125(.A(new_n165_), .B(new_n166_), .C(new_n168_), .Y(new_n169_));
  AOI21x1_ASAP7_75t_R g126(.A1(new_n161_), .A2(new_n164_), .B(new_n169_), .Y(new_n170_));
  NAND3x1_ASAP7_75t_R g127(.A(new_n152_), .B(new_n160_), .C(new_n170_), .Y(new_n171_));
  NOR2x1_ASAP7_75t_R  g128(.A(new_n123_), .B(new_n171_), .Y(new_n172_));
  INVx1_ASAP7_75t_R   g129(.A(new_n172_), .Y(o2));
  NOR3x1_ASAP7_75t_R  g130(.A(new_n113_), .B(new_n117_), .C(new_n122_), .Y(new_n174_));
  AO21x1_ASAP7_75t_R  g131(.A1(new_n46_), .A2(o0), .B(new_n67_), .Y(new_n175_));
  AO21x1_ASAP7_75t_R  g132(.A1(p11), .A2(o0), .B(new_n70_), .Y(new_n176_));
  NAND3x1_ASAP7_75t_R g133(.A(new_n175_), .B(new_n176_), .C(new_n126_), .Y(new_n177_));
  NOR3x1_ASAP7_75t_R  g134(.A(new_n177_), .B(new_n139_), .C(new_n145_), .Y(new_n178_));
  OA21x2_ASAP7_75t_R  g135(.A1(new_n66_), .A2(new_n178_), .B(new_n157_), .Y(new_n179_));
  OAI21x1_ASAP7_75t_R g136(.A1(new_n156_), .A2(new_n174_), .B(new_n179_), .Y(new_n180_));
  NAND2x1_ASAP7_75t_R g137(.A(new_n138_), .B(new_n144_), .Y(new_n181_));
  NOR3x1_ASAP7_75t_R  g138(.A(new_n181_), .B(new_n88_), .C(new_n92_), .Y(new_n182_));
  OAI21x1_ASAP7_75t_R g139(.A1(new_n167_), .A2(new_n79_), .B(new_n135_), .Y(new_n183_));
  NOR3x1_ASAP7_75t_R  g140(.A(new_n127_), .B(new_n183_), .C(new_n68_), .Y(new_n184_));
  INVx1_ASAP7_75t_R   g141(.A(p25), .Y(new_n185_));
  AOI21x1_ASAP7_75t_R g142(.A1(new_n182_), .A2(new_n184_), .B(new_n185_), .Y(new_n186_));
  OAI21x1_ASAP7_75t_R g143(.A1(new_n139_), .A2(new_n145_), .B(p24), .Y(new_n187_));
  NAND2x1_ASAP7_75t_R g144(.A(p24), .B(new_n177_), .Y(new_n188_));
  INVx1_ASAP7_75t_R   g145(.A(new_n168_), .Y(new_n189_));
  NAND3x1_ASAP7_75t_R g146(.A(new_n187_), .B(new_n188_), .C(new_n189_), .Y(new_n190_));
  OAI21x1_ASAP7_75t_R g147(.A1(new_n154_), .A2(new_n186_), .B(new_n190_), .Y(new_n191_));
  INVx1_ASAP7_75t_R   g148(.A(new_n191_), .Y(new_n192_));
  AOI21x1_ASAP7_75t_R g149(.A1(new_n129_), .A2(new_n146_), .B(new_n73_), .Y(new_n193_));
  OAI21x1_ASAP7_75t_R g150(.A1(new_n139_), .A2(new_n145_), .B(p17), .Y(new_n194_));
  NAND2x1_ASAP7_75t_R g151(.A(p17), .B(new_n177_), .Y(new_n195_));
  NAND3x1_ASAP7_75t_R g152(.A(new_n194_), .B(new_n195_), .C(new_n164_), .Y(new_n196_));
  OAI21x1_ASAP7_75t_R g153(.A1(p27), .A2(new_n193_), .B(new_n196_), .Y(new_n197_));
  AOI21x1_ASAP7_75t_R g154(.A1(new_n182_), .A2(new_n184_), .B(new_n66_), .Y(new_n198_));
  OAI21x1_ASAP7_75t_R g155(.A1(new_n69_), .A2(new_n178_), .B(new_n149_), .Y(new_n199_));
  OAI21x1_ASAP7_75t_R g156(.A1(new_n198_), .A2(new_n158_), .B(new_n199_), .Y(new_n200_));
  NOR2x1_ASAP7_75t_R  g157(.A(new_n197_), .B(new_n200_), .Y(new_n201_));
  AOI21x1_ASAP7_75t_R g158(.A1(new_n192_), .A2(new_n201_), .B(new_n156_), .Y(new_n202_));
  NAND2x1_ASAP7_75t_R g159(.A(p6), .B(new_n111_), .Y(new_n203_));
  AO21x1_ASAP7_75t_R  g160(.A1(p20), .A2(o1), .B(new_n203_), .Y(new_n204_));
  NOR2x1_ASAP7_75t_R  g161(.A(new_n86_), .B(new_n178_), .Y(new_n205_));
  INVx1_ASAP7_75t_R   g162(.A(p21), .Y(new_n206_));
  OAI21x1_ASAP7_75t_R g163(.A1(new_n206_), .A2(new_n178_), .B(new_n115_), .Y(new_n207_));
  OAI21x1_ASAP7_75t_R g164(.A1(new_n121_), .A2(new_n205_), .B(new_n207_), .Y(new_n208_));
  NOR2x1_ASAP7_75t_R  g165(.A(new_n204_), .B(new_n208_), .Y(new_n209_));
  NOR3x1_ASAP7_75t_R  g166(.A(new_n200_), .B(new_n197_), .C(new_n191_), .Y(new_n210_));
  AOI21x1_ASAP7_75t_R g167(.A1(new_n209_), .A2(new_n210_), .B(new_n113_), .Y(new_n211_));
  OAI21x1_ASAP7_75t_R g168(.A1(new_n180_), .A2(new_n202_), .B(new_n211_), .Y(new_n212_));
  AND3x1_ASAP7_75t_R  g169(.A(new_n161_), .B(p0), .C(new_n162_), .Y(new_n213_));
  OAI21x1_ASAP7_75t_R g170(.A1(new_n163_), .A2(new_n174_), .B(new_n213_), .Y(new_n214_));
  NOR2x1_ASAP7_75t_R  g171(.A(new_n163_), .B(new_n210_), .Y(new_n215_));
  NOR3x1_ASAP7_75t_R  g172(.A(new_n208_), .B(new_n113_), .C(new_n193_), .Y(new_n216_));
  NOR2x1_ASAP7_75t_R  g173(.A(p27), .B(new_n193_), .Y(new_n217_));
  AOI21x1_ASAP7_75t_R g174(.A1(new_n210_), .A2(new_n216_), .B(new_n217_), .Y(new_n218_));
  OAI21x1_ASAP7_75t_R g175(.A1(new_n214_), .A2(new_n215_), .B(new_n218_), .Y(new_n219_));
  NOR2x1_ASAP7_75t_R  g176(.A(new_n212_), .B(new_n219_), .Y(new_n220_));
  INVx1_ASAP7_75t_R   g177(.A(p30), .Y(new_n221_));
  AOI21x1_ASAP7_75t_R g178(.A1(new_n192_), .A2(new_n201_), .B(new_n221_), .Y(new_n222_));
  AOI21x1_ASAP7_75t_R g179(.A1(p21), .A2(o1), .B(new_n114_), .Y(new_n223_));
  OAI21x1_ASAP7_75t_R g180(.A1(new_n221_), .A2(new_n174_), .B(new_n223_), .Y(new_n224_));
  INVx1_ASAP7_75t_R   g181(.A(new_n120_), .Y(new_n225_));
  AO21x1_ASAP7_75t_R  g182(.A1(p22), .A2(o1), .B(new_n225_), .Y(new_n226_));
  AO21x1_ASAP7_75t_R  g183(.A1(p20), .A2(o1), .B(new_n112_), .Y(new_n227_));
  AOI21x1_ASAP7_75t_R g184(.A1(new_n207_), .A2(new_n227_), .B(new_n118_), .Y(new_n228_));
  NOR2x1_ASAP7_75t_R  g185(.A(new_n226_), .B(new_n228_), .Y(new_n229_));
  OAI21x1_ASAP7_75t_R g186(.A1(new_n118_), .A2(new_n210_), .B(new_n229_), .Y(new_n230_));
  OAI21x1_ASAP7_75t_R g187(.A1(new_n222_), .A2(new_n224_), .B(new_n230_), .Y(new_n231_));
  INVx1_ASAP7_75t_R   g188(.A(p32), .Y(new_n232_));
  AOI21x1_ASAP7_75t_R g189(.A1(p23), .A2(o1), .B(new_n148_), .Y(new_n233_));
  OAI21x1_ASAP7_75t_R g190(.A1(new_n232_), .A2(new_n174_), .B(new_n233_), .Y(new_n234_));
  NOR2x1_ASAP7_75t_R  g191(.A(new_n232_), .B(new_n210_), .Y(new_n235_));
  AO21x1_ASAP7_75t_R  g192(.A1(p13), .A2(o0), .B(new_n48_), .Y(new_n236_));
  OR3x1_ASAP7_75t_R   g193(.A(new_n165_), .B(new_n166_), .C(new_n236_), .Y(new_n237_));
  NOR3x1_ASAP7_75t_R  g194(.A(new_n208_), .B(new_n113_), .C(new_n237_), .Y(new_n238_));
  AOI21x1_ASAP7_75t_R g195(.A1(new_n210_), .A2(new_n238_), .B(new_n169_), .Y(new_n239_));
  OAI21x1_ASAP7_75t_R g196(.A1(new_n234_), .A2(new_n235_), .B(new_n239_), .Y(new_n240_));
  NOR2x1_ASAP7_75t_R  g197(.A(new_n231_), .B(new_n240_), .Y(new_n241_));
  NOR3x1_ASAP7_75t_R  g198(.A(new_n186_), .B(new_n81_), .C(new_n153_), .Y(new_n242_));
  AO21x1_ASAP7_75t_R  g199(.A1(new_n242_), .A2(new_n172_), .B(new_n155_), .Y(new_n243_));
  AOI21x1_ASAP7_75t_R g200(.A1(new_n220_), .A2(new_n241_), .B(new_n243_), .Y(o3));
  INVx1_ASAP7_75t_R   g201(.A(new_n241_), .Y(o4));
  NAND2x1_ASAP7_75t_R g202(.A(new_n223_), .B(new_n174_), .Y(new_n246_));
  NOR2x1_ASAP7_75t_R  g203(.A(new_n171_), .B(new_n246_), .Y(new_n247_));
  NOR2x1_ASAP7_75t_R  g204(.A(new_n117_), .B(new_n122_), .Y(new_n248_));
  INVx1_ASAP7_75t_R   g205(.A(new_n226_), .Y(new_n249_));
  NAND3x1_ASAP7_75t_R g206(.A(new_n248_), .B(new_n249_), .C(new_n227_), .Y(new_n250_));
  OAI21x1_ASAP7_75t_R g207(.A1(new_n250_), .A2(new_n171_), .B(new_n248_), .Y(new_n251_));
  NOR2x1_ASAP7_75t_R  g208(.A(new_n247_), .B(new_n251_), .Y(new_n252_));
  NAND3x1_ASAP7_75t_R g209(.A(new_n248_), .B(new_n227_), .C(new_n233_), .Y(new_n253_));
  OAI21x1_ASAP7_75t_R g210(.A1(new_n253_), .A2(new_n171_), .B(new_n199_), .Y(new_n254_));
  NOR2x1_ASAP7_75t_R  g211(.A(new_n211_), .B(new_n254_), .Y(new_n255_));
  NAND2x1_ASAP7_75t_R g212(.A(new_n252_), .B(new_n255_), .Y(new_n256_));
  AOI21x1_ASAP7_75t_R g213(.A1(p28), .A2(new_n171_), .B(new_n180_), .Y(new_n257_));
  AOI21x1_ASAP7_75t_R g214(.A1(new_n257_), .A2(new_n252_), .B(new_n240_), .Y(new_n258_));
  NAND2x1_ASAP7_75t_R g215(.A(new_n256_), .B(new_n258_), .Y(o5));
  OA21x2_ASAP7_75t_R  g216(.A1(new_n218_), .A2(new_n257_), .B(new_n230_), .Y(new_n260_));
  INVx1_ASAP7_75t_R   g217(.A(new_n239_), .Y(new_n261_));
  AOI21x1_ASAP7_75t_R g218(.A1(new_n252_), .A2(new_n255_), .B(new_n261_), .Y(new_n262_));
  OAI21x1_ASAP7_75t_R g219(.A1(new_n254_), .A2(new_n260_), .B(new_n262_), .Y(o6));
endmodule


