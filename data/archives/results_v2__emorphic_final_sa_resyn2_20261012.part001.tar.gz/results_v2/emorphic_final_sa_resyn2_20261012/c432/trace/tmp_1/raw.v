// Benchmark "/tmp/" written by ABC on Mon Oct 12 14:43:37 2026

module \/tmp/  ( 
    p29, p30, p7, p18, p25, p23, p17, p26, p34, p6, p0, p19, p13, p4, p12,
    p10, p33, p28, p14, p15, p3, p24, p2, p22, p20, p1, p21, p16, p5, p32,
    p8, p31, p11, p27, p9, p35,
    o0, o1, o2, o3, o4, o5, o6  );
  input  p29, p30, p7, p18, p25, p23, p17, p26, p34, p6, p0, p19, p13,
    p4, p12, p10, p33, p28, p14, p15, p3, p24, p2, p22, p20, p1, p21, p16,
    p5, p32, p8, p31, p11, p27, p9, p35;
  output o0, o1, o2, o3, o4, o5, o6;
  wire new_n44_, new_n45_, new_n46_, new_n47_, new_n48_, new_n49_, new_n50_,
    new_n51_, new_n52_, new_n53_, new_n54_, new_n55_, new_n56_, new_n57_,
    new_n58_, new_n59_, new_n60_, new_n61_, new_n62_, new_n63_, new_n64_,
    new_n66_, new_n67_, new_n68_, new_n69_, new_n70_, new_n71_, new_n72_,
    new_n73_, new_n74_, new_n75_, new_n76_, new_n77_, new_n78_, new_n79_,
    new_n80_, new_n81_, new_n82_, new_n83_, new_n84_, new_n85_, new_n86_,
    new_n87_, new_n88_, new_n89_, new_n90_, new_n91_, new_n92_, new_n93_,
    new_n94_, new_n95_, new_n96_, new_n97_, new_n98_, new_n99_, new_n100_,
    new_n101_, new_n102_, new_n103_, new_n104_, new_n106_, new_n107_,
    new_n108_, new_n109_, new_n110_, new_n111_, new_n112_, new_n113_,
    new_n114_, new_n115_, new_n116_, new_n117_, new_n118_, new_n119_,
    new_n120_, new_n121_, new_n122_, new_n123_, new_n124_, new_n125_,
    new_n126_, new_n127_, new_n128_, new_n129_, new_n130_, new_n131_,
    new_n132_, new_n133_, new_n134_, new_n135_, new_n136_, new_n137_,
    new_n138_, new_n139_, new_n140_, new_n141_, new_n142_, new_n143_,
    new_n144_, new_n145_, new_n146_, new_n147_, new_n148_, new_n149_,
    new_n150_, new_n151_, new_n152_, new_n153_, new_n154_, new_n155_,
    new_n156_, new_n157_, new_n158_, new_n159_, new_n160_, new_n161_,
    new_n162_, new_n164_, new_n165_, new_n166_, new_n167_, new_n168_,
    new_n169_, new_n170_, new_n171_, new_n172_, new_n173_, new_n174_,
    new_n175_, new_n176_, new_n177_, new_n178_, new_n179_, new_n180_,
    new_n181_, new_n182_, new_n183_, new_n184_, new_n185_, new_n186_,
    new_n187_, new_n188_, new_n189_, new_n190_, new_n191_, new_n192_,
    new_n193_, new_n194_, new_n195_, new_n196_, new_n197_, new_n198_,
    new_n199_, new_n200_, new_n201_, new_n202_, new_n203_, new_n204_,
    new_n205_, new_n206_, new_n207_, new_n210_, new_n211_, new_n212_,
    new_n213_, new_n214_, new_n215_, new_n216_, new_n217_, new_n218_,
    new_n219_, new_n220_, new_n221_, new_n222_, new_n223_, new_n224_,
    new_n225_, new_n226_, new_n227_, new_n228_, new_n229_, new_n230_,
    new_n231_, new_n233_, new_n234_, new_n235_, new_n236_, new_n237_,
    new_n238_;
  INVx1_ASAP7_75t_R   g000(.A(p12), .Y(new_n44_));
  INVx1_ASAP7_75t_R   g001(.A(p3), .Y(new_n45_));
  NAND2x1_ASAP7_75t_R g002(.A(p4), .B(new_n45_), .Y(new_n46_));
  OAI21x1_ASAP7_75t_R g003(.A1(new_n44_), .A2(p11), .B(new_n46_), .Y(new_n47_));
  INVx1_ASAP7_75t_R   g004(.A(p14), .Y(new_n48_));
  INVx1_ASAP7_75t_R   g005(.A(p15), .Y(new_n49_));
  NAND2x1_ASAP7_75t_R g006(.A(p16), .B(new_n49_), .Y(new_n50_));
  OAI21x1_ASAP7_75t_R g007(.A1(p13), .A2(new_n48_), .B(new_n50_), .Y(new_n51_));
  NOR2x1_ASAP7_75t_R  g008(.A(new_n47_), .B(new_n51_), .Y(new_n52_));
  INVx1_ASAP7_75t_R   g009(.A(p0), .Y(new_n53_));
  NOR2x1_ASAP7_75t_R  g010(.A(p35), .B(new_n53_), .Y(new_n54_));
  INVx1_ASAP7_75t_R   g011(.A(p2), .Y(new_n55_));
  NOR2x1_ASAP7_75t_R  g012(.A(p1), .B(new_n55_), .Y(new_n56_));
  NOR2x1_ASAP7_75t_R  g013(.A(new_n54_), .B(new_n56_), .Y(new_n57_));
  INVx1_ASAP7_75t_R   g014(.A(p9), .Y(new_n58_));
  NAND2x1_ASAP7_75t_R g015(.A(p10), .B(new_n58_), .Y(new_n59_));
  INVx1_ASAP7_75t_R   g016(.A(p7), .Y(new_n60_));
  NAND2x1_ASAP7_75t_R g017(.A(p8), .B(new_n60_), .Y(new_n61_));
  INVx1_ASAP7_75t_R   g018(.A(p5), .Y(new_n62_));
  NAND2x1_ASAP7_75t_R g019(.A(p6), .B(new_n62_), .Y(new_n63_));
  AND3x1_ASAP7_75t_R  g020(.A(new_n59_), .B(new_n61_), .C(new_n63_), .Y(new_n64_));
  NAND3x1_ASAP7_75t_R g021(.A(new_n52_), .B(new_n57_), .C(new_n64_), .Y(o0));
  NOR2x1_ASAP7_75t_R  g022(.A(p11), .B(new_n44_), .Y(new_n66_));
  AOI21x1_ASAP7_75t_R g023(.A1(p4), .A2(new_n45_), .B(new_n66_), .Y(new_n67_));
  OR2x4_ASAP7_75t_R   g024(.A(p13), .B(new_n48_), .Y(new_n68_));
  NAND3x1_ASAP7_75t_R g025(.A(new_n67_), .B(new_n68_), .C(new_n50_), .Y(new_n69_));
  INVx1_ASAP7_75t_R   g026(.A(p10), .Y(new_n70_));
  NOR2x1_ASAP7_75t_R  g027(.A(p9), .B(new_n70_), .Y(new_n71_));
  AOI21x1_ASAP7_75t_R g028(.A1(new_n60_), .A2(p8), .B(new_n71_), .Y(new_n72_));
  NAND3x1_ASAP7_75t_R g029(.A(new_n72_), .B(new_n57_), .C(new_n63_), .Y(new_n73_));
  OA21x2_ASAP7_75t_R  g030(.A1(new_n69_), .A2(new_n73_), .B(p35), .Y(new_n74_));
  INVx1_ASAP7_75t_R   g031(.A(p17), .Y(new_n75_));
  NAND2x1_ASAP7_75t_R g032(.A(p0), .B(new_n75_), .Y(new_n76_));
  NOR2x1_ASAP7_75t_R  g033(.A(p24), .B(new_n48_), .Y(new_n77_));
  OAI21x1_ASAP7_75t_R g034(.A1(new_n69_), .A2(new_n73_), .B(p13), .Y(new_n78_));
  NAND2x1_ASAP7_75t_R g035(.A(new_n77_), .B(new_n78_), .Y(new_n79_));
  OAI21x1_ASAP7_75t_R g036(.A1(new_n74_), .A2(new_n76_), .B(new_n79_), .Y(new_n80_));
  OA21x2_ASAP7_75t_R  g037(.A1(new_n69_), .A2(new_n73_), .B(p7), .Y(new_n81_));
  INVx1_ASAP7_75t_R   g038(.A(p8), .Y(new_n82_));
  OR2x4_ASAP7_75t_R   g039(.A(p21), .B(new_n82_), .Y(new_n83_));
  INVx1_ASAP7_75t_R   g040(.A(p16), .Y(new_n84_));
  NOR2x1_ASAP7_75t_R  g041(.A(p25), .B(new_n84_), .Y(new_n85_));
  OAI21x1_ASAP7_75t_R g042(.A1(new_n69_), .A2(new_n73_), .B(p15), .Y(new_n86_));
  NAND2x1_ASAP7_75t_R g043(.A(new_n85_), .B(new_n86_), .Y(new_n87_));
  OAI21x1_ASAP7_75t_R g044(.A1(new_n81_), .A2(new_n83_), .B(new_n87_), .Y(new_n88_));
  NOR2x1_ASAP7_75t_R  g045(.A(new_n80_), .B(new_n88_), .Y(new_n89_));
  OR2x4_ASAP7_75t_R   g046(.A(p18), .B(new_n55_), .Y(new_n90_));
  AO21x1_ASAP7_75t_R  g047(.A1(p1), .A2(o0), .B(new_n90_), .Y(new_n91_));
  INVx1_ASAP7_75t_R   g048(.A(p19), .Y(new_n92_));
  NAND2x1_ASAP7_75t_R g049(.A(p4), .B(new_n92_), .Y(new_n93_));
  AO21x1_ASAP7_75t_R  g050(.A1(new_n46_), .A2(o0), .B(new_n93_), .Y(new_n94_));
  INVx1_ASAP7_75t_R   g051(.A(p23), .Y(new_n95_));
  NAND2x1_ASAP7_75t_R g052(.A(p12), .B(new_n95_), .Y(new_n96_));
  AO21x1_ASAP7_75t_R  g053(.A1(p11), .A2(o0), .B(new_n96_), .Y(new_n97_));
  AND3x1_ASAP7_75t_R  g054(.A(new_n91_), .B(new_n94_), .C(new_n97_), .Y(new_n98_));
  INVx1_ASAP7_75t_R   g055(.A(p6), .Y(new_n99_));
  NOR2x1_ASAP7_75t_R  g056(.A(p20), .B(new_n99_), .Y(new_n100_));
  NAND2x1_ASAP7_75t_R g057(.A(p5), .B(o0), .Y(new_n101_));
  OR2x4_ASAP7_75t_R   g058(.A(p22), .B(new_n70_), .Y(new_n102_));
  AOI21x1_ASAP7_75t_R g059(.A1(p9), .A2(o0), .B(new_n102_), .Y(new_n103_));
  AOI21x1_ASAP7_75t_R g060(.A1(new_n100_), .A2(new_n101_), .B(new_n103_), .Y(new_n104_));
  NAND3x1_ASAP7_75t_R g061(.A(new_n89_), .B(new_n98_), .C(new_n104_), .Y(o1));
  INVx1_ASAP7_75t_R   g062(.A(new_n77_), .Y(new_n106_));
  AOI21x1_ASAP7_75t_R g063(.A1(p13), .A2(o0), .B(new_n106_), .Y(new_n107_));
  AOI21x1_ASAP7_75t_R g064(.A1(p35), .A2(o0), .B(new_n76_), .Y(new_n108_));
  NOR2x1_ASAP7_75t_R  g065(.A(new_n107_), .B(new_n108_), .Y(new_n109_));
  NAND3x1_ASAP7_75t_R g066(.A(new_n109_), .B(new_n94_), .C(new_n97_), .Y(new_n110_));
  AOI21x1_ASAP7_75t_R g067(.A1(p7), .A2(o0), .B(new_n83_), .Y(new_n111_));
  AOI21x1_ASAP7_75t_R g068(.A1(new_n86_), .A2(new_n85_), .B(new_n111_), .Y(new_n112_));
  AOI21x1_ASAP7_75t_R g069(.A1(p1), .A2(o0), .B(new_n90_), .Y(new_n113_));
  NOR2x1_ASAP7_75t_R  g070(.A(new_n113_), .B(new_n103_), .Y(new_n114_));
  NAND2x1_ASAP7_75t_R g071(.A(new_n100_), .B(new_n101_), .Y(new_n115_));
  NAND3x1_ASAP7_75t_R g072(.A(new_n112_), .B(new_n114_), .C(new_n115_), .Y(new_n116_));
  OAI21x1_ASAP7_75t_R g073(.A1(new_n110_), .A2(new_n116_), .B(p22), .Y(new_n117_));
  INVx1_ASAP7_75t_R   g074(.A(p31), .Y(new_n118_));
  AO21x1_ASAP7_75t_R  g075(.A1(p9), .A2(o0), .B(new_n70_), .Y(new_n119_));
  INVx1_ASAP7_75t_R   g076(.A(new_n119_), .Y(new_n120_));
  NAND3x1_ASAP7_75t_R g077(.A(new_n117_), .B(new_n118_), .C(new_n120_), .Y(new_n121_));
  INVx1_ASAP7_75t_R   g078(.A(p20), .Y(new_n122_));
  NOR2x1_ASAP7_75t_R  g079(.A(new_n110_), .B(new_n116_), .Y(new_n123_));
  AO21x1_ASAP7_75t_R  g080(.A1(p5), .A2(o0), .B(new_n99_), .Y(new_n124_));
  NOR2x1_ASAP7_75t_R  g081(.A(p29), .B(new_n124_), .Y(new_n125_));
  OAI21x1_ASAP7_75t_R g082(.A1(new_n122_), .A2(new_n123_), .B(new_n125_), .Y(new_n126_));
  INVx1_ASAP7_75t_R   g083(.A(p21), .Y(new_n127_));
  AO21x1_ASAP7_75t_R  g084(.A1(p7), .A2(o0), .B(new_n82_), .Y(new_n128_));
  NOR2x1_ASAP7_75t_R  g085(.A(p30), .B(new_n128_), .Y(new_n129_));
  OAI21x1_ASAP7_75t_R g086(.A1(new_n127_), .A2(new_n123_), .B(new_n129_), .Y(new_n130_));
  NAND3x1_ASAP7_75t_R g087(.A(new_n121_), .B(new_n126_), .C(new_n130_), .Y(new_n131_));
  NOR2x1_ASAP7_75t_R  g088(.A(new_n53_), .B(new_n74_), .Y(new_n132_));
  INVx1_ASAP7_75t_R   g089(.A(new_n132_), .Y(new_n133_));
  NOR2x1_ASAP7_75t_R  g090(.A(p26), .B(new_n133_), .Y(new_n134_));
  OAI21x1_ASAP7_75t_R g091(.A1(new_n75_), .A2(new_n123_), .B(new_n134_), .Y(new_n135_));
  INVx1_ASAP7_75t_R   g092(.A(p4), .Y(new_n136_));
  AO21x1_ASAP7_75t_R  g093(.A1(p3), .A2(o0), .B(new_n136_), .Y(new_n137_));
  NOR2x1_ASAP7_75t_R  g094(.A(p28), .B(new_n137_), .Y(new_n138_));
  OAI21x1_ASAP7_75t_R g095(.A1(new_n92_), .A2(new_n123_), .B(new_n138_), .Y(new_n139_));
  INVx1_ASAP7_75t_R   g096(.A(new_n104_), .Y(new_n140_));
  NAND2x1_ASAP7_75t_R g097(.A(new_n109_), .B(new_n112_), .Y(new_n141_));
  OAI21x1_ASAP7_75t_R g098(.A1(new_n140_), .A2(new_n141_), .B(p24), .Y(new_n142_));
  INVx1_ASAP7_75t_R   g099(.A(new_n94_), .Y(new_n143_));
  NAND2x1_ASAP7_75t_R g100(.A(new_n91_), .B(new_n97_), .Y(new_n144_));
  OAI21x1_ASAP7_75t_R g101(.A1(new_n143_), .A2(new_n144_), .B(p24), .Y(new_n145_));
  INVx1_ASAP7_75t_R   g102(.A(p33), .Y(new_n146_));
  AND3x1_ASAP7_75t_R  g103(.A(new_n78_), .B(new_n146_), .C(p14), .Y(new_n147_));
  NAND3x1_ASAP7_75t_R g104(.A(new_n142_), .B(new_n145_), .C(new_n147_), .Y(new_n148_));
  NAND3x1_ASAP7_75t_R g105(.A(new_n135_), .B(new_n139_), .C(new_n148_), .Y(new_n149_));
  AO21x1_ASAP7_75t_R  g106(.A1(p11), .A2(o0), .B(new_n44_), .Y(new_n150_));
  NOR2x1_ASAP7_75t_R  g107(.A(p32), .B(new_n150_), .Y(new_n151_));
  OAI21x1_ASAP7_75t_R g108(.A1(new_n95_), .A2(new_n123_), .B(new_n151_), .Y(new_n152_));
  AO21x1_ASAP7_75t_R  g109(.A1(p1), .A2(o0), .B(new_n55_), .Y(new_n153_));
  NOR2x1_ASAP7_75t_R  g110(.A(p27), .B(new_n153_), .Y(new_n154_));
  OAI21x1_ASAP7_75t_R g111(.A1(new_n110_), .A2(new_n116_), .B(p18), .Y(new_n155_));
  NAND2x1_ASAP7_75t_R g112(.A(new_n154_), .B(new_n155_), .Y(new_n156_));
  OAI21x1_ASAP7_75t_R g113(.A1(new_n140_), .A2(new_n141_), .B(p25), .Y(new_n157_));
  OAI21x1_ASAP7_75t_R g114(.A1(new_n143_), .A2(new_n144_), .B(p25), .Y(new_n158_));
  INVx1_ASAP7_75t_R   g115(.A(p34), .Y(new_n159_));
  AND3x1_ASAP7_75t_R  g116(.A(new_n86_), .B(new_n159_), .C(p16), .Y(new_n160_));
  NAND3x1_ASAP7_75t_R g117(.A(new_n157_), .B(new_n158_), .C(new_n160_), .Y(new_n161_));
  NAND3x1_ASAP7_75t_R g118(.A(new_n152_), .B(new_n156_), .C(new_n161_), .Y(new_n162_));
  OR3x1_ASAP7_75t_R   g119(.A(new_n131_), .B(new_n149_), .C(new_n162_), .Y(o2));
  OA21x2_ASAP7_75t_R  g120(.A1(new_n162_), .A2(new_n149_), .B(p26), .Y(new_n164_));
  AO21x1_ASAP7_75t_R  g121(.A1(p17), .A2(o1), .B(new_n133_), .Y(new_n165_));
  AO21x1_ASAP7_75t_R  g122(.A1(p26), .A2(new_n131_), .B(new_n165_), .Y(new_n166_));
  OAI21x1_ASAP7_75t_R g123(.A1(new_n162_), .A2(new_n149_), .B(p27), .Y(new_n167_));
  AO21x1_ASAP7_75t_R  g124(.A1(p18), .A2(o1), .B(new_n153_), .Y(new_n168_));
  AOI21x1_ASAP7_75t_R g125(.A1(p27), .A2(new_n131_), .B(new_n168_), .Y(new_n169_));
  NAND2x1_ASAP7_75t_R g126(.A(new_n167_), .B(new_n169_), .Y(new_n170_));
  OAI21x1_ASAP7_75t_R g127(.A1(new_n164_), .A2(new_n166_), .B(new_n170_), .Y(new_n171_));
  OAI21x1_ASAP7_75t_R g128(.A1(new_n162_), .A2(new_n149_), .B(p28), .Y(new_n172_));
  AO21x1_ASAP7_75t_R  g129(.A1(p19), .A2(o1), .B(new_n137_), .Y(new_n173_));
  AOI21x1_ASAP7_75t_R g130(.A1(p28), .A2(new_n131_), .B(new_n173_), .Y(new_n174_));
  NAND2x1_ASAP7_75t_R g131(.A(new_n172_), .B(new_n174_), .Y(new_n175_));
  OAI21x1_ASAP7_75t_R g132(.A1(new_n162_), .A2(new_n149_), .B(p29), .Y(new_n176_));
  AO21x1_ASAP7_75t_R  g133(.A1(p20), .A2(o1), .B(new_n124_), .Y(new_n177_));
  AOI21x1_ASAP7_75t_R g134(.A1(p29), .A2(new_n131_), .B(new_n177_), .Y(new_n178_));
  NAND2x1_ASAP7_75t_R g135(.A(new_n176_), .B(new_n178_), .Y(new_n179_));
  NAND2x1_ASAP7_75t_R g136(.A(new_n175_), .B(new_n179_), .Y(new_n180_));
  NOR2x1_ASAP7_75t_R  g137(.A(new_n171_), .B(new_n180_), .Y(new_n181_));
  OA21x2_ASAP7_75t_R  g138(.A1(new_n162_), .A2(new_n149_), .B(p30), .Y(new_n182_));
  AOI21x1_ASAP7_75t_R g139(.A1(p21), .A2(o1), .B(new_n128_), .Y(new_n183_));
  NAND2x1_ASAP7_75t_R g140(.A(p10), .B(new_n118_), .Y(new_n184_));
  AO21x1_ASAP7_75t_R  g141(.A1(p9), .A2(o0), .B(new_n184_), .Y(new_n185_));
  AOI21x1_ASAP7_75t_R g142(.A1(p22), .A2(o1), .B(new_n185_), .Y(new_n186_));
  OA21x2_ASAP7_75t_R  g143(.A1(new_n122_), .A2(new_n123_), .B(new_n125_), .Y(new_n187_));
  OAI21x1_ASAP7_75t_R g144(.A1(new_n186_), .A2(new_n187_), .B(p30), .Y(new_n188_));
  NAND2x1_ASAP7_75t_R g145(.A(new_n183_), .B(new_n188_), .Y(new_n189_));
  NOR2x1_ASAP7_75t_R  g146(.A(new_n162_), .B(new_n149_), .Y(new_n190_));
  NAND2x1_ASAP7_75t_R g147(.A(new_n120_), .B(new_n117_), .Y(new_n191_));
  NOR2x1_ASAP7_75t_R  g148(.A(new_n191_), .B(new_n131_), .Y(new_n192_));
  AOI21x1_ASAP7_75t_R g149(.A1(new_n190_), .A2(new_n192_), .B(new_n186_), .Y(new_n193_));
  OAI21x1_ASAP7_75t_R g150(.A1(new_n182_), .A2(new_n189_), .B(new_n193_), .Y(new_n194_));
  NAND2x1_ASAP7_75t_R g151(.A(p14), .B(new_n78_), .Y(new_n195_));
  AO21x1_ASAP7_75t_R  g152(.A1(p24), .A2(o1), .B(new_n195_), .Y(new_n196_));
  AO21x1_ASAP7_75t_R  g153(.A1(p33), .A2(new_n131_), .B(new_n196_), .Y(new_n197_));
  NOR2x1_ASAP7_75t_R  g154(.A(new_n146_), .B(new_n190_), .Y(new_n198_));
  OAI21x1_ASAP7_75t_R g155(.A1(new_n162_), .A2(new_n149_), .B(p32), .Y(new_n199_));
  AO21x1_ASAP7_75t_R  g156(.A1(p23), .A2(o1), .B(new_n150_), .Y(new_n200_));
  AOI21x1_ASAP7_75t_R g157(.A1(p32), .A2(new_n131_), .B(new_n200_), .Y(new_n201_));
  NAND2x1_ASAP7_75t_R g158(.A(new_n199_), .B(new_n201_), .Y(new_n202_));
  OAI21x1_ASAP7_75t_R g159(.A1(new_n197_), .A2(new_n198_), .B(new_n202_), .Y(new_n203_));
  NOR2x1_ASAP7_75t_R  g160(.A(new_n194_), .B(new_n203_), .Y(new_n204_));
  NAND2x1_ASAP7_75t_R g161(.A(p16), .B(new_n86_), .Y(new_n205_));
  AO21x1_ASAP7_75t_R  g162(.A1(p25), .A2(o1), .B(new_n205_), .Y(new_n206_));
  AOI21x1_ASAP7_75t_R g163(.A1(p34), .A2(o2), .B(new_n206_), .Y(new_n207_));
  AOI21x1_ASAP7_75t_R g164(.A1(new_n181_), .A2(new_n204_), .B(new_n207_), .Y(o3));
  INVx1_ASAP7_75t_R   g165(.A(new_n204_), .Y(o4));
  AOI21x1_ASAP7_75t_R g166(.A1(new_n199_), .A2(new_n201_), .B(new_n179_), .Y(new_n210_));
  INVx1_ASAP7_75t_R   g167(.A(new_n134_), .Y(new_n211_));
  AOI21x1_ASAP7_75t_R g168(.A1(p17), .A2(o1), .B(new_n211_), .Y(new_n212_));
  AOI21x1_ASAP7_75t_R g169(.A1(new_n155_), .A2(new_n154_), .B(new_n212_), .Y(new_n213_));
  NAND2x1_ASAP7_75t_R g170(.A(new_n94_), .B(o1), .Y(new_n214_));
  INVx1_ASAP7_75t_R   g171(.A(new_n151_), .Y(new_n215_));
  AOI21x1_ASAP7_75t_R g172(.A1(p23), .A2(o1), .B(new_n215_), .Y(new_n216_));
  AOI21x1_ASAP7_75t_R g173(.A1(new_n138_), .A2(new_n214_), .B(new_n216_), .Y(new_n217_));
  INVx1_ASAP7_75t_R   g174(.A(new_n160_), .Y(new_n218_));
  AOI21x1_ASAP7_75t_R g175(.A1(p25), .A2(o1), .B(new_n218_), .Y(new_n219_));
  INVx1_ASAP7_75t_R   g176(.A(new_n147_), .Y(new_n220_));
  AOI21x1_ASAP7_75t_R g177(.A1(p24), .A2(o1), .B(new_n220_), .Y(new_n221_));
  NOR2x1_ASAP7_75t_R  g178(.A(new_n219_), .B(new_n221_), .Y(new_n222_));
  NAND3x1_ASAP7_75t_R g179(.A(new_n213_), .B(new_n217_), .C(new_n222_), .Y(new_n223_));
  NAND2x1_ASAP7_75t_R g180(.A(new_n126_), .B(new_n130_), .Y(new_n224_));
  AO21x1_ASAP7_75t_R  g181(.A1(p31), .A2(new_n224_), .B(new_n191_), .Y(new_n225_));
  AOI21x1_ASAP7_75t_R g182(.A1(p31), .A2(new_n223_), .B(new_n225_), .Y(new_n226_));
  AOI21x1_ASAP7_75t_R g183(.A1(p30), .A2(new_n223_), .B(new_n189_), .Y(new_n227_));
  NOR2x1_ASAP7_75t_R  g184(.A(new_n226_), .B(new_n227_), .Y(new_n228_));
  NAND2x1_ASAP7_75t_R g185(.A(new_n210_), .B(new_n228_), .Y(new_n229_));
  INVx1_ASAP7_75t_R   g186(.A(new_n203_), .Y(new_n230_));
  OR3x1_ASAP7_75t_R   g187(.A(new_n227_), .B(new_n226_), .C(new_n175_), .Y(new_n231_));
  NAND3x1_ASAP7_75t_R g188(.A(new_n229_), .B(new_n230_), .C(new_n231_), .Y(o5));
  NOR2x1_ASAP7_75t_R  g189(.A(new_n197_), .B(new_n198_), .Y(new_n233_));
  AOI21x1_ASAP7_75t_R g190(.A1(new_n226_), .A2(new_n202_), .B(new_n233_), .Y(new_n234_));
  AOI21x1_ASAP7_75t_R g191(.A1(new_n172_), .A2(new_n174_), .B(new_n170_), .Y(new_n235_));
  NOR2x1_ASAP7_75t_R  g192(.A(new_n179_), .B(new_n227_), .Y(new_n236_));
  AOI21x1_ASAP7_75t_R g193(.A1(new_n199_), .A2(new_n201_), .B(new_n226_), .Y(new_n237_));
  OAI21x1_ASAP7_75t_R g194(.A1(new_n235_), .A2(new_n236_), .B(new_n237_), .Y(new_n238_));
  NAND2x1_ASAP7_75t_R g195(.A(new_n234_), .B(new_n238_), .Y(o6));
endmodule


