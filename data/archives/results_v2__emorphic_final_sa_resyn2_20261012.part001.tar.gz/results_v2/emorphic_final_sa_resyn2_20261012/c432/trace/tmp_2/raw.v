// Benchmark "/tmp/" written by ABC on Mon Oct 12 14:43:37 2026

module \/tmp/  ( 
    p26, p24, p3, p1, p34, p18, p9, p29, p22, p2, p25, p32, p6, p19, p28,
    p4, p0, p13, p10, p20, p16, p35, p7, p21, p33, p27, p8, p11, p14, p30,
    p23, p5, p31, p17, p15, p12,
    o0, o1, o2, o3, o4, o5, o6  );
  input  p26, p24, p3, p1, p34, p18, p9, p29, p22, p2, p25, p32, p6, p19,
    p28, p4, p0, p13, p10, p20, p16, p35, p7, p21, p33, p27, p8, p11, p14,
    p30, p23, p5, p31, p17, p15, p12;
  output o0, o1, o2, o3, o4, o5, o6;
  wire new_n44_, new_n45_, new_n46_, new_n47_, new_n48_, new_n49_, new_n50_,
    new_n51_, new_n52_, new_n53_, new_n54_, new_n55_, new_n56_, new_n57_,
    new_n58_, new_n59_, new_n60_, new_n61_, new_n62_, new_n63_, new_n65_,
    new_n66_, new_n67_, new_n68_, new_n69_, new_n70_, new_n71_, new_n72_,
    new_n73_, new_n74_, new_n75_, new_n76_, new_n77_, new_n78_, new_n79_,
    new_n80_, new_n81_, new_n82_, new_n83_, new_n84_, new_n85_, new_n86_,
    new_n87_, new_n88_, new_n89_, new_n90_, new_n91_, new_n92_, new_n93_,
    new_n94_, new_n95_, new_n96_, new_n97_, new_n98_, new_n99_, new_n100_,
    new_n101_, new_n102_, new_n103_, new_n105_, new_n106_, new_n107_,
    new_n108_, new_n109_, new_n110_, new_n111_, new_n112_, new_n113_,
    new_n114_, new_n115_, new_n116_, new_n117_, new_n118_, new_n119_,
    new_n120_, new_n121_, new_n122_, new_n123_, new_n124_, new_n125_,
    new_n126_, new_n127_, new_n128_, new_n129_, new_n130_, new_n131_,
    new_n132_, new_n133_, new_n134_, new_n135_, new_n136_, new_n137_,
    new_n138_, new_n139_, new_n140_, new_n141_, new_n142_, new_n143_,
    new_n144_, new_n145_, new_n146_, new_n147_, new_n148_, new_n149_,
    new_n150_, new_n151_, new_n152_, new_n153_, new_n154_, new_n155_,
    new_n156_, new_n157_, new_n158_, new_n159_, new_n160_, new_n162_,
    new_n163_, new_n164_, new_n165_, new_n166_, new_n167_, new_n168_,
    new_n169_, new_n170_, new_n171_, new_n172_, new_n173_, new_n174_,
    new_n175_, new_n176_, new_n177_, new_n178_, new_n179_, new_n180_,
    new_n181_, new_n182_, new_n183_, new_n184_, new_n185_, new_n186_,
    new_n187_, new_n188_, new_n189_, new_n190_, new_n191_, new_n192_,
    new_n193_, new_n194_, new_n195_, new_n196_, new_n197_, new_n198_,
    new_n199_, new_n200_, new_n201_, new_n202_, new_n203_, new_n204_,
    new_n205_, new_n208_, new_n209_, new_n210_, new_n211_, new_n212_,
    new_n213_, new_n214_, new_n215_, new_n216_, new_n217_, new_n218_,
    new_n219_, new_n220_, new_n221_, new_n222_, new_n223_, new_n224_,
    new_n225_, new_n226_, new_n227_, new_n228_, new_n229_, new_n230_,
    new_n232_, new_n233_, new_n234_, new_n235_, new_n236_, new_n237_,
    new_n238_, new_n239_, new_n240_, new_n241_, new_n242_, new_n243_;
  INVx1_ASAP7_75t_R   g000(.A(p0), .Y(new_n44_));
  INVx1_ASAP7_75t_R   g001(.A(p1), .Y(new_n45_));
  NAND2x1_ASAP7_75t_R g002(.A(p2), .B(new_n45_), .Y(new_n46_));
  OAI21x1_ASAP7_75t_R g003(.A1(new_n44_), .A2(p35), .B(new_n46_), .Y(new_n47_));
  INVx1_ASAP7_75t_R   g004(.A(p12), .Y(new_n48_));
  INVx1_ASAP7_75t_R   g005(.A(p3), .Y(new_n49_));
  NAND2x1_ASAP7_75t_R g006(.A(p4), .B(new_n49_), .Y(new_n50_));
  OAI21x1_ASAP7_75t_R g007(.A1(p11), .A2(new_n48_), .B(new_n50_), .Y(new_n51_));
  NOR2x1_ASAP7_75t_R  g008(.A(new_n47_), .B(new_n51_), .Y(new_n52_));
  INVx1_ASAP7_75t_R   g009(.A(p15), .Y(new_n53_));
  INVx1_ASAP7_75t_R   g010(.A(p14), .Y(new_n54_));
  NOR2x1_ASAP7_75t_R  g011(.A(p13), .B(new_n54_), .Y(new_n55_));
  AOI21x1_ASAP7_75t_R g012(.A1(p16), .A2(new_n53_), .B(new_n55_), .Y(new_n56_));
  INVx1_ASAP7_75t_R   g013(.A(p8), .Y(new_n57_));
  NOR2x1_ASAP7_75t_R  g014(.A(p7), .B(new_n57_), .Y(new_n58_));
  INVx1_ASAP7_75t_R   g015(.A(p10), .Y(new_n59_));
  NOR2x1_ASAP7_75t_R  g016(.A(p9), .B(new_n59_), .Y(new_n60_));
  INVx1_ASAP7_75t_R   g017(.A(p6), .Y(new_n61_));
  NOR2x1_ASAP7_75t_R  g018(.A(p5), .B(new_n61_), .Y(new_n62_));
  NOR3x1_ASAP7_75t_R  g019(.A(new_n58_), .B(new_n60_), .C(new_n62_), .Y(new_n63_));
  NAND3x1_ASAP7_75t_R g020(.A(new_n52_), .B(new_n56_), .C(new_n63_), .Y(o0));
  NOR2x1_ASAP7_75t_R  g021(.A(p35), .B(new_n44_), .Y(new_n65_));
  AOI21x1_ASAP7_75t_R g022(.A1(new_n45_), .A2(p2), .B(new_n65_), .Y(new_n66_));
  OR2x4_ASAP7_75t_R   g023(.A(p11), .B(new_n48_), .Y(new_n67_));
  NAND3x1_ASAP7_75t_R g024(.A(new_n66_), .B(new_n67_), .C(new_n50_), .Y(new_n68_));
  NOR2x1_ASAP7_75t_R  g025(.A(new_n58_), .B(new_n60_), .Y(new_n69_));
  INVx1_ASAP7_75t_R   g026(.A(new_n62_), .Y(new_n70_));
  NAND3x1_ASAP7_75t_R g027(.A(new_n56_), .B(new_n69_), .C(new_n70_), .Y(new_n71_));
  OA21x2_ASAP7_75t_R  g028(.A1(new_n68_), .A2(new_n71_), .B(p9), .Y(new_n72_));
  NOR2x1_ASAP7_75t_R  g029(.A(p22), .B(new_n59_), .Y(new_n73_));
  INVx1_ASAP7_75t_R   g030(.A(new_n73_), .Y(new_n74_));
  NOR2x1_ASAP7_75t_R  g031(.A(p20), .B(new_n61_), .Y(new_n75_));
  OAI21x1_ASAP7_75t_R g032(.A1(new_n68_), .A2(new_n71_), .B(p5), .Y(new_n76_));
  NAND2x1_ASAP7_75t_R g033(.A(new_n75_), .B(new_n76_), .Y(new_n77_));
  OAI21x1_ASAP7_75t_R g034(.A1(new_n72_), .A2(new_n74_), .B(new_n77_), .Y(new_n78_));
  INVx1_ASAP7_75t_R   g035(.A(p25), .Y(new_n79_));
  NAND2x1_ASAP7_75t_R g036(.A(p16), .B(new_n79_), .Y(new_n80_));
  NOR2x1_ASAP7_75t_R  g037(.A(new_n68_), .B(new_n71_), .Y(new_n81_));
  NOR2x1_ASAP7_75t_R  g038(.A(new_n53_), .B(new_n81_), .Y(new_n82_));
  INVx1_ASAP7_75t_R   g039(.A(p7), .Y(new_n83_));
  NOR2x1_ASAP7_75t_R  g040(.A(p21), .B(new_n57_), .Y(new_n84_));
  OAI21x1_ASAP7_75t_R g041(.A1(new_n83_), .A2(new_n81_), .B(new_n84_), .Y(new_n85_));
  OAI21x1_ASAP7_75t_R g042(.A1(new_n80_), .A2(new_n82_), .B(new_n85_), .Y(new_n86_));
  NOR2x1_ASAP7_75t_R  g043(.A(new_n78_), .B(new_n86_), .Y(new_n87_));
  INVx1_ASAP7_75t_R   g044(.A(p17), .Y(new_n88_));
  NAND2x1_ASAP7_75t_R g045(.A(p0), .B(new_n88_), .Y(new_n89_));
  AOI21x1_ASAP7_75t_R g046(.A1(p35), .A2(o0), .B(new_n89_), .Y(new_n90_));
  INVx1_ASAP7_75t_R   g047(.A(p24), .Y(new_n91_));
  NAND2x1_ASAP7_75t_R g048(.A(p14), .B(new_n91_), .Y(new_n92_));
  AOI21x1_ASAP7_75t_R g049(.A1(p13), .A2(o0), .B(new_n92_), .Y(new_n93_));
  NOR2x1_ASAP7_75t_R  g050(.A(new_n90_), .B(new_n93_), .Y(new_n94_));
  INVx1_ASAP7_75t_R   g051(.A(p19), .Y(new_n95_));
  NAND2x1_ASAP7_75t_R g052(.A(p4), .B(new_n95_), .Y(new_n96_));
  AO21x1_ASAP7_75t_R  g053(.A1(new_n50_), .A2(o0), .B(new_n96_), .Y(new_n97_));
  OR2x4_ASAP7_75t_R   g054(.A(p23), .B(new_n48_), .Y(new_n98_));
  AO21x1_ASAP7_75t_R  g055(.A1(p11), .A2(o0), .B(new_n98_), .Y(new_n99_));
  INVx1_ASAP7_75t_R   g056(.A(p18), .Y(new_n100_));
  NAND2x1_ASAP7_75t_R g057(.A(p2), .B(new_n100_), .Y(new_n101_));
  AO21x1_ASAP7_75t_R  g058(.A1(p1), .A2(o0), .B(new_n101_), .Y(new_n102_));
  AND3x1_ASAP7_75t_R  g059(.A(new_n97_), .B(new_n99_), .C(new_n102_), .Y(new_n103_));
  NAND3x1_ASAP7_75t_R g060(.A(new_n87_), .B(new_n94_), .C(new_n103_), .Y(o1));
  INVx1_ASAP7_75t_R   g061(.A(p20), .Y(new_n105_));
  NAND2x1_ASAP7_75t_R g062(.A(p7), .B(o0), .Y(new_n106_));
  AOI21x1_ASAP7_75t_R g063(.A1(p15), .A2(o0), .B(new_n80_), .Y(new_n107_));
  AOI21x1_ASAP7_75t_R g064(.A1(new_n106_), .A2(new_n84_), .B(new_n107_), .Y(new_n108_));
  NAND2x1_ASAP7_75t_R g065(.A(new_n94_), .B(new_n108_), .Y(new_n109_));
  NAND3x1_ASAP7_75t_R g066(.A(new_n97_), .B(new_n99_), .C(new_n102_), .Y(new_n110_));
  NOR3x1_ASAP7_75t_R  g067(.A(new_n109_), .B(new_n78_), .C(new_n110_), .Y(new_n111_));
  INVx1_ASAP7_75t_R   g068(.A(p29), .Y(new_n112_));
  AND3x1_ASAP7_75t_R  g069(.A(new_n76_), .B(new_n112_), .C(p6), .Y(new_n113_));
  OAI21x1_ASAP7_75t_R g070(.A1(new_n105_), .A2(new_n111_), .B(new_n113_), .Y(new_n114_));
  INVx1_ASAP7_75t_R   g071(.A(p21), .Y(new_n115_));
  INVx1_ASAP7_75t_R   g072(.A(p30), .Y(new_n116_));
  AND3x1_ASAP7_75t_R  g073(.A(new_n106_), .B(p8), .C(new_n116_), .Y(new_n117_));
  OAI21x1_ASAP7_75t_R g074(.A1(new_n115_), .A2(new_n111_), .B(new_n117_), .Y(new_n118_));
  OAI21x1_ASAP7_75t_R g075(.A1(new_n78_), .A2(new_n109_), .B(p22), .Y(new_n119_));
  NAND2x1_ASAP7_75t_R g076(.A(p22), .B(new_n110_), .Y(new_n120_));
  AO21x1_ASAP7_75t_R  g077(.A1(p10), .A2(new_n81_), .B(new_n60_), .Y(new_n121_));
  INVx1_ASAP7_75t_R   g078(.A(new_n121_), .Y(new_n122_));
  NOR2x1_ASAP7_75t_R  g079(.A(p31), .B(new_n122_), .Y(new_n123_));
  NAND3x1_ASAP7_75t_R g080(.A(new_n119_), .B(new_n120_), .C(new_n123_), .Y(new_n124_));
  NAND3x1_ASAP7_75t_R g081(.A(new_n114_), .B(new_n118_), .C(new_n124_), .Y(new_n125_));
  INVx1_ASAP7_75t_R   g082(.A(p16), .Y(new_n126_));
  OR3x1_ASAP7_75t_R   g083(.A(new_n82_), .B(p34), .C(new_n126_), .Y(new_n127_));
  INVx1_ASAP7_75t_R   g084(.A(new_n127_), .Y(new_n128_));
  OAI21x1_ASAP7_75t_R g085(.A1(new_n79_), .A2(new_n111_), .B(new_n128_), .Y(new_n129_));
  OAI21x1_ASAP7_75t_R g086(.A1(new_n49_), .A2(new_n81_), .B(p4), .Y(new_n130_));
  NOR2x1_ASAP7_75t_R  g087(.A(p28), .B(new_n130_), .Y(new_n131_));
  OAI21x1_ASAP7_75t_R g088(.A1(new_n95_), .A2(new_n111_), .B(new_n131_), .Y(new_n132_));
  OAI21x1_ASAP7_75t_R g089(.A1(new_n78_), .A2(new_n109_), .B(p23), .Y(new_n133_));
  NAND2x1_ASAP7_75t_R g090(.A(p23), .B(new_n110_), .Y(new_n134_));
  AO21x1_ASAP7_75t_R  g091(.A1(p11), .A2(o0), .B(new_n48_), .Y(new_n135_));
  NOR2x1_ASAP7_75t_R  g092(.A(p32), .B(new_n135_), .Y(new_n136_));
  NAND3x1_ASAP7_75t_R g093(.A(new_n133_), .B(new_n134_), .C(new_n136_), .Y(new_n137_));
  NAND3x1_ASAP7_75t_R g094(.A(new_n129_), .B(new_n132_), .C(new_n137_), .Y(new_n138_));
  INVx1_ASAP7_75t_R   g095(.A(p27), .Y(new_n139_));
  AOI21x1_ASAP7_75t_R g096(.A1(p11), .A2(o0), .B(new_n98_), .Y(new_n140_));
  AOI21x1_ASAP7_75t_R g097(.A1(p1), .A2(o0), .B(new_n101_), .Y(new_n141_));
  NOR2x1_ASAP7_75t_R  g098(.A(new_n140_), .B(new_n141_), .Y(new_n142_));
  OA21x2_ASAP7_75t_R  g099(.A1(new_n45_), .A2(new_n81_), .B(p2), .Y(new_n143_));
  NAND3x1_ASAP7_75t_R g100(.A(new_n142_), .B(new_n97_), .C(new_n143_), .Y(new_n144_));
  NAND2x1_ASAP7_75t_R g101(.A(p9), .B(o0), .Y(new_n145_));
  INVx1_ASAP7_75t_R   g102(.A(new_n75_), .Y(new_n146_));
  AOI21x1_ASAP7_75t_R g103(.A1(p5), .A2(o0), .B(new_n146_), .Y(new_n147_));
  AOI21x1_ASAP7_75t_R g104(.A1(new_n145_), .A2(new_n73_), .B(new_n147_), .Y(new_n148_));
  NAND3x1_ASAP7_75t_R g105(.A(new_n148_), .B(new_n108_), .C(new_n94_), .Y(new_n149_));
  OAI21x1_ASAP7_75t_R g106(.A1(new_n144_), .A2(new_n149_), .B(new_n102_), .Y(new_n150_));
  NAND2x1_ASAP7_75t_R g107(.A(new_n139_), .B(new_n150_), .Y(new_n151_));
  AO21x1_ASAP7_75t_R  g108(.A1(p35), .A2(o0), .B(new_n44_), .Y(new_n152_));
  NOR2x1_ASAP7_75t_R  g109(.A(p26), .B(new_n152_), .Y(new_n153_));
  OAI21x1_ASAP7_75t_R g110(.A1(new_n88_), .A2(new_n111_), .B(new_n153_), .Y(new_n154_));
  OAI21x1_ASAP7_75t_R g111(.A1(new_n78_), .A2(new_n109_), .B(p24), .Y(new_n155_));
  NAND2x1_ASAP7_75t_R g112(.A(p13), .B(o0), .Y(new_n156_));
  OA21x2_ASAP7_75t_R  g113(.A1(new_n91_), .A2(new_n103_), .B(new_n156_), .Y(new_n157_));
  NOR2x1_ASAP7_75t_R  g114(.A(p33), .B(new_n54_), .Y(new_n158_));
  NAND3x1_ASAP7_75t_R g115(.A(new_n155_), .B(new_n157_), .C(new_n158_), .Y(new_n159_));
  NAND3x1_ASAP7_75t_R g116(.A(new_n151_), .B(new_n154_), .C(new_n159_), .Y(new_n160_));
  OR3x1_ASAP7_75t_R   g117(.A(new_n125_), .B(new_n138_), .C(new_n160_), .Y(o2));
  OA21x2_ASAP7_75t_R  g118(.A1(new_n138_), .A2(new_n160_), .B(p26), .Y(new_n162_));
  AO21x1_ASAP7_75t_R  g119(.A1(p17), .A2(o1), .B(new_n152_), .Y(new_n163_));
  AO21x1_ASAP7_75t_R  g120(.A1(p26), .A2(new_n125_), .B(new_n163_), .Y(new_n164_));
  NAND2x1_ASAP7_75t_R g121(.A(new_n124_), .B(new_n118_), .Y(new_n165_));
  NAND2x1_ASAP7_75t_R g122(.A(p6), .B(new_n76_), .Y(new_n166_));
  AO21x1_ASAP7_75t_R  g123(.A1(p20), .A2(o1), .B(new_n166_), .Y(new_n167_));
  AOI21x1_ASAP7_75t_R g124(.A1(p29), .A2(new_n165_), .B(new_n167_), .Y(new_n168_));
  OAI21x1_ASAP7_75t_R g125(.A1(new_n138_), .A2(new_n160_), .B(p29), .Y(new_n169_));
  NAND2x1_ASAP7_75t_R g126(.A(new_n168_), .B(new_n169_), .Y(new_n170_));
  OAI21x1_ASAP7_75t_R g127(.A1(new_n162_), .A2(new_n164_), .B(new_n170_), .Y(new_n171_));
  INVx1_ASAP7_75t_R   g128(.A(new_n150_), .Y(new_n172_));
  AOI21x1_ASAP7_75t_R g129(.A1(p27), .A2(new_n125_), .B(new_n172_), .Y(new_n173_));
  OAI21x1_ASAP7_75t_R g130(.A1(new_n138_), .A2(new_n160_), .B(p27), .Y(new_n174_));
  NAND2x1_ASAP7_75t_R g131(.A(new_n173_), .B(new_n174_), .Y(new_n175_));
  INVx1_ASAP7_75t_R   g132(.A(p28), .Y(new_n176_));
  NOR2x1_ASAP7_75t_R  g133(.A(new_n138_), .B(new_n160_), .Y(new_n177_));
  AO21x1_ASAP7_75t_R  g134(.A1(p19), .A2(o1), .B(new_n130_), .Y(new_n178_));
  AOI21x1_ASAP7_75t_R g135(.A1(p28), .A2(new_n125_), .B(new_n178_), .Y(new_n179_));
  OAI21x1_ASAP7_75t_R g136(.A1(new_n176_), .A2(new_n177_), .B(new_n179_), .Y(new_n180_));
  NAND2x1_ASAP7_75t_R g137(.A(new_n175_), .B(new_n180_), .Y(new_n181_));
  NOR2x1_ASAP7_75t_R  g138(.A(new_n171_), .B(new_n181_), .Y(new_n182_));
  OA21x2_ASAP7_75t_R  g139(.A1(new_n138_), .A2(new_n160_), .B(p30), .Y(new_n183_));
  NAND2x1_ASAP7_75t_R g140(.A(new_n124_), .B(new_n114_), .Y(new_n184_));
  AO21x1_ASAP7_75t_R  g141(.A1(p7), .A2(o0), .B(new_n57_), .Y(new_n185_));
  AO21x1_ASAP7_75t_R  g142(.A1(p21), .A2(o1), .B(new_n185_), .Y(new_n186_));
  AO21x1_ASAP7_75t_R  g143(.A1(p30), .A2(new_n184_), .B(new_n186_), .Y(new_n187_));
  AND3x1_ASAP7_75t_R  g144(.A(new_n119_), .B(new_n121_), .C(new_n120_), .Y(new_n188_));
  INVx1_ASAP7_75t_R   g145(.A(new_n188_), .Y(new_n189_));
  AOI21x1_ASAP7_75t_R g146(.A1(p31), .A2(new_n125_), .B(new_n189_), .Y(new_n190_));
  OAI21x1_ASAP7_75t_R g147(.A1(new_n138_), .A2(new_n160_), .B(p31), .Y(new_n191_));
  NAND2x1_ASAP7_75t_R g148(.A(new_n190_), .B(new_n191_), .Y(new_n192_));
  OAI21x1_ASAP7_75t_R g149(.A1(new_n183_), .A2(new_n187_), .B(new_n192_), .Y(new_n193_));
  NAND3x1_ASAP7_75t_R g150(.A(new_n155_), .B(new_n157_), .C(p14), .Y(new_n194_));
  AO21x1_ASAP7_75t_R  g151(.A1(p33), .A2(new_n125_), .B(new_n194_), .Y(new_n195_));
  OA21x2_ASAP7_75t_R  g152(.A1(new_n138_), .A2(new_n160_), .B(p33), .Y(new_n196_));
  AO21x1_ASAP7_75t_R  g153(.A1(p23), .A2(o1), .B(new_n135_), .Y(new_n197_));
  AOI21x1_ASAP7_75t_R g154(.A1(p32), .A2(new_n125_), .B(new_n197_), .Y(new_n198_));
  OAI21x1_ASAP7_75t_R g155(.A1(new_n138_), .A2(new_n160_), .B(p32), .Y(new_n199_));
  NAND2x1_ASAP7_75t_R g156(.A(new_n198_), .B(new_n199_), .Y(new_n200_));
  OAI21x1_ASAP7_75t_R g157(.A1(new_n195_), .A2(new_n196_), .B(new_n200_), .Y(new_n201_));
  NOR2x1_ASAP7_75t_R  g158(.A(new_n193_), .B(new_n201_), .Y(new_n202_));
  AO21x1_ASAP7_75t_R  g159(.A1(p15), .A2(o0), .B(new_n126_), .Y(new_n203_));
  AO21x1_ASAP7_75t_R  g160(.A1(p25), .A2(o1), .B(new_n203_), .Y(new_n204_));
  AOI21x1_ASAP7_75t_R g161(.A1(p34), .A2(o2), .B(new_n204_), .Y(new_n205_));
  AOI21x1_ASAP7_75t_R g162(.A1(new_n182_), .A2(new_n202_), .B(new_n205_), .Y(o3));
  INVx1_ASAP7_75t_R   g163(.A(new_n202_), .Y(o4));
  AOI21x1_ASAP7_75t_R g164(.A1(new_n199_), .A2(new_n198_), .B(new_n170_), .Y(new_n208_));
  NAND2x1_ASAP7_75t_R g165(.A(new_n97_), .B(o1), .Y(new_n209_));
  AND3x1_ASAP7_75t_R  g166(.A(new_n133_), .B(new_n134_), .C(new_n136_), .Y(new_n210_));
  AOI21x1_ASAP7_75t_R g167(.A1(new_n131_), .A2(new_n209_), .B(new_n210_), .Y(new_n211_));
  INVx1_ASAP7_75t_R   g168(.A(new_n153_), .Y(new_n212_));
  AOI21x1_ASAP7_75t_R g169(.A1(p17), .A2(o1), .B(new_n212_), .Y(new_n213_));
  AOI21x1_ASAP7_75t_R g170(.A1(new_n139_), .A2(new_n150_), .B(new_n213_), .Y(new_n214_));
  AOI21x1_ASAP7_75t_R g171(.A1(p25), .A2(o1), .B(new_n127_), .Y(new_n215_));
  NAND2x1_ASAP7_75t_R g172(.A(new_n158_), .B(new_n156_), .Y(new_n216_));
  AOI21x1_ASAP7_75t_R g173(.A1(p24), .A2(o1), .B(new_n216_), .Y(new_n217_));
  NOR2x1_ASAP7_75t_R  g174(.A(new_n215_), .B(new_n217_), .Y(new_n218_));
  NAND3x1_ASAP7_75t_R g175(.A(new_n211_), .B(new_n214_), .C(new_n218_), .Y(new_n219_));
  OR3x1_ASAP7_75t_R   g176(.A(new_n184_), .B(new_n116_), .C(new_n186_), .Y(new_n220_));
  NOR2x1_ASAP7_75t_R  g177(.A(new_n219_), .B(new_n220_), .Y(new_n221_));
  NAND2x1_ASAP7_75t_R g178(.A(p21), .B(o1), .Y(new_n222_));
  AND3x1_ASAP7_75t_R  g179(.A(new_n119_), .B(new_n120_), .C(new_n123_), .Y(new_n223_));
  AOI21x1_ASAP7_75t_R g180(.A1(new_n222_), .A2(new_n117_), .B(new_n223_), .Y(new_n224_));
  NAND3x1_ASAP7_75t_R g181(.A(new_n224_), .B(new_n114_), .C(new_n188_), .Y(new_n225_));
  OAI21x1_ASAP7_75t_R g182(.A1(new_n225_), .A2(new_n219_), .B(new_n224_), .Y(new_n226_));
  NOR2x1_ASAP7_75t_R  g183(.A(new_n221_), .B(new_n226_), .Y(new_n227_));
  NAND2x1_ASAP7_75t_R g184(.A(new_n208_), .B(new_n227_), .Y(new_n228_));
  INVx1_ASAP7_75t_R   g185(.A(new_n201_), .Y(new_n229_));
  OR3x1_ASAP7_75t_R   g186(.A(new_n226_), .B(new_n180_), .C(new_n221_), .Y(new_n230_));
  NAND3x1_ASAP7_75t_R g187(.A(new_n228_), .B(new_n229_), .C(new_n230_), .Y(o5));
  OAI21x1_ASAP7_75t_R g188(.A1(new_n225_), .A2(new_n219_), .B(new_n124_), .Y(new_n232_));
  NOR2x1_ASAP7_75t_R  g189(.A(new_n195_), .B(new_n196_), .Y(new_n233_));
  AOI21x1_ASAP7_75t_R g190(.A1(new_n200_), .A2(new_n232_), .B(new_n233_), .Y(new_n234_));
  AND3x1_ASAP7_75t_R  g191(.A(new_n129_), .B(new_n132_), .C(new_n137_), .Y(new_n235_));
  AND3x1_ASAP7_75t_R  g192(.A(new_n151_), .B(new_n154_), .C(new_n159_), .Y(new_n236_));
  AO21x1_ASAP7_75t_R  g193(.A1(new_n235_), .A2(new_n236_), .B(new_n116_), .Y(new_n237_));
  INVx1_ASAP7_75t_R   g194(.A(new_n187_), .Y(new_n238_));
  AOI21x1_ASAP7_75t_R g195(.A1(new_n237_), .A2(new_n238_), .B(new_n170_), .Y(new_n239_));
  AO21x1_ASAP7_75t_R  g196(.A1(new_n235_), .A2(new_n236_), .B(new_n176_), .Y(new_n240_));
  AOI21x1_ASAP7_75t_R g197(.A1(new_n240_), .A2(new_n179_), .B(new_n175_), .Y(new_n241_));
  AOI21x1_ASAP7_75t_R g198(.A1(new_n199_), .A2(new_n198_), .B(new_n232_), .Y(new_n242_));
  OAI21x1_ASAP7_75t_R g199(.A1(new_n239_), .A2(new_n241_), .B(new_n242_), .Y(new_n243_));
  NAND2x1_ASAP7_75t_R g200(.A(new_n234_), .B(new_n243_), .Y(o6));
endmodule


