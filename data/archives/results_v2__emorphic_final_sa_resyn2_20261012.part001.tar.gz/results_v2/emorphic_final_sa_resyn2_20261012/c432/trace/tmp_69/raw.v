// Benchmark "/tmp/" written by ABC on Mon Oct 12 14:43:42 2026

module \/tmp/  ( 
    p2, p22, p12, p10, p6, p11, p34, p26, p35, p1, p31, p24, p5, p30, p25,
    p19, p0, p23, p27, p4, p21, p13, p7, p32, p16, p28, p17, p33, p8, p15,
    p14, p9, p18, p29, p3, p20,
    o0, o1, o2, o3, o4, o5, o6  );
  input  p2, p22, p12, p10, p6, p11, p34, p26, p35, p1, p31, p24, p5,
    p30, p25, p19, p0, p23, p27, p4, p21, p13, p7, p32, p16, p28, p17, p33,
    p8, p15, p14, p9, p18, p29, p3, p20;
  output o0, o1, o2, o3, o4, o5, o6;
  wire new_n44_, new_n45_, new_n46_, new_n47_, new_n48_, new_n49_, new_n50_,
    new_n51_, new_n52_, new_n53_, new_n54_, new_n55_, new_n56_, new_n57_,
    new_n58_, new_n59_, new_n60_, new_n61_, new_n62_, new_n63_, new_n64_,
    new_n66_, new_n67_, new_n68_, new_n69_, new_n70_, new_n71_, new_n72_,
    new_n73_, new_n74_, new_n75_, new_n76_, new_n77_, new_n78_, new_n79_,
    new_n80_, new_n81_, new_n82_, new_n83_, new_n84_, new_n85_, new_n86_,
    new_n87_, new_n88_, new_n89_, new_n90_, new_n91_, new_n92_, new_n93_,
    new_n94_, new_n95_, new_n96_, new_n97_, new_n98_, new_n99_, new_n100_,
    new_n101_, new_n102_, new_n103_, new_n104_, new_n105_, new_n106_,
    new_n107_, new_n108_, new_n109_, new_n111_, new_n112_, new_n113_,
    new_n114_, new_n115_, new_n116_, new_n117_, new_n118_, new_n119_,
    new_n120_, new_n121_, new_n122_, new_n123_, new_n124_, new_n125_,
    new_n126_, new_n127_, new_n128_, new_n129_, new_n130_, new_n131_,
    new_n132_, new_n133_, new_n134_, new_n135_, new_n136_, new_n137_,
    new_n138_, new_n139_, new_n140_, new_n141_, new_n142_, new_n143_,
    new_n144_, new_n145_, new_n146_, new_n147_, new_n148_, new_n149_,
    new_n150_, new_n151_, new_n152_, new_n153_, new_n154_, new_n155_,
    new_n156_, new_n157_, new_n158_, new_n159_, new_n160_, new_n161_,
    new_n162_, new_n163_, new_n164_, new_n165_, new_n166_, new_n167_,
    new_n168_, new_n169_, new_n170_, new_n171_, new_n173_, new_n174_,
    new_n175_, new_n176_, new_n177_, new_n178_, new_n179_, new_n180_,
    new_n181_, new_n182_, new_n183_, new_n184_, new_n185_, new_n186_,
    new_n187_, new_n188_, new_n189_, new_n190_, new_n191_, new_n192_,
    new_n193_, new_n194_, new_n195_, new_n196_, new_n197_, new_n198_,
    new_n199_, new_n200_, new_n201_, new_n202_, new_n203_, new_n204_,
    new_n205_, new_n206_, new_n207_, new_n208_, new_n209_, new_n210_,
    new_n211_, new_n212_, new_n213_, new_n214_, new_n215_, new_n216_,
    new_n217_, new_n218_, new_n219_, new_n220_, new_n221_, new_n222_,
    new_n223_, new_n224_, new_n225_, new_n226_, new_n227_, new_n228_,
    new_n229_, new_n232_, new_n233_, new_n234_, new_n235_, new_n236_,
    new_n237_, new_n238_, new_n239_, new_n240_, new_n241_, new_n242_,
    new_n243_, new_n244_, new_n245_, new_n246_, new_n247_, new_n248_,
    new_n249_, new_n250_, new_n251_, new_n253_, new_n254_, new_n255_;
  INVx1_ASAP7_75t_R   g000(.A(p12), .Y(new_n44_));
  INVx1_ASAP7_75t_R   g001(.A(p3), .Y(new_n45_));
  NAND2x1_ASAP7_75t_R g002(.A(p4), .B(new_n45_), .Y(new_n46_));
  OAI21x1_ASAP7_75t_R g003(.A1(new_n44_), .A2(p11), .B(new_n46_), .Y(new_n47_));
  INVx1_ASAP7_75t_R   g004(.A(p13), .Y(new_n48_));
  NAND2x1_ASAP7_75t_R g005(.A(p14), .B(new_n48_), .Y(new_n49_));
  INVx1_ASAP7_75t_R   g006(.A(p15), .Y(new_n50_));
  NAND2x1_ASAP7_75t_R g007(.A(p16), .B(new_n50_), .Y(new_n51_));
  NAND2x1_ASAP7_75t_R g008(.A(new_n49_), .B(new_n51_), .Y(new_n52_));
  NOR2x1_ASAP7_75t_R  g009(.A(new_n47_), .B(new_n52_), .Y(new_n53_));
  INVx1_ASAP7_75t_R   g010(.A(p1), .Y(new_n54_));
  INVx1_ASAP7_75t_R   g011(.A(p0), .Y(new_n55_));
  NOR2x1_ASAP7_75t_R  g012(.A(p35), .B(new_n55_), .Y(new_n56_));
  AOI21x1_ASAP7_75t_R g013(.A1(p2), .A2(new_n54_), .B(new_n56_), .Y(new_n57_));
  INVx1_ASAP7_75t_R   g014(.A(p7), .Y(new_n58_));
  NAND2x1_ASAP7_75t_R g015(.A(p8), .B(new_n58_), .Y(new_n59_));
  INVx1_ASAP7_75t_R   g016(.A(p9), .Y(new_n60_));
  NAND2x1_ASAP7_75t_R g017(.A(p10), .B(new_n60_), .Y(new_n61_));
  INVx1_ASAP7_75t_R   g018(.A(p5), .Y(new_n62_));
  NAND2x1_ASAP7_75t_R g019(.A(p6), .B(new_n62_), .Y(new_n63_));
  AND3x1_ASAP7_75t_R  g020(.A(new_n59_), .B(new_n61_), .C(new_n63_), .Y(new_n64_));
  NAND3x1_ASAP7_75t_R g021(.A(new_n53_), .B(new_n57_), .C(new_n64_), .Y(o0));
  INVx1_ASAP7_75t_R   g022(.A(p11), .Y(new_n66_));
  INVx1_ASAP7_75t_R   g023(.A(p4), .Y(new_n67_));
  NOR2x1_ASAP7_75t_R  g024(.A(p3), .B(new_n67_), .Y(new_n68_));
  AOI21x1_ASAP7_75t_R g025(.A1(p12), .A2(new_n66_), .B(new_n68_), .Y(new_n69_));
  AND2x2_ASAP7_75t_R  g026(.A(new_n49_), .B(new_n51_), .Y(new_n70_));
  NAND2x1_ASAP7_75t_R g027(.A(new_n69_), .B(new_n70_), .Y(new_n71_));
  INVx1_ASAP7_75t_R   g028(.A(p8), .Y(new_n72_));
  NOR2x1_ASAP7_75t_R  g029(.A(p7), .B(new_n72_), .Y(new_n73_));
  AOI21x1_ASAP7_75t_R g030(.A1(p10), .A2(new_n60_), .B(new_n73_), .Y(new_n74_));
  NAND3x1_ASAP7_75t_R g031(.A(new_n57_), .B(new_n74_), .C(new_n63_), .Y(new_n75_));
  OA21x2_ASAP7_75t_R  g032(.A1(new_n71_), .A2(new_n75_), .B(p15), .Y(new_n76_));
  INVx1_ASAP7_75t_R   g033(.A(p25), .Y(new_n77_));
  NAND2x1_ASAP7_75t_R g034(.A(p16), .B(new_n77_), .Y(new_n78_));
  NAND2x1_ASAP7_75t_R g035(.A(new_n69_), .B(new_n57_), .Y(new_n79_));
  OAI21x1_ASAP7_75t_R g036(.A1(new_n52_), .A2(new_n79_), .B(p7), .Y(new_n80_));
  AO21x1_ASAP7_75t_R  g037(.A1(new_n63_), .A2(new_n74_), .B(new_n58_), .Y(new_n81_));
  NOR2x1_ASAP7_75t_R  g038(.A(p21), .B(new_n72_), .Y(new_n82_));
  NAND3x1_ASAP7_75t_R g039(.A(new_n80_), .B(new_n81_), .C(new_n82_), .Y(new_n83_));
  OAI21x1_ASAP7_75t_R g040(.A1(new_n76_), .A2(new_n78_), .B(new_n83_), .Y(new_n84_));
  OA21x2_ASAP7_75t_R  g041(.A1(new_n71_), .A2(new_n75_), .B(p9), .Y(new_n85_));
  INVx1_ASAP7_75t_R   g042(.A(p22), .Y(new_n86_));
  NAND2x1_ASAP7_75t_R g043(.A(p10), .B(new_n86_), .Y(new_n87_));
  INVx1_ASAP7_75t_R   g044(.A(p6), .Y(new_n88_));
  NOR2x1_ASAP7_75t_R  g045(.A(p20), .B(new_n88_), .Y(new_n89_));
  OAI21x1_ASAP7_75t_R g046(.A1(new_n71_), .A2(new_n75_), .B(p5), .Y(new_n90_));
  NAND2x1_ASAP7_75t_R g047(.A(new_n89_), .B(new_n90_), .Y(new_n91_));
  OAI21x1_ASAP7_75t_R g048(.A1(new_n85_), .A2(new_n87_), .B(new_n91_), .Y(new_n92_));
  NOR2x1_ASAP7_75t_R  g049(.A(new_n84_), .B(new_n92_), .Y(new_n93_));
  INVx1_ASAP7_75t_R   g050(.A(p17), .Y(new_n94_));
  NAND2x1_ASAP7_75t_R g051(.A(p0), .B(new_n94_), .Y(new_n95_));
  AOI21x1_ASAP7_75t_R g052(.A1(p35), .A2(o0), .B(new_n95_), .Y(new_n96_));
  INVx1_ASAP7_75t_R   g053(.A(p24), .Y(new_n97_));
  NAND2x1_ASAP7_75t_R g054(.A(p14), .B(new_n97_), .Y(new_n98_));
  AOI21x1_ASAP7_75t_R g055(.A1(p13), .A2(o0), .B(new_n98_), .Y(new_n99_));
  NOR2x1_ASAP7_75t_R  g056(.A(new_n96_), .B(new_n99_), .Y(new_n100_));
  NOR2x1_ASAP7_75t_R  g057(.A(p19), .B(new_n67_), .Y(new_n101_));
  INVx1_ASAP7_75t_R   g058(.A(new_n101_), .Y(new_n102_));
  AOI21x1_ASAP7_75t_R g059(.A1(new_n46_), .A2(o0), .B(new_n102_), .Y(new_n103_));
  OR2x4_ASAP7_75t_R   g060(.A(p23), .B(new_n44_), .Y(new_n104_));
  AOI21x1_ASAP7_75t_R g061(.A1(p11), .A2(o0), .B(new_n104_), .Y(new_n105_));
  INVx1_ASAP7_75t_R   g062(.A(p18), .Y(new_n106_));
  NAND2x1_ASAP7_75t_R g063(.A(p2), .B(new_n106_), .Y(new_n107_));
  AOI21x1_ASAP7_75t_R g064(.A1(p1), .A2(o0), .B(new_n107_), .Y(new_n108_));
  NOR3x1_ASAP7_75t_R  g065(.A(new_n103_), .B(new_n105_), .C(new_n108_), .Y(new_n109_));
  NAND3x1_ASAP7_75t_R g066(.A(new_n93_), .B(new_n100_), .C(new_n109_), .Y(o1));
  NOR2x1_ASAP7_75t_R  g067(.A(new_n105_), .B(new_n108_), .Y(new_n111_));
  AOI21x1_ASAP7_75t_R g068(.A1(p9), .A2(o0), .B(new_n87_), .Y(new_n112_));
  INVx1_ASAP7_75t_R   g069(.A(new_n89_), .Y(new_n113_));
  AOI21x1_ASAP7_75t_R g070(.A1(p5), .A2(o0), .B(new_n113_), .Y(new_n114_));
  NOR2x1_ASAP7_75t_R  g071(.A(new_n112_), .B(new_n114_), .Y(new_n115_));
  INVx1_ASAP7_75t_R   g072(.A(new_n103_), .Y(new_n116_));
  AND3x1_ASAP7_75t_R  g073(.A(new_n111_), .B(new_n115_), .C(new_n116_), .Y(new_n117_));
  INVx1_ASAP7_75t_R   g074(.A(o0), .Y(new_n118_));
  OA21x2_ASAP7_75t_R  g075(.A1(new_n54_), .A2(new_n118_), .B(p2), .Y(new_n119_));
  AOI21x1_ASAP7_75t_R g076(.A1(p15), .A2(o0), .B(new_n78_), .Y(new_n120_));
  INVx1_ASAP7_75t_R   g077(.A(new_n82_), .Y(new_n121_));
  AOI21x1_ASAP7_75t_R g078(.A1(p7), .A2(o0), .B(new_n121_), .Y(new_n122_));
  NOR2x1_ASAP7_75t_R  g079(.A(new_n120_), .B(new_n122_), .Y(new_n123_));
  AND3x1_ASAP7_75t_R  g080(.A(new_n100_), .B(new_n119_), .C(new_n123_), .Y(new_n124_));
  AOI21x1_ASAP7_75t_R g081(.A1(new_n117_), .A2(new_n124_), .B(new_n108_), .Y(new_n125_));
  NOR3x1_ASAP7_75t_R  g082(.A(new_n122_), .B(new_n112_), .C(new_n114_), .Y(new_n126_));
  NOR3x1_ASAP7_75t_R  g083(.A(new_n96_), .B(new_n99_), .C(new_n120_), .Y(new_n127_));
  AOI21x1_ASAP7_75t_R g084(.A1(new_n126_), .A2(new_n127_), .B(new_n94_), .Y(new_n128_));
  NOR2x1_ASAP7_75t_R  g085(.A(new_n94_), .B(new_n109_), .Y(new_n129_));
  INVx1_ASAP7_75t_R   g086(.A(p26), .Y(new_n130_));
  NAND2x1_ASAP7_75t_R g087(.A(p0), .B(new_n130_), .Y(new_n131_));
  AO21x1_ASAP7_75t_R  g088(.A1(p35), .A2(o0), .B(new_n131_), .Y(new_n132_));
  OR3x1_ASAP7_75t_R   g089(.A(new_n128_), .B(new_n129_), .C(new_n132_), .Y(new_n133_));
  OAI21x1_ASAP7_75t_R g090(.A1(p27), .A2(new_n125_), .B(new_n133_), .Y(new_n134_));
  AO21x1_ASAP7_75t_R  g091(.A1(p11), .A2(o0), .B(new_n44_), .Y(new_n135_));
  NOR2x1_ASAP7_75t_R  g092(.A(p32), .B(new_n135_), .Y(new_n136_));
  INVx1_ASAP7_75t_R   g093(.A(new_n136_), .Y(new_n137_));
  AOI21x1_ASAP7_75t_R g094(.A1(p23), .A2(o1), .B(new_n137_), .Y(new_n138_));
  INVx1_ASAP7_75t_R   g095(.A(p28), .Y(new_n139_));
  AO21x1_ASAP7_75t_R  g096(.A1(p4), .A2(new_n118_), .B(new_n68_), .Y(new_n140_));
  NAND2x1_ASAP7_75t_R g097(.A(new_n139_), .B(new_n140_), .Y(new_n141_));
  AOI21x1_ASAP7_75t_R g098(.A1(p19), .A2(o1), .B(new_n141_), .Y(new_n142_));
  NOR3x1_ASAP7_75t_R  g099(.A(new_n134_), .B(new_n138_), .C(new_n142_), .Y(new_n143_));
  NOR2x1_ASAP7_75t_R  g100(.A(p29), .B(new_n88_), .Y(new_n144_));
  NAND2x1_ASAP7_75t_R g101(.A(new_n144_), .B(new_n90_), .Y(new_n145_));
  AO21x1_ASAP7_75t_R  g102(.A1(p20), .A2(o1), .B(new_n145_), .Y(new_n146_));
  INVx1_ASAP7_75t_R   g103(.A(p30), .Y(new_n147_));
  AND3x1_ASAP7_75t_R  g104(.A(new_n80_), .B(p8), .C(new_n81_), .Y(new_n148_));
  NAND2x1_ASAP7_75t_R g105(.A(new_n147_), .B(new_n148_), .Y(new_n149_));
  AO21x1_ASAP7_75t_R  g106(.A1(p21), .A2(o1), .B(new_n149_), .Y(new_n150_));
  NAND2x1_ASAP7_75t_R g107(.A(new_n100_), .B(new_n123_), .Y(new_n151_));
  NAND3x1_ASAP7_75t_R g108(.A(new_n111_), .B(new_n115_), .C(new_n116_), .Y(new_n152_));
  NOR2x1_ASAP7_75t_R  g109(.A(new_n151_), .B(new_n152_), .Y(new_n153_));
  INVx1_ASAP7_75t_R   g110(.A(p31), .Y(new_n154_));
  OA21x2_ASAP7_75t_R  g111(.A1(new_n60_), .A2(new_n118_), .B(p10), .Y(new_n155_));
  AND2x2_ASAP7_75t_R  g112(.A(new_n154_), .B(new_n155_), .Y(new_n156_));
  OAI21x1_ASAP7_75t_R g113(.A1(new_n86_), .A2(new_n153_), .B(new_n156_), .Y(new_n157_));
  AND3x1_ASAP7_75t_R  g114(.A(new_n146_), .B(new_n150_), .C(new_n157_), .Y(new_n158_));
  OAI21x1_ASAP7_75t_R g115(.A1(new_n151_), .A2(new_n152_), .B(p25), .Y(new_n159_));
  INVx1_ASAP7_75t_R   g116(.A(new_n76_), .Y(new_n160_));
  INVx1_ASAP7_75t_R   g117(.A(p34), .Y(new_n161_));
  AND3x1_ASAP7_75t_R  g118(.A(new_n160_), .B(new_n161_), .C(p16), .Y(new_n162_));
  AOI21x1_ASAP7_75t_R g119(.A1(new_n126_), .A2(new_n127_), .B(new_n97_), .Y(new_n163_));
  NOR2x1_ASAP7_75t_R  g120(.A(new_n97_), .B(new_n109_), .Y(new_n164_));
  AND3x1_ASAP7_75t_R  g121(.A(new_n70_), .B(new_n69_), .C(new_n57_), .Y(new_n165_));
  AO21x1_ASAP7_75t_R  g122(.A1(new_n64_), .A2(new_n165_), .B(new_n48_), .Y(new_n166_));
  INVx1_ASAP7_75t_R   g123(.A(p33), .Y(new_n167_));
  NAND3x1_ASAP7_75t_R g124(.A(new_n166_), .B(new_n167_), .C(p14), .Y(new_n168_));
  NOR3x1_ASAP7_75t_R  g125(.A(new_n163_), .B(new_n164_), .C(new_n168_), .Y(new_n169_));
  AOI21x1_ASAP7_75t_R g126(.A1(new_n159_), .A2(new_n162_), .B(new_n169_), .Y(new_n170_));
  AND3x1_ASAP7_75t_R  g127(.A(new_n143_), .B(new_n158_), .C(new_n170_), .Y(new_n171_));
  INVx1_ASAP7_75t_R   g128(.A(new_n171_), .Y(o2));
  AOI21x1_ASAP7_75t_R g129(.A1(new_n170_), .A2(new_n143_), .B(new_n139_), .Y(new_n173_));
  INVx1_ASAP7_75t_R   g130(.A(p19), .Y(new_n174_));
  OA21x2_ASAP7_75t_R  g131(.A1(new_n174_), .A2(new_n153_), .B(new_n140_), .Y(new_n175_));
  OAI21x1_ASAP7_75t_R g132(.A1(new_n139_), .A2(new_n158_), .B(new_n175_), .Y(new_n176_));
  NAND2x1_ASAP7_75t_R g133(.A(p6), .B(new_n90_), .Y(new_n177_));
  AO21x1_ASAP7_75t_R  g134(.A1(p20), .A2(o1), .B(new_n177_), .Y(new_n178_));
  INVx1_ASAP7_75t_R   g135(.A(p21), .Y(new_n179_));
  AOI21x1_ASAP7_75t_R g136(.A1(new_n127_), .A2(new_n126_), .B(new_n179_), .Y(new_n180_));
  AO21x1_ASAP7_75t_R  g137(.A1(new_n64_), .A2(new_n165_), .B(new_n58_), .Y(new_n181_));
  OAI21x1_ASAP7_75t_R g138(.A1(new_n179_), .A2(new_n109_), .B(new_n181_), .Y(new_n182_));
  OR3x1_ASAP7_75t_R   g139(.A(new_n180_), .B(new_n182_), .C(new_n72_), .Y(new_n183_));
  OAI21x1_ASAP7_75t_R g140(.A1(p30), .A2(new_n183_), .B(new_n157_), .Y(new_n184_));
  NOR2x1_ASAP7_75t_R  g141(.A(new_n178_), .B(new_n184_), .Y(new_n185_));
  OA21x2_ASAP7_75t_R  g142(.A1(new_n151_), .A2(new_n152_), .B(p19), .Y(new_n186_));
  OAI21x1_ASAP7_75t_R g143(.A1(new_n151_), .A2(new_n152_), .B(p23), .Y(new_n187_));
  NAND2x1_ASAP7_75t_R g144(.A(new_n136_), .B(new_n187_), .Y(new_n188_));
  OAI21x1_ASAP7_75t_R g145(.A1(new_n186_), .A2(new_n141_), .B(new_n188_), .Y(new_n189_));
  AO21x1_ASAP7_75t_R  g146(.A1(new_n159_), .A2(new_n162_), .B(new_n169_), .Y(new_n190_));
  NOR3x1_ASAP7_75t_R  g147(.A(new_n189_), .B(new_n190_), .C(new_n134_), .Y(new_n191_));
  AOI21x1_ASAP7_75t_R g148(.A1(p20), .A2(o1), .B(new_n145_), .Y(new_n192_));
  AOI21x1_ASAP7_75t_R g149(.A1(new_n185_), .A2(new_n191_), .B(new_n192_), .Y(new_n193_));
  OAI21x1_ASAP7_75t_R g150(.A1(new_n173_), .A2(new_n176_), .B(new_n193_), .Y(new_n194_));
  AOI21x1_ASAP7_75t_R g151(.A1(p21), .A2(o1), .B(new_n149_), .Y(new_n195_));
  INVx1_ASAP7_75t_R   g152(.A(new_n156_), .Y(new_n196_));
  AOI21x1_ASAP7_75t_R g153(.A1(p22), .A2(o1), .B(new_n196_), .Y(new_n197_));
  OR3x1_ASAP7_75t_R   g154(.A(new_n192_), .B(new_n195_), .C(new_n197_), .Y(new_n198_));
  AO21x1_ASAP7_75t_R  g155(.A1(p35), .A2(o0), .B(new_n55_), .Y(new_n199_));
  OR3x1_ASAP7_75t_R   g156(.A(new_n128_), .B(new_n129_), .C(new_n199_), .Y(new_n200_));
  AO21x1_ASAP7_75t_R  g157(.A1(p26), .A2(new_n198_), .B(new_n200_), .Y(new_n201_));
  NOR2x1_ASAP7_75t_R  g158(.A(new_n130_), .B(new_n191_), .Y(new_n202_));
  NOR3x1_ASAP7_75t_R  g159(.A(new_n184_), .B(new_n192_), .C(new_n125_), .Y(new_n203_));
  NOR2x1_ASAP7_75t_R  g160(.A(p27), .B(new_n125_), .Y(new_n204_));
  AOI21x1_ASAP7_75t_R g161(.A1(new_n191_), .A2(new_n203_), .B(new_n204_), .Y(new_n205_));
  OAI21x1_ASAP7_75t_R g162(.A1(new_n201_), .A2(new_n202_), .B(new_n205_), .Y(new_n206_));
  NOR2x1_ASAP7_75t_R  g163(.A(new_n194_), .B(new_n206_), .Y(new_n207_));
  AOI21x1_ASAP7_75t_R g164(.A1(new_n170_), .A2(new_n143_), .B(new_n147_), .Y(new_n208_));
  AO21x1_ASAP7_75t_R  g165(.A1(p30), .A2(new_n198_), .B(new_n183_), .Y(new_n209_));
  OA21x2_ASAP7_75t_R  g166(.A1(new_n86_), .A2(new_n153_), .B(new_n155_), .Y(new_n210_));
  INVx1_ASAP7_75t_R   g167(.A(new_n210_), .Y(new_n211_));
  AOI21x1_ASAP7_75t_R g168(.A1(new_n146_), .A2(new_n150_), .B(new_n154_), .Y(new_n212_));
  NOR2x1_ASAP7_75t_R  g169(.A(new_n211_), .B(new_n212_), .Y(new_n213_));
  OAI21x1_ASAP7_75t_R g170(.A1(new_n154_), .A2(new_n191_), .B(new_n213_), .Y(new_n214_));
  OAI21x1_ASAP7_75t_R g171(.A1(new_n208_), .A2(new_n209_), .B(new_n214_), .Y(new_n215_));
  INVx1_ASAP7_75t_R   g172(.A(p32), .Y(new_n216_));
  INVx1_ASAP7_75t_R   g173(.A(new_n135_), .Y(new_n217_));
  AND2x2_ASAP7_75t_R  g174(.A(new_n217_), .B(new_n187_), .Y(new_n218_));
  OAI21x1_ASAP7_75t_R g175(.A1(new_n216_), .A2(new_n158_), .B(new_n218_), .Y(new_n219_));
  NOR2x1_ASAP7_75t_R  g176(.A(new_n216_), .B(new_n191_), .Y(new_n220_));
  NAND2x1_ASAP7_75t_R g177(.A(p14), .B(new_n166_), .Y(new_n221_));
  OR3x1_ASAP7_75t_R   g178(.A(new_n163_), .B(new_n164_), .C(new_n221_), .Y(new_n222_));
  NOR3x1_ASAP7_75t_R  g179(.A(new_n184_), .B(new_n192_), .C(new_n222_), .Y(new_n223_));
  AOI21x1_ASAP7_75t_R g180(.A1(new_n191_), .A2(new_n223_), .B(new_n169_), .Y(new_n224_));
  OAI21x1_ASAP7_75t_R g181(.A1(new_n219_), .A2(new_n220_), .B(new_n224_), .Y(new_n225_));
  NOR2x1_ASAP7_75t_R  g182(.A(new_n215_), .B(new_n225_), .Y(new_n226_));
  AO21x1_ASAP7_75t_R  g183(.A1(new_n158_), .A2(new_n191_), .B(new_n161_), .Y(new_n227_));
  AND2x2_ASAP7_75t_R  g184(.A(p16), .B(new_n160_), .Y(new_n228_));
  AND3x1_ASAP7_75t_R  g185(.A(new_n227_), .B(new_n159_), .C(new_n228_), .Y(new_n229_));
  AOI21x1_ASAP7_75t_R g186(.A1(new_n207_), .A2(new_n226_), .B(new_n229_), .Y(o3));
  INVx1_ASAP7_75t_R   g187(.A(new_n226_), .Y(o4));
  NOR2x1_ASAP7_75t_R  g188(.A(new_n138_), .B(new_n142_), .Y(new_n232_));
  INVx1_ASAP7_75t_R   g189(.A(p27), .Y(new_n233_));
  AO21x1_ASAP7_75t_R  g190(.A1(new_n117_), .A2(new_n124_), .B(new_n108_), .Y(new_n234_));
  NOR3x1_ASAP7_75t_R  g191(.A(new_n128_), .B(new_n129_), .C(new_n132_), .Y(new_n235_));
  AOI21x1_ASAP7_75t_R g192(.A1(new_n233_), .A2(new_n234_), .B(new_n235_), .Y(new_n236_));
  NAND3x1_ASAP7_75t_R g193(.A(new_n232_), .B(new_n170_), .C(new_n236_), .Y(new_n237_));
  NOR2x1_ASAP7_75t_R  g194(.A(new_n195_), .B(new_n197_), .Y(new_n238_));
  INVx1_ASAP7_75t_R   g195(.A(new_n183_), .Y(new_n239_));
  NAND3x1_ASAP7_75t_R g196(.A(new_n238_), .B(new_n146_), .C(new_n239_), .Y(new_n240_));
  NOR2x1_ASAP7_75t_R  g197(.A(new_n237_), .B(new_n240_), .Y(new_n241_));
  NAND3x1_ASAP7_75t_R g198(.A(new_n238_), .B(new_n146_), .C(new_n210_), .Y(new_n242_));
  OAI21x1_ASAP7_75t_R g199(.A1(new_n237_), .A2(new_n242_), .B(new_n238_), .Y(new_n243_));
  NOR2x1_ASAP7_75t_R  g200(.A(new_n241_), .B(new_n243_), .Y(new_n244_));
  NAND3x1_ASAP7_75t_R g201(.A(new_n238_), .B(new_n146_), .C(new_n218_), .Y(new_n245_));
  OAI21x1_ASAP7_75t_R g202(.A1(new_n237_), .A2(new_n245_), .B(new_n188_), .Y(new_n246_));
  NOR2x1_ASAP7_75t_R  g203(.A(new_n193_), .B(new_n246_), .Y(new_n247_));
  NAND2x1_ASAP7_75t_R g204(.A(new_n244_), .B(new_n247_), .Y(new_n248_));
  AND3x1_ASAP7_75t_R  g205(.A(new_n238_), .B(new_n146_), .C(new_n175_), .Y(new_n249_));
  AO21x1_ASAP7_75t_R  g206(.A1(new_n191_), .A2(new_n249_), .B(new_n142_), .Y(new_n250_));
  AOI21x1_ASAP7_75t_R g207(.A1(new_n250_), .A2(new_n244_), .B(new_n225_), .Y(new_n251_));
  NAND2x1_ASAP7_75t_R g208(.A(new_n248_), .B(new_n251_), .Y(o5));
  OA21x2_ASAP7_75t_R  g209(.A1(new_n205_), .A2(new_n250_), .B(new_n214_), .Y(new_n253_));
  INVx1_ASAP7_75t_R   g210(.A(new_n224_), .Y(new_n254_));
  AOI21x1_ASAP7_75t_R g211(.A1(new_n244_), .A2(new_n247_), .B(new_n254_), .Y(new_n255_));
  OAI21x1_ASAP7_75t_R g212(.A1(new_n246_), .A2(new_n253_), .B(new_n255_), .Y(o6));
endmodule


