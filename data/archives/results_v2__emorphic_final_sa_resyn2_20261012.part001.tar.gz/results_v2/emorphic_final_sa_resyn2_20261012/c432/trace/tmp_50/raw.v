// Benchmark "/tmp/" written by ABC on Mon Oct 12 14:43:41 2026

module \/tmp/  ( 
    p11, p4, p25, p0, p7, p32, p18, p15, p26, p28, p27, p31, p22, p9, p16,
    p29, p20, p21, p6, p35, p1, p8, p10, p14, p30, p24, p17, p3, p5, p13,
    p12, p34, p23, p19, p2, p33,
    o0, o1, o2, o3, o4, o5, o6  );
  input  p11, p4, p25, p0, p7, p32, p18, p15, p26, p28, p27, p31, p22,
    p9, p16, p29, p20, p21, p6, p35, p1, p8, p10, p14, p30, p24, p17, p3,
    p5, p13, p12, p34, p23, p19, p2, p33;
  output o0, o1, o2, o3, o4, o5, o6;
  wire new_n44_, new_n45_, new_n46_, new_n47_, new_n48_, new_n49_, new_n50_,
    new_n51_, new_n52_, new_n53_, new_n54_, new_n55_, new_n56_, new_n57_,
    new_n58_, new_n59_, new_n60_, new_n61_, new_n62_, new_n63_, new_n65_,
    new_n66_, new_n67_, new_n68_, new_n69_, new_n70_, new_n71_, new_n72_,
    new_n73_, new_n74_, new_n75_, new_n76_, new_n77_, new_n78_, new_n79_,
    new_n80_, new_n81_, new_n82_, new_n83_, new_n84_, new_n85_, new_n86_,
    new_n87_, new_n88_, new_n89_, new_n90_, new_n91_, new_n92_, new_n93_,
    new_n94_, new_n95_, new_n96_, new_n97_, new_n98_, new_n99_, new_n100_,
    new_n101_, new_n102_, new_n103_, new_n104_, new_n105_, new_n106_,
    new_n107_, new_n109_, new_n110_, new_n111_, new_n112_, new_n113_,
    new_n114_, new_n115_, new_n116_, new_n117_, new_n118_, new_n119_,
    new_n120_, new_n121_, new_n122_, new_n123_, new_n124_, new_n125_,
    new_n126_, new_n127_, new_n128_, new_n129_, new_n130_, new_n131_,
    new_n132_, new_n133_, new_n134_, new_n135_, new_n136_, new_n137_,
    new_n138_, new_n139_, new_n140_, new_n141_, new_n142_, new_n143_,
    new_n144_, new_n145_, new_n146_, new_n147_, new_n148_, new_n149_,
    new_n150_, new_n151_, new_n152_, new_n153_, new_n154_, new_n155_,
    new_n156_, new_n157_, new_n158_, new_n159_, new_n160_, new_n161_,
    new_n162_, new_n163_, new_n164_, new_n165_, new_n166_, new_n167_,
    new_n169_, new_n170_, new_n171_, new_n172_, new_n173_, new_n174_,
    new_n175_, new_n176_, new_n177_, new_n178_, new_n179_, new_n180_,
    new_n181_, new_n182_, new_n183_, new_n184_, new_n185_, new_n186_,
    new_n187_, new_n188_, new_n189_, new_n190_, new_n191_, new_n192_,
    new_n193_, new_n194_, new_n195_, new_n196_, new_n197_, new_n198_,
    new_n199_, new_n200_, new_n201_, new_n202_, new_n203_, new_n204_,
    new_n205_, new_n206_, new_n207_, new_n208_, new_n209_, new_n210_,
    new_n211_, new_n212_, new_n213_, new_n214_, new_n215_, new_n216_,
    new_n217_, new_n218_, new_n219_, new_n220_, new_n221_, new_n222_,
    new_n223_, new_n224_, new_n225_, new_n228_, new_n229_, new_n230_,
    new_n231_, new_n232_, new_n233_, new_n234_, new_n235_, new_n236_,
    new_n237_, new_n238_, new_n239_, new_n240_, new_n241_, new_n242_,
    new_n243_, new_n244_, new_n245_, new_n246_, new_n247_, new_n249_,
    new_n250_, new_n251_;
  INVx1_ASAP7_75t_R   g000(.A(p14), .Y(new_n44_));
  INVx1_ASAP7_75t_R   g001(.A(p15), .Y(new_n45_));
  NAND2x1_ASAP7_75t_R g002(.A(p16), .B(new_n45_), .Y(new_n46_));
  OAI21x1_ASAP7_75t_R g003(.A1(new_n44_), .A2(p13), .B(new_n46_), .Y(new_n47_));
  INVx1_ASAP7_75t_R   g004(.A(p12), .Y(new_n48_));
  INVx1_ASAP7_75t_R   g005(.A(p3), .Y(new_n49_));
  NAND2x1_ASAP7_75t_R g006(.A(p4), .B(new_n49_), .Y(new_n50_));
  OAI21x1_ASAP7_75t_R g007(.A1(p11), .A2(new_n48_), .B(new_n50_), .Y(new_n51_));
  NOR2x1_ASAP7_75t_R  g008(.A(new_n47_), .B(new_n51_), .Y(new_n52_));
  INVx1_ASAP7_75t_R   g009(.A(p35), .Y(new_n53_));
  INVx1_ASAP7_75t_R   g010(.A(p2), .Y(new_n54_));
  NOR2x1_ASAP7_75t_R  g011(.A(p1), .B(new_n54_), .Y(new_n55_));
  AOI21x1_ASAP7_75t_R g012(.A1(p0), .A2(new_n53_), .B(new_n55_), .Y(new_n56_));
  INVx1_ASAP7_75t_R   g013(.A(p7), .Y(new_n57_));
  NAND2x1_ASAP7_75t_R g014(.A(p8), .B(new_n57_), .Y(new_n58_));
  INVx1_ASAP7_75t_R   g015(.A(p5), .Y(new_n59_));
  NAND2x1_ASAP7_75t_R g016(.A(p6), .B(new_n59_), .Y(new_n60_));
  INVx1_ASAP7_75t_R   g017(.A(p9), .Y(new_n61_));
  NAND2x1_ASAP7_75t_R g018(.A(p10), .B(new_n61_), .Y(new_n62_));
  AND3x1_ASAP7_75t_R  g019(.A(new_n58_), .B(new_n60_), .C(new_n62_), .Y(new_n63_));
  NAND3x1_ASAP7_75t_R g020(.A(new_n52_), .B(new_n56_), .C(new_n63_), .Y(o0));
  INVx1_ASAP7_75t_R   g021(.A(p11), .Y(new_n65_));
  INVx1_ASAP7_75t_R   g022(.A(p4), .Y(new_n66_));
  NOR2x1_ASAP7_75t_R  g023(.A(p3), .B(new_n66_), .Y(new_n67_));
  AOI21x1_ASAP7_75t_R g024(.A1(new_n65_), .A2(p12), .B(new_n67_), .Y(new_n68_));
  OR2x4_ASAP7_75t_R   g025(.A(p13), .B(new_n44_), .Y(new_n69_));
  NAND3x1_ASAP7_75t_R g026(.A(new_n68_), .B(new_n46_), .C(new_n69_), .Y(new_n70_));
  INVx1_ASAP7_75t_R   g027(.A(p8), .Y(new_n71_));
  NOR2x1_ASAP7_75t_R  g028(.A(p7), .B(new_n71_), .Y(new_n72_));
  AOI21x1_ASAP7_75t_R g029(.A1(new_n61_), .A2(p10), .B(new_n72_), .Y(new_n73_));
  NAND3x1_ASAP7_75t_R g030(.A(new_n56_), .B(new_n73_), .C(new_n60_), .Y(new_n74_));
  OA21x2_ASAP7_75t_R  g031(.A1(new_n70_), .A2(new_n74_), .B(p15), .Y(new_n75_));
  INVx1_ASAP7_75t_R   g032(.A(p25), .Y(new_n76_));
  NAND2x1_ASAP7_75t_R g033(.A(p16), .B(new_n76_), .Y(new_n77_));
  NAND2x1_ASAP7_75t_R g034(.A(new_n68_), .B(new_n56_), .Y(new_n78_));
  OAI21x1_ASAP7_75t_R g035(.A1(new_n47_), .A2(new_n78_), .B(p7), .Y(new_n79_));
  AO21x1_ASAP7_75t_R  g036(.A1(new_n60_), .A2(new_n73_), .B(new_n57_), .Y(new_n80_));
  NOR2x1_ASAP7_75t_R  g037(.A(p21), .B(new_n71_), .Y(new_n81_));
  NAND3x1_ASAP7_75t_R g038(.A(new_n79_), .B(new_n80_), .C(new_n81_), .Y(new_n82_));
  OAI21x1_ASAP7_75t_R g039(.A1(new_n75_), .A2(new_n77_), .B(new_n82_), .Y(new_n83_));
  INVx1_ASAP7_75t_R   g040(.A(p22), .Y(new_n84_));
  NAND2x1_ASAP7_75t_R g041(.A(p10), .B(new_n84_), .Y(new_n85_));
  OA21x2_ASAP7_75t_R  g042(.A1(new_n70_), .A2(new_n74_), .B(p9), .Y(new_n86_));
  INVx1_ASAP7_75t_R   g043(.A(p6), .Y(new_n87_));
  NOR2x1_ASAP7_75t_R  g044(.A(p20), .B(new_n87_), .Y(new_n88_));
  OAI21x1_ASAP7_75t_R g045(.A1(new_n70_), .A2(new_n74_), .B(p5), .Y(new_n89_));
  NAND2x1_ASAP7_75t_R g046(.A(new_n88_), .B(new_n89_), .Y(new_n90_));
  OAI21x1_ASAP7_75t_R g047(.A1(new_n85_), .A2(new_n86_), .B(new_n90_), .Y(new_n91_));
  NOR2x1_ASAP7_75t_R  g048(.A(new_n83_), .B(new_n91_), .Y(new_n92_));
  INVx1_ASAP7_75t_R   g049(.A(p17), .Y(new_n93_));
  NAND2x1_ASAP7_75t_R g050(.A(p0), .B(new_n93_), .Y(new_n94_));
  AOI21x1_ASAP7_75t_R g051(.A1(p35), .A2(o0), .B(new_n94_), .Y(new_n95_));
  INVx1_ASAP7_75t_R   g052(.A(p24), .Y(new_n96_));
  NAND2x1_ASAP7_75t_R g053(.A(p14), .B(new_n96_), .Y(new_n97_));
  AOI21x1_ASAP7_75t_R g054(.A1(p13), .A2(o0), .B(new_n97_), .Y(new_n98_));
  NOR2x1_ASAP7_75t_R  g055(.A(new_n95_), .B(new_n98_), .Y(new_n99_));
  NOR2x1_ASAP7_75t_R  g056(.A(p19), .B(new_n66_), .Y(new_n100_));
  INVx1_ASAP7_75t_R   g057(.A(new_n100_), .Y(new_n101_));
  AOI21x1_ASAP7_75t_R g058(.A1(new_n50_), .A2(o0), .B(new_n101_), .Y(new_n102_));
  OR2x4_ASAP7_75t_R   g059(.A(p23), .B(new_n48_), .Y(new_n103_));
  AOI21x1_ASAP7_75t_R g060(.A1(p11), .A2(o0), .B(new_n103_), .Y(new_n104_));
  OR2x4_ASAP7_75t_R   g061(.A(p18), .B(new_n54_), .Y(new_n105_));
  AOI21x1_ASAP7_75t_R g062(.A1(p1), .A2(o0), .B(new_n105_), .Y(new_n106_));
  NOR3x1_ASAP7_75t_R  g063(.A(new_n102_), .B(new_n104_), .C(new_n106_), .Y(new_n107_));
  NAND3x1_ASAP7_75t_R g064(.A(new_n92_), .B(new_n99_), .C(new_n107_), .Y(o1));
  AOI21x1_ASAP7_75t_R g065(.A1(p15), .A2(o0), .B(new_n77_), .Y(new_n109_));
  INVx1_ASAP7_75t_R   g066(.A(new_n81_), .Y(new_n110_));
  AOI21x1_ASAP7_75t_R g067(.A1(p7), .A2(o0), .B(new_n110_), .Y(new_n111_));
  NOR2x1_ASAP7_75t_R  g068(.A(new_n109_), .B(new_n111_), .Y(new_n112_));
  AOI21x1_ASAP7_75t_R g069(.A1(p1), .A2(o0), .B(new_n54_), .Y(new_n113_));
  AND3x1_ASAP7_75t_R  g070(.A(new_n99_), .B(new_n112_), .C(new_n113_), .Y(new_n114_));
  NOR2x1_ASAP7_75t_R  g071(.A(new_n104_), .B(new_n106_), .Y(new_n115_));
  AOI21x1_ASAP7_75t_R g072(.A1(p9), .A2(o0), .B(new_n85_), .Y(new_n116_));
  INVx1_ASAP7_75t_R   g073(.A(new_n88_), .Y(new_n117_));
  AOI21x1_ASAP7_75t_R g074(.A1(p5), .A2(o0), .B(new_n117_), .Y(new_n118_));
  NOR2x1_ASAP7_75t_R  g075(.A(new_n116_), .B(new_n118_), .Y(new_n119_));
  INVx1_ASAP7_75t_R   g076(.A(new_n102_), .Y(new_n120_));
  AND3x1_ASAP7_75t_R  g077(.A(new_n115_), .B(new_n119_), .C(new_n120_), .Y(new_n121_));
  AOI21x1_ASAP7_75t_R g078(.A1(new_n114_), .A2(new_n121_), .B(new_n106_), .Y(new_n122_));
  NOR3x1_ASAP7_75t_R  g079(.A(new_n111_), .B(new_n116_), .C(new_n118_), .Y(new_n123_));
  NOR3x1_ASAP7_75t_R  g080(.A(new_n95_), .B(new_n98_), .C(new_n109_), .Y(new_n124_));
  AOI21x1_ASAP7_75t_R g081(.A1(new_n123_), .A2(new_n124_), .B(new_n93_), .Y(new_n125_));
  NOR2x1_ASAP7_75t_R  g082(.A(new_n93_), .B(new_n107_), .Y(new_n126_));
  NAND2x1_ASAP7_75t_R g083(.A(p35), .B(o0), .Y(new_n127_));
  INVx1_ASAP7_75t_R   g084(.A(p26), .Y(new_n128_));
  NAND3x1_ASAP7_75t_R g085(.A(new_n127_), .B(p0), .C(new_n128_), .Y(new_n129_));
  OR3x1_ASAP7_75t_R   g086(.A(new_n125_), .B(new_n126_), .C(new_n129_), .Y(new_n130_));
  OAI21x1_ASAP7_75t_R g087(.A1(p27), .A2(new_n122_), .B(new_n130_), .Y(new_n131_));
  AO21x1_ASAP7_75t_R  g088(.A1(p11), .A2(o0), .B(new_n48_), .Y(new_n132_));
  NOR2x1_ASAP7_75t_R  g089(.A(p32), .B(new_n132_), .Y(new_n133_));
  INVx1_ASAP7_75t_R   g090(.A(new_n133_), .Y(new_n134_));
  AOI21x1_ASAP7_75t_R g091(.A1(p23), .A2(o1), .B(new_n134_), .Y(new_n135_));
  INVx1_ASAP7_75t_R   g092(.A(p28), .Y(new_n136_));
  INVx1_ASAP7_75t_R   g093(.A(o0), .Y(new_n137_));
  AO21x1_ASAP7_75t_R  g094(.A1(p4), .A2(new_n137_), .B(new_n67_), .Y(new_n138_));
  NAND2x1_ASAP7_75t_R g095(.A(new_n136_), .B(new_n138_), .Y(new_n139_));
  AOI21x1_ASAP7_75t_R g096(.A1(p19), .A2(o1), .B(new_n139_), .Y(new_n140_));
  NOR3x1_ASAP7_75t_R  g097(.A(new_n131_), .B(new_n135_), .C(new_n140_), .Y(new_n141_));
  NOR2x1_ASAP7_75t_R  g098(.A(p29), .B(new_n87_), .Y(new_n142_));
  NAND2x1_ASAP7_75t_R g099(.A(new_n142_), .B(new_n89_), .Y(new_n143_));
  AO21x1_ASAP7_75t_R  g100(.A1(p20), .A2(o1), .B(new_n143_), .Y(new_n144_));
  INVx1_ASAP7_75t_R   g101(.A(p30), .Y(new_n145_));
  AND3x1_ASAP7_75t_R  g102(.A(new_n79_), .B(p8), .C(new_n80_), .Y(new_n146_));
  NAND2x1_ASAP7_75t_R g103(.A(new_n145_), .B(new_n146_), .Y(new_n147_));
  AO21x1_ASAP7_75t_R  g104(.A1(p21), .A2(o1), .B(new_n147_), .Y(new_n148_));
  NAND2x1_ASAP7_75t_R g105(.A(new_n99_), .B(new_n112_), .Y(new_n149_));
  NAND3x1_ASAP7_75t_R g106(.A(new_n115_), .B(new_n119_), .C(new_n120_), .Y(new_n150_));
  NOR2x1_ASAP7_75t_R  g107(.A(new_n149_), .B(new_n150_), .Y(new_n151_));
  INVx1_ASAP7_75t_R   g108(.A(p31), .Y(new_n152_));
  OA21x2_ASAP7_75t_R  g109(.A1(new_n61_), .A2(new_n137_), .B(p10), .Y(new_n153_));
  AND2x2_ASAP7_75t_R  g110(.A(new_n152_), .B(new_n153_), .Y(new_n154_));
  OAI21x1_ASAP7_75t_R g111(.A1(new_n84_), .A2(new_n151_), .B(new_n154_), .Y(new_n155_));
  AND3x1_ASAP7_75t_R  g112(.A(new_n144_), .B(new_n148_), .C(new_n155_), .Y(new_n156_));
  OAI21x1_ASAP7_75t_R g113(.A1(new_n149_), .A2(new_n150_), .B(p25), .Y(new_n157_));
  INVx1_ASAP7_75t_R   g114(.A(new_n75_), .Y(new_n158_));
  INVx1_ASAP7_75t_R   g115(.A(p34), .Y(new_n159_));
  AND3x1_ASAP7_75t_R  g116(.A(new_n158_), .B(p16), .C(new_n159_), .Y(new_n160_));
  AOI21x1_ASAP7_75t_R g117(.A1(new_n123_), .A2(new_n124_), .B(new_n96_), .Y(new_n161_));
  NOR2x1_ASAP7_75t_R  g118(.A(new_n96_), .B(new_n107_), .Y(new_n162_));
  AND2x2_ASAP7_75t_R  g119(.A(p13), .B(o0), .Y(new_n163_));
  OR3x1_ASAP7_75t_R   g120(.A(new_n163_), .B(new_n44_), .C(p33), .Y(new_n164_));
  NOR3x1_ASAP7_75t_R  g121(.A(new_n161_), .B(new_n162_), .C(new_n164_), .Y(new_n165_));
  AOI21x1_ASAP7_75t_R g122(.A1(new_n157_), .A2(new_n160_), .B(new_n165_), .Y(new_n166_));
  AND3x1_ASAP7_75t_R  g123(.A(new_n141_), .B(new_n156_), .C(new_n166_), .Y(new_n167_));
  INVx1_ASAP7_75t_R   g124(.A(new_n167_), .Y(o2));
  AOI21x1_ASAP7_75t_R g125(.A1(new_n166_), .A2(new_n141_), .B(new_n136_), .Y(new_n169_));
  INVx1_ASAP7_75t_R   g126(.A(p19), .Y(new_n170_));
  OA21x2_ASAP7_75t_R  g127(.A1(new_n170_), .A2(new_n151_), .B(new_n138_), .Y(new_n171_));
  OAI21x1_ASAP7_75t_R g128(.A1(new_n136_), .A2(new_n156_), .B(new_n171_), .Y(new_n172_));
  NAND2x1_ASAP7_75t_R g129(.A(p6), .B(new_n89_), .Y(new_n173_));
  AO21x1_ASAP7_75t_R  g130(.A1(p20), .A2(o1), .B(new_n173_), .Y(new_n174_));
  INVx1_ASAP7_75t_R   g131(.A(p21), .Y(new_n175_));
  AOI21x1_ASAP7_75t_R g132(.A1(new_n124_), .A2(new_n123_), .B(new_n175_), .Y(new_n176_));
  NAND2x1_ASAP7_75t_R g133(.A(p7), .B(o0), .Y(new_n177_));
  OAI21x1_ASAP7_75t_R g134(.A1(new_n175_), .A2(new_n107_), .B(new_n177_), .Y(new_n178_));
  OR3x1_ASAP7_75t_R   g135(.A(new_n176_), .B(new_n178_), .C(new_n71_), .Y(new_n179_));
  OAI21x1_ASAP7_75t_R g136(.A1(p30), .A2(new_n179_), .B(new_n155_), .Y(new_n180_));
  NOR2x1_ASAP7_75t_R  g137(.A(new_n174_), .B(new_n180_), .Y(new_n181_));
  OA21x2_ASAP7_75t_R  g138(.A1(new_n149_), .A2(new_n150_), .B(p19), .Y(new_n182_));
  OAI21x1_ASAP7_75t_R g139(.A1(new_n149_), .A2(new_n150_), .B(p23), .Y(new_n183_));
  NAND2x1_ASAP7_75t_R g140(.A(new_n133_), .B(new_n183_), .Y(new_n184_));
  OAI21x1_ASAP7_75t_R g141(.A1(new_n182_), .A2(new_n139_), .B(new_n184_), .Y(new_n185_));
  AO21x1_ASAP7_75t_R  g142(.A1(new_n157_), .A2(new_n160_), .B(new_n165_), .Y(new_n186_));
  NOR3x1_ASAP7_75t_R  g143(.A(new_n185_), .B(new_n186_), .C(new_n131_), .Y(new_n187_));
  AOI21x1_ASAP7_75t_R g144(.A1(p20), .A2(o1), .B(new_n143_), .Y(new_n188_));
  AOI21x1_ASAP7_75t_R g145(.A1(new_n181_), .A2(new_n187_), .B(new_n188_), .Y(new_n189_));
  OAI21x1_ASAP7_75t_R g146(.A1(new_n169_), .A2(new_n172_), .B(new_n189_), .Y(new_n190_));
  AOI21x1_ASAP7_75t_R g147(.A1(p21), .A2(o1), .B(new_n147_), .Y(new_n191_));
  INVx1_ASAP7_75t_R   g148(.A(new_n154_), .Y(new_n192_));
  AOI21x1_ASAP7_75t_R g149(.A1(p22), .A2(o1), .B(new_n192_), .Y(new_n193_));
  OR3x1_ASAP7_75t_R   g150(.A(new_n188_), .B(new_n191_), .C(new_n193_), .Y(new_n194_));
  NAND2x1_ASAP7_75t_R g151(.A(p0), .B(new_n127_), .Y(new_n195_));
  OR3x1_ASAP7_75t_R   g152(.A(new_n125_), .B(new_n126_), .C(new_n195_), .Y(new_n196_));
  AO21x1_ASAP7_75t_R  g153(.A1(p26), .A2(new_n194_), .B(new_n196_), .Y(new_n197_));
  NOR2x1_ASAP7_75t_R  g154(.A(new_n128_), .B(new_n187_), .Y(new_n198_));
  NOR3x1_ASAP7_75t_R  g155(.A(new_n180_), .B(new_n188_), .C(new_n122_), .Y(new_n199_));
  NOR2x1_ASAP7_75t_R  g156(.A(p27), .B(new_n122_), .Y(new_n200_));
  AOI21x1_ASAP7_75t_R g157(.A1(new_n187_), .A2(new_n199_), .B(new_n200_), .Y(new_n201_));
  OAI21x1_ASAP7_75t_R g158(.A1(new_n197_), .A2(new_n198_), .B(new_n201_), .Y(new_n202_));
  NOR2x1_ASAP7_75t_R  g159(.A(new_n190_), .B(new_n202_), .Y(new_n203_));
  AOI21x1_ASAP7_75t_R g160(.A1(new_n166_), .A2(new_n141_), .B(new_n145_), .Y(new_n204_));
  AO21x1_ASAP7_75t_R  g161(.A1(p30), .A2(new_n194_), .B(new_n179_), .Y(new_n205_));
  OA21x2_ASAP7_75t_R  g162(.A1(new_n84_), .A2(new_n151_), .B(new_n153_), .Y(new_n206_));
  INVx1_ASAP7_75t_R   g163(.A(new_n206_), .Y(new_n207_));
  AOI21x1_ASAP7_75t_R g164(.A1(new_n144_), .A2(new_n148_), .B(new_n152_), .Y(new_n208_));
  NOR2x1_ASAP7_75t_R  g165(.A(new_n207_), .B(new_n208_), .Y(new_n209_));
  OAI21x1_ASAP7_75t_R g166(.A1(new_n152_), .A2(new_n187_), .B(new_n209_), .Y(new_n210_));
  OAI21x1_ASAP7_75t_R g167(.A1(new_n204_), .A2(new_n205_), .B(new_n210_), .Y(new_n211_));
  INVx1_ASAP7_75t_R   g168(.A(p32), .Y(new_n212_));
  INVx1_ASAP7_75t_R   g169(.A(new_n132_), .Y(new_n213_));
  AND2x2_ASAP7_75t_R  g170(.A(new_n213_), .B(new_n183_), .Y(new_n214_));
  OAI21x1_ASAP7_75t_R g171(.A1(new_n212_), .A2(new_n156_), .B(new_n214_), .Y(new_n215_));
  NOR2x1_ASAP7_75t_R  g172(.A(new_n212_), .B(new_n187_), .Y(new_n216_));
  AO21x1_ASAP7_75t_R  g173(.A1(p13), .A2(o0), .B(new_n44_), .Y(new_n217_));
  OR3x1_ASAP7_75t_R   g174(.A(new_n161_), .B(new_n162_), .C(new_n217_), .Y(new_n218_));
  NOR3x1_ASAP7_75t_R  g175(.A(new_n180_), .B(new_n188_), .C(new_n218_), .Y(new_n219_));
  AOI21x1_ASAP7_75t_R g176(.A1(new_n187_), .A2(new_n219_), .B(new_n165_), .Y(new_n220_));
  OAI21x1_ASAP7_75t_R g177(.A1(new_n215_), .A2(new_n216_), .B(new_n220_), .Y(new_n221_));
  NOR2x1_ASAP7_75t_R  g178(.A(new_n211_), .B(new_n221_), .Y(new_n222_));
  AO21x1_ASAP7_75t_R  g179(.A1(new_n156_), .A2(new_n187_), .B(new_n159_), .Y(new_n223_));
  AND2x2_ASAP7_75t_R  g180(.A(p16), .B(new_n158_), .Y(new_n224_));
  AND3x1_ASAP7_75t_R  g181(.A(new_n223_), .B(new_n157_), .C(new_n224_), .Y(new_n225_));
  AOI21x1_ASAP7_75t_R g182(.A1(new_n203_), .A2(new_n222_), .B(new_n225_), .Y(o3));
  INVx1_ASAP7_75t_R   g183(.A(new_n222_), .Y(o4));
  NOR2x1_ASAP7_75t_R  g184(.A(new_n135_), .B(new_n140_), .Y(new_n228_));
  INVx1_ASAP7_75t_R   g185(.A(p27), .Y(new_n229_));
  AO21x1_ASAP7_75t_R  g186(.A1(new_n114_), .A2(new_n121_), .B(new_n106_), .Y(new_n230_));
  NOR3x1_ASAP7_75t_R  g187(.A(new_n125_), .B(new_n126_), .C(new_n129_), .Y(new_n231_));
  AOI21x1_ASAP7_75t_R g188(.A1(new_n229_), .A2(new_n230_), .B(new_n231_), .Y(new_n232_));
  NAND3x1_ASAP7_75t_R g189(.A(new_n228_), .B(new_n166_), .C(new_n232_), .Y(new_n233_));
  NOR2x1_ASAP7_75t_R  g190(.A(new_n191_), .B(new_n193_), .Y(new_n234_));
  INVx1_ASAP7_75t_R   g191(.A(new_n179_), .Y(new_n235_));
  NAND3x1_ASAP7_75t_R g192(.A(new_n234_), .B(new_n144_), .C(new_n235_), .Y(new_n236_));
  NOR2x1_ASAP7_75t_R  g193(.A(new_n233_), .B(new_n236_), .Y(new_n237_));
  NAND3x1_ASAP7_75t_R g194(.A(new_n234_), .B(new_n144_), .C(new_n206_), .Y(new_n238_));
  OAI21x1_ASAP7_75t_R g195(.A1(new_n233_), .A2(new_n238_), .B(new_n234_), .Y(new_n239_));
  NOR2x1_ASAP7_75t_R  g196(.A(new_n237_), .B(new_n239_), .Y(new_n240_));
  NAND3x1_ASAP7_75t_R g197(.A(new_n234_), .B(new_n144_), .C(new_n214_), .Y(new_n241_));
  OAI21x1_ASAP7_75t_R g198(.A1(new_n233_), .A2(new_n241_), .B(new_n184_), .Y(new_n242_));
  NOR2x1_ASAP7_75t_R  g199(.A(new_n189_), .B(new_n242_), .Y(new_n243_));
  NAND2x1_ASAP7_75t_R g200(.A(new_n240_), .B(new_n243_), .Y(new_n244_));
  AND3x1_ASAP7_75t_R  g201(.A(new_n234_), .B(new_n144_), .C(new_n171_), .Y(new_n245_));
  AO21x1_ASAP7_75t_R  g202(.A1(new_n187_), .A2(new_n245_), .B(new_n140_), .Y(new_n246_));
  AOI21x1_ASAP7_75t_R g203(.A1(new_n246_), .A2(new_n240_), .B(new_n221_), .Y(new_n247_));
  NAND2x1_ASAP7_75t_R g204(.A(new_n244_), .B(new_n247_), .Y(o5));
  OA21x2_ASAP7_75t_R  g205(.A1(new_n201_), .A2(new_n246_), .B(new_n210_), .Y(new_n249_));
  INVx1_ASAP7_75t_R   g206(.A(new_n220_), .Y(new_n250_));
  AOI21x1_ASAP7_75t_R g207(.A1(new_n240_), .A2(new_n243_), .B(new_n250_), .Y(new_n251_));
  OAI21x1_ASAP7_75t_R g208(.A1(new_n242_), .A2(new_n249_), .B(new_n251_), .Y(o6));
endmodule


