// Benchmark "/tmp/" written by ABC on Mon Oct 12 14:43:39 2026

module \/tmp/  ( 
    p6, p31, p24, p20, p23, p0, p34, p25, p10, p33, p3, p14, p22, p21, p32,
    p13, p7, p19, p12, p15, p4, p30, p16, p27, p17, p2, p26, p11, p5, p8,
    p9, p18, p28, p1, p29, p35,
    o0, o1, o2, o3, o4, o5, o6  );
  input  p6, p31, p24, p20, p23, p0, p34, p25, p10, p33, p3, p14, p22,
    p21, p32, p13, p7, p19, p12, p15, p4, p30, p16, p27, p17, p2, p26, p11,
    p5, p8, p9, p18, p28, p1, p29, p35;
  output o0, o1, o2, o3, o4, o5, o6;
  wire new_n44_, new_n45_, new_n46_, new_n47_, new_n48_, new_n49_, new_n50_,
    new_n51_, new_n52_, new_n53_, new_n54_, new_n55_, new_n56_, new_n57_,
    new_n58_, new_n59_, new_n60_, new_n61_, new_n62_, new_n63_, new_n65_,
    new_n66_, new_n67_, new_n68_, new_n69_, new_n70_, new_n71_, new_n72_,
    new_n73_, new_n74_, new_n75_, new_n76_, new_n77_, new_n78_, new_n79_,
    new_n80_, new_n81_, new_n82_, new_n83_, new_n84_, new_n85_, new_n86_,
    new_n87_, new_n88_, new_n89_, new_n90_, new_n91_, new_n92_, new_n93_,
    new_n94_, new_n95_, new_n96_, new_n97_, new_n98_, new_n99_, new_n100_,
    new_n101_, new_n102_, new_n103_, new_n104_, new_n105_, new_n106_,
    new_n107_, new_n108_, new_n109_, new_n110_, new_n111_, new_n112_,
    new_n114_, new_n115_, new_n116_, new_n117_, new_n118_, new_n119_,
    new_n120_, new_n121_, new_n122_, new_n123_, new_n124_, new_n125_,
    new_n126_, new_n127_, new_n128_, new_n129_, new_n130_, new_n131_,
    new_n132_, new_n133_, new_n134_, new_n135_, new_n136_, new_n137_,
    new_n138_, new_n139_, new_n140_, new_n141_, new_n142_, new_n143_,
    new_n144_, new_n145_, new_n146_, new_n147_, new_n148_, new_n149_,
    new_n150_, new_n151_, new_n152_, new_n153_, new_n154_, new_n155_,
    new_n156_, new_n157_, new_n158_, new_n159_, new_n160_, new_n161_,
    new_n162_, new_n163_, new_n164_, new_n165_, new_n166_, new_n167_,
    new_n168_, new_n169_, new_n170_, new_n171_, new_n173_, new_n174_,
    new_n175_, new_n176_, new_n177_, new_n178_, new_n179_, new_n180_,
    new_n181_, new_n182_, new_n183_, new_n184_, new_n185_, new_n186_,
    new_n187_, new_n188_, new_n189_, new_n190_, new_n191_, new_n192_,
    new_n193_, new_n194_, new_n195_, new_n196_, new_n197_, new_n198_,
    new_n199_, new_n200_, new_n201_, new_n202_, new_n203_, new_n204_,
    new_n205_, new_n206_, new_n207_, new_n208_, new_n209_, new_n210_,
    new_n211_, new_n212_, new_n213_, new_n214_, new_n215_, new_n216_,
    new_n217_, new_n218_, new_n219_, new_n220_, new_n221_, new_n222_,
    new_n223_, new_n224_, new_n225_, new_n226_, new_n227_, new_n230_,
    new_n231_, new_n232_, new_n233_, new_n234_, new_n235_, new_n236_,
    new_n237_, new_n238_, new_n239_, new_n240_, new_n241_, new_n242_,
    new_n243_, new_n244_, new_n245_, new_n246_, new_n247_, new_n248_,
    new_n249_, new_n250_, new_n252_, new_n253_, new_n254_;
  INVx1_ASAP7_75t_R   g000(.A(p0), .Y(new_n44_));
  INVx1_ASAP7_75t_R   g001(.A(p1), .Y(new_n45_));
  NAND2x1_ASAP7_75t_R g002(.A(p2), .B(new_n45_), .Y(new_n46_));
  OAI21x1_ASAP7_75t_R g003(.A1(new_n44_), .A2(p35), .B(new_n46_), .Y(new_n47_));
  INVx1_ASAP7_75t_R   g004(.A(p12), .Y(new_n48_));
  INVx1_ASAP7_75t_R   g005(.A(p3), .Y(new_n49_));
  NAND2x1_ASAP7_75t_R g006(.A(p4), .B(new_n49_), .Y(new_n50_));
  OAI21x1_ASAP7_75t_R g007(.A1(new_n48_), .A2(p11), .B(new_n50_), .Y(new_n51_));
  NOR2x1_ASAP7_75t_R  g008(.A(new_n47_), .B(new_n51_), .Y(new_n52_));
  INVx1_ASAP7_75t_R   g009(.A(p15), .Y(new_n53_));
  INVx1_ASAP7_75t_R   g010(.A(p14), .Y(new_n54_));
  NOR2x1_ASAP7_75t_R  g011(.A(p13), .B(new_n54_), .Y(new_n55_));
  AOI21x1_ASAP7_75t_R g012(.A1(new_n53_), .A2(p16), .B(new_n55_), .Y(new_n56_));
  INVx1_ASAP7_75t_R   g013(.A(p9), .Y(new_n57_));
  NAND2x1_ASAP7_75t_R g014(.A(p10), .B(new_n57_), .Y(new_n58_));
  INVx1_ASAP7_75t_R   g015(.A(p7), .Y(new_n59_));
  NAND2x1_ASAP7_75t_R g016(.A(p8), .B(new_n59_), .Y(new_n60_));
  INVx1_ASAP7_75t_R   g017(.A(p5), .Y(new_n61_));
  NAND2x1_ASAP7_75t_R g018(.A(p6), .B(new_n61_), .Y(new_n62_));
  AND3x1_ASAP7_75t_R  g019(.A(new_n58_), .B(new_n60_), .C(new_n62_), .Y(new_n63_));
  NAND3x1_ASAP7_75t_R g020(.A(new_n52_), .B(new_n56_), .C(new_n63_), .Y(o0));
  INVx1_ASAP7_75t_R   g021(.A(p11), .Y(new_n65_));
  INVx1_ASAP7_75t_R   g022(.A(p4), .Y(new_n66_));
  NOR2x1_ASAP7_75t_R  g023(.A(p3), .B(new_n66_), .Y(new_n67_));
  AOI21x1_ASAP7_75t_R g024(.A1(p12), .A2(new_n65_), .B(new_n67_), .Y(new_n68_));
  NAND2x1_ASAP7_75t_R g025(.A(new_n68_), .B(new_n56_), .Y(new_n69_));
  INVx1_ASAP7_75t_R   g026(.A(p10), .Y(new_n70_));
  NOR2x1_ASAP7_75t_R  g027(.A(p9), .B(new_n70_), .Y(new_n71_));
  AOI21x1_ASAP7_75t_R g028(.A1(new_n59_), .A2(p8), .B(new_n71_), .Y(new_n72_));
  INVx1_ASAP7_75t_R   g029(.A(p2), .Y(new_n73_));
  NOR2x1_ASAP7_75t_R  g030(.A(p1), .B(new_n73_), .Y(new_n74_));
  NOR2x1_ASAP7_75t_R  g031(.A(p35), .B(new_n44_), .Y(new_n75_));
  NOR2x1_ASAP7_75t_R  g032(.A(new_n74_), .B(new_n75_), .Y(new_n76_));
  NAND3x1_ASAP7_75t_R g033(.A(new_n72_), .B(new_n76_), .C(new_n62_), .Y(new_n77_));
  OA21x2_ASAP7_75t_R  g034(.A1(new_n69_), .A2(new_n77_), .B(p15), .Y(new_n78_));
  INVx1_ASAP7_75t_R   g035(.A(p25), .Y(new_n79_));
  NAND2x1_ASAP7_75t_R g036(.A(p16), .B(new_n79_), .Y(new_n80_));
  INVx1_ASAP7_75t_R   g037(.A(new_n56_), .Y(new_n81_));
  NAND2x1_ASAP7_75t_R g038(.A(new_n76_), .B(new_n68_), .Y(new_n82_));
  OAI21x1_ASAP7_75t_R g039(.A1(new_n81_), .A2(new_n82_), .B(p7), .Y(new_n83_));
  AO21x1_ASAP7_75t_R  g040(.A1(new_n62_), .A2(new_n72_), .B(new_n59_), .Y(new_n84_));
  INVx1_ASAP7_75t_R   g041(.A(p8), .Y(new_n85_));
  NOR2x1_ASAP7_75t_R  g042(.A(p21), .B(new_n85_), .Y(new_n86_));
  NAND3x1_ASAP7_75t_R g043(.A(new_n83_), .B(new_n84_), .C(new_n86_), .Y(new_n87_));
  OAI21x1_ASAP7_75t_R g044(.A1(new_n78_), .A2(new_n80_), .B(new_n87_), .Y(new_n88_));
  INVx1_ASAP7_75t_R   g045(.A(p22), .Y(new_n89_));
  NAND2x1_ASAP7_75t_R g046(.A(p10), .B(new_n89_), .Y(new_n90_));
  OA21x2_ASAP7_75t_R  g047(.A1(new_n69_), .A2(new_n77_), .B(p9), .Y(new_n91_));
  INVx1_ASAP7_75t_R   g048(.A(p6), .Y(new_n92_));
  NOR2x1_ASAP7_75t_R  g049(.A(p20), .B(new_n92_), .Y(new_n93_));
  OAI21x1_ASAP7_75t_R g050(.A1(new_n69_), .A2(new_n77_), .B(p5), .Y(new_n94_));
  NAND2x1_ASAP7_75t_R g051(.A(new_n93_), .B(new_n94_), .Y(new_n95_));
  OAI21x1_ASAP7_75t_R g052(.A1(new_n90_), .A2(new_n91_), .B(new_n95_), .Y(new_n96_));
  NOR2x1_ASAP7_75t_R  g053(.A(new_n88_), .B(new_n96_), .Y(new_n97_));
  INVx1_ASAP7_75t_R   g054(.A(p17), .Y(new_n98_));
  NAND2x1_ASAP7_75t_R g055(.A(p0), .B(new_n98_), .Y(new_n99_));
  AOI21x1_ASAP7_75t_R g056(.A1(p35), .A2(o0), .B(new_n99_), .Y(new_n100_));
  INVx1_ASAP7_75t_R   g057(.A(p24), .Y(new_n101_));
  NAND2x1_ASAP7_75t_R g058(.A(p14), .B(new_n101_), .Y(new_n102_));
  AOI21x1_ASAP7_75t_R g059(.A1(p13), .A2(o0), .B(new_n102_), .Y(new_n103_));
  NOR2x1_ASAP7_75t_R  g060(.A(new_n100_), .B(new_n103_), .Y(new_n104_));
  NOR2x1_ASAP7_75t_R  g061(.A(p19), .B(new_n66_), .Y(new_n105_));
  INVx1_ASAP7_75t_R   g062(.A(new_n105_), .Y(new_n106_));
  AOI21x1_ASAP7_75t_R g063(.A1(new_n50_), .A2(o0), .B(new_n106_), .Y(new_n107_));
  OR2x4_ASAP7_75t_R   g064(.A(p23), .B(new_n48_), .Y(new_n108_));
  AOI21x1_ASAP7_75t_R g065(.A1(p11), .A2(o0), .B(new_n108_), .Y(new_n109_));
  OR2x4_ASAP7_75t_R   g066(.A(p18), .B(new_n73_), .Y(new_n110_));
  AOI21x1_ASAP7_75t_R g067(.A1(p1), .A2(o0), .B(new_n110_), .Y(new_n111_));
  NOR3x1_ASAP7_75t_R  g068(.A(new_n107_), .B(new_n109_), .C(new_n111_), .Y(new_n112_));
  NAND3x1_ASAP7_75t_R g069(.A(new_n97_), .B(new_n104_), .C(new_n112_), .Y(o1));
  NOR2x1_ASAP7_75t_R  g070(.A(new_n109_), .B(new_n111_), .Y(new_n114_));
  AOI21x1_ASAP7_75t_R g071(.A1(p9), .A2(o0), .B(new_n90_), .Y(new_n115_));
  INVx1_ASAP7_75t_R   g072(.A(new_n93_), .Y(new_n116_));
  AOI21x1_ASAP7_75t_R g073(.A1(p5), .A2(o0), .B(new_n116_), .Y(new_n117_));
  NOR2x1_ASAP7_75t_R  g074(.A(new_n115_), .B(new_n117_), .Y(new_n118_));
  INVx1_ASAP7_75t_R   g075(.A(new_n107_), .Y(new_n119_));
  AND3x1_ASAP7_75t_R  g076(.A(new_n114_), .B(new_n118_), .C(new_n119_), .Y(new_n120_));
  INVx1_ASAP7_75t_R   g077(.A(o0), .Y(new_n121_));
  OA21x2_ASAP7_75t_R  g078(.A1(new_n45_), .A2(new_n121_), .B(p2), .Y(new_n122_));
  AOI21x1_ASAP7_75t_R g079(.A1(p15), .A2(o0), .B(new_n80_), .Y(new_n123_));
  INVx1_ASAP7_75t_R   g080(.A(new_n86_), .Y(new_n124_));
  AOI21x1_ASAP7_75t_R g081(.A1(p7), .A2(o0), .B(new_n124_), .Y(new_n125_));
  NOR2x1_ASAP7_75t_R  g082(.A(new_n123_), .B(new_n125_), .Y(new_n126_));
  AND3x1_ASAP7_75t_R  g083(.A(new_n104_), .B(new_n122_), .C(new_n126_), .Y(new_n127_));
  AOI21x1_ASAP7_75t_R g084(.A1(new_n120_), .A2(new_n127_), .B(new_n111_), .Y(new_n128_));
  NOR3x1_ASAP7_75t_R  g085(.A(new_n125_), .B(new_n115_), .C(new_n117_), .Y(new_n129_));
  NOR3x1_ASAP7_75t_R  g086(.A(new_n100_), .B(new_n103_), .C(new_n123_), .Y(new_n130_));
  AOI21x1_ASAP7_75t_R g087(.A1(new_n129_), .A2(new_n130_), .B(new_n98_), .Y(new_n131_));
  NOR2x1_ASAP7_75t_R  g088(.A(new_n98_), .B(new_n112_), .Y(new_n132_));
  NAND2x1_ASAP7_75t_R g089(.A(p35), .B(o0), .Y(new_n133_));
  INVx1_ASAP7_75t_R   g090(.A(p26), .Y(new_n134_));
  NAND3x1_ASAP7_75t_R g091(.A(new_n133_), .B(p0), .C(new_n134_), .Y(new_n135_));
  OR3x1_ASAP7_75t_R   g092(.A(new_n131_), .B(new_n132_), .C(new_n135_), .Y(new_n136_));
  OAI21x1_ASAP7_75t_R g093(.A1(p27), .A2(new_n128_), .B(new_n136_), .Y(new_n137_));
  AO21x1_ASAP7_75t_R  g094(.A1(p11), .A2(o0), .B(new_n48_), .Y(new_n138_));
  NOR2x1_ASAP7_75t_R  g095(.A(p32), .B(new_n138_), .Y(new_n139_));
  INVx1_ASAP7_75t_R   g096(.A(new_n139_), .Y(new_n140_));
  AOI21x1_ASAP7_75t_R g097(.A1(p23), .A2(o1), .B(new_n140_), .Y(new_n141_));
  INVx1_ASAP7_75t_R   g098(.A(p28), .Y(new_n142_));
  AO21x1_ASAP7_75t_R  g099(.A1(p4), .A2(new_n121_), .B(new_n67_), .Y(new_n143_));
  NAND2x1_ASAP7_75t_R g100(.A(new_n142_), .B(new_n143_), .Y(new_n144_));
  AOI21x1_ASAP7_75t_R g101(.A1(p19), .A2(o1), .B(new_n144_), .Y(new_n145_));
  NOR3x1_ASAP7_75t_R  g102(.A(new_n137_), .B(new_n141_), .C(new_n145_), .Y(new_n146_));
  NOR2x1_ASAP7_75t_R  g103(.A(p29), .B(new_n92_), .Y(new_n147_));
  NAND2x1_ASAP7_75t_R g104(.A(new_n147_), .B(new_n94_), .Y(new_n148_));
  AO21x1_ASAP7_75t_R  g105(.A1(p20), .A2(o1), .B(new_n148_), .Y(new_n149_));
  INVx1_ASAP7_75t_R   g106(.A(p30), .Y(new_n150_));
  AND3x1_ASAP7_75t_R  g107(.A(new_n83_), .B(p8), .C(new_n84_), .Y(new_n151_));
  NAND2x1_ASAP7_75t_R g108(.A(new_n150_), .B(new_n151_), .Y(new_n152_));
  AO21x1_ASAP7_75t_R  g109(.A1(p21), .A2(o1), .B(new_n152_), .Y(new_n153_));
  NAND2x1_ASAP7_75t_R g110(.A(new_n104_), .B(new_n126_), .Y(new_n154_));
  NAND3x1_ASAP7_75t_R g111(.A(new_n114_), .B(new_n118_), .C(new_n119_), .Y(new_n155_));
  NOR2x1_ASAP7_75t_R  g112(.A(new_n154_), .B(new_n155_), .Y(new_n156_));
  AO21x1_ASAP7_75t_R  g113(.A1(p9), .A2(o0), .B(new_n70_), .Y(new_n157_));
  NOR2x1_ASAP7_75t_R  g114(.A(p31), .B(new_n157_), .Y(new_n158_));
  OAI21x1_ASAP7_75t_R g115(.A1(new_n89_), .A2(new_n156_), .B(new_n158_), .Y(new_n159_));
  AND3x1_ASAP7_75t_R  g116(.A(new_n149_), .B(new_n153_), .C(new_n159_), .Y(new_n160_));
  OAI21x1_ASAP7_75t_R g117(.A1(new_n154_), .A2(new_n155_), .B(p25), .Y(new_n161_));
  INVx1_ASAP7_75t_R   g118(.A(new_n78_), .Y(new_n162_));
  INVx1_ASAP7_75t_R   g119(.A(p34), .Y(new_n163_));
  AND3x1_ASAP7_75t_R  g120(.A(new_n162_), .B(new_n163_), .C(p16), .Y(new_n164_));
  AOI21x1_ASAP7_75t_R g121(.A1(new_n129_), .A2(new_n130_), .B(new_n101_), .Y(new_n165_));
  NOR2x1_ASAP7_75t_R  g122(.A(new_n101_), .B(new_n112_), .Y(new_n166_));
  AND2x2_ASAP7_75t_R  g123(.A(p13), .B(o0), .Y(new_n167_));
  OR3x1_ASAP7_75t_R   g124(.A(new_n167_), .B(p33), .C(new_n54_), .Y(new_n168_));
  NOR3x1_ASAP7_75t_R  g125(.A(new_n165_), .B(new_n166_), .C(new_n168_), .Y(new_n169_));
  AOI21x1_ASAP7_75t_R g126(.A1(new_n161_), .A2(new_n164_), .B(new_n169_), .Y(new_n170_));
  AND3x1_ASAP7_75t_R  g127(.A(new_n146_), .B(new_n160_), .C(new_n170_), .Y(new_n171_));
  INVx1_ASAP7_75t_R   g128(.A(new_n171_), .Y(o2));
  AOI21x1_ASAP7_75t_R g129(.A1(new_n170_), .A2(new_n146_), .B(new_n142_), .Y(new_n173_));
  INVx1_ASAP7_75t_R   g130(.A(p19), .Y(new_n174_));
  OA21x2_ASAP7_75t_R  g131(.A1(new_n174_), .A2(new_n156_), .B(new_n143_), .Y(new_n175_));
  OAI21x1_ASAP7_75t_R g132(.A1(new_n142_), .A2(new_n160_), .B(new_n175_), .Y(new_n176_));
  NAND2x1_ASAP7_75t_R g133(.A(p6), .B(new_n94_), .Y(new_n177_));
  AO21x1_ASAP7_75t_R  g134(.A1(p20), .A2(o1), .B(new_n177_), .Y(new_n178_));
  INVx1_ASAP7_75t_R   g135(.A(p21), .Y(new_n179_));
  AOI21x1_ASAP7_75t_R g136(.A1(new_n130_), .A2(new_n129_), .B(new_n179_), .Y(new_n180_));
  NAND2x1_ASAP7_75t_R g137(.A(p7), .B(o0), .Y(new_n181_));
  OAI21x1_ASAP7_75t_R g138(.A1(new_n179_), .A2(new_n112_), .B(new_n181_), .Y(new_n182_));
  OR3x1_ASAP7_75t_R   g139(.A(new_n180_), .B(new_n182_), .C(new_n85_), .Y(new_n183_));
  OAI21x1_ASAP7_75t_R g140(.A1(p30), .A2(new_n183_), .B(new_n159_), .Y(new_n184_));
  NOR2x1_ASAP7_75t_R  g141(.A(new_n178_), .B(new_n184_), .Y(new_n185_));
  OA21x2_ASAP7_75t_R  g142(.A1(new_n154_), .A2(new_n155_), .B(p19), .Y(new_n186_));
  OAI21x1_ASAP7_75t_R g143(.A1(new_n154_), .A2(new_n155_), .B(p23), .Y(new_n187_));
  NAND2x1_ASAP7_75t_R g144(.A(new_n139_), .B(new_n187_), .Y(new_n188_));
  OAI21x1_ASAP7_75t_R g145(.A1(new_n186_), .A2(new_n144_), .B(new_n188_), .Y(new_n189_));
  AO21x1_ASAP7_75t_R  g146(.A1(new_n161_), .A2(new_n164_), .B(new_n169_), .Y(new_n190_));
  NOR3x1_ASAP7_75t_R  g147(.A(new_n189_), .B(new_n190_), .C(new_n137_), .Y(new_n191_));
  AOI21x1_ASAP7_75t_R g148(.A1(p20), .A2(o1), .B(new_n148_), .Y(new_n192_));
  AOI21x1_ASAP7_75t_R g149(.A1(new_n185_), .A2(new_n191_), .B(new_n192_), .Y(new_n193_));
  OAI21x1_ASAP7_75t_R g150(.A1(new_n173_), .A2(new_n176_), .B(new_n193_), .Y(new_n194_));
  NOR2x1_ASAP7_75t_R  g151(.A(new_n132_), .B(new_n131_), .Y(new_n195_));
  AND3x1_ASAP7_75t_R  g152(.A(new_n195_), .B(p0), .C(new_n133_), .Y(new_n196_));
  OAI21x1_ASAP7_75t_R g153(.A1(new_n134_), .A2(new_n160_), .B(new_n196_), .Y(new_n197_));
  NOR2x1_ASAP7_75t_R  g154(.A(new_n134_), .B(new_n191_), .Y(new_n198_));
  NOR3x1_ASAP7_75t_R  g155(.A(new_n184_), .B(new_n192_), .C(new_n128_), .Y(new_n199_));
  NOR2x1_ASAP7_75t_R  g156(.A(p27), .B(new_n128_), .Y(new_n200_));
  AOI21x1_ASAP7_75t_R g157(.A1(new_n191_), .A2(new_n199_), .B(new_n200_), .Y(new_n201_));
  OAI21x1_ASAP7_75t_R g158(.A1(new_n197_), .A2(new_n198_), .B(new_n201_), .Y(new_n202_));
  NOR2x1_ASAP7_75t_R  g159(.A(new_n194_), .B(new_n202_), .Y(new_n203_));
  AOI21x1_ASAP7_75t_R g160(.A1(new_n170_), .A2(new_n146_), .B(new_n150_), .Y(new_n204_));
  INVx1_ASAP7_75t_R   g161(.A(new_n183_), .Y(new_n205_));
  OAI21x1_ASAP7_75t_R g162(.A1(new_n150_), .A2(new_n160_), .B(new_n205_), .Y(new_n206_));
  INVx1_ASAP7_75t_R   g163(.A(p31), .Y(new_n207_));
  AOI21x1_ASAP7_75t_R g164(.A1(p22), .A2(o1), .B(new_n157_), .Y(new_n208_));
  INVx1_ASAP7_75t_R   g165(.A(new_n208_), .Y(new_n209_));
  AOI21x1_ASAP7_75t_R g166(.A1(new_n149_), .A2(new_n153_), .B(new_n207_), .Y(new_n210_));
  NOR2x1_ASAP7_75t_R  g167(.A(new_n209_), .B(new_n210_), .Y(new_n211_));
  OAI21x1_ASAP7_75t_R g168(.A1(new_n207_), .A2(new_n191_), .B(new_n211_), .Y(new_n212_));
  OAI21x1_ASAP7_75t_R g169(.A1(new_n204_), .A2(new_n206_), .B(new_n212_), .Y(new_n213_));
  INVx1_ASAP7_75t_R   g170(.A(p32), .Y(new_n214_));
  INVx1_ASAP7_75t_R   g171(.A(new_n138_), .Y(new_n215_));
  AND2x2_ASAP7_75t_R  g172(.A(new_n215_), .B(new_n187_), .Y(new_n216_));
  OAI21x1_ASAP7_75t_R g173(.A1(new_n214_), .A2(new_n160_), .B(new_n216_), .Y(new_n217_));
  NOR2x1_ASAP7_75t_R  g174(.A(new_n214_), .B(new_n191_), .Y(new_n218_));
  AO21x1_ASAP7_75t_R  g175(.A1(p13), .A2(o0), .B(new_n54_), .Y(new_n219_));
  OR3x1_ASAP7_75t_R   g176(.A(new_n165_), .B(new_n166_), .C(new_n219_), .Y(new_n220_));
  NOR3x1_ASAP7_75t_R  g177(.A(new_n184_), .B(new_n192_), .C(new_n220_), .Y(new_n221_));
  AOI21x1_ASAP7_75t_R g178(.A1(new_n191_), .A2(new_n221_), .B(new_n169_), .Y(new_n222_));
  OAI21x1_ASAP7_75t_R g179(.A1(new_n217_), .A2(new_n218_), .B(new_n222_), .Y(new_n223_));
  NOR2x1_ASAP7_75t_R  g180(.A(new_n213_), .B(new_n223_), .Y(new_n224_));
  AO21x1_ASAP7_75t_R  g181(.A1(new_n160_), .A2(new_n191_), .B(new_n163_), .Y(new_n225_));
  AND2x2_ASAP7_75t_R  g182(.A(p16), .B(new_n162_), .Y(new_n226_));
  AND3x1_ASAP7_75t_R  g183(.A(new_n225_), .B(new_n161_), .C(new_n226_), .Y(new_n227_));
  AOI21x1_ASAP7_75t_R g184(.A1(new_n203_), .A2(new_n224_), .B(new_n227_), .Y(o3));
  INVx1_ASAP7_75t_R   g185(.A(new_n224_), .Y(o4));
  NOR2x1_ASAP7_75t_R  g186(.A(new_n141_), .B(new_n145_), .Y(new_n230_));
  INVx1_ASAP7_75t_R   g187(.A(p27), .Y(new_n231_));
  AO21x1_ASAP7_75t_R  g188(.A1(new_n120_), .A2(new_n127_), .B(new_n111_), .Y(new_n232_));
  NOR3x1_ASAP7_75t_R  g189(.A(new_n131_), .B(new_n132_), .C(new_n135_), .Y(new_n233_));
  AOI21x1_ASAP7_75t_R g190(.A1(new_n231_), .A2(new_n232_), .B(new_n233_), .Y(new_n234_));
  NAND3x1_ASAP7_75t_R g191(.A(new_n230_), .B(new_n170_), .C(new_n234_), .Y(new_n235_));
  NAND2x1_ASAP7_75t_R g192(.A(p22), .B(o1), .Y(new_n236_));
  AOI21x1_ASAP7_75t_R g193(.A1(p21), .A2(o1), .B(new_n152_), .Y(new_n237_));
  AOI21x1_ASAP7_75t_R g194(.A1(new_n236_), .A2(new_n158_), .B(new_n237_), .Y(new_n238_));
  NAND3x1_ASAP7_75t_R g195(.A(new_n238_), .B(new_n149_), .C(new_n205_), .Y(new_n239_));
  NOR2x1_ASAP7_75t_R  g196(.A(new_n235_), .B(new_n239_), .Y(new_n240_));
  NAND3x1_ASAP7_75t_R g197(.A(new_n238_), .B(new_n149_), .C(new_n208_), .Y(new_n241_));
  OAI21x1_ASAP7_75t_R g198(.A1(new_n235_), .A2(new_n241_), .B(new_n238_), .Y(new_n242_));
  NOR2x1_ASAP7_75t_R  g199(.A(new_n240_), .B(new_n242_), .Y(new_n243_));
  NAND3x1_ASAP7_75t_R g200(.A(new_n238_), .B(new_n149_), .C(new_n216_), .Y(new_n244_));
  OAI21x1_ASAP7_75t_R g201(.A1(new_n235_), .A2(new_n244_), .B(new_n188_), .Y(new_n245_));
  NOR2x1_ASAP7_75t_R  g202(.A(new_n193_), .B(new_n245_), .Y(new_n246_));
  NAND2x1_ASAP7_75t_R g203(.A(new_n243_), .B(new_n246_), .Y(new_n247_));
  AND3x1_ASAP7_75t_R  g204(.A(new_n238_), .B(new_n149_), .C(new_n175_), .Y(new_n248_));
  AO21x1_ASAP7_75t_R  g205(.A1(new_n191_), .A2(new_n248_), .B(new_n145_), .Y(new_n249_));
  AOI21x1_ASAP7_75t_R g206(.A1(new_n249_), .A2(new_n243_), .B(new_n223_), .Y(new_n250_));
  NAND2x1_ASAP7_75t_R g207(.A(new_n247_), .B(new_n250_), .Y(o5));
  OA21x2_ASAP7_75t_R  g208(.A1(new_n201_), .A2(new_n249_), .B(new_n212_), .Y(new_n252_));
  INVx1_ASAP7_75t_R   g209(.A(new_n222_), .Y(new_n253_));
  AOI21x1_ASAP7_75t_R g210(.A1(new_n243_), .A2(new_n246_), .B(new_n253_), .Y(new_n254_));
  OAI21x1_ASAP7_75t_R g211(.A1(new_n245_), .A2(new_n252_), .B(new_n254_), .Y(o6));
endmodule


