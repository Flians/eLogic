// Benchmark "/tmp/" written by ABC on Mon Oct 12 14:43:38 2026

module \/tmp/  ( 
    p21, p4, p18, p25, p30, p3, p8, p5, p7, p29, p10, p22, p28, p24, p31,
    p32, p6, p12, p34, p11, p27, p19, p26, p9, p16, p2, p17, p1, p35, p13,
    p20, p14, p33, p15, p0, p23,
    o0, o1, o2, o3, o4, o5, o6  );
  input  p21, p4, p18, p25, p30, p3, p8, p5, p7, p29, p10, p22, p28, p24,
    p31, p32, p6, p12, p34, p11, p27, p19, p26, p9, p16, p2, p17, p1, p35,
    p13, p20, p14, p33, p15, p0, p23;
  output o0, o1, o2, o3, o4, o5, o6;
  wire new_n44_, new_n45_, new_n46_, new_n47_, new_n48_, new_n49_, new_n50_,
    new_n51_, new_n52_, new_n53_, new_n54_, new_n55_, new_n56_, new_n57_,
    new_n58_, new_n59_, new_n60_, new_n61_, new_n62_, new_n63_, new_n65_,
    new_n66_, new_n67_, new_n68_, new_n69_, new_n70_, new_n71_, new_n72_,
    new_n73_, new_n74_, new_n75_, new_n76_, new_n77_, new_n78_, new_n79_,
    new_n80_, new_n81_, new_n82_, new_n83_, new_n84_, new_n85_, new_n86_,
    new_n87_, new_n88_, new_n89_, new_n90_, new_n91_, new_n92_, new_n93_,
    new_n94_, new_n95_, new_n96_, new_n97_, new_n98_, new_n99_, new_n100_,
    new_n101_, new_n102_, new_n103_, new_n104_, new_n105_, new_n106_,
    new_n107_, new_n108_, new_n109_, new_n111_, new_n112_, new_n113_,
    new_n114_, new_n115_, new_n116_, new_n117_, new_n118_, new_n119_,
    new_n120_, new_n121_, new_n122_, new_n123_, new_n124_, new_n125_,
    new_n126_, new_n127_, new_n128_, new_n129_, new_n130_, new_n131_,
    new_n132_, new_n133_, new_n134_, new_n135_, new_n136_, new_n137_,
    new_n138_, new_n139_, new_n140_, new_n141_, new_n142_, new_n143_,
    new_n144_, new_n145_, new_n146_, new_n147_, new_n148_, new_n149_,
    new_n150_, new_n151_, new_n152_, new_n153_, new_n154_, new_n155_,
    new_n156_, new_n157_, new_n158_, new_n159_, new_n160_, new_n161_,
    new_n162_, new_n163_, new_n164_, new_n165_, new_n166_, new_n167_,
    new_n168_, new_n170_, new_n171_, new_n172_, new_n173_, new_n174_,
    new_n175_, new_n176_, new_n177_, new_n178_, new_n179_, new_n180_,
    new_n181_, new_n182_, new_n183_, new_n184_, new_n185_, new_n186_,
    new_n187_, new_n188_, new_n189_, new_n190_, new_n191_, new_n192_,
    new_n193_, new_n194_, new_n195_, new_n196_, new_n197_, new_n198_,
    new_n199_, new_n200_, new_n201_, new_n202_, new_n203_, new_n204_,
    new_n205_, new_n206_, new_n207_, new_n208_, new_n209_, new_n210_,
    new_n211_, new_n212_, new_n213_, new_n214_, new_n215_, new_n216_,
    new_n217_, new_n218_, new_n219_, new_n220_, new_n221_, new_n222_,
    new_n223_, new_n224_, new_n225_, new_n226_, new_n227_, new_n230_,
    new_n231_, new_n232_, new_n233_, new_n234_, new_n235_, new_n236_,
    new_n237_, new_n238_, new_n239_, new_n240_, new_n241_, new_n242_,
    new_n243_, new_n244_, new_n245_, new_n246_, new_n247_, new_n248_,
    new_n249_, new_n251_, new_n252_, new_n253_;
  INVx1_ASAP7_75t_R   g000(.A(p14), .Y(new_n44_));
  INVx1_ASAP7_75t_R   g001(.A(p15), .Y(new_n45_));
  NAND2x1_ASAP7_75t_R g002(.A(p16), .B(new_n45_), .Y(new_n46_));
  OAI21x1_ASAP7_75t_R g003(.A1(p13), .A2(new_n44_), .B(new_n46_), .Y(new_n47_));
  INVx1_ASAP7_75t_R   g004(.A(p12), .Y(new_n48_));
  INVx1_ASAP7_75t_R   g005(.A(p3), .Y(new_n49_));
  NAND2x1_ASAP7_75t_R g006(.A(p4), .B(new_n49_), .Y(new_n50_));
  OAI21x1_ASAP7_75t_R g007(.A1(new_n48_), .A2(p11), .B(new_n50_), .Y(new_n51_));
  NOR2x1_ASAP7_75t_R  g008(.A(new_n47_), .B(new_n51_), .Y(new_n52_));
  INVx1_ASAP7_75t_R   g009(.A(p35), .Y(new_n53_));
  INVx1_ASAP7_75t_R   g010(.A(p2), .Y(new_n54_));
  NOR2x1_ASAP7_75t_R  g011(.A(p1), .B(new_n54_), .Y(new_n55_));
  AOI21x1_ASAP7_75t_R g012(.A1(new_n53_), .A2(p0), .B(new_n55_), .Y(new_n56_));
  INVx1_ASAP7_75t_R   g013(.A(p5), .Y(new_n57_));
  NAND2x1_ASAP7_75t_R g014(.A(p6), .B(new_n57_), .Y(new_n58_));
  INVx1_ASAP7_75t_R   g015(.A(p9), .Y(new_n59_));
  NAND2x1_ASAP7_75t_R g016(.A(p10), .B(new_n59_), .Y(new_n60_));
  INVx1_ASAP7_75t_R   g017(.A(p7), .Y(new_n61_));
  NAND2x1_ASAP7_75t_R g018(.A(p8), .B(new_n61_), .Y(new_n62_));
  AND3x1_ASAP7_75t_R  g019(.A(new_n58_), .B(new_n60_), .C(new_n62_), .Y(new_n63_));
  NAND3x1_ASAP7_75t_R g020(.A(new_n52_), .B(new_n56_), .C(new_n63_), .Y(o0));
  INVx1_ASAP7_75t_R   g021(.A(p11), .Y(new_n65_));
  INVx1_ASAP7_75t_R   g022(.A(p4), .Y(new_n66_));
  NOR2x1_ASAP7_75t_R  g023(.A(p3), .B(new_n66_), .Y(new_n67_));
  AOI21x1_ASAP7_75t_R g024(.A1(p12), .A2(new_n65_), .B(new_n67_), .Y(new_n68_));
  NOR2x1_ASAP7_75t_R  g025(.A(p13), .B(new_n44_), .Y(new_n69_));
  AOI21x1_ASAP7_75t_R g026(.A1(p16), .A2(new_n45_), .B(new_n69_), .Y(new_n70_));
  NAND2x1_ASAP7_75t_R g027(.A(new_n68_), .B(new_n70_), .Y(new_n71_));
  INVx1_ASAP7_75t_R   g028(.A(p10), .Y(new_n72_));
  NOR2x1_ASAP7_75t_R  g029(.A(p9), .B(new_n72_), .Y(new_n73_));
  AOI21x1_ASAP7_75t_R g030(.A1(p8), .A2(new_n61_), .B(new_n73_), .Y(new_n74_));
  NAND3x1_ASAP7_75t_R g031(.A(new_n74_), .B(new_n56_), .C(new_n58_), .Y(new_n75_));
  OA21x2_ASAP7_75t_R  g032(.A1(new_n71_), .A2(new_n75_), .B(p15), .Y(new_n76_));
  INVx1_ASAP7_75t_R   g033(.A(p25), .Y(new_n77_));
  NAND2x1_ASAP7_75t_R g034(.A(p16), .B(new_n77_), .Y(new_n78_));
  NAND2x1_ASAP7_75t_R g035(.A(new_n68_), .B(new_n56_), .Y(new_n79_));
  OAI21x1_ASAP7_75t_R g036(.A1(new_n47_), .A2(new_n79_), .B(p7), .Y(new_n80_));
  AO21x1_ASAP7_75t_R  g037(.A1(new_n58_), .A2(new_n74_), .B(new_n61_), .Y(new_n81_));
  INVx1_ASAP7_75t_R   g038(.A(p8), .Y(new_n82_));
  NOR2x1_ASAP7_75t_R  g039(.A(p21), .B(new_n82_), .Y(new_n83_));
  NAND3x1_ASAP7_75t_R g040(.A(new_n80_), .B(new_n81_), .C(new_n83_), .Y(new_n84_));
  OAI21x1_ASAP7_75t_R g041(.A1(new_n76_), .A2(new_n78_), .B(new_n84_), .Y(new_n85_));
  INVx1_ASAP7_75t_R   g042(.A(p22), .Y(new_n86_));
  NAND2x1_ASAP7_75t_R g043(.A(p10), .B(new_n86_), .Y(new_n87_));
  OA21x2_ASAP7_75t_R  g044(.A1(new_n71_), .A2(new_n75_), .B(p9), .Y(new_n88_));
  INVx1_ASAP7_75t_R   g045(.A(p6), .Y(new_n89_));
  NOR2x1_ASAP7_75t_R  g046(.A(p20), .B(new_n89_), .Y(new_n90_));
  OAI21x1_ASAP7_75t_R g047(.A1(new_n71_), .A2(new_n75_), .B(p5), .Y(new_n91_));
  NAND2x1_ASAP7_75t_R g048(.A(new_n90_), .B(new_n91_), .Y(new_n92_));
  OAI21x1_ASAP7_75t_R g049(.A1(new_n87_), .A2(new_n88_), .B(new_n92_), .Y(new_n93_));
  NOR2x1_ASAP7_75t_R  g050(.A(new_n85_), .B(new_n93_), .Y(new_n94_));
  INVx1_ASAP7_75t_R   g051(.A(p17), .Y(new_n95_));
  NAND2x1_ASAP7_75t_R g052(.A(p0), .B(new_n95_), .Y(new_n96_));
  AOI21x1_ASAP7_75t_R g053(.A1(p35), .A2(o0), .B(new_n96_), .Y(new_n97_));
  INVx1_ASAP7_75t_R   g054(.A(p24), .Y(new_n98_));
  NAND2x1_ASAP7_75t_R g055(.A(p14), .B(new_n98_), .Y(new_n99_));
  AOI21x1_ASAP7_75t_R g056(.A1(p13), .A2(o0), .B(new_n99_), .Y(new_n100_));
  NOR2x1_ASAP7_75t_R  g057(.A(new_n97_), .B(new_n100_), .Y(new_n101_));
  NOR2x1_ASAP7_75t_R  g058(.A(p19), .B(new_n66_), .Y(new_n102_));
  INVx1_ASAP7_75t_R   g059(.A(new_n102_), .Y(new_n103_));
  AOI21x1_ASAP7_75t_R g060(.A1(new_n50_), .A2(o0), .B(new_n103_), .Y(new_n104_));
  OR2x4_ASAP7_75t_R   g061(.A(p23), .B(new_n48_), .Y(new_n105_));
  AOI21x1_ASAP7_75t_R g062(.A1(p11), .A2(o0), .B(new_n105_), .Y(new_n106_));
  OR2x4_ASAP7_75t_R   g063(.A(p18), .B(new_n54_), .Y(new_n107_));
  AOI21x1_ASAP7_75t_R g064(.A1(p1), .A2(o0), .B(new_n107_), .Y(new_n108_));
  NOR3x1_ASAP7_75t_R  g065(.A(new_n104_), .B(new_n106_), .C(new_n108_), .Y(new_n109_));
  NAND3x1_ASAP7_75t_R g066(.A(new_n94_), .B(new_n101_), .C(new_n109_), .Y(o1));
  AOI21x1_ASAP7_75t_R g067(.A1(p15), .A2(o0), .B(new_n78_), .Y(new_n111_));
  INVx1_ASAP7_75t_R   g068(.A(new_n83_), .Y(new_n112_));
  AOI21x1_ASAP7_75t_R g069(.A1(p7), .A2(o0), .B(new_n112_), .Y(new_n113_));
  NOR2x1_ASAP7_75t_R  g070(.A(new_n111_), .B(new_n113_), .Y(new_n114_));
  AOI21x1_ASAP7_75t_R g071(.A1(p1), .A2(o0), .B(new_n54_), .Y(new_n115_));
  AND3x1_ASAP7_75t_R  g072(.A(new_n101_), .B(new_n114_), .C(new_n115_), .Y(new_n116_));
  NOR2x1_ASAP7_75t_R  g073(.A(new_n106_), .B(new_n108_), .Y(new_n117_));
  AOI21x1_ASAP7_75t_R g074(.A1(p9), .A2(o0), .B(new_n87_), .Y(new_n118_));
  INVx1_ASAP7_75t_R   g075(.A(new_n90_), .Y(new_n119_));
  AOI21x1_ASAP7_75t_R g076(.A1(p5), .A2(o0), .B(new_n119_), .Y(new_n120_));
  NOR2x1_ASAP7_75t_R  g077(.A(new_n118_), .B(new_n120_), .Y(new_n121_));
  INVx1_ASAP7_75t_R   g078(.A(new_n104_), .Y(new_n122_));
  AND3x1_ASAP7_75t_R  g079(.A(new_n117_), .B(new_n121_), .C(new_n122_), .Y(new_n123_));
  AOI21x1_ASAP7_75t_R g080(.A1(new_n116_), .A2(new_n123_), .B(new_n108_), .Y(new_n124_));
  NOR3x1_ASAP7_75t_R  g081(.A(new_n113_), .B(new_n118_), .C(new_n120_), .Y(new_n125_));
  NOR3x1_ASAP7_75t_R  g082(.A(new_n97_), .B(new_n100_), .C(new_n111_), .Y(new_n126_));
  AOI21x1_ASAP7_75t_R g083(.A1(new_n125_), .A2(new_n126_), .B(new_n95_), .Y(new_n127_));
  NOR2x1_ASAP7_75t_R  g084(.A(new_n95_), .B(new_n109_), .Y(new_n128_));
  AND3x1_ASAP7_75t_R  g085(.A(new_n70_), .B(new_n56_), .C(new_n68_), .Y(new_n129_));
  AO21x1_ASAP7_75t_R  g086(.A1(new_n63_), .A2(new_n129_), .B(new_n53_), .Y(new_n130_));
  INVx1_ASAP7_75t_R   g087(.A(p26), .Y(new_n131_));
  NAND3x1_ASAP7_75t_R g088(.A(new_n130_), .B(new_n131_), .C(p0), .Y(new_n132_));
  OR3x1_ASAP7_75t_R   g089(.A(new_n127_), .B(new_n128_), .C(new_n132_), .Y(new_n133_));
  OAI21x1_ASAP7_75t_R g090(.A1(p27), .A2(new_n124_), .B(new_n133_), .Y(new_n134_));
  AO21x1_ASAP7_75t_R  g091(.A1(p11), .A2(o0), .B(new_n48_), .Y(new_n135_));
  NOR2x1_ASAP7_75t_R  g092(.A(p32), .B(new_n135_), .Y(new_n136_));
  INVx1_ASAP7_75t_R   g093(.A(new_n136_), .Y(new_n137_));
  AOI21x1_ASAP7_75t_R g094(.A1(p23), .A2(o1), .B(new_n137_), .Y(new_n138_));
  INVx1_ASAP7_75t_R   g095(.A(p28), .Y(new_n139_));
  OAI21x1_ASAP7_75t_R g096(.A1(new_n66_), .A2(o0), .B(new_n50_), .Y(new_n140_));
  NAND2x1_ASAP7_75t_R g097(.A(new_n139_), .B(new_n140_), .Y(new_n141_));
  AOI21x1_ASAP7_75t_R g098(.A1(p19), .A2(o1), .B(new_n141_), .Y(new_n142_));
  NOR3x1_ASAP7_75t_R  g099(.A(new_n134_), .B(new_n138_), .C(new_n142_), .Y(new_n143_));
  NOR2x1_ASAP7_75t_R  g100(.A(p29), .B(new_n89_), .Y(new_n144_));
  NAND2x1_ASAP7_75t_R g101(.A(new_n144_), .B(new_n91_), .Y(new_n145_));
  AO21x1_ASAP7_75t_R  g102(.A1(p20), .A2(o1), .B(new_n145_), .Y(new_n146_));
  INVx1_ASAP7_75t_R   g103(.A(p30), .Y(new_n147_));
  AND3x1_ASAP7_75t_R  g104(.A(new_n80_), .B(p8), .C(new_n81_), .Y(new_n148_));
  NAND2x1_ASAP7_75t_R g105(.A(new_n147_), .B(new_n148_), .Y(new_n149_));
  AO21x1_ASAP7_75t_R  g106(.A1(p21), .A2(o1), .B(new_n149_), .Y(new_n150_));
  NAND2x1_ASAP7_75t_R g107(.A(new_n101_), .B(new_n114_), .Y(new_n151_));
  NAND3x1_ASAP7_75t_R g108(.A(new_n117_), .B(new_n121_), .C(new_n122_), .Y(new_n152_));
  NOR2x1_ASAP7_75t_R  g109(.A(new_n151_), .B(new_n152_), .Y(new_n153_));
  AO21x1_ASAP7_75t_R  g110(.A1(p9), .A2(o0), .B(new_n72_), .Y(new_n154_));
  NOR2x1_ASAP7_75t_R  g111(.A(p31), .B(new_n154_), .Y(new_n155_));
  OAI21x1_ASAP7_75t_R g112(.A1(new_n86_), .A2(new_n153_), .B(new_n155_), .Y(new_n156_));
  AND3x1_ASAP7_75t_R  g113(.A(new_n146_), .B(new_n150_), .C(new_n156_), .Y(new_n157_));
  OAI21x1_ASAP7_75t_R g114(.A1(new_n151_), .A2(new_n152_), .B(p25), .Y(new_n158_));
  INVx1_ASAP7_75t_R   g115(.A(new_n76_), .Y(new_n159_));
  INVx1_ASAP7_75t_R   g116(.A(p34), .Y(new_n160_));
  AND3x1_ASAP7_75t_R  g117(.A(new_n159_), .B(new_n160_), .C(p16), .Y(new_n161_));
  AOI21x1_ASAP7_75t_R g118(.A1(new_n125_), .A2(new_n126_), .B(new_n98_), .Y(new_n162_));
  NOR2x1_ASAP7_75t_R  g119(.A(new_n98_), .B(new_n109_), .Y(new_n163_));
  AND2x2_ASAP7_75t_R  g120(.A(p13), .B(o0), .Y(new_n164_));
  OR3x1_ASAP7_75t_R   g121(.A(new_n164_), .B(new_n44_), .C(p33), .Y(new_n165_));
  NOR3x1_ASAP7_75t_R  g122(.A(new_n162_), .B(new_n163_), .C(new_n165_), .Y(new_n166_));
  AOI21x1_ASAP7_75t_R g123(.A1(new_n158_), .A2(new_n161_), .B(new_n166_), .Y(new_n167_));
  AND3x1_ASAP7_75t_R  g124(.A(new_n143_), .B(new_n157_), .C(new_n167_), .Y(new_n168_));
  INVx1_ASAP7_75t_R   g125(.A(new_n168_), .Y(o2));
  AOI21x1_ASAP7_75t_R g126(.A1(new_n167_), .A2(new_n143_), .B(new_n139_), .Y(new_n170_));
  INVx1_ASAP7_75t_R   g127(.A(p19), .Y(new_n171_));
  OA21x2_ASAP7_75t_R  g128(.A1(new_n171_), .A2(new_n153_), .B(new_n140_), .Y(new_n172_));
  OAI21x1_ASAP7_75t_R g129(.A1(new_n139_), .A2(new_n157_), .B(new_n172_), .Y(new_n173_));
  NAND2x1_ASAP7_75t_R g130(.A(p6), .B(new_n91_), .Y(new_n174_));
  AO21x1_ASAP7_75t_R  g131(.A1(p20), .A2(o1), .B(new_n174_), .Y(new_n175_));
  INVx1_ASAP7_75t_R   g132(.A(p21), .Y(new_n176_));
  AOI21x1_ASAP7_75t_R g133(.A1(new_n126_), .A2(new_n125_), .B(new_n176_), .Y(new_n177_));
  AO21x1_ASAP7_75t_R  g134(.A1(new_n63_), .A2(new_n129_), .B(new_n61_), .Y(new_n178_));
  OAI21x1_ASAP7_75t_R g135(.A1(new_n176_), .A2(new_n109_), .B(new_n178_), .Y(new_n179_));
  OR3x1_ASAP7_75t_R   g136(.A(new_n177_), .B(new_n179_), .C(new_n82_), .Y(new_n180_));
  OAI21x1_ASAP7_75t_R g137(.A1(p30), .A2(new_n180_), .B(new_n156_), .Y(new_n181_));
  NOR2x1_ASAP7_75t_R  g138(.A(new_n175_), .B(new_n181_), .Y(new_n182_));
  OA21x2_ASAP7_75t_R  g139(.A1(new_n151_), .A2(new_n152_), .B(p19), .Y(new_n183_));
  OAI21x1_ASAP7_75t_R g140(.A1(new_n151_), .A2(new_n152_), .B(p23), .Y(new_n184_));
  NAND2x1_ASAP7_75t_R g141(.A(new_n136_), .B(new_n184_), .Y(new_n185_));
  OAI21x1_ASAP7_75t_R g142(.A1(new_n183_), .A2(new_n141_), .B(new_n185_), .Y(new_n186_));
  AO21x1_ASAP7_75t_R  g143(.A1(new_n158_), .A2(new_n161_), .B(new_n166_), .Y(new_n187_));
  NOR3x1_ASAP7_75t_R  g144(.A(new_n186_), .B(new_n187_), .C(new_n134_), .Y(new_n188_));
  AOI21x1_ASAP7_75t_R g145(.A1(p20), .A2(o1), .B(new_n145_), .Y(new_n189_));
  AOI21x1_ASAP7_75t_R g146(.A1(new_n182_), .A2(new_n188_), .B(new_n189_), .Y(new_n190_));
  OAI21x1_ASAP7_75t_R g147(.A1(new_n170_), .A2(new_n173_), .B(new_n190_), .Y(new_n191_));
  AOI21x1_ASAP7_75t_R g148(.A1(p21), .A2(o1), .B(new_n149_), .Y(new_n192_));
  INVx1_ASAP7_75t_R   g149(.A(new_n155_), .Y(new_n193_));
  AOI21x1_ASAP7_75t_R g150(.A1(p22), .A2(o1), .B(new_n193_), .Y(new_n194_));
  OR3x1_ASAP7_75t_R   g151(.A(new_n189_), .B(new_n192_), .C(new_n194_), .Y(new_n195_));
  NAND2x1_ASAP7_75t_R g152(.A(p0), .B(new_n130_), .Y(new_n196_));
  OR3x1_ASAP7_75t_R   g153(.A(new_n127_), .B(new_n128_), .C(new_n196_), .Y(new_n197_));
  AO21x1_ASAP7_75t_R  g154(.A1(p26), .A2(new_n195_), .B(new_n197_), .Y(new_n198_));
  NOR2x1_ASAP7_75t_R  g155(.A(new_n131_), .B(new_n188_), .Y(new_n199_));
  NOR3x1_ASAP7_75t_R  g156(.A(new_n181_), .B(new_n189_), .C(new_n124_), .Y(new_n200_));
  NOR2x1_ASAP7_75t_R  g157(.A(p27), .B(new_n124_), .Y(new_n201_));
  AOI21x1_ASAP7_75t_R g158(.A1(new_n188_), .A2(new_n200_), .B(new_n201_), .Y(new_n202_));
  OAI21x1_ASAP7_75t_R g159(.A1(new_n198_), .A2(new_n199_), .B(new_n202_), .Y(new_n203_));
  NOR2x1_ASAP7_75t_R  g160(.A(new_n191_), .B(new_n203_), .Y(new_n204_));
  AOI21x1_ASAP7_75t_R g161(.A1(new_n167_), .A2(new_n143_), .B(new_n147_), .Y(new_n205_));
  AO21x1_ASAP7_75t_R  g162(.A1(p30), .A2(new_n195_), .B(new_n180_), .Y(new_n206_));
  INVx1_ASAP7_75t_R   g163(.A(p31), .Y(new_n207_));
  AOI21x1_ASAP7_75t_R g164(.A1(p22), .A2(o1), .B(new_n154_), .Y(new_n208_));
  INVx1_ASAP7_75t_R   g165(.A(new_n208_), .Y(new_n209_));
  AOI21x1_ASAP7_75t_R g166(.A1(new_n146_), .A2(new_n150_), .B(new_n207_), .Y(new_n210_));
  NOR2x1_ASAP7_75t_R  g167(.A(new_n209_), .B(new_n210_), .Y(new_n211_));
  OAI21x1_ASAP7_75t_R g168(.A1(new_n207_), .A2(new_n188_), .B(new_n211_), .Y(new_n212_));
  OAI21x1_ASAP7_75t_R g169(.A1(new_n205_), .A2(new_n206_), .B(new_n212_), .Y(new_n213_));
  INVx1_ASAP7_75t_R   g170(.A(p32), .Y(new_n214_));
  INVx1_ASAP7_75t_R   g171(.A(new_n135_), .Y(new_n215_));
  AND2x2_ASAP7_75t_R  g172(.A(new_n215_), .B(new_n184_), .Y(new_n216_));
  OAI21x1_ASAP7_75t_R g173(.A1(new_n214_), .A2(new_n157_), .B(new_n216_), .Y(new_n217_));
  NOR2x1_ASAP7_75t_R  g174(.A(new_n214_), .B(new_n188_), .Y(new_n218_));
  AO21x1_ASAP7_75t_R  g175(.A1(p13), .A2(o0), .B(new_n44_), .Y(new_n219_));
  OR3x1_ASAP7_75t_R   g176(.A(new_n162_), .B(new_n163_), .C(new_n219_), .Y(new_n220_));
  NOR3x1_ASAP7_75t_R  g177(.A(new_n181_), .B(new_n189_), .C(new_n220_), .Y(new_n221_));
  AOI21x1_ASAP7_75t_R g178(.A1(new_n188_), .A2(new_n221_), .B(new_n166_), .Y(new_n222_));
  OAI21x1_ASAP7_75t_R g179(.A1(new_n217_), .A2(new_n218_), .B(new_n222_), .Y(new_n223_));
  NOR2x1_ASAP7_75t_R  g180(.A(new_n213_), .B(new_n223_), .Y(new_n224_));
  AO21x1_ASAP7_75t_R  g181(.A1(new_n157_), .A2(new_n188_), .B(new_n160_), .Y(new_n225_));
  AND2x2_ASAP7_75t_R  g182(.A(p16), .B(new_n159_), .Y(new_n226_));
  AND3x1_ASAP7_75t_R  g183(.A(new_n225_), .B(new_n158_), .C(new_n226_), .Y(new_n227_));
  AOI21x1_ASAP7_75t_R g184(.A1(new_n204_), .A2(new_n224_), .B(new_n227_), .Y(o3));
  INVx1_ASAP7_75t_R   g185(.A(new_n224_), .Y(o4));
  NOR2x1_ASAP7_75t_R  g186(.A(new_n138_), .B(new_n142_), .Y(new_n230_));
  INVx1_ASAP7_75t_R   g187(.A(p27), .Y(new_n231_));
  AO21x1_ASAP7_75t_R  g188(.A1(new_n116_), .A2(new_n123_), .B(new_n108_), .Y(new_n232_));
  NOR3x1_ASAP7_75t_R  g189(.A(new_n127_), .B(new_n128_), .C(new_n132_), .Y(new_n233_));
  AOI21x1_ASAP7_75t_R g190(.A1(new_n231_), .A2(new_n232_), .B(new_n233_), .Y(new_n234_));
  NAND3x1_ASAP7_75t_R g191(.A(new_n230_), .B(new_n167_), .C(new_n234_), .Y(new_n235_));
  NOR2x1_ASAP7_75t_R  g192(.A(new_n192_), .B(new_n194_), .Y(new_n236_));
  INVx1_ASAP7_75t_R   g193(.A(new_n180_), .Y(new_n237_));
  NAND3x1_ASAP7_75t_R g194(.A(new_n236_), .B(new_n146_), .C(new_n237_), .Y(new_n238_));
  NOR2x1_ASAP7_75t_R  g195(.A(new_n235_), .B(new_n238_), .Y(new_n239_));
  NAND3x1_ASAP7_75t_R g196(.A(new_n236_), .B(new_n146_), .C(new_n208_), .Y(new_n240_));
  OAI21x1_ASAP7_75t_R g197(.A1(new_n235_), .A2(new_n240_), .B(new_n236_), .Y(new_n241_));
  NOR2x1_ASAP7_75t_R  g198(.A(new_n239_), .B(new_n241_), .Y(new_n242_));
  NAND3x1_ASAP7_75t_R g199(.A(new_n236_), .B(new_n146_), .C(new_n216_), .Y(new_n243_));
  OAI21x1_ASAP7_75t_R g200(.A1(new_n235_), .A2(new_n243_), .B(new_n185_), .Y(new_n244_));
  NOR2x1_ASAP7_75t_R  g201(.A(new_n190_), .B(new_n244_), .Y(new_n245_));
  NAND2x1_ASAP7_75t_R g202(.A(new_n242_), .B(new_n245_), .Y(new_n246_));
  AND3x1_ASAP7_75t_R  g203(.A(new_n236_), .B(new_n146_), .C(new_n172_), .Y(new_n247_));
  AO21x1_ASAP7_75t_R  g204(.A1(new_n188_), .A2(new_n247_), .B(new_n142_), .Y(new_n248_));
  AOI21x1_ASAP7_75t_R g205(.A1(new_n248_), .A2(new_n242_), .B(new_n223_), .Y(new_n249_));
  NAND2x1_ASAP7_75t_R g206(.A(new_n246_), .B(new_n249_), .Y(o5));
  OA21x2_ASAP7_75t_R  g207(.A1(new_n202_), .A2(new_n248_), .B(new_n212_), .Y(new_n251_));
  INVx1_ASAP7_75t_R   g208(.A(new_n222_), .Y(new_n252_));
  AOI21x1_ASAP7_75t_R g209(.A1(new_n242_), .A2(new_n245_), .B(new_n252_), .Y(new_n253_));
  OAI21x1_ASAP7_75t_R g210(.A1(new_n244_), .A2(new_n251_), .B(new_n253_), .Y(o6));
endmodule


