// Benchmark "/tmp/" written by ABC on Mon Oct 12 14:43:37 2026

module \/tmp/  ( 
    p17, p24, p29, p22, p1, p25, p3, p12, p33, p23, p7, p6, p15, p11, p31,
    p8, p18, p13, p35, p26, p4, p28, p14, p16, p19, p2, p0, p9, p34, p30,
    p32, p10, p21, p27, p5, p20,
    o0, o1, o2, o3, o4, o5, o6  );
  input  p17, p24, p29, p22, p1, p25, p3, p12, p33, p23, p7, p6, p15,
    p11, p31, p8, p18, p13, p35, p26, p4, p28, p14, p16, p19, p2, p0, p9,
    p34, p30, p32, p10, p21, p27, p5, p20;
  output o0, o1, o2, o3, o4, o5, o6;
  wire new_n44_, new_n45_, new_n46_, new_n47_, new_n48_, new_n49_, new_n50_,
    new_n51_, new_n52_, new_n53_, new_n54_, new_n55_, new_n56_, new_n57_,
    new_n58_, new_n59_, new_n60_, new_n61_, new_n62_, new_n63_, new_n65_,
    new_n66_, new_n67_, new_n68_, new_n69_, new_n70_, new_n71_, new_n72_,
    new_n73_, new_n74_, new_n75_, new_n76_, new_n77_, new_n78_, new_n79_,
    new_n80_, new_n81_, new_n82_, new_n83_, new_n84_, new_n85_, new_n86_,
    new_n87_, new_n88_, new_n89_, new_n90_, new_n91_, new_n92_, new_n93_,
    new_n94_, new_n96_, new_n97_, new_n98_, new_n99_, new_n100_, new_n101_,
    new_n102_, new_n103_, new_n104_, new_n105_, new_n106_, new_n107_,
    new_n108_, new_n109_, new_n110_, new_n111_, new_n112_, new_n113_,
    new_n114_, new_n115_, new_n116_, new_n117_, new_n118_, new_n119_,
    new_n120_, new_n121_, new_n122_, new_n123_, new_n124_, new_n125_,
    new_n126_, new_n127_, new_n128_, new_n129_, new_n130_, new_n131_,
    new_n132_, new_n133_, new_n134_, new_n135_, new_n136_, new_n137_,
    new_n138_, new_n139_, new_n140_, new_n141_, new_n142_, new_n143_,
    new_n144_, new_n145_, new_n146_, new_n147_, new_n148_, new_n149_,
    new_n150_, new_n151_, new_n152_, new_n153_, new_n154_, new_n155_,
    new_n156_, new_n157_, new_n158_, new_n159_, new_n160_, new_n161_,
    new_n162_, new_n163_, new_n164_, new_n165_, new_n166_, new_n167_,
    new_n168_, new_n169_, new_n170_, new_n171_, new_n172_, new_n173_,
    new_n174_, new_n175_, new_n176_, new_n177_, new_n178_, new_n179_,
    new_n180_, new_n181_, new_n183_, new_n184_, new_n185_, new_n186_,
    new_n187_, new_n188_, new_n189_, new_n190_, new_n191_, new_n192_,
    new_n193_, new_n194_, new_n195_, new_n196_, new_n197_, new_n198_,
    new_n199_, new_n200_, new_n201_, new_n202_, new_n203_, new_n204_,
    new_n205_, new_n206_, new_n207_, new_n208_, new_n209_, new_n210_,
    new_n211_, new_n212_, new_n213_, new_n214_, new_n215_, new_n216_,
    new_n217_, new_n218_, new_n219_, new_n220_, new_n221_, new_n222_,
    new_n223_, new_n224_, new_n225_, new_n226_, new_n227_, new_n228_,
    new_n229_, new_n230_, new_n231_, new_n232_, new_n233_, new_n234_,
    new_n235_, new_n236_, new_n237_, new_n238_, new_n239_, new_n241_,
    new_n242_, new_n243_, new_n244_, new_n245_, new_n246_, new_n247_,
    new_n248_, new_n249_, new_n250_, new_n251_, new_n252_, new_n253_,
    new_n254_, new_n256_, new_n257_, new_n258_, new_n259_, new_n260_,
    new_n261_, new_n262_, new_n263_, new_n264_, new_n265_, new_n266_,
    new_n268_, new_n269_, new_n270_, new_n271_, new_n272_, new_n273_,
    new_n274_, new_n275_;
  INVx1_ASAP7_75t_R   g000(.A(p0), .Y(new_n44_));
  INVx1_ASAP7_75t_R   g001(.A(p1), .Y(new_n45_));
  NAND2x1_ASAP7_75t_R g002(.A(p2), .B(new_n45_), .Y(new_n46_));
  OAI21x1_ASAP7_75t_R g003(.A1(p35), .A2(new_n44_), .B(new_n46_), .Y(new_n47_));
  INVx1_ASAP7_75t_R   g004(.A(p12), .Y(new_n48_));
  INVx1_ASAP7_75t_R   g005(.A(p3), .Y(new_n49_));
  NAND2x1_ASAP7_75t_R g006(.A(p4), .B(new_n49_), .Y(new_n50_));
  OAI21x1_ASAP7_75t_R g007(.A1(new_n48_), .A2(p11), .B(new_n50_), .Y(new_n51_));
  NOR2x1_ASAP7_75t_R  g008(.A(new_n47_), .B(new_n51_), .Y(new_n52_));
  INVx1_ASAP7_75t_R   g009(.A(p13), .Y(new_n53_));
  INVx1_ASAP7_75t_R   g010(.A(p16), .Y(new_n54_));
  NOR2x1_ASAP7_75t_R  g011(.A(p15), .B(new_n54_), .Y(new_n55_));
  AOI21x1_ASAP7_75t_R g012(.A1(new_n53_), .A2(p14), .B(new_n55_), .Y(new_n56_));
  INVx1_ASAP7_75t_R   g013(.A(p6), .Y(new_n57_));
  NOR2x1_ASAP7_75t_R  g014(.A(p5), .B(new_n57_), .Y(new_n58_));
  INVx1_ASAP7_75t_R   g015(.A(p10), .Y(new_n59_));
  NOR2x1_ASAP7_75t_R  g016(.A(p9), .B(new_n59_), .Y(new_n60_));
  INVx1_ASAP7_75t_R   g017(.A(p8), .Y(new_n61_));
  NOR2x1_ASAP7_75t_R  g018(.A(p7), .B(new_n61_), .Y(new_n62_));
  NOR3x1_ASAP7_75t_R  g019(.A(new_n58_), .B(new_n60_), .C(new_n62_), .Y(new_n63_));
  NAND3x1_ASAP7_75t_R g020(.A(new_n52_), .B(new_n56_), .C(new_n63_), .Y(o0));
  INVx1_ASAP7_75t_R   g021(.A(p4), .Y(new_n65_));
  OR2x4_ASAP7_75t_R   g022(.A(p19), .B(new_n65_), .Y(new_n66_));
  AOI21x1_ASAP7_75t_R g023(.A1(new_n50_), .A2(o0), .B(new_n66_), .Y(new_n67_));
  INVx1_ASAP7_75t_R   g024(.A(p23), .Y(new_n68_));
  NAND2x1_ASAP7_75t_R g025(.A(p12), .B(new_n68_), .Y(new_n69_));
  AOI21x1_ASAP7_75t_R g026(.A1(p11), .A2(o0), .B(new_n69_), .Y(new_n70_));
  INVx1_ASAP7_75t_R   g027(.A(p18), .Y(new_n71_));
  NAND2x1_ASAP7_75t_R g028(.A(p2), .B(new_n71_), .Y(new_n72_));
  AOI21x1_ASAP7_75t_R g029(.A1(p1), .A2(o0), .B(new_n72_), .Y(new_n73_));
  NOR3x1_ASAP7_75t_R  g030(.A(new_n67_), .B(new_n70_), .C(new_n73_), .Y(new_n74_));
  NOR2x1_ASAP7_75t_R  g031(.A(p25), .B(new_n54_), .Y(new_n75_));
  INVx1_ASAP7_75t_R   g032(.A(new_n75_), .Y(new_n76_));
  AOI21x1_ASAP7_75t_R g033(.A1(p15), .A2(o0), .B(new_n76_), .Y(new_n77_));
  INVx1_ASAP7_75t_R   g034(.A(p17), .Y(new_n78_));
  NAND2x1_ASAP7_75t_R g035(.A(p0), .B(new_n78_), .Y(new_n79_));
  AOI21x1_ASAP7_75t_R g036(.A1(p35), .A2(o0), .B(new_n79_), .Y(new_n80_));
  INVx1_ASAP7_75t_R   g037(.A(p14), .Y(new_n81_));
  NOR2x1_ASAP7_75t_R  g038(.A(p24), .B(new_n81_), .Y(new_n82_));
  INVx1_ASAP7_75t_R   g039(.A(new_n82_), .Y(new_n83_));
  AOI21x1_ASAP7_75t_R g040(.A1(p13), .A2(o0), .B(new_n83_), .Y(new_n84_));
  NOR3x1_ASAP7_75t_R  g041(.A(new_n77_), .B(new_n80_), .C(new_n84_), .Y(new_n85_));
  NOR2x1_ASAP7_75t_R  g042(.A(p21), .B(new_n61_), .Y(new_n86_));
  INVx1_ASAP7_75t_R   g043(.A(new_n86_), .Y(new_n87_));
  AOI21x1_ASAP7_75t_R g044(.A1(p7), .A2(o0), .B(new_n87_), .Y(new_n88_));
  OR2x4_ASAP7_75t_R   g045(.A(p20), .B(new_n57_), .Y(new_n89_));
  AOI21x1_ASAP7_75t_R g046(.A1(p5), .A2(o0), .B(new_n89_), .Y(new_n90_));
  NOR2x1_ASAP7_75t_R  g047(.A(p22), .B(new_n59_), .Y(new_n91_));
  INVx1_ASAP7_75t_R   g048(.A(new_n91_), .Y(new_n92_));
  AOI21x1_ASAP7_75t_R g049(.A1(p9), .A2(o0), .B(new_n92_), .Y(new_n93_));
  NOR3x1_ASAP7_75t_R  g050(.A(new_n88_), .B(new_n90_), .C(new_n93_), .Y(new_n94_));
  NAND3x1_ASAP7_75t_R g051(.A(new_n74_), .B(new_n85_), .C(new_n94_), .Y(o1));
  INVx1_ASAP7_75t_R   g052(.A(p30), .Y(new_n96_));
  NAND2x1_ASAP7_75t_R g053(.A(p8), .B(new_n96_), .Y(new_n97_));
  AO21x1_ASAP7_75t_R  g054(.A1(p7), .A2(o0), .B(new_n97_), .Y(new_n98_));
  AOI21x1_ASAP7_75t_R g055(.A1(p21), .A2(o1), .B(new_n98_), .Y(new_n99_));
  AO21x1_ASAP7_75t_R  g056(.A1(p5), .A2(o0), .B(new_n57_), .Y(new_n100_));
  OR2x4_ASAP7_75t_R   g057(.A(p29), .B(new_n100_), .Y(new_n101_));
  NOR2x1_ASAP7_75t_R  g058(.A(new_n70_), .B(new_n73_), .Y(new_n102_));
  AO21x1_ASAP7_75t_R  g059(.A1(new_n50_), .A2(o0), .B(new_n66_), .Y(new_n103_));
  AO21x1_ASAP7_75t_R  g060(.A1(p5), .A2(o0), .B(new_n89_), .Y(new_n104_));
  AND3x1_ASAP7_75t_R  g061(.A(new_n102_), .B(new_n103_), .C(new_n104_), .Y(new_n105_));
  NOR2x1_ASAP7_75t_R  g062(.A(new_n77_), .B(new_n88_), .Y(new_n106_));
  NOR2x1_ASAP7_75t_R  g063(.A(new_n80_), .B(new_n84_), .Y(new_n107_));
  INVx1_ASAP7_75t_R   g064(.A(p2), .Y(new_n108_));
  NOR2x1_ASAP7_75t_R  g065(.A(p1), .B(new_n108_), .Y(new_n109_));
  NOR2x1_ASAP7_75t_R  g066(.A(new_n55_), .B(new_n109_), .Y(new_n110_));
  NOR2x1_ASAP7_75t_R  g067(.A(new_n60_), .B(new_n62_), .Y(new_n111_));
  NAND2x1_ASAP7_75t_R g068(.A(new_n110_), .B(new_n111_), .Y(new_n112_));
  AOI21x1_ASAP7_75t_R g069(.A1(new_n53_), .A2(p14), .B(new_n58_), .Y(new_n113_));
  NOR2x1_ASAP7_75t_R  g070(.A(p11), .B(new_n48_), .Y(new_n114_));
  NOR2x1_ASAP7_75t_R  g071(.A(p35), .B(new_n44_), .Y(new_n115_));
  NOR2x1_ASAP7_75t_R  g072(.A(new_n114_), .B(new_n115_), .Y(new_n116_));
  NAND3x1_ASAP7_75t_R g073(.A(new_n113_), .B(new_n116_), .C(new_n50_), .Y(new_n117_));
  OAI21x1_ASAP7_75t_R g074(.A1(new_n112_), .A2(new_n117_), .B(p9), .Y(new_n118_));
  NAND2x1_ASAP7_75t_R g075(.A(new_n91_), .B(new_n118_), .Y(new_n119_));
  AND3x1_ASAP7_75t_R  g076(.A(new_n106_), .B(new_n107_), .C(new_n119_), .Y(new_n120_));
  INVx1_ASAP7_75t_R   g077(.A(p20), .Y(new_n121_));
  AOI21x1_ASAP7_75t_R g078(.A1(new_n105_), .A2(new_n120_), .B(new_n121_), .Y(new_n122_));
  AO21x1_ASAP7_75t_R  g079(.A1(p11), .A2(o0), .B(new_n69_), .Y(new_n123_));
  AO21x1_ASAP7_75t_R  g080(.A1(p1), .A2(o0), .B(new_n72_), .Y(new_n124_));
  NAND3x1_ASAP7_75t_R g081(.A(new_n103_), .B(new_n123_), .C(new_n124_), .Y(new_n125_));
  INVx1_ASAP7_75t_R   g082(.A(new_n118_), .Y(new_n126_));
  AOI21x1_ASAP7_75t_R g083(.A1(p22), .A2(new_n125_), .B(new_n126_), .Y(new_n127_));
  INVx1_ASAP7_75t_R   g084(.A(new_n56_), .Y(new_n128_));
  NOR2x1_ASAP7_75t_R  g085(.A(new_n115_), .B(new_n109_), .Y(new_n129_));
  AOI21x1_ASAP7_75t_R g086(.A1(new_n49_), .A2(p4), .B(new_n114_), .Y(new_n130_));
  NAND2x1_ASAP7_75t_R g087(.A(new_n129_), .B(new_n130_), .Y(new_n131_));
  OAI21x1_ASAP7_75t_R g088(.A1(new_n128_), .A2(new_n131_), .B(p7), .Y(new_n132_));
  INVx1_ASAP7_75t_R   g089(.A(new_n58_), .Y(new_n133_));
  INVx1_ASAP7_75t_R   g090(.A(p7), .Y(new_n134_));
  AO21x1_ASAP7_75t_R  g091(.A1(new_n133_), .A2(new_n111_), .B(new_n134_), .Y(new_n135_));
  NAND3x1_ASAP7_75t_R g092(.A(new_n132_), .B(new_n135_), .C(new_n86_), .Y(new_n136_));
  NAND3x1_ASAP7_75t_R g093(.A(new_n104_), .B(new_n119_), .C(new_n136_), .Y(new_n137_));
  AO21x1_ASAP7_75t_R  g094(.A1(p35), .A2(o0), .B(new_n79_), .Y(new_n138_));
  NOR2x1_ASAP7_75t_R  g095(.A(new_n112_), .B(new_n117_), .Y(new_n139_));
  OAI21x1_ASAP7_75t_R g096(.A1(new_n53_), .A2(new_n139_), .B(new_n82_), .Y(new_n140_));
  OAI21x1_ASAP7_75t_R g097(.A1(new_n128_), .A2(new_n131_), .B(p15), .Y(new_n141_));
  INVx1_ASAP7_75t_R   g098(.A(p15), .Y(new_n142_));
  AO21x1_ASAP7_75t_R  g099(.A1(new_n133_), .A2(new_n111_), .B(new_n142_), .Y(new_n143_));
  NAND3x1_ASAP7_75t_R g100(.A(new_n141_), .B(new_n143_), .C(new_n75_), .Y(new_n144_));
  NAND3x1_ASAP7_75t_R g101(.A(new_n138_), .B(new_n140_), .C(new_n144_), .Y(new_n145_));
  OAI21x1_ASAP7_75t_R g102(.A1(new_n137_), .A2(new_n145_), .B(p22), .Y(new_n146_));
  NOR2x1_ASAP7_75t_R  g103(.A(p31), .B(new_n59_), .Y(new_n147_));
  NAND3x1_ASAP7_75t_R g104(.A(new_n127_), .B(new_n146_), .C(new_n147_), .Y(new_n148_));
  OAI21x1_ASAP7_75t_R g105(.A1(new_n101_), .A2(new_n122_), .B(new_n148_), .Y(new_n149_));
  NOR2x1_ASAP7_75t_R  g106(.A(new_n99_), .B(new_n149_), .Y(new_n150_));
  INVx1_ASAP7_75t_R   g107(.A(p25), .Y(new_n151_));
  AOI21x1_ASAP7_75t_R g108(.A1(new_n105_), .A2(new_n120_), .B(new_n151_), .Y(new_n152_));
  INVx1_ASAP7_75t_R   g109(.A(p34), .Y(new_n153_));
  AND3x1_ASAP7_75t_R  g110(.A(new_n141_), .B(p16), .C(new_n143_), .Y(new_n154_));
  NAND2x1_ASAP7_75t_R g111(.A(new_n153_), .B(new_n154_), .Y(new_n155_));
  INVx1_ASAP7_75t_R   g112(.A(p24), .Y(new_n156_));
  NOR3x1_ASAP7_75t_R  g113(.A(new_n125_), .B(new_n145_), .C(new_n137_), .Y(new_n157_));
  AO21x1_ASAP7_75t_R  g114(.A1(p13), .A2(o0), .B(new_n81_), .Y(new_n158_));
  NOR2x1_ASAP7_75t_R  g115(.A(p33), .B(new_n158_), .Y(new_n159_));
  OAI21x1_ASAP7_75t_R g116(.A1(new_n156_), .A2(new_n157_), .B(new_n159_), .Y(new_n160_));
  OAI21x1_ASAP7_75t_R g117(.A1(new_n152_), .A2(new_n155_), .B(new_n160_), .Y(new_n161_));
  AND2x2_ASAP7_75t_R  g118(.A(p35), .B(o0), .Y(new_n162_));
  OR3x1_ASAP7_75t_R   g119(.A(new_n162_), .B(p26), .C(new_n44_), .Y(new_n163_));
  AOI21x1_ASAP7_75t_R g120(.A1(new_n105_), .A2(new_n120_), .B(new_n78_), .Y(new_n164_));
  OAI21x1_ASAP7_75t_R g121(.A1(new_n137_), .A2(new_n145_), .B(p18), .Y(new_n165_));
  AO21x1_ASAP7_75t_R  g122(.A1(new_n103_), .A2(new_n102_), .B(new_n71_), .Y(new_n166_));
  AO21x1_ASAP7_75t_R  g123(.A1(p1), .A2(o0), .B(new_n108_), .Y(new_n167_));
  NOR2x1_ASAP7_75t_R  g124(.A(p27), .B(new_n167_), .Y(new_n168_));
  NAND3x1_ASAP7_75t_R g125(.A(new_n165_), .B(new_n166_), .C(new_n168_), .Y(new_n169_));
  OAI21x1_ASAP7_75t_R g126(.A1(new_n163_), .A2(new_n164_), .B(new_n169_), .Y(new_n170_));
  AO21x1_ASAP7_75t_R  g127(.A1(p11), .A2(o0), .B(new_n48_), .Y(new_n171_));
  OR2x4_ASAP7_75t_R   g128(.A(p32), .B(new_n171_), .Y(new_n172_));
  OAI21x1_ASAP7_75t_R g129(.A1(new_n137_), .A2(new_n145_), .B(p23), .Y(new_n173_));
  OAI21x1_ASAP7_75t_R g130(.A1(new_n68_), .A2(new_n74_), .B(new_n173_), .Y(new_n174_));
  OAI21x1_ASAP7_75t_R g131(.A1(new_n137_), .A2(new_n145_), .B(new_n103_), .Y(new_n175_));
  AO21x1_ASAP7_75t_R  g132(.A1(new_n123_), .A2(new_n124_), .B(new_n67_), .Y(new_n176_));
  AO21x1_ASAP7_75t_R  g133(.A1(p3), .A2(o0), .B(new_n65_), .Y(new_n177_));
  NOR2x1_ASAP7_75t_R  g134(.A(p28), .B(new_n177_), .Y(new_n178_));
  NAND3x1_ASAP7_75t_R g135(.A(new_n175_), .B(new_n176_), .C(new_n178_), .Y(new_n179_));
  OAI21x1_ASAP7_75t_R g136(.A1(new_n172_), .A2(new_n174_), .B(new_n179_), .Y(new_n180_));
  NOR3x1_ASAP7_75t_R  g137(.A(new_n161_), .B(new_n170_), .C(new_n180_), .Y(new_n181_));
  NAND2x1_ASAP7_75t_R g138(.A(new_n150_), .B(new_n181_), .Y(o2));
  AOI21x1_ASAP7_75t_R g139(.A1(p25), .A2(o1), .B(new_n155_), .Y(new_n183_));
  AOI21x1_ASAP7_75t_R g140(.A1(new_n85_), .A2(new_n94_), .B(new_n71_), .Y(new_n184_));
  NOR2x1_ASAP7_75t_R  g141(.A(new_n71_), .B(new_n74_), .Y(new_n185_));
  INVx1_ASAP7_75t_R   g142(.A(new_n168_), .Y(new_n186_));
  NOR3x1_ASAP7_75t_R  g143(.A(new_n184_), .B(new_n185_), .C(new_n186_), .Y(new_n187_));
  AOI21x1_ASAP7_75t_R g144(.A1(new_n85_), .A2(new_n94_), .B(new_n68_), .Y(new_n188_));
  NOR2x1_ASAP7_75t_R  g145(.A(new_n68_), .B(new_n74_), .Y(new_n189_));
  NOR3x1_ASAP7_75t_R  g146(.A(new_n188_), .B(new_n189_), .C(new_n172_), .Y(new_n190_));
  NOR3x1_ASAP7_75t_R  g147(.A(new_n183_), .B(new_n187_), .C(new_n190_), .Y(new_n191_));
  AOI21x1_ASAP7_75t_R g148(.A1(p17), .A2(o1), .B(new_n163_), .Y(new_n192_));
  INVx1_ASAP7_75t_R   g149(.A(new_n159_), .Y(new_n193_));
  AOI21x1_ASAP7_75t_R g150(.A1(p24), .A2(o1), .B(new_n193_), .Y(new_n194_));
  AOI21x1_ASAP7_75t_R g151(.A1(new_n85_), .A2(new_n94_), .B(new_n67_), .Y(new_n195_));
  INVx1_ASAP7_75t_R   g152(.A(new_n178_), .Y(new_n196_));
  INVx1_ASAP7_75t_R   g153(.A(new_n176_), .Y(new_n197_));
  NOR3x1_ASAP7_75t_R  g154(.A(new_n195_), .B(new_n196_), .C(new_n197_), .Y(new_n198_));
  NOR3x1_ASAP7_75t_R  g155(.A(new_n192_), .B(new_n194_), .C(new_n198_), .Y(new_n199_));
  INVx1_ASAP7_75t_R   g156(.A(p27), .Y(new_n200_));
  AOI21x1_ASAP7_75t_R g157(.A1(new_n191_), .A2(new_n199_), .B(new_n200_), .Y(new_n201_));
  AND3x1_ASAP7_75t_R  g158(.A(new_n127_), .B(new_n146_), .C(new_n147_), .Y(new_n202_));
  AOI21x1_ASAP7_75t_R g159(.A1(p20), .A2(o1), .B(new_n101_), .Y(new_n203_));
  OR3x1_ASAP7_75t_R   g160(.A(new_n202_), .B(new_n99_), .C(new_n203_), .Y(new_n204_));
  OR3x1_ASAP7_75t_R   g161(.A(new_n184_), .B(new_n185_), .C(new_n167_), .Y(new_n205_));
  AO21x1_ASAP7_75t_R  g162(.A1(p27), .A2(new_n204_), .B(new_n205_), .Y(new_n206_));
  AO21x1_ASAP7_75t_R  g163(.A1(p20), .A2(o1), .B(new_n100_), .Y(new_n207_));
  NOR3x1_ASAP7_75t_R  g164(.A(new_n149_), .B(new_n99_), .C(new_n207_), .Y(new_n208_));
  AOI21x1_ASAP7_75t_R g165(.A1(new_n208_), .A2(new_n181_), .B(new_n203_), .Y(new_n209_));
  OAI21x1_ASAP7_75t_R g166(.A1(new_n201_), .A2(new_n206_), .B(new_n209_), .Y(new_n210_));
  INVx1_ASAP7_75t_R   g167(.A(p26), .Y(new_n211_));
  AOI21x1_ASAP7_75t_R g168(.A1(new_n191_), .A2(new_n199_), .B(new_n211_), .Y(new_n212_));
  OR3x1_ASAP7_75t_R   g169(.A(new_n164_), .B(new_n44_), .C(new_n162_), .Y(new_n213_));
  AO21x1_ASAP7_75t_R  g170(.A1(p26), .A2(new_n204_), .B(new_n213_), .Y(new_n214_));
  AO21x1_ASAP7_75t_R  g171(.A1(p19), .A2(o1), .B(new_n177_), .Y(new_n215_));
  NOR3x1_ASAP7_75t_R  g172(.A(new_n149_), .B(new_n99_), .C(new_n215_), .Y(new_n216_));
  AOI21x1_ASAP7_75t_R g173(.A1(new_n216_), .A2(new_n181_), .B(new_n198_), .Y(new_n217_));
  OAI21x1_ASAP7_75t_R g174(.A1(new_n212_), .A2(new_n214_), .B(new_n217_), .Y(new_n218_));
  OAI21x1_ASAP7_75t_R g175(.A1(new_n151_), .A2(new_n157_), .B(new_n154_), .Y(new_n219_));
  AO21x1_ASAP7_75t_R  g176(.A1(p34), .A2(o2), .B(new_n219_), .Y(new_n220_));
  OAI21x1_ASAP7_75t_R g177(.A1(new_n210_), .A2(new_n218_), .B(new_n220_), .Y(new_n221_));
  INVx1_ASAP7_75t_R   g178(.A(p31), .Y(new_n222_));
  AND3x1_ASAP7_75t_R  g179(.A(new_n127_), .B(new_n146_), .C(p10), .Y(new_n223_));
  OAI21x1_ASAP7_75t_R g180(.A1(new_n222_), .A2(new_n150_), .B(new_n223_), .Y(new_n224_));
  NOR2x1_ASAP7_75t_R  g181(.A(new_n222_), .B(new_n181_), .Y(new_n225_));
  AO21x1_ASAP7_75t_R  g182(.A1(p7), .A2(o0), .B(new_n61_), .Y(new_n226_));
  AO21x1_ASAP7_75t_R  g183(.A1(p21), .A2(o1), .B(new_n226_), .Y(new_n227_));
  AOI21x1_ASAP7_75t_R g184(.A1(p30), .A2(new_n149_), .B(new_n227_), .Y(new_n228_));
  OAI21x1_ASAP7_75t_R g185(.A1(new_n96_), .A2(new_n181_), .B(new_n228_), .Y(new_n229_));
  OAI21x1_ASAP7_75t_R g186(.A1(new_n224_), .A2(new_n225_), .B(new_n229_), .Y(new_n230_));
  AO21x1_ASAP7_75t_R  g187(.A1(p24), .A2(o1), .B(new_n158_), .Y(new_n231_));
  AO21x1_ASAP7_75t_R  g188(.A1(p33), .A2(new_n204_), .B(new_n231_), .Y(new_n232_));
  INVx1_ASAP7_75t_R   g189(.A(p33), .Y(new_n233_));
  NOR2x1_ASAP7_75t_R  g190(.A(new_n233_), .B(new_n181_), .Y(new_n234_));
  OR3x1_ASAP7_75t_R   g191(.A(new_n188_), .B(new_n189_), .C(new_n171_), .Y(new_n235_));
  NOR3x1_ASAP7_75t_R  g192(.A(new_n149_), .B(new_n99_), .C(new_n235_), .Y(new_n236_));
  AOI21x1_ASAP7_75t_R g193(.A1(new_n236_), .A2(new_n181_), .B(new_n190_), .Y(new_n237_));
  OAI21x1_ASAP7_75t_R g194(.A1(new_n232_), .A2(new_n234_), .B(new_n237_), .Y(new_n238_));
  OAI21x1_ASAP7_75t_R g195(.A1(new_n230_), .A2(new_n238_), .B(new_n220_), .Y(new_n239_));
  NAND2x1_ASAP7_75t_R g196(.A(new_n221_), .B(new_n239_), .Y(o3));
  NAND2x1_ASAP7_75t_R g197(.A(new_n118_), .B(new_n74_), .Y(new_n241_));
  NAND2x1_ASAP7_75t_R g198(.A(new_n85_), .B(new_n94_), .Y(new_n242_));
  AO21x1_ASAP7_75t_R  g199(.A1(p9), .A2(o0), .B(p22), .Y(new_n243_));
  OAI21x1_ASAP7_75t_R g200(.A1(new_n241_), .A2(new_n242_), .B(new_n243_), .Y(new_n244_));
  AOI21x1_ASAP7_75t_R g201(.A1(new_n244_), .A2(new_n147_), .B(new_n203_), .Y(new_n245_));
  INVx1_ASAP7_75t_R   g202(.A(new_n99_), .Y(new_n246_));
  NAND3x1_ASAP7_75t_R g203(.A(new_n245_), .B(new_n246_), .C(new_n223_), .Y(new_n247_));
  NOR2x1_ASAP7_75t_R  g204(.A(new_n194_), .B(new_n183_), .Y(new_n248_));
  NOR2x1_ASAP7_75t_R  g205(.A(new_n187_), .B(new_n192_), .Y(new_n249_));
  NOR2x1_ASAP7_75t_R  g206(.A(new_n190_), .B(new_n198_), .Y(new_n250_));
  NAND3x1_ASAP7_75t_R g207(.A(new_n248_), .B(new_n249_), .C(new_n250_), .Y(new_n251_));
  OAI21x1_ASAP7_75t_R g208(.A1(new_n247_), .A2(new_n251_), .B(new_n148_), .Y(new_n252_));
  AO21x1_ASAP7_75t_R  g209(.A1(p30), .A2(new_n149_), .B(new_n227_), .Y(new_n253_));
  AOI21x1_ASAP7_75t_R g210(.A1(p30), .A2(new_n251_), .B(new_n253_), .Y(new_n254_));
  OR3x1_ASAP7_75t_R   g211(.A(new_n238_), .B(new_n252_), .C(new_n254_), .Y(o4));
  NOR2x1_ASAP7_75t_R  g212(.A(new_n254_), .B(new_n252_), .Y(new_n256_));
  INVx1_ASAP7_75t_R   g213(.A(new_n235_), .Y(new_n257_));
  NAND3x1_ASAP7_75t_R g214(.A(new_n245_), .B(new_n246_), .C(new_n257_), .Y(new_n258_));
  INVx1_ASAP7_75t_R   g215(.A(new_n190_), .Y(new_n259_));
  OAI21x1_ASAP7_75t_R g216(.A1(new_n258_), .A2(new_n251_), .B(new_n259_), .Y(new_n260_));
  NOR2x1_ASAP7_75t_R  g217(.A(new_n209_), .B(new_n260_), .Y(new_n261_));
  NAND2x1_ASAP7_75t_R g218(.A(new_n256_), .B(new_n261_), .Y(new_n262_));
  INVx1_ASAP7_75t_R   g219(.A(new_n215_), .Y(new_n263_));
  NAND3x1_ASAP7_75t_R g220(.A(new_n245_), .B(new_n263_), .C(new_n246_), .Y(new_n264_));
  OAI21x1_ASAP7_75t_R g221(.A1(new_n264_), .A2(new_n251_), .B(new_n179_), .Y(new_n265_));
  AOI21x1_ASAP7_75t_R g222(.A1(new_n265_), .A2(new_n256_), .B(new_n238_), .Y(new_n266_));
  NAND2x1_ASAP7_75t_R g223(.A(new_n262_), .B(new_n266_), .Y(o5));
  NOR3x1_ASAP7_75t_R  g224(.A(new_n149_), .B(new_n99_), .C(new_n205_), .Y(new_n268_));
  AOI21x1_ASAP7_75t_R g225(.A1(new_n268_), .A2(new_n181_), .B(new_n187_), .Y(new_n269_));
  AND3x1_ASAP7_75t_R  g226(.A(new_n245_), .B(new_n246_), .C(new_n223_), .Y(new_n270_));
  AOI21x1_ASAP7_75t_R g227(.A1(new_n181_), .A2(new_n270_), .B(new_n202_), .Y(new_n271_));
  OAI21x1_ASAP7_75t_R g228(.A1(new_n269_), .A2(new_n265_), .B(new_n271_), .Y(new_n272_));
  NAND2x1_ASAP7_75t_R g229(.A(new_n237_), .B(new_n272_), .Y(new_n273_));
  NOR2x1_ASAP7_75t_R  g230(.A(new_n232_), .B(new_n234_), .Y(new_n274_));
  AOI21x1_ASAP7_75t_R g231(.A1(new_n256_), .A2(new_n261_), .B(new_n274_), .Y(new_n275_));
  NAND2x1_ASAP7_75t_R g232(.A(new_n273_), .B(new_n275_), .Y(o6));
endmodule


