// Benchmark "/tmp/" written by ABC on Mon Oct 12 14:43:37 2026

module \/tmp/  ( 
    p15, p10, p30, p9, p3, p16, p1, p34, p24, p20, p17, p29, p26, p28, p4,
    p0, p35, p32, p6, p14, p13, p25, p11, p33, p18, p21, p7, p27, p19, p8,
    p31, p2, p23, p22, p5, p12,
    o0, o1, o2, o3, o4, o5, o6  );
  input  p15, p10, p30, p9, p3, p16, p1, p34, p24, p20, p17, p29, p26,
    p28, p4, p0, p35, p32, p6, p14, p13, p25, p11, p33, p18, p21, p7, p27,
    p19, p8, p31, p2, p23, p22, p5, p12;
  output o0, o1, o2, o3, o4, o5, o6;
  wire new_n44_, new_n45_, new_n46_, new_n47_, new_n48_, new_n49_, new_n50_,
    new_n51_, new_n52_, new_n53_, new_n54_, new_n55_, new_n56_, new_n57_,
    new_n58_, new_n59_, new_n60_, new_n61_, new_n62_, new_n63_, new_n64_,
    new_n66_, new_n67_, new_n68_, new_n69_, new_n70_, new_n71_, new_n72_,
    new_n73_, new_n74_, new_n75_, new_n76_, new_n77_, new_n78_, new_n79_,
    new_n80_, new_n81_, new_n82_, new_n83_, new_n84_, new_n85_, new_n86_,
    new_n87_, new_n88_, new_n89_, new_n90_, new_n91_, new_n92_, new_n93_,
    new_n94_, new_n95_, new_n96_, new_n97_, new_n98_, new_n100_, new_n101_,
    new_n102_, new_n103_, new_n104_, new_n105_, new_n106_, new_n107_,
    new_n108_, new_n109_, new_n110_, new_n111_, new_n112_, new_n113_,
    new_n114_, new_n115_, new_n116_, new_n117_, new_n118_, new_n119_,
    new_n120_, new_n121_, new_n122_, new_n123_, new_n124_, new_n125_,
    new_n126_, new_n127_, new_n128_, new_n129_, new_n130_, new_n131_,
    new_n132_, new_n133_, new_n134_, new_n135_, new_n136_, new_n137_,
    new_n138_, new_n139_, new_n140_, new_n141_, new_n142_, new_n143_,
    new_n144_, new_n145_, new_n146_, new_n147_, new_n148_, new_n149_,
    new_n150_, new_n151_, new_n152_, new_n153_, new_n154_, new_n155_,
    new_n156_, new_n157_, new_n158_, new_n159_, new_n160_, new_n161_,
    new_n162_, new_n163_, new_n164_, new_n165_, new_n166_, new_n167_,
    new_n168_, new_n169_, new_n170_, new_n171_, new_n173_, new_n174_,
    new_n175_, new_n176_, new_n177_, new_n178_, new_n179_, new_n180_,
    new_n181_, new_n182_, new_n183_, new_n184_, new_n185_, new_n186_,
    new_n187_, new_n188_, new_n189_, new_n190_, new_n191_, new_n192_,
    new_n193_, new_n194_, new_n195_, new_n196_, new_n197_, new_n198_,
    new_n199_, new_n200_, new_n201_, new_n202_, new_n203_, new_n204_,
    new_n205_, new_n206_, new_n207_, new_n208_, new_n209_, new_n210_,
    new_n211_, new_n212_, new_n213_, new_n214_, new_n215_, new_n216_,
    new_n217_, new_n218_, new_n219_, new_n220_, new_n221_, new_n222_,
    new_n223_, new_n224_, new_n225_, new_n226_, new_n227_, new_n228_,
    new_n229_, new_n230_, new_n231_, new_n232_, new_n233_, new_n234_,
    new_n235_, new_n236_, new_n237_, new_n240_, new_n241_, new_n242_,
    new_n243_, new_n244_, new_n245_, new_n246_, new_n247_, new_n248_,
    new_n249_, new_n250_, new_n251_, new_n252_, new_n253_, new_n254_,
    new_n255_, new_n256_, new_n257_, new_n258_, new_n259_, new_n260_,
    new_n261_, new_n263_, new_n264_, new_n265_;
  INVx1_ASAP7_75t_R   g000(.A(p4), .Y(new_n44_));
  INVx1_ASAP7_75t_R   g001(.A(p11), .Y(new_n45_));
  NAND2x1_ASAP7_75t_R g002(.A(p12), .B(new_n45_), .Y(new_n46_));
  OAI21x1_ASAP7_75t_R g003(.A1(p3), .A2(new_n44_), .B(new_n46_), .Y(new_n47_));
  INVx1_ASAP7_75t_R   g004(.A(p14), .Y(new_n48_));
  INVx1_ASAP7_75t_R   g005(.A(p15), .Y(new_n49_));
  NAND2x1_ASAP7_75t_R g006(.A(p16), .B(new_n49_), .Y(new_n50_));
  OAI21x1_ASAP7_75t_R g007(.A1(new_n48_), .A2(p13), .B(new_n50_), .Y(new_n51_));
  NOR2x1_ASAP7_75t_R  g008(.A(new_n47_), .B(new_n51_), .Y(new_n52_));
  INVx1_ASAP7_75t_R   g009(.A(p5), .Y(new_n53_));
  NAND2x1_ASAP7_75t_R g010(.A(p6), .B(new_n53_), .Y(new_n54_));
  INVx1_ASAP7_75t_R   g011(.A(p9), .Y(new_n55_));
  NAND2x1_ASAP7_75t_R g012(.A(p10), .B(new_n55_), .Y(new_n56_));
  INVx1_ASAP7_75t_R   g013(.A(p7), .Y(new_n57_));
  NAND2x1_ASAP7_75t_R g014(.A(p8), .B(new_n57_), .Y(new_n58_));
  AND3x1_ASAP7_75t_R  g015(.A(new_n54_), .B(new_n56_), .C(new_n58_), .Y(new_n59_));
  INVx1_ASAP7_75t_R   g016(.A(p2), .Y(new_n60_));
  INVx1_ASAP7_75t_R   g017(.A(p35), .Y(new_n61_));
  NAND2x1_ASAP7_75t_R g018(.A(p0), .B(new_n61_), .Y(new_n62_));
  OAI21x1_ASAP7_75t_R g019(.A1(p1), .A2(new_n60_), .B(new_n62_), .Y(new_n63_));
  INVx1_ASAP7_75t_R   g020(.A(new_n63_), .Y(new_n64_));
  NAND3x1_ASAP7_75t_R g021(.A(new_n52_), .B(new_n59_), .C(new_n64_), .Y(o0));
  INVx1_ASAP7_75t_R   g022(.A(p24), .Y(new_n66_));
  NAND2x1_ASAP7_75t_R g023(.A(p14), .B(new_n66_), .Y(new_n67_));
  AOI21x1_ASAP7_75t_R g024(.A1(p13), .A2(o0), .B(new_n67_), .Y(new_n68_));
  INVx1_ASAP7_75t_R   g025(.A(p17), .Y(new_n69_));
  NAND2x1_ASAP7_75t_R g026(.A(p0), .B(new_n69_), .Y(new_n70_));
  AOI21x1_ASAP7_75t_R g027(.A1(p35), .A2(o0), .B(new_n70_), .Y(new_n71_));
  INVx1_ASAP7_75t_R   g028(.A(p16), .Y(new_n72_));
  NOR2x1_ASAP7_75t_R  g029(.A(p25), .B(new_n72_), .Y(new_n73_));
  INVx1_ASAP7_75t_R   g030(.A(new_n73_), .Y(new_n74_));
  AOI21x1_ASAP7_75t_R g031(.A1(p15), .A2(o0), .B(new_n74_), .Y(new_n75_));
  NOR3x1_ASAP7_75t_R  g032(.A(new_n68_), .B(new_n71_), .C(new_n75_), .Y(new_n76_));
  INVx1_ASAP7_75t_R   g033(.A(p8), .Y(new_n77_));
  NOR2x1_ASAP7_75t_R  g034(.A(p21), .B(new_n77_), .Y(new_n78_));
  INVx1_ASAP7_75t_R   g035(.A(new_n78_), .Y(new_n79_));
  AOI21x1_ASAP7_75t_R g036(.A1(p7), .A2(o0), .B(new_n79_), .Y(new_n80_));
  INVx1_ASAP7_75t_R   g037(.A(p10), .Y(new_n81_));
  NOR2x1_ASAP7_75t_R  g038(.A(p22), .B(new_n81_), .Y(new_n82_));
  INVx1_ASAP7_75t_R   g039(.A(new_n82_), .Y(new_n83_));
  AOI21x1_ASAP7_75t_R g040(.A1(p9), .A2(o0), .B(new_n83_), .Y(new_n84_));
  INVx1_ASAP7_75t_R   g041(.A(p6), .Y(new_n85_));
  NOR2x1_ASAP7_75t_R  g042(.A(p20), .B(new_n85_), .Y(new_n86_));
  INVx1_ASAP7_75t_R   g043(.A(new_n86_), .Y(new_n87_));
  AOI21x1_ASAP7_75t_R g044(.A1(p5), .A2(o0), .B(new_n87_), .Y(new_n88_));
  NOR3x1_ASAP7_75t_R  g045(.A(new_n80_), .B(new_n84_), .C(new_n88_), .Y(new_n89_));
  OR2x4_ASAP7_75t_R   g046(.A(p19), .B(new_n44_), .Y(new_n90_));
  AOI21x1_ASAP7_75t_R g047(.A1(p3), .A2(o0), .B(new_n90_), .Y(new_n91_));
  INVx1_ASAP7_75t_R   g048(.A(p23), .Y(new_n92_));
  NAND2x1_ASAP7_75t_R g049(.A(p12), .B(new_n92_), .Y(new_n93_));
  AOI21x1_ASAP7_75t_R g050(.A1(p11), .A2(o0), .B(new_n93_), .Y(new_n94_));
  NOR2x1_ASAP7_75t_R  g051(.A(p18), .B(new_n60_), .Y(new_n95_));
  INVx1_ASAP7_75t_R   g052(.A(new_n95_), .Y(new_n96_));
  AOI21x1_ASAP7_75t_R g053(.A1(p1), .A2(o0), .B(new_n96_), .Y(new_n97_));
  NOR3x1_ASAP7_75t_R  g054(.A(new_n91_), .B(new_n94_), .C(new_n97_), .Y(new_n98_));
  NAND3x1_ASAP7_75t_R g055(.A(new_n76_), .B(new_n89_), .C(new_n98_), .Y(o1));
  NAND3x1_ASAP7_75t_R g056(.A(new_n54_), .B(new_n56_), .C(new_n58_), .Y(new_n100_));
  NAND2x1_ASAP7_75t_R g057(.A(p9), .B(new_n100_), .Y(new_n101_));
  INVx1_ASAP7_75t_R   g058(.A(p12), .Y(new_n102_));
  NOR2x1_ASAP7_75t_R  g059(.A(p11), .B(new_n102_), .Y(new_n103_));
  NOR2x1_ASAP7_75t_R  g060(.A(p3), .B(new_n44_), .Y(new_n104_));
  NOR2x1_ASAP7_75t_R  g061(.A(new_n103_), .B(new_n104_), .Y(new_n105_));
  NOR2x1_ASAP7_75t_R  g062(.A(p13), .B(new_n48_), .Y(new_n106_));
  AOI21x1_ASAP7_75t_R g063(.A1(new_n49_), .A2(p16), .B(new_n106_), .Y(new_n107_));
  NAND2x1_ASAP7_75t_R g064(.A(new_n105_), .B(new_n107_), .Y(new_n108_));
  OAI21x1_ASAP7_75t_R g065(.A1(new_n63_), .A2(new_n108_), .B(p9), .Y(new_n109_));
  NAND2x1_ASAP7_75t_R g066(.A(new_n101_), .B(new_n109_), .Y(new_n110_));
  OR3x1_ASAP7_75t_R   g067(.A(new_n110_), .B(new_n81_), .C(p31), .Y(new_n111_));
  AOI21x1_ASAP7_75t_R g068(.A1(p22), .A2(o1), .B(new_n111_), .Y(new_n112_));
  NAND2x1_ASAP7_75t_R g069(.A(p7), .B(o0), .Y(new_n113_));
  INVx1_ASAP7_75t_R   g070(.A(p30), .Y(new_n114_));
  AND3x1_ASAP7_75t_R  g071(.A(new_n113_), .B(new_n114_), .C(p8), .Y(new_n115_));
  INVx1_ASAP7_75t_R   g072(.A(new_n115_), .Y(new_n116_));
  AOI21x1_ASAP7_75t_R g073(.A1(p21), .A2(o1), .B(new_n116_), .Y(new_n117_));
  NOR3x1_ASAP7_75t_R  g074(.A(new_n108_), .B(new_n100_), .C(new_n63_), .Y(new_n118_));
  NOR2x1_ASAP7_75t_R  g075(.A(new_n53_), .B(new_n118_), .Y(new_n119_));
  OR3x1_ASAP7_75t_R   g076(.A(new_n119_), .B(p29), .C(new_n85_), .Y(new_n120_));
  AOI21x1_ASAP7_75t_R g077(.A1(p20), .A2(o1), .B(new_n120_), .Y(new_n121_));
  NOR3x1_ASAP7_75t_R  g078(.A(new_n112_), .B(new_n117_), .C(new_n121_), .Y(new_n122_));
  AO21x1_ASAP7_75t_R  g079(.A1(p1), .A2(o0), .B(new_n60_), .Y(new_n123_));
  AO21x1_ASAP7_75t_R  g080(.A1(p3), .A2(o0), .B(new_n90_), .Y(new_n124_));
  AO21x1_ASAP7_75t_R  g081(.A1(p11), .A2(o0), .B(new_n93_), .Y(new_n125_));
  INVx1_ASAP7_75t_R   g082(.A(p1), .Y(new_n126_));
  OAI21x1_ASAP7_75t_R g083(.A1(new_n126_), .A2(new_n118_), .B(new_n95_), .Y(new_n127_));
  NAND3x1_ASAP7_75t_R g084(.A(new_n124_), .B(new_n125_), .C(new_n127_), .Y(new_n128_));
  NOR2x1_ASAP7_75t_R  g085(.A(new_n123_), .B(new_n128_), .Y(new_n129_));
  AO21x1_ASAP7_75t_R  g086(.A1(p5), .A2(o0), .B(new_n87_), .Y(new_n130_));
  OAI21x1_ASAP7_75t_R g087(.A1(new_n57_), .A2(new_n118_), .B(new_n78_), .Y(new_n131_));
  NAND3x1_ASAP7_75t_R g088(.A(new_n109_), .B(new_n101_), .C(new_n82_), .Y(new_n132_));
  NAND3x1_ASAP7_75t_R g089(.A(new_n130_), .B(new_n131_), .C(new_n132_), .Y(new_n133_));
  AO21x1_ASAP7_75t_R  g090(.A1(p13), .A2(o0), .B(new_n67_), .Y(new_n134_));
  AO21x1_ASAP7_75t_R  g091(.A1(p35), .A2(o0), .B(new_n70_), .Y(new_n135_));
  OAI21x1_ASAP7_75t_R g092(.A1(new_n49_), .A2(new_n118_), .B(new_n73_), .Y(new_n136_));
  NAND3x1_ASAP7_75t_R g093(.A(new_n134_), .B(new_n135_), .C(new_n136_), .Y(new_n137_));
  NOR2x1_ASAP7_75t_R  g094(.A(new_n133_), .B(new_n137_), .Y(new_n138_));
  AOI21x1_ASAP7_75t_R g095(.A1(new_n129_), .A2(new_n138_), .B(new_n97_), .Y(new_n139_));
  INVx1_ASAP7_75t_R   g096(.A(p25), .Y(new_n140_));
  AO21x1_ASAP7_75t_R  g097(.A1(new_n76_), .A2(new_n89_), .B(new_n140_), .Y(new_n141_));
  NAND2x1_ASAP7_75t_R g098(.A(p25), .B(new_n128_), .Y(new_n142_));
  AO21x1_ASAP7_75t_R  g099(.A1(p15), .A2(o0), .B(new_n72_), .Y(new_n143_));
  NOR2x1_ASAP7_75t_R  g100(.A(p34), .B(new_n143_), .Y(new_n144_));
  NAND3x1_ASAP7_75t_R g101(.A(new_n141_), .B(new_n142_), .C(new_n144_), .Y(new_n145_));
  OAI21x1_ASAP7_75t_R g102(.A1(p27), .A2(new_n139_), .B(new_n145_), .Y(new_n146_));
  OAI21x1_ASAP7_75t_R g103(.A1(new_n61_), .A2(new_n118_), .B(p0), .Y(new_n147_));
  OR2x4_ASAP7_75t_R   g104(.A(p26), .B(new_n147_), .Y(new_n148_));
  NOR2x1_ASAP7_75t_R  g105(.A(new_n45_), .B(new_n118_), .Y(new_n149_));
  OAI21x1_ASAP7_75t_R g106(.A1(new_n93_), .A2(new_n149_), .B(new_n127_), .Y(new_n150_));
  NOR3x1_ASAP7_75t_R  g107(.A(new_n150_), .B(new_n91_), .C(new_n88_), .Y(new_n151_));
  NAND2x1_ASAP7_75t_R g108(.A(new_n134_), .B(new_n135_), .Y(new_n152_));
  NAND3x1_ASAP7_75t_R g109(.A(new_n136_), .B(new_n131_), .C(new_n132_), .Y(new_n153_));
  NOR2x1_ASAP7_75t_R  g110(.A(new_n152_), .B(new_n153_), .Y(new_n154_));
  AOI21x1_ASAP7_75t_R g111(.A1(new_n151_), .A2(new_n154_), .B(new_n69_), .Y(new_n155_));
  OAI21x1_ASAP7_75t_R g112(.A1(new_n133_), .A2(new_n137_), .B(p23), .Y(new_n156_));
  NAND2x1_ASAP7_75t_R g113(.A(p23), .B(new_n128_), .Y(new_n157_));
  AO21x1_ASAP7_75t_R  g114(.A1(p11), .A2(o0), .B(new_n102_), .Y(new_n158_));
  NOR2x1_ASAP7_75t_R  g115(.A(p32), .B(new_n158_), .Y(new_n159_));
  NAND3x1_ASAP7_75t_R g116(.A(new_n156_), .B(new_n157_), .C(new_n159_), .Y(new_n160_));
  OAI21x1_ASAP7_75t_R g117(.A1(new_n148_), .A2(new_n155_), .B(new_n160_), .Y(new_n161_));
  AO21x1_ASAP7_75t_R  g118(.A1(p13), .A2(o0), .B(new_n48_), .Y(new_n162_));
  OR2x4_ASAP7_75t_R   g119(.A(p33), .B(new_n162_), .Y(new_n163_));
  AOI21x1_ASAP7_75t_R g120(.A1(new_n151_), .A2(new_n154_), .B(new_n66_), .Y(new_n164_));
  OAI21x1_ASAP7_75t_R g121(.A1(new_n133_), .A2(new_n137_), .B(new_n124_), .Y(new_n165_));
  AO21x1_ASAP7_75t_R  g122(.A1(new_n127_), .A2(new_n125_), .B(new_n91_), .Y(new_n166_));
  AO21x1_ASAP7_75t_R  g123(.A1(p3), .A2(o0), .B(new_n44_), .Y(new_n167_));
  NOR2x1_ASAP7_75t_R  g124(.A(p28), .B(new_n167_), .Y(new_n168_));
  NAND3x1_ASAP7_75t_R g125(.A(new_n165_), .B(new_n166_), .C(new_n168_), .Y(new_n169_));
  OAI21x1_ASAP7_75t_R g126(.A1(new_n163_), .A2(new_n164_), .B(new_n169_), .Y(new_n170_));
  NOR3x1_ASAP7_75t_R  g127(.A(new_n146_), .B(new_n161_), .C(new_n170_), .Y(new_n171_));
  NAND2x1_ASAP7_75t_R g128(.A(new_n122_), .B(new_n171_), .Y(o2));
  AOI21x1_ASAP7_75t_R g129(.A1(p17), .A2(o1), .B(new_n148_), .Y(new_n173_));
  AOI21x1_ASAP7_75t_R g130(.A1(new_n76_), .A2(new_n89_), .B(new_n140_), .Y(new_n174_));
  NOR2x1_ASAP7_75t_R  g131(.A(new_n140_), .B(new_n98_), .Y(new_n175_));
  INVx1_ASAP7_75t_R   g132(.A(new_n144_), .Y(new_n176_));
  NOR3x1_ASAP7_75t_R  g133(.A(new_n174_), .B(new_n175_), .C(new_n176_), .Y(new_n177_));
  AOI21x1_ASAP7_75t_R g134(.A1(new_n76_), .A2(new_n89_), .B(new_n91_), .Y(new_n178_));
  INVx1_ASAP7_75t_R   g135(.A(new_n166_), .Y(new_n179_));
  INVx1_ASAP7_75t_R   g136(.A(new_n168_), .Y(new_n180_));
  NOR3x1_ASAP7_75t_R  g137(.A(new_n178_), .B(new_n179_), .C(new_n180_), .Y(new_n181_));
  NOR3x1_ASAP7_75t_R  g138(.A(new_n173_), .B(new_n177_), .C(new_n181_), .Y(new_n182_));
  NOR2x1_ASAP7_75t_R  g139(.A(p27), .B(new_n139_), .Y(new_n183_));
  AOI21x1_ASAP7_75t_R g140(.A1(new_n76_), .A2(new_n89_), .B(new_n92_), .Y(new_n184_));
  NOR2x1_ASAP7_75t_R  g141(.A(new_n92_), .B(new_n98_), .Y(new_n185_));
  INVx1_ASAP7_75t_R   g142(.A(new_n159_), .Y(new_n186_));
  NOR3x1_ASAP7_75t_R  g143(.A(new_n184_), .B(new_n185_), .C(new_n186_), .Y(new_n187_));
  AOI21x1_ASAP7_75t_R g144(.A1(p24), .A2(o1), .B(new_n163_), .Y(new_n188_));
  NOR3x1_ASAP7_75t_R  g145(.A(new_n183_), .B(new_n187_), .C(new_n188_), .Y(new_n189_));
  AOI21x1_ASAP7_75t_R g146(.A1(new_n182_), .A2(new_n189_), .B(new_n114_), .Y(new_n190_));
  NOR2x1_ASAP7_75t_R  g147(.A(new_n112_), .B(new_n121_), .Y(new_n191_));
  NAND2x1_ASAP7_75t_R g148(.A(p21), .B(o1), .Y(new_n192_));
  AND3x1_ASAP7_75t_R  g149(.A(new_n192_), .B(p8), .C(new_n113_), .Y(new_n193_));
  OAI21x1_ASAP7_75t_R g150(.A1(new_n114_), .A2(new_n191_), .B(new_n193_), .Y(new_n194_));
  NAND2x1_ASAP7_75t_R g151(.A(p22), .B(o1), .Y(new_n195_));
  INVx1_ASAP7_75t_R   g152(.A(new_n110_), .Y(new_n196_));
  NAND3x1_ASAP7_75t_R g153(.A(new_n195_), .B(p10), .C(new_n196_), .Y(new_n197_));
  INVx1_ASAP7_75t_R   g154(.A(p20), .Y(new_n198_));
  AOI21x1_ASAP7_75t_R g155(.A1(new_n151_), .A2(new_n154_), .B(new_n198_), .Y(new_n199_));
  INVx1_ASAP7_75t_R   g156(.A(p21), .Y(new_n200_));
  AND3x1_ASAP7_75t_R  g157(.A(new_n76_), .B(new_n89_), .C(new_n98_), .Y(new_n201_));
  OAI21x1_ASAP7_75t_R g158(.A1(new_n200_), .A2(new_n201_), .B(new_n115_), .Y(new_n202_));
  OAI21x1_ASAP7_75t_R g159(.A1(new_n199_), .A2(new_n120_), .B(new_n202_), .Y(new_n203_));
  NOR2x1_ASAP7_75t_R  g160(.A(new_n197_), .B(new_n203_), .Y(new_n204_));
  AOI21x1_ASAP7_75t_R g161(.A1(new_n204_), .A2(new_n171_), .B(new_n112_), .Y(new_n205_));
  OAI21x1_ASAP7_75t_R g162(.A1(new_n190_), .A2(new_n194_), .B(new_n205_), .Y(new_n206_));
  OR3x1_ASAP7_75t_R   g163(.A(new_n112_), .B(new_n117_), .C(new_n121_), .Y(new_n207_));
  AO21x1_ASAP7_75t_R  g164(.A1(p24), .A2(o1), .B(new_n162_), .Y(new_n208_));
  AO21x1_ASAP7_75t_R  g165(.A1(p33), .A2(new_n207_), .B(new_n208_), .Y(new_n209_));
  INVx1_ASAP7_75t_R   g166(.A(p33), .Y(new_n210_));
  NOR2x1_ASAP7_75t_R  g167(.A(new_n210_), .B(new_n171_), .Y(new_n211_));
  OR3x1_ASAP7_75t_R   g168(.A(new_n184_), .B(new_n185_), .C(new_n158_), .Y(new_n212_));
  NOR3x1_ASAP7_75t_R  g169(.A(new_n203_), .B(new_n112_), .C(new_n212_), .Y(new_n213_));
  AOI21x1_ASAP7_75t_R g170(.A1(new_n171_), .A2(new_n213_), .B(new_n187_), .Y(new_n214_));
  OAI21x1_ASAP7_75t_R g171(.A1(new_n209_), .A2(new_n211_), .B(new_n214_), .Y(new_n215_));
  NOR2x1_ASAP7_75t_R  g172(.A(new_n206_), .B(new_n215_), .Y(new_n216_));
  INVx1_ASAP7_75t_R   g173(.A(p28), .Y(new_n217_));
  AOI21x1_ASAP7_75t_R g174(.A1(new_n182_), .A2(new_n189_), .B(new_n217_), .Y(new_n218_));
  AOI21x1_ASAP7_75t_R g175(.A1(p19), .A2(o1), .B(new_n167_), .Y(new_n219_));
  OAI21x1_ASAP7_75t_R g176(.A1(new_n217_), .A2(new_n122_), .B(new_n219_), .Y(new_n220_));
  INVx1_ASAP7_75t_R   g177(.A(p29), .Y(new_n221_));
  OR3x1_ASAP7_75t_R   g178(.A(new_n199_), .B(new_n85_), .C(new_n119_), .Y(new_n222_));
  AO21x1_ASAP7_75t_R  g179(.A1(p22), .A2(o1), .B(new_n111_), .Y(new_n223_));
  AOI21x1_ASAP7_75t_R g180(.A1(new_n202_), .A2(new_n223_), .B(new_n221_), .Y(new_n224_));
  NOR2x1_ASAP7_75t_R  g181(.A(new_n222_), .B(new_n224_), .Y(new_n225_));
  OAI21x1_ASAP7_75t_R g182(.A1(new_n221_), .A2(new_n171_), .B(new_n225_), .Y(new_n226_));
  OAI21x1_ASAP7_75t_R g183(.A1(new_n218_), .A2(new_n220_), .B(new_n226_), .Y(new_n227_));
  AO21x1_ASAP7_75t_R  g184(.A1(p17), .A2(o1), .B(new_n147_), .Y(new_n228_));
  AO21x1_ASAP7_75t_R  g185(.A1(p26), .A2(new_n207_), .B(new_n228_), .Y(new_n229_));
  INVx1_ASAP7_75t_R   g186(.A(p26), .Y(new_n230_));
  NOR2x1_ASAP7_75t_R  g187(.A(new_n230_), .B(new_n171_), .Y(new_n231_));
  NOR3x1_ASAP7_75t_R  g188(.A(new_n203_), .B(new_n112_), .C(new_n139_), .Y(new_n232_));
  AOI21x1_ASAP7_75t_R g189(.A1(new_n171_), .A2(new_n232_), .B(new_n183_), .Y(new_n233_));
  OAI21x1_ASAP7_75t_R g190(.A1(new_n229_), .A2(new_n231_), .B(new_n233_), .Y(new_n234_));
  NOR2x1_ASAP7_75t_R  g191(.A(new_n227_), .B(new_n234_), .Y(new_n235_));
  OR3x1_ASAP7_75t_R   g192(.A(new_n174_), .B(new_n175_), .C(new_n143_), .Y(new_n236_));
  AOI21x1_ASAP7_75t_R g193(.A1(p34), .A2(o2), .B(new_n236_), .Y(new_n237_));
  AOI21x1_ASAP7_75t_R g194(.A1(new_n216_), .A2(new_n235_), .B(new_n237_), .Y(o3));
  INVx1_ASAP7_75t_R   g195(.A(new_n216_), .Y(o4));
  INVx1_ASAP7_75t_R   g196(.A(p27), .Y(new_n240_));
  NAND2x1_ASAP7_75t_R g197(.A(new_n76_), .B(new_n89_), .Y(new_n241_));
  OR3x1_ASAP7_75t_R   g198(.A(new_n150_), .B(new_n91_), .C(new_n123_), .Y(new_n242_));
  OAI21x1_ASAP7_75t_R g199(.A1(new_n241_), .A2(new_n242_), .B(new_n127_), .Y(new_n243_));
  AOI21x1_ASAP7_75t_R g200(.A1(new_n240_), .A2(new_n243_), .B(new_n173_), .Y(new_n244_));
  NOR2x1_ASAP7_75t_R  g201(.A(new_n177_), .B(new_n188_), .Y(new_n245_));
  NOR2x1_ASAP7_75t_R  g202(.A(new_n187_), .B(new_n181_), .Y(new_n246_));
  NAND3x1_ASAP7_75t_R g203(.A(new_n244_), .B(new_n245_), .C(new_n246_), .Y(new_n247_));
  INVx1_ASAP7_75t_R   g204(.A(p31), .Y(new_n248_));
  NOR2x1_ASAP7_75t_R  g205(.A(new_n117_), .B(new_n121_), .Y(new_n249_));
  AND3x1_ASAP7_75t_R  g206(.A(new_n195_), .B(p10), .C(new_n196_), .Y(new_n250_));
  OAI21x1_ASAP7_75t_R g207(.A1(new_n248_), .A2(new_n249_), .B(new_n250_), .Y(new_n251_));
  AOI21x1_ASAP7_75t_R g208(.A1(p31), .A2(new_n247_), .B(new_n251_), .Y(new_n252_));
  AOI21x1_ASAP7_75t_R g209(.A1(p30), .A2(new_n247_), .B(new_n194_), .Y(new_n253_));
  NOR2x1_ASAP7_75t_R  g210(.A(new_n252_), .B(new_n253_), .Y(new_n254_));
  INVx1_ASAP7_75t_R   g211(.A(new_n212_), .Y(new_n255_));
  NAND3x1_ASAP7_75t_R g212(.A(new_n191_), .B(new_n255_), .C(new_n202_), .Y(new_n256_));
  OAI21x1_ASAP7_75t_R g213(.A1(new_n256_), .A2(new_n247_), .B(new_n160_), .Y(new_n257_));
  NOR2x1_ASAP7_75t_R  g214(.A(new_n257_), .B(new_n226_), .Y(new_n258_));
  NAND2x1_ASAP7_75t_R g215(.A(new_n254_), .B(new_n258_), .Y(new_n259_));
  AOI21x1_ASAP7_75t_R g216(.A1(p28), .A2(new_n247_), .B(new_n220_), .Y(new_n260_));
  AOI21x1_ASAP7_75t_R g217(.A1(new_n260_), .A2(new_n254_), .B(new_n215_), .Y(new_n261_));
  NAND2x1_ASAP7_75t_R g218(.A(new_n259_), .B(new_n261_), .Y(o5));
  OA21x2_ASAP7_75t_R  g219(.A1(new_n233_), .A2(new_n260_), .B(new_n205_), .Y(new_n263_));
  NOR2x1_ASAP7_75t_R  g220(.A(new_n209_), .B(new_n211_), .Y(new_n264_));
  AOI21x1_ASAP7_75t_R g221(.A1(new_n254_), .A2(new_n258_), .B(new_n264_), .Y(new_n265_));
  OAI21x1_ASAP7_75t_R g222(.A1(new_n257_), .A2(new_n263_), .B(new_n265_), .Y(o6));
endmodule


