#!/usr/bin/env python3
"""Audit paired cold/warm campaigns, then export tables without pooling their times."""
import argparse,csv,hashlib,json,re,statistics,subprocess,sys
from pathlib import Path
import report,export_paper
from run_three_parts import DESIGNS,ARMS
SCRIPT=Path(__file__).resolve().parent

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def rows(p):
    with p.open() as f:return list(csv.DictReader(f,delimiter='\t'))
def mean(v):return statistics.mean(v)
def pct(a,b):return 100*(float(a)/float(b)-1)
def time_of(root,stage,arm,d):return report.read_counters(str(root/stage/f'{arm}.{d}'/'log'))['time_optimizer']
def pair(a,b):return f'{a:.1f}/{b:.1f}'
def fmt(v):return '0.00' if round(v,2)==0 else f'{v:+.2f}'
def table(caption,label,head,body,align,group=None):
    return '\n'.join([r'\begin{table}[t]',r'\centering\scriptsize',r'\setlength{\tabcolsep}{1.5pt}',r'\caption{'+caption+'}'+r'\label{'+label+'}',r'\begin{tabular}{@{}'+align+r'@{}}',r'\toprule',*(group or []),' & '.join(head)+r' \\',r'\midrule',*[line[0] if len(line)==1 else ' & '.join(map(str,line))+r' \\' for line in body],r'\bottomrule',r'\end{tabular}',r'\end{table}'])
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--root',type=Path,required=True);ap.add_argument('--out',type=Path);args=ap.parse_args();root=args.root.resolve();cohorts={m:root/m for m in ['cold','warm']}
    certificates={};metrics={};data={};cache_records=[]
    for mode,folder in cohorts.items():
        with (root/f'{mode}_audit.log').open('w') as f:
            subprocess.run([sys.executable,str(SCRIPT/'report_three_parts.py'),'--root',str(folder)],check=True,stdout=f,stderr=subprocess.STDOUT)
        cert=json.loads((folder/'verified_metrics.json').read_text());certificates[mode]=sha(folder/'verified_metrics.json');metrics[mode]=cert['metrics']
        manifest=json.loads((folder/'manifest.json').read_text());assert manifest['profile_cache_mode']==mode and manifest['goal']['MAP_EGG_PROFILE']=='1'
        data[mode]={stage:{(r['stage'],r['design']):r for r in rows(folder/stage/'summary.tsv')} for stage in ['tab_mfs3','tab_main','ablation']}
        for stage,rr in data[mode].items():
            for (arm,d),r in rr.items():
                if arm=='base':continue
                wd=folder/stage/f'{arm}.{d}';flags=(wd/'experiment_env.txt').read_text().splitlines();assert 'MAP_EGG_PROFILE=1' in flags
                trace=json.loads((wd/'cache_provenance.json').read_text());assert trace['mode']==mode
                p=re.search(r'egraph_profile (.*)',(wd/'log').read_text());assert p
                stats={k:int(v) for k,v in (item.split('=') for item in p[1].split())}
                assert stats['corrupt']==stats['write_failures']==0,(mode,stage,arm,d,stats)
                expected=Path(manifest['cache_root'])/stage/f'{arm}.{d}'
                assert Path(trace['cache_directory'])==expected
                for name,h in trace['cache_record_sha256'].items():
                    assert sha(expected/name)==h, f'changed cached pool: {mode}/{stage}/{arm}.{d}/{name}'
                # A cold process can reload records it created itself after memory eviction.
                # Empty-at-start is enforced by the archived runner, not by zero disk reads.
                cache_records.append(dict(mode=mode,stage=stage,arm=arm,design=d,optimizer_seconds=time_of(folder,stage,arm,d),**stats))
    matches=[]
    for stage,rr in data['cold'].items():
        assert rr.keys()==data['warm'][stage].keys()
        for (arm,d),r in rr.items():
            if arm=='base':continue
            c=cohorts['cold']/stage/f'{arm}.{d}';w=cohorts['warm']/stage/f'{arm}.{d}';assert (c/'epmapping_baseline.v').read_bytes()==(w/'epmapping_baseline.v').read_bytes()
            other=data['warm'][stage][arm,d];matches.append(dict(stage=stage,arm=arm,design=d,ppa_equal=all(r[k]==other[k] for k in ['out_a','out_d']),netlist_equal=(c/'epmapping_mapped.v').read_bytes()==(w/'epmapping_mapped.v').read_bytes()))
    # The common baseline is a freshly executed ABC batch, reused by the warm cohort.
    assert json.loads((cohorts['cold']/'tab_mfs3/abc_results.json').read_text())==json.loads((cohorts['warm']/'tab_mfs3/abc_results.json').read_text())
    raw={str(p.relative_to(root)):sha(p) for m in cohorts for p in (cohorts[m]).rglob('cache_provenance.json')}
    raw['execution_plan.json']=sha(root/'execution_plan.json')
    report_data=dict(raw_sha256=raw,cohort_metrics=metrics,cohort_certificate_sha256=certificates,cache_runs=cache_records,matches=matches,all_ppa_equal=all(r['ppa_equal'] for r in matches),all_netlists_equal=all(r['netlist_equal'] for r in matches))
    (root/'verified_profiles.json').write_text(json.dumps(report_data,indent=2)+'\n')
    # Complete per-design costs for both cohorts, including any trajectory difference.
    allrows=[]
    for mode in cohorts:
        for stage,rr in data[mode].items():
            for (arm,d),r in rr.items():
                if arm!='base':allrows.append(dict(mode=mode,part=stage,arm=arm,design=d,initial_area=r['base_a'],initial_delay=r['base_d'],area=r['out_a'],delay=r['out_d'],optimizer_seconds=time_of(cohorts[mode],stage,arm,d),cec=r['cec']))
    with (root/'paired_results.tsv').open('w') as f:
        writer=csv.DictWriter(f,fieldnames=list(allrows[0]),delimiter='\t');writer.writeheader();writer.writerows(allrows)
    if not report_data['all_ppa_equal']:
        raise RuntimeError('Cold/warm QoR differs: complete audited paired results saved; tables must explicitly show both costs')
    generated=(cohorts['cold']/'generated_results.tex').read_text();generated=generated[:generated.index('\\newcommand{\\MainResultTable}')]
    generated='% GENERATED from paired CEC/PPA/cache audits.\n'+generated
    cold,warm=metrics['cold'],metrics['warm'];times={m:{part:sum(r['optimizer_seconds'] for r in cache_records if r['mode']==m and r['stage']==part and r['arm'] in ('ae','ours','full')) for part in ['tab_mfs3','tab_main','ablation']} for m in cohorts}
    macros={
        'ColdMainSeconds':f"{times['cold']['tab_main']:.1f}",'WarmMainSeconds':f"{times['warm']['tab_main']:.1f}",
        'ColdMfsSeconds':f"{times['cold']['tab_mfs3']:.1f}",'WarmMfsSeconds':f"{times['warm']['tab_mfs3']:.1f}",
        'WarmTimeEggShare':f"{100*warm['cut_oracle_times']['secs_egg']/sum(warm['cut_oracle_times'].values()):.1f}",
        'WarmTimeSynShare':f"{100*warm['cut_oracle_times']['secs_synth']/sum(warm['cut_oracle_times'].values()):.1f}",
        'ColdNoEggRatio':f"{cold['ablation']['noEGG']['time_ratio']:.2f}",'WarmNoEggRatio':f"{warm['ablation']['noEGG']['time_ratio']:.2f}",
        'SynWorseCount':cold['ablation']['noSYN']['worse'],'EggWorseCount':cold['ablation']['noEGG']['worse'],'DBBetterCount':cold['ablation']['noDB']['better']}
    generated+='\n'.join(f'\\newcommand{{\\{k}}}{{{v}}}' for k,v in macros.items())+'\n'
    reference=report.read_paper_table(str(cohorts['cold']/'inputs/compare_with_aspdac25.sh'))
    ref={d:(reference[d][0]*(1+reference[d][2]/100),reference[d][3]*(1+reference[d][5]/100)) for d in DESIGNS}
    mainbody=[]
    for d in DESIGNS:
        r=data['cold']['tab_main']['ae',d];mainbody.append([d.replace('_',r'\_'),*[f'{x:.2f}' for x in ref[d]],*[f'{float(r[k]):.2f}' for k in ['base_a','base_d','out_a','out_d']],pair(*[time_of(cohorts[m],'tab_main','ae',d) for m in cohorts])])
    ratio=[mean(float(data['cold']['tab_main']['ae',d][key])/ref[d][i] for d in DESIGNS) for key,i in [('base_a',0),('base_d',1),('out_a',0),('out_d',1)]]
    mainbody+=[[r'\midrule'],['Ave. Ratio','1.0000','1.0000',*[f'{v:.4f}' for v in ratio],'--']]
    main=table(r"Fully preprocessed mappings and six-round-cap results. ASPDAC'25 gives reported final costs; starts differ. Area: $\mu m^2$; delay: ps. $t_c/t_w$ are cold/warm optimizer seconds, including cache construction or loading and excluding preprocessing, mapping and CEC. Both cohorts produce the same costs. Ave. Ratio averages ratios to ASPDAC'25 over all 16 designs.",'tab:main',['','Area','Delay','$A_e$','$D_e$','Area','Delay','$t_c/t_w$'],mainbody,'lrrrrrrr',[r'Circuit & \multicolumn{2}{c}{ASPDAC\textquotesingle25} & \multicolumn{2}{c}{Initial} & \multicolumn{2}{c}{Ours} & Time (s) \\',r'\cmidrule(lr){2-3}\cmidrule(lr){4-5}\cmidrule(lr){6-7}'])
    ablbody=[]
    for arm in ARMS:
        v=cold['ablation'][arm];other=warm['ablation'][arm]
        ablbody.append([arm,f"{v['own_area']:+.2f}",f"{v['own_delay']:+.2f}",f"{v['area']:+.2f}",v['worse'],v['better'],f"{v['time_ratio']:.2f}/{other['time_ratio']:.2f}"])
    abl=table(r'Ablations on sixteen identical $N_e$ starts. $\Delta A$ sums differences from full; W/B count worse/better areas. Each time ratio uses total optimizer seconds divided by the corresponding full cohort; entries are cold/warm. Both cohorts produce the same costs.','tab:ablation',['Arm','$\delta A$ (\%)','$\delta D$ (\%)','$\Delta A$','W','B','Time/full'],ablbody,'lrrrrrr')
    abc={r['design']:r for r in json.loads((cohorts['cold']/'tab_mfs3/abc_results.json').read_text())};paired=[d for d in DESIGNS if abc[d]['rc']==0];mfsbody=[]
    for d in DESIGNS:
        r=data['cold']['tab_mfs3']['ours',d];b=abc[d]
        abcval=['TO','TO','1000']
        if b['rc']==0:abcval=[fmt(pct(b['area'],b['baseline']['area'])),fmt(pct(b['delay'],b['baseline']['delay']))+(r'$^{\dagger}$' if b['delay']>b['baseline']['delay']+.001 else ''),f"{b['secs']:.1f}"]
        mfsbody.append([d.replace('_',r'\_'),f"{float(r['base_a']):.2f}",f"{float(r['base_d']):.2f}",*abcval,fmt(pct(r['out_a'],r['base_a'])),fmt(pct(r['out_d'],r['base_d'])),pair(*[time_of(cohorts[m],'tab_mfs3','ours',d) for m in cohorts])])
    abcrat=[mean(abc[d][k]/abc[d]['baseline'][k] for d in paired) for k in ['area','delay']]
    ownrat=[mean(float(data['cold']['tab_mfs3']['ours',d][f'out_{k}'])/float(data['cold']['tab_mfs3']['ours',d][f'base_{k}']) for d in paired) for k in ['a','d']]
    mfsbody+=[[r'\midrule'],['Ave. Ratio','1.0000','1.0000',*[f'{v:.4f}' for v in abcrat],f"{mean(abc[d]['secs'] for d in paired):.1f}",*[f'{v:.4f}' for v in ownrat],pair(*[mean(time_of(cohorts[m],'tab_mfs3','ours',d) for d in paired) for m in cohorts])]]
    mfs=table(r'One-pass comparison on identical inputs and the same six-input library. $A_0$ ($\mu m^2$), $D_0$ (ps): common pre-import mapping; changes (\%) use native starts. $t$ excludes CEC; ours gives cold/warm seconds with identical costs. TO: 1000\,s limit; $\dagger$: delay violation. Ave. Ratio averages output/input ratios on the common '+str(len(paired))+r' completed designs; time entries give mean seconds.','tab:mfs3',['','$A_0$','$D_0$','$\delta A$','$\delta D$','$t$','$\delta A$','$\delta D$','$t_c/t_w$'],mfsbody,'lrrrrrrrr',[r'Circuit & \multicolumn{2}{c}{Initial} & \multicolumn{3}{c}{ABC mfs3} & \multicolumn{3}{c}{Ours} \\',r'\cmidrule(lr){2-3}\cmidrule(lr){4-6}\cmidrule(lr){7-9}'])
    for name,t in [('MainResultTable',main),('AblationResultTable',abl)]:generated+=f'\\newcommand{{\\{name}}}{{%\n{t}\n}}\n'
    (root/'generated_profiles.tex').write_text(generated)
    mfs_text='% GENERATED from paired CEC/PPA/cache audits.\n'+f'\\newcommand{{\\MfsComparisonTable}}{{%\n{mfs}\n}}\n'
    (root/'generated_mfs_profiles.tex').write_text(mfs_text)
    if args.out:
        args.out.write_text(generated)
        args.out.with_name('generated_mfs.tex').write_text(mfs_text)
    print(json.dumps(dict(metrics=metrics,totals=times,all_ppa_equal=report_data['all_ppa_equal'],all_netlists_equal=report_data['all_netlists_equal']),indent=2))
if __name__=='__main__':main()
