# Three-part constrained-area experiments

Every ePMapping output satisfies its own initial area/delay bounds and passes CEC.
ABC raw area-mode outputs are preserved. The guarded comparison reverts an infeasible completed output to its native initial mapping; it is an external output-selection policy, not an internal mfs3 timing constraint. Timeouts are excluded from paired means.

{
  "whole_window_synthesis": false,
  "engine_cec_outputs": 160,
  "baseline_cec_outputs": 16,
  "main_own_area": -4.591114286506752,
  "main_own_delay": -6.403613037468098,
  "main_one_area": -3.0110933154467467,
  "main_one_delay": -4.492009122045409,
  "main_other_area": -0.9037868653241447,
  "main_other_delay": -1.906680474086407,
  "main_area_wins": 15,
  "reference_area": -6.7152393843153755,
  "reference_delay": -5.849966243920819,
  "reference_wins": 14,
  "mfs_ours_area": -5.040276040098358,
  "mfs_ours_delay": -5.058388161376079,
  "abc_completed": 13,
  "abc_timeouts": 3,
  "abc_feasible": 6,
  "abc_delay_violations": 7,
  "cut_oracle_times": {
    "secs_stage1": 280.35125458699997,
    "secs_stage2": 108.34332139599998,
    "secs_synth": 789.6658601629997,
    "secs_egg": 2110.738062505,
    "secs_care": 61.704021491,
    "secs_window": 0.0,
    "secs_chain": 0.298276506
  },
  "abc_raw_area": -3.575691302200082,
  "abc_guarded_area": -1.5940348664441888,
  "paired_ours_area": -5.0072051936994075,
  "abc_raw_delay": 11.018744353868293,
  "abc_guarded_delay": -0.14558063949823968,
  "paired_ours_delay": -6.139349029132858,
  "paired_area_wins": 4,
  "guarded_paired_area_wins": 9,
  "ablation": {
    "full": {
      "area": 0.0,
      "worse": 0,
      "better": 0,
      "own_area": -4.591114286506752,
      "own_delay": -6.403613037468098,
      "optimizer_seconds": 3486.6996753640005,
      "time_ratio": 1.0
    },
    "noSYN": {
      "area": 116.77000000000007,
      "worse": 14,
      "better": 0,
      "own_area": -3.8301404289437104,
      "own_delay": -5.477683576362751,
      "optimizer_seconds": 2321.661563435,
      "time_ratio": 0.6658622134390241
    },
    "noEGG": {
      "area": 1.470000000000347,
      "worse": 10,
      "better": 0,
      "own_area": -4.582147323605786,
      "own_delay": -6.357121810072237,
      "optimizer_seconds": 1273.544872619,
      "time_ratio": 0.3652579777998935
    },
    "noDB": {
      "area": 0.5799999999999201,
      "worse": 6,
      "better": 2,
      "own_area": -4.585512813190183,
      "own_delay": -6.31816523147761,
      "optimizer_seconds": 2942.8061756700004,
      "time_ratio": 0.8440090772552071
    },
    "noCARE": {
      "area": 11.379999999999761,
      "worse": 13,
      "better": 0,
      "own_area": -4.50189406003191,
      "own_delay": -6.143600396951674,
      "optimizer_seconds": 3129.329084878,
      "time_ratio": 0.8975046250725072
    },
    "noCHAIN": {
      "area": 334.08000000000004,
      "worse": 1,
      "better": 0,
      "own_area": -0.8473001862413856,
      "own_delay": -1.7875129444560067,
      "optimizer_seconds": 3426.302526441,
      "time_ratio": 0.9826778459441892
    },
    "noSHARE": {
      "area": 334.08000000000004,
      "worse": 1,
      "better": 0,
      "own_area": -0.8473001862413856,
      "own_delay": -1.7875129444560067,
      "optimizer_seconds": 3479.8366511020004,
      "time_ratio": 0.9980316560355077
    }
  },
  "chain_activity": {
    "aes_core": {
      "chain_wins": 0,
      "secs_chain": 0.0
    },
    "arbiter": {
      "chain_wins": 384,
      "secs_chain": 0.057059503
    },
    "div": {
      "chain_wins": 0,
      "secs_chain": 0.0
    },
    "ethernet": {
      "chain_wins": 0,
      "secs_chain": 0.0
    },
    "iwls05_i2c": {
      "chain_wins": 0,
      "secs_chain": 0.0
    },
    "mem_ctrl": {
      "chain_wins": 0,
      "secs_chain": 0.224758279
    },
    "RISC": {
      "chain_wins": 0,
      "secs_chain": 0.0
    },
    "sasc": {
      "chain_wins": 0,
      "secs_chain": 0.0
    },
    "simple_spi": {
      "chain_wins": 0,
      "secs_chain": 0.0
    },
    "spi": {
      "chain_wins": 0,
      "secs_chain": 0.0
    },
    "sqrt": {
      "chain_wins": 0,
      "secs_chain": 0.0
    },
    "systemcaes": {
      "chain_wins": 0,
      "secs_chain": 0.0
    },
    "systemcdes": {
      "chain_wins": 0,
      "secs_chain": 0.0
    },
    "tv80": {
      "chain_wins": 0,
      "secs_chain": 0.0
    },
    "usb_funct": {
      "chain_wins": 0,
      "secs_chain": 0.0
    },
    "usb_phy": {
      "chain_wins": 0,
      "secs_chain": 0.0
    }
  }
}

## Per-design fully preprocessed results

| Design | A0 | D0 | A | D | dA % | dD % |
| --- | --- | --- | --- | --- | --- | --- |
| aes_core | 1029.98 | 410.72 | 1010.4 | 410.72 | -1.90 | +0.00 |
| arbiter | 557.72 | 999.87 | 223.64 | 261.39 | -59.90 | -73.86 |
| div | 1184.5 | 53105.06 | 1183.29 | 53065.1 | -0.10 | -0.08 |
| ethernet | 2541.41 | 543.88 | 2539.28 | 540.76 | -0.08 | -0.57 |
| iwls05_i2c | 47.66 | 303.61 | 47.45 | 303.61 | -0.44 | +0.00 |
| mem_ctrl | 1895.4 | 1519.75 | 1879.51 | 1488.38 | -0.84 | -2.06 |
| RISC | 2927.19 | 1453.77 | 2917.81 | 1428.82 | -0.32 | -1.72 |
| sasc | 27.28 | 191.2 | 27.17 | 191.2 | -0.40 | +0.00 |
| simple_spi | 36.96 | 308.22 | 36.79 | 291.82 | -0.46 | -5.32 |
| spi | 149.43 | 500.98 | 149.3 | 480.72 | -0.09 | -4.04 |
| sqrt | 1157.38 | 88015.07 | 1094.87 | 81526.22 | -5.40 | -7.37 |
| systemcaes | 483.75 | 709.03 | 474.07 | 682.83 | -2.00 | -3.70 |
| systemcdes | 131.06 | 488.85 | 130.64 | 487.83 | -0.32 | -0.21 |
| tv80 | 340.61 | 846.12 | 338.86 | 846.12 | -0.51 | +0.00 |
| usb_funct | 646.23 | 668.08 | 641.81 | 663.36 | -0.68 | -0.71 |
| usb_phy | 22.54 | 163.29 | 22.54 | 158.68 | +0.00 | -2.82 |
