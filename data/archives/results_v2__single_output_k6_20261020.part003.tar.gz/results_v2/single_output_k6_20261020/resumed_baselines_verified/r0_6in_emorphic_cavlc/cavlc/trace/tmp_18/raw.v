// Benchmark "/tmp/" written by ABC on Tue Oct 20 17:20:35 2026

module \/tmp/  ( 
    p5, p4, p8, p3, p6, p9, p2, p1, p0, p7,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10  );
  input  p5, p4, p8, p3, p6, p9, p2, p1, p0, p7;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10;
  wire new_n22_, new_n23_, new_n24_, new_n25_, new_n26_, new_n27_, new_n28_,
    new_n29_, new_n30_, new_n31_, new_n32_, new_n33_, new_n34_, new_n35_,
    new_n36_, new_n37_, new_n38_, new_n39_, new_n40_, new_n41_, new_n42_,
    new_n43_, new_n44_, new_n45_, new_n46_, new_n47_, new_n48_, new_n49_,
    new_n50_, new_n51_, new_n52_, new_n53_, new_n54_, new_n55_, new_n56_,
    new_n57_, new_n58_, new_n59_, new_n60_, new_n61_, new_n62_, new_n63_,
    new_n64_, new_n65_, new_n66_, new_n67_, new_n68_, new_n69_, new_n70_,
    new_n71_, new_n72_, new_n73_, new_n74_, new_n75_, new_n76_, new_n77_,
    new_n78_, new_n79_, new_n80_, new_n81_, new_n82_, new_n83_, new_n84_,
    new_n85_, new_n86_, new_n87_, new_n88_, new_n89_, new_n90_, new_n91_,
    new_n92_, new_n93_, new_n94_, new_n95_, new_n96_, new_n97_, new_n98_,
    new_n99_, new_n100_, new_n101_, new_n102_, new_n103_, new_n104_,
    new_n105_, new_n106_, new_n107_, new_n108_, new_n109_, new_n110_,
    new_n111_, new_n112_, new_n113_, new_n114_, new_n115_, new_n116_,
    new_n117_, new_n118_, new_n119_, new_n120_, new_n122_, new_n123_,
    new_n124_, new_n125_, new_n126_, new_n127_, new_n128_, new_n129_,
    new_n130_, new_n131_, new_n132_, new_n133_, new_n134_, new_n135_,
    new_n136_, new_n137_, new_n138_, new_n139_, new_n140_, new_n141_,
    new_n142_, new_n143_, new_n144_, new_n145_, new_n146_, new_n147_,
    new_n148_, new_n149_, new_n150_, new_n151_, new_n152_, new_n153_,
    new_n154_, new_n155_, new_n156_, new_n157_, new_n158_, new_n159_,
    new_n160_, new_n161_, new_n162_, new_n163_, new_n164_, new_n165_,
    new_n166_, new_n167_, new_n168_, new_n169_, new_n170_, new_n171_,
    new_n172_, new_n173_, new_n174_, new_n175_, new_n176_, new_n177_,
    new_n178_, new_n179_, new_n180_, new_n181_, new_n182_, new_n183_,
    new_n184_, new_n185_, new_n186_, new_n187_, new_n188_, new_n189_,
    new_n191_, new_n192_, new_n193_, new_n194_, new_n195_, new_n196_,
    new_n197_, new_n198_, new_n199_, new_n200_, new_n201_, new_n202_,
    new_n203_, new_n204_, new_n205_, new_n206_, new_n207_, new_n208_,
    new_n209_, new_n210_, new_n211_, new_n212_, new_n213_, new_n214_,
    new_n215_, new_n216_, new_n217_, new_n218_, new_n219_, new_n220_,
    new_n221_, new_n222_, new_n223_, new_n224_, new_n225_, new_n226_,
    new_n227_, new_n228_, new_n229_, new_n230_, new_n231_, new_n232_,
    new_n233_, new_n234_, new_n235_, new_n236_, new_n237_, new_n238_,
    new_n239_, new_n240_, new_n241_, new_n242_, new_n243_, new_n244_,
    new_n245_, new_n247_, new_n248_, new_n249_, new_n250_, new_n251_,
    new_n252_, new_n253_, new_n254_, new_n255_, new_n256_, new_n257_,
    new_n258_, new_n259_, new_n260_, new_n261_, new_n262_, new_n263_,
    new_n264_, new_n265_, new_n266_, new_n267_, new_n268_, new_n269_,
    new_n270_, new_n271_, new_n272_, new_n273_, new_n274_, new_n275_,
    new_n277_, new_n278_, new_n279_, new_n281_, new_n283_, new_n284_,
    new_n285_, new_n286_, new_n287_, new_n288_, new_n289_, new_n290_,
    new_n291_, new_n292_, new_n293_, new_n294_, new_n295_, new_n296_,
    new_n297_, new_n298_, new_n299_, new_n300_, new_n301_, new_n302_,
    new_n303_, new_n304_, new_n305_, new_n306_, new_n307_, new_n308_,
    new_n309_, new_n310_, new_n311_, new_n312_, new_n313_, new_n314_,
    new_n315_, new_n316_, new_n317_, new_n318_, new_n319_, new_n320_,
    new_n321_, new_n322_, new_n324_, new_n325_, new_n326_, new_n327_,
    new_n328_, new_n329_, new_n330_, new_n331_, new_n332_, new_n333_,
    new_n334_, new_n335_, new_n336_, new_n337_, new_n338_, new_n339_,
    new_n340_, new_n341_, new_n342_, new_n343_, new_n344_, new_n345_,
    new_n346_, new_n347_, new_n348_, new_n349_, new_n350_, new_n351_,
    new_n352_, new_n353_, new_n354_, new_n355_, new_n356_, new_n357_,
    new_n358_, new_n359_, new_n360_, new_n361_, new_n362_, new_n363_,
    new_n364_, new_n365_, new_n366_, new_n367_, new_n368_, new_n370_,
    new_n371_, new_n372_, new_n373_, new_n374_, new_n375_, new_n376_,
    new_n377_, new_n378_, new_n379_, new_n380_, new_n381_, new_n382_,
    new_n383_, new_n384_, new_n385_, new_n386_, new_n387_, new_n388_,
    new_n389_, new_n390_, new_n391_, new_n392_, new_n393_, new_n394_,
    new_n395_, new_n396_, new_n397_, new_n398_, new_n400_, new_n401_,
    new_n402_, new_n403_, new_n404_, new_n405_, new_n406_, new_n407_,
    new_n408_, new_n409_, new_n410_, new_n411_, new_n412_, new_n413_,
    new_n414_, new_n415_, new_n416_, new_n417_, new_n418_, new_n420_,
    new_n421_;
  INVx1_ASAP7_75t_R    g000(.A(p7), .Y(new_n22_));
  NAND2x1_ASAP7_75t_R  g001(.A(p0), .B(new_n22_), .Y(new_n23_));
  NOR2x1_ASAP7_75t_R   g002(.A(p2), .B(p0), .Y(new_n24_));
  AND2x2_ASAP7_75t_R   g003(.A(p8), .B(p1), .Y(new_n25_));
  NAND2x1_ASAP7_75t_R  g004(.A(new_n24_), .B(new_n25_), .Y(new_n26_));
  AO21x1_ASAP7_75t_R   g005(.A1(new_n23_), .A2(new_n26_), .B(p9), .Y(new_n27_));
  NAND2x1_ASAP7_75t_R  g006(.A(p8), .B(p1), .Y(new_n28_));
  NOR2x1_ASAP7_75t_R   g007(.A(p8), .B(p0), .Y(new_n29_));
  INVx1_ASAP7_75t_R    g008(.A(new_n29_), .Y(new_n30_));
  INVx1_ASAP7_75t_R    g009(.A(p2), .Y(new_n31_));
  NOR2x1_ASAP7_75t_R   g010(.A(p5), .B(new_n31_), .Y(new_n32_));
  AND2x2_ASAP7_75t_R   g011(.A(p2), .B(p1), .Y(new_n33_));
  OR3x1_ASAP7_75t_R    g012(.A(new_n30_), .B(new_n32_), .C(new_n33_), .Y(new_n34_));
  AO21x1_ASAP7_75t_R   g013(.A1(new_n28_), .A2(new_n34_), .B(p7), .Y(new_n35_));
  AO21x1_ASAP7_75t_R   g014(.A1(new_n27_), .A2(new_n35_), .B(p4), .Y(new_n36_));
  INVx1_ASAP7_75t_R    g015(.A(p1), .Y(new_n37_));
  NOR2x1_ASAP7_75t_R   g016(.A(p0), .B(new_n37_), .Y(new_n38_));
  INVx1_ASAP7_75t_R    g017(.A(p9), .Y(new_n39_));
  NOR2x1_ASAP7_75t_R   g018(.A(p8), .B(new_n39_), .Y(new_n40_));
  NOR2x1_ASAP7_75t_R   g019(.A(p9), .B(p7), .Y(new_n41_));
  AOI22x1_ASAP7_75t_R  g020(.A1(new_n38_), .A2(new_n40_), .B1(p8), .B2(new_n41_), .Y(new_n42_));
  AOI21x1_ASAP7_75t_R  g021(.A1(new_n23_), .A2(new_n42_), .B(p4), .Y(new_n43_));
  NOR2x1_ASAP7_75t_R   g022(.A(p9), .B(p0), .Y(new_n44_));
  AO21x1_ASAP7_75t_R   g023(.A1(new_n37_), .A2(new_n44_), .B(p4), .Y(new_n45_));
  NOR2x1_ASAP7_75t_R   g024(.A(p4), .B(p8), .Y(new_n46_));
  INVx1_ASAP7_75t_R    g025(.A(new_n46_), .Y(new_n47_));
  AND2x2_ASAP7_75t_R   g026(.A(p5), .B(p7), .Y(new_n48_));
  AND3x1_ASAP7_75t_R   g027(.A(p4), .B(p1), .C(p7), .Y(new_n49_));
  INVx1_ASAP7_75t_R    g028(.A(p8), .Y(new_n50_));
  NAND2x1_ASAP7_75t_R  g029(.A(p9), .B(new_n50_), .Y(new_n51_));
  AND2x2_ASAP7_75t_R   g030(.A(new_n49_), .B(new_n51_), .Y(new_n52_));
  NAND2x1_ASAP7_75t_R  g031(.A(p9), .B(p0), .Y(new_n53_));
  NAND2x1_ASAP7_75t_R  g032(.A(p0), .B(new_n50_), .Y(new_n54_));
  NAND2x1_ASAP7_75t_R  g033(.A(new_n53_), .B(new_n54_), .Y(new_n55_));
  AO32x1_ASAP7_75t_R   g034(.A1(new_n45_), .A2(new_n47_), .A3(new_n48_), .B1(new_n52_), .B2(new_n55_), .Y(new_n56_));
  OAI21x1_ASAP7_75t_R  g035(.A1(new_n43_), .A2(new_n56_), .B(p2), .Y(new_n57_));
  INVx1_ASAP7_75t_R    g036(.A(p5), .Y(new_n58_));
  AO21x1_ASAP7_75t_R   g037(.A1(p9), .A2(new_n50_), .B(p1), .Y(new_n59_));
  NAND2x1_ASAP7_75t_R  g038(.A(new_n58_), .B(new_n59_), .Y(new_n60_));
  NAND2x1_ASAP7_75t_R  g039(.A(p0), .B(new_n31_), .Y(new_n61_));
  NOR2x1_ASAP7_75t_R   g040(.A(p9), .B(new_n50_), .Y(new_n62_));
  NOR2x1_ASAP7_75t_R   g041(.A(new_n61_), .B(new_n62_), .Y(new_n63_));
  AND2x2_ASAP7_75t_R   g042(.A(p4), .B(p7), .Y(new_n64_));
  OA21x2_ASAP7_75t_R   g043(.A1(new_n59_), .A2(new_n63_), .B(new_n64_), .Y(new_n65_));
  NOR2x1_ASAP7_75t_R   g044(.A(p2), .B(p1), .Y(new_n66_));
  INVx1_ASAP7_75t_R    g045(.A(p0), .Y(new_n67_));
  AND3x1_ASAP7_75t_R   g046(.A(new_n50_), .B(new_n67_), .C(new_n22_), .Y(new_n68_));
  NOR2x1_ASAP7_75t_R   g047(.A(p8), .B(new_n67_), .Y(new_n69_));
  AO21x1_ASAP7_75t_R   g048(.A1(new_n37_), .A2(new_n69_), .B(new_n25_), .Y(new_n70_));
  NOR2x1_ASAP7_75t_R   g049(.A(p9), .B(p2), .Y(new_n71_));
  AND3x1_ASAP7_75t_R   g050(.A(new_n71_), .B(p5), .C(p7), .Y(new_n72_));
  AO32x1_ASAP7_75t_R   g051(.A1(new_n39_), .A2(new_n66_), .A3(new_n68_), .B1(new_n70_), .B2(new_n72_), .Y(new_n73_));
  AOI21x1_ASAP7_75t_R  g052(.A1(new_n60_), .A2(new_n65_), .B(new_n73_), .Y(new_n74_));
  NOR2x1_ASAP7_75t_R   g053(.A(p3), .B(p6), .Y(new_n75_));
  INVx1_ASAP7_75t_R    g054(.A(new_n75_), .Y(new_n76_));
  AO31x2_ASAP7_75t_R   g055(.A1(new_n36_), .A2(new_n57_), .A3(new_n74_), .B(new_n76_), .Y(new_n77_));
  NOR2x1_ASAP7_75t_R   g056(.A(p0), .B(new_n50_), .Y(new_n78_));
  INVx1_ASAP7_75t_R    g057(.A(new_n66_), .Y(new_n79_));
  AND3x1_ASAP7_75t_R   g058(.A(new_n67_), .B(p9), .C(p2), .Y(new_n80_));
  AOI221x1_ASAP7_75t_R g059(.A1(new_n31_), .A2(p0), .B1(new_n78_), .B2(new_n79_), .C(new_n80_), .Y(new_n81_));
  NAND2x1_ASAP7_75t_R  g060(.A(p1), .B(p0), .Y(new_n82_));
  INVx1_ASAP7_75t_R    g061(.A(p4), .Y(new_n83_));
  AO21x1_ASAP7_75t_R   g062(.A1(new_n83_), .A2(new_n37_), .B(p9), .Y(new_n84_));
  AO21x1_ASAP7_75t_R   g063(.A1(new_n82_), .A2(new_n84_), .B(p8), .Y(new_n85_));
  INVx1_ASAP7_75t_R    g064(.A(p6), .Y(new_n86_));
  NAND2x1_ASAP7_75t_R  g065(.A(new_n86_), .B(new_n22_), .Y(new_n87_));
  AO21x1_ASAP7_75t_R   g066(.A1(new_n81_), .A2(new_n85_), .B(new_n87_), .Y(new_n88_));
  NAND2x1_ASAP7_75t_R  g067(.A(p7), .B(new_n83_), .Y(new_n89_));
  NAND2x1_ASAP7_75t_R  g068(.A(p9), .B(new_n37_), .Y(new_n90_));
  AO21x1_ASAP7_75t_R   g069(.A1(p6), .A2(new_n47_), .B(new_n90_), .Y(new_n91_));
  AO21x1_ASAP7_75t_R   g070(.A1(new_n86_), .A2(new_n69_), .B(p2), .Y(new_n92_));
  AO21x1_ASAP7_75t_R   g071(.A1(new_n89_), .A2(new_n91_), .B(new_n92_), .Y(new_n93_));
  NOR2x1_ASAP7_75t_R   g072(.A(p8), .B(p9), .Y(new_n94_));
  NAND2x1_ASAP7_75t_R  g073(.A(new_n94_), .B(new_n38_), .Y(new_n95_));
  AO21x1_ASAP7_75t_R   g074(.A1(new_n67_), .A2(new_n47_), .B(new_n90_), .Y(new_n96_));
  OA21x2_ASAP7_75t_R   g075(.A1(new_n86_), .A2(new_n95_), .B(new_n96_), .Y(new_n97_));
  NOR2x1_ASAP7_75t_R   g076(.A(p1), .B(p7), .Y(new_n98_));
  INVx1_ASAP7_75t_R    g077(.A(new_n98_), .Y(new_n99_));
  AND2x2_ASAP7_75t_R   g078(.A(p8), .B(p0), .Y(new_n100_));
  NOR2x1_ASAP7_75t_R   g079(.A(new_n29_), .B(new_n100_), .Y(new_n101_));
  NOR2x1_ASAP7_75t_R   g080(.A(new_n99_), .B(new_n101_), .Y(new_n102_));
  INVx1_ASAP7_75t_R    g081(.A(new_n44_), .Y(new_n103_));
  AO32x1_ASAP7_75t_R   g082(.A1(new_n83_), .A2(new_n31_), .A3(new_n53_), .B1(new_n103_), .B2(new_n86_), .Y(new_n104_));
  NAND2x1_ASAP7_75t_R  g083(.A(new_n102_), .B(new_n104_), .Y(new_n105_));
  OA21x2_ASAP7_75t_R   g084(.A1(new_n93_), .A2(new_n97_), .B(new_n105_), .Y(new_n106_));
  INVx1_ASAP7_75t_R    g085(.A(p3), .Y(new_n107_));
  NAND2x1_ASAP7_75t_R  g086(.A(new_n58_), .B(new_n107_), .Y(new_n108_));
  AO21x1_ASAP7_75t_R   g087(.A1(new_n88_), .A2(new_n106_), .B(new_n108_), .Y(new_n109_));
  AND2x2_ASAP7_75t_R   g088(.A(p5), .B(p4), .Y(new_n110_));
  INVx1_ASAP7_75t_R    g089(.A(new_n110_), .Y(new_n111_));
  NAND2x1_ASAP7_75t_R  g090(.A(p4), .B(new_n22_), .Y(new_n112_));
  NOR2x1_ASAP7_75t_R   g091(.A(p5), .B(p8), .Y(new_n113_));
  AND2x2_ASAP7_75t_R   g092(.A(p3), .B(p7), .Y(new_n114_));
  NOR2x1_ASAP7_75t_R   g093(.A(new_n113_), .B(new_n114_), .Y(new_n115_));
  AO21x1_ASAP7_75t_R   g094(.A1(new_n111_), .A2(new_n112_), .B(new_n115_), .Y(new_n116_));
  AO21x1_ASAP7_75t_R   g095(.A1(p8), .A2(new_n107_), .B(new_n113_), .Y(new_n117_));
  OR3x1_ASAP7_75t_R    g096(.A(new_n117_), .B(p7), .C(new_n110_), .Y(new_n118_));
  OR3x1_ASAP7_75t_R    g097(.A(new_n103_), .B(new_n79_), .C(p6), .Y(new_n119_));
  AO21x1_ASAP7_75t_R   g098(.A1(new_n116_), .A2(new_n118_), .B(new_n119_), .Y(new_n120_));
  NAND3x1_ASAP7_75t_R  g099(.A(new_n77_), .B(new_n109_), .C(new_n120_), .Y(o0));
  NAND2x1_ASAP7_75t_R  g100(.A(new_n86_), .B(new_n31_), .Y(new_n122_));
  OR3x1_ASAP7_75t_R    g101(.A(new_n48_), .B(new_n39_), .C(p1), .Y(new_n123_));
  NAND2x1_ASAP7_75t_R  g102(.A(p5), .B(p8), .Y(new_n124_));
  OA21x2_ASAP7_75t_R   g103(.A1(p4), .A2(new_n22_), .B(new_n124_), .Y(new_n125_));
  INVx1_ASAP7_75t_R    g104(.A(new_n62_), .Y(new_n126_));
  NAND2x1_ASAP7_75t_R  g105(.A(p4), .B(new_n98_), .Y(new_n127_));
  OAI22x1_ASAP7_75t_R  g106(.A1(new_n123_), .A2(new_n125_), .B1(new_n126_), .B2(new_n127_), .Y(new_n128_));
  OA21x2_ASAP7_75t_R   g107(.A1(p9), .A2(new_n58_), .B(new_n37_), .Y(new_n129_));
  NAND2x1_ASAP7_75t_R  g108(.A(new_n58_), .B(new_n22_), .Y(new_n130_));
  OAI21x1_ASAP7_75t_R  g109(.A1(new_n89_), .A2(new_n129_), .B(new_n130_), .Y(new_n131_));
  AOI22x1_ASAP7_75t_R  g110(.A1(new_n128_), .A2(p0), .B1(new_n69_), .B2(new_n131_), .Y(new_n132_));
  NAND2x1_ASAP7_75t_R  g111(.A(p9), .B(p7), .Y(new_n133_));
  NOR2x1_ASAP7_75t_R   g112(.A(p9), .B(p1), .Y(new_n134_));
  NOR2x1_ASAP7_75t_R   g113(.A(p8), .B(p7), .Y(new_n135_));
  NAND2x1_ASAP7_75t_R  g114(.A(new_n134_), .B(new_n135_), .Y(new_n136_));
  OA21x2_ASAP7_75t_R   g115(.A1(new_n28_), .A2(new_n133_), .B(new_n136_), .Y(new_n137_));
  NAND2x1_ASAP7_75t_R  g116(.A(p4), .B(new_n67_), .Y(new_n138_));
  INVx1_ASAP7_75t_R    g117(.A(new_n113_), .Y(new_n139_));
  NAND2x1_ASAP7_75t_R  g118(.A(p1), .B(p7), .Y(new_n140_));
  OA22x2_ASAP7_75t_R   g119(.A1(new_n137_), .A2(new_n138_), .B1(new_n139_), .B2(new_n140_), .Y(new_n141_));
  OA22x2_ASAP7_75t_R   g120(.A1(new_n48_), .A2(new_n46_), .B1(p8), .B2(new_n22_), .Y(new_n142_));
  NOR2x1_ASAP7_75t_R   g121(.A(p9), .B(new_n125_), .Y(new_n143_));
  OAI21x1_ASAP7_75t_R  g122(.A1(new_n142_), .A2(new_n143_), .B(new_n38_), .Y(new_n144_));
  NAND3x1_ASAP7_75t_R  g123(.A(new_n132_), .B(new_n141_), .C(new_n144_), .Y(new_n145_));
  OR3x1_ASAP7_75t_R    g124(.A(p9), .B(p1), .C(p0), .Y(new_n146_));
  INVx1_ASAP7_75t_R    g125(.A(new_n146_), .Y(new_n147_));
  AO21x1_ASAP7_75t_R   g126(.A1(p4), .A2(new_n22_), .B(new_n114_), .Y(new_n148_));
  AND3x1_ASAP7_75t_R   g127(.A(p5), .B(p8), .C(p3), .Y(new_n149_));
  AO21x1_ASAP7_75t_R   g128(.A1(new_n113_), .A2(new_n148_), .B(new_n149_), .Y(new_n150_));
  AOI22x1_ASAP7_75t_R  g129(.A1(new_n145_), .A2(new_n107_), .B1(new_n147_), .B2(new_n150_), .Y(new_n151_));
  NAND2x1_ASAP7_75t_R  g130(.A(p2), .B(new_n37_), .Y(new_n152_));
  NAND2x1_ASAP7_75t_R  g131(.A(new_n67_), .B(new_n22_), .Y(new_n153_));
  NAND2x1_ASAP7_75t_R  g132(.A(p4), .B(p0), .Y(new_n154_));
  OA21x2_ASAP7_75t_R   g133(.A1(new_n152_), .A2(new_n153_), .B(new_n154_), .Y(new_n155_));
  OR3x1_ASAP7_75t_R    g134(.A(new_n155_), .B(new_n58_), .C(new_n39_), .Y(new_n156_));
  NOR2x1_ASAP7_75t_R   g135(.A(p4), .B(p2), .Y(new_n157_));
  OR3x1_ASAP7_75t_R    g136(.A(new_n66_), .B(new_n157_), .C(new_n58_), .Y(new_n158_));
  AO21x1_ASAP7_75t_R   g137(.A1(new_n83_), .A2(new_n82_), .B(new_n158_), .Y(new_n159_));
  OR3x1_ASAP7_75t_R    g138(.A(new_n112_), .B(new_n31_), .C(new_n82_), .Y(new_n160_));
  AND3x1_ASAP7_75t_R   g139(.A(new_n159_), .B(p8), .C(new_n160_), .Y(new_n161_));
  AOI21x1_ASAP7_75t_R  g140(.A1(new_n156_), .A2(new_n161_), .B(new_n76_), .Y(new_n162_));
  NOR2x1_ASAP7_75t_R   g141(.A(p2), .B(p7), .Y(new_n163_));
  AO21x1_ASAP7_75t_R   g142(.A1(new_n83_), .A2(p7), .B(new_n163_), .Y(new_n164_));
  OAI21x1_ASAP7_75t_R  g143(.A1(new_n39_), .A2(new_n164_), .B(new_n127_), .Y(new_n165_));
  AND3x1_ASAP7_75t_R   g144(.A(new_n79_), .B(new_n99_), .C(new_n39_), .Y(new_n166_));
  NOR2x1_ASAP7_75t_R   g145(.A(p9), .B(new_n83_), .Y(new_n167_));
  NOR2x1_ASAP7_75t_R   g146(.A(p1), .B(new_n133_), .Y(new_n168_));
  NAND2x1_ASAP7_75t_R  g147(.A(p9), .B(new_n83_), .Y(new_n169_));
  INVx1_ASAP7_75t_R    g148(.A(new_n169_), .Y(new_n170_));
  OA31x2_ASAP7_75t_R   g149(.A1(new_n167_), .A2(new_n168_), .A3(new_n170_), .B1(p0), .Y(new_n171_));
  AOI211x1_ASAP7_75t_R g150(.A1(new_n67_), .A2(new_n165_), .B(new_n166_), .C(new_n171_), .Y(new_n172_));
  NAND2x1_ASAP7_75t_R  g151(.A(p2), .B(new_n83_), .Y(new_n173_));
  AOI22x1_ASAP7_75t_R  g152(.A1(new_n153_), .A2(new_n37_), .B1(new_n67_), .B2(new_n48_), .Y(new_n174_));
  NOR2x1_ASAP7_75t_R   g153(.A(p9), .B(new_n22_), .Y(new_n175_));
  AND2x2_ASAP7_75t_R   g154(.A(p9), .B(p0), .Y(new_n176_));
  NOR2x1_ASAP7_75t_R   g155(.A(p5), .B(p0), .Y(new_n177_));
  OR5x1_ASAP7_75t_R    g156(.A(p4), .B(new_n175_), .C(p1), .D(new_n176_), .E(new_n177_), .Y(new_n178_));
  OA211x2_ASAP7_75t_R  g157(.A1(new_n173_), .A2(new_n174_), .B(new_n178_), .C(new_n50_), .Y(new_n179_));
  OAI21x1_ASAP7_75t_R  g158(.A1(p5), .A2(new_n172_), .B(new_n179_), .Y(new_n180_));
  OR3x1_ASAP7_75t_R    g159(.A(new_n108_), .B(p4), .C(p2), .Y(new_n181_));
  OA211x2_ASAP7_75t_R  g160(.A1(new_n41_), .A2(new_n98_), .B(new_n82_), .C(p6), .Y(new_n182_));
  OAI21x1_ASAP7_75t_R  g161(.A1(new_n176_), .A2(new_n59_), .B(new_n182_), .Y(new_n183_));
  NOR2x1_ASAP7_75t_R   g162(.A(p1), .B(new_n22_), .Y(new_n184_));
  INVx1_ASAP7_75t_R    g163(.A(new_n184_), .Y(new_n185_));
  OR3x1_ASAP7_75t_R    g164(.A(new_n185_), .B(new_n86_), .C(new_n54_), .Y(new_n186_));
  AND3x1_ASAP7_75t_R   g165(.A(new_n183_), .B(new_n186_), .C(new_n95_), .Y(new_n187_));
  NOR2x1_ASAP7_75t_R   g166(.A(new_n181_), .B(new_n187_), .Y(new_n188_));
  AOI21x1_ASAP7_75t_R  g167(.A1(new_n162_), .A2(new_n180_), .B(new_n188_), .Y(new_n189_));
  OAI21x1_ASAP7_75t_R  g168(.A1(new_n122_), .A2(new_n151_), .B(new_n189_), .Y(o1));
  NOR2x1_ASAP7_75t_R   g169(.A(p7), .B(new_n37_), .Y(new_n191_));
  AND2x2_ASAP7_75t_R   g170(.A(p5), .B(p1), .Y(new_n192_));
  OR3x1_ASAP7_75t_R    g171(.A(new_n191_), .B(new_n67_), .C(new_n192_), .Y(new_n193_));
  AND3x1_ASAP7_75t_R   g172(.A(new_n79_), .B(new_n99_), .C(p4), .Y(new_n194_));
  NOR2x1_ASAP7_75t_R   g173(.A(p7), .B(new_n31_), .Y(new_n195_));
  NAND2x1_ASAP7_75t_R  g174(.A(p2), .B(new_n50_), .Y(new_n196_));
  OA211x2_ASAP7_75t_R  g175(.A1(new_n69_), .A2(new_n195_), .B(new_n196_), .C(new_n58_), .Y(new_n197_));
  AOI211x1_ASAP7_75t_R g176(.A1(new_n193_), .A2(new_n194_), .B(p3), .C(new_n197_), .Y(new_n198_));
  OR4x2_ASAP7_75t_R    g177(.A(p4), .B(p8), .C(p2), .D(p0), .Y(new_n199_));
  OR3x1_ASAP7_75t_R    g178(.A(new_n50_), .B(new_n67_), .C(p2), .Y(new_n200_));
  NAND2x1_ASAP7_75t_R  g179(.A(p5), .B(new_n22_), .Y(new_n201_));
  AO21x1_ASAP7_75t_R   g180(.A1(new_n199_), .A2(new_n200_), .B(new_n201_), .Y(new_n202_));
  NAND2x1_ASAP7_75t_R  g181(.A(p4), .B(p2), .Y(new_n203_));
  OA21x2_ASAP7_75t_R   g182(.A1(new_n203_), .A2(new_n184_), .B(new_n69_), .Y(new_n204_));
  AO21x1_ASAP7_75t_R   g183(.A1(p7), .A2(new_n152_), .B(p4), .Y(new_n205_));
  NOR2x1_ASAP7_75t_R   g184(.A(p1), .B(new_n31_), .Y(new_n206_));
  AO21x1_ASAP7_75t_R   g185(.A1(new_n78_), .A2(new_n195_), .B(new_n206_), .Y(new_n207_));
  AND3x1_ASAP7_75t_R   g186(.A(new_n50_), .B(p0), .C(p7), .Y(new_n208_));
  NOR2x1_ASAP7_75t_R   g187(.A(new_n113_), .B(new_n208_), .Y(new_n209_));
  AOI22x1_ASAP7_75t_R  g188(.A1(new_n204_), .A2(new_n205_), .B1(new_n207_), .B2(new_n209_), .Y(new_n210_));
  NAND3x1_ASAP7_75t_R  g189(.A(new_n198_), .B(new_n202_), .C(new_n210_), .Y(new_n211_));
  NAND2x1_ASAP7_75t_R  g190(.A(p8), .B(p7), .Y(new_n212_));
  AO21x1_ASAP7_75t_R   g191(.A1(new_n212_), .A2(new_n201_), .B(p4), .Y(new_n213_));
  AO21x1_ASAP7_75t_R   g192(.A1(new_n67_), .A2(new_n66_), .B(new_n107_), .Y(new_n214_));
  OA211x2_ASAP7_75t_R  g193(.A1(new_n107_), .A2(new_n213_), .B(new_n39_), .C(new_n214_), .Y(new_n215_));
  NOR2x1_ASAP7_75t_R   g194(.A(p0), .B(new_n31_), .Y(new_n216_));
  OA211x2_ASAP7_75t_R  g195(.A1(new_n83_), .A2(new_n216_), .B(new_n37_), .C(new_n135_), .Y(new_n217_));
  AND2x2_ASAP7_75t_R   g196(.A(p9), .B(p7), .Y(new_n218_));
  AND3x1_ASAP7_75t_R   g197(.A(new_n79_), .B(new_n78_), .C(new_n218_), .Y(new_n219_));
  AND2x2_ASAP7_75t_R   g198(.A(p8), .B(p7), .Y(new_n220_));
  NOR2x1_ASAP7_75t_R   g199(.A(new_n135_), .B(new_n220_), .Y(new_n221_));
  NOR2x1_ASAP7_75t_R   g200(.A(p2), .B(new_n37_), .Y(new_n222_));
  OA21x2_ASAP7_75t_R   g201(.A1(new_n29_), .A2(new_n221_), .B(new_n222_), .Y(new_n223_));
  AOI211x1_ASAP7_75t_R g202(.A1(p9), .A2(new_n217_), .B(new_n219_), .C(new_n223_), .Y(new_n224_));
  OR3x1_ASAP7_75t_R    g203(.A(new_n50_), .B(new_n37_), .C(p4), .Y(new_n225_));
  OR3x1_ASAP7_75t_R    g204(.A(new_n221_), .B(new_n83_), .C(new_n62_), .Y(new_n226_));
  AO21x1_ASAP7_75t_R   g205(.A1(new_n225_), .A2(new_n226_), .B(new_n61_), .Y(new_n227_));
  AOI21x1_ASAP7_75t_R  g206(.A1(new_n224_), .A2(new_n227_), .B(new_n108_), .Y(new_n228_));
  AOI21x1_ASAP7_75t_R  g207(.A1(new_n211_), .A2(new_n215_), .B(new_n228_), .Y(new_n229_));
  AND2x2_ASAP7_75t_R   g208(.A(new_n163_), .B(new_n54_), .Y(new_n230_));
  OR3x1_ASAP7_75t_R    g209(.A(new_n230_), .B(new_n48_), .C(new_n208_), .Y(new_n231_));
  INVx1_ASAP7_75t_R    g210(.A(new_n78_), .Y(new_n232_));
  AND2x2_ASAP7_75t_R   g211(.A(p1), .B(p0), .Y(new_n233_));
  AO32x1_ASAP7_75t_R   g212(.A1(new_n233_), .A2(p5), .A3(p8), .B1(new_n48_), .B2(new_n67_), .Y(new_n234_));
  AND3x1_ASAP7_75t_R   g213(.A(new_n50_), .B(new_n22_), .C(p1), .Y(new_n235_));
  NOR2x1_ASAP7_75t_R   g214(.A(p8), .B(new_n37_), .Y(new_n236_));
  NOR2x1_ASAP7_75t_R   g215(.A(new_n22_), .B(new_n236_), .Y(new_n237_));
  OR3x1_ASAP7_75t_R    g216(.A(new_n234_), .B(new_n235_), .C(new_n237_), .Y(new_n238_));
  AO32x1_ASAP7_75t_R   g217(.A1(new_n231_), .A2(new_n37_), .A3(new_n232_), .B1(new_n238_), .B2(p2), .Y(new_n239_));
  AND3x1_ASAP7_75t_R   g218(.A(new_n75_), .B(new_n83_), .C(p9), .Y(new_n240_));
  AO21x1_ASAP7_75t_R   g219(.A1(p6), .A2(new_n220_), .B(new_n39_), .Y(new_n241_));
  AO32x1_ASAP7_75t_R   g220(.A1(new_n67_), .A2(new_n22_), .A3(new_n40_), .B1(new_n241_), .B2(new_n55_), .Y(new_n242_));
  NOR2x1_ASAP7_75t_R   g221(.A(p5), .B(p4), .Y(new_n243_));
  AND3x1_ASAP7_75t_R   g222(.A(new_n66_), .B(new_n243_), .C(new_n107_), .Y(new_n244_));
  AOI22x1_ASAP7_75t_R  g223(.A1(new_n239_), .A2(new_n240_), .B1(new_n242_), .B2(new_n244_), .Y(new_n245_));
  OAI21x1_ASAP7_75t_R  g224(.A1(p6), .A2(new_n229_), .B(new_n245_), .Y(o2));
  NAND2x1_ASAP7_75t_R  g225(.A(p8), .B(new_n58_), .Y(new_n247_));
  INVx1_ASAP7_75t_R    g226(.A(new_n247_), .Y(new_n248_));
  AO21x1_ASAP7_75t_R   g227(.A1(p5), .A2(new_n22_), .B(p2), .Y(new_n249_));
  AND3x1_ASAP7_75t_R   g228(.A(new_n249_), .B(new_n111_), .C(new_n112_), .Y(new_n250_));
  AOI221x1_ASAP7_75t_R g229(.A1(new_n83_), .A2(new_n235_), .B1(new_n49_), .B2(new_n248_), .C(new_n250_), .Y(new_n251_));
  AOI22x1_ASAP7_75t_R  g230(.A1(new_n216_), .A2(new_n247_), .B1(new_n192_), .B2(new_n154_), .Y(new_n252_));
  OAI21x1_ASAP7_75t_R  g231(.A1(new_n67_), .A2(new_n251_), .B(new_n252_), .Y(new_n253_));
  NOR2x1_ASAP7_75t_R   g232(.A(p3), .B(p9), .Y(new_n254_));
  AO21x1_ASAP7_75t_R   g233(.A1(new_n243_), .A2(new_n220_), .B(new_n110_), .Y(new_n255_));
  OR3x1_ASAP7_75t_R    g234(.A(new_n146_), .B(new_n107_), .C(p2), .Y(new_n256_));
  INVx1_ASAP7_75t_R    g235(.A(new_n256_), .Y(new_n257_));
  AOI22x1_ASAP7_75t_R  g236(.A1(new_n253_), .A2(new_n254_), .B1(new_n255_), .B2(new_n257_), .Y(new_n258_));
  NOR2x1_ASAP7_75t_R   g237(.A(p1), .B(new_n83_), .Y(new_n259_));
  AO21x1_ASAP7_75t_R   g238(.A1(new_n259_), .A2(new_n221_), .B(new_n206_), .Y(new_n260_));
  OA21x2_ASAP7_75t_R   g239(.A1(p5), .A2(new_n195_), .B(new_n173_), .Y(new_n261_));
  AO21x1_ASAP7_75t_R   g240(.A1(new_n236_), .A2(new_n164_), .B(new_n261_), .Y(new_n262_));
  OAI21x1_ASAP7_75t_R  g241(.A1(new_n260_), .A2(new_n262_), .B(new_n176_), .Y(new_n263_));
  AO32x1_ASAP7_75t_R   g242(.A1(new_n98_), .A2(new_n177_), .A3(p4), .B1(p5), .B2(new_n157_), .Y(new_n264_));
  AO32x1_ASAP7_75t_R   g243(.A1(new_n79_), .A2(p5), .A3(new_n83_), .B1(new_n32_), .B2(p1), .Y(new_n265_));
  NAND2x1_ASAP7_75t_R  g244(.A(p2), .B(new_n58_), .Y(new_n266_));
  NOR2x1_ASAP7_75t_R   g245(.A(new_n266_), .B(new_n153_), .Y(new_n267_));
  AOI221x1_ASAP7_75t_R g246(.A1(new_n40_), .A2(new_n264_), .B1(new_n265_), .B2(new_n78_), .C(new_n267_), .Y(new_n268_));
  AND3x1_ASAP7_75t_R   g247(.A(new_n135_), .B(p5), .C(new_n83_), .Y(new_n269_));
  AO21x1_ASAP7_75t_R   g248(.A1(new_n58_), .A2(new_n22_), .B(new_n46_), .Y(new_n270_));
  AO32x1_ASAP7_75t_R   g249(.A1(p5), .A2(new_n83_), .A3(new_n208_), .B1(new_n270_), .B2(new_n206_), .Y(new_n271_));
  AO21x1_ASAP7_75t_R   g250(.A1(new_n58_), .A2(new_n83_), .B(new_n113_), .Y(new_n272_));
  OA211x2_ASAP7_75t_R  g251(.A1(new_n64_), .A2(new_n100_), .B(new_n272_), .C(p2), .Y(new_n273_));
  AOI211x1_ASAP7_75t_R g252(.A1(new_n67_), .A2(new_n269_), .B(new_n271_), .C(new_n273_), .Y(new_n274_));
  AO31x2_ASAP7_75t_R   g253(.A1(new_n263_), .A2(new_n268_), .A3(new_n274_), .B(p3), .Y(new_n275_));
  AOI21x1_ASAP7_75t_R  g254(.A1(new_n258_), .A2(new_n275_), .B(p6), .Y(o3));
  NOR2x1_ASAP7_75t_R   g255(.A(new_n37_), .B(new_n44_), .Y(new_n277_));
  XOR2x2_ASAP7_75t_R   g256(.A(new_n66_), .B(new_n107_), .Y(new_n278_));
  AND3x1_ASAP7_75t_R   g257(.A(new_n86_), .B(p5), .C(p4), .Y(new_n279_));
  OA211x2_ASAP7_75t_R  g258(.A1(new_n147_), .A2(new_n277_), .B(new_n278_), .C(new_n279_), .Y(o4));
  AND3x1_ASAP7_75t_R   g259(.A(new_n146_), .B(new_n107_), .C(p2), .Y(new_n281_));
  OA21x2_ASAP7_75t_R   g260(.A1(new_n281_), .A2(new_n257_), .B(new_n279_), .Y(o5));
  OA211x2_ASAP7_75t_R  g261(.A1(p9), .A2(p7), .B(new_n69_), .C(new_n169_), .Y(new_n283_));
  AND3x1_ASAP7_75t_R   g262(.A(new_n168_), .B(p5), .C(p8), .Y(new_n284_));
  OA211x2_ASAP7_75t_R  g263(.A1(p9), .A2(new_n37_), .B(new_n100_), .C(new_n22_), .Y(new_n285_));
  OR3x1_ASAP7_75t_R    g264(.A(new_n283_), .B(new_n284_), .C(new_n285_), .Y(new_n286_));
  NOR2x1_ASAP7_75t_R   g265(.A(p4), .B(new_n31_), .Y(new_n287_));
  NOR2x1_ASAP7_75t_R   g266(.A(p5), .B(p9), .Y(new_n288_));
  AO21x1_ASAP7_75t_R   g267(.A1(p1), .A2(p0), .B(new_n288_), .Y(new_n289_));
  NOR2x1_ASAP7_75t_R   g268(.A(p0), .B(new_n135_), .Y(new_n290_));
  NOR2x1_ASAP7_75t_R   g269(.A(new_n39_), .B(new_n290_), .Y(new_n291_));
  AO32x1_ASAP7_75t_R   g270(.A1(new_n153_), .A2(new_n101_), .A3(new_n289_), .B1(new_n291_), .B2(new_n54_), .Y(new_n292_));
  AOI22x1_ASAP7_75t_R  g271(.A1(new_n286_), .A2(p2), .B1(new_n287_), .B2(new_n292_), .Y(new_n293_));
  AND2x2_ASAP7_75t_R   g272(.A(p4), .B(p1), .Y(new_n294_));
  OR5x1_ASAP7_75t_R    g273(.A(p5), .B(new_n294_), .C(new_n233_), .D(p8), .E(new_n133_), .Y(new_n295_));
  NAND2x1_ASAP7_75t_R  g274(.A(p4), .B(new_n68_), .Y(new_n296_));
  OR3x1_ASAP7_75t_R    g275(.A(new_n28_), .B(new_n83_), .C(p9), .Y(new_n297_));
  AND3x1_ASAP7_75t_R   g276(.A(new_n295_), .B(new_n296_), .C(new_n297_), .Y(new_n298_));
  NOR2x1_ASAP7_75t_R   g277(.A(p9), .B(new_n140_), .Y(new_n299_));
  AND3x1_ASAP7_75t_R   g278(.A(new_n100_), .B(new_n218_), .C(p4), .Y(new_n300_));
  OAI21x1_ASAP7_75t_R  g279(.A1(new_n299_), .A2(new_n300_), .B(new_n47_), .Y(new_n301_));
  OR4x2_ASAP7_75t_R    g280(.A(new_n221_), .B(new_n58_), .C(new_n184_), .D(new_n191_), .Y(new_n302_));
  AO31x2_ASAP7_75t_R   g281(.A1(new_n298_), .A2(new_n301_), .A3(new_n302_), .B(p2), .Y(new_n303_));
  AO21x1_ASAP7_75t_R   g282(.A1(new_n51_), .A2(new_n259_), .B(new_n62_), .Y(new_n304_));
  AO21x1_ASAP7_75t_R   g283(.A1(p1), .A2(new_n83_), .B(p5), .Y(new_n305_));
  OA211x2_ASAP7_75t_R  g284(.A1(new_n126_), .A2(new_n305_), .B(p0), .C(new_n22_), .Y(new_n306_));
  OA21x2_ASAP7_75t_R   g285(.A1(p8), .A2(p7), .B(p1), .Y(new_n307_));
  AO21x1_ASAP7_75t_R   g286(.A1(p8), .A2(new_n218_), .B(new_n307_), .Y(new_n308_));
  AND3x1_ASAP7_75t_R   g287(.A(new_n308_), .B(p5), .C(p0), .Y(new_n309_));
  NAND2x1_ASAP7_75t_R  g288(.A(new_n50_), .B(new_n37_), .Y(new_n310_));
  NOR2x1_ASAP7_75t_R   g289(.A(new_n64_), .B(new_n310_), .Y(new_n311_));
  AO21x1_ASAP7_75t_R   g290(.A1(p5), .A2(new_n22_), .B(p9), .Y(new_n312_));
  AO32x1_ASAP7_75t_R   g291(.A1(new_n311_), .A2(new_n67_), .A3(new_n312_), .B1(new_n78_), .B2(new_n299_), .Y(new_n313_));
  AOI211x1_ASAP7_75t_R g292(.A1(new_n304_), .A2(new_n306_), .B(new_n309_), .C(new_n313_), .Y(new_n314_));
  NAND3x1_ASAP7_75t_R  g293(.A(new_n293_), .B(new_n303_), .C(new_n314_), .Y(new_n315_));
  AO21x1_ASAP7_75t_R   g294(.A1(p6), .A2(new_n50_), .B(new_n22_), .Y(new_n316_));
  AO22x1_ASAP7_75t_R   g295(.A1(new_n37_), .A2(new_n69_), .B1(new_n38_), .B2(new_n316_), .Y(new_n317_));
  AO21x1_ASAP7_75t_R   g296(.A1(new_n100_), .A2(new_n218_), .B(new_n135_), .Y(new_n318_));
  AND3x1_ASAP7_75t_R   g297(.A(new_n318_), .B(p6), .C(new_n37_), .Y(new_n319_));
  AOI21x1_ASAP7_75t_R  g298(.A1(new_n39_), .A2(new_n317_), .B(new_n319_), .Y(new_n320_));
  AO21x1_ASAP7_75t_R   g299(.A1(new_n111_), .A2(new_n256_), .B(p6), .Y(new_n321_));
  OAI21x1_ASAP7_75t_R  g300(.A1(new_n181_), .A2(new_n320_), .B(new_n321_), .Y(new_n322_));
  AOI21x1_ASAP7_75t_R  g301(.A1(new_n75_), .A2(new_n315_), .B(new_n322_), .Y(o6));
  INVx1_ASAP7_75t_R    g302(.A(new_n135_), .Y(new_n324_));
  NOR2x1_ASAP7_75t_R   g303(.A(p9), .B(new_n37_), .Y(new_n325_));
  AND3x1_ASAP7_75t_R   g304(.A(new_n324_), .B(new_n325_), .C(new_n212_), .Y(new_n326_));
  AND3x1_ASAP7_75t_R   g305(.A(new_n168_), .B(new_n50_), .C(p6), .Y(new_n327_));
  AND3x1_ASAP7_75t_R   g306(.A(new_n243_), .B(new_n31_), .C(new_n67_), .Y(new_n328_));
  OAI21x1_ASAP7_75t_R  g307(.A1(new_n326_), .A2(new_n327_), .B(new_n328_), .Y(new_n329_));
  AOI21x1_ASAP7_75t_R  g308(.A1(p6), .A2(new_n329_), .B(p3), .Y(new_n330_));
  AOI21x1_ASAP7_75t_R  g309(.A1(new_n266_), .A2(new_n201_), .B(new_n50_), .Y(new_n331_));
  NAND2x1_ASAP7_75t_R  g310(.A(p7), .B(new_n39_), .Y(new_n332_));
  NAND2x1_ASAP7_75t_R  g311(.A(new_n332_), .B(new_n201_), .Y(new_n333_));
  AOI221x1_ASAP7_75t_R g312(.A1(p8), .A2(new_n39_), .B1(new_n124_), .B2(new_n22_), .C(new_n288_), .Y(new_n334_));
  AOI22x1_ASAP7_75t_R  g313(.A1(new_n331_), .A2(new_n333_), .B1(new_n266_), .B2(new_n334_), .Y(new_n335_));
  AO21x1_ASAP7_75t_R   g314(.A1(p2), .A2(new_n212_), .B(new_n218_), .Y(new_n336_));
  NOR2x1_ASAP7_75t_R   g315(.A(p5), .B(new_n37_), .Y(new_n337_));
  AND3x1_ASAP7_75t_R   g316(.A(new_n25_), .B(new_n31_), .C(p7), .Y(new_n338_));
  AOI221x1_ASAP7_75t_R g317(.A1(new_n113_), .A2(new_n163_), .B1(new_n336_), .B2(new_n337_), .C(new_n338_), .Y(new_n339_));
  OAI21x1_ASAP7_75t_R  g318(.A1(p1), .A2(new_n335_), .B(new_n339_), .Y(new_n340_));
  OAI21x1_ASAP7_75t_R  g319(.A1(new_n22_), .A2(new_n94_), .B(p4), .Y(new_n341_));
  OAI21x1_ASAP7_75t_R  g320(.A1(p8), .A2(p1), .B(p9), .Y(new_n342_));
  AO21x1_ASAP7_75t_R   g321(.A1(p8), .A2(p1), .B(new_n342_), .Y(new_n343_));
  OR3x1_ASAP7_75t_R    g322(.A(new_n135_), .B(new_n98_), .C(p2), .Y(new_n344_));
  AO21x1_ASAP7_75t_R   g323(.A1(new_n341_), .A2(new_n343_), .B(new_n344_), .Y(new_n345_));
  AND2x2_ASAP7_75t_R   g324(.A(p4), .B(p2), .Y(new_n346_));
  AO21x1_ASAP7_75t_R   g325(.A1(new_n50_), .A2(p1), .B(new_n346_), .Y(new_n347_));
  AND3x1_ASAP7_75t_R   g326(.A(new_n259_), .B(p2), .C(new_n212_), .Y(new_n348_));
  AOI21x1_ASAP7_75t_R  g327(.A1(new_n41_), .A2(new_n347_), .B(new_n348_), .Y(new_n349_));
  AOI21x1_ASAP7_75t_R  g328(.A1(new_n345_), .A2(new_n349_), .B(p5), .Y(new_n350_));
  AOI21x1_ASAP7_75t_R  g329(.A1(new_n83_), .A2(new_n340_), .B(new_n350_), .Y(new_n351_));
  OA211x2_ASAP7_75t_R  g330(.A1(new_n135_), .A2(new_n220_), .B(p5), .C(new_n39_), .Y(new_n352_));
  AOI21x1_ASAP7_75t_R  g331(.A1(new_n139_), .A2(new_n130_), .B(new_n59_), .Y(new_n353_));
  OAI21x1_ASAP7_75t_R  g332(.A1(new_n352_), .A2(new_n353_), .B(new_n216_), .Y(new_n354_));
  OAI21x1_ASAP7_75t_R  g333(.A1(p5), .A2(new_n163_), .B(new_n307_), .Y(new_n355_));
  OR3x1_ASAP7_75t_R    g334(.A(new_n133_), .B(new_n58_), .C(p8), .Y(new_n356_));
  AO31x2_ASAP7_75t_R   g335(.A1(new_n355_), .A2(new_n356_), .A3(new_n136_), .B(p0), .Y(new_n357_));
  OR3x1_ASAP7_75t_R    g336(.A(new_n324_), .B(new_n152_), .C(new_n58_), .Y(new_n358_));
  NAND3x1_ASAP7_75t_R  g337(.A(new_n354_), .B(new_n357_), .C(new_n358_), .Y(new_n359_));
  OR3x1_ASAP7_75t_R    g338(.A(new_n33_), .B(new_n220_), .C(new_n135_), .Y(new_n360_));
  AO21x1_ASAP7_75t_R   g339(.A1(p9), .A2(p2), .B(p1), .Y(new_n361_));
  AND3x1_ASAP7_75t_R   g340(.A(new_n361_), .B(p4), .C(new_n67_), .Y(new_n362_));
  AND3x1_ASAP7_75t_R   g341(.A(new_n25_), .B(new_n346_), .C(p7), .Y(new_n363_));
  AOI221x1_ASAP7_75t_R g342(.A1(new_n80_), .A2(new_n235_), .B1(new_n360_), .B2(new_n362_), .C(new_n363_), .Y(new_n364_));
  OAI21x1_ASAP7_75t_R  g343(.A1(p5), .A2(new_n364_), .B(new_n329_), .Y(new_n365_));
  AOI21x1_ASAP7_75t_R  g344(.A1(new_n83_), .A2(new_n359_), .B(new_n365_), .Y(new_n366_));
  OAI21x1_ASAP7_75t_R  g345(.A1(new_n67_), .A2(new_n351_), .B(new_n366_), .Y(new_n367_));
  AND3x1_ASAP7_75t_R   g346(.A(new_n257_), .B(new_n86_), .C(new_n243_), .Y(new_n368_));
  AOI21x1_ASAP7_75t_R  g347(.A1(new_n330_), .A2(new_n367_), .B(new_n368_), .Y(o7));
  INVx1_ASAP7_75t_R    g348(.A(new_n157_), .Y(new_n370_));
  AOI211x1_ASAP7_75t_R g349(.A1(new_n138_), .A2(new_n370_), .B(new_n71_), .C(new_n185_), .Y(new_n371_));
  OA211x2_ASAP7_75t_R  g350(.A1(p4), .A2(new_n175_), .B(new_n233_), .C(new_n203_), .Y(new_n372_));
  AND3x1_ASAP7_75t_R   g351(.A(new_n218_), .B(new_n83_), .C(new_n24_), .Y(new_n373_));
  OR3x1_ASAP7_75t_R    g352(.A(new_n371_), .B(new_n372_), .C(new_n373_), .Y(new_n374_));
  OR5x1_ASAP7_75t_R    g353(.A(new_n31_), .B(new_n167_), .C(p1), .D(p0), .E(new_n22_), .Y(new_n375_));
  OR5x1_ASAP7_75t_R    g354(.A(new_n67_), .B(new_n195_), .C(new_n287_), .D(new_n294_), .E(new_n66_), .Y(new_n376_));
  NAND2x1_ASAP7_75t_R  g355(.A(new_n375_), .B(new_n376_), .Y(new_n377_));
  AOI22x1_ASAP7_75t_R  g356(.A1(new_n374_), .A2(new_n113_), .B1(new_n248_), .B2(new_n377_), .Y(new_n378_));
  NAND2x1_ASAP7_75t_R  g357(.A(new_n54_), .B(new_n175_), .Y(new_n379_));
  AND3x1_ASAP7_75t_R   g358(.A(new_n379_), .B(p5), .C(new_n232_), .Y(new_n380_));
  AO21x1_ASAP7_75t_R   g359(.A1(p0), .A2(new_n22_), .B(p5), .Y(new_n381_));
  OA21x2_ASAP7_75t_R   g360(.A1(new_n381_), .A2(new_n291_), .B(new_n287_), .Y(new_n382_));
  OAI21x1_ASAP7_75t_R  g361(.A1(p1), .A2(new_n380_), .B(new_n382_), .Y(new_n383_));
  NAND2x1_ASAP7_75t_R  g362(.A(new_n29_), .B(new_n259_), .Y(new_n384_));
  AO21x1_ASAP7_75t_R   g363(.A1(new_n200_), .A2(new_n384_), .B(p9), .Y(new_n385_));
  AO221x2_ASAP7_75t_R  g364(.A1(new_n310_), .A2(new_n152_), .B1(new_n138_), .B2(new_n370_), .C(new_n29_), .Y(new_n386_));
  NAND2x1_ASAP7_75t_R  g365(.A(new_n83_), .B(new_n67_), .Y(new_n387_));
  INVx1_ASAP7_75t_R    g366(.A(new_n222_), .Y(new_n388_));
  AO21x1_ASAP7_75t_R   g367(.A1(new_n387_), .A2(new_n101_), .B(new_n388_), .Y(new_n389_));
  AO31x2_ASAP7_75t_R   g368(.A1(new_n385_), .A2(new_n386_), .A3(new_n389_), .B(new_n130_), .Y(new_n390_));
  NAND3x1_ASAP7_75t_R  g369(.A(new_n378_), .B(new_n383_), .C(new_n390_), .Y(new_n391_));
  NAND2x1_ASAP7_75t_R  g370(.A(new_n140_), .B(new_n99_), .Y(new_n392_));
  AO32x1_ASAP7_75t_R   g371(.A1(new_n39_), .A2(new_n22_), .A3(new_n25_), .B1(new_n168_), .B2(new_n50_), .Y(new_n393_));
  AO21x1_ASAP7_75t_R   g372(.A1(new_n94_), .A2(new_n392_), .B(new_n393_), .Y(new_n394_));
  AND3x1_ASAP7_75t_R   g373(.A(new_n100_), .B(new_n22_), .C(new_n134_), .Y(new_n395_));
  AOI21x1_ASAP7_75t_R  g374(.A1(new_n67_), .A2(new_n394_), .B(new_n395_), .Y(new_n396_));
  OR3x1_ASAP7_75t_R    g375(.A(new_n256_), .B(p4), .C(p6), .Y(new_n397_));
  OAI21x1_ASAP7_75t_R  g376(.A1(new_n181_), .A2(new_n396_), .B(new_n397_), .Y(new_n398_));
  AOI21x1_ASAP7_75t_R  g377(.A1(new_n75_), .A2(new_n391_), .B(new_n398_), .Y(o8));
  AND2x2_ASAP7_75t_R   g378(.A(p2), .B(new_n124_), .Y(new_n400_));
  OR3x1_ASAP7_75t_R    g379(.A(new_n332_), .B(new_n113_), .C(new_n243_), .Y(new_n401_));
  AO21x1_ASAP7_75t_R   g380(.A1(p8), .A2(p7), .B(p4), .Y(new_n402_));
  OR3x1_ASAP7_75t_R    g381(.A(new_n243_), .B(new_n107_), .C(p2), .Y(new_n403_));
  AO32x1_ASAP7_75t_R   g382(.A1(new_n31_), .A2(new_n402_), .A3(new_n307_), .B1(new_n403_), .B2(new_n37_), .Y(new_n404_));
  NAND2x1_ASAP7_75t_R  g383(.A(new_n67_), .B(new_n404_), .Y(new_n405_));
  AO21x1_ASAP7_75t_R   g384(.A1(new_n400_), .A2(new_n401_), .B(new_n405_), .Y(new_n406_));
  OA21x2_ASAP7_75t_R   g385(.A1(p2), .A2(new_n46_), .B(new_n332_), .Y(new_n407_));
  OR3x1_ASAP7_75t_R    g386(.A(new_n407_), .B(p1), .C(new_n400_), .Y(new_n408_));
  AO21x1_ASAP7_75t_R   g387(.A1(new_n58_), .A2(new_n22_), .B(p2), .Y(new_n409_));
  OR3x1_ASAP7_75t_R    g388(.A(new_n266_), .B(new_n37_), .C(new_n402_), .Y(new_n410_));
  OA21x2_ASAP7_75t_R   g389(.A1(new_n272_), .A2(new_n409_), .B(new_n410_), .Y(new_n411_));
  AO21x1_ASAP7_75t_R   g390(.A1(new_n408_), .A2(new_n411_), .B(new_n67_), .Y(new_n412_));
  OR3x1_ASAP7_75t_R    g391(.A(new_n266_), .B(new_n169_), .C(new_n37_), .Y(new_n413_));
  AO21x1_ASAP7_75t_R   g392(.A1(new_n86_), .A2(new_n413_), .B(new_n290_), .Y(new_n414_));
  AO21x1_ASAP7_75t_R   g393(.A1(new_n83_), .A2(new_n388_), .B(new_n58_), .Y(new_n415_));
  OR3x1_ASAP7_75t_R    g394(.A(new_n79_), .B(new_n39_), .C(p0), .Y(new_n416_));
  AO21x1_ASAP7_75t_R   g395(.A1(new_n39_), .A2(new_n222_), .B(new_n86_), .Y(new_n417_));
  AND3x1_ASAP7_75t_R   g396(.A(new_n415_), .B(new_n416_), .C(new_n417_), .Y(new_n418_));
  AND5x1_ASAP7_75t_R   g397(.A(new_n406_), .B(new_n214_), .C(new_n412_), .D(new_n414_), .E(new_n418_), .Y(o9));
  OR3x1_ASAP7_75t_R    g398(.A(new_n69_), .B(new_n22_), .C(new_n176_), .Y(new_n420_));
  AND5x1_ASAP7_75t_R   g399(.A(new_n107_), .B(new_n420_), .C(new_n103_), .D(new_n232_), .E(new_n33_), .Y(new_n421_));
  OA211x2_ASAP7_75t_R  g400(.A1(new_n257_), .A2(new_n421_), .B(new_n86_), .C(new_n243_), .Y(o10));
endmodule


