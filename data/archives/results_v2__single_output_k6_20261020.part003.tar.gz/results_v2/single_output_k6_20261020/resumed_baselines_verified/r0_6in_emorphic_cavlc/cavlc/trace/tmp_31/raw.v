// Benchmark "/tmp/" written by ABC on Tue Oct 20 17:20:37 2026

module \/tmp/  ( 
    p2, p0, p6, p1, p7, p9, p3, p5, p4, p8,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10  );
  input  p2, p0, p6, p1, p7, p9, p3, p5, p4, p8;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10;
  wire new_n22_, new_n23_, new_n24_, new_n25_, new_n26_, new_n27_, new_n28_,
    new_n29_, new_n30_, new_n31_, new_n32_, new_n33_, new_n34_, new_n35_,
    new_n36_, new_n37_, new_n38_, new_n39_, new_n40_, new_n41_, new_n42_,
    new_n43_, new_n44_, new_n45_, new_n46_, new_n47_, new_n48_, new_n49_,
    new_n50_, new_n51_, new_n52_, new_n53_, new_n54_, new_n55_, new_n56_,
    new_n57_, new_n58_, new_n59_, new_n60_, new_n61_, new_n62_, new_n63_,
    new_n64_, new_n65_, new_n66_, new_n67_, new_n68_, new_n69_, new_n70_,
    new_n71_, new_n72_, new_n73_, new_n74_, new_n75_, new_n76_, new_n77_,
    new_n78_, new_n79_, new_n80_, new_n81_, new_n82_, new_n83_, new_n84_,
    new_n85_, new_n86_, new_n87_, new_n88_, new_n89_, new_n90_, new_n91_,
    new_n92_, new_n93_, new_n94_, new_n95_, new_n96_, new_n97_, new_n98_,
    new_n99_, new_n100_, new_n101_, new_n102_, new_n103_, new_n104_,
    new_n105_, new_n106_, new_n107_, new_n108_, new_n109_, new_n110_,
    new_n111_, new_n112_, new_n113_, new_n114_, new_n115_, new_n117_,
    new_n118_, new_n119_, new_n120_, new_n121_, new_n122_, new_n123_,
    new_n124_, new_n125_, new_n126_, new_n127_, new_n128_, new_n129_,
    new_n130_, new_n131_, new_n132_, new_n133_, new_n134_, new_n135_,
    new_n136_, new_n137_, new_n138_, new_n139_, new_n140_, new_n141_,
    new_n142_, new_n143_, new_n144_, new_n145_, new_n146_, new_n147_,
    new_n148_, new_n149_, new_n150_, new_n151_, new_n152_, new_n153_,
    new_n154_, new_n155_, new_n156_, new_n157_, new_n158_, new_n159_,
    new_n160_, new_n161_, new_n162_, new_n163_, new_n164_, new_n165_,
    new_n166_, new_n167_, new_n168_, new_n169_, new_n170_, new_n171_,
    new_n172_, new_n173_, new_n174_, new_n175_, new_n176_, new_n177_,
    new_n178_, new_n179_, new_n180_, new_n182_, new_n183_, new_n184_,
    new_n185_, new_n186_, new_n187_, new_n188_, new_n189_, new_n190_,
    new_n191_, new_n192_, new_n193_, new_n194_, new_n195_, new_n196_,
    new_n197_, new_n198_, new_n199_, new_n200_, new_n201_, new_n202_,
    new_n203_, new_n204_, new_n205_, new_n206_, new_n207_, new_n208_,
    new_n209_, new_n210_, new_n211_, new_n212_, new_n213_, new_n214_,
    new_n215_, new_n216_, new_n217_, new_n218_, new_n219_, new_n220_,
    new_n221_, new_n222_, new_n223_, new_n224_, new_n225_, new_n226_,
    new_n227_, new_n228_, new_n229_, new_n230_, new_n231_, new_n233_,
    new_n234_, new_n235_, new_n236_, new_n237_, new_n238_, new_n239_,
    new_n240_, new_n241_, new_n242_, new_n243_, new_n244_, new_n245_,
    new_n246_, new_n247_, new_n248_, new_n249_, new_n250_, new_n251_,
    new_n252_, new_n253_, new_n254_, new_n255_, new_n256_, new_n257_,
    new_n258_, new_n259_, new_n260_, new_n261_, new_n263_, new_n264_,
    new_n265_, new_n266_, new_n267_, new_n269_, new_n270_, new_n272_,
    new_n273_, new_n274_, new_n275_, new_n276_, new_n277_, new_n278_,
    new_n279_, new_n280_, new_n281_, new_n282_, new_n283_, new_n284_,
    new_n285_, new_n286_, new_n287_, new_n288_, new_n289_, new_n290_,
    new_n291_, new_n292_, new_n293_, new_n294_, new_n295_, new_n296_,
    new_n297_, new_n298_, new_n299_, new_n300_, new_n301_, new_n302_,
    new_n303_, new_n304_, new_n305_, new_n306_, new_n307_, new_n308_,
    new_n309_, new_n310_, new_n311_, new_n313_, new_n314_, new_n315_,
    new_n316_, new_n317_, new_n318_, new_n319_, new_n320_, new_n321_,
    new_n322_, new_n323_, new_n324_, new_n325_, new_n326_, new_n327_,
    new_n328_, new_n329_, new_n330_, new_n331_, new_n332_, new_n333_,
    new_n334_, new_n335_, new_n336_, new_n337_, new_n338_, new_n339_,
    new_n340_, new_n341_, new_n342_, new_n343_, new_n344_, new_n345_,
    new_n346_, new_n347_, new_n348_, new_n349_, new_n350_, new_n351_,
    new_n352_, new_n353_, new_n354_, new_n355_, new_n356_, new_n357_,
    new_n358_, new_n359_, new_n360_, new_n361_, new_n362_, new_n364_,
    new_n365_, new_n366_, new_n367_, new_n368_, new_n369_, new_n370_,
    new_n371_, new_n372_, new_n373_, new_n374_, new_n375_, new_n376_,
    new_n377_, new_n378_, new_n379_, new_n380_, new_n381_, new_n382_,
    new_n383_, new_n384_, new_n385_, new_n386_, new_n387_, new_n388_,
    new_n389_, new_n390_, new_n391_, new_n392_, new_n393_, new_n394_,
    new_n395_, new_n397_, new_n398_, new_n399_, new_n400_, new_n401_,
    new_n402_, new_n403_, new_n404_, new_n405_, new_n406_, new_n407_,
    new_n408_, new_n409_, new_n410_, new_n411_, new_n412_, new_n414_,
    new_n415_;
  NOR2x1_ASAP7_75t_R   g000(.A(p0), .B(p1), .Y(new_n22_));
  INVx1_ASAP7_75t_R    g001(.A(p9), .Y(new_n23_));
  NAND2x1_ASAP7_75t_R  g002(.A(p8), .B(new_n23_), .Y(new_n24_));
  INVx1_ASAP7_75t_R    g003(.A(new_n24_), .Y(new_n25_));
  AO21x1_ASAP7_75t_R   g004(.A1(new_n22_), .A2(new_n25_), .B(p4), .Y(new_n26_));
  AND2x2_ASAP7_75t_R   g005(.A(p7), .B(p5), .Y(new_n27_));
  INVx1_ASAP7_75t_R    g006(.A(p8), .Y(new_n28_));
  NAND2x1_ASAP7_75t_R  g007(.A(p9), .B(new_n28_), .Y(new_n29_));
  AND5x1_ASAP7_75t_R   g008(.A(p0), .B(new_n29_), .C(new_n24_), .D(p1), .E(p4), .Y(new_n30_));
  AOI22x1_ASAP7_75t_R  g009(.A1(new_n26_), .A2(new_n27_), .B1(p7), .B2(new_n30_), .Y(new_n31_));
  INVx1_ASAP7_75t_R    g010(.A(p1), .Y(new_n32_));
  NOR2x1_ASAP7_75t_R   g011(.A(p0), .B(new_n32_), .Y(new_n33_));
  NOR2x1_ASAP7_75t_R   g012(.A(p8), .B(new_n23_), .Y(new_n34_));
  INVx1_ASAP7_75t_R    g013(.A(p7), .Y(new_n35_));
  NAND2x1_ASAP7_75t_R  g014(.A(p0), .B(new_n35_), .Y(new_n36_));
  INVx1_ASAP7_75t_R    g015(.A(new_n36_), .Y(new_n37_));
  AO21x1_ASAP7_75t_R   g016(.A1(new_n33_), .A2(new_n34_), .B(new_n37_), .Y(new_n38_));
  INVx1_ASAP7_75t_R    g017(.A(p4), .Y(new_n39_));
  NOR2x1_ASAP7_75t_R   g018(.A(p7), .B(p4), .Y(new_n40_));
  AOI22x1_ASAP7_75t_R  g019(.A1(new_n38_), .A2(new_n39_), .B1(new_n25_), .B2(new_n40_), .Y(new_n41_));
  INVx1_ASAP7_75t_R    g020(.A(p2), .Y(new_n42_));
  AOI21x1_ASAP7_75t_R  g021(.A1(new_n31_), .A2(new_n41_), .B(new_n42_), .Y(new_n43_));
  NOR2x1_ASAP7_75t_R   g022(.A(p1), .B(new_n34_), .Y(new_n44_));
  NAND2x1_ASAP7_75t_R  g023(.A(p0), .B(p9), .Y(new_n45_));
  NAND2x1_ASAP7_75t_R  g024(.A(p0), .B(new_n28_), .Y(new_n46_));
  AO21x1_ASAP7_75t_R   g025(.A1(new_n45_), .A2(new_n46_), .B(p2), .Y(new_n47_));
  AND2x2_ASAP7_75t_R   g026(.A(p7), .B(p4), .Y(new_n48_));
  OAI21x1_ASAP7_75t_R  g027(.A1(p5), .A2(new_n44_), .B(new_n48_), .Y(new_n49_));
  AO21x1_ASAP7_75t_R   g028(.A1(new_n44_), .A2(new_n47_), .B(new_n49_), .Y(new_n50_));
  AND3x1_ASAP7_75t_R   g029(.A(new_n27_), .B(new_n42_), .C(new_n23_), .Y(new_n51_));
  NOR2x1_ASAP7_75t_R   g030(.A(p1), .B(p8), .Y(new_n52_));
  NAND2x1_ASAP7_75t_R  g031(.A(p1), .B(p8), .Y(new_n53_));
  INVx1_ASAP7_75t_R    g032(.A(new_n53_), .Y(new_n54_));
  AO21x1_ASAP7_75t_R   g033(.A1(p0), .A2(new_n52_), .B(new_n54_), .Y(new_n55_));
  NOR2x1_ASAP7_75t_R   g034(.A(p0), .B(p8), .Y(new_n56_));
  NOR2x1_ASAP7_75t_R   g035(.A(p1), .B(p9), .Y(new_n57_));
  NOR2x1_ASAP7_75t_R   g036(.A(p2), .B(p7), .Y(new_n58_));
  AND3x1_ASAP7_75t_R   g037(.A(new_n56_), .B(new_n57_), .C(new_n58_), .Y(new_n59_));
  AOI21x1_ASAP7_75t_R  g038(.A1(new_n51_), .A2(new_n55_), .B(new_n59_), .Y(new_n60_));
  NOR2x1_ASAP7_75t_R   g039(.A(p2), .B(p0), .Y(new_n61_));
  AO21x1_ASAP7_75t_R   g040(.A1(new_n54_), .A2(new_n61_), .B(new_n37_), .Y(new_n62_));
  NOR2x1_ASAP7_75t_R   g041(.A(p9), .B(p4), .Y(new_n63_));
  INVx1_ASAP7_75t_R    g042(.A(p5), .Y(new_n64_));
  NAND2x1_ASAP7_75t_R  g043(.A(p2), .B(new_n64_), .Y(new_n65_));
  NAND2x1_ASAP7_75t_R  g044(.A(p2), .B(p1), .Y(new_n66_));
  AO32x1_ASAP7_75t_R   g045(.A1(new_n65_), .A2(new_n56_), .A3(new_n66_), .B1(p1), .B2(p8), .Y(new_n67_));
  AOI22x1_ASAP7_75t_R  g046(.A1(new_n62_), .A2(new_n63_), .B1(new_n40_), .B2(new_n67_), .Y(new_n68_));
  NAND3x1_ASAP7_75t_R  g047(.A(new_n50_), .B(new_n60_), .C(new_n68_), .Y(new_n69_));
  NOR2x1_ASAP7_75t_R   g048(.A(p6), .B(p3), .Y(new_n70_));
  OAI21x1_ASAP7_75t_R  g049(.A1(new_n43_), .A2(new_n69_), .B(new_n70_), .Y(new_n71_));
  NAND2x1_ASAP7_75t_R  g050(.A(p0), .B(p1), .Y(new_n72_));
  AO21x1_ASAP7_75t_R   g051(.A1(new_n32_), .A2(new_n39_), .B(p9), .Y(new_n73_));
  AO21x1_ASAP7_75t_R   g052(.A1(new_n72_), .A2(new_n73_), .B(p8), .Y(new_n74_));
  INVx1_ASAP7_75t_R    g053(.A(p0), .Y(new_n75_));
  NAND2x1_ASAP7_75t_R  g054(.A(p8), .B(new_n75_), .Y(new_n76_));
  NOR2x1_ASAP7_75t_R   g055(.A(p2), .B(p1), .Y(new_n77_));
  NAND3x1_ASAP7_75t_R  g056(.A(new_n75_), .B(p2), .C(p9), .Y(new_n78_));
  NAND2x1_ASAP7_75t_R  g057(.A(p0), .B(new_n42_), .Y(new_n79_));
  OA211x2_ASAP7_75t_R  g058(.A1(new_n76_), .A2(new_n77_), .B(new_n78_), .C(new_n79_), .Y(new_n80_));
  INVx1_ASAP7_75t_R    g059(.A(p6), .Y(new_n81_));
  NAND2x1_ASAP7_75t_R  g060(.A(new_n81_), .B(new_n35_), .Y(new_n82_));
  AO21x1_ASAP7_75t_R   g061(.A1(new_n74_), .A2(new_n80_), .B(new_n82_), .Y(new_n83_));
  NOR2x1_ASAP7_75t_R   g062(.A(p0), .B(p9), .Y(new_n84_));
  NOR2x1_ASAP7_75t_R   g063(.A(p8), .B(new_n32_), .Y(new_n85_));
  NAND2x1_ASAP7_75t_R  g064(.A(p9), .B(new_n32_), .Y(new_n86_));
  NOR2x1_ASAP7_75t_R   g065(.A(p0), .B(new_n28_), .Y(new_n87_));
  NOR2x1_ASAP7_75t_R   g066(.A(new_n86_), .B(new_n87_), .Y(new_n88_));
  NAND2x1_ASAP7_75t_R  g067(.A(p4), .B(new_n75_), .Y(new_n89_));
  AO32x1_ASAP7_75t_R   g068(.A1(p6), .A2(new_n84_), .A3(new_n85_), .B1(new_n88_), .B2(new_n89_), .Y(new_n90_));
  INVx1_ASAP7_75t_R    g069(.A(new_n46_), .Y(new_n91_));
  NOR2x1_ASAP7_75t_R   g070(.A(p4), .B(p8), .Y(new_n92_));
  INVx1_ASAP7_75t_R    g071(.A(new_n92_), .Y(new_n93_));
  AO21x1_ASAP7_75t_R   g072(.A1(p6), .A2(new_n93_), .B(new_n86_), .Y(new_n94_));
  NAND2x1_ASAP7_75t_R  g073(.A(p7), .B(new_n39_), .Y(new_n95_));
  AOI221x1_ASAP7_75t_R g074(.A1(new_n81_), .A2(new_n91_), .B1(new_n94_), .B2(new_n95_), .C(p2), .Y(new_n96_));
  INVx1_ASAP7_75t_R    g075(.A(new_n84_), .Y(new_n97_));
  AO32x1_ASAP7_75t_R   g076(.A1(new_n42_), .A2(new_n39_), .A3(new_n45_), .B1(new_n97_), .B2(new_n81_), .Y(new_n98_));
  NOR2x1_ASAP7_75t_R   g077(.A(p1), .B(p7), .Y(new_n99_));
  XNOR2x2_ASAP7_75t_R  g078(.A(p0), .B(p8), .Y(new_n100_));
  AND3x1_ASAP7_75t_R   g079(.A(new_n98_), .B(new_n99_), .C(new_n100_), .Y(new_n101_));
  AOI21x1_ASAP7_75t_R  g080(.A1(new_n90_), .A2(new_n96_), .B(new_n101_), .Y(new_n102_));
  INVx1_ASAP7_75t_R    g081(.A(p3), .Y(new_n103_));
  NAND2x1_ASAP7_75t_R  g082(.A(new_n103_), .B(new_n64_), .Y(new_n104_));
  AO21x1_ASAP7_75t_R   g083(.A1(new_n83_), .A2(new_n102_), .B(new_n104_), .Y(new_n105_));
  NOR2x1_ASAP7_75t_R   g084(.A(p7), .B(new_n39_), .Y(new_n106_));
  AND2x2_ASAP7_75t_R   g085(.A(p5), .B(p4), .Y(new_n107_));
  NOR2x1_ASAP7_75t_R   g086(.A(p5), .B(p8), .Y(new_n108_));
  AND2x2_ASAP7_75t_R   g087(.A(p7), .B(p3), .Y(new_n109_));
  OAI22x1_ASAP7_75t_R  g088(.A1(new_n106_), .A2(new_n107_), .B1(new_n108_), .B2(new_n109_), .Y(new_n110_));
  AO21x1_ASAP7_75t_R   g089(.A1(new_n103_), .A2(p8), .B(new_n107_), .Y(new_n111_));
  OR3x1_ASAP7_75t_R    g090(.A(new_n111_), .B(p7), .C(new_n108_), .Y(new_n112_));
  OR3x1_ASAP7_75t_R    g091(.A(p0), .B(p1), .C(p9), .Y(new_n113_));
  OR3x1_ASAP7_75t_R    g092(.A(new_n113_), .B(p2), .C(p6), .Y(new_n114_));
  AO21x1_ASAP7_75t_R   g093(.A1(new_n110_), .A2(new_n112_), .B(new_n114_), .Y(new_n115_));
  NAND3x1_ASAP7_75t_R  g094(.A(new_n71_), .B(new_n105_), .C(new_n115_), .Y(o0));
  NAND2x1_ASAP7_75t_R  g095(.A(new_n42_), .B(new_n81_), .Y(new_n117_));
  NOR2x1_ASAP7_75t_R   g096(.A(p4), .B(new_n35_), .Y(new_n118_));
  AOI21x1_ASAP7_75t_R  g097(.A1(p5), .A2(p8), .B(new_n118_), .Y(new_n119_));
  OR3x1_ASAP7_75t_R    g098(.A(new_n27_), .B(p1), .C(new_n23_), .Y(new_n120_));
  NAND2x1_ASAP7_75t_R  g099(.A(p4), .B(new_n99_), .Y(new_n121_));
  OAI22x1_ASAP7_75t_R  g100(.A1(new_n119_), .A2(new_n120_), .B1(new_n24_), .B2(new_n121_), .Y(new_n122_));
  AO21x1_ASAP7_75t_R   g101(.A1(p5), .A2(new_n23_), .B(p1), .Y(new_n123_));
  NOR2x1_ASAP7_75t_R   g102(.A(p7), .B(p5), .Y(new_n124_));
  AO21x1_ASAP7_75t_R   g103(.A1(new_n118_), .A2(new_n123_), .B(new_n124_), .Y(new_n125_));
  AOI22x1_ASAP7_75t_R  g104(.A1(new_n122_), .A2(p0), .B1(new_n91_), .B2(new_n125_), .Y(new_n126_));
  AND2x2_ASAP7_75t_R   g105(.A(p7), .B(p8), .Y(new_n127_));
  AO22x1_ASAP7_75t_R   g106(.A1(new_n28_), .A2(new_n40_), .B1(p5), .B2(new_n127_), .Y(new_n128_));
  NOR2x1_ASAP7_75t_R   g107(.A(p9), .B(new_n119_), .Y(new_n129_));
  OAI21x1_ASAP7_75t_R  g108(.A1(new_n128_), .A2(new_n129_), .B(new_n33_), .Y(new_n130_));
  NOR2x1_ASAP7_75t_R   g109(.A(p7), .B(p9), .Y(new_n131_));
  AO32x1_ASAP7_75t_R   g110(.A1(new_n127_), .A2(p1), .A3(p9), .B1(new_n52_), .B2(new_n131_), .Y(new_n132_));
  NOR2x1_ASAP7_75t_R   g111(.A(p0), .B(new_n39_), .Y(new_n133_));
  NAND2x1_ASAP7_75t_R  g112(.A(p7), .B(new_n64_), .Y(new_n134_));
  INVx1_ASAP7_75t_R    g113(.A(new_n134_), .Y(new_n135_));
  AOI22x1_ASAP7_75t_R  g114(.A1(new_n132_), .A2(new_n133_), .B1(new_n85_), .B2(new_n135_), .Y(new_n136_));
  NAND3x1_ASAP7_75t_R  g115(.A(new_n126_), .B(new_n130_), .C(new_n136_), .Y(new_n137_));
  AND3x1_ASAP7_75t_R   g116(.A(p3), .B(p5), .C(p8), .Y(new_n138_));
  OA21x2_ASAP7_75t_R   g117(.A1(new_n109_), .A2(new_n106_), .B(new_n108_), .Y(new_n139_));
  OA211x2_ASAP7_75t_R  g118(.A1(new_n138_), .A2(new_n139_), .B(new_n75_), .C(new_n57_), .Y(new_n140_));
  AOI21x1_ASAP7_75t_R  g119(.A1(new_n103_), .A2(new_n137_), .B(new_n140_), .Y(new_n141_));
  NOR2x1_ASAP7_75t_R   g120(.A(p0), .B(new_n42_), .Y(new_n142_));
  AND2x2_ASAP7_75t_R   g121(.A(p0), .B(p4), .Y(new_n143_));
  AO21x1_ASAP7_75t_R   g122(.A1(new_n99_), .A2(new_n142_), .B(new_n143_), .Y(new_n144_));
  AND3x1_ASAP7_75t_R   g123(.A(new_n144_), .B(p9), .C(p5), .Y(new_n145_));
  INVx1_ASAP7_75t_R    g124(.A(new_n77_), .Y(new_n146_));
  AND3x1_ASAP7_75t_R   g125(.A(p2), .B(p0), .C(p1), .Y(new_n147_));
  AO21x1_ASAP7_75t_R   g126(.A1(p4), .A2(new_n146_), .B(new_n147_), .Y(new_n148_));
  AO21x1_ASAP7_75t_R   g127(.A1(new_n147_), .A2(new_n106_), .B(new_n28_), .Y(new_n149_));
  AO21x1_ASAP7_75t_R   g128(.A1(p5), .A2(new_n148_), .B(new_n149_), .Y(new_n150_));
  OA21x2_ASAP7_75t_R   g129(.A1(new_n145_), .A2(new_n150_), .B(new_n70_), .Y(new_n151_));
  INVx1_ASAP7_75t_R    g130(.A(new_n58_), .Y(new_n152_));
  AO32x1_ASAP7_75t_R   g131(.A1(new_n152_), .A2(new_n95_), .A3(p9), .B1(p4), .B2(new_n99_), .Y(new_n153_));
  AO21x1_ASAP7_75t_R   g132(.A1(p2), .A2(p7), .B(p1), .Y(new_n154_));
  AND2x2_ASAP7_75t_R   g133(.A(new_n23_), .B(new_n154_), .Y(new_n155_));
  AND3x1_ASAP7_75t_R   g134(.A(new_n32_), .B(p7), .C(p9), .Y(new_n156_));
  NAND2x1_ASAP7_75t_R  g135(.A(p4), .B(new_n23_), .Y(new_n157_));
  NAND2x1_ASAP7_75t_R  g136(.A(p9), .B(new_n39_), .Y(new_n158_));
  NAND2x1_ASAP7_75t_R  g137(.A(new_n157_), .B(new_n158_), .Y(new_n159_));
  OA21x2_ASAP7_75t_R   g138(.A1(new_n156_), .A2(new_n159_), .B(p0), .Y(new_n160_));
  AOI211x1_ASAP7_75t_R g139(.A1(new_n75_), .A2(new_n153_), .B(new_n155_), .C(new_n160_), .Y(new_n161_));
  NAND2x1_ASAP7_75t_R  g140(.A(p2), .B(new_n39_), .Y(new_n162_));
  NOR2x1_ASAP7_75t_R   g141(.A(p0), .B(p7), .Y(new_n163_));
  OR3x1_ASAP7_75t_R    g142(.A(new_n35_), .B(new_n64_), .C(p0), .Y(new_n164_));
  OA21x2_ASAP7_75t_R   g143(.A1(p1), .A2(new_n163_), .B(new_n164_), .Y(new_n165_));
  NOR2x1_ASAP7_75t_R   g144(.A(p9), .B(new_n35_), .Y(new_n166_));
  AND2x2_ASAP7_75t_R   g145(.A(p0), .B(p9), .Y(new_n167_));
  NOR2x1_ASAP7_75t_R   g146(.A(p0), .B(p5), .Y(new_n168_));
  OR5x1_ASAP7_75t_R    g147(.A(p1), .B(new_n166_), .C(p4), .D(new_n167_), .E(new_n168_), .Y(new_n169_));
  OA211x2_ASAP7_75t_R  g148(.A1(new_n162_), .A2(new_n165_), .B(new_n169_), .C(new_n28_), .Y(new_n170_));
  OAI21x1_ASAP7_75t_R  g149(.A1(p5), .A2(new_n161_), .B(new_n170_), .Y(new_n171_));
  AND3x1_ASAP7_75t_R   g150(.A(new_n28_), .B(p0), .C(p7), .Y(new_n172_));
  AO32x1_ASAP7_75t_R   g151(.A1(new_n172_), .A2(p6), .A3(new_n32_), .B1(new_n84_), .B2(new_n85_), .Y(new_n173_));
  OR3x1_ASAP7_75t_R    g152(.A(new_n34_), .B(p1), .C(new_n167_), .Y(new_n174_));
  OA21x2_ASAP7_75t_R   g153(.A1(new_n99_), .A2(new_n131_), .B(new_n72_), .Y(new_n175_));
  AND3x1_ASAP7_75t_R   g154(.A(new_n174_), .B(p6), .C(new_n175_), .Y(new_n176_));
  NOR2x1_ASAP7_75t_R   g155(.A(p2), .B(p4), .Y(new_n177_));
  AND3x1_ASAP7_75t_R   g156(.A(new_n177_), .B(new_n103_), .C(new_n64_), .Y(new_n178_));
  OA21x2_ASAP7_75t_R   g157(.A1(new_n173_), .A2(new_n176_), .B(new_n178_), .Y(new_n179_));
  AOI21x1_ASAP7_75t_R  g158(.A1(new_n151_), .A2(new_n171_), .B(new_n179_), .Y(new_n180_));
  OAI21x1_ASAP7_75t_R  g159(.A1(new_n117_), .A2(new_n141_), .B(new_n180_), .Y(o1));
  NAND2x1_ASAP7_75t_R  g160(.A(p2), .B(new_n35_), .Y(new_n182_));
  NAND2x1_ASAP7_75t_R  g161(.A(p2), .B(new_n32_), .Y(new_n183_));
  OA21x2_ASAP7_75t_R   g162(.A1(new_n76_), .A2(new_n182_), .B(new_n183_), .Y(new_n184_));
  OR3x1_ASAP7_75t_R    g163(.A(new_n184_), .B(new_n108_), .C(new_n172_), .Y(new_n185_));
  NAND2x1_ASAP7_75t_R  g164(.A(new_n42_), .B(new_n64_), .Y(new_n186_));
  NAND2x1_ASAP7_75t_R  g165(.A(p8), .B(new_n64_), .Y(new_n187_));
  AO22x1_ASAP7_75t_R   g166(.A1(new_n46_), .A2(new_n182_), .B1(new_n186_), .B2(new_n187_), .Y(new_n188_));
  AND3x1_ASAP7_75t_R   g167(.A(new_n185_), .B(new_n103_), .C(new_n188_), .Y(new_n189_));
  AND3x1_ASAP7_75t_R   g168(.A(new_n92_), .B(new_n163_), .C(p5), .Y(new_n190_));
  AND3x1_ASAP7_75t_R   g169(.A(new_n37_), .B(p5), .C(p8), .Y(new_n191_));
  OAI21x1_ASAP7_75t_R  g170(.A1(new_n190_), .A2(new_n191_), .B(new_n42_), .Y(new_n192_));
  AO21x1_ASAP7_75t_R   g171(.A1(p7), .A2(new_n183_), .B(p4), .Y(new_n193_));
  NAND2x1_ASAP7_75t_R  g172(.A(p2), .B(p4), .Y(new_n194_));
  NOR2x1_ASAP7_75t_R   g173(.A(p1), .B(new_n35_), .Y(new_n195_));
  OA21x2_ASAP7_75t_R   g174(.A1(new_n194_), .A2(new_n195_), .B(new_n91_), .Y(new_n196_));
  AO21x1_ASAP7_75t_R   g175(.A1(p1), .A2(new_n134_), .B(new_n75_), .Y(new_n197_));
  AND3x1_ASAP7_75t_R   g176(.A(new_n197_), .B(p4), .C(new_n154_), .Y(new_n198_));
  AOI21x1_ASAP7_75t_R  g177(.A1(new_n193_), .A2(new_n196_), .B(new_n198_), .Y(new_n199_));
  NAND2x1_ASAP7_75t_R  g178(.A(p7), .B(p8), .Y(new_n200_));
  NAND2x1_ASAP7_75t_R  g179(.A(p5), .B(new_n35_), .Y(new_n201_));
  AOI211x1_ASAP7_75t_R g180(.A1(new_n200_), .A2(new_n201_), .B(new_n103_), .C(p4), .Y(new_n202_));
  AND3x1_ASAP7_75t_R   g181(.A(new_n42_), .B(new_n75_), .C(new_n32_), .Y(new_n203_));
  NOR2x1_ASAP7_75t_R   g182(.A(new_n103_), .B(new_n203_), .Y(new_n204_));
  OR4x2_ASAP7_75t_R    g183(.A(new_n202_), .B(new_n204_), .C(p6), .D(p9), .Y(new_n205_));
  AO31x2_ASAP7_75t_R   g184(.A1(new_n189_), .A2(new_n192_), .A3(new_n199_), .B(new_n205_), .Y(new_n206_));
  NOR2x1_ASAP7_75t_R   g185(.A(p7), .B(p8), .Y(new_n207_));
  OA211x2_ASAP7_75t_R  g186(.A1(new_n39_), .A2(new_n142_), .B(new_n32_), .C(new_n207_), .Y(new_n208_));
  AND2x2_ASAP7_75t_R   g187(.A(p7), .B(p9), .Y(new_n209_));
  AND3x1_ASAP7_75t_R   g188(.A(new_n146_), .B(new_n87_), .C(new_n209_), .Y(new_n210_));
  NOR2x1_ASAP7_75t_R   g189(.A(new_n207_), .B(new_n127_), .Y(new_n211_));
  NOR2x1_ASAP7_75t_R   g190(.A(p2), .B(new_n32_), .Y(new_n212_));
  OA21x2_ASAP7_75t_R   g191(.A1(new_n56_), .A2(new_n211_), .B(new_n212_), .Y(new_n213_));
  AOI211x1_ASAP7_75t_R g192(.A1(p9), .A2(new_n208_), .B(new_n210_), .C(new_n213_), .Y(new_n214_));
  OR3x1_ASAP7_75t_R    g193(.A(new_n32_), .B(new_n28_), .C(p4), .Y(new_n215_));
  OR3x1_ASAP7_75t_R    g194(.A(new_n25_), .B(new_n211_), .C(new_n39_), .Y(new_n216_));
  AO21x1_ASAP7_75t_R   g195(.A1(new_n215_), .A2(new_n216_), .B(new_n79_), .Y(new_n217_));
  OR3x1_ASAP7_75t_R    g196(.A(p6), .B(p3), .C(p5), .Y(new_n218_));
  AO21x1_ASAP7_75t_R   g197(.A1(new_n214_), .A2(new_n217_), .B(new_n218_), .Y(new_n219_));
  AND3x1_ASAP7_75t_R   g198(.A(new_n70_), .B(p9), .C(new_n39_), .Y(new_n220_));
  OA21x2_ASAP7_75t_R   g199(.A1(new_n35_), .A2(new_n85_), .B(new_n164_), .Y(new_n221_));
  OR3x1_ASAP7_75t_R    g200(.A(new_n53_), .B(new_n75_), .C(new_n64_), .Y(new_n222_));
  NAND2x1_ASAP7_75t_R  g201(.A(p1), .B(new_n207_), .Y(new_n223_));
  AND3x1_ASAP7_75t_R   g202(.A(new_n221_), .B(new_n222_), .C(new_n223_), .Y(new_n224_));
  AOI211x1_ASAP7_75t_R g203(.A1(new_n58_), .A2(new_n46_), .B(new_n27_), .C(new_n172_), .Y(new_n225_));
  OR3x1_ASAP7_75t_R    g204(.A(new_n225_), .B(p1), .C(new_n87_), .Y(new_n226_));
  OAI21x1_ASAP7_75t_R  g205(.A1(new_n42_), .A2(new_n224_), .B(new_n226_), .Y(new_n227_));
  AO21x1_ASAP7_75t_R   g206(.A1(p6), .A2(new_n127_), .B(new_n23_), .Y(new_n228_));
  AO32x1_ASAP7_75t_R   g207(.A1(new_n228_), .A2(p0), .A3(new_n24_), .B1(new_n34_), .B2(new_n163_), .Y(new_n229_));
  AND3x1_ASAP7_75t_R   g208(.A(new_n229_), .B(new_n32_), .C(new_n178_), .Y(new_n230_));
  AOI21x1_ASAP7_75t_R  g209(.A1(new_n220_), .A2(new_n227_), .B(new_n230_), .Y(new_n231_));
  NAND3x1_ASAP7_75t_R  g210(.A(new_n206_), .B(new_n219_), .C(new_n231_), .Y(o2));
  NOR2x1_ASAP7_75t_R   g211(.A(p5), .B(p4), .Y(new_n233_));
  AO21x1_ASAP7_75t_R   g212(.A1(new_n233_), .A2(new_n127_), .B(new_n107_), .Y(new_n234_));
  AO21x1_ASAP7_75t_R   g213(.A1(new_n187_), .A2(new_n186_), .B(p0), .Y(new_n235_));
  AOI21x1_ASAP7_75t_R  g214(.A1(new_n143_), .A2(new_n134_), .B(p3), .Y(new_n236_));
  OA211x2_ASAP7_75t_R  g215(.A1(new_n146_), .A2(new_n37_), .B(new_n235_), .C(new_n236_), .Y(new_n237_));
  AO221x2_ASAP7_75t_R  g216(.A1(p1), .A2(new_n207_), .B1(new_n54_), .B2(p4), .C(new_n186_), .Y(new_n238_));
  AO32x1_ASAP7_75t_R   g217(.A1(p3), .A2(new_n203_), .A3(new_n234_), .B1(new_n237_), .B2(new_n238_), .Y(new_n239_));
  AO21x1_ASAP7_75t_R   g218(.A1(p4), .A2(p8), .B(p5), .Y(new_n240_));
  INVx1_ASAP7_75t_R    g219(.A(new_n240_), .Y(new_n241_));
  AND2x2_ASAP7_75t_R   g220(.A(p0), .B(p8), .Y(new_n242_));
  OA21x2_ASAP7_75t_R   g221(.A1(new_n242_), .A2(new_n48_), .B(p2), .Y(new_n243_));
  INVx1_ASAP7_75t_R    g222(.A(new_n183_), .Y(new_n244_));
  AO21x1_ASAP7_75t_R   g223(.A1(new_n35_), .A2(new_n64_), .B(new_n92_), .Y(new_n245_));
  AO32x1_ASAP7_75t_R   g224(.A1(p5), .A2(new_n39_), .A3(new_n172_), .B1(new_n244_), .B2(new_n245_), .Y(new_n246_));
  AOI211x1_ASAP7_75t_R g225(.A1(new_n241_), .A2(new_n243_), .B(new_n190_), .C(new_n246_), .Y(new_n247_));
  INVx1_ASAP7_75t_R    g226(.A(new_n48_), .Y(new_n248_));
  AO21x1_ASAP7_75t_R   g227(.A1(p2), .A2(new_n35_), .B(p5), .Y(new_n249_));
  AO32x1_ASAP7_75t_R   g228(.A1(new_n248_), .A2(new_n85_), .A3(new_n182_), .B1(new_n249_), .B2(new_n162_), .Y(new_n250_));
  NOR2x1_ASAP7_75t_R   g229(.A(p1), .B(new_n39_), .Y(new_n251_));
  AO21x1_ASAP7_75t_R   g230(.A1(new_n251_), .A2(new_n211_), .B(new_n244_), .Y(new_n252_));
  OAI21x1_ASAP7_75t_R  g231(.A1(new_n250_), .A2(new_n252_), .B(new_n167_), .Y(new_n253_));
  AO32x1_ASAP7_75t_R   g232(.A1(new_n99_), .A2(new_n168_), .A3(p4), .B1(p5), .B2(new_n177_), .Y(new_n254_));
  NAND2x1_ASAP7_75t_R  g233(.A(new_n34_), .B(new_n254_), .Y(new_n255_));
  OR3x1_ASAP7_75t_R    g234(.A(new_n42_), .B(new_n32_), .C(p5), .Y(new_n256_));
  OR3x1_ASAP7_75t_R    g235(.A(new_n77_), .B(new_n64_), .C(p4), .Y(new_n257_));
  AO21x1_ASAP7_75t_R   g236(.A1(new_n256_), .A2(new_n257_), .B(new_n76_), .Y(new_n258_));
  OR3x1_ASAP7_75t_R    g237(.A(new_n65_), .B(p0), .C(p7), .Y(new_n259_));
  AND3x1_ASAP7_75t_R   g238(.A(new_n255_), .B(new_n258_), .C(new_n259_), .Y(new_n260_));
  NAND3x1_ASAP7_75t_R  g239(.A(new_n247_), .B(new_n253_), .C(new_n260_), .Y(new_n261_));
  AO32x1_ASAP7_75t_R   g240(.A1(new_n239_), .A2(new_n81_), .A3(new_n23_), .B1(new_n261_), .B2(new_n70_), .Y(o3));
  NAND2x1_ASAP7_75t_R  g241(.A(p3), .B(new_n42_), .Y(new_n263_));
  NAND2x1_ASAP7_75t_R  g242(.A(p2), .B(new_n103_), .Y(new_n264_));
  AOI21x1_ASAP7_75t_R  g243(.A1(new_n263_), .A2(new_n264_), .B(new_n113_), .Y(new_n265_));
  AND3x1_ASAP7_75t_R   g244(.A(new_n97_), .B(p1), .C(new_n103_), .Y(new_n266_));
  AND3x1_ASAP7_75t_R   g245(.A(new_n81_), .B(p5), .C(p4), .Y(new_n267_));
  OA21x2_ASAP7_75t_R   g246(.A1(new_n265_), .A2(new_n266_), .B(new_n267_), .Y(o4));
  AND3x1_ASAP7_75t_R   g247(.A(new_n77_), .B(new_n84_), .C(p3), .Y(new_n269_));
  AND3x1_ASAP7_75t_R   g248(.A(new_n113_), .B(p2), .C(new_n103_), .Y(new_n270_));
  OA21x2_ASAP7_75t_R   g249(.A1(new_n269_), .A2(new_n270_), .B(new_n267_), .Y(o5));
  INVx1_ASAP7_75t_R    g250(.A(new_n211_), .Y(new_n272_));
  XNOR2x2_ASAP7_75t_R  g251(.A(p1), .B(p7), .Y(new_n273_));
  NOR2x1_ASAP7_75t_R   g252(.A(p9), .B(new_n53_), .Y(new_n274_));
  AO21x1_ASAP7_75t_R   g253(.A1(new_n28_), .A2(new_n163_), .B(new_n274_), .Y(new_n275_));
  AO32x1_ASAP7_75t_R   g254(.A1(p5), .A2(new_n272_), .A3(new_n273_), .B1(new_n275_), .B2(p4), .Y(new_n276_));
  NAND2x1_ASAP7_75t_R  g255(.A(p1), .B(p4), .Y(new_n277_));
  AO32x1_ASAP7_75t_R   g256(.A1(new_n72_), .A2(new_n277_), .A3(new_n108_), .B1(new_n143_), .B2(p8), .Y(new_n278_));
  NOR2x1_ASAP7_75t_R   g257(.A(p9), .B(new_n32_), .Y(new_n279_));
  AND2x2_ASAP7_75t_R   g258(.A(new_n279_), .B(new_n93_), .Y(new_n280_));
  AO21x1_ASAP7_75t_R   g259(.A1(p1), .A2(new_n93_), .B(p9), .Y(new_n281_));
  OA211x2_ASAP7_75t_R  g260(.A1(new_n278_), .A2(new_n280_), .B(new_n281_), .C(p7), .Y(new_n282_));
  OAI21x1_ASAP7_75t_R  g261(.A1(new_n276_), .A2(new_n282_), .B(new_n42_), .Y(new_n283_));
  NOR2x1_ASAP7_75t_R   g262(.A(p9), .B(p5), .Y(new_n284_));
  INVx1_ASAP7_75t_R    g263(.A(new_n284_), .Y(new_n285_));
  AOI211x1_ASAP7_75t_R g264(.A1(new_n72_), .A2(new_n285_), .B(new_n163_), .C(new_n100_), .Y(new_n286_));
  AO21x1_ASAP7_75t_R   g265(.A1(new_n35_), .A2(new_n28_), .B(p0), .Y(new_n287_));
  AND3x1_ASAP7_75t_R   g266(.A(new_n287_), .B(p9), .C(new_n46_), .Y(new_n288_));
  OA21x2_ASAP7_75t_R   g267(.A1(new_n286_), .A2(new_n288_), .B(new_n39_), .Y(new_n289_));
  INVx1_ASAP7_75t_R    g268(.A(new_n131_), .Y(new_n290_));
  INVx1_ASAP7_75t_R    g269(.A(new_n27_), .Y(new_n291_));
  OAI22x1_ASAP7_75t_R  g270(.A1(new_n291_), .A2(new_n86_), .B1(new_n279_), .B2(new_n36_), .Y(new_n292_));
  AO32x1_ASAP7_75t_R   g271(.A1(new_n91_), .A2(new_n290_), .A3(new_n158_), .B1(new_n292_), .B2(p8), .Y(new_n293_));
  OAI21x1_ASAP7_75t_R  g272(.A1(new_n289_), .A2(new_n293_), .B(p2), .Y(new_n294_));
  AO21x1_ASAP7_75t_R   g273(.A1(new_n29_), .A2(new_n251_), .B(new_n25_), .Y(new_n295_));
  AO21x1_ASAP7_75t_R   g274(.A1(p1), .A2(new_n39_), .B(p5), .Y(new_n296_));
  OA21x2_ASAP7_75t_R   g275(.A1(new_n24_), .A2(new_n296_), .B(new_n37_), .Y(new_n297_));
  NAND2x1_ASAP7_75t_R  g276(.A(p7), .B(new_n23_), .Y(new_n298_));
  AND5x1_ASAP7_75t_R   g277(.A(new_n75_), .B(new_n248_), .C(new_n298_), .D(new_n52_), .E(new_n285_), .Y(new_n299_));
  OA21x2_ASAP7_75t_R   g278(.A1(p7), .A2(p8), .B(p1), .Y(new_n300_));
  AO21x1_ASAP7_75t_R   g279(.A1(p9), .A2(new_n127_), .B(new_n300_), .Y(new_n301_));
  AND2x2_ASAP7_75t_R   g280(.A(p0), .B(p5), .Y(new_n302_));
  AO32x1_ASAP7_75t_R   g281(.A1(new_n75_), .A2(p7), .A3(new_n274_), .B1(new_n301_), .B2(new_n302_), .Y(new_n303_));
  AOI211x1_ASAP7_75t_R g282(.A1(new_n295_), .A2(new_n297_), .B(new_n299_), .C(new_n303_), .Y(new_n304_));
  NAND3x1_ASAP7_75t_R  g283(.A(new_n283_), .B(new_n294_), .C(new_n304_), .Y(new_n305_));
  AO21x1_ASAP7_75t_R   g284(.A1(new_n167_), .A2(new_n127_), .B(new_n207_), .Y(new_n306_));
  AO21x1_ASAP7_75t_R   g285(.A1(p6), .A2(new_n28_), .B(new_n35_), .Y(new_n307_));
  AO22x1_ASAP7_75t_R   g286(.A1(p0), .A2(new_n52_), .B1(new_n33_), .B2(new_n307_), .Y(new_n308_));
  AO32x1_ASAP7_75t_R   g287(.A1(p6), .A2(new_n32_), .A3(new_n306_), .B1(new_n308_), .B2(new_n23_), .Y(new_n309_));
  AND2x2_ASAP7_75t_R   g288(.A(new_n81_), .B(new_n269_), .Y(new_n310_));
  AO221x2_ASAP7_75t_R  g289(.A1(new_n81_), .A2(new_n107_), .B1(new_n309_), .B2(new_n178_), .C(new_n310_), .Y(new_n311_));
  AOI21x1_ASAP7_75t_R  g290(.A1(new_n70_), .A2(new_n305_), .B(new_n311_), .Y(o6));
  AO32x1_ASAP7_75t_R   g291(.A1(p6), .A2(new_n28_), .A3(new_n156_), .B1(new_n211_), .B2(new_n279_), .Y(new_n313_));
  AND3x1_ASAP7_75t_R   g292(.A(new_n313_), .B(new_n177_), .C(new_n168_), .Y(new_n314_));
  OA21x2_ASAP7_75t_R   g293(.A1(new_n81_), .A2(new_n314_), .B(new_n103_), .Y(new_n315_));
  AOI21x1_ASAP7_75t_R  g294(.A1(new_n65_), .A2(new_n201_), .B(new_n28_), .Y(new_n316_));
  NAND2x1_ASAP7_75t_R  g295(.A(new_n298_), .B(new_n201_), .Y(new_n317_));
  AOI21x1_ASAP7_75t_R  g296(.A1(p5), .A2(p8), .B(p7), .Y(new_n318_));
  AOI211x1_ASAP7_75t_R g297(.A1(new_n23_), .A2(p8), .B(new_n284_), .C(new_n318_), .Y(new_n319_));
  AOI22x1_ASAP7_75t_R  g298(.A1(new_n316_), .A2(new_n317_), .B1(new_n65_), .B2(new_n319_), .Y(new_n320_));
  NOR2x1_ASAP7_75t_R   g299(.A(p5), .B(new_n32_), .Y(new_n321_));
  AO21x1_ASAP7_75t_R   g300(.A1(p2), .A2(new_n200_), .B(new_n209_), .Y(new_n322_));
  AO32x1_ASAP7_75t_R   g301(.A1(new_n127_), .A2(new_n42_), .A3(p1), .B1(new_n58_), .B2(new_n108_), .Y(new_n323_));
  AOI21x1_ASAP7_75t_R  g302(.A1(new_n321_), .A2(new_n322_), .B(new_n323_), .Y(new_n324_));
  OAI21x1_ASAP7_75t_R  g303(.A1(p1), .A2(new_n320_), .B(new_n324_), .Y(new_n325_));
  INVx1_ASAP7_75t_R    g304(.A(new_n207_), .Y(new_n326_));
  NAND2x1_ASAP7_75t_R  g305(.A(p5), .B(new_n23_), .Y(new_n327_));
  AOI21x1_ASAP7_75t_R  g306(.A1(new_n200_), .A2(new_n326_), .B(new_n327_), .Y(new_n328_));
  OA221x2_ASAP7_75t_R  g307(.A1(new_n23_), .A2(p8), .B1(new_n108_), .B2(new_n124_), .C(new_n32_), .Y(new_n329_));
  OAI21x1_ASAP7_75t_R  g308(.A1(new_n328_), .A2(new_n329_), .B(new_n142_), .Y(new_n330_));
  OAI21x1_ASAP7_75t_R  g309(.A1(p5), .A2(new_n58_), .B(new_n300_), .Y(new_n331_));
  AND3x1_ASAP7_75t_R   g310(.A(p7), .B(p9), .C(p5), .Y(new_n332_));
  NAND2x1_ASAP7_75t_R  g311(.A(new_n28_), .B(new_n332_), .Y(new_n333_));
  NAND2x1_ASAP7_75t_R  g312(.A(new_n52_), .B(new_n131_), .Y(new_n334_));
  AO31x2_ASAP7_75t_R   g313(.A1(new_n331_), .A2(new_n333_), .A3(new_n334_), .B(p0), .Y(new_n335_));
  INVx1_ASAP7_75t_R    g314(.A(new_n52_), .Y(new_n336_));
  OR3x1_ASAP7_75t_R    g315(.A(new_n336_), .B(new_n201_), .C(new_n42_), .Y(new_n337_));
  NAND3x1_ASAP7_75t_R  g316(.A(new_n330_), .B(new_n335_), .C(new_n337_), .Y(new_n338_));
  AOI21x1_ASAP7_75t_R  g317(.A1(p0), .A2(new_n325_), .B(new_n338_), .Y(new_n339_));
  NAND3x1_ASAP7_75t_R  g318(.A(p7), .B(p4), .C(p8), .Y(new_n340_));
  OAI22x1_ASAP7_75t_R  g319(.A1(new_n223_), .A2(new_n78_), .B1(new_n66_), .B2(new_n340_), .Y(new_n341_));
  OR3x1_ASAP7_75t_R    g320(.A(new_n42_), .B(new_n23_), .C(new_n39_), .Y(new_n342_));
  AOI22x1_ASAP7_75t_R  g321(.A1(new_n211_), .A2(new_n66_), .B1(new_n342_), .B2(new_n277_), .Y(new_n343_));
  OA31x2_ASAP7_75t_R   g322(.A1(p0), .A2(new_n341_), .A3(new_n343_), .B1(new_n64_), .Y(new_n344_));
  AND2x2_ASAP7_75t_R   g323(.A(p2), .B(p1), .Y(new_n345_));
  OR3x1_ASAP7_75t_R    g324(.A(new_n127_), .B(new_n345_), .C(new_n207_), .Y(new_n346_));
  INVx1_ASAP7_75t_R    g325(.A(new_n57_), .Y(new_n347_));
  AND3x1_ASAP7_75t_R   g326(.A(new_n146_), .B(new_n347_), .C(new_n133_), .Y(new_n348_));
  AOI21x1_ASAP7_75t_R  g327(.A1(new_n346_), .A2(new_n348_), .B(new_n341_), .Y(new_n349_));
  OAI21x1_ASAP7_75t_R  g328(.A1(p1), .A2(p8), .B(p9), .Y(new_n350_));
  OAI22x1_ASAP7_75t_R  g329(.A1(new_n54_), .A2(new_n350_), .B1(new_n157_), .B2(p8), .Y(new_n351_));
  AND3x1_ASAP7_75t_R   g330(.A(new_n106_), .B(p1), .C(p8), .Y(new_n352_));
  AO31x2_ASAP7_75t_R   g331(.A1(p1), .A2(p4), .A3(p8), .B(p7), .Y(new_n353_));
  AND2x2_ASAP7_75t_R   g332(.A(new_n42_), .B(new_n353_), .Y(new_n354_));
  OAI21x1_ASAP7_75t_R  g333(.A1(new_n351_), .A2(new_n352_), .B(new_n354_), .Y(new_n355_));
  OAI21x1_ASAP7_75t_R  g334(.A1(new_n32_), .A2(p8), .B(new_n194_), .Y(new_n356_));
  AND3x1_ASAP7_75t_R   g335(.A(new_n251_), .B(p2), .C(new_n200_), .Y(new_n357_));
  AOI21x1_ASAP7_75t_R  g336(.A1(new_n131_), .A2(new_n356_), .B(new_n357_), .Y(new_n358_));
  NAND3x1_ASAP7_75t_R  g337(.A(new_n349_), .B(new_n355_), .C(new_n358_), .Y(new_n359_));
  AOI21x1_ASAP7_75t_R  g338(.A1(new_n344_), .A2(new_n359_), .B(new_n314_), .Y(new_n360_));
  OAI21x1_ASAP7_75t_R  g339(.A1(p4), .A2(new_n339_), .B(new_n360_), .Y(new_n361_));
  AND3x1_ASAP7_75t_R   g340(.A(new_n269_), .B(new_n81_), .C(new_n233_), .Y(new_n362_));
  AOI21x1_ASAP7_75t_R  g341(.A1(new_n315_), .A2(new_n361_), .B(new_n362_), .Y(o7));
  NAND2x1_ASAP7_75t_R  g342(.A(new_n42_), .B(new_n23_), .Y(new_n364_));
  OA211x2_ASAP7_75t_R  g343(.A1(new_n133_), .A2(new_n177_), .B(new_n364_), .C(new_n195_), .Y(new_n365_));
  AND3x1_ASAP7_75t_R   g344(.A(new_n194_), .B(p0), .C(p1), .Y(new_n366_));
  OA21x2_ASAP7_75t_R   g345(.A1(p4), .A2(new_n166_), .B(new_n366_), .Y(new_n367_));
  NOR2x1_ASAP7_75t_R   g346(.A(p4), .B(new_n23_), .Y(new_n368_));
  AND3x1_ASAP7_75t_R   g347(.A(new_n368_), .B(p7), .C(new_n61_), .Y(new_n369_));
  OR3x1_ASAP7_75t_R    g348(.A(new_n365_), .B(new_n367_), .C(new_n369_), .Y(new_n370_));
  NAND3x1_ASAP7_75t_R  g349(.A(new_n142_), .B(new_n195_), .C(new_n157_), .Y(new_n371_));
  NAND2x1_ASAP7_75t_R  g350(.A(new_n66_), .B(new_n182_), .Y(new_n372_));
  OA21x2_ASAP7_75t_R   g351(.A1(new_n32_), .A2(p4), .B(new_n194_), .Y(new_n373_));
  OR3x1_ASAP7_75t_R    g352(.A(new_n372_), .B(new_n75_), .C(new_n373_), .Y(new_n374_));
  AOI21x1_ASAP7_75t_R  g353(.A1(new_n371_), .A2(new_n374_), .B(new_n187_), .Y(new_n375_));
  AOI21x1_ASAP7_75t_R  g354(.A1(new_n108_), .A2(new_n370_), .B(new_n375_), .Y(new_n376_));
  INVx1_ASAP7_75t_R    g355(.A(new_n177_), .Y(new_n377_));
  AOI221x1_ASAP7_75t_R g356(.A1(new_n377_), .A2(new_n89_), .B1(new_n336_), .B2(new_n183_), .C(new_n56_), .Y(new_n378_));
  AND2x2_ASAP7_75t_R   g357(.A(new_n212_), .B(new_n100_), .Y(new_n379_));
  AND3x1_ASAP7_75t_R   g358(.A(new_n133_), .B(new_n23_), .C(new_n52_), .Y(new_n380_));
  AND3x1_ASAP7_75t_R   g359(.A(new_n177_), .B(new_n75_), .C(p1), .Y(new_n381_));
  NOR2x1_ASAP7_75t_R   g360(.A(new_n79_), .B(new_n24_), .Y(new_n382_));
  OR5x1_ASAP7_75t_R    g361(.A(new_n378_), .B(new_n379_), .C(new_n380_), .D(new_n381_), .E(new_n382_), .Y(new_n383_));
  NAND2x1_ASAP7_75t_R  g362(.A(new_n124_), .B(new_n383_), .Y(new_n384_));
  AO21x1_ASAP7_75t_R   g363(.A1(new_n46_), .A2(new_n166_), .B(new_n64_), .Y(new_n385_));
  OA21x2_ASAP7_75t_R   g364(.A1(new_n87_), .A2(new_n385_), .B(new_n32_), .Y(new_n386_));
  AOI211x1_ASAP7_75t_R g365(.A1(p9), .A2(new_n287_), .B(p5), .C(new_n37_), .Y(new_n387_));
  OR3x1_ASAP7_75t_R    g366(.A(new_n386_), .B(new_n387_), .C(new_n162_), .Y(new_n388_));
  NAND3x1_ASAP7_75t_R  g367(.A(new_n376_), .B(new_n384_), .C(new_n388_), .Y(new_n389_));
  AO32x1_ASAP7_75t_R   g368(.A1(new_n34_), .A2(new_n32_), .A3(p7), .B1(new_n54_), .B2(new_n131_), .Y(new_n390_));
  AND3x1_ASAP7_75t_R   g369(.A(new_n273_), .B(new_n23_), .C(new_n28_), .Y(new_n391_));
  AND3x1_ASAP7_75t_R   g370(.A(new_n242_), .B(new_n35_), .C(new_n57_), .Y(new_n392_));
  OR3x1_ASAP7_75t_R    g371(.A(new_n390_), .B(new_n391_), .C(new_n392_), .Y(new_n393_));
  OA211x2_ASAP7_75t_R  g372(.A1(new_n75_), .A2(new_n392_), .B(new_n64_), .C(new_n177_), .Y(new_n394_));
  AO32x1_ASAP7_75t_R   g373(.A1(new_n393_), .A2(new_n103_), .A3(new_n394_), .B1(new_n39_), .B2(new_n310_), .Y(new_n395_));
  AOI21x1_ASAP7_75t_R  g374(.A1(new_n70_), .A2(new_n389_), .B(new_n395_), .Y(o8));
  AO21x1_ASAP7_75t_R   g375(.A1(p7), .A2(p8), .B(p4), .Y(new_n397_));
  AO21x1_ASAP7_75t_R   g376(.A1(p5), .A2(p8), .B(new_n42_), .Y(new_n398_));
  AO21x1_ASAP7_75t_R   g377(.A1(new_n166_), .A2(new_n240_), .B(new_n398_), .Y(new_n399_));
  OA21x2_ASAP7_75t_R   g378(.A1(new_n233_), .A2(new_n263_), .B(new_n32_), .Y(new_n400_));
  AO32x1_ASAP7_75t_R   g379(.A1(new_n212_), .A2(new_n326_), .A3(new_n397_), .B1(new_n399_), .B2(new_n400_), .Y(new_n401_));
  AO21x1_ASAP7_75t_R   g380(.A1(new_n42_), .A2(new_n93_), .B(new_n166_), .Y(new_n402_));
  AND3x1_ASAP7_75t_R   g381(.A(new_n402_), .B(new_n32_), .C(new_n398_), .Y(new_n403_));
  OR3x1_ASAP7_75t_R    g382(.A(new_n241_), .B(p2), .C(new_n124_), .Y(new_n404_));
  OAI21x1_ASAP7_75t_R  g383(.A1(new_n397_), .A2(new_n256_), .B(new_n404_), .Y(new_n405_));
  OA21x2_ASAP7_75t_R   g384(.A1(new_n403_), .A2(new_n405_), .B(p0), .Y(new_n406_));
  AND3x1_ASAP7_75t_R   g385(.A(new_n368_), .B(new_n64_), .C(new_n345_), .Y(new_n407_));
  OA21x2_ASAP7_75t_R   g386(.A1(p6), .A2(new_n407_), .B(new_n287_), .Y(new_n408_));
  AND3x1_ASAP7_75t_R   g387(.A(new_n22_), .B(new_n42_), .C(p9), .Y(new_n409_));
  OA21x2_ASAP7_75t_R   g388(.A1(p4), .A2(new_n212_), .B(p5), .Y(new_n410_));
  AOI21x1_ASAP7_75t_R  g389(.A1(new_n23_), .A2(new_n212_), .B(new_n81_), .Y(new_n411_));
  OR5x1_ASAP7_75t_R    g390(.A(new_n408_), .B(new_n204_), .C(new_n409_), .D(new_n410_), .E(new_n411_), .Y(new_n412_));
  AOI211x1_ASAP7_75t_R g391(.A1(new_n75_), .A2(new_n401_), .B(new_n406_), .C(new_n412_), .Y(o9));
  AO21x1_ASAP7_75t_R   g392(.A1(p0), .A2(new_n24_), .B(new_n35_), .Y(new_n414_));
  AND5x1_ASAP7_75t_R   g393(.A(new_n103_), .B(new_n414_), .C(new_n76_), .D(new_n97_), .E(new_n345_), .Y(new_n415_));
  OA211x2_ASAP7_75t_R  g394(.A1(new_n269_), .A2(new_n415_), .B(new_n81_), .C(new_n233_), .Y(o10));
endmodule


