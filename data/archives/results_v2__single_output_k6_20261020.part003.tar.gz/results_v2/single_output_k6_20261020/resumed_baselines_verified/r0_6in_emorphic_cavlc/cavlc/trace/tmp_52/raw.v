// Benchmark "/tmp/" written by ABC on Tue Oct 20 17:20:41 2026

module \/tmp/  ( 
    p7, p0, p2, p3, p8, p9, p4, p1, p5, p6,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10  );
  input  p7, p0, p2, p3, p8, p9, p4, p1, p5, p6;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10;
  wire new_n22_, new_n23_, new_n24_, new_n25_, new_n26_, new_n27_, new_n28_,
    new_n29_, new_n30_, new_n31_, new_n32_, new_n33_, new_n34_, new_n35_,
    new_n36_, new_n37_, new_n38_, new_n39_, new_n40_, new_n41_, new_n42_,
    new_n43_, new_n44_, new_n45_, new_n46_, new_n47_, new_n48_, new_n49_,
    new_n50_, new_n51_, new_n52_, new_n53_, new_n54_, new_n55_, new_n56_,
    new_n57_, new_n58_, new_n59_, new_n60_, new_n61_, new_n62_, new_n63_,
    new_n64_, new_n65_, new_n66_, new_n67_, new_n68_, new_n69_, new_n70_,
    new_n71_, new_n72_, new_n73_, new_n74_, new_n75_, new_n76_, new_n77_,
    new_n78_, new_n79_, new_n80_, new_n81_, new_n82_, new_n83_, new_n84_,
    new_n85_, new_n86_, new_n87_, new_n88_, new_n89_, new_n90_, new_n91_,
    new_n92_, new_n93_, new_n94_, new_n95_, new_n96_, new_n97_, new_n98_,
    new_n99_, new_n100_, new_n101_, new_n102_, new_n103_, new_n104_,
    new_n105_, new_n106_, new_n107_, new_n108_, new_n109_, new_n110_,
    new_n111_, new_n112_, new_n113_, new_n114_, new_n116_, new_n117_,
    new_n118_, new_n119_, new_n120_, new_n121_, new_n122_, new_n123_,
    new_n124_, new_n125_, new_n126_, new_n127_, new_n128_, new_n129_,
    new_n130_, new_n131_, new_n132_, new_n133_, new_n134_, new_n135_,
    new_n136_, new_n137_, new_n138_, new_n139_, new_n140_, new_n141_,
    new_n142_, new_n143_, new_n144_, new_n145_, new_n146_, new_n147_,
    new_n148_, new_n149_, new_n150_, new_n151_, new_n152_, new_n153_,
    new_n154_, new_n155_, new_n156_, new_n157_, new_n158_, new_n159_,
    new_n160_, new_n161_, new_n162_, new_n163_, new_n164_, new_n165_,
    new_n166_, new_n167_, new_n168_, new_n169_, new_n170_, new_n171_,
    new_n172_, new_n173_, new_n174_, new_n175_, new_n176_, new_n177_,
    new_n178_, new_n179_, new_n180_, new_n181_, new_n182_, new_n184_,
    new_n185_, new_n186_, new_n187_, new_n188_, new_n189_, new_n190_,
    new_n191_, new_n192_, new_n193_, new_n194_, new_n195_, new_n196_,
    new_n197_, new_n198_, new_n199_, new_n200_, new_n201_, new_n202_,
    new_n203_, new_n204_, new_n205_, new_n206_, new_n207_, new_n208_,
    new_n209_, new_n210_, new_n211_, new_n212_, new_n213_, new_n214_,
    new_n215_, new_n216_, new_n217_, new_n218_, new_n219_, new_n220_,
    new_n221_, new_n222_, new_n223_, new_n224_, new_n225_, new_n226_,
    new_n227_, new_n228_, new_n229_, new_n230_, new_n231_, new_n232_,
    new_n234_, new_n235_, new_n236_, new_n237_, new_n238_, new_n239_,
    new_n240_, new_n241_, new_n242_, new_n243_, new_n244_, new_n245_,
    new_n246_, new_n247_, new_n248_, new_n249_, new_n250_, new_n251_,
    new_n252_, new_n253_, new_n254_, new_n255_, new_n256_, new_n257_,
    new_n258_, new_n259_, new_n260_, new_n261_, new_n263_, new_n264_,
    new_n265_, new_n266_, new_n267_, new_n268_, new_n269_, new_n270_,
    new_n272_, new_n273_, new_n275_, new_n276_, new_n277_, new_n278_,
    new_n279_, new_n280_, new_n281_, new_n282_, new_n283_, new_n284_,
    new_n285_, new_n286_, new_n287_, new_n288_, new_n289_, new_n290_,
    new_n291_, new_n292_, new_n293_, new_n294_, new_n295_, new_n296_,
    new_n297_, new_n298_, new_n299_, new_n300_, new_n301_, new_n302_,
    new_n303_, new_n304_, new_n305_, new_n306_, new_n307_, new_n308_,
    new_n309_, new_n310_, new_n311_, new_n312_, new_n314_, new_n315_,
    new_n316_, new_n317_, new_n318_, new_n319_, new_n320_, new_n321_,
    new_n322_, new_n323_, new_n324_, new_n325_, new_n326_, new_n327_,
    new_n328_, new_n329_, new_n330_, new_n331_, new_n332_, new_n333_,
    new_n334_, new_n335_, new_n336_, new_n337_, new_n338_, new_n339_,
    new_n340_, new_n341_, new_n342_, new_n343_, new_n344_, new_n345_,
    new_n346_, new_n347_, new_n348_, new_n349_, new_n350_, new_n351_,
    new_n352_, new_n353_, new_n354_, new_n355_, new_n356_, new_n357_,
    new_n358_, new_n359_, new_n360_, new_n361_, new_n362_, new_n363_,
    new_n365_, new_n366_, new_n367_, new_n368_, new_n369_, new_n370_,
    new_n371_, new_n372_, new_n373_, new_n374_, new_n375_, new_n376_,
    new_n377_, new_n378_, new_n379_, new_n380_, new_n381_, new_n382_,
    new_n383_, new_n384_, new_n385_, new_n386_, new_n387_, new_n388_,
    new_n389_, new_n390_, new_n391_, new_n392_, new_n393_, new_n394_,
    new_n395_, new_n397_, new_n398_, new_n399_, new_n400_, new_n401_,
    new_n402_, new_n403_, new_n404_, new_n405_, new_n406_, new_n407_,
    new_n408_, new_n409_, new_n410_, new_n411_, new_n412_, new_n413_,
    new_n415_, new_n416_;
  INVx1_ASAP7_75t_R    g000(.A(p8), .Y(new_n22_));
  NOR2x1_ASAP7_75t_R   g001(.A(p0), .B(new_n22_), .Y(new_n23_));
  NOR2x1_ASAP7_75t_R   g002(.A(p2), .B(p1), .Y(new_n24_));
  INVx1_ASAP7_75t_R    g003(.A(new_n24_), .Y(new_n25_));
  INVx1_ASAP7_75t_R    g004(.A(p0), .Y(new_n26_));
  NOR2x1_ASAP7_75t_R   g005(.A(p2), .B(new_n26_), .Y(new_n27_));
  NAND2x1_ASAP7_75t_R  g006(.A(p2), .B(p9), .Y(new_n28_));
  NOR2x1_ASAP7_75t_R   g007(.A(p0), .B(new_n28_), .Y(new_n29_));
  AOI211x1_ASAP7_75t_R g008(.A1(new_n23_), .A2(new_n25_), .B(new_n27_), .C(new_n29_), .Y(new_n30_));
  NAND2x1_ASAP7_75t_R  g009(.A(p0), .B(p1), .Y(new_n31_));
  INVx1_ASAP7_75t_R    g010(.A(p4), .Y(new_n32_));
  INVx1_ASAP7_75t_R    g011(.A(p1), .Y(new_n33_));
  AO21x1_ASAP7_75t_R   g012(.A1(new_n32_), .A2(new_n33_), .B(p9), .Y(new_n34_));
  AO21x1_ASAP7_75t_R   g013(.A1(new_n31_), .A2(new_n34_), .B(p8), .Y(new_n35_));
  INVx1_ASAP7_75t_R    g014(.A(p7), .Y(new_n36_));
  INVx1_ASAP7_75t_R    g015(.A(p6), .Y(new_n37_));
  NAND2x1_ASAP7_75t_R  g016(.A(new_n36_), .B(new_n37_), .Y(new_n38_));
  AO21x1_ASAP7_75t_R   g017(.A1(new_n30_), .A2(new_n35_), .B(new_n38_), .Y(new_n39_));
  NOR2x1_ASAP7_75t_R   g018(.A(p4), .B(new_n36_), .Y(new_n40_));
  NOR2x1_ASAP7_75t_R   g019(.A(p8), .B(p4), .Y(new_n41_));
  INVx1_ASAP7_75t_R    g020(.A(p9), .Y(new_n42_));
  NOR2x1_ASAP7_75t_R   g021(.A(p1), .B(new_n42_), .Y(new_n43_));
  OA21x2_ASAP7_75t_R   g022(.A1(new_n37_), .A2(new_n41_), .B(new_n43_), .Y(new_n44_));
  NAND2x1_ASAP7_75t_R  g023(.A(p0), .B(new_n22_), .Y(new_n45_));
  INVx1_ASAP7_75t_R    g024(.A(p2), .Y(new_n46_));
  OA21x2_ASAP7_75t_R   g025(.A1(p6), .A2(new_n45_), .B(new_n46_), .Y(new_n47_));
  OA21x2_ASAP7_75t_R   g026(.A1(new_n40_), .A2(new_n44_), .B(new_n47_), .Y(new_n48_));
  NAND2x1_ASAP7_75t_R  g027(.A(p8), .B(new_n26_), .Y(new_n49_));
  NAND2x1_ASAP7_75t_R  g028(.A(p4), .B(new_n26_), .Y(new_n50_));
  NOR2x1_ASAP7_75t_R   g029(.A(p0), .B(p9), .Y(new_n51_));
  AND3x1_ASAP7_75t_R   g030(.A(new_n51_), .B(new_n22_), .C(p1), .Y(new_n52_));
  AO32x1_ASAP7_75t_R   g031(.A1(new_n49_), .A2(new_n43_), .A3(new_n50_), .B1(new_n52_), .B2(p6), .Y(new_n53_));
  NOR2x1_ASAP7_75t_R   g032(.A(p2), .B(p4), .Y(new_n54_));
  INVx1_ASAP7_75t_R    g033(.A(new_n54_), .Y(new_n55_));
  AND2x2_ASAP7_75t_R   g034(.A(p0), .B(p9), .Y(new_n56_));
  OAI22x1_ASAP7_75t_R  g035(.A1(new_n55_), .A2(new_n56_), .B1(p6), .B2(new_n51_), .Y(new_n57_));
  NOR2x1_ASAP7_75t_R   g036(.A(p7), .B(p1), .Y(new_n58_));
  INVx1_ASAP7_75t_R    g037(.A(new_n58_), .Y(new_n59_));
  NOR2x1_ASAP7_75t_R   g038(.A(p0), .B(p8), .Y(new_n60_));
  AND2x2_ASAP7_75t_R   g039(.A(p0), .B(p8), .Y(new_n61_));
  NOR2x1_ASAP7_75t_R   g040(.A(new_n60_), .B(new_n61_), .Y(new_n62_));
  NOR2x1_ASAP7_75t_R   g041(.A(new_n59_), .B(new_n62_), .Y(new_n63_));
  AOI22x1_ASAP7_75t_R  g042(.A1(new_n48_), .A2(new_n53_), .B1(new_n57_), .B2(new_n63_), .Y(new_n64_));
  NOR2x1_ASAP7_75t_R   g043(.A(p3), .B(p5), .Y(new_n65_));
  INVx1_ASAP7_75t_R    g044(.A(new_n65_), .Y(new_n66_));
  AO21x1_ASAP7_75t_R   g045(.A1(new_n39_), .A2(new_n64_), .B(new_n66_), .Y(new_n67_));
  NAND2x1_ASAP7_75t_R  g046(.A(p8), .B(new_n42_), .Y(new_n68_));
  AO21x1_ASAP7_75t_R   g047(.A1(p9), .A2(new_n22_), .B(p1), .Y(new_n69_));
  AO21x1_ASAP7_75t_R   g048(.A1(new_n68_), .A2(new_n27_), .B(new_n69_), .Y(new_n70_));
  INVx1_ASAP7_75t_R    g049(.A(p5), .Y(new_n71_));
  NAND2x1_ASAP7_75t_R  g050(.A(p7), .B(p4), .Y(new_n72_));
  AOI21x1_ASAP7_75t_R  g051(.A1(new_n71_), .A2(new_n69_), .B(new_n72_), .Y(new_n73_));
  NAND2x1_ASAP7_75t_R  g052(.A(p2), .B(new_n71_), .Y(new_n74_));
  NAND2x1_ASAP7_75t_R  g053(.A(p2), .B(p1), .Y(new_n75_));
  AO32x1_ASAP7_75t_R   g054(.A1(new_n74_), .A2(new_n75_), .A3(new_n60_), .B1(p8), .B2(p1), .Y(new_n76_));
  NOR2x1_ASAP7_75t_R   g055(.A(p7), .B(p4), .Y(new_n77_));
  AOI22x1_ASAP7_75t_R  g056(.A1(new_n70_), .A2(new_n73_), .B1(new_n76_), .B2(new_n77_), .Y(new_n78_));
  NOR2x1_ASAP7_75t_R   g057(.A(p0), .B(p2), .Y(new_n79_));
  AND2x2_ASAP7_75t_R   g058(.A(p8), .B(p1), .Y(new_n80_));
  NOR2x1_ASAP7_75t_R   g059(.A(p7), .B(new_n26_), .Y(new_n81_));
  AOI21x1_ASAP7_75t_R  g060(.A1(new_n79_), .A2(new_n80_), .B(new_n81_), .Y(new_n82_));
  OR3x1_ASAP7_75t_R    g061(.A(new_n82_), .B(p9), .C(p4), .Y(new_n83_));
  NOR2x1_ASAP7_75t_R   g062(.A(p8), .B(p1), .Y(new_n84_));
  AO21x1_ASAP7_75t_R   g063(.A1(p0), .A2(new_n84_), .B(new_n80_), .Y(new_n85_));
  AND2x2_ASAP7_75t_R   g064(.A(p7), .B(p5), .Y(new_n86_));
  AND3x1_ASAP7_75t_R   g065(.A(new_n86_), .B(new_n46_), .C(new_n42_), .Y(new_n87_));
  NOR2x1_ASAP7_75t_R   g066(.A(p7), .B(p8), .Y(new_n88_));
  AND3x1_ASAP7_75t_R   g067(.A(new_n88_), .B(new_n42_), .C(new_n33_), .Y(new_n89_));
  AOI22x1_ASAP7_75t_R  g068(.A1(new_n85_), .A2(new_n87_), .B1(new_n79_), .B2(new_n89_), .Y(new_n90_));
  NAND3x1_ASAP7_75t_R  g069(.A(new_n78_), .B(new_n83_), .C(new_n90_), .Y(new_n91_));
  NAND2x1_ASAP7_75t_R  g070(.A(p9), .B(new_n22_), .Y(new_n92_));
  NOR2x1_ASAP7_75t_R   g071(.A(p0), .B(new_n33_), .Y(new_n93_));
  OAI21x1_ASAP7_75t_R  g072(.A1(new_n93_), .A2(new_n81_), .B(new_n32_), .Y(new_n94_));
  AO21x1_ASAP7_75t_R   g073(.A1(new_n26_), .A2(new_n92_), .B(new_n94_), .Y(new_n95_));
  NOR2x1_ASAP7_75t_R   g074(.A(p9), .B(new_n22_), .Y(new_n96_));
  NOR2x1_ASAP7_75t_R   g075(.A(p0), .B(p1), .Y(new_n97_));
  AO21x1_ASAP7_75t_R   g076(.A1(new_n97_), .A2(new_n96_), .B(p4), .Y(new_n98_));
  AND2x2_ASAP7_75t_R   g077(.A(p4), .B(p1), .Y(new_n99_));
  AND5x1_ASAP7_75t_R   g078(.A(p7), .B(new_n92_), .C(new_n68_), .D(p0), .E(new_n99_), .Y(new_n100_));
  AOI221x1_ASAP7_75t_R g079(.A1(new_n96_), .A2(new_n77_), .B1(new_n86_), .B2(new_n98_), .C(new_n100_), .Y(new_n101_));
  AOI21x1_ASAP7_75t_R  g080(.A1(new_n95_), .A2(new_n101_), .B(new_n46_), .Y(new_n102_));
  NOR2x1_ASAP7_75t_R   g081(.A(p3), .B(p6), .Y(new_n103_));
  OAI21x1_ASAP7_75t_R  g082(.A1(new_n91_), .A2(new_n102_), .B(new_n103_), .Y(new_n104_));
  NOR2x1_ASAP7_75t_R   g083(.A(p9), .B(p1), .Y(new_n105_));
  AND3x1_ASAP7_75t_R   g084(.A(new_n105_), .B(new_n79_), .C(new_n37_), .Y(new_n106_));
  NOR2x1_ASAP7_75t_R   g085(.A(p8), .B(p5), .Y(new_n107_));
  AO21x1_ASAP7_75t_R   g086(.A1(p7), .A2(p3), .B(new_n107_), .Y(new_n108_));
  NAND2x1_ASAP7_75t_R  g087(.A(p7), .B(new_n71_), .Y(new_n109_));
  NOR2x1_ASAP7_75t_R   g088(.A(p7), .B(new_n107_), .Y(new_n110_));
  NAND2x1_ASAP7_75t_R  g089(.A(p4), .B(p5), .Y(new_n111_));
  OA21x2_ASAP7_75t_R   g090(.A1(p3), .A2(new_n22_), .B(new_n111_), .Y(new_n112_));
  AO32x1_ASAP7_75t_R   g091(.A1(new_n108_), .A2(p4), .A3(new_n109_), .B1(new_n110_), .B2(new_n112_), .Y(new_n113_));
  NAND2x1_ASAP7_75t_R  g092(.A(new_n106_), .B(new_n113_), .Y(new_n114_));
  NAND3x1_ASAP7_75t_R  g093(.A(new_n67_), .B(new_n104_), .C(new_n114_), .Y(o0));
  NAND2x1_ASAP7_75t_R  g094(.A(new_n46_), .B(new_n37_), .Y(new_n116_));
  INVx1_ASAP7_75t_R    g095(.A(p3), .Y(new_n117_));
  OAI21x1_ASAP7_75t_R  g096(.A1(new_n36_), .A2(new_n71_), .B(new_n43_), .Y(new_n118_));
  NAND2x1_ASAP7_75t_R  g097(.A(p8), .B(p5), .Y(new_n119_));
  OA21x2_ASAP7_75t_R   g098(.A1(new_n36_), .A2(p4), .B(new_n119_), .Y(new_n120_));
  NAND2x1_ASAP7_75t_R  g099(.A(p4), .B(new_n58_), .Y(new_n121_));
  OAI22x1_ASAP7_75t_R  g100(.A1(new_n118_), .A2(new_n120_), .B1(new_n68_), .B2(new_n121_), .Y(new_n122_));
  NOR2x1_ASAP7_75t_R   g101(.A(p8), .B(new_n26_), .Y(new_n123_));
  AO21x1_ASAP7_75t_R   g102(.A1(p5), .A2(new_n42_), .B(p1), .Y(new_n124_));
  NOR2x1_ASAP7_75t_R   g103(.A(p7), .B(p5), .Y(new_n125_));
  AO21x1_ASAP7_75t_R   g104(.A1(new_n40_), .A2(new_n124_), .B(new_n125_), .Y(new_n126_));
  AOI22x1_ASAP7_75t_R  g105(.A1(new_n122_), .A2(p0), .B1(new_n123_), .B2(new_n126_), .Y(new_n127_));
  AND2x2_ASAP7_75t_R   g106(.A(p7), .B(p8), .Y(new_n128_));
  AO22x1_ASAP7_75t_R   g107(.A1(new_n22_), .A2(new_n77_), .B1(p5), .B2(new_n128_), .Y(new_n129_));
  NOR2x1_ASAP7_75t_R   g108(.A(p9), .B(new_n120_), .Y(new_n130_));
  OAI21x1_ASAP7_75t_R  g109(.A1(new_n129_), .A2(new_n130_), .B(new_n93_), .Y(new_n131_));
  AND3x1_ASAP7_75t_R   g110(.A(p7), .B(p8), .C(p9), .Y(new_n132_));
  AOI21x1_ASAP7_75t_R  g111(.A1(p1), .A2(new_n132_), .B(new_n89_), .Y(new_n133_));
  NAND2x1_ASAP7_75t_R  g112(.A(p7), .B(p1), .Y(new_n134_));
  OR3x1_ASAP7_75t_R    g113(.A(new_n134_), .B(p8), .C(p5), .Y(new_n135_));
  OA21x2_ASAP7_75t_R   g114(.A1(new_n50_), .A2(new_n133_), .B(new_n135_), .Y(new_n136_));
  NAND3x1_ASAP7_75t_R  g115(.A(new_n127_), .B(new_n131_), .C(new_n136_), .Y(new_n137_));
  AND3x1_ASAP7_75t_R   g116(.A(new_n107_), .B(new_n36_), .C(p4), .Y(new_n138_));
  AND3x1_ASAP7_75t_R   g117(.A(new_n107_), .B(p7), .C(p3), .Y(new_n139_));
  AND3x1_ASAP7_75t_R   g118(.A(p3), .B(p8), .C(p5), .Y(new_n140_));
  OR3x1_ASAP7_75t_R    g119(.A(new_n138_), .B(new_n139_), .C(new_n140_), .Y(new_n141_));
  AND3x1_ASAP7_75t_R   g120(.A(new_n141_), .B(new_n42_), .C(new_n97_), .Y(new_n142_));
  AOI21x1_ASAP7_75t_R  g121(.A1(new_n117_), .A2(new_n137_), .B(new_n142_), .Y(new_n143_));
  NOR2x1_ASAP7_75t_R   g122(.A(p7), .B(new_n46_), .Y(new_n144_));
  AOI22x1_ASAP7_75t_R  g123(.A1(new_n144_), .A2(new_n97_), .B1(p0), .B2(p4), .Y(new_n145_));
  OR3x1_ASAP7_75t_R    g124(.A(new_n145_), .B(new_n42_), .C(new_n71_), .Y(new_n146_));
  INVx1_ASAP7_75t_R    g125(.A(new_n81_), .Y(new_n147_));
  NAND3x1_ASAP7_75t_R  g126(.A(p2), .B(p4), .C(p1), .Y(new_n148_));
  NAND2x1_ASAP7_75t_R  g127(.A(p4), .B(p1), .Y(new_n149_));
  AO221x2_ASAP7_75t_R  g128(.A1(new_n149_), .A2(new_n46_), .B1(new_n32_), .B2(new_n31_), .C(new_n71_), .Y(new_n150_));
  OA211x2_ASAP7_75t_R  g129(.A1(new_n147_), .A2(new_n148_), .B(new_n150_), .C(p8), .Y(new_n151_));
  INVx1_ASAP7_75t_R    g130(.A(new_n103_), .Y(new_n152_));
  AOI21x1_ASAP7_75t_R  g131(.A1(new_n146_), .A2(new_n151_), .B(new_n152_), .Y(new_n153_));
  NOR2x1_ASAP7_75t_R   g132(.A(p7), .B(p2), .Y(new_n154_));
  AO21x1_ASAP7_75t_R   g133(.A1(p7), .A2(new_n32_), .B(new_n154_), .Y(new_n155_));
  OAI21x1_ASAP7_75t_R  g134(.A1(new_n42_), .A2(new_n155_), .B(new_n121_), .Y(new_n156_));
  NAND2x1_ASAP7_75t_R  g135(.A(p4), .B(new_n42_), .Y(new_n157_));
  NAND2x1_ASAP7_75t_R  g136(.A(p9), .B(new_n32_), .Y(new_n158_));
  AOI21x1_ASAP7_75t_R  g137(.A1(new_n157_), .A2(new_n158_), .B(new_n26_), .Y(new_n159_));
  AND3x1_ASAP7_75t_R   g138(.A(new_n33_), .B(p7), .C(p9), .Y(new_n160_));
  AO32x1_ASAP7_75t_R   g139(.A1(new_n42_), .A2(new_n59_), .A3(new_n25_), .B1(new_n160_), .B2(p0), .Y(new_n161_));
  AOI211x1_ASAP7_75t_R g140(.A1(new_n26_), .A2(new_n156_), .B(new_n159_), .C(new_n161_), .Y(new_n162_));
  NAND2x1_ASAP7_75t_R  g141(.A(p2), .B(new_n32_), .Y(new_n163_));
  NOR2x1_ASAP7_75t_R   g142(.A(p7), .B(p0), .Y(new_n164_));
  INVx1_ASAP7_75t_R    g143(.A(new_n164_), .Y(new_n165_));
  AND3x1_ASAP7_75t_R   g144(.A(new_n26_), .B(p7), .C(p5), .Y(new_n166_));
  AOI21x1_ASAP7_75t_R  g145(.A1(new_n33_), .A2(new_n165_), .B(new_n166_), .Y(new_n167_));
  NOR2x1_ASAP7_75t_R   g146(.A(p9), .B(new_n36_), .Y(new_n168_));
  NOR2x1_ASAP7_75t_R   g147(.A(p0), .B(p5), .Y(new_n169_));
  OR4x2_ASAP7_75t_R    g148(.A(new_n168_), .B(p1), .C(new_n56_), .D(new_n169_), .Y(new_n170_));
  OA221x2_ASAP7_75t_R  g149(.A1(new_n163_), .A2(new_n167_), .B1(p4), .B2(new_n170_), .C(new_n22_), .Y(new_n171_));
  OAI21x1_ASAP7_75t_R  g150(.A1(p5), .A2(new_n162_), .B(new_n171_), .Y(new_n172_));
  AND3x1_ASAP7_75t_R   g151(.A(new_n54_), .B(new_n117_), .C(new_n71_), .Y(new_n173_));
  AND3x1_ASAP7_75t_R   g152(.A(new_n22_), .B(p7), .C(p0), .Y(new_n174_));
  NOR2x1_ASAP7_75t_R   g153(.A(p1), .B(new_n37_), .Y(new_n175_));
  NOR2x1_ASAP7_75t_R   g154(.A(p8), .B(new_n42_), .Y(new_n176_));
  OR3x1_ASAP7_75t_R    g155(.A(new_n176_), .B(p1), .C(new_n56_), .Y(new_n177_));
  NOR2x1_ASAP7_75t_R   g156(.A(p7), .B(p9), .Y(new_n178_));
  OA211x2_ASAP7_75t_R  g157(.A1(new_n58_), .A2(new_n178_), .B(new_n31_), .C(p6), .Y(new_n179_));
  AO221x2_ASAP7_75t_R  g158(.A1(new_n174_), .A2(new_n175_), .B1(new_n177_), .B2(new_n179_), .C(new_n52_), .Y(new_n180_));
  AND2x2_ASAP7_75t_R   g159(.A(new_n173_), .B(new_n180_), .Y(new_n181_));
  AOI21x1_ASAP7_75t_R  g160(.A1(new_n153_), .A2(new_n172_), .B(new_n181_), .Y(new_n182_));
  OAI21x1_ASAP7_75t_R  g161(.A1(new_n116_), .A2(new_n143_), .B(new_n182_), .Y(o1));
  AND3x1_ASAP7_75t_R   g162(.A(new_n88_), .B(new_n32_), .C(p5), .Y(new_n184_));
  NAND2x1_ASAP7_75t_R  g163(.A(p5), .B(new_n36_), .Y(new_n185_));
  OR3x1_ASAP7_75t_R    g164(.A(new_n26_), .B(new_n22_), .C(p2), .Y(new_n186_));
  OAI21x1_ASAP7_75t_R  g165(.A1(new_n185_), .A2(new_n186_), .B(new_n117_), .Y(new_n187_));
  OA21x2_ASAP7_75t_R   g166(.A1(p8), .A2(new_n46_), .B(new_n71_), .Y(new_n188_));
  OA21x2_ASAP7_75t_R   g167(.A1(new_n123_), .A2(new_n144_), .B(new_n188_), .Y(new_n189_));
  AOI211x1_ASAP7_75t_R g168(.A1(new_n79_), .A2(new_n184_), .B(new_n187_), .C(new_n189_), .Y(new_n190_));
  NAND2x1_ASAP7_75t_R  g169(.A(p2), .B(new_n36_), .Y(new_n191_));
  NAND2x1_ASAP7_75t_R  g170(.A(p2), .B(new_n33_), .Y(new_n192_));
  OA21x2_ASAP7_75t_R   g171(.A1(new_n49_), .A2(new_n191_), .B(new_n192_), .Y(new_n193_));
  OR3x1_ASAP7_75t_R    g172(.A(new_n193_), .B(new_n107_), .C(new_n174_), .Y(new_n194_));
  NAND2x1_ASAP7_75t_R  g173(.A(p2), .B(p4), .Y(new_n195_));
  NOR2x1_ASAP7_75t_R   g174(.A(p1), .B(new_n36_), .Y(new_n196_));
  OA21x2_ASAP7_75t_R   g175(.A1(new_n195_), .A2(new_n196_), .B(new_n123_), .Y(new_n197_));
  AO21x1_ASAP7_75t_R   g176(.A1(p7), .A2(new_n192_), .B(p4), .Y(new_n198_));
  AND3x1_ASAP7_75t_R   g177(.A(new_n59_), .B(new_n25_), .C(p4), .Y(new_n199_));
  AO21x1_ASAP7_75t_R   g178(.A1(p1), .A2(new_n109_), .B(new_n26_), .Y(new_n200_));
  AOI22x1_ASAP7_75t_R  g179(.A1(new_n197_), .A2(new_n198_), .B1(new_n199_), .B2(new_n200_), .Y(new_n201_));
  NAND3x1_ASAP7_75t_R  g180(.A(new_n190_), .B(new_n194_), .C(new_n201_), .Y(new_n202_));
  NOR2x1_ASAP7_75t_R   g181(.A(p7), .B(new_n71_), .Y(new_n203_));
  OA21x2_ASAP7_75t_R   g182(.A1(new_n128_), .A2(new_n203_), .B(new_n32_), .Y(new_n204_));
  OA21x2_ASAP7_75t_R   g183(.A1(p0), .A2(new_n25_), .B(p3), .Y(new_n205_));
  AOI211x1_ASAP7_75t_R g184(.A1(p3), .A2(new_n204_), .B(p9), .C(new_n205_), .Y(new_n206_));
  OR3x1_ASAP7_75t_R    g185(.A(new_n132_), .B(new_n32_), .C(new_n88_), .Y(new_n207_));
  AO21x1_ASAP7_75t_R   g186(.A1(p8), .A2(p1), .B(p4), .Y(new_n208_));
  AND3x1_ASAP7_75t_R   g187(.A(new_n207_), .B(new_n27_), .C(new_n208_), .Y(new_n209_));
  AND2x2_ASAP7_75t_R   g188(.A(p7), .B(p9), .Y(new_n210_));
  AND3x1_ASAP7_75t_R   g189(.A(new_n58_), .B(new_n22_), .C(p9), .Y(new_n211_));
  AO21x1_ASAP7_75t_R   g190(.A1(p2), .A2(new_n26_), .B(new_n32_), .Y(new_n212_));
  AO32x1_ASAP7_75t_R   g191(.A1(new_n23_), .A2(new_n25_), .A3(new_n210_), .B1(new_n211_), .B2(new_n212_), .Y(new_n213_));
  NOR2x1_ASAP7_75t_R   g192(.A(new_n88_), .B(new_n128_), .Y(new_n214_));
  NOR2x1_ASAP7_75t_R   g193(.A(p2), .B(new_n33_), .Y(new_n215_));
  OA21x2_ASAP7_75t_R   g194(.A1(new_n60_), .A2(new_n214_), .B(new_n215_), .Y(new_n216_));
  OR3x1_ASAP7_75t_R    g195(.A(new_n209_), .B(new_n213_), .C(new_n216_), .Y(new_n217_));
  AOI22x1_ASAP7_75t_R  g196(.A1(new_n202_), .A2(new_n206_), .B1(new_n65_), .B2(new_n217_), .Y(new_n218_));
  NOR2x1_ASAP7_75t_R   g197(.A(p8), .B(new_n36_), .Y(new_n219_));
  AO221x2_ASAP7_75t_R  g198(.A1(new_n45_), .A2(new_n154_), .B1(p0), .B2(new_n219_), .C(new_n86_), .Y(new_n220_));
  NOR2x1_ASAP7_75t_R   g199(.A(p8), .B(new_n33_), .Y(new_n221_));
  NOR2x1_ASAP7_75t_R   g200(.A(new_n36_), .B(new_n221_), .Y(new_n222_));
  AND3x1_ASAP7_75t_R   g201(.A(new_n80_), .B(p0), .C(p5), .Y(new_n223_));
  NOR3x1_ASAP7_75t_R   g202(.A(new_n33_), .B(p7), .C(p8), .Y(new_n224_));
  OR4x2_ASAP7_75t_R    g203(.A(new_n222_), .B(new_n223_), .C(new_n166_), .D(new_n224_), .Y(new_n225_));
  AO32x1_ASAP7_75t_R   g204(.A1(new_n33_), .A2(new_n220_), .A3(new_n49_), .B1(new_n225_), .B2(p2), .Y(new_n226_));
  AND3x1_ASAP7_75t_R   g205(.A(new_n103_), .B(p9), .C(new_n32_), .Y(new_n227_));
  AO21x1_ASAP7_75t_R   g206(.A1(p6), .A2(new_n128_), .B(new_n42_), .Y(new_n228_));
  AO32x1_ASAP7_75t_R   g207(.A1(new_n228_), .A2(p0), .A3(new_n68_), .B1(new_n176_), .B2(new_n164_), .Y(new_n229_));
  NOR2x1_ASAP7_75t_R   g208(.A(p4), .B(p5), .Y(new_n230_));
  AND3x1_ASAP7_75t_R   g209(.A(new_n24_), .B(new_n230_), .C(new_n117_), .Y(new_n231_));
  AOI22x1_ASAP7_75t_R  g210(.A1(new_n226_), .A2(new_n227_), .B1(new_n229_), .B2(new_n231_), .Y(new_n232_));
  OAI21x1_ASAP7_75t_R  g211(.A1(p6), .A2(new_n218_), .B(new_n232_), .Y(o2));
  AO32x1_ASAP7_75t_R   g212(.A1(new_n58_), .A2(new_n169_), .A3(p4), .B1(p5), .B2(new_n54_), .Y(new_n234_));
  NAND2x1_ASAP7_75t_R  g213(.A(new_n176_), .B(new_n234_), .Y(new_n235_));
  OR3x1_ASAP7_75t_R    g214(.A(new_n46_), .B(new_n33_), .C(p5), .Y(new_n236_));
  OR3x1_ASAP7_75t_R    g215(.A(new_n24_), .B(p4), .C(new_n71_), .Y(new_n237_));
  AO21x1_ASAP7_75t_R   g216(.A1(new_n236_), .A2(new_n237_), .B(new_n49_), .Y(new_n238_));
  OA211x2_ASAP7_75t_R  g217(.A1(new_n165_), .A2(new_n74_), .B(new_n235_), .C(new_n238_), .Y(new_n239_));
  NOR2x1_ASAP7_75t_R   g218(.A(p1), .B(new_n32_), .Y(new_n240_));
  NOR2x1_ASAP7_75t_R   g219(.A(p1), .B(new_n46_), .Y(new_n241_));
  AO21x1_ASAP7_75t_R   g220(.A1(new_n240_), .A2(new_n214_), .B(new_n241_), .Y(new_n242_));
  OA21x2_ASAP7_75t_R   g221(.A1(p5), .A2(new_n144_), .B(new_n163_), .Y(new_n243_));
  AO21x1_ASAP7_75t_R   g222(.A1(new_n221_), .A2(new_n155_), .B(new_n243_), .Y(new_n244_));
  OAI21x1_ASAP7_75t_R  g223(.A1(new_n242_), .A2(new_n244_), .B(new_n56_), .Y(new_n245_));
  AO21x1_ASAP7_75t_R   g224(.A1(new_n36_), .A2(new_n71_), .B(new_n41_), .Y(new_n246_));
  AO32x1_ASAP7_75t_R   g225(.A1(new_n32_), .A2(p5), .A3(new_n174_), .B1(new_n246_), .B2(new_n241_), .Y(new_n247_));
  INVx1_ASAP7_75t_R    g226(.A(new_n72_), .Y(new_n248_));
  AO21x1_ASAP7_75t_R   g227(.A1(new_n32_), .A2(new_n71_), .B(new_n107_), .Y(new_n249_));
  OA211x2_ASAP7_75t_R  g228(.A1(new_n248_), .A2(new_n61_), .B(new_n249_), .C(p2), .Y(new_n250_));
  AOI211x1_ASAP7_75t_R g229(.A1(new_n26_), .A2(new_n184_), .B(new_n247_), .C(new_n250_), .Y(new_n251_));
  AND3x1_ASAP7_75t_R   g230(.A(new_n239_), .B(new_n245_), .C(new_n251_), .Y(new_n252_));
  AO21x1_ASAP7_75t_R   g231(.A1(p8), .A2(new_n32_), .B(new_n33_), .Y(new_n253_));
  OA21x2_ASAP7_75t_R   g232(.A1(new_n219_), .A2(new_n253_), .B(new_n46_), .Y(new_n254_));
  AO32x1_ASAP7_75t_R   g233(.A1(new_n109_), .A2(p0), .A3(p4), .B1(new_n147_), .B2(new_n24_), .Y(new_n255_));
  AO221x2_ASAP7_75t_R  g234(.A1(new_n26_), .A2(new_n188_), .B1(new_n254_), .B2(new_n71_), .C(new_n255_), .Y(new_n256_));
  NAND2x1_ASAP7_75t_R  g235(.A(p7), .B(p8), .Y(new_n257_));
  INVx1_ASAP7_75t_R    g236(.A(new_n230_), .Y(new_n258_));
  OA211x2_ASAP7_75t_R  g237(.A1(new_n257_), .A2(new_n258_), .B(p3), .C(new_n111_), .Y(new_n259_));
  OR4x2_ASAP7_75t_R    g238(.A(new_n259_), .B(p9), .C(p6), .D(new_n205_), .Y(new_n260_));
  AO21x1_ASAP7_75t_R   g239(.A1(new_n117_), .A2(new_n256_), .B(new_n260_), .Y(new_n261_));
  OAI21x1_ASAP7_75t_R  g240(.A1(new_n152_), .A2(new_n252_), .B(new_n261_), .Y(o3));
  OR3x1_ASAP7_75t_R    g241(.A(new_n51_), .B(p3), .C(new_n33_), .Y(new_n263_));
  NAND2x1_ASAP7_75t_R  g242(.A(p2), .B(new_n117_), .Y(new_n264_));
  NOR2x1_ASAP7_75t_R   g243(.A(p2), .B(new_n117_), .Y(new_n265_));
  INVx1_ASAP7_75t_R    g244(.A(new_n265_), .Y(new_n266_));
  OR3x1_ASAP7_75t_R    g245(.A(p0), .B(p9), .C(p1), .Y(new_n267_));
  AO21x1_ASAP7_75t_R   g246(.A1(new_n264_), .A2(new_n266_), .B(new_n267_), .Y(new_n268_));
  NOR2x1_ASAP7_75t_R   g247(.A(p6), .B(new_n111_), .Y(new_n269_));
  INVx1_ASAP7_75t_R    g248(.A(new_n269_), .Y(new_n270_));
  AOI21x1_ASAP7_75t_R  g249(.A1(new_n263_), .A2(new_n268_), .B(new_n270_), .Y(o4));
  AND3x1_ASAP7_75t_R   g250(.A(new_n51_), .B(new_n24_), .C(p3), .Y(new_n272_));
  AND3x1_ASAP7_75t_R   g251(.A(new_n267_), .B(p2), .C(new_n117_), .Y(new_n273_));
  OA21x2_ASAP7_75t_R   g252(.A1(new_n272_), .A2(new_n273_), .B(new_n269_), .Y(o5));
  NAND2x1_ASAP7_75t_R  g253(.A(new_n134_), .B(new_n59_), .Y(new_n275_));
  NOR2x1_ASAP7_75t_R   g254(.A(new_n71_), .B(new_n214_), .Y(new_n276_));
  NAND2x1_ASAP7_75t_R  g255(.A(new_n275_), .B(new_n276_), .Y(new_n277_));
  AND3x1_ASAP7_75t_R   g256(.A(new_n128_), .B(p0), .C(p9), .Y(new_n278_));
  AO32x1_ASAP7_75t_R   g257(.A1(p8), .A2(new_n42_), .A3(p1), .B1(new_n88_), .B2(new_n26_), .Y(new_n279_));
  OAI21x1_ASAP7_75t_R  g258(.A1(new_n278_), .A2(new_n279_), .B(p4), .Y(new_n280_));
  OR3x1_ASAP7_75t_R    g259(.A(new_n41_), .B(new_n134_), .C(p9), .Y(new_n281_));
  INVx1_ASAP7_75t_R    g260(.A(new_n210_), .Y(new_n282_));
  INVx1_ASAP7_75t_R    g261(.A(new_n31_), .Y(new_n283_));
  OR5x1_ASAP7_75t_R    g262(.A(p8), .B(new_n282_), .C(p5), .D(new_n99_), .E(new_n283_), .Y(new_n284_));
  AND5x1_ASAP7_75t_R   g263(.A(new_n46_), .B(new_n277_), .C(new_n280_), .D(new_n281_), .E(new_n284_), .Y(new_n285_));
  NOR2x1_ASAP7_75t_R   g264(.A(p9), .B(new_n33_), .Y(new_n286_));
  INVx1_ASAP7_75t_R    g265(.A(new_n286_), .Y(new_n287_));
  AO32x1_ASAP7_75t_R   g266(.A1(p9), .A2(p5), .A3(new_n196_), .B1(new_n287_), .B2(new_n81_), .Y(new_n288_));
  NOR2x1_ASAP7_75t_R   g267(.A(p9), .B(p5), .Y(new_n289_));
  AO21x1_ASAP7_75t_R   g268(.A1(new_n289_), .A2(new_n165_), .B(new_n221_), .Y(new_n290_));
  OAI21x1_ASAP7_75t_R  g269(.A1(p0), .A2(new_n88_), .B(p9), .Y(new_n291_));
  NOR2x1_ASAP7_75t_R   g270(.A(new_n123_), .B(new_n291_), .Y(new_n292_));
  AO21x1_ASAP7_75t_R   g271(.A1(new_n62_), .A2(new_n290_), .B(new_n292_), .Y(new_n293_));
  NOR2x1_ASAP7_75t_R   g272(.A(new_n178_), .B(new_n45_), .Y(new_n294_));
  AO21x1_ASAP7_75t_R   g273(.A1(new_n158_), .A2(new_n294_), .B(new_n46_), .Y(new_n295_));
  AOI221x1_ASAP7_75t_R g274(.A1(p8), .A2(new_n288_), .B1(new_n293_), .B2(new_n32_), .C(new_n295_), .Y(new_n296_));
  OA21x2_ASAP7_75t_R   g275(.A1(p7), .A2(p8), .B(p1), .Y(new_n297_));
  OA21x2_ASAP7_75t_R   g276(.A1(new_n132_), .A2(new_n297_), .B(p5), .Y(new_n298_));
  NOR2x1_ASAP7_75t_R   g277(.A(p4), .B(new_n33_), .Y(new_n299_));
  OR3x1_ASAP7_75t_R    g278(.A(new_n299_), .B(new_n68_), .C(p5), .Y(new_n300_));
  OA211x2_ASAP7_75t_R  g279(.A1(new_n96_), .A2(new_n240_), .B(new_n92_), .C(new_n36_), .Y(new_n301_));
  AO21x1_ASAP7_75t_R   g280(.A1(new_n300_), .A2(new_n301_), .B(new_n26_), .Y(new_n302_));
  OA211x2_ASAP7_75t_R  g281(.A1(p9), .A2(new_n203_), .B(new_n84_), .C(new_n72_), .Y(new_n303_));
  NOR2x1_ASAP7_75t_R   g282(.A(new_n134_), .B(new_n68_), .Y(new_n304_));
  OR3x1_ASAP7_75t_R    g283(.A(new_n303_), .B(p0), .C(new_n304_), .Y(new_n305_));
  OAI21x1_ASAP7_75t_R  g284(.A1(new_n298_), .A2(new_n302_), .B(new_n305_), .Y(new_n306_));
  OAI21x1_ASAP7_75t_R  g285(.A1(new_n285_), .A2(new_n296_), .B(new_n306_), .Y(new_n307_));
  AO21x1_ASAP7_75t_R   g286(.A1(p6), .A2(new_n22_), .B(new_n36_), .Y(new_n308_));
  AO22x1_ASAP7_75t_R   g287(.A1(p0), .A2(new_n84_), .B1(new_n93_), .B2(new_n308_), .Y(new_n309_));
  OA21x2_ASAP7_75t_R   g288(.A1(new_n88_), .A2(new_n278_), .B(new_n175_), .Y(new_n310_));
  AO21x1_ASAP7_75t_R   g289(.A1(new_n42_), .A2(new_n309_), .B(new_n310_), .Y(new_n311_));
  AO221x2_ASAP7_75t_R  g290(.A1(p3), .A2(new_n106_), .B1(new_n311_), .B2(new_n173_), .C(new_n269_), .Y(new_n312_));
  AOI21x1_ASAP7_75t_R  g291(.A1(new_n103_), .A2(new_n307_), .B(new_n312_), .Y(o6));
  AND3x1_ASAP7_75t_R   g292(.A(new_n80_), .B(new_n36_), .C(p4), .Y(new_n314_));
  AO21x1_ASAP7_75t_R   g293(.A1(p8), .A2(p1), .B(new_n42_), .Y(new_n315_));
  OAI22x1_ASAP7_75t_R  g294(.A1(new_n315_), .A2(new_n84_), .B1(p8), .B2(new_n157_), .Y(new_n316_));
  OAI21x1_ASAP7_75t_R  g295(.A1(new_n22_), .A2(new_n149_), .B(new_n36_), .Y(new_n317_));
  AND2x2_ASAP7_75t_R   g296(.A(new_n46_), .B(new_n317_), .Y(new_n318_));
  OAI21x1_ASAP7_75t_R  g297(.A1(new_n314_), .A2(new_n316_), .B(new_n318_), .Y(new_n319_));
  AND2x2_ASAP7_75t_R   g298(.A(p2), .B(p1), .Y(new_n320_));
  OR3x1_ASAP7_75t_R    g299(.A(new_n128_), .B(new_n320_), .C(new_n88_), .Y(new_n321_));
  NOR3x1_ASAP7_75t_R   g300(.A(new_n50_), .B(new_n105_), .C(new_n24_), .Y(new_n322_));
  NAND2x1_ASAP7_75t_R  g301(.A(p1), .B(new_n88_), .Y(new_n323_));
  NAND3x1_ASAP7_75t_R  g302(.A(new_n26_), .B(p2), .C(p9), .Y(new_n324_));
  OAI22x1_ASAP7_75t_R  g303(.A1(new_n323_), .A2(new_n324_), .B1(new_n257_), .B2(new_n148_), .Y(new_n325_));
  AOI22x1_ASAP7_75t_R  g304(.A1(new_n22_), .A2(p1), .B1(p2), .B2(p4), .Y(new_n326_));
  INVx1_ASAP7_75t_R    g305(.A(new_n178_), .Y(new_n327_));
  NAND2x1_ASAP7_75t_R  g306(.A(p2), .B(new_n257_), .Y(new_n328_));
  NAND2x1_ASAP7_75t_R  g307(.A(p4), .B(new_n33_), .Y(new_n329_));
  OAI22x1_ASAP7_75t_R  g308(.A1(new_n326_), .A2(new_n327_), .B1(new_n328_), .B2(new_n329_), .Y(new_n330_));
  AOI211x1_ASAP7_75t_R g309(.A1(new_n321_), .A2(new_n322_), .B(new_n325_), .C(new_n330_), .Y(new_n331_));
  AND5x1_ASAP7_75t_R   g310(.A(p7), .B(p2), .C(p8), .D(p4), .E(p1), .Y(new_n332_));
  AOI21x1_ASAP7_75t_R  g311(.A1(new_n224_), .A2(new_n29_), .B(new_n332_), .Y(new_n333_));
  AO22x1_ASAP7_75t_R   g312(.A1(p7), .A2(p8), .B1(p2), .B2(p1), .Y(new_n334_));
  AND3x1_ASAP7_75t_R   g313(.A(p2), .B(p9), .C(p4), .Y(new_n335_));
  OAI22x1_ASAP7_75t_R  g314(.A1(new_n334_), .A2(new_n88_), .B1(new_n99_), .B2(new_n335_), .Y(new_n336_));
  AO31x2_ASAP7_75t_R   g315(.A1(new_n333_), .A2(new_n26_), .A3(new_n336_), .B(p5), .Y(new_n337_));
  AOI21x1_ASAP7_75t_R  g316(.A1(new_n319_), .A2(new_n331_), .B(new_n337_), .Y(new_n338_));
  NOR2x1_ASAP7_75t_R   g317(.A(new_n32_), .B(new_n338_), .Y(new_n339_));
  NAND2x1_ASAP7_75t_R  g318(.A(p7), .B(new_n42_), .Y(new_n340_));
  OAI21x1_ASAP7_75t_R  g319(.A1(new_n340_), .A2(new_n74_), .B(new_n185_), .Y(new_n341_));
  AOI221x1_ASAP7_75t_R g320(.A1(p8), .A2(new_n42_), .B1(new_n119_), .B2(new_n36_), .C(new_n289_), .Y(new_n342_));
  AOI22x1_ASAP7_75t_R  g321(.A1(new_n341_), .A2(p8), .B1(new_n74_), .B2(new_n342_), .Y(new_n343_));
  AO21x1_ASAP7_75t_R   g322(.A1(p2), .A2(new_n257_), .B(new_n210_), .Y(new_n344_));
  NOR2x1_ASAP7_75t_R   g323(.A(p5), .B(new_n33_), .Y(new_n345_));
  AND3x1_ASAP7_75t_R   g324(.A(new_n107_), .B(new_n36_), .C(new_n46_), .Y(new_n346_));
  AOI221x1_ASAP7_75t_R g325(.A1(new_n128_), .A2(new_n215_), .B1(new_n344_), .B2(new_n345_), .C(new_n346_), .Y(new_n347_));
  OAI21x1_ASAP7_75t_R  g326(.A1(p1), .A2(new_n343_), .B(new_n347_), .Y(new_n348_));
  NAND2x1_ASAP7_75t_R  g327(.A(p5), .B(new_n42_), .Y(new_n349_));
  AO21x1_ASAP7_75t_R   g328(.A1(p7), .A2(p8), .B(p5), .Y(new_n350_));
  OAI22x1_ASAP7_75t_R  g329(.A1(new_n214_), .A2(new_n349_), .B1(new_n69_), .B2(new_n350_), .Y(new_n351_));
  NOR2x1_ASAP7_75t_R   g330(.A(p0), .B(new_n46_), .Y(new_n352_));
  NAND2x1_ASAP7_75t_R  g331(.A(new_n105_), .B(new_n88_), .Y(new_n353_));
  OAI21x1_ASAP7_75t_R  g332(.A1(p5), .A2(new_n154_), .B(new_n297_), .Y(new_n354_));
  AOI21x1_ASAP7_75t_R  g333(.A1(new_n353_), .A2(new_n354_), .B(p0), .Y(new_n355_));
  AO32x1_ASAP7_75t_R   g334(.A1(p5), .A2(new_n88_), .A3(new_n241_), .B1(new_n166_), .B2(new_n176_), .Y(new_n356_));
  AO211x2_ASAP7_75t_R  g335(.A1(new_n351_), .A2(new_n352_), .B(new_n355_), .C(new_n356_), .Y(new_n357_));
  AOI211x1_ASAP7_75t_R g336(.A1(p0), .A2(new_n348_), .B(new_n357_), .C(new_n338_), .Y(new_n358_));
  OR5x1_ASAP7_75t_R    g337(.A(p2), .B(new_n267_), .C(new_n117_), .D(p4), .E(p6), .Y(new_n359_));
  AND3x1_ASAP7_75t_R   g338(.A(new_n54_), .B(new_n65_), .C(new_n26_), .Y(new_n360_));
  AO32x1_ASAP7_75t_R   g339(.A1(new_n22_), .A2(p6), .A3(new_n160_), .B1(new_n214_), .B2(new_n286_), .Y(new_n361_));
  NAND2x1_ASAP7_75t_R  g340(.A(new_n360_), .B(new_n361_), .Y(new_n362_));
  OA21x2_ASAP7_75t_R   g341(.A1(p5), .A2(new_n359_), .B(new_n362_), .Y(new_n363_));
  OA31x2_ASAP7_75t_R   g342(.A1(new_n152_), .A2(new_n339_), .A3(new_n358_), .B1(new_n363_), .Y(o7));
  OA211x2_ASAP7_75t_R  g343(.A1(p4), .A2(new_n168_), .B(new_n283_), .C(new_n195_), .Y(new_n365_));
  AO21x1_ASAP7_75t_R   g344(.A1(new_n46_), .A2(new_n42_), .B(p1), .Y(new_n366_));
  AOI211x1_ASAP7_75t_R g345(.A1(new_n50_), .A2(new_n55_), .B(new_n36_), .C(new_n366_), .Y(new_n367_));
  AND5x1_ASAP7_75t_R   g346(.A(p7), .B(new_n26_), .C(new_n46_), .D(new_n32_), .E(p9), .Y(new_n368_));
  OR3x1_ASAP7_75t_R    g347(.A(new_n365_), .B(new_n367_), .C(new_n368_), .Y(new_n369_));
  NOR2x1_ASAP7_75t_R   g348(.A(p5), .B(new_n22_), .Y(new_n370_));
  AO21x1_ASAP7_75t_R   g349(.A1(p2), .A2(p4), .B(new_n299_), .Y(new_n371_));
  AND3x1_ASAP7_75t_R   g350(.A(new_n191_), .B(p0), .C(new_n75_), .Y(new_n372_));
  AO32x1_ASAP7_75t_R   g351(.A1(new_n157_), .A2(new_n352_), .A3(new_n196_), .B1(new_n371_), .B2(new_n372_), .Y(new_n373_));
  AOI22x1_ASAP7_75t_R  g352(.A1(new_n369_), .A2(new_n107_), .B1(new_n370_), .B2(new_n373_), .Y(new_n374_));
  NAND2x1_ASAP7_75t_R  g353(.A(new_n60_), .B(new_n240_), .Y(new_n375_));
  AO21x1_ASAP7_75t_R   g354(.A1(new_n186_), .A2(new_n375_), .B(p9), .Y(new_n376_));
  INVx1_ASAP7_75t_R    g355(.A(new_n84_), .Y(new_n377_));
  AO221x2_ASAP7_75t_R  g356(.A1(new_n377_), .A2(new_n192_), .B1(new_n50_), .B2(new_n55_), .C(new_n60_), .Y(new_n378_));
  NAND2x1_ASAP7_75t_R  g357(.A(new_n26_), .B(new_n32_), .Y(new_n379_));
  INVx1_ASAP7_75t_R    g358(.A(new_n215_), .Y(new_n380_));
  AO21x1_ASAP7_75t_R   g359(.A1(new_n379_), .A2(new_n62_), .B(new_n380_), .Y(new_n381_));
  NAND3x1_ASAP7_75t_R  g360(.A(new_n376_), .B(new_n378_), .C(new_n381_), .Y(new_n382_));
  AO21x1_ASAP7_75t_R   g361(.A1(new_n49_), .A2(new_n340_), .B(new_n123_), .Y(new_n383_));
  AO21x1_ASAP7_75t_R   g362(.A1(p5), .A2(new_n383_), .B(p1), .Y(new_n384_));
  AND3x1_ASAP7_75t_R   g363(.A(new_n147_), .B(new_n71_), .C(new_n291_), .Y(new_n385_));
  NOR2x1_ASAP7_75t_R   g364(.A(new_n163_), .B(new_n385_), .Y(new_n386_));
  AOI22x1_ASAP7_75t_R  g365(.A1(new_n382_), .A2(new_n125_), .B1(new_n384_), .B2(new_n386_), .Y(new_n387_));
  NAND2x1_ASAP7_75t_R  g366(.A(new_n374_), .B(new_n387_), .Y(new_n388_));
  INVx1_ASAP7_75t_R    g367(.A(new_n173_), .Y(new_n389_));
  NOR2x1_ASAP7_75t_R   g368(.A(p8), .B(p9), .Y(new_n390_));
  AO32x1_ASAP7_75t_R   g369(.A1(new_n196_), .A2(new_n22_), .A3(p9), .B1(new_n80_), .B2(new_n178_), .Y(new_n391_));
  AO21x1_ASAP7_75t_R   g370(.A1(new_n390_), .A2(new_n275_), .B(new_n391_), .Y(new_n392_));
  AND3x1_ASAP7_75t_R   g371(.A(new_n61_), .B(new_n42_), .C(new_n58_), .Y(new_n393_));
  AOI21x1_ASAP7_75t_R  g372(.A1(new_n26_), .A2(new_n392_), .B(new_n393_), .Y(new_n394_));
  OAI21x1_ASAP7_75t_R  g373(.A1(new_n389_), .A2(new_n394_), .B(new_n359_), .Y(new_n395_));
  AOI21x1_ASAP7_75t_R  g374(.A1(new_n103_), .A2(new_n388_), .B(new_n395_), .Y(o8));
  AO21x1_ASAP7_75t_R   g375(.A1(p7), .A2(p8), .B(p4), .Y(new_n397_));
  AND3x1_ASAP7_75t_R   g376(.A(new_n297_), .B(new_n46_), .C(new_n397_), .Y(new_n398_));
  AND2x2_ASAP7_75t_R   g377(.A(p2), .B(new_n119_), .Y(new_n399_));
  OAI21x1_ASAP7_75t_R  g378(.A1(new_n340_), .A2(new_n249_), .B(new_n399_), .Y(new_n400_));
  OA211x2_ASAP7_75t_R  g379(.A1(new_n230_), .A2(new_n266_), .B(new_n400_), .C(new_n33_), .Y(new_n401_));
  OAI21x1_ASAP7_75t_R  g380(.A1(new_n398_), .A2(new_n401_), .B(new_n26_), .Y(new_n402_));
  OA21x2_ASAP7_75t_R   g381(.A1(p2), .A2(new_n41_), .B(new_n340_), .Y(new_n403_));
  OR3x1_ASAP7_75t_R    g382(.A(new_n403_), .B(p1), .C(new_n399_), .Y(new_n404_));
  OR3x1_ASAP7_75t_R    g383(.A(new_n249_), .B(p2), .C(new_n125_), .Y(new_n405_));
  OA21x2_ASAP7_75t_R   g384(.A1(new_n236_), .A2(new_n397_), .B(new_n405_), .Y(new_n406_));
  AO21x1_ASAP7_75t_R   g385(.A1(new_n404_), .A2(new_n406_), .B(new_n26_), .Y(new_n407_));
  NOR2x1_ASAP7_75t_R   g386(.A(new_n158_), .B(new_n236_), .Y(new_n408_));
  OAI22x1_ASAP7_75t_R  g387(.A1(new_n408_), .A2(p6), .B1(p0), .B2(new_n88_), .Y(new_n409_));
  NAND2x1_ASAP7_75t_R  g388(.A(new_n79_), .B(new_n43_), .Y(new_n410_));
  OA211x2_ASAP7_75t_R  g389(.A1(new_n71_), .A2(new_n380_), .B(new_n410_), .C(new_n111_), .Y(new_n411_));
  OR3x1_ASAP7_75t_R    g390(.A(new_n33_), .B(p2), .C(p9), .Y(new_n412_));
  AOI21x1_ASAP7_75t_R  g391(.A1(p6), .A2(new_n412_), .B(new_n205_), .Y(new_n413_));
  AND5x1_ASAP7_75t_R   g392(.A(new_n402_), .B(new_n407_), .C(new_n409_), .D(new_n411_), .E(new_n413_), .Y(o9));
  OR5x1_ASAP7_75t_R    g393(.A(new_n23_), .B(new_n152_), .C(new_n258_), .D(new_n51_), .E(new_n75_), .Y(new_n415_));
  OA21x2_ASAP7_75t_R   g394(.A1(new_n26_), .A2(new_n96_), .B(p7), .Y(new_n416_));
  OAI22x1_ASAP7_75t_R  g395(.A1(new_n415_), .A2(new_n416_), .B1(p5), .B2(new_n359_), .Y(o10));
endmodule


