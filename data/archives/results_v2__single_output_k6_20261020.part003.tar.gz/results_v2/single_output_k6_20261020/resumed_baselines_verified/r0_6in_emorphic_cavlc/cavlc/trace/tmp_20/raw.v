// Benchmark "/tmp/" written by ABC on Tue Oct 20 17:20:35 2026

module \/tmp/  ( 
    p3, p8, p0, p7, p1, p9, p5, p2, p6, p4,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10  );
  input  p3, p8, p0, p7, p1, p9, p5, p2, p6, p4;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10;
  wire new_n22_, new_n23_, new_n24_, new_n25_, new_n26_, new_n27_, new_n28_,
    new_n29_, new_n30_, new_n31_, new_n32_, new_n33_, new_n34_, new_n35_,
    new_n36_, new_n37_, new_n38_, new_n39_, new_n40_, new_n41_, new_n42_,
    new_n43_, new_n44_, new_n45_, new_n46_, new_n47_, new_n48_, new_n49_,
    new_n50_, new_n51_, new_n52_, new_n53_, new_n54_, new_n55_, new_n56_,
    new_n57_, new_n58_, new_n59_, new_n60_, new_n61_, new_n62_, new_n63_,
    new_n64_, new_n65_, new_n66_, new_n67_, new_n68_, new_n69_, new_n70_,
    new_n71_, new_n72_, new_n73_, new_n74_, new_n75_, new_n76_, new_n77_,
    new_n78_, new_n79_, new_n80_, new_n81_, new_n82_, new_n83_, new_n84_,
    new_n85_, new_n86_, new_n87_, new_n88_, new_n89_, new_n90_, new_n91_,
    new_n92_, new_n93_, new_n94_, new_n95_, new_n96_, new_n97_, new_n98_,
    new_n99_, new_n100_, new_n101_, new_n102_, new_n103_, new_n104_,
    new_n105_, new_n106_, new_n107_, new_n108_, new_n109_, new_n110_,
    new_n111_, new_n112_, new_n113_, new_n114_, new_n115_, new_n117_,
    new_n118_, new_n119_, new_n120_, new_n121_, new_n122_, new_n123_,
    new_n124_, new_n125_, new_n126_, new_n127_, new_n128_, new_n129_,
    new_n130_, new_n131_, new_n132_, new_n133_, new_n134_, new_n135_,
    new_n136_, new_n137_, new_n138_, new_n139_, new_n140_, new_n141_,
    new_n142_, new_n143_, new_n144_, new_n145_, new_n146_, new_n147_,
    new_n148_, new_n149_, new_n150_, new_n151_, new_n152_, new_n153_,
    new_n154_, new_n155_, new_n156_, new_n157_, new_n158_, new_n159_,
    new_n160_, new_n161_, new_n162_, new_n163_, new_n164_, new_n165_,
    new_n166_, new_n167_, new_n168_, new_n169_, new_n170_, new_n171_,
    new_n172_, new_n173_, new_n174_, new_n175_, new_n176_, new_n177_,
    new_n178_, new_n179_, new_n180_, new_n181_, new_n183_, new_n184_,
    new_n185_, new_n186_, new_n187_, new_n188_, new_n189_, new_n190_,
    new_n191_, new_n192_, new_n193_, new_n194_, new_n195_, new_n196_,
    new_n197_, new_n198_, new_n199_, new_n200_, new_n201_, new_n202_,
    new_n203_, new_n204_, new_n205_, new_n206_, new_n207_, new_n208_,
    new_n209_, new_n210_, new_n211_, new_n212_, new_n213_, new_n214_,
    new_n215_, new_n216_, new_n217_, new_n218_, new_n219_, new_n220_,
    new_n221_, new_n222_, new_n223_, new_n224_, new_n225_, new_n226_,
    new_n227_, new_n228_, new_n229_, new_n230_, new_n231_, new_n232_,
    new_n233_, new_n234_, new_n235_, new_n236_, new_n237_, new_n238_,
    new_n239_, new_n240_, new_n241_, new_n242_, new_n244_, new_n245_,
    new_n246_, new_n247_, new_n248_, new_n249_, new_n250_, new_n251_,
    new_n252_, new_n253_, new_n254_, new_n255_, new_n256_, new_n257_,
    new_n258_, new_n259_, new_n260_, new_n261_, new_n262_, new_n263_,
    new_n264_, new_n265_, new_n266_, new_n267_, new_n268_, new_n269_,
    new_n270_, new_n271_, new_n272_, new_n273_, new_n274_, new_n275_,
    new_n276_, new_n278_, new_n279_, new_n280_, new_n281_, new_n282_,
    new_n284_, new_n285_, new_n287_, new_n288_, new_n289_, new_n290_,
    new_n291_, new_n292_, new_n293_, new_n294_, new_n295_, new_n296_,
    new_n297_, new_n298_, new_n299_, new_n300_, new_n301_, new_n302_,
    new_n303_, new_n304_, new_n305_, new_n306_, new_n307_, new_n308_,
    new_n309_, new_n310_, new_n311_, new_n312_, new_n313_, new_n314_,
    new_n315_, new_n316_, new_n317_, new_n318_, new_n319_, new_n320_,
    new_n321_, new_n322_, new_n323_, new_n324_, new_n325_, new_n326_,
    new_n327_, new_n328_, new_n330_, new_n331_, new_n332_, new_n333_,
    new_n334_, new_n335_, new_n336_, new_n337_, new_n338_, new_n339_,
    new_n340_, new_n341_, new_n342_, new_n343_, new_n344_, new_n345_,
    new_n346_, new_n347_, new_n348_, new_n349_, new_n350_, new_n351_,
    new_n352_, new_n353_, new_n354_, new_n355_, new_n356_, new_n357_,
    new_n358_, new_n359_, new_n360_, new_n361_, new_n362_, new_n363_,
    new_n364_, new_n365_, new_n366_, new_n367_, new_n368_, new_n369_,
    new_n370_, new_n371_, new_n372_, new_n373_, new_n374_, new_n375_,
    new_n377_, new_n378_, new_n379_, new_n380_, new_n381_, new_n382_,
    new_n383_, new_n384_, new_n385_, new_n386_, new_n387_, new_n388_,
    new_n389_, new_n390_, new_n391_, new_n392_, new_n393_, new_n394_,
    new_n395_, new_n396_, new_n397_, new_n398_, new_n399_, new_n400_,
    new_n401_, new_n402_, new_n403_, new_n404_, new_n405_, new_n406_,
    new_n407_, new_n408_, new_n410_, new_n411_, new_n412_, new_n413_,
    new_n414_, new_n415_, new_n416_, new_n417_, new_n418_, new_n419_,
    new_n420_, new_n421_, new_n422_, new_n423_, new_n424_, new_n425_,
    new_n427_, new_n428_;
  INVx1_ASAP7_75t_R    g000(.A(p4), .Y(new_n22_));
  INVx1_ASAP7_75t_R    g001(.A(p0), .Y(new_n23_));
  INVx1_ASAP7_75t_R    g002(.A(p1), .Y(new_n24_));
  INVx1_ASAP7_75t_R    g003(.A(p9), .Y(new_n25_));
  AND3x1_ASAP7_75t_R   g004(.A(new_n23_), .B(new_n24_), .C(new_n25_), .Y(new_n26_));
  INVx1_ASAP7_75t_R    g005(.A(new_n26_), .Y(new_n27_));
  INVx1_ASAP7_75t_R    g006(.A(p8), .Y(new_n28_));
  NAND2x1_ASAP7_75t_R  g007(.A(p7), .B(p5), .Y(new_n29_));
  AO21x1_ASAP7_75t_R   g008(.A1(new_n28_), .A2(new_n22_), .B(new_n29_), .Y(new_n30_));
  AO21x1_ASAP7_75t_R   g009(.A1(new_n22_), .A2(new_n27_), .B(new_n30_), .Y(new_n31_));
  NAND2x1_ASAP7_75t_R  g010(.A(p1), .B(p4), .Y(new_n32_));
  INVx1_ASAP7_75t_R    g011(.A(new_n32_), .Y(new_n33_));
  NAND2x1_ASAP7_75t_R  g012(.A(p9), .B(new_n28_), .Y(new_n34_));
  AND3x1_ASAP7_75t_R   g013(.A(new_n33_), .B(new_n34_), .C(p7), .Y(new_n35_));
  NAND2x1_ASAP7_75t_R  g014(.A(p0), .B(p9), .Y(new_n36_));
  NAND2x1_ASAP7_75t_R  g015(.A(p0), .B(new_n28_), .Y(new_n37_));
  NAND2x1_ASAP7_75t_R  g016(.A(new_n36_), .B(new_n37_), .Y(new_n38_));
  NOR2x1_ASAP7_75t_R   g017(.A(p9), .B(new_n28_), .Y(new_n39_));
  NOR2x1_ASAP7_75t_R   g018(.A(p7), .B(p4), .Y(new_n40_));
  AOI22x1_ASAP7_75t_R  g019(.A1(new_n35_), .A2(new_n38_), .B1(new_n39_), .B2(new_n40_), .Y(new_n41_));
  AO21x1_ASAP7_75t_R   g020(.A1(p9), .A2(new_n28_), .B(p0), .Y(new_n42_));
  NOR2x1_ASAP7_75t_R   g021(.A(p7), .B(new_n23_), .Y(new_n43_));
  NOR2x1_ASAP7_75t_R   g022(.A(p0), .B(new_n24_), .Y(new_n44_));
  OA21x2_ASAP7_75t_R   g023(.A1(new_n43_), .A2(new_n44_), .B(new_n22_), .Y(new_n45_));
  NAND2x1_ASAP7_75t_R  g024(.A(new_n42_), .B(new_n45_), .Y(new_n46_));
  INVx1_ASAP7_75t_R    g025(.A(p2), .Y(new_n47_));
  AO31x2_ASAP7_75t_R   g026(.A1(new_n31_), .A2(new_n41_), .A3(new_n46_), .B(new_n47_), .Y(new_n48_));
  AO221x2_ASAP7_75t_R  g027(.A1(new_n28_), .A2(p9), .B1(new_n38_), .B2(new_n47_), .C(p1), .Y(new_n49_));
  AO21x1_ASAP7_75t_R   g028(.A1(new_n24_), .A2(new_n34_), .B(p5), .Y(new_n50_));
  AND3x1_ASAP7_75t_R   g029(.A(new_n50_), .B(p7), .C(p4), .Y(new_n51_));
  NOR2x1_ASAP7_75t_R   g030(.A(p7), .B(p1), .Y(new_n52_));
  NOR2x1_ASAP7_75t_R   g031(.A(p8), .B(p1), .Y(new_n53_));
  AND2x2_ASAP7_75t_R   g032(.A(p8), .B(p1), .Y(new_n54_));
  AO21x1_ASAP7_75t_R   g033(.A1(p0), .A2(new_n53_), .B(new_n54_), .Y(new_n55_));
  AND2x2_ASAP7_75t_R   g034(.A(p7), .B(p5), .Y(new_n56_));
  AO32x1_ASAP7_75t_R   g035(.A1(new_n28_), .A2(new_n23_), .A3(new_n52_), .B1(new_n55_), .B2(new_n56_), .Y(new_n57_));
  NOR2x1_ASAP7_75t_R   g036(.A(p9), .B(p2), .Y(new_n58_));
  AOI22x1_ASAP7_75t_R  g037(.A1(new_n49_), .A2(new_n51_), .B1(new_n57_), .B2(new_n58_), .Y(new_n59_));
  AND2x2_ASAP7_75t_R   g038(.A(p1), .B(p2), .Y(new_n60_));
  INVx1_ASAP7_75t_R    g039(.A(new_n60_), .Y(new_n61_));
  NOR2x1_ASAP7_75t_R   g040(.A(p8), .B(p0), .Y(new_n62_));
  INVx1_ASAP7_75t_R    g041(.A(p5), .Y(new_n63_));
  NAND2x1_ASAP7_75t_R  g042(.A(p2), .B(new_n63_), .Y(new_n64_));
  AO32x1_ASAP7_75t_R   g043(.A1(new_n61_), .A2(new_n62_), .A3(new_n64_), .B1(p8), .B2(p1), .Y(new_n65_));
  NOR2x1_ASAP7_75t_R   g044(.A(p0), .B(p2), .Y(new_n66_));
  AO21x1_ASAP7_75t_R   g045(.A1(new_n54_), .A2(new_n66_), .B(new_n43_), .Y(new_n67_));
  AND3x1_ASAP7_75t_R   g046(.A(new_n67_), .B(new_n25_), .C(new_n22_), .Y(new_n68_));
  AOI21x1_ASAP7_75t_R  g047(.A1(new_n40_), .A2(new_n65_), .B(new_n68_), .Y(new_n69_));
  AO31x2_ASAP7_75t_R   g048(.A1(new_n48_), .A2(new_n59_), .A3(new_n69_), .B(p6), .Y(new_n70_));
  NOR2x1_ASAP7_75t_R   g049(.A(p3), .B(p5), .Y(new_n71_));
  NOR2x1_ASAP7_75t_R   g050(.A(p9), .B(new_n24_), .Y(new_n72_));
  AO21x1_ASAP7_75t_R   g051(.A1(new_n28_), .A2(new_n22_), .B(p0), .Y(new_n73_));
  NOR2x1_ASAP7_75t_R   g052(.A(p1), .B(new_n25_), .Y(new_n74_));
  AO32x1_ASAP7_75t_R   g053(.A1(p6), .A2(new_n72_), .A3(new_n62_), .B1(new_n73_), .B2(new_n74_), .Y(new_n75_));
  NAND2x1_ASAP7_75t_R  g054(.A(p7), .B(new_n22_), .Y(new_n76_));
  INVx1_ASAP7_75t_R    g055(.A(p6), .Y(new_n77_));
  NOR2x1_ASAP7_75t_R   g056(.A(p8), .B(p4), .Y(new_n78_));
  OAI21x1_ASAP7_75t_R  g057(.A1(new_n77_), .A2(new_n78_), .B(new_n74_), .Y(new_n79_));
  NOR2x1_ASAP7_75t_R   g058(.A(p8), .B(new_n23_), .Y(new_n80_));
  AO21x1_ASAP7_75t_R   g059(.A1(new_n77_), .A2(new_n80_), .B(p2), .Y(new_n81_));
  AOI21x1_ASAP7_75t_R  g060(.A1(new_n76_), .A2(new_n79_), .B(new_n81_), .Y(new_n82_));
  NOR2x1_ASAP7_75t_R   g061(.A(p0), .B(new_n47_), .Y(new_n83_));
  NOR2x1_ASAP7_75t_R   g062(.A(p0), .B(new_n28_), .Y(new_n84_));
  NOR2x1_ASAP7_75t_R   g063(.A(p1), .B(p2), .Y(new_n85_));
  INVx1_ASAP7_75t_R    g064(.A(new_n85_), .Y(new_n86_));
  NOR2x1_ASAP7_75t_R   g065(.A(p2), .B(new_n23_), .Y(new_n87_));
  AOI221x1_ASAP7_75t_R g066(.A1(new_n83_), .A2(p9), .B1(new_n84_), .B2(new_n86_), .C(new_n87_), .Y(new_n88_));
  NAND2x1_ASAP7_75t_R  g067(.A(p0), .B(p1), .Y(new_n89_));
  AO21x1_ASAP7_75t_R   g068(.A1(new_n24_), .A2(new_n22_), .B(p9), .Y(new_n90_));
  AO21x1_ASAP7_75t_R   g069(.A1(new_n89_), .A2(new_n90_), .B(p8), .Y(new_n91_));
  AOI21x1_ASAP7_75t_R  g070(.A1(new_n88_), .A2(new_n91_), .B(p6), .Y(new_n92_));
  INVx1_ASAP7_75t_R    g071(.A(p7), .Y(new_n93_));
  NOR2x1_ASAP7_75t_R   g072(.A(p2), .B(p4), .Y(new_n94_));
  INVx1_ASAP7_75t_R    g073(.A(new_n94_), .Y(new_n95_));
  INVx1_ASAP7_75t_R    g074(.A(new_n36_), .Y(new_n96_));
  NOR2x1_ASAP7_75t_R   g075(.A(p0), .B(p9), .Y(new_n97_));
  OAI22x1_ASAP7_75t_R  g076(.A1(new_n95_), .A2(new_n96_), .B1(p6), .B2(new_n97_), .Y(new_n98_));
  NAND2x1_ASAP7_75t_R  g077(.A(p8), .B(p0), .Y(new_n99_));
  INVx1_ASAP7_75t_R    g078(.A(new_n62_), .Y(new_n100_));
  NAND2x1_ASAP7_75t_R  g079(.A(new_n99_), .B(new_n100_), .Y(new_n101_));
  AND3x1_ASAP7_75t_R   g080(.A(new_n98_), .B(new_n52_), .C(new_n101_), .Y(new_n102_));
  AO221x2_ASAP7_75t_R  g081(.A1(new_n75_), .A2(new_n82_), .B1(new_n92_), .B2(new_n93_), .C(new_n102_), .Y(new_n103_));
  NOR2x1_ASAP7_75t_R   g082(.A(p8), .B(p5), .Y(new_n104_));
  AO21x1_ASAP7_75t_R   g083(.A1(p3), .A2(p7), .B(new_n104_), .Y(new_n105_));
  NOR2x1_ASAP7_75t_R   g084(.A(p5), .B(new_n93_), .Y(new_n106_));
  INVx1_ASAP7_75t_R    g085(.A(new_n106_), .Y(new_n107_));
  AND2x2_ASAP7_75t_R   g086(.A(p3), .B(p8), .Y(new_n108_));
  AO21x1_ASAP7_75t_R   g087(.A1(new_n28_), .A2(p5), .B(new_n108_), .Y(new_n109_));
  NAND2x1_ASAP7_75t_R  g088(.A(p5), .B(p4), .Y(new_n110_));
  AND2x2_ASAP7_75t_R   g089(.A(new_n93_), .B(new_n110_), .Y(new_n111_));
  AO32x1_ASAP7_75t_R   g090(.A1(p4), .A2(new_n105_), .A3(new_n107_), .B1(new_n109_), .B2(new_n111_), .Y(new_n112_));
  NOR2x1_ASAP7_75t_R   g091(.A(p1), .B(p9), .Y(new_n113_));
  AND5x1_ASAP7_75t_R   g092(.A(new_n23_), .B(new_n112_), .C(new_n47_), .D(new_n77_), .E(new_n113_), .Y(new_n114_));
  AOI21x1_ASAP7_75t_R  g093(.A1(new_n71_), .A2(new_n103_), .B(new_n114_), .Y(new_n115_));
  OAI21x1_ASAP7_75t_R  g094(.A1(p3), .A2(new_n70_), .B(new_n115_), .Y(o0));
  NOR2x1_ASAP7_75t_R   g095(.A(p7), .B(p9), .Y(new_n117_));
  OA211x2_ASAP7_75t_R  g096(.A1(new_n52_), .A2(new_n117_), .B(new_n89_), .C(p6), .Y(new_n118_));
  INVx1_ASAP7_75t_R    g097(.A(new_n34_), .Y(new_n119_));
  OR3x1_ASAP7_75t_R    g098(.A(new_n119_), .B(p1), .C(new_n96_), .Y(new_n120_));
  NOR2x1_ASAP7_75t_R   g099(.A(p1), .B(new_n93_), .Y(new_n121_));
  NOR2x1_ASAP7_75t_R   g100(.A(p8), .B(new_n24_), .Y(new_n122_));
  AO32x1_ASAP7_75t_R   g101(.A1(new_n80_), .A2(new_n121_), .A3(p6), .B1(new_n97_), .B2(new_n122_), .Y(new_n123_));
  AOI21x1_ASAP7_75t_R  g102(.A1(new_n118_), .A2(new_n120_), .B(new_n123_), .Y(new_n124_));
  OR3x1_ASAP7_75t_R    g103(.A(p5), .B(p2), .C(p4), .Y(new_n125_));
  OR3x1_ASAP7_75t_R    g104(.A(new_n124_), .B(p3), .C(new_n125_), .Y(new_n126_));
  NOR2x1_ASAP7_75t_R   g105(.A(p0), .B(p5), .Y(new_n127_));
  AO21x1_ASAP7_75t_R   g106(.A1(p0), .A2(p9), .B(new_n127_), .Y(new_n128_));
  AO21x1_ASAP7_75t_R   g107(.A1(p7), .A2(new_n25_), .B(p4), .Y(new_n129_));
  NOR2x1_ASAP7_75t_R   g108(.A(p0), .B(p7), .Y(new_n130_));
  NAND2x1_ASAP7_75t_R  g109(.A(p2), .B(new_n22_), .Y(new_n131_));
  OAI22x1_ASAP7_75t_R  g110(.A1(new_n128_), .A2(new_n129_), .B1(new_n130_), .B2(new_n131_), .Y(new_n132_));
  AOI21x1_ASAP7_75t_R  g111(.A1(p4), .A2(new_n52_), .B(p0), .Y(new_n133_));
  OA21x2_ASAP7_75t_R   g112(.A1(p7), .A2(p2), .B(p9), .Y(new_n134_));
  NAND2x1_ASAP7_75t_R  g113(.A(new_n134_), .B(new_n76_), .Y(new_n135_));
  AOI21x1_ASAP7_75t_R  g114(.A1(new_n133_), .A2(new_n135_), .B(p5), .Y(new_n136_));
  NAND2x1_ASAP7_75t_R  g115(.A(p7), .B(p9), .Y(new_n137_));
  NOR2x1_ASAP7_75t_R   g116(.A(p1), .B(new_n137_), .Y(new_n138_));
  NOR2x1_ASAP7_75t_R   g117(.A(p9), .B(new_n22_), .Y(new_n139_));
  NOR2x1_ASAP7_75t_R   g118(.A(p4), .B(new_n25_), .Y(new_n140_));
  OR4x2_ASAP7_75t_R    g119(.A(new_n138_), .B(new_n23_), .C(new_n139_), .D(new_n140_), .Y(new_n141_));
  AO21x1_ASAP7_75t_R   g120(.A1(p7), .A2(p2), .B(p1), .Y(new_n142_));
  NOR2x1_ASAP7_75t_R   g121(.A(p9), .B(p5), .Y(new_n143_));
  NOR2x1_ASAP7_75t_R   g122(.A(p0), .B(new_n29_), .Y(new_n144_));
  NOR2x1_ASAP7_75t_R   g123(.A(p4), .B(new_n47_), .Y(new_n145_));
  AO221x2_ASAP7_75t_R  g124(.A1(new_n142_), .A2(new_n143_), .B1(new_n144_), .B2(new_n145_), .C(p8), .Y(new_n146_));
  AOI221x1_ASAP7_75t_R g125(.A1(new_n24_), .A2(new_n132_), .B1(new_n136_), .B2(new_n141_), .C(new_n146_), .Y(new_n147_));
  AO22x1_ASAP7_75t_R   g126(.A1(new_n47_), .A2(new_n32_), .B1(new_n22_), .B2(new_n89_), .Y(new_n148_));
  AND3x1_ASAP7_75t_R   g127(.A(p1), .B(p2), .C(p4), .Y(new_n149_));
  AOI21x1_ASAP7_75t_R  g128(.A1(new_n149_), .A2(new_n43_), .B(new_n28_), .Y(new_n150_));
  OAI21x1_ASAP7_75t_R  g129(.A1(new_n63_), .A2(new_n148_), .B(new_n150_), .Y(new_n151_));
  AO32x1_ASAP7_75t_R   g130(.A1(new_n130_), .A2(new_n24_), .A3(p2), .B1(p0), .B2(p4), .Y(new_n152_));
  AND3x1_ASAP7_75t_R   g131(.A(new_n152_), .B(p9), .C(p5), .Y(new_n153_));
  INVx1_ASAP7_75t_R    g132(.A(p3), .Y(new_n154_));
  OAI21x1_ASAP7_75t_R  g133(.A1(new_n151_), .A2(new_n153_), .B(new_n154_), .Y(new_n155_));
  AND3x1_ASAP7_75t_R   g134(.A(new_n104_), .B(new_n93_), .C(p4), .Y(new_n156_));
  AO32x1_ASAP7_75t_R   g135(.A1(p3), .A2(p7), .A3(new_n104_), .B1(new_n108_), .B2(p5), .Y(new_n157_));
  OAI21x1_ASAP7_75t_R  g136(.A1(new_n156_), .A2(new_n157_), .B(new_n26_), .Y(new_n158_));
  OAI22x1_ASAP7_75t_R  g137(.A1(new_n147_), .A2(new_n155_), .B1(p2), .B2(new_n158_), .Y(new_n159_));
  NOR2x1_ASAP7_75t_R   g138(.A(p4), .B(new_n93_), .Y(new_n160_));
  AO21x1_ASAP7_75t_R   g139(.A1(p5), .A2(new_n25_), .B(p1), .Y(new_n161_));
  NOR2x1_ASAP7_75t_R   g140(.A(p7), .B(p5), .Y(new_n162_));
  AO21x1_ASAP7_75t_R   g141(.A1(new_n160_), .A2(new_n161_), .B(new_n162_), .Y(new_n163_));
  NAND3x1_ASAP7_75t_R  g142(.A(new_n29_), .B(new_n24_), .C(p9), .Y(new_n164_));
  AOI22x1_ASAP7_75t_R  g143(.A1(new_n22_), .A2(p7), .B1(p8), .B2(p5), .Y(new_n165_));
  NAND2x1_ASAP7_75t_R  g144(.A(p8), .B(new_n25_), .Y(new_n166_));
  NAND2x1_ASAP7_75t_R  g145(.A(p4), .B(new_n52_), .Y(new_n167_));
  OAI22x1_ASAP7_75t_R  g146(.A1(new_n164_), .A2(new_n165_), .B1(new_n166_), .B2(new_n167_), .Y(new_n168_));
  AOI22x1_ASAP7_75t_R  g147(.A1(new_n163_), .A2(new_n80_), .B1(new_n168_), .B2(p0), .Y(new_n169_));
  NOR2x1_ASAP7_75t_R   g148(.A(new_n78_), .B(new_n56_), .Y(new_n170_));
  NOR2x1_ASAP7_75t_R   g149(.A(p8), .B(new_n93_), .Y(new_n171_));
  OAI22x1_ASAP7_75t_R  g150(.A1(new_n170_), .A2(new_n171_), .B1(p9), .B2(new_n165_), .Y(new_n172_));
  NOR2x1_ASAP7_75t_R   g151(.A(p8), .B(p7), .Y(new_n173_));
  NAND2x1_ASAP7_75t_R  g152(.A(new_n113_), .B(new_n173_), .Y(new_n174_));
  AND2x2_ASAP7_75t_R   g153(.A(p7), .B(p9), .Y(new_n175_));
  NAND2x1_ASAP7_75t_R  g154(.A(new_n54_), .B(new_n175_), .Y(new_n176_));
  NAND2x1_ASAP7_75t_R  g155(.A(p4), .B(new_n23_), .Y(new_n177_));
  AOI21x1_ASAP7_75t_R  g156(.A1(new_n174_), .A2(new_n176_), .B(new_n177_), .Y(new_n178_));
  AOI221x1_ASAP7_75t_R g157(.A1(new_n122_), .A2(new_n106_), .B1(new_n172_), .B2(new_n44_), .C(new_n178_), .Y(new_n179_));
  AOI211x1_ASAP7_75t_R g158(.A1(new_n169_), .A2(new_n179_), .B(p3), .C(p2), .Y(new_n180_));
  OAI21x1_ASAP7_75t_R  g159(.A1(new_n159_), .A2(new_n180_), .B(new_n77_), .Y(new_n181_));
  NAND2x1_ASAP7_75t_R  g160(.A(new_n126_), .B(new_n181_), .Y(o1));
  NOR2x1_ASAP7_75t_R   g161(.A(p7), .B(p2), .Y(new_n183_));
  NAND2x1_ASAP7_75t_R  g162(.A(new_n183_), .B(new_n37_), .Y(new_n184_));
  AND3x1_ASAP7_75t_R   g163(.A(new_n28_), .B(p0), .C(p7), .Y(new_n185_));
  NOR2x1_ASAP7_75t_R   g164(.A(new_n56_), .B(new_n185_), .Y(new_n186_));
  AO21x1_ASAP7_75t_R   g165(.A1(p8), .A2(new_n23_), .B(p1), .Y(new_n187_));
  AO21x1_ASAP7_75t_R   g166(.A1(new_n184_), .A2(new_n186_), .B(new_n187_), .Y(new_n188_));
  INVx1_ASAP7_75t_R    g167(.A(new_n89_), .Y(new_n189_));
  AND2x2_ASAP7_75t_R   g168(.A(p8), .B(p5), .Y(new_n190_));
  AO21x1_ASAP7_75t_R   g169(.A1(new_n189_), .A2(new_n190_), .B(new_n144_), .Y(new_n191_));
  NAND2x1_ASAP7_75t_R  g170(.A(p2), .B(new_n191_), .Y(new_n192_));
  NAND2x1_ASAP7_75t_R  g171(.A(p1), .B(new_n173_), .Y(new_n193_));
  AO21x1_ASAP7_75t_R   g172(.A1(p1), .A2(new_n28_), .B(new_n93_), .Y(new_n194_));
  AO21x1_ASAP7_75t_R   g173(.A1(new_n193_), .A2(new_n194_), .B(new_n47_), .Y(new_n195_));
  OR3x1_ASAP7_75t_R    g174(.A(new_n25_), .B(p3), .C(p4), .Y(new_n196_));
  AO31x2_ASAP7_75t_R   g175(.A1(new_n188_), .A2(new_n192_), .A3(new_n195_), .B(new_n196_), .Y(new_n197_));
  NAND2x1_ASAP7_75t_R  g176(.A(p2), .B(new_n23_), .Y(new_n198_));
  OR3x1_ASAP7_75t_R    g177(.A(p8), .B(p7), .C(p1), .Y(new_n199_));
  AO21x1_ASAP7_75t_R   g178(.A1(p4), .A2(new_n198_), .B(new_n199_), .Y(new_n200_));
  NAND2x1_ASAP7_75t_R  g179(.A(p8), .B(new_n23_), .Y(new_n201_));
  OR3x1_ASAP7_75t_R    g180(.A(new_n201_), .B(new_n85_), .C(new_n137_), .Y(new_n202_));
  OA21x2_ASAP7_75t_R   g181(.A1(new_n25_), .A2(new_n200_), .B(new_n202_), .Y(new_n203_));
  INVx1_ASAP7_75t_R    g182(.A(new_n173_), .Y(new_n204_));
  NAND3x1_ASAP7_75t_R  g183(.A(p8), .B(p7), .C(p9), .Y(new_n205_));
  AND3x1_ASAP7_75t_R   g184(.A(new_n204_), .B(p4), .C(new_n205_), .Y(new_n206_));
  NAND2x1_ASAP7_75t_R  g185(.A(p8), .B(p1), .Y(new_n207_));
  AO21x1_ASAP7_75t_R   g186(.A1(new_n22_), .A2(new_n207_), .B(new_n23_), .Y(new_n208_));
  OR3x1_ASAP7_75t_R    g187(.A(new_n206_), .B(p2), .C(new_n208_), .Y(new_n209_));
  AND2x2_ASAP7_75t_R   g188(.A(p8), .B(p7), .Y(new_n210_));
  NOR2x1_ASAP7_75t_R   g189(.A(new_n173_), .B(new_n210_), .Y(new_n211_));
  NOR2x1_ASAP7_75t_R   g190(.A(p2), .B(new_n24_), .Y(new_n212_));
  OAI21x1_ASAP7_75t_R  g191(.A1(new_n62_), .A2(new_n211_), .B(new_n212_), .Y(new_n213_));
  INVx1_ASAP7_75t_R    g192(.A(new_n71_), .Y(new_n214_));
  AO31x2_ASAP7_75t_R   g193(.A1(new_n203_), .A2(new_n209_), .A3(new_n213_), .B(new_n214_), .Y(new_n215_));
  AOI21x1_ASAP7_75t_R  g194(.A1(new_n197_), .A2(new_n215_), .B(p6), .Y(new_n216_));
  NOR2x1_ASAP7_75t_R   g195(.A(p0), .B(new_n22_), .Y(new_n217_));
  AO21x1_ASAP7_75t_R   g196(.A1(new_n33_), .A2(new_n107_), .B(new_n217_), .Y(new_n218_));
  NOR2x1_ASAP7_75t_R   g197(.A(p1), .B(new_n47_), .Y(new_n219_));
  OAI21x1_ASAP7_75t_R  g198(.A1(new_n93_), .A2(new_n219_), .B(new_n22_), .Y(new_n220_));
  NAND2x1_ASAP7_75t_R  g199(.A(p2), .B(p4), .Y(new_n221_));
  OA21x2_ASAP7_75t_R   g200(.A1(new_n221_), .A2(new_n121_), .B(new_n80_), .Y(new_n222_));
  AOI22x1_ASAP7_75t_R  g201(.A1(new_n218_), .A2(new_n142_), .B1(new_n220_), .B2(new_n222_), .Y(new_n223_));
  NOR2x1_ASAP7_75t_R   g202(.A(p7), .B(new_n47_), .Y(new_n224_));
  AO21x1_ASAP7_75t_R   g203(.A1(new_n84_), .A2(new_n224_), .B(new_n219_), .Y(new_n225_));
  NOR2x1_ASAP7_75t_R   g204(.A(new_n104_), .B(new_n185_), .Y(new_n226_));
  NAND2x1_ASAP7_75t_R  g205(.A(p5), .B(new_n93_), .Y(new_n227_));
  OR3x1_ASAP7_75t_R    g206(.A(new_n28_), .B(new_n23_), .C(p2), .Y(new_n228_));
  OAI21x1_ASAP7_75t_R  g207(.A1(new_n227_), .A2(new_n228_), .B(new_n154_), .Y(new_n229_));
  NAND2x1_ASAP7_75t_R  g208(.A(p2), .B(new_n93_), .Y(new_n230_));
  NAND2x1_ASAP7_75t_R  g209(.A(new_n37_), .B(new_n230_), .Y(new_n231_));
  NAND2x1_ASAP7_75t_R  g210(.A(p2), .B(new_n28_), .Y(new_n232_));
  AND3x1_ASAP7_75t_R   g211(.A(new_n173_), .B(p5), .C(new_n22_), .Y(new_n233_));
  AO32x1_ASAP7_75t_R   g212(.A1(new_n231_), .A2(new_n63_), .A3(new_n232_), .B1(new_n66_), .B2(new_n233_), .Y(new_n234_));
  AOI211x1_ASAP7_75t_R g213(.A1(new_n225_), .A2(new_n226_), .B(new_n229_), .C(new_n234_), .Y(new_n235_));
  OR4x2_ASAP7_75t_R    g214(.A(new_n171_), .B(new_n154_), .C(p4), .D(new_n162_), .Y(new_n236_));
  AO21x1_ASAP7_75t_R   g215(.A1(new_n23_), .A2(new_n85_), .B(new_n154_), .Y(new_n237_));
  NAND3x1_ASAP7_75t_R  g216(.A(new_n236_), .B(new_n25_), .C(new_n237_), .Y(new_n238_));
  AOI211x1_ASAP7_75t_R g217(.A1(new_n223_), .A2(new_n235_), .B(p6), .C(new_n238_), .Y(new_n239_));
  AO21x1_ASAP7_75t_R   g218(.A1(p6), .A2(new_n210_), .B(new_n25_), .Y(new_n240_));
  AO32x1_ASAP7_75t_R   g219(.A1(new_n23_), .A2(new_n93_), .A3(new_n119_), .B1(new_n240_), .B2(new_n38_), .Y(new_n241_));
  AND5x1_ASAP7_75t_R   g220(.A(new_n154_), .B(new_n241_), .C(new_n63_), .D(new_n22_), .E(new_n85_), .Y(new_n242_));
  OR3x1_ASAP7_75t_R    g221(.A(new_n216_), .B(new_n239_), .C(new_n242_), .Y(o2));
  NOR2x1_ASAP7_75t_R   g222(.A(p5), .B(p4), .Y(new_n244_));
  INVx1_ASAP7_75t_R    g223(.A(new_n244_), .Y(new_n245_));
  NAND2x1_ASAP7_75t_R  g224(.A(new_n110_), .B(new_n245_), .Y(new_n246_));
  AO21x1_ASAP7_75t_R   g225(.A1(p8), .A2(p7), .B(p4), .Y(new_n247_));
  AND5x1_ASAP7_75t_R   g226(.A(p3), .B(new_n246_), .C(new_n23_), .D(new_n85_), .E(new_n247_), .Y(new_n248_));
  AND3x1_ASAP7_75t_R   g227(.A(new_n193_), .B(new_n63_), .C(new_n47_), .Y(new_n249_));
  OAI21x1_ASAP7_75t_R  g228(.A1(new_n22_), .A2(new_n207_), .B(new_n249_), .Y(new_n250_));
  NAND3x1_ASAP7_75t_R  g229(.A(new_n232_), .B(new_n23_), .C(new_n63_), .Y(new_n251_));
  OR3x1_ASAP7_75t_R    g230(.A(new_n106_), .B(new_n23_), .C(new_n22_), .Y(new_n252_));
  OR3x1_ASAP7_75t_R    g231(.A(new_n43_), .B(p1), .C(p2), .Y(new_n253_));
  AND5x1_ASAP7_75t_R   g232(.A(new_n250_), .B(new_n154_), .C(new_n251_), .D(new_n252_), .E(new_n253_), .Y(new_n254_));
  OAI21x1_ASAP7_75t_R  g233(.A1(new_n248_), .A2(new_n254_), .B(new_n25_), .Y(new_n255_));
  NAND2x1_ASAP7_75t_R  g234(.A(p4), .B(new_n24_), .Y(new_n256_));
  INVx1_ASAP7_75t_R    g235(.A(new_n256_), .Y(new_n257_));
  AO21x1_ASAP7_75t_R   g236(.A1(new_n211_), .A2(new_n257_), .B(new_n219_), .Y(new_n258_));
  NAND2x1_ASAP7_75t_R  g237(.A(p7), .B(p4), .Y(new_n259_));
  AO21x1_ASAP7_75t_R   g238(.A1(p2), .A2(new_n93_), .B(p5), .Y(new_n260_));
  AO32x1_ASAP7_75t_R   g239(.A1(new_n122_), .A2(new_n259_), .A3(new_n230_), .B1(new_n260_), .B2(new_n131_), .Y(new_n261_));
  OA21x2_ASAP7_75t_R   g240(.A1(new_n258_), .A2(new_n261_), .B(new_n96_), .Y(new_n262_));
  AO32x1_ASAP7_75t_R   g241(.A1(new_n52_), .A2(new_n127_), .A3(p4), .B1(p5), .B2(new_n94_), .Y(new_n263_));
  NAND2x1_ASAP7_75t_R  g242(.A(new_n119_), .B(new_n263_), .Y(new_n264_));
  OR3x1_ASAP7_75t_R    g243(.A(new_n24_), .B(new_n47_), .C(p5), .Y(new_n265_));
  OR3x1_ASAP7_75t_R    g244(.A(new_n85_), .B(new_n63_), .C(p4), .Y(new_n266_));
  AO21x1_ASAP7_75t_R   g245(.A1(new_n265_), .A2(new_n266_), .B(new_n201_), .Y(new_n267_));
  OR3x1_ASAP7_75t_R    g246(.A(new_n64_), .B(p0), .C(p7), .Y(new_n268_));
  AND3x1_ASAP7_75t_R   g247(.A(new_n264_), .B(new_n267_), .C(new_n268_), .Y(new_n269_));
  AO21x1_ASAP7_75t_R   g248(.A1(p8), .A2(p4), .B(p5), .Y(new_n270_));
  AOI21x1_ASAP7_75t_R  g249(.A1(new_n99_), .A2(new_n259_), .B(new_n270_), .Y(new_n271_));
  AO21x1_ASAP7_75t_R   g250(.A1(new_n93_), .A2(new_n63_), .B(new_n78_), .Y(new_n272_));
  AO32x1_ASAP7_75t_R   g251(.A1(p5), .A2(new_n22_), .A3(new_n185_), .B1(new_n272_), .B2(new_n219_), .Y(new_n273_));
  AOI221x1_ASAP7_75t_R g252(.A1(new_n23_), .A2(new_n233_), .B1(p2), .B2(new_n271_), .C(new_n273_), .Y(new_n274_));
  NAND2x1_ASAP7_75t_R  g253(.A(new_n269_), .B(new_n274_), .Y(new_n275_));
  OAI21x1_ASAP7_75t_R  g254(.A1(new_n262_), .A2(new_n275_), .B(new_n154_), .Y(new_n276_));
  AOI21x1_ASAP7_75t_R  g255(.A1(new_n255_), .A2(new_n276_), .B(p6), .Y(o3));
  OA211x2_ASAP7_75t_R  g256(.A1(p0), .A2(p9), .B(new_n154_), .C(p1), .Y(new_n278_));
  NAND2x1_ASAP7_75t_R  g257(.A(p3), .B(new_n47_), .Y(new_n279_));
  NAND2x1_ASAP7_75t_R  g258(.A(p2), .B(new_n154_), .Y(new_n280_));
  AOI21x1_ASAP7_75t_R  g259(.A1(new_n279_), .A2(new_n280_), .B(new_n27_), .Y(new_n281_));
  NOR2x1_ASAP7_75t_R   g260(.A(p6), .B(new_n110_), .Y(new_n282_));
  OA21x2_ASAP7_75t_R   g261(.A1(new_n278_), .A2(new_n281_), .B(new_n282_), .Y(o4));
  AND3x1_ASAP7_75t_R   g262(.A(new_n85_), .B(new_n97_), .C(p3), .Y(new_n284_));
  NOR2x1_ASAP7_75t_R   g263(.A(new_n280_), .B(new_n26_), .Y(new_n285_));
  OA21x2_ASAP7_75t_R   g264(.A1(new_n284_), .A2(new_n285_), .B(new_n282_), .Y(o5));
  AND3x1_ASAP7_75t_R   g265(.A(new_n175_), .B(new_n89_), .C(new_n104_), .Y(new_n287_));
  AO21x1_ASAP7_75t_R   g266(.A1(p8), .A2(new_n25_), .B(new_n32_), .Y(new_n288_));
  OAI21x1_ASAP7_75t_R  g267(.A1(new_n33_), .A2(new_n287_), .B(new_n288_), .Y(new_n289_));
  XOR2x2_ASAP7_75t_R   g268(.A(p7), .B(p1), .Y(new_n290_));
  OR3x1_ASAP7_75t_R    g269(.A(new_n211_), .B(new_n290_), .C(new_n63_), .Y(new_n291_));
  INVx1_ASAP7_75t_R    g270(.A(new_n205_), .Y(new_n292_));
  AND2x2_ASAP7_75t_R   g271(.A(p0), .B(p4), .Y(new_n293_));
  INVx1_ASAP7_75t_R    g272(.A(new_n78_), .Y(new_n294_));
  AND3x1_ASAP7_75t_R   g273(.A(new_n25_), .B(p7), .C(p1), .Y(new_n295_));
  AND3x1_ASAP7_75t_R   g274(.A(new_n173_), .B(new_n23_), .C(p4), .Y(new_n296_));
  AOI221x1_ASAP7_75t_R g275(.A1(new_n292_), .A2(new_n293_), .B1(new_n294_), .B2(new_n295_), .C(new_n296_), .Y(new_n297_));
  NAND3x1_ASAP7_75t_R  g276(.A(new_n289_), .B(new_n291_), .C(new_n297_), .Y(new_n298_));
  AO21x1_ASAP7_75t_R   g277(.A1(p6), .A2(new_n28_), .B(new_n93_), .Y(new_n299_));
  AOI22x1_ASAP7_75t_R  g278(.A1(new_n299_), .A2(new_n44_), .B1(p0), .B2(new_n53_), .Y(new_n300_));
  NAND2x1_ASAP7_75t_R  g279(.A(p6), .B(new_n24_), .Y(new_n301_));
  AO21x1_ASAP7_75t_R   g280(.A1(new_n36_), .A2(new_n204_), .B(new_n301_), .Y(new_n302_));
  OAI22x1_ASAP7_75t_R  g281(.A1(new_n300_), .A2(p9), .B1(new_n211_), .B2(new_n302_), .Y(new_n303_));
  AOI22x1_ASAP7_75t_R  g282(.A1(new_n298_), .A2(new_n77_), .B1(new_n244_), .B2(new_n303_), .Y(new_n304_));
  OAI21x1_ASAP7_75t_R  g283(.A1(p8), .A2(p7), .B(p1), .Y(new_n305_));
  AOI21x1_ASAP7_75t_R  g284(.A1(new_n305_), .A2(new_n205_), .B(new_n63_), .Y(new_n306_));
  OAI21x1_ASAP7_75t_R  g285(.A1(new_n93_), .A2(new_n306_), .B(p0), .Y(new_n307_));
  AO21x1_ASAP7_75t_R   g286(.A1(p1), .A2(new_n22_), .B(p5), .Y(new_n308_));
  NOR2x1_ASAP7_75t_R   g287(.A(new_n256_), .B(new_n39_), .Y(new_n309_));
  AOI221x1_ASAP7_75t_R g288(.A1(new_n39_), .A2(new_n308_), .B1(new_n309_), .B2(new_n34_), .C(new_n306_), .Y(new_n310_));
  NAND2x1_ASAP7_75t_R  g289(.A(new_n25_), .B(new_n63_), .Y(new_n311_));
  NAND2x1_ASAP7_75t_R  g290(.A(p7), .B(new_n25_), .Y(new_n312_));
  AND5x1_ASAP7_75t_R   g291(.A(new_n23_), .B(new_n311_), .C(new_n312_), .D(new_n53_), .E(new_n259_), .Y(new_n313_));
  AOI21x1_ASAP7_75t_R  g292(.A1(new_n84_), .A2(new_n295_), .B(new_n313_), .Y(new_n314_));
  OAI21x1_ASAP7_75t_R  g293(.A1(new_n307_), .A2(new_n310_), .B(new_n314_), .Y(new_n315_));
  NOR2x1_ASAP7_75t_R   g294(.A(new_n37_), .B(new_n140_), .Y(new_n316_));
  INVx1_ASAP7_75t_R    g295(.A(new_n117_), .Y(new_n317_));
  NOR3x1_ASAP7_75t_R   g296(.A(new_n72_), .B(p7), .C(new_n99_), .Y(new_n318_));
  AOI221x1_ASAP7_75t_R g297(.A1(new_n138_), .A2(new_n190_), .B1(new_n316_), .B2(new_n317_), .C(new_n318_), .Y(new_n319_));
  OAI22x1_ASAP7_75t_R  g298(.A1(new_n311_), .A2(new_n130_), .B1(p8), .B2(new_n24_), .Y(new_n320_));
  INVx1_ASAP7_75t_R    g299(.A(new_n99_), .Y(new_n321_));
  NOR2x1_ASAP7_75t_R   g300(.A(new_n62_), .B(new_n321_), .Y(new_n322_));
  OA21x2_ASAP7_75t_R   g301(.A1(p0), .A2(new_n173_), .B(p9), .Y(new_n323_));
  AOI22x1_ASAP7_75t_R  g302(.A1(new_n320_), .A2(new_n322_), .B1(new_n37_), .B2(new_n323_), .Y(new_n324_));
  OAI22x1_ASAP7_75t_R  g303(.A1(new_n319_), .A2(new_n47_), .B1(new_n324_), .B2(new_n131_), .Y(new_n325_));
  OAI21x1_ASAP7_75t_R  g304(.A1(new_n315_), .A2(new_n325_), .B(new_n77_), .Y(new_n326_));
  OAI21x1_ASAP7_75t_R  g305(.A1(p2), .A2(new_n304_), .B(new_n326_), .Y(new_n327_));
  AO21x1_ASAP7_75t_R   g306(.A1(new_n77_), .A2(new_n284_), .B(new_n282_), .Y(new_n328_));
  AOI21x1_ASAP7_75t_R  g307(.A1(new_n154_), .A2(new_n327_), .B(new_n328_), .Y(o6));
  AO32x1_ASAP7_75t_R   g308(.A1(new_n28_), .A2(p6), .A3(new_n138_), .B1(new_n211_), .B2(new_n72_), .Y(new_n330_));
  AND3x1_ASAP7_75t_R   g309(.A(new_n330_), .B(new_n66_), .C(new_n244_), .Y(new_n331_));
  OA21x2_ASAP7_75t_R   g310(.A1(new_n77_), .A2(new_n331_), .B(new_n154_), .Y(new_n332_));
  AOI21x1_ASAP7_75t_R  g311(.A1(new_n64_), .A2(new_n227_), .B(new_n28_), .Y(new_n333_));
  NAND2x1_ASAP7_75t_R  g312(.A(new_n312_), .B(new_n227_), .Y(new_n334_));
  AOI21x1_ASAP7_75t_R  g313(.A1(p8), .A2(p5), .B(p7), .Y(new_n335_));
  AOI211x1_ASAP7_75t_R g314(.A1(p8), .A2(new_n25_), .B(new_n143_), .C(new_n335_), .Y(new_n336_));
  AOI22x1_ASAP7_75t_R  g315(.A1(new_n333_), .A2(new_n334_), .B1(new_n64_), .B2(new_n336_), .Y(new_n337_));
  NAND2x1_ASAP7_75t_R  g316(.A(p8), .B(p7), .Y(new_n338_));
  AO21x1_ASAP7_75t_R   g317(.A1(p2), .A2(new_n338_), .B(new_n175_), .Y(new_n339_));
  NOR2x1_ASAP7_75t_R   g318(.A(p5), .B(new_n24_), .Y(new_n340_));
  AND3x1_ASAP7_75t_R   g319(.A(new_n104_), .B(new_n93_), .C(new_n47_), .Y(new_n341_));
  AOI221x1_ASAP7_75t_R g320(.A1(new_n210_), .A2(new_n212_), .B1(new_n339_), .B2(new_n340_), .C(new_n341_), .Y(new_n342_));
  OAI21x1_ASAP7_75t_R  g321(.A1(p1), .A2(new_n337_), .B(new_n342_), .Y(new_n343_));
  NAND2x1_ASAP7_75t_R  g322(.A(p5), .B(new_n25_), .Y(new_n344_));
  AOI21x1_ASAP7_75t_R  g323(.A1(new_n338_), .A2(new_n204_), .B(new_n344_), .Y(new_n345_));
  OA221x2_ASAP7_75t_R  g324(.A1(p8), .A2(new_n25_), .B1(new_n104_), .B2(new_n162_), .C(new_n24_), .Y(new_n346_));
  OAI21x1_ASAP7_75t_R  g325(.A1(new_n345_), .A2(new_n346_), .B(new_n83_), .Y(new_n347_));
  OR5x1_ASAP7_75t_R    g326(.A(p8), .B(new_n63_), .C(new_n47_), .D(p7), .E(p1), .Y(new_n348_));
  OA21x2_ASAP7_75t_R   g327(.A1(p8), .A2(p7), .B(p1), .Y(new_n349_));
  OAI21x1_ASAP7_75t_R  g328(.A1(p5), .A2(new_n183_), .B(new_n349_), .Y(new_n350_));
  OR3x1_ASAP7_75t_R    g329(.A(new_n137_), .B(p8), .C(new_n63_), .Y(new_n351_));
  AO31x2_ASAP7_75t_R   g330(.A1(new_n350_), .A2(new_n351_), .A3(new_n174_), .B(p0), .Y(new_n352_));
  NAND3x1_ASAP7_75t_R  g331(.A(new_n347_), .B(new_n348_), .C(new_n352_), .Y(new_n353_));
  AOI21x1_ASAP7_75t_R  g332(.A1(p0), .A2(new_n343_), .B(new_n353_), .Y(new_n354_));
  NAND3x1_ASAP7_75t_R  g333(.A(new_n23_), .B(p9), .C(p2), .Y(new_n355_));
  NAND2x1_ASAP7_75t_R  g334(.A(new_n210_), .B(new_n149_), .Y(new_n356_));
  OAI21x1_ASAP7_75t_R  g335(.A1(new_n355_), .A2(new_n193_), .B(new_n356_), .Y(new_n357_));
  OR3x1_ASAP7_75t_R    g336(.A(new_n25_), .B(new_n47_), .C(new_n22_), .Y(new_n358_));
  AOI22x1_ASAP7_75t_R  g337(.A1(new_n211_), .A2(new_n61_), .B1(new_n358_), .B2(new_n32_), .Y(new_n359_));
  OA31x2_ASAP7_75t_R   g338(.A1(p0), .A2(new_n357_), .A3(new_n359_), .B1(new_n63_), .Y(new_n360_));
  NOR2x1_ASAP7_75t_R   g339(.A(p8), .B(p9), .Y(new_n361_));
  OAI21x1_ASAP7_75t_R  g340(.A1(new_n93_), .A2(new_n361_), .B(p4), .Y(new_n362_));
  OR3x1_ASAP7_75t_R    g341(.A(new_n54_), .B(new_n25_), .C(new_n53_), .Y(new_n363_));
  OR3x1_ASAP7_75t_R    g342(.A(new_n52_), .B(new_n173_), .C(p2), .Y(new_n364_));
  AO21x1_ASAP7_75t_R   g343(.A1(new_n362_), .A2(new_n363_), .B(new_n364_), .Y(new_n365_));
  OR3x1_ASAP7_75t_R    g344(.A(new_n210_), .B(new_n60_), .C(new_n173_), .Y(new_n366_));
  NOR3x1_ASAP7_75t_R   g345(.A(new_n177_), .B(new_n85_), .C(new_n113_), .Y(new_n367_));
  AOI22x1_ASAP7_75t_R  g346(.A1(new_n28_), .A2(p1), .B1(p2), .B2(p4), .Y(new_n368_));
  NAND2x1_ASAP7_75t_R  g347(.A(p2), .B(new_n338_), .Y(new_n369_));
  OAI22x1_ASAP7_75t_R  g348(.A1(new_n368_), .A2(new_n317_), .B1(new_n369_), .B2(new_n256_), .Y(new_n370_));
  AOI211x1_ASAP7_75t_R g349(.A1(new_n366_), .A2(new_n367_), .B(new_n370_), .C(new_n357_), .Y(new_n371_));
  NAND2x1_ASAP7_75t_R  g350(.A(new_n365_), .B(new_n371_), .Y(new_n372_));
  AOI21x1_ASAP7_75t_R  g351(.A1(new_n360_), .A2(new_n372_), .B(new_n331_), .Y(new_n373_));
  OAI21x1_ASAP7_75t_R  g352(.A1(p4), .A2(new_n354_), .B(new_n373_), .Y(new_n374_));
  AND3x1_ASAP7_75t_R   g353(.A(new_n284_), .B(new_n77_), .C(new_n244_), .Y(new_n375_));
  AOI21x1_ASAP7_75t_R  g354(.A1(new_n332_), .A2(new_n374_), .B(new_n375_), .Y(o7));
  OR3x1_ASAP7_75t_R    g355(.A(new_n317_), .B(p1), .C(new_n99_), .Y(new_n377_));
  INVx1_ASAP7_75t_R    g356(.A(new_n361_), .Y(new_n378_));
  AOI22x1_ASAP7_75t_R  g357(.A1(new_n54_), .A2(new_n117_), .B1(new_n175_), .B2(new_n53_), .Y(new_n379_));
  OA21x2_ASAP7_75t_R   g358(.A1(new_n378_), .A2(new_n290_), .B(new_n379_), .Y(new_n380_));
  AO21x1_ASAP7_75t_R   g359(.A1(p0), .A2(new_n377_), .B(new_n125_), .Y(new_n381_));
  AOI21x1_ASAP7_75t_R  g360(.A1(new_n377_), .A2(new_n380_), .B(new_n381_), .Y(new_n382_));
  OA21x2_ASAP7_75t_R   g361(.A1(new_n77_), .A2(new_n382_), .B(new_n154_), .Y(new_n383_));
  NAND2x1_ASAP7_75t_R  g362(.A(new_n53_), .B(new_n217_), .Y(new_n384_));
  AOI21x1_ASAP7_75t_R  g363(.A1(new_n228_), .A2(new_n384_), .B(p9), .Y(new_n385_));
  AO21x1_ASAP7_75t_R   g364(.A1(new_n23_), .A2(p4), .B(new_n94_), .Y(new_n386_));
  AO21x1_ASAP7_75t_R   g365(.A1(new_n24_), .A2(p2), .B(new_n53_), .Y(new_n387_));
  AND3x1_ASAP7_75t_R   g366(.A(new_n386_), .B(new_n387_), .C(new_n100_), .Y(new_n388_));
  AND3x1_ASAP7_75t_R   g367(.A(new_n66_), .B(p1), .C(new_n22_), .Y(new_n389_));
  AO21x1_ASAP7_75t_R   g368(.A1(new_n212_), .A2(new_n101_), .B(new_n389_), .Y(new_n390_));
  OA31x2_ASAP7_75t_R   g369(.A1(new_n385_), .A2(new_n388_), .A3(new_n390_), .B1(new_n162_), .Y(new_n391_));
  AND3x1_ASAP7_75t_R   g370(.A(new_n175_), .B(new_n22_), .C(new_n66_), .Y(new_n392_));
  AND3x1_ASAP7_75t_R   g371(.A(new_n129_), .B(new_n189_), .C(new_n221_), .Y(new_n393_));
  INVx1_ASAP7_75t_R    g372(.A(new_n58_), .Y(new_n394_));
  AND3x1_ASAP7_75t_R   g373(.A(new_n386_), .B(new_n394_), .C(new_n121_), .Y(new_n395_));
  OA31x2_ASAP7_75t_R   g374(.A1(new_n392_), .A2(new_n393_), .A3(new_n395_), .B1(new_n104_), .Y(new_n396_));
  OR4x2_ASAP7_75t_R    g375(.A(new_n139_), .B(new_n198_), .C(new_n93_), .D(p1), .Y(new_n397_));
  OA21x2_ASAP7_75t_R   g376(.A1(new_n24_), .A2(p4), .B(new_n221_), .Y(new_n398_));
  OR4x2_ASAP7_75t_R    g377(.A(new_n398_), .B(new_n23_), .C(new_n60_), .D(new_n224_), .Y(new_n399_));
  NAND2x1_ASAP7_75t_R  g378(.A(p8), .B(new_n63_), .Y(new_n400_));
  AOI21x1_ASAP7_75t_R  g379(.A1(new_n397_), .A2(new_n399_), .B(new_n400_), .Y(new_n401_));
  NOR2x1_ASAP7_75t_R   g380(.A(new_n43_), .B(new_n323_), .Y(new_n402_));
  INVx1_ASAP7_75t_R    g381(.A(new_n312_), .Y(new_n403_));
  AO21x1_ASAP7_75t_R   g382(.A1(p8), .A2(new_n23_), .B(new_n63_), .Y(new_n404_));
  AO21x1_ASAP7_75t_R   g383(.A1(new_n37_), .A2(new_n403_), .B(new_n404_), .Y(new_n405_));
  AOI221x1_ASAP7_75t_R g384(.A1(new_n63_), .A2(new_n402_), .B1(new_n405_), .B2(new_n24_), .C(new_n131_), .Y(new_n406_));
  OR5x1_ASAP7_75t_R    g385(.A(new_n391_), .B(new_n382_), .C(new_n396_), .D(new_n401_), .E(new_n406_), .Y(new_n407_));
  AND3x1_ASAP7_75t_R   g386(.A(new_n284_), .B(new_n77_), .C(new_n22_), .Y(new_n408_));
  AOI21x1_ASAP7_75t_R  g387(.A1(new_n383_), .A2(new_n407_), .B(new_n408_), .Y(o8));
  AO32x1_ASAP7_75t_R   g388(.A1(p7), .A2(new_n25_), .A3(new_n270_), .B1(new_n64_), .B2(new_n232_), .Y(new_n410_));
  OA21x2_ASAP7_75t_R   g389(.A1(new_n244_), .A2(new_n279_), .B(new_n24_), .Y(new_n411_));
  AO32x1_ASAP7_75t_R   g390(.A1(new_n204_), .A2(new_n212_), .A3(new_n247_), .B1(new_n410_), .B2(new_n411_), .Y(new_n412_));
  NAND2x1_ASAP7_75t_R  g391(.A(new_n23_), .B(new_n412_), .Y(new_n413_));
  OR4x2_ASAP7_75t_R    g392(.A(new_n104_), .B(new_n162_), .C(new_n244_), .D(p2), .Y(new_n414_));
  OA21x2_ASAP7_75t_R   g393(.A1(new_n247_), .A2(new_n265_), .B(new_n414_), .Y(new_n415_));
  AND3x1_ASAP7_75t_R   g394(.A(new_n64_), .B(new_n232_), .C(new_n24_), .Y(new_n416_));
  AO21x1_ASAP7_75t_R   g395(.A1(new_n47_), .A2(new_n294_), .B(new_n403_), .Y(new_n417_));
  NAND2x1_ASAP7_75t_R  g396(.A(new_n416_), .B(new_n417_), .Y(new_n418_));
  AO21x1_ASAP7_75t_R   g397(.A1(new_n415_), .A2(new_n418_), .B(new_n23_), .Y(new_n419_));
  OR3x1_ASAP7_75t_R    g398(.A(new_n265_), .B(new_n25_), .C(p4), .Y(new_n420_));
  AO22x1_ASAP7_75t_R   g399(.A1(new_n23_), .A2(new_n204_), .B1(new_n77_), .B2(new_n420_), .Y(new_n421_));
  OR3x1_ASAP7_75t_R    g400(.A(new_n86_), .B(p0), .C(new_n25_), .Y(new_n422_));
  OAI21x1_ASAP7_75t_R  g401(.A1(p4), .A2(new_n212_), .B(p5), .Y(new_n423_));
  AO21x1_ASAP7_75t_R   g402(.A1(new_n25_), .A2(new_n212_), .B(new_n77_), .Y(new_n424_));
  AND3x1_ASAP7_75t_R   g403(.A(new_n422_), .B(new_n423_), .C(new_n424_), .Y(new_n425_));
  AND5x1_ASAP7_75t_R   g404(.A(new_n237_), .B(new_n413_), .C(new_n419_), .D(new_n421_), .E(new_n425_), .Y(o9));
  AND3x1_ASAP7_75t_R   g405(.A(new_n42_), .B(new_n154_), .C(new_n60_), .Y(new_n427_));
  OA21x2_ASAP7_75t_R   g406(.A1(new_n93_), .A2(new_n38_), .B(new_n427_), .Y(new_n428_));
  AO32x1_ASAP7_75t_R   g407(.A1(new_n428_), .A2(new_n77_), .A3(new_n244_), .B1(new_n63_), .B2(new_n408_), .Y(o10));
endmodule


