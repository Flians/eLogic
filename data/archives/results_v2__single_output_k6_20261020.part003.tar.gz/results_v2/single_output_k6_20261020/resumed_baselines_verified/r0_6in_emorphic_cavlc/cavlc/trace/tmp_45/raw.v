// Benchmark "/tmp/" written by ABC on Tue Oct 20 17:20:39 2026

module \/tmp/  ( 
    p6, p3, p7, p8, p4, p5, p0, p9, p1, p2,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10  );
  input  p6, p3, p7, p8, p4, p5, p0, p9, p1, p2;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10;
  wire new_n22_, new_n23_, new_n24_, new_n25_, new_n26_, new_n27_, new_n28_,
    new_n29_, new_n30_, new_n31_, new_n32_, new_n33_, new_n34_, new_n35_,
    new_n36_, new_n37_, new_n38_, new_n39_, new_n40_, new_n41_, new_n42_,
    new_n43_, new_n44_, new_n45_, new_n46_, new_n47_, new_n48_, new_n49_,
    new_n50_, new_n51_, new_n52_, new_n53_, new_n54_, new_n55_, new_n56_,
    new_n57_, new_n58_, new_n59_, new_n60_, new_n61_, new_n62_, new_n63_,
    new_n64_, new_n65_, new_n66_, new_n67_, new_n68_, new_n69_, new_n70_,
    new_n71_, new_n72_, new_n73_, new_n74_, new_n75_, new_n76_, new_n77_,
    new_n78_, new_n79_, new_n80_, new_n81_, new_n82_, new_n83_, new_n84_,
    new_n85_, new_n86_, new_n87_, new_n88_, new_n89_, new_n90_, new_n91_,
    new_n92_, new_n93_, new_n94_, new_n95_, new_n96_, new_n97_, new_n98_,
    new_n99_, new_n100_, new_n101_, new_n102_, new_n103_, new_n104_,
    new_n105_, new_n106_, new_n107_, new_n108_, new_n109_, new_n110_,
    new_n111_, new_n113_, new_n114_, new_n115_, new_n116_, new_n117_,
    new_n118_, new_n119_, new_n120_, new_n121_, new_n122_, new_n123_,
    new_n124_, new_n125_, new_n126_, new_n127_, new_n128_, new_n129_,
    new_n130_, new_n131_, new_n132_, new_n133_, new_n134_, new_n135_,
    new_n136_, new_n137_, new_n138_, new_n139_, new_n140_, new_n141_,
    new_n142_, new_n143_, new_n144_, new_n145_, new_n146_, new_n147_,
    new_n148_, new_n149_, new_n150_, new_n151_, new_n152_, new_n153_,
    new_n154_, new_n155_, new_n156_, new_n157_, new_n158_, new_n159_,
    new_n160_, new_n161_, new_n162_, new_n163_, new_n164_, new_n165_,
    new_n166_, new_n167_, new_n168_, new_n169_, new_n170_, new_n171_,
    new_n172_, new_n173_, new_n174_, new_n175_, new_n176_, new_n177_,
    new_n178_, new_n179_, new_n180_, new_n181_, new_n182_, new_n183_,
    new_n185_, new_n186_, new_n187_, new_n188_, new_n189_, new_n190_,
    new_n191_, new_n192_, new_n193_, new_n194_, new_n195_, new_n196_,
    new_n197_, new_n198_, new_n199_, new_n200_, new_n201_, new_n202_,
    new_n203_, new_n204_, new_n205_, new_n206_, new_n207_, new_n208_,
    new_n209_, new_n210_, new_n211_, new_n212_, new_n213_, new_n214_,
    new_n215_, new_n216_, new_n217_, new_n218_, new_n219_, new_n220_,
    new_n221_, new_n222_, new_n223_, new_n224_, new_n225_, new_n226_,
    new_n227_, new_n228_, new_n229_, new_n230_, new_n231_, new_n232_,
    new_n233_, new_n234_, new_n235_, new_n236_, new_n237_, new_n238_,
    new_n240_, new_n241_, new_n242_, new_n243_, new_n244_, new_n245_,
    new_n246_, new_n247_, new_n248_, new_n249_, new_n250_, new_n251_,
    new_n252_, new_n253_, new_n254_, new_n255_, new_n256_, new_n257_,
    new_n258_, new_n259_, new_n260_, new_n261_, new_n262_, new_n263_,
    new_n264_, new_n265_, new_n266_, new_n267_, new_n268_, new_n269_,
    new_n270_, new_n272_, new_n273_, new_n274_, new_n275_, new_n276_,
    new_n278_, new_n279_, new_n280_, new_n282_, new_n283_, new_n284_,
    new_n285_, new_n286_, new_n287_, new_n288_, new_n289_, new_n290_,
    new_n291_, new_n292_, new_n293_, new_n294_, new_n295_, new_n296_,
    new_n297_, new_n298_, new_n299_, new_n300_, new_n301_, new_n302_,
    new_n303_, new_n304_, new_n305_, new_n306_, new_n307_, new_n308_,
    new_n309_, new_n310_, new_n311_, new_n312_, new_n313_, new_n314_,
    new_n315_, new_n316_, new_n317_, new_n318_, new_n319_, new_n320_,
    new_n322_, new_n323_, new_n324_, new_n325_, new_n326_, new_n327_,
    new_n328_, new_n329_, new_n330_, new_n331_, new_n332_, new_n333_,
    new_n334_, new_n335_, new_n336_, new_n337_, new_n338_, new_n339_,
    new_n340_, new_n341_, new_n342_, new_n343_, new_n344_, new_n345_,
    new_n346_, new_n347_, new_n348_, new_n349_, new_n350_, new_n351_,
    new_n352_, new_n353_, new_n354_, new_n355_, new_n356_, new_n357_,
    new_n358_, new_n359_, new_n360_, new_n361_, new_n362_, new_n363_,
    new_n364_, new_n365_, new_n366_, new_n367_, new_n369_, new_n370_,
    new_n371_, new_n372_, new_n373_, new_n374_, new_n375_, new_n376_,
    new_n377_, new_n378_, new_n379_, new_n380_, new_n381_, new_n382_,
    new_n383_, new_n384_, new_n385_, new_n386_, new_n387_, new_n388_,
    new_n389_, new_n390_, new_n391_, new_n392_, new_n393_, new_n394_,
    new_n395_, new_n396_, new_n397_, new_n398_, new_n399_, new_n400_,
    new_n402_, new_n403_, new_n404_, new_n405_, new_n406_, new_n407_,
    new_n408_, new_n409_, new_n410_, new_n411_, new_n412_, new_n413_,
    new_n414_, new_n415_, new_n416_, new_n417_, new_n418_, new_n420_,
    new_n421_, new_n422_;
  NOR2x1_ASAP7_75t_R   g000(.A(p6), .B(p3), .Y(new_n22_));
  INVx1_ASAP7_75t_R    g001(.A(new_n22_), .Y(new_n23_));
  INVx1_ASAP7_75t_R    g002(.A(p0), .Y(new_n24_));
  NOR2x1_ASAP7_75t_R   g003(.A(p7), .B(new_n24_), .Y(new_n25_));
  INVx1_ASAP7_75t_R    g004(.A(p9), .Y(new_n26_));
  NOR2x1_ASAP7_75t_R   g005(.A(p8), .B(new_n26_), .Y(new_n27_));
  INVx1_ASAP7_75t_R    g006(.A(p8), .Y(new_n28_));
  NOR2x1_ASAP7_75t_R   g007(.A(p9), .B(new_n28_), .Y(new_n29_));
  INVx1_ASAP7_75t_R    g008(.A(p7), .Y(new_n30_));
  AO32x1_ASAP7_75t_R   g009(.A1(new_n27_), .A2(new_n24_), .A3(p1), .B1(new_n29_), .B2(new_n30_), .Y(new_n31_));
  INVx1_ASAP7_75t_R    g010(.A(p4), .Y(new_n32_));
  OAI21x1_ASAP7_75t_R  g011(.A1(new_n25_), .A2(new_n31_), .B(new_n32_), .Y(new_n33_));
  NAND2x1_ASAP7_75t_R  g012(.A(p9), .B(new_n28_), .Y(new_n34_));
  NAND2x1_ASAP7_75t_R  g013(.A(p8), .B(new_n26_), .Y(new_n35_));
  AND5x1_ASAP7_75t_R   g014(.A(p4), .B(new_n34_), .C(new_n35_), .D(p0), .E(p1), .Y(new_n36_));
  AND2x2_ASAP7_75t_R   g015(.A(p7), .B(p5), .Y(new_n37_));
  NOR2x1_ASAP7_75t_R   g016(.A(p0), .B(p1), .Y(new_n38_));
  AO21x1_ASAP7_75t_R   g017(.A1(new_n38_), .A2(new_n29_), .B(p4), .Y(new_n39_));
  AOI22x1_ASAP7_75t_R  g018(.A1(new_n36_), .A2(p7), .B1(new_n37_), .B2(new_n39_), .Y(new_n40_));
  INVx1_ASAP7_75t_R    g019(.A(p2), .Y(new_n41_));
  AO21x1_ASAP7_75t_R   g020(.A1(new_n33_), .A2(new_n40_), .B(new_n41_), .Y(new_n42_));
  NOR2x1_ASAP7_75t_R   g021(.A(p1), .B(p2), .Y(new_n43_));
  NOR2x1_ASAP7_75t_R   g022(.A(p7), .B(p8), .Y(new_n44_));
  AO32x1_ASAP7_75t_R   g023(.A1(new_n24_), .A2(new_n43_), .A3(new_n44_), .B1(new_n25_), .B2(new_n32_), .Y(new_n45_));
  NOR2x1_ASAP7_75t_R   g024(.A(p1), .B(new_n27_), .Y(new_n46_));
  OA211x2_ASAP7_75t_R  g025(.A1(p5), .A2(new_n46_), .B(p7), .C(p4), .Y(new_n47_));
  NAND2x1_ASAP7_75t_R  g026(.A(p0), .B(new_n41_), .Y(new_n48_));
  OAI21x1_ASAP7_75t_R  g027(.A1(new_n29_), .A2(new_n48_), .B(new_n46_), .Y(new_n49_));
  AND2x2_ASAP7_75t_R   g028(.A(p8), .B(p1), .Y(new_n50_));
  INVx1_ASAP7_75t_R    g029(.A(p1), .Y(new_n51_));
  AND3x1_ASAP7_75t_R   g030(.A(new_n28_), .B(new_n51_), .C(p0), .Y(new_n52_));
  NOR2x1_ASAP7_75t_R   g031(.A(p9), .B(p2), .Y(new_n53_));
  OA211x2_ASAP7_75t_R  g032(.A1(new_n50_), .A2(new_n52_), .B(new_n37_), .C(new_n53_), .Y(new_n54_));
  AOI221x1_ASAP7_75t_R g033(.A1(new_n26_), .A2(new_n45_), .B1(new_n47_), .B2(new_n49_), .C(new_n54_), .Y(new_n55_));
  NOR2x1_ASAP7_75t_R   g034(.A(p0), .B(new_n28_), .Y(new_n56_));
  AND3x1_ASAP7_75t_R   g035(.A(new_n26_), .B(new_n41_), .C(p1), .Y(new_n57_));
  NAND2x1_ASAP7_75t_R  g036(.A(new_n56_), .B(new_n57_), .Y(new_n58_));
  INVx1_ASAP7_75t_R    g037(.A(p5), .Y(new_n59_));
  NAND2x1_ASAP7_75t_R  g038(.A(p2), .B(new_n59_), .Y(new_n60_));
  NOR2x1_ASAP7_75t_R   g039(.A(p8), .B(p0), .Y(new_n61_));
  NAND2x1_ASAP7_75t_R  g040(.A(p1), .B(p2), .Y(new_n62_));
  AO32x1_ASAP7_75t_R   g041(.A1(new_n60_), .A2(new_n61_), .A3(new_n62_), .B1(p8), .B2(p1), .Y(new_n63_));
  NAND2x1_ASAP7_75t_R  g042(.A(new_n30_), .B(new_n63_), .Y(new_n64_));
  AO21x1_ASAP7_75t_R   g043(.A1(new_n58_), .A2(new_n64_), .B(p4), .Y(new_n65_));
  AND3x1_ASAP7_75t_R   g044(.A(new_n42_), .B(new_n55_), .C(new_n65_), .Y(new_n66_));
  AND2x2_ASAP7_75t_R   g045(.A(p0), .B(p1), .Y(new_n67_));
  INVx1_ASAP7_75t_R    g046(.A(new_n67_), .Y(new_n68_));
  AO21x1_ASAP7_75t_R   g047(.A1(new_n32_), .A2(new_n51_), .B(p9), .Y(new_n69_));
  AO21x1_ASAP7_75t_R   g048(.A1(new_n68_), .A2(new_n69_), .B(p8), .Y(new_n70_));
  OR3x1_ASAP7_75t_R    g049(.A(new_n43_), .B(new_n28_), .C(p0), .Y(new_n71_));
  OR3x1_ASAP7_75t_R    g050(.A(new_n26_), .B(new_n41_), .C(p0), .Y(new_n72_));
  AND3x1_ASAP7_75t_R   g051(.A(new_n71_), .B(new_n48_), .C(new_n72_), .Y(new_n73_));
  AO21x1_ASAP7_75t_R   g052(.A1(new_n70_), .A2(new_n73_), .B(p6), .Y(new_n74_));
  NOR2x1_ASAP7_75t_R   g053(.A(p4), .B(new_n30_), .Y(new_n75_));
  INVx1_ASAP7_75t_R    g054(.A(new_n75_), .Y(new_n76_));
  INVx1_ASAP7_75t_R    g055(.A(p6), .Y(new_n77_));
  NOR2x1_ASAP7_75t_R   g056(.A(p8), .B(p4), .Y(new_n78_));
  NOR2x1_ASAP7_75t_R   g057(.A(p1), .B(new_n26_), .Y(new_n79_));
  OAI21x1_ASAP7_75t_R  g058(.A1(new_n77_), .A2(new_n78_), .B(new_n79_), .Y(new_n80_));
  NOR2x1_ASAP7_75t_R   g059(.A(p8), .B(new_n24_), .Y(new_n81_));
  AO21x1_ASAP7_75t_R   g060(.A1(new_n77_), .A2(new_n81_), .B(p2), .Y(new_n82_));
  AOI21x1_ASAP7_75t_R  g061(.A1(new_n76_), .A2(new_n80_), .B(new_n82_), .Y(new_n83_));
  INVx1_ASAP7_75t_R    g062(.A(new_n56_), .Y(new_n84_));
  NAND2x1_ASAP7_75t_R  g063(.A(p4), .B(new_n24_), .Y(new_n85_));
  AND3x1_ASAP7_75t_R   g064(.A(new_n61_), .B(new_n26_), .C(p1), .Y(new_n86_));
  AO32x1_ASAP7_75t_R   g065(.A1(new_n84_), .A2(new_n85_), .A3(new_n79_), .B1(new_n86_), .B2(p6), .Y(new_n87_));
  NAND2x1_ASAP7_75t_R  g066(.A(p0), .B(p9), .Y(new_n88_));
  NOR2x1_ASAP7_75t_R   g067(.A(p4), .B(p2), .Y(new_n89_));
  NAND2x1_ASAP7_75t_R  g068(.A(new_n88_), .B(new_n89_), .Y(new_n90_));
  AO21x1_ASAP7_75t_R   g069(.A1(new_n24_), .A2(new_n26_), .B(p6), .Y(new_n91_));
  NOR2x1_ASAP7_75t_R   g070(.A(p7), .B(p1), .Y(new_n92_));
  INVx1_ASAP7_75t_R    g071(.A(new_n92_), .Y(new_n93_));
  NAND2x1_ASAP7_75t_R  g072(.A(p8), .B(p0), .Y(new_n94_));
  INVx1_ASAP7_75t_R    g073(.A(new_n94_), .Y(new_n95_));
  NOR2x1_ASAP7_75t_R   g074(.A(new_n61_), .B(new_n95_), .Y(new_n96_));
  AOI211x1_ASAP7_75t_R g075(.A1(new_n90_), .A2(new_n91_), .B(new_n93_), .C(new_n96_), .Y(new_n97_));
  AOI21x1_ASAP7_75t_R  g076(.A1(new_n83_), .A2(new_n87_), .B(new_n97_), .Y(new_n98_));
  OAI21x1_ASAP7_75t_R  g077(.A1(p7), .A2(new_n74_), .B(new_n98_), .Y(new_n99_));
  NOR2x1_ASAP7_75t_R   g078(.A(p3), .B(p5), .Y(new_n100_));
  AND2x2_ASAP7_75t_R   g079(.A(p3), .B(p8), .Y(new_n101_));
  AO21x1_ASAP7_75t_R   g080(.A1(new_n28_), .A2(p5), .B(new_n101_), .Y(new_n102_));
  AND2x2_ASAP7_75t_R   g081(.A(p4), .B(p5), .Y(new_n103_));
  INVx1_ASAP7_75t_R    g082(.A(new_n103_), .Y(new_n104_));
  AO21x1_ASAP7_75t_R   g083(.A1(new_n30_), .A2(p4), .B(new_n103_), .Y(new_n105_));
  NOR2x1_ASAP7_75t_R   g084(.A(p8), .B(p5), .Y(new_n106_));
  AO21x1_ASAP7_75t_R   g085(.A1(p3), .A2(p7), .B(new_n106_), .Y(new_n107_));
  AO32x1_ASAP7_75t_R   g086(.A1(new_n102_), .A2(new_n30_), .A3(new_n104_), .B1(new_n105_), .B2(new_n107_), .Y(new_n108_));
  AND3x1_ASAP7_75t_R   g087(.A(new_n24_), .B(new_n26_), .C(new_n51_), .Y(new_n109_));
  AND3x1_ASAP7_75t_R   g088(.A(new_n109_), .B(new_n77_), .C(new_n41_), .Y(new_n110_));
  AOI22x1_ASAP7_75t_R  g089(.A1(new_n99_), .A2(new_n100_), .B1(new_n108_), .B2(new_n110_), .Y(new_n111_));
  OAI21x1_ASAP7_75t_R  g090(.A1(new_n23_), .A2(new_n66_), .B(new_n111_), .Y(o0));
  NAND2x1_ASAP7_75t_R  g091(.A(new_n77_), .B(new_n41_), .Y(new_n113_));
  INVx1_ASAP7_75t_R    g092(.A(p3), .Y(new_n114_));
  AOI21x1_ASAP7_75t_R  g093(.A1(p8), .A2(p5), .B(new_n75_), .Y(new_n115_));
  OR3x1_ASAP7_75t_R    g094(.A(new_n37_), .B(new_n26_), .C(p1), .Y(new_n116_));
  NAND2x1_ASAP7_75t_R  g095(.A(p4), .B(new_n92_), .Y(new_n117_));
  OAI22x1_ASAP7_75t_R  g096(.A1(new_n115_), .A2(new_n116_), .B1(new_n35_), .B2(new_n117_), .Y(new_n118_));
  AO21x1_ASAP7_75t_R   g097(.A1(p5), .A2(new_n26_), .B(p1), .Y(new_n119_));
  NOR2x1_ASAP7_75t_R   g098(.A(p7), .B(p5), .Y(new_n120_));
  AO21x1_ASAP7_75t_R   g099(.A1(new_n75_), .A2(new_n119_), .B(new_n120_), .Y(new_n121_));
  AOI22x1_ASAP7_75t_R  g100(.A1(new_n118_), .A2(p0), .B1(new_n81_), .B2(new_n121_), .Y(new_n122_));
  NAND2x1_ASAP7_75t_R  g101(.A(p7), .B(p8), .Y(new_n123_));
  OR3x1_ASAP7_75t_R    g102(.A(p7), .B(p8), .C(p4), .Y(new_n124_));
  OAI21x1_ASAP7_75t_R  g103(.A1(new_n59_), .A2(new_n123_), .B(new_n124_), .Y(new_n125_));
  NOR2x1_ASAP7_75t_R   g104(.A(p9), .B(new_n115_), .Y(new_n126_));
  NOR2x1_ASAP7_75t_R   g105(.A(p0), .B(new_n51_), .Y(new_n127_));
  OAI21x1_ASAP7_75t_R  g106(.A1(new_n125_), .A2(new_n126_), .B(new_n127_), .Y(new_n128_));
  INVx1_ASAP7_75t_R    g107(.A(new_n106_), .Y(new_n129_));
  NAND2x1_ASAP7_75t_R  g108(.A(p7), .B(p1), .Y(new_n130_));
  OR4x2_ASAP7_75t_R    g109(.A(p7), .B(p8), .C(p9), .D(p1), .Y(new_n131_));
  AND2x2_ASAP7_75t_R   g110(.A(p7), .B(p9), .Y(new_n132_));
  NAND2x1_ASAP7_75t_R  g111(.A(new_n50_), .B(new_n132_), .Y(new_n133_));
  AO21x1_ASAP7_75t_R   g112(.A1(new_n131_), .A2(new_n133_), .B(new_n85_), .Y(new_n134_));
  OA21x2_ASAP7_75t_R   g113(.A1(new_n129_), .A2(new_n130_), .B(new_n134_), .Y(new_n135_));
  NAND3x1_ASAP7_75t_R  g114(.A(new_n122_), .B(new_n128_), .C(new_n135_), .Y(new_n136_));
  AND2x2_ASAP7_75t_R   g115(.A(p3), .B(p7), .Y(new_n137_));
  AO21x1_ASAP7_75t_R   g116(.A1(new_n30_), .A2(p4), .B(new_n137_), .Y(new_n138_));
  AO22x1_ASAP7_75t_R   g117(.A1(p5), .A2(new_n101_), .B1(new_n106_), .B2(new_n138_), .Y(new_n139_));
  AND2x2_ASAP7_75t_R   g118(.A(new_n109_), .B(new_n139_), .Y(new_n140_));
  AOI21x1_ASAP7_75t_R  g119(.A1(new_n114_), .A2(new_n136_), .B(new_n140_), .Y(new_n141_));
  NAND2x1_ASAP7_75t_R  g120(.A(p4), .B(p0), .Y(new_n142_));
  NOR2x1_ASAP7_75t_R   g121(.A(p7), .B(new_n41_), .Y(new_n143_));
  NAND2x1_ASAP7_75t_R  g122(.A(new_n38_), .B(new_n143_), .Y(new_n144_));
  NAND2x1_ASAP7_75t_R  g123(.A(p5), .B(p9), .Y(new_n145_));
  AO21x1_ASAP7_75t_R   g124(.A1(new_n142_), .A2(new_n144_), .B(new_n145_), .Y(new_n146_));
  OR3x1_ASAP7_75t_R    g125(.A(new_n43_), .B(new_n89_), .C(new_n59_), .Y(new_n147_));
  AO21x1_ASAP7_75t_R   g126(.A1(new_n32_), .A2(new_n68_), .B(new_n147_), .Y(new_n148_));
  OR3x1_ASAP7_75t_R    g127(.A(new_n62_), .B(new_n142_), .C(p7), .Y(new_n149_));
  AND3x1_ASAP7_75t_R   g128(.A(new_n148_), .B(p8), .C(new_n149_), .Y(new_n150_));
  AOI21x1_ASAP7_75t_R  g129(.A1(new_n146_), .A2(new_n150_), .B(new_n23_), .Y(new_n151_));
  NOR2x1_ASAP7_75t_R   g130(.A(p7), .B(p2), .Y(new_n152_));
  AO21x1_ASAP7_75t_R   g131(.A1(p7), .A2(new_n32_), .B(new_n152_), .Y(new_n153_));
  OAI21x1_ASAP7_75t_R  g132(.A1(new_n26_), .A2(new_n153_), .B(new_n117_), .Y(new_n154_));
  AO21x1_ASAP7_75t_R   g133(.A1(p7), .A2(p2), .B(p1), .Y(new_n155_));
  AND2x2_ASAP7_75t_R   g134(.A(new_n26_), .B(new_n155_), .Y(new_n156_));
  NAND2x1_ASAP7_75t_R  g135(.A(p7), .B(p9), .Y(new_n157_));
  NOR2x1_ASAP7_75t_R   g136(.A(p1), .B(new_n157_), .Y(new_n158_));
  NAND2x1_ASAP7_75t_R  g137(.A(p4), .B(new_n26_), .Y(new_n159_));
  NAND2x1_ASAP7_75t_R  g138(.A(p9), .B(new_n32_), .Y(new_n160_));
  NAND2x1_ASAP7_75t_R  g139(.A(new_n159_), .B(new_n160_), .Y(new_n161_));
  OA21x2_ASAP7_75t_R   g140(.A1(new_n158_), .A2(new_n161_), .B(p0), .Y(new_n162_));
  AOI211x1_ASAP7_75t_R g141(.A1(new_n24_), .A2(new_n154_), .B(new_n156_), .C(new_n162_), .Y(new_n163_));
  INVx1_ASAP7_75t_R    g142(.A(new_n88_), .Y(new_n164_));
  NOR2x1_ASAP7_75t_R   g143(.A(p9), .B(new_n30_), .Y(new_n165_));
  NOR2x1_ASAP7_75t_R   g144(.A(p5), .B(p0), .Y(new_n166_));
  OR5x1_ASAP7_75t_R    g145(.A(p4), .B(new_n164_), .C(new_n165_), .D(p1), .E(new_n166_), .Y(new_n167_));
  NOR2x1_ASAP7_75t_R   g146(.A(p5), .B(new_n51_), .Y(new_n168_));
  NAND2x1_ASAP7_75t_R  g147(.A(p2), .B(new_n32_), .Y(new_n169_));
  NOR2x1_ASAP7_75t_R   g148(.A(p7), .B(p0), .Y(new_n170_));
  OR4x2_ASAP7_75t_R    g149(.A(new_n168_), .B(new_n169_), .C(new_n170_), .D(new_n67_), .Y(new_n171_));
  AND3x1_ASAP7_75t_R   g150(.A(new_n167_), .B(new_n171_), .C(new_n28_), .Y(new_n172_));
  OAI21x1_ASAP7_75t_R  g151(.A1(p5), .A2(new_n163_), .B(new_n172_), .Y(new_n173_));
  AND3x1_ASAP7_75t_R   g152(.A(new_n28_), .B(p7), .C(p0), .Y(new_n174_));
  NOR2x1_ASAP7_75t_R   g153(.A(p1), .B(new_n77_), .Y(new_n175_));
  AO21x1_ASAP7_75t_R   g154(.A1(new_n174_), .A2(new_n175_), .B(new_n86_), .Y(new_n176_));
  NOR2x1_ASAP7_75t_R   g155(.A(p7), .B(p9), .Y(new_n177_));
  INVx1_ASAP7_75t_R    g156(.A(new_n177_), .Y(new_n178_));
  AO21x1_ASAP7_75t_R   g157(.A1(new_n178_), .A2(new_n93_), .B(new_n67_), .Y(new_n179_));
  AOI211x1_ASAP7_75t_R g158(.A1(new_n88_), .A2(new_n46_), .B(new_n77_), .C(new_n179_), .Y(new_n180_));
  AND3x1_ASAP7_75t_R   g159(.A(new_n89_), .B(new_n114_), .C(new_n59_), .Y(new_n181_));
  OA21x2_ASAP7_75t_R   g160(.A1(new_n176_), .A2(new_n180_), .B(new_n181_), .Y(new_n182_));
  AOI21x1_ASAP7_75t_R  g161(.A1(new_n151_), .A2(new_n173_), .B(new_n182_), .Y(new_n183_));
  OAI21x1_ASAP7_75t_R  g162(.A1(new_n113_), .A2(new_n141_), .B(new_n183_), .Y(o1));
  OR3x1_ASAP7_75t_R    g163(.A(new_n28_), .B(new_n51_), .C(p4), .Y(new_n185_));
  AND2x2_ASAP7_75t_R   g164(.A(p7), .B(p8), .Y(new_n186_));
  NOR2x1_ASAP7_75t_R   g165(.A(new_n44_), .B(new_n186_), .Y(new_n187_));
  OR3x1_ASAP7_75t_R    g166(.A(new_n187_), .B(new_n32_), .C(new_n29_), .Y(new_n188_));
  AO21x1_ASAP7_75t_R   g167(.A1(new_n185_), .A2(new_n188_), .B(new_n48_), .Y(new_n189_));
  OR3x1_ASAP7_75t_R    g168(.A(p7), .B(p8), .C(p1), .Y(new_n190_));
  AO21x1_ASAP7_75t_R   g169(.A1(new_n160_), .A2(new_n72_), .B(new_n190_), .Y(new_n191_));
  OA21x2_ASAP7_75t_R   g170(.A1(new_n71_), .A2(new_n157_), .B(new_n191_), .Y(new_n192_));
  NAND2x1_ASAP7_75t_R  g171(.A(new_n28_), .B(new_n24_), .Y(new_n193_));
  INVx1_ASAP7_75t_R    g172(.A(new_n187_), .Y(new_n194_));
  NAND2x1_ASAP7_75t_R  g173(.A(p1), .B(new_n41_), .Y(new_n195_));
  AO21x1_ASAP7_75t_R   g174(.A1(new_n193_), .A2(new_n194_), .B(new_n195_), .Y(new_n196_));
  NAND3x1_ASAP7_75t_R  g175(.A(new_n189_), .B(new_n192_), .C(new_n196_), .Y(new_n197_));
  AND3x1_ASAP7_75t_R   g176(.A(new_n77_), .B(new_n114_), .C(new_n59_), .Y(new_n198_));
  NAND2x1_ASAP7_75t_R  g177(.A(p0), .B(new_n28_), .Y(new_n199_));
  AND2x2_ASAP7_75t_R   g178(.A(new_n152_), .B(new_n199_), .Y(new_n200_));
  OR3x1_ASAP7_75t_R    g179(.A(new_n200_), .B(new_n37_), .C(new_n174_), .Y(new_n201_));
  AND3x1_ASAP7_75t_R   g180(.A(new_n50_), .B(p5), .C(p0), .Y(new_n202_));
  AND3x1_ASAP7_75t_R   g181(.A(new_n24_), .B(p7), .C(p5), .Y(new_n203_));
  AND3x1_ASAP7_75t_R   g182(.A(new_n30_), .B(new_n28_), .C(p1), .Y(new_n204_));
  OA21x2_ASAP7_75t_R   g183(.A1(p8), .A2(new_n51_), .B(p7), .Y(new_n205_));
  OR4x2_ASAP7_75t_R    g184(.A(new_n202_), .B(new_n203_), .C(new_n204_), .D(new_n205_), .Y(new_n206_));
  AO32x1_ASAP7_75t_R   g185(.A1(new_n201_), .A2(new_n51_), .A3(new_n84_), .B1(new_n206_), .B2(p2), .Y(new_n207_));
  AND3x1_ASAP7_75t_R   g186(.A(new_n22_), .B(new_n32_), .C(p9), .Y(new_n208_));
  AOI22x1_ASAP7_75t_R  g187(.A1(new_n197_), .A2(new_n198_), .B1(new_n207_), .B2(new_n208_), .Y(new_n209_));
  AO21x1_ASAP7_75t_R   g188(.A1(p2), .A2(new_n28_), .B(p5), .Y(new_n210_));
  NAND2x1_ASAP7_75t_R  g189(.A(p7), .B(new_n51_), .Y(new_n211_));
  AND2x2_ASAP7_75t_R   g190(.A(p4), .B(p2), .Y(new_n212_));
  NOR2x1_ASAP7_75t_R   g191(.A(p1), .B(new_n41_), .Y(new_n213_));
  OA21x2_ASAP7_75t_R   g192(.A1(new_n30_), .A2(new_n213_), .B(new_n32_), .Y(new_n214_));
  AO21x1_ASAP7_75t_R   g193(.A1(new_n211_), .A2(new_n212_), .B(new_n214_), .Y(new_n215_));
  AO21x1_ASAP7_75t_R   g194(.A1(new_n210_), .A2(new_n215_), .B(new_n199_), .Y(new_n216_));
  NAND2x1_ASAP7_75t_R  g195(.A(new_n94_), .B(new_n193_), .Y(new_n217_));
  NOR2x1_ASAP7_75t_R   g196(.A(p7), .B(new_n59_), .Y(new_n218_));
  AND3x1_ASAP7_75t_R   g197(.A(new_n218_), .B(new_n85_), .C(new_n41_), .Y(new_n219_));
  AND3x1_ASAP7_75t_R   g198(.A(new_n143_), .B(p8), .C(new_n59_), .Y(new_n220_));
  AOI211x1_ASAP7_75t_R g199(.A1(new_n217_), .A2(new_n219_), .B(p3), .C(new_n220_), .Y(new_n221_));
  AO21x1_ASAP7_75t_R   g200(.A1(p5), .A2(p1), .B(new_n24_), .Y(new_n222_));
  AO21x1_ASAP7_75t_R   g201(.A1(new_n30_), .A2(p1), .B(new_n222_), .Y(new_n223_));
  AND2x2_ASAP7_75t_R   g202(.A(p4), .B(new_n155_), .Y(new_n224_));
  AO21x1_ASAP7_75t_R   g203(.A1(new_n56_), .A2(new_n143_), .B(new_n213_), .Y(new_n225_));
  NOR2x1_ASAP7_75t_R   g204(.A(new_n106_), .B(new_n174_), .Y(new_n226_));
  AOI22x1_ASAP7_75t_R  g205(.A1(new_n223_), .A2(new_n224_), .B1(new_n225_), .B2(new_n226_), .Y(new_n227_));
  AO21x1_ASAP7_75t_R   g206(.A1(new_n24_), .A2(new_n43_), .B(new_n114_), .Y(new_n228_));
  NAND2x1_ASAP7_75t_R  g207(.A(new_n77_), .B(new_n26_), .Y(new_n229_));
  OA211x2_ASAP7_75t_R  g208(.A1(new_n186_), .A2(new_n218_), .B(p3), .C(new_n32_), .Y(new_n230_));
  NOR2x1_ASAP7_75t_R   g209(.A(new_n229_), .B(new_n230_), .Y(new_n231_));
  NAND2x1_ASAP7_75t_R  g210(.A(new_n228_), .B(new_n231_), .Y(new_n232_));
  AO31x2_ASAP7_75t_R   g211(.A1(new_n216_), .A2(new_n221_), .A3(new_n227_), .B(new_n232_), .Y(new_n233_));
  NOR2x1_ASAP7_75t_R   g212(.A(p4), .B(p5), .Y(new_n234_));
  AND3x1_ASAP7_75t_R   g213(.A(new_n43_), .B(new_n234_), .C(new_n114_), .Y(new_n235_));
  AO21x1_ASAP7_75t_R   g214(.A1(p6), .A2(new_n186_), .B(new_n26_), .Y(new_n236_));
  AO32x1_ASAP7_75t_R   g215(.A1(new_n236_), .A2(p0), .A3(new_n35_), .B1(new_n27_), .B2(new_n170_), .Y(new_n237_));
  NAND2x1_ASAP7_75t_R  g216(.A(new_n235_), .B(new_n237_), .Y(new_n238_));
  NAND3x1_ASAP7_75t_R  g217(.A(new_n209_), .B(new_n233_), .C(new_n238_), .Y(o2));
  NOR2x1_ASAP7_75t_R   g218(.A(p1), .B(new_n32_), .Y(new_n240_));
  AO21x1_ASAP7_75t_R   g219(.A1(new_n240_), .A2(new_n187_), .B(new_n213_), .Y(new_n241_));
  AO21x1_ASAP7_75t_R   g220(.A1(p2), .A2(new_n30_), .B(p5), .Y(new_n242_));
  AO32x1_ASAP7_75t_R   g221(.A1(new_n153_), .A2(new_n28_), .A3(p1), .B1(new_n169_), .B2(new_n242_), .Y(new_n243_));
  OAI21x1_ASAP7_75t_R  g222(.A1(new_n241_), .A2(new_n243_), .B(new_n164_), .Y(new_n244_));
  NAND2x1_ASAP7_75t_R  g223(.A(p7), .B(p4), .Y(new_n245_));
  INVx1_ASAP7_75t_R    g224(.A(new_n234_), .Y(new_n246_));
  AO221x2_ASAP7_75t_R  g225(.A1(new_n245_), .A2(new_n94_), .B1(new_n129_), .B2(new_n246_), .C(new_n41_), .Y(new_n247_));
  NOR2x1_ASAP7_75t_R   g226(.A(p4), .B(new_n59_), .Y(new_n248_));
  OA21x2_ASAP7_75t_R   g227(.A1(new_n78_), .A2(new_n120_), .B(new_n213_), .Y(new_n249_));
  AOI21x1_ASAP7_75t_R  g228(.A1(new_n174_), .A2(new_n248_), .B(new_n249_), .Y(new_n250_));
  AO32x1_ASAP7_75t_R   g229(.A1(new_n30_), .A2(new_n59_), .A3(p2), .B1(new_n248_), .B2(new_n44_), .Y(new_n251_));
  INVx1_ASAP7_75t_R    g230(.A(new_n43_), .Y(new_n252_));
  NOR2x1_ASAP7_75t_R   g231(.A(p5), .B(new_n62_), .Y(new_n253_));
  AO21x1_ASAP7_75t_R   g232(.A1(new_n252_), .A2(new_n248_), .B(new_n253_), .Y(new_n254_));
  AOI22x1_ASAP7_75t_R  g233(.A1(new_n251_), .A2(new_n24_), .B1(new_n254_), .B2(new_n56_), .Y(new_n255_));
  AO32x1_ASAP7_75t_R   g234(.A1(new_n92_), .A2(new_n166_), .A3(p4), .B1(p5), .B2(new_n89_), .Y(new_n256_));
  NAND2x1_ASAP7_75t_R  g235(.A(new_n27_), .B(new_n256_), .Y(new_n257_));
  AND5x1_ASAP7_75t_R   g236(.A(new_n244_), .B(new_n247_), .C(new_n250_), .D(new_n255_), .E(new_n257_), .Y(new_n258_));
  OR3x1_ASAP7_75t_R    g237(.A(new_n245_), .B(new_n28_), .C(p5), .Y(new_n259_));
  NAND2x1_ASAP7_75t_R  g238(.A(new_n124_), .B(new_n259_), .Y(new_n260_));
  NAND2x1_ASAP7_75t_R  g239(.A(p5), .B(new_n30_), .Y(new_n261_));
  AOI21x1_ASAP7_75t_R  g240(.A1(new_n41_), .A2(new_n261_), .B(new_n105_), .Y(new_n262_));
  NOR2x1_ASAP7_75t_R   g241(.A(p0), .B(new_n41_), .Y(new_n263_));
  NAND2x1_ASAP7_75t_R  g242(.A(p8), .B(new_n59_), .Y(new_n264_));
  AO32x1_ASAP7_75t_R   g243(.A1(p5), .A2(p1), .A3(new_n142_), .B1(new_n263_), .B2(new_n264_), .Y(new_n265_));
  AO221x2_ASAP7_75t_R  g244(.A1(new_n67_), .A2(new_n260_), .B1(new_n262_), .B2(p0), .C(new_n265_), .Y(new_n266_));
  AND3x1_ASAP7_75t_R   g245(.A(new_n38_), .B(p3), .C(new_n41_), .Y(new_n267_));
  AO21x1_ASAP7_75t_R   g246(.A1(p7), .A2(p8), .B(p5), .Y(new_n268_));
  OA211x2_ASAP7_75t_R  g247(.A1(new_n103_), .A2(new_n234_), .B(new_n267_), .C(new_n268_), .Y(new_n269_));
  AOI21x1_ASAP7_75t_R  g248(.A1(new_n114_), .A2(new_n266_), .B(new_n269_), .Y(new_n270_));
  OAI22x1_ASAP7_75t_R  g249(.A1(new_n23_), .A2(new_n258_), .B1(new_n270_), .B2(new_n229_), .Y(o3));
  OA211x2_ASAP7_75t_R  g250(.A1(p0), .A2(p9), .B(new_n114_), .C(p1), .Y(new_n272_));
  NOR2x1_ASAP7_75t_R   g251(.A(p2), .B(new_n114_), .Y(new_n273_));
  NOR2x1_ASAP7_75t_R   g252(.A(p3), .B(new_n41_), .Y(new_n274_));
  OA21x2_ASAP7_75t_R   g253(.A1(new_n273_), .A2(new_n274_), .B(new_n109_), .Y(new_n275_));
  AND3x1_ASAP7_75t_R   g254(.A(new_n77_), .B(p4), .C(p5), .Y(new_n276_));
  OA21x2_ASAP7_75t_R   g255(.A1(new_n272_), .A2(new_n275_), .B(new_n276_), .Y(o4));
  INVx1_ASAP7_75t_R    g256(.A(new_n109_), .Y(new_n278_));
  AND2x2_ASAP7_75t_R   g257(.A(new_n274_), .B(new_n278_), .Y(new_n279_));
  AND3x1_ASAP7_75t_R   g258(.A(new_n109_), .B(new_n273_), .C(new_n276_), .Y(new_n280_));
  AO21x1_ASAP7_75t_R   g259(.A1(new_n276_), .A2(new_n279_), .B(new_n280_), .Y(o5));
  NAND2x1_ASAP7_75t_R  g260(.A(p1), .B(new_n26_), .Y(new_n282_));
  AO32x1_ASAP7_75t_R   g261(.A1(new_n282_), .A2(new_n30_), .A3(p0), .B1(new_n79_), .B2(new_n37_), .Y(new_n283_));
  AO32x1_ASAP7_75t_R   g262(.A1(new_n178_), .A2(new_n81_), .A3(new_n160_), .B1(new_n283_), .B2(p8), .Y(new_n284_));
  NOR2x1_ASAP7_75t_R   g263(.A(p0), .B(new_n44_), .Y(new_n285_));
  OR3x1_ASAP7_75t_R    g264(.A(new_n285_), .B(new_n26_), .C(new_n81_), .Y(new_n286_));
  NOR2x1_ASAP7_75t_R   g265(.A(p5), .B(p9), .Y(new_n287_));
  NOR2x1_ASAP7_75t_R   g266(.A(new_n287_), .B(new_n67_), .Y(new_n288_));
  OR3x1_ASAP7_75t_R    g267(.A(new_n217_), .B(new_n170_), .C(new_n288_), .Y(new_n289_));
  AOI21x1_ASAP7_75t_R  g268(.A1(new_n286_), .A2(new_n289_), .B(p4), .Y(new_n290_));
  OAI21x1_ASAP7_75t_R  g269(.A1(new_n284_), .A2(new_n290_), .B(p2), .Y(new_n291_));
  AO21x1_ASAP7_75t_R   g270(.A1(new_n34_), .A2(new_n240_), .B(new_n29_), .Y(new_n292_));
  AO21x1_ASAP7_75t_R   g271(.A1(p1), .A2(new_n32_), .B(p5), .Y(new_n293_));
  OA21x2_ASAP7_75t_R   g272(.A1(new_n35_), .A2(new_n293_), .B(new_n25_), .Y(new_n294_));
  INVx1_ASAP7_75t_R    g273(.A(new_n287_), .Y(new_n295_));
  NAND2x1_ASAP7_75t_R  g274(.A(p7), .B(new_n26_), .Y(new_n296_));
  NOR2x1_ASAP7_75t_R   g275(.A(p8), .B(p1), .Y(new_n297_));
  AND5x1_ASAP7_75t_R   g276(.A(new_n24_), .B(new_n295_), .C(new_n296_), .D(new_n245_), .E(new_n297_), .Y(new_n298_));
  AND3x1_ASAP7_75t_R   g277(.A(new_n26_), .B(p8), .C(p1), .Y(new_n299_));
  OA21x2_ASAP7_75t_R   g278(.A1(p7), .A2(p8), .B(p1), .Y(new_n300_));
  AO21x1_ASAP7_75t_R   g279(.A1(p8), .A2(new_n132_), .B(new_n300_), .Y(new_n301_));
  AND2x2_ASAP7_75t_R   g280(.A(p5), .B(p0), .Y(new_n302_));
  AO32x1_ASAP7_75t_R   g281(.A1(p7), .A2(new_n24_), .A3(new_n299_), .B1(new_n301_), .B2(new_n302_), .Y(new_n303_));
  AOI211x1_ASAP7_75t_R g282(.A1(new_n292_), .A2(new_n294_), .B(new_n298_), .C(new_n303_), .Y(new_n304_));
  AO32x1_ASAP7_75t_R   g283(.A1(new_n95_), .A2(p7), .A3(p9), .B1(new_n24_), .B2(new_n44_), .Y(new_n305_));
  OAI21x1_ASAP7_75t_R  g284(.A1(new_n299_), .A2(new_n305_), .B(p4), .Y(new_n306_));
  AND2x2_ASAP7_75t_R   g285(.A(new_n130_), .B(new_n93_), .Y(new_n307_));
  OR3x1_ASAP7_75t_R    g286(.A(new_n307_), .B(new_n59_), .C(new_n187_), .Y(new_n308_));
  NAND2x1_ASAP7_75t_R  g287(.A(new_n106_), .B(new_n132_), .Y(new_n309_));
  AO21x1_ASAP7_75t_R   g288(.A1(p4), .A2(p1), .B(new_n67_), .Y(new_n310_));
  OR3x1_ASAP7_75t_R    g289(.A(new_n78_), .B(new_n130_), .C(p9), .Y(new_n311_));
  OA21x2_ASAP7_75t_R   g290(.A1(new_n309_), .A2(new_n310_), .B(new_n311_), .Y(new_n312_));
  AO31x2_ASAP7_75t_R   g291(.A1(new_n306_), .A2(new_n308_), .A3(new_n312_), .B(p2), .Y(new_n313_));
  NAND3x1_ASAP7_75t_R  g292(.A(new_n291_), .B(new_n304_), .C(new_n313_), .Y(new_n314_));
  AO21x1_ASAP7_75t_R   g293(.A1(p0), .A2(p9), .B(new_n44_), .Y(new_n315_));
  AO21x1_ASAP7_75t_R   g294(.A1(p6), .A2(new_n28_), .B(new_n30_), .Y(new_n316_));
  AO21x1_ASAP7_75t_R   g295(.A1(new_n127_), .A2(new_n316_), .B(new_n52_), .Y(new_n317_));
  AO32x1_ASAP7_75t_R   g296(.A1(new_n175_), .A2(new_n194_), .A3(new_n315_), .B1(new_n317_), .B2(new_n26_), .Y(new_n318_));
  AND3x1_ASAP7_75t_R   g297(.A(new_n267_), .B(new_n77_), .C(new_n26_), .Y(new_n319_));
  AO221x2_ASAP7_75t_R  g298(.A1(new_n77_), .A2(new_n103_), .B1(new_n318_), .B2(new_n181_), .C(new_n319_), .Y(new_n320_));
  AOI21x1_ASAP7_75t_R  g299(.A1(new_n22_), .A2(new_n314_), .B(new_n320_), .Y(o6));
  AND3x1_ASAP7_75t_R   g300(.A(new_n123_), .B(new_n26_), .C(p1), .Y(new_n322_));
  INVx1_ASAP7_75t_R    g301(.A(new_n44_), .Y(new_n323_));
  AO32x1_ASAP7_75t_R   g302(.A1(p6), .A2(new_n28_), .A3(new_n158_), .B1(new_n322_), .B2(new_n323_), .Y(new_n324_));
  NOR2x1_ASAP7_75t_R   g303(.A(p0), .B(p2), .Y(new_n325_));
  AND3x1_ASAP7_75t_R   g304(.A(new_n324_), .B(new_n325_), .C(new_n234_), .Y(new_n326_));
  OA21x2_ASAP7_75t_R   g305(.A1(new_n77_), .A2(new_n326_), .B(new_n114_), .Y(new_n327_));
  AOI21x1_ASAP7_75t_R  g306(.A1(new_n60_), .A2(new_n261_), .B(new_n28_), .Y(new_n328_));
  NAND2x1_ASAP7_75t_R  g307(.A(new_n296_), .B(new_n261_), .Y(new_n329_));
  AOI21x1_ASAP7_75t_R  g308(.A1(p8), .A2(p5), .B(p7), .Y(new_n330_));
  AOI211x1_ASAP7_75t_R g309(.A1(p8), .A2(new_n26_), .B(new_n287_), .C(new_n330_), .Y(new_n331_));
  AOI22x1_ASAP7_75t_R  g310(.A1(new_n328_), .A2(new_n329_), .B1(new_n60_), .B2(new_n331_), .Y(new_n332_));
  AO21x1_ASAP7_75t_R   g311(.A1(p2), .A2(new_n123_), .B(new_n132_), .Y(new_n333_));
  AO32x1_ASAP7_75t_R   g312(.A1(new_n186_), .A2(p1), .A3(new_n41_), .B1(new_n106_), .B2(new_n152_), .Y(new_n334_));
  AOI21x1_ASAP7_75t_R  g313(.A1(new_n168_), .A2(new_n333_), .B(new_n334_), .Y(new_n335_));
  OAI21x1_ASAP7_75t_R  g314(.A1(p1), .A2(new_n332_), .B(new_n335_), .Y(new_n336_));
  NOR3x1_ASAP7_75t_R   g315(.A(new_n27_), .B(p1), .C(new_n268_), .Y(new_n337_));
  NAND2x1_ASAP7_75t_R  g316(.A(p5), .B(new_n26_), .Y(new_n338_));
  AOI21x1_ASAP7_75t_R  g317(.A1(new_n123_), .A2(new_n323_), .B(new_n338_), .Y(new_n339_));
  OAI21x1_ASAP7_75t_R  g318(.A1(new_n337_), .A2(new_n339_), .B(new_n263_), .Y(new_n340_));
  OAI21x1_ASAP7_75t_R  g319(.A1(p5), .A2(new_n152_), .B(new_n300_), .Y(new_n341_));
  OR3x1_ASAP7_75t_R    g320(.A(new_n145_), .B(new_n30_), .C(p8), .Y(new_n342_));
  AO31x2_ASAP7_75t_R   g321(.A1(new_n341_), .A2(new_n342_), .A3(new_n131_), .B(p0), .Y(new_n343_));
  OR3x1_ASAP7_75t_R    g322(.A(new_n190_), .B(new_n59_), .C(new_n41_), .Y(new_n344_));
  NAND3x1_ASAP7_75t_R  g323(.A(new_n340_), .B(new_n343_), .C(new_n344_), .Y(new_n345_));
  AOI21x1_ASAP7_75t_R  g324(.A1(p0), .A2(new_n336_), .B(new_n345_), .Y(new_n346_));
  AND3x1_ASAP7_75t_R   g325(.A(new_n24_), .B(p9), .C(p2), .Y(new_n347_));
  AO21x1_ASAP7_75t_R   g326(.A1(p9), .A2(p2), .B(p1), .Y(new_n348_));
  AND3x1_ASAP7_75t_R   g327(.A(new_n348_), .B(p4), .C(new_n24_), .Y(new_n349_));
  AOI22x1_ASAP7_75t_R  g328(.A1(p7), .A2(p8), .B1(p1), .B2(p2), .Y(new_n350_));
  NAND2x1_ASAP7_75t_R  g329(.A(new_n350_), .B(new_n323_), .Y(new_n351_));
  AND3x1_ASAP7_75t_R   g330(.A(new_n186_), .B(new_n212_), .C(p1), .Y(new_n352_));
  AOI221x1_ASAP7_75t_R g331(.A1(new_n347_), .A2(new_n204_), .B1(new_n349_), .B2(new_n351_), .C(new_n352_), .Y(new_n353_));
  AO21x1_ASAP7_75t_R   g332(.A1(new_n28_), .A2(p1), .B(new_n212_), .Y(new_n354_));
  AND3x1_ASAP7_75t_R   g333(.A(new_n240_), .B(p2), .C(new_n123_), .Y(new_n355_));
  AOI21x1_ASAP7_75t_R  g334(.A1(new_n177_), .A2(new_n354_), .B(new_n355_), .Y(new_n356_));
  AND3x1_ASAP7_75t_R   g335(.A(new_n50_), .B(new_n30_), .C(p4), .Y(new_n357_));
  OAI21x1_ASAP7_75t_R  g336(.A1(p8), .A2(p1), .B(p9), .Y(new_n358_));
  OAI22x1_ASAP7_75t_R  g337(.A1(new_n159_), .A2(p8), .B1(new_n50_), .B2(new_n358_), .Y(new_n359_));
  AO31x2_ASAP7_75t_R   g338(.A1(p8), .A2(p4), .A3(p1), .B(p7), .Y(new_n360_));
  AND2x2_ASAP7_75t_R   g339(.A(new_n41_), .B(new_n360_), .Y(new_n361_));
  OAI21x1_ASAP7_75t_R  g340(.A1(new_n357_), .A2(new_n359_), .B(new_n361_), .Y(new_n362_));
  NAND3x1_ASAP7_75t_R  g341(.A(new_n353_), .B(new_n356_), .C(new_n362_), .Y(new_n363_));
  AOI21x1_ASAP7_75t_R  g342(.A1(new_n24_), .A2(new_n353_), .B(p5), .Y(new_n364_));
  AOI21x1_ASAP7_75t_R  g343(.A1(new_n363_), .A2(new_n364_), .B(new_n326_), .Y(new_n365_));
  OAI21x1_ASAP7_75t_R  g344(.A1(p4), .A2(new_n346_), .B(new_n365_), .Y(new_n366_));
  AND2x2_ASAP7_75t_R   g345(.A(new_n234_), .B(new_n319_), .Y(new_n367_));
  AOI21x1_ASAP7_75t_R  g346(.A1(new_n327_), .A2(new_n366_), .B(new_n367_), .Y(o7));
  AO21x1_ASAP7_75t_R   g347(.A1(p4), .A2(new_n24_), .B(new_n89_), .Y(new_n369_));
  INVx1_ASAP7_75t_R    g348(.A(new_n53_), .Y(new_n370_));
  NOR2x1_ASAP7_75t_R   g349(.A(p1), .B(new_n30_), .Y(new_n371_));
  AND3x1_ASAP7_75t_R   g350(.A(new_n369_), .B(new_n370_), .C(new_n371_), .Y(new_n372_));
  NAND2x1_ASAP7_75t_R  g351(.A(p4), .B(p2), .Y(new_n373_));
  OA211x2_ASAP7_75t_R  g352(.A1(p4), .A2(new_n165_), .B(new_n67_), .C(new_n373_), .Y(new_n374_));
  AND5x1_ASAP7_75t_R   g353(.A(p7), .B(new_n32_), .C(new_n24_), .D(new_n41_), .E(p9), .Y(new_n375_));
  OR3x1_ASAP7_75t_R    g354(.A(new_n372_), .B(new_n374_), .C(new_n375_), .Y(new_n376_));
  AND3x1_ASAP7_75t_R   g355(.A(new_n263_), .B(new_n371_), .C(new_n159_), .Y(new_n377_));
  NAND2x1_ASAP7_75t_R  g356(.A(p1), .B(new_n32_), .Y(new_n378_));
  AOI221x1_ASAP7_75t_R g357(.A1(new_n211_), .A2(p2), .B1(new_n373_), .B2(new_n378_), .C(new_n24_), .Y(new_n379_));
  OA211x2_ASAP7_75t_R  g358(.A1(new_n377_), .A2(new_n379_), .B(p8), .C(new_n59_), .Y(new_n380_));
  AOI21x1_ASAP7_75t_R  g359(.A1(new_n106_), .A2(new_n376_), .B(new_n380_), .Y(new_n381_));
  AOI22x1_ASAP7_75t_R  g360(.A1(new_n127_), .A2(new_n89_), .B1(new_n53_), .B2(new_n95_), .Y(new_n382_));
  OA21x2_ASAP7_75t_R   g361(.A1(new_n195_), .A2(new_n96_), .B(new_n382_), .Y(new_n383_));
  OA21x2_ASAP7_75t_R   g362(.A1(new_n297_), .A2(new_n213_), .B(new_n193_), .Y(new_n384_));
  NAND2x1_ASAP7_75t_R  g363(.A(new_n369_), .B(new_n384_), .Y(new_n385_));
  OR5x1_ASAP7_75t_R    g364(.A(new_n32_), .B(p8), .C(p0), .D(p9), .E(p1), .Y(new_n386_));
  INVx1_ASAP7_75t_R    g365(.A(new_n120_), .Y(new_n387_));
  AO31x2_ASAP7_75t_R   g366(.A1(new_n383_), .A2(new_n385_), .A3(new_n386_), .B(new_n387_), .Y(new_n388_));
  AO21x1_ASAP7_75t_R   g367(.A1(new_n24_), .A2(new_n323_), .B(new_n26_), .Y(new_n389_));
  NOR2x1_ASAP7_75t_R   g368(.A(p5), .B(new_n25_), .Y(new_n390_));
  AO21x1_ASAP7_75t_R   g369(.A1(p8), .A2(new_n24_), .B(new_n59_), .Y(new_n391_));
  AO21x1_ASAP7_75t_R   g370(.A1(new_n199_), .A2(new_n165_), .B(new_n391_), .Y(new_n392_));
  AO221x2_ASAP7_75t_R  g371(.A1(new_n389_), .A2(new_n390_), .B1(new_n392_), .B2(new_n51_), .C(new_n169_), .Y(new_n393_));
  NAND3x1_ASAP7_75t_R  g372(.A(new_n381_), .B(new_n388_), .C(new_n393_), .Y(new_n394_));
  NAND2x1_ASAP7_75t_R  g373(.A(new_n28_), .B(new_n26_), .Y(new_n395_));
  AOI22x1_ASAP7_75t_R  g374(.A1(new_n177_), .A2(new_n50_), .B1(new_n132_), .B2(new_n297_), .Y(new_n396_));
  OAI21x1_ASAP7_75t_R  g375(.A1(new_n395_), .A2(new_n307_), .B(new_n396_), .Y(new_n397_));
  AND3x1_ASAP7_75t_R   g376(.A(new_n95_), .B(new_n26_), .C(new_n92_), .Y(new_n398_));
  AO21x1_ASAP7_75t_R   g377(.A1(new_n24_), .A2(new_n397_), .B(new_n398_), .Y(new_n399_));
  AO32x1_ASAP7_75t_R   g378(.A1(new_n399_), .A2(new_n89_), .A3(new_n100_), .B1(new_n32_), .B2(new_n319_), .Y(new_n400_));
  AOI21x1_ASAP7_75t_R  g379(.A1(new_n22_), .A2(new_n394_), .B(new_n400_), .Y(o8));
  AND2x2_ASAP7_75t_R   g380(.A(new_n32_), .B(new_n123_), .Y(new_n402_));
  OR3x1_ASAP7_75t_R    g381(.A(new_n402_), .B(new_n195_), .C(new_n44_), .Y(new_n403_));
  AO21x1_ASAP7_75t_R   g382(.A1(p8), .A2(p4), .B(p5), .Y(new_n404_));
  NAND2x1_ASAP7_75t_R  g383(.A(new_n404_), .B(new_n165_), .Y(new_n405_));
  OA21x2_ASAP7_75t_R   g384(.A1(new_n28_), .A2(new_n59_), .B(p2), .Y(new_n406_));
  AO221x2_ASAP7_75t_R  g385(.A1(new_n246_), .A2(new_n273_), .B1(new_n405_), .B2(new_n406_), .C(p1), .Y(new_n407_));
  AO21x1_ASAP7_75t_R   g386(.A1(new_n403_), .A2(new_n407_), .B(p0), .Y(new_n408_));
  AND3x1_ASAP7_75t_R   g387(.A(new_n387_), .B(new_n41_), .C(new_n404_), .Y(new_n409_));
  AOI21x1_ASAP7_75t_R  g388(.A1(new_n402_), .A2(new_n253_), .B(new_n409_), .Y(new_n410_));
  OA21x2_ASAP7_75t_R   g389(.A1(p2), .A2(new_n78_), .B(new_n296_), .Y(new_n411_));
  OR3x1_ASAP7_75t_R    g390(.A(new_n411_), .B(p1), .C(new_n406_), .Y(new_n412_));
  AO21x1_ASAP7_75t_R   g391(.A1(new_n410_), .A2(new_n412_), .B(new_n24_), .Y(new_n413_));
  OR3x1_ASAP7_75t_R    g392(.A(new_n160_), .B(p5), .C(new_n62_), .Y(new_n414_));
  AO21x1_ASAP7_75t_R   g393(.A1(new_n77_), .A2(new_n414_), .B(new_n285_), .Y(new_n415_));
  AO21x1_ASAP7_75t_R   g394(.A1(p1), .A2(new_n41_), .B(p4), .Y(new_n416_));
  AOI22x1_ASAP7_75t_R  g395(.A1(new_n416_), .A2(p5), .B1(new_n325_), .B2(new_n79_), .Y(new_n417_));
  OA21x2_ASAP7_75t_R   g396(.A1(new_n77_), .A2(new_n57_), .B(new_n228_), .Y(new_n418_));
  AND5x1_ASAP7_75t_R   g397(.A(new_n408_), .B(new_n413_), .C(new_n415_), .D(new_n417_), .E(new_n418_), .Y(o9));
  AO21x1_ASAP7_75t_R   g398(.A1(p0), .A2(new_n35_), .B(new_n30_), .Y(new_n420_));
  OR5x1_ASAP7_75t_R    g399(.A(p3), .B(new_n56_), .C(p4), .D(p5), .E(new_n62_), .Y(new_n421_));
  NOR2x1_ASAP7_75t_R   g400(.A(new_n91_), .B(new_n421_), .Y(new_n422_));
  AO21x1_ASAP7_75t_R   g401(.A1(new_n420_), .A2(new_n422_), .B(new_n367_), .Y(o10));
endmodule


