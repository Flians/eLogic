// Benchmark "/tmp/" written by ABC on Tue Oct 20 17:20:37 2026

module \/tmp/  ( 
    p9, p7, p2, p5, p4, p8, p0, p6, p3, p1,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10  );
  input  p9, p7, p2, p5, p4, p8, p0, p6, p3, p1;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10;
  wire new_n22_, new_n23_, new_n24_, new_n25_, new_n26_, new_n27_, new_n28_,
    new_n29_, new_n30_, new_n31_, new_n32_, new_n33_, new_n34_, new_n35_,
    new_n36_, new_n37_, new_n38_, new_n39_, new_n40_, new_n41_, new_n42_,
    new_n43_, new_n44_, new_n45_, new_n46_, new_n47_, new_n48_, new_n49_,
    new_n50_, new_n51_, new_n52_, new_n53_, new_n54_, new_n55_, new_n56_,
    new_n57_, new_n58_, new_n59_, new_n60_, new_n61_, new_n62_, new_n63_,
    new_n64_, new_n65_, new_n66_, new_n67_, new_n68_, new_n69_, new_n70_,
    new_n71_, new_n72_, new_n73_, new_n74_, new_n75_, new_n76_, new_n77_,
    new_n78_, new_n79_, new_n80_, new_n81_, new_n82_, new_n83_, new_n84_,
    new_n85_, new_n86_, new_n87_, new_n88_, new_n89_, new_n90_, new_n91_,
    new_n92_, new_n93_, new_n94_, new_n95_, new_n96_, new_n97_, new_n98_,
    new_n99_, new_n100_, new_n101_, new_n102_, new_n103_, new_n104_,
    new_n105_, new_n106_, new_n107_, new_n108_, new_n109_, new_n110_,
    new_n111_, new_n112_, new_n113_, new_n114_, new_n115_, new_n116_,
    new_n118_, new_n119_, new_n120_, new_n121_, new_n122_, new_n123_,
    new_n124_, new_n125_, new_n126_, new_n127_, new_n128_, new_n129_,
    new_n130_, new_n131_, new_n132_, new_n133_, new_n134_, new_n135_,
    new_n136_, new_n137_, new_n138_, new_n139_, new_n140_, new_n141_,
    new_n142_, new_n143_, new_n144_, new_n145_, new_n146_, new_n147_,
    new_n148_, new_n149_, new_n150_, new_n151_, new_n152_, new_n153_,
    new_n154_, new_n155_, new_n156_, new_n157_, new_n158_, new_n159_,
    new_n160_, new_n161_, new_n162_, new_n163_, new_n164_, new_n165_,
    new_n166_, new_n167_, new_n168_, new_n169_, new_n170_, new_n171_,
    new_n172_, new_n173_, new_n174_, new_n175_, new_n176_, new_n177_,
    new_n178_, new_n179_, new_n180_, new_n181_, new_n182_, new_n184_,
    new_n185_, new_n186_, new_n187_, new_n188_, new_n189_, new_n190_,
    new_n191_, new_n192_, new_n193_, new_n194_, new_n195_, new_n196_,
    new_n197_, new_n198_, new_n199_, new_n200_, new_n201_, new_n202_,
    new_n203_, new_n204_, new_n205_, new_n206_, new_n207_, new_n208_,
    new_n209_, new_n210_, new_n211_, new_n212_, new_n213_, new_n214_,
    new_n215_, new_n216_, new_n217_, new_n218_, new_n219_, new_n220_,
    new_n221_, new_n222_, new_n223_, new_n224_, new_n225_, new_n226_,
    new_n227_, new_n228_, new_n229_, new_n230_, new_n231_, new_n232_,
    new_n233_, new_n234_, new_n235_, new_n236_, new_n237_, new_n238_,
    new_n240_, new_n241_, new_n242_, new_n243_, new_n244_, new_n245_,
    new_n246_, new_n247_, new_n248_, new_n249_, new_n250_, new_n251_,
    new_n252_, new_n253_, new_n254_, new_n255_, new_n256_, new_n257_,
    new_n258_, new_n259_, new_n260_, new_n261_, new_n262_, new_n263_,
    new_n264_, new_n265_, new_n266_, new_n267_, new_n268_, new_n269_,
    new_n270_, new_n271_, new_n272_, new_n273_, new_n275_, new_n276_,
    new_n277_, new_n278_, new_n279_, new_n280_, new_n281_, new_n283_,
    new_n284_, new_n286_, new_n287_, new_n288_, new_n289_, new_n290_,
    new_n291_, new_n292_, new_n293_, new_n294_, new_n295_, new_n296_,
    new_n297_, new_n298_, new_n299_, new_n300_, new_n301_, new_n302_,
    new_n303_, new_n304_, new_n305_, new_n306_, new_n307_, new_n308_,
    new_n309_, new_n310_, new_n311_, new_n312_, new_n313_, new_n314_,
    new_n315_, new_n316_, new_n317_, new_n318_, new_n319_, new_n320_,
    new_n321_, new_n322_, new_n323_, new_n324_, new_n325_, new_n327_,
    new_n328_, new_n329_, new_n330_, new_n331_, new_n332_, new_n333_,
    new_n334_, new_n335_, new_n336_, new_n337_, new_n338_, new_n339_,
    new_n340_, new_n341_, new_n342_, new_n343_, new_n344_, new_n345_,
    new_n346_, new_n347_, new_n348_, new_n349_, new_n350_, new_n351_,
    new_n352_, new_n353_, new_n354_, new_n355_, new_n356_, new_n357_,
    new_n358_, new_n359_, new_n360_, new_n361_, new_n362_, new_n363_,
    new_n364_, new_n365_, new_n366_, new_n367_, new_n368_, new_n370_,
    new_n371_, new_n372_, new_n373_, new_n374_, new_n375_, new_n376_,
    new_n377_, new_n378_, new_n379_, new_n380_, new_n381_, new_n382_,
    new_n383_, new_n384_, new_n385_, new_n386_, new_n387_, new_n388_,
    new_n389_, new_n390_, new_n391_, new_n392_, new_n393_, new_n394_,
    new_n395_, new_n396_, new_n397_, new_n398_, new_n399_, new_n400_,
    new_n402_, new_n403_, new_n404_, new_n405_, new_n406_, new_n407_,
    new_n408_, new_n409_, new_n410_, new_n411_, new_n412_, new_n413_,
    new_n414_, new_n415_, new_n416_, new_n417_, new_n418_, new_n420_,
    new_n421_;
  INVx1_ASAP7_75t_R    g000(.A(p4), .Y(new_n22_));
  INVx1_ASAP7_75t_R    g001(.A(p7), .Y(new_n23_));
  AND2x2_ASAP7_75t_R   g002(.A(p2), .B(p1), .Y(new_n24_));
  INVx1_ASAP7_75t_R    g003(.A(new_n24_), .Y(new_n25_));
  NOR2x1_ASAP7_75t_R   g004(.A(p8), .B(p0), .Y(new_n26_));
  INVx1_ASAP7_75t_R    g005(.A(p5), .Y(new_n27_));
  NAND2x1_ASAP7_75t_R  g006(.A(p2), .B(new_n27_), .Y(new_n28_));
  AO32x1_ASAP7_75t_R   g007(.A1(new_n25_), .A2(new_n26_), .A3(new_n28_), .B1(p8), .B2(p1), .Y(new_n29_));
  INVx1_ASAP7_75t_R    g008(.A(p9), .Y(new_n30_));
  AND2x2_ASAP7_75t_R   g009(.A(p8), .B(p1), .Y(new_n31_));
  NOR2x1_ASAP7_75t_R   g010(.A(p2), .B(p0), .Y(new_n32_));
  NAND2x1_ASAP7_75t_R  g011(.A(p0), .B(new_n23_), .Y(new_n33_));
  INVx1_ASAP7_75t_R    g012(.A(new_n33_), .Y(new_n34_));
  AO21x1_ASAP7_75t_R   g013(.A1(new_n31_), .A2(new_n32_), .B(new_n34_), .Y(new_n35_));
  AO22x1_ASAP7_75t_R   g014(.A1(new_n23_), .A2(new_n29_), .B1(new_n30_), .B2(new_n35_), .Y(new_n36_));
  NAND2x1_ASAP7_75t_R  g015(.A(p8), .B(new_n30_), .Y(new_n37_));
  INVx1_ASAP7_75t_R    g016(.A(p8), .Y(new_n38_));
  NAND2x1_ASAP7_75t_R  g017(.A(p9), .B(new_n38_), .Y(new_n39_));
  INVx1_ASAP7_75t_R    g018(.A(p0), .Y(new_n40_));
  NAND2x1_ASAP7_75t_R  g019(.A(p1), .B(new_n40_), .Y(new_n41_));
  OA21x2_ASAP7_75t_R   g020(.A1(new_n39_), .A2(new_n41_), .B(new_n33_), .Y(new_n42_));
  OA21x2_ASAP7_75t_R   g021(.A1(p7), .A2(new_n37_), .B(new_n42_), .Y(new_n43_));
  AND5x1_ASAP7_75t_R   g022(.A(p4), .B(new_n37_), .C(new_n39_), .D(p0), .E(p1), .Y(new_n44_));
  NAND2x1_ASAP7_75t_R  g023(.A(p7), .B(p5), .Y(new_n45_));
  INVx1_ASAP7_75t_R    g024(.A(new_n45_), .Y(new_n46_));
  NOR2x1_ASAP7_75t_R   g025(.A(p0), .B(p1), .Y(new_n47_));
  NOR2x1_ASAP7_75t_R   g026(.A(p9), .B(new_n38_), .Y(new_n48_));
  AO21x1_ASAP7_75t_R   g027(.A1(new_n47_), .A2(new_n48_), .B(p4), .Y(new_n49_));
  AOI22x1_ASAP7_75t_R  g028(.A1(new_n44_), .A2(p7), .B1(new_n46_), .B2(new_n49_), .Y(new_n50_));
  OAI21x1_ASAP7_75t_R  g029(.A1(p4), .A2(new_n43_), .B(new_n50_), .Y(new_n51_));
  INVx1_ASAP7_75t_R    g030(.A(p2), .Y(new_n52_));
  NAND2x1_ASAP7_75t_R  g031(.A(p0), .B(new_n52_), .Y(new_n53_));
  INVx1_ASAP7_75t_R    g032(.A(p1), .Y(new_n54_));
  OA211x2_ASAP7_75t_R  g033(.A1(new_n48_), .A2(new_n53_), .B(new_n39_), .C(new_n54_), .Y(new_n55_));
  AO21x1_ASAP7_75t_R   g034(.A1(p9), .A2(new_n38_), .B(p1), .Y(new_n56_));
  NAND2x1_ASAP7_75t_R  g035(.A(p7), .B(p4), .Y(new_n57_));
  AO21x1_ASAP7_75t_R   g036(.A1(new_n27_), .A2(new_n56_), .B(new_n57_), .Y(new_n58_));
  NOR2x1_ASAP7_75t_R   g037(.A(p2), .B(p1), .Y(new_n59_));
  INVx1_ASAP7_75t_R    g038(.A(new_n59_), .Y(new_n60_));
  OR3x1_ASAP7_75t_R    g039(.A(p7), .B(p8), .C(p0), .Y(new_n61_));
  OR3x1_ASAP7_75t_R    g040(.A(new_n60_), .B(p9), .C(new_n61_), .Y(new_n62_));
  INVx1_ASAP7_75t_R    g041(.A(new_n31_), .Y(new_n63_));
  NOR2x1_ASAP7_75t_R   g042(.A(p8), .B(p1), .Y(new_n64_));
  NAND2x1_ASAP7_75t_R  g043(.A(p0), .B(new_n64_), .Y(new_n65_));
  OR3x1_ASAP7_75t_R    g044(.A(new_n45_), .B(p9), .C(p2), .Y(new_n66_));
  AO21x1_ASAP7_75t_R   g045(.A1(new_n63_), .A2(new_n65_), .B(new_n66_), .Y(new_n67_));
  AND2x2_ASAP7_75t_R   g046(.A(new_n62_), .B(new_n67_), .Y(new_n68_));
  OAI21x1_ASAP7_75t_R  g047(.A1(new_n55_), .A2(new_n58_), .B(new_n68_), .Y(new_n69_));
  AOI221x1_ASAP7_75t_R g048(.A1(new_n22_), .A2(new_n36_), .B1(p2), .B2(new_n51_), .C(new_n69_), .Y(new_n70_));
  NOR2x1_ASAP7_75t_R   g049(.A(p6), .B(p3), .Y(new_n71_));
  INVx1_ASAP7_75t_R    g050(.A(new_n71_), .Y(new_n72_));
  NAND2x1_ASAP7_75t_R  g051(.A(p0), .B(p1), .Y(new_n73_));
  AO21x1_ASAP7_75t_R   g052(.A1(new_n22_), .A2(new_n54_), .B(p9), .Y(new_n74_));
  AO21x1_ASAP7_75t_R   g053(.A1(new_n73_), .A2(new_n74_), .B(p8), .Y(new_n75_));
  OR3x1_ASAP7_75t_R    g054(.A(new_n59_), .B(new_n38_), .C(p0), .Y(new_n76_));
  OR3x1_ASAP7_75t_R    g055(.A(new_n30_), .B(new_n52_), .C(p0), .Y(new_n77_));
  AND3x1_ASAP7_75t_R   g056(.A(new_n76_), .B(new_n53_), .C(new_n77_), .Y(new_n78_));
  AO21x1_ASAP7_75t_R   g057(.A1(new_n75_), .A2(new_n78_), .B(p6), .Y(new_n79_));
  NAND2x1_ASAP7_75t_R  g058(.A(p8), .B(new_n40_), .Y(new_n80_));
  NAND2x1_ASAP7_75t_R  g059(.A(p4), .B(new_n40_), .Y(new_n81_));
  NOR2x1_ASAP7_75t_R   g060(.A(p1), .B(new_n30_), .Y(new_n82_));
  AND3x1_ASAP7_75t_R   g061(.A(new_n26_), .B(new_n30_), .C(p1), .Y(new_n83_));
  AO32x1_ASAP7_75t_R   g062(.A1(new_n80_), .A2(new_n81_), .A3(new_n82_), .B1(new_n83_), .B2(p6), .Y(new_n84_));
  NOR2x1_ASAP7_75t_R   g063(.A(p4), .B(new_n23_), .Y(new_n85_));
  INVx1_ASAP7_75t_R    g064(.A(new_n85_), .Y(new_n86_));
  NAND2x1_ASAP7_75t_R  g065(.A(new_n22_), .B(new_n38_), .Y(new_n87_));
  NAND2x1_ASAP7_75t_R  g066(.A(p9), .B(new_n54_), .Y(new_n88_));
  AO21x1_ASAP7_75t_R   g067(.A1(p6), .A2(new_n87_), .B(new_n88_), .Y(new_n89_));
  INVx1_ASAP7_75t_R    g068(.A(p6), .Y(new_n90_));
  NOR2x1_ASAP7_75t_R   g069(.A(p8), .B(new_n40_), .Y(new_n91_));
  AO21x1_ASAP7_75t_R   g070(.A1(new_n90_), .A2(new_n91_), .B(p2), .Y(new_n92_));
  AOI21x1_ASAP7_75t_R  g071(.A1(new_n86_), .A2(new_n89_), .B(new_n92_), .Y(new_n93_));
  NAND2x1_ASAP7_75t_R  g072(.A(p9), .B(p0), .Y(new_n94_));
  NOR2x1_ASAP7_75t_R   g073(.A(p2), .B(p4), .Y(new_n95_));
  NAND2x1_ASAP7_75t_R  g074(.A(new_n94_), .B(new_n95_), .Y(new_n96_));
  AO21x1_ASAP7_75t_R   g075(.A1(new_n30_), .A2(new_n40_), .B(p6), .Y(new_n97_));
  NOR2x1_ASAP7_75t_R   g076(.A(p7), .B(p1), .Y(new_n98_));
  INVx1_ASAP7_75t_R    g077(.A(new_n98_), .Y(new_n99_));
  AND2x2_ASAP7_75t_R   g078(.A(p8), .B(p0), .Y(new_n100_));
  NOR2x1_ASAP7_75t_R   g079(.A(new_n26_), .B(new_n100_), .Y(new_n101_));
  AOI211x1_ASAP7_75t_R g080(.A1(new_n96_), .A2(new_n97_), .B(new_n99_), .C(new_n101_), .Y(new_n102_));
  AOI21x1_ASAP7_75t_R  g081(.A1(new_n84_), .A2(new_n93_), .B(new_n102_), .Y(new_n103_));
  OAI21x1_ASAP7_75t_R  g082(.A1(p7), .A2(new_n79_), .B(new_n103_), .Y(new_n104_));
  NOR2x1_ASAP7_75t_R   g083(.A(p5), .B(p3), .Y(new_n105_));
  NOR2x1_ASAP7_75t_R   g084(.A(p5), .B(p8), .Y(new_n106_));
  INVx1_ASAP7_75t_R    g085(.A(new_n106_), .Y(new_n107_));
  NAND2x1_ASAP7_75t_R  g086(.A(p5), .B(p4), .Y(new_n108_));
  OA21x2_ASAP7_75t_R   g087(.A1(new_n38_), .A2(p3), .B(new_n108_), .Y(new_n109_));
  NAND2x1_ASAP7_75t_R  g088(.A(p4), .B(new_n23_), .Y(new_n110_));
  NAND2x1_ASAP7_75t_R  g089(.A(new_n108_), .B(new_n110_), .Y(new_n111_));
  AO21x1_ASAP7_75t_R   g090(.A1(p7), .A2(p3), .B(new_n106_), .Y(new_n112_));
  AO32x1_ASAP7_75t_R   g091(.A1(new_n23_), .A2(new_n107_), .A3(new_n109_), .B1(new_n111_), .B2(new_n112_), .Y(new_n113_));
  AND3x1_ASAP7_75t_R   g092(.A(new_n30_), .B(new_n40_), .C(new_n54_), .Y(new_n114_));
  AND3x1_ASAP7_75t_R   g093(.A(new_n114_), .B(new_n52_), .C(new_n90_), .Y(new_n115_));
  AOI22x1_ASAP7_75t_R  g094(.A1(new_n104_), .A2(new_n105_), .B1(new_n113_), .B2(new_n115_), .Y(new_n116_));
  OAI21x1_ASAP7_75t_R  g095(.A1(new_n70_), .A2(new_n72_), .B(new_n116_), .Y(o0));
  OR3x1_ASAP7_75t_R    g096(.A(new_n107_), .B(new_n23_), .C(new_n54_), .Y(new_n118_));
  NOR2x1_ASAP7_75t_R   g097(.A(p9), .B(p7), .Y(new_n119_));
  NAND2x1_ASAP7_75t_R  g098(.A(new_n119_), .B(new_n64_), .Y(new_n120_));
  AND2x2_ASAP7_75t_R   g099(.A(p9), .B(p7), .Y(new_n121_));
  NAND2x1_ASAP7_75t_R  g100(.A(new_n31_), .B(new_n121_), .Y(new_n122_));
  AO21x1_ASAP7_75t_R   g101(.A1(new_n120_), .A2(new_n122_), .B(new_n81_), .Y(new_n123_));
  AND2x2_ASAP7_75t_R   g102(.A(new_n118_), .B(new_n123_), .Y(new_n124_));
  NAND2x1_ASAP7_75t_R  g103(.A(p7), .B(p8), .Y(new_n125_));
  OR3x1_ASAP7_75t_R    g104(.A(p7), .B(p4), .C(p8), .Y(new_n126_));
  OA21x2_ASAP7_75t_R   g105(.A1(new_n27_), .A2(new_n125_), .B(new_n126_), .Y(new_n127_));
  AO21x1_ASAP7_75t_R   g106(.A1(p5), .A2(p8), .B(new_n85_), .Y(new_n128_));
  NAND2x1_ASAP7_75t_R  g107(.A(new_n30_), .B(new_n128_), .Y(new_n129_));
  AO21x1_ASAP7_75t_R   g108(.A1(new_n127_), .A2(new_n129_), .B(new_n41_), .Y(new_n130_));
  NAND2x1_ASAP7_75t_R  g109(.A(new_n124_), .B(new_n130_), .Y(new_n131_));
  AO21x1_ASAP7_75t_R   g110(.A1(p5), .A2(new_n30_), .B(p1), .Y(new_n132_));
  NOR2x1_ASAP7_75t_R   g111(.A(p7), .B(p5), .Y(new_n133_));
  AO21x1_ASAP7_75t_R   g112(.A1(new_n85_), .A2(new_n132_), .B(new_n133_), .Y(new_n134_));
  AND3x1_ASAP7_75t_R   g113(.A(new_n45_), .B(p9), .C(new_n54_), .Y(new_n135_));
  AO32x1_ASAP7_75t_R   g114(.A1(p4), .A2(new_n48_), .A3(new_n98_), .B1(new_n128_), .B2(new_n135_), .Y(new_n136_));
  AO22x1_ASAP7_75t_R   g115(.A1(new_n91_), .A2(new_n134_), .B1(p0), .B2(new_n136_), .Y(new_n137_));
  INVx1_ASAP7_75t_R    g116(.A(p3), .Y(new_n138_));
  AND3x1_ASAP7_75t_R   g117(.A(new_n52_), .B(new_n90_), .C(new_n138_), .Y(new_n139_));
  OAI21x1_ASAP7_75t_R  g118(.A1(new_n131_), .A2(new_n137_), .B(new_n139_), .Y(new_n140_));
  NOR2x1_ASAP7_75t_R   g119(.A(p9), .B(new_n22_), .Y(new_n141_));
  NOR2x1_ASAP7_75t_R   g120(.A(p4), .B(new_n30_), .Y(new_n142_));
  OA21x2_ASAP7_75t_R   g121(.A1(new_n141_), .A2(new_n142_), .B(p0), .Y(new_n143_));
  NAND2x1_ASAP7_75t_R  g122(.A(p9), .B(p7), .Y(new_n144_));
  NOR2x1_ASAP7_75t_R   g123(.A(p1), .B(new_n144_), .Y(new_n145_));
  AO32x1_ASAP7_75t_R   g124(.A1(new_n30_), .A2(new_n60_), .A3(new_n99_), .B1(new_n145_), .B2(p0), .Y(new_n146_));
  OA21x2_ASAP7_75t_R   g125(.A1(new_n143_), .A2(new_n146_), .B(new_n27_), .Y(new_n147_));
  NOR2x1_ASAP7_75t_R   g126(.A(p5), .B(p0), .Y(new_n148_));
  NOR2x1_ASAP7_75t_R   g127(.A(p7), .B(p2), .Y(new_n149_));
  AO21x1_ASAP7_75t_R   g128(.A1(p7), .A2(new_n22_), .B(new_n149_), .Y(new_n150_));
  OAI22x1_ASAP7_75t_R  g129(.A1(new_n150_), .A2(new_n30_), .B1(new_n22_), .B2(new_n99_), .Y(new_n151_));
  INVx1_ASAP7_75t_R    g130(.A(new_n94_), .Y(new_n152_));
  NOR2x1_ASAP7_75t_R   g131(.A(p9), .B(new_n23_), .Y(new_n153_));
  OR5x1_ASAP7_75t_R    g132(.A(p4), .B(new_n152_), .C(new_n153_), .D(p1), .E(new_n148_), .Y(new_n154_));
  NOR2x1_ASAP7_75t_R   g133(.A(p5), .B(new_n54_), .Y(new_n155_));
  NAND2x1_ASAP7_75t_R  g134(.A(p2), .B(new_n22_), .Y(new_n156_));
  NOR2x1_ASAP7_75t_R   g135(.A(p7), .B(p0), .Y(new_n157_));
  AND2x2_ASAP7_75t_R   g136(.A(p0), .B(p1), .Y(new_n158_));
  OR4x2_ASAP7_75t_R    g137(.A(new_n155_), .B(new_n156_), .C(new_n157_), .D(new_n158_), .Y(new_n159_));
  NAND3x1_ASAP7_75t_R  g138(.A(new_n154_), .B(new_n159_), .C(new_n38_), .Y(new_n160_));
  AO21x1_ASAP7_75t_R   g139(.A1(new_n148_), .A2(new_n151_), .B(new_n160_), .Y(new_n161_));
  NAND2x1_ASAP7_75t_R  g140(.A(p2), .B(new_n40_), .Y(new_n162_));
  NAND2x1_ASAP7_75t_R  g141(.A(p4), .B(p0), .Y(new_n163_));
  OA21x2_ASAP7_75t_R   g142(.A1(new_n162_), .A2(new_n99_), .B(new_n163_), .Y(new_n164_));
  OR3x1_ASAP7_75t_R    g143(.A(new_n164_), .B(new_n30_), .C(new_n27_), .Y(new_n165_));
  NAND2x1_ASAP7_75t_R  g144(.A(p4), .B(p1), .Y(new_n166_));
  NAND2x1_ASAP7_75t_R  g145(.A(p2), .B(p4), .Y(new_n167_));
  OA211x2_ASAP7_75t_R  g146(.A1(new_n52_), .A2(new_n73_), .B(new_n166_), .C(new_n167_), .Y(new_n168_));
  OR3x1_ASAP7_75t_R    g147(.A(new_n110_), .B(new_n52_), .C(new_n73_), .Y(new_n169_));
  OA211x2_ASAP7_75t_R  g148(.A1(new_n27_), .A2(new_n168_), .B(new_n169_), .C(p8), .Y(new_n170_));
  AOI21x1_ASAP7_75t_R  g149(.A1(new_n165_), .A2(new_n170_), .B(new_n72_), .Y(new_n171_));
  OAI21x1_ASAP7_75t_R  g150(.A1(new_n147_), .A2(new_n161_), .B(new_n171_), .Y(new_n172_));
  OA211x2_ASAP7_75t_R  g151(.A1(new_n119_), .A2(new_n98_), .B(new_n73_), .C(p6), .Y(new_n173_));
  OA21x2_ASAP7_75t_R   g152(.A1(new_n56_), .A2(new_n152_), .B(new_n173_), .Y(new_n174_));
  NOR2x1_ASAP7_75t_R   g153(.A(p1), .B(new_n23_), .Y(new_n175_));
  AND3x1_ASAP7_75t_R   g154(.A(new_n91_), .B(new_n175_), .C(p6), .Y(new_n176_));
  OR3x1_ASAP7_75t_R    g155(.A(new_n174_), .B(new_n83_), .C(new_n176_), .Y(new_n177_));
  AND3x1_ASAP7_75t_R   g156(.A(new_n95_), .B(new_n27_), .C(new_n138_), .Y(new_n178_));
  OAI21x1_ASAP7_75t_R  g157(.A1(new_n23_), .A2(new_n138_), .B(new_n110_), .Y(new_n179_));
  AND3x1_ASAP7_75t_R   g158(.A(p5), .B(p8), .C(p3), .Y(new_n180_));
  AO21x1_ASAP7_75t_R   g159(.A1(new_n106_), .A2(new_n179_), .B(new_n180_), .Y(new_n181_));
  AOI22x1_ASAP7_75t_R  g160(.A1(new_n177_), .A2(new_n178_), .B1(new_n115_), .B2(new_n181_), .Y(new_n182_));
  NAND3x1_ASAP7_75t_R  g161(.A(new_n140_), .B(new_n172_), .C(new_n182_), .Y(o1));
  AND3x1_ASAP7_75t_R   g162(.A(new_n27_), .B(new_n90_), .C(new_n138_), .Y(new_n184_));
  NOR2x1_ASAP7_75t_R   g163(.A(p2), .B(new_n54_), .Y(new_n185_));
  NOR2x1_ASAP7_75t_R   g164(.A(p7), .B(p8), .Y(new_n186_));
  INVx1_ASAP7_75t_R    g165(.A(new_n186_), .Y(new_n187_));
  AO21x1_ASAP7_75t_R   g166(.A1(new_n125_), .A2(new_n187_), .B(new_n26_), .Y(new_n188_));
  AND3x1_ASAP7_75t_R   g167(.A(p9), .B(p7), .C(p8), .Y(new_n189_));
  OR3x1_ASAP7_75t_R    g168(.A(new_n189_), .B(new_n22_), .C(new_n186_), .Y(new_n190_));
  OA211x2_ASAP7_75t_R  g169(.A1(p4), .A2(new_n31_), .B(new_n52_), .C(p0), .Y(new_n191_));
  NAND2x1_ASAP7_75t_R  g170(.A(p9), .B(new_n22_), .Y(new_n192_));
  OR3x1_ASAP7_75t_R    g171(.A(p7), .B(p8), .C(p1), .Y(new_n193_));
  AO21x1_ASAP7_75t_R   g172(.A1(new_n192_), .A2(new_n77_), .B(new_n193_), .Y(new_n194_));
  OAI21x1_ASAP7_75t_R  g173(.A1(new_n76_), .A2(new_n144_), .B(new_n194_), .Y(new_n195_));
  AO221x2_ASAP7_75t_R  g174(.A1(new_n185_), .A2(new_n188_), .B1(new_n190_), .B2(new_n191_), .C(new_n195_), .Y(new_n196_));
  AND2x2_ASAP7_75t_R   g175(.A(p7), .B(p8), .Y(new_n197_));
  AO21x1_ASAP7_75t_R   g176(.A1(p6), .A2(new_n197_), .B(new_n30_), .Y(new_n198_));
  NOR2x1_ASAP7_75t_R   g177(.A(p8), .B(new_n30_), .Y(new_n199_));
  AO32x1_ASAP7_75t_R   g178(.A1(new_n198_), .A2(p0), .A3(new_n37_), .B1(new_n199_), .B2(new_n157_), .Y(new_n200_));
  AND3x1_ASAP7_75t_R   g179(.A(new_n200_), .B(new_n54_), .C(new_n178_), .Y(new_n201_));
  AOI21x1_ASAP7_75t_R  g180(.A1(new_n184_), .A2(new_n196_), .B(new_n201_), .Y(new_n202_));
  AND2x2_ASAP7_75t_R   g181(.A(p5), .B(p1), .Y(new_n203_));
  NOR2x1_ASAP7_75t_R   g182(.A(p0), .B(new_n45_), .Y(new_n204_));
  AO21x1_ASAP7_75t_R   g183(.A1(new_n100_), .A2(new_n203_), .B(new_n204_), .Y(new_n205_));
  AND3x1_ASAP7_75t_R   g184(.A(new_n23_), .B(new_n38_), .C(p1), .Y(new_n206_));
  NOR2x1_ASAP7_75t_R   g185(.A(p8), .B(new_n54_), .Y(new_n207_));
  NOR2x1_ASAP7_75t_R   g186(.A(new_n23_), .B(new_n207_), .Y(new_n208_));
  OR3x1_ASAP7_75t_R    g187(.A(new_n205_), .B(new_n206_), .C(new_n208_), .Y(new_n209_));
  NAND2x1_ASAP7_75t_R  g188(.A(p0), .B(new_n38_), .Y(new_n210_));
  AO21x1_ASAP7_75t_R   g189(.A1(new_n149_), .A2(new_n210_), .B(new_n46_), .Y(new_n211_));
  NAND2x1_ASAP7_75t_R  g190(.A(p7), .B(p0), .Y(new_n212_));
  NOR2x1_ASAP7_75t_R   g191(.A(p8), .B(new_n212_), .Y(new_n213_));
  AO21x1_ASAP7_75t_R   g192(.A1(new_n80_), .A2(new_n211_), .B(new_n213_), .Y(new_n214_));
  AOI22x1_ASAP7_75t_R  g193(.A1(new_n209_), .A2(p2), .B1(new_n214_), .B2(new_n54_), .Y(new_n215_));
  OR3x1_ASAP7_75t_R    g194(.A(new_n215_), .B(new_n72_), .C(new_n192_), .Y(new_n216_));
  AND3x1_ASAP7_75t_R   g195(.A(new_n186_), .B(p5), .C(new_n22_), .Y(new_n217_));
  NOR2x1_ASAP7_75t_R   g196(.A(p7), .B(new_n52_), .Y(new_n218_));
  NAND2x1_ASAP7_75t_R  g197(.A(p2), .B(new_n38_), .Y(new_n219_));
  OA211x2_ASAP7_75t_R  g198(.A1(new_n91_), .A2(new_n218_), .B(new_n219_), .C(new_n27_), .Y(new_n220_));
  AND3x1_ASAP7_75t_R   g199(.A(new_n60_), .B(new_n99_), .C(p4), .Y(new_n221_));
  OA21x2_ASAP7_75t_R   g200(.A1(new_n203_), .A2(new_n212_), .B(new_n221_), .Y(new_n222_));
  AOI211x1_ASAP7_75t_R g201(.A1(new_n32_), .A2(new_n217_), .B(new_n220_), .C(new_n222_), .Y(new_n223_));
  AO21x1_ASAP7_75t_R   g202(.A1(p2), .A2(new_n54_), .B(new_n23_), .Y(new_n224_));
  INVx1_ASAP7_75t_R    g203(.A(new_n175_), .Y(new_n225_));
  AND2x2_ASAP7_75t_R   g204(.A(p2), .B(p4), .Y(new_n226_));
  AO221x2_ASAP7_75t_R  g205(.A1(new_n22_), .A2(new_n224_), .B1(new_n225_), .B2(new_n226_), .C(new_n210_), .Y(new_n227_));
  AO21x1_ASAP7_75t_R   g206(.A1(p5), .A2(new_n212_), .B(p8), .Y(new_n228_));
  AO32x1_ASAP7_75t_R   g207(.A1(new_n218_), .A2(p8), .A3(new_n40_), .B1(p2), .B2(new_n54_), .Y(new_n229_));
  NAND2x1_ASAP7_75t_R  g208(.A(p5), .B(new_n23_), .Y(new_n230_));
  OR3x1_ASAP7_75t_R    g209(.A(new_n38_), .B(new_n40_), .C(p2), .Y(new_n231_));
  OAI21x1_ASAP7_75t_R  g210(.A1(new_n230_), .A2(new_n231_), .B(new_n138_), .Y(new_n232_));
  AOI21x1_ASAP7_75t_R  g211(.A1(new_n228_), .A2(new_n229_), .B(new_n232_), .Y(new_n233_));
  AO21x1_ASAP7_75t_R   g212(.A1(new_n125_), .A2(new_n230_), .B(p4), .Y(new_n234_));
  AO21x1_ASAP7_75t_R   g213(.A1(new_n54_), .A2(new_n32_), .B(new_n138_), .Y(new_n235_));
  AND3x1_ASAP7_75t_R   g214(.A(new_n235_), .B(new_n30_), .C(new_n90_), .Y(new_n236_));
  OAI21x1_ASAP7_75t_R  g215(.A1(new_n138_), .A2(new_n234_), .B(new_n236_), .Y(new_n237_));
  AO31x2_ASAP7_75t_R   g216(.A1(new_n223_), .A2(new_n227_), .A3(new_n233_), .B(new_n237_), .Y(new_n238_));
  NAND3x1_ASAP7_75t_R  g217(.A(new_n202_), .B(new_n216_), .C(new_n238_), .Y(o2));
  AO21x1_ASAP7_75t_R   g218(.A1(new_n52_), .A2(new_n230_), .B(new_n111_), .Y(new_n240_));
  OR3x1_ASAP7_75t_R    g219(.A(new_n57_), .B(p5), .C(new_n38_), .Y(new_n241_));
  AO21x1_ASAP7_75t_R   g220(.A1(new_n126_), .A2(new_n241_), .B(new_n73_), .Y(new_n242_));
  INVx1_ASAP7_75t_R    g221(.A(new_n162_), .Y(new_n243_));
  NAND2x1_ASAP7_75t_R  g222(.A(p8), .B(new_n27_), .Y(new_n244_));
  AOI22x1_ASAP7_75t_R  g223(.A1(new_n243_), .A2(new_n244_), .B1(new_n163_), .B2(new_n203_), .Y(new_n245_));
  OA211x2_ASAP7_75t_R  g224(.A1(new_n40_), .A2(new_n240_), .B(new_n242_), .C(new_n245_), .Y(new_n246_));
  NOR2x1_ASAP7_75t_R   g225(.A(p5), .B(p4), .Y(new_n247_));
  INVx1_ASAP7_75t_R    g226(.A(new_n247_), .Y(new_n248_));
  AND2x2_ASAP7_75t_R   g227(.A(new_n108_), .B(new_n248_), .Y(new_n249_));
  AND2x2_ASAP7_75t_R   g228(.A(new_n22_), .B(new_n125_), .Y(new_n250_));
  NOR2x1_ASAP7_75t_R   g229(.A(p2), .B(new_n138_), .Y(new_n251_));
  INVx1_ASAP7_75t_R    g230(.A(new_n251_), .Y(new_n252_));
  OR5x1_ASAP7_75t_R    g231(.A(p0), .B(new_n249_), .C(p1), .D(new_n250_), .E(new_n252_), .Y(new_n253_));
  OAI21x1_ASAP7_75t_R  g232(.A1(p3), .A2(new_n246_), .B(new_n253_), .Y(new_n254_));
  NOR2x1_ASAP7_75t_R   g233(.A(p1), .B(new_n22_), .Y(new_n255_));
  NOR2x1_ASAP7_75t_R   g234(.A(new_n186_), .B(new_n197_), .Y(new_n256_));
  NOR2x1_ASAP7_75t_R   g235(.A(p1), .B(new_n52_), .Y(new_n257_));
  AO21x1_ASAP7_75t_R   g236(.A1(new_n255_), .A2(new_n256_), .B(new_n257_), .Y(new_n258_));
  OA21x2_ASAP7_75t_R   g237(.A1(p5), .A2(new_n218_), .B(new_n156_), .Y(new_n259_));
  AO21x1_ASAP7_75t_R   g238(.A1(new_n207_), .A2(new_n150_), .B(new_n259_), .Y(new_n260_));
  OAI21x1_ASAP7_75t_R  g239(.A1(new_n258_), .A2(new_n260_), .B(new_n152_), .Y(new_n261_));
  AO21x1_ASAP7_75t_R   g240(.A1(new_n22_), .A2(new_n38_), .B(new_n133_), .Y(new_n262_));
  AO32x1_ASAP7_75t_R   g241(.A1(p5), .A2(new_n22_), .A3(new_n213_), .B1(new_n262_), .B2(new_n257_), .Y(new_n263_));
  AND2x2_ASAP7_75t_R   g242(.A(p7), .B(p4), .Y(new_n264_));
  AO21x1_ASAP7_75t_R   g243(.A1(new_n27_), .A2(new_n22_), .B(new_n106_), .Y(new_n265_));
  OA211x2_ASAP7_75t_R  g244(.A1(new_n264_), .A2(new_n100_), .B(new_n265_), .C(p2), .Y(new_n266_));
  AOI211x1_ASAP7_75t_R g245(.A1(new_n40_), .A2(new_n217_), .B(new_n263_), .C(new_n266_), .Y(new_n267_));
  AO32x1_ASAP7_75t_R   g246(.A1(new_n98_), .A2(new_n148_), .A3(p4), .B1(p5), .B2(new_n95_), .Y(new_n268_));
  NAND2x1_ASAP7_75t_R  g247(.A(p5), .B(new_n22_), .Y(new_n269_));
  OR3x1_ASAP7_75t_R    g248(.A(new_n52_), .B(new_n54_), .C(p5), .Y(new_n270_));
  AOI21x1_ASAP7_75t_R  g249(.A1(new_n269_), .A2(new_n270_), .B(new_n76_), .Y(new_n271_));
  AOI221x1_ASAP7_75t_R g250(.A1(new_n199_), .A2(new_n268_), .B1(new_n243_), .B2(new_n133_), .C(new_n271_), .Y(new_n272_));
  NAND3x1_ASAP7_75t_R  g251(.A(new_n261_), .B(new_n267_), .C(new_n272_), .Y(new_n273_));
  AO32x1_ASAP7_75t_R   g252(.A1(new_n254_), .A2(new_n30_), .A3(new_n90_), .B1(new_n71_), .B2(new_n273_), .Y(o3));
  NOR2x1_ASAP7_75t_R   g253(.A(p9), .B(p0), .Y(new_n275_));
  INVx1_ASAP7_75t_R    g254(.A(new_n275_), .Y(new_n276_));
  AND3x1_ASAP7_75t_R   g255(.A(new_n276_), .B(new_n138_), .C(p1), .Y(new_n277_));
  NAND2x1_ASAP7_75t_R  g256(.A(p2), .B(new_n138_), .Y(new_n278_));
  INVx1_ASAP7_75t_R    g257(.A(new_n114_), .Y(new_n279_));
  AOI21x1_ASAP7_75t_R  g258(.A1(new_n252_), .A2(new_n278_), .B(new_n279_), .Y(new_n280_));
  NOR2x1_ASAP7_75t_R   g259(.A(p6), .B(new_n108_), .Y(new_n281_));
  OA21x2_ASAP7_75t_R   g260(.A1(new_n277_), .A2(new_n280_), .B(new_n281_), .Y(o4));
  AND3x1_ASAP7_75t_R   g261(.A(new_n275_), .B(new_n59_), .C(p3), .Y(new_n283_));
  NOR2x1_ASAP7_75t_R   g262(.A(new_n278_), .B(new_n114_), .Y(new_n284_));
  OA21x2_ASAP7_75t_R   g263(.A1(new_n283_), .A2(new_n284_), .B(new_n281_), .Y(o5));
  XNOR2x2_ASAP7_75t_R  g264(.A(p7), .B(p1), .Y(new_n286_));
  NOR2x1_ASAP7_75t_R   g265(.A(new_n27_), .B(new_n256_), .Y(new_n287_));
  AND3x1_ASAP7_75t_R   g266(.A(new_n73_), .B(new_n27_), .C(new_n38_), .Y(new_n288_));
  AND3x1_ASAP7_75t_R   g267(.A(new_n30_), .B(p7), .C(p1), .Y(new_n289_));
  AO32x1_ASAP7_75t_R   g268(.A1(new_n288_), .A2(new_n166_), .A3(new_n121_), .B1(new_n87_), .B2(new_n289_), .Y(new_n290_));
  NAND2x1_ASAP7_75t_R  g269(.A(new_n100_), .B(new_n121_), .Y(new_n291_));
  OA21x2_ASAP7_75t_R   g270(.A1(new_n54_), .A2(new_n37_), .B(new_n61_), .Y(new_n292_));
  AOI21x1_ASAP7_75t_R  g271(.A1(new_n291_), .A2(new_n292_), .B(new_n22_), .Y(new_n293_));
  AOI211x1_ASAP7_75t_R g272(.A1(new_n286_), .A2(new_n287_), .B(new_n290_), .C(new_n293_), .Y(new_n294_));
  NAND2x1_ASAP7_75t_R  g273(.A(p6), .B(new_n54_), .Y(new_n295_));
  AO21x1_ASAP7_75t_R   g274(.A1(new_n187_), .A2(new_n291_), .B(new_n295_), .Y(new_n296_));
  NAND2x1_ASAP7_75t_R  g275(.A(p6), .B(new_n38_), .Y(new_n297_));
  AO21x1_ASAP7_75t_R   g276(.A1(p7), .A2(new_n297_), .B(new_n41_), .Y(new_n298_));
  AO21x1_ASAP7_75t_R   g277(.A1(new_n65_), .A2(new_n298_), .B(p9), .Y(new_n299_));
  AO21x1_ASAP7_75t_R   g278(.A1(new_n296_), .A2(new_n299_), .B(new_n248_), .Y(new_n300_));
  OAI21x1_ASAP7_75t_R  g279(.A1(p6), .A2(new_n294_), .B(new_n300_), .Y(new_n301_));
  NOR2x1_ASAP7_75t_R   g280(.A(p2), .B(p3), .Y(new_n302_));
  NOR2x1_ASAP7_75t_R   g281(.A(p9), .B(new_n54_), .Y(new_n303_));
  INVx1_ASAP7_75t_R    g282(.A(new_n303_), .Y(new_n304_));
  AO32x1_ASAP7_75t_R   g283(.A1(p9), .A2(p5), .A3(new_n175_), .B1(new_n304_), .B2(new_n34_), .Y(new_n305_));
  NOR2x1_ASAP7_75t_R   g284(.A(p9), .B(p5), .Y(new_n306_));
  AO21x1_ASAP7_75t_R   g285(.A1(p0), .A2(p1), .B(new_n306_), .Y(new_n307_));
  INVx1_ASAP7_75t_R    g286(.A(new_n157_), .Y(new_n308_));
  OA21x2_ASAP7_75t_R   g287(.A1(p0), .A2(new_n186_), .B(p9), .Y(new_n309_));
  AO32x1_ASAP7_75t_R   g288(.A1(new_n307_), .A2(new_n101_), .A3(new_n308_), .B1(new_n309_), .B2(new_n210_), .Y(new_n310_));
  OA211x2_ASAP7_75t_R  g289(.A1(p9), .A2(p7), .B(new_n91_), .C(new_n192_), .Y(new_n311_));
  AOI221x1_ASAP7_75t_R g290(.A1(new_n305_), .A2(p8), .B1(new_n22_), .B2(new_n310_), .C(new_n311_), .Y(new_n312_));
  NOR2x1_ASAP7_75t_R   g291(.A(p4), .B(new_n54_), .Y(new_n313_));
  OR3x1_ASAP7_75t_R    g292(.A(new_n313_), .B(new_n37_), .C(p5), .Y(new_n314_));
  OA211x2_ASAP7_75t_R  g293(.A1(new_n48_), .A2(new_n255_), .B(new_n34_), .C(new_n39_), .Y(new_n315_));
  AND5x1_ASAP7_75t_R   g294(.A(new_n30_), .B(new_n40_), .C(p7), .D(p8), .E(p1), .Y(new_n316_));
  INVx1_ASAP7_75t_R    g295(.A(new_n64_), .Y(new_n317_));
  OR5x1_ASAP7_75t_R    g296(.A(p0), .B(new_n317_), .C(new_n153_), .D(new_n264_), .E(new_n306_), .Y(new_n318_));
  OA21x2_ASAP7_75t_R   g297(.A1(p7), .A2(p8), .B(p1), .Y(new_n319_));
  NOR2x1_ASAP7_75t_R   g298(.A(new_n189_), .B(new_n319_), .Y(new_n320_));
  OR3x1_ASAP7_75t_R    g299(.A(new_n320_), .B(new_n27_), .C(new_n40_), .Y(new_n321_));
  NAND2x1_ASAP7_75t_R  g300(.A(new_n318_), .B(new_n321_), .Y(new_n322_));
  AOI211x1_ASAP7_75t_R g301(.A1(new_n314_), .A2(new_n315_), .B(new_n316_), .C(new_n322_), .Y(new_n323_));
  OAI21x1_ASAP7_75t_R  g302(.A1(new_n52_), .A2(new_n312_), .B(new_n323_), .Y(new_n324_));
  AO21x1_ASAP7_75t_R   g303(.A1(new_n90_), .A2(new_n283_), .B(new_n281_), .Y(new_n325_));
  AOI221x1_ASAP7_75t_R g304(.A1(new_n301_), .A2(new_n302_), .B1(new_n324_), .B2(new_n71_), .C(new_n325_), .Y(o6));
  AND3x1_ASAP7_75t_R   g305(.A(new_n187_), .B(new_n303_), .C(new_n125_), .Y(new_n327_));
  AND3x1_ASAP7_75t_R   g306(.A(new_n145_), .B(new_n38_), .C(p6), .Y(new_n328_));
  AND3x1_ASAP7_75t_R   g307(.A(new_n247_), .B(new_n52_), .C(new_n40_), .Y(new_n329_));
  OAI21x1_ASAP7_75t_R  g308(.A1(new_n327_), .A2(new_n328_), .B(new_n329_), .Y(new_n330_));
  AOI21x1_ASAP7_75t_R  g309(.A1(p6), .A2(new_n330_), .B(p3), .Y(new_n331_));
  AOI21x1_ASAP7_75t_R  g310(.A1(new_n28_), .A2(new_n230_), .B(new_n38_), .Y(new_n332_));
  NAND2x1_ASAP7_75t_R  g311(.A(p7), .B(new_n30_), .Y(new_n333_));
  NAND2x1_ASAP7_75t_R  g312(.A(new_n333_), .B(new_n230_), .Y(new_n334_));
  AOI21x1_ASAP7_75t_R  g313(.A1(p5), .A2(p8), .B(p7), .Y(new_n335_));
  AOI211x1_ASAP7_75t_R g314(.A1(new_n30_), .A2(p8), .B(new_n306_), .C(new_n335_), .Y(new_n336_));
  AOI22x1_ASAP7_75t_R  g315(.A1(new_n332_), .A2(new_n334_), .B1(new_n28_), .B2(new_n336_), .Y(new_n337_));
  AO21x1_ASAP7_75t_R   g316(.A1(p2), .A2(new_n125_), .B(new_n121_), .Y(new_n338_));
  AND3x1_ASAP7_75t_R   g317(.A(new_n106_), .B(new_n23_), .C(new_n52_), .Y(new_n339_));
  AOI221x1_ASAP7_75t_R g318(.A1(new_n185_), .A2(new_n197_), .B1(new_n338_), .B2(new_n155_), .C(new_n339_), .Y(new_n340_));
  OAI21x1_ASAP7_75t_R  g319(.A1(p1), .A2(new_n337_), .B(new_n340_), .Y(new_n341_));
  NOR2x1_ASAP7_75t_R   g320(.A(p9), .B(p8), .Y(new_n342_));
  OAI21x1_ASAP7_75t_R  g321(.A1(new_n23_), .A2(new_n342_), .B(p4), .Y(new_n343_));
  OR3x1_ASAP7_75t_R    g322(.A(new_n31_), .B(new_n30_), .C(new_n64_), .Y(new_n344_));
  OR3x1_ASAP7_75t_R    g323(.A(new_n186_), .B(new_n98_), .C(p2), .Y(new_n345_));
  AO21x1_ASAP7_75t_R   g324(.A1(new_n343_), .A2(new_n344_), .B(new_n345_), .Y(new_n346_));
  AND3x1_ASAP7_75t_R   g325(.A(new_n255_), .B(p2), .C(new_n125_), .Y(new_n347_));
  OA21x2_ASAP7_75t_R   g326(.A1(new_n226_), .A2(new_n207_), .B(new_n119_), .Y(new_n348_));
  NOR2x1_ASAP7_75t_R   g327(.A(new_n347_), .B(new_n348_), .Y(new_n349_));
  AOI21x1_ASAP7_75t_R  g328(.A1(new_n346_), .A2(new_n349_), .B(p5), .Y(new_n350_));
  AOI21x1_ASAP7_75t_R  g329(.A1(new_n22_), .A2(new_n341_), .B(new_n350_), .Y(new_n351_));
  NAND2x1_ASAP7_75t_R  g330(.A(p5), .B(new_n30_), .Y(new_n352_));
  AO21x1_ASAP7_75t_R   g331(.A1(p7), .A2(p8), .B(p5), .Y(new_n353_));
  OAI22x1_ASAP7_75t_R  g332(.A1(new_n256_), .A2(new_n352_), .B1(new_n56_), .B2(new_n353_), .Y(new_n354_));
  OAI21x1_ASAP7_75t_R  g333(.A1(p5), .A2(new_n149_), .B(new_n319_), .Y(new_n355_));
  AOI21x1_ASAP7_75t_R  g334(.A1(new_n120_), .A2(new_n355_), .B(p0), .Y(new_n356_));
  AO32x1_ASAP7_75t_R   g335(.A1(p5), .A2(new_n64_), .A3(new_n218_), .B1(new_n204_), .B2(new_n199_), .Y(new_n357_));
  AO211x2_ASAP7_75t_R  g336(.A1(new_n354_), .A2(new_n243_), .B(new_n356_), .C(new_n357_), .Y(new_n358_));
  AND3x1_ASAP7_75t_R   g337(.A(new_n40_), .B(p9), .C(p2), .Y(new_n359_));
  OR3x1_ASAP7_75t_R    g338(.A(new_n24_), .B(new_n197_), .C(new_n186_), .Y(new_n360_));
  AO21x1_ASAP7_75t_R   g339(.A1(p9), .A2(p2), .B(p1), .Y(new_n361_));
  AND3x1_ASAP7_75t_R   g340(.A(new_n361_), .B(p4), .C(new_n40_), .Y(new_n362_));
  AND3x1_ASAP7_75t_R   g341(.A(new_n24_), .B(new_n264_), .C(p8), .Y(new_n363_));
  AOI221x1_ASAP7_75t_R g342(.A1(new_n359_), .A2(new_n206_), .B1(new_n360_), .B2(new_n362_), .C(new_n363_), .Y(new_n364_));
  OAI21x1_ASAP7_75t_R  g343(.A1(p5), .A2(new_n364_), .B(new_n330_), .Y(new_n365_));
  AOI21x1_ASAP7_75t_R  g344(.A1(new_n22_), .A2(new_n358_), .B(new_n365_), .Y(new_n366_));
  OAI21x1_ASAP7_75t_R  g345(.A1(new_n40_), .A2(new_n351_), .B(new_n366_), .Y(new_n367_));
  AND3x1_ASAP7_75t_R   g346(.A(new_n283_), .B(new_n90_), .C(new_n247_), .Y(new_n368_));
  AOI21x1_ASAP7_75t_R  g347(.A1(new_n331_), .A2(new_n367_), .B(new_n368_), .Y(o7));
  NAND2x1_ASAP7_75t_R  g348(.A(new_n163_), .B(new_n156_), .Y(new_n370_));
  AO21x1_ASAP7_75t_R   g349(.A1(p8), .A2(new_n52_), .B(p1), .Y(new_n371_));
  OR3x1_ASAP7_75t_R    g350(.A(new_n370_), .B(new_n26_), .C(new_n371_), .Y(new_n372_));
  NAND2x1_ASAP7_75t_R  g351(.A(new_n26_), .B(new_n255_), .Y(new_n373_));
  AO21x1_ASAP7_75t_R   g352(.A1(new_n231_), .A2(new_n373_), .B(p9), .Y(new_n374_));
  NAND2x1_ASAP7_75t_R  g353(.A(new_n22_), .B(new_n40_), .Y(new_n375_));
  INVx1_ASAP7_75t_R    g354(.A(new_n185_), .Y(new_n376_));
  AO21x1_ASAP7_75t_R   g355(.A1(new_n375_), .A2(new_n101_), .B(new_n376_), .Y(new_n377_));
  NAND3x1_ASAP7_75t_R  g356(.A(new_n372_), .B(new_n374_), .C(new_n377_), .Y(new_n378_));
  OR3x1_ASAP7_75t_R    g357(.A(new_n225_), .B(new_n141_), .C(new_n162_), .Y(new_n379_));
  OA21x2_ASAP7_75t_R   g358(.A1(p4), .A2(new_n54_), .B(new_n167_), .Y(new_n380_));
  OR4x2_ASAP7_75t_R    g359(.A(new_n380_), .B(new_n40_), .C(new_n24_), .D(new_n218_), .Y(new_n381_));
  AOI21x1_ASAP7_75t_R  g360(.A1(new_n379_), .A2(new_n381_), .B(new_n244_), .Y(new_n382_));
  AOI21x1_ASAP7_75t_R  g361(.A1(new_n133_), .A2(new_n378_), .B(new_n382_), .Y(new_n383_));
  OR3x1_ASAP7_75t_R    g362(.A(new_n309_), .B(new_n34_), .C(p5), .Y(new_n384_));
  AND3x1_ASAP7_75t_R   g363(.A(new_n384_), .B(p2), .C(new_n22_), .Y(new_n385_));
  AO21x1_ASAP7_75t_R   g364(.A1(new_n80_), .A2(new_n333_), .B(new_n91_), .Y(new_n386_));
  AO21x1_ASAP7_75t_R   g365(.A1(p5), .A2(new_n386_), .B(p1), .Y(new_n387_));
  OA211x2_ASAP7_75t_R  g366(.A1(p4), .A2(new_n153_), .B(new_n158_), .C(new_n167_), .Y(new_n388_));
  NAND2x1_ASAP7_75t_R  g367(.A(new_n30_), .B(new_n52_), .Y(new_n389_));
  AND5x1_ASAP7_75t_R   g368(.A(p7), .B(new_n389_), .C(new_n156_), .D(new_n54_), .E(new_n163_), .Y(new_n390_));
  AND3x1_ASAP7_75t_R   g369(.A(new_n142_), .B(p7), .C(new_n32_), .Y(new_n391_));
  OR3x1_ASAP7_75t_R    g370(.A(new_n388_), .B(new_n390_), .C(new_n391_), .Y(new_n392_));
  AOI22x1_ASAP7_75t_R  g371(.A1(new_n385_), .A2(new_n387_), .B1(new_n106_), .B2(new_n392_), .Y(new_n393_));
  NAND2x1_ASAP7_75t_R  g372(.A(new_n383_), .B(new_n393_), .Y(new_n394_));
  AO32x1_ASAP7_75t_R   g373(.A1(new_n82_), .A2(p7), .A3(new_n38_), .B1(new_n119_), .B2(new_n31_), .Y(new_n395_));
  AO21x1_ASAP7_75t_R   g374(.A1(new_n342_), .A2(new_n286_), .B(new_n395_), .Y(new_n396_));
  AND3x1_ASAP7_75t_R   g375(.A(new_n100_), .B(new_n54_), .C(new_n119_), .Y(new_n397_));
  AO21x1_ASAP7_75t_R   g376(.A1(new_n40_), .A2(new_n396_), .B(new_n397_), .Y(new_n398_));
  AND3x1_ASAP7_75t_R   g377(.A(new_n283_), .B(new_n22_), .C(new_n90_), .Y(new_n399_));
  AO21x1_ASAP7_75t_R   g378(.A1(new_n178_), .A2(new_n398_), .B(new_n399_), .Y(new_n400_));
  AOI21x1_ASAP7_75t_R  g379(.A1(new_n71_), .A2(new_n394_), .B(new_n400_), .Y(o8));
  NAND2x1_ASAP7_75t_R  g380(.A(new_n28_), .B(new_n219_), .Y(new_n402_));
  OA21x2_ASAP7_75t_R   g381(.A1(new_n333_), .A2(new_n265_), .B(new_n402_), .Y(new_n403_));
  OA21x2_ASAP7_75t_R   g382(.A1(new_n247_), .A2(new_n252_), .B(new_n54_), .Y(new_n404_));
  INVx1_ASAP7_75t_R    g383(.A(new_n250_), .Y(new_n405_));
  AND3x1_ASAP7_75t_R   g384(.A(new_n405_), .B(new_n52_), .C(new_n319_), .Y(new_n406_));
  OAI21x1_ASAP7_75t_R  g385(.A1(new_n404_), .A2(new_n406_), .B(new_n40_), .Y(new_n407_));
  AOI21x1_ASAP7_75t_R  g386(.A1(new_n52_), .A2(new_n87_), .B(new_n153_), .Y(new_n408_));
  OR3x1_ASAP7_75t_R    g387(.A(new_n408_), .B(p1), .C(new_n402_), .Y(new_n409_));
  OR3x1_ASAP7_75t_R    g388(.A(new_n265_), .B(p2), .C(new_n133_), .Y(new_n410_));
  OA21x2_ASAP7_75t_R   g389(.A1(new_n405_), .A2(new_n270_), .B(new_n410_), .Y(new_n411_));
  AO21x1_ASAP7_75t_R   g390(.A1(new_n409_), .A2(new_n411_), .B(new_n40_), .Y(new_n412_));
  OR3x1_ASAP7_75t_R    g391(.A(new_n28_), .B(new_n192_), .C(new_n54_), .Y(new_n413_));
  AO22x1_ASAP7_75t_R   g392(.A1(new_n40_), .A2(new_n187_), .B1(new_n90_), .B2(new_n413_), .Y(new_n414_));
  AO21x1_ASAP7_75t_R   g393(.A1(new_n22_), .A2(new_n376_), .B(new_n27_), .Y(new_n415_));
  NAND2x1_ASAP7_75t_R  g394(.A(new_n32_), .B(new_n82_), .Y(new_n416_));
  AO21x1_ASAP7_75t_R   g395(.A1(new_n30_), .A2(new_n185_), .B(new_n90_), .Y(new_n417_));
  AND5x1_ASAP7_75t_R   g396(.A(new_n414_), .B(new_n235_), .C(new_n415_), .D(new_n416_), .E(new_n417_), .Y(new_n418_));
  OA211x2_ASAP7_75t_R  g397(.A1(new_n403_), .A2(new_n407_), .B(new_n412_), .C(new_n418_), .Y(o9));
  AO21x1_ASAP7_75t_R   g398(.A1(p0), .A2(new_n37_), .B(new_n23_), .Y(new_n420_));
  AND5x1_ASAP7_75t_R   g399(.A(new_n138_), .B(new_n420_), .C(new_n276_), .D(new_n80_), .E(new_n24_), .Y(new_n421_));
  OA211x2_ASAP7_75t_R  g400(.A1(new_n283_), .A2(new_n421_), .B(new_n90_), .C(new_n247_), .Y(o10));
endmodule


