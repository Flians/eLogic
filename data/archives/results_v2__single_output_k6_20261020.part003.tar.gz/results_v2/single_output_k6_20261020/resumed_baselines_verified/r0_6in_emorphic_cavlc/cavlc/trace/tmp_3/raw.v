// Benchmark "/tmp/" written by ABC on Tue Oct 20 17:20:32 2026

module \/tmp/  ( 
    p0, p1, p9, p6, p3, p2, p7, p4, p8, p5,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10  );
  input  p0, p1, p9, p6, p3, p2, p7, p4, p8, p5;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10;
  wire new_n22_, new_n23_, new_n24_, new_n25_, new_n26_, new_n27_, new_n28_,
    new_n29_, new_n30_, new_n31_, new_n32_, new_n33_, new_n34_, new_n35_,
    new_n36_, new_n37_, new_n38_, new_n39_, new_n40_, new_n41_, new_n42_,
    new_n43_, new_n44_, new_n45_, new_n46_, new_n47_, new_n48_, new_n49_,
    new_n50_, new_n51_, new_n52_, new_n53_, new_n54_, new_n55_, new_n56_,
    new_n57_, new_n58_, new_n59_, new_n60_, new_n61_, new_n62_, new_n63_,
    new_n64_, new_n65_, new_n66_, new_n67_, new_n68_, new_n69_, new_n70_,
    new_n71_, new_n72_, new_n73_, new_n74_, new_n75_, new_n76_, new_n77_,
    new_n78_, new_n79_, new_n80_, new_n81_, new_n82_, new_n83_, new_n84_,
    new_n85_, new_n86_, new_n87_, new_n88_, new_n89_, new_n90_, new_n91_,
    new_n92_, new_n93_, new_n94_, new_n95_, new_n96_, new_n97_, new_n98_,
    new_n99_, new_n100_, new_n101_, new_n102_, new_n103_, new_n104_,
    new_n105_, new_n106_, new_n107_, new_n108_, new_n109_, new_n110_,
    new_n111_, new_n112_, new_n113_, new_n114_, new_n115_, new_n116_,
    new_n118_, new_n119_, new_n120_, new_n121_, new_n122_, new_n123_,
    new_n124_, new_n125_, new_n126_, new_n127_, new_n128_, new_n129_,
    new_n130_, new_n131_, new_n132_, new_n133_, new_n134_, new_n135_,
    new_n136_, new_n137_, new_n138_, new_n139_, new_n140_, new_n141_,
    new_n142_, new_n143_, new_n144_, new_n145_, new_n146_, new_n147_,
    new_n148_, new_n149_, new_n150_, new_n151_, new_n152_, new_n153_,
    new_n154_, new_n155_, new_n156_, new_n157_, new_n158_, new_n159_,
    new_n160_, new_n161_, new_n162_, new_n163_, new_n164_, new_n165_,
    new_n166_, new_n167_, new_n168_, new_n169_, new_n170_, new_n171_,
    new_n172_, new_n173_, new_n174_, new_n175_, new_n176_, new_n177_,
    new_n178_, new_n179_, new_n180_, new_n181_, new_n182_, new_n183_,
    new_n185_, new_n186_, new_n187_, new_n188_, new_n189_, new_n190_,
    new_n191_, new_n192_, new_n193_, new_n194_, new_n195_, new_n196_,
    new_n197_, new_n198_, new_n199_, new_n200_, new_n201_, new_n202_,
    new_n203_, new_n204_, new_n205_, new_n206_, new_n207_, new_n208_,
    new_n209_, new_n210_, new_n211_, new_n212_, new_n213_, new_n214_,
    new_n215_, new_n216_, new_n217_, new_n218_, new_n219_, new_n220_,
    new_n221_, new_n222_, new_n223_, new_n224_, new_n225_, new_n226_,
    new_n227_, new_n228_, new_n229_, new_n230_, new_n231_, new_n232_,
    new_n233_, new_n234_, new_n235_, new_n236_, new_n238_, new_n239_,
    new_n240_, new_n241_, new_n242_, new_n243_, new_n244_, new_n245_,
    new_n246_, new_n247_, new_n248_, new_n249_, new_n250_, new_n251_,
    new_n252_, new_n253_, new_n254_, new_n255_, new_n256_, new_n257_,
    new_n258_, new_n259_, new_n260_, new_n261_, new_n262_, new_n263_,
    new_n264_, new_n265_, new_n266_, new_n267_, new_n268_, new_n269_,
    new_n271_, new_n272_, new_n273_, new_n274_, new_n275_, new_n277_,
    new_n278_, new_n280_, new_n281_, new_n282_, new_n283_, new_n284_,
    new_n285_, new_n286_, new_n287_, new_n288_, new_n289_, new_n290_,
    new_n291_, new_n292_, new_n293_, new_n294_, new_n295_, new_n296_,
    new_n297_, new_n298_, new_n299_, new_n300_, new_n301_, new_n302_,
    new_n303_, new_n304_, new_n305_, new_n306_, new_n307_, new_n308_,
    new_n309_, new_n310_, new_n311_, new_n312_, new_n313_, new_n314_,
    new_n316_, new_n317_, new_n318_, new_n319_, new_n320_, new_n321_,
    new_n322_, new_n323_, new_n324_, new_n325_, new_n326_, new_n327_,
    new_n328_, new_n329_, new_n330_, new_n331_, new_n332_, new_n333_,
    new_n334_, new_n335_, new_n336_, new_n337_, new_n338_, new_n339_,
    new_n340_, new_n341_, new_n342_, new_n343_, new_n344_, new_n345_,
    new_n346_, new_n347_, new_n348_, new_n349_, new_n350_, new_n351_,
    new_n352_, new_n353_, new_n354_, new_n355_, new_n356_, new_n357_,
    new_n358_, new_n359_, new_n360_, new_n361_, new_n363_, new_n364_,
    new_n365_, new_n366_, new_n367_, new_n368_, new_n369_, new_n370_,
    new_n371_, new_n372_, new_n373_, new_n374_, new_n375_, new_n376_,
    new_n377_, new_n378_, new_n379_, new_n380_, new_n381_, new_n382_,
    new_n383_, new_n384_, new_n385_, new_n386_, new_n387_, new_n388_,
    new_n389_, new_n390_, new_n391_, new_n393_, new_n394_, new_n395_,
    new_n396_, new_n397_, new_n398_, new_n399_, new_n400_, new_n401_,
    new_n402_, new_n403_, new_n404_, new_n405_, new_n406_, new_n407_,
    new_n408_, new_n409_, new_n411_, new_n412_, new_n413_;
  NOR2x1_ASAP7_75t_R   g000(.A(p9), .B(p7), .Y(new_n22_));
  INVx1_ASAP7_75t_R    g001(.A(p9), .Y(new_n23_));
  NOR2x1_ASAP7_75t_R   g002(.A(p8), .B(new_n23_), .Y(new_n24_));
  INVx1_ASAP7_75t_R    g003(.A(p1), .Y(new_n25_));
  NOR2x1_ASAP7_75t_R   g004(.A(p0), .B(new_n25_), .Y(new_n26_));
  INVx1_ASAP7_75t_R    g005(.A(p0), .Y(new_n27_));
  NOR2x1_ASAP7_75t_R   g006(.A(p7), .B(new_n27_), .Y(new_n28_));
  AO221x2_ASAP7_75t_R  g007(.A1(p8), .A2(new_n22_), .B1(new_n24_), .B2(new_n26_), .C(new_n28_), .Y(new_n29_));
  INVx1_ASAP7_75t_R    g008(.A(p2), .Y(new_n30_));
  NOR2x1_ASAP7_75t_R   g009(.A(p4), .B(new_n30_), .Y(new_n31_));
  INVx1_ASAP7_75t_R    g010(.A(p8), .Y(new_n32_));
  NOR2x1_ASAP7_75t_R   g011(.A(p9), .B(new_n32_), .Y(new_n33_));
  NAND2x1_ASAP7_75t_R  g012(.A(p0), .B(new_n30_), .Y(new_n34_));
  NOR2x1_ASAP7_75t_R   g013(.A(p1), .B(new_n24_), .Y(new_n35_));
  OAI21x1_ASAP7_75t_R  g014(.A1(new_n33_), .A2(new_n34_), .B(new_n35_), .Y(new_n36_));
  AND2x2_ASAP7_75t_R   g015(.A(p7), .B(p4), .Y(new_n37_));
  OA21x2_ASAP7_75t_R   g016(.A1(p5), .A2(new_n35_), .B(new_n37_), .Y(new_n38_));
  NOR2x1_ASAP7_75t_R   g017(.A(p9), .B(p2), .Y(new_n39_));
  INVx1_ASAP7_75t_R    g018(.A(p7), .Y(new_n40_));
  AND3x1_ASAP7_75t_R   g019(.A(new_n27_), .B(new_n40_), .C(new_n32_), .Y(new_n41_));
  NOR2x1_ASAP7_75t_R   g020(.A(p1), .B(p8), .Y(new_n42_));
  AND2x2_ASAP7_75t_R   g021(.A(p1), .B(p8), .Y(new_n43_));
  AO21x1_ASAP7_75t_R   g022(.A1(p0), .A2(new_n42_), .B(new_n43_), .Y(new_n44_));
  AND3x1_ASAP7_75t_R   g023(.A(new_n39_), .B(p7), .C(p5), .Y(new_n45_));
  AO32x1_ASAP7_75t_R   g024(.A1(new_n25_), .A2(new_n39_), .A3(new_n41_), .B1(new_n44_), .B2(new_n45_), .Y(new_n46_));
  AOI221x1_ASAP7_75t_R g025(.A1(new_n29_), .A2(new_n31_), .B1(new_n36_), .B2(new_n38_), .C(new_n46_), .Y(new_n47_));
  NOR2x1_ASAP7_75t_R   g026(.A(p1), .B(p9), .Y(new_n48_));
  AO21x1_ASAP7_75t_R   g027(.A1(new_n27_), .A2(new_n48_), .B(p4), .Y(new_n49_));
  NOR2x1_ASAP7_75t_R   g028(.A(p4), .B(p8), .Y(new_n50_));
  INVx1_ASAP7_75t_R    g029(.A(new_n50_), .Y(new_n51_));
  NAND2x1_ASAP7_75t_R  g030(.A(p7), .B(p5), .Y(new_n52_));
  INVx1_ASAP7_75t_R    g031(.A(new_n52_), .Y(new_n53_));
  NAND2x1_ASAP7_75t_R  g032(.A(p8), .B(new_n23_), .Y(new_n54_));
  NAND2x1_ASAP7_75t_R  g033(.A(p9), .B(new_n32_), .Y(new_n55_));
  AND3x1_ASAP7_75t_R   g034(.A(new_n54_), .B(new_n55_), .C(p0), .Y(new_n56_));
  AND3x1_ASAP7_75t_R   g035(.A(p1), .B(p7), .C(p4), .Y(new_n57_));
  AO32x1_ASAP7_75t_R   g036(.A1(new_n49_), .A2(new_n51_), .A3(new_n53_), .B1(new_n56_), .B2(new_n57_), .Y(new_n58_));
  NAND2x1_ASAP7_75t_R  g037(.A(p2), .B(new_n58_), .Y(new_n59_));
  NOR2x1_ASAP7_75t_R   g038(.A(p0), .B(p2), .Y(new_n60_));
  AO21x1_ASAP7_75t_R   g039(.A1(new_n43_), .A2(new_n60_), .B(new_n28_), .Y(new_n61_));
  NAND2x1_ASAP7_75t_R  g040(.A(new_n23_), .B(new_n61_), .Y(new_n62_));
  INVx1_ASAP7_75t_R    g041(.A(p5), .Y(new_n63_));
  NAND2x1_ASAP7_75t_R  g042(.A(p2), .B(new_n63_), .Y(new_n64_));
  NOR2x1_ASAP7_75t_R   g043(.A(p0), .B(p8), .Y(new_n65_));
  NAND2x1_ASAP7_75t_R  g044(.A(p1), .B(p2), .Y(new_n66_));
  AND3x1_ASAP7_75t_R   g045(.A(new_n64_), .B(new_n65_), .C(new_n66_), .Y(new_n67_));
  OAI21x1_ASAP7_75t_R  g046(.A1(new_n43_), .A2(new_n67_), .B(new_n40_), .Y(new_n68_));
  AO21x1_ASAP7_75t_R   g047(.A1(new_n62_), .A2(new_n68_), .B(p4), .Y(new_n69_));
  NOR2x1_ASAP7_75t_R   g048(.A(p6), .B(p3), .Y(new_n70_));
  INVx1_ASAP7_75t_R    g049(.A(new_n70_), .Y(new_n71_));
  AO31x2_ASAP7_75t_R   g050(.A1(new_n47_), .A2(new_n59_), .A3(new_n69_), .B(new_n71_), .Y(new_n72_));
  NAND2x1_ASAP7_75t_R  g051(.A(p0), .B(p1), .Y(new_n73_));
  INVx1_ASAP7_75t_R    g052(.A(p4), .Y(new_n74_));
  AO21x1_ASAP7_75t_R   g053(.A1(new_n25_), .A2(new_n74_), .B(p9), .Y(new_n75_));
  AO21x1_ASAP7_75t_R   g054(.A1(new_n73_), .A2(new_n75_), .B(p8), .Y(new_n76_));
  NAND2x1_ASAP7_75t_R  g055(.A(p8), .B(new_n27_), .Y(new_n77_));
  NOR2x1_ASAP7_75t_R   g056(.A(p1), .B(p2), .Y(new_n78_));
  NAND3x1_ASAP7_75t_R  g057(.A(new_n27_), .B(p9), .C(p2), .Y(new_n79_));
  OA211x2_ASAP7_75t_R  g058(.A1(new_n77_), .A2(new_n78_), .B(new_n79_), .C(new_n34_), .Y(new_n80_));
  INVx1_ASAP7_75t_R    g059(.A(p6), .Y(new_n81_));
  NAND2x1_ASAP7_75t_R  g060(.A(new_n81_), .B(new_n40_), .Y(new_n82_));
  AO21x1_ASAP7_75t_R   g061(.A1(new_n76_), .A2(new_n80_), .B(new_n82_), .Y(new_n83_));
  NOR2x1_ASAP7_75t_R   g062(.A(p4), .B(new_n40_), .Y(new_n84_));
  NOR2x1_ASAP7_75t_R   g063(.A(p1), .B(new_n23_), .Y(new_n85_));
  OA21x2_ASAP7_75t_R   g064(.A1(new_n81_), .A2(new_n50_), .B(new_n85_), .Y(new_n86_));
  NAND2x1_ASAP7_75t_R  g065(.A(p0), .B(new_n32_), .Y(new_n87_));
  OA21x2_ASAP7_75t_R   g066(.A1(p6), .A2(new_n87_), .B(new_n30_), .Y(new_n88_));
  OA21x2_ASAP7_75t_R   g067(.A1(new_n84_), .A2(new_n86_), .B(new_n88_), .Y(new_n89_));
  NAND2x1_ASAP7_75t_R  g068(.A(p4), .B(new_n27_), .Y(new_n90_));
  NOR2x1_ASAP7_75t_R   g069(.A(p0), .B(p9), .Y(new_n91_));
  AND3x1_ASAP7_75t_R   g070(.A(new_n91_), .B(p1), .C(new_n32_), .Y(new_n92_));
  AO32x1_ASAP7_75t_R   g071(.A1(new_n77_), .A2(new_n90_), .A3(new_n85_), .B1(new_n92_), .B2(p6), .Y(new_n93_));
  NAND2x1_ASAP7_75t_R  g072(.A(p0), .B(p9), .Y(new_n94_));
  INVx1_ASAP7_75t_R    g073(.A(new_n91_), .Y(new_n95_));
  AO32x1_ASAP7_75t_R   g074(.A1(new_n30_), .A2(new_n74_), .A3(new_n94_), .B1(new_n95_), .B2(new_n81_), .Y(new_n96_));
  NOR2x1_ASAP7_75t_R   g075(.A(p1), .B(p7), .Y(new_n97_));
  INVx1_ASAP7_75t_R    g076(.A(new_n97_), .Y(new_n98_));
  NAND2x1_ASAP7_75t_R  g077(.A(p0), .B(p8), .Y(new_n99_));
  INVx1_ASAP7_75t_R    g078(.A(new_n99_), .Y(new_n100_));
  NOR2x1_ASAP7_75t_R   g079(.A(new_n65_), .B(new_n100_), .Y(new_n101_));
  NOR2x1_ASAP7_75t_R   g080(.A(new_n98_), .B(new_n101_), .Y(new_n102_));
  AOI22x1_ASAP7_75t_R  g081(.A1(new_n89_), .A2(new_n93_), .B1(new_n96_), .B2(new_n102_), .Y(new_n103_));
  INVx1_ASAP7_75t_R    g082(.A(p3), .Y(new_n104_));
  NAND2x1_ASAP7_75t_R  g083(.A(new_n104_), .B(new_n63_), .Y(new_n105_));
  AO21x1_ASAP7_75t_R   g084(.A1(new_n83_), .A2(new_n103_), .B(new_n105_), .Y(new_n106_));
  AND3x1_ASAP7_75t_R   g085(.A(new_n27_), .B(new_n25_), .C(new_n23_), .Y(new_n107_));
  AND3x1_ASAP7_75t_R   g086(.A(new_n107_), .B(new_n81_), .C(new_n30_), .Y(new_n108_));
  AND2x2_ASAP7_75t_R   g087(.A(p3), .B(p8), .Y(new_n109_));
  AO21x1_ASAP7_75t_R   g088(.A1(new_n32_), .A2(p5), .B(new_n109_), .Y(new_n110_));
  NAND2x1_ASAP7_75t_R  g089(.A(p4), .B(p5), .Y(new_n111_));
  OA21x2_ASAP7_75t_R   g090(.A1(p5), .A2(new_n40_), .B(p4), .Y(new_n112_));
  NOR2x1_ASAP7_75t_R   g091(.A(p8), .B(p5), .Y(new_n113_));
  AO21x1_ASAP7_75t_R   g092(.A1(p3), .A2(p7), .B(new_n113_), .Y(new_n114_));
  AO32x1_ASAP7_75t_R   g093(.A1(new_n110_), .A2(new_n40_), .A3(new_n111_), .B1(new_n112_), .B2(new_n114_), .Y(new_n115_));
  NAND2x1_ASAP7_75t_R  g094(.A(new_n108_), .B(new_n115_), .Y(new_n116_));
  NAND3x1_ASAP7_75t_R  g095(.A(new_n72_), .B(new_n106_), .C(new_n116_), .Y(o0));
  AOI21x1_ASAP7_75t_R  g096(.A1(p8), .A2(p5), .B(new_n84_), .Y(new_n118_));
  NAND2x1_ASAP7_75t_R  g097(.A(new_n52_), .B(new_n85_), .Y(new_n119_));
  NAND2x1_ASAP7_75t_R  g098(.A(p4), .B(new_n97_), .Y(new_n120_));
  OA22x2_ASAP7_75t_R   g099(.A1(new_n118_), .A2(new_n119_), .B1(new_n54_), .B2(new_n120_), .Y(new_n121_));
  NOR2x1_ASAP7_75t_R   g100(.A(p7), .B(p8), .Y(new_n122_));
  NAND2x1_ASAP7_75t_R  g101(.A(new_n48_), .B(new_n122_), .Y(new_n123_));
  AND2x2_ASAP7_75t_R   g102(.A(p9), .B(p7), .Y(new_n124_));
  NAND2x1_ASAP7_75t_R  g103(.A(new_n43_), .B(new_n124_), .Y(new_n125_));
  AO21x1_ASAP7_75t_R   g104(.A1(new_n123_), .A2(new_n125_), .B(new_n90_), .Y(new_n126_));
  OA21x2_ASAP7_75t_R   g105(.A1(new_n27_), .A2(new_n121_), .B(new_n126_), .Y(new_n127_));
  AND2x2_ASAP7_75t_R   g106(.A(p7), .B(p8), .Y(new_n128_));
  AO22x1_ASAP7_75t_R   g107(.A1(new_n74_), .A2(new_n122_), .B1(p5), .B2(new_n128_), .Y(new_n129_));
  NOR2x1_ASAP7_75t_R   g108(.A(p9), .B(new_n118_), .Y(new_n130_));
  OAI21x1_ASAP7_75t_R  g109(.A1(new_n129_), .A2(new_n130_), .B(new_n26_), .Y(new_n131_));
  AO21x1_ASAP7_75t_R   g110(.A1(p5), .A2(new_n23_), .B(p1), .Y(new_n132_));
  NOR2x1_ASAP7_75t_R   g111(.A(p7), .B(p5), .Y(new_n133_));
  AO21x1_ASAP7_75t_R   g112(.A1(new_n84_), .A2(new_n132_), .B(new_n133_), .Y(new_n134_));
  INVx1_ASAP7_75t_R    g113(.A(new_n87_), .Y(new_n135_));
  AND2x2_ASAP7_75t_R   g114(.A(p1), .B(p7), .Y(new_n136_));
  AOI22x1_ASAP7_75t_R  g115(.A1(new_n134_), .A2(new_n135_), .B1(new_n113_), .B2(new_n136_), .Y(new_n137_));
  OR3x1_ASAP7_75t_R    g116(.A(p6), .B(p3), .C(p2), .Y(new_n138_));
  AO31x2_ASAP7_75t_R   g117(.A1(new_n127_), .A2(new_n131_), .A3(new_n137_), .B(new_n138_), .Y(new_n139_));
  OR3x1_ASAP7_75t_R    g118(.A(new_n73_), .B(new_n30_), .C(new_n63_), .Y(new_n140_));
  NAND2x1_ASAP7_75t_R  g119(.A(p0), .B(p4), .Y(new_n141_));
  OR3x1_ASAP7_75t_R    g120(.A(new_n66_), .B(new_n141_), .C(p7), .Y(new_n142_));
  AND2x2_ASAP7_75t_R   g121(.A(new_n140_), .B(new_n142_), .Y(new_n143_));
  AND3x1_ASAP7_75t_R   g122(.A(new_n27_), .B(p9), .C(p2), .Y(new_n144_));
  NAND2x1_ASAP7_75t_R  g123(.A(new_n97_), .B(new_n144_), .Y(new_n145_));
  NAND2x1_ASAP7_75t_R  g124(.A(p1), .B(p4), .Y(new_n146_));
  NAND2x1_ASAP7_75t_R  g125(.A(p2), .B(p4), .Y(new_n147_));
  OA211x2_ASAP7_75t_R  g126(.A1(new_n23_), .A2(new_n141_), .B(new_n146_), .C(new_n147_), .Y(new_n148_));
  AO21x1_ASAP7_75t_R   g127(.A1(new_n145_), .A2(new_n148_), .B(new_n63_), .Y(new_n149_));
  AOI21x1_ASAP7_75t_R  g128(.A1(new_n143_), .A2(new_n149_), .B(new_n32_), .Y(new_n150_));
  INVx1_ASAP7_75t_R    g129(.A(new_n94_), .Y(new_n151_));
  NOR2x1_ASAP7_75t_R   g130(.A(p9), .B(new_n40_), .Y(new_n152_));
  NOR2x1_ASAP7_75t_R   g131(.A(p0), .B(p5), .Y(new_n153_));
  OR5x1_ASAP7_75t_R    g132(.A(p1), .B(new_n151_), .C(new_n152_), .D(p4), .E(new_n153_), .Y(new_n154_));
  INVx1_ASAP7_75t_R    g133(.A(new_n73_), .Y(new_n155_));
  NOR2x1_ASAP7_75t_R   g134(.A(p5), .B(new_n25_), .Y(new_n156_));
  NAND2x1_ASAP7_75t_R  g135(.A(p2), .B(new_n74_), .Y(new_n157_));
  NOR2x1_ASAP7_75t_R   g136(.A(p0), .B(p7), .Y(new_n158_));
  OR4x2_ASAP7_75t_R    g137(.A(new_n155_), .B(new_n156_), .C(new_n157_), .D(new_n158_), .Y(new_n159_));
  OR4x2_ASAP7_75t_R    g138(.A(new_n78_), .B(new_n97_), .C(p9), .D(p5), .Y(new_n160_));
  AND3x1_ASAP7_75t_R   g139(.A(new_n154_), .B(new_n159_), .C(new_n160_), .Y(new_n161_));
  AO21x1_ASAP7_75t_R   g140(.A1(p4), .A2(new_n23_), .B(new_n27_), .Y(new_n162_));
  AND3x1_ASAP7_75t_R   g141(.A(new_n25_), .B(p9), .C(p7), .Y(new_n163_));
  NOR2x1_ASAP7_75t_R   g142(.A(p4), .B(new_n23_), .Y(new_n164_));
  NOR3x1_ASAP7_75t_R   g143(.A(new_n162_), .B(new_n163_), .C(new_n164_), .Y(new_n165_));
  NOR2x1_ASAP7_75t_R   g144(.A(p2), .B(p7), .Y(new_n166_));
  OR3x1_ASAP7_75t_R    g145(.A(new_n84_), .B(new_n23_), .C(new_n166_), .Y(new_n167_));
  AND2x2_ASAP7_75t_R   g146(.A(new_n27_), .B(new_n120_), .Y(new_n168_));
  INVx1_ASAP7_75t_R    g147(.A(new_n113_), .Y(new_n169_));
  AO21x1_ASAP7_75t_R   g148(.A1(new_n167_), .A2(new_n168_), .B(new_n169_), .Y(new_n170_));
  OAI22x1_ASAP7_75t_R  g149(.A1(new_n161_), .A2(p8), .B1(new_n165_), .B2(new_n170_), .Y(new_n171_));
  OAI21x1_ASAP7_75t_R  g150(.A1(new_n150_), .A2(new_n171_), .B(new_n70_), .Y(new_n172_));
  AND3x1_ASAP7_75t_R   g151(.A(new_n32_), .B(p0), .C(p7), .Y(new_n173_));
  NOR2x1_ASAP7_75t_R   g152(.A(p1), .B(new_n81_), .Y(new_n174_));
  OR3x1_ASAP7_75t_R    g153(.A(new_n151_), .B(new_n24_), .C(p1), .Y(new_n175_));
  OA211x2_ASAP7_75t_R  g154(.A1(new_n22_), .A2(new_n97_), .B(new_n73_), .C(p6), .Y(new_n176_));
  AO221x2_ASAP7_75t_R  g155(.A1(new_n173_), .A2(new_n174_), .B1(new_n175_), .B2(new_n176_), .C(new_n92_), .Y(new_n177_));
  NOR2x1_ASAP7_75t_R   g156(.A(p2), .B(p4), .Y(new_n178_));
  AND3x1_ASAP7_75t_R   g157(.A(new_n178_), .B(new_n104_), .C(new_n63_), .Y(new_n179_));
  NOR2x1_ASAP7_75t_R   g158(.A(p7), .B(new_n74_), .Y(new_n180_));
  AO32x1_ASAP7_75t_R   g159(.A1(p3), .A2(p7), .A3(new_n113_), .B1(new_n109_), .B2(p5), .Y(new_n181_));
  AO21x1_ASAP7_75t_R   g160(.A1(new_n113_), .A2(new_n180_), .B(new_n181_), .Y(new_n182_));
  AOI22x1_ASAP7_75t_R  g161(.A1(new_n177_), .A2(new_n179_), .B1(new_n108_), .B2(new_n182_), .Y(new_n183_));
  NAND3x1_ASAP7_75t_R  g162(.A(new_n139_), .B(new_n172_), .C(new_n183_), .Y(o1));
  NOR2x1_ASAP7_75t_R   g163(.A(new_n113_), .B(new_n173_), .Y(new_n185_));
  NAND2x1_ASAP7_75t_R  g164(.A(p2), .B(new_n40_), .Y(new_n186_));
  NOR2x1_ASAP7_75t_R   g165(.A(p1), .B(new_n30_), .Y(new_n187_));
  INVx1_ASAP7_75t_R    g166(.A(new_n187_), .Y(new_n188_));
  OAI21x1_ASAP7_75t_R  g167(.A1(new_n77_), .A2(new_n186_), .B(new_n188_), .Y(new_n189_));
  NAND2x1_ASAP7_75t_R  g168(.A(p5), .B(new_n40_), .Y(new_n190_));
  OR3x1_ASAP7_75t_R    g169(.A(new_n27_), .B(new_n32_), .C(p2), .Y(new_n191_));
  OAI21x1_ASAP7_75t_R  g170(.A1(new_n190_), .A2(new_n191_), .B(new_n104_), .Y(new_n192_));
  AO21x1_ASAP7_75t_R   g171(.A1(new_n185_), .A2(new_n189_), .B(new_n192_), .Y(new_n193_));
  OA21x2_ASAP7_75t_R   g172(.A1(new_n40_), .A2(new_n187_), .B(new_n74_), .Y(new_n194_));
  NOR2x1_ASAP7_75t_R   g173(.A(p1), .B(new_n40_), .Y(new_n195_));
  NOR2x1_ASAP7_75t_R   g174(.A(new_n147_), .B(new_n195_), .Y(new_n196_));
  OR3x1_ASAP7_75t_R    g175(.A(new_n194_), .B(new_n87_), .C(new_n196_), .Y(new_n197_));
  NAND2x1_ASAP7_75t_R  g176(.A(p1), .B(p5), .Y(new_n198_));
  AND3x1_ASAP7_75t_R   g177(.A(new_n198_), .B(p0), .C(p7), .Y(new_n199_));
  OR4x2_ASAP7_75t_R    g178(.A(new_n199_), .B(new_n74_), .C(new_n78_), .D(new_n97_), .Y(new_n200_));
  AO221x2_ASAP7_75t_R  g179(.A1(p2), .A2(new_n32_), .B1(new_n87_), .B2(new_n186_), .C(p5), .Y(new_n201_));
  AND3x1_ASAP7_75t_R   g180(.A(new_n122_), .B(new_n74_), .C(p5), .Y(new_n202_));
  NAND2x1_ASAP7_75t_R  g181(.A(new_n60_), .B(new_n202_), .Y(new_n203_));
  AND3x1_ASAP7_75t_R   g182(.A(new_n200_), .B(new_n201_), .C(new_n203_), .Y(new_n204_));
  NAND2x1_ASAP7_75t_R  g183(.A(new_n197_), .B(new_n204_), .Y(new_n205_));
  NAND2x1_ASAP7_75t_R  g184(.A(p7), .B(p8), .Y(new_n206_));
  AO21x1_ASAP7_75t_R   g185(.A1(new_n206_), .A2(new_n190_), .B(p4), .Y(new_n207_));
  AO21x1_ASAP7_75t_R   g186(.A1(new_n27_), .A2(new_n78_), .B(new_n104_), .Y(new_n208_));
  OA21x2_ASAP7_75t_R   g187(.A1(new_n104_), .A2(new_n207_), .B(new_n208_), .Y(new_n209_));
  AND2x2_ASAP7_75t_R   g188(.A(new_n23_), .B(new_n209_), .Y(new_n210_));
  OAI21x1_ASAP7_75t_R  g189(.A1(new_n193_), .A2(new_n205_), .B(new_n210_), .Y(new_n211_));
  AND3x1_ASAP7_75t_R   g190(.A(p9), .B(p7), .C(p8), .Y(new_n212_));
  OR3x1_ASAP7_75t_R    g191(.A(new_n212_), .B(new_n74_), .C(new_n122_), .Y(new_n213_));
  OA21x2_ASAP7_75t_R   g192(.A1(p4), .A2(new_n43_), .B(p0), .Y(new_n214_));
  AND3x1_ASAP7_75t_R   g193(.A(new_n213_), .B(new_n214_), .C(new_n30_), .Y(new_n215_));
  NOR2x1_ASAP7_75t_R   g194(.A(new_n122_), .B(new_n128_), .Y(new_n216_));
  OA211x2_ASAP7_75t_R  g195(.A1(new_n65_), .A2(new_n216_), .B(p1), .C(new_n30_), .Y(new_n217_));
  OA211x2_ASAP7_75t_R  g196(.A1(new_n164_), .A2(new_n144_), .B(new_n32_), .C(new_n97_), .Y(new_n218_));
  NOR2x1_ASAP7_75t_R   g197(.A(new_n32_), .B(new_n78_), .Y(new_n219_));
  AND3x1_ASAP7_75t_R   g198(.A(new_n219_), .B(new_n27_), .C(new_n124_), .Y(new_n220_));
  OR4x2_ASAP7_75t_R    g199(.A(new_n215_), .B(new_n217_), .C(new_n218_), .D(new_n220_), .Y(new_n221_));
  AND3x1_ASAP7_75t_R   g200(.A(new_n81_), .B(new_n104_), .C(new_n63_), .Y(new_n222_));
  AND2x2_ASAP7_75t_R   g201(.A(new_n166_), .B(new_n87_), .Y(new_n223_));
  OR3x1_ASAP7_75t_R    g202(.A(new_n223_), .B(new_n53_), .C(new_n173_), .Y(new_n224_));
  NAND2x1_ASAP7_75t_R  g203(.A(p1), .B(new_n122_), .Y(new_n225_));
  OAI21x1_ASAP7_75t_R  g204(.A1(new_n99_), .A2(new_n198_), .B(new_n225_), .Y(new_n226_));
  NOR2x1_ASAP7_75t_R   g205(.A(p0), .B(new_n52_), .Y(new_n227_));
  NOR2x1_ASAP7_75t_R   g206(.A(p8), .B(new_n25_), .Y(new_n228_));
  NOR2x1_ASAP7_75t_R   g207(.A(new_n40_), .B(new_n228_), .Y(new_n229_));
  OR3x1_ASAP7_75t_R    g208(.A(new_n226_), .B(new_n227_), .C(new_n229_), .Y(new_n230_));
  AO32x1_ASAP7_75t_R   g209(.A1(new_n224_), .A2(new_n25_), .A3(new_n77_), .B1(new_n230_), .B2(p2), .Y(new_n231_));
  AND3x1_ASAP7_75t_R   g210(.A(new_n70_), .B(p9), .C(new_n74_), .Y(new_n232_));
  AO21x1_ASAP7_75t_R   g211(.A1(p6), .A2(new_n128_), .B(new_n23_), .Y(new_n233_));
  AO32x1_ASAP7_75t_R   g212(.A1(new_n233_), .A2(p0), .A3(new_n54_), .B1(p9), .B2(new_n41_), .Y(new_n234_));
  AND5x1_ASAP7_75t_R   g213(.A(new_n104_), .B(new_n234_), .C(new_n74_), .D(new_n63_), .E(new_n78_), .Y(new_n235_));
  AOI221x1_ASAP7_75t_R g214(.A1(new_n221_), .A2(new_n222_), .B1(new_n231_), .B2(new_n232_), .C(new_n235_), .Y(new_n236_));
  OAI21x1_ASAP7_75t_R  g215(.A1(p6), .A2(new_n211_), .B(new_n236_), .Y(o2));
  AOI21x1_ASAP7_75t_R  g216(.A1(new_n30_), .A2(new_n190_), .B(new_n112_), .Y(new_n238_));
  NOR2x1_ASAP7_75t_R   g217(.A(p4), .B(new_n25_), .Y(new_n239_));
  AO32x1_ASAP7_75t_R   g218(.A1(p8), .A2(new_n63_), .A3(new_n57_), .B1(new_n239_), .B2(new_n122_), .Y(new_n240_));
  OA21x2_ASAP7_75t_R   g219(.A1(new_n238_), .A2(new_n240_), .B(p0), .Y(new_n241_));
  AND3x1_ASAP7_75t_R   g220(.A(new_n78_), .B(new_n27_), .C(p3), .Y(new_n242_));
  NOR2x1_ASAP7_75t_R   g221(.A(p4), .B(p5), .Y(new_n243_));
  INVx1_ASAP7_75t_R    g222(.A(new_n243_), .Y(new_n244_));
  NAND2x1_ASAP7_75t_R  g223(.A(new_n111_), .B(new_n244_), .Y(new_n245_));
  AO21x1_ASAP7_75t_R   g224(.A1(p7), .A2(p8), .B(p4), .Y(new_n246_));
  NOR2x1_ASAP7_75t_R   g225(.A(p0), .B(new_n30_), .Y(new_n247_));
  NAND2x1_ASAP7_75t_R  g226(.A(p8), .B(new_n63_), .Y(new_n248_));
  AO32x1_ASAP7_75t_R   g227(.A1(p1), .A2(p5), .A3(new_n141_), .B1(new_n247_), .B2(new_n248_), .Y(new_n249_));
  AO32x1_ASAP7_75t_R   g228(.A1(new_n242_), .A2(new_n245_), .A3(new_n246_), .B1(new_n249_), .B2(new_n104_), .Y(new_n250_));
  AO21x1_ASAP7_75t_R   g229(.A1(new_n104_), .A2(new_n241_), .B(new_n250_), .Y(new_n251_));
  AO21x1_ASAP7_75t_R   g230(.A1(new_n40_), .A2(new_n63_), .B(new_n50_), .Y(new_n252_));
  AO32x1_ASAP7_75t_R   g231(.A1(new_n74_), .A2(p5), .A3(new_n173_), .B1(new_n252_), .B2(new_n187_), .Y(new_n253_));
  AO21x1_ASAP7_75t_R   g232(.A1(new_n74_), .A2(new_n63_), .B(new_n113_), .Y(new_n254_));
  OA211x2_ASAP7_75t_R  g233(.A1(new_n37_), .A2(new_n100_), .B(new_n254_), .C(p2), .Y(new_n255_));
  AOI211x1_ASAP7_75t_R g234(.A1(new_n27_), .A2(new_n202_), .B(new_n253_), .C(new_n255_), .Y(new_n256_));
  NOR2x1_ASAP7_75t_R   g235(.A(p1), .B(new_n74_), .Y(new_n257_));
  AO21x1_ASAP7_75t_R   g236(.A1(new_n257_), .A2(new_n216_), .B(new_n187_), .Y(new_n258_));
  INVx1_ASAP7_75t_R    g237(.A(new_n37_), .Y(new_n259_));
  AO21x1_ASAP7_75t_R   g238(.A1(p2), .A2(new_n40_), .B(p5), .Y(new_n260_));
  AO32x1_ASAP7_75t_R   g239(.A1(new_n259_), .A2(new_n228_), .A3(new_n186_), .B1(new_n260_), .B2(new_n157_), .Y(new_n261_));
  OAI21x1_ASAP7_75t_R  g240(.A1(new_n258_), .A2(new_n261_), .B(new_n151_), .Y(new_n262_));
  NOR2x1_ASAP7_75t_R   g241(.A(p5), .B(new_n30_), .Y(new_n263_));
  AO32x1_ASAP7_75t_R   g242(.A1(new_n97_), .A2(new_n153_), .A3(p4), .B1(p5), .B2(new_n178_), .Y(new_n264_));
  OR3x1_ASAP7_75t_R    g243(.A(new_n25_), .B(new_n30_), .C(p5), .Y(new_n265_));
  OR3x1_ASAP7_75t_R    g244(.A(new_n78_), .B(p4), .C(new_n63_), .Y(new_n266_));
  AOI21x1_ASAP7_75t_R  g245(.A1(new_n265_), .A2(new_n266_), .B(new_n77_), .Y(new_n267_));
  AOI221x1_ASAP7_75t_R g246(.A1(new_n263_), .A2(new_n158_), .B1(new_n24_), .B2(new_n264_), .C(new_n267_), .Y(new_n268_));
  NAND3x1_ASAP7_75t_R  g247(.A(new_n256_), .B(new_n262_), .C(new_n268_), .Y(new_n269_));
  AO32x1_ASAP7_75t_R   g248(.A1(new_n23_), .A2(new_n251_), .A3(new_n81_), .B1(new_n269_), .B2(new_n70_), .Y(o3));
  AND3x1_ASAP7_75t_R   g249(.A(new_n95_), .B(p1), .C(new_n104_), .Y(new_n271_));
  NOR2x1_ASAP7_75t_R   g250(.A(p2), .B(new_n104_), .Y(new_n272_));
  NOR2x1_ASAP7_75t_R   g251(.A(p3), .B(new_n30_), .Y(new_n273_));
  OA21x2_ASAP7_75t_R   g252(.A1(new_n272_), .A2(new_n273_), .B(new_n107_), .Y(new_n274_));
  NOR2x1_ASAP7_75t_R   g253(.A(p6), .B(new_n111_), .Y(new_n275_));
  OA21x2_ASAP7_75t_R   g254(.A1(new_n271_), .A2(new_n274_), .B(new_n275_), .Y(o4));
  AND3x1_ASAP7_75t_R   g255(.A(new_n91_), .B(new_n78_), .C(p3), .Y(new_n277_));
  OA211x2_ASAP7_75t_R  g256(.A1(p1), .A2(new_n95_), .B(new_n275_), .C(new_n273_), .Y(new_n278_));
  AO21x1_ASAP7_75t_R   g257(.A1(new_n275_), .A2(new_n277_), .B(new_n278_), .Y(o5));
  INVx1_ASAP7_75t_R    g258(.A(new_n141_), .Y(new_n280_));
  AND5x1_ASAP7_75t_R   g259(.A(p9), .B(new_n146_), .C(new_n113_), .D(new_n73_), .E(p7), .Y(new_n281_));
  AO221x2_ASAP7_75t_R  g260(.A1(p4), .A2(new_n41_), .B1(new_n280_), .B2(new_n212_), .C(new_n281_), .Y(new_n282_));
  NOR2x1_ASAP7_75t_R   g261(.A(new_n97_), .B(new_n136_), .Y(new_n283_));
  OR3x1_ASAP7_75t_R    g262(.A(new_n216_), .B(new_n283_), .C(new_n63_), .Y(new_n284_));
  OR4x2_ASAP7_75t_R    g263(.A(new_n50_), .B(new_n25_), .C(p9), .D(new_n40_), .Y(new_n285_));
  OA21x2_ASAP7_75t_R   g264(.A1(new_n54_), .A2(new_n146_), .B(new_n285_), .Y(new_n286_));
  NAND2x1_ASAP7_75t_R  g265(.A(new_n284_), .B(new_n286_), .Y(new_n287_));
  OAI21x1_ASAP7_75t_R  g266(.A1(new_n282_), .A2(new_n287_), .B(new_n30_), .Y(new_n288_));
  INVx1_ASAP7_75t_R    g267(.A(new_n164_), .Y(new_n289_));
  NOR2x1_ASAP7_75t_R   g268(.A(new_n22_), .B(new_n87_), .Y(new_n290_));
  NAND2x1_ASAP7_75t_R  g269(.A(p1), .B(new_n23_), .Y(new_n291_));
  AO32x1_ASAP7_75t_R   g270(.A1(new_n195_), .A2(p9), .A3(p5), .B1(new_n28_), .B2(new_n291_), .Y(new_n292_));
  AO22x1_ASAP7_75t_R   g271(.A1(new_n289_), .A2(new_n290_), .B1(p8), .B2(new_n292_), .Y(new_n293_));
  OR3x1_ASAP7_75t_R    g272(.A(new_n100_), .B(new_n65_), .C(new_n158_), .Y(new_n294_));
  NOR2x1_ASAP7_75t_R   g273(.A(p9), .B(p5), .Y(new_n295_));
  NOR2x1_ASAP7_75t_R   g274(.A(new_n295_), .B(new_n155_), .Y(new_n296_));
  INVx1_ASAP7_75t_R    g275(.A(new_n122_), .Y(new_n297_));
  AO21x1_ASAP7_75t_R   g276(.A1(new_n27_), .A2(new_n297_), .B(new_n23_), .Y(new_n298_));
  OAI22x1_ASAP7_75t_R  g277(.A1(new_n294_), .A2(new_n296_), .B1(new_n298_), .B2(new_n135_), .Y(new_n299_));
  AOI22x1_ASAP7_75t_R  g278(.A1(new_n293_), .A2(p2), .B1(new_n31_), .B2(new_n299_), .Y(new_n300_));
  AO21x1_ASAP7_75t_R   g279(.A1(p5), .A2(new_n40_), .B(p9), .Y(new_n301_));
  AO32x1_ASAP7_75t_R   g280(.A1(new_n301_), .A2(new_n259_), .A3(new_n42_), .B1(new_n43_), .B2(new_n152_), .Y(new_n302_));
  OA21x2_ASAP7_75t_R   g281(.A1(p7), .A2(p8), .B(p1), .Y(new_n303_));
  OA211x2_ASAP7_75t_R  g282(.A1(new_n212_), .A2(new_n303_), .B(p0), .C(p5), .Y(new_n304_));
  OR3x1_ASAP7_75t_R    g283(.A(new_n239_), .B(new_n54_), .C(p5), .Y(new_n305_));
  AO21x1_ASAP7_75t_R   g284(.A1(new_n55_), .A2(new_n257_), .B(new_n33_), .Y(new_n306_));
  AND3x1_ASAP7_75t_R   g285(.A(new_n305_), .B(new_n306_), .C(new_n28_), .Y(new_n307_));
  AOI211x1_ASAP7_75t_R g286(.A1(new_n27_), .A2(new_n302_), .B(new_n304_), .C(new_n307_), .Y(new_n308_));
  NAND3x1_ASAP7_75t_R  g287(.A(new_n288_), .B(new_n300_), .C(new_n308_), .Y(new_n309_));
  AO21x1_ASAP7_75t_R   g288(.A1(new_n124_), .A2(new_n100_), .B(new_n122_), .Y(new_n310_));
  AO21x1_ASAP7_75t_R   g289(.A1(p6), .A2(new_n32_), .B(new_n40_), .Y(new_n311_));
  AO22x1_ASAP7_75t_R   g290(.A1(p0), .A2(new_n42_), .B1(new_n26_), .B2(new_n311_), .Y(new_n312_));
  AO32x1_ASAP7_75t_R   g291(.A1(new_n25_), .A2(p6), .A3(new_n310_), .B1(new_n312_), .B2(new_n23_), .Y(new_n313_));
  AO221x2_ASAP7_75t_R  g292(.A1(new_n81_), .A2(new_n277_), .B1(new_n313_), .B2(new_n179_), .C(new_n275_), .Y(new_n314_));
  AOI21x1_ASAP7_75t_R  g293(.A1(new_n70_), .A2(new_n309_), .B(new_n314_), .Y(o6));
  AND3x1_ASAP7_75t_R   g294(.A(new_n206_), .B(p1), .C(new_n23_), .Y(new_n316_));
  AO32x1_ASAP7_75t_R   g295(.A1(p6), .A2(new_n32_), .A3(new_n163_), .B1(new_n316_), .B2(new_n297_), .Y(new_n317_));
  AND3x1_ASAP7_75t_R   g296(.A(new_n317_), .B(new_n60_), .C(new_n243_), .Y(new_n318_));
  OA21x2_ASAP7_75t_R   g297(.A1(new_n81_), .A2(new_n318_), .B(new_n104_), .Y(new_n319_));
  AOI21x1_ASAP7_75t_R  g298(.A1(new_n64_), .A2(new_n190_), .B(new_n32_), .Y(new_n320_));
  NAND2x1_ASAP7_75t_R  g299(.A(p7), .B(new_n23_), .Y(new_n321_));
  NAND2x1_ASAP7_75t_R  g300(.A(new_n321_), .B(new_n190_), .Y(new_n322_));
  AOI21x1_ASAP7_75t_R  g301(.A1(p8), .A2(p5), .B(p7), .Y(new_n323_));
  AOI211x1_ASAP7_75t_R g302(.A1(new_n23_), .A2(p8), .B(new_n295_), .C(new_n323_), .Y(new_n324_));
  AOI22x1_ASAP7_75t_R  g303(.A1(new_n320_), .A2(new_n322_), .B1(new_n64_), .B2(new_n324_), .Y(new_n325_));
  AO21x1_ASAP7_75t_R   g304(.A1(p2), .A2(new_n206_), .B(new_n124_), .Y(new_n326_));
  AO32x1_ASAP7_75t_R   g305(.A1(new_n128_), .A2(p1), .A3(new_n30_), .B1(new_n113_), .B2(new_n166_), .Y(new_n327_));
  AOI21x1_ASAP7_75t_R  g306(.A1(new_n156_), .A2(new_n326_), .B(new_n327_), .Y(new_n328_));
  OAI21x1_ASAP7_75t_R  g307(.A1(p1), .A2(new_n325_), .B(new_n328_), .Y(new_n329_));
  NAND2x1_ASAP7_75t_R  g308(.A(p5), .B(new_n23_), .Y(new_n330_));
  AOI21x1_ASAP7_75t_R  g309(.A1(new_n206_), .A2(new_n297_), .B(new_n330_), .Y(new_n331_));
  OA221x2_ASAP7_75t_R  g310(.A1(new_n23_), .A2(p8), .B1(new_n113_), .B2(new_n133_), .C(new_n25_), .Y(new_n332_));
  OAI21x1_ASAP7_75t_R  g311(.A1(new_n331_), .A2(new_n332_), .B(new_n247_), .Y(new_n333_));
  OAI21x1_ASAP7_75t_R  g312(.A1(p5), .A2(new_n166_), .B(new_n303_), .Y(new_n334_));
  OR3x1_ASAP7_75t_R    g313(.A(new_n52_), .B(new_n23_), .C(p8), .Y(new_n335_));
  AO31x2_ASAP7_75t_R   g314(.A1(new_n334_), .A2(new_n335_), .A3(new_n123_), .B(p0), .Y(new_n336_));
  OR5x1_ASAP7_75t_R    g315(.A(p1), .B(new_n30_), .C(new_n63_), .D(p7), .E(p8), .Y(new_n337_));
  NAND3x1_ASAP7_75t_R  g316(.A(new_n333_), .B(new_n336_), .C(new_n337_), .Y(new_n338_));
  AOI21x1_ASAP7_75t_R  g317(.A1(p0), .A2(new_n329_), .B(new_n338_), .Y(new_n339_));
  AO21x1_ASAP7_75t_R   g318(.A1(p9), .A2(p2), .B(p1), .Y(new_n340_));
  AOI22x1_ASAP7_75t_R  g319(.A1(p1), .A2(p2), .B1(p7), .B2(p8), .Y(new_n341_));
  AOI21x1_ASAP7_75t_R  g320(.A1(new_n341_), .A2(new_n297_), .B(new_n90_), .Y(new_n342_));
  NAND3x1_ASAP7_75t_R  g321(.A(p1), .B(p2), .C(p4), .Y(new_n343_));
  OAI22x1_ASAP7_75t_R  g322(.A1(new_n225_), .A2(new_n79_), .B1(new_n206_), .B2(new_n343_), .Y(new_n344_));
  AOI21x1_ASAP7_75t_R  g323(.A1(new_n340_), .A2(new_n342_), .B(new_n344_), .Y(new_n345_));
  AND2x2_ASAP7_75t_R   g324(.A(p2), .B(p4), .Y(new_n346_));
  AO21x1_ASAP7_75t_R   g325(.A1(p1), .A2(new_n32_), .B(new_n346_), .Y(new_n347_));
  AND3x1_ASAP7_75t_R   g326(.A(new_n257_), .B(p2), .C(new_n206_), .Y(new_n348_));
  AOI21x1_ASAP7_75t_R  g327(.A1(new_n22_), .A2(new_n347_), .B(new_n348_), .Y(new_n349_));
  AND3x1_ASAP7_75t_R   g328(.A(new_n43_), .B(new_n40_), .C(p4), .Y(new_n350_));
  NAND2x1_ASAP7_75t_R  g329(.A(p4), .B(new_n23_), .Y(new_n351_));
  OAI21x1_ASAP7_75t_R  g330(.A1(p1), .A2(p8), .B(p9), .Y(new_n352_));
  OAI22x1_ASAP7_75t_R  g331(.A1(new_n351_), .A2(p8), .B1(new_n43_), .B2(new_n352_), .Y(new_n353_));
  AO31x2_ASAP7_75t_R   g332(.A1(p1), .A2(p4), .A3(p8), .B(p7), .Y(new_n354_));
  AND2x2_ASAP7_75t_R   g333(.A(new_n30_), .B(new_n354_), .Y(new_n355_));
  OAI21x1_ASAP7_75t_R  g334(.A1(new_n350_), .A2(new_n353_), .B(new_n355_), .Y(new_n356_));
  NAND3x1_ASAP7_75t_R  g335(.A(new_n345_), .B(new_n349_), .C(new_n356_), .Y(new_n357_));
  AOI21x1_ASAP7_75t_R  g336(.A1(new_n27_), .A2(new_n345_), .B(p5), .Y(new_n358_));
  AOI21x1_ASAP7_75t_R  g337(.A1(new_n357_), .A2(new_n358_), .B(new_n318_), .Y(new_n359_));
  OAI21x1_ASAP7_75t_R  g338(.A1(p4), .A2(new_n339_), .B(new_n359_), .Y(new_n360_));
  AND3x1_ASAP7_75t_R   g339(.A(new_n277_), .B(new_n81_), .C(new_n243_), .Y(new_n361_));
  AOI21x1_ASAP7_75t_R  g340(.A1(new_n319_), .A2(new_n360_), .B(new_n361_), .Y(o7));
  OA211x2_ASAP7_75t_R  g341(.A1(p4), .A2(new_n152_), .B(new_n155_), .C(new_n147_), .Y(new_n363_));
  INVx1_ASAP7_75t_R    g342(.A(new_n39_), .Y(new_n364_));
  AND5x1_ASAP7_75t_R   g343(.A(new_n25_), .B(new_n364_), .C(new_n157_), .D(p7), .E(new_n141_), .Y(new_n365_));
  AND3x1_ASAP7_75t_R   g344(.A(new_n124_), .B(new_n74_), .C(new_n60_), .Y(new_n366_));
  OR3x1_ASAP7_75t_R    g345(.A(new_n363_), .B(new_n365_), .C(new_n366_), .Y(new_n367_));
  INVx1_ASAP7_75t_R    g346(.A(new_n248_), .Y(new_n368_));
  AND3x1_ASAP7_75t_R   g347(.A(new_n186_), .B(p0), .C(new_n66_), .Y(new_n369_));
  AO21x1_ASAP7_75t_R   g348(.A1(p1), .A2(new_n74_), .B(new_n346_), .Y(new_n370_));
  AO32x1_ASAP7_75t_R   g349(.A1(new_n351_), .A2(new_n247_), .A3(new_n195_), .B1(new_n369_), .B2(new_n370_), .Y(new_n371_));
  AOI22x1_ASAP7_75t_R  g350(.A1(new_n367_), .A2(new_n113_), .B1(new_n368_), .B2(new_n371_), .Y(new_n372_));
  NAND2x1_ASAP7_75t_R  g351(.A(new_n27_), .B(new_n74_), .Y(new_n373_));
  NAND2x1_ASAP7_75t_R  g352(.A(p1), .B(new_n30_), .Y(new_n374_));
  AO21x1_ASAP7_75t_R   g353(.A1(new_n373_), .A2(new_n101_), .B(new_n374_), .Y(new_n375_));
  NAND2x1_ASAP7_75t_R  g354(.A(new_n65_), .B(new_n257_), .Y(new_n376_));
  AO21x1_ASAP7_75t_R   g355(.A1(new_n191_), .A2(new_n376_), .B(p9), .Y(new_n377_));
  NOR2x1_ASAP7_75t_R   g356(.A(p2), .B(new_n32_), .Y(new_n378_));
  OR5x1_ASAP7_75t_R    g357(.A(p1), .B(new_n31_), .C(new_n280_), .D(new_n378_), .E(new_n65_), .Y(new_n379_));
  NAND3x1_ASAP7_75t_R  g358(.A(new_n375_), .B(new_n377_), .C(new_n379_), .Y(new_n380_));
  NAND2x1_ASAP7_75t_R  g359(.A(new_n133_), .B(new_n380_), .Y(new_n381_));
  NOR2x1_ASAP7_75t_R   g360(.A(p5), .B(new_n28_), .Y(new_n382_));
  AO21x1_ASAP7_75t_R   g361(.A1(p8), .A2(new_n27_), .B(new_n63_), .Y(new_n383_));
  AO21x1_ASAP7_75t_R   g362(.A1(new_n87_), .A2(new_n152_), .B(new_n383_), .Y(new_n384_));
  AO221x2_ASAP7_75t_R  g363(.A1(new_n298_), .A2(new_n382_), .B1(new_n384_), .B2(new_n25_), .C(new_n157_), .Y(new_n385_));
  NAND3x1_ASAP7_75t_R  g364(.A(new_n372_), .B(new_n381_), .C(new_n385_), .Y(new_n386_));
  NAND2x1_ASAP7_75t_R  g365(.A(new_n23_), .B(new_n32_), .Y(new_n387_));
  AOI22x1_ASAP7_75t_R  g366(.A1(new_n43_), .A2(new_n22_), .B1(new_n124_), .B2(new_n42_), .Y(new_n388_));
  OAI21x1_ASAP7_75t_R  g367(.A1(new_n387_), .A2(new_n283_), .B(new_n388_), .Y(new_n389_));
  AO32x1_ASAP7_75t_R   g368(.A1(new_n25_), .A2(new_n22_), .A3(new_n100_), .B1(new_n389_), .B2(new_n27_), .Y(new_n390_));
  AO32x1_ASAP7_75t_R   g369(.A1(new_n81_), .A2(new_n74_), .A3(new_n277_), .B1(new_n390_), .B2(new_n179_), .Y(new_n391_));
  AOI21x1_ASAP7_75t_R  g370(.A1(new_n70_), .A2(new_n386_), .B(new_n391_), .Y(o8));
  OR3x1_ASAP7_75t_R    g371(.A(new_n265_), .B(new_n23_), .C(p4), .Y(new_n393_));
  AO22x1_ASAP7_75t_R   g372(.A1(new_n27_), .A2(new_n297_), .B1(new_n81_), .B2(new_n393_), .Y(new_n394_));
  AO21x1_ASAP7_75t_R   g373(.A1(new_n74_), .A2(new_n374_), .B(new_n63_), .Y(new_n395_));
  OR4x2_ASAP7_75t_R    g374(.A(new_n23_), .B(p0), .C(p1), .D(p2), .Y(new_n396_));
  OAI21x1_ASAP7_75t_R  g375(.A1(p9), .A2(new_n374_), .B(p6), .Y(new_n397_));
  AND5x1_ASAP7_75t_R   g376(.A(new_n208_), .B(new_n394_), .C(new_n395_), .D(new_n396_), .E(new_n397_), .Y(new_n398_));
  AND3x1_ASAP7_75t_R   g377(.A(new_n303_), .B(new_n30_), .C(new_n246_), .Y(new_n399_));
  AO21x1_ASAP7_75t_R   g378(.A1(new_n272_), .A2(new_n244_), .B(p1), .Y(new_n400_));
  AO21x1_ASAP7_75t_R   g379(.A1(p2), .A2(new_n32_), .B(new_n263_), .Y(new_n401_));
  OA21x2_ASAP7_75t_R   g380(.A1(new_n321_), .A2(new_n254_), .B(new_n401_), .Y(new_n402_));
  NOR2x1_ASAP7_75t_R   g381(.A(new_n400_), .B(new_n402_), .Y(new_n403_));
  OAI21x1_ASAP7_75t_R  g382(.A1(new_n399_), .A2(new_n403_), .B(new_n27_), .Y(new_n404_));
  OA21x2_ASAP7_75t_R   g383(.A1(p2), .A2(new_n50_), .B(new_n321_), .Y(new_n405_));
  OR3x1_ASAP7_75t_R    g384(.A(new_n401_), .B(new_n405_), .C(p1), .Y(new_n406_));
  OR3x1_ASAP7_75t_R    g385(.A(new_n254_), .B(p2), .C(new_n133_), .Y(new_n407_));
  OA21x2_ASAP7_75t_R   g386(.A1(new_n246_), .A2(new_n265_), .B(new_n407_), .Y(new_n408_));
  AO21x1_ASAP7_75t_R   g387(.A1(new_n406_), .A2(new_n408_), .B(new_n27_), .Y(new_n409_));
  AND3x1_ASAP7_75t_R   g388(.A(new_n398_), .B(new_n404_), .C(new_n409_), .Y(o9));
  AND3x1_ASAP7_75t_R   g389(.A(new_n243_), .B(new_n81_), .C(p2), .Y(new_n411_));
  AO21x1_ASAP7_75t_R   g390(.A1(p0), .A2(new_n54_), .B(new_n40_), .Y(new_n412_));
  AND3x1_ASAP7_75t_R   g391(.A(new_n271_), .B(new_n412_), .C(new_n77_), .Y(new_n413_));
  AO21x1_ASAP7_75t_R   g392(.A1(new_n411_), .A2(new_n413_), .B(new_n361_), .Y(o10));
endmodule


