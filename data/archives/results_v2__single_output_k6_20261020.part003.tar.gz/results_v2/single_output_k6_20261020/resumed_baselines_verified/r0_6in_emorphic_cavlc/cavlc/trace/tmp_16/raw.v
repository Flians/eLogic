// Benchmark "/tmp/" written by ABC on Tue Oct 20 17:20:34 2026

module \/tmp/  ( 
    p5, p2, p8, p3, p0, p7, p4, p6, p9, p1,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10  );
  input  p5, p2, p8, p3, p0, p7, p4, p6, p9, p1;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10;
  wire new_n22_, new_n23_, new_n24_, new_n25_, new_n26_, new_n27_, new_n28_,
    new_n29_, new_n30_, new_n31_, new_n32_, new_n33_, new_n34_, new_n35_,
    new_n36_, new_n37_, new_n38_, new_n39_, new_n40_, new_n41_, new_n42_,
    new_n43_, new_n44_, new_n45_, new_n46_, new_n47_, new_n48_, new_n49_,
    new_n50_, new_n51_, new_n52_, new_n53_, new_n54_, new_n55_, new_n56_,
    new_n57_, new_n58_, new_n59_, new_n60_, new_n61_, new_n62_, new_n63_,
    new_n64_, new_n65_, new_n66_, new_n67_, new_n68_, new_n69_, new_n70_,
    new_n71_, new_n72_, new_n73_, new_n74_, new_n75_, new_n76_, new_n77_,
    new_n78_, new_n79_, new_n80_, new_n81_, new_n82_, new_n83_, new_n84_,
    new_n85_, new_n86_, new_n87_, new_n88_, new_n89_, new_n90_, new_n91_,
    new_n92_, new_n93_, new_n94_, new_n95_, new_n96_, new_n97_, new_n98_,
    new_n99_, new_n100_, new_n101_, new_n102_, new_n103_, new_n104_,
    new_n105_, new_n106_, new_n107_, new_n108_, new_n109_, new_n110_,
    new_n111_, new_n112_, new_n113_, new_n114_, new_n116_, new_n117_,
    new_n118_, new_n119_, new_n120_, new_n121_, new_n122_, new_n123_,
    new_n124_, new_n125_, new_n126_, new_n127_, new_n128_, new_n129_,
    new_n130_, new_n131_, new_n132_, new_n133_, new_n134_, new_n135_,
    new_n136_, new_n137_, new_n138_, new_n139_, new_n140_, new_n141_,
    new_n142_, new_n143_, new_n144_, new_n145_, new_n146_, new_n147_,
    new_n148_, new_n149_, new_n150_, new_n151_, new_n152_, new_n153_,
    new_n154_, new_n155_, new_n156_, new_n157_, new_n158_, new_n159_,
    new_n160_, new_n161_, new_n162_, new_n163_, new_n164_, new_n165_,
    new_n166_, new_n167_, new_n168_, new_n169_, new_n170_, new_n171_,
    new_n172_, new_n173_, new_n174_, new_n175_, new_n176_, new_n177_,
    new_n178_, new_n179_, new_n180_, new_n181_, new_n182_, new_n183_,
    new_n184_, new_n185_, new_n186_, new_n187_, new_n188_, new_n190_,
    new_n191_, new_n192_, new_n193_, new_n194_, new_n195_, new_n196_,
    new_n197_, new_n198_, new_n199_, new_n200_, new_n201_, new_n202_,
    new_n203_, new_n204_, new_n205_, new_n206_, new_n207_, new_n208_,
    new_n209_, new_n210_, new_n211_, new_n212_, new_n213_, new_n214_,
    new_n215_, new_n216_, new_n217_, new_n218_, new_n219_, new_n220_,
    new_n221_, new_n222_, new_n223_, new_n224_, new_n225_, new_n226_,
    new_n227_, new_n228_, new_n229_, new_n230_, new_n231_, new_n232_,
    new_n233_, new_n234_, new_n235_, new_n236_, new_n237_, new_n238_,
    new_n239_, new_n240_, new_n241_, new_n242_, new_n243_, new_n244_,
    new_n245_, new_n247_, new_n248_, new_n249_, new_n250_, new_n251_,
    new_n252_, new_n253_, new_n254_, new_n255_, new_n256_, new_n257_,
    new_n258_, new_n259_, new_n260_, new_n261_, new_n262_, new_n263_,
    new_n264_, new_n265_, new_n266_, new_n267_, new_n268_, new_n269_,
    new_n270_, new_n271_, new_n272_, new_n273_, new_n274_, new_n275_,
    new_n276_, new_n278_, new_n279_, new_n280_, new_n281_, new_n282_,
    new_n284_, new_n285_, new_n287_, new_n288_, new_n289_, new_n290_,
    new_n291_, new_n292_, new_n293_, new_n294_, new_n295_, new_n296_,
    new_n297_, new_n298_, new_n299_, new_n300_, new_n301_, new_n302_,
    new_n303_, new_n304_, new_n305_, new_n306_, new_n307_, new_n308_,
    new_n309_, new_n310_, new_n311_, new_n312_, new_n313_, new_n314_,
    new_n315_, new_n316_, new_n317_, new_n318_, new_n319_, new_n320_,
    new_n322_, new_n323_, new_n324_, new_n325_, new_n326_, new_n327_,
    new_n328_, new_n329_, new_n330_, new_n331_, new_n332_, new_n333_,
    new_n334_, new_n335_, new_n336_, new_n337_, new_n338_, new_n339_,
    new_n340_, new_n341_, new_n342_, new_n343_, new_n344_, new_n345_,
    new_n346_, new_n347_, new_n348_, new_n349_, new_n350_, new_n351_,
    new_n352_, new_n353_, new_n354_, new_n355_, new_n356_, new_n357_,
    new_n358_, new_n359_, new_n360_, new_n361_, new_n362_, new_n363_,
    new_n364_, new_n366_, new_n367_, new_n368_, new_n369_, new_n370_,
    new_n371_, new_n372_, new_n373_, new_n374_, new_n375_, new_n376_,
    new_n377_, new_n378_, new_n379_, new_n380_, new_n381_, new_n382_,
    new_n383_, new_n384_, new_n385_, new_n386_, new_n387_, new_n388_,
    new_n389_, new_n390_, new_n391_, new_n392_, new_n393_, new_n394_,
    new_n395_, new_n397_, new_n398_, new_n399_, new_n400_, new_n401_,
    new_n402_, new_n403_, new_n404_, new_n405_, new_n406_, new_n407_,
    new_n408_, new_n409_, new_n410_, new_n411_, new_n412_, new_n413_,
    new_n415_, new_n416_, new_n417_;
  INVx1_ASAP7_75t_R    g000(.A(p3), .Y(new_n22_));
  AND2x2_ASAP7_75t_R   g001(.A(p8), .B(p1), .Y(new_n23_));
  INVx1_ASAP7_75t_R    g002(.A(p8), .Y(new_n24_));
  INVx1_ASAP7_75t_R    g003(.A(p1), .Y(new_n25_));
  AND3x1_ASAP7_75t_R   g004(.A(new_n24_), .B(new_n25_), .C(p0), .Y(new_n26_));
  NOR2x1_ASAP7_75t_R   g005(.A(new_n23_), .B(new_n26_), .Y(new_n27_));
  INVx1_ASAP7_75t_R    g006(.A(p5), .Y(new_n28_));
  INVx1_ASAP7_75t_R    g007(.A(p7), .Y(new_n29_));
  OR4x2_ASAP7_75t_R    g008(.A(new_n28_), .B(new_n29_), .C(p2), .D(p9), .Y(new_n30_));
  NOR2x1_ASAP7_75t_R   g009(.A(p2), .B(p0), .Y(new_n31_));
  INVx1_ASAP7_75t_R    g010(.A(new_n31_), .Y(new_n32_));
  NOR2x1_ASAP7_75t_R   g011(.A(p7), .B(p1), .Y(new_n33_));
  NOR2x1_ASAP7_75t_R   g012(.A(p8), .B(p9), .Y(new_n34_));
  NAND2x1_ASAP7_75t_R  g013(.A(new_n33_), .B(new_n34_), .Y(new_n35_));
  OA22x2_ASAP7_75t_R   g014(.A1(new_n27_), .A2(new_n30_), .B1(new_n32_), .B2(new_n35_), .Y(new_n36_));
  NAND2x1_ASAP7_75t_R  g015(.A(p2), .B(new_n28_), .Y(new_n37_));
  NOR2x1_ASAP7_75t_R   g016(.A(p8), .B(p0), .Y(new_n38_));
  NAND2x1_ASAP7_75t_R  g017(.A(p2), .B(p1), .Y(new_n39_));
  AO32x1_ASAP7_75t_R   g018(.A1(new_n37_), .A2(new_n38_), .A3(new_n39_), .B1(p8), .B2(p1), .Y(new_n40_));
  NOR2x1_ASAP7_75t_R   g019(.A(p7), .B(p4), .Y(new_n41_));
  INVx1_ASAP7_75t_R    g020(.A(p0), .Y(new_n42_));
  NOR2x1_ASAP7_75t_R   g021(.A(p7), .B(new_n42_), .Y(new_n43_));
  AO21x1_ASAP7_75t_R   g022(.A1(new_n23_), .A2(new_n31_), .B(new_n43_), .Y(new_n44_));
  NOR2x1_ASAP7_75t_R   g023(.A(p4), .B(p9), .Y(new_n45_));
  AOI22x1_ASAP7_75t_R  g024(.A1(new_n40_), .A2(new_n41_), .B1(new_n44_), .B2(new_n45_), .Y(new_n46_));
  AO21x1_ASAP7_75t_R   g025(.A1(p9), .A2(new_n24_), .B(p1), .Y(new_n47_));
  AND2x2_ASAP7_75t_R   g026(.A(p7), .B(p4), .Y(new_n48_));
  INVx1_ASAP7_75t_R    g027(.A(new_n48_), .Y(new_n49_));
  AOI21x1_ASAP7_75t_R  g028(.A1(new_n28_), .A2(new_n47_), .B(new_n49_), .Y(new_n50_));
  NOR2x1_ASAP7_75t_R   g029(.A(p2), .B(new_n42_), .Y(new_n51_));
  INVx1_ASAP7_75t_R    g030(.A(p9), .Y(new_n52_));
  NAND2x1_ASAP7_75t_R  g031(.A(p8), .B(new_n52_), .Y(new_n53_));
  AO21x1_ASAP7_75t_R   g032(.A1(new_n51_), .A2(new_n53_), .B(new_n47_), .Y(new_n54_));
  NAND2x1_ASAP7_75t_R  g033(.A(new_n50_), .B(new_n54_), .Y(new_n55_));
  NAND3x1_ASAP7_75t_R  g034(.A(new_n36_), .B(new_n46_), .C(new_n55_), .Y(new_n56_));
  NOR2x1_ASAP7_75t_R   g035(.A(p8), .B(new_n52_), .Y(new_n57_));
  NOR2x1_ASAP7_75t_R   g036(.A(p9), .B(new_n24_), .Y(new_n58_));
  AO32x1_ASAP7_75t_R   g037(.A1(new_n57_), .A2(new_n42_), .A3(p1), .B1(new_n58_), .B2(new_n29_), .Y(new_n59_));
  INVx1_ASAP7_75t_R    g038(.A(p4), .Y(new_n60_));
  OAI21x1_ASAP7_75t_R  g039(.A1(new_n43_), .A2(new_n59_), .B(new_n60_), .Y(new_n61_));
  NAND2x1_ASAP7_75t_R  g040(.A(p9), .B(new_n24_), .Y(new_n62_));
  AND5x1_ASAP7_75t_R   g041(.A(p0), .B(new_n62_), .C(new_n53_), .D(p4), .E(p1), .Y(new_n63_));
  AND3x1_ASAP7_75t_R   g042(.A(new_n42_), .B(new_n52_), .C(new_n25_), .Y(new_n64_));
  NOR2x1_ASAP7_75t_R   g043(.A(p8), .B(p4), .Y(new_n65_));
  INVx1_ASAP7_75t_R    g044(.A(new_n65_), .Y(new_n66_));
  AND2x2_ASAP7_75t_R   g045(.A(p5), .B(p7), .Y(new_n67_));
  OA211x2_ASAP7_75t_R  g046(.A1(p4), .A2(new_n64_), .B(new_n66_), .C(new_n67_), .Y(new_n68_));
  AOI21x1_ASAP7_75t_R  g047(.A1(p7), .A2(new_n63_), .B(new_n68_), .Y(new_n69_));
  NAND2x1_ASAP7_75t_R  g048(.A(p2), .B(new_n22_), .Y(new_n70_));
  AOI21x1_ASAP7_75t_R  g049(.A1(new_n61_), .A2(new_n69_), .B(new_n70_), .Y(new_n71_));
  NOR2x1_ASAP7_75t_R   g050(.A(p5), .B(p8), .Y(new_n72_));
  AND2x2_ASAP7_75t_R   g051(.A(p3), .B(p7), .Y(new_n73_));
  NOR2x1_ASAP7_75t_R   g052(.A(new_n72_), .B(new_n73_), .Y(new_n74_));
  AO21x1_ASAP7_75t_R   g053(.A1(p7), .A2(new_n28_), .B(new_n60_), .Y(new_n75_));
  AO21x1_ASAP7_75t_R   g054(.A1(p8), .A2(new_n22_), .B(new_n72_), .Y(new_n76_));
  AND2x2_ASAP7_75t_R   g055(.A(p5), .B(p4), .Y(new_n77_));
  OR3x1_ASAP7_75t_R    g056(.A(new_n76_), .B(p7), .C(new_n77_), .Y(new_n78_));
  OAI21x1_ASAP7_75t_R  g057(.A1(new_n74_), .A2(new_n75_), .B(new_n78_), .Y(new_n79_));
  NOR2x1_ASAP7_75t_R   g058(.A(p2), .B(p1), .Y(new_n80_));
  NOR2x1_ASAP7_75t_R   g059(.A(p0), .B(p9), .Y(new_n81_));
  AND3x1_ASAP7_75t_R   g060(.A(new_n79_), .B(new_n80_), .C(new_n81_), .Y(new_n82_));
  AOI211x1_ASAP7_75t_R g061(.A1(new_n22_), .A2(new_n56_), .B(new_n71_), .C(new_n82_), .Y(new_n83_));
  NOR2x1_ASAP7_75t_R   g062(.A(p4), .B(new_n29_), .Y(new_n84_));
  INVx1_ASAP7_75t_R    g063(.A(p6), .Y(new_n85_));
  OA211x2_ASAP7_75t_R  g064(.A1(new_n85_), .A2(new_n65_), .B(new_n25_), .C(p9), .Y(new_n86_));
  NAND2x1_ASAP7_75t_R  g065(.A(p0), .B(new_n24_), .Y(new_n87_));
  INVx1_ASAP7_75t_R    g066(.A(p2), .Y(new_n88_));
  OA21x2_ASAP7_75t_R   g067(.A1(p6), .A2(new_n87_), .B(new_n88_), .Y(new_n89_));
  OA21x2_ASAP7_75t_R   g068(.A1(new_n84_), .A2(new_n86_), .B(new_n89_), .Y(new_n90_));
  NAND2x1_ASAP7_75t_R  g069(.A(p9), .B(new_n25_), .Y(new_n91_));
  AO21x1_ASAP7_75t_R   g070(.A1(new_n42_), .A2(new_n66_), .B(new_n91_), .Y(new_n92_));
  INVx1_ASAP7_75t_R    g071(.A(new_n38_), .Y(new_n93_));
  NAND2x1_ASAP7_75t_R  g072(.A(p1), .B(new_n52_), .Y(new_n94_));
  OR3x1_ASAP7_75t_R    g073(.A(new_n93_), .B(new_n94_), .C(new_n85_), .Y(new_n95_));
  NAND2x1_ASAP7_75t_R  g074(.A(new_n92_), .B(new_n95_), .Y(new_n96_));
  NOR2x1_ASAP7_75t_R   g075(.A(p0), .B(new_n24_), .Y(new_n97_));
  INVx1_ASAP7_75t_R    g076(.A(new_n80_), .Y(new_n98_));
  AND3x1_ASAP7_75t_R   g077(.A(new_n42_), .B(p2), .C(p9), .Y(new_n99_));
  AOI211x1_ASAP7_75t_R g078(.A1(new_n97_), .A2(new_n98_), .B(new_n51_), .C(new_n99_), .Y(new_n100_));
  NAND2x1_ASAP7_75t_R  g079(.A(p4), .B(new_n52_), .Y(new_n101_));
  AO21x1_ASAP7_75t_R   g080(.A1(p9), .A2(new_n42_), .B(new_n25_), .Y(new_n102_));
  AO21x1_ASAP7_75t_R   g081(.A1(new_n101_), .A2(new_n102_), .B(p8), .Y(new_n103_));
  AOI21x1_ASAP7_75t_R  g082(.A1(new_n100_), .A2(new_n103_), .B(p6), .Y(new_n104_));
  NOR2x1_ASAP7_75t_R   g083(.A(p2), .B(p4), .Y(new_n105_));
  AND2x2_ASAP7_75t_R   g084(.A(p0), .B(p9), .Y(new_n106_));
  INVx1_ASAP7_75t_R    g085(.A(new_n106_), .Y(new_n107_));
  NOR2x1_ASAP7_75t_R   g086(.A(p6), .B(new_n81_), .Y(new_n108_));
  AO21x1_ASAP7_75t_R   g087(.A1(new_n105_), .A2(new_n107_), .B(new_n108_), .Y(new_n109_));
  XNOR2x2_ASAP7_75t_R  g088(.A(p8), .B(p0), .Y(new_n110_));
  AND3x1_ASAP7_75t_R   g089(.A(new_n109_), .B(new_n33_), .C(new_n110_), .Y(new_n111_));
  AOI221x1_ASAP7_75t_R g090(.A1(new_n90_), .A2(new_n96_), .B1(new_n104_), .B2(new_n29_), .C(new_n111_), .Y(new_n112_));
  NOR2x1_ASAP7_75t_R   g091(.A(p5), .B(p3), .Y(new_n113_));
  INVx1_ASAP7_75t_R    g092(.A(new_n113_), .Y(new_n114_));
  OAI22x1_ASAP7_75t_R  g093(.A1(new_n83_), .A2(p6), .B1(new_n112_), .B2(new_n114_), .Y(o0));
  NAND2x1_ASAP7_75t_R  g094(.A(new_n88_), .B(new_n85_), .Y(new_n116_));
  OR3x1_ASAP7_75t_R    g095(.A(new_n67_), .B(new_n52_), .C(p1), .Y(new_n117_));
  NAND2x1_ASAP7_75t_R  g096(.A(p5), .B(p8), .Y(new_n118_));
  OA21x2_ASAP7_75t_R   g097(.A1(new_n29_), .A2(p4), .B(new_n118_), .Y(new_n119_));
  NAND2x1_ASAP7_75t_R  g098(.A(p4), .B(new_n33_), .Y(new_n120_));
  OAI22x1_ASAP7_75t_R  g099(.A1(new_n117_), .A2(new_n119_), .B1(new_n53_), .B2(new_n120_), .Y(new_n121_));
  NOR2x1_ASAP7_75t_R   g100(.A(p8), .B(new_n42_), .Y(new_n122_));
  AO21x1_ASAP7_75t_R   g101(.A1(p5), .A2(new_n52_), .B(p1), .Y(new_n123_));
  NOR2x1_ASAP7_75t_R   g102(.A(p5), .B(p7), .Y(new_n124_));
  AO21x1_ASAP7_75t_R   g103(.A1(new_n84_), .A2(new_n123_), .B(new_n124_), .Y(new_n125_));
  AOI22x1_ASAP7_75t_R  g104(.A1(new_n121_), .A2(p0), .B1(new_n122_), .B2(new_n125_), .Y(new_n126_));
  OA21x2_ASAP7_75t_R   g105(.A1(p7), .A2(p4), .B(new_n118_), .Y(new_n127_));
  NOR2x1_ASAP7_75t_R   g106(.A(p7), .B(new_n24_), .Y(new_n128_));
  OAI22x1_ASAP7_75t_R  g107(.A1(p9), .A2(new_n119_), .B1(new_n127_), .B2(new_n128_), .Y(new_n129_));
  NOR2x1_ASAP7_75t_R   g108(.A(p0), .B(new_n25_), .Y(new_n130_));
  NAND2x1_ASAP7_75t_R  g109(.A(p7), .B(p1), .Y(new_n131_));
  INVx1_ASAP7_75t_R    g110(.A(new_n131_), .Y(new_n132_));
  AOI22x1_ASAP7_75t_R  g111(.A1(new_n129_), .A2(new_n130_), .B1(new_n132_), .B2(new_n72_), .Y(new_n133_));
  AND2x2_ASAP7_75t_R   g112(.A(p8), .B(p7), .Y(new_n134_));
  NAND2x1_ASAP7_75t_R  g113(.A(p9), .B(new_n134_), .Y(new_n135_));
  NAND2x1_ASAP7_75t_R  g114(.A(p4), .B(p1), .Y(new_n136_));
  OAI22x1_ASAP7_75t_R  g115(.A1(new_n135_), .A2(new_n136_), .B1(new_n60_), .B2(new_n35_), .Y(new_n137_));
  NAND2x1_ASAP7_75t_R  g116(.A(new_n42_), .B(new_n137_), .Y(new_n138_));
  NAND3x1_ASAP7_75t_R  g117(.A(new_n126_), .B(new_n133_), .C(new_n138_), .Y(new_n139_));
  AND3x1_ASAP7_75t_R   g118(.A(p5), .B(p8), .C(p3), .Y(new_n140_));
  NOR2x1_ASAP7_75t_R   g119(.A(p7), .B(new_n60_), .Y(new_n141_));
  OA21x2_ASAP7_75t_R   g120(.A1(new_n73_), .A2(new_n141_), .B(new_n72_), .Y(new_n142_));
  OA21x2_ASAP7_75t_R   g121(.A1(new_n140_), .A2(new_n142_), .B(new_n64_), .Y(new_n143_));
  AOI21x1_ASAP7_75t_R  g122(.A1(new_n22_), .A2(new_n139_), .B(new_n143_), .Y(new_n144_));
  AND2x2_ASAP7_75t_R   g123(.A(p0), .B(p4), .Y(new_n145_));
  INVx1_ASAP7_75t_R    g124(.A(new_n145_), .Y(new_n146_));
  NOR2x1_ASAP7_75t_R   g125(.A(p0), .B(p7), .Y(new_n147_));
  NOR2x1_ASAP7_75t_R   g126(.A(p1), .B(new_n88_), .Y(new_n148_));
  NAND2x1_ASAP7_75t_R  g127(.A(new_n147_), .B(new_n148_), .Y(new_n149_));
  NAND2x1_ASAP7_75t_R  g128(.A(p5), .B(p9), .Y(new_n150_));
  AO21x1_ASAP7_75t_R   g129(.A1(new_n146_), .A2(new_n149_), .B(new_n150_), .Y(new_n151_));
  NAND2x1_ASAP7_75t_R  g130(.A(p0), .B(p1), .Y(new_n152_));
  OR3x1_ASAP7_75t_R    g131(.A(new_n80_), .B(new_n105_), .C(new_n28_), .Y(new_n153_));
  AO21x1_ASAP7_75t_R   g132(.A1(new_n60_), .A2(new_n152_), .B(new_n153_), .Y(new_n154_));
  OR4x2_ASAP7_75t_R    g133(.A(new_n152_), .B(new_n88_), .C(p7), .D(new_n60_), .Y(new_n155_));
  AND3x1_ASAP7_75t_R   g134(.A(new_n154_), .B(p8), .C(new_n155_), .Y(new_n156_));
  NOR2x1_ASAP7_75t_R   g135(.A(p3), .B(p6), .Y(new_n157_));
  INVx1_ASAP7_75t_R    g136(.A(new_n157_), .Y(new_n158_));
  AOI21x1_ASAP7_75t_R  g137(.A1(new_n151_), .A2(new_n156_), .B(new_n158_), .Y(new_n159_));
  NAND2x1_ASAP7_75t_R  g138(.A(p9), .B(new_n60_), .Y(new_n160_));
  AO21x1_ASAP7_75t_R   g139(.A1(new_n101_), .A2(new_n160_), .B(new_n42_), .Y(new_n161_));
  AND3x1_ASAP7_75t_R   g140(.A(new_n25_), .B(p7), .C(p9), .Y(new_n162_));
  AO21x1_ASAP7_75t_R   g141(.A1(p2), .A2(p7), .B(p1), .Y(new_n163_));
  AOI22x1_ASAP7_75t_R  g142(.A1(new_n162_), .A2(p0), .B1(new_n52_), .B2(new_n163_), .Y(new_n164_));
  AOI21x1_ASAP7_75t_R  g143(.A1(new_n161_), .A2(new_n164_), .B(p5), .Y(new_n165_));
  NOR2x1_ASAP7_75t_R   g144(.A(p2), .B(p7), .Y(new_n166_));
  OR3x1_ASAP7_75t_R    g145(.A(new_n84_), .B(new_n52_), .C(new_n166_), .Y(new_n167_));
  NOR2x1_ASAP7_75t_R   g146(.A(p5), .B(p0), .Y(new_n168_));
  INVx1_ASAP7_75t_R    g147(.A(new_n168_), .Y(new_n169_));
  AOI21x1_ASAP7_75t_R  g148(.A1(new_n120_), .A2(new_n167_), .B(new_n169_), .Y(new_n170_));
  NOR2x1_ASAP7_75t_R   g149(.A(p1), .B(new_n147_), .Y(new_n171_));
  AND3x1_ASAP7_75t_R   g150(.A(new_n42_), .B(p5), .C(p7), .Y(new_n172_));
  NOR2x1_ASAP7_75t_R   g151(.A(p4), .B(new_n88_), .Y(new_n173_));
  OA21x2_ASAP7_75t_R   g152(.A1(new_n171_), .A2(new_n172_), .B(new_n173_), .Y(new_n174_));
  NAND2x1_ASAP7_75t_R  g153(.A(p7), .B(new_n52_), .Y(new_n175_));
  AND5x1_ASAP7_75t_R   g154(.A(new_n60_), .B(new_n107_), .C(new_n25_), .D(new_n175_), .E(new_n169_), .Y(new_n176_));
  OR5x1_ASAP7_75t_R    g155(.A(new_n165_), .B(p8), .C(new_n170_), .D(new_n174_), .E(new_n176_), .Y(new_n177_));
  AND3x1_ASAP7_75t_R   g156(.A(new_n105_), .B(new_n28_), .C(new_n22_), .Y(new_n178_));
  INVx1_ASAP7_75t_R    g157(.A(new_n94_), .Y(new_n179_));
  AND3x1_ASAP7_75t_R   g158(.A(new_n24_), .B(p0), .C(p7), .Y(new_n180_));
  NOR2x1_ASAP7_75t_R   g159(.A(p1), .B(new_n85_), .Y(new_n181_));
  INVx1_ASAP7_75t_R    g160(.A(new_n33_), .Y(new_n182_));
  NAND2x1_ASAP7_75t_R  g161(.A(new_n29_), .B(new_n52_), .Y(new_n183_));
  NOR2x1_ASAP7_75t_R   g162(.A(p1), .B(new_n106_), .Y(new_n184_));
  NAND2x1_ASAP7_75t_R  g163(.A(p6), .B(new_n152_), .Y(new_n185_));
  AOI221x1_ASAP7_75t_R g164(.A1(new_n182_), .A2(new_n183_), .B1(new_n184_), .B2(new_n62_), .C(new_n185_), .Y(new_n186_));
  AO221x2_ASAP7_75t_R  g165(.A1(new_n179_), .A2(new_n38_), .B1(new_n180_), .B2(new_n181_), .C(new_n186_), .Y(new_n187_));
  AOI22x1_ASAP7_75t_R  g166(.A1(new_n159_), .A2(new_n177_), .B1(new_n178_), .B2(new_n187_), .Y(new_n188_));
  OAI21x1_ASAP7_75t_R  g167(.A1(new_n116_), .A2(new_n144_), .B(new_n188_), .Y(o1));
  AND3x1_ASAP7_75t_R   g168(.A(new_n24_), .B(new_n29_), .C(new_n25_), .Y(new_n190_));
  AO21x1_ASAP7_75t_R   g169(.A1(new_n60_), .A2(p9), .B(new_n99_), .Y(new_n191_));
  AND2x2_ASAP7_75t_R   g170(.A(p7), .B(p9), .Y(new_n192_));
  AND3x1_ASAP7_75t_R   g171(.A(new_n98_), .B(new_n97_), .C(new_n192_), .Y(new_n193_));
  AOI21x1_ASAP7_75t_R  g172(.A1(new_n190_), .A2(new_n191_), .B(new_n193_), .Y(new_n194_));
  INVx1_ASAP7_75t_R    g173(.A(new_n23_), .Y(new_n195_));
  NOR2x1_ASAP7_75t_R   g174(.A(p8), .B(p7), .Y(new_n196_));
  NOR2x1_ASAP7_75t_R   g175(.A(new_n60_), .B(new_n196_), .Y(new_n197_));
  INVx1_ASAP7_75t_R    g176(.A(new_n51_), .Y(new_n198_));
  AO221x2_ASAP7_75t_R  g177(.A1(new_n60_), .A2(new_n195_), .B1(new_n135_), .B2(new_n197_), .C(new_n198_), .Y(new_n199_));
  NOR2x1_ASAP7_75t_R   g178(.A(new_n196_), .B(new_n134_), .Y(new_n200_));
  INVx1_ASAP7_75t_R    g179(.A(new_n200_), .Y(new_n201_));
  NOR2x1_ASAP7_75t_R   g180(.A(p2), .B(new_n25_), .Y(new_n202_));
  INVx1_ASAP7_75t_R    g181(.A(new_n202_), .Y(new_n203_));
  AO21x1_ASAP7_75t_R   g182(.A1(new_n93_), .A2(new_n201_), .B(new_n203_), .Y(new_n204_));
  AO31x2_ASAP7_75t_R   g183(.A1(new_n194_), .A2(new_n199_), .A3(new_n204_), .B(new_n114_), .Y(new_n205_));
  AOI211x1_ASAP7_75t_R g184(.A1(new_n166_), .A2(new_n87_), .B(new_n67_), .C(new_n180_), .Y(new_n206_));
  OR3x1_ASAP7_75t_R    g185(.A(new_n206_), .B(p1), .C(new_n97_), .Y(new_n207_));
  AND3x1_ASAP7_75t_R   g186(.A(new_n24_), .B(new_n29_), .C(p1), .Y(new_n208_));
  NOR2x1_ASAP7_75t_R   g187(.A(p8), .B(new_n25_), .Y(new_n209_));
  NOR2x1_ASAP7_75t_R   g188(.A(new_n29_), .B(new_n209_), .Y(new_n210_));
  OAI21x1_ASAP7_75t_R  g189(.A1(new_n208_), .A2(new_n210_), .B(p2), .Y(new_n211_));
  AND2x2_ASAP7_75t_R   g190(.A(p8), .B(p0), .Y(new_n212_));
  AND2x2_ASAP7_75t_R   g191(.A(p5), .B(p1), .Y(new_n213_));
  AO21x1_ASAP7_75t_R   g192(.A1(new_n212_), .A2(new_n213_), .B(new_n172_), .Y(new_n214_));
  NAND2x1_ASAP7_75t_R  g193(.A(p2), .B(new_n214_), .Y(new_n215_));
  OR3x1_ASAP7_75t_R    g194(.A(new_n52_), .B(p3), .C(p4), .Y(new_n216_));
  AO31x2_ASAP7_75t_R   g195(.A1(new_n207_), .A2(new_n211_), .A3(new_n215_), .B(new_n216_), .Y(new_n217_));
  AO21x1_ASAP7_75t_R   g196(.A1(new_n205_), .A2(new_n217_), .B(p6), .Y(new_n218_));
  AOI21x1_ASAP7_75t_R  g197(.A1(new_n60_), .A2(new_n148_), .B(new_n41_), .Y(new_n219_));
  NAND2x1_ASAP7_75t_R  g198(.A(p2), .B(p4), .Y(new_n220_));
  NOR2x1_ASAP7_75t_R   g199(.A(p1), .B(new_n29_), .Y(new_n221_));
  OA21x2_ASAP7_75t_R   g200(.A1(new_n220_), .A2(new_n221_), .B(new_n122_), .Y(new_n222_));
  AO21x1_ASAP7_75t_R   g201(.A1(p1), .A2(new_n29_), .B(new_n42_), .Y(new_n223_));
  OA211x2_ASAP7_75t_R  g202(.A1(new_n213_), .A2(new_n223_), .B(p4), .C(new_n163_), .Y(new_n224_));
  NAND2x1_ASAP7_75t_R  g203(.A(p2), .B(new_n29_), .Y(new_n225_));
  NAND2x1_ASAP7_75t_R  g204(.A(new_n87_), .B(new_n225_), .Y(new_n226_));
  NAND2x1_ASAP7_75t_R  g205(.A(p2), .B(new_n24_), .Y(new_n227_));
  AND3x1_ASAP7_75t_R   g206(.A(new_n196_), .B(p5), .C(new_n60_), .Y(new_n228_));
  AO32x1_ASAP7_75t_R   g207(.A1(new_n226_), .A2(new_n28_), .A3(new_n227_), .B1(new_n31_), .B2(new_n228_), .Y(new_n229_));
  AOI211x1_ASAP7_75t_R g208(.A1(new_n219_), .A2(new_n222_), .B(new_n224_), .C(new_n229_), .Y(new_n230_));
  NAND2x1_ASAP7_75t_R  g209(.A(p8), .B(new_n42_), .Y(new_n231_));
  OA22x2_ASAP7_75t_R   g210(.A1(new_n231_), .A2(new_n225_), .B1(new_n88_), .B2(p1), .Y(new_n232_));
  AO21x1_ASAP7_75t_R   g211(.A1(p7), .A2(new_n122_), .B(new_n72_), .Y(new_n233_));
  NAND2x1_ASAP7_75t_R  g212(.A(p5), .B(new_n29_), .Y(new_n234_));
  OR3x1_ASAP7_75t_R    g213(.A(new_n24_), .B(new_n42_), .C(p2), .Y(new_n235_));
  OA21x2_ASAP7_75t_R   g214(.A1(new_n234_), .A2(new_n235_), .B(new_n22_), .Y(new_n236_));
  OA21x2_ASAP7_75t_R   g215(.A1(new_n232_), .A2(new_n233_), .B(new_n236_), .Y(new_n237_));
  NAND2x1_ASAP7_75t_R  g216(.A(p8), .B(p7), .Y(new_n238_));
  AOI211x1_ASAP7_75t_R g217(.A1(new_n238_), .A2(new_n234_), .B(new_n22_), .C(p4), .Y(new_n239_));
  OA21x2_ASAP7_75t_R   g218(.A1(p1), .A2(new_n32_), .B(p3), .Y(new_n240_));
  OR3x1_ASAP7_75t_R    g219(.A(new_n239_), .B(new_n240_), .C(p9), .Y(new_n241_));
  AO211x2_ASAP7_75t_R  g220(.A1(new_n230_), .A2(new_n237_), .B(p6), .C(new_n241_), .Y(new_n242_));
  AO21x1_ASAP7_75t_R   g221(.A1(p6), .A2(new_n134_), .B(new_n52_), .Y(new_n243_));
  AO32x1_ASAP7_75t_R   g222(.A1(new_n243_), .A2(p0), .A3(new_n53_), .B1(new_n57_), .B2(new_n147_), .Y(new_n244_));
  NAND3x1_ASAP7_75t_R  g223(.A(new_n244_), .B(new_n25_), .C(new_n178_), .Y(new_n245_));
  NAND3x1_ASAP7_75t_R  g224(.A(new_n218_), .B(new_n242_), .C(new_n245_), .Y(o2));
  NOR2x1_ASAP7_75t_R   g225(.A(p1), .B(new_n60_), .Y(new_n247_));
  AO32x1_ASAP7_75t_R   g226(.A1(new_n209_), .A2(new_n49_), .A3(new_n225_), .B1(new_n200_), .B2(new_n247_), .Y(new_n248_));
  INVx1_ASAP7_75t_R    g227(.A(new_n173_), .Y(new_n249_));
  AO221x2_ASAP7_75t_R  g228(.A1(p2), .A2(new_n141_), .B1(new_n249_), .B2(p5), .C(new_n148_), .Y(new_n250_));
  OAI21x1_ASAP7_75t_R  g229(.A1(new_n248_), .A2(new_n250_), .B(new_n106_), .Y(new_n251_));
  AO21x1_ASAP7_75t_R   g230(.A1(p8), .A2(p4), .B(p5), .Y(new_n252_));
  INVx1_ASAP7_75t_R    g231(.A(new_n252_), .Y(new_n253_));
  OA211x2_ASAP7_75t_R  g232(.A1(new_n212_), .A2(new_n48_), .B(new_n253_), .C(p2), .Y(new_n254_));
  AO21x1_ASAP7_75t_R   g233(.A1(new_n28_), .A2(new_n29_), .B(new_n65_), .Y(new_n255_));
  AO32x1_ASAP7_75t_R   g234(.A1(p5), .A2(new_n60_), .A3(new_n180_), .B1(new_n255_), .B2(new_n148_), .Y(new_n256_));
  AOI211x1_ASAP7_75t_R g235(.A1(new_n42_), .A2(new_n228_), .B(new_n254_), .C(new_n256_), .Y(new_n257_));
  OR3x1_ASAP7_75t_R    g236(.A(new_n37_), .B(p0), .C(p7), .Y(new_n258_));
  OR3x1_ASAP7_75t_R    g237(.A(new_n88_), .B(new_n25_), .C(p5), .Y(new_n259_));
  OR3x1_ASAP7_75t_R    g238(.A(new_n80_), .B(new_n28_), .C(p4), .Y(new_n260_));
  AO21x1_ASAP7_75t_R   g239(.A1(new_n259_), .A2(new_n260_), .B(new_n231_), .Y(new_n261_));
  AO32x1_ASAP7_75t_R   g240(.A1(new_n33_), .A2(new_n168_), .A3(p4), .B1(p5), .B2(new_n105_), .Y(new_n262_));
  NAND2x1_ASAP7_75t_R  g241(.A(new_n57_), .B(new_n262_), .Y(new_n263_));
  AND5x1_ASAP7_75t_R   g242(.A(new_n251_), .B(new_n257_), .C(new_n258_), .D(new_n261_), .E(new_n263_), .Y(new_n264_));
  AND3x1_ASAP7_75t_R   g243(.A(new_n23_), .B(new_n48_), .C(new_n28_), .Y(new_n265_));
  AO21x1_ASAP7_75t_R   g244(.A1(p5), .A2(new_n29_), .B(p2), .Y(new_n266_));
  AO32x1_ASAP7_75t_R   g245(.A1(new_n24_), .A2(p1), .A3(new_n41_), .B1(new_n75_), .B2(new_n266_), .Y(new_n267_));
  OA21x2_ASAP7_75t_R   g246(.A1(new_n265_), .A2(new_n267_), .B(p0), .Y(new_n268_));
  NOR2x1_ASAP7_75t_R   g247(.A(p0), .B(new_n88_), .Y(new_n269_));
  NAND2x1_ASAP7_75t_R  g248(.A(p8), .B(new_n28_), .Y(new_n270_));
  AO221x2_ASAP7_75t_R  g249(.A1(new_n269_), .A2(new_n270_), .B1(new_n146_), .B2(new_n213_), .C(p3), .Y(new_n271_));
  NOR2x1_ASAP7_75t_R   g250(.A(p5), .B(p4), .Y(new_n272_));
  AO21x1_ASAP7_75t_R   g251(.A1(new_n272_), .A2(new_n134_), .B(new_n77_), .Y(new_n273_));
  AND3x1_ASAP7_75t_R   g252(.A(new_n273_), .B(new_n25_), .C(new_n31_), .Y(new_n274_));
  OA211x2_ASAP7_75t_R  g253(.A1(new_n22_), .A2(new_n274_), .B(new_n85_), .C(new_n52_), .Y(new_n275_));
  OAI21x1_ASAP7_75t_R  g254(.A1(new_n268_), .A2(new_n271_), .B(new_n275_), .Y(new_n276_));
  OAI21x1_ASAP7_75t_R  g255(.A1(new_n158_), .A2(new_n264_), .B(new_n276_), .Y(o3));
  OA211x2_ASAP7_75t_R  g256(.A1(p0), .A2(p9), .B(new_n22_), .C(p1), .Y(new_n278_));
  NAND2x1_ASAP7_75t_R  g257(.A(p3), .B(new_n88_), .Y(new_n279_));
  INVx1_ASAP7_75t_R    g258(.A(new_n64_), .Y(new_n280_));
  AOI21x1_ASAP7_75t_R  g259(.A1(new_n70_), .A2(new_n279_), .B(new_n280_), .Y(new_n281_));
  AND3x1_ASAP7_75t_R   g260(.A(new_n85_), .B(p5), .C(p4), .Y(new_n282_));
  OA21x2_ASAP7_75t_R   g261(.A1(new_n278_), .A2(new_n281_), .B(new_n282_), .Y(o4));
  AND3x1_ASAP7_75t_R   g262(.A(new_n80_), .B(new_n81_), .C(p3), .Y(new_n284_));
  NOR2x1_ASAP7_75t_R   g263(.A(new_n70_), .B(new_n64_), .Y(new_n285_));
  OA21x2_ASAP7_75t_R   g264(.A1(new_n284_), .A2(new_n285_), .B(new_n282_), .Y(o5));
  NOR2x1_ASAP7_75t_R   g265(.A(p0), .B(new_n196_), .Y(new_n287_));
  OR3x1_ASAP7_75t_R    g266(.A(new_n287_), .B(new_n52_), .C(new_n122_), .Y(new_n288_));
  NOR2x1_ASAP7_75t_R   g267(.A(p5), .B(p9), .Y(new_n289_));
  INVx1_ASAP7_75t_R    g268(.A(new_n289_), .Y(new_n290_));
  AO221x2_ASAP7_75t_R  g269(.A1(new_n42_), .A2(new_n29_), .B1(new_n152_), .B2(new_n290_), .C(new_n110_), .Y(new_n291_));
  AOI21x1_ASAP7_75t_R  g270(.A1(new_n288_), .A2(new_n291_), .B(p4), .Y(new_n292_));
  AO32x1_ASAP7_75t_R   g271(.A1(new_n221_), .A2(p5), .A3(p9), .B1(new_n43_), .B2(new_n94_), .Y(new_n293_));
  AO32x1_ASAP7_75t_R   g272(.A1(new_n122_), .A2(new_n183_), .A3(new_n160_), .B1(new_n293_), .B2(p8), .Y(new_n294_));
  OAI21x1_ASAP7_75t_R  g273(.A1(new_n292_), .A2(new_n294_), .B(p2), .Y(new_n295_));
  AO21x1_ASAP7_75t_R   g274(.A1(new_n62_), .A2(new_n247_), .B(new_n58_), .Y(new_n296_));
  AO21x1_ASAP7_75t_R   g275(.A1(p1), .A2(new_n60_), .B(p5), .Y(new_n297_));
  OA21x2_ASAP7_75t_R   g276(.A1(new_n53_), .A2(new_n297_), .B(new_n43_), .Y(new_n298_));
  NAND2x1_ASAP7_75t_R  g277(.A(new_n296_), .B(new_n298_), .Y(new_n299_));
  INVx1_ASAP7_75t_R    g278(.A(new_n175_), .Y(new_n300_));
  NAND2x1_ASAP7_75t_R  g279(.A(new_n24_), .B(new_n25_), .Y(new_n301_));
  OR5x1_ASAP7_75t_R    g280(.A(p0), .B(new_n300_), .C(new_n301_), .D(new_n48_), .E(new_n289_), .Y(new_n302_));
  OR3x1_ASAP7_75t_R    g281(.A(new_n231_), .B(p9), .C(new_n131_), .Y(new_n303_));
  OA21x2_ASAP7_75t_R   g282(.A1(p8), .A2(p7), .B(p1), .Y(new_n304_));
  AO21x1_ASAP7_75t_R   g283(.A1(p8), .A2(new_n192_), .B(new_n304_), .Y(new_n305_));
  NAND3x1_ASAP7_75t_R  g284(.A(new_n305_), .B(p5), .C(p0), .Y(new_n306_));
  AND4x2_ASAP7_75t_R   g285(.A(new_n299_), .B(new_n302_), .C(new_n303_), .D(new_n306_), .Y(new_n307_));
  NAND2x1_ASAP7_75t_R  g286(.A(new_n131_), .B(new_n182_), .Y(new_n308_));
  AO32x1_ASAP7_75t_R   g287(.A1(p8), .A2(new_n52_), .A3(p1), .B1(new_n196_), .B2(new_n42_), .Y(new_n309_));
  AO32x1_ASAP7_75t_R   g288(.A1(new_n201_), .A2(new_n308_), .A3(p5), .B1(new_n309_), .B2(p4), .Y(new_n310_));
  AO32x1_ASAP7_75t_R   g289(.A1(new_n152_), .A2(new_n136_), .A3(new_n72_), .B1(new_n145_), .B2(p8), .Y(new_n311_));
  AO32x1_ASAP7_75t_R   g290(.A1(p1), .A2(new_n66_), .A3(new_n300_), .B1(new_n311_), .B2(new_n192_), .Y(new_n312_));
  OAI21x1_ASAP7_75t_R  g291(.A1(new_n310_), .A2(new_n312_), .B(new_n88_), .Y(new_n313_));
  NAND3x1_ASAP7_75t_R  g292(.A(new_n295_), .B(new_n307_), .C(new_n313_), .Y(new_n314_));
  AO21x1_ASAP7_75t_R   g293(.A1(p0), .A2(p9), .B(new_n196_), .Y(new_n315_));
  AO21x1_ASAP7_75t_R   g294(.A1(p6), .A2(new_n24_), .B(new_n29_), .Y(new_n316_));
  AO21x1_ASAP7_75t_R   g295(.A1(new_n130_), .A2(new_n316_), .B(new_n26_), .Y(new_n317_));
  AO32x1_ASAP7_75t_R   g296(.A1(new_n181_), .A2(new_n201_), .A3(new_n315_), .B1(new_n317_), .B2(new_n52_), .Y(new_n318_));
  OA21x2_ASAP7_75t_R   g297(.A1(new_n77_), .A2(new_n284_), .B(new_n85_), .Y(new_n319_));
  AO21x1_ASAP7_75t_R   g298(.A1(new_n178_), .A2(new_n318_), .B(new_n319_), .Y(new_n320_));
  AOI21x1_ASAP7_75t_R  g299(.A1(new_n157_), .A2(new_n314_), .B(new_n320_), .Y(o6));
  AO32x1_ASAP7_75t_R   g300(.A1(new_n24_), .A2(p6), .A3(new_n162_), .B1(new_n179_), .B2(new_n200_), .Y(new_n322_));
  AND3x1_ASAP7_75t_R   g301(.A(new_n322_), .B(new_n31_), .C(new_n272_), .Y(new_n323_));
  OA21x2_ASAP7_75t_R   g302(.A1(new_n85_), .A2(new_n323_), .B(new_n22_), .Y(new_n324_));
  AOI21x1_ASAP7_75t_R  g303(.A1(new_n37_), .A2(new_n234_), .B(new_n24_), .Y(new_n325_));
  NAND2x1_ASAP7_75t_R  g304(.A(new_n175_), .B(new_n234_), .Y(new_n326_));
  AOI221x1_ASAP7_75t_R g305(.A1(p8), .A2(new_n52_), .B1(new_n118_), .B2(new_n29_), .C(new_n289_), .Y(new_n327_));
  AOI22x1_ASAP7_75t_R  g306(.A1(new_n325_), .A2(new_n326_), .B1(new_n37_), .B2(new_n327_), .Y(new_n328_));
  AO21x1_ASAP7_75t_R   g307(.A1(p2), .A2(new_n238_), .B(new_n192_), .Y(new_n329_));
  NOR2x1_ASAP7_75t_R   g308(.A(p5), .B(new_n25_), .Y(new_n330_));
  AND3x1_ASAP7_75t_R   g309(.A(new_n72_), .B(new_n88_), .C(new_n29_), .Y(new_n331_));
  AOI221x1_ASAP7_75t_R g310(.A1(new_n202_), .A2(new_n134_), .B1(new_n329_), .B2(new_n330_), .C(new_n331_), .Y(new_n332_));
  OAI21x1_ASAP7_75t_R  g311(.A1(p1), .A2(new_n328_), .B(new_n332_), .Y(new_n333_));
  INVx1_ASAP7_75t_R    g312(.A(new_n196_), .Y(new_n334_));
  NAND2x1_ASAP7_75t_R  g313(.A(p5), .B(new_n52_), .Y(new_n335_));
  AOI21x1_ASAP7_75t_R  g314(.A1(new_n238_), .A2(new_n334_), .B(new_n335_), .Y(new_n336_));
  OA221x2_ASAP7_75t_R  g315(.A1(p8), .A2(new_n52_), .B1(new_n72_), .B2(new_n124_), .C(new_n25_), .Y(new_n337_));
  OAI21x1_ASAP7_75t_R  g316(.A1(new_n336_), .A2(new_n337_), .B(new_n269_), .Y(new_n338_));
  OAI21x1_ASAP7_75t_R  g317(.A1(p5), .A2(new_n166_), .B(new_n304_), .Y(new_n339_));
  OR3x1_ASAP7_75t_R    g318(.A(new_n150_), .B(p8), .C(new_n29_), .Y(new_n340_));
  AO31x2_ASAP7_75t_R   g319(.A1(new_n339_), .A2(new_n340_), .A3(new_n35_), .B(p0), .Y(new_n341_));
  OR3x1_ASAP7_75t_R    g320(.A(new_n301_), .B(new_n234_), .C(new_n88_), .Y(new_n342_));
  NAND3x1_ASAP7_75t_R  g321(.A(new_n338_), .B(new_n341_), .C(new_n342_), .Y(new_n343_));
  AOI21x1_ASAP7_75t_R  g322(.A1(p0), .A2(new_n333_), .B(new_n343_), .Y(new_n344_));
  AOI22x1_ASAP7_75t_R  g323(.A1(p2), .A2(p1), .B1(p8), .B2(p7), .Y(new_n345_));
  NAND3x1_ASAP7_75t_R  g324(.A(p2), .B(p4), .C(p9), .Y(new_n346_));
  AOI22x1_ASAP7_75t_R  g325(.A1(new_n334_), .A2(new_n345_), .B1(new_n136_), .B2(new_n346_), .Y(new_n347_));
  AND5x1_ASAP7_75t_R   g326(.A(p2), .B(p8), .C(p7), .D(p4), .E(p1), .Y(new_n348_));
  AO21x1_ASAP7_75t_R   g327(.A1(new_n99_), .A2(new_n208_), .B(new_n348_), .Y(new_n349_));
  OA31x2_ASAP7_75t_R   g328(.A1(p0), .A2(new_n347_), .A3(new_n349_), .B1(new_n28_), .Y(new_n350_));
  OAI21x1_ASAP7_75t_R  g329(.A1(p8), .A2(p1), .B(p9), .Y(new_n351_));
  OAI21x1_ASAP7_75t_R  g330(.A1(new_n29_), .A2(new_n34_), .B(p4), .Y(new_n352_));
  OAI21x1_ASAP7_75t_R  g331(.A1(new_n23_), .A2(new_n351_), .B(new_n352_), .Y(new_n353_));
  AND3x1_ASAP7_75t_R   g332(.A(new_n182_), .B(new_n334_), .C(new_n88_), .Y(new_n354_));
  AOI22x1_ASAP7_75t_R  g333(.A1(new_n24_), .A2(p1), .B1(p2), .B2(p4), .Y(new_n355_));
  NAND2x1_ASAP7_75t_R  g334(.A(p2), .B(new_n238_), .Y(new_n356_));
  NAND2x1_ASAP7_75t_R  g335(.A(p4), .B(new_n25_), .Y(new_n357_));
  OAI22x1_ASAP7_75t_R  g336(.A1(new_n355_), .A2(new_n183_), .B1(new_n356_), .B2(new_n357_), .Y(new_n358_));
  AOI21x1_ASAP7_75t_R  g337(.A1(new_n353_), .A2(new_n354_), .B(new_n358_), .Y(new_n359_));
  AOI221x1_ASAP7_75t_R g338(.A1(new_n99_), .A2(new_n208_), .B1(new_n347_), .B2(new_n42_), .C(new_n348_), .Y(new_n360_));
  NAND2x1_ASAP7_75t_R  g339(.A(new_n359_), .B(new_n360_), .Y(new_n361_));
  AOI21x1_ASAP7_75t_R  g340(.A1(new_n350_), .A2(new_n361_), .B(new_n323_), .Y(new_n362_));
  OAI21x1_ASAP7_75t_R  g341(.A1(p4), .A2(new_n344_), .B(new_n362_), .Y(new_n363_));
  AND3x1_ASAP7_75t_R   g342(.A(new_n284_), .B(new_n85_), .C(new_n272_), .Y(new_n364_));
  AOI21x1_ASAP7_75t_R  g343(.A1(new_n324_), .A2(new_n363_), .B(new_n364_), .Y(o7));
  AO21x1_ASAP7_75t_R   g344(.A1(p7), .A2(new_n52_), .B(p4), .Y(new_n366_));
  AND3x1_ASAP7_75t_R   g345(.A(new_n220_), .B(p0), .C(p1), .Y(new_n367_));
  OA21x2_ASAP7_75t_R   g346(.A1(p2), .A2(p9), .B(new_n221_), .Y(new_n368_));
  NOR2x1_ASAP7_75t_R   g347(.A(new_n145_), .B(new_n173_), .Y(new_n369_));
  AND3x1_ASAP7_75t_R   g348(.A(new_n192_), .B(new_n60_), .C(new_n31_), .Y(new_n370_));
  AO221x2_ASAP7_75t_R  g349(.A1(new_n366_), .A2(new_n367_), .B1(new_n368_), .B2(new_n369_), .C(new_n370_), .Y(new_n371_));
  INVx1_ASAP7_75t_R    g350(.A(new_n270_), .Y(new_n372_));
  AND3x1_ASAP7_75t_R   g351(.A(new_n225_), .B(p0), .C(new_n39_), .Y(new_n373_));
  OAI21x1_ASAP7_75t_R  g352(.A1(p4), .A2(new_n25_), .B(new_n220_), .Y(new_n374_));
  AO32x1_ASAP7_75t_R   g353(.A1(new_n101_), .A2(new_n269_), .A3(new_n221_), .B1(new_n373_), .B2(new_n374_), .Y(new_n375_));
  AOI22x1_ASAP7_75t_R  g354(.A1(new_n371_), .A2(new_n72_), .B1(new_n372_), .B2(new_n375_), .Y(new_n376_));
  AO21x1_ASAP7_75t_R   g355(.A1(new_n24_), .A2(new_n25_), .B(new_n148_), .Y(new_n377_));
  AND3x1_ASAP7_75t_R   g356(.A(new_n377_), .B(new_n93_), .C(new_n369_), .Y(new_n378_));
  AOI22x1_ASAP7_75t_R  g357(.A1(new_n110_), .A2(new_n202_), .B1(new_n105_), .B2(new_n130_), .Y(new_n379_));
  NAND2x1_ASAP7_75t_R  g358(.A(new_n38_), .B(new_n247_), .Y(new_n380_));
  AO21x1_ASAP7_75t_R   g359(.A1(new_n235_), .A2(new_n380_), .B(p9), .Y(new_n381_));
  NAND2x1_ASAP7_75t_R  g360(.A(new_n379_), .B(new_n381_), .Y(new_n382_));
  OAI21x1_ASAP7_75t_R  g361(.A1(new_n378_), .A2(new_n382_), .B(new_n124_), .Y(new_n383_));
  AO21x1_ASAP7_75t_R   g362(.A1(new_n42_), .A2(new_n334_), .B(new_n52_), .Y(new_n384_));
  NOR2x1_ASAP7_75t_R   g363(.A(p5), .B(new_n43_), .Y(new_n385_));
  AO21x1_ASAP7_75t_R   g364(.A1(p8), .A2(new_n42_), .B(new_n28_), .Y(new_n386_));
  AO21x1_ASAP7_75t_R   g365(.A1(new_n87_), .A2(new_n300_), .B(new_n386_), .Y(new_n387_));
  AO221x2_ASAP7_75t_R  g366(.A1(new_n384_), .A2(new_n385_), .B1(new_n387_), .B2(new_n25_), .C(new_n249_), .Y(new_n388_));
  NAND3x1_ASAP7_75t_R  g367(.A(new_n376_), .B(new_n383_), .C(new_n388_), .Y(new_n389_));
  AND3x1_ASAP7_75t_R   g368(.A(new_n23_), .B(new_n29_), .C(new_n52_), .Y(new_n390_));
  AO221x2_ASAP7_75t_R  g369(.A1(new_n57_), .A2(new_n221_), .B1(new_n308_), .B2(new_n34_), .C(new_n390_), .Y(new_n391_));
  AND3x1_ASAP7_75t_R   g370(.A(new_n212_), .B(new_n52_), .C(new_n33_), .Y(new_n392_));
  AO21x1_ASAP7_75t_R   g371(.A1(new_n42_), .A2(new_n391_), .B(new_n392_), .Y(new_n393_));
  AND3x1_ASAP7_75t_R   g372(.A(new_n284_), .B(new_n60_), .C(new_n85_), .Y(new_n394_));
  AO21x1_ASAP7_75t_R   g373(.A1(new_n178_), .A2(new_n393_), .B(new_n394_), .Y(new_n395_));
  AOI21x1_ASAP7_75t_R  g374(.A1(new_n157_), .A2(new_n389_), .B(new_n395_), .Y(o8));
  INVx1_ASAP7_75t_R    g375(.A(new_n240_), .Y(new_n397_));
  AO21x1_ASAP7_75t_R   g376(.A1(p8), .A2(p7), .B(p4), .Y(new_n398_));
  NAND2x1_ASAP7_75t_R  g377(.A(p2), .B(new_n118_), .Y(new_n399_));
  AO21x1_ASAP7_75t_R   g378(.A1(new_n252_), .A2(new_n300_), .B(new_n399_), .Y(new_n400_));
  OA21x2_ASAP7_75t_R   g379(.A1(new_n272_), .A2(new_n279_), .B(new_n25_), .Y(new_n401_));
  AO32x1_ASAP7_75t_R   g380(.A1(new_n202_), .A2(new_n334_), .A3(new_n398_), .B1(new_n400_), .B2(new_n401_), .Y(new_n402_));
  NAND2x1_ASAP7_75t_R  g381(.A(new_n42_), .B(new_n402_), .Y(new_n403_));
  OR3x1_ASAP7_75t_R    g382(.A(new_n160_), .B(p5), .C(new_n39_), .Y(new_n404_));
  AO21x1_ASAP7_75t_R   g383(.A1(new_n85_), .A2(new_n404_), .B(new_n287_), .Y(new_n405_));
  AO21x1_ASAP7_75t_R   g384(.A1(new_n60_), .A2(new_n203_), .B(new_n28_), .Y(new_n406_));
  OA211x2_ASAP7_75t_R  g385(.A1(new_n91_), .A2(new_n32_), .B(new_n405_), .C(new_n406_), .Y(new_n407_));
  OR3x1_ASAP7_75t_R    g386(.A(new_n253_), .B(p2), .C(new_n124_), .Y(new_n408_));
  OAI21x1_ASAP7_75t_R  g387(.A1(new_n398_), .A2(new_n259_), .B(new_n408_), .Y(new_n409_));
  AO21x1_ASAP7_75t_R   g388(.A1(new_n88_), .A2(new_n66_), .B(new_n300_), .Y(new_n410_));
  AND3x1_ASAP7_75t_R   g389(.A(new_n410_), .B(new_n25_), .C(new_n399_), .Y(new_n411_));
  OAI21x1_ASAP7_75t_R  g390(.A1(new_n409_), .A2(new_n411_), .B(p0), .Y(new_n412_));
  AO21x1_ASAP7_75t_R   g391(.A1(new_n52_), .A2(new_n202_), .B(new_n85_), .Y(new_n413_));
  AND5x1_ASAP7_75t_R   g392(.A(new_n397_), .B(new_n403_), .C(new_n407_), .D(new_n412_), .E(new_n413_), .Y(o9));
  AO21x1_ASAP7_75t_R   g393(.A1(p0), .A2(new_n53_), .B(new_n29_), .Y(new_n415_));
  AO21x1_ASAP7_75t_R   g394(.A1(p9), .A2(new_n24_), .B(p0), .Y(new_n416_));
  AND5x1_ASAP7_75t_R   g395(.A(p2), .B(new_n416_), .C(p1), .D(new_n272_), .E(new_n157_), .Y(new_n417_));
  AO21x1_ASAP7_75t_R   g396(.A1(new_n415_), .A2(new_n417_), .B(new_n364_), .Y(o10));
endmodule


