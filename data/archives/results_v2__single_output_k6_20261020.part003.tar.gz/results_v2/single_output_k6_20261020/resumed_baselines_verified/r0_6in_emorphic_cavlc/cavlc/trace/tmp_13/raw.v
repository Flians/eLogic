// Benchmark "/tmp/" written by ABC on Tue Oct 20 17:20:34 2026

module \/tmp/  ( 
    p5, p7, p8, p3, p1, p9, p2, p0, p4, p6,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10  );
  input  p5, p7, p8, p3, p1, p9, p2, p0, p4, p6;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10;
  wire new_n22_, new_n23_, new_n24_, new_n25_, new_n26_, new_n27_, new_n28_,
    new_n29_, new_n30_, new_n31_, new_n32_, new_n33_, new_n34_, new_n35_,
    new_n36_, new_n37_, new_n38_, new_n39_, new_n40_, new_n41_, new_n42_,
    new_n43_, new_n44_, new_n45_, new_n46_, new_n47_, new_n48_, new_n49_,
    new_n50_, new_n51_, new_n52_, new_n53_, new_n54_, new_n55_, new_n56_,
    new_n57_, new_n58_, new_n59_, new_n60_, new_n61_, new_n62_, new_n63_,
    new_n64_, new_n65_, new_n66_, new_n67_, new_n68_, new_n69_, new_n70_,
    new_n71_, new_n72_, new_n73_, new_n74_, new_n75_, new_n76_, new_n77_,
    new_n78_, new_n79_, new_n80_, new_n81_, new_n82_, new_n83_, new_n84_,
    new_n85_, new_n86_, new_n87_, new_n88_, new_n89_, new_n90_, new_n91_,
    new_n92_, new_n93_, new_n94_, new_n95_, new_n96_, new_n97_, new_n98_,
    new_n99_, new_n100_, new_n101_, new_n102_, new_n103_, new_n104_,
    new_n105_, new_n106_, new_n107_, new_n108_, new_n109_, new_n110_,
    new_n111_, new_n112_, new_n113_, new_n114_, new_n115_, new_n117_,
    new_n118_, new_n119_, new_n120_, new_n121_, new_n122_, new_n123_,
    new_n124_, new_n125_, new_n126_, new_n127_, new_n128_, new_n129_,
    new_n130_, new_n131_, new_n132_, new_n133_, new_n134_, new_n135_,
    new_n136_, new_n137_, new_n138_, new_n139_, new_n140_, new_n141_,
    new_n142_, new_n143_, new_n144_, new_n145_, new_n146_, new_n147_,
    new_n148_, new_n149_, new_n150_, new_n151_, new_n152_, new_n153_,
    new_n154_, new_n155_, new_n156_, new_n157_, new_n158_, new_n159_,
    new_n160_, new_n161_, new_n162_, new_n163_, new_n164_, new_n165_,
    new_n166_, new_n167_, new_n168_, new_n169_, new_n170_, new_n171_,
    new_n172_, new_n173_, new_n174_, new_n175_, new_n176_, new_n177_,
    new_n178_, new_n179_, new_n180_, new_n181_, new_n182_, new_n183_,
    new_n184_, new_n185_, new_n186_, new_n187_, new_n188_, new_n190_,
    new_n191_, new_n192_, new_n193_, new_n194_, new_n195_, new_n196_,
    new_n197_, new_n198_, new_n199_, new_n200_, new_n201_, new_n202_,
    new_n203_, new_n204_, new_n205_, new_n206_, new_n207_, new_n208_,
    new_n209_, new_n210_, new_n211_, new_n212_, new_n213_, new_n214_,
    new_n215_, new_n216_, new_n217_, new_n218_, new_n219_, new_n220_,
    new_n221_, new_n222_, new_n223_, new_n224_, new_n225_, new_n226_,
    new_n227_, new_n228_, new_n229_, new_n230_, new_n231_, new_n232_,
    new_n233_, new_n234_, new_n235_, new_n236_, new_n237_, new_n238_,
    new_n239_, new_n240_, new_n241_, new_n242_, new_n243_, new_n244_,
    new_n245_, new_n246_, new_n247_, new_n249_, new_n250_, new_n251_,
    new_n252_, new_n253_, new_n254_, new_n255_, new_n256_, new_n257_,
    new_n258_, new_n259_, new_n260_, new_n261_, new_n262_, new_n263_,
    new_n264_, new_n265_, new_n266_, new_n267_, new_n268_, new_n269_,
    new_n270_, new_n271_, new_n272_, new_n273_, new_n274_, new_n275_,
    new_n276_, new_n277_, new_n278_, new_n279_, new_n281_, new_n282_,
    new_n283_, new_n284_, new_n285_, new_n287_, new_n288_, new_n289_,
    new_n291_, new_n292_, new_n293_, new_n294_, new_n295_, new_n296_,
    new_n297_, new_n298_, new_n299_, new_n300_, new_n301_, new_n302_,
    new_n303_, new_n304_, new_n305_, new_n306_, new_n307_, new_n308_,
    new_n309_, new_n310_, new_n311_, new_n312_, new_n313_, new_n314_,
    new_n315_, new_n316_, new_n317_, new_n318_, new_n319_, new_n320_,
    new_n321_, new_n322_, new_n323_, new_n324_, new_n325_, new_n326_,
    new_n327_, new_n328_, new_n329_, new_n330_, new_n331_, new_n332_,
    new_n334_, new_n335_, new_n336_, new_n337_, new_n338_, new_n339_,
    new_n340_, new_n341_, new_n342_, new_n343_, new_n344_, new_n345_,
    new_n346_, new_n347_, new_n348_, new_n349_, new_n350_, new_n351_,
    new_n352_, new_n353_, new_n354_, new_n355_, new_n356_, new_n357_,
    new_n358_, new_n359_, new_n360_, new_n361_, new_n362_, new_n363_,
    new_n364_, new_n365_, new_n366_, new_n367_, new_n368_, new_n369_,
    new_n370_, new_n371_, new_n372_, new_n374_, new_n375_, new_n376_,
    new_n377_, new_n378_, new_n379_, new_n380_, new_n381_, new_n382_,
    new_n383_, new_n384_, new_n385_, new_n386_, new_n387_, new_n388_,
    new_n389_, new_n390_, new_n391_, new_n392_, new_n393_, new_n394_,
    new_n395_, new_n396_, new_n397_, new_n398_, new_n399_, new_n400_,
    new_n401_, new_n402_, new_n403_, new_n404_, new_n406_, new_n407_,
    new_n408_, new_n409_, new_n410_, new_n411_, new_n412_, new_n413_,
    new_n414_, new_n415_, new_n416_, new_n417_, new_n418_, new_n419_,
    new_n420_, new_n421_, new_n422_, new_n424_, new_n425_, new_n426_,
    new_n427_;
  NOR2x1_ASAP7_75t_R   g000(.A(p3), .B(p6), .Y(new_n22_));
  INVx1_ASAP7_75t_R    g001(.A(new_n22_), .Y(new_n23_));
  INVx1_ASAP7_75t_R    g002(.A(p8), .Y(new_n24_));
  NOR2x1_ASAP7_75t_R   g003(.A(p9), .B(new_n24_), .Y(new_n25_));
  NOR2x1_ASAP7_75t_R   g004(.A(p7), .B(p4), .Y(new_n26_));
  INVx1_ASAP7_75t_R    g005(.A(p9), .Y(new_n27_));
  NAND2x1_ASAP7_75t_R  g006(.A(p8), .B(new_n27_), .Y(new_n28_));
  NAND2x1_ASAP7_75t_R  g007(.A(p7), .B(p4), .Y(new_n29_));
  INVx1_ASAP7_75t_R    g008(.A(new_n29_), .Y(new_n30_));
  NAND2x1_ASAP7_75t_R  g009(.A(p9), .B(new_n24_), .Y(new_n31_));
  AND5x1_ASAP7_75t_R   g010(.A(p1), .B(new_n28_), .C(new_n30_), .D(new_n31_), .E(p0), .Y(new_n32_));
  AOI21x1_ASAP7_75t_R  g011(.A1(new_n25_), .A2(new_n26_), .B(new_n32_), .Y(new_n33_));
  INVx1_ASAP7_75t_R    g012(.A(p4), .Y(new_n34_));
  INVx1_ASAP7_75t_R    g013(.A(p1), .Y(new_n35_));
  INVx1_ASAP7_75t_R    g014(.A(p0), .Y(new_n36_));
  AND3x1_ASAP7_75t_R   g015(.A(new_n35_), .B(new_n27_), .C(new_n36_), .Y(new_n37_));
  INVx1_ASAP7_75t_R    g016(.A(new_n37_), .Y(new_n38_));
  NAND2x1_ASAP7_75t_R  g017(.A(p5), .B(p7), .Y(new_n39_));
  AO21x1_ASAP7_75t_R   g018(.A1(new_n24_), .A2(new_n34_), .B(new_n39_), .Y(new_n40_));
  AO21x1_ASAP7_75t_R   g019(.A1(new_n34_), .A2(new_n38_), .B(new_n40_), .Y(new_n41_));
  NAND2x1_ASAP7_75t_R  g020(.A(p1), .B(new_n36_), .Y(new_n42_));
  INVx1_ASAP7_75t_R    g021(.A(p7), .Y(new_n43_));
  NAND2x1_ASAP7_75t_R  g022(.A(p0), .B(new_n43_), .Y(new_n44_));
  AO221x2_ASAP7_75t_R  g023(.A1(new_n31_), .A2(new_n36_), .B1(new_n42_), .B2(new_n44_), .C(p4), .Y(new_n45_));
  INVx1_ASAP7_75t_R    g024(.A(p2), .Y(new_n46_));
  AO31x2_ASAP7_75t_R   g025(.A1(new_n33_), .A2(new_n41_), .A3(new_n45_), .B(new_n46_), .Y(new_n47_));
  AND2x2_ASAP7_75t_R   g026(.A(p1), .B(p2), .Y(new_n48_));
  INVx1_ASAP7_75t_R    g027(.A(new_n48_), .Y(new_n49_));
  NOR2x1_ASAP7_75t_R   g028(.A(p8), .B(p0), .Y(new_n50_));
  INVx1_ASAP7_75t_R    g029(.A(p5), .Y(new_n51_));
  NAND2x1_ASAP7_75t_R  g030(.A(p2), .B(new_n51_), .Y(new_n52_));
  AO32x1_ASAP7_75t_R   g031(.A1(new_n49_), .A2(new_n50_), .A3(new_n52_), .B1(p8), .B2(p1), .Y(new_n53_));
  AND2x2_ASAP7_75t_R   g032(.A(p8), .B(p1), .Y(new_n54_));
  NOR2x1_ASAP7_75t_R   g033(.A(p2), .B(p0), .Y(new_n55_));
  NOR2x1_ASAP7_75t_R   g034(.A(p7), .B(new_n36_), .Y(new_n56_));
  AO21x1_ASAP7_75t_R   g035(.A1(new_n54_), .A2(new_n55_), .B(new_n56_), .Y(new_n57_));
  AND3x1_ASAP7_75t_R   g036(.A(new_n57_), .B(new_n27_), .C(new_n34_), .Y(new_n58_));
  AOI21x1_ASAP7_75t_R  g037(.A1(new_n26_), .A2(new_n53_), .B(new_n58_), .Y(new_n59_));
  NOR2x1_ASAP7_75t_R   g038(.A(p7), .B(p8), .Y(new_n60_));
  NOR2x1_ASAP7_75t_R   g039(.A(p8), .B(p1), .Y(new_n61_));
  AO21x1_ASAP7_75t_R   g040(.A1(p0), .A2(new_n61_), .B(new_n54_), .Y(new_n62_));
  AND2x2_ASAP7_75t_R   g041(.A(p5), .B(p7), .Y(new_n63_));
  AO32x1_ASAP7_75t_R   g042(.A1(new_n35_), .A2(new_n36_), .A3(new_n60_), .B1(new_n62_), .B2(new_n63_), .Y(new_n64_));
  NOR2x1_ASAP7_75t_R   g043(.A(p9), .B(p2), .Y(new_n65_));
  NAND2x1_ASAP7_75t_R  g044(.A(p0), .B(new_n46_), .Y(new_n66_));
  AO21x1_ASAP7_75t_R   g045(.A1(p9), .A2(new_n24_), .B(p1), .Y(new_n67_));
  INVx1_ASAP7_75t_R    g046(.A(new_n67_), .Y(new_n68_));
  OAI21x1_ASAP7_75t_R  g047(.A1(new_n25_), .A2(new_n66_), .B(new_n68_), .Y(new_n69_));
  OA21x2_ASAP7_75t_R   g048(.A1(p5), .A2(new_n68_), .B(new_n30_), .Y(new_n70_));
  AOI22x1_ASAP7_75t_R  g049(.A1(new_n64_), .A2(new_n65_), .B1(new_n69_), .B2(new_n70_), .Y(new_n71_));
  AND3x1_ASAP7_75t_R   g050(.A(new_n47_), .B(new_n59_), .C(new_n71_), .Y(new_n72_));
  NAND2x1_ASAP7_75t_R  g051(.A(p1), .B(p0), .Y(new_n73_));
  AO21x1_ASAP7_75t_R   g052(.A1(new_n35_), .A2(new_n34_), .B(p9), .Y(new_n74_));
  AO21x1_ASAP7_75t_R   g053(.A1(new_n73_), .A2(new_n74_), .B(p8), .Y(new_n75_));
  NAND2x1_ASAP7_75t_R  g054(.A(p8), .B(new_n36_), .Y(new_n76_));
  NOR2x1_ASAP7_75t_R   g055(.A(p1), .B(p2), .Y(new_n77_));
  NAND3x1_ASAP7_75t_R  g056(.A(new_n36_), .B(p9), .C(p2), .Y(new_n78_));
  OA211x2_ASAP7_75t_R  g057(.A1(new_n76_), .A2(new_n77_), .B(new_n78_), .C(new_n66_), .Y(new_n79_));
  AO21x1_ASAP7_75t_R   g058(.A1(new_n75_), .A2(new_n79_), .B(p6), .Y(new_n80_));
  NAND2x1_ASAP7_75t_R  g059(.A(p9), .B(new_n35_), .Y(new_n81_));
  INVx1_ASAP7_75t_R    g060(.A(new_n81_), .Y(new_n82_));
  NAND2x1_ASAP7_75t_R  g061(.A(p4), .B(new_n36_), .Y(new_n83_));
  AND3x1_ASAP7_75t_R   g062(.A(new_n50_), .B(p1), .C(new_n27_), .Y(new_n84_));
  AO32x1_ASAP7_75t_R   g063(.A1(new_n82_), .A2(new_n76_), .A3(new_n83_), .B1(p6), .B2(new_n84_), .Y(new_n85_));
  NAND2x1_ASAP7_75t_R  g064(.A(p7), .B(new_n34_), .Y(new_n86_));
  NOR2x1_ASAP7_75t_R   g065(.A(p8), .B(p4), .Y(new_n87_));
  INVx1_ASAP7_75t_R    g066(.A(new_n87_), .Y(new_n88_));
  AO21x1_ASAP7_75t_R   g067(.A1(p6), .A2(new_n88_), .B(new_n81_), .Y(new_n89_));
  INVx1_ASAP7_75t_R    g068(.A(p6), .Y(new_n90_));
  NOR2x1_ASAP7_75t_R   g069(.A(p8), .B(new_n36_), .Y(new_n91_));
  AO21x1_ASAP7_75t_R   g070(.A1(new_n90_), .A2(new_n91_), .B(p2), .Y(new_n92_));
  AOI21x1_ASAP7_75t_R  g071(.A1(new_n86_), .A2(new_n89_), .B(new_n92_), .Y(new_n93_));
  NAND2x1_ASAP7_75t_R  g072(.A(p9), .B(p0), .Y(new_n94_));
  NOR2x1_ASAP7_75t_R   g073(.A(p2), .B(p4), .Y(new_n95_));
  NAND2x1_ASAP7_75t_R  g074(.A(new_n94_), .B(new_n95_), .Y(new_n96_));
  AO21x1_ASAP7_75t_R   g075(.A1(new_n27_), .A2(new_n36_), .B(p6), .Y(new_n97_));
  NOR2x1_ASAP7_75t_R   g076(.A(p7), .B(p1), .Y(new_n98_));
  INVx1_ASAP7_75t_R    g077(.A(new_n98_), .Y(new_n99_));
  AND2x2_ASAP7_75t_R   g078(.A(p8), .B(p0), .Y(new_n100_));
  NOR2x1_ASAP7_75t_R   g079(.A(new_n50_), .B(new_n100_), .Y(new_n101_));
  AOI211x1_ASAP7_75t_R g080(.A1(new_n96_), .A2(new_n97_), .B(new_n99_), .C(new_n101_), .Y(new_n102_));
  AOI21x1_ASAP7_75t_R  g081(.A1(new_n85_), .A2(new_n93_), .B(new_n102_), .Y(new_n103_));
  OAI21x1_ASAP7_75t_R  g082(.A1(p7), .A2(new_n80_), .B(new_n103_), .Y(new_n104_));
  NOR2x1_ASAP7_75t_R   g083(.A(p5), .B(p3), .Y(new_n105_));
  NOR2x1_ASAP7_75t_R   g084(.A(p5), .B(p8), .Y(new_n106_));
  INVx1_ASAP7_75t_R    g085(.A(new_n106_), .Y(new_n107_));
  OA21x2_ASAP7_75t_R   g086(.A1(new_n24_), .A2(p3), .B(new_n107_), .Y(new_n108_));
  AND2x2_ASAP7_75t_R   g087(.A(p5), .B(p4), .Y(new_n109_));
  INVx1_ASAP7_75t_R    g088(.A(new_n109_), .Y(new_n110_));
  AO21x1_ASAP7_75t_R   g089(.A1(p7), .A2(p3), .B(new_n106_), .Y(new_n111_));
  AO21x1_ASAP7_75t_R   g090(.A1(new_n43_), .A2(p4), .B(new_n109_), .Y(new_n112_));
  AO32x1_ASAP7_75t_R   g091(.A1(new_n108_), .A2(new_n43_), .A3(new_n110_), .B1(new_n111_), .B2(new_n112_), .Y(new_n113_));
  AND5x1_ASAP7_75t_R   g092(.A(new_n35_), .B(new_n27_), .C(new_n46_), .D(new_n36_), .E(new_n90_), .Y(new_n114_));
  AOI22x1_ASAP7_75t_R  g093(.A1(new_n104_), .A2(new_n105_), .B1(new_n113_), .B2(new_n114_), .Y(new_n115_));
  OAI21x1_ASAP7_75t_R  g094(.A1(new_n23_), .A2(new_n72_), .B(new_n115_), .Y(o0));
  AND3x1_ASAP7_75t_R   g095(.A(new_n35_), .B(p7), .C(p9), .Y(new_n117_));
  AO21x1_ASAP7_75t_R   g096(.A1(p7), .A2(p2), .B(p1), .Y(new_n118_));
  AOI22x1_ASAP7_75t_R  g097(.A1(new_n117_), .A2(p0), .B1(new_n27_), .B2(new_n118_), .Y(new_n119_));
  NAND2x1_ASAP7_75t_R  g098(.A(p4), .B(new_n27_), .Y(new_n120_));
  NOR2x1_ASAP7_75t_R   g099(.A(p4), .B(new_n27_), .Y(new_n121_));
  INVx1_ASAP7_75t_R    g100(.A(new_n121_), .Y(new_n122_));
  AO21x1_ASAP7_75t_R   g101(.A1(new_n120_), .A2(new_n122_), .B(new_n36_), .Y(new_n123_));
  NAND2x1_ASAP7_75t_R  g102(.A(new_n119_), .B(new_n123_), .Y(new_n124_));
  AND3x1_ASAP7_75t_R   g103(.A(new_n43_), .B(new_n35_), .C(p4), .Y(new_n125_));
  NOR2x1_ASAP7_75t_R   g104(.A(p7), .B(p2), .Y(new_n126_));
  AO21x1_ASAP7_75t_R   g105(.A1(p7), .A2(new_n34_), .B(new_n126_), .Y(new_n127_));
  NOR2x1_ASAP7_75t_R   g106(.A(new_n27_), .B(new_n127_), .Y(new_n128_));
  OA21x2_ASAP7_75t_R   g107(.A1(new_n125_), .A2(new_n128_), .B(new_n36_), .Y(new_n129_));
  OAI21x1_ASAP7_75t_R  g108(.A1(new_n124_), .A2(new_n129_), .B(new_n106_), .Y(new_n130_));
  NAND2x1_ASAP7_75t_R  g109(.A(p0), .B(p4), .Y(new_n131_));
  NOR2x1_ASAP7_75t_R   g110(.A(p0), .B(new_n46_), .Y(new_n132_));
  NAND2x1_ASAP7_75t_R  g111(.A(new_n98_), .B(new_n132_), .Y(new_n133_));
  NAND2x1_ASAP7_75t_R  g112(.A(p5), .B(p9), .Y(new_n134_));
  AO21x1_ASAP7_75t_R   g113(.A1(new_n131_), .A2(new_n133_), .B(new_n134_), .Y(new_n135_));
  OR3x1_ASAP7_75t_R    g114(.A(new_n77_), .B(new_n95_), .C(new_n51_), .Y(new_n136_));
  AO21x1_ASAP7_75t_R   g115(.A1(new_n34_), .A2(new_n73_), .B(new_n136_), .Y(new_n137_));
  NAND3x1_ASAP7_75t_R  g116(.A(p1), .B(p2), .C(p4), .Y(new_n138_));
  OR3x1_ASAP7_75t_R    g117(.A(new_n138_), .B(p7), .C(new_n36_), .Y(new_n139_));
  AO31x2_ASAP7_75t_R   g118(.A1(new_n135_), .A2(new_n137_), .A3(new_n139_), .B(new_n24_), .Y(new_n140_));
  NAND2x1_ASAP7_75t_R  g119(.A(p2), .B(new_n34_), .Y(new_n141_));
  NOR2x1_ASAP7_75t_R   g120(.A(p7), .B(p0), .Y(new_n142_));
  OR3x1_ASAP7_75t_R    g121(.A(new_n51_), .B(new_n43_), .C(p0), .Y(new_n143_));
  OA21x2_ASAP7_75t_R   g122(.A1(p1), .A2(new_n142_), .B(new_n143_), .Y(new_n144_));
  INVx1_ASAP7_75t_R    g123(.A(new_n94_), .Y(new_n145_));
  NOR2x1_ASAP7_75t_R   g124(.A(p9), .B(new_n43_), .Y(new_n146_));
  NOR2x1_ASAP7_75t_R   g125(.A(p5), .B(p0), .Y(new_n147_));
  OR5x1_ASAP7_75t_R    g126(.A(p1), .B(new_n145_), .C(new_n146_), .D(p4), .E(new_n147_), .Y(new_n148_));
  OAI21x1_ASAP7_75t_R  g127(.A1(new_n141_), .A2(new_n144_), .B(new_n148_), .Y(new_n149_));
  NAND2x1_ASAP7_75t_R  g128(.A(new_n24_), .B(new_n149_), .Y(new_n150_));
  AO31x2_ASAP7_75t_R   g129(.A1(new_n130_), .A2(new_n140_), .A3(new_n150_), .B(new_n23_), .Y(new_n151_));
  NAND2x1_ASAP7_75t_R  g130(.A(p5), .B(p8), .Y(new_n152_));
  NAND2x1_ASAP7_75t_R  g131(.A(new_n152_), .B(new_n86_), .Y(new_n153_));
  AO32x1_ASAP7_75t_R   g132(.A1(new_n153_), .A2(new_n39_), .A3(new_n82_), .B1(new_n25_), .B2(new_n125_), .Y(new_n154_));
  NOR2x1_ASAP7_75t_R   g133(.A(p5), .B(p7), .Y(new_n155_));
  INVx1_ASAP7_75t_R    g134(.A(new_n155_), .Y(new_n156_));
  NAND2x1_ASAP7_75t_R  g135(.A(p5), .B(new_n27_), .Y(new_n157_));
  AO21x1_ASAP7_75t_R   g136(.A1(new_n35_), .A2(new_n157_), .B(new_n86_), .Y(new_n158_));
  NAND2x1_ASAP7_75t_R  g137(.A(new_n156_), .B(new_n158_), .Y(new_n159_));
  AOI22x1_ASAP7_75t_R  g138(.A1(new_n154_), .A2(p0), .B1(new_n91_), .B2(new_n159_), .Y(new_n160_));
  OR4x2_ASAP7_75t_R    g139(.A(p7), .B(p8), .C(p1), .D(p9), .Y(new_n161_));
  AND2x2_ASAP7_75t_R   g140(.A(p7), .B(p9), .Y(new_n162_));
  NAND2x1_ASAP7_75t_R  g141(.A(new_n54_), .B(new_n162_), .Y(new_n163_));
  NAND2x1_ASAP7_75t_R  g142(.A(new_n161_), .B(new_n163_), .Y(new_n164_));
  NOR2x1_ASAP7_75t_R   g143(.A(p0), .B(new_n34_), .Y(new_n165_));
  AND2x2_ASAP7_75t_R   g144(.A(p7), .B(p1), .Y(new_n166_));
  AOI22x1_ASAP7_75t_R  g145(.A1(new_n164_), .A2(new_n165_), .B1(new_n106_), .B2(new_n166_), .Y(new_n167_));
  AO21x1_ASAP7_75t_R   g146(.A1(new_n152_), .A2(new_n86_), .B(p9), .Y(new_n168_));
  XOR2x2_ASAP7_75t_R   g147(.A(p7), .B(p8), .Y(new_n169_));
  AO21x1_ASAP7_75t_R   g148(.A1(new_n88_), .A2(new_n152_), .B(new_n169_), .Y(new_n170_));
  AO21x1_ASAP7_75t_R   g149(.A1(new_n168_), .A2(new_n170_), .B(new_n42_), .Y(new_n171_));
  AND2x2_ASAP7_75t_R   g150(.A(new_n167_), .B(new_n171_), .Y(new_n172_));
  OR3x1_ASAP7_75t_R    g151(.A(p3), .B(p2), .C(p6), .Y(new_n173_));
  AO21x1_ASAP7_75t_R   g152(.A1(new_n160_), .A2(new_n172_), .B(new_n173_), .Y(new_n174_));
  INVx1_ASAP7_75t_R    g153(.A(p3), .Y(new_n175_));
  AND3x1_ASAP7_75t_R   g154(.A(new_n95_), .B(new_n51_), .C(new_n175_), .Y(new_n176_));
  NOR2x1_ASAP7_75t_R   g155(.A(p7), .B(p9), .Y(new_n177_));
  OA211x2_ASAP7_75t_R  g156(.A1(new_n98_), .A2(new_n177_), .B(new_n73_), .C(p6), .Y(new_n178_));
  OA21x2_ASAP7_75t_R   g157(.A1(new_n145_), .A2(new_n67_), .B(new_n178_), .Y(new_n179_));
  NOR2x1_ASAP7_75t_R   g158(.A(p1), .B(new_n43_), .Y(new_n180_));
  AND3x1_ASAP7_75t_R   g159(.A(new_n91_), .B(new_n180_), .C(p6), .Y(new_n181_));
  OR3x1_ASAP7_75t_R    g160(.A(new_n179_), .B(new_n84_), .C(new_n181_), .Y(new_n182_));
  AND2x2_ASAP7_75t_R   g161(.A(p7), .B(p3), .Y(new_n183_));
  AO21x1_ASAP7_75t_R   g162(.A1(new_n43_), .A2(p4), .B(new_n183_), .Y(new_n184_));
  AND2x2_ASAP7_75t_R   g163(.A(p3), .B(new_n114_), .Y(new_n185_));
  INVx1_ASAP7_75t_R    g164(.A(new_n152_), .Y(new_n186_));
  AO32x1_ASAP7_75t_R   g165(.A1(new_n106_), .A2(new_n114_), .A3(new_n184_), .B1(new_n185_), .B2(new_n186_), .Y(new_n187_));
  AOI21x1_ASAP7_75t_R  g166(.A1(new_n176_), .A2(new_n182_), .B(new_n187_), .Y(new_n188_));
  NAND3x1_ASAP7_75t_R  g167(.A(new_n151_), .B(new_n174_), .C(new_n188_), .Y(o1));
  NAND2x1_ASAP7_75t_R  g168(.A(p0), .B(new_n24_), .Y(new_n190_));
  AND2x2_ASAP7_75t_R   g169(.A(new_n126_), .B(new_n190_), .Y(new_n191_));
  AND3x1_ASAP7_75t_R   g170(.A(new_n24_), .B(p7), .C(p0), .Y(new_n192_));
  OR3x1_ASAP7_75t_R    g171(.A(new_n191_), .B(new_n63_), .C(new_n192_), .Y(new_n193_));
  AND2x2_ASAP7_75t_R   g172(.A(p1), .B(p0), .Y(new_n194_));
  AO32x1_ASAP7_75t_R   g173(.A1(new_n194_), .A2(p5), .A3(p8), .B1(new_n63_), .B2(new_n36_), .Y(new_n195_));
  NOR2x1_ASAP7_75t_R   g174(.A(p8), .B(new_n35_), .Y(new_n196_));
  NOR2x1_ASAP7_75t_R   g175(.A(new_n43_), .B(new_n196_), .Y(new_n197_));
  NAND2x1_ASAP7_75t_R  g176(.A(p1), .B(new_n60_), .Y(new_n198_));
  INVx1_ASAP7_75t_R    g177(.A(new_n198_), .Y(new_n199_));
  OR3x1_ASAP7_75t_R    g178(.A(new_n195_), .B(new_n197_), .C(new_n199_), .Y(new_n200_));
  AO32x1_ASAP7_75t_R   g179(.A1(new_n193_), .A2(new_n35_), .A3(new_n76_), .B1(new_n200_), .B2(p2), .Y(new_n201_));
  AND3x1_ASAP7_75t_R   g180(.A(new_n22_), .B(p9), .C(new_n34_), .Y(new_n202_));
  OR3x1_ASAP7_75t_R    g181(.A(new_n24_), .B(new_n35_), .C(p4), .Y(new_n203_));
  OR3x1_ASAP7_75t_R    g182(.A(new_n169_), .B(new_n34_), .C(new_n25_), .Y(new_n204_));
  AOI21x1_ASAP7_75t_R  g183(.A1(new_n203_), .A2(new_n204_), .B(new_n66_), .Y(new_n205_));
  NOR2x1_ASAP7_75t_R   g184(.A(p2), .B(new_n35_), .Y(new_n206_));
  NAND2x1_ASAP7_75t_R  g185(.A(p7), .B(p8), .Y(new_n207_));
  INVx1_ASAP7_75t_R    g186(.A(new_n60_), .Y(new_n208_));
  AO21x1_ASAP7_75t_R   g187(.A1(new_n207_), .A2(new_n208_), .B(new_n50_), .Y(new_n209_));
  INVx1_ASAP7_75t_R    g188(.A(new_n77_), .Y(new_n210_));
  NOR2x1_ASAP7_75t_R   g189(.A(p0), .B(new_n24_), .Y(new_n211_));
  AND3x1_ASAP7_75t_R   g190(.A(new_n210_), .B(new_n211_), .C(new_n162_), .Y(new_n212_));
  AO21x1_ASAP7_75t_R   g191(.A1(new_n206_), .A2(new_n209_), .B(new_n212_), .Y(new_n213_));
  OR3x1_ASAP7_75t_R    g192(.A(p7), .B(p8), .C(p1), .Y(new_n214_));
  AOI21x1_ASAP7_75t_R  g193(.A1(new_n78_), .A2(new_n122_), .B(new_n214_), .Y(new_n215_));
  OR3x1_ASAP7_75t_R    g194(.A(new_n205_), .B(new_n213_), .C(new_n215_), .Y(new_n216_));
  AND3x1_ASAP7_75t_R   g195(.A(new_n51_), .B(new_n175_), .C(new_n90_), .Y(new_n217_));
  AOI22x1_ASAP7_75t_R  g196(.A1(new_n201_), .A2(new_n202_), .B1(new_n216_), .B2(new_n217_), .Y(new_n218_));
  AND2x2_ASAP7_75t_R   g197(.A(p7), .B(p8), .Y(new_n219_));
  AO21x1_ASAP7_75t_R   g198(.A1(p6), .A2(new_n219_), .B(new_n27_), .Y(new_n220_));
  NOR2x1_ASAP7_75t_R   g199(.A(p8), .B(new_n27_), .Y(new_n221_));
  AO32x1_ASAP7_75t_R   g200(.A1(new_n220_), .A2(p0), .A3(new_n28_), .B1(new_n221_), .B2(new_n142_), .Y(new_n222_));
  NAND3x1_ASAP7_75t_R  g201(.A(new_n222_), .B(new_n35_), .C(new_n176_), .Y(new_n223_));
  NAND2x1_ASAP7_75t_R  g202(.A(p7), .B(new_n35_), .Y(new_n224_));
  AND2x2_ASAP7_75t_R   g203(.A(p2), .B(p4), .Y(new_n225_));
  NOR2x1_ASAP7_75t_R   g204(.A(p1), .B(new_n46_), .Y(new_n226_));
  AO221x2_ASAP7_75t_R  g205(.A1(new_n224_), .A2(new_n225_), .B1(new_n34_), .B2(new_n226_), .C(new_n26_), .Y(new_n227_));
  AO21x1_ASAP7_75t_R   g206(.A1(p2), .A2(new_n24_), .B(p5), .Y(new_n228_));
  NAND2x1_ASAP7_75t_R  g207(.A(p8), .B(new_n51_), .Y(new_n229_));
  OR3x1_ASAP7_75t_R    g208(.A(new_n229_), .B(p7), .C(new_n46_), .Y(new_n230_));
  AOI22x1_ASAP7_75t_R  g209(.A1(new_n227_), .A2(new_n228_), .B1(new_n190_), .B2(new_n230_), .Y(new_n231_));
  INVx1_ASAP7_75t_R    g210(.A(new_n226_), .Y(new_n232_));
  NOR2x1_ASAP7_75t_R   g211(.A(p7), .B(new_n46_), .Y(new_n233_));
  NAND2x1_ASAP7_75t_R  g212(.A(new_n211_), .B(new_n233_), .Y(new_n234_));
  AOI211x1_ASAP7_75t_R g213(.A1(new_n232_), .A2(new_n234_), .B(new_n106_), .C(new_n192_), .Y(new_n235_));
  NAND2x1_ASAP7_75t_R  g214(.A(p5), .B(new_n43_), .Y(new_n236_));
  OR3x1_ASAP7_75t_R    g215(.A(new_n165_), .B(new_n236_), .C(p2), .Y(new_n237_));
  NOR2x1_ASAP7_75t_R   g216(.A(new_n101_), .B(new_n237_), .Y(new_n238_));
  AND2x2_ASAP7_75t_R   g217(.A(p5), .B(p1), .Y(new_n239_));
  AO21x1_ASAP7_75t_R   g218(.A1(p1), .A2(new_n43_), .B(new_n36_), .Y(new_n240_));
  OA211x2_ASAP7_75t_R  g219(.A1(new_n239_), .A2(new_n240_), .B(p4), .C(new_n118_), .Y(new_n241_));
  OR4x2_ASAP7_75t_R    g220(.A(new_n235_), .B(new_n238_), .C(p3), .D(new_n241_), .Y(new_n242_));
  AO21x1_ASAP7_75t_R   g221(.A1(new_n207_), .A2(new_n236_), .B(p4), .Y(new_n243_));
  AO21x1_ASAP7_75t_R   g222(.A1(new_n36_), .A2(new_n77_), .B(new_n175_), .Y(new_n244_));
  AND3x1_ASAP7_75t_R   g223(.A(new_n244_), .B(new_n27_), .C(new_n90_), .Y(new_n245_));
  OA21x2_ASAP7_75t_R   g224(.A1(new_n175_), .A2(new_n243_), .B(new_n245_), .Y(new_n246_));
  OAI21x1_ASAP7_75t_R  g225(.A1(new_n231_), .A2(new_n242_), .B(new_n246_), .Y(new_n247_));
  NAND3x1_ASAP7_75t_R  g226(.A(new_n218_), .B(new_n223_), .C(new_n247_), .Y(o2));
  AO32x1_ASAP7_75t_R   g227(.A1(new_n61_), .A2(p2), .A3(new_n34_), .B1(new_n51_), .B2(new_n43_), .Y(new_n249_));
  OA21x2_ASAP7_75t_R   g228(.A1(new_n132_), .A2(new_n226_), .B(new_n249_), .Y(new_n250_));
  AO21x1_ASAP7_75t_R   g229(.A1(new_n36_), .A2(new_n60_), .B(new_n192_), .Y(new_n251_));
  AND3x1_ASAP7_75t_R   g230(.A(new_n251_), .B(p5), .C(new_n34_), .Y(new_n252_));
  NOR2x1_ASAP7_75t_R   g231(.A(new_n250_), .B(new_n252_), .Y(new_n253_));
  NOR2x1_ASAP7_75t_R   g232(.A(p1), .B(new_n34_), .Y(new_n254_));
  AO21x1_ASAP7_75t_R   g233(.A1(new_n254_), .A2(new_n169_), .B(new_n226_), .Y(new_n255_));
  OA21x2_ASAP7_75t_R   g234(.A1(p5), .A2(new_n233_), .B(new_n141_), .Y(new_n256_));
  AO21x1_ASAP7_75t_R   g235(.A1(new_n196_), .A2(new_n127_), .B(new_n256_), .Y(new_n257_));
  OAI21x1_ASAP7_75t_R  g236(.A1(new_n255_), .A2(new_n257_), .B(new_n145_), .Y(new_n258_));
  AO21x1_ASAP7_75t_R   g237(.A1(new_n51_), .A2(new_n34_), .B(new_n106_), .Y(new_n259_));
  OA21x2_ASAP7_75t_R   g238(.A1(new_n30_), .A2(new_n100_), .B(p2), .Y(new_n260_));
  NAND2x1_ASAP7_75t_R  g239(.A(new_n259_), .B(new_n260_), .Y(new_n261_));
  OR3x1_ASAP7_75t_R    g240(.A(new_n35_), .B(new_n46_), .C(p5), .Y(new_n262_));
  OR3x1_ASAP7_75t_R    g241(.A(new_n77_), .B(new_n51_), .C(p4), .Y(new_n263_));
  AO21x1_ASAP7_75t_R   g242(.A1(new_n262_), .A2(new_n263_), .B(new_n76_), .Y(new_n264_));
  AO32x1_ASAP7_75t_R   g243(.A1(new_n98_), .A2(new_n147_), .A3(p4), .B1(p5), .B2(new_n95_), .Y(new_n265_));
  NAND2x1_ASAP7_75t_R  g244(.A(new_n221_), .B(new_n265_), .Y(new_n266_));
  AND5x1_ASAP7_75t_R   g245(.A(new_n253_), .B(new_n258_), .C(new_n261_), .D(new_n264_), .E(new_n266_), .Y(new_n267_));
  AO21x1_ASAP7_75t_R   g246(.A1(new_n46_), .A2(new_n236_), .B(new_n112_), .Y(new_n268_));
  AOI22x1_ASAP7_75t_R  g247(.A1(new_n132_), .A2(new_n229_), .B1(new_n239_), .B2(new_n131_), .Y(new_n269_));
  OR3x1_ASAP7_75t_R    g248(.A(p7), .B(p8), .C(p4), .Y(new_n270_));
  OR3x1_ASAP7_75t_R    g249(.A(new_n29_), .B(p5), .C(new_n24_), .Y(new_n271_));
  AO21x1_ASAP7_75t_R   g250(.A1(new_n270_), .A2(new_n271_), .B(new_n73_), .Y(new_n272_));
  OA211x2_ASAP7_75t_R  g251(.A1(new_n36_), .A2(new_n268_), .B(new_n269_), .C(new_n272_), .Y(new_n273_));
  NOR2x1_ASAP7_75t_R   g252(.A(p5), .B(p4), .Y(new_n274_));
  AO21x1_ASAP7_75t_R   g253(.A1(p7), .A2(p8), .B(p4), .Y(new_n275_));
  AND5x1_ASAP7_75t_R   g254(.A(p3), .B(new_n275_), .C(new_n35_), .D(new_n46_), .E(new_n36_), .Y(new_n276_));
  OAI21x1_ASAP7_75t_R  g255(.A1(new_n109_), .A2(new_n274_), .B(new_n276_), .Y(new_n277_));
  OA21x2_ASAP7_75t_R   g256(.A1(p3), .A2(new_n273_), .B(new_n277_), .Y(new_n278_));
  NAND2x1_ASAP7_75t_R  g257(.A(new_n27_), .B(new_n90_), .Y(new_n279_));
  OAI22x1_ASAP7_75t_R  g258(.A1(new_n267_), .A2(new_n23_), .B1(new_n278_), .B2(new_n279_), .Y(o3));
  OA211x2_ASAP7_75t_R  g259(.A1(p9), .A2(p0), .B(new_n175_), .C(p1), .Y(new_n281_));
  NOR2x1_ASAP7_75t_R   g260(.A(p2), .B(new_n175_), .Y(new_n282_));
  NOR2x1_ASAP7_75t_R   g261(.A(p3), .B(new_n46_), .Y(new_n283_));
  OA21x2_ASAP7_75t_R   g262(.A1(new_n282_), .A2(new_n283_), .B(new_n37_), .Y(new_n284_));
  AND3x1_ASAP7_75t_R   g263(.A(new_n90_), .B(p5), .C(p4), .Y(new_n285_));
  OA21x2_ASAP7_75t_R   g264(.A1(new_n281_), .A2(new_n284_), .B(new_n285_), .Y(o4));
  NOR2x1_ASAP7_75t_R   g265(.A(p9), .B(p0), .Y(new_n287_));
  AND3x1_ASAP7_75t_R   g266(.A(new_n287_), .B(new_n77_), .C(p3), .Y(new_n288_));
  AO21x1_ASAP7_75t_R   g267(.A1(new_n283_), .A2(new_n38_), .B(new_n288_), .Y(new_n289_));
  AND2x2_ASAP7_75t_R   g268(.A(new_n285_), .B(new_n289_), .Y(o5));
  AO21x1_ASAP7_75t_R   g269(.A1(new_n100_), .A2(new_n162_), .B(new_n60_), .Y(new_n291_));
  AND3x1_ASAP7_75t_R   g270(.A(new_n291_), .B(new_n35_), .C(p6), .Y(new_n292_));
  NAND2x1_ASAP7_75t_R  g271(.A(p0), .B(new_n61_), .Y(new_n293_));
  NAND2x1_ASAP7_75t_R  g272(.A(p6), .B(new_n24_), .Y(new_n294_));
  AO21x1_ASAP7_75t_R   g273(.A1(p7), .A2(new_n294_), .B(new_n42_), .Y(new_n295_));
  AOI21x1_ASAP7_75t_R  g274(.A1(new_n293_), .A2(new_n295_), .B(p9), .Y(new_n296_));
  OAI21x1_ASAP7_75t_R  g275(.A1(new_n292_), .A2(new_n296_), .B(new_n274_), .Y(new_n297_));
  AND3x1_ASAP7_75t_R   g276(.A(new_n27_), .B(p8), .C(p1), .Y(new_n298_));
  AO32x1_ASAP7_75t_R   g277(.A1(new_n100_), .A2(p7), .A3(p9), .B1(new_n36_), .B2(new_n60_), .Y(new_n299_));
  OAI21x1_ASAP7_75t_R  g278(.A1(new_n298_), .A2(new_n299_), .B(p4), .Y(new_n300_));
  AND3x1_ASAP7_75t_R   g279(.A(new_n73_), .B(new_n51_), .C(new_n24_), .Y(new_n301_));
  OA21x2_ASAP7_75t_R   g280(.A1(new_n35_), .A2(new_n34_), .B(new_n162_), .Y(new_n302_));
  AND3x1_ASAP7_75t_R   g281(.A(new_n88_), .B(new_n27_), .C(new_n166_), .Y(new_n303_));
  AOI21x1_ASAP7_75t_R  g282(.A1(new_n301_), .A2(new_n302_), .B(new_n303_), .Y(new_n304_));
  NOR2x1_ASAP7_75t_R   g283(.A(new_n98_), .B(new_n166_), .Y(new_n305_));
  OR3x1_ASAP7_75t_R    g284(.A(new_n305_), .B(new_n51_), .C(new_n169_), .Y(new_n306_));
  AO31x2_ASAP7_75t_R   g285(.A1(new_n300_), .A2(new_n304_), .A3(new_n306_), .B(p6), .Y(new_n307_));
  AOI21x1_ASAP7_75t_R  g286(.A1(new_n297_), .A2(new_n307_), .B(p2), .Y(new_n308_));
  AO21x1_ASAP7_75t_R   g287(.A1(p3), .A2(new_n114_), .B(new_n285_), .Y(new_n309_));
  AO21x1_ASAP7_75t_R   g288(.A1(new_n31_), .A2(new_n254_), .B(new_n25_), .Y(new_n310_));
  AO21x1_ASAP7_75t_R   g289(.A1(p1), .A2(new_n34_), .B(p5), .Y(new_n311_));
  OA21x2_ASAP7_75t_R   g290(.A1(new_n28_), .A2(new_n311_), .B(new_n56_), .Y(new_n312_));
  OA21x2_ASAP7_75t_R   g291(.A1(p7), .A2(p8), .B(p1), .Y(new_n313_));
  AO21x1_ASAP7_75t_R   g292(.A1(p8), .A2(new_n162_), .B(new_n313_), .Y(new_n314_));
  AND3x1_ASAP7_75t_R   g293(.A(new_n314_), .B(p5), .C(p0), .Y(new_n315_));
  NOR2x1_ASAP7_75t_R   g294(.A(p5), .B(p9), .Y(new_n316_));
  INVx1_ASAP7_75t_R    g295(.A(new_n316_), .Y(new_n317_));
  NAND2x1_ASAP7_75t_R  g296(.A(p7), .B(new_n27_), .Y(new_n318_));
  AND3x1_ASAP7_75t_R   g297(.A(new_n317_), .B(new_n318_), .C(new_n29_), .Y(new_n319_));
  NOR2x1_ASAP7_75t_R   g298(.A(p0), .B(new_n43_), .Y(new_n320_));
  AO32x1_ASAP7_75t_R   g299(.A1(new_n319_), .A2(new_n35_), .A3(new_n50_), .B1(new_n320_), .B2(new_n298_), .Y(new_n321_));
  AOI211x1_ASAP7_75t_R g300(.A1(new_n310_), .A2(new_n312_), .B(new_n315_), .C(new_n321_), .Y(new_n322_));
  NOR2x1_ASAP7_75t_R   g301(.A(p9), .B(new_n35_), .Y(new_n323_));
  OA22x2_ASAP7_75t_R   g302(.A1(new_n323_), .A2(new_n44_), .B1(new_n134_), .B2(new_n224_), .Y(new_n324_));
  OR3x1_ASAP7_75t_R    g303(.A(new_n121_), .B(new_n190_), .C(new_n177_), .Y(new_n325_));
  OAI21x1_ASAP7_75t_R  g304(.A1(new_n24_), .A2(new_n324_), .B(new_n325_), .Y(new_n326_));
  OR4x2_ASAP7_75t_R    g305(.A(new_n91_), .B(new_n211_), .C(new_n320_), .D(new_n27_), .Y(new_n327_));
  NOR2x1_ASAP7_75t_R   g306(.A(new_n142_), .B(new_n317_), .Y(new_n328_));
  OAI21x1_ASAP7_75t_R  g307(.A1(new_n196_), .A2(new_n328_), .B(new_n101_), .Y(new_n329_));
  AOI21x1_ASAP7_75t_R  g308(.A1(new_n327_), .A2(new_n329_), .B(p4), .Y(new_n330_));
  OAI21x1_ASAP7_75t_R  g309(.A1(new_n326_), .A2(new_n330_), .B(p2), .Y(new_n331_));
  AOI21x1_ASAP7_75t_R  g310(.A1(new_n322_), .A2(new_n331_), .B(new_n23_), .Y(new_n332_));
  AOI211x1_ASAP7_75t_R g311(.A1(new_n175_), .A2(new_n308_), .B(new_n309_), .C(new_n332_), .Y(o6));
  AO32x1_ASAP7_75t_R   g312(.A1(new_n117_), .A2(new_n24_), .A3(p6), .B1(new_n169_), .B2(new_n323_), .Y(new_n334_));
  AND3x1_ASAP7_75t_R   g313(.A(new_n334_), .B(new_n55_), .C(new_n274_), .Y(new_n335_));
  OA21x2_ASAP7_75t_R   g314(.A1(new_n90_), .A2(new_n335_), .B(new_n175_), .Y(new_n336_));
  AOI21x1_ASAP7_75t_R  g315(.A1(new_n52_), .A2(new_n236_), .B(new_n24_), .Y(new_n337_));
  NAND2x1_ASAP7_75t_R  g316(.A(new_n318_), .B(new_n236_), .Y(new_n338_));
  AOI221x1_ASAP7_75t_R g317(.A1(p8), .A2(new_n27_), .B1(new_n152_), .B2(new_n43_), .C(new_n316_), .Y(new_n339_));
  AOI22x1_ASAP7_75t_R  g318(.A1(new_n337_), .A2(new_n338_), .B1(new_n52_), .B2(new_n339_), .Y(new_n340_));
  NOR2x1_ASAP7_75t_R   g319(.A(p5), .B(new_n35_), .Y(new_n341_));
  AO21x1_ASAP7_75t_R   g320(.A1(p2), .A2(new_n207_), .B(new_n162_), .Y(new_n342_));
  AO32x1_ASAP7_75t_R   g321(.A1(new_n219_), .A2(p1), .A3(new_n46_), .B1(new_n106_), .B2(new_n126_), .Y(new_n343_));
  AOI21x1_ASAP7_75t_R  g322(.A1(new_n341_), .A2(new_n342_), .B(new_n343_), .Y(new_n344_));
  OAI21x1_ASAP7_75t_R  g323(.A1(p1), .A2(new_n340_), .B(new_n344_), .Y(new_n345_));
  AO21x1_ASAP7_75t_R   g324(.A1(p7), .A2(p8), .B(p5), .Y(new_n346_));
  OAI22x1_ASAP7_75t_R  g325(.A1(new_n67_), .A2(new_n346_), .B1(new_n169_), .B2(new_n157_), .Y(new_n347_));
  NAND2x1_ASAP7_75t_R  g326(.A(p5), .B(p2), .Y(new_n348_));
  OAI22x1_ASAP7_75t_R  g327(.A1(new_n143_), .A2(new_n31_), .B1(new_n348_), .B2(new_n214_), .Y(new_n349_));
  OAI21x1_ASAP7_75t_R  g328(.A1(p5), .A2(new_n126_), .B(new_n313_), .Y(new_n350_));
  AOI21x1_ASAP7_75t_R  g329(.A1(new_n161_), .A2(new_n350_), .B(p0), .Y(new_n351_));
  AO211x2_ASAP7_75t_R  g330(.A1(new_n347_), .A2(new_n132_), .B(new_n349_), .C(new_n351_), .Y(new_n352_));
  AOI21x1_ASAP7_75t_R  g331(.A1(p0), .A2(new_n345_), .B(new_n352_), .Y(new_n353_));
  OR3x1_ASAP7_75t_R    g332(.A(new_n48_), .B(new_n219_), .C(new_n60_), .Y(new_n354_));
  AOI211x1_ASAP7_75t_R g333(.A1(new_n35_), .A2(new_n27_), .B(new_n77_), .C(new_n83_), .Y(new_n355_));
  OAI22x1_ASAP7_75t_R  g334(.A1(new_n198_), .A2(new_n78_), .B1(new_n138_), .B2(new_n207_), .Y(new_n356_));
  AOI21x1_ASAP7_75t_R  g335(.A1(new_n354_), .A2(new_n355_), .B(new_n356_), .Y(new_n357_));
  AO21x1_ASAP7_75t_R   g336(.A1(new_n24_), .A2(p1), .B(new_n225_), .Y(new_n358_));
  AND3x1_ASAP7_75t_R   g337(.A(new_n254_), .B(p2), .C(new_n207_), .Y(new_n359_));
  AOI21x1_ASAP7_75t_R  g338(.A1(new_n177_), .A2(new_n358_), .B(new_n359_), .Y(new_n360_));
  AND3x1_ASAP7_75t_R   g339(.A(new_n54_), .B(new_n43_), .C(p4), .Y(new_n361_));
  OAI21x1_ASAP7_75t_R  g340(.A1(p8), .A2(p1), .B(p9), .Y(new_n362_));
  OAI22x1_ASAP7_75t_R  g341(.A1(new_n120_), .A2(p8), .B1(new_n54_), .B2(new_n362_), .Y(new_n363_));
  AO31x2_ASAP7_75t_R   g342(.A1(p8), .A2(p1), .A3(p4), .B(p7), .Y(new_n364_));
  AND2x2_ASAP7_75t_R   g343(.A(new_n46_), .B(new_n364_), .Y(new_n365_));
  OAI21x1_ASAP7_75t_R  g344(.A1(new_n361_), .A2(new_n363_), .B(new_n365_), .Y(new_n366_));
  NAND3x1_ASAP7_75t_R  g345(.A(new_n357_), .B(new_n360_), .C(new_n366_), .Y(new_n367_));
  AOI21x1_ASAP7_75t_R  g346(.A1(new_n36_), .A2(new_n357_), .B(p5), .Y(new_n368_));
  AOI21x1_ASAP7_75t_R  g347(.A1(new_n367_), .A2(new_n368_), .B(new_n335_), .Y(new_n369_));
  OAI21x1_ASAP7_75t_R  g348(.A1(p4), .A2(new_n353_), .B(new_n369_), .Y(new_n370_));
  NOR2x1_ASAP7_75t_R   g349(.A(p4), .B(p6), .Y(new_n371_));
  AND3x1_ASAP7_75t_R   g350(.A(new_n288_), .B(new_n51_), .C(new_n371_), .Y(new_n372_));
  AOI21x1_ASAP7_75t_R  g351(.A1(new_n336_), .A2(new_n370_), .B(new_n372_), .Y(o7));
  NAND2x1_ASAP7_75t_R  g352(.A(p2), .B(p4), .Y(new_n374_));
  OA211x2_ASAP7_75t_R  g353(.A1(p4), .A2(new_n146_), .B(new_n194_), .C(new_n374_), .Y(new_n375_));
  INVx1_ASAP7_75t_R    g354(.A(new_n95_), .Y(new_n376_));
  AOI211x1_ASAP7_75t_R g355(.A1(new_n83_), .A2(new_n376_), .B(new_n65_), .C(new_n224_), .Y(new_n377_));
  AND3x1_ASAP7_75t_R   g356(.A(new_n121_), .B(p7), .C(new_n55_), .Y(new_n378_));
  OR3x1_ASAP7_75t_R    g357(.A(new_n375_), .B(new_n377_), .C(new_n378_), .Y(new_n379_));
  AND3x1_ASAP7_75t_R   g358(.A(new_n132_), .B(new_n180_), .C(new_n120_), .Y(new_n380_));
  OA21x2_ASAP7_75t_R   g359(.A1(new_n35_), .A2(p4), .B(new_n374_), .Y(new_n381_));
  AOI211x1_ASAP7_75t_R g360(.A1(p2), .A2(new_n224_), .B(new_n36_), .C(new_n381_), .Y(new_n382_));
  OA211x2_ASAP7_75t_R  g361(.A1(new_n380_), .A2(new_n382_), .B(new_n51_), .C(p8), .Y(new_n383_));
  AOI21x1_ASAP7_75t_R  g362(.A1(new_n106_), .A2(new_n379_), .B(new_n383_), .Y(new_n384_));
  AO21x1_ASAP7_75t_R   g363(.A1(new_n36_), .A2(new_n208_), .B(new_n27_), .Y(new_n385_));
  NOR2x1_ASAP7_75t_R   g364(.A(p5), .B(new_n56_), .Y(new_n386_));
  AO21x1_ASAP7_75t_R   g365(.A1(p8), .A2(new_n36_), .B(new_n51_), .Y(new_n387_));
  AO21x1_ASAP7_75t_R   g366(.A1(new_n190_), .A2(new_n146_), .B(new_n387_), .Y(new_n388_));
  AO221x2_ASAP7_75t_R  g367(.A1(new_n385_), .A2(new_n386_), .B1(new_n388_), .B2(new_n35_), .C(new_n141_), .Y(new_n389_));
  INVx1_ASAP7_75t_R    g368(.A(new_n61_), .Y(new_n390_));
  AO221x2_ASAP7_75t_R  g369(.A1(new_n83_), .A2(new_n376_), .B1(new_n232_), .B2(new_n390_), .C(new_n50_), .Y(new_n391_));
  OR3x1_ASAP7_75t_R    g370(.A(new_n101_), .B(new_n35_), .C(p2), .Y(new_n392_));
  AND3x1_ASAP7_75t_R   g371(.A(new_n95_), .B(p1), .C(new_n36_), .Y(new_n393_));
  AND3x1_ASAP7_75t_R   g372(.A(new_n165_), .B(new_n27_), .C(new_n61_), .Y(new_n394_));
  AOI211x1_ASAP7_75t_R g373(.A1(new_n65_), .A2(new_n100_), .B(new_n393_), .C(new_n394_), .Y(new_n395_));
  AO31x2_ASAP7_75t_R   g374(.A1(new_n391_), .A2(new_n392_), .A3(new_n395_), .B(new_n156_), .Y(new_n396_));
  NAND3x1_ASAP7_75t_R  g375(.A(new_n384_), .B(new_n389_), .C(new_n396_), .Y(new_n397_));
  AOI22x1_ASAP7_75t_R  g376(.A1(new_n54_), .A2(new_n177_), .B1(new_n162_), .B2(new_n61_), .Y(new_n398_));
  OR3x1_ASAP7_75t_R    g377(.A(new_n305_), .B(p8), .C(p9), .Y(new_n399_));
  NAND2x1_ASAP7_75t_R  g378(.A(new_n398_), .B(new_n399_), .Y(new_n400_));
  AND3x1_ASAP7_75t_R   g379(.A(new_n100_), .B(new_n27_), .C(new_n98_), .Y(new_n401_));
  AO21x1_ASAP7_75t_R   g380(.A1(new_n36_), .A2(new_n400_), .B(new_n401_), .Y(new_n402_));
  AND3x1_ASAP7_75t_R   g381(.A(new_n37_), .B(new_n282_), .C(new_n371_), .Y(new_n403_));
  AO21x1_ASAP7_75t_R   g382(.A1(new_n176_), .A2(new_n402_), .B(new_n403_), .Y(new_n404_));
  AOI21x1_ASAP7_75t_R  g383(.A1(new_n22_), .A2(new_n397_), .B(new_n404_), .Y(o8));
  OA21x2_ASAP7_75t_R   g384(.A1(new_n262_), .A2(new_n122_), .B(new_n90_), .Y(new_n406_));
  AO21x1_ASAP7_75t_R   g385(.A1(new_n36_), .A2(new_n208_), .B(new_n406_), .Y(new_n407_));
  OR3x1_ASAP7_75t_R    g386(.A(new_n81_), .B(p2), .C(p0), .Y(new_n408_));
  OAI21x1_ASAP7_75t_R  g387(.A1(p4), .A2(new_n206_), .B(p5), .Y(new_n409_));
  AO21x1_ASAP7_75t_R   g388(.A1(new_n27_), .A2(new_n206_), .B(new_n90_), .Y(new_n410_));
  AND5x1_ASAP7_75t_R   g389(.A(new_n407_), .B(new_n244_), .C(new_n408_), .D(new_n409_), .E(new_n410_), .Y(new_n411_));
  AND3x1_ASAP7_75t_R   g390(.A(new_n313_), .B(new_n46_), .C(new_n275_), .Y(new_n412_));
  INVx1_ASAP7_75t_R    g391(.A(new_n282_), .Y(new_n413_));
  AND2x2_ASAP7_75t_R   g392(.A(p2), .B(new_n152_), .Y(new_n414_));
  OAI21x1_ASAP7_75t_R  g393(.A1(new_n318_), .A2(new_n259_), .B(new_n414_), .Y(new_n415_));
  OA211x2_ASAP7_75t_R  g394(.A1(new_n413_), .A2(new_n274_), .B(new_n415_), .C(new_n35_), .Y(new_n416_));
  OAI21x1_ASAP7_75t_R  g395(.A1(new_n412_), .A2(new_n416_), .B(new_n36_), .Y(new_n417_));
  OA21x2_ASAP7_75t_R   g396(.A1(p2), .A2(new_n87_), .B(new_n318_), .Y(new_n418_));
  OR3x1_ASAP7_75t_R    g397(.A(new_n418_), .B(p1), .C(new_n414_), .Y(new_n419_));
  OR3x1_ASAP7_75t_R    g398(.A(new_n259_), .B(p2), .C(new_n155_), .Y(new_n420_));
  OA21x2_ASAP7_75t_R   g399(.A1(new_n275_), .A2(new_n262_), .B(new_n420_), .Y(new_n421_));
  AO21x1_ASAP7_75t_R   g400(.A1(new_n419_), .A2(new_n421_), .B(new_n36_), .Y(new_n422_));
  AND3x1_ASAP7_75t_R   g401(.A(new_n411_), .B(new_n417_), .C(new_n422_), .Y(o9));
  AO21x1_ASAP7_75t_R   g402(.A1(p8), .A2(new_n36_), .B(new_n287_), .Y(new_n424_));
  INVx1_ASAP7_75t_R    g403(.A(new_n424_), .Y(new_n425_));
  AO21x1_ASAP7_75t_R   g404(.A1(p0), .A2(new_n28_), .B(new_n43_), .Y(new_n426_));
  AND3x1_ASAP7_75t_R   g405(.A(new_n48_), .B(new_n22_), .C(new_n274_), .Y(new_n427_));
  AO32x1_ASAP7_75t_R   g406(.A1(new_n425_), .A2(new_n426_), .A3(new_n427_), .B1(new_n403_), .B2(new_n51_), .Y(o10));
endmodule


