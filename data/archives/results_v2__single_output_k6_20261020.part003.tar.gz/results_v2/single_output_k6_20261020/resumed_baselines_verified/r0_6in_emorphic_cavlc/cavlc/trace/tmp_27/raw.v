// Benchmark "/tmp/" written by ABC on Tue Oct 20 17:20:36 2026

module \/tmp/  ( 
    p7, p6, p2, p0, p8, p3, p9, p1, p5, p4,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10  );
  input  p7, p6, p2, p0, p8, p3, p9, p1, p5, p4;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10;
  wire new_n22_, new_n23_, new_n24_, new_n25_, new_n26_, new_n27_, new_n28_,
    new_n29_, new_n30_, new_n31_, new_n32_, new_n33_, new_n34_, new_n35_,
    new_n36_, new_n37_, new_n38_, new_n39_, new_n40_, new_n41_, new_n42_,
    new_n43_, new_n44_, new_n45_, new_n46_, new_n47_, new_n48_, new_n49_,
    new_n50_, new_n51_, new_n52_, new_n53_, new_n54_, new_n55_, new_n56_,
    new_n57_, new_n58_, new_n59_, new_n60_, new_n61_, new_n62_, new_n63_,
    new_n64_, new_n65_, new_n66_, new_n67_, new_n68_, new_n69_, new_n70_,
    new_n71_, new_n72_, new_n73_, new_n74_, new_n75_, new_n76_, new_n77_,
    new_n78_, new_n79_, new_n80_, new_n81_, new_n82_, new_n83_, new_n84_,
    new_n85_, new_n86_, new_n87_, new_n88_, new_n89_, new_n90_, new_n91_,
    new_n92_, new_n93_, new_n94_, new_n95_, new_n96_, new_n97_, new_n98_,
    new_n99_, new_n100_, new_n101_, new_n102_, new_n103_, new_n104_,
    new_n105_, new_n106_, new_n107_, new_n108_, new_n109_, new_n110_,
    new_n111_, new_n112_, new_n113_, new_n114_, new_n115_, new_n117_,
    new_n118_, new_n119_, new_n120_, new_n121_, new_n122_, new_n123_,
    new_n124_, new_n125_, new_n126_, new_n127_, new_n128_, new_n129_,
    new_n130_, new_n131_, new_n132_, new_n133_, new_n134_, new_n135_,
    new_n136_, new_n137_, new_n138_, new_n139_, new_n140_, new_n141_,
    new_n142_, new_n143_, new_n144_, new_n145_, new_n146_, new_n147_,
    new_n148_, new_n149_, new_n150_, new_n151_, new_n152_, new_n153_,
    new_n154_, new_n155_, new_n156_, new_n157_, new_n158_, new_n159_,
    new_n160_, new_n161_, new_n162_, new_n163_, new_n164_, new_n165_,
    new_n166_, new_n167_, new_n168_, new_n169_, new_n170_, new_n171_,
    new_n172_, new_n173_, new_n174_, new_n175_, new_n177_, new_n178_,
    new_n179_, new_n180_, new_n181_, new_n182_, new_n183_, new_n184_,
    new_n185_, new_n186_, new_n187_, new_n188_, new_n189_, new_n190_,
    new_n191_, new_n192_, new_n193_, new_n194_, new_n195_, new_n196_,
    new_n197_, new_n198_, new_n199_, new_n200_, new_n201_, new_n202_,
    new_n203_, new_n204_, new_n205_, new_n206_, new_n207_, new_n208_,
    new_n209_, new_n210_, new_n211_, new_n212_, new_n213_, new_n214_,
    new_n215_, new_n216_, new_n217_, new_n218_, new_n219_, new_n220_,
    new_n221_, new_n222_, new_n223_, new_n224_, new_n225_, new_n226_,
    new_n227_, new_n228_, new_n229_, new_n230_, new_n231_, new_n232_,
    new_n233_, new_n235_, new_n236_, new_n237_, new_n238_, new_n239_,
    new_n240_, new_n241_, new_n242_, new_n243_, new_n244_, new_n245_,
    new_n246_, new_n247_, new_n248_, new_n249_, new_n250_, new_n251_,
    new_n252_, new_n253_, new_n254_, new_n255_, new_n256_, new_n257_,
    new_n258_, new_n259_, new_n260_, new_n261_, new_n262_, new_n263_,
    new_n264_, new_n265_, new_n266_, new_n267_, new_n268_, new_n269_,
    new_n271_, new_n272_, new_n273_, new_n274_, new_n275_, new_n276_,
    new_n277_, new_n279_, new_n280_, new_n282_, new_n283_, new_n284_,
    new_n285_, new_n286_, new_n287_, new_n288_, new_n289_, new_n290_,
    new_n291_, new_n292_, new_n293_, new_n294_, new_n295_, new_n296_,
    new_n297_, new_n298_, new_n299_, new_n300_, new_n301_, new_n302_,
    new_n303_, new_n304_, new_n305_, new_n306_, new_n307_, new_n308_,
    new_n309_, new_n310_, new_n311_, new_n312_, new_n313_, new_n314_,
    new_n316_, new_n317_, new_n318_, new_n319_, new_n320_, new_n321_,
    new_n322_, new_n323_, new_n324_, new_n325_, new_n326_, new_n327_,
    new_n328_, new_n329_, new_n330_, new_n331_, new_n332_, new_n333_,
    new_n334_, new_n335_, new_n336_, new_n337_, new_n338_, new_n339_,
    new_n340_, new_n341_, new_n342_, new_n343_, new_n344_, new_n345_,
    new_n346_, new_n347_, new_n348_, new_n349_, new_n350_, new_n351_,
    new_n352_, new_n353_, new_n354_, new_n355_, new_n356_, new_n357_,
    new_n358_, new_n359_, new_n361_, new_n362_, new_n363_, new_n364_,
    new_n365_, new_n366_, new_n367_, new_n368_, new_n369_, new_n370_,
    new_n371_, new_n372_, new_n373_, new_n374_, new_n375_, new_n376_,
    new_n377_, new_n378_, new_n379_, new_n380_, new_n381_, new_n382_,
    new_n383_, new_n384_, new_n385_, new_n386_, new_n387_, new_n388_,
    new_n389_, new_n390_, new_n391_, new_n393_, new_n394_, new_n395_,
    new_n396_, new_n397_, new_n398_, new_n399_, new_n400_, new_n401_,
    new_n402_, new_n403_, new_n404_, new_n405_, new_n406_, new_n407_,
    new_n408_, new_n409_, new_n411_, new_n412_;
  INVx1_ASAP7_75t_R    g000(.A(p4), .Y(new_n22_));
  OR3x1_ASAP7_75t_R    g001(.A(p0), .B(p9), .C(p1), .Y(new_n23_));
  NOR2x1_ASAP7_75t_R   g002(.A(p8), .B(p4), .Y(new_n24_));
  NAND2x1_ASAP7_75t_R  g003(.A(p7), .B(p5), .Y(new_n25_));
  AOI211x1_ASAP7_75t_R g004(.A1(new_n22_), .A2(new_n23_), .B(new_n24_), .C(new_n25_), .Y(new_n26_));
  INVx1_ASAP7_75t_R    g005(.A(p8), .Y(new_n27_));
  NAND2x1_ASAP7_75t_R  g006(.A(p9), .B(new_n27_), .Y(new_n28_));
  INVx1_ASAP7_75t_R    g007(.A(p9), .Y(new_n29_));
  NAND2x1_ASAP7_75t_R  g008(.A(p8), .B(new_n29_), .Y(new_n30_));
  AND2x2_ASAP7_75t_R   g009(.A(p1), .B(p4), .Y(new_n31_));
  AND5x1_ASAP7_75t_R   g010(.A(p7), .B(new_n28_), .C(new_n30_), .D(p0), .E(new_n31_), .Y(new_n32_));
  NOR2x1_ASAP7_75t_R   g011(.A(new_n26_), .B(new_n32_), .Y(new_n33_));
  INVx1_ASAP7_75t_R    g012(.A(p1), .Y(new_n34_));
  NOR2x1_ASAP7_75t_R   g013(.A(p0), .B(new_n34_), .Y(new_n35_));
  INVx1_ASAP7_75t_R    g014(.A(p0), .Y(new_n36_));
  NOR2x1_ASAP7_75t_R   g015(.A(p7), .B(new_n36_), .Y(new_n37_));
  OA21x2_ASAP7_75t_R   g016(.A1(new_n35_), .A2(new_n37_), .B(new_n22_), .Y(new_n38_));
  AO21x1_ASAP7_75t_R   g017(.A1(p9), .A2(new_n27_), .B(p0), .Y(new_n39_));
  NOR2x1_ASAP7_75t_R   g018(.A(p9), .B(new_n27_), .Y(new_n40_));
  NOR2x1_ASAP7_75t_R   g019(.A(p7), .B(p4), .Y(new_n41_));
  AOI22x1_ASAP7_75t_R  g020(.A1(new_n38_), .A2(new_n39_), .B1(new_n40_), .B2(new_n41_), .Y(new_n42_));
  INVx1_ASAP7_75t_R    g021(.A(p2), .Y(new_n43_));
  AOI21x1_ASAP7_75t_R  g022(.A1(new_n33_), .A2(new_n42_), .B(new_n43_), .Y(new_n44_));
  NAND2x1_ASAP7_75t_R  g023(.A(p0), .B(new_n43_), .Y(new_n45_));
  OA211x2_ASAP7_75t_R  g024(.A1(new_n45_), .A2(new_n40_), .B(new_n28_), .C(new_n34_), .Y(new_n46_));
  INVx1_ASAP7_75t_R    g025(.A(p5), .Y(new_n47_));
  AO21x1_ASAP7_75t_R   g026(.A1(p9), .A2(new_n27_), .B(p1), .Y(new_n48_));
  AND2x2_ASAP7_75t_R   g027(.A(new_n47_), .B(new_n48_), .Y(new_n49_));
  NAND2x1_ASAP7_75t_R  g028(.A(p7), .B(p4), .Y(new_n50_));
  OR3x1_ASAP7_75t_R    g029(.A(new_n46_), .B(new_n49_), .C(new_n50_), .Y(new_n51_));
  NOR2x1_ASAP7_75t_R   g030(.A(p8), .B(p1), .Y(new_n52_));
  AND2x2_ASAP7_75t_R   g031(.A(p8), .B(p1), .Y(new_n53_));
  AO21x1_ASAP7_75t_R   g032(.A1(p0), .A2(new_n52_), .B(new_n53_), .Y(new_n54_));
  NAND2x1_ASAP7_75t_R  g033(.A(new_n43_), .B(new_n29_), .Y(new_n55_));
  NOR2x1_ASAP7_75t_R   g034(.A(new_n25_), .B(new_n55_), .Y(new_n56_));
  NOR2x1_ASAP7_75t_R   g035(.A(p2), .B(p0), .Y(new_n57_));
  AO21x1_ASAP7_75t_R   g036(.A1(new_n53_), .A2(new_n57_), .B(new_n37_), .Y(new_n58_));
  NOR2x1_ASAP7_75t_R   g037(.A(p9), .B(p4), .Y(new_n59_));
  NOR2x1_ASAP7_75t_R   g038(.A(p9), .B(p1), .Y(new_n60_));
  NOR2x1_ASAP7_75t_R   g039(.A(p7), .B(p8), .Y(new_n61_));
  AND3x1_ASAP7_75t_R   g040(.A(new_n60_), .B(new_n57_), .C(new_n61_), .Y(new_n62_));
  AOI221x1_ASAP7_75t_R g041(.A1(new_n54_), .A2(new_n56_), .B1(new_n58_), .B2(new_n59_), .C(new_n62_), .Y(new_n63_));
  NAND2x1_ASAP7_75t_R  g042(.A(p2), .B(new_n47_), .Y(new_n64_));
  NOR2x1_ASAP7_75t_R   g043(.A(p0), .B(p8), .Y(new_n65_));
  OA211x2_ASAP7_75t_R  g044(.A1(new_n43_), .A2(new_n34_), .B(new_n64_), .C(new_n65_), .Y(new_n66_));
  OAI21x1_ASAP7_75t_R  g045(.A1(new_n53_), .A2(new_n66_), .B(new_n41_), .Y(new_n67_));
  NAND3x1_ASAP7_75t_R  g046(.A(new_n51_), .B(new_n63_), .C(new_n67_), .Y(new_n68_));
  NOR2x1_ASAP7_75t_R   g047(.A(p6), .B(p3), .Y(new_n69_));
  OAI21x1_ASAP7_75t_R  g048(.A1(new_n44_), .A2(new_n68_), .B(new_n69_), .Y(new_n70_));
  AND2x2_ASAP7_75t_R   g049(.A(p0), .B(p1), .Y(new_n71_));
  INVx1_ASAP7_75t_R    g050(.A(new_n71_), .Y(new_n72_));
  AO21x1_ASAP7_75t_R   g051(.A1(new_n34_), .A2(new_n22_), .B(p9), .Y(new_n73_));
  AO21x1_ASAP7_75t_R   g052(.A1(new_n72_), .A2(new_n73_), .B(p8), .Y(new_n74_));
  NAND3x1_ASAP7_75t_R  g053(.A(new_n36_), .B(p2), .C(p9), .Y(new_n75_));
  NAND2x1_ASAP7_75t_R  g054(.A(new_n43_), .B(new_n34_), .Y(new_n76_));
  NOR2x1_ASAP7_75t_R   g055(.A(p0), .B(new_n27_), .Y(new_n77_));
  AOI22x1_ASAP7_75t_R  g056(.A1(new_n76_), .A2(new_n77_), .B1(new_n43_), .B2(p0), .Y(new_n78_));
  AND2x2_ASAP7_75t_R   g057(.A(new_n75_), .B(new_n78_), .Y(new_n79_));
  INVx1_ASAP7_75t_R    g058(.A(p7), .Y(new_n80_));
  INVx1_ASAP7_75t_R    g059(.A(p6), .Y(new_n81_));
  NAND2x1_ASAP7_75t_R  g060(.A(new_n80_), .B(new_n81_), .Y(new_n82_));
  AO21x1_ASAP7_75t_R   g061(.A1(new_n74_), .A2(new_n79_), .B(new_n82_), .Y(new_n83_));
  NOR2x1_ASAP7_75t_R   g062(.A(p4), .B(new_n80_), .Y(new_n84_));
  OA211x2_ASAP7_75t_R  g063(.A1(new_n81_), .A2(new_n24_), .B(new_n34_), .C(p9), .Y(new_n85_));
  NAND2x1_ASAP7_75t_R  g064(.A(p0), .B(new_n27_), .Y(new_n86_));
  OA21x2_ASAP7_75t_R   g065(.A1(p6), .A2(new_n86_), .B(new_n43_), .Y(new_n87_));
  OA21x2_ASAP7_75t_R   g066(.A1(new_n84_), .A2(new_n85_), .B(new_n87_), .Y(new_n88_));
  NOR2x1_ASAP7_75t_R   g067(.A(p0), .B(p9), .Y(new_n89_));
  NOR2x1_ASAP7_75t_R   g068(.A(p8), .B(new_n34_), .Y(new_n90_));
  NAND2x1_ASAP7_75t_R  g069(.A(p9), .B(new_n34_), .Y(new_n91_));
  NOR2x1_ASAP7_75t_R   g070(.A(p0), .B(new_n22_), .Y(new_n92_));
  NOR2x1_ASAP7_75t_R   g071(.A(new_n91_), .B(new_n92_), .Y(new_n93_));
  INVx1_ASAP7_75t_R    g072(.A(new_n77_), .Y(new_n94_));
  AO32x1_ASAP7_75t_R   g073(.A1(p6), .A2(new_n89_), .A3(new_n90_), .B1(new_n93_), .B2(new_n94_), .Y(new_n95_));
  NOR2x1_ASAP7_75t_R   g074(.A(p2), .B(p4), .Y(new_n96_));
  INVx1_ASAP7_75t_R    g075(.A(new_n96_), .Y(new_n97_));
  AND2x2_ASAP7_75t_R   g076(.A(p0), .B(p9), .Y(new_n98_));
  OAI22x1_ASAP7_75t_R  g077(.A1(new_n97_), .A2(new_n98_), .B1(p6), .B2(new_n89_), .Y(new_n99_));
  NAND2x1_ASAP7_75t_R  g078(.A(new_n80_), .B(new_n34_), .Y(new_n100_));
  XOR2x2_ASAP7_75t_R   g079(.A(p0), .B(p8), .Y(new_n101_));
  NOR2x1_ASAP7_75t_R   g080(.A(new_n100_), .B(new_n101_), .Y(new_n102_));
  AOI22x1_ASAP7_75t_R  g081(.A1(new_n88_), .A2(new_n95_), .B1(new_n99_), .B2(new_n102_), .Y(new_n103_));
  INVx1_ASAP7_75t_R    g082(.A(p3), .Y(new_n104_));
  NAND2x1_ASAP7_75t_R  g083(.A(new_n104_), .B(new_n47_), .Y(new_n105_));
  AO21x1_ASAP7_75t_R   g084(.A1(new_n83_), .A2(new_n103_), .B(new_n105_), .Y(new_n106_));
  AND3x1_ASAP7_75t_R   g085(.A(new_n60_), .B(new_n57_), .C(new_n81_), .Y(new_n107_));
  NOR2x1_ASAP7_75t_R   g086(.A(p8), .B(p5), .Y(new_n108_));
  AO21x1_ASAP7_75t_R   g087(.A1(p7), .A2(p3), .B(new_n108_), .Y(new_n109_));
  NAND2x1_ASAP7_75t_R  g088(.A(p7), .B(new_n47_), .Y(new_n110_));
  INVx1_ASAP7_75t_R    g089(.A(new_n108_), .Y(new_n111_));
  NAND2x1_ASAP7_75t_R  g090(.A(p5), .B(p4), .Y(new_n112_));
  OA211x2_ASAP7_75t_R  g091(.A1(new_n27_), .A2(p3), .B(new_n111_), .C(new_n112_), .Y(new_n113_));
  AO32x1_ASAP7_75t_R   g092(.A1(p4), .A2(new_n109_), .A3(new_n110_), .B1(new_n113_), .B2(new_n80_), .Y(new_n114_));
  NAND2x1_ASAP7_75t_R  g093(.A(new_n107_), .B(new_n114_), .Y(new_n115_));
  NAND3x1_ASAP7_75t_R  g094(.A(new_n70_), .B(new_n106_), .C(new_n115_), .Y(o0));
  OAI21x1_ASAP7_75t_R  g095(.A1(p7), .A2(p2), .B(p9), .Y(new_n117_));
  NOR2x1_ASAP7_75t_R   g096(.A(p7), .B(p1), .Y(new_n118_));
  NAND2x1_ASAP7_75t_R  g097(.A(p4), .B(new_n118_), .Y(new_n119_));
  OAI21x1_ASAP7_75t_R  g098(.A1(new_n84_), .A2(new_n117_), .B(new_n119_), .Y(new_n120_));
  AND2x2_ASAP7_75t_R   g099(.A(p7), .B(p9), .Y(new_n121_));
  AO21x1_ASAP7_75t_R   g100(.A1(p7), .A2(p2), .B(p1), .Y(new_n122_));
  AO32x1_ASAP7_75t_R   g101(.A1(new_n121_), .A2(p0), .A3(new_n34_), .B1(new_n122_), .B2(new_n29_), .Y(new_n123_));
  NOR2x1_ASAP7_75t_R   g102(.A(p9), .B(new_n22_), .Y(new_n124_));
  NOR2x1_ASAP7_75t_R   g103(.A(p4), .B(new_n29_), .Y(new_n125_));
  OA21x2_ASAP7_75t_R   g104(.A1(new_n124_), .A2(new_n125_), .B(p0), .Y(new_n126_));
  AOI211x1_ASAP7_75t_R g105(.A1(new_n36_), .A2(new_n120_), .B(new_n123_), .C(new_n126_), .Y(new_n127_));
  NOR2x1_ASAP7_75t_R   g106(.A(p0), .B(p5), .Y(new_n128_));
  AOI211x1_ASAP7_75t_R g107(.A1(new_n91_), .A2(new_n100_), .B(new_n98_), .C(new_n128_), .Y(new_n129_));
  NAND2x1_ASAP7_75t_R  g108(.A(p2), .B(new_n22_), .Y(new_n130_));
  INVx1_ASAP7_75t_R    g109(.A(new_n130_), .Y(new_n131_));
  NOR2x1_ASAP7_75t_R   g110(.A(p0), .B(new_n80_), .Y(new_n132_));
  NAND2x1_ASAP7_75t_R  g111(.A(new_n80_), .B(new_n36_), .Y(new_n133_));
  AO22x1_ASAP7_75t_R   g112(.A1(p5), .A2(new_n132_), .B1(new_n34_), .B2(new_n133_), .Y(new_n134_));
  AOI221x1_ASAP7_75t_R g113(.A1(new_n129_), .A2(new_n22_), .B1(new_n131_), .B2(new_n134_), .C(p8), .Y(new_n135_));
  OAI21x1_ASAP7_75t_R  g114(.A1(p5), .A2(new_n127_), .B(new_n135_), .Y(new_n136_));
  NOR2x1_ASAP7_75t_R   g115(.A(p0), .B(new_n43_), .Y(new_n137_));
  AOI22x1_ASAP7_75t_R  g116(.A1(new_n137_), .A2(new_n118_), .B1(p0), .B2(p4), .Y(new_n138_));
  OR3x1_ASAP7_75t_R    g117(.A(new_n138_), .B(new_n29_), .C(new_n47_), .Y(new_n139_));
  AND3x1_ASAP7_75t_R   g118(.A(new_n71_), .B(new_n80_), .C(p4), .Y(new_n140_));
  AO21x1_ASAP7_75t_R   g119(.A1(p1), .A2(p4), .B(p2), .Y(new_n141_));
  OA211x2_ASAP7_75t_R  g120(.A1(p4), .A2(new_n71_), .B(new_n141_), .C(p5), .Y(new_n142_));
  AOI211x1_ASAP7_75t_R g121(.A1(p2), .A2(new_n140_), .B(new_n27_), .C(new_n142_), .Y(new_n143_));
  AOI21x1_ASAP7_75t_R  g122(.A1(new_n139_), .A2(new_n143_), .B(p3), .Y(new_n144_));
  AO21x1_ASAP7_75t_R   g123(.A1(p5), .A2(new_n29_), .B(p1), .Y(new_n145_));
  NOR2x1_ASAP7_75t_R   g124(.A(p7), .B(p5), .Y(new_n146_));
  AO21x1_ASAP7_75t_R   g125(.A1(new_n84_), .A2(new_n145_), .B(new_n146_), .Y(new_n147_));
  NOR2x1_ASAP7_75t_R   g126(.A(p8), .B(new_n36_), .Y(new_n148_));
  NAND3x1_ASAP7_75t_R  g127(.A(new_n25_), .B(p9), .C(new_n34_), .Y(new_n149_));
  AOI22x1_ASAP7_75t_R  g128(.A1(new_n22_), .A2(p7), .B1(p8), .B2(p5), .Y(new_n150_));
  OAI22x1_ASAP7_75t_R  g129(.A1(new_n149_), .A2(new_n150_), .B1(new_n30_), .B2(new_n119_), .Y(new_n151_));
  AOI22x1_ASAP7_75t_R  g130(.A1(new_n147_), .A2(new_n148_), .B1(new_n151_), .B2(p0), .Y(new_n152_));
  AND2x2_ASAP7_75t_R   g131(.A(p7), .B(p1), .Y(new_n153_));
  AOI21x1_ASAP7_75t_R  g132(.A1(p8), .A2(p5), .B(new_n41_), .Y(new_n154_));
  NOR2x1_ASAP7_75t_R   g133(.A(p7), .B(new_n27_), .Y(new_n155_));
  OAI22x1_ASAP7_75t_R  g134(.A1(new_n154_), .A2(new_n155_), .B1(p9), .B2(new_n150_), .Y(new_n156_));
  NAND2x1_ASAP7_75t_R  g135(.A(new_n60_), .B(new_n61_), .Y(new_n157_));
  NAND2x1_ASAP7_75t_R  g136(.A(new_n53_), .B(new_n121_), .Y(new_n158_));
  NAND2x1_ASAP7_75t_R  g137(.A(p4), .B(new_n36_), .Y(new_n159_));
  AOI21x1_ASAP7_75t_R  g138(.A1(new_n157_), .A2(new_n158_), .B(new_n159_), .Y(new_n160_));
  AOI221x1_ASAP7_75t_R g139(.A1(new_n108_), .A2(new_n153_), .B1(new_n156_), .B2(new_n35_), .C(new_n160_), .Y(new_n161_));
  AOI21x1_ASAP7_75t_R  g140(.A1(new_n152_), .A2(new_n161_), .B(p3), .Y(new_n162_));
  OR3x1_ASAP7_75t_R    g141(.A(new_n27_), .B(new_n104_), .C(new_n47_), .Y(new_n163_));
  NAND2x1_ASAP7_75t_R  g142(.A(p7), .B(p3), .Y(new_n164_));
  NAND2x1_ASAP7_75t_R  g143(.A(p4), .B(new_n80_), .Y(new_n165_));
  AO21x1_ASAP7_75t_R   g144(.A1(new_n164_), .A2(new_n165_), .B(new_n111_), .Y(new_n166_));
  AOI211x1_ASAP7_75t_R g145(.A1(new_n163_), .A2(new_n166_), .B(p2), .C(new_n23_), .Y(new_n167_));
  AOI221x1_ASAP7_75t_R g146(.A1(new_n136_), .A2(new_n144_), .B1(new_n162_), .B2(new_n43_), .C(new_n167_), .Y(new_n168_));
  NOR2x1_ASAP7_75t_R   g147(.A(p1), .B(new_n80_), .Y(new_n169_));
  AO32x1_ASAP7_75t_R   g148(.A1(new_n148_), .A2(new_n169_), .A3(p6), .B1(new_n89_), .B2(new_n90_), .Y(new_n170_));
  NOR2x1_ASAP7_75t_R   g149(.A(p7), .B(p9), .Y(new_n171_));
  OA211x2_ASAP7_75t_R  g150(.A1(new_n118_), .A2(new_n171_), .B(new_n72_), .C(p6), .Y(new_n172_));
  OA21x2_ASAP7_75t_R   g151(.A1(new_n98_), .A2(new_n48_), .B(new_n172_), .Y(new_n173_));
  AND3x1_ASAP7_75t_R   g152(.A(new_n96_), .B(new_n104_), .C(new_n47_), .Y(new_n174_));
  OAI21x1_ASAP7_75t_R  g153(.A1(new_n170_), .A2(new_n173_), .B(new_n174_), .Y(new_n175_));
  OAI21x1_ASAP7_75t_R  g154(.A1(p6), .A2(new_n168_), .B(new_n175_), .Y(o1));
  NOR2x1_ASAP7_75t_R   g155(.A(p7), .B(p2), .Y(new_n177_));
  NAND2x1_ASAP7_75t_R  g156(.A(new_n177_), .B(new_n86_), .Y(new_n178_));
  AO21x1_ASAP7_75t_R   g157(.A1(new_n47_), .A2(new_n86_), .B(new_n80_), .Y(new_n179_));
  AO21x1_ASAP7_75t_R   g158(.A1(p8), .A2(new_n36_), .B(p1), .Y(new_n180_));
  AO21x1_ASAP7_75t_R   g159(.A1(new_n178_), .A2(new_n179_), .B(new_n180_), .Y(new_n181_));
  NAND2x1_ASAP7_75t_R  g160(.A(p1), .B(new_n61_), .Y(new_n182_));
  AO21x1_ASAP7_75t_R   g161(.A1(p1), .A2(new_n27_), .B(new_n80_), .Y(new_n183_));
  AO21x1_ASAP7_75t_R   g162(.A1(new_n182_), .A2(new_n183_), .B(new_n43_), .Y(new_n184_));
  OR3x1_ASAP7_75t_R    g163(.A(new_n80_), .B(new_n47_), .C(p0), .Y(new_n185_));
  AND2x2_ASAP7_75t_R   g164(.A(p0), .B(p5), .Y(new_n186_));
  NAND2x1_ASAP7_75t_R  g165(.A(new_n53_), .B(new_n186_), .Y(new_n187_));
  AO21x1_ASAP7_75t_R   g166(.A1(new_n185_), .A2(new_n187_), .B(new_n43_), .Y(new_n188_));
  INVx1_ASAP7_75t_R    g167(.A(new_n125_), .Y(new_n189_));
  AO31x2_ASAP7_75t_R   g168(.A1(new_n181_), .A2(new_n184_), .A3(new_n188_), .B(new_n189_), .Y(new_n190_));
  OA211x2_ASAP7_75t_R  g169(.A1(new_n22_), .A2(new_n137_), .B(new_n34_), .C(new_n61_), .Y(new_n191_));
  AND3x1_ASAP7_75t_R   g170(.A(new_n76_), .B(new_n77_), .C(new_n121_), .Y(new_n192_));
  AOI21x1_ASAP7_75t_R  g171(.A1(p9), .A2(new_n191_), .B(new_n192_), .Y(new_n193_));
  NAND2x1_ASAP7_75t_R  g172(.A(p8), .B(p1), .Y(new_n194_));
  AND2x2_ASAP7_75t_R   g173(.A(p7), .B(p8), .Y(new_n195_));
  NAND2x1_ASAP7_75t_R  g174(.A(p9), .B(new_n195_), .Y(new_n196_));
  NOR2x1_ASAP7_75t_R   g175(.A(new_n22_), .B(new_n61_), .Y(new_n197_));
  AO221x2_ASAP7_75t_R  g176(.A1(new_n22_), .A2(new_n194_), .B1(new_n196_), .B2(new_n197_), .C(new_n45_), .Y(new_n198_));
  XOR2x2_ASAP7_75t_R   g177(.A(p7), .B(p8), .Y(new_n199_));
  NOR2x1_ASAP7_75t_R   g178(.A(p2), .B(new_n34_), .Y(new_n200_));
  OAI21x1_ASAP7_75t_R  g179(.A1(new_n65_), .A2(new_n199_), .B(new_n200_), .Y(new_n201_));
  AO31x2_ASAP7_75t_R   g180(.A1(new_n193_), .A2(new_n198_), .A3(new_n201_), .B(p5), .Y(new_n202_));
  AO21x1_ASAP7_75t_R   g181(.A1(new_n190_), .A2(new_n202_), .B(p3), .Y(new_n203_));
  NAND2x1_ASAP7_75t_R  g182(.A(p5), .B(new_n80_), .Y(new_n204_));
  INVx1_ASAP7_75t_R    g183(.A(new_n204_), .Y(new_n205_));
  OA21x2_ASAP7_75t_R   g184(.A1(new_n195_), .A2(new_n205_), .B(new_n22_), .Y(new_n206_));
  AO21x1_ASAP7_75t_R   g185(.A1(new_n34_), .A2(new_n57_), .B(new_n104_), .Y(new_n207_));
  NAND2x1_ASAP7_75t_R  g186(.A(new_n29_), .B(new_n207_), .Y(new_n208_));
  AO21x1_ASAP7_75t_R   g187(.A1(p3), .A2(new_n206_), .B(new_n208_), .Y(new_n209_));
  NOR2x1_ASAP7_75t_R   g188(.A(p7), .B(new_n43_), .Y(new_n210_));
  NOR2x1_ASAP7_75t_R   g189(.A(p1), .B(new_n43_), .Y(new_n211_));
  AOI21x1_ASAP7_75t_R  g190(.A1(new_n77_), .A2(new_n210_), .B(new_n211_), .Y(new_n212_));
  AND3x1_ASAP7_75t_R   g191(.A(new_n27_), .B(p7), .C(p0), .Y(new_n213_));
  OR3x1_ASAP7_75t_R    g192(.A(new_n212_), .B(new_n108_), .C(new_n213_), .Y(new_n214_));
  AO21x1_ASAP7_75t_R   g193(.A1(p2), .A2(new_n27_), .B(p5), .Y(new_n215_));
  NOR2x1_ASAP7_75t_R   g194(.A(new_n148_), .B(new_n210_), .Y(new_n216_));
  OA21x2_ASAP7_75t_R   g195(.A1(new_n215_), .A2(new_n216_), .B(new_n104_), .Y(new_n217_));
  NAND2x1_ASAP7_75t_R  g196(.A(p2), .B(new_n34_), .Y(new_n218_));
  AO21x1_ASAP7_75t_R   g197(.A1(p7), .A2(new_n218_), .B(p4), .Y(new_n219_));
  NAND2x1_ASAP7_75t_R  g198(.A(p2), .B(p4), .Y(new_n220_));
  OA21x2_ASAP7_75t_R   g199(.A1(new_n220_), .A2(new_n169_), .B(new_n148_), .Y(new_n221_));
  NAND2x1_ASAP7_75t_R  g200(.A(new_n219_), .B(new_n221_), .Y(new_n222_));
  AO21x1_ASAP7_75t_R   g201(.A1(new_n31_), .A2(new_n110_), .B(new_n92_), .Y(new_n223_));
  NAND2x1_ASAP7_75t_R  g202(.A(new_n122_), .B(new_n223_), .Y(new_n224_));
  OR4x2_ASAP7_75t_R    g203(.A(new_n101_), .B(p2), .C(new_n92_), .D(new_n204_), .Y(new_n225_));
  AND5x1_ASAP7_75t_R   g204(.A(new_n214_), .B(new_n217_), .C(new_n222_), .D(new_n224_), .E(new_n225_), .Y(new_n226_));
  OR3x1_ASAP7_75t_R    g205(.A(new_n28_), .B(p7), .C(p0), .Y(new_n227_));
  AO21x1_ASAP7_75t_R   g206(.A1(p6), .A2(new_n195_), .B(new_n29_), .Y(new_n228_));
  OAI21x1_ASAP7_75t_R  g207(.A1(new_n148_), .A2(new_n98_), .B(new_n228_), .Y(new_n229_));
  OR3x1_ASAP7_75t_R    g208(.A(p2), .B(p5), .C(p4), .Y(new_n230_));
  OR3x1_ASAP7_75t_R    g209(.A(new_n230_), .B(p3), .C(p1), .Y(new_n231_));
  AO21x1_ASAP7_75t_R   g210(.A1(new_n227_), .A2(new_n229_), .B(new_n231_), .Y(new_n232_));
  OA31x2_ASAP7_75t_R   g211(.A1(p6), .A2(new_n209_), .A3(new_n226_), .B1(new_n232_), .Y(new_n233_));
  OAI21x1_ASAP7_75t_R  g212(.A1(p6), .A2(new_n203_), .B(new_n233_), .Y(o2));
  NOR2x1_ASAP7_75t_R   g213(.A(p1), .B(new_n22_), .Y(new_n235_));
  AO21x1_ASAP7_75t_R   g214(.A1(new_n235_), .A2(new_n199_), .B(new_n211_), .Y(new_n236_));
  AO21x1_ASAP7_75t_R   g215(.A1(p7), .A2(new_n22_), .B(new_n177_), .Y(new_n237_));
  OA21x2_ASAP7_75t_R   g216(.A1(p5), .A2(new_n210_), .B(new_n130_), .Y(new_n238_));
  AO21x1_ASAP7_75t_R   g217(.A1(new_n90_), .A2(new_n237_), .B(new_n238_), .Y(new_n239_));
  OAI21x1_ASAP7_75t_R  g218(.A1(new_n236_), .A2(new_n239_), .B(new_n98_), .Y(new_n240_));
  AO21x1_ASAP7_75t_R   g219(.A1(p8), .A2(p4), .B(p5), .Y(new_n241_));
  INVx1_ASAP7_75t_R    g220(.A(new_n241_), .Y(new_n242_));
  NAND2x1_ASAP7_75t_R  g221(.A(p0), .B(p8), .Y(new_n243_));
  AOI21x1_ASAP7_75t_R  g222(.A1(new_n243_), .A2(new_n50_), .B(new_n43_), .Y(new_n244_));
  NOR2x1_ASAP7_75t_R   g223(.A(p4), .B(new_n47_), .Y(new_n245_));
  AND3x1_ASAP7_75t_R   g224(.A(new_n245_), .B(new_n36_), .C(new_n61_), .Y(new_n246_));
  OA21x2_ASAP7_75t_R   g225(.A1(new_n24_), .A2(new_n146_), .B(new_n211_), .Y(new_n247_));
  AO21x1_ASAP7_75t_R   g226(.A1(new_n213_), .A2(new_n245_), .B(new_n247_), .Y(new_n248_));
  AOI211x1_ASAP7_75t_R g227(.A1(new_n242_), .A2(new_n244_), .B(new_n246_), .C(new_n248_), .Y(new_n249_));
  INVx1_ASAP7_75t_R    g228(.A(new_n28_), .Y(new_n250_));
  AO32x1_ASAP7_75t_R   g229(.A1(new_n118_), .A2(new_n128_), .A3(p4), .B1(p5), .B2(new_n96_), .Y(new_n251_));
  AND2x2_ASAP7_75t_R   g230(.A(p2), .B(p1), .Y(new_n252_));
  AO22x1_ASAP7_75t_R   g231(.A1(new_n47_), .A2(new_n252_), .B1(new_n245_), .B2(new_n76_), .Y(new_n253_));
  NOR2x1_ASAP7_75t_R   g232(.A(new_n64_), .B(new_n133_), .Y(new_n254_));
  AOI221x1_ASAP7_75t_R g233(.A1(new_n250_), .A2(new_n251_), .B1(new_n253_), .B2(new_n77_), .C(new_n254_), .Y(new_n255_));
  AO31x2_ASAP7_75t_R   g234(.A1(new_n240_), .A2(new_n249_), .A3(new_n255_), .B(p3), .Y(new_n256_));
  NOR2x1_ASAP7_75t_R   g235(.A(p5), .B(p4), .Y(new_n257_));
  INVx1_ASAP7_75t_R    g236(.A(new_n257_), .Y(new_n258_));
  NAND2x1_ASAP7_75t_R  g237(.A(new_n112_), .B(new_n258_), .Y(new_n259_));
  AO21x1_ASAP7_75t_R   g238(.A1(p7), .A2(p8), .B(p4), .Y(new_n260_));
  AND5x1_ASAP7_75t_R   g239(.A(p3), .B(new_n259_), .C(new_n34_), .D(new_n57_), .E(new_n260_), .Y(new_n261_));
  OA22x2_ASAP7_75t_R   g240(.A1(new_n90_), .A2(new_n31_), .B1(new_n80_), .B2(p8), .Y(new_n262_));
  OR3x1_ASAP7_75t_R    g241(.A(new_n262_), .B(p2), .C(p5), .Y(new_n263_));
  OAI21x1_ASAP7_75t_R  g242(.A1(new_n57_), .A2(new_n77_), .B(new_n47_), .Y(new_n264_));
  OR3x1_ASAP7_75t_R    g243(.A(new_n37_), .B(p2), .C(p1), .Y(new_n265_));
  NAND2x1_ASAP7_75t_R  g244(.A(p0), .B(p4), .Y(new_n266_));
  AO21x1_ASAP7_75t_R   g245(.A1(p7), .A2(new_n47_), .B(new_n266_), .Y(new_n267_));
  AND5x1_ASAP7_75t_R   g246(.A(new_n263_), .B(new_n104_), .C(new_n264_), .D(new_n265_), .E(new_n267_), .Y(new_n268_));
  OAI21x1_ASAP7_75t_R  g247(.A1(new_n261_), .A2(new_n268_), .B(new_n29_), .Y(new_n269_));
  AOI21x1_ASAP7_75t_R  g248(.A1(new_n256_), .A2(new_n269_), .B(p6), .Y(o3));
  OR3x1_ASAP7_75t_R    g249(.A(new_n89_), .B(p3), .C(new_n34_), .Y(new_n271_));
  NAND2x1_ASAP7_75t_R  g250(.A(p2), .B(new_n104_), .Y(new_n272_));
  NOR2x1_ASAP7_75t_R   g251(.A(p2), .B(new_n104_), .Y(new_n273_));
  INVx1_ASAP7_75t_R    g252(.A(new_n273_), .Y(new_n274_));
  AO21x1_ASAP7_75t_R   g253(.A1(new_n272_), .A2(new_n274_), .B(new_n23_), .Y(new_n275_));
  NOR2x1_ASAP7_75t_R   g254(.A(p6), .B(new_n112_), .Y(new_n276_));
  INVx1_ASAP7_75t_R    g255(.A(new_n276_), .Y(new_n277_));
  AOI21x1_ASAP7_75t_R  g256(.A1(new_n271_), .A2(new_n275_), .B(new_n277_), .Y(o4));
  AND3x1_ASAP7_75t_R   g257(.A(new_n23_), .B(p2), .C(new_n104_), .Y(new_n279_));
  AND3x1_ASAP7_75t_R   g258(.A(new_n273_), .B(new_n36_), .C(new_n60_), .Y(new_n280_));
  OA21x2_ASAP7_75t_R   g259(.A1(new_n279_), .A2(new_n280_), .B(new_n276_), .Y(o5));
  NAND2x1_ASAP7_75t_R  g260(.A(new_n98_), .B(new_n195_), .Y(new_n282_));
  NOR2x1_ASAP7_75t_R   g261(.A(p9), .B(new_n34_), .Y(new_n283_));
  AOI22x1_ASAP7_75t_R  g262(.A1(new_n283_), .A2(p8), .B1(new_n36_), .B2(new_n61_), .Y(new_n284_));
  AO21x1_ASAP7_75t_R   g263(.A1(new_n282_), .A2(new_n284_), .B(new_n22_), .Y(new_n285_));
  NOR2x1_ASAP7_75t_R   g264(.A(new_n118_), .B(new_n153_), .Y(new_n286_));
  OR3x1_ASAP7_75t_R    g265(.A(new_n286_), .B(new_n47_), .C(new_n199_), .Y(new_n287_));
  NAND2x1_ASAP7_75t_R  g266(.A(p7), .B(new_n29_), .Y(new_n288_));
  OR3x1_ASAP7_75t_R    g267(.A(new_n288_), .B(new_n34_), .C(new_n24_), .Y(new_n289_));
  OR5x1_ASAP7_75t_R    g268(.A(new_n80_), .B(new_n111_), .C(new_n29_), .D(new_n71_), .E(new_n31_), .Y(new_n290_));
  AND5x1_ASAP7_75t_R   g269(.A(new_n285_), .B(new_n43_), .C(new_n287_), .D(new_n289_), .E(new_n290_), .Y(new_n291_));
  INVx1_ASAP7_75t_R    g270(.A(new_n283_), .Y(new_n292_));
  AO32x1_ASAP7_75t_R   g271(.A1(p9), .A2(p5), .A3(new_n169_), .B1(new_n292_), .B2(new_n37_), .Y(new_n293_));
  NOR2x1_ASAP7_75t_R   g272(.A(p9), .B(p5), .Y(new_n294_));
  AO21x1_ASAP7_75t_R   g273(.A1(p0), .A2(p1), .B(new_n294_), .Y(new_n295_));
  OA21x2_ASAP7_75t_R   g274(.A1(p0), .A2(new_n61_), .B(p9), .Y(new_n296_));
  AO32x1_ASAP7_75t_R   g275(.A1(new_n295_), .A2(new_n101_), .A3(new_n133_), .B1(new_n296_), .B2(new_n86_), .Y(new_n297_));
  OR3x1_ASAP7_75t_R    g276(.A(new_n125_), .B(new_n86_), .C(new_n171_), .Y(new_n298_));
  NAND2x1_ASAP7_75t_R  g277(.A(p2), .B(new_n298_), .Y(new_n299_));
  AOI221x1_ASAP7_75t_R g278(.A1(new_n293_), .A2(p8), .B1(new_n22_), .B2(new_n297_), .C(new_n299_), .Y(new_n300_));
  OA211x2_ASAP7_75t_R  g279(.A1(p9), .A2(new_n205_), .B(new_n52_), .C(new_n50_), .Y(new_n301_));
  AO21x1_ASAP7_75t_R   g280(.A1(p1), .A2(new_n22_), .B(p5), .Y(new_n302_));
  OA21x2_ASAP7_75t_R   g281(.A1(new_n30_), .A2(new_n302_), .B(new_n37_), .Y(new_n303_));
  AO21x1_ASAP7_75t_R   g282(.A1(new_n28_), .A2(new_n235_), .B(new_n40_), .Y(new_n304_));
  OA21x2_ASAP7_75t_R   g283(.A1(p7), .A2(p8), .B(p1), .Y(new_n305_));
  AO21x1_ASAP7_75t_R   g284(.A1(p9), .A2(new_n195_), .B(new_n305_), .Y(new_n306_));
  AO32x1_ASAP7_75t_R   g285(.A1(p1), .A2(new_n40_), .A3(new_n132_), .B1(new_n306_), .B2(new_n186_), .Y(new_n307_));
  AOI221x1_ASAP7_75t_R g286(.A1(new_n36_), .A2(new_n301_), .B1(new_n303_), .B2(new_n304_), .C(new_n307_), .Y(new_n308_));
  OAI21x1_ASAP7_75t_R  g287(.A1(new_n291_), .A2(new_n300_), .B(new_n308_), .Y(new_n309_));
  AO21x1_ASAP7_75t_R   g288(.A1(new_n98_), .A2(new_n195_), .B(new_n61_), .Y(new_n310_));
  AO21x1_ASAP7_75t_R   g289(.A1(p6), .A2(new_n27_), .B(new_n80_), .Y(new_n311_));
  AO22x1_ASAP7_75t_R   g290(.A1(p0), .A2(new_n52_), .B1(new_n35_), .B2(new_n311_), .Y(new_n312_));
  AO32x1_ASAP7_75t_R   g291(.A1(p6), .A2(new_n34_), .A3(new_n310_), .B1(new_n312_), .B2(new_n29_), .Y(new_n313_));
  AO221x2_ASAP7_75t_R  g292(.A1(p3), .A2(new_n107_), .B1(new_n313_), .B2(new_n174_), .C(new_n276_), .Y(new_n314_));
  AOI21x1_ASAP7_75t_R  g293(.A1(new_n69_), .A2(new_n309_), .B(new_n314_), .Y(o6));
  NOR2x1_ASAP7_75t_R   g294(.A(p8), .B(new_n81_), .Y(new_n316_));
  AO32x1_ASAP7_75t_R   g295(.A1(p9), .A2(new_n169_), .A3(new_n316_), .B1(new_n199_), .B2(new_n283_), .Y(new_n317_));
  AND3x1_ASAP7_75t_R   g296(.A(new_n317_), .B(new_n57_), .C(new_n257_), .Y(new_n318_));
  OA21x2_ASAP7_75t_R   g297(.A1(new_n81_), .A2(new_n318_), .B(new_n104_), .Y(new_n319_));
  AOI21x1_ASAP7_75t_R  g298(.A1(new_n64_), .A2(new_n204_), .B(new_n27_), .Y(new_n320_));
  NAND2x1_ASAP7_75t_R  g299(.A(new_n288_), .B(new_n204_), .Y(new_n321_));
  NAND2x1_ASAP7_75t_R  g300(.A(p8), .B(p5), .Y(new_n322_));
  AOI221x1_ASAP7_75t_R g301(.A1(p8), .A2(new_n29_), .B1(new_n322_), .B2(new_n80_), .C(new_n294_), .Y(new_n323_));
  AOI22x1_ASAP7_75t_R  g302(.A1(new_n320_), .A2(new_n321_), .B1(new_n64_), .B2(new_n323_), .Y(new_n324_));
  NAND2x1_ASAP7_75t_R  g303(.A(p7), .B(p8), .Y(new_n325_));
  AO21x1_ASAP7_75t_R   g304(.A1(p2), .A2(new_n325_), .B(new_n121_), .Y(new_n326_));
  NOR2x1_ASAP7_75t_R   g305(.A(p5), .B(new_n34_), .Y(new_n327_));
  AO32x1_ASAP7_75t_R   g306(.A1(new_n195_), .A2(new_n43_), .A3(p1), .B1(new_n108_), .B2(new_n177_), .Y(new_n328_));
  AOI21x1_ASAP7_75t_R  g307(.A1(new_n326_), .A2(new_n327_), .B(new_n328_), .Y(new_n329_));
  OAI21x1_ASAP7_75t_R  g308(.A1(p1), .A2(new_n324_), .B(new_n329_), .Y(new_n330_));
  AO21x1_ASAP7_75t_R   g309(.A1(p7), .A2(p8), .B(p5), .Y(new_n331_));
  NAND2x1_ASAP7_75t_R  g310(.A(p5), .B(new_n29_), .Y(new_n332_));
  OAI22x1_ASAP7_75t_R  g311(.A1(new_n48_), .A2(new_n331_), .B1(new_n199_), .B2(new_n332_), .Y(new_n333_));
  NAND2x1_ASAP7_75t_R  g312(.A(p5), .B(new_n61_), .Y(new_n334_));
  OAI22x1_ASAP7_75t_R  g313(.A1(new_n185_), .A2(new_n28_), .B1(new_n218_), .B2(new_n334_), .Y(new_n335_));
  OAI21x1_ASAP7_75t_R  g314(.A1(p5), .A2(new_n177_), .B(new_n305_), .Y(new_n336_));
  AOI21x1_ASAP7_75t_R  g315(.A1(new_n157_), .A2(new_n336_), .B(p0), .Y(new_n337_));
  AO211x2_ASAP7_75t_R  g316(.A1(new_n333_), .A2(new_n137_), .B(new_n335_), .C(new_n337_), .Y(new_n338_));
  AOI21x1_ASAP7_75t_R  g317(.A1(p0), .A2(new_n330_), .B(new_n338_), .Y(new_n339_));
  OR3x1_ASAP7_75t_R    g318(.A(new_n195_), .B(new_n252_), .C(new_n61_), .Y(new_n340_));
  AOI211x1_ASAP7_75t_R g319(.A1(new_n43_), .A2(new_n34_), .B(new_n60_), .C(new_n159_), .Y(new_n341_));
  NAND3x1_ASAP7_75t_R  g320(.A(p7), .B(p8), .C(p1), .Y(new_n342_));
  OAI22x1_ASAP7_75t_R  g321(.A1(new_n182_), .A2(new_n75_), .B1(new_n220_), .B2(new_n342_), .Y(new_n343_));
  AOI21x1_ASAP7_75t_R  g322(.A1(new_n340_), .A2(new_n341_), .B(new_n343_), .Y(new_n344_));
  NOR2x1_ASAP7_75t_R   g323(.A(new_n194_), .B(new_n165_), .Y(new_n345_));
  NAND2x1_ASAP7_75t_R  g324(.A(new_n27_), .B(new_n29_), .Y(new_n346_));
  OAI21x1_ASAP7_75t_R  g325(.A1(p8), .A2(p1), .B(p9), .Y(new_n347_));
  OAI22x1_ASAP7_75t_R  g326(.A1(new_n346_), .A2(new_n22_), .B1(new_n53_), .B2(new_n347_), .Y(new_n348_));
  AO31x2_ASAP7_75t_R   g327(.A1(p8), .A2(p1), .A3(p4), .B(p7), .Y(new_n349_));
  AND2x2_ASAP7_75t_R   g328(.A(new_n43_), .B(new_n349_), .Y(new_n350_));
  OAI21x1_ASAP7_75t_R  g329(.A1(new_n345_), .A2(new_n348_), .B(new_n350_), .Y(new_n351_));
  OAI21x1_ASAP7_75t_R  g330(.A1(p8), .A2(new_n34_), .B(new_n220_), .Y(new_n352_));
  AND3x1_ASAP7_75t_R   g331(.A(new_n235_), .B(p2), .C(new_n325_), .Y(new_n353_));
  AOI21x1_ASAP7_75t_R  g332(.A1(new_n171_), .A2(new_n352_), .B(new_n353_), .Y(new_n354_));
  NAND3x1_ASAP7_75t_R  g333(.A(new_n344_), .B(new_n351_), .C(new_n354_), .Y(new_n355_));
  AOI21x1_ASAP7_75t_R  g334(.A1(new_n36_), .A2(new_n344_), .B(p5), .Y(new_n356_));
  AOI21x1_ASAP7_75t_R  g335(.A1(new_n355_), .A2(new_n356_), .B(new_n318_), .Y(new_n357_));
  OAI21x1_ASAP7_75t_R  g336(.A1(p4), .A2(new_n339_), .B(new_n357_), .Y(new_n358_));
  AND3x1_ASAP7_75t_R   g337(.A(new_n280_), .B(new_n81_), .C(new_n257_), .Y(new_n359_));
  AOI21x1_ASAP7_75t_R  g338(.A1(new_n319_), .A2(new_n358_), .B(new_n359_), .Y(o7));
  OR3x1_ASAP7_75t_R    g339(.A(new_n100_), .B(p9), .C(new_n243_), .Y(new_n361_));
  AOI22x1_ASAP7_75t_R  g340(.A1(new_n53_), .A2(new_n171_), .B1(new_n121_), .B2(new_n52_), .Y(new_n362_));
  OA21x2_ASAP7_75t_R   g341(.A1(new_n346_), .A2(new_n286_), .B(new_n362_), .Y(new_n363_));
  AO21x1_ASAP7_75t_R   g342(.A1(p0), .A2(new_n361_), .B(new_n230_), .Y(new_n364_));
  AOI21x1_ASAP7_75t_R  g343(.A1(new_n361_), .A2(new_n363_), .B(new_n364_), .Y(new_n365_));
  OA21x2_ASAP7_75t_R   g344(.A1(new_n81_), .A2(new_n365_), .B(new_n104_), .Y(new_n366_));
  AO21x1_ASAP7_75t_R   g345(.A1(p8), .A2(new_n43_), .B(p1), .Y(new_n367_));
  AOI211x1_ASAP7_75t_R g346(.A1(new_n159_), .A2(new_n97_), .B(new_n65_), .C(new_n367_), .Y(new_n368_));
  NAND2x1_ASAP7_75t_R  g347(.A(new_n36_), .B(new_n22_), .Y(new_n369_));
  INVx1_ASAP7_75t_R    g348(.A(new_n200_), .Y(new_n370_));
  AOI21x1_ASAP7_75t_R  g349(.A1(new_n369_), .A2(new_n101_), .B(new_n370_), .Y(new_n371_));
  NOR2x1_ASAP7_75t_R   g350(.A(p2), .B(new_n243_), .Y(new_n372_));
  AND3x1_ASAP7_75t_R   g351(.A(new_n52_), .B(new_n36_), .C(p4), .Y(new_n373_));
  OA21x2_ASAP7_75t_R   g352(.A1(new_n372_), .A2(new_n373_), .B(new_n29_), .Y(new_n374_));
  OA31x2_ASAP7_75t_R   g353(.A1(new_n368_), .A2(new_n371_), .A3(new_n374_), .B1(new_n146_), .Y(new_n375_));
  NOR2x1_ASAP7_75t_R   g354(.A(new_n37_), .B(new_n296_), .Y(new_n376_));
  NOR2x1_ASAP7_75t_R   g355(.A(p9), .B(new_n80_), .Y(new_n377_));
  AO21x1_ASAP7_75t_R   g356(.A1(p8), .A2(new_n36_), .B(new_n47_), .Y(new_n378_));
  AO21x1_ASAP7_75t_R   g357(.A1(new_n86_), .A2(new_n377_), .B(new_n378_), .Y(new_n379_));
  AOI221x1_ASAP7_75t_R g358(.A1(new_n376_), .A2(new_n47_), .B1(new_n34_), .B2(new_n379_), .C(new_n130_), .Y(new_n380_));
  OR5x1_ASAP7_75t_R    g359(.A(new_n80_), .B(new_n124_), .C(new_n43_), .D(p0), .E(p1), .Y(new_n381_));
  OA21x2_ASAP7_75t_R   g360(.A1(new_n34_), .A2(p4), .B(new_n220_), .Y(new_n382_));
  OR4x2_ASAP7_75t_R    g361(.A(new_n382_), .B(new_n36_), .C(new_n252_), .D(new_n210_), .Y(new_n383_));
  NAND2x1_ASAP7_75t_R  g362(.A(p8), .B(new_n47_), .Y(new_n384_));
  AOI21x1_ASAP7_75t_R  g363(.A1(new_n381_), .A2(new_n383_), .B(new_n384_), .Y(new_n385_));
  AND3x1_ASAP7_75t_R   g364(.A(new_n125_), .B(p7), .C(new_n57_), .Y(new_n386_));
  AND5x1_ASAP7_75t_R   g365(.A(p7), .B(new_n55_), .C(new_n130_), .D(new_n34_), .E(new_n266_), .Y(new_n387_));
  OA211x2_ASAP7_75t_R  g366(.A1(p4), .A2(new_n377_), .B(new_n71_), .C(new_n220_), .Y(new_n388_));
  OA31x2_ASAP7_75t_R   g367(.A1(new_n386_), .A2(new_n387_), .A3(new_n388_), .B1(new_n108_), .Y(new_n389_));
  OR5x1_ASAP7_75t_R    g368(.A(new_n365_), .B(new_n375_), .C(new_n380_), .D(new_n385_), .E(new_n389_), .Y(new_n390_));
  AND3x1_ASAP7_75t_R   g369(.A(new_n280_), .B(new_n81_), .C(new_n22_), .Y(new_n391_));
  AOI21x1_ASAP7_75t_R  g370(.A1(new_n366_), .A2(new_n390_), .B(new_n391_), .Y(o8));
  AND3x1_ASAP7_75t_R   g371(.A(new_n305_), .B(new_n43_), .C(new_n260_), .Y(new_n393_));
  AND2x2_ASAP7_75t_R   g372(.A(p2), .B(new_n322_), .Y(new_n394_));
  OAI21x1_ASAP7_75t_R  g373(.A1(new_n288_), .A2(new_n242_), .B(new_n394_), .Y(new_n395_));
  OA211x2_ASAP7_75t_R  g374(.A1(new_n257_), .A2(new_n274_), .B(new_n395_), .C(new_n34_), .Y(new_n396_));
  OAI21x1_ASAP7_75t_R  g375(.A1(new_n393_), .A2(new_n396_), .B(new_n36_), .Y(new_n397_));
  OA21x2_ASAP7_75t_R   g376(.A1(p2), .A2(new_n24_), .B(new_n288_), .Y(new_n398_));
  OR3x1_ASAP7_75t_R    g377(.A(new_n398_), .B(p1), .C(new_n394_), .Y(new_n399_));
  OR3x1_ASAP7_75t_R    g378(.A(new_n43_), .B(new_n34_), .C(p5), .Y(new_n400_));
  OR3x1_ASAP7_75t_R    g379(.A(new_n242_), .B(p2), .C(new_n146_), .Y(new_n401_));
  OA21x2_ASAP7_75t_R   g380(.A1(new_n260_), .A2(new_n400_), .B(new_n401_), .Y(new_n402_));
  AO21x1_ASAP7_75t_R   g381(.A1(new_n399_), .A2(new_n402_), .B(new_n36_), .Y(new_n403_));
  OA21x2_ASAP7_75t_R   g382(.A1(new_n400_), .A2(new_n189_), .B(new_n81_), .Y(new_n404_));
  OR3x1_ASAP7_75t_R    g383(.A(new_n404_), .B(new_n77_), .C(new_n132_), .Y(new_n405_));
  AO21x1_ASAP7_75t_R   g384(.A1(new_n22_), .A2(new_n370_), .B(new_n47_), .Y(new_n406_));
  OR3x1_ASAP7_75t_R    g385(.A(new_n91_), .B(p2), .C(p0), .Y(new_n407_));
  AO21x1_ASAP7_75t_R   g386(.A1(new_n29_), .A2(new_n200_), .B(new_n81_), .Y(new_n408_));
  AND3x1_ASAP7_75t_R   g387(.A(new_n406_), .B(new_n407_), .C(new_n408_), .Y(new_n409_));
  AND5x1_ASAP7_75t_R   g388(.A(new_n397_), .B(new_n207_), .C(new_n403_), .D(new_n405_), .E(new_n409_), .Y(o9));
  AO21x1_ASAP7_75t_R   g389(.A1(p0), .A2(new_n30_), .B(new_n80_), .Y(new_n411_));
  AND5x1_ASAP7_75t_R   g390(.A(new_n81_), .B(new_n257_), .C(p2), .D(new_n104_), .E(p1), .Y(new_n412_));
  AO32x1_ASAP7_75t_R   g391(.A1(new_n39_), .A2(new_n411_), .A3(new_n412_), .B1(new_n391_), .B2(new_n47_), .Y(o10));
endmodule


