// Benchmark "/tmp/" written by ABC on Tue Oct 20 17:20:37 2026

module \/tmp/  ( 
    p0, p7, p6, p4, p3, p1, p2, p5, p9, p8,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10  );
  input  p0, p7, p6, p4, p3, p1, p2, p5, p9, p8;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10;
  wire new_n22_, new_n23_, new_n24_, new_n25_, new_n26_, new_n27_, new_n28_,
    new_n29_, new_n30_, new_n31_, new_n32_, new_n33_, new_n34_, new_n35_,
    new_n36_, new_n37_, new_n38_, new_n39_, new_n40_, new_n41_, new_n42_,
    new_n43_, new_n44_, new_n45_, new_n46_, new_n47_, new_n48_, new_n49_,
    new_n50_, new_n51_, new_n52_, new_n53_, new_n54_, new_n55_, new_n56_,
    new_n57_, new_n58_, new_n59_, new_n60_, new_n61_, new_n62_, new_n63_,
    new_n64_, new_n65_, new_n66_, new_n67_, new_n68_, new_n69_, new_n70_,
    new_n71_, new_n72_, new_n73_, new_n74_, new_n75_, new_n76_, new_n77_,
    new_n78_, new_n79_, new_n80_, new_n81_, new_n82_, new_n83_, new_n84_,
    new_n85_, new_n86_, new_n87_, new_n88_, new_n89_, new_n90_, new_n91_,
    new_n92_, new_n93_, new_n94_, new_n95_, new_n96_, new_n97_, new_n98_,
    new_n99_, new_n100_, new_n101_, new_n102_, new_n103_, new_n104_,
    new_n105_, new_n106_, new_n107_, new_n108_, new_n109_, new_n110_,
    new_n111_, new_n112_, new_n114_, new_n115_, new_n116_, new_n117_,
    new_n118_, new_n119_, new_n120_, new_n121_, new_n122_, new_n123_,
    new_n124_, new_n125_, new_n126_, new_n127_, new_n128_, new_n129_,
    new_n130_, new_n131_, new_n132_, new_n133_, new_n134_, new_n135_,
    new_n136_, new_n137_, new_n138_, new_n139_, new_n140_, new_n141_,
    new_n142_, new_n143_, new_n144_, new_n145_, new_n146_, new_n147_,
    new_n148_, new_n149_, new_n150_, new_n151_, new_n152_, new_n153_,
    new_n154_, new_n155_, new_n156_, new_n157_, new_n158_, new_n159_,
    new_n160_, new_n161_, new_n162_, new_n163_, new_n164_, new_n165_,
    new_n166_, new_n167_, new_n168_, new_n169_, new_n170_, new_n171_,
    new_n172_, new_n173_, new_n174_, new_n175_, new_n176_, new_n177_,
    new_n178_, new_n179_, new_n180_, new_n181_, new_n182_, new_n184_,
    new_n185_, new_n186_, new_n187_, new_n188_, new_n189_, new_n190_,
    new_n191_, new_n192_, new_n193_, new_n194_, new_n195_, new_n196_,
    new_n197_, new_n198_, new_n199_, new_n200_, new_n201_, new_n202_,
    new_n203_, new_n204_, new_n205_, new_n206_, new_n207_, new_n208_,
    new_n209_, new_n210_, new_n211_, new_n212_, new_n213_, new_n214_,
    new_n215_, new_n216_, new_n217_, new_n218_, new_n219_, new_n220_,
    new_n221_, new_n222_, new_n223_, new_n224_, new_n225_, new_n226_,
    new_n227_, new_n228_, new_n229_, new_n230_, new_n231_, new_n232_,
    new_n233_, new_n234_, new_n235_, new_n236_, new_n237_, new_n238_,
    new_n239_, new_n240_, new_n241_, new_n242_, new_n243_, new_n245_,
    new_n246_, new_n247_, new_n248_, new_n249_, new_n250_, new_n251_,
    new_n252_, new_n253_, new_n254_, new_n255_, new_n256_, new_n257_,
    new_n258_, new_n259_, new_n260_, new_n261_, new_n262_, new_n263_,
    new_n264_, new_n265_, new_n266_, new_n267_, new_n268_, new_n269_,
    new_n270_, new_n271_, new_n272_, new_n273_, new_n274_, new_n275_,
    new_n276_, new_n277_, new_n278_, new_n279_, new_n280_, new_n281_,
    new_n283_, new_n284_, new_n285_, new_n286_, new_n287_, new_n289_,
    new_n290_, new_n291_, new_n293_, new_n294_, new_n295_, new_n296_,
    new_n297_, new_n298_, new_n299_, new_n300_, new_n301_, new_n302_,
    new_n303_, new_n304_, new_n305_, new_n306_, new_n307_, new_n308_,
    new_n309_, new_n310_, new_n311_, new_n312_, new_n313_, new_n314_,
    new_n315_, new_n316_, new_n317_, new_n318_, new_n319_, new_n320_,
    new_n321_, new_n322_, new_n323_, new_n324_, new_n325_, new_n326_,
    new_n327_, new_n328_, new_n329_, new_n330_, new_n331_, new_n333_,
    new_n334_, new_n335_, new_n336_, new_n337_, new_n338_, new_n339_,
    new_n340_, new_n341_, new_n342_, new_n343_, new_n344_, new_n345_,
    new_n346_, new_n347_, new_n348_, new_n349_, new_n350_, new_n351_,
    new_n352_, new_n353_, new_n354_, new_n355_, new_n356_, new_n357_,
    new_n358_, new_n359_, new_n360_, new_n361_, new_n362_, new_n363_,
    new_n364_, new_n365_, new_n366_, new_n367_, new_n368_, new_n369_,
    new_n370_, new_n371_, new_n372_, new_n373_, new_n374_, new_n375_,
    new_n376_, new_n377_, new_n378_, new_n379_, new_n380_, new_n382_,
    new_n383_, new_n384_, new_n385_, new_n386_, new_n387_, new_n388_,
    new_n389_, new_n390_, new_n391_, new_n392_, new_n393_, new_n394_,
    new_n395_, new_n396_, new_n397_, new_n398_, new_n399_, new_n400_,
    new_n401_, new_n402_, new_n403_, new_n404_, new_n405_, new_n406_,
    new_n407_, new_n408_, new_n409_, new_n410_, new_n412_, new_n413_,
    new_n414_, new_n415_, new_n416_, new_n417_, new_n418_, new_n419_,
    new_n420_, new_n421_, new_n422_, new_n423_, new_n424_, new_n425_,
    new_n426_, new_n427_, new_n428_, new_n430_, new_n431_, new_n432_;
  INVx1_ASAP7_75t_R    g000(.A(p5), .Y(new_n22_));
  NAND2x1_ASAP7_75t_R  g001(.A(p2), .B(new_n22_), .Y(new_n23_));
  NOR2x1_ASAP7_75t_R   g002(.A(p0), .B(p8), .Y(new_n24_));
  NAND2x1_ASAP7_75t_R  g003(.A(p1), .B(p2), .Y(new_n25_));
  AO32x1_ASAP7_75t_R   g004(.A1(new_n23_), .A2(new_n24_), .A3(new_n25_), .B1(p1), .B2(p8), .Y(new_n26_));
  NOR2x1_ASAP7_75t_R   g005(.A(p7), .B(p4), .Y(new_n27_));
  NOR2x1_ASAP7_75t_R   g006(.A(p0), .B(p2), .Y(new_n28_));
  INVx1_ASAP7_75t_R    g007(.A(p7), .Y(new_n29_));
  AO32x1_ASAP7_75t_R   g008(.A1(new_n28_), .A2(p1), .A3(p8), .B1(p0), .B2(new_n29_), .Y(new_n30_));
  NOR2x1_ASAP7_75t_R   g009(.A(p4), .B(p9), .Y(new_n31_));
  AOI22x1_ASAP7_75t_R  g010(.A1(new_n26_), .A2(new_n27_), .B1(new_n30_), .B2(new_n31_), .Y(new_n32_));
  NAND2x1_ASAP7_75t_R  g011(.A(p7), .B(p5), .Y(new_n33_));
  OR3x1_ASAP7_75t_R    g012(.A(new_n33_), .B(p2), .C(p9), .Y(new_n34_));
  AND2x2_ASAP7_75t_R   g013(.A(p1), .B(p8), .Y(new_n35_));
  INVx1_ASAP7_75t_R    g014(.A(p1), .Y(new_n36_));
  INVx1_ASAP7_75t_R    g015(.A(p8), .Y(new_n37_));
  AND3x1_ASAP7_75t_R   g016(.A(new_n36_), .B(new_n37_), .C(p0), .Y(new_n38_));
  NOR2x1_ASAP7_75t_R   g017(.A(new_n35_), .B(new_n38_), .Y(new_n39_));
  INVx1_ASAP7_75t_R    g018(.A(p2), .Y(new_n40_));
  INVx1_ASAP7_75t_R    g019(.A(p9), .Y(new_n41_));
  NAND2x1_ASAP7_75t_R  g020(.A(new_n40_), .B(new_n41_), .Y(new_n42_));
  OR3x1_ASAP7_75t_R    g021(.A(p0), .B(p7), .C(p8), .Y(new_n43_));
  OR3x1_ASAP7_75t_R    g022(.A(new_n42_), .B(p1), .C(new_n43_), .Y(new_n44_));
  OA21x2_ASAP7_75t_R   g023(.A1(new_n34_), .A2(new_n39_), .B(new_n44_), .Y(new_n45_));
  AO21x1_ASAP7_75t_R   g024(.A1(p9), .A2(new_n37_), .B(p1), .Y(new_n46_));
  NAND2x1_ASAP7_75t_R  g025(.A(p8), .B(new_n41_), .Y(new_n47_));
  AND3x1_ASAP7_75t_R   g026(.A(new_n47_), .B(p0), .C(new_n40_), .Y(new_n48_));
  NAND2x1_ASAP7_75t_R  g027(.A(p7), .B(p4), .Y(new_n49_));
  AOI21x1_ASAP7_75t_R  g028(.A1(new_n22_), .A2(new_n46_), .B(new_n49_), .Y(new_n50_));
  OAI21x1_ASAP7_75t_R  g029(.A1(new_n46_), .A2(new_n48_), .B(new_n50_), .Y(new_n51_));
  NAND3x1_ASAP7_75t_R  g030(.A(new_n32_), .B(new_n45_), .C(new_n51_), .Y(new_n52_));
  NAND2x1_ASAP7_75t_R  g031(.A(p0), .B(new_n29_), .Y(new_n53_));
  NOR2x1_ASAP7_75t_R   g032(.A(p0), .B(new_n36_), .Y(new_n54_));
  NOR2x1_ASAP7_75t_R   g033(.A(p8), .B(new_n41_), .Y(new_n55_));
  NOR2x1_ASAP7_75t_R   g034(.A(p9), .B(new_n37_), .Y(new_n56_));
  AOI22x1_ASAP7_75t_R  g035(.A1(new_n54_), .A2(new_n55_), .B1(new_n56_), .B2(new_n29_), .Y(new_n57_));
  AO21x1_ASAP7_75t_R   g036(.A1(new_n53_), .A2(new_n57_), .B(p4), .Y(new_n58_));
  INVx1_ASAP7_75t_R    g037(.A(p0), .Y(new_n59_));
  AND3x1_ASAP7_75t_R   g038(.A(new_n59_), .B(new_n36_), .C(new_n41_), .Y(new_n60_));
  NOR2x1_ASAP7_75t_R   g039(.A(p4), .B(p8), .Y(new_n61_));
  INVx1_ASAP7_75t_R    g040(.A(new_n61_), .Y(new_n62_));
  INVx1_ASAP7_75t_R    g041(.A(new_n33_), .Y(new_n63_));
  OA211x2_ASAP7_75t_R  g042(.A1(p4), .A2(new_n60_), .B(new_n62_), .C(new_n63_), .Y(new_n64_));
  INVx1_ASAP7_75t_R    g043(.A(new_n55_), .Y(new_n65_));
  AND2x2_ASAP7_75t_R   g044(.A(p4), .B(p1), .Y(new_n66_));
  AND5x1_ASAP7_75t_R   g045(.A(p0), .B(new_n65_), .C(new_n47_), .D(p7), .E(new_n66_), .Y(new_n67_));
  NOR2x1_ASAP7_75t_R   g046(.A(new_n64_), .B(new_n67_), .Y(new_n68_));
  AOI21x1_ASAP7_75t_R  g047(.A1(new_n58_), .A2(new_n68_), .B(new_n40_), .Y(new_n69_));
  INVx1_ASAP7_75t_R    g048(.A(p6), .Y(new_n70_));
  OAI21x1_ASAP7_75t_R  g049(.A1(new_n52_), .A2(new_n69_), .B(new_n70_), .Y(new_n71_));
  NOR2x1_ASAP7_75t_R   g050(.A(p3), .B(p5), .Y(new_n72_));
  NOR2x1_ASAP7_75t_R   g051(.A(p0), .B(new_n37_), .Y(new_n73_));
  NOR2x1_ASAP7_75t_R   g052(.A(p1), .B(p2), .Y(new_n74_));
  INVx1_ASAP7_75t_R    g053(.A(new_n74_), .Y(new_n75_));
  AND3x1_ASAP7_75t_R   g054(.A(new_n59_), .B(p2), .C(p9), .Y(new_n76_));
  AOI221x1_ASAP7_75t_R g055(.A1(p0), .A2(new_n40_), .B1(new_n73_), .B2(new_n75_), .C(new_n76_), .Y(new_n77_));
  NAND2x1_ASAP7_75t_R  g056(.A(p0), .B(p1), .Y(new_n78_));
  INVx1_ASAP7_75t_R    g057(.A(p4), .Y(new_n79_));
  AO21x1_ASAP7_75t_R   g058(.A1(new_n79_), .A2(new_n36_), .B(p9), .Y(new_n80_));
  AO21x1_ASAP7_75t_R   g059(.A1(new_n78_), .A2(new_n80_), .B(p8), .Y(new_n81_));
  AO21x1_ASAP7_75t_R   g060(.A1(new_n77_), .A2(new_n81_), .B(p6), .Y(new_n82_));
  NOR2x1_ASAP7_75t_R   g061(.A(p4), .B(new_n29_), .Y(new_n83_));
  INVx1_ASAP7_75t_R    g062(.A(new_n83_), .Y(new_n84_));
  NAND2x1_ASAP7_75t_R  g063(.A(p9), .B(new_n36_), .Y(new_n85_));
  AO21x1_ASAP7_75t_R   g064(.A1(p6), .A2(new_n62_), .B(new_n85_), .Y(new_n86_));
  NOR2x1_ASAP7_75t_R   g065(.A(p8), .B(new_n59_), .Y(new_n87_));
  AO21x1_ASAP7_75t_R   g066(.A1(new_n70_), .A2(new_n87_), .B(p2), .Y(new_n88_));
  AOI21x1_ASAP7_75t_R  g067(.A1(new_n84_), .A2(new_n86_), .B(new_n88_), .Y(new_n89_));
  AO21x1_ASAP7_75t_R   g068(.A1(new_n79_), .A2(new_n37_), .B(p0), .Y(new_n90_));
  NOR2x1_ASAP7_75t_R   g069(.A(p0), .B(p9), .Y(new_n91_));
  AND3x1_ASAP7_75t_R   g070(.A(new_n91_), .B(p1), .C(new_n37_), .Y(new_n92_));
  AO32x1_ASAP7_75t_R   g071(.A1(new_n36_), .A2(new_n90_), .A3(p9), .B1(new_n92_), .B2(p6), .Y(new_n93_));
  NAND2x1_ASAP7_75t_R  g072(.A(p0), .B(p9), .Y(new_n94_));
  NOR2x1_ASAP7_75t_R   g073(.A(p4), .B(p2), .Y(new_n95_));
  NOR2x1_ASAP7_75t_R   g074(.A(p6), .B(new_n91_), .Y(new_n96_));
  AO21x1_ASAP7_75t_R   g075(.A1(new_n94_), .A2(new_n95_), .B(new_n96_), .Y(new_n97_));
  NOR2x1_ASAP7_75t_R   g076(.A(p7), .B(p1), .Y(new_n98_));
  XNOR2x2_ASAP7_75t_R  g077(.A(p0), .B(p8), .Y(new_n99_));
  AND2x2_ASAP7_75t_R   g078(.A(new_n98_), .B(new_n99_), .Y(new_n100_));
  AOI22x1_ASAP7_75t_R  g079(.A1(new_n89_), .A2(new_n93_), .B1(new_n97_), .B2(new_n100_), .Y(new_n101_));
  OAI21x1_ASAP7_75t_R  g080(.A1(p7), .A2(new_n82_), .B(new_n101_), .Y(new_n102_));
  NOR2x1_ASAP7_75t_R   g081(.A(p5), .B(p8), .Y(new_n103_));
  INVx1_ASAP7_75t_R    g082(.A(new_n103_), .Y(new_n104_));
  NAND2x1_ASAP7_75t_R  g083(.A(p4), .B(p5), .Y(new_n105_));
  OA21x2_ASAP7_75t_R   g084(.A1(p3), .A2(new_n37_), .B(new_n105_), .Y(new_n106_));
  NAND2x1_ASAP7_75t_R  g085(.A(p4), .B(new_n29_), .Y(new_n107_));
  NAND2x1_ASAP7_75t_R  g086(.A(new_n105_), .B(new_n107_), .Y(new_n108_));
  AO21x1_ASAP7_75t_R   g087(.A1(p7), .A2(p3), .B(new_n103_), .Y(new_n109_));
  AO32x1_ASAP7_75t_R   g088(.A1(new_n29_), .A2(new_n104_), .A3(new_n106_), .B1(new_n108_), .B2(new_n109_), .Y(new_n110_));
  AND5x1_ASAP7_75t_R   g089(.A(new_n70_), .B(new_n110_), .C(new_n36_), .D(new_n41_), .E(new_n28_), .Y(new_n111_));
  AOI21x1_ASAP7_75t_R  g090(.A1(new_n72_), .A2(new_n102_), .B(new_n111_), .Y(new_n112_));
  OAI21x1_ASAP7_75t_R  g091(.A1(p3), .A2(new_n71_), .B(new_n112_), .Y(o0));
  OAI21x1_ASAP7_75t_R  g092(.A1(p7), .A2(p2), .B(p9), .Y(new_n114_));
  NAND2x1_ASAP7_75t_R  g093(.A(p4), .B(new_n98_), .Y(new_n115_));
  OAI21x1_ASAP7_75t_R  g094(.A1(new_n83_), .A2(new_n114_), .B(new_n115_), .Y(new_n116_));
  AND2x2_ASAP7_75t_R   g095(.A(p7), .B(p9), .Y(new_n117_));
  AO21x1_ASAP7_75t_R   g096(.A1(p7), .A2(p2), .B(p1), .Y(new_n118_));
  AO32x1_ASAP7_75t_R   g097(.A1(new_n117_), .A2(p0), .A3(new_n36_), .B1(new_n118_), .B2(new_n41_), .Y(new_n119_));
  NOR2x1_ASAP7_75t_R   g098(.A(p9), .B(new_n79_), .Y(new_n120_));
  NOR2x1_ASAP7_75t_R   g099(.A(p4), .B(new_n41_), .Y(new_n121_));
  OA21x2_ASAP7_75t_R   g100(.A1(new_n120_), .A2(new_n121_), .B(p0), .Y(new_n122_));
  AOI211x1_ASAP7_75t_R g101(.A1(new_n59_), .A2(new_n116_), .B(new_n119_), .C(new_n122_), .Y(new_n123_));
  NAND2x1_ASAP7_75t_R  g102(.A(p2), .B(new_n79_), .Y(new_n124_));
  INVx1_ASAP7_75t_R    g103(.A(new_n124_), .Y(new_n125_));
  NOR2x1_ASAP7_75t_R   g104(.A(p0), .B(p7), .Y(new_n126_));
  OAI22x1_ASAP7_75t_R  g105(.A1(new_n126_), .A2(p1), .B1(new_n33_), .B2(p0), .Y(new_n127_));
  NOR2x1_ASAP7_75t_R   g106(.A(p0), .B(p5), .Y(new_n128_));
  INVx1_ASAP7_75t_R    g107(.A(new_n128_), .Y(new_n129_));
  NAND2x1_ASAP7_75t_R  g108(.A(p7), .B(new_n41_), .Y(new_n130_));
  AND5x1_ASAP7_75t_R   g109(.A(new_n79_), .B(new_n129_), .C(new_n130_), .D(new_n36_), .E(new_n94_), .Y(new_n131_));
  AOI211x1_ASAP7_75t_R g110(.A1(new_n125_), .A2(new_n127_), .B(p8), .C(new_n131_), .Y(new_n132_));
  OAI21x1_ASAP7_75t_R  g111(.A1(p5), .A2(new_n123_), .B(new_n132_), .Y(new_n133_));
  AND2x2_ASAP7_75t_R   g112(.A(p0), .B(p4), .Y(new_n134_));
  INVx1_ASAP7_75t_R    g113(.A(new_n134_), .Y(new_n135_));
  NOR2x1_ASAP7_75t_R   g114(.A(p1), .B(new_n40_), .Y(new_n136_));
  NAND2x1_ASAP7_75t_R  g115(.A(new_n126_), .B(new_n136_), .Y(new_n137_));
  NAND2x1_ASAP7_75t_R  g116(.A(p5), .B(p9), .Y(new_n138_));
  AO21x1_ASAP7_75t_R   g117(.A1(new_n135_), .A2(new_n137_), .B(new_n138_), .Y(new_n139_));
  NOR2x1_ASAP7_75t_R   g118(.A(p7), .B(new_n36_), .Y(new_n140_));
  NAND2x1_ASAP7_75t_R  g119(.A(p4), .B(p2), .Y(new_n141_));
  INVx1_ASAP7_75t_R    g120(.A(new_n141_), .Y(new_n142_));
  AOI21x1_ASAP7_75t_R  g121(.A1(new_n140_), .A2(new_n142_), .B(new_n37_), .Y(new_n143_));
  AO21x1_ASAP7_75t_R   g122(.A1(new_n36_), .A2(new_n40_), .B(new_n22_), .Y(new_n144_));
  AO21x1_ASAP7_75t_R   g123(.A1(new_n79_), .A2(new_n78_), .B(new_n95_), .Y(new_n145_));
  OA22x2_ASAP7_75t_R   g124(.A1(new_n143_), .A2(new_n73_), .B1(new_n144_), .B2(new_n145_), .Y(new_n146_));
  AOI21x1_ASAP7_75t_R  g125(.A1(new_n139_), .A2(new_n146_), .B(p3), .Y(new_n147_));
  AO21x1_ASAP7_75t_R   g126(.A1(p5), .A2(new_n41_), .B(p1), .Y(new_n148_));
  NOR2x1_ASAP7_75t_R   g127(.A(p7), .B(p5), .Y(new_n149_));
  AO21x1_ASAP7_75t_R   g128(.A1(new_n83_), .A2(new_n148_), .B(new_n149_), .Y(new_n150_));
  NAND3x1_ASAP7_75t_R  g129(.A(new_n33_), .B(new_n36_), .C(p9), .Y(new_n151_));
  AOI22x1_ASAP7_75t_R  g130(.A1(new_n79_), .A2(p7), .B1(p5), .B2(p8), .Y(new_n152_));
  OAI22x1_ASAP7_75t_R  g131(.A1(new_n151_), .A2(new_n152_), .B1(new_n47_), .B2(new_n115_), .Y(new_n153_));
  AOI22x1_ASAP7_75t_R  g132(.A1(new_n150_), .A2(new_n87_), .B1(new_n153_), .B2(p0), .Y(new_n154_));
  AND2x2_ASAP7_75t_R   g133(.A(p7), .B(p8), .Y(new_n155_));
  NOR2x1_ASAP7_75t_R   g134(.A(p7), .B(p8), .Y(new_n156_));
  AOI22x1_ASAP7_75t_R  g135(.A1(new_n155_), .A2(p5), .B1(new_n79_), .B2(new_n156_), .Y(new_n157_));
  OAI21x1_ASAP7_75t_R  g136(.A1(p9), .A2(new_n152_), .B(new_n157_), .Y(new_n158_));
  NAND2x1_ASAP7_75t_R  g137(.A(p4), .B(new_n59_), .Y(new_n159_));
  AND3x1_ASAP7_75t_R   g138(.A(p7), .B(p9), .C(p8), .Y(new_n160_));
  NOR2x1_ASAP7_75t_R   g139(.A(p1), .B(p9), .Y(new_n161_));
  AOI22x1_ASAP7_75t_R  g140(.A1(new_n160_), .A2(p1), .B1(new_n161_), .B2(new_n156_), .Y(new_n162_));
  NAND2x1_ASAP7_75t_R  g141(.A(p7), .B(p1), .Y(new_n163_));
  OR3x1_ASAP7_75t_R    g142(.A(new_n163_), .B(p5), .C(p8), .Y(new_n164_));
  OAI21x1_ASAP7_75t_R  g143(.A1(new_n159_), .A2(new_n162_), .B(new_n164_), .Y(new_n165_));
  AOI21x1_ASAP7_75t_R  g144(.A1(new_n54_), .A2(new_n158_), .B(new_n165_), .Y(new_n166_));
  AOI21x1_ASAP7_75t_R  g145(.A1(new_n154_), .A2(new_n166_), .B(p3), .Y(new_n167_));
  AND3x1_ASAP7_75t_R   g146(.A(p3), .B(p5), .C(p8), .Y(new_n168_));
  NAND2x1_ASAP7_75t_R  g147(.A(p7), .B(p3), .Y(new_n169_));
  AOI21x1_ASAP7_75t_R  g148(.A1(new_n169_), .A2(new_n107_), .B(new_n104_), .Y(new_n170_));
  OA211x2_ASAP7_75t_R  g149(.A1(new_n168_), .A2(new_n170_), .B(new_n40_), .C(new_n60_), .Y(new_n171_));
  AOI221x1_ASAP7_75t_R g150(.A1(new_n133_), .A2(new_n147_), .B1(new_n167_), .B2(new_n40_), .C(new_n171_), .Y(new_n172_));
  AO21x1_ASAP7_75t_R   g151(.A1(p0), .A2(p9), .B(new_n46_), .Y(new_n173_));
  AO21x1_ASAP7_75t_R   g152(.A1(new_n29_), .A2(new_n41_), .B(new_n98_), .Y(new_n174_));
  AND3x1_ASAP7_75t_R   g153(.A(new_n174_), .B(p6), .C(new_n78_), .Y(new_n175_));
  NOR2x1_ASAP7_75t_R   g154(.A(p1), .B(new_n29_), .Y(new_n176_));
  NOR2x1_ASAP7_75t_R   g155(.A(p8), .B(new_n36_), .Y(new_n177_));
  AO32x1_ASAP7_75t_R   g156(.A1(new_n87_), .A2(new_n176_), .A3(p6), .B1(new_n91_), .B2(new_n177_), .Y(new_n178_));
  AOI21x1_ASAP7_75t_R  g157(.A1(new_n173_), .A2(new_n175_), .B(new_n178_), .Y(new_n179_));
  NOR2x1_ASAP7_75t_R   g158(.A(p4), .B(p5), .Y(new_n180_));
  INVx1_ASAP7_75t_R    g159(.A(new_n180_), .Y(new_n181_));
  OR4x2_ASAP7_75t_R    g160(.A(new_n179_), .B(p3), .C(p2), .D(new_n181_), .Y(new_n182_));
  OAI21x1_ASAP7_75t_R  g161(.A1(p6), .A2(new_n172_), .B(new_n182_), .Y(o1));
  NOR2x1_ASAP7_75t_R   g162(.A(p7), .B(p2), .Y(new_n184_));
  NAND2x1_ASAP7_75t_R  g163(.A(p0), .B(new_n37_), .Y(new_n185_));
  AND3x1_ASAP7_75t_R   g164(.A(new_n37_), .B(p0), .C(p7), .Y(new_n186_));
  AOI211x1_ASAP7_75t_R g165(.A1(new_n184_), .A2(new_n185_), .B(new_n63_), .C(new_n186_), .Y(new_n187_));
  OR3x1_ASAP7_75t_R    g166(.A(new_n187_), .B(p1), .C(new_n73_), .Y(new_n188_));
  NOR3x1_ASAP7_75t_R   g167(.A(new_n36_), .B(p7), .C(p8), .Y(new_n189_));
  AOI21x1_ASAP7_75t_R  g168(.A1(new_n59_), .A2(new_n63_), .B(new_n189_), .Y(new_n190_));
  AND2x2_ASAP7_75t_R   g169(.A(p0), .B(p8), .Y(new_n191_));
  AND2x2_ASAP7_75t_R   g170(.A(p1), .B(p5), .Y(new_n192_));
  NAND2x1_ASAP7_75t_R  g171(.A(new_n191_), .B(new_n192_), .Y(new_n193_));
  OA21x2_ASAP7_75t_R   g172(.A1(new_n29_), .A2(new_n177_), .B(new_n193_), .Y(new_n194_));
  AO21x1_ASAP7_75t_R   g173(.A1(new_n190_), .A2(new_n194_), .B(new_n40_), .Y(new_n195_));
  NAND2x1_ASAP7_75t_R  g174(.A(p9), .B(new_n79_), .Y(new_n196_));
  AOI21x1_ASAP7_75t_R  g175(.A1(new_n188_), .A2(new_n195_), .B(new_n196_), .Y(new_n197_));
  AO21x1_ASAP7_75t_R   g176(.A1(p1), .A2(p8), .B(p4), .Y(new_n198_));
  AO21x1_ASAP7_75t_R   g177(.A1(new_n29_), .A2(new_n37_), .B(new_n79_), .Y(new_n199_));
  OA211x2_ASAP7_75t_R  g178(.A1(new_n160_), .A2(new_n199_), .B(p0), .C(new_n40_), .Y(new_n200_));
  NOR2x1_ASAP7_75t_R   g179(.A(new_n156_), .B(new_n155_), .Y(new_n201_));
  NOR2x1_ASAP7_75t_R   g180(.A(p2), .B(new_n36_), .Y(new_n202_));
  OA21x2_ASAP7_75t_R   g181(.A1(new_n24_), .A2(new_n201_), .B(new_n202_), .Y(new_n203_));
  AOI21x1_ASAP7_75t_R  g182(.A1(new_n198_), .A2(new_n200_), .B(new_n203_), .Y(new_n204_));
  OR4x2_ASAP7_75t_R    g183(.A(new_n74_), .B(p0), .C(new_n29_), .D(new_n37_), .Y(new_n205_));
  NOR2x1_ASAP7_75t_R   g184(.A(p0), .B(new_n40_), .Y(new_n206_));
  INVx1_ASAP7_75t_R    g185(.A(new_n206_), .Y(new_n207_));
  OR3x1_ASAP7_75t_R    g186(.A(p7), .B(p1), .C(p8), .Y(new_n208_));
  AO21x1_ASAP7_75t_R   g187(.A1(p4), .A2(new_n207_), .B(new_n208_), .Y(new_n209_));
  AO21x1_ASAP7_75t_R   g188(.A1(new_n205_), .A2(new_n209_), .B(new_n41_), .Y(new_n210_));
  AOI21x1_ASAP7_75t_R  g189(.A1(new_n204_), .A2(new_n210_), .B(p5), .Y(new_n211_));
  INVx1_ASAP7_75t_R    g190(.A(p3), .Y(new_n212_));
  OAI21x1_ASAP7_75t_R  g191(.A1(new_n197_), .A2(new_n211_), .B(new_n212_), .Y(new_n213_));
  NOR2x1_ASAP7_75t_R   g192(.A(p7), .B(new_n40_), .Y(new_n214_));
  AO21x1_ASAP7_75t_R   g193(.A1(new_n73_), .A2(new_n214_), .B(new_n136_), .Y(new_n215_));
  NOR2x1_ASAP7_75t_R   g194(.A(new_n103_), .B(new_n186_), .Y(new_n216_));
  NAND2x1_ASAP7_75t_R  g195(.A(p5), .B(new_n29_), .Y(new_n217_));
  OR3x1_ASAP7_75t_R    g196(.A(new_n59_), .B(new_n37_), .C(p2), .Y(new_n218_));
  OAI21x1_ASAP7_75t_R  g197(.A1(new_n217_), .A2(new_n218_), .B(new_n212_), .Y(new_n219_));
  NOR2x1_ASAP7_75t_R   g198(.A(new_n87_), .B(new_n214_), .Y(new_n220_));
  AO21x1_ASAP7_75t_R   g199(.A1(p2), .A2(new_n37_), .B(p5), .Y(new_n221_));
  NAND2x1_ASAP7_75t_R  g200(.A(p5), .B(new_n79_), .Y(new_n222_));
  NAND2x1_ASAP7_75t_R  g201(.A(new_n28_), .B(new_n156_), .Y(new_n223_));
  OAI22x1_ASAP7_75t_R  g202(.A1(new_n220_), .A2(new_n221_), .B1(new_n222_), .B2(new_n223_), .Y(new_n224_));
  AOI211x1_ASAP7_75t_R g203(.A1(new_n215_), .A2(new_n216_), .B(new_n219_), .C(new_n224_), .Y(new_n225_));
  NAND2x1_ASAP7_75t_R  g204(.A(p7), .B(new_n36_), .Y(new_n226_));
  AO21x1_ASAP7_75t_R   g205(.A1(new_n226_), .A2(new_n142_), .B(new_n185_), .Y(new_n227_));
  AND2x2_ASAP7_75t_R   g206(.A(p4), .B(new_n118_), .Y(new_n228_));
  OR3x1_ASAP7_75t_R    g207(.A(new_n140_), .B(new_n59_), .C(new_n192_), .Y(new_n229_));
  NAND2x1_ASAP7_75t_R  g208(.A(new_n228_), .B(new_n229_), .Y(new_n230_));
  OA21x2_ASAP7_75t_R   g209(.A1(new_n29_), .A2(new_n136_), .B(new_n79_), .Y(new_n231_));
  AO21x1_ASAP7_75t_R   g210(.A1(new_n227_), .A2(new_n230_), .B(new_n231_), .Y(new_n232_));
  INVx1_ASAP7_75t_R    g211(.A(new_n217_), .Y(new_n233_));
  OA21x2_ASAP7_75t_R   g212(.A1(new_n155_), .A2(new_n233_), .B(new_n79_), .Y(new_n234_));
  AO21x1_ASAP7_75t_R   g213(.A1(new_n59_), .A2(new_n74_), .B(new_n212_), .Y(new_n235_));
  NAND2x1_ASAP7_75t_R  g214(.A(new_n41_), .B(new_n235_), .Y(new_n236_));
  AO21x1_ASAP7_75t_R   g215(.A1(p3), .A2(new_n234_), .B(new_n236_), .Y(new_n237_));
  AOI21x1_ASAP7_75t_R  g216(.A1(new_n225_), .A2(new_n232_), .B(new_n237_), .Y(new_n238_));
  AO21x1_ASAP7_75t_R   g217(.A1(p6), .A2(new_n155_), .B(new_n41_), .Y(new_n239_));
  INVx1_ASAP7_75t_R    g218(.A(new_n43_), .Y(new_n240_));
  AO32x1_ASAP7_75t_R   g219(.A1(new_n239_), .A2(p0), .A3(new_n47_), .B1(p9), .B2(new_n240_), .Y(new_n241_));
  AND5x1_ASAP7_75t_R   g220(.A(new_n79_), .B(new_n241_), .C(new_n212_), .D(new_n22_), .E(new_n74_), .Y(new_n242_));
  AOI21x1_ASAP7_75t_R  g221(.A1(new_n70_), .A2(new_n238_), .B(new_n242_), .Y(new_n243_));
  OAI21x1_ASAP7_75t_R  g222(.A1(p6), .A2(new_n213_), .B(new_n243_), .Y(o2));
  AO21x1_ASAP7_75t_R   g223(.A1(p7), .A2(new_n79_), .B(new_n184_), .Y(new_n245_));
  OA21x2_ASAP7_75t_R   g224(.A1(p5), .A2(new_n214_), .B(new_n124_), .Y(new_n246_));
  AO21x1_ASAP7_75t_R   g225(.A1(new_n177_), .A2(new_n245_), .B(new_n246_), .Y(new_n247_));
  NOR2x1_ASAP7_75t_R   g226(.A(p1), .B(new_n79_), .Y(new_n248_));
  AO21x1_ASAP7_75t_R   g227(.A1(new_n248_), .A2(new_n201_), .B(new_n136_), .Y(new_n249_));
  AO32x1_ASAP7_75t_R   g228(.A1(new_n98_), .A2(new_n128_), .A3(p4), .B1(p5), .B2(new_n95_), .Y(new_n250_));
  AND2x2_ASAP7_75t_R   g229(.A(new_n37_), .B(new_n250_), .Y(new_n251_));
  OR3x1_ASAP7_75t_R    g230(.A(new_n247_), .B(new_n249_), .C(new_n251_), .Y(new_n252_));
  OA21x2_ASAP7_75t_R   g231(.A1(p0), .A2(new_n251_), .B(p9), .Y(new_n253_));
  NAND3x1_ASAP7_75t_R  g232(.A(new_n252_), .B(new_n212_), .C(new_n253_), .Y(new_n254_));
  NOR2x1_ASAP7_75t_R   g233(.A(p1), .B(p8), .Y(new_n255_));
  AO21x1_ASAP7_75t_R   g234(.A1(new_n255_), .A2(new_n125_), .B(new_n149_), .Y(new_n256_));
  AO21x1_ASAP7_75t_R   g235(.A1(new_n36_), .A2(p2), .B(new_n206_), .Y(new_n257_));
  AO21x1_ASAP7_75t_R   g236(.A1(p7), .A2(p4), .B(new_n191_), .Y(new_n258_));
  AO21x1_ASAP7_75t_R   g237(.A1(new_n79_), .A2(new_n22_), .B(new_n103_), .Y(new_n259_));
  AND3x1_ASAP7_75t_R   g238(.A(new_n258_), .B(p2), .C(new_n259_), .Y(new_n260_));
  AOI21x1_ASAP7_75t_R  g239(.A1(new_n256_), .A2(new_n257_), .B(new_n260_), .Y(new_n261_));
  OR3x1_ASAP7_75t_R    g240(.A(new_n36_), .B(new_n40_), .C(p5), .Y(new_n262_));
  OA21x2_ASAP7_75t_R   g241(.A1(new_n74_), .A2(new_n222_), .B(new_n262_), .Y(new_n263_));
  OR3x1_ASAP7_75t_R    g242(.A(new_n263_), .B(p0), .C(new_n37_), .Y(new_n264_));
  INVx1_ASAP7_75t_R    g243(.A(new_n186_), .Y(new_n265_));
  AO21x1_ASAP7_75t_R   g244(.A1(new_n43_), .A2(new_n265_), .B(new_n222_), .Y(new_n266_));
  NAND3x1_ASAP7_75t_R  g245(.A(new_n261_), .B(new_n264_), .C(new_n266_), .Y(new_n267_));
  AND2x2_ASAP7_75t_R   g246(.A(new_n40_), .B(new_n217_), .Y(new_n268_));
  NAND2x1_ASAP7_75t_R  g247(.A(p8), .B(new_n22_), .Y(new_n269_));
  NAND2x1_ASAP7_75t_R  g248(.A(p4), .B(p1), .Y(new_n270_));
  OR3x1_ASAP7_75t_R    g249(.A(new_n269_), .B(new_n29_), .C(new_n270_), .Y(new_n271_));
  OA21x2_ASAP7_75t_R   g250(.A1(new_n108_), .A2(new_n268_), .B(new_n271_), .Y(new_n272_));
  AND2x2_ASAP7_75t_R   g251(.A(p0), .B(p1), .Y(new_n273_));
  AND3x1_ASAP7_75t_R   g252(.A(new_n273_), .B(new_n79_), .C(new_n156_), .Y(new_n274_));
  AO21x1_ASAP7_75t_R   g253(.A1(new_n192_), .A2(new_n135_), .B(p3), .Y(new_n275_));
  AOI211x1_ASAP7_75t_R g254(.A1(new_n206_), .A2(new_n269_), .B(new_n274_), .C(new_n275_), .Y(new_n276_));
  OAI21x1_ASAP7_75t_R  g255(.A1(new_n59_), .A2(new_n272_), .B(new_n276_), .Y(new_n277_));
  NAND2x1_ASAP7_75t_R  g256(.A(p7), .B(p8), .Y(new_n278_));
  OA211x2_ASAP7_75t_R  g257(.A1(new_n278_), .A2(new_n181_), .B(p3), .C(new_n105_), .Y(new_n279_));
  NOR2x1_ASAP7_75t_R   g258(.A(new_n236_), .B(new_n279_), .Y(new_n280_));
  AOI22x1_ASAP7_75t_R  g259(.A1(new_n267_), .A2(new_n212_), .B1(new_n277_), .B2(new_n280_), .Y(new_n281_));
  AOI21x1_ASAP7_75t_R  g260(.A1(new_n254_), .A2(new_n281_), .B(p6), .Y(o3));
  OA211x2_ASAP7_75t_R  g261(.A1(p0), .A2(p9), .B(new_n212_), .C(p1), .Y(new_n283_));
  NOR2x1_ASAP7_75t_R   g262(.A(p3), .B(new_n40_), .Y(new_n284_));
  NOR2x1_ASAP7_75t_R   g263(.A(p2), .B(new_n212_), .Y(new_n285_));
  OA21x2_ASAP7_75t_R   g264(.A1(new_n284_), .A2(new_n285_), .B(new_n60_), .Y(new_n286_));
  NOR2x1_ASAP7_75t_R   g265(.A(p6), .B(new_n105_), .Y(new_n287_));
  OA21x2_ASAP7_75t_R   g266(.A1(new_n283_), .A2(new_n286_), .B(new_n287_), .Y(o4));
  AND3x1_ASAP7_75t_R   g267(.A(new_n74_), .B(new_n91_), .C(p3), .Y(new_n289_));
  INVx1_ASAP7_75t_R    g268(.A(new_n161_), .Y(new_n290_));
  OA21x2_ASAP7_75t_R   g269(.A1(p0), .A2(new_n290_), .B(new_n284_), .Y(new_n291_));
  OA21x2_ASAP7_75t_R   g270(.A1(new_n289_), .A2(new_n291_), .B(new_n287_), .Y(o5));
  AO21x1_ASAP7_75t_R   g271(.A1(new_n22_), .A2(new_n41_), .B(new_n273_), .Y(new_n293_));
  NOR3x1_ASAP7_75t_R   g272(.A(new_n191_), .B(new_n24_), .C(new_n126_), .Y(new_n294_));
  OA21x2_ASAP7_75t_R   g273(.A1(p0), .A2(new_n156_), .B(p9), .Y(new_n295_));
  AOI22x1_ASAP7_75t_R  g274(.A1(new_n293_), .A2(new_n294_), .B1(new_n185_), .B2(new_n295_), .Y(new_n296_));
  NOR2x1_ASAP7_75t_R   g275(.A(p9), .B(new_n36_), .Y(new_n297_));
  OAI22x1_ASAP7_75t_R  g276(.A1(new_n297_), .A2(new_n53_), .B1(new_n85_), .B2(new_n33_), .Y(new_n298_));
  NAND2x1_ASAP7_75t_R  g277(.A(new_n29_), .B(new_n41_), .Y(new_n299_));
  AND3x1_ASAP7_75t_R   g278(.A(new_n87_), .B(new_n299_), .C(new_n196_), .Y(new_n300_));
  AOI21x1_ASAP7_75t_R  g279(.A1(p8), .A2(new_n298_), .B(new_n300_), .Y(new_n301_));
  OAI21x1_ASAP7_75t_R  g280(.A1(p4), .A2(new_n296_), .B(new_n301_), .Y(new_n302_));
  AO21x1_ASAP7_75t_R   g281(.A1(p1), .A2(new_n79_), .B(p5), .Y(new_n303_));
  AOI211x1_ASAP7_75t_R g282(.A1(p8), .A2(new_n41_), .B(new_n79_), .C(p1), .Y(new_n304_));
  OAI21x1_ASAP7_75t_R  g283(.A1(p7), .A2(p8), .B(p1), .Y(new_n305_));
  NAND3x1_ASAP7_75t_R  g284(.A(p7), .B(p9), .C(p8), .Y(new_n306_));
  AOI21x1_ASAP7_75t_R  g285(.A1(new_n305_), .A2(new_n306_), .B(new_n22_), .Y(new_n307_));
  AOI221x1_ASAP7_75t_R g286(.A1(new_n56_), .A2(new_n303_), .B1(new_n65_), .B2(new_n304_), .C(new_n307_), .Y(new_n308_));
  OAI21x1_ASAP7_75t_R  g287(.A1(new_n29_), .A2(new_n307_), .B(p0), .Y(new_n309_));
  NAND2x1_ASAP7_75t_R  g288(.A(new_n49_), .B(new_n255_), .Y(new_n310_));
  OR3x1_ASAP7_75t_R    g289(.A(new_n163_), .B(p9), .C(new_n37_), .Y(new_n311_));
  AO21x1_ASAP7_75t_R   g290(.A1(new_n310_), .A2(new_n311_), .B(p0), .Y(new_n312_));
  AND3x1_ASAP7_75t_R   g291(.A(new_n311_), .B(new_n41_), .C(new_n217_), .Y(new_n313_));
  OAI22x1_ASAP7_75t_R  g292(.A1(new_n308_), .A2(new_n309_), .B1(new_n312_), .B2(new_n313_), .Y(new_n314_));
  AOI21x1_ASAP7_75t_R  g293(.A1(p2), .A2(new_n302_), .B(new_n314_), .Y(new_n315_));
  AO21x1_ASAP7_75t_R   g294(.A1(new_n191_), .A2(new_n117_), .B(new_n156_), .Y(new_n316_));
  AO21x1_ASAP7_75t_R   g295(.A1(p6), .A2(new_n37_), .B(new_n29_), .Y(new_n317_));
  AO21x1_ASAP7_75t_R   g296(.A1(new_n54_), .A2(new_n317_), .B(new_n38_), .Y(new_n318_));
  AO32x1_ASAP7_75t_R   g297(.A1(p6), .A2(new_n36_), .A3(new_n316_), .B1(new_n318_), .B2(new_n41_), .Y(new_n319_));
  AND3x1_ASAP7_75t_R   g298(.A(new_n79_), .B(new_n40_), .C(new_n22_), .Y(new_n320_));
  NAND3x1_ASAP7_75t_R  g299(.A(p7), .B(p1), .C(p8), .Y(new_n321_));
  AOI21x1_ASAP7_75t_R  g300(.A1(new_n321_), .A2(new_n208_), .B(new_n22_), .Y(new_n322_));
  AOI21x1_ASAP7_75t_R  g301(.A1(new_n270_), .A2(new_n163_), .B(new_n47_), .Y(new_n323_));
  AOI211x1_ASAP7_75t_R g302(.A1(new_n134_), .A2(new_n160_), .B(new_n322_), .C(new_n323_), .Y(new_n324_));
  AND3x1_ASAP7_75t_R   g303(.A(new_n66_), .B(p7), .C(new_n41_), .Y(new_n325_));
  AND5x1_ASAP7_75t_R   g304(.A(p7), .B(new_n78_), .C(new_n103_), .D(new_n270_), .E(p9), .Y(new_n326_));
  AOI211x1_ASAP7_75t_R g305(.A1(p4), .A2(new_n240_), .B(new_n325_), .C(new_n326_), .Y(new_n327_));
  AOI21x1_ASAP7_75t_R  g306(.A1(new_n324_), .A2(new_n327_), .B(p6), .Y(new_n328_));
  AOI22x1_ASAP7_75t_R  g307(.A1(new_n319_), .A2(new_n320_), .B1(new_n328_), .B2(new_n40_), .Y(new_n329_));
  OAI21x1_ASAP7_75t_R  g308(.A1(p6), .A2(new_n315_), .B(new_n329_), .Y(new_n330_));
  AO21x1_ASAP7_75t_R   g309(.A1(new_n70_), .A2(new_n289_), .B(new_n287_), .Y(new_n331_));
  AOI21x1_ASAP7_75t_R  g310(.A1(new_n212_), .A2(new_n330_), .B(new_n331_), .Y(o6));
  NAND2x1_ASAP7_75t_R  g311(.A(new_n25_), .B(new_n278_), .Y(new_n333_));
  AND3x1_ASAP7_75t_R   g312(.A(p4), .B(p2), .C(p9), .Y(new_n334_));
  OAI22x1_ASAP7_75t_R  g313(.A1(new_n333_), .A2(new_n156_), .B1(new_n66_), .B2(new_n334_), .Y(new_n335_));
  AND3x1_ASAP7_75t_R   g314(.A(p7), .B(p1), .C(p8), .Y(new_n336_));
  AOI22x1_ASAP7_75t_R  g315(.A1(new_n76_), .A2(new_n189_), .B1(new_n142_), .B2(new_n336_), .Y(new_n337_));
  OA21x2_ASAP7_75t_R   g316(.A1(p0), .A2(new_n335_), .B(new_n337_), .Y(new_n338_));
  AO21x1_ASAP7_75t_R   g317(.A1(p1), .A2(p8), .B(new_n41_), .Y(new_n339_));
  NOR2x1_ASAP7_75t_R   g318(.A(p9), .B(p8), .Y(new_n340_));
  OAI21x1_ASAP7_75t_R  g319(.A1(new_n29_), .A2(new_n340_), .B(p4), .Y(new_n341_));
  OAI21x1_ASAP7_75t_R  g320(.A1(new_n255_), .A2(new_n339_), .B(new_n341_), .Y(new_n342_));
  NOR3x1_ASAP7_75t_R   g321(.A(new_n98_), .B(new_n156_), .C(p2), .Y(new_n343_));
  OA21x2_ASAP7_75t_R   g322(.A1(new_n36_), .A2(p8), .B(new_n141_), .Y(new_n344_));
  NAND2x1_ASAP7_75t_R  g323(.A(p4), .B(new_n36_), .Y(new_n345_));
  NAND2x1_ASAP7_75t_R  g324(.A(p2), .B(new_n278_), .Y(new_n346_));
  OAI22x1_ASAP7_75t_R  g325(.A1(new_n344_), .A2(new_n299_), .B1(new_n345_), .B2(new_n346_), .Y(new_n347_));
  AOI21x1_ASAP7_75t_R  g326(.A1(new_n342_), .A2(new_n343_), .B(new_n347_), .Y(new_n348_));
  AO31x2_ASAP7_75t_R   g327(.A1(new_n337_), .A2(new_n335_), .A3(new_n59_), .B(p5), .Y(new_n349_));
  AOI21x1_ASAP7_75t_R  g328(.A1(new_n338_), .A2(new_n348_), .B(new_n349_), .Y(new_n350_));
  NOR2x1_ASAP7_75t_R   g329(.A(new_n79_), .B(new_n350_), .Y(new_n351_));
  NAND2x1_ASAP7_75t_R  g330(.A(new_n70_), .B(new_n212_), .Y(new_n352_));
  AOI21x1_ASAP7_75t_R  g331(.A1(new_n23_), .A2(new_n217_), .B(new_n37_), .Y(new_n353_));
  NAND2x1_ASAP7_75t_R  g332(.A(new_n130_), .B(new_n217_), .Y(new_n354_));
  AO21x1_ASAP7_75t_R   g333(.A1(p5), .A2(p8), .B(p7), .Y(new_n355_));
  OA21x2_ASAP7_75t_R   g334(.A1(p5), .A2(p9), .B(new_n355_), .Y(new_n356_));
  NOR2x1_ASAP7_75t_R   g335(.A(p5), .B(new_n40_), .Y(new_n357_));
  NOR2x1_ASAP7_75t_R   g336(.A(new_n56_), .B(new_n357_), .Y(new_n358_));
  AOI22x1_ASAP7_75t_R  g337(.A1(new_n353_), .A2(new_n354_), .B1(new_n356_), .B2(new_n358_), .Y(new_n359_));
  NOR2x1_ASAP7_75t_R   g338(.A(p5), .B(new_n36_), .Y(new_n360_));
  AO21x1_ASAP7_75t_R   g339(.A1(p2), .A2(new_n278_), .B(new_n117_), .Y(new_n361_));
  AO32x1_ASAP7_75t_R   g340(.A1(new_n22_), .A2(new_n37_), .A3(new_n184_), .B1(new_n336_), .B2(new_n40_), .Y(new_n362_));
  AOI21x1_ASAP7_75t_R  g341(.A1(new_n360_), .A2(new_n361_), .B(new_n362_), .Y(new_n363_));
  OAI21x1_ASAP7_75t_R  g342(.A1(p1), .A2(new_n359_), .B(new_n363_), .Y(new_n364_));
  OA211x2_ASAP7_75t_R  g343(.A1(new_n156_), .A2(new_n155_), .B(p5), .C(new_n41_), .Y(new_n365_));
  NOR3x1_ASAP7_75t_R   g344(.A(new_n46_), .B(p5), .C(new_n155_), .Y(new_n366_));
  OAI21x1_ASAP7_75t_R  g345(.A1(new_n365_), .A2(new_n366_), .B(new_n206_), .Y(new_n367_));
  INVx1_ASAP7_75t_R    g346(.A(new_n163_), .Y(new_n368_));
  OAI22x1_ASAP7_75t_R  g347(.A1(new_n368_), .A2(new_n35_), .B1(p5), .B2(new_n184_), .Y(new_n369_));
  NAND2x1_ASAP7_75t_R  g348(.A(new_n161_), .B(new_n156_), .Y(new_n370_));
  OR3x1_ASAP7_75t_R    g349(.A(new_n138_), .B(new_n29_), .C(p8), .Y(new_n371_));
  AO31x2_ASAP7_75t_R   g350(.A1(new_n369_), .A2(new_n370_), .A3(new_n371_), .B(p0), .Y(new_n372_));
  OR3x1_ASAP7_75t_R    g351(.A(new_n208_), .B(new_n40_), .C(new_n22_), .Y(new_n373_));
  NAND3x1_ASAP7_75t_R  g352(.A(new_n367_), .B(new_n372_), .C(new_n373_), .Y(new_n374_));
  AOI211x1_ASAP7_75t_R g353(.A1(p0), .A2(new_n364_), .B(new_n374_), .C(new_n350_), .Y(new_n375_));
  NOR2x1_ASAP7_75t_R   g354(.A(p8), .B(new_n70_), .Y(new_n376_));
  AO32x1_ASAP7_75t_R   g355(.A1(p9), .A2(new_n176_), .A3(new_n376_), .B1(new_n201_), .B2(new_n297_), .Y(new_n377_));
  AND3x1_ASAP7_75t_R   g356(.A(new_n28_), .B(new_n180_), .C(new_n212_), .Y(new_n378_));
  AND3x1_ASAP7_75t_R   g357(.A(new_n289_), .B(new_n70_), .C(new_n79_), .Y(new_n379_));
  AOI22x1_ASAP7_75t_R  g358(.A1(new_n377_), .A2(new_n378_), .B1(new_n22_), .B2(new_n379_), .Y(new_n380_));
  OA31x2_ASAP7_75t_R   g359(.A1(new_n351_), .A2(new_n352_), .A3(new_n375_), .B1(new_n380_), .Y(o7));
  OA211x2_ASAP7_75t_R  g360(.A1(new_n41_), .A2(new_n176_), .B(new_n28_), .C(new_n180_), .Y(new_n382_));
  OAI21x1_ASAP7_75t_R  g361(.A1(new_n176_), .A2(new_n140_), .B(new_n340_), .Y(new_n383_));
  AO21x1_ASAP7_75t_R   g362(.A1(p1), .A2(new_n29_), .B(new_n37_), .Y(new_n384_));
  AND3x1_ASAP7_75t_R   g363(.A(new_n191_), .B(new_n41_), .C(new_n98_), .Y(new_n385_));
  AO32x1_ASAP7_75t_R   g364(.A1(new_n382_), .A2(new_n383_), .A3(new_n384_), .B1(new_n320_), .B2(new_n385_), .Y(new_n386_));
  OA21x2_ASAP7_75t_R   g365(.A1(new_n70_), .A2(new_n386_), .B(new_n212_), .Y(new_n387_));
  AO21x1_ASAP7_75t_R   g366(.A1(new_n59_), .A2(p4), .B(new_n95_), .Y(new_n388_));
  NOR2x1_ASAP7_75t_R   g367(.A(p1), .B(new_n24_), .Y(new_n389_));
  NAND2x1_ASAP7_75t_R  g368(.A(p8), .B(new_n40_), .Y(new_n390_));
  AND3x1_ASAP7_75t_R   g369(.A(new_n388_), .B(new_n389_), .C(new_n390_), .Y(new_n391_));
  NAND2x1_ASAP7_75t_R  g370(.A(new_n24_), .B(new_n248_), .Y(new_n392_));
  AOI21x1_ASAP7_75t_R  g371(.A1(new_n218_), .A2(new_n392_), .B(p9), .Y(new_n393_));
  AO32x1_ASAP7_75t_R   g372(.A1(new_n79_), .A2(p1), .A3(new_n28_), .B1(new_n99_), .B2(new_n202_), .Y(new_n394_));
  OA31x2_ASAP7_75t_R   g373(.A1(new_n391_), .A2(new_n393_), .A3(new_n394_), .B1(new_n149_), .Y(new_n395_));
  NOR2x1_ASAP7_75t_R   g374(.A(p9), .B(new_n29_), .Y(new_n396_));
  OA211x2_ASAP7_75t_R  g375(.A1(p4), .A2(new_n396_), .B(new_n273_), .C(new_n141_), .Y(new_n397_));
  AND3x1_ASAP7_75t_R   g376(.A(new_n117_), .B(new_n79_), .C(new_n28_), .Y(new_n398_));
  AND3x1_ASAP7_75t_R   g377(.A(new_n388_), .B(new_n42_), .C(new_n176_), .Y(new_n399_));
  OA31x2_ASAP7_75t_R   g378(.A1(new_n397_), .A2(new_n398_), .A3(new_n399_), .B1(new_n103_), .Y(new_n400_));
  AO21x1_ASAP7_75t_R   g379(.A1(p8), .A2(new_n59_), .B(new_n22_), .Y(new_n401_));
  AOI21x1_ASAP7_75t_R  g380(.A1(new_n185_), .A2(new_n396_), .B(new_n401_), .Y(new_n402_));
  AO21x1_ASAP7_75t_R   g381(.A1(p0), .A2(new_n29_), .B(p5), .Y(new_n403_));
  OA21x2_ASAP7_75t_R   g382(.A1(new_n403_), .A2(new_n295_), .B(new_n125_), .Y(new_n404_));
  OA21x2_ASAP7_75t_R   g383(.A1(p1), .A2(new_n402_), .B(new_n404_), .Y(new_n405_));
  NAND2x1_ASAP7_75t_R  g384(.A(p1), .B(new_n79_), .Y(new_n406_));
  AO221x2_ASAP7_75t_R  g385(.A1(new_n226_), .A2(p2), .B1(new_n141_), .B2(new_n406_), .C(new_n59_), .Y(new_n407_));
  OR3x1_ASAP7_75t_R    g386(.A(new_n207_), .B(new_n120_), .C(new_n226_), .Y(new_n408_));
  AOI21x1_ASAP7_75t_R  g387(.A1(new_n407_), .A2(new_n408_), .B(new_n269_), .Y(new_n409_));
  OR5x1_ASAP7_75t_R    g388(.A(new_n395_), .B(new_n386_), .C(new_n400_), .D(new_n405_), .E(new_n409_), .Y(new_n410_));
  AOI21x1_ASAP7_75t_R  g389(.A1(new_n387_), .A2(new_n410_), .B(new_n379_), .Y(o8));
  AO21x1_ASAP7_75t_R   g390(.A1(new_n285_), .A2(new_n181_), .B(p1), .Y(new_n412_));
  AO21x1_ASAP7_75t_R   g391(.A1(p2), .A2(new_n37_), .B(new_n357_), .Y(new_n413_));
  OA21x2_ASAP7_75t_R   g392(.A1(new_n130_), .A2(new_n259_), .B(new_n413_), .Y(new_n414_));
  OR4x2_ASAP7_75t_R    g393(.A(new_n305_), .B(new_n61_), .C(new_n27_), .D(p2), .Y(new_n415_));
  OA21x2_ASAP7_75t_R   g394(.A1(new_n412_), .A2(new_n414_), .B(new_n415_), .Y(new_n416_));
  OA21x2_ASAP7_75t_R   g395(.A1(p2), .A2(new_n61_), .B(new_n130_), .Y(new_n417_));
  OR3x1_ASAP7_75t_R    g396(.A(new_n413_), .B(new_n417_), .C(p1), .Y(new_n418_));
  AO21x1_ASAP7_75t_R   g397(.A1(p7), .A2(p8), .B(p4), .Y(new_n419_));
  OR3x1_ASAP7_75t_R    g398(.A(new_n259_), .B(p2), .C(new_n149_), .Y(new_n420_));
  OA21x2_ASAP7_75t_R   g399(.A1(new_n419_), .A2(new_n262_), .B(new_n420_), .Y(new_n421_));
  AO21x1_ASAP7_75t_R   g400(.A1(new_n418_), .A2(new_n421_), .B(new_n59_), .Y(new_n422_));
  AND3x1_ASAP7_75t_R   g401(.A(new_n357_), .B(new_n121_), .C(p1), .Y(new_n423_));
  OAI22x1_ASAP7_75t_R  g402(.A1(new_n423_), .A2(p6), .B1(p0), .B2(new_n156_), .Y(new_n424_));
  OAI21x1_ASAP7_75t_R  g403(.A1(p4), .A2(new_n202_), .B(p5), .Y(new_n425_));
  AO21x1_ASAP7_75t_R   g404(.A1(new_n41_), .A2(new_n202_), .B(new_n70_), .Y(new_n426_));
  OR3x1_ASAP7_75t_R    g405(.A(new_n75_), .B(p0), .C(new_n41_), .Y(new_n427_));
  AND5x1_ASAP7_75t_R   g406(.A(new_n424_), .B(new_n235_), .C(new_n425_), .D(new_n426_), .E(new_n427_), .Y(new_n428_));
  OA211x2_ASAP7_75t_R  g407(.A1(p0), .A2(new_n416_), .B(new_n422_), .C(new_n428_), .Y(o9));
  OA211x2_ASAP7_75t_R  g408(.A1(p0), .A2(new_n55_), .B(new_n284_), .C(p1), .Y(new_n430_));
  AND3x1_ASAP7_75t_R   g409(.A(new_n70_), .B(new_n79_), .C(new_n22_), .Y(new_n431_));
  AO21x1_ASAP7_75t_R   g410(.A1(p0), .A2(new_n47_), .B(new_n29_), .Y(new_n432_));
  AO32x1_ASAP7_75t_R   g411(.A1(new_n430_), .A2(new_n431_), .A3(new_n432_), .B1(new_n379_), .B2(new_n22_), .Y(o10));
endmodule


