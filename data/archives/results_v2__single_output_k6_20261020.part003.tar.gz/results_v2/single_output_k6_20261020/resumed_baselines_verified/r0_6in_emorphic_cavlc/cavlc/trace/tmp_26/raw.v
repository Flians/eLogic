// Benchmark "/tmp/" written by ABC on Tue Oct 20 17:20:36 2026

module \/tmp/  ( 
    p5, p0, p8, p9, p6, p3, p7, p1, p2, p4,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10  );
  input  p5, p0, p8, p9, p6, p3, p7, p1, p2, p4;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10;
  wire new_n22_, new_n23_, new_n24_, new_n25_, new_n26_, new_n27_, new_n28_,
    new_n29_, new_n30_, new_n31_, new_n32_, new_n33_, new_n34_, new_n35_,
    new_n36_, new_n37_, new_n38_, new_n39_, new_n40_, new_n41_, new_n42_,
    new_n43_, new_n44_, new_n45_, new_n46_, new_n47_, new_n48_, new_n49_,
    new_n50_, new_n51_, new_n52_, new_n53_, new_n54_, new_n55_, new_n56_,
    new_n57_, new_n58_, new_n59_, new_n60_, new_n61_, new_n62_, new_n63_,
    new_n64_, new_n65_, new_n66_, new_n67_, new_n68_, new_n69_, new_n70_,
    new_n71_, new_n72_, new_n73_, new_n74_, new_n75_, new_n76_, new_n77_,
    new_n78_, new_n79_, new_n80_, new_n81_, new_n82_, new_n83_, new_n84_,
    new_n85_, new_n86_, new_n87_, new_n88_, new_n89_, new_n90_, new_n91_,
    new_n92_, new_n93_, new_n94_, new_n95_, new_n96_, new_n97_, new_n98_,
    new_n99_, new_n100_, new_n101_, new_n102_, new_n103_, new_n104_,
    new_n105_, new_n106_, new_n107_, new_n108_, new_n109_, new_n110_,
    new_n111_, new_n112_, new_n114_, new_n115_, new_n116_, new_n117_,
    new_n118_, new_n119_, new_n120_, new_n121_, new_n122_, new_n123_,
    new_n124_, new_n125_, new_n126_, new_n127_, new_n128_, new_n129_,
    new_n130_, new_n131_, new_n132_, new_n133_, new_n134_, new_n135_,
    new_n136_, new_n137_, new_n138_, new_n139_, new_n140_, new_n141_,
    new_n142_, new_n143_, new_n144_, new_n145_, new_n146_, new_n147_,
    new_n148_, new_n149_, new_n150_, new_n151_, new_n152_, new_n153_,
    new_n154_, new_n155_, new_n156_, new_n157_, new_n158_, new_n159_,
    new_n160_, new_n161_, new_n162_, new_n163_, new_n164_, new_n165_,
    new_n166_, new_n167_, new_n168_, new_n169_, new_n170_, new_n171_,
    new_n172_, new_n173_, new_n174_, new_n175_, new_n176_, new_n177_,
    new_n178_, new_n179_, new_n180_, new_n181_, new_n182_, new_n183_,
    new_n184_, new_n185_, new_n187_, new_n188_, new_n189_, new_n190_,
    new_n191_, new_n192_, new_n193_, new_n194_, new_n195_, new_n196_,
    new_n197_, new_n198_, new_n199_, new_n200_, new_n201_, new_n202_,
    new_n203_, new_n204_, new_n205_, new_n206_, new_n207_, new_n208_,
    new_n209_, new_n210_, new_n211_, new_n212_, new_n213_, new_n214_,
    new_n215_, new_n216_, new_n217_, new_n218_, new_n219_, new_n220_,
    new_n221_, new_n222_, new_n223_, new_n224_, new_n225_, new_n226_,
    new_n227_, new_n228_, new_n229_, new_n230_, new_n231_, new_n232_,
    new_n233_, new_n234_, new_n235_, new_n236_, new_n237_, new_n238_,
    new_n239_, new_n241_, new_n242_, new_n243_, new_n244_, new_n245_,
    new_n246_, new_n247_, new_n248_, new_n249_, new_n250_, new_n251_,
    new_n252_, new_n253_, new_n254_, new_n255_, new_n256_, new_n257_,
    new_n258_, new_n259_, new_n260_, new_n261_, new_n262_, new_n263_,
    new_n264_, new_n265_, new_n266_, new_n267_, new_n268_, new_n269_,
    new_n270_, new_n271_, new_n272_, new_n273_, new_n274_, new_n275_,
    new_n277_, new_n278_, new_n279_, new_n280_, new_n281_, new_n283_,
    new_n284_, new_n285_, new_n287_, new_n288_, new_n289_, new_n290_,
    new_n291_, new_n292_, new_n293_, new_n294_, new_n295_, new_n296_,
    new_n297_, new_n298_, new_n299_, new_n300_, new_n301_, new_n302_,
    new_n303_, new_n304_, new_n305_, new_n306_, new_n307_, new_n308_,
    new_n309_, new_n310_, new_n311_, new_n312_, new_n313_, new_n314_,
    new_n315_, new_n316_, new_n317_, new_n318_, new_n319_, new_n320_,
    new_n321_, new_n322_, new_n323_, new_n324_, new_n326_, new_n327_,
    new_n328_, new_n329_, new_n330_, new_n331_, new_n332_, new_n333_,
    new_n334_, new_n335_, new_n336_, new_n337_, new_n338_, new_n339_,
    new_n340_, new_n341_, new_n342_, new_n343_, new_n344_, new_n345_,
    new_n346_, new_n347_, new_n348_, new_n349_, new_n350_, new_n351_,
    new_n352_, new_n353_, new_n354_, new_n355_, new_n356_, new_n357_,
    new_n358_, new_n359_, new_n360_, new_n361_, new_n362_, new_n363_,
    new_n364_, new_n365_, new_n366_, new_n367_, new_n368_, new_n369_,
    new_n370_, new_n372_, new_n373_, new_n374_, new_n375_, new_n376_,
    new_n377_, new_n378_, new_n379_, new_n380_, new_n381_, new_n382_,
    new_n383_, new_n384_, new_n385_, new_n386_, new_n387_, new_n388_,
    new_n389_, new_n390_, new_n391_, new_n392_, new_n393_, new_n394_,
    new_n395_, new_n396_, new_n397_, new_n398_, new_n399_, new_n400_,
    new_n401_, new_n403_, new_n404_, new_n405_, new_n406_, new_n407_,
    new_n408_, new_n409_, new_n410_, new_n411_, new_n412_, new_n413_,
    new_n414_, new_n415_, new_n416_, new_n417_, new_n418_, new_n419_,
    new_n421_, new_n422_, new_n423_;
  INVx1_ASAP7_75t_R    g000(.A(p8), .Y(new_n22_));
  NOR2x1_ASAP7_75t_R   g001(.A(p9), .B(new_n22_), .Y(new_n23_));
  INVx1_ASAP7_75t_R    g002(.A(p2), .Y(new_n24_));
  NAND2x1_ASAP7_75t_R  g003(.A(p0), .B(new_n24_), .Y(new_n25_));
  INVx1_ASAP7_75t_R    g004(.A(p9), .Y(new_n26_));
  NOR2x1_ASAP7_75t_R   g005(.A(p8), .B(new_n26_), .Y(new_n27_));
  NOR2x1_ASAP7_75t_R   g006(.A(p1), .B(new_n27_), .Y(new_n28_));
  OA21x2_ASAP7_75t_R   g007(.A1(new_n23_), .A2(new_n25_), .B(new_n28_), .Y(new_n29_));
  INVx1_ASAP7_75t_R    g008(.A(p5), .Y(new_n30_));
  INVx1_ASAP7_75t_R    g009(.A(new_n28_), .Y(new_n31_));
  NAND2x1_ASAP7_75t_R  g010(.A(p7), .B(p4), .Y(new_n32_));
  AO21x1_ASAP7_75t_R   g011(.A1(new_n30_), .A2(new_n31_), .B(new_n32_), .Y(new_n33_));
  NOR2x1_ASAP7_75t_R   g012(.A(p7), .B(p4), .Y(new_n34_));
  NAND2x1_ASAP7_75t_R  g013(.A(p2), .B(new_n30_), .Y(new_n35_));
  NOR2x1_ASAP7_75t_R   g014(.A(p0), .B(p8), .Y(new_n36_));
  NAND2x1_ASAP7_75t_R  g015(.A(p1), .B(p2), .Y(new_n37_));
  AO32x1_ASAP7_75t_R   g016(.A1(new_n35_), .A2(new_n36_), .A3(new_n37_), .B1(p8), .B2(p1), .Y(new_n38_));
  AND2x2_ASAP7_75t_R   g017(.A(p8), .B(p1), .Y(new_n39_));
  NOR2x1_ASAP7_75t_R   g018(.A(p0), .B(p2), .Y(new_n40_));
  INVx1_ASAP7_75t_R    g019(.A(p0), .Y(new_n41_));
  NOR2x1_ASAP7_75t_R   g020(.A(p7), .B(new_n41_), .Y(new_n42_));
  AO21x1_ASAP7_75t_R   g021(.A1(new_n39_), .A2(new_n40_), .B(new_n42_), .Y(new_n43_));
  NOR2x1_ASAP7_75t_R   g022(.A(p9), .B(p4), .Y(new_n44_));
  AND2x2_ASAP7_75t_R   g023(.A(p5), .B(p7), .Y(new_n45_));
  AND3x1_ASAP7_75t_R   g024(.A(new_n45_), .B(new_n26_), .C(new_n24_), .Y(new_n46_));
  NOR2x1_ASAP7_75t_R   g025(.A(p8), .B(p1), .Y(new_n47_));
  AO21x1_ASAP7_75t_R   g026(.A1(p0), .A2(new_n47_), .B(new_n39_), .Y(new_n48_));
  NOR2x1_ASAP7_75t_R   g027(.A(p9), .B(p7), .Y(new_n49_));
  NOR2x1_ASAP7_75t_R   g028(.A(p1), .B(p2), .Y(new_n50_));
  AND3x1_ASAP7_75t_R   g029(.A(new_n49_), .B(new_n50_), .C(new_n36_), .Y(new_n51_));
  AO21x1_ASAP7_75t_R   g030(.A1(new_n46_), .A2(new_n48_), .B(new_n51_), .Y(new_n52_));
  AOI221x1_ASAP7_75t_R g031(.A1(new_n34_), .A2(new_n38_), .B1(new_n43_), .B2(new_n44_), .C(new_n52_), .Y(new_n53_));
  OAI21x1_ASAP7_75t_R  g032(.A1(new_n29_), .A2(new_n33_), .B(new_n53_), .Y(new_n54_));
  INVx1_ASAP7_75t_R    g033(.A(new_n42_), .Y(new_n55_));
  INVx1_ASAP7_75t_R    g034(.A(p1), .Y(new_n56_));
  NOR2x1_ASAP7_75t_R   g035(.A(p0), .B(new_n56_), .Y(new_n57_));
  INVx1_ASAP7_75t_R    g036(.A(p7), .Y(new_n58_));
  AOI22x1_ASAP7_75t_R  g037(.A1(new_n27_), .A2(new_n57_), .B1(new_n23_), .B2(new_n58_), .Y(new_n59_));
  AO21x1_ASAP7_75t_R   g038(.A1(new_n55_), .A2(new_n59_), .B(p4), .Y(new_n60_));
  INVx1_ASAP7_75t_R    g039(.A(new_n27_), .Y(new_n61_));
  NAND2x1_ASAP7_75t_R  g040(.A(p8), .B(new_n26_), .Y(new_n62_));
  AND5x1_ASAP7_75t_R   g041(.A(p0), .B(new_n61_), .C(p1), .D(p4), .E(new_n62_), .Y(new_n63_));
  AND3x1_ASAP7_75t_R   g042(.A(new_n41_), .B(new_n26_), .C(new_n56_), .Y(new_n64_));
  NOR2x1_ASAP7_75t_R   g043(.A(p8), .B(p4), .Y(new_n65_));
  INVx1_ASAP7_75t_R    g044(.A(new_n65_), .Y(new_n66_));
  OA211x2_ASAP7_75t_R  g045(.A1(p4), .A2(new_n64_), .B(new_n66_), .C(new_n45_), .Y(new_n67_));
  AOI21x1_ASAP7_75t_R  g046(.A1(p7), .A2(new_n63_), .B(new_n67_), .Y(new_n68_));
  AOI21x1_ASAP7_75t_R  g047(.A1(new_n60_), .A2(new_n68_), .B(new_n24_), .Y(new_n69_));
  NOR2x1_ASAP7_75t_R   g048(.A(p6), .B(p3), .Y(new_n70_));
  OAI21x1_ASAP7_75t_R  g049(.A1(new_n54_), .A2(new_n69_), .B(new_n70_), .Y(new_n71_));
  NOR2x1_ASAP7_75t_R   g050(.A(p5), .B(p3), .Y(new_n72_));
  NOR2x1_ASAP7_75t_R   g051(.A(p8), .B(p9), .Y(new_n73_));
  INVx1_ASAP7_75t_R    g052(.A(p4), .Y(new_n74_));
  AO21x1_ASAP7_75t_R   g053(.A1(new_n22_), .A2(new_n74_), .B(p0), .Y(new_n75_));
  NOR2x1_ASAP7_75t_R   g054(.A(p1), .B(new_n26_), .Y(new_n76_));
  AO32x1_ASAP7_75t_R   g055(.A1(p6), .A2(new_n57_), .A3(new_n73_), .B1(new_n75_), .B2(new_n76_), .Y(new_n77_));
  NOR2x1_ASAP7_75t_R   g056(.A(p4), .B(new_n58_), .Y(new_n78_));
  INVx1_ASAP7_75t_R    g057(.A(new_n78_), .Y(new_n79_));
  NAND2x1_ASAP7_75t_R  g058(.A(p9), .B(new_n56_), .Y(new_n80_));
  AO21x1_ASAP7_75t_R   g059(.A1(p6), .A2(new_n66_), .B(new_n80_), .Y(new_n81_));
  INVx1_ASAP7_75t_R    g060(.A(p6), .Y(new_n82_));
  NOR2x1_ASAP7_75t_R   g061(.A(p8), .B(new_n41_), .Y(new_n83_));
  AO21x1_ASAP7_75t_R   g062(.A1(new_n82_), .A2(new_n83_), .B(p2), .Y(new_n84_));
  AOI21x1_ASAP7_75t_R  g063(.A1(new_n79_), .A2(new_n81_), .B(new_n84_), .Y(new_n85_));
  NOR2x1_ASAP7_75t_R   g064(.A(p0), .B(new_n22_), .Y(new_n86_));
  INVx1_ASAP7_75t_R    g065(.A(new_n50_), .Y(new_n87_));
  AND3x1_ASAP7_75t_R   g066(.A(new_n41_), .B(p9), .C(p2), .Y(new_n88_));
  AOI221x1_ASAP7_75t_R g067(.A1(p0), .A2(new_n24_), .B1(new_n86_), .B2(new_n87_), .C(new_n88_), .Y(new_n89_));
  NAND2x1_ASAP7_75t_R  g068(.A(p0), .B(p1), .Y(new_n90_));
  AO21x1_ASAP7_75t_R   g069(.A1(new_n56_), .A2(new_n74_), .B(p9), .Y(new_n91_));
  AO21x1_ASAP7_75t_R   g070(.A1(new_n90_), .A2(new_n91_), .B(p8), .Y(new_n92_));
  AOI21x1_ASAP7_75t_R  g071(.A1(new_n89_), .A2(new_n92_), .B(p6), .Y(new_n93_));
  NAND2x1_ASAP7_75t_R  g072(.A(p0), .B(p9), .Y(new_n94_));
  NOR2x1_ASAP7_75t_R   g073(.A(p2), .B(p4), .Y(new_n95_));
  NOR2x1_ASAP7_75t_R   g074(.A(p0), .B(p9), .Y(new_n96_));
  NOR2x1_ASAP7_75t_R   g075(.A(p6), .B(new_n96_), .Y(new_n97_));
  AO21x1_ASAP7_75t_R   g076(.A1(new_n94_), .A2(new_n95_), .B(new_n97_), .Y(new_n98_));
  NOR2x1_ASAP7_75t_R   g077(.A(p7), .B(p1), .Y(new_n99_));
  XNOR2x2_ASAP7_75t_R  g078(.A(p0), .B(p8), .Y(new_n100_));
  AND3x1_ASAP7_75t_R   g079(.A(new_n98_), .B(new_n99_), .C(new_n100_), .Y(new_n101_));
  AO221x2_ASAP7_75t_R  g080(.A1(new_n77_), .A2(new_n85_), .B1(new_n93_), .B2(new_n58_), .C(new_n101_), .Y(new_n102_));
  NOR2x1_ASAP7_75t_R   g081(.A(p5), .B(p8), .Y(new_n103_));
  INVx1_ASAP7_75t_R    g082(.A(new_n103_), .Y(new_n104_));
  NAND2x1_ASAP7_75t_R  g083(.A(p5), .B(p4), .Y(new_n105_));
  OA21x2_ASAP7_75t_R   g084(.A1(new_n22_), .A2(p3), .B(new_n105_), .Y(new_n106_));
  NAND2x1_ASAP7_75t_R  g085(.A(p4), .B(new_n58_), .Y(new_n107_));
  NAND2x1_ASAP7_75t_R  g086(.A(new_n105_), .B(new_n107_), .Y(new_n108_));
  AO21x1_ASAP7_75t_R   g087(.A1(p3), .A2(p7), .B(new_n103_), .Y(new_n109_));
  AO32x1_ASAP7_75t_R   g088(.A1(new_n58_), .A2(new_n104_), .A3(new_n106_), .B1(new_n108_), .B2(new_n109_), .Y(new_n110_));
  AND5x1_ASAP7_75t_R   g089(.A(new_n26_), .B(new_n110_), .C(new_n82_), .D(new_n56_), .E(new_n40_), .Y(new_n111_));
  AOI21x1_ASAP7_75t_R  g090(.A1(new_n72_), .A2(new_n102_), .B(new_n111_), .Y(new_n112_));
  NAND2x1_ASAP7_75t_R  g091(.A(new_n71_), .B(new_n112_), .Y(o0));
  NAND2x1_ASAP7_75t_R  g092(.A(new_n82_), .B(new_n24_), .Y(new_n114_));
  NAND2x1_ASAP7_75t_R  g093(.A(p4), .B(new_n56_), .Y(new_n115_));
  OR3x1_ASAP7_75t_R    g094(.A(new_n62_), .B(new_n115_), .C(p7), .Y(new_n116_));
  NAND2x1_ASAP7_75t_R  g095(.A(p5), .B(p8), .Y(new_n117_));
  OA21x2_ASAP7_75t_R   g096(.A1(new_n58_), .A2(p4), .B(new_n117_), .Y(new_n118_));
  OR3x1_ASAP7_75t_R    g097(.A(new_n118_), .B(new_n45_), .C(new_n80_), .Y(new_n119_));
  AO21x1_ASAP7_75t_R   g098(.A1(new_n116_), .A2(new_n119_), .B(new_n41_), .Y(new_n120_));
  NAND2x1_ASAP7_75t_R  g099(.A(p1), .B(new_n26_), .Y(new_n121_));
  NAND2x1_ASAP7_75t_R  g100(.A(new_n47_), .B(new_n49_), .Y(new_n122_));
  OAI22x1_ASAP7_75t_R  g101(.A1(new_n118_), .A2(new_n121_), .B1(new_n74_), .B2(new_n122_), .Y(new_n123_));
  INVx1_ASAP7_75t_R    g102(.A(new_n117_), .Y(new_n124_));
  NOR2x1_ASAP7_75t_R   g103(.A(new_n34_), .B(new_n124_), .Y(new_n125_));
  AO21x1_ASAP7_75t_R   g104(.A1(p8), .A2(new_n58_), .B(new_n56_), .Y(new_n126_));
  AND2x2_ASAP7_75t_R   g105(.A(p8), .B(p7), .Y(new_n127_));
  NAND2x1_ASAP7_75t_R  g106(.A(p9), .B(new_n127_), .Y(new_n128_));
  NAND2x1_ASAP7_75t_R  g107(.A(p1), .B(p4), .Y(new_n129_));
  OAI22x1_ASAP7_75t_R  g108(.A1(new_n125_), .A2(new_n126_), .B1(new_n128_), .B2(new_n129_), .Y(new_n130_));
  OAI21x1_ASAP7_75t_R  g109(.A1(new_n123_), .A2(new_n130_), .B(new_n41_), .Y(new_n131_));
  AO21x1_ASAP7_75t_R   g110(.A1(p5), .A2(new_n26_), .B(p1), .Y(new_n132_));
  NOR2x1_ASAP7_75t_R   g111(.A(p5), .B(p7), .Y(new_n133_));
  AOI21x1_ASAP7_75t_R  g112(.A1(new_n78_), .A2(new_n132_), .B(new_n133_), .Y(new_n134_));
  NAND2x1_ASAP7_75t_R  g113(.A(p0), .B(new_n22_), .Y(new_n135_));
  NAND2x1_ASAP7_75t_R  g114(.A(p7), .B(p1), .Y(new_n136_));
  OA22x2_ASAP7_75t_R   g115(.A1(new_n134_), .A2(new_n135_), .B1(new_n136_), .B2(new_n104_), .Y(new_n137_));
  NAND3x1_ASAP7_75t_R  g116(.A(new_n120_), .B(new_n131_), .C(new_n137_), .Y(new_n138_));
  INVx1_ASAP7_75t_R    g117(.A(p3), .Y(new_n139_));
  NOR2x1_ASAP7_75t_R   g118(.A(p7), .B(new_n74_), .Y(new_n140_));
  AND3x1_ASAP7_75t_R   g119(.A(new_n103_), .B(p3), .C(p7), .Y(new_n141_));
  AO221x2_ASAP7_75t_R  g120(.A1(p3), .A2(new_n124_), .B1(new_n103_), .B2(new_n140_), .C(new_n141_), .Y(new_n142_));
  AOI22x1_ASAP7_75t_R  g121(.A1(new_n138_), .A2(new_n139_), .B1(new_n64_), .B2(new_n142_), .Y(new_n143_));
  NAND2x1_ASAP7_75t_R  g122(.A(p2), .B(new_n56_), .Y(new_n144_));
  NOR2x1_ASAP7_75t_R   g123(.A(p0), .B(p7), .Y(new_n145_));
  INVx1_ASAP7_75t_R    g124(.A(new_n145_), .Y(new_n146_));
  NAND2x1_ASAP7_75t_R  g125(.A(p0), .B(p4), .Y(new_n147_));
  OA21x2_ASAP7_75t_R   g126(.A1(new_n144_), .A2(new_n146_), .B(new_n147_), .Y(new_n148_));
  OR3x1_ASAP7_75t_R    g127(.A(new_n148_), .B(new_n30_), .C(new_n26_), .Y(new_n149_));
  OR3x1_ASAP7_75t_R    g128(.A(new_n50_), .B(new_n95_), .C(new_n30_), .Y(new_n150_));
  AO21x1_ASAP7_75t_R   g129(.A1(new_n74_), .A2(new_n90_), .B(new_n150_), .Y(new_n151_));
  OR3x1_ASAP7_75t_R    g130(.A(new_n107_), .B(new_n41_), .C(new_n37_), .Y(new_n152_));
  AND3x1_ASAP7_75t_R   g131(.A(new_n151_), .B(p8), .C(new_n152_), .Y(new_n153_));
  INVx1_ASAP7_75t_R    g132(.A(new_n70_), .Y(new_n154_));
  AOI21x1_ASAP7_75t_R  g133(.A1(new_n149_), .A2(new_n153_), .B(new_n154_), .Y(new_n155_));
  NOR2x1_ASAP7_75t_R   g134(.A(p7), .B(p2), .Y(new_n156_));
  AO21x1_ASAP7_75t_R   g135(.A1(p7), .A2(new_n74_), .B(new_n156_), .Y(new_n157_));
  INVx1_ASAP7_75t_R    g136(.A(new_n99_), .Y(new_n158_));
  OA22x2_ASAP7_75t_R   g137(.A1(new_n157_), .A2(new_n26_), .B1(new_n74_), .B2(new_n158_), .Y(new_n159_));
  OR3x1_ASAP7_75t_R    g138(.A(new_n159_), .B(p5), .C(p0), .Y(new_n160_));
  NOR2x1_ASAP7_75t_R   g139(.A(p5), .B(p0), .Y(new_n161_));
  AND2x2_ASAP7_75t_R   g140(.A(p0), .B(p9), .Y(new_n162_));
  NOR2x1_ASAP7_75t_R   g141(.A(new_n161_), .B(new_n162_), .Y(new_n163_));
  NAND2x1_ASAP7_75t_R  g142(.A(p7), .B(new_n26_), .Y(new_n164_));
  NOR2x1_ASAP7_75t_R   g143(.A(p4), .B(new_n24_), .Y(new_n165_));
  AO32x1_ASAP7_75t_R   g144(.A1(new_n163_), .A2(new_n74_), .A3(new_n164_), .B1(new_n146_), .B2(new_n165_), .Y(new_n166_));
  AND3x1_ASAP7_75t_R   g145(.A(new_n41_), .B(p5), .C(p7), .Y(new_n167_));
  AO21x1_ASAP7_75t_R   g146(.A1(new_n165_), .A2(new_n167_), .B(p8), .Y(new_n168_));
  AOI21x1_ASAP7_75t_R  g147(.A1(new_n56_), .A2(new_n166_), .B(new_n168_), .Y(new_n169_));
  NAND2x1_ASAP7_75t_R  g148(.A(p4), .B(new_n26_), .Y(new_n170_));
  NAND2x1_ASAP7_75t_R  g149(.A(p9), .B(new_n74_), .Y(new_n171_));
  AO21x1_ASAP7_75t_R   g150(.A1(new_n170_), .A2(new_n171_), .B(new_n41_), .Y(new_n172_));
  NAND2x1_ASAP7_75t_R  g151(.A(p9), .B(p7), .Y(new_n173_));
  NOR2x1_ASAP7_75t_R   g152(.A(p1), .B(new_n173_), .Y(new_n174_));
  AO21x1_ASAP7_75t_R   g153(.A1(p7), .A2(p2), .B(p1), .Y(new_n175_));
  AOI22x1_ASAP7_75t_R  g154(.A1(new_n174_), .A2(p0), .B1(new_n26_), .B2(new_n175_), .Y(new_n176_));
  AO21x1_ASAP7_75t_R   g155(.A1(new_n172_), .A2(new_n176_), .B(p5), .Y(new_n177_));
  NAND3x1_ASAP7_75t_R  g156(.A(new_n160_), .B(new_n169_), .C(new_n177_), .Y(new_n178_));
  NOR2x1_ASAP7_75t_R   g157(.A(p1), .B(new_n58_), .Y(new_n179_));
  AO32x1_ASAP7_75t_R   g158(.A1(new_n83_), .A2(new_n179_), .A3(p6), .B1(new_n57_), .B2(new_n73_), .Y(new_n180_));
  OA211x2_ASAP7_75t_R  g159(.A1(new_n49_), .A2(new_n99_), .B(new_n90_), .C(p6), .Y(new_n181_));
  OA21x2_ASAP7_75t_R   g160(.A1(new_n162_), .A2(new_n31_), .B(new_n181_), .Y(new_n182_));
  AND3x1_ASAP7_75t_R   g161(.A(new_n95_), .B(new_n30_), .C(new_n139_), .Y(new_n183_));
  OA21x2_ASAP7_75t_R   g162(.A1(new_n180_), .A2(new_n182_), .B(new_n183_), .Y(new_n184_));
  AOI21x1_ASAP7_75t_R  g163(.A1(new_n155_), .A2(new_n178_), .B(new_n184_), .Y(new_n185_));
  OAI21x1_ASAP7_75t_R  g164(.A1(new_n114_), .A2(new_n143_), .B(new_n185_), .Y(o1));
  AO21x1_ASAP7_75t_R   g165(.A1(p7), .A2(new_n144_), .B(p4), .Y(new_n187_));
  NAND2x1_ASAP7_75t_R  g166(.A(p2), .B(p4), .Y(new_n188_));
  AO21x1_ASAP7_75t_R   g167(.A1(p7), .A2(new_n56_), .B(new_n188_), .Y(new_n189_));
  AND3x1_ASAP7_75t_R   g168(.A(new_n187_), .B(new_n83_), .C(new_n189_), .Y(new_n190_));
  NOR2x1_ASAP7_75t_R   g169(.A(p7), .B(new_n24_), .Y(new_n191_));
  NOR2x1_ASAP7_75t_R   g170(.A(p1), .B(new_n24_), .Y(new_n192_));
  AO21x1_ASAP7_75t_R   g171(.A1(new_n86_), .A2(new_n191_), .B(new_n192_), .Y(new_n193_));
  OR3x1_ASAP7_75t_R    g172(.A(new_n41_), .B(new_n58_), .C(p8), .Y(new_n194_));
  AND3x1_ASAP7_75t_R   g173(.A(new_n193_), .B(new_n104_), .C(new_n194_), .Y(new_n195_));
  NOR2x1_ASAP7_75t_R   g174(.A(p8), .B(p7), .Y(new_n196_));
  AND3x1_ASAP7_75t_R   g175(.A(new_n196_), .B(p5), .C(new_n74_), .Y(new_n197_));
  OA21x2_ASAP7_75t_R   g176(.A1(p8), .A2(new_n24_), .B(new_n30_), .Y(new_n198_));
  NAND2x1_ASAP7_75t_R  g177(.A(p2), .B(new_n58_), .Y(new_n199_));
  NAND2x1_ASAP7_75t_R  g178(.A(new_n135_), .B(new_n199_), .Y(new_n200_));
  AO22x1_ASAP7_75t_R   g179(.A1(new_n40_), .A2(new_n197_), .B1(new_n198_), .B2(new_n200_), .Y(new_n201_));
  AND2x2_ASAP7_75t_R   g180(.A(p5), .B(p1), .Y(new_n202_));
  AO21x1_ASAP7_75t_R   g181(.A1(p1), .A2(new_n58_), .B(new_n41_), .Y(new_n203_));
  OA211x2_ASAP7_75t_R  g182(.A1(new_n202_), .A2(new_n203_), .B(p4), .C(new_n175_), .Y(new_n204_));
  NAND2x1_ASAP7_75t_R  g183(.A(p5), .B(new_n58_), .Y(new_n205_));
  OR3x1_ASAP7_75t_R    g184(.A(new_n41_), .B(new_n22_), .C(p2), .Y(new_n206_));
  OAI21x1_ASAP7_75t_R  g185(.A1(new_n205_), .A2(new_n206_), .B(new_n139_), .Y(new_n207_));
  OR5x1_ASAP7_75t_R    g186(.A(new_n190_), .B(new_n195_), .C(new_n201_), .D(new_n204_), .E(new_n207_), .Y(new_n208_));
  NAND2x1_ASAP7_75t_R  g187(.A(p8), .B(p7), .Y(new_n209_));
  AO21x1_ASAP7_75t_R   g188(.A1(new_n209_), .A2(new_n205_), .B(p4), .Y(new_n210_));
  AO21x1_ASAP7_75t_R   g189(.A1(new_n41_), .A2(new_n50_), .B(new_n139_), .Y(new_n211_));
  OA211x2_ASAP7_75t_R  g190(.A1(new_n139_), .A2(new_n210_), .B(new_n26_), .C(new_n211_), .Y(new_n212_));
  NAND2x1_ASAP7_75t_R  g191(.A(p8), .B(p1), .Y(new_n213_));
  NOR2x1_ASAP7_75t_R   g192(.A(new_n74_), .B(new_n196_), .Y(new_n214_));
  AO221x2_ASAP7_75t_R  g193(.A1(new_n74_), .A2(new_n213_), .B1(new_n128_), .B2(new_n214_), .C(new_n25_), .Y(new_n215_));
  NOR2x1_ASAP7_75t_R   g194(.A(p2), .B(new_n56_), .Y(new_n216_));
  INVx1_ASAP7_75t_R    g195(.A(new_n196_), .Y(new_n217_));
  AO21x1_ASAP7_75t_R   g196(.A1(new_n209_), .A2(new_n217_), .B(new_n36_), .Y(new_n218_));
  NOR2x1_ASAP7_75t_R   g197(.A(p0), .B(new_n24_), .Y(new_n219_));
  OA211x2_ASAP7_75t_R  g198(.A1(new_n74_), .A2(new_n219_), .B(new_n58_), .C(new_n47_), .Y(new_n220_));
  INVx1_ASAP7_75t_R    g199(.A(new_n173_), .Y(new_n221_));
  AND3x1_ASAP7_75t_R   g200(.A(new_n87_), .B(new_n221_), .C(new_n86_), .Y(new_n222_));
  AOI221x1_ASAP7_75t_R g201(.A1(new_n216_), .A2(new_n218_), .B1(new_n220_), .B2(p9), .C(new_n222_), .Y(new_n223_));
  NAND2x1_ASAP7_75t_R  g202(.A(new_n215_), .B(new_n223_), .Y(new_n224_));
  AOI22x1_ASAP7_75t_R  g203(.A1(new_n208_), .A2(new_n212_), .B1(new_n72_), .B2(new_n224_), .Y(new_n225_));
  AND3x1_ASAP7_75t_R   g204(.A(new_n70_), .B(p9), .C(new_n74_), .Y(new_n226_));
  AO21x1_ASAP7_75t_R   g205(.A1(p7), .A2(new_n83_), .B(new_n45_), .Y(new_n227_));
  AO21x1_ASAP7_75t_R   g206(.A1(new_n135_), .A2(new_n156_), .B(new_n227_), .Y(new_n228_));
  NOR2x1_ASAP7_75t_R   g207(.A(p1), .B(new_n86_), .Y(new_n229_));
  NAND2x1_ASAP7_75t_R  g208(.A(p1), .B(new_n22_), .Y(new_n230_));
  AND3x1_ASAP7_75t_R   g209(.A(new_n22_), .B(new_n58_), .C(p1), .Y(new_n231_));
  AO21x1_ASAP7_75t_R   g210(.A1(p7), .A2(new_n230_), .B(new_n231_), .Y(new_n232_));
  NOR2x1_ASAP7_75t_R   g211(.A(new_n90_), .B(new_n117_), .Y(new_n233_));
  OR3x1_ASAP7_75t_R    g212(.A(new_n232_), .B(new_n167_), .C(new_n233_), .Y(new_n234_));
  AO22x1_ASAP7_75t_R   g213(.A1(new_n228_), .A2(new_n229_), .B1(p2), .B2(new_n234_), .Y(new_n235_));
  AO21x1_ASAP7_75t_R   g214(.A1(p6), .A2(new_n127_), .B(new_n26_), .Y(new_n236_));
  AO32x1_ASAP7_75t_R   g215(.A1(new_n236_), .A2(p0), .A3(new_n62_), .B1(new_n27_), .B2(new_n145_), .Y(new_n237_));
  AND3x1_ASAP7_75t_R   g216(.A(new_n237_), .B(new_n56_), .C(new_n183_), .Y(new_n238_));
  AOI21x1_ASAP7_75t_R  g217(.A1(new_n226_), .A2(new_n235_), .B(new_n238_), .Y(new_n239_));
  OAI21x1_ASAP7_75t_R  g218(.A1(p6), .A2(new_n225_), .B(new_n239_), .Y(o2));
  AO32x1_ASAP7_75t_R   g219(.A1(new_n99_), .A2(new_n161_), .A3(p4), .B1(p5), .B2(new_n95_), .Y(new_n241_));
  NAND2x1_ASAP7_75t_R  g220(.A(new_n27_), .B(new_n241_), .Y(new_n242_));
  NOR2x1_ASAP7_75t_R   g221(.A(p4), .B(new_n30_), .Y(new_n243_));
  NOR2x1_ASAP7_75t_R   g222(.A(p5), .B(new_n37_), .Y(new_n244_));
  AO21x1_ASAP7_75t_R   g223(.A1(new_n87_), .A2(new_n243_), .B(new_n244_), .Y(new_n245_));
  AO21x1_ASAP7_75t_R   g224(.A1(p8), .A2(new_n245_), .B(new_n197_), .Y(new_n246_));
  NAND2x1_ASAP7_75t_R  g225(.A(new_n41_), .B(new_n246_), .Y(new_n247_));
  OR3x1_ASAP7_75t_R    g226(.A(new_n194_), .B(new_n30_), .C(p4), .Y(new_n248_));
  INVx1_ASAP7_75t_R    g227(.A(new_n133_), .Y(new_n249_));
  AO21x1_ASAP7_75t_R   g228(.A1(new_n66_), .A2(new_n249_), .B(new_n144_), .Y(new_n250_));
  OA211x2_ASAP7_75t_R  g229(.A1(new_n146_), .A2(new_n35_), .B(new_n248_), .C(new_n250_), .Y(new_n251_));
  INVx1_ASAP7_75t_R    g230(.A(new_n230_), .Y(new_n252_));
  AOI21x1_ASAP7_75t_R  g231(.A1(new_n30_), .A2(new_n199_), .B(new_n165_), .Y(new_n253_));
  AOI21x1_ASAP7_75t_R  g232(.A1(new_n252_), .A2(new_n157_), .B(new_n253_), .Y(new_n254_));
  NAND2x1_ASAP7_75t_R  g233(.A(new_n209_), .B(new_n217_), .Y(new_n255_));
  OA21x2_ASAP7_75t_R   g234(.A1(new_n115_), .A2(new_n255_), .B(new_n144_), .Y(new_n256_));
  AO21x1_ASAP7_75t_R   g235(.A1(new_n254_), .A2(new_n256_), .B(new_n94_), .Y(new_n257_));
  OA21x2_ASAP7_75t_R   g236(.A1(new_n41_), .A2(new_n22_), .B(new_n32_), .Y(new_n258_));
  AO21x1_ASAP7_75t_R   g237(.A1(p8), .A2(p4), .B(p5), .Y(new_n259_));
  OR3x1_ASAP7_75t_R    g238(.A(new_n258_), .B(new_n24_), .C(new_n259_), .Y(new_n260_));
  AND5x1_ASAP7_75t_R   g239(.A(new_n242_), .B(new_n247_), .C(new_n251_), .D(new_n257_), .E(new_n260_), .Y(new_n261_));
  NOR2x1_ASAP7_75t_R   g240(.A(new_n213_), .B(new_n32_), .Y(new_n262_));
  AOI22x1_ASAP7_75t_R  g241(.A1(new_n231_), .A2(new_n74_), .B1(new_n262_), .B2(new_n30_), .Y(new_n263_));
  AO21x1_ASAP7_75t_R   g242(.A1(new_n24_), .A2(new_n205_), .B(new_n108_), .Y(new_n264_));
  AOI21x1_ASAP7_75t_R  g243(.A1(new_n263_), .A2(new_n264_), .B(new_n41_), .Y(new_n265_));
  AND3x1_ASAP7_75t_R   g244(.A(new_n50_), .B(new_n41_), .C(p3), .Y(new_n266_));
  NOR2x1_ASAP7_75t_R   g245(.A(p5), .B(p4), .Y(new_n267_));
  INVx1_ASAP7_75t_R    g246(.A(new_n267_), .Y(new_n268_));
  NAND2x1_ASAP7_75t_R  g247(.A(new_n105_), .B(new_n268_), .Y(new_n269_));
  AO21x1_ASAP7_75t_R   g248(.A1(p8), .A2(p7), .B(p4), .Y(new_n270_));
  NAND2x1_ASAP7_75t_R  g249(.A(p8), .B(new_n30_), .Y(new_n271_));
  AO32x1_ASAP7_75t_R   g250(.A1(new_n271_), .A2(new_n41_), .A3(p2), .B1(new_n202_), .B2(new_n147_), .Y(new_n272_));
  AO32x1_ASAP7_75t_R   g251(.A1(new_n266_), .A2(new_n269_), .A3(new_n270_), .B1(new_n272_), .B2(new_n139_), .Y(new_n273_));
  AOI21x1_ASAP7_75t_R  g252(.A1(new_n139_), .A2(new_n265_), .B(new_n273_), .Y(new_n274_));
  OR3x1_ASAP7_75t_R    g253(.A(new_n274_), .B(p9), .C(p6), .Y(new_n275_));
  OAI21x1_ASAP7_75t_R  g254(.A1(new_n154_), .A2(new_n261_), .B(new_n275_), .Y(o3));
  OA211x2_ASAP7_75t_R  g255(.A1(p0), .A2(p9), .B(new_n139_), .C(p1), .Y(new_n277_));
  NOR2x1_ASAP7_75t_R   g256(.A(p2), .B(new_n139_), .Y(new_n278_));
  NOR2x1_ASAP7_75t_R   g257(.A(p3), .B(new_n24_), .Y(new_n279_));
  OA21x2_ASAP7_75t_R   g258(.A1(new_n278_), .A2(new_n279_), .B(new_n64_), .Y(new_n280_));
  NOR2x1_ASAP7_75t_R   g259(.A(p6), .B(new_n105_), .Y(new_n281_));
  OA21x2_ASAP7_75t_R   g260(.A1(new_n277_), .A2(new_n280_), .B(new_n281_), .Y(o4));
  INVx1_ASAP7_75t_R    g261(.A(new_n64_), .Y(new_n283_));
  AND3x1_ASAP7_75t_R   g262(.A(new_n96_), .B(new_n50_), .C(p3), .Y(new_n284_));
  AO21x1_ASAP7_75t_R   g263(.A1(new_n279_), .A2(new_n283_), .B(new_n284_), .Y(new_n285_));
  AND2x2_ASAP7_75t_R   g264(.A(new_n281_), .B(new_n285_), .Y(o5));
  INVx1_ASAP7_75t_R    g265(.A(new_n147_), .Y(new_n287_));
  AO32x1_ASAP7_75t_R   g266(.A1(new_n129_), .A2(new_n90_), .A3(new_n103_), .B1(new_n287_), .B2(p8), .Y(new_n288_));
  NAND2x1_ASAP7_75t_R  g267(.A(new_n221_), .B(new_n288_), .Y(new_n289_));
  OR3x1_ASAP7_75t_R    g268(.A(new_n213_), .B(p9), .C(new_n58_), .Y(new_n290_));
  NAND2x1_ASAP7_75t_R  g269(.A(new_n136_), .B(new_n158_), .Y(new_n291_));
  NAND3x1_ASAP7_75t_R  g270(.A(new_n255_), .B(new_n291_), .C(p5), .Y(new_n292_));
  AO21x1_ASAP7_75t_R   g271(.A1(new_n213_), .A2(new_n136_), .B(new_n170_), .Y(new_n293_));
  AOI21x1_ASAP7_75t_R  g272(.A1(new_n36_), .A2(new_n140_), .B(p2), .Y(new_n294_));
  AND5x1_ASAP7_75t_R   g273(.A(new_n289_), .B(new_n290_), .C(new_n292_), .D(new_n293_), .E(new_n294_), .Y(new_n295_));
  OA21x2_ASAP7_75t_R   g274(.A1(p0), .A2(new_n196_), .B(p9), .Y(new_n296_));
  NAND2x1_ASAP7_75t_R  g275(.A(new_n135_), .B(new_n296_), .Y(new_n297_));
  OR3x1_ASAP7_75t_R    g276(.A(new_n145_), .B(p5), .C(p9), .Y(new_n298_));
  AO21x1_ASAP7_75t_R   g277(.A1(new_n230_), .A2(new_n298_), .B(new_n100_), .Y(new_n299_));
  AOI21x1_ASAP7_75t_R  g278(.A1(new_n297_), .A2(new_n299_), .B(p4), .Y(new_n300_));
  INVx1_ASAP7_75t_R    g279(.A(new_n49_), .Y(new_n301_));
  AND3x1_ASAP7_75t_R   g280(.A(new_n301_), .B(new_n83_), .C(new_n171_), .Y(new_n302_));
  AND3x1_ASAP7_75t_R   g281(.A(new_n124_), .B(new_n221_), .C(new_n56_), .Y(new_n303_));
  AND3x1_ASAP7_75t_R   g282(.A(new_n42_), .B(new_n121_), .C(p8), .Y(new_n304_));
  OR4x2_ASAP7_75t_R    g283(.A(new_n302_), .B(new_n303_), .C(new_n304_), .D(new_n24_), .Y(new_n305_));
  NOR2x1_ASAP7_75t_R   g284(.A(new_n300_), .B(new_n305_), .Y(new_n306_));
  AO21x1_ASAP7_75t_R   g285(.A1(p5), .A2(new_n58_), .B(p9), .Y(new_n307_));
  INVx1_ASAP7_75t_R    g286(.A(new_n164_), .Y(new_n308_));
  AO32x1_ASAP7_75t_R   g287(.A1(new_n32_), .A2(new_n47_), .A3(new_n307_), .B1(new_n308_), .B2(new_n39_), .Y(new_n309_));
  NAND2x1_ASAP7_75t_R  g288(.A(new_n41_), .B(new_n309_), .Y(new_n310_));
  OA21x2_ASAP7_75t_R   g289(.A1(new_n115_), .A2(new_n27_), .B(new_n62_), .Y(new_n311_));
  NAND2x1_ASAP7_75t_R  g290(.A(p1), .B(new_n74_), .Y(new_n312_));
  AND3x1_ASAP7_75t_R   g291(.A(new_n23_), .B(new_n312_), .C(new_n30_), .Y(new_n313_));
  OR3x1_ASAP7_75t_R    g292(.A(new_n311_), .B(new_n55_), .C(new_n313_), .Y(new_n314_));
  AND3x1_ASAP7_75t_R   g293(.A(new_n128_), .B(new_n213_), .C(new_n136_), .Y(new_n315_));
  OR3x1_ASAP7_75t_R    g294(.A(new_n315_), .B(new_n30_), .C(new_n41_), .Y(new_n316_));
  AND3x1_ASAP7_75t_R   g295(.A(new_n310_), .B(new_n314_), .C(new_n316_), .Y(new_n317_));
  OAI21x1_ASAP7_75t_R  g296(.A1(new_n295_), .A2(new_n306_), .B(new_n317_), .Y(new_n318_));
  NOR2x1_ASAP7_75t_R   g297(.A(p1), .B(new_n82_), .Y(new_n319_));
  AO21x1_ASAP7_75t_R   g298(.A1(p0), .A2(p9), .B(new_n196_), .Y(new_n320_));
  AO21x1_ASAP7_75t_R   g299(.A1(p6), .A2(new_n22_), .B(new_n58_), .Y(new_n321_));
  AO22x1_ASAP7_75t_R   g300(.A1(p0), .A2(new_n47_), .B1(new_n57_), .B2(new_n321_), .Y(new_n322_));
  AO32x1_ASAP7_75t_R   g301(.A1(new_n319_), .A2(new_n255_), .A3(new_n320_), .B1(new_n322_), .B2(new_n26_), .Y(new_n323_));
  AO221x2_ASAP7_75t_R  g302(.A1(new_n82_), .A2(new_n284_), .B1(new_n323_), .B2(new_n183_), .C(new_n281_), .Y(new_n324_));
  AOI21x1_ASAP7_75t_R  g303(.A1(new_n70_), .A2(new_n318_), .B(new_n324_), .Y(o6));
  AND3x1_ASAP7_75t_R   g304(.A(new_n209_), .B(new_n26_), .C(p1), .Y(new_n326_));
  AO32x1_ASAP7_75t_R   g305(.A1(new_n22_), .A2(p6), .A3(new_n174_), .B1(new_n326_), .B2(new_n217_), .Y(new_n327_));
  AND3x1_ASAP7_75t_R   g306(.A(new_n327_), .B(new_n40_), .C(new_n267_), .Y(new_n328_));
  OA21x2_ASAP7_75t_R   g307(.A1(new_n82_), .A2(new_n328_), .B(new_n139_), .Y(new_n329_));
  AOI21x1_ASAP7_75t_R  g308(.A1(new_n35_), .A2(new_n205_), .B(new_n22_), .Y(new_n330_));
  NAND2x1_ASAP7_75t_R  g309(.A(new_n164_), .B(new_n205_), .Y(new_n331_));
  NOR2x1_ASAP7_75t_R   g310(.A(p5), .B(p9), .Y(new_n332_));
  AOI221x1_ASAP7_75t_R g311(.A1(p8), .A2(new_n26_), .B1(new_n117_), .B2(new_n58_), .C(new_n332_), .Y(new_n333_));
  AOI22x1_ASAP7_75t_R  g312(.A1(new_n330_), .A2(new_n331_), .B1(new_n35_), .B2(new_n333_), .Y(new_n334_));
  NAND3x1_ASAP7_75t_R  g313(.A(new_n24_), .B(p8), .C(p7), .Y(new_n335_));
  AOI21x1_ASAP7_75t_R  g314(.A1(p5), .A2(new_n335_), .B(new_n56_), .Y(new_n336_));
  NAND2x1_ASAP7_75t_R  g315(.A(p2), .B(new_n209_), .Y(new_n337_));
  NAND3x1_ASAP7_75t_R  g316(.A(new_n337_), .B(new_n335_), .C(new_n173_), .Y(new_n338_));
  AND3x1_ASAP7_75t_R   g317(.A(new_n103_), .B(new_n58_), .C(new_n24_), .Y(new_n339_));
  AOI21x1_ASAP7_75t_R  g318(.A1(new_n336_), .A2(new_n338_), .B(new_n339_), .Y(new_n340_));
  OAI21x1_ASAP7_75t_R  g319(.A1(p1), .A2(new_n334_), .B(new_n340_), .Y(new_n341_));
  NAND2x1_ASAP7_75t_R  g320(.A(p5), .B(new_n26_), .Y(new_n342_));
  AOI21x1_ASAP7_75t_R  g321(.A1(new_n209_), .A2(new_n217_), .B(new_n342_), .Y(new_n343_));
  OA221x2_ASAP7_75t_R  g322(.A1(p8), .A2(new_n26_), .B1(new_n103_), .B2(new_n133_), .C(new_n56_), .Y(new_n344_));
  OAI21x1_ASAP7_75t_R  g323(.A1(new_n343_), .A2(new_n344_), .B(new_n219_), .Y(new_n345_));
  OA21x2_ASAP7_75t_R   g324(.A1(p8), .A2(p7), .B(p1), .Y(new_n346_));
  OAI21x1_ASAP7_75t_R  g325(.A1(p5), .A2(new_n156_), .B(new_n346_), .Y(new_n347_));
  OR3x1_ASAP7_75t_R    g326(.A(new_n173_), .B(new_n30_), .C(p8), .Y(new_n348_));
  AO31x2_ASAP7_75t_R   g327(.A1(new_n347_), .A2(new_n348_), .A3(new_n122_), .B(p0), .Y(new_n349_));
  OR5x1_ASAP7_75t_R    g328(.A(new_n30_), .B(new_n24_), .C(p8), .D(p7), .E(p1), .Y(new_n350_));
  NAND3x1_ASAP7_75t_R  g329(.A(new_n345_), .B(new_n349_), .C(new_n350_), .Y(new_n351_));
  AOI21x1_ASAP7_75t_R  g330(.A1(p0), .A2(new_n341_), .B(new_n351_), .Y(new_n352_));
  AOI22x1_ASAP7_75t_R  g331(.A1(p8), .A2(p7), .B1(p1), .B2(p2), .Y(new_n353_));
  NAND3x1_ASAP7_75t_R  g332(.A(p9), .B(p2), .C(p4), .Y(new_n354_));
  AOI22x1_ASAP7_75t_R  g333(.A1(new_n217_), .A2(new_n353_), .B1(new_n129_), .B2(new_n354_), .Y(new_n355_));
  AND5x1_ASAP7_75t_R   g334(.A(p8), .B(p7), .C(p1), .D(p2), .E(p4), .Y(new_n356_));
  AO21x1_ASAP7_75t_R   g335(.A1(new_n88_), .A2(new_n231_), .B(new_n356_), .Y(new_n357_));
  OA31x2_ASAP7_75t_R   g336(.A1(p0), .A2(new_n355_), .A3(new_n357_), .B1(new_n30_), .Y(new_n358_));
  INVx1_ASAP7_75t_R    g337(.A(new_n73_), .Y(new_n359_));
  AOI22x1_ASAP7_75t_R  g338(.A1(p8), .A2(p1), .B1(p9), .B2(p7), .Y(new_n360_));
  OAI22x1_ASAP7_75t_R  g339(.A1(new_n359_), .A2(new_n32_), .B1(new_n47_), .B2(new_n360_), .Y(new_n361_));
  OA21x2_ASAP7_75t_R   g340(.A1(new_n213_), .A2(new_n140_), .B(new_n24_), .Y(new_n362_));
  AOI22x1_ASAP7_75t_R  g341(.A1(new_n22_), .A2(p1), .B1(p2), .B2(p4), .Y(new_n363_));
  OAI22x1_ASAP7_75t_R  g342(.A1(new_n363_), .A2(new_n301_), .B1(new_n337_), .B2(new_n115_), .Y(new_n364_));
  AOI21x1_ASAP7_75t_R  g343(.A1(new_n361_), .A2(new_n362_), .B(new_n364_), .Y(new_n365_));
  AOI221x1_ASAP7_75t_R g344(.A1(new_n88_), .A2(new_n231_), .B1(new_n355_), .B2(new_n41_), .C(new_n356_), .Y(new_n366_));
  NAND2x1_ASAP7_75t_R  g345(.A(new_n365_), .B(new_n366_), .Y(new_n367_));
  AOI21x1_ASAP7_75t_R  g346(.A1(new_n358_), .A2(new_n367_), .B(new_n328_), .Y(new_n368_));
  OAI21x1_ASAP7_75t_R  g347(.A1(p4), .A2(new_n352_), .B(new_n368_), .Y(new_n369_));
  AND3x1_ASAP7_75t_R   g348(.A(new_n284_), .B(new_n82_), .C(new_n267_), .Y(new_n370_));
  AOI21x1_ASAP7_75t_R  g349(.A1(new_n329_), .A2(new_n369_), .B(new_n370_), .Y(o7));
  AO21x1_ASAP7_75t_R   g350(.A1(p8), .A2(new_n41_), .B(new_n30_), .Y(new_n372_));
  AO21x1_ASAP7_75t_R   g351(.A1(new_n135_), .A2(new_n308_), .B(new_n372_), .Y(new_n373_));
  OR3x1_ASAP7_75t_R    g352(.A(new_n296_), .B(p5), .C(new_n42_), .Y(new_n374_));
  NAND2x1_ASAP7_75t_R  g353(.A(new_n165_), .B(new_n374_), .Y(new_n375_));
  AO21x1_ASAP7_75t_R   g354(.A1(new_n56_), .A2(new_n373_), .B(new_n375_), .Y(new_n376_));
  AO21x1_ASAP7_75t_R   g355(.A1(p7), .A2(new_n26_), .B(p4), .Y(new_n377_));
  AND3x1_ASAP7_75t_R   g356(.A(new_n188_), .B(p0), .C(p1), .Y(new_n378_));
  OA21x2_ASAP7_75t_R   g357(.A1(p9), .A2(p2), .B(new_n179_), .Y(new_n379_));
  NOR2x1_ASAP7_75t_R   g358(.A(new_n165_), .B(new_n287_), .Y(new_n380_));
  AND3x1_ASAP7_75t_R   g359(.A(new_n221_), .B(new_n74_), .C(new_n40_), .Y(new_n381_));
  AO221x2_ASAP7_75t_R  g360(.A1(new_n377_), .A2(new_n378_), .B1(new_n379_), .B2(new_n380_), .C(new_n381_), .Y(new_n382_));
  INVx1_ASAP7_75t_R    g361(.A(new_n271_), .Y(new_n383_));
  AND3x1_ASAP7_75t_R   g362(.A(new_n199_), .B(p0), .C(new_n37_), .Y(new_n384_));
  NAND2x1_ASAP7_75t_R  g363(.A(new_n188_), .B(new_n312_), .Y(new_n385_));
  AO32x1_ASAP7_75t_R   g364(.A1(new_n170_), .A2(new_n219_), .A3(new_n179_), .B1(new_n384_), .B2(new_n385_), .Y(new_n386_));
  AOI22x1_ASAP7_75t_R  g365(.A1(new_n382_), .A2(new_n103_), .B1(new_n383_), .B2(new_n386_), .Y(new_n387_));
  OR3x1_ASAP7_75t_R    g366(.A(new_n115_), .B(p0), .C(p8), .Y(new_n388_));
  AO21x1_ASAP7_75t_R   g367(.A1(new_n206_), .A2(new_n388_), .B(p9), .Y(new_n389_));
  NOR2x1_ASAP7_75t_R   g368(.A(p2), .B(new_n22_), .Y(new_n390_));
  OR5x1_ASAP7_75t_R    g369(.A(p1), .B(new_n165_), .C(new_n287_), .D(new_n390_), .E(new_n36_), .Y(new_n391_));
  NOR2x1_ASAP7_75t_R   g370(.A(p0), .B(p4), .Y(new_n392_));
  OAI21x1_ASAP7_75t_R  g371(.A1(new_n392_), .A2(new_n100_), .B(new_n216_), .Y(new_n393_));
  AO31x2_ASAP7_75t_R   g372(.A1(new_n389_), .A2(new_n391_), .A3(new_n393_), .B(new_n249_), .Y(new_n394_));
  NAND3x1_ASAP7_75t_R  g373(.A(new_n376_), .B(new_n387_), .C(new_n394_), .Y(new_n395_));
  AO32x1_ASAP7_75t_R   g374(.A1(new_n76_), .A2(new_n22_), .A3(p7), .B1(new_n39_), .B2(new_n49_), .Y(new_n396_));
  AO21x1_ASAP7_75t_R   g375(.A1(new_n73_), .A2(new_n291_), .B(new_n396_), .Y(new_n397_));
  AND5x1_ASAP7_75t_R   g376(.A(p0), .B(new_n26_), .C(new_n58_), .D(new_n56_), .E(p8), .Y(new_n398_));
  AO21x1_ASAP7_75t_R   g377(.A1(new_n41_), .A2(new_n397_), .B(new_n398_), .Y(new_n399_));
  AND3x1_ASAP7_75t_R   g378(.A(new_n284_), .B(new_n82_), .C(new_n74_), .Y(new_n400_));
  AO21x1_ASAP7_75t_R   g379(.A1(new_n183_), .A2(new_n399_), .B(new_n400_), .Y(new_n401_));
  AOI21x1_ASAP7_75t_R  g380(.A1(new_n70_), .A2(new_n395_), .B(new_n401_), .Y(o8));
  OR5x1_ASAP7_75t_R    g381(.A(new_n56_), .B(new_n65_), .C(new_n34_), .D(new_n196_), .E(p2), .Y(new_n403_));
  OR3x1_ASAP7_75t_R    g382(.A(new_n164_), .B(new_n103_), .C(new_n267_), .Y(new_n404_));
  AND2x2_ASAP7_75t_R   g383(.A(p2), .B(new_n117_), .Y(new_n405_));
  AO221x2_ASAP7_75t_R  g384(.A1(new_n268_), .A2(new_n278_), .B1(new_n404_), .B2(new_n405_), .C(p1), .Y(new_n406_));
  AO21x1_ASAP7_75t_R   g385(.A1(new_n403_), .A2(new_n406_), .B(p0), .Y(new_n407_));
  INVx1_ASAP7_75t_R    g386(.A(new_n270_), .Y(new_n408_));
  AND3x1_ASAP7_75t_R   g387(.A(new_n249_), .B(new_n24_), .C(new_n259_), .Y(new_n409_));
  AOI21x1_ASAP7_75t_R  g388(.A1(new_n244_), .A2(new_n408_), .B(new_n409_), .Y(new_n410_));
  OA21x2_ASAP7_75t_R   g389(.A1(p2), .A2(new_n65_), .B(new_n164_), .Y(new_n411_));
  OR3x1_ASAP7_75t_R    g390(.A(new_n411_), .B(p1), .C(new_n405_), .Y(new_n412_));
  AO21x1_ASAP7_75t_R   g391(.A1(new_n410_), .A2(new_n412_), .B(new_n41_), .Y(new_n413_));
  OR3x1_ASAP7_75t_R    g392(.A(new_n171_), .B(p5), .C(new_n37_), .Y(new_n414_));
  AO22x1_ASAP7_75t_R   g393(.A1(new_n41_), .A2(new_n217_), .B1(new_n82_), .B2(new_n414_), .Y(new_n415_));
  NAND2x1_ASAP7_75t_R  g394(.A(new_n40_), .B(new_n76_), .Y(new_n416_));
  OAI21x1_ASAP7_75t_R  g395(.A1(p4), .A2(new_n216_), .B(p5), .Y(new_n417_));
  AO21x1_ASAP7_75t_R   g396(.A1(new_n26_), .A2(new_n216_), .B(new_n82_), .Y(new_n418_));
  AND5x1_ASAP7_75t_R   g397(.A(new_n415_), .B(new_n211_), .C(new_n416_), .D(new_n417_), .E(new_n418_), .Y(new_n419_));
  AND3x1_ASAP7_75t_R   g398(.A(new_n407_), .B(new_n413_), .C(new_n419_), .Y(o9));
  AO21x1_ASAP7_75t_R   g399(.A1(p0), .A2(new_n62_), .B(new_n58_), .Y(new_n421_));
  AO21x1_ASAP7_75t_R   g400(.A1(p9), .A2(new_n22_), .B(p0), .Y(new_n422_));
  AND5x1_ASAP7_75t_R   g401(.A(new_n139_), .B(new_n421_), .C(p1), .D(p2), .E(new_n422_), .Y(new_n423_));
  OA211x2_ASAP7_75t_R  g402(.A1(new_n284_), .A2(new_n423_), .B(new_n82_), .C(new_n267_), .Y(o10));
endmodule


