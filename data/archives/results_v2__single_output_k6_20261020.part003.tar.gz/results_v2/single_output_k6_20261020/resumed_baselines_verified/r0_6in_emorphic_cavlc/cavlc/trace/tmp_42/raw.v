// Benchmark "/tmp/" written by ABC on Tue Oct 20 17:20:39 2026

module \/tmp/  ( 
    p5, p0, p7, p6, p2, p9, p1, p4, p8, p3,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10  );
  input  p5, p0, p7, p6, p2, p9, p1, p4, p8, p3;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10;
  wire new_n22_, new_n23_, new_n24_, new_n25_, new_n26_, new_n27_, new_n28_,
    new_n29_, new_n30_, new_n31_, new_n32_, new_n33_, new_n34_, new_n35_,
    new_n36_, new_n37_, new_n38_, new_n39_, new_n40_, new_n41_, new_n42_,
    new_n43_, new_n44_, new_n45_, new_n46_, new_n47_, new_n48_, new_n49_,
    new_n50_, new_n51_, new_n52_, new_n53_, new_n54_, new_n55_, new_n56_,
    new_n57_, new_n58_, new_n59_, new_n60_, new_n61_, new_n62_, new_n63_,
    new_n64_, new_n65_, new_n66_, new_n67_, new_n68_, new_n69_, new_n70_,
    new_n71_, new_n72_, new_n73_, new_n74_, new_n75_, new_n76_, new_n77_,
    new_n78_, new_n79_, new_n80_, new_n81_, new_n82_, new_n83_, new_n84_,
    new_n85_, new_n86_, new_n87_, new_n88_, new_n89_, new_n90_, new_n91_,
    new_n92_, new_n93_, new_n94_, new_n95_, new_n96_, new_n97_, new_n98_,
    new_n99_, new_n100_, new_n101_, new_n102_, new_n103_, new_n104_,
    new_n105_, new_n106_, new_n107_, new_n108_, new_n109_, new_n110_,
    new_n111_, new_n112_, new_n113_, new_n114_, new_n115_, new_n116_,
    new_n117_, new_n118_, new_n120_, new_n121_, new_n122_, new_n123_,
    new_n124_, new_n125_, new_n126_, new_n127_, new_n128_, new_n129_,
    new_n130_, new_n131_, new_n132_, new_n133_, new_n134_, new_n135_,
    new_n136_, new_n137_, new_n138_, new_n139_, new_n140_, new_n141_,
    new_n142_, new_n143_, new_n144_, new_n145_, new_n146_, new_n147_,
    new_n148_, new_n149_, new_n150_, new_n151_, new_n152_, new_n153_,
    new_n154_, new_n155_, new_n156_, new_n157_, new_n158_, new_n159_,
    new_n160_, new_n161_, new_n162_, new_n163_, new_n164_, new_n165_,
    new_n166_, new_n167_, new_n168_, new_n169_, new_n170_, new_n171_,
    new_n172_, new_n173_, new_n174_, new_n175_, new_n176_, new_n177_,
    new_n178_, new_n179_, new_n180_, new_n181_, new_n182_, new_n183_,
    new_n184_, new_n185_, new_n186_, new_n187_, new_n189_, new_n190_,
    new_n191_, new_n192_, new_n193_, new_n194_, new_n195_, new_n196_,
    new_n197_, new_n198_, new_n199_, new_n200_, new_n201_, new_n202_,
    new_n203_, new_n204_, new_n205_, new_n206_, new_n207_, new_n208_,
    new_n209_, new_n210_, new_n211_, new_n212_, new_n213_, new_n214_,
    new_n215_, new_n216_, new_n217_, new_n218_, new_n219_, new_n220_,
    new_n221_, new_n222_, new_n223_, new_n224_, new_n225_, new_n226_,
    new_n227_, new_n228_, new_n229_, new_n230_, new_n231_, new_n232_,
    new_n233_, new_n234_, new_n235_, new_n236_, new_n237_, new_n238_,
    new_n239_, new_n240_, new_n241_, new_n242_, new_n243_, new_n244_,
    new_n246_, new_n247_, new_n248_, new_n249_, new_n250_, new_n251_,
    new_n252_, new_n253_, new_n254_, new_n255_, new_n256_, new_n257_,
    new_n258_, new_n259_, new_n260_, new_n261_, new_n262_, new_n263_,
    new_n264_, new_n265_, new_n266_, new_n267_, new_n268_, new_n269_,
    new_n270_, new_n271_, new_n272_, new_n273_, new_n274_, new_n275_,
    new_n276_, new_n277_, new_n278_, new_n279_, new_n281_, new_n282_,
    new_n283_, new_n284_, new_n285_, new_n287_, new_n288_, new_n289_,
    new_n291_, new_n292_, new_n293_, new_n294_, new_n295_, new_n296_,
    new_n297_, new_n298_, new_n299_, new_n300_, new_n301_, new_n302_,
    new_n303_, new_n304_, new_n305_, new_n306_, new_n307_, new_n308_,
    new_n309_, new_n310_, new_n311_, new_n312_, new_n313_, new_n314_,
    new_n315_, new_n316_, new_n317_, new_n318_, new_n319_, new_n320_,
    new_n321_, new_n322_, new_n323_, new_n324_, new_n325_, new_n326_,
    new_n327_, new_n328_, new_n329_, new_n330_, new_n331_, new_n332_,
    new_n334_, new_n335_, new_n336_, new_n337_, new_n338_, new_n339_,
    new_n340_, new_n341_, new_n342_, new_n343_, new_n344_, new_n345_,
    new_n346_, new_n347_, new_n348_, new_n349_, new_n350_, new_n351_,
    new_n352_, new_n353_, new_n354_, new_n355_, new_n356_, new_n357_,
    new_n358_, new_n359_, new_n360_, new_n361_, new_n362_, new_n363_,
    new_n364_, new_n365_, new_n366_, new_n367_, new_n368_, new_n369_,
    new_n370_, new_n371_, new_n372_, new_n373_, new_n374_, new_n375_,
    new_n376_, new_n377_, new_n378_, new_n379_, new_n380_, new_n381_,
    new_n382_, new_n384_, new_n385_, new_n386_, new_n387_, new_n388_,
    new_n389_, new_n390_, new_n391_, new_n392_, new_n393_, new_n394_,
    new_n395_, new_n396_, new_n397_, new_n398_, new_n399_, new_n400_,
    new_n401_, new_n402_, new_n403_, new_n404_, new_n405_, new_n406_,
    new_n407_, new_n408_, new_n410_, new_n411_, new_n412_, new_n413_,
    new_n414_, new_n415_, new_n416_, new_n417_, new_n418_, new_n419_,
    new_n420_, new_n421_, new_n422_, new_n423_, new_n424_, new_n425_,
    new_n427_, new_n428_;
  INVx1_ASAP7_75t_R    g000(.A(p0), .Y(new_n22_));
  NOR2x1_ASAP7_75t_R   g001(.A(p7), .B(new_n22_), .Y(new_n23_));
  NAND2x1_ASAP7_75t_R  g002(.A(p1), .B(new_n22_), .Y(new_n24_));
  INVx1_ASAP7_75t_R    g003(.A(new_n24_), .Y(new_n25_));
  INVx1_ASAP7_75t_R    g004(.A(p4), .Y(new_n26_));
  INVx1_ASAP7_75t_R    g005(.A(p8), .Y(new_n27_));
  AO21x1_ASAP7_75t_R   g006(.A1(p9), .A2(new_n27_), .B(p0), .Y(new_n28_));
  OA211x2_ASAP7_75t_R  g007(.A1(new_n23_), .A2(new_n25_), .B(new_n26_), .C(new_n28_), .Y(new_n29_));
  NAND2x1_ASAP7_75t_R  g008(.A(p0), .B(p9), .Y(new_n30_));
  NAND2x1_ASAP7_75t_R  g009(.A(p0), .B(new_n27_), .Y(new_n31_));
  NAND2x1_ASAP7_75t_R  g010(.A(new_n30_), .B(new_n31_), .Y(new_n32_));
  INVx1_ASAP7_75t_R    g011(.A(p9), .Y(new_n33_));
  NOR2x1_ASAP7_75t_R   g012(.A(p8), .B(new_n33_), .Y(new_n34_));
  INVx1_ASAP7_75t_R    g013(.A(new_n34_), .Y(new_n35_));
  AND3x1_ASAP7_75t_R   g014(.A(p7), .B(p1), .C(p4), .Y(new_n36_));
  NOR2x1_ASAP7_75t_R   g015(.A(p9), .B(new_n27_), .Y(new_n37_));
  NOR2x1_ASAP7_75t_R   g016(.A(p7), .B(p4), .Y(new_n38_));
  AO32x1_ASAP7_75t_R   g017(.A1(new_n32_), .A2(new_n35_), .A3(new_n36_), .B1(new_n37_), .B2(new_n38_), .Y(new_n39_));
  NOR2x1_ASAP7_75t_R   g018(.A(p9), .B(p1), .Y(new_n40_));
  NOR2x1_ASAP7_75t_R   g019(.A(p0), .B(new_n27_), .Y(new_n41_));
  AO21x1_ASAP7_75t_R   g020(.A1(new_n40_), .A2(new_n41_), .B(p4), .Y(new_n42_));
  AND3x1_ASAP7_75t_R   g021(.A(new_n42_), .B(p5), .C(p7), .Y(new_n43_));
  OA31x2_ASAP7_75t_R   g022(.A1(new_n29_), .A2(new_n39_), .A3(new_n43_), .B1(p2), .Y(new_n44_));
  NOR2x1_ASAP7_75t_R   g023(.A(p1), .B(new_n34_), .Y(new_n45_));
  INVx1_ASAP7_75t_R    g024(.A(p2), .Y(new_n46_));
  NAND2x1_ASAP7_75t_R  g025(.A(p0), .B(new_n46_), .Y(new_n47_));
  AO21x1_ASAP7_75t_R   g026(.A1(new_n33_), .A2(p8), .B(new_n47_), .Y(new_n48_));
  NAND2x1_ASAP7_75t_R  g027(.A(p7), .B(p4), .Y(new_n49_));
  INVx1_ASAP7_75t_R    g028(.A(new_n49_), .Y(new_n50_));
  OAI21x1_ASAP7_75t_R  g029(.A1(p5), .A2(new_n45_), .B(new_n50_), .Y(new_n51_));
  AO21x1_ASAP7_75t_R   g030(.A1(new_n45_), .A2(new_n48_), .B(new_n51_), .Y(new_n52_));
  NAND2x1_ASAP7_75t_R  g031(.A(p5), .B(p7), .Y(new_n53_));
  NAND2x1_ASAP7_75t_R  g032(.A(new_n46_), .B(new_n33_), .Y(new_n54_));
  NOR2x1_ASAP7_75t_R   g033(.A(new_n53_), .B(new_n54_), .Y(new_n55_));
  NOR2x1_ASAP7_75t_R   g034(.A(p1), .B(p8), .Y(new_n56_));
  AND2x2_ASAP7_75t_R   g035(.A(p1), .B(p8), .Y(new_n57_));
  AO21x1_ASAP7_75t_R   g036(.A1(p0), .A2(new_n56_), .B(new_n57_), .Y(new_n58_));
  NOR2x1_ASAP7_75t_R   g037(.A(p0), .B(p8), .Y(new_n59_));
  NOR2x1_ASAP7_75t_R   g038(.A(p7), .B(p2), .Y(new_n60_));
  AND3x1_ASAP7_75t_R   g039(.A(new_n59_), .B(new_n40_), .C(new_n60_), .Y(new_n61_));
  AOI21x1_ASAP7_75t_R  g040(.A1(new_n55_), .A2(new_n58_), .B(new_n61_), .Y(new_n62_));
  INVx1_ASAP7_75t_R    g041(.A(p5), .Y(new_n63_));
  NAND2x1_ASAP7_75t_R  g042(.A(p2), .B(new_n63_), .Y(new_n64_));
  NAND2x1_ASAP7_75t_R  g043(.A(p2), .B(p1), .Y(new_n65_));
  AO32x1_ASAP7_75t_R   g044(.A1(new_n64_), .A2(new_n59_), .A3(new_n65_), .B1(p1), .B2(p8), .Y(new_n66_));
  NOR2x1_ASAP7_75t_R   g045(.A(p0), .B(p2), .Y(new_n67_));
  AO21x1_ASAP7_75t_R   g046(.A1(new_n57_), .A2(new_n67_), .B(new_n23_), .Y(new_n68_));
  NOR2x1_ASAP7_75t_R   g047(.A(p9), .B(p4), .Y(new_n69_));
  AOI22x1_ASAP7_75t_R  g048(.A1(new_n66_), .A2(new_n38_), .B1(new_n68_), .B2(new_n69_), .Y(new_n70_));
  NAND3x1_ASAP7_75t_R  g049(.A(new_n52_), .B(new_n62_), .C(new_n70_), .Y(new_n71_));
  NOR2x1_ASAP7_75t_R   g050(.A(p6), .B(p3), .Y(new_n72_));
  OAI21x1_ASAP7_75t_R  g051(.A1(new_n44_), .A2(new_n71_), .B(new_n72_), .Y(new_n73_));
  NAND2x1_ASAP7_75t_R  g052(.A(p0), .B(p1), .Y(new_n74_));
  INVx1_ASAP7_75t_R    g053(.A(p1), .Y(new_n75_));
  AO21x1_ASAP7_75t_R   g054(.A1(new_n75_), .A2(new_n26_), .B(p9), .Y(new_n76_));
  AO21x1_ASAP7_75t_R   g055(.A1(new_n74_), .A2(new_n76_), .B(p8), .Y(new_n77_));
  NOR2x1_ASAP7_75t_R   g056(.A(p2), .B(p1), .Y(new_n78_));
  OR3x1_ASAP7_75t_R    g057(.A(new_n78_), .B(p0), .C(new_n27_), .Y(new_n79_));
  NAND3x1_ASAP7_75t_R  g058(.A(new_n22_), .B(p2), .C(p9), .Y(new_n80_));
  AND3x1_ASAP7_75t_R   g059(.A(new_n79_), .B(new_n80_), .C(new_n47_), .Y(new_n81_));
  INVx1_ASAP7_75t_R    g060(.A(p7), .Y(new_n82_));
  INVx1_ASAP7_75t_R    g061(.A(p6), .Y(new_n83_));
  NAND2x1_ASAP7_75t_R  g062(.A(new_n82_), .B(new_n83_), .Y(new_n84_));
  AO21x1_ASAP7_75t_R   g063(.A1(new_n77_), .A2(new_n81_), .B(new_n84_), .Y(new_n85_));
  NAND2x1_ASAP7_75t_R  g064(.A(p7), .B(new_n26_), .Y(new_n86_));
  INVx1_ASAP7_75t_R    g065(.A(new_n86_), .Y(new_n87_));
  NOR2x1_ASAP7_75t_R   g066(.A(p4), .B(p8), .Y(new_n88_));
  NOR2x1_ASAP7_75t_R   g067(.A(p1), .B(new_n33_), .Y(new_n89_));
  OA21x2_ASAP7_75t_R   g068(.A1(new_n83_), .A2(new_n88_), .B(new_n89_), .Y(new_n90_));
  OA21x2_ASAP7_75t_R   g069(.A1(p6), .A2(new_n31_), .B(new_n46_), .Y(new_n91_));
  OA21x2_ASAP7_75t_R   g070(.A1(new_n87_), .A2(new_n90_), .B(new_n91_), .Y(new_n92_));
  INVx1_ASAP7_75t_R    g071(.A(new_n41_), .Y(new_n93_));
  NAND2x1_ASAP7_75t_R  g072(.A(p4), .B(new_n22_), .Y(new_n94_));
  AND3x1_ASAP7_75t_R   g073(.A(new_n59_), .B(new_n33_), .C(p1), .Y(new_n95_));
  AO32x1_ASAP7_75t_R   g074(.A1(new_n93_), .A2(new_n94_), .A3(new_n89_), .B1(new_n95_), .B2(p6), .Y(new_n96_));
  NAND2x1_ASAP7_75t_R  g075(.A(new_n22_), .B(new_n33_), .Y(new_n97_));
  AO32x1_ASAP7_75t_R   g076(.A1(new_n46_), .A2(new_n26_), .A3(new_n30_), .B1(new_n97_), .B2(new_n83_), .Y(new_n98_));
  NOR2x1_ASAP7_75t_R   g077(.A(p7), .B(p1), .Y(new_n99_));
  INVx1_ASAP7_75t_R    g078(.A(new_n99_), .Y(new_n100_));
  AND2x2_ASAP7_75t_R   g079(.A(p0), .B(p8), .Y(new_n101_));
  NOR2x1_ASAP7_75t_R   g080(.A(new_n59_), .B(new_n101_), .Y(new_n102_));
  NOR2x1_ASAP7_75t_R   g081(.A(new_n100_), .B(new_n102_), .Y(new_n103_));
  AOI22x1_ASAP7_75t_R  g082(.A1(new_n92_), .A2(new_n96_), .B1(new_n98_), .B2(new_n103_), .Y(new_n104_));
  INVx1_ASAP7_75t_R    g083(.A(p3), .Y(new_n105_));
  NAND2x1_ASAP7_75t_R  g084(.A(new_n63_), .B(new_n105_), .Y(new_n106_));
  AO21x1_ASAP7_75t_R   g085(.A1(new_n85_), .A2(new_n104_), .B(new_n106_), .Y(new_n107_));
  AND3x1_ASAP7_75t_R   g086(.A(new_n22_), .B(new_n33_), .C(new_n75_), .Y(new_n108_));
  AND3x1_ASAP7_75t_R   g087(.A(new_n108_), .B(new_n83_), .C(new_n46_), .Y(new_n109_));
  NOR2x1_ASAP7_75t_R   g088(.A(p5), .B(p8), .Y(new_n110_));
  INVx1_ASAP7_75t_R    g089(.A(new_n110_), .Y(new_n111_));
  NAND2x1_ASAP7_75t_R  g090(.A(p5), .B(p4), .Y(new_n112_));
  OA21x2_ASAP7_75t_R   g091(.A1(new_n27_), .A2(p3), .B(new_n112_), .Y(new_n113_));
  NOR2x1_ASAP7_75t_R   g092(.A(p7), .B(new_n26_), .Y(new_n114_));
  AO21x1_ASAP7_75t_R   g093(.A1(p5), .A2(p4), .B(new_n114_), .Y(new_n115_));
  AO21x1_ASAP7_75t_R   g094(.A1(p7), .A2(p3), .B(new_n110_), .Y(new_n116_));
  AO32x1_ASAP7_75t_R   g095(.A1(new_n82_), .A2(new_n111_), .A3(new_n113_), .B1(new_n115_), .B2(new_n116_), .Y(new_n117_));
  NAND2x1_ASAP7_75t_R  g096(.A(new_n109_), .B(new_n117_), .Y(new_n118_));
  NAND3x1_ASAP7_75t_R  g097(.A(new_n73_), .B(new_n107_), .C(new_n118_), .Y(o0));
  NOR2x1_ASAP7_75t_R   g098(.A(p1), .B(new_n26_), .Y(new_n120_));
  NAND2x1_ASAP7_75t_R  g099(.A(p5), .B(p8), .Y(new_n121_));
  NAND2x1_ASAP7_75t_R  g100(.A(new_n121_), .B(new_n86_), .Y(new_n122_));
  AND3x1_ASAP7_75t_R   g101(.A(new_n53_), .B(p9), .C(new_n75_), .Y(new_n123_));
  AO32x1_ASAP7_75t_R   g102(.A1(new_n82_), .A2(new_n37_), .A3(new_n120_), .B1(new_n122_), .B2(new_n123_), .Y(new_n124_));
  NOR2x1_ASAP7_75t_R   g103(.A(p8), .B(new_n22_), .Y(new_n125_));
  AO21x1_ASAP7_75t_R   g104(.A1(p5), .A2(new_n33_), .B(p1), .Y(new_n126_));
  NOR2x1_ASAP7_75t_R   g105(.A(p5), .B(p7), .Y(new_n127_));
  AO21x1_ASAP7_75t_R   g106(.A1(new_n126_), .A2(new_n87_), .B(new_n127_), .Y(new_n128_));
  AOI22x1_ASAP7_75t_R  g107(.A1(new_n124_), .A2(p0), .B1(new_n125_), .B2(new_n128_), .Y(new_n129_));
  NAND2x1_ASAP7_75t_R  g108(.A(p7), .B(p1), .Y(new_n130_));
  NOR2x1_ASAP7_75t_R   g109(.A(p7), .B(p9), .Y(new_n131_));
  NAND2x1_ASAP7_75t_R  g110(.A(new_n56_), .B(new_n131_), .Y(new_n132_));
  NAND2x1_ASAP7_75t_R  g111(.A(p1), .B(p8), .Y(new_n133_));
  OR3x1_ASAP7_75t_R    g112(.A(new_n133_), .B(new_n82_), .C(new_n33_), .Y(new_n134_));
  AO21x1_ASAP7_75t_R   g113(.A1(new_n132_), .A2(new_n134_), .B(new_n94_), .Y(new_n135_));
  OA21x2_ASAP7_75t_R   g114(.A1(new_n111_), .A2(new_n130_), .B(new_n135_), .Y(new_n136_));
  AO21x1_ASAP7_75t_R   g115(.A1(new_n121_), .A2(new_n86_), .B(p9), .Y(new_n137_));
  INVx1_ASAP7_75t_R    g116(.A(new_n88_), .Y(new_n138_));
  NOR2x1_ASAP7_75t_R   g117(.A(p7), .B(p8), .Y(new_n139_));
  AND2x2_ASAP7_75t_R   g118(.A(p7), .B(p8), .Y(new_n140_));
  NOR2x1_ASAP7_75t_R   g119(.A(new_n139_), .B(new_n140_), .Y(new_n141_));
  AO21x1_ASAP7_75t_R   g120(.A1(new_n138_), .A2(new_n121_), .B(new_n141_), .Y(new_n142_));
  AO21x1_ASAP7_75t_R   g121(.A1(new_n137_), .A2(new_n142_), .B(new_n24_), .Y(new_n143_));
  NAND3x1_ASAP7_75t_R  g122(.A(new_n129_), .B(new_n136_), .C(new_n143_), .Y(new_n144_));
  AND3x1_ASAP7_75t_R   g123(.A(new_n83_), .B(new_n46_), .C(new_n105_), .Y(new_n145_));
  AOI21x1_ASAP7_75t_R  g124(.A1(p7), .A2(p3), .B(new_n114_), .Y(new_n146_));
  OAI22x1_ASAP7_75t_R  g125(.A1(new_n146_), .A2(new_n111_), .B1(new_n105_), .B2(new_n121_), .Y(new_n147_));
  NOR2x1_ASAP7_75t_R   g126(.A(p2), .B(p4), .Y(new_n148_));
  AND3x1_ASAP7_75t_R   g127(.A(new_n148_), .B(new_n63_), .C(new_n105_), .Y(new_n149_));
  AND3x1_ASAP7_75t_R   g128(.A(new_n125_), .B(p7), .C(new_n75_), .Y(new_n150_));
  INVx1_ASAP7_75t_R    g129(.A(new_n30_), .Y(new_n151_));
  OR3x1_ASAP7_75t_R    g130(.A(new_n151_), .B(new_n34_), .C(p1), .Y(new_n152_));
  OA211x2_ASAP7_75t_R  g131(.A1(new_n99_), .A2(new_n131_), .B(new_n74_), .C(p6), .Y(new_n153_));
  AO221x2_ASAP7_75t_R  g132(.A1(p6), .A2(new_n150_), .B1(new_n152_), .B2(new_n153_), .C(new_n95_), .Y(new_n154_));
  AO22x1_ASAP7_75t_R   g133(.A1(new_n109_), .A2(new_n147_), .B1(new_n149_), .B2(new_n154_), .Y(new_n155_));
  AO21x1_ASAP7_75t_R   g134(.A1(p7), .A2(new_n26_), .B(new_n60_), .Y(new_n156_));
  NOR2x1_ASAP7_75t_R   g135(.A(new_n33_), .B(new_n156_), .Y(new_n157_));
  AO21x1_ASAP7_75t_R   g136(.A1(p4), .A2(new_n99_), .B(p0), .Y(new_n158_));
  AO21x1_ASAP7_75t_R   g137(.A1(p4), .A2(new_n33_), .B(new_n22_), .Y(new_n159_));
  NAND2x1_ASAP7_75t_R  g138(.A(p7), .B(p9), .Y(new_n160_));
  NOR2x1_ASAP7_75t_R   g139(.A(p1), .B(new_n160_), .Y(new_n161_));
  NOR2x1_ASAP7_75t_R   g140(.A(p4), .B(new_n33_), .Y(new_n162_));
  OR3x1_ASAP7_75t_R    g141(.A(new_n159_), .B(new_n161_), .C(new_n162_), .Y(new_n163_));
  OA211x2_ASAP7_75t_R  g142(.A1(new_n157_), .A2(new_n158_), .B(new_n163_), .C(new_n63_), .Y(new_n164_));
  NAND2x1_ASAP7_75t_R  g143(.A(new_n22_), .B(new_n82_), .Y(new_n165_));
  NOR2x1_ASAP7_75t_R   g144(.A(p0), .B(new_n53_), .Y(new_n166_));
  AO21x1_ASAP7_75t_R   g145(.A1(new_n75_), .A2(new_n165_), .B(new_n166_), .Y(new_n167_));
  NAND2x1_ASAP7_75t_R  g146(.A(p2), .B(new_n26_), .Y(new_n168_));
  INVx1_ASAP7_75t_R    g147(.A(new_n168_), .Y(new_n169_));
  NAND2x1_ASAP7_75t_R  g148(.A(new_n63_), .B(new_n22_), .Y(new_n170_));
  OA211x2_ASAP7_75t_R  g149(.A1(new_n89_), .A2(new_n99_), .B(new_n170_), .C(new_n30_), .Y(new_n171_));
  NOR2x1_ASAP7_75t_R   g150(.A(p5), .B(p9), .Y(new_n172_));
  AO21x1_ASAP7_75t_R   g151(.A1(p7), .A2(p2), .B(p1), .Y(new_n173_));
  AO21x1_ASAP7_75t_R   g152(.A1(new_n172_), .A2(new_n173_), .B(p8), .Y(new_n174_));
  AO221x2_ASAP7_75t_R  g153(.A1(new_n167_), .A2(new_n169_), .B1(new_n171_), .B2(new_n26_), .C(new_n174_), .Y(new_n175_));
  NAND2x1_ASAP7_75t_R  g154(.A(p0), .B(p4), .Y(new_n176_));
  OR3x1_ASAP7_75t_R    g155(.A(new_n65_), .B(new_n176_), .C(p7), .Y(new_n177_));
  OR3x1_ASAP7_75t_R    g156(.A(new_n74_), .B(new_n63_), .C(new_n46_), .Y(new_n178_));
  AND3x1_ASAP7_75t_R   g157(.A(new_n177_), .B(new_n178_), .C(p8), .Y(new_n179_));
  OR5x1_ASAP7_75t_R    g158(.A(p0), .B(new_n46_), .C(new_n33_), .D(p7), .E(p1), .Y(new_n180_));
  NAND2x1_ASAP7_75t_R  g159(.A(p1), .B(p4), .Y(new_n181_));
  NAND2x1_ASAP7_75t_R  g160(.A(p2), .B(p4), .Y(new_n182_));
  OA211x2_ASAP7_75t_R  g161(.A1(new_n33_), .A2(new_n176_), .B(new_n181_), .C(new_n182_), .Y(new_n183_));
  AO21x1_ASAP7_75t_R   g162(.A1(new_n180_), .A2(new_n183_), .B(new_n63_), .Y(new_n184_));
  INVx1_ASAP7_75t_R    g163(.A(new_n72_), .Y(new_n185_));
  AOI21x1_ASAP7_75t_R  g164(.A1(new_n179_), .A2(new_n184_), .B(new_n185_), .Y(new_n186_));
  OA21x2_ASAP7_75t_R   g165(.A1(new_n164_), .A2(new_n175_), .B(new_n186_), .Y(new_n187_));
  AO211x2_ASAP7_75t_R  g166(.A1(new_n144_), .A2(new_n145_), .B(new_n155_), .C(new_n187_), .Y(o1));
  OR3x1_ASAP7_75t_R    g167(.A(new_n22_), .B(new_n82_), .C(p8), .Y(new_n189_));
  NAND2x1_ASAP7_75t_R  g168(.A(new_n53_), .B(new_n189_), .Y(new_n190_));
  AO21x1_ASAP7_75t_R   g169(.A1(new_n31_), .A2(new_n60_), .B(new_n190_), .Y(new_n191_));
  AND3x1_ASAP7_75t_R   g170(.A(new_n57_), .B(p5), .C(p0), .Y(new_n192_));
  AND3x1_ASAP7_75t_R   g171(.A(new_n82_), .B(new_n27_), .C(p1), .Y(new_n193_));
  OA21x2_ASAP7_75t_R   g172(.A1(p8), .A2(new_n75_), .B(p7), .Y(new_n194_));
  OR4x2_ASAP7_75t_R    g173(.A(new_n192_), .B(new_n166_), .C(new_n193_), .D(new_n194_), .Y(new_n195_));
  AO32x1_ASAP7_75t_R   g174(.A1(new_n191_), .A2(new_n75_), .A3(new_n93_), .B1(p2), .B2(new_n195_), .Y(new_n196_));
  AND3x1_ASAP7_75t_R   g175(.A(new_n72_), .B(p9), .C(new_n26_), .Y(new_n197_));
  OR3x1_ASAP7_75t_R    g176(.A(new_n75_), .B(new_n27_), .C(p4), .Y(new_n198_));
  OR3x1_ASAP7_75t_R    g177(.A(new_n141_), .B(new_n26_), .C(new_n37_), .Y(new_n199_));
  AO21x1_ASAP7_75t_R   g178(.A1(new_n198_), .A2(new_n199_), .B(new_n47_), .Y(new_n200_));
  INVx1_ASAP7_75t_R    g179(.A(new_n59_), .Y(new_n201_));
  NAND2x1_ASAP7_75t_R  g180(.A(p7), .B(p8), .Y(new_n202_));
  NAND2x1_ASAP7_75t_R  g181(.A(new_n82_), .B(new_n27_), .Y(new_n203_));
  NAND2x1_ASAP7_75t_R  g182(.A(new_n202_), .B(new_n203_), .Y(new_n204_));
  NAND2x1_ASAP7_75t_R  g183(.A(p1), .B(new_n46_), .Y(new_n205_));
  AO21x1_ASAP7_75t_R   g184(.A1(new_n201_), .A2(new_n204_), .B(new_n205_), .Y(new_n206_));
  NAND2x1_ASAP7_75t_R  g185(.A(p9), .B(new_n26_), .Y(new_n207_));
  OR3x1_ASAP7_75t_R    g186(.A(p7), .B(p1), .C(p8), .Y(new_n208_));
  AO21x1_ASAP7_75t_R   g187(.A1(new_n207_), .A2(new_n80_), .B(new_n208_), .Y(new_n209_));
  OA21x2_ASAP7_75t_R   g188(.A1(new_n160_), .A2(new_n79_), .B(new_n209_), .Y(new_n210_));
  NAND3x1_ASAP7_75t_R  g189(.A(new_n200_), .B(new_n206_), .C(new_n210_), .Y(new_n211_));
  AND3x1_ASAP7_75t_R   g190(.A(new_n63_), .B(new_n83_), .C(new_n105_), .Y(new_n212_));
  AOI22x1_ASAP7_75t_R  g191(.A1(new_n196_), .A2(new_n197_), .B1(new_n211_), .B2(new_n212_), .Y(new_n213_));
  AO21x1_ASAP7_75t_R   g192(.A1(p6), .A2(new_n140_), .B(new_n33_), .Y(new_n214_));
  NAND2x1_ASAP7_75t_R  g193(.A(new_n32_), .B(new_n214_), .Y(new_n215_));
  OA21x2_ASAP7_75t_R   g194(.A1(new_n35_), .A2(new_n165_), .B(new_n215_), .Y(new_n216_));
  INVx1_ASAP7_75t_R    g195(.A(new_n149_), .Y(new_n217_));
  OR3x1_ASAP7_75t_R    g196(.A(new_n216_), .B(p1), .C(new_n217_), .Y(new_n218_));
  NOR2x1_ASAP7_75t_R   g197(.A(p1), .B(new_n46_), .Y(new_n219_));
  INVx1_ASAP7_75t_R    g198(.A(new_n219_), .Y(new_n220_));
  AO21x1_ASAP7_75t_R   g199(.A1(p7), .A2(new_n220_), .B(p4), .Y(new_n221_));
  NOR2x1_ASAP7_75t_R   g200(.A(p1), .B(new_n82_), .Y(new_n222_));
  OA21x2_ASAP7_75t_R   g201(.A1(new_n182_), .A2(new_n222_), .B(new_n125_), .Y(new_n223_));
  NAND2x1_ASAP7_75t_R  g202(.A(p0), .B(p7), .Y(new_n224_));
  AO21x1_ASAP7_75t_R   g203(.A1(p5), .A2(p1), .B(new_n224_), .Y(new_n225_));
  AND3x1_ASAP7_75t_R   g204(.A(new_n225_), .B(p4), .C(new_n173_), .Y(new_n226_));
  NOR2x1_ASAP7_75t_R   g205(.A(p7), .B(new_n46_), .Y(new_n227_));
  AO21x1_ASAP7_75t_R   g206(.A1(new_n41_), .A2(new_n227_), .B(new_n219_), .Y(new_n228_));
  AND3x1_ASAP7_75t_R   g207(.A(new_n228_), .B(new_n111_), .C(new_n189_), .Y(new_n229_));
  AOI211x1_ASAP7_75t_R g208(.A1(new_n221_), .A2(new_n223_), .B(new_n226_), .C(new_n229_), .Y(new_n230_));
  NOR2x1_ASAP7_75t_R   g209(.A(new_n125_), .B(new_n227_), .Y(new_n231_));
  AO21x1_ASAP7_75t_R   g210(.A1(p2), .A2(new_n27_), .B(p5), .Y(new_n232_));
  NAND2x1_ASAP7_75t_R  g211(.A(p5), .B(new_n82_), .Y(new_n233_));
  OR3x1_ASAP7_75t_R    g212(.A(new_n22_), .B(new_n27_), .C(p2), .Y(new_n234_));
  OA21x2_ASAP7_75t_R   g213(.A1(new_n233_), .A2(new_n234_), .B(new_n105_), .Y(new_n235_));
  INVx1_ASAP7_75t_R    g214(.A(new_n67_), .Y(new_n236_));
  NAND2x1_ASAP7_75t_R  g215(.A(p5), .B(new_n26_), .Y(new_n237_));
  OR3x1_ASAP7_75t_R    g216(.A(new_n236_), .B(new_n203_), .C(new_n237_), .Y(new_n238_));
  OA211x2_ASAP7_75t_R  g217(.A1(new_n231_), .A2(new_n232_), .B(new_n235_), .C(new_n238_), .Y(new_n239_));
  AO21x1_ASAP7_75t_R   g218(.A1(new_n22_), .A2(new_n78_), .B(new_n105_), .Y(new_n240_));
  AO21x1_ASAP7_75t_R   g219(.A1(new_n202_), .A2(new_n233_), .B(p4), .Y(new_n241_));
  OA211x2_ASAP7_75t_R  g220(.A1(new_n105_), .A2(new_n241_), .B(new_n83_), .C(new_n33_), .Y(new_n242_));
  NAND2x1_ASAP7_75t_R  g221(.A(new_n240_), .B(new_n242_), .Y(new_n243_));
  AO21x1_ASAP7_75t_R   g222(.A1(new_n230_), .A2(new_n239_), .B(new_n243_), .Y(new_n244_));
  NAND3x1_ASAP7_75t_R  g223(.A(new_n213_), .B(new_n218_), .C(new_n244_), .Y(o2));
  INVx1_ASAP7_75t_R    g224(.A(new_n74_), .Y(new_n246_));
  NAND2x1_ASAP7_75t_R  g225(.A(p8), .B(new_n63_), .Y(new_n247_));
  INVx1_ASAP7_75t_R    g226(.A(new_n247_), .Y(new_n248_));
  AND3x1_ASAP7_75t_R   g227(.A(new_n82_), .B(new_n26_), .C(new_n27_), .Y(new_n249_));
  AO21x1_ASAP7_75t_R   g228(.A1(new_n50_), .A2(new_n248_), .B(new_n249_), .Y(new_n250_));
  AOI21x1_ASAP7_75t_R  g229(.A1(new_n46_), .A2(new_n233_), .B(new_n115_), .Y(new_n251_));
  NOR2x1_ASAP7_75t_R   g230(.A(p0), .B(new_n46_), .Y(new_n252_));
  AO32x1_ASAP7_75t_R   g231(.A1(p5), .A2(p1), .A3(new_n176_), .B1(new_n252_), .B2(new_n247_), .Y(new_n253_));
  AO221x2_ASAP7_75t_R  g232(.A1(new_n246_), .A2(new_n250_), .B1(new_n251_), .B2(p0), .C(new_n253_), .Y(new_n254_));
  NAND2x1_ASAP7_75t_R  g233(.A(new_n63_), .B(new_n26_), .Y(new_n255_));
  NAND2x1_ASAP7_75t_R  g234(.A(new_n112_), .B(new_n255_), .Y(new_n256_));
  AO21x1_ASAP7_75t_R   g235(.A1(p7), .A2(p8), .B(p4), .Y(new_n257_));
  AND5x1_ASAP7_75t_R   g236(.A(new_n22_), .B(new_n256_), .C(p3), .D(new_n78_), .E(new_n257_), .Y(new_n258_));
  AOI21x1_ASAP7_75t_R  g237(.A1(new_n105_), .A2(new_n254_), .B(new_n258_), .Y(new_n259_));
  NAND2x1_ASAP7_75t_R  g238(.A(new_n83_), .B(new_n33_), .Y(new_n260_));
  AO21x1_ASAP7_75t_R   g239(.A1(new_n120_), .A2(new_n141_), .B(new_n219_), .Y(new_n261_));
  AO21x1_ASAP7_75t_R   g240(.A1(p2), .A2(new_n82_), .B(p5), .Y(new_n262_));
  AO32x1_ASAP7_75t_R   g241(.A1(new_n156_), .A2(p1), .A3(new_n27_), .B1(new_n168_), .B2(new_n262_), .Y(new_n263_));
  OAI21x1_ASAP7_75t_R  g242(.A1(new_n261_), .A2(new_n263_), .B(new_n151_), .Y(new_n264_));
  OR3x1_ASAP7_75t_R    g243(.A(new_n46_), .B(new_n75_), .C(p5), .Y(new_n265_));
  AO21x1_ASAP7_75t_R   g244(.A1(new_n237_), .A2(new_n265_), .B(new_n79_), .Y(new_n266_));
  OR3x1_ASAP7_75t_R    g245(.A(new_n165_), .B(new_n237_), .C(p8), .Y(new_n267_));
  OR3x1_ASAP7_75t_R    g246(.A(new_n64_), .B(p0), .C(p7), .Y(new_n268_));
  AND3x1_ASAP7_75t_R   g247(.A(new_n266_), .B(new_n267_), .C(new_n268_), .Y(new_n269_));
  INVx1_ASAP7_75t_R    g248(.A(new_n127_), .Y(new_n270_));
  AO21x1_ASAP7_75t_R   g249(.A1(new_n138_), .A2(new_n270_), .B(new_n220_), .Y(new_n271_));
  OA21x2_ASAP7_75t_R   g250(.A1(new_n189_), .A2(new_n237_), .B(new_n271_), .Y(new_n272_));
  AO21x1_ASAP7_75t_R   g251(.A1(new_n63_), .A2(new_n26_), .B(new_n110_), .Y(new_n273_));
  OA21x2_ASAP7_75t_R   g252(.A1(new_n101_), .A2(new_n50_), .B(p2), .Y(new_n274_));
  NAND2x1_ASAP7_75t_R  g253(.A(new_n273_), .B(new_n274_), .Y(new_n275_));
  NAND2x1_ASAP7_75t_R  g254(.A(p5), .B(new_n148_), .Y(new_n276_));
  OR3x1_ASAP7_75t_R    g255(.A(new_n100_), .B(new_n170_), .C(new_n26_), .Y(new_n277_));
  AO21x1_ASAP7_75t_R   g256(.A1(new_n276_), .A2(new_n277_), .B(new_n35_), .Y(new_n278_));
  AND5x1_ASAP7_75t_R   g257(.A(new_n264_), .B(new_n269_), .C(new_n272_), .D(new_n275_), .E(new_n278_), .Y(new_n279_));
  OAI22x1_ASAP7_75t_R  g258(.A1(new_n259_), .A2(new_n260_), .B1(new_n185_), .B2(new_n279_), .Y(o3));
  AND3x1_ASAP7_75t_R   g259(.A(new_n97_), .B(p1), .C(new_n105_), .Y(new_n281_));
  NOR2x1_ASAP7_75t_R   g260(.A(p2), .B(new_n105_), .Y(new_n282_));
  NOR2x1_ASAP7_75t_R   g261(.A(p3), .B(new_n46_), .Y(new_n283_));
  OA21x2_ASAP7_75t_R   g262(.A1(new_n282_), .A2(new_n283_), .B(new_n108_), .Y(new_n284_));
  NOR2x1_ASAP7_75t_R   g263(.A(p6), .B(new_n112_), .Y(new_n285_));
  OA21x2_ASAP7_75t_R   g264(.A1(new_n281_), .A2(new_n284_), .B(new_n285_), .Y(o4));
  INVx1_ASAP7_75t_R    g265(.A(new_n108_), .Y(new_n287_));
  AND2x2_ASAP7_75t_R   g266(.A(new_n283_), .B(new_n287_), .Y(new_n288_));
  AND3x1_ASAP7_75t_R   g267(.A(new_n108_), .B(new_n282_), .C(new_n285_), .Y(new_n289_));
  AO21x1_ASAP7_75t_R   g268(.A1(new_n285_), .A2(new_n288_), .B(new_n289_), .Y(o5));
  OR3x1_ASAP7_75t_R    g269(.A(new_n162_), .B(new_n31_), .C(new_n131_), .Y(new_n291_));
  NAND2x1_ASAP7_75t_R  g270(.A(p1), .B(new_n33_), .Y(new_n292_));
  AO32x1_ASAP7_75t_R   g271(.A1(new_n222_), .A2(p5), .A3(p9), .B1(new_n23_), .B2(new_n292_), .Y(new_n293_));
  NAND2x1_ASAP7_75t_R  g272(.A(p8), .B(new_n293_), .Y(new_n294_));
  AO21x1_ASAP7_75t_R   g273(.A1(new_n291_), .A2(new_n294_), .B(new_n46_), .Y(new_n295_));
  OA21x2_ASAP7_75t_R   g274(.A1(p7), .A2(p8), .B(p1), .Y(new_n296_));
  NOR2x1_ASAP7_75t_R   g275(.A(new_n30_), .B(new_n202_), .Y(new_n297_));
  AO21x1_ASAP7_75t_R   g276(.A1(p0), .A2(new_n296_), .B(new_n297_), .Y(new_n298_));
  AO21x1_ASAP7_75t_R   g277(.A1(p1), .A2(new_n26_), .B(p5), .Y(new_n299_));
  INVx1_ASAP7_75t_R    g278(.A(new_n37_), .Y(new_n300_));
  OA21x2_ASAP7_75t_R   g279(.A1(new_n299_), .A2(new_n300_), .B(new_n23_), .Y(new_n301_));
  AO21x1_ASAP7_75t_R   g280(.A1(new_n120_), .A2(new_n35_), .B(new_n37_), .Y(new_n302_));
  AND3x1_ASAP7_75t_R   g281(.A(new_n49_), .B(new_n75_), .C(new_n27_), .Y(new_n303_));
  AO21x1_ASAP7_75t_R   g282(.A1(p5), .A2(new_n82_), .B(p9), .Y(new_n304_));
  NOR2x1_ASAP7_75t_R   g283(.A(p0), .B(new_n82_), .Y(new_n305_));
  NOR2x1_ASAP7_75t_R   g284(.A(p9), .B(new_n133_), .Y(new_n306_));
  AO32x1_ASAP7_75t_R   g285(.A1(new_n303_), .A2(new_n22_), .A3(new_n304_), .B1(new_n305_), .B2(new_n306_), .Y(new_n307_));
  AOI221x1_ASAP7_75t_R g286(.A1(p5), .A2(new_n298_), .B1(new_n301_), .B2(new_n302_), .C(new_n307_), .Y(new_n308_));
  AO21x1_ASAP7_75t_R   g287(.A1(new_n22_), .A2(new_n203_), .B(new_n33_), .Y(new_n309_));
  NOR2x1_ASAP7_75t_R   g288(.A(new_n125_), .B(new_n309_), .Y(new_n310_));
  OA211x2_ASAP7_75t_R  g289(.A1(new_n246_), .A2(new_n172_), .B(new_n102_), .C(new_n165_), .Y(new_n311_));
  OAI21x1_ASAP7_75t_R  g290(.A1(new_n310_), .A2(new_n311_), .B(new_n169_), .Y(new_n312_));
  NAND3x1_ASAP7_75t_R  g291(.A(new_n295_), .B(new_n308_), .C(new_n312_), .Y(new_n313_));
  AO21x1_ASAP7_75t_R   g292(.A1(p3), .A2(new_n109_), .B(new_n285_), .Y(new_n314_));
  NOR2x1_ASAP7_75t_R   g293(.A(new_n139_), .B(new_n297_), .Y(new_n315_));
  OR3x1_ASAP7_75t_R    g294(.A(new_n315_), .B(new_n83_), .C(p1), .Y(new_n316_));
  NAND2x1_ASAP7_75t_R  g295(.A(p0), .B(new_n56_), .Y(new_n317_));
  NAND2x1_ASAP7_75t_R  g296(.A(p6), .B(new_n27_), .Y(new_n318_));
  AO21x1_ASAP7_75t_R   g297(.A1(p7), .A2(new_n318_), .B(new_n24_), .Y(new_n319_));
  AO21x1_ASAP7_75t_R   g298(.A1(new_n317_), .A2(new_n319_), .B(p9), .Y(new_n320_));
  AO21x1_ASAP7_75t_R   g299(.A1(new_n316_), .A2(new_n320_), .B(new_n255_), .Y(new_n321_));
  AO21x1_ASAP7_75t_R   g300(.A1(new_n82_), .A2(new_n59_), .B(new_n297_), .Y(new_n322_));
  OA21x2_ASAP7_75t_R   g301(.A1(new_n306_), .A2(new_n322_), .B(p4), .Y(new_n323_));
  AO21x1_ASAP7_75t_R   g302(.A1(new_n130_), .A2(new_n100_), .B(new_n63_), .Y(new_n324_));
  AND5x1_ASAP7_75t_R   g303(.A(p7), .B(new_n74_), .C(new_n110_), .D(new_n181_), .E(p9), .Y(new_n325_));
  NOR2x1_ASAP7_75t_R   g304(.A(p9), .B(new_n82_), .Y(new_n326_));
  AND3x1_ASAP7_75t_R   g305(.A(new_n138_), .B(new_n326_), .C(p1), .Y(new_n327_));
  NOR2x1_ASAP7_75t_R   g306(.A(new_n325_), .B(new_n327_), .Y(new_n328_));
  OAI21x1_ASAP7_75t_R  g307(.A1(new_n141_), .A2(new_n324_), .B(new_n328_), .Y(new_n329_));
  OAI21x1_ASAP7_75t_R  g308(.A1(new_n323_), .A2(new_n329_), .B(new_n83_), .Y(new_n330_));
  NAND2x1_ASAP7_75t_R  g309(.A(new_n46_), .B(new_n105_), .Y(new_n331_));
  AOI21x1_ASAP7_75t_R  g310(.A1(new_n321_), .A2(new_n330_), .B(new_n331_), .Y(new_n332_));
  AOI211x1_ASAP7_75t_R g311(.A1(new_n72_), .A2(new_n313_), .B(new_n314_), .C(new_n332_), .Y(o6));
  OR3x1_ASAP7_75t_R    g312(.A(new_n82_), .B(new_n33_), .C(p1), .Y(new_n334_));
  OAI22x1_ASAP7_75t_R  g313(.A1(new_n204_), .A2(new_n292_), .B1(new_n334_), .B2(new_n318_), .Y(new_n335_));
  INVx1_ASAP7_75t_R    g314(.A(new_n255_), .Y(new_n336_));
  AND3x1_ASAP7_75t_R   g315(.A(new_n335_), .B(new_n67_), .C(new_n336_), .Y(new_n337_));
  OA21x2_ASAP7_75t_R   g316(.A1(new_n83_), .A2(new_n337_), .B(new_n105_), .Y(new_n338_));
  AOI21x1_ASAP7_75t_R  g317(.A1(new_n64_), .A2(new_n233_), .B(new_n27_), .Y(new_n339_));
  NAND2x1_ASAP7_75t_R  g318(.A(p7), .B(new_n33_), .Y(new_n340_));
  NAND2x1_ASAP7_75t_R  g319(.A(new_n340_), .B(new_n233_), .Y(new_n341_));
  AOI221x1_ASAP7_75t_R g320(.A1(new_n33_), .A2(p8), .B1(new_n121_), .B2(new_n82_), .C(new_n172_), .Y(new_n342_));
  AOI22x1_ASAP7_75t_R  g321(.A1(new_n339_), .A2(new_n341_), .B1(new_n64_), .B2(new_n342_), .Y(new_n343_));
  NAND3x1_ASAP7_75t_R  g322(.A(new_n46_), .B(p7), .C(p8), .Y(new_n344_));
  AOI21x1_ASAP7_75t_R  g323(.A1(p5), .A2(new_n344_), .B(new_n75_), .Y(new_n345_));
  NAND2x1_ASAP7_75t_R  g324(.A(p2), .B(new_n202_), .Y(new_n346_));
  NAND3x1_ASAP7_75t_R  g325(.A(new_n346_), .B(new_n344_), .C(new_n160_), .Y(new_n347_));
  AND3x1_ASAP7_75t_R   g326(.A(new_n110_), .B(new_n82_), .C(new_n46_), .Y(new_n348_));
  AOI21x1_ASAP7_75t_R  g327(.A1(new_n345_), .A2(new_n347_), .B(new_n348_), .Y(new_n349_));
  OAI21x1_ASAP7_75t_R  g328(.A1(p1), .A2(new_n343_), .B(new_n349_), .Y(new_n350_));
  NAND2x1_ASAP7_75t_R  g329(.A(p5), .B(new_n33_), .Y(new_n351_));
  AOI21x1_ASAP7_75t_R  g330(.A1(new_n202_), .A2(new_n203_), .B(new_n351_), .Y(new_n352_));
  OA221x2_ASAP7_75t_R  g331(.A1(new_n33_), .A2(p8), .B1(new_n110_), .B2(new_n127_), .C(new_n75_), .Y(new_n353_));
  OAI21x1_ASAP7_75t_R  g332(.A1(new_n352_), .A2(new_n353_), .B(new_n252_), .Y(new_n354_));
  OAI21x1_ASAP7_75t_R  g333(.A1(p5), .A2(new_n60_), .B(new_n296_), .Y(new_n355_));
  OR3x1_ASAP7_75t_R    g334(.A(new_n160_), .B(new_n63_), .C(p8), .Y(new_n356_));
  AO31x2_ASAP7_75t_R   g335(.A1(new_n355_), .A2(new_n356_), .A3(new_n132_), .B(p0), .Y(new_n357_));
  OR3x1_ASAP7_75t_R    g336(.A(new_n208_), .B(new_n63_), .C(new_n46_), .Y(new_n358_));
  NAND3x1_ASAP7_75t_R  g337(.A(new_n354_), .B(new_n357_), .C(new_n358_), .Y(new_n359_));
  AOI21x1_ASAP7_75t_R  g338(.A1(p0), .A2(new_n350_), .B(new_n359_), .Y(new_n360_));
  NAND3x1_ASAP7_75t_R  g339(.A(new_n203_), .B(new_n202_), .C(new_n65_), .Y(new_n361_));
  NOR3x1_ASAP7_75t_R   g340(.A(new_n94_), .B(new_n78_), .C(new_n40_), .Y(new_n362_));
  NAND2x1_ASAP7_75t_R  g341(.A(p1), .B(new_n139_), .Y(new_n363_));
  NAND3x1_ASAP7_75t_R  g342(.A(p2), .B(p4), .C(p8), .Y(new_n364_));
  OAI22x1_ASAP7_75t_R  g343(.A1(new_n363_), .A2(new_n80_), .B1(new_n130_), .B2(new_n364_), .Y(new_n365_));
  AOI21x1_ASAP7_75t_R  g344(.A1(new_n361_), .A2(new_n362_), .B(new_n365_), .Y(new_n366_));
  AND2x2_ASAP7_75t_R   g345(.A(p2), .B(p4), .Y(new_n367_));
  AO21x1_ASAP7_75t_R   g346(.A1(p1), .A2(new_n27_), .B(new_n367_), .Y(new_n368_));
  AND3x1_ASAP7_75t_R   g347(.A(new_n120_), .B(p2), .C(new_n202_), .Y(new_n369_));
  AOI21x1_ASAP7_75t_R  g348(.A1(new_n131_), .A2(new_n368_), .B(new_n369_), .Y(new_n370_));
  AND3x1_ASAP7_75t_R   g349(.A(new_n57_), .B(new_n82_), .C(p4), .Y(new_n371_));
  NAND2x1_ASAP7_75t_R  g350(.A(p4), .B(new_n33_), .Y(new_n372_));
  OAI21x1_ASAP7_75t_R  g351(.A1(p1), .A2(p8), .B(p9), .Y(new_n373_));
  OAI22x1_ASAP7_75t_R  g352(.A1(new_n372_), .A2(p8), .B1(new_n57_), .B2(new_n373_), .Y(new_n374_));
  AO31x2_ASAP7_75t_R   g353(.A1(p1), .A2(p4), .A3(p8), .B(p7), .Y(new_n375_));
  AND2x2_ASAP7_75t_R   g354(.A(new_n46_), .B(new_n375_), .Y(new_n376_));
  OAI21x1_ASAP7_75t_R  g355(.A1(new_n371_), .A2(new_n374_), .B(new_n376_), .Y(new_n377_));
  NAND3x1_ASAP7_75t_R  g356(.A(new_n366_), .B(new_n370_), .C(new_n377_), .Y(new_n378_));
  AOI21x1_ASAP7_75t_R  g357(.A1(new_n22_), .A2(new_n366_), .B(p5), .Y(new_n379_));
  AOI21x1_ASAP7_75t_R  g358(.A1(new_n378_), .A2(new_n379_), .B(new_n337_), .Y(new_n380_));
  OAI21x1_ASAP7_75t_R  g359(.A1(p4), .A2(new_n360_), .B(new_n380_), .Y(new_n381_));
  AND3x1_ASAP7_75t_R   g360(.A(new_n109_), .B(p3), .C(new_n336_), .Y(new_n382_));
  AOI21x1_ASAP7_75t_R  g361(.A1(new_n338_), .A2(new_n381_), .B(new_n382_), .Y(o7));
  OA211x2_ASAP7_75t_R  g362(.A1(p4), .A2(new_n326_), .B(new_n246_), .C(new_n182_), .Y(new_n384_));
  AND5x1_ASAP7_75t_R   g363(.A(p7), .B(new_n54_), .C(new_n168_), .D(new_n75_), .E(new_n176_), .Y(new_n385_));
  AND3x1_ASAP7_75t_R   g364(.A(new_n162_), .B(p7), .C(new_n67_), .Y(new_n386_));
  OR3x1_ASAP7_75t_R    g365(.A(new_n384_), .B(new_n385_), .C(new_n386_), .Y(new_n387_));
  OA211x2_ASAP7_75t_R  g366(.A1(p7), .A2(new_n46_), .B(new_n65_), .C(p0), .Y(new_n388_));
  AO21x1_ASAP7_75t_R   g367(.A1(p1), .A2(new_n26_), .B(new_n367_), .Y(new_n389_));
  AO32x1_ASAP7_75t_R   g368(.A1(new_n372_), .A2(new_n252_), .A3(new_n222_), .B1(new_n388_), .B2(new_n389_), .Y(new_n390_));
  AOI22x1_ASAP7_75t_R  g369(.A1(new_n387_), .A2(new_n110_), .B1(new_n248_), .B2(new_n390_), .Y(new_n391_));
  AND3x1_ASAP7_75t_R   g370(.A(new_n201_), .B(new_n168_), .C(new_n176_), .Y(new_n392_));
  OAI21x1_ASAP7_75t_R  g371(.A1(new_n56_), .A2(new_n219_), .B(new_n392_), .Y(new_n393_));
  NAND2x1_ASAP7_75t_R  g372(.A(new_n59_), .B(new_n120_), .Y(new_n394_));
  AO21x1_ASAP7_75t_R   g373(.A1(new_n234_), .A2(new_n394_), .B(p9), .Y(new_n395_));
  NAND2x1_ASAP7_75t_R  g374(.A(new_n22_), .B(new_n26_), .Y(new_n396_));
  AO21x1_ASAP7_75t_R   g375(.A1(new_n396_), .A2(new_n102_), .B(new_n205_), .Y(new_n397_));
  AO31x2_ASAP7_75t_R   g376(.A1(new_n393_), .A2(new_n395_), .A3(new_n397_), .B(new_n270_), .Y(new_n398_));
  NOR2x1_ASAP7_75t_R   g377(.A(p5), .B(new_n23_), .Y(new_n399_));
  AO21x1_ASAP7_75t_R   g378(.A1(p8), .A2(new_n22_), .B(new_n63_), .Y(new_n400_));
  AO21x1_ASAP7_75t_R   g379(.A1(new_n31_), .A2(new_n326_), .B(new_n400_), .Y(new_n401_));
  AO221x2_ASAP7_75t_R  g380(.A1(new_n309_), .A2(new_n399_), .B1(new_n401_), .B2(new_n75_), .C(new_n168_), .Y(new_n402_));
  NAND3x1_ASAP7_75t_R  g381(.A(new_n391_), .B(new_n398_), .C(new_n402_), .Y(new_n403_));
  AO22x1_ASAP7_75t_R   g382(.A1(new_n75_), .A2(new_n101_), .B1(p8), .B2(new_n25_), .Y(new_n404_));
  AO21x1_ASAP7_75t_R   g383(.A1(new_n130_), .A2(new_n100_), .B(p9), .Y(new_n405_));
  NAND2x1_ASAP7_75t_R  g384(.A(new_n334_), .B(new_n405_), .Y(new_n406_));
  AO32x1_ASAP7_75t_R   g385(.A1(new_n404_), .A2(new_n82_), .A3(new_n33_), .B1(new_n406_), .B2(new_n59_), .Y(new_n407_));
  AO32x1_ASAP7_75t_R   g386(.A1(new_n26_), .A2(p3), .A3(new_n109_), .B1(new_n407_), .B2(new_n149_), .Y(new_n408_));
  AOI21x1_ASAP7_75t_R  g387(.A1(new_n72_), .A2(new_n403_), .B(new_n408_), .Y(o8));
  AO21x1_ASAP7_75t_R   g388(.A1(new_n282_), .A2(new_n255_), .B(p1), .Y(new_n410_));
  AND2x2_ASAP7_75t_R   g389(.A(p2), .B(new_n121_), .Y(new_n411_));
  OA21x2_ASAP7_75t_R   g390(.A1(new_n340_), .A2(new_n273_), .B(new_n411_), .Y(new_n412_));
  OR5x1_ASAP7_75t_R    g391(.A(p2), .B(new_n88_), .C(new_n38_), .D(new_n139_), .E(new_n75_), .Y(new_n413_));
  OA21x2_ASAP7_75t_R   g392(.A1(new_n410_), .A2(new_n412_), .B(new_n413_), .Y(new_n414_));
  OA21x2_ASAP7_75t_R   g393(.A1(p2), .A2(new_n88_), .B(new_n340_), .Y(new_n415_));
  OR3x1_ASAP7_75t_R    g394(.A(new_n415_), .B(p1), .C(new_n411_), .Y(new_n416_));
  OR3x1_ASAP7_75t_R    g395(.A(new_n273_), .B(p2), .C(new_n127_), .Y(new_n417_));
  OA21x2_ASAP7_75t_R   g396(.A1(new_n257_), .A2(new_n265_), .B(new_n417_), .Y(new_n418_));
  AO21x1_ASAP7_75t_R   g397(.A1(new_n416_), .A2(new_n418_), .B(new_n22_), .Y(new_n419_));
  OR3x1_ASAP7_75t_R    g398(.A(new_n207_), .B(p5), .C(new_n65_), .Y(new_n420_));
  AO22x1_ASAP7_75t_R   g399(.A1(new_n22_), .A2(new_n203_), .B1(new_n83_), .B2(new_n420_), .Y(new_n421_));
  NAND2x1_ASAP7_75t_R  g400(.A(new_n67_), .B(new_n89_), .Y(new_n422_));
  AO21x1_ASAP7_75t_R   g401(.A1(new_n26_), .A2(new_n205_), .B(new_n63_), .Y(new_n423_));
  OAI21x1_ASAP7_75t_R  g402(.A1(p9), .A2(new_n205_), .B(p6), .Y(new_n424_));
  AND5x1_ASAP7_75t_R   g403(.A(new_n421_), .B(new_n240_), .C(new_n422_), .D(new_n423_), .E(new_n424_), .Y(new_n425_));
  OA211x2_ASAP7_75t_R  g404(.A1(p0), .A2(new_n414_), .B(new_n419_), .C(new_n425_), .Y(o9));
  OR3x1_ASAP7_75t_R    g405(.A(new_n125_), .B(new_n82_), .C(new_n151_), .Y(new_n427_));
  AND5x1_ASAP7_75t_R   g406(.A(p2), .B(new_n336_), .C(p1), .D(new_n28_), .E(new_n72_), .Y(new_n428_));
  AO21x1_ASAP7_75t_R   g407(.A1(new_n427_), .A2(new_n428_), .B(new_n382_), .Y(o10));
endmodule


