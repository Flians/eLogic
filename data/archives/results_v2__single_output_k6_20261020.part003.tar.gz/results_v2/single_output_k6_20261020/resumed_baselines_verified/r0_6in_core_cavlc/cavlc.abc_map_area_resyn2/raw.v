// Benchmark "/home/flynn/workplace/MIGBalance/results_v2/single_output_k6_20261020/resumed_baselines_verified/r0_6in_core_cavlc/cavlc.resyn2" written by ABC on Tue Oct 20 17:19:21 2026

module \/home/flynn/workplace/MIGBalance/results_v2/single_output_k6_20261020/resumed_baselines_verified/r0_6in_core_cavlc/cavlc.resyn2  ( 
    \totalcoeffs[0] , \totalcoeffs[1] , \totalcoeffs[2] , \totalcoeffs[3] ,
    \totalcoeffs[4] , \ctable[0] , \ctable[1] , \ctable[2] ,
    \trailingones[0] , \trailingones[1] ,
    \coeff_token[0] , \coeff_token[1] , \coeff_token[2] , \coeff_token[3] ,
    \coeff_token[4] , \coeff_token[5] , \ctoken_len[0] , \ctoken_len[1] ,
    \ctoken_len[2] , \ctoken_len[3] , \ctoken_len[4]   );
  input  \totalcoeffs[0] , \totalcoeffs[1] , \totalcoeffs[2] ,
    \totalcoeffs[3] , \totalcoeffs[4] , \ctable[0] , \ctable[1] ,
    \ctable[2] , \trailingones[0] , \trailingones[1] ;
  output \coeff_token[0] , \coeff_token[1] , \coeff_token[2] ,
    \coeff_token[3] , \coeff_token[4] , \coeff_token[5] , \ctoken_len[0] ,
    \ctoken_len[1] , \ctoken_len[2] , \ctoken_len[3] , \ctoken_len[4] ;
  wire new_n22_, new_n23_, new_n24_, new_n25_, new_n26_, new_n27_, new_n28_,
    new_n29_, new_n30_, new_n31_, new_n32_, new_n33_, new_n34_, new_n35_,
    new_n36_, new_n37_, new_n38_, new_n39_, new_n40_, new_n41_, new_n42_,
    new_n43_, new_n44_, new_n45_, new_n46_, new_n47_, new_n48_, new_n49_,
    new_n50_, new_n51_, new_n52_, new_n53_, new_n54_, new_n55_, new_n56_,
    new_n57_, new_n58_, new_n59_, new_n60_, new_n61_, new_n62_, new_n63_,
    new_n64_, new_n65_, new_n66_, new_n67_, new_n68_, new_n69_, new_n70_,
    new_n71_, new_n72_, new_n73_, new_n74_, new_n75_, new_n76_, new_n77_,
    new_n78_, new_n79_, new_n80_, new_n81_, new_n82_, new_n83_, new_n84_,
    new_n85_, new_n86_, new_n87_, new_n88_, new_n89_, new_n90_, new_n91_,
    new_n92_, new_n93_, new_n94_, new_n95_, new_n96_, new_n97_, new_n98_,
    new_n99_, new_n100_, new_n102_, new_n103_, new_n104_, new_n105_,
    new_n106_, new_n107_, new_n108_, new_n109_, new_n110_, new_n111_,
    new_n112_, new_n113_, new_n114_, new_n115_, new_n116_, new_n117_,
    new_n118_, new_n119_, new_n120_, new_n121_, new_n122_, new_n123_,
    new_n124_, new_n125_, new_n126_, new_n127_, new_n128_, new_n129_,
    new_n130_, new_n131_, new_n132_, new_n133_, new_n134_, new_n135_,
    new_n136_, new_n137_, new_n138_, new_n139_, new_n140_, new_n141_,
    new_n142_, new_n143_, new_n144_, new_n145_, new_n146_, new_n147_,
    new_n148_, new_n149_, new_n150_, new_n151_, new_n152_, new_n153_,
    new_n154_, new_n155_, new_n156_, new_n157_, new_n158_, new_n159_,
    new_n160_, new_n161_, new_n162_, new_n163_, new_n164_, new_n165_,
    new_n166_, new_n167_, new_n169_, new_n170_, new_n171_, new_n172_,
    new_n173_, new_n174_, new_n175_, new_n176_, new_n177_, new_n178_,
    new_n179_, new_n180_, new_n181_, new_n182_, new_n183_, new_n184_,
    new_n185_, new_n186_, new_n187_, new_n188_, new_n189_, new_n190_,
    new_n191_, new_n192_, new_n193_, new_n194_, new_n195_, new_n196_,
    new_n197_, new_n198_, new_n199_, new_n200_, new_n201_, new_n202_,
    new_n203_, new_n204_, new_n205_, new_n206_, new_n207_, new_n208_,
    new_n209_, new_n210_, new_n211_, new_n212_, new_n213_, new_n214_,
    new_n215_, new_n216_, new_n217_, new_n218_, new_n219_, new_n220_,
    new_n221_, new_n223_, new_n224_, new_n225_, new_n226_, new_n227_,
    new_n228_, new_n229_, new_n230_, new_n231_, new_n232_, new_n233_,
    new_n234_, new_n235_, new_n236_, new_n237_, new_n238_, new_n239_,
    new_n240_, new_n241_, new_n242_, new_n243_, new_n244_, new_n245_,
    new_n246_, new_n247_, new_n248_, new_n249_, new_n250_, new_n251_,
    new_n252_, new_n253_, new_n254_, new_n255_, new_n256_, new_n257_,
    new_n258_, new_n259_, new_n260_, new_n261_, new_n262_, new_n263_,
    new_n264_, new_n265_, new_n267_, new_n268_, new_n269_, new_n270_,
    new_n271_, new_n273_, new_n274_, new_n275_, new_n277_, new_n278_,
    new_n279_, new_n280_, new_n281_, new_n282_, new_n283_, new_n284_,
    new_n285_, new_n286_, new_n287_, new_n288_, new_n289_, new_n290_,
    new_n291_, new_n292_, new_n293_, new_n294_, new_n295_, new_n296_,
    new_n297_, new_n298_, new_n299_, new_n300_, new_n301_, new_n302_,
    new_n303_, new_n304_, new_n305_, new_n306_, new_n307_, new_n308_,
    new_n309_, new_n310_, new_n311_, new_n313_, new_n314_, new_n315_,
    new_n316_, new_n317_, new_n318_, new_n319_, new_n320_, new_n321_,
    new_n322_, new_n323_, new_n324_, new_n325_, new_n326_, new_n327_,
    new_n328_, new_n329_, new_n330_, new_n331_, new_n332_, new_n333_,
    new_n334_, new_n335_, new_n336_, new_n337_, new_n338_, new_n339_,
    new_n340_, new_n341_, new_n342_, new_n343_, new_n344_, new_n345_,
    new_n346_, new_n347_, new_n348_, new_n350_, new_n351_, new_n352_,
    new_n353_, new_n354_, new_n355_, new_n356_, new_n357_, new_n358_,
    new_n359_, new_n360_, new_n361_, new_n362_, new_n363_, new_n364_,
    new_n365_, new_n366_, new_n367_, new_n368_, new_n369_, new_n370_,
    new_n371_, new_n372_, new_n373_, new_n374_, new_n375_, new_n376_,
    new_n377_, new_n378_, new_n379_, new_n381_, new_n382_, new_n383_,
    new_n384_, new_n385_, new_n386_, new_n387_, new_n388_, new_n389_,
    new_n390_, new_n391_, new_n392_, new_n393_, new_n394_, new_n395_,
    new_n396_, new_n398_, new_n399_;
  INVx1_ASAP7_75t_R    g000(.A(\totalcoeffs[4] ), .Y(new_n22_));
  INVx1_ASAP7_75t_R    g001(.A(\ctable[2] ), .Y(new_n23_));
  INVx1_ASAP7_75t_R    g002(.A(\ctable[1] ), .Y(new_n24_));
  INVx1_ASAP7_75t_R    g003(.A(\totalcoeffs[3] ), .Y(new_n25_));
  INVx1_ASAP7_75t_R    g004(.A(\totalcoeffs[2] ), .Y(new_n26_));
  INVx1_ASAP7_75t_R    g005(.A(\ctable[0] ), .Y(new_n27_));
  AND3x1_ASAP7_75t_R   g006(.A(new_n27_), .B(\ctable[2] ), .C(\trailingones[0] ), .Y(new_n28_));
  AO21x1_ASAP7_75t_R   g007(.A1(new_n23_), .A2(\trailingones[1] ), .B(new_n28_), .Y(new_n29_));
  INVx1_ASAP7_75t_R    g008(.A(\totalcoeffs[1] ), .Y(new_n30_));
  NOR2x1_ASAP7_75t_R   g009(.A(\ctable[0] ), .B(\trailingones[1] ), .Y(new_n31_));
  OA21x2_ASAP7_75t_R   g010(.A1(new_n30_), .A2(\ctable[2] ), .B(new_n31_), .Y(new_n32_));
  AO21x1_ASAP7_75t_R   g011(.A1(new_n29_), .A2(\totalcoeffs[1] ), .B(new_n32_), .Y(new_n33_));
  AND3x1_ASAP7_75t_R   g012(.A(new_n33_), .B(\totalcoeffs[0] ), .C(new_n26_), .Y(new_n34_));
  NOR2x1_ASAP7_75t_R   g013(.A(\totalcoeffs[0] ), .B(\totalcoeffs[1] ), .Y(new_n35_));
  INVx1_ASAP7_75t_R    g014(.A(\trailingones[1] ), .Y(new_n36_));
  AND2x2_ASAP7_75t_R   g015(.A(new_n36_), .B(\totalcoeffs[2] ), .Y(new_n37_));
  AND3x1_ASAP7_75t_R   g016(.A(new_n28_), .B(new_n35_), .C(new_n37_), .Y(new_n38_));
  OA21x2_ASAP7_75t_R   g017(.A1(new_n34_), .A2(new_n38_), .B(new_n25_), .Y(new_n39_));
  INVx1_ASAP7_75t_R    g018(.A(\totalcoeffs[0] ), .Y(new_n40_));
  AND2x2_ASAP7_75t_R   g019(.A(new_n40_), .B(\trailingones[1] ), .Y(new_n41_));
  NOR2x1_ASAP7_75t_R   g020(.A(new_n30_), .B(new_n41_), .Y(new_n42_));
  AND2x2_ASAP7_75t_R   g021(.A(new_n30_), .B(\trailingones[1] ), .Y(new_n43_));
  OR4x2_ASAP7_75t_R    g022(.A(new_n42_), .B(\totalcoeffs[3] ), .C(\ctable[0] ), .D(new_n43_), .Y(new_n44_));
  AND2x2_ASAP7_75t_R   g023(.A(new_n36_), .B(\totalcoeffs[0] ), .Y(new_n45_));
  INVx1_ASAP7_75t_R    g024(.A(new_n45_), .Y(new_n46_));
  AO21x1_ASAP7_75t_R   g025(.A1(new_n36_), .A2(\totalcoeffs[1] ), .B(\ctable[2] ), .Y(new_n47_));
  AO21x1_ASAP7_75t_R   g026(.A1(new_n46_), .A2(new_n30_), .B(new_n47_), .Y(new_n48_));
  AO21x1_ASAP7_75t_R   g027(.A1(new_n44_), .A2(new_n48_), .B(\totalcoeffs[2] ), .Y(new_n49_));
  AND2x2_ASAP7_75t_R   g028(.A(\totalcoeffs[1] ), .B(\totalcoeffs[2] ), .Y(new_n50_));
  OA21x2_ASAP7_75t_R   g029(.A1(\totalcoeffs[2] ), .A2(\ctable[0] ), .B(new_n40_), .Y(new_n51_));
  OAI21x1_ASAP7_75t_R  g030(.A1(new_n50_), .A2(new_n51_), .B(new_n36_), .Y(new_n52_));
  AO21x1_ASAP7_75t_R   g031(.A1(new_n26_), .A2(new_n25_), .B(new_n36_), .Y(new_n53_));
  AND2x2_ASAP7_75t_R   g032(.A(\totalcoeffs[0] ), .B(\totalcoeffs[3] ), .Y(new_n54_));
  INVx1_ASAP7_75t_R    g033(.A(new_n54_), .Y(new_n55_));
  AO21x1_ASAP7_75t_R   g034(.A1(new_n55_), .A2(new_n53_), .B(\totalcoeffs[1] ), .Y(new_n56_));
  OA21x2_ASAP7_75t_R   g035(.A1(new_n30_), .A2(\totalcoeffs[3] ), .B(new_n56_), .Y(new_n57_));
  AO21x1_ASAP7_75t_R   g036(.A1(new_n57_), .A2(new_n52_), .B(\ctable[2] ), .Y(new_n58_));
  AOI21x1_ASAP7_75t_R  g037(.A1(new_n58_), .A2(new_n49_), .B(\trailingones[0] ), .Y(new_n59_));
  OA21x2_ASAP7_75t_R   g038(.A1(new_n59_), .A2(new_n39_), .B(new_n24_), .Y(new_n60_));
  NOR2x1_ASAP7_75t_R   g039(.A(\totalcoeffs[0] ), .B(\totalcoeffs[2] ), .Y(new_n61_));
  AO21x1_ASAP7_75t_R   g040(.A1(new_n43_), .A2(new_n61_), .B(\ctable[0] ), .Y(new_n62_));
  NOR2x1_ASAP7_75t_R   g041(.A(new_n41_), .B(new_n45_), .Y(new_n63_));
  AND2x2_ASAP7_75t_R   g042(.A(\totalcoeffs[1] ), .B(\ctable[0] ), .Y(new_n64_));
  AO32x1_ASAP7_75t_R   g043(.A1(\totalcoeffs[2] ), .A2(new_n63_), .A3(new_n64_), .B1(\ctable[1] ), .B2(new_n62_), .Y(new_n65_));
  INVx1_ASAP7_75t_R    g044(.A(\trailingones[0] ), .Y(new_n66_));
  AO21x1_ASAP7_75t_R   g045(.A1(new_n40_), .A2(\trailingones[1] ), .B(\totalcoeffs[1] ), .Y(new_n67_));
  AO32x1_ASAP7_75t_R   g046(.A1(new_n30_), .A2(new_n45_), .A3(\totalcoeffs[2] ), .B1(new_n66_), .B2(new_n67_), .Y(new_n68_));
  AO22x1_ASAP7_75t_R   g047(.A1(new_n65_), .A2(\trailingones[0] ), .B1(new_n27_), .B2(new_n68_), .Y(new_n69_));
  NOR2x1_ASAP7_75t_R   g048(.A(\totalcoeffs[2] ), .B(new_n45_), .Y(new_n70_));
  OR3x1_ASAP7_75t_R    g049(.A(new_n41_), .B(new_n30_), .C(\totalcoeffs[3] ), .Y(new_n71_));
  NAND2x1_ASAP7_75t_R  g050(.A(new_n70_), .B(new_n71_), .Y(new_n72_));
  AO21x1_ASAP7_75t_R   g051(.A1(new_n46_), .A2(new_n26_), .B(\ctable[1] ), .Y(new_n73_));
  AND2x2_ASAP7_75t_R   g052(.A(new_n36_), .B(\totalcoeffs[1] ), .Y(new_n74_));
  AND2x2_ASAP7_75t_R   g053(.A(\totalcoeffs[2] ), .B(\trailingones[1] ), .Y(new_n75_));
  AO21x1_ASAP7_75t_R   g054(.A1(new_n74_), .A2(new_n26_), .B(new_n75_), .Y(new_n76_));
  AND3x1_ASAP7_75t_R   g055(.A(new_n40_), .B(new_n25_), .C(\ctable[1] ), .Y(new_n77_));
  AO32x1_ASAP7_75t_R   g056(.A1(\ctable[0] ), .A2(new_n72_), .A3(new_n73_), .B1(new_n76_), .B2(new_n77_), .Y(new_n78_));
  NOR2x1_ASAP7_75t_R   g057(.A(\totalcoeffs[2] ), .B(\totalcoeffs[3] ), .Y(new_n79_));
  NOR2x1_ASAP7_75t_R   g058(.A(\totalcoeffs[1] ), .B(\trailingones[1] ), .Y(new_n80_));
  AND4x2_ASAP7_75t_R   g059(.A(new_n79_), .B(new_n80_), .C(new_n40_), .D(new_n66_), .Y(new_n81_));
  AO32x1_ASAP7_75t_R   g060(.A1(\totalcoeffs[2] ), .A2(new_n43_), .A3(new_n25_), .B1(\totalcoeffs[1] ), .B2(new_n66_), .Y(new_n82_));
  AO21x1_ASAP7_75t_R   g061(.A1(new_n26_), .A2(\ctable[1] ), .B(new_n25_), .Y(new_n83_));
  AO21x1_ASAP7_75t_R   g062(.A1(new_n83_), .A2(new_n80_), .B(new_n75_), .Y(new_n84_));
  AO22x1_ASAP7_75t_R   g063(.A1(new_n82_), .A2(new_n40_), .B1(new_n66_), .B2(new_n84_), .Y(new_n85_));
  AO21x1_ASAP7_75t_R   g064(.A1(new_n85_), .A2(new_n27_), .B(new_n81_), .Y(new_n86_));
  AO221x2_ASAP7_75t_R  g065(.A1(\totalcoeffs[3] ), .A2(new_n69_), .B1(\trailingones[0] ), .B2(new_n78_), .C(new_n86_), .Y(new_n87_));
  AO21x1_ASAP7_75t_R   g066(.A1(new_n23_), .A2(new_n87_), .B(new_n60_), .Y(new_n88_));
  AND2x2_ASAP7_75t_R   g067(.A(new_n24_), .B(\trailingones[0] ), .Y(new_n89_));
  NOR2x1_ASAP7_75t_R   g068(.A(new_n27_), .B(new_n89_), .Y(new_n90_));
  AND2x2_ASAP7_75t_R   g069(.A(\totalcoeffs[4] ), .B(\trailingones[0] ), .Y(new_n91_));
  NOR2x1_ASAP7_75t_R   g070(.A(\ctable[1] ), .B(\trailingones[1] ), .Y(new_n92_));
  OA21x2_ASAP7_75t_R   g071(.A1(new_n91_), .A2(new_n92_), .B(new_n90_), .Y(new_n93_));
  AND2x2_ASAP7_75t_R   g072(.A(new_n36_), .B(\ctable[1] ), .Y(new_n94_));
  AO21x1_ASAP7_75t_R   g073(.A1(\totalcoeffs[4] ), .A2(\trailingones[1] ), .B(new_n94_), .Y(new_n95_));
  NAND2x1_ASAP7_75t_R  g074(.A(\ctable[0] ), .B(\ctable[1] ), .Y(new_n96_));
  AND3x1_ASAP7_75t_R   g075(.A(new_n95_), .B(new_n66_), .C(new_n96_), .Y(new_n97_));
  NOR2x1_ASAP7_75t_R   g076(.A(\totalcoeffs[1] ), .B(\totalcoeffs[3] ), .Y(new_n98_));
  AND3x1_ASAP7_75t_R   g077(.A(new_n61_), .B(new_n98_), .C(new_n23_), .Y(new_n99_));
  OA21x2_ASAP7_75t_R   g078(.A1(new_n97_), .A2(new_n93_), .B(new_n99_), .Y(new_n100_));
  AO21x1_ASAP7_75t_R   g079(.A1(new_n88_), .A2(new_n22_), .B(new_n100_), .Y(\coeff_token[0] ));
  AND2x2_ASAP7_75t_R   g080(.A(new_n40_), .B(\ctable[0] ), .Y(new_n102_));
  INVx1_ASAP7_75t_R    g081(.A(new_n102_), .Y(new_n103_));
  AND2x2_ASAP7_75t_R   g082(.A(new_n66_), .B(\trailingones[1] ), .Y(new_n104_));
  INVx1_ASAP7_75t_R    g083(.A(new_n104_), .Y(new_n105_));
  AND2x2_ASAP7_75t_R   g084(.A(new_n27_), .B(\trailingones[0] ), .Y(new_n106_));
  INVx1_ASAP7_75t_R    g085(.A(new_n106_), .Y(new_n107_));
  AND2x2_ASAP7_75t_R   g086(.A(\ctable[1] ), .B(\trailingones[1] ), .Y(new_n108_));
  INVx1_ASAP7_75t_R    g087(.A(new_n108_), .Y(new_n109_));
  AO221x2_ASAP7_75t_R  g088(.A1(\ctable[1] ), .A2(\trailingones[0] ), .B1(new_n109_), .B2(new_n107_), .C(new_n40_), .Y(new_n110_));
  OAI21x1_ASAP7_75t_R  g089(.A1(new_n103_), .A2(new_n105_), .B(new_n110_), .Y(new_n111_));
  AO21x1_ASAP7_75t_R   g090(.A1(new_n40_), .A2(\ctable[1] ), .B(\totalcoeffs[2] ), .Y(new_n112_));
  AO22x1_ASAP7_75t_R   g091(.A1(new_n106_), .A2(new_n112_), .B1(new_n24_), .B2(new_n66_), .Y(new_n113_));
  AO22x1_ASAP7_75t_R   g092(.A1(new_n111_), .A2(new_n26_), .B1(new_n36_), .B2(new_n113_), .Y(new_n114_));
  NOR2x1_ASAP7_75t_R   g093(.A(\totalcoeffs[2] ), .B(\trailingones[0] ), .Y(new_n115_));
  AND3x1_ASAP7_75t_R   g094(.A(\totalcoeffs[0] ), .B(\trailingones[0] ), .C(\trailingones[1] ), .Y(new_n116_));
  AO32x1_ASAP7_75t_R   g095(.A1(new_n40_), .A2(new_n36_), .A3(new_n115_), .B1(\totalcoeffs[2] ), .B2(new_n116_), .Y(new_n117_));
  NAND2x1_ASAP7_75t_R  g096(.A(\ctable[0] ), .B(new_n117_), .Y(new_n118_));
  AO21x1_ASAP7_75t_R   g097(.A1(new_n107_), .A2(new_n109_), .B(\totalcoeffs[0] ), .Y(new_n119_));
  AND3x1_ASAP7_75t_R   g098(.A(new_n27_), .B(new_n66_), .C(new_n36_), .Y(new_n120_));
  AND3x1_ASAP7_75t_R   g099(.A(\ctable[1] ), .B(\trailingones[0] ), .C(\trailingones[1] ), .Y(new_n121_));
  NOR2x1_ASAP7_75t_R   g100(.A(new_n121_), .B(new_n120_), .Y(new_n122_));
  AO21x1_ASAP7_75t_R   g101(.A1(new_n119_), .A2(new_n122_), .B(new_n26_), .Y(new_n123_));
  AOI21x1_ASAP7_75t_R  g102(.A1(new_n118_), .A2(new_n123_), .B(\totalcoeffs[1] ), .Y(new_n124_));
  AO221x2_ASAP7_75t_R  g103(.A1(new_n37_), .A2(new_n89_), .B1(\totalcoeffs[1] ), .B2(new_n114_), .C(new_n124_), .Y(new_n125_));
  AND2x2_ASAP7_75t_R   g104(.A(new_n66_), .B(\ctable[0] ), .Y(new_n126_));
  OA21x2_ASAP7_75t_R   g105(.A1(new_n126_), .A2(new_n91_), .B(new_n92_), .Y(new_n127_));
  AO21x1_ASAP7_75t_R   g106(.A1(\totalcoeffs[4] ), .A2(new_n108_), .B(new_n127_), .Y(new_n128_));
  AO32x1_ASAP7_75t_R   g107(.A1(new_n26_), .A2(new_n35_), .A3(new_n128_), .B1(new_n22_), .B2(new_n125_), .Y(new_n129_));
  NOR2x1_ASAP7_75t_R   g108(.A(\totalcoeffs[3] ), .B(\trailingones[0] ), .Y(new_n130_));
  INVx1_ASAP7_75t_R    g109(.A(new_n130_), .Y(new_n131_));
  AND3x1_ASAP7_75t_R   g110(.A(new_n107_), .B(\totalcoeffs[0] ), .C(new_n131_), .Y(new_n132_));
  AO21x1_ASAP7_75t_R   g111(.A1(\ctable[0] ), .A2(new_n115_), .B(new_n132_), .Y(new_n133_));
  AO21x1_ASAP7_75t_R   g112(.A1(\totalcoeffs[3] ), .A2(\trailingones[0] ), .B(\totalcoeffs[2] ), .Y(new_n134_));
  AND3x1_ASAP7_75t_R   g113(.A(new_n26_), .B(\totalcoeffs[0] ), .C(\trailingones[0] ), .Y(new_n135_));
  AND2x2_ASAP7_75t_R   g114(.A(new_n27_), .B(\totalcoeffs[0] ), .Y(new_n136_));
  OR3x1_ASAP7_75t_R    g115(.A(new_n135_), .B(new_n102_), .C(new_n136_), .Y(new_n137_));
  AO22x1_ASAP7_75t_R   g116(.A1(new_n137_), .A2(\totalcoeffs[1] ), .B1(new_n40_), .B2(new_n134_), .Y(new_n138_));
  AO21x1_ASAP7_75t_R   g117(.A1(new_n133_), .A2(new_n30_), .B(new_n138_), .Y(new_n139_));
  NAND2x1_ASAP7_75t_R  g118(.A(new_n30_), .B(new_n66_), .Y(new_n140_));
  AND2x2_ASAP7_75t_R   g119(.A(new_n30_), .B(\trailingones[0] ), .Y(new_n141_));
  AO22x1_ASAP7_75t_R   g120(.A1(new_n140_), .A2(new_n26_), .B1(new_n141_), .B2(\ctable[1] ), .Y(new_n142_));
  AND2x2_ASAP7_75t_R   g121(.A(new_n40_), .B(\trailingones[0] ), .Y(new_n143_));
  NOR2x1_ASAP7_75t_R   g122(.A(\totalcoeffs[2] ), .B(new_n143_), .Y(new_n144_));
  NAND2x1_ASAP7_75t_R  g123(.A(\totalcoeffs[0] ), .B(\totalcoeffs[1] ), .Y(new_n145_));
  NAND2x1_ASAP7_75t_R  g124(.A(new_n30_), .B(new_n24_), .Y(new_n146_));
  AO32x1_ASAP7_75t_R   g125(.A1(new_n145_), .A2(new_n144_), .A3(new_n146_), .B1(\totalcoeffs[3] ), .B2(new_n142_), .Y(new_n147_));
  AO21x1_ASAP7_75t_R   g126(.A1(new_n147_), .A2(new_n27_), .B(\trailingones[1] ), .Y(new_n148_));
  AO21x1_ASAP7_75t_R   g127(.A1(new_n139_), .A2(new_n24_), .B(new_n148_), .Y(new_n149_));
  NAND2x1_ASAP7_75t_R  g128(.A(\totalcoeffs[1] ), .B(\ctable[0] ), .Y(new_n150_));
  OR4x2_ASAP7_75t_R    g129(.A(new_n25_), .B(\totalcoeffs[1] ), .C(\totalcoeffs[2] ), .D(\trailingones[0] ), .Y(new_n151_));
  AO21x1_ASAP7_75t_R   g130(.A1(new_n151_), .A2(new_n150_), .B(new_n40_), .Y(new_n152_));
  AND3x1_ASAP7_75t_R   g131(.A(\totalcoeffs[1] ), .B(\totalcoeffs[2] ), .C(\totalcoeffs[3] ), .Y(new_n153_));
  INVx1_ASAP7_75t_R    g132(.A(new_n153_), .Y(new_n154_));
  AO21x1_ASAP7_75t_R   g133(.A1(new_n154_), .A2(new_n27_), .B(new_n79_), .Y(new_n155_));
  AOI21x1_ASAP7_75t_R  g134(.A1(new_n155_), .A2(new_n152_), .B(new_n24_), .Y(new_n156_));
  AO21x1_ASAP7_75t_R   g135(.A1(new_n126_), .A2(new_n153_), .B(new_n36_), .Y(new_n157_));
  OA211x2_ASAP7_75t_R  g136(.A1(new_n156_), .A2(new_n157_), .B(new_n149_), .C(new_n22_), .Y(new_n158_));
  AO21x1_ASAP7_75t_R   g137(.A1(new_n129_), .A2(new_n25_), .B(new_n158_), .Y(new_n159_));
  INVx1_ASAP7_75t_R    g138(.A(new_n35_), .Y(new_n160_));
  INVx1_ASAP7_75t_R    g139(.A(new_n37_), .Y(new_n161_));
  INVx1_ASAP7_75t_R    g140(.A(new_n74_), .Y(new_n162_));
  OR3x1_ASAP7_75t_R    g141(.A(new_n162_), .B(\totalcoeffs[2] ), .C(new_n66_), .Y(new_n163_));
  AO221x2_ASAP7_75t_R  g142(.A1(\totalcoeffs[2] ), .A2(new_n160_), .B1(new_n145_), .B2(new_n70_), .C(\trailingones[0] ), .Y(new_n164_));
  AO21x1_ASAP7_75t_R   g143(.A1(new_n164_), .A2(new_n163_), .B(new_n23_), .Y(new_n165_));
  OAI21x1_ASAP7_75t_R  g144(.A1(new_n160_), .A2(new_n161_), .B(new_n165_), .Y(new_n166_));
  AND3x1_ASAP7_75t_R   g145(.A(new_n25_), .B(new_n27_), .C(new_n24_), .Y(new_n167_));
  AO32x1_ASAP7_75t_R   g146(.A1(new_n22_), .A2(new_n166_), .A3(new_n167_), .B1(new_n23_), .B2(new_n159_), .Y(\coeff_token[1] ));
  INVx1_ASAP7_75t_R    g147(.A(new_n80_), .Y(new_n169_));
  NOR2x1_ASAP7_75t_R   g148(.A(\trailingones[0] ), .B(\trailingones[1] ), .Y(new_n170_));
  AND2x2_ASAP7_75t_R   g149(.A(\trailingones[0] ), .B(\trailingones[1] ), .Y(new_n171_));
  NOR2x1_ASAP7_75t_R   g150(.A(new_n171_), .B(new_n170_), .Y(new_n172_));
  INVx1_ASAP7_75t_R    g151(.A(new_n172_), .Y(new_n173_));
  AO21x1_ASAP7_75t_R   g152(.A1(new_n173_), .A2(new_n169_), .B(new_n26_), .Y(new_n174_));
  NAND2x1_ASAP7_75t_R  g153(.A(\totalcoeffs[0] ), .B(\trailingones[0] ), .Y(new_n175_));
  INVx1_ASAP7_75t_R    g154(.A(new_n170_), .Y(new_n176_));
  OA211x2_ASAP7_75t_R  g155(.A1(new_n36_), .A2(new_n175_), .B(new_n176_), .C(\ctable[0] ), .Y(new_n177_));
  INVx1_ASAP7_75t_R    g156(.A(new_n75_), .Y(new_n178_));
  AO21x1_ASAP7_75t_R   g157(.A1(new_n178_), .A2(new_n27_), .B(new_n30_), .Y(new_n179_));
  OA21x2_ASAP7_75t_R   g158(.A1(new_n177_), .A2(new_n179_), .B(new_n174_), .Y(new_n180_));
  INVx1_ASAP7_75t_R    g159(.A(new_n141_), .Y(new_n181_));
  OA21x2_ASAP7_75t_R   g160(.A1(new_n25_), .A2(\totalcoeffs[1] ), .B(\ctable[0] ), .Y(new_n182_));
  OR3x1_ASAP7_75t_R    g161(.A(new_n176_), .B(\totalcoeffs[2] ), .C(new_n182_), .Y(new_n183_));
  OA21x2_ASAP7_75t_R   g162(.A1(new_n53_), .A2(new_n181_), .B(new_n183_), .Y(new_n184_));
  OAI22x1_ASAP7_75t_R  g163(.A1(new_n40_), .A2(new_n184_), .B1(new_n180_), .B2(\totalcoeffs[3] ), .Y(new_n185_));
  AO21x1_ASAP7_75t_R   g164(.A1(new_n30_), .A2(\trailingones[1] ), .B(new_n24_), .Y(new_n186_));
  AO21x1_ASAP7_75t_R   g165(.A1(new_n162_), .A2(new_n186_), .B(new_n66_), .Y(new_n187_));
  AND2x2_ASAP7_75t_R   g166(.A(\totalcoeffs[1] ), .B(\trailingones[1] ), .Y(new_n188_));
  NOR2x1_ASAP7_75t_R   g167(.A(new_n188_), .B(new_n80_), .Y(new_n189_));
  OAI21x1_ASAP7_75t_R  g168(.A1(new_n131_), .A2(new_n189_), .B(new_n187_), .Y(new_n190_));
  AO21x1_ASAP7_75t_R   g169(.A1(\totalcoeffs[2] ), .A2(new_n188_), .B(new_n141_), .Y(new_n191_));
  AND3x1_ASAP7_75t_R   g170(.A(new_n66_), .B(new_n36_), .C(\totalcoeffs[2] ), .Y(new_n192_));
  AO221x2_ASAP7_75t_R  g171(.A1(\trailingones[0] ), .A2(new_n161_), .B1(\ctable[1] ), .B2(new_n191_), .C(new_n192_), .Y(new_n193_));
  AO22x1_ASAP7_75t_R   g172(.A1(new_n190_), .A2(new_n26_), .B1(\totalcoeffs[3] ), .B2(new_n193_), .Y(new_n194_));
  AO32x1_ASAP7_75t_R   g173(.A1(\totalcoeffs[0] ), .A2(new_n194_), .A3(new_n27_), .B1(new_n24_), .B2(new_n185_), .Y(new_n195_));
  AO21x1_ASAP7_75t_R   g174(.A1(new_n26_), .A2(\trailingones[0] ), .B(new_n25_), .Y(new_n196_));
  AO21x1_ASAP7_75t_R   g175(.A1(new_n27_), .A2(\totalcoeffs[2] ), .B(new_n25_), .Y(new_n197_));
  AOI22x1_ASAP7_75t_R  g176(.A1(new_n196_), .A2(\ctable[0] ), .B1(new_n197_), .B2(\trailingones[0] ), .Y(new_n198_));
  OR3x1_ASAP7_75t_R    g177(.A(new_n24_), .B(\totalcoeffs[3] ), .C(\ctable[0] ), .Y(new_n199_));
  OAI22x1_ASAP7_75t_R  g178(.A1(new_n140_), .A2(new_n199_), .B1(new_n198_), .B2(new_n30_), .Y(new_n200_));
  AND2x2_ASAP7_75t_R   g179(.A(\totalcoeffs[1] ), .B(\trailingones[0] ), .Y(new_n201_));
  OAI21x1_ASAP7_75t_R  g180(.A1(new_n24_), .A2(new_n201_), .B(new_n36_), .Y(new_n202_));
  AO32x1_ASAP7_75t_R   g181(.A1(new_n30_), .A2(new_n66_), .A3(\trailingones[1] ), .B1(new_n26_), .B2(new_n202_), .Y(new_n203_));
  OAI21x1_ASAP7_75t_R  g182(.A1(new_n26_), .A2(new_n89_), .B(\totalcoeffs[1] ), .Y(new_n204_));
  AND3x1_ASAP7_75t_R   g183(.A(new_n204_), .B(\ctable[0] ), .C(new_n134_), .Y(new_n205_));
  AO21x1_ASAP7_75t_R   g184(.A1(\totalcoeffs[3] ), .A2(new_n66_), .B(new_n74_), .Y(new_n206_));
  OA211x2_ASAP7_75t_R  g185(.A1(new_n25_), .A2(\trailingones[1] ), .B(new_n206_), .C(new_n24_), .Y(new_n207_));
  AND2x2_ASAP7_75t_R   g186(.A(new_n66_), .B(\ctable[1] ), .Y(new_n208_));
  AND3x1_ASAP7_75t_R   g187(.A(new_n25_), .B(\totalcoeffs[1] ), .C(\trailingones[1] ), .Y(new_n209_));
  AO21x1_ASAP7_75t_R   g188(.A1(new_n209_), .A2(new_n208_), .B(\totalcoeffs[4] ), .Y(new_n210_));
  OR3x1_ASAP7_75t_R    g189(.A(new_n207_), .B(new_n205_), .C(new_n210_), .Y(new_n211_));
  AO221x2_ASAP7_75t_R  g190(.A1(\totalcoeffs[3] ), .A2(new_n203_), .B1(new_n36_), .B2(new_n200_), .C(new_n211_), .Y(new_n212_));
  AO21x1_ASAP7_75t_R   g191(.A1(\ctable[1] ), .A2(new_n66_), .B(new_n171_), .Y(new_n213_));
  OR3x1_ASAP7_75t_R    g192(.A(\totalcoeffs[1] ), .B(\totalcoeffs[2] ), .C(\totalcoeffs[3] ), .Y(new_n214_));
  AO21x1_ASAP7_75t_R   g193(.A1(new_n213_), .A2(new_n27_), .B(new_n214_), .Y(new_n215_));
  NAND2x1_ASAP7_75t_R  g194(.A(\totalcoeffs[4] ), .B(new_n215_), .Y(new_n216_));
  AO32x1_ASAP7_75t_R   g195(.A1(new_n40_), .A2(new_n212_), .A3(new_n216_), .B1(new_n22_), .B2(new_n195_), .Y(new_n217_));
  AO21x1_ASAP7_75t_R   g196(.A1(new_n171_), .A2(\ctable[2] ), .B(new_n40_), .Y(new_n218_));
  AO32x1_ASAP7_75t_R   g197(.A1(new_n30_), .A2(new_n66_), .A3(new_n45_), .B1(new_n218_), .B2(new_n42_), .Y(new_n219_));
  NOR2x1_ASAP7_75t_R   g198(.A(\ctable[0] ), .B(\ctable[1] ), .Y(new_n220_));
  AND3x1_ASAP7_75t_R   g199(.A(new_n26_), .B(new_n25_), .C(new_n22_), .Y(new_n221_));
  AO32x1_ASAP7_75t_R   g200(.A1(new_n219_), .A2(new_n220_), .A3(new_n221_), .B1(new_n23_), .B2(new_n217_), .Y(\coeff_token[2] ));
  OR3x1_ASAP7_75t_R    g201(.A(new_n27_), .B(new_n66_), .C(new_n36_), .Y(new_n223_));
  NOR2x1_ASAP7_75t_R   g202(.A(\ctable[1] ), .B(new_n223_), .Y(new_n224_));
  OA21x2_ASAP7_75t_R   g203(.A1(new_n224_), .A2(new_n120_), .B(\totalcoeffs[2] ), .Y(new_n225_));
  OA22x2_ASAP7_75t_R   g204(.A1(new_n89_), .A2(new_n27_), .B1(new_n208_), .B2(\totalcoeffs[3] ), .Y(new_n226_));
  OA21x2_ASAP7_75t_R   g205(.A1(new_n225_), .A2(new_n226_), .B(\totalcoeffs[1] ), .Y(new_n227_));
  OAI22x1_ASAP7_75t_R  g206(.A1(new_n25_), .A2(\trailingones[1] ), .B1(new_n79_), .B2(new_n24_), .Y(new_n228_));
  AO32x1_ASAP7_75t_R   g207(.A1(\totalcoeffs[2] ), .A2(new_n27_), .A3(\ctable[1] ), .B1(new_n30_), .B2(new_n228_), .Y(new_n229_));
  OAI21x1_ASAP7_75t_R  g208(.A1(new_n229_), .A2(new_n227_), .B(new_n22_), .Y(new_n230_));
  INVx1_ASAP7_75t_R    g209(.A(new_n220_), .Y(new_n231_));
  AND2x2_ASAP7_75t_R   g210(.A(new_n231_), .B(new_n96_), .Y(new_n232_));
  NOR2x1_ASAP7_75t_R   g211(.A(\ctable[0] ), .B(new_n171_), .Y(new_n233_));
  AND2x2_ASAP7_75t_R   g212(.A(new_n25_), .B(\totalcoeffs[4] ), .Y(new_n234_));
  INVx1_ASAP7_75t_R    g213(.A(new_n234_), .Y(new_n235_));
  OR5x1_ASAP7_75t_R    g214(.A(\totalcoeffs[1] ), .B(new_n232_), .C(\totalcoeffs[2] ), .D(new_n233_), .E(new_n235_), .Y(new_n236_));
  AO21x1_ASAP7_75t_R   g215(.A1(new_n230_), .A2(new_n236_), .B(\totalcoeffs[0] ), .Y(new_n237_));
  AO21x1_ASAP7_75t_R   g216(.A1(new_n107_), .A2(new_n131_), .B(new_n26_), .Y(new_n238_));
  OR3x1_ASAP7_75t_R    g217(.A(new_n27_), .B(new_n66_), .C(\totalcoeffs[2] ), .Y(new_n239_));
  AO21x1_ASAP7_75t_R   g218(.A1(new_n238_), .A2(new_n239_), .B(\trailingones[1] ), .Y(new_n240_));
  AO21x1_ASAP7_75t_R   g219(.A1(new_n104_), .A2(\ctable[0] ), .B(\totalcoeffs[3] ), .Y(new_n241_));
  AO21x1_ASAP7_75t_R   g220(.A1(new_n66_), .A2(\totalcoeffs[3] ), .B(\ctable[1] ), .Y(new_n242_));
  NAND2x1_ASAP7_75t_R  g221(.A(\totalcoeffs[3] ), .B(new_n27_), .Y(new_n243_));
  AOI22x1_ASAP7_75t_R  g222(.A1(new_n242_), .A2(new_n243_), .B1(new_n241_), .B2(new_n26_), .Y(new_n244_));
  AO21x1_ASAP7_75t_R   g223(.A1(new_n240_), .A2(new_n244_), .B(new_n30_), .Y(new_n245_));
  OR5x1_ASAP7_75t_R    g224(.A(\totalcoeffs[1] ), .B(new_n27_), .C(\totalcoeffs[2] ), .D(\ctable[1] ), .E(\trailingones[0] ), .Y(new_n246_));
  AO21x1_ASAP7_75t_R   g225(.A1(new_n246_), .A2(new_n199_), .B(\trailingones[1] ), .Y(new_n247_));
  AO21x1_ASAP7_75t_R   g226(.A1(new_n245_), .A2(new_n247_), .B(new_n40_), .Y(new_n248_));
  AND3x1_ASAP7_75t_R   g227(.A(new_n24_), .B(\totalcoeffs[2] ), .C(\totalcoeffs[3] ), .Y(new_n249_));
  INVx1_ASAP7_75t_R    g228(.A(new_n249_), .Y(new_n250_));
  OR3x1_ASAP7_75t_R    g229(.A(new_n79_), .B(\ctable[0] ), .C(new_n24_), .Y(new_n251_));
  AO21x1_ASAP7_75t_R   g230(.A1(new_n250_), .A2(new_n251_), .B(new_n36_), .Y(new_n252_));
  AND2x2_ASAP7_75t_R   g231(.A(new_n24_), .B(\totalcoeffs[3] ), .Y(new_n253_));
  AND3x1_ASAP7_75t_R   g232(.A(new_n27_), .B(new_n36_), .C(\ctable[1] ), .Y(new_n254_));
  NOR2x1_ASAP7_75t_R   g233(.A(new_n253_), .B(new_n254_), .Y(new_n255_));
  OA21x2_ASAP7_75t_R   g234(.A1(\trailingones[0] ), .A2(new_n255_), .B(new_n252_), .Y(new_n256_));
  INVx1_ASAP7_75t_R    g235(.A(new_n31_), .Y(new_n257_));
  OA21x2_ASAP7_75t_R   g236(.A1(\ctable[1] ), .A2(\trailingones[0] ), .B(new_n257_), .Y(new_n258_));
  AO21x1_ASAP7_75t_R   g237(.A1(\ctable[0] ), .A2(\trailingones[1] ), .B(\ctable[1] ), .Y(new_n259_));
  NAND2x1_ASAP7_75t_R  g238(.A(\ctable[0] ), .B(\trailingones[0] ), .Y(new_n260_));
  OA21x2_ASAP7_75t_R   g239(.A1(new_n30_), .A2(new_n36_), .B(new_n260_), .Y(new_n261_));
  OAI22x1_ASAP7_75t_R  g240(.A1(new_n259_), .A2(new_n261_), .B1(new_n258_), .B2(\totalcoeffs[2] ), .Y(new_n262_));
  AOI22x1_ASAP7_75t_R  g241(.A1(new_n201_), .A2(new_n254_), .B1(new_n262_), .B2(\totalcoeffs[3] ), .Y(new_n263_));
  OA21x2_ASAP7_75t_R   g242(.A1(\totalcoeffs[1] ), .A2(new_n256_), .B(new_n263_), .Y(new_n264_));
  AO21x1_ASAP7_75t_R   g243(.A1(new_n248_), .A2(new_n264_), .B(\totalcoeffs[4] ), .Y(new_n265_));
  AOI21x1_ASAP7_75t_R  g244(.A1(new_n237_), .A2(new_n265_), .B(\ctable[2] ), .Y(\coeff_token[3] ));
  OR3x1_ASAP7_75t_R    g245(.A(new_n35_), .B(new_n26_), .C(\totalcoeffs[4] ), .Y(new_n267_));
  AND3x1_ASAP7_75t_R   g246(.A(new_n40_), .B(new_n30_), .C(new_n26_), .Y(new_n268_));
  AND2x2_ASAP7_75t_R   g247(.A(new_n22_), .B(\totalcoeffs[3] ), .Y(new_n269_));
  OAI21x1_ASAP7_75t_R  g248(.A1(new_n234_), .A2(new_n269_), .B(new_n268_), .Y(new_n270_));
  OR3x1_ASAP7_75t_R    g249(.A(new_n27_), .B(new_n24_), .C(\ctable[2] ), .Y(new_n271_));
  AOI21x1_ASAP7_75t_R  g250(.A1(new_n267_), .A2(new_n270_), .B(new_n271_), .Y(\coeff_token[4] ));
  OR3x1_ASAP7_75t_R    g251(.A(new_n268_), .B(new_n25_), .C(\totalcoeffs[4] ), .Y(new_n273_));
  AND3x1_ASAP7_75t_R   g252(.A(new_n234_), .B(new_n26_), .C(new_n35_), .Y(new_n274_));
  INVx1_ASAP7_75t_R    g253(.A(new_n274_), .Y(new_n275_));
  AOI21x1_ASAP7_75t_R  g254(.A1(new_n273_), .A2(new_n275_), .B(new_n271_), .Y(\coeff_token[5] ));
  AO32x1_ASAP7_75t_R   g255(.A1(new_n35_), .A2(new_n79_), .A3(\totalcoeffs[4] ), .B1(\ctable[0] ), .B2(\ctable[1] ), .Y(new_n277_));
  NAND2x1_ASAP7_75t_R  g256(.A(\totalcoeffs[2] ), .B(new_n30_), .Y(new_n278_));
  OA21x2_ASAP7_75t_R   g257(.A1(new_n23_), .A2(\trailingones[1] ), .B(\trailingones[0] ), .Y(new_n279_));
  OAI22x1_ASAP7_75t_R  g258(.A1(new_n278_), .A2(new_n279_), .B1(new_n162_), .B2(\totalcoeffs[2] ), .Y(new_n280_));
  AO21x1_ASAP7_75t_R   g259(.A1(new_n116_), .A2(\totalcoeffs[1] ), .B(new_n170_), .Y(new_n281_));
  AO32x1_ASAP7_75t_R   g260(.A1(new_n26_), .A2(\ctable[2] ), .A3(new_n281_), .B1(new_n40_), .B2(new_n280_), .Y(new_n282_));
  AO21x1_ASAP7_75t_R   g261(.A1(new_n30_), .A2(new_n27_), .B(new_n26_), .Y(new_n283_));
  AO32x1_ASAP7_75t_R   g262(.A1(new_n24_), .A2(new_n283_), .A3(new_n36_), .B1(\ctable[0] ), .B2(new_n188_), .Y(new_n284_));
  AND2x2_ASAP7_75t_R   g263(.A(new_n40_), .B(\totalcoeffs[2] ), .Y(new_n285_));
  AO22x1_ASAP7_75t_R   g264(.A1(new_n284_), .A2(\totalcoeffs[0] ), .B1(new_n257_), .B2(new_n285_), .Y(new_n286_));
  AND2x2_ASAP7_75t_R   g265(.A(\totalcoeffs[2] ), .B(\trailingones[0] ), .Y(new_n287_));
  OR2x4_ASAP7_75t_R    g266(.A(new_n287_), .B(new_n115_), .Y(new_n288_));
  AO32x1_ASAP7_75t_R   g267(.A1(new_n40_), .A2(\totalcoeffs[2] ), .A3(\trailingones[1] ), .B1(new_n66_), .B2(new_n80_), .Y(new_n289_));
  AO32x1_ASAP7_75t_R   g268(.A1(\ctable[1] ), .A2(new_n173_), .A3(new_n288_), .B1(\ctable[0] ), .B2(new_n289_), .Y(new_n290_));
  AO21x1_ASAP7_75t_R   g269(.A1(\trailingones[0] ), .A2(new_n286_), .B(new_n290_), .Y(new_n291_));
  AO32x1_ASAP7_75t_R   g270(.A1(new_n27_), .A2(new_n24_), .A3(new_n282_), .B1(new_n23_), .B2(new_n291_), .Y(new_n292_));
  AO32x1_ASAP7_75t_R   g271(.A1(new_n40_), .A2(new_n140_), .A3(new_n24_), .B1(\totalcoeffs[1] ), .B2(\totalcoeffs[2] ), .Y(new_n293_));
  AO21x1_ASAP7_75t_R   g272(.A1(new_n66_), .A2(new_n36_), .B(\totalcoeffs[1] ), .Y(new_n294_));
  AO32x1_ASAP7_75t_R   g273(.A1(\totalcoeffs[0] ), .A2(new_n162_), .A3(new_n294_), .B1(new_n189_), .B2(new_n293_), .Y(new_n295_));
  OA211x2_ASAP7_75t_R  g274(.A1(\totalcoeffs[0] ), .A2(new_n26_), .B(new_n66_), .C(\totalcoeffs[1] ), .Y(new_n296_));
  AND3x1_ASAP7_75t_R   g275(.A(\totalcoeffs[0] ), .B(\ctable[1] ), .C(\trailingones[0] ), .Y(new_n297_));
  AO21x1_ASAP7_75t_R   g276(.A1(new_n26_), .A2(new_n297_), .B(new_n296_), .Y(new_n298_));
  INVx1_ASAP7_75t_R    g277(.A(new_n136_), .Y(new_n299_));
  OA211x2_ASAP7_75t_R  g278(.A1(\totalcoeffs[0] ), .A2(\trailingones[0] ), .B(new_n299_), .C(new_n74_), .Y(new_n300_));
  AO221x2_ASAP7_75t_R  g279(.A1(\trailingones[1] ), .A2(new_n298_), .B1(new_n27_), .B2(new_n295_), .C(new_n300_), .Y(new_n301_));
  AO21x1_ASAP7_75t_R   g280(.A1(new_n66_), .A2(\ctable[1] ), .B(\totalcoeffs[0] ), .Y(new_n302_));
  NOR2x1_ASAP7_75t_R   g281(.A(\totalcoeffs[2] ), .B(\trailingones[1] ), .Y(new_n303_));
  AO32x1_ASAP7_75t_R   g282(.A1(new_n260_), .A2(new_n302_), .A3(new_n303_), .B1(new_n287_), .B2(new_n41_), .Y(new_n304_));
  AND2x2_ASAP7_75t_R   g283(.A(new_n304_), .B(new_n30_), .Y(new_n305_));
  AO21x1_ASAP7_75t_R   g284(.A1(new_n27_), .A2(\totalcoeffs[2] ), .B(\ctable[1] ), .Y(new_n306_));
  AO32x1_ASAP7_75t_R   g285(.A1(new_n26_), .A2(new_n63_), .A3(\ctable[0] ), .B1(new_n41_), .B2(new_n306_), .Y(new_n307_));
  AO21x1_ASAP7_75t_R   g286(.A1(new_n176_), .A2(\totalcoeffs[2] ), .B(new_n116_), .Y(new_n308_));
  AO22x1_ASAP7_75t_R   g287(.A1(new_n307_), .A2(new_n66_), .B1(\ctable[1] ), .B2(new_n308_), .Y(new_n309_));
  AO221x2_ASAP7_75t_R  g288(.A1(\totalcoeffs[1] ), .A2(new_n309_), .B1(\totalcoeffs[3] ), .B2(new_n301_), .C(new_n305_), .Y(new_n310_));
  AO22x1_ASAP7_75t_R   g289(.A1(new_n310_), .A2(new_n23_), .B1(new_n25_), .B2(new_n292_), .Y(new_n311_));
  AOI22x1_ASAP7_75t_R  g290(.A1(new_n23_), .A2(new_n277_), .B1(new_n311_), .B2(new_n22_), .Y(\ctoken_len[0] ));
  AO21x1_ASAP7_75t_R   g291(.A1(\trailingones[0] ), .A2(\trailingones[1] ), .B(new_n25_), .Y(new_n313_));
  AO21x1_ASAP7_75t_R   g292(.A1(new_n313_), .A2(new_n175_), .B(\ctable[1] ), .Y(new_n314_));
  OR3x1_ASAP7_75t_R    g293(.A(new_n66_), .B(new_n36_), .C(\totalcoeffs[3] ), .Y(new_n315_));
  AOI21x1_ASAP7_75t_R  g294(.A1(new_n315_), .A2(new_n314_), .B(new_n26_), .Y(new_n316_));
  AO21x1_ASAP7_75t_R   g295(.A1(new_n143_), .A2(new_n253_), .B(new_n208_), .Y(new_n317_));
  NOR2x1_ASAP7_75t_R   g296(.A(new_n40_), .B(new_n253_), .Y(new_n318_));
  OA22x2_ASAP7_75t_R   g297(.A1(\trailingones[0] ), .A2(new_n108_), .B1(new_n318_), .B2(new_n94_), .Y(new_n319_));
  AO21x1_ASAP7_75t_R   g298(.A1(new_n317_), .A2(\trailingones[1] ), .B(new_n319_), .Y(new_n320_));
  AO221x2_ASAP7_75t_R  g299(.A1(new_n92_), .A2(new_n130_), .B1(new_n26_), .B2(new_n320_), .C(new_n316_), .Y(new_n321_));
  NOR2x1_ASAP7_75t_R   g300(.A(\ctable[1] ), .B(new_n171_), .Y(new_n322_));
  AO32x1_ASAP7_75t_R   g301(.A1(new_n40_), .A2(new_n173_), .A3(\ctable[1] ), .B1(new_n322_), .B2(new_n70_), .Y(new_n323_));
  AO21x1_ASAP7_75t_R   g302(.A1(new_n40_), .A2(new_n115_), .B(new_n297_), .Y(new_n324_));
  OA211x2_ASAP7_75t_R  g303(.A1(\ctable[1] ), .A2(new_n130_), .B(new_n176_), .C(\totalcoeffs[2] ), .Y(new_n325_));
  AO221x2_ASAP7_75t_R  g304(.A1(new_n36_), .A2(new_n324_), .B1(\totalcoeffs[3] ), .B2(new_n323_), .C(new_n325_), .Y(new_n326_));
  AND3x1_ASAP7_75t_R   g305(.A(new_n94_), .B(\totalcoeffs[3] ), .C(new_n115_), .Y(new_n327_));
  AO21x1_ASAP7_75t_R   g306(.A1(new_n326_), .A2(new_n30_), .B(new_n327_), .Y(new_n328_));
  AO21x1_ASAP7_75t_R   g307(.A1(\totalcoeffs[1] ), .A2(new_n321_), .B(new_n328_), .Y(new_n329_));
  INVx1_ASAP7_75t_R    g308(.A(new_n303_), .Y(new_n330_));
  AO32x1_ASAP7_75t_R   g309(.A1(\totalcoeffs[0] ), .A2(new_n330_), .A3(new_n178_), .B1(new_n36_), .B2(new_n102_), .Y(new_n331_));
  AO32x1_ASAP7_75t_R   g310(.A1(\totalcoeffs[2] ), .A2(\trailingones[1] ), .A3(new_n126_), .B1(\trailingones[0] ), .B2(new_n331_), .Y(new_n332_));
  AND2x2_ASAP7_75t_R   g311(.A(\totalcoeffs[3] ), .B(\ctable[0] ), .Y(new_n333_));
  AO21x1_ASAP7_75t_R   g312(.A1(\totalcoeffs[2] ), .A2(new_n36_), .B(new_n333_), .Y(new_n334_));
  AO32x1_ASAP7_75t_R   g313(.A1(new_n26_), .A2(\totalcoeffs[3] ), .A3(\ctable[0] ), .B1(new_n40_), .B2(new_n334_), .Y(new_n335_));
  AO32x1_ASAP7_75t_R   g314(.A1(new_n26_), .A2(new_n36_), .A3(new_n333_), .B1(new_n66_), .B2(new_n335_), .Y(new_n336_));
  AO21x1_ASAP7_75t_R   g315(.A1(new_n25_), .A2(new_n332_), .B(new_n336_), .Y(new_n337_));
  AO21x1_ASAP7_75t_R   g316(.A1(\totalcoeffs[2] ), .A2(\totalcoeffs[3] ), .B(new_n173_), .Y(new_n338_));
  AO21x1_ASAP7_75t_R   g317(.A1(\totalcoeffs[0] ), .A2(\totalcoeffs[3] ), .B(\totalcoeffs[2] ), .Y(new_n339_));
  AO32x1_ASAP7_75t_R   g318(.A1(\ctable[0] ), .A2(new_n338_), .A3(new_n339_), .B1(new_n54_), .B2(new_n192_), .Y(new_n340_));
  AND5x1_ASAP7_75t_R   g319(.A(\totalcoeffs[2] ), .B(\totalcoeffs[3] ), .C(\ctable[0] ), .D(\trailingones[0] ), .E(\trailingones[1] ), .Y(new_n341_));
  AO21x1_ASAP7_75t_R   g320(.A1(new_n340_), .A2(new_n30_), .B(new_n341_), .Y(new_n342_));
  AO21x1_ASAP7_75t_R   g321(.A1(\totalcoeffs[1] ), .A2(new_n337_), .B(new_n342_), .Y(new_n343_));
  AO22x1_ASAP7_75t_R   g322(.A1(new_n329_), .A2(new_n27_), .B1(new_n24_), .B2(new_n343_), .Y(new_n344_));
  AND5x1_ASAP7_75t_R   g323(.A(\totalcoeffs[0] ), .B(new_n26_), .C(new_n36_), .D(\ctable[2] ), .E(\trailingones[0] ), .Y(new_n345_));
  AO21x1_ASAP7_75t_R   g324(.A1(new_n172_), .A2(new_n285_), .B(new_n345_), .Y(new_n346_));
  AO32x1_ASAP7_75t_R   g325(.A1(new_n98_), .A2(new_n220_), .A3(new_n346_), .B1(new_n23_), .B2(new_n344_), .Y(new_n347_));
  AND3x1_ASAP7_75t_R   g326(.A(new_n274_), .B(new_n27_), .C(new_n23_), .Y(new_n348_));
  AOI22x1_ASAP7_75t_R  g327(.A1(new_n24_), .A2(new_n348_), .B1(new_n347_), .B2(new_n22_), .Y(\ctoken_len[1] ));
  AND2x2_ASAP7_75t_R   g328(.A(new_n243_), .B(new_n150_), .Y(new_n350_));
  OA211x2_ASAP7_75t_R  g329(.A1(\totalcoeffs[3] ), .A2(new_n36_), .B(new_n169_), .C(new_n26_), .Y(new_n351_));
  AND2x2_ASAP7_75t_R   g330(.A(new_n26_), .B(\ctable[0] ), .Y(new_n352_));
  AO21x1_ASAP7_75t_R   g331(.A1(new_n80_), .A2(new_n352_), .B(new_n209_), .Y(new_n353_));
  AND2x2_ASAP7_75t_R   g332(.A(new_n25_), .B(\totalcoeffs[2] ), .Y(new_n354_));
  INVx1_ASAP7_75t_R    g333(.A(new_n354_), .Y(new_n355_));
  NAND2x1_ASAP7_75t_R  g334(.A(new_n30_), .B(new_n27_), .Y(new_n356_));
  AOI21x1_ASAP7_75t_R  g335(.A1(new_n189_), .A2(new_n356_), .B(new_n355_), .Y(new_n357_));
  AO221x2_ASAP7_75t_R  g336(.A1(new_n40_), .A2(new_n353_), .B1(new_n350_), .B2(new_n351_), .C(new_n357_), .Y(new_n358_));
  INVx1_ASAP7_75t_R    g337(.A(new_n333_), .Y(new_n359_));
  NAND2x1_ASAP7_75t_R  g338(.A(new_n40_), .B(new_n25_), .Y(new_n360_));
  AO32x1_ASAP7_75t_R   g339(.A1(new_n26_), .A2(new_n350_), .A3(new_n360_), .B1(new_n98_), .B2(new_n136_), .Y(new_n361_));
  AO21x1_ASAP7_75t_R   g340(.A1(new_n40_), .A2(\trailingones[0] ), .B(\ctable[0] ), .Y(new_n362_));
  AO32x1_ASAP7_75t_R   g341(.A1(new_n50_), .A2(new_n359_), .A3(new_n362_), .B1(\trailingones[0] ), .B2(new_n361_), .Y(new_n363_));
  AO21x1_ASAP7_75t_R   g342(.A1(\totalcoeffs[2] ), .A2(new_n27_), .B(new_n333_), .Y(new_n364_));
  AND3x1_ASAP7_75t_R   g343(.A(new_n364_), .B(\totalcoeffs[1] ), .C(new_n196_), .Y(new_n365_));
  AND5x1_ASAP7_75t_R   g344(.A(new_n30_), .B(new_n103_), .C(new_n26_), .D(\totalcoeffs[3] ), .E(\trailingones[0] ), .Y(new_n366_));
  OA21x2_ASAP7_75t_R   g345(.A1(new_n366_), .A2(new_n365_), .B(\trailingones[1] ), .Y(new_n367_));
  AO221x2_ASAP7_75t_R  g346(.A1(new_n66_), .A2(new_n358_), .B1(new_n36_), .B2(new_n363_), .C(new_n367_), .Y(new_n368_));
  AO21x1_ASAP7_75t_R   g347(.A1(new_n66_), .A2(\totalcoeffs[1] ), .B(\ctable[1] ), .Y(new_n369_));
  AO21x1_ASAP7_75t_R   g348(.A1(new_n294_), .A2(\totalcoeffs[0] ), .B(new_n369_), .Y(new_n370_));
  AO21x1_ASAP7_75t_R   g349(.A1(new_n162_), .A2(new_n143_), .B(new_n186_), .Y(new_n371_));
  AOI21x1_ASAP7_75t_R  g350(.A1(new_n26_), .A2(new_n371_), .B(new_n243_), .Y(new_n372_));
  AO22x1_ASAP7_75t_R   g351(.A1(new_n368_), .A2(new_n24_), .B1(new_n370_), .B2(new_n372_), .Y(new_n373_));
  AO21x1_ASAP7_75t_R   g352(.A1(new_n288_), .A2(new_n40_), .B(new_n135_), .Y(new_n374_));
  AND3x1_ASAP7_75t_R   g353(.A(new_n285_), .B(new_n66_), .C(\trailingones[1] ), .Y(new_n375_));
  AO21x1_ASAP7_75t_R   g354(.A1(new_n374_), .A2(new_n36_), .B(new_n375_), .Y(new_n376_));
  AND3x1_ASAP7_75t_R   g355(.A(new_n115_), .B(new_n40_), .C(new_n188_), .Y(new_n377_));
  AO21x1_ASAP7_75t_R   g356(.A1(new_n376_), .A2(new_n30_), .B(new_n377_), .Y(new_n378_));
  AO22x1_ASAP7_75t_R   g357(.A1(new_n373_), .A2(new_n23_), .B1(new_n167_), .B2(new_n378_), .Y(new_n379_));
  AOI21x1_ASAP7_75t_R  g358(.A1(new_n22_), .A2(new_n379_), .B(new_n348_), .Y(\ctoken_len[2] ));
  INVx1_ASAP7_75t_R    g359(.A(new_n233_), .Y(new_n381_));
  AO21x1_ASAP7_75t_R   g360(.A1(\ctable[1] ), .A2(\trailingones[1] ), .B(new_n25_), .Y(new_n382_));
  AO21x1_ASAP7_75t_R   g361(.A1(new_n143_), .A2(new_n259_), .B(new_n382_), .Y(new_n383_));
  OA21x2_ASAP7_75t_R   g362(.A1(new_n235_), .A2(new_n220_), .B(new_n26_), .Y(new_n384_));
  AO32x1_ASAP7_75t_R   g363(.A1(new_n354_), .A2(new_n176_), .A3(new_n381_), .B1(new_n383_), .B2(new_n384_), .Y(new_n385_));
  NAND2x1_ASAP7_75t_R  g364(.A(new_n30_), .B(new_n385_), .Y(new_n386_));
  AO32x1_ASAP7_75t_R   g365(.A1(new_n40_), .A2(\trailingones[0] ), .A3(new_n382_), .B1(new_n25_), .B2(new_n257_), .Y(new_n387_));
  NAND2x1_ASAP7_75t_R  g366(.A(new_n26_), .B(new_n387_), .Y(new_n388_));
  AO21x1_ASAP7_75t_R   g367(.A1(new_n223_), .A2(new_n24_), .B(\totalcoeffs[3] ), .Y(new_n389_));
  OA21x2_ASAP7_75t_R   g368(.A1(new_n381_), .A2(new_n250_), .B(new_n389_), .Y(new_n390_));
  AO21x1_ASAP7_75t_R   g369(.A1(new_n388_), .A2(new_n390_), .B(new_n30_), .Y(new_n391_));
  AO21x1_ASAP7_75t_R   g370(.A1(new_n249_), .A2(new_n136_), .B(\ctable[2] ), .Y(new_n392_));
  NAND2x1_ASAP7_75t_R  g371(.A(new_n294_), .B(new_n392_), .Y(new_n393_));
  AO21x1_ASAP7_75t_R   g372(.A1(new_n214_), .A2(new_n23_), .B(new_n40_), .Y(new_n394_));
  OA21x2_ASAP7_75t_R   g373(.A1(new_n354_), .A2(\ctable[0] ), .B(\ctable[1] ), .Y(new_n395_));
  AOI221x1_ASAP7_75t_R g374(.A1(\totalcoeffs[4] ), .A2(new_n214_), .B1(\ctable[2] ), .B2(new_n355_), .C(new_n395_), .Y(new_n396_));
  AND5x1_ASAP7_75t_R   g375(.A(new_n386_), .B(new_n391_), .C(new_n393_), .D(new_n394_), .E(new_n396_), .Y(\ctoken_len[3] ));
  OA211x2_ASAP7_75t_R  g376(.A1(\totalcoeffs[1] ), .A2(new_n45_), .B(new_n269_), .C(\totalcoeffs[2] ), .Y(new_n398_));
  OA21x2_ASAP7_75t_R   g377(.A1(new_n66_), .A2(new_n42_), .B(new_n398_), .Y(new_n399_));
  OA211x2_ASAP7_75t_R  g378(.A1(new_n399_), .A2(new_n274_), .B(new_n23_), .C(new_n220_), .Y(\ctoken_len[4] ));
endmodule


