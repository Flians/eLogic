// Benchmark "/tmp/" written by ABC on Tue Oct 20 17:23:05 2026

module \/tmp/  ( 
    p2, p4, p5, p3, p6, p1, p0,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25  );
  input  p2, p4, p5, p3, p6, p1, p0;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25;
  wire new_n34_, new_n35_, new_n36_, new_n37_, new_n38_, new_n39_, new_n41_,
    new_n42_, new_n43_, new_n44_, new_n45_, new_n46_, new_n47_, new_n49_,
    new_n50_, new_n51_, new_n52_, new_n53_, new_n55_, new_n56_, new_n58_,
    new_n59_, new_n60_, new_n61_, new_n62_, new_n63_, new_n64_, new_n66_,
    new_n67_, new_n68_, new_n70_, new_n71_, new_n72_, new_n74_, new_n75_,
    new_n76_, new_n78_, new_n81_, new_n82_, new_n85_, new_n86_, new_n87_,
    new_n88_, new_n93_, new_n98_, new_n99_, new_n100_, new_n101_,
    new_n103_, new_n104_, new_n105_, new_n107_, new_n108_, new_n109_,
    new_n112_;
  INVx1_ASAP7_75t_R    g00(.A(p1), .Y(new_n34_));
  INVx1_ASAP7_75t_R    g01(.A(p0), .Y(new_n35_));
  OR4x2_ASAP7_75t_R    g02(.A(new_n34_), .B(new_n35_), .C(p2), .D(p3), .Y(new_n36_));
  NAND2x1_ASAP7_75t_R  g03(.A(p2), .B(p3), .Y(new_n37_));
  INVx1_ASAP7_75t_R    g04(.A(p6), .Y(new_n38_));
  NOR2x1_ASAP7_75t_R   g05(.A(p1), .B(p0), .Y(new_n39_));
  AOI22x1_ASAP7_75t_R  g06(.A1(new_n36_), .A2(new_n37_), .B1(new_n38_), .B2(new_n39_), .Y(o0));
  INVx1_ASAP7_75t_R    g07(.A(p3), .Y(new_n41_));
  NOR2x1_ASAP7_75t_R   g08(.A(p2), .B(new_n41_), .Y(new_n42_));
  INVx1_ASAP7_75t_R    g09(.A(new_n42_), .Y(new_n43_));
  NOR2x1_ASAP7_75t_R   g10(.A(p1), .B(new_n35_), .Y(new_n44_));
  AND2x2_ASAP7_75t_R   g11(.A(p2), .B(p3), .Y(new_n45_));
  NOR2x1_ASAP7_75t_R   g12(.A(p2), .B(p3), .Y(new_n46_));
  OAI22x1_ASAP7_75t_R  g13(.A1(new_n45_), .A2(p0), .B1(new_n34_), .B2(new_n46_), .Y(new_n47_));
  AOI221x1_ASAP7_75t_R g14(.A1(p6), .A2(new_n39_), .B1(new_n43_), .B2(new_n44_), .C(new_n47_), .Y(o1));
  INVx1_ASAP7_75t_R    g15(.A(new_n44_), .Y(new_n49_));
  OR3x1_ASAP7_75t_R    g16(.A(new_n37_), .B(p6), .C(p1), .Y(new_n50_));
  OR3x1_ASAP7_75t_R    g17(.A(new_n41_), .B(p2), .C(p6), .Y(new_n51_));
  INVx1_ASAP7_75t_R    g18(.A(p2), .Y(new_n52_));
  OA21x2_ASAP7_75t_R   g19(.A1(p3), .A2(new_n52_), .B(p0), .Y(new_n53_));
  AOI22x1_ASAP7_75t_R  g20(.A1(new_n49_), .A2(new_n50_), .B1(new_n51_), .B2(new_n53_), .Y(o2));
  NAND2x1_ASAP7_75t_R  g21(.A(p3), .B(p6), .Y(new_n55_));
  AND3x1_ASAP7_75t_R   g22(.A(new_n34_), .B(new_n35_), .C(p2), .Y(new_n56_));
  AO21x1_ASAP7_75t_R   g23(.A1(new_n55_), .A2(new_n56_), .B(new_n42_), .Y(o3));
  AND2x2_ASAP7_75t_R   g24(.A(p4), .B(p5), .Y(new_n58_));
  AND3x1_ASAP7_75t_R   g25(.A(p2), .B(p6), .C(p0), .Y(new_n59_));
  OAI21x1_ASAP7_75t_R  g26(.A1(new_n41_), .A2(new_n58_), .B(new_n59_), .Y(new_n60_));
  AND3x1_ASAP7_75t_R   g27(.A(p2), .B(p4), .C(p3), .Y(new_n61_));
  NOR2x1_ASAP7_75t_R   g28(.A(p6), .B(new_n35_), .Y(new_n62_));
  AOI21x1_ASAP7_75t_R  g29(.A1(new_n61_), .A2(new_n62_), .B(p1), .Y(new_n63_));
  OA21x2_ASAP7_75t_R   g30(.A1(p2), .A2(new_n55_), .B(p1), .Y(new_n64_));
  AOI21x1_ASAP7_75t_R  g31(.A1(new_n60_), .A2(new_n63_), .B(new_n64_), .Y(o4));
  NAND2x1_ASAP7_75t_R  g32(.A(p2), .B(new_n41_), .Y(new_n66_));
  AOI21x1_ASAP7_75t_R  g33(.A1(p2), .A2(p5), .B(p1), .Y(new_n67_));
  NOR2x1_ASAP7_75t_R   g34(.A(new_n34_), .B(new_n42_), .Y(new_n68_));
  AOI211x1_ASAP7_75t_R g35(.A1(new_n66_), .A2(new_n67_), .B(new_n35_), .C(new_n68_), .Y(o5));
  NAND2x1_ASAP7_75t_R  g36(.A(p6), .B(p0), .Y(new_n70_));
  AO21x1_ASAP7_75t_R   g37(.A1(new_n34_), .A2(new_n70_), .B(new_n37_), .Y(new_n71_));
  OR3x1_ASAP7_75t_R    g38(.A(new_n45_), .B(p1), .C(new_n46_), .Y(new_n72_));
  NAND2x1_ASAP7_75t_R  g39(.A(new_n71_), .B(new_n72_), .Y(o6));
  NAND2x1_ASAP7_75t_R  g40(.A(p6), .B(p1), .Y(new_n74_));
  OR3x1_ASAP7_75t_R    g41(.A(p6), .B(p1), .C(p0), .Y(new_n75_));
  AO21x1_ASAP7_75t_R   g42(.A1(new_n74_), .A2(new_n75_), .B(new_n37_), .Y(new_n76_));
  NAND2x1_ASAP7_75t_R  g43(.A(new_n36_), .B(new_n76_), .Y(o7));
  NOR2x1_ASAP7_75t_R   g44(.A(new_n34_), .B(new_n46_), .Y(new_n78_));
  AOI221x1_ASAP7_75t_R g45(.A1(new_n37_), .A2(new_n78_), .B1(new_n51_), .B2(new_n44_), .C(new_n35_), .Y(o8));
  AOI21x1_ASAP7_75t_R  g46(.A1(new_n44_), .A2(new_n51_), .B(new_n47_), .Y(o9));
  NOR2x1_ASAP7_75t_R   g47(.A(p2), .B(p1), .Y(new_n81_));
  AO21x1_ASAP7_75t_R   g48(.A1(p3), .A2(new_n39_), .B(new_n81_), .Y(new_n82_));
  OAI22x1_ASAP7_75t_R  g49(.A1(new_n68_), .A2(new_n82_), .B1(new_n43_), .B2(new_n62_), .Y(o10));
  AND3x1_ASAP7_75t_R   g50(.A(new_n39_), .B(new_n46_), .C(new_n38_), .Y(o11));
  NOR2x1_ASAP7_75t_R   g51(.A(p3), .B(p0), .Y(new_n85_));
  INVx1_ASAP7_75t_R    g52(.A(new_n85_), .Y(new_n86_));
  NOR2x1_ASAP7_75t_R   g53(.A(p1), .B(new_n46_), .Y(new_n87_));
  OR3x1_ASAP7_75t_R    g54(.A(p2), .B(p6), .C(p0), .Y(new_n88_));
  AO32x1_ASAP7_75t_R   g55(.A1(p1), .A2(new_n66_), .A3(new_n86_), .B1(new_n87_), .B2(new_n88_), .Y(o12));
  AND3x1_ASAP7_75t_R   g56(.A(new_n46_), .B(p6), .C(p1), .Y(o13));
  AND3x1_ASAP7_75t_R   g57(.A(new_n46_), .B(new_n38_), .C(p1), .Y(o14));
  AND5x1_ASAP7_75t_R   g58(.A(p2), .B(new_n41_), .C(new_n38_), .D(new_n35_), .E(p1), .Y(o15));
  NAND2x1_ASAP7_75t_R  g59(.A(p2), .B(new_n85_), .Y(new_n93_));
  NOR2x1_ASAP7_75t_R   g60(.A(new_n74_), .B(new_n93_), .Y(o16));
  AND5x1_ASAP7_75t_R   g61(.A(new_n41_), .B(p2), .C(p6), .D(p1), .E(p0), .Y(o17));
  AND5x1_ASAP7_75t_R   g62(.A(p2), .B(new_n41_), .C(new_n38_), .D(p1), .E(p0), .Y(o18));
  AND3x1_ASAP7_75t_R   g63(.A(new_n52_), .B(new_n41_), .C(p1), .Y(o19));
  OAI21x1_ASAP7_75t_R  g64(.A1(p4), .A2(new_n41_), .B(new_n59_), .Y(new_n98_));
  AND2x2_ASAP7_75t_R   g65(.A(p2), .B(p6), .Y(new_n99_));
  AOI21x1_ASAP7_75t_R  g66(.A1(new_n85_), .A2(new_n99_), .B(p1), .Y(new_n100_));
  AOI21x1_ASAP7_75t_R  g67(.A1(new_n70_), .A2(new_n45_), .B(new_n34_), .Y(new_n101_));
  AOI21x1_ASAP7_75t_R  g68(.A1(new_n98_), .A2(new_n100_), .B(new_n101_), .Y(o20));
  INVx1_ASAP7_75t_R    g69(.A(p4), .Y(new_n103_));
  OR4x2_ASAP7_75t_R    g70(.A(new_n37_), .B(new_n103_), .C(p5), .D(new_n35_), .Y(new_n104_));
  NAND2x1_ASAP7_75t_R  g71(.A(p6), .B(new_n34_), .Y(new_n105_));
  AOI21x1_ASAP7_75t_R  g72(.A1(new_n93_), .A2(new_n104_), .B(new_n105_), .Y(o21));
  NAND2x1_ASAP7_75t_R  g73(.A(p5), .B(p3), .Y(new_n107_));
  AND2x2_ASAP7_75t_R   g74(.A(p6), .B(p0), .Y(new_n108_));
  OAI21x1_ASAP7_75t_R  g75(.A1(p4), .A2(new_n107_), .B(new_n108_), .Y(new_n109_));
  AOI221x1_ASAP7_75t_R g76(.A1(new_n66_), .A2(new_n67_), .B1(new_n109_), .B2(new_n34_), .C(new_n101_), .Y(o22));
  assign               o23 = 1'b1;
  NOR2x1_ASAP7_75t_R   g77(.A(p6), .B(p0), .Y(new_n112_));
  OA211x2_ASAP7_75t_R  g78(.A1(new_n112_), .A2(new_n108_), .B(p3), .C(new_n81_), .Y(o24));
  AND3x1_ASAP7_75t_R   g79(.A(new_n42_), .B(p6), .C(new_n39_), .Y(o25));
endmodule


