// Benchmark "/tmp/" written by ABC on Tue Oct 20 17:23:04 2026

module \/tmp/  ( 
    p2, p3, p0, p6, p1, p4, p5,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25  );
  input  p2, p3, p0, p6, p1, p4, p5;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25;
  wire new_n34_, new_n35_, new_n36_, new_n39_, new_n40_, new_n41_, new_n42_,
    new_n43_, new_n44_, new_n45_, new_n46_, new_n48_, new_n49_, new_n51_,
    new_n52_, new_n53_, new_n55_, new_n56_, new_n57_, new_n58_, new_n59_,
    new_n60_, new_n61_, new_n62_, new_n63_, new_n64_, new_n66_, new_n67_,
    new_n69_, new_n70_, new_n71_, new_n72_, new_n74_, new_n75_, new_n76_,
    new_n78_, new_n81_, new_n82_, new_n83_, new_n86_, new_n87_, new_n91_,
    new_n92_, new_n94_, new_n98_, new_n99_, new_n100_, new_n102_,
    new_n103_;
  OR3x1_ASAP7_75t_R    g00(.A(p0), .B(p6), .C(p1), .Y(new_n34_));
  INVx1_ASAP7_75t_R    g01(.A(p2), .Y(new_n35_));
  INVx1_ASAP7_75t_R    g02(.A(p3), .Y(new_n36_));
  AND3x1_ASAP7_75t_R   g03(.A(new_n35_), .B(new_n36_), .C(p1), .Y(o19));
  AO32x1_ASAP7_75t_R   g04(.A1(p2), .A2(p3), .A3(new_n34_), .B1(o19), .B2(p0), .Y(o0));
  NAND2x1_ASAP7_75t_R  g05(.A(p3), .B(new_n35_), .Y(new_n39_));
  INVx1_ASAP7_75t_R    g06(.A(p0), .Y(new_n40_));
  NOR2x1_ASAP7_75t_R   g07(.A(p1), .B(new_n40_), .Y(new_n41_));
  OR3x1_ASAP7_75t_R    g08(.A(new_n35_), .B(new_n36_), .C(p6), .Y(new_n42_));
  NOR2x1_ASAP7_75t_R   g09(.A(p0), .B(p1), .Y(new_n43_));
  NOR2x1_ASAP7_75t_R   g10(.A(p2), .B(p3), .Y(new_n44_));
  INVx1_ASAP7_75t_R    g11(.A(p1), .Y(new_n45_));
  AOI21x1_ASAP7_75t_R  g12(.A1(p0), .A2(new_n44_), .B(new_n45_), .Y(new_n46_));
  AOI221x1_ASAP7_75t_R g13(.A1(new_n39_), .A2(new_n41_), .B1(new_n42_), .B2(new_n43_), .C(new_n46_), .Y(o1));
  OA21x2_ASAP7_75t_R   g14(.A1(p3), .A2(new_n35_), .B(p0), .Y(new_n48_));
  OR3x1_ASAP7_75t_R    g15(.A(new_n36_), .B(p2), .C(p6), .Y(new_n49_));
  AOI221x1_ASAP7_75t_R g16(.A1(new_n48_), .A2(new_n49_), .B1(new_n40_), .B2(new_n42_), .C(p1), .Y(o2));
  INVx1_ASAP7_75t_R    g17(.A(p6), .Y(new_n51_));
  NAND2x1_ASAP7_75t_R  g18(.A(p2), .B(p3), .Y(new_n52_));
  INVx1_ASAP7_75t_R    g19(.A(new_n44_), .Y(new_n53_));
  OA221x2_ASAP7_75t_R  g20(.A1(new_n35_), .A2(new_n43_), .B1(new_n51_), .B2(new_n52_), .C(new_n53_), .Y(o3));
  NAND2x1_ASAP7_75t_R  g21(.A(p0), .B(p4), .Y(new_n55_));
  OA31x2_ASAP7_75t_R   g22(.A1(p6), .A2(new_n52_), .A3(new_n55_), .B1(new_n45_), .Y(new_n56_));
  INVx1_ASAP7_75t_R    g23(.A(p5), .Y(new_n57_));
  NAND2x1_ASAP7_75t_R  g24(.A(p3), .B(new_n57_), .Y(new_n58_));
  INVx1_ASAP7_75t_R    g25(.A(p4), .Y(new_n59_));
  NAND2x1_ASAP7_75t_R  g26(.A(p3), .B(new_n59_), .Y(new_n60_));
  AND3x1_ASAP7_75t_R   g27(.A(p2), .B(p0), .C(p6), .Y(new_n61_));
  NAND3x1_ASAP7_75t_R  g28(.A(new_n58_), .B(new_n60_), .C(new_n61_), .Y(new_n62_));
  NAND2x1_ASAP7_75t_R  g29(.A(p3), .B(p6), .Y(new_n63_));
  OA21x2_ASAP7_75t_R   g30(.A1(p2), .A2(new_n63_), .B(p1), .Y(new_n64_));
  AOI21x1_ASAP7_75t_R  g31(.A1(new_n56_), .A2(new_n62_), .B(new_n64_), .Y(o4));
  AO21x1_ASAP7_75t_R   g32(.A1(p3), .A2(new_n57_), .B(new_n35_), .Y(new_n66_));
  OA21x2_ASAP7_75t_R   g33(.A1(p2), .A2(new_n36_), .B(p1), .Y(new_n67_));
  AOI211x1_ASAP7_75t_R g34(.A1(new_n45_), .A2(new_n66_), .B(new_n40_), .C(new_n67_), .Y(o5));
  AND2x2_ASAP7_75t_R   g35(.A(p0), .B(p6), .Y(new_n69_));
  NOR2x1_ASAP7_75t_R   g36(.A(p1), .B(new_n69_), .Y(new_n70_));
  NOR2x1_ASAP7_75t_R   g37(.A(p1), .B(new_n44_), .Y(new_n71_));
  NAND2x1_ASAP7_75t_R  g38(.A(new_n52_), .B(new_n71_), .Y(new_n72_));
  OAI21x1_ASAP7_75t_R  g39(.A1(new_n52_), .A2(new_n70_), .B(new_n72_), .Y(o6));
  NAND2x1_ASAP7_75t_R  g40(.A(p6), .B(p1), .Y(new_n74_));
  AO21x1_ASAP7_75t_R   g41(.A1(new_n74_), .A2(new_n34_), .B(new_n52_), .Y(new_n75_));
  NAND2x1_ASAP7_75t_R  g42(.A(p0), .B(o19), .Y(new_n76_));
  NAND2x1_ASAP7_75t_R  g43(.A(new_n75_), .B(new_n76_), .Y(o7));
  NOR2x1_ASAP7_75t_R   g44(.A(new_n45_), .B(new_n44_), .Y(new_n78_));
  AOI221x1_ASAP7_75t_R g45(.A1(new_n52_), .A2(new_n78_), .B1(new_n49_), .B2(new_n45_), .C(new_n40_), .Y(o8));
  AOI221x1_ASAP7_75t_R g46(.A1(new_n40_), .A2(new_n52_), .B1(new_n49_), .B2(new_n41_), .C(new_n46_), .Y(o9));
  NOR2x1_ASAP7_75t_R   g47(.A(p2), .B(p1), .Y(new_n81_));
  AO21x1_ASAP7_75t_R   g48(.A1(p3), .A2(new_n43_), .B(new_n81_), .Y(new_n82_));
  AO21x1_ASAP7_75t_R   g49(.A1(p0), .A2(new_n51_), .B(new_n39_), .Y(new_n83_));
  OAI21x1_ASAP7_75t_R  g50(.A1(new_n67_), .A2(new_n82_), .B(new_n83_), .Y(o10));
  AND3x1_ASAP7_75t_R   g51(.A(new_n44_), .B(new_n43_), .C(new_n51_), .Y(o11));
  OR3x1_ASAP7_75t_R    g52(.A(p2), .B(p0), .C(p6), .Y(new_n86_));
  AND3x1_ASAP7_75t_R   g53(.A(new_n35_), .B(p0), .C(p1), .Y(new_n87_));
  AO221x2_ASAP7_75t_R  g54(.A1(p3), .A2(p1), .B1(new_n71_), .B2(new_n86_), .C(new_n87_), .Y(o12));
  AND3x1_ASAP7_75t_R   g55(.A(new_n44_), .B(p6), .C(p1), .Y(o13));
  AND3x1_ASAP7_75t_R   g56(.A(new_n44_), .B(new_n51_), .C(p1), .Y(o14));
  NOR2x1_ASAP7_75t_R   g57(.A(p3), .B(new_n35_), .Y(new_n91_));
  NOR2x1_ASAP7_75t_R   g58(.A(p0), .B(p6), .Y(new_n92_));
  AND3x1_ASAP7_75t_R   g59(.A(new_n91_), .B(p1), .C(new_n92_), .Y(o15));
  NOR2x1_ASAP7_75t_R   g60(.A(p0), .B(new_n51_), .Y(new_n94_));
  AND3x1_ASAP7_75t_R   g61(.A(new_n91_), .B(new_n94_), .C(p1), .Y(o16));
  AND3x1_ASAP7_75t_R   g62(.A(new_n91_), .B(p1), .C(new_n69_), .Y(o17));
  AND5x1_ASAP7_75t_R   g63(.A(p2), .B(new_n36_), .C(new_n51_), .D(p0), .E(p1), .Y(o18));
  NAND2x1_ASAP7_75t_R  g64(.A(new_n61_), .B(new_n60_), .Y(new_n98_));
  AOI21x1_ASAP7_75t_R  g65(.A1(new_n91_), .A2(new_n94_), .B(p1), .Y(new_n99_));
  OA21x2_ASAP7_75t_R   g66(.A1(new_n52_), .A2(new_n69_), .B(p1), .Y(new_n100_));
  AOI21x1_ASAP7_75t_R  g67(.A1(new_n98_), .A2(new_n99_), .B(new_n100_), .Y(o20));
  OR5x1_ASAP7_75t_R    g68(.A(new_n35_), .B(new_n51_), .C(p3), .D(p0), .E(p1), .Y(new_n102_));
  OR5x1_ASAP7_75t_R    g69(.A(new_n51_), .B(new_n52_), .C(new_n55_), .D(p1), .E(p5), .Y(new_n103_));
  NAND2x1_ASAP7_75t_R  g70(.A(new_n102_), .B(new_n103_), .Y(o21));
  AOI21x1_ASAP7_75t_R  g71(.A1(new_n45_), .A2(new_n62_), .B(new_n100_), .Y(o22));
  assign               o23 = 1'b1;
  OA211x2_ASAP7_75t_R  g72(.A1(new_n92_), .A2(new_n69_), .B(p3), .C(new_n81_), .Y(o24));
  AND5x1_ASAP7_75t_R   g73(.A(new_n35_), .B(new_n40_), .C(new_n45_), .D(p3), .E(p6), .Y(o25));
endmodule


