// Benchmark "/tmp/" written by ABC on Tue Oct 20 17:23:06 2026

module \/tmp/  ( 
    p2, p3, p4, p5, p6, p0, p1,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25  );
  input  p2, p3, p4, p5, p6, p0, p1;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25;
  wire new_n34_, new_n35_, new_n36_, new_n37_, new_n39_, new_n40_, new_n41_,
    new_n42_, new_n43_, new_n44_, new_n45_, new_n47_, new_n48_, new_n49_,
    new_n50_, new_n51_, new_n53_, new_n54_, new_n55_, new_n57_, new_n58_,
    new_n59_, new_n60_, new_n61_, new_n62_, new_n64_, new_n65_, new_n66_,
    new_n68_, new_n69_, new_n70_, new_n72_, new_n73_, new_n75_, new_n76_,
    new_n79_, new_n80_, new_n81_, new_n84_, new_n85_, new_n86_, new_n87_,
    new_n92_, new_n97_, new_n98_, new_n99_, new_n100_, new_n102_,
    new_n103_, new_n105_, new_n106_, new_n107_, new_n110_;
  OR3x1_ASAP7_75t_R    g00(.A(p6), .B(p0), .C(p1), .Y(new_n34_));
  AND2x2_ASAP7_75t_R   g01(.A(p2), .B(p3), .Y(new_n35_));
  NOR2x1_ASAP7_75t_R   g02(.A(p2), .B(p3), .Y(new_n36_));
  AND3x1_ASAP7_75t_R   g03(.A(new_n36_), .B(p0), .C(p1), .Y(new_n37_));
  AO21x1_ASAP7_75t_R   g04(.A1(new_n34_), .A2(new_n35_), .B(new_n37_), .Y(o0));
  NOR2x1_ASAP7_75t_R   g05(.A(p0), .B(p1), .Y(new_n39_));
  INVx1_ASAP7_75t_R    g06(.A(p1), .Y(new_n40_));
  OAI22x1_ASAP7_75t_R  g07(.A1(new_n35_), .A2(p0), .B1(new_n40_), .B2(new_n36_), .Y(new_n41_));
  NAND2x1_ASAP7_75t_R  g08(.A(p0), .B(new_n40_), .Y(new_n42_));
  INVx1_ASAP7_75t_R    g09(.A(p3), .Y(new_n43_));
  NOR2x1_ASAP7_75t_R   g10(.A(p2), .B(new_n43_), .Y(new_n44_));
  NOR2x1_ASAP7_75t_R   g11(.A(new_n42_), .B(new_n44_), .Y(new_n45_));
  AOI211x1_ASAP7_75t_R g12(.A1(p6), .A2(new_n39_), .B(new_n41_), .C(new_n45_), .Y(o1));
  NAND2x1_ASAP7_75t_R  g13(.A(p2), .B(p3), .Y(new_n47_));
  OR3x1_ASAP7_75t_R    g14(.A(new_n47_), .B(p6), .C(p1), .Y(new_n48_));
  OR3x1_ASAP7_75t_R    g15(.A(new_n43_), .B(p2), .C(p6), .Y(new_n49_));
  INVx1_ASAP7_75t_R    g16(.A(p2), .Y(new_n50_));
  OA21x2_ASAP7_75t_R   g17(.A1(p3), .A2(new_n50_), .B(p0), .Y(new_n51_));
  AOI22x1_ASAP7_75t_R  g18(.A1(new_n48_), .A2(new_n42_), .B1(new_n49_), .B2(new_n51_), .Y(o2));
  NAND2x1_ASAP7_75t_R  g19(.A(p3), .B(p6), .Y(new_n53_));
  INVx1_ASAP7_75t_R    g20(.A(p0), .Y(new_n54_));
  AND3x1_ASAP7_75t_R   g21(.A(new_n54_), .B(new_n40_), .C(p2), .Y(new_n55_));
  AO21x1_ASAP7_75t_R   g22(.A1(new_n53_), .A2(new_n55_), .B(new_n44_), .Y(o3));
  AND2x2_ASAP7_75t_R   g23(.A(p4), .B(p5), .Y(new_n57_));
  AND3x1_ASAP7_75t_R   g24(.A(p2), .B(p6), .C(p0), .Y(new_n58_));
  OAI21x1_ASAP7_75t_R  g25(.A1(new_n43_), .A2(new_n57_), .B(new_n58_), .Y(new_n59_));
  NAND2x1_ASAP7_75t_R  g26(.A(p4), .B(p0), .Y(new_n60_));
  OA31x2_ASAP7_75t_R   g27(.A1(p6), .A2(new_n47_), .A3(new_n60_), .B1(new_n40_), .Y(new_n61_));
  OA21x2_ASAP7_75t_R   g28(.A1(p2), .A2(new_n53_), .B(p1), .Y(new_n62_));
  AOI21x1_ASAP7_75t_R  g29(.A1(new_n59_), .A2(new_n61_), .B(new_n62_), .Y(o4));
  NAND2x1_ASAP7_75t_R  g30(.A(p2), .B(new_n43_), .Y(new_n64_));
  AOI21x1_ASAP7_75t_R  g31(.A1(p2), .A2(p5), .B(p1), .Y(new_n65_));
  NOR2x1_ASAP7_75t_R   g32(.A(new_n40_), .B(new_n44_), .Y(new_n66_));
  AOI211x1_ASAP7_75t_R g33(.A1(new_n64_), .A2(new_n65_), .B(new_n54_), .C(new_n66_), .Y(o5));
  NAND2x1_ASAP7_75t_R  g34(.A(p6), .B(p0), .Y(new_n68_));
  AO21x1_ASAP7_75t_R   g35(.A1(new_n40_), .A2(new_n68_), .B(new_n47_), .Y(new_n69_));
  OR3x1_ASAP7_75t_R    g36(.A(new_n35_), .B(p1), .C(new_n36_), .Y(new_n70_));
  NAND2x1_ASAP7_75t_R  g37(.A(new_n69_), .B(new_n70_), .Y(o6));
  INVx1_ASAP7_75t_R    g38(.A(p6), .Y(new_n72_));
  OAI21x1_ASAP7_75t_R  g39(.A1(new_n72_), .A2(new_n40_), .B(new_n34_), .Y(new_n73_));
  AO21x1_ASAP7_75t_R   g40(.A1(new_n35_), .A2(new_n73_), .B(new_n37_), .Y(o7));
  NOR2x1_ASAP7_75t_R   g41(.A(new_n40_), .B(new_n36_), .Y(new_n75_));
  NOR2x1_ASAP7_75t_R   g42(.A(p1), .B(new_n54_), .Y(new_n76_));
  AOI221x1_ASAP7_75t_R g43(.A1(new_n47_), .A2(new_n75_), .B1(new_n49_), .B2(new_n76_), .C(new_n54_), .Y(o8));
  AOI21x1_ASAP7_75t_R  g44(.A1(new_n76_), .A2(new_n49_), .B(new_n41_), .Y(o9));
  NOR2x1_ASAP7_75t_R   g45(.A(p2), .B(p1), .Y(new_n79_));
  AO21x1_ASAP7_75t_R   g46(.A1(p3), .A2(new_n39_), .B(new_n79_), .Y(new_n80_));
  OAI21x1_ASAP7_75t_R  g47(.A1(p6), .A2(new_n54_), .B(new_n44_), .Y(new_n81_));
  OAI21x1_ASAP7_75t_R  g48(.A1(new_n80_), .A2(new_n66_), .B(new_n81_), .Y(o10));
  AND3x1_ASAP7_75t_R   g49(.A(new_n36_), .B(new_n39_), .C(new_n72_), .Y(o11));
  NOR2x1_ASAP7_75t_R   g50(.A(p3), .B(p0), .Y(new_n84_));
  INVx1_ASAP7_75t_R    g51(.A(new_n84_), .Y(new_n85_));
  NOR2x1_ASAP7_75t_R   g52(.A(p1), .B(new_n36_), .Y(new_n86_));
  OR3x1_ASAP7_75t_R    g53(.A(p2), .B(p6), .C(p0), .Y(new_n87_));
  AO32x1_ASAP7_75t_R   g54(.A1(p1), .A2(new_n64_), .A3(new_n85_), .B1(new_n86_), .B2(new_n87_), .Y(o12));
  AND3x1_ASAP7_75t_R   g55(.A(new_n36_), .B(p6), .C(p1), .Y(o13));
  AND3x1_ASAP7_75t_R   g56(.A(new_n36_), .B(new_n72_), .C(p1), .Y(o14));
  AND5x1_ASAP7_75t_R   g57(.A(p2), .B(new_n43_), .C(new_n72_), .D(new_n54_), .E(p1), .Y(o15));
  AND3x1_ASAP7_75t_R   g58(.A(new_n43_), .B(new_n54_), .C(p2), .Y(new_n92_));
  AND3x1_ASAP7_75t_R   g59(.A(new_n92_), .B(p6), .C(p1), .Y(o16));
  AND5x1_ASAP7_75t_R   g60(.A(new_n43_), .B(p2), .C(p6), .D(p0), .E(p1), .Y(o17));
  AND5x1_ASAP7_75t_R   g61(.A(p2), .B(new_n43_), .C(new_n72_), .D(p0), .E(p1), .Y(o18));
  AND3x1_ASAP7_75t_R   g62(.A(new_n50_), .B(new_n43_), .C(p1), .Y(o19));
  OAI21x1_ASAP7_75t_R  g63(.A1(new_n43_), .A2(p4), .B(new_n58_), .Y(new_n97_));
  AND2x2_ASAP7_75t_R   g64(.A(p2), .B(p6), .Y(new_n98_));
  AOI21x1_ASAP7_75t_R  g65(.A1(new_n84_), .A2(new_n98_), .B(p1), .Y(new_n99_));
  AOI21x1_ASAP7_75t_R  g66(.A1(new_n68_), .A2(new_n35_), .B(new_n40_), .Y(new_n100_));
  AOI21x1_ASAP7_75t_R  g67(.A1(new_n97_), .A2(new_n99_), .B(new_n100_), .Y(o20));
  NOR3x1_ASAP7_75t_R   g68(.A(new_n47_), .B(new_n60_), .C(p5), .Y(new_n102_));
  NOR2x1_ASAP7_75t_R   g69(.A(p1), .B(new_n72_), .Y(new_n103_));
  OA21x2_ASAP7_75t_R   g70(.A1(new_n92_), .A2(new_n102_), .B(new_n103_), .Y(o21));
  NAND2x1_ASAP7_75t_R  g71(.A(p3), .B(p5), .Y(new_n105_));
  AND2x2_ASAP7_75t_R   g72(.A(p6), .B(p0), .Y(new_n106_));
  OAI21x1_ASAP7_75t_R  g73(.A1(p4), .A2(new_n105_), .B(new_n106_), .Y(new_n107_));
  AOI221x1_ASAP7_75t_R g74(.A1(new_n64_), .A2(new_n65_), .B1(new_n107_), .B2(new_n40_), .C(new_n100_), .Y(o22));
  assign               o23 = 1'b1;
  NOR2x1_ASAP7_75t_R   g75(.A(p6), .B(p0), .Y(new_n110_));
  OA211x2_ASAP7_75t_R  g76(.A1(new_n110_), .A2(new_n106_), .B(p3), .C(new_n79_), .Y(o24));
  AND3x1_ASAP7_75t_R   g77(.A(new_n44_), .B(p6), .C(new_n39_), .Y(o25));
endmodule


