// Benchmark "/tmp/" written by ABC on Tue Oct 20 17:23:05 2026

module \/tmp/  ( 
    p2, p4, p6, p0, p5, p1, p3,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25  );
  input  p2, p4, p6, p0, p5, p1, p3;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25;
  wire new_n34_, new_n35_, new_n36_, new_n37_, new_n38_, new_n39_, new_n41_,
    new_n43_, new_n44_, new_n45_, new_n46_, new_n47_, new_n48_, new_n49_,
    new_n50_, new_n52_, new_n53_, new_n54_, new_n55_, new_n57_, new_n59_,
    new_n60_, new_n61_, new_n62_, new_n63_, new_n64_, new_n65_, new_n67_,
    new_n68_, new_n69_, new_n71_, new_n72_, new_n73_, new_n75_, new_n76_,
    new_n78_, new_n81_, new_n82_, new_n85_, new_n86_, new_n87_, new_n95_,
    new_n96_, new_n97_, new_n98_, new_n99_, new_n101_, new_n102_,
    new_n103_, new_n104_, new_n106_, new_n107_, new_n108_, new_n109_,
    new_n112_, new_n113_;
  INVx1_ASAP7_75t_R    g00(.A(p6), .Y(new_n34_));
  NOR2x1_ASAP7_75t_R   g01(.A(p0), .B(p1), .Y(new_n35_));
  NAND2x1_ASAP7_75t_R  g02(.A(p2), .B(p3), .Y(new_n36_));
  AO21x1_ASAP7_75t_R   g03(.A1(new_n34_), .A2(new_n35_), .B(new_n36_), .Y(new_n37_));
  INVx1_ASAP7_75t_R    g04(.A(p2), .Y(new_n38_));
  INVx1_ASAP7_75t_R    g05(.A(p3), .Y(new_n39_));
  AND3x1_ASAP7_75t_R   g06(.A(new_n38_), .B(new_n39_), .C(p1), .Y(o19));
  NAND2x1_ASAP7_75t_R  g07(.A(p0), .B(o19), .Y(new_n41_));
  NAND2x1_ASAP7_75t_R  g08(.A(new_n37_), .B(new_n41_), .Y(o0));
  NOR2x1_ASAP7_75t_R   g09(.A(p2), .B(new_n39_), .Y(new_n43_));
  INVx1_ASAP7_75t_R    g10(.A(new_n43_), .Y(new_n44_));
  INVx1_ASAP7_75t_R    g11(.A(p0), .Y(new_n45_));
  NOR2x1_ASAP7_75t_R   g12(.A(p1), .B(new_n45_), .Y(new_n46_));
  AND2x2_ASAP7_75t_R   g13(.A(p2), .B(p3), .Y(new_n47_));
  INVx1_ASAP7_75t_R    g14(.A(p1), .Y(new_n48_));
  NOR2x1_ASAP7_75t_R   g15(.A(p2), .B(p3), .Y(new_n49_));
  OAI22x1_ASAP7_75t_R  g16(.A1(new_n47_), .A2(p0), .B1(new_n48_), .B2(new_n49_), .Y(new_n50_));
  AOI221x1_ASAP7_75t_R g17(.A1(p6), .A2(new_n35_), .B1(new_n44_), .B2(new_n46_), .C(new_n50_), .Y(o1));
  INVx1_ASAP7_75t_R    g18(.A(new_n46_), .Y(new_n52_));
  OR3x1_ASAP7_75t_R    g19(.A(new_n36_), .B(p6), .C(p1), .Y(new_n53_));
  OR3x1_ASAP7_75t_R    g20(.A(new_n39_), .B(p2), .C(p6), .Y(new_n54_));
  OA21x2_ASAP7_75t_R   g21(.A1(p3), .A2(new_n38_), .B(p0), .Y(new_n55_));
  AOI22x1_ASAP7_75t_R  g22(.A1(new_n52_), .A2(new_n53_), .B1(new_n54_), .B2(new_n55_), .Y(o2));
  NAND2x1_ASAP7_75t_R  g23(.A(p2), .B(new_n35_), .Y(new_n57_));
  AOI22x1_ASAP7_75t_R  g24(.A1(new_n44_), .A2(new_n57_), .B1(p6), .B2(new_n47_), .Y(o3));
  AND2x2_ASAP7_75t_R   g25(.A(p4), .B(p5), .Y(new_n59_));
  AND3x1_ASAP7_75t_R   g26(.A(p2), .B(p6), .C(p0), .Y(new_n60_));
  OAI21x1_ASAP7_75t_R  g27(.A1(new_n39_), .A2(new_n59_), .B(new_n60_), .Y(new_n61_));
  AND3x1_ASAP7_75t_R   g28(.A(p2), .B(p4), .C(p3), .Y(new_n62_));
  NOR2x1_ASAP7_75t_R   g29(.A(p6), .B(new_n45_), .Y(new_n63_));
  AOI21x1_ASAP7_75t_R  g30(.A1(new_n62_), .A2(new_n63_), .B(p1), .Y(new_n64_));
  AOI21x1_ASAP7_75t_R  g31(.A1(p6), .A2(new_n43_), .B(new_n48_), .Y(new_n65_));
  AOI21x1_ASAP7_75t_R  g32(.A1(new_n61_), .A2(new_n64_), .B(new_n65_), .Y(o4));
  NAND2x1_ASAP7_75t_R  g33(.A(p2), .B(new_n39_), .Y(new_n67_));
  AOI21x1_ASAP7_75t_R  g34(.A1(p2), .A2(p5), .B(p1), .Y(new_n68_));
  NOR2x1_ASAP7_75t_R   g35(.A(new_n48_), .B(new_n43_), .Y(new_n69_));
  AOI211x1_ASAP7_75t_R g36(.A1(new_n67_), .A2(new_n68_), .B(new_n45_), .C(new_n69_), .Y(o5));
  NOR2x1_ASAP7_75t_R   g37(.A(p1), .B(new_n49_), .Y(new_n71_));
  AOI21x1_ASAP7_75t_R  g38(.A1(p6), .A2(p0), .B(p1), .Y(new_n72_));
  NOR2x1_ASAP7_75t_R   g39(.A(new_n36_), .B(new_n72_), .Y(new_n73_));
  AO21x1_ASAP7_75t_R   g40(.A1(new_n36_), .A2(new_n71_), .B(new_n73_), .Y(o6));
  AND2x2_ASAP7_75t_R   g41(.A(p6), .B(p1), .Y(new_n75_));
  AOI21x1_ASAP7_75t_R  g42(.A1(new_n34_), .A2(new_n35_), .B(new_n75_), .Y(new_n76_));
  OAI21x1_ASAP7_75t_R  g43(.A1(new_n36_), .A2(new_n76_), .B(new_n41_), .Y(o7));
  NOR2x1_ASAP7_75t_R   g44(.A(new_n48_), .B(new_n49_), .Y(new_n78_));
  AOI221x1_ASAP7_75t_R g45(.A1(new_n36_), .A2(new_n78_), .B1(new_n54_), .B2(new_n46_), .C(new_n45_), .Y(o8));
  AOI21x1_ASAP7_75t_R  g46(.A1(new_n46_), .A2(new_n54_), .B(new_n50_), .Y(o9));
  NOR2x1_ASAP7_75t_R   g47(.A(p2), .B(p1), .Y(new_n81_));
  AO21x1_ASAP7_75t_R   g48(.A1(p3), .A2(new_n35_), .B(new_n81_), .Y(new_n82_));
  OAI22x1_ASAP7_75t_R  g49(.A1(new_n69_), .A2(new_n82_), .B1(new_n44_), .B2(new_n63_), .Y(o10));
  AND3x1_ASAP7_75t_R   g50(.A(new_n35_), .B(new_n49_), .C(new_n34_), .Y(o11));
  NOR2x1_ASAP7_75t_R   g51(.A(p0), .B(p3), .Y(new_n85_));
  INVx1_ASAP7_75t_R    g52(.A(new_n85_), .Y(new_n86_));
  OR3x1_ASAP7_75t_R    g53(.A(p2), .B(p6), .C(p0), .Y(new_n87_));
  AO32x1_ASAP7_75t_R   g54(.A1(p1), .A2(new_n67_), .A3(new_n86_), .B1(new_n71_), .B2(new_n87_), .Y(o12));
  AND3x1_ASAP7_75t_R   g55(.A(new_n49_), .B(p6), .C(p1), .Y(o13));
  AND3x1_ASAP7_75t_R   g56(.A(new_n49_), .B(new_n34_), .C(p1), .Y(o14));
  AND5x1_ASAP7_75t_R   g57(.A(p2), .B(new_n34_), .C(new_n45_), .D(new_n39_), .E(p1), .Y(o15));
  AND3x1_ASAP7_75t_R   g58(.A(new_n75_), .B(p2), .C(new_n85_), .Y(o16));
  AND5x1_ASAP7_75t_R   g59(.A(p2), .B(new_n39_), .C(p6), .D(p0), .E(p1), .Y(o17));
  AND5x1_ASAP7_75t_R   g60(.A(p2), .B(new_n34_), .C(new_n39_), .D(p0), .E(p1), .Y(o18));
  OAI21x1_ASAP7_75t_R  g61(.A1(p4), .A2(new_n39_), .B(new_n60_), .Y(new_n95_));
  AND2x2_ASAP7_75t_R   g62(.A(p2), .B(p6), .Y(new_n96_));
  AOI21x1_ASAP7_75t_R  g63(.A1(new_n85_), .A2(new_n96_), .B(p1), .Y(new_n97_));
  AND3x1_ASAP7_75t_R   g64(.A(p6), .B(p0), .C(p1), .Y(new_n98_));
  AO21x1_ASAP7_75t_R   g65(.A1(p1), .A2(new_n36_), .B(new_n98_), .Y(new_n99_));
  AOI21x1_ASAP7_75t_R  g66(.A1(new_n95_), .A2(new_n97_), .B(new_n99_), .Y(o20));
  NAND2x1_ASAP7_75t_R  g67(.A(p2), .B(new_n85_), .Y(new_n101_));
  INVx1_ASAP7_75t_R    g68(.A(p4), .Y(new_n102_));
  OR4x2_ASAP7_75t_R    g69(.A(new_n36_), .B(new_n102_), .C(new_n45_), .D(p5), .Y(new_n103_));
  NAND2x1_ASAP7_75t_R  g70(.A(p6), .B(new_n48_), .Y(new_n104_));
  AOI21x1_ASAP7_75t_R  g71(.A1(new_n101_), .A2(new_n103_), .B(new_n104_), .Y(o21));
  NAND2x1_ASAP7_75t_R  g72(.A(new_n68_), .B(new_n67_), .Y(new_n106_));
  AOI211x1_ASAP7_75t_R g73(.A1(p1), .A2(new_n36_), .B(new_n72_), .C(new_n98_), .Y(new_n107_));
  NAND2x1_ASAP7_75t_R  g74(.A(p5), .B(p3), .Y(new_n108_));
  OR3x1_ASAP7_75t_R    g75(.A(new_n108_), .B(p4), .C(p1), .Y(new_n109_));
  AND3x1_ASAP7_75t_R   g76(.A(new_n106_), .B(new_n107_), .C(new_n109_), .Y(o22));
  assign               o23 = 1'b1;
  NOR2x1_ASAP7_75t_R   g77(.A(p6), .B(p0), .Y(new_n112_));
  AND2x2_ASAP7_75t_R   g78(.A(p6), .B(p0), .Y(new_n113_));
  OA211x2_ASAP7_75t_R  g79(.A1(new_n112_), .A2(new_n113_), .B(p3), .C(new_n81_), .Y(o24));
  AND3x1_ASAP7_75t_R   g80(.A(new_n43_), .B(p6), .C(new_n35_), .Y(o25));
endmodule


