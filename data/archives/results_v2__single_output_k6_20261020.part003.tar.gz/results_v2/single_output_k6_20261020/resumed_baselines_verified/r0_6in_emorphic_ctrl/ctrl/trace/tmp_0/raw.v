// Benchmark "/tmp/" written by ABC on Tue Oct 20 17:23:04 2026

module \/tmp/  ( 
    p5, p0, p1, p3, p6, p2, p4,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25  );
  input  p5, p0, p1, p3, p6, p2, p4;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25;
  wire new_n34_, new_n35_, new_n36_, new_n38_, new_n39_, new_n40_, new_n41_,
    new_n42_, new_n43_, new_n44_, new_n45_, new_n47_, new_n48_, new_n49_,
    new_n50_, new_n51_, new_n52_, new_n54_, new_n55_, new_n57_, new_n58_,
    new_n59_, new_n60_, new_n61_, new_n62_, new_n63_, new_n64_, new_n65_,
    new_n66_, new_n68_, new_n69_, new_n71_, new_n72_, new_n73_, new_n75_,
    new_n76_, new_n81_, new_n82_, new_n85_, new_n86_, new_n87_, new_n91_,
    new_n93_, new_n94_, new_n98_, new_n99_, new_n101_, new_n102_;
  NOR2x1_ASAP7_75t_R   g00(.A(p3), .B(p2), .Y(new_n34_));
  OR3x1_ASAP7_75t_R    g01(.A(p0), .B(p1), .C(p6), .Y(new_n35_));
  AND2x2_ASAP7_75t_R   g02(.A(p3), .B(p2), .Y(new_n36_));
  AO32x1_ASAP7_75t_R   g03(.A1(p0), .A2(p1), .A3(new_n34_), .B1(new_n35_), .B2(new_n36_), .Y(o0));
  NOR2x1_ASAP7_75t_R   g04(.A(p0), .B(p1), .Y(new_n38_));
  INVx1_ASAP7_75t_R    g05(.A(p3), .Y(new_n39_));
  NOR2x1_ASAP7_75t_R   g06(.A(p2), .B(new_n39_), .Y(new_n40_));
  INVx1_ASAP7_75t_R    g07(.A(new_n40_), .Y(new_n41_));
  INVx1_ASAP7_75t_R    g08(.A(p0), .Y(new_n42_));
  NOR2x1_ASAP7_75t_R   g09(.A(p1), .B(new_n42_), .Y(new_n43_));
  INVx1_ASAP7_75t_R    g10(.A(p1), .Y(new_n44_));
  OAI22x1_ASAP7_75t_R  g11(.A1(new_n36_), .A2(p0), .B1(new_n44_), .B2(new_n34_), .Y(new_n45_));
  AOI221x1_ASAP7_75t_R g12(.A1(p6), .A2(new_n38_), .B1(new_n41_), .B2(new_n43_), .C(new_n45_), .Y(o1));
  INVx1_ASAP7_75t_R    g13(.A(new_n43_), .Y(new_n47_));
  NAND2x1_ASAP7_75t_R  g14(.A(p3), .B(p2), .Y(new_n48_));
  OR3x1_ASAP7_75t_R    g15(.A(new_n48_), .B(p1), .C(p6), .Y(new_n49_));
  OR3x1_ASAP7_75t_R    g16(.A(new_n39_), .B(p6), .C(p2), .Y(new_n50_));
  INVx1_ASAP7_75t_R    g17(.A(p2), .Y(new_n51_));
  OA21x2_ASAP7_75t_R   g18(.A1(p3), .A2(new_n51_), .B(p0), .Y(new_n52_));
  AOI22x1_ASAP7_75t_R  g19(.A1(new_n47_), .A2(new_n49_), .B1(new_n50_), .B2(new_n52_), .Y(o2));
  INVx1_ASAP7_75t_R    g20(.A(p6), .Y(new_n54_));
  INVx1_ASAP7_75t_R    g21(.A(new_n34_), .Y(new_n55_));
  OA221x2_ASAP7_75t_R  g22(.A1(new_n54_), .A2(new_n48_), .B1(new_n51_), .B2(new_n38_), .C(new_n55_), .Y(o3));
  AND3x1_ASAP7_75t_R   g23(.A(p3), .B(p2), .C(p4), .Y(new_n57_));
  NOR2x1_ASAP7_75t_R   g24(.A(p6), .B(new_n42_), .Y(new_n58_));
  AOI21x1_ASAP7_75t_R  g25(.A1(new_n57_), .A2(new_n58_), .B(p1), .Y(new_n59_));
  INVx1_ASAP7_75t_R    g26(.A(p5), .Y(new_n60_));
  NAND2x1_ASAP7_75t_R  g27(.A(p3), .B(new_n60_), .Y(new_n61_));
  INVx1_ASAP7_75t_R    g28(.A(p4), .Y(new_n62_));
  NAND2x1_ASAP7_75t_R  g29(.A(p3), .B(new_n62_), .Y(new_n63_));
  AND3x1_ASAP7_75t_R   g30(.A(p0), .B(p6), .C(p2), .Y(new_n64_));
  NAND3x1_ASAP7_75t_R  g31(.A(new_n61_), .B(new_n63_), .C(new_n64_), .Y(new_n65_));
  AOI21x1_ASAP7_75t_R  g32(.A1(p6), .A2(new_n40_), .B(new_n44_), .Y(new_n66_));
  AOI21x1_ASAP7_75t_R  g33(.A1(new_n59_), .A2(new_n65_), .B(new_n66_), .Y(o4));
  AO21x1_ASAP7_75t_R   g34(.A1(p3), .A2(new_n60_), .B(new_n51_), .Y(new_n68_));
  NOR2x1_ASAP7_75t_R   g35(.A(new_n44_), .B(new_n40_), .Y(new_n69_));
  AOI211x1_ASAP7_75t_R g36(.A1(new_n44_), .A2(new_n68_), .B(new_n42_), .C(new_n69_), .Y(o5));
  AND2x2_ASAP7_75t_R   g37(.A(p0), .B(p6), .Y(new_n71_));
  NOR2x1_ASAP7_75t_R   g38(.A(new_n48_), .B(new_n71_), .Y(new_n72_));
  AND2x2_ASAP7_75t_R   g39(.A(p1), .B(new_n48_), .Y(new_n73_));
  AOI211x1_ASAP7_75t_R g40(.A1(new_n44_), .A2(new_n72_), .B(new_n34_), .C(new_n73_), .Y(o6));
  AO21x1_ASAP7_75t_R   g41(.A1(new_n42_), .A2(new_n54_), .B(p1), .Y(new_n75_));
  NAND2x1_ASAP7_75t_R  g42(.A(p1), .B(new_n54_), .Y(new_n76_));
  AND3x1_ASAP7_75t_R   g43(.A(new_n39_), .B(new_n51_), .C(p1), .Y(o19));
  AO32x1_ASAP7_75t_R   g44(.A1(new_n75_), .A2(new_n36_), .A3(new_n76_), .B1(o19), .B2(p0), .Y(o7));
  AOI221x1_ASAP7_75t_R g45(.A1(new_n50_), .A2(new_n44_), .B1(new_n73_), .B2(new_n55_), .C(new_n42_), .Y(o8));
  AOI21x1_ASAP7_75t_R  g46(.A1(new_n43_), .A2(new_n50_), .B(new_n45_), .Y(o9));
  NOR2x1_ASAP7_75t_R   g47(.A(p1), .B(p2), .Y(new_n81_));
  AO21x1_ASAP7_75t_R   g48(.A1(p3), .A2(new_n38_), .B(new_n81_), .Y(new_n82_));
  OAI22x1_ASAP7_75t_R  g49(.A1(new_n69_), .A2(new_n82_), .B1(new_n41_), .B2(new_n58_), .Y(o10));
  AND3x1_ASAP7_75t_R   g50(.A(new_n34_), .B(new_n38_), .C(new_n54_), .Y(o11));
  NOR2x1_ASAP7_75t_R   g51(.A(p0), .B(p6), .Y(new_n85_));
  OA21x2_ASAP7_75t_R   g52(.A1(new_n39_), .A2(new_n85_), .B(new_n81_), .Y(new_n86_));
  OA211x2_ASAP7_75t_R  g53(.A1(new_n42_), .A2(p2), .B(new_n39_), .C(p1), .Y(new_n87_));
  NOR2x1_ASAP7_75t_R   g54(.A(new_n86_), .B(new_n87_), .Y(o12));
  AND3x1_ASAP7_75t_R   g55(.A(new_n34_), .B(p1), .C(p6), .Y(o13));
  AND3x1_ASAP7_75t_R   g56(.A(new_n34_), .B(p1), .C(new_n54_), .Y(o14));
  AND3x1_ASAP7_75t_R   g57(.A(new_n39_), .B(p1), .C(p2), .Y(new_n91_));
  AND2x2_ASAP7_75t_R   g58(.A(new_n85_), .B(new_n91_), .Y(o15));
  AND2x2_ASAP7_75t_R   g59(.A(p6), .B(p2), .Y(new_n93_));
  NOR2x1_ASAP7_75t_R   g60(.A(p0), .B(p3), .Y(new_n94_));
  AND3x1_ASAP7_75t_R   g61(.A(new_n93_), .B(p1), .C(new_n94_), .Y(o16));
  AND2x2_ASAP7_75t_R   g62(.A(new_n71_), .B(new_n91_), .Y(o17));
  AND2x2_ASAP7_75t_R   g63(.A(new_n58_), .B(new_n91_), .Y(o18));
  AOI22x1_ASAP7_75t_R  g64(.A1(new_n63_), .A2(new_n64_), .B1(new_n94_), .B2(new_n93_), .Y(new_n98_));
  OA21x2_ASAP7_75t_R   g65(.A1(new_n48_), .A2(new_n71_), .B(p1), .Y(new_n99_));
  AOI21x1_ASAP7_75t_R  g66(.A1(new_n44_), .A2(new_n98_), .B(new_n99_), .Y(o20));
  AND3x1_ASAP7_75t_R   g67(.A(new_n42_), .B(new_n39_), .C(p2), .Y(new_n101_));
  AND5x1_ASAP7_75t_R   g68(.A(new_n60_), .B(p0), .C(p3), .D(p2), .E(p4), .Y(new_n102_));
  OA211x2_ASAP7_75t_R  g69(.A1(new_n101_), .A2(new_n102_), .B(new_n44_), .C(p6), .Y(o21));
  AOI21x1_ASAP7_75t_R  g70(.A1(new_n44_), .A2(new_n65_), .B(new_n99_), .Y(o22));
  assign               o23 = 1'b1;
  OA211x2_ASAP7_75t_R  g71(.A1(new_n85_), .A2(new_n71_), .B(p3), .C(new_n81_), .Y(o24));
  AND3x1_ASAP7_75t_R   g72(.A(new_n40_), .B(p6), .C(new_n38_), .Y(o25));
endmodule


