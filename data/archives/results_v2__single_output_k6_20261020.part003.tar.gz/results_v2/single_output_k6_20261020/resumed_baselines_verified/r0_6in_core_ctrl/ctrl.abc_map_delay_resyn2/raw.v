// Benchmark "/home/flynn/workplace/MIGBalance/results_v2/single_output_k6_20261020/resumed_baselines_verified/r0_6in_core_ctrl/ctrl.resyn2" written by ABC on Tue Oct 20 17:22:23 2026

module \/home/flynn/workplace/MIGBalance/results_v2/single_output_k6_20261020/resumed_baselines_verified/r0_6in_core_ctrl/ctrl.resyn2  ( 
    \opcode[0] , \opcode[1] , \opcode[2] , \opcode[3] , \opcode[4] ,
    \op_ext[0] , \op_ext[1] ,
    \sel_reg_dst[0] , \sel_reg_dst[1] , \sel_alu_opB[0] , \sel_alu_opB[1] ,
    \alu_op[0] , \alu_op[1] , \alu_op[2] , \alu_op_ext[0] ,
    \alu_op_ext[1] , \alu_op_ext[2] , \alu_op_ext[3] , halt, reg_write,
    sel_pc_opA, sel_pc_opB, beqz, bnez, bgez, bltz, jump, Cin, invA, invB,
    sign, mem_write, sel_wb  );
  input  \opcode[0] , \opcode[1] , \opcode[2] , \opcode[3] , \opcode[4] ,
    \op_ext[0] , \op_ext[1] ;
  output \sel_reg_dst[0] , \sel_reg_dst[1] , \sel_alu_opB[0] ,
    \sel_alu_opB[1] , \alu_op[0] , \alu_op[1] , \alu_op[2] ,
    \alu_op_ext[0] , \alu_op_ext[1] , \alu_op_ext[2] , \alu_op_ext[3] ,
    halt, reg_write, sel_pc_opA, sel_pc_opB, beqz, bnez, bgez, bltz, jump,
    Cin, invA, invB, sign, mem_write, sel_wb;
  wire new_n34_, new_n35_, new_n36_, new_n37_, new_n38_, new_n39_, new_n40_,
    new_n42_, new_n43_, new_n44_, new_n45_, new_n46_, new_n47_, new_n48_,
    new_n49_, new_n51_, new_n52_, new_n53_, new_n55_, new_n56_, new_n58_,
    new_n59_, new_n60_, new_n61_, new_n62_, new_n63_, new_n64_, new_n65_,
    new_n66_, new_n69_, new_n70_, new_n71_, new_n73_, new_n75_, new_n77_,
    new_n79_, new_n80_, new_n83_, new_n84_, new_n85_, new_n89_, new_n95_,
    new_n96_, new_n97_, new_n99_, new_n101_, new_n102_;
  AND2x2_ASAP7_75t_R   g00(.A(\opcode[3] ), .B(\opcode[4] ), .Y(new_n34_));
  INVx1_ASAP7_75t_R    g01(.A(new_n34_), .Y(new_n35_));
  NOR2x1_ASAP7_75t_R   g02(.A(\opcode[0] ), .B(\opcode[1] ), .Y(new_n36_));
  INVx1_ASAP7_75t_R    g03(.A(\opcode[2] ), .Y(new_n37_));
  INVx1_ASAP7_75t_R    g04(.A(\opcode[1] ), .Y(new_n38_));
  OR3x1_ASAP7_75t_R    g05(.A(new_n38_), .B(\opcode[3] ), .C(\opcode[4] ), .Y(new_n39_));
  AO21x1_ASAP7_75t_R   g06(.A1(new_n39_), .A2(new_n35_), .B(new_n37_), .Y(new_n40_));
  OAI21x1_ASAP7_75t_R  g07(.A1(new_n35_), .A2(new_n36_), .B(new_n40_), .Y(\sel_reg_dst[0] ));
  INVx1_ASAP7_75t_R    g08(.A(\opcode[3] ), .Y(new_n42_));
  AND2x2_ASAP7_75t_R   g09(.A(new_n42_), .B(\opcode[4] ), .Y(new_n43_));
  INVx1_ASAP7_75t_R    g10(.A(\opcode[0] ), .Y(new_n44_));
  AND2x2_ASAP7_75t_R   g11(.A(new_n44_), .B(\opcode[3] ), .Y(new_n45_));
  AO21x1_ASAP7_75t_R   g12(.A1(new_n45_), .A2(\opcode[4] ), .B(\opcode[1] ), .Y(new_n46_));
  OA21x2_ASAP7_75t_R   g13(.A1(new_n38_), .A2(new_n43_), .B(new_n46_), .Y(new_n47_));
  NOR2x1_ASAP7_75t_R   g14(.A(\opcode[3] ), .B(\opcode[4] ), .Y(new_n48_));
  AO21x1_ASAP7_75t_R   g15(.A1(new_n48_), .A2(\opcode[1] ), .B(new_n37_), .Y(new_n49_));
  OA21x2_ASAP7_75t_R   g16(.A1(new_n47_), .A2(\opcode[2] ), .B(new_n49_), .Y(\sel_reg_dst[1] ));
  AO21x1_ASAP7_75t_R   g17(.A1(new_n43_), .A2(new_n44_), .B(new_n38_), .Y(new_n51_));
  INVx1_ASAP7_75t_R    g18(.A(\opcode[4] ), .Y(new_n52_));
  AND2x2_ASAP7_75t_R   g19(.A(new_n52_), .B(\opcode[3] ), .Y(new_n53_));
  OA211x2_ASAP7_75t_R  g20(.A1(new_n51_), .A2(new_n53_), .B(new_n46_), .C(new_n37_), .Y(\sel_alu_opB[0] ));
  NOR2x1_ASAP7_75t_R   g21(.A(\opcode[1] ), .B(\opcode[2] ), .Y(new_n55_));
  INVx1_ASAP7_75t_R    g22(.A(new_n55_), .Y(new_n56_));
  AOI221x1_ASAP7_75t_R g23(.A1(\opcode[0] ), .A2(new_n34_), .B1(\opcode[3] ), .B2(new_n56_), .C(new_n48_), .Y(\sel_alu_opB[1] ));
  INVx1_ASAP7_75t_R    g24(.A(\op_ext[1] ), .Y(new_n58_));
  OA21x2_ASAP7_75t_R   g25(.A1(new_n52_), .A2(\op_ext[1] ), .B(\opcode[3] ), .Y(new_n59_));
  INVx1_ASAP7_75t_R    g26(.A(\op_ext[0] ), .Y(new_n60_));
  NAND2x1_ASAP7_75t_R  g27(.A(\opcode[4] ), .B(new_n60_), .Y(new_n61_));
  OA211x2_ASAP7_75t_R  g28(.A1(new_n58_), .A2(new_n61_), .B(new_n59_), .C(\opcode[0] ), .Y(new_n62_));
  AND4x2_ASAP7_75t_R   g29(.A(new_n44_), .B(\opcode[3] ), .C(\opcode[4] ), .D(\op_ext[0] ), .Y(new_n63_));
  OAI21x1_ASAP7_75t_R  g30(.A1(new_n63_), .A2(new_n62_), .B(\opcode[1] ), .Y(new_n64_));
  AO21x1_ASAP7_75t_R   g31(.A1(new_n42_), .A2(\opcode[4] ), .B(new_n37_), .Y(new_n65_));
  OAI21x1_ASAP7_75t_R  g32(.A1(\opcode[0] ), .A2(new_n37_), .B(new_n65_), .Y(new_n66_));
  AOI21x1_ASAP7_75t_R  g33(.A1(new_n37_), .A2(new_n64_), .B(new_n66_), .Y(\alu_op[0] ));
  OA211x2_ASAP7_75t_R  g34(.A1(\opcode[2] ), .A2(new_n59_), .B(new_n65_), .C(\opcode[1] ), .Y(\alu_op[1] ));
  AND2x2_ASAP7_75t_R   g35(.A(\opcode[0] ), .B(\opcode[1] ), .Y(new_n69_));
  INVx1_ASAP7_75t_R    g36(.A(new_n69_), .Y(new_n70_));
  AND3x1_ASAP7_75t_R   g37(.A(new_n70_), .B(new_n34_), .C(new_n37_), .Y(new_n71_));
  AOI211x1_ASAP7_75t_R g38(.A1(\opcode[2] ), .A2(new_n35_), .B(new_n71_), .C(new_n48_), .Y(\alu_op[2] ));
  OAI21x1_ASAP7_75t_R  g39(.A1(new_n44_), .A2(new_n35_), .B(new_n39_), .Y(new_n73_));
  AO32x1_ASAP7_75t_R   g40(.A1(\opcode[4] ), .A2(new_n45_), .A3(new_n55_), .B1(\opcode[2] ), .B2(new_n73_), .Y(\alu_op_ext[0] ));
  OR3x1_ASAP7_75t_R    g41(.A(new_n48_), .B(new_n37_), .C(new_n34_), .Y(new_n75_));
  OA211x2_ASAP7_75t_R  g42(.A1(new_n51_), .A2(\opcode[2] ), .B(\opcode[1] ), .C(new_n75_), .Y(\alu_op_ext[1] ));
  OR3x1_ASAP7_75t_R    g43(.A(new_n34_), .B(\opcode[1] ), .C(\opcode[2] ), .Y(new_n77_));
  OA211x2_ASAP7_75t_R  g44(.A1(new_n51_), .A2(\opcode[2] ), .B(new_n49_), .C(new_n77_), .Y(\alu_op_ext[2] ));
  OA21x2_ASAP7_75t_R   g45(.A1(new_n52_), .A2(\opcode[1] ), .B(\opcode[3] ), .Y(new_n79_));
  OA21x2_ASAP7_75t_R   g46(.A1(\opcode[0] ), .A2(new_n38_), .B(new_n43_), .Y(new_n80_));
  OA31x2_ASAP7_75t_R   g47(.A1(\opcode[2] ), .A2(new_n80_), .A3(new_n79_), .B1(new_n65_), .Y(\alu_op_ext[3] ));
  AND3x1_ASAP7_75t_R   g48(.A(new_n48_), .B(new_n55_), .C(new_n44_), .Y(halt));
  NOR2x1_ASAP7_75t_R   g49(.A(new_n52_), .B(new_n36_), .Y(new_n83_));
  OA21x2_ASAP7_75t_R   g50(.A1(new_n83_), .A2(\opcode[3] ), .B(new_n37_), .Y(new_n84_));
  AO21x1_ASAP7_75t_R   g51(.A1(new_n42_), .A2(\opcode[1] ), .B(\opcode[4] ), .Y(new_n85_));
  AO21x1_ASAP7_75t_R   g52(.A1(\opcode[2] ), .A2(new_n85_), .B(new_n84_), .Y(reg_write));
  AND3x1_ASAP7_75t_R   g53(.A(new_n48_), .B(\opcode[0] ), .C(\opcode[2] ), .Y(sel_pc_opA));
  AND3x1_ASAP7_75t_R   g54(.A(new_n48_), .B(new_n44_), .C(\opcode[2] ), .Y(sel_pc_opB));
  AND3x1_ASAP7_75t_R   g55(.A(new_n38_), .B(new_n52_), .C(\opcode[3] ), .Y(new_n89_));
  AND3x1_ASAP7_75t_R   g56(.A(new_n89_), .B(new_n44_), .C(\opcode[2] ), .Y(beqz));
  AND3x1_ASAP7_75t_R   g57(.A(new_n89_), .B(\opcode[0] ), .C(\opcode[2] ), .Y(bnez));
  AND3x1_ASAP7_75t_R   g58(.A(new_n53_), .B(\opcode[2] ), .C(new_n69_), .Y(bgez));
  AND5x1_ASAP7_75t_R   g59(.A(new_n44_), .B(new_n52_), .C(\opcode[1] ), .D(\opcode[2] ), .E(\opcode[3] ), .Y(bltz));
  AND3x1_ASAP7_75t_R   g60(.A(new_n42_), .B(new_n52_), .C(\opcode[2] ), .Y(jump));
  AO21x1_ASAP7_75t_R   g61(.A1(new_n70_), .A2(new_n34_), .B(new_n37_), .Y(new_n95_));
  AND3x1_ASAP7_75t_R   g62(.A(new_n61_), .B(\opcode[3] ), .C(new_n69_), .Y(new_n96_));
  AO21x1_ASAP7_75t_R   g63(.A1(new_n89_), .A2(\opcode[0] ), .B(\opcode[2] ), .Y(new_n97_));
  OA21x2_ASAP7_75t_R   g64(.A1(new_n96_), .A2(new_n97_), .B(new_n95_), .Y(Cin));
  AND5x1_ASAP7_75t_R   g65(.A(\opcode[1] ), .B(new_n58_), .C(\opcode[3] ), .D(\opcode[4] ), .E(\op_ext[0] ), .Y(new_n99_));
  OA211x2_ASAP7_75t_R  g66(.A1(new_n99_), .A2(new_n89_), .B(\opcode[0] ), .C(new_n37_), .Y(invA));
  OA21x2_ASAP7_75t_R   g67(.A1(new_n61_), .A2(new_n58_), .B(new_n59_), .Y(new_n101_));
  AO21x1_ASAP7_75t_R   g68(.A1(new_n101_), .A2(new_n69_), .B(\opcode[2] ), .Y(new_n102_));
  AND2x2_ASAP7_75t_R   g69(.A(new_n102_), .B(new_n95_), .Y(invB));
  OA211x2_ASAP7_75t_R  g70(.A1(new_n36_), .A2(new_n69_), .B(new_n43_), .C(new_n37_), .Y(mem_write));
  AND5x1_ASAP7_75t_R   g71(.A(\opcode[0] ), .B(new_n38_), .C(new_n37_), .D(new_n42_), .E(\opcode[4] ), .Y(sel_wb));
  assign               sign = 1'b1;
endmodule


