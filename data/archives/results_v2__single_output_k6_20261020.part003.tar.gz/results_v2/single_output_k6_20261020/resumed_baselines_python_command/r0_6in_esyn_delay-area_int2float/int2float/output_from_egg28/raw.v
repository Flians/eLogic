// Benchmark "/home/flynn/workplace/MIGBalance/results_v2/single_output_k6_20261020/resumed_baselines_python_command/r0_6in_esyn_delay-area_int2float/int2float/output_from_egg28/logic" written by ABC on Tue Oct 20 17:45:50 2026

module \/home/flynn/workplace/MIGBalance/results_v2/single_output_k6_20261020/resumed_baselines_python_command/r0_6in_esyn_delay-area_int2float/int2float/output_from_egg28/logic  ( 
    \B[1] , \B[2] , \B[3] , \B[4] , \B[5] , \B[6] , \B[7] , \B[8] , \B[9] ,
    \B[10] , \B[0] ,
    \M[0] , \M[1] , \M[2] , \M[3] , \E[0] , \E[1] , \E[2]   );
  input  \B[1] , \B[2] , \B[3] , \B[4] , \B[5] , \B[6] , \B[7] , \B[8] ,
    \B[9] , \B[10] , \B[0] ;
  output \M[0] , \M[1] , \M[2] , \M[3] , \E[0] , \E[1] , \E[2] ;
  wire new_n19_, new_n20_, new_n21_, new_n22_, new_n23_, new_n24_, new_n25_,
    new_n26_, new_n27_, new_n28_, new_n29_, new_n30_, new_n31_, new_n32_,
    new_n33_, new_n34_, new_n35_, new_n36_, new_n37_, new_n38_, new_n39_,
    new_n40_, new_n41_, new_n42_, new_n43_, new_n44_, new_n45_, new_n46_,
    new_n47_, new_n48_, new_n49_, new_n50_, new_n51_, new_n52_, new_n53_,
    new_n54_, new_n55_, new_n56_, new_n58_, new_n59_, new_n60_, new_n61_,
    new_n62_, new_n63_, new_n64_, new_n65_, new_n66_, new_n67_, new_n68_,
    new_n69_, new_n70_, new_n71_, new_n72_, new_n73_, new_n74_, new_n75_,
    new_n76_, new_n77_, new_n78_, new_n79_, new_n80_, new_n81_, new_n82_,
    new_n83_, new_n85_, new_n86_, new_n87_, new_n88_, new_n89_, new_n90_,
    new_n91_, new_n92_, new_n93_, new_n94_, new_n95_, new_n96_, new_n97_,
    new_n98_, new_n99_, new_n100_, new_n101_, new_n102_, new_n103_,
    new_n104_, new_n105_, new_n106_, new_n108_, new_n109_, new_n110_,
    new_n111_, new_n112_, new_n113_, new_n115_, new_n116_, new_n117_,
    new_n118_, new_n119_, new_n120_, new_n121_, new_n122_, new_n123_,
    new_n125_, new_n126_, new_n127_, new_n128_, new_n129_, new_n130_,
    new_n131_;
  INVx1_ASAP7_75t_R    g000(.A(\B[1] ), .Y(new_n19_));
  INVx1_ASAP7_75t_R    g001(.A(\B[2] ), .Y(new_n20_));
  INVx1_ASAP7_75t_R    g002(.A(\B[3] ), .Y(new_n21_));
  INVx1_ASAP7_75t_R    g003(.A(\B[4] ), .Y(new_n22_));
  INVx1_ASAP7_75t_R    g004(.A(\B[5] ), .Y(new_n23_));
  INVx1_ASAP7_75t_R    g005(.A(\B[6] ), .Y(new_n24_));
  INVx1_ASAP7_75t_R    g006(.A(\B[7] ), .Y(new_n25_));
  INVx1_ASAP7_75t_R    g007(.A(\B[8] ), .Y(new_n26_));
  INVx1_ASAP7_75t_R    g008(.A(\B[9] ), .Y(new_n27_));
  INVx1_ASAP7_75t_R    g009(.A(\B[10] ), .Y(new_n28_));
  INVx1_ASAP7_75t_R    g010(.A(\B[0] ), .Y(new_n29_));
  NAND2x1_ASAP7_75t_R  g011(.A(new_n24_), .B(\B[7] ), .Y(new_n30_));
  AO22x1_ASAP7_75t_R   g012(.A1(new_n20_), .A2(\B[3] ), .B1(\B[2] ), .B2(new_n21_), .Y(new_n31_));
  NOR2x1_ASAP7_75t_R   g013(.A(\B[8] ), .B(\B[9] ), .Y(new_n32_));
  INVx1_ASAP7_75t_R    g014(.A(new_n32_), .Y(new_n33_));
  AO21x1_ASAP7_75t_R   g015(.A1(new_n31_), .A2(new_n32_), .B(\B[10] ), .Y(new_n34_));
  NOR2x1_ASAP7_75t_R   g016(.A(new_n26_), .B(new_n28_), .Y(new_n35_));
  AOI22x1_ASAP7_75t_R  g017(.A1(new_n25_), .A2(new_n34_), .B1(\B[9] ), .B2(new_n35_), .Y(new_n36_));
  NOR2x1_ASAP7_75t_R   g018(.A(new_n19_), .B(new_n22_), .Y(new_n37_));
  OA211x2_ASAP7_75t_R  g019(.A1(\B[0] ), .A2(new_n37_), .B(new_n24_), .C(new_n25_), .Y(new_n38_));
  AO21x1_ASAP7_75t_R   g020(.A1(new_n22_), .A2(\B[8] ), .B(new_n37_), .Y(new_n39_));
  NAND2x1_ASAP7_75t_R  g021(.A(\B[0] ), .B(new_n39_), .Y(new_n40_));
  NOR2x1_ASAP7_75t_R   g022(.A(new_n22_), .B(new_n26_), .Y(new_n41_));
  AO21x1_ASAP7_75t_R   g023(.A1(new_n38_), .A2(new_n40_), .B(new_n41_), .Y(new_n42_));
  NOR2x1_ASAP7_75t_R   g024(.A(new_n19_), .B(new_n23_), .Y(new_n43_));
  NOR2x1_ASAP7_75t_R   g025(.A(\B[4] ), .B(new_n25_), .Y(new_n44_));
  AO32x1_ASAP7_75t_R   g026(.A1(new_n20_), .A2(new_n25_), .A3(new_n43_), .B1(new_n22_), .B2(\B[7] ), .Y(new_n45_));
  AO32x1_ASAP7_75t_R   g027(.A1(new_n21_), .A2(\B[4] ), .A3(\B[7] ), .B1(\B[3] ), .B2(new_n45_), .Y(new_n46_));
  AO32x1_ASAP7_75t_R   g028(.A1(new_n22_), .A2(\B[5] ), .A3(\B[8] ), .B1(new_n26_), .B2(new_n46_), .Y(new_n47_));
  AOI21x1_ASAP7_75t_R  g029(.A1(new_n23_), .A2(new_n42_), .B(new_n47_), .Y(new_n48_));
  NOR2x1_ASAP7_75t_R   g030(.A(new_n21_), .B(new_n22_), .Y(new_n49_));
  INVx1_ASAP7_75t_R    g031(.A(new_n49_), .Y(new_n50_));
  OR5x1_ASAP7_75t_R    g032(.A(new_n19_), .B(\B[2] ), .C(new_n44_), .D(new_n41_), .E(new_n49_), .Y(new_n51_));
  OR4x2_ASAP7_75t_R    g033(.A(\B[1] ), .B(new_n20_), .C(\B[7] ), .D(\B[8] ), .Y(new_n52_));
  AND3x1_ASAP7_75t_R   g034(.A(new_n27_), .B(new_n52_), .C(new_n51_), .Y(new_n53_));
  OA33x2_ASAP7_75t_R   g035(.A1(new_n23_), .A2(\B[6] ), .A3(new_n53_), .B1(\B[5] ), .B2(new_n24_), .B3(new_n27_), .Y(new_n54_));
  OA21x2_ASAP7_75t_R   g036(.A1(\B[9] ), .A2(new_n48_), .B(new_n54_), .Y(new_n55_));
  OA222x2_ASAP7_75t_R  g037(.A1(new_n28_), .A2(new_n30_), .B1(new_n24_), .B2(new_n36_), .C1(\B[10] ), .C2(new_n55_), .Y(new_n56_));
  INVx1_ASAP7_75t_R    g038(.A(new_n56_), .Y(\M[0] ));
  AOI22x1_ASAP7_75t_R  g039(.A1(new_n22_), .A2(new_n27_), .B1(new_n25_), .B2(\B[9] ), .Y(new_n58_));
  OA21x2_ASAP7_75t_R   g040(.A1(new_n19_), .A2(new_n20_), .B(new_n25_), .Y(new_n59_));
  OR3x1_ASAP7_75t_R    g041(.A(new_n19_), .B(new_n20_), .C(\B[7] ), .Y(new_n60_));
  OA33x2_ASAP7_75t_R   g042(.A1(new_n22_), .A2(new_n33_), .A3(new_n59_), .B1(\B[4] ), .B2(\B[6] ), .B3(new_n60_), .Y(new_n61_));
  INVx1_ASAP7_75t_R    g043(.A(new_n61_), .Y(new_n62_));
  AO32x1_ASAP7_75t_R   g044(.A1(\B[6] ), .A2(new_n33_), .A3(new_n58_), .B1(\B[3] ), .B2(new_n62_), .Y(new_n63_));
  AO32x1_ASAP7_75t_R   g045(.A1(new_n22_), .A2(\B[8] ), .A3(new_n27_), .B1(new_n25_), .B2(\B[9] ), .Y(new_n64_));
  OA211x2_ASAP7_75t_R  g046(.A1(new_n20_), .A2(\B[0] ), .B(\B[4] ), .C(new_n25_), .Y(new_n65_));
  INVx1_ASAP7_75t_R    g047(.A(new_n65_), .Y(new_n66_));
  OA21x2_ASAP7_75t_R   g048(.A1(new_n19_), .A2(new_n20_), .B(\B[0] ), .Y(new_n67_));
  AOI22x1_ASAP7_75t_R  g049(.A1(new_n20_), .A2(new_n25_), .B1(new_n22_), .B2(new_n27_), .Y(new_n68_));
  OA222x2_ASAP7_75t_R  g050(.A1(\B[1] ), .A2(new_n68_), .B1(new_n26_), .B2(\B[9] ), .C1(new_n66_), .C2(new_n67_), .Y(new_n69_));
  INVx1_ASAP7_75t_R    g051(.A(new_n69_), .Y(new_n70_));
  AO32x1_ASAP7_75t_R   g052(.A1(\B[7] ), .A2(new_n32_), .A3(new_n50_), .B1(new_n25_), .B2(\B[9] ), .Y(new_n71_));
  AO21x1_ASAP7_75t_R   g053(.A1(new_n24_), .A2(new_n70_), .B(new_n71_), .Y(new_n72_));
  AO222x2_ASAP7_75t_R  g054(.A1(\B[5] ), .A2(new_n63_), .B1(new_n24_), .B2(new_n64_), .C1(new_n23_), .C2(new_n72_), .Y(new_n73_));
  NOR2x1_ASAP7_75t_R   g055(.A(new_n24_), .B(new_n25_), .Y(new_n74_));
  INVx1_ASAP7_75t_R    g056(.A(new_n74_), .Y(new_n75_));
  AND3x1_ASAP7_75t_R   g057(.A(\B[6] ), .B(\B[7] ), .C(new_n27_), .Y(new_n76_));
  AO33x2_ASAP7_75t_R   g058(.A1(\B[6] ), .A2(new_n27_), .A3(new_n22_), .B1(\B[5] ), .B2(new_n24_), .B3(new_n19_), .Y(new_n77_));
  AO33x2_ASAP7_75t_R   g059(.A1(\B[6] ), .A2(new_n27_), .A3(new_n22_), .B1(new_n21_), .B2(\B[5] ), .B3(new_n24_), .Y(new_n78_));
  AND3x1_ASAP7_75t_R   g060(.A(\B[3] ), .B(\B[4] ), .C(\B[2] ), .Y(new_n79_));
  AO32x1_ASAP7_75t_R   g061(.A1(\B[6] ), .A2(new_n27_), .A3(new_n79_), .B1(new_n20_), .B2(new_n78_), .Y(new_n80_));
  AO21x1_ASAP7_75t_R   g062(.A1(new_n21_), .A2(new_n77_), .B(new_n80_), .Y(new_n81_));
  AO21x1_ASAP7_75t_R   g063(.A1(new_n25_), .A2(new_n81_), .B(\B[10] ), .Y(new_n82_));
  AO32x1_ASAP7_75t_R   g064(.A1(new_n26_), .A2(new_n75_), .A3(new_n82_), .B1(new_n35_), .B2(new_n76_), .Y(new_n83_));
  AOI21x1_ASAP7_75t_R  g065(.A1(new_n28_), .A2(new_n73_), .B(new_n83_), .Y(\M[1] ));
  NOR2x1_ASAP7_75t_R   g066(.A(new_n22_), .B(new_n23_), .Y(new_n85_));
  INVx1_ASAP7_75t_R    g067(.A(new_n85_), .Y(new_n86_));
  NAND2x1_ASAP7_75t_R  g068(.A(\B[6] ), .B(new_n25_), .Y(new_n87_));
  OA33x2_ASAP7_75t_R   g069(.A1(\B[6] ), .A2(new_n25_), .A3(new_n21_), .B1(new_n24_), .B2(\B[7] ), .B3(\B[2] ), .Y(new_n88_));
  OA33x2_ASAP7_75t_R   g070(.A1(new_n23_), .A2(\B[6] ), .A3(\B[1] ), .B1(\B[5] ), .B2(new_n24_), .B3(new_n20_), .Y(new_n89_));
  NAND2x1_ASAP7_75t_R  g071(.A(\B[5] ), .B(\B[6] ), .Y(new_n90_));
  AO32x1_ASAP7_75t_R   g072(.A1(new_n20_), .A2(\B[3] ), .A3(new_n24_), .B1(new_n21_), .B2(\B[5] ), .Y(new_n91_));
  NOR2x1_ASAP7_75t_R   g073(.A(new_n19_), .B(new_n29_), .Y(new_n92_));
  OAI22x1_ASAP7_75t_R  g074(.A1(\B[4] ), .A2(\B[6] ), .B1(new_n50_), .B2(new_n92_), .Y(new_n93_));
  NOR2x1_ASAP7_75t_R   g075(.A(\B[6] ), .B(new_n29_), .Y(new_n94_));
  AO33x2_ASAP7_75t_R   g076(.A1(new_n22_), .A2(\B[5] ), .A3(\B[3] ), .B1(new_n21_), .B2(\B[4] ), .B3(new_n94_), .Y(new_n95_));
  AO22x1_ASAP7_75t_R   g077(.A1(new_n23_), .A2(new_n93_), .B1(\B[1] ), .B2(new_n95_), .Y(new_n96_));
  AOI22x1_ASAP7_75t_R  g078(.A1(\B[4] ), .A2(new_n91_), .B1(\B[2] ), .B2(new_n96_), .Y(new_n97_));
  OA222x2_ASAP7_75t_R  g079(.A1(new_n50_), .A2(new_n89_), .B1(new_n49_), .B2(new_n90_), .C1(\B[7] ), .C2(new_n97_), .Y(new_n98_));
  OA222x2_ASAP7_75t_R  g080(.A1(new_n75_), .A2(new_n85_), .B1(new_n86_), .B2(new_n88_), .C1(\B[8] ), .C2(new_n98_), .Y(new_n99_));
  INVx1_ASAP7_75t_R    g081(.A(new_n99_), .Y(new_n100_));
  OR3x1_ASAP7_75t_R    g082(.A(new_n24_), .B(\B[7] ), .C(new_n86_), .Y(new_n101_));
  AOI21x1_ASAP7_75t_R  g083(.A1(new_n30_), .A2(new_n101_), .B(new_n26_), .Y(new_n102_));
  AO21x1_ASAP7_75t_R   g084(.A1(new_n27_), .A2(new_n100_), .B(new_n102_), .Y(new_n103_));
  AO21x1_ASAP7_75t_R   g085(.A1(\B[5] ), .A2(\B[7] ), .B(new_n26_), .Y(new_n104_));
  NAND2x1_ASAP7_75t_R  g086(.A(new_n28_), .B(new_n104_), .Y(new_n105_));
  AO32x1_ASAP7_75t_R   g087(.A1(\B[5] ), .A2(new_n26_), .A3(\B[9] ), .B1(\B[8] ), .B2(\B[10] ), .Y(new_n106_));
  AO222x2_ASAP7_75t_R  g088(.A1(\B[9] ), .A2(new_n105_), .B1(new_n74_), .B2(new_n106_), .C1(new_n28_), .C2(new_n103_), .Y(\M[2] ));
  NOR2x1_ASAP7_75t_R   g089(.A(\B[9] ), .B(\B[10] ), .Y(new_n108_));
  NOR2x1_ASAP7_75t_R   g090(.A(\B[5] ), .B(\B[6] ), .Y(new_n109_));
  AND5x1_ASAP7_75t_R   g091(.A(new_n22_), .B(new_n25_), .C(new_n26_), .D(new_n23_), .E(new_n24_), .Y(new_n110_));
  AND3x1_ASAP7_75t_R   g092(.A(\B[5] ), .B(\B[6] ), .C(\B[7] ), .Y(new_n111_));
  AND3x1_ASAP7_75t_R   g093(.A(new_n20_), .B(new_n41_), .C(new_n111_), .Y(new_n112_));
  OA211x2_ASAP7_75t_R  g094(.A1(new_n110_), .A2(new_n112_), .B(new_n21_), .C(new_n108_), .Y(new_n113_));
  INVx1_ASAP7_75t_R    g095(.A(new_n113_), .Y(\M[3] ));
  AO21x1_ASAP7_75t_R   g096(.A1(new_n60_), .A2(new_n90_), .B(new_n21_), .Y(new_n115_));
  NAND2x1_ASAP7_75t_R  g097(.A(new_n23_), .B(new_n25_), .Y(new_n116_));
  AO21x1_ASAP7_75t_R   g098(.A1(new_n115_), .A2(new_n116_), .B(new_n22_), .Y(new_n117_));
  AO32x1_ASAP7_75t_R   g099(.A1(\B[6] ), .A2(new_n25_), .A3(new_n85_), .B1(new_n92_), .B2(new_n109_), .Y(new_n118_));
  AO32x1_ASAP7_75t_R   g100(.A1(\B[2] ), .A2(\B[3] ), .A3(new_n118_), .B1(new_n87_), .B2(new_n117_), .Y(new_n119_));
  OR3x1_ASAP7_75t_R    g101(.A(new_n25_), .B(new_n90_), .C(new_n26_), .Y(new_n120_));
  AO22x1_ASAP7_75t_R   g102(.A1(\B[2] ), .A2(new_n21_), .B1(\B[3] ), .B2(\B[8] ), .Y(new_n121_));
  AO32x1_ASAP7_75t_R   g103(.A1(new_n76_), .A2(new_n85_), .A3(new_n121_), .B1(\B[9] ), .B2(new_n120_), .Y(new_n122_));
  AO21x1_ASAP7_75t_R   g104(.A1(new_n26_), .A2(new_n119_), .B(new_n122_), .Y(new_n123_));
  NAND2x1_ASAP7_75t_R  g105(.A(new_n28_), .B(new_n123_), .Y(\E[0] ));
  AND3x1_ASAP7_75t_R   g106(.A(\B[5] ), .B(\B[6] ), .C(new_n79_), .Y(new_n125_));
  OR4x2_ASAP7_75t_R    g107(.A(\B[7] ), .B(\B[8] ), .C(new_n109_), .D(new_n125_), .Y(new_n126_));
  AND3x1_ASAP7_75t_R   g108(.A(\B[3] ), .B(new_n26_), .C(new_n92_), .Y(new_n127_));
  AO32x1_ASAP7_75t_R   g109(.A1(new_n23_), .A2(new_n25_), .A3(new_n127_), .B1(\B[8] ), .B2(new_n111_), .Y(new_n128_));
  AO32x1_ASAP7_75t_R   g110(.A1(\B[3] ), .A2(\B[8] ), .A3(new_n111_), .B1(\B[2] ), .B2(new_n128_), .Y(new_n129_));
  INVx1_ASAP7_75t_R    g111(.A(new_n129_), .Y(new_n130_));
  OA211x2_ASAP7_75t_R  g112(.A1(new_n22_), .A2(new_n130_), .B(new_n108_), .C(new_n126_), .Y(new_n131_));
  INVx1_ASAP7_75t_R    g113(.A(new_n131_), .Y(\E[1] ));
  OR5x1_ASAP7_75t_R    g114(.A(\B[7] ), .B(\B[8] ), .C(\B[9] ), .D(\B[10] ), .E(new_n125_), .Y(\E[2] ));
endmodule


