# V16 exact physical-area rejection filter

{
  "studies": {
    "full": {
      "campaign": "/home/flynn/workplace/MIGBalance/results_v2/delta_area_full_20261016/campaign.json",
      "campaign_sha256": "8ab7d2f3450829b9c2a34addd100b65fabc97af5978dc7409dec9f7ba00a0292",
      "attempts": 80,
      "CEC": 68,
      "failures": 12
    },
    "repeats": {
      "campaign": "/home/flynn/workplace/MIGBalance/results_v2/delta_area_repeats_20261016/campaign.json",
      "campaign_sha256": "1ab08b6417d6b7062db6373eb3f1e96d3978034165f576015c7b6a65967baec9",
      "attempts": 24,
      "CEC": 24,
      "failures": 0
    }
  },
  "full": {
    "area": {
      "better": 2,
      "equal": 31,
      "worse": 1
    },
    "delay": {
      "better": 0,
      "equal": 34,
      "worse": 0
    }
  },
  "targeted_repeats": {
    "area": {
      "better": 1,
      "equal": 8,
      "worse": 3
    },
    "delay": {
      "better": 0,
      "equal": 12,
      "worse": 0
    }
  },
  "main_common_legal": {
    "area": {
      "better": 3,
      "equal": 20,
      "worse": 11
    },
    "delay": {
      "better": 14,
      "equal": 20,
      "worse": 0
    }
  },
  "baseline_gates": [
    false,
    false,
    false,
    false,
    false,
    false
  ],
  "promoted": false,
  "reason": "Full physical timing acceptance unchanged. Local filter correctness and targeted repetitions do not establish overall baseline dominance or solve failed imports. Source proof study is a separate version, not merged."
}

Every failed attempt retained. Same prepared inputs, libraries, actual 20k egraph nodes, cuts16, pool100k, SAT16 and inclusive2s recovery; native60 and mapping300 guards unchanged. CEC and public evaluator excluded from mapping clock. Six gates include full20 missing/failures; area-delay is posthoc. Baseline algorithms untouched; main not promoted. Repeated sqrt observations are targeted, not a full-suite replication. Proof-source V17 is independent.

The source-only V17 study is independent from V16.16attempts,4priority mappedCEC and12actual node failures. A bounded exact signed ROBDD finds112div aliases and releases121rawANDs; no alias gains for hyp/mem_ctrl. The4in source-plan count20435->20373 and3in20612->20545 remain over the actual total allowance after PI/constant/PO accounting. RawAND/source estimates are not egraph imports, mapped PPA, lower bounds or impossibility proofs. All real big-design imports still stop at20000admitted nodes. All original PI/PO names survive.3fullsource replay CECs and4positive/negative/phase calibrations pass independently; a further diagnostic post-alias structural cleanup passes div source CEC and removes16additional rawANDs, but is NOT integrated into the mapped version and is not evidence of budgeted physical feasibility. Diagnostic artifacts are not fed to the mapper. The temporary BDD state is capped4095nonterminal decisions/20000calls/.2s search checkpoints, not a hard whole-stage .2s cap; clone/rewire/scan charged to original native60/mapping300. Retained physical100k does not bound generated transient RAM.

FullV16sqrt areas2248.34/2153.71 at47047.28/60087.26 remain about43.9%/30.9%above same-library emap1562.46/1644.87. New filter does not establish stable reduction: four sqrt repeat pairs have one gain, one tie and two losses, all delay ties. Across all12targeted pairs,area1better8equal3worse. Priority4in repeat one tie/one+0.01loss;bar four ties. Compared with production main34common legal covers,D14better20equal,area3better20equal11worse, all11area costs accompany lower delay; no universal Pareto or baseline win. All six complete-scope baseline gates false; MtM unconnected. Earlier13403file baseline audit is referenced, not relabeled as a fresh audit. Original baseline520status slots372CEC124reportedfail24unmeasured retained, no original algorithm/model/parameter changes.

Total this round120fresh physical-mapping attempts/96direct original named-portCEC/24nodefailures across THREE separate studies, not a mixed portfolio. Source diagnostics and calibration verdicts are excluded from mapping coverage. Main source/defaults/native8f6 unchanged, no promotion. The whole-crate test command was interrupted130 on three unchanged slow synthesis tests; relevant97egraph+2proof tests pass and raw logs are retained. V16 relevant114tests pass/5ignored. Next substantive area work is actual sparse transactions with safe arrival increases/required tightening, not just a rejection bound; see incremental_transaction_next.md. Source work next should refine exact proof selection under the original global clocks; post-cleanup counts must not be subtracted from e-node estimates as a feasibility proof.

Final publication QA: delta_area_paper_20261016/paper_qa.json confirms6body+1references, standard preamble/fonts/margins and four reference tables unchanged. Pages4/5/6 visually checked,1/2/3/7 pixel-identical to prior validated pages.8page draft retained; prose shortened only. Published output/pdf/DAC-eGraphMap-draft.pdf, project PDFsameSHA. All finite native/source-audit/build/render sessions finished,9relevant runner locks idle, main/source/defaults/bin8f6unchanged; no promotion.
