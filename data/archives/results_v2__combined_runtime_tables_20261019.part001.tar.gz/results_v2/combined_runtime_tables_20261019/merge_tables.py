import json,re,hashlib,math,csv
from pathlib import Path
root=Path('/home/flynn/workplace/MIGBalance');out=root/'results_v2/combined_runtime_tables_20261019';src=root/'epmapping_paper/DAC-eGraphMap-draft/main.tex';text=(out/'before.tex').read_text()
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
block=text.split('% BEGIN EPFL COMPLETE TABLES')[1].split('% END EPFL COMPLETE TABLES')[0]
tables=re.findall(r'\\begin\{table\*\}.*?\\end\{table\*\}',block,re.S);assert len(tables)==4
old=[]
for t in tables:
 rows={}
 for line in t.splitlines():
  if ' & ' in line and not line.startswith('Design'):
   bits=[x.strip() for x in line.split(' & ')];rows[bits[0]]= [x.replace('\\\\','').strip() for x in bits[1:]]
 old.append(rows)
methods=['abc_map_delay_resyn2','mockturtle_emap_delay_resyn2','eqmap_lut_amap','esyn_frozen_model_amap_bounded_dag','emorphic_final_sa','B','X']
profiles=json.loads((root/'results_v2/protected_recovery_paper_20261019/table_sources.json').read_text())['records'];records=[];new=[]
for k in (3,4):
 basefile=root/f'results_v2/guarded_joint_evidence_20261016/baseline_scope/baselines_{k}in.json';baseline=json.loads(basefile.read_text())['results'];aa,dd=old[(k-3)*2:(k-3)*2+2];times={}
 for design in aa:
  bench=design.replace('\\_','_');times[design]=[]
  for idx,method in enumerate(methods):
   area,delay=aa[design][idx],dd[design][idx];rec={'k':k,'design':bench,'method':method,'area_cell':area,'delay_cell':delay}
   if area in ('F','N'):
    times[design].append('--');rec.update(runtime_cell='--',note='no validated PPA result; runtime not tabulated')
   else:
    if method in ('B','X'):
     r=next(x for x in profiles if x['k']==k and x['design']==bench and x['profile']==method);report=Path(r['report']);m=r
    else:
     rs=[r for r in baseline if r['bench']==bench and r['method']==method and r.get('source_objective') in (None,'delay-area')];assert len(rs)==1,(k,bench,method,len(rs));r=rs[0];report=Path(r['observation_report']);assert sha(report)==r['observation_report_sha256'];m=r['measured']
    assert f"{m['area']:.2f}"==area and f"{m['delay']:.2f}"==delay,(k,bench,method,area,delay,m)
    audit=report.parent.with_suffix('.audit.json')
    if not audit.exists():
     replay=r['verification_replay']; mapped=Path(replay['after_argv'][3]);audit=mapped.parent.parent.with_suffix('.audit.json');assert audit.exists()
    a=json.loads(audit.read_text());statekey=bench+'/'+('egraph_staged_control_resyn2' if method in ('B','X') else method);s=a['states'][statekey];seconds=s['mapping_wall_secs'];assert not s['exhausted']
    upper=method in ('B','X','eqmap_lut_amap')
    if method=='eqmap_lut_amap':
     enclosing=[c['wall_secs'] for st in a['states'].values() for c in st['commands'] if Path(c['argv'][0]).name=='yosys' and 'abc -lut' in ' '.join(c['argv'])];assert enclosing;seconds+=sum(enclosing);assert abs(seconds-r['mapping_budget_upper_bound_secs'])<1e-6
    assert 0<seconds<=300
    cell=(r'$\leq$'+f'{math.ceil(seconds*100)/100:.2f}') if upper else f'{seconds:.2f}'
    times[design].append(cell);rec.update(runtime_cell=cell,mapping_wall_secs=seconds,upper_bound=upper,report=str(report),report_sha256=sha(report),audit=str(audit),audit_sha256=sha(audit),state=statekey,note='EqMap includes enclosing initial LUT-stage upper bound' if method=='eqmap_lut_amap' else 'mapper-process upper bound includes internal diagnostics' if method in ('B','X') else 'mapping-clock wall time; E-morphic uses nested active-interval union')
   records.append(rec)
 lines=[r'\begin{table*}[!t]\centering\small',r'\setlength{\tabcolsep}{5pt}',r'\renewcommand{\arraystretch}{0.96}',r'\caption{EPFL '+str(k)+r'-input inventory: area (A), unloaded block delay (D), and mapping runtime in seconds (T). $\leq$ denotes a conservative upper bound; -- denotes unavailable runtime. Fixed delay-oriented profiles; F/N retain failure/node-rejection status.}',r'\label{tab:epfl'+str(k)+r'area}\label{tab:epfl'+str(k)+r'delay}',r'\begin{tabular}{llrrrrrrr}\toprule',r'Design & Metric & ABC map & emap & EqMap & E-Syn & E-morphic & B & X \\ \midrule']
 for i,design in enumerate(aa):
  for metric,values in [('A',aa[design]),('D',dd[design]),('T',times[design])]:lines.append((design if metric=='A' else '')+' & '+metric+' & '+' & '.join(values)+r' \\')
  if i<len(aa)-1:lines.append(r'\addlinespace[1pt]')
 lines.append(r'\bottomrule\end{tabular}\end{table*}');new.append('\n'.join(lines))
text=text.replace(block,'\n'+'\n\n'.join(new)+'\n')
text=text.replace('Tables~\\ref{tab:epfl3area}--\\ref{tab:epfl4delay} separate area and delay\nfor fixed delay-oriented profiles:', 'Tables~\\ref{tab:epfl3area} and~\\ref{tab:epfl4area} combine area, delay\nand mapping runtime for fixed delay-oriented profiles:')
text=text.replace('no isolated runtime speedup is claimed.', 'Tables report mapping-clock wall time, excluding external preparation,\nCEC and evaluation. EqMap and B/X use conservative bounds, rounded up\nto 0.01 seconds: EqMap includes the enclosing initial LUT stage; B/X\ninclude internal diagnostic output. Failed or unmeasured PPA records\nhave no tabulated runtime. These bounds do not establish isolated\nmapping-algorithm speedups.')
src.write_text(text);(out/'runtime_sources.json').write_text(json.dumps({'records':records,'before_sha256':sha(out/'before.tex'),'source_sha256':sha(src),'ppa_cells_unchanged':True,'baseline_algorithms_changed':False},indent=2));print('verified PPA records',len(records),'timed',sum('mapping_wall_secs' in r for r in records))
