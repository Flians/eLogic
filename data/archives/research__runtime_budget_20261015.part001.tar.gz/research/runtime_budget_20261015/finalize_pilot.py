"""Re-audit immutable pilot outputs and summarize measured work and runtime."""
import hashlib
import json
from pathlib import Path
import re
import shutil
import sys

ROOT = Path(__file__).resolve().parents[2]
P = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'scripts/experiments'))
from audit_mapped_ppa import audit

sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
inputs = ROOT / 'results_v20_three_parts_chain/inputs'
rows = []
for f in sorted((P / 'runs').glob('*/result.json')):
    wd = f.parent
    r = json.loads(f.read_text())
    manifest = json.loads((wd / 'manifest.json').read_text())
    assert sha(manifest['command'][0]) == r['binary_sha256'] == manifest['binary_sha256']
    for name, digest in manifest['input_sha256'].items(): assert sha(inputs / name) == digest
    text = (wd / 'log').read_text()
    assert sha(wd / 'log') == r['log_sha256']
    assert 'post_mapping_timeout=1000 seconds' in text
    assert 'area_under_delay=1,' in text and f"max_rounds={r.get('rounds',6)}," in text
    assert manifest['env']['EPMAPPING_WINDOW_SYN'] == '0'
    assert manifest['env']['EPMAPPING_DSE'] == '0'
    reference = ROOT / 'results_v26_three_parts_cofactor_shared/cold/tab_main' / f"ae.{r['design']}" / 'epmapping_baseline.v'
    assert sha(wd / 'epmapping_baseline.v') == sha(reference) == r['baseline_sha256']
    if r['status'] == 'complete':
        assert '[i] cec=1' in text and 'window_synth windows=0 applied=0' in text
        selected = wd / 'epmapping_mapped.v'
    else:
        meta = json.loads((wd / 'checkpoint_selection.json').read_text())
        assert meta['status'] == 'optimizer_timeout' and meta['cec'] == 1
        assert sha(wd / 'checkpoint_cec.log') == meta['proof_sha256']
        assert 'Networks are equivalent' in (wd / 'checkpoint_cec.log').read_text()
        selected = wd / meta['checkpoint']['netlist']
    assert sha(selected) == r['netlist_sha256']
    initial = audit(wd / 'epmapping_baseline.v', inputs / 'asap7.genlib')
    measured = audit(selected, inputs / 'asap7.genlib')
    assert measured['area'] <= initial['area'] + .0001 and measured['delay'] <= initial['delay'] + .001
    assert abs(measured['area'] - r['area']) < .0001 and abs(measured['delay'] - r['delay']) < .001
    assert measured['serialized_area'] <= initial['serialized_area'] + .0001
    assert measured['serialized_delay'] <= initial['serialized_delay'] + .001
    r['version'] = r.get('version', 'candidate')
    proof = re.findall(r'cofactor_proofs=(\d+)', text)
    if proof: r['counters']['proofs'] = int(proof[-1])
    r['run'] = wd.name
    rows.append(r)

required = {(d, a, m) for d in ['usb_phy', 'arbiter', 'tv80'] for a in ['exact', 'cache64'] for m in ['cold', 'warm']}
found = {(r['design'], r['arm'], r['mode']) for r in rows if r['version'] == 'anytime'}
assert required <= found, f'final validation cohort incomplete: {required-found}'
validation = json.loads((P / 'final_validation.json').read_text())
assert len(validation) == 6 and all(r['returncode'] == 0 for r in validation)
lines = ['Runtime-budget optimization pilot — verified results', '',
 'Original inputs and initial mapping unchanged; fixed original delay bound; window synthesis OFF;',
 'native post-mapping 1000 s, six rounds. Native completions and recovered timeouts remain distinct.',
 'Single shared-host observations, not statistical speedup estimates. Some small probes overlap regression tests.', '',
 'run                                      area      delay     post(s)    cofactor builds / covers / proofs / duplicates']
for r in rows:
    c = r['counters'].get('cofactor', {})
    lines.append(f"{r['run']:38s} {r['area']:9.2f} {r['delay']:9.2f} {r['optimizer_seconds']:10.3f} "
                 f"{c.get('builds','NA')} / {c.get('covers','NA')} / {r['counters'].get('proofs','NA')} / {r['counters'].get('duplicates','NA')}")
lines += ['', 'Final anytime build compared with same-session old probes where available:']
for d in ['usb_phy', 'arbiter', 'tv80']:
    for mode in ['cold', 'warm']:
        old = next((r for r in rows if r['version']=='candidate' and r['arm']=='old' and r['design']==d and r['mode']==mode), None)
        for arm in ['exact', 'cache64']:
            new = next(r for r in rows if r['version']=='anytime' and r['arm']==arm and r['design']==d and r['mode']==mode)
            if old:
                lines.append(f"{d} {arm} {mode}: area difference {new['area']-old['area']:+.4f}; delay difference {new['delay']-old['delay']:+.4f}; observed runtime reduction {100*(1-new['optimizer_seconds']/old['optimizer_seconds']):.2f}%")
            elif d == 'tv80':
                import csv
                reference = list(csv.DictReader((ROOT/'results_v26_three_parts_cofactor_shared/paired_results.tsv').open(),delimiter='\t'))
                previous = next(r for r in reference if r['part']=='tab_main' and r['arm']=='ae' and r['design']==d and r['mode']==mode)
                lines.append(f"tv80 {arm} {mode}: archived v26 post {float(previous['optimizer_seconds']):.3f} s; current {new['optimizer_seconds']:.3f} s; different batches, not a controlled timing pair; area difference {new['area']-float(previous['area']):+.4f}; delay difference {new['delay']-float(previous['delay']):+.4f}")
lines += ['', 'Rejected fixed pivot budgets: usb_phy pivot1 area 22.28, pivot2 area 21.39 versus full 21.38.',
          'pivot3 retained usb_phy area/delay but remains opt-in; it is not validated globally.',
          'All final cohort selections pass independent area/delay audits and CEC. The paper and v26 results are unchanged.',
          'The native cache capacity default remains 8192; cache64 is a separate 65536-entry experiment.',
          'Native memos are not persistent. Warm means e-graph persistent-pool reuse only.',
          'These changes reduce repeated work; they do not establish a lower asymptotic complexity than mfs3.',
          'No new full-cohort mfs3 or three-part paper comparison is claimed by this pilot.']
(P/'verified_results.json').write_text(json.dumps(rows,indent=2)+'\n')
(P/'RESULTS.txt').write_text('\n'.join(lines)+'\n')
for rel in ['epmapping/README.md', 'scripts/experiments/run_three_parts.py',
            'scripts/experiments/recover_checkpoint.py', 'scripts/experiments/timeout_selection.py',
            'scripts/experiments/report_three_parts.py', 'scripts/experiments/report_three_parts_profiles.py',
            'scripts/experiments/tests/test_anytime_checkpoint.py',
            'scripts/experiments/tests/test_post_timeout.py',
            'scripts/experiments/tests/test_operator_policy.cpp',
            'scripts/experiments/tests/test_bounded_cache.cpp']:
    dest=P/'pipeline_sources'/rel;dest.parent.mkdir(parents=True,exist_ok=True)
    shutil.copy2(ROOT/rel,dest)
print('\n'.join(lines),flush=True)
files = [f for f in P.rglob('*') if f.is_file() and '__pycache__' not in f.parts and f.name!='delivery_manifest.json']
(P/'delivery_manifest.json').write_text(json.dumps({str(f.relative_to(P)):sha(f) for f in sorted(files)},indent=2)+'\n')
