"""Audit operator ledgers and compare the opt-in scheduler with full search."""
import json
from pathlib import Path
import re

P=Path(__file__).resolve().parent
rows=[]
for file in sorted((P/'runs').glob('policy*/*result.json')):
    row=json.loads(file.read_text())
    records=[]
    for line in file.with_name('log').read_text().splitlines():
        if '[i] operator_policy ' not in line:continue
        record=dict(re.findall(r'(\w+)=([^ ]+)',line))
        for key in ['calls','build_requests','cache_hits','skipped','proposals','committed','delay_rejects','area_rejects','bucket']:
            record[key]=int(record[key])
        for key in ['seconds','build_seconds','credited_area']:record[key]=float(record[key])
        assert record['calls']==record['build_requests']+record['cache_hits']+record['skipped']
        assert record['committed']<=record['proposals']
        assert record['build_seconds']<=record['seconds']+.0001
        assert record['credited_area']>=0
        records.append(record)
    assert records and row['cec']==1
    assert sum(r['credited_area'] for r in records)<=row['initial_area']-row['area']+.0001
    aggregate={}
    for record in records:
        source=record['source'];aggregate.setdefault(source,{k:0 for k in record if k not in ['source','bucket']})
        for key in aggregate[source]:aggregate[source][key]+=record[key]
    rows.append(dict(**row,run=file.parent.name,operator_records=records,operator_totals=aggregate))
required={(d,m) for d in ['usb_phy','arbiter','tv80'] for m in ['cold','warm']}
assert required<={(r['design'],r['mode']) for r in rows if r['version']=='policy_v2'},'scheduler cohort incomplete'
lines=['Operator-trigger policy pilot — opt-in, not the default', '',
       'Original inputs, fixed original delay bound, six-round cap, no whole-window synthesis,',
       'post-mapping 1000 s, 65536-entry native caches for both comparison configurations.',
       'Single shared-host observations; runtime ratios are not statistical speedups.',
       'Full-search references are the frozen anytime/cache64 runs; small designs also have',
       'same-generation profiling/full-search controls in policy/.', '',
       'design       mode     full(s)  policy(s)  delta time     area full/policy      delay full/policy']
for design in ['usb_phy','arbiter','tv80']:
    for mode in ['cold','warm']:
        row=next(r for r in rows if r['version']=='policy_v2' and r['design']==design and r['mode']==mode)
        old=json.loads((P/'runs'/f'anytime.cache64.{mode}.{design}'/'result.json').read_text())
        lines.append(f"{design:12s} {mode:5s} {old['optimizer_seconds']:10.3f} {row['optimizer_seconds']:10.3f} "
                     f"{100*(row['optimizer_seconds']/old['optimizer_seconds']-1):+9.2f}%   "
                     f"{old['area']:.2f}/{row['area']:.2f}             {old['delay']:.2f}/{row['delay']:.2f}")
        lines.append('  '+', '.join(f"{source}: deferred {stat['skipped']}, build {stat['build_seconds']:.3f}s, total {stat['seconds']:.3f}s, committed {stat['committed']}" for source,stat in row['operator_totals'].items()))
lines+=['', 'Credits allocate bounded globally validated round gain; they are not causal operator ablations.',
        'Profiles group SOP/DSD. E-graph is measured but keeps its existing fallback trigger.',
        'Cache hits are not throttled. Strong structures and one-in-sixteen uncached exploration remain.',
        'The first prototype used all calls for exploration; policy_v2 fixes cache-traffic starvation.',
        'Scheduling can change greedy choices and downstream fallback work. Do not infer uniform wins.',
        'Experimental mode remains OFF by default. Paper/v26 data have not been replaced.']
(P/'verified_policy.json').write_text(json.dumps(rows,indent=2)+'\n')
(P/'POLICY_RESULTS.txt').write_text('\n'.join(lines)+'\n')
print('\n'.join(lines))
