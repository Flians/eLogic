Runtime-budget optimization pilot

The v26 paper and published raw experiments are immutable in this pilot.
Original v20 AIGs, original high-effort ABC preprocessing, original full library,
and byte-identical v26 initial netlists are required. Fixed original output-delay
bound, area-first optimization, no whole-window synthesis, no DSE, six-round cap,
and native post-mapping 1000-second SIGALRM remain in effect. A separate outer
3600-second process guard includes preprocessing and validation; it never extends
the post-mapping limit. CEC and independent mapped-area/pin-delay audit are required.

before/ contains the pre-change native sources and executable. candidate/ freezes
the first modified executable (LRU, DAG deduplication, round-boundary checkpoints).
anytime/ freezes the final executable (in-round checkpoints and structural proofs).
run_pilot.py --version anytime selects the final implementation; the default
version candidate retains the first-stage pilot for provenance. Per-run manifests
record binary, inputs and effective knobs. Runs are sequential within the pilot;
this is a shared host and individual time ratios are observations, not statistical
speedup estimates. Regression tests may overlap the first usb_phy probes.

Changes:
- A bounded LRU memo replaces the old stop-inserting-when-full policy for native
  synthesis and cofactor structures. EPMAPPING_CACHE_REPLACE=0 restores the old
  insertion policy. Failed synthesis is cached too. Entry capacity stays 8192.
- Cached cofactor structures are immutable shared objects. Exact mapped DAG/pin/
  polarity encodings identify duplicates within a cut before copying, live pricing
  and equivalence checks. EPMAPPING_COFAC_DEDUP=0 disables suppression. The first
  occurrence is preserved, so candidate order among unique structures is unchanged.
- EPMAPPING_COFAC_PIVOTS=N optionally keeps N pivots per decomposition family,
  ranked by cofactor/Boolean-difference support size. Retained pivots retain their
  original relative order. Zero remains exhaustive and is the executable default.
  Budgeting is a heuristic search restriction and must be quality-validated.
- EPMAPPING_CHECKPOINT=1 (default) atomically publishes an initial checkpoint and
  every strictly better globally legal round boundary. Metadata is committed last;
  filenames are immutable within a process. All writing is synchronous within the
  post-mapping budget; no unsafe signal handler writes. It does not yet checkpoint
  an incomplete first round in the initial candidate build. The final anytime build
  also saves globally checked in-round progress every 30 seconds after a replacement,
  retaining an independent deep snapshot. SIGALRM remains a timeout.
- recover_checkpoint.py independently audits the selected netlist and runs ABC CEC
  after a native optimizer SIGALRM. It records checkpoint_selection.json, including
  hashes and timeout status. Validation is outside the search budget. The old paper
  runner/reporting initial-fallback protocol is not silently reinterpreted.
  New three-part runs can explicitly choose --timeout-selection checkpoint; this
  freezes the selection policy in their manifest. Existing manifests default to
  initial fallback. Auditors distinguish validated checkpoints from initial nets
  while retaining the native timeout classification and raw row/log hashes.

Arms: old = before binary; exact = modified exhaustive search; pivot1/2/3 = modified
budgeted search. Cold starts a private empty e-graph pool; warm reuses only that
arm/design pool in a fresh process. Native structural memos restart in each mode.
Warm cofactor synthesis is not claimed to be persistent. Native persistent caching
and NPN/input-permutation canonicalization are not implemented in this pilot.

The final anytime build additionally caches full-function structural proofs per
immutable cofactor entry (same ordered truth table and fixed library). Live pricing
and accepted-replacement validation remain. Objective comparisons for snapshot
selection use the same area 1e-4 / delay 1e-3 quantization as the existing guards.

Evidence: run_pilot.py, runs/*/{manifest,log,result}.json (log has no suffix),
results.json, checkpoint_regression*.log, cofactor_regression.log and build*.log.

Development logs are retained. checkpoint_initial.log contains an obsolete byte-
identity assertion between differently ordered canonical rebuilds; the corrected
test audits physical area/delay and CEC. final_validation.json and the final
pipeline/outer-alarm regression logs identify the passing completion checks.
