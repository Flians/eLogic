// Benchmark "/tmp/" written by ABC on Tue Oct 13 13:02:38 2026

module \/tmp/  ( 
    p3, p7, p6, p8, p2, p9, p1, p5, p0, p4,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10  );
  input  p3, p7, p6, p8, p2, p9, p1, p5, p0, p4;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10;
  wire new_n22_, new_n23_, new_n24_, new_n25_, new_n26_, new_n27_, new_n28_,
    new_n29_, new_n30_, new_n31_, new_n32_, new_n33_, new_n34_, new_n35_,
    new_n36_, new_n37_, new_n38_, new_n39_, new_n40_, new_n41_, new_n42_,
    new_n43_, new_n44_, new_n45_, new_n46_, new_n47_, new_n48_, new_n49_,
    new_n50_, new_n51_, new_n52_, new_n53_, new_n54_, new_n55_, new_n56_,
    new_n57_, new_n58_, new_n59_, new_n60_, new_n61_, new_n62_, new_n63_,
    new_n64_, new_n65_, new_n66_, new_n67_, new_n68_, new_n69_, new_n70_,
    new_n71_, new_n72_, new_n73_, new_n74_, new_n75_, new_n76_, new_n77_,
    new_n78_, new_n79_, new_n80_, new_n81_, new_n82_, new_n83_, new_n84_,
    new_n85_, new_n86_, new_n87_, new_n88_, new_n89_, new_n90_, new_n91_,
    new_n92_, new_n93_, new_n94_, new_n95_, new_n96_, new_n97_, new_n98_,
    new_n99_, new_n100_, new_n101_, new_n102_, new_n103_, new_n104_,
    new_n105_, new_n106_, new_n107_, new_n108_, new_n109_, new_n110_,
    new_n111_, new_n112_, new_n113_, new_n114_, new_n115_, new_n116_,
    new_n117_, new_n118_, new_n119_, new_n120_, new_n121_, new_n122_,
    new_n124_, new_n125_, new_n126_, new_n127_, new_n128_, new_n129_,
    new_n130_, new_n131_, new_n132_, new_n133_, new_n134_, new_n135_,
    new_n136_, new_n137_, new_n138_, new_n139_, new_n140_, new_n141_,
    new_n142_, new_n143_, new_n144_, new_n145_, new_n146_, new_n147_,
    new_n148_, new_n149_, new_n150_, new_n151_, new_n152_, new_n153_,
    new_n154_, new_n155_, new_n156_, new_n157_, new_n158_, new_n159_,
    new_n160_, new_n161_, new_n162_, new_n163_, new_n164_, new_n165_,
    new_n166_, new_n167_, new_n168_, new_n169_, new_n170_, new_n171_,
    new_n172_, new_n173_, new_n174_, new_n175_, new_n176_, new_n177_,
    new_n178_, new_n179_, new_n180_, new_n181_, new_n182_, new_n183_,
    new_n184_, new_n185_, new_n186_, new_n187_, new_n188_, new_n189_,
    new_n190_, new_n191_, new_n192_, new_n193_, new_n194_, new_n195_,
    new_n196_, new_n197_, new_n198_, new_n199_, new_n200_, new_n201_,
    new_n202_, new_n204_, new_n205_, new_n206_, new_n207_, new_n208_,
    new_n209_, new_n210_, new_n211_, new_n212_, new_n213_, new_n214_,
    new_n215_, new_n216_, new_n217_, new_n218_, new_n219_, new_n220_,
    new_n221_, new_n222_, new_n223_, new_n224_, new_n225_, new_n226_,
    new_n227_, new_n228_, new_n229_, new_n230_, new_n231_, new_n232_,
    new_n233_, new_n234_, new_n235_, new_n236_, new_n237_, new_n238_,
    new_n239_, new_n240_, new_n241_, new_n242_, new_n243_, new_n244_,
    new_n245_, new_n246_, new_n247_, new_n248_, new_n249_, new_n250_,
    new_n251_, new_n252_, new_n253_, new_n254_, new_n255_, new_n256_,
    new_n257_, new_n258_, new_n259_, new_n260_, new_n262_, new_n263_,
    new_n264_, new_n265_, new_n266_, new_n267_, new_n268_, new_n269_,
    new_n270_, new_n271_, new_n272_, new_n273_, new_n274_, new_n275_,
    new_n276_, new_n277_, new_n278_, new_n279_, new_n280_, new_n281_,
    new_n282_, new_n283_, new_n284_, new_n285_, new_n286_, new_n287_,
    new_n288_, new_n289_, new_n290_, new_n291_, new_n292_, new_n293_,
    new_n294_, new_n295_, new_n296_, new_n297_, new_n298_, new_n299_,
    new_n301_, new_n302_, new_n303_, new_n304_, new_n305_, new_n306_,
    new_n308_, new_n309_, new_n311_, new_n312_, new_n313_, new_n314_,
    new_n315_, new_n316_, new_n317_, new_n318_, new_n319_, new_n320_,
    new_n321_, new_n322_, new_n323_, new_n324_, new_n325_, new_n326_,
    new_n327_, new_n328_, new_n329_, new_n330_, new_n331_, new_n332_,
    new_n333_, new_n334_, new_n335_, new_n336_, new_n337_, new_n338_,
    new_n339_, new_n340_, new_n341_, new_n342_, new_n343_, new_n344_,
    new_n345_, new_n346_, new_n347_, new_n348_, new_n349_, new_n350_,
    new_n351_, new_n352_, new_n353_, new_n354_, new_n355_, new_n356_,
    new_n357_, new_n358_, new_n360_, new_n361_, new_n362_, new_n363_,
    new_n364_, new_n365_, new_n366_, new_n367_, new_n368_, new_n369_,
    new_n370_, new_n371_, new_n372_, new_n373_, new_n374_, new_n375_,
    new_n376_, new_n377_, new_n378_, new_n379_, new_n380_, new_n381_,
    new_n382_, new_n383_, new_n384_, new_n385_, new_n386_, new_n387_,
    new_n388_, new_n389_, new_n390_, new_n391_, new_n392_, new_n393_,
    new_n394_, new_n395_, new_n396_, new_n397_, new_n398_, new_n399_,
    new_n400_, new_n401_, new_n402_, new_n403_, new_n404_, new_n405_,
    new_n406_, new_n407_, new_n408_, new_n409_, new_n410_, new_n411_,
    new_n413_, new_n414_, new_n415_, new_n416_, new_n417_, new_n418_,
    new_n419_, new_n420_, new_n421_, new_n422_, new_n423_, new_n424_,
    new_n425_, new_n426_, new_n427_, new_n428_, new_n429_, new_n430_,
    new_n431_, new_n432_, new_n433_, new_n434_, new_n435_, new_n436_,
    new_n437_, new_n438_, new_n439_, new_n440_, new_n441_, new_n442_,
    new_n443_, new_n444_, new_n445_, new_n446_, new_n447_, new_n448_,
    new_n449_, new_n450_, new_n451_, new_n453_, new_n454_, new_n455_,
    new_n456_, new_n457_, new_n458_, new_n459_, new_n460_, new_n461_,
    new_n462_, new_n463_, new_n464_, new_n465_, new_n466_, new_n467_,
    new_n468_, new_n469_, new_n470_, new_n471_, new_n472_, new_n474_,
    new_n475_, new_n476_, new_n477_;
  INVx1_ASAP7_75t_R   g000(.A(p0), .Y(new_n22_));
  NOR2x1_ASAP7_75t_R  g001(.A(p7), .B(new_n22_), .Y(new_n23_));
  NAND2x1_ASAP7_75t_R g002(.A(p8), .B(new_n22_), .Y(new_n24_));
  INVx1_ASAP7_75t_R   g003(.A(p2), .Y(new_n25_));
  NAND2x1_ASAP7_75t_R g004(.A(p1), .B(new_n25_), .Y(new_n26_));
  NOR2x1_ASAP7_75t_R  g005(.A(new_n24_), .B(new_n26_), .Y(new_n27_));
  INVx1_ASAP7_75t_R   g006(.A(p9), .Y(new_n28_));
  OA21x2_ASAP7_75t_R  g007(.A1(new_n23_), .A2(new_n27_), .B(new_n28_), .Y(new_n29_));
  NAND2x1_ASAP7_75t_R g008(.A(p8), .B(p1), .Y(new_n30_));
  INVx1_ASAP7_75t_R   g009(.A(new_n30_), .Y(new_n31_));
  INVx1_ASAP7_75t_R   g010(.A(p5), .Y(new_n32_));
  NAND2x1_ASAP7_75t_R g011(.A(p2), .B(new_n32_), .Y(new_n33_));
  NAND2x1_ASAP7_75t_R g012(.A(p2), .B(p1), .Y(new_n34_));
  NOR2x1_ASAP7_75t_R  g013(.A(p8), .B(p0), .Y(new_n35_));
  AND3x1_ASAP7_75t_R  g014(.A(new_n33_), .B(new_n34_), .C(new_n35_), .Y(new_n36_));
  INVx1_ASAP7_75t_R   g015(.A(p7), .Y(new_n37_));
  OA21x2_ASAP7_75t_R  g016(.A1(new_n31_), .A2(new_n36_), .B(new_n37_), .Y(new_n38_));
  INVx1_ASAP7_75t_R   g017(.A(p4), .Y(new_n39_));
  OA21x2_ASAP7_75t_R  g018(.A1(new_n29_), .A2(new_n38_), .B(new_n39_), .Y(new_n40_));
  INVx1_ASAP7_75t_R   g019(.A(p8), .Y(new_n41_));
  NAND2x1_ASAP7_75t_R g020(.A(p9), .B(new_n41_), .Y(new_n42_));
  NAND2x1_ASAP7_75t_R g021(.A(p1), .B(new_n22_), .Y(new_n43_));
  NAND2x1_ASAP7_75t_R g022(.A(p8), .B(new_n28_), .Y(new_n44_));
  AO21x1_ASAP7_75t_R  g023(.A1(new_n22_), .A2(new_n44_), .B(p7), .Y(new_n45_));
  OAI21x1_ASAP7_75t_R g024(.A1(new_n42_), .A2(new_n43_), .B(new_n45_), .Y(new_n46_));
  NOR2x1_ASAP7_75t_R  g025(.A(p4), .B(new_n25_), .Y(new_n47_));
  NOR2x1_ASAP7_75t_R  g026(.A(p2), .B(p9), .Y(new_n48_));
  AND2x2_ASAP7_75t_R  g027(.A(p7), .B(p5), .Y(new_n49_));
  NAND2x1_ASAP7_75t_R g028(.A(new_n48_), .B(new_n49_), .Y(new_n50_));
  NAND2x1_ASAP7_75t_R g029(.A(p0), .B(new_n41_), .Y(new_n51_));
  OA21x2_ASAP7_75t_R  g030(.A1(p1), .A2(new_n51_), .B(new_n30_), .Y(new_n52_));
  NOR2x1_ASAP7_75t_R  g031(.A(p2), .B(p1), .Y(new_n53_));
  INVx1_ASAP7_75t_R   g032(.A(new_n53_), .Y(new_n54_));
  OR3x1_ASAP7_75t_R   g033(.A(p7), .B(p8), .C(p0), .Y(new_n55_));
  OR3x1_ASAP7_75t_R   g034(.A(new_n54_), .B(p9), .C(new_n55_), .Y(new_n56_));
  OAI21x1_ASAP7_75t_R g035(.A1(new_n50_), .A2(new_n52_), .B(new_n56_), .Y(new_n57_));
  AOI21x1_ASAP7_75t_R g036(.A1(new_n46_), .A2(new_n47_), .B(new_n57_), .Y(new_n58_));
  NOR2x1_ASAP7_75t_R  g037(.A(p9), .B(p1), .Y(new_n59_));
  AND3x1_ASAP7_75t_R  g038(.A(new_n22_), .B(p8), .C(p5), .Y(new_n60_));
  AND2x2_ASAP7_75t_R  g039(.A(p5), .B(p4), .Y(new_n61_));
  AO21x1_ASAP7_75t_R  g040(.A1(new_n59_), .A2(new_n60_), .B(new_n61_), .Y(new_n62_));
  NAND2x1_ASAP7_75t_R g041(.A(new_n42_), .B(new_n44_), .Y(new_n63_));
  NAND2x1_ASAP7_75t_R g042(.A(p1), .B(p4), .Y(new_n64_));
  NOR3x1_ASAP7_75t_R  g043(.A(new_n63_), .B(new_n22_), .C(new_n64_), .Y(new_n65_));
  AND2x2_ASAP7_75t_R  g044(.A(p7), .B(p2), .Y(new_n66_));
  OAI21x1_ASAP7_75t_R g045(.A1(new_n62_), .A2(new_n65_), .B(new_n66_), .Y(new_n67_));
  NOR2x1_ASAP7_75t_R  g046(.A(p2), .B(new_n22_), .Y(new_n68_));
  AO21x1_ASAP7_75t_R  g047(.A1(p9), .A2(new_n41_), .B(p1), .Y(new_n69_));
  AOI21x1_ASAP7_75t_R g048(.A1(new_n44_), .A2(new_n68_), .B(new_n69_), .Y(new_n70_));
  NOR2x1_ASAP7_75t_R  g049(.A(p1), .B(new_n39_), .Y(new_n71_));
  AOI21x1_ASAP7_75t_R g050(.A1(new_n42_), .A2(new_n71_), .B(new_n61_), .Y(new_n72_));
  OR3x1_ASAP7_75t_R   g051(.A(new_n70_), .B(new_n37_), .C(new_n72_), .Y(new_n73_));
  NAND3x1_ASAP7_75t_R g052(.A(new_n58_), .B(new_n67_), .C(new_n73_), .Y(new_n74_));
  NOR2x1_ASAP7_75t_R  g053(.A(p3), .B(p6), .Y(new_n75_));
  OAI21x1_ASAP7_75t_R g054(.A1(new_n40_), .A2(new_n74_), .B(new_n75_), .Y(new_n76_));
  OR3x1_ASAP7_75t_R   g055(.A(new_n28_), .B(new_n22_), .C(p1), .Y(new_n77_));
  INVx1_ASAP7_75t_R   g056(.A(p1), .Y(new_n78_));
  NOR2x1_ASAP7_75t_R  g057(.A(p9), .B(new_n78_), .Y(new_n79_));
  NAND2x1_ASAP7_75t_R g058(.A(new_n35_), .B(new_n79_), .Y(new_n80_));
  INVx1_ASAP7_75t_R   g059(.A(p6), .Y(new_n81_));
  OR3x1_ASAP7_75t_R   g060(.A(new_n37_), .B(new_n81_), .C(p4), .Y(new_n82_));
  AO21x1_ASAP7_75t_R  g061(.A1(new_n77_), .A2(new_n80_), .B(new_n82_), .Y(new_n83_));
  NOR2x1_ASAP7_75t_R  g062(.A(p8), .B(p4), .Y(new_n84_));
  INVx1_ASAP7_75t_R   g063(.A(new_n84_), .Y(new_n85_));
  OA21x2_ASAP7_75t_R  g064(.A1(p6), .A2(new_n22_), .B(new_n85_), .Y(new_n86_));
  NAND2x1_ASAP7_75t_R g065(.A(p9), .B(new_n78_), .Y(new_n87_));
  AND3x1_ASAP7_75t_R  g066(.A(new_n81_), .B(new_n41_), .C(p0), .Y(new_n88_));
  OR3x1_ASAP7_75t_R   g067(.A(new_n86_), .B(new_n87_), .C(new_n88_), .Y(new_n89_));
  NAND2x1_ASAP7_75t_R g068(.A(new_n25_), .B(new_n32_), .Y(new_n90_));
  AOI21x1_ASAP7_75t_R g069(.A1(new_n83_), .A2(new_n89_), .B(new_n90_), .Y(new_n91_));
  NOR2x1_ASAP7_75t_R  g070(.A(p9), .B(p0), .Y(new_n92_));
  NAND2x1_ASAP7_75t_R g071(.A(p9), .B(p0), .Y(new_n93_));
  NOR2x1_ASAP7_75t_R  g072(.A(p2), .B(p4), .Y(new_n94_));
  NAND2x1_ASAP7_75t_R g073(.A(new_n93_), .B(new_n94_), .Y(new_n95_));
  OA21x2_ASAP7_75t_R  g074(.A1(p6), .A2(new_n92_), .B(new_n95_), .Y(new_n96_));
  XOR2x2_ASAP7_75t_R  g075(.A(p8), .B(p0), .Y(new_n97_));
  OR3x1_ASAP7_75t_R   g076(.A(new_n96_), .B(p1), .C(new_n97_), .Y(new_n98_));
  NAND2x1_ASAP7_75t_R g077(.A(p1), .B(p0), .Y(new_n99_));
  AO21x1_ASAP7_75t_R  g078(.A1(new_n78_), .A2(new_n39_), .B(p9), .Y(new_n100_));
  AO21x1_ASAP7_75t_R  g079(.A1(new_n99_), .A2(new_n100_), .B(p8), .Y(new_n101_));
  INVx1_ASAP7_75t_R   g080(.A(new_n68_), .Y(new_n102_));
  OR3x1_ASAP7_75t_R   g081(.A(new_n53_), .B(new_n41_), .C(p0), .Y(new_n103_));
  OR3x1_ASAP7_75t_R   g082(.A(new_n25_), .B(new_n28_), .C(p0), .Y(new_n104_));
  AND3x1_ASAP7_75t_R  g083(.A(new_n102_), .B(new_n103_), .C(new_n104_), .Y(new_n105_));
  AO21x1_ASAP7_75t_R  g084(.A1(new_n101_), .A2(new_n105_), .B(p6), .Y(new_n106_));
  NOR2x1_ASAP7_75t_R  g085(.A(p7), .B(p5), .Y(new_n107_));
  INVx1_ASAP7_75t_R   g086(.A(new_n107_), .Y(new_n108_));
  AOI21x1_ASAP7_75t_R g087(.A1(new_n98_), .A2(new_n106_), .B(new_n108_), .Y(new_n109_));
  INVx1_ASAP7_75t_R   g088(.A(p3), .Y(new_n110_));
  OAI21x1_ASAP7_75t_R g089(.A1(new_n91_), .A2(new_n109_), .B(new_n110_), .Y(new_n111_));
  AND3x1_ASAP7_75t_R  g090(.A(new_n92_), .B(new_n53_), .C(new_n81_), .Y(new_n112_));
  NOR2x1_ASAP7_75t_R  g091(.A(p8), .B(p5), .Y(new_n113_));
  AO21x1_ASAP7_75t_R  g092(.A1(p3), .A2(p7), .B(new_n113_), .Y(new_n114_));
  AO21x1_ASAP7_75t_R  g093(.A1(p7), .A2(new_n32_), .B(new_n39_), .Y(new_n115_));
  INVx1_ASAP7_75t_R   g094(.A(new_n115_), .Y(new_n116_));
  INVx1_ASAP7_75t_R   g095(.A(new_n61_), .Y(new_n117_));
  OA21x2_ASAP7_75t_R  g096(.A1(p3), .A2(new_n41_), .B(new_n117_), .Y(new_n118_));
  INVx1_ASAP7_75t_R   g097(.A(new_n113_), .Y(new_n119_));
  AND3x1_ASAP7_75t_R  g098(.A(new_n118_), .B(new_n37_), .C(new_n119_), .Y(new_n120_));
  AO21x1_ASAP7_75t_R  g099(.A1(new_n114_), .A2(new_n116_), .B(new_n120_), .Y(new_n121_));
  NAND2x1_ASAP7_75t_R g100(.A(new_n112_), .B(new_n121_), .Y(new_n122_));
  NAND3x1_ASAP7_75t_R g101(.A(new_n76_), .B(new_n111_), .C(new_n122_), .Y(o0));
  OR3x1_ASAP7_75t_R   g102(.A(new_n37_), .B(new_n28_), .C(p1), .Y(new_n124_));
  NOR2x1_ASAP7_75t_R  g103(.A(p9), .B(new_n39_), .Y(new_n125_));
  NOR2x1_ASAP7_75t_R  g104(.A(p4), .B(new_n28_), .Y(new_n126_));
  NOR2x1_ASAP7_75t_R  g105(.A(new_n125_), .B(new_n126_), .Y(new_n127_));
  AOI21x1_ASAP7_75t_R g106(.A1(new_n124_), .A2(new_n127_), .B(new_n22_), .Y(new_n128_));
  NOR2x1_ASAP7_75t_R  g107(.A(p7), .B(p2), .Y(new_n129_));
  NAND2x1_ASAP7_75t_R g108(.A(p9), .B(new_n22_), .Y(new_n130_));
  AO21x1_ASAP7_75t_R  g109(.A1(p7), .A2(new_n39_), .B(new_n130_), .Y(new_n131_));
  AO21x1_ASAP7_75t_R  g110(.A1(p7), .A2(p2), .B(p1), .Y(new_n132_));
  NAND2x1_ASAP7_75t_R g111(.A(new_n28_), .B(new_n132_), .Y(new_n133_));
  OAI21x1_ASAP7_75t_R g112(.A1(new_n129_), .A2(new_n131_), .B(new_n133_), .Y(new_n134_));
  OAI21x1_ASAP7_75t_R g113(.A1(new_n128_), .A2(new_n134_), .B(new_n32_), .Y(new_n135_));
  NAND2x1_ASAP7_75t_R g114(.A(p7), .B(new_n28_), .Y(new_n136_));
  AND2x2_ASAP7_75t_R  g115(.A(new_n39_), .B(new_n136_), .Y(new_n137_));
  NOR2x1_ASAP7_75t_R  g116(.A(p5), .B(p0), .Y(new_n138_));
  INVx1_ASAP7_75t_R   g117(.A(new_n138_), .Y(new_n139_));
  AND2x2_ASAP7_75t_R  g118(.A(new_n78_), .B(new_n93_), .Y(new_n140_));
  AND3x1_ASAP7_75t_R  g119(.A(new_n137_), .B(new_n139_), .C(new_n140_), .Y(new_n141_));
  OR3x1_ASAP7_75t_R   g120(.A(new_n37_), .B(new_n32_), .C(p0), .Y(new_n142_));
  INVx1_ASAP7_75t_R   g121(.A(new_n47_), .Y(new_n143_));
  OAI21x1_ASAP7_75t_R g122(.A1(new_n142_), .A2(new_n143_), .B(new_n41_), .Y(new_n144_));
  NAND2x1_ASAP7_75t_R g123(.A(new_n37_), .B(new_n22_), .Y(new_n145_));
  AND3x1_ASAP7_75t_R  g124(.A(new_n78_), .B(new_n39_), .C(p2), .Y(new_n146_));
  NOR2x1_ASAP7_75t_R  g125(.A(p7), .B(p1), .Y(new_n147_));
  AND3x1_ASAP7_75t_R  g126(.A(new_n147_), .B(new_n138_), .C(p4), .Y(new_n148_));
  AO21x1_ASAP7_75t_R  g127(.A1(new_n145_), .A2(new_n146_), .B(new_n148_), .Y(new_n149_));
  NOR3x1_ASAP7_75t_R  g128(.A(new_n141_), .B(new_n144_), .C(new_n149_), .Y(new_n150_));
  NAND2x1_ASAP7_75t_R g129(.A(new_n135_), .B(new_n150_), .Y(new_n151_));
  NOR2x1_ASAP7_75t_R  g130(.A(p0), .B(new_n25_), .Y(new_n152_));
  AND2x2_ASAP7_75t_R  g131(.A(p0), .B(p4), .Y(new_n153_));
  AO21x1_ASAP7_75t_R  g132(.A1(new_n147_), .A2(new_n152_), .B(new_n153_), .Y(new_n154_));
  AND3x1_ASAP7_75t_R  g133(.A(p2), .B(p1), .C(p0), .Y(new_n155_));
  AO21x1_ASAP7_75t_R  g134(.A1(p4), .A2(new_n54_), .B(new_n155_), .Y(new_n156_));
  AO21x1_ASAP7_75t_R  g135(.A1(p9), .A2(new_n154_), .B(new_n156_), .Y(new_n157_));
  NOR2x1_ASAP7_75t_R  g136(.A(p7), .B(new_n39_), .Y(new_n158_));
  AO21x1_ASAP7_75t_R  g137(.A1(new_n155_), .A2(new_n158_), .B(new_n41_), .Y(new_n159_));
  AO21x1_ASAP7_75t_R  g138(.A1(p5), .A2(new_n157_), .B(new_n159_), .Y(new_n160_));
  NAND3x1_ASAP7_75t_R g139(.A(new_n151_), .B(new_n75_), .C(new_n160_), .Y(new_n161_));
  INVx1_ASAP7_75t_R   g140(.A(new_n112_), .Y(new_n162_));
  NAND2x1_ASAP7_75t_R g141(.A(p8), .B(p5), .Y(new_n163_));
  AO21x1_ASAP7_75t_R  g142(.A1(p3), .A2(p7), .B(new_n158_), .Y(new_n164_));
  NAND2x1_ASAP7_75t_R g143(.A(new_n113_), .B(new_n164_), .Y(new_n165_));
  OA21x2_ASAP7_75t_R  g144(.A1(new_n110_), .A2(new_n163_), .B(new_n165_), .Y(new_n166_));
  OR3x1_ASAP7_75t_R   g145(.A(new_n22_), .B(p8), .C(p1), .Y(new_n167_));
  NAND2x1_ASAP7_75t_R g146(.A(p7), .B(p6), .Y(new_n168_));
  OA21x2_ASAP7_75t_R  g147(.A1(new_n167_), .A2(new_n168_), .B(new_n80_), .Y(new_n169_));
  NOR2x1_ASAP7_75t_R  g148(.A(new_n78_), .B(new_n92_), .Y(new_n170_));
  OR3x1_ASAP7_75t_R   g149(.A(new_n170_), .B(p7), .C(new_n81_), .Y(new_n171_));
  AO21x1_ASAP7_75t_R  g150(.A1(new_n42_), .A2(new_n140_), .B(new_n171_), .Y(new_n172_));
  AND3x1_ASAP7_75t_R  g151(.A(new_n94_), .B(new_n110_), .C(new_n32_), .Y(new_n173_));
  INVx1_ASAP7_75t_R   g152(.A(new_n173_), .Y(new_n174_));
  AO21x1_ASAP7_75t_R  g153(.A1(new_n169_), .A2(new_n172_), .B(new_n174_), .Y(new_n175_));
  OA21x2_ASAP7_75t_R  g154(.A1(new_n162_), .A2(new_n166_), .B(new_n175_), .Y(new_n176_));
  OA21x2_ASAP7_75t_R  g155(.A1(new_n37_), .A2(p4), .B(new_n163_), .Y(new_n177_));
  INVx1_ASAP7_75t_R   g156(.A(new_n79_), .Y(new_n178_));
  NAND2x1_ASAP7_75t_R g157(.A(p7), .B(p9), .Y(new_n179_));
  OR3x1_ASAP7_75t_R   g158(.A(new_n64_), .B(new_n179_), .C(new_n41_), .Y(new_n180_));
  OA21x2_ASAP7_75t_R  g159(.A1(new_n177_), .A2(new_n178_), .B(new_n180_), .Y(new_n181_));
  OR3x1_ASAP7_75t_R   g160(.A(new_n39_), .B(p8), .C(p9), .Y(new_n182_));
  INVx1_ASAP7_75t_R   g161(.A(new_n147_), .Y(new_n183_));
  NOR2x1_ASAP7_75t_R  g162(.A(p7), .B(p8), .Y(new_n184_));
  AND3x1_ASAP7_75t_R  g163(.A(new_n184_), .B(p1), .C(new_n39_), .Y(new_n185_));
  AOI21x1_ASAP7_75t_R g164(.A1(new_n31_), .A2(new_n49_), .B(new_n185_), .Y(new_n186_));
  OA21x2_ASAP7_75t_R  g165(.A1(new_n182_), .A2(new_n183_), .B(new_n186_), .Y(new_n187_));
  AOI21x1_ASAP7_75t_R g166(.A1(new_n181_), .A2(new_n187_), .B(p0), .Y(new_n188_));
  AND3x1_ASAP7_75t_R  g167(.A(new_n147_), .B(p8), .C(p4), .Y(new_n189_));
  NAND2x1_ASAP7_75t_R g168(.A(new_n28_), .B(new_n189_), .Y(new_n190_));
  OR3x1_ASAP7_75t_R   g169(.A(new_n177_), .B(new_n49_), .C(new_n87_), .Y(new_n191_));
  AOI21x1_ASAP7_75t_R g170(.A1(new_n190_), .A2(new_n191_), .B(new_n22_), .Y(new_n192_));
  AND2x2_ASAP7_75t_R  g171(.A(p7), .B(p1), .Y(new_n193_));
  AO21x1_ASAP7_75t_R  g172(.A1(new_n39_), .A2(new_n193_), .B(new_n107_), .Y(new_n194_));
  NAND2x1_ASAP7_75t_R g173(.A(p5), .B(new_n39_), .Y(new_n195_));
  NOR2x1_ASAP7_75t_R  g174(.A(new_n136_), .B(new_n195_), .Y(new_n196_));
  NOR2x1_ASAP7_75t_R  g175(.A(p8), .B(new_n22_), .Y(new_n197_));
  OA21x2_ASAP7_75t_R  g176(.A1(new_n194_), .A2(new_n196_), .B(new_n197_), .Y(new_n198_));
  AND3x1_ASAP7_75t_R  g177(.A(new_n113_), .B(p7), .C(p1), .Y(new_n199_));
  OR3x1_ASAP7_75t_R   g178(.A(new_n192_), .B(new_n198_), .C(new_n199_), .Y(new_n200_));
  AND3x1_ASAP7_75t_R  g179(.A(new_n110_), .B(new_n81_), .C(new_n25_), .Y(new_n201_));
  OAI21x1_ASAP7_75t_R g180(.A1(new_n188_), .A2(new_n200_), .B(new_n201_), .Y(new_n202_));
  NAND3x1_ASAP7_75t_R g181(.A(new_n161_), .B(new_n176_), .C(new_n202_), .Y(o1));
  INVx1_ASAP7_75t_R   g182(.A(new_n75_), .Y(new_n204_));
  AND3x1_ASAP7_75t_R  g183(.A(p7), .B(p8), .C(p9), .Y(new_n205_));
  NOR2x1_ASAP7_75t_R  g184(.A(p0), .B(new_n53_), .Y(new_n206_));
  AO21x1_ASAP7_75t_R  g185(.A1(p2), .A2(new_n22_), .B(new_n39_), .Y(new_n207_));
  NOR2x1_ASAP7_75t_R  g186(.A(p8), .B(new_n28_), .Y(new_n208_));
  AND3x1_ASAP7_75t_R  g187(.A(new_n207_), .B(new_n208_), .C(new_n147_), .Y(new_n209_));
  AO21x1_ASAP7_75t_R  g188(.A1(new_n205_), .A2(new_n206_), .B(new_n209_), .Y(new_n210_));
  XOR2x2_ASAP7_75t_R  g189(.A(p7), .B(p8), .Y(new_n211_));
  INVx1_ASAP7_75t_R   g190(.A(new_n26_), .Y(new_n212_));
  OA21x2_ASAP7_75t_R  g191(.A1(new_n35_), .A2(new_n211_), .B(new_n212_), .Y(new_n213_));
  AO21x1_ASAP7_75t_R  g192(.A1(p0), .A2(new_n31_), .B(new_n153_), .Y(new_n214_));
  OR3x1_ASAP7_75t_R   g193(.A(new_n205_), .B(new_n39_), .C(new_n184_), .Y(new_n215_));
  AND3x1_ASAP7_75t_R  g194(.A(new_n214_), .B(new_n25_), .C(new_n215_), .Y(new_n216_));
  OR3x1_ASAP7_75t_R   g195(.A(new_n210_), .B(new_n213_), .C(new_n216_), .Y(new_n217_));
  OR3x1_ASAP7_75t_R   g196(.A(new_n97_), .B(p7), .C(p2), .Y(new_n218_));
  AO21x1_ASAP7_75t_R  g197(.A1(p8), .A2(new_n22_), .B(new_n32_), .Y(new_n219_));
  AO21x1_ASAP7_75t_R  g198(.A1(new_n51_), .A2(new_n219_), .B(new_n37_), .Y(new_n220_));
  AO21x1_ASAP7_75t_R  g199(.A1(new_n218_), .A2(new_n220_), .B(p1), .Y(new_n221_));
  AO21x1_ASAP7_75t_R  g200(.A1(p1), .A2(new_n41_), .B(new_n37_), .Y(new_n222_));
  OR3x1_ASAP7_75t_R   g201(.A(new_n30_), .B(new_n32_), .C(new_n22_), .Y(new_n223_));
  NAND2x1_ASAP7_75t_R g202(.A(p1), .B(new_n184_), .Y(new_n224_));
  AND3x1_ASAP7_75t_R  g203(.A(new_n223_), .B(new_n142_), .C(new_n224_), .Y(new_n225_));
  AO21x1_ASAP7_75t_R  g204(.A1(new_n222_), .A2(new_n225_), .B(new_n25_), .Y(new_n226_));
  INVx1_ASAP7_75t_R   g205(.A(new_n126_), .Y(new_n227_));
  AOI21x1_ASAP7_75t_R g206(.A1(new_n221_), .A2(new_n226_), .B(new_n227_), .Y(new_n228_));
  AOI21x1_ASAP7_75t_R g207(.A1(new_n32_), .A2(new_n217_), .B(new_n228_), .Y(new_n229_));
  NAND2x1_ASAP7_75t_R g208(.A(p7), .B(p8), .Y(new_n230_));
  NAND2x1_ASAP7_75t_R g209(.A(p5), .B(new_n37_), .Y(new_n231_));
  NAND2x1_ASAP7_75t_R g210(.A(p3), .B(new_n39_), .Y(new_n232_));
  AO21x1_ASAP7_75t_R  g211(.A1(new_n230_), .A2(new_n231_), .B(new_n232_), .Y(new_n233_));
  AO21x1_ASAP7_75t_R  g212(.A1(new_n22_), .A2(new_n53_), .B(new_n110_), .Y(new_n234_));
  NOR2x1_ASAP7_75t_R  g213(.A(p6), .B(p9), .Y(new_n235_));
  AND3x1_ASAP7_75t_R  g214(.A(new_n233_), .B(new_n234_), .C(new_n235_), .Y(new_n236_));
  AO21x1_ASAP7_75t_R  g215(.A1(p7), .A2(new_n197_), .B(new_n113_), .Y(new_n237_));
  OR3x1_ASAP7_75t_R   g216(.A(new_n41_), .B(p7), .C(p0), .Y(new_n238_));
  AO21x1_ASAP7_75t_R  g217(.A1(p1), .A2(new_n238_), .B(new_n25_), .Y(new_n239_));
  OR3x1_ASAP7_75t_R   g218(.A(new_n41_), .B(new_n22_), .C(p2), .Y(new_n240_));
  OA21x2_ASAP7_75t_R  g219(.A1(new_n231_), .A2(new_n240_), .B(new_n110_), .Y(new_n241_));
  OA21x2_ASAP7_75t_R  g220(.A1(new_n237_), .A2(new_n239_), .B(new_n241_), .Y(new_n242_));
  OA21x2_ASAP7_75t_R  g221(.A1(new_n78_), .A2(new_n32_), .B(p0), .Y(new_n243_));
  NAND2x1_ASAP7_75t_R g222(.A(p4), .B(new_n132_), .Y(new_n244_));
  AO21x1_ASAP7_75t_R  g223(.A1(p7), .A2(new_n243_), .B(new_n244_), .Y(new_n245_));
  OR3x1_ASAP7_75t_R   g224(.A(new_n195_), .B(p2), .C(new_n55_), .Y(new_n246_));
  NAND2x1_ASAP7_75t_R g225(.A(p2), .B(new_n37_), .Y(new_n247_));
  AO21x1_ASAP7_75t_R  g226(.A1(p2), .A2(new_n41_), .B(p5), .Y(new_n248_));
  AO21x1_ASAP7_75t_R  g227(.A1(new_n51_), .A2(new_n247_), .B(new_n248_), .Y(new_n249_));
  AND3x1_ASAP7_75t_R  g228(.A(new_n245_), .B(new_n246_), .C(new_n249_), .Y(new_n250_));
  AO21x1_ASAP7_75t_R  g229(.A1(new_n37_), .A2(new_n39_), .B(new_n51_), .Y(new_n251_));
  NAND2x1_ASAP7_75t_R g230(.A(p7), .B(new_n78_), .Y(new_n252_));
  AND3x1_ASAP7_75t_R  g231(.A(new_n252_), .B(p2), .C(p4), .Y(new_n253_));
  OR3x1_ASAP7_75t_R   g232(.A(new_n251_), .B(new_n253_), .C(new_n146_), .Y(new_n254_));
  NAND3x1_ASAP7_75t_R g233(.A(new_n242_), .B(new_n250_), .C(new_n254_), .Y(new_n255_));
  AO21x1_ASAP7_75t_R  g234(.A1(p8), .A2(new_n168_), .B(new_n22_), .Y(new_n256_));
  OR3x1_ASAP7_75t_R   g235(.A(new_n42_), .B(p7), .C(p0), .Y(new_n257_));
  OAI21x1_ASAP7_75t_R g236(.A1(new_n63_), .A2(new_n256_), .B(new_n257_), .Y(new_n258_));
  AND3x1_ASAP7_75t_R  g237(.A(new_n258_), .B(new_n78_), .C(new_n173_), .Y(new_n259_));
  AOI21x1_ASAP7_75t_R g238(.A1(new_n236_), .A2(new_n255_), .B(new_n259_), .Y(new_n260_));
  OAI21x1_ASAP7_75t_R g239(.A1(new_n204_), .A2(new_n229_), .B(new_n260_), .Y(o2));
  AO21x1_ASAP7_75t_R  g240(.A1(new_n32_), .A2(new_n247_), .B(new_n47_), .Y(new_n262_));
  AOI21x1_ASAP7_75t_R g241(.A1(p2), .A2(new_n78_), .B(new_n189_), .Y(new_n263_));
  AO21x1_ASAP7_75t_R  g242(.A1(new_n262_), .A2(new_n263_), .B(new_n93_), .Y(new_n264_));
  OR3x1_ASAP7_75t_R   g243(.A(new_n51_), .B(new_n195_), .C(new_n37_), .Y(new_n265_));
  NAND2x1_ASAP7_75t_R g244(.A(p8), .B(p0), .Y(new_n266_));
  NAND2x1_ASAP7_75t_R g245(.A(p7), .B(p4), .Y(new_n267_));
  AO21x1_ASAP7_75t_R  g246(.A1(p8), .A2(p4), .B(p5), .Y(new_n268_));
  AO21x1_ASAP7_75t_R  g247(.A1(new_n266_), .A2(new_n267_), .B(new_n268_), .Y(new_n269_));
  OR3x1_ASAP7_75t_R   g248(.A(new_n55_), .B(new_n32_), .C(p4), .Y(new_n270_));
  OA21x2_ASAP7_75t_R  g249(.A1(new_n25_), .A2(new_n269_), .B(new_n270_), .Y(new_n271_));
  AND3x1_ASAP7_75t_R  g250(.A(new_n264_), .B(new_n265_), .C(new_n271_), .Y(new_n272_));
  AND3x1_ASAP7_75t_R  g251(.A(new_n183_), .B(new_n197_), .C(p9), .Y(new_n273_));
  AND3x1_ASAP7_75t_R  g252(.A(new_n39_), .B(p7), .C(p1), .Y(new_n274_));
  OR3x1_ASAP7_75t_R   g253(.A(new_n274_), .B(new_n71_), .C(new_n129_), .Y(new_n275_));
  NAND2x1_ASAP7_75t_R g254(.A(new_n273_), .B(new_n275_), .Y(new_n276_));
  NOR2x1_ASAP7_75t_R  g255(.A(p5), .B(new_n34_), .Y(new_n277_));
  INVx1_ASAP7_75t_R   g256(.A(new_n277_), .Y(new_n278_));
  AO21x1_ASAP7_75t_R  g257(.A1(new_n195_), .A2(new_n278_), .B(new_n103_), .Y(new_n279_));
  OA21x2_ASAP7_75t_R  g258(.A1(new_n107_), .A2(new_n84_), .B(new_n78_), .Y(new_n280_));
  AND3x1_ASAP7_75t_R  g259(.A(new_n107_), .B(p2), .C(new_n22_), .Y(new_n281_));
  AOI21x1_ASAP7_75t_R g260(.A1(p2), .A2(new_n280_), .B(new_n281_), .Y(new_n282_));
  AND3x1_ASAP7_75t_R  g261(.A(new_n276_), .B(new_n279_), .C(new_n282_), .Y(new_n283_));
  AO21x1_ASAP7_75t_R  g262(.A1(p5), .A2(new_n94_), .B(new_n148_), .Y(new_n284_));
  NAND2x1_ASAP7_75t_R g263(.A(new_n208_), .B(new_n284_), .Y(new_n285_));
  AND3x1_ASAP7_75t_R  g264(.A(new_n272_), .B(new_n283_), .C(new_n285_), .Y(new_n286_));
  NOR2x1_ASAP7_75t_R  g265(.A(p5), .B(p4), .Y(new_n287_));
  OR2x4_ASAP7_75t_R   g266(.A(new_n287_), .B(new_n61_), .Y(new_n288_));
  AND3x1_ASAP7_75t_R  g267(.A(new_n53_), .B(p3), .C(new_n22_), .Y(new_n289_));
  AO21x1_ASAP7_75t_R  g268(.A1(p7), .A2(p8), .B(p4), .Y(new_n290_));
  AND3x1_ASAP7_75t_R  g269(.A(new_n288_), .B(new_n289_), .C(new_n290_), .Y(new_n291_));
  AND3x1_ASAP7_75t_R  g270(.A(new_n39_), .B(p1), .C(p5), .Y(new_n292_));
  AO21x1_ASAP7_75t_R  g271(.A1(new_n206_), .A2(new_n248_), .B(new_n292_), .Y(new_n293_));
  OR3x1_ASAP7_75t_R   g272(.A(new_n30_), .B(new_n267_), .C(p5), .Y(new_n294_));
  AO21x1_ASAP7_75t_R  g273(.A1(p5), .A2(new_n37_), .B(p2), .Y(new_n295_));
  AOI21x1_ASAP7_75t_R g274(.A1(new_n115_), .A2(new_n295_), .B(new_n185_), .Y(new_n296_));
  AOI21x1_ASAP7_75t_R g275(.A1(new_n294_), .A2(new_n296_), .B(new_n22_), .Y(new_n297_));
  OA21x2_ASAP7_75t_R  g276(.A1(new_n293_), .A2(new_n297_), .B(new_n110_), .Y(new_n298_));
  OAI21x1_ASAP7_75t_R g277(.A1(new_n291_), .A2(new_n298_), .B(new_n235_), .Y(new_n299_));
  OAI21x1_ASAP7_75t_R g278(.A1(new_n204_), .A2(new_n286_), .B(new_n299_), .Y(o3));
  NAND2x1_ASAP7_75t_R g279(.A(p3), .B(new_n25_), .Y(new_n301_));
  NAND2x1_ASAP7_75t_R g280(.A(p2), .B(new_n110_), .Y(new_n302_));
  OR3x1_ASAP7_75t_R   g281(.A(p9), .B(p1), .C(p0), .Y(new_n303_));
  AOI21x1_ASAP7_75t_R g282(.A1(new_n301_), .A2(new_n302_), .B(new_n303_), .Y(new_n304_));
  AND2x2_ASAP7_75t_R  g283(.A(new_n110_), .B(new_n170_), .Y(new_n305_));
  AND3x1_ASAP7_75t_R  g284(.A(new_n81_), .B(p5), .C(p4), .Y(new_n306_));
  OA21x2_ASAP7_75t_R  g285(.A1(new_n304_), .A2(new_n305_), .B(new_n306_), .Y(o4));
  AND3x1_ASAP7_75t_R  g286(.A(new_n303_), .B(new_n110_), .C(p2), .Y(new_n308_));
  AO21x1_ASAP7_75t_R  g287(.A1(new_n28_), .A2(new_n289_), .B(new_n308_), .Y(new_n309_));
  AND2x2_ASAP7_75t_R  g288(.A(new_n306_), .B(new_n309_), .Y(o5));
  AND3x1_ASAP7_75t_R  g289(.A(new_n49_), .B(p9), .C(new_n78_), .Y(new_n311_));
  AOI21x1_ASAP7_75t_R g290(.A1(new_n23_), .A2(new_n178_), .B(new_n311_), .Y(new_n312_));
  NOR2x1_ASAP7_75t_R  g291(.A(p7), .B(p9), .Y(new_n313_));
  OR3x1_ASAP7_75t_R   g292(.A(new_n126_), .B(new_n51_), .C(new_n313_), .Y(new_n314_));
  OAI21x1_ASAP7_75t_R g293(.A1(new_n41_), .A2(new_n312_), .B(new_n314_), .Y(new_n315_));
  NOR2x1_ASAP7_75t_R  g294(.A(p0), .B(new_n184_), .Y(new_n316_));
  OR3x1_ASAP7_75t_R   g295(.A(new_n316_), .B(new_n28_), .C(new_n197_), .Y(new_n317_));
  NOR2x1_ASAP7_75t_R  g296(.A(p9), .B(p5), .Y(new_n318_));
  NOR2x1_ASAP7_75t_R  g297(.A(p8), .B(new_n78_), .Y(new_n319_));
  AO21x1_ASAP7_75t_R  g298(.A1(new_n318_), .A2(new_n145_), .B(new_n319_), .Y(new_n320_));
  NAND2x1_ASAP7_75t_R g299(.A(new_n97_), .B(new_n320_), .Y(new_n321_));
  AOI21x1_ASAP7_75t_R g300(.A1(new_n317_), .A2(new_n321_), .B(new_n143_), .Y(new_n322_));
  AOI21x1_ASAP7_75t_R g301(.A1(p2), .A2(new_n315_), .B(new_n322_), .Y(new_n323_));
  OR3x1_ASAP7_75t_R   g302(.A(new_n230_), .B(p9), .C(new_n78_), .Y(new_n324_));
  OR3x1_ASAP7_75t_R   g303(.A(new_n318_), .B(p8), .C(p1), .Y(new_n325_));
  AO21x1_ASAP7_75t_R  g304(.A1(p7), .A2(new_n227_), .B(new_n325_), .Y(new_n326_));
  AO21x1_ASAP7_75t_R  g305(.A1(new_n324_), .A2(new_n326_), .B(p0), .Y(new_n327_));
  AND3x1_ASAP7_75t_R  g306(.A(new_n42_), .B(new_n71_), .C(new_n44_), .Y(new_n328_));
  AO21x1_ASAP7_75t_R  g307(.A1(p1), .A2(new_n39_), .B(p5), .Y(new_n329_));
  AND3x1_ASAP7_75t_R  g308(.A(new_n329_), .B(p8), .C(new_n28_), .Y(new_n330_));
  OAI21x1_ASAP7_75t_R g309(.A1(new_n328_), .A2(new_n330_), .B(new_n23_), .Y(new_n331_));
  INVx1_ASAP7_75t_R   g310(.A(new_n179_), .Y(new_n332_));
  OA21x2_ASAP7_75t_R  g311(.A1(p7), .A2(p8), .B(p1), .Y(new_n333_));
  AO21x1_ASAP7_75t_R  g312(.A1(p8), .A2(new_n332_), .B(new_n333_), .Y(new_n334_));
  NAND3x1_ASAP7_75t_R g313(.A(new_n334_), .B(p5), .C(p0), .Y(new_n335_));
  AND3x1_ASAP7_75t_R  g314(.A(new_n327_), .B(new_n331_), .C(new_n335_), .Y(new_n336_));
  AOI21x1_ASAP7_75t_R g315(.A1(new_n323_), .A2(new_n336_), .B(new_n204_), .Y(new_n337_));
  NOR2x1_ASAP7_75t_R  g316(.A(new_n184_), .B(new_n205_), .Y(new_n338_));
  NAND2x1_ASAP7_75t_R g317(.A(p6), .B(new_n78_), .Y(new_n339_));
  OR3x1_ASAP7_75t_R   g318(.A(new_n338_), .B(new_n316_), .C(new_n339_), .Y(new_n340_));
  NAND2x1_ASAP7_75t_R g319(.A(p6), .B(new_n41_), .Y(new_n341_));
  AO21x1_ASAP7_75t_R  g320(.A1(p7), .A2(new_n341_), .B(new_n43_), .Y(new_n342_));
  AO21x1_ASAP7_75t_R  g321(.A1(new_n167_), .A2(new_n342_), .B(p9), .Y(new_n343_));
  OR3x1_ASAP7_75t_R   g322(.A(p2), .B(p5), .C(p4), .Y(new_n344_));
  AO21x1_ASAP7_75t_R  g323(.A1(new_n340_), .A2(new_n343_), .B(new_n344_), .Y(new_n345_));
  OAI21x1_ASAP7_75t_R g324(.A1(new_n147_), .A2(new_n193_), .B(p5), .Y(new_n346_));
  OR3x1_ASAP7_75t_R   g325(.A(new_n41_), .B(new_n78_), .C(p9), .Y(new_n347_));
  AO21x1_ASAP7_75t_R  g326(.A1(new_n55_), .A2(new_n347_), .B(new_n39_), .Y(new_n348_));
  OAI21x1_ASAP7_75t_R g327(.A1(new_n211_), .A2(new_n346_), .B(new_n348_), .Y(new_n349_));
  AND3x1_ASAP7_75t_R  g328(.A(new_n64_), .B(new_n113_), .C(new_n99_), .Y(new_n350_));
  AOI21x1_ASAP7_75t_R g329(.A1(p8), .A2(new_n153_), .B(new_n350_), .Y(new_n351_));
  OR3x1_ASAP7_75t_R   g330(.A(new_n84_), .B(p9), .C(new_n78_), .Y(new_n352_));
  AO21x1_ASAP7_75t_R  g331(.A1(new_n28_), .A2(new_n352_), .B(new_n37_), .Y(new_n353_));
  AOI21x1_ASAP7_75t_R g332(.A1(new_n351_), .A2(new_n352_), .B(new_n353_), .Y(new_n354_));
  NOR2x1_ASAP7_75t_R  g333(.A(p6), .B(p2), .Y(new_n355_));
  OAI21x1_ASAP7_75t_R g334(.A1(new_n349_), .A2(new_n354_), .B(new_n355_), .Y(new_n356_));
  AOI21x1_ASAP7_75t_R g335(.A1(new_n345_), .A2(new_n356_), .B(p3), .Y(new_n357_));
  AO21x1_ASAP7_75t_R  g336(.A1(p3), .A2(new_n112_), .B(new_n306_), .Y(new_n358_));
  NOR3x1_ASAP7_75t_R  g337(.A(new_n337_), .B(new_n357_), .C(new_n358_), .Y(o6));
  INVx1_ASAP7_75t_R   g338(.A(new_n184_), .Y(new_n360_));
  AND3x1_ASAP7_75t_R  g339(.A(new_n360_), .B(new_n79_), .C(new_n230_), .Y(new_n361_));
  NOR2x1_ASAP7_75t_R  g340(.A(new_n341_), .B(new_n124_), .Y(new_n362_));
  AND3x1_ASAP7_75t_R  g341(.A(new_n94_), .B(new_n32_), .C(new_n22_), .Y(new_n363_));
  OA21x2_ASAP7_75t_R  g342(.A1(new_n361_), .A2(new_n362_), .B(new_n363_), .Y(new_n364_));
  OA21x2_ASAP7_75t_R  g343(.A1(new_n81_), .A2(new_n364_), .B(new_n110_), .Y(new_n365_));
  OAI21x1_ASAP7_75t_R g344(.A1(new_n33_), .A2(new_n136_), .B(new_n231_), .Y(new_n366_));
  AOI21x1_ASAP7_75t_R g345(.A1(p5), .A2(new_n41_), .B(p9), .Y(new_n367_));
  NOR2x1_ASAP7_75t_R  g346(.A(p5), .B(new_n25_), .Y(new_n368_));
  AOI21x1_ASAP7_75t_R g347(.A1(p8), .A2(p5), .B(p7), .Y(new_n369_));
  NOR3x1_ASAP7_75t_R  g348(.A(new_n367_), .B(new_n368_), .C(new_n369_), .Y(new_n370_));
  AOI21x1_ASAP7_75t_R g349(.A1(p8), .A2(new_n366_), .B(new_n370_), .Y(new_n371_));
  NOR2x1_ASAP7_75t_R  g350(.A(p5), .B(new_n78_), .Y(new_n372_));
  AO21x1_ASAP7_75t_R  g351(.A1(p2), .A2(new_n230_), .B(new_n332_), .Y(new_n373_));
  NAND2x1_ASAP7_75t_R g352(.A(new_n113_), .B(new_n129_), .Y(new_n374_));
  OAI21x1_ASAP7_75t_R g353(.A1(new_n26_), .A2(new_n230_), .B(new_n374_), .Y(new_n375_));
  AOI21x1_ASAP7_75t_R g354(.A1(new_n372_), .A2(new_n373_), .B(new_n375_), .Y(new_n376_));
  OAI21x1_ASAP7_75t_R g355(.A1(p1), .A2(new_n371_), .B(new_n376_), .Y(new_n377_));
  NOR2x1_ASAP7_75t_R  g356(.A(new_n59_), .B(new_n49_), .Y(new_n378_));
  NAND2x1_ASAP7_75t_R g357(.A(new_n35_), .B(new_n136_), .Y(new_n379_));
  AND3x1_ASAP7_75t_R  g358(.A(new_n41_), .B(p2), .C(p5), .Y(new_n380_));
  NAND2x1_ASAP7_75t_R g359(.A(new_n147_), .B(new_n380_), .Y(new_n381_));
  OA21x2_ASAP7_75t_R  g360(.A1(new_n378_), .A2(new_n379_), .B(new_n381_), .Y(new_n382_));
  NAND2x1_ASAP7_75t_R g361(.A(p5), .B(new_n28_), .Y(new_n383_));
  NOR2x1_ASAP7_75t_R  g362(.A(new_n383_), .B(new_n211_), .Y(new_n384_));
  AO21x1_ASAP7_75t_R  g363(.A1(p7), .A2(p8), .B(p5), .Y(new_n385_));
  NOR2x1_ASAP7_75t_R  g364(.A(new_n385_), .B(new_n69_), .Y(new_n386_));
  OAI21x1_ASAP7_75t_R g365(.A1(new_n384_), .A2(new_n386_), .B(new_n152_), .Y(new_n387_));
  NOR2x1_ASAP7_75t_R  g366(.A(p5), .B(new_n129_), .Y(new_n388_));
  OR3x1_ASAP7_75t_R   g367(.A(new_n388_), .B(new_n184_), .C(new_n43_), .Y(new_n389_));
  NAND3x1_ASAP7_75t_R g368(.A(new_n382_), .B(new_n387_), .C(new_n389_), .Y(new_n390_));
  AOI21x1_ASAP7_75t_R g369(.A1(p0), .A2(new_n377_), .B(new_n390_), .Y(new_n391_));
  AND3x1_ASAP7_75t_R  g370(.A(new_n54_), .B(new_n22_), .C(p4), .Y(new_n392_));
  OAI21x1_ASAP7_75t_R g371(.A1(new_n59_), .A2(new_n211_), .B(new_n34_), .Y(new_n393_));
  OR3x1_ASAP7_75t_R   g372(.A(new_n30_), .B(new_n267_), .C(new_n25_), .Y(new_n394_));
  OAI21x1_ASAP7_75t_R g373(.A1(new_n104_), .A2(new_n224_), .B(new_n394_), .Y(new_n395_));
  AOI21x1_ASAP7_75t_R g374(.A1(new_n392_), .A2(new_n393_), .B(new_n395_), .Y(new_n396_));
  AND3x1_ASAP7_75t_R  g375(.A(new_n158_), .B(p8), .C(p1), .Y(new_n397_));
  OAI21x1_ASAP7_75t_R g376(.A1(p8), .A2(p1), .B(p9), .Y(new_n398_));
  OAI21x1_ASAP7_75t_R g377(.A1(new_n31_), .A2(new_n398_), .B(new_n182_), .Y(new_n399_));
  OA21x2_ASAP7_75t_R  g378(.A1(new_n39_), .A2(new_n30_), .B(new_n37_), .Y(new_n400_));
  NOR2x1_ASAP7_75t_R  g379(.A(p2), .B(new_n400_), .Y(new_n401_));
  OAI21x1_ASAP7_75t_R g380(.A1(new_n397_), .A2(new_n399_), .B(new_n401_), .Y(new_n402_));
  AO21x1_ASAP7_75t_R  g381(.A1(p2), .A2(p4), .B(new_n319_), .Y(new_n403_));
  AND3x1_ASAP7_75t_R  g382(.A(new_n71_), .B(p2), .C(new_n230_), .Y(new_n404_));
  AOI21x1_ASAP7_75t_R g383(.A1(new_n313_), .A2(new_n403_), .B(new_n404_), .Y(new_n405_));
  NAND3x1_ASAP7_75t_R g384(.A(new_n396_), .B(new_n402_), .C(new_n405_), .Y(new_n406_));
  AOI21x1_ASAP7_75t_R g385(.A1(new_n22_), .A2(new_n396_), .B(p5), .Y(new_n407_));
  AOI21x1_ASAP7_75t_R g386(.A1(new_n406_), .A2(new_n407_), .B(new_n364_), .Y(new_n408_));
  OAI21x1_ASAP7_75t_R g387(.A1(p4), .A2(new_n391_), .B(new_n408_), .Y(new_n409_));
  AND3x1_ASAP7_75t_R  g388(.A(new_n81_), .B(new_n32_), .C(new_n39_), .Y(new_n410_));
  AND3x1_ASAP7_75t_R  g389(.A(new_n289_), .B(new_n28_), .C(new_n410_), .Y(new_n411_));
  AOI21x1_ASAP7_75t_R g390(.A1(new_n365_), .A2(new_n409_), .B(new_n411_), .Y(o7));
  AO21x1_ASAP7_75t_R  g391(.A1(p2), .A2(new_n39_), .B(new_n153_), .Y(new_n413_));
  AO21x1_ASAP7_75t_R  g392(.A1(p8), .A2(new_n25_), .B(new_n35_), .Y(new_n414_));
  OR3x1_ASAP7_75t_R   g393(.A(new_n413_), .B(p1), .C(new_n414_), .Y(new_n415_));
  NAND2x1_ASAP7_75t_R g394(.A(new_n35_), .B(new_n71_), .Y(new_n416_));
  AO21x1_ASAP7_75t_R  g395(.A1(new_n240_), .A2(new_n416_), .B(p9), .Y(new_n417_));
  NAND2x1_ASAP7_75t_R g396(.A(new_n22_), .B(new_n39_), .Y(new_n418_));
  AO21x1_ASAP7_75t_R  g397(.A1(new_n418_), .A2(new_n97_), .B(new_n26_), .Y(new_n419_));
  NAND3x1_ASAP7_75t_R g398(.A(new_n415_), .B(new_n417_), .C(new_n419_), .Y(new_n420_));
  NOR2x1_ASAP7_75t_R  g399(.A(new_n136_), .B(new_n197_), .Y(new_n421_));
  OA21x2_ASAP7_75t_R  g400(.A1(new_n219_), .A2(new_n421_), .B(new_n78_), .Y(new_n422_));
  NOR2x1_ASAP7_75t_R  g401(.A(p5), .B(new_n23_), .Y(new_n423_));
  AO21x1_ASAP7_75t_R  g402(.A1(new_n22_), .A2(new_n360_), .B(new_n28_), .Y(new_n424_));
  AO21x1_ASAP7_75t_R  g403(.A1(new_n423_), .A2(new_n424_), .B(new_n143_), .Y(new_n425_));
  NOR2x1_ASAP7_75t_R  g404(.A(new_n422_), .B(new_n425_), .Y(new_n426_));
  AOI21x1_ASAP7_75t_R g405(.A1(new_n107_), .A2(new_n420_), .B(new_n426_), .Y(new_n427_));
  NOR3x1_ASAP7_75t_R  g406(.A(new_n413_), .B(new_n48_), .C(new_n252_), .Y(new_n428_));
  AO21x1_ASAP7_75t_R  g407(.A1(p2), .A2(p4), .B(new_n99_), .Y(new_n429_));
  NAND3x1_ASAP7_75t_R g408(.A(new_n332_), .B(new_n22_), .C(new_n94_), .Y(new_n430_));
  OAI21x1_ASAP7_75t_R g409(.A1(new_n429_), .A2(new_n137_), .B(new_n430_), .Y(new_n431_));
  OAI21x1_ASAP7_75t_R g410(.A1(new_n428_), .A2(new_n431_), .B(new_n41_), .Y(new_n432_));
  INVx1_ASAP7_75t_R   g411(.A(new_n152_), .Y(new_n433_));
  OR3x1_ASAP7_75t_R   g412(.A(new_n433_), .B(new_n125_), .C(new_n252_), .Y(new_n434_));
  OR3x1_ASAP7_75t_R   g413(.A(new_n25_), .B(new_n39_), .C(p1), .Y(new_n435_));
  NAND2x1_ASAP7_75t_R g414(.A(p1), .B(new_n94_), .Y(new_n436_));
  AO21x1_ASAP7_75t_R  g415(.A1(new_n37_), .A2(p2), .B(new_n266_), .Y(new_n437_));
  AO21x1_ASAP7_75t_R  g416(.A1(new_n435_), .A2(new_n436_), .B(new_n437_), .Y(new_n438_));
  OA21x2_ASAP7_75t_R  g417(.A1(new_n41_), .A2(new_n434_), .B(new_n438_), .Y(new_n439_));
  AO21x1_ASAP7_75t_R  g418(.A1(new_n432_), .A2(new_n439_), .B(p5), .Y(new_n440_));
  NAND2x1_ASAP7_75t_R g419(.A(new_n427_), .B(new_n440_), .Y(new_n441_));
  OR3x1_ASAP7_75t_R   g420(.A(new_n37_), .B(new_n78_), .C(p9), .Y(new_n442_));
  INVx1_ASAP7_75t_R   g421(.A(new_n35_), .Y(new_n443_));
  AO21x1_ASAP7_75t_R  g422(.A1(new_n124_), .A2(new_n442_), .B(new_n443_), .Y(new_n444_));
  NAND2x1_ASAP7_75t_R g423(.A(p1), .B(new_n37_), .Y(new_n445_));
  OR3x1_ASAP7_75t_R   g424(.A(new_n24_), .B(new_n445_), .C(p9), .Y(new_n446_));
  INVx1_ASAP7_75t_R   g425(.A(new_n59_), .Y(new_n447_));
  OR3x1_ASAP7_75t_R   g426(.A(new_n97_), .B(p7), .C(new_n447_), .Y(new_n448_));
  AND3x1_ASAP7_75t_R  g427(.A(new_n444_), .B(new_n446_), .C(new_n448_), .Y(new_n449_));
  OR3x1_ASAP7_75t_R   g428(.A(new_n162_), .B(new_n110_), .C(p4), .Y(new_n450_));
  OAI21x1_ASAP7_75t_R g429(.A1(new_n174_), .A2(new_n449_), .B(new_n450_), .Y(new_n451_));
  AOI21x1_ASAP7_75t_R g430(.A1(new_n75_), .A2(new_n441_), .B(new_n451_), .Y(o8));
  OA21x2_ASAP7_75t_R  g431(.A1(p2), .A2(new_n84_), .B(new_n136_), .Y(new_n453_));
  AND2x2_ASAP7_75t_R  g432(.A(p2), .B(new_n163_), .Y(new_n454_));
  OR3x1_ASAP7_75t_R   g433(.A(new_n453_), .B(p1), .C(new_n454_), .Y(new_n455_));
  INVx1_ASAP7_75t_R   g434(.A(new_n268_), .Y(new_n456_));
  OR3x1_ASAP7_75t_R   g435(.A(new_n456_), .B(p2), .C(new_n107_), .Y(new_n457_));
  OA21x2_ASAP7_75t_R  g436(.A1(new_n290_), .A2(new_n278_), .B(new_n457_), .Y(new_n458_));
  AO21x1_ASAP7_75t_R  g437(.A1(new_n455_), .A2(new_n458_), .B(new_n22_), .Y(new_n459_));
  OR3x1_ASAP7_75t_R   g438(.A(new_n136_), .B(new_n113_), .C(new_n287_), .Y(new_n460_));
  AND3x1_ASAP7_75t_R  g439(.A(new_n333_), .B(new_n25_), .C(new_n290_), .Y(new_n461_));
  OA21x2_ASAP7_75t_R  g440(.A1(new_n287_), .A2(new_n301_), .B(new_n78_), .Y(new_n462_));
  OAI21x1_ASAP7_75t_R g441(.A1(new_n461_), .A2(new_n462_), .B(new_n22_), .Y(new_n463_));
  AO21x1_ASAP7_75t_R  g442(.A1(new_n454_), .A2(new_n460_), .B(new_n463_), .Y(new_n464_));
  AO21x1_ASAP7_75t_R  g443(.A1(new_n39_), .A2(new_n26_), .B(new_n32_), .Y(new_n465_));
  AO21x1_ASAP7_75t_R  g444(.A1(p1), .A2(new_n25_), .B(new_n81_), .Y(new_n466_));
  AND3x1_ASAP7_75t_R  g445(.A(new_n465_), .B(new_n234_), .C(new_n466_), .Y(new_n467_));
  NAND2x1_ASAP7_75t_R g446(.A(new_n126_), .B(new_n277_), .Y(new_n468_));
  AO21x1_ASAP7_75t_R  g447(.A1(new_n81_), .A2(new_n468_), .B(new_n316_), .Y(new_n469_));
  OR3x1_ASAP7_75t_R   g448(.A(p2), .B(p1), .C(p0), .Y(new_n470_));
  AO21x1_ASAP7_75t_R  g449(.A1(new_n81_), .A2(new_n470_), .B(new_n28_), .Y(new_n471_));
  AND3x1_ASAP7_75t_R  g450(.A(new_n467_), .B(new_n469_), .C(new_n471_), .Y(new_n472_));
  AND3x1_ASAP7_75t_R  g451(.A(new_n459_), .B(new_n464_), .C(new_n472_), .Y(o9));
  INVx1_ASAP7_75t_R   g452(.A(new_n93_), .Y(new_n474_));
  OR3x1_ASAP7_75t_R   g453(.A(new_n474_), .B(new_n197_), .C(new_n37_), .Y(new_n475_));
  AND3x1_ASAP7_75t_R  g454(.A(new_n24_), .B(new_n110_), .C(p2), .Y(new_n476_));
  AND3x1_ASAP7_75t_R  g455(.A(new_n475_), .B(new_n170_), .C(new_n476_), .Y(new_n477_));
  AO21x1_ASAP7_75t_R  g456(.A1(new_n410_), .A2(new_n477_), .B(new_n411_), .Y(o10));
endmodule


