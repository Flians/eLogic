// Benchmark "/tmp/" written by ABC on Tue Oct 13 13:54:47 2026

module \/tmp/  ( 
    p1, p4, p3, p5, p6, p2, p0,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25  );
  input  p1, p4, p3, p5, p6, p2, p0;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25;
  wire new_n34_, new_n35_, new_n36_, new_n37_, new_n39_, new_n40_, new_n41_,
    new_n42_, new_n43_, new_n44_, new_n45_, new_n46_, new_n47_, new_n49_,
    new_n50_, new_n51_, new_n52_, new_n53_, new_n54_, new_n55_, new_n57_,
    new_n58_, new_n59_, new_n61_, new_n62_, new_n63_, new_n64_, new_n65_,
    new_n66_, new_n67_, new_n68_, new_n69_, new_n71_, new_n72_, new_n73_,
    new_n74_, new_n76_, new_n77_, new_n78_, new_n80_, new_n81_, new_n82_,
    new_n84_, new_n85_, new_n86_, new_n89_, new_n90_, new_n91_, new_n92_,
    new_n93_, new_n96_, new_n97_, new_n98_, new_n102_, new_n104_,
    new_n105_, new_n110_, new_n111_, new_n112_, new_n114_, new_n115_,
    new_n116_, new_n117_, new_n121_;
  NAND2x1_ASAP7_75t_R g00(.A(p3), .B(p2), .Y(new_n34_));
  NOR3x1_ASAP7_75t_R  g01(.A(p1), .B(p6), .C(p0), .Y(new_n35_));
  NOR2x1_ASAP7_75t_R  g02(.A(p3), .B(p2), .Y(new_n36_));
  NAND3x1_ASAP7_75t_R g03(.A(new_n36_), .B(p1), .C(p0), .Y(new_n37_));
  OAI21x1_ASAP7_75t_R g04(.A1(new_n34_), .A2(new_n35_), .B(new_n37_), .Y(o0));
  INVx1_ASAP7_75t_R   g05(.A(p1), .Y(new_n39_));
  AO21x1_ASAP7_75t_R  g06(.A1(p3), .A2(p2), .B(p0), .Y(new_n40_));
  OAI21x1_ASAP7_75t_R g07(.A1(new_n39_), .A2(new_n36_), .B(new_n40_), .Y(new_n41_));
  NAND2x1_ASAP7_75t_R g08(.A(p0), .B(new_n39_), .Y(new_n42_));
  INVx1_ASAP7_75t_R   g09(.A(p3), .Y(new_n43_));
  NOR2x1_ASAP7_75t_R  g10(.A(p2), .B(new_n43_), .Y(new_n44_));
  NOR2x1_ASAP7_75t_R  g11(.A(p1), .B(p0), .Y(new_n45_));
  NAND2x1_ASAP7_75t_R g12(.A(p6), .B(new_n45_), .Y(new_n46_));
  OAI21x1_ASAP7_75t_R g13(.A1(new_n42_), .A2(new_n44_), .B(new_n46_), .Y(new_n47_));
  NOR2x1_ASAP7_75t_R  g14(.A(new_n41_), .B(new_n47_), .Y(o1));
  OR3x1_ASAP7_75t_R   g15(.A(new_n43_), .B(p6), .C(p2), .Y(new_n49_));
  INVx1_ASAP7_75t_R   g16(.A(p0), .Y(new_n50_));
  INVx1_ASAP7_75t_R   g17(.A(p2), .Y(new_n51_));
  NOR2x1_ASAP7_75t_R  g18(.A(p3), .B(new_n51_), .Y(new_n52_));
  NOR2x1_ASAP7_75t_R  g19(.A(new_n50_), .B(new_n52_), .Y(new_n53_));
  NAND2x1_ASAP7_75t_R g20(.A(p6), .B(new_n50_), .Y(new_n54_));
  NAND3x1_ASAP7_75t_R g21(.A(new_n54_), .B(new_n39_), .C(new_n40_), .Y(new_n55_));
  AOI21x1_ASAP7_75t_R g22(.A1(new_n49_), .A2(new_n53_), .B(new_n55_), .Y(o2));
  AND3x1_ASAP7_75t_R  g23(.A(new_n39_), .B(new_n50_), .C(p2), .Y(new_n57_));
  AND2x2_ASAP7_75t_R  g24(.A(p3), .B(p2), .Y(new_n58_));
  NAND2x1_ASAP7_75t_R g25(.A(p6), .B(new_n58_), .Y(new_n59_));
  OA21x2_ASAP7_75t_R  g26(.A1(new_n44_), .A2(new_n57_), .B(new_n59_), .Y(o3));
  AND3x1_ASAP7_75t_R  g27(.A(p6), .B(p2), .C(p0), .Y(new_n61_));
  INVx1_ASAP7_75t_R   g28(.A(p4), .Y(new_n62_));
  INVx1_ASAP7_75t_R   g29(.A(p5), .Y(new_n63_));
  OAI21x1_ASAP7_75t_R g30(.A1(new_n62_), .A2(new_n63_), .B(p3), .Y(new_n64_));
  NAND2x1_ASAP7_75t_R g31(.A(new_n61_), .B(new_n64_), .Y(new_n65_));
  AND3x1_ASAP7_75t_R  g32(.A(p4), .B(p3), .C(p2), .Y(new_n66_));
  NOR2x1_ASAP7_75t_R  g33(.A(p6), .B(new_n50_), .Y(new_n67_));
  AOI21x1_ASAP7_75t_R g34(.A1(new_n66_), .A2(new_n67_), .B(p1), .Y(new_n68_));
  AOI21x1_ASAP7_75t_R g35(.A1(p6), .A2(new_n44_), .B(new_n39_), .Y(new_n69_));
  AOI21x1_ASAP7_75t_R g36(.A1(new_n65_), .A2(new_n68_), .B(new_n69_), .Y(o4));
  AO21x1_ASAP7_75t_R  g37(.A1(p5), .A2(p2), .B(p1), .Y(new_n71_));
  NOR2x1_ASAP7_75t_R  g38(.A(new_n71_), .B(new_n52_), .Y(new_n72_));
  NAND2x1_ASAP7_75t_R g39(.A(p3), .B(new_n51_), .Y(new_n73_));
  AO21x1_ASAP7_75t_R  g40(.A1(p1), .A2(new_n73_), .B(new_n50_), .Y(new_n74_));
  NOR2x1_ASAP7_75t_R  g41(.A(new_n72_), .B(new_n74_), .Y(o5));
  AND2x2_ASAP7_75t_R  g42(.A(p6), .B(p0), .Y(new_n76_));
  NOR2x1_ASAP7_75t_R  g43(.A(new_n34_), .B(new_n76_), .Y(new_n77_));
  AO21x1_ASAP7_75t_R  g44(.A1(p1), .A2(new_n34_), .B(new_n36_), .Y(new_n78_));
  AOI21x1_ASAP7_75t_R g45(.A1(new_n39_), .A2(new_n77_), .B(new_n78_), .Y(o6));
  INVx1_ASAP7_75t_R   g46(.A(p6), .Y(new_n80_));
  OR3x1_ASAP7_75t_R   g47(.A(new_n34_), .B(new_n39_), .C(new_n80_), .Y(new_n81_));
  NAND2x1_ASAP7_75t_R g48(.A(new_n58_), .B(new_n35_), .Y(new_n82_));
  NAND3x1_ASAP7_75t_R g49(.A(new_n81_), .B(new_n82_), .C(new_n37_), .Y(o7));
  NAND2x1_ASAP7_75t_R g50(.A(p0), .B(new_n36_), .Y(new_n84_));
  AO21x1_ASAP7_75t_R  g51(.A1(p1), .A2(new_n34_), .B(new_n50_), .Y(new_n85_));
  AOI21x1_ASAP7_75t_R g52(.A1(new_n80_), .A2(new_n44_), .B(new_n42_), .Y(new_n86_));
  AOI21x1_ASAP7_75t_R g53(.A1(new_n84_), .A2(new_n85_), .B(new_n86_), .Y(o8));
  NOR2x1_ASAP7_75t_R  g54(.A(new_n41_), .B(new_n86_), .Y(o9));
  NOR2x1_ASAP7_75t_R  g55(.A(p1), .B(p2), .Y(new_n89_));
  AO21x1_ASAP7_75t_R  g56(.A1(p3), .A2(new_n45_), .B(new_n89_), .Y(new_n90_));
  NOR2x1_ASAP7_75t_R  g57(.A(new_n39_), .B(new_n44_), .Y(new_n91_));
  NAND2x1_ASAP7_75t_R g58(.A(p0), .B(new_n80_), .Y(new_n92_));
  NAND2x1_ASAP7_75t_R g59(.A(new_n92_), .B(new_n44_), .Y(new_n93_));
  OAI21x1_ASAP7_75t_R g60(.A1(new_n90_), .A2(new_n91_), .B(new_n93_), .Y(o10));
  AND3x1_ASAP7_75t_R  g61(.A(new_n45_), .B(new_n36_), .C(new_n80_), .Y(o11));
  AO21x1_ASAP7_75t_R  g62(.A1(new_n80_), .A2(new_n50_), .B(new_n43_), .Y(new_n96_));
  NAND2x1_ASAP7_75t_R g63(.A(p1), .B(new_n43_), .Y(new_n97_));
  AOI21x1_ASAP7_75t_R g64(.A1(new_n51_), .A2(p0), .B(new_n97_), .Y(new_n98_));
  AOI21x1_ASAP7_75t_R g65(.A1(new_n89_), .A2(new_n96_), .B(new_n98_), .Y(o12));
  AND3x1_ASAP7_75t_R  g66(.A(new_n36_), .B(p1), .C(p6), .Y(o13));
  AND3x1_ASAP7_75t_R  g67(.A(new_n36_), .B(p1), .C(new_n80_), .Y(o14));
  NOR2x1_ASAP7_75t_R  g68(.A(p6), .B(p0), .Y(new_n102_));
  AND3x1_ASAP7_75t_R  g69(.A(new_n52_), .B(p1), .C(new_n102_), .Y(o15));
  AND2x2_ASAP7_75t_R  g70(.A(p6), .B(p2), .Y(new_n104_));
  NOR2x1_ASAP7_75t_R  g71(.A(p3), .B(p0), .Y(new_n105_));
  AND3x1_ASAP7_75t_R  g72(.A(new_n104_), .B(p1), .C(new_n105_), .Y(o16));
  AND3x1_ASAP7_75t_R  g73(.A(new_n61_), .B(p1), .C(new_n43_), .Y(o17));
  AND3x1_ASAP7_75t_R  g74(.A(new_n52_), .B(new_n67_), .C(p1), .Y(o18));
  AND3x1_ASAP7_75t_R  g75(.A(new_n43_), .B(new_n51_), .C(p1), .Y(o19));
  OAI21x1_ASAP7_75t_R g76(.A1(p4), .A2(new_n43_), .B(new_n61_), .Y(new_n110_));
  AOI21x1_ASAP7_75t_R g77(.A1(new_n105_), .A2(new_n104_), .B(p1), .Y(new_n111_));
  OA21x2_ASAP7_75t_R  g78(.A1(new_n34_), .A2(new_n76_), .B(p1), .Y(new_n112_));
  AOI21x1_ASAP7_75t_R g79(.A1(new_n110_), .A2(new_n111_), .B(new_n112_), .Y(o20));
  NAND2x1_ASAP7_75t_R g80(.A(p2), .B(new_n105_), .Y(new_n114_));
  NAND2x1_ASAP7_75t_R g81(.A(p4), .B(p0), .Y(new_n115_));
  OR3x1_ASAP7_75t_R   g82(.A(new_n34_), .B(new_n115_), .C(p5), .Y(new_n116_));
  NAND2x1_ASAP7_75t_R g83(.A(p6), .B(new_n39_), .Y(new_n117_));
  AOI21x1_ASAP7_75t_R g84(.A1(new_n114_), .A2(new_n116_), .B(new_n117_), .Y(o21));
  AOI21x1_ASAP7_75t_R g85(.A1(new_n39_), .A2(new_n65_), .B(new_n112_), .Y(o22));
  assign              o23 = 1'b1;
  AND3x1_ASAP7_75t_R  g86(.A(new_n39_), .B(new_n51_), .C(p3), .Y(new_n121_));
  AND3x1_ASAP7_75t_R  g87(.A(new_n121_), .B(new_n54_), .C(new_n92_), .Y(o24));
  NOR2x1_ASAP7_75t_R  g88(.A(new_n73_), .B(new_n46_), .Y(o25));
endmodule


