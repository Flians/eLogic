// Benchmark "/tmp/" written by ABC on Tue Oct 13 13:54:46 2026

module \/tmp/  ( 
    p0, p4, p5, p3, p1, p2, p6,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25  );
  input  p0, p4, p5, p3, p1, p2, p6;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25;
  wire new_n34_, new_n35_, new_n36_, new_n37_, new_n39_, new_n40_, new_n41_,
    new_n42_, new_n43_, new_n44_, new_n45_, new_n46_, new_n47_, new_n49_,
    new_n50_, new_n51_, new_n52_, new_n53_, new_n54_, new_n55_, new_n57_,
    new_n58_, new_n60_, new_n61_, new_n62_, new_n63_, new_n64_, new_n65_,
    new_n66_, new_n67_, new_n68_, new_n69_, new_n71_, new_n72_, new_n74_,
    new_n75_, new_n76_, new_n78_, new_n79_, new_n81_, new_n82_, new_n84_,
    new_n86_, new_n87_, new_n88_, new_n89_, new_n91_, new_n93_, new_n94_,
    new_n95_, new_n100_, new_n105_, new_n106_, new_n107_, new_n109_,
    new_n110_, new_n111_, new_n115_, new_n116_;
  AND2x2_ASAP7_75t_R  g00(.A(p3), .B(p2), .Y(new_n34_));
  OR3x1_ASAP7_75t_R   g01(.A(p0), .B(p1), .C(p6), .Y(new_n35_));
  NOR2x1_ASAP7_75t_R  g02(.A(p3), .B(p2), .Y(new_n36_));
  AND3x1_ASAP7_75t_R  g03(.A(new_n36_), .B(p0), .C(p1), .Y(new_n37_));
  AO21x1_ASAP7_75t_R  g04(.A1(new_n34_), .A2(new_n35_), .B(new_n37_), .Y(o0));
  INVx1_ASAP7_75t_R   g05(.A(p1), .Y(new_n39_));
  NAND2x1_ASAP7_75t_R g06(.A(p0), .B(new_n39_), .Y(new_n40_));
  INVx1_ASAP7_75t_R   g07(.A(p3), .Y(new_n41_));
  NOR2x1_ASAP7_75t_R  g08(.A(p2), .B(new_n41_), .Y(new_n42_));
  NOR2x1_ASAP7_75t_R  g09(.A(new_n40_), .B(new_n42_), .Y(new_n43_));
  AOI21x1_ASAP7_75t_R g10(.A1(p0), .A2(new_n36_), .B(new_n39_), .Y(new_n44_));
  NAND2x1_ASAP7_75t_R g11(.A(p3), .B(p2), .Y(new_n45_));
  NOR2x1_ASAP7_75t_R  g12(.A(p0), .B(p1), .Y(new_n46_));
  OA21x2_ASAP7_75t_R  g13(.A1(p6), .A2(new_n45_), .B(new_n46_), .Y(new_n47_));
  NOR3x1_ASAP7_75t_R  g14(.A(new_n43_), .B(new_n44_), .C(new_n47_), .Y(o1));
  OR3x1_ASAP7_75t_R   g15(.A(new_n41_), .B(p2), .C(p6), .Y(new_n49_));
  INVx1_ASAP7_75t_R   g16(.A(p0), .Y(new_n50_));
  INVx1_ASAP7_75t_R   g17(.A(p2), .Y(new_n51_));
  NOR2x1_ASAP7_75t_R  g18(.A(p3), .B(new_n51_), .Y(new_n52_));
  NOR2x1_ASAP7_75t_R  g19(.A(new_n50_), .B(new_n52_), .Y(new_n53_));
  NOR2x1_ASAP7_75t_R  g20(.A(p6), .B(new_n45_), .Y(new_n54_));
  OAI21x1_ASAP7_75t_R g21(.A1(p0), .A2(new_n54_), .B(new_n39_), .Y(new_n55_));
  AOI21x1_ASAP7_75t_R g22(.A1(new_n49_), .A2(new_n53_), .B(new_n55_), .Y(o2));
  AND3x1_ASAP7_75t_R  g23(.A(new_n50_), .B(new_n39_), .C(p2), .Y(new_n57_));
  NAND2x1_ASAP7_75t_R g24(.A(p6), .B(new_n34_), .Y(new_n58_));
  OA21x2_ASAP7_75t_R  g25(.A1(new_n42_), .A2(new_n57_), .B(new_n58_), .Y(o3));
  AND2x2_ASAP7_75t_R  g26(.A(p0), .B(p4), .Y(new_n60_));
  NAND2x1_ASAP7_75t_R g27(.A(new_n60_), .B(new_n54_), .Y(new_n61_));
  AND3x1_ASAP7_75t_R  g28(.A(p0), .B(p2), .C(p6), .Y(new_n62_));
  INVx1_ASAP7_75t_R   g29(.A(p4), .Y(new_n63_));
  INVx1_ASAP7_75t_R   g30(.A(p5), .Y(new_n64_));
  OAI21x1_ASAP7_75t_R g31(.A1(new_n63_), .A2(new_n64_), .B(p3), .Y(new_n65_));
  AOI21x1_ASAP7_75t_R g32(.A1(new_n62_), .A2(new_n65_), .B(p1), .Y(new_n66_));
  INVx1_ASAP7_75t_R   g33(.A(p6), .Y(new_n67_));
  NAND2x1_ASAP7_75t_R g34(.A(p3), .B(new_n51_), .Y(new_n68_));
  OA21x2_ASAP7_75t_R  g35(.A1(new_n67_), .A2(new_n68_), .B(p1), .Y(new_n69_));
  AOI21x1_ASAP7_75t_R g36(.A1(new_n61_), .A2(new_n66_), .B(new_n69_), .Y(o4));
  AO21x1_ASAP7_75t_R  g37(.A1(p3), .A2(new_n64_), .B(new_n51_), .Y(new_n71_));
  AO21x1_ASAP7_75t_R  g38(.A1(p1), .A2(new_n68_), .B(new_n50_), .Y(new_n72_));
  AOI21x1_ASAP7_75t_R g39(.A1(new_n39_), .A2(new_n71_), .B(new_n72_), .Y(o5));
  AO21x1_ASAP7_75t_R  g40(.A1(p1), .A2(new_n45_), .B(new_n36_), .Y(new_n74_));
  NAND2x1_ASAP7_75t_R g41(.A(p0), .B(p6), .Y(new_n75_));
  AND3x1_ASAP7_75t_R  g42(.A(new_n34_), .B(new_n39_), .C(new_n75_), .Y(new_n76_));
  NOR2x1_ASAP7_75t_R  g43(.A(new_n74_), .B(new_n76_), .Y(o6));
  AND3x1_ASAP7_75t_R  g44(.A(new_n34_), .B(p1), .C(p6), .Y(new_n78_));
  AND3x1_ASAP7_75t_R  g45(.A(new_n34_), .B(new_n67_), .C(new_n46_), .Y(new_n79_));
  OR3x1_ASAP7_75t_R   g46(.A(new_n78_), .B(new_n79_), .C(new_n37_), .Y(o7));
  AOI21x1_ASAP7_75t_R g47(.A1(new_n67_), .A2(new_n42_), .B(new_n40_), .Y(new_n81_));
  NOR3x1_ASAP7_75t_R  g48(.A(new_n34_), .B(new_n39_), .C(new_n36_), .Y(new_n82_));
  NOR3x1_ASAP7_75t_R  g49(.A(new_n81_), .B(new_n50_), .C(new_n82_), .Y(o8));
  AND2x2_ASAP7_75t_R  g50(.A(new_n50_), .B(new_n45_), .Y(new_n84_));
  NOR3x1_ASAP7_75t_R  g51(.A(new_n81_), .B(new_n44_), .C(new_n84_), .Y(o9));
  NOR2x1_ASAP7_75t_R  g52(.A(new_n39_), .B(new_n42_), .Y(new_n86_));
  NOR2x1_ASAP7_75t_R  g53(.A(p1), .B(p2), .Y(new_n87_));
  AO21x1_ASAP7_75t_R  g54(.A1(p3), .A2(new_n46_), .B(new_n87_), .Y(new_n88_));
  AO21x1_ASAP7_75t_R  g55(.A1(p0), .A2(new_n67_), .B(new_n68_), .Y(new_n89_));
  OAI21x1_ASAP7_75t_R g56(.A1(new_n86_), .A2(new_n88_), .B(new_n89_), .Y(o10));
  NOR2x1_ASAP7_75t_R  g57(.A(p0), .B(p6), .Y(new_n91_));
  AND3x1_ASAP7_75t_R  g58(.A(new_n36_), .B(new_n91_), .C(new_n39_), .Y(o11));
  OA21x2_ASAP7_75t_R  g59(.A1(new_n41_), .A2(new_n91_), .B(new_n87_), .Y(new_n93_));
  AND3x1_ASAP7_75t_R  g60(.A(new_n50_), .B(new_n41_), .C(p1), .Y(new_n94_));
  AND3x1_ASAP7_75t_R  g61(.A(new_n41_), .B(p1), .C(p2), .Y(new_n95_));
  NOR3x1_ASAP7_75t_R  g62(.A(new_n93_), .B(new_n94_), .C(new_n95_), .Y(o12));
  AND3x1_ASAP7_75t_R  g63(.A(new_n36_), .B(p1), .C(p6), .Y(o13));
  AND3x1_ASAP7_75t_R  g64(.A(new_n36_), .B(p1), .C(new_n67_), .Y(o14));
  AND3x1_ASAP7_75t_R  g65(.A(new_n52_), .B(p1), .C(new_n91_), .Y(o15));
  NOR2x1_ASAP7_75t_R  g66(.A(p0), .B(new_n67_), .Y(new_n100_));
  AND3x1_ASAP7_75t_R  g67(.A(new_n100_), .B(new_n52_), .C(p1), .Y(o16));
  AND3x1_ASAP7_75t_R  g68(.A(new_n62_), .B(new_n41_), .C(p1), .Y(o17));
  AND3x1_ASAP7_75t_R  g69(.A(new_n95_), .B(p0), .C(new_n67_), .Y(o18));
  AND3x1_ASAP7_75t_R  g70(.A(new_n41_), .B(new_n51_), .C(p1), .Y(o19));
  OAI21x1_ASAP7_75t_R g71(.A1(p4), .A2(new_n41_), .B(new_n62_), .Y(new_n105_));
  AOI21x1_ASAP7_75t_R g72(.A1(new_n100_), .A2(new_n52_), .B(p1), .Y(new_n106_));
  AOI21x1_ASAP7_75t_R g73(.A1(new_n75_), .A2(new_n34_), .B(new_n39_), .Y(new_n107_));
  AOI21x1_ASAP7_75t_R g74(.A1(new_n105_), .A2(new_n106_), .B(new_n107_), .Y(o20));
  NOR2x1_ASAP7_75t_R  g75(.A(p0), .B(p3), .Y(new_n109_));
  AND3x1_ASAP7_75t_R  g76(.A(new_n60_), .B(new_n64_), .C(p3), .Y(new_n110_));
  AND3x1_ASAP7_75t_R  g77(.A(new_n39_), .B(p2), .C(p6), .Y(new_n111_));
  OA21x2_ASAP7_75t_R  g78(.A1(new_n109_), .A2(new_n110_), .B(new_n111_), .Y(o21));
  NOR2x1_ASAP7_75t_R  g79(.A(new_n107_), .B(new_n66_), .Y(o22));
  assign              o23 = 1'b1;
  INVx1_ASAP7_75t_R   g80(.A(new_n91_), .Y(new_n115_));
  NAND2x1_ASAP7_75t_R g81(.A(new_n75_), .B(new_n115_), .Y(new_n116_));
  AND3x1_ASAP7_75t_R  g82(.A(new_n116_), .B(p3), .C(new_n87_), .Y(o24));
  AND3x1_ASAP7_75t_R  g83(.A(new_n100_), .B(p3), .C(new_n87_), .Y(o25));
endmodule


