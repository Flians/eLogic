// Benchmark "/tmp/" written by ABC on Tue Oct 13 13:54:46 2026

module \/tmp/  ( 
    p6, p0, p5, p2, p4, p1, p3,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25  );
  input  p6, p0, p5, p2, p4, p1, p3;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25;
  wire new_n34_, new_n35_, new_n36_, new_n37_, new_n39_, new_n40_, new_n41_,
    new_n42_, new_n43_, new_n44_, new_n45_, new_n46_, new_n47_, new_n49_,
    new_n50_, new_n51_, new_n52_, new_n53_, new_n54_, new_n55_, new_n56_,
    new_n58_, new_n59_, new_n61_, new_n62_, new_n63_, new_n64_, new_n65_,
    new_n66_, new_n67_, new_n68_, new_n69_, new_n70_, new_n71_, new_n73_,
    new_n74_, new_n75_, new_n77_, new_n78_, new_n79_, new_n81_, new_n82_,
    new_n83_, new_n85_, new_n86_, new_n88_, new_n90_, new_n91_, new_n94_,
    new_n95_, new_n99_, new_n101_, new_n103_, new_n107_, new_n108_,
    new_n109_, new_n111_, new_n112_, new_n116_;
  AND2x2_ASAP7_75t_R  g00(.A(p2), .B(p3), .Y(new_n34_));
  OR3x1_ASAP7_75t_R   g01(.A(p6), .B(p0), .C(p1), .Y(new_n35_));
  NOR2x1_ASAP7_75t_R  g02(.A(p2), .B(p3), .Y(new_n36_));
  AND3x1_ASAP7_75t_R  g03(.A(new_n36_), .B(p0), .C(p1), .Y(new_n37_));
  AO21x1_ASAP7_75t_R  g04(.A1(new_n34_), .A2(new_n35_), .B(new_n37_), .Y(o0));
  INVx1_ASAP7_75t_R   g05(.A(p1), .Y(new_n39_));
  NAND2x1_ASAP7_75t_R g06(.A(p0), .B(new_n39_), .Y(new_n40_));
  INVx1_ASAP7_75t_R   g07(.A(p3), .Y(new_n41_));
  NOR2x1_ASAP7_75t_R  g08(.A(p2), .B(new_n41_), .Y(new_n42_));
  NOR2x1_ASAP7_75t_R  g09(.A(new_n40_), .B(new_n42_), .Y(new_n43_));
  NAND2x1_ASAP7_75t_R g10(.A(p2), .B(p3), .Y(new_n44_));
  NOR2x1_ASAP7_75t_R  g11(.A(p0), .B(p1), .Y(new_n45_));
  OA21x2_ASAP7_75t_R  g12(.A1(p6), .A2(new_n44_), .B(new_n45_), .Y(new_n46_));
  AOI21x1_ASAP7_75t_R g13(.A1(p0), .A2(new_n36_), .B(new_n39_), .Y(new_n47_));
  NOR3x1_ASAP7_75t_R  g14(.A(new_n43_), .B(new_n46_), .C(new_n47_), .Y(o1));
  OR3x1_ASAP7_75t_R   g15(.A(new_n41_), .B(p6), .C(p2), .Y(new_n49_));
  INVx1_ASAP7_75t_R   g16(.A(p0), .Y(new_n50_));
  INVx1_ASAP7_75t_R   g17(.A(p2), .Y(new_n51_));
  NOR2x1_ASAP7_75t_R  g18(.A(p3), .B(new_n51_), .Y(new_n52_));
  NOR2x1_ASAP7_75t_R  g19(.A(new_n50_), .B(new_n52_), .Y(new_n53_));
  INVx1_ASAP7_75t_R   g20(.A(p6), .Y(new_n54_));
  NAND2x1_ASAP7_75t_R g21(.A(new_n54_), .B(new_n39_), .Y(new_n55_));
  OA21x2_ASAP7_75t_R  g22(.A1(new_n44_), .A2(new_n55_), .B(new_n40_), .Y(new_n56_));
  AOI21x1_ASAP7_75t_R g23(.A1(new_n49_), .A2(new_n53_), .B(new_n56_), .Y(o2));
  NOR2x1_ASAP7_75t_R  g24(.A(new_n51_), .B(new_n45_), .Y(new_n58_));
  AO21x1_ASAP7_75t_R  g25(.A1(p6), .A2(new_n34_), .B(new_n36_), .Y(new_n59_));
  NOR2x1_ASAP7_75t_R  g26(.A(new_n58_), .B(new_n59_), .Y(o3));
  INVx1_ASAP7_75t_R   g27(.A(p5), .Y(new_n61_));
  NAND2x1_ASAP7_75t_R g28(.A(p3), .B(new_n61_), .Y(new_n62_));
  INVx1_ASAP7_75t_R   g29(.A(p4), .Y(new_n63_));
  NAND2x1_ASAP7_75t_R g30(.A(p3), .B(new_n63_), .Y(new_n64_));
  AND3x1_ASAP7_75t_R  g31(.A(p6), .B(p0), .C(p2), .Y(new_n65_));
  NAND3x1_ASAP7_75t_R g32(.A(new_n62_), .B(new_n64_), .C(new_n65_), .Y(new_n66_));
  AND2x2_ASAP7_75t_R  g33(.A(p0), .B(p4), .Y(new_n67_));
  NOR2x1_ASAP7_75t_R  g34(.A(p6), .B(new_n44_), .Y(new_n68_));
  AOI21x1_ASAP7_75t_R g35(.A1(new_n67_), .A2(new_n68_), .B(p1), .Y(new_n69_));
  NAND2x1_ASAP7_75t_R g36(.A(p3), .B(new_n51_), .Y(new_n70_));
  OA21x2_ASAP7_75t_R  g37(.A1(new_n54_), .A2(new_n70_), .B(p1), .Y(new_n71_));
  AOI21x1_ASAP7_75t_R g38(.A1(new_n66_), .A2(new_n69_), .B(new_n71_), .Y(o4));
  OAI21x1_ASAP7_75t_R g39(.A1(p1), .A2(new_n62_), .B(p0), .Y(new_n73_));
  NOR2x1_ASAP7_75t_R  g40(.A(new_n39_), .B(new_n42_), .Y(new_n74_));
  NOR2x1_ASAP7_75t_R  g41(.A(p2), .B(p1), .Y(new_n75_));
  NOR3x1_ASAP7_75t_R  g42(.A(new_n73_), .B(new_n74_), .C(new_n75_), .Y(o5));
  AO21x1_ASAP7_75t_R  g43(.A1(new_n51_), .A2(new_n41_), .B(p1), .Y(new_n77_));
  NAND2x1_ASAP7_75t_R g44(.A(p6), .B(p0), .Y(new_n78_));
  AND3x1_ASAP7_75t_R  g45(.A(new_n34_), .B(new_n39_), .C(new_n78_), .Y(new_n79_));
  AOI21x1_ASAP7_75t_R g46(.A1(new_n44_), .A2(new_n77_), .B(new_n79_), .Y(o6));
  NOR2x1_ASAP7_75t_R  g47(.A(p0), .B(p3), .Y(new_n81_));
  NOR2x1_ASAP7_75t_R  g48(.A(new_n39_), .B(new_n81_), .Y(new_n82_));
  NOR2x1_ASAP7_75t_R  g49(.A(new_n44_), .B(new_n35_), .Y(new_n83_));
  AO21x1_ASAP7_75t_R  g50(.A1(new_n82_), .A2(new_n59_), .B(new_n83_), .Y(o7));
  AOI21x1_ASAP7_75t_R g51(.A1(new_n54_), .A2(new_n42_), .B(new_n40_), .Y(new_n85_));
  NOR3x1_ASAP7_75t_R  g52(.A(new_n34_), .B(new_n39_), .C(new_n36_), .Y(new_n86_));
  NOR3x1_ASAP7_75t_R  g53(.A(new_n85_), .B(new_n50_), .C(new_n86_), .Y(o8));
  AND2x2_ASAP7_75t_R  g54(.A(new_n50_), .B(new_n44_), .Y(new_n88_));
  NOR3x1_ASAP7_75t_R  g55(.A(new_n85_), .B(new_n47_), .C(new_n88_), .Y(o9));
  AO21x1_ASAP7_75t_R  g56(.A1(p3), .A2(new_n45_), .B(new_n75_), .Y(new_n90_));
  AO21x1_ASAP7_75t_R  g57(.A1(new_n54_), .A2(p0), .B(new_n70_), .Y(new_n91_));
  OAI21x1_ASAP7_75t_R g58(.A1(new_n74_), .A2(new_n90_), .B(new_n91_), .Y(o10));
  AND3x1_ASAP7_75t_R  g59(.A(new_n45_), .B(new_n36_), .C(new_n54_), .Y(o11));
  AND3x1_ASAP7_75t_R  g60(.A(new_n54_), .B(new_n50_), .C(new_n51_), .Y(new_n94_));
  OR3x1_ASAP7_75t_R   g61(.A(new_n52_), .B(new_n39_), .C(new_n81_), .Y(new_n95_));
  OAI21x1_ASAP7_75t_R g62(.A1(new_n77_), .A2(new_n94_), .B(new_n95_), .Y(o12));
  AND3x1_ASAP7_75t_R  g63(.A(new_n36_), .B(p6), .C(p1), .Y(o13));
  AND3x1_ASAP7_75t_R  g64(.A(new_n36_), .B(new_n54_), .C(p1), .Y(o14));
  NOR2x1_ASAP7_75t_R  g65(.A(p6), .B(new_n39_), .Y(new_n99_));
  AND3x1_ASAP7_75t_R  g66(.A(new_n99_), .B(p2), .C(new_n81_), .Y(o15));
  AND2x2_ASAP7_75t_R  g67(.A(p6), .B(p2), .Y(new_n101_));
  AND3x1_ASAP7_75t_R  g68(.A(new_n101_), .B(p1), .C(new_n81_), .Y(o16));
  INVx1_ASAP7_75t_R   g69(.A(new_n78_), .Y(new_n103_));
  AND3x1_ASAP7_75t_R  g70(.A(new_n103_), .B(new_n52_), .C(p1), .Y(o17));
  AND3x1_ASAP7_75t_R  g71(.A(new_n52_), .B(new_n99_), .C(p0), .Y(o18));
  AND3x1_ASAP7_75t_R  g72(.A(new_n51_), .B(new_n41_), .C(p1), .Y(o19));
  NAND2x1_ASAP7_75t_R g73(.A(new_n65_), .B(new_n64_), .Y(new_n107_));
  AOI21x1_ASAP7_75t_R g74(.A1(new_n81_), .A2(new_n101_), .B(p1), .Y(new_n108_));
  OA21x2_ASAP7_75t_R  g75(.A1(new_n44_), .A2(new_n103_), .B(p1), .Y(new_n109_));
  AOI21x1_ASAP7_75t_R g76(.A1(new_n107_), .A2(new_n108_), .B(new_n109_), .Y(o20));
  AND3x1_ASAP7_75t_R  g77(.A(new_n67_), .B(new_n61_), .C(p3), .Y(new_n111_));
  AND3x1_ASAP7_75t_R  g78(.A(new_n39_), .B(p6), .C(p2), .Y(new_n112_));
  OA21x2_ASAP7_75t_R  g79(.A1(new_n81_), .A2(new_n111_), .B(new_n112_), .Y(o21));
  AOI21x1_ASAP7_75t_R g80(.A1(new_n39_), .A2(new_n66_), .B(new_n109_), .Y(o22));
  assign              o23 = 1'b1;
  XNOR2x2_ASAP7_75t_R g81(.A(p6), .B(p0), .Y(new_n116_));
  AND3x1_ASAP7_75t_R  g82(.A(new_n116_), .B(p3), .C(new_n75_), .Y(o24));
  AND3x1_ASAP7_75t_R  g83(.A(new_n42_), .B(p6), .C(new_n45_), .Y(o25));
endmodule


