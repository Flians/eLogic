// Benchmark "/tmp/" written by ABC on Tue Oct 13 13:54:47 2026

module \/tmp/  ( 
    p4, p5, p3, p1, p2, p6, p0,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25  );
  input  p4, p5, p3, p1, p2, p6, p0;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25;
  wire new_n34_, new_n35_, new_n36_, new_n37_, new_n39_, new_n40_, new_n41_,
    new_n42_, new_n43_, new_n44_, new_n45_, new_n46_, new_n47_, new_n48_,
    new_n50_, new_n51_, new_n52_, new_n53_, new_n54_, new_n55_, new_n57_,
    new_n58_, new_n59_, new_n61_, new_n62_, new_n63_, new_n64_, new_n65_,
    new_n66_, new_n67_, new_n69_, new_n70_, new_n71_, new_n73_, new_n74_,
    new_n75_, new_n77_, new_n78_, new_n80_, new_n81_, new_n82_, new_n83_,
    new_n84_, new_n86_, new_n87_, new_n88_, new_n89_, new_n91_, new_n92_,
    new_n93_, new_n95_, new_n97_, new_n98_, new_n99_, new_n100_, new_n101_,
    new_n106_, new_n108_, new_n112_, new_n113_, new_n114_, new_n115_,
    new_n116_, new_n117_, new_n118_, new_n120_, new_n121_, new_n122_,
    new_n124_, new_n125_, new_n128_;
  AND2x2_ASAP7_75t_R  g00(.A(p3), .B(p2), .Y(new_n34_));
  OR3x1_ASAP7_75t_R   g01(.A(p1), .B(p6), .C(p0), .Y(new_n35_));
  NOR2x1_ASAP7_75t_R  g02(.A(p3), .B(p2), .Y(new_n36_));
  AND3x1_ASAP7_75t_R  g03(.A(new_n36_), .B(p1), .C(p0), .Y(new_n37_));
  AO21x1_ASAP7_75t_R  g04(.A1(new_n34_), .A2(new_n35_), .B(new_n37_), .Y(o0));
  INVx1_ASAP7_75t_R   g05(.A(p2), .Y(new_n39_));
  NAND2x1_ASAP7_75t_R g06(.A(p3), .B(new_n39_), .Y(new_n40_));
  INVx1_ASAP7_75t_R   g07(.A(p0), .Y(new_n41_));
  NOR2x1_ASAP7_75t_R  g08(.A(p1), .B(new_n41_), .Y(new_n42_));
  NAND2x1_ASAP7_75t_R g09(.A(new_n40_), .B(new_n42_), .Y(new_n43_));
  NAND2x1_ASAP7_75t_R g10(.A(p3), .B(p2), .Y(new_n44_));
  NOR2x1_ASAP7_75t_R  g11(.A(p1), .B(p0), .Y(new_n45_));
  OAI21x1_ASAP7_75t_R g12(.A1(p6), .A2(new_n44_), .B(new_n45_), .Y(new_n46_));
  INVx1_ASAP7_75t_R   g13(.A(p1), .Y(new_n47_));
  AO21x1_ASAP7_75t_R  g14(.A1(p0), .A2(new_n36_), .B(new_n47_), .Y(new_n48_));
  AND3x1_ASAP7_75t_R  g15(.A(new_n43_), .B(new_n46_), .C(new_n48_), .Y(o1));
  INVx1_ASAP7_75t_R   g16(.A(p3), .Y(new_n50_));
  OR3x1_ASAP7_75t_R   g17(.A(new_n50_), .B(p2), .C(p6), .Y(new_n51_));
  NOR2x1_ASAP7_75t_R  g18(.A(p3), .B(new_n39_), .Y(new_n52_));
  NOR2x1_ASAP7_75t_R  g19(.A(new_n41_), .B(new_n52_), .Y(new_n53_));
  NOR2x1_ASAP7_75t_R  g20(.A(p1), .B(p6), .Y(new_n54_));
  AOI21x1_ASAP7_75t_R g21(.A1(new_n34_), .A2(new_n54_), .B(new_n42_), .Y(new_n55_));
  AOI21x1_ASAP7_75t_R g22(.A1(new_n51_), .A2(new_n53_), .B(new_n55_), .Y(o2));
  NOR2x1_ASAP7_75t_R  g23(.A(p2), .B(new_n50_), .Y(new_n57_));
  AND3x1_ASAP7_75t_R  g24(.A(new_n47_), .B(new_n41_), .C(p2), .Y(new_n58_));
  NAND2x1_ASAP7_75t_R g25(.A(p6), .B(new_n34_), .Y(new_n59_));
  OA21x2_ASAP7_75t_R  g26(.A1(new_n57_), .A2(new_n58_), .B(new_n59_), .Y(o3));
  AND2x2_ASAP7_75t_R  g27(.A(p4), .B(p5), .Y(new_n61_));
  AND3x1_ASAP7_75t_R  g28(.A(p2), .B(p6), .C(p0), .Y(new_n62_));
  OAI21x1_ASAP7_75t_R g29(.A1(new_n50_), .A2(new_n61_), .B(new_n62_), .Y(new_n63_));
  AND3x1_ASAP7_75t_R  g30(.A(p4), .B(p3), .C(p2), .Y(new_n64_));
  NOR2x1_ASAP7_75t_R  g31(.A(p6), .B(new_n41_), .Y(new_n65_));
  AOI21x1_ASAP7_75t_R g32(.A1(new_n64_), .A2(new_n65_), .B(p1), .Y(new_n66_));
  AOI21x1_ASAP7_75t_R g33(.A1(p6), .A2(new_n57_), .B(new_n47_), .Y(new_n67_));
  AOI21x1_ASAP7_75t_R g34(.A1(new_n63_), .A2(new_n66_), .B(new_n67_), .Y(o4));
  NOR2x1_ASAP7_75t_R  g35(.A(new_n47_), .B(new_n57_), .Y(new_n69_));
  AO21x1_ASAP7_75t_R  g36(.A1(p5), .A2(p2), .B(p1), .Y(new_n70_));
  NOR2x1_ASAP7_75t_R  g37(.A(new_n70_), .B(new_n52_), .Y(new_n71_));
  NOR3x1_ASAP7_75t_R  g38(.A(new_n69_), .B(new_n71_), .C(new_n41_), .Y(o5));
  AO21x1_ASAP7_75t_R  g39(.A1(p6), .A2(p0), .B(p1), .Y(new_n73_));
  NAND2x1_ASAP7_75t_R g40(.A(new_n34_), .B(new_n73_), .Y(new_n74_));
  OR3x1_ASAP7_75t_R   g41(.A(new_n34_), .B(p1), .C(new_n36_), .Y(new_n75_));
  NAND2x1_ASAP7_75t_R g42(.A(new_n74_), .B(new_n75_), .Y(o6));
  NAND2x1_ASAP7_75t_R g43(.A(p1), .B(p6), .Y(new_n77_));
  NAND2x1_ASAP7_75t_R g44(.A(new_n77_), .B(new_n35_), .Y(new_n78_));
  AO21x1_ASAP7_75t_R  g45(.A1(new_n34_), .A2(new_n78_), .B(new_n37_), .Y(o7));
  NAND2x1_ASAP7_75t_R g46(.A(p0), .B(new_n36_), .Y(new_n80_));
  AO21x1_ASAP7_75t_R  g47(.A1(p1), .A2(new_n44_), .B(new_n41_), .Y(new_n81_));
  INVx1_ASAP7_75t_R   g48(.A(p6), .Y(new_n82_));
  NAND2x1_ASAP7_75t_R g49(.A(p0), .B(new_n47_), .Y(new_n83_));
  AOI21x1_ASAP7_75t_R g50(.A1(new_n82_), .A2(new_n57_), .B(new_n83_), .Y(new_n84_));
  AOI21x1_ASAP7_75t_R g51(.A1(new_n80_), .A2(new_n81_), .B(new_n84_), .Y(o8));
  NAND2x1_ASAP7_75t_R g52(.A(p1), .B(new_n41_), .Y(new_n86_));
  OAI21x1_ASAP7_75t_R g53(.A1(p3), .A2(p2), .B(p1), .Y(new_n87_));
  AO21x1_ASAP7_75t_R  g54(.A1(p3), .A2(p2), .B(p0), .Y(new_n88_));
  NAND3x1_ASAP7_75t_R g55(.A(new_n86_), .B(new_n87_), .C(new_n88_), .Y(new_n89_));
  NOR2x1_ASAP7_75t_R  g56(.A(new_n89_), .B(new_n84_), .Y(o9));
  NOR2x1_ASAP7_75t_R  g57(.A(p1), .B(p2), .Y(new_n91_));
  AO21x1_ASAP7_75t_R  g58(.A1(p3), .A2(new_n45_), .B(new_n91_), .Y(new_n92_));
  AO21x1_ASAP7_75t_R  g59(.A1(new_n82_), .A2(p0), .B(new_n40_), .Y(new_n93_));
  OAI21x1_ASAP7_75t_R g60(.A1(new_n69_), .A2(new_n92_), .B(new_n93_), .Y(o10));
  NOR2x1_ASAP7_75t_R  g61(.A(p6), .B(p0), .Y(new_n95_));
  AND3x1_ASAP7_75t_R  g62(.A(new_n36_), .B(new_n95_), .C(new_n47_), .Y(o11));
  NOR2x1_ASAP7_75t_R  g63(.A(p3), .B(p0), .Y(new_n97_));
  AO21x1_ASAP7_75t_R  g64(.A1(new_n50_), .A2(p2), .B(new_n97_), .Y(new_n98_));
  INVx1_ASAP7_75t_R   g65(.A(new_n95_), .Y(new_n99_));
  NOR2x1_ASAP7_75t_R  g66(.A(p1), .B(new_n36_), .Y(new_n100_));
  OAI21x1_ASAP7_75t_R g67(.A1(p2), .A2(new_n99_), .B(new_n100_), .Y(new_n101_));
  OAI21x1_ASAP7_75t_R g68(.A1(new_n47_), .A2(new_n98_), .B(new_n101_), .Y(o12));
  AND3x1_ASAP7_75t_R  g69(.A(new_n36_), .B(p1), .C(p6), .Y(o13));
  AND3x1_ASAP7_75t_R  g70(.A(new_n36_), .B(p1), .C(new_n82_), .Y(o14));
  AND3x1_ASAP7_75t_R  g71(.A(new_n52_), .B(p1), .C(new_n95_), .Y(o15));
  NAND2x1_ASAP7_75t_R g72(.A(p2), .B(new_n97_), .Y(new_n106_));
  NOR2x1_ASAP7_75t_R  g73(.A(new_n77_), .B(new_n106_), .Y(o16));
  AND3x1_ASAP7_75t_R  g74(.A(p1), .B(p6), .C(p0), .Y(new_n108_));
  AND3x1_ASAP7_75t_R  g75(.A(new_n108_), .B(new_n50_), .C(p2), .Y(o17));
  AND3x1_ASAP7_75t_R  g76(.A(new_n52_), .B(new_n65_), .C(p1), .Y(o18));
  AND3x1_ASAP7_75t_R  g77(.A(new_n50_), .B(new_n39_), .C(p1), .Y(o19));
  AND2x2_ASAP7_75t_R  g78(.A(p2), .B(p6), .Y(new_n112_));
  AOI21x1_ASAP7_75t_R g79(.A1(new_n97_), .A2(new_n112_), .B(p1), .Y(new_n113_));
  INVx1_ASAP7_75t_R   g80(.A(p4), .Y(new_n114_));
  NAND2x1_ASAP7_75t_R g81(.A(p3), .B(new_n114_), .Y(new_n115_));
  NAND2x1_ASAP7_75t_R g82(.A(new_n62_), .B(new_n115_), .Y(new_n116_));
  NAND2x1_ASAP7_75t_R g83(.A(p6), .B(p0), .Y(new_n117_));
  AOI21x1_ASAP7_75t_R g84(.A1(new_n117_), .A2(new_n34_), .B(new_n47_), .Y(new_n118_));
  AOI21x1_ASAP7_75t_R g85(.A1(new_n113_), .A2(new_n116_), .B(new_n118_), .Y(o20));
  NOR2x1_ASAP7_75t_R  g86(.A(p5), .B(new_n41_), .Y(new_n120_));
  NAND2x1_ASAP7_75t_R g87(.A(new_n64_), .B(new_n120_), .Y(new_n121_));
  NAND2x1_ASAP7_75t_R g88(.A(p6), .B(new_n47_), .Y(new_n122_));
  AOI21x1_ASAP7_75t_R g89(.A1(new_n106_), .A2(new_n121_), .B(new_n122_), .Y(o21));
  NAND2x1_ASAP7_75t_R g90(.A(p5), .B(new_n47_), .Y(new_n124_));
  OAI21x1_ASAP7_75t_R g91(.A1(new_n115_), .A2(new_n124_), .B(new_n73_), .Y(new_n125_));
  NOR3x1_ASAP7_75t_R  g92(.A(new_n125_), .B(new_n71_), .C(new_n118_), .Y(o22));
  assign              o23 = 1'b1;
  NAND2x1_ASAP7_75t_R g93(.A(new_n117_), .B(new_n99_), .Y(new_n128_));
  AND3x1_ASAP7_75t_R  g94(.A(new_n128_), .B(p3), .C(new_n91_), .Y(o24));
  AND3x1_ASAP7_75t_R  g95(.A(new_n57_), .B(p6), .C(new_n45_), .Y(o25));
endmodule


