// Benchmark "/tmp/" written by ABC on Tue Oct 13 13:54:47 2026

module \/tmp/  ( 
    p2, p4, p0, p6, p3, p1, p5,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25  );
  input  p2, p4, p0, p6, p3, p1, p5;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25;
  wire new_n34_, new_n35_, new_n36_, new_n37_, new_n39_, new_n40_, new_n41_,
    new_n42_, new_n43_, new_n44_, new_n45_, new_n46_, new_n48_, new_n49_,
    new_n50_, new_n51_, new_n52_, new_n53_, new_n54_, new_n56_, new_n57_,
    new_n59_, new_n60_, new_n61_, new_n62_, new_n63_, new_n64_, new_n65_,
    new_n66_, new_n67_, new_n68_, new_n70_, new_n71_, new_n73_, new_n74_,
    new_n75_, new_n77_, new_n78_, new_n80_, new_n81_, new_n82_, new_n83_,
    new_n84_, new_n85_, new_n87_, new_n88_, new_n90_, new_n91_, new_n92_,
    new_n93_, new_n94_, new_n97_, new_n98_, new_n99_, new_n100_, new_n104_,
    new_n110_, new_n111_, new_n112_, new_n114_, new_n115_, new_n116_,
    new_n120_;
  AND2x2_ASAP7_75t_R  g00(.A(p2), .B(p3), .Y(new_n34_));
  OR3x1_ASAP7_75t_R   g01(.A(p0), .B(p6), .C(p1), .Y(new_n35_));
  NOR2x1_ASAP7_75t_R  g02(.A(p2), .B(p3), .Y(new_n36_));
  AND3x1_ASAP7_75t_R  g03(.A(new_n36_), .B(p0), .C(p1), .Y(new_n37_));
  AO21x1_ASAP7_75t_R  g04(.A1(new_n34_), .A2(new_n35_), .B(new_n37_), .Y(o0));
  INVx1_ASAP7_75t_R   g05(.A(p2), .Y(new_n39_));
  NAND2x1_ASAP7_75t_R g06(.A(p3), .B(new_n39_), .Y(new_n40_));
  INVx1_ASAP7_75t_R   g07(.A(p1), .Y(new_n41_));
  AND3x1_ASAP7_75t_R  g08(.A(new_n40_), .B(p0), .C(new_n41_), .Y(new_n42_));
  NAND2x1_ASAP7_75t_R g09(.A(p2), .B(p3), .Y(new_n43_));
  NOR2x1_ASAP7_75t_R  g10(.A(p0), .B(p1), .Y(new_n44_));
  OA21x2_ASAP7_75t_R  g11(.A1(p6), .A2(new_n43_), .B(new_n44_), .Y(new_n45_));
  AOI21x1_ASAP7_75t_R g12(.A1(p0), .A2(new_n36_), .B(new_n41_), .Y(new_n46_));
  NOR3x1_ASAP7_75t_R  g13(.A(new_n42_), .B(new_n45_), .C(new_n46_), .Y(o1));
  INVx1_ASAP7_75t_R   g14(.A(p3), .Y(new_n48_));
  OR3x1_ASAP7_75t_R   g15(.A(new_n48_), .B(p2), .C(p6), .Y(new_n49_));
  INVx1_ASAP7_75t_R   g16(.A(p0), .Y(new_n50_));
  NOR2x1_ASAP7_75t_R  g17(.A(p3), .B(new_n39_), .Y(new_n51_));
  NOR2x1_ASAP7_75t_R  g18(.A(new_n50_), .B(new_n51_), .Y(new_n52_));
  NOR2x1_ASAP7_75t_R  g19(.A(p6), .B(new_n43_), .Y(new_n53_));
  OAI21x1_ASAP7_75t_R g20(.A1(p0), .A2(new_n53_), .B(new_n41_), .Y(new_n54_));
  AOI21x1_ASAP7_75t_R g21(.A1(new_n49_), .A2(new_n52_), .B(new_n54_), .Y(o2));
  AND2x2_ASAP7_75t_R  g22(.A(p2), .B(p6), .Y(new_n56_));
  AOI21x1_ASAP7_75t_R g23(.A1(p3), .A2(new_n56_), .B(new_n36_), .Y(new_n57_));
  OA21x2_ASAP7_75t_R  g24(.A1(new_n39_), .A2(new_n44_), .B(new_n57_), .Y(o3));
  INVx1_ASAP7_75t_R   g25(.A(p5), .Y(new_n59_));
  NAND2x1_ASAP7_75t_R g26(.A(p3), .B(new_n59_), .Y(new_n60_));
  INVx1_ASAP7_75t_R   g27(.A(p4), .Y(new_n61_));
  NAND2x1_ASAP7_75t_R g28(.A(p3), .B(new_n61_), .Y(new_n62_));
  AND3x1_ASAP7_75t_R  g29(.A(p2), .B(p0), .C(p6), .Y(new_n63_));
  NAND3x1_ASAP7_75t_R g30(.A(new_n60_), .B(new_n62_), .C(new_n63_), .Y(new_n64_));
  AND2x2_ASAP7_75t_R  g31(.A(p4), .B(p0), .Y(new_n65_));
  AOI21x1_ASAP7_75t_R g32(.A1(new_n65_), .A2(new_n53_), .B(p1), .Y(new_n66_));
  INVx1_ASAP7_75t_R   g33(.A(p6), .Y(new_n67_));
  OA21x2_ASAP7_75t_R  g34(.A1(new_n67_), .A2(new_n40_), .B(p1), .Y(new_n68_));
  AOI21x1_ASAP7_75t_R g35(.A1(new_n64_), .A2(new_n66_), .B(new_n68_), .Y(o4));
  AO21x1_ASAP7_75t_R  g36(.A1(p3), .A2(new_n59_), .B(new_n39_), .Y(new_n70_));
  AO21x1_ASAP7_75t_R  g37(.A1(p1), .A2(new_n40_), .B(new_n50_), .Y(new_n71_));
  AOI21x1_ASAP7_75t_R g38(.A1(new_n41_), .A2(new_n70_), .B(new_n71_), .Y(o5));
  NOR2x1_ASAP7_75t_R  g39(.A(p1), .B(new_n36_), .Y(new_n73_));
  AND2x2_ASAP7_75t_R  g40(.A(p0), .B(p6), .Y(new_n74_));
  OR3x1_ASAP7_75t_R   g41(.A(new_n74_), .B(p1), .C(new_n43_), .Y(new_n75_));
  OA21x2_ASAP7_75t_R  g42(.A1(new_n34_), .A2(new_n73_), .B(new_n75_), .Y(o6));
  AND3x1_ASAP7_75t_R  g43(.A(new_n34_), .B(p6), .C(p1), .Y(new_n77_));
  NOR2x1_ASAP7_75t_R  g44(.A(new_n43_), .B(new_n35_), .Y(new_n78_));
  OR3x1_ASAP7_75t_R   g45(.A(new_n77_), .B(new_n78_), .C(new_n37_), .Y(o7));
  AND3x1_ASAP7_75t_R  g46(.A(new_n39_), .B(new_n48_), .C(p0), .Y(new_n80_));
  INVx1_ASAP7_75t_R   g47(.A(new_n80_), .Y(new_n81_));
  AND3x1_ASAP7_75t_R  g48(.A(p2), .B(p0), .C(p3), .Y(new_n82_));
  NOR2x1_ASAP7_75t_R  g49(.A(p1), .B(new_n50_), .Y(new_n83_));
  NOR2x1_ASAP7_75t_R  g50(.A(new_n82_), .B(new_n83_), .Y(new_n84_));
  OA21x2_ASAP7_75t_R  g51(.A1(p6), .A2(new_n40_), .B(new_n83_), .Y(new_n85_));
  AOI21x1_ASAP7_75t_R g52(.A1(new_n81_), .A2(new_n84_), .B(new_n85_), .Y(o8));
  AO21x1_ASAP7_75t_R  g53(.A1(p2), .A2(p3), .B(p0), .Y(new_n87_));
  OAI21x1_ASAP7_75t_R g54(.A1(new_n41_), .A2(new_n80_), .B(new_n87_), .Y(new_n88_));
  NOR2x1_ASAP7_75t_R  g55(.A(new_n85_), .B(new_n88_), .Y(o9));
  NOR2x1_ASAP7_75t_R  g56(.A(p2), .B(new_n48_), .Y(new_n90_));
  NOR2x1_ASAP7_75t_R  g57(.A(new_n41_), .B(new_n90_), .Y(new_n91_));
  NOR2x1_ASAP7_75t_R  g58(.A(p2), .B(p1), .Y(new_n92_));
  AO21x1_ASAP7_75t_R  g59(.A1(p3), .A2(new_n44_), .B(new_n92_), .Y(new_n93_));
  AO21x1_ASAP7_75t_R  g60(.A1(p0), .A2(new_n67_), .B(new_n40_), .Y(new_n94_));
  OAI21x1_ASAP7_75t_R g61(.A1(new_n91_), .A2(new_n93_), .B(new_n94_), .Y(o10));
  AND3x1_ASAP7_75t_R  g62(.A(new_n36_), .B(new_n44_), .C(new_n67_), .Y(o11));
  NAND2x1_ASAP7_75t_R g63(.A(new_n50_), .B(new_n67_), .Y(new_n97_));
  OAI21x1_ASAP7_75t_R g64(.A1(p2), .A2(new_n97_), .B(new_n73_), .Y(new_n98_));
  NOR2x1_ASAP7_75t_R  g65(.A(p0), .B(p3), .Y(new_n99_));
  OR3x1_ASAP7_75t_R   g66(.A(new_n51_), .B(new_n41_), .C(new_n99_), .Y(new_n100_));
  NAND2x1_ASAP7_75t_R g67(.A(new_n98_), .B(new_n100_), .Y(o12));
  AND3x1_ASAP7_75t_R  g68(.A(new_n36_), .B(p6), .C(p1), .Y(o13));
  AND3x1_ASAP7_75t_R  g69(.A(new_n36_), .B(new_n67_), .C(p1), .Y(o14));
  AND3x1_ASAP7_75t_R  g70(.A(new_n48_), .B(p2), .C(p1), .Y(new_n104_));
  AND3x1_ASAP7_75t_R  g71(.A(new_n104_), .B(new_n50_), .C(new_n67_), .Y(o15));
  AND3x1_ASAP7_75t_R  g72(.A(new_n56_), .B(p1), .C(new_n99_), .Y(o16));
  AND3x1_ASAP7_75t_R  g73(.A(new_n51_), .B(p1), .C(new_n74_), .Y(o17));
  AND3x1_ASAP7_75t_R  g74(.A(new_n104_), .B(p0), .C(new_n67_), .Y(o18));
  AND3x1_ASAP7_75t_R  g75(.A(new_n39_), .B(new_n48_), .C(p1), .Y(o19));
  NAND2x1_ASAP7_75t_R g76(.A(new_n63_), .B(new_n62_), .Y(new_n110_));
  AOI21x1_ASAP7_75t_R g77(.A1(new_n99_), .A2(new_n56_), .B(p1), .Y(new_n111_));
  OA21x2_ASAP7_75t_R  g78(.A1(new_n43_), .A2(new_n74_), .B(p1), .Y(new_n112_));
  AOI21x1_ASAP7_75t_R g79(.A1(new_n110_), .A2(new_n111_), .B(new_n112_), .Y(o20));
  AND3x1_ASAP7_75t_R  g80(.A(new_n50_), .B(new_n48_), .C(p2), .Y(new_n114_));
  AND3x1_ASAP7_75t_R  g81(.A(new_n34_), .B(new_n65_), .C(new_n59_), .Y(new_n115_));
  NOR2x1_ASAP7_75t_R  g82(.A(p1), .B(new_n67_), .Y(new_n116_));
  OA21x2_ASAP7_75t_R  g83(.A1(new_n114_), .A2(new_n115_), .B(new_n116_), .Y(o21));
  AOI21x1_ASAP7_75t_R g84(.A1(new_n41_), .A2(new_n64_), .B(new_n112_), .Y(o22));
  assign              o23 = 1'b1;
  XNOR2x2_ASAP7_75t_R g85(.A(p0), .B(p6), .Y(new_n120_));
  AND3x1_ASAP7_75t_R  g86(.A(new_n120_), .B(p3), .C(new_n92_), .Y(o24));
  AND3x1_ASAP7_75t_R  g87(.A(new_n90_), .B(p6), .C(new_n44_), .Y(o25));
endmodule


