// Benchmark "/tmp/" written by ABC on Tue Oct 13 13:54:47 2026

module \/tmp/  ( 
    p1, p2, p4, p5, p3, p6, p0,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25  );
  input  p1, p2, p4, p5, p3, p6, p0;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25;
  wire new_n34_, new_n35_, new_n36_, new_n37_, new_n38_, new_n39_, new_n41_,
    new_n43_, new_n44_, new_n45_, new_n46_, new_n47_, new_n48_, new_n49_,
    new_n50_, new_n52_, new_n53_, new_n54_, new_n55_, new_n56_, new_n57_,
    new_n59_, new_n60_, new_n62_, new_n63_, new_n64_, new_n65_, new_n66_,
    new_n67_, new_n68_, new_n69_, new_n71_, new_n72_, new_n73_, new_n74_,
    new_n76_, new_n77_, new_n78_, new_n80_, new_n81_, new_n83_, new_n84_,
    new_n85_, new_n86_, new_n88_, new_n89_, new_n90_, new_n91_, new_n93_,
    new_n94_, new_n95_, new_n98_, new_n99_, new_n100_, new_n104_,
    new_n106_, new_n109_, new_n111_, new_n112_, new_n113_, new_n115_,
    new_n116_, new_n117_, new_n121_;
  INVx1_ASAP7_75t_R   g00(.A(p6), .Y(new_n34_));
  NOR2x1_ASAP7_75t_R  g01(.A(p1), .B(p0), .Y(new_n35_));
  NAND2x1_ASAP7_75t_R g02(.A(p2), .B(p3), .Y(new_n36_));
  AO21x1_ASAP7_75t_R  g03(.A1(new_n34_), .A2(new_n35_), .B(new_n36_), .Y(new_n37_));
  INVx1_ASAP7_75t_R   g04(.A(p2), .Y(new_n38_));
  INVx1_ASAP7_75t_R   g05(.A(p3), .Y(new_n39_));
  AND3x1_ASAP7_75t_R  g06(.A(new_n38_), .B(new_n39_), .C(p1), .Y(o19));
  NAND2x1_ASAP7_75t_R g07(.A(p0), .B(o19), .Y(new_n41_));
  NAND2x1_ASAP7_75t_R g08(.A(new_n37_), .B(new_n41_), .Y(o0));
  NAND2x1_ASAP7_75t_R g09(.A(p3), .B(new_n38_), .Y(new_n43_));
  INVx1_ASAP7_75t_R   g10(.A(p0), .Y(new_n44_));
  NOR2x1_ASAP7_75t_R  g11(.A(p1), .B(new_n44_), .Y(new_n45_));
  NAND2x1_ASAP7_75t_R g12(.A(new_n43_), .B(new_n45_), .Y(new_n46_));
  OAI21x1_ASAP7_75t_R g13(.A1(p6), .A2(new_n36_), .B(new_n35_), .Y(new_n47_));
  NOR2x1_ASAP7_75t_R  g14(.A(p2), .B(p3), .Y(new_n48_));
  INVx1_ASAP7_75t_R   g15(.A(p1), .Y(new_n49_));
  AO21x1_ASAP7_75t_R  g16(.A1(p0), .A2(new_n48_), .B(new_n49_), .Y(new_n50_));
  AND3x1_ASAP7_75t_R  g17(.A(new_n46_), .B(new_n47_), .C(new_n50_), .Y(o1));
  OR3x1_ASAP7_75t_R   g18(.A(new_n39_), .B(p2), .C(p6), .Y(new_n52_));
  NOR2x1_ASAP7_75t_R  g19(.A(p3), .B(new_n38_), .Y(new_n53_));
  NOR2x1_ASAP7_75t_R  g20(.A(new_n44_), .B(new_n53_), .Y(new_n54_));
  NOR2x1_ASAP7_75t_R  g21(.A(p1), .B(p6), .Y(new_n55_));
  INVx1_ASAP7_75t_R   g22(.A(new_n36_), .Y(new_n56_));
  AOI21x1_ASAP7_75t_R g23(.A1(new_n55_), .A2(new_n56_), .B(new_n45_), .Y(new_n57_));
  AOI21x1_ASAP7_75t_R g24(.A1(new_n52_), .A2(new_n54_), .B(new_n57_), .Y(o2));
  NOR2x1_ASAP7_75t_R  g25(.A(new_n38_), .B(new_n35_), .Y(new_n59_));
  AO21x1_ASAP7_75t_R  g26(.A1(p6), .A2(new_n56_), .B(new_n48_), .Y(new_n60_));
  NOR2x1_ASAP7_75t_R  g27(.A(new_n59_), .B(new_n60_), .Y(o3));
  NAND2x1_ASAP7_75t_R g28(.A(p4), .B(p0), .Y(new_n62_));
  OR3x1_ASAP7_75t_R   g29(.A(new_n36_), .B(new_n62_), .C(p6), .Y(new_n63_));
  AND3x1_ASAP7_75t_R  g30(.A(p2), .B(p6), .C(p0), .Y(new_n64_));
  INVx1_ASAP7_75t_R   g31(.A(p4), .Y(new_n65_));
  INVx1_ASAP7_75t_R   g32(.A(p5), .Y(new_n66_));
  OAI21x1_ASAP7_75t_R g33(.A1(new_n65_), .A2(new_n66_), .B(p3), .Y(new_n67_));
  AOI21x1_ASAP7_75t_R g34(.A1(new_n64_), .A2(new_n67_), .B(p1), .Y(new_n68_));
  OA21x2_ASAP7_75t_R  g35(.A1(new_n34_), .A2(new_n43_), .B(p1), .Y(new_n69_));
  AOI21x1_ASAP7_75t_R g36(.A1(new_n63_), .A2(new_n68_), .B(new_n69_), .Y(o4));
  NOR2x1_ASAP7_75t_R  g37(.A(p2), .B(new_n39_), .Y(new_n71_));
  NOR2x1_ASAP7_75t_R  g38(.A(new_n49_), .B(new_n71_), .Y(new_n72_));
  AO21x1_ASAP7_75t_R  g39(.A1(p2), .A2(p5), .B(p1), .Y(new_n73_));
  OAI21x1_ASAP7_75t_R g40(.A1(new_n73_), .A2(new_n53_), .B(p0), .Y(new_n74_));
  NOR2x1_ASAP7_75t_R  g41(.A(new_n72_), .B(new_n74_), .Y(o5));
  NOR2x1_ASAP7_75t_R  g42(.A(p1), .B(new_n48_), .Y(new_n76_));
  AND2x2_ASAP7_75t_R  g43(.A(p6), .B(p0), .Y(new_n77_));
  OR3x1_ASAP7_75t_R   g44(.A(new_n77_), .B(p1), .C(new_n36_), .Y(new_n78_));
  OA21x2_ASAP7_75t_R  g45(.A1(new_n56_), .A2(new_n76_), .B(new_n78_), .Y(o6));
  OR3x1_ASAP7_75t_R   g46(.A(p1), .B(p6), .C(p0), .Y(new_n80_));
  OA21x2_ASAP7_75t_R  g47(.A1(new_n49_), .A2(new_n34_), .B(new_n80_), .Y(new_n81_));
  OAI21x1_ASAP7_75t_R g48(.A1(new_n36_), .A2(new_n81_), .B(new_n41_), .Y(o7));
  NAND2x1_ASAP7_75t_R g49(.A(p0), .B(new_n48_), .Y(new_n83_));
  AND3x1_ASAP7_75t_R  g50(.A(p2), .B(p3), .C(p0), .Y(new_n84_));
  NOR2x1_ASAP7_75t_R  g51(.A(new_n84_), .B(new_n45_), .Y(new_n85_));
  OA21x2_ASAP7_75t_R  g52(.A1(p6), .A2(new_n43_), .B(new_n45_), .Y(new_n86_));
  AOI21x1_ASAP7_75t_R g53(.A1(new_n83_), .A2(new_n85_), .B(new_n86_), .Y(o8));
  NAND2x1_ASAP7_75t_R g54(.A(p1), .B(new_n44_), .Y(new_n88_));
  OAI21x1_ASAP7_75t_R g55(.A1(p2), .A2(p3), .B(p1), .Y(new_n89_));
  AO21x1_ASAP7_75t_R  g56(.A1(p2), .A2(p3), .B(p0), .Y(new_n90_));
  NAND3x1_ASAP7_75t_R g57(.A(new_n88_), .B(new_n89_), .C(new_n90_), .Y(new_n91_));
  NOR2x1_ASAP7_75t_R  g58(.A(new_n91_), .B(new_n86_), .Y(o9));
  NOR2x1_ASAP7_75t_R  g59(.A(p1), .B(p2), .Y(new_n93_));
  AO21x1_ASAP7_75t_R  g60(.A1(p3), .A2(new_n35_), .B(new_n93_), .Y(new_n94_));
  AO21x1_ASAP7_75t_R  g61(.A1(new_n34_), .A2(p0), .B(new_n43_), .Y(new_n95_));
  OAI21x1_ASAP7_75t_R g62(.A1(new_n72_), .A2(new_n94_), .B(new_n95_), .Y(o10));
  AND3x1_ASAP7_75t_R  g63(.A(new_n35_), .B(new_n48_), .C(new_n34_), .Y(o11));
  OA21x2_ASAP7_75t_R  g64(.A1(p2), .A2(new_n44_), .B(new_n39_), .Y(new_n98_));
  OR3x1_ASAP7_75t_R   g65(.A(p2), .B(p6), .C(p0), .Y(new_n99_));
  NAND2x1_ASAP7_75t_R g66(.A(new_n99_), .B(new_n76_), .Y(new_n100_));
  OAI21x1_ASAP7_75t_R g67(.A1(new_n49_), .A2(new_n98_), .B(new_n100_), .Y(o12));
  AND3x1_ASAP7_75t_R  g68(.A(new_n48_), .B(p1), .C(p6), .Y(o13));
  AND3x1_ASAP7_75t_R  g69(.A(new_n48_), .B(p1), .C(new_n34_), .Y(o14));
  NOR2x1_ASAP7_75t_R  g70(.A(p6), .B(p0), .Y(new_n104_));
  AND3x1_ASAP7_75t_R  g71(.A(new_n53_), .B(p1), .C(new_n104_), .Y(o15));
  NOR2x1_ASAP7_75t_R  g72(.A(p0), .B(new_n34_), .Y(new_n106_));
  AND3x1_ASAP7_75t_R  g73(.A(new_n106_), .B(new_n53_), .C(p1), .Y(o16));
  AND3x1_ASAP7_75t_R  g74(.A(new_n53_), .B(p1), .C(new_n77_), .Y(o17));
  NOR2x1_ASAP7_75t_R  g75(.A(p6), .B(new_n44_), .Y(new_n109_));
  AND3x1_ASAP7_75t_R  g76(.A(new_n53_), .B(new_n109_), .C(p1), .Y(o18));
  OAI21x1_ASAP7_75t_R g77(.A1(p4), .A2(new_n39_), .B(new_n64_), .Y(new_n111_));
  AOI21x1_ASAP7_75t_R g78(.A1(new_n106_), .A2(new_n53_), .B(p1), .Y(new_n112_));
  OA21x2_ASAP7_75t_R  g79(.A1(new_n36_), .A2(new_n77_), .B(p1), .Y(new_n113_));
  AOI21x1_ASAP7_75t_R g80(.A1(new_n111_), .A2(new_n112_), .B(new_n113_), .Y(o20));
  NAND2x1_ASAP7_75t_R g81(.A(new_n39_), .B(new_n44_), .Y(new_n115_));
  OR3x1_ASAP7_75t_R   g82(.A(new_n62_), .B(p5), .C(new_n39_), .Y(new_n116_));
  OR3x1_ASAP7_75t_R   g83(.A(new_n38_), .B(new_n34_), .C(p1), .Y(new_n117_));
  AOI21x1_ASAP7_75t_R g84(.A1(new_n115_), .A2(new_n116_), .B(new_n117_), .Y(o21));
  NOR2x1_ASAP7_75t_R  g85(.A(new_n113_), .B(new_n68_), .Y(o22));
  assign              o23 = 1'b1;
  NOR2x1_ASAP7_75t_R  g86(.A(new_n106_), .B(new_n109_), .Y(new_n121_));
  AND3x1_ASAP7_75t_R  g87(.A(new_n121_), .B(p3), .C(new_n93_), .Y(o24));
  AND3x1_ASAP7_75t_R  g88(.A(new_n71_), .B(p6), .C(new_n35_), .Y(o25));
endmodule


