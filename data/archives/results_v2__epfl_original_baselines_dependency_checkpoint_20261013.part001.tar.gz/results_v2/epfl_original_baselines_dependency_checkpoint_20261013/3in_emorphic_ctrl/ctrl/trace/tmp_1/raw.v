// Benchmark "/tmp/" written by ABC on Tue Oct 13 13:54:46 2026

module \/tmp/  ( 
    p1, p0, p6, p4, p5, p2, p3,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25  );
  input  p1, p0, p6, p4, p5, p2, p3;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25;
  wire new_n34_, new_n35_, new_n36_, new_n37_, new_n38_, new_n39_, new_n40_,
    new_n42_, new_n44_, new_n45_, new_n46_, new_n47_, new_n48_, new_n50_,
    new_n51_, new_n52_, new_n53_, new_n54_, new_n56_, new_n57_, new_n58_,
    new_n60_, new_n61_, new_n62_, new_n63_, new_n64_, new_n65_, new_n66_,
    new_n68_, new_n69_, new_n70_, new_n72_, new_n73_, new_n74_, new_n75_,
    new_n77_, new_n78_, new_n80_, new_n81_, new_n83_, new_n84_, new_n86_,
    new_n87_, new_n88_, new_n91_, new_n92_, new_n93_, new_n94_, new_n98_,
    new_n100_, new_n102_, new_n105_, new_n106_, new_n107_, new_n108_,
    new_n109_, new_n111_, new_n112_, new_n113_, new_n114_, new_n116_,
    new_n117_, new_n120_;
  NAND2x1_ASAP7_75t_R g00(.A(p2), .B(p3), .Y(new_n34_));
  INVx1_ASAP7_75t_R   g01(.A(p1), .Y(new_n35_));
  INVx1_ASAP7_75t_R   g02(.A(p0), .Y(new_n36_));
  INVx1_ASAP7_75t_R   g03(.A(p6), .Y(new_n37_));
  AND3x1_ASAP7_75t_R  g04(.A(new_n35_), .B(new_n36_), .C(new_n37_), .Y(new_n38_));
  INVx1_ASAP7_75t_R   g05(.A(p2), .Y(new_n39_));
  INVx1_ASAP7_75t_R   g06(.A(p3), .Y(new_n40_));
  AND3x1_ASAP7_75t_R  g07(.A(new_n39_), .B(new_n40_), .C(p1), .Y(o19));
  NAND2x1_ASAP7_75t_R g08(.A(p0), .B(o19), .Y(new_n42_));
  OAI21x1_ASAP7_75t_R g09(.A1(new_n34_), .A2(new_n38_), .B(new_n42_), .Y(o0));
  OR3x1_ASAP7_75t_R   g10(.A(new_n34_), .B(p1), .C(p6), .Y(new_n44_));
  NAND2x1_ASAP7_75t_R g11(.A(p0), .B(new_n35_), .Y(new_n45_));
  NOR2x1_ASAP7_75t_R  g12(.A(p2), .B(new_n40_), .Y(new_n46_));
  AO21x1_ASAP7_75t_R  g13(.A1(new_n39_), .A2(new_n40_), .B(new_n35_), .Y(new_n47_));
  OAI21x1_ASAP7_75t_R g14(.A1(new_n45_), .A2(new_n46_), .B(new_n47_), .Y(new_n48_));
  AOI21x1_ASAP7_75t_R g15(.A1(new_n36_), .A2(new_n44_), .B(new_n48_), .Y(o1));
  OR3x1_ASAP7_75t_R   g16(.A(new_n40_), .B(p6), .C(p2), .Y(new_n50_));
  NOR2x1_ASAP7_75t_R  g17(.A(p3), .B(new_n39_), .Y(new_n51_));
  NOR2x1_ASAP7_75t_R  g18(.A(new_n36_), .B(new_n51_), .Y(new_n52_));
  NOR2x1_ASAP7_75t_R  g19(.A(p6), .B(new_n34_), .Y(new_n53_));
  OAI21x1_ASAP7_75t_R g20(.A1(p0), .A2(new_n53_), .B(new_n35_), .Y(new_n54_));
  AOI21x1_ASAP7_75t_R g21(.A1(new_n50_), .A2(new_n52_), .B(new_n54_), .Y(o2));
  AND2x2_ASAP7_75t_R  g22(.A(p2), .B(p3), .Y(new_n56_));
  NOR2x1_ASAP7_75t_R  g23(.A(p1), .B(p0), .Y(new_n57_));
  AOI21x1_ASAP7_75t_R g24(.A1(p2), .A2(new_n57_), .B(new_n46_), .Y(new_n58_));
  AOI21x1_ASAP7_75t_R g25(.A1(p6), .A2(new_n56_), .B(new_n58_), .Y(o3));
  AND3x1_ASAP7_75t_R  g26(.A(p0), .B(p6), .C(p2), .Y(new_n60_));
  AO21x1_ASAP7_75t_R  g27(.A1(p4), .A2(p5), .B(new_n40_), .Y(new_n61_));
  NAND2x1_ASAP7_75t_R g28(.A(new_n60_), .B(new_n61_), .Y(new_n62_));
  AND2x2_ASAP7_75t_R  g29(.A(p0), .B(p4), .Y(new_n63_));
  AOI21x1_ASAP7_75t_R g30(.A1(new_n63_), .A2(new_n53_), .B(p1), .Y(new_n64_));
  NAND2x1_ASAP7_75t_R g31(.A(p3), .B(new_n39_), .Y(new_n65_));
  OA21x2_ASAP7_75t_R  g32(.A1(new_n37_), .A2(new_n65_), .B(p1), .Y(new_n66_));
  AOI21x1_ASAP7_75t_R g33(.A1(new_n62_), .A2(new_n64_), .B(new_n66_), .Y(o4));
  NOR2x1_ASAP7_75t_R  g34(.A(new_n35_), .B(new_n46_), .Y(new_n68_));
  AO21x1_ASAP7_75t_R  g35(.A1(p5), .A2(p2), .B(p1), .Y(new_n69_));
  NOR2x1_ASAP7_75t_R  g36(.A(new_n69_), .B(new_n51_), .Y(new_n70_));
  NOR3x1_ASAP7_75t_R  g37(.A(new_n68_), .B(new_n70_), .C(new_n36_), .Y(o5));
  NOR2x1_ASAP7_75t_R  g38(.A(p2), .B(p3), .Y(new_n72_));
  NOR2x1_ASAP7_75t_R  g39(.A(p1), .B(new_n72_), .Y(new_n73_));
  AO21x1_ASAP7_75t_R  g40(.A1(p0), .A2(p6), .B(p1), .Y(new_n74_));
  AND2x2_ASAP7_75t_R  g41(.A(new_n56_), .B(new_n74_), .Y(new_n75_));
  AO21x1_ASAP7_75t_R  g42(.A1(new_n34_), .A2(new_n73_), .B(new_n75_), .Y(o6));
  NOR2x1_ASAP7_75t_R  g43(.A(p6), .B(new_n57_), .Y(new_n77_));
  AO21x1_ASAP7_75t_R  g44(.A1(new_n35_), .A2(p6), .B(new_n34_), .Y(new_n78_));
  OAI21x1_ASAP7_75t_R g45(.A1(new_n77_), .A2(new_n78_), .B(new_n42_), .Y(o7));
  AOI21x1_ASAP7_75t_R g46(.A1(new_n37_), .A2(new_n46_), .B(new_n45_), .Y(new_n80_));
  NOR3x1_ASAP7_75t_R  g47(.A(new_n56_), .B(new_n35_), .C(new_n72_), .Y(new_n81_));
  NOR3x1_ASAP7_75t_R  g48(.A(new_n80_), .B(new_n36_), .C(new_n81_), .Y(o8));
  INVx1_ASAP7_75t_R   g49(.A(new_n47_), .Y(new_n83_));
  AND2x2_ASAP7_75t_R  g50(.A(new_n36_), .B(new_n34_), .Y(new_n84_));
  NOR3x1_ASAP7_75t_R  g51(.A(new_n83_), .B(new_n80_), .C(new_n84_), .Y(o9));
  NOR2x1_ASAP7_75t_R  g52(.A(p1), .B(p2), .Y(new_n86_));
  AO21x1_ASAP7_75t_R  g53(.A1(p3), .A2(new_n57_), .B(new_n86_), .Y(new_n87_));
  AO21x1_ASAP7_75t_R  g54(.A1(p0), .A2(new_n37_), .B(new_n65_), .Y(new_n88_));
  OAI21x1_ASAP7_75t_R g55(.A1(new_n68_), .A2(new_n87_), .B(new_n88_), .Y(o10));
  AND3x1_ASAP7_75t_R  g56(.A(new_n72_), .B(new_n57_), .C(new_n37_), .Y(o11));
  NAND2x1_ASAP7_75t_R g57(.A(new_n36_), .B(new_n37_), .Y(new_n91_));
  OAI21x1_ASAP7_75t_R g58(.A1(p2), .A2(new_n91_), .B(new_n73_), .Y(new_n92_));
  NOR2x1_ASAP7_75t_R  g59(.A(p0), .B(p3), .Y(new_n93_));
  OR3x1_ASAP7_75t_R   g60(.A(new_n51_), .B(new_n35_), .C(new_n93_), .Y(new_n94_));
  NAND2x1_ASAP7_75t_R g61(.A(new_n92_), .B(new_n94_), .Y(o12));
  AND3x1_ASAP7_75t_R  g62(.A(new_n72_), .B(p1), .C(p6), .Y(o13));
  AND3x1_ASAP7_75t_R  g63(.A(new_n72_), .B(p1), .C(new_n37_), .Y(o14));
  AND3x1_ASAP7_75t_R  g64(.A(new_n40_), .B(p1), .C(p2), .Y(new_n98_));
  AND3x1_ASAP7_75t_R  g65(.A(new_n98_), .B(new_n36_), .C(new_n37_), .Y(o15));
  AND2x2_ASAP7_75t_R  g66(.A(p6), .B(p2), .Y(new_n100_));
  AND3x1_ASAP7_75t_R  g67(.A(new_n100_), .B(p1), .C(new_n93_), .Y(o16));
  AND2x2_ASAP7_75t_R  g68(.A(p0), .B(p6), .Y(new_n102_));
  AND3x1_ASAP7_75t_R  g69(.A(new_n51_), .B(p1), .C(new_n102_), .Y(o17));
  AND3x1_ASAP7_75t_R  g70(.A(new_n98_), .B(p0), .C(new_n37_), .Y(o18));
  INVx1_ASAP7_75t_R   g71(.A(p4), .Y(new_n105_));
  NAND2x1_ASAP7_75t_R g72(.A(p3), .B(new_n105_), .Y(new_n106_));
  NAND2x1_ASAP7_75t_R g73(.A(new_n60_), .B(new_n106_), .Y(new_n107_));
  AOI21x1_ASAP7_75t_R g74(.A1(new_n93_), .A2(new_n100_), .B(p1), .Y(new_n108_));
  OA21x2_ASAP7_75t_R  g75(.A1(new_n34_), .A2(new_n102_), .B(p1), .Y(new_n109_));
  AOI21x1_ASAP7_75t_R g76(.A1(new_n107_), .A2(new_n108_), .B(new_n109_), .Y(o20));
  AND3x1_ASAP7_75t_R  g77(.A(new_n36_), .B(new_n40_), .C(p2), .Y(new_n111_));
  INVx1_ASAP7_75t_R   g78(.A(p5), .Y(new_n112_));
  AND3x1_ASAP7_75t_R  g79(.A(new_n56_), .B(new_n63_), .C(new_n112_), .Y(new_n113_));
  NOR2x1_ASAP7_75t_R  g80(.A(p1), .B(new_n37_), .Y(new_n114_));
  OA21x2_ASAP7_75t_R  g81(.A1(new_n111_), .A2(new_n113_), .B(new_n114_), .Y(o21));
  NAND2x1_ASAP7_75t_R g82(.A(p5), .B(new_n35_), .Y(new_n116_));
  OAI21x1_ASAP7_75t_R g83(.A1(new_n106_), .A2(new_n116_), .B(new_n74_), .Y(new_n117_));
  NOR3x1_ASAP7_75t_R  g84(.A(new_n117_), .B(new_n109_), .C(new_n70_), .Y(o22));
  assign              o23 = 1'b1;
  XNOR2x2_ASAP7_75t_R g85(.A(p0), .B(p6), .Y(new_n120_));
  AND3x1_ASAP7_75t_R  g86(.A(new_n120_), .B(p3), .C(new_n86_), .Y(o24));
  AND3x1_ASAP7_75t_R  g87(.A(new_n46_), .B(p6), .C(new_n57_), .Y(o25));
endmodule


