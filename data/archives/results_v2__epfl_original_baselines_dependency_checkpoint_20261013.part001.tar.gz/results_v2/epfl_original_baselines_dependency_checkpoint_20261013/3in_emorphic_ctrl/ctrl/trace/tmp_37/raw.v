// Benchmark "/tmp/" written by ABC on Tue Oct 13 13:54:49 2026

module \/tmp/  ( 
    p6, p4, p5, p0, p3, p1, p2,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25  );
  input  p6, p4, p5, p0, p3, p1, p2;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25;
  wire new_n34_, new_n35_, new_n36_, new_n37_, new_n38_, new_n39_, new_n41_,
    new_n43_, new_n44_, new_n45_, new_n46_, new_n47_, new_n48_, new_n49_,
    new_n50_, new_n52_, new_n53_, new_n54_, new_n55_, new_n56_, new_n58_,
    new_n59_, new_n60_, new_n62_, new_n63_, new_n64_, new_n65_, new_n66_,
    new_n67_, new_n68_, new_n69_, new_n70_, new_n71_, new_n72_, new_n74_,
    new_n75_, new_n76_, new_n78_, new_n79_, new_n80_, new_n82_, new_n83_,
    new_n85_, new_n86_, new_n89_, new_n90_, new_n91_, new_n94_, new_n95_,
    new_n96_, new_n101_, new_n103_, new_n106_, new_n107_, new_n108_,
    new_n110_, new_n111_, new_n112_, new_n114_, new_n115_, new_n118_;
  INVx1_ASAP7_75t_R   g00(.A(p6), .Y(new_n34_));
  NOR2x1_ASAP7_75t_R  g01(.A(p0), .B(p1), .Y(new_n35_));
  NAND2x1_ASAP7_75t_R g02(.A(p3), .B(p2), .Y(new_n36_));
  AO21x1_ASAP7_75t_R  g03(.A1(new_n34_), .A2(new_n35_), .B(new_n36_), .Y(new_n37_));
  INVx1_ASAP7_75t_R   g04(.A(p3), .Y(new_n38_));
  INVx1_ASAP7_75t_R   g05(.A(p2), .Y(new_n39_));
  AND3x1_ASAP7_75t_R  g06(.A(new_n38_), .B(new_n39_), .C(p1), .Y(o19));
  NAND2x1_ASAP7_75t_R g07(.A(p0), .B(o19), .Y(new_n41_));
  NAND2x1_ASAP7_75t_R g08(.A(new_n37_), .B(new_n41_), .Y(o0));
  INVx1_ASAP7_75t_R   g09(.A(p0), .Y(new_n43_));
  OR3x1_ASAP7_75t_R   g10(.A(new_n43_), .B(new_n38_), .C(p2), .Y(new_n44_));
  INVx1_ASAP7_75t_R   g11(.A(p1), .Y(new_n45_));
  NAND2x1_ASAP7_75t_R g12(.A(new_n34_), .B(new_n43_), .Y(new_n46_));
  AND2x2_ASAP7_75t_R  g13(.A(new_n45_), .B(new_n46_), .Y(new_n47_));
  AND2x2_ASAP7_75t_R  g14(.A(p3), .B(p2), .Y(new_n48_));
  OAI21x1_ASAP7_75t_R g15(.A1(p3), .A2(p2), .B(p1), .Y(new_n49_));
  OAI21x1_ASAP7_75t_R g16(.A1(p0), .A2(new_n48_), .B(new_n49_), .Y(new_n50_));
  AOI21x1_ASAP7_75t_R g17(.A1(new_n44_), .A2(new_n47_), .B(new_n50_), .Y(o1));
  OR3x1_ASAP7_75t_R   g18(.A(new_n38_), .B(p6), .C(p2), .Y(new_n52_));
  NOR2x1_ASAP7_75t_R  g19(.A(p3), .B(new_n39_), .Y(new_n53_));
  NOR2x1_ASAP7_75t_R  g20(.A(new_n43_), .B(new_n53_), .Y(new_n54_));
  NOR2x1_ASAP7_75t_R  g21(.A(p6), .B(new_n36_), .Y(new_n55_));
  OAI21x1_ASAP7_75t_R g22(.A1(p0), .A2(new_n55_), .B(new_n45_), .Y(new_n56_));
  AOI21x1_ASAP7_75t_R g23(.A1(new_n52_), .A2(new_n54_), .B(new_n56_), .Y(o2));
  NOR2x1_ASAP7_75t_R  g24(.A(new_n39_), .B(new_n35_), .Y(new_n58_));
  NOR2x1_ASAP7_75t_R  g25(.A(p3), .B(p2), .Y(new_n59_));
  AO21x1_ASAP7_75t_R  g26(.A1(p6), .A2(new_n48_), .B(new_n59_), .Y(new_n60_));
  NOR2x1_ASAP7_75t_R  g27(.A(new_n58_), .B(new_n60_), .Y(o3));
  INVx1_ASAP7_75t_R   g28(.A(p5), .Y(new_n62_));
  NAND2x1_ASAP7_75t_R g29(.A(p3), .B(new_n62_), .Y(new_n63_));
  INVx1_ASAP7_75t_R   g30(.A(p4), .Y(new_n64_));
  NAND2x1_ASAP7_75t_R g31(.A(p3), .B(new_n64_), .Y(new_n65_));
  AND3x1_ASAP7_75t_R  g32(.A(p6), .B(p0), .C(p2), .Y(new_n66_));
  NAND3x1_ASAP7_75t_R g33(.A(new_n63_), .B(new_n65_), .C(new_n66_), .Y(new_n67_));
  AND2x2_ASAP7_75t_R  g34(.A(p4), .B(p0), .Y(new_n68_));
  AOI21x1_ASAP7_75t_R g35(.A1(new_n68_), .A2(new_n55_), .B(p1), .Y(new_n69_));
  NAND2x1_ASAP7_75t_R g36(.A(p3), .B(new_n39_), .Y(new_n70_));
  NOR2x1_ASAP7_75t_R  g37(.A(p6), .B(new_n45_), .Y(new_n71_));
  AO21x1_ASAP7_75t_R  g38(.A1(p1), .A2(new_n70_), .B(new_n71_), .Y(new_n72_));
  AOI21x1_ASAP7_75t_R g39(.A1(new_n67_), .A2(new_n69_), .B(new_n72_), .Y(o4));
  AOI21x1_ASAP7_75t_R g40(.A1(p2), .A2(new_n63_), .B(p1), .Y(new_n74_));
  NOR2x1_ASAP7_75t_R  g41(.A(p2), .B(new_n38_), .Y(new_n75_));
  NOR2x1_ASAP7_75t_R  g42(.A(new_n45_), .B(new_n75_), .Y(new_n76_));
  NOR3x1_ASAP7_75t_R  g43(.A(new_n74_), .B(new_n76_), .C(new_n43_), .Y(o5));
  NOR2x1_ASAP7_75t_R  g44(.A(p1), .B(new_n59_), .Y(new_n78_));
  AO21x1_ASAP7_75t_R  g45(.A1(p6), .A2(p0), .B(p1), .Y(new_n79_));
  AND2x2_ASAP7_75t_R  g46(.A(new_n48_), .B(new_n79_), .Y(new_n80_));
  AO21x1_ASAP7_75t_R  g47(.A1(new_n36_), .A2(new_n78_), .B(new_n80_), .Y(o6));
  NOR2x1_ASAP7_75t_R  g48(.A(p6), .B(new_n35_), .Y(new_n82_));
  AO21x1_ASAP7_75t_R  g49(.A1(p6), .A2(new_n45_), .B(new_n36_), .Y(new_n83_));
  OAI21x1_ASAP7_75t_R g50(.A1(new_n82_), .A2(new_n83_), .B(new_n41_), .Y(o7));
  NOR2x1_ASAP7_75t_R  g51(.A(p1), .B(new_n43_), .Y(new_n85_));
  OAI21x1_ASAP7_75t_R g52(.A1(new_n49_), .A2(new_n48_), .B(p0), .Y(new_n86_));
  AOI21x1_ASAP7_75t_R g53(.A1(new_n85_), .A2(new_n52_), .B(new_n86_), .Y(o8));
  AOI21x1_ASAP7_75t_R g54(.A1(new_n85_), .A2(new_n52_), .B(new_n50_), .Y(o9));
  NOR2x1_ASAP7_75t_R  g55(.A(p1), .B(p2), .Y(new_n89_));
  AO21x1_ASAP7_75t_R  g56(.A1(p3), .A2(new_n35_), .B(new_n89_), .Y(new_n90_));
  AO21x1_ASAP7_75t_R  g57(.A1(new_n34_), .A2(p0), .B(new_n70_), .Y(new_n91_));
  OAI21x1_ASAP7_75t_R g58(.A1(new_n76_), .A2(new_n90_), .B(new_n91_), .Y(o10));
  AND3x1_ASAP7_75t_R  g59(.A(new_n35_), .B(new_n59_), .C(new_n34_), .Y(o11));
  OAI21x1_ASAP7_75t_R g60(.A1(p2), .A2(new_n46_), .B(new_n78_), .Y(new_n94_));
  NOR2x1_ASAP7_75t_R  g61(.A(p0), .B(p3), .Y(new_n95_));
  OR3x1_ASAP7_75t_R   g62(.A(new_n53_), .B(new_n45_), .C(new_n95_), .Y(new_n96_));
  NAND2x1_ASAP7_75t_R g63(.A(new_n94_), .B(new_n96_), .Y(o12));
  AND3x1_ASAP7_75t_R  g64(.A(new_n59_), .B(p6), .C(p1), .Y(o13));
  AND3x1_ASAP7_75t_R  g65(.A(new_n59_), .B(new_n34_), .C(p1), .Y(o14));
  AND3x1_ASAP7_75t_R  g66(.A(new_n71_), .B(p2), .C(new_n95_), .Y(o15));
  AND2x2_ASAP7_75t_R  g67(.A(p6), .B(p2), .Y(new_n101_));
  AND3x1_ASAP7_75t_R  g68(.A(new_n101_), .B(p1), .C(new_n95_), .Y(o16));
  AND2x2_ASAP7_75t_R  g69(.A(p6), .B(p0), .Y(new_n103_));
  AND3x1_ASAP7_75t_R  g70(.A(new_n53_), .B(p1), .C(new_n103_), .Y(o17));
  AND3x1_ASAP7_75t_R  g71(.A(new_n53_), .B(new_n71_), .C(p0), .Y(o18));
  NAND2x1_ASAP7_75t_R g72(.A(new_n66_), .B(new_n65_), .Y(new_n106_));
  AOI21x1_ASAP7_75t_R g73(.A1(new_n95_), .A2(new_n101_), .B(p1), .Y(new_n107_));
  OA21x2_ASAP7_75t_R  g74(.A1(new_n36_), .A2(new_n103_), .B(p1), .Y(new_n108_));
  AOI21x1_ASAP7_75t_R g75(.A1(new_n106_), .A2(new_n107_), .B(new_n108_), .Y(o20));
  AND3x1_ASAP7_75t_R  g76(.A(new_n43_), .B(new_n38_), .C(p2), .Y(new_n110_));
  AND3x1_ASAP7_75t_R  g77(.A(new_n48_), .B(new_n68_), .C(new_n62_), .Y(new_n111_));
  NOR2x1_ASAP7_75t_R  g78(.A(p1), .B(new_n34_), .Y(new_n112_));
  OA21x2_ASAP7_75t_R  g79(.A1(new_n110_), .A2(new_n111_), .B(new_n112_), .Y(o21));
  NAND2x1_ASAP7_75t_R g80(.A(p5), .B(new_n45_), .Y(new_n114_));
  OAI21x1_ASAP7_75t_R g81(.A1(new_n65_), .A2(new_n114_), .B(new_n79_), .Y(new_n115_));
  NOR3x1_ASAP7_75t_R  g82(.A(new_n115_), .B(new_n74_), .C(new_n108_), .Y(o22));
  assign              o23 = 1'b1;
  XNOR2x2_ASAP7_75t_R g83(.A(p6), .B(p0), .Y(new_n118_));
  AND3x1_ASAP7_75t_R  g84(.A(new_n118_), .B(p3), .C(new_n89_), .Y(o24));
  AND3x1_ASAP7_75t_R  g85(.A(new_n75_), .B(p6), .C(new_n35_), .Y(o25));
endmodule


