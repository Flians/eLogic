// Benchmark "/tmp/" written by ABC on Tue Oct 13 13:54:48 2026

module \/tmp/  ( 
    p0, p5, p4, p6, p3, p1, p2,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25  );
  input  p0, p5, p4, p6, p3, p1, p2;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25;
  wire new_n34_, new_n35_, new_n36_, new_n37_, new_n39_, new_n40_, new_n41_,
    new_n42_, new_n43_, new_n44_, new_n45_, new_n46_, new_n47_, new_n49_,
    new_n50_, new_n51_, new_n52_, new_n53_, new_n54_, new_n55_, new_n57_,
    new_n58_, new_n60_, new_n61_, new_n62_, new_n63_, new_n64_, new_n65_,
    new_n66_, new_n67_, new_n68_, new_n69_, new_n70_, new_n72_, new_n73_,
    new_n75_, new_n76_, new_n77_, new_n79_, new_n80_, new_n81_, new_n83_,
    new_n84_, new_n85_, new_n87_, new_n89_, new_n90_, new_n91_, new_n94_,
    new_n95_, new_n96_, new_n97_, new_n102_, new_n104_, new_n108_,
    new_n109_, new_n110_, new_n112_, new_n113_, new_n115_, new_n116_,
    new_n119_;
  AND2x2_ASAP7_75t_R  g00(.A(p3), .B(p2), .Y(new_n34_));
  OR3x1_ASAP7_75t_R   g01(.A(p0), .B(p6), .C(p1), .Y(new_n35_));
  NOR2x1_ASAP7_75t_R  g02(.A(p3), .B(p2), .Y(new_n36_));
  AND3x1_ASAP7_75t_R  g03(.A(new_n36_), .B(p0), .C(p1), .Y(new_n37_));
  AO21x1_ASAP7_75t_R  g04(.A1(new_n34_), .A2(new_n35_), .B(new_n37_), .Y(o0));
  INVx1_ASAP7_75t_R   g05(.A(p1), .Y(new_n39_));
  NAND2x1_ASAP7_75t_R g06(.A(p0), .B(new_n39_), .Y(new_n40_));
  INVx1_ASAP7_75t_R   g07(.A(p3), .Y(new_n41_));
  NOR2x1_ASAP7_75t_R  g08(.A(p2), .B(new_n41_), .Y(new_n42_));
  NOR2x1_ASAP7_75t_R  g09(.A(new_n40_), .B(new_n42_), .Y(new_n43_));
  AOI21x1_ASAP7_75t_R g10(.A1(p0), .A2(new_n36_), .B(new_n39_), .Y(new_n44_));
  NAND2x1_ASAP7_75t_R g11(.A(p3), .B(p2), .Y(new_n45_));
  NOR2x1_ASAP7_75t_R  g12(.A(p0), .B(p1), .Y(new_n46_));
  OA21x2_ASAP7_75t_R  g13(.A1(p6), .A2(new_n45_), .B(new_n46_), .Y(new_n47_));
  NOR3x1_ASAP7_75t_R  g14(.A(new_n43_), .B(new_n44_), .C(new_n47_), .Y(o1));
  OR3x1_ASAP7_75t_R   g15(.A(new_n41_), .B(p6), .C(p2), .Y(new_n49_));
  INVx1_ASAP7_75t_R   g16(.A(p0), .Y(new_n50_));
  INVx1_ASAP7_75t_R   g17(.A(p2), .Y(new_n51_));
  NOR2x1_ASAP7_75t_R  g18(.A(p3), .B(new_n51_), .Y(new_n52_));
  NOR2x1_ASAP7_75t_R  g19(.A(new_n50_), .B(new_n52_), .Y(new_n53_));
  NOR2x1_ASAP7_75t_R  g20(.A(p6), .B(new_n45_), .Y(new_n54_));
  OAI21x1_ASAP7_75t_R g21(.A1(p0), .A2(new_n54_), .B(new_n39_), .Y(new_n55_));
  AOI21x1_ASAP7_75t_R g22(.A1(new_n49_), .A2(new_n53_), .B(new_n55_), .Y(o2));
  NOR2x1_ASAP7_75t_R  g23(.A(new_n51_), .B(new_n46_), .Y(new_n57_));
  AO21x1_ASAP7_75t_R  g24(.A1(p6), .A2(new_n34_), .B(new_n36_), .Y(new_n58_));
  NOR2x1_ASAP7_75t_R  g25(.A(new_n57_), .B(new_n58_), .Y(o3));
  INVx1_ASAP7_75t_R   g26(.A(p5), .Y(new_n60_));
  NAND2x1_ASAP7_75t_R g27(.A(p3), .B(new_n60_), .Y(new_n61_));
  INVx1_ASAP7_75t_R   g28(.A(p4), .Y(new_n62_));
  NAND2x1_ASAP7_75t_R g29(.A(p3), .B(new_n62_), .Y(new_n63_));
  AND3x1_ASAP7_75t_R  g30(.A(p0), .B(p6), .C(p2), .Y(new_n64_));
  NAND3x1_ASAP7_75t_R g31(.A(new_n61_), .B(new_n63_), .C(new_n64_), .Y(new_n65_));
  AND2x2_ASAP7_75t_R  g32(.A(p0), .B(p4), .Y(new_n66_));
  AOI21x1_ASAP7_75t_R g33(.A1(new_n66_), .A2(new_n54_), .B(p1), .Y(new_n67_));
  NAND2x1_ASAP7_75t_R g34(.A(p3), .B(new_n51_), .Y(new_n68_));
  NOR2x1_ASAP7_75t_R  g35(.A(p6), .B(new_n39_), .Y(new_n69_));
  AO21x1_ASAP7_75t_R  g36(.A1(p1), .A2(new_n68_), .B(new_n69_), .Y(new_n70_));
  AOI21x1_ASAP7_75t_R g37(.A1(new_n65_), .A2(new_n67_), .B(new_n70_), .Y(o4));
  AOI21x1_ASAP7_75t_R g38(.A1(p2), .A2(new_n61_), .B(p1), .Y(new_n72_));
  NOR2x1_ASAP7_75t_R  g39(.A(new_n39_), .B(new_n42_), .Y(new_n73_));
  NOR3x1_ASAP7_75t_R  g40(.A(new_n72_), .B(new_n73_), .C(new_n50_), .Y(o5));
  NOR2x1_ASAP7_75t_R  g41(.A(p1), .B(new_n36_), .Y(new_n75_));
  AO21x1_ASAP7_75t_R  g42(.A1(p0), .A2(p6), .B(p1), .Y(new_n76_));
  AND2x2_ASAP7_75t_R  g43(.A(new_n34_), .B(new_n76_), .Y(new_n77_));
  AO21x1_ASAP7_75t_R  g44(.A1(new_n45_), .A2(new_n75_), .B(new_n77_), .Y(o6));
  INVx1_ASAP7_75t_R   g45(.A(p6), .Y(new_n79_));
  AND3x1_ASAP7_75t_R  g46(.A(new_n34_), .B(new_n79_), .C(new_n46_), .Y(new_n80_));
  AND3x1_ASAP7_75t_R  g47(.A(new_n34_), .B(p6), .C(p1), .Y(new_n81_));
  OR3x1_ASAP7_75t_R   g48(.A(new_n80_), .B(new_n81_), .C(new_n37_), .Y(o7));
  NAND2x1_ASAP7_75t_R g49(.A(p0), .B(new_n36_), .Y(new_n83_));
  AO21x1_ASAP7_75t_R  g50(.A1(p1), .A2(new_n45_), .B(new_n50_), .Y(new_n84_));
  AOI21x1_ASAP7_75t_R g51(.A1(new_n79_), .A2(new_n42_), .B(new_n40_), .Y(new_n85_));
  AOI21x1_ASAP7_75t_R g52(.A1(new_n83_), .A2(new_n84_), .B(new_n85_), .Y(o8));
  AND2x2_ASAP7_75t_R  g53(.A(new_n50_), .B(new_n45_), .Y(new_n87_));
  NOR3x1_ASAP7_75t_R  g54(.A(new_n85_), .B(new_n44_), .C(new_n87_), .Y(o9));
  NOR2x1_ASAP7_75t_R  g55(.A(p1), .B(p2), .Y(new_n89_));
  AO21x1_ASAP7_75t_R  g56(.A1(p3), .A2(new_n46_), .B(new_n89_), .Y(new_n90_));
  AO21x1_ASAP7_75t_R  g57(.A1(p0), .A2(new_n79_), .B(new_n68_), .Y(new_n91_));
  AOI21x1_ASAP7_75t_R g58(.A1(new_n90_), .A2(new_n91_), .B(new_n73_), .Y(o10));
  AND3x1_ASAP7_75t_R  g59(.A(new_n36_), .B(new_n46_), .C(new_n79_), .Y(o11));
  NAND2x1_ASAP7_75t_R g60(.A(new_n50_), .B(new_n79_), .Y(new_n94_));
  OAI21x1_ASAP7_75t_R g61(.A1(p2), .A2(new_n94_), .B(new_n75_), .Y(new_n95_));
  NOR2x1_ASAP7_75t_R  g62(.A(p0), .B(p3), .Y(new_n96_));
  OR3x1_ASAP7_75t_R   g63(.A(new_n52_), .B(new_n39_), .C(new_n96_), .Y(new_n97_));
  NAND2x1_ASAP7_75t_R g64(.A(new_n95_), .B(new_n97_), .Y(o12));
  AND3x1_ASAP7_75t_R  g65(.A(new_n36_), .B(p6), .C(p1), .Y(o13));
  AND3x1_ASAP7_75t_R  g66(.A(new_n36_), .B(new_n79_), .C(p1), .Y(o14));
  AND3x1_ASAP7_75t_R  g67(.A(new_n69_), .B(p2), .C(new_n96_), .Y(o15));
  AND2x2_ASAP7_75t_R  g68(.A(p6), .B(p2), .Y(new_n102_));
  AND3x1_ASAP7_75t_R  g69(.A(new_n102_), .B(p1), .C(new_n96_), .Y(o16));
  AND2x2_ASAP7_75t_R  g70(.A(p0), .B(p6), .Y(new_n104_));
  AND3x1_ASAP7_75t_R  g71(.A(new_n52_), .B(p1), .C(new_n104_), .Y(o17));
  AND3x1_ASAP7_75t_R  g72(.A(new_n52_), .B(new_n69_), .C(p0), .Y(o18));
  AND3x1_ASAP7_75t_R  g73(.A(new_n41_), .B(new_n51_), .C(p1), .Y(o19));
  NAND2x1_ASAP7_75t_R g74(.A(new_n64_), .B(new_n63_), .Y(new_n108_));
  AOI21x1_ASAP7_75t_R g75(.A1(new_n96_), .A2(new_n102_), .B(p1), .Y(new_n109_));
  OA21x2_ASAP7_75t_R  g76(.A1(new_n45_), .A2(new_n104_), .B(p1), .Y(new_n110_));
  AOI21x1_ASAP7_75t_R g77(.A1(new_n108_), .A2(new_n109_), .B(new_n110_), .Y(o20));
  AND3x1_ASAP7_75t_R  g78(.A(new_n66_), .B(new_n60_), .C(p3), .Y(new_n112_));
  AND3x1_ASAP7_75t_R  g79(.A(new_n39_), .B(p6), .C(p2), .Y(new_n113_));
  OA21x2_ASAP7_75t_R  g80(.A1(new_n96_), .A2(new_n112_), .B(new_n113_), .Y(o21));
  NAND2x1_ASAP7_75t_R g81(.A(p5), .B(new_n39_), .Y(new_n115_));
  OAI21x1_ASAP7_75t_R g82(.A1(new_n63_), .A2(new_n115_), .B(new_n76_), .Y(new_n116_));
  NOR3x1_ASAP7_75t_R  g83(.A(new_n116_), .B(new_n72_), .C(new_n110_), .Y(o22));
  assign              o23 = 1'b1;
  XNOR2x2_ASAP7_75t_R g84(.A(p0), .B(p6), .Y(new_n119_));
  AND3x1_ASAP7_75t_R  g85(.A(new_n119_), .B(p3), .C(new_n89_), .Y(o24));
  AND3x1_ASAP7_75t_R  g86(.A(new_n42_), .B(p6), .C(new_n46_), .Y(o25));
endmodule


