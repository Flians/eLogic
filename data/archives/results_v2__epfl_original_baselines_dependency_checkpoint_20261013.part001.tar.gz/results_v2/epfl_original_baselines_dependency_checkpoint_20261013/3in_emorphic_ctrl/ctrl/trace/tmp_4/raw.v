// Benchmark "/tmp/" written by ABC on Tue Oct 13 13:54:47 2026

module \/tmp/  ( 
    p4, p6, p2, p0, p1, p3, p5,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25  );
  input  p4, p6, p2, p0, p1, p3, p5;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25;
  wire new_n34_, new_n35_, new_n36_, new_n37_, new_n39_, new_n40_, new_n41_,
    new_n42_, new_n43_, new_n44_, new_n45_, new_n46_, new_n47_, new_n49_,
    new_n50_, new_n51_, new_n52_, new_n53_, new_n54_, new_n55_, new_n56_,
    new_n57_, new_n59_, new_n60_, new_n62_, new_n63_, new_n64_, new_n65_,
    new_n66_, new_n67_, new_n69_, new_n70_, new_n71_, new_n73_, new_n74_,
    new_n75_, new_n77_, new_n79_, new_n80_, new_n81_, new_n82_, new_n84_,
    new_n85_, new_n87_, new_n88_, new_n89_, new_n90_, new_n93_, new_n94_,
    new_n95_, new_n96_, new_n100_, new_n102_, new_n104_, new_n108_,
    new_n109_, new_n110_, new_n111_, new_n112_, new_n114_, new_n115_,
    new_n116_, new_n118_, new_n119_;
  AND2x2_ASAP7_75t_R  g00(.A(p2), .B(p3), .Y(new_n34_));
  OR3x1_ASAP7_75t_R   g01(.A(p6), .B(p0), .C(p1), .Y(new_n35_));
  NOR2x1_ASAP7_75t_R  g02(.A(p2), .B(p3), .Y(new_n36_));
  AND3x1_ASAP7_75t_R  g03(.A(new_n36_), .B(p0), .C(p1), .Y(new_n37_));
  AO21x1_ASAP7_75t_R  g04(.A1(new_n34_), .A2(new_n35_), .B(new_n37_), .Y(o0));
  INVx1_ASAP7_75t_R   g05(.A(p1), .Y(new_n39_));
  NAND2x1_ASAP7_75t_R g06(.A(p0), .B(new_n39_), .Y(new_n40_));
  INVx1_ASAP7_75t_R   g07(.A(p3), .Y(new_n41_));
  NOR2x1_ASAP7_75t_R  g08(.A(p2), .B(new_n41_), .Y(new_n42_));
  NOR2x1_ASAP7_75t_R  g09(.A(new_n40_), .B(new_n42_), .Y(new_n43_));
  AOI21x1_ASAP7_75t_R g10(.A1(p0), .A2(new_n36_), .B(new_n39_), .Y(new_n44_));
  NAND2x1_ASAP7_75t_R g11(.A(p2), .B(p3), .Y(new_n45_));
  NOR2x1_ASAP7_75t_R  g12(.A(p0), .B(p1), .Y(new_n46_));
  OA21x2_ASAP7_75t_R  g13(.A1(p6), .A2(new_n45_), .B(new_n46_), .Y(new_n47_));
  NOR3x1_ASAP7_75t_R  g14(.A(new_n43_), .B(new_n44_), .C(new_n47_), .Y(o1));
  INVx1_ASAP7_75t_R   g15(.A(p6), .Y(new_n49_));
  INVx1_ASAP7_75t_R   g16(.A(p2), .Y(new_n50_));
  AND3x1_ASAP7_75t_R  g17(.A(new_n49_), .B(new_n50_), .C(p3), .Y(new_n51_));
  INVx1_ASAP7_75t_R   g18(.A(new_n51_), .Y(new_n52_));
  INVx1_ASAP7_75t_R   g19(.A(p0), .Y(new_n53_));
  NOR2x1_ASAP7_75t_R  g20(.A(p3), .B(new_n50_), .Y(new_n54_));
  NOR2x1_ASAP7_75t_R  g21(.A(new_n53_), .B(new_n54_), .Y(new_n55_));
  NOR2x1_ASAP7_75t_R  g22(.A(p6), .B(new_n45_), .Y(new_n56_));
  OAI21x1_ASAP7_75t_R g23(.A1(p0), .A2(new_n56_), .B(new_n39_), .Y(new_n57_));
  AOI21x1_ASAP7_75t_R g24(.A1(new_n52_), .A2(new_n55_), .B(new_n57_), .Y(o2));
  NOR2x1_ASAP7_75t_R  g25(.A(new_n50_), .B(new_n46_), .Y(new_n59_));
  AO21x1_ASAP7_75t_R  g26(.A1(p6), .A2(new_n34_), .B(new_n36_), .Y(new_n60_));
  NOR2x1_ASAP7_75t_R  g27(.A(new_n59_), .B(new_n60_), .Y(o3));
  AND3x1_ASAP7_75t_R  g28(.A(p6), .B(p2), .C(p0), .Y(new_n62_));
  AO21x1_ASAP7_75t_R  g29(.A1(p4), .A2(p5), .B(new_n41_), .Y(new_n63_));
  NAND2x1_ASAP7_75t_R g30(.A(new_n62_), .B(new_n63_), .Y(new_n64_));
  AND2x2_ASAP7_75t_R  g31(.A(p4), .B(p0), .Y(new_n65_));
  AOI21x1_ASAP7_75t_R g32(.A1(new_n65_), .A2(new_n56_), .B(p1), .Y(new_n66_));
  AOI21x1_ASAP7_75t_R g33(.A1(p6), .A2(new_n42_), .B(new_n39_), .Y(new_n67_));
  AOI21x1_ASAP7_75t_R g34(.A1(new_n64_), .A2(new_n66_), .B(new_n67_), .Y(o4));
  NOR2x1_ASAP7_75t_R  g35(.A(new_n39_), .B(new_n42_), .Y(new_n69_));
  AO21x1_ASAP7_75t_R  g36(.A1(p2), .A2(p5), .B(p1), .Y(new_n70_));
  NOR2x1_ASAP7_75t_R  g37(.A(new_n70_), .B(new_n54_), .Y(new_n71_));
  NOR3x1_ASAP7_75t_R  g38(.A(new_n69_), .B(new_n71_), .C(new_n53_), .Y(o5));
  NOR2x1_ASAP7_75t_R  g39(.A(p1), .B(new_n36_), .Y(new_n73_));
  AO21x1_ASAP7_75t_R  g40(.A1(p6), .A2(p0), .B(p1), .Y(new_n74_));
  AND2x2_ASAP7_75t_R  g41(.A(new_n34_), .B(new_n74_), .Y(new_n75_));
  AO21x1_ASAP7_75t_R  g42(.A1(new_n45_), .A2(new_n73_), .B(new_n75_), .Y(o6));
  OAI21x1_ASAP7_75t_R g43(.A1(new_n49_), .A2(new_n39_), .B(new_n35_), .Y(new_n77_));
  AO21x1_ASAP7_75t_R  g44(.A1(new_n34_), .A2(new_n77_), .B(new_n37_), .Y(o7));
  AND3x1_ASAP7_75t_R  g45(.A(new_n50_), .B(new_n41_), .C(p0), .Y(new_n79_));
  INVx1_ASAP7_75t_R   g46(.A(new_n79_), .Y(new_n80_));
  AO21x1_ASAP7_75t_R  g47(.A1(p1), .A2(new_n45_), .B(new_n53_), .Y(new_n81_));
  NOR2x1_ASAP7_75t_R  g48(.A(new_n40_), .B(new_n51_), .Y(new_n82_));
  AOI21x1_ASAP7_75t_R g49(.A1(new_n80_), .A2(new_n81_), .B(new_n82_), .Y(o8));
  AO21x1_ASAP7_75t_R  g50(.A1(p2), .A2(p3), .B(p0), .Y(new_n84_));
  OAI21x1_ASAP7_75t_R g51(.A1(new_n39_), .A2(new_n79_), .B(new_n84_), .Y(new_n85_));
  NOR2x1_ASAP7_75t_R  g52(.A(new_n82_), .B(new_n85_), .Y(o9));
  NOR2x1_ASAP7_75t_R  g53(.A(p2), .B(p1), .Y(new_n87_));
  AO21x1_ASAP7_75t_R  g54(.A1(p3), .A2(new_n46_), .B(new_n87_), .Y(new_n88_));
  NAND2x1_ASAP7_75t_R g55(.A(p0), .B(new_n49_), .Y(new_n89_));
  NAND2x1_ASAP7_75t_R g56(.A(new_n89_), .B(new_n42_), .Y(new_n90_));
  OAI21x1_ASAP7_75t_R g57(.A1(new_n88_), .A2(new_n69_), .B(new_n90_), .Y(o10));
  AND3x1_ASAP7_75t_R  g58(.A(new_n36_), .B(new_n46_), .C(new_n49_), .Y(o11));
  OR3x1_ASAP7_75t_R   g59(.A(p6), .B(p2), .C(p0), .Y(new_n93_));
  NAND2x1_ASAP7_75t_R g60(.A(new_n93_), .B(new_n73_), .Y(new_n94_));
  NOR2x1_ASAP7_75t_R  g61(.A(p0), .B(p3), .Y(new_n95_));
  OR3x1_ASAP7_75t_R   g62(.A(new_n54_), .B(new_n39_), .C(new_n95_), .Y(new_n96_));
  NAND2x1_ASAP7_75t_R g63(.A(new_n94_), .B(new_n96_), .Y(o12));
  AND3x1_ASAP7_75t_R  g64(.A(new_n36_), .B(p6), .C(p1), .Y(o13));
  AND3x1_ASAP7_75t_R  g65(.A(new_n36_), .B(new_n49_), .C(p1), .Y(o14));
  AND3x1_ASAP7_75t_R  g66(.A(new_n41_), .B(p2), .C(p1), .Y(new_n100_));
  AND3x1_ASAP7_75t_R  g67(.A(new_n100_), .B(new_n49_), .C(new_n53_), .Y(o15));
  NOR2x1_ASAP7_75t_R  g68(.A(p0), .B(new_n49_), .Y(new_n102_));
  AND3x1_ASAP7_75t_R  g69(.A(new_n54_), .B(new_n102_), .C(p1), .Y(o16));
  AND2x2_ASAP7_75t_R  g70(.A(p6), .B(p0), .Y(new_n104_));
  AND3x1_ASAP7_75t_R  g71(.A(new_n54_), .B(p1), .C(new_n104_), .Y(o17));
  AND3x1_ASAP7_75t_R  g72(.A(new_n100_), .B(new_n49_), .C(p0), .Y(o18));
  AND3x1_ASAP7_75t_R  g73(.A(new_n50_), .B(new_n41_), .C(p1), .Y(o19));
  INVx1_ASAP7_75t_R   g74(.A(p4), .Y(new_n108_));
  NAND2x1_ASAP7_75t_R g75(.A(p3), .B(new_n108_), .Y(new_n109_));
  NAND2x1_ASAP7_75t_R g76(.A(new_n62_), .B(new_n109_), .Y(new_n110_));
  AOI21x1_ASAP7_75t_R g77(.A1(new_n54_), .A2(new_n102_), .B(p1), .Y(new_n111_));
  OA21x2_ASAP7_75t_R  g78(.A1(new_n45_), .A2(new_n104_), .B(p1), .Y(new_n112_));
  AOI21x1_ASAP7_75t_R g79(.A1(new_n110_), .A2(new_n111_), .B(new_n112_), .Y(o20));
  INVx1_ASAP7_75t_R   g80(.A(p5), .Y(new_n114_));
  AND3x1_ASAP7_75t_R  g81(.A(new_n65_), .B(p3), .C(new_n114_), .Y(new_n115_));
  AND3x1_ASAP7_75t_R  g82(.A(new_n39_), .B(p6), .C(p2), .Y(new_n116_));
  OA21x2_ASAP7_75t_R  g83(.A1(new_n95_), .A2(new_n115_), .B(new_n116_), .Y(o21));
  NAND2x1_ASAP7_75t_R g84(.A(p5), .B(new_n39_), .Y(new_n118_));
  OAI21x1_ASAP7_75t_R g85(.A1(new_n109_), .A2(new_n118_), .B(new_n74_), .Y(new_n119_));
  NOR3x1_ASAP7_75t_R  g86(.A(new_n119_), .B(new_n112_), .C(new_n71_), .Y(o22));
  assign              o23 = 1'b1;
  NOR3x1_ASAP7_75t_R  g87(.A(new_n90_), .B(p1), .C(new_n102_), .Y(o24));
  AND3x1_ASAP7_75t_R  g88(.A(new_n42_), .B(p6), .C(new_n46_), .Y(o25));
endmodule


