// Benchmark "/home/flynn/workplace/MIGBalance/results_v2/epfl_original_baselines_dependency_checkpoint_20261013/3in_core_ctrl/ctrl.resyn2" written by ABC on Tue Oct 13 13:03:11 2026

module \/home/flynn/workplace/MIGBalance/results_v2/epfl_original_baselines_dependency_checkpoint_20261013/3in_core_ctrl/ctrl.resyn2  ( 
    \opcode[0] , \opcode[1] , \opcode[2] , \opcode[3] , \opcode[4] ,
    \op_ext[0] , \op_ext[1] ,
    \sel_reg_dst[0] , \sel_reg_dst[1] , \sel_alu_opB[0] , \sel_alu_opB[1] ,
    \alu_op[0] , \alu_op[1] , \alu_op[2] , \alu_op_ext[0] ,
    \alu_op_ext[1] , \alu_op_ext[2] , \alu_op_ext[3] , halt, reg_write,
    sel_pc_opA, sel_pc_opB, beqz, bnez, bgez, bltz, jump, Cin, invA, invB,
    sign, mem_write, sel_wb  );
  input  \opcode[0] , \opcode[1] , \opcode[2] , \opcode[3] , \opcode[4] ,
    \op_ext[0] , \op_ext[1] ;
  output \sel_reg_dst[0] , \sel_reg_dst[1] , \sel_alu_opB[0] ,
    \sel_alu_opB[1] , \alu_op[0] , \alu_op[1] , \alu_op[2] ,
    \alu_op_ext[0] , \alu_op_ext[1] , \alu_op_ext[2] , \alu_op_ext[3] ,
    halt, reg_write, sel_pc_opA, sel_pc_opB, beqz, bnez, bgez, bltz, jump,
    Cin, invA, invB, sign, mem_write, sel_wb;
  wire new_n34_, new_n35_, new_n36_, new_n37_, new_n38_, new_n39_, new_n40_,
    new_n42_, new_n43_, new_n44_, new_n45_, new_n46_, new_n47_, new_n48_,
    new_n50_, new_n51_, new_n52_, new_n53_, new_n54_, new_n55_, new_n57_,
    new_n58_, new_n59_, new_n61_, new_n62_, new_n63_, new_n64_, new_n65_,
    new_n66_, new_n67_, new_n68_, new_n70_, new_n72_, new_n73_, new_n74_,
    new_n75_, new_n77_, new_n78_, new_n80_, new_n81_, new_n83_, new_n85_,
    new_n86_, new_n87_, new_n90_, new_n91_, new_n92_, new_n96_, new_n99_,
    new_n103_, new_n104_, new_n105_, new_n106_, new_n108_, new_n109_,
    new_n110_, new_n111_, new_n113_, new_n116_;
  AND2x2_ASAP7_75t_R  g00(.A(\opcode[3] ), .B(\opcode[4] ), .Y(new_n34_));
  INVx1_ASAP7_75t_R   g01(.A(new_n34_), .Y(new_n35_));
  NOR2x1_ASAP7_75t_R  g02(.A(\opcode[0] ), .B(\opcode[1] ), .Y(new_n36_));
  INVx1_ASAP7_75t_R   g03(.A(\opcode[2] ), .Y(new_n37_));
  INVx1_ASAP7_75t_R   g04(.A(\opcode[1] ), .Y(new_n38_));
  OR3x1_ASAP7_75t_R   g05(.A(new_n38_), .B(\opcode[3] ), .C(\opcode[4] ), .Y(new_n39_));
  AO21x1_ASAP7_75t_R  g06(.A1(new_n39_), .A2(new_n35_), .B(new_n37_), .Y(new_n40_));
  OAI21x1_ASAP7_75t_R g07(.A1(new_n35_), .A2(new_n36_), .B(new_n40_), .Y(\sel_reg_dst[0] ));
  INVx1_ASAP7_75t_R   g08(.A(\opcode[3] ), .Y(new_n42_));
  AO21x1_ASAP7_75t_R  g09(.A1(new_n42_), .A2(\opcode[4] ), .B(new_n38_), .Y(new_n43_));
  INVx1_ASAP7_75t_R   g10(.A(\opcode[0] ), .Y(new_n44_));
  AND3x1_ASAP7_75t_R  g11(.A(new_n44_), .B(\opcode[3] ), .C(\opcode[4] ), .Y(new_n45_));
  OA21x2_ASAP7_75t_R  g12(.A1(new_n45_), .A2(\opcode[1] ), .B(new_n43_), .Y(new_n46_));
  NOR2x1_ASAP7_75t_R  g13(.A(\opcode[3] ), .B(\opcode[4] ), .Y(new_n47_));
  AO21x1_ASAP7_75t_R  g14(.A1(new_n47_), .A2(\opcode[1] ), .B(new_n37_), .Y(new_n48_));
  OA21x2_ASAP7_75t_R  g15(.A1(new_n46_), .A2(\opcode[2] ), .B(new_n48_), .Y(\sel_reg_dst[1] ));
  NAND2x1_ASAP7_75t_R g16(.A(\opcode[4] ), .B(new_n42_), .Y(new_n50_));
  INVx1_ASAP7_75t_R   g17(.A(new_n50_), .Y(new_n51_));
  AO21x1_ASAP7_75t_R  g18(.A1(new_n51_), .A2(new_n44_), .B(new_n38_), .Y(new_n52_));
  INVx1_ASAP7_75t_R   g19(.A(\opcode[4] ), .Y(new_n53_));
  AND2x2_ASAP7_75t_R  g20(.A(new_n53_), .B(\opcode[3] ), .Y(new_n54_));
  OA21x2_ASAP7_75t_R  g21(.A1(new_n45_), .A2(\opcode[1] ), .B(new_n37_), .Y(new_n55_));
  OA21x2_ASAP7_75t_R  g22(.A1(new_n52_), .A2(new_n54_), .B(new_n55_), .Y(\sel_alu_opB[0] ));
  NOR2x1_ASAP7_75t_R  g23(.A(\opcode[1] ), .B(\opcode[2] ), .Y(new_n57_));
  INVx1_ASAP7_75t_R   g24(.A(new_n57_), .Y(new_n58_));
  AO21x1_ASAP7_75t_R  g25(.A1(new_n58_), .A2(\opcode[3] ), .B(new_n47_), .Y(new_n59_));
  AOI21x1_ASAP7_75t_R g26(.A1(\opcode[0] ), .A2(new_n34_), .B(new_n59_), .Y(\sel_alu_opB[1] ));
  OA21x2_ASAP7_75t_R  g27(.A1(new_n53_), .A2(\op_ext[1] ), .B(\opcode[3] ), .Y(new_n61_));
  INVx1_ASAP7_75t_R   g28(.A(\op_ext[0] ), .Y(new_n62_));
  NAND3x1_ASAP7_75t_R g29(.A(new_n62_), .B(\op_ext[1] ), .C(\opcode[4] ), .Y(new_n63_));
  AND3x1_ASAP7_75t_R  g30(.A(new_n63_), .B(\opcode[0] ), .C(new_n61_), .Y(new_n64_));
  AND2x2_ASAP7_75t_R  g31(.A(new_n45_), .B(\op_ext[0] ), .Y(new_n65_));
  OAI21x1_ASAP7_75t_R g32(.A1(new_n65_), .A2(new_n64_), .B(\opcode[1] ), .Y(new_n66_));
  AND2x2_ASAP7_75t_R  g33(.A(new_n50_), .B(\opcode[2] ), .Y(new_n67_));
  AO21x1_ASAP7_75t_R  g34(.A1(new_n44_), .A2(\opcode[2] ), .B(new_n67_), .Y(new_n68_));
  AOI21x1_ASAP7_75t_R g35(.A1(new_n37_), .A2(new_n66_), .B(new_n68_), .Y(\alu_op[0] ));
  NOR2x1_ASAP7_75t_R  g36(.A(new_n38_), .B(new_n67_), .Y(new_n70_));
  OA21x2_ASAP7_75t_R  g37(.A1(\opcode[2] ), .A2(new_n61_), .B(new_n70_), .Y(\alu_op[1] ));
  AND2x2_ASAP7_75t_R  g38(.A(\opcode[0] ), .B(\opcode[1] ), .Y(new_n72_));
  INVx1_ASAP7_75t_R   g39(.A(new_n72_), .Y(new_n73_));
  AND3x1_ASAP7_75t_R  g40(.A(new_n73_), .B(new_n34_), .C(new_n37_), .Y(new_n74_));
  AO21x1_ASAP7_75t_R  g41(.A1(new_n35_), .A2(\opcode[2] ), .B(new_n47_), .Y(new_n75_));
  NOR2x1_ASAP7_75t_R  g42(.A(new_n75_), .B(new_n74_), .Y(\alu_op[2] ));
  OR3x1_ASAP7_75t_R   g43(.A(new_n44_), .B(new_n42_), .C(new_n53_), .Y(new_n77_));
  AOI21x1_ASAP7_75t_R g44(.A1(new_n39_), .A2(new_n77_), .B(new_n37_), .Y(new_n78_));
  AO21x1_ASAP7_75t_R  g45(.A1(new_n45_), .A2(new_n57_), .B(new_n78_), .Y(\alu_op_ext[0] ));
  OR3x1_ASAP7_75t_R   g46(.A(new_n47_), .B(new_n37_), .C(new_n34_), .Y(new_n80_));
  AND2x2_ASAP7_75t_R  g47(.A(new_n80_), .B(\opcode[1] ), .Y(new_n81_));
  OA21x2_ASAP7_75t_R  g48(.A1(new_n52_), .A2(\opcode[2] ), .B(new_n81_), .Y(\alu_op_ext[1] ));
  OA21x2_ASAP7_75t_R  g49(.A1(new_n34_), .A2(new_n58_), .B(new_n48_), .Y(new_n83_));
  OA21x2_ASAP7_75t_R  g50(.A1(new_n52_), .A2(\opcode[2] ), .B(new_n83_), .Y(\alu_op_ext[2] ));
  AO21x1_ASAP7_75t_R  g51(.A1(new_n38_), .A2(\opcode[4] ), .B(new_n42_), .Y(new_n85_));
  AO21x1_ASAP7_75t_R  g52(.A1(new_n44_), .A2(\opcode[1] ), .B(new_n50_), .Y(new_n86_));
  AND3x1_ASAP7_75t_R  g53(.A(new_n86_), .B(new_n37_), .C(new_n85_), .Y(new_n87_));
  NOR2x1_ASAP7_75t_R  g54(.A(new_n67_), .B(new_n87_), .Y(\alu_op_ext[3] ));
  AND3x1_ASAP7_75t_R  g55(.A(new_n47_), .B(new_n57_), .C(new_n44_), .Y(halt));
  NOR2x1_ASAP7_75t_R  g56(.A(new_n53_), .B(new_n36_), .Y(new_n90_));
  OA21x2_ASAP7_75t_R  g57(.A1(new_n90_), .A2(\opcode[3] ), .B(new_n37_), .Y(new_n91_));
  AO21x1_ASAP7_75t_R  g58(.A1(new_n42_), .A2(\opcode[1] ), .B(\opcode[4] ), .Y(new_n92_));
  AO21x1_ASAP7_75t_R  g59(.A1(\opcode[2] ), .A2(new_n92_), .B(new_n91_), .Y(reg_write));
  AND3x1_ASAP7_75t_R  g60(.A(new_n47_), .B(\opcode[0] ), .C(\opcode[2] ), .Y(sel_pc_opA));
  AND3x1_ASAP7_75t_R  g61(.A(new_n47_), .B(new_n44_), .C(\opcode[2] ), .Y(sel_pc_opB));
  AND3x1_ASAP7_75t_R  g62(.A(new_n38_), .B(new_n53_), .C(\opcode[3] ), .Y(new_n96_));
  AND3x1_ASAP7_75t_R  g63(.A(new_n96_), .B(new_n44_), .C(\opcode[2] ), .Y(beqz));
  AND3x1_ASAP7_75t_R  g64(.A(new_n96_), .B(\opcode[0] ), .C(\opcode[2] ), .Y(bnez));
  AND3x1_ASAP7_75t_R  g65(.A(new_n53_), .B(\opcode[2] ), .C(\opcode[3] ), .Y(new_n99_));
  AND2x2_ASAP7_75t_R  g66(.A(new_n99_), .B(new_n72_), .Y(bgez));
  AND3x1_ASAP7_75t_R  g67(.A(new_n99_), .B(new_n44_), .C(\opcode[1] ), .Y(bltz));
  AND3x1_ASAP7_75t_R  g68(.A(new_n42_), .B(new_n53_), .C(\opcode[2] ), .Y(jump));
  AO21x1_ASAP7_75t_R  g69(.A1(new_n73_), .A2(new_n34_), .B(new_n37_), .Y(new_n103_));
  AO21x1_ASAP7_75t_R  g70(.A1(new_n62_), .A2(\opcode[4] ), .B(new_n42_), .Y(new_n104_));
  NOR2x1_ASAP7_75t_R  g71(.A(new_n104_), .B(new_n73_), .Y(new_n105_));
  AO21x1_ASAP7_75t_R  g72(.A1(new_n96_), .A2(\opcode[0] ), .B(\opcode[2] ), .Y(new_n106_));
  OA21x2_ASAP7_75t_R  g73(.A1(new_n106_), .A2(new_n105_), .B(new_n103_), .Y(Cin));
  INVx1_ASAP7_75t_R   g74(.A(\op_ext[1] ), .Y(new_n108_));
  AND2x2_ASAP7_75t_R  g75(.A(\opcode[1] ), .B(\op_ext[0] ), .Y(new_n109_));
  AND3x1_ASAP7_75t_R  g76(.A(new_n34_), .B(new_n109_), .C(new_n108_), .Y(new_n110_));
  AND2x2_ASAP7_75t_R  g77(.A(new_n37_), .B(\opcode[0] ), .Y(new_n111_));
  OA21x2_ASAP7_75t_R  g78(.A1(new_n110_), .A2(new_n96_), .B(new_n111_), .Y(invA));
  AND3x1_ASAP7_75t_R  g79(.A(new_n63_), .B(new_n61_), .C(new_n72_), .Y(new_n113_));
  OA21x2_ASAP7_75t_R  g80(.A1(new_n113_), .A2(\opcode[2] ), .B(new_n103_), .Y(invB));
  AND3x1_ASAP7_75t_R  g81(.A(new_n37_), .B(new_n42_), .C(\opcode[4] ), .Y(new_n116_));
  OA21x2_ASAP7_75t_R  g82(.A1(new_n36_), .A2(new_n72_), .B(new_n116_), .Y(mem_write));
  AND3x1_ASAP7_75t_R  g83(.A(new_n51_), .B(new_n111_), .C(new_n38_), .Y(sel_wb));
  assign              sign = 1'b1;
endmodule


