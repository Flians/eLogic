// Benchmark "/home/flynn/workplace/MIGBalance/results_v2/epfl_original_baselines_dependency_checkpoint_20261013/3in_core_ctrl/ctrl.resyn2" written by ABC on Tue Oct 13 13:03:10 2026

module \/home/flynn/workplace/MIGBalance/results_v2/epfl_original_baselines_dependency_checkpoint_20261013/3in_core_ctrl/ctrl.resyn2  ( 
    \opcode[0] , \opcode[1] , \opcode[2] , \opcode[3] , \opcode[4] ,
    \op_ext[0] , \op_ext[1] ,
    \sel_reg_dst[0] , \sel_reg_dst[1] , \sel_alu_opB[0] , \sel_alu_opB[1] ,
    \alu_op[0] , \alu_op[1] , \alu_op[2] , \alu_op_ext[0] ,
    \alu_op_ext[1] , \alu_op_ext[2] , \alu_op_ext[3] , halt, reg_write,
    sel_pc_opA, sel_pc_opB, beqz, bnez, bgez, bltz, jump, Cin, invA, invB,
    sign, mem_write, sel_wb  );
  input  \opcode[0] , \opcode[1] , \opcode[2] , \opcode[3] , \opcode[4] ,
    \op_ext[0] , \op_ext[1] ;
  output \sel_reg_dst[0] , \sel_reg_dst[1] , \sel_alu_opB[0] ,
    \sel_alu_opB[1] , \alu_op[0] , \alu_op[1] , \alu_op[2] ,
    \alu_op_ext[0] , \alu_op_ext[1] , \alu_op_ext[2] , \alu_op_ext[3] ,
    halt, reg_write, sel_pc_opA, sel_pc_opB, beqz, bnez, bgez, bltz, jump,
    Cin, invA, invB, sign, mem_write, sel_wb;
  wire new_n34_, new_n35_, new_n36_, new_n37_, new_n38_, new_n39_, new_n40_,
    new_n42_, new_n43_, new_n44_, new_n45_, new_n46_, new_n47_, new_n48_,
    new_n49_, new_n51_, new_n52_, new_n53_, new_n54_, new_n56_, new_n57_,
    new_n58_, new_n59_, new_n60_, new_n62_, new_n63_, new_n64_, new_n65_,
    new_n66_, new_n67_, new_n68_, new_n69_, new_n71_, new_n73_, new_n74_,
    new_n75_, new_n76_, new_n78_, new_n79_, new_n81_, new_n82_, new_n84_,
    new_n86_, new_n87_, new_n88_, new_n89_, new_n92_, new_n93_, new_n94_,
    new_n98_, new_n101_, new_n105_, new_n106_, new_n107_, new_n109_,
    new_n110_, new_n111_, new_n113_, new_n116_;
  AND2x2_ASAP7_75t_R  g00(.A(\opcode[3] ), .B(\opcode[4] ), .Y(new_n34_));
  NOR2x1_ASAP7_75t_R  g01(.A(\opcode[0] ), .B(\opcode[1] ), .Y(new_n35_));
  INVx1_ASAP7_75t_R   g02(.A(new_n35_), .Y(new_n36_));
  INVx1_ASAP7_75t_R   g03(.A(\opcode[3] ), .Y(new_n37_));
  INVx1_ASAP7_75t_R   g04(.A(\opcode[4] ), .Y(new_n38_));
  AND3x1_ASAP7_75t_R  g05(.A(new_n37_), .B(new_n38_), .C(\opcode[1] ), .Y(new_n39_));
  OA21x2_ASAP7_75t_R  g06(.A1(new_n39_), .A2(new_n34_), .B(\opcode[2] ), .Y(new_n40_));
  AO21x1_ASAP7_75t_R  g07(.A1(new_n34_), .A2(new_n36_), .B(new_n40_), .Y(\sel_reg_dst[0] ));
  INVx1_ASAP7_75t_R   g08(.A(\opcode[2] ), .Y(new_n42_));
  AND2x2_ASAP7_75t_R  g09(.A(new_n37_), .B(\opcode[4] ), .Y(new_n43_));
  INVx1_ASAP7_75t_R   g10(.A(new_n43_), .Y(new_n44_));
  INVx1_ASAP7_75t_R   g11(.A(\opcode[0] ), .Y(new_n45_));
  AND3x1_ASAP7_75t_R  g12(.A(new_n45_), .B(\opcode[3] ), .C(\opcode[4] ), .Y(new_n46_));
  NOR2x1_ASAP7_75t_R  g13(.A(\opcode[1] ), .B(new_n46_), .Y(new_n47_));
  AO21x1_ASAP7_75t_R  g14(.A1(\opcode[1] ), .A2(new_n44_), .B(new_n47_), .Y(new_n48_));
  NOR2x1_ASAP7_75t_R  g15(.A(new_n42_), .B(new_n39_), .Y(new_n49_));
  AOI21x1_ASAP7_75t_R g16(.A1(new_n42_), .A2(new_n48_), .B(new_n49_), .Y(\sel_reg_dst[1] ));
  INVx1_ASAP7_75t_R   g17(.A(\opcode[1] ), .Y(new_n51_));
  AO21x1_ASAP7_75t_R  g18(.A1(new_n43_), .A2(new_n45_), .B(new_n51_), .Y(new_n52_));
  AND2x2_ASAP7_75t_R  g19(.A(new_n38_), .B(\opcode[3] ), .Y(new_n53_));
  NOR2x1_ASAP7_75t_R  g20(.A(\opcode[2] ), .B(new_n47_), .Y(new_n54_));
  OA21x2_ASAP7_75t_R  g21(.A1(new_n52_), .A2(new_n53_), .B(new_n54_), .Y(\sel_alu_opB[0] ));
  INVx1_ASAP7_75t_R   g22(.A(new_n34_), .Y(new_n56_));
  NOR2x1_ASAP7_75t_R  g23(.A(\opcode[3] ), .B(\opcode[4] ), .Y(new_n57_));
  INVx1_ASAP7_75t_R   g24(.A(new_n57_), .Y(new_n58_));
  NOR2x1_ASAP7_75t_R  g25(.A(\opcode[1] ), .B(\opcode[2] ), .Y(new_n59_));
  OA21x2_ASAP7_75t_R  g26(.A1(new_n59_), .A2(new_n37_), .B(new_n58_), .Y(new_n60_));
  OA21x2_ASAP7_75t_R  g27(.A1(new_n45_), .A2(new_n56_), .B(new_n60_), .Y(\sel_alu_opB[1] ));
  INVx1_ASAP7_75t_R   g28(.A(\op_ext[1] ), .Y(new_n62_));
  AO21x1_ASAP7_75t_R  g29(.A1(new_n62_), .A2(\opcode[4] ), .B(new_n37_), .Y(new_n63_));
  NOR2x1_ASAP7_75t_R  g30(.A(\op_ext[0] ), .B(new_n38_), .Y(new_n64_));
  AO21x1_ASAP7_75t_R  g31(.A1(new_n64_), .A2(\op_ext[1] ), .B(new_n63_), .Y(new_n65_));
  NOR2x1_ASAP7_75t_R  g32(.A(new_n45_), .B(new_n65_), .Y(new_n66_));
  AO21x1_ASAP7_75t_R  g33(.A1(\op_ext[0] ), .A2(new_n46_), .B(new_n66_), .Y(new_n67_));
  AO21x1_ASAP7_75t_R  g34(.A1(new_n67_), .A2(\opcode[1] ), .B(\opcode[2] ), .Y(new_n68_));
  AO21x1_ASAP7_75t_R  g35(.A1(new_n43_), .A2(\opcode[0] ), .B(new_n42_), .Y(new_n69_));
  AND2x2_ASAP7_75t_R  g36(.A(new_n68_), .B(new_n69_), .Y(\alu_op[0] ));
  AO21x1_ASAP7_75t_R  g37(.A1(new_n44_), .A2(\opcode[2] ), .B(new_n51_), .Y(new_n71_));
  AOI21x1_ASAP7_75t_R g38(.A1(new_n42_), .A2(new_n63_), .B(new_n71_), .Y(\alu_op[1] ));
  AND2x2_ASAP7_75t_R  g39(.A(\opcode[0] ), .B(\opcode[1] ), .Y(new_n73_));
  INVx1_ASAP7_75t_R   g40(.A(new_n73_), .Y(new_n74_));
  AND3x1_ASAP7_75t_R  g41(.A(new_n74_), .B(new_n34_), .C(new_n42_), .Y(new_n75_));
  AO21x1_ASAP7_75t_R  g42(.A1(new_n56_), .A2(\opcode[2] ), .B(new_n57_), .Y(new_n76_));
  NOR2x1_ASAP7_75t_R  g43(.A(new_n76_), .B(new_n75_), .Y(\alu_op[2] ));
  AO21x1_ASAP7_75t_R  g44(.A1(\opcode[0] ), .A2(new_n34_), .B(new_n39_), .Y(new_n78_));
  AND2x2_ASAP7_75t_R  g45(.A(new_n46_), .B(new_n59_), .Y(new_n79_));
  AO21x1_ASAP7_75t_R  g46(.A1(\opcode[2] ), .A2(new_n78_), .B(new_n79_), .Y(\alu_op_ext[0] ));
  OR3x1_ASAP7_75t_R   g47(.A(new_n57_), .B(new_n42_), .C(new_n34_), .Y(new_n81_));
  AND2x2_ASAP7_75t_R  g48(.A(new_n81_), .B(\opcode[1] ), .Y(new_n82_));
  OA21x2_ASAP7_75t_R  g49(.A1(\opcode[2] ), .A2(new_n52_), .B(new_n82_), .Y(\alu_op_ext[1] ));
  AOI21x1_ASAP7_75t_R g50(.A1(new_n56_), .A2(new_n59_), .B(new_n49_), .Y(new_n84_));
  OA21x2_ASAP7_75t_R  g51(.A1(\opcode[2] ), .A2(new_n52_), .B(new_n84_), .Y(\alu_op_ext[2] ));
  AO21x1_ASAP7_75t_R  g52(.A1(new_n51_), .A2(\opcode[4] ), .B(new_n37_), .Y(new_n86_));
  AND2x2_ASAP7_75t_R  g53(.A(new_n45_), .B(\opcode[1] ), .Y(new_n87_));
  OA21x2_ASAP7_75t_R  g54(.A1(new_n44_), .A2(new_n87_), .B(new_n42_), .Y(new_n88_));
  NAND2x1_ASAP7_75t_R g55(.A(new_n86_), .B(new_n88_), .Y(new_n89_));
  OA21x2_ASAP7_75t_R  g56(.A1(new_n42_), .A2(new_n43_), .B(new_n89_), .Y(\alu_op_ext[3] ));
  AND3x1_ASAP7_75t_R  g57(.A(new_n57_), .B(new_n59_), .C(new_n45_), .Y(halt));
  NOR2x1_ASAP7_75t_R  g58(.A(new_n38_), .B(new_n35_), .Y(new_n92_));
  OA21x2_ASAP7_75t_R  g59(.A1(new_n92_), .A2(\opcode[3] ), .B(new_n42_), .Y(new_n93_));
  AO21x1_ASAP7_75t_R  g60(.A1(new_n37_), .A2(\opcode[1] ), .B(\opcode[4] ), .Y(new_n94_));
  AO21x1_ASAP7_75t_R  g61(.A1(\opcode[2] ), .A2(new_n94_), .B(new_n93_), .Y(reg_write));
  AND3x1_ASAP7_75t_R  g62(.A(new_n57_), .B(\opcode[0] ), .C(\opcode[2] ), .Y(sel_pc_opA));
  AND3x1_ASAP7_75t_R  g63(.A(new_n57_), .B(new_n45_), .C(\opcode[2] ), .Y(sel_pc_opB));
  AND3x1_ASAP7_75t_R  g64(.A(new_n51_), .B(new_n38_), .C(\opcode[3] ), .Y(new_n98_));
  AND3x1_ASAP7_75t_R  g65(.A(new_n98_), .B(new_n45_), .C(\opcode[2] ), .Y(beqz));
  AND3x1_ASAP7_75t_R  g66(.A(new_n98_), .B(\opcode[0] ), .C(\opcode[2] ), .Y(bnez));
  AND3x1_ASAP7_75t_R  g67(.A(new_n38_), .B(\opcode[2] ), .C(\opcode[3] ), .Y(new_n101_));
  AND2x2_ASAP7_75t_R  g68(.A(new_n101_), .B(new_n73_), .Y(bgez));
  AND2x2_ASAP7_75t_R  g69(.A(new_n101_), .B(new_n87_), .Y(bltz));
  AND3x1_ASAP7_75t_R  g70(.A(new_n37_), .B(new_n38_), .C(\opcode[2] ), .Y(jump));
  OA21x2_ASAP7_75t_R  g71(.A1(new_n56_), .A2(new_n73_), .B(\opcode[2] ), .Y(new_n105_));
  OR3x1_ASAP7_75t_R   g72(.A(new_n64_), .B(new_n74_), .C(new_n37_), .Y(new_n106_));
  AOI21x1_ASAP7_75t_R g73(.A1(\opcode[0] ), .A2(new_n98_), .B(\opcode[2] ), .Y(new_n107_));
  AOI21x1_ASAP7_75t_R g74(.A1(new_n107_), .A2(new_n106_), .B(new_n105_), .Y(Cin));
  AND2x2_ASAP7_75t_R  g75(.A(\opcode[1] ), .B(\op_ext[0] ), .Y(new_n109_));
  AND3x1_ASAP7_75t_R  g76(.A(new_n34_), .B(new_n109_), .C(new_n62_), .Y(new_n110_));
  AND2x2_ASAP7_75t_R  g77(.A(new_n42_), .B(\opcode[0] ), .Y(new_n111_));
  OA21x2_ASAP7_75t_R  g78(.A1(new_n110_), .A2(new_n98_), .B(new_n111_), .Y(invA));
  OR3x1_ASAP7_75t_R   g79(.A(new_n65_), .B(new_n45_), .C(new_n51_), .Y(new_n113_));
  AOI21x1_ASAP7_75t_R g80(.A1(new_n42_), .A2(new_n113_), .B(new_n105_), .Y(invB));
  NAND2x1_ASAP7_75t_R g81(.A(new_n74_), .B(new_n36_), .Y(new_n116_));
  AND3x1_ASAP7_75t_R  g82(.A(new_n116_), .B(new_n42_), .C(new_n43_), .Y(mem_write));
  AND3x1_ASAP7_75t_R  g83(.A(new_n43_), .B(new_n111_), .C(new_n51_), .Y(sel_wb));
  assign              sign = 1'b1;
endmodule


