// Benchmark "/home/flynn/workplace/MIGBalance/results_v2/epfl_original_baselines_dependency_checkpoint_20261013/3in_core_router/router.resyn2" written by ABC on Tue Oct 13 14:44:18 2026

module \/home/flynn/workplace/MIGBalance/results_v2/epfl_original_baselines_dependency_checkpoint_20261013/3in_core_router/router.resyn2  ( 
    \dest_x[0] , \dest_x[1] , \dest_x[2] , \dest_x[3] , \dest_x[4] ,
    \dest_x[5] , \dest_x[6] , \dest_x[7] , \dest_x[8] , \dest_x[9] ,
    \dest_x[10] , \dest_x[11] , \dest_x[12] , \dest_x[13] , \dest_x[14] ,
    \dest_x[15] , \dest_x[16] , \dest_x[17] , \dest_x[18] , \dest_x[19] ,
    \dest_x[20] , \dest_x[21] , \dest_x[22] , \dest_x[23] , \dest_x[24] ,
    \dest_x[25] , \dest_x[26] , \dest_x[27] , \dest_x[28] , \dest_x[29] ,
    \dest_y[0] , \dest_y[1] , \dest_y[2] , \dest_y[3] , \dest_y[4] ,
    \dest_y[5] , \dest_y[6] , \dest_y[7] , \dest_y[8] , \dest_y[9] ,
    \dest_y[10] , \dest_y[11] , \dest_y[12] , \dest_y[13] , \dest_y[14] ,
    \dest_y[15] , \dest_y[16] , \dest_y[17] , \dest_y[18] , \dest_y[19] ,
    \dest_y[20] , \dest_y[21] , \dest_y[22] , \dest_y[23] , \dest_y[24] ,
    \dest_y[25] , \dest_y[26] , \dest_y[27] , \dest_y[28] , \dest_y[29] ,
    \outport[0] , \outport[1] , \outport[2] , \outport[3] , \outport[4] ,
    \outport[5] , \outport[6] , \outport[7] , \outport[8] , \outport[9] ,
    \outport[10] , \outport[11] , \outport[12] , \outport[13] ,
    \outport[14] , \outport[15] , \outport[16] , \outport[17] ,
    \outport[18] , \outport[19] , \outport[20] , \outport[21] ,
    \outport[22] , \outport[23] , \outport[24] , \outport[25] ,
    \outport[26] , \outport[27] , \outport[28] , \outport[29]   );
  input  \dest_x[0] , \dest_x[1] , \dest_x[2] , \dest_x[3] , \dest_x[4] ,
    \dest_x[5] , \dest_x[6] , \dest_x[7] , \dest_x[8] , \dest_x[9] ,
    \dest_x[10] , \dest_x[11] , \dest_x[12] , \dest_x[13] , \dest_x[14] ,
    \dest_x[15] , \dest_x[16] , \dest_x[17] , \dest_x[18] , \dest_x[19] ,
    \dest_x[20] , \dest_x[21] , \dest_x[22] , \dest_x[23] , \dest_x[24] ,
    \dest_x[25] , \dest_x[26] , \dest_x[27] , \dest_x[28] , \dest_x[29] ,
    \dest_y[0] , \dest_y[1] , \dest_y[2] , \dest_y[3] , \dest_y[4] ,
    \dest_y[5] , \dest_y[6] , \dest_y[7] , \dest_y[8] , \dest_y[9] ,
    \dest_y[10] , \dest_y[11] , \dest_y[12] , \dest_y[13] , \dest_y[14] ,
    \dest_y[15] , \dest_y[16] , \dest_y[17] , \dest_y[18] , \dest_y[19] ,
    \dest_y[20] , \dest_y[21] , \dest_y[22] , \dest_y[23] , \dest_y[24] ,
    \dest_y[25] , \dest_y[26] , \dest_y[27] , \dest_y[28] , \dest_y[29] ;
  output \outport[0] , \outport[1] , \outport[2] , \outport[3] , \outport[4] ,
    \outport[5] , \outport[6] , \outport[7] , \outport[8] , \outport[9] ,
    \outport[10] , \outport[11] , \outport[12] , \outport[13] ,
    \outport[14] , \outport[15] , \outport[16] , \outport[17] ,
    \outport[18] , \outport[19] , \outport[20] , \outport[21] ,
    \outport[22] , \outport[23] , \outport[24] , \outport[25] ,
    \outport[26] , \outport[27] , \outport[28] , \outport[29] ;
  wire new_n91_, new_n92_, new_n93_, new_n94_, new_n95_, new_n96_, new_n97_,
    new_n98_, new_n99_, new_n100_, new_n101_, new_n102_, new_n103_,
    new_n104_, new_n105_, new_n106_, new_n107_, new_n108_, new_n109_,
    new_n110_, new_n111_, new_n112_, new_n113_, new_n114_, new_n115_,
    new_n116_, new_n117_, new_n118_, new_n119_, new_n120_, new_n121_,
    new_n122_, new_n123_, new_n124_, new_n125_, new_n126_, new_n127_,
    new_n128_, new_n129_, new_n130_, new_n131_, new_n132_, new_n133_,
    new_n134_, new_n135_, new_n136_, new_n137_, new_n138_, new_n139_,
    new_n140_, new_n141_, new_n142_, new_n143_, new_n144_, new_n145_,
    new_n146_, new_n147_, new_n148_, new_n149_, new_n150_, new_n151_,
    new_n152_, new_n153_, new_n154_, new_n156_, new_n157_, new_n158_,
    new_n159_, new_n160_, new_n161_, new_n162_, new_n163_, new_n164_,
    new_n165_, new_n166_, new_n167_, new_n168_, new_n169_, new_n170_,
    new_n171_, new_n172_, new_n173_, new_n174_, new_n175_, new_n176_,
    new_n177_, new_n178_, new_n179_, new_n180_, new_n181_, new_n182_,
    new_n183_, new_n184_, new_n185_, new_n186_, new_n187_, new_n188_,
    new_n189_, new_n190_, new_n191_, new_n192_, new_n193_, new_n194_,
    new_n195_, new_n196_, new_n197_, new_n198_, new_n199_, new_n200_,
    new_n201_, new_n202_, new_n203_, new_n204_, new_n205_, new_n206_,
    new_n207_, new_n208_, new_n209_, new_n210_, new_n211_, new_n212_,
    new_n213_, new_n214_, new_n215_, new_n216_, new_n217_, new_n218_,
    new_n219_, new_n220_, new_n221_, new_n222_, new_n223_, new_n224_,
    new_n225_, new_n226_, new_n227_, new_n228_, new_n230_, new_n231_;
  INVx1_ASAP7_75t_R   g000(.A(\dest_x[14] ), .Y(new_n91_));
  INVx1_ASAP7_75t_R   g001(.A(\dest_x[11] ), .Y(new_n92_));
  NOR2x1_ASAP7_75t_R  g002(.A(\dest_x[9] ), .B(\dest_x[10] ), .Y(new_n93_));
  NOR2x1_ASAP7_75t_R  g003(.A(\dest_x[12] ), .B(\dest_x[13] ), .Y(new_n94_));
  OA21x2_ASAP7_75t_R  g004(.A1(new_n93_), .A2(new_n92_), .B(new_n94_), .Y(new_n95_));
  NOR2x1_ASAP7_75t_R  g005(.A(new_n91_), .B(new_n95_), .Y(new_n96_));
  AND2x2_ASAP7_75t_R  g006(.A(new_n96_), .B(\dest_x[15] ), .Y(new_n97_));
  NOR2x1_ASAP7_75t_R  g007(.A(\dest_x[16] ), .B(new_n97_), .Y(new_n98_));
  INVx1_ASAP7_75t_R   g008(.A(new_n98_), .Y(new_n99_));
  AND2x2_ASAP7_75t_R  g009(.A(new_n99_), .B(\dest_x[17] ), .Y(new_n100_));
  AND3x1_ASAP7_75t_R  g010(.A(\dest_x[27] ), .B(\dest_x[28] ), .C(\dest_x[29] ), .Y(new_n101_));
  NOR2x1_ASAP7_75t_R  g011(.A(\dest_x[18] ), .B(new_n100_), .Y(new_n102_));
  INVx1_ASAP7_75t_R   g012(.A(new_n102_), .Y(new_n103_));
  AND3x1_ASAP7_75t_R  g013(.A(new_n103_), .B(\dest_x[19] ), .C(\dest_x[20] ), .Y(new_n104_));
  OR3x1_ASAP7_75t_R   g014(.A(new_n104_), .B(\dest_x[21] ), .C(\dest_x[22] ), .Y(new_n105_));
  AND3x1_ASAP7_75t_R  g015(.A(new_n105_), .B(\dest_x[23] ), .C(\dest_x[24] ), .Y(new_n106_));
  AO21x1_ASAP7_75t_R  g016(.A1(new_n106_), .A2(\dest_x[25] ), .B(\dest_x[26] ), .Y(new_n107_));
  NAND2x1_ASAP7_75t_R g017(.A(new_n101_), .B(new_n107_), .Y(new_n108_));
  NOR2x1_ASAP7_75t_R  g018(.A(\dest_x[15] ), .B(new_n96_), .Y(new_n109_));
  NAND2x1_ASAP7_75t_R g019(.A(\dest_x[16] ), .B(new_n97_), .Y(new_n110_));
  INVx1_ASAP7_75t_R   g020(.A(\dest_x[12] ), .Y(new_n111_));
  NOR2x1_ASAP7_75t_R  g021(.A(new_n92_), .B(new_n93_), .Y(new_n112_));
  AND3x1_ASAP7_75t_R  g022(.A(new_n93_), .B(new_n92_), .C(\dest_x[12] ), .Y(new_n113_));
  AO21x1_ASAP7_75t_R  g023(.A1(new_n111_), .A2(new_n112_), .B(new_n113_), .Y(new_n114_));
  INVx1_ASAP7_75t_R   g024(.A(\dest_x[21] ), .Y(new_n115_));
  AND2x2_ASAP7_75t_R  g025(.A(new_n115_), .B(\dest_x[20] ), .Y(new_n116_));
  INVx1_ASAP7_75t_R   g026(.A(\dest_x[22] ), .Y(new_n117_));
  AND2x2_ASAP7_75t_R  g027(.A(new_n117_), .B(\dest_x[23] ), .Y(new_n118_));
  NOR2x1_ASAP7_75t_R  g028(.A(\dest_x[1] ), .B(\dest_x[2] ), .Y(new_n119_));
  AND3x1_ASAP7_75t_R  g029(.A(new_n116_), .B(new_n118_), .C(new_n119_), .Y(new_n120_));
  INVx1_ASAP7_75t_R   g030(.A(\dest_x[10] ), .Y(new_n121_));
  NOR2x1_ASAP7_75t_R  g031(.A(\dest_x[7] ), .B(\dest_x[8] ), .Y(new_n122_));
  AND3x1_ASAP7_75t_R  g032(.A(new_n122_), .B(\dest_x[9] ), .C(new_n121_), .Y(new_n123_));
  NOR2x1_ASAP7_75t_R  g033(.A(\dest_x[3] ), .B(\dest_x[4] ), .Y(new_n124_));
  NOR2x1_ASAP7_75t_R  g034(.A(\dest_x[5] ), .B(\dest_x[6] ), .Y(new_n125_));
  AND3x1_ASAP7_75t_R  g035(.A(new_n123_), .B(new_n124_), .C(new_n125_), .Y(new_n126_));
  INVx1_ASAP7_75t_R   g036(.A(\dest_x[26] ), .Y(new_n127_));
  AND3x1_ASAP7_75t_R  g037(.A(new_n127_), .B(\dest_x[24] ), .C(\dest_x[25] ), .Y(new_n128_));
  NOR2x1_ASAP7_75t_R  g038(.A(\dest_x[13] ), .B(new_n91_), .Y(new_n129_));
  INVx1_ASAP7_75t_R   g039(.A(\dest_x[18] ), .Y(new_n130_));
  AND2x2_ASAP7_75t_R  g040(.A(new_n130_), .B(\dest_x[19] ), .Y(new_n131_));
  AND3x1_ASAP7_75t_R  g041(.A(new_n128_), .B(new_n129_), .C(new_n131_), .Y(new_n132_));
  AND3x1_ASAP7_75t_R  g042(.A(new_n126_), .B(new_n120_), .C(new_n132_), .Y(new_n133_));
  AND3x1_ASAP7_75t_R  g043(.A(new_n110_), .B(new_n114_), .C(new_n133_), .Y(new_n134_));
  OA21x2_ASAP7_75t_R  g044(.A1(new_n97_), .A2(new_n109_), .B(new_n134_), .Y(new_n135_));
  AO21x1_ASAP7_75t_R  g045(.A1(new_n100_), .A2(new_n135_), .B(new_n108_), .Y(new_n136_));
  AOI21x1_ASAP7_75t_R g046(.A1(\dest_x[23] ), .A2(new_n105_), .B(\dest_x[24] ), .Y(new_n137_));
  AND3x1_ASAP7_75t_R  g047(.A(new_n127_), .B(\dest_x[19] ), .C(\dest_x[25] ), .Y(new_n138_));
  INVx1_ASAP7_75t_R   g048(.A(\dest_x[16] ), .Y(new_n139_));
  AND3x1_ASAP7_75t_R  g049(.A(new_n94_), .B(\dest_x[15] ), .C(new_n139_), .Y(new_n140_));
  AND3x1_ASAP7_75t_R  g050(.A(new_n140_), .B(new_n101_), .C(new_n138_), .Y(new_n141_));
  AND3x1_ASAP7_75t_R  g051(.A(new_n93_), .B(\dest_x[0] ), .C(\dest_x[1] ), .Y(new_n142_));
  AND3x1_ASAP7_75t_R  g052(.A(new_n142_), .B(new_n116_), .C(new_n118_), .Y(new_n143_));
  AND2x2_ASAP7_75t_R  g053(.A(\dest_x[6] ), .B(\dest_x[7] ), .Y(new_n144_));
  AND3x1_ASAP7_75t_R  g054(.A(new_n144_), .B(\dest_x[8] ), .C(\dest_x[11] ), .Y(new_n145_));
  AND2x2_ASAP7_75t_R  g055(.A(\dest_x[2] ), .B(\dest_x[3] ), .Y(new_n146_));
  AND3x1_ASAP7_75t_R  g056(.A(new_n146_), .B(\dest_x[4] ), .C(\dest_x[5] ), .Y(new_n147_));
  AND3x1_ASAP7_75t_R  g057(.A(new_n143_), .B(new_n145_), .C(new_n147_), .Y(new_n148_));
  XOR2x2_ASAP7_75t_R  g058(.A(new_n95_), .B(new_n91_), .Y(new_n149_));
  AND3x1_ASAP7_75t_R  g059(.A(new_n148_), .B(new_n141_), .C(new_n149_), .Y(new_n150_));
  OAI21x1_ASAP7_75t_R g060(.A1(\dest_x[17] ), .A2(new_n99_), .B(new_n150_), .Y(new_n151_));
  OR3x1_ASAP7_75t_R   g061(.A(new_n106_), .B(new_n103_), .C(new_n151_), .Y(new_n152_));
  OA21x2_ASAP7_75t_R  g062(.A1(new_n137_), .A2(new_n152_), .B(new_n108_), .Y(new_n153_));
  INVx1_ASAP7_75t_R   g063(.A(new_n153_), .Y(new_n154_));
  NAND2x1_ASAP7_75t_R g064(.A(new_n136_), .B(new_n154_), .Y(\outport[0] ));
  AND3x1_ASAP7_75t_R  g065(.A(\dest_y[27] ), .B(\dest_y[28] ), .C(\dest_y[29] ), .Y(new_n156_));
  INVx1_ASAP7_75t_R   g066(.A(\dest_y[12] ), .Y(new_n157_));
  OAI21x1_ASAP7_75t_R g067(.A1(\dest_y[9] ), .A2(\dest_y[10] ), .B(\dest_y[11] ), .Y(new_n158_));
  AND2x2_ASAP7_75t_R  g068(.A(new_n158_), .B(new_n157_), .Y(new_n159_));
  INVx1_ASAP7_75t_R   g069(.A(new_n159_), .Y(new_n160_));
  OA21x2_ASAP7_75t_R  g070(.A1(new_n160_), .A2(\dest_y[13] ), .B(\dest_y[14] ), .Y(new_n161_));
  AO21x1_ASAP7_75t_R  g071(.A1(new_n161_), .A2(\dest_y[15] ), .B(\dest_y[16] ), .Y(new_n162_));
  AND2x2_ASAP7_75t_R  g072(.A(new_n162_), .B(\dest_y[17] ), .Y(new_n163_));
  NOR2x1_ASAP7_75t_R  g073(.A(\dest_y[18] ), .B(new_n163_), .Y(new_n164_));
  INVx1_ASAP7_75t_R   g074(.A(new_n164_), .Y(new_n165_));
  AND2x2_ASAP7_75t_R  g075(.A(\dest_y[19] ), .B(\dest_y[20] ), .Y(new_n166_));
  AND2x2_ASAP7_75t_R  g076(.A(new_n165_), .B(new_n166_), .Y(new_n167_));
  OR3x1_ASAP7_75t_R   g077(.A(new_n167_), .B(\dest_y[21] ), .C(\dest_y[22] ), .Y(new_n168_));
  AND3x1_ASAP7_75t_R  g078(.A(\dest_y[23] ), .B(\dest_y[24] ), .C(\dest_y[25] ), .Y(new_n169_));
  AO21x1_ASAP7_75t_R  g079(.A1(new_n168_), .A2(new_n169_), .B(\dest_y[26] ), .Y(new_n170_));
  NOR2x1_ASAP7_75t_R  g080(.A(\dest_x[0] ), .B(\dest_y[21] ), .Y(new_n171_));
  AO21x1_ASAP7_75t_R  g081(.A1(new_n170_), .A2(new_n156_), .B(new_n171_), .Y(new_n172_));
  INVx1_ASAP7_75t_R   g082(.A(\dest_y[22] ), .Y(new_n173_));
  OAI21x1_ASAP7_75t_R g083(.A1(new_n173_), .A2(\dest_y[23] ), .B(new_n167_), .Y(new_n174_));
  AND2x2_ASAP7_75t_R  g084(.A(new_n173_), .B(\dest_y[23] ), .Y(new_n175_));
  AO21x1_ASAP7_75t_R  g085(.A1(new_n165_), .A2(new_n166_), .B(new_n175_), .Y(new_n176_));
  INVx1_ASAP7_75t_R   g086(.A(\dest_y[19] ), .Y(new_n177_));
  AO21x1_ASAP7_75t_R  g087(.A1(new_n177_), .A2(new_n163_), .B(new_n164_), .Y(new_n178_));
  INVx1_ASAP7_75t_R   g088(.A(new_n161_), .Y(new_n179_));
  NOR2x1_ASAP7_75t_R  g089(.A(new_n157_), .B(new_n158_), .Y(new_n180_));
  AO21x1_ASAP7_75t_R  g090(.A1(new_n180_), .A2(\dest_y[13] ), .B(\dest_y[14] ), .Y(new_n181_));
  AND2x2_ASAP7_75t_R  g091(.A(\dest_y[24] ), .B(\dest_y[25] ), .Y(new_n182_));
  AND2x2_ASAP7_75t_R  g092(.A(\dest_y[0] ), .B(\dest_y[1] ), .Y(new_n183_));
  NOR2x1_ASAP7_75t_R  g093(.A(\dest_y[9] ), .B(\dest_y[10] ), .Y(new_n184_));
  OA21x2_ASAP7_75t_R  g094(.A1(\dest_y[18] ), .A2(\dest_y[19] ), .B(new_n184_), .Y(new_n185_));
  AND3x1_ASAP7_75t_R  g095(.A(new_n185_), .B(new_n182_), .C(new_n183_), .Y(new_n186_));
  AND2x2_ASAP7_75t_R  g096(.A(\dest_y[6] ), .B(\dest_y[7] ), .Y(new_n187_));
  AND3x1_ASAP7_75t_R  g097(.A(new_n187_), .B(\dest_y[8] ), .C(\dest_y[11] ), .Y(new_n188_));
  AND2x2_ASAP7_75t_R  g098(.A(\dest_y[2] ), .B(\dest_y[3] ), .Y(new_n189_));
  AND3x1_ASAP7_75t_R  g099(.A(new_n189_), .B(\dest_y[4] ), .C(\dest_y[5] ), .Y(new_n190_));
  AND2x2_ASAP7_75t_R  g100(.A(new_n188_), .B(new_n190_), .Y(new_n191_));
  INVx1_ASAP7_75t_R   g101(.A(\dest_y[16] ), .Y(new_n192_));
  AND2x2_ASAP7_75t_R  g102(.A(new_n192_), .B(\dest_y[17] ), .Y(new_n193_));
  INVx1_ASAP7_75t_R   g103(.A(\dest_y[26] ), .Y(new_n194_));
  AND2x2_ASAP7_75t_R  g104(.A(new_n194_), .B(\dest_y[20] ), .Y(new_n195_));
  AND3x1_ASAP7_75t_R  g105(.A(new_n193_), .B(new_n195_), .C(new_n156_), .Y(new_n196_));
  AND3x1_ASAP7_75t_R  g106(.A(new_n191_), .B(new_n186_), .C(new_n196_), .Y(new_n197_));
  AND3x1_ASAP7_75t_R  g107(.A(new_n197_), .B(new_n179_), .C(new_n181_), .Y(new_n198_));
  XOR2x2_ASAP7_75t_R  g108(.A(new_n161_), .B(\dest_y[15] ), .Y(new_n199_));
  AND3x1_ASAP7_75t_R  g109(.A(new_n178_), .B(new_n198_), .C(new_n199_), .Y(new_n200_));
  AND3x1_ASAP7_75t_R  g110(.A(new_n174_), .B(new_n176_), .C(new_n200_), .Y(new_n201_));
  INVx1_ASAP7_75t_R   g111(.A(new_n162_), .Y(new_n202_));
  AO21x1_ASAP7_75t_R  g112(.A1(\dest_y[18] ), .A2(new_n202_), .B(new_n163_), .Y(new_n203_));
  NOR2x1_ASAP7_75t_R  g113(.A(\dest_y[16] ), .B(\dest_y[21] ), .Y(new_n204_));
  AND3x1_ASAP7_75t_R  g114(.A(new_n204_), .B(new_n194_), .C(\dest_y[27] ), .Y(new_n205_));
  INVx1_ASAP7_75t_R   g115(.A(\dest_y[13] ), .Y(new_n206_));
  AND2x2_ASAP7_75t_R  g116(.A(\dest_y[14] ), .B(\dest_y[15] ), .Y(new_n207_));
  AND3x1_ASAP7_75t_R  g117(.A(new_n207_), .B(\dest_y[11] ), .C(new_n206_), .Y(new_n208_));
  INVx1_ASAP7_75t_R   g118(.A(\dest_y[10] ), .Y(new_n209_));
  NOR2x1_ASAP7_75t_R  g119(.A(\dest_y[7] ), .B(\dest_y[8] ), .Y(new_n210_));
  AND3x1_ASAP7_75t_R  g120(.A(new_n210_), .B(\dest_y[9] ), .C(new_n209_), .Y(new_n211_));
  AND3x1_ASAP7_75t_R  g121(.A(new_n205_), .B(new_n211_), .C(new_n208_), .Y(new_n212_));
  NAND2x1_ASAP7_75t_R g122(.A(\dest_y[17] ), .B(\dest_y[18] ), .Y(new_n213_));
  AND3x1_ASAP7_75t_R  g123(.A(new_n175_), .B(new_n166_), .C(new_n213_), .Y(new_n214_));
  INVx1_ASAP7_75t_R   g124(.A(\dest_y[5] ), .Y(new_n215_));
  INVx1_ASAP7_75t_R   g125(.A(\dest_y[6] ), .Y(new_n216_));
  NOR2x1_ASAP7_75t_R  g126(.A(\dest_y[3] ), .B(\dest_y[4] ), .Y(new_n217_));
  AND3x1_ASAP7_75t_R  g127(.A(new_n217_), .B(new_n215_), .C(new_n216_), .Y(new_n218_));
  INVx1_ASAP7_75t_R   g128(.A(\dest_y[1] ), .Y(new_n219_));
  INVx1_ASAP7_75t_R   g129(.A(\dest_y[2] ), .Y(new_n220_));
  AND3x1_ASAP7_75t_R  g130(.A(new_n182_), .B(new_n219_), .C(new_n220_), .Y(new_n221_));
  AND3x1_ASAP7_75t_R  g131(.A(new_n214_), .B(new_n218_), .C(new_n221_), .Y(new_n222_));
  NOR2x1_ASAP7_75t_R  g132(.A(new_n159_), .B(new_n180_), .Y(new_n223_));
  AND3x1_ASAP7_75t_R  g133(.A(new_n222_), .B(new_n212_), .C(new_n223_), .Y(new_n224_));
  NAND2x1_ASAP7_75t_R g134(.A(new_n224_), .B(new_n203_), .Y(new_n225_));
  OR3x1_ASAP7_75t_R   g135(.A(new_n225_), .B(\dest_x[0] ), .C(\dest_y[0] ), .Y(new_n226_));
  AND3x1_ASAP7_75t_R  g136(.A(new_n170_), .B(new_n156_), .C(new_n226_), .Y(new_n227_));
  AOI21x1_ASAP7_75t_R g137(.A1(new_n201_), .A2(new_n172_), .B(new_n227_), .Y(new_n228_));
  OA21x2_ASAP7_75t_R  g138(.A1(new_n153_), .A2(new_n228_), .B(new_n136_), .Y(\outport[1] ));
  AO21x1_ASAP7_75t_R  g139(.A1(\dest_x[0] ), .A2(\dest_y[0] ), .B(new_n225_), .Y(new_n230_));
  AND3x1_ASAP7_75t_R  g140(.A(new_n170_), .B(new_n156_), .C(new_n230_), .Y(new_n231_));
  AND3x1_ASAP7_75t_R  g141(.A(new_n154_), .B(new_n136_), .C(new_n231_), .Y(\outport[2] ));
  assign              \outport[3]  = 1'b0;
  assign              \outport[4]  = 1'b0;
  assign              \outport[5]  = 1'b0;
  assign              \outport[6]  = 1'b0;
  assign              \outport[7]  = 1'b0;
  assign              \outport[8]  = 1'b0;
  assign              \outport[9]  = 1'b0;
  assign              \outport[10]  = 1'b0;
  assign              \outport[11]  = 1'b0;
  assign              \outport[12]  = 1'b0;
  assign              \outport[13]  = 1'b0;
  assign              \outport[14]  = 1'b0;
  assign              \outport[15]  = 1'b0;
  assign              \outport[16]  = 1'b0;
  assign              \outport[17]  = 1'b0;
  assign              \outport[18]  = 1'b0;
  assign              \outport[19]  = 1'b0;
  assign              \outport[20]  = 1'b0;
  assign              \outport[21]  = 1'b0;
  assign              \outport[22]  = 1'b0;
  assign              \outport[23]  = 1'b0;
  assign              \outport[24]  = 1'b0;
  assign              \outport[25]  = 1'b0;
  assign              \outport[26]  = 1'b0;
  assign              \outport[27]  = 1'b0;
  assign              \outport[28]  = 1'b0;
  assign              \outport[29]  = 1'b0;
endmodule


