// Benchmark "/tmp/" written by ABC on Tue Oct 13 14:25:00 2026

module \/tmp/  ( 
    p4, p3, p7, p2, p1, p8, p5, p0, p10, p9, p6,
    o0, o1, o2, o3, o4, o5, o6  );
  input  p4, p3, p7, p2, p1, p8, p5, p0, p10, p9, p6;
  output o0, o1, o2, o3, o4, o5, o6;
  wire new_n19_, new_n20_, new_n21_, new_n22_, new_n23_, new_n24_, new_n25_,
    new_n26_, new_n27_, new_n28_, new_n29_, new_n30_, new_n31_, new_n32_,
    new_n33_, new_n34_, new_n35_, new_n36_, new_n37_, new_n38_, new_n39_,
    new_n40_, new_n41_, new_n42_, new_n43_, new_n44_, new_n45_, new_n46_,
    new_n47_, new_n48_, new_n49_, new_n50_, new_n51_, new_n52_, new_n53_,
    new_n54_, new_n55_, new_n56_, new_n57_, new_n58_, new_n59_, new_n60_,
    new_n61_, new_n62_, new_n63_, new_n64_, new_n65_, new_n66_, new_n67_,
    new_n68_, new_n70_, new_n71_, new_n72_, new_n73_, new_n74_, new_n75_,
    new_n76_, new_n77_, new_n78_, new_n79_, new_n80_, new_n81_, new_n82_,
    new_n83_, new_n84_, new_n85_, new_n86_, new_n87_, new_n88_, new_n89_,
    new_n90_, new_n91_, new_n92_, new_n93_, new_n94_, new_n95_, new_n96_,
    new_n97_, new_n98_, new_n99_, new_n100_, new_n101_, new_n102_,
    new_n103_, new_n104_, new_n105_, new_n106_, new_n107_, new_n108_,
    new_n109_, new_n110_, new_n112_, new_n113_, new_n114_, new_n115_,
    new_n116_, new_n117_, new_n118_, new_n119_, new_n120_, new_n121_,
    new_n122_, new_n123_, new_n124_, new_n125_, new_n126_, new_n127_,
    new_n128_, new_n129_, new_n130_, new_n131_, new_n132_, new_n133_,
    new_n134_, new_n135_, new_n136_, new_n137_, new_n138_, new_n139_,
    new_n140_, new_n141_, new_n142_, new_n143_, new_n144_, new_n145_,
    new_n146_, new_n148_, new_n149_, new_n150_, new_n151_, new_n152_,
    new_n154_, new_n155_, new_n156_, new_n157_, new_n158_, new_n159_,
    new_n160_, new_n161_, new_n162_, new_n163_, new_n164_, new_n165_,
    new_n166_, new_n168_, new_n169_, new_n170_, new_n171_, new_n172_,
    new_n173_, new_n174_;
  NOR2x1_ASAP7_75t_R  g000(.A(p7), .B(p6), .Y(new_n19_));
  INVx1_ASAP7_75t_R   g001(.A(p0), .Y(new_n20_));
  AND3x1_ASAP7_75t_R  g002(.A(new_n19_), .B(p1), .C(new_n20_), .Y(new_n21_));
  NOR2x1_ASAP7_75t_R  g003(.A(p8), .B(new_n21_), .Y(new_n22_));
  NAND2x1_ASAP7_75t_R g004(.A(p3), .B(p7), .Y(new_n23_));
  INVx1_ASAP7_75t_R   g005(.A(p1), .Y(new_n24_));
  AND3x1_ASAP7_75t_R  g006(.A(new_n23_), .B(new_n24_), .C(p0), .Y(new_n25_));
  NAND2x1_ASAP7_75t_R g007(.A(p3), .B(p2), .Y(new_n26_));
  INVx1_ASAP7_75t_R   g008(.A(p3), .Y(new_n27_));
  NAND2x1_ASAP7_75t_R g009(.A(p6), .B(new_n27_), .Y(new_n28_));
  NAND3x1_ASAP7_75t_R g010(.A(new_n25_), .B(new_n26_), .C(new_n28_), .Y(new_n29_));
  INVx1_ASAP7_75t_R   g011(.A(p5), .Y(new_n30_));
  NAND2x1_ASAP7_75t_R g012(.A(p4), .B(new_n30_), .Y(new_n31_));
  AOI21x1_ASAP7_75t_R g013(.A1(new_n22_), .A2(new_n29_), .B(new_n31_), .Y(new_n32_));
  INVx1_ASAP7_75t_R   g014(.A(p2), .Y(new_n33_));
  NAND2x1_ASAP7_75t_R g015(.A(p6), .B(new_n26_), .Y(new_n34_));
  AOI21x1_ASAP7_75t_R g016(.A1(new_n27_), .A2(new_n33_), .B(new_n34_), .Y(new_n35_));
  NAND2x1_ASAP7_75t_R g017(.A(p2), .B(p0), .Y(new_n36_));
  INVx1_ASAP7_75t_R   g018(.A(new_n36_), .Y(new_n37_));
  NOR2x1_ASAP7_75t_R  g019(.A(p1), .B(p6), .Y(new_n38_));
  AND3x1_ASAP7_75t_R  g020(.A(new_n37_), .B(p4), .C(new_n38_), .Y(new_n39_));
  NOR2x1_ASAP7_75t_R  g021(.A(p7), .B(p8), .Y(new_n40_));
  OA21x2_ASAP7_75t_R  g022(.A1(new_n35_), .A2(new_n39_), .B(new_n40_), .Y(new_n41_));
  INVx1_ASAP7_75t_R   g023(.A(p8), .Y(new_n42_));
  OR3x1_ASAP7_75t_R   g024(.A(new_n42_), .B(new_n30_), .C(p4), .Y(new_n43_));
  NAND2x1_ASAP7_75t_R g025(.A(p7), .B(new_n42_), .Y(new_n44_));
  INVx1_ASAP7_75t_R   g026(.A(p4), .Y(new_n45_));
  OR3x1_ASAP7_75t_R   g027(.A(new_n44_), .B(new_n45_), .C(p3), .Y(new_n46_));
  NAND2x1_ASAP7_75t_R g028(.A(new_n43_), .B(new_n46_), .Y(new_n47_));
  NOR3x1_ASAP7_75t_R  g029(.A(new_n32_), .B(new_n41_), .C(new_n47_), .Y(new_n48_));
  AND2x2_ASAP7_75t_R  g030(.A(p3), .B(p0), .Y(new_n49_));
  INVx1_ASAP7_75t_R   g031(.A(p7), .Y(new_n50_));
  NOR2x1_ASAP7_75t_R  g032(.A(p3), .B(new_n50_), .Y(new_n51_));
  OA21x2_ASAP7_75t_R  g033(.A1(new_n49_), .A2(new_n51_), .B(p10), .Y(new_n52_));
  NOR2x1_ASAP7_75t_R  g034(.A(p10), .B(new_n49_), .Y(new_n53_));
  OR3x1_ASAP7_75t_R   g035(.A(new_n53_), .B(p5), .C(p6), .Y(new_n54_));
  OAI21x1_ASAP7_75t_R g036(.A1(new_n52_), .A2(new_n54_), .B(new_n23_), .Y(new_n55_));
  INVx1_ASAP7_75t_R   g037(.A(p9), .Y(new_n56_));
  AND3x1_ASAP7_75t_R  g038(.A(new_n45_), .B(new_n42_), .C(new_n56_), .Y(new_n57_));
  NOR2x1_ASAP7_75t_R  g039(.A(p6), .B(new_n30_), .Y(new_n58_));
  NAND2x1_ASAP7_75t_R g040(.A(p6), .B(new_n30_), .Y(new_n59_));
  OR3x1_ASAP7_75t_R   g041(.A(new_n50_), .B(new_n42_), .C(new_n30_), .Y(new_n60_));
  AOI21x1_ASAP7_75t_R g042(.A1(new_n59_), .A2(new_n60_), .B(new_n56_), .Y(new_n61_));
  NOR2x1_ASAP7_75t_R  g043(.A(p2), .B(p1), .Y(new_n62_));
  INVx1_ASAP7_75t_R   g044(.A(new_n62_), .Y(new_n63_));
  NAND2x1_ASAP7_75t_R g045(.A(p2), .B(p1), .Y(new_n64_));
  AND3x1_ASAP7_75t_R  g046(.A(new_n64_), .B(new_n50_), .C(new_n42_), .Y(new_n65_));
  AO21x1_ASAP7_75t_R  g047(.A1(new_n63_), .A2(new_n65_), .B(p9), .Y(new_n66_));
  OA21x2_ASAP7_75t_R  g048(.A1(new_n58_), .A2(new_n61_), .B(new_n66_), .Y(new_n67_));
  AOI21x1_ASAP7_75t_R g049(.A1(new_n55_), .A2(new_n57_), .B(new_n67_), .Y(new_n68_));
  OAI21x1_ASAP7_75t_R g050(.A1(p9), .A2(new_n48_), .B(new_n68_), .Y(o0));
  NAND2x1_ASAP7_75t_R g051(.A(p4), .B(p5), .Y(new_n70_));
  INVx1_ASAP7_75t_R   g052(.A(p6), .Y(new_n71_));
  NOR2x1_ASAP7_75t_R  g053(.A(p3), .B(p8), .Y(new_n72_));
  AOI21x1_ASAP7_75t_R g054(.A1(p8), .A2(new_n71_), .B(new_n72_), .Y(new_n73_));
  NAND2x1_ASAP7_75t_R g055(.A(new_n70_), .B(new_n73_), .Y(new_n74_));
  INVx1_ASAP7_75t_R   g056(.A(new_n40_), .Y(new_n75_));
  OA21x2_ASAP7_75t_R  g057(.A1(new_n30_), .A2(new_n73_), .B(new_n75_), .Y(new_n76_));
  OR3x1_ASAP7_75t_R   g058(.A(p3), .B(p5), .C(p6), .Y(new_n77_));
  NAND2x1_ASAP7_75t_R g059(.A(p3), .B(new_n40_), .Y(new_n78_));
  NAND2x1_ASAP7_75t_R g060(.A(p1), .B(p0), .Y(new_n79_));
  NAND2x1_ASAP7_75t_R g061(.A(p4), .B(p2), .Y(new_n80_));
  AO21x1_ASAP7_75t_R  g062(.A1(new_n71_), .A2(new_n79_), .B(new_n80_), .Y(new_n81_));
  AOI21x1_ASAP7_75t_R g063(.A1(new_n77_), .A2(new_n78_), .B(new_n81_), .Y(new_n82_));
  AOI21x1_ASAP7_75t_R g064(.A1(new_n74_), .A2(new_n76_), .B(new_n82_), .Y(new_n83_));
  OAI21x1_ASAP7_75t_R g065(.A1(new_n38_), .A2(new_n72_), .B(new_n20_), .Y(new_n84_));
  NAND2x1_ASAP7_75t_R g066(.A(new_n44_), .B(new_n84_), .Y(new_n85_));
  AND2x2_ASAP7_75t_R  g067(.A(p10), .B(new_n79_), .Y(new_n86_));
  INVx1_ASAP7_75t_R   g068(.A(p10), .Y(new_n87_));
  AO21x1_ASAP7_75t_R  g069(.A1(p1), .A2(new_n87_), .B(p6), .Y(new_n88_));
  NOR3x1_ASAP7_75t_R  g070(.A(new_n86_), .B(new_n27_), .C(new_n88_), .Y(new_n89_));
  NOR2x1_ASAP7_75t_R  g071(.A(p4), .B(p5), .Y(new_n90_));
  OAI21x1_ASAP7_75t_R g072(.A1(new_n85_), .A2(new_n89_), .B(new_n90_), .Y(new_n91_));
  NAND2x1_ASAP7_75t_R g073(.A(p8), .B(new_n71_), .Y(new_n92_));
  AND2x2_ASAP7_75t_R  g074(.A(p3), .B(p2), .Y(new_n93_));
  OR3x1_ASAP7_75t_R   g075(.A(new_n75_), .B(new_n71_), .C(new_n93_), .Y(new_n94_));
  AO21x1_ASAP7_75t_R  g076(.A1(new_n92_), .A2(new_n94_), .B(p4), .Y(new_n95_));
  NAND3x1_ASAP7_75t_R g077(.A(new_n83_), .B(new_n91_), .C(new_n95_), .Y(new_n96_));
  AO21x1_ASAP7_75t_R  g078(.A1(p5), .A2(p6), .B(p7), .Y(new_n97_));
  AO21x1_ASAP7_75t_R  g079(.A1(new_n56_), .A2(p6), .B(new_n97_), .Y(new_n98_));
  INVx1_ASAP7_75t_R   g080(.A(new_n79_), .Y(new_n99_));
  NOR2x1_ASAP7_75t_R  g081(.A(p2), .B(p5), .Y(new_n100_));
  NAND2x1_ASAP7_75t_R g082(.A(p4), .B(new_n100_), .Y(new_n101_));
  AND2x2_ASAP7_75t_R  g083(.A(p1), .B(p5), .Y(new_n102_));
  NAND3x1_ASAP7_75t_R g084(.A(new_n93_), .B(new_n102_), .C(new_n42_), .Y(new_n103_));
  OAI21x1_ASAP7_75t_R g085(.A1(new_n99_), .A2(new_n101_), .B(new_n103_), .Y(new_n104_));
  AND3x1_ASAP7_75t_R  g086(.A(new_n72_), .B(new_n64_), .C(p5), .Y(new_n105_));
  NOR3x1_ASAP7_75t_R  g087(.A(new_n104_), .B(p9), .C(new_n105_), .Y(new_n106_));
  AND2x2_ASAP7_75t_R  g088(.A(p5), .B(p6), .Y(new_n107_));
  AND3x1_ASAP7_75t_R  g089(.A(new_n107_), .B(p7), .C(p9), .Y(new_n108_));
  NAND2x1_ASAP7_75t_R g090(.A(new_n42_), .B(new_n108_), .Y(new_n109_));
  OAI21x1_ASAP7_75t_R g091(.A1(new_n98_), .A2(new_n106_), .B(new_n109_), .Y(new_n110_));
  AOI21x1_ASAP7_75t_R g092(.A1(new_n56_), .A2(new_n96_), .B(new_n110_), .Y(o1));
  OR3x1_ASAP7_75t_R   g093(.A(p7), .B(p8), .C(p9), .Y(new_n112_));
  NOR2x1_ASAP7_75t_R  g094(.A(p1), .B(p5), .Y(new_n113_));
  NAND2x1_ASAP7_75t_R g095(.A(new_n113_), .B(new_n93_), .Y(new_n114_));
  OR3x1_ASAP7_75t_R   g096(.A(new_n45_), .B(new_n27_), .C(p2), .Y(new_n115_));
  AND3x1_ASAP7_75t_R  g097(.A(new_n114_), .B(new_n115_), .C(new_n24_), .Y(new_n116_));
  NOR2x1_ASAP7_75t_R  g098(.A(p6), .B(new_n116_), .Y(new_n117_));
  AND2x2_ASAP7_75t_R  g099(.A(p0), .B(p10), .Y(new_n118_));
  NOR3x1_ASAP7_75t_R  g100(.A(new_n118_), .B(p4), .C(new_n26_), .Y(new_n119_));
  NOR3x1_ASAP7_75t_R  g101(.A(new_n36_), .B(new_n45_), .C(p3), .Y(new_n120_));
  AND3x1_ASAP7_75t_R  g102(.A(new_n45_), .B(new_n27_), .C(new_n30_), .Y(new_n121_));
  NOR3x1_ASAP7_75t_R  g103(.A(new_n119_), .B(new_n120_), .C(new_n121_), .Y(new_n122_));
  NAND3x1_ASAP7_75t_R g104(.A(new_n49_), .B(p10), .C(new_n100_), .Y(new_n123_));
  AND3x1_ASAP7_75t_R  g105(.A(new_n123_), .B(new_n115_), .C(new_n114_), .Y(new_n124_));
  NAND2x1_ASAP7_75t_R g106(.A(new_n122_), .B(new_n124_), .Y(new_n125_));
  AND3x1_ASAP7_75t_R  g107(.A(new_n70_), .B(p3), .C(p2), .Y(new_n126_));
  AO21x1_ASAP7_75t_R  g108(.A1(p4), .A2(new_n20_), .B(new_n102_), .Y(new_n127_));
  AND3x1_ASAP7_75t_R  g109(.A(new_n26_), .B(p4), .C(p5), .Y(new_n128_));
  AO21x1_ASAP7_75t_R  g110(.A1(new_n126_), .A2(new_n127_), .B(new_n128_), .Y(new_n129_));
  AOI21x1_ASAP7_75t_R g111(.A1(new_n117_), .A2(new_n125_), .B(new_n129_), .Y(new_n130_));
  NOR2x1_ASAP7_75t_R  g112(.A(p8), .B(p9), .Y(new_n131_));
  NAND2x1_ASAP7_75t_R g113(.A(p4), .B(p3), .Y(new_n132_));
  AND3x1_ASAP7_75t_R  g114(.A(new_n30_), .B(p2), .C(p6), .Y(new_n133_));
  AO21x1_ASAP7_75t_R  g115(.A1(p5), .A2(new_n38_), .B(new_n133_), .Y(new_n134_));
  AO21x1_ASAP7_75t_R  g116(.A1(p4), .A2(p3), .B(new_n107_), .Y(new_n135_));
  OA21x2_ASAP7_75t_R  g117(.A1(new_n132_), .A2(new_n134_), .B(new_n135_), .Y(new_n136_));
  OR3x1_ASAP7_75t_R   g118(.A(new_n70_), .B(new_n27_), .C(p6), .Y(new_n137_));
  NAND2x1_ASAP7_75t_R g119(.A(p7), .B(new_n56_), .Y(new_n138_));
  AO21x1_ASAP7_75t_R  g120(.A1(new_n59_), .A2(new_n137_), .B(new_n138_), .Y(new_n139_));
  AND3x1_ASAP7_75t_R  g121(.A(new_n50_), .B(p4), .C(p8), .Y(new_n140_));
  AOI21x1_ASAP7_75t_R g122(.A1(new_n107_), .A2(new_n140_), .B(new_n108_), .Y(new_n141_));
  AND3x1_ASAP7_75t_R  g123(.A(new_n56_), .B(p4), .C(p6), .Y(new_n142_));
  NOR2x1_ASAP7_75t_R  g124(.A(p7), .B(p9), .Y(new_n143_));
  OR3x1_ASAP7_75t_R   g125(.A(new_n142_), .B(new_n42_), .C(new_n143_), .Y(new_n144_));
  NAND3x1_ASAP7_75t_R g126(.A(new_n139_), .B(new_n141_), .C(new_n144_), .Y(new_n145_));
  AOI21x1_ASAP7_75t_R g127(.A1(new_n131_), .A2(new_n136_), .B(new_n145_), .Y(new_n146_));
  OAI21x1_ASAP7_75t_R g128(.A1(new_n112_), .A2(new_n130_), .B(new_n146_), .Y(o2));
  AND3x1_ASAP7_75t_R  g129(.A(p4), .B(p5), .C(p6), .Y(new_n148_));
  NOR2x1_ASAP7_75t_R  g130(.A(p1), .B(new_n23_), .Y(new_n149_));
  AND3x1_ASAP7_75t_R  g131(.A(new_n19_), .B(new_n90_), .C(new_n27_), .Y(new_n150_));
  AOI21x1_ASAP7_75t_R g132(.A1(new_n148_), .A2(new_n149_), .B(new_n150_), .Y(new_n151_));
  INVx1_ASAP7_75t_R   g133(.A(new_n131_), .Y(new_n152_));
  OR3x1_ASAP7_75t_R   g134(.A(new_n151_), .B(p2), .C(new_n152_), .Y(o3));
  NAND2x1_ASAP7_75t_R g135(.A(new_n90_), .B(new_n118_), .Y(new_n154_));
  AO21x1_ASAP7_75t_R  g136(.A1(new_n154_), .A2(new_n137_), .B(new_n64_), .Y(new_n155_));
  OAI21x1_ASAP7_75t_R g137(.A1(p6), .A2(new_n79_), .B(new_n70_), .Y(new_n156_));
  NOR2x1_ASAP7_75t_R  g138(.A(p4), .B(p6), .Y(new_n157_));
  AO21x1_ASAP7_75t_R  g139(.A1(p3), .A2(new_n157_), .B(new_n58_), .Y(new_n158_));
  AO21x1_ASAP7_75t_R  g140(.A1(new_n93_), .A2(new_n156_), .B(new_n158_), .Y(new_n159_));
  NAND2x1_ASAP7_75t_R g141(.A(new_n155_), .B(new_n159_), .Y(new_n160_));
  AO21x1_ASAP7_75t_R  g142(.A1(new_n50_), .A2(p2), .B(new_n62_), .Y(new_n161_));
  INVx1_ASAP7_75t_R   g143(.A(new_n107_), .Y(new_n162_));
  OR3x1_ASAP7_75t_R   g144(.A(new_n162_), .B(new_n132_), .C(p8), .Y(new_n163_));
  AO21x1_ASAP7_75t_R  g145(.A1(p7), .A2(new_n148_), .B(new_n42_), .Y(new_n164_));
  OA21x2_ASAP7_75t_R  g146(.A1(new_n161_), .A2(new_n163_), .B(new_n164_), .Y(new_n165_));
  NOR2x1_ASAP7_75t_R  g147(.A(p9), .B(new_n165_), .Y(new_n166_));
  AOI21x1_ASAP7_75t_R g148(.A1(new_n143_), .A2(new_n160_), .B(new_n166_), .Y(o4));
  AND3x1_ASAP7_75t_R  g149(.A(new_n63_), .B(p7), .C(new_n148_), .Y(new_n168_));
  AND3x1_ASAP7_75t_R  g150(.A(new_n50_), .B(p1), .C(p10), .Y(new_n169_));
  AND3x1_ASAP7_75t_R  g151(.A(new_n169_), .B(new_n37_), .C(new_n157_), .Y(new_n170_));
  OA21x2_ASAP7_75t_R  g152(.A1(new_n168_), .A2(new_n170_), .B(p3), .Y(new_n171_));
  OR3x1_ASAP7_75t_R   g153(.A(new_n64_), .B(new_n70_), .C(new_n27_), .Y(new_n172_));
  INVx1_ASAP7_75t_R   g154(.A(new_n90_), .Y(new_n173_));
  AND3x1_ASAP7_75t_R  g155(.A(new_n172_), .B(new_n19_), .C(new_n173_), .Y(new_n174_));
  OR3x1_ASAP7_75t_R   g156(.A(new_n171_), .B(new_n152_), .C(new_n174_), .Y(o5));
  NAND3x1_ASAP7_75t_R g157(.A(new_n172_), .B(new_n19_), .C(new_n131_), .Y(o6));
endmodule


