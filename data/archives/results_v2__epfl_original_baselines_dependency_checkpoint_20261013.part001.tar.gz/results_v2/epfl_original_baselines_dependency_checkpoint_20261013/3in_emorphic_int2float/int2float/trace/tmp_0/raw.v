// Benchmark "/tmp/" written by ABC on Tue Oct 13 14:24:55 2026

module \/tmp/  ( 
    p5, p4, p9, p6, p7, p10, p3, p8, p2, p0, p1,
    o0, o1, o2, o3, o4, o5, o6  );
  input  p5, p4, p9, p6, p7, p10, p3, p8, p2, p0, p1;
  output o0, o1, o2, o3, o4, o5, o6;
  wire new_n19_, new_n20_, new_n21_, new_n22_, new_n23_, new_n24_, new_n25_,
    new_n26_, new_n27_, new_n28_, new_n29_, new_n30_, new_n31_, new_n32_,
    new_n33_, new_n34_, new_n35_, new_n36_, new_n37_, new_n38_, new_n39_,
    new_n40_, new_n41_, new_n42_, new_n43_, new_n44_, new_n45_, new_n46_,
    new_n47_, new_n48_, new_n49_, new_n50_, new_n51_, new_n52_, new_n53_,
    new_n54_, new_n55_, new_n56_, new_n57_, new_n58_, new_n59_, new_n60_,
    new_n61_, new_n62_, new_n63_, new_n64_, new_n65_, new_n66_, new_n67_,
    new_n68_, new_n69_, new_n71_, new_n72_, new_n73_, new_n74_, new_n75_,
    new_n76_, new_n77_, new_n78_, new_n79_, new_n80_, new_n81_, new_n82_,
    new_n83_, new_n84_, new_n85_, new_n86_, new_n87_, new_n88_, new_n89_,
    new_n90_, new_n91_, new_n92_, new_n93_, new_n94_, new_n95_, new_n96_,
    new_n97_, new_n98_, new_n99_, new_n100_, new_n101_, new_n102_,
    new_n103_, new_n104_, new_n105_, new_n106_, new_n107_, new_n108_,
    new_n109_, new_n110_, new_n111_, new_n113_, new_n114_, new_n115_,
    new_n116_, new_n117_, new_n118_, new_n119_, new_n120_, new_n121_,
    new_n122_, new_n123_, new_n124_, new_n125_, new_n126_, new_n127_,
    new_n128_, new_n129_, new_n130_, new_n131_, new_n132_, new_n133_,
    new_n134_, new_n135_, new_n136_, new_n137_, new_n138_, new_n139_,
    new_n140_, new_n141_, new_n142_, new_n143_, new_n144_, new_n145_,
    new_n146_, new_n148_, new_n149_, new_n150_, new_n151_, new_n152_,
    new_n153_, new_n155_, new_n156_, new_n157_, new_n158_, new_n159_,
    new_n160_, new_n161_, new_n162_, new_n163_, new_n164_, new_n165_,
    new_n167_, new_n168_, new_n169_, new_n170_, new_n171_, new_n172_,
    new_n174_;
  INVx1_ASAP7_75t_R   g000(.A(p9), .Y(new_n19_));
  INVx1_ASAP7_75t_R   g001(.A(p8), .Y(new_n20_));
  NAND2x1_ASAP7_75t_R g002(.A(new_n19_), .B(new_n20_), .Y(new_n21_));
  AO21x1_ASAP7_75t_R  g003(.A1(p3), .A2(p0), .B(p10), .Y(new_n22_));
  INVx1_ASAP7_75t_R   g004(.A(p5), .Y(new_n23_));
  INVx1_ASAP7_75t_R   g005(.A(p6), .Y(new_n24_));
  AND3x1_ASAP7_75t_R  g006(.A(new_n22_), .B(new_n23_), .C(new_n24_), .Y(new_n25_));
  NAND2x1_ASAP7_75t_R g007(.A(p3), .B(p0), .Y(new_n26_));
  INVx1_ASAP7_75t_R   g008(.A(p3), .Y(new_n27_));
  NAND2x1_ASAP7_75t_R g009(.A(p7), .B(new_n27_), .Y(new_n28_));
  INVx1_ASAP7_75t_R   g010(.A(p10), .Y(new_n29_));
  AO21x1_ASAP7_75t_R  g011(.A1(new_n26_), .A2(new_n28_), .B(new_n29_), .Y(new_n30_));
  AO21x1_ASAP7_75t_R  g012(.A1(p7), .A2(p3), .B(p4), .Y(new_n31_));
  AO21x1_ASAP7_75t_R  g013(.A1(new_n25_), .A2(new_n30_), .B(new_n31_), .Y(new_n32_));
  INVx1_ASAP7_75t_R   g014(.A(p4), .Y(new_n33_));
  AO21x1_ASAP7_75t_R  g015(.A1(p7), .A2(new_n27_), .B(new_n33_), .Y(new_n34_));
  AND2x2_ASAP7_75t_R  g016(.A(p2), .B(p0), .Y(new_n35_));
  NOR2x1_ASAP7_75t_R  g017(.A(p6), .B(p1), .Y(new_n36_));
  AND3x1_ASAP7_75t_R  g018(.A(new_n35_), .B(p4), .C(new_n36_), .Y(new_n37_));
  AOI21x1_ASAP7_75t_R g019(.A1(p3), .A2(p2), .B(new_n24_), .Y(new_n38_));
  OA21x2_ASAP7_75t_R  g020(.A1(p3), .A2(p2), .B(new_n38_), .Y(new_n39_));
  INVx1_ASAP7_75t_R   g021(.A(p7), .Y(new_n40_));
  OA21x2_ASAP7_75t_R  g022(.A1(new_n37_), .A2(new_n39_), .B(new_n40_), .Y(new_n41_));
  AOI21x1_ASAP7_75t_R g023(.A1(new_n32_), .A2(new_n34_), .B(new_n41_), .Y(new_n42_));
  AND2x2_ASAP7_75t_R  g024(.A(p5), .B(p4), .Y(new_n43_));
  INVx1_ASAP7_75t_R   g025(.A(new_n43_), .Y(new_n44_));
  NOR2x1_ASAP7_75t_R  g026(.A(p5), .B(p4), .Y(new_n45_));
  INVx1_ASAP7_75t_R   g027(.A(new_n45_), .Y(new_n46_));
  AND3x1_ASAP7_75t_R  g028(.A(new_n44_), .B(new_n19_), .C(new_n46_), .Y(new_n47_));
  AO21x1_ASAP7_75t_R  g029(.A1(p7), .A2(p3), .B(p5), .Y(new_n48_));
  AND2x2_ASAP7_75t_R  g030(.A(p3), .B(p2), .Y(new_n49_));
  AO21x1_ASAP7_75t_R  g031(.A1(p6), .A2(new_n27_), .B(new_n49_), .Y(new_n50_));
  INVx1_ASAP7_75t_R   g032(.A(p0), .Y(new_n51_));
  OR3x1_ASAP7_75t_R   g033(.A(new_n50_), .B(new_n51_), .C(p1), .Y(new_n52_));
  NOR2x1_ASAP7_75t_R  g034(.A(p6), .B(p7), .Y(new_n53_));
  INVx1_ASAP7_75t_R   g035(.A(new_n53_), .Y(new_n54_));
  INVx1_ASAP7_75t_R   g036(.A(p1), .Y(new_n55_));
  OR3x1_ASAP7_75t_R   g037(.A(new_n55_), .B(p5), .C(p0), .Y(new_n56_));
  OA21x2_ASAP7_75t_R  g038(.A1(new_n54_), .A2(new_n56_), .B(new_n20_), .Y(new_n57_));
  OAI21x1_ASAP7_75t_R g039(.A1(new_n48_), .A2(new_n52_), .B(new_n57_), .Y(new_n58_));
  NOR2x1_ASAP7_75t_R  g040(.A(p2), .B(p1), .Y(new_n59_));
  INVx1_ASAP7_75t_R   g041(.A(new_n59_), .Y(new_n60_));
  NOR2x1_ASAP7_75t_R  g042(.A(p7), .B(p8), .Y(new_n61_));
  NAND2x1_ASAP7_75t_R g043(.A(p2), .B(p1), .Y(new_n62_));
  AND3x1_ASAP7_75t_R  g044(.A(new_n60_), .B(new_n61_), .C(new_n62_), .Y(new_n63_));
  AND3x1_ASAP7_75t_R  g045(.A(p5), .B(p7), .C(p8), .Y(new_n64_));
  NOR2x1_ASAP7_75t_R  g046(.A(p5), .B(new_n24_), .Y(new_n65_));
  OAI21x1_ASAP7_75t_R g047(.A1(new_n64_), .A2(new_n65_), .B(p9), .Y(new_n66_));
  OAI21x1_ASAP7_75t_R g048(.A1(new_n23_), .A2(p6), .B(new_n66_), .Y(new_n67_));
  OA21x2_ASAP7_75t_R  g049(.A1(p9), .A2(new_n63_), .B(new_n67_), .Y(new_n68_));
  AOI21x1_ASAP7_75t_R g050(.A1(new_n47_), .A2(new_n58_), .B(new_n68_), .Y(new_n69_));
  OAI21x1_ASAP7_75t_R g051(.A1(new_n21_), .A2(new_n42_), .B(new_n69_), .Y(o0));
  AO21x1_ASAP7_75t_R  g052(.A1(p5), .A2(p6), .B(p7), .Y(new_n71_));
  AO21x1_ASAP7_75t_R  g053(.A1(new_n19_), .A2(p6), .B(new_n71_), .Y(new_n72_));
  NAND2x1_ASAP7_75t_R g054(.A(p3), .B(p2), .Y(new_n73_));
  NAND2x1_ASAP7_75t_R g055(.A(p5), .B(p1), .Y(new_n74_));
  OR3x1_ASAP7_75t_R   g056(.A(new_n73_), .B(new_n74_), .C(p8), .Y(new_n75_));
  NOR3x1_ASAP7_75t_R  g057(.A(new_n23_), .B(p3), .C(p8), .Y(new_n76_));
  NOR3x1_ASAP7_75t_R  g058(.A(new_n33_), .B(p5), .C(p0), .Y(new_n77_));
  INVx1_ASAP7_75t_R   g059(.A(p2), .Y(new_n78_));
  OAI21x1_ASAP7_75t_R g060(.A1(new_n76_), .A2(new_n77_), .B(new_n78_), .Y(new_n79_));
  NAND2x1_ASAP7_75t_R g061(.A(new_n75_), .B(new_n79_), .Y(new_n80_));
  AND3x1_ASAP7_75t_R  g062(.A(new_n23_), .B(new_n78_), .C(p4), .Y(new_n81_));
  OA21x2_ASAP7_75t_R  g063(.A1(new_n76_), .A2(new_n81_), .B(new_n55_), .Y(new_n82_));
  NOR3x1_ASAP7_75t_R  g064(.A(new_n80_), .B(p9), .C(new_n82_), .Y(new_n83_));
  NAND2x1_ASAP7_75t_R g065(.A(p7), .B(new_n20_), .Y(new_n84_));
  NAND2x1_ASAP7_75t_R g066(.A(p5), .B(p6), .Y(new_n85_));
  OR3x1_ASAP7_75t_R   g067(.A(new_n84_), .B(new_n19_), .C(new_n85_), .Y(new_n86_));
  OAI21x1_ASAP7_75t_R g068(.A1(new_n72_), .A2(new_n83_), .B(new_n86_), .Y(new_n87_));
  NAND2x1_ASAP7_75t_R g069(.A(p3), .B(new_n61_), .Y(new_n88_));
  NOR2x1_ASAP7_75t_R  g070(.A(p5), .B(p3), .Y(new_n89_));
  NAND2x1_ASAP7_75t_R g071(.A(p0), .B(p1), .Y(new_n90_));
  NOR2x1_ASAP7_75t_R  g072(.A(p6), .B(new_n90_), .Y(new_n91_));
  NAND2x1_ASAP7_75t_R g073(.A(new_n89_), .B(new_n91_), .Y(new_n92_));
  AO21x1_ASAP7_75t_R  g074(.A1(new_n24_), .A2(new_n90_), .B(new_n78_), .Y(new_n93_));
  AOI21x1_ASAP7_75t_R g075(.A1(new_n88_), .A2(new_n92_), .B(new_n93_), .Y(new_n94_));
  NOR2x1_ASAP7_75t_R  g076(.A(p6), .B(new_n20_), .Y(new_n95_));
  NOR2x1_ASAP7_75t_R  g077(.A(p3), .B(p8), .Y(new_n96_));
  OR3x1_ASAP7_75t_R   g078(.A(new_n95_), .B(new_n23_), .C(new_n96_), .Y(new_n97_));
  NOR2x1_ASAP7_75t_R  g079(.A(new_n61_), .B(new_n97_), .Y(new_n98_));
  OAI21x1_ASAP7_75t_R g080(.A1(new_n94_), .A2(new_n98_), .B(p4), .Y(new_n99_));
  OAI21x1_ASAP7_75t_R g081(.A1(new_n51_), .A2(new_n55_), .B(p10), .Y(new_n100_));
  NAND2x1_ASAP7_75t_R g082(.A(p1), .B(new_n29_), .Y(new_n101_));
  NOR2x1_ASAP7_75t_R  g083(.A(p6), .B(new_n27_), .Y(new_n102_));
  NAND3x1_ASAP7_75t_R g084(.A(new_n100_), .B(new_n101_), .C(new_n102_), .Y(new_n103_));
  OAI21x1_ASAP7_75t_R g085(.A1(new_n36_), .A2(new_n96_), .B(new_n51_), .Y(new_n104_));
  NAND3x1_ASAP7_75t_R g086(.A(new_n103_), .B(new_n104_), .C(new_n84_), .Y(new_n105_));
  AOI21x1_ASAP7_75t_R g087(.A1(new_n61_), .A2(new_n38_), .B(new_n95_), .Y(new_n106_));
  NOR2x1_ASAP7_75t_R  g088(.A(p5), .B(new_n61_), .Y(new_n107_));
  OAI21x1_ASAP7_75t_R g089(.A1(new_n96_), .A2(new_n95_), .B(new_n107_), .Y(new_n108_));
  OAI21x1_ASAP7_75t_R g090(.A1(p4), .A2(new_n106_), .B(new_n108_), .Y(new_n109_));
  AOI21x1_ASAP7_75t_R g091(.A1(new_n45_), .A2(new_n105_), .B(new_n109_), .Y(new_n110_));
  AOI21x1_ASAP7_75t_R g092(.A1(new_n99_), .A2(new_n110_), .B(p9), .Y(new_n111_));
  NOR2x1_ASAP7_75t_R  g093(.A(new_n87_), .B(new_n111_), .Y(o1));
  OR3x1_ASAP7_75t_R   g094(.A(p9), .B(p7), .C(p8), .Y(new_n113_));
  NAND2x1_ASAP7_75t_R g095(.A(p4), .B(new_n78_), .Y(new_n114_));
  OR3x1_ASAP7_75t_R   g096(.A(new_n78_), .B(p5), .C(p1), .Y(new_n115_));
  AO21x1_ASAP7_75t_R  g097(.A1(new_n114_), .A2(new_n115_), .B(new_n27_), .Y(new_n116_));
  AOI21x1_ASAP7_75t_R g098(.A1(new_n55_), .A2(new_n116_), .B(p6), .Y(new_n117_));
  AND3x1_ASAP7_75t_R  g099(.A(new_n27_), .B(p4), .C(p2), .Y(new_n118_));
  NAND2x1_ASAP7_75t_R g100(.A(p3), .B(new_n78_), .Y(new_n119_));
  NAND2x1_ASAP7_75t_R g101(.A(p10), .B(new_n23_), .Y(new_n120_));
  NOR2x1_ASAP7_75t_R  g102(.A(new_n119_), .B(new_n120_), .Y(new_n121_));
  OAI21x1_ASAP7_75t_R g103(.A1(new_n118_), .A2(new_n121_), .B(p0), .Y(new_n122_));
  AND2x2_ASAP7_75t_R  g104(.A(p10), .B(p0), .Y(new_n123_));
  NOR2x1_ASAP7_75t_R  g105(.A(new_n73_), .B(new_n123_), .Y(new_n124_));
  OAI21x1_ASAP7_75t_R g106(.A1(new_n89_), .A2(new_n124_), .B(new_n33_), .Y(new_n125_));
  NAND3x1_ASAP7_75t_R g107(.A(new_n122_), .B(new_n116_), .C(new_n125_), .Y(new_n126_));
  INVx1_ASAP7_75t_R   g108(.A(new_n74_), .Y(new_n127_));
  AO21x1_ASAP7_75t_R  g109(.A1(new_n33_), .A2(new_n127_), .B(new_n77_), .Y(new_n128_));
  AND3x1_ASAP7_75t_R  g110(.A(new_n73_), .B(p5), .C(p4), .Y(new_n129_));
  AO21x1_ASAP7_75t_R  g111(.A1(new_n49_), .A2(new_n128_), .B(new_n129_), .Y(new_n130_));
  AOI21x1_ASAP7_75t_R g112(.A1(new_n117_), .A2(new_n126_), .B(new_n130_), .Y(new_n131_));
  OR3x1_ASAP7_75t_R   g113(.A(new_n33_), .B(new_n20_), .C(p7), .Y(new_n132_));
  OA21x2_ASAP7_75t_R  g114(.A1(new_n19_), .A2(new_n40_), .B(new_n132_), .Y(new_n133_));
  AND3x1_ASAP7_75t_R  g115(.A(new_n19_), .B(p4), .C(p6), .Y(new_n134_));
  NOR2x1_ASAP7_75t_R  g116(.A(p9), .B(p7), .Y(new_n135_));
  OR3x1_ASAP7_75t_R   g117(.A(new_n134_), .B(new_n20_), .C(new_n135_), .Y(new_n136_));
  OA21x2_ASAP7_75t_R  g118(.A1(new_n85_), .A2(new_n133_), .B(new_n136_), .Y(new_n137_));
  AND3x1_ASAP7_75t_R  g119(.A(new_n43_), .B(new_n24_), .C(p3), .Y(new_n138_));
  NOR2x1_ASAP7_75t_R  g120(.A(new_n65_), .B(new_n138_), .Y(new_n139_));
  OR3x1_ASAP7_75t_R   g121(.A(new_n139_), .B(p9), .C(new_n40_), .Y(new_n140_));
  NAND2x1_ASAP7_75t_R g122(.A(p4), .B(p3), .Y(new_n141_));
  AND3x1_ASAP7_75t_R  g123(.A(new_n23_), .B(p6), .C(p2), .Y(new_n142_));
  AO21x1_ASAP7_75t_R  g124(.A1(p5), .A2(new_n36_), .B(new_n142_), .Y(new_n143_));
  AOI21x1_ASAP7_75t_R g125(.A1(new_n85_), .A2(new_n141_), .B(new_n21_), .Y(new_n144_));
  OAI21x1_ASAP7_75t_R g126(.A1(new_n141_), .A2(new_n143_), .B(new_n144_), .Y(new_n145_));
  AND3x1_ASAP7_75t_R  g127(.A(new_n137_), .B(new_n140_), .C(new_n145_), .Y(new_n146_));
  OAI21x1_ASAP7_75t_R g128(.A1(new_n113_), .A2(new_n131_), .B(new_n146_), .Y(o2));
  OR3x1_ASAP7_75t_R   g129(.A(new_n54_), .B(new_n46_), .C(p3), .Y(new_n148_));
  AND3x1_ASAP7_75t_R  g130(.A(p5), .B(p4), .C(p6), .Y(new_n149_));
  INVx1_ASAP7_75t_R   g131(.A(new_n149_), .Y(new_n150_));
  NAND2x1_ASAP7_75t_R g132(.A(p7), .B(p3), .Y(new_n151_));
  OR3x1_ASAP7_75t_R   g133(.A(new_n150_), .B(p1), .C(new_n151_), .Y(new_n152_));
  OR3x1_ASAP7_75t_R   g134(.A(p9), .B(p8), .C(p2), .Y(new_n153_));
  AO21x1_ASAP7_75t_R  g135(.A1(new_n148_), .A2(new_n152_), .B(new_n153_), .Y(o3));
  OAI21x1_ASAP7_75t_R g136(.A1(new_n43_), .A2(new_n91_), .B(new_n49_), .Y(new_n155_));
  NOR2x1_ASAP7_75t_R  g137(.A(p4), .B(p6), .Y(new_n156_));
  NAND2x1_ASAP7_75t_R g138(.A(p3), .B(new_n156_), .Y(new_n157_));
  OA21x2_ASAP7_75t_R  g139(.A1(p6), .A2(new_n23_), .B(new_n40_), .Y(new_n158_));
  AND3x1_ASAP7_75t_R  g140(.A(new_n155_), .B(new_n157_), .C(new_n158_), .Y(new_n159_));
  AOI21x1_ASAP7_75t_R g141(.A1(new_n45_), .A2(new_n123_), .B(new_n138_), .Y(new_n160_));
  OR3x1_ASAP7_75t_R   g142(.A(new_n160_), .B(p7), .C(new_n62_), .Y(new_n161_));
  AO21x1_ASAP7_75t_R  g143(.A1(new_n151_), .A2(new_n119_), .B(p8), .Y(new_n162_));
  OR3x1_ASAP7_75t_R   g144(.A(new_n162_), .B(new_n59_), .C(new_n150_), .Y(new_n163_));
  AO21x1_ASAP7_75t_R  g145(.A1(p7), .A2(new_n149_), .B(new_n20_), .Y(new_n164_));
  NAND3x1_ASAP7_75t_R g146(.A(new_n161_), .B(new_n163_), .C(new_n164_), .Y(new_n165_));
  OAI21x1_ASAP7_75t_R g147(.A1(new_n159_), .A2(new_n165_), .B(new_n19_), .Y(o4));
  AND3x1_ASAP7_75t_R  g148(.A(new_n60_), .B(p7), .C(new_n149_), .Y(new_n167_));
  AND3x1_ASAP7_75t_R  g149(.A(new_n35_), .B(p10), .C(p1), .Y(new_n168_));
  AND3x1_ASAP7_75t_R  g150(.A(new_n168_), .B(new_n40_), .C(new_n156_), .Y(new_n169_));
  OA21x2_ASAP7_75t_R  g151(.A1(new_n167_), .A2(new_n169_), .B(p3), .Y(new_n170_));
  OR3x1_ASAP7_75t_R   g152(.A(new_n73_), .B(new_n74_), .C(new_n33_), .Y(new_n171_));
  AND3x1_ASAP7_75t_R  g153(.A(new_n171_), .B(new_n53_), .C(new_n46_), .Y(new_n172_));
  OR3x1_ASAP7_75t_R   g154(.A(new_n170_), .B(new_n21_), .C(new_n172_), .Y(o5));
  INVx1_ASAP7_75t_R   g155(.A(new_n171_), .Y(new_n174_));
  OR3x1_ASAP7_75t_R   g156(.A(new_n174_), .B(new_n21_), .C(new_n54_), .Y(o6));
endmodule


