// Benchmark "/tmp/" written by ABC on Tue Oct 13 14:24:55 2026

module \/tmp/  ( 
    p10, p8, p7, p3, p2, p4, p9, p0, p5, p6, p1,
    o0, o1, o2, o3, o4, o5, o6  );
  input  p10, p8, p7, p3, p2, p4, p9, p0, p5, p6, p1;
  output o0, o1, o2, o3, o4, o5, o6;
  wire new_n19_, new_n20_, new_n21_, new_n22_, new_n23_, new_n24_, new_n25_,
    new_n26_, new_n27_, new_n28_, new_n29_, new_n30_, new_n31_, new_n32_,
    new_n33_, new_n34_, new_n35_, new_n36_, new_n37_, new_n38_, new_n39_,
    new_n40_, new_n41_, new_n42_, new_n43_, new_n44_, new_n45_, new_n46_,
    new_n47_, new_n48_, new_n49_, new_n50_, new_n51_, new_n52_, new_n53_,
    new_n54_, new_n55_, new_n56_, new_n57_, new_n58_, new_n59_, new_n60_,
    new_n61_, new_n62_, new_n63_, new_n64_, new_n66_, new_n67_, new_n68_,
    new_n69_, new_n70_, new_n71_, new_n72_, new_n73_, new_n74_, new_n75_,
    new_n76_, new_n77_, new_n78_, new_n79_, new_n80_, new_n81_, new_n82_,
    new_n83_, new_n84_, new_n85_, new_n86_, new_n87_, new_n88_, new_n89_,
    new_n90_, new_n91_, new_n92_, new_n93_, new_n94_, new_n95_, new_n96_,
    new_n97_, new_n98_, new_n99_, new_n100_, new_n101_, new_n102_,
    new_n103_, new_n104_, new_n105_, new_n106_, new_n107_, new_n108_,
    new_n109_, new_n111_, new_n112_, new_n113_, new_n114_, new_n115_,
    new_n116_, new_n117_, new_n118_, new_n119_, new_n120_, new_n121_,
    new_n122_, new_n123_, new_n124_, new_n125_, new_n126_, new_n127_,
    new_n128_, new_n129_, new_n130_, new_n131_, new_n132_, new_n133_,
    new_n134_, new_n135_, new_n136_, new_n137_, new_n138_, new_n139_,
    new_n140_, new_n141_, new_n142_, new_n143_, new_n145_, new_n146_,
    new_n147_, new_n148_, new_n150_, new_n151_, new_n152_, new_n153_,
    new_n154_, new_n155_, new_n156_, new_n157_, new_n158_, new_n159_,
    new_n160_, new_n161_, new_n162_, new_n163_, new_n165_, new_n166_,
    new_n167_, new_n168_, new_n169_, new_n170_, new_n171_, new_n172_,
    new_n173_;
  INVx1_ASAP7_75t_R   g000(.A(p3), .Y(new_n19_));
  INVx1_ASAP7_75t_R   g001(.A(p4), .Y(new_n20_));
  AO21x1_ASAP7_75t_R  g002(.A1(p7), .A2(new_n19_), .B(new_n20_), .Y(new_n21_));
  AND2x2_ASAP7_75t_R  g003(.A(p3), .B(p0), .Y(new_n22_));
  INVx1_ASAP7_75t_R   g004(.A(p7), .Y(new_n23_));
  NOR2x1_ASAP7_75t_R  g005(.A(p3), .B(new_n23_), .Y(new_n24_));
  OA21x2_ASAP7_75t_R  g006(.A1(new_n22_), .A2(new_n24_), .B(p10), .Y(new_n25_));
  NOR2x1_ASAP7_75t_R  g007(.A(p10), .B(new_n22_), .Y(new_n26_));
  OR3x1_ASAP7_75t_R   g008(.A(new_n26_), .B(p5), .C(p6), .Y(new_n27_));
  AND2x2_ASAP7_75t_R  g009(.A(p7), .B(p3), .Y(new_n28_));
  NOR2x1_ASAP7_75t_R  g010(.A(p4), .B(new_n28_), .Y(new_n29_));
  OAI21x1_ASAP7_75t_R g011(.A1(new_n25_), .A2(new_n27_), .B(new_n29_), .Y(new_n30_));
  NAND2x1_ASAP7_75t_R g012(.A(p2), .B(new_n23_), .Y(new_n31_));
  NOR2x1_ASAP7_75t_R  g013(.A(p6), .B(p1), .Y(new_n32_));
  AND3x1_ASAP7_75t_R  g014(.A(new_n32_), .B(p4), .C(p0), .Y(new_n33_));
  AOI21x1_ASAP7_75t_R g015(.A1(new_n19_), .A2(p6), .B(new_n33_), .Y(new_n34_));
  INVx1_ASAP7_75t_R   g016(.A(p2), .Y(new_n35_));
  NAND2x1_ASAP7_75t_R g017(.A(p3), .B(new_n35_), .Y(new_n36_));
  INVx1_ASAP7_75t_R   g018(.A(p6), .Y(new_n37_));
  OR3x1_ASAP7_75t_R   g019(.A(new_n36_), .B(p7), .C(new_n37_), .Y(new_n38_));
  OAI21x1_ASAP7_75t_R g020(.A1(new_n31_), .A2(new_n34_), .B(new_n38_), .Y(new_n39_));
  AOI21x1_ASAP7_75t_R g021(.A1(new_n21_), .A2(new_n30_), .B(new_n39_), .Y(new_n40_));
  NOR2x1_ASAP7_75t_R  g022(.A(p8), .B(p9), .Y(new_n41_));
  INVx1_ASAP7_75t_R   g023(.A(new_n41_), .Y(new_n42_));
  NOR2x1_ASAP7_75t_R  g024(.A(p5), .B(new_n20_), .Y(new_n43_));
  NAND2x1_ASAP7_75t_R g025(.A(p3), .B(p2), .Y(new_n44_));
  INVx1_ASAP7_75t_R   g026(.A(p1), .Y(new_n45_));
  AND3x1_ASAP7_75t_R  g027(.A(new_n44_), .B(p0), .C(new_n45_), .Y(new_n46_));
  AOI21x1_ASAP7_75t_R g028(.A1(new_n19_), .A2(p6), .B(new_n28_), .Y(new_n47_));
  NOR2x1_ASAP7_75t_R  g029(.A(p7), .B(p6), .Y(new_n48_));
  INVx1_ASAP7_75t_R   g030(.A(p0), .Y(new_n49_));
  AND3x1_ASAP7_75t_R  g031(.A(new_n48_), .B(new_n49_), .C(p1), .Y(new_n50_));
  AO21x1_ASAP7_75t_R  g032(.A1(new_n46_), .A2(new_n47_), .B(new_n50_), .Y(new_n51_));
  INVx1_ASAP7_75t_R   g033(.A(p5), .Y(new_n52_));
  NOR2x1_ASAP7_75t_R  g034(.A(p4), .B(new_n52_), .Y(new_n53_));
  OA21x2_ASAP7_75t_R  g035(.A1(new_n43_), .A2(new_n53_), .B(p8), .Y(new_n54_));
  AOI21x1_ASAP7_75t_R g036(.A1(new_n43_), .A2(new_n51_), .B(new_n54_), .Y(new_n55_));
  NAND2x1_ASAP7_75t_R g037(.A(p5), .B(new_n37_), .Y(new_n56_));
  AND3x1_ASAP7_75t_R  g038(.A(p8), .B(p7), .C(p5), .Y(new_n57_));
  NOR2x1_ASAP7_75t_R  g039(.A(p5), .B(new_n37_), .Y(new_n58_));
  OAI21x1_ASAP7_75t_R g040(.A1(new_n57_), .A2(new_n58_), .B(p9), .Y(new_n59_));
  NOR2x1_ASAP7_75t_R  g041(.A(p8), .B(p7), .Y(new_n60_));
  XOR2x2_ASAP7_75t_R  g042(.A(p2), .B(p1), .Y(new_n61_));
  AOI21x1_ASAP7_75t_R g043(.A1(new_n60_), .A2(new_n61_), .B(p9), .Y(new_n62_));
  AO21x1_ASAP7_75t_R  g044(.A1(new_n56_), .A2(new_n59_), .B(new_n62_), .Y(new_n63_));
  OA21x2_ASAP7_75t_R  g045(.A1(p9), .A2(new_n55_), .B(new_n63_), .Y(new_n64_));
  OAI21x1_ASAP7_75t_R g046(.A1(new_n40_), .A2(new_n42_), .B(new_n64_), .Y(o0));
  INVx1_ASAP7_75t_R   g047(.A(p9), .Y(new_n66_));
  AO21x1_ASAP7_75t_R  g048(.A1(p5), .A2(p6), .B(p7), .Y(new_n67_));
  AO21x1_ASAP7_75t_R  g049(.A1(new_n66_), .A2(p6), .B(new_n67_), .Y(new_n68_));
  OR3x1_ASAP7_75t_R   g050(.A(new_n52_), .B(new_n45_), .C(p8), .Y(new_n69_));
  NOR3x1_ASAP7_75t_R  g051(.A(new_n52_), .B(p8), .C(p3), .Y(new_n70_));
  NOR3x1_ASAP7_75t_R  g052(.A(new_n20_), .B(p0), .C(p5), .Y(new_n71_));
  OAI21x1_ASAP7_75t_R g053(.A1(new_n70_), .A2(new_n71_), .B(new_n35_), .Y(new_n72_));
  OAI21x1_ASAP7_75t_R g054(.A1(new_n44_), .A2(new_n69_), .B(new_n72_), .Y(new_n73_));
  AND3x1_ASAP7_75t_R  g055(.A(new_n35_), .B(new_n52_), .C(p4), .Y(new_n74_));
  OA21x2_ASAP7_75t_R  g056(.A1(new_n70_), .A2(new_n74_), .B(new_n45_), .Y(new_n75_));
  NOR3x1_ASAP7_75t_R  g057(.A(new_n73_), .B(p9), .C(new_n75_), .Y(new_n76_));
  NAND2x1_ASAP7_75t_R g058(.A(p7), .B(p9), .Y(new_n77_));
  NAND2x1_ASAP7_75t_R g059(.A(p5), .B(p6), .Y(new_n78_));
  OR3x1_ASAP7_75t_R   g060(.A(new_n77_), .B(new_n78_), .C(p8), .Y(new_n79_));
  OAI21x1_ASAP7_75t_R g061(.A1(new_n68_), .A2(new_n76_), .B(new_n79_), .Y(new_n80_));
  INVx1_ASAP7_75t_R   g062(.A(p8), .Y(new_n81_));
  NOR2x1_ASAP7_75t_R  g063(.A(p8), .B(p3), .Y(new_n82_));
  OA21x2_ASAP7_75t_R  g064(.A1(new_n32_), .A2(new_n82_), .B(new_n49_), .Y(new_n83_));
  AO21x1_ASAP7_75t_R  g065(.A1(new_n81_), .A2(p7), .B(new_n83_), .Y(new_n84_));
  INVx1_ASAP7_75t_R   g066(.A(p10), .Y(new_n85_));
  AND2x2_ASAP7_75t_R  g067(.A(p0), .B(p1), .Y(new_n86_));
  NAND2x1_ASAP7_75t_R g068(.A(p3), .B(new_n37_), .Y(new_n87_));
  AOI21x1_ASAP7_75t_R g069(.A1(new_n85_), .A2(p1), .B(new_n87_), .Y(new_n88_));
  OA21x2_ASAP7_75t_R  g070(.A1(new_n85_), .A2(new_n86_), .B(new_n88_), .Y(new_n89_));
  NOR2x1_ASAP7_75t_R  g071(.A(p4), .B(p5), .Y(new_n90_));
  OAI21x1_ASAP7_75t_R g072(.A1(new_n84_), .A2(new_n89_), .B(new_n90_), .Y(new_n91_));
  INVx1_ASAP7_75t_R   g073(.A(new_n82_), .Y(new_n92_));
  NAND2x1_ASAP7_75t_R g074(.A(p8), .B(new_n37_), .Y(new_n93_));
  OA21x2_ASAP7_75t_R  g075(.A1(p8), .A2(p7), .B(p5), .Y(new_n94_));
  NAND3x1_ASAP7_75t_R g076(.A(new_n92_), .B(new_n93_), .C(new_n94_), .Y(new_n95_));
  NOR2x1_ASAP7_75t_R  g077(.A(p3), .B(p5), .Y(new_n96_));
  NAND3x1_ASAP7_75t_R g078(.A(new_n86_), .B(new_n37_), .C(new_n96_), .Y(new_n97_));
  AO21x1_ASAP7_75t_R  g079(.A1(p0), .A2(p1), .B(p6), .Y(new_n98_));
  NAND3x1_ASAP7_75t_R g080(.A(new_n98_), .B(p3), .C(new_n60_), .Y(new_n99_));
  NAND3x1_ASAP7_75t_R g081(.A(new_n95_), .B(new_n97_), .C(new_n99_), .Y(new_n100_));
  AOI21x1_ASAP7_75t_R g082(.A1(new_n35_), .A2(new_n95_), .B(new_n20_), .Y(new_n101_));
  NOR3x1_ASAP7_75t_R  g083(.A(new_n37_), .B(p8), .C(p7), .Y(new_n102_));
  NOR2x1_ASAP7_75t_R  g084(.A(p6), .B(new_n81_), .Y(new_n103_));
  AOI21x1_ASAP7_75t_R g085(.A1(new_n44_), .A2(new_n102_), .B(new_n103_), .Y(new_n104_));
  AND3x1_ASAP7_75t_R  g086(.A(new_n81_), .B(new_n19_), .C(p7), .Y(new_n105_));
  OAI21x1_ASAP7_75t_R g087(.A1(new_n103_), .A2(new_n105_), .B(new_n52_), .Y(new_n106_));
  OAI21x1_ASAP7_75t_R g088(.A1(p4), .A2(new_n104_), .B(new_n106_), .Y(new_n107_));
  AOI21x1_ASAP7_75t_R g089(.A1(new_n100_), .A2(new_n101_), .B(new_n107_), .Y(new_n108_));
  AOI21x1_ASAP7_75t_R g090(.A1(new_n91_), .A2(new_n108_), .B(p9), .Y(new_n109_));
  NOR2x1_ASAP7_75t_R  g091(.A(new_n80_), .B(new_n109_), .Y(o1));
  OR3x1_ASAP7_75t_R   g092(.A(p8), .B(p7), .C(p9), .Y(new_n111_));
  NAND2x1_ASAP7_75t_R g093(.A(p2), .B(new_n45_), .Y(new_n112_));
  NAND2x1_ASAP7_75t_R g094(.A(p3), .B(new_n52_), .Y(new_n113_));
  NAND3x1_ASAP7_75t_R g095(.A(new_n35_), .B(p3), .C(p4), .Y(new_n114_));
  OAI21x1_ASAP7_75t_R g096(.A1(new_n112_), .A2(new_n113_), .B(new_n114_), .Y(new_n115_));
  OA21x2_ASAP7_75t_R  g097(.A1(p1), .A2(new_n115_), .B(new_n37_), .Y(new_n116_));
  NAND2x1_ASAP7_75t_R g098(.A(p10), .B(new_n52_), .Y(new_n117_));
  OR3x1_ASAP7_75t_R   g099(.A(new_n35_), .B(new_n20_), .C(p3), .Y(new_n118_));
  OA21x2_ASAP7_75t_R  g100(.A1(new_n36_), .A2(new_n117_), .B(new_n118_), .Y(new_n119_));
  NAND2x1_ASAP7_75t_R g101(.A(p10), .B(p0), .Y(new_n120_));
  AND2x2_ASAP7_75t_R  g102(.A(p3), .B(p2), .Y(new_n121_));
  AO21x1_ASAP7_75t_R  g103(.A1(new_n120_), .A2(new_n121_), .B(new_n96_), .Y(new_n122_));
  AOI21x1_ASAP7_75t_R g104(.A1(new_n20_), .A2(new_n122_), .B(new_n115_), .Y(new_n123_));
  OAI21x1_ASAP7_75t_R g105(.A1(new_n49_), .A2(new_n119_), .B(new_n123_), .Y(new_n124_));
  AO21x1_ASAP7_75t_R  g106(.A1(p1), .A2(new_n53_), .B(new_n71_), .Y(new_n125_));
  AND3x1_ASAP7_75t_R  g107(.A(new_n44_), .B(p4), .C(p5), .Y(new_n126_));
  AO21x1_ASAP7_75t_R  g108(.A1(new_n121_), .A2(new_n125_), .B(new_n126_), .Y(new_n127_));
  AOI21x1_ASAP7_75t_R g109(.A1(new_n116_), .A2(new_n124_), .B(new_n127_), .Y(new_n128_));
  NAND2x1_ASAP7_75t_R g110(.A(p3), .B(p4), .Y(new_n129_));
  AND3x1_ASAP7_75t_R  g111(.A(new_n52_), .B(p2), .C(p6), .Y(new_n130_));
  AO21x1_ASAP7_75t_R  g112(.A1(p5), .A2(new_n32_), .B(new_n130_), .Y(new_n131_));
  NAND2x1_ASAP7_75t_R g113(.A(new_n78_), .B(new_n129_), .Y(new_n132_));
  OA21x2_ASAP7_75t_R  g114(.A1(new_n129_), .A2(new_n131_), .B(new_n132_), .Y(new_n133_));
  NAND2x1_ASAP7_75t_R g115(.A(p4), .B(p5), .Y(new_n134_));
  NOR2x1_ASAP7_75t_R  g116(.A(new_n134_), .B(new_n87_), .Y(new_n135_));
  NOR2x1_ASAP7_75t_R  g117(.A(p9), .B(new_n23_), .Y(new_n136_));
  OAI21x1_ASAP7_75t_R g118(.A1(new_n58_), .A2(new_n135_), .B(new_n136_), .Y(new_n137_));
  AO21x1_ASAP7_75t_R  g119(.A1(p4), .A2(p6), .B(new_n23_), .Y(new_n138_));
  AO21x1_ASAP7_75t_R  g120(.A1(new_n66_), .A2(new_n138_), .B(new_n81_), .Y(new_n139_));
  OR3x1_ASAP7_75t_R   g121(.A(new_n81_), .B(new_n20_), .C(p7), .Y(new_n140_));
  AO21x1_ASAP7_75t_R  g122(.A1(new_n77_), .A2(new_n140_), .B(new_n78_), .Y(new_n141_));
  NAND3x1_ASAP7_75t_R g123(.A(new_n137_), .B(new_n139_), .C(new_n141_), .Y(new_n142_));
  AOI21x1_ASAP7_75t_R g124(.A1(new_n41_), .A2(new_n133_), .B(new_n142_), .Y(new_n143_));
  OAI21x1_ASAP7_75t_R g125(.A1(new_n111_), .A2(new_n128_), .B(new_n143_), .Y(o2));
  AND3x1_ASAP7_75t_R  g126(.A(new_n48_), .B(new_n90_), .C(new_n19_), .Y(new_n145_));
  AND3x1_ASAP7_75t_R  g127(.A(p4), .B(p5), .C(p6), .Y(new_n146_));
  AND3x1_ASAP7_75t_R  g128(.A(new_n146_), .B(new_n28_), .C(new_n45_), .Y(new_n147_));
  NOR2x1_ASAP7_75t_R  g129(.A(new_n145_), .B(new_n147_), .Y(new_n148_));
  OR3x1_ASAP7_75t_R   g130(.A(new_n148_), .B(p2), .C(new_n42_), .Y(o3));
  OR3x1_ASAP7_75t_R   g131(.A(new_n78_), .B(new_n129_), .C(p8), .Y(new_n150_));
  AND2x2_ASAP7_75t_R  g132(.A(p7), .B(p2), .Y(new_n151_));
  AOI21x1_ASAP7_75t_R g133(.A1(new_n35_), .A2(p1), .B(new_n151_), .Y(new_n152_));
  AO21x1_ASAP7_75t_R  g134(.A1(p7), .A2(new_n146_), .B(new_n81_), .Y(new_n153_));
  OA21x2_ASAP7_75t_R  g135(.A1(new_n150_), .A2(new_n152_), .B(new_n153_), .Y(new_n154_));
  AND2x2_ASAP7_75t_R  g136(.A(p2), .B(p1), .Y(new_n155_));
  INVx1_ASAP7_75t_R   g137(.A(new_n120_), .Y(new_n156_));
  AO21x1_ASAP7_75t_R  g138(.A1(new_n90_), .A2(new_n156_), .B(new_n135_), .Y(new_n157_));
  OR3x1_ASAP7_75t_R   g139(.A(new_n49_), .B(new_n45_), .C(p6), .Y(new_n158_));
  AO21x1_ASAP7_75t_R  g140(.A1(new_n134_), .A2(new_n158_), .B(new_n44_), .Y(new_n159_));
  OR3x1_ASAP7_75t_R   g141(.A(new_n19_), .B(p4), .C(p6), .Y(new_n160_));
  AND3x1_ASAP7_75t_R  g142(.A(new_n159_), .B(new_n56_), .C(new_n160_), .Y(new_n161_));
  AOI21x1_ASAP7_75t_R g143(.A1(new_n155_), .A2(new_n157_), .B(new_n161_), .Y(new_n162_));
  AO21x1_ASAP7_75t_R  g144(.A1(p7), .A2(new_n154_), .B(p9), .Y(new_n163_));
  AO21x1_ASAP7_75t_R  g145(.A1(new_n154_), .A2(new_n162_), .B(new_n163_), .Y(o4));
  AO21x1_ASAP7_75t_R  g146(.A1(new_n151_), .A2(new_n146_), .B(p1), .Y(new_n165_));
  OR3x1_ASAP7_75t_R   g147(.A(new_n120_), .B(p4), .C(p6), .Y(new_n166_));
  NAND2x1_ASAP7_75t_R g148(.A(p7), .B(new_n146_), .Y(new_n167_));
  OA21x2_ASAP7_75t_R  g149(.A1(new_n31_), .A2(new_n166_), .B(new_n167_), .Y(new_n168_));
  NOR2x1_ASAP7_75t_R  g150(.A(new_n19_), .B(new_n168_), .Y(new_n169_));
  NOR3x1_ASAP7_75t_R  g151(.A(new_n44_), .B(new_n134_), .C(new_n45_), .Y(new_n170_));
  INVx1_ASAP7_75t_R   g152(.A(new_n48_), .Y(new_n171_));
  OR3x1_ASAP7_75t_R   g153(.A(new_n170_), .B(new_n171_), .C(new_n90_), .Y(new_n172_));
  NAND2x1_ASAP7_75t_R g154(.A(new_n41_), .B(new_n172_), .Y(new_n173_));
  AO21x1_ASAP7_75t_R  g155(.A1(new_n165_), .A2(new_n169_), .B(new_n173_), .Y(o5));
  OR3x1_ASAP7_75t_R   g156(.A(new_n170_), .B(new_n42_), .C(new_n171_), .Y(o6));
endmodule


