// Benchmark "/home/flynn/workplace/MIGBalance/results_v2/epfl_original_baselines_dependency_checkpoint_20261013/3in_core_cavlc/cavlc.resyn2" written by ABC on Tue Oct 13 12:59:44 2026

module \/home/flynn/workplace/MIGBalance/results_v2/epfl_original_baselines_dependency_checkpoint_20261013/3in_core_cavlc/cavlc.resyn2  ( 
    \totalcoeffs[0] , \totalcoeffs[1] , \totalcoeffs[2] , \totalcoeffs[3] ,
    \totalcoeffs[4] , \ctable[0] , \ctable[1] , \ctable[2] ,
    \trailingones[0] , \trailingones[1] ,
    \coeff_token[0] , \coeff_token[1] , \coeff_token[2] , \coeff_token[3] ,
    \coeff_token[4] , \coeff_token[5] , \ctoken_len[0] , \ctoken_len[1] ,
    \ctoken_len[2] , \ctoken_len[3] , \ctoken_len[4]   );
  input  \totalcoeffs[0] , \totalcoeffs[1] , \totalcoeffs[2] ,
    \totalcoeffs[3] , \totalcoeffs[4] , \ctable[0] , \ctable[1] ,
    \ctable[2] , \trailingones[0] , \trailingones[1] ;
  output \coeff_token[0] , \coeff_token[1] , \coeff_token[2] ,
    \coeff_token[3] , \coeff_token[4] , \coeff_token[5] , \ctoken_len[0] ,
    \ctoken_len[1] , \ctoken_len[2] , \ctoken_len[3] , \ctoken_len[4] ;
  wire new_n22_, new_n23_, new_n24_, new_n25_, new_n26_, new_n27_, new_n28_,
    new_n29_, new_n30_, new_n31_, new_n32_, new_n33_, new_n34_, new_n35_,
    new_n36_, new_n37_, new_n38_, new_n39_, new_n40_, new_n41_, new_n42_,
    new_n43_, new_n44_, new_n45_, new_n46_, new_n47_, new_n48_, new_n49_,
    new_n50_, new_n51_, new_n52_, new_n53_, new_n54_, new_n55_, new_n56_,
    new_n57_, new_n58_, new_n59_, new_n60_, new_n61_, new_n62_, new_n63_,
    new_n64_, new_n65_, new_n66_, new_n67_, new_n68_, new_n69_, new_n70_,
    new_n71_, new_n72_, new_n73_, new_n74_, new_n75_, new_n76_, new_n77_,
    new_n78_, new_n79_, new_n80_, new_n81_, new_n82_, new_n83_, new_n84_,
    new_n85_, new_n86_, new_n87_, new_n88_, new_n89_, new_n90_, new_n91_,
    new_n92_, new_n93_, new_n94_, new_n95_, new_n96_, new_n97_, new_n98_,
    new_n99_, new_n100_, new_n101_, new_n102_, new_n103_, new_n104_,
    new_n105_, new_n106_, new_n107_, new_n108_, new_n109_, new_n110_,
    new_n111_, new_n112_, new_n113_, new_n114_, new_n116_, new_n117_,
    new_n118_, new_n119_, new_n120_, new_n121_, new_n122_, new_n123_,
    new_n124_, new_n125_, new_n126_, new_n127_, new_n128_, new_n129_,
    new_n130_, new_n131_, new_n132_, new_n133_, new_n134_, new_n135_,
    new_n136_, new_n137_, new_n138_, new_n139_, new_n140_, new_n141_,
    new_n142_, new_n143_, new_n144_, new_n145_, new_n146_, new_n147_,
    new_n148_, new_n149_, new_n150_, new_n151_, new_n152_, new_n153_,
    new_n154_, new_n155_, new_n156_, new_n157_, new_n158_, new_n159_,
    new_n160_, new_n161_, new_n162_, new_n163_, new_n164_, new_n165_,
    new_n166_, new_n167_, new_n168_, new_n169_, new_n170_, new_n171_,
    new_n172_, new_n173_, new_n174_, new_n175_, new_n176_, new_n177_,
    new_n178_, new_n179_, new_n180_, new_n181_, new_n182_, new_n183_,
    new_n184_, new_n185_, new_n186_, new_n187_, new_n188_, new_n189_,
    new_n190_, new_n192_, new_n193_, new_n194_, new_n195_, new_n196_,
    new_n197_, new_n198_, new_n199_, new_n200_, new_n201_, new_n202_,
    new_n203_, new_n204_, new_n205_, new_n206_, new_n207_, new_n208_,
    new_n209_, new_n210_, new_n211_, new_n212_, new_n213_, new_n214_,
    new_n215_, new_n216_, new_n217_, new_n218_, new_n219_, new_n220_,
    new_n221_, new_n222_, new_n223_, new_n224_, new_n225_, new_n226_,
    new_n227_, new_n228_, new_n229_, new_n230_, new_n231_, new_n232_,
    new_n233_, new_n234_, new_n235_, new_n236_, new_n237_, new_n238_,
    new_n239_, new_n240_, new_n241_, new_n242_, new_n243_, new_n244_,
    new_n245_, new_n246_, new_n247_, new_n248_, new_n249_, new_n250_,
    new_n251_, new_n252_, new_n253_, new_n254_, new_n255_, new_n256_,
    new_n257_, new_n258_, new_n260_, new_n261_, new_n262_, new_n263_,
    new_n264_, new_n265_, new_n266_, new_n267_, new_n268_, new_n269_,
    new_n270_, new_n271_, new_n272_, new_n273_, new_n274_, new_n275_,
    new_n276_, new_n277_, new_n278_, new_n279_, new_n280_, new_n281_,
    new_n282_, new_n283_, new_n284_, new_n285_, new_n286_, new_n287_,
    new_n288_, new_n289_, new_n290_, new_n291_, new_n292_, new_n293_,
    new_n294_, new_n295_, new_n296_, new_n297_, new_n298_, new_n299_,
    new_n300_, new_n301_, new_n302_, new_n303_, new_n304_, new_n305_,
    new_n307_, new_n308_, new_n309_, new_n310_, new_n311_, new_n313_,
    new_n314_, new_n316_, new_n317_, new_n318_, new_n319_, new_n320_,
    new_n321_, new_n322_, new_n323_, new_n324_, new_n325_, new_n326_,
    new_n327_, new_n328_, new_n329_, new_n330_, new_n331_, new_n332_,
    new_n333_, new_n334_, new_n335_, new_n336_, new_n337_, new_n338_,
    new_n339_, new_n340_, new_n341_, new_n342_, new_n343_, new_n344_,
    new_n345_, new_n346_, new_n347_, new_n348_, new_n349_, new_n350_,
    new_n351_, new_n352_, new_n353_, new_n354_, new_n355_, new_n356_,
    new_n357_, new_n358_, new_n359_, new_n360_, new_n361_, new_n362_,
    new_n363_, new_n364_, new_n365_, new_n367_, new_n368_, new_n369_,
    new_n370_, new_n371_, new_n372_, new_n373_, new_n374_, new_n375_,
    new_n376_, new_n377_, new_n378_, new_n379_, new_n380_, new_n381_,
    new_n382_, new_n383_, new_n384_, new_n385_, new_n386_, new_n387_,
    new_n388_, new_n389_, new_n390_, new_n391_, new_n392_, new_n393_,
    new_n394_, new_n395_, new_n396_, new_n397_, new_n398_, new_n399_,
    new_n400_, new_n401_, new_n402_, new_n403_, new_n404_, new_n405_,
    new_n406_, new_n407_, new_n408_, new_n409_, new_n410_, new_n411_,
    new_n412_, new_n413_, new_n414_, new_n415_, new_n416_, new_n417_,
    new_n418_, new_n420_, new_n421_, new_n422_, new_n423_, new_n424_,
    new_n425_, new_n426_, new_n427_, new_n428_, new_n429_, new_n430_,
    new_n431_, new_n432_, new_n433_, new_n434_, new_n435_, new_n436_,
    new_n437_, new_n438_, new_n439_, new_n440_, new_n441_, new_n442_,
    new_n443_, new_n444_, new_n445_, new_n446_, new_n447_, new_n448_,
    new_n449_, new_n450_, new_n451_, new_n452_, new_n454_, new_n455_,
    new_n456_, new_n457_, new_n458_, new_n459_, new_n460_, new_n461_,
    new_n462_, new_n463_, new_n464_, new_n465_, new_n466_, new_n467_,
    new_n468_, new_n469_, new_n470_, new_n471_, new_n472_, new_n473_,
    new_n475_, new_n476_, new_n477_;
  INVx1_ASAP7_75t_R   g000(.A(\totalcoeffs[4] ), .Y(new_n22_));
  INVx1_ASAP7_75t_R   g001(.A(\ctable[2] ), .Y(new_n23_));
  INVx1_ASAP7_75t_R   g002(.A(\ctable[0] ), .Y(new_n24_));
  AND3x1_ASAP7_75t_R  g003(.A(new_n24_), .B(\ctable[2] ), .C(\trailingones[0] ), .Y(new_n25_));
  AO21x1_ASAP7_75t_R  g004(.A1(new_n23_), .A2(\trailingones[1] ), .B(new_n25_), .Y(new_n26_));
  NAND2x1_ASAP7_75t_R g005(.A(\totalcoeffs[1] ), .B(new_n26_), .Y(new_n27_));
  INVx1_ASAP7_75t_R   g006(.A(\trailingones[1] ), .Y(new_n28_));
  NAND2x1_ASAP7_75t_R g007(.A(new_n24_), .B(new_n28_), .Y(new_n29_));
  AO21x1_ASAP7_75t_R  g008(.A1(\totalcoeffs[1] ), .A2(new_n23_), .B(new_n29_), .Y(new_n30_));
  INVx1_ASAP7_75t_R   g009(.A(\totalcoeffs[2] ), .Y(new_n31_));
  NAND2x1_ASAP7_75t_R g010(.A(\totalcoeffs[0] ), .B(new_n31_), .Y(new_n32_));
  AO21x1_ASAP7_75t_R  g011(.A1(new_n27_), .A2(new_n30_), .B(new_n32_), .Y(new_n33_));
  NOR2x1_ASAP7_75t_R  g012(.A(\totalcoeffs[0] ), .B(\totalcoeffs[1] ), .Y(new_n34_));
  AND3x1_ASAP7_75t_R  g013(.A(new_n34_), .B(\totalcoeffs[2] ), .C(new_n28_), .Y(new_n35_));
  NAND2x1_ASAP7_75t_R g014(.A(new_n25_), .B(new_n35_), .Y(new_n36_));
  AO21x1_ASAP7_75t_R  g015(.A1(new_n33_), .A2(new_n36_), .B(\totalcoeffs[3] ), .Y(new_n37_));
  INVx1_ASAP7_75t_R   g016(.A(\totalcoeffs[0] ), .Y(new_n38_));
  INVx1_ASAP7_75t_R   g017(.A(\totalcoeffs[1] ), .Y(new_n39_));
  AO21x1_ASAP7_75t_R  g018(.A1(new_n38_), .A2(\trailingones[1] ), .B(new_n39_), .Y(new_n40_));
  NOR2x1_ASAP7_75t_R  g019(.A(\totalcoeffs[3] ), .B(\ctable[0] ), .Y(new_n41_));
  NAND2x1_ASAP7_75t_R g020(.A(\trailingones[1] ), .B(new_n39_), .Y(new_n42_));
  AND3x1_ASAP7_75t_R  g021(.A(new_n42_), .B(new_n40_), .C(new_n41_), .Y(new_n43_));
  AO21x1_ASAP7_75t_R  g022(.A1(new_n28_), .A2(\totalcoeffs[0] ), .B(\totalcoeffs[1] ), .Y(new_n44_));
  NAND2x1_ASAP7_75t_R g023(.A(\totalcoeffs[1] ), .B(new_n28_), .Y(new_n45_));
  AND3x1_ASAP7_75t_R  g024(.A(new_n45_), .B(new_n44_), .C(new_n23_), .Y(new_n46_));
  OAI21x1_ASAP7_75t_R g025(.A1(new_n43_), .A2(new_n46_), .B(new_n31_), .Y(new_n47_));
  NAND2x1_ASAP7_75t_R g026(.A(\totalcoeffs[1] ), .B(\totalcoeffs[2] ), .Y(new_n48_));
  AO21x1_ASAP7_75t_R  g027(.A1(new_n31_), .A2(new_n24_), .B(\totalcoeffs[0] ), .Y(new_n49_));
  AO21x1_ASAP7_75t_R  g028(.A1(new_n49_), .A2(new_n48_), .B(\trailingones[1] ), .Y(new_n50_));
  INVx1_ASAP7_75t_R   g029(.A(\totalcoeffs[3] ), .Y(new_n51_));
  AO21x1_ASAP7_75t_R  g030(.A1(new_n31_), .A2(new_n51_), .B(new_n28_), .Y(new_n52_));
  NAND2x1_ASAP7_75t_R g031(.A(\totalcoeffs[0] ), .B(\totalcoeffs[3] ), .Y(new_n53_));
  AO21x1_ASAP7_75t_R  g032(.A1(new_n52_), .A2(new_n53_), .B(\totalcoeffs[1] ), .Y(new_n54_));
  OA21x2_ASAP7_75t_R  g033(.A1(new_n39_), .A2(\totalcoeffs[3] ), .B(new_n54_), .Y(new_n55_));
  AO21x1_ASAP7_75t_R  g034(.A1(new_n55_), .A2(new_n50_), .B(\ctable[2] ), .Y(new_n56_));
  AO21x1_ASAP7_75t_R  g035(.A1(new_n56_), .A2(new_n47_), .B(\trailingones[0] ), .Y(new_n57_));
  AO21x1_ASAP7_75t_R  g036(.A1(new_n37_), .A2(new_n57_), .B(\ctable[1] ), .Y(new_n58_));
  INVx1_ASAP7_75t_R   g037(.A(\trailingones[0] ), .Y(new_n59_));
  NOR2x1_ASAP7_75t_R  g038(.A(\totalcoeffs[0] ), .B(\totalcoeffs[2] ), .Y(new_n60_));
  AND3x1_ASAP7_75t_R  g039(.A(new_n60_), .B(new_n39_), .C(\trailingones[1] ), .Y(new_n61_));
  OAI21x1_ASAP7_75t_R g040(.A1(\ctable[0] ), .A2(new_n61_), .B(\ctable[1] ), .Y(new_n62_));
  NAND2x1_ASAP7_75t_R g041(.A(\trailingones[1] ), .B(new_n38_), .Y(new_n63_));
  INVx1_ASAP7_75t_R   g042(.A(new_n63_), .Y(new_n64_));
  AND2x2_ASAP7_75t_R  g043(.A(new_n28_), .B(\totalcoeffs[0] ), .Y(new_n65_));
  OR3x1_ASAP7_75t_R   g044(.A(new_n39_), .B(new_n31_), .C(new_n24_), .Y(new_n66_));
  OR3x1_ASAP7_75t_R   g045(.A(new_n64_), .B(new_n65_), .C(new_n66_), .Y(new_n67_));
  AO21x1_ASAP7_75t_R  g046(.A1(new_n67_), .A2(new_n62_), .B(new_n59_), .Y(new_n68_));
  AO21x1_ASAP7_75t_R  g047(.A1(new_n63_), .A2(new_n39_), .B(\trailingones[0] ), .Y(new_n69_));
  NAND2x1_ASAP7_75t_R g048(.A(\totalcoeffs[2] ), .B(new_n39_), .Y(new_n70_));
  OR3x1_ASAP7_75t_R   g049(.A(new_n70_), .B(new_n38_), .C(\trailingones[1] ), .Y(new_n71_));
  AO21x1_ASAP7_75t_R  g050(.A1(new_n71_), .A2(new_n69_), .B(\ctable[0] ), .Y(new_n72_));
  AO21x1_ASAP7_75t_R  g051(.A1(new_n68_), .A2(new_n72_), .B(new_n51_), .Y(new_n73_));
  INVx1_ASAP7_75t_R   g052(.A(new_n40_), .Y(new_n74_));
  AO21x1_ASAP7_75t_R  g053(.A1(new_n28_), .A2(\totalcoeffs[0] ), .B(\totalcoeffs[2] ), .Y(new_n75_));
  AO21x1_ASAP7_75t_R  g054(.A1(new_n74_), .A2(new_n51_), .B(new_n75_), .Y(new_n76_));
  INVx1_ASAP7_75t_R   g055(.A(\ctable[1] ), .Y(new_n77_));
  NAND2x1_ASAP7_75t_R g056(.A(new_n77_), .B(new_n75_), .Y(new_n78_));
  AND3x1_ASAP7_75t_R  g057(.A(new_n76_), .B(\ctable[0] ), .C(new_n78_), .Y(new_n79_));
  AND2x2_ASAP7_75t_R  g058(.A(\totalcoeffs[2] ), .B(\trailingones[1] ), .Y(new_n80_));
  AND3x1_ASAP7_75t_R  g059(.A(new_n31_), .B(new_n28_), .C(\totalcoeffs[1] ), .Y(new_n81_));
  AND3x1_ASAP7_75t_R  g060(.A(new_n38_), .B(new_n51_), .C(\ctable[1] ), .Y(new_n82_));
  OA21x2_ASAP7_75t_R  g061(.A1(new_n81_), .A2(new_n80_), .B(new_n82_), .Y(new_n83_));
  OAI21x1_ASAP7_75t_R g062(.A1(new_n83_), .A2(new_n79_), .B(\trailingones[0] ), .Y(new_n84_));
  NOR2x1_ASAP7_75t_R  g063(.A(\totalcoeffs[2] ), .B(\totalcoeffs[3] ), .Y(new_n85_));
  INVx1_ASAP7_75t_R   g064(.A(new_n85_), .Y(new_n86_));
  OR3x1_ASAP7_75t_R   g065(.A(\totalcoeffs[1] ), .B(\trailingones[0] ), .C(\trailingones[1] ), .Y(new_n87_));
  OR3x1_ASAP7_75t_R   g066(.A(new_n86_), .B(\totalcoeffs[0] ), .C(new_n87_), .Y(new_n88_));
  NAND2x1_ASAP7_75t_R g067(.A(\totalcoeffs[1] ), .B(new_n59_), .Y(new_n89_));
  NAND2x1_ASAP7_75t_R g068(.A(\totalcoeffs[2] ), .B(new_n51_), .Y(new_n90_));
  OA21x2_ASAP7_75t_R  g069(.A1(new_n42_), .A2(new_n90_), .B(new_n89_), .Y(new_n91_));
  NOR2x1_ASAP7_75t_R  g070(.A(\totalcoeffs[1] ), .B(\trailingones[1] ), .Y(new_n92_));
  AO21x1_ASAP7_75t_R  g071(.A1(new_n31_), .A2(\ctable[1] ), .B(new_n51_), .Y(new_n93_));
  AO21x1_ASAP7_75t_R  g072(.A1(new_n93_), .A2(new_n92_), .B(new_n80_), .Y(new_n94_));
  NAND2x1_ASAP7_75t_R g073(.A(new_n59_), .B(new_n94_), .Y(new_n95_));
  OA21x2_ASAP7_75t_R  g074(.A1(\totalcoeffs[0] ), .A2(new_n91_), .B(new_n95_), .Y(new_n96_));
  OA21x2_ASAP7_75t_R  g075(.A1(new_n96_), .A2(\ctable[0] ), .B(new_n88_), .Y(new_n97_));
  AND3x1_ASAP7_75t_R  g076(.A(new_n73_), .B(new_n84_), .C(new_n97_), .Y(new_n98_));
  OAI21x1_ASAP7_75t_R g077(.A1(\ctable[2] ), .A2(new_n98_), .B(new_n58_), .Y(new_n99_));
  AO21x1_ASAP7_75t_R  g078(.A1(new_n77_), .A2(\trailingones[0] ), .B(new_n24_), .Y(new_n100_));
  INVx1_ASAP7_75t_R   g079(.A(new_n100_), .Y(new_n101_));
  AND2x2_ASAP7_75t_R  g080(.A(\totalcoeffs[4] ), .B(\trailingones[0] ), .Y(new_n102_));
  NAND2x1_ASAP7_75t_R g081(.A(new_n77_), .B(new_n28_), .Y(new_n103_));
  INVx1_ASAP7_75t_R   g082(.A(new_n103_), .Y(new_n104_));
  OA21x2_ASAP7_75t_R  g083(.A1(new_n104_), .A2(new_n102_), .B(new_n101_), .Y(new_n105_));
  NAND2x1_ASAP7_75t_R g084(.A(\ctable[1] ), .B(new_n28_), .Y(new_n106_));
  INVx1_ASAP7_75t_R   g085(.A(new_n106_), .Y(new_n107_));
  AO21x1_ASAP7_75t_R  g086(.A1(\totalcoeffs[4] ), .A2(\trailingones[1] ), .B(new_n107_), .Y(new_n108_));
  AND2x2_ASAP7_75t_R  g087(.A(\ctable[0] ), .B(\ctable[1] ), .Y(new_n109_));
  INVx1_ASAP7_75t_R   g088(.A(new_n109_), .Y(new_n110_));
  AND3x1_ASAP7_75t_R  g089(.A(new_n108_), .B(new_n59_), .C(new_n110_), .Y(new_n111_));
  NOR2x1_ASAP7_75t_R  g090(.A(\totalcoeffs[1] ), .B(\totalcoeffs[3] ), .Y(new_n112_));
  AND3x1_ASAP7_75t_R  g091(.A(new_n60_), .B(new_n112_), .C(new_n23_), .Y(new_n113_));
  OA21x2_ASAP7_75t_R  g092(.A1(new_n111_), .A2(new_n105_), .B(new_n113_), .Y(new_n114_));
  AO21x1_ASAP7_75t_R  g093(.A1(new_n99_), .A2(new_n22_), .B(new_n114_), .Y(\coeff_token[0] ));
  NAND2x1_ASAP7_75t_R g094(.A(\ctable[0] ), .B(new_n38_), .Y(new_n116_));
  OR3x1_ASAP7_75t_R   g095(.A(new_n116_), .B(\trailingones[0] ), .C(new_n28_), .Y(new_n117_));
  NAND2x1_ASAP7_75t_R g096(.A(\trailingones[0] ), .B(new_n24_), .Y(new_n118_));
  NAND2x1_ASAP7_75t_R g097(.A(\ctable[1] ), .B(\trailingones[1] ), .Y(new_n119_));
  AO21x1_ASAP7_75t_R  g098(.A1(\ctable[1] ), .A2(\trailingones[0] ), .B(new_n38_), .Y(new_n120_));
  AO21x1_ASAP7_75t_R  g099(.A1(new_n118_), .A2(new_n119_), .B(new_n120_), .Y(new_n121_));
  AO21x1_ASAP7_75t_R  g100(.A1(new_n117_), .A2(new_n121_), .B(\totalcoeffs[2] ), .Y(new_n122_));
  NAND2x1_ASAP7_75t_R g101(.A(new_n77_), .B(new_n59_), .Y(new_n123_));
  AND2x2_ASAP7_75t_R  g102(.A(new_n24_), .B(\trailingones[0] ), .Y(new_n124_));
  AND2x2_ASAP7_75t_R  g103(.A(new_n38_), .B(\ctable[1] ), .Y(new_n125_));
  OAI21x1_ASAP7_75t_R g104(.A1(\totalcoeffs[2] ), .A2(new_n125_), .B(new_n124_), .Y(new_n126_));
  AO21x1_ASAP7_75t_R  g105(.A1(new_n126_), .A2(new_n123_), .B(\trailingones[1] ), .Y(new_n127_));
  AO21x1_ASAP7_75t_R  g106(.A1(new_n122_), .A2(new_n127_), .B(new_n39_), .Y(new_n128_));
  NAND2x1_ASAP7_75t_R g107(.A(\totalcoeffs[2] ), .B(new_n28_), .Y(new_n129_));
  OR3x1_ASAP7_75t_R   g108(.A(new_n129_), .B(\ctable[1] ), .C(new_n59_), .Y(new_n130_));
  NOR2x1_ASAP7_75t_R  g109(.A(\totalcoeffs[2] ), .B(\trailingones[0] ), .Y(new_n131_));
  INVx1_ASAP7_75t_R   g110(.A(new_n131_), .Y(new_n132_));
  OR3x1_ASAP7_75t_R   g111(.A(new_n132_), .B(\totalcoeffs[0] ), .C(\trailingones[1] ), .Y(new_n133_));
  AND3x1_ASAP7_75t_R  g112(.A(\totalcoeffs[0] ), .B(\trailingones[0] ), .C(\trailingones[1] ), .Y(new_n134_));
  NAND2x1_ASAP7_75t_R g113(.A(\totalcoeffs[2] ), .B(new_n134_), .Y(new_n135_));
  AO21x1_ASAP7_75t_R  g114(.A1(new_n133_), .A2(new_n135_), .B(new_n24_), .Y(new_n136_));
  AO21x1_ASAP7_75t_R  g115(.A1(new_n118_), .A2(new_n119_), .B(\totalcoeffs[0] ), .Y(new_n137_));
  OR3x1_ASAP7_75t_R   g116(.A(\ctable[0] ), .B(\trailingones[0] ), .C(\trailingones[1] ), .Y(new_n138_));
  OR3x1_ASAP7_75t_R   g117(.A(new_n77_), .B(new_n59_), .C(new_n28_), .Y(new_n139_));
  AND2x2_ASAP7_75t_R  g118(.A(new_n139_), .B(new_n138_), .Y(new_n140_));
  AO21x1_ASAP7_75t_R  g119(.A1(new_n140_), .A2(new_n137_), .B(new_n31_), .Y(new_n141_));
  AO21x1_ASAP7_75t_R  g120(.A1(new_n136_), .A2(new_n141_), .B(\totalcoeffs[1] ), .Y(new_n142_));
  AND3x1_ASAP7_75t_R  g121(.A(new_n142_), .B(new_n128_), .C(new_n130_), .Y(new_n143_));
  OR3x1_ASAP7_75t_R   g122(.A(\totalcoeffs[0] ), .B(\totalcoeffs[1] ), .C(\totalcoeffs[2] ), .Y(new_n144_));
  AND2x2_ASAP7_75t_R  g123(.A(new_n59_), .B(\ctable[0] ), .Y(new_n145_));
  OAI21x1_ASAP7_75t_R g124(.A1(new_n102_), .A2(new_n145_), .B(new_n104_), .Y(new_n146_));
  OR3x1_ASAP7_75t_R   g125(.A(new_n22_), .B(new_n77_), .C(new_n28_), .Y(new_n147_));
  AO21x1_ASAP7_75t_R  g126(.A1(new_n146_), .A2(new_n147_), .B(new_n144_), .Y(new_n148_));
  OAI21x1_ASAP7_75t_R g127(.A1(\totalcoeffs[4] ), .A2(new_n143_), .B(new_n148_), .Y(new_n149_));
  OR3x1_ASAP7_75t_R   g128(.A(new_n24_), .B(\totalcoeffs[2] ), .C(\trailingones[0] ), .Y(new_n150_));
  NOR2x1_ASAP7_75t_R  g129(.A(\totalcoeffs[3] ), .B(\trailingones[0] ), .Y(new_n151_));
  OR3x1_ASAP7_75t_R   g130(.A(new_n124_), .B(new_n38_), .C(new_n151_), .Y(new_n152_));
  AO21x1_ASAP7_75t_R  g131(.A1(new_n152_), .A2(new_n150_), .B(\totalcoeffs[1] ), .Y(new_n153_));
  AO21x1_ASAP7_75t_R  g132(.A1(\totalcoeffs[3] ), .A2(\trailingones[0] ), .B(\totalcoeffs[2] ), .Y(new_n154_));
  NAND2x1_ASAP7_75t_R g133(.A(new_n38_), .B(new_n154_), .Y(new_n155_));
  OR3x1_ASAP7_75t_R   g134(.A(new_n38_), .B(new_n59_), .C(\totalcoeffs[2] ), .Y(new_n156_));
  AND2x2_ASAP7_75t_R  g135(.A(new_n24_), .B(\totalcoeffs[0] ), .Y(new_n157_));
  INVx1_ASAP7_75t_R   g136(.A(new_n157_), .Y(new_n158_));
  AND3x1_ASAP7_75t_R  g137(.A(new_n158_), .B(new_n116_), .C(new_n156_), .Y(new_n159_));
  OA21x2_ASAP7_75t_R  g138(.A1(new_n159_), .A2(new_n39_), .B(new_n155_), .Y(new_n160_));
  AOI21x1_ASAP7_75t_R g139(.A1(new_n153_), .A2(new_n160_), .B(\ctable[1] ), .Y(new_n161_));
  AO21x1_ASAP7_75t_R  g140(.A1(new_n39_), .A2(new_n59_), .B(\totalcoeffs[2] ), .Y(new_n162_));
  OR3x1_ASAP7_75t_R   g141(.A(new_n77_), .B(new_n59_), .C(\totalcoeffs[1] ), .Y(new_n163_));
  AO21x1_ASAP7_75t_R  g142(.A1(new_n163_), .A2(new_n162_), .B(new_n51_), .Y(new_n164_));
  NAND2x1_ASAP7_75t_R g143(.A(\trailingones[0] ), .B(new_n38_), .Y(new_n165_));
  INVx1_ASAP7_75t_R   g144(.A(new_n165_), .Y(new_n166_));
  AND2x2_ASAP7_75t_R  g145(.A(\totalcoeffs[0] ), .B(\totalcoeffs[1] ), .Y(new_n167_));
  AO21x1_ASAP7_75t_R  g146(.A1(new_n39_), .A2(new_n77_), .B(new_n167_), .Y(new_n168_));
  OR3x1_ASAP7_75t_R   g147(.A(new_n166_), .B(\totalcoeffs[2] ), .C(new_n168_), .Y(new_n169_));
  AO21x1_ASAP7_75t_R  g148(.A1(new_n169_), .A2(new_n164_), .B(\ctable[0] ), .Y(new_n170_));
  NAND2x1_ASAP7_75t_R g149(.A(new_n28_), .B(new_n170_), .Y(new_n171_));
  AND2x2_ASAP7_75t_R  g150(.A(\totalcoeffs[1] ), .B(\ctable[0] ), .Y(new_n172_));
  AND2x2_ASAP7_75t_R  g151(.A(new_n39_), .B(\totalcoeffs[3] ), .Y(new_n173_));
  AO21x1_ASAP7_75t_R  g152(.A1(new_n173_), .A2(new_n131_), .B(new_n172_), .Y(new_n174_));
  AND3x1_ASAP7_75t_R  g153(.A(\totalcoeffs[1] ), .B(\totalcoeffs[2] ), .C(\totalcoeffs[3] ), .Y(new_n175_));
  OA21x2_ASAP7_75t_R  g154(.A1(new_n175_), .A2(\ctable[0] ), .B(new_n86_), .Y(new_n176_));
  AO21x1_ASAP7_75t_R  g155(.A1(new_n174_), .A2(\totalcoeffs[0] ), .B(new_n176_), .Y(new_n177_));
  AO21x1_ASAP7_75t_R  g156(.A1(new_n145_), .A2(new_n175_), .B(new_n28_), .Y(new_n178_));
  AO21x1_ASAP7_75t_R  g157(.A1(new_n177_), .A2(\ctable[1] ), .B(new_n178_), .Y(new_n179_));
  AND2x2_ASAP7_75t_R  g158(.A(new_n179_), .B(new_n22_), .Y(new_n180_));
  OA21x2_ASAP7_75t_R  g159(.A1(new_n171_), .A2(new_n161_), .B(new_n180_), .Y(new_n181_));
  AOI21x1_ASAP7_75t_R g160(.A1(new_n51_), .A2(new_n149_), .B(new_n181_), .Y(new_n182_));
  AND2x2_ASAP7_75t_R  g161(.A(new_n31_), .B(\trailingones[0] ), .Y(new_n183_));
  AND3x1_ASAP7_75t_R  g162(.A(new_n183_), .B(\totalcoeffs[1] ), .C(new_n28_), .Y(new_n184_));
  OA21x2_ASAP7_75t_R  g163(.A1(new_n34_), .A2(new_n31_), .B(new_n59_), .Y(new_n185_));
  OA21x2_ASAP7_75t_R  g164(.A1(new_n75_), .A2(new_n167_), .B(new_n185_), .Y(new_n186_));
  OA21x2_ASAP7_75t_R  g165(.A1(new_n186_), .A2(new_n184_), .B(\ctable[2] ), .Y(new_n187_));
  NOR2x1_ASAP7_75t_R  g166(.A(new_n35_), .B(new_n187_), .Y(new_n188_));
  OR3x1_ASAP7_75t_R   g167(.A(\totalcoeffs[3] ), .B(\ctable[0] ), .C(\ctable[1] ), .Y(new_n189_));
  OR3x1_ASAP7_75t_R   g168(.A(new_n188_), .B(\totalcoeffs[4] ), .C(new_n189_), .Y(new_n190_));
  OAI21x1_ASAP7_75t_R g169(.A1(\ctable[2] ), .A2(new_n182_), .B(new_n190_), .Y(\coeff_token[1] ));
  NOR2x1_ASAP7_75t_R  g170(.A(\trailingones[0] ), .B(\trailingones[1] ), .Y(new_n192_));
  AND2x2_ASAP7_75t_R  g171(.A(\trailingones[0] ), .B(\trailingones[1] ), .Y(new_n193_));
  NOR2x1_ASAP7_75t_R  g172(.A(new_n193_), .B(new_n192_), .Y(new_n194_));
  OAI21x1_ASAP7_75t_R g173(.A1(new_n92_), .A2(new_n194_), .B(\totalcoeffs[2] ), .Y(new_n195_));
  INVx1_ASAP7_75t_R   g174(.A(new_n134_), .Y(new_n196_));
  NOR2x1_ASAP7_75t_R  g175(.A(new_n24_), .B(new_n192_), .Y(new_n197_));
  INVx1_ASAP7_75t_R   g176(.A(new_n80_), .Y(new_n198_));
  AO21x1_ASAP7_75t_R  g177(.A1(new_n198_), .A2(new_n24_), .B(new_n39_), .Y(new_n199_));
  AO21x1_ASAP7_75t_R  g178(.A1(new_n197_), .A2(new_n196_), .B(new_n199_), .Y(new_n200_));
  AO21x1_ASAP7_75t_R  g179(.A1(new_n200_), .A2(new_n195_), .B(\totalcoeffs[3] ), .Y(new_n201_));
  OR3x1_ASAP7_75t_R   g180(.A(new_n52_), .B(\totalcoeffs[1] ), .C(new_n59_), .Y(new_n202_));
  INVx1_ASAP7_75t_R   g181(.A(new_n192_), .Y(new_n203_));
  NOR2x1_ASAP7_75t_R  g182(.A(new_n24_), .B(new_n173_), .Y(new_n204_));
  OR3x1_ASAP7_75t_R   g183(.A(new_n204_), .B(\totalcoeffs[2] ), .C(new_n203_), .Y(new_n205_));
  AO21x1_ASAP7_75t_R  g184(.A1(new_n205_), .A2(new_n202_), .B(new_n38_), .Y(new_n206_));
  AO21x1_ASAP7_75t_R  g185(.A1(new_n206_), .A2(new_n201_), .B(\ctable[1] ), .Y(new_n207_));
  AO21x1_ASAP7_75t_R  g186(.A1(new_n39_), .A2(\trailingones[1] ), .B(new_n77_), .Y(new_n208_));
  AO21x1_ASAP7_75t_R  g187(.A1(new_n45_), .A2(new_n208_), .B(new_n59_), .Y(new_n209_));
  XNOR2x2_ASAP7_75t_R g188(.A(\totalcoeffs[1] ), .B(\trailingones[1] ), .Y(new_n210_));
  NAND2x1_ASAP7_75t_R g189(.A(new_n151_), .B(new_n210_), .Y(new_n211_));
  AO21x1_ASAP7_75t_R  g190(.A1(new_n211_), .A2(new_n209_), .B(\totalcoeffs[2] ), .Y(new_n212_));
  NAND2x1_ASAP7_75t_R g191(.A(\trailingones[0] ), .B(new_n39_), .Y(new_n213_));
  OR3x1_ASAP7_75t_R   g192(.A(new_n39_), .B(new_n31_), .C(new_n28_), .Y(new_n214_));
  AO21x1_ASAP7_75t_R  g193(.A1(new_n214_), .A2(new_n213_), .B(new_n77_), .Y(new_n215_));
  AO21x1_ASAP7_75t_R  g194(.A1(new_n28_), .A2(\totalcoeffs[2] ), .B(new_n59_), .Y(new_n216_));
  OA21x2_ASAP7_75t_R  g195(.A1(new_n203_), .A2(new_n31_), .B(new_n216_), .Y(new_n217_));
  AO21x1_ASAP7_75t_R  g196(.A1(new_n215_), .A2(new_n217_), .B(new_n51_), .Y(new_n218_));
  AO21x1_ASAP7_75t_R  g197(.A1(new_n218_), .A2(new_n212_), .B(new_n158_), .Y(new_n219_));
  AOI21x1_ASAP7_75t_R g198(.A1(new_n219_), .A2(new_n207_), .B(\totalcoeffs[4] ), .Y(new_n220_));
  AO21x1_ASAP7_75t_R  g199(.A1(new_n31_), .A2(\trailingones[0] ), .B(new_n51_), .Y(new_n221_));
  NAND2x1_ASAP7_75t_R g200(.A(\ctable[0] ), .B(new_n221_), .Y(new_n222_));
  NAND2x1_ASAP7_75t_R g201(.A(\totalcoeffs[2] ), .B(new_n24_), .Y(new_n223_));
  AO21x1_ASAP7_75t_R  g202(.A1(new_n223_), .A2(\totalcoeffs[3] ), .B(new_n59_), .Y(new_n224_));
  AO21x1_ASAP7_75t_R  g203(.A1(new_n222_), .A2(new_n224_), .B(new_n39_), .Y(new_n225_));
  NOR2x1_ASAP7_75t_R  g204(.A(\totalcoeffs[1] ), .B(\trailingones[0] ), .Y(new_n226_));
  AND3x1_ASAP7_75t_R  g205(.A(new_n51_), .B(new_n24_), .C(\ctable[1] ), .Y(new_n227_));
  NAND2x1_ASAP7_75t_R g206(.A(new_n226_), .B(new_n227_), .Y(new_n228_));
  AO21x1_ASAP7_75t_R  g207(.A1(new_n225_), .A2(new_n228_), .B(\trailingones[1] ), .Y(new_n229_));
  AO21x1_ASAP7_75t_R  g208(.A1(\totalcoeffs[1] ), .A2(\trailingones[0] ), .B(new_n77_), .Y(new_n230_));
  AO21x1_ASAP7_75t_R  g209(.A1(new_n230_), .A2(new_n28_), .B(\totalcoeffs[2] ), .Y(new_n231_));
  OR3x1_ASAP7_75t_R   g210(.A(new_n28_), .B(\totalcoeffs[1] ), .C(\trailingones[0] ), .Y(new_n232_));
  AO21x1_ASAP7_75t_R  g211(.A1(new_n231_), .A2(new_n232_), .B(new_n51_), .Y(new_n233_));
  AO21x1_ASAP7_75t_R  g212(.A1(new_n77_), .A2(\trailingones[0] ), .B(new_n31_), .Y(new_n234_));
  NAND2x1_ASAP7_75t_R g213(.A(\ctable[0] ), .B(new_n154_), .Y(new_n235_));
  AO21x1_ASAP7_75t_R  g214(.A1(\totalcoeffs[1] ), .A2(new_n234_), .B(new_n235_), .Y(new_n236_));
  OA21x2_ASAP7_75t_R  g215(.A1(new_n51_), .A2(\trailingones[0] ), .B(new_n45_), .Y(new_n237_));
  AND2x2_ASAP7_75t_R  g216(.A(new_n28_), .B(\totalcoeffs[3] ), .Y(new_n238_));
  OR3x1_ASAP7_75t_R   g217(.A(new_n237_), .B(\ctable[1] ), .C(new_n238_), .Y(new_n239_));
  NAND2x1_ASAP7_75t_R g218(.A(\ctable[1] ), .B(new_n59_), .Y(new_n240_));
  INVx1_ASAP7_75t_R   g219(.A(new_n240_), .Y(new_n241_));
  AND3x1_ASAP7_75t_R  g220(.A(new_n51_), .B(\totalcoeffs[1] ), .C(\trailingones[1] ), .Y(new_n242_));
  NAND2x1_ASAP7_75t_R g221(.A(new_n242_), .B(new_n241_), .Y(new_n243_));
  AND3x1_ASAP7_75t_R  g222(.A(new_n239_), .B(new_n22_), .C(new_n243_), .Y(new_n244_));
  AND3x1_ASAP7_75t_R  g223(.A(new_n244_), .B(new_n233_), .C(new_n236_), .Y(new_n245_));
  AO21x1_ASAP7_75t_R  g224(.A1(\ctable[1] ), .A2(new_n59_), .B(new_n193_), .Y(new_n246_));
  OR3x1_ASAP7_75t_R   g225(.A(\totalcoeffs[1] ), .B(\totalcoeffs[2] ), .C(\totalcoeffs[3] ), .Y(new_n247_));
  AO21x1_ASAP7_75t_R  g226(.A1(new_n246_), .A2(new_n24_), .B(new_n247_), .Y(new_n248_));
  AO21x1_ASAP7_75t_R  g227(.A1(new_n248_), .A2(\totalcoeffs[4] ), .B(\totalcoeffs[0] ), .Y(new_n249_));
  AOI21x1_ASAP7_75t_R g228(.A1(new_n229_), .A2(new_n245_), .B(new_n249_), .Y(new_n250_));
  OAI21x1_ASAP7_75t_R g229(.A1(new_n220_), .A2(new_n250_), .B(new_n23_), .Y(new_n251_));
  INVx1_ASAP7_75t_R   g230(.A(new_n193_), .Y(new_n252_));
  OA21x2_ASAP7_75t_R  g231(.A1(new_n252_), .A2(new_n23_), .B(\totalcoeffs[0] ), .Y(new_n253_));
  NAND2x1_ASAP7_75t_R g232(.A(new_n226_), .B(new_n65_), .Y(new_n254_));
  OA21x2_ASAP7_75t_R  g233(.A1(new_n253_), .A2(new_n40_), .B(new_n254_), .Y(new_n255_));
  NOR2x1_ASAP7_75t_R  g234(.A(\ctable[0] ), .B(\ctable[1] ), .Y(new_n256_));
  INVx1_ASAP7_75t_R   g235(.A(new_n256_), .Y(new_n257_));
  OR3x1_ASAP7_75t_R   g236(.A(new_n86_), .B(new_n257_), .C(\totalcoeffs[4] ), .Y(new_n258_));
  OAI21x1_ASAP7_75t_R g237(.A1(new_n255_), .A2(new_n258_), .B(new_n251_), .Y(\coeff_token[2] ));
  AND3x1_ASAP7_75t_R  g238(.A(\ctable[0] ), .B(\trailingones[0] ), .C(\trailingones[1] ), .Y(new_n260_));
  NAND2x1_ASAP7_75t_R g239(.A(new_n77_), .B(new_n260_), .Y(new_n261_));
  AO21x1_ASAP7_75t_R  g240(.A1(new_n261_), .A2(new_n138_), .B(new_n31_), .Y(new_n262_));
  AO21x1_ASAP7_75t_R  g241(.A1(new_n240_), .A2(new_n51_), .B(new_n101_), .Y(new_n263_));
  AOI21x1_ASAP7_75t_R g242(.A1(new_n262_), .A2(new_n263_), .B(new_n39_), .Y(new_n264_));
  AND3x1_ASAP7_75t_R  g243(.A(new_n24_), .B(\totalcoeffs[2] ), .C(\ctable[1] ), .Y(new_n265_));
  AO21x1_ASAP7_75t_R  g244(.A1(new_n86_), .A2(\ctable[1] ), .B(new_n238_), .Y(new_n266_));
  AO21x1_ASAP7_75t_R  g245(.A1(new_n266_), .A2(new_n39_), .B(new_n265_), .Y(new_n267_));
  OA21x2_ASAP7_75t_R  g246(.A1(new_n264_), .A2(new_n267_), .B(new_n22_), .Y(new_n268_));
  NAND2x1_ASAP7_75t_R g247(.A(new_n110_), .B(new_n257_), .Y(new_n269_));
  AO21x1_ASAP7_75t_R  g248(.A1(\trailingones[0] ), .A2(\trailingones[1] ), .B(\ctable[0] ), .Y(new_n270_));
  AND2x2_ASAP7_75t_R  g249(.A(new_n51_), .B(\totalcoeffs[4] ), .Y(new_n271_));
  AND3x1_ASAP7_75t_R  g250(.A(new_n271_), .B(new_n39_), .C(new_n31_), .Y(new_n272_));
  AND3x1_ASAP7_75t_R  g251(.A(new_n272_), .B(new_n269_), .C(new_n270_), .Y(new_n273_));
  OA21x2_ASAP7_75t_R  g252(.A1(new_n268_), .A2(new_n273_), .B(new_n38_), .Y(new_n274_));
  OA21x2_ASAP7_75t_R  g253(.A1(new_n124_), .A2(new_n151_), .B(\totalcoeffs[2] ), .Y(new_n275_));
  AND2x2_ASAP7_75t_R  g254(.A(new_n31_), .B(\ctable[0] ), .Y(new_n276_));
  AO21x1_ASAP7_75t_R  g255(.A1(\trailingones[0] ), .A2(new_n276_), .B(new_n275_), .Y(new_n277_));
  AND2x2_ASAP7_75t_R  g256(.A(new_n59_), .B(\trailingones[1] ), .Y(new_n278_));
  AO21x1_ASAP7_75t_R  g257(.A1(new_n278_), .A2(\ctable[0] ), .B(\totalcoeffs[3] ), .Y(new_n279_));
  AO21x1_ASAP7_75t_R  g258(.A1(new_n59_), .A2(\totalcoeffs[3] ), .B(\ctable[1] ), .Y(new_n280_));
  NAND2x1_ASAP7_75t_R g259(.A(\totalcoeffs[3] ), .B(new_n24_), .Y(new_n281_));
  AND2x2_ASAP7_75t_R  g260(.A(new_n281_), .B(new_n280_), .Y(new_n282_));
  AO21x1_ASAP7_75t_R  g261(.A1(new_n279_), .A2(new_n31_), .B(new_n282_), .Y(new_n283_));
  AO21x1_ASAP7_75t_R  g262(.A1(new_n277_), .A2(new_n28_), .B(new_n283_), .Y(new_n284_));
  NAND2x1_ASAP7_75t_R g263(.A(\totalcoeffs[1] ), .B(new_n284_), .Y(new_n285_));
  INVx1_ASAP7_75t_R   g264(.A(new_n227_), .Y(new_n286_));
  OR3x1_ASAP7_75t_R   g265(.A(new_n150_), .B(\totalcoeffs[1] ), .C(\ctable[1] ), .Y(new_n287_));
  AO21x1_ASAP7_75t_R  g266(.A1(new_n287_), .A2(new_n286_), .B(\trailingones[1] ), .Y(new_n288_));
  AO21x1_ASAP7_75t_R  g267(.A1(new_n285_), .A2(new_n288_), .B(new_n38_), .Y(new_n289_));
  OR3x1_ASAP7_75t_R   g268(.A(new_n31_), .B(new_n51_), .C(\ctable[1] ), .Y(new_n290_));
  OR3x1_ASAP7_75t_R   g269(.A(new_n85_), .B(\ctable[0] ), .C(new_n77_), .Y(new_n291_));
  AO21x1_ASAP7_75t_R  g270(.A1(new_n291_), .A2(new_n290_), .B(new_n28_), .Y(new_n292_));
  NAND2x1_ASAP7_75t_R g271(.A(\totalcoeffs[3] ), .B(new_n77_), .Y(new_n293_));
  OR3x1_ASAP7_75t_R   g272(.A(new_n77_), .B(\ctable[0] ), .C(\trailingones[1] ), .Y(new_n294_));
  AO21x1_ASAP7_75t_R  g273(.A1(new_n294_), .A2(new_n293_), .B(\trailingones[0] ), .Y(new_n295_));
  AO21x1_ASAP7_75t_R  g274(.A1(new_n292_), .A2(new_n295_), .B(\totalcoeffs[1] ), .Y(new_n296_));
  OR3x1_ASAP7_75t_R   g275(.A(new_n294_), .B(new_n39_), .C(new_n59_), .Y(new_n297_));
  AO21x1_ASAP7_75t_R  g276(.A1(new_n29_), .A2(new_n123_), .B(\totalcoeffs[2] ), .Y(new_n298_));
  NAND2x1_ASAP7_75t_R g277(.A(\totalcoeffs[1] ), .B(\trailingones[1] ), .Y(new_n299_));
  AO21x1_ASAP7_75t_R  g278(.A1(\ctable[0] ), .A2(\trailingones[1] ), .B(\ctable[1] ), .Y(new_n300_));
  NAND2x1_ASAP7_75t_R g279(.A(\ctable[0] ), .B(\trailingones[0] ), .Y(new_n301_));
  AO21x1_ASAP7_75t_R  g280(.A1(new_n299_), .A2(new_n301_), .B(new_n300_), .Y(new_n302_));
  AO21x1_ASAP7_75t_R  g281(.A1(new_n298_), .A2(new_n302_), .B(new_n51_), .Y(new_n303_));
  AND3x1_ASAP7_75t_R  g282(.A(new_n296_), .B(new_n297_), .C(new_n303_), .Y(new_n304_));
  AOI21x1_ASAP7_75t_R g283(.A1(new_n304_), .A2(new_n289_), .B(\totalcoeffs[4] ), .Y(new_n305_));
  OA21x2_ASAP7_75t_R  g284(.A1(new_n305_), .A2(new_n274_), .B(new_n23_), .Y(\coeff_token[3] ));
  NOR3x1_ASAP7_75t_R  g285(.A(new_n34_), .B(new_n31_), .C(\totalcoeffs[4] ), .Y(new_n307_));
  INVx1_ASAP7_75t_R   g286(.A(new_n144_), .Y(new_n308_));
  AND2x2_ASAP7_75t_R  g287(.A(new_n22_), .B(\totalcoeffs[3] ), .Y(new_n309_));
  OA21x2_ASAP7_75t_R  g288(.A1(new_n271_), .A2(new_n309_), .B(new_n308_), .Y(new_n310_));
  AND3x1_ASAP7_75t_R  g289(.A(new_n23_), .B(\ctable[0] ), .C(\ctable[1] ), .Y(new_n311_));
  OA21x2_ASAP7_75t_R  g290(.A1(new_n310_), .A2(new_n307_), .B(new_n311_), .Y(\coeff_token[4] ));
  AND3x1_ASAP7_75t_R  g291(.A(new_n144_), .B(\totalcoeffs[3] ), .C(new_n22_), .Y(new_n313_));
  AND3x1_ASAP7_75t_R  g292(.A(new_n271_), .B(new_n31_), .C(new_n34_), .Y(new_n314_));
  OA21x2_ASAP7_75t_R  g293(.A1(new_n314_), .A2(new_n313_), .B(new_n311_), .Y(\coeff_token[5] ));
  AND3x1_ASAP7_75t_R  g294(.A(new_n34_), .B(new_n85_), .C(\totalcoeffs[4] ), .Y(new_n316_));
  OA21x2_ASAP7_75t_R  g295(.A1(new_n316_), .A2(new_n109_), .B(new_n23_), .Y(new_n317_));
  NAND2x1_ASAP7_75t_R g296(.A(\ctable[2] ), .B(new_n28_), .Y(new_n318_));
  AOI21x1_ASAP7_75t_R g297(.A1(\trailingones[0] ), .A2(new_n318_), .B(new_n70_), .Y(new_n319_));
  OAI21x1_ASAP7_75t_R g298(.A1(new_n81_), .A2(new_n319_), .B(new_n38_), .Y(new_n320_));
  OA21x2_ASAP7_75t_R  g299(.A1(new_n196_), .A2(new_n39_), .B(new_n203_), .Y(new_n321_));
  OR3x1_ASAP7_75t_R   g300(.A(new_n321_), .B(\totalcoeffs[2] ), .C(new_n23_), .Y(new_n322_));
  AO21x1_ASAP7_75t_R  g301(.A1(new_n322_), .A2(new_n320_), .B(new_n257_), .Y(new_n323_));
  NOR2x1_ASAP7_75t_R  g302(.A(\totalcoeffs[1] ), .B(\ctable[0] ), .Y(new_n324_));
  OAI21x1_ASAP7_75t_R g303(.A1(new_n31_), .A2(new_n324_), .B(new_n104_), .Y(new_n325_));
  OR3x1_ASAP7_75t_R   g304(.A(new_n39_), .B(new_n24_), .C(new_n28_), .Y(new_n326_));
  AO21x1_ASAP7_75t_R  g305(.A1(new_n325_), .A2(new_n326_), .B(new_n38_), .Y(new_n327_));
  AND2x2_ASAP7_75t_R  g306(.A(new_n38_), .B(\totalcoeffs[2] ), .Y(new_n328_));
  NAND2x1_ASAP7_75t_R g307(.A(new_n328_), .B(new_n29_), .Y(new_n329_));
  AO21x1_ASAP7_75t_R  g308(.A1(new_n327_), .A2(new_n329_), .B(new_n59_), .Y(new_n330_));
  NAND2x1_ASAP7_75t_R g309(.A(\totalcoeffs[2] ), .B(\trailingones[0] ), .Y(new_n331_));
  AO21x1_ASAP7_75t_R  g310(.A1(new_n203_), .A2(new_n252_), .B(new_n77_), .Y(new_n332_));
  AO21x1_ASAP7_75t_R  g311(.A1(new_n132_), .A2(new_n331_), .B(new_n332_), .Y(new_n333_));
  OR3x1_ASAP7_75t_R   g312(.A(new_n31_), .B(new_n28_), .C(\totalcoeffs[0] ), .Y(new_n334_));
  AO21x1_ASAP7_75t_R  g313(.A1(new_n334_), .A2(new_n87_), .B(new_n24_), .Y(new_n335_));
  AND2x2_ASAP7_75t_R  g314(.A(new_n333_), .B(new_n335_), .Y(new_n336_));
  AO21x1_ASAP7_75t_R  g315(.A1(new_n330_), .A2(new_n336_), .B(\ctable[2] ), .Y(new_n337_));
  AO21x1_ASAP7_75t_R  g316(.A1(new_n337_), .A2(new_n323_), .B(\totalcoeffs[3] ), .Y(new_n338_));
  OR3x1_ASAP7_75t_R   g317(.A(new_n226_), .B(\totalcoeffs[0] ), .C(\ctable[1] ), .Y(new_n339_));
  AO21x1_ASAP7_75t_R  g318(.A1(new_n339_), .A2(new_n48_), .B(new_n210_), .Y(new_n340_));
  AO21x1_ASAP7_75t_R  g319(.A1(new_n59_), .A2(new_n28_), .B(\totalcoeffs[1] ), .Y(new_n341_));
  NAND2x1_ASAP7_75t_R g320(.A(\totalcoeffs[0] ), .B(new_n341_), .Y(new_n342_));
  AO21x1_ASAP7_75t_R  g321(.A1(\totalcoeffs[1] ), .A2(new_n28_), .B(new_n342_), .Y(new_n343_));
  AO21x1_ASAP7_75t_R  g322(.A1(new_n343_), .A2(new_n340_), .B(\ctable[0] ), .Y(new_n344_));
  AND3x1_ASAP7_75t_R  g323(.A(\totalcoeffs[0] ), .B(\ctable[1] ), .C(\trailingones[0] ), .Y(new_n345_));
  NAND2x1_ASAP7_75t_R g324(.A(new_n31_), .B(new_n345_), .Y(new_n346_));
  OA21x2_ASAP7_75t_R  g325(.A1(new_n89_), .A2(new_n328_), .B(new_n346_), .Y(new_n347_));
  NOR2x1_ASAP7_75t_R  g326(.A(\totalcoeffs[0] ), .B(\trailingones[0] ), .Y(new_n348_));
  OR3x1_ASAP7_75t_R   g327(.A(new_n157_), .B(new_n45_), .C(new_n348_), .Y(new_n349_));
  OA21x2_ASAP7_75t_R  g328(.A1(new_n347_), .A2(new_n28_), .B(new_n349_), .Y(new_n350_));
  AO21x1_ASAP7_75t_R  g329(.A1(new_n344_), .A2(new_n350_), .B(new_n51_), .Y(new_n351_));
  NOR2x1_ASAP7_75t_R  g330(.A(new_n331_), .B(new_n63_), .Y(new_n352_));
  AO21x1_ASAP7_75t_R  g331(.A1(new_n59_), .A2(\ctable[1] ), .B(\totalcoeffs[0] ), .Y(new_n353_));
  NOR2x1_ASAP7_75t_R  g332(.A(\totalcoeffs[2] ), .B(\trailingones[1] ), .Y(new_n354_));
  AND3x1_ASAP7_75t_R  g333(.A(new_n353_), .B(new_n301_), .C(new_n354_), .Y(new_n355_));
  OAI21x1_ASAP7_75t_R g334(.A1(new_n352_), .A2(new_n355_), .B(new_n39_), .Y(new_n356_));
  INVx1_ASAP7_75t_R   g335(.A(new_n276_), .Y(new_n357_));
  OR3x1_ASAP7_75t_R   g336(.A(new_n357_), .B(new_n64_), .C(new_n65_), .Y(new_n358_));
  AO21x1_ASAP7_75t_R  g337(.A1(new_n223_), .A2(new_n77_), .B(new_n63_), .Y(new_n359_));
  AO21x1_ASAP7_75t_R  g338(.A1(new_n358_), .A2(new_n359_), .B(\trailingones[0] ), .Y(new_n360_));
  OA21x2_ASAP7_75t_R  g339(.A1(\trailingones[0] ), .A2(\trailingones[1] ), .B(\totalcoeffs[2] ), .Y(new_n361_));
  OAI21x1_ASAP7_75t_R g340(.A1(new_n361_), .A2(new_n134_), .B(\ctable[1] ), .Y(new_n362_));
  AO21x1_ASAP7_75t_R  g341(.A1(new_n360_), .A2(new_n362_), .B(new_n39_), .Y(new_n363_));
  AND3x1_ASAP7_75t_R  g342(.A(new_n363_), .B(new_n351_), .C(new_n356_), .Y(new_n364_));
  OAI21x1_ASAP7_75t_R g343(.A1(\ctable[2] ), .A2(new_n364_), .B(new_n338_), .Y(new_n365_));
  AOI21x1_ASAP7_75t_R g344(.A1(new_n22_), .A2(new_n365_), .B(new_n317_), .Y(\ctoken_len[0] ));
  NAND2x1_ASAP7_75t_R g345(.A(\totalcoeffs[0] ), .B(\trailingones[0] ), .Y(new_n367_));
  AO21x1_ASAP7_75t_R  g346(.A1(\trailingones[0] ), .A2(\trailingones[1] ), .B(new_n51_), .Y(new_n368_));
  AO21x1_ASAP7_75t_R  g347(.A1(new_n368_), .A2(new_n367_), .B(\ctable[1] ), .Y(new_n369_));
  OR3x1_ASAP7_75t_R   g348(.A(new_n59_), .B(new_n28_), .C(\totalcoeffs[3] ), .Y(new_n370_));
  AOI21x1_ASAP7_75t_R g349(.A1(new_n370_), .A2(new_n369_), .B(new_n31_), .Y(new_n371_));
  OR3x1_ASAP7_75t_R   g350(.A(new_n103_), .B(\totalcoeffs[3] ), .C(\trailingones[0] ), .Y(new_n372_));
  OAI21x1_ASAP7_75t_R g351(.A1(new_n165_), .A2(new_n293_), .B(new_n240_), .Y(new_n373_));
  AOI21x1_ASAP7_75t_R g352(.A1(\ctable[1] ), .A2(\trailingones[1] ), .B(\trailingones[0] ), .Y(new_n374_));
  OAI21x1_ASAP7_75t_R g353(.A1(\ctable[1] ), .A2(new_n51_), .B(\totalcoeffs[0] ), .Y(new_n375_));
  AOI21x1_ASAP7_75t_R g354(.A1(new_n375_), .A2(new_n106_), .B(new_n374_), .Y(new_n376_));
  AOI21x1_ASAP7_75t_R g355(.A1(\trailingones[1] ), .A2(new_n373_), .B(new_n376_), .Y(new_n377_));
  OAI21x1_ASAP7_75t_R g356(.A1(\totalcoeffs[2] ), .A2(new_n377_), .B(new_n372_), .Y(new_n378_));
  OAI21x1_ASAP7_75t_R g357(.A1(new_n371_), .A2(new_n378_), .B(\totalcoeffs[1] ), .Y(new_n379_));
  OAI21x1_ASAP7_75t_R g358(.A1(new_n192_), .A2(new_n193_), .B(new_n125_), .Y(new_n380_));
  AO21x1_ASAP7_75t_R  g359(.A1(\trailingones[0] ), .A2(\trailingones[1] ), .B(\ctable[1] ), .Y(new_n381_));
  OAI21x1_ASAP7_75t_R g360(.A1(new_n75_), .A2(new_n381_), .B(new_n380_), .Y(new_n382_));
  AO21x1_ASAP7_75t_R  g361(.A1(new_n38_), .A2(new_n131_), .B(new_n345_), .Y(new_n383_));
  OA21x2_ASAP7_75t_R  g362(.A1(new_n151_), .A2(\ctable[1] ), .B(new_n361_), .Y(new_n384_));
  AO21x1_ASAP7_75t_R  g363(.A1(new_n383_), .A2(new_n28_), .B(new_n384_), .Y(new_n385_));
  AO21x1_ASAP7_75t_R  g364(.A1(new_n382_), .A2(\totalcoeffs[3] ), .B(new_n385_), .Y(new_n386_));
  AND3x1_ASAP7_75t_R  g365(.A(new_n107_), .B(\totalcoeffs[3] ), .C(new_n131_), .Y(new_n387_));
  AOI21x1_ASAP7_75t_R g366(.A1(new_n39_), .A2(new_n386_), .B(new_n387_), .Y(new_n388_));
  AOI21x1_ASAP7_75t_R g367(.A1(new_n388_), .A2(new_n379_), .B(\ctable[0] ), .Y(new_n389_));
  OR3x1_ASAP7_75t_R   g368(.A(new_n354_), .B(new_n38_), .C(new_n80_), .Y(new_n390_));
  OR3x1_ASAP7_75t_R   g369(.A(new_n24_), .B(\totalcoeffs[0] ), .C(\trailingones[1] ), .Y(new_n391_));
  AO21x1_ASAP7_75t_R  g370(.A1(new_n390_), .A2(new_n391_), .B(new_n59_), .Y(new_n392_));
  NAND2x1_ASAP7_75t_R g371(.A(new_n80_), .B(new_n145_), .Y(new_n393_));
  AOI21x1_ASAP7_75t_R g372(.A1(new_n393_), .A2(new_n392_), .B(\totalcoeffs[3] ), .Y(new_n394_));
  AND2x2_ASAP7_75t_R  g373(.A(\totalcoeffs[3] ), .B(\ctable[0] ), .Y(new_n395_));
  AO21x1_ASAP7_75t_R  g374(.A1(\totalcoeffs[2] ), .A2(new_n28_), .B(new_n395_), .Y(new_n396_));
  AND3x1_ASAP7_75t_R  g375(.A(new_n31_), .B(\totalcoeffs[3] ), .C(\ctable[0] ), .Y(new_n397_));
  AO21x1_ASAP7_75t_R  g376(.A1(new_n396_), .A2(new_n38_), .B(new_n397_), .Y(new_n398_));
  AND2x2_ASAP7_75t_R  g377(.A(new_n354_), .B(new_n395_), .Y(new_n399_));
  AO21x1_ASAP7_75t_R  g378(.A1(new_n398_), .A2(new_n59_), .B(new_n399_), .Y(new_n400_));
  OAI21x1_ASAP7_75t_R g379(.A1(new_n400_), .A2(new_n394_), .B(\totalcoeffs[1] ), .Y(new_n401_));
  OR3x1_ASAP7_75t_R   g380(.A(new_n203_), .B(new_n31_), .C(new_n53_), .Y(new_n402_));
  OA21x2_ASAP7_75t_R  g381(.A1(new_n31_), .A2(new_n51_), .B(new_n194_), .Y(new_n403_));
  AO21x1_ASAP7_75t_R  g382(.A1(new_n53_), .A2(new_n31_), .B(new_n24_), .Y(new_n404_));
  OA21x2_ASAP7_75t_R  g383(.A1(new_n403_), .A2(new_n404_), .B(new_n402_), .Y(new_n405_));
  INVx1_ASAP7_75t_R   g384(.A(new_n260_), .Y(new_n406_));
  OR3x1_ASAP7_75t_R   g385(.A(new_n406_), .B(new_n31_), .C(new_n51_), .Y(new_n407_));
  OA21x2_ASAP7_75t_R  g386(.A1(new_n405_), .A2(\totalcoeffs[1] ), .B(new_n407_), .Y(new_n408_));
  AOI21x1_ASAP7_75t_R g387(.A1(new_n408_), .A2(new_n401_), .B(\ctable[1] ), .Y(new_n409_));
  OAI21x1_ASAP7_75t_R g388(.A1(new_n409_), .A2(new_n389_), .B(new_n23_), .Y(new_n410_));
  NAND2x1_ASAP7_75t_R g389(.A(new_n328_), .B(new_n194_), .Y(new_n411_));
  OR3x1_ASAP7_75t_R   g390(.A(new_n32_), .B(new_n318_), .C(new_n59_), .Y(new_n412_));
  AND2x2_ASAP7_75t_R  g391(.A(new_n411_), .B(new_n412_), .Y(new_n413_));
  NAND2x1_ASAP7_75t_R g392(.A(new_n112_), .B(new_n256_), .Y(new_n414_));
  OAI21x1_ASAP7_75t_R g393(.A1(new_n413_), .A2(new_n414_), .B(new_n410_), .Y(new_n415_));
  INVx1_ASAP7_75t_R   g394(.A(new_n314_), .Y(new_n416_));
  OR3x1_ASAP7_75t_R   g395(.A(new_n416_), .B(\ctable[0] ), .C(\ctable[2] ), .Y(new_n417_));
  NOR2x1_ASAP7_75t_R  g396(.A(\ctable[1] ), .B(new_n417_), .Y(new_n418_));
  AOI21x1_ASAP7_75t_R g397(.A1(new_n22_), .A2(new_n415_), .B(new_n418_), .Y(\ctoken_len[1] ));
  AND2x2_ASAP7_75t_R  g398(.A(new_n51_), .B(\trailingones[1] ), .Y(new_n420_));
  AO21x1_ASAP7_75t_R  g399(.A1(\totalcoeffs[3] ), .A2(new_n24_), .B(new_n172_), .Y(new_n421_));
  AO21x1_ASAP7_75t_R  g400(.A1(new_n39_), .A2(new_n28_), .B(\totalcoeffs[2] ), .Y(new_n422_));
  OR3x1_ASAP7_75t_R   g401(.A(new_n421_), .B(new_n420_), .C(new_n422_), .Y(new_n423_));
  AO21x1_ASAP7_75t_R  g402(.A1(new_n92_), .A2(new_n276_), .B(new_n242_), .Y(new_n424_));
  AND2x2_ASAP7_75t_R  g403(.A(new_n51_), .B(\totalcoeffs[2] ), .Y(new_n425_));
  OA21x2_ASAP7_75t_R  g404(.A1(new_n210_), .A2(new_n324_), .B(new_n425_), .Y(new_n426_));
  AOI21x1_ASAP7_75t_R g405(.A1(new_n38_), .A2(new_n424_), .B(new_n426_), .Y(new_n427_));
  AO21x1_ASAP7_75t_R  g406(.A1(new_n427_), .A2(new_n423_), .B(\trailingones[0] ), .Y(new_n428_));
  NAND3x1_ASAP7_75t_R g407(.A(new_n112_), .B(new_n24_), .C(\totalcoeffs[0] ), .Y(new_n429_));
  AO21x1_ASAP7_75t_R  g408(.A1(new_n38_), .A2(new_n51_), .B(\totalcoeffs[2] ), .Y(new_n430_));
  OA21x2_ASAP7_75t_R  g409(.A1(new_n421_), .A2(new_n430_), .B(new_n429_), .Y(new_n431_));
  AO21x1_ASAP7_75t_R  g410(.A1(\totalcoeffs[3] ), .A2(\ctable[0] ), .B(new_n48_), .Y(new_n432_));
  AO21x1_ASAP7_75t_R  g411(.A1(new_n24_), .A2(new_n165_), .B(new_n432_), .Y(new_n433_));
  OAI21x1_ASAP7_75t_R g412(.A1(new_n59_), .A2(new_n431_), .B(new_n433_), .Y(new_n434_));
  AO21x1_ASAP7_75t_R  g413(.A1(\totalcoeffs[2] ), .A2(new_n24_), .B(new_n395_), .Y(new_n435_));
  AND3x1_ASAP7_75t_R  g414(.A(new_n435_), .B(\totalcoeffs[1] ), .C(new_n221_), .Y(new_n436_));
  AND3x1_ASAP7_75t_R  g415(.A(new_n183_), .B(new_n173_), .C(new_n116_), .Y(new_n437_));
  OA21x2_ASAP7_75t_R  g416(.A1(new_n436_), .A2(new_n437_), .B(\trailingones[1] ), .Y(new_n438_));
  AOI21x1_ASAP7_75t_R g417(.A1(new_n28_), .A2(new_n434_), .B(new_n438_), .Y(new_n439_));
  AO21x1_ASAP7_75t_R  g418(.A1(new_n439_), .A2(new_n428_), .B(\ctable[1] ), .Y(new_n440_));
  AND2x2_ASAP7_75t_R  g419(.A(new_n89_), .B(new_n77_), .Y(new_n441_));
  AO21x1_ASAP7_75t_R  g420(.A1(new_n166_), .A2(new_n45_), .B(new_n208_), .Y(new_n442_));
  AO21x1_ASAP7_75t_R  g421(.A1(new_n442_), .A2(new_n31_), .B(new_n281_), .Y(new_n443_));
  AO21x1_ASAP7_75t_R  g422(.A1(new_n342_), .A2(new_n441_), .B(new_n443_), .Y(new_n444_));
  AOI21x1_ASAP7_75t_R g423(.A1(new_n444_), .A2(new_n440_), .B(\ctable[2] ), .Y(new_n445_));
  AO21x1_ASAP7_75t_R  g424(.A1(new_n132_), .A2(new_n331_), .B(\totalcoeffs[0] ), .Y(new_n446_));
  AO21x1_ASAP7_75t_R  g425(.A1(new_n446_), .A2(new_n156_), .B(\trailingones[1] ), .Y(new_n447_));
  OR2x4_ASAP7_75t_R   g426(.A(\trailingones[0] ), .B(new_n334_), .Y(new_n448_));
  AO21x1_ASAP7_75t_R  g427(.A1(new_n447_), .A2(new_n448_), .B(\totalcoeffs[1] ), .Y(new_n449_));
  OR3x1_ASAP7_75t_R   g428(.A(new_n132_), .B(\totalcoeffs[0] ), .C(new_n299_), .Y(new_n450_));
  AOI21x1_ASAP7_75t_R g429(.A1(new_n450_), .A2(new_n449_), .B(new_n189_), .Y(new_n451_));
  OAI21x1_ASAP7_75t_R g430(.A1(new_n451_), .A2(new_n445_), .B(new_n22_), .Y(new_n452_));
  AND2x2_ASAP7_75t_R  g431(.A(new_n452_), .B(new_n417_), .Y(\ctoken_len[2] ));
  AO21x1_ASAP7_75t_R  g432(.A1(\ctable[1] ), .A2(\trailingones[1] ), .B(new_n51_), .Y(new_n454_));
  AO21x1_ASAP7_75t_R  g433(.A1(new_n166_), .A2(new_n300_), .B(new_n454_), .Y(new_n455_));
  OR3x1_ASAP7_75t_R   g434(.A(new_n256_), .B(\totalcoeffs[3] ), .C(new_n22_), .Y(new_n456_));
  AND3x1_ASAP7_75t_R  g435(.A(new_n455_), .B(new_n31_), .C(new_n456_), .Y(new_n457_));
  AND3x1_ASAP7_75t_R  g436(.A(new_n203_), .B(new_n425_), .C(new_n270_), .Y(new_n458_));
  OAI21x1_ASAP7_75t_R g437(.A1(new_n458_), .A2(new_n457_), .B(new_n39_), .Y(new_n459_));
  AO21x1_ASAP7_75t_R  g438(.A1(new_n24_), .A2(new_n28_), .B(\totalcoeffs[3] ), .Y(new_n460_));
  AO21x1_ASAP7_75t_R  g439(.A1(\totalcoeffs[3] ), .A2(new_n119_), .B(new_n165_), .Y(new_n461_));
  AO21x1_ASAP7_75t_R  g440(.A1(new_n461_), .A2(new_n460_), .B(\totalcoeffs[2] ), .Y(new_n462_));
  AO21x1_ASAP7_75t_R  g441(.A1(new_n406_), .A2(new_n77_), .B(\totalcoeffs[3] ), .Y(new_n463_));
  OA21x2_ASAP7_75t_R  g442(.A1(new_n270_), .A2(new_n290_), .B(new_n463_), .Y(new_n464_));
  AO21x1_ASAP7_75t_R  g443(.A1(new_n464_), .A2(new_n462_), .B(new_n39_), .Y(new_n465_));
  INVx1_ASAP7_75t_R   g444(.A(new_n341_), .Y(new_n466_));
  OA21x2_ASAP7_75t_R  g445(.A1(new_n158_), .A2(new_n290_), .B(new_n23_), .Y(new_n467_));
  AO21x1_ASAP7_75t_R  g446(.A1(new_n247_), .A2(new_n23_), .B(new_n38_), .Y(new_n468_));
  AO21x1_ASAP7_75t_R  g447(.A1(new_n90_), .A2(new_n24_), .B(new_n77_), .Y(new_n469_));
  AO21x1_ASAP7_75t_R  g448(.A1(new_n112_), .A2(new_n31_), .B(new_n22_), .Y(new_n470_));
  OA21x2_ASAP7_75t_R  g449(.A1(new_n23_), .A2(new_n425_), .B(new_n470_), .Y(new_n471_));
  AND3x1_ASAP7_75t_R  g450(.A(new_n471_), .B(new_n468_), .C(new_n469_), .Y(new_n472_));
  OA21x2_ASAP7_75t_R  g451(.A1(new_n466_), .A2(new_n467_), .B(new_n472_), .Y(new_n473_));
  AND3x1_ASAP7_75t_R  g452(.A(new_n459_), .B(new_n465_), .C(new_n473_), .Y(\ctoken_len[3] ));
  AND3x1_ASAP7_75t_R  g453(.A(new_n309_), .B(\totalcoeffs[2] ), .C(new_n44_), .Y(new_n475_));
  OA21x2_ASAP7_75t_R  g454(.A1(new_n59_), .A2(new_n74_), .B(new_n475_), .Y(new_n476_));
  AO21x1_ASAP7_75t_R  g455(.A1(new_n308_), .A2(new_n271_), .B(new_n476_), .Y(new_n477_));
  AND3x1_ASAP7_75t_R  g456(.A(new_n477_), .B(new_n23_), .C(new_n256_), .Y(\ctoken_len[4] ));
endmodule


