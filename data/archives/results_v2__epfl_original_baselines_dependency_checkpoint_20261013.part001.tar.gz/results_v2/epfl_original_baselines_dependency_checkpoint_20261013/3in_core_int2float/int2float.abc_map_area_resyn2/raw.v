// Benchmark "/home/flynn/workplace/MIGBalance/results_v2/epfl_original_baselines_dependency_checkpoint_20261013/3in_core_int2float/int2float.resyn2" written by ABC on Tue Oct 13 14:23:44 2026

module \/home/flynn/workplace/MIGBalance/results_v2/epfl_original_baselines_dependency_checkpoint_20261013/3in_core_int2float/int2float.resyn2  ( 
    \B[0] , \B[1] , \B[2] , \B[3] , \B[4] , \B[5] , \B[6] , \B[7] , \B[8] ,
    \B[9] , \B[10] ,
    \M[0] , \M[1] , \M[2] , \M[3] , \E[0] , \E[1] , \E[2]   );
  input  \B[0] , \B[1] , \B[2] , \B[3] , \B[4] , \B[5] , \B[6] , \B[7] ,
    \B[8] , \B[9] , \B[10] ;
  output \M[0] , \M[1] , \M[2] , \M[3] , \E[0] , \E[1] , \E[2] ;
  wire new_n19_, new_n20_, new_n21_, new_n22_, new_n23_, new_n24_, new_n25_,
    new_n26_, new_n27_, new_n28_, new_n29_, new_n30_, new_n31_, new_n32_,
    new_n33_, new_n34_, new_n35_, new_n36_, new_n37_, new_n38_, new_n39_,
    new_n40_, new_n41_, new_n42_, new_n43_, new_n44_, new_n45_, new_n46_,
    new_n47_, new_n48_, new_n49_, new_n50_, new_n51_, new_n52_, new_n53_,
    new_n54_, new_n55_, new_n56_, new_n57_, new_n58_, new_n59_, new_n60_,
    new_n61_, new_n62_, new_n64_, new_n65_, new_n66_, new_n67_, new_n68_,
    new_n69_, new_n70_, new_n71_, new_n72_, new_n73_, new_n74_, new_n75_,
    new_n76_, new_n77_, new_n78_, new_n79_, new_n80_, new_n81_, new_n82_,
    new_n83_, new_n84_, new_n85_, new_n86_, new_n87_, new_n88_, new_n89_,
    new_n90_, new_n91_, new_n92_, new_n93_, new_n94_, new_n95_, new_n96_,
    new_n97_, new_n98_, new_n99_, new_n100_, new_n101_, new_n102_,
    new_n103_, new_n105_, new_n106_, new_n107_, new_n108_, new_n109_,
    new_n110_, new_n111_, new_n112_, new_n113_, new_n114_, new_n115_,
    new_n116_, new_n117_, new_n118_, new_n119_, new_n120_, new_n121_,
    new_n122_, new_n123_, new_n124_, new_n125_, new_n126_, new_n127_,
    new_n128_, new_n129_, new_n130_, new_n131_, new_n132_, new_n133_,
    new_n134_, new_n135_, new_n137_, new_n138_, new_n139_, new_n140_,
    new_n141_, new_n142_, new_n144_, new_n145_, new_n146_, new_n147_,
    new_n148_, new_n149_, new_n150_, new_n151_, new_n152_, new_n153_,
    new_n154_, new_n155_, new_n156_, new_n157_, new_n159_, new_n160_,
    new_n161_, new_n162_, new_n163_, new_n164_, new_n165_, new_n166_;
  INVx1_ASAP7_75t_R   g000(.A(\B[10] ), .Y(new_n19_));
  INVx1_ASAP7_75t_R   g001(.A(\B[5] ), .Y(new_n20_));
  AND2x2_ASAP7_75t_R  g002(.A(\B[4] ), .B(\B[8] ), .Y(new_n21_));
  INVx1_ASAP7_75t_R   g003(.A(\B[4] ), .Y(new_n22_));
  AND2x2_ASAP7_75t_R  g004(.A(\B[1] ), .B(\B[4] ), .Y(new_n23_));
  AO21x1_ASAP7_75t_R  g005(.A1(new_n22_), .A2(\B[8] ), .B(new_n23_), .Y(new_n24_));
  NOR2x1_ASAP7_75t_R  g006(.A(\B[0] ), .B(new_n23_), .Y(new_n25_));
  OR3x1_ASAP7_75t_R   g007(.A(new_n25_), .B(\B[6] ), .C(\B[7] ), .Y(new_n26_));
  AOI21x1_ASAP7_75t_R g008(.A1(\B[0] ), .A2(new_n24_), .B(new_n26_), .Y(new_n27_));
  OAI21x1_ASAP7_75t_R g009(.A1(new_n21_), .A2(new_n27_), .B(new_n20_), .Y(new_n28_));
  INVx1_ASAP7_75t_R   g010(.A(\B[8] ), .Y(new_n29_));
  AND2x2_ASAP7_75t_R  g011(.A(new_n22_), .B(\B[7] ), .Y(new_n30_));
  NOR2x1_ASAP7_75t_R  g012(.A(\B[2] ), .B(\B[7] ), .Y(new_n31_));
  AND3x1_ASAP7_75t_R  g013(.A(new_n31_), .B(\B[1] ), .C(\B[5] ), .Y(new_n32_));
  OA21x2_ASAP7_75t_R  g014(.A1(new_n32_), .A2(new_n30_), .B(\B[3] ), .Y(new_n33_));
  INVx1_ASAP7_75t_R   g015(.A(\B[3] ), .Y(new_n34_));
  AND2x2_ASAP7_75t_R  g016(.A(new_n34_), .B(\B[4] ), .Y(new_n35_));
  AO21x1_ASAP7_75t_R  g017(.A1(\B[7] ), .A2(new_n35_), .B(new_n33_), .Y(new_n36_));
  NAND2x1_ASAP7_75t_R g018(.A(new_n29_), .B(new_n36_), .Y(new_n37_));
  OR3x1_ASAP7_75t_R   g019(.A(new_n20_), .B(new_n29_), .C(\B[4] ), .Y(new_n38_));
  AND3x1_ASAP7_75t_R  g020(.A(new_n28_), .B(new_n37_), .C(new_n38_), .Y(new_n39_));
  INVx1_ASAP7_75t_R   g021(.A(\B[6] ), .Y(new_n40_));
  INVx1_ASAP7_75t_R   g022(.A(\B[9] ), .Y(new_n41_));
  OR3x1_ASAP7_75t_R   g023(.A(new_n40_), .B(new_n41_), .C(\B[5] ), .Y(new_n42_));
  INVx1_ASAP7_75t_R   g024(.A(\B[1] ), .Y(new_n43_));
  OR3x1_ASAP7_75t_R   g025(.A(new_n30_), .B(new_n43_), .C(\B[2] ), .Y(new_n44_));
  AND2x2_ASAP7_75t_R  g026(.A(\B[3] ), .B(\B[4] ), .Y(new_n45_));
  OR3x1_ASAP7_75t_R   g027(.A(new_n44_), .B(new_n21_), .C(new_n45_), .Y(new_n46_));
  INVx1_ASAP7_75t_R   g028(.A(\B[2] ), .Y(new_n47_));
  NOR2x1_ASAP7_75t_R  g029(.A(\B[7] ), .B(\B[8] ), .Y(new_n48_));
  INVx1_ASAP7_75t_R   g030(.A(new_n48_), .Y(new_n49_));
  OR3x1_ASAP7_75t_R   g031(.A(new_n49_), .B(\B[1] ), .C(new_n47_), .Y(new_n50_));
  AND3x1_ASAP7_75t_R  g032(.A(new_n46_), .B(new_n41_), .C(new_n50_), .Y(new_n51_));
  OR3x1_ASAP7_75t_R   g033(.A(new_n51_), .B(new_n20_), .C(\B[6] ), .Y(new_n52_));
  AND2x2_ASAP7_75t_R  g034(.A(new_n52_), .B(new_n42_), .Y(new_n53_));
  OAI21x1_ASAP7_75t_R g035(.A1(\B[9] ), .A2(new_n39_), .B(new_n53_), .Y(new_n54_));
  AND3x1_ASAP7_75t_R  g036(.A(new_n40_), .B(\B[7] ), .C(\B[10] ), .Y(new_n55_));
  INVx1_ASAP7_75t_R   g037(.A(\B[7] ), .Y(new_n56_));
  XOR2x2_ASAP7_75t_R  g038(.A(\B[2] ), .B(\B[3] ), .Y(new_n57_));
  NOR2x1_ASAP7_75t_R  g039(.A(\B[8] ), .B(\B[9] ), .Y(new_n58_));
  AO21x1_ASAP7_75t_R  g040(.A1(new_n57_), .A2(new_n58_), .B(\B[10] ), .Y(new_n59_));
  AND3x1_ASAP7_75t_R  g041(.A(\B[8] ), .B(\B[9] ), .C(\B[10] ), .Y(new_n60_));
  AO21x1_ASAP7_75t_R  g042(.A1(new_n59_), .A2(new_n56_), .B(new_n60_), .Y(new_n61_));
  AO21x1_ASAP7_75t_R  g043(.A1(new_n61_), .A2(\B[6] ), .B(new_n55_), .Y(new_n62_));
  AO21x1_ASAP7_75t_R  g044(.A1(new_n54_), .A2(new_n19_), .B(new_n62_), .Y(\M[0] ));
  OA21x2_ASAP7_75t_R  g045(.A1(new_n43_), .A2(new_n47_), .B(\B[0] ), .Y(new_n64_));
  NOR2x1_ASAP7_75t_R  g046(.A(\B[0] ), .B(new_n47_), .Y(new_n65_));
  OR3x1_ASAP7_75t_R   g047(.A(new_n65_), .B(new_n22_), .C(\B[7] ), .Y(new_n66_));
  AO21x1_ASAP7_75t_R  g048(.A1(new_n22_), .A2(new_n41_), .B(new_n31_), .Y(new_n67_));
  NAND2x1_ASAP7_75t_R g049(.A(new_n43_), .B(new_n67_), .Y(new_n68_));
  OA21x2_ASAP7_75t_R  g050(.A1(new_n29_), .A2(\B[9] ), .B(new_n68_), .Y(new_n69_));
  OAI21x1_ASAP7_75t_R g051(.A1(new_n64_), .A2(new_n66_), .B(new_n69_), .Y(new_n70_));
  INVx1_ASAP7_75t_R   g052(.A(new_n45_), .Y(new_n71_));
  AND2x2_ASAP7_75t_R  g053(.A(new_n56_), .B(\B[9] ), .Y(new_n72_));
  AND3x1_ASAP7_75t_R  g054(.A(new_n29_), .B(new_n41_), .C(\B[7] ), .Y(new_n73_));
  AO21x1_ASAP7_75t_R  g055(.A1(new_n73_), .A2(new_n71_), .B(new_n72_), .Y(new_n74_));
  AO21x1_ASAP7_75t_R  g056(.A1(new_n70_), .A2(new_n40_), .B(new_n74_), .Y(new_n75_));
  AND2x2_ASAP7_75t_R  g057(.A(\B[1] ), .B(\B[2] ), .Y(new_n76_));
  NOR2x1_ASAP7_75t_R  g058(.A(\B[4] ), .B(\B[6] ), .Y(new_n77_));
  AND3x1_ASAP7_75t_R  g059(.A(new_n77_), .B(new_n56_), .C(new_n76_), .Y(new_n78_));
  AO21x1_ASAP7_75t_R  g060(.A1(\B[1] ), .A2(\B[2] ), .B(\B[7] ), .Y(new_n79_));
  AND3x1_ASAP7_75t_R  g061(.A(new_n58_), .B(\B[4] ), .C(new_n79_), .Y(new_n80_));
  NOR2x1_ASAP7_75t_R  g062(.A(new_n78_), .B(new_n80_), .Y(new_n81_));
  AO21x1_ASAP7_75t_R  g063(.A1(new_n22_), .A2(new_n41_), .B(new_n72_), .Y(new_n82_));
  OR3x1_ASAP7_75t_R   g064(.A(new_n82_), .B(new_n40_), .C(new_n58_), .Y(new_n83_));
  OAI21x1_ASAP7_75t_R g065(.A1(new_n34_), .A2(new_n81_), .B(new_n83_), .Y(new_n84_));
  AND3x1_ASAP7_75t_R  g066(.A(new_n22_), .B(new_n41_), .C(\B[8] ), .Y(new_n85_));
  OA21x2_ASAP7_75t_R  g067(.A1(new_n85_), .A2(new_n72_), .B(new_n40_), .Y(new_n86_));
  AO21x1_ASAP7_75t_R  g068(.A1(new_n84_), .A2(\B[5] ), .B(new_n86_), .Y(new_n87_));
  AO21x1_ASAP7_75t_R  g069(.A1(new_n75_), .A2(new_n20_), .B(new_n87_), .Y(new_n88_));
  AND2x2_ASAP7_75t_R  g070(.A(\B[8] ), .B(\B[10] ), .Y(new_n89_));
  AND2x2_ASAP7_75t_R  g071(.A(\B[6] ), .B(\B[7] ), .Y(new_n90_));
  AND3x1_ASAP7_75t_R  g072(.A(new_n89_), .B(new_n90_), .C(new_n41_), .Y(new_n91_));
  AND3x1_ASAP7_75t_R  g073(.A(new_n22_), .B(new_n41_), .C(\B[6] ), .Y(new_n92_));
  AND3x1_ASAP7_75t_R  g074(.A(new_n43_), .B(new_n40_), .C(\B[5] ), .Y(new_n93_));
  OAI21x1_ASAP7_75t_R g075(.A1(new_n92_), .A2(new_n93_), .B(new_n34_), .Y(new_n94_));
  AND2x2_ASAP7_75t_R  g076(.A(new_n34_), .B(\B[5] ), .Y(new_n95_));
  AO21x1_ASAP7_75t_R  g077(.A1(new_n40_), .A2(new_n95_), .B(new_n92_), .Y(new_n96_));
  NAND2x1_ASAP7_75t_R g078(.A(new_n47_), .B(new_n96_), .Y(new_n97_));
  NAND2x1_ASAP7_75t_R g079(.A(\B[6] ), .B(new_n41_), .Y(new_n98_));
  OR3x1_ASAP7_75t_R   g080(.A(new_n71_), .B(new_n98_), .C(new_n47_), .Y(new_n99_));
  AND3x1_ASAP7_75t_R  g081(.A(new_n97_), .B(new_n94_), .C(new_n99_), .Y(new_n100_));
  OAI21x1_ASAP7_75t_R g082(.A1(\B[7] ), .A2(new_n100_), .B(new_n19_), .Y(new_n101_));
  NOR2x1_ASAP7_75t_R  g083(.A(\B[8] ), .B(new_n90_), .Y(new_n102_));
  AO21x1_ASAP7_75t_R  g084(.A1(new_n101_), .A2(new_n102_), .B(new_n91_), .Y(new_n103_));
  AOI21x1_ASAP7_75t_R g085(.A1(new_n19_), .A2(new_n88_), .B(new_n103_), .Y(\M[1] ));
  AND2x2_ASAP7_75t_R  g086(.A(new_n40_), .B(\B[0] ), .Y(new_n105_));
  AND3x1_ASAP7_75t_R  g087(.A(new_n22_), .B(\B[3] ), .C(\B[5] ), .Y(new_n106_));
  AO21x1_ASAP7_75t_R  g088(.A1(new_n35_), .A2(new_n105_), .B(new_n106_), .Y(new_n107_));
  AND2x2_ASAP7_75t_R  g089(.A(\B[0] ), .B(\B[1] ), .Y(new_n108_));
  NOR2x1_ASAP7_75t_R  g090(.A(new_n108_), .B(new_n71_), .Y(new_n109_));
  OA21x2_ASAP7_75t_R  g091(.A1(new_n109_), .A2(new_n77_), .B(new_n20_), .Y(new_n110_));
  AO21x1_ASAP7_75t_R  g092(.A1(new_n107_), .A2(\B[1] ), .B(new_n110_), .Y(new_n111_));
  AND3x1_ASAP7_75t_R  g093(.A(new_n47_), .B(new_n40_), .C(\B[3] ), .Y(new_n112_));
  OA21x2_ASAP7_75t_R  g094(.A1(new_n112_), .A2(new_n95_), .B(\B[4] ), .Y(new_n113_));
  AO21x1_ASAP7_75t_R  g095(.A1(new_n111_), .A2(\B[2] ), .B(new_n113_), .Y(new_n114_));
  AND2x2_ASAP7_75t_R  g096(.A(\B[5] ), .B(\B[6] ), .Y(new_n115_));
  AND3x1_ASAP7_75t_R  g097(.A(new_n20_), .B(\B[2] ), .C(\B[6] ), .Y(new_n116_));
  OA21x2_ASAP7_75t_R  g098(.A1(new_n93_), .A2(new_n116_), .B(new_n45_), .Y(new_n117_));
  AO21x1_ASAP7_75t_R  g099(.A1(new_n71_), .A2(new_n115_), .B(new_n117_), .Y(new_n118_));
  AO21x1_ASAP7_75t_R  g100(.A1(new_n114_), .A2(new_n56_), .B(new_n118_), .Y(new_n119_));
  AND2x2_ASAP7_75t_R  g101(.A(\B[4] ), .B(\B[5] ), .Y(new_n120_));
  OA21x2_ASAP7_75t_R  g102(.A1(new_n22_), .A2(new_n20_), .B(new_n90_), .Y(new_n121_));
  AND3x1_ASAP7_75t_R  g103(.A(new_n40_), .B(\B[3] ), .C(\B[7] ), .Y(new_n122_));
  AND2x2_ASAP7_75t_R  g104(.A(new_n56_), .B(\B[6] ), .Y(new_n123_));
  AO21x1_ASAP7_75t_R  g105(.A1(new_n47_), .A2(new_n123_), .B(new_n122_), .Y(new_n124_));
  AO21x1_ASAP7_75t_R  g106(.A1(new_n124_), .A2(new_n120_), .B(new_n121_), .Y(new_n125_));
  AO21x1_ASAP7_75t_R  g107(.A1(new_n119_), .A2(new_n29_), .B(new_n125_), .Y(new_n126_));
  AND2x2_ASAP7_75t_R  g108(.A(new_n40_), .B(\B[7] ), .Y(new_n127_));
  AND3x1_ASAP7_75t_R  g109(.A(new_n120_), .B(\B[6] ), .C(new_n56_), .Y(new_n128_));
  OA21x2_ASAP7_75t_R  g110(.A1(new_n128_), .A2(new_n127_), .B(\B[8] ), .Y(new_n129_));
  AO21x1_ASAP7_75t_R  g111(.A1(new_n126_), .A2(new_n41_), .B(new_n129_), .Y(new_n130_));
  AND2x2_ASAP7_75t_R  g112(.A(new_n29_), .B(\B[5] ), .Y(new_n131_));
  AO21x1_ASAP7_75t_R  g113(.A1(new_n131_), .A2(\B[9] ), .B(new_n89_), .Y(new_n132_));
  OA21x2_ASAP7_75t_R  g114(.A1(new_n20_), .A2(new_n56_), .B(\B[8] ), .Y(new_n133_));
  OA21x2_ASAP7_75t_R  g115(.A1(new_n133_), .A2(\B[10] ), .B(\B[9] ), .Y(new_n134_));
  AO21x1_ASAP7_75t_R  g116(.A1(new_n132_), .A2(new_n90_), .B(new_n134_), .Y(new_n135_));
  AO21x1_ASAP7_75t_R  g117(.A1(new_n130_), .A2(new_n19_), .B(new_n135_), .Y(\M[2] ));
  AND3x1_ASAP7_75t_R  g118(.A(\B[5] ), .B(\B[6] ), .C(\B[7] ), .Y(new_n137_));
  AND3x1_ASAP7_75t_R  g119(.A(new_n137_), .B(new_n47_), .C(new_n21_), .Y(new_n138_));
  AND3x1_ASAP7_75t_R  g120(.A(new_n22_), .B(new_n56_), .C(new_n29_), .Y(new_n139_));
  AND3x1_ASAP7_75t_R  g121(.A(new_n139_), .B(new_n20_), .C(new_n40_), .Y(new_n140_));
  NOR2x1_ASAP7_75t_R  g122(.A(new_n138_), .B(new_n140_), .Y(new_n141_));
  NAND2x1_ASAP7_75t_R g123(.A(new_n41_), .B(new_n19_), .Y(new_n142_));
  OR3x1_ASAP7_75t_R   g124(.A(new_n141_), .B(\B[3] ), .C(new_n142_), .Y(\M[3] ));
  AO21x1_ASAP7_75t_R  g125(.A1(new_n76_), .A2(new_n56_), .B(new_n115_), .Y(new_n144_));
  NOR2x1_ASAP7_75t_R  g126(.A(\B[5] ), .B(\B[7] ), .Y(new_n145_));
  AO21x1_ASAP7_75t_R  g127(.A1(new_n144_), .A2(\B[3] ), .B(new_n145_), .Y(new_n146_));
  AO21x1_ASAP7_75t_R  g128(.A1(new_n146_), .A2(\B[4] ), .B(new_n123_), .Y(new_n147_));
  AND3x1_ASAP7_75t_R  g129(.A(new_n108_), .B(new_n20_), .C(new_n40_), .Y(new_n148_));
  NOR2x1_ASAP7_75t_R  g130(.A(new_n128_), .B(new_n148_), .Y(new_n149_));
  OR3x1_ASAP7_75t_R   g131(.A(new_n149_), .B(new_n47_), .C(new_n34_), .Y(new_n150_));
  AO21x1_ASAP7_75t_R  g132(.A1(new_n150_), .A2(new_n147_), .B(\B[8] ), .Y(new_n151_));
  AND3x1_ASAP7_75t_R  g133(.A(new_n115_), .B(\B[7] ), .C(\B[8] ), .Y(new_n152_));
  AND2x2_ASAP7_75t_R  g134(.A(\B[3] ), .B(\B[8] ), .Y(new_n153_));
  AO21x1_ASAP7_75t_R  g135(.A1(\B[2] ), .A2(new_n34_), .B(new_n153_), .Y(new_n154_));
  AND3x1_ASAP7_75t_R  g136(.A(new_n90_), .B(new_n120_), .C(new_n41_), .Y(new_n155_));
  NAND2x1_ASAP7_75t_R g137(.A(new_n154_), .B(new_n155_), .Y(new_n156_));
  OA21x2_ASAP7_75t_R  g138(.A1(new_n41_), .A2(new_n152_), .B(new_n156_), .Y(new_n157_));
  AO21x1_ASAP7_75t_R  g139(.A1(new_n151_), .A2(new_n157_), .B(\B[10] ), .Y(\E[0] ));
  AND3x1_ASAP7_75t_R  g140(.A(new_n108_), .B(\B[3] ), .C(new_n29_), .Y(new_n159_));
  AO21x1_ASAP7_75t_R  g141(.A1(new_n159_), .A2(new_n145_), .B(new_n152_), .Y(new_n160_));
  AND3x1_ASAP7_75t_R  g142(.A(new_n115_), .B(new_n153_), .C(\B[7] ), .Y(new_n161_));
  AO21x1_ASAP7_75t_R  g143(.A1(new_n160_), .A2(\B[2] ), .B(new_n161_), .Y(new_n162_));
  AND3x1_ASAP7_75t_R  g144(.A(new_n45_), .B(new_n115_), .C(\B[2] ), .Y(new_n163_));
  INVx1_ASAP7_75t_R   g145(.A(new_n163_), .Y(new_n164_));
  OA21x2_ASAP7_75t_R  g146(.A1(\B[5] ), .A2(\B[6] ), .B(new_n48_), .Y(new_n165_));
  AO21x1_ASAP7_75t_R  g147(.A1(new_n164_), .A2(new_n165_), .B(new_n142_), .Y(new_n166_));
  AO21x1_ASAP7_75t_R  g148(.A1(new_n162_), .A2(\B[4] ), .B(new_n166_), .Y(\E[1] ));
  OR3x1_ASAP7_75t_R   g149(.A(new_n163_), .B(new_n49_), .C(new_n142_), .Y(\E[2] ));
endmodule


