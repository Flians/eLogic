// Benchmark "/tmp/" written by ABC on Tue Oct 13 13:56:40 2026

module \/tmp/  ( 
    p0, p5, p1, p4, p3, p6, p7, p2,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25, o26, o27, o28, o29,
    o30, o31, o32, o33, o34, o35, o36, o37, o38, o39, o40, o41, o42, o43,
    o44, o45, o46, o47, o48, o49, o50, o51, o52, o53, o54, o55, o56, o57,
    o58, o59, o60, o61, o62, o63, o64, o65, o66, o67, o68, o69, o70, o71,
    o72, o73, o74, o75, o76, o77, o78, o79, o80, o81, o82, o83, o84, o85,
    o86, o87, o88, o89, o90, o91, o92, o93, o94, o95, o96, o97, o98, o99,
    o100, o101, o102, o103, o104, o105, o106, o107, o108, o109, o110, o111,
    o112, o113, o114, o115, o116, o117, o118, o119, o120, o121, o122, o123,
    o124, o125, o126, o127, o128, o129, o130, o131, o132, o133, o134, o135,
    o136, o137, o138, o139, o140, o141, o142, o143, o144, o145, o146, o147,
    o148, o149, o150, o151, o152, o153, o154, o155, o156, o157, o158, o159,
    o160, o161, o162, o163, o164, o165, o166, o167, o168, o169, o170, o171,
    o172, o173, o174, o175, o176, o177, o178, o179, o180, o181, o182, o183,
    o184, o185, o186, o187, o188, o189, o190, o191, o192, o193, o194, o195,
    o196, o197, o198, o199, o200, o201, o202, o203, o204, o205, o206, o207,
    o208, o209, o210, o211, o212, o213, o214, o215, o216, o217, o218, o219,
    o220, o221, o222, o223, o224, o225, o226, o227, o228, o229, o230, o231,
    o232, o233, o234, o235, o236, o237, o238, o239, o240, o241, o242, o243,
    o244, o245, o246, o247, o248, o249, o250, o251, o252, o253, o254, o255  );
  input  p0, p5, p1, p4, p3, p6, p7, p2;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25, o26, o27, o28, o29,
    o30, o31, o32, o33, o34, o35, o36, o37, o38, o39, o40, o41, o42, o43,
    o44, o45, o46, o47, o48, o49, o50, o51, o52, o53, o54, o55, o56, o57,
    o58, o59, o60, o61, o62, o63, o64, o65, o66, o67, o68, o69, o70, o71,
    o72, o73, o74, o75, o76, o77, o78, o79, o80, o81, o82, o83, o84, o85,
    o86, o87, o88, o89, o90, o91, o92, o93, o94, o95, o96, o97, o98, o99,
    o100, o101, o102, o103, o104, o105, o106, o107, o108, o109, o110, o111,
    o112, o113, o114, o115, o116, o117, o118, o119, o120, o121, o122, o123,
    o124, o125, o126, o127, o128, o129, o130, o131, o132, o133, o134, o135,
    o136, o137, o138, o139, o140, o141, o142, o143, o144, o145, o146, o147,
    o148, o149, o150, o151, o152, o153, o154, o155, o156, o157, o158, o159,
    o160, o161, o162, o163, o164, o165, o166, o167, o168, o169, o170, o171,
    o172, o173, o174, o175, o176, o177, o178, o179, o180, o181, o182, o183,
    o184, o185, o186, o187, o188, o189, o190, o191, o192, o193, o194, o195,
    o196, o197, o198, o199, o200, o201, o202, o203, o204, o205, o206, o207,
    o208, o209, o210, o211, o212, o213, o214, o215, o216, o217, o218, o219,
    o220, o221, o222, o223, o224, o225, o226, o227, o228, o229, o230, o231,
    o232, o233, o234, o235, o236, o237, o238, o239, o240, o241, o242, o243,
    o244, o245, o246, o247, o248, o249, o250, o251, o252, o253, o254, o255;
  wire new_n265_, new_n266_, new_n267_, new_n268_, new_n269_, new_n270_,
    new_n271_, new_n273_, new_n274_, new_n275_, new_n277_, new_n278_,
    new_n279_, new_n281_, new_n283_, new_n284_, new_n285_, new_n287_,
    new_n288_, new_n290_, new_n292_, new_n294_, new_n295_, new_n296_,
    new_n298_, new_n300_, new_n301_, new_n303_, new_n305_, new_n307_,
    new_n309_, new_n311_, new_n313_, new_n314_, new_n315_, new_n332_,
    new_n333_, new_n334_, new_n351_, new_n352_, new_n369_, new_n370_,
    new_n387_, new_n404_, new_n421_, new_n422_, new_n439_, new_n440_,
    new_n457_, new_n474_, new_n491_, new_n508_, new_n509_, new_n526_,
    new_n543_, new_n560_;
  NOR2x1_ASAP7_75t_R  g000(.A(p0), .B(p2), .Y(new_n265_));
  NOR2x1_ASAP7_75t_R  g001(.A(p1), .B(p7), .Y(new_n266_));
  NAND2x1_ASAP7_75t_R g002(.A(new_n265_), .B(new_n266_), .Y(new_n267_));
  NOR2x1_ASAP7_75t_R  g003(.A(p4), .B(p3), .Y(new_n268_));
  INVx1_ASAP7_75t_R   g004(.A(p6), .Y(new_n269_));
  NOR2x1_ASAP7_75t_R  g005(.A(p5), .B(new_n269_), .Y(new_n270_));
  NAND2x1_ASAP7_75t_R g006(.A(new_n268_), .B(new_n270_), .Y(new_n271_));
  NOR2x1_ASAP7_75t_R  g007(.A(new_n267_), .B(new_n271_), .Y(o0));
  INVx1_ASAP7_75t_R   g008(.A(p7), .Y(new_n273_));
  NOR2x1_ASAP7_75t_R  g009(.A(p1), .B(new_n273_), .Y(new_n274_));
  NAND2x1_ASAP7_75t_R g010(.A(new_n265_), .B(new_n274_), .Y(new_n275_));
  NOR2x1_ASAP7_75t_R  g011(.A(new_n271_), .B(new_n275_), .Y(o1));
  INVx1_ASAP7_75t_R   g012(.A(p0), .Y(new_n277_));
  NOR2x1_ASAP7_75t_R  g013(.A(p2), .B(new_n277_), .Y(new_n278_));
  NAND2x1_ASAP7_75t_R g014(.A(new_n266_), .B(new_n278_), .Y(new_n279_));
  NOR2x1_ASAP7_75t_R  g015(.A(new_n271_), .B(new_n279_), .Y(o2));
  NAND2x1_ASAP7_75t_R g016(.A(new_n274_), .B(new_n278_), .Y(new_n281_));
  NOR2x1_ASAP7_75t_R  g017(.A(new_n271_), .B(new_n281_), .Y(o3));
  INVx1_ASAP7_75t_R   g018(.A(p1), .Y(new_n283_));
  NOR2x1_ASAP7_75t_R  g019(.A(p7), .B(new_n283_), .Y(new_n284_));
  NAND2x1_ASAP7_75t_R g020(.A(new_n265_), .B(new_n284_), .Y(new_n285_));
  NOR2x1_ASAP7_75t_R  g021(.A(new_n271_), .B(new_n285_), .Y(o4));
  NAND2x1_ASAP7_75t_R g022(.A(p1), .B(p7), .Y(new_n287_));
  OR3x1_ASAP7_75t_R   g023(.A(new_n287_), .B(p0), .C(p2), .Y(new_n288_));
  NOR2x1_ASAP7_75t_R  g024(.A(new_n288_), .B(new_n271_), .Y(o5));
  NAND2x1_ASAP7_75t_R g025(.A(new_n278_), .B(new_n284_), .Y(new_n290_));
  NOR2x1_ASAP7_75t_R  g026(.A(new_n271_), .B(new_n290_), .Y(o6));
  OR3x1_ASAP7_75t_R   g027(.A(new_n287_), .B(new_n277_), .C(p2), .Y(new_n292_));
  NOR2x1_ASAP7_75t_R  g028(.A(new_n292_), .B(new_n271_), .Y(o7));
  INVx1_ASAP7_75t_R   g029(.A(p2), .Y(new_n294_));
  NOR2x1_ASAP7_75t_R  g030(.A(p0), .B(new_n294_), .Y(new_n295_));
  NAND2x1_ASAP7_75t_R g031(.A(new_n266_), .B(new_n295_), .Y(new_n296_));
  NOR2x1_ASAP7_75t_R  g032(.A(new_n271_), .B(new_n296_), .Y(o8));
  NAND2x1_ASAP7_75t_R g033(.A(new_n274_), .B(new_n295_), .Y(new_n298_));
  NOR2x1_ASAP7_75t_R  g034(.A(new_n271_), .B(new_n298_), .Y(o9));
  NAND2x1_ASAP7_75t_R g035(.A(p0), .B(p2), .Y(new_n300_));
  OR3x1_ASAP7_75t_R   g036(.A(new_n300_), .B(p1), .C(p7), .Y(new_n301_));
  NOR2x1_ASAP7_75t_R  g037(.A(new_n301_), .B(new_n271_), .Y(o10));
  OR3x1_ASAP7_75t_R   g038(.A(new_n300_), .B(p1), .C(new_n273_), .Y(new_n303_));
  NOR2x1_ASAP7_75t_R  g039(.A(new_n303_), .B(new_n271_), .Y(o11));
  NAND2x1_ASAP7_75t_R g040(.A(new_n284_), .B(new_n295_), .Y(new_n305_));
  NOR2x1_ASAP7_75t_R  g041(.A(new_n271_), .B(new_n305_), .Y(o12));
  OR3x1_ASAP7_75t_R   g042(.A(new_n287_), .B(p0), .C(new_n294_), .Y(new_n307_));
  NOR2x1_ASAP7_75t_R  g043(.A(new_n307_), .B(new_n271_), .Y(o13));
  OR3x1_ASAP7_75t_R   g044(.A(new_n300_), .B(new_n283_), .C(p7), .Y(new_n309_));
  NOR2x1_ASAP7_75t_R  g045(.A(new_n309_), .B(new_n271_), .Y(o14));
  OR3x1_ASAP7_75t_R   g046(.A(new_n287_), .B(new_n277_), .C(new_n294_), .Y(new_n311_));
  NOR2x1_ASAP7_75t_R  g047(.A(new_n311_), .B(new_n271_), .Y(o15));
  INVx1_ASAP7_75t_R   g048(.A(p3), .Y(new_n313_));
  NOR2x1_ASAP7_75t_R  g049(.A(p4), .B(new_n313_), .Y(new_n314_));
  NAND2x1_ASAP7_75t_R g050(.A(new_n270_), .B(new_n314_), .Y(new_n315_));
  NOR2x1_ASAP7_75t_R  g051(.A(new_n267_), .B(new_n315_), .Y(o16));
  NOR2x1_ASAP7_75t_R  g052(.A(new_n275_), .B(new_n315_), .Y(o17));
  NOR2x1_ASAP7_75t_R  g053(.A(new_n279_), .B(new_n315_), .Y(o18));
  NOR2x1_ASAP7_75t_R  g054(.A(new_n281_), .B(new_n315_), .Y(o19));
  NOR2x1_ASAP7_75t_R  g055(.A(new_n285_), .B(new_n315_), .Y(o20));
  NOR2x1_ASAP7_75t_R  g056(.A(new_n288_), .B(new_n315_), .Y(o21));
  NOR2x1_ASAP7_75t_R  g057(.A(new_n290_), .B(new_n315_), .Y(o22));
  NOR2x1_ASAP7_75t_R  g058(.A(new_n292_), .B(new_n315_), .Y(o23));
  NOR2x1_ASAP7_75t_R  g059(.A(new_n296_), .B(new_n315_), .Y(o24));
  NOR2x1_ASAP7_75t_R  g060(.A(new_n298_), .B(new_n315_), .Y(o25));
  NOR2x1_ASAP7_75t_R  g061(.A(new_n301_), .B(new_n315_), .Y(o26));
  NOR2x1_ASAP7_75t_R  g062(.A(new_n303_), .B(new_n315_), .Y(o27));
  NOR2x1_ASAP7_75t_R  g063(.A(new_n305_), .B(new_n315_), .Y(o28));
  NOR2x1_ASAP7_75t_R  g064(.A(new_n307_), .B(new_n315_), .Y(o29));
  NOR2x1_ASAP7_75t_R  g065(.A(new_n309_), .B(new_n315_), .Y(o30));
  NOR2x1_ASAP7_75t_R  g066(.A(new_n311_), .B(new_n315_), .Y(o31));
  INVx1_ASAP7_75t_R   g067(.A(p4), .Y(new_n332_));
  NOR2x1_ASAP7_75t_R  g068(.A(p3), .B(new_n332_), .Y(new_n333_));
  NAND2x1_ASAP7_75t_R g069(.A(new_n270_), .B(new_n333_), .Y(new_n334_));
  NOR2x1_ASAP7_75t_R  g070(.A(new_n267_), .B(new_n334_), .Y(o32));
  NOR2x1_ASAP7_75t_R  g071(.A(new_n275_), .B(new_n334_), .Y(o33));
  NOR2x1_ASAP7_75t_R  g072(.A(new_n279_), .B(new_n334_), .Y(o34));
  NOR2x1_ASAP7_75t_R  g073(.A(new_n281_), .B(new_n334_), .Y(o35));
  NOR2x1_ASAP7_75t_R  g074(.A(new_n285_), .B(new_n334_), .Y(o36));
  NOR2x1_ASAP7_75t_R  g075(.A(new_n288_), .B(new_n334_), .Y(o37));
  NOR2x1_ASAP7_75t_R  g076(.A(new_n290_), .B(new_n334_), .Y(o38));
  NOR2x1_ASAP7_75t_R  g077(.A(new_n292_), .B(new_n334_), .Y(o39));
  NOR2x1_ASAP7_75t_R  g078(.A(new_n296_), .B(new_n334_), .Y(o40));
  NOR2x1_ASAP7_75t_R  g079(.A(new_n298_), .B(new_n334_), .Y(o41));
  NOR2x1_ASAP7_75t_R  g080(.A(new_n301_), .B(new_n334_), .Y(o42));
  NOR2x1_ASAP7_75t_R  g081(.A(new_n303_), .B(new_n334_), .Y(o43));
  NOR2x1_ASAP7_75t_R  g082(.A(new_n305_), .B(new_n334_), .Y(o44));
  NOR2x1_ASAP7_75t_R  g083(.A(new_n307_), .B(new_n334_), .Y(o45));
  NOR2x1_ASAP7_75t_R  g084(.A(new_n309_), .B(new_n334_), .Y(o46));
  NOR2x1_ASAP7_75t_R  g085(.A(new_n311_), .B(new_n334_), .Y(o47));
  NAND2x1_ASAP7_75t_R g086(.A(p4), .B(p3), .Y(new_n351_));
  OR3x1_ASAP7_75t_R   g087(.A(new_n351_), .B(p5), .C(new_n269_), .Y(new_n352_));
  NOR2x1_ASAP7_75t_R  g088(.A(new_n267_), .B(new_n352_), .Y(o48));
  NOR2x1_ASAP7_75t_R  g089(.A(new_n352_), .B(new_n275_), .Y(o49));
  NOR2x1_ASAP7_75t_R  g090(.A(new_n352_), .B(new_n279_), .Y(o50));
  NOR2x1_ASAP7_75t_R  g091(.A(new_n352_), .B(new_n281_), .Y(o51));
  NOR2x1_ASAP7_75t_R  g092(.A(new_n352_), .B(new_n285_), .Y(o52));
  NOR2x1_ASAP7_75t_R  g093(.A(new_n288_), .B(new_n352_), .Y(o53));
  NOR2x1_ASAP7_75t_R  g094(.A(new_n352_), .B(new_n290_), .Y(o54));
  NOR2x1_ASAP7_75t_R  g095(.A(new_n292_), .B(new_n352_), .Y(o55));
  NOR2x1_ASAP7_75t_R  g096(.A(new_n352_), .B(new_n296_), .Y(o56));
  NOR2x1_ASAP7_75t_R  g097(.A(new_n352_), .B(new_n298_), .Y(o57));
  NOR2x1_ASAP7_75t_R  g098(.A(new_n301_), .B(new_n352_), .Y(o58));
  NOR2x1_ASAP7_75t_R  g099(.A(new_n303_), .B(new_n352_), .Y(o59));
  NOR2x1_ASAP7_75t_R  g100(.A(new_n352_), .B(new_n305_), .Y(o60));
  NOR2x1_ASAP7_75t_R  g101(.A(new_n307_), .B(new_n352_), .Y(o61));
  NOR2x1_ASAP7_75t_R  g102(.A(new_n309_), .B(new_n352_), .Y(o62));
  NOR2x1_ASAP7_75t_R  g103(.A(new_n311_), .B(new_n352_), .Y(o63));
  NAND2x1_ASAP7_75t_R g104(.A(p5), .B(p6), .Y(new_n369_));
  OR3x1_ASAP7_75t_R   g105(.A(new_n369_), .B(p4), .C(p3), .Y(new_n370_));
  NOR2x1_ASAP7_75t_R  g106(.A(new_n267_), .B(new_n370_), .Y(o64));
  NOR2x1_ASAP7_75t_R  g107(.A(new_n370_), .B(new_n275_), .Y(o65));
  NOR2x1_ASAP7_75t_R  g108(.A(new_n370_), .B(new_n279_), .Y(o66));
  NOR2x1_ASAP7_75t_R  g109(.A(new_n370_), .B(new_n281_), .Y(o67));
  NOR2x1_ASAP7_75t_R  g110(.A(new_n370_), .B(new_n285_), .Y(o68));
  NOR2x1_ASAP7_75t_R  g111(.A(new_n288_), .B(new_n370_), .Y(o69));
  NOR2x1_ASAP7_75t_R  g112(.A(new_n370_), .B(new_n290_), .Y(o70));
  NOR2x1_ASAP7_75t_R  g113(.A(new_n292_), .B(new_n370_), .Y(o71));
  NOR2x1_ASAP7_75t_R  g114(.A(new_n370_), .B(new_n296_), .Y(o72));
  NOR2x1_ASAP7_75t_R  g115(.A(new_n370_), .B(new_n298_), .Y(o73));
  NOR2x1_ASAP7_75t_R  g116(.A(new_n301_), .B(new_n370_), .Y(o74));
  NOR2x1_ASAP7_75t_R  g117(.A(new_n303_), .B(new_n370_), .Y(o75));
  NOR2x1_ASAP7_75t_R  g118(.A(new_n370_), .B(new_n305_), .Y(o76));
  NOR2x1_ASAP7_75t_R  g119(.A(new_n307_), .B(new_n370_), .Y(o77));
  NOR2x1_ASAP7_75t_R  g120(.A(new_n309_), .B(new_n370_), .Y(o78));
  NOR2x1_ASAP7_75t_R  g121(.A(new_n311_), .B(new_n370_), .Y(o79));
  OR3x1_ASAP7_75t_R   g122(.A(new_n369_), .B(p4), .C(new_n313_), .Y(new_n387_));
  NOR2x1_ASAP7_75t_R  g123(.A(new_n267_), .B(new_n387_), .Y(o80));
  NOR2x1_ASAP7_75t_R  g124(.A(new_n387_), .B(new_n275_), .Y(o81));
  NOR2x1_ASAP7_75t_R  g125(.A(new_n387_), .B(new_n279_), .Y(o82));
  NOR2x1_ASAP7_75t_R  g126(.A(new_n387_), .B(new_n281_), .Y(o83));
  NOR2x1_ASAP7_75t_R  g127(.A(new_n387_), .B(new_n285_), .Y(o84));
  NOR2x1_ASAP7_75t_R  g128(.A(new_n288_), .B(new_n387_), .Y(o85));
  NOR2x1_ASAP7_75t_R  g129(.A(new_n387_), .B(new_n290_), .Y(o86));
  NOR2x1_ASAP7_75t_R  g130(.A(new_n292_), .B(new_n387_), .Y(o87));
  NOR2x1_ASAP7_75t_R  g131(.A(new_n387_), .B(new_n296_), .Y(o88));
  NOR2x1_ASAP7_75t_R  g132(.A(new_n387_), .B(new_n298_), .Y(o89));
  NOR2x1_ASAP7_75t_R  g133(.A(new_n301_), .B(new_n387_), .Y(o90));
  NOR2x1_ASAP7_75t_R  g134(.A(new_n303_), .B(new_n387_), .Y(o91));
  NOR2x1_ASAP7_75t_R  g135(.A(new_n387_), .B(new_n305_), .Y(o92));
  NOR2x1_ASAP7_75t_R  g136(.A(new_n307_), .B(new_n387_), .Y(o93));
  NOR2x1_ASAP7_75t_R  g137(.A(new_n309_), .B(new_n387_), .Y(o94));
  NOR2x1_ASAP7_75t_R  g138(.A(new_n311_), .B(new_n387_), .Y(o95));
  OR3x1_ASAP7_75t_R   g139(.A(new_n369_), .B(new_n332_), .C(p3), .Y(new_n404_));
  NOR2x1_ASAP7_75t_R  g140(.A(new_n267_), .B(new_n404_), .Y(o96));
  NOR2x1_ASAP7_75t_R  g141(.A(new_n404_), .B(new_n275_), .Y(o97));
  NOR2x1_ASAP7_75t_R  g142(.A(new_n404_), .B(new_n279_), .Y(o98));
  NOR2x1_ASAP7_75t_R  g143(.A(new_n404_), .B(new_n281_), .Y(o99));
  NOR2x1_ASAP7_75t_R  g144(.A(new_n404_), .B(new_n285_), .Y(o100));
  NOR2x1_ASAP7_75t_R  g145(.A(new_n288_), .B(new_n404_), .Y(o101));
  NOR2x1_ASAP7_75t_R  g146(.A(new_n404_), .B(new_n290_), .Y(o102));
  NOR2x1_ASAP7_75t_R  g147(.A(new_n292_), .B(new_n404_), .Y(o103));
  NOR2x1_ASAP7_75t_R  g148(.A(new_n404_), .B(new_n296_), .Y(o104));
  NOR2x1_ASAP7_75t_R  g149(.A(new_n404_), .B(new_n298_), .Y(o105));
  NOR2x1_ASAP7_75t_R  g150(.A(new_n301_), .B(new_n404_), .Y(o106));
  NOR2x1_ASAP7_75t_R  g151(.A(new_n303_), .B(new_n404_), .Y(o107));
  NOR2x1_ASAP7_75t_R  g152(.A(new_n404_), .B(new_n305_), .Y(o108));
  NOR2x1_ASAP7_75t_R  g153(.A(new_n307_), .B(new_n404_), .Y(o109));
  NOR2x1_ASAP7_75t_R  g154(.A(new_n309_), .B(new_n404_), .Y(o110));
  NOR2x1_ASAP7_75t_R  g155(.A(new_n311_), .B(new_n404_), .Y(o111));
  INVx1_ASAP7_75t_R   g156(.A(p5), .Y(new_n421_));
  OR3x1_ASAP7_75t_R   g157(.A(new_n351_), .B(new_n421_), .C(new_n269_), .Y(new_n422_));
  NOR2x1_ASAP7_75t_R  g158(.A(new_n267_), .B(new_n422_), .Y(o112));
  NOR2x1_ASAP7_75t_R  g159(.A(new_n422_), .B(new_n275_), .Y(o113));
  NOR2x1_ASAP7_75t_R  g160(.A(new_n422_), .B(new_n279_), .Y(o114));
  NOR2x1_ASAP7_75t_R  g161(.A(new_n422_), .B(new_n281_), .Y(o115));
  NOR2x1_ASAP7_75t_R  g162(.A(new_n422_), .B(new_n285_), .Y(o116));
  NOR2x1_ASAP7_75t_R  g163(.A(new_n288_), .B(new_n422_), .Y(o117));
  NOR2x1_ASAP7_75t_R  g164(.A(new_n422_), .B(new_n290_), .Y(o118));
  NOR2x1_ASAP7_75t_R  g165(.A(new_n292_), .B(new_n422_), .Y(o119));
  NOR2x1_ASAP7_75t_R  g166(.A(new_n422_), .B(new_n296_), .Y(o120));
  NOR2x1_ASAP7_75t_R  g167(.A(new_n422_), .B(new_n298_), .Y(o121));
  NOR2x1_ASAP7_75t_R  g168(.A(new_n301_), .B(new_n422_), .Y(o122));
  NOR2x1_ASAP7_75t_R  g169(.A(new_n303_), .B(new_n422_), .Y(o123));
  NOR2x1_ASAP7_75t_R  g170(.A(new_n422_), .B(new_n305_), .Y(o124));
  NOR2x1_ASAP7_75t_R  g171(.A(new_n307_), .B(new_n422_), .Y(o125));
  NOR2x1_ASAP7_75t_R  g172(.A(new_n309_), .B(new_n422_), .Y(o126));
  NOR2x1_ASAP7_75t_R  g173(.A(new_n311_), .B(new_n422_), .Y(o127));
  NOR2x1_ASAP7_75t_R  g174(.A(p5), .B(p6), .Y(new_n439_));
  NAND2x1_ASAP7_75t_R g175(.A(new_n268_), .B(new_n439_), .Y(new_n440_));
  NOR2x1_ASAP7_75t_R  g176(.A(new_n267_), .B(new_n440_), .Y(o128));
  NOR2x1_ASAP7_75t_R  g177(.A(new_n440_), .B(new_n275_), .Y(o129));
  NOR2x1_ASAP7_75t_R  g178(.A(new_n440_), .B(new_n279_), .Y(o130));
  NOR2x1_ASAP7_75t_R  g179(.A(new_n440_), .B(new_n281_), .Y(o131));
  NOR2x1_ASAP7_75t_R  g180(.A(new_n440_), .B(new_n285_), .Y(o132));
  NOR2x1_ASAP7_75t_R  g181(.A(new_n440_), .B(new_n288_), .Y(o133));
  NOR2x1_ASAP7_75t_R  g182(.A(new_n440_), .B(new_n290_), .Y(o134));
  NOR2x1_ASAP7_75t_R  g183(.A(new_n440_), .B(new_n292_), .Y(o135));
  NOR2x1_ASAP7_75t_R  g184(.A(new_n440_), .B(new_n296_), .Y(o136));
  NOR2x1_ASAP7_75t_R  g185(.A(new_n440_), .B(new_n298_), .Y(o137));
  NOR2x1_ASAP7_75t_R  g186(.A(new_n440_), .B(new_n301_), .Y(o138));
  NOR2x1_ASAP7_75t_R  g187(.A(new_n440_), .B(new_n303_), .Y(o139));
  NOR2x1_ASAP7_75t_R  g188(.A(new_n440_), .B(new_n305_), .Y(o140));
  NOR2x1_ASAP7_75t_R  g189(.A(new_n440_), .B(new_n307_), .Y(o141));
  NOR2x1_ASAP7_75t_R  g190(.A(new_n440_), .B(new_n309_), .Y(o142));
  NOR2x1_ASAP7_75t_R  g191(.A(new_n440_), .B(new_n311_), .Y(o143));
  NAND2x1_ASAP7_75t_R g192(.A(new_n439_), .B(new_n314_), .Y(new_n457_));
  NOR2x1_ASAP7_75t_R  g193(.A(new_n267_), .B(new_n457_), .Y(o144));
  NOR2x1_ASAP7_75t_R  g194(.A(new_n275_), .B(new_n457_), .Y(o145));
  NOR2x1_ASAP7_75t_R  g195(.A(new_n279_), .B(new_n457_), .Y(o146));
  NOR2x1_ASAP7_75t_R  g196(.A(new_n457_), .B(new_n281_), .Y(o147));
  NOR2x1_ASAP7_75t_R  g197(.A(new_n285_), .B(new_n457_), .Y(o148));
  NOR2x1_ASAP7_75t_R  g198(.A(new_n288_), .B(new_n457_), .Y(o149));
  NOR2x1_ASAP7_75t_R  g199(.A(new_n457_), .B(new_n290_), .Y(o150));
  NOR2x1_ASAP7_75t_R  g200(.A(new_n292_), .B(new_n457_), .Y(o151));
  NOR2x1_ASAP7_75t_R  g201(.A(new_n296_), .B(new_n457_), .Y(o152));
  NOR2x1_ASAP7_75t_R  g202(.A(new_n457_), .B(new_n298_), .Y(o153));
  NOR2x1_ASAP7_75t_R  g203(.A(new_n301_), .B(new_n457_), .Y(o154));
  NOR2x1_ASAP7_75t_R  g204(.A(new_n303_), .B(new_n457_), .Y(o155));
  NOR2x1_ASAP7_75t_R  g205(.A(new_n457_), .B(new_n305_), .Y(o156));
  NOR2x1_ASAP7_75t_R  g206(.A(new_n307_), .B(new_n457_), .Y(o157));
  NOR2x1_ASAP7_75t_R  g207(.A(new_n309_), .B(new_n457_), .Y(o158));
  NOR2x1_ASAP7_75t_R  g208(.A(new_n311_), .B(new_n457_), .Y(o159));
  NAND2x1_ASAP7_75t_R g209(.A(new_n439_), .B(new_n333_), .Y(new_n474_));
  NOR2x1_ASAP7_75t_R  g210(.A(new_n267_), .B(new_n474_), .Y(o160));
  NOR2x1_ASAP7_75t_R  g211(.A(new_n275_), .B(new_n474_), .Y(o161));
  NOR2x1_ASAP7_75t_R  g212(.A(new_n279_), .B(new_n474_), .Y(o162));
  NOR2x1_ASAP7_75t_R  g213(.A(new_n474_), .B(new_n281_), .Y(o163));
  NOR2x1_ASAP7_75t_R  g214(.A(new_n285_), .B(new_n474_), .Y(o164));
  NOR2x1_ASAP7_75t_R  g215(.A(new_n288_), .B(new_n474_), .Y(o165));
  NOR2x1_ASAP7_75t_R  g216(.A(new_n474_), .B(new_n290_), .Y(o166));
  NOR2x1_ASAP7_75t_R  g217(.A(new_n292_), .B(new_n474_), .Y(o167));
  NOR2x1_ASAP7_75t_R  g218(.A(new_n296_), .B(new_n474_), .Y(o168));
  NOR2x1_ASAP7_75t_R  g219(.A(new_n474_), .B(new_n298_), .Y(o169));
  NOR2x1_ASAP7_75t_R  g220(.A(new_n301_), .B(new_n474_), .Y(o170));
  NOR2x1_ASAP7_75t_R  g221(.A(new_n303_), .B(new_n474_), .Y(o171));
  NOR2x1_ASAP7_75t_R  g222(.A(new_n474_), .B(new_n305_), .Y(o172));
  NOR2x1_ASAP7_75t_R  g223(.A(new_n307_), .B(new_n474_), .Y(o173));
  NOR2x1_ASAP7_75t_R  g224(.A(new_n309_), .B(new_n474_), .Y(o174));
  NOR2x1_ASAP7_75t_R  g225(.A(new_n311_), .B(new_n474_), .Y(o175));
  OR3x1_ASAP7_75t_R   g226(.A(new_n351_), .B(p5), .C(p6), .Y(new_n491_));
  NOR2x1_ASAP7_75t_R  g227(.A(new_n267_), .B(new_n491_), .Y(o176));
  NOR2x1_ASAP7_75t_R  g228(.A(new_n491_), .B(new_n275_), .Y(o177));
  NOR2x1_ASAP7_75t_R  g229(.A(new_n491_), .B(new_n279_), .Y(o178));
  NOR2x1_ASAP7_75t_R  g230(.A(new_n491_), .B(new_n281_), .Y(o179));
  NOR2x1_ASAP7_75t_R  g231(.A(new_n491_), .B(new_n285_), .Y(o180));
  NOR2x1_ASAP7_75t_R  g232(.A(new_n288_), .B(new_n491_), .Y(o181));
  NOR2x1_ASAP7_75t_R  g233(.A(new_n491_), .B(new_n290_), .Y(o182));
  NOR2x1_ASAP7_75t_R  g234(.A(new_n292_), .B(new_n491_), .Y(o183));
  NOR2x1_ASAP7_75t_R  g235(.A(new_n491_), .B(new_n296_), .Y(o184));
  NOR2x1_ASAP7_75t_R  g236(.A(new_n491_), .B(new_n298_), .Y(o185));
  NOR2x1_ASAP7_75t_R  g237(.A(new_n301_), .B(new_n491_), .Y(o186));
  NOR2x1_ASAP7_75t_R  g238(.A(new_n303_), .B(new_n491_), .Y(o187));
  NOR2x1_ASAP7_75t_R  g239(.A(new_n491_), .B(new_n305_), .Y(o188));
  NOR2x1_ASAP7_75t_R  g240(.A(new_n307_), .B(new_n491_), .Y(o189));
  NOR2x1_ASAP7_75t_R  g241(.A(new_n309_), .B(new_n491_), .Y(o190));
  NOR2x1_ASAP7_75t_R  g242(.A(new_n311_), .B(new_n491_), .Y(o191));
  NOR2x1_ASAP7_75t_R  g243(.A(p6), .B(new_n421_), .Y(new_n508_));
  NAND2x1_ASAP7_75t_R g244(.A(new_n268_), .B(new_n508_), .Y(new_n509_));
  NOR2x1_ASAP7_75t_R  g245(.A(new_n267_), .B(new_n509_), .Y(o192));
  NOR2x1_ASAP7_75t_R  g246(.A(new_n275_), .B(new_n509_), .Y(o193));
  NOR2x1_ASAP7_75t_R  g247(.A(new_n279_), .B(new_n509_), .Y(o194));
  NOR2x1_ASAP7_75t_R  g248(.A(new_n509_), .B(new_n281_), .Y(o195));
  NOR2x1_ASAP7_75t_R  g249(.A(new_n285_), .B(new_n509_), .Y(o196));
  NOR2x1_ASAP7_75t_R  g250(.A(new_n288_), .B(new_n509_), .Y(o197));
  NOR2x1_ASAP7_75t_R  g251(.A(new_n509_), .B(new_n290_), .Y(o198));
  NOR2x1_ASAP7_75t_R  g252(.A(new_n292_), .B(new_n509_), .Y(o199));
  NOR2x1_ASAP7_75t_R  g253(.A(new_n296_), .B(new_n509_), .Y(o200));
  NOR2x1_ASAP7_75t_R  g254(.A(new_n509_), .B(new_n298_), .Y(o201));
  NOR2x1_ASAP7_75t_R  g255(.A(new_n301_), .B(new_n509_), .Y(o202));
  NOR2x1_ASAP7_75t_R  g256(.A(new_n303_), .B(new_n509_), .Y(o203));
  NOR2x1_ASAP7_75t_R  g257(.A(new_n509_), .B(new_n305_), .Y(o204));
  NOR2x1_ASAP7_75t_R  g258(.A(new_n307_), .B(new_n509_), .Y(o205));
  NOR2x1_ASAP7_75t_R  g259(.A(new_n309_), .B(new_n509_), .Y(o206));
  NOR2x1_ASAP7_75t_R  g260(.A(new_n311_), .B(new_n509_), .Y(o207));
  NAND2x1_ASAP7_75t_R g261(.A(new_n314_), .B(new_n508_), .Y(new_n526_));
  NOR2x1_ASAP7_75t_R  g262(.A(new_n267_), .B(new_n526_), .Y(o208));
  NOR2x1_ASAP7_75t_R  g263(.A(new_n275_), .B(new_n526_), .Y(o209));
  NOR2x1_ASAP7_75t_R  g264(.A(new_n279_), .B(new_n526_), .Y(o210));
  NOR2x1_ASAP7_75t_R  g265(.A(new_n281_), .B(new_n526_), .Y(o211));
  NOR2x1_ASAP7_75t_R  g266(.A(new_n285_), .B(new_n526_), .Y(o212));
  NOR2x1_ASAP7_75t_R  g267(.A(new_n288_), .B(new_n526_), .Y(o213));
  NOR2x1_ASAP7_75t_R  g268(.A(new_n290_), .B(new_n526_), .Y(o214));
  NOR2x1_ASAP7_75t_R  g269(.A(new_n292_), .B(new_n526_), .Y(o215));
  NOR2x1_ASAP7_75t_R  g270(.A(new_n296_), .B(new_n526_), .Y(o216));
  NOR2x1_ASAP7_75t_R  g271(.A(new_n298_), .B(new_n526_), .Y(o217));
  NOR2x1_ASAP7_75t_R  g272(.A(new_n301_), .B(new_n526_), .Y(o218));
  NOR2x1_ASAP7_75t_R  g273(.A(new_n303_), .B(new_n526_), .Y(o219));
  NOR2x1_ASAP7_75t_R  g274(.A(new_n305_), .B(new_n526_), .Y(o220));
  NOR2x1_ASAP7_75t_R  g275(.A(new_n307_), .B(new_n526_), .Y(o221));
  NOR2x1_ASAP7_75t_R  g276(.A(new_n309_), .B(new_n526_), .Y(o222));
  NOR2x1_ASAP7_75t_R  g277(.A(new_n311_), .B(new_n526_), .Y(o223));
  NAND2x1_ASAP7_75t_R g278(.A(new_n333_), .B(new_n508_), .Y(new_n543_));
  NOR2x1_ASAP7_75t_R  g279(.A(new_n267_), .B(new_n543_), .Y(o224));
  NOR2x1_ASAP7_75t_R  g280(.A(new_n275_), .B(new_n543_), .Y(o225));
  NOR2x1_ASAP7_75t_R  g281(.A(new_n279_), .B(new_n543_), .Y(o226));
  NOR2x1_ASAP7_75t_R  g282(.A(new_n281_), .B(new_n543_), .Y(o227));
  NOR2x1_ASAP7_75t_R  g283(.A(new_n285_), .B(new_n543_), .Y(o228));
  NOR2x1_ASAP7_75t_R  g284(.A(new_n288_), .B(new_n543_), .Y(o229));
  NOR2x1_ASAP7_75t_R  g285(.A(new_n290_), .B(new_n543_), .Y(o230));
  NOR2x1_ASAP7_75t_R  g286(.A(new_n292_), .B(new_n543_), .Y(o231));
  NOR2x1_ASAP7_75t_R  g287(.A(new_n296_), .B(new_n543_), .Y(o232));
  NOR2x1_ASAP7_75t_R  g288(.A(new_n298_), .B(new_n543_), .Y(o233));
  NOR2x1_ASAP7_75t_R  g289(.A(new_n301_), .B(new_n543_), .Y(o234));
  NOR2x1_ASAP7_75t_R  g290(.A(new_n303_), .B(new_n543_), .Y(o235));
  NOR2x1_ASAP7_75t_R  g291(.A(new_n305_), .B(new_n543_), .Y(o236));
  NOR2x1_ASAP7_75t_R  g292(.A(new_n307_), .B(new_n543_), .Y(o237));
  NOR2x1_ASAP7_75t_R  g293(.A(new_n309_), .B(new_n543_), .Y(o238));
  NOR2x1_ASAP7_75t_R  g294(.A(new_n311_), .B(new_n543_), .Y(o239));
  OR3x1_ASAP7_75t_R   g295(.A(new_n351_), .B(new_n421_), .C(p6), .Y(new_n560_));
  NOR2x1_ASAP7_75t_R  g296(.A(new_n267_), .B(new_n560_), .Y(o240));
  NOR2x1_ASAP7_75t_R  g297(.A(new_n560_), .B(new_n275_), .Y(o241));
  NOR2x1_ASAP7_75t_R  g298(.A(new_n560_), .B(new_n279_), .Y(o242));
  NOR2x1_ASAP7_75t_R  g299(.A(new_n560_), .B(new_n281_), .Y(o243));
  NOR2x1_ASAP7_75t_R  g300(.A(new_n560_), .B(new_n285_), .Y(o244));
  NOR2x1_ASAP7_75t_R  g301(.A(new_n288_), .B(new_n560_), .Y(o245));
  NOR2x1_ASAP7_75t_R  g302(.A(new_n560_), .B(new_n290_), .Y(o246));
  NOR2x1_ASAP7_75t_R  g303(.A(new_n292_), .B(new_n560_), .Y(o247));
  NOR2x1_ASAP7_75t_R  g304(.A(new_n560_), .B(new_n296_), .Y(o248));
  NOR2x1_ASAP7_75t_R  g305(.A(new_n560_), .B(new_n298_), .Y(o249));
  NOR2x1_ASAP7_75t_R  g306(.A(new_n301_), .B(new_n560_), .Y(o250));
  NOR2x1_ASAP7_75t_R  g307(.A(new_n303_), .B(new_n560_), .Y(o251));
  NOR2x1_ASAP7_75t_R  g308(.A(new_n560_), .B(new_n305_), .Y(o252));
  NOR2x1_ASAP7_75t_R  g309(.A(new_n307_), .B(new_n560_), .Y(o253));
  NOR2x1_ASAP7_75t_R  g310(.A(new_n309_), .B(new_n560_), .Y(o254));
  NOR2x1_ASAP7_75t_R  g311(.A(new_n311_), .B(new_n560_), .Y(o255));
endmodule


