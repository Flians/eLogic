module mapped(input p0,p1,p2,p3,output o0,o1,o2,o3);assign o0=~p0;assign o1=~p1;assign o2=~p2;assign o3=~p3;endmodule
