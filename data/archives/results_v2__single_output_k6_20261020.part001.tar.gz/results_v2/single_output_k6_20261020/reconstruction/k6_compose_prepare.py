from pathlib import Path
import shutil
src=Path('/tmp/emapper-single-output-k6-20261020');dst=Path('/tmp/emapper-single-output-k6-compose-20261020');assert not dst.exists();dst.mkdir()
for n in ['Cargo.toml','Cargo.lock','main.rs','measure.rs','supergates.jsonl']:shutil.copy2(src/n,dst/n)
shutil.copytree(src/'emapper',dst/'emapper',ignore=shutil.ignore_patterns('target'))
(dst/'tools').symlink_to('/home/flynn/workplace/MIGBalance/tools')
p=dst/'Cargo.toml';p.write_text(p.read_text().replace('emapper-single-output-k6','emapper-single-output-k6-compose').replace('bench_rs_egraph_k6','bench_rs_egraph_k6_compose'))
p=dst/'emapper/src/egraph_map.rs';s=p.read_text()
old='''fn expand(function: u64, from: &[usize], to: &[usize]) -> u64 {
    static WORD: std::sync::OnceLock<bool> = std::sync::OnceLock::new();
    if *WORD.get_or_init(|| std::env::var("EGM_WORD_TRUTH").as_deref() == Ok("1")) {'''
new='''fn word_truth_enabled() -> bool {
    static WORD: std::sync::OnceLock<bool> = std::sync::OnceLock::new();
    *WORD.get_or_init(|| std::env::var("EGM_WORD_TRUTH").as_deref() == Ok("1"))
}
fn expand(function: u64, from: &[usize], to: &[usize]) -> u64 {
    if word_truth_enabled() {'''
assert old in s;s=s.replace(old,new)
start=s.index('let mut function=0;for a in 0..1usize<<leaves.len(){let sub=')
end=s.index('let cut=reduce(Cut{leaves,function});',start)
original=s[start:end]
Path('results_v2/single_output_k6_20261020/substitution_reference_fragment.txt').write_text(original)
s=s[:start]+'let function=if word_truth_enabled(){substitute_word(base,position,child,&leaves)}else{substitute_reference(base,position,child,&leaves)};'+s[end:]
helper='''
fn substitute_reference(base: &Cut, position: usize, child: &Cut, leaves: &[usize]) -> u64 {
    '''+original+'''
    function
}
fn cofactor_word(function: u64, position: usize, value: bool, width: usize) -> u64 {
    const GROUPS:[u64;6]=[0x5555555555555555,0x3333333333333333,
        0x0f0f0f0f0f0f0f0f,0x00ff00ff00ff00ff,0x0000ffff0000ffff,0x00000000ffffffff];
    let mut result=(function >> (usize::from(value)*(1usize<<position))) & GROUPS[position];
    for step in position..5 {result=(result | (result>>(1usize<<step))) & GROUPS[step+1];}
    result & mask(width-1)
}
fn substitute_word(base:&Cut, position:usize, child:&Cut, leaves:&[usize])->u64 {
    let remaining:Vec<_>=base.leaves.iter().enumerate().filter_map(|(i,&leaf)|(i!=position).then_some(leaf)).collect();
    let low=expand_word(cofactor_word(base.function,position,false,base.leaves.len()),&remaining,leaves);
    let high=expand_word(cofactor_word(base.function,position,true,base.leaves.len()),&remaining,leaves);
    let condition=expand_word(child.function,&child.leaves,leaves);
    ((low & !condition) | (high & condition)) & mask(leaves.len())
}
'''
s+=helper+'''
#[cfg(test)]mod word_substitution_tests {
 use super::*;
 #[test]fn truth_substitution_matches_old_row_evaluation_with_shared_supports(){
  let mut state=1321u64;
  for n in 1..=6 {
   for ordinal in 0..4000usize {
    let mut random=||{state=state.wrapping_mul(6364136223846793005).wrapping_add(1);state};
    let base_mask=(random() as usize % ((1<<n)-1))+1;let child_mask=random() as usize % (1<<n);
    let base=Cut{leaves:(0..n).filter(|i|base_mask&(1<<i)!=0).map(|i|i*3+5).collect(),function:random()};
    let child=Cut{leaves:(0..n).filter(|i|child_mask&(1<<i)!=0).map(|i|i*3+5).collect(),function:random()};
    let position=ordinal%base.leaves.len();
    let leaves:Vec<_>=base.leaves.iter().enumerate().filter_map(|(i,&leaf)|(i!=position).then_some(leaf)).chain(child.leaves.iter().copied()).collect::<BTreeSet<_>>().into_iter().collect();
    assert_eq!(substitute_word(&base,position,&child,&leaves),substitute_reference(&base,position,&child,&leaves),"n={n} ordinal={ordinal} base={base:?} child={child:?}");
   }
  }
 }
 #[test]fn word_cofactors_match_every_four_input_truth(){
  for tt in 0..=u16::MAX {for position in 0..4 {for value in [false,true] {
   let mut expected=0;
   for assignment in 0..8usize {let below=assignment&((1<<position)-1);let above=assignment>>position;let full=below|((value as usize)<<position)|(above<<(position+1));expected|=(((tt as u64)>>full)&1)<<assignment;}
   assert_eq!(cofactor_word(tt as u64,position,value,4),expected);
  }}}
 }
}
'''
p.write_text(s)
print('Prepared separate, unbuilt compose variant:',dst)
