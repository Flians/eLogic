import ctypes as c,json,hashlib
from pathlib import Path
lib=next(Path('/tmp/emapper-esyn-baseline/e-rewriter/target/release/build').glob('xgboost-sys-*/out/xgboost/lib/libxgboost.so'))
x=c.CDLL(str(lib));x.XGBGetLastError.restype=c.c_char_p
b=c.c_void_p();d=c.c_void_p();data=(c.c_float*8)(0,0,0,0,0,0,0,0)
x.XGBoosterCreate.argtypes=[c.POINTER(c.c_void_p),c.c_ulong,c.POINTER(c.c_void_p)]
x.XGBoosterLoadModel.argtypes=[c.c_void_p,c.c_char_p]
x.XGDMatrixCreateFromMat.argtypes=[c.POINTER(c.c_float),c.c_ulong,c.c_ulong,c.c_float,c.POINTER(c.c_void_p)]
x.XGBoosterPredict.argtypes=[c.c_void_p,c.c_void_p,c.c_int,c.c_uint,c.POINTER(c.c_ulong),c.POINTER(c.POINTER(c.c_float))]
records=[]
for model in ['xgb_delay.model','xgb.model']:
 path=Path('/tmp/emapper-esyn-baseline/e-rewriter/src/model')/model
 code=x.XGBoosterCreate(None,0,c.byref(b));assert code==0
 code=x.XGBoosterLoadModel(b,str(path).encode());error=x.XGBGetLastError().decode() if code else None
 if not code:
  assert x.XGDMatrixCreateFromMat(data,1,8,0.0,c.byref(d))==0
  n=c.c_ulong();p=c.POINTER(c.c_float)();code=x.XGBoosterPredict(b,d,0,0,c.byref(n),c.byref(p));error=x.XGBGetLastError().decode() if code else None
  values=[p[i] for i in range(n.value)] if code==0 else None
 else:values=None
 records.append(dict(model=model,model_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),return_code=code,error=error,zero_feature_prediction=values))
 x.XGBoosterFree(b)
print(json.dumps(dict(library=str(lib),sha256=hashlib.sha256(lib.read_bytes()).hexdigest(),results=records),indent=2))
