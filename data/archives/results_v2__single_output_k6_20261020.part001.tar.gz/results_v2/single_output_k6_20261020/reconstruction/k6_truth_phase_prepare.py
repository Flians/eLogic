from pathlib import Path
p=Path('/tmp/emapper-single-output-k6-compose-20261020/emapper/src/egraph_map.rs');s=p.read_text()
start=s.index('fn input_phase(tt:');end=s.index('\nfn subsets(',start)
old=s[start:end].replace('fn input_phase(','fn input_phase_reference(')
new='''
fn input_phase_word(mut tt:u64,n:usize,phase:usize)->u64 {
    const LOW:[u64;6]=[0x5555555555555555,0x3333333333333333,0x0f0f0f0f0f0f0f0f,
        0x00ff00ff00ff00ff,0x0000ffff0000ffff,0x00000000ffffffff];
    for bit in 0..n {if phase&(1<<bit)!=0 {
        let shift=1usize<<bit;tt=((tt&LOW[bit])<<shift)|((tt&!LOW[bit])>>shift);
    }}
    tt & mask(n)
}
fn input_phase(tt:u64,n:usize,phase:usize)->u64 {
    if word_truth_enabled(){input_phase_word(tt,n,phase)}else{input_phase_reference(tt,n,phase)}
}
fn boundary_function_reference(function:u64,inputs:&[usize],boundary:&[usize])->u64 {
    let mut actual=0;
    for a in 0..1usize<<boundary.len(){
        let tuple=inputs.iter().enumerate().fold(0,|v,(p,&s)|v|(((((a>>boundary.binary_search(&(s/2)).expect("physical input outside matched boundary"))&1)^(s%2)))<<p));
        actual|=((function>>tuple)&1)<<a;
    }
    actual
}
fn boundary_function_word(function:u64,inputs:&[usize],boundary:&[usize])->u64 {
    let variables:Vec<_>=inputs.iter().map(|s|s/2).collect();
    if !variables.windows(2).all(|w|w[0]<w[1]) {return boundary_function_reference(function,inputs,boundary);}
    let phase=inputs.iter().filter(|s|*s%2==1).fold(0,|mask,&s|mask|(1usize<<boundary.binary_search(&(s/2)).expect("physical input outside matched boundary")));
    input_phase_word(expand_word(function,&variables,boundary),boundary.len(),phase)
}
'''
s=s[:start]+old+new+s[end:]
needle='''    let mut groups: BTreeMap<&str, Vec<&Cell>> = BTreeMap::new();'''
# Exactly one generator definition; cache pure cell-pin functions, not matches.
assert needle in s[s.index('fn generate_mode('):]
start_generator=s.index('fn generate_mode(')
prefix=s[:start_generator];tail=s[start_generator:]
s=prefix+tail.replace(needle,'''    let word_truth=word_truth_enabled();
    let mut physical_truth_cache:HashMap<(&str,&str,&[String]),u64>=HashMap::new();
'''+needle,1)
needle='''                    let physical = physical_function(cell, &v.pin_names);''';assert needle in s[s.index('fn generate_mode('):]
start_generator=s.index('fn generate_mode(')
prefix=s[:start_generator];tail=s[start_generator:]
s=prefix+tail.replace(needle,'''                    let physical = if word_truth {
                        *physical_truth_cache.entry((v.cell_name.as_str(),v.out_pin.as_str(),v.pin_names.as_slice()))
                            .or_insert_with(||physical_function(cell,&v.pin_names))
                    } else {physical_function(cell,&v.pin_names)};''')
s+='''
#[cfg(test)]mod word_phase_tests {
 use super::*;
 #[test]fn every_four_input_truth_and_phase_matches_row_reference(){
  for tt in 0..=u16::MAX {for phase in 0..16 {
   assert_eq!(input_phase_word(tt as u64,4,phase),input_phase_reference(tt as u64,4,phase));
  }}
 }
 #[test]fn binding_evidence_function_matches_with_subsets_phases_reordering_and_aliases(){
  let mut state=43u64;
  for n in 0..=6 {let boundary:Vec<_>=(0..n).map(|i|i*3+5).collect();
   for subset in 0..1usize<<n {
    let variables:Vec<_>=boundary.iter().enumerate().filter(|(i,_)|subset&(1<<i)!=0).map(|(_,s)|*s).collect();
    for phase in 0..1usize<<variables.len() {
     state=state.wrapping_mul(6364136223846793005).wrapping_add(1);
     let mut inputs:Vec<_>=variables.iter().enumerate().map(|(i,s)|s*2+((phase>>i)&1)).collect();
     assert_eq!(boundary_function_word(state,&inputs,&boundary),boundary_function_reference(state,&inputs,&boundary));
     inputs.reverse();assert_eq!(boundary_function_word(state,&inputs,&boundary),boundary_function_reference(state,&inputs,&boundary));
     if inputs.len()<6&&!inputs.is_empty(){inputs.push(inputs[0]);assert_eq!(boundary_function_word(state,&inputs,&boundary),boundary_function_reference(state,&inputs,&boundary));}
    }
   }
  }
 }
}
''';p.write_text(s)
p=Path('/tmp/emapper-single-output-k6-compose-20261020/emapper/src/egraph_cover_exchange.rs');s=p.read_text();start=s.index('        let mut actual=0;');end=s.index('        for t in targets.iter()',start)
old=s[start:end]
assert 'output.function' in old
s=s[:start]+'''        let actual=if word_truth_enabled(){boundary_function_word(output.function,&m.inputs,boundary)}else{boundary_function_reference(output.function,&m.inputs,boundary)};
'''+s[end:];p.write_text(s)
Path('results_v2/single_output_k6_20261020/binding_reference_fragment.txt').write_text(old)
print('Prepared word phases, exact cached cell/pin truth, and unchanged-evidence evaluation; unbuilt/unmeasured')
