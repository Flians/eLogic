from pathlib import Path
p=Path('/tmp/emapper-single-output-k6-20261020/emapper/src/egraph_map.rs');s=p.read_text();start=s.index('fn expand(function:');end=s.index('\nfn reduce(',start)
old=s[start:end].replace('fn expand(','fn expand_reference(')
new='''// Exact word-level lifting for sorted supports with at most six variables.
// Reference fallback preserves callers whose input order is not canonical.
fn expand_word(function: u64, from: &[usize], to: &[usize]) -> u64 {
    if to.len() > 6 || !from.windows(2).all(|w| w[0] < w[1]) {
        return expand_reference(function, from, to);
    }
    const LOW_GROUPS: [u64; 6] = [
        0x5555555555555555, 0x3333333333333333,
        0x0f0f0f0f0f0f0f0f, 0x00ff00ff00ff00ff,
        0x0000ffff0000ffff, 0x00000000ffffffff,
    ];
    let mut bits = function & mask(from.len());
    let mut source = 0;
    for (position, &leaf) in to.iter().enumerate() {
        if from.get(source) == Some(&leaf) {
            source += 1;
        } else {
            for step in (position..6).rev() {
                bits = (bits | (bits << (1usize << step))) & LOW_GROUPS[step];
            }
            bits |= bits << (1usize << position);
        }
    }
    assert_eq!(source, from.len(), "truth support is not a subset");
    bits & mask(to.len())
}

fn expand(function: u64, from: &[usize], to: &[usize]) -> u64 {
    static WORD: std::sync::OnceLock<bool> = std::sync::OnceLock::new();
    if *WORD.get_or_init(|| std::env::var("EGM_WORD_TRUTH").as_deref() == Ok("1")) {
        expand_word(function, from, to)
    } else {
        expand_reference(function, from, to)
    }
}
'''
tests='''
#[cfg(test)] mod word_truth_tests {
 use super::*;
 #[test] fn lifted_truths_match_reference_for_all_supports_and_small_functions() {
  let mut state = 43u64;
  for n in 0..=6 {
   let to:Vec<_>=(0..n).map(|i|i*3+7).collect();
   for subset in 0..(1usize<<n) {
    let from:Vec<_>=(0..n).filter(|i|subset&(1<<i)!=0).map(|i|to[i]).collect();
    let count=if from.len()<=3 {1usize<<(1usize<<from.len())} else {1024};
    for ordinal in 0..count {
     state=state.wrapping_mul(6364136223846793005).wrapping_add(1);
     let tt=if from.len()<=3 {ordinal as u64 | (state & !mask(from.len()))} else {state};
     assert_eq!(expand_word(tt,&from,&to),expand_reference(tt,&from,&to),"n={n}, subset={subset}, tt={tt}");
    }
    let mut reversed=from.clone();reversed.reverse();
    assert_eq!(expand_word(state,&reversed,&to),expand_reference(state,&reversed,&to));
   }
  }
 }
 #[test] fn four_input_truths_are_exhaustive_when_lifted_to_six() {
  for absent in 0..6 {for absent2 in absent+1..6 {
   let to:Vec<_>=(0..6).collect();let from:Vec<_>=to.iter().copied().filter(|i|*i!=absent&&*i!=absent2).collect();
   for tt in 0..=u16::MAX {assert_eq!(expand_word(tt as u64,&from,&to),expand_reference(tt as u64,&from,&to));}
  }}
 }
}
'''
s=s[:start]+old+'\n\n'+new+s[end:]+tests;p.write_text(s)
out=Path('results_v2/single_output_k6_20261020');(out/'truth_word.rs').write_text(new)
base=(out/'truth_reference_probe.rs').read_text();base=base.replace('fn main()',new+'\nfn mask(k:usize)->u64 {if k==6{u64::MAX}else{(1u64<<(1usize<<k))-1}}\nfn main()').replace('black_box(expand_reference(','black_box(expand_word(')
(out/'truth_word_probe.rs').write_text(base)
