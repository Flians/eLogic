use xgboost::{Booster,DMatrix};
fn main(){let mut d=DMatrix::from_dense(&[0f32;8],1).unwrap();for name in ["xgb_delay.model","xgb.model"]{let file=format!("/tmp/emapper-esyn-baseline/e-rewriter/src/model/{name}");match Booster::load(file).and_then(|b|b.predict(&d)){Ok(v)=>println!("{name} {v:?}"),Err(e)=>{eprintln!("{name}: {e:?}");std::process::exit(1);}}}}
