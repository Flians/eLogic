import importlib.util,itertools,json
from pathlib import Path
source=Path("scripts/experiments/campaigns/analyze_pin_symmetry_relaxation.py")
s=importlib.util.spec_from_file_location("pinrelax",source);m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
assert m.symmetries({"vars":["A","B"],"tt":[8]})==[(0,1),(1,0)]
perms=m.symmetries({"vars":["A1","A2","A3","B"],"tt":[65408]})
assert len(perms)==6 and all(perm[3]==3 for perm in perms)
assert (3,1,2,0) not in perms
assert m.symmetries({"vars":[],"tt":[1]})==[()]
assert m.symmetries({"vars":["A"],"tt":[1]})==[(0,)]
for tt in range(16):
 found=set(m.symmetries({"vars":["A","B"],"tt":[tt]}))
 for perm in itertools.permutations(range(2)):
  same=all(((tt>>bits)&1)==((tt>>sum(((bits>>perm[i])&1)<<i for i in range(2)))&1) for bits in range(4))
  assert (perm in found)==same
out=Path(__file__).with_name("pin_symmetry_tests.json")
assert not out.exists()
out.write_text(json.dumps(dict(source_sha256=m.sha(source),tests=["AND pin swap","AO31 only product inputs interchangeable","AO31 product/addend swap rejected","constants","inverter","all16 two-input truth tables exact positive and negative permutation tests"],passed=True,actual_mapper_calls=0,prior_harness_error="initial ad-hoc test shadowed source-path variable with a permutation; no result recorded; assertions themselves had passed"),indent=2)+"\n")
print("6 diagnostic symmetry tests passed")
