fn expand_reference(function: u64, from: &[usize], to: &[usize]) -> u64 {
    let positions: Vec<_> = from.iter().map(|x| to.binary_search(x).unwrap()).collect();
    let mut result = 0;
    for a in 0..1usize << to.len() {
        let old = positions
            .iter()
            .enumerate()
            .fold(0, |v, (i, p)| v | (((a >> p) & 1) << i));
        result |= ((function >> old) & 1) << a;
    }
    result
}
