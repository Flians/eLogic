use std::hint::black_box;
use std::time::Instant;
fn expand_reference(function: u64, from: &[usize], to: &[usize]) -> u64 {
    let positions: Vec<_> = from.iter().map(|x| to.binary_search(x).unwrap()).collect();
    let mut result = 0;
    for a in 0..1usize << to.len() {
        let old = positions
            .iter()
            .enumerate()
            .fold(0, |v, (i, p)| v | (((a >> p) & 1) << i));
        result |= ((function >> old) & 1) << a;
    }
    result
}

// Exact word-level lifting for sorted supports with at most six variables.
// Reference fallback preserves callers whose input order is not canonical.
fn expand_word(function: u64, from: &[usize], to: &[usize]) -> u64 {
    if to.len() > 6 || !from.windows(2).all(|w| w[0] < w[1]) {
        return expand_reference(function, from, to);
    }
    const LOW_GROUPS: [u64; 6] = [
        0x5555555555555555, 0x3333333333333333,
        0x0f0f0f0f0f0f0f0f, 0x00ff00ff00ff00ff,
        0x0000ffff0000ffff, 0x00000000ffffffff,
    ];
    let mut bits = function & mask(from.len());
    let mut source = 0;
    for (position, &leaf) in to.iter().enumerate() {
        if from.get(source) == Some(&leaf) {
            source += 1;
        } else {
            for step in (position..6).rev() {
                bits = (bits | (bits << (1usize << step))) & LOW_GROUPS[step];
            }
            bits |= bits << (1usize << position);
        }
    }
    assert_eq!(source, from.len(), "truth support is not a subset");
    bits & mask(to.len())
}

fn expand(function: u64, from: &[usize], to: &[usize]) -> u64 {
    static WORD: std::sync::OnceLock<bool> = std::sync::OnceLock::new();
    if *WORD.get_or_init(|| std::env::var("EGM_WORD_TRUTH").as_deref() == Ok("1")) {
        expand_word(function, from, to)
    } else {
        expand_reference(function, from, to)
    }
}

fn mask(k:usize)->u64 {if k==6{u64::MAX}else{(1u64<<(1usize<<k))-1}}
fn main(){let mut state=7u64;let before=Instant::now();let mut checksum=0u64;
for i in 0..2000000usize {state=state.wrapping_mul(6364136223846793005).wrapping_add(1);let from=match i%4 {0=>vec![0,2,4],1=>vec![1,3,5],2=>vec![0,1,2,4,5],_=>vec![2]};checksum^=black_box(expand_word(black_box(state),black_box(&from),black_box(&[0,1,2,3,4,5])));}
println!("{{\"seconds\":{},\"checksum\":{}}}",before.elapsed().as_secs_f64(),checksum);}
