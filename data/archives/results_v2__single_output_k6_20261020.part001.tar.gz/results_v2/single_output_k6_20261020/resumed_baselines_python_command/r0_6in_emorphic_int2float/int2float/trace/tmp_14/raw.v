// Benchmark "/tmp/" written by ABC on Tue Oct 20 17:46:15 2026

module \/tmp/  ( 
    p6, p3, p4, p8, p10, p0, p1, p5, p2, p9, p7,
    o0, o1, o2, o3, o4, o5, o6  );
  input  p6, p3, p4, p8, p10, p0, p1, p5, p2, p9, p7;
  output o0, o1, o2, o3, o4, o5, o6;
  wire new_n19_, new_n20_, new_n21_, new_n22_, new_n23_, new_n24_, new_n25_,
    new_n26_, new_n27_, new_n28_, new_n29_, new_n30_, new_n31_, new_n32_,
    new_n33_, new_n34_, new_n35_, new_n36_, new_n37_, new_n38_, new_n39_,
    new_n40_, new_n41_, new_n42_, new_n43_, new_n44_, new_n45_, new_n46_,
    new_n47_, new_n48_, new_n49_, new_n50_, new_n51_, new_n52_, new_n53_,
    new_n54_, new_n55_, new_n56_, new_n57_, new_n58_, new_n59_, new_n60_,
    new_n61_, new_n62_, new_n63_, new_n64_, new_n66_, new_n67_, new_n68_,
    new_n69_, new_n70_, new_n71_, new_n72_, new_n73_, new_n74_, new_n75_,
    new_n76_, new_n77_, new_n78_, new_n79_, new_n80_, new_n81_, new_n82_,
    new_n83_, new_n84_, new_n85_, new_n86_, new_n87_, new_n88_, new_n89_,
    new_n90_, new_n91_, new_n92_, new_n93_, new_n94_, new_n95_, new_n96_,
    new_n97_, new_n98_, new_n99_, new_n100_, new_n101_, new_n103_,
    new_n104_, new_n105_, new_n106_, new_n107_, new_n108_, new_n109_,
    new_n110_, new_n111_, new_n112_, new_n113_, new_n114_, new_n115_,
    new_n116_, new_n117_, new_n118_, new_n119_, new_n120_, new_n121_,
    new_n122_, new_n123_, new_n124_, new_n125_, new_n126_, new_n127_,
    new_n128_, new_n129_, new_n130_, new_n131_, new_n132_, new_n133_,
    new_n135_, new_n136_, new_n137_, new_n138_, new_n139_, new_n141_,
    new_n142_, new_n143_, new_n144_, new_n145_, new_n146_, new_n147_,
    new_n148_, new_n149_, new_n150_, new_n151_, new_n153_, new_n154_,
    new_n155_, new_n156_, new_n157_;
  NAND2x1_ASAP7_75t_R  g000(.A(p3), .B(p0), .Y(new_n19_));
  INVx1_ASAP7_75t_R    g001(.A(p3), .Y(new_n20_));
  NAND2x1_ASAP7_75t_R  g002(.A(p7), .B(new_n20_), .Y(new_n21_));
  INVx1_ASAP7_75t_R    g003(.A(p10), .Y(new_n22_));
  AOI21x1_ASAP7_75t_R  g004(.A1(new_n19_), .A2(new_n21_), .B(new_n22_), .Y(new_n23_));
  INVx1_ASAP7_75t_R    g005(.A(p6), .Y(new_n24_));
  INVx1_ASAP7_75t_R    g006(.A(p5), .Y(new_n25_));
  NAND2x1_ASAP7_75t_R  g007(.A(new_n24_), .B(new_n25_), .Y(new_n26_));
  AO21x1_ASAP7_75t_R   g008(.A1(new_n22_), .A2(new_n19_), .B(new_n26_), .Y(new_n27_));
  INVx1_ASAP7_75t_R    g009(.A(p7), .Y(new_n28_));
  INVx1_ASAP7_75t_R    g010(.A(p4), .Y(new_n29_));
  OA21x2_ASAP7_75t_R   g011(.A1(new_n20_), .A2(new_n28_), .B(new_n29_), .Y(new_n30_));
  OAI21x1_ASAP7_75t_R  g012(.A1(new_n23_), .A2(new_n27_), .B(new_n30_), .Y(new_n31_));
  AO21x1_ASAP7_75t_R   g013(.A1(p7), .A2(new_n20_), .B(new_n29_), .Y(new_n32_));
  NAND2x1_ASAP7_75t_R  g014(.A(p4), .B(p2), .Y(new_n33_));
  INVx1_ASAP7_75t_R    g015(.A(p0), .Y(new_n34_));
  OR4x2_ASAP7_75t_R    g016(.A(new_n33_), .B(p6), .C(new_n34_), .D(p1), .Y(new_n35_));
  INVx1_ASAP7_75t_R    g017(.A(p2), .Y(new_n36_));
  NAND2x1_ASAP7_75t_R  g018(.A(p3), .B(p2), .Y(new_n37_));
  NAND2x1_ASAP7_75t_R  g019(.A(p6), .B(new_n37_), .Y(new_n38_));
  AO21x1_ASAP7_75t_R   g020(.A1(new_n20_), .A2(new_n36_), .B(new_n38_), .Y(new_n39_));
  AOI21x1_ASAP7_75t_R  g021(.A1(new_n35_), .A2(new_n39_), .B(p7), .Y(new_n40_));
  AOI21x1_ASAP7_75t_R  g022(.A1(new_n31_), .A2(new_n32_), .B(new_n40_), .Y(new_n41_));
  NOR2x1_ASAP7_75t_R   g023(.A(p8), .B(p9), .Y(new_n42_));
  INVx1_ASAP7_75t_R    g024(.A(new_n42_), .Y(new_n43_));
  INVx1_ASAP7_75t_R    g025(.A(p9), .Y(new_n44_));
  AOI211x1_ASAP7_75t_R g026(.A1(p6), .A2(new_n20_), .B(new_n34_), .C(p1), .Y(new_n45_));
  AO21x1_ASAP7_75t_R   g027(.A1(new_n36_), .A2(new_n28_), .B(new_n20_), .Y(new_n46_));
  NOR2x1_ASAP7_75t_R   g028(.A(p5), .B(new_n29_), .Y(new_n47_));
  NAND3x1_ASAP7_75t_R  g029(.A(new_n45_), .B(new_n46_), .C(new_n47_), .Y(new_n48_));
  NOR2x1_ASAP7_75t_R   g030(.A(p6), .B(p7), .Y(new_n49_));
  AO31x2_ASAP7_75t_R   g031(.A1(new_n49_), .A2(new_n34_), .A3(p1), .B(p8), .Y(new_n50_));
  AND3x1_ASAP7_75t_R   g032(.A(new_n29_), .B(p8), .C(p5), .Y(new_n51_));
  AOI21x1_ASAP7_75t_R  g033(.A1(new_n47_), .A2(new_n50_), .B(new_n51_), .Y(new_n52_));
  NAND2x1_ASAP7_75t_R  g034(.A(new_n48_), .B(new_n52_), .Y(new_n53_));
  NAND2x1_ASAP7_75t_R  g035(.A(p5), .B(new_n24_), .Y(new_n54_));
  NOR2x1_ASAP7_75t_R   g036(.A(p1), .B(p2), .Y(new_n55_));
  AND2x2_ASAP7_75t_R   g037(.A(p1), .B(p2), .Y(new_n56_));
  INVx1_ASAP7_75t_R    g038(.A(p8), .Y(new_n57_));
  NAND2x1_ASAP7_75t_R  g039(.A(new_n57_), .B(new_n28_), .Y(new_n58_));
  OA31x2_ASAP7_75t_R   g040(.A1(new_n55_), .A2(new_n56_), .A3(new_n58_), .B1(new_n44_), .Y(new_n59_));
  NOR2x1_ASAP7_75t_R   g041(.A(p5), .B(new_n24_), .Y(new_n60_));
  AND3x1_ASAP7_75t_R   g042(.A(p8), .B(p9), .C(p7), .Y(new_n61_));
  AOI22x1_ASAP7_75t_R  g043(.A1(new_n60_), .A2(p9), .B1(p5), .B2(new_n61_), .Y(new_n62_));
  OAI21x1_ASAP7_75t_R  g044(.A1(new_n54_), .A2(new_n59_), .B(new_n62_), .Y(new_n63_));
  AOI21x1_ASAP7_75t_R  g045(.A1(new_n44_), .A2(new_n53_), .B(new_n63_), .Y(new_n64_));
  OAI21x1_ASAP7_75t_R  g046(.A1(new_n41_), .A2(new_n43_), .B(new_n64_), .Y(o0));
  NAND2x1_ASAP7_75t_R  g047(.A(p8), .B(new_n24_), .Y(new_n66_));
  OAI21x1_ASAP7_75t_R  g048(.A1(new_n58_), .A2(new_n38_), .B(new_n66_), .Y(new_n67_));
  OAI21x1_ASAP7_75t_R  g049(.A1(p6), .A2(p5), .B(new_n20_), .Y(new_n68_));
  OAI21x1_ASAP7_75t_R  g050(.A1(p8), .A2(p7), .B(p3), .Y(new_n69_));
  AO21x1_ASAP7_75t_R   g051(.A1(p0), .A2(p1), .B(p6), .Y(new_n70_));
  AND5x1_ASAP7_75t_R   g052(.A(p4), .B(new_n68_), .C(p2), .D(new_n69_), .E(new_n70_), .Y(new_n71_));
  AOI21x1_ASAP7_75t_R  g053(.A1(new_n29_), .A2(new_n67_), .B(new_n71_), .Y(new_n72_));
  OAI22x1_ASAP7_75t_R  g054(.A1(p6), .A2(p1), .B1(p3), .B2(p8), .Y(new_n73_));
  AO22x1_ASAP7_75t_R   g055(.A1(new_n57_), .A2(p7), .B1(new_n34_), .B2(new_n73_), .Y(new_n74_));
  NAND2x1_ASAP7_75t_R  g056(.A(p0), .B(p1), .Y(new_n75_));
  NAND2x1_ASAP7_75t_R  g057(.A(p3), .B(new_n24_), .Y(new_n76_));
  INVx1_ASAP7_75t_R    g058(.A(p1), .Y(new_n77_));
  NOR2x1_ASAP7_75t_R   g059(.A(p10), .B(new_n77_), .Y(new_n78_));
  AOI211x1_ASAP7_75t_R g060(.A1(p10), .A2(new_n75_), .B(new_n76_), .C(new_n78_), .Y(new_n79_));
  NOR2x1_ASAP7_75t_R   g061(.A(p4), .B(p5), .Y(new_n80_));
  OAI21x1_ASAP7_75t_R  g062(.A1(new_n74_), .A2(new_n79_), .B(new_n80_), .Y(new_n81_));
  NAND2x1_ASAP7_75t_R  g063(.A(new_n20_), .B(new_n57_), .Y(new_n82_));
  AO21x1_ASAP7_75t_R   g064(.A1(new_n66_), .A2(new_n82_), .B(new_n25_), .Y(new_n83_));
  NAND2x1_ASAP7_75t_R  g065(.A(p4), .B(p5), .Y(new_n84_));
  NAND3x1_ASAP7_75t_R  g066(.A(new_n82_), .B(new_n66_), .C(new_n84_), .Y(new_n85_));
  NAND3x1_ASAP7_75t_R  g067(.A(new_n83_), .B(new_n58_), .C(new_n85_), .Y(new_n86_));
  NAND3x1_ASAP7_75t_R  g068(.A(new_n72_), .B(new_n81_), .C(new_n86_), .Y(new_n87_));
  AO21x1_ASAP7_75t_R   g069(.A1(p6), .A2(p5), .B(p7), .Y(new_n88_));
  AO21x1_ASAP7_75t_R   g070(.A1(p6), .A2(new_n44_), .B(new_n88_), .Y(new_n89_));
  NOR2x1_ASAP7_75t_R   g071(.A(p5), .B(p2), .Y(new_n90_));
  AO32x1_ASAP7_75t_R   g072(.A1(new_n20_), .A2(new_n57_), .A3(p5), .B1(new_n90_), .B2(p4), .Y(new_n91_));
  NOR2x1_ASAP7_75t_R   g073(.A(p0), .B(p5), .Y(new_n92_));
  AO32x1_ASAP7_75t_R   g074(.A1(new_n20_), .A2(new_n57_), .A3(p5), .B1(new_n92_), .B2(p4), .Y(new_n93_));
  AND3x1_ASAP7_75t_R   g075(.A(p3), .B(p1), .C(p2), .Y(new_n94_));
  NOR2x1_ASAP7_75t_R   g076(.A(p8), .B(new_n25_), .Y(new_n95_));
  AO21x1_ASAP7_75t_R   g077(.A1(new_n94_), .A2(new_n95_), .B(p9), .Y(new_n96_));
  AOI221x1_ASAP7_75t_R g078(.A1(new_n91_), .A2(new_n77_), .B1(new_n36_), .B2(new_n93_), .C(new_n96_), .Y(new_n97_));
  NAND2x1_ASAP7_75t_R  g079(.A(p9), .B(p7), .Y(new_n98_));
  NAND2x1_ASAP7_75t_R  g080(.A(p6), .B(p5), .Y(new_n99_));
  OR3x1_ASAP7_75t_R    g081(.A(new_n98_), .B(new_n99_), .C(p8), .Y(new_n100_));
  OAI21x1_ASAP7_75t_R  g082(.A1(new_n89_), .A2(new_n97_), .B(new_n100_), .Y(new_n101_));
  AOI21x1_ASAP7_75t_R  g083(.A1(new_n44_), .A2(new_n87_), .B(new_n101_), .Y(o1));
  NOR2x1_ASAP7_75t_R   g084(.A(p2), .B(new_n29_), .Y(new_n103_));
  NOR3x1_ASAP7_75t_R   g085(.A(new_n36_), .B(p1), .C(p5), .Y(new_n104_));
  OAI21x1_ASAP7_75t_R  g086(.A1(new_n103_), .A2(new_n104_), .B(p3), .Y(new_n105_));
  INVx1_ASAP7_75t_R    g087(.A(new_n49_), .Y(new_n106_));
  AOI21x1_ASAP7_75t_R  g088(.A1(new_n77_), .A2(new_n105_), .B(new_n106_), .Y(new_n107_));
  NOR2x1_ASAP7_75t_R   g089(.A(p3), .B(p5), .Y(new_n108_));
  AOI21x1_ASAP7_75t_R  g090(.A1(p10), .A2(p0), .B(new_n37_), .Y(new_n109_));
  OAI21x1_ASAP7_75t_R  g091(.A1(new_n108_), .A2(new_n109_), .B(new_n29_), .Y(new_n110_));
  NOR3x1_ASAP7_75t_R   g092(.A(new_n22_), .B(p5), .C(p2), .Y(new_n111_));
  AOI21x1_ASAP7_75t_R  g093(.A1(new_n20_), .A2(new_n33_), .B(new_n34_), .Y(new_n112_));
  OAI21x1_ASAP7_75t_R  g094(.A1(new_n20_), .A2(new_n111_), .B(new_n112_), .Y(new_n113_));
  NAND3x1_ASAP7_75t_R  g095(.A(new_n110_), .B(new_n113_), .C(new_n105_), .Y(new_n114_));
  AO21x1_ASAP7_75t_R   g096(.A1(new_n37_), .A2(new_n84_), .B(p7), .Y(new_n115_));
  AND3x1_ASAP7_75t_R   g097(.A(new_n29_), .B(p1), .C(p5), .Y(new_n116_));
  AOI211x1_ASAP7_75t_R g098(.A1(p4), .A2(new_n92_), .B(new_n37_), .C(new_n116_), .Y(new_n117_));
  AND3x1_ASAP7_75t_R   g099(.A(p3), .B(p4), .C(p2), .Y(new_n118_));
  NOR3x1_ASAP7_75t_R   g100(.A(new_n25_), .B(p6), .C(p1), .Y(new_n119_));
  NAND2x1_ASAP7_75t_R  g101(.A(p3), .B(p4), .Y(new_n120_));
  INVx1_ASAP7_75t_R    g102(.A(new_n120_), .Y(new_n121_));
  AOI21x1_ASAP7_75t_R  g103(.A1(p3), .A2(p4), .B(new_n99_), .Y(new_n122_));
  AOI221x1_ASAP7_75t_R g104(.A1(new_n60_), .A2(new_n118_), .B1(new_n119_), .B2(new_n121_), .C(new_n122_), .Y(new_n123_));
  OAI21x1_ASAP7_75t_R  g105(.A1(new_n115_), .A2(new_n117_), .B(new_n123_), .Y(new_n124_));
  AOI21x1_ASAP7_75t_R  g106(.A1(new_n107_), .A2(new_n114_), .B(new_n124_), .Y(new_n125_));
  NOR2x1_ASAP7_75t_R   g107(.A(new_n120_), .B(new_n54_), .Y(new_n126_));
  OAI21x1_ASAP7_75t_R  g108(.A1(new_n60_), .A2(new_n126_), .B(p7), .Y(new_n127_));
  OR3x1_ASAP7_75t_R    g109(.A(new_n29_), .B(new_n57_), .C(p7), .Y(new_n128_));
  AO21x1_ASAP7_75t_R   g110(.A1(new_n98_), .A2(new_n128_), .B(new_n99_), .Y(new_n129_));
  AND3x1_ASAP7_75t_R   g111(.A(new_n44_), .B(p6), .C(p4), .Y(new_n130_));
  NOR2x1_ASAP7_75t_R   g112(.A(p9), .B(p7), .Y(new_n131_));
  OR3x1_ASAP7_75t_R    g113(.A(new_n130_), .B(new_n57_), .C(new_n131_), .Y(new_n132_));
  OA211x2_ASAP7_75t_R  g114(.A1(p9), .A2(new_n127_), .B(new_n129_), .C(new_n132_), .Y(new_n133_));
  OAI21x1_ASAP7_75t_R  g115(.A1(new_n43_), .A2(new_n125_), .B(new_n133_), .Y(o2));
  NAND2x1_ASAP7_75t_R  g116(.A(new_n24_), .B(new_n29_), .Y(new_n135_));
  OR3x1_ASAP7_75t_R    g117(.A(new_n135_), .B(p3), .C(p5), .Y(new_n136_));
  OR3x1_ASAP7_75t_R    g118(.A(new_n84_), .B(new_n24_), .C(new_n28_), .Y(new_n137_));
  OR3x1_ASAP7_75t_R    g119(.A(new_n137_), .B(new_n20_), .C(p1), .Y(new_n138_));
  OA21x2_ASAP7_75t_R   g120(.A1(p7), .A2(new_n136_), .B(new_n138_), .Y(new_n139_));
  OR3x1_ASAP7_75t_R    g121(.A(new_n139_), .B(p2), .C(new_n43_), .Y(o3));
  OR3x1_ASAP7_75t_R    g122(.A(new_n34_), .B(new_n77_), .C(p6), .Y(new_n141_));
  AO21x1_ASAP7_75t_R   g123(.A1(new_n84_), .A2(new_n141_), .B(new_n37_), .Y(new_n142_));
  OA211x2_ASAP7_75t_R  g124(.A1(new_n20_), .A2(new_n135_), .B(new_n54_), .C(new_n28_), .Y(new_n143_));
  NAND2x1_ASAP7_75t_R  g125(.A(new_n142_), .B(new_n143_), .Y(new_n144_));
  AND3x1_ASAP7_75t_R   g126(.A(new_n80_), .B(p10), .C(p0), .Y(new_n145_));
  AND3x1_ASAP7_75t_R   g127(.A(new_n28_), .B(p1), .C(p2), .Y(new_n146_));
  OAI21x1_ASAP7_75t_R  g128(.A1(new_n145_), .A2(new_n126_), .B(new_n146_), .Y(new_n147_));
  NOR2x1_ASAP7_75t_R   g129(.A(p7), .B(new_n36_), .Y(new_n148_));
  OR5x1_ASAP7_75t_R    g130(.A(p8), .B(new_n148_), .C(new_n55_), .D(new_n99_), .E(new_n120_), .Y(new_n149_));
  NAND2x1_ASAP7_75t_R  g131(.A(p8), .B(new_n137_), .Y(new_n150_));
  AND3x1_ASAP7_75t_R   g132(.A(new_n147_), .B(new_n149_), .C(new_n150_), .Y(new_n151_));
  AO21x1_ASAP7_75t_R   g133(.A1(new_n144_), .A2(new_n151_), .B(p9), .Y(o4));
  OR5x1_ASAP7_75t_R    g134(.A(new_n22_), .B(new_n135_), .C(new_n34_), .D(new_n36_), .E(p7), .Y(new_n153_));
  OAI22x1_ASAP7_75t_R  g135(.A1(new_n153_), .A2(new_n77_), .B1(new_n55_), .B2(new_n137_), .Y(new_n154_));
  AND3x1_ASAP7_75t_R   g136(.A(new_n94_), .B(p4), .C(p5), .Y(new_n155_));
  OR3x1_ASAP7_75t_R    g137(.A(new_n155_), .B(new_n106_), .C(new_n80_), .Y(new_n156_));
  NAND2x1_ASAP7_75t_R  g138(.A(new_n42_), .B(new_n156_), .Y(new_n157_));
  AO21x1_ASAP7_75t_R   g139(.A1(p3), .A2(new_n154_), .B(new_n157_), .Y(o5));
  OR3x1_ASAP7_75t_R    g140(.A(new_n155_), .B(new_n43_), .C(new_n106_), .Y(o6));
endmodule


