// Benchmark "/tmp/" written by ABC on Tue Oct 20 17:46:15 2026

module \/tmp/  ( 
    p8, p5, p6, p10, p4, p9, p1, p2, p7, p3, p0,
    o0, o1, o2, o3, o4, o5, o6  );
  input  p8, p5, p6, p10, p4, p9, p1, p2, p7, p3, p0;
  output o0, o1, o2, o3, o4, o5, o6;
  wire new_n19_, new_n20_, new_n21_, new_n22_, new_n23_, new_n24_, new_n25_,
    new_n26_, new_n27_, new_n28_, new_n29_, new_n30_, new_n31_, new_n32_,
    new_n33_, new_n34_, new_n35_, new_n36_, new_n37_, new_n38_, new_n39_,
    new_n40_, new_n41_, new_n42_, new_n43_, new_n44_, new_n45_, new_n46_,
    new_n47_, new_n48_, new_n49_, new_n50_, new_n51_, new_n52_, new_n53_,
    new_n54_, new_n55_, new_n56_, new_n57_, new_n58_, new_n59_, new_n60_,
    new_n61_, new_n62_, new_n63_, new_n64_, new_n65_, new_n67_, new_n68_,
    new_n69_, new_n70_, new_n71_, new_n72_, new_n73_, new_n74_, new_n75_,
    new_n76_, new_n77_, new_n78_, new_n79_, new_n80_, new_n81_, new_n82_,
    new_n83_, new_n84_, new_n85_, new_n86_, new_n87_, new_n88_, new_n89_,
    new_n90_, new_n91_, new_n92_, new_n93_, new_n94_, new_n95_, new_n96_,
    new_n97_, new_n98_, new_n99_, new_n100_, new_n101_, new_n103_,
    new_n104_, new_n105_, new_n106_, new_n107_, new_n108_, new_n109_,
    new_n110_, new_n111_, new_n112_, new_n113_, new_n114_, new_n115_,
    new_n116_, new_n117_, new_n118_, new_n119_, new_n120_, new_n121_,
    new_n122_, new_n123_, new_n124_, new_n125_, new_n126_, new_n127_,
    new_n128_, new_n129_, new_n130_, new_n131_, new_n132_, new_n134_,
    new_n135_, new_n136_, new_n137_, new_n138_, new_n140_, new_n141_,
    new_n142_, new_n143_, new_n144_, new_n145_, new_n146_, new_n147_,
    new_n148_, new_n149_, new_n151_, new_n152_, new_n153_, new_n154_,
    new_n155_, new_n156_;
  NAND2x1_ASAP7_75t_R  g000(.A(p3), .B(p0), .Y(new_n19_));
  INVx1_ASAP7_75t_R    g001(.A(p3), .Y(new_n20_));
  NAND2x1_ASAP7_75t_R  g002(.A(p7), .B(new_n20_), .Y(new_n21_));
  INVx1_ASAP7_75t_R    g003(.A(p10), .Y(new_n22_));
  AOI21x1_ASAP7_75t_R  g004(.A1(new_n19_), .A2(new_n21_), .B(new_n22_), .Y(new_n23_));
  INVx1_ASAP7_75t_R    g005(.A(p5), .Y(new_n24_));
  INVx1_ASAP7_75t_R    g006(.A(p6), .Y(new_n25_));
  NAND2x1_ASAP7_75t_R  g007(.A(new_n24_), .B(new_n25_), .Y(new_n26_));
  AO21x1_ASAP7_75t_R   g008(.A1(new_n22_), .A2(new_n19_), .B(new_n26_), .Y(new_n27_));
  INVx1_ASAP7_75t_R    g009(.A(p7), .Y(new_n28_));
  INVx1_ASAP7_75t_R    g010(.A(p4), .Y(new_n29_));
  OA21x2_ASAP7_75t_R   g011(.A1(new_n28_), .A2(new_n20_), .B(new_n29_), .Y(new_n30_));
  OAI21x1_ASAP7_75t_R  g012(.A1(new_n23_), .A2(new_n27_), .B(new_n30_), .Y(new_n31_));
  AO21x1_ASAP7_75t_R   g013(.A1(p7), .A2(new_n20_), .B(new_n29_), .Y(new_n32_));
  AND3x1_ASAP7_75t_R   g014(.A(p4), .B(p2), .C(p0), .Y(new_n33_));
  INVx1_ASAP7_75t_R    g015(.A(p1), .Y(new_n34_));
  AND3x1_ASAP7_75t_R   g016(.A(new_n33_), .B(new_n25_), .C(new_n34_), .Y(new_n35_));
  INVx1_ASAP7_75t_R    g017(.A(p2), .Y(new_n36_));
  NAND2x1_ASAP7_75t_R  g018(.A(p2), .B(p3), .Y(new_n37_));
  NAND2x1_ASAP7_75t_R  g019(.A(p6), .B(new_n37_), .Y(new_n38_));
  AOI21x1_ASAP7_75t_R  g020(.A1(new_n36_), .A2(new_n20_), .B(new_n38_), .Y(new_n39_));
  OA21x2_ASAP7_75t_R   g021(.A1(new_n35_), .A2(new_n39_), .B(new_n28_), .Y(new_n40_));
  AOI21x1_ASAP7_75t_R  g022(.A1(new_n31_), .A2(new_n32_), .B(new_n40_), .Y(new_n41_));
  NOR2x1_ASAP7_75t_R   g023(.A(p8), .B(p9), .Y(new_n42_));
  INVx1_ASAP7_75t_R    g024(.A(new_n42_), .Y(new_n43_));
  INVx1_ASAP7_75t_R    g025(.A(p9), .Y(new_n44_));
  INVx1_ASAP7_75t_R    g026(.A(p0), .Y(new_n45_));
  AOI211x1_ASAP7_75t_R g027(.A1(p6), .A2(new_n20_), .B(p1), .C(new_n45_), .Y(new_n46_));
  AO21x1_ASAP7_75t_R   g028(.A1(new_n36_), .A2(new_n28_), .B(new_n20_), .Y(new_n47_));
  NOR2x1_ASAP7_75t_R   g029(.A(p5), .B(new_n29_), .Y(new_n48_));
  NAND3x1_ASAP7_75t_R  g030(.A(new_n46_), .B(new_n47_), .C(new_n48_), .Y(new_n49_));
  NOR2x1_ASAP7_75t_R   g031(.A(p6), .B(p7), .Y(new_n50_));
  AO31x2_ASAP7_75t_R   g032(.A1(new_n50_), .A2(p1), .A3(new_n45_), .B(p8), .Y(new_n51_));
  AND3x1_ASAP7_75t_R   g033(.A(new_n29_), .B(p8), .C(p5), .Y(new_n52_));
  AOI21x1_ASAP7_75t_R  g034(.A1(new_n48_), .A2(new_n51_), .B(new_n52_), .Y(new_n53_));
  NAND2x1_ASAP7_75t_R  g035(.A(new_n49_), .B(new_n53_), .Y(new_n54_));
  NAND2x1_ASAP7_75t_R  g036(.A(p5), .B(new_n25_), .Y(new_n55_));
  NOR2x1_ASAP7_75t_R   g037(.A(p1), .B(p2), .Y(new_n56_));
  AND2x2_ASAP7_75t_R   g038(.A(p1), .B(p2), .Y(new_n57_));
  INVx1_ASAP7_75t_R    g039(.A(p8), .Y(new_n58_));
  NAND2x1_ASAP7_75t_R  g040(.A(new_n58_), .B(new_n28_), .Y(new_n59_));
  OA31x2_ASAP7_75t_R   g041(.A1(new_n56_), .A2(new_n57_), .A3(new_n59_), .B1(new_n44_), .Y(new_n60_));
  NOR2x1_ASAP7_75t_R   g042(.A(p5), .B(new_n25_), .Y(new_n61_));
  AND3x1_ASAP7_75t_R   g043(.A(p8), .B(p9), .C(p7), .Y(new_n62_));
  AOI22x1_ASAP7_75t_R  g044(.A1(new_n61_), .A2(p9), .B1(p5), .B2(new_n62_), .Y(new_n63_));
  OAI21x1_ASAP7_75t_R  g045(.A1(new_n55_), .A2(new_n60_), .B(new_n63_), .Y(new_n64_));
  AOI21x1_ASAP7_75t_R  g046(.A1(new_n44_), .A2(new_n54_), .B(new_n64_), .Y(new_n65_));
  OAI21x1_ASAP7_75t_R  g047(.A1(new_n41_), .A2(new_n43_), .B(new_n65_), .Y(o0));
  NAND2x1_ASAP7_75t_R  g048(.A(p8), .B(new_n25_), .Y(new_n67_));
  OAI21x1_ASAP7_75t_R  g049(.A1(new_n59_), .A2(new_n38_), .B(new_n67_), .Y(new_n68_));
  NOR2x1_ASAP7_75t_R   g050(.A(p5), .B(p3), .Y(new_n69_));
  AO32x1_ASAP7_75t_R   g051(.A1(new_n58_), .A2(new_n28_), .A3(p3), .B1(new_n69_), .B2(new_n25_), .Y(new_n70_));
  AO21x1_ASAP7_75t_R   g052(.A1(p1), .A2(p0), .B(p6), .Y(new_n71_));
  AND3x1_ASAP7_75t_R   g053(.A(new_n71_), .B(p4), .C(p2), .Y(new_n72_));
  AOI22x1_ASAP7_75t_R  g054(.A1(new_n68_), .A2(new_n29_), .B1(new_n70_), .B2(new_n72_), .Y(new_n73_));
  NAND2x1_ASAP7_75t_R  g055(.A(new_n58_), .B(new_n20_), .Y(new_n74_));
  AO21x1_ASAP7_75t_R   g056(.A1(new_n67_), .A2(new_n74_), .B(new_n24_), .Y(new_n75_));
  NAND2x1_ASAP7_75t_R  g057(.A(p5), .B(p4), .Y(new_n76_));
  NAND3x1_ASAP7_75t_R  g058(.A(new_n74_), .B(new_n67_), .C(new_n76_), .Y(new_n77_));
  NAND3x1_ASAP7_75t_R  g059(.A(new_n75_), .B(new_n59_), .C(new_n77_), .Y(new_n78_));
  OAI22x1_ASAP7_75t_R  g060(.A1(p8), .A2(p3), .B1(p6), .B2(p1), .Y(new_n79_));
  AO22x1_ASAP7_75t_R   g061(.A1(new_n58_), .A2(p7), .B1(new_n45_), .B2(new_n79_), .Y(new_n80_));
  NAND2x1_ASAP7_75t_R  g062(.A(p10), .B(p0), .Y(new_n81_));
  NAND2x1_ASAP7_75t_R  g063(.A(p3), .B(new_n25_), .Y(new_n82_));
  NOR2x1_ASAP7_75t_R   g064(.A(p1), .B(new_n22_), .Y(new_n83_));
  AOI211x1_ASAP7_75t_R g065(.A1(p1), .A2(new_n81_), .B(new_n82_), .C(new_n83_), .Y(new_n84_));
  NOR2x1_ASAP7_75t_R   g066(.A(p5), .B(p4), .Y(new_n85_));
  OAI21x1_ASAP7_75t_R  g067(.A1(new_n80_), .A2(new_n84_), .B(new_n85_), .Y(new_n86_));
  NAND3x1_ASAP7_75t_R  g068(.A(new_n73_), .B(new_n78_), .C(new_n86_), .Y(new_n87_));
  AO21x1_ASAP7_75t_R   g069(.A1(p5), .A2(p6), .B(p7), .Y(new_n88_));
  AO21x1_ASAP7_75t_R   g070(.A1(p6), .A2(new_n44_), .B(new_n88_), .Y(new_n89_));
  NOR2x1_ASAP7_75t_R   g071(.A(p5), .B(p2), .Y(new_n90_));
  AO32x1_ASAP7_75t_R   g072(.A1(new_n58_), .A2(p5), .A3(new_n20_), .B1(new_n90_), .B2(p4), .Y(new_n91_));
  NOR2x1_ASAP7_75t_R   g073(.A(p5), .B(p0), .Y(new_n92_));
  AO32x1_ASAP7_75t_R   g074(.A1(new_n58_), .A2(p5), .A3(new_n20_), .B1(new_n92_), .B2(p4), .Y(new_n93_));
  AND3x1_ASAP7_75t_R   g075(.A(p1), .B(p2), .C(p3), .Y(new_n94_));
  NOR2x1_ASAP7_75t_R   g076(.A(p8), .B(new_n24_), .Y(new_n95_));
  AO21x1_ASAP7_75t_R   g077(.A1(new_n94_), .A2(new_n95_), .B(p9), .Y(new_n96_));
  AOI221x1_ASAP7_75t_R g078(.A1(new_n91_), .A2(new_n34_), .B1(new_n36_), .B2(new_n93_), .C(new_n96_), .Y(new_n97_));
  NAND2x1_ASAP7_75t_R  g079(.A(p9), .B(p7), .Y(new_n98_));
  NAND2x1_ASAP7_75t_R  g080(.A(p5), .B(p6), .Y(new_n99_));
  OR3x1_ASAP7_75t_R    g081(.A(new_n98_), .B(new_n99_), .C(p8), .Y(new_n100_));
  OAI21x1_ASAP7_75t_R  g082(.A1(new_n89_), .A2(new_n97_), .B(new_n100_), .Y(new_n101_));
  AOI21x1_ASAP7_75t_R  g083(.A1(new_n44_), .A2(new_n87_), .B(new_n101_), .Y(o1));
  NOR3x1_ASAP7_75t_R   g084(.A(new_n20_), .B(p5), .C(p2), .Y(new_n103_));
  INVx1_ASAP7_75t_R    g085(.A(new_n81_), .Y(new_n104_));
  AOI22x1_ASAP7_75t_R  g086(.A1(new_n103_), .A2(new_n104_), .B1(new_n20_), .B2(new_n33_), .Y(new_n105_));
  AOI21x1_ASAP7_75t_R  g087(.A1(p10), .A2(p0), .B(new_n37_), .Y(new_n106_));
  OAI21x1_ASAP7_75t_R  g088(.A1(new_n69_), .A2(new_n106_), .B(new_n29_), .Y(new_n107_));
  NAND2x1_ASAP7_75t_R  g089(.A(p1), .B(new_n50_), .Y(new_n108_));
  AOI21x1_ASAP7_75t_R  g090(.A1(new_n105_), .A2(new_n107_), .B(new_n108_), .Y(new_n109_));
  NOR2x1_ASAP7_75t_R   g091(.A(p2), .B(new_n29_), .Y(new_n110_));
  NOR3x1_ASAP7_75t_R   g092(.A(new_n36_), .B(p5), .C(p1), .Y(new_n111_));
  AND3x1_ASAP7_75t_R   g093(.A(new_n25_), .B(new_n28_), .C(p3), .Y(new_n112_));
  OAI21x1_ASAP7_75t_R  g094(.A1(new_n110_), .A2(new_n111_), .B(new_n112_), .Y(new_n113_));
  OR5x1_ASAP7_75t_R    g095(.A(new_n24_), .B(new_n29_), .C(new_n20_), .D(p6), .E(p1), .Y(new_n114_));
  AND3x1_ASAP7_75t_R   g096(.A(p4), .B(p2), .C(p3), .Y(new_n115_));
  AND2x2_ASAP7_75t_R   g097(.A(p5), .B(p6), .Y(new_n116_));
  NAND2x1_ASAP7_75t_R  g098(.A(p4), .B(p3), .Y(new_n117_));
  AOI22x1_ASAP7_75t_R  g099(.A1(new_n61_), .A2(new_n115_), .B1(new_n116_), .B2(new_n117_), .Y(new_n118_));
  NAND3x1_ASAP7_75t_R  g100(.A(new_n113_), .B(new_n114_), .C(new_n118_), .Y(new_n119_));
  AND3x1_ASAP7_75t_R   g101(.A(new_n29_), .B(p5), .C(p1), .Y(new_n120_));
  AO21x1_ASAP7_75t_R   g102(.A1(p4), .A2(new_n92_), .B(new_n37_), .Y(new_n121_));
  NAND2x1_ASAP7_75t_R  g103(.A(new_n37_), .B(new_n76_), .Y(new_n122_));
  OA211x2_ASAP7_75t_R  g104(.A1(new_n120_), .A2(new_n121_), .B(new_n28_), .C(new_n122_), .Y(new_n123_));
  NOR3x1_ASAP7_75t_R   g105(.A(new_n109_), .B(new_n119_), .C(new_n123_), .Y(new_n124_));
  NOR2x1_ASAP7_75t_R   g106(.A(new_n117_), .B(new_n55_), .Y(new_n125_));
  OAI21x1_ASAP7_75t_R  g107(.A1(new_n61_), .A2(new_n125_), .B(p7), .Y(new_n126_));
  OR3x1_ASAP7_75t_R    g108(.A(new_n58_), .B(new_n29_), .C(p7), .Y(new_n127_));
  AO21x1_ASAP7_75t_R   g109(.A1(new_n98_), .A2(new_n127_), .B(new_n99_), .Y(new_n128_));
  AND3x1_ASAP7_75t_R   g110(.A(new_n44_), .B(p6), .C(p4), .Y(new_n129_));
  NOR2x1_ASAP7_75t_R   g111(.A(p9), .B(p7), .Y(new_n130_));
  OR3x1_ASAP7_75t_R    g112(.A(new_n129_), .B(new_n58_), .C(new_n130_), .Y(new_n131_));
  OA211x2_ASAP7_75t_R  g113(.A1(p9), .A2(new_n126_), .B(new_n128_), .C(new_n131_), .Y(new_n132_));
  OAI21x1_ASAP7_75t_R  g114(.A1(new_n43_), .A2(new_n124_), .B(new_n132_), .Y(o2));
  NAND2x1_ASAP7_75t_R  g115(.A(new_n25_), .B(new_n29_), .Y(new_n134_));
  OR3x1_ASAP7_75t_R    g116(.A(new_n134_), .B(p5), .C(p3), .Y(new_n135_));
  OR3x1_ASAP7_75t_R    g117(.A(new_n76_), .B(new_n25_), .C(new_n28_), .Y(new_n136_));
  OR3x1_ASAP7_75t_R    g118(.A(new_n136_), .B(p1), .C(new_n20_), .Y(new_n137_));
  OA21x2_ASAP7_75t_R   g119(.A1(p7), .A2(new_n135_), .B(new_n137_), .Y(new_n138_));
  OR3x1_ASAP7_75t_R    g120(.A(new_n138_), .B(p2), .C(new_n43_), .Y(o3));
  AO21x1_ASAP7_75t_R   g121(.A1(new_n85_), .A2(new_n104_), .B(new_n125_), .Y(new_n140_));
  NOR2x1_ASAP7_75t_R   g122(.A(p7), .B(new_n36_), .Y(new_n141_));
  NAND3x1_ASAP7_75t_R  g123(.A(new_n140_), .B(p1), .C(new_n141_), .Y(new_n142_));
  NAND2x1_ASAP7_75t_R  g124(.A(p8), .B(new_n136_), .Y(new_n143_));
  OR5x1_ASAP7_75t_R    g125(.A(p8), .B(new_n141_), .C(new_n56_), .D(new_n99_), .E(new_n117_), .Y(new_n144_));
  AND2x2_ASAP7_75t_R   g126(.A(new_n143_), .B(new_n144_), .Y(new_n145_));
  OR3x1_ASAP7_75t_R    g127(.A(new_n34_), .B(new_n45_), .C(p6), .Y(new_n146_));
  AO21x1_ASAP7_75t_R   g128(.A1(new_n76_), .A2(new_n146_), .B(new_n37_), .Y(new_n147_));
  OA211x2_ASAP7_75t_R  g129(.A1(new_n20_), .A2(new_n134_), .B(new_n55_), .C(new_n28_), .Y(new_n148_));
  NAND2x1_ASAP7_75t_R  g130(.A(new_n147_), .B(new_n148_), .Y(new_n149_));
  AO31x2_ASAP7_75t_R   g131(.A1(new_n142_), .A2(new_n145_), .A3(new_n149_), .B(p9), .Y(o4));
  OR5x1_ASAP7_75t_R    g132(.A(new_n34_), .B(new_n134_), .C(new_n36_), .D(p7), .E(new_n81_), .Y(new_n151_));
  OAI21x1_ASAP7_75t_R  g133(.A1(new_n56_), .A2(new_n136_), .B(new_n151_), .Y(new_n152_));
  AND3x1_ASAP7_75t_R   g134(.A(new_n94_), .B(p5), .C(p4), .Y(new_n153_));
  INVx1_ASAP7_75t_R    g135(.A(new_n50_), .Y(new_n154_));
  OR3x1_ASAP7_75t_R    g136(.A(new_n153_), .B(new_n154_), .C(new_n85_), .Y(new_n155_));
  NAND2x1_ASAP7_75t_R  g137(.A(new_n42_), .B(new_n155_), .Y(new_n156_));
  AO21x1_ASAP7_75t_R   g138(.A1(p3), .A2(new_n152_), .B(new_n156_), .Y(o5));
  OR3x1_ASAP7_75t_R    g139(.A(new_n153_), .B(new_n43_), .C(new_n154_), .Y(o6));
endmodule


