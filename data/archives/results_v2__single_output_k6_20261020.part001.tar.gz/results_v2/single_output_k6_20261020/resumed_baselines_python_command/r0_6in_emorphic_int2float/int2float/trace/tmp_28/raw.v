// Benchmark "/tmp/" written by ABC on Tue Oct 20 17:46:16 2026

module \/tmp/  ( 
    p10, p6, p5, p1, p0, p7, p4, p3, p2, p9, p8,
    o0, o1, o2, o3, o4, o5, o6  );
  input  p10, p6, p5, p1, p0, p7, p4, p3, p2, p9, p8;
  output o0, o1, o2, o3, o4, o5, o6;
  wire new_n19_, new_n20_, new_n21_, new_n22_, new_n23_, new_n24_, new_n25_,
    new_n26_, new_n27_, new_n28_, new_n29_, new_n30_, new_n31_, new_n32_,
    new_n33_, new_n34_, new_n35_, new_n36_, new_n37_, new_n38_, new_n39_,
    new_n40_, new_n41_, new_n42_, new_n43_, new_n44_, new_n45_, new_n46_,
    new_n47_, new_n48_, new_n49_, new_n50_, new_n51_, new_n52_, new_n53_,
    new_n54_, new_n55_, new_n56_, new_n57_, new_n58_, new_n59_, new_n60_,
    new_n61_, new_n62_, new_n64_, new_n65_, new_n66_, new_n67_, new_n68_,
    new_n69_, new_n70_, new_n71_, new_n72_, new_n73_, new_n74_, new_n75_,
    new_n76_, new_n77_, new_n78_, new_n79_, new_n80_, new_n81_, new_n82_,
    new_n83_, new_n84_, new_n85_, new_n86_, new_n87_, new_n88_, new_n89_,
    new_n90_, new_n91_, new_n92_, new_n93_, new_n94_, new_n95_, new_n96_,
    new_n97_, new_n98_, new_n99_, new_n100_, new_n102_, new_n103_,
    new_n104_, new_n105_, new_n106_, new_n107_, new_n108_, new_n109_,
    new_n110_, new_n111_, new_n112_, new_n113_, new_n114_, new_n115_,
    new_n116_, new_n117_, new_n118_, new_n119_, new_n120_, new_n121_,
    new_n122_, new_n123_, new_n124_, new_n125_, new_n126_, new_n127_,
    new_n128_, new_n129_, new_n130_, new_n131_, new_n132_, new_n133_,
    new_n134_, new_n135_, new_n137_, new_n138_, new_n139_, new_n140_,
    new_n141_, new_n143_, new_n144_, new_n145_, new_n146_, new_n147_,
    new_n148_, new_n149_, new_n150_, new_n151_, new_n152_, new_n153_,
    new_n155_, new_n156_, new_n157_, new_n158_, new_n159_;
  INVx1_ASAP7_75t_R    g000(.A(p4), .Y(new_n19_));
  NAND2x1_ASAP7_75t_R  g001(.A(p0), .B(p3), .Y(new_n20_));
  INVx1_ASAP7_75t_R    g002(.A(p3), .Y(new_n21_));
  NAND2x1_ASAP7_75t_R  g003(.A(p7), .B(new_n21_), .Y(new_n22_));
  INVx1_ASAP7_75t_R    g004(.A(p10), .Y(new_n23_));
  AOI21x1_ASAP7_75t_R  g005(.A1(new_n20_), .A2(new_n22_), .B(new_n23_), .Y(new_n24_));
  INVx1_ASAP7_75t_R    g006(.A(p6), .Y(new_n25_));
  INVx1_ASAP7_75t_R    g007(.A(p5), .Y(new_n26_));
  NAND2x1_ASAP7_75t_R  g008(.A(new_n25_), .B(new_n26_), .Y(new_n27_));
  AO21x1_ASAP7_75t_R   g009(.A1(new_n23_), .A2(new_n20_), .B(new_n27_), .Y(new_n28_));
  NAND2x1_ASAP7_75t_R  g010(.A(p7), .B(p3), .Y(new_n29_));
  OAI21x1_ASAP7_75t_R  g011(.A1(new_n24_), .A2(new_n28_), .B(new_n29_), .Y(new_n30_));
  AOI21x1_ASAP7_75t_R  g012(.A1(p3), .A2(p2), .B(new_n25_), .Y(new_n31_));
  INVx1_ASAP7_75t_R    g013(.A(p2), .Y(new_n32_));
  NAND2x1_ASAP7_75t_R  g014(.A(new_n21_), .B(new_n32_), .Y(new_n33_));
  NOR2x1_ASAP7_75t_R   g015(.A(p6), .B(p1), .Y(new_n34_));
  AND3x1_ASAP7_75t_R   g016(.A(p0), .B(p4), .C(p2), .Y(new_n35_));
  AOI22x1_ASAP7_75t_R  g017(.A1(new_n31_), .A2(new_n33_), .B1(new_n34_), .B2(new_n35_), .Y(new_n36_));
  OAI22x1_ASAP7_75t_R  g018(.A1(new_n36_), .A2(p7), .B1(new_n19_), .B2(new_n22_), .Y(new_n37_));
  AOI21x1_ASAP7_75t_R  g019(.A1(new_n19_), .A2(new_n30_), .B(new_n37_), .Y(new_n38_));
  NOR2x1_ASAP7_75t_R   g020(.A(p9), .B(p8), .Y(new_n39_));
  INVx1_ASAP7_75t_R    g021(.A(new_n39_), .Y(new_n40_));
  INVx1_ASAP7_75t_R    g022(.A(p9), .Y(new_n41_));
  OA21x2_ASAP7_75t_R   g023(.A1(new_n25_), .A2(p3), .B(new_n29_), .Y(new_n42_));
  NAND2x1_ASAP7_75t_R  g024(.A(p3), .B(p2), .Y(new_n43_));
  INVx1_ASAP7_75t_R    g025(.A(p1), .Y(new_n44_));
  AND3x1_ASAP7_75t_R   g026(.A(new_n43_), .B(new_n44_), .C(p0), .Y(new_n45_));
  NOR2x1_ASAP7_75t_R   g027(.A(p5), .B(new_n19_), .Y(new_n46_));
  NAND3x1_ASAP7_75t_R  g028(.A(new_n42_), .B(new_n45_), .C(new_n46_), .Y(new_n47_));
  NOR2x1_ASAP7_75t_R   g029(.A(p6), .B(p7), .Y(new_n48_));
  INVx1_ASAP7_75t_R    g030(.A(p0), .Y(new_n49_));
  AO31x2_ASAP7_75t_R   g031(.A1(new_n48_), .A2(p1), .A3(new_n49_), .B(p8), .Y(new_n50_));
  AND3x1_ASAP7_75t_R   g032(.A(new_n19_), .B(p5), .C(p8), .Y(new_n51_));
  AOI21x1_ASAP7_75t_R  g033(.A1(new_n46_), .A2(new_n50_), .B(new_n51_), .Y(new_n52_));
  NAND2x1_ASAP7_75t_R  g034(.A(new_n47_), .B(new_n52_), .Y(new_n53_));
  NOR2x1_ASAP7_75t_R   g035(.A(p6), .B(new_n26_), .Y(new_n54_));
  NOR2x1_ASAP7_75t_R   g036(.A(p7), .B(p8), .Y(new_n55_));
  XOR2x2_ASAP7_75t_R   g037(.A(p1), .B(p2), .Y(new_n56_));
  AO21x1_ASAP7_75t_R   g038(.A1(new_n55_), .A2(new_n56_), .B(p9), .Y(new_n57_));
  AND3x1_ASAP7_75t_R   g039(.A(p5), .B(p7), .C(p8), .Y(new_n58_));
  NOR2x1_ASAP7_75t_R   g040(.A(p5), .B(new_n25_), .Y(new_n59_));
  OA21x2_ASAP7_75t_R   g041(.A1(new_n58_), .A2(new_n59_), .B(p9), .Y(new_n60_));
  AO21x1_ASAP7_75t_R   g042(.A1(new_n54_), .A2(new_n57_), .B(new_n60_), .Y(new_n61_));
  AOI21x1_ASAP7_75t_R  g043(.A1(new_n41_), .A2(new_n53_), .B(new_n61_), .Y(new_n62_));
  OAI21x1_ASAP7_75t_R  g044(.A1(new_n38_), .A2(new_n40_), .B(new_n62_), .Y(o0));
  INVx1_ASAP7_75t_R    g045(.A(p8), .Y(new_n64_));
  NOR2x1_ASAP7_75t_R   g046(.A(p6), .B(new_n64_), .Y(new_n65_));
  AO21x1_ASAP7_75t_R   g047(.A1(new_n55_), .A2(new_n31_), .B(new_n65_), .Y(new_n66_));
  OAI21x1_ASAP7_75t_R  g048(.A1(p6), .A2(p5), .B(new_n21_), .Y(new_n67_));
  OAI21x1_ASAP7_75t_R  g049(.A1(p7), .A2(p8), .B(p3), .Y(new_n68_));
  AO21x1_ASAP7_75t_R   g050(.A1(p1), .A2(p0), .B(p6), .Y(new_n69_));
  AND5x1_ASAP7_75t_R   g051(.A(p4), .B(new_n67_), .C(p2), .D(new_n68_), .E(new_n69_), .Y(new_n70_));
  AOI21x1_ASAP7_75t_R  g052(.A1(new_n19_), .A2(new_n66_), .B(new_n70_), .Y(new_n71_));
  AND2x2_ASAP7_75t_R   g053(.A(p5), .B(p4), .Y(new_n72_));
  NOR2x1_ASAP7_75t_R   g054(.A(p3), .B(p8), .Y(new_n73_));
  OR3x1_ASAP7_75t_R    g055(.A(new_n65_), .B(new_n72_), .C(new_n73_), .Y(new_n74_));
  OAI21x1_ASAP7_75t_R  g056(.A1(new_n73_), .A2(new_n65_), .B(p5), .Y(new_n75_));
  INVx1_ASAP7_75t_R    g057(.A(new_n55_), .Y(new_n76_));
  NAND3x1_ASAP7_75t_R  g058(.A(new_n74_), .B(new_n75_), .C(new_n76_), .Y(new_n77_));
  OAI22x1_ASAP7_75t_R  g059(.A1(p6), .A2(p1), .B1(p3), .B2(p8), .Y(new_n78_));
  AO22x1_ASAP7_75t_R   g060(.A1(p7), .A2(new_n64_), .B1(new_n49_), .B2(new_n78_), .Y(new_n79_));
  NAND2x1_ASAP7_75t_R  g061(.A(p1), .B(p0), .Y(new_n80_));
  NAND2x1_ASAP7_75t_R  g062(.A(p3), .B(new_n25_), .Y(new_n81_));
  NOR2x1_ASAP7_75t_R   g063(.A(p10), .B(new_n44_), .Y(new_n82_));
  AOI211x1_ASAP7_75t_R g064(.A1(p10), .A2(new_n80_), .B(new_n81_), .C(new_n82_), .Y(new_n83_));
  NOR2x1_ASAP7_75t_R   g065(.A(p5), .B(p4), .Y(new_n84_));
  OAI21x1_ASAP7_75t_R  g066(.A1(new_n79_), .A2(new_n83_), .B(new_n84_), .Y(new_n85_));
  NAND3x1_ASAP7_75t_R  g067(.A(new_n71_), .B(new_n77_), .C(new_n85_), .Y(new_n86_));
  AO21x1_ASAP7_75t_R   g068(.A1(p6), .A2(p5), .B(p7), .Y(new_n87_));
  AO21x1_ASAP7_75t_R   g069(.A1(p6), .A2(new_n41_), .B(new_n87_), .Y(new_n88_));
  NOR2x1_ASAP7_75t_R   g070(.A(p5), .B(p2), .Y(new_n89_));
  AO32x1_ASAP7_75t_R   g071(.A1(p5), .A2(new_n21_), .A3(new_n64_), .B1(new_n89_), .B2(p4), .Y(new_n90_));
  NOR2x1_ASAP7_75t_R   g072(.A(p5), .B(p0), .Y(new_n91_));
  AO32x1_ASAP7_75t_R   g073(.A1(p5), .A2(new_n21_), .A3(new_n64_), .B1(new_n91_), .B2(p4), .Y(new_n92_));
  AND3x1_ASAP7_75t_R   g074(.A(p1), .B(p3), .C(p2), .Y(new_n93_));
  NOR2x1_ASAP7_75t_R   g075(.A(p8), .B(new_n26_), .Y(new_n94_));
  AO21x1_ASAP7_75t_R   g076(.A1(new_n93_), .A2(new_n94_), .B(p9), .Y(new_n95_));
  AOI221x1_ASAP7_75t_R g077(.A1(new_n90_), .A2(new_n44_), .B1(new_n32_), .B2(new_n92_), .C(new_n95_), .Y(new_n96_));
  NAND2x1_ASAP7_75t_R  g078(.A(p7), .B(p9), .Y(new_n97_));
  NAND2x1_ASAP7_75t_R  g079(.A(p6), .B(p5), .Y(new_n98_));
  OR3x1_ASAP7_75t_R    g080(.A(new_n97_), .B(new_n98_), .C(p8), .Y(new_n99_));
  OAI21x1_ASAP7_75t_R  g081(.A1(new_n88_), .A2(new_n96_), .B(new_n99_), .Y(new_n100_));
  AOI21x1_ASAP7_75t_R  g082(.A1(new_n41_), .A2(new_n86_), .B(new_n100_), .Y(o1));
  AND2x2_ASAP7_75t_R   g083(.A(p4), .B(p3), .Y(new_n102_));
  AO21x1_ASAP7_75t_R   g084(.A1(new_n102_), .A2(new_n54_), .B(new_n59_), .Y(new_n103_));
  OA21x2_ASAP7_75t_R   g085(.A1(new_n25_), .A2(new_n19_), .B(p8), .Y(new_n104_));
  AO21x1_ASAP7_75t_R   g086(.A1(new_n41_), .A2(new_n103_), .B(new_n104_), .Y(new_n105_));
  INVx1_ASAP7_75t_R    g087(.A(new_n98_), .Y(new_n106_));
  INVx1_ASAP7_75t_R    g088(.A(p7), .Y(new_n107_));
  AND3x1_ASAP7_75t_R   g089(.A(p6), .B(p5), .C(p4), .Y(new_n108_));
  AO21x1_ASAP7_75t_R   g090(.A1(new_n107_), .A2(new_n108_), .B(p9), .Y(new_n109_));
  AO32x1_ASAP7_75t_R   g091(.A1(p7), .A2(p9), .A3(new_n106_), .B1(new_n109_), .B2(p8), .Y(new_n110_));
  AOI21x1_ASAP7_75t_R  g092(.A1(p7), .A2(new_n105_), .B(new_n110_), .Y(new_n111_));
  AND3x1_ASAP7_75t_R   g093(.A(new_n21_), .B(p4), .C(p2), .Y(new_n112_));
  AND4x2_ASAP7_75t_R   g094(.A(new_n26_), .B(new_n32_), .C(p10), .D(p3), .Y(new_n113_));
  OAI21x1_ASAP7_75t_R  g095(.A1(new_n112_), .A2(new_n113_), .B(p0), .Y(new_n114_));
  NOR2x1_ASAP7_75t_R   g096(.A(p5), .B(p3), .Y(new_n115_));
  AND2x2_ASAP7_75t_R   g097(.A(p10), .B(p0), .Y(new_n116_));
  NOR2x1_ASAP7_75t_R   g098(.A(new_n43_), .B(new_n116_), .Y(new_n117_));
  OAI21x1_ASAP7_75t_R  g099(.A1(new_n115_), .A2(new_n117_), .B(new_n19_), .Y(new_n118_));
  NAND2x1_ASAP7_75t_R  g100(.A(p1), .B(new_n48_), .Y(new_n119_));
  AOI21x1_ASAP7_75t_R  g101(.A1(new_n114_), .A2(new_n118_), .B(new_n119_), .Y(new_n120_));
  AND3x1_ASAP7_75t_R   g102(.A(new_n19_), .B(p5), .C(p1), .Y(new_n121_));
  AO21x1_ASAP7_75t_R   g103(.A1(p4), .A2(new_n91_), .B(new_n43_), .Y(new_n122_));
  NAND2x1_ASAP7_75t_R  g104(.A(p5), .B(p4), .Y(new_n123_));
  AOI21x1_ASAP7_75t_R  g105(.A1(new_n43_), .A2(new_n123_), .B(p7), .Y(new_n124_));
  OAI21x1_ASAP7_75t_R  g106(.A1(new_n121_), .A2(new_n122_), .B(new_n124_), .Y(new_n125_));
  AND3x1_ASAP7_75t_R   g107(.A(p4), .B(p3), .C(p2), .Y(new_n126_));
  NOR3x1_ASAP7_75t_R   g108(.A(new_n26_), .B(p6), .C(p1), .Y(new_n127_));
  AOI21x1_ASAP7_75t_R  g109(.A1(p4), .A2(p3), .B(new_n98_), .Y(new_n128_));
  AOI221x1_ASAP7_75t_R g110(.A1(new_n59_), .A2(new_n126_), .B1(new_n127_), .B2(new_n102_), .C(new_n128_), .Y(new_n129_));
  NOR2x1_ASAP7_75t_R   g111(.A(p2), .B(new_n19_), .Y(new_n130_));
  AND3x1_ASAP7_75t_R   g112(.A(new_n26_), .B(new_n44_), .C(p2), .Y(new_n131_));
  AND3x1_ASAP7_75t_R   g113(.A(new_n25_), .B(new_n107_), .C(p3), .Y(new_n132_));
  OAI21x1_ASAP7_75t_R  g114(.A1(new_n130_), .A2(new_n131_), .B(new_n132_), .Y(new_n133_));
  NAND3x1_ASAP7_75t_R  g115(.A(new_n125_), .B(new_n129_), .C(new_n133_), .Y(new_n134_));
  OAI21x1_ASAP7_75t_R  g116(.A1(new_n120_), .A2(new_n134_), .B(new_n39_), .Y(new_n135_));
  NAND2x1_ASAP7_75t_R  g117(.A(new_n111_), .B(new_n135_), .Y(o2));
  NOR2x1_ASAP7_75t_R   g118(.A(p6), .B(p4), .Y(new_n137_));
  AND3x1_ASAP7_75t_R   g119(.A(new_n115_), .B(new_n137_), .C(new_n107_), .Y(new_n138_));
  AND3x1_ASAP7_75t_R   g120(.A(new_n72_), .B(p6), .C(p7), .Y(new_n139_));
  AND3x1_ASAP7_75t_R   g121(.A(new_n139_), .B(new_n44_), .C(p3), .Y(new_n140_));
  NOR2x1_ASAP7_75t_R   g122(.A(new_n138_), .B(new_n140_), .Y(new_n141_));
  OR3x1_ASAP7_75t_R    g123(.A(new_n141_), .B(p2), .C(new_n40_), .Y(o3));
  OR3x1_ASAP7_75t_R    g124(.A(new_n44_), .B(new_n49_), .C(p6), .Y(new_n143_));
  AOI21x1_ASAP7_75t_R  g125(.A1(new_n123_), .A2(new_n143_), .B(new_n43_), .Y(new_n144_));
  AO21x1_ASAP7_75t_R   g126(.A1(p3), .A2(new_n137_), .B(new_n54_), .Y(new_n145_));
  OR3x1_ASAP7_75t_R    g127(.A(new_n144_), .B(p7), .C(new_n145_), .Y(new_n146_));
  AO32x1_ASAP7_75t_R   g128(.A1(new_n72_), .A2(new_n25_), .A3(p3), .B1(new_n116_), .B2(new_n84_), .Y(new_n147_));
  AND3x1_ASAP7_75t_R   g129(.A(new_n107_), .B(p1), .C(p2), .Y(new_n148_));
  NAND2x1_ASAP7_75t_R  g130(.A(new_n44_), .B(new_n32_), .Y(new_n149_));
  NAND2x1_ASAP7_75t_R  g131(.A(p2), .B(new_n107_), .Y(new_n150_));
  AND5x1_ASAP7_75t_R   g132(.A(new_n64_), .B(new_n149_), .C(new_n106_), .D(new_n150_), .E(new_n102_), .Y(new_n151_));
  NOR2x1_ASAP7_75t_R   g133(.A(new_n64_), .B(new_n139_), .Y(new_n152_));
  AOI211x1_ASAP7_75t_R g134(.A1(new_n147_), .A2(new_n148_), .B(new_n151_), .C(new_n152_), .Y(new_n153_));
  AO21x1_ASAP7_75t_R   g135(.A1(new_n146_), .A2(new_n153_), .B(p9), .Y(o4));
  AO32x1_ASAP7_75t_R   g136(.A1(new_n116_), .A2(new_n137_), .A3(new_n148_), .B1(new_n139_), .B2(new_n149_), .Y(new_n155_));
  AND2x2_ASAP7_75t_R   g137(.A(new_n72_), .B(new_n93_), .Y(new_n156_));
  INVx1_ASAP7_75t_R    g138(.A(new_n48_), .Y(new_n157_));
  OR3x1_ASAP7_75t_R    g139(.A(new_n156_), .B(new_n157_), .C(new_n84_), .Y(new_n158_));
  NAND2x1_ASAP7_75t_R  g140(.A(new_n39_), .B(new_n158_), .Y(new_n159_));
  AO21x1_ASAP7_75t_R   g141(.A1(p3), .A2(new_n155_), .B(new_n159_), .Y(o5));
  OR3x1_ASAP7_75t_R    g142(.A(new_n156_), .B(new_n157_), .C(new_n40_), .Y(o6));
endmodule


