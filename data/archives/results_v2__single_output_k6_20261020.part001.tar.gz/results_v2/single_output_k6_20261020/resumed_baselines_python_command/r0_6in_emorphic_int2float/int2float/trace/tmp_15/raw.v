// Benchmark "/tmp/" written by ABC on Tue Oct 20 17:46:15 2026

module \/tmp/  ( 
    p1, p10, p7, p9, p3, p2, p6, p4, p5, p8, p0,
    o0, o1, o2, o3, o4, o5, o6  );
  input  p1, p10, p7, p9, p3, p2, p6, p4, p5, p8, p0;
  output o0, o1, o2, o3, o4, o5, o6;
  wire new_n19_, new_n20_, new_n21_, new_n22_, new_n23_, new_n24_, new_n25_,
    new_n26_, new_n27_, new_n28_, new_n29_, new_n30_, new_n31_, new_n32_,
    new_n33_, new_n34_, new_n35_, new_n36_, new_n37_, new_n38_, new_n39_,
    new_n40_, new_n41_, new_n42_, new_n43_, new_n44_, new_n45_, new_n46_,
    new_n47_, new_n48_, new_n49_, new_n50_, new_n51_, new_n52_, new_n53_,
    new_n54_, new_n55_, new_n56_, new_n57_, new_n58_, new_n59_, new_n60_,
    new_n61_, new_n62_, new_n63_, new_n64_, new_n66_, new_n67_, new_n68_,
    new_n69_, new_n70_, new_n71_, new_n72_, new_n73_, new_n74_, new_n75_,
    new_n76_, new_n77_, new_n78_, new_n79_, new_n80_, new_n81_, new_n82_,
    new_n83_, new_n84_, new_n85_, new_n86_, new_n87_, new_n88_, new_n89_,
    new_n90_, new_n91_, new_n92_, new_n93_, new_n94_, new_n95_, new_n96_,
    new_n97_, new_n98_, new_n99_, new_n101_, new_n102_, new_n103_,
    new_n104_, new_n105_, new_n106_, new_n107_, new_n108_, new_n109_,
    new_n110_, new_n111_, new_n112_, new_n113_, new_n114_, new_n115_,
    new_n116_, new_n117_, new_n118_, new_n119_, new_n120_, new_n121_,
    new_n122_, new_n123_, new_n124_, new_n125_, new_n126_, new_n127_,
    new_n128_, new_n130_, new_n131_, new_n132_, new_n134_, new_n135_,
    new_n136_, new_n137_, new_n138_, new_n139_, new_n140_, new_n141_,
    new_n142_, new_n143_, new_n144_, new_n145_, new_n147_, new_n148_,
    new_n149_, new_n150_, new_n151_, new_n152_;
  INVx1_ASAP7_75t_R    g000(.A(p3), .Y(new_n19_));
  INVx1_ASAP7_75t_R    g001(.A(p4), .Y(new_n20_));
  AO21x1_ASAP7_75t_R   g002(.A1(p7), .A2(new_n19_), .B(new_n20_), .Y(new_n21_));
  INVx1_ASAP7_75t_R    g003(.A(p10), .Y(new_n22_));
  NAND2x1_ASAP7_75t_R  g004(.A(p3), .B(p0), .Y(new_n23_));
  AOI211x1_ASAP7_75t_R g005(.A1(new_n22_), .A2(new_n23_), .B(p6), .C(p5), .Y(new_n24_));
  NAND2x1_ASAP7_75t_R  g006(.A(p7), .B(new_n19_), .Y(new_n25_));
  AO21x1_ASAP7_75t_R   g007(.A1(new_n23_), .A2(new_n25_), .B(new_n22_), .Y(new_n26_));
  AO21x1_ASAP7_75t_R   g008(.A1(p7), .A2(p3), .B(p4), .Y(new_n27_));
  AO21x1_ASAP7_75t_R   g009(.A1(new_n24_), .A2(new_n26_), .B(new_n27_), .Y(new_n28_));
  INVx1_ASAP7_75t_R    g010(.A(p1), .Y(new_n29_));
  INVx1_ASAP7_75t_R    g011(.A(p6), .Y(new_n30_));
  AND5x1_ASAP7_75t_R   g012(.A(new_n29_), .B(new_n30_), .C(p2), .D(p4), .E(p0), .Y(new_n31_));
  INVx1_ASAP7_75t_R    g013(.A(p2), .Y(new_n32_));
  NAND2x1_ASAP7_75t_R  g014(.A(p3), .B(new_n32_), .Y(new_n33_));
  NAND2x1_ASAP7_75t_R  g015(.A(p2), .B(new_n19_), .Y(new_n34_));
  AOI21x1_ASAP7_75t_R  g016(.A1(new_n33_), .A2(new_n34_), .B(new_n30_), .Y(new_n35_));
  INVx1_ASAP7_75t_R    g017(.A(p7), .Y(new_n36_));
  OA21x2_ASAP7_75t_R   g018(.A1(new_n31_), .A2(new_n35_), .B(new_n36_), .Y(new_n37_));
  AOI21x1_ASAP7_75t_R  g019(.A1(new_n21_), .A2(new_n28_), .B(new_n37_), .Y(new_n38_));
  NOR2x1_ASAP7_75t_R   g020(.A(p9), .B(p8), .Y(new_n39_));
  INVx1_ASAP7_75t_R    g021(.A(new_n39_), .Y(new_n40_));
  INVx1_ASAP7_75t_R    g022(.A(p9), .Y(new_n41_));
  NOR2x1_ASAP7_75t_R   g023(.A(p5), .B(new_n20_), .Y(new_n42_));
  INVx1_ASAP7_75t_R    g024(.A(new_n42_), .Y(new_n43_));
  NOR2x1_ASAP7_75t_R   g025(.A(p3), .B(new_n30_), .Y(new_n44_));
  INVx1_ASAP7_75t_R    g026(.A(p0), .Y(new_n45_));
  AND2x2_ASAP7_75t_R   g027(.A(p7), .B(p3), .Y(new_n46_));
  AND2x2_ASAP7_75t_R   g028(.A(p3), .B(p2), .Y(new_n47_));
  OR5x1_ASAP7_75t_R    g029(.A(p1), .B(new_n44_), .C(new_n45_), .D(new_n46_), .E(new_n47_), .Y(new_n48_));
  NOR2x1_ASAP7_75t_R   g030(.A(p7), .B(p6), .Y(new_n49_));
  AO31x2_ASAP7_75t_R   g031(.A1(new_n49_), .A2(p1), .A3(new_n45_), .B(p8), .Y(new_n50_));
  AND3x1_ASAP7_75t_R   g032(.A(new_n20_), .B(p5), .C(p8), .Y(new_n51_));
  AOI21x1_ASAP7_75t_R  g033(.A1(new_n42_), .A2(new_n50_), .B(new_n51_), .Y(new_n52_));
  OAI21x1_ASAP7_75t_R  g034(.A1(new_n43_), .A2(new_n48_), .B(new_n52_), .Y(new_n53_));
  INVx1_ASAP7_75t_R    g035(.A(p5), .Y(new_n54_));
  NOR2x1_ASAP7_75t_R   g036(.A(p6), .B(new_n54_), .Y(new_n55_));
  INVx1_ASAP7_75t_R    g037(.A(p8), .Y(new_n56_));
  NAND2x1_ASAP7_75t_R  g038(.A(new_n36_), .B(new_n56_), .Y(new_n57_));
  XNOR2x2_ASAP7_75t_R  g039(.A(p1), .B(p2), .Y(new_n58_));
  OAI21x1_ASAP7_75t_R  g040(.A1(new_n57_), .A2(new_n58_), .B(new_n41_), .Y(new_n59_));
  AND3x1_ASAP7_75t_R   g041(.A(p7), .B(p5), .C(p8), .Y(new_n60_));
  NOR2x1_ASAP7_75t_R   g042(.A(p5), .B(new_n30_), .Y(new_n61_));
  OA21x2_ASAP7_75t_R   g043(.A1(new_n60_), .A2(new_n61_), .B(p9), .Y(new_n62_));
  AO21x1_ASAP7_75t_R   g044(.A1(new_n55_), .A2(new_n59_), .B(new_n62_), .Y(new_n63_));
  AOI21x1_ASAP7_75t_R  g045(.A1(new_n41_), .A2(new_n53_), .B(new_n63_), .Y(new_n64_));
  OAI21x1_ASAP7_75t_R  g046(.A1(new_n38_), .A2(new_n40_), .B(new_n64_), .Y(o0));
  NOR2x1_ASAP7_75t_R   g047(.A(p3), .B(p8), .Y(new_n66_));
  AO21x1_ASAP7_75t_R   g048(.A1(new_n36_), .A2(new_n56_), .B(new_n54_), .Y(new_n67_));
  AOI211x1_ASAP7_75t_R g049(.A1(new_n30_), .A2(p8), .B(new_n66_), .C(new_n67_), .Y(new_n68_));
  OR3x1_ASAP7_75t_R    g050(.A(new_n19_), .B(p7), .C(p8), .Y(new_n69_));
  OR3x1_ASAP7_75t_R    g051(.A(p3), .B(p6), .C(p5), .Y(new_n70_));
  NAND2x1_ASAP7_75t_R  g052(.A(p1), .B(p0), .Y(new_n71_));
  AO21x1_ASAP7_75t_R   g053(.A1(new_n30_), .A2(new_n71_), .B(new_n32_), .Y(new_n72_));
  AOI21x1_ASAP7_75t_R  g054(.A1(new_n69_), .A2(new_n70_), .B(new_n72_), .Y(new_n73_));
  OAI21x1_ASAP7_75t_R  g055(.A1(new_n68_), .A2(new_n73_), .B(p4), .Y(new_n74_));
  AO21x1_ASAP7_75t_R   g056(.A1(p3), .A2(p2), .B(new_n30_), .Y(new_n75_));
  NAND2x1_ASAP7_75t_R  g057(.A(p8), .B(new_n30_), .Y(new_n76_));
  OAI21x1_ASAP7_75t_R  g058(.A1(new_n57_), .A2(new_n75_), .B(new_n76_), .Y(new_n77_));
  NAND2x1_ASAP7_75t_R  g059(.A(p7), .B(new_n66_), .Y(new_n78_));
  NAND2x1_ASAP7_75t_R  g060(.A(new_n76_), .B(new_n78_), .Y(new_n79_));
  AOI22x1_ASAP7_75t_R  g061(.A1(new_n77_), .A2(new_n20_), .B1(new_n54_), .B2(new_n79_), .Y(new_n80_));
  NOR2x1_ASAP7_75t_R   g062(.A(p3), .B(p0), .Y(new_n81_));
  OA21x2_ASAP7_75t_R   g063(.A1(p7), .A2(new_n81_), .B(new_n56_), .Y(new_n82_));
  AO21x1_ASAP7_75t_R   g064(.A1(p10), .A2(p0), .B(p1), .Y(new_n83_));
  NAND3x1_ASAP7_75t_R  g065(.A(p1), .B(p10), .C(p0), .Y(new_n84_));
  AOI221x1_ASAP7_75t_R g066(.A1(new_n19_), .A2(p0), .B1(new_n83_), .B2(new_n84_), .C(p6), .Y(new_n85_));
  NOR2x1_ASAP7_75t_R   g067(.A(p4), .B(p5), .Y(new_n86_));
  OAI21x1_ASAP7_75t_R  g068(.A1(new_n82_), .A2(new_n85_), .B(new_n86_), .Y(new_n87_));
  NAND3x1_ASAP7_75t_R  g069(.A(new_n74_), .B(new_n80_), .C(new_n87_), .Y(new_n88_));
  AND3x1_ASAP7_75t_R   g070(.A(new_n56_), .B(p1), .C(p2), .Y(new_n89_));
  OR3x1_ASAP7_75t_R    g071(.A(new_n89_), .B(new_n54_), .C(new_n66_), .Y(new_n90_));
  OA22x2_ASAP7_75t_R   g072(.A1(new_n34_), .A2(new_n29_), .B1(p5), .B2(new_n71_), .Y(new_n91_));
  INVx1_ASAP7_75t_R    g073(.A(new_n86_), .Y(new_n92_));
  NAND2x1_ASAP7_75t_R  g074(.A(p2), .B(new_n54_), .Y(new_n93_));
  AND3x1_ASAP7_75t_R   g075(.A(new_n92_), .B(new_n93_), .C(new_n30_), .Y(new_n94_));
  NAND3x1_ASAP7_75t_R  g076(.A(new_n90_), .B(new_n91_), .C(new_n94_), .Y(new_n95_));
  AND2x2_ASAP7_75t_R   g077(.A(p6), .B(p5), .Y(new_n96_));
  AOI21x1_ASAP7_75t_R  g078(.A1(new_n56_), .A2(new_n96_), .B(new_n36_), .Y(new_n97_));
  AO21x1_ASAP7_75t_R   g079(.A1(new_n36_), .A2(new_n96_), .B(new_n97_), .Y(new_n98_));
  AOI21x1_ASAP7_75t_R  g080(.A1(new_n41_), .A2(new_n95_), .B(new_n98_), .Y(new_n99_));
  AOI21x1_ASAP7_75t_R  g081(.A1(new_n41_), .A2(new_n88_), .B(new_n99_), .Y(o1));
  NAND2x1_ASAP7_75t_R  g082(.A(p3), .B(new_n29_), .Y(new_n101_));
  OAI22x1_ASAP7_75t_R  g083(.A1(new_n93_), .A2(new_n101_), .B1(new_n33_), .B2(new_n20_), .Y(new_n102_));
  OAI21x1_ASAP7_75t_R  g084(.A1(p1), .A2(new_n102_), .B(new_n49_), .Y(new_n103_));
  NAND2x1_ASAP7_75t_R  g085(.A(p10), .B(p0), .Y(new_n104_));
  NOR2x1_ASAP7_75t_R   g086(.A(p3), .B(p5), .Y(new_n105_));
  AO21x1_ASAP7_75t_R   g087(.A1(new_n104_), .A2(new_n47_), .B(new_n105_), .Y(new_n106_));
  NAND2x1_ASAP7_75t_R  g088(.A(p10), .B(new_n54_), .Y(new_n107_));
  NAND3x1_ASAP7_75t_R  g089(.A(new_n19_), .B(p2), .C(p4), .Y(new_n108_));
  OAI21x1_ASAP7_75t_R  g090(.A1(new_n33_), .A2(new_n107_), .B(new_n108_), .Y(new_n109_));
  AOI221x1_ASAP7_75t_R g091(.A1(new_n20_), .A2(new_n106_), .B1(new_n109_), .B2(p0), .C(new_n102_), .Y(new_n110_));
  AND2x2_ASAP7_75t_R   g092(.A(p4), .B(p5), .Y(new_n111_));
  AND3x1_ASAP7_75t_R   g093(.A(new_n111_), .B(p3), .C(new_n30_), .Y(new_n112_));
  NAND3x1_ASAP7_75t_R  g094(.A(new_n54_), .B(new_n45_), .C(p4), .Y(new_n113_));
  NAND3x1_ASAP7_75t_R  g095(.A(new_n20_), .B(p1), .C(p5), .Y(new_n114_));
  NAND3x1_ASAP7_75t_R  g096(.A(new_n113_), .B(new_n114_), .C(new_n47_), .Y(new_n115_));
  OA21x2_ASAP7_75t_R   g097(.A1(new_n47_), .A2(new_n111_), .B(new_n36_), .Y(new_n116_));
  NAND2x1_ASAP7_75t_R  g098(.A(p3), .B(p4), .Y(new_n117_));
  AND3x1_ASAP7_75t_R   g099(.A(p3), .B(p2), .C(p4), .Y(new_n118_));
  AO22x1_ASAP7_75t_R   g100(.A1(new_n96_), .A2(new_n117_), .B1(new_n118_), .B2(new_n61_), .Y(new_n119_));
  AOI221x1_ASAP7_75t_R g101(.A1(new_n29_), .A2(new_n112_), .B1(new_n115_), .B2(new_n116_), .C(new_n119_), .Y(new_n120_));
  OAI21x1_ASAP7_75t_R  g102(.A1(new_n103_), .A2(new_n110_), .B(new_n120_), .Y(new_n121_));
  OAI21x1_ASAP7_75t_R  g103(.A1(new_n61_), .A2(new_n112_), .B(p7), .Y(new_n122_));
  OR3x1_ASAP7_75t_R    g104(.A(new_n20_), .B(new_n56_), .C(p7), .Y(new_n123_));
  OAI21x1_ASAP7_75t_R  g105(.A1(new_n36_), .A2(new_n41_), .B(new_n123_), .Y(new_n124_));
  OR3x1_ASAP7_75t_R    g106(.A(new_n30_), .B(new_n20_), .C(p9), .Y(new_n125_));
  OA21x2_ASAP7_75t_R   g107(.A1(p7), .A2(p9), .B(p8), .Y(new_n126_));
  AOI22x1_ASAP7_75t_R  g108(.A1(new_n124_), .A2(new_n96_), .B1(new_n125_), .B2(new_n126_), .Y(new_n127_));
  OAI21x1_ASAP7_75t_R  g109(.A1(p9), .A2(new_n122_), .B(new_n127_), .Y(new_n128_));
  AO21x1_ASAP7_75t_R   g110(.A1(new_n39_), .A2(new_n121_), .B(new_n128_), .Y(o2));
  OR4x2_ASAP7_75t_R    g111(.A(new_n36_), .B(new_n30_), .C(new_n20_), .D(new_n54_), .Y(new_n130_));
  OR5x1_ASAP7_75t_R    g112(.A(p7), .B(p3), .C(p6), .D(p4), .E(p5), .Y(new_n131_));
  OA21x2_ASAP7_75t_R   g113(.A1(new_n101_), .A2(new_n130_), .B(new_n131_), .Y(new_n132_));
  OR3x1_ASAP7_75t_R    g114(.A(new_n132_), .B(p2), .C(new_n40_), .Y(o3));
  NOR2x1_ASAP7_75t_R   g115(.A(p6), .B(new_n71_), .Y(new_n134_));
  OA21x2_ASAP7_75t_R   g116(.A1(new_n111_), .A2(new_n134_), .B(new_n47_), .Y(new_n135_));
  AND3x1_ASAP7_75t_R   g117(.A(new_n30_), .B(new_n20_), .C(p3), .Y(new_n136_));
  OR4x2_ASAP7_75t_R    g118(.A(new_n135_), .B(p7), .C(new_n55_), .D(new_n136_), .Y(new_n137_));
  AND3x1_ASAP7_75t_R   g119(.A(new_n86_), .B(p10), .C(p0), .Y(new_n138_));
  NOR2x1_ASAP7_75t_R   g120(.A(new_n138_), .B(new_n112_), .Y(new_n139_));
  NAND2x1_ASAP7_75t_R  g121(.A(p2), .B(new_n36_), .Y(new_n140_));
  OR3x1_ASAP7_75t_R    g122(.A(new_n139_), .B(new_n29_), .C(new_n140_), .Y(new_n141_));
  NAND2x1_ASAP7_75t_R  g123(.A(new_n29_), .B(new_n32_), .Y(new_n142_));
  INVx1_ASAP7_75t_R    g124(.A(new_n117_), .Y(new_n143_));
  AND5x1_ASAP7_75t_R   g125(.A(new_n56_), .B(new_n142_), .C(new_n143_), .D(new_n140_), .E(new_n96_), .Y(new_n144_));
  AOI21x1_ASAP7_75t_R  g126(.A1(p8), .A2(new_n130_), .B(new_n144_), .Y(new_n145_));
  AO31x2_ASAP7_75t_R   g127(.A1(new_n137_), .A2(new_n141_), .A3(new_n145_), .B(p9), .Y(o4));
  OR5x1_ASAP7_75t_R    g128(.A(p7), .B(new_n84_), .C(new_n32_), .D(p6), .E(p4), .Y(new_n147_));
  AO21x1_ASAP7_75t_R   g129(.A1(new_n29_), .A2(new_n32_), .B(new_n130_), .Y(new_n148_));
  AO21x1_ASAP7_75t_R   g130(.A1(new_n147_), .A2(new_n148_), .B(new_n19_), .Y(new_n149_));
  AND3x1_ASAP7_75t_R   g131(.A(new_n47_), .B(new_n111_), .C(p1), .Y(new_n150_));
  INVx1_ASAP7_75t_R    g132(.A(new_n49_), .Y(new_n151_));
  OR3x1_ASAP7_75t_R    g133(.A(new_n150_), .B(new_n151_), .C(new_n86_), .Y(new_n152_));
  NAND3x1_ASAP7_75t_R  g134(.A(new_n149_), .B(new_n39_), .C(new_n152_), .Y(o5));
  OR3x1_ASAP7_75t_R    g135(.A(new_n150_), .B(new_n40_), .C(new_n151_), .Y(o6));
endmodule


