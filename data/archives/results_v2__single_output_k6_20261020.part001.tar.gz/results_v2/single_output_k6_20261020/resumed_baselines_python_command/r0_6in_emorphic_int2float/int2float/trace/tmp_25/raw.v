// Benchmark "/tmp/" written by ABC on Tue Oct 20 17:46:16 2026

module \/tmp/  ( 
    p9, p3, p1, p0, p8, p7, p5, p4, p6, p2, p10,
    o0, o1, o2, o3, o4, o5, o6  );
  input  p9, p3, p1, p0, p8, p7, p5, p4, p6, p2, p10;
  output o0, o1, o2, o3, o4, o5, o6;
  wire new_n19_, new_n20_, new_n21_, new_n22_, new_n23_, new_n24_, new_n25_,
    new_n26_, new_n27_, new_n28_, new_n29_, new_n30_, new_n31_, new_n32_,
    new_n33_, new_n34_, new_n35_, new_n36_, new_n37_, new_n38_, new_n39_,
    new_n40_, new_n41_, new_n42_, new_n43_, new_n44_, new_n45_, new_n46_,
    new_n47_, new_n48_, new_n49_, new_n50_, new_n51_, new_n52_, new_n53_,
    new_n54_, new_n55_, new_n56_, new_n57_, new_n58_, new_n59_, new_n60_,
    new_n62_, new_n63_, new_n64_, new_n65_, new_n66_, new_n67_, new_n68_,
    new_n69_, new_n70_, new_n71_, new_n72_, new_n73_, new_n74_, new_n75_,
    new_n76_, new_n77_, new_n78_, new_n79_, new_n80_, new_n81_, new_n82_,
    new_n83_, new_n84_, new_n85_, new_n86_, new_n87_, new_n88_, new_n89_,
    new_n90_, new_n91_, new_n92_, new_n93_, new_n94_, new_n95_, new_n96_,
    new_n97_, new_n98_, new_n100_, new_n101_, new_n102_, new_n103_,
    new_n104_, new_n105_, new_n106_, new_n107_, new_n108_, new_n109_,
    new_n110_, new_n111_, new_n112_, new_n113_, new_n114_, new_n115_,
    new_n116_, new_n117_, new_n118_, new_n119_, new_n120_, new_n121_,
    new_n122_, new_n123_, new_n124_, new_n125_, new_n126_, new_n127_,
    new_n128_, new_n130_, new_n131_, new_n132_, new_n133_, new_n135_,
    new_n136_, new_n137_, new_n138_, new_n139_, new_n140_, new_n141_,
    new_n142_, new_n143_, new_n144_, new_n145_, new_n146_, new_n148_,
    new_n149_, new_n150_, new_n151_, new_n152_;
  INVx1_ASAP7_75t_R    g000(.A(p4), .Y(new_n19_));
  NAND2x1_ASAP7_75t_R  g001(.A(p3), .B(p0), .Y(new_n20_));
  INVx1_ASAP7_75t_R    g002(.A(p3), .Y(new_n21_));
  NAND2x1_ASAP7_75t_R  g003(.A(p7), .B(new_n21_), .Y(new_n22_));
  INVx1_ASAP7_75t_R    g004(.A(p10), .Y(new_n23_));
  AOI21x1_ASAP7_75t_R  g005(.A1(new_n20_), .A2(new_n22_), .B(new_n23_), .Y(new_n24_));
  AO211x2_ASAP7_75t_R  g006(.A1(new_n20_), .A2(new_n23_), .B(p5), .C(p6), .Y(new_n25_));
  INVx1_ASAP7_75t_R    g007(.A(p7), .Y(new_n26_));
  OAI22x1_ASAP7_75t_R  g008(.A1(new_n24_), .A2(new_n25_), .B1(new_n21_), .B2(new_n26_), .Y(new_n27_));
  INVx1_ASAP7_75t_R    g009(.A(p0), .Y(new_n28_));
  INVx1_ASAP7_75t_R    g010(.A(p2), .Y(new_n29_));
  OR5x1_ASAP7_75t_R    g011(.A(p1), .B(new_n28_), .C(new_n19_), .D(new_n29_), .E(p6), .Y(new_n30_));
  NAND2x1_ASAP7_75t_R  g012(.A(p3), .B(new_n29_), .Y(new_n31_));
  NAND2x1_ASAP7_75t_R  g013(.A(p2), .B(new_n21_), .Y(new_n32_));
  INVx1_ASAP7_75t_R    g014(.A(p6), .Y(new_n33_));
  AO21x1_ASAP7_75t_R   g015(.A1(new_n31_), .A2(new_n32_), .B(new_n33_), .Y(new_n34_));
  AOI21x1_ASAP7_75t_R  g016(.A1(new_n30_), .A2(new_n34_), .B(p7), .Y(new_n35_));
  AND3x1_ASAP7_75t_R   g017(.A(new_n21_), .B(p7), .C(p4), .Y(new_n36_));
  AOI211x1_ASAP7_75t_R g018(.A1(new_n19_), .A2(new_n27_), .B(new_n35_), .C(new_n36_), .Y(new_n37_));
  NOR2x1_ASAP7_75t_R   g019(.A(p9), .B(p8), .Y(new_n38_));
  INVx1_ASAP7_75t_R    g020(.A(new_n38_), .Y(new_n39_));
  INVx1_ASAP7_75t_R    g021(.A(p9), .Y(new_n40_));
  NAND2x1_ASAP7_75t_R  g022(.A(p5), .B(p4), .Y(new_n41_));
  AND2x2_ASAP7_75t_R   g023(.A(new_n40_), .B(new_n41_), .Y(new_n42_));
  NOR2x1_ASAP7_75t_R   g024(.A(p7), .B(p6), .Y(new_n43_));
  AO31x2_ASAP7_75t_R   g025(.A1(new_n43_), .A2(p1), .A3(new_n28_), .B(p8), .Y(new_n44_));
  AND2x2_ASAP7_75t_R   g026(.A(p3), .B(p7), .Y(new_n45_));
  OAI22x1_ASAP7_75t_R  g027(.A1(new_n31_), .A2(new_n45_), .B1(p3), .B2(p6), .Y(new_n46_));
  INVx1_ASAP7_75t_R    g028(.A(p1), .Y(new_n47_));
  AND3x1_ASAP7_75t_R   g029(.A(new_n47_), .B(p0), .C(p4), .Y(new_n48_));
  AND2x2_ASAP7_75t_R   g030(.A(p8), .B(p5), .Y(new_n49_));
  AO221x2_ASAP7_75t_R  g031(.A1(p4), .A2(new_n44_), .B1(new_n46_), .B2(new_n48_), .C(new_n49_), .Y(new_n50_));
  INVx1_ASAP7_75t_R    g032(.A(p5), .Y(new_n51_));
  NOR2x1_ASAP7_75t_R   g033(.A(p6), .B(new_n51_), .Y(new_n52_));
  NOR2x1_ASAP7_75t_R   g034(.A(p8), .B(p7), .Y(new_n53_));
  XOR2x2_ASAP7_75t_R   g035(.A(p1), .B(p2), .Y(new_n54_));
  AO21x1_ASAP7_75t_R   g036(.A1(new_n53_), .A2(new_n54_), .B(p9), .Y(new_n55_));
  NAND2x1_ASAP7_75t_R  g037(.A(p6), .B(new_n51_), .Y(new_n56_));
  NAND2x1_ASAP7_75t_R  g038(.A(p7), .B(new_n49_), .Y(new_n57_));
  AOI21x1_ASAP7_75t_R  g039(.A1(new_n56_), .A2(new_n57_), .B(new_n40_), .Y(new_n58_));
  AO21x1_ASAP7_75t_R   g040(.A1(new_n52_), .A2(new_n55_), .B(new_n58_), .Y(new_n59_));
  AOI21x1_ASAP7_75t_R  g041(.A1(new_n42_), .A2(new_n50_), .B(new_n59_), .Y(new_n60_));
  OAI21x1_ASAP7_75t_R  g042(.A1(new_n37_), .A2(new_n39_), .B(new_n60_), .Y(o0));
  NOR2x1_ASAP7_75t_R   g043(.A(p3), .B(p8), .Y(new_n62_));
  INVx1_ASAP7_75t_R    g044(.A(new_n62_), .Y(new_n63_));
  NAND2x1_ASAP7_75t_R  g045(.A(p8), .B(new_n33_), .Y(new_n64_));
  AND3x1_ASAP7_75t_R   g046(.A(new_n63_), .B(new_n64_), .C(new_n41_), .Y(new_n65_));
  AOI21x1_ASAP7_75t_R  g047(.A1(new_n64_), .A2(new_n63_), .B(new_n51_), .Y(new_n66_));
  OR3x1_ASAP7_75t_R    g048(.A(new_n65_), .B(new_n53_), .C(new_n66_), .Y(new_n67_));
  NAND2x1_ASAP7_75t_R  g049(.A(p3), .B(p2), .Y(new_n68_));
  INVx1_ASAP7_75t_R    g050(.A(new_n68_), .Y(new_n69_));
  NAND2x1_ASAP7_75t_R  g051(.A(p6), .B(new_n53_), .Y(new_n70_));
  OAI21x1_ASAP7_75t_R  g052(.A1(new_n69_), .A2(new_n70_), .B(new_n64_), .Y(new_n71_));
  INVx1_ASAP7_75t_R    g053(.A(p8), .Y(new_n72_));
  NOR2x1_ASAP7_75t_R   g054(.A(p3), .B(p5), .Y(new_n73_));
  AO32x1_ASAP7_75t_R   g055(.A1(p3), .A2(new_n72_), .A3(new_n26_), .B1(new_n73_), .B2(new_n33_), .Y(new_n74_));
  AO21x1_ASAP7_75t_R   g056(.A1(p1), .A2(p0), .B(p6), .Y(new_n75_));
  AND3x1_ASAP7_75t_R   g057(.A(new_n75_), .B(p4), .C(p2), .Y(new_n76_));
  AOI22x1_ASAP7_75t_R  g058(.A1(new_n71_), .A2(new_n19_), .B1(new_n74_), .B2(new_n76_), .Y(new_n77_));
  OAI22x1_ASAP7_75t_R  g059(.A1(p3), .A2(p8), .B1(p1), .B2(p6), .Y(new_n78_));
  AO22x1_ASAP7_75t_R   g060(.A1(new_n72_), .A2(p7), .B1(new_n28_), .B2(new_n78_), .Y(new_n79_));
  NAND2x1_ASAP7_75t_R  g061(.A(p0), .B(p10), .Y(new_n80_));
  NAND2x1_ASAP7_75t_R  g062(.A(p3), .B(new_n33_), .Y(new_n81_));
  NOR2x1_ASAP7_75t_R   g063(.A(p1), .B(new_n23_), .Y(new_n82_));
  AOI211x1_ASAP7_75t_R g064(.A1(p1), .A2(new_n80_), .B(new_n81_), .C(new_n82_), .Y(new_n83_));
  NOR2x1_ASAP7_75t_R   g065(.A(p5), .B(p4), .Y(new_n84_));
  OAI21x1_ASAP7_75t_R  g066(.A1(new_n79_), .A2(new_n83_), .B(new_n84_), .Y(new_n85_));
  NAND3x1_ASAP7_75t_R  g067(.A(new_n67_), .B(new_n77_), .C(new_n85_), .Y(new_n86_));
  NAND2x1_ASAP7_75t_R  g068(.A(p5), .B(p6), .Y(new_n87_));
  OR3x1_ASAP7_75t_R    g069(.A(new_n87_), .B(new_n40_), .C(new_n26_), .Y(new_n88_));
  OR3x1_ASAP7_75t_R    g070(.A(new_n68_), .B(new_n47_), .C(new_n51_), .Y(new_n89_));
  NOR2x1_ASAP7_75t_R   g071(.A(p0), .B(p5), .Y(new_n90_));
  AOI22x1_ASAP7_75t_R  g072(.A1(p5), .A2(new_n62_), .B1(new_n90_), .B2(p4), .Y(new_n91_));
  OAI22x1_ASAP7_75t_R  g073(.A1(new_n89_), .A2(p8), .B1(new_n91_), .B2(p2), .Y(new_n92_));
  NOR2x1_ASAP7_75t_R   g074(.A(p5), .B(p2), .Y(new_n93_));
  AOI22x1_ASAP7_75t_R  g075(.A1(p5), .A2(new_n62_), .B1(new_n93_), .B2(p4), .Y(new_n94_));
  OAI21x1_ASAP7_75t_R  g076(.A1(p1), .A2(new_n94_), .B(new_n40_), .Y(new_n95_));
  AND3x1_ASAP7_75t_R   g077(.A(new_n26_), .B(new_n51_), .C(p9), .Y(new_n96_));
  OAI22x1_ASAP7_75t_R  g078(.A1(new_n92_), .A2(new_n95_), .B1(new_n43_), .B2(new_n96_), .Y(new_n97_));
  OAI21x1_ASAP7_75t_R  g079(.A1(p8), .A2(new_n88_), .B(new_n97_), .Y(new_n98_));
  AOI21x1_ASAP7_75t_R  g080(.A1(new_n40_), .A2(new_n86_), .B(new_n98_), .Y(o1));
  NOR2x1_ASAP7_75t_R   g081(.A(p2), .B(new_n19_), .Y(new_n100_));
  AND3x1_ASAP7_75t_R   g082(.A(new_n47_), .B(new_n51_), .C(p2), .Y(new_n101_));
  OAI21x1_ASAP7_75t_R  g083(.A1(new_n100_), .A2(new_n101_), .B(p3), .Y(new_n102_));
  INVx1_ASAP7_75t_R    g084(.A(new_n43_), .Y(new_n103_));
  AOI21x1_ASAP7_75t_R  g085(.A1(new_n47_), .A2(new_n102_), .B(new_n103_), .Y(new_n104_));
  AND3x1_ASAP7_75t_R   g086(.A(new_n21_), .B(p4), .C(p2), .Y(new_n105_));
  AND4x2_ASAP7_75t_R   g087(.A(new_n51_), .B(new_n29_), .C(p3), .D(p10), .Y(new_n106_));
  OAI21x1_ASAP7_75t_R  g088(.A1(new_n105_), .A2(new_n106_), .B(p0), .Y(new_n107_));
  AOI21x1_ASAP7_75t_R  g089(.A1(p0), .A2(p10), .B(new_n68_), .Y(new_n108_));
  OAI21x1_ASAP7_75t_R  g090(.A1(new_n73_), .A2(new_n108_), .B(new_n19_), .Y(new_n109_));
  NAND3x1_ASAP7_75t_R  g091(.A(new_n107_), .B(new_n102_), .C(new_n109_), .Y(new_n110_));
  AND3x1_ASAP7_75t_R   g092(.A(new_n19_), .B(p1), .C(p5), .Y(new_n111_));
  AOI211x1_ASAP7_75t_R g093(.A1(p4), .A2(new_n90_), .B(new_n68_), .C(new_n111_), .Y(new_n112_));
  AO21x1_ASAP7_75t_R   g094(.A1(new_n68_), .A2(new_n41_), .B(p7), .Y(new_n113_));
  AND5x1_ASAP7_75t_R   g095(.A(p3), .B(new_n47_), .C(new_n33_), .D(p5), .E(p4), .Y(new_n114_));
  AND5x1_ASAP7_75t_R   g096(.A(new_n51_), .B(p3), .C(p4), .D(p6), .E(p2), .Y(new_n115_));
  NAND2x1_ASAP7_75t_R  g097(.A(p3), .B(p4), .Y(new_n116_));
  AND3x1_ASAP7_75t_R   g098(.A(new_n116_), .B(p5), .C(p6), .Y(new_n117_));
  NOR3x1_ASAP7_75t_R   g099(.A(new_n114_), .B(new_n115_), .C(new_n117_), .Y(new_n118_));
  OAI21x1_ASAP7_75t_R  g100(.A1(new_n112_), .A2(new_n113_), .B(new_n118_), .Y(new_n119_));
  AOI21x1_ASAP7_75t_R  g101(.A1(new_n104_), .A2(new_n110_), .B(new_n119_), .Y(new_n120_));
  AO21x1_ASAP7_75t_R   g102(.A1(p4), .A2(p6), .B(new_n72_), .Y(new_n121_));
  OR3x1_ASAP7_75t_R    g103(.A(new_n41_), .B(new_n21_), .C(p6), .Y(new_n122_));
  AO21x1_ASAP7_75t_R   g104(.A1(new_n56_), .A2(new_n122_), .B(p9), .Y(new_n123_));
  NAND2x1_ASAP7_75t_R  g105(.A(new_n121_), .B(new_n123_), .Y(new_n124_));
  OR3x1_ASAP7_75t_R    g106(.A(new_n87_), .B(p7), .C(new_n19_), .Y(new_n125_));
  AO21x1_ASAP7_75t_R   g107(.A1(new_n40_), .A2(new_n125_), .B(new_n72_), .Y(new_n126_));
  NAND2x1_ASAP7_75t_R  g108(.A(new_n88_), .B(new_n126_), .Y(new_n127_));
  AOI21x1_ASAP7_75t_R  g109(.A1(p7), .A2(new_n124_), .B(new_n127_), .Y(new_n128_));
  OAI21x1_ASAP7_75t_R  g110(.A1(new_n39_), .A2(new_n120_), .B(new_n128_), .Y(o2));
  OR5x1_ASAP7_75t_R    g111(.A(p3), .B(p7), .C(p5), .D(p4), .E(p6), .Y(new_n130_));
  OR3x1_ASAP7_75t_R    g112(.A(new_n41_), .B(new_n26_), .C(new_n33_), .Y(new_n131_));
  OR3x1_ASAP7_75t_R    g113(.A(new_n131_), .B(new_n21_), .C(p1), .Y(new_n132_));
  OR3x1_ASAP7_75t_R    g114(.A(p9), .B(p8), .C(p2), .Y(new_n133_));
  AO21x1_ASAP7_75t_R   g115(.A1(new_n130_), .A2(new_n132_), .B(new_n133_), .Y(o3));
  INVx1_ASAP7_75t_R    g116(.A(new_n41_), .Y(new_n135_));
  AND3x1_ASAP7_75t_R   g117(.A(new_n33_), .B(p1), .C(p0), .Y(new_n136_));
  OA21x2_ASAP7_75t_R   g118(.A1(new_n135_), .A2(new_n136_), .B(new_n69_), .Y(new_n137_));
  AND3x1_ASAP7_75t_R   g119(.A(new_n19_), .B(new_n33_), .C(p3), .Y(new_n138_));
  OR4x2_ASAP7_75t_R    g120(.A(new_n137_), .B(p7), .C(new_n52_), .D(new_n138_), .Y(new_n139_));
  OR3x1_ASAP7_75t_R    g121(.A(new_n80_), .B(p5), .C(p4), .Y(new_n140_));
  OR3x1_ASAP7_75t_R    g122(.A(new_n47_), .B(new_n29_), .C(p7), .Y(new_n141_));
  AO21x1_ASAP7_75t_R   g123(.A1(new_n122_), .A2(new_n140_), .B(new_n141_), .Y(new_n142_));
  AND2x2_ASAP7_75t_R   g124(.A(p7), .B(p2), .Y(new_n143_));
  AO21x1_ASAP7_75t_R   g125(.A1(p1), .A2(new_n29_), .B(new_n143_), .Y(new_n144_));
  AND5x1_ASAP7_75t_R   g126(.A(new_n72_), .B(p3), .C(p5), .D(p4), .E(p6), .Y(new_n145_));
  AOI22x1_ASAP7_75t_R  g127(.A1(new_n144_), .A2(new_n145_), .B1(p8), .B2(new_n131_), .Y(new_n146_));
  AO31x2_ASAP7_75t_R   g128(.A1(new_n139_), .A2(new_n142_), .A3(new_n146_), .B(p9), .Y(o4));
  AO21x1_ASAP7_75t_R   g129(.A1(new_n47_), .A2(new_n29_), .B(new_n131_), .Y(new_n148_));
  OR4x2_ASAP7_75t_R    g130(.A(new_n141_), .B(p4), .C(p6), .D(new_n80_), .Y(new_n149_));
  AO21x1_ASAP7_75t_R   g131(.A1(new_n148_), .A2(new_n149_), .B(new_n21_), .Y(new_n150_));
  AND3x1_ASAP7_75t_R   g132(.A(new_n69_), .B(new_n135_), .C(p1), .Y(new_n151_));
  OR3x1_ASAP7_75t_R    g133(.A(new_n151_), .B(new_n103_), .C(new_n84_), .Y(new_n152_));
  NAND3x1_ASAP7_75t_R  g134(.A(new_n150_), .B(new_n38_), .C(new_n152_), .Y(o5));
  OR3x1_ASAP7_75t_R    g135(.A(new_n151_), .B(new_n39_), .C(new_n103_), .Y(o6));
endmodule


