// Benchmark "/tmp/" written by ABC on Tue Oct 20 17:46:14 2026

module \/tmp/  ( 
    p3, p6, p10, p0, p7, p9, p5, p8, p1, p4, p2,
    o0, o1, o2, o3, o4, o5, o6  );
  input  p3, p6, p10, p0, p7, p9, p5, p8, p1, p4, p2;
  output o0, o1, o2, o3, o4, o5, o6;
  wire new_n19_, new_n20_, new_n21_, new_n22_, new_n23_, new_n24_, new_n25_,
    new_n26_, new_n27_, new_n28_, new_n29_, new_n30_, new_n31_, new_n32_,
    new_n33_, new_n34_, new_n35_, new_n36_, new_n37_, new_n38_, new_n39_,
    new_n40_, new_n41_, new_n42_, new_n43_, new_n44_, new_n45_, new_n46_,
    new_n47_, new_n48_, new_n49_, new_n50_, new_n51_, new_n52_, new_n53_,
    new_n54_, new_n55_, new_n56_, new_n57_, new_n58_, new_n59_, new_n60_,
    new_n61_, new_n62_, new_n63_, new_n64_, new_n66_, new_n67_, new_n68_,
    new_n69_, new_n70_, new_n71_, new_n72_, new_n73_, new_n74_, new_n75_,
    new_n76_, new_n77_, new_n78_, new_n79_, new_n80_, new_n81_, new_n82_,
    new_n83_, new_n84_, new_n85_, new_n86_, new_n87_, new_n88_, new_n89_,
    new_n90_, new_n91_, new_n92_, new_n93_, new_n94_, new_n95_, new_n96_,
    new_n97_, new_n98_, new_n99_, new_n100_, new_n101_, new_n103_,
    new_n104_, new_n105_, new_n106_, new_n107_, new_n108_, new_n109_,
    new_n110_, new_n111_, new_n112_, new_n113_, new_n114_, new_n115_,
    new_n116_, new_n117_, new_n118_, new_n119_, new_n120_, new_n121_,
    new_n122_, new_n123_, new_n124_, new_n125_, new_n126_, new_n127_,
    new_n128_, new_n129_, new_n130_, new_n131_, new_n132_, new_n133_,
    new_n134_, new_n135_, new_n136_, new_n138_, new_n139_, new_n141_,
    new_n142_, new_n143_, new_n144_, new_n145_, new_n146_, new_n147_,
    new_n148_, new_n149_, new_n150_, new_n151_, new_n153_, new_n154_,
    new_n155_, new_n156_, new_n157_, new_n158_, new_n159_;
  NOR2x1_ASAP7_75t_R   g000(.A(p9), .B(p8), .Y(new_n19_));
  INVx1_ASAP7_75t_R    g001(.A(new_n19_), .Y(new_n20_));
  INVx1_ASAP7_75t_R    g002(.A(p4), .Y(new_n21_));
  INVx1_ASAP7_75t_R    g003(.A(p10), .Y(new_n22_));
  NAND2x1_ASAP7_75t_R  g004(.A(p3), .B(p0), .Y(new_n23_));
  INVx1_ASAP7_75t_R    g005(.A(p6), .Y(new_n24_));
  INVx1_ASAP7_75t_R    g006(.A(p5), .Y(new_n25_));
  NAND2x1_ASAP7_75t_R  g007(.A(new_n24_), .B(new_n25_), .Y(new_n26_));
  AO21x1_ASAP7_75t_R   g008(.A1(new_n22_), .A2(new_n23_), .B(new_n26_), .Y(new_n27_));
  INVx1_ASAP7_75t_R    g009(.A(p3), .Y(new_n28_));
  NAND2x1_ASAP7_75t_R  g010(.A(p7), .B(new_n28_), .Y(new_n29_));
  AOI21x1_ASAP7_75t_R  g011(.A1(new_n23_), .A2(new_n29_), .B(new_n22_), .Y(new_n30_));
  INVx1_ASAP7_75t_R    g012(.A(p7), .Y(new_n31_));
  OAI22x1_ASAP7_75t_R  g013(.A1(new_n27_), .A2(new_n30_), .B1(new_n28_), .B2(new_n31_), .Y(new_n32_));
  NAND2x1_ASAP7_75t_R  g014(.A(p4), .B(p2), .Y(new_n33_));
  NOR2x1_ASAP7_75t_R   g015(.A(p6), .B(new_n33_), .Y(new_n34_));
  INVx1_ASAP7_75t_R    g016(.A(p0), .Y(new_n35_));
  NOR2x1_ASAP7_75t_R   g017(.A(p1), .B(new_n35_), .Y(new_n36_));
  INVx1_ASAP7_75t_R    g018(.A(p2), .Y(new_n37_));
  NAND2x1_ASAP7_75t_R  g019(.A(new_n28_), .B(new_n37_), .Y(new_n38_));
  AOI21x1_ASAP7_75t_R  g020(.A1(p3), .A2(p2), .B(new_n24_), .Y(new_n39_));
  AOI22x1_ASAP7_75t_R  g021(.A1(new_n34_), .A2(new_n36_), .B1(new_n38_), .B2(new_n39_), .Y(new_n40_));
  OAI22x1_ASAP7_75t_R  g022(.A1(new_n40_), .A2(p7), .B1(new_n21_), .B2(new_n29_), .Y(new_n41_));
  AOI21x1_ASAP7_75t_R  g023(.A1(new_n21_), .A2(new_n32_), .B(new_n41_), .Y(new_n42_));
  INVx1_ASAP7_75t_R    g024(.A(p9), .Y(new_n43_));
  AOI211x1_ASAP7_75t_R g025(.A1(p6), .A2(new_n28_), .B(new_n35_), .C(p1), .Y(new_n44_));
  AO21x1_ASAP7_75t_R   g026(.A1(new_n31_), .A2(new_n37_), .B(new_n28_), .Y(new_n45_));
  NOR2x1_ASAP7_75t_R   g027(.A(p5), .B(new_n21_), .Y(new_n46_));
  NAND3x1_ASAP7_75t_R  g028(.A(new_n44_), .B(new_n45_), .C(new_n46_), .Y(new_n47_));
  NOR2x1_ASAP7_75t_R   g029(.A(p6), .B(p7), .Y(new_n48_));
  AO31x2_ASAP7_75t_R   g030(.A1(new_n48_), .A2(new_n35_), .A3(p1), .B(p8), .Y(new_n49_));
  AND3x1_ASAP7_75t_R   g031(.A(new_n21_), .B(p5), .C(p8), .Y(new_n50_));
  AOI21x1_ASAP7_75t_R  g032(.A1(new_n46_), .A2(new_n49_), .B(new_n50_), .Y(new_n51_));
  NAND2x1_ASAP7_75t_R  g033(.A(new_n47_), .B(new_n51_), .Y(new_n52_));
  NAND2x1_ASAP7_75t_R  g034(.A(p5), .B(new_n24_), .Y(new_n53_));
  NOR2x1_ASAP7_75t_R   g035(.A(p1), .B(p2), .Y(new_n54_));
  NAND2x1_ASAP7_75t_R  g036(.A(p1), .B(p2), .Y(new_n55_));
  NOR2x1_ASAP7_75t_R   g037(.A(p7), .B(p8), .Y(new_n56_));
  NAND2x1_ASAP7_75t_R  g038(.A(new_n55_), .B(new_n56_), .Y(new_n57_));
  OA21x2_ASAP7_75t_R   g039(.A1(new_n54_), .A2(new_n57_), .B(new_n43_), .Y(new_n58_));
  NAND2x1_ASAP7_75t_R  g040(.A(p6), .B(new_n25_), .Y(new_n59_));
  INVx1_ASAP7_75t_R    g041(.A(p8), .Y(new_n60_));
  OR3x1_ASAP7_75t_R    g042(.A(new_n31_), .B(new_n25_), .C(new_n60_), .Y(new_n61_));
  AO21x1_ASAP7_75t_R   g043(.A1(new_n59_), .A2(new_n61_), .B(new_n43_), .Y(new_n62_));
  OAI21x1_ASAP7_75t_R  g044(.A1(new_n53_), .A2(new_n58_), .B(new_n62_), .Y(new_n63_));
  AOI21x1_ASAP7_75t_R  g045(.A1(new_n43_), .A2(new_n52_), .B(new_n63_), .Y(new_n64_));
  OAI21x1_ASAP7_75t_R  g046(.A1(new_n20_), .A2(new_n42_), .B(new_n64_), .Y(o0));
  NOR2x1_ASAP7_75t_R   g047(.A(p6), .B(new_n60_), .Y(new_n66_));
  AO21x1_ASAP7_75t_R   g048(.A1(new_n56_), .A2(new_n39_), .B(new_n66_), .Y(new_n67_));
  OAI21x1_ASAP7_75t_R  g049(.A1(p6), .A2(p5), .B(new_n28_), .Y(new_n68_));
  AO21x1_ASAP7_75t_R   g050(.A1(p0), .A2(p1), .B(p6), .Y(new_n69_));
  OAI21x1_ASAP7_75t_R  g051(.A1(p7), .A2(p8), .B(p3), .Y(new_n70_));
  AND5x1_ASAP7_75t_R   g052(.A(p4), .B(new_n68_), .C(p2), .D(new_n69_), .E(new_n70_), .Y(new_n71_));
  AOI21x1_ASAP7_75t_R  g053(.A1(new_n21_), .A2(new_n67_), .B(new_n71_), .Y(new_n72_));
  NAND2x1_ASAP7_75t_R  g054(.A(new_n28_), .B(new_n60_), .Y(new_n73_));
  NAND2x1_ASAP7_75t_R  g055(.A(p8), .B(new_n24_), .Y(new_n74_));
  AND2x2_ASAP7_75t_R   g056(.A(p5), .B(p4), .Y(new_n75_));
  AND3x1_ASAP7_75t_R   g057(.A(new_n73_), .B(new_n74_), .C(new_n75_), .Y(new_n76_));
  AOI21x1_ASAP7_75t_R  g058(.A1(new_n74_), .A2(new_n73_), .B(p5), .Y(new_n77_));
  OAI22x1_ASAP7_75t_R  g059(.A1(new_n76_), .A2(new_n77_), .B1(p7), .B2(p8), .Y(new_n78_));
  OAI22x1_ASAP7_75t_R  g060(.A1(p3), .A2(p8), .B1(p6), .B2(p1), .Y(new_n79_));
  AO22x1_ASAP7_75t_R   g061(.A1(p7), .A2(new_n60_), .B1(new_n35_), .B2(new_n79_), .Y(new_n80_));
  NAND2x1_ASAP7_75t_R  g062(.A(p0), .B(p1), .Y(new_n81_));
  NAND2x1_ASAP7_75t_R  g063(.A(p3), .B(new_n24_), .Y(new_n82_));
  INVx1_ASAP7_75t_R    g064(.A(p1), .Y(new_n83_));
  NOR2x1_ASAP7_75t_R   g065(.A(p10), .B(new_n83_), .Y(new_n84_));
  AOI211x1_ASAP7_75t_R g066(.A1(p10), .A2(new_n81_), .B(new_n82_), .C(new_n84_), .Y(new_n85_));
  NOR2x1_ASAP7_75t_R   g067(.A(p5), .B(p4), .Y(new_n86_));
  OAI21x1_ASAP7_75t_R  g068(.A1(new_n80_), .A2(new_n85_), .B(new_n86_), .Y(new_n87_));
  NAND3x1_ASAP7_75t_R  g069(.A(new_n72_), .B(new_n78_), .C(new_n87_), .Y(new_n88_));
  AO21x1_ASAP7_75t_R   g070(.A1(p6), .A2(p5), .B(p7), .Y(new_n89_));
  OR3x1_ASAP7_75t_R    g071(.A(new_n21_), .B(p0), .C(p2), .Y(new_n90_));
  AOI21x1_ASAP7_75t_R  g072(.A1(p4), .A2(new_n54_), .B(p5), .Y(new_n91_));
  AOI21x1_ASAP7_75t_R  g073(.A1(new_n90_), .A2(new_n91_), .B(p6), .Y(new_n92_));
  INVx1_ASAP7_75t_R    g074(.A(new_n55_), .Y(new_n93_));
  OA21x2_ASAP7_75t_R   g075(.A1(p3), .A2(p8), .B(p5), .Y(new_n94_));
  OR3x1_ASAP7_75t_R    g076(.A(new_n55_), .B(new_n28_), .C(p8), .Y(new_n95_));
  OAI21x1_ASAP7_75t_R  g077(.A1(new_n93_), .A2(new_n94_), .B(new_n95_), .Y(new_n96_));
  AOI21x1_ASAP7_75t_R  g078(.A1(new_n92_), .A2(new_n96_), .B(p9), .Y(new_n97_));
  NAND2x1_ASAP7_75t_R  g079(.A(p7), .B(p9), .Y(new_n98_));
  NAND2x1_ASAP7_75t_R  g080(.A(p6), .B(p5), .Y(new_n99_));
  OR3x1_ASAP7_75t_R    g081(.A(new_n98_), .B(new_n99_), .C(p8), .Y(new_n100_));
  OAI21x1_ASAP7_75t_R  g082(.A1(new_n89_), .A2(new_n97_), .B(new_n100_), .Y(new_n101_));
  AOI21x1_ASAP7_75t_R  g083(.A1(new_n43_), .A2(new_n88_), .B(new_n101_), .Y(o1));
  OR3x1_ASAP7_75t_R    g084(.A(p7), .B(p9), .C(p8), .Y(new_n103_));
  NAND2x1_ASAP7_75t_R  g085(.A(p3), .B(p2), .Y(new_n104_));
  INVx1_ASAP7_75t_R    g086(.A(new_n104_), .Y(new_n105_));
  NOR2x1_ASAP7_75t_R   g087(.A(p5), .B(p1), .Y(new_n106_));
  NAND2x1_ASAP7_75t_R  g088(.A(p3), .B(p4), .Y(new_n107_));
  NOR2x1_ASAP7_75t_R   g089(.A(p2), .B(new_n107_), .Y(new_n108_));
  AOI21x1_ASAP7_75t_R  g090(.A1(new_n105_), .A2(new_n106_), .B(new_n108_), .Y(new_n109_));
  AOI21x1_ASAP7_75t_R  g091(.A1(new_n83_), .A2(new_n109_), .B(p6), .Y(new_n110_));
  NOR2x1_ASAP7_75t_R   g092(.A(p4), .B(new_n104_), .Y(new_n111_));
  AND2x2_ASAP7_75t_R   g093(.A(p10), .B(p0), .Y(new_n112_));
  INVx1_ASAP7_75t_R    g094(.A(new_n112_), .Y(new_n113_));
  AND3x1_ASAP7_75t_R   g095(.A(new_n28_), .B(new_n25_), .C(new_n21_), .Y(new_n114_));
  AOI21x1_ASAP7_75t_R  g096(.A1(new_n111_), .A2(new_n113_), .B(new_n114_), .Y(new_n115_));
  AOI21x1_ASAP7_75t_R  g097(.A1(p3), .A2(p2), .B(new_n35_), .Y(new_n116_));
  NAND2x1_ASAP7_75t_R  g098(.A(p3), .B(p10), .Y(new_n117_));
  OAI21x1_ASAP7_75t_R  g099(.A1(p5), .A2(new_n117_), .B(new_n33_), .Y(new_n118_));
  NAND2x1_ASAP7_75t_R  g100(.A(new_n116_), .B(new_n118_), .Y(new_n119_));
  NAND3x1_ASAP7_75t_R  g101(.A(new_n115_), .B(new_n119_), .C(new_n109_), .Y(new_n120_));
  INVx1_ASAP7_75t_R    g102(.A(new_n75_), .Y(new_n121_));
  AOI22x1_ASAP7_75t_R  g103(.A1(new_n35_), .A2(p4), .B1(p5), .B2(p1), .Y(new_n122_));
  OR3x1_ASAP7_75t_R    g104(.A(new_n122_), .B(new_n104_), .C(new_n75_), .Y(new_n123_));
  OAI21x1_ASAP7_75t_R  g105(.A1(new_n105_), .A2(new_n121_), .B(new_n123_), .Y(new_n124_));
  AOI21x1_ASAP7_75t_R  g106(.A1(new_n110_), .A2(new_n120_), .B(new_n124_), .Y(new_n125_));
  AND3x1_ASAP7_75t_R   g107(.A(new_n25_), .B(p6), .C(p2), .Y(new_n126_));
  AND3x1_ASAP7_75t_R   g108(.A(new_n24_), .B(new_n83_), .C(p5), .Y(new_n127_));
  NAND2x1_ASAP7_75t_R  g109(.A(new_n99_), .B(new_n107_), .Y(new_n128_));
  OA31x2_ASAP7_75t_R   g110(.A1(new_n107_), .A2(new_n126_), .A3(new_n127_), .B1(new_n128_), .Y(new_n129_));
  OAI21x1_ASAP7_75t_R  g111(.A1(new_n107_), .A2(new_n53_), .B(new_n59_), .Y(new_n130_));
  OA21x2_ASAP7_75t_R   g112(.A1(new_n24_), .A2(new_n21_), .B(p8), .Y(new_n131_));
  AO21x1_ASAP7_75t_R   g113(.A1(new_n43_), .A2(new_n130_), .B(new_n131_), .Y(new_n132_));
  NAND2x1_ASAP7_75t_R  g114(.A(p8), .B(p4), .Y(new_n133_));
  OA21x2_ASAP7_75t_R   g115(.A1(p7), .A2(new_n133_), .B(new_n98_), .Y(new_n134_));
  OAI22x1_ASAP7_75t_R  g116(.A1(new_n134_), .A2(new_n99_), .B1(new_n43_), .B2(new_n60_), .Y(new_n135_));
  AOI221x1_ASAP7_75t_R g117(.A1(new_n19_), .A2(new_n129_), .B1(new_n132_), .B2(p7), .C(new_n135_), .Y(new_n136_));
  OAI21x1_ASAP7_75t_R  g118(.A1(new_n103_), .A2(new_n125_), .B(new_n136_), .Y(o2));
  AND5x1_ASAP7_75t_R   g119(.A(p3), .B(new_n75_), .C(p6), .D(p7), .E(new_n83_), .Y(new_n138_));
  AOI21x1_ASAP7_75t_R  g120(.A1(new_n48_), .A2(new_n114_), .B(new_n138_), .Y(new_n139_));
  OR3x1_ASAP7_75t_R    g121(.A(new_n139_), .B(p2), .C(new_n20_), .Y(o3));
  AND3x1_ASAP7_75t_R   g122(.A(new_n75_), .B(p6), .C(p7), .Y(new_n141_));
  NOR2x1_ASAP7_75t_R   g123(.A(p7), .B(new_n37_), .Y(new_n142_));
  OR5x1_ASAP7_75t_R    g124(.A(p8), .B(new_n142_), .C(new_n54_), .D(new_n99_), .E(new_n107_), .Y(new_n143_));
  OA21x2_ASAP7_75t_R   g125(.A1(new_n60_), .A2(new_n141_), .B(new_n143_), .Y(new_n144_));
  OR3x1_ASAP7_75t_R    g126(.A(new_n28_), .B(p6), .C(p4), .Y(new_n145_));
  AND3x1_ASAP7_75t_R   g127(.A(new_n145_), .B(new_n31_), .C(new_n53_), .Y(new_n146_));
  OR3x1_ASAP7_75t_R    g128(.A(new_n35_), .B(new_n83_), .C(p6), .Y(new_n147_));
  AO21x1_ASAP7_75t_R   g129(.A1(new_n121_), .A2(new_n147_), .B(new_n104_), .Y(new_n148_));
  NAND2x1_ASAP7_75t_R  g130(.A(new_n146_), .B(new_n148_), .Y(new_n149_));
  AO32x1_ASAP7_75t_R   g131(.A1(new_n75_), .A2(p3), .A3(new_n24_), .B1(new_n112_), .B2(new_n86_), .Y(new_n150_));
  NAND3x1_ASAP7_75t_R  g132(.A(new_n150_), .B(p1), .C(new_n142_), .Y(new_n151_));
  AO31x2_ASAP7_75t_R   g133(.A1(new_n144_), .A2(new_n149_), .A3(new_n151_), .B(p9), .Y(o4));
  INVx1_ASAP7_75t_R    g134(.A(new_n86_), .Y(new_n153_));
  INVx1_ASAP7_75t_R    g135(.A(new_n48_), .Y(new_n154_));
  AND3x1_ASAP7_75t_R   g136(.A(new_n105_), .B(new_n75_), .C(p1), .Y(new_n155_));
  NOR2x1_ASAP7_75t_R   g137(.A(new_n154_), .B(new_n155_), .Y(new_n156_));
  AND3x1_ASAP7_75t_R   g138(.A(new_n112_), .B(new_n24_), .C(new_n21_), .Y(new_n157_));
  INVx1_ASAP7_75t_R    g139(.A(new_n54_), .Y(new_n158_));
  AO32x1_ASAP7_75t_R   g140(.A1(new_n157_), .A2(p1), .A3(new_n142_), .B1(new_n141_), .B2(new_n158_), .Y(new_n159_));
  AO221x2_ASAP7_75t_R  g141(.A1(new_n153_), .A2(new_n156_), .B1(new_n159_), .B2(p3), .C(new_n20_), .Y(o5));
  OR3x1_ASAP7_75t_R    g142(.A(new_n155_), .B(new_n20_), .C(new_n154_), .Y(o6));
endmodule


