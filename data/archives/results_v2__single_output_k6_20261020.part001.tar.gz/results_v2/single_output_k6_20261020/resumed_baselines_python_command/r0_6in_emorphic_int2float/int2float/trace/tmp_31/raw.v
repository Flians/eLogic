// Benchmark "/tmp/" written by ABC on Tue Oct 20 17:46:17 2026

module \/tmp/  ( 
    p4, p5, p10, p9, p7, p6, p0, p2, p1, p3, p8,
    o0, o1, o2, o3, o4, o5, o6  );
  input  p4, p5, p10, p9, p7, p6, p0, p2, p1, p3, p8;
  output o0, o1, o2, o3, o4, o5, o6;
  wire new_n19_, new_n20_, new_n21_, new_n22_, new_n23_, new_n24_, new_n25_,
    new_n26_, new_n27_, new_n28_, new_n29_, new_n30_, new_n31_, new_n32_,
    new_n33_, new_n34_, new_n35_, new_n36_, new_n37_, new_n38_, new_n39_,
    new_n40_, new_n41_, new_n42_, new_n43_, new_n44_, new_n45_, new_n46_,
    new_n47_, new_n48_, new_n49_, new_n50_, new_n51_, new_n52_, new_n53_,
    new_n54_, new_n55_, new_n56_, new_n57_, new_n58_, new_n59_, new_n60_,
    new_n61_, new_n62_, new_n64_, new_n65_, new_n66_, new_n67_, new_n68_,
    new_n69_, new_n70_, new_n71_, new_n72_, new_n73_, new_n74_, new_n75_,
    new_n76_, new_n77_, new_n78_, new_n79_, new_n80_, new_n81_, new_n82_,
    new_n83_, new_n84_, new_n85_, new_n86_, new_n87_, new_n88_, new_n89_,
    new_n90_, new_n91_, new_n92_, new_n93_, new_n94_, new_n95_, new_n96_,
    new_n97_, new_n98_, new_n99_, new_n100_, new_n101_, new_n103_,
    new_n104_, new_n105_, new_n106_, new_n107_, new_n108_, new_n109_,
    new_n110_, new_n111_, new_n112_, new_n113_, new_n114_, new_n115_,
    new_n116_, new_n117_, new_n118_, new_n119_, new_n120_, new_n121_,
    new_n122_, new_n123_, new_n124_, new_n125_, new_n126_, new_n127_,
    new_n128_, new_n129_, new_n130_, new_n131_, new_n132_, new_n133_,
    new_n135_, new_n136_, new_n137_, new_n138_, new_n139_, new_n141_,
    new_n142_, new_n143_, new_n144_, new_n145_, new_n146_, new_n147_,
    new_n148_, new_n149_, new_n150_, new_n151_, new_n153_, new_n154_,
    new_n155_, new_n156_, new_n157_;
  NOR2x1_ASAP7_75t_R   g000(.A(p9), .B(p8), .Y(new_n19_));
  INVx1_ASAP7_75t_R    g001(.A(new_n19_), .Y(new_n20_));
  INVx1_ASAP7_75t_R    g002(.A(p3), .Y(new_n21_));
  NAND2x1_ASAP7_75t_R  g003(.A(p7), .B(new_n21_), .Y(new_n22_));
  AND2x2_ASAP7_75t_R   g004(.A(p4), .B(new_n22_), .Y(new_n23_));
  INVx1_ASAP7_75t_R    g005(.A(p10), .Y(new_n24_));
  NAND2x1_ASAP7_75t_R  g006(.A(p0), .B(p3), .Y(new_n25_));
  INVx1_ASAP7_75t_R    g007(.A(p5), .Y(new_n26_));
  INVx1_ASAP7_75t_R    g008(.A(p6), .Y(new_n27_));
  NAND2x1_ASAP7_75t_R  g009(.A(new_n26_), .B(new_n27_), .Y(new_n28_));
  AOI21x1_ASAP7_75t_R  g010(.A1(new_n24_), .A2(new_n25_), .B(new_n28_), .Y(new_n29_));
  AO21x1_ASAP7_75t_R   g011(.A1(new_n25_), .A2(new_n22_), .B(new_n24_), .Y(new_n30_));
  AO21x1_ASAP7_75t_R   g012(.A1(p7), .A2(p3), .B(p4), .Y(new_n31_));
  AOI21x1_ASAP7_75t_R  g013(.A1(new_n29_), .A2(new_n30_), .B(new_n31_), .Y(new_n32_));
  INVx1_ASAP7_75t_R    g014(.A(p4), .Y(new_n33_));
  INVx1_ASAP7_75t_R    g015(.A(p0), .Y(new_n34_));
  INVx1_ASAP7_75t_R    g016(.A(p2), .Y(new_n35_));
  OR5x1_ASAP7_75t_R    g017(.A(new_n33_), .B(new_n34_), .C(new_n35_), .D(p6), .E(p1), .Y(new_n36_));
  AND2x2_ASAP7_75t_R   g018(.A(p2), .B(p3), .Y(new_n37_));
  NOR2x1_ASAP7_75t_R   g019(.A(p2), .B(p3), .Y(new_n38_));
  OR3x1_ASAP7_75t_R    g020(.A(new_n37_), .B(new_n27_), .C(new_n38_), .Y(new_n39_));
  AO21x1_ASAP7_75t_R   g021(.A1(new_n36_), .A2(new_n39_), .B(p7), .Y(new_n40_));
  OA21x2_ASAP7_75t_R   g022(.A1(new_n23_), .A2(new_n32_), .B(new_n40_), .Y(new_n41_));
  INVx1_ASAP7_75t_R    g023(.A(p9), .Y(new_n42_));
  NAND2x1_ASAP7_75t_R  g024(.A(p4), .B(new_n26_), .Y(new_n43_));
  NOR2x1_ASAP7_75t_R   g025(.A(p3), .B(new_n27_), .Y(new_n44_));
  AND2x2_ASAP7_75t_R   g026(.A(p7), .B(p3), .Y(new_n45_));
  OR5x1_ASAP7_75t_R    g027(.A(new_n34_), .B(new_n44_), .C(p1), .D(new_n45_), .E(new_n37_), .Y(new_n46_));
  NOR2x1_ASAP7_75t_R   g028(.A(p5), .B(new_n33_), .Y(new_n47_));
  NOR2x1_ASAP7_75t_R   g029(.A(p7), .B(p6), .Y(new_n48_));
  AO31x2_ASAP7_75t_R   g030(.A1(new_n48_), .A2(new_n34_), .A3(p1), .B(p8), .Y(new_n49_));
  AND3x1_ASAP7_75t_R   g031(.A(new_n33_), .B(p5), .C(p8), .Y(new_n50_));
  AOI21x1_ASAP7_75t_R  g032(.A1(new_n47_), .A2(new_n49_), .B(new_n50_), .Y(new_n51_));
  OAI21x1_ASAP7_75t_R  g033(.A1(new_n43_), .A2(new_n46_), .B(new_n51_), .Y(new_n52_));
  NOR2x1_ASAP7_75t_R   g034(.A(p7), .B(p8), .Y(new_n53_));
  XOR2x2_ASAP7_75t_R   g035(.A(p2), .B(p1), .Y(new_n54_));
  AOI21x1_ASAP7_75t_R  g036(.A1(new_n53_), .A2(new_n54_), .B(p9), .Y(new_n55_));
  OR3x1_ASAP7_75t_R    g037(.A(new_n42_), .B(new_n27_), .C(p5), .Y(new_n56_));
  OA21x2_ASAP7_75t_R   g038(.A1(new_n26_), .A2(p6), .B(new_n56_), .Y(new_n57_));
  NAND2x1_ASAP7_75t_R  g039(.A(p9), .B(p7), .Y(new_n58_));
  INVx1_ASAP7_75t_R    g040(.A(p8), .Y(new_n59_));
  OR3x1_ASAP7_75t_R    g041(.A(new_n58_), .B(new_n26_), .C(new_n59_), .Y(new_n60_));
  OAI21x1_ASAP7_75t_R  g042(.A1(new_n55_), .A2(new_n57_), .B(new_n60_), .Y(new_n61_));
  AOI21x1_ASAP7_75t_R  g043(.A1(new_n42_), .A2(new_n52_), .B(new_n61_), .Y(new_n62_));
  OAI21x1_ASAP7_75t_R  g044(.A1(new_n20_), .A2(new_n41_), .B(new_n62_), .Y(o0));
  NAND2x1_ASAP7_75t_R  g045(.A(new_n21_), .B(new_n59_), .Y(new_n64_));
  NAND2x1_ASAP7_75t_R  g046(.A(p8), .B(new_n27_), .Y(new_n65_));
  NAND2x1_ASAP7_75t_R  g047(.A(p4), .B(p5), .Y(new_n66_));
  AND3x1_ASAP7_75t_R   g048(.A(new_n64_), .B(new_n65_), .C(new_n66_), .Y(new_n67_));
  AOI21x1_ASAP7_75t_R  g049(.A1(new_n65_), .A2(new_n64_), .B(new_n26_), .Y(new_n68_));
  OR3x1_ASAP7_75t_R    g050(.A(new_n67_), .B(new_n53_), .C(new_n68_), .Y(new_n69_));
  NAND2x1_ASAP7_75t_R  g051(.A(p6), .B(new_n53_), .Y(new_n70_));
  OAI21x1_ASAP7_75t_R  g052(.A1(new_n37_), .A2(new_n70_), .B(new_n65_), .Y(new_n71_));
  INVx1_ASAP7_75t_R    g053(.A(p7), .Y(new_n72_));
  NOR2x1_ASAP7_75t_R   g054(.A(p5), .B(p3), .Y(new_n73_));
  AO32x1_ASAP7_75t_R   g055(.A1(new_n72_), .A2(p3), .A3(new_n59_), .B1(new_n73_), .B2(new_n27_), .Y(new_n74_));
  AND2x2_ASAP7_75t_R   g056(.A(p4), .B(p2), .Y(new_n75_));
  AO21x1_ASAP7_75t_R   g057(.A1(p0), .A2(p1), .B(p6), .Y(new_n76_));
  AND2x2_ASAP7_75t_R   g058(.A(new_n75_), .B(new_n76_), .Y(new_n77_));
  AOI22x1_ASAP7_75t_R  g059(.A1(new_n71_), .A2(new_n33_), .B1(new_n74_), .B2(new_n77_), .Y(new_n78_));
  OAI22x1_ASAP7_75t_R  g060(.A1(p6), .A2(p1), .B1(p3), .B2(p8), .Y(new_n79_));
  AO22x1_ASAP7_75t_R   g061(.A1(p7), .A2(new_n59_), .B1(new_n34_), .B2(new_n79_), .Y(new_n80_));
  NAND2x1_ASAP7_75t_R  g062(.A(p10), .B(p0), .Y(new_n81_));
  NAND2x1_ASAP7_75t_R  g063(.A(p3), .B(new_n27_), .Y(new_n82_));
  NOR2x1_ASAP7_75t_R   g064(.A(p1), .B(new_n24_), .Y(new_n83_));
  AOI211x1_ASAP7_75t_R g065(.A1(p1), .A2(new_n81_), .B(new_n82_), .C(new_n83_), .Y(new_n84_));
  NOR2x1_ASAP7_75t_R   g066(.A(p4), .B(p5), .Y(new_n85_));
  OAI21x1_ASAP7_75t_R  g067(.A1(new_n80_), .A2(new_n84_), .B(new_n85_), .Y(new_n86_));
  NAND3x1_ASAP7_75t_R  g068(.A(new_n69_), .B(new_n78_), .C(new_n86_), .Y(new_n87_));
  AO21x1_ASAP7_75t_R   g069(.A1(p5), .A2(p6), .B(p7), .Y(new_n88_));
  AO21x1_ASAP7_75t_R   g070(.A1(new_n42_), .A2(p6), .B(new_n88_), .Y(new_n89_));
  INVx1_ASAP7_75t_R    g071(.A(p1), .Y(new_n90_));
  NOR2x1_ASAP7_75t_R   g072(.A(p5), .B(p2), .Y(new_n91_));
  AO32x1_ASAP7_75t_R   g073(.A1(p5), .A2(new_n21_), .A3(new_n59_), .B1(new_n91_), .B2(p4), .Y(new_n92_));
  OAI22x1_ASAP7_75t_R  g074(.A1(new_n64_), .A2(new_n26_), .B1(new_n43_), .B2(p0), .Y(new_n93_));
  AND3x1_ASAP7_75t_R   g075(.A(p2), .B(p1), .C(p3), .Y(new_n94_));
  NOR2x1_ASAP7_75t_R   g076(.A(p8), .B(new_n26_), .Y(new_n95_));
  AO21x1_ASAP7_75t_R   g077(.A1(new_n94_), .A2(new_n95_), .B(p9), .Y(new_n96_));
  AOI221x1_ASAP7_75t_R g078(.A1(new_n90_), .A2(new_n92_), .B1(new_n93_), .B2(new_n35_), .C(new_n96_), .Y(new_n97_));
  AND2x2_ASAP7_75t_R   g079(.A(p5), .B(p6), .Y(new_n98_));
  INVx1_ASAP7_75t_R    g080(.A(new_n98_), .Y(new_n99_));
  OR3x1_ASAP7_75t_R    g081(.A(new_n99_), .B(p8), .C(new_n58_), .Y(new_n100_));
  OAI21x1_ASAP7_75t_R  g082(.A1(new_n89_), .A2(new_n97_), .B(new_n100_), .Y(new_n101_));
  AOI21x1_ASAP7_75t_R  g083(.A1(new_n42_), .A2(new_n87_), .B(new_n101_), .Y(o1));
  NOR2x1_ASAP7_75t_R   g084(.A(p2), .B(new_n33_), .Y(new_n103_));
  AND3x1_ASAP7_75t_R   g085(.A(new_n26_), .B(new_n90_), .C(p2), .Y(new_n104_));
  OAI21x1_ASAP7_75t_R  g086(.A1(new_n103_), .A2(new_n104_), .B(p3), .Y(new_n105_));
  INVx1_ASAP7_75t_R    g087(.A(new_n48_), .Y(new_n106_));
  AOI21x1_ASAP7_75t_R  g088(.A1(new_n90_), .A2(new_n105_), .B(new_n106_), .Y(new_n107_));
  AND3x1_ASAP7_75t_R   g089(.A(new_n21_), .B(p4), .C(p2), .Y(new_n108_));
  AND4x2_ASAP7_75t_R   g090(.A(new_n26_), .B(new_n35_), .C(p10), .D(p3), .Y(new_n109_));
  OAI21x1_ASAP7_75t_R  g091(.A1(new_n108_), .A2(new_n109_), .B(p0), .Y(new_n110_));
  NAND2x1_ASAP7_75t_R  g092(.A(p2), .B(p3), .Y(new_n111_));
  AOI21x1_ASAP7_75t_R  g093(.A1(p10), .A2(p0), .B(new_n111_), .Y(new_n112_));
  OAI21x1_ASAP7_75t_R  g094(.A1(new_n73_), .A2(new_n112_), .B(new_n33_), .Y(new_n113_));
  NAND3x1_ASAP7_75t_R  g095(.A(new_n110_), .B(new_n113_), .C(new_n105_), .Y(new_n114_));
  AND3x1_ASAP7_75t_R   g096(.A(new_n33_), .B(p5), .C(p1), .Y(new_n115_));
  AOI211x1_ASAP7_75t_R g097(.A1(new_n34_), .A2(new_n47_), .B(new_n111_), .C(new_n115_), .Y(new_n116_));
  AO21x1_ASAP7_75t_R   g098(.A1(new_n111_), .A2(new_n66_), .B(p7), .Y(new_n117_));
  AND2x2_ASAP7_75t_R   g099(.A(p4), .B(p3), .Y(new_n118_));
  INVx1_ASAP7_75t_R    g100(.A(new_n118_), .Y(new_n119_));
  AND5x1_ASAP7_75t_R   g101(.A(new_n26_), .B(p4), .C(p6), .D(p2), .E(p3), .Y(new_n120_));
  AND5x1_ASAP7_75t_R   g102(.A(p4), .B(new_n27_), .C(new_n90_), .D(p5), .E(p3), .Y(new_n121_));
  AOI211x1_ASAP7_75t_R g103(.A1(new_n98_), .A2(new_n119_), .B(new_n120_), .C(new_n121_), .Y(new_n122_));
  OAI21x1_ASAP7_75t_R  g104(.A1(new_n116_), .A2(new_n117_), .B(new_n122_), .Y(new_n123_));
  AOI21x1_ASAP7_75t_R  g105(.A1(new_n107_), .A2(new_n114_), .B(new_n123_), .Y(new_n124_));
  NAND2x1_ASAP7_75t_R  g106(.A(p6), .B(new_n26_), .Y(new_n125_));
  OR3x1_ASAP7_75t_R    g107(.A(new_n66_), .B(p6), .C(new_n21_), .Y(new_n126_));
  AO21x1_ASAP7_75t_R   g108(.A1(new_n125_), .A2(new_n126_), .B(new_n72_), .Y(new_n127_));
  OR3x1_ASAP7_75t_R    g109(.A(new_n33_), .B(new_n59_), .C(p7), .Y(new_n128_));
  AO21x1_ASAP7_75t_R   g110(.A1(new_n58_), .A2(new_n128_), .B(new_n99_), .Y(new_n129_));
  AND3x1_ASAP7_75t_R   g111(.A(new_n42_), .B(p4), .C(p6), .Y(new_n130_));
  NOR2x1_ASAP7_75t_R   g112(.A(p9), .B(p7), .Y(new_n131_));
  OR3x1_ASAP7_75t_R    g113(.A(new_n130_), .B(new_n59_), .C(new_n131_), .Y(new_n132_));
  OA211x2_ASAP7_75t_R  g114(.A1(p9), .A2(new_n127_), .B(new_n129_), .C(new_n132_), .Y(new_n133_));
  OAI21x1_ASAP7_75t_R  g115(.A1(new_n20_), .A2(new_n124_), .B(new_n133_), .Y(o2));
  NAND2x1_ASAP7_75t_R  g116(.A(new_n33_), .B(new_n27_), .Y(new_n135_));
  OR3x1_ASAP7_75t_R    g117(.A(new_n135_), .B(p5), .C(p3), .Y(new_n136_));
  OR3x1_ASAP7_75t_R    g118(.A(new_n66_), .B(new_n72_), .C(new_n27_), .Y(new_n137_));
  OR3x1_ASAP7_75t_R    g119(.A(new_n137_), .B(p1), .C(new_n21_), .Y(new_n138_));
  OA21x2_ASAP7_75t_R   g120(.A1(p7), .A2(new_n136_), .B(new_n138_), .Y(new_n139_));
  OR3x1_ASAP7_75t_R    g121(.A(new_n139_), .B(p2), .C(new_n20_), .Y(o3));
  INVx1_ASAP7_75t_R    g122(.A(new_n81_), .Y(new_n141_));
  AO32x1_ASAP7_75t_R   g123(.A1(p5), .A2(new_n27_), .A3(new_n118_), .B1(new_n141_), .B2(new_n85_), .Y(new_n142_));
  AND3x1_ASAP7_75t_R   g124(.A(new_n72_), .B(p2), .C(p1), .Y(new_n143_));
  NAND2x1_ASAP7_75t_R  g125(.A(new_n35_), .B(new_n90_), .Y(new_n144_));
  NAND2x1_ASAP7_75t_R  g126(.A(p2), .B(new_n72_), .Y(new_n145_));
  AND5x1_ASAP7_75t_R   g127(.A(new_n59_), .B(new_n144_), .C(new_n145_), .D(new_n98_), .E(new_n118_), .Y(new_n146_));
  AO221x2_ASAP7_75t_R  g128(.A1(p8), .A2(new_n137_), .B1(new_n142_), .B2(new_n143_), .C(new_n146_), .Y(new_n147_));
  OR3x1_ASAP7_75t_R    g129(.A(new_n34_), .B(new_n90_), .C(p6), .Y(new_n148_));
  AO21x1_ASAP7_75t_R   g130(.A1(new_n66_), .A2(new_n148_), .B(new_n111_), .Y(new_n149_));
  OA21x2_ASAP7_75t_R   g131(.A1(p6), .A2(new_n26_), .B(new_n72_), .Y(new_n150_));
  OA211x2_ASAP7_75t_R  g132(.A1(new_n21_), .A2(new_n135_), .B(new_n149_), .C(new_n150_), .Y(new_n151_));
  OAI21x1_ASAP7_75t_R  g133(.A1(new_n147_), .A2(new_n151_), .B(new_n42_), .Y(o4));
  OR5x1_ASAP7_75t_R    g134(.A(p4), .B(new_n145_), .C(p6), .D(new_n90_), .E(new_n81_), .Y(new_n153_));
  AO21x1_ASAP7_75t_R   g135(.A1(new_n35_), .A2(new_n90_), .B(new_n137_), .Y(new_n154_));
  AO21x1_ASAP7_75t_R   g136(.A1(new_n153_), .A2(new_n154_), .B(new_n21_), .Y(new_n155_));
  AND3x1_ASAP7_75t_R   g137(.A(new_n94_), .B(p4), .C(p5), .Y(new_n156_));
  OR3x1_ASAP7_75t_R    g138(.A(new_n156_), .B(new_n106_), .C(new_n85_), .Y(new_n157_));
  NAND3x1_ASAP7_75t_R  g139(.A(new_n155_), .B(new_n19_), .C(new_n157_), .Y(o5));
  OR3x1_ASAP7_75t_R    g140(.A(new_n156_), .B(new_n20_), .C(new_n106_), .Y(o6));
endmodule


