// Benchmark "/tmp/" written by ABC on Tue Oct 20 17:46:17 2026

module \/tmp/  ( 
    p9, p1, p2, p4, p6, p10, p3, p5, p7, p8, p0,
    o0, o1, o2, o3, o4, o5, o6  );
  input  p9, p1, p2, p4, p6, p10, p3, p5, p7, p8, p0;
  output o0, o1, o2, o3, o4, o5, o6;
  wire new_n19_, new_n20_, new_n21_, new_n22_, new_n23_, new_n24_, new_n25_,
    new_n26_, new_n27_, new_n28_, new_n29_, new_n30_, new_n31_, new_n32_,
    new_n33_, new_n34_, new_n35_, new_n36_, new_n37_, new_n38_, new_n39_,
    new_n40_, new_n41_, new_n42_, new_n43_, new_n44_, new_n45_, new_n46_,
    new_n47_, new_n48_, new_n49_, new_n50_, new_n51_, new_n52_, new_n53_,
    new_n54_, new_n55_, new_n56_, new_n57_, new_n58_, new_n59_, new_n60_,
    new_n61_, new_n62_, new_n63_, new_n64_, new_n65_, new_n67_, new_n68_,
    new_n69_, new_n70_, new_n71_, new_n72_, new_n73_, new_n74_, new_n75_,
    new_n76_, new_n77_, new_n78_, new_n79_, new_n80_, new_n81_, new_n82_,
    new_n83_, new_n84_, new_n85_, new_n86_, new_n87_, new_n88_, new_n89_,
    new_n90_, new_n91_, new_n92_, new_n93_, new_n94_, new_n95_, new_n96_,
    new_n97_, new_n98_, new_n99_, new_n100_, new_n101_, new_n102_,
    new_n103_, new_n105_, new_n106_, new_n107_, new_n108_, new_n109_,
    new_n110_, new_n111_, new_n112_, new_n113_, new_n114_, new_n115_,
    new_n116_, new_n117_, new_n118_, new_n119_, new_n120_, new_n121_,
    new_n122_, new_n123_, new_n124_, new_n125_, new_n126_, new_n127_,
    new_n128_, new_n129_, new_n130_, new_n131_, new_n132_, new_n133_,
    new_n134_, new_n135_, new_n136_, new_n138_, new_n139_, new_n140_,
    new_n141_, new_n142_, new_n143_, new_n145_, new_n146_, new_n147_,
    new_n148_, new_n149_, new_n150_, new_n151_, new_n152_, new_n153_,
    new_n155_, new_n156_, new_n157_, new_n158_, new_n159_;
  INVx1_ASAP7_75t_R    g000(.A(p3), .Y(new_n19_));
  INVx1_ASAP7_75t_R    g001(.A(p4), .Y(new_n20_));
  AO21x1_ASAP7_75t_R   g002(.A1(p7), .A2(new_n19_), .B(new_n20_), .Y(new_n21_));
  NAND2x1_ASAP7_75t_R  g003(.A(p3), .B(p0), .Y(new_n22_));
  NAND2x1_ASAP7_75t_R  g004(.A(p7), .B(new_n19_), .Y(new_n23_));
  INVx1_ASAP7_75t_R    g005(.A(p10), .Y(new_n24_));
  AOI21x1_ASAP7_75t_R  g006(.A1(new_n22_), .A2(new_n23_), .B(new_n24_), .Y(new_n25_));
  INVx1_ASAP7_75t_R    g007(.A(p6), .Y(new_n26_));
  INVx1_ASAP7_75t_R    g008(.A(p5), .Y(new_n27_));
  NAND2x1_ASAP7_75t_R  g009(.A(new_n26_), .B(new_n27_), .Y(new_n28_));
  AO21x1_ASAP7_75t_R   g010(.A1(new_n24_), .A2(new_n22_), .B(new_n28_), .Y(new_n29_));
  INVx1_ASAP7_75t_R    g011(.A(p7), .Y(new_n30_));
  OA21x2_ASAP7_75t_R   g012(.A1(new_n19_), .A2(new_n30_), .B(new_n20_), .Y(new_n31_));
  OAI21x1_ASAP7_75t_R  g013(.A1(new_n25_), .A2(new_n29_), .B(new_n31_), .Y(new_n32_));
  NAND2x1_ASAP7_75t_R  g014(.A(p2), .B(p4), .Y(new_n33_));
  INVx1_ASAP7_75t_R    g015(.A(p0), .Y(new_n34_));
  OR4x2_ASAP7_75t_R    g016(.A(new_n33_), .B(p1), .C(p6), .D(new_n34_), .Y(new_n35_));
  INVx1_ASAP7_75t_R    g017(.A(p2), .Y(new_n36_));
  NAND2x1_ASAP7_75t_R  g018(.A(p2), .B(p3), .Y(new_n37_));
  NAND2x1_ASAP7_75t_R  g019(.A(p6), .B(new_n37_), .Y(new_n38_));
  AO21x1_ASAP7_75t_R   g020(.A1(new_n36_), .A2(new_n19_), .B(new_n38_), .Y(new_n39_));
  AOI21x1_ASAP7_75t_R  g021(.A1(new_n35_), .A2(new_n39_), .B(p7), .Y(new_n40_));
  AOI21x1_ASAP7_75t_R  g022(.A1(new_n21_), .A2(new_n32_), .B(new_n40_), .Y(new_n41_));
  NOR2x1_ASAP7_75t_R   g023(.A(p9), .B(p8), .Y(new_n42_));
  INVx1_ASAP7_75t_R    g024(.A(new_n42_), .Y(new_n43_));
  INVx1_ASAP7_75t_R    g025(.A(p9), .Y(new_n44_));
  AOI211x1_ASAP7_75t_R g026(.A1(p6), .A2(new_n19_), .B(p1), .C(new_n34_), .Y(new_n45_));
  AO21x1_ASAP7_75t_R   g027(.A1(new_n36_), .A2(new_n30_), .B(new_n19_), .Y(new_n46_));
  NOR2x1_ASAP7_75t_R   g028(.A(p5), .B(new_n20_), .Y(new_n47_));
  NAND3x1_ASAP7_75t_R  g029(.A(new_n45_), .B(new_n46_), .C(new_n47_), .Y(new_n48_));
  NOR2x1_ASAP7_75t_R   g030(.A(p6), .B(p7), .Y(new_n49_));
  AO31x2_ASAP7_75t_R   g031(.A1(new_n49_), .A2(p1), .A3(new_n34_), .B(p8), .Y(new_n50_));
  NAND2x1_ASAP7_75t_R  g032(.A(p5), .B(p8), .Y(new_n51_));
  NOR2x1_ASAP7_75t_R   g033(.A(p4), .B(new_n51_), .Y(new_n52_));
  AOI21x1_ASAP7_75t_R  g034(.A1(new_n47_), .A2(new_n50_), .B(new_n52_), .Y(new_n53_));
  NAND2x1_ASAP7_75t_R  g035(.A(new_n48_), .B(new_n53_), .Y(new_n54_));
  NOR2x1_ASAP7_75t_R   g036(.A(p1), .B(p2), .Y(new_n55_));
  INVx1_ASAP7_75t_R    g037(.A(new_n55_), .Y(new_n56_));
  NOR2x1_ASAP7_75t_R   g038(.A(p7), .B(p8), .Y(new_n57_));
  NAND2x1_ASAP7_75t_R  g039(.A(p1), .B(p2), .Y(new_n58_));
  NAND3x1_ASAP7_75t_R  g040(.A(new_n56_), .B(new_n57_), .C(new_n58_), .Y(new_n59_));
  AND3x1_ASAP7_75t_R   g041(.A(p5), .B(p7), .C(p8), .Y(new_n60_));
  NOR2x1_ASAP7_75t_R   g042(.A(p5), .B(new_n26_), .Y(new_n61_));
  OAI21x1_ASAP7_75t_R  g043(.A1(new_n60_), .A2(new_n61_), .B(p9), .Y(new_n62_));
  NAND2x1_ASAP7_75t_R  g044(.A(p5), .B(new_n26_), .Y(new_n63_));
  AOI22x1_ASAP7_75t_R  g045(.A1(new_n44_), .A2(new_n59_), .B1(new_n62_), .B2(new_n63_), .Y(new_n64_));
  AOI21x1_ASAP7_75t_R  g046(.A1(new_n44_), .A2(new_n54_), .B(new_n64_), .Y(new_n65_));
  OAI21x1_ASAP7_75t_R  g047(.A1(new_n41_), .A2(new_n43_), .B(new_n65_), .Y(o0));
  INVx1_ASAP7_75t_R    g048(.A(new_n57_), .Y(new_n67_));
  NAND2x1_ASAP7_75t_R  g049(.A(p8), .B(new_n26_), .Y(new_n68_));
  OAI21x1_ASAP7_75t_R  g050(.A1(new_n67_), .A2(new_n38_), .B(new_n68_), .Y(new_n69_));
  NOR2x1_ASAP7_75t_R   g051(.A(p3), .B(p8), .Y(new_n70_));
  NAND2x1_ASAP7_75t_R  g052(.A(p7), .B(new_n70_), .Y(new_n71_));
  NAND2x1_ASAP7_75t_R  g053(.A(new_n68_), .B(new_n71_), .Y(new_n72_));
  AOI22x1_ASAP7_75t_R  g054(.A1(new_n69_), .A2(new_n20_), .B1(new_n27_), .B2(new_n72_), .Y(new_n73_));
  OAI21x1_ASAP7_75t_R  g055(.A1(p7), .A2(p8), .B(p5), .Y(new_n74_));
  AOI211x1_ASAP7_75t_R g056(.A1(new_n26_), .A2(p8), .B(new_n70_), .C(new_n74_), .Y(new_n75_));
  OAI21x1_ASAP7_75t_R  g057(.A1(p6), .A2(p5), .B(new_n19_), .Y(new_n76_));
  OAI21x1_ASAP7_75t_R  g058(.A1(p7), .A2(p8), .B(p3), .Y(new_n77_));
  AO21x1_ASAP7_75t_R   g059(.A1(p1), .A2(p0), .B(p6), .Y(new_n78_));
  AND4x2_ASAP7_75t_R   g060(.A(new_n76_), .B(p2), .C(new_n77_), .D(new_n78_), .Y(new_n79_));
  OAI21x1_ASAP7_75t_R  g061(.A1(new_n75_), .A2(new_n79_), .B(p4), .Y(new_n80_));
  INVx1_ASAP7_75t_R    g062(.A(p8), .Y(new_n81_));
  OAI22x1_ASAP7_75t_R  g063(.A1(p1), .A2(p6), .B1(p3), .B2(p8), .Y(new_n82_));
  AO22x1_ASAP7_75t_R   g064(.A1(p7), .A2(new_n81_), .B1(new_n34_), .B2(new_n82_), .Y(new_n83_));
  NAND2x1_ASAP7_75t_R  g065(.A(p1), .B(p0), .Y(new_n84_));
  NAND2x1_ASAP7_75t_R  g066(.A(p3), .B(new_n26_), .Y(new_n85_));
  INVx1_ASAP7_75t_R    g067(.A(p1), .Y(new_n86_));
  NOR2x1_ASAP7_75t_R   g068(.A(p10), .B(new_n86_), .Y(new_n87_));
  AOI211x1_ASAP7_75t_R g069(.A1(p10), .A2(new_n84_), .B(new_n85_), .C(new_n87_), .Y(new_n88_));
  NOR2x1_ASAP7_75t_R   g070(.A(p4), .B(p5), .Y(new_n89_));
  OAI21x1_ASAP7_75t_R  g071(.A1(new_n83_), .A2(new_n88_), .B(new_n89_), .Y(new_n90_));
  NAND3x1_ASAP7_75t_R  g072(.A(new_n73_), .B(new_n80_), .C(new_n90_), .Y(new_n91_));
  AO21x1_ASAP7_75t_R   g073(.A1(p6), .A2(p5), .B(p7), .Y(new_n92_));
  OA21x2_ASAP7_75t_R   g074(.A1(p3), .A2(new_n58_), .B(new_n26_), .Y(new_n93_));
  AOI21x1_ASAP7_75t_R  g075(.A1(p1), .A2(p2), .B(new_n19_), .Y(new_n94_));
  NAND2x1_ASAP7_75t_R  g076(.A(p5), .B(new_n81_), .Y(new_n95_));
  NAND2x1_ASAP7_75t_R  g077(.A(p4), .B(new_n27_), .Y(new_n96_));
  AO21x1_ASAP7_75t_R   g078(.A1(p1), .A2(p0), .B(p2), .Y(new_n97_));
  OAI22x1_ASAP7_75t_R  g079(.A1(new_n94_), .A2(new_n95_), .B1(new_n96_), .B2(new_n97_), .Y(new_n98_));
  AOI21x1_ASAP7_75t_R  g080(.A1(new_n93_), .A2(new_n98_), .B(p9), .Y(new_n99_));
  NAND2x1_ASAP7_75t_R  g081(.A(p9), .B(p7), .Y(new_n100_));
  NAND2x1_ASAP7_75t_R  g082(.A(p6), .B(p5), .Y(new_n101_));
  OR3x1_ASAP7_75t_R    g083(.A(new_n100_), .B(new_n101_), .C(p8), .Y(new_n102_));
  OAI21x1_ASAP7_75t_R  g084(.A1(new_n92_), .A2(new_n99_), .B(new_n102_), .Y(new_n103_));
  AOI21x1_ASAP7_75t_R  g085(.A1(new_n44_), .A2(new_n91_), .B(new_n103_), .Y(o1));
  AND2x2_ASAP7_75t_R   g086(.A(p2), .B(p3), .Y(new_n105_));
  NOR2x1_ASAP7_75t_R   g087(.A(p1), .B(p5), .Y(new_n106_));
  AND3x1_ASAP7_75t_R   g088(.A(new_n36_), .B(p4), .C(p3), .Y(new_n107_));
  AOI21x1_ASAP7_75t_R  g089(.A1(new_n105_), .A2(new_n106_), .B(new_n107_), .Y(new_n108_));
  INVx1_ASAP7_75t_R    g090(.A(new_n49_), .Y(new_n109_));
  AOI21x1_ASAP7_75t_R  g091(.A1(new_n86_), .A2(new_n108_), .B(new_n109_), .Y(new_n110_));
  NOR2x1_ASAP7_75t_R   g092(.A(p3), .B(p5), .Y(new_n111_));
  AOI21x1_ASAP7_75t_R  g093(.A1(p10), .A2(p0), .B(new_n37_), .Y(new_n112_));
  OAI21x1_ASAP7_75t_R  g094(.A1(new_n111_), .A2(new_n112_), .B(new_n20_), .Y(new_n113_));
  NOR3x1_ASAP7_75t_R   g095(.A(new_n24_), .B(p2), .C(p5), .Y(new_n114_));
  AOI21x1_ASAP7_75t_R  g096(.A1(new_n19_), .A2(new_n33_), .B(new_n34_), .Y(new_n115_));
  OAI21x1_ASAP7_75t_R  g097(.A1(new_n19_), .A2(new_n114_), .B(new_n115_), .Y(new_n116_));
  NAND3x1_ASAP7_75t_R  g098(.A(new_n113_), .B(new_n108_), .C(new_n116_), .Y(new_n117_));
  NAND2x1_ASAP7_75t_R  g099(.A(p4), .B(p5), .Y(new_n118_));
  AO21x1_ASAP7_75t_R   g100(.A1(new_n37_), .A2(new_n118_), .B(p7), .Y(new_n119_));
  AND3x1_ASAP7_75t_R   g101(.A(new_n20_), .B(p1), .C(p5), .Y(new_n120_));
  AOI211x1_ASAP7_75t_R g102(.A1(new_n34_), .A2(new_n47_), .B(new_n37_), .C(new_n120_), .Y(new_n121_));
  NOR2x1_ASAP7_75t_R   g103(.A(p1), .B(p6), .Y(new_n122_));
  AND3x1_ASAP7_75t_R   g104(.A(p4), .B(p3), .C(p5), .Y(new_n123_));
  AND3x1_ASAP7_75t_R   g105(.A(p2), .B(p4), .C(p3), .Y(new_n124_));
  AOI21x1_ASAP7_75t_R  g106(.A1(p4), .A2(p3), .B(new_n101_), .Y(new_n125_));
  AOI221x1_ASAP7_75t_R g107(.A1(new_n122_), .A2(new_n123_), .B1(new_n61_), .B2(new_n124_), .C(new_n125_), .Y(new_n126_));
  OAI21x1_ASAP7_75t_R  g108(.A1(new_n119_), .A2(new_n121_), .B(new_n126_), .Y(new_n127_));
  AOI21x1_ASAP7_75t_R  g109(.A1(new_n110_), .A2(new_n117_), .B(new_n127_), .Y(new_n128_));
  AO21x1_ASAP7_75t_R   g110(.A1(new_n26_), .A2(new_n123_), .B(new_n61_), .Y(new_n129_));
  AND3x1_ASAP7_75t_R   g111(.A(new_n129_), .B(new_n44_), .C(p7), .Y(new_n130_));
  AND3x1_ASAP7_75t_R   g112(.A(new_n44_), .B(p4), .C(p6), .Y(new_n131_));
  AO21x1_ASAP7_75t_R   g113(.A1(new_n44_), .A2(new_n30_), .B(new_n81_), .Y(new_n132_));
  OR3x1_ASAP7_75t_R    g114(.A(new_n20_), .B(new_n81_), .C(p7), .Y(new_n133_));
  AO21x1_ASAP7_75t_R   g115(.A1(new_n100_), .A2(new_n133_), .B(new_n101_), .Y(new_n134_));
  OAI21x1_ASAP7_75t_R  g116(.A1(new_n131_), .A2(new_n132_), .B(new_n134_), .Y(new_n135_));
  NOR2x1_ASAP7_75t_R   g117(.A(new_n130_), .B(new_n135_), .Y(new_n136_));
  OAI21x1_ASAP7_75t_R  g118(.A1(new_n43_), .A2(new_n128_), .B(new_n136_), .Y(o2));
  NOR2x1_ASAP7_75t_R   g119(.A(p4), .B(p6), .Y(new_n138_));
  AND3x1_ASAP7_75t_R   g120(.A(new_n111_), .B(new_n138_), .C(new_n30_), .Y(new_n139_));
  AND2x2_ASAP7_75t_R   g121(.A(p4), .B(p5), .Y(new_n140_));
  AND3x1_ASAP7_75t_R   g122(.A(new_n140_), .B(p6), .C(p7), .Y(new_n141_));
  AND3x1_ASAP7_75t_R   g123(.A(new_n141_), .B(new_n86_), .C(p3), .Y(new_n142_));
  NOR2x1_ASAP7_75t_R   g124(.A(new_n139_), .B(new_n142_), .Y(new_n143_));
  OR3x1_ASAP7_75t_R    g125(.A(new_n143_), .B(p2), .C(new_n43_), .Y(o3));
  NOR2x1_ASAP7_75t_R   g126(.A(p7), .B(new_n36_), .Y(new_n145_));
  OR5x1_ASAP7_75t_R    g127(.A(new_n20_), .B(new_n145_), .C(new_n19_), .D(new_n55_), .E(new_n101_), .Y(new_n146_));
  AND3x1_ASAP7_75t_R   g128(.A(new_n60_), .B(p4), .C(p6), .Y(new_n147_));
  AO21x1_ASAP7_75t_R   g129(.A1(new_n81_), .A2(new_n146_), .B(new_n147_), .Y(new_n148_));
  AO32x1_ASAP7_75t_R   g130(.A1(p10), .A2(p0), .A3(new_n89_), .B1(new_n123_), .B2(new_n26_), .Y(new_n149_));
  NAND3x1_ASAP7_75t_R  g131(.A(new_n149_), .B(p1), .C(new_n145_), .Y(new_n150_));
  OAI21x1_ASAP7_75t_R  g132(.A1(p6), .A2(new_n84_), .B(new_n118_), .Y(new_n151_));
  AO21x1_ASAP7_75t_R   g133(.A1(p5), .A2(new_n26_), .B(p7), .Y(new_n152_));
  AO221x2_ASAP7_75t_R  g134(.A1(p3), .A2(new_n138_), .B1(new_n151_), .B2(new_n105_), .C(new_n152_), .Y(new_n153_));
  AO31x2_ASAP7_75t_R   g135(.A1(new_n148_), .A2(new_n150_), .A3(new_n153_), .B(p9), .Y(o4));
  AND3x1_ASAP7_75t_R   g136(.A(new_n138_), .B(p10), .C(p0), .Y(new_n155_));
  AO32x1_ASAP7_75t_R   g137(.A1(p1), .A2(new_n145_), .A3(new_n155_), .B1(new_n141_), .B2(new_n56_), .Y(new_n156_));
  AND3x1_ASAP7_75t_R   g138(.A(new_n105_), .B(new_n140_), .C(p1), .Y(new_n157_));
  OR3x1_ASAP7_75t_R    g139(.A(new_n157_), .B(new_n109_), .C(new_n89_), .Y(new_n158_));
  NAND2x1_ASAP7_75t_R  g140(.A(new_n42_), .B(new_n158_), .Y(new_n159_));
  AO21x1_ASAP7_75t_R   g141(.A1(p3), .A2(new_n156_), .B(new_n159_), .Y(o5));
  OR3x1_ASAP7_75t_R    g142(.A(new_n157_), .B(new_n43_), .C(new_n109_), .Y(o6));
endmodule


