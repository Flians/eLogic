// Benchmark "/tmp/" written by ABC on Tue Oct 20 17:46:17 2026

module \/tmp/  ( 
    p10, p2, p5, p6, p9, p1, p0, p8, p4, p3, p7,
    o0, o1, o2, o3, o4, o5, o6  );
  input  p10, p2, p5, p6, p9, p1, p0, p8, p4, p3, p7;
  output o0, o1, o2, o3, o4, o5, o6;
  wire new_n19_, new_n20_, new_n21_, new_n22_, new_n23_, new_n24_, new_n25_,
    new_n26_, new_n27_, new_n28_, new_n29_, new_n30_, new_n31_, new_n32_,
    new_n33_, new_n34_, new_n35_, new_n36_, new_n37_, new_n38_, new_n39_,
    new_n40_, new_n41_, new_n42_, new_n43_, new_n44_, new_n45_, new_n46_,
    new_n47_, new_n48_, new_n49_, new_n50_, new_n51_, new_n52_, new_n53_,
    new_n54_, new_n55_, new_n56_, new_n57_, new_n58_, new_n59_, new_n60_,
    new_n61_, new_n62_, new_n63_, new_n65_, new_n66_, new_n67_, new_n68_,
    new_n69_, new_n70_, new_n71_, new_n72_, new_n73_, new_n74_, new_n75_,
    new_n76_, new_n77_, new_n78_, new_n79_, new_n80_, new_n81_, new_n82_,
    new_n83_, new_n84_, new_n85_, new_n86_, new_n87_, new_n88_, new_n89_,
    new_n90_, new_n91_, new_n92_, new_n93_, new_n94_, new_n95_, new_n96_,
    new_n98_, new_n99_, new_n100_, new_n101_, new_n102_, new_n103_,
    new_n104_, new_n105_, new_n106_, new_n107_, new_n108_, new_n109_,
    new_n110_, new_n111_, new_n112_, new_n113_, new_n114_, new_n115_,
    new_n116_, new_n117_, new_n118_, new_n119_, new_n120_, new_n121_,
    new_n122_, new_n123_, new_n124_, new_n125_, new_n126_, new_n128_,
    new_n129_, new_n130_, new_n131_, new_n133_, new_n134_, new_n135_,
    new_n136_, new_n137_, new_n138_, new_n139_, new_n140_, new_n141_,
    new_n142_, new_n143_, new_n144_, new_n146_, new_n147_, new_n148_,
    new_n149_, new_n150_;
  INVx1_ASAP7_75t_R    g000(.A(p3), .Y(new_n19_));
  NAND2x1_ASAP7_75t_R  g001(.A(p7), .B(new_n19_), .Y(new_n20_));
  AND2x2_ASAP7_75t_R   g002(.A(p4), .B(new_n20_), .Y(new_n21_));
  INVx1_ASAP7_75t_R    g003(.A(p10), .Y(new_n22_));
  NAND2x1_ASAP7_75t_R  g004(.A(p0), .B(p3), .Y(new_n23_));
  AOI211x1_ASAP7_75t_R g005(.A1(new_n22_), .A2(new_n23_), .B(p5), .C(p6), .Y(new_n24_));
  AO21x1_ASAP7_75t_R   g006(.A1(new_n23_), .A2(new_n20_), .B(new_n22_), .Y(new_n25_));
  AO21x1_ASAP7_75t_R   g007(.A1(p3), .A2(p7), .B(p4), .Y(new_n26_));
  AOI21x1_ASAP7_75t_R  g008(.A1(new_n24_), .A2(new_n25_), .B(new_n26_), .Y(new_n27_));
  INVx1_ASAP7_75t_R    g009(.A(p2), .Y(new_n28_));
  INVx1_ASAP7_75t_R    g010(.A(p0), .Y(new_n29_));
  INVx1_ASAP7_75t_R    g011(.A(p4), .Y(new_n30_));
  OR5x1_ASAP7_75t_R    g012(.A(new_n28_), .B(new_n29_), .C(new_n30_), .D(p6), .E(p1), .Y(new_n31_));
  AND2x2_ASAP7_75t_R   g013(.A(p2), .B(p3), .Y(new_n32_));
  INVx1_ASAP7_75t_R    g014(.A(p6), .Y(new_n33_));
  NOR2x1_ASAP7_75t_R   g015(.A(p2), .B(p3), .Y(new_n34_));
  OR3x1_ASAP7_75t_R    g016(.A(new_n32_), .B(new_n33_), .C(new_n34_), .Y(new_n35_));
  AO21x1_ASAP7_75t_R   g017(.A1(new_n31_), .A2(new_n35_), .B(p7), .Y(new_n36_));
  OA21x2_ASAP7_75t_R   g018(.A1(new_n21_), .A2(new_n27_), .B(new_n36_), .Y(new_n37_));
  NOR2x1_ASAP7_75t_R   g019(.A(p9), .B(p8), .Y(new_n38_));
  INVx1_ASAP7_75t_R    g020(.A(new_n38_), .Y(new_n39_));
  INVx1_ASAP7_75t_R    g021(.A(p9), .Y(new_n40_));
  INVx1_ASAP7_75t_R    g022(.A(p5), .Y(new_n41_));
  NAND2x1_ASAP7_75t_R  g023(.A(p4), .B(new_n41_), .Y(new_n42_));
  NOR2x1_ASAP7_75t_R   g024(.A(p3), .B(new_n33_), .Y(new_n43_));
  AND2x2_ASAP7_75t_R   g025(.A(p3), .B(p7), .Y(new_n44_));
  OR5x1_ASAP7_75t_R    g026(.A(p1), .B(new_n43_), .C(new_n29_), .D(new_n32_), .E(new_n44_), .Y(new_n45_));
  INVx1_ASAP7_75t_R    g027(.A(new_n42_), .Y(new_n46_));
  NOR2x1_ASAP7_75t_R   g028(.A(p6), .B(p7), .Y(new_n47_));
  AO31x2_ASAP7_75t_R   g029(.A1(new_n47_), .A2(p1), .A3(new_n29_), .B(p8), .Y(new_n48_));
  AND3x1_ASAP7_75t_R   g030(.A(new_n30_), .B(p5), .C(p8), .Y(new_n49_));
  AOI21x1_ASAP7_75t_R  g031(.A1(new_n46_), .A2(new_n48_), .B(new_n49_), .Y(new_n50_));
  OAI21x1_ASAP7_75t_R  g032(.A1(new_n42_), .A2(new_n45_), .B(new_n50_), .Y(new_n51_));
  NAND2x1_ASAP7_75t_R  g033(.A(p2), .B(p1), .Y(new_n52_));
  INVx1_ASAP7_75t_R    g034(.A(p1), .Y(new_n53_));
  NAND2x1_ASAP7_75t_R  g035(.A(new_n28_), .B(new_n53_), .Y(new_n54_));
  AO21x1_ASAP7_75t_R   g036(.A1(new_n52_), .A2(new_n54_), .B(p9), .Y(new_n55_));
  INVx1_ASAP7_75t_R    g037(.A(p8), .Y(new_n56_));
  INVx1_ASAP7_75t_R    g038(.A(p7), .Y(new_n57_));
  NAND2x1_ASAP7_75t_R  g039(.A(new_n56_), .B(new_n57_), .Y(new_n58_));
  AOI21x1_ASAP7_75t_R  g040(.A1(new_n40_), .A2(new_n58_), .B(p6), .Y(new_n59_));
  AND3x1_ASAP7_75t_R   g041(.A(p5), .B(p8), .C(p7), .Y(new_n60_));
  AO21x1_ASAP7_75t_R   g042(.A1(new_n41_), .A2(p6), .B(new_n60_), .Y(new_n61_));
  AO32x1_ASAP7_75t_R   g043(.A1(new_n55_), .A2(p5), .A3(new_n59_), .B1(p9), .B2(new_n61_), .Y(new_n62_));
  AOI21x1_ASAP7_75t_R  g044(.A1(new_n40_), .A2(new_n51_), .B(new_n62_), .Y(new_n63_));
  OAI21x1_ASAP7_75t_R  g045(.A1(new_n37_), .A2(new_n39_), .B(new_n63_), .Y(o0));
  AO21x1_ASAP7_75t_R   g046(.A1(p2), .A2(p3), .B(new_n33_), .Y(new_n65_));
  OAI22x1_ASAP7_75t_R  g047(.A1(new_n65_), .A2(new_n58_), .B1(p6), .B2(new_n56_), .Y(new_n66_));
  OAI21x1_ASAP7_75t_R  g048(.A1(p5), .A2(p6), .B(new_n19_), .Y(new_n67_));
  OAI21x1_ASAP7_75t_R  g049(.A1(p8), .A2(p7), .B(p3), .Y(new_n68_));
  AO21x1_ASAP7_75t_R   g050(.A1(p1), .A2(p0), .B(p6), .Y(new_n69_));
  AND5x1_ASAP7_75t_R   g051(.A(p2), .B(new_n67_), .C(p4), .D(new_n68_), .E(new_n69_), .Y(new_n70_));
  AOI21x1_ASAP7_75t_R  g052(.A1(new_n30_), .A2(new_n66_), .B(new_n70_), .Y(new_n71_));
  NAND2x1_ASAP7_75t_R  g053(.A(p10), .B(p0), .Y(new_n72_));
  NAND2x1_ASAP7_75t_R  g054(.A(p3), .B(new_n33_), .Y(new_n73_));
  NOR2x1_ASAP7_75t_R   g055(.A(p1), .B(new_n22_), .Y(new_n74_));
  AOI211x1_ASAP7_75t_R g056(.A1(p1), .A2(new_n72_), .B(new_n73_), .C(new_n74_), .Y(new_n75_));
  NOR2x1_ASAP7_75t_R   g057(.A(p8), .B(p3), .Y(new_n76_));
  AOI21x1_ASAP7_75t_R  g058(.A1(new_n33_), .A2(new_n53_), .B(new_n76_), .Y(new_n77_));
  OAI22x1_ASAP7_75t_R  g059(.A1(new_n77_), .A2(p0), .B1(p8), .B2(new_n57_), .Y(new_n78_));
  NOR2x1_ASAP7_75t_R   g060(.A(p5), .B(p4), .Y(new_n79_));
  OAI21x1_ASAP7_75t_R  g061(.A1(new_n75_), .A2(new_n78_), .B(new_n79_), .Y(new_n80_));
  NOR2x1_ASAP7_75t_R   g062(.A(p6), .B(new_n56_), .Y(new_n81_));
  AND2x2_ASAP7_75t_R   g063(.A(p5), .B(p4), .Y(new_n82_));
  OR3x1_ASAP7_75t_R    g064(.A(new_n81_), .B(new_n82_), .C(new_n76_), .Y(new_n83_));
  OAI21x1_ASAP7_75t_R  g065(.A1(new_n76_), .A2(new_n81_), .B(p5), .Y(new_n84_));
  NAND3x1_ASAP7_75t_R  g066(.A(new_n83_), .B(new_n84_), .C(new_n58_), .Y(new_n85_));
  NAND3x1_ASAP7_75t_R  g067(.A(new_n71_), .B(new_n80_), .C(new_n85_), .Y(new_n86_));
  OA21x2_ASAP7_75t_R   g068(.A1(p3), .A2(new_n52_), .B(new_n33_), .Y(new_n87_));
  AND2x2_ASAP7_75t_R   g069(.A(p3), .B(new_n52_), .Y(new_n88_));
  NAND2x1_ASAP7_75t_R  g070(.A(p5), .B(new_n56_), .Y(new_n89_));
  AO21x1_ASAP7_75t_R   g071(.A1(p1), .A2(p0), .B(p2), .Y(new_n90_));
  OAI22x1_ASAP7_75t_R  g072(.A1(new_n88_), .A2(new_n89_), .B1(new_n42_), .B2(new_n90_), .Y(new_n91_));
  AOI21x1_ASAP7_75t_R  g073(.A1(new_n87_), .A2(new_n91_), .B(p9), .Y(new_n92_));
  AO21x1_ASAP7_75t_R   g074(.A1(p5), .A2(p6), .B(p7), .Y(new_n93_));
  NAND2x1_ASAP7_75t_R  g075(.A(p9), .B(p7), .Y(new_n94_));
  OR3x1_ASAP7_75t_R    g076(.A(new_n94_), .B(new_n41_), .C(new_n33_), .Y(new_n95_));
  OAI22x1_ASAP7_75t_R  g077(.A1(new_n92_), .A2(new_n93_), .B1(p8), .B2(new_n95_), .Y(new_n96_));
  AOI21x1_ASAP7_75t_R  g078(.A1(new_n40_), .A2(new_n86_), .B(new_n96_), .Y(o1));
  AND2x2_ASAP7_75t_R   g079(.A(p4), .B(p3), .Y(new_n98_));
  AO32x1_ASAP7_75t_R   g080(.A1(new_n32_), .A2(new_n41_), .A3(new_n53_), .B1(new_n98_), .B2(new_n28_), .Y(new_n99_));
  OAI21x1_ASAP7_75t_R  g081(.A1(p1), .A2(new_n99_), .B(new_n47_), .Y(new_n100_));
  NOR2x1_ASAP7_75t_R   g082(.A(p5), .B(p3), .Y(new_n101_));
  AO21x1_ASAP7_75t_R   g083(.A1(new_n72_), .A2(new_n32_), .B(new_n101_), .Y(new_n102_));
  NAND2x1_ASAP7_75t_R  g084(.A(p3), .B(new_n28_), .Y(new_n103_));
  NAND2x1_ASAP7_75t_R  g085(.A(p10), .B(new_n41_), .Y(new_n104_));
  NAND3x1_ASAP7_75t_R  g086(.A(new_n19_), .B(p2), .C(p4), .Y(new_n105_));
  OAI21x1_ASAP7_75t_R  g087(.A1(new_n103_), .A2(new_n104_), .B(new_n105_), .Y(new_n106_));
  AOI221x1_ASAP7_75t_R g088(.A1(new_n30_), .A2(new_n102_), .B1(new_n106_), .B2(p0), .C(new_n99_), .Y(new_n107_));
  AND3x1_ASAP7_75t_R   g089(.A(new_n82_), .B(new_n33_), .C(p3), .Y(new_n108_));
  NAND3x1_ASAP7_75t_R  g090(.A(new_n41_), .B(new_n29_), .C(p4), .Y(new_n109_));
  NAND3x1_ASAP7_75t_R  g091(.A(new_n30_), .B(p5), .C(p1), .Y(new_n110_));
  NAND3x1_ASAP7_75t_R  g092(.A(new_n109_), .B(new_n110_), .C(new_n32_), .Y(new_n111_));
  OA21x2_ASAP7_75t_R   g093(.A1(new_n32_), .A2(new_n82_), .B(new_n57_), .Y(new_n112_));
  AND2x2_ASAP7_75t_R   g094(.A(p5), .B(p6), .Y(new_n113_));
  NAND2x1_ASAP7_75t_R  g095(.A(p4), .B(p3), .Y(new_n114_));
  AND3x1_ASAP7_75t_R   g096(.A(p2), .B(p4), .C(p3), .Y(new_n115_));
  NOR2x1_ASAP7_75t_R   g097(.A(p5), .B(new_n33_), .Y(new_n116_));
  AO22x1_ASAP7_75t_R   g098(.A1(new_n113_), .A2(new_n114_), .B1(new_n115_), .B2(new_n116_), .Y(new_n117_));
  AOI221x1_ASAP7_75t_R g099(.A1(new_n53_), .A2(new_n108_), .B1(new_n111_), .B2(new_n112_), .C(new_n117_), .Y(new_n118_));
  OAI21x1_ASAP7_75t_R  g100(.A1(new_n100_), .A2(new_n107_), .B(new_n118_), .Y(new_n119_));
  OAI21x1_ASAP7_75t_R  g101(.A1(new_n116_), .A2(new_n108_), .B(p7), .Y(new_n120_));
  OR3x1_ASAP7_75t_R    g102(.A(new_n56_), .B(new_n30_), .C(p7), .Y(new_n121_));
  NAND2x1_ASAP7_75t_R  g103(.A(new_n94_), .B(new_n121_), .Y(new_n122_));
  OR3x1_ASAP7_75t_R    g104(.A(new_n33_), .B(new_n30_), .C(p9), .Y(new_n123_));
  OA21x2_ASAP7_75t_R   g105(.A1(p9), .A2(p7), .B(p8), .Y(new_n124_));
  AOI22x1_ASAP7_75t_R  g106(.A1(new_n122_), .A2(new_n113_), .B1(new_n123_), .B2(new_n124_), .Y(new_n125_));
  OAI21x1_ASAP7_75t_R  g107(.A1(p9), .A2(new_n120_), .B(new_n125_), .Y(new_n126_));
  AO21x1_ASAP7_75t_R   g108(.A1(new_n38_), .A2(new_n119_), .B(new_n126_), .Y(o2));
  AND5x1_ASAP7_75t_R   g109(.A(new_n41_), .B(new_n33_), .C(new_n30_), .D(new_n19_), .E(new_n57_), .Y(new_n128_));
  AND3x1_ASAP7_75t_R   g110(.A(new_n82_), .B(p6), .C(p7), .Y(new_n129_));
  AND3x1_ASAP7_75t_R   g111(.A(new_n129_), .B(new_n53_), .C(p3), .Y(new_n130_));
  NOR2x1_ASAP7_75t_R   g112(.A(new_n128_), .B(new_n130_), .Y(new_n131_));
  OR3x1_ASAP7_75t_R    g113(.A(new_n131_), .B(p2), .C(new_n39_), .Y(o3));
  OA21x2_ASAP7_75t_R   g114(.A1(new_n28_), .A2(p7), .B(new_n98_), .Y(new_n133_));
  AND3x1_ASAP7_75t_R   g115(.A(new_n133_), .B(new_n54_), .C(new_n113_), .Y(new_n134_));
  NAND2x1_ASAP7_75t_R  g116(.A(p8), .B(new_n129_), .Y(new_n135_));
  OAI21x1_ASAP7_75t_R  g117(.A1(p8), .A2(new_n134_), .B(new_n135_), .Y(new_n136_));
  INVx1_ASAP7_75t_R    g118(.A(new_n72_), .Y(new_n137_));
  AOI21x1_ASAP7_75t_R  g119(.A1(new_n137_), .A2(new_n79_), .B(new_n108_), .Y(new_n138_));
  OR3x1_ASAP7_75t_R    g120(.A(new_n138_), .B(p7), .C(new_n52_), .Y(new_n139_));
  AND3x1_ASAP7_75t_R   g121(.A(new_n33_), .B(p1), .C(p0), .Y(new_n140_));
  OA21x2_ASAP7_75t_R   g122(.A1(new_n82_), .A2(new_n140_), .B(new_n32_), .Y(new_n141_));
  AND3x1_ASAP7_75t_R   g123(.A(new_n33_), .B(new_n30_), .C(p3), .Y(new_n142_));
  AO21x1_ASAP7_75t_R   g124(.A1(p5), .A2(new_n33_), .B(p7), .Y(new_n143_));
  OR3x1_ASAP7_75t_R    g125(.A(new_n141_), .B(new_n142_), .C(new_n143_), .Y(new_n144_));
  AO31x2_ASAP7_75t_R   g126(.A1(new_n136_), .A2(new_n139_), .A3(new_n144_), .B(p9), .Y(o4));
  AND5x1_ASAP7_75t_R   g127(.A(p10), .B(new_n33_), .C(new_n30_), .D(p2), .E(p0), .Y(new_n146_));
  AO32x1_ASAP7_75t_R   g128(.A1(p1), .A2(new_n146_), .A3(new_n57_), .B1(new_n129_), .B2(new_n54_), .Y(new_n147_));
  OR3x1_ASAP7_75t_R    g129(.A(new_n79_), .B(p6), .C(p7), .Y(new_n148_));
  AND3x1_ASAP7_75t_R   g130(.A(new_n32_), .B(new_n82_), .C(p1), .Y(new_n149_));
  OAI21x1_ASAP7_75t_R  g131(.A1(new_n148_), .A2(new_n149_), .B(new_n38_), .Y(new_n150_));
  AO21x1_ASAP7_75t_R   g132(.A1(p3), .A2(new_n147_), .B(new_n150_), .Y(o5));
  OR4x2_ASAP7_75t_R    g133(.A(new_n149_), .B(p6), .C(p7), .D(new_n39_), .Y(o6));
endmodule


