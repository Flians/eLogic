// Benchmark "/tmp/" written by ABC on Tue Oct 20 17:46:15 2026

module \/tmp/  ( 
    p0, p6, p10, p1, p5, p2, p3, p7, p9, p8, p4,
    o0, o1, o2, o3, o4, o5, o6  );
  input  p0, p6, p10, p1, p5, p2, p3, p7, p9, p8, p4;
  output o0, o1, o2, o3, o4, o5, o6;
  wire new_n19_, new_n20_, new_n21_, new_n22_, new_n23_, new_n24_, new_n25_,
    new_n26_, new_n27_, new_n28_, new_n29_, new_n30_, new_n31_, new_n32_,
    new_n33_, new_n34_, new_n35_, new_n36_, new_n37_, new_n38_, new_n39_,
    new_n40_, new_n41_, new_n42_, new_n43_, new_n44_, new_n45_, new_n46_,
    new_n47_, new_n48_, new_n49_, new_n50_, new_n51_, new_n52_, new_n53_,
    new_n54_, new_n55_, new_n56_, new_n57_, new_n58_, new_n59_, new_n60_,
    new_n61_, new_n63_, new_n64_, new_n65_, new_n66_, new_n67_, new_n68_,
    new_n69_, new_n70_, new_n71_, new_n72_, new_n73_, new_n74_, new_n75_,
    new_n76_, new_n77_, new_n78_, new_n79_, new_n80_, new_n81_, new_n82_,
    new_n83_, new_n84_, new_n85_, new_n86_, new_n87_, new_n88_, new_n89_,
    new_n90_, new_n91_, new_n92_, new_n93_, new_n94_, new_n95_, new_n96_,
    new_n97_, new_n99_, new_n100_, new_n101_, new_n102_, new_n103_,
    new_n104_, new_n105_, new_n106_, new_n107_, new_n108_, new_n109_,
    new_n110_, new_n111_, new_n112_, new_n113_, new_n114_, new_n115_,
    new_n116_, new_n117_, new_n118_, new_n119_, new_n120_, new_n121_,
    new_n122_, new_n123_, new_n124_, new_n125_, new_n126_, new_n127_,
    new_n128_, new_n129_, new_n130_, new_n131_, new_n132_, new_n133_,
    new_n135_, new_n136_, new_n137_, new_n138_, new_n140_, new_n141_,
    new_n142_, new_n143_, new_n144_, new_n145_, new_n146_, new_n147_,
    new_n148_, new_n149_, new_n150_, new_n152_, new_n153_, new_n154_,
    new_n155_, new_n156_, new_n157_;
  NOR2x1_ASAP7_75t_R   g000(.A(p9), .B(p8), .Y(new_n19_));
  INVx1_ASAP7_75t_R    g001(.A(new_n19_), .Y(new_n20_));
  INVx1_ASAP7_75t_R    g002(.A(p10), .Y(new_n21_));
  NAND2x1_ASAP7_75t_R  g003(.A(p0), .B(p3), .Y(new_n22_));
  AOI211x1_ASAP7_75t_R g004(.A1(new_n21_), .A2(new_n22_), .B(p6), .C(p5), .Y(new_n23_));
  INVx1_ASAP7_75t_R    g005(.A(p3), .Y(new_n24_));
  NAND2x1_ASAP7_75t_R  g006(.A(p7), .B(new_n24_), .Y(new_n25_));
  AO21x1_ASAP7_75t_R   g007(.A1(new_n22_), .A2(new_n25_), .B(new_n21_), .Y(new_n26_));
  AO21x1_ASAP7_75t_R   g008(.A1(p3), .A2(p7), .B(p4), .Y(new_n27_));
  AO21x1_ASAP7_75t_R   g009(.A1(new_n23_), .A2(new_n26_), .B(new_n27_), .Y(new_n28_));
  INVx1_ASAP7_75t_R    g010(.A(p4), .Y(new_n29_));
  AO21x1_ASAP7_75t_R   g011(.A1(p7), .A2(new_n24_), .B(new_n29_), .Y(new_n30_));
  INVx1_ASAP7_75t_R    g012(.A(p7), .Y(new_n31_));
  INVx1_ASAP7_75t_R    g013(.A(p0), .Y(new_n32_));
  INVx1_ASAP7_75t_R    g014(.A(p2), .Y(new_n33_));
  OR5x1_ASAP7_75t_R    g015(.A(new_n32_), .B(new_n33_), .C(new_n29_), .D(p6), .E(p1), .Y(new_n34_));
  NAND2x1_ASAP7_75t_R  g016(.A(p2), .B(p3), .Y(new_n35_));
  NAND2x1_ASAP7_75t_R  g017(.A(p6), .B(new_n35_), .Y(new_n36_));
  AO21x1_ASAP7_75t_R   g018(.A1(new_n33_), .A2(new_n24_), .B(new_n36_), .Y(new_n37_));
  NAND2x1_ASAP7_75t_R  g019(.A(new_n34_), .B(new_n37_), .Y(new_n38_));
  AOI22x1_ASAP7_75t_R  g020(.A1(new_n28_), .A2(new_n30_), .B1(new_n31_), .B2(new_n38_), .Y(new_n39_));
  INVx1_ASAP7_75t_R    g021(.A(p9), .Y(new_n40_));
  AOI211x1_ASAP7_75t_R g022(.A1(p6), .A2(new_n24_), .B(new_n32_), .C(p1), .Y(new_n41_));
  AO21x1_ASAP7_75t_R   g023(.A1(new_n33_), .A2(new_n31_), .B(new_n24_), .Y(new_n42_));
  NOR2x1_ASAP7_75t_R   g024(.A(p5), .B(new_n29_), .Y(new_n43_));
  NAND3x1_ASAP7_75t_R  g025(.A(new_n41_), .B(new_n42_), .C(new_n43_), .Y(new_n44_));
  NOR2x1_ASAP7_75t_R   g026(.A(p6), .B(p7), .Y(new_n45_));
  AO31x2_ASAP7_75t_R   g027(.A1(new_n45_), .A2(new_n32_), .A3(p1), .B(p8), .Y(new_n46_));
  AND3x1_ASAP7_75t_R   g028(.A(new_n29_), .B(p5), .C(p8), .Y(new_n47_));
  AOI21x1_ASAP7_75t_R  g029(.A1(new_n43_), .A2(new_n46_), .B(new_n47_), .Y(new_n48_));
  NAND2x1_ASAP7_75t_R  g030(.A(new_n44_), .B(new_n48_), .Y(new_n49_));
  INVx1_ASAP7_75t_R    g031(.A(p5), .Y(new_n50_));
  NOR2x1_ASAP7_75t_R   g032(.A(p6), .B(new_n50_), .Y(new_n51_));
  INVx1_ASAP7_75t_R    g033(.A(p8), .Y(new_n52_));
  NAND2x1_ASAP7_75t_R  g034(.A(new_n31_), .B(new_n52_), .Y(new_n53_));
  XNOR2x2_ASAP7_75t_R  g035(.A(p1), .B(p2), .Y(new_n54_));
  OAI21x1_ASAP7_75t_R  g036(.A1(new_n53_), .A2(new_n54_), .B(new_n40_), .Y(new_n55_));
  AND3x1_ASAP7_75t_R   g037(.A(p5), .B(p7), .C(p8), .Y(new_n56_));
  INVx1_ASAP7_75t_R    g038(.A(p6), .Y(new_n57_));
  NOR2x1_ASAP7_75t_R   g039(.A(p5), .B(new_n57_), .Y(new_n58_));
  OA21x2_ASAP7_75t_R   g040(.A1(new_n56_), .A2(new_n58_), .B(p9), .Y(new_n59_));
  AO21x1_ASAP7_75t_R   g041(.A1(new_n51_), .A2(new_n55_), .B(new_n59_), .Y(new_n60_));
  AOI21x1_ASAP7_75t_R  g042(.A1(new_n40_), .A2(new_n49_), .B(new_n60_), .Y(new_n61_));
  OAI21x1_ASAP7_75t_R  g043(.A1(new_n20_), .A2(new_n39_), .B(new_n61_), .Y(o0));
  NAND2x1_ASAP7_75t_R  g044(.A(p8), .B(new_n57_), .Y(new_n63_));
  OAI21x1_ASAP7_75t_R  g045(.A1(new_n53_), .A2(new_n36_), .B(new_n63_), .Y(new_n64_));
  OAI21x1_ASAP7_75t_R  g046(.A1(p6), .A2(p5), .B(new_n24_), .Y(new_n65_));
  OAI21x1_ASAP7_75t_R  g047(.A1(p7), .A2(p8), .B(p3), .Y(new_n66_));
  AO21x1_ASAP7_75t_R   g048(.A1(p0), .A2(p1), .B(p6), .Y(new_n67_));
  AND5x1_ASAP7_75t_R   g049(.A(p2), .B(new_n65_), .C(p4), .D(new_n66_), .E(new_n67_), .Y(new_n68_));
  AOI21x1_ASAP7_75t_R  g050(.A1(new_n29_), .A2(new_n64_), .B(new_n68_), .Y(new_n69_));
  NOR2x1_ASAP7_75t_R   g051(.A(p3), .B(p8), .Y(new_n70_));
  INVx1_ASAP7_75t_R    g052(.A(new_n70_), .Y(new_n71_));
  AO21x1_ASAP7_75t_R   g053(.A1(new_n63_), .A2(new_n71_), .B(new_n50_), .Y(new_n72_));
  AO221x2_ASAP7_75t_R  g054(.A1(p5), .A2(p4), .B1(new_n57_), .B2(p8), .C(new_n70_), .Y(new_n73_));
  NAND3x1_ASAP7_75t_R  g055(.A(new_n72_), .B(new_n53_), .C(new_n73_), .Y(new_n74_));
  OAI22x1_ASAP7_75t_R  g056(.A1(p6), .A2(p1), .B1(p3), .B2(p8), .Y(new_n75_));
  AO22x1_ASAP7_75t_R   g057(.A1(p7), .A2(new_n52_), .B1(new_n32_), .B2(new_n75_), .Y(new_n76_));
  NAND2x1_ASAP7_75t_R  g058(.A(p0), .B(p1), .Y(new_n77_));
  NAND2x1_ASAP7_75t_R  g059(.A(p3), .B(new_n57_), .Y(new_n78_));
  INVx1_ASAP7_75t_R    g060(.A(p1), .Y(new_n79_));
  NOR2x1_ASAP7_75t_R   g061(.A(p10), .B(new_n79_), .Y(new_n80_));
  AOI211x1_ASAP7_75t_R g062(.A1(p10), .A2(new_n77_), .B(new_n78_), .C(new_n80_), .Y(new_n81_));
  NOR2x1_ASAP7_75t_R   g063(.A(p5), .B(p4), .Y(new_n82_));
  OAI21x1_ASAP7_75t_R  g064(.A1(new_n76_), .A2(new_n81_), .B(new_n82_), .Y(new_n83_));
  NAND3x1_ASAP7_75t_R  g065(.A(new_n69_), .B(new_n74_), .C(new_n83_), .Y(new_n84_));
  NAND2x1_ASAP7_75t_R  g066(.A(p7), .B(p9), .Y(new_n85_));
  NAND2x1_ASAP7_75t_R  g067(.A(p6), .B(p5), .Y(new_n86_));
  OR3x1_ASAP7_75t_R    g068(.A(new_n85_), .B(new_n86_), .C(p8), .Y(new_n87_));
  NOR2x1_ASAP7_75t_R   g069(.A(p5), .B(p2), .Y(new_n88_));
  AOI22x1_ASAP7_75t_R  g070(.A1(p5), .A2(new_n70_), .B1(new_n88_), .B2(p4), .Y(new_n89_));
  OAI21x1_ASAP7_75t_R  g071(.A1(p1), .A2(new_n89_), .B(new_n40_), .Y(new_n90_));
  OR3x1_ASAP7_75t_R    g072(.A(new_n35_), .B(new_n79_), .C(new_n50_), .Y(new_n91_));
  NOR2x1_ASAP7_75t_R   g073(.A(p0), .B(p5), .Y(new_n92_));
  AOI22x1_ASAP7_75t_R  g074(.A1(p5), .A2(new_n70_), .B1(new_n92_), .B2(p4), .Y(new_n93_));
  OAI22x1_ASAP7_75t_R  g075(.A1(new_n91_), .A2(p8), .B1(new_n93_), .B2(p2), .Y(new_n94_));
  OA211x2_ASAP7_75t_R  g076(.A1(new_n57_), .A2(p9), .B(new_n86_), .C(new_n31_), .Y(new_n95_));
  OAI21x1_ASAP7_75t_R  g077(.A1(new_n90_), .A2(new_n94_), .B(new_n95_), .Y(new_n96_));
  NAND2x1_ASAP7_75t_R  g078(.A(new_n87_), .B(new_n96_), .Y(new_n97_));
  AOI21x1_ASAP7_75t_R  g079(.A1(new_n40_), .A2(new_n84_), .B(new_n97_), .Y(o1));
  AND2x2_ASAP7_75t_R   g080(.A(p3), .B(p4), .Y(new_n99_));
  AO21x1_ASAP7_75t_R   g081(.A1(new_n99_), .A2(new_n51_), .B(new_n58_), .Y(new_n100_));
  AND3x1_ASAP7_75t_R   g082(.A(new_n100_), .B(p7), .C(new_n40_), .Y(new_n101_));
  AND3x1_ASAP7_75t_R   g083(.A(new_n40_), .B(p6), .C(p4), .Y(new_n102_));
  AO21x1_ASAP7_75t_R   g084(.A1(new_n31_), .A2(new_n40_), .B(new_n52_), .Y(new_n103_));
  OR3x1_ASAP7_75t_R    g085(.A(new_n52_), .B(new_n29_), .C(p7), .Y(new_n104_));
  AO21x1_ASAP7_75t_R   g086(.A1(new_n85_), .A2(new_n104_), .B(new_n86_), .Y(new_n105_));
  OAI21x1_ASAP7_75t_R  g087(.A1(new_n102_), .A2(new_n103_), .B(new_n105_), .Y(new_n106_));
  NOR2x1_ASAP7_75t_R   g088(.A(new_n101_), .B(new_n106_), .Y(new_n107_));
  AND3x1_ASAP7_75t_R   g089(.A(new_n24_), .B(p2), .C(p4), .Y(new_n108_));
  AND4x2_ASAP7_75t_R   g090(.A(new_n50_), .B(new_n33_), .C(p10), .D(p3), .Y(new_n109_));
  OAI21x1_ASAP7_75t_R  g091(.A1(new_n108_), .A2(new_n109_), .B(p0), .Y(new_n110_));
  NOR2x1_ASAP7_75t_R   g092(.A(p5), .B(p3), .Y(new_n111_));
  NAND2x1_ASAP7_75t_R  g093(.A(p0), .B(p10), .Y(new_n112_));
  AND3x1_ASAP7_75t_R   g094(.A(new_n112_), .B(p2), .C(p3), .Y(new_n113_));
  OAI21x1_ASAP7_75t_R  g095(.A1(new_n111_), .A2(new_n113_), .B(new_n29_), .Y(new_n114_));
  NAND2x1_ASAP7_75t_R  g096(.A(p1), .B(new_n45_), .Y(new_n115_));
  AOI21x1_ASAP7_75t_R  g097(.A1(new_n110_), .A2(new_n114_), .B(new_n115_), .Y(new_n116_));
  AND3x1_ASAP7_75t_R   g098(.A(p2), .B(p3), .C(p4), .Y(new_n117_));
  NOR3x1_ASAP7_75t_R   g099(.A(new_n50_), .B(p6), .C(p1), .Y(new_n118_));
  AOI21x1_ASAP7_75t_R  g100(.A1(p3), .A2(p4), .B(new_n86_), .Y(new_n119_));
  AOI221x1_ASAP7_75t_R g101(.A1(new_n58_), .A2(new_n117_), .B1(new_n118_), .B2(new_n99_), .C(new_n119_), .Y(new_n120_));
  AND3x1_ASAP7_75t_R   g102(.A(new_n32_), .B(new_n50_), .C(p4), .Y(new_n121_));
  NAND2x1_ASAP7_75t_R  g103(.A(p1), .B(p5), .Y(new_n122_));
  AND2x2_ASAP7_75t_R   g104(.A(p2), .B(p3), .Y(new_n123_));
  OAI21x1_ASAP7_75t_R  g105(.A1(p4), .A2(new_n122_), .B(new_n123_), .Y(new_n124_));
  NAND2x1_ASAP7_75t_R  g106(.A(p5), .B(p4), .Y(new_n125_));
  AOI21x1_ASAP7_75t_R  g107(.A1(new_n35_), .A2(new_n125_), .B(p7), .Y(new_n126_));
  OAI21x1_ASAP7_75t_R  g108(.A1(new_n121_), .A2(new_n124_), .B(new_n126_), .Y(new_n127_));
  NOR2x1_ASAP7_75t_R   g109(.A(p2), .B(new_n29_), .Y(new_n128_));
  AND3x1_ASAP7_75t_R   g110(.A(new_n79_), .B(new_n50_), .C(p2), .Y(new_n129_));
  AND3x1_ASAP7_75t_R   g111(.A(new_n57_), .B(new_n31_), .C(p3), .Y(new_n130_));
  OAI21x1_ASAP7_75t_R  g112(.A1(new_n128_), .A2(new_n129_), .B(new_n130_), .Y(new_n131_));
  NAND3x1_ASAP7_75t_R  g113(.A(new_n120_), .B(new_n127_), .C(new_n131_), .Y(new_n132_));
  OAI21x1_ASAP7_75t_R  g114(.A1(new_n116_), .A2(new_n132_), .B(new_n19_), .Y(new_n133_));
  NAND2x1_ASAP7_75t_R  g115(.A(new_n107_), .B(new_n133_), .Y(o2));
  OR5x1_ASAP7_75t_R    g116(.A(p6), .B(p5), .C(p3), .D(p7), .E(p4), .Y(new_n135_));
  OR3x1_ASAP7_75t_R    g117(.A(new_n125_), .B(new_n57_), .C(new_n31_), .Y(new_n136_));
  OR3x1_ASAP7_75t_R    g118(.A(new_n136_), .B(p1), .C(new_n24_), .Y(new_n137_));
  OR3x1_ASAP7_75t_R    g119(.A(p2), .B(p9), .C(p8), .Y(new_n138_));
  AO21x1_ASAP7_75t_R   g120(.A1(new_n135_), .A2(new_n137_), .B(new_n138_), .Y(o3));
  OR3x1_ASAP7_75t_R    g121(.A(new_n112_), .B(p5), .C(p4), .Y(new_n140_));
  OA21x2_ASAP7_75t_R   g122(.A1(new_n125_), .A2(new_n78_), .B(new_n140_), .Y(new_n141_));
  NAND2x1_ASAP7_75t_R  g123(.A(p2), .B(new_n31_), .Y(new_n142_));
  OR3x1_ASAP7_75t_R    g124(.A(new_n141_), .B(new_n79_), .C(new_n142_), .Y(new_n143_));
  OR3x1_ASAP7_75t_R    g125(.A(new_n32_), .B(new_n79_), .C(p6), .Y(new_n144_));
  AOI21x1_ASAP7_75t_R  g126(.A1(new_n125_), .A2(new_n144_), .B(new_n35_), .Y(new_n145_));
  AND3x1_ASAP7_75t_R   g127(.A(new_n57_), .B(new_n29_), .C(p3), .Y(new_n146_));
  OR4x2_ASAP7_75t_R    g128(.A(new_n145_), .B(p7), .C(new_n51_), .D(new_n146_), .Y(new_n147_));
  OA211x2_ASAP7_75t_R  g129(.A1(p1), .A2(p2), .B(new_n142_), .C(new_n99_), .Y(new_n148_));
  NOR2x1_ASAP7_75t_R   g130(.A(p8), .B(new_n86_), .Y(new_n149_));
  AOI22x1_ASAP7_75t_R  g131(.A1(new_n148_), .A2(new_n149_), .B1(p8), .B2(new_n136_), .Y(new_n150_));
  AO31x2_ASAP7_75t_R   g132(.A1(new_n143_), .A2(new_n147_), .A3(new_n150_), .B(p9), .Y(o4));
  OR5x1_ASAP7_75t_R    g133(.A(p6), .B(new_n142_), .C(new_n79_), .D(p4), .E(new_n112_), .Y(new_n152_));
  AO21x1_ASAP7_75t_R   g134(.A1(new_n79_), .A2(new_n33_), .B(new_n136_), .Y(new_n153_));
  AO21x1_ASAP7_75t_R   g135(.A1(new_n152_), .A2(new_n153_), .B(new_n24_), .Y(new_n154_));
  NOR2x1_ASAP7_75t_R   g136(.A(new_n29_), .B(new_n91_), .Y(new_n155_));
  INVx1_ASAP7_75t_R    g137(.A(new_n45_), .Y(new_n156_));
  OR3x1_ASAP7_75t_R    g138(.A(new_n155_), .B(new_n82_), .C(new_n156_), .Y(new_n157_));
  NAND3x1_ASAP7_75t_R  g139(.A(new_n154_), .B(new_n19_), .C(new_n157_), .Y(o5));
  OR3x1_ASAP7_75t_R    g140(.A(new_n155_), .B(new_n20_), .C(new_n156_), .Y(o6));
endmodule


