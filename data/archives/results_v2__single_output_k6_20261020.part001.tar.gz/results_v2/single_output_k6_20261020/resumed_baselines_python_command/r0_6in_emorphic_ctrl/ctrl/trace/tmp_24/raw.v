// Benchmark "/tmp/" written by ABC on Tue Oct 20 17:33:02 2026

module \/tmp/  ( 
    p2, p4, p5, p6, p0, p3, p1,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25  );
  input  p2, p4, p5, p6, p0, p3, p1;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25;
  wire new_n34_, new_n35_, new_n36_, new_n38_, new_n39_, new_n40_, new_n41_,
    new_n42_, new_n43_, new_n44_, new_n45_, new_n47_, new_n48_, new_n49_,
    new_n50_, new_n51_, new_n52_, new_n54_, new_n56_, new_n57_, new_n58_,
    new_n59_, new_n60_, new_n61_, new_n62_, new_n63_, new_n64_, new_n66_,
    new_n67_, new_n69_, new_n70_, new_n71_, new_n74_, new_n75_, new_n77_,
    new_n80_, new_n81_, new_n84_, new_n85_, new_n86_, new_n87_, new_n92_,
    new_n96_, new_n97_, new_n98_, new_n100_, new_n101_, new_n102_,
    new_n106_;
  NOR2x1_ASAP7_75t_R   g00(.A(p2), .B(p3), .Y(new_n34_));
  OR3x1_ASAP7_75t_R    g01(.A(p6), .B(p0), .C(p1), .Y(new_n35_));
  AND2x2_ASAP7_75t_R   g02(.A(p2), .B(p3), .Y(new_n36_));
  AO32x1_ASAP7_75t_R   g03(.A1(p0), .A2(p1), .A3(new_n34_), .B1(new_n35_), .B2(new_n36_), .Y(o0));
  NOR2x1_ASAP7_75t_R   g04(.A(p0), .B(p1), .Y(new_n38_));
  INVx1_ASAP7_75t_R    g05(.A(p3), .Y(new_n39_));
  NOR2x1_ASAP7_75t_R   g06(.A(p2), .B(new_n39_), .Y(new_n40_));
  INVx1_ASAP7_75t_R    g07(.A(new_n40_), .Y(new_n41_));
  INVx1_ASAP7_75t_R    g08(.A(p0), .Y(new_n42_));
  NOR2x1_ASAP7_75t_R   g09(.A(p1), .B(new_n42_), .Y(new_n43_));
  INVx1_ASAP7_75t_R    g10(.A(p1), .Y(new_n44_));
  OAI22x1_ASAP7_75t_R  g11(.A1(new_n36_), .A2(p0), .B1(new_n44_), .B2(new_n34_), .Y(new_n45_));
  AOI221x1_ASAP7_75t_R g12(.A1(p6), .A2(new_n38_), .B1(new_n41_), .B2(new_n43_), .C(new_n45_), .Y(o1));
  INVx1_ASAP7_75t_R    g13(.A(new_n43_), .Y(new_n47_));
  NAND2x1_ASAP7_75t_R  g14(.A(p2), .B(p3), .Y(new_n48_));
  OR3x1_ASAP7_75t_R    g15(.A(new_n48_), .B(p6), .C(p1), .Y(new_n49_));
  OR3x1_ASAP7_75t_R    g16(.A(new_n39_), .B(p2), .C(p6), .Y(new_n50_));
  INVx1_ASAP7_75t_R    g17(.A(p2), .Y(new_n51_));
  OA21x2_ASAP7_75t_R   g18(.A1(p3), .A2(new_n51_), .B(p0), .Y(new_n52_));
  AOI22x1_ASAP7_75t_R  g19(.A1(new_n47_), .A2(new_n49_), .B1(new_n50_), .B2(new_n52_), .Y(o2));
  NAND2x1_ASAP7_75t_R  g20(.A(p2), .B(new_n38_), .Y(new_n54_));
  AOI22x1_ASAP7_75t_R  g21(.A1(new_n41_), .A2(new_n54_), .B1(p6), .B2(new_n36_), .Y(o3));
  AND3x1_ASAP7_75t_R   g22(.A(p2), .B(p6), .C(p0), .Y(new_n56_));
  INVx1_ASAP7_75t_R    g23(.A(p4), .Y(new_n57_));
  INVx1_ASAP7_75t_R    g24(.A(p5), .Y(new_n58_));
  OAI21x1_ASAP7_75t_R  g25(.A1(new_n57_), .A2(new_n58_), .B(p3), .Y(new_n59_));
  NAND2x1_ASAP7_75t_R  g26(.A(new_n56_), .B(new_n59_), .Y(new_n60_));
  AND3x1_ASAP7_75t_R   g27(.A(p2), .B(p4), .C(p3), .Y(new_n61_));
  NOR2x1_ASAP7_75t_R   g28(.A(p6), .B(new_n42_), .Y(new_n62_));
  AOI21x1_ASAP7_75t_R  g29(.A1(new_n61_), .A2(new_n62_), .B(p1), .Y(new_n63_));
  AOI21x1_ASAP7_75t_R  g30(.A1(p6), .A2(new_n40_), .B(new_n44_), .Y(new_n64_));
  AOI21x1_ASAP7_75t_R  g31(.A1(new_n60_), .A2(new_n63_), .B(new_n64_), .Y(o4));
  AO21x1_ASAP7_75t_R   g32(.A1(p3), .A2(new_n58_), .B(new_n51_), .Y(new_n66_));
  NOR2x1_ASAP7_75t_R   g33(.A(new_n44_), .B(new_n40_), .Y(new_n67_));
  AOI211x1_ASAP7_75t_R g34(.A1(new_n44_), .A2(new_n66_), .B(new_n42_), .C(new_n67_), .Y(o5));
  AND2x2_ASAP7_75t_R   g35(.A(p6), .B(p0), .Y(new_n69_));
  NOR2x1_ASAP7_75t_R   g36(.A(p1), .B(new_n69_), .Y(new_n70_));
  OR3x1_ASAP7_75t_R    g37(.A(new_n36_), .B(p1), .C(new_n34_), .Y(new_n71_));
  OAI21x1_ASAP7_75t_R  g38(.A1(new_n48_), .A2(new_n70_), .B(new_n71_), .Y(o6));
  AND3x1_ASAP7_75t_R   g39(.A(new_n51_), .B(new_n39_), .C(p1), .Y(o19));
  INVx1_ASAP7_75t_R    g40(.A(p6), .Y(new_n74_));
  OAI21x1_ASAP7_75t_R  g41(.A1(new_n74_), .A2(new_n44_), .B(new_n35_), .Y(new_n75_));
  AO22x1_ASAP7_75t_R   g42(.A1(p0), .A2(o19), .B1(new_n36_), .B2(new_n75_), .Y(o7));
  NOR2x1_ASAP7_75t_R   g43(.A(new_n44_), .B(new_n34_), .Y(new_n77_));
  AOI221x1_ASAP7_75t_R g44(.A1(new_n48_), .A2(new_n77_), .B1(new_n50_), .B2(new_n43_), .C(new_n42_), .Y(o8));
  AOI21x1_ASAP7_75t_R  g45(.A1(new_n43_), .A2(new_n50_), .B(new_n45_), .Y(o9));
  NOR2x1_ASAP7_75t_R   g46(.A(p2), .B(p1), .Y(new_n80_));
  AO21x1_ASAP7_75t_R   g47(.A1(p3), .A2(new_n38_), .B(new_n80_), .Y(new_n81_));
  OAI22x1_ASAP7_75t_R  g48(.A1(new_n67_), .A2(new_n81_), .B1(new_n41_), .B2(new_n62_), .Y(o10));
  AND3x1_ASAP7_75t_R   g49(.A(new_n34_), .B(new_n38_), .C(new_n74_), .Y(o11));
  AND3x1_ASAP7_75t_R   g50(.A(new_n51_), .B(new_n74_), .C(new_n42_), .Y(new_n84_));
  AO21x1_ASAP7_75t_R   g51(.A1(new_n51_), .A2(new_n39_), .B(p1), .Y(new_n85_));
  AO21x1_ASAP7_75t_R   g52(.A1(p2), .A2(new_n39_), .B(new_n44_), .Y(new_n86_));
  NOR2x1_ASAP7_75t_R   g53(.A(p0), .B(p3), .Y(new_n87_));
  OAI22x1_ASAP7_75t_R  g54(.A1(new_n84_), .A2(new_n85_), .B1(new_n86_), .B2(new_n87_), .Y(o12));
  AND3x1_ASAP7_75t_R   g55(.A(new_n34_), .B(p6), .C(p1), .Y(o13));
  AND3x1_ASAP7_75t_R   g56(.A(new_n34_), .B(new_n74_), .C(p1), .Y(o14));
  AND5x1_ASAP7_75t_R   g57(.A(p2), .B(new_n74_), .C(new_n42_), .D(new_n39_), .E(p1), .Y(o15));
  AND2x2_ASAP7_75t_R   g58(.A(p2), .B(p6), .Y(new_n92_));
  AND3x1_ASAP7_75t_R   g59(.A(new_n92_), .B(p1), .C(new_n87_), .Y(o16));
  AND5x1_ASAP7_75t_R   g60(.A(p2), .B(new_n39_), .C(p6), .D(p0), .E(p1), .Y(o17));
  AND5x1_ASAP7_75t_R   g61(.A(p2), .B(new_n74_), .C(new_n39_), .D(p0), .E(p1), .Y(o18));
  OAI21x1_ASAP7_75t_R  g62(.A1(p4), .A2(new_n39_), .B(new_n56_), .Y(new_n96_));
  AOI21x1_ASAP7_75t_R  g63(.A1(new_n87_), .A2(new_n92_), .B(p1), .Y(new_n97_));
  OA21x2_ASAP7_75t_R   g64(.A1(new_n48_), .A2(new_n69_), .B(p1), .Y(new_n98_));
  AOI21x1_ASAP7_75t_R  g65(.A1(new_n96_), .A2(new_n97_), .B(new_n98_), .Y(o20));
  NAND2x1_ASAP7_75t_R  g66(.A(p2), .B(new_n87_), .Y(new_n100_));
  OR4x2_ASAP7_75t_R    g67(.A(new_n48_), .B(new_n57_), .C(p5), .D(new_n42_), .Y(new_n101_));
  NAND2x1_ASAP7_75t_R  g68(.A(p6), .B(new_n44_), .Y(new_n102_));
  AOI21x1_ASAP7_75t_R  g69(.A1(new_n100_), .A2(new_n101_), .B(new_n102_), .Y(o21));
  AOI21x1_ASAP7_75t_R  g70(.A1(new_n44_), .A2(new_n60_), .B(new_n98_), .Y(o22));
  assign               o23 = 1'b1;
  NOR2x1_ASAP7_75t_R   g71(.A(p6), .B(p0), .Y(new_n106_));
  OA211x2_ASAP7_75t_R  g72(.A1(new_n106_), .A2(new_n69_), .B(p3), .C(new_n80_), .Y(o24));
  AND3x1_ASAP7_75t_R   g73(.A(new_n40_), .B(p6), .C(new_n38_), .Y(o25));
endmodule


