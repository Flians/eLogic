// Benchmark "/tmp/" written by ABC on Tue Oct 20 17:33:00 2026

module \/tmp/  ( 
    p3, p1, p6, p2, p4, p5, p0,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25  );
  input  p3, p1, p6, p2, p4, p5, p0;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25;
  wire new_n34_, new_n35_, new_n36_, new_n38_, new_n39_, new_n40_, new_n41_,
    new_n42_, new_n43_, new_n44_, new_n45_, new_n47_, new_n48_, new_n49_,
    new_n50_, new_n51_, new_n53_, new_n55_, new_n56_, new_n57_, new_n58_,
    new_n59_, new_n60_, new_n61_, new_n62_, new_n64_, new_n65_, new_n67_,
    new_n68_, new_n69_, new_n71_, new_n72_, new_n73_, new_n74_, new_n78_,
    new_n79_, new_n81_, new_n82_, new_n84_, new_n85_, new_n86_, new_n87_,
    new_n92_, new_n94_, new_n98_, new_n99_, new_n100_, new_n102_,
    new_n103_, new_n104_, new_n105_, new_n107_, new_n108_;
  NOR2x1_ASAP7_75t_R   g00(.A(p3), .B(p2), .Y(new_n34_));
  OR3x1_ASAP7_75t_R    g01(.A(p1), .B(p6), .C(p0), .Y(new_n35_));
  AND2x2_ASAP7_75t_R   g02(.A(p3), .B(p2), .Y(new_n36_));
  AO32x1_ASAP7_75t_R   g03(.A1(p1), .A2(p0), .A3(new_n34_), .B1(new_n35_), .B2(new_n36_), .Y(o0));
  INVx1_ASAP7_75t_R    g04(.A(p0), .Y(new_n38_));
  NOR2x1_ASAP7_75t_R   g05(.A(p1), .B(new_n38_), .Y(new_n39_));
  INVx1_ASAP7_75t_R    g06(.A(p2), .Y(new_n40_));
  NAND2x1_ASAP7_75t_R  g07(.A(p3), .B(new_n40_), .Y(new_n41_));
  NAND2x1_ASAP7_75t_R  g08(.A(p3), .B(p2), .Y(new_n42_));
  OR3x1_ASAP7_75t_R    g09(.A(new_n42_), .B(p1), .C(p6), .Y(new_n43_));
  INVx1_ASAP7_75t_R    g10(.A(p1), .Y(new_n44_));
  NOR2x1_ASAP7_75t_R   g11(.A(new_n44_), .B(new_n34_), .Y(new_n45_));
  AOI221x1_ASAP7_75t_R g12(.A1(new_n39_), .A2(new_n41_), .B1(new_n43_), .B2(new_n38_), .C(new_n45_), .Y(o1));
  NOR2x1_ASAP7_75t_R   g13(.A(p3), .B(new_n40_), .Y(new_n47_));
  NOR2x1_ASAP7_75t_R   g14(.A(new_n38_), .B(new_n47_), .Y(new_n48_));
  INVx1_ASAP7_75t_R    g15(.A(p3), .Y(new_n49_));
  OR3x1_ASAP7_75t_R    g16(.A(new_n49_), .B(p6), .C(p2), .Y(new_n50_));
  NAND2x1_ASAP7_75t_R  g17(.A(p0), .B(new_n44_), .Y(new_n51_));
  AOI22x1_ASAP7_75t_R  g18(.A1(new_n48_), .A2(new_n50_), .B1(new_n43_), .B2(new_n51_), .Y(o2));
  OR3x1_ASAP7_75t_R    g19(.A(new_n40_), .B(p1), .C(p0), .Y(new_n53_));
  AOI22x1_ASAP7_75t_R  g20(.A1(new_n53_), .A2(new_n41_), .B1(p6), .B2(new_n36_), .Y(o3));
  AND2x2_ASAP7_75t_R   g21(.A(p4), .B(p5), .Y(new_n55_));
  AND3x1_ASAP7_75t_R   g22(.A(p6), .B(p2), .C(p0), .Y(new_n56_));
  OAI21x1_ASAP7_75t_R  g23(.A1(new_n49_), .A2(new_n55_), .B(new_n56_), .Y(new_n57_));
  AND3x1_ASAP7_75t_R   g24(.A(p2), .B(p4), .C(p0), .Y(new_n58_));
  NOR2x1_ASAP7_75t_R   g25(.A(p6), .B(new_n49_), .Y(new_n59_));
  AOI21x1_ASAP7_75t_R  g26(.A1(new_n58_), .A2(new_n59_), .B(p1), .Y(new_n60_));
  NAND2x1_ASAP7_75t_R  g27(.A(p3), .B(p6), .Y(new_n61_));
  OA21x2_ASAP7_75t_R   g28(.A1(p2), .A2(new_n61_), .B(p1), .Y(new_n62_));
  AOI21x1_ASAP7_75t_R  g29(.A1(new_n57_), .A2(new_n60_), .B(new_n62_), .Y(o4));
  NAND2x1_ASAP7_75t_R  g30(.A(p2), .B(new_n49_), .Y(new_n64_));
  AOI21x1_ASAP7_75t_R  g31(.A1(p2), .A2(p5), .B(p1), .Y(new_n65_));
  AOI221x1_ASAP7_75t_R g32(.A1(new_n41_), .A2(p1), .B1(new_n64_), .B2(new_n65_), .C(new_n38_), .Y(o5));
  NAND2x1_ASAP7_75t_R  g33(.A(p6), .B(p0), .Y(new_n67_));
  AO21x1_ASAP7_75t_R   g34(.A1(new_n44_), .A2(new_n67_), .B(new_n42_), .Y(new_n68_));
  OR3x1_ASAP7_75t_R    g35(.A(new_n36_), .B(p1), .C(new_n34_), .Y(new_n69_));
  NAND2x1_ASAP7_75t_R  g36(.A(new_n68_), .B(new_n69_), .Y(o6));
  OR4x2_ASAP7_75t_R    g37(.A(new_n44_), .B(new_n38_), .C(p3), .D(p2), .Y(new_n71_));
  OR5x1_ASAP7_75t_R    g38(.A(new_n49_), .B(new_n40_), .C(p1), .D(p6), .E(p0), .Y(new_n72_));
  INVx1_ASAP7_75t_R    g39(.A(p6), .Y(new_n73_));
  OR3x1_ASAP7_75t_R    g40(.A(new_n42_), .B(new_n44_), .C(new_n73_), .Y(new_n74_));
  NAND3x1_ASAP7_75t_R  g41(.A(new_n71_), .B(new_n72_), .C(new_n74_), .Y(o7));
  AOI221x1_ASAP7_75t_R g42(.A1(new_n42_), .A2(new_n45_), .B1(new_n50_), .B2(new_n44_), .C(new_n38_), .Y(o8));
  AOI221x1_ASAP7_75t_R g43(.A1(new_n38_), .A2(new_n42_), .B1(new_n50_), .B2(new_n39_), .C(new_n45_), .Y(o9));
  AO21x1_ASAP7_75t_R   g44(.A1(p3), .A2(new_n38_), .B(new_n40_), .Y(new_n78_));
  AO21x1_ASAP7_75t_R   g45(.A1(new_n73_), .A2(new_n39_), .B(new_n41_), .Y(new_n79_));
  OAI21x1_ASAP7_75t_R  g46(.A1(p1), .A2(new_n78_), .B(new_n79_), .Y(o10));
  NOR2x1_ASAP7_75t_R   g47(.A(p1), .B(p2), .Y(new_n81_));
  NOR2x1_ASAP7_75t_R   g48(.A(p6), .B(p0), .Y(new_n82_));
  AND3x1_ASAP7_75t_R   g49(.A(new_n81_), .B(new_n82_), .C(new_n49_), .Y(o11));
  NOR2x1_ASAP7_75t_R   g50(.A(p3), .B(p0), .Y(new_n84_));
  INVx1_ASAP7_75t_R    g51(.A(new_n84_), .Y(new_n85_));
  NOR2x1_ASAP7_75t_R   g52(.A(p1), .B(new_n34_), .Y(new_n86_));
  OR3x1_ASAP7_75t_R    g53(.A(p6), .B(p2), .C(p0), .Y(new_n87_));
  AO32x1_ASAP7_75t_R   g54(.A1(p1), .A2(new_n64_), .A3(new_n85_), .B1(new_n86_), .B2(new_n87_), .Y(o12));
  AND3x1_ASAP7_75t_R   g55(.A(new_n34_), .B(p1), .C(p6), .Y(o13));
  AND3x1_ASAP7_75t_R   g56(.A(new_n34_), .B(p1), .C(new_n73_), .Y(o14));
  AND3x1_ASAP7_75t_R   g57(.A(new_n47_), .B(p1), .C(new_n82_), .Y(o15));
  AND2x2_ASAP7_75t_R   g58(.A(p6), .B(p2), .Y(new_n92_));
  AND3x1_ASAP7_75t_R   g59(.A(new_n92_), .B(p1), .C(new_n84_), .Y(o16));
  AND2x2_ASAP7_75t_R   g60(.A(p6), .B(p0), .Y(new_n94_));
  AND3x1_ASAP7_75t_R   g61(.A(new_n47_), .B(p1), .C(new_n94_), .Y(o17));
  AND5x1_ASAP7_75t_R   g62(.A(new_n49_), .B(new_n73_), .C(p1), .D(p2), .E(p0), .Y(o18));
  AND3x1_ASAP7_75t_R   g63(.A(new_n49_), .B(new_n40_), .C(p1), .Y(o19));
  OAI21x1_ASAP7_75t_R  g64(.A1(new_n49_), .A2(p4), .B(new_n56_), .Y(new_n98_));
  AOI21x1_ASAP7_75t_R  g65(.A1(new_n84_), .A2(new_n92_), .B(p1), .Y(new_n99_));
  AOI21x1_ASAP7_75t_R  g66(.A1(new_n67_), .A2(new_n36_), .B(new_n44_), .Y(new_n100_));
  AOI21x1_ASAP7_75t_R  g67(.A1(new_n98_), .A2(new_n99_), .B(new_n100_), .Y(o20));
  NAND2x1_ASAP7_75t_R  g68(.A(p2), .B(new_n84_), .Y(new_n102_));
  INVx1_ASAP7_75t_R    g69(.A(p4), .Y(new_n103_));
  OR5x1_ASAP7_75t_R    g70(.A(new_n49_), .B(new_n40_), .C(new_n103_), .D(new_n38_), .E(p5), .Y(new_n104_));
  NAND2x1_ASAP7_75t_R  g71(.A(p6), .B(new_n44_), .Y(new_n105_));
  AOI21x1_ASAP7_75t_R  g72(.A1(new_n102_), .A2(new_n104_), .B(new_n105_), .Y(o21));
  NAND2x1_ASAP7_75t_R  g73(.A(p3), .B(p5), .Y(new_n107_));
  OAI21x1_ASAP7_75t_R  g74(.A1(p4), .A2(new_n107_), .B(new_n94_), .Y(new_n108_));
  AOI221x1_ASAP7_75t_R g75(.A1(new_n64_), .A2(new_n65_), .B1(new_n108_), .B2(new_n44_), .C(new_n100_), .Y(o22));
  assign               o23 = 1'b1;
  OA211x2_ASAP7_75t_R  g76(.A1(new_n82_), .A2(new_n94_), .B(p3), .C(new_n81_), .Y(o24));
  AND5x1_ASAP7_75t_R   g77(.A(p3), .B(new_n44_), .C(new_n40_), .D(new_n38_), .E(p6), .Y(o25));
endmodule


