// Benchmark "/tmp/" written by ABC on Tue Oct 20 17:33:00 2026

module \/tmp/  ( 
    p4, p6, p3, p2, p5, p0, p1,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25  );
  input  p4, p6, p3, p2, p5, p0, p1;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25;
  wire new_n34_, new_n35_, new_n36_, new_n37_, new_n39_, new_n40_, new_n41_,
    new_n42_, new_n43_, new_n44_, new_n45_, new_n47_, new_n48_, new_n49_,
    new_n50_, new_n51_, new_n52_, new_n53_, new_n55_, new_n56_, new_n58_,
    new_n59_, new_n60_, new_n61_, new_n62_, new_n63_, new_n64_, new_n65_,
    new_n66_, new_n67_, new_n68_, new_n70_, new_n71_, new_n73_, new_n74_,
    new_n76_, new_n77_, new_n78_, new_n80_, new_n83_, new_n84_, new_n87_,
    new_n88_, new_n92_, new_n94_, new_n96_, new_n100_, new_n101_,
    new_n102_, new_n104_, new_n105_;
  AND2x2_ASAP7_75t_R   g00(.A(p3), .B(p2), .Y(new_n34_));
  NOR2x1_ASAP7_75t_R   g01(.A(p3), .B(p2), .Y(new_n35_));
  AND3x1_ASAP7_75t_R   g02(.A(new_n35_), .B(p0), .C(p1), .Y(new_n36_));
  OR3x1_ASAP7_75t_R    g03(.A(p6), .B(p0), .C(p1), .Y(new_n37_));
  OA21x2_ASAP7_75t_R   g04(.A1(new_n34_), .A2(new_n36_), .B(new_n37_), .Y(o0));
  INVx1_ASAP7_75t_R    g05(.A(p0), .Y(new_n39_));
  NOR2x1_ASAP7_75t_R   g06(.A(p1), .B(new_n39_), .Y(new_n40_));
  INVx1_ASAP7_75t_R    g07(.A(p2), .Y(new_n41_));
  NAND2x1_ASAP7_75t_R  g08(.A(p3), .B(new_n41_), .Y(new_n42_));
  INVx1_ASAP7_75t_R    g09(.A(p1), .Y(new_n43_));
  AND3x1_ASAP7_75t_R   g10(.A(new_n39_), .B(new_n43_), .C(p6), .Y(new_n44_));
  OAI22x1_ASAP7_75t_R  g11(.A1(new_n34_), .A2(p0), .B1(new_n43_), .B2(new_n35_), .Y(new_n45_));
  AOI211x1_ASAP7_75t_R g12(.A1(new_n40_), .A2(new_n42_), .B(new_n44_), .C(new_n45_), .Y(o1));
  NOR2x1_ASAP7_75t_R   g13(.A(p3), .B(new_n41_), .Y(new_n47_));
  NOR2x1_ASAP7_75t_R   g14(.A(new_n39_), .B(new_n47_), .Y(new_n48_));
  INVx1_ASAP7_75t_R    g15(.A(p3), .Y(new_n49_));
  OR3x1_ASAP7_75t_R    g16(.A(new_n49_), .B(p6), .C(p2), .Y(new_n50_));
  INVx1_ASAP7_75t_R    g17(.A(new_n40_), .Y(new_n51_));
  NAND2x1_ASAP7_75t_R  g18(.A(p3), .B(p2), .Y(new_n52_));
  OR3x1_ASAP7_75t_R    g19(.A(new_n52_), .B(p6), .C(p1), .Y(new_n53_));
  AOI22x1_ASAP7_75t_R  g20(.A1(new_n48_), .A2(new_n50_), .B1(new_n51_), .B2(new_n53_), .Y(o2));
  NOR2x1_ASAP7_75t_R   g21(.A(p0), .B(p1), .Y(new_n55_));
  NAND2x1_ASAP7_75t_R  g22(.A(p2), .B(new_n55_), .Y(new_n56_));
  AOI22x1_ASAP7_75t_R  g23(.A1(new_n56_), .A2(new_n42_), .B1(p6), .B2(new_n34_), .Y(o3));
  AND3x1_ASAP7_75t_R   g24(.A(p4), .B(p2), .C(p0), .Y(new_n58_));
  NOR2x1_ASAP7_75t_R   g25(.A(p6), .B(new_n49_), .Y(new_n59_));
  AOI21x1_ASAP7_75t_R  g26(.A1(new_n58_), .A2(new_n59_), .B(p1), .Y(new_n60_));
  INVx1_ASAP7_75t_R    g27(.A(p5), .Y(new_n61_));
  NAND2x1_ASAP7_75t_R  g28(.A(p3), .B(new_n61_), .Y(new_n62_));
  INVx1_ASAP7_75t_R    g29(.A(p4), .Y(new_n63_));
  NAND2x1_ASAP7_75t_R  g30(.A(p3), .B(new_n63_), .Y(new_n64_));
  AND3x1_ASAP7_75t_R   g31(.A(p6), .B(p2), .C(p0), .Y(new_n65_));
  NAND3x1_ASAP7_75t_R  g32(.A(new_n62_), .B(new_n64_), .C(new_n65_), .Y(new_n66_));
  NOR2x1_ASAP7_75t_R   g33(.A(p2), .B(new_n49_), .Y(new_n67_));
  AOI21x1_ASAP7_75t_R  g34(.A1(p6), .A2(new_n67_), .B(new_n43_), .Y(new_n68_));
  AOI21x1_ASAP7_75t_R  g35(.A1(new_n60_), .A2(new_n66_), .B(new_n68_), .Y(o4));
  AO21x1_ASAP7_75t_R   g36(.A1(p3), .A2(new_n61_), .B(new_n41_), .Y(new_n70_));
  NOR2x1_ASAP7_75t_R   g37(.A(new_n43_), .B(new_n67_), .Y(new_n71_));
  AOI211x1_ASAP7_75t_R g38(.A1(new_n43_), .A2(new_n70_), .B(new_n39_), .C(new_n71_), .Y(o5));
  AO21x1_ASAP7_75t_R   g39(.A1(p6), .A2(p0), .B(new_n52_), .Y(new_n73_));
  NOR2x1_ASAP7_75t_R   g40(.A(p1), .B(new_n35_), .Y(new_n74_));
  OA22x2_ASAP7_75t_R   g41(.A1(new_n73_), .A2(p1), .B1(new_n34_), .B2(new_n74_), .Y(o6));
  INVx1_ASAP7_75t_R    g42(.A(p6), .Y(new_n76_));
  AND5x1_ASAP7_75t_R   g43(.A(new_n76_), .B(new_n39_), .C(new_n43_), .D(p3), .E(p2), .Y(new_n77_));
  NOR3x1_ASAP7_75t_R   g44(.A(new_n52_), .B(new_n76_), .C(new_n43_), .Y(new_n78_));
  OR3x1_ASAP7_75t_R    g45(.A(new_n77_), .B(new_n36_), .C(new_n78_), .Y(o7));
  NOR2x1_ASAP7_75t_R   g46(.A(new_n43_), .B(new_n35_), .Y(new_n80_));
  AOI221x1_ASAP7_75t_R g47(.A1(new_n52_), .A2(new_n80_), .B1(new_n50_), .B2(new_n43_), .C(new_n39_), .Y(o8));
  AOI21x1_ASAP7_75t_R  g48(.A1(new_n40_), .A2(new_n50_), .B(new_n45_), .Y(o9));
  AO22x1_ASAP7_75t_R   g49(.A1(new_n41_), .A2(new_n43_), .B1(p3), .B2(new_n55_), .Y(new_n83_));
  AO21x1_ASAP7_75t_R   g50(.A1(new_n76_), .A2(p0), .B(new_n42_), .Y(new_n84_));
  OAI21x1_ASAP7_75t_R  g51(.A1(new_n71_), .A2(new_n83_), .B(new_n84_), .Y(o10));
  AND3x1_ASAP7_75t_R   g52(.A(new_n55_), .B(new_n35_), .C(new_n76_), .Y(o11));
  OR3x1_ASAP7_75t_R    g53(.A(p6), .B(p2), .C(p0), .Y(new_n87_));
  AND3x1_ASAP7_75t_R   g54(.A(new_n41_), .B(p0), .C(p1), .Y(new_n88_));
  AO221x2_ASAP7_75t_R  g55(.A1(p3), .A2(p1), .B1(new_n74_), .B2(new_n87_), .C(new_n88_), .Y(o12));
  AND3x1_ASAP7_75t_R   g56(.A(new_n35_), .B(p6), .C(p1), .Y(o13));
  AND3x1_ASAP7_75t_R   g57(.A(new_n35_), .B(new_n76_), .C(p1), .Y(o14));
  NOR2x1_ASAP7_75t_R   g58(.A(p6), .B(p0), .Y(new_n92_));
  AND3x1_ASAP7_75t_R   g59(.A(new_n47_), .B(p1), .C(new_n92_), .Y(o15));
  NOR2x1_ASAP7_75t_R   g60(.A(p0), .B(new_n76_), .Y(new_n94_));
  AND3x1_ASAP7_75t_R   g61(.A(new_n94_), .B(new_n47_), .C(p1), .Y(o16));
  AND2x2_ASAP7_75t_R   g62(.A(p6), .B(p0), .Y(new_n96_));
  AND3x1_ASAP7_75t_R   g63(.A(new_n47_), .B(p1), .C(new_n96_), .Y(o17));
  AND5x1_ASAP7_75t_R   g64(.A(new_n76_), .B(new_n49_), .C(p2), .D(p0), .E(p1), .Y(o18));
  AND3x1_ASAP7_75t_R   g65(.A(new_n49_), .B(new_n41_), .C(p1), .Y(o19));
  NAND2x1_ASAP7_75t_R  g66(.A(new_n65_), .B(new_n64_), .Y(new_n100_));
  AOI21x1_ASAP7_75t_R  g67(.A1(new_n94_), .A2(new_n47_), .B(p1), .Y(new_n101_));
  OA21x2_ASAP7_75t_R   g68(.A1(new_n52_), .A2(new_n96_), .B(p1), .Y(new_n102_));
  AOI21x1_ASAP7_75t_R  g69(.A1(new_n100_), .A2(new_n101_), .B(new_n102_), .Y(o20));
  NOR2x1_ASAP7_75t_R   g70(.A(p5), .B(new_n49_), .Y(new_n104_));
  NOR2x1_ASAP7_75t_R   g71(.A(p1), .B(new_n76_), .Y(new_n105_));
  AO32x1_ASAP7_75t_R   g72(.A1(new_n104_), .A2(new_n58_), .A3(new_n105_), .B1(new_n44_), .B2(new_n47_), .Y(o21));
  AOI21x1_ASAP7_75t_R  g73(.A1(new_n43_), .A2(new_n66_), .B(new_n102_), .Y(o22));
  assign               o23 = 1'b1;
  OA211x2_ASAP7_75t_R  g74(.A1(new_n92_), .A2(new_n96_), .B(new_n67_), .C(new_n43_), .Y(o24));
  AND3x1_ASAP7_75t_R   g75(.A(new_n67_), .B(p6), .C(new_n55_), .Y(o25));
endmodule


