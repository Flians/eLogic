// Benchmark "/tmp/" written by ABC on Tue Oct 20 17:33:06 2026

module \/tmp/  ( 
    p2, p1, p3, p4, p0, p5, p6,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25  );
  input  p2, p1, p3, p4, p0, p5, p6;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25;
  wire new_n34_, new_n35_, new_n36_, new_n37_, new_n38_, new_n39_, new_n41_,
    new_n42_, new_n43_, new_n44_, new_n45_, new_n46_, new_n47_, new_n48_,
    new_n50_, new_n51_, new_n52_, new_n53_, new_n55_, new_n57_, new_n58_,
    new_n59_, new_n60_, new_n61_, new_n62_, new_n63_, new_n64_, new_n66_,
    new_n67_, new_n68_, new_n70_, new_n71_, new_n72_, new_n74_, new_n75_,
    new_n77_, new_n79_, new_n81_, new_n82_, new_n83_, new_n86_, new_n87_,
    new_n88_, new_n92_, new_n94_, new_n96_, new_n100_, new_n101_,
    new_n102_, new_n104_, new_n105_, new_n107_, new_n108_, new_n109_,
    new_n110_, new_n113_;
  INVx1_ASAP7_75t_R    g00(.A(p1), .Y(new_n34_));
  INVx1_ASAP7_75t_R    g01(.A(p0), .Y(new_n35_));
  OR4x2_ASAP7_75t_R    g02(.A(new_n34_), .B(new_n35_), .C(p2), .D(p3), .Y(new_n36_));
  NAND2x1_ASAP7_75t_R  g03(.A(p2), .B(p3), .Y(new_n37_));
  INVx1_ASAP7_75t_R    g04(.A(p6), .Y(new_n38_));
  NOR2x1_ASAP7_75t_R   g05(.A(p1), .B(p0), .Y(new_n39_));
  AOI22x1_ASAP7_75t_R  g06(.A1(new_n36_), .A2(new_n37_), .B1(new_n38_), .B2(new_n39_), .Y(o0));
  INVx1_ASAP7_75t_R    g07(.A(p2), .Y(new_n41_));
  INVx1_ASAP7_75t_R    g08(.A(p3), .Y(new_n42_));
  OR3x1_ASAP7_75t_R    g09(.A(new_n41_), .B(new_n42_), .C(p6), .Y(new_n43_));
  NOR2x1_ASAP7_75t_R   g10(.A(p2), .B(p3), .Y(new_n44_));
  AOI21x1_ASAP7_75t_R  g11(.A1(p0), .A2(new_n44_), .B(new_n34_), .Y(new_n45_));
  NAND2x1_ASAP7_75t_R  g12(.A(p0), .B(new_n34_), .Y(new_n46_));
  NOR2x1_ASAP7_75t_R   g13(.A(p2), .B(new_n42_), .Y(new_n47_));
  NOR2x1_ASAP7_75t_R   g14(.A(new_n46_), .B(new_n47_), .Y(new_n48_));
  AOI211x1_ASAP7_75t_R g15(.A1(new_n39_), .A2(new_n43_), .B(new_n45_), .C(new_n48_), .Y(o1));
  NOR2x1_ASAP7_75t_R   g16(.A(p3), .B(new_n41_), .Y(new_n50_));
  NOR2x1_ASAP7_75t_R   g17(.A(new_n35_), .B(new_n50_), .Y(new_n51_));
  OR3x1_ASAP7_75t_R    g18(.A(new_n42_), .B(p2), .C(p6), .Y(new_n52_));
  OR3x1_ASAP7_75t_R    g19(.A(new_n37_), .B(p1), .C(p6), .Y(new_n53_));
  AOI22x1_ASAP7_75t_R  g20(.A1(new_n51_), .A2(new_n52_), .B1(new_n46_), .B2(new_n53_), .Y(o2));
  INVx1_ASAP7_75t_R    g21(.A(new_n44_), .Y(new_n55_));
  OA221x2_ASAP7_75t_R  g22(.A1(new_n41_), .A2(new_n39_), .B1(new_n38_), .B2(new_n37_), .C(new_n55_), .Y(o3));
  NAND2x1_ASAP7_75t_R  g23(.A(p4), .B(p0), .Y(new_n57_));
  OA31x2_ASAP7_75t_R   g24(.A1(p6), .A2(new_n37_), .A3(new_n57_), .B1(new_n34_), .Y(new_n58_));
  AND3x1_ASAP7_75t_R   g25(.A(p2), .B(p0), .C(p6), .Y(new_n59_));
  INVx1_ASAP7_75t_R    g26(.A(p4), .Y(new_n60_));
  INVx1_ASAP7_75t_R    g27(.A(p5), .Y(new_n61_));
  OAI21x1_ASAP7_75t_R  g28(.A1(new_n60_), .A2(new_n61_), .B(p3), .Y(new_n62_));
  NAND2x1_ASAP7_75t_R  g29(.A(new_n59_), .B(new_n62_), .Y(new_n63_));
  AOI21x1_ASAP7_75t_R  g30(.A1(p6), .A2(new_n47_), .B(new_n34_), .Y(new_n64_));
  AOI21x1_ASAP7_75t_R  g31(.A1(new_n58_), .A2(new_n63_), .B(new_n64_), .Y(o4));
  NAND2x1_ASAP7_75t_R  g32(.A(p2), .B(new_n42_), .Y(new_n66_));
  AOI21x1_ASAP7_75t_R  g33(.A1(p2), .A2(p5), .B(p1), .Y(new_n67_));
  NOR2x1_ASAP7_75t_R   g34(.A(new_n34_), .B(new_n47_), .Y(new_n68_));
  AOI211x1_ASAP7_75t_R g35(.A1(new_n66_), .A2(new_n67_), .B(new_n35_), .C(new_n68_), .Y(o5));
  NOR2x1_ASAP7_75t_R   g36(.A(p1), .B(new_n44_), .Y(new_n70_));
  AOI21x1_ASAP7_75t_R  g37(.A1(p0), .A2(p6), .B(p1), .Y(new_n71_));
  NOR2x1_ASAP7_75t_R   g38(.A(new_n37_), .B(new_n71_), .Y(new_n72_));
  AO21x1_ASAP7_75t_R   g39(.A1(new_n37_), .A2(new_n70_), .B(new_n72_), .Y(o6));
  OR5x1_ASAP7_75t_R    g40(.A(new_n41_), .B(new_n42_), .C(p1), .D(p0), .E(p6), .Y(new_n74_));
  OR3x1_ASAP7_75t_R    g41(.A(new_n37_), .B(new_n34_), .C(new_n38_), .Y(new_n75_));
  NAND3x1_ASAP7_75t_R  g42(.A(new_n36_), .B(new_n74_), .C(new_n75_), .Y(o7));
  AND2x2_ASAP7_75t_R   g43(.A(p1), .B(new_n37_), .Y(new_n77_));
  AOI221x1_ASAP7_75t_R g44(.A1(new_n52_), .A2(new_n34_), .B1(new_n77_), .B2(new_n55_), .C(new_n35_), .Y(o8));
  INVx1_ASAP7_75t_R    g45(.A(new_n46_), .Y(new_n79_));
  AOI221x1_ASAP7_75t_R g46(.A1(new_n35_), .A2(new_n37_), .B1(new_n79_), .B2(new_n52_), .C(new_n45_), .Y(o9));
  NOR2x1_ASAP7_75t_R   g47(.A(p2), .B(p1), .Y(new_n81_));
  AO21x1_ASAP7_75t_R   g48(.A1(p3), .A2(new_n39_), .B(new_n81_), .Y(new_n82_));
  OAI21x1_ASAP7_75t_R  g49(.A1(new_n35_), .A2(p6), .B(new_n47_), .Y(new_n83_));
  OAI21x1_ASAP7_75t_R  g50(.A1(new_n82_), .A2(new_n68_), .B(new_n83_), .Y(o10));
  AND3x1_ASAP7_75t_R   g51(.A(new_n39_), .B(new_n44_), .C(new_n38_), .Y(o11));
  NOR2x1_ASAP7_75t_R   g52(.A(p3), .B(p0), .Y(new_n86_));
  INVx1_ASAP7_75t_R    g53(.A(new_n86_), .Y(new_n87_));
  OR3x1_ASAP7_75t_R    g54(.A(p2), .B(p0), .C(p6), .Y(new_n88_));
  AO32x1_ASAP7_75t_R   g55(.A1(p1), .A2(new_n66_), .A3(new_n87_), .B1(new_n70_), .B2(new_n88_), .Y(o12));
  AND3x1_ASAP7_75t_R   g56(.A(new_n44_), .B(p1), .C(p6), .Y(o13));
  AND3x1_ASAP7_75t_R   g57(.A(new_n44_), .B(p1), .C(new_n38_), .Y(o14));
  NOR2x1_ASAP7_75t_R   g58(.A(p0), .B(p6), .Y(new_n92_));
  AND3x1_ASAP7_75t_R   g59(.A(new_n50_), .B(p1), .C(new_n92_), .Y(o15));
  AND2x2_ASAP7_75t_R   g60(.A(p2), .B(p6), .Y(new_n94_));
  AND3x1_ASAP7_75t_R   g61(.A(new_n94_), .B(p1), .C(new_n86_), .Y(o16));
  AND3x1_ASAP7_75t_R   g62(.A(p1), .B(p0), .C(p6), .Y(new_n96_));
  AND3x1_ASAP7_75t_R   g63(.A(new_n96_), .B(p2), .C(new_n42_), .Y(o17));
  AND5x1_ASAP7_75t_R   g64(.A(p2), .B(new_n42_), .C(new_n38_), .D(p1), .E(p0), .Y(o18));
  AND3x1_ASAP7_75t_R   g65(.A(new_n41_), .B(new_n42_), .C(p1), .Y(o19));
  OAI21x1_ASAP7_75t_R  g66(.A1(new_n42_), .A2(p4), .B(new_n59_), .Y(new_n100_));
  AOI21x1_ASAP7_75t_R  g67(.A1(new_n86_), .A2(new_n94_), .B(p1), .Y(new_n101_));
  AO21x1_ASAP7_75t_R   g68(.A1(p1), .A2(new_n37_), .B(new_n96_), .Y(new_n102_));
  AOI21x1_ASAP7_75t_R  g69(.A1(new_n100_), .A2(new_n101_), .B(new_n102_), .Y(o20));
  NAND2x1_ASAP7_75t_R  g70(.A(new_n86_), .B(new_n94_), .Y(new_n104_));
  OR5x1_ASAP7_75t_R    g71(.A(new_n41_), .B(new_n57_), .C(new_n42_), .D(p5), .E(new_n38_), .Y(new_n105_));
  AOI21x1_ASAP7_75t_R  g72(.A1(new_n104_), .A2(new_n105_), .B(p1), .Y(o21));
  NAND2x1_ASAP7_75t_R  g73(.A(new_n67_), .B(new_n66_), .Y(new_n107_));
  AOI211x1_ASAP7_75t_R g74(.A1(p1), .A2(new_n37_), .B(new_n71_), .C(new_n96_), .Y(new_n108_));
  NAND2x1_ASAP7_75t_R  g75(.A(p3), .B(p5), .Y(new_n109_));
  OR3x1_ASAP7_75t_R    g76(.A(new_n109_), .B(p1), .C(p4), .Y(new_n110_));
  AND3x1_ASAP7_75t_R   g77(.A(new_n107_), .B(new_n108_), .C(new_n110_), .Y(o22));
  assign               o23 = 1'b1;
  AND2x2_ASAP7_75t_R   g78(.A(p0), .B(p6), .Y(new_n113_));
  OA211x2_ASAP7_75t_R  g79(.A1(new_n92_), .A2(new_n113_), .B(p3), .C(new_n81_), .Y(o24));
  AND3x1_ASAP7_75t_R   g80(.A(new_n47_), .B(p6), .C(new_n39_), .Y(o25));
endmodule


