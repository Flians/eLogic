// Benchmark "/tmp/" written by ABC on Tue Oct 20 17:33:00 2026

module \/tmp/  ( 
    p3, p2, p4, p5, p6, p0, p1,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25  );
  input  p3, p2, p4, p5, p6, p0, p1;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25;
  wire new_n34_, new_n35_, new_n36_, new_n37_, new_n38_, new_n40_, new_n41_,
    new_n42_, new_n43_, new_n44_, new_n45_, new_n46_, new_n47_, new_n48_,
    new_n50_, new_n51_, new_n52_, new_n54_, new_n56_, new_n57_, new_n58_,
    new_n59_, new_n60_, new_n61_, new_n62_, new_n63_, new_n64_, new_n65_,
    new_n67_, new_n69_, new_n70_, new_n72_, new_n74_, new_n77_, new_n78_,
    new_n79_, new_n81_, new_n83_, new_n84_, new_n85_, new_n90_, new_n95_,
    new_n96_, new_n97_, new_n99_;
  NAND2x1_ASAP7_75t_R  g00(.A(p3), .B(p2), .Y(new_n34_));
  INVx1_ASAP7_75t_R    g01(.A(new_n34_), .Y(new_n35_));
  OR3x1_ASAP7_75t_R    g02(.A(p6), .B(p0), .C(p1), .Y(new_n36_));
  NOR2x1_ASAP7_75t_R   g03(.A(p3), .B(p2), .Y(new_n37_));
  AND3x1_ASAP7_75t_R   g04(.A(new_n37_), .B(p0), .C(p1), .Y(new_n38_));
  AO21x1_ASAP7_75t_R   g05(.A1(new_n35_), .A2(new_n36_), .B(new_n38_), .Y(o0));
  INVx1_ASAP7_75t_R    g06(.A(p2), .Y(new_n40_));
  NAND2x1_ASAP7_75t_R  g07(.A(p3), .B(new_n40_), .Y(new_n41_));
  INVx1_ASAP7_75t_R    g08(.A(p0), .Y(new_n42_));
  NOR2x1_ASAP7_75t_R   g09(.A(p1), .B(new_n42_), .Y(new_n43_));
  INVx1_ASAP7_75t_R    g10(.A(p3), .Y(new_n44_));
  OR3x1_ASAP7_75t_R    g11(.A(new_n44_), .B(new_n40_), .C(p6), .Y(new_n45_));
  NOR2x1_ASAP7_75t_R   g12(.A(p0), .B(p1), .Y(new_n46_));
  INVx1_ASAP7_75t_R    g13(.A(p1), .Y(new_n47_));
  AOI21x1_ASAP7_75t_R  g14(.A1(p0), .A2(new_n37_), .B(new_n47_), .Y(new_n48_));
  AOI221x1_ASAP7_75t_R g15(.A1(new_n41_), .A2(new_n43_), .B1(new_n45_), .B2(new_n46_), .C(new_n48_), .Y(o1));
  NOR2x1_ASAP7_75t_R   g16(.A(p3), .B(new_n40_), .Y(new_n50_));
  NOR2x1_ASAP7_75t_R   g17(.A(new_n42_), .B(new_n50_), .Y(new_n51_));
  OR3x1_ASAP7_75t_R    g18(.A(new_n44_), .B(p2), .C(p6), .Y(new_n52_));
  AOI221x1_ASAP7_75t_R g19(.A1(new_n42_), .A2(new_n45_), .B1(new_n51_), .B2(new_n52_), .C(p1), .Y(o2));
  INVx1_ASAP7_75t_R    g20(.A(new_n46_), .Y(new_n54_));
  AOI221x1_ASAP7_75t_R g21(.A1(new_n35_), .A2(p6), .B1(p2), .B2(new_n54_), .C(new_n37_), .Y(o3));
  NAND2x1_ASAP7_75t_R  g22(.A(p4), .B(p0), .Y(new_n56_));
  OA31x2_ASAP7_75t_R   g23(.A1(p6), .A2(new_n34_), .A3(new_n56_), .B1(new_n47_), .Y(new_n57_));
  INVx1_ASAP7_75t_R    g24(.A(p5), .Y(new_n58_));
  AOI21x1_ASAP7_75t_R  g25(.A1(p3), .A2(new_n58_), .B(new_n40_), .Y(new_n59_));
  INVx1_ASAP7_75t_R    g26(.A(p4), .Y(new_n60_));
  NAND3x1_ASAP7_75t_R  g27(.A(new_n60_), .B(p3), .C(p5), .Y(new_n61_));
  AND2x2_ASAP7_75t_R   g28(.A(p6), .B(p0), .Y(new_n62_));
  NAND3x1_ASAP7_75t_R  g29(.A(new_n59_), .B(new_n61_), .C(new_n62_), .Y(new_n63_));
  INVx1_ASAP7_75t_R    g30(.A(p6), .Y(new_n64_));
  OA21x2_ASAP7_75t_R   g31(.A1(new_n64_), .A2(new_n41_), .B(p1), .Y(new_n65_));
  AOI21x1_ASAP7_75t_R  g32(.A1(new_n57_), .A2(new_n63_), .B(new_n65_), .Y(o4));
  AO21x1_ASAP7_75t_R   g33(.A1(p3), .A2(new_n40_), .B(new_n47_), .Y(new_n67_));
  OA211x2_ASAP7_75t_R  g34(.A1(p1), .A2(new_n59_), .B(new_n67_), .C(p0), .Y(o5));
  NOR2x1_ASAP7_75t_R   g35(.A(p1), .B(new_n37_), .Y(new_n69_));
  OR3x1_ASAP7_75t_R    g36(.A(new_n62_), .B(p1), .C(new_n34_), .Y(new_n70_));
  OA21x2_ASAP7_75t_R   g37(.A1(new_n35_), .A2(new_n69_), .B(new_n70_), .Y(o6));
  OAI21x1_ASAP7_75t_R  g38(.A1(new_n64_), .A2(new_n47_), .B(new_n36_), .Y(new_n72_));
  AO21x1_ASAP7_75t_R   g39(.A1(new_n35_), .A2(new_n72_), .B(new_n38_), .Y(o7));
  NOR2x1_ASAP7_75t_R   g40(.A(new_n47_), .B(new_n37_), .Y(new_n74_));
  AOI221x1_ASAP7_75t_R g41(.A1(new_n34_), .A2(new_n74_), .B1(new_n52_), .B2(new_n47_), .C(new_n42_), .Y(o8));
  AOI221x1_ASAP7_75t_R g42(.A1(new_n42_), .A2(new_n34_), .B1(new_n52_), .B2(new_n43_), .C(new_n48_), .Y(o9));
  NAND2x1_ASAP7_75t_R  g43(.A(p0), .B(new_n64_), .Y(new_n77_));
  NOR2x1_ASAP7_75t_R   g44(.A(p2), .B(p1), .Y(new_n78_));
  AOI21x1_ASAP7_75t_R  g45(.A1(p3), .A2(new_n46_), .B(new_n78_), .Y(new_n79_));
  AO32x1_ASAP7_75t_R   g46(.A1(p3), .A2(new_n40_), .A3(new_n77_), .B1(new_n79_), .B2(new_n67_), .Y(o10));
  NOR2x1_ASAP7_75t_R   g47(.A(p6), .B(p0), .Y(new_n81_));
  AND3x1_ASAP7_75t_R   g48(.A(new_n37_), .B(new_n81_), .C(new_n47_), .Y(o11));
  NAND2x1_ASAP7_75t_R  g49(.A(new_n44_), .B(new_n42_), .Y(new_n83_));
  NAND2x1_ASAP7_75t_R  g50(.A(p2), .B(new_n44_), .Y(new_n84_));
  OR3x1_ASAP7_75t_R    g51(.A(p2), .B(p6), .C(p0), .Y(new_n85_));
  AO32x1_ASAP7_75t_R   g52(.A1(p1), .A2(new_n83_), .A3(new_n84_), .B1(new_n69_), .B2(new_n85_), .Y(o12));
  AND3x1_ASAP7_75t_R   g53(.A(new_n37_), .B(p6), .C(p1), .Y(o13));
  AND3x1_ASAP7_75t_R   g54(.A(new_n37_), .B(new_n64_), .C(p1), .Y(o14));
  AND3x1_ASAP7_75t_R   g55(.A(new_n50_), .B(p1), .C(new_n81_), .Y(o15));
  AND3x1_ASAP7_75t_R   g56(.A(new_n44_), .B(new_n42_), .C(p2), .Y(new_n90_));
  AND3x1_ASAP7_75t_R   g57(.A(new_n90_), .B(p6), .C(p1), .Y(o16));
  AND3x1_ASAP7_75t_R   g58(.A(new_n50_), .B(p1), .C(new_n62_), .Y(o17));
  AND5x1_ASAP7_75t_R   g59(.A(new_n44_), .B(new_n64_), .C(p2), .D(p0), .E(p1), .Y(o18));
  AND3x1_ASAP7_75t_R   g60(.A(new_n44_), .B(new_n40_), .C(p1), .Y(o19));
  NAND2x1_ASAP7_75t_R  g61(.A(p2), .B(p6), .Y(new_n95_));
  AO21x1_ASAP7_75t_R   g62(.A1(p3), .A2(new_n56_), .B(new_n95_), .Y(new_n96_));
  OA21x2_ASAP7_75t_R   g63(.A1(new_n34_), .A2(new_n62_), .B(p1), .Y(new_n97_));
  AOI21x1_ASAP7_75t_R  g64(.A1(new_n47_), .A2(new_n96_), .B(new_n97_), .Y(o20));
  AND5x1_ASAP7_75t_R   g65(.A(p3), .B(new_n58_), .C(p2), .D(p4), .E(p0), .Y(new_n99_));
  OA211x2_ASAP7_75t_R  g66(.A1(new_n90_), .A2(new_n99_), .B(p6), .C(new_n47_), .Y(o21));
  AOI21x1_ASAP7_75t_R  g67(.A1(new_n47_), .A2(new_n63_), .B(new_n97_), .Y(o22));
  assign               o23 = 1'b1;
  OA211x2_ASAP7_75t_R  g68(.A1(new_n81_), .A2(new_n62_), .B(p3), .C(new_n78_), .Y(o24));
  AND5x1_ASAP7_75t_R   g69(.A(p3), .B(new_n40_), .C(new_n42_), .D(new_n47_), .E(p6), .Y(o25));
endmodule


