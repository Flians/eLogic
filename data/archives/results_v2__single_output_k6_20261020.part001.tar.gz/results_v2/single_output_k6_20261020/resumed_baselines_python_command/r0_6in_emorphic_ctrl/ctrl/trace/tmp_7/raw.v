// Benchmark "/tmp/" written by ABC on Tue Oct 20 17:33:00 2026

module \/tmp/  ( 
    p4, p5, p1, p2, p0, p3, p6,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25  );
  input  p4, p5, p1, p2, p0, p3, p6;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25;
  wire new_n34_, new_n35_, new_n36_, new_n37_, new_n39_, new_n40_, new_n41_,
    new_n42_, new_n43_, new_n44_, new_n45_, new_n47_, new_n48_, new_n49_,
    new_n50_, new_n52_, new_n53_, new_n54_, new_n56_, new_n57_, new_n58_,
    new_n59_, new_n60_, new_n61_, new_n62_, new_n63_, new_n65_, new_n66_,
    new_n67_, new_n68_, new_n70_, new_n71_, new_n73_, new_n74_, new_n78_,
    new_n80_, new_n81_, new_n82_, new_n83_, new_n86_, new_n87_, new_n88_,
    new_n89_, new_n94_, new_n96_, new_n99_, new_n100_, new_n101_,
    new_n103_, new_n104_, new_n105_, new_n107_, new_n108_, new_n109_,
    new_n112_;
  NOR2x1_ASAP7_75t_R   g00(.A(p2), .B(p3), .Y(new_n34_));
  NAND2x1_ASAP7_75t_R  g01(.A(p2), .B(p3), .Y(new_n35_));
  INVx1_ASAP7_75t_R    g02(.A(new_n35_), .Y(new_n36_));
  OR3x1_ASAP7_75t_R    g03(.A(p1), .B(p0), .C(p6), .Y(new_n37_));
  AO32x1_ASAP7_75t_R   g04(.A1(p1), .A2(p0), .A3(new_n34_), .B1(new_n36_), .B2(new_n37_), .Y(o0));
  INVx1_ASAP7_75t_R    g05(.A(p0), .Y(new_n39_));
  INVx1_ASAP7_75t_R    g06(.A(p3), .Y(new_n40_));
  OR3x1_ASAP7_75t_R    g07(.A(new_n39_), .B(new_n40_), .C(p2), .Y(new_n41_));
  NOR2x1_ASAP7_75t_R   g08(.A(p0), .B(p6), .Y(new_n42_));
  NOR2x1_ASAP7_75t_R   g09(.A(p1), .B(new_n42_), .Y(new_n43_));
  INVx1_ASAP7_75t_R    g10(.A(p1), .Y(new_n44_));
  OAI22x1_ASAP7_75t_R  g11(.A1(new_n36_), .A2(p0), .B1(new_n44_), .B2(new_n34_), .Y(new_n45_));
  AOI21x1_ASAP7_75t_R  g12(.A1(new_n41_), .A2(new_n43_), .B(new_n45_), .Y(o1));
  OR3x1_ASAP7_75t_R    g13(.A(new_n40_), .B(p2), .C(p6), .Y(new_n47_));
  INVx1_ASAP7_75t_R    g14(.A(p2), .Y(new_n48_));
  OA21x2_ASAP7_75t_R   g15(.A1(p3), .A2(new_n48_), .B(p0), .Y(new_n49_));
  OA21x2_ASAP7_75t_R   g16(.A1(p6), .A2(new_n35_), .B(new_n39_), .Y(new_n50_));
  AOI211x1_ASAP7_75t_R g17(.A1(new_n47_), .A2(new_n49_), .B(p1), .C(new_n50_), .Y(o2));
  NOR2x1_ASAP7_75t_R   g18(.A(p1), .B(p0), .Y(new_n52_));
  INVx1_ASAP7_75t_R    g19(.A(p6), .Y(new_n53_));
  INVx1_ASAP7_75t_R    g20(.A(new_n34_), .Y(new_n54_));
  OA221x2_ASAP7_75t_R  g21(.A1(new_n48_), .A2(new_n52_), .B1(new_n53_), .B2(new_n35_), .C(new_n54_), .Y(o3));
  AND2x2_ASAP7_75t_R   g22(.A(p4), .B(p5), .Y(new_n56_));
  AND3x1_ASAP7_75t_R   g23(.A(p2), .B(p0), .C(p6), .Y(new_n57_));
  OAI21x1_ASAP7_75t_R  g24(.A1(new_n40_), .A2(new_n56_), .B(new_n57_), .Y(new_n58_));
  AND3x1_ASAP7_75t_R   g25(.A(p4), .B(p2), .C(p3), .Y(new_n59_));
  NOR2x1_ASAP7_75t_R   g26(.A(p6), .B(new_n39_), .Y(new_n60_));
  AOI21x1_ASAP7_75t_R  g27(.A1(new_n59_), .A2(new_n60_), .B(p1), .Y(new_n61_));
  NOR2x1_ASAP7_75t_R   g28(.A(p2), .B(new_n40_), .Y(new_n62_));
  AOI21x1_ASAP7_75t_R  g29(.A1(p6), .A2(new_n62_), .B(new_n44_), .Y(new_n63_));
  AOI21x1_ASAP7_75t_R  g30(.A1(new_n58_), .A2(new_n61_), .B(new_n63_), .Y(o4));
  AOI21x1_ASAP7_75t_R  g31(.A1(p5), .A2(p2), .B(p1), .Y(new_n65_));
  NAND2x1_ASAP7_75t_R  g32(.A(p2), .B(new_n40_), .Y(new_n66_));
  NAND2x1_ASAP7_75t_R  g33(.A(new_n65_), .B(new_n66_), .Y(new_n67_));
  AO21x1_ASAP7_75t_R   g34(.A1(p3), .A2(new_n48_), .B(new_n44_), .Y(new_n68_));
  AND3x1_ASAP7_75t_R   g35(.A(new_n67_), .B(p0), .C(new_n68_), .Y(o5));
  AOI21x1_ASAP7_75t_R  g36(.A1(p0), .A2(p6), .B(p1), .Y(new_n70_));
  AND2x2_ASAP7_75t_R   g37(.A(p1), .B(new_n35_), .Y(new_n71_));
  AOI211x1_ASAP7_75t_R g38(.A1(new_n36_), .A2(new_n70_), .B(new_n34_), .C(new_n71_), .Y(o6));
  AO21x1_ASAP7_75t_R   g39(.A1(new_n44_), .A2(new_n39_), .B(p6), .Y(new_n73_));
  NAND2x1_ASAP7_75t_R  g40(.A(p6), .B(new_n44_), .Y(new_n74_));
  AND3x1_ASAP7_75t_R   g41(.A(new_n48_), .B(new_n40_), .C(p1), .Y(o19));
  AO32x1_ASAP7_75t_R   g42(.A1(new_n73_), .A2(new_n36_), .A3(new_n74_), .B1(o19), .B2(p0), .Y(o7));
  AOI221x1_ASAP7_75t_R g43(.A1(new_n47_), .A2(new_n44_), .B1(new_n71_), .B2(new_n54_), .C(new_n39_), .Y(o8));
  NOR2x1_ASAP7_75t_R   g44(.A(p1), .B(new_n39_), .Y(new_n78_));
  AOI21x1_ASAP7_75t_R  g45(.A1(new_n78_), .A2(new_n47_), .B(new_n45_), .Y(o9));
  NAND2x1_ASAP7_75t_R  g46(.A(p3), .B(new_n52_), .Y(new_n80_));
  NOR2x1_ASAP7_75t_R   g47(.A(p1), .B(p2), .Y(new_n81_));
  INVx1_ASAP7_75t_R    g48(.A(new_n81_), .Y(new_n82_));
  NAND2x1_ASAP7_75t_R  g49(.A(p0), .B(new_n53_), .Y(new_n83_));
  AO32x1_ASAP7_75t_R   g50(.A1(new_n68_), .A2(new_n80_), .A3(new_n82_), .B1(new_n62_), .B2(new_n83_), .Y(o10));
  AND3x1_ASAP7_75t_R   g51(.A(new_n42_), .B(new_n81_), .C(new_n40_), .Y(o11));
  NOR2x1_ASAP7_75t_R   g52(.A(p0), .B(p3), .Y(new_n86_));
  INVx1_ASAP7_75t_R    g53(.A(new_n86_), .Y(new_n87_));
  NOR2x1_ASAP7_75t_R   g54(.A(p1), .B(new_n34_), .Y(new_n88_));
  OR3x1_ASAP7_75t_R    g55(.A(p2), .B(p0), .C(p6), .Y(new_n89_));
  AO32x1_ASAP7_75t_R   g56(.A1(p1), .A2(new_n87_), .A3(new_n66_), .B1(new_n88_), .B2(new_n89_), .Y(o12));
  AND3x1_ASAP7_75t_R   g57(.A(new_n34_), .B(p1), .C(p6), .Y(o13));
  AND3x1_ASAP7_75t_R   g58(.A(new_n34_), .B(p1), .C(new_n53_), .Y(o14));
  AND5x1_ASAP7_75t_R   g59(.A(p1), .B(new_n39_), .C(new_n40_), .D(new_n53_), .E(p2), .Y(o15));
  AND2x2_ASAP7_75t_R   g60(.A(p2), .B(p6), .Y(new_n94_));
  AND3x1_ASAP7_75t_R   g61(.A(new_n94_), .B(p1), .C(new_n86_), .Y(o16));
  AND3x1_ASAP7_75t_R   g62(.A(p1), .B(p0), .C(p6), .Y(new_n96_));
  AND3x1_ASAP7_75t_R   g63(.A(new_n96_), .B(p2), .C(new_n40_), .Y(o17));
  AND5x1_ASAP7_75t_R   g64(.A(p1), .B(new_n40_), .C(new_n53_), .D(p2), .E(p0), .Y(o18));
  OAI21x1_ASAP7_75t_R  g65(.A1(p4), .A2(new_n40_), .B(new_n57_), .Y(new_n99_));
  AOI21x1_ASAP7_75t_R  g66(.A1(new_n86_), .A2(new_n94_), .B(p1), .Y(new_n100_));
  AO21x1_ASAP7_75t_R   g67(.A1(p1), .A2(new_n35_), .B(new_n96_), .Y(new_n101_));
  AOI21x1_ASAP7_75t_R  g68(.A1(new_n99_), .A2(new_n100_), .B(new_n101_), .Y(o20));
  NAND2x1_ASAP7_75t_R  g69(.A(p2), .B(new_n86_), .Y(new_n103_));
  INVx1_ASAP7_75t_R    g70(.A(p4), .Y(new_n104_));
  OR4x2_ASAP7_75t_R    g71(.A(new_n35_), .B(new_n104_), .C(p5), .D(new_n39_), .Y(new_n105_));
  AOI21x1_ASAP7_75t_R  g72(.A1(new_n103_), .A2(new_n105_), .B(new_n74_), .Y(o21));
  AOI211x1_ASAP7_75t_R g73(.A1(p1), .A2(new_n35_), .B(new_n70_), .C(new_n96_), .Y(new_n107_));
  NAND2x1_ASAP7_75t_R  g74(.A(p5), .B(p3), .Y(new_n108_));
  OR3x1_ASAP7_75t_R    g75(.A(new_n108_), .B(p4), .C(p1), .Y(new_n109_));
  AND3x1_ASAP7_75t_R   g76(.A(new_n67_), .B(new_n107_), .C(new_n109_), .Y(o22));
  assign               o23 = 1'b1;
  AND2x2_ASAP7_75t_R   g77(.A(p0), .B(p6), .Y(new_n112_));
  OA211x2_ASAP7_75t_R  g78(.A1(new_n42_), .A2(new_n112_), .B(p3), .C(new_n81_), .Y(o24));
  AND3x1_ASAP7_75t_R   g79(.A(new_n62_), .B(p6), .C(new_n52_), .Y(o25));
endmodule


