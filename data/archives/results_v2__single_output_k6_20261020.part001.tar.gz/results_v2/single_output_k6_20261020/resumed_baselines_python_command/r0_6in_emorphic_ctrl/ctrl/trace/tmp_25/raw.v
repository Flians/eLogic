// Benchmark "/tmp/" written by ABC on Tue Oct 20 17:33:02 2026

module \/tmp/  ( 
    p2, p5, p3, p0, p4, p6, p1,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25  );
  input  p2, p5, p3, p0, p4, p6, p1;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25;
  wire new_n34_, new_n35_, new_n36_, new_n37_, new_n38_, new_n39_, new_n40_,
    new_n42_, new_n43_, new_n44_, new_n45_, new_n46_, new_n47_, new_n48_,
    new_n49_, new_n51_, new_n52_, new_n53_, new_n54_, new_n56_, new_n58_,
    new_n59_, new_n60_, new_n61_, new_n62_, new_n63_, new_n64_, new_n65_,
    new_n67_, new_n68_, new_n69_, new_n71_, new_n72_, new_n73_, new_n75_,
    new_n76_, new_n78_, new_n80_, new_n82_, new_n83_, new_n84_, new_n87_,
    new_n88_, new_n89_, new_n93_, new_n95_, new_n97_, new_n101_, new_n102_,
    new_n103_, new_n105_, new_n106_, new_n108_, new_n109_, new_n110_,
    new_n111_, new_n114_;
  INVx1_ASAP7_75t_R    g00(.A(p6), .Y(new_n34_));
  NOR2x1_ASAP7_75t_R   g01(.A(p0), .B(p1), .Y(new_n35_));
  NAND2x1_ASAP7_75t_R  g02(.A(p2), .B(p3), .Y(new_n36_));
  AO21x1_ASAP7_75t_R   g03(.A1(new_n34_), .A2(new_n35_), .B(new_n36_), .Y(new_n37_));
  INVx1_ASAP7_75t_R    g04(.A(p0), .Y(new_n38_));
  INVx1_ASAP7_75t_R    g05(.A(p1), .Y(new_n39_));
  OR4x2_ASAP7_75t_R    g06(.A(new_n38_), .B(new_n39_), .C(p2), .D(p3), .Y(new_n40_));
  NAND2x1_ASAP7_75t_R  g07(.A(new_n37_), .B(new_n40_), .Y(o0));
  INVx1_ASAP7_75t_R    g08(.A(p2), .Y(new_n42_));
  INVx1_ASAP7_75t_R    g09(.A(p3), .Y(new_n43_));
  OR3x1_ASAP7_75t_R    g10(.A(new_n42_), .B(new_n43_), .C(p6), .Y(new_n44_));
  NOR2x1_ASAP7_75t_R   g11(.A(p2), .B(p3), .Y(new_n45_));
  AOI21x1_ASAP7_75t_R  g12(.A1(p0), .A2(new_n45_), .B(new_n39_), .Y(new_n46_));
  NAND2x1_ASAP7_75t_R  g13(.A(p0), .B(new_n39_), .Y(new_n47_));
  NOR2x1_ASAP7_75t_R   g14(.A(p2), .B(new_n43_), .Y(new_n48_));
  NOR2x1_ASAP7_75t_R   g15(.A(new_n47_), .B(new_n48_), .Y(new_n49_));
  AOI211x1_ASAP7_75t_R g16(.A1(new_n35_), .A2(new_n44_), .B(new_n46_), .C(new_n49_), .Y(o1));
  NOR2x1_ASAP7_75t_R   g17(.A(p3), .B(new_n42_), .Y(new_n51_));
  NOR2x1_ASAP7_75t_R   g18(.A(new_n38_), .B(new_n51_), .Y(new_n52_));
  OR3x1_ASAP7_75t_R    g19(.A(new_n43_), .B(p2), .C(p6), .Y(new_n53_));
  OR3x1_ASAP7_75t_R    g20(.A(new_n36_), .B(p6), .C(p1), .Y(new_n54_));
  AOI22x1_ASAP7_75t_R  g21(.A1(new_n52_), .A2(new_n53_), .B1(new_n47_), .B2(new_n54_), .Y(o2));
  INVx1_ASAP7_75t_R    g22(.A(new_n45_), .Y(new_n56_));
  OA221x2_ASAP7_75t_R  g23(.A1(new_n42_), .A2(new_n35_), .B1(new_n34_), .B2(new_n36_), .C(new_n56_), .Y(o3));
  NAND2x1_ASAP7_75t_R  g24(.A(p0), .B(p4), .Y(new_n58_));
  OA31x2_ASAP7_75t_R   g25(.A1(p6), .A2(new_n36_), .A3(new_n58_), .B1(new_n39_), .Y(new_n59_));
  AND3x1_ASAP7_75t_R   g26(.A(p2), .B(p0), .C(p6), .Y(new_n60_));
  INVx1_ASAP7_75t_R    g27(.A(p5), .Y(new_n61_));
  INVx1_ASAP7_75t_R    g28(.A(p4), .Y(new_n62_));
  OAI21x1_ASAP7_75t_R  g29(.A1(new_n61_), .A2(new_n62_), .B(p3), .Y(new_n63_));
  NAND2x1_ASAP7_75t_R  g30(.A(new_n60_), .B(new_n63_), .Y(new_n64_));
  AOI21x1_ASAP7_75t_R  g31(.A1(p6), .A2(new_n48_), .B(new_n39_), .Y(new_n65_));
  AOI21x1_ASAP7_75t_R  g32(.A1(new_n59_), .A2(new_n64_), .B(new_n65_), .Y(o4));
  NAND2x1_ASAP7_75t_R  g33(.A(p2), .B(new_n43_), .Y(new_n67_));
  AOI21x1_ASAP7_75t_R  g34(.A1(p2), .A2(p5), .B(p1), .Y(new_n68_));
  NOR2x1_ASAP7_75t_R   g35(.A(new_n39_), .B(new_n48_), .Y(new_n69_));
  AOI211x1_ASAP7_75t_R g36(.A1(new_n67_), .A2(new_n68_), .B(new_n38_), .C(new_n69_), .Y(o5));
  NOR2x1_ASAP7_75t_R   g37(.A(p1), .B(new_n45_), .Y(new_n71_));
  AOI21x1_ASAP7_75t_R  g38(.A1(p0), .A2(p6), .B(p1), .Y(new_n72_));
  NOR2x1_ASAP7_75t_R   g39(.A(new_n36_), .B(new_n72_), .Y(new_n73_));
  AO21x1_ASAP7_75t_R   g40(.A1(new_n36_), .A2(new_n71_), .B(new_n73_), .Y(o6));
  OR5x1_ASAP7_75t_R    g41(.A(new_n42_), .B(new_n43_), .C(p0), .D(p6), .E(p1), .Y(new_n75_));
  OR3x1_ASAP7_75t_R    g42(.A(new_n36_), .B(new_n34_), .C(new_n39_), .Y(new_n76_));
  NAND3x1_ASAP7_75t_R  g43(.A(new_n40_), .B(new_n75_), .C(new_n76_), .Y(o7));
  AND2x2_ASAP7_75t_R   g44(.A(p1), .B(new_n36_), .Y(new_n78_));
  AOI221x1_ASAP7_75t_R g45(.A1(new_n53_), .A2(new_n39_), .B1(new_n78_), .B2(new_n56_), .C(new_n38_), .Y(o8));
  INVx1_ASAP7_75t_R    g46(.A(new_n47_), .Y(new_n80_));
  AOI221x1_ASAP7_75t_R g47(.A1(new_n38_), .A2(new_n36_), .B1(new_n80_), .B2(new_n53_), .C(new_n46_), .Y(o9));
  NOR2x1_ASAP7_75t_R   g48(.A(p2), .B(p1), .Y(new_n82_));
  AO21x1_ASAP7_75t_R   g49(.A1(p3), .A2(new_n35_), .B(new_n82_), .Y(new_n83_));
  OAI21x1_ASAP7_75t_R  g50(.A1(new_n38_), .A2(p6), .B(new_n48_), .Y(new_n84_));
  OAI21x1_ASAP7_75t_R  g51(.A1(new_n83_), .A2(new_n69_), .B(new_n84_), .Y(o10));
  AND3x1_ASAP7_75t_R   g52(.A(new_n45_), .B(new_n35_), .C(new_n34_), .Y(o11));
  NOR2x1_ASAP7_75t_R   g53(.A(p3), .B(p0), .Y(new_n87_));
  INVx1_ASAP7_75t_R    g54(.A(new_n87_), .Y(new_n88_));
  OR3x1_ASAP7_75t_R    g55(.A(p2), .B(p0), .C(p6), .Y(new_n89_));
  AO32x1_ASAP7_75t_R   g56(.A1(p1), .A2(new_n67_), .A3(new_n88_), .B1(new_n71_), .B2(new_n89_), .Y(o12));
  AND3x1_ASAP7_75t_R   g57(.A(new_n45_), .B(p6), .C(p1), .Y(o13));
  AND3x1_ASAP7_75t_R   g58(.A(new_n45_), .B(new_n34_), .C(p1), .Y(o14));
  NOR2x1_ASAP7_75t_R   g59(.A(p0), .B(p6), .Y(new_n93_));
  AND3x1_ASAP7_75t_R   g60(.A(new_n51_), .B(p1), .C(new_n93_), .Y(o15));
  AND2x2_ASAP7_75t_R   g61(.A(p2), .B(p6), .Y(new_n95_));
  AND3x1_ASAP7_75t_R   g62(.A(new_n95_), .B(p1), .C(new_n87_), .Y(o16));
  AND3x1_ASAP7_75t_R   g63(.A(p0), .B(p6), .C(p1), .Y(new_n97_));
  AND3x1_ASAP7_75t_R   g64(.A(new_n97_), .B(p2), .C(new_n43_), .Y(o17));
  AND5x1_ASAP7_75t_R   g65(.A(p2), .B(new_n43_), .C(new_n34_), .D(p0), .E(p1), .Y(o18));
  AND3x1_ASAP7_75t_R   g66(.A(new_n42_), .B(new_n43_), .C(p1), .Y(o19));
  OAI21x1_ASAP7_75t_R  g67(.A1(new_n43_), .A2(p4), .B(new_n60_), .Y(new_n101_));
  AOI21x1_ASAP7_75t_R  g68(.A1(new_n87_), .A2(new_n95_), .B(p1), .Y(new_n102_));
  AO21x1_ASAP7_75t_R   g69(.A1(p1), .A2(new_n36_), .B(new_n97_), .Y(new_n103_));
  AOI21x1_ASAP7_75t_R  g70(.A1(new_n101_), .A2(new_n102_), .B(new_n103_), .Y(o20));
  NAND2x1_ASAP7_75t_R  g71(.A(new_n87_), .B(new_n95_), .Y(new_n105_));
  OR5x1_ASAP7_75t_R    g72(.A(new_n42_), .B(new_n58_), .C(p5), .D(new_n43_), .E(new_n34_), .Y(new_n106_));
  AOI21x1_ASAP7_75t_R  g73(.A1(new_n105_), .A2(new_n106_), .B(p1), .Y(o21));
  NAND2x1_ASAP7_75t_R  g74(.A(new_n68_), .B(new_n67_), .Y(new_n108_));
  AOI211x1_ASAP7_75t_R g75(.A1(p1), .A2(new_n36_), .B(new_n72_), .C(new_n97_), .Y(new_n109_));
  NAND2x1_ASAP7_75t_R  g76(.A(p5), .B(p3), .Y(new_n110_));
  OR3x1_ASAP7_75t_R    g77(.A(new_n110_), .B(p4), .C(p1), .Y(new_n111_));
  AND3x1_ASAP7_75t_R   g78(.A(new_n108_), .B(new_n109_), .C(new_n111_), .Y(o22));
  assign               o23 = 1'b1;
  AND2x2_ASAP7_75t_R   g79(.A(p0), .B(p6), .Y(new_n114_));
  OA211x2_ASAP7_75t_R  g80(.A1(new_n93_), .A2(new_n114_), .B(p3), .C(new_n82_), .Y(o24));
  AND3x1_ASAP7_75t_R   g81(.A(new_n48_), .B(p6), .C(new_n35_), .Y(o25));
endmodule


