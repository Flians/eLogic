// Benchmark "/tmp/" written by ABC on Tue Oct 20 17:33:00 2026

module \/tmp/  ( 
    p2, p1, p4, p5, p6, p0, p3,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25  );
  input  p2, p1, p4, p5, p6, p0, p3;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25;
  wire new_n34_, new_n35_, new_n36_, new_n37_, new_n39_, new_n40_, new_n41_,
    new_n42_, new_n43_, new_n44_, new_n45_, new_n47_, new_n48_, new_n49_,
    new_n50_, new_n51_, new_n52_, new_n54_, new_n55_, new_n56_, new_n58_,
    new_n59_, new_n60_, new_n61_, new_n62_, new_n63_, new_n64_, new_n65_,
    new_n66_, new_n67_, new_n69_, new_n71_, new_n72_, new_n74_, new_n76_,
    new_n79_, new_n80_, new_n81_, new_n84_, new_n85_, new_n86_, new_n90_,
    new_n92_, new_n97_, new_n98_, new_n99_, new_n100_, new_n102_,
    new_n106_;
  NOR2x1_ASAP7_75t_R   g00(.A(p2), .B(p3), .Y(new_n34_));
  NAND2x1_ASAP7_75t_R  g01(.A(p2), .B(p3), .Y(new_n35_));
  INVx1_ASAP7_75t_R    g02(.A(new_n35_), .Y(new_n36_));
  OR3x1_ASAP7_75t_R    g03(.A(p1), .B(p6), .C(p0), .Y(new_n37_));
  AO32x1_ASAP7_75t_R   g04(.A1(p1), .A2(p0), .A3(new_n34_), .B1(new_n36_), .B2(new_n37_), .Y(o0));
  NOR2x1_ASAP7_75t_R   g05(.A(p1), .B(p0), .Y(new_n39_));
  INVx1_ASAP7_75t_R    g06(.A(p0), .Y(new_n40_));
  NOR2x1_ASAP7_75t_R   g07(.A(p1), .B(new_n40_), .Y(new_n41_));
  INVx1_ASAP7_75t_R    g08(.A(p2), .Y(new_n42_));
  NAND2x1_ASAP7_75t_R  g09(.A(p3), .B(new_n42_), .Y(new_n43_));
  INVx1_ASAP7_75t_R    g10(.A(p1), .Y(new_n44_));
  OAI22x1_ASAP7_75t_R  g11(.A1(new_n36_), .A2(p0), .B1(new_n44_), .B2(new_n34_), .Y(new_n45_));
  AOI221x1_ASAP7_75t_R g12(.A1(p6), .A2(new_n39_), .B1(new_n41_), .B2(new_n43_), .C(new_n45_), .Y(o1));
  INVx1_ASAP7_75t_R    g13(.A(p3), .Y(new_n47_));
  NAND2x1_ASAP7_75t_R  g14(.A(p2), .B(new_n47_), .Y(new_n48_));
  AND2x2_ASAP7_75t_R   g15(.A(p0), .B(new_n48_), .Y(new_n49_));
  OR3x1_ASAP7_75t_R    g16(.A(new_n47_), .B(p2), .C(p6), .Y(new_n50_));
  INVx1_ASAP7_75t_R    g17(.A(new_n41_), .Y(new_n51_));
  OR3x1_ASAP7_75t_R    g18(.A(new_n35_), .B(p1), .C(p6), .Y(new_n52_));
  AOI22x1_ASAP7_75t_R  g19(.A1(new_n49_), .A2(new_n50_), .B1(new_n51_), .B2(new_n52_), .Y(o2));
  INVx1_ASAP7_75t_R    g20(.A(p6), .Y(new_n54_));
  AO21x1_ASAP7_75t_R   g21(.A1(new_n44_), .A2(new_n40_), .B(new_n42_), .Y(new_n55_));
  INVx1_ASAP7_75t_R    g22(.A(new_n34_), .Y(new_n56_));
  OA211x2_ASAP7_75t_R  g23(.A1(new_n54_), .A2(new_n35_), .B(new_n55_), .C(new_n56_), .Y(o3));
  AND3x1_ASAP7_75t_R   g24(.A(p2), .B(p4), .C(p3), .Y(new_n58_));
  NOR2x1_ASAP7_75t_R   g25(.A(p6), .B(new_n40_), .Y(new_n59_));
  AOI21x1_ASAP7_75t_R  g26(.A1(new_n58_), .A2(new_n59_), .B(p1), .Y(new_n60_));
  INVx1_ASAP7_75t_R    g27(.A(p5), .Y(new_n61_));
  AOI21x1_ASAP7_75t_R  g28(.A1(p3), .A2(new_n61_), .B(new_n42_), .Y(new_n62_));
  INVx1_ASAP7_75t_R    g29(.A(p4), .Y(new_n63_));
  NAND3x1_ASAP7_75t_R  g30(.A(new_n63_), .B(p5), .C(p3), .Y(new_n64_));
  AND2x2_ASAP7_75t_R   g31(.A(p6), .B(p0), .Y(new_n65_));
  NAND3x1_ASAP7_75t_R  g32(.A(new_n62_), .B(new_n64_), .C(new_n65_), .Y(new_n66_));
  OA21x2_ASAP7_75t_R   g33(.A1(new_n54_), .A2(new_n43_), .B(p1), .Y(new_n67_));
  AOI21x1_ASAP7_75t_R  g34(.A1(new_n60_), .A2(new_n66_), .B(new_n67_), .Y(o4));
  AO21x1_ASAP7_75t_R   g35(.A1(p3), .A2(new_n42_), .B(new_n44_), .Y(new_n69_));
  OA211x2_ASAP7_75t_R  g36(.A1(p1), .A2(new_n62_), .B(new_n69_), .C(p0), .Y(o5));
  NOR2x1_ASAP7_75t_R   g37(.A(p1), .B(new_n34_), .Y(new_n71_));
  OR3x1_ASAP7_75t_R    g38(.A(new_n65_), .B(p1), .C(new_n35_), .Y(new_n72_));
  OA21x2_ASAP7_75t_R   g39(.A1(new_n36_), .A2(new_n71_), .B(new_n72_), .Y(o6));
  OAI21x1_ASAP7_75t_R  g40(.A1(new_n44_), .A2(new_n54_), .B(new_n37_), .Y(new_n74_));
  AO32x1_ASAP7_75t_R   g41(.A1(p1), .A2(p0), .A3(new_n34_), .B1(new_n74_), .B2(new_n36_), .Y(o7));
  AND2x2_ASAP7_75t_R   g42(.A(p1), .B(new_n35_), .Y(new_n76_));
  AOI221x1_ASAP7_75t_R g43(.A1(new_n50_), .A2(new_n44_), .B1(new_n76_), .B2(new_n56_), .C(new_n40_), .Y(o8));
  AOI21x1_ASAP7_75t_R  g44(.A1(new_n41_), .A2(new_n50_), .B(new_n45_), .Y(o9));
  NOR2x1_ASAP7_75t_R   g45(.A(p2), .B(p1), .Y(new_n79_));
  AOI21x1_ASAP7_75t_R  g46(.A1(p3), .A2(new_n39_), .B(new_n79_), .Y(new_n80_));
  NOR2x1_ASAP7_75t_R   g47(.A(new_n43_), .B(new_n59_), .Y(new_n81_));
  AO21x1_ASAP7_75t_R   g48(.A1(new_n69_), .A2(new_n80_), .B(new_n81_), .Y(o10));
  AND3x1_ASAP7_75t_R   g49(.A(new_n34_), .B(new_n39_), .C(new_n54_), .Y(o11));
  NOR2x1_ASAP7_75t_R   g50(.A(p0), .B(p3), .Y(new_n84_));
  INVx1_ASAP7_75t_R    g51(.A(new_n84_), .Y(new_n85_));
  OR3x1_ASAP7_75t_R    g52(.A(p2), .B(p6), .C(p0), .Y(new_n86_));
  AO32x1_ASAP7_75t_R   g53(.A1(p1), .A2(new_n48_), .A3(new_n85_), .B1(new_n71_), .B2(new_n86_), .Y(o12));
  AND3x1_ASAP7_75t_R   g54(.A(new_n34_), .B(p1), .C(p6), .Y(o13));
  AND3x1_ASAP7_75t_R   g55(.A(new_n34_), .B(p1), .C(new_n54_), .Y(o14));
  AND3x1_ASAP7_75t_R   g56(.A(new_n40_), .B(new_n47_), .C(p2), .Y(new_n90_));
  AND3x1_ASAP7_75t_R   g57(.A(new_n90_), .B(p1), .C(new_n54_), .Y(o15));
  AND2x2_ASAP7_75t_R   g58(.A(p2), .B(p6), .Y(new_n92_));
  AND3x1_ASAP7_75t_R   g59(.A(new_n92_), .B(p1), .C(new_n84_), .Y(o16));
  AND5x1_ASAP7_75t_R   g60(.A(p2), .B(new_n47_), .C(p1), .D(p6), .E(p0), .Y(o17));
  AND5x1_ASAP7_75t_R   g61(.A(p2), .B(new_n54_), .C(new_n47_), .D(p1), .E(p0), .Y(o18));
  AND3x1_ASAP7_75t_R   g62(.A(new_n42_), .B(new_n47_), .C(p1), .Y(o19));
  AND3x1_ASAP7_75t_R   g63(.A(p2), .B(p6), .C(p0), .Y(new_n97_));
  OAI21x1_ASAP7_75t_R  g64(.A1(p4), .A2(new_n47_), .B(new_n97_), .Y(new_n98_));
  AOI21x1_ASAP7_75t_R  g65(.A1(new_n84_), .A2(new_n92_), .B(p1), .Y(new_n99_));
  OA21x2_ASAP7_75t_R   g66(.A1(new_n35_), .A2(new_n65_), .B(p1), .Y(new_n100_));
  AOI21x1_ASAP7_75t_R  g67(.A1(new_n98_), .A2(new_n99_), .B(new_n100_), .Y(o20));
  AND5x1_ASAP7_75t_R   g68(.A(p2), .B(new_n61_), .C(p4), .D(p0), .E(p3), .Y(new_n102_));
  OA211x2_ASAP7_75t_R  g69(.A1(new_n90_), .A2(new_n102_), .B(new_n44_), .C(p6), .Y(o21));
  AOI21x1_ASAP7_75t_R  g70(.A1(new_n44_), .A2(new_n66_), .B(new_n100_), .Y(o22));
  assign               o23 = 1'b1;
  NOR2x1_ASAP7_75t_R   g71(.A(p6), .B(p0), .Y(new_n106_));
  OA211x2_ASAP7_75t_R  g72(.A1(new_n106_), .A2(new_n65_), .B(p3), .C(new_n79_), .Y(o24));
  AND5x1_ASAP7_75t_R   g73(.A(new_n42_), .B(new_n44_), .C(new_n40_), .D(p6), .E(p3), .Y(o25));
endmodule


