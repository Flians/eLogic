// Benchmark "/tmp/" written by ABC on Tue Oct 20 17:33:00 2026

module \/tmp/  ( 
    p3, p5, p6, p0, p2, p1, p4,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25  );
  input  p3, p5, p6, p0, p2, p1, p4;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25;
  wire new_n34_, new_n35_, new_n36_, new_n37_, new_n38_, new_n39_, new_n41_,
    new_n42_, new_n43_, new_n44_, new_n45_, new_n46_, new_n47_, new_n48_,
    new_n50_, new_n51_, new_n53_, new_n54_, new_n56_, new_n57_, new_n58_,
    new_n59_, new_n60_, new_n61_, new_n62_, new_n64_, new_n65_, new_n66_,
    new_n68_, new_n69_, new_n70_, new_n72_, new_n73_, new_n74_, new_n77_,
    new_n80_, new_n81_, new_n84_, new_n85_, new_n86_, new_n87_, new_n91_,
    new_n93_, new_n95_, new_n98_, new_n99_, new_n100_, new_n102_,
    new_n104_, new_n105_, new_n106_, new_n109_;
  INVx1_ASAP7_75t_R    g00(.A(p1), .Y(new_n34_));
  NOR2x1_ASAP7_75t_R   g01(.A(p6), .B(p0), .Y(new_n35_));
  NAND2x1_ASAP7_75t_R  g02(.A(p3), .B(p2), .Y(new_n36_));
  AO21x1_ASAP7_75t_R   g03(.A1(new_n34_), .A2(new_n35_), .B(new_n36_), .Y(new_n37_));
  INVx1_ASAP7_75t_R    g04(.A(p0), .Y(new_n38_));
  OR4x2_ASAP7_75t_R    g05(.A(new_n38_), .B(new_n34_), .C(p3), .D(p2), .Y(new_n39_));
  NAND2x1_ASAP7_75t_R  g06(.A(new_n37_), .B(new_n39_), .Y(o0));
  INVx1_ASAP7_75t_R    g07(.A(p2), .Y(new_n41_));
  NAND2x1_ASAP7_75t_R  g08(.A(p3), .B(new_n41_), .Y(new_n42_));
  NOR2x1_ASAP7_75t_R   g09(.A(p1), .B(new_n38_), .Y(new_n43_));
  INVx1_ASAP7_75t_R    g10(.A(p3), .Y(new_n44_));
  OR3x1_ASAP7_75t_R    g11(.A(new_n44_), .B(new_n41_), .C(p6), .Y(new_n45_));
  NOR2x1_ASAP7_75t_R   g12(.A(p0), .B(p1), .Y(new_n46_));
  NOR2x1_ASAP7_75t_R   g13(.A(p3), .B(p2), .Y(new_n47_));
  AOI21x1_ASAP7_75t_R  g14(.A1(p0), .A2(new_n47_), .B(new_n34_), .Y(new_n48_));
  AOI221x1_ASAP7_75t_R g15(.A1(new_n42_), .A2(new_n43_), .B1(new_n45_), .B2(new_n46_), .C(new_n48_), .Y(o1));
  OA21x2_ASAP7_75t_R   g16(.A1(p3), .A2(new_n41_), .B(p0), .Y(new_n50_));
  OR3x1_ASAP7_75t_R    g17(.A(new_n44_), .B(p6), .C(p2), .Y(new_n51_));
  AOI221x1_ASAP7_75t_R g18(.A1(new_n50_), .A2(new_n51_), .B1(new_n38_), .B2(new_n45_), .C(p1), .Y(o2));
  INVx1_ASAP7_75t_R    g19(.A(p6), .Y(new_n53_));
  INVx1_ASAP7_75t_R    g20(.A(new_n47_), .Y(new_n54_));
  OA221x2_ASAP7_75t_R  g21(.A1(new_n53_), .A2(new_n36_), .B1(new_n41_), .B2(new_n46_), .C(new_n54_), .Y(o3));
  AND2x2_ASAP7_75t_R   g22(.A(p5), .B(p4), .Y(new_n56_));
  AND3x1_ASAP7_75t_R   g23(.A(p6), .B(p0), .C(p2), .Y(new_n57_));
  OAI21x1_ASAP7_75t_R  g24(.A1(new_n44_), .A2(new_n56_), .B(new_n57_), .Y(new_n58_));
  NAND2x1_ASAP7_75t_R  g25(.A(p0), .B(p4), .Y(new_n59_));
  OA31x2_ASAP7_75t_R   g26(.A1(p6), .A2(new_n36_), .A3(new_n59_), .B1(new_n34_), .Y(new_n60_));
  NOR2x1_ASAP7_75t_R   g27(.A(p2), .B(new_n44_), .Y(new_n61_));
  AOI21x1_ASAP7_75t_R  g28(.A1(p6), .A2(new_n61_), .B(new_n34_), .Y(new_n62_));
  AOI21x1_ASAP7_75t_R  g29(.A1(new_n58_), .A2(new_n60_), .B(new_n62_), .Y(o4));
  AO21x1_ASAP7_75t_R   g30(.A1(p3), .A2(new_n41_), .B(new_n34_), .Y(new_n64_));
  AOI21x1_ASAP7_75t_R  g31(.A1(p5), .A2(p2), .B(p1), .Y(new_n65_));
  OAI21x1_ASAP7_75t_R  g32(.A1(p3), .A2(new_n41_), .B(new_n65_), .Y(new_n66_));
  AND3x1_ASAP7_75t_R   g33(.A(new_n64_), .B(new_n66_), .C(p0), .Y(o5));
  NOR2x1_ASAP7_75t_R   g34(.A(p1), .B(new_n47_), .Y(new_n68_));
  AOI21x1_ASAP7_75t_R  g35(.A1(p6), .A2(p0), .B(p1), .Y(new_n69_));
  NOR2x1_ASAP7_75t_R   g36(.A(new_n36_), .B(new_n69_), .Y(new_n70_));
  AO21x1_ASAP7_75t_R   g37(.A1(new_n36_), .A2(new_n68_), .B(new_n70_), .Y(o6));
  AOI21x1_ASAP7_75t_R  g38(.A1(new_n53_), .A2(p0), .B(new_n36_), .Y(new_n72_));
  NAND2x1_ASAP7_75t_R  g39(.A(p1), .B(new_n53_), .Y(new_n73_));
  NAND2x1_ASAP7_75t_R  g40(.A(p6), .B(new_n34_), .Y(new_n74_));
  AND3x1_ASAP7_75t_R   g41(.A(new_n44_), .B(new_n41_), .C(p1), .Y(o19));
  AO32x1_ASAP7_75t_R   g42(.A1(new_n72_), .A2(new_n73_), .A3(new_n74_), .B1(o19), .B2(p0), .Y(o7));
  AOI21x1_ASAP7_75t_R  g43(.A1(p3), .A2(p2), .B(new_n34_), .Y(new_n77_));
  AOI221x1_ASAP7_75t_R g44(.A1(new_n54_), .A2(new_n77_), .B1(new_n51_), .B2(new_n34_), .C(new_n38_), .Y(o8));
  AOI221x1_ASAP7_75t_R g45(.A1(new_n38_), .A2(new_n36_), .B1(new_n51_), .B2(new_n43_), .C(new_n48_), .Y(o9));
  AO21x1_ASAP7_75t_R   g46(.A1(p3), .A2(new_n38_), .B(new_n41_), .Y(new_n80_));
  AND3x1_ASAP7_75t_R   g47(.A(new_n53_), .B(new_n34_), .C(p0), .Y(new_n81_));
  OAI22x1_ASAP7_75t_R  g48(.A1(new_n80_), .A2(p1), .B1(new_n81_), .B2(new_n42_), .Y(o10));
  AND3x1_ASAP7_75t_R   g49(.A(new_n47_), .B(new_n46_), .C(new_n53_), .Y(o11));
  NOR2x1_ASAP7_75t_R   g50(.A(p3), .B(p0), .Y(new_n84_));
  INVx1_ASAP7_75t_R    g51(.A(new_n84_), .Y(new_n85_));
  NAND2x1_ASAP7_75t_R  g52(.A(p2), .B(new_n44_), .Y(new_n86_));
  OR3x1_ASAP7_75t_R    g53(.A(p6), .B(p0), .C(p2), .Y(new_n87_));
  AO32x1_ASAP7_75t_R   g54(.A1(p1), .A2(new_n85_), .A3(new_n86_), .B1(new_n68_), .B2(new_n87_), .Y(o12));
  AND3x1_ASAP7_75t_R   g55(.A(new_n47_), .B(p6), .C(p1), .Y(o13));
  AND3x1_ASAP7_75t_R   g56(.A(new_n47_), .B(new_n53_), .C(p1), .Y(o14));
  NAND2x1_ASAP7_75t_R  g57(.A(p2), .B(new_n84_), .Y(new_n91_));
  NOR2x1_ASAP7_75t_R   g58(.A(new_n73_), .B(new_n91_), .Y(o15));
  AND2x2_ASAP7_75t_R   g59(.A(p6), .B(p2), .Y(new_n93_));
  AND3x1_ASAP7_75t_R   g60(.A(new_n93_), .B(p1), .C(new_n84_), .Y(o16));
  AND3x1_ASAP7_75t_R   g61(.A(p6), .B(p0), .C(p1), .Y(new_n95_));
  AND3x1_ASAP7_75t_R   g62(.A(new_n95_), .B(new_n44_), .C(p2), .Y(o17));
  AND5x1_ASAP7_75t_R   g63(.A(new_n44_), .B(new_n53_), .C(p0), .D(p2), .E(p1), .Y(o18));
  OAI21x1_ASAP7_75t_R  g64(.A1(new_n44_), .A2(p4), .B(new_n57_), .Y(new_n98_));
  AOI21x1_ASAP7_75t_R  g65(.A1(new_n84_), .A2(new_n93_), .B(p1), .Y(new_n99_));
  AO21x1_ASAP7_75t_R   g66(.A1(p1), .A2(new_n36_), .B(new_n95_), .Y(new_n100_));
  AOI21x1_ASAP7_75t_R  g67(.A1(new_n98_), .A2(new_n99_), .B(new_n100_), .Y(o20));
  OR4x2_ASAP7_75t_R    g68(.A(new_n59_), .B(new_n44_), .C(p5), .D(new_n41_), .Y(new_n102_));
  AOI21x1_ASAP7_75t_R  g69(.A1(new_n91_), .A2(new_n102_), .B(new_n74_), .Y(o21));
  AOI211x1_ASAP7_75t_R g70(.A1(p1), .A2(new_n36_), .B(new_n69_), .C(new_n95_), .Y(new_n104_));
  NAND2x1_ASAP7_75t_R  g71(.A(p3), .B(p5), .Y(new_n105_));
  OR3x1_ASAP7_75t_R    g72(.A(new_n105_), .B(p1), .C(p4), .Y(new_n106_));
  AND3x1_ASAP7_75t_R   g73(.A(new_n104_), .B(new_n66_), .C(new_n106_), .Y(o22));
  assign               o23 = 1'b1;
  AND2x2_ASAP7_75t_R   g74(.A(p6), .B(p0), .Y(new_n109_));
  OA211x2_ASAP7_75t_R  g75(.A1(new_n35_), .A2(new_n109_), .B(new_n61_), .C(new_n34_), .Y(o24));
  AND3x1_ASAP7_75t_R   g76(.A(new_n61_), .B(p6), .C(new_n46_), .Y(o25));
endmodule


