// Benchmark "/tmp/" written by ABC on Tue Oct 20 17:33:03 2026

module \/tmp/  ( 
    p3, p2, p5, p1, p0, p6, p4,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25  );
  input  p3, p2, p5, p1, p0, p6, p4;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25;
  wire new_n34_, new_n35_, new_n36_, new_n37_, new_n38_, new_n39_, new_n41_,
    new_n43_, new_n44_, new_n45_, new_n46_, new_n47_, new_n48_, new_n49_,
    new_n50_, new_n52_, new_n53_, new_n54_, new_n55_, new_n56_, new_n58_,
    new_n60_, new_n61_, new_n62_, new_n63_, new_n64_, new_n65_, new_n66_,
    new_n67_, new_n68_, new_n70_, new_n71_, new_n72_, new_n74_, new_n75_,
    new_n76_, new_n78_, new_n79_, new_n81_, new_n84_, new_n85_, new_n88_,
    new_n89_, new_n90_, new_n94_, new_n97_, new_n100_, new_n101_,
    new_n102_, new_n103_, new_n105_, new_n106_, new_n107_, new_n109_,
    new_n110_, new_n111_, new_n112_, new_n115_;
  INVx1_ASAP7_75t_R    g00(.A(p6), .Y(new_n34_));
  NOR2x1_ASAP7_75t_R   g01(.A(p1), .B(p0), .Y(new_n35_));
  NAND2x1_ASAP7_75t_R  g02(.A(p3), .B(p2), .Y(new_n36_));
  AO21x1_ASAP7_75t_R   g03(.A1(new_n34_), .A2(new_n35_), .B(new_n36_), .Y(new_n37_));
  INVx1_ASAP7_75t_R    g04(.A(p3), .Y(new_n38_));
  INVx1_ASAP7_75t_R    g05(.A(p2), .Y(new_n39_));
  AND3x1_ASAP7_75t_R   g06(.A(new_n38_), .B(new_n39_), .C(p1), .Y(o19));
  NAND2x1_ASAP7_75t_R  g07(.A(p0), .B(o19), .Y(new_n41_));
  NAND2x1_ASAP7_75t_R  g08(.A(new_n37_), .B(new_n41_), .Y(o0));
  NOR2x1_ASAP7_75t_R   g09(.A(p2), .B(new_n38_), .Y(new_n43_));
  INVx1_ASAP7_75t_R    g10(.A(new_n43_), .Y(new_n44_));
  INVx1_ASAP7_75t_R    g11(.A(p0), .Y(new_n45_));
  NOR2x1_ASAP7_75t_R   g12(.A(p1), .B(new_n45_), .Y(new_n46_));
  AND2x2_ASAP7_75t_R   g13(.A(p3), .B(p2), .Y(new_n47_));
  INVx1_ASAP7_75t_R    g14(.A(p1), .Y(new_n48_));
  NOR2x1_ASAP7_75t_R   g15(.A(p3), .B(p2), .Y(new_n49_));
  OAI22x1_ASAP7_75t_R  g16(.A1(new_n47_), .A2(p0), .B1(new_n48_), .B2(new_n49_), .Y(new_n50_));
  AOI221x1_ASAP7_75t_R g17(.A1(p6), .A2(new_n35_), .B1(new_n44_), .B2(new_n46_), .C(new_n50_), .Y(o1));
  NOR2x1_ASAP7_75t_R   g18(.A(p3), .B(new_n39_), .Y(new_n52_));
  NOR2x1_ASAP7_75t_R   g19(.A(new_n45_), .B(new_n52_), .Y(new_n53_));
  OR3x1_ASAP7_75t_R    g20(.A(new_n38_), .B(p2), .C(p6), .Y(new_n54_));
  INVx1_ASAP7_75t_R    g21(.A(new_n46_), .Y(new_n55_));
  OR3x1_ASAP7_75t_R    g22(.A(new_n36_), .B(p1), .C(p6), .Y(new_n56_));
  AOI22x1_ASAP7_75t_R  g23(.A1(new_n53_), .A2(new_n54_), .B1(new_n55_), .B2(new_n56_), .Y(o2));
  NAND2x1_ASAP7_75t_R  g24(.A(p2), .B(new_n35_), .Y(new_n58_));
  AOI22x1_ASAP7_75t_R  g25(.A1(new_n44_), .A2(new_n58_), .B1(p6), .B2(new_n47_), .Y(o3));
  AND3x1_ASAP7_75t_R   g26(.A(p2), .B(p0), .C(p6), .Y(new_n60_));
  INVx1_ASAP7_75t_R    g27(.A(p5), .Y(new_n61_));
  INVx1_ASAP7_75t_R    g28(.A(p4), .Y(new_n62_));
  OAI21x1_ASAP7_75t_R  g29(.A1(new_n61_), .A2(new_n62_), .B(p3), .Y(new_n63_));
  NAND2x1_ASAP7_75t_R  g30(.A(new_n60_), .B(new_n63_), .Y(new_n64_));
  AND3x1_ASAP7_75t_R   g31(.A(p3), .B(p2), .C(p4), .Y(new_n65_));
  NOR2x1_ASAP7_75t_R   g32(.A(p6), .B(new_n45_), .Y(new_n66_));
  AOI21x1_ASAP7_75t_R  g33(.A1(new_n65_), .A2(new_n66_), .B(p1), .Y(new_n67_));
  AOI21x1_ASAP7_75t_R  g34(.A1(p6), .A2(new_n43_), .B(new_n48_), .Y(new_n68_));
  AOI21x1_ASAP7_75t_R  g35(.A1(new_n64_), .A2(new_n67_), .B(new_n68_), .Y(o4));
  NAND2x1_ASAP7_75t_R  g36(.A(p2), .B(new_n38_), .Y(new_n70_));
  AOI21x1_ASAP7_75t_R  g37(.A1(p2), .A2(p5), .B(p1), .Y(new_n71_));
  NOR2x1_ASAP7_75t_R   g38(.A(new_n48_), .B(new_n43_), .Y(new_n72_));
  AOI211x1_ASAP7_75t_R g39(.A1(new_n70_), .A2(new_n71_), .B(new_n45_), .C(new_n72_), .Y(o5));
  NOR2x1_ASAP7_75t_R   g40(.A(p1), .B(new_n49_), .Y(new_n74_));
  AOI21x1_ASAP7_75t_R  g41(.A1(p0), .A2(p6), .B(p1), .Y(new_n75_));
  NOR2x1_ASAP7_75t_R   g42(.A(new_n36_), .B(new_n75_), .Y(new_n76_));
  AO21x1_ASAP7_75t_R   g43(.A1(new_n36_), .A2(new_n74_), .B(new_n76_), .Y(o6));
  AND2x2_ASAP7_75t_R   g44(.A(p1), .B(p6), .Y(new_n78_));
  AOI21x1_ASAP7_75t_R  g45(.A1(new_n34_), .A2(new_n35_), .B(new_n78_), .Y(new_n79_));
  OAI21x1_ASAP7_75t_R  g46(.A1(new_n36_), .A2(new_n79_), .B(new_n41_), .Y(o7));
  NOR2x1_ASAP7_75t_R   g47(.A(new_n48_), .B(new_n49_), .Y(new_n81_));
  AOI221x1_ASAP7_75t_R g48(.A1(new_n36_), .A2(new_n81_), .B1(new_n54_), .B2(new_n48_), .C(new_n45_), .Y(o8));
  AOI21x1_ASAP7_75t_R  g49(.A1(new_n54_), .A2(new_n46_), .B(new_n50_), .Y(o9));
  NOR2x1_ASAP7_75t_R   g50(.A(p2), .B(p1), .Y(new_n84_));
  AO21x1_ASAP7_75t_R   g51(.A1(p3), .A2(new_n35_), .B(new_n84_), .Y(new_n85_));
  OAI22x1_ASAP7_75t_R  g52(.A1(new_n72_), .A2(new_n85_), .B1(new_n44_), .B2(new_n66_), .Y(o10));
  AND3x1_ASAP7_75t_R   g53(.A(new_n35_), .B(new_n49_), .C(new_n34_), .Y(o11));
  NOR2x1_ASAP7_75t_R   g54(.A(p3), .B(p0), .Y(new_n88_));
  INVx1_ASAP7_75t_R    g55(.A(new_n88_), .Y(new_n89_));
  OR3x1_ASAP7_75t_R    g56(.A(p2), .B(p0), .C(p6), .Y(new_n90_));
  AO32x1_ASAP7_75t_R   g57(.A1(p1), .A2(new_n70_), .A3(new_n89_), .B1(new_n74_), .B2(new_n90_), .Y(o12));
  AND3x1_ASAP7_75t_R   g58(.A(new_n49_), .B(p1), .C(p6), .Y(o13));
  AND3x1_ASAP7_75t_R   g59(.A(new_n49_), .B(p1), .C(new_n34_), .Y(o14));
  NOR2x1_ASAP7_75t_R   g60(.A(p0), .B(p6), .Y(new_n94_));
  AND3x1_ASAP7_75t_R   g61(.A(new_n52_), .B(p1), .C(new_n94_), .Y(o15));
  AND3x1_ASAP7_75t_R   g62(.A(new_n78_), .B(p2), .C(new_n88_), .Y(o16));
  AND3x1_ASAP7_75t_R   g63(.A(p1), .B(p0), .C(p6), .Y(new_n97_));
  AND3x1_ASAP7_75t_R   g64(.A(new_n97_), .B(new_n38_), .C(p2), .Y(o17));
  AND3x1_ASAP7_75t_R   g65(.A(new_n52_), .B(new_n66_), .C(p1), .Y(o18));
  OAI21x1_ASAP7_75t_R  g66(.A1(new_n38_), .A2(p4), .B(new_n60_), .Y(new_n100_));
  AND2x2_ASAP7_75t_R   g67(.A(p2), .B(p6), .Y(new_n101_));
  AOI21x1_ASAP7_75t_R  g68(.A1(new_n88_), .A2(new_n101_), .B(p1), .Y(new_n102_));
  AO21x1_ASAP7_75t_R   g69(.A1(p1), .A2(new_n36_), .B(new_n97_), .Y(new_n103_));
  AOI21x1_ASAP7_75t_R  g70(.A1(new_n100_), .A2(new_n102_), .B(new_n103_), .Y(o20));
  NAND2x1_ASAP7_75t_R  g71(.A(p2), .B(new_n88_), .Y(new_n105_));
  OR4x2_ASAP7_75t_R    g72(.A(new_n36_), .B(p5), .C(new_n45_), .D(new_n62_), .Y(new_n106_));
  NAND2x1_ASAP7_75t_R  g73(.A(p6), .B(new_n48_), .Y(new_n107_));
  AOI21x1_ASAP7_75t_R  g74(.A1(new_n105_), .A2(new_n106_), .B(new_n107_), .Y(o21));
  NAND2x1_ASAP7_75t_R  g75(.A(new_n71_), .B(new_n70_), .Y(new_n109_));
  AOI211x1_ASAP7_75t_R g76(.A1(p1), .A2(new_n36_), .B(new_n75_), .C(new_n97_), .Y(new_n110_));
  NAND2x1_ASAP7_75t_R  g77(.A(p3), .B(p5), .Y(new_n111_));
  OR3x1_ASAP7_75t_R    g78(.A(new_n111_), .B(p1), .C(p4), .Y(new_n112_));
  AND3x1_ASAP7_75t_R   g79(.A(new_n109_), .B(new_n110_), .C(new_n112_), .Y(o22));
  assign               o23 = 1'b1;
  AND2x2_ASAP7_75t_R   g80(.A(p0), .B(p6), .Y(new_n115_));
  OA211x2_ASAP7_75t_R  g81(.A1(new_n94_), .A2(new_n115_), .B(p3), .C(new_n84_), .Y(o24));
  AND3x1_ASAP7_75t_R   g82(.A(new_n43_), .B(p6), .C(new_n35_), .Y(o25));
endmodule


