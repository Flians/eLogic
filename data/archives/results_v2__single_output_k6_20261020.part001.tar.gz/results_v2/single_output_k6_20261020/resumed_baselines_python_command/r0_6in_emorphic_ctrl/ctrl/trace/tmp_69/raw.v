// Benchmark "/tmp/" written by ABC on Tue Oct 20 17:33:06 2026

module \/tmp/  ( 
    p0, p6, p2, p5, p4, p3, p1,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25  );
  input  p0, p6, p2, p5, p4, p3, p1;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25;
  wire new_n34_, new_n35_, new_n36_, new_n37_, new_n39_, new_n40_, new_n41_,
    new_n42_, new_n43_, new_n44_, new_n45_, new_n46_, new_n48_, new_n49_,
    new_n50_, new_n52_, new_n53_, new_n54_, new_n56_, new_n57_, new_n58_,
    new_n59_, new_n60_, new_n61_, new_n62_, new_n63_, new_n64_, new_n66_,
    new_n67_, new_n68_, new_n70_, new_n71_, new_n74_, new_n78_, new_n79_,
    new_n82_, new_n83_, new_n84_, new_n85_, new_n90_, new_n92_, new_n95_,
    new_n96_, new_n97_, new_n99_, new_n100_, new_n101_, new_n103_,
    new_n104_, new_n105_, new_n106_, new_n109_, new_n110_;
  NOR2x1_ASAP7_75t_R   g00(.A(p2), .B(p3), .Y(new_n34_));
  NAND2x1_ASAP7_75t_R  g01(.A(p2), .B(p3), .Y(new_n35_));
  INVx1_ASAP7_75t_R    g02(.A(new_n35_), .Y(new_n36_));
  OR3x1_ASAP7_75t_R    g03(.A(p0), .B(p6), .C(p1), .Y(new_n37_));
  AO32x1_ASAP7_75t_R   g04(.A1(p0), .A2(p1), .A3(new_n34_), .B1(new_n36_), .B2(new_n37_), .Y(o0));
  INVx1_ASAP7_75t_R    g05(.A(p0), .Y(new_n39_));
  NOR2x1_ASAP7_75t_R   g06(.A(p1), .B(new_n39_), .Y(new_n40_));
  INVx1_ASAP7_75t_R    g07(.A(p3), .Y(new_n41_));
  NOR2x1_ASAP7_75t_R   g08(.A(p2), .B(new_n41_), .Y(new_n42_));
  INVx1_ASAP7_75t_R    g09(.A(new_n42_), .Y(new_n43_));
  INVx1_ASAP7_75t_R    g10(.A(p1), .Y(new_n44_));
  AOI21x1_ASAP7_75t_R  g11(.A1(p0), .A2(new_n34_), .B(new_n44_), .Y(new_n45_));
  OA21x2_ASAP7_75t_R   g12(.A1(p6), .A2(new_n35_), .B(new_n39_), .Y(new_n46_));
  AOI211x1_ASAP7_75t_R g13(.A1(new_n40_), .A2(new_n43_), .B(new_n45_), .C(new_n46_), .Y(o1));
  OR3x1_ASAP7_75t_R    g14(.A(new_n41_), .B(p6), .C(p2), .Y(new_n48_));
  INVx1_ASAP7_75t_R    g15(.A(p2), .Y(new_n49_));
  OA21x2_ASAP7_75t_R   g16(.A1(p3), .A2(new_n49_), .B(p0), .Y(new_n50_));
  AOI211x1_ASAP7_75t_R g17(.A1(new_n48_), .A2(new_n50_), .B(p1), .C(new_n46_), .Y(o2));
  INVx1_ASAP7_75t_R    g18(.A(p6), .Y(new_n52_));
  NOR2x1_ASAP7_75t_R   g19(.A(p0), .B(p1), .Y(new_n53_));
  INVx1_ASAP7_75t_R    g20(.A(new_n34_), .Y(new_n54_));
  OA221x2_ASAP7_75t_R  g21(.A1(new_n52_), .A2(new_n35_), .B1(new_n49_), .B2(new_n53_), .C(new_n54_), .Y(o3));
  AND3x1_ASAP7_75t_R   g22(.A(p0), .B(p6), .C(p2), .Y(new_n56_));
  INVx1_ASAP7_75t_R    g23(.A(p5), .Y(new_n57_));
  INVx1_ASAP7_75t_R    g24(.A(p4), .Y(new_n58_));
  OAI21x1_ASAP7_75t_R  g25(.A1(new_n57_), .A2(new_n58_), .B(p3), .Y(new_n59_));
  NAND2x1_ASAP7_75t_R  g26(.A(new_n56_), .B(new_n59_), .Y(new_n60_));
  AND3x1_ASAP7_75t_R   g27(.A(p2), .B(p4), .C(p3), .Y(new_n61_));
  NOR2x1_ASAP7_75t_R   g28(.A(p6), .B(new_n39_), .Y(new_n62_));
  AOI21x1_ASAP7_75t_R  g29(.A1(new_n61_), .A2(new_n62_), .B(p1), .Y(new_n63_));
  AOI21x1_ASAP7_75t_R  g30(.A1(p6), .A2(new_n42_), .B(new_n44_), .Y(new_n64_));
  AOI21x1_ASAP7_75t_R  g31(.A1(new_n60_), .A2(new_n63_), .B(new_n64_), .Y(o4));
  NAND2x1_ASAP7_75t_R  g32(.A(p2), .B(new_n41_), .Y(new_n66_));
  AOI21x1_ASAP7_75t_R  g33(.A1(p2), .A2(p5), .B(p1), .Y(new_n67_));
  NOR2x1_ASAP7_75t_R   g34(.A(new_n44_), .B(new_n42_), .Y(new_n68_));
  AOI211x1_ASAP7_75t_R g35(.A1(new_n66_), .A2(new_n67_), .B(new_n39_), .C(new_n68_), .Y(o5));
  AOI21x1_ASAP7_75t_R  g36(.A1(p0), .A2(p6), .B(p1), .Y(new_n70_));
  AND2x2_ASAP7_75t_R   g37(.A(p1), .B(new_n35_), .Y(new_n71_));
  AOI211x1_ASAP7_75t_R g38(.A1(new_n36_), .A2(new_n70_), .B(new_n34_), .C(new_n71_), .Y(o6));
  AND3x1_ASAP7_75t_R   g39(.A(new_n49_), .B(new_n41_), .C(p1), .Y(o19));
  OAI21x1_ASAP7_75t_R  g40(.A1(new_n52_), .A2(new_n44_), .B(new_n37_), .Y(new_n74_));
  AO22x1_ASAP7_75t_R   g41(.A1(p0), .A2(o19), .B1(new_n36_), .B2(new_n74_), .Y(o7));
  AOI221x1_ASAP7_75t_R g42(.A1(new_n48_), .A2(new_n44_), .B1(new_n71_), .B2(new_n54_), .C(new_n39_), .Y(o8));
  AOI221x1_ASAP7_75t_R g43(.A1(new_n39_), .A2(new_n35_), .B1(new_n48_), .B2(new_n40_), .C(new_n45_), .Y(o9));
  NOR2x1_ASAP7_75t_R   g44(.A(p2), .B(p1), .Y(new_n78_));
  AO21x1_ASAP7_75t_R   g45(.A1(p3), .A2(new_n53_), .B(new_n78_), .Y(new_n79_));
  OAI22x1_ASAP7_75t_R  g46(.A1(new_n68_), .A2(new_n79_), .B1(new_n43_), .B2(new_n62_), .Y(o10));
  AND3x1_ASAP7_75t_R   g47(.A(new_n34_), .B(new_n53_), .C(new_n52_), .Y(o11));
  NOR2x1_ASAP7_75t_R   g48(.A(p0), .B(p3), .Y(new_n82_));
  INVx1_ASAP7_75t_R    g49(.A(new_n82_), .Y(new_n83_));
  NOR2x1_ASAP7_75t_R   g50(.A(p1), .B(new_n34_), .Y(new_n84_));
  OR3x1_ASAP7_75t_R    g51(.A(p0), .B(p6), .C(p2), .Y(new_n85_));
  AO32x1_ASAP7_75t_R   g52(.A1(p1), .A2(new_n66_), .A3(new_n83_), .B1(new_n84_), .B2(new_n85_), .Y(o12));
  AND3x1_ASAP7_75t_R   g53(.A(new_n34_), .B(p6), .C(p1), .Y(o13));
  AND3x1_ASAP7_75t_R   g54(.A(new_n34_), .B(new_n52_), .C(p1), .Y(o14));
  AND5x1_ASAP7_75t_R   g55(.A(new_n39_), .B(new_n52_), .C(new_n41_), .D(p2), .E(p1), .Y(o15));
  AND2x2_ASAP7_75t_R   g56(.A(p6), .B(p2), .Y(new_n90_));
  AND3x1_ASAP7_75t_R   g57(.A(new_n90_), .B(p1), .C(new_n82_), .Y(o16));
  AND3x1_ASAP7_75t_R   g58(.A(p0), .B(p6), .C(p1), .Y(new_n92_));
  AND3x1_ASAP7_75t_R   g59(.A(new_n92_), .B(p2), .C(new_n41_), .Y(o17));
  AND5x1_ASAP7_75t_R   g60(.A(p0), .B(new_n52_), .C(new_n41_), .D(p2), .E(p1), .Y(o18));
  OAI21x1_ASAP7_75t_R  g61(.A1(p4), .A2(new_n41_), .B(new_n56_), .Y(new_n95_));
  AOI21x1_ASAP7_75t_R  g62(.A1(new_n82_), .A2(new_n90_), .B(p1), .Y(new_n96_));
  AO21x1_ASAP7_75t_R   g63(.A1(p1), .A2(new_n35_), .B(new_n92_), .Y(new_n97_));
  AOI21x1_ASAP7_75t_R  g64(.A1(new_n95_), .A2(new_n96_), .B(new_n97_), .Y(o20));
  NAND2x1_ASAP7_75t_R  g65(.A(p2), .B(new_n82_), .Y(new_n99_));
  OR4x2_ASAP7_75t_R    g66(.A(new_n35_), .B(new_n39_), .C(p5), .D(new_n58_), .Y(new_n100_));
  NAND2x1_ASAP7_75t_R  g67(.A(p6), .B(new_n44_), .Y(new_n101_));
  AOI21x1_ASAP7_75t_R  g68(.A1(new_n99_), .A2(new_n100_), .B(new_n101_), .Y(o21));
  NAND2x1_ASAP7_75t_R  g69(.A(new_n67_), .B(new_n66_), .Y(new_n103_));
  AOI211x1_ASAP7_75t_R g70(.A1(p1), .A2(new_n35_), .B(new_n70_), .C(new_n92_), .Y(new_n104_));
  NAND2x1_ASAP7_75t_R  g71(.A(p5), .B(p3), .Y(new_n105_));
  OR3x1_ASAP7_75t_R    g72(.A(new_n105_), .B(p4), .C(p1), .Y(new_n106_));
  AND3x1_ASAP7_75t_R   g73(.A(new_n103_), .B(new_n104_), .C(new_n106_), .Y(o22));
  assign               o23 = 1'b1;
  NOR2x1_ASAP7_75t_R   g74(.A(p0), .B(p6), .Y(new_n109_));
  AND2x2_ASAP7_75t_R   g75(.A(p0), .B(p6), .Y(new_n110_));
  OA211x2_ASAP7_75t_R  g76(.A1(new_n109_), .A2(new_n110_), .B(p3), .C(new_n78_), .Y(o24));
  AND3x1_ASAP7_75t_R   g77(.A(new_n42_), .B(p6), .C(new_n53_), .Y(o25));
endmodule


