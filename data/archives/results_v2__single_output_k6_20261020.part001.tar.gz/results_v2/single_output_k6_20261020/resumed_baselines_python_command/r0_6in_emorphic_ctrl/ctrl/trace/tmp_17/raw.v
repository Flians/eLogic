// Benchmark "/tmp/" written by ABC on Tue Oct 20 17:33:01 2026

module \/tmp/  ( 
    p4, p6, p0, p1, p5, p3, p2,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25  );
  input  p4, p6, p0, p1, p5, p3, p2;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25;
  wire new_n34_, new_n35_, new_n36_, new_n37_, new_n38_, new_n40_, new_n41_,
    new_n42_, new_n43_, new_n44_, new_n45_, new_n46_, new_n48_, new_n49_,
    new_n50_, new_n51_, new_n52_, new_n53_, new_n56_, new_n57_, new_n58_,
    new_n59_, new_n60_, new_n61_, new_n62_, new_n63_, new_n64_, new_n66_,
    new_n67_, new_n69_, new_n70_, new_n71_, new_n73_, new_n74_, new_n77_,
    new_n80_, new_n81_, new_n83_, new_n85_, new_n86_, new_n87_, new_n88_,
    new_n93_, new_n97_, new_n98_, new_n99_, new_n101_, new_n102_,
    new_n106_;
  NOR2x1_ASAP7_75t_R   g00(.A(p3), .B(p2), .Y(new_n34_));
  AND3x1_ASAP7_75t_R   g01(.A(new_n34_), .B(p0), .C(p1), .Y(new_n35_));
  AND2x2_ASAP7_75t_R   g02(.A(p3), .B(p2), .Y(new_n36_));
  NOR2x1_ASAP7_75t_R   g03(.A(p0), .B(p1), .Y(new_n37_));
  INVx1_ASAP7_75t_R    g04(.A(new_n37_), .Y(new_n38_));
  OA22x2_ASAP7_75t_R   g05(.A1(new_n35_), .A2(new_n36_), .B1(p6), .B2(new_n38_), .Y(o0));
  INVx1_ASAP7_75t_R    g06(.A(p3), .Y(new_n40_));
  NOR2x1_ASAP7_75t_R   g07(.A(p2), .B(new_n40_), .Y(new_n41_));
  INVx1_ASAP7_75t_R    g08(.A(new_n41_), .Y(new_n42_));
  INVx1_ASAP7_75t_R    g09(.A(p0), .Y(new_n43_));
  NOR2x1_ASAP7_75t_R   g10(.A(p1), .B(new_n43_), .Y(new_n44_));
  INVx1_ASAP7_75t_R    g11(.A(p1), .Y(new_n45_));
  OAI22x1_ASAP7_75t_R  g12(.A1(new_n36_), .A2(p0), .B1(new_n45_), .B2(new_n34_), .Y(new_n46_));
  AOI221x1_ASAP7_75t_R g13(.A1(p6), .A2(new_n37_), .B1(new_n42_), .B2(new_n44_), .C(new_n46_), .Y(o1));
  INVx1_ASAP7_75t_R    g14(.A(new_n44_), .Y(new_n48_));
  NAND2x1_ASAP7_75t_R  g15(.A(p3), .B(p2), .Y(new_n49_));
  OR3x1_ASAP7_75t_R    g16(.A(new_n49_), .B(p6), .C(p1), .Y(new_n50_));
  OR3x1_ASAP7_75t_R    g17(.A(new_n40_), .B(p6), .C(p2), .Y(new_n51_));
  INVx1_ASAP7_75t_R    g18(.A(p2), .Y(new_n52_));
  OA21x2_ASAP7_75t_R   g19(.A1(p3), .A2(new_n52_), .B(p0), .Y(new_n53_));
  AOI22x1_ASAP7_75t_R  g20(.A1(new_n48_), .A2(new_n50_), .B1(new_n51_), .B2(new_n53_), .Y(o2));
  AOI221x1_ASAP7_75t_R g21(.A1(p6), .A2(new_n36_), .B1(new_n38_), .B2(p2), .C(new_n34_), .Y(o3));
  AND3x1_ASAP7_75t_R   g22(.A(p6), .B(p0), .C(p2), .Y(new_n56_));
  INVx1_ASAP7_75t_R    g23(.A(p4), .Y(new_n57_));
  INVx1_ASAP7_75t_R    g24(.A(p5), .Y(new_n58_));
  OAI21x1_ASAP7_75t_R  g25(.A1(new_n57_), .A2(new_n58_), .B(p3), .Y(new_n59_));
  NAND2x1_ASAP7_75t_R  g26(.A(new_n56_), .B(new_n59_), .Y(new_n60_));
  AND3x1_ASAP7_75t_R   g27(.A(p4), .B(p3), .C(p2), .Y(new_n61_));
  NOR2x1_ASAP7_75t_R   g28(.A(p6), .B(new_n43_), .Y(new_n62_));
  AOI21x1_ASAP7_75t_R  g29(.A1(new_n61_), .A2(new_n62_), .B(p1), .Y(new_n63_));
  AOI21x1_ASAP7_75t_R  g30(.A1(p6), .A2(new_n41_), .B(new_n45_), .Y(new_n64_));
  AOI21x1_ASAP7_75t_R  g31(.A1(new_n60_), .A2(new_n63_), .B(new_n64_), .Y(o4));
  AO21x1_ASAP7_75t_R   g32(.A1(p3), .A2(new_n58_), .B(new_n52_), .Y(new_n66_));
  NOR2x1_ASAP7_75t_R   g33(.A(new_n45_), .B(new_n41_), .Y(new_n67_));
  AOI211x1_ASAP7_75t_R g34(.A1(new_n45_), .A2(new_n66_), .B(new_n43_), .C(new_n67_), .Y(o5));
  AND2x2_ASAP7_75t_R   g35(.A(p6), .B(p0), .Y(new_n69_));
  NOR2x1_ASAP7_75t_R   g36(.A(p1), .B(new_n69_), .Y(new_n70_));
  OR3x1_ASAP7_75t_R    g37(.A(new_n36_), .B(p1), .C(new_n34_), .Y(new_n71_));
  OAI21x1_ASAP7_75t_R  g38(.A1(new_n49_), .A2(new_n70_), .B(new_n71_), .Y(o6));
  AO21x1_ASAP7_75t_R   g39(.A1(new_n43_), .A2(new_n45_), .B(p6), .Y(new_n73_));
  NAND2x1_ASAP7_75t_R  g40(.A(p6), .B(new_n45_), .Y(new_n74_));
  AND3x1_ASAP7_75t_R   g41(.A(new_n40_), .B(new_n52_), .C(p1), .Y(o19));
  AO32x1_ASAP7_75t_R   g42(.A1(new_n73_), .A2(new_n36_), .A3(new_n74_), .B1(o19), .B2(p0), .Y(o7));
  NOR2x1_ASAP7_75t_R   g43(.A(new_n45_), .B(new_n34_), .Y(new_n77_));
  AOI221x1_ASAP7_75t_R g44(.A1(new_n49_), .A2(new_n77_), .B1(new_n51_), .B2(new_n44_), .C(new_n43_), .Y(o8));
  AOI21x1_ASAP7_75t_R  g45(.A1(new_n44_), .A2(new_n51_), .B(new_n46_), .Y(o9));
  NOR2x1_ASAP7_75t_R   g46(.A(p1), .B(p2), .Y(new_n80_));
  AO21x1_ASAP7_75t_R   g47(.A1(p3), .A2(new_n37_), .B(new_n80_), .Y(new_n81_));
  OAI22x1_ASAP7_75t_R  g48(.A1(new_n67_), .A2(new_n81_), .B1(new_n42_), .B2(new_n62_), .Y(o10));
  INVx1_ASAP7_75t_R    g49(.A(p6), .Y(new_n83_));
  AND3x1_ASAP7_75t_R   g50(.A(new_n37_), .B(new_n34_), .C(new_n83_), .Y(o11));
  AND3x1_ASAP7_75t_R   g51(.A(new_n83_), .B(new_n43_), .C(new_n52_), .Y(new_n85_));
  AO21x1_ASAP7_75t_R   g52(.A1(new_n40_), .A2(new_n52_), .B(p1), .Y(new_n86_));
  AO21x1_ASAP7_75t_R   g53(.A1(p2), .A2(new_n40_), .B(new_n45_), .Y(new_n87_));
  NOR2x1_ASAP7_75t_R   g54(.A(p0), .B(p3), .Y(new_n88_));
  OAI22x1_ASAP7_75t_R  g55(.A1(new_n85_), .A2(new_n86_), .B1(new_n87_), .B2(new_n88_), .Y(o12));
  AND3x1_ASAP7_75t_R   g56(.A(new_n34_), .B(p6), .C(p1), .Y(o13));
  AND3x1_ASAP7_75t_R   g57(.A(new_n34_), .B(new_n83_), .C(p1), .Y(o14));
  AND5x1_ASAP7_75t_R   g58(.A(new_n83_), .B(new_n43_), .C(new_n40_), .D(p1), .E(p2), .Y(o15));
  AND2x2_ASAP7_75t_R   g59(.A(p6), .B(p2), .Y(new_n93_));
  AND3x1_ASAP7_75t_R   g60(.A(new_n93_), .B(p1), .C(new_n88_), .Y(o16));
  AND5x1_ASAP7_75t_R   g61(.A(p6), .B(new_n40_), .C(p0), .D(p1), .E(p2), .Y(o17));
  AND5x1_ASAP7_75t_R   g62(.A(new_n83_), .B(new_n40_), .C(p0), .D(p1), .E(p2), .Y(o18));
  OAI21x1_ASAP7_75t_R  g63(.A1(p4), .A2(new_n40_), .B(new_n56_), .Y(new_n97_));
  AOI21x1_ASAP7_75t_R  g64(.A1(new_n88_), .A2(new_n93_), .B(p1), .Y(new_n98_));
  OA21x2_ASAP7_75t_R   g65(.A1(new_n49_), .A2(new_n69_), .B(p1), .Y(new_n99_));
  AOI21x1_ASAP7_75t_R  g66(.A1(new_n97_), .A2(new_n98_), .B(new_n99_), .Y(o20));
  NAND2x1_ASAP7_75t_R  g67(.A(p2), .B(new_n88_), .Y(new_n101_));
  OR4x2_ASAP7_75t_R    g68(.A(new_n49_), .B(new_n57_), .C(new_n43_), .D(p5), .Y(new_n102_));
  AOI21x1_ASAP7_75t_R  g69(.A1(new_n101_), .A2(new_n102_), .B(new_n74_), .Y(o21));
  AOI21x1_ASAP7_75t_R  g70(.A1(new_n45_), .A2(new_n60_), .B(new_n99_), .Y(o22));
  assign               o23 = 1'b1;
  NOR2x1_ASAP7_75t_R   g71(.A(p6), .B(p0), .Y(new_n106_));
  OA211x2_ASAP7_75t_R  g72(.A1(new_n106_), .A2(new_n69_), .B(p3), .C(new_n80_), .Y(o24));
  AND3x1_ASAP7_75t_R   g73(.A(new_n41_), .B(p6), .C(new_n37_), .Y(o25));
endmodule


