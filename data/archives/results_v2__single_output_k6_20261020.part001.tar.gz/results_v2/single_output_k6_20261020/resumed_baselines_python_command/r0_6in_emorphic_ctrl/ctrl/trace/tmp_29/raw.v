// Benchmark "/tmp/" written by ABC on Tue Oct 20 17:33:02 2026

module \/tmp/  ( 
    p4, p0, p1, p6, p3, p2, p5,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25  );
  input  p4, p0, p1, p6, p3, p2, p5;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25;
  wire new_n34_, new_n35_, new_n36_, new_n37_, new_n38_, new_n40_, new_n41_,
    new_n42_, new_n43_, new_n44_, new_n45_, new_n46_, new_n47_, new_n48_,
    new_n50_, new_n51_, new_n52_, new_n53_, new_n54_, new_n56_, new_n57_,
    new_n59_, new_n60_, new_n61_, new_n62_, new_n63_, new_n64_, new_n65_,
    new_n66_, new_n68_, new_n69_, new_n70_, new_n72_, new_n73_, new_n75_,
    new_n78_, new_n80_, new_n81_, new_n82_, new_n85_, new_n86_, new_n87_,
    new_n88_, new_n92_, new_n94_, new_n96_, new_n100_, new_n101_,
    new_n102_, new_n104_, new_n106_, new_n107_, new_n108_, new_n109_,
    new_n112_;
  NAND2x1_ASAP7_75t_R  g00(.A(p3), .B(p2), .Y(new_n34_));
  INVx1_ASAP7_75t_R    g01(.A(new_n34_), .Y(new_n35_));
  OR3x1_ASAP7_75t_R    g02(.A(p0), .B(p1), .C(p6), .Y(new_n36_));
  NOR2x1_ASAP7_75t_R   g03(.A(p3), .B(p2), .Y(new_n37_));
  AND3x1_ASAP7_75t_R   g04(.A(new_n37_), .B(p0), .C(p1), .Y(new_n38_));
  AO21x1_ASAP7_75t_R   g05(.A1(new_n35_), .A2(new_n36_), .B(new_n38_), .Y(o0));
  NOR2x1_ASAP7_75t_R   g06(.A(p0), .B(p1), .Y(new_n40_));
  INVx1_ASAP7_75t_R    g07(.A(p3), .Y(new_n41_));
  INVx1_ASAP7_75t_R    g08(.A(p2), .Y(new_n42_));
  OR3x1_ASAP7_75t_R    g09(.A(new_n41_), .B(new_n42_), .C(p6), .Y(new_n43_));
  INVx1_ASAP7_75t_R    g10(.A(p1), .Y(new_n44_));
  AOI21x1_ASAP7_75t_R  g11(.A1(p0), .A2(new_n37_), .B(new_n44_), .Y(new_n45_));
  NAND2x1_ASAP7_75t_R  g12(.A(p0), .B(new_n44_), .Y(new_n46_));
  NOR2x1_ASAP7_75t_R   g13(.A(p2), .B(new_n41_), .Y(new_n47_));
  NOR2x1_ASAP7_75t_R   g14(.A(new_n46_), .B(new_n47_), .Y(new_n48_));
  AOI211x1_ASAP7_75t_R g15(.A1(new_n40_), .A2(new_n43_), .B(new_n45_), .C(new_n48_), .Y(o1));
  INVx1_ASAP7_75t_R    g16(.A(p0), .Y(new_n50_));
  NOR2x1_ASAP7_75t_R   g17(.A(p3), .B(new_n42_), .Y(new_n51_));
  NOR2x1_ASAP7_75t_R   g18(.A(new_n50_), .B(new_n51_), .Y(new_n52_));
  OR3x1_ASAP7_75t_R    g19(.A(new_n41_), .B(p6), .C(p2), .Y(new_n53_));
  OR3x1_ASAP7_75t_R    g20(.A(new_n34_), .B(p1), .C(p6), .Y(new_n54_));
  AOI22x1_ASAP7_75t_R  g21(.A1(new_n52_), .A2(new_n53_), .B1(new_n46_), .B2(new_n54_), .Y(o2));
  INVx1_ASAP7_75t_R    g22(.A(p6), .Y(new_n56_));
  INVx1_ASAP7_75t_R    g23(.A(new_n37_), .Y(new_n57_));
  OA221x2_ASAP7_75t_R  g24(.A1(new_n56_), .A2(new_n34_), .B1(new_n42_), .B2(new_n40_), .C(new_n57_), .Y(o3));
  NAND2x1_ASAP7_75t_R  g25(.A(p4), .B(p0), .Y(new_n59_));
  OA31x2_ASAP7_75t_R   g26(.A1(p6), .A2(new_n34_), .A3(new_n59_), .B1(new_n44_), .Y(new_n60_));
  AND3x1_ASAP7_75t_R   g27(.A(p0), .B(p6), .C(p2), .Y(new_n61_));
  INVx1_ASAP7_75t_R    g28(.A(p4), .Y(new_n62_));
  INVx1_ASAP7_75t_R    g29(.A(p5), .Y(new_n63_));
  OAI21x1_ASAP7_75t_R  g30(.A1(new_n62_), .A2(new_n63_), .B(p3), .Y(new_n64_));
  NAND2x1_ASAP7_75t_R  g31(.A(new_n61_), .B(new_n64_), .Y(new_n65_));
  AOI21x1_ASAP7_75t_R  g32(.A1(p6), .A2(new_n47_), .B(new_n44_), .Y(new_n66_));
  AOI21x1_ASAP7_75t_R  g33(.A1(new_n60_), .A2(new_n65_), .B(new_n66_), .Y(o4));
  NAND2x1_ASAP7_75t_R  g34(.A(p2), .B(new_n41_), .Y(new_n68_));
  AOI21x1_ASAP7_75t_R  g35(.A1(p2), .A2(p5), .B(p1), .Y(new_n69_));
  NOR2x1_ASAP7_75t_R   g36(.A(new_n44_), .B(new_n47_), .Y(new_n70_));
  AOI211x1_ASAP7_75t_R g37(.A1(new_n68_), .A2(new_n69_), .B(new_n50_), .C(new_n70_), .Y(o5));
  AOI21x1_ASAP7_75t_R  g38(.A1(p0), .A2(p6), .B(p1), .Y(new_n72_));
  AND2x2_ASAP7_75t_R   g39(.A(p1), .B(new_n34_), .Y(new_n73_));
  AOI211x1_ASAP7_75t_R g40(.A1(new_n35_), .A2(new_n72_), .B(new_n37_), .C(new_n73_), .Y(o6));
  OAI21x1_ASAP7_75t_R  g41(.A1(new_n44_), .A2(new_n56_), .B(new_n36_), .Y(new_n75_));
  AO21x1_ASAP7_75t_R   g42(.A1(new_n35_), .A2(new_n75_), .B(new_n38_), .Y(o7));
  AOI221x1_ASAP7_75t_R g43(.A1(new_n53_), .A2(new_n44_), .B1(new_n73_), .B2(new_n57_), .C(new_n50_), .Y(o8));
  INVx1_ASAP7_75t_R    g44(.A(new_n46_), .Y(new_n78_));
  AOI221x1_ASAP7_75t_R g45(.A1(new_n50_), .A2(new_n34_), .B1(new_n78_), .B2(new_n53_), .C(new_n45_), .Y(o9));
  NOR2x1_ASAP7_75t_R   g46(.A(p1), .B(p2), .Y(new_n80_));
  AO21x1_ASAP7_75t_R   g47(.A1(p3), .A2(new_n40_), .B(new_n80_), .Y(new_n81_));
  OAI21x1_ASAP7_75t_R  g48(.A1(new_n50_), .A2(p6), .B(new_n47_), .Y(new_n82_));
  OAI21x1_ASAP7_75t_R  g49(.A1(new_n81_), .A2(new_n70_), .B(new_n82_), .Y(o10));
  AND3x1_ASAP7_75t_R   g50(.A(new_n37_), .B(new_n40_), .C(new_n56_), .Y(o11));
  NOR2x1_ASAP7_75t_R   g51(.A(p0), .B(p3), .Y(new_n85_));
  INVx1_ASAP7_75t_R    g52(.A(new_n85_), .Y(new_n86_));
  NOR2x1_ASAP7_75t_R   g53(.A(p1), .B(new_n37_), .Y(new_n87_));
  OR3x1_ASAP7_75t_R    g54(.A(p0), .B(p6), .C(p2), .Y(new_n88_));
  AO32x1_ASAP7_75t_R   g55(.A1(p1), .A2(new_n68_), .A3(new_n86_), .B1(new_n87_), .B2(new_n88_), .Y(o12));
  AND3x1_ASAP7_75t_R   g56(.A(new_n37_), .B(p1), .C(p6), .Y(o13));
  AND3x1_ASAP7_75t_R   g57(.A(new_n37_), .B(p1), .C(new_n56_), .Y(o14));
  NOR2x1_ASAP7_75t_R   g58(.A(p0), .B(p6), .Y(new_n92_));
  AND3x1_ASAP7_75t_R   g59(.A(new_n51_), .B(p1), .C(new_n92_), .Y(o15));
  AND2x2_ASAP7_75t_R   g60(.A(p6), .B(p2), .Y(new_n94_));
  AND3x1_ASAP7_75t_R   g61(.A(new_n94_), .B(p1), .C(new_n85_), .Y(o16));
  AND3x1_ASAP7_75t_R   g62(.A(p0), .B(p1), .C(p6), .Y(new_n96_));
  AND3x1_ASAP7_75t_R   g63(.A(new_n96_), .B(new_n41_), .C(p2), .Y(o17));
  AND5x1_ASAP7_75t_R   g64(.A(p0), .B(new_n56_), .C(new_n41_), .D(p1), .E(p2), .Y(o18));
  AND3x1_ASAP7_75t_R   g65(.A(new_n41_), .B(new_n42_), .C(p1), .Y(o19));
  OAI21x1_ASAP7_75t_R  g66(.A1(p4), .A2(new_n41_), .B(new_n61_), .Y(new_n100_));
  AOI21x1_ASAP7_75t_R  g67(.A1(new_n85_), .A2(new_n94_), .B(p1), .Y(new_n101_));
  AO21x1_ASAP7_75t_R   g68(.A1(p1), .A2(new_n34_), .B(new_n96_), .Y(new_n102_));
  AOI21x1_ASAP7_75t_R  g69(.A1(new_n100_), .A2(new_n101_), .B(new_n102_), .Y(o20));
  NOR3x1_ASAP7_75t_R   g70(.A(new_n59_), .B(new_n41_), .C(p5), .Y(new_n104_));
  OA211x2_ASAP7_75t_R  g71(.A1(new_n85_), .A2(new_n104_), .B(new_n44_), .C(new_n94_), .Y(o21));
  NAND2x1_ASAP7_75t_R  g72(.A(new_n69_), .B(new_n68_), .Y(new_n106_));
  AOI211x1_ASAP7_75t_R g73(.A1(p1), .A2(new_n34_), .B(new_n72_), .C(new_n96_), .Y(new_n107_));
  NAND2x1_ASAP7_75t_R  g74(.A(p3), .B(p5), .Y(new_n108_));
  OR3x1_ASAP7_75t_R    g75(.A(new_n108_), .B(p4), .C(p1), .Y(new_n109_));
  AND3x1_ASAP7_75t_R   g76(.A(new_n106_), .B(new_n107_), .C(new_n109_), .Y(o22));
  assign               o23 = 1'b1;
  AND2x2_ASAP7_75t_R   g77(.A(p0), .B(p6), .Y(new_n112_));
  OA211x2_ASAP7_75t_R  g78(.A1(new_n92_), .A2(new_n112_), .B(p3), .C(new_n80_), .Y(o24));
  AND3x1_ASAP7_75t_R   g79(.A(new_n47_), .B(p6), .C(new_n40_), .Y(o25));
endmodule


