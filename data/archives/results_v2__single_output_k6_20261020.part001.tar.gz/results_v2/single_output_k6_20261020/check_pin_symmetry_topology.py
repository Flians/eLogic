import importlib.util,json
from pathlib import Path
source=Path("scripts/experiments/campaigns/analyze_pin_symmetry_relaxation.py")
s=importlib.util.spec_from_file_location("pinrelax",source);m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
folder=Path(__file__).with_name("pin_symmetry_fixture");folder.mkdir(exist_ok=False)
method="fixture";netdir=folder/"toy.fixture";netdir.mkdir()
models=[dict(name="BUF",area=1.,out_pin="Y",vars=["A"],tt=[2],pin_delay={"A":9.}),dict(name="AND",area=1.,out_pin="Y",vars=["A","B"],tt=[8],pin_delay={"A":1.,"B":10.})]
net=dict(modules=dict(mapped=dict(ports={"x":dict(direction="input",bits=[0]),"y":dict(direction="output",bits=[3])},cells={"buf":dict(type="BUF",connections={"A":[0],"Y":[2]}),"and":dict(type="AND",connections={"A":[0],"B":[2],"Y":[3]})})))
report=dict(library_sha256="synthetic",results=[dict(bench="toy",method=method,status="ok",measured=dict(cec=1,area=2.,delay=19.),input_sha256="synthetic",preprocessing=dict(sha256="synthetic"))])
paths=[folder/"library.json",netdir/"mapped.json",folder/"report.json"]
for path,data in zip(paths,[models,net,report]):path.write_text(json.dumps(data))
before={str(path):m.sha(path) for path in paths}
r=m.analyze(paths[-1],method)
assert r["original_delay"]==19. and r["relaxed_fixed_topology_delay"]==10.
assert r["original_area"]==2. and r["improved_internal_nodes"]==1
assert before=={str(path):m.sha(path) for path in paths}
# False selected metric must fail; the diagnostic is not allowed to silently
# invent a different original delay model.
report["results"][0]["measured"]["delay"]=18.
paths[-1].write_text(json.dumps(report))
try:m.analyze(paths[-1],method)
except AssertionError:pass
else:raise AssertionError("incorrect original timing was accepted")
report["results"][0]["measured"]["delay"]=19.;paths[-1].write_text(json.dumps(report))
models.append(dict(models[1],out_pin="Z"));paths[0].write_text(json.dumps(models))
try:m.analyze(paths[-1],method)
except AssertionError:pass
else:raise AssertionError("multi-output model was accepted")
models.pop();paths[0].write_text(json.dumps(models))
assert before=={str(path):m.sha(path) for path in paths}
(folder/"validation.json").write_text(json.dumps(dict(passed=True,fixed_topology_expected_delay=10,old_delay=19,incorrect_original_metric_rejected=True,multioutput_rejected=True,netlist_and_sources_unchanged=True,source_sha256=m.sha(source),warning="Synthetic report cec=1 is test input only; no actual CEC or mapped result is asserted"),indent=2)+"\n")
print("fixed-topology pin relaxation fixture and two negative controls passed")
