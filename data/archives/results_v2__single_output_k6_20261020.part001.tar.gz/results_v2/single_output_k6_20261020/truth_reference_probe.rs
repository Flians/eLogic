use std::hint::black_box;
use std::time::Instant;
fn expand_reference(function: u64, from: &[usize], to: &[usize]) -> u64 {
    let positions: Vec<_> = from.iter().map(|x| to.binary_search(x).unwrap()).collect();
    let mut result = 0;
    for a in 0..1usize << to.len() {
        let old = positions
            .iter()
            .enumerate()
            .fold(0, |v, (i, p)| v | (((a >> p) & 1) << i));
        result |= ((function >> old) & 1) << a;
    }
    result
}

fn main(){let mut state=7u64;let before=Instant::now();let mut checksum=0u64;
for i in 0..2000000usize {state=state.wrapping_mul(6364136223846793005).wrapping_add(1);let from=match i%4 {0=>vec![0,2,4],1=>vec![1,3,5],2=>vec![0,1,2,4,5],_=>vec![2]};checksum^=black_box(expand_reference(black_box(state),black_box(&from),black_box(&[0,1,2,3,4,5])));}
println!("{{\"seconds\":{},\"checksum\":{}}}",before.elapsed().as_secs_f64(),checksum);}
