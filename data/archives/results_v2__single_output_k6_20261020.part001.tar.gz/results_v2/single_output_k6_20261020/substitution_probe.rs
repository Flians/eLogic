use std::{hint::black_box,time::Instant};
#[derive(Clone)]struct Cut {leaves:Vec<usize>, function:u64}
fn mask(k: usize) -> u64 {
    if k == 6 {
        u64::MAX
    } else {
        (1u64 << (1usize << k)) - 1
    }
}
fn expand_reference(function: u64, from: &[usize], to: &[usize]) -> u64 {
    let positions: Vec<_> = from.iter().map(|x| to.binary_search(x).unwrap()).collect();
    let mut result = 0;
    for a in 0..1usize << to.len() {
        let old = positions
            .iter()
            .enumerate()
            .fold(0, |v, (i, p)| v | (((a >> p) & 1) << i));
        result |= ((function >> old) & 1) << a;
    }
    result
}
fn expand_word(function: u64, from: &[usize], to: &[usize]) -> u64 {
    if to.len() > 6 || !from.windows(2).all(|w| w[0] < w[1]) {
        return expand_reference(function, from, to);
    }
    const LOW_GROUPS: [u64; 6] = [
        0x5555555555555555, 0x3333333333333333,
        0x0f0f0f0f0f0f0f0f, 0x00ff00ff00ff00ff,
        0x0000ffff0000ffff, 0x00000000ffffffff,
    ];
    let mut bits = function & mask(from.len());
    let mut source = 0;
    for (position, &leaf) in to.iter().enumerate() {
        if from.get(source) == Some(&leaf) {
            source += 1;
        } else {
            for step in (position..6).rev() {
                bits = (bits | (bits << (1usize << step))) & LOW_GROUPS[step];
            }
            bits |= bits << (1usize << position);
        }
    }
    assert_eq!(source, from.len(), "truth support is not a subset");
    bits & mask(to.len())
}
fn substitute_reference(base: &Cut, position: usize, child: &Cut, leaves: &[usize]) -> u64 {
    let mut function=0;for a in 0..1usize<<leaves.len(){let sub=child.leaves.iter().enumerate().map(|(p,s)|((a>>leaves.binary_search(s).unwrap())&1)<<p).sum::<usize>();let bit=((child.function>>sub)&1)as usize;let tuple=base.leaves.iter().enumerate().map(|(p,s)|if p==position{bit<<p}else{((a>>leaves.binary_search(s).unwrap())&1)<<p}).sum::<usize>();function|=((base.function>>tuple)&1)<<a;}
    function
}
fn cofactor_word(function: u64, position: usize, value: bool, width: usize) -> u64 {
    const GROUPS:[u64;6]=[0x5555555555555555,0x3333333333333333,
        0x0f0f0f0f0f0f0f0f,0x00ff00ff00ff00ff,0x0000ffff0000ffff,0x00000000ffffffff];
    let mut result=(function >> (usize::from(value)*(1usize<<position))) & GROUPS[position];
    for step in position..5 {result=(result | (result>>(1usize<<step))) & GROUPS[step+1];}
    result & mask(width-1)
}
fn substitute_word(base:&Cut, position:usize, child:&Cut, leaves:&[usize])->u64 {
    let remaining:Vec<_>=base.leaves.iter().enumerate().filter_map(|(i,&leaf)|(i!=position).then_some(leaf)).collect();
    let low=expand_word(cofactor_word(base.function,position,false,base.leaves.len()),&remaining,leaves);
    let high=expand_word(cofactor_word(base.function,position,true,base.leaves.len()),&remaining,leaves);
    let condition=expand_word(child.function,&child.leaves,leaves);
    ((low & !condition) | (high & condition)) & mask(leaves.len())
}
fn main(){let mode=std::env::args().nth(1).unwrap();let f:fn(&Cut,usize,&Cut,&[usize])->u64=if mode=="reference"{substitute_reference}else{substitute_word};
let mut base=Cut{leaves:vec![0,1,2,3],function:0};let mut child=Cut{leaves:vec![2,4,5],function:0};let leaves=[0,1,2,3,4,5];let mut state=7u64;let mut sum=0;let t=Instant::now();
for _ in 0..500000 {state=state.wrapping_mul(6364136223846793005).wrapping_add(1);base.function=state;child.function=state.rotate_left(17);sum^=black_box(f(black_box(&base),2,black_box(&child),black_box(&leaves)));}
println!("{{\"mode\":\"{}\",\"seconds\":{},\"checksum\":{}}}",mode,t.elapsed().as_secs_f64(),sum);}
