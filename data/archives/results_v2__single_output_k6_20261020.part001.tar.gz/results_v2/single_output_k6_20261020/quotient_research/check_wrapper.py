import sys,importlib,subprocess,json,hashlib
from pathlib import Path
here=Path("scripts/experiments/campaigns").resolve();sys.path.insert(0,str(here))
w=importlib.import_module("run_k6_quotient_budget")
real_init=subprocess.Popen.__init__;real_main=w.delegated.main;real_argv=sys.argv[:]
records=[]
def fake(proc,argv,*args,**kwargs):
 proc._child_created=False;records.append(dict(argv=argv,env=dict(kwargs["env"])))
def driver():
 assert "--mapping-seconds" in sys.argv and sys.argv[sys.argv.index("--mapping-seconds")+1]=="300"
 for executable in ["/tmp/egraphmap_scaled.py","/tmp/author-original"]:
  proc=object.__new__(subprocess.Popen);subprocess.Popen.__init__(proc,[executable],env={"unchanged":"yes"})
try:
 subprocess.Popen.__init__=fake;w.delegated.main=driver
 for profile in [0,1]:
  sys.argv=[str(here/"run_k6_quotient_budget.py"),"--profile",str(profile),"--mode","quotient","--mapping-seconds","300"]
  w.main()
finally:
 subprocess.Popen.__init__=real_init;w.delegated.main=real_main;sys.argv=real_argv
assert len(records)==4
for profile in [0,1]:
 own,author=records[profile*2:profile*2+2]
 assert own["env"]["EGM_WORD_QUOTIENT"]==str(profile)
 assert own["env"]["EGM_FORCE_COMPACT_SOURCE"]=="1"
 assert own["env"]["EGM_EXCHANGE_TIME_FRACTION"]=="0.70"
 assert own["env"]["EGM_EXACT_CUT_OPS"]=="1"
 assert author["env"]=={"unchanged":"yes"}
Path(__file__).with_name("wrapper_validation.json").write_text(json.dumps(dict(passed=True,calls=records,actual_processes=0,mapping_seconds_forwarded=300,author_environment_unchanged=True,source_sha256=hashlib.sha256(Path(w.__file__).read_bytes()).hexdigest()),indent=2)+"\n")
print("two own profiles and two unchanged author environments passed; no actual process")
