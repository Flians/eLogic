from pathlib import Path
base=Path(__file__).resolve().parent
red=(base/'red.log').read_text();assert 'left: 8' in red and 'right: 0' in red and 'test result: FAILED' in red
p=base/'source/emapper/src/egraph_map.rs';s=p.read_text()
old='fn exact_functional_quotient_word(root:&Cut,helper:usize,part:&Cut)->Option<Cut>{exact_functional_quotient_reference(root,helper,part)}'
new='''fn exact_functional_quotient_word(root:&Cut,helper:usize,part:&Cut)->Option<Cut>{
 if !(3..=4).contains(&root.leaves.len()) || part.leaves.len()<2
  || part.leaves.len()>=root.leaves.len() || part.function==0
  || part.function==mask(part.leaves.len())
  || !part.leaves.iter().all(|v|root.leaves.contains(v)){return None;}
 let rest:Vec<_>=root.leaves.iter().filter(|v|!part.leaves.contains(v)).copied().collect();
 if rest.contains(&helper){return None;}
 let leaves:Vec<_>=rest.iter().copied().chain([helper]).collect::<BTreeSet<_>>().into_iter().collect();
 // Each output row denotes a full cube of original assignments. Validate that
 // all root values on this nonempty cube agree; no SDC completion is involved.
 let universe=mask(root.leaves.len());
 let part_true=expand_word(part.function,&part.leaves,&root.leaves);
 let patterns:Vec<_>=rest.iter().map(|&r|(leaves.binary_search(&r).unwrap(),expand_word(2,&[r],&root.leaves))).collect();
 let helper_position=leaves.binary_search(&helper).unwrap();let mut truth=0;
 for output in 0..1usize<<leaves.len(){
  let mut cube=if output&(1<<helper_position)!=0{part_true}else{universe^part_true};
  for &(position,pattern) in &patterns{cube &= if output&(1<<position)!=0{pattern}else{universe^pattern};}
  if cube==0{return None;}
  let values=root.function&cube;
  if values!=0 && values!=cube{return None;}
  if values!=0{truth|=1<<output;}
 }
 Some(reduce(Cut{leaves,function:truth}))
}'''
assert s.count(old)==1;s=s.replace(old,new)
s+='''
#[cfg(test)]mod word_quotient_oracle_tests{
 use super::*;
 #[test]fn all_three_input_truths_parts_and_helper_positions_match_row_oracle(){
  for function in 0..256 {let root=Cut{leaves:vec![2,5,9],function};
   for leaves in [vec![2,5],vec![2,9],vec![5,9],vec![5,2]]{for part_function in 0..16{let part=Cut{leaves:leaves.clone(),function:part_function};for helper in [0,2,5,9,12]{assert_eq!(exact_functional_quotient_word(&root,helper,&part),exact_functional_quotient_reference(&root,helper,&part));}}}
  }
 }
 #[test]fn four_input_parts_constants_and_output_positions_match_row_oracle(){
  let leaves=vec![2,5,9,14];let mut state=43u64;
  for _ in 0..8192 {state=state.wrapping_mul(6364136223846793005).wrapping_add(1);let root=Cut{leaves:leaves.clone(),function:state&mask(4)};
   for subset in 1..15usize {let support:Vec<_>=leaves.iter().enumerate().filter_map(|(i,&r)|(subset&(1<<i)!=0).then_some(r)).collect();if support.len()<2{continue;}
    state=state.wrapping_mul(6364136223846793005).wrapping_add(1);let part=Cut{leaves:support,function:state&mask(subset.count_ones()as usize)};
    for helper in [0,4,8,12,20] {assert_eq!(exact_functional_quotient_word(&root,helper,&part),exact_functional_quotient_reference(&root,helper,&part));}
   }
  }
  let root=Cut{leaves,function:0x8888};for part in [Cut{leaves:vec![2,5],function:0},Cut{leaves:vec![2,5],function:15},Cut{leaves:vec![2,5],function:16},Cut{leaves:vec![2,5],function:31},Cut{leaves:vec![2,17],function:8}]{assert_eq!(exact_functional_quotient_word(&root,20,&part),exact_functional_quotient_reference(&root,20,&part));}
 }
}
'''
original=(base.parent/'source_kernels_final/emapper/src/egraph_map.rs').read_text();a=original.index('#[cfg(test)] mod word_reduce_whole_pool_tests {');b=original.index('#[cfg(test)]mod exact_cut_ops_tests',a)
pool=original[a:b].replace('word_reduce_whole_pool_tests','word_quotient_whole_pool_tests').replace('with_reduce','with_quotient').replace('TEST_REDUCE_OVERRIDE','TEST_QUOTIENT_OVERRIDE').replace('word_reduce_preserves_exact_cut_pool_and_binding_proof_sequences','word_quotient_preserves_exact_cut_pool_and_binding_proof_sequences').replace('max_inputs:3+seed%4,','max_inputs:3+seed%4,functional_cuts:true,')
s+=pool;p.write_text(s)
