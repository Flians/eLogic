//! Lifetime admission accounting, shared by import and saturation. Rebuild and
//! union may shrink resident storage, but never refund admitted e-nodes.
use crate::egraph_sat::AigLang;
use egg::{EGraph, ENodeOrVar, Id, Language, PatternAst, Subst};
use std::collections::HashMap;
use std::sync::{Arc, Mutex};
pub(crate) type SharedAdmission = Arc<Mutex<NodeAdmission>>;

#[derive(Debug)]
pub(crate) struct NodeAdmission {
    limit: usize,
    admitted: usize,
}
impl NodeAdmission {
    pub(crate) fn new(limit: usize) -> Self { Self { limit, admitted: 0 } }
    pub(crate) fn admitted(&self) -> usize { self.admitted }
    pub(crate) fn remaining(&self) -> usize { self.limit - self.admitted }
    pub(crate) fn add(&mut self, graph: &mut EGraph<AigLang, ()>, node: AigLang) -> Option<Id> {
        let node = node.map_children(|id| graph.find(id));
        if let Some(id) = graph.lookup(node.clone()) { return Some(id); }
        if self.remaining() == 0 { return None; }
        let id = graph.add(node);
        self.admitted += 1;
        Some(id)
    }
    /// Read-only exact RHS dry run. Variables and hash-consed duplicates cost
    /// zero; repeated new subexpressions count once. No partial RHS is installed.
    pub(crate) fn rhs_cost(&self, graph: &EGraph<AigLang, ()>, ast: &PatternAst<AigLang>, subst: &Subst) -> usize {
        #[derive(Clone, Copy, Debug, PartialEq, Eq, Hash)]
        enum Ref { Existing(Id), Pending(usize) }
        let mut ids = Vec::new();
        let mut pending = HashMap::new();
        for entry in ast.as_ref() {
            let id = match entry {
                ENodeOrVar::Var(v) => Ref::Existing(graph.find(subst[*v])),
                ENodeOrVar::ENode(node) => {
                    let children: Vec<_> = node.children().iter().map(|id| ids[usize::from(*id)]).collect();
                    let mut existing = Vec::new();
                    let all_existing = children.iter().all(|id| if let Ref::Existing(id) = id { existing.push(*id); true } else { false });
                    let found = if all_existing {
                        let mut i = 0;
                        graph.lookup(node.clone().map_children(|_| { let id = existing[i]; i += 1; id }))
                    } else { None };
                    if let Some(id) = found { Ref::Existing(graph.find(id)) }
                    else {
                        let key = (node.clone().map_children(|_| Id::from(0)), children);
                        let next = pending.len();
                        Ref::Pending(*pending.entry(key).or_insert(next))
                    }
                }
            };
            ids.push(id);
        }
        pending.len()
    }
    /// RHS application is a sequence of add/union operations without rebuild.
    /// Its local resident or memo delta equals actual admissions; the read-only
    /// dry run established capacity first. Neither counter is ever used to
    /// reset/refund the lifetime ledger. Unknown/custom appliers are not accepted.
    pub(crate) fn charge_rhs(&mut self, before: usize, after: usize, reserved: usize) {
        let added = after.checked_sub(before).expect("RHS unexpectedly removed resident nodes");
        assert!(added <= reserved && added <= self.remaining(), "RHS exceeded its admission reservation");
        self.admitted += added;
    }
    pub(crate) fn rejected_import(&self, graph: &EGraph<AigLang, ()>, route: &str) {
        eprintln!("budget: cumulative admission rejected before insertion: route={route}, admitted={}, resident={}, node allowance={}", self.admitted, graph.total_number_of_nodes(), self.limit);
        if let Some(path) = std::env::var_os("EGM_POOL_DIAG_PATH") {
            let path = std::path::Path::new(&path).with_extension("admission.json");
            let _ = std::fs::write(path, serde_json::json!({"schema_version":1,"import_complete":false,"route":route,"cumulative_admitted_enodes":self.admitted,"resident_enodes":graph.total_number_of_nodes(),"node_allowance":self.limit,"rejected_before_insertion":true,"refund_on_rebuild":false}).to_string());
        }
    }
    pub(crate) fn import(&mut self, graph: &mut EGraph<AigLang, ()>, node: AigLang, route: &str) -> Option<Id> {
        let result = self.add(graph, node);
        if result.is_none() { self.rejected_import(graph, route); }
        result
    }
}

/// One lifetime ledger, also used by import. Each RHS is dry-run before
/// mutation; zero-new-node unions remain legal when the allowance is exhausted.
struct ReservedRewrite {
    inner: std::sync::Arc<dyn egg::Applier<AigLang, ()> + Send + Sync>,
    admission: crate::egraph_budget::SharedAdmission,
    skipped: std::sync::Arc<std::sync::atomic::AtomicUsize>,
    fast_delta:bool,
    shadow_delta:bool,
}
impl egg::Applier<AigLang, ()> for ReservedRewrite {
    fn apply_one(&self, graph: &mut egg::EGraph<AigLang, ()>, id: Id,
        subst: &egg::Subst, _ast: Option<&egg::PatternAst<AigLang>>, name: egg::Symbol) -> Vec<Id> {
        let mut admission = self.admission.lock().unwrap();
        let rhs = self.inner.get_pattern_ast().expect("strict rewrite must expose its exact RHS");
        let needed = admission.rhs_cost(graph, rhs, subst);
        if needed > admission.remaining() {
            self.skipped.fetch_add(1, std::sync::atomic::Ordering::Relaxed);
            return vec![];
        }
        let shadow_before=if self.shadow_delta && self.fast_delta {Some(graph.total_number_of_nodes())}else{None};
        let before = rhs_node_snapshot(graph,self.fast_delta);
        // No explanation mode is enabled in this mapper. Passing no searcher
        // AST avoids re-instantiating the LHS; only the preflighted RHS is added.
        let result = self.inner.apply_one(graph, id, subst, None, name);
        let after=rhs_node_snapshot(graph,self.fast_delta);
        if let Some(shadow_before)=shadow_before {
            let resident_after=graph.total_number_of_nodes();
            assert_eq!(after.checked_sub(before),resident_after.checked_sub(shadow_before),"RHS memo/local resident deltas differ; fail closed");
            record_shadow_delta_check();
        }
        admission.charge_rhs(before, after, needed);
        result
    }
    fn vars(&self) -> Vec<egg::Var> { self.inner.vars() }
    fn get_pattern_ast(&self) -> Option<&egg::PatternAst<AigLang>> { self.inner.get_pattern_ast() }
}
pub(crate) fn reserve_rewrites(rules: &mut [egg::Rewrite<AigLang, ()>],
    admission: crate::egraph_budget::SharedAdmission,
) -> std::sync::Arc<std::sync::atomic::AtomicUsize> {
    let skipped = std::sync::Arc::new(std::sync::atomic::AtomicUsize::new(0));
    for rule in rules {
        assert!(rule.applier.get_pattern_ast().is_some(), "unaccounted custom strict rewrite: {}", rule.name);
        rule.applier = std::sync::Arc::new(ReservedRewrite {
            inner: rule.applier.clone(), admission: admission.clone(), skipped: skipped.clone(),
            fast_delta:std::env::var("EGM_FAST_ADMISSION_DELTA").as_deref()==Ok("1"),
            shadow_delta:std::env::var("EGM_ADMISSION_SHADOW").as_deref()==Ok("1"),
        });
    }
    skipped
}


#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn cumulative_admission_never_refunds_rebuild_and_allows_duplicates_at_cap() {
        let mut g=EGraph::default(); let mut b=NodeAdmission::new(4);
        let a=b.add(&mut g,AigLang::Pi(0)).unwrap();let c=b.add(&mut g,AigLang::Pi(1)).unwrap();
        b.add(&mut g,AigLang::Not(a)).unwrap();b.add(&mut g,AigLang::Not(c)).unwrap();
        assert!(b.add(&mut g,AigLang::Zero).is_none());assert_eq!(g.total_number_of_nodes(),4);
        g.union(a,c);g.rebuild();assert!(g.total_number_of_nodes()<4);
        assert!(b.add(&mut g,AigLang::Not(c)).is_some());
        assert!(b.add(&mut g,AigLang::Zero).is_none());assert_eq!(b.admitted(),4);
    }
    #[test]
    fn rhs_dry_run_matches_actual_additions_across_unions() {
        use egg::{Applier, Pattern};
        let patterns=["?a","(~ ?a)","(& (~ ?a) (~ ?a))","(& (& ?a ?b) (& ?a ?b))","(& ?b (~ (~ ?a)))"];
        for seed in 0..16 {
            let mut g=EGraph::default();let mut b=NodeAdmission::new(100);
            let a=b.add(&mut g,AigLang::Pi(0)).unwrap();let c=b.add(&mut g,AigLang::Pi(1)).unwrap();
            let n=b.add(&mut g,AigLang::Not(a)).unwrap();
            if seed&1!=0 {b.add(&mut g,AigLang::And([a,c])).unwrap();}
            if seed&2!=0 {b.add(&mut g,AigLang::Not(n)).unwrap();}
            if seed&4!=0 {g.union(a,c);}
            if seed&8!=0 {g.rebuild();}
            let mut subst=Subst::default();subst.insert("?a".parse().unwrap(),a);subst.insert("?b".parse().unwrap(),c);
            for text in patterns {
                let rhs:Pattern<AigLang>=text.parse().unwrap();let expected=b.rhs_cost(&g,&rhs.ast,&subst);
                let mut trial=g.clone();let before=trial.total_number_of_nodes();
                rhs.apply_one(&mut trial,a,&subst,None,"test".into());
                assert_eq!(expected,trial.total_number_of_nodes()-before,"seed{seed}, RHS{text}");
            }
        }
    }

    #[test]
    fn rhs_reservation_counts_new_subterms_not_variables_or_existing_nodes() {
        let mut g=EGraph::default();let mut b=NodeAdmission::new(3);
        let a=b.add(&mut g,AigLang::Pi(0)).unwrap(); let n=b.add(&mut g,AigLang::Not(a)).unwrap();
        let mut s=Subst::default();s.insert("?a".parse().unwrap(),a);s.insert("?n".parse().unwrap(),n);
        for (text,expected) in [("?a",0),("(~ ?a)",0),("(& (~ ?n) (~ ?n))",2)] {
            let p:egg::Pattern<AigLang>=text.parse().unwrap();assert_eq!(b.rhs_cost(&g,&p.ast,&s),expected);
        }
        assert_eq!(b.admitted(),2);assert_eq!(g.total_number_of_nodes(),2);
    }
}

#[cfg(test)]thread_local!{static TEST_RHS_FULL_SCANS:std::cell::Cell<usize>=const{std::cell::Cell::new(0)};}
// Only a local delta around one trusted Pattern RHS application is measured.
// With unit analysis, no explanations, and no rebuild inside apply_one, each
// new hash-consed enode adds one memo entry; union alone does not add entries.
// Rebuild can later shrink the memo, but this value NEVER becomes the lifetime
// allowance or the lifetime admission count. charge_rhs only adds the delta.
fn rhs_node_snapshot(graph:&EGraph<AigLang,()>,fast_delta:bool)->usize {
 if fast_delta {return graph.total_size();}
 #[cfg(test)]TEST_RHS_FULL_SCANS.with(|v|v.set(v.get()+1));
 graph.total_number_of_nodes()
}
#[cfg(test)]mod rhs_delta_regression_tests{
 use super::*;use egg::{Applier,Pattern};
 fn wrapped(rhs:&str,admission:SharedAdmission,fast_delta:bool)->ReservedRewrite{
  ReservedRewrite{inner:Arc::new(rhs.parse::<Pattern<AigLang>>().unwrap()),admission,
   skipped:Arc::new(std::sync::atomic::AtomicUsize::new(0)),fast_delta,shadow_delta:false}
 }
 #[test]fn constant_time_admission_does_not_scan_the_whole_graph_per_rhs(){
  let mut g=EGraph::default();let mut budget=NodeAdmission::new(1000);let mut inputs=Vec::new();
  for i in 0..512{inputs.push(budget.add(&mut g,AigLang::Pi(i)).unwrap());}
  let state=Arc::new(Mutex::new(budget));let rule=wrapped("(~ ?a)",state.clone(),true);
  let mut subst=Subst::default();subst.insert("?a".parse().unwrap(),inputs[0]);TEST_RHS_FULL_SCANS.with(|v|v.set(0));
  rule.apply_one(&mut g,inputs[0],&subst,None,"delta-test".into());
  assert_eq!(state.lock().unwrap().admitted(),513);
  assert_eq!(TEST_RHS_FULL_SCANS.with(|v|v.get()),0,"the fast path must not sum every eclass twice per RHS");
 }
 #[test]fn local_delta_matches_resident_oracle_across_rebuilds_and_exhausted_ledgers(){
  for seed in 0..64usize{
   let limit=[4,5,8,20,100][seed%5];let mut first=EGraph::default();let mut budget=NodeAdmission::new(limit);
   let a=budget.add(&mut first,AigLang::Pi(0)).unwrap();let b=budget.add(&mut first,AigLang::Pi(1)).unwrap();
   budget.add(&mut first,AigLang::Not(a)).unwrap();budget.add(&mut first,AigLang::Not(b)).unwrap();
   let mut second=first.clone();let old=Arc::new(Mutex::new(NodeAdmission{limit,admitted:budget.admitted()}));let fast=Arc::new(Mutex::new(budget));
   let mut subst=Subst::default();subst.insert("?a".parse().unwrap(),a);subst.insert("?b".parse().unwrap(),b);
   let mut prior=4;
   for (index,text)in ["?b","(~ ?a)","(& (~ ?a) (~ ?a))","(& (& ?a ?b) (& ?a ?b))","(& ?b (~ (~ ?a)))","?a"].iter().enumerate(){
    let one=wrapped(text,old.clone(),false);let two=wrapped(text,fast.clone(),true);
    let x=one.apply_one(&mut first,a,&subst,None,"resident-oracle".into());let y=two.apply_one(&mut second,a,&subst,None,"memo-delta".into());assert_eq!(x,y);
    let old_count=old.lock().unwrap().admitted();let fast_count=fast.lock().unwrap().admitted();assert_eq!(old_count,fast_count,"seed={seed} RHS={text}");assert!(fast_count>=prior && fast_count<=limit);prior=fast_count;
    if (index+seed)%2==0{first.rebuild();second.rebuild();}
    let mut x:Vec<_>=first.classes().map(|c|(usize::from(c.id),format!("{:?}",c.nodes))).collect();let mut y:Vec<_>=second.classes().map(|c|(usize::from(c.id),format!("{:?}",c.nodes))).collect();x.sort();y.sort();assert_eq!(x,y);
   }
  }
 }
}

fn record_shadow_delta_check(){
 use std::sync::atomic::{AtomicUsize,Ordering};static COUNT:AtomicUsize=AtomicUsize::new(0);
 let count=COUNT.fetch_add(1,Ordering::Relaxed)+1;
 if count%4096==0 {if let Ok(path)=std::env::var("EGM_STAGE_TRACE") {
  use std::io::Write;if let Ok(mut file)=std::fs::OpenOptions::new().create(true).append(true).open(path){
   let _=writeln!(file,"{}",serde_json::json!({"stage":"admission_delta_shadow","unix_secs":std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).unwrap_or_default().as_secs_f64(),"matched_RHS_deltas":count,"disagreements":0,"scope":"diagnostic only: original resident delta equals proposed memo delta on every checked RHS; no rebuild within RHS"}));
  }
 }}
}
