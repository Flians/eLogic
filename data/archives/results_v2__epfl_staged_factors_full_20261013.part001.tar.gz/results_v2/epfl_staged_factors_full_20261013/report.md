# Staged recovery factorial experiment

160 attempted jobs, 4 fixed profiles, same isolated binary and immutable budgets. All failures retained.

- event_no_critical: {'valid_pairs': 22, 'both_failed': 18, 'one_failed': 0, 'delay_better': 6, 'delay_equal': 16, 'delay_worse': 0, 'area_better': 7, 'area_equal': 12, 'area_worse': 3}
- event_with_critical: {'valid_pairs': 22, 'both_failed': 18, 'one_failed': 0, 'delay_better': 6, 'delay_equal': 16, 'delay_worse': 0, 'area_better': 7, 'area_equal': 12, 'area_worse': 3}
- critical_no_event: {'valid_pairs': 22, 'both_failed': 18, 'one_failed': 0, 'delay_better': 6, 'delay_equal': 16, 'delay_worse': 0, 'area_better': 2, 'area_equal': 14, 'area_worse': 6}
- critical_with_event: {'valid_pairs': 22, 'both_failed': 18, 'one_failed': 0, 'delay_better': 0, 'delay_equal': 22, 'delay_worse': 0, 'area_better': 2, 'area_equal': 18, 'area_worse': 2}
- combined: {'valid_pairs': 22, 'both_failed': 18, 'one_failed': 0, 'delay_better': 6, 'delay_equal': 16, 'delay_worse': 0, 'area_better': 7, 'area_equal': 12, 'area_worse': 3}

Changes affect propagation/proposal ordering under the same global2s recovery and2000-total-trial cap. These single deadline-sensitive runs do not establish optimality or statistical stability; no profile is adopted by default.
