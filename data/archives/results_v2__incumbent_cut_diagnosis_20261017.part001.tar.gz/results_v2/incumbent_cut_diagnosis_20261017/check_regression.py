"""Read-only red-capable symptom check on original frozen V19 evidence."""
import json
from pathlib import Path
p=Path(__file__).with_name('diagnosis.json');r=json.loads(p.read_text())[0]
assert abs(r['control'][1]-r['candidate'][1])<1e-6
assert r['candidate'][0] <= r['control'][0]+1e-6, 'Same-delay area regression: %.2f -> %.2f' % (r['control'][0],r['candidate'][0])
