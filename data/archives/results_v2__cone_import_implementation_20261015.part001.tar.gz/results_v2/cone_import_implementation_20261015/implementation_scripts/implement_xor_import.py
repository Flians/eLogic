from pathlib import Path
import shutil
ROOT=Path('/home/flynn/workplace/MIGBalance');base=Path('/tmp/emapper-epoch-report-20261015');dst=Path('/tmp/emapper-xor-import-20261015');assert not dst.exists();dst.mkdir();shutil.copy2(base/'Cargo.toml',dst/'Cargo.toml');shutil.copy2(base/'Cargo.lock',dst/'Cargo.lock');shutil.copytree(ROOT/'emapper',dst/'emapper',ignore=shutil.ignore_patterns('target','build'));(dst/'src/bin').mkdir(parents=True);shutil.copy2(ROOT/'src/bin/bench_rs_egraph_map.rs',dst/'src/bin/bench_rs_egraph_map.rs');shutil.copytree(base/'tools',dst/'tools',symlinks=True)
p=dst/'emapper/src/egraph_sat.rs';s=p.read_text();marker='#[derive(Clone, Debug)]\npub struct SatParams';i=s.index(marker);s=s[:i]+'''/// Exact XOR/XNOR internal operator. Its operands are real counted classes,
/// not external boundary functions or library cells.
pub(crate) fn xor_inputs(node:&AigLang)->Option<(Id,Id,u8)>{
 if let AigLang::Cell(sym,args)=node{if args.len()==2{return match sym.as_str(){"@egm_xor"=>Some((args[0],args[1],0)),"@egm_xnor"=>Some((args[0],args[1],1)),_=>None}}}None
}

'''+s[i:];s=s.replace('usize::from(literal_inputs(node).is_some())','if xor_inputs(node).is_some(){3}else{usize::from(literal_inputs(node).is_some())}');p.write_text(s)
p=dst/'emapper/src/egraph_regions.rs';s=p.read_text();s+='''
/// Fixed exact XOR pattern contraction BEFORE import. Original intermediate AND
/// functions replaced by a two-input XOR are not materialized as hidden eclasses.
/// Every realized XOR/AND/PI/Not/constant is globally charged; no retirement/reset.
pub(super) fn import_xors(aig:&Aig)->Option<(egg::EGraph<AigLang,()>,Vec<(u32,Id)>)>{
 use crate::aig_graph::AigNode;use petgraph::visit::{EdgeRef,Topo};use petgraph::Direction;
 let g=aig.graph();let pair=|n|{let (a,b)=aig.try_unwrap_and(n)?;let mut v=vec![(aig.edge_source(a),aig.is_edge_inverted(a)),(aig.edge_source(b),aig.is_edge_inverted(b))];v.sort();Some(v)};
 let mut macros=HashMap::new();
 for n in g.node_indices(){if !matches!(aig.node_type(n),AigNode::And){continue}let outer=pair(n)?;if !outer.iter().all(|(n,p)|*p && matches!(aig.node_type(*n),AigNode::And)){continue}let x=pair(outer[0].0)?;let y=pair(outer[1].0)?;let mut complement:Vec<_>=y.iter().map(|&(n,p)|(n,!p)).collect();complement.sort();if x==complement{macros.insert(n,x);}}
 let mut needed=HashSet::new();let mut stack:Vec<_>=g.node_indices().filter(|&n|matches!(aig.node_type(n),AigNode::Input(_)|AigNode::Zero|AigNode::Output(_))).collect();
 while let Some(n)=stack.pop(){if !needed.insert(n){continue}if let Some(v)=macros.get(&n){stack.extend(v.iter().map(|(n,_)|*n));}else{stack.extend(g.edges_directed(n,Direction::Incoming).map(|e|e.source()));}}
 let mut graph=egg::EGraph::default();let mut ids=HashMap::new();let mut topo=Topo::new(g);let mut actual_xor=0;
 while let Some(n)=topo.next(g){if !needed.contains(&n){continue}let node=match aig.node_type(n){
 AigNode::Zero=>AigLang::Zero,AigNode::Input(v)=>AigLang::Pi(v),AigNode::Output(_)=>continue,
 AigNode::And=>{if let Some(v)=macros.get(&n){actual_xor+=1;let odd=v[0].1^v[1].1;AigLang::Cell(if odd{"@egm_xnor"}else{"@egm_xor"}.into(),v.iter().map(|(n,_)|ids[n]).collect())}else{let v=pair(n)?;let x=ids[&v[0].0];let y=ids[&v[1].0];match(v[0].1,v[1].1){(false,false)=>AigLang::And([x,y]),(true,false)=>AigLang::Cell("@egm_and_np".into(),vec![x,y]),(false,true)=>AigLang::Cell("@egm_and_pn".into(),vec![x,y]),(true,true)=>AigLang::Cell("@egm_and_nn".into(),vec![x,y])}}}};ids.insert(n,graph.add(node));}
 let mut roots=Vec::new();for n in g.node_indices(){if let AigNode::Output(pos)=aig.node_type(n){let e=g.edges_directed(n,Direction::Incoming).next()?;let base=ids[&e.source()];let root=if *e.weight(){graph.add(AigLang::Not(base))}else{base};roots.push((pos,root));}}
 roots.sort_by_key(|(p,_)|*p);graph.rebuild();let roots=roots.into_iter().map(|(p,id)|(p,graph.find(id))).collect();
 if let Some(path)=std::env::var_os("EGM_POOL_DIAG_PATH"){let path=std::path::Path::new(&path).with_extension("import.json");let _=std::fs::write(path,serde_json::json!({"actual_imported_enodes":graph.total_number_of_nodes(),"retained_xor_operators":actual_xor,"original_source_ands":g.node_indices().filter(|&n|matches!(aig.node_type(n),AigNode::And)).count(),"representation":"Exact pre-import XOR contraction; omitted internal functions not retained as hidden classes; all actual enodes count cumulatively; no regional reset. Not an unchanged expanded-AIG-node budget comparison."}).to_string());}
 Some((graph,roots))
}
''';p.write_text(s)
p=dst/'emapper/src/egraph_map.rs';s=p.read_text();s=s.replace('cheapest_nodes, cheapest_nodes_queued, import_aig, literal_inputs,','cheapest_nodes, cheapest_nodes_queued, import_aig, literal_inputs, xor_inputs,',1)
s=s.replace('node if literal_inputs(node).is_some() => {','node if literal_inputs(node).is_some() || xor_inputs(node).is_some() => {')
s=s.replace('let (a,b,phases)=literal_inputs(node).unwrap();','let is_xor=xor_inputs(node).is_some();let (a,b,phases)=literal_inputs(node).or_else(||xor_inputs(node)).unwrap();')
s=s.replace('let (a,b,_)=literal_inputs(node).unwrap();','let (a,b,_)=literal_inputs(node).or_else(||xor_inputs(node)).unwrap();')
s=s.replace('function|=u64::from(av&bv)<<assignment;','function|=u64::from(if is_xor{av^bv}else{av&bv})<<assignment;')
s=s.replace('Cut{leaves,function:left&right}','Cut{leaves,function:if is_xor{left^right}else{left&right}}')
s=s.replace('if let Some((a,b,_))=literal_inputs(&self.nodes[c]) {','if let Some((a,b,_))=literal_inputs(&self.nodes[c]).or_else(||xor_inputs(&self.nodes[c])) {')
s=s.replace('let (x,y,phases)=literal_inputs(&self.nodes[c]).expect("unknown logical macro");\n                (self.eval(self.ids[&x],vars,a,memo)^(phases&1!=0))\n                    & (self.eval(self.ids[&y],vars,a,memo)^(phases&2!=0))','let node=&self.nodes[c];let (x,y,phases)=literal_inputs(node).or_else(||xor_inputs(node)).expect("unknown logical macro");\n                let left=self.eval(self.ids[&x],vars,a,memo)^(phases&1!=0);let right=self.eval(self.ids[&y],vars,a,memo)^(phases&2!=0);if xor_inputs(node).is_some(){left^right}else{left&right}')
s=s.replace('let (graph, roots) = if literal_import {','let (graph, roots) = if std::env::var("EGM_XOR_IMPORT").as_deref()==Ok("1"){regions::import_xors(aig)}else if literal_import {',1)
p.write_text(s)
# Driver leaves baseline/model/guards and prepared inputs unchanged.
p=ROOT/'scripts/experiments/campaigns/bench_xor_import.py';assert not p.exists();s=(ROOT/'scripts/experiments/campaigns/bench_epoch_incumbent.py').read_text().replace('ap.add_argument("--metric-epochs"','ap.add_argument("--xor-import",type=int,choices=[0,1],default=0)\n    ap.add_argument("--metric-epochs"',1).replace('env = {k: v for k, v in os.environ.items() if not k.startswith("EGM_")}','env = {k: v for k, v in os.environ.items() if not k.startswith("EGM_")}\n    env["EGM_XOR_IMPORT"]=str(a.xor_import)',1);p.write_text(s)
print(dst)
