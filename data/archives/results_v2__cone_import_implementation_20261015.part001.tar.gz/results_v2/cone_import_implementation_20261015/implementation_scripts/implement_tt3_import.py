from pathlib import Path
import shutil
ROOT=Path('/home/flynn/workplace/MIGBalance');src=Path('/tmp/emapper-xor-import-20261015');dst=Path('/tmp/emapper-tt3-import-20261015');assert not dst.exists();dst.mkdir()
for name in ['Cargo.toml','Cargo.lock']:shutil.copy2(src/name,dst/name)
for name in ['emapper','src','tools']:shutil.copytree(src/name,dst/name,symlinks=True)
p=dst/'emapper/src/egraph_sat.rs';s=p.read_text();i=s.index('/// Exact XOR/XNOR internal operator.');s=s[:i]+'''/// Bounded exact three-input logical operator; the full truth table and every
/// child are stored in the counted e-node. No external Boolean cone is hidden.
pub(crate) fn tt3_inputs(node:&AigLang)->Option<(&[Id],u64)>{
 if let AigLang::Cell(sym,args)=node{if args.len()==3{let value=sym.as_str().strip_prefix("@egm_tt3_")?;let tt=u64::from_str_radix(value,16).ok()?;if tt<=255{return Some((args,tt))}}}None
}

'''+s[i:];s=s.replace('if xor_inputs(node).is_some(){3}else{usize::from(literal_inputs(node).is_some())}','if xor_inputs(node).is_some(){3}else if tt3_inputs(node).is_some(){2}else{usize::from(literal_inputs(node).is_some())}');p.write_text(s)
p=dst/'emapper/src/egraph_regions.rs';s=p.read_text();needle=' let mut needed=HashSet::new();let mut stack:Vec<_>=g.node_indices().filter';a=s.index(needle,s.index('pub(super) fn import_xors'))
s=s[:a]+''' let mut uses=HashMap::<_,usize>::new();for e in g.edge_references(){*uses.entry(e.source()).or_default()+=1;}
 let mut triples=HashMap::new();
 for n in g.node_indices(){if !matches!(aig.node_type(n),AigNode::And)||macros.contains_key(&n){continue}let outer=pair(n)?;
  for which in 0..2{let child=outer[which].0;if !matches!(aig.node_type(child),AigNode::And)||uses[&child]!=1||macros.contains_key(&child){continue}let inner=pair(child)?;let leaves:Vec<_>=[outer[1-which].0,inner[0].0,inner[1].0].into_iter().collect::<BTreeSet<_>>().into_iter().collect();if leaves.len()!=3{continue}let mut tt=0;for a in 0..8{let get=|node|((a>>leaves.binary_search(&node).unwrap())&1)!=0;let c=(get(inner[0].0)^inner[0].1)&(get(inner[1].0)^inner[1].1);let other=get(outer[1-which].0)^outer[1-which].1;tt|=u64::from((c^outer[which].1)&other)<<a;}triples.insert(n,(leaves,tt));break;}
 }
'''+s[a:]
s=s.replace('if let Some(v)=macros.get(&n){stack.extend(v.iter().map(|(n,_)|*n));}else{','if let Some((leaves,_))=triples.get(&n){stack.extend(leaves);}else if let Some(v)=macros.get(&n){stack.extend(v.iter().map(|(n,_)|*n));}else{',1)
s=s.replace('let mut topo=Topo::new(g);let mut actual_xor=0;','let mut topo=Topo::new(g);let mut actual_xor=0;let mut actual_tt3=0;',1)
s=s.replace('AigNode::And=>{if let Some(v)=macros.get(&n){','AigNode::And=>{if let Some((leaves,tt))=triples.get(&n){actual_tt3+=1;AigLang::Cell(format!("@egm_tt3_{tt:02x}").into(),leaves.iter().map(|n|ids[n]).collect())}else if let Some(v)=macros.get(&n){',1)
s=s.replace('"retained_xor_operators":actual_xor,','"retained_xor_operators":actual_xor,"retained_tt3_operators":actual_tt3,',1).replace('Exact pre-import XOR contraction','Exact pre-import XOR and unshared two-AND TT3 contraction')
p.write_text(s)
p=dst/'emapper/src/egraph_map.rs';s=p.read_text().replace('literal_inputs, xor_inputs,','literal_inputs, xor_inputs, tt3_inputs,',1)
# Fixed structural policy: use the richer import above 80% of node allowance.
s=s.replace('(xor_setting=="1" && compact_upper>ps.saturation.node_limit)','(xor_setting=="1" && compact_upper>ps.saturation.node_limit*4/5)',1).replace('Only original compact-overflow inputs use exact XOR contraction','Fixed 80%-of-node-limit compact-size threshold uses exact XOR/TT3 contraction',1)
# Mandatory direct truth cut; repeated class IDs are explicitly composed.
needle='''                node if literal_inputs(node).is_some() || xor_inputs(node).is_some() => {'''
a=s.index(needle,s.index('fn enumerate('));s=s[:a]+'''                node if tt3_inputs(node).is_some()=>{
                    let (args,tt)=tt3_inputs(node).unwrap();let inputs:Vec<_>=args.iter().map(|&id|index(id)).collect();let leaves:Vec<_>=inputs.iter().copied().collect::<BTreeSet<_>>().into_iter().collect();let mut function=0;
                    for assignment in 0..1usize<<leaves.len(){let tuple=inputs.iter().enumerate().map(|(p,id)|((assignment>>leaves.binary_search(id).unwrap())&1)<<p).sum::<usize>();function|=((tt>>tuple)&1)<<assignment;}reduce(Cut{leaves,function})
                }
'''+s[a:]
# Depth is only a heuristic; each macro is one real logical level.
needle='''                        _ => usize::MAX,''';a=s.index(needle,s.index('let mut boundary_depth'))
s=s[:a]+'''                        node if tt3_inputs(node).is_some()=>tt3_inputs(node).unwrap().0.iter().map(|&id|boundary_depth[index(id)]).max().unwrap_or(0).saturating_add(1),
'''+s[a:]
# A bounded one-leaf substitution beam avoids a hidden 16^3 Cartesian bank.
needle='''                    node if literal_inputs(node).is_some() || xor_inputs(node).is_some() => {''';a=s.index(needle,s.index('for _ in 0..ps.cut_rounds'))
s=s[:a]+'''                    node if tt3_inputs(node).is_some()=>{
                        for base in &old[c]{if base.leaves.contains(&c){continue}for (position,&leaf) in base.leaves.iter().enumerate(){for child in &old[leaf]{if child.leaves==vec![leaf]&&child.function==2{continue}let leaves:Vec<_>=base.leaves.iter().enumerate().filter_map(|(p,&s)|(p!=position).then_some(s)).chain(child.leaves.iter().copied()).collect::<BTreeSet<_>>().into_iter().collect();if leaves.len()>ps.max_inputs{continue}let mut function=0;for a in 0..1usize<<leaves.len(){let sub=child.leaves.iter().enumerate().map(|(p,s)|((a>>leaves.binary_search(s).unwrap())&1)<<p).sum::<usize>();let bit=((child.function>>sub)&1)as usize;let tuple=base.leaves.iter().enumerate().map(|(p,s)|if p==position{bit<<p}else{((a>>leaves.binary_search(s).unwrap())&1)<<p}).sum::<usize>();function|=((base.function>>tuple)&1)<<a;}let cut=reduce(Cut{leaves,function});pending.insert(if ps.canonical_phases{normalize_phase_cut(&cut,&phase_map)}else{cut});}}}
                    }
'''+s[a:]
# Conservative care cone traversal and exact truth evaluation.
s=s.replace('''                    if let Some((a,b,_))=literal_inputs(&self.nodes[c]).or_else(||xor_inputs(&self.nodes[c])) {''','''                    if let Some((args,_))=tt3_inputs(&self.nodes[c]){stack.extend(args.iter().map(|id|self.ids[id]));}
                    if let Some((a,b,_))=literal_inputs(&self.nodes[c]).or_else(||xor_inputs(&self.nodes[c])) {''',1)
s=s.replace('''            AigLang::Cell(_, _) => {
                let node=&self.nodes[c];''','''            ref node if tt3_inputs(node).is_some()=>{let (args,tt)=tt3_inputs(node).unwrap();let tuple=args.iter().enumerate().map(|(p,id)|usize::from(self.eval(self.ids[id],vars,a,memo))<<p).sum::<usize>();(tt>>tuple)&1!=0},
            AigLang::Cell(_, _) => {
                let node=&self.nodes[c];''',1)
# Actual call-site truth tests, including all edge phases and a shared interior PO.
a=s.index('    #[test]\n    fn exact_xor_contraction_keeps_shared_internal_outputs_and_all_input_phases')
s=s[:a]+'''    #[test]
    fn exact_tt3_import_truth_for_every_edge_phase_with_unused_inputs(){
      let tech=library("GATE AO 1.3 Y=(A*B)+C;\\nPIN A UNKNOWN 1 99 1 0 1 0\\nPIN B UNKNOWN 1 99 1 0 1 0\\nPIN C UNKNOWN 1 99 1 0 1 0\\nGATE AND3 1.3 Y=A*B*C;\\nPIN A UNKNOWN 1 99 1 0 1 0\\nPIN B UNKNOWN 1 99 1 0 1 0\\nPIN C UNKNOWN 1 99 1 0 1 0\\n");
      for phase in 0..16{let mut aig=graph();let a=input(&mut aig,1);let b=input(&mut aig,2);let c=input(&mut aig,3);input(&mut aig,4);let u=and(&mut aig,if phase&1!=0{inv(a)}else{a},if phase&2!=0{inv(b)}else{b});let v=and(&mut aig,if phase&4!=0{inv(u)}else{u},if phase&8!=0{inv(c)}else{c});output(&mut aig,v,0);
       let (g,_)=regions::import_xors(&aig).unwrap();assert!(g.classes().any(|c|c.nodes.iter().any(|n|tt3_inputs(n).is_some())));std::env::set_var("EGM_XOR_IMPORT","force");let ps=MapParams{strict_budgets:true,literal_auto:true,canonical_phases:true,canonical_wire_only:true,max_inputs:3,cuts_per_class:16,time_limit_secs:0.,..Default::default()};let mapped=map(&aig,&tech,&ps).unwrap();std::env::remove_var("EGM_XOR_IMPORT");assert_function(&mapped,4,|a|{let x=(a&1!=0)^(phase&1!=0);let y=(a&2!=0)^(phase&2!=0);let z=(a&4!=0)^(phase&8!=0);vec![((x&y)^(phase&4!=0))&z]});
      }
    }
'''+s[a:]
p.write_text(s)
p=ROOT/'scripts/experiments/campaigns/run_tt3_import.py';s=(ROOT/'scripts/experiments/campaigns/run_xor_import.py').read_text().replace('/tmp/emapper-xor-import-20261015','/tmp/emapper-tt3-import-20261015').replace('Isolated xor_import','Isolated tt3_import, fixed80% node-size policy and bounded exact XOR/TT3 operators');p.write_text(s)
print(dst)
