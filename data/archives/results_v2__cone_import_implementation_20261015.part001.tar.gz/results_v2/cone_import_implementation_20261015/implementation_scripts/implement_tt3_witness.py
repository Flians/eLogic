from pathlib import Path
import shutil
ROOT=Path('/home/flynn/workplace/MIGBalance');src=Path('/tmp/emapper-tt3-import-20261015');dst=Path('/tmp/emapper-tt3-witness-20261015');assert not dst.exists();dst.mkdir()
for name in ['Cargo.toml','Cargo.lock']:shutil.copy2(src/name,dst/name)
for name in ['emapper','src','tools']:shutil.copytree(src/name,dst/name,symlinks=True)
p=dst/'emapper/src/egraph_regions.rs';s=p.read_text();start=s.index('pub(super) fn import_xors(');s=s[:start]+'''#[derive(Clone,Copy)]
pub(super) struct SourceAnd{pub root:Id,pub left:Id,pub right:Id,pub left_neg:bool,pub right_neg:bool}

pub(super) fn import_xors(aig:&Aig)->Option<(egg::EGraph<AigLang,()>,Vec<(u32,Id)>)>{import_with_source(aig,false).map(|(g,r,_)|(g,r))}

/// All helper functions are actual imported nodes. The source AND certificate
/// only authorizes physical cut/match records in the ordinary bounded cut/pool
/// bank; it adds no egraph alternative or conditional union. No omitted function
/// may appear in any certificate or physical boundary.
pub(super) fn import_with_source(aig:&Aig,keep_helpers:bool)->Option<(egg::EGraph<AigLang,()>,Vec<(u32,Id)>,Vec<SourceAnd>)>{'''+s[s.index('{',start)+1:]
needle=''' while let Some(n)=stack.pop(){if !needed.insert(n){continue}''';i=s.index(needle,s.index('pub(super) fn import_with_source'));s=s[:i]+''' if keep_helpers{stack.extend(g.node_indices().filter(|&n|matches!(aig.node_type(n),AigNode::And)));}
'''+s[i:]
needle=''' roots.sort_by_key(|(p,_)|*p);graph.rebuild();let roots=roots.into_iter().map(|(p,id)|(p,graph.find(id))).collect();'''
s=s.replace(needle,needle+'''
 let mut source=Vec::new();for n in g.node_indices(){if !ids.contains_key(&n)||(!macros.contains_key(&n)&&!triples.contains_key(&n)){continue}let inputs=pair(n)?;if let(Some(&a),Some(&b))=(ids.get(&inputs[0].0),ids.get(&inputs[1].0)){source.push(SourceAnd{root:graph.find(ids[&n]),left:graph.find(a),right:graph.find(b),left_neg:inputs[0].1,right_neg:inputs[1].1});}}
''',1)
s=s.replace('"retained_tt3_operators":actual_tt3,','"retained_tt3_operators":actual_tt3,"all_original_helpers_retained":keep_helpers,"source_physical_witnesses":source.len(),',1)
a=s.index('pub(super) fn import_with_source');b=s.index('pub(super) fn compact_node_upper',a);chunk=s[a:b].replace('Some((graph,roots))','Some((graph,roots,source))');s=s[:a]+chunk+s[b:];p.write_text(s)
p=dst/'emapper/src/egraph_map.rs';s=p.read_text();s=s.replace('''    let (graph, roots) = if xor_import{regions::import_xors(aig)}else if literal_import {
        regions::import_literals(aig)
    } else if ps.region_classes > 0 {
        regions::import_demanded(aig)
    } else {
        import_aig(aig)
    }''','''    let (graph, roots, source_pairs) = if xor_import{regions::import_with_source(aig,compact_upper<=ps.saturation.node_limit)}else if literal_import {
        regions::import_literals(aig).map(|(g,r)|(g,r,Vec::new()))
    } else if ps.region_classes > 0 {
        regions::import_demanded(aig).map(|(g,r)|(g,r,Vec::new()))
    } else {
        import_aig(aig).map(|(g,r)|(g,r,Vec::new()))
    }''',1)
# Preserve the old enumerate interface for existing callers/tests.
a=s.index('fn enumerate(');b=s.index('    let index =',a);signature=s[a:b];new_signature=signature.replace('fn enumerate(','fn enumerate_with_source(',1).replace(') -> Vec<BTreeSet<Cut>> {','    source_pairs:&[regions::SourceAnd],\n) -> Vec<BTreeSet<Cut>> {',1);wrapper=signature+'    enumerate_with_source(nodes,ids,graph,tech,ps,stats,&[])\n}\n\n';s=s[:a]+wrapper+new_signature+s[b:]
# Certificates use only the post-SAT canonical IDs of actual imported functions.
a=s.index('    let area_quota =',s.index('fn enumerate_with_source'));s=s[:a]+'''    let mut source=vec![Vec::new();nodes.len()];
    for pair in source_pairs{source[index(pair.root)].push((index(pair.left),index(pair.right),pair.left_neg,pair.right_neg));}
'''+s[a:]
needle='''    let mandatory = cuts.clone();''';a=s.index(needle,s.index('fn enumerate_with_source'));s=s[:a]+'''    for (root,bank) in source.iter().enumerate(){for &(a,b,an,bn) in bank{
        let leaves:Vec<_>=[a,b].into_iter().collect::<BTreeSet<_>>().into_iter().collect();let mut function=0;for x in 0..1usize<<leaves.len(){let av=((x>>leaves.binary_search(&a).unwrap())&1!=0)^an;let bv=((x>>leaves.binary_search(&b).unwrap())&1!=0)^bn;function|=u64::from(av&bv)<<x;}let cut=reduce(Cut{leaves,function});let cut=if ps.canonical_phases{normalize_phase_cut(&cut,&phase_map)}else{cut};if !cut.leaves.contains(&root){cuts[root].insert(cut);}
    }}
'''+s[a:]
s=s.replace('''                    node if tt3_inputs(node).is_some()=>{
                        for base in &old[c]''','''                    node if tt3_inputs(node).is_some() && source[c].is_empty()=>{
                        for base in &old[c]''',1)
# If the original source boundary exists, use its exact two-input propagation;
# otherwise retain the bounded TT3 substitution path from the prior prototype.
needle='''            // Reserving structural cuts guarantees a finite fallback.''';a=s.index(needle,s.index('fn enumerate_with_source'));s=s[:a]+'''            for &(a,b,an,bn) in &source[c]{for x in &old[a]{for y in &old[b]{let leaves:Vec<_>=x.leaves.iter().chain(&y.leaves).copied().collect::<BTreeSet<_>>().into_iter().collect();if leaves.len()<=ps.max_inputs{let mut left=expand(x.function,&x.leaves,&leaves);let mut right=expand(y.function,&y.leaves,&leaves);if an{left^=mask(leaves.len());}if bn{right^=mask(leaves.len());}let cut=reduce(Cut{leaves,function:left&right});pending.insert(if ps.canonical_phases{normalize_phase_cut(&cut,&phase_map)}else{cut});}}}
'''+s[a:]
# Only the map call uses source-certified physical boundaries.
needle='''let cuts = enumerate(&nodes, &ids, graph, tech, &cut_params, &mut stats);'''
if needle not in s:
 print('MAP ENUMERATE CALL NEEDS FOLLOW-UP')
else:s=s.replace(needle,'''let cuts = enumerate_with_source(&nodes, &ids, graph, tech, &cut_params, &mut stats,&source_pairs);''',1)
p.write_text(s)
p=ROOT/'scripts/experiments/campaigns/run_tt3_witness.py';s=(ROOT/'scripts/experiments/campaigns/run_tt3_import.py').read_text().replace('/tmp/emapper-tt3-import-20261015','/tmp/emapper-tt3-witness-20261015').replace('Isolated tt3_import','Isolated tt3_witness, actual original helpers retained when within20k and exact source physical certificates within same cut/pool caps');p.write_text(s)
print(dst)
