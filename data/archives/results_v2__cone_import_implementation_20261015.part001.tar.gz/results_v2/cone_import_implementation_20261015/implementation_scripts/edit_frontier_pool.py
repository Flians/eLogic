from pathlib import Path
p=Path('/tmp/emapper-frontier-pool-20261015/emapper/src/egraph_map.rs');s=p.read_text()
needle='''    let diagnose = std::env::var("EGM_POOL_DIAG_PATH").ok();'''
pos=s.index(needle,s.index('fn cap_instances_impl('));s=s[:pos]+'''    cap_instances_reserved(instances,free,roots,budget,timing_cap,queued_witness,&BTreeSet::new())
}
fn cap_instances_reserved(instances:&mut Vec<Instance>,free:&[bool],roots:&[usize],budget:usize,timing_cap:bool,queued_witness:bool,reserved:&BTreeSet<usize>)->Result<usize,String>{
'''+s[pos:]
s=s.replace('''    let witness_kept = keep.len();
    if instances.len() <= budget {''','''    let witness_kept = keep.len();
    keep.extend(reserved.iter().copied());
    if keep.len()>budget{return Err("global retained pool below combined area/delay witnesses".into())}
    if instances.len() <= budget {''',1)
s=s.replace('''    if ps.library_timing || ps.strict_budgets {
        stats.instance_budget_pruned = cap_instances_impl(''','''    let mut frontier_charge=0.;let mut reserved=BTreeSet::new();
    if std::env::var("EGM_POOL_FRONTIER").as_deref()==Ok("1") {
        let t=Instant::now();let limit=t+std::time::Duration::from_secs_f64((ps.refine_time_secs*0.25).min(0.5));
        let mut status="deadline";let mut value=None;
        if let Some((mut cover,_))=delay_frontier_seed(&instances,&free,limit){
            if prune(&instances,&mut cover,&free,&required).is_ok(){value=Some(metrics(&instances,&cover,&free,&required));reserved.extend(cover.iter().flatten().map(|b|b.instance));status="validated";}
        }
        frontier_charge=t.elapsed().as_secs_f64();
        if let Some(path)=std::env::var_os("EGM_POOL_DIAG_PATH"){let path=std::path::Path::new(&path).with_extension("frontier.json");let _=std::fs::write(path,serde_json::json!({"status":status,"seconds":frontier_charge,"delay_cover_metrics":value,"reserved":reserved.len(),"charged_to_original_global_recovery":true}).to_string());}
    }
    if ps.library_timing || ps.strict_budgets {
        stats.instance_budget_pruned = cap_instances_reserved(''',1)
s=s.replace('''            ps.strict_budgets,
        )?;
        stats.instance_limit_hit''','''            ps.strict_budgets,
            &reserved,
        )?;
        stats.instance_limit_hit''',1)
s=s.replace('''    let chosen = extract(&instances, &free, &required, ps, &mut stats)?;
    let (area, delay)''','''    let mut extraction_params=ps.clone();
    if frontier_charge>=ps.refine_time_secs{return Err("budget: prepool frontier exhausted global recovery".into())}
    extraction_params.refine_time_secs-=frontier_charge;
    let chosen = extract(&instances, &free, &required, &extraction_params, &mut stats)?;
    stats.heuristic_secs+=frontier_charge;
    if ps.strict_budgets && stats.heuristic_secs>ps.refine_time_secs{return Err("budget: frontier plus recovery exceeds original global window".into())}
    let (area, delay)''',1)
s+='''\n#[cfg(test)] mod pool_frontier_regression {use super::*;
fn gate(input:usize,target:usize,area:f32,delay:f32)->Instance{Instance{cell:format!("g{target}_{area}_{delay}"),area,inputs:vec![input],pins:vec!["A".into()],outputs:vec![Output{pin:"Y".into(),function:2,delays:vec![delay],targets:vec![target]}]}}
#[test]fn early_target_roundrobin_cannot_discard_full_delay_witness(){
let original=vec![gate(0,2,1.,100.),gate(0,2,2.,1.),gate(2,1,1.,1.),gate(0,1,3.,10.)];let free=vec![true,false,false];let roots=vec![1];
let(mut full,_)=delay_frontier_seed(&original,&free,Instant::now()+std::time::Duration::from_secs(1)).unwrap();prune(&original,&mut full,&free,&roots).unwrap();assert_eq!(metrics(&original,&full,&free,&roots).1,2.);
let reserve=full.iter().flatten().map(|b|b.instance).collect();let mut limited=original.clone();cap_instances_reserved(&mut limited,&free,&roots,3,true,true,&reserve).unwrap();assert_eq!(limited.len(),3);let(mut c,_)=delay_frontier_seed(&limited,&free,Instant::now()+std::time::Duration::from_secs(1)).unwrap();prune(&limited,&mut c,&free,&roots).unwrap();assert_eq!(metrics(&limited,&c,&free,&roots).1,2.);
}
}
'''
# Reuse actual model names from existing tests below if necessary.
p.write_text(s)
