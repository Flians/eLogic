from pathlib import Path
import shutil
src=Path('/tmp/emapper-frontier-fast-20261015');dst=Path('/tmp/emapper-frontier-dag-tail-20261015');assert not dst.exists();dst.mkdir()
for name in ['Cargo.toml','Cargo.lock']:shutil.copy2(src/name,dst/name)
for name in ['emapper','src','tools']:shutil.copytree(src/name,dst/name,symlinks=True)
p=dst/'emapper/src/egraph_map.rs';s=p.read_text();a=s.index('''    let flow_deadline=if ps.fast_area_scan {''');s=s[:a]+'''    let pool_area_tail=std::env::var("EGM_POOL_FRONTIER").as_deref()==Ok("1");
    if pool_area_tail {
      let stage=Instant::now();let fixed=best.1;let full=frontier_state.as_ref().map_or(&witness,|(_,_,w)|w);
      for _ in 0..ps.refine_rounds {if Instant::now()>=deadline{break}stats.slack_attempts+=1;
       let Some(mut trial)=required_area_dag(instances,free,roots,&chosen,full,deadline)else{break};
       if prune(instances,&mut trial,free,roots).is_err(){break}stats.slack_valid+=1;let value=metrics(instances,&trial,free,roots);
       if value.1<=fixed+1e-6 && value.0<best.0-1e-6 && Instant::now()<deadline{chosen=trial;best=value;stats.slack_accepted+=1;stats.refinement_accepted+=1;}else{break}
      }
      recovery_event("deferred_dag_area_tail",stage,serde_json::json!({"fixed_delay":fixed,"area":best.0,"delay":best.1,"attempts":stats.slack_attempts,"accepted":stats.slack_accepted}));
    }
'''+s[a:]
# Existing general flow is replaced by the above bounded DAG pass, not run in addition.
s=s.replace('''        for _ in 0..ps.refine_rounds {
            if Instant::now() >= flow_deadline {''','''        for _ in 0..if pool_area_tail {0}else{ps.refine_rounds} {
            if Instant::now() >= flow_deadline {''',1)
p.write_text(s)
p=Path('/home/flynn/workplace/MIGBalance/scripts/experiments/campaigns/run_frontier_dag_tail.py');s=Path('/home/flynn/workplace/MIGBalance/scripts/experiments/campaigns/run_frontier_fast.py').read_text().replace('/tmp/emapper-frontier-fast-20261015','/tmp/emapper-frontier-dag-tail-20261015').replace('Isolated frontier_fast','Isolated frontier_dag_tail, bounded acyclic fixed-delay area sweeps replace general slack worklist');p.write_text(s)
