from pathlib import Path
import shutil
ROOT=Path('/home/flynn/workplace/MIGBalance');src=Path('/tmp/emapper-tt3-witness-20261015');dst=Path('/tmp/emapper-tt3-helpers-20261015');assert not dst.exists();dst.mkdir()
for name in ['Cargo.toml','Cargo.lock']:shutil.copy2(src/name,dst/name)
for name in ['emapper','src','tools']:shutil.copytree(src/name,dst/name,symlinks=True)
p=dst/'emapper/src/egraph_regions.rs';s=p.read_text();needle='''pub(super) fn import_with_source(aig:&Aig,keep_helpers:bool)->Option<(egg::EGraph<AigLang,()>,Vec<(u32,Id)>,Vec<SourceAnd>)>{''';s=s.replace(needle,needle+'''
 import_with_helpers(aig,if keep_helpers{usize::MAX}else{0},usize::MAX)
}
pub(super) fn import_with_helpers(aig:&Aig,helper_quota:usize,node_allowance:usize)->Option<(egg::EGraph<AigLang,()>,Vec<(u32,Id)>,Vec<SourceAnd>)>{''',1)
s=s.replace(''' if keep_helpers{stack.extend(g.node_indices().filter(|&n|matches!(aig.node_type(n),AigNode::And)));}
''','',1)
# Select helper functions only after the minimal globally live import is planned.
needle=''' let mut graph=egg::EGraph::default();let mut ids=HashMap::new();let mut topo=Topo::new(g);let mut actual_xor=0;let mut actual_tt3=0;'''
s=s.replace(needle,''' let mut helpers=HashSet::new();
 if helper_quota==usize::MAX {for n in g.node_indices(){if matches!(aig.node_type(n),AigNode::And)&&!needed.contains(&n){helpers.insert(n);needed.insert(n);}}}
 else if helper_quota>0 {
  let mut topo=Topo::new(g);let mut order=Vec::new();let mut depth=HashMap::new();while let Some(n)=topo.next(g){let d=if matches!(aig.node_type(n),AigNode::And){let v=pair(n)?;depth[&v[0].0].max(depth[&v[1].0])+1usize}else if matches!(aig.node_type(n),AigNode::Output(_)){let e=g.edges_directed(n,Direction::Incoming).next()?;depth[&e.source()]}else{0};depth.insert(n,d);order.push(n);}
  let maximum=order.iter().filter(|&&n|matches!(aig.node_type(n),AigNode::Output(_))).map(|n|depth[n]).max().unwrap_or(0);let mut required=HashMap::<_,usize>::new();for &n in &order{if matches!(aig.node_type(n),AigNode::Output(_)){required.insert(n,maximum);}}
  for &n in order.iter().rev(){if let Some(&r)=required.get(&n){let child_r=r.saturating_sub(usize::from(matches!(aig.node_type(n),AigNode::And)));for e in g.edges_directed(n,Direction::Incoming){required.entry(e.source()).and_modify(|v|*v=(*v).min(child_r)).or_insert(child_r);}}}
  let mut groups=Vec::new();for &n in &needed{if !matches!(aig.node_type(n),AigNode::And)||(!macros.contains_key(&n)&&!triples.contains_key(&n)){continue}let original=pair(n)?;let missing:Vec<_>=original.iter().map(|v|v.0).filter(|n|!needed.contains(n)).collect::<BTreeSet<_>>().into_iter().collect();if missing.is_empty(){continue}if missing.iter().all(|n|matches!(aig.node_type(*n),AigNode::And)&&pair(*n).is_some_and(|v|v.iter().all(|(c,_)|needed.contains(c)))){groups.push((required.get(&n).copied().unwrap_or(usize::MAX).saturating_sub(depth[&n]),std::cmp::Reverse(depth[&n]),n,missing));}}
  groups.sort_by_key(|(slack,d,n,_)|(*slack,*d,*n));let output_not:HashSet<_>=g.node_indices().filter(|&n|matches!(aig.node_type(n),AigNode::Output(_))).flat_map(|n|g.edges_directed(n,Direction::Incoming)).filter(|e|*e.weight()).map(|e|e.source()).collect();let base=needed.iter().filter(|&&n|!matches!(aig.node_type(n),AigNode::Output(_))).count()+output_not.len();let ceiling=node_allowance.saturating_mul(9)/10;
  for (_,_,_,missing) in groups{let novel:Vec<_>=missing.into_iter().filter(|n|!needed.contains(n)).collect();if helpers.len()+novel.len()>helper_quota||base+helpers.len()+novel.len()>ceiling{continue}for n in novel{needed.insert(n);helpers.insert(n);}}
 }
 let mut graph=egg::EGraph::default();let mut ids=HashMap::new();let mut topo=Topo::new(g);let mut actual_xor=0;let mut actual_tt3=0;''',1)
s=s.replace('''AigNode::And=>{if let Some((leaves,tt))=triples.get(&n){''','''AigNode::And=>{if let Some((leaves,tt))=triples.get(&n).filter(|_|!helpers.contains(&n)){''',1)
s=s.replace('''}else if let Some(v)=macros.get(&n){actual_xor''','''}else if let Some(v)=macros.get(&n).filter(|_|!helpers.contains(&n)){actual_xor''',1)
s=s.replace('''if !ids.contains_key(&n)||(!macros.contains_key(&n)&&!triples.contains_key(&n)){continue}''','''if !ids.contains_key(&n)||helpers.contains(&n)||(!macros.contains_key(&n)&&!triples.contains_key(&n)){continue}''',1)
s=s.replace('''"all_original_helpers_retained":keep_helpers,''','''"all_original_helpers_retained":helper_quota==usize::MAX,"helper_quota":helper_quota,"actual_helpers":helpers.len(),"helper_node_reserve_fraction":0.1,''',1)
p.write_text(s)
p=dst/'emapper/src/egraph_map.rs';s=p.read_text().replace('regions::import_with_source(aig,compact_upper<=ps.saturation.node_limit)','regions::import_with_helpers(aig,2048,ps.saturation.node_limit)',1);p.write_text(s)
p=ROOT/'scripts/experiments/campaigns/run_tt3_helpers.py';s=(ROOT/'scripts/experiments/campaigns/run_tt3_witness.py').read_text().replace('/tmp/emapper-tt3-witness-20261015','/tmp/emapper-tt3-helpers-20261015').replace('Isolated tt3_witness','Isolated tt3_helpers, structural-slack ordered helper groups quota2048 and10% preimport rewrite reserve');p.write_text(s)
print(dst)
