from pathlib import Path
import shutil
src=Path('/tmp/emapper-frontier-tail-20261015');dst=Path('/tmp/emapper-frontier-fast-20261015');assert not dst.exists();dst.mkdir()
for name in ['Cargo.toml','Cargo.lock']:shutil.copy2(src/name,dst/name)
for name in ['emapper','src','tools']:shutil.copytree(src/name,dst/name,symlinks=True)
p=dst/'emapper/src/egraph_map.rs';s=p.read_text();a=s.index('fn delay_frontier_seed(');b=s.index('// One constrained area-flow sweep',a);old=s[a:b].replace('fn delay_frontier_seed(','fn delay_frontier_seed_reference(',1)
s=s[:a]+s[a:b].replace('''        let inputs:BTreeSet<_>=m.inputs.iter().copied().collect();''','''        // Same distinct physical dependencies without one tree allocation per instance.
        let inputs=m.inputs.iter().enumerate().filter(|(p,x)|!m.inputs[..*p].contains(x)).map(|(_,x)|*x).collect::<Vec<_>>();''').replace('for &x in &inputs','for &x in &inputs')+s[b:]
# Remove even the small Vec allocation using a reusable inline bank for common arities.
s=s.replace('''let inputs=m.inputs.iter().enumerate().filter(|(p,x)|!m.inputs[..*p].contains(x)).map(|(_,x)|*x).collect::<Vec<_>>();''','''let mut unique=[0usize;6];let mut count=0;for &x in &m.inputs{if !unique[..count].contains(&x){unique[count]=x;count+=1;}}let inputs=&unique[..count];''').replace('for &x in &inputs{if !known[x]','for &x in inputs{if !known[x]')
# Physical interface validation already limits fanin <=6; keep an explicit fallback for synthetic tests/future API users.
s=s.replace('''let mut unique=[0usize;6];let mut count=0;for &x in &m.inputs{if !unique[..count].contains(&x){unique[count]=x;count+=1;}}let inputs=&unique[..count];''','''let mut unique=[0usize;6];let mut count=0;let fallback:Vec<_>;let inputs=if m.inputs.len()<=6{for &x in &m.inputs{if !unique[..count].contains(&x){unique[count]=x;count+=1;}}&unique[..count]}else{fallback=m.inputs.iter().copied().collect::<BTreeSet<_>>().into_iter().collect();&fallback[..]};''')
s+='\n#[cfg(test)]\n'+old
s+='''
#[cfg(test)]mod ready_inline_equivalence{use super::*;
#[test]fn all_bindings_match_reference_with_duplicate_inputs_cycles_and_nonarcs(){
 for seed in 0..128{let n=24;let free:Vec<_>=(0..n).map(|s|s<3).collect();let mut m=Vec::new();for i in 0..160{let count=1+(i+seed)%4;let inputs:Vec<_>=(0..count).map(|p|(i*13+p*seed+seed)%n).collect();m.push(Instance{cell:format!("c{i}"),area:((i+seed)%11)as f32+0.1,inputs,input_pins:(0..count).map(|p|format!("p{p}")).collect(),outputs:vec![OutputPin{name:"Y".into(),delays:vec![((i*3+seed)%7)as f32;count],function:if i%5==0{2}else{1u64<<((1usize<<count)-1)},targets:vec![(i*7+seed)%n]}]});}
 let run=|reference:bool|{let (c,nonarc)=if reference{delay_frontier_seed_reference(&m,&free,Instant::now()+std::time::Duration::from_secs(5))}else{delay_frontier_seed(&m,&free,Instant::now()+std::time::Duration::from_secs(5))}.unwrap();(c.into_iter().map(|b|b.map(|x|(x.instance,x.pin))).collect::<Vec<_>>(),nonarc)};assert_eq!(run(false),run(true),"seed {seed}");
 }
}
}
''';p.write_text(s)
p=Path('/home/flynn/workplace/MIGBalance/scripts/experiments/campaigns/run_frontier_fast.py');s=Path('/home/flynn/workplace/MIGBalance/scripts/experiments/campaigns/run_frontier_tail.py').read_text().replace('/tmp/emapper-frontier-tail-20261015','/tmp/emapper-frontier-fast-20261015').replace('Isolated frontier_tail','Isolated frontier_fast, same bindings with inline dependencies');p.write_text(s)
