from pathlib import Path
import shutil
src=Path('/tmp/emapper-frontier-pool-20261015');dst=Path('/tmp/emapper-frontier-tail-20261015');assert not dst.exists();dst.mkdir()
for name in ['Cargo.toml','Cargo.lock']:shutil.copy2(src/name,dst/name)
for name in ['emapper','src','tools']:shutil.copytree(src/name,dst/name,symlinks=True)
p=dst/'emapper/src/egraph_map.rs';s=p.read_text();s=s.replace('''    let flow_deadline=if ps.fast_area_scan {''','''    let mut saved_legacy=None;
    if std::env::var("EGM_POOL_FRONTIER").as_deref()==Ok("1") {
        if let Some((trial,value))=&deferred_area {if better_cover(*value,best,ps){saved_legacy=Some((chosen.clone(),best));chosen=trial.clone();best=*value;recovery_event("deferred_area_stage_start",Instant::now(),serde_json::json!({"area":best.0,"delay":best.1,"legacy_backup_valid":true}));}}
    }
    let flow_deadline=if ps.fast_area_scan {''',1)
s=s.replace('''    // Both covers have already passed whole-cover validation in this immutable pool.''','''    if let Some((old,value))=saved_legacy {if better_cover(value,best,ps){chosen=old;best=value;}}
    // Both covers have already passed whole-cover validation in this immutable pool.''',1)
s=s.replace('''    extraction_params.refine_time_secs-=frontier_charge;
    let chosen''','''    extraction_params.refine_time_secs-=frontier_charge;
    if std::env::var("EGM_POOL_FRONTIER").as_deref()==Ok("1"){extraction_params.area_time_fraction=0.25;extraction_params.fast_area_scan=true;}
    let chosen''',1)
p.write_text(s)
p=Path('/home/flynn/workplace/MIGBalance/scripts/experiments/campaigns/run_frontier_tail.py');s=Path('/home/flynn/workplace/MIGBalance/scripts/experiments/campaigns/run_frontier_pool.py').read_text().replace('/tmp/emapper-frontier-pool-20261015','/tmp/emapper-frontier-tail-20261015').replace('Isolated frontier_pool','Isolated frontier_tail, reserve25% tail for deferred incumbent fixed-delay area recovery');p.write_text(s)
