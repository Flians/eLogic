# Region, library timing and phase recovery

All 20 EPFL designs remain in this report, including budget failures. Inputs reuse the one verified resyn2 AIG. The comparison is against the same native binary with experimental options disabled, not a claim of baseline dominance.

Attempted jobs: 80/80. Verified pairs: 22; delay better/equal/worse: 16/2/4.

|Library|Objective|Design|Control area|Control delay|Candidate area|Candidate delay|Status|
|---|---|---|---:|---:|---:|---:|---|
|3|delay-area|adder|76.83|3016.20|97.49|3130.00|ok/ok|
|3|delay-area|bar|298.45|191.85|290.21|193.78|ok/ok|
|3|delay-area|div|—|—|—|—|failed/failed|
|3|delay-area|hyp|—|—|—|—|failed/failed|
|3|delay-area|log2|—|—|—|—|failed/failed|
|3|delay-area|max|297.32|2735.12|319.06|2683.82|ok/ok|
|3|delay-area|multiplier|—|—|—|—|failed/failed|
|3|delay-area|sin|670.17|2806.05|763.09|2580.93|ok/ok|
|3|delay-area|sqrt|—|—|—|—|failed/failed|
|3|delay-area|square|—|—|—|—|failed/failed|
|3|delay-area|arbiter|—|—|—|—|failed/failed|
|3|delay-area|cavlc|46.52|197.59|47.24|194.91|ok/ok|
|3|delay-area|ctrl|7.76|108.06|7.86|98.66|ok/ok|
|3|delay-area|dec|27.68|82.92|29.48|82.92|ok/ok|
|3|delay-area|i2c|84.09|166.78|90.97|168.95|ok/ok|
|3|delay-area|int2float|14.47|183.34|14.28|183.34|ok/ok|
|3|delay-area|mem_ctrl|—|—|—|—|failed/failed|
|3|delay-area|priority|70.72|2062.18|59.60|2042.28|ok/ok|
|3|delay-area|router|13.94|216.40|14.94|190.00|ok/ok|
|3|delay-area|voter|—|—|—|—|failed/failed|
|4|delay-area|adder|82.22|3550.84|120.90|3012.52|ok/ok|
|4|delay-area|bar|325.28|191.11|400.98|180.28|ok/ok|
|4|delay-area|div|—|—|—|—|failed/failed|
|4|delay-area|hyp|—|—|—|—|failed/failed|
|4|delay-area|log2|—|—|—|—|failed/failed|
|4|delay-area|max|269.86|3090.61|388.32|2504.82|ok/ok|
|4|delay-area|multiplier|—|—|—|—|failed/failed|
|4|delay-area|sin|703.93|2640.42|1074.89|2165.30|ok/ok|
|4|delay-area|sqrt|—|—|—|—|failed/failed|
|4|delay-area|square|—|—|—|—|failed/failed|
|4|delay-area|arbiter|—|—|—|—|failed/failed|
|4|delay-area|cavlc|45.72|194.95|45.89|191.55|ok/ok|
|4|delay-area|ctrl|7.56|103.17|7.46|98.66|ok/ok|
|4|delay-area|dec|29.54|66.15|32.72|68.10|ok/ok|
|4|delay-area|i2c|82.74|176.27|93.77|170.06|ok/ok|
|4|delay-area|int2float|14.08|182.22|14.41|181.00|ok/ok|
|4|delay-area|mem_ctrl|—|—|—|—|failed/failed|
|4|delay-area|priority|61.04|2047.24|69.64|2043.80|ok/ok|
|4|delay-area|router|13.55|199.00|14.56|184.25|ok/ok|
|4|delay-area|voter|—|—|—|—|failed/failed|

Failed cases retain command logs and reports in the checkpoint campaign. Node limits are global; regions do not receive separate budgets. Area increases and all delay regressions remain reported.
