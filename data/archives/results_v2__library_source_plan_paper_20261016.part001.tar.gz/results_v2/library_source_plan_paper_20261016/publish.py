"""Publish only the reviewed six-body-plus-one-reference PDF."""
from pathlib import Path
import shutil,json,hashlib,difflib,subprocess,re
root=Path('/home/flynn/workplace/MIGBalance');out=Path(__file__).resolve().parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
pdf=out/'main.pdf';tex=root/'epmapping_paper/DAC-eGraphMap-draft/main.tex'
info=subprocess.check_output(['pdfinfo',str(pdf)],text=True);(out/'pdfinfo.txt').write_text(info);assert re.search(r'Pages:\s+7\b',info)
text=subprocess.check_output(['pdftotext','-layout',str(pdf),'-'],text=True);(out/'final_layout.txt').write_text(text);pages=[p for p in text.split('\f') if p.strip()];assert len(pages)==7 and re.sub(r'\s+','',pages[6]).startswith('REFERENCES')
log=(out/'pass5.log').read_text();assert 'Overfull' not in log and 'LaTeX Warning:' not in log
for n in range(1,8):assert (out/f'page-{n}.png').is_file()
qa=dict(pages=7,body_pages=6,reference_pages=1,all_pages_visually_checked=list(range(1,8)),visual_result='No clipping, overlaps, unreadable tables or equations. Standard conference font/margins unchanged; underfull table-page spacing visually acceptable.',primary_tables_unchanged=True,table_count=4,preamble_unchanged=True,latex_overfull=False,latex_warnings=False,underfull_messages_preserved=True,rejected_eight_page_attempt_retained=True,pdf_sha256=sha(pdf),tex_sha256=sha(tex),page_sha256={str(i):sha(out/f'page-{i}.png') for i in range(1,8)})
(out/'paper_qa.json').write_text(json.dumps(qa,indent=2)+'\n')
shutil.copy2(pdf,root/'output/pdf/DAC-eGraphMap-draft.pdf');shutil.copy2(pdf,tex.with_suffix('.pdf'))
for stem in ['joined_source_plan','library_source_plan']:
 base=root/'results_v2'/f'{stem}_implementation_20261016';frozen=base/'frozen_source';lines=[]
 for p in sorted(frozen.rglob('*.rs')):
  rel=p.relative_to(frozen);old=root/rel;before=old.read_text().splitlines(keepends=True) if old.exists() else []
  lines.extend(difflib.unified_diff(before,p.read_text().splitlines(keepends=True),fromfile='main/'+str(rel),tofile=stem+'/'+str(rel)))
 (base/'diff_main.patch').write_text(''.join(lines))
print('Published verified6+1; all4tables unchanged; prototype patches archived')
