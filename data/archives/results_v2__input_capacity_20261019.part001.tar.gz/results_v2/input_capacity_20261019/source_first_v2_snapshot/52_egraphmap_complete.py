#!/usr/bin/env python3
"""Explicit source-first scalability protocol; no baseline mapping is invoked.
The old bounded optimizer is attempted unchanged. An import-only refusal may
retry with the remaining input-scaled cumulative allowance. Admitted nodes
from failed attempts are NOT refunded. Both attempts share one60s window;
construction, attempts and export all count toward the300s mapping deadline.
"""
import json,sys,os,time,math,shutil,subprocess,resource,hashlib
from pathlib import Path
from source_cover import build_source_cover

def main():
 start=time.monotonic();deadline=start+300
 if len(sys.argv)!=4:raise ValueError('expected genlib prepared-AIG output-Verilog')
 library,subject,out=map(Path,sys.argv[1:]);child=Path(__file__).resolve().parents[3]/'target/release/bench_rs_egraph_map';models=library.parent/'library.json';meta=out.with_suffix('.complete.json');source=out.with_suffix('.source.v');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
 text,seed=build_source_cover(subject.read_bytes(),models,deadline);source.write_text(text)
 bank_limit=int(os.environ['EGM_INSTANCES']);global_pool=int(os.environ['EGM_GLOBAL_INSTANCES']);global_nodes=int(os.environ['EGM_NODES']);assert seed['instances']+bank_limit<=global_pool
 info=dict(policy='source-first-input-capacity-v2',mapping_limit_secs=300,optimizer_shared_window_secs=60,optimizer_recovery_secs=float(os.environ['EGM_REFINE_TIME']),global_cumulative_node_allowance=global_nodes,optimizer_pool_limit=bank_limit,global_retained_candidate_limit=global_pool,source=seed,source_verilog=str(source),source_sha256=sha(source),subject_sha256=sha(subject),library_sha256=sha(library),library_models_sha256=sha(models),native_optimizer=str(child),native_optimizer_sha256=sha(child),frontend_sha256=sha(__file__),optimizer_succeeded=False,selected='source_witness',unconditional_CEC_required=True,old_fixed20k_protocol=False,attempts=[],no_refund_on_retry=True,source_construction_is_inside300s_outside_native_recovery_window=True)
 chosen=source;metrics=dict(area=seed['area'],delay=seed['delay'],cec=-1,status='source-witness-fallback',proven_optimal=False,egraph_cover_selected=False);opt_end=min(time.monotonic()+60,deadline-20);accounted=0
 for index in range(2):
  limit=min(20000,global_nodes)if index==0 else global_nodes-accounted
  remaining=opt_end-time.monotonic()
  if remaining<=0 or limit<=0:break
  prefix=out.parent/f'attempt{index}';worker=prefix.with_suffix('.v');pool=prefix.with_suffix('.pool.json');diag=prefix.with_suffix('.candidates.json');trace=prefix.with_suffix('.trace.json');ledger=pool.with_suffix('.admission.json')
  env=dict(os.environ,EGM_NOCEC='1',EGM_NODES=str(limit),EGM_POOL_DIAG_PATH=str(pool),EGM_DIAG_PATH=str(diag),EGM_RECOVERY_TRACE=str(trace));argv=[str(child),str(library),str(subject),str(worker)]
  def memory_guard():resource.setrlimit(resource.RLIMIT_AS,(16*1024**3,16*1024**3))
  t=time.monotonic();p=subprocess.Popen(argv,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,preexec_fn=memory_guard);timeout=False
  try:stdout,stderr=p.communicate(timeout=remaining)
  except subprocess.TimeoutExpired:timeout=True;p.kill();stdout,stderr=p.communicate()
  prefix.with_suffix('.stdout').write_text(stdout);prefix.with_suffix('.stderr').write_text(stderr);a=json.loads(ledger.read_text())if ledger.exists()else None
  # A killed attempt without a final ledger is conservatively charged its full
  # reservation. The next attempt never receives a fresh independent budget.
  charge=a['cumulative_admitted_enodes']if a else limit;assert 0<=charge<=limit;accounted+=charge;assert accounted<=global_nodes
  records=[json.loads(l)for l in stdout.splitlines()if l.startswith('{"area":')];ok=p.returncode==0 and len(records)==1 and worker.is_file() and all(math.isfinite(records[0][k])for k in ['area','delay'])
  event=dict(index=index,argv=argv,node_allowance=limit,charged_admission_upper=charge,charge_is_measured=a is not None,cumulative_accounted_upper=accounted,admission=a,admission_path=str(ledger),pool_path=str(pool),candidate_path=str(diag),trace_path=str(trace),stdout_path=str(prefix.with_suffix('.stdout')),stderr_path=str(prefix.with_suffix('.stderr')),exit_code=p.returncode,timeout=timeout,wall_secs=time.monotonic()-t,complete_returned_cover=ok)
  info['attempts'].append(event)
  if ok:
   z=records[0];assert z['cumulative_admitted_enodes']<=limit and z['instances']<=bank_limit;info['optimizer_succeeded']=True;info['optimizer_native']=z
   if (z['delay'],z['area'])<(metrics['delay'],metrics['area']):chosen=worker;metrics=dict(area=z['area'],delay=z['delay'],cec=-1,status='checked-native-egraph-cover',proven_optimal=False,egraph_cover_selected=True);info['selected']='egraph_cover';info['selected_attempt']=index
   break
  # Retry only a proved incomplete import, not arbitrary timeout/recovery error.
  if not(a and not a['import_complete'] and a['rejected_before_insertion']):break
 info.update(cumulative_accounted_enode_upper=accounted,optimizer_address_space_limit_bytes=16*1024**3,source_plus_optimizer_retained_upper=seed['instances']+bank_limit,parent_peak_rss_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024,optimizer_peak_rss_bytes=resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss*1024,sum_of_process_peak_rss_is_conservative=True)
 shutil.copyfile(chosen,out);info['selected_verilog_sha256']=sha(out);info['total_mapping_frontend_secs']=time.monotonic()-start
 if time.monotonic()>deadline:raise TimeoutError('complete frontend exceeded300s; no success reported')
 meta.write_text(json.dumps(info,indent=2));metrics.update(source_first=True,optimization_succeeded=info['optimizer_succeeded'],selected_mode=info['selected'],source_instances=seed['instances'],global_retained_candidate_limit=global_pool,cumulative_accounted_enode_upper=accounted,total_mapping_frontend_secs=info['total_mapping_frontend_secs'])
 print(json.dumps(metrics,separators=(',',':')),flush=True)
if __name__=='__main__':main()
