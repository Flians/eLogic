"""Constructive source-AIG library cover, used only as a checked incumbent.
No baseline tool is called. There is no egraph search in this constructor.
"""
import json,math,time
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'prototypes'))
from region_stitch import read_binary_aig,symbols,identifier

def build_source_cover(data,library_json,deadline):
 start=time.monotonic()
 if start>deadline:raise TimeoutError("source-cover construction exceeds mapping deadline")
 inputs,roots,gates=read_binary_aig(data);ins,outs=symbols(data,inputs,roots,gates)
 live=set();todo=list(roots)
 while todo:
  v=todo.pop()//2
  if v in gates and v not in live:live.add(v);todo.extend(gates[v])
 cells=json.loads(Path(library_json).read_text());names=[c['name']for c in cells]
 def choose(arity,truth):
  xs=[c for c in cells if len(c['vars'])==arity and c['tt'][0]==truth and names.count(c['name'])==1]
  if not xs:raise ValueError('source cover requires unique single-output AND2 and INV cells')
  return min(xs,key=lambda c:(max(c['pin_delay'].values(),default=0),c['area'],c['name']))
 and2=choose(2,8);inv=choose(1,1);prefix='_egm_source_'
 while any(n.startswith(prefix)for n in ins+outs):prefix+='x'
 neg={x//2 for x in roots if x>1 and x&1};neg.update(x//2 for v in live for x in gates[v]if x>1 and x&1)
 arrival={0:0.,1:0.};areas=[];count=0;lines=['module mapped('+', '.join(['input '+identifier(n)for n in ins]+['output '+identifier(n)for n in outs])+');']
 def net(lit):
  if lit<2:return "1'b1"if lit else"1'b0"
  v=lit//2
  if v<=inputs and not lit&1:return identifier(ins[v-1])
  return prefix+('m'if lit&1 else'p')+str(v)
 def emit(cell,args,out,label):
  nonlocal count
  if time.monotonic()>deadline:raise TimeoutError('source-cover construction exceeds mapping deadline')
  count+=1;areas.append(cell['area']);lines.append('wire '+out+';');pins=[f'.{identifier(p)}({net(x)})'for p,x in zip(cell['vars'],args)];pins.append(f'.{identifier(cell["out_pin"])}({out})');lines.append(f'{identifier(cell["name"])} {prefix}{label}('+', '.join(pins)+');')
  arrival[(int(out[len(prefix)+1:])*2)+(out[len(prefix)]=='m')]=max((arrival[x]+cell['pin_delay'][p]for p,x in zip(cell['vars'],args)),default=0.)
 for v in range(1,inputs+1):
  arrival[2*v]=0.
  if v in neg:emit(inv,[2*v],net(2*v+1),'i'+str(v))
 for v in sorted(live):
  x,y=gates[v];args=min([(x,y),(y,x)],key=lambda a:(max(arrival[t]+and2['pin_delay'][p]for p,t in zip(and2['vars'],a)),a))
  emit(and2,args,net(2*v),'a'+str(v))
  if v in neg:emit(inv,[2*v],net(2*v+1),'i'+str(v))
 for name,root in zip(outs,roots):lines.append('assign '+identifier(name)+' = '+net(root)+';')
 lines.append('endmodule');assert count==len(live)+len(neg)
 stats=dict(area=math.fsum(areas),delay=max((arrival[x]for x in roots),default=0.),instances=count,live_source_ands=len(live),shared_source_inverters=len(neg),source_build_secs=time.monotonic()-start,input_names=ins,output_names=outs,source_cells=[and2['name'],inv['name']],proof='Exact AND2 per live original AIG gate, one shared INV per demanded negative variable, named ports preserved; independent CEC still required',egraph_search=False)
 if time.monotonic()>deadline:raise TimeoutError('source-cover construction exceeds mapping deadline')
 return '\n'.join(lines)+'\n',stats
