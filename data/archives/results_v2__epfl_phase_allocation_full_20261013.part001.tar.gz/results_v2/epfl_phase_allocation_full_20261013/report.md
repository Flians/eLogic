# Phase-time allocation within the unchanged global recovery budget

Both profiles enable region256 and phase recovery. Candidate fraction=0.25; control fraction=1.0. The stage deadline partitions the remaining global two-second recovery window, checked between atomic trials. An atomic trial is not preempted. Node/cut/pool/saturation/global-recovery/mapping budgets and all other settings are unchanged. Defaults remain unchanged; the experimental fraction requires an explicit option.

160/160 attempts: 88 CEC-successful covers, 72 node-budget failures; all 20 designs and both libraries/objectives are retained. Same-binary paired study; not a claim of baseline dominance or runtime stability.

area-delay: {"pairs": 22, "delay_better_equal_worse": [1, 17, 4], "area_better_equal_worse": [6, 15, 1], "zero_local_candidate": 0, "zero_local_control": 4}
delay-area: {"pairs": 22, "delay_better_equal_worse": [2, 20, 0], "area_better_equal_worse": [6, 16, 0], "zero_local_candidate": 0, "zero_local_control": 4}

|Library|Objective|Design|Control area/delay|Candidate area/delay|Candidate/control local trials|
|---|---|---|---|---|---:|
|3|area-delay|adder|62.88/3944.30|62.88/3944.30|5249/5249|
|3|area-delay|bar|220.03/252.49|220.03/252.49|1528/1486|
|3|area-delay|cavlc|39.79/262.80|39.79/262.80|8088/8088|
|3|area-delay|ctrl|7.05/134.48|7.05/134.48|5740/5740|
|3|area-delay|dec|27.59/91.66|27.59/91.66|3852/3852|
|3|area-delay|i2c|73.39/244.72|73.35/244.72|6696/6321|
|3|area-delay|int2float|13.26/235.71|13.26/235.71|5428/5428|
|3|area-delay|max|291.08/3303.60|239.89/3340.31|1298/127|
|3|area-delay|priority|49.56/2744.19|49.56/2744.19|6156/6156|
|3|area-delay|router|11.44/340.73|11.44/340.73|7139/7139|
|3|area-delay|sin|570.20/3138.50|530.16/3163.27|512/0|
|3|delay-area|adder|76.25/2849.22|76.25/2849.22|9256/8975|
|3|delay-area|bar|295.43/191.85|295.43/191.85|1664/1629|
|3|delay-area|cavlc|46.59/197.59|46.59/197.59|9761/9761|
|3|delay-area|ctrl|7.78/108.06|7.78/108.06|7636/7636|
|3|delay-area|dec|27.68/82.92|27.68/82.92|3882/3882|
|3|delay-area|i2c|84.16/166.78|83.95/166.78|7860/7082|
|3|delay-area|int2float|14.47/183.34|14.47/183.34|9100/9100|
|3|delay-area|max|313.14/2587.75|251.49/2582.33|1208/0|
|3|delay-area|priority|70.89/2062.18|70.89/2062.18|8306/8306|
|3|delay-area|router|13.94/216.40|13.94/216.40|9065/9065|
|3|delay-area|sin|716.75/2776.23|681.05/2776.23|410/0|
|4|area-delay|adder|61.85/4124.03|61.85/4124.03|5558/5558|
|4|area-delay|bar|274.12/284.38|242.59/307.27|1313/0|
|4|area-delay|cavlc|39.11/257.29|39.11/257.29|7749/7749|
|4|area-delay|ctrl|6.90/127.29|6.90/127.29|7374/7374|
|4|area-delay|dec|27.41/91.20|27.41/91.20|5690/5690|
|4|area-delay|i2c|72.60/223.12|72.60/223.12|5989/5980|
|4|area-delay|int2float|12.86/234.41|12.86/234.41|7387/7387|
|4|area-delay|max|307.45/3540.43|261.26/3545.50|1230/0|
|4|area-delay|priority|50.01/2907.17|50.64/2907.17|6391/7123|
|4|area-delay|router|10.38/309.69|10.38/309.69|5437/5437|
|4|area-delay|sin|552.67/3063.43|526.03/3060.68|424/0|
|4|delay-area|adder|83.36/3561.91|83.36/3561.91|5992/5992|
|4|delay-area|bar|322.35/191.11|322.35/191.11|1368/1441|
|4|delay-area|cavlc|45.83/194.95|45.83/194.95|9861/9861|
|4|delay-area|ctrl|7.56/103.17|7.56/103.17|7736/7736|
|4|delay-area|dec|29.54/66.15|29.54/66.15|5980/5980|
|4|delay-area|i2c|82.09/176.27|82.09/176.27|6265/6146|
|4|delay-area|int2float|14.14/182.22|14.14/182.22|9158/9158|
|4|delay-area|max|323.77/3102.43|279.93/3082.56|871/0|
|4|delay-area|priority|60.25/2047.24|59.98/2047.24|8720/7834|
|4|delay-area|router|13.55/199.00|13.55/199.00|7406/7406|
|4|delay-area|sin|734.13/2689.54|707.89/2689.54|246/0|

All failed pairs remain in paired.csv and full_scope.json. Nine designs exceed the node budget in all settings; this scheduling change does not solve their mapping. Main source has the same changes but a separately built binary; isolated-study results are not relabeled as main-run observations. Baseline algorithms, models and parameters remain unchanged.
