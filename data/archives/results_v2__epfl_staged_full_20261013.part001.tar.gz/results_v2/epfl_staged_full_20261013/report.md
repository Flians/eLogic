# Three-stage recovery prototype, unchanged global budget

Same binary/candidate pool: coupled recovery vs staged recovery. Two libraries, delay-area, all20 EPFL designs,80/80 attempts;44 named-port CEC-successful covers,36 node-budget failures.22 valid pairs: delay1better/18equal/3worse. All22 staged covers satisfy their validated frozen reference delay. Required-time area flow accepts at least one working cover in7/22 cases. Main and baseline algorithms are unchanged.

Stages share the original two-second recovery deadline, including witness/setup/final validation. Delay and area deadlines partition30% and cumulative50% of time remaining after witness; actual physical-area recovery uses the rest. Deadlines are checked between atomic operations, not preemptive stage caps. One global e-graph, same retained candidate pool/node/cut/SAT limits. A separate(D,A) incumbent preserves the best valid visited cover rather than trading final delay for area.

Negative result: three-input adder reference3233.65/final3210.79 versus coupled2949.64. This does not establish causality: the prototype also changes local ordering to a simple area scan and caps total local trials at2000, whereas the original uses richer proposal ranking. Default is not replaced. Candidate coverage and node refusals remain unresolved.

Next controlled experiment: reuse event-driven arrival propagation for delay flow and critical-path proposal ranking, as separate fixed ablation factors, without increasing time, node/cut/pool/SAT or the prototype trial cap. Preserve all four parameter configurations, failures and regressions; never select parameters by design. Do not claim required-time constraints alone improve PPA or exact cost means global optimality.
