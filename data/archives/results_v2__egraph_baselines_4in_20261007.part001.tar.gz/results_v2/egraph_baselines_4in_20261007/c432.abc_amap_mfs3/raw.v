// Benchmark "/home/flynn/workplace/MIGBalance/tools/mockturtle/experiments/benchmarks/c432" written by ABC on Wed Oct  7 15:32:30 2026

module \/home/flynn/workplace/MIGBalance/tools/mockturtle/experiments/benchmarks/c432  ( 
    G32, G34, G28, G30, G24, G26, G20, G22, G16, G18, G12, G14, G8, G10,
    G4, G6, G1, G2, G35, G31, G27, G23, G19, G15, G11, G7, G3, G36, G33,
    G29, G25, G21, G17, G13, G9, G5,
    G426, G427, G428, G429, G430, G431, G432  );
  input  G32, G34, G28, G30, G24, G26, G20, G22, G16, G18, G12, G14, G8,
    G10, G4, G6, G1, G2, G35, G31, G27, G23, G19, G15, G11, G7, G3, G36,
    G33, G29, G25, G21, G17, G13, G9, G5;
  output G426, G427, G428, G429, G430, G431, G432;
  wire new_n67_, new_n69_, new_n71_, new_n73_, new_n75_, new_n76_, new_n78_,
    new_n80_, new_n82_, new_n84_, new_n86_, new_n87_, new_n89_, new_n91_,
    new_n92_, new_n94_, new_n95_, new_n97_, new_n98_, new_n100_, new_n101_,
    new_n102_, new_n103_, new_n104_, new_n105_, new_n106_, new_n107_,
    new_n108_, new_n109_, new_n110_, new_n111_, new_n112_, new_n113_,
    new_n116_, new_n118_, new_n120_, new_n122_, new_n123_, new_n125_,
    new_n127_, new_n129_, new_n131_, new_n133_, new_n134_, new_n137_,
    new_n142_, new_n144_, new_n145_, new_n148_, new_n150_, new_n152_,
    new_n154_, new_n156_, new_n157_, new_n158_, new_n159_, new_n160_,
    new_n161_, new_n163_, new_n164_, new_n166_, new_n168_, new_n169_,
    new_n170_, new_n172_, new_n173_, new_n175_, new_n176_, new_n177_,
    new_n178_, new_n179_, new_n180_, new_n181_, new_n182_, new_n183_,
    new_n184_, new_n185_, new_n186_, new_n187_, new_n188_, new_n189_,
    new_n190_, new_n191_, new_n192_, new_n193_, new_n194_, new_n195_,
    new_n196_, new_n197_, new_n198_, new_n199_, new_n200_, new_n201_,
    new_n202_, new_n203_, new_n204_, new_n205_, new_n206_, new_n208_,
    new_n209_, new_n210_, new_n211_, new_n212_, new_n213_, new_n214_,
    new_n215_, new_n216_, new_n217_, new_n218_, new_n219_, new_n220_,
    new_n221_, new_n222_, new_n223_, new_n224_, new_n225_, new_n226_,
    new_n227_, new_n228_, new_n229_, new_n230_, new_n231_;
  NOR2x1_ASAP7_75t_R   g000(.A(G32), .B(new_n175_), .Y(new_n67_));
  NOR2x1_ASAP7_75t_R   g001(.A(G28), .B(new_n176_), .Y(new_n69_));
  NOR2x1_ASAP7_75t_R   g002(.A(G24), .B(new_n177_), .Y(new_n71_));
  NOR2x1_ASAP7_75t_R   g003(.A(G20), .B(new_n178_), .Y(new_n73_));
  AND4x2_ASAP7_75t_R   g004(.A(new_n198_), .B(new_n199_), .C(new_n200_), .D(new_n201_), .Y(new_n75_));
  NOR2x1_ASAP7_75t_R   g005(.A(G16), .B(new_n179_), .Y(new_n76_));
  NOR2x1_ASAP7_75t_R   g006(.A(G12), .B(new_n180_), .Y(new_n78_));
  NOR2x1_ASAP7_75t_R   g007(.A(G8), .B(new_n181_), .Y(new_n80_));
  NOR2x1_ASAP7_75t_R   g008(.A(G4), .B(new_n182_), .Y(new_n82_));
  NOR2x1_ASAP7_75t_R   g009(.A(G1), .B(new_n183_), .Y(new_n84_));
  AND3x1_ASAP7_75t_R   g010(.A(new_n205_), .B(new_n206_), .C(new_n204_), .Y(new_n86_));
  AND4x2_ASAP7_75t_R   g011(.A(new_n202_), .B(new_n203_), .C(new_n86_), .D(new_n75_), .Y(new_n87_));
  AO22x1_ASAP7_75t_R   g012(.A1(new_n198_), .A2(new_n87_), .B1(new_n67_), .B2(G426), .Y(new_n89_));
  OR3x1_ASAP7_75t_R    g013(.A(new_n175_), .B(G35), .C(new_n208_), .Y(new_n91_));
  AO22x1_ASAP7_75t_R   g014(.A1(new_n199_), .A2(new_n87_), .B1(new_n69_), .B2(G426), .Y(new_n92_));
  OR3x1_ASAP7_75t_R    g015(.A(new_n176_), .B(G31), .C(new_n209_), .Y(new_n94_));
  AO22x1_ASAP7_75t_R   g016(.A1(new_n200_), .A2(new_n87_), .B1(new_n71_), .B2(G426), .Y(new_n95_));
  OR3x1_ASAP7_75t_R    g017(.A(new_n177_), .B(G27), .C(new_n210_), .Y(new_n97_));
  AO22x1_ASAP7_75t_R   g018(.A1(new_n201_), .A2(new_n87_), .B1(new_n73_), .B2(G426), .Y(new_n98_));
  OR3x1_ASAP7_75t_R    g019(.A(new_n178_), .B(G23), .C(new_n211_), .Y(new_n100_));
  AND4x2_ASAP7_75t_R   g020(.A(new_n91_), .B(new_n94_), .C(new_n97_), .D(new_n100_), .Y(new_n101_));
  INVx1_ASAP7_75t_R    g021(.A(new_n101_), .Y(new_n102_));
  AO22x1_ASAP7_75t_R   g022(.A1(new_n202_), .A2(new_n87_), .B1(new_n76_), .B2(G426), .Y(new_n103_));
  AND3x1_ASAP7_75t_R   g023(.A(G18), .B(new_n184_), .C(new_n103_), .Y(new_n104_));
  AO22x1_ASAP7_75t_R   g024(.A1(new_n203_), .A2(new_n87_), .B1(new_n78_), .B2(G426), .Y(new_n105_));
  AND3x1_ASAP7_75t_R   g025(.A(G14), .B(new_n185_), .C(new_n105_), .Y(new_n106_));
  AO22x1_ASAP7_75t_R   g026(.A1(new_n204_), .A2(new_n87_), .B1(new_n80_), .B2(G426), .Y(new_n107_));
  AND3x1_ASAP7_75t_R   g027(.A(G10), .B(new_n186_), .C(new_n107_), .Y(new_n108_));
  AO22x1_ASAP7_75t_R   g028(.A1(new_n205_), .A2(new_n87_), .B1(new_n82_), .B2(G426), .Y(new_n109_));
  AND3x1_ASAP7_75t_R   g029(.A(G6), .B(new_n187_), .C(new_n109_), .Y(new_n110_));
  AO22x1_ASAP7_75t_R   g030(.A1(new_n206_), .A2(new_n87_), .B1(new_n84_), .B2(G426), .Y(new_n111_));
  AND3x1_ASAP7_75t_R   g031(.A(G2), .B(new_n188_), .C(new_n111_), .Y(new_n112_));
  OR3x1_ASAP7_75t_R    g032(.A(new_n110_), .B(new_n112_), .C(new_n108_), .Y(new_n113_));
  OR4x2_ASAP7_75t_R    g033(.A(new_n104_), .B(new_n106_), .C(new_n113_), .D(new_n102_), .Y(G427));
  AND4x2_ASAP7_75t_R   g034(.A(G34), .B(new_n189_), .C(new_n89_), .D(new_n212_), .Y(new_n116_));
  AND4x2_ASAP7_75t_R   g035(.A(G30), .B(new_n190_), .C(new_n92_), .D(new_n213_), .Y(new_n118_));
  AND4x2_ASAP7_75t_R   g036(.A(G26), .B(new_n191_), .C(new_n95_), .D(new_n214_), .Y(new_n120_));
  AND4x2_ASAP7_75t_R   g037(.A(G22), .B(new_n192_), .C(new_n98_), .D(new_n215_), .Y(new_n122_));
  OR4x2_ASAP7_75t_R    g038(.A(new_n116_), .B(new_n118_), .C(new_n120_), .D(new_n122_), .Y(new_n123_));
  AND4x2_ASAP7_75t_R   g039(.A(G18), .B(new_n193_), .C(new_n103_), .D(new_n216_), .Y(new_n125_));
  AND4x2_ASAP7_75t_R   g040(.A(G14), .B(new_n194_), .C(new_n105_), .D(new_n217_), .Y(new_n127_));
  AND4x2_ASAP7_75t_R   g041(.A(G10), .B(new_n195_), .C(new_n107_), .D(new_n218_), .Y(new_n129_));
  AND4x2_ASAP7_75t_R   g042(.A(G6), .B(new_n196_), .C(new_n109_), .D(new_n219_), .Y(new_n131_));
  AND4x2_ASAP7_75t_R   g043(.A(G2), .B(new_n197_), .C(new_n111_), .D(new_n220_), .Y(new_n133_));
  OR3x1_ASAP7_75t_R    g044(.A(new_n131_), .B(new_n133_), .C(new_n129_), .Y(new_n134_));
  OR4x2_ASAP7_75t_R    g045(.A(new_n125_), .B(new_n127_), .C(new_n134_), .D(new_n123_), .Y(G428));
  AOI22x1_ASAP7_75t_R  g046(.A1(G5), .A2(G428), .B1(G3), .B2(G427), .Y(new_n137_));
  OA211x2_ASAP7_75t_R  g047(.A1(new_n190_), .A2(new_n221_), .B(G30), .C(new_n223_), .Y(new_n142_));
  AOI22x1_ASAP7_75t_R  g048(.A1(G27), .A2(G427), .B1(G24), .B2(G426), .Y(new_n144_));
  OA211x2_ASAP7_75t_R  g049(.A1(new_n191_), .A2(new_n221_), .B(G26), .C(new_n144_), .Y(new_n145_));
  OA211x2_ASAP7_75t_R  g050(.A1(new_n192_), .A2(new_n221_), .B(G22), .C(new_n226_), .Y(new_n148_));
  OR4x2_ASAP7_75t_R    g051(.A(G34), .B(new_n142_), .C(new_n145_), .D(new_n148_), .Y(new_n150_));
  OA211x2_ASAP7_75t_R  g052(.A1(new_n193_), .A2(new_n221_), .B(G18), .C(new_n228_), .Y(new_n152_));
  OA211x2_ASAP7_75t_R  g053(.A1(new_n194_), .A2(new_n221_), .B(G14), .C(new_n229_), .Y(new_n154_));
  OR2x4_ASAP7_75t_R    g054(.A(new_n152_), .B(new_n154_), .Y(new_n156_));
  AOI22x1_ASAP7_75t_R  g055(.A1(G11), .A2(G427), .B1(G8), .B2(G426), .Y(new_n157_));
  OA211x2_ASAP7_75t_R  g056(.A1(new_n195_), .A2(new_n221_), .B(G10), .C(new_n157_), .Y(new_n158_));
  AOI22x1_ASAP7_75t_R  g057(.A1(G7), .A2(G427), .B1(G4), .B2(G426), .Y(new_n159_));
  OA211x2_ASAP7_75t_R  g058(.A1(new_n196_), .A2(new_n221_), .B(G6), .C(new_n159_), .Y(new_n160_));
  NOR2x1_ASAP7_75t_R   g059(.A(new_n158_), .B(new_n160_), .Y(new_n161_));
  OR3x1_ASAP7_75t_R    g060(.A(new_n156_), .B(new_n231_), .C(new_n150_), .Y(new_n163_));
  INVx1_ASAP7_75t_R    g061(.A(new_n163_), .Y(new_n164_));
  AOI21x1_ASAP7_75t_R  g062(.A1(new_n137_), .A2(new_n222_), .B(new_n164_), .Y(G429));
  NOR2x1_ASAP7_75t_R   g063(.A(new_n230_), .B(new_n158_), .Y(new_n166_));
  OR3x1_ASAP7_75t_R    g064(.A(new_n152_), .B(new_n166_), .C(new_n231_), .Y(G430));
  OR2x4_ASAP7_75t_R    g065(.A(new_n154_), .B(new_n158_), .Y(new_n168_));
  OR3x1_ASAP7_75t_R    g066(.A(new_n227_), .B(new_n152_), .C(new_n168_), .Y(new_n169_));
  OA211x2_ASAP7_75t_R  g067(.A1(new_n225_), .A2(new_n156_), .B(new_n169_), .C(new_n161_), .Y(new_n170_));
  INVx1_ASAP7_75t_R    g068(.A(new_n170_), .Y(G431));
  OR3x1_ASAP7_75t_R    g069(.A(new_n224_), .B(new_n145_), .C(new_n168_), .Y(new_n172_));
  NAND2x1_ASAP7_75t_R  g070(.A(new_n169_), .B(new_n172_), .Y(new_n173_));
  OR3x1_ASAP7_75t_R    g071(.A(new_n160_), .B(new_n166_), .C(new_n173_), .Y(G432));
  INVx1_ASAP7_75t_R    g072(.A(G34), .Y(new_n175_));
  INVx1_ASAP7_75t_R    g073(.A(G30), .Y(new_n176_));
  INVx1_ASAP7_75t_R    g074(.A(G26), .Y(new_n177_));
  INVx1_ASAP7_75t_R    g075(.A(G22), .Y(new_n178_));
  INVx1_ASAP7_75t_R    g076(.A(G18), .Y(new_n179_));
  INVx1_ASAP7_75t_R    g077(.A(G14), .Y(new_n180_));
  INVx1_ASAP7_75t_R    g078(.A(G10), .Y(new_n181_));
  INVx1_ASAP7_75t_R    g079(.A(G6), .Y(new_n182_));
  INVx1_ASAP7_75t_R    g080(.A(G2), .Y(new_n183_));
  INVx1_ASAP7_75t_R    g081(.A(G19), .Y(new_n184_));
  INVx1_ASAP7_75t_R    g082(.A(G15), .Y(new_n185_));
  INVx1_ASAP7_75t_R    g083(.A(G11), .Y(new_n186_));
  INVx1_ASAP7_75t_R    g084(.A(G7), .Y(new_n187_));
  INVx1_ASAP7_75t_R    g085(.A(G3), .Y(new_n188_));
  INVx1_ASAP7_75t_R    g086(.A(G36), .Y(new_n189_));
  INVx1_ASAP7_75t_R    g087(.A(G33), .Y(new_n190_));
  INVx1_ASAP7_75t_R    g088(.A(G29), .Y(new_n191_));
  INVx1_ASAP7_75t_R    g089(.A(G25), .Y(new_n192_));
  INVx1_ASAP7_75t_R    g090(.A(G21), .Y(new_n193_));
  INVx1_ASAP7_75t_R    g091(.A(G17), .Y(new_n194_));
  INVx1_ASAP7_75t_R    g092(.A(G13), .Y(new_n195_));
  INVx1_ASAP7_75t_R    g093(.A(G9), .Y(new_n196_));
  INVx1_ASAP7_75t_R    g094(.A(G5), .Y(new_n197_));
  INVx1_ASAP7_75t_R    g095(.A(new_n67_), .Y(new_n198_));
  INVx1_ASAP7_75t_R    g096(.A(new_n69_), .Y(new_n199_));
  INVx1_ASAP7_75t_R    g097(.A(new_n71_), .Y(new_n200_));
  INVx1_ASAP7_75t_R    g098(.A(new_n73_), .Y(new_n201_));
  INVx1_ASAP7_75t_R    g099(.A(new_n76_), .Y(new_n202_));
  INVx1_ASAP7_75t_R    g100(.A(new_n78_), .Y(new_n203_));
  INVx1_ASAP7_75t_R    g101(.A(new_n80_), .Y(new_n204_));
  INVx1_ASAP7_75t_R    g102(.A(new_n82_), .Y(new_n205_));
  INVx1_ASAP7_75t_R    g103(.A(new_n84_), .Y(new_n206_));
  INVx1_ASAP7_75t_R    g104(.A(new_n87_), .Y(G426));
  INVx1_ASAP7_75t_R    g105(.A(new_n89_), .Y(new_n208_));
  INVx1_ASAP7_75t_R    g106(.A(new_n92_), .Y(new_n209_));
  INVx1_ASAP7_75t_R    g107(.A(new_n95_), .Y(new_n210_));
  INVx1_ASAP7_75t_R    g108(.A(new_n98_), .Y(new_n211_));
  NAND2x1_ASAP7_75t_R  g109(.A(G35), .B(G427), .Y(new_n212_));
  NAND2x1_ASAP7_75t_R  g110(.A(G31), .B(G427), .Y(new_n213_));
  NAND2x1_ASAP7_75t_R  g111(.A(G27), .B(G427), .Y(new_n214_));
  NAND2x1_ASAP7_75t_R  g112(.A(G23), .B(G427), .Y(new_n215_));
  NAND2x1_ASAP7_75t_R  g113(.A(G19), .B(G427), .Y(new_n216_));
  NAND2x1_ASAP7_75t_R  g114(.A(G15), .B(G427), .Y(new_n217_));
  NAND2x1_ASAP7_75t_R  g115(.A(G11), .B(G427), .Y(new_n218_));
  NAND2x1_ASAP7_75t_R  g116(.A(G7), .B(G427), .Y(new_n219_));
  NAND2x1_ASAP7_75t_R  g117(.A(G3), .B(G427), .Y(new_n220_));
  INVx1_ASAP7_75t_R    g118(.A(G428), .Y(new_n221_));
  AND2x2_ASAP7_75t_R   g119(.A(G2), .B(new_n111_), .Y(new_n222_));
  AND2x2_ASAP7_75t_R   g120(.A(new_n92_), .B(new_n213_), .Y(new_n223_));
  INVx1_ASAP7_75t_R    g121(.A(new_n142_), .Y(new_n224_));
  INVx1_ASAP7_75t_R    g122(.A(new_n145_), .Y(new_n225_));
  AND2x2_ASAP7_75t_R   g123(.A(new_n98_), .B(new_n215_), .Y(new_n226_));
  INVx1_ASAP7_75t_R    g124(.A(new_n148_), .Y(new_n227_));
  AND2x2_ASAP7_75t_R   g125(.A(new_n103_), .B(new_n216_), .Y(new_n228_));
  AND2x2_ASAP7_75t_R   g126(.A(new_n105_), .B(new_n217_), .Y(new_n229_));
  INVx1_ASAP7_75t_R    g127(.A(new_n154_), .Y(new_n230_));
  INVx1_ASAP7_75t_R    g128(.A(new_n161_), .Y(new_n231_));
endmodule


