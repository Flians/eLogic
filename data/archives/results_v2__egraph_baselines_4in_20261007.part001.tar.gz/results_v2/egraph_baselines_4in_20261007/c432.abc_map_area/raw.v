// Benchmark "/home/flynn/workplace/MIGBalance/tools/mockturtle/experiments/benchmarks/c432" written by ABC on Wed Oct  7 15:32:29 2026

module \/home/flynn/workplace/MIGBalance/tools/mockturtle/experiments/benchmarks/c432  ( 
    G32, G34, G28, G30, G24, G26, G20, G22, G16, G18, G12, G14, G8, G10,
    G4, G6, G1, G2, G35, G31, G27, G23, G19, G15, G11, G7, G3, G36, G33,
    G29, G25, G21, G17, G13, G9, G5,
    G426, G427, G428, G429, G430, G431, G432  );
  input  G32, G34, G28, G30, G24, G26, G20, G22, G16, G18, G12, G14, G8,
    G10, G4, G6, G1, G2, G35, G31, G27, G23, G19, G15, G11, G7, G3, G36,
    G33, G29, G25, G21, G17, G13, G9, G5;
  output G426, G427, G428, G429, G430, G431, G432;
  wire new_n44_, new_n45_, new_n46_, new_n47_, new_n48_, new_n49_, new_n50_,
    new_n51_, new_n52_, new_n53_, new_n54_, new_n55_, new_n56_, new_n57_,
    new_n58_, new_n59_, new_n60_, new_n61_, new_n62_, new_n63_, new_n64_,
    new_n65_, new_n66_, new_n68_, new_n69_, new_n70_, new_n71_, new_n72_,
    new_n73_, new_n74_, new_n75_, new_n76_, new_n77_, new_n78_, new_n79_,
    new_n80_, new_n81_, new_n82_, new_n83_, new_n84_, new_n85_, new_n86_,
    new_n87_, new_n88_, new_n89_, new_n90_, new_n91_, new_n92_, new_n93_,
    new_n94_, new_n95_, new_n96_, new_n97_, new_n98_, new_n99_, new_n101_,
    new_n102_, new_n103_, new_n104_, new_n105_, new_n106_, new_n107_,
    new_n108_, new_n109_, new_n110_, new_n111_, new_n112_, new_n113_,
    new_n114_, new_n115_, new_n116_, new_n117_, new_n118_, new_n119_,
    new_n120_, new_n121_, new_n122_, new_n123_, new_n124_, new_n125_,
    new_n126_, new_n127_, new_n128_, new_n129_, new_n130_, new_n131_,
    new_n132_, new_n133_, new_n134_, new_n135_, new_n137_, new_n138_,
    new_n139_, new_n140_, new_n141_, new_n142_, new_n143_, new_n144_,
    new_n145_, new_n146_, new_n147_, new_n148_, new_n149_, new_n150_,
    new_n151_, new_n152_, new_n153_, new_n154_, new_n155_, new_n156_,
    new_n157_, new_n158_, new_n159_, new_n160_, new_n161_, new_n162_,
    new_n163_, new_n164_, new_n165_, new_n167_, new_n168_, new_n170_,
    new_n171_, new_n172_, new_n173_, new_n175_, new_n176_, new_n177_;
  INVx1_ASAP7_75t_R    g000(.A(G22), .Y(new_n44_));
  INVx1_ASAP7_75t_R    g001(.A(G32), .Y(new_n45_));
  AND2x2_ASAP7_75t_R   g002(.A(new_n45_), .B(G34), .Y(new_n46_));
  INVx1_ASAP7_75t_R    g003(.A(G30), .Y(new_n47_));
  NOR2x1_ASAP7_75t_R   g004(.A(G28), .B(new_n47_), .Y(new_n48_));
  NOR2x1_ASAP7_75t_R   g005(.A(new_n46_), .B(new_n48_), .Y(new_n49_));
  INVx1_ASAP7_75t_R    g006(.A(G24), .Y(new_n50_));
  AND2x2_ASAP7_75t_R   g007(.A(new_n50_), .B(G26), .Y(new_n51_));
  INVx1_ASAP7_75t_R    g008(.A(new_n51_), .Y(new_n52_));
  OA211x2_ASAP7_75t_R  g009(.A1(G20), .A2(new_n44_), .B(new_n49_), .C(new_n52_), .Y(new_n53_));
  INVx1_ASAP7_75t_R    g010(.A(G18), .Y(new_n54_));
  NOR2x1_ASAP7_75t_R   g011(.A(G16), .B(new_n54_), .Y(new_n55_));
  INVx1_ASAP7_75t_R    g012(.A(G12), .Y(new_n56_));
  AND2x2_ASAP7_75t_R   g013(.A(new_n56_), .B(G14), .Y(new_n57_));
  INVx1_ASAP7_75t_R    g014(.A(G10), .Y(new_n58_));
  NOR2x1_ASAP7_75t_R   g015(.A(G8), .B(new_n58_), .Y(new_n59_));
  INVx1_ASAP7_75t_R    g016(.A(G6), .Y(new_n60_));
  NOR2x1_ASAP7_75t_R   g017(.A(G4), .B(new_n60_), .Y(new_n61_));
  INVx1_ASAP7_75t_R    g018(.A(G1), .Y(new_n62_));
  AND2x2_ASAP7_75t_R   g019(.A(new_n62_), .B(G2), .Y(new_n63_));
  OR3x1_ASAP7_75t_R    g020(.A(new_n59_), .B(new_n61_), .C(new_n63_), .Y(new_n64_));
  NOR3x1_ASAP7_75t_R   g021(.A(new_n64_), .B(new_n55_), .C(new_n57_), .Y(new_n65_));
  AND2x2_ASAP7_75t_R   g022(.A(new_n65_), .B(new_n53_), .Y(new_n66_));
  INVx1_ASAP7_75t_R    g023(.A(new_n66_), .Y(G426));
  INVx1_ASAP7_75t_R    g024(.A(G35), .Y(new_n68_));
  XOR2x2_ASAP7_75t_R   g025(.A(new_n66_), .B(new_n46_), .Y(new_n69_));
  AND3x1_ASAP7_75t_R   g026(.A(new_n69_), .B(G34), .C(new_n68_), .Y(new_n70_));
  INVx1_ASAP7_75t_R    g027(.A(G31), .Y(new_n71_));
  XOR2x2_ASAP7_75t_R   g028(.A(new_n66_), .B(new_n48_), .Y(new_n72_));
  AND3x1_ASAP7_75t_R   g029(.A(new_n72_), .B(G30), .C(new_n71_), .Y(new_n73_));
  NOR2x1_ASAP7_75t_R   g030(.A(new_n70_), .B(new_n73_), .Y(new_n74_));
  INVx1_ASAP7_75t_R    g031(.A(G27), .Y(new_n75_));
  XOR2x2_ASAP7_75t_R   g032(.A(new_n66_), .B(new_n51_), .Y(new_n76_));
  AND3x1_ASAP7_75t_R   g033(.A(new_n76_), .B(G26), .C(new_n75_), .Y(new_n77_));
  INVx1_ASAP7_75t_R    g034(.A(G23), .Y(new_n78_));
  NOR2x1_ASAP7_75t_R   g035(.A(G20), .B(new_n44_), .Y(new_n79_));
  XOR2x2_ASAP7_75t_R   g036(.A(new_n66_), .B(new_n79_), .Y(new_n80_));
  AND3x1_ASAP7_75t_R   g037(.A(new_n80_), .B(G22), .C(new_n78_), .Y(new_n81_));
  NOR2x1_ASAP7_75t_R   g038(.A(new_n77_), .B(new_n81_), .Y(new_n82_));
  AND2x2_ASAP7_75t_R   g039(.A(new_n74_), .B(new_n82_), .Y(new_n83_));
  INVx1_ASAP7_75t_R    g040(.A(G19), .Y(new_n84_));
  XOR2x2_ASAP7_75t_R   g041(.A(new_n66_), .B(new_n55_), .Y(new_n85_));
  AND3x1_ASAP7_75t_R   g042(.A(new_n85_), .B(G18), .C(new_n84_), .Y(new_n86_));
  INVx1_ASAP7_75t_R    g043(.A(G15), .Y(new_n87_));
  XOR2x2_ASAP7_75t_R   g044(.A(new_n66_), .B(new_n57_), .Y(new_n88_));
  AND3x1_ASAP7_75t_R   g045(.A(new_n88_), .B(G14), .C(new_n87_), .Y(new_n89_));
  NOR2x1_ASAP7_75t_R   g046(.A(new_n86_), .B(new_n89_), .Y(new_n90_));
  XNOR2x2_ASAP7_75t_R  g047(.A(new_n59_), .B(new_n66_), .Y(new_n91_));
  OR3x1_ASAP7_75t_R    g048(.A(new_n91_), .B(new_n58_), .C(G11), .Y(new_n92_));
  XNOR2x2_ASAP7_75t_R  g049(.A(new_n61_), .B(new_n66_), .Y(new_n93_));
  OR3x1_ASAP7_75t_R    g050(.A(new_n93_), .B(new_n60_), .C(G7), .Y(new_n94_));
  INVx1_ASAP7_75t_R    g051(.A(G2), .Y(new_n95_));
  XNOR2x2_ASAP7_75t_R  g052(.A(new_n63_), .B(new_n66_), .Y(new_n96_));
  OR3x1_ASAP7_75t_R    g053(.A(new_n96_), .B(new_n95_), .C(G3), .Y(new_n97_));
  AND4x2_ASAP7_75t_R   g054(.A(new_n90_), .B(new_n92_), .C(new_n94_), .D(new_n97_), .Y(new_n98_));
  AND2x2_ASAP7_75t_R   g055(.A(new_n98_), .B(new_n83_), .Y(new_n99_));
  INVx1_ASAP7_75t_R    g056(.A(new_n99_), .Y(G427));
  XOR2x2_ASAP7_75t_R   g057(.A(new_n99_), .B(new_n70_), .Y(new_n101_));
  INVx1_ASAP7_75t_R    g058(.A(G36), .Y(new_n102_));
  AND3x1_ASAP7_75t_R   g059(.A(new_n69_), .B(G34), .C(new_n102_), .Y(new_n103_));
  XOR2x2_ASAP7_75t_R   g060(.A(new_n99_), .B(new_n73_), .Y(new_n104_));
  INVx1_ASAP7_75t_R    g061(.A(G33), .Y(new_n105_));
  AND3x1_ASAP7_75t_R   g062(.A(new_n72_), .B(G30), .C(new_n105_), .Y(new_n106_));
  AO22x1_ASAP7_75t_R   g063(.A1(new_n101_), .A2(new_n103_), .B1(new_n104_), .B2(new_n106_), .Y(new_n107_));
  XOR2x2_ASAP7_75t_R   g064(.A(new_n99_), .B(new_n77_), .Y(new_n108_));
  INVx1_ASAP7_75t_R    g065(.A(G29), .Y(new_n109_));
  AND3x1_ASAP7_75t_R   g066(.A(new_n76_), .B(G26), .C(new_n109_), .Y(new_n110_));
  XOR2x2_ASAP7_75t_R   g067(.A(new_n99_), .B(new_n81_), .Y(new_n111_));
  INVx1_ASAP7_75t_R    g068(.A(G25), .Y(new_n112_));
  AND3x1_ASAP7_75t_R   g069(.A(new_n80_), .B(G22), .C(new_n112_), .Y(new_n113_));
  AO22x1_ASAP7_75t_R   g070(.A1(new_n108_), .A2(new_n110_), .B1(new_n111_), .B2(new_n113_), .Y(new_n114_));
  NOR2x1_ASAP7_75t_R   g071(.A(new_n107_), .B(new_n114_), .Y(new_n115_));
  XOR2x2_ASAP7_75t_R   g072(.A(new_n99_), .B(new_n86_), .Y(new_n116_));
  INVx1_ASAP7_75t_R    g073(.A(G21), .Y(new_n117_));
  AND3x1_ASAP7_75t_R   g074(.A(new_n85_), .B(G18), .C(new_n117_), .Y(new_n118_));
  XOR2x2_ASAP7_75t_R   g075(.A(new_n99_), .B(new_n89_), .Y(new_n119_));
  INVx1_ASAP7_75t_R    g076(.A(G17), .Y(new_n120_));
  AND3x1_ASAP7_75t_R   g077(.A(new_n88_), .B(G14), .C(new_n120_), .Y(new_n121_));
  AOI22x1_ASAP7_75t_R  g078(.A1(new_n116_), .A2(new_n118_), .B1(new_n119_), .B2(new_n121_), .Y(new_n122_));
  XOR2x2_ASAP7_75t_R   g079(.A(new_n99_), .B(new_n92_), .Y(new_n123_));
  OR3x1_ASAP7_75t_R    g080(.A(new_n91_), .B(new_n58_), .C(G13), .Y(new_n124_));
  NAND2x1_ASAP7_75t_R  g081(.A(new_n94_), .B(new_n99_), .Y(new_n125_));
  AO21x1_ASAP7_75t_R   g082(.A1(new_n98_), .A2(new_n83_), .B(new_n94_), .Y(new_n126_));
  OR3x1_ASAP7_75t_R    g083(.A(new_n93_), .B(new_n60_), .C(G9), .Y(new_n127_));
  AO21x1_ASAP7_75t_R   g084(.A1(new_n125_), .A2(new_n126_), .B(new_n127_), .Y(new_n128_));
  NAND2x1_ASAP7_75t_R  g085(.A(new_n97_), .B(new_n99_), .Y(new_n129_));
  AO21x1_ASAP7_75t_R   g086(.A1(new_n98_), .A2(new_n83_), .B(new_n97_), .Y(new_n130_));
  OR3x1_ASAP7_75t_R    g087(.A(new_n96_), .B(new_n95_), .C(G5), .Y(new_n131_));
  AO21x1_ASAP7_75t_R   g088(.A1(new_n129_), .A2(new_n130_), .B(new_n131_), .Y(new_n132_));
  AND2x2_ASAP7_75t_R   g089(.A(new_n128_), .B(new_n132_), .Y(new_n133_));
  OA211x2_ASAP7_75t_R  g090(.A1(new_n123_), .A2(new_n124_), .B(new_n133_), .C(new_n122_), .Y(new_n134_));
  AND2x2_ASAP7_75t_R   g091(.A(new_n134_), .B(new_n115_), .Y(new_n135_));
  INVx1_ASAP7_75t_R    g092(.A(new_n135_), .Y(G428));
  AOI22x1_ASAP7_75t_R  g093(.A1(G3), .A2(G427), .B1(G428), .B2(G5), .Y(new_n137_));
  OA211x2_ASAP7_75t_R  g094(.A1(new_n62_), .A2(new_n66_), .B(new_n137_), .C(G2), .Y(new_n138_));
  OA21x2_ASAP7_75t_R   g095(.A1(new_n135_), .A2(new_n102_), .B(G34), .Y(new_n139_));
  OA22x2_ASAP7_75t_R   g096(.A1(new_n45_), .A2(new_n66_), .B1(new_n99_), .B2(new_n68_), .Y(new_n140_));
  AO22x1_ASAP7_75t_R   g097(.A1(G427), .A2(G31), .B1(G28), .B2(G426), .Y(new_n141_));
  AOI211x1_ASAP7_75t_R g098(.A1(G428), .A2(G33), .B(new_n47_), .C(new_n141_), .Y(new_n142_));
  AOI21x1_ASAP7_75t_R  g099(.A1(new_n139_), .A2(new_n140_), .B(new_n142_), .Y(new_n143_));
  OA21x2_ASAP7_75t_R   g100(.A1(new_n135_), .A2(new_n109_), .B(G26), .Y(new_n144_));
  OA22x2_ASAP7_75t_R   g101(.A1(new_n50_), .A2(new_n66_), .B1(new_n99_), .B2(new_n75_), .Y(new_n145_));
  NAND2x1_ASAP7_75t_R  g102(.A(new_n145_), .B(new_n144_), .Y(new_n146_));
  AO22x1_ASAP7_75t_R   g103(.A1(G427), .A2(G23), .B1(G20), .B2(G426), .Y(new_n147_));
  AOI211x1_ASAP7_75t_R g104(.A1(G428), .A2(G25), .B(new_n44_), .C(new_n147_), .Y(new_n148_));
  INVx1_ASAP7_75t_R    g105(.A(new_n148_), .Y(new_n149_));
  AND3x1_ASAP7_75t_R   g106(.A(new_n143_), .B(new_n146_), .C(new_n149_), .Y(new_n150_));
  NOR2x1_ASAP7_75t_R   g107(.A(new_n117_), .B(new_n135_), .Y(new_n151_));
  AO22x1_ASAP7_75t_R   g108(.A1(G427), .A2(G19), .B1(G16), .B2(G426), .Y(new_n152_));
  NOR3x1_ASAP7_75t_R   g109(.A(new_n151_), .B(new_n54_), .C(new_n152_), .Y(new_n153_));
  OA21x2_ASAP7_75t_R   g110(.A1(new_n135_), .A2(new_n120_), .B(G14), .Y(new_n154_));
  OA22x2_ASAP7_75t_R   g111(.A1(new_n56_), .A2(new_n66_), .B1(new_n99_), .B2(new_n87_), .Y(new_n155_));
  AO21x1_ASAP7_75t_R   g112(.A1(new_n154_), .A2(new_n155_), .B(new_n153_), .Y(new_n156_));
  AND2x2_ASAP7_75t_R   g113(.A(G428), .B(G13), .Y(new_n157_));
  AO22x1_ASAP7_75t_R   g114(.A1(G427), .A2(G11), .B1(G8), .B2(G426), .Y(new_n158_));
  NOR3x1_ASAP7_75t_R   g115(.A(new_n157_), .B(new_n58_), .C(new_n158_), .Y(new_n159_));
  INVx1_ASAP7_75t_R    g116(.A(new_n159_), .Y(new_n160_));
  AND2x2_ASAP7_75t_R   g117(.A(G428), .B(G9), .Y(new_n161_));
  AO22x1_ASAP7_75t_R   g118(.A1(G427), .A2(G7), .B1(G4), .B2(G426), .Y(new_n162_));
  OR3x1_ASAP7_75t_R    g119(.A(new_n161_), .B(new_n60_), .C(new_n162_), .Y(new_n163_));
  NAND2x1_ASAP7_75t_R  g120(.A(new_n163_), .B(new_n160_), .Y(new_n164_));
  NOR2x1_ASAP7_75t_R   g121(.A(new_n156_), .B(new_n164_), .Y(new_n165_));
  AOI21x1_ASAP7_75t_R  g122(.A1(new_n150_), .A2(new_n165_), .B(new_n138_), .Y(G429));
  AND2x2_ASAP7_75t_R   g123(.A(new_n154_), .B(new_n155_), .Y(new_n167_));
  AND2x2_ASAP7_75t_R   g124(.A(new_n160_), .B(new_n167_), .Y(new_n168_));
  OR3x1_ASAP7_75t_R    g125(.A(new_n168_), .B(new_n164_), .C(new_n153_), .Y(G430));
  NOR2x1_ASAP7_75t_R   g126(.A(new_n146_), .B(new_n156_), .Y(new_n170_));
  INVx1_ASAP7_75t_R    g127(.A(new_n153_), .Y(new_n171_));
  NOR2x1_ASAP7_75t_R   g128(.A(new_n167_), .B(new_n159_), .Y(new_n172_));
  AND3x1_ASAP7_75t_R   g129(.A(new_n172_), .B(new_n148_), .C(new_n171_), .Y(new_n173_));
  OR3x1_ASAP7_75t_R    g130(.A(new_n173_), .B(new_n164_), .C(new_n170_), .Y(G431));
  AND3x1_ASAP7_75t_R   g131(.A(new_n172_), .B(new_n142_), .C(new_n146_), .Y(new_n175_));
  INVx1_ASAP7_75t_R    g132(.A(new_n168_), .Y(new_n176_));
  NAND2x1_ASAP7_75t_R  g133(.A(new_n163_), .B(new_n176_), .Y(new_n177_));
  OR3x1_ASAP7_75t_R    g134(.A(new_n177_), .B(new_n173_), .C(new_n175_), .Y(G432));
endmodule


