// Benchmark "/home/flynn/workplace/MIGBalance/tools/mockturtle/experiments/benchmarks/c432" written by ABC on Wed Oct  7 15:32:30 2026

module \/home/flynn/workplace/MIGBalance/tools/mockturtle/experiments/benchmarks/c432  ( 
    G32, G34, G28, G30, G24, G26, G20, G22, G16, G18, G12, G14, G8, G10,
    G4, G6, G1, G2, G35, G31, G27, G23, G19, G15, G11, G7, G3, G36, G33,
    G29, G25, G21, G17, G13, G9, G5,
    G426, G427, G428, G429, G430, G431, G432  );
  input  G32, G34, G28, G30, G24, G26, G20, G22, G16, G18, G12, G14, G8,
    G10, G4, G6, G1, G2, G35, G31, G27, G23, G19, G15, G11, G7, G3, G36,
    G33, G29, G25, G21, G17, G13, G9, G5;
  output G426, G427, G428, G429, G430, G431, G432;
  wire new_n44_, new_n45_, new_n46_, new_n47_, new_n48_, new_n49_, new_n50_,
    new_n51_, new_n52_, new_n53_, new_n54_, new_n55_, new_n56_, new_n57_,
    new_n58_, new_n59_, new_n60_, new_n61_, new_n62_, new_n63_, new_n64_,
    new_n65_, new_n66_, new_n67_, new_n68_, new_n69_, new_n70_, new_n71_,
    new_n72_, new_n73_, new_n74_, new_n75_, new_n76_, new_n77_, new_n78_,
    new_n80_, new_n81_, new_n82_, new_n83_, new_n84_, new_n85_, new_n86_,
    new_n87_, new_n88_, new_n89_, new_n90_, new_n91_, new_n92_, new_n93_,
    new_n94_, new_n95_, new_n96_, new_n97_, new_n98_, new_n99_, new_n100_,
    new_n101_, new_n102_, new_n103_, new_n105_, new_n106_, new_n107_,
    new_n108_, new_n109_, new_n110_, new_n111_, new_n112_, new_n113_,
    new_n114_, new_n115_, new_n116_, new_n117_, new_n118_, new_n119_,
    new_n120_, new_n121_, new_n122_, new_n123_, new_n124_, new_n125_,
    new_n126_, new_n127_, new_n128_, new_n129_, new_n131_, new_n132_,
    new_n133_, new_n134_, new_n135_, new_n136_, new_n137_, new_n138_,
    new_n139_, new_n140_, new_n141_, new_n142_, new_n143_, new_n145_,
    new_n146_, new_n147_, new_n148_, new_n149_, new_n150_, new_n151_,
    new_n152_, new_n153_, new_n155_, new_n156_, new_n157_, new_n159_,
    new_n160_;
  INVx1_ASAP7_75t_R    g000(.A(G32), .Y(new_n44_));
  INVx1_ASAP7_75t_R    g001(.A(G34), .Y(new_n45_));
  INVx1_ASAP7_75t_R    g002(.A(G28), .Y(new_n46_));
  INVx1_ASAP7_75t_R    g003(.A(G24), .Y(new_n47_));
  INVx1_ASAP7_75t_R    g004(.A(G26), .Y(new_n48_));
  INVx1_ASAP7_75t_R    g005(.A(G22), .Y(new_n49_));
  INVx1_ASAP7_75t_R    g006(.A(G16), .Y(new_n50_));
  INVx1_ASAP7_75t_R    g007(.A(G18), .Y(new_n51_));
  INVx1_ASAP7_75t_R    g008(.A(G14), .Y(new_n52_));
  INVx1_ASAP7_75t_R    g009(.A(G8), .Y(new_n53_));
  INVx1_ASAP7_75t_R    g010(.A(G10), .Y(new_n54_));
  INVx1_ASAP7_75t_R    g011(.A(G4), .Y(new_n55_));
  INVx1_ASAP7_75t_R    g012(.A(G6), .Y(new_n56_));
  INVx1_ASAP7_75t_R    g013(.A(G1), .Y(new_n57_));
  INVx1_ASAP7_75t_R    g014(.A(G2), .Y(new_n58_));
  INVx1_ASAP7_75t_R    g015(.A(G31), .Y(new_n59_));
  INVx1_ASAP7_75t_R    g016(.A(G19), .Y(new_n60_));
  INVx1_ASAP7_75t_R    g017(.A(G15), .Y(new_n61_));
  INVx1_ASAP7_75t_R    g018(.A(G11), .Y(new_n62_));
  INVx1_ASAP7_75t_R    g019(.A(G36), .Y(new_n63_));
  INVx1_ASAP7_75t_R    g020(.A(G33), .Y(new_n64_));
  INVx1_ASAP7_75t_R    g021(.A(G29), .Y(new_n65_));
  INVx1_ASAP7_75t_R    g022(.A(G25), .Y(new_n66_));
  INVx1_ASAP7_75t_R    g023(.A(G21), .Y(new_n67_));
  INVx1_ASAP7_75t_R    g024(.A(G17), .Y(new_n68_));
  INVx1_ASAP7_75t_R    g025(.A(G13), .Y(new_n69_));
  INVx1_ASAP7_75t_R    g026(.A(G9), .Y(new_n70_));
  OAI22x1_ASAP7_75t_R  g027(.A1(new_n52_), .A2(G12), .B1(new_n49_), .B2(G20), .Y(new_n71_));
  AOI21x1_ASAP7_75t_R  g028(.A1(new_n50_), .A2(G18), .B(new_n71_), .Y(new_n72_));
  AOI22x1_ASAP7_75t_R  g029(.A1(new_n44_), .A2(G34), .B1(new_n46_), .B2(G30), .Y(new_n73_));
  NAND2x1_ASAP7_75t_R  g030(.A(G26), .B(new_n47_), .Y(new_n74_));
  AOI22x1_ASAP7_75t_R  g031(.A1(new_n47_), .A2(G26), .B1(new_n53_), .B2(G10), .Y(new_n75_));
  AOI22x1_ASAP7_75t_R  g032(.A1(new_n55_), .A2(G6), .B1(new_n57_), .B2(G2), .Y(new_n76_));
  AND2x2_ASAP7_75t_R   g033(.A(new_n75_), .B(new_n76_), .Y(new_n77_));
  AND3x1_ASAP7_75t_R   g034(.A(new_n73_), .B(new_n75_), .C(new_n76_), .Y(new_n78_));
  NAND2x1_ASAP7_75t_R  g035(.A(new_n72_), .B(new_n78_), .Y(G426));
  AO31x2_ASAP7_75t_R   g036(.A1(new_n72_), .A2(new_n73_), .A3(new_n77_), .B(new_n46_), .Y(new_n80_));
  NAND2x1_ASAP7_75t_R  g037(.A(G30), .B(new_n80_), .Y(new_n81_));
  AND3x1_ASAP7_75t_R   g038(.A(new_n80_), .B(G30), .C(new_n59_), .Y(new_n82_));
  AND4x2_ASAP7_75t_R   g039(.A(new_n74_), .B(new_n77_), .C(new_n72_), .D(new_n73_), .Y(new_n83_));
  AOI21x1_ASAP7_75t_R  g040(.A1(new_n72_), .A2(new_n78_), .B(new_n74_), .Y(new_n84_));
  NOR2x1_ASAP7_75t_R   g041(.A(new_n83_), .B(new_n84_), .Y(new_n85_));
  NOR2x1_ASAP7_75t_R   g042(.A(G27), .B(new_n48_), .Y(new_n86_));
  OA21x2_ASAP7_75t_R   g043(.A1(new_n83_), .A2(new_n84_), .B(new_n86_), .Y(new_n87_));
  OR3x1_ASAP7_75t_R    g044(.A(new_n85_), .B(new_n48_), .C(G27), .Y(new_n88_));
  AOI21x1_ASAP7_75t_R  g045(.A1(G8), .A2(G426), .B(new_n54_), .Y(new_n89_));
  AO21x1_ASAP7_75t_R   g046(.A1(G426), .A2(G8), .B(new_n54_), .Y(new_n90_));
  AOI211x1_ASAP7_75t_R g047(.A1(new_n89_), .A2(new_n62_), .B(new_n82_), .C(new_n87_), .Y(new_n91_));
  AO21x1_ASAP7_75t_R   g048(.A1(G426), .A2(G20), .B(new_n49_), .Y(new_n92_));
  AO21x1_ASAP7_75t_R   g049(.A1(G426), .A2(G12), .B(new_n52_), .Y(new_n93_));
  INVx1_ASAP7_75t_R    g050(.A(new_n93_), .Y(new_n94_));
  OA22x2_ASAP7_75t_R   g051(.A1(new_n93_), .A2(G15), .B1(new_n92_), .B2(G23), .Y(new_n95_));
  AO21x1_ASAP7_75t_R   g052(.A1(G426), .A2(G16), .B(new_n51_), .Y(new_n96_));
  INVx1_ASAP7_75t_R    g053(.A(new_n96_), .Y(new_n97_));
  AO21x1_ASAP7_75t_R   g054(.A1(G426), .A2(G1), .B(new_n58_), .Y(new_n98_));
  OA22x2_ASAP7_75t_R   g055(.A1(new_n98_), .A2(G3), .B1(new_n96_), .B2(G19), .Y(new_n99_));
  AO21x1_ASAP7_75t_R   g056(.A1(G426), .A2(G32), .B(new_n45_), .Y(new_n100_));
  AO21x1_ASAP7_75t_R   g057(.A1(G426), .A2(G4), .B(new_n56_), .Y(new_n101_));
  OA22x2_ASAP7_75t_R   g058(.A1(new_n101_), .A2(G7), .B1(new_n100_), .B2(G35), .Y(new_n102_));
  AND4x2_ASAP7_75t_R   g059(.A(new_n91_), .B(new_n95_), .C(new_n99_), .D(new_n102_), .Y(new_n103_));
  INVx1_ASAP7_75t_R    g060(.A(new_n103_), .Y(G427));
  OA21x2_ASAP7_75t_R   g061(.A1(new_n103_), .A2(new_n60_), .B(new_n97_), .Y(new_n105_));
  OA211x2_ASAP7_75t_R  g062(.A1(new_n103_), .A2(new_n60_), .B(new_n67_), .C(new_n97_), .Y(new_n106_));
  AOI21x1_ASAP7_75t_R  g063(.A1(G23), .A2(G427), .B(new_n92_), .Y(new_n107_));
  OA21x2_ASAP7_75t_R   g064(.A1(new_n103_), .A2(new_n61_), .B(new_n94_), .Y(new_n108_));
  OA211x2_ASAP7_75t_R  g065(.A1(new_n103_), .A2(new_n61_), .B(new_n68_), .C(new_n94_), .Y(new_n109_));
  AOI211x1_ASAP7_75t_R g066(.A1(new_n107_), .A2(new_n66_), .B(new_n106_), .C(new_n109_), .Y(new_n110_));
  AOI21x1_ASAP7_75t_R  g067(.A1(G7), .A2(G427), .B(new_n101_), .Y(new_n111_));
  AO21x1_ASAP7_75t_R   g068(.A1(G427), .A2(G7), .B(new_n101_), .Y(new_n112_));
  AO21x1_ASAP7_75t_R   g069(.A1(G427), .A2(G3), .B(new_n98_), .Y(new_n113_));
  OA22x2_ASAP7_75t_R   g070(.A1(new_n113_), .A2(G5), .B1(new_n112_), .B2(G9), .Y(new_n114_));
  AOI21x1_ASAP7_75t_R  g071(.A1(G31), .A2(G427), .B(new_n81_), .Y(new_n115_));
  AO211x2_ASAP7_75t_R  g072(.A1(G31), .A2(G427), .B(new_n81_), .C(G33), .Y(new_n116_));
  AO21x1_ASAP7_75t_R   g073(.A1(G427), .A2(G35), .B(new_n100_), .Y(new_n117_));
  INVx1_ASAP7_75t_R    g074(.A(new_n117_), .Y(new_n118_));
  AO211x2_ASAP7_75t_R  g075(.A1(G35), .A2(G427), .B(new_n100_), .C(G36), .Y(new_n119_));
  OA21x2_ASAP7_75t_R   g076(.A1(G36), .A2(new_n117_), .B(new_n116_), .Y(new_n120_));
  OA21x2_ASAP7_75t_R   g077(.A1(new_n103_), .A2(new_n62_), .B(new_n89_), .Y(new_n121_));
  AO21x1_ASAP7_75t_R   g078(.A1(G427), .A2(G11), .B(new_n90_), .Y(new_n122_));
  AO211x2_ASAP7_75t_R  g079(.A1(G11), .A2(G427), .B(new_n90_), .C(G13), .Y(new_n123_));
  OR3x1_ASAP7_75t_R    g080(.A(new_n85_), .B(new_n48_), .C(G29), .Y(new_n124_));
  AO21x1_ASAP7_75t_R   g081(.A1(new_n88_), .A2(G427), .B(new_n124_), .Y(new_n125_));
  OA21x2_ASAP7_75t_R   g082(.A1(new_n122_), .A2(G13), .B(new_n125_), .Y(new_n126_));
  AND4x2_ASAP7_75t_R   g083(.A(new_n116_), .B(new_n119_), .C(new_n123_), .D(new_n125_), .Y(new_n127_));
  AND3x1_ASAP7_75t_R   g084(.A(new_n114_), .B(new_n120_), .C(new_n126_), .Y(new_n128_));
  AND4x2_ASAP7_75t_R   g085(.A(new_n110_), .B(new_n114_), .C(new_n120_), .D(new_n126_), .Y(new_n129_));
  INVx1_ASAP7_75t_R    g086(.A(new_n129_), .Y(G428));
  AOI21x1_ASAP7_75t_R  g087(.A1(G5), .A2(G428), .B(new_n113_), .Y(new_n131_));
  AO21x1_ASAP7_75t_R   g088(.A1(new_n110_), .A2(new_n128_), .B(new_n67_), .Y(new_n132_));
  OAI21x1_ASAP7_75t_R  g089(.A1(new_n67_), .A2(new_n129_), .B(new_n105_), .Y(new_n133_));
  AO31x2_ASAP7_75t_R   g090(.A1(new_n110_), .A2(new_n114_), .A3(new_n127_), .B(new_n68_), .Y(new_n134_));
  OAI21x1_ASAP7_75t_R  g091(.A1(new_n68_), .A2(new_n129_), .B(new_n108_), .Y(new_n135_));
  AND2x2_ASAP7_75t_R   g092(.A(new_n133_), .B(new_n135_), .Y(new_n136_));
  AO31x2_ASAP7_75t_R   g093(.A1(new_n110_), .A2(new_n114_), .A3(new_n127_), .B(new_n69_), .Y(new_n137_));
  AND2x2_ASAP7_75t_R   g094(.A(new_n137_), .B(new_n121_), .Y(new_n138_));
  AO31x2_ASAP7_75t_R   g095(.A1(new_n110_), .A2(new_n114_), .A3(new_n127_), .B(new_n70_), .Y(new_n139_));
  NAND2x1_ASAP7_75t_R  g096(.A(new_n111_), .B(new_n139_), .Y(new_n140_));
  AOI22x1_ASAP7_75t_R  g097(.A1(new_n139_), .A2(new_n111_), .B1(new_n137_), .B2(new_n121_), .Y(new_n141_));
  AO21x1_ASAP7_75t_R   g098(.A1(new_n111_), .A2(new_n139_), .B(new_n138_), .Y(new_n142_));
  AND3x1_ASAP7_75t_R   g099(.A(new_n141_), .B(new_n135_), .C(new_n133_), .Y(new_n143_));
  INVx1_ASAP7_75t_R    g100(.A(new_n143_), .Y(G430));
  OAI21x1_ASAP7_75t_R  g101(.A1(new_n63_), .A2(new_n129_), .B(new_n118_), .Y(new_n145_));
  AO21x1_ASAP7_75t_R   g102(.A1(G426), .A2(G24), .B(new_n48_), .Y(new_n146_));
  AOI21x1_ASAP7_75t_R  g103(.A1(G27), .A2(G427), .B(new_n146_), .Y(new_n147_));
  OAI21x1_ASAP7_75t_R  g104(.A1(new_n65_), .A2(new_n129_), .B(new_n147_), .Y(new_n148_));
  INVx1_ASAP7_75t_R    g105(.A(new_n148_), .Y(new_n149_));
  OAI21x1_ASAP7_75t_R  g106(.A1(new_n66_), .A2(new_n129_), .B(new_n107_), .Y(new_n150_));
  OA21x2_ASAP7_75t_R   g107(.A1(new_n129_), .A2(new_n64_), .B(new_n115_), .Y(new_n151_));
  OAI21x1_ASAP7_75t_R  g108(.A1(new_n64_), .A2(new_n129_), .B(new_n115_), .Y(new_n152_));
  AND4x2_ASAP7_75t_R   g109(.A(new_n145_), .B(new_n148_), .C(new_n150_), .D(new_n152_), .Y(new_n153_));
  AOI21x1_ASAP7_75t_R  g110(.A1(new_n143_), .A2(new_n153_), .B(new_n131_), .Y(G429));
  AOI22x1_ASAP7_75t_R  g111(.A1(new_n137_), .A2(new_n121_), .B1(new_n134_), .B2(new_n108_), .Y(new_n155_));
  AO22x1_ASAP7_75t_R   g112(.A1(new_n137_), .A2(new_n121_), .B1(new_n134_), .B2(new_n108_), .Y(new_n156_));
  AOI211x1_ASAP7_75t_R g113(.A1(new_n132_), .A2(new_n105_), .B(new_n156_), .C(new_n150_), .Y(new_n157_));
  AO211x2_ASAP7_75t_R  g114(.A1(new_n136_), .A2(new_n149_), .B(new_n142_), .C(new_n157_), .Y(G431));
  AND2x2_ASAP7_75t_R   g115(.A(new_n151_), .B(new_n148_), .Y(new_n159_));
  OAI21x1_ASAP7_75t_R  g116(.A1(new_n135_), .A2(new_n138_), .B(new_n140_), .Y(new_n160_));
  AO211x2_ASAP7_75t_R  g117(.A1(new_n155_), .A2(new_n159_), .B(new_n160_), .C(new_n157_), .Y(G432));
endmodule


