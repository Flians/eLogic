// Benchmark "/home/flynn/workplace/MIGBalance/tools/mockturtle/experiments/benchmarks/c880" written by ABC on Wed Oct  7 15:32:37 2026

module \/home/flynn/workplace/MIGBalance/tools/mockturtle/experiments/benchmarks/c880  ( 
    G8, G16, G6, G17, G7, G18, G19, G4, G3, G2, G1, G5, G11, G23, G20, G21,
    G9, G10, G12, G15, G22, G32, G24, G25, G26, G27, G28, G29, G30, G31,
    G33, G41, G42, G43, G44, G45, G46, G47, G48, G49, G13, G14, G55, G59,
    G54, G60, G39, G40, G52, G53, G50, G51, G58, G35, G37, G36, G56, G57,
    G34, G38,
    G855, G856, G857, G858, G859, G860, G861, G862, G863, G864, G865, G866,
    G867, G868, G869, G870, G871, G872, G873, G874, G875, G876, G877, G878,
    G879, G880  );
  input  G8, G16, G6, G17, G7, G18, G19, G4, G3, G2, G1, G5, G11, G23,
    G20, G21, G9, G10, G12, G15, G22, G32, G24, G25, G26, G27, G28, G29,
    G30, G31, G33, G41, G42, G43, G44, G45, G46, G47, G48, G49, G13, G14,
    G55, G59, G54, G60, G39, G40, G52, G53, G50, G51, G58, G35, G37, G36,
    G56, G57, G34, G38;
  output G855, G856, G857, G858, G859, G860, G861, G862, G863, G864, G865,
    G866, G867, G868, G869, G870, G871, G872, G873, G874, G875, G876, G877,
    G878, G879, G880;
  wire new_n117_, new_n119_, new_n126_, new_n128_, new_n129_, new_n131_,
    new_n134_, new_n135_, new_n136_, new_n137_, new_n138_, new_n139_,
    new_n140_, new_n141_, new_n143_, new_n144_, new_n145_, new_n146_,
    new_n147_, new_n148_, new_n149_, new_n150_, new_n152_, new_n153_,
    new_n154_, new_n155_, new_n156_, new_n157_, new_n159_, new_n160_,
    new_n163_, new_n164_, new_n165_, new_n167_, new_n169_, new_n170_,
    new_n171_, new_n173_, new_n175_, new_n177_, new_n178_, new_n179_,
    new_n180_, new_n182_, new_n183_, new_n185_, new_n186_, new_n187_,
    new_n188_, new_n189_, new_n190_, new_n191_, new_n193_, new_n194_,
    new_n195_, new_n197_, new_n198_, new_n199_, new_n200_, new_n201_,
    new_n203_, new_n205_, new_n206_, new_n207_, new_n208_, new_n209_,
    new_n211_, new_n212_, new_n213_, new_n214_, new_n215_, new_n216_,
    new_n217_, new_n218_, new_n219_, new_n221_, new_n222_, new_n223_,
    new_n224_, new_n225_, new_n226_, new_n227_, new_n228_, new_n230_,
    new_n231_, new_n232_, new_n233_, new_n234_, new_n236_, new_n237_,
    new_n239_, new_n240_, new_n242_, new_n244_, new_n245_, new_n247_,
    new_n248_, new_n249_, new_n251_, new_n252_, new_n253_, new_n254_,
    new_n257_, new_n259_, new_n262_, new_n264_, new_n265_, new_n266_,
    new_n267_, new_n268_, new_n269_, new_n271_, new_n272_, new_n273_,
    new_n274_, new_n275_, new_n276_, new_n278_, new_n279_, new_n280_,
    new_n281_, new_n282_, new_n283_, new_n284_, new_n285_, new_n287_,
    new_n288_, new_n289_, new_n290_, new_n291_, new_n292_, new_n293_,
    new_n295_, new_n296_, new_n297_, new_n298_, new_n299_, new_n300_,
    new_n301_, new_n302_, new_n303_, new_n304_, new_n305_, new_n306_,
    new_n307_, new_n308_, new_n309_, new_n310_, new_n311_, new_n312_,
    new_n313_, new_n314_, new_n315_, new_n316_, new_n317_, new_n318_,
    new_n319_, new_n321_, new_n322_, new_n323_, new_n324_, new_n325_,
    new_n326_, new_n327_, new_n328_, new_n329_, new_n330_, new_n331_,
    new_n332_, new_n333_, new_n334_, new_n335_, new_n336_, new_n337_,
    new_n338_, new_n339_, new_n340_, new_n341_, new_n343_, new_n344_,
    new_n345_;
  OR3x1_ASAP7_75t_R    g000(.A(new_n296_), .B(new_n297_), .C(new_n295_), .Y(G855));
  OR3x1_ASAP7_75t_R    g001(.A(new_n297_), .B(new_n299_), .C(new_n298_), .Y(G856));
  OR3x1_ASAP7_75t_R    g002(.A(new_n297_), .B(new_n299_), .C(new_n295_), .Y(G857));
  NAND2x1_ASAP7_75t_R  g003(.A(G18), .B(G19), .Y(G858));
  AND4x2_ASAP7_75t_R   g004(.A(G4), .B(G3), .C(G2), .D(G1), .Y(new_n117_));
  INVx1_ASAP7_75t_R    g005(.A(new_n117_), .Y(G859));
  AND4x2_ASAP7_75t_R   g006(.A(G4), .B(G3), .C(G1), .D(G5), .Y(new_n119_));
  AND2x2_ASAP7_75t_R   g007(.A(G857), .B(new_n119_), .Y(G860));
  AND3x1_ASAP7_75t_R   g008(.A(G16), .B(G11), .C(G17), .Y(G861));
  AND3x1_ASAP7_75t_R   g009(.A(G7), .B(G11), .C(G17), .Y(G862));
  AND3x1_ASAP7_75t_R   g010(.A(G7), .B(G11), .C(G8), .Y(G863));
  OAI21x1_ASAP7_75t_R  g011(.A1(G20), .A2(G21), .B(G23), .Y(G864));
  AND4x2_ASAP7_75t_R   g012(.A(G6), .B(G7), .C(G8), .D(new_n119_), .Y(G865));
  AND3x1_ASAP7_75t_R   g013(.A(G1), .B(G5), .C(G9), .Y(new_n126_));
  AND4x2_ASAP7_75t_R   g014(.A(G2), .B(G1), .C(G3), .D(G10), .Y(new_n128_));
  AND3x1_ASAP7_75t_R   g015(.A(G6), .B(G12), .C(new_n128_), .Y(new_n129_));
  INVx1_ASAP7_75t_R    g016(.A(new_n129_), .Y(G867));
  AND4x2_ASAP7_75t_R   g017(.A(G11), .B(G12), .C(G15), .D(new_n128_), .Y(new_n131_));
  INVx1_ASAP7_75t_R    g018(.A(new_n131_), .Y(G868));
  OAI21x1_ASAP7_75t_R  g019(.A1(G20), .A2(G21), .B(G22), .Y(G869));
  XOR2x2_ASAP7_75t_R   g020(.A(G24), .B(G25), .Y(new_n134_));
  XOR2x2_ASAP7_75t_R   g021(.A(G26), .B(G27), .Y(new_n135_));
  XNOR2x2_ASAP7_75t_R  g022(.A(new_n134_), .B(new_n135_), .Y(new_n136_));
  XNOR2x2_ASAP7_75t_R  g023(.A(G32), .B(new_n136_), .Y(new_n137_));
  AO22x1_ASAP7_75t_R   g024(.A1(G28), .A2(G29), .B1(new_n302_), .B2(new_n303_), .Y(new_n138_));
  AO22x1_ASAP7_75t_R   g025(.A1(G30), .A2(G31), .B1(new_n304_), .B2(new_n305_), .Y(new_n139_));
  XNOR2x2_ASAP7_75t_R  g026(.A(new_n138_), .B(new_n139_), .Y(new_n140_));
  XNOR2x2_ASAP7_75t_R  g027(.A(G33), .B(new_n140_), .Y(new_n141_));
  XNOR2x2_ASAP7_75t_R  g028(.A(new_n137_), .B(new_n141_), .Y(G870));
  AO22x1_ASAP7_75t_R   g029(.A1(G41), .A2(G42), .B1(new_n306_), .B2(new_n307_), .Y(new_n143_));
  AO22x1_ASAP7_75t_R   g030(.A1(G43), .A2(G44), .B1(new_n308_), .B2(new_n309_), .Y(new_n144_));
  XNOR2x2_ASAP7_75t_R  g031(.A(new_n143_), .B(new_n144_), .Y(new_n145_));
  XNOR2x2_ASAP7_75t_R  g032(.A(G32), .B(new_n145_), .Y(new_n146_));
  AO22x1_ASAP7_75t_R   g033(.A1(G45), .A2(G46), .B1(new_n310_), .B2(new_n311_), .Y(new_n147_));
  AO22x1_ASAP7_75t_R   g034(.A1(G47), .A2(G48), .B1(new_n312_), .B2(new_n313_), .Y(new_n148_));
  XNOR2x2_ASAP7_75t_R  g035(.A(new_n147_), .B(new_n148_), .Y(new_n149_));
  XNOR2x2_ASAP7_75t_R  g036(.A(G49), .B(new_n149_), .Y(new_n150_));
  XNOR2x2_ASAP7_75t_R  g037(.A(new_n146_), .B(new_n150_), .Y(G871));
  AND4x2_ASAP7_75t_R   g038(.A(G12), .B(G13), .C(G8), .D(G11), .Y(new_n152_));
  AND3x1_ASAP7_75t_R   g039(.A(new_n128_), .B(new_n152_), .C(G14), .Y(new_n153_));
  AND3x1_ASAP7_75t_R   g040(.A(G16), .B(G6), .C(G17), .Y(new_n154_));
  AND4x2_ASAP7_75t_R   g041(.A(new_n126_), .B(new_n154_), .C(G10), .D(new_n314_), .Y(new_n155_));
  INVx1_ASAP7_75t_R    g042(.A(new_n155_), .Y(new_n156_));
  AO21x1_ASAP7_75t_R   g043(.A1(G11), .A2(G40), .B(G866), .Y(new_n157_));
  OA21x2_ASAP7_75t_R   g044(.A1(new_n300_), .A2(new_n157_), .B(G1), .Y(new_n159_));
  OR2x4_ASAP7_75t_R    g045(.A(new_n315_), .B(new_n159_), .Y(new_n160_));
  AND4x2_ASAP7_75t_R   g046(.A(G2), .B(G1), .C(G4), .D(G9), .Y(new_n163_));
  OR3x1_ASAP7_75t_R    g047(.A(new_n296_), .B(new_n301_), .C(new_n295_), .Y(new_n164_));
  AO21x1_ASAP7_75t_R   g048(.A1(new_n163_), .A2(new_n164_), .B(new_n323_), .Y(new_n165_));
  OA211x2_ASAP7_75t_R  g049(.A1(new_n305_), .A2(new_n324_), .B(new_n160_), .C(new_n156_), .Y(new_n167_));
  AO22x1_ASAP7_75t_R   g050(.A1(G55), .A2(G59), .B1(G54), .B2(new_n325_), .Y(new_n169_));
  AO21x1_ASAP7_75t_R   g051(.A1(G48), .A2(new_n153_), .B(new_n169_), .Y(new_n170_));
  NOR2x1_ASAP7_75t_R   g052(.A(G48), .B(new_n325_), .Y(new_n171_));
  NOR2x1_ASAP7_75t_R   g053(.A(new_n313_), .B(new_n167_), .Y(new_n173_));
  AO21x1_ASAP7_75t_R   g054(.A1(new_n313_), .A2(new_n167_), .B(new_n173_), .Y(new_n175_));
  AO22x1_ASAP7_75t_R   g055(.A1(G52), .A2(new_n328_), .B1(G53), .B2(new_n173_), .Y(new_n177_));
  AOI22x1_ASAP7_75t_R  g056(.A1(new_n316_), .A2(new_n175_), .B1(G58), .B2(new_n328_), .Y(new_n178_));
  AO22x1_ASAP7_75t_R   g057(.A1(G30), .A2(G50), .B1(G51), .B2(new_n178_), .Y(new_n179_));
  OR3x1_ASAP7_75t_R    g058(.A(new_n177_), .B(new_n179_), .C(new_n170_), .Y(new_n180_));
  INVx1_ASAP7_75t_R    g059(.A(new_n180_), .Y(G872));
  OR2x4_ASAP7_75t_R    g060(.A(new_n317_), .B(new_n159_), .Y(new_n182_));
  OA211x2_ASAP7_75t_R  g061(.A1(new_n302_), .A2(new_n324_), .B(new_n182_), .C(new_n156_), .Y(new_n183_));
  AO22x1_ASAP7_75t_R   g062(.A1(G54), .A2(new_n329_), .B1(G45), .B2(new_n153_), .Y(new_n185_));
  NAND2x1_ASAP7_75t_R  g063(.A(new_n310_), .B(new_n183_), .Y(new_n186_));
  NOR2x1_ASAP7_75t_R   g064(.A(new_n310_), .B(new_n183_), .Y(new_n187_));
  OA21x2_ASAP7_75t_R   g065(.A1(new_n310_), .A2(new_n183_), .B(new_n186_), .Y(new_n188_));
  AO22x1_ASAP7_75t_R   g066(.A1(G52), .A2(new_n188_), .B1(G53), .B2(new_n187_), .Y(new_n189_));
  OR2x4_ASAP7_75t_R    g067(.A(new_n318_), .B(new_n159_), .Y(new_n190_));
  OA211x2_ASAP7_75t_R  g068(.A1(new_n304_), .A2(new_n324_), .B(new_n190_), .C(new_n156_), .Y(new_n191_));
  NOR2x1_ASAP7_75t_R   g069(.A(G47), .B(new_n330_), .Y(new_n193_));
  OR2x4_ASAP7_75t_R    g070(.A(new_n319_), .B(new_n159_), .Y(new_n194_));
  OA211x2_ASAP7_75t_R  g071(.A1(new_n303_), .A2(new_n324_), .B(new_n194_), .C(new_n156_), .Y(new_n195_));
  NOR2x1_ASAP7_75t_R   g072(.A(G46), .B(new_n331_), .Y(new_n197_));
  NOR2x1_ASAP7_75t_R   g073(.A(new_n193_), .B(new_n197_), .Y(new_n198_));
  AND3x1_ASAP7_75t_R   g074(.A(G58), .B(new_n326_), .C(new_n198_), .Y(new_n199_));
  AOI21x1_ASAP7_75t_R  g075(.A1(new_n173_), .A2(new_n198_), .B(new_n199_), .Y(new_n200_));
  NOR2x1_ASAP7_75t_R   g076(.A(new_n312_), .B(new_n191_), .Y(new_n201_));
  NOR2x1_ASAP7_75t_R   g077(.A(new_n311_), .B(new_n195_), .Y(new_n203_));
  OA211x2_ASAP7_75t_R  g078(.A1(new_n197_), .A2(new_n332_), .B(new_n333_), .C(new_n200_), .Y(new_n205_));
  INVx1_ASAP7_75t_R    g079(.A(new_n205_), .Y(new_n206_));
  XOR2x2_ASAP7_75t_R   g080(.A(new_n188_), .B(new_n206_), .Y(new_n207_));
  AO22x1_ASAP7_75t_R   g081(.A1(G27), .A2(G50), .B1(G51), .B2(new_n207_), .Y(new_n208_));
  OR3x1_ASAP7_75t_R    g082(.A(new_n189_), .B(new_n208_), .C(new_n185_), .Y(new_n209_));
  INVx1_ASAP7_75t_R    g083(.A(new_n209_), .Y(G873));
  AO22x1_ASAP7_75t_R   g084(.A1(G55), .A2(G56), .B1(G54), .B2(new_n331_), .Y(new_n211_));
  AO21x1_ASAP7_75t_R   g085(.A1(G46), .A2(new_n153_), .B(new_n211_), .Y(new_n212_));
  NOR2x1_ASAP7_75t_R   g086(.A(new_n197_), .B(new_n203_), .Y(new_n213_));
  AO22x1_ASAP7_75t_R   g087(.A1(G52), .A2(new_n213_), .B1(G53), .B2(new_n203_), .Y(new_n214_));
  OR3x1_ASAP7_75t_R    g088(.A(new_n171_), .B(new_n193_), .C(new_n316_), .Y(new_n215_));
  OA211x2_ASAP7_75t_R  g089(.A1(new_n327_), .A2(new_n193_), .B(new_n332_), .C(new_n215_), .Y(new_n216_));
  XNOR2x2_ASAP7_75t_R  g090(.A(new_n213_), .B(new_n216_), .Y(new_n217_));
  AO22x1_ASAP7_75t_R   g091(.A1(G28), .A2(G50), .B1(G51), .B2(new_n217_), .Y(new_n218_));
  OR3x1_ASAP7_75t_R    g092(.A(new_n214_), .B(new_n218_), .C(new_n212_), .Y(new_n219_));
  INVx1_ASAP7_75t_R    g093(.A(new_n219_), .Y(G874));
  AO22x1_ASAP7_75t_R   g094(.A1(G55), .A2(G57), .B1(G54), .B2(new_n330_), .Y(new_n221_));
  AO21x1_ASAP7_75t_R   g095(.A1(G47), .A2(new_n153_), .B(new_n221_), .Y(new_n222_));
  NOR2x1_ASAP7_75t_R   g096(.A(new_n193_), .B(new_n201_), .Y(new_n223_));
  AO22x1_ASAP7_75t_R   g097(.A1(G52), .A2(new_n223_), .B1(G53), .B2(new_n201_), .Y(new_n224_));
  AO21x1_ASAP7_75t_R   g098(.A1(G58), .A2(new_n326_), .B(new_n173_), .Y(new_n225_));
  XOR2x2_ASAP7_75t_R   g099(.A(new_n223_), .B(new_n225_), .Y(new_n226_));
  AO22x1_ASAP7_75t_R   g100(.A1(G29), .A2(G50), .B1(G51), .B2(new_n226_), .Y(new_n227_));
  OR3x1_ASAP7_75t_R    g101(.A(new_n224_), .B(new_n227_), .C(new_n222_), .Y(new_n228_));
  INVx1_ASAP7_75t_R    g102(.A(new_n228_), .Y(G875));
  AOI22x1_ASAP7_75t_R  g103(.A1(G2), .A2(G34), .B1(G24), .B2(new_n165_), .Y(new_n230_));
  NAND2x1_ASAP7_75t_R  g104(.A(G10), .B(new_n321_), .Y(new_n231_));
  AND4x2_ASAP7_75t_R   g105(.A(G4), .B(new_n126_), .C(new_n154_), .D(new_n314_), .Y(new_n232_));
  INVx1_ASAP7_75t_R    g106(.A(new_n232_), .Y(new_n233_));
  OA211x2_ASAP7_75t_R  g107(.A1(new_n317_), .A2(new_n231_), .B(new_n233_), .C(new_n230_), .Y(new_n234_));
  NOR2x1_ASAP7_75t_R   g108(.A(new_n306_), .B(new_n234_), .Y(new_n236_));
  AO21x1_ASAP7_75t_R   g109(.A1(new_n186_), .A2(new_n206_), .B(new_n187_), .Y(new_n237_));
  AOI22x1_ASAP7_75t_R  g110(.A1(G34), .A2(G38), .B1(G27), .B2(new_n165_), .Y(new_n239_));
  OA211x2_ASAP7_75t_R  g111(.A1(new_n315_), .A2(new_n231_), .B(new_n233_), .C(new_n239_), .Y(new_n240_));
  NOR2x1_ASAP7_75t_R   g112(.A(G44), .B(new_n336_), .Y(new_n242_));
  AOI22x1_ASAP7_75t_R  g113(.A1(G4), .A2(G34), .B1(G26), .B2(new_n165_), .Y(new_n244_));
  OA211x2_ASAP7_75t_R  g114(.A1(new_n318_), .A2(new_n231_), .B(new_n233_), .C(new_n244_), .Y(new_n245_));
  NOR2x1_ASAP7_75t_R   g115(.A(G43), .B(new_n338_), .Y(new_n247_));
  AOI22x1_ASAP7_75t_R  g116(.A1(G9), .A2(G34), .B1(G25), .B2(new_n165_), .Y(new_n248_));
  OA211x2_ASAP7_75t_R  g117(.A1(new_n319_), .A2(new_n231_), .B(new_n233_), .C(new_n248_), .Y(new_n249_));
  NOR2x1_ASAP7_75t_R   g118(.A(G42), .B(new_n339_), .Y(new_n251_));
  NOR2x1_ASAP7_75t_R   g119(.A(new_n247_), .B(new_n251_), .Y(new_n252_));
  AND3x1_ASAP7_75t_R   g120(.A(new_n237_), .B(new_n337_), .C(new_n252_), .Y(new_n253_));
  NOR2x1_ASAP7_75t_R   g121(.A(new_n309_), .B(new_n240_), .Y(new_n254_));
  NOR2x1_ASAP7_75t_R   g122(.A(new_n308_), .B(new_n245_), .Y(new_n257_));
  NOR2x1_ASAP7_75t_R   g123(.A(new_n307_), .B(new_n249_), .Y(new_n259_));
  AO21x1_ASAP7_75t_R   g124(.A1(new_n306_), .A2(new_n234_), .B(new_n345_), .Y(new_n262_));
  OA21x2_ASAP7_75t_R   g125(.A1(new_n306_), .A2(new_n234_), .B(new_n262_), .Y(G876));
  AO22x1_ASAP7_75t_R   g126(.A1(G54), .A2(new_n336_), .B1(G44), .B2(new_n153_), .Y(new_n264_));
  NOR2x1_ASAP7_75t_R   g127(.A(new_n242_), .B(new_n254_), .Y(new_n265_));
  AO22x1_ASAP7_75t_R   g128(.A1(G52), .A2(new_n265_), .B1(G53), .B2(new_n254_), .Y(new_n266_));
  XOR2x2_ASAP7_75t_R   g129(.A(new_n237_), .B(new_n265_), .Y(new_n267_));
  AO22x1_ASAP7_75t_R   g130(.A1(G26), .A2(G50), .B1(G51), .B2(new_n267_), .Y(new_n268_));
  OR3x1_ASAP7_75t_R    g131(.A(new_n266_), .B(new_n268_), .C(new_n264_), .Y(new_n269_));
  INVx1_ASAP7_75t_R    g132(.A(new_n269_), .Y(G877));
  AO22x1_ASAP7_75t_R   g133(.A1(G54), .A2(new_n334_), .B1(G41), .B2(new_n153_), .Y(new_n271_));
  AOI21x1_ASAP7_75t_R  g134(.A1(new_n306_), .A2(new_n234_), .B(new_n236_), .Y(new_n272_));
  AO22x1_ASAP7_75t_R   g135(.A1(G52), .A2(new_n272_), .B1(G53), .B2(new_n236_), .Y(new_n273_));
  XOR2x2_ASAP7_75t_R   g136(.A(new_n344_), .B(new_n272_), .Y(new_n274_));
  AO22x1_ASAP7_75t_R   g137(.A1(G60), .A2(G50), .B1(G51), .B2(new_n274_), .Y(new_n275_));
  OR3x1_ASAP7_75t_R    g138(.A(new_n273_), .B(new_n275_), .C(new_n271_), .Y(new_n276_));
  INVx1_ASAP7_75t_R    g139(.A(new_n276_), .Y(G878));
  AO22x1_ASAP7_75t_R   g140(.A1(G54), .A2(new_n339_), .B1(G42), .B2(new_n153_), .Y(new_n278_));
  NOR2x1_ASAP7_75t_R   g141(.A(new_n251_), .B(new_n259_), .Y(new_n279_));
  AO22x1_ASAP7_75t_R   g142(.A1(G52), .A2(new_n279_), .B1(G53), .B2(new_n259_), .Y(new_n280_));
  OR3x1_ASAP7_75t_R    g143(.A(new_n242_), .B(new_n247_), .C(new_n335_), .Y(new_n281_));
  OA211x2_ASAP7_75t_R  g144(.A1(new_n247_), .A2(new_n340_), .B(new_n341_), .C(new_n281_), .Y(new_n282_));
  XNOR2x2_ASAP7_75t_R  g145(.A(new_n279_), .B(new_n282_), .Y(new_n283_));
  AO22x1_ASAP7_75t_R   g146(.A1(G24), .A2(G50), .B1(G51), .B2(new_n283_), .Y(new_n284_));
  OR3x1_ASAP7_75t_R    g147(.A(new_n280_), .B(new_n284_), .C(new_n278_), .Y(new_n285_));
  INVx1_ASAP7_75t_R    g148(.A(new_n285_), .Y(G879));
  AO22x1_ASAP7_75t_R   g149(.A1(G54), .A2(new_n338_), .B1(G43), .B2(new_n153_), .Y(new_n287_));
  NOR2x1_ASAP7_75t_R   g150(.A(new_n247_), .B(new_n257_), .Y(new_n288_));
  AO22x1_ASAP7_75t_R   g151(.A1(G52), .A2(new_n288_), .B1(G53), .B2(new_n257_), .Y(new_n289_));
  AO21x1_ASAP7_75t_R   g152(.A1(new_n237_), .A2(new_n337_), .B(new_n254_), .Y(new_n290_));
  XOR2x2_ASAP7_75t_R   g153(.A(new_n288_), .B(new_n290_), .Y(new_n291_));
  AO22x1_ASAP7_75t_R   g154(.A1(G25), .A2(G50), .B1(G51), .B2(new_n291_), .Y(new_n292_));
  OR3x1_ASAP7_75t_R    g155(.A(new_n289_), .B(new_n292_), .C(new_n287_), .Y(new_n293_));
  INVx1_ASAP7_75t_R    g156(.A(new_n293_), .Y(G880));
  INVx1_ASAP7_75t_R    g157(.A(G8), .Y(new_n295_));
  INVx1_ASAP7_75t_R    g158(.A(G16), .Y(new_n296_));
  INVx1_ASAP7_75t_R    g159(.A(G6), .Y(new_n297_));
  INVx1_ASAP7_75t_R    g160(.A(G17), .Y(new_n298_));
  INVx1_ASAP7_75t_R    g161(.A(G7), .Y(new_n299_));
  INVx1_ASAP7_75t_R    g162(.A(G4), .Y(new_n300_));
  INVx1_ASAP7_75t_R    g163(.A(G11), .Y(new_n301_));
  INVx1_ASAP7_75t_R    g164(.A(G28), .Y(new_n302_));
  INVx1_ASAP7_75t_R    g165(.A(G29), .Y(new_n303_));
  INVx1_ASAP7_75t_R    g166(.A(G30), .Y(new_n304_));
  INVx1_ASAP7_75t_R    g167(.A(G31), .Y(new_n305_));
  INVx1_ASAP7_75t_R    g168(.A(G41), .Y(new_n306_));
  INVx1_ASAP7_75t_R    g169(.A(G42), .Y(new_n307_));
  INVx1_ASAP7_75t_R    g170(.A(G43), .Y(new_n308_));
  INVx1_ASAP7_75t_R    g171(.A(G44), .Y(new_n309_));
  INVx1_ASAP7_75t_R    g172(.A(G45), .Y(new_n310_));
  INVx1_ASAP7_75t_R    g173(.A(G46), .Y(new_n311_));
  INVx1_ASAP7_75t_R    g174(.A(G47), .Y(new_n312_));
  INVx1_ASAP7_75t_R    g175(.A(G48), .Y(new_n313_));
  INVx1_ASAP7_75t_R    g176(.A(G60), .Y(new_n314_));
  INVx1_ASAP7_75t_R    g177(.A(G39), .Y(new_n315_));
  INVx1_ASAP7_75t_R    g178(.A(G58), .Y(new_n316_));
  INVx1_ASAP7_75t_R    g179(.A(G35), .Y(new_n317_));
  INVx1_ASAP7_75t_R    g180(.A(G37), .Y(new_n318_));
  INVx1_ASAP7_75t_R    g181(.A(G36), .Y(new_n319_));
  INVx1_ASAP7_75t_R    g182(.A(new_n126_), .Y(G866));
  INVx1_ASAP7_75t_R    g183(.A(new_n157_), .Y(new_n321_));
  XOR2x2_ASAP7_75t_R   g184(.A(G8), .B(G4), .Y(new_n322_));
  AND3x1_ASAP7_75t_R   g185(.A(new_n322_), .B(new_n157_), .C(new_n126_), .Y(new_n323_));
  INVx1_ASAP7_75t_R    g186(.A(new_n165_), .Y(new_n324_));
  INVx1_ASAP7_75t_R    g187(.A(new_n167_), .Y(new_n325_));
  INVx1_ASAP7_75t_R    g188(.A(new_n171_), .Y(new_n326_));
  INVx1_ASAP7_75t_R    g189(.A(new_n173_), .Y(new_n327_));
  INVx1_ASAP7_75t_R    g190(.A(new_n175_), .Y(new_n328_));
  INVx1_ASAP7_75t_R    g191(.A(new_n183_), .Y(new_n329_));
  INVx1_ASAP7_75t_R    g192(.A(new_n191_), .Y(new_n330_));
  INVx1_ASAP7_75t_R    g193(.A(new_n195_), .Y(new_n331_));
  INVx1_ASAP7_75t_R    g194(.A(new_n201_), .Y(new_n332_));
  INVx1_ASAP7_75t_R    g195(.A(new_n203_), .Y(new_n333_));
  INVx1_ASAP7_75t_R    g196(.A(new_n234_), .Y(new_n334_));
  INVx1_ASAP7_75t_R    g197(.A(new_n237_), .Y(new_n335_));
  INVx1_ASAP7_75t_R    g198(.A(new_n240_), .Y(new_n336_));
  INVx1_ASAP7_75t_R    g199(.A(new_n242_), .Y(new_n337_));
  INVx1_ASAP7_75t_R    g200(.A(new_n245_), .Y(new_n338_));
  INVx1_ASAP7_75t_R    g201(.A(new_n249_), .Y(new_n339_));
  INVx1_ASAP7_75t_R    g202(.A(new_n254_), .Y(new_n340_));
  INVx1_ASAP7_75t_R    g203(.A(new_n257_), .Y(new_n341_));
  OA21x2_ASAP7_75t_R   g204(.A1(new_n257_), .A2(new_n254_), .B(new_n252_), .Y(new_n343_));
  OR3x1_ASAP7_75t_R    g205(.A(new_n343_), .B(new_n259_), .C(new_n253_), .Y(new_n344_));
  INVx1_ASAP7_75t_R    g206(.A(new_n344_), .Y(new_n345_));
endmodule


