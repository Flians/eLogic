// Benchmark "/home/flynn/workplace/MIGBalance/tools/mockturtle/experiments/benchmarks/c880" written by ABC on Wed Oct  7 15:32:37 2026

module \/home/flynn/workplace/MIGBalance/tools/mockturtle/experiments/benchmarks/c880  ( 
    G8, G16, G6, G17, G7, G18, G19, G4, G3, G2, G1, G5, G11, G23, G20, G21,
    G9, G10, G12, G15, G22, G32, G24, G25, G26, G27, G28, G29, G30, G31,
    G33, G41, G42, G43, G44, G45, G46, G47, G48, G49, G13, G14, G55, G59,
    G54, G60, G39, G40, G52, G53, G50, G51, G58, G35, G37, G36, G56, G57,
    G34, G38,
    G855, G856, G857, G858, G859, G860, G861, G862, G863, G864, G865, G866,
    G867, G868, G869, G870, G871, G872, G873, G874, G875, G876, G877, G878,
    G879, G880  );
  input  G8, G16, G6, G17, G7, G18, G19, G4, G3, G2, G1, G5, G11, G23,
    G20, G21, G9, G10, G12, G15, G22, G32, G24, G25, G26, G27, G28, G29,
    G30, G31, G33, G41, G42, G43, G44, G45, G46, G47, G48, G49, G13, G14,
    G55, G59, G54, G60, G39, G40, G52, G53, G50, G51, G58, G35, G37, G36,
    G56, G57, G34, G38;
  output G855, G856, G857, G858, G859, G860, G861, G862, G863, G864, G865,
    G866, G867, G868, G869, G870, G871, G872, G873, G874, G875, G876, G877,
    G878, G879, G880;
  wire new_n87_, new_n88_, new_n89_, new_n91_, new_n92_, new_n96_, new_n97_,
    new_n98_, new_n99_, new_n101_, new_n108_, new_n110_, new_n111_,
    new_n112_, new_n114_, new_n115_, new_n118_, new_n119_, new_n120_,
    new_n121_, new_n122_, new_n123_, new_n124_, new_n125_, new_n126_,
    new_n128_, new_n129_, new_n130_, new_n131_, new_n132_, new_n133_,
    new_n134_, new_n135_, new_n137_, new_n138_, new_n139_, new_n140_,
    new_n141_, new_n142_, new_n143_, new_n144_, new_n145_, new_n146_,
    new_n147_, new_n148_, new_n149_, new_n150_, new_n151_, new_n152_,
    new_n153_, new_n154_, new_n155_, new_n156_, new_n157_, new_n158_,
    new_n159_, new_n160_, new_n161_, new_n162_, new_n163_, new_n164_,
    new_n165_, new_n166_, new_n167_, new_n168_, new_n170_, new_n171_,
    new_n172_, new_n173_, new_n174_, new_n175_, new_n176_, new_n177_,
    new_n178_, new_n179_, new_n180_, new_n181_, new_n182_, new_n183_,
    new_n184_, new_n185_, new_n186_, new_n187_, new_n188_, new_n189_,
    new_n190_, new_n191_, new_n192_, new_n193_, new_n194_, new_n195_,
    new_n196_, new_n197_, new_n198_, new_n200_, new_n201_, new_n202_,
    new_n203_, new_n204_, new_n205_, new_n206_, new_n207_, new_n208_,
    new_n209_, new_n211_, new_n212_, new_n213_, new_n214_, new_n215_,
    new_n216_, new_n217_, new_n219_, new_n220_, new_n221_, new_n222_,
    new_n223_, new_n224_, new_n225_, new_n226_, new_n227_, new_n228_,
    new_n229_, new_n230_, new_n231_, new_n232_, new_n233_, new_n234_,
    new_n235_, new_n236_, new_n237_, new_n238_, new_n239_, new_n240_,
    new_n241_, new_n242_, new_n243_, new_n244_, new_n245_, new_n246_,
    new_n247_, new_n248_, new_n250_, new_n251_, new_n252_, new_n253_,
    new_n254_, new_n255_, new_n257_, new_n258_, new_n259_, new_n260_,
    new_n261_, new_n262_, new_n264_, new_n265_, new_n266_, new_n267_,
    new_n268_, new_n269_, new_n270_, new_n271_, new_n273_, new_n274_,
    new_n275_, new_n276_, new_n277_, new_n278_;
  INVx1_ASAP7_75t_R    g000(.A(G8), .Y(new_n87_));
  INVx1_ASAP7_75t_R    g001(.A(G16), .Y(new_n88_));
  INVx1_ASAP7_75t_R    g002(.A(G6), .Y(new_n89_));
  OR3x1_ASAP7_75t_R    g003(.A(new_n87_), .B(new_n88_), .C(new_n89_), .Y(G855));
  INVx1_ASAP7_75t_R    g004(.A(G17), .Y(new_n91_));
  INVx1_ASAP7_75t_R    g005(.A(G7), .Y(new_n92_));
  OR3x1_ASAP7_75t_R    g006(.A(new_n89_), .B(new_n91_), .C(new_n92_), .Y(G856));
  OR3x1_ASAP7_75t_R    g007(.A(new_n87_), .B(new_n89_), .C(new_n92_), .Y(G857));
  NAND2x1_ASAP7_75t_R  g008(.A(G18), .B(G19), .Y(G858));
  INVx1_ASAP7_75t_R    g009(.A(G4), .Y(new_n96_));
  INVx1_ASAP7_75t_R    g010(.A(G3), .Y(new_n97_));
  INVx1_ASAP7_75t_R    g011(.A(G2), .Y(new_n98_));
  INVx1_ASAP7_75t_R    g012(.A(G1), .Y(new_n99_));
  OR4x2_ASAP7_75t_R    g013(.A(new_n96_), .B(new_n97_), .C(new_n98_), .D(new_n99_), .Y(G859));
  AND4x2_ASAP7_75t_R   g014(.A(G4), .B(G3), .C(G1), .D(G5), .Y(new_n101_));
  AND2x2_ASAP7_75t_R   g015(.A(G857), .B(new_n101_), .Y(G860));
  AND3x1_ASAP7_75t_R   g016(.A(G16), .B(G17), .C(G11), .Y(G861));
  AND3x1_ASAP7_75t_R   g017(.A(G17), .B(G7), .C(G11), .Y(G862));
  AND3x1_ASAP7_75t_R   g018(.A(G8), .B(G7), .C(G11), .Y(G863));
  OAI21x1_ASAP7_75t_R  g019(.A1(G20), .A2(G21), .B(G23), .Y(G864));
  AND4x2_ASAP7_75t_R   g020(.A(new_n101_), .B(G8), .C(G6), .D(G7), .Y(G865));
  AND3x1_ASAP7_75t_R   g021(.A(G1), .B(G5), .C(G9), .Y(new_n108_));
  INVx1_ASAP7_75t_R    g022(.A(new_n108_), .Y(G866));
  INVx1_ASAP7_75t_R    g023(.A(G12), .Y(new_n110_));
  AND4x2_ASAP7_75t_R   g024(.A(G3), .B(G2), .C(G1), .D(G10), .Y(new_n111_));
  INVx1_ASAP7_75t_R    g025(.A(new_n111_), .Y(new_n112_));
  OR3x1_ASAP7_75t_R    g026(.A(new_n112_), .B(new_n89_), .C(new_n110_), .Y(G867));
  INVx1_ASAP7_75t_R    g027(.A(G11), .Y(new_n114_));
  INVx1_ASAP7_75t_R    g028(.A(G15), .Y(new_n115_));
  OR4x2_ASAP7_75t_R    g029(.A(new_n112_), .B(new_n114_), .C(new_n110_), .D(new_n115_), .Y(G868));
  OAI21x1_ASAP7_75t_R  g030(.A1(G20), .A2(G21), .B(G22), .Y(G869));
  INVx1_ASAP7_75t_R    g031(.A(G32), .Y(new_n118_));
  XOR2x2_ASAP7_75t_R   g032(.A(G24), .B(G25), .Y(new_n119_));
  XOR2x2_ASAP7_75t_R   g033(.A(G26), .B(G27), .Y(new_n120_));
  XOR2x2_ASAP7_75t_R   g034(.A(new_n119_), .B(new_n120_), .Y(new_n121_));
  XOR2x2_ASAP7_75t_R   g035(.A(new_n121_), .B(new_n118_), .Y(new_n122_));
  XOR2x2_ASAP7_75t_R   g036(.A(G28), .B(G29), .Y(new_n123_));
  XOR2x2_ASAP7_75t_R   g037(.A(G30), .B(G31), .Y(new_n124_));
  XOR2x2_ASAP7_75t_R   g038(.A(new_n123_), .B(new_n124_), .Y(new_n125_));
  XOR2x2_ASAP7_75t_R   g039(.A(new_n125_), .B(G33), .Y(new_n126_));
  XOR2x2_ASAP7_75t_R   g040(.A(new_n122_), .B(new_n126_), .Y(G870));
  XOR2x2_ASAP7_75t_R   g041(.A(G41), .B(G42), .Y(new_n128_));
  XOR2x2_ASAP7_75t_R   g042(.A(G43), .B(G44), .Y(new_n129_));
  XOR2x2_ASAP7_75t_R   g043(.A(new_n128_), .B(new_n129_), .Y(new_n130_));
  XOR2x2_ASAP7_75t_R   g044(.A(new_n130_), .B(new_n118_), .Y(new_n131_));
  XOR2x2_ASAP7_75t_R   g045(.A(G45), .B(G46), .Y(new_n132_));
  XOR2x2_ASAP7_75t_R   g046(.A(G47), .B(G48), .Y(new_n133_));
  XOR2x2_ASAP7_75t_R   g047(.A(new_n132_), .B(new_n133_), .Y(new_n134_));
  XOR2x2_ASAP7_75t_R   g048(.A(new_n134_), .B(G49), .Y(new_n135_));
  XOR2x2_ASAP7_75t_R   g049(.A(new_n131_), .B(new_n135_), .Y(G871));
  INVx1_ASAP7_75t_R    g050(.A(G48), .Y(new_n137_));
  AND4x2_ASAP7_75t_R   g051(.A(G8), .B(G11), .C(G12), .D(G13), .Y(new_n138_));
  AND3x1_ASAP7_75t_R   g052(.A(new_n111_), .B(new_n138_), .C(G14), .Y(new_n139_));
  INVx1_ASAP7_75t_R    g053(.A(new_n139_), .Y(new_n140_));
  INVx1_ASAP7_75t_R    g054(.A(G54), .Y(new_n141_));
  NAND2x1_ASAP7_75t_R  g055(.A(G55), .B(G59), .Y(new_n142_));
  INVx1_ASAP7_75t_R    g056(.A(G31), .Y(new_n143_));
  INVx1_ASAP7_75t_R    g057(.A(G60), .Y(new_n144_));
  AND3x1_ASAP7_75t_R   g058(.A(G16), .B(G6), .C(G17), .Y(new_n145_));
  AND3x1_ASAP7_75t_R   g059(.A(new_n108_), .B(new_n145_), .C(G10), .Y(new_n146_));
  AND2x2_ASAP7_75t_R   g060(.A(new_n146_), .B(new_n144_), .Y(new_n147_));
  INVx1_ASAP7_75t_R    g061(.A(new_n147_), .Y(new_n148_));
  AOI21x1_ASAP7_75t_R  g062(.A1(G11), .A2(G40), .B(G866), .Y(new_n149_));
  AO21x1_ASAP7_75t_R   g063(.A1(new_n149_), .A2(G4), .B(new_n99_), .Y(new_n150_));
  NAND2x1_ASAP7_75t_R  g064(.A(G39), .B(new_n150_), .Y(new_n151_));
  NAND2x1_ASAP7_75t_R  g065(.A(new_n87_), .B(new_n96_), .Y(new_n152_));
  NAND2x1_ASAP7_75t_R  g066(.A(G8), .B(G4), .Y(new_n153_));
  AND3x1_ASAP7_75t_R   g067(.A(new_n152_), .B(G11), .C(new_n153_), .Y(new_n154_));
  AND3x1_ASAP7_75t_R   g068(.A(new_n154_), .B(G40), .C(new_n108_), .Y(new_n155_));
  AND4x2_ASAP7_75t_R   g069(.A(G4), .B(G2), .C(G1), .D(G9), .Y(new_n156_));
  OR3x1_ASAP7_75t_R    g070(.A(new_n87_), .B(new_n88_), .C(new_n114_), .Y(new_n157_));
  AO21x1_ASAP7_75t_R   g071(.A1(new_n156_), .A2(new_n157_), .B(new_n155_), .Y(new_n158_));
  INVx1_ASAP7_75t_R    g072(.A(new_n158_), .Y(new_n159_));
  OA211x2_ASAP7_75t_R  g073(.A1(new_n159_), .A2(new_n143_), .B(new_n148_), .C(new_n151_), .Y(new_n160_));
  OA21x2_ASAP7_75t_R   g074(.A1(new_n160_), .A2(new_n141_), .B(new_n142_), .Y(new_n161_));
  OA21x2_ASAP7_75t_R   g075(.A1(new_n137_), .A2(new_n140_), .B(new_n161_), .Y(new_n162_));
  NOR2x1_ASAP7_75t_R   g076(.A(new_n137_), .B(new_n160_), .Y(new_n163_));
  AND2x2_ASAP7_75t_R   g077(.A(new_n160_), .B(new_n137_), .Y(new_n164_));
  NOR2x1_ASAP7_75t_R   g078(.A(new_n164_), .B(new_n163_), .Y(new_n165_));
  AOI22x1_ASAP7_75t_R  g079(.A1(G53), .A2(new_n163_), .B1(new_n165_), .B2(G52), .Y(new_n166_));
  XOR2x2_ASAP7_75t_R   g080(.A(new_n165_), .B(G58), .Y(new_n167_));
  AOI22x1_ASAP7_75t_R  g081(.A1(G30), .A2(G50), .B1(new_n167_), .B2(G51), .Y(new_n168_));
  AND3x1_ASAP7_75t_R   g082(.A(new_n168_), .B(new_n162_), .C(new_n166_), .Y(G872));
  INVx1_ASAP7_75t_R    g083(.A(G45), .Y(new_n170_));
  AOI22x1_ASAP7_75t_R  g084(.A1(G35), .A2(new_n150_), .B1(new_n158_), .B2(G28), .Y(new_n171_));
  AND2x2_ASAP7_75t_R   g085(.A(new_n171_), .B(new_n148_), .Y(new_n172_));
  OA22x2_ASAP7_75t_R   g086(.A1(new_n170_), .A2(new_n140_), .B1(new_n172_), .B2(new_n141_), .Y(new_n173_));
  INVx1_ASAP7_75t_R    g087(.A(G52), .Y(new_n174_));
  INVx1_ASAP7_75t_R    g088(.A(G53), .Y(new_n175_));
  NOR2x1_ASAP7_75t_R   g089(.A(new_n170_), .B(new_n172_), .Y(new_n176_));
  INVx1_ASAP7_75t_R    g090(.A(new_n176_), .Y(new_n177_));
  XOR2x2_ASAP7_75t_R   g091(.A(new_n172_), .B(G45), .Y(new_n178_));
  OA22x2_ASAP7_75t_R   g092(.A1(new_n174_), .A2(new_n178_), .B1(new_n177_), .B2(new_n175_), .Y(new_n179_));
  INVx1_ASAP7_75t_R    g093(.A(G46), .Y(new_n180_));
  INVx1_ASAP7_75t_R    g094(.A(G29), .Y(new_n181_));
  NAND2x1_ASAP7_75t_R  g095(.A(G36), .B(new_n150_), .Y(new_n182_));
  OA211x2_ASAP7_75t_R  g096(.A1(new_n159_), .A2(new_n181_), .B(new_n148_), .C(new_n182_), .Y(new_n183_));
  NAND2x1_ASAP7_75t_R  g097(.A(new_n180_), .B(new_n183_), .Y(new_n184_));
  INVx1_ASAP7_75t_R    g098(.A(new_n164_), .Y(new_n185_));
  AND2x2_ASAP7_75t_R   g099(.A(new_n185_), .B(G58), .Y(new_n186_));
  AO22x1_ASAP7_75t_R   g100(.A1(new_n158_), .A2(G30), .B1(G37), .B2(new_n150_), .Y(new_n187_));
  NOR2x1_ASAP7_75t_R   g101(.A(new_n147_), .B(new_n187_), .Y(new_n188_));
  INVx1_ASAP7_75t_R    g102(.A(new_n188_), .Y(new_n189_));
  NOR2x1_ASAP7_75t_R   g103(.A(G47), .B(new_n189_), .Y(new_n190_));
  AND2x2_ASAP7_75t_R   g104(.A(new_n183_), .B(new_n180_), .Y(new_n191_));
  NOR2x1_ASAP7_75t_R   g105(.A(new_n191_), .B(new_n190_), .Y(new_n192_));
  OA21x2_ASAP7_75t_R   g106(.A1(new_n163_), .A2(new_n186_), .B(new_n192_), .Y(new_n193_));
  AND2x2_ASAP7_75t_R   g107(.A(new_n189_), .B(G47), .Y(new_n194_));
  NOR2x1_ASAP7_75t_R   g108(.A(new_n180_), .B(new_n183_), .Y(new_n195_));
  AOI211x1_ASAP7_75t_R g109(.A1(new_n184_), .A2(new_n194_), .B(new_n193_), .C(new_n195_), .Y(new_n196_));
  XOR2x2_ASAP7_75t_R   g110(.A(new_n196_), .B(new_n178_), .Y(new_n197_));
  AOI22x1_ASAP7_75t_R  g111(.A1(G27), .A2(G50), .B1(new_n197_), .B2(G51), .Y(new_n198_));
  AND3x1_ASAP7_75t_R   g112(.A(new_n198_), .B(new_n173_), .C(new_n179_), .Y(G873));
  NAND2x1_ASAP7_75t_R  g113(.A(G55), .B(G56), .Y(new_n200_));
  OA21x2_ASAP7_75t_R   g114(.A1(new_n183_), .A2(new_n141_), .B(new_n200_), .Y(new_n201_));
  OA21x2_ASAP7_75t_R   g115(.A1(new_n180_), .A2(new_n140_), .B(new_n201_), .Y(new_n202_));
  NOR2x1_ASAP7_75t_R   g116(.A(new_n191_), .B(new_n195_), .Y(new_n203_));
  AOI22x1_ASAP7_75t_R  g117(.A1(G53), .A2(new_n195_), .B1(new_n203_), .B2(G52), .Y(new_n204_));
  INVx1_ASAP7_75t_R    g118(.A(new_n190_), .Y(new_n205_));
  AND3x1_ASAP7_75t_R   g119(.A(new_n205_), .B(G58), .C(new_n185_), .Y(new_n206_));
  AOI211x1_ASAP7_75t_R g120(.A1(new_n163_), .A2(new_n205_), .B(new_n206_), .C(new_n194_), .Y(new_n207_));
  XNOR2x2_ASAP7_75t_R  g121(.A(new_n203_), .B(new_n207_), .Y(new_n208_));
  AOI22x1_ASAP7_75t_R  g122(.A1(G28), .A2(G50), .B1(new_n208_), .B2(G51), .Y(new_n209_));
  AND3x1_ASAP7_75t_R   g123(.A(new_n209_), .B(new_n202_), .C(new_n204_), .Y(G874));
  AO22x1_ASAP7_75t_R   g124(.A1(new_n189_), .A2(G54), .B1(G55), .B2(G57), .Y(new_n211_));
  AOI21x1_ASAP7_75t_R  g125(.A1(G47), .A2(new_n139_), .B(new_n211_), .Y(new_n212_));
  NOR2x1_ASAP7_75t_R   g126(.A(new_n194_), .B(new_n190_), .Y(new_n213_));
  AOI22x1_ASAP7_75t_R  g127(.A1(G53), .A2(new_n194_), .B1(new_n213_), .B2(G52), .Y(new_n214_));
  AO21x1_ASAP7_75t_R   g128(.A1(new_n185_), .A2(G58), .B(new_n163_), .Y(new_n215_));
  XOR2x2_ASAP7_75t_R   g129(.A(new_n213_), .B(new_n215_), .Y(new_n216_));
  AOI22x1_ASAP7_75t_R  g130(.A1(G29), .A2(G50), .B1(new_n216_), .B2(G51), .Y(new_n217_));
  AND3x1_ASAP7_75t_R   g131(.A(new_n217_), .B(new_n212_), .C(new_n214_), .Y(G875));
  INVx1_ASAP7_75t_R    g132(.A(G41), .Y(new_n219_));
  AND2x2_ASAP7_75t_R   g133(.A(G2), .B(G34), .Y(new_n220_));
  AO21x1_ASAP7_75t_R   g134(.A1(new_n158_), .A2(G24), .B(new_n220_), .Y(new_n221_));
  AND3x1_ASAP7_75t_R   g135(.A(new_n149_), .B(G10), .C(G35), .Y(new_n222_));
  AND4x2_ASAP7_75t_R   g136(.A(new_n108_), .B(new_n145_), .C(G4), .D(new_n144_), .Y(new_n223_));
  NOR3x1_ASAP7_75t_R   g137(.A(new_n221_), .B(new_n222_), .C(new_n223_), .Y(new_n224_));
  AO21x1_ASAP7_75t_R   g138(.A1(new_n170_), .A2(new_n172_), .B(new_n196_), .Y(new_n225_));
  AND2x2_ASAP7_75t_R   g139(.A(new_n225_), .B(new_n177_), .Y(new_n226_));
  AO22x1_ASAP7_75t_R   g140(.A1(new_n158_), .A2(G27), .B1(G34), .B2(G38), .Y(new_n227_));
  AND3x1_ASAP7_75t_R   g141(.A(new_n149_), .B(G10), .C(G39), .Y(new_n228_));
  OR3x1_ASAP7_75t_R    g142(.A(new_n227_), .B(new_n223_), .C(new_n228_), .Y(new_n229_));
  NOR2x1_ASAP7_75t_R   g143(.A(G44), .B(new_n229_), .Y(new_n230_));
  AO22x1_ASAP7_75t_R   g144(.A1(new_n158_), .A2(G26), .B1(G4), .B2(G34), .Y(new_n231_));
  AND3x1_ASAP7_75t_R   g145(.A(new_n149_), .B(G10), .C(G37), .Y(new_n232_));
  OR3x1_ASAP7_75t_R    g146(.A(new_n231_), .B(new_n223_), .C(new_n232_), .Y(new_n233_));
  NOR2x1_ASAP7_75t_R   g147(.A(G43), .B(new_n233_), .Y(new_n234_));
  AO22x1_ASAP7_75t_R   g148(.A1(new_n158_), .A2(G25), .B1(G9), .B2(G34), .Y(new_n235_));
  AND3x1_ASAP7_75t_R   g149(.A(new_n149_), .B(G10), .C(G36), .Y(new_n236_));
  OR3x1_ASAP7_75t_R    g150(.A(new_n235_), .B(new_n223_), .C(new_n236_), .Y(new_n237_));
  NOR2x1_ASAP7_75t_R   g151(.A(G42), .B(new_n237_), .Y(new_n238_));
  OR4x2_ASAP7_75t_R    g152(.A(new_n226_), .B(new_n230_), .C(new_n234_), .D(new_n238_), .Y(new_n239_));
  AND2x2_ASAP7_75t_R   g153(.A(new_n229_), .B(G44), .Y(new_n240_));
  INVx1_ASAP7_75t_R    g154(.A(new_n240_), .Y(new_n241_));
  OR3x1_ASAP7_75t_R    g155(.A(new_n241_), .B(new_n234_), .C(new_n238_), .Y(new_n242_));
  AND2x2_ASAP7_75t_R   g156(.A(new_n233_), .B(G43), .Y(new_n243_));
  INVx1_ASAP7_75t_R    g157(.A(new_n243_), .Y(new_n244_));
  AND2x2_ASAP7_75t_R   g158(.A(new_n237_), .B(G42), .Y(new_n245_));
  INVx1_ASAP7_75t_R    g159(.A(new_n245_), .Y(new_n246_));
  OA21x2_ASAP7_75t_R   g160(.A1(new_n244_), .A2(new_n238_), .B(new_n246_), .Y(new_n247_));
  AND3x1_ASAP7_75t_R   g161(.A(new_n239_), .B(new_n242_), .C(new_n247_), .Y(new_n248_));
  MAJx2_ASAP7_75t_R    g162(.A(new_n248_), .B(new_n219_), .C(new_n224_), .Y(G876));
  AOI22x1_ASAP7_75t_R  g163(.A1(G44), .A2(new_n139_), .B1(new_n229_), .B2(G54), .Y(new_n250_));
  INVx1_ASAP7_75t_R    g164(.A(new_n230_), .Y(new_n251_));
  NAND2x1_ASAP7_75t_R  g165(.A(new_n241_), .B(new_n251_), .Y(new_n252_));
  OA22x2_ASAP7_75t_R   g166(.A1(new_n175_), .A2(new_n241_), .B1(new_n252_), .B2(new_n174_), .Y(new_n253_));
  XOR2x2_ASAP7_75t_R   g167(.A(new_n226_), .B(new_n252_), .Y(new_n254_));
  AOI22x1_ASAP7_75t_R  g168(.A1(G26), .A2(G50), .B1(new_n254_), .B2(G51), .Y(new_n255_));
  AND3x1_ASAP7_75t_R   g169(.A(new_n255_), .B(new_n250_), .C(new_n253_), .Y(G877));
  OA22x2_ASAP7_75t_R   g170(.A1(new_n219_), .A2(new_n140_), .B1(new_n224_), .B2(new_n141_), .Y(new_n257_));
  XOR2x2_ASAP7_75t_R   g171(.A(new_n224_), .B(new_n219_), .Y(new_n258_));
  NAND2x1_ASAP7_75t_R  g172(.A(G52), .B(new_n258_), .Y(new_n259_));
  OR3x1_ASAP7_75t_R    g173(.A(new_n224_), .B(new_n219_), .C(new_n175_), .Y(new_n260_));
  XNOR2x2_ASAP7_75t_R  g174(.A(new_n258_), .B(new_n248_), .Y(new_n261_));
  AOI22x1_ASAP7_75t_R  g175(.A1(G60), .A2(G50), .B1(new_n261_), .B2(G51), .Y(new_n262_));
  AND4x2_ASAP7_75t_R   g176(.A(new_n262_), .B(new_n257_), .C(new_n259_), .D(new_n260_), .Y(G878));
  AOI22x1_ASAP7_75t_R  g177(.A1(G42), .A2(new_n139_), .B1(new_n237_), .B2(G54), .Y(new_n264_));
  NOR2x1_ASAP7_75t_R   g178(.A(new_n245_), .B(new_n238_), .Y(new_n265_));
  AOI22x1_ASAP7_75t_R  g179(.A1(G53), .A2(new_n245_), .B1(new_n265_), .B2(G52), .Y(new_n266_));
  OR3x1_ASAP7_75t_R    g180(.A(new_n226_), .B(new_n230_), .C(new_n234_), .Y(new_n267_));
  OA21x2_ASAP7_75t_R   g181(.A1(new_n241_), .A2(new_n234_), .B(new_n244_), .Y(new_n268_));
  NAND2x1_ASAP7_75t_R  g182(.A(new_n268_), .B(new_n267_), .Y(new_n269_));
  XOR2x2_ASAP7_75t_R   g183(.A(new_n269_), .B(new_n265_), .Y(new_n270_));
  AOI22x1_ASAP7_75t_R  g184(.A1(G24), .A2(G50), .B1(new_n270_), .B2(G51), .Y(new_n271_));
  AND3x1_ASAP7_75t_R   g185(.A(new_n271_), .B(new_n264_), .C(new_n266_), .Y(G879));
  AOI22x1_ASAP7_75t_R  g186(.A1(G43), .A2(new_n139_), .B1(new_n233_), .B2(G54), .Y(new_n273_));
  NOR2x1_ASAP7_75t_R   g187(.A(new_n243_), .B(new_n234_), .Y(new_n274_));
  AOI22x1_ASAP7_75t_R  g188(.A1(G53), .A2(new_n243_), .B1(new_n274_), .B2(G52), .Y(new_n275_));
  OA21x2_ASAP7_75t_R   g189(.A1(new_n226_), .A2(new_n230_), .B(new_n241_), .Y(new_n276_));
  XNOR2x2_ASAP7_75t_R  g190(.A(new_n274_), .B(new_n276_), .Y(new_n277_));
  AOI22x1_ASAP7_75t_R  g191(.A1(G25), .A2(G50), .B1(new_n277_), .B2(G51), .Y(new_n278_));
  AND3x1_ASAP7_75t_R   g192(.A(new_n278_), .B(new_n273_), .C(new_n275_), .Y(G880));
endmodule


