// Benchmark "/home/flynn/workplace/MIGBalance/tools/mockturtle/experiments/benchmarks/c880" written by ABC on Wed Oct  7 15:32:38 2026

module \/home/flynn/workplace/MIGBalance/tools/mockturtle/experiments/benchmarks/c880  ( 
    G8, G16, G6, G17, G7, G18, G19, G4, G3, G2, G1, G5, G11, G23, G20, G21,
    G9, G10, G12, G15, G22, G32, G24, G25, G26, G27, G28, G29, G30, G31,
    G33, G41, G42, G43, G44, G45, G46, G47, G48, G49, G13, G14, G55, G59,
    G54, G60, G39, G40, G52, G53, G50, G51, G58, G35, G37, G36, G56, G57,
    G34, G38,
    G855, G856, G857, G858, G859, G860, G861, G862, G863, G864, G865, G866,
    G867, G868, G869, G870, G871, G872, G873, G874, G875, G876, G877, G878,
    G879, G880  );
  input  G8, G16, G6, G17, G7, G18, G19, G4, G3, G2, G1, G5, G11, G23,
    G20, G21, G9, G10, G12, G15, G22, G32, G24, G25, G26, G27, G28, G29,
    G30, G31, G33, G41, G42, G43, G44, G45, G46, G47, G48, G49, G13, G14,
    G55, G59, G54, G60, G39, G40, G52, G53, G50, G51, G58, G35, G37, G36,
    G56, G57, G34, G38;
  output G855, G856, G857, G858, G859, G860, G861, G862, G863, G864, G865,
    G866, G867, G868, G869, G870, G871, G872, G873, G874, G875, G876, G877,
    G878, G879, G880;
  wire new_n87_, new_n88_, new_n89_, new_n90_, new_n91_, new_n92_, new_n93_,
    new_n94_, new_n95_, new_n96_, new_n97_, new_n98_, new_n100_, new_n104_,
    new_n106_, new_n108_, new_n114_, new_n116_, new_n117_, new_n119_,
    new_n122_, new_n123_, new_n124_, new_n125_, new_n126_, new_n127_,
    new_n128_, new_n129_, new_n131_, new_n132_, new_n133_, new_n134_,
    new_n135_, new_n136_, new_n137_, new_n138_, new_n140_, new_n141_,
    new_n142_, new_n143_, new_n144_, new_n145_, new_n146_, new_n147_,
    new_n148_, new_n149_, new_n150_, new_n151_, new_n152_, new_n153_,
    new_n154_, new_n155_, new_n156_, new_n157_, new_n158_, new_n159_,
    new_n160_, new_n161_, new_n162_, new_n163_, new_n164_, new_n165_,
    new_n166_, new_n167_, new_n168_, new_n169_, new_n170_, new_n172_,
    new_n173_, new_n174_, new_n175_, new_n176_, new_n177_, new_n178_,
    new_n179_, new_n180_, new_n181_, new_n182_, new_n183_, new_n184_,
    new_n185_, new_n186_, new_n187_, new_n188_, new_n189_, new_n190_,
    new_n191_, new_n192_, new_n193_, new_n194_, new_n195_, new_n196_,
    new_n198_, new_n199_, new_n200_, new_n201_, new_n202_, new_n203_,
    new_n204_, new_n205_, new_n206_, new_n208_, new_n209_, new_n210_,
    new_n211_, new_n212_, new_n213_, new_n214_, new_n215_, new_n216_,
    new_n218_, new_n219_, new_n220_, new_n221_, new_n222_, new_n223_,
    new_n224_, new_n225_, new_n226_, new_n227_, new_n228_, new_n229_,
    new_n230_, new_n231_, new_n232_, new_n233_, new_n234_, new_n235_,
    new_n236_, new_n237_, new_n238_, new_n239_, new_n240_, new_n241_,
    new_n242_, new_n243_, new_n244_, new_n245_, new_n246_, new_n247_,
    new_n249_, new_n250_, new_n251_, new_n252_, new_n253_, new_n254_,
    new_n255_, new_n256_, new_n258_, new_n259_, new_n260_, new_n261_,
    new_n262_, new_n263_, new_n264_, new_n266_, new_n267_, new_n268_,
    new_n269_, new_n270_, new_n271_, new_n272_, new_n273_, new_n275_,
    new_n276_, new_n277_, new_n278_, new_n279_, new_n280_, new_n281_,
    new_n282_;
  INVx1_ASAP7_75t_R    g000(.A(G8), .Y(new_n87_));
  INVx1_ASAP7_75t_R    g001(.A(G1), .Y(new_n88_));
  INVx1_ASAP7_75t_R    g002(.A(G26), .Y(new_n89_));
  INVx1_ASAP7_75t_R    g003(.A(G31), .Y(new_n90_));
  INVx1_ASAP7_75t_R    g004(.A(G41), .Y(new_n91_));
  INVx1_ASAP7_75t_R    g005(.A(G44), .Y(new_n92_));
  INVx1_ASAP7_75t_R    g006(.A(G48), .Y(new_n93_));
  INVx1_ASAP7_75t_R    g007(.A(G60), .Y(new_n94_));
  INVx1_ASAP7_75t_R    g008(.A(G52), .Y(new_n95_));
  INVx1_ASAP7_75t_R    g009(.A(G51), .Y(new_n96_));
  INVx1_ASAP7_75t_R    g010(.A(G58), .Y(new_n97_));
  AND3x1_ASAP7_75t_R   g011(.A(G8), .B(G16), .C(G6), .Y(new_n98_));
  INVx1_ASAP7_75t_R    g012(.A(new_n98_), .Y(G855));
  AND3x1_ASAP7_75t_R   g013(.A(G6), .B(G17), .C(G7), .Y(new_n100_));
  INVx1_ASAP7_75t_R    g014(.A(new_n100_), .Y(G856));
  NAND3x1_ASAP7_75t_R  g015(.A(G8), .B(G6), .C(G7), .Y(G857));
  NAND2x1_ASAP7_75t_R  g016(.A(G18), .B(G19), .Y(G858));
  AND4x2_ASAP7_75t_R   g017(.A(G4), .B(G3), .C(G2), .D(G1), .Y(new_n104_));
  INVx1_ASAP7_75t_R    g018(.A(new_n104_), .Y(G859));
  AND4x2_ASAP7_75t_R   g019(.A(G4), .B(G3), .C(G1), .D(G5), .Y(new_n106_));
  AND2x2_ASAP7_75t_R   g020(.A(G857), .B(new_n106_), .Y(G860));
  NAND2x1_ASAP7_75t_R  g021(.A(G16), .B(G11), .Y(new_n108_));
  AND3x1_ASAP7_75t_R   g022(.A(G16), .B(G17), .C(G11), .Y(G861));
  AND3x1_ASAP7_75t_R   g023(.A(G17), .B(G7), .C(G11), .Y(G862));
  AND3x1_ASAP7_75t_R   g024(.A(G8), .B(G7), .C(G11), .Y(G863));
  OAI21x1_ASAP7_75t_R  g025(.A1(G20), .A2(G21), .B(G23), .Y(G864));
  AND4x2_ASAP7_75t_R   g026(.A(G8), .B(G6), .C(G7), .D(new_n106_), .Y(G865));
  AND3x1_ASAP7_75t_R   g027(.A(G1), .B(G5), .C(G9), .Y(new_n114_));
  INVx1_ASAP7_75t_R    g028(.A(new_n114_), .Y(G866));
  AND4x2_ASAP7_75t_R   g029(.A(G3), .B(G2), .C(G1), .D(G10), .Y(new_n116_));
  AND3x1_ASAP7_75t_R   g030(.A(G6), .B(G12), .C(new_n116_), .Y(new_n117_));
  INVx1_ASAP7_75t_R    g031(.A(new_n117_), .Y(G867));
  AND3x1_ASAP7_75t_R   g032(.A(G11), .B(G12), .C(new_n116_), .Y(new_n119_));
  NAND2x1_ASAP7_75t_R  g033(.A(G15), .B(new_n119_), .Y(G868));
  OAI21x1_ASAP7_75t_R  g034(.A1(G20), .A2(G21), .B(G22), .Y(G869));
  XOR2x2_ASAP7_75t_R   g035(.A(G24), .B(G25), .Y(new_n122_));
  XOR2x2_ASAP7_75t_R   g036(.A(G32), .B(new_n122_), .Y(new_n123_));
  XNOR2x2_ASAP7_75t_R  g037(.A(G30), .B(G31), .Y(new_n124_));
  XOR2x2_ASAP7_75t_R   g038(.A(new_n123_), .B(new_n124_), .Y(new_n125_));
  XOR2x2_ASAP7_75t_R   g039(.A(G28), .B(G29), .Y(new_n126_));
  XOR2x2_ASAP7_75t_R   g040(.A(G33), .B(new_n126_), .Y(new_n127_));
  XOR2x2_ASAP7_75t_R   g041(.A(G26), .B(G27), .Y(new_n128_));
  XOR2x2_ASAP7_75t_R   g042(.A(new_n127_), .B(new_n128_), .Y(new_n129_));
  XOR2x2_ASAP7_75t_R   g043(.A(new_n125_), .B(new_n129_), .Y(G870));
  XOR2x2_ASAP7_75t_R   g044(.A(G41), .B(G42), .Y(new_n131_));
  XOR2x2_ASAP7_75t_R   g045(.A(G32), .B(new_n131_), .Y(new_n132_));
  XNOR2x2_ASAP7_75t_R  g046(.A(G47), .B(G48), .Y(new_n133_));
  XOR2x2_ASAP7_75t_R   g047(.A(new_n132_), .B(new_n133_), .Y(new_n134_));
  XOR2x2_ASAP7_75t_R   g048(.A(G45), .B(G46), .Y(new_n135_));
  XOR2x2_ASAP7_75t_R   g049(.A(G49), .B(new_n135_), .Y(new_n136_));
  XOR2x2_ASAP7_75t_R   g050(.A(G43), .B(G44), .Y(new_n137_));
  XOR2x2_ASAP7_75t_R   g051(.A(new_n136_), .B(new_n137_), .Y(new_n138_));
  XOR2x2_ASAP7_75t_R   g052(.A(new_n134_), .B(new_n138_), .Y(G871));
  AND2x2_ASAP7_75t_R   g053(.A(G11), .B(G40), .Y(new_n140_));
  NAND2x1_ASAP7_75t_R  g054(.A(G11), .B(G40), .Y(new_n141_));
  AO31x2_ASAP7_75t_R   g055(.A1(G4), .A2(new_n114_), .A3(new_n141_), .B(new_n88_), .Y(new_n142_));
  NAND2x1_ASAP7_75t_R  g056(.A(G39), .B(new_n142_), .Y(new_n143_));
  OR2x4_ASAP7_75t_R    g057(.A(G8), .B(G4), .Y(new_n144_));
  NAND2x1_ASAP7_75t_R  g058(.A(G8), .B(G4), .Y(new_n145_));
  AND3x1_ASAP7_75t_R   g059(.A(new_n144_), .B(new_n145_), .C(new_n140_), .Y(new_n146_));
  AND4x2_ASAP7_75t_R   g060(.A(new_n114_), .B(new_n140_), .C(new_n144_), .D(new_n145_), .Y(new_n147_));
  AND4x2_ASAP7_75t_R   g061(.A(G4), .B(G2), .C(G1), .D(G9), .Y(new_n148_));
  OA21x2_ASAP7_75t_R   g062(.A1(new_n87_), .A2(new_n108_), .B(new_n148_), .Y(new_n149_));
  AOI21x1_ASAP7_75t_R  g063(.A1(new_n114_), .A2(new_n146_), .B(new_n149_), .Y(new_n150_));
  AO21x1_ASAP7_75t_R   g064(.A1(new_n114_), .A2(new_n146_), .B(new_n149_), .Y(new_n151_));
  OAI21x1_ASAP7_75t_R  g065(.A1(new_n147_), .A2(new_n149_), .B(G31), .Y(new_n152_));
  AND3x1_ASAP7_75t_R   g066(.A(G16), .B(G6), .C(G17), .Y(new_n153_));
  AND2x2_ASAP7_75t_R   g067(.A(new_n114_), .B(new_n153_), .Y(new_n154_));
  AND2x2_ASAP7_75t_R   g068(.A(new_n94_), .B(G10), .Y(new_n155_));
  NAND2x1_ASAP7_75t_R  g069(.A(new_n154_), .B(new_n155_), .Y(new_n156_));
  OA21x2_ASAP7_75t_R   g070(.A1(new_n150_), .A2(new_n90_), .B(new_n156_), .Y(new_n157_));
  AND3x1_ASAP7_75t_R   g071(.A(new_n143_), .B(new_n152_), .C(new_n156_), .Y(new_n158_));
  NOR2x1_ASAP7_75t_R   g072(.A(new_n93_), .B(new_n158_), .Y(new_n159_));
  AO31x2_ASAP7_75t_R   g073(.A1(new_n143_), .A2(new_n152_), .A3(new_n156_), .B(new_n93_), .Y(new_n160_));
  AND4x2_ASAP7_75t_R   g074(.A(new_n93_), .B(new_n143_), .C(new_n152_), .D(new_n156_), .Y(new_n161_));
  OR2x4_ASAP7_75t_R    g075(.A(new_n159_), .B(new_n161_), .Y(new_n162_));
  AO31x2_ASAP7_75t_R   g076(.A1(new_n93_), .A2(new_n157_), .A3(new_n143_), .B(new_n97_), .Y(new_n163_));
  OAI21x1_ASAP7_75t_R  g077(.A1(new_n163_), .A2(new_n159_), .B(G51), .Y(new_n164_));
  AO21x1_ASAP7_75t_R   g078(.A1(new_n97_), .A2(new_n162_), .B(new_n164_), .Y(new_n165_));
  AOI21x1_ASAP7_75t_R  g079(.A1(G48), .A2(G53), .B(G54), .Y(new_n166_));
  AND4x2_ASAP7_75t_R   g080(.A(G8), .B(G13), .C(G14), .D(new_n119_), .Y(new_n167_));
  AO22x1_ASAP7_75t_R   g081(.A1(G55), .A2(G59), .B1(G50), .B2(G30), .Y(new_n168_));
  AOI21x1_ASAP7_75t_R  g082(.A1(G48), .A2(new_n167_), .B(new_n168_), .Y(new_n169_));
  OA21x2_ASAP7_75t_R   g083(.A1(new_n158_), .A2(new_n166_), .B(new_n169_), .Y(new_n170_));
  OA211x2_ASAP7_75t_R  g084(.A1(new_n95_), .A2(new_n162_), .B(new_n165_), .C(new_n170_), .Y(G872));
  AO22x1_ASAP7_75t_R   g085(.A1(new_n154_), .A2(new_n155_), .B1(new_n142_), .B2(G35), .Y(new_n172_));
  AO21x1_ASAP7_75t_R   g086(.A1(new_n151_), .A2(G28), .B(new_n172_), .Y(new_n173_));
  NOR2x1_ASAP7_75t_R   g087(.A(G45), .B(new_n173_), .Y(new_n174_));
  OR2x4_ASAP7_75t_R    g088(.A(G45), .B(new_n173_), .Y(new_n175_));
  NAND2x1_ASAP7_75t_R  g089(.A(G45), .B(new_n173_), .Y(new_n176_));
  AND2x2_ASAP7_75t_R   g090(.A(new_n175_), .B(new_n176_), .Y(new_n177_));
  OAI21x1_ASAP7_75t_R  g091(.A1(new_n97_), .A2(new_n161_), .B(new_n160_), .Y(new_n178_));
  OA21x2_ASAP7_75t_R   g092(.A1(new_n147_), .A2(new_n149_), .B(G29), .Y(new_n179_));
  AO22x1_ASAP7_75t_R   g093(.A1(new_n154_), .A2(new_n155_), .B1(new_n142_), .B2(G36), .Y(new_n180_));
  AO21x1_ASAP7_75t_R   g094(.A1(new_n151_), .A2(G29), .B(new_n180_), .Y(new_n181_));
  AO211x2_ASAP7_75t_R  g095(.A1(G29), .A2(new_n151_), .B(new_n180_), .C(G46), .Y(new_n182_));
  AO22x1_ASAP7_75t_R   g096(.A1(new_n154_), .A2(new_n155_), .B1(new_n142_), .B2(G37), .Y(new_n183_));
  AO21x1_ASAP7_75t_R   g097(.A1(new_n151_), .A2(G30), .B(new_n183_), .Y(new_n184_));
  OA21x2_ASAP7_75t_R   g098(.A1(G47), .A2(new_n184_), .B(new_n182_), .Y(new_n185_));
  OAI21x1_ASAP7_75t_R  g099(.A1(G47), .A2(new_n184_), .B(new_n182_), .Y(new_n186_));
  AOI21x1_ASAP7_75t_R  g100(.A1(new_n160_), .A2(new_n163_), .B(new_n186_), .Y(new_n187_));
  OA21x2_ASAP7_75t_R   g101(.A1(new_n179_), .A2(new_n180_), .B(G46), .Y(new_n188_));
  AO31x2_ASAP7_75t_R   g102(.A1(G47), .A2(new_n182_), .A3(new_n184_), .B(new_n188_), .Y(new_n189_));
  AOI21x1_ASAP7_75t_R  g103(.A1(new_n185_), .A2(new_n178_), .B(new_n189_), .Y(new_n190_));
  AO21x1_ASAP7_75t_R   g104(.A1(new_n178_), .A2(new_n185_), .B(new_n189_), .Y(new_n191_));
  AOI21x1_ASAP7_75t_R  g105(.A1(new_n177_), .A2(new_n191_), .B(new_n96_), .Y(new_n192_));
  OA21x2_ASAP7_75t_R   g106(.A1(new_n177_), .A2(new_n191_), .B(new_n192_), .Y(new_n193_));
  AO21x1_ASAP7_75t_R   g107(.A1(G45), .A2(G53), .B(G54), .Y(new_n194_));
  AO22x1_ASAP7_75t_R   g108(.A1(G27), .A2(G50), .B1(new_n167_), .B2(G45), .Y(new_n195_));
  AO21x1_ASAP7_75t_R   g109(.A1(new_n173_), .A2(new_n194_), .B(new_n195_), .Y(new_n196_));
  AOI211x1_ASAP7_75t_R g110(.A1(G52), .A2(new_n177_), .B(new_n193_), .C(new_n196_), .Y(G873));
  XOR2x2_ASAP7_75t_R   g111(.A(G46), .B(new_n181_), .Y(new_n198_));
  MAJx2_ASAP7_75t_R    g112(.A(new_n178_), .B(new_n184_), .C(G47), .Y(new_n199_));
  NOR2x1_ASAP7_75t_R   g113(.A(new_n198_), .B(new_n199_), .Y(new_n200_));
  AO21x1_ASAP7_75t_R   g114(.A1(new_n199_), .A2(new_n198_), .B(new_n96_), .Y(new_n201_));
  AO21x1_ASAP7_75t_R   g115(.A1(G46), .A2(G53), .B(G54), .Y(new_n202_));
  AO22x1_ASAP7_75t_R   g116(.A1(G28), .A2(G50), .B1(G56), .B2(G55), .Y(new_n203_));
  AO21x1_ASAP7_75t_R   g117(.A1(G46), .A2(new_n167_), .B(new_n203_), .Y(new_n204_));
  AO21x1_ASAP7_75t_R   g118(.A1(new_n181_), .A2(new_n202_), .B(new_n204_), .Y(new_n205_));
  AOI21x1_ASAP7_75t_R  g119(.A1(G52), .A2(new_n198_), .B(new_n205_), .Y(new_n206_));
  OA21x2_ASAP7_75t_R   g120(.A1(new_n200_), .A2(new_n201_), .B(new_n206_), .Y(G874));
  XNOR2x2_ASAP7_75t_R  g121(.A(G47), .B(new_n184_), .Y(new_n208_));
  INVx1_ASAP7_75t_R    g122(.A(new_n208_), .Y(new_n209_));
  AO21x1_ASAP7_75t_R   g123(.A1(new_n160_), .A2(new_n163_), .B(new_n208_), .Y(new_n210_));
  OA21x2_ASAP7_75t_R   g124(.A1(new_n209_), .A2(new_n178_), .B(G51), .Y(new_n211_));
  AO21x1_ASAP7_75t_R   g125(.A1(G47), .A2(G53), .B(G54), .Y(new_n212_));
  AO22x1_ASAP7_75t_R   g126(.A1(G29), .A2(G50), .B1(G57), .B2(G55), .Y(new_n213_));
  AO21x1_ASAP7_75t_R   g127(.A1(G47), .A2(new_n167_), .B(new_n213_), .Y(new_n214_));
  AO21x1_ASAP7_75t_R   g128(.A1(new_n184_), .A2(new_n212_), .B(new_n214_), .Y(new_n215_));
  AO21x1_ASAP7_75t_R   g129(.A1(G52), .A2(new_n209_), .B(new_n215_), .Y(new_n216_));
  AOI21x1_ASAP7_75t_R  g130(.A1(new_n211_), .A2(new_n210_), .B(new_n216_), .Y(G875));
  AND3x1_ASAP7_75t_R   g131(.A(G10), .B(new_n114_), .C(new_n141_), .Y(new_n218_));
  AND4x2_ASAP7_75t_R   g132(.A(G4), .B(new_n114_), .C(new_n153_), .D(new_n94_), .Y(new_n219_));
  AO21x1_ASAP7_75t_R   g133(.A1(G2), .A2(G34), .B(new_n219_), .Y(new_n220_));
  AO21x1_ASAP7_75t_R   g134(.A1(G35), .A2(new_n218_), .B(new_n220_), .Y(new_n221_));
  AOI21x1_ASAP7_75t_R  g135(.A1(G24), .A2(new_n151_), .B(new_n221_), .Y(new_n222_));
  INVx1_ASAP7_75t_R    g136(.A(new_n222_), .Y(new_n223_));
  OAI21x1_ASAP7_75t_R  g137(.A1(new_n147_), .A2(new_n149_), .B(G27), .Y(new_n224_));
  AND4x2_ASAP7_75t_R   g138(.A(new_n141_), .B(new_n114_), .C(G39), .D(G10), .Y(new_n225_));
  AOI211x1_ASAP7_75t_R g139(.A1(G34), .A2(G38), .B(new_n219_), .C(new_n225_), .Y(new_n226_));
  NAND2x1_ASAP7_75t_R  g140(.A(new_n224_), .B(new_n226_), .Y(new_n227_));
  AND3x1_ASAP7_75t_R   g141(.A(new_n226_), .B(new_n224_), .C(new_n92_), .Y(new_n228_));
  OR2x4_ASAP7_75t_R    g142(.A(G44), .B(new_n227_), .Y(new_n229_));
  OAI21x1_ASAP7_75t_R  g143(.A1(new_n189_), .A2(new_n187_), .B(new_n175_), .Y(new_n230_));
  OA21x2_ASAP7_75t_R   g144(.A1(new_n174_), .A2(new_n190_), .B(new_n176_), .Y(new_n231_));
  OAI21x1_ASAP7_75t_R  g145(.A1(new_n174_), .A2(new_n190_), .B(new_n176_), .Y(new_n232_));
  AOI21x1_ASAP7_75t_R  g146(.A1(new_n176_), .A2(new_n230_), .B(new_n228_), .Y(new_n233_));
  AND4x2_ASAP7_75t_R   g147(.A(new_n141_), .B(new_n114_), .C(G37), .D(G10), .Y(new_n234_));
  AOI211x1_ASAP7_75t_R g148(.A1(G4), .A2(G34), .B(new_n219_), .C(new_n234_), .Y(new_n235_));
  OAI21x1_ASAP7_75t_R  g149(.A1(new_n89_), .A2(new_n150_), .B(new_n235_), .Y(new_n236_));
  OR2x4_ASAP7_75t_R    g150(.A(G43), .B(new_n236_), .Y(new_n237_));
  AO21x1_ASAP7_75t_R   g151(.A1(G9), .A2(G34), .B(new_n219_), .Y(new_n238_));
  AO21x1_ASAP7_75t_R   g152(.A1(G36), .A2(new_n218_), .B(new_n238_), .Y(new_n239_));
  AO21x1_ASAP7_75t_R   g153(.A1(G25), .A2(new_n151_), .B(new_n239_), .Y(new_n240_));
  OA21x2_ASAP7_75t_R   g154(.A1(G42), .A2(new_n240_), .B(new_n237_), .Y(new_n241_));
  AOI21x1_ASAP7_75t_R  g155(.A1(new_n224_), .A2(new_n226_), .B(new_n92_), .Y(new_n242_));
  INVx1_ASAP7_75t_R    g156(.A(new_n242_), .Y(new_n243_));
  MAJx2_ASAP7_75t_R    g157(.A(G43), .B(new_n236_), .C(new_n242_), .Y(new_n244_));
  MAJx2_ASAP7_75t_R    g158(.A(G42), .B(new_n240_), .C(new_n244_), .Y(new_n245_));
  AO31x2_ASAP7_75t_R   g159(.A1(new_n229_), .A2(new_n232_), .A3(new_n241_), .B(new_n245_), .Y(new_n246_));
  OAI21x1_ASAP7_75t_R  g160(.A1(G41), .A2(new_n223_), .B(new_n246_), .Y(new_n247_));
  OA21x2_ASAP7_75t_R   g161(.A1(new_n91_), .A2(new_n222_), .B(new_n247_), .Y(G876));
  NAND2x1_ASAP7_75t_R  g162(.A(new_n229_), .B(new_n243_), .Y(new_n249_));
  INVx1_ASAP7_75t_R    g163(.A(new_n249_), .Y(new_n250_));
  AO21x1_ASAP7_75t_R   g164(.A1(new_n229_), .A2(new_n243_), .B(new_n232_), .Y(new_n251_));
  OA21x2_ASAP7_75t_R   g165(.A1(new_n231_), .A2(new_n249_), .B(G51), .Y(new_n252_));
  AO21x1_ASAP7_75t_R   g166(.A1(G44), .A2(G53), .B(G54), .Y(new_n253_));
  AO22x1_ASAP7_75t_R   g167(.A1(G26), .A2(G50), .B1(new_n167_), .B2(G44), .Y(new_n254_));
  AO21x1_ASAP7_75t_R   g168(.A1(new_n227_), .A2(new_n253_), .B(new_n254_), .Y(new_n255_));
  AO21x1_ASAP7_75t_R   g169(.A1(G52), .A2(new_n250_), .B(new_n255_), .Y(new_n256_));
  AOI21x1_ASAP7_75t_R  g170(.A1(new_n251_), .A2(new_n252_), .B(new_n256_), .Y(G877));
  XOR2x2_ASAP7_75t_R   g171(.A(new_n91_), .B(new_n222_), .Y(new_n258_));
  AO211x2_ASAP7_75t_R  g172(.A1(new_n233_), .A2(new_n241_), .B(new_n245_), .C(new_n258_), .Y(new_n259_));
  AOI21x1_ASAP7_75t_R  g173(.A1(new_n258_), .A2(new_n246_), .B(new_n96_), .Y(new_n260_));
  AO21x1_ASAP7_75t_R   g174(.A1(G41), .A2(G53), .B(G54), .Y(new_n261_));
  AO22x1_ASAP7_75t_R   g175(.A1(G60), .A2(G50), .B1(new_n167_), .B2(G41), .Y(new_n262_));
  AO21x1_ASAP7_75t_R   g176(.A1(new_n223_), .A2(new_n261_), .B(new_n262_), .Y(new_n263_));
  AO21x1_ASAP7_75t_R   g177(.A1(G52), .A2(new_n258_), .B(new_n263_), .Y(new_n264_));
  AOI21x1_ASAP7_75t_R  g178(.A1(new_n259_), .A2(new_n260_), .B(new_n264_), .Y(G878));
  XOR2x2_ASAP7_75t_R   g179(.A(G42), .B(new_n240_), .Y(new_n266_));
  AO31x2_ASAP7_75t_R   g180(.A1(new_n229_), .A2(new_n232_), .A3(new_n237_), .B(new_n244_), .Y(new_n267_));
  AO211x2_ASAP7_75t_R  g181(.A1(new_n237_), .A2(new_n233_), .B(new_n266_), .C(new_n244_), .Y(new_n268_));
  AOI21x1_ASAP7_75t_R  g182(.A1(new_n266_), .A2(new_n267_), .B(new_n96_), .Y(new_n269_));
  AO21x1_ASAP7_75t_R   g183(.A1(G42), .A2(G53), .B(G54), .Y(new_n270_));
  AO22x1_ASAP7_75t_R   g184(.A1(G24), .A2(G50), .B1(new_n167_), .B2(G42), .Y(new_n271_));
  AO21x1_ASAP7_75t_R   g185(.A1(new_n240_), .A2(new_n270_), .B(new_n271_), .Y(new_n272_));
  AO21x1_ASAP7_75t_R   g186(.A1(G52), .A2(new_n266_), .B(new_n272_), .Y(new_n273_));
  AOI21x1_ASAP7_75t_R  g187(.A1(new_n268_), .A2(new_n269_), .B(new_n273_), .Y(G879));
  XNOR2x2_ASAP7_75t_R  g188(.A(G43), .B(new_n236_), .Y(new_n275_));
  INVx1_ASAP7_75t_R    g189(.A(new_n275_), .Y(new_n276_));
  OA211x2_ASAP7_75t_R  g190(.A1(new_n228_), .A2(new_n231_), .B(new_n243_), .C(new_n275_), .Y(new_n277_));
  OA21x2_ASAP7_75t_R   g191(.A1(new_n233_), .A2(new_n242_), .B(new_n276_), .Y(new_n278_));
  AO21x1_ASAP7_75t_R   g192(.A1(G43), .A2(G53), .B(G54), .Y(new_n279_));
  AO22x1_ASAP7_75t_R   g193(.A1(G25), .A2(G50), .B1(new_n167_), .B2(G43), .Y(new_n280_));
  AO21x1_ASAP7_75t_R   g194(.A1(new_n236_), .A2(new_n279_), .B(new_n280_), .Y(new_n281_));
  AOI21x1_ASAP7_75t_R  g195(.A1(G52), .A2(new_n276_), .B(new_n281_), .Y(new_n282_));
  OA31x2_ASAP7_75t_R   g196(.A1(new_n277_), .A2(new_n278_), .A3(new_n96_), .B1(new_n282_), .Y(G880));
endmodule


