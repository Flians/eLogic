from pathlib import Path
b=Path(__file__).resolve().parent
red=(b/'red.log').read_text();assert 'enabled TT3 replacement must not construct' in red and 'left: 1' in red and 'right: 0' in red and 'test result: FAILED' in red
p=b/'source/emapper/src/egraph_map.rs';s=p.read_text();old='fn tt3_replacement_support(rest:&[usize],child:&[usize],limit:usize,_fast:bool)->Option<Vec<usize>>{\n';new='fn tt3_replacement_support(rest:&[usize],child:&[usize],limit:usize,fast:bool)->Option<Vec<usize>>{\n if fast{return merge_cut_support(rest,child,limit,true);}\n';assert s.count(old)==1;s=s.replace(old,new)
s+='''
#[cfg(test)]mod tt3_support_oracle_tests{use super::*;
 #[test]fn all_small_support_sets_limits_and_unordered_fallback_match_reference(){
  for a in 0..128usize{for b in 0..128usize{let x:Vec<_>=(0..7).filter(|i|a&(1<<i)!=0).map(|i|i*3+2).collect();let y:Vec<_>=(0..7).filter(|i|b&(1<<i)!=0).map(|i|i*3+2).collect();for k in 0..=6{assert_eq!(tt3_replacement_support(&x,&y,k,true),tt3_replacement_support(&x,&y,k,false));}}}
  for x in [vec![4,2],vec![2,2],vec![],vec![9,1,5]]{for y in [vec![3,3],vec![4,2],vec![]]{for k in 0..=6{assert_eq!(tt3_replacement_support(&x,&y,k,true),tt3_replacement_support(&x,&y,k,false));}}}
 }
}
'''
a=s.index('#[cfg(test)] mod word_quotient_whole_pool_tests {');z=s.index('\n}',a)+2
# This existing module has indented inner closing braces and one unindented module brace.
pool=s[a:z].replace('word_quotient_whole_pool_tests','tt3_support_whole_pool_tests').replace('with_quotient','with_tt3').replace('TEST_QUOTIENT_OVERRIDE','TEST_TT3_SUPPORT_OVERRIDE').replace('word_quotient_preserves_exact_cut_pool_and_binding_proof_sequences','tt3_support_preserves_exact_cut_pool_and_binding_proof_sequences')
oldgraph='all.push(g.add(AigLang::And([a,b])));if i%3==0'
newgraph='if i%2==0{let c=all[(i*5+seed+2)%all.len()];all.push(g.add(AigLang::Cell("@egm_tt3_f8".into(),vec![a,b,c])));}else{all.push(g.add(AigLang::And([a,b])));}if i%3==0'
assert pool.count(oldgraph)==1;pool=pool.replace(oldgraph,newgraph)
pool=pool.replace('for seed in 0..24usize {','let mut observed_reference_sets=0;for seed in 0..24usize {',1)
pool=pool.replace('let cuts=with_tt3(false,','TEST_TT3_REFERENCE_SETS.with(|v|v.set(0));let cuts=with_tt3(false,',1)
pool=pool.replace('let mut word_stats=MapStats::default();','observed_reference_sets+=TEST_TT3_REFERENCE_SETS.with(|v|v.get());TEST_TT3_REFERENCE_SETS.with(|v|v.set(0));let mut word_stats=MapStats::default();',1)
pool=pool.replace('assert_eq!(cuts,word_cuts,"cut banks seed={seed}");','assert_eq!(TEST_TT3_REFERENCE_SETS.with(|v|v.get()),0,"production TT3 path must use the fast helper");assert_eq!(cuts,word_cuts,"cut banks seed={seed}");assert_eq!(stats.functional_cut_trials,word_stats.functional_cut_trials);assert_eq!(stats.functional_cut_proofs,word_stats.functional_cut_proofs);',1)
assert pool.endswith('  }\n }\n}')
pool=pool[:-len('  }\n }\n}')]+'''  }
  assert!(observed_reference_sets>0,"fixture must exercise the actual TT3 substitution loop");
 }
}'''
s+='\n'+pool+'\n';p.write_text(s)
