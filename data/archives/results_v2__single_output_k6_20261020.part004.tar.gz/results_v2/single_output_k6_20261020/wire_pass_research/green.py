from pathlib import Path
b=Path(__file__).resolve().parent
red=(b/'red.log').read_text();assert 'left: 2' in red and 'right: 0' in red and 'test result: FAILED' in red
p=b/'source/emapper/src/egraph_map.rs';s=p.read_text();old='fn normalize_generated_pool(instances:Vec<Instance>,canonical:&[usize],free:&[bool],ps:&MapParams,_streamed:bool,_skip:bool)->Vec<Instance>{';new='''// Only a streamed generator result carries the uniqueness contract. Its
// canonicalization is reusable when aliases are idempotent and every actual
// row and binding source is already in canonical normal form. Otherwise use
// the original complete pass. No candidate or proof is sampled or discarded.
fn streamed_pool_is_canonical(instances:&[Instance],canonical:&[usize],free:&[bool])->bool{
 if canonical.len()!=free.len() || !canonical.iter().all(|&a|canonical.get(a)==Some(&a)){return false;}
 instances.iter().all(|m|m.inputs.iter().all(|&i|canonical.get(i)==Some(&i)) && m.outputs.iter().any(|o|!o.targets.is_empty()) && m.outputs.iter().all(|o|
  o.targets.windows(2).all(|v|v[0]<v[1]) && o.targets.iter().all(|&t|canonical.get(t)==Some(&t)&&!free[t]&&!m.inputs.contains(&t)) &&
  o.sources.iter().all(|source|canonical.get(source.target)==Some(&source.target)&&o.targets.binary_search(&source.target).is_ok())
 ))
}
fn normalize_generated_pool(instances:Vec<Instance>,canonical:&[usize],free:&[bool],ps:&MapParams,streamed:bool,skip:bool)->Vec<Instance>{
 let reused=skip&&streamed&&streamed_pool_is_canonical(&instances,canonical,free);
 if let Some(path)=std::env::var_os("EGM_POOL_DIAG_PATH"){let _=std::fs::write(std::path::Path::new(&path).with_extension("wire-pass.json"),serde_json::json!({"skip_requested":skip,"streamed_generation":streamed,"normal_form_verified":reused,"reused_streamed_pool":reused,"input_instances":instances.len(),"candidates_dropped":0,"instance_order_unchanged_if_reused":true,"candidate_or_node_budget_changed":false}).to_string());}
 if reused{return instances;}
''';assert s.count(old)==1;s=s.replace(old,new)
# Capture the actual generation mode once; no second environment read is used
# to assert a capability that the generator may not have provided.
old='let mut instances = generate(&cuts, interface_free, interface_constants, tech, ps, &mut reach, &mut stats,physical_aliases,None);';new='let streamed_matches=std::env::var("EGM_STREAM_MATCHES").as_deref()==Ok("1");\n    let mut instances = generate_mode(&cuts, interface_free, interface_constants, tech, ps, &mut reach, &mut stats,physical_aliases,None,streamed_matches);';assert s.count(old)==1;s=s.replace(old,new)
old='normalize_generated_pool(instances,&canonical,&free,ps,std::env::var("EGM_STREAM_MATCHES").as_deref()==Ok("1"),std::env::var';new='normalize_generated_pool(instances,&canonical,&free,ps,streamed_matches,std::env::var';assert s.count(old)==1;s=s.replace(old,new)
s+='''
#[cfg(test)]mod wire_pass_oracle_tests{use super::*;
 fn row(input:usize,targets:Vec<usize>)->Instance{Instance{cell:"BUF".into(),area:1.,inputs:vec![input],input_pins:vec!["A".into()],outputs:vec![OutputPin{name:"Y".into(),function:2,delays:vec![1.],targets,sources:vec![]}]}}
 #[test]fn nonstreamed_noncanonical_and_nonidempotent_inputs_fall_back_to_exact_old_pass(){
  for (m,aliases,free,stream) in [
   (vec![row(0,vec![1])],vec![0,1],vec![true,false],false),
   (vec![row(1,vec![2])],vec![0,0,2],vec![true,false,false],true),
   (vec![row(2,vec![3])],vec![0,0,1,3],vec![true,false,false,false],true),
   (vec![row(0,vec![3,2,3])],vec![0,1,2,3],vec![true,false,false,false],true),
  ]{let ps=MapParams::default();let expected=normalize_generated_pool(m.clone(),&aliases,&free,&ps,stream,false);TEST_WIRE_PASS_ROWS.with(|v|v.set(0));let got=normalize_generated_pool(m,&aliases,&free,&ps,stream,true);assert!(TEST_WIRE_PASS_ROWS.with(|v|v.get())>0);assert_eq!(format!("{expected:?}"),format!("{got:?}"));}
 }
 #[test]fn actual_streamed_pool_preserves_every_physical_binding_and_proof_sequence(){
  let lib=TechLib::from_genlib(std::path::Path::new(env!("CARGO_MANIFEST_DIR")).join("tests/fixtures/asap7_single_output_6.genlib"),6).unwrap();
  for seed in 0..24usize {
   let mut g=egg::EGraph::<AigLang,()>::default();let mut all=vec![g.add(AigLang::Zero),g.add(AigLang::One)];for p in 0..4{all.push(g.add(AigLang::Pi(p)));}
   for i in 0..9 {let a=all[(i+seed)%all.len()];let b=all[(i*3+seed+1)%all.len()];if i%3==1{let c=all[(i*5+seed+2)%all.len()];all.push(g.add(AigLang::Cell(format!("@egm_tt3_{:02x}",[0x80,0xfe,0x96,0xe8][seed%4]).into(),vec![a,b,c])));}else{all.push(g.add(AigLang::And([a,b])));}if i%3==0{all.push(g.add(AigLang::Not(a)));}}
   g.rebuild();let mut classes:Vec<_>=g.classes().map(|c|c.id).collect();classes.sort_by_key(|&id|usize::from(id));let ids:HashMap<_,_>=classes.iter().enumerate().map(|(i,&id)|(id,i)).collect();let nodes:Vec<_>=classes.iter().map(|&id|g[id].nodes.clone()).collect();
   let ps=MapParams{max_inputs:3+seed%2,cuts_per_class:8,cut_rounds:4,protected_exchange:true,dc_support:if seed%2==0{0}else{4},max_instances:10000,multioutput:false,..Default::default()};let mut stats=MapStats::default();let cuts=enumerate_with_source_mode(&nodes,&ids,&g,&lib,&ps,&mut stats,&[],true);let mut free=vec![false;nodes.len()*2];let mut constants=vec![None;free.len()];
   for (c,ns)in nodes.iter().enumerate(){for n in ns {match n {AigLang::Pi(_)=>free[c*2]=true,AigLang::Zero|AigLang::One=>{let b=matches!(n,AigLang::One);for p in 0..2 {free[c*2+p]=true;constants[c*2+p]=Some(b^(p==1));}},_=>{}}}}
   let aliases=phase_aliases(&nodes,|id|ids[&g.find(id)]).unwrap();let mut cf=vec![false;free.len()];for i in 0..free.len(){cf[aliases[i]]|=free[i];}let witnesses=cheapest_nodes_queued(&g);let reps:Vec<_>=classes.iter().map(|id|witnesses[id].clone().map_children(|child|g.find(child))).collect();
   let mut reach=Reachability{nodes:reps,ids,cache:HashMap::new()};let mut st=MapStats::default();let generated=generate_mode(&cuts,&free,&constants,&lib,&ps,&mut reach,&mut st,Some((&aliases,&cf)),None,true);assert!(streamed_pool_is_canonical(&generated,&aliases,&cf),"seed={seed}");
   let expected=normalize_generated_pool(generated.clone(),&aliases,&cf,&ps,true,false);TEST_WIRE_PASS_ROWS.with(|v|v.set(0));let actual=normalize_generated_pool(generated,&aliases,&cf,&ps,true,true);assert_eq!(TEST_WIRE_PASS_ROWS.with(|v|v.get()),0);assert_eq!(format!("{expected:?}"),format!("{actual:?}"),"seed={seed}");
  }
 }
}
''';p.write_text(s)
