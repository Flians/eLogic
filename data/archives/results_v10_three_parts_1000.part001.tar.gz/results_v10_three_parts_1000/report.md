# Three-part constrained-area experiments

Every ePMapping output satisfies its own initial area/delay bounds and passes CEC.
ABC raw area-mode outputs are preserved. The guarded comparison reverts an infeasible completed output to its native initial mapping; it is an external output-selection policy, not an internal mfs3 timing constraint. Timeouts are excluded from paired means.

{
  "whole_window_synthesis": false,
  "engine_cec_outputs": 103,
  "baseline_cec_outputs": 16,
  "main_own_area": -0.8542674651363171,
  "main_own_delay": -1.7954486996706882,
  "main_one_area": -0.6914090499220905,
  "main_one_delay": -1.783234291954791,
  "main_area_wins": 15,
  "reference_area": 1.045230864556221,
  "reference_delay": 1.7803176135717353,
  "reference_wins": 13,
  "mfs_ours_area": -2.7165293571750273,
  "mfs_ours_delay": -2.3471363021629466,
  "abc_completed": 13,
  "abc_timeouts": 3,
  "abc_feasible": 6,
  "abc_delay_violations": 7,
  "cut_oracle_times": {
    "secs_stage1": 110.576156875,
    "secs_stage2": 45.779554238,
    "secs_synth": 364.56393280099996,
    "secs_egg": 726.46361754,
    "secs_care": 24.54510446,
    "secs_window": 0.0
  },
  "abc_raw_area": -3.575691302200082,
  "abc_guarded_area": -1.5940348664441888,
  "paired_ours_area": -2.1472092762553077,
  "abc_raw_delay": 11.018744353868293,
  "abc_guarded_delay": -0.14558063949823968,
  "paired_ours_delay": -2.8024236639474656,
  "paired_area_wins": 3,
  "guarded_paired_area_wins": 8,
  "ablation": {
    "full": {
      "area": 0.0,
      "worse": 0,
      "better": 0,
      "own_area": -0.4703720506163209,
      "own_delay": -1.3339371213640645,
      "optimizer_seconds": 1328.9454131900002,
      "time_ratio": 1.0
    },
    "noSYN": {
      "area": 29.819999999999993,
      "worse": 8,
      "better": 0,
      "own_area": -0.18437964840731588,
      "own_delay": -0.6487806150017327,
      "optimizer_seconds": 815.4145589499999,
      "time_ratio": 0.6135801748189785
    },
    "noEGG": {
      "area": 1.1400000000000965,
      "worse": 7,
      "better": 0,
      "own_area": -0.45072433074748325,
      "own_delay": -1.3032604360180773,
      "optimizer_seconds": 598.097298765,
      "time_ratio": 0.45005407507997447
    },
    "noDB": {
      "area": 0.09000000000002473,
      "worse": 3,
      "better": 2,
      "own_area": -0.46411654532622787,
      "own_delay": -1.2079940228688937,
      "optimizer_seconds": 1096.41875356,
      "time_ratio": 0.8250291868107333
    },
    "noCARE": {
      "area": 4.830000000000091,
      "worse": 8,
      "better": 0,
      "own_area": -0.42757204389376774,
      "own_delay": -1.0756205303375077,
      "optimizer_seconds": 1222.56524255,
      "time_ratio": 0.9199514369934539
    }
  }
}

## Per-design fully preprocessed results

| Design | A0 | D0 | A | D | dA % | dD % |
| --- | --- | --- | --- | --- | --- | --- |
| aes_core | 1029.98 | 410.72 | 1010.38 | 410.72 | -1.90 | +0.00 |
| arbiter | 557.72 | 999.87 | 557.72 | 999.87 | +0.00 | +0.00 |
| div | 1184.5 | 53105.06 | 1183.25 | 53041.21 | -0.11 | -0.12 |
| ethernet | 2541.41 | 543.88 | 2539.28 | 540.76 | -0.08 | -0.57 |
| iwls05_i2c | 47.66 | 303.61 | 47.45 | 303.61 | -0.44 | +0.00 |
| mem_ctrl | 1895.4 | 1519.75 | 1879.31 | 1486.98 | -0.85 | -2.16 |
| RISC | 2927.19 | 1453.77 | 2917.74 | 1428.82 | -0.32 | -1.72 |
| sasc | 27.28 | 191.2 | 27.17 | 191.2 | -0.40 | +0.00 |
| simple_spi | 36.96 | 308.22 | 36.79 | 291.82 | -0.46 | -5.32 |
| spi | 149.43 | 500.98 | 149.3 | 480.72 | -0.09 | -4.04 |
| sqrt | 1157.38 | 88015.07 | 1094.87 | 81535.14 | -5.40 | -7.36 |
| systemcaes | 483.75 | 709.03 | 474.07 | 682.83 | -2.00 | -3.70 |
| systemcdes | 131.06 | 488.85 | 130.64 | 487.83 | -0.32 | -0.21 |
| tv80 | 340.61 | 846.12 | 338.85 | 846.12 | -0.52 | +0.00 |
| usb_funct | 646.23 | 668.08 | 641.8 | 663.36 | -0.69 | -0.71 |
| usb_phy | 22.54 | 163.29 | 22.52 | 158.68 | -0.09 | -2.82 |
