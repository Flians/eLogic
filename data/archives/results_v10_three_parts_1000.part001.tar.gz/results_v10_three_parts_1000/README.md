# Three-part constrained-area campaign

This archive reruns all three experimental parts from frozen inputs. The ePMapping runs are fresh. ABC measurements come from the immediately preceding, freshly rerun batch in results_v9_three_parts, whose 1000-second cap already matches the final request. Every copied ABC record includes hash provenance and proof of identical mapped input, binary, library gate/pin records and benchmark. Generated genlib source-path comments differ and are excluded from semantic library equality.

1. **Common mapped inputs:** 16 direct-mapped baselines, 16 one-round ePMapping runs and 16 ABC `mfs3 -a` runs on the same 40-cell ASAP7 subset. Both optimizers have a 1000-second optimization cap. ABC CEC is measured separately. The native ePMapping post-mapping timer covers optimizer preparation, all rounds and the final rebuild. Preprocessing, input mapping and CEC do not consume that 1000-second budget. ABC's raw area mode may increase delay; report raw outputs and a separate whole-output selection policy that returns the initial mapping when area or delay exceeds the native initial metric. This policy is not an internal timing-constrained variant of mfs3. Paired means exclude timeouts and use identical design subsets.
2. **Fully preprocessed inputs:** 16 one-round and 16 six-round-cap runs. Preprocessing repeats `fraig; resyn2rs; fraig; compress2rs`, keeping an iteration only when AND count falls, with a 20-iteration safety cap. Area-oriented mapping on the full ASAP7 genlib produces the initial netlist. This is a script-specific fixed point, not a global optimum. Own-input changes isolate post-mapping benefit; published ASPDAC'25 final numbers are an additional comparison with different starts.
3. **Ablation:** 11 designs × full/noSYN/noEGG/noDB/noCARE, all six-round-cap and identical fully preprocessed initial netlists. L1 remains the shared library fallback. Its measured runtime is reported, but no marginal-area attribution is claimed for it. Database removal is global, including internal cut mapping. Care removal supplies full masks and must record zero DC cuts. Marginal effects can be signed and are not additive.

All 103 optimization outputs use `area_delay_bound` / `AREA_UNDER_DELAY=1`: minimize area under the fixed initial worst-output delay, with physical-pin required times, net-area ranking and a rebuilt-round objective guard. Whole-window synthesis and unmap/remap DSE are off everywhere. Numerical timing tolerance is 0.001 ps. Six-round runs stop early on no progress; this is not a proof of convergence. All post-mapping runs, including main and ablation, have a 1000-second optimizer deadline. A separate 3600-second outer guard covers the entire process including setup and CEC; its remaining budget is restored after the optimizer timer ends. Batches have at most 8 engine workers, each using one Rust worker, on a shared host; timings are observational.

Frozen executables, source, benchmarks, genlibs and database are in `inputs/`, with SHA256 provenance and the complete declared plan in `manifest.json`. Each engine run saves `log`, `experiment_env.txt`, `row.tsv`, an initial netlist and a final netlist. ABC saves native baseline statistics, raw optimization and CEC logs, result metadata and completed mapped outputs. Completed rows are resumable only under the same plan; failures require investigation, not silent inclusion.

Reproduce from the repository root:

```bash
python3 scripts/experiments/run_three_parts.py \
  --root results_v10_three_parts_1000 --jobs 8 --timeout 3600 --abc-timeout 1000 \
  --abc-source results_v9_three_parts
python3 scripts/experiments/report_three_parts.py --root results_v10_three_parts_1000 \
  --out epmapping_paper/DATE27-ePMapping-sub/doc/generated_results.tex
python3 scripts/experiments/plot_paper.py --root results_v10_three_parts_1000 \
  --out epmapping_paper/DATE27-ePMapping-sub/figs/results
make -C epmapping_paper/DATE27-ePMapping-sub all
```

The exporter requires all three parts, validates mode banners and hard bounds, checks raw CEC and metric consistency, verifies same initial netlist bytes across paired runs and ablations, and rejects a falsely disabled operator. The paper's Makefile uses this campaign exclusively; older archives remain available for historical analysis.

## Verified results

All 103 optimized outputs and 16 independently checked initial mappings pass CEC. Every optimized output respects its own initial area and delay bounds; whole-window activity is zero. All ePMapping optimizer times are below the declared 1000-second cap. ABC completes 13 designs and times out on div/mem_ctrl/sqrt.

| Input / round cap | Mean area change | Mean delay change |
| --- | ---: | ---: |
| Direct, one round | -2.72% | -2.35% |
| Fully preprocessed, one round | -0.69% | -1.78% |
| Fully preprocessed, six-round cap | -0.85% | -1.80% |

Relative to the published ASPDAC final outputs, 13/16 areas are smaller, but all-design mean area and delay are +1.05%/+1.78%. This is an end-to-end comparison with different mapped starts, not isolated optimizer superiority.

Ablation cumulative area penalties from removing synthesis/e-graph/database/care are +29.82/+1.14/+0.09/+4.83 square micrometers. Their total optimizer-time ratios to full are 0.61/0.45/0.83/0.92. Signed per-design effects remain in the report and figures.

`report.md` and `verified_metrics.json` contain the admitted results; `figures/` contains four vector figures and their numeric sidecar. `paper_snapshot/` preserves the final 6+1-page manuscript, sources and figure hashes against these verified metrics.
