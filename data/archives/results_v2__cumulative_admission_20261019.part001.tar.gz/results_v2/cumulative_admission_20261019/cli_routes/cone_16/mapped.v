module mapped(\a[0] , \b[0] , \c[0] , \unused[0] , \y[0] );
  input \a[0] ;
  input \b[0] ;
  input \c[0] ;
  input \unused[0] ;
  output \y[0] ;
  wire __egm_s24;
  OAI21x1_ASAP7_75t_R __egm_g3 (.A1(\c[0] ), .A2(\b[0] ), .B(\a[0] ), .Y(__egm_s24));
  assign \y[0]  = __egm_s24;
endmodule
