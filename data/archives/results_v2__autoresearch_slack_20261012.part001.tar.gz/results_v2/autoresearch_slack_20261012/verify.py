import subprocess,json,sys,uuid
from pathlib import Path
root=Path(__file__).resolve().parent
folder=root/"measurements"/uuid.uuid4().hex
subprocess.run(["cargo","build","--release","--bin","bench_rs_egraph_map"],cwd=root,check=True,stdout=sys.stderr,stderr=sys.stderr)
subprocess.run(["python3","scripts/experiments/bench_egraph_baselines.py","--output",str(folder),"--objective","delay-area","--prepared-report","/home/flynn/workplace/MIGBalance/results_v2/fixed_all_area_20261012/report.json","--methods","egraph_library_timing","--benches","c432","c1908"],cwd=root,check=True,stdout=sys.stderr,stderr=sys.stderr)
d=json.loads((folder/"report.json").read_text())
assert len(d["results"])==2
reference={"c432":13.640000104904175,"c1908":37.99000019580126}
limits={"c432":365.5499973297119,"c1908":276.11000061035156}
ratios=[]
for r in d["results"]:
 assert r["status"]=="ok" and r["measured"]["cec"]==1
 assert r["settings"]["EGM_CUTS"]=="16" and r["settings"]["EGM_REFINE_TIME"]=="2"
 assert d["library_sha256"]=="097ebff0594902058ef11449637222e60df297f519f9071980fb2dcb46378ec0"
 assert r["measured"]["delay"] <= limits[r["bench"]] + 1e-6
 assert r["native"]["instances"] <= 100000
 ratios.append(r["measured"]["area"]/reference[r["bench"]])
(root/"measurements"/"latest.json").write_text(json.dumps({"report":str(folder/"report.json"),"metric":max(ratios)}))
print(max(ratios))
