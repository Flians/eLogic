# Delay cause analysis — 2026-10-15

Read-only analysis: 120 main/regional/ABC/emap netlists plus twenty recorded author-selected E-morphic SA netlists. All reconstructed instance areas and unloaded dependent-pin delays agree with the existing public evaluator. All observations already passed named-port CEC. No mapping run, baseline modification, new winner selection or production promotion.

The 120 core observations cover all thirty legacy-import-eligible design/inventory pairs, not the five unresolved large designs. Twenty additional SA observations are the existing original native winners; failed/missing baseline cases are not replaced. Independent reconstruction checks common original-input, prepared-input and inventory hashes. Raw records, paths, report hashes and stage counters are saved alongside this report.

## What the data establish

1. In all thirty production observations, final delay equals seed delay. Post-seed acceptance occurs, but does not reduce the measured delay in these observations. Both sqrt observations have zero local refinement trials. These counters do not separate finite-witness/setup, each seed, proposal collection and sorting costs, so it would be premature to blame only the flow worklist.

2. The isolated fixed-bound area stage preserves regional delay on all thirty eligible pairs. Its area benefit cannot repair a slow reference cover. It protects its own initial cover rather than the production seed.

3. The regional source clears nontrivial cut banks every 256 ANDs and restores unit cuts on frontier variables. Its sixteen cuts are selected by arity/leaf-ID/truth-table order, then each phase keeps the fastest plan and one minimum-cell-area alternative. This proves a restriction of the available structural candidate space; it does NOT prove that any particular regression is caused by that restriction.

4. The production driver strips inherited EGM environment variables. This fixed control does not set EGM_CRITICAL_RECOVERY; the CLI defaults it to zero. Local proposal timing gain therefore becomes zero and proposals are sorted by estimated area delta before bounded trials. Whole-cover acceptance still uses delay-area lexicographic metrics. Proposal priority and acceptance objective are therefore misaligned.

5. Local proposal collection checks its deadline inside the collection loop only for the cone pass. The first ordinary pass can collect and sort a large candidate list before the first trial. A zero trial count can therefore reflect setup/seed/preparation/sorting consumption, not a lack of legal improvement candidates. Stage instrumentation is needed before assigning causal timing costs.

## Selected critical paths

Each profile can have a different critical endpoint; these are selected-cover descriptions, not matched-cone causal proofs. ABC is one fixed reference, not a per-design merged best baseline.

| Inventory/design | Main delay / path cells | Regional-area delay / path cells | Original ABC map delay / path cells |
|---|---:|---:|---:|
| 3in bar | 190.87 / 9 | 254.76 / 12 | 190.87 / 9 |
| 4in bar | 188.34 / 9 | 216.03 / 10 | 171.90 / 8 |
| 4in sqrt | 73633.69 / 3061 | 48010.83 / 2130 | 47071.95 / 2078 |
| 4in sin | 2029.35 / 86 | 1882.00 / 84 | 1857.54 / 79 |
| 4in max | 2098.34 / 104 | 2119.86 / 105 | 2076.21 / 102 |
| 4in priority | 2047.24 / 102 | 2062.54 / 103 | 2045.58 / 102 |
| 4in cavlc | 194.95 / 10 | 202.93 / 10 | 186.01 / 9 |
| 4in dec | 66.15 / 3 | 68.67 / 3 | 65.72 / 3 |

Bar 3in: main 9 cells at mean arc 21.21; regional 12 cells at 21.23. Its 33.47% regression is associated with more path stages, not a materially slower average arc. Critical endpoints differ (result[98] vs result[90]), so this is not proof that a particular three-cell replacement caused the gap. Bar 4in similarly has main/regional/ABC path lengths 9/10/8.

Sqrt 4in: main/regional/ABC path lengths 3061/2130/2078, with AO31 counts 354/1628/1739. Regional delay is only 1.99% above ABC, although main is 56.43% above ABC in these fixed first-run observations. All three critical paths end at asqrt[0]. The residual gap remains worth auditing at cut/phase/pin interfaces; counts alone do not establish candidate absence or a feasible substitution.

Sin 4in: main/regional/ABC path lengths 86/84/79. Regional improves over main but remains slower than ABC and emap (1788.13, 80 cells). This leaves structural and pin/phase matching space, not merely area recovery space.

Priority 4in: main 102 cells / 2047.24; the existing E-morphic native winner has 50 / 1071.64. It still primarily uses OAI21 and AOI21. Main has 2190 e-nodes, no saturation budget skips and 37608 producers, so the global node/pool cap is not exhausted. The fixed profile uses BOOLEAN=0 and LIBRARY_TIMING=0: no explicit association rule and no bounded library-timing association rule are installed. Saturated means exhausted installed rewrites, not exhausted all equivalent representations. E-morphic includes its original native search and ABC feedback; this selected-path comparison is not equal end-to-end compute or proof our two-second recovery can reproduce it.

## Candidate cap evidence

| Inventory/design | Before cap | After cap | Critical targets losing common-witness best arrival estimate |
|---|---:|---:|---:|
| 3in bar | 100000 | 100000 | 0 |
| 3in sin | 199392 | 100000 | 0 |
| 3in sqrt | 693868 | 100000 | 1464 |
| 3in priority | 18508 | 18508 | 0 |
| 4in bar | 154547 | 100000 | 0 |
| 4in sin | 398174 | 100000 | 0 |
| 4in sqrt | 1726666 | 100000 | 1501 |
| 4in priority | 37608 | 37608 | 0 |

These losses are local scores under ONE area-ranked witness, not delay lower bounds or CEC-verified replacement improvements. Zero losses do not prove that optimal cuts were generated or that the witness ranking is appropriate. In particular, bar can regress even with no loss at the later pool cap; cut enumeration and regional cut resets remain separate filters. Sqrt has substantial cap losses, consistent with prior exact phase replay evidence, but this does not turn a speculative AO31 replacement into a valid cover. The prior fixed 4096 compound reservation experiment had no delay gain and a timeout; do not repeat it unchanged or simply reserve more AO31 slots.

## Prioritized experiments without increasing budgets

1. Preserve the production seed inside one imported graph, physical pool and global deadline. Admit regional cuts as additional bounded alternatives rather than replace the seed generator. Protect every incumbent binding; swap optional slots, not source versions or per-design outside-budget outputs. Keep an independently validated best delay-area cover throughout.

2. Isolate delay recovery scheduling. First instrument witness/setup, each flow seed, critical proposal preparation/sort, phase, local/cone trials and final validation with one frozen diagnostic build. Then compare critical-recovery on/off with identical retained-pool fingerprints. Replace the full proposal sort with bounded top-K/early live-critical filtering under the existing trial cap; reserve remaining-window time for critical trials rather than let all setup and seeds consume it. No guaranteed ratio is selected from these data.

3. Audit and retain cross-region frontier cuts with exact pin/phase interfaces. Prioritize bar and sqrt. Within sixteen cut slots, protect the incumbent cut and preserve nondominated delay/area and positive/negative phase alternatives; retain critical fusion candidates rather than simply smallest-arity cuts. All referenced logical classes, pending dependencies and physical alternatives must remain globally charged. Retiring interfaces cannot be renamed as cumulative budget compliance.

4. Address the long-chain structural plateau in priority/max separately from sqrt. Explore targeted exact association/factoring/prefix restructuring inside the mapper, not another external resyn2 or modified baseline. Use existing node allowance and sixteen saturation iterations; count every RHS allocation and preserve incumbent candidates. Global balancing can sacrifice multi-output sharing, so verify both actual delay and unique physical area.

5. After a strong delay stage, keep the fixed required-time actual-area stage. Use joint producer/inverter or bounded cone trials for critical plateaus; a local arrival improvement may not improve the global maximum when several outputs tie. Incremental timing/instance-reference updates can reduce trial cost, but acceptance and final validation must recompute the complete physical cover.

Each changed source/profile requires explicit same-input/library/budget full EPFL comparison and repetitions with failures retained. Node/pool/trial/time limits stay unchanged. Do not promote based only on sqrt, merge regional/main winners per design or take the best repeat.

Multiplier remains independent: retirement leaves 55628 cumulative materialized nodes, and 24556 original live ANDs already exceed 20000. Addressing it requires an explicitly proved elimination/representation change; none is established by this delay analysis.

