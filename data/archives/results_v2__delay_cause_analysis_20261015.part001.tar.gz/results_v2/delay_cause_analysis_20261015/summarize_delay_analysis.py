import json,math,hashlib
from pathlib import Path
root=Path('/home/flynn/workplace/MIGBalance');out=root/'results_v2/delay_cause_analysis_20261015'
records=json.loads((out/'paths.json').read_text())['records'];d={(x['k'],x['bench'],x['profile']):x for x in records};seeds=json.loads((out/'seed_stage_stats.json').read_text());campaign=json.load(open(root/'results_v2/compound_cap_epfl_full_20261014/campaign.json'));regional=json.load(open(root/'results_v2/actual_area_recovery_full_20261014/report.json'));matched=0;pool=[]
for r in regional['results']:
 if r['status']!='diagnostic_cec_ok' or not r['formal_same_import_budget_eligible']:continue
 j=next(j for j in campaign['jobs'] if (j['k'],j['bench'],j['profile'])==(r['k'],r['bench'],'control'));rp=Path(j['report']);p=json.load(open(rp));m=p['results'][0]
 assert p['library_sha256']==r['library_sha256'] and m['input_sha256']==r['input_sha256'] and m['preprocessing']['sha256']==r['prepared_sha256'];matched+=1
 f=rp.parent/f"{r['bench']}.{m['method']}";diag=json.load(open(f/'candidate-diagnostics.json'));q=json.load(open(f/'pool-diagnostics.json'));critical={x['signal'] for x in diag['critical_signals']};loss=[]
 for s in q['signals']:
  if s['signal'] not in critical:continue
  b,a=s['best_before'],s['best_after']
  if not b or not a:continue
  x,y=b['area_witness_arrival_estimate'],a['area_witness_arrival_estimate']
  if x is not None and y is not None and math.isfinite(x) and math.isfinite(y) and y>x+1e-6:loss.append({'signal':s['signal'],'before_cell':b['cell'],'after_cell':a['cell'],'before_estimate':x,'after_estimate':y,'difference':y-x})
 pool.append({'k':r['k'],'bench':r['bench'],'before':q['instances_before'],'after':q['instances_after'],'witness_reserved':q['witness_reserved_instances'],'critical_signals':len(critical),'critical_common_witness_best_estimate_loss':len(loss),'losses':loss,'meaning':'estimates under a common area witness, NOT actual valid replacement benefit or minimum-delay bounds'})
 print(r['k'],r['bench'],len(loss),flush=True)
(out/'pool_loss.json').write_text(json.dumps(pool,indent=2))
rows=[]
for s in seeds:
 k,b=s['k'],s['bench'];m=d[k,b,'production'];r=d[k,b,'regional_area'];a=d[k,b,'abc_map_delay_resyn2']
 rows.append({'k':k,'bench':b,'production_delay':m['delay'],'regional_delay':r['delay'],'abc_delay':a['delay'],'production_vs_abc_percent':100*(m['delay']/a['delay']-1),'regional_vs_abc_percent':100*(r['delay']/a['delay']-1),'regional_vs_production_percent':100*(r['delay']/m['delay']-1),'production_cells':m['critical_path_cells'],'regional_cells':r['critical_path_cells'],'abc_cells':a['critical_path_cells'],'production_mean_arc':m['mean_critical_arc_delay'],'regional_mean_arc':r['mean_critical_arc_delay'],'abc_mean_arc':a['mean_critical_arc_delay'],'critical_endpoints':[m['endpoint'],r['endpoint'],a['endpoint']],'seed_equals_final':abs(s['seed_delay']-s['final_delay'])<1e-6,'local_trials':s['refinement_trials']})
summary={'reproduced_netlists':len(records),'reconstruction_errors':0,'source_identity_verified_cases':matched,'production_seed_equals_final_delay_count':sum(x['seed_equals_final'] for x in rows),'production_case_count':len(rows),'no_local_trial_cases':[{k:x[k] for k in ['k','bench']} for x in rows if x['local_trials']==0],'baseline_algorithms_changed':False,'new_mapping_runs':0,'hypotheses_not_causally_proven':['region cut resets explain any particular full-suite regression','common-area-witness scoring losses determine a feasible faster cover','critical recovery flag or phase budget changes will improve all cases'],'limitations':['These are selected critical paths and may end at different ports. Depth and cell-family differences are descriptive, not a matched-cone causal experiment.','Stage counters do not separate finite-witness/setup, each flow seed, proposal collection and sorting times.','No physical loaded-delay, slew or interconnect inference.','No production promotion, no new full-suite mapping claim, no per-design winner selection.']}
(out/'summary.json').write_text(json.dumps(summary,indent=2));(out/'comparison.json').write_text(json.dumps(rows,indent=2));print(summary)
