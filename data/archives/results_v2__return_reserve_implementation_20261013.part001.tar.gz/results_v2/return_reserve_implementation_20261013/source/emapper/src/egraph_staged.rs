//! Experimental single-pool staging. All stages share the caller's deadline.
use super::*;

fn stage_ends(start: Instant, global: Instant) -> (Instant, Instant) {
    if global <= start { return (global, global); }
    let remaining = global.duration_since(start);
    (start + remaining.mul_f64(0.30), start + remaining.mul_f64(0.50))
}

fn remember(
    cover: &[Option<Binding>], value: (f64, f64), ps: &MapParams,
    best: &mut Vec<Option<Binding>>, score: &mut (f64, f64),
) {
    if better_cover(value, *score, ps) {
        *best = cover.to_vec(); *score = value;
    }
}

pub(super) fn recover(
    instances: &[Instance], free: &[bool], roots: &[usize],
    ps: &MapParams, stats: &mut MapStats, deadline: Instant,
) -> Result<Vec<Option<Binding>>, String> {
    // The initial feasible witness, including its setup cost, is inside the
    // caller's original global recovery window. No pool or e-graph is rebuilt.
    let witness = finite_choices_queued(instances, free);
    let mut chosen = witness.clone();
    prune(instances, &mut chosen, free, roots)?;
    let initial = metrics(instances, &chosen, free, roots);
    stats.initial_area = initial.0; stats.initial_delay = initial.1;
    stats.seed_delay = initial.1;
    let mut global_best = chosen.clone();
    let mut global_score = initial;
    let stage_start = Instant::now();
    let (delay_end, area_end) = stage_ends(stage_start, deadline);

    // Stage 1: arrival-first flow. Repair and score the actual full cover.
    let mut references = vec![1.; free.len()];
    let mut edges = HashSet::new();
    for m in instances {
        if Instant::now() >= delay_end { break; }
        for output in &m.outputs {
            for &s in &output.targets {
                for &input in &m.inputs { edges.insert((input, s)); }
            }
        }
    }
    for (input, _) in edges { references[input] += 1.; }
    for refs in [vec![1.; free.len()], references] {
        if Instant::now() >= delay_end { break; }
        let (mut trial, _) = if ps.staged_event_flow {
            flow_choices_worklist_impl(instances, free, &refs, 0., false, true,
                MapObjective::DelayArea, delay_end, None, None)
        } else {
            flow_choices(instances, free, &refs, 0., false, true,
                MapObjective::DelayArea, delay_end)
        };
        if fill_from_witness(instances, &mut trial, &witness, free, roots).is_err() { continue; }
        let value = metrics(instances, &trial, free, roots);
        stats.seed_delay = stats.seed_delay.min(value.1);
        if better_cover(value, global_score, ps) {
            chosen = trial.clone();
            global_best = trial; global_score = value;
        }
    }
    stats.staged_delay_secs = stage_start.elapsed().as_secs_f64();
    let reference_delay = global_score.1;
    stats.staged_delay_bound = ps.max_delay.map_or(reference_delay, |d| d.min(reference_delay));
    let mut area_params = ps.clone();
    area_params.objective = MapObjective::AreaDelay;
    area_params.max_delay = Some(ps.max_delay.map_or(reference_delay, |d| d.min(reference_delay)));
    let mut working_value = metrics(instances, &chosen, free, roots);

    // Stage 2: required-time area flow under the frozen validated delay bound.
    let area_start = Instant::now();
    for _ in 0..ps.refine_rounds {
        if Instant::now() >= area_end { break; }
        let required = required_times(instances, &chosen, free, roots, stats.staged_delay_bound);
        stats.staged_required_signals = required.iter().filter(|r| r.is_finite()).count();
        let refs = physical_refs(instances, &chosen, roots);
        let (mut trial, _) = flow_choices_worklist_impl(
            instances, free, &refs, 0., true, true, MapObjective::AreaDelay,
            area_end, Some(&required), Some(&chosen),
        );
        if fill_from_witness(instances, &mut trial, &witness, free, roots).is_err() { break; }
        let value = metrics(instances, &trial, free, roots);
        remember(&trial, value, ps, &mut global_best, &mut global_score);
        if !better_cover(value, working_value, &area_params) { break; }
        chosen = trial; working_value = value;
        stats.staged_area_accepts += 1;
    }
    stats.staged_area_secs = area_start.elapsed().as_secs_f64();

    // Stage 3: actual unique-instance area recovery. Single-pin and joint live
    // output replacements both receive whole-cover acyclicity/timing checks.
    // A separate lexicographic incumbent retains delay improvements, even if
    // an area-first exploration branch rejects them for their higher area.
    let exact_start = Instant::now();
    let mut order: Vec<_> = (0..instances.len()).collect();
    order.sort_by(|&a, &b| instances[a].area.total_cmp(&instances[b].area).then(a.cmp(&b)));
    'rounds: for _ in 0..ps.refine_rounds {
        // Recompute only the proposal order. Full-cover legality, fixed timing
        // bound, total trial cap and global deadline remain authoritative.
        if ps.staged_critical_order {
            let (arrival, critical) = critical_arrivals(instances, &chosen, free, roots);
            order.sort_by(|&a, &b| {
                critical_gain(&instances[a], &chosen, &arrival, &critical)
                    .total_cmp(&critical_gain(&instances[b], &chosen, &arrival, &critical))
                    .then(instances[a].area.total_cmp(&instances[b].area)).then(a.cmp(&b))
            });
        }
        let before = stats.refinement_accepted;
        for &i in &order {
            if Instant::now() >= deadline || stats.refinement_trials >= ps.refine_trials { break 'rounds; }
            let m = &instances[i];
            let mut assignments = Vec::new();
            for (pin, output) in m.outputs.iter().enumerate() {
                for &s in &output.targets {
                    if !free[s] && chosen[s].is_some()
                        && chosen[s].is_none_or(|b| b.instance != i || b.pin != pin) {
                        assignments.push((s, Binding { instance: i, pin }));
                    }
                }
            }
            let mut proposals: Vec<Vec<_>> = assignments.iter().map(|a| vec![*a]).collect();
            if assignments.len() > 1 { proposals.push(assignments); }
            for assignment in proposals {
                if Instant::now() >= deadline || stats.refinement_trials >= ps.refine_trials { break 'rounds; }
                stats.refinement_trials += 1;
                let mut trial = chosen.clone();
                for (s, binding) in assignment { trial[s] = Some(binding); }
                if fill_from_witness(instances, &mut trial, &witness, free, roots).is_err() { continue; }
                let value = metrics(instances, &trial, free, roots);
                remember(&trial, value, ps, &mut global_best, &mut global_score);
                if better_cover(value, working_value, &area_params) {
                    chosen = trial; working_value = value;
                    stats.refinement_accepted += 1;
                }
            }
        }
        if before == stats.refinement_accepted { break; }
    }
    stats.staged_exact_secs = exact_start.elapsed().as_secs_f64();
    prune(instances, &mut global_best, free, roots)?;
    Ok(global_best)
}

#[cfg(test)]
mod tests {
    use super::*;
    fn buffer(area: f32, delay: f32, targets: Vec<usize>) -> Instance {
        Instance { cell: "buf".into(), area, input_pins: vec!["A".into()], inputs: vec![0],
            outputs: vec![OutputPin { name: "Y".into(), targets, delays: vec![delay], function: 2 }] }
    }
    #[test]
    fn area_recovery_cannot_buy_area_with_reference_delay() {
        let cells = vec![buffer(1., 10., vec![2]), buffer(2., 2., vec![2]), buffer(1.5, 2., vec![2])];
        let ps = MapParams { strict_budgets: true, objective: MapObjective::DelayArea,
            staged_recovery: true, ..Default::default() };
        let mut stats = MapStats::default();
        let c = recover(&cells, &[true, false, false], &[2], &ps, &mut stats,
            Instant::now()+std::time::Duration::from_secs(1)).unwrap();
        assert_eq!(stats.staged_delay_bound, 2.);
        assert_eq!(metrics(&cells, &c, &[true, false, false], &[2]), (1.5, 2.));
    }
    #[test]
    fn joint_pin_area_is_charged_once_under_the_timing_bound() {
        let mut joint = buffer(1., 2., vec![2]);
        let mut second = joint.outputs[0].clone(); second.name = "Z".into(); second.targets = vec![4];
        joint.outputs.push(second);
        let cells = vec![buffer(0.6, 2., vec![2]), buffer(0.6, 2., vec![4]), joint];
        let free = [true, false, false, false, false];
        let ps = MapParams { strict_budgets: true, objective: MapObjective::DelayArea,
            staged_recovery: true, ..Default::default() };
        let mut stats = MapStats::default();
        let c = recover(&cells, &free, &[2,4], &ps, &mut stats,
            Instant::now()+std::time::Duration::from_secs(1)).unwrap();
        assert_eq!(metrics(&cells, &c, &free, &[2,4]), (1., 2.));
        assert!(stats.refinement_accepted > 0);
    }
    #[test]
    fn deadlines_partition_one_remaining_window() {
        let start = Instant::now(); let global = start+std::time::Duration::from_secs(2);
        let (d,a) = stage_ends(start,global);
        assert_eq!(d-start,std::time::Duration::from_millis(600));
        assert_eq!(a-start,std::time::Duration::from_secs(1));
        assert!(d <= a && a <= global);
        assert_eq!(stage_ends(global,global),(global,global));
    }
    #[test]
    fn event_flow_reaches_reverse_ordered_deep_cone_with_same_deadline() {
        let n = 96;
        let mut cells = Vec::new();
        for s in (1..=n).rev() {
            let mut cell = buffer(1., 1., vec![s]); cell.inputs = vec![s-1];
            cells.push(cell);
        }
        let mut free = vec![false; n+1]; free[0] = true;
        let refs = vec![1.; n+1];
        let deadline = Instant::now()+std::time::Duration::from_secs(1);
        let (old, _) = flow_choices(&cells,&free,&refs,0.,false,true,MapObjective::DelayArea,deadline);
        assert!(old[n].is_none());
        let (mut queued, _) = flow_choices_worklist_impl(&cells,&free,&refs,0.,false,true,
            MapObjective::DelayArea,deadline,None,None);
        prune(&cells,&mut queued,&free,&[n]).unwrap();
        assert_eq!(metrics(&cells,&queued,&free,&[n]),(96.,96.));
    }

}
