# Finite delay frontier — isolated experimental version

Same production import, exact rewrites, cuts, matcher and retained pool. The new
feature creates a finite acyclic witness by finalizing physically ready signals
in nonnegative readiness-bound order. Every candidate waits for all physical
input drivers, including logically nondependent pins. Such pins contribute a
conservative physical readiness bound; this is not a global unloaded-delay
optimality claim. Costs break timing ties with a bounded tree-area proxy.
Repeated inputs are deduplicated for readiness counts, not for physical pin arcs.
All chosen parents precede their output; an unavailable cyclic component is not
invented as a witness. Deadline expiration returns no new seed.

The full all-signal witness and the pruned PO cover are independently validated
before use. The incumbent changes only on actual whole-cover objective
improvement. Subsequent flow seeds start from the validated witness. One global
recovery deadline still includes witness/setup, seeds, phase/local/cone work and
final validation. There is no second mapping run, per-region budget reset or
new logical/physical candidate allocation. Heap entries reference already
admitted output bindings; each edge becomes ready once, so total pushed
references are bounded by the retained binding count. This is not a hard RAM
cap on transient generation or solver labels.

Release tests: 67 relevant tests passed, three existing ignored. New tests cover
cycles, duplicate inputs, timeout and exact delay agreement with exhaustive
small all-arc DAG covers. No general (D,A) or global area optimality declaration.
All original baselines remain unchanged. Default production source is untouched.
