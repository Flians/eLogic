// Benchmark "/home/flynn/workplace/MIGBalance/results_v2/eqmap_lut6_adapter_3in_20261007/c880/lut_stage_amap/stage" written by ABC on Wed Oct  7 16:33:09 2026

module \/home/flynn/workplace/MIGBalance/results_v2/eqmap_lut6_adapter_3in_20261007/c880/lut_stage_amap/stage  ( 
    G1, G10, G11, G12, G13, G14, G15, G16, G17, G18, G19, G2, G20, G21,
    G22, G23, G24, G25, G26, G27, G28, G29, G3, G30, G31, G32, G33, G34,
    G35, G36, G37, G38, G39, G4, G40, G41, G42, G43, G44, G45, G46, G47,
    G48, G49, G5, G50, G51, G52, G53, G54, G55, G56, G57, G58, G59, G6,
    G60, G7, G8, G9,
    G855, G856, G857, G858, G859, G860, G861, G862, G863, G864, G865, G866,
    G867, G868, G869, G870, G871, G872, G873, G874, G875, G876, G877, G878,
    G879, G880  );
  input  G1, G10, G11, G12, G13, G14, G15, G16, G17, G18, G19, G2, G20,
    G21, G22, G23, G24, G25, G26, G27, G28, G29, G3, G30, G31, G32, G33,
    G34, G35, G36, G37, G38, G39, G4, G40, G41, G42, G43, G44, G45, G46,
    G47, G48, G49, G5, G50, G51, G52, G53, G54, G55, G56, G57, G58, G59,
    G6, G60, G7, G8, G9;
  output G855, G856, G857, G858, G859, G860, G861, G862, G863, G864, G865,
    G866, G867, G868, G869, G870, G871, G872, G873, G874, G875, G876, G877,
    G878, G879, G880;
  wire new_n87_, new_n88_, new_n89_, new_n90_, new_n91_, new_n92_, new_n93_,
    new_n94_, new_n95_, new_n96_, new_n97_, new_n98_, new_n99_, new_n100_,
    new_n101_, new_n102_, new_n103_, new_n104_, new_n105_, new_n106_,
    new_n107_, new_n108_, new_n109_, new_n110_, new_n111_, new_n112_,
    new_n113_, new_n114_, new_n115_, new_n116_, new_n117_, new_n118_,
    new_n119_, new_n120_, new_n121_, new_n122_, new_n123_, new_n124_,
    new_n125_, new_n126_, new_n127_, new_n128_, new_n129_, new_n130_,
    new_n131_, new_n132_, new_n133_, new_n134_, new_n136_, new_n139_,
    new_n141_, new_n142_, new_n144_, new_n145_, new_n150_, new_n152_,
    new_n153_, new_n155_, new_n157_, new_n158_, new_n159_, new_n160_,
    new_n162_, new_n165_, new_n166_, new_n167_, new_n168_, new_n169_,
    new_n170_, new_n171_, new_n172_, new_n173_, new_n174_, new_n175_,
    new_n176_, new_n177_, new_n178_, new_n179_, new_n180_, new_n181_,
    new_n182_, new_n183_, new_n184_, new_n185_, new_n186_, new_n187_,
    new_n188_, new_n189_, new_n190_, new_n191_, new_n192_, new_n193_,
    new_n194_, new_n195_, new_n196_, new_n197_, new_n198_, new_n200_,
    new_n201_, new_n202_, new_n203_, new_n204_, new_n205_, new_n206_,
    new_n207_, new_n208_, new_n209_, new_n210_, new_n211_, new_n212_,
    new_n213_, new_n214_, new_n215_, new_n216_, new_n217_, new_n218_,
    new_n219_, new_n220_, new_n221_, new_n222_, new_n223_, new_n225_,
    new_n226_, new_n227_, new_n228_, new_n229_, new_n230_, new_n231_,
    new_n232_, new_n233_, new_n234_, new_n235_, new_n236_, new_n237_,
    new_n238_, new_n239_, new_n240_, new_n241_, new_n242_, new_n243_,
    new_n244_, new_n245_, new_n246_, new_n247_, new_n248_, new_n249_,
    new_n250_, new_n251_, new_n252_, new_n253_, new_n254_, new_n255_,
    new_n256_, new_n257_, new_n258_, new_n259_, new_n260_, new_n261_,
    new_n262_, new_n263_, new_n264_, new_n265_, new_n266_, new_n267_,
    new_n268_, new_n269_, new_n270_, new_n271_, new_n272_, new_n274_,
    new_n275_, new_n276_, new_n277_, new_n278_, new_n279_, new_n280_,
    new_n281_, new_n282_, new_n283_, new_n284_, new_n285_, new_n286_,
    new_n287_, new_n288_, new_n289_, new_n290_, new_n291_, new_n292_,
    new_n293_, new_n294_, new_n295_, new_n296_, new_n297_, new_n298_,
    new_n299_, new_n300_, new_n301_, new_n302_, new_n303_, new_n304_,
    new_n305_, new_n306_, new_n307_, new_n308_, new_n309_, new_n310_,
    new_n311_, new_n312_, new_n313_, new_n314_, new_n315_, new_n316_,
    new_n317_, new_n318_, new_n319_, new_n320_, new_n321_, new_n322_,
    new_n323_, new_n324_, new_n325_, new_n326_, new_n327_, new_n328_,
    new_n329_, new_n330_, new_n331_, new_n333_, new_n334_, new_n335_,
    new_n336_, new_n337_, new_n338_, new_n339_, new_n340_, new_n341_,
    new_n342_, new_n343_, new_n344_, new_n345_, new_n346_, new_n347_,
    new_n348_, new_n349_, new_n350_, new_n351_, new_n353_, new_n354_,
    new_n355_, new_n356_, new_n357_, new_n358_, new_n359_, new_n360_,
    new_n361_, new_n362_, new_n363_, new_n364_, new_n365_, new_n366_,
    new_n367_, new_n368_, new_n369_, new_n370_, new_n371_, new_n373_,
    new_n374_, new_n375_, new_n376_, new_n377_, new_n378_, new_n379_,
    new_n380_, new_n381_, new_n382_, new_n383_, new_n384_, new_n385_,
    new_n386_, new_n387_, new_n388_, new_n389_, new_n390_, new_n391_,
    new_n392_, new_n393_, new_n394_, new_n395_, new_n396_, new_n397_,
    new_n398_, new_n399_, new_n400_, new_n401_, new_n402_, new_n403_,
    new_n404_, new_n405_, new_n406_, new_n407_, new_n408_, new_n409_,
    new_n410_, new_n411_, new_n412_, new_n413_, new_n414_, new_n415_,
    new_n416_, new_n417_, new_n418_, new_n419_, new_n420_, new_n421_,
    new_n422_, new_n423_, new_n424_, new_n425_, new_n426_, new_n427_,
    new_n428_, new_n429_, new_n430_, new_n431_, new_n432_, new_n433_,
    new_n434_, new_n435_, new_n436_, new_n437_, new_n438_, new_n439_,
    new_n440_, new_n441_, new_n442_, new_n443_, new_n444_, new_n445_,
    new_n446_, new_n447_, new_n448_, new_n449_, new_n450_, new_n451_,
    new_n452_, new_n453_, new_n454_, new_n455_, new_n456_, new_n458_,
    new_n459_, new_n460_, new_n461_, new_n462_, new_n463_, new_n464_,
    new_n465_, new_n466_, new_n467_, new_n468_, new_n469_, new_n470_,
    new_n471_, new_n472_, new_n473_, new_n474_, new_n475_, new_n476_,
    new_n477_, new_n478_, new_n480_, new_n481_, new_n482_, new_n483_,
    new_n484_, new_n485_, new_n486_, new_n487_, new_n488_, new_n489_,
    new_n490_, new_n491_, new_n492_, new_n493_, new_n494_, new_n495_,
    new_n496_, new_n497_, new_n498_, new_n499_, new_n500_, new_n501_,
    new_n502_, new_n504_, new_n505_, new_n506_, new_n507_, new_n508_,
    new_n509_, new_n510_, new_n511_, new_n512_, new_n513_, new_n514_,
    new_n515_, new_n516_, new_n517_, new_n518_, new_n519_, new_n521_,
    new_n522_, new_n523_, new_n524_, new_n525_, new_n526_, new_n527_,
    new_n528_, new_n529_, new_n530_, new_n531_, new_n532_, new_n533_,
    new_n534_, new_n535_, new_n536_, new_n537_, new_n538_, new_n539_,
    new_n540_, new_n541_, new_n542_, new_n543_, new_n544_;
  INVx1_ASAP7_75t_R   g000(.A(G1), .Y(new_n87_));
  INVx1_ASAP7_75t_R   g001(.A(G10), .Y(new_n88_));
  INVx1_ASAP7_75t_R   g002(.A(G11), .Y(new_n89_));
  INVx1_ASAP7_75t_R   g003(.A(G12), .Y(new_n90_));
  INVx1_ASAP7_75t_R   g004(.A(G13), .Y(new_n91_));
  INVx1_ASAP7_75t_R   g005(.A(G15), .Y(new_n92_));
  INVx1_ASAP7_75t_R   g006(.A(G16), .Y(new_n93_));
  INVx1_ASAP7_75t_R   g007(.A(G17), .Y(new_n94_));
  INVx1_ASAP7_75t_R   g008(.A(G18), .Y(new_n95_));
  INVx1_ASAP7_75t_R   g009(.A(G2), .Y(new_n96_));
  INVx1_ASAP7_75t_R   g010(.A(G22), .Y(new_n97_));
  INVx1_ASAP7_75t_R   g011(.A(G23), .Y(new_n98_));
  INVx1_ASAP7_75t_R   g012(.A(G25), .Y(new_n99_));
  INVx1_ASAP7_75t_R   g013(.A(G26), .Y(new_n100_));
  INVx1_ASAP7_75t_R   g014(.A(G28), .Y(new_n101_));
  INVx1_ASAP7_75t_R   g015(.A(G29), .Y(new_n102_));
  INVx1_ASAP7_75t_R   g016(.A(G3), .Y(new_n103_));
  INVx1_ASAP7_75t_R   g017(.A(G30), .Y(new_n104_));
  INVx1_ASAP7_75t_R   g018(.A(G31), .Y(new_n105_));
  INVx1_ASAP7_75t_R   g019(.A(G34), .Y(new_n106_));
  INVx1_ASAP7_75t_R   g020(.A(G36), .Y(new_n107_));
  INVx1_ASAP7_75t_R   g021(.A(G37), .Y(new_n108_));
  INVx1_ASAP7_75t_R   g022(.A(G38), .Y(new_n109_));
  INVx1_ASAP7_75t_R   g023(.A(G39), .Y(new_n110_));
  INVx1_ASAP7_75t_R   g024(.A(G4), .Y(new_n111_));
  INVx1_ASAP7_75t_R   g025(.A(G40), .Y(new_n112_));
  INVx1_ASAP7_75t_R   g026(.A(G41), .Y(new_n113_));
  INVx1_ASAP7_75t_R   g027(.A(G42), .Y(new_n114_));
  INVx1_ASAP7_75t_R   g028(.A(G43), .Y(new_n115_));
  INVx1_ASAP7_75t_R   g029(.A(G44), .Y(new_n116_));
  INVx1_ASAP7_75t_R   g030(.A(G45), .Y(new_n117_));
  INVx1_ASAP7_75t_R   g031(.A(G46), .Y(new_n118_));
  INVx1_ASAP7_75t_R   g032(.A(G47), .Y(new_n119_));
  INVx1_ASAP7_75t_R   g033(.A(G48), .Y(new_n120_));
  INVx1_ASAP7_75t_R   g034(.A(G5), .Y(new_n121_));
  INVx1_ASAP7_75t_R   g035(.A(G50), .Y(new_n122_));
  INVx1_ASAP7_75t_R   g036(.A(G51), .Y(new_n123_));
  INVx1_ASAP7_75t_R   g037(.A(G52), .Y(new_n124_));
  INVx1_ASAP7_75t_R   g038(.A(G53), .Y(new_n125_));
  INVx1_ASAP7_75t_R   g039(.A(G55), .Y(new_n126_));
  INVx1_ASAP7_75t_R   g040(.A(G56), .Y(new_n127_));
  INVx1_ASAP7_75t_R   g041(.A(G57), .Y(new_n128_));
  INVx1_ASAP7_75t_R   g042(.A(G58), .Y(new_n129_));
  INVx1_ASAP7_75t_R   g043(.A(G59), .Y(new_n130_));
  INVx1_ASAP7_75t_R   g044(.A(G6), .Y(new_n131_));
  INVx1_ASAP7_75t_R   g045(.A(G7), .Y(new_n132_));
  INVx1_ASAP7_75t_R   g046(.A(G9), .Y(new_n133_));
  OAI21x1_ASAP7_75t_R g047(.A1(new_n131_), .A2(G8), .B(G6), .Y(new_n134_));
  AO21x1_ASAP7_75t_R  g048(.A1(G16), .A2(new_n134_), .B(new_n93_), .Y(G855));
  AO21x1_ASAP7_75t_R  g049(.A1(new_n94_), .A2(G6), .B(new_n131_), .Y(new_n136_));
  AO21x1_ASAP7_75t_R  g050(.A1(G7), .A2(new_n136_), .B(new_n132_), .Y(G856));
  AO21x1_ASAP7_75t_R  g051(.A1(G7), .A2(new_n134_), .B(new_n132_), .Y(G857));
  INVx1_ASAP7_75t_R   g052(.A(G857), .Y(new_n139_));
  OAI21x1_ASAP7_75t_R g053(.A1(new_n95_), .A2(G19), .B(G18), .Y(G858));
  AO21x1_ASAP7_75t_R  g054(.A1(G1), .A2(new_n111_), .B(new_n87_), .Y(new_n141_));
  AO21x1_ASAP7_75t_R  g055(.A1(G2), .A2(new_n141_), .B(new_n96_), .Y(new_n142_));
  AO21x1_ASAP7_75t_R  g056(.A1(G3), .A2(new_n142_), .B(new_n103_), .Y(G859));
  OR3x1_ASAP7_75t_R   g057(.A(new_n111_), .B(new_n139_), .C(new_n87_), .Y(new_n144_));
  OR3x1_ASAP7_75t_R   g058(.A(new_n103_), .B(new_n144_), .C(new_n121_), .Y(new_n145_));
  INVx1_ASAP7_75t_R   g059(.A(new_n145_), .Y(G860));
  AND3x1_ASAP7_75t_R  g060(.A(G11), .B(G17), .C(G16), .Y(G861));
  AND3x1_ASAP7_75t_R  g061(.A(G11), .B(G17), .C(G7), .Y(G862));
  AND3x1_ASAP7_75t_R  g062(.A(G11), .B(G8), .C(G7), .Y(G863));
  NOR2x1_ASAP7_75t_R  g063(.A(G20), .B(G21), .Y(new_n150_));
  AO21x1_ASAP7_75t_R  g064(.A1(G23), .A2(new_n150_), .B(new_n98_), .Y(G864));
  OR3x1_ASAP7_75t_R   g065(.A(new_n111_), .B(G857), .C(new_n87_), .Y(new_n152_));
  OR3x1_ASAP7_75t_R   g066(.A(new_n103_), .B(new_n152_), .C(new_n121_), .Y(new_n153_));
  INVx1_ASAP7_75t_R   g067(.A(new_n153_), .Y(G865));
  AO21x1_ASAP7_75t_R  g068(.A1(new_n87_), .A2(G9), .B(new_n133_), .Y(new_n155_));
  AO21x1_ASAP7_75t_R  g069(.A1(G5), .A2(new_n155_), .B(new_n121_), .Y(G866));
  INVx1_ASAP7_75t_R   g070(.A(G866), .Y(new_n157_));
  OR3x1_ASAP7_75t_R   g071(.A(new_n87_), .B(new_n88_), .C(new_n96_), .Y(new_n158_));
  OR2x4_ASAP7_75t_R   g072(.A(new_n103_), .B(new_n158_), .Y(new_n159_));
  AO21x1_ASAP7_75t_R  g073(.A1(G12), .A2(new_n159_), .B(new_n90_), .Y(new_n160_));
  AO21x1_ASAP7_75t_R  g074(.A1(G6), .A2(new_n160_), .B(new_n131_), .Y(G867));
  AO21x1_ASAP7_75t_R  g075(.A1(G11), .A2(new_n160_), .B(new_n89_), .Y(new_n162_));
  AO21x1_ASAP7_75t_R  g076(.A1(G15), .A2(new_n162_), .B(new_n92_), .Y(G868));
  AO21x1_ASAP7_75t_R  g077(.A1(G22), .A2(new_n150_), .B(new_n97_), .Y(G869));
  XOR2x2_ASAP7_75t_R  g078(.A(new_n101_), .B(G29), .Y(new_n165_));
  INVx1_ASAP7_75t_R   g079(.A(new_n165_), .Y(new_n166_));
  XOR2x2_ASAP7_75t_R  g080(.A(new_n101_), .B(new_n102_), .Y(new_n167_));
  INVx1_ASAP7_75t_R   g081(.A(new_n167_), .Y(new_n168_));
  NOR2x1_ASAP7_75t_R  g082(.A(G33), .B(new_n167_), .Y(new_n169_));
  AO21x1_ASAP7_75t_R  g083(.A1(G33), .A2(new_n166_), .B(new_n169_), .Y(new_n170_));
  INVx1_ASAP7_75t_R   g084(.A(new_n170_), .Y(new_n171_));
  NOR2x1_ASAP7_75t_R  g085(.A(G33), .B(new_n165_), .Y(new_n172_));
  AO21x1_ASAP7_75t_R  g086(.A1(G33), .A2(new_n168_), .B(new_n172_), .Y(new_n173_));
  INVx1_ASAP7_75t_R   g087(.A(new_n173_), .Y(new_n174_));
  NOR2x1_ASAP7_75t_R  g088(.A(G32), .B(new_n174_), .Y(new_n175_));
  AO21x1_ASAP7_75t_R  g089(.A1(G32), .A2(new_n170_), .B(new_n175_), .Y(new_n176_));
  NOR2x1_ASAP7_75t_R  g090(.A(G32), .B(new_n171_), .Y(new_n177_));
  AO21x1_ASAP7_75t_R  g091(.A1(G32), .A2(new_n173_), .B(new_n177_), .Y(new_n178_));
  AND2x2_ASAP7_75t_R  g092(.A(new_n100_), .B(new_n178_), .Y(new_n179_));
  AO21x1_ASAP7_75t_R  g093(.A1(G26), .A2(new_n176_), .B(new_n179_), .Y(new_n180_));
  AND2x2_ASAP7_75t_R  g094(.A(new_n100_), .B(new_n176_), .Y(new_n181_));
  AOI21x1_ASAP7_75t_R g095(.A1(G26), .A2(new_n178_), .B(new_n181_), .Y(new_n182_));
  NOR2x1_ASAP7_75t_R  g096(.A(G25), .B(new_n182_), .Y(new_n183_));
  AO21x1_ASAP7_75t_R  g097(.A1(G25), .A2(new_n180_), .B(new_n183_), .Y(new_n184_));
  XOR2x2_ASAP7_75t_R  g098(.A(new_n105_), .B(new_n184_), .Y(new_n185_));
  NOR2x1_ASAP7_75t_R  g099(.A(new_n104_), .B(new_n185_), .Y(new_n186_));
  XNOR2x2_ASAP7_75t_R g100(.A(G31), .B(new_n184_), .Y(new_n187_));
  AO21x1_ASAP7_75t_R  g101(.A1(new_n104_), .A2(new_n187_), .B(new_n186_), .Y(new_n188_));
  INVx1_ASAP7_75t_R   g102(.A(new_n188_), .Y(new_n189_));
  NOR2x1_ASAP7_75t_R  g103(.A(G30), .B(new_n185_), .Y(new_n190_));
  AO21x1_ASAP7_75t_R  g104(.A1(G30), .A2(new_n187_), .B(new_n190_), .Y(new_n191_));
  INVx1_ASAP7_75t_R   g105(.A(new_n191_), .Y(new_n192_));
  NOR2x1_ASAP7_75t_R  g106(.A(G27), .B(new_n192_), .Y(new_n193_));
  AO21x1_ASAP7_75t_R  g107(.A1(G27), .A2(new_n188_), .B(new_n193_), .Y(new_n194_));
  NAND2x1_ASAP7_75t_R g108(.A(G24), .B(new_n194_), .Y(new_n195_));
  NAND2x1_ASAP7_75t_R g109(.A(G27), .B(new_n191_), .Y(new_n196_));
  OA21x2_ASAP7_75t_R  g110(.A1(G27), .A2(new_n189_), .B(new_n196_), .Y(new_n197_));
  OR2x4_ASAP7_75t_R   g111(.A(G24), .B(new_n197_), .Y(new_n198_));
  NAND2x1_ASAP7_75t_R g112(.A(new_n195_), .B(new_n198_), .Y(G870));
  XNOR2x2_ASAP7_75t_R g113(.A(new_n115_), .B(G44), .Y(new_n200_));
  XOR2x2_ASAP7_75t_R  g114(.A(new_n115_), .B(new_n116_), .Y(new_n201_));
  NOR2x1_ASAP7_75t_R  g115(.A(G48), .B(new_n201_), .Y(new_n202_));
  AO21x1_ASAP7_75t_R  g116(.A1(G48), .A2(new_n200_), .B(new_n202_), .Y(new_n203_));
  NOR2x1_ASAP7_75t_R  g117(.A(new_n120_), .B(new_n201_), .Y(new_n204_));
  AO21x1_ASAP7_75t_R  g118(.A1(new_n120_), .A2(new_n200_), .B(new_n204_), .Y(new_n205_));
  AND2x2_ASAP7_75t_R  g119(.A(new_n119_), .B(new_n205_), .Y(new_n206_));
  AO21x1_ASAP7_75t_R  g120(.A1(G47), .A2(new_n203_), .B(new_n206_), .Y(new_n207_));
  XOR2x2_ASAP7_75t_R  g121(.A(new_n114_), .B(new_n207_), .Y(new_n208_));
  NOR2x1_ASAP7_75t_R  g122(.A(new_n113_), .B(new_n208_), .Y(new_n209_));
  XNOR2x2_ASAP7_75t_R g123(.A(G42), .B(new_n207_), .Y(new_n210_));
  AO21x1_ASAP7_75t_R  g124(.A1(new_n113_), .A2(new_n210_), .B(new_n209_), .Y(new_n211_));
  NAND2x1_ASAP7_75t_R g125(.A(G41), .B(new_n210_), .Y(new_n212_));
  OA21x2_ASAP7_75t_R  g126(.A1(G41), .A2(new_n208_), .B(new_n212_), .Y(new_n213_));
  NOR2x1_ASAP7_75t_R  g127(.A(G32), .B(new_n213_), .Y(new_n214_));
  AO21x1_ASAP7_75t_R  g128(.A1(G32), .A2(new_n211_), .B(new_n214_), .Y(new_n215_));
  XOR2x2_ASAP7_75t_R  g129(.A(G46), .B(new_n215_), .Y(new_n216_));
  NOR2x1_ASAP7_75t_R  g130(.A(new_n117_), .B(new_n216_), .Y(new_n217_));
  XNOR2x2_ASAP7_75t_R g131(.A(new_n118_), .B(new_n215_), .Y(new_n218_));
  AO21x1_ASAP7_75t_R  g132(.A1(new_n117_), .A2(new_n218_), .B(new_n217_), .Y(new_n219_));
  NAND2x1_ASAP7_75t_R g133(.A(G49), .B(new_n219_), .Y(new_n220_));
  NAND2x1_ASAP7_75t_R g134(.A(G45), .B(new_n218_), .Y(new_n221_));
  OA21x2_ASAP7_75t_R  g135(.A1(G45), .A2(new_n216_), .B(new_n221_), .Y(new_n222_));
  OR2x4_ASAP7_75t_R   g136(.A(G49), .B(new_n222_), .Y(new_n223_));
  NAND2x1_ASAP7_75t_R g137(.A(new_n220_), .B(new_n223_), .Y(G871));
  AO21x1_ASAP7_75t_R  g138(.A1(new_n126_), .A2(G59), .B(new_n130_), .Y(new_n225_));
  AND3x1_ASAP7_75t_R  g139(.A(new_n104_), .B(new_n225_), .C(G50), .Y(new_n226_));
  AOI21x1_ASAP7_75t_R g140(.A1(new_n122_), .A2(new_n225_), .B(new_n226_), .Y(new_n227_));
  OR3x1_ASAP7_75t_R   g141(.A(new_n91_), .B(new_n159_), .C(new_n90_), .Y(new_n228_));
  NOR2x1_ASAP7_75t_R  g142(.A(new_n89_), .B(new_n228_), .Y(new_n229_));
  AND3x1_ASAP7_75t_R  g143(.A(G8), .B(new_n229_), .C(G14), .Y(new_n230_));
  INVx1_ASAP7_75t_R   g144(.A(new_n230_), .Y(new_n231_));
  XOR2x2_ASAP7_75t_R  g145(.A(new_n111_), .B(G8), .Y(new_n232_));
  OR3x1_ASAP7_75t_R   g146(.A(new_n112_), .B(new_n232_), .C(new_n89_), .Y(new_n233_));
  INVx1_ASAP7_75t_R   g147(.A(new_n233_), .Y(new_n234_));
  NOR2x1_ASAP7_75t_R  g148(.A(new_n87_), .B(new_n111_), .Y(new_n235_));
  AND3x1_ASAP7_75t_R  g149(.A(G9), .B(new_n235_), .C(G2), .Y(new_n236_));
  INVx1_ASAP7_75t_R   g150(.A(new_n236_), .Y(new_n237_));
  AND3x1_ASAP7_75t_R  g151(.A(G11), .B(G8), .C(G16), .Y(new_n238_));
  NOR2x1_ASAP7_75t_R  g152(.A(new_n237_), .B(new_n238_), .Y(new_n239_));
  AO21x1_ASAP7_75t_R  g153(.A1(G866), .A2(new_n239_), .B(new_n157_), .Y(new_n240_));
  AND2x2_ASAP7_75t_R  g154(.A(new_n233_), .B(new_n239_), .Y(new_n241_));
  AOI21x1_ASAP7_75t_R g155(.A1(new_n234_), .A2(new_n240_), .B(new_n241_), .Y(new_n242_));
  NOR2x1_ASAP7_75t_R  g156(.A(new_n105_), .B(new_n242_), .Y(new_n243_));
  OR2x4_ASAP7_75t_R   g157(.A(G60), .B(G866), .Y(new_n244_));
  OR3x1_ASAP7_75t_R   g158(.A(new_n88_), .B(new_n244_), .C(new_n94_), .Y(new_n245_));
  OR3x1_ASAP7_75t_R   g159(.A(new_n131_), .B(new_n245_), .C(new_n93_), .Y(new_n246_));
  INVx1_ASAP7_75t_R   g160(.A(new_n246_), .Y(new_n247_));
  OR3x1_ASAP7_75t_R   g161(.A(new_n89_), .B(new_n112_), .C(new_n111_), .Y(new_n248_));
  AO21x1_ASAP7_75t_R  g162(.A1(G4), .A2(new_n248_), .B(G866), .Y(new_n249_));
  AO21x1_ASAP7_75t_R  g163(.A1(new_n157_), .A2(new_n249_), .B(new_n87_), .Y(new_n250_));
  INVx1_ASAP7_75t_R   g164(.A(new_n250_), .Y(new_n251_));
  OA21x2_ASAP7_75t_R  g165(.A1(G39), .A2(new_n251_), .B(new_n250_), .Y(new_n252_));
  OR3x1_ASAP7_75t_R   g166(.A(new_n247_), .B(new_n252_), .C(new_n243_), .Y(new_n253_));
  INVx1_ASAP7_75t_R   g167(.A(new_n253_), .Y(new_n254_));
  AND3x1_ASAP7_75t_R  g168(.A(new_n120_), .B(new_n254_), .C(new_n230_), .Y(new_n255_));
  AO21x1_ASAP7_75t_R  g169(.A1(new_n231_), .A2(new_n254_), .B(new_n255_), .Y(new_n256_));
  NAND2x1_ASAP7_75t_R g170(.A(G54), .B(new_n256_), .Y(new_n257_));
  AO21x1_ASAP7_75t_R  g171(.A1(new_n125_), .A2(new_n253_), .B(new_n254_), .Y(new_n258_));
  AO21x1_ASAP7_75t_R  g172(.A1(G48), .A2(new_n258_), .B(new_n120_), .Y(new_n259_));
  AND2x2_ASAP7_75t_R  g173(.A(new_n231_), .B(new_n259_), .Y(new_n260_));
  AOI21x1_ASAP7_75t_R g174(.A1(new_n120_), .A2(new_n230_), .B(new_n260_), .Y(new_n261_));
  OA21x2_ASAP7_75t_R  g175(.A1(G54), .A2(new_n261_), .B(new_n257_), .Y(new_n262_));
  AND3x1_ASAP7_75t_R  g176(.A(new_n123_), .B(new_n124_), .C(new_n129_), .Y(new_n263_));
  AO21x1_ASAP7_75t_R  g177(.A1(new_n124_), .A2(G58), .B(new_n263_), .Y(new_n264_));
  AO21x1_ASAP7_75t_R  g178(.A1(new_n123_), .A2(G58), .B(new_n129_), .Y(new_n265_));
  AND2x2_ASAP7_75t_R  g179(.A(new_n253_), .B(new_n265_), .Y(new_n266_));
  AO21x1_ASAP7_75t_R  g180(.A1(new_n254_), .A2(new_n264_), .B(new_n266_), .Y(new_n267_));
  NAND2x1_ASAP7_75t_R g181(.A(G48), .B(new_n267_), .Y(new_n268_));
  AND2x2_ASAP7_75t_R  g182(.A(new_n253_), .B(new_n264_), .Y(new_n269_));
  AOI21x1_ASAP7_75t_R g183(.A1(new_n254_), .A2(new_n265_), .B(new_n269_), .Y(new_n270_));
  OA21x2_ASAP7_75t_R  g184(.A1(G48), .A2(new_n270_), .B(new_n268_), .Y(new_n271_));
  OR3x1_ASAP7_75t_R   g185(.A(new_n227_), .B(new_n262_), .C(new_n271_), .Y(new_n272_));
  INVx1_ASAP7_75t_R   g186(.A(new_n272_), .Y(G872));
  AO21x1_ASAP7_75t_R  g187(.A1(new_n236_), .A2(new_n238_), .B(new_n237_), .Y(new_n274_));
  AND3x1_ASAP7_75t_R  g188(.A(G866), .B(new_n274_), .C(new_n234_), .Y(new_n275_));
  AO21x1_ASAP7_75t_R  g189(.A1(new_n233_), .A2(new_n274_), .B(new_n275_), .Y(new_n276_));
  INVx1_ASAP7_75t_R   g190(.A(new_n276_), .Y(new_n277_));
  OA21x2_ASAP7_75t_R  g191(.A1(new_n101_), .A2(new_n277_), .B(G28), .Y(new_n278_));
  NOR2x1_ASAP7_75t_R  g192(.A(new_n250_), .B(new_n278_), .Y(new_n279_));
  NOR2x1_ASAP7_75t_R  g193(.A(G35), .B(new_n278_), .Y(new_n280_));
  AO21x1_ASAP7_75t_R  g194(.A1(new_n250_), .A2(new_n280_), .B(new_n279_), .Y(new_n281_));
  NAND2x1_ASAP7_75t_R g195(.A(new_n246_), .B(new_n281_), .Y(new_n282_));
  INVx1_ASAP7_75t_R   g196(.A(new_n282_), .Y(new_n283_));
  AO21x1_ASAP7_75t_R  g197(.A1(G29), .A2(new_n276_), .B(new_n102_), .Y(new_n284_));
  AND3x1_ASAP7_75t_R  g198(.A(new_n107_), .B(new_n284_), .C(new_n250_), .Y(new_n285_));
  AOI21x1_ASAP7_75t_R g199(.A1(new_n251_), .A2(new_n284_), .B(new_n285_), .Y(new_n286_));
  NOR2x1_ASAP7_75t_R  g200(.A(new_n247_), .B(new_n286_), .Y(new_n287_));
  INVx1_ASAP7_75t_R   g201(.A(new_n287_), .Y(new_n288_));
  AO21x1_ASAP7_75t_R  g202(.A1(G48), .A2(new_n129_), .B(G58), .Y(new_n289_));
  NAND2x1_ASAP7_75t_R g203(.A(G39), .B(new_n250_), .Y(new_n290_));
  OR3x1_ASAP7_75t_R   g204(.A(new_n110_), .B(new_n251_), .C(G48), .Y(new_n291_));
  AO21x1_ASAP7_75t_R  g205(.A1(new_n120_), .A2(new_n291_), .B(new_n129_), .Y(new_n292_));
  OR3x1_ASAP7_75t_R   g206(.A(new_n120_), .B(new_n290_), .C(G58), .Y(new_n293_));
  AOI21x1_ASAP7_75t_R g207(.A1(new_n292_), .A2(new_n293_), .B(new_n243_), .Y(new_n294_));
  AOI21x1_ASAP7_75t_R g208(.A1(new_n243_), .A2(new_n289_), .B(new_n294_), .Y(new_n295_));
  NOR2x1_ASAP7_75t_R  g209(.A(new_n247_), .B(new_n295_), .Y(new_n296_));
  AO21x1_ASAP7_75t_R  g210(.A1(new_n247_), .A2(new_n289_), .B(new_n296_), .Y(new_n297_));
  INVx1_ASAP7_75t_R   g211(.A(new_n297_), .Y(new_n298_));
  AO21x1_ASAP7_75t_R  g212(.A1(G30), .A2(new_n276_), .B(new_n104_), .Y(new_n299_));
  AND3x1_ASAP7_75t_R  g213(.A(new_n108_), .B(new_n299_), .C(new_n250_), .Y(new_n300_));
  AOI21x1_ASAP7_75t_R g214(.A1(new_n251_), .A2(new_n299_), .B(new_n300_), .Y(new_n301_));
  NOR2x1_ASAP7_75t_R  g215(.A(new_n247_), .B(new_n301_), .Y(new_n302_));
  INVx1_ASAP7_75t_R   g216(.A(new_n302_), .Y(new_n303_));
  AND3x1_ASAP7_75t_R  g217(.A(new_n298_), .B(new_n302_), .C(G47), .Y(new_n304_));
  AO21x1_ASAP7_75t_R  g218(.A1(new_n297_), .A2(new_n302_), .B(new_n298_), .Y(new_n305_));
  AO21x1_ASAP7_75t_R  g219(.A1(new_n119_), .A2(new_n305_), .B(new_n304_), .Y(new_n306_));
  INVx1_ASAP7_75t_R   g220(.A(new_n306_), .Y(new_n307_));
  AO21x1_ASAP7_75t_R  g221(.A1(G46), .A2(new_n306_), .B(new_n118_), .Y(new_n308_));
  AND3x1_ASAP7_75t_R  g222(.A(new_n118_), .B(new_n306_), .C(new_n288_), .Y(new_n309_));
  AO21x1_ASAP7_75t_R  g223(.A1(new_n287_), .A2(new_n308_), .B(new_n309_), .Y(new_n310_));
  NOR2x1_ASAP7_75t_R  g224(.A(G52), .B(new_n230_), .Y(new_n311_));
  OR3x1_ASAP7_75t_R   g225(.A(G54), .B(new_n230_), .C(new_n283_), .Y(new_n312_));
  INVx1_ASAP7_75t_R   g226(.A(new_n312_), .Y(new_n313_));
  AO21x1_ASAP7_75t_R  g227(.A1(new_n283_), .A2(new_n311_), .B(new_n313_), .Y(new_n314_));
  OR3x1_ASAP7_75t_R   g228(.A(G52), .B(G54), .C(new_n283_), .Y(new_n315_));
  AOI21x1_ASAP7_75t_R g229(.A1(new_n282_), .A2(new_n315_), .B(G45), .Y(new_n316_));
  AOI21x1_ASAP7_75t_R g230(.A1(G45), .A2(new_n314_), .B(new_n316_), .Y(new_n317_));
  AO21x1_ASAP7_75t_R  g231(.A1(G27), .A2(G50), .B(new_n317_), .Y(new_n318_));
  INVx1_ASAP7_75t_R   g232(.A(new_n318_), .Y(new_n319_));
  NOR2x1_ASAP7_75t_R  g233(.A(new_n310_), .B(new_n318_), .Y(new_n320_));
  NOR2x1_ASAP7_75t_R  g234(.A(G51), .B(new_n318_), .Y(new_n321_));
  AO21x1_ASAP7_75t_R  g235(.A1(G51), .A2(new_n320_), .B(new_n321_), .Y(new_n322_));
  NOR2x1_ASAP7_75t_R  g236(.A(G53), .B(new_n318_), .Y(new_n323_));
  AND3x1_ASAP7_75t_R  g237(.A(new_n310_), .B(new_n323_), .C(G51), .Y(new_n324_));
  AOI21x1_ASAP7_75t_R g238(.A1(new_n123_), .A2(new_n323_), .B(new_n324_), .Y(new_n325_));
  NOR2x1_ASAP7_75t_R  g239(.A(new_n283_), .B(new_n325_), .Y(new_n326_));
  AO21x1_ASAP7_75t_R  g240(.A1(new_n283_), .A2(new_n322_), .B(new_n326_), .Y(new_n327_));
  AND3x1_ASAP7_75t_R  g241(.A(new_n310_), .B(new_n319_), .C(G51), .Y(new_n328_));
  OA21x2_ASAP7_75t_R  g242(.A1(new_n321_), .A2(new_n328_), .B(new_n283_), .Y(new_n329_));
  AOI21x1_ASAP7_75t_R g243(.A1(new_n282_), .A2(new_n322_), .B(new_n329_), .Y(new_n330_));
  NOR2x1_ASAP7_75t_R  g244(.A(G45), .B(new_n330_), .Y(new_n331_));
  AO21x1_ASAP7_75t_R  g245(.A1(G45), .A2(new_n327_), .B(new_n331_), .Y(G873));
  AO21x1_ASAP7_75t_R  g246(.A1(new_n126_), .A2(G56), .B(new_n127_), .Y(new_n333_));
  AND3x1_ASAP7_75t_R  g247(.A(new_n101_), .B(new_n333_), .C(G50), .Y(new_n334_));
  AO21x1_ASAP7_75t_R  g248(.A1(new_n122_), .A2(new_n333_), .B(new_n334_), .Y(new_n335_));
  AND3x1_ASAP7_75t_R  g249(.A(new_n231_), .B(new_n335_), .C(G46), .Y(new_n336_));
  AOI21x1_ASAP7_75t_R g250(.A1(new_n118_), .A2(new_n335_), .B(new_n336_), .Y(new_n337_));
  OR3x1_ASAP7_75t_R   g251(.A(G53), .B(G54), .C(new_n287_), .Y(new_n338_));
  OAI21x1_ASAP7_75t_R g252(.A1(G52), .A2(new_n288_), .B(new_n338_), .Y(new_n339_));
  OR3x1_ASAP7_75t_R   g253(.A(G52), .B(G54), .C(new_n287_), .Y(new_n340_));
  AOI21x1_ASAP7_75t_R g254(.A1(new_n288_), .A2(new_n340_), .B(G46), .Y(new_n341_));
  AOI21x1_ASAP7_75t_R g255(.A1(G46), .A2(new_n339_), .B(new_n341_), .Y(new_n342_));
  AO21x1_ASAP7_75t_R  g256(.A1(new_n123_), .A2(new_n306_), .B(new_n307_), .Y(new_n343_));
  AO21x1_ASAP7_75t_R  g257(.A1(new_n123_), .A2(new_n307_), .B(new_n306_), .Y(new_n344_));
  AND2x2_ASAP7_75t_R  g258(.A(new_n288_), .B(new_n344_), .Y(new_n345_));
  AO21x1_ASAP7_75t_R  g259(.A1(new_n287_), .A2(new_n343_), .B(new_n345_), .Y(new_n346_));
  NAND2x1_ASAP7_75t_R g260(.A(G46), .B(new_n346_), .Y(new_n347_));
  AND2x2_ASAP7_75t_R  g261(.A(new_n288_), .B(new_n343_), .Y(new_n348_));
  AOI21x1_ASAP7_75t_R g262(.A1(new_n287_), .A2(new_n344_), .B(new_n348_), .Y(new_n349_));
  OA21x2_ASAP7_75t_R  g263(.A1(G46), .A2(new_n349_), .B(new_n347_), .Y(new_n350_));
  OR3x1_ASAP7_75t_R   g264(.A(new_n337_), .B(new_n342_), .C(new_n350_), .Y(new_n351_));
  INVx1_ASAP7_75t_R   g265(.A(new_n351_), .Y(G874));
  AO21x1_ASAP7_75t_R  g266(.A1(new_n126_), .A2(G57), .B(new_n128_), .Y(new_n353_));
  AND3x1_ASAP7_75t_R  g267(.A(new_n102_), .B(new_n353_), .C(G50), .Y(new_n354_));
  AO21x1_ASAP7_75t_R  g268(.A1(new_n122_), .A2(new_n353_), .B(new_n354_), .Y(new_n355_));
  AND3x1_ASAP7_75t_R  g269(.A(new_n231_), .B(new_n355_), .C(G47), .Y(new_n356_));
  AOI21x1_ASAP7_75t_R g270(.A1(new_n119_), .A2(new_n355_), .B(new_n356_), .Y(new_n357_));
  OR3x1_ASAP7_75t_R   g271(.A(G53), .B(G54), .C(new_n302_), .Y(new_n358_));
  OAI21x1_ASAP7_75t_R g272(.A1(G52), .A2(new_n303_), .B(new_n358_), .Y(new_n359_));
  OR3x1_ASAP7_75t_R   g273(.A(G52), .B(G54), .C(new_n302_), .Y(new_n360_));
  AOI21x1_ASAP7_75t_R g274(.A1(new_n303_), .A2(new_n360_), .B(G47), .Y(new_n361_));
  AOI21x1_ASAP7_75t_R g275(.A1(G47), .A2(new_n359_), .B(new_n361_), .Y(new_n362_));
  AO21x1_ASAP7_75t_R  g276(.A1(new_n123_), .A2(new_n303_), .B(new_n302_), .Y(new_n363_));
  AO21x1_ASAP7_75t_R  g277(.A1(new_n123_), .A2(new_n302_), .B(new_n303_), .Y(new_n364_));
  AND2x2_ASAP7_75t_R  g278(.A(new_n298_), .B(new_n364_), .Y(new_n365_));
  AO21x1_ASAP7_75t_R  g279(.A1(new_n297_), .A2(new_n363_), .B(new_n365_), .Y(new_n366_));
  NAND2x1_ASAP7_75t_R g280(.A(G47), .B(new_n366_), .Y(new_n367_));
  AND2x2_ASAP7_75t_R  g281(.A(new_n298_), .B(new_n363_), .Y(new_n368_));
  AOI21x1_ASAP7_75t_R g282(.A1(new_n297_), .A2(new_n364_), .B(new_n368_), .Y(new_n369_));
  OA21x2_ASAP7_75t_R  g283(.A1(G47), .A2(new_n369_), .B(new_n367_), .Y(new_n370_));
  OR3x1_ASAP7_75t_R   g284(.A(new_n357_), .B(new_n362_), .C(new_n370_), .Y(new_n371_));
  INVx1_ASAP7_75t_R   g285(.A(new_n371_), .Y(G875));
  OR3x1_ASAP7_75t_R   g286(.A(new_n111_), .B(new_n244_), .C(new_n94_), .Y(new_n373_));
  OR3x1_ASAP7_75t_R   g287(.A(new_n131_), .B(new_n373_), .C(new_n93_), .Y(new_n374_));
  INVx1_ASAP7_75t_R   g288(.A(new_n374_), .Y(new_n375_));
  OA21x2_ASAP7_75t_R  g289(.A1(new_n89_), .A2(G40), .B(G11), .Y(new_n376_));
  OR3x1_ASAP7_75t_R   g290(.A(G866), .B(new_n376_), .C(new_n88_), .Y(new_n377_));
  INVx1_ASAP7_75t_R   g291(.A(new_n377_), .Y(new_n378_));
  OR3x1_ASAP7_75t_R   g292(.A(G9), .B(new_n277_), .C(new_n106_), .Y(new_n379_));
  NOR2x1_ASAP7_75t_R  g293(.A(G34), .B(new_n277_), .Y(new_n380_));
  INVx1_ASAP7_75t_R   g294(.A(new_n380_), .Y(new_n381_));
  AOI21x1_ASAP7_75t_R g295(.A1(new_n379_), .A2(new_n381_), .B(new_n99_), .Y(new_n382_));
  AO21x1_ASAP7_75t_R  g296(.A1(G34), .A2(new_n133_), .B(new_n106_), .Y(new_n383_));
  AOI21x1_ASAP7_75t_R g297(.A1(new_n99_), .A2(new_n383_), .B(new_n382_), .Y(new_n384_));
  AO21x1_ASAP7_75t_R  g298(.A1(G36), .A2(new_n378_), .B(new_n384_), .Y(new_n385_));
  NOR2x1_ASAP7_75t_R  g299(.A(new_n375_), .B(new_n385_), .Y(new_n386_));
  INVx1_ASAP7_75t_R   g300(.A(new_n386_), .Y(new_n387_));
  AND2x2_ASAP7_75t_R  g301(.A(G35), .B(new_n378_), .Y(new_n388_));
  NOR2x1_ASAP7_75t_R  g302(.A(G2), .B(new_n277_), .Y(new_n389_));
  AO21x1_ASAP7_75t_R  g303(.A1(G2), .A2(new_n380_), .B(new_n389_), .Y(new_n390_));
  NAND2x1_ASAP7_75t_R g304(.A(G24), .B(new_n390_), .Y(new_n391_));
  OA21x2_ASAP7_75t_R  g305(.A1(new_n96_), .A2(G34), .B(G2), .Y(new_n392_));
  OA21x2_ASAP7_75t_R  g306(.A1(G24), .A2(new_n392_), .B(new_n391_), .Y(new_n393_));
  OR3x1_ASAP7_75t_R   g307(.A(new_n375_), .B(new_n393_), .C(new_n388_), .Y(new_n394_));
  INVx1_ASAP7_75t_R   g308(.A(new_n394_), .Y(new_n395_));
  AND3x1_ASAP7_75t_R  g309(.A(new_n251_), .B(new_n276_), .C(G28), .Y(new_n396_));
  AO21x1_ASAP7_75t_R  g310(.A1(new_n101_), .A2(new_n251_), .B(new_n396_), .Y(new_n397_));
  AOI21x1_ASAP7_75t_R g311(.A1(G35), .A2(new_n397_), .B(new_n280_), .Y(new_n398_));
  NOR2x1_ASAP7_75t_R  g312(.A(G45), .B(new_n398_), .Y(new_n399_));
  AO21x1_ASAP7_75t_R  g313(.A1(new_n288_), .A2(new_n302_), .B(new_n303_), .Y(new_n400_));
  AO21x1_ASAP7_75t_R  g314(.A1(new_n298_), .A2(new_n400_), .B(new_n297_), .Y(new_n401_));
  NAND2x1_ASAP7_75t_R g315(.A(new_n297_), .B(new_n400_), .Y(new_n402_));
  OA21x2_ASAP7_75t_R  g316(.A1(new_n287_), .A2(new_n297_), .B(new_n402_), .Y(new_n403_));
  NOR2x1_ASAP7_75t_R  g317(.A(G47), .B(new_n403_), .Y(new_n404_));
  AO21x1_ASAP7_75t_R  g318(.A1(G47), .A2(new_n401_), .B(new_n404_), .Y(new_n405_));
  NAND2x1_ASAP7_75t_R g319(.A(G46), .B(new_n405_), .Y(new_n406_));
  AND3x1_ASAP7_75t_R  g320(.A(new_n288_), .B(new_n303_), .C(new_n298_), .Y(new_n407_));
  AO21x1_ASAP7_75t_R  g321(.A1(new_n288_), .A2(new_n297_), .B(new_n407_), .Y(new_n408_));
  NAND2x1_ASAP7_75t_R g322(.A(G47), .B(new_n408_), .Y(new_n409_));
  OR3x1_ASAP7_75t_R   g323(.A(new_n287_), .B(new_n302_), .C(new_n298_), .Y(new_n410_));
  OA21x2_ASAP7_75t_R  g324(.A1(G47), .A2(new_n410_), .B(new_n409_), .Y(new_n411_));
  OA21x2_ASAP7_75t_R  g325(.A1(G46), .A2(new_n411_), .B(new_n406_), .Y(new_n412_));
  AO21x1_ASAP7_75t_R  g326(.A1(new_n246_), .A2(new_n399_), .B(new_n412_), .Y(new_n413_));
  INVx1_ASAP7_75t_R   g327(.A(new_n413_), .Y(new_n414_));
  NOR2x1_ASAP7_75t_R  g328(.A(new_n110_), .B(new_n377_), .Y(new_n415_));
  NOR2x1_ASAP7_75t_R  g329(.A(G38), .B(new_n277_), .Y(new_n416_));
  AO21x1_ASAP7_75t_R  g330(.A1(G38), .A2(new_n380_), .B(new_n416_), .Y(new_n417_));
  NAND2x1_ASAP7_75t_R g331(.A(G27), .B(new_n417_), .Y(new_n418_));
  OA21x2_ASAP7_75t_R  g332(.A1(G34), .A2(new_n109_), .B(G38), .Y(new_n419_));
  OA21x2_ASAP7_75t_R  g333(.A1(G27), .A2(new_n419_), .B(new_n418_), .Y(new_n420_));
  OR3x1_ASAP7_75t_R   g334(.A(new_n375_), .B(new_n420_), .C(new_n415_), .Y(new_n421_));
  INVx1_ASAP7_75t_R   g335(.A(new_n421_), .Y(new_n422_));
  OR3x1_ASAP7_75t_R   g336(.A(G4), .B(new_n277_), .C(new_n106_), .Y(new_n423_));
  AOI21x1_ASAP7_75t_R g337(.A1(new_n381_), .A2(new_n423_), .B(new_n100_), .Y(new_n424_));
  AO21x1_ASAP7_75t_R  g338(.A1(G34), .A2(new_n111_), .B(new_n106_), .Y(new_n425_));
  AOI21x1_ASAP7_75t_R g339(.A1(new_n100_), .A2(new_n425_), .B(new_n424_), .Y(new_n426_));
  AO21x1_ASAP7_75t_R  g340(.A1(G37), .A2(new_n378_), .B(new_n426_), .Y(new_n427_));
  NOR2x1_ASAP7_75t_R  g341(.A(new_n375_), .B(new_n427_), .Y(new_n428_));
  INVx1_ASAP7_75t_R   g342(.A(new_n428_), .Y(new_n429_));
  NOR2x1_ASAP7_75t_R  g343(.A(new_n421_), .B(new_n429_), .Y(new_n430_));
  AND3x1_ASAP7_75t_R  g344(.A(new_n116_), .B(new_n430_), .C(G43), .Y(new_n431_));
  AO21x1_ASAP7_75t_R  g345(.A1(new_n421_), .A2(new_n428_), .B(new_n422_), .Y(new_n432_));
  AND2x2_ASAP7_75t_R  g346(.A(new_n116_), .B(new_n432_), .Y(new_n433_));
  AO21x1_ASAP7_75t_R  g347(.A1(G44), .A2(new_n428_), .B(new_n433_), .Y(new_n434_));
  AO21x1_ASAP7_75t_R  g348(.A1(new_n115_), .A2(new_n434_), .B(new_n431_), .Y(new_n435_));
  NOR2x1_ASAP7_75t_R  g349(.A(new_n117_), .B(new_n283_), .Y(new_n436_));
  INVx1_ASAP7_75t_R   g350(.A(new_n436_), .Y(new_n437_));
  NOR2x1_ASAP7_75t_R  g351(.A(G44), .B(new_n429_), .Y(new_n438_));
  AO21x1_ASAP7_75t_R  g352(.A1(G44), .A2(new_n430_), .B(new_n438_), .Y(new_n439_));
  NAND2x1_ASAP7_75t_R g353(.A(G43), .B(new_n439_), .Y(new_n440_));
  AOI21x1_ASAP7_75t_R g354(.A1(G44), .A2(new_n432_), .B(new_n116_), .Y(new_n441_));
  OA21x2_ASAP7_75t_R  g355(.A1(G43), .A2(new_n441_), .B(new_n440_), .Y(new_n442_));
  NOR2x1_ASAP7_75t_R  g356(.A(new_n436_), .B(new_n442_), .Y(new_n443_));
  AO21x1_ASAP7_75t_R  g357(.A1(new_n435_), .A2(new_n436_), .B(new_n443_), .Y(new_n444_));
  AND2x2_ASAP7_75t_R  g358(.A(new_n413_), .B(new_n444_), .Y(new_n445_));
  AO21x1_ASAP7_75t_R  g359(.A1(new_n414_), .A2(new_n435_), .B(new_n445_), .Y(new_n446_));
  INVx1_ASAP7_75t_R   g360(.A(new_n446_), .Y(new_n447_));
  AND3x1_ASAP7_75t_R  g361(.A(new_n395_), .B(new_n446_), .C(G41), .Y(new_n448_));
  AO21x1_ASAP7_75t_R  g362(.A1(new_n394_), .A2(new_n446_), .B(new_n395_), .Y(new_n449_));
  AO21x1_ASAP7_75t_R  g363(.A1(new_n113_), .A2(new_n449_), .B(new_n448_), .Y(new_n450_));
  AO21x1_ASAP7_75t_R  g364(.A1(G41), .A2(new_n395_), .B(new_n113_), .Y(new_n451_));
  AND2x2_ASAP7_75t_R  g365(.A(new_n114_), .B(new_n451_), .Y(new_n452_));
  AO21x1_ASAP7_75t_R  g366(.A1(G42), .A2(new_n450_), .B(new_n452_), .Y(new_n453_));
  AND3x1_ASAP7_75t_R  g367(.A(new_n113_), .B(new_n395_), .C(G42), .Y(new_n454_));
  AOI21x1_ASAP7_75t_R g368(.A1(new_n114_), .A2(new_n450_), .B(new_n454_), .Y(new_n455_));
  NOR2x1_ASAP7_75t_R  g369(.A(new_n386_), .B(new_n455_), .Y(new_n456_));
  AO21x1_ASAP7_75t_R  g370(.A1(new_n386_), .A2(new_n453_), .B(new_n456_), .Y(G876));
  AO21x1_ASAP7_75t_R  g371(.A1(G45), .A2(new_n282_), .B(new_n414_), .Y(new_n458_));
  INVx1_ASAP7_75t_R   g372(.A(new_n458_), .Y(new_n459_));
  OR3x1_ASAP7_75t_R   g373(.A(G54), .B(new_n230_), .C(new_n422_), .Y(new_n460_));
  INVx1_ASAP7_75t_R   g374(.A(new_n460_), .Y(new_n461_));
  AO21x1_ASAP7_75t_R  g375(.A1(new_n311_), .A2(new_n422_), .B(new_n461_), .Y(new_n462_));
  OR3x1_ASAP7_75t_R   g376(.A(G52), .B(G54), .C(new_n422_), .Y(new_n463_));
  AOI21x1_ASAP7_75t_R g377(.A1(new_n421_), .A2(new_n463_), .B(G44), .Y(new_n464_));
  AOI21x1_ASAP7_75t_R g378(.A1(G44), .A2(new_n462_), .B(new_n464_), .Y(new_n465_));
  AO21x1_ASAP7_75t_R  g379(.A1(G26), .A2(G50), .B(new_n465_), .Y(new_n466_));
  AO21x1_ASAP7_75t_R  g380(.A1(new_n413_), .A2(new_n437_), .B(new_n466_), .Y(new_n467_));
  OR2x4_ASAP7_75t_R   g381(.A(G51), .B(new_n466_), .Y(new_n468_));
  OAI21x1_ASAP7_75t_R g382(.A1(new_n123_), .A2(new_n467_), .B(new_n468_), .Y(new_n469_));
  NOR2x1_ASAP7_75t_R  g383(.A(G53), .B(new_n466_), .Y(new_n470_));
  AND3x1_ASAP7_75t_R  g384(.A(new_n459_), .B(new_n470_), .C(G51), .Y(new_n471_));
  AOI21x1_ASAP7_75t_R g385(.A1(new_n123_), .A2(new_n470_), .B(new_n471_), .Y(new_n472_));
  NOR2x1_ASAP7_75t_R  g386(.A(new_n422_), .B(new_n472_), .Y(new_n473_));
  AO21x1_ASAP7_75t_R  g387(.A1(new_n422_), .A2(new_n469_), .B(new_n473_), .Y(new_n474_));
  OR3x1_ASAP7_75t_R   g388(.A(new_n458_), .B(new_n466_), .C(new_n123_), .Y(new_n475_));
  AOI21x1_ASAP7_75t_R g389(.A1(new_n468_), .A2(new_n475_), .B(new_n421_), .Y(new_n476_));
  AOI21x1_ASAP7_75t_R g390(.A1(new_n421_), .A2(new_n469_), .B(new_n476_), .Y(new_n477_));
  NOR2x1_ASAP7_75t_R  g391(.A(G44), .B(new_n477_), .Y(new_n478_));
  AO21x1_ASAP7_75t_R  g392(.A1(G44), .A2(new_n474_), .B(new_n478_), .Y(G877));
  OR3x1_ASAP7_75t_R   g393(.A(G53), .B(new_n230_), .C(G54), .Y(new_n480_));
  NOR2x1_ASAP7_75t_R  g394(.A(new_n395_), .B(new_n480_), .Y(new_n481_));
  AO21x1_ASAP7_75t_R  g395(.A1(new_n311_), .A2(new_n395_), .B(new_n481_), .Y(new_n482_));
  OR3x1_ASAP7_75t_R   g396(.A(G52), .B(G54), .C(new_n395_), .Y(new_n483_));
  AOI21x1_ASAP7_75t_R g397(.A1(new_n394_), .A2(new_n483_), .B(G41), .Y(new_n484_));
  AOI21x1_ASAP7_75t_R g398(.A1(G41), .A2(new_n482_), .B(new_n484_), .Y(new_n485_));
  OA21x2_ASAP7_75t_R  g399(.A1(new_n122_), .A2(G60), .B(G50), .Y(new_n486_));
  XNOR2x2_ASAP7_75t_R g400(.A(new_n113_), .B(new_n394_), .Y(new_n487_));
  OA21x2_ASAP7_75t_R  g401(.A1(G51), .A2(new_n447_), .B(new_n446_), .Y(new_n488_));
  NOR2x1_ASAP7_75t_R  g402(.A(new_n114_), .B(new_n488_), .Y(new_n489_));
  AO21x1_ASAP7_75t_R  g403(.A1(new_n114_), .A2(new_n123_), .B(new_n489_), .Y(new_n490_));
  NOR2x1_ASAP7_75t_R  g404(.A(G42), .B(new_n488_), .Y(new_n491_));
  OA21x2_ASAP7_75t_R  g405(.A1(G42), .A2(new_n491_), .B(new_n387_), .Y(new_n492_));
  AO21x1_ASAP7_75t_R  g406(.A1(new_n386_), .A2(new_n490_), .B(new_n492_), .Y(new_n493_));
  NAND2x1_ASAP7_75t_R g407(.A(new_n487_), .B(new_n493_), .Y(new_n494_));
  AO21x1_ASAP7_75t_R  g408(.A1(new_n123_), .A2(new_n447_), .B(new_n446_), .Y(new_n495_));
  AO21x1_ASAP7_75t_R  g409(.A1(G42), .A2(new_n495_), .B(new_n114_), .Y(new_n496_));
  AND2x2_ASAP7_75t_R  g410(.A(new_n114_), .B(new_n495_), .Y(new_n497_));
  AO21x1_ASAP7_75t_R  g411(.A1(G42), .A2(new_n123_), .B(new_n497_), .Y(new_n498_));
  AND2x2_ASAP7_75t_R  g412(.A(new_n387_), .B(new_n498_), .Y(new_n499_));
  AOI21x1_ASAP7_75t_R g413(.A1(new_n386_), .A2(new_n496_), .B(new_n499_), .Y(new_n500_));
  OA21x2_ASAP7_75t_R  g414(.A1(new_n487_), .A2(new_n500_), .B(new_n494_), .Y(new_n501_));
  OR3x1_ASAP7_75t_R   g415(.A(new_n485_), .B(new_n486_), .C(new_n501_), .Y(new_n502_));
  INVx1_ASAP7_75t_R   g416(.A(new_n502_), .Y(G878));
  OR3x1_ASAP7_75t_R   g417(.A(G53), .B(G54), .C(new_n386_), .Y(new_n504_));
  OAI21x1_ASAP7_75t_R g418(.A1(G52), .A2(new_n387_), .B(new_n504_), .Y(new_n505_));
  OR3x1_ASAP7_75t_R   g419(.A(G52), .B(G54), .C(new_n386_), .Y(new_n506_));
  AOI21x1_ASAP7_75t_R g420(.A1(new_n387_), .A2(new_n506_), .B(G42), .Y(new_n507_));
  AOI21x1_ASAP7_75t_R g421(.A1(G42), .A2(new_n505_), .B(new_n507_), .Y(new_n508_));
  AO21x1_ASAP7_75t_R  g422(.A1(G24), .A2(G50), .B(new_n508_), .Y(new_n509_));
  AND3x1_ASAP7_75t_R  g423(.A(new_n123_), .B(new_n231_), .C(new_n446_), .Y(new_n510_));
  AO21x1_ASAP7_75t_R  g424(.A1(new_n231_), .A2(new_n447_), .B(new_n510_), .Y(new_n511_));
  AND3x1_ASAP7_75t_R  g425(.A(new_n123_), .B(new_n231_), .C(new_n447_), .Y(new_n512_));
  AO21x1_ASAP7_75t_R  g426(.A1(new_n231_), .A2(new_n446_), .B(new_n512_), .Y(new_n513_));
  AND2x2_ASAP7_75t_R  g427(.A(new_n387_), .B(new_n513_), .Y(new_n514_));
  AO21x1_ASAP7_75t_R  g428(.A1(new_n386_), .A2(new_n511_), .B(new_n514_), .Y(new_n515_));
  NAND2x1_ASAP7_75t_R g429(.A(G42), .B(new_n515_), .Y(new_n516_));
  NAND2x1_ASAP7_75t_R g430(.A(new_n386_), .B(new_n495_), .Y(new_n517_));
  OA21x2_ASAP7_75t_R  g431(.A1(new_n386_), .A2(new_n488_), .B(new_n517_), .Y(new_n518_));
  OA21x2_ASAP7_75t_R  g432(.A1(G42), .A2(new_n518_), .B(new_n516_), .Y(new_n519_));
  NOR2x1_ASAP7_75t_R  g433(.A(new_n509_), .B(new_n519_), .Y(G879));
  AND3x1_ASAP7_75t_R  g434(.A(new_n115_), .B(new_n428_), .C(new_n230_), .Y(new_n521_));
  AO21x1_ASAP7_75t_R  g435(.A1(new_n231_), .A2(new_n428_), .B(new_n521_), .Y(new_n522_));
  NAND2x1_ASAP7_75t_R g436(.A(G54), .B(new_n522_), .Y(new_n523_));
  AO21x1_ASAP7_75t_R  g437(.A1(new_n125_), .A2(new_n429_), .B(new_n428_), .Y(new_n524_));
  AO21x1_ASAP7_75t_R  g438(.A1(G43), .A2(new_n524_), .B(new_n115_), .Y(new_n525_));
  AND2x2_ASAP7_75t_R  g439(.A(new_n231_), .B(new_n525_), .Y(new_n526_));
  AOI21x1_ASAP7_75t_R g440(.A1(new_n115_), .A2(new_n230_), .B(new_n526_), .Y(new_n527_));
  OA21x2_ASAP7_75t_R  g441(.A1(G54), .A2(new_n527_), .B(new_n523_), .Y(new_n528_));
  AO21x1_ASAP7_75t_R  g442(.A1(G25), .A2(G50), .B(new_n528_), .Y(new_n529_));
  AND3x1_ASAP7_75t_R  g443(.A(new_n116_), .B(new_n422_), .C(new_n414_), .Y(new_n530_));
  AND3x1_ASAP7_75t_R  g444(.A(new_n116_), .B(new_n422_), .C(new_n436_), .Y(new_n531_));
  AO21x1_ASAP7_75t_R  g445(.A1(G44), .A2(new_n422_), .B(new_n116_), .Y(new_n532_));
  AO21x1_ASAP7_75t_R  g446(.A1(new_n437_), .A2(new_n532_), .B(new_n531_), .Y(new_n533_));
  AO21x1_ASAP7_75t_R  g447(.A1(new_n413_), .A2(new_n533_), .B(new_n530_), .Y(new_n534_));
  INVx1_ASAP7_75t_R   g448(.A(new_n534_), .Y(new_n535_));
  AND3x1_ASAP7_75t_R  g449(.A(new_n123_), .B(new_n124_), .C(new_n534_), .Y(new_n536_));
  AO21x1_ASAP7_75t_R  g450(.A1(new_n124_), .A2(new_n535_), .B(new_n536_), .Y(new_n537_));
  AO21x1_ASAP7_75t_R  g451(.A1(new_n123_), .A2(new_n535_), .B(new_n534_), .Y(new_n538_));
  AND2x2_ASAP7_75t_R  g452(.A(new_n429_), .B(new_n538_), .Y(new_n539_));
  AO21x1_ASAP7_75t_R  g453(.A1(new_n428_), .A2(new_n537_), .B(new_n539_), .Y(new_n540_));
  NAND2x1_ASAP7_75t_R g454(.A(G43), .B(new_n540_), .Y(new_n541_));
  AND2x2_ASAP7_75t_R  g455(.A(new_n429_), .B(new_n537_), .Y(new_n542_));
  AOI21x1_ASAP7_75t_R g456(.A1(new_n428_), .A2(new_n538_), .B(new_n542_), .Y(new_n543_));
  OA21x2_ASAP7_75t_R  g457(.A1(G43), .A2(new_n543_), .B(new_n541_), .Y(new_n544_));
  NOR2x1_ASAP7_75t_R  g458(.A(new_n529_), .B(new_n544_), .Y(G880));
endmodule


