// Benchmark "/home/flynn/workplace/MIGBalance/results_v2/eqmap_lut6_adapter_3in_20261007/c880/eqmap_lut_amap/stage" written by ABC on Wed Oct  7 16:33:14 2026

module \/home/flynn/workplace/MIGBalance/results_v2/eqmap_lut6_adapter_3in_20261007/c880/eqmap_lut_amap/stage  ( 
    G1, G10, G11, G12, G13, G14, G15, G16, G17, G18, G19, G2, G20, G21,
    G22, G23, G24, G25, G26, G27, G28, G29, G3, G30, G31, G32, G33, G34,
    G35, G36, G37, G38, G39, G4, G40, G41, G42, G43, G44, G45, G46, G47,
    G48, G49, G5, G50, G51, G52, G53, G54, G55, G56, G57, G58, G59, G6,
    G60, G7, G8, G9,
    G855, G856, G857, G858, G859, G860, G861, G862, G863, G864, G865, G866,
    G867, G868, G869, G870, G871, G872, G873, G874, G875, G876, G877, G878,
    G879, G880  );
  input  G1, G10, G11, G12, G13, G14, G15, G16, G17, G18, G19, G2, G20,
    G21, G22, G23, G24, G25, G26, G27, G28, G29, G3, G30, G31, G32, G33,
    G34, G35, G36, G37, G38, G39, G4, G40, G41, G42, G43, G44, G45, G46,
    G47, G48, G49, G5, G50, G51, G52, G53, G54, G55, G56, G57, G58, G59,
    G6, G60, G7, G8, G9;
  output G855, G856, G857, G858, G859, G860, G861, G862, G863, G864, G865,
    G866, G867, G868, G869, G870, G871, G872, G873, G874, G875, G876, G877,
    G878, G879, G880;
  wire new_n87_, new_n88_, new_n89_, new_n90_, new_n91_, new_n92_, new_n93_,
    new_n94_, new_n95_, new_n96_, new_n97_, new_n98_, new_n99_, new_n100_,
    new_n101_, new_n102_, new_n103_, new_n104_, new_n105_, new_n106_,
    new_n107_, new_n108_, new_n109_, new_n110_, new_n111_, new_n112_,
    new_n113_, new_n114_, new_n115_, new_n116_, new_n117_, new_n118_,
    new_n119_, new_n120_, new_n121_, new_n122_, new_n123_, new_n124_,
    new_n125_, new_n126_, new_n127_, new_n128_, new_n129_, new_n130_,
    new_n131_, new_n132_, new_n134_, new_n136_, new_n139_, new_n140_,
    new_n142_, new_n143_, new_n148_, new_n150_, new_n152_, new_n154_,
    new_n155_, new_n156_, new_n157_, new_n158_, new_n160_, new_n161_,
    new_n162_, new_n163_, new_n164_, new_n167_, new_n168_, new_n169_,
    new_n170_, new_n171_, new_n172_, new_n173_, new_n174_, new_n175_,
    new_n176_, new_n177_, new_n178_, new_n179_, new_n180_, new_n181_,
    new_n182_, new_n183_, new_n184_, new_n185_, new_n186_, new_n187_,
    new_n188_, new_n189_, new_n190_, new_n191_, new_n192_, new_n193_,
    new_n194_, new_n195_, new_n196_, new_n197_, new_n198_, new_n200_,
    new_n201_, new_n202_, new_n203_, new_n204_, new_n205_, new_n206_,
    new_n207_, new_n208_, new_n209_, new_n210_, new_n211_, new_n212_,
    new_n213_, new_n214_, new_n215_, new_n216_, new_n217_, new_n218_,
    new_n219_, new_n220_, new_n221_, new_n222_, new_n223_, new_n225_,
    new_n226_, new_n227_, new_n228_, new_n229_, new_n230_, new_n231_,
    new_n232_, new_n233_, new_n234_, new_n235_, new_n236_, new_n237_,
    new_n238_, new_n239_, new_n240_, new_n241_, new_n242_, new_n243_,
    new_n244_, new_n245_, new_n246_, new_n247_, new_n248_, new_n249_,
    new_n250_, new_n251_, new_n252_, new_n253_, new_n254_, new_n255_,
    new_n256_, new_n257_, new_n258_, new_n259_, new_n260_, new_n261_,
    new_n262_, new_n263_, new_n264_, new_n265_, new_n266_, new_n267_,
    new_n268_, new_n269_, new_n270_, new_n271_, new_n272_, new_n273_,
    new_n274_, new_n275_, new_n277_, new_n278_, new_n279_, new_n280_,
    new_n281_, new_n282_, new_n283_, new_n284_, new_n285_, new_n286_,
    new_n287_, new_n288_, new_n289_, new_n290_, new_n291_, new_n292_,
    new_n293_, new_n294_, new_n295_, new_n296_, new_n297_, new_n298_,
    new_n299_, new_n300_, new_n301_, new_n302_, new_n303_, new_n304_,
    new_n305_, new_n306_, new_n307_, new_n308_, new_n309_, new_n310_,
    new_n311_, new_n312_, new_n313_, new_n314_, new_n315_, new_n316_,
    new_n317_, new_n318_, new_n319_, new_n320_, new_n321_, new_n322_,
    new_n323_, new_n324_, new_n325_, new_n326_, new_n327_, new_n328_,
    new_n329_, new_n330_, new_n331_, new_n332_, new_n333_, new_n334_,
    new_n335_, new_n336_, new_n337_, new_n338_, new_n340_, new_n341_,
    new_n342_, new_n343_, new_n344_, new_n345_, new_n346_, new_n347_,
    new_n348_, new_n349_, new_n350_, new_n351_, new_n352_, new_n353_,
    new_n354_, new_n355_, new_n356_, new_n357_, new_n358_, new_n360_,
    new_n361_, new_n362_, new_n363_, new_n364_, new_n365_, new_n366_,
    new_n367_, new_n368_, new_n369_, new_n370_, new_n371_, new_n372_,
    new_n373_, new_n374_, new_n375_, new_n376_, new_n377_, new_n378_,
    new_n380_, new_n381_, new_n382_, new_n383_, new_n384_, new_n385_,
    new_n386_, new_n387_, new_n388_, new_n389_, new_n390_, new_n391_,
    new_n392_, new_n393_, new_n394_, new_n395_, new_n396_, new_n397_,
    new_n398_, new_n399_, new_n400_, new_n401_, new_n402_, new_n403_,
    new_n404_, new_n405_, new_n406_, new_n407_, new_n408_, new_n409_,
    new_n410_, new_n411_, new_n412_, new_n413_, new_n414_, new_n415_,
    new_n416_, new_n417_, new_n418_, new_n419_, new_n420_, new_n421_,
    new_n422_, new_n423_, new_n424_, new_n425_, new_n426_, new_n427_,
    new_n428_, new_n429_, new_n430_, new_n431_, new_n432_, new_n433_,
    new_n434_, new_n435_, new_n436_, new_n437_, new_n438_, new_n439_,
    new_n440_, new_n441_, new_n442_, new_n443_, new_n444_, new_n445_,
    new_n446_, new_n447_, new_n448_, new_n449_, new_n450_, new_n451_,
    new_n452_, new_n453_, new_n454_, new_n455_, new_n456_, new_n457_,
    new_n458_, new_n459_, new_n460_, new_n461_, new_n462_, new_n463_,
    new_n464_, new_n465_, new_n467_, new_n468_, new_n469_, new_n470_,
    new_n471_, new_n472_, new_n473_, new_n474_, new_n475_, new_n476_,
    new_n477_, new_n478_, new_n479_, new_n480_, new_n481_, new_n482_,
    new_n483_, new_n484_, new_n485_, new_n486_, new_n487_, new_n488_,
    new_n490_, new_n491_, new_n492_, new_n493_, new_n494_, new_n495_,
    new_n496_, new_n497_, new_n498_, new_n499_, new_n500_, new_n501_,
    new_n502_, new_n503_, new_n504_, new_n505_, new_n506_, new_n507_,
    new_n508_, new_n509_, new_n510_, new_n511_, new_n512_, new_n513_,
    new_n515_, new_n516_, new_n517_, new_n518_, new_n519_, new_n520_,
    new_n521_, new_n522_, new_n523_, new_n524_, new_n525_, new_n526_,
    new_n527_, new_n528_, new_n529_, new_n530_, new_n532_, new_n533_,
    new_n534_, new_n535_, new_n536_, new_n537_, new_n538_, new_n539_,
    new_n540_, new_n541_, new_n542_, new_n543_, new_n544_, new_n545_,
    new_n546_, new_n547_, new_n548_, new_n549_, new_n550_, new_n551_,
    new_n552_, new_n553_, new_n554_, new_n555_;
  INVx1_ASAP7_75t_R   g000(.A(G1), .Y(new_n87_));
  INVx1_ASAP7_75t_R   g001(.A(G10), .Y(new_n88_));
  INVx1_ASAP7_75t_R   g002(.A(G11), .Y(new_n89_));
  INVx1_ASAP7_75t_R   g003(.A(G12), .Y(new_n90_));
  INVx1_ASAP7_75t_R   g004(.A(G16), .Y(new_n91_));
  INVx1_ASAP7_75t_R   g005(.A(G17), .Y(new_n92_));
  INVx1_ASAP7_75t_R   g006(.A(G18), .Y(new_n93_));
  INVx1_ASAP7_75t_R   g007(.A(G2), .Y(new_n94_));
  INVx1_ASAP7_75t_R   g008(.A(G22), .Y(new_n95_));
  INVx1_ASAP7_75t_R   g009(.A(G23), .Y(new_n96_));
  INVx1_ASAP7_75t_R   g010(.A(G27), .Y(new_n97_));
  INVx1_ASAP7_75t_R   g011(.A(G28), .Y(new_n98_));
  INVx1_ASAP7_75t_R   g012(.A(G29), .Y(new_n99_));
  INVx1_ASAP7_75t_R   g013(.A(G3), .Y(new_n100_));
  INVx1_ASAP7_75t_R   g014(.A(G30), .Y(new_n101_));
  INVx1_ASAP7_75t_R   g015(.A(G31), .Y(new_n102_));
  INVx1_ASAP7_75t_R   g016(.A(G32), .Y(new_n103_));
  INVx1_ASAP7_75t_R   g017(.A(G34), .Y(new_n104_));
  INVx1_ASAP7_75t_R   g018(.A(G35), .Y(new_n105_));
  INVx1_ASAP7_75t_R   g019(.A(G36), .Y(new_n106_));
  INVx1_ASAP7_75t_R   g020(.A(G37), .Y(new_n107_));
  INVx1_ASAP7_75t_R   g021(.A(G39), .Y(new_n108_));
  INVx1_ASAP7_75t_R   g022(.A(G4), .Y(new_n109_));
  INVx1_ASAP7_75t_R   g023(.A(G40), .Y(new_n110_));
  INVx1_ASAP7_75t_R   g024(.A(G41), .Y(new_n111_));
  INVx1_ASAP7_75t_R   g025(.A(G42), .Y(new_n112_));
  INVx1_ASAP7_75t_R   g026(.A(G43), .Y(new_n113_));
  INVx1_ASAP7_75t_R   g027(.A(G44), .Y(new_n114_));
  INVx1_ASAP7_75t_R   g028(.A(G45), .Y(new_n115_));
  INVx1_ASAP7_75t_R   g029(.A(G46), .Y(new_n116_));
  INVx1_ASAP7_75t_R   g030(.A(G47), .Y(new_n117_));
  INVx1_ASAP7_75t_R   g031(.A(G48), .Y(new_n118_));
  INVx1_ASAP7_75t_R   g032(.A(G5), .Y(new_n119_));
  INVx1_ASAP7_75t_R   g033(.A(G50), .Y(new_n120_));
  INVx1_ASAP7_75t_R   g034(.A(G51), .Y(new_n121_));
  INVx1_ASAP7_75t_R   g035(.A(G52), .Y(new_n122_));
  INVx1_ASAP7_75t_R   g036(.A(G53), .Y(new_n123_));
  INVx1_ASAP7_75t_R   g037(.A(G55), .Y(new_n124_));
  INVx1_ASAP7_75t_R   g038(.A(G56), .Y(new_n125_));
  INVx1_ASAP7_75t_R   g039(.A(G58), .Y(new_n126_));
  INVx1_ASAP7_75t_R   g040(.A(G6), .Y(new_n127_));
  INVx1_ASAP7_75t_R   g041(.A(G60), .Y(new_n128_));
  INVx1_ASAP7_75t_R   g042(.A(G7), .Y(new_n129_));
  INVx1_ASAP7_75t_R   g043(.A(G8), .Y(new_n130_));
  INVx1_ASAP7_75t_R   g044(.A(G9), .Y(new_n131_));
  AO21x1_ASAP7_75t_R  g045(.A1(new_n91_), .A2(G8), .B(new_n130_), .Y(new_n132_));
  AO21x1_ASAP7_75t_R  g046(.A1(G6), .A2(new_n132_), .B(new_n127_), .Y(G855));
  AO21x1_ASAP7_75t_R  g047(.A1(new_n92_), .A2(G6), .B(new_n127_), .Y(new_n134_));
  AO21x1_ASAP7_75t_R  g048(.A1(G7), .A2(new_n134_), .B(new_n129_), .Y(G856));
  AO21x1_ASAP7_75t_R  g049(.A1(G6), .A2(new_n130_), .B(new_n127_), .Y(new_n136_));
  AO21x1_ASAP7_75t_R  g050(.A1(G7), .A2(new_n136_), .B(new_n129_), .Y(G857));
  OAI21x1_ASAP7_75t_R g051(.A1(new_n93_), .A2(G19), .B(G18), .Y(G858));
  AO21x1_ASAP7_75t_R  g052(.A1(new_n94_), .A2(G4), .B(new_n109_), .Y(new_n139_));
  AO21x1_ASAP7_75t_R  g053(.A1(G1), .A2(new_n139_), .B(new_n87_), .Y(new_n140_));
  AO21x1_ASAP7_75t_R  g054(.A1(G3), .A2(new_n140_), .B(new_n100_), .Y(G859));
  OR3x1_ASAP7_75t_R   g055(.A(new_n87_), .B(new_n109_), .C(new_n100_), .Y(new_n142_));
  INVx1_ASAP7_75t_R   g056(.A(new_n142_), .Y(new_n143_));
  AND3x1_ASAP7_75t_R  g057(.A(G5), .B(new_n143_), .C(G857), .Y(G860));
  AND3x1_ASAP7_75t_R  g058(.A(G11), .B(G17), .C(G16), .Y(G861));
  AND3x1_ASAP7_75t_R  g059(.A(G11), .B(G17), .C(G7), .Y(G862));
  AND3x1_ASAP7_75t_R  g060(.A(G11), .B(G8), .C(G7), .Y(G863));
  NOR2x1_ASAP7_75t_R  g061(.A(G20), .B(G21), .Y(new_n148_));
  AO21x1_ASAP7_75t_R  g062(.A1(G23), .A2(new_n148_), .B(new_n96_), .Y(G864));
  OR3x1_ASAP7_75t_R   g063(.A(new_n119_), .B(new_n142_), .C(G857), .Y(new_n150_));
  INVx1_ASAP7_75t_R   g064(.A(new_n150_), .Y(G865));
  AO21x1_ASAP7_75t_R  g065(.A1(G1), .A2(new_n131_), .B(new_n87_), .Y(new_n152_));
  AO21x1_ASAP7_75t_R  g066(.A1(G5), .A2(new_n152_), .B(new_n119_), .Y(G866));
  INVx1_ASAP7_75t_R   g067(.A(G866), .Y(new_n154_));
  AO21x1_ASAP7_75t_R  g068(.A1(new_n90_), .A2(G2), .B(new_n94_), .Y(new_n155_));
  AO21x1_ASAP7_75t_R  g069(.A1(G10), .A2(new_n155_), .B(new_n88_), .Y(new_n156_));
  AO21x1_ASAP7_75t_R  g070(.A1(G1), .A2(new_n156_), .B(new_n87_), .Y(new_n157_));
  AO21x1_ASAP7_75t_R  g071(.A1(G3), .A2(new_n157_), .B(new_n100_), .Y(new_n158_));
  AO21x1_ASAP7_75t_R  g072(.A1(G6), .A2(new_n158_), .B(new_n127_), .Y(G867));
  NOR2x1_ASAP7_75t_R  g073(.A(new_n88_), .B(new_n94_), .Y(new_n160_));
  AND3x1_ASAP7_75t_R  g074(.A(G1), .B(new_n160_), .C(G3), .Y(new_n161_));
  INVx1_ASAP7_75t_R   g075(.A(new_n161_), .Y(new_n162_));
  OAI21x1_ASAP7_75t_R g076(.A1(G15), .A2(new_n162_), .B(new_n161_), .Y(new_n163_));
  AO21x1_ASAP7_75t_R  g077(.A1(G12), .A2(new_n163_), .B(new_n90_), .Y(new_n164_));
  AO21x1_ASAP7_75t_R  g078(.A1(G11), .A2(new_n164_), .B(new_n89_), .Y(G868));
  AO21x1_ASAP7_75t_R  g079(.A1(G22), .A2(new_n148_), .B(new_n95_), .Y(G869));
  XOR2x2_ASAP7_75t_R  g080(.A(new_n103_), .B(G33), .Y(new_n167_));
  NOR2x1_ASAP7_75t_R  g081(.A(new_n99_), .B(new_n167_), .Y(new_n168_));
  XNOR2x2_ASAP7_75t_R g082(.A(G32), .B(G33), .Y(new_n169_));
  AO21x1_ASAP7_75t_R  g083(.A1(new_n99_), .A2(new_n169_), .B(new_n168_), .Y(new_n170_));
  INVx1_ASAP7_75t_R   g084(.A(new_n170_), .Y(new_n171_));
  NOR2x1_ASAP7_75t_R  g085(.A(G29), .B(new_n167_), .Y(new_n172_));
  AO21x1_ASAP7_75t_R  g086(.A1(G29), .A2(new_n169_), .B(new_n172_), .Y(new_n173_));
  INVx1_ASAP7_75t_R   g087(.A(new_n173_), .Y(new_n174_));
  NOR2x1_ASAP7_75t_R  g088(.A(G26), .B(new_n174_), .Y(new_n175_));
  AO21x1_ASAP7_75t_R  g089(.A1(G26), .A2(new_n170_), .B(new_n175_), .Y(new_n176_));
  INVx1_ASAP7_75t_R   g090(.A(new_n176_), .Y(new_n177_));
  NOR2x1_ASAP7_75t_R  g091(.A(G26), .B(new_n171_), .Y(new_n178_));
  AO21x1_ASAP7_75t_R  g092(.A1(G26), .A2(new_n173_), .B(new_n178_), .Y(new_n179_));
  INVx1_ASAP7_75t_R   g093(.A(new_n179_), .Y(new_n180_));
  NOR2x1_ASAP7_75t_R  g094(.A(G25), .B(new_n180_), .Y(new_n181_));
  AO21x1_ASAP7_75t_R  g095(.A1(G25), .A2(new_n176_), .B(new_n181_), .Y(new_n182_));
  NAND2x1_ASAP7_75t_R g096(.A(G25), .B(new_n179_), .Y(new_n183_));
  OA21x2_ASAP7_75t_R  g097(.A1(G25), .A2(new_n177_), .B(new_n183_), .Y(new_n184_));
  NOR2x1_ASAP7_75t_R  g098(.A(G28), .B(new_n184_), .Y(new_n185_));
  AO21x1_ASAP7_75t_R  g099(.A1(G28), .A2(new_n182_), .B(new_n185_), .Y(new_n186_));
  XNOR2x2_ASAP7_75t_R g100(.A(G24), .B(new_n186_), .Y(new_n187_));
  NOR2x1_ASAP7_75t_R  g101(.A(new_n97_), .B(new_n187_), .Y(new_n188_));
  XNOR2x2_ASAP7_75t_R g102(.A(G24), .B(new_n186_), .Y(new_n189_));
  AO21x1_ASAP7_75t_R  g103(.A1(new_n97_), .A2(new_n189_), .B(new_n188_), .Y(new_n190_));
  NOR2x1_ASAP7_75t_R  g104(.A(G27), .B(new_n187_), .Y(new_n191_));
  AO21x1_ASAP7_75t_R  g105(.A1(G27), .A2(new_n189_), .B(new_n191_), .Y(new_n192_));
  AND2x2_ASAP7_75t_R  g106(.A(new_n101_), .B(new_n192_), .Y(new_n193_));
  AO21x1_ASAP7_75t_R  g107(.A1(G30), .A2(new_n190_), .B(new_n193_), .Y(new_n194_));
  NAND2x1_ASAP7_75t_R g108(.A(G31), .B(new_n194_), .Y(new_n195_));
  NAND2x1_ASAP7_75t_R g109(.A(G30), .B(new_n192_), .Y(new_n196_));
  NAND2x1_ASAP7_75t_R g110(.A(new_n101_), .B(new_n190_), .Y(new_n197_));
  AO21x1_ASAP7_75t_R  g111(.A1(new_n196_), .A2(new_n197_), .B(G31), .Y(new_n198_));
  NAND2x1_ASAP7_75t_R g112(.A(new_n195_), .B(new_n198_), .Y(G870));
  XNOR2x2_ASAP7_75t_R g113(.A(new_n113_), .B(G44), .Y(new_n200_));
  XOR2x2_ASAP7_75t_R  g114(.A(new_n113_), .B(new_n114_), .Y(new_n201_));
  NOR2x1_ASAP7_75t_R  g115(.A(G48), .B(new_n201_), .Y(new_n202_));
  AO21x1_ASAP7_75t_R  g116(.A1(G48), .A2(new_n200_), .B(new_n202_), .Y(new_n203_));
  NOR2x1_ASAP7_75t_R  g117(.A(new_n118_), .B(new_n201_), .Y(new_n204_));
  AO21x1_ASAP7_75t_R  g118(.A1(new_n118_), .A2(new_n200_), .B(new_n204_), .Y(new_n205_));
  AND2x2_ASAP7_75t_R  g119(.A(new_n117_), .B(new_n205_), .Y(new_n206_));
  AO21x1_ASAP7_75t_R  g120(.A1(G47), .A2(new_n203_), .B(new_n206_), .Y(new_n207_));
  XNOR2x2_ASAP7_75t_R g121(.A(new_n103_), .B(new_n207_), .Y(new_n208_));
  XOR2x2_ASAP7_75t_R  g122(.A(G32), .B(new_n207_), .Y(new_n209_));
  NOR2x1_ASAP7_75t_R  g123(.A(G41), .B(new_n209_), .Y(new_n210_));
  AO21x1_ASAP7_75t_R  g124(.A1(G41), .A2(new_n208_), .B(new_n210_), .Y(new_n211_));
  NOR2x1_ASAP7_75t_R  g125(.A(new_n111_), .B(new_n209_), .Y(new_n212_));
  AO21x1_ASAP7_75t_R  g126(.A1(new_n111_), .A2(new_n208_), .B(new_n212_), .Y(new_n213_));
  AND2x2_ASAP7_75t_R  g127(.A(new_n112_), .B(new_n213_), .Y(new_n214_));
  AO21x1_ASAP7_75t_R  g128(.A1(G42), .A2(new_n211_), .B(new_n214_), .Y(new_n215_));
  XOR2x2_ASAP7_75t_R  g129(.A(G49), .B(new_n215_), .Y(new_n216_));
  NOR2x1_ASAP7_75t_R  g130(.A(new_n116_), .B(new_n216_), .Y(new_n217_));
  XOR2x2_ASAP7_75t_R  g131(.A(G49), .B(new_n215_), .Y(new_n218_));
  AO21x1_ASAP7_75t_R  g132(.A1(new_n116_), .A2(new_n218_), .B(new_n217_), .Y(new_n219_));
  NAND2x1_ASAP7_75t_R g133(.A(G45), .B(new_n219_), .Y(new_n220_));
  NAND2x1_ASAP7_75t_R g134(.A(G46), .B(new_n218_), .Y(new_n221_));
  OA21x2_ASAP7_75t_R  g135(.A1(G46), .A2(new_n216_), .B(new_n221_), .Y(new_n222_));
  OR2x4_ASAP7_75t_R   g136(.A(G45), .B(new_n222_), .Y(new_n223_));
  NAND2x1_ASAP7_75t_R g137(.A(new_n220_), .B(new_n223_), .Y(G871));
  OAI21x1_ASAP7_75t_R g138(.A1(new_n124_), .A2(G59), .B(G55), .Y(new_n225_));
  AND3x1_ASAP7_75t_R  g139(.A(new_n120_), .B(new_n225_), .C(G30), .Y(new_n226_));
  AOI21x1_ASAP7_75t_R g140(.A1(new_n101_), .A2(new_n225_), .B(new_n226_), .Y(new_n227_));
  AND2x2_ASAP7_75t_R  g141(.A(G13), .B(new_n161_), .Y(new_n228_));
  AND3x1_ASAP7_75t_R  g142(.A(G12), .B(new_n228_), .C(G14), .Y(new_n229_));
  AND3x1_ASAP7_75t_R  g143(.A(G11), .B(new_n229_), .C(G8), .Y(new_n230_));
  INVx1_ASAP7_75t_R   g144(.A(new_n230_), .Y(new_n231_));
  NAND2x1_ASAP7_75t_R g145(.A(new_n128_), .B(new_n154_), .Y(new_n232_));
  OR3x1_ASAP7_75t_R   g146(.A(new_n88_), .B(new_n232_), .C(new_n92_), .Y(new_n233_));
  OR3x1_ASAP7_75t_R   g147(.A(new_n91_), .B(new_n233_), .C(new_n127_), .Y(new_n234_));
  INVx1_ASAP7_75t_R   g148(.A(new_n234_), .Y(new_n235_));
  OR3x1_ASAP7_75t_R   g149(.A(G4), .B(new_n110_), .C(new_n130_), .Y(new_n236_));
  OR3x1_ASAP7_75t_R   g150(.A(new_n109_), .B(new_n110_), .C(G8), .Y(new_n237_));
  AO21x1_ASAP7_75t_R  g151(.A1(new_n236_), .A2(new_n237_), .B(new_n89_), .Y(new_n238_));
  INVx1_ASAP7_75t_R   g152(.A(new_n238_), .Y(new_n239_));
  OR3x1_ASAP7_75t_R   g153(.A(new_n94_), .B(new_n131_), .C(new_n109_), .Y(new_n240_));
  OR2x4_ASAP7_75t_R   g154(.A(new_n87_), .B(new_n240_), .Y(new_n241_));
  NOR2x1_ASAP7_75t_R  g155(.A(new_n89_), .B(new_n91_), .Y(new_n242_));
  AO21x1_ASAP7_75t_R  g156(.A1(G8), .A2(new_n242_), .B(new_n241_), .Y(new_n243_));
  NOR2x1_ASAP7_75t_R  g157(.A(new_n154_), .B(new_n243_), .Y(new_n244_));
  OAI21x1_ASAP7_75t_R g158(.A1(new_n154_), .A2(new_n244_), .B(new_n239_), .Y(new_n245_));
  OA21x2_ASAP7_75t_R  g159(.A1(new_n239_), .A2(new_n243_), .B(new_n245_), .Y(new_n246_));
  NOR2x1_ASAP7_75t_R  g160(.A(new_n102_), .B(new_n246_), .Y(new_n247_));
  AO21x1_ASAP7_75t_R  g161(.A1(G40), .A2(G9), .B(new_n131_), .Y(new_n248_));
  NOR2x1_ASAP7_75t_R  g162(.A(G11), .B(G9), .Y(new_n249_));
  AO21x1_ASAP7_75t_R  g163(.A1(G11), .A2(new_n248_), .B(new_n249_), .Y(new_n250_));
  AOI21x1_ASAP7_75t_R g164(.A1(G4), .A2(new_n250_), .B(new_n109_), .Y(new_n251_));
  OR3x1_ASAP7_75t_R   g165(.A(new_n87_), .B(new_n251_), .C(new_n119_), .Y(new_n252_));
  OA21x2_ASAP7_75t_R  g166(.A1(new_n87_), .A2(G5), .B(new_n252_), .Y(new_n253_));
  INVx1_ASAP7_75t_R   g167(.A(new_n253_), .Y(new_n254_));
  OA21x2_ASAP7_75t_R  g168(.A1(G39), .A2(new_n254_), .B(new_n253_), .Y(new_n255_));
  OR3x1_ASAP7_75t_R   g169(.A(new_n247_), .B(new_n255_), .C(new_n235_), .Y(new_n256_));
  INVx1_ASAP7_75t_R   g170(.A(new_n256_), .Y(new_n257_));
  AND3x1_ASAP7_75t_R  g171(.A(new_n118_), .B(new_n257_), .C(new_n230_), .Y(new_n258_));
  AO21x1_ASAP7_75t_R  g172(.A1(new_n231_), .A2(new_n257_), .B(new_n258_), .Y(new_n259_));
  NAND2x1_ASAP7_75t_R g173(.A(G54), .B(new_n259_), .Y(new_n260_));
  AO21x1_ASAP7_75t_R  g174(.A1(new_n123_), .A2(new_n256_), .B(new_n257_), .Y(new_n261_));
  AO21x1_ASAP7_75t_R  g175(.A1(G48), .A2(new_n261_), .B(new_n118_), .Y(new_n262_));
  AND2x2_ASAP7_75t_R  g176(.A(new_n231_), .B(new_n262_), .Y(new_n263_));
  AOI21x1_ASAP7_75t_R g177(.A1(new_n118_), .A2(new_n230_), .B(new_n263_), .Y(new_n264_));
  OA21x2_ASAP7_75t_R  g178(.A1(G54), .A2(new_n264_), .B(new_n260_), .Y(new_n265_));
  AND3x1_ASAP7_75t_R  g179(.A(new_n121_), .B(new_n122_), .C(new_n126_), .Y(new_n266_));
  AO21x1_ASAP7_75t_R  g180(.A1(new_n122_), .A2(G58), .B(new_n266_), .Y(new_n267_));
  AO21x1_ASAP7_75t_R  g181(.A1(new_n121_), .A2(G58), .B(new_n126_), .Y(new_n268_));
  AND2x2_ASAP7_75t_R  g182(.A(new_n256_), .B(new_n268_), .Y(new_n269_));
  AO21x1_ASAP7_75t_R  g183(.A1(new_n257_), .A2(new_n267_), .B(new_n269_), .Y(new_n270_));
  NAND2x1_ASAP7_75t_R g184(.A(G48), .B(new_n270_), .Y(new_n271_));
  AND2x2_ASAP7_75t_R  g185(.A(new_n256_), .B(new_n267_), .Y(new_n272_));
  AOI21x1_ASAP7_75t_R g186(.A1(new_n257_), .A2(new_n268_), .B(new_n272_), .Y(new_n273_));
  OA21x2_ASAP7_75t_R  g187(.A1(G48), .A2(new_n273_), .B(new_n271_), .Y(new_n274_));
  OR3x1_ASAP7_75t_R   g188(.A(new_n227_), .B(new_n265_), .C(new_n274_), .Y(new_n275_));
  INVx1_ASAP7_75t_R   g189(.A(new_n275_), .Y(G872));
  AO21x1_ASAP7_75t_R  g190(.A1(new_n154_), .A2(new_n238_), .B(G866), .Y(new_n277_));
  AND3x1_ASAP7_75t_R  g191(.A(new_n238_), .B(new_n241_), .C(new_n154_), .Y(new_n278_));
  AOI21x1_ASAP7_75t_R g192(.A1(G866), .A2(new_n241_), .B(new_n278_), .Y(new_n279_));
  NOR2x1_ASAP7_75t_R  g193(.A(G11), .B(new_n279_), .Y(new_n280_));
  AO21x1_ASAP7_75t_R  g194(.A1(G11), .A2(new_n277_), .B(new_n280_), .Y(new_n281_));
  NOR2x1_ASAP7_75t_R  g195(.A(G16), .B(new_n279_), .Y(new_n282_));
  AO21x1_ASAP7_75t_R  g196(.A1(G16), .A2(new_n281_), .B(new_n282_), .Y(new_n283_));
  NOR2x1_ASAP7_75t_R  g197(.A(G8), .B(new_n279_), .Y(new_n284_));
  AO21x1_ASAP7_75t_R  g198(.A1(G8), .A2(new_n283_), .B(new_n284_), .Y(new_n285_));
  INVx1_ASAP7_75t_R   g199(.A(new_n285_), .Y(new_n286_));
  AO21x1_ASAP7_75t_R  g200(.A1(G28), .A2(new_n285_), .B(new_n98_), .Y(new_n287_));
  AND3x1_ASAP7_75t_R  g201(.A(new_n105_), .B(new_n287_), .C(new_n253_), .Y(new_n288_));
  AOI21x1_ASAP7_75t_R g202(.A1(new_n254_), .A2(new_n287_), .B(new_n288_), .Y(new_n289_));
  NOR2x1_ASAP7_75t_R  g203(.A(new_n235_), .B(new_n289_), .Y(new_n290_));
  INVx1_ASAP7_75t_R   g204(.A(new_n290_), .Y(new_n291_));
  AO21x1_ASAP7_75t_R  g205(.A1(G29), .A2(new_n285_), .B(new_n99_), .Y(new_n292_));
  AND3x1_ASAP7_75t_R  g206(.A(new_n106_), .B(new_n292_), .C(new_n253_), .Y(new_n293_));
  AOI21x1_ASAP7_75t_R g207(.A1(new_n254_), .A2(new_n292_), .B(new_n293_), .Y(new_n294_));
  NOR2x1_ASAP7_75t_R  g208(.A(new_n235_), .B(new_n294_), .Y(new_n295_));
  INVx1_ASAP7_75t_R   g209(.A(new_n295_), .Y(new_n296_));
  AO21x1_ASAP7_75t_R  g210(.A1(G48), .A2(new_n126_), .B(G58), .Y(new_n297_));
  NAND2x1_ASAP7_75t_R g211(.A(G39), .B(new_n253_), .Y(new_n298_));
  OR3x1_ASAP7_75t_R   g212(.A(new_n108_), .B(new_n254_), .C(G48), .Y(new_n299_));
  AO21x1_ASAP7_75t_R  g213(.A1(new_n118_), .A2(new_n299_), .B(new_n126_), .Y(new_n300_));
  OR3x1_ASAP7_75t_R   g214(.A(new_n118_), .B(new_n298_), .C(G58), .Y(new_n301_));
  AOI21x1_ASAP7_75t_R g215(.A1(new_n300_), .A2(new_n301_), .B(new_n247_), .Y(new_n302_));
  AOI21x1_ASAP7_75t_R g216(.A1(new_n247_), .A2(new_n297_), .B(new_n302_), .Y(new_n303_));
  NOR2x1_ASAP7_75t_R  g217(.A(new_n235_), .B(new_n303_), .Y(new_n304_));
  AO21x1_ASAP7_75t_R  g218(.A1(new_n235_), .A2(new_n297_), .B(new_n304_), .Y(new_n305_));
  INVx1_ASAP7_75t_R   g219(.A(new_n305_), .Y(new_n306_));
  AO21x1_ASAP7_75t_R  g220(.A1(G30), .A2(new_n285_), .B(new_n101_), .Y(new_n307_));
  AND3x1_ASAP7_75t_R  g221(.A(new_n107_), .B(new_n307_), .C(new_n253_), .Y(new_n308_));
  AOI21x1_ASAP7_75t_R g222(.A1(new_n254_), .A2(new_n307_), .B(new_n308_), .Y(new_n309_));
  NOR2x1_ASAP7_75t_R  g223(.A(new_n235_), .B(new_n309_), .Y(new_n310_));
  INVx1_ASAP7_75t_R   g224(.A(new_n310_), .Y(new_n311_));
  AND3x1_ASAP7_75t_R  g225(.A(new_n306_), .B(new_n310_), .C(G47), .Y(new_n312_));
  AO21x1_ASAP7_75t_R  g226(.A1(new_n305_), .A2(new_n310_), .B(new_n306_), .Y(new_n313_));
  AO21x1_ASAP7_75t_R  g227(.A1(new_n117_), .A2(new_n313_), .B(new_n312_), .Y(new_n314_));
  INVx1_ASAP7_75t_R   g228(.A(new_n314_), .Y(new_n315_));
  AO21x1_ASAP7_75t_R  g229(.A1(G46), .A2(new_n314_), .B(new_n116_), .Y(new_n316_));
  AND3x1_ASAP7_75t_R  g230(.A(new_n116_), .B(new_n314_), .C(new_n296_), .Y(new_n317_));
  AO21x1_ASAP7_75t_R  g231(.A1(new_n295_), .A2(new_n316_), .B(new_n317_), .Y(new_n318_));
  OR3x1_ASAP7_75t_R   g232(.A(G52), .B(new_n230_), .C(new_n291_), .Y(new_n319_));
  OR3x1_ASAP7_75t_R   g233(.A(G54), .B(new_n230_), .C(new_n290_), .Y(new_n320_));
  AOI21x1_ASAP7_75t_R g234(.A1(new_n319_), .A2(new_n320_), .B(new_n115_), .Y(new_n321_));
  NOR2x1_ASAP7_75t_R  g235(.A(G52), .B(G54), .Y(new_n322_));
  AO21x1_ASAP7_75t_R  g236(.A1(new_n291_), .A2(new_n322_), .B(new_n290_), .Y(new_n323_));
  AOI21x1_ASAP7_75t_R g237(.A1(new_n115_), .A2(new_n323_), .B(new_n321_), .Y(new_n324_));
  AO21x1_ASAP7_75t_R  g238(.A1(G27), .A2(G50), .B(new_n324_), .Y(new_n325_));
  INVx1_ASAP7_75t_R   g239(.A(new_n325_), .Y(new_n326_));
  NOR2x1_ASAP7_75t_R  g240(.A(new_n318_), .B(new_n325_), .Y(new_n327_));
  NOR2x1_ASAP7_75t_R  g241(.A(G51), .B(new_n325_), .Y(new_n328_));
  AO21x1_ASAP7_75t_R  g242(.A1(G51), .A2(new_n327_), .B(new_n328_), .Y(new_n329_));
  NOR2x1_ASAP7_75t_R  g243(.A(G53), .B(new_n325_), .Y(new_n330_));
  AND3x1_ASAP7_75t_R  g244(.A(new_n318_), .B(new_n330_), .C(G51), .Y(new_n331_));
  AOI21x1_ASAP7_75t_R g245(.A1(new_n121_), .A2(new_n330_), .B(new_n331_), .Y(new_n332_));
  NOR2x1_ASAP7_75t_R  g246(.A(new_n290_), .B(new_n332_), .Y(new_n333_));
  AO21x1_ASAP7_75t_R  g247(.A1(new_n290_), .A2(new_n329_), .B(new_n333_), .Y(new_n334_));
  AND3x1_ASAP7_75t_R  g248(.A(new_n318_), .B(new_n326_), .C(G51), .Y(new_n335_));
  OA21x2_ASAP7_75t_R  g249(.A1(new_n328_), .A2(new_n335_), .B(new_n290_), .Y(new_n336_));
  AOI21x1_ASAP7_75t_R g250(.A1(new_n291_), .A2(new_n329_), .B(new_n336_), .Y(new_n337_));
  NOR2x1_ASAP7_75t_R  g251(.A(G45), .B(new_n337_), .Y(new_n338_));
  AO21x1_ASAP7_75t_R  g252(.A1(G45), .A2(new_n334_), .B(new_n338_), .Y(G873));
  AO21x1_ASAP7_75t_R  g253(.A1(new_n124_), .A2(G56), .B(new_n125_), .Y(new_n340_));
  AND3x1_ASAP7_75t_R  g254(.A(new_n231_), .B(new_n340_), .C(G46), .Y(new_n341_));
  AO21x1_ASAP7_75t_R  g255(.A1(new_n116_), .A2(new_n340_), .B(new_n341_), .Y(new_n342_));
  AND3x1_ASAP7_75t_R  g256(.A(new_n120_), .B(new_n342_), .C(G28), .Y(new_n343_));
  AOI21x1_ASAP7_75t_R g257(.A1(new_n98_), .A2(new_n342_), .B(new_n343_), .Y(new_n344_));
  OR3x1_ASAP7_75t_R   g258(.A(G53), .B(G54), .C(new_n295_), .Y(new_n345_));
  OAI21x1_ASAP7_75t_R g259(.A1(G52), .A2(new_n296_), .B(new_n345_), .Y(new_n346_));
  AO21x1_ASAP7_75t_R  g260(.A1(new_n296_), .A2(new_n322_), .B(new_n295_), .Y(new_n347_));
  AND2x2_ASAP7_75t_R  g261(.A(new_n116_), .B(new_n347_), .Y(new_n348_));
  AOI21x1_ASAP7_75t_R g262(.A1(G46), .A2(new_n346_), .B(new_n348_), .Y(new_n349_));
  AO21x1_ASAP7_75t_R  g263(.A1(new_n121_), .A2(new_n314_), .B(new_n315_), .Y(new_n350_));
  AO21x1_ASAP7_75t_R  g264(.A1(new_n121_), .A2(new_n315_), .B(new_n314_), .Y(new_n351_));
  AND2x2_ASAP7_75t_R  g265(.A(new_n116_), .B(new_n351_), .Y(new_n352_));
  AO21x1_ASAP7_75t_R  g266(.A1(G46), .A2(new_n350_), .B(new_n352_), .Y(new_n353_));
  NAND2x1_ASAP7_75t_R g267(.A(new_n295_), .B(new_n353_), .Y(new_n354_));
  AND2x2_ASAP7_75t_R  g268(.A(new_n116_), .B(new_n350_), .Y(new_n355_));
  AOI21x1_ASAP7_75t_R g269(.A1(G46), .A2(new_n351_), .B(new_n355_), .Y(new_n356_));
  OA21x2_ASAP7_75t_R  g270(.A1(new_n295_), .A2(new_n356_), .B(new_n354_), .Y(new_n357_));
  OR3x1_ASAP7_75t_R   g271(.A(new_n344_), .B(new_n349_), .C(new_n357_), .Y(new_n358_));
  INVx1_ASAP7_75t_R   g272(.A(new_n358_), .Y(G874));
  OAI21x1_ASAP7_75t_R g273(.A1(new_n124_), .A2(G57), .B(G55), .Y(new_n360_));
  AND3x1_ASAP7_75t_R  g274(.A(new_n231_), .B(new_n360_), .C(G47), .Y(new_n361_));
  AO21x1_ASAP7_75t_R  g275(.A1(new_n117_), .A2(new_n360_), .B(new_n361_), .Y(new_n362_));
  AND3x1_ASAP7_75t_R  g276(.A(new_n120_), .B(new_n362_), .C(G29), .Y(new_n363_));
  AOI21x1_ASAP7_75t_R g277(.A1(new_n99_), .A2(new_n362_), .B(new_n363_), .Y(new_n364_));
  OR3x1_ASAP7_75t_R   g278(.A(G53), .B(G54), .C(new_n310_), .Y(new_n365_));
  OAI21x1_ASAP7_75t_R g279(.A1(G52), .A2(new_n311_), .B(new_n365_), .Y(new_n366_));
  AO21x1_ASAP7_75t_R  g280(.A1(new_n311_), .A2(new_n322_), .B(new_n310_), .Y(new_n367_));
  AND2x2_ASAP7_75t_R  g281(.A(new_n117_), .B(new_n367_), .Y(new_n368_));
  AOI21x1_ASAP7_75t_R g282(.A1(G47), .A2(new_n366_), .B(new_n368_), .Y(new_n369_));
  AO21x1_ASAP7_75t_R  g283(.A1(new_n121_), .A2(new_n311_), .B(new_n310_), .Y(new_n370_));
  AO21x1_ASAP7_75t_R  g284(.A1(new_n121_), .A2(new_n310_), .B(new_n311_), .Y(new_n371_));
  AND2x2_ASAP7_75t_R  g285(.A(new_n306_), .B(new_n371_), .Y(new_n372_));
  AO21x1_ASAP7_75t_R  g286(.A1(new_n305_), .A2(new_n370_), .B(new_n372_), .Y(new_n373_));
  NAND2x1_ASAP7_75t_R g287(.A(G47), .B(new_n373_), .Y(new_n374_));
  AND2x2_ASAP7_75t_R  g288(.A(new_n306_), .B(new_n370_), .Y(new_n375_));
  AOI21x1_ASAP7_75t_R g289(.A1(new_n305_), .A2(new_n371_), .B(new_n375_), .Y(new_n376_));
  OA21x2_ASAP7_75t_R  g290(.A1(G47), .A2(new_n376_), .B(new_n374_), .Y(new_n377_));
  OR3x1_ASAP7_75t_R   g291(.A(new_n364_), .B(new_n369_), .C(new_n377_), .Y(new_n378_));
  INVx1_ASAP7_75t_R   g292(.A(new_n378_), .Y(G875));
  OR3x1_ASAP7_75t_R   g293(.A(new_n92_), .B(new_n232_), .C(new_n91_), .Y(new_n380_));
  OR3x1_ASAP7_75t_R   g294(.A(new_n109_), .B(new_n380_), .C(new_n127_), .Y(new_n381_));
  INVx1_ASAP7_75t_R   g295(.A(new_n381_), .Y(new_n382_));
  AO21x1_ASAP7_75t_R  g296(.A1(G11), .A2(new_n110_), .B(new_n89_), .Y(new_n383_));
  NAND2x1_ASAP7_75t_R g297(.A(new_n154_), .B(new_n383_), .Y(new_n384_));
  OR3x1_ASAP7_75t_R   g298(.A(new_n106_), .B(new_n384_), .C(new_n88_), .Y(new_n385_));
  INVx1_ASAP7_75t_R   g299(.A(new_n385_), .Y(new_n386_));
  NOR2x1_ASAP7_75t_R  g300(.A(G34), .B(new_n286_), .Y(new_n387_));
  NOR2x1_ASAP7_75t_R  g301(.A(G9), .B(new_n286_), .Y(new_n388_));
  AO21x1_ASAP7_75t_R  g302(.A1(G9), .A2(new_n387_), .B(new_n388_), .Y(new_n389_));
  NAND2x1_ASAP7_75t_R g303(.A(G25), .B(new_n389_), .Y(new_n390_));
  OA21x2_ASAP7_75t_R  g304(.A1(G34), .A2(new_n131_), .B(G9), .Y(new_n391_));
  OA21x2_ASAP7_75t_R  g305(.A1(G25), .A2(new_n391_), .B(new_n390_), .Y(new_n392_));
  OR3x1_ASAP7_75t_R   g306(.A(new_n386_), .B(new_n392_), .C(new_n382_), .Y(new_n393_));
  INVx1_ASAP7_75t_R   g307(.A(new_n393_), .Y(new_n394_));
  OR3x1_ASAP7_75t_R   g308(.A(new_n105_), .B(new_n384_), .C(new_n88_), .Y(new_n395_));
  INVx1_ASAP7_75t_R   g309(.A(new_n395_), .Y(new_n396_));
  NOR2x1_ASAP7_75t_R  g310(.A(G2), .B(new_n286_), .Y(new_n397_));
  AO21x1_ASAP7_75t_R  g311(.A1(G2), .A2(new_n387_), .B(new_n397_), .Y(new_n398_));
  NAND2x1_ASAP7_75t_R g312(.A(G24), .B(new_n398_), .Y(new_n399_));
  OA21x2_ASAP7_75t_R  g313(.A1(new_n94_), .A2(G34), .B(G2), .Y(new_n400_));
  OA21x2_ASAP7_75t_R  g314(.A1(G24), .A2(new_n400_), .B(new_n399_), .Y(new_n401_));
  OR3x1_ASAP7_75t_R   g315(.A(new_n396_), .B(new_n401_), .C(new_n382_), .Y(new_n402_));
  INVx1_ASAP7_75t_R   g316(.A(new_n402_), .Y(new_n403_));
  AND3x1_ASAP7_75t_R  g317(.A(G46), .B(new_n305_), .C(new_n295_), .Y(new_n404_));
  AO21x1_ASAP7_75t_R  g318(.A1(new_n116_), .A2(new_n305_), .B(G46), .Y(new_n405_));
  AO21x1_ASAP7_75t_R  g319(.A1(new_n296_), .A2(new_n405_), .B(new_n404_), .Y(new_n406_));
  AO21x1_ASAP7_75t_R  g320(.A1(G46), .A2(new_n295_), .B(new_n296_), .Y(new_n407_));
  AND2x2_ASAP7_75t_R  g321(.A(new_n311_), .B(new_n407_), .Y(new_n408_));
  AO21x1_ASAP7_75t_R  g322(.A1(new_n310_), .A2(new_n406_), .B(new_n408_), .Y(new_n409_));
  NAND2x1_ASAP7_75t_R g323(.A(G47), .B(new_n409_), .Y(new_n410_));
  AND3x1_ASAP7_75t_R  g324(.A(G46), .B(new_n296_), .C(new_n310_), .Y(new_n411_));
  AOI21x1_ASAP7_75t_R g325(.A1(new_n311_), .A2(new_n406_), .B(new_n411_), .Y(new_n412_));
  OA21x2_ASAP7_75t_R  g326(.A1(G47), .A2(new_n412_), .B(new_n410_), .Y(new_n413_));
  AO21x1_ASAP7_75t_R  g327(.A1(new_n115_), .A2(new_n290_), .B(new_n413_), .Y(new_n414_));
  INVx1_ASAP7_75t_R   g328(.A(new_n414_), .Y(new_n415_));
  OR3x1_ASAP7_75t_R   g329(.A(new_n108_), .B(new_n384_), .C(new_n88_), .Y(new_n416_));
  INVx1_ASAP7_75t_R   g330(.A(new_n416_), .Y(new_n417_));
  OR3x1_ASAP7_75t_R   g331(.A(G38), .B(new_n286_), .C(new_n104_), .Y(new_n418_));
  INVx1_ASAP7_75t_R   g332(.A(new_n418_), .Y(new_n419_));
  OA21x2_ASAP7_75t_R  g333(.A1(new_n387_), .A2(new_n419_), .B(G27), .Y(new_n420_));
  OAI21x1_ASAP7_75t_R g334(.A1(new_n104_), .A2(G38), .B(G34), .Y(new_n421_));
  AOI21x1_ASAP7_75t_R g335(.A1(new_n97_), .A2(new_n421_), .B(new_n420_), .Y(new_n422_));
  OR3x1_ASAP7_75t_R   g336(.A(new_n417_), .B(new_n422_), .C(new_n382_), .Y(new_n423_));
  INVx1_ASAP7_75t_R   g337(.A(new_n423_), .Y(new_n424_));
  OR3x1_ASAP7_75t_R   g338(.A(new_n107_), .B(new_n384_), .C(new_n88_), .Y(new_n425_));
  INVx1_ASAP7_75t_R   g339(.A(new_n425_), .Y(new_n426_));
  NOR2x1_ASAP7_75t_R  g340(.A(G4), .B(new_n286_), .Y(new_n427_));
  AO21x1_ASAP7_75t_R  g341(.A1(G4), .A2(new_n387_), .B(new_n427_), .Y(new_n428_));
  NAND2x1_ASAP7_75t_R g342(.A(G26), .B(new_n428_), .Y(new_n429_));
  OA21x2_ASAP7_75t_R  g343(.A1(G34), .A2(new_n109_), .B(G4), .Y(new_n430_));
  OA21x2_ASAP7_75t_R  g344(.A1(G26), .A2(new_n430_), .B(new_n429_), .Y(new_n431_));
  OR3x1_ASAP7_75t_R   g345(.A(new_n426_), .B(new_n431_), .C(new_n382_), .Y(new_n432_));
  INVx1_ASAP7_75t_R   g346(.A(new_n432_), .Y(new_n433_));
  NOR2x1_ASAP7_75t_R  g347(.A(new_n423_), .B(new_n432_), .Y(new_n434_));
  AND3x1_ASAP7_75t_R  g348(.A(new_n114_), .B(new_n434_), .C(G43), .Y(new_n435_));
  AO21x1_ASAP7_75t_R  g349(.A1(new_n423_), .A2(new_n433_), .B(new_n424_), .Y(new_n436_));
  AND2x2_ASAP7_75t_R  g350(.A(new_n114_), .B(new_n436_), .Y(new_n437_));
  AO21x1_ASAP7_75t_R  g351(.A1(G44), .A2(new_n433_), .B(new_n437_), .Y(new_n438_));
  AO21x1_ASAP7_75t_R  g352(.A1(new_n113_), .A2(new_n438_), .B(new_n435_), .Y(new_n439_));
  NOR2x1_ASAP7_75t_R  g353(.A(new_n98_), .B(new_n285_), .Y(new_n440_));
  AOI21x1_ASAP7_75t_R g354(.A1(new_n105_), .A2(new_n440_), .B(G35), .Y(new_n441_));
  NOR2x1_ASAP7_75t_R  g355(.A(new_n254_), .B(new_n441_), .Y(new_n442_));
  AO21x1_ASAP7_75t_R  g356(.A1(new_n254_), .A2(new_n440_), .B(new_n442_), .Y(new_n443_));
  NAND2x1_ASAP7_75t_R g357(.A(new_n234_), .B(new_n443_), .Y(new_n444_));
  AO21x1_ASAP7_75t_R  g358(.A1(new_n234_), .A2(new_n444_), .B(new_n115_), .Y(new_n445_));
  INVx1_ASAP7_75t_R   g359(.A(new_n445_), .Y(new_n446_));
  NAND2x1_ASAP7_75t_R g360(.A(new_n439_), .B(new_n446_), .Y(new_n447_));
  NOR2x1_ASAP7_75t_R  g361(.A(G44), .B(new_n432_), .Y(new_n448_));
  AO21x1_ASAP7_75t_R  g362(.A1(G44), .A2(new_n434_), .B(new_n448_), .Y(new_n449_));
  NAND2x1_ASAP7_75t_R g363(.A(G43), .B(new_n449_), .Y(new_n450_));
  AOI21x1_ASAP7_75t_R g364(.A1(G44), .A2(new_n436_), .B(new_n114_), .Y(new_n451_));
  OA21x2_ASAP7_75t_R  g365(.A1(G43), .A2(new_n451_), .B(new_n450_), .Y(new_n452_));
  OA21x2_ASAP7_75t_R  g366(.A1(new_n446_), .A2(new_n452_), .B(new_n447_), .Y(new_n453_));
  NOR2x1_ASAP7_75t_R  g367(.A(new_n415_), .B(new_n453_), .Y(new_n454_));
  AO21x1_ASAP7_75t_R  g368(.A1(new_n415_), .A2(new_n439_), .B(new_n454_), .Y(new_n455_));
  INVx1_ASAP7_75t_R   g369(.A(new_n455_), .Y(new_n456_));
  AND3x1_ASAP7_75t_R  g370(.A(new_n403_), .B(new_n455_), .C(G41), .Y(new_n457_));
  AO21x1_ASAP7_75t_R  g371(.A1(new_n402_), .A2(new_n455_), .B(new_n403_), .Y(new_n458_));
  AO21x1_ASAP7_75t_R  g372(.A1(new_n111_), .A2(new_n458_), .B(new_n457_), .Y(new_n459_));
  AO21x1_ASAP7_75t_R  g373(.A1(G41), .A2(new_n403_), .B(new_n111_), .Y(new_n460_));
  AND2x2_ASAP7_75t_R  g374(.A(new_n112_), .B(new_n460_), .Y(new_n461_));
  AO21x1_ASAP7_75t_R  g375(.A1(G42), .A2(new_n459_), .B(new_n461_), .Y(new_n462_));
  AND3x1_ASAP7_75t_R  g376(.A(new_n111_), .B(new_n403_), .C(G42), .Y(new_n463_));
  AOI21x1_ASAP7_75t_R g377(.A1(new_n112_), .A2(new_n459_), .B(new_n463_), .Y(new_n464_));
  NOR2x1_ASAP7_75t_R  g378(.A(new_n394_), .B(new_n464_), .Y(new_n465_));
  AO21x1_ASAP7_75t_R  g379(.A1(new_n394_), .A2(new_n462_), .B(new_n465_), .Y(G876));
  AO21x1_ASAP7_75t_R  g380(.A1(new_n115_), .A2(new_n291_), .B(new_n290_), .Y(new_n467_));
  NAND2x1_ASAP7_75t_R g381(.A(new_n414_), .B(new_n467_), .Y(new_n468_));
  INVx1_ASAP7_75t_R   g382(.A(new_n468_), .Y(new_n469_));
  OR3x1_ASAP7_75t_R   g383(.A(G52), .B(new_n230_), .C(new_n423_), .Y(new_n470_));
  OR3x1_ASAP7_75t_R   g384(.A(G54), .B(new_n230_), .C(new_n424_), .Y(new_n471_));
  AOI21x1_ASAP7_75t_R g385(.A1(new_n470_), .A2(new_n471_), .B(new_n114_), .Y(new_n472_));
  AO21x1_ASAP7_75t_R  g386(.A1(new_n322_), .A2(new_n423_), .B(new_n424_), .Y(new_n473_));
  AOI21x1_ASAP7_75t_R g387(.A1(new_n114_), .A2(new_n473_), .B(new_n472_), .Y(new_n474_));
  AO21x1_ASAP7_75t_R  g388(.A1(G26), .A2(G50), .B(new_n474_), .Y(new_n475_));
  NOR2x1_ASAP7_75t_R  g389(.A(new_n469_), .B(new_n475_), .Y(new_n476_));
  NOR2x1_ASAP7_75t_R  g390(.A(G51), .B(new_n475_), .Y(new_n477_));
  AO21x1_ASAP7_75t_R  g391(.A1(G51), .A2(new_n476_), .B(new_n477_), .Y(new_n478_));
  NOR2x1_ASAP7_75t_R  g392(.A(G53), .B(new_n475_), .Y(new_n479_));
  AND3x1_ASAP7_75t_R  g393(.A(new_n469_), .B(new_n479_), .C(G51), .Y(new_n480_));
  AOI21x1_ASAP7_75t_R g394(.A1(new_n121_), .A2(new_n479_), .B(new_n480_), .Y(new_n481_));
  NOR2x1_ASAP7_75t_R  g395(.A(new_n424_), .B(new_n481_), .Y(new_n482_));
  AO21x1_ASAP7_75t_R  g396(.A1(new_n424_), .A2(new_n478_), .B(new_n482_), .Y(new_n483_));
  OR3x1_ASAP7_75t_R   g397(.A(new_n468_), .B(new_n475_), .C(new_n121_), .Y(new_n484_));
  INVx1_ASAP7_75t_R   g398(.A(new_n484_), .Y(new_n485_));
  OA21x2_ASAP7_75t_R  g399(.A1(new_n477_), .A2(new_n485_), .B(new_n424_), .Y(new_n486_));
  AOI21x1_ASAP7_75t_R g400(.A1(new_n423_), .A2(new_n478_), .B(new_n486_), .Y(new_n487_));
  NOR2x1_ASAP7_75t_R  g401(.A(G44), .B(new_n487_), .Y(new_n488_));
  AO21x1_ASAP7_75t_R  g402(.A1(G44), .A2(new_n483_), .B(new_n488_), .Y(G877));
  AND3x1_ASAP7_75t_R  g403(.A(new_n122_), .B(new_n231_), .C(new_n403_), .Y(new_n490_));
  OR3x1_ASAP7_75t_R   g404(.A(G53), .B(new_n230_), .C(G54), .Y(new_n491_));
  INVx1_ASAP7_75t_R   g405(.A(new_n491_), .Y(new_n492_));
  AO21x1_ASAP7_75t_R  g406(.A1(new_n402_), .A2(new_n492_), .B(new_n490_), .Y(new_n493_));
  AO21x1_ASAP7_75t_R  g407(.A1(new_n322_), .A2(new_n402_), .B(new_n403_), .Y(new_n494_));
  AND2x2_ASAP7_75t_R  g408(.A(new_n111_), .B(new_n494_), .Y(new_n495_));
  AOI21x1_ASAP7_75t_R g409(.A1(G41), .A2(new_n493_), .B(new_n495_), .Y(new_n496_));
  OA21x2_ASAP7_75t_R  g410(.A1(G50), .A2(new_n128_), .B(G60), .Y(new_n497_));
  XNOR2x2_ASAP7_75t_R g411(.A(new_n111_), .B(new_n402_), .Y(new_n498_));
  OA21x2_ASAP7_75t_R  g412(.A1(G51), .A2(new_n456_), .B(new_n455_), .Y(new_n499_));
  NOR2x1_ASAP7_75t_R  g413(.A(new_n112_), .B(new_n499_), .Y(new_n500_));
  AO21x1_ASAP7_75t_R  g414(.A1(new_n112_), .A2(new_n121_), .B(new_n500_), .Y(new_n501_));
  NOR2x1_ASAP7_75t_R  g415(.A(G42), .B(new_n499_), .Y(new_n502_));
  OA21x2_ASAP7_75t_R  g416(.A1(G42), .A2(new_n502_), .B(new_n393_), .Y(new_n503_));
  AO21x1_ASAP7_75t_R  g417(.A1(new_n394_), .A2(new_n501_), .B(new_n503_), .Y(new_n504_));
  NAND2x1_ASAP7_75t_R g418(.A(new_n498_), .B(new_n504_), .Y(new_n505_));
  AO21x1_ASAP7_75t_R  g419(.A1(new_n121_), .A2(new_n456_), .B(new_n455_), .Y(new_n506_));
  AO21x1_ASAP7_75t_R  g420(.A1(G42), .A2(new_n506_), .B(new_n112_), .Y(new_n507_));
  AND2x2_ASAP7_75t_R  g421(.A(new_n112_), .B(new_n506_), .Y(new_n508_));
  AO21x1_ASAP7_75t_R  g422(.A1(G42), .A2(new_n121_), .B(new_n508_), .Y(new_n509_));
  AND2x2_ASAP7_75t_R  g423(.A(new_n393_), .B(new_n509_), .Y(new_n510_));
  AOI21x1_ASAP7_75t_R g424(.A1(new_n394_), .A2(new_n507_), .B(new_n510_), .Y(new_n511_));
  OA21x2_ASAP7_75t_R  g425(.A1(new_n498_), .A2(new_n511_), .B(new_n505_), .Y(new_n512_));
  OR3x1_ASAP7_75t_R   g426(.A(new_n496_), .B(new_n497_), .C(new_n512_), .Y(new_n513_));
  INVx1_ASAP7_75t_R   g427(.A(new_n513_), .Y(G878));
  OR3x1_ASAP7_75t_R   g428(.A(G53), .B(G54), .C(new_n394_), .Y(new_n515_));
  OAI21x1_ASAP7_75t_R g429(.A1(G52), .A2(new_n393_), .B(new_n515_), .Y(new_n516_));
  AO21x1_ASAP7_75t_R  g430(.A1(new_n322_), .A2(new_n393_), .B(new_n394_), .Y(new_n517_));
  AND2x2_ASAP7_75t_R  g431(.A(new_n112_), .B(new_n517_), .Y(new_n518_));
  AOI21x1_ASAP7_75t_R g432(.A1(G42), .A2(new_n516_), .B(new_n518_), .Y(new_n519_));
  AO21x1_ASAP7_75t_R  g433(.A1(G24), .A2(G50), .B(new_n519_), .Y(new_n520_));
  AND3x1_ASAP7_75t_R  g434(.A(new_n121_), .B(new_n231_), .C(new_n455_), .Y(new_n521_));
  AO21x1_ASAP7_75t_R  g435(.A1(new_n231_), .A2(new_n456_), .B(new_n521_), .Y(new_n522_));
  AND3x1_ASAP7_75t_R  g436(.A(new_n121_), .B(new_n231_), .C(new_n456_), .Y(new_n523_));
  AO21x1_ASAP7_75t_R  g437(.A1(new_n231_), .A2(new_n455_), .B(new_n523_), .Y(new_n524_));
  AND2x2_ASAP7_75t_R  g438(.A(new_n393_), .B(new_n524_), .Y(new_n525_));
  AO21x1_ASAP7_75t_R  g439(.A1(new_n394_), .A2(new_n522_), .B(new_n525_), .Y(new_n526_));
  NAND2x1_ASAP7_75t_R g440(.A(G42), .B(new_n526_), .Y(new_n527_));
  NAND2x1_ASAP7_75t_R g441(.A(new_n394_), .B(new_n506_), .Y(new_n528_));
  OA21x2_ASAP7_75t_R  g442(.A1(new_n394_), .A2(new_n499_), .B(new_n528_), .Y(new_n529_));
  OA21x2_ASAP7_75t_R  g443(.A1(G42), .A2(new_n529_), .B(new_n527_), .Y(new_n530_));
  NOR2x1_ASAP7_75t_R  g444(.A(new_n520_), .B(new_n530_), .Y(G879));
  AND3x1_ASAP7_75t_R  g445(.A(new_n113_), .B(new_n433_), .C(new_n230_), .Y(new_n532_));
  AO21x1_ASAP7_75t_R  g446(.A1(new_n231_), .A2(new_n433_), .B(new_n532_), .Y(new_n533_));
  NAND2x1_ASAP7_75t_R g447(.A(G54), .B(new_n533_), .Y(new_n534_));
  AO21x1_ASAP7_75t_R  g448(.A1(new_n123_), .A2(new_n432_), .B(new_n433_), .Y(new_n535_));
  AO21x1_ASAP7_75t_R  g449(.A1(G43), .A2(new_n535_), .B(new_n113_), .Y(new_n536_));
  AND2x2_ASAP7_75t_R  g450(.A(new_n231_), .B(new_n536_), .Y(new_n537_));
  AOI21x1_ASAP7_75t_R g451(.A1(new_n113_), .A2(new_n230_), .B(new_n537_), .Y(new_n538_));
  OA21x2_ASAP7_75t_R  g452(.A1(G54), .A2(new_n538_), .B(new_n534_), .Y(new_n539_));
  AO21x1_ASAP7_75t_R  g453(.A1(G25), .A2(G50), .B(new_n539_), .Y(new_n540_));
  AND3x1_ASAP7_75t_R  g454(.A(new_n114_), .B(new_n424_), .C(new_n415_), .Y(new_n541_));
  AND3x1_ASAP7_75t_R  g455(.A(new_n114_), .B(new_n424_), .C(new_n446_), .Y(new_n542_));
  AO21x1_ASAP7_75t_R  g456(.A1(G44), .A2(new_n424_), .B(new_n114_), .Y(new_n543_));
  AO21x1_ASAP7_75t_R  g457(.A1(new_n445_), .A2(new_n543_), .B(new_n542_), .Y(new_n544_));
  AO21x1_ASAP7_75t_R  g458(.A1(new_n414_), .A2(new_n544_), .B(new_n541_), .Y(new_n545_));
  INVx1_ASAP7_75t_R   g459(.A(new_n545_), .Y(new_n546_));
  AND3x1_ASAP7_75t_R  g460(.A(new_n121_), .B(new_n122_), .C(new_n545_), .Y(new_n547_));
  AO21x1_ASAP7_75t_R  g461(.A1(new_n122_), .A2(new_n546_), .B(new_n547_), .Y(new_n548_));
  AO21x1_ASAP7_75t_R  g462(.A1(new_n121_), .A2(new_n546_), .B(new_n545_), .Y(new_n549_));
  AND2x2_ASAP7_75t_R  g463(.A(new_n432_), .B(new_n549_), .Y(new_n550_));
  AO21x1_ASAP7_75t_R  g464(.A1(new_n433_), .A2(new_n548_), .B(new_n550_), .Y(new_n551_));
  NAND2x1_ASAP7_75t_R g465(.A(G43), .B(new_n551_), .Y(new_n552_));
  AND2x2_ASAP7_75t_R  g466(.A(new_n432_), .B(new_n548_), .Y(new_n553_));
  AOI21x1_ASAP7_75t_R g467(.A1(new_n433_), .A2(new_n549_), .B(new_n553_), .Y(new_n554_));
  OA21x2_ASAP7_75t_R  g468(.A1(G43), .A2(new_n554_), .B(new_n552_), .Y(new_n555_));
  NOR2x1_ASAP7_75t_R  g469(.A(new_n540_), .B(new_n555_), .Y(G880));
endmodule


