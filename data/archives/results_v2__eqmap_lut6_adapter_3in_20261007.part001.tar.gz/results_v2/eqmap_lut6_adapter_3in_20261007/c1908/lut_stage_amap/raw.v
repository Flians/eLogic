// Benchmark "/home/flynn/workplace/MIGBalance/results_v2/eqmap_lut6_adapter_3in_20261007/c1908/lut_stage_amap/stage" written by ABC on Wed Oct  7 16:33:25 2026

module \/home/flynn/workplace/MIGBalance/results_v2/eqmap_lut6_adapter_3in_20261007/c1908/lut_stage_amap/stage  ( 
    G1, G10, G11, G12, G13, G14, G15, G16, G17, G18, G19, G2, G20, G21,
    G22, G23, G24, G25, G26, G27, G28, G29, G3, G30, G31, G32, G33, G4, G5,
    G6, G7, G8, G9,
    G1884, G1885, G1886, G1887, G1888, G1889, G1890, G1891, G1892, G1893,
    G1894, G1895, G1896, G1897, G1898, G1899, G1900, G1901, G1902, G1903,
    G1904, G1905, G1906, G1907, G1908  );
  input  G1, G10, G11, G12, G13, G14, G15, G16, G17, G18, G19, G2, G20,
    G21, G22, G23, G24, G25, G26, G27, G28, G29, G3, G30, G31, G32, G33,
    G4, G5, G6, G7, G8, G9;
  output G1884, G1885, G1886, G1887, G1888, G1889, G1890, G1891, G1892, G1893,
    G1894, G1895, G1896, G1897, G1898, G1899, G1900, G1901, G1902, G1903,
    G1904, G1905, G1906, G1907, G1908;
  wire new_n59_, new_n60_, new_n61_, new_n62_, new_n63_, new_n64_, new_n65_,
    new_n66_, new_n67_, new_n68_, new_n69_, new_n70_, new_n71_, new_n72_,
    new_n73_, new_n74_, new_n75_, new_n76_, new_n77_, new_n78_, new_n79_,
    new_n80_, new_n81_, new_n82_, new_n83_, new_n84_, new_n85_, new_n86_,
    new_n87_, new_n88_, new_n89_, new_n90_, new_n91_, new_n92_, new_n93_,
    new_n94_, new_n95_, new_n96_, new_n97_, new_n98_, new_n99_, new_n100_,
    new_n101_, new_n102_, new_n103_, new_n104_, new_n105_, new_n106_,
    new_n107_, new_n108_, new_n109_, new_n110_, new_n111_, new_n112_,
    new_n113_, new_n114_, new_n115_, new_n116_, new_n117_, new_n118_,
    new_n119_, new_n120_, new_n121_, new_n122_, new_n123_, new_n124_,
    new_n125_, new_n126_, new_n127_, new_n128_, new_n129_, new_n130_,
    new_n131_, new_n132_, new_n133_, new_n134_, new_n135_, new_n136_,
    new_n137_, new_n138_, new_n139_, new_n140_, new_n141_, new_n142_,
    new_n143_, new_n144_, new_n145_, new_n146_, new_n147_, new_n148_,
    new_n149_, new_n150_, new_n151_, new_n152_, new_n153_, new_n154_,
    new_n155_, new_n156_, new_n157_, new_n158_, new_n159_, new_n160_,
    new_n161_, new_n162_, new_n163_, new_n164_, new_n165_, new_n166_,
    new_n167_, new_n168_, new_n169_, new_n170_, new_n171_, new_n172_,
    new_n173_, new_n174_, new_n175_, new_n176_, new_n177_, new_n178_,
    new_n179_, new_n180_, new_n181_, new_n182_, new_n183_, new_n184_,
    new_n185_, new_n186_, new_n187_, new_n188_, new_n189_, new_n190_,
    new_n191_, new_n192_, new_n193_, new_n194_, new_n195_, new_n196_,
    new_n197_, new_n198_, new_n199_, new_n200_, new_n201_, new_n202_,
    new_n203_, new_n204_, new_n205_, new_n206_, new_n207_, new_n208_,
    new_n209_, new_n210_, new_n211_, new_n212_, new_n213_, new_n214_,
    new_n215_, new_n216_, new_n217_, new_n218_, new_n219_, new_n220_,
    new_n221_, new_n222_, new_n223_, new_n224_, new_n225_, new_n226_,
    new_n227_, new_n228_, new_n229_, new_n230_, new_n231_, new_n232_,
    new_n233_, new_n234_, new_n235_, new_n236_, new_n237_, new_n238_,
    new_n239_, new_n240_, new_n241_, new_n242_, new_n243_, new_n244_,
    new_n245_, new_n246_, new_n247_, new_n248_, new_n249_, new_n250_,
    new_n251_, new_n252_, new_n253_, new_n254_, new_n255_, new_n256_,
    new_n257_, new_n258_, new_n259_, new_n260_, new_n261_, new_n262_,
    new_n263_, new_n264_, new_n265_, new_n266_, new_n267_, new_n268_,
    new_n269_, new_n270_, new_n271_, new_n272_, new_n273_, new_n274_,
    new_n275_, new_n276_, new_n277_, new_n278_, new_n279_, new_n280_,
    new_n281_, new_n282_, new_n283_, new_n284_, new_n285_, new_n286_,
    new_n287_, new_n288_, new_n289_, new_n290_, new_n291_, new_n292_,
    new_n293_, new_n294_, new_n295_, new_n296_, new_n297_, new_n298_,
    new_n299_, new_n300_, new_n301_, new_n306_, new_n307_, new_n308_,
    new_n309_, new_n310_, new_n311_, new_n312_, new_n313_, new_n314_,
    new_n315_, new_n316_, new_n320_, new_n321_, new_n322_, new_n323_,
    new_n324_, new_n325_, new_n326_, new_n328_, new_n330_, new_n332_,
    new_n334_, new_n335_, new_n336_, new_n337_, new_n338_, new_n340_,
    new_n341_, new_n342_, new_n343_, new_n344_, new_n345_, new_n346_,
    new_n347_, new_n348_, new_n349_, new_n350_, new_n351_, new_n352_,
    new_n354_, new_n356_, new_n358_, new_n360_, new_n361_, new_n362_,
    new_n363_, new_n364_, new_n365_, new_n366_, new_n367_, new_n368_,
    new_n369_, new_n370_, new_n371_, new_n372_, new_n373_, new_n374_,
    new_n375_, new_n376_, new_n378_, new_n379_, new_n380_, new_n381_,
    new_n382_, new_n383_, new_n384_, new_n385_, new_n386_, new_n388_,
    new_n389_, new_n390_, new_n392_, new_n393_, new_n394_, new_n395_,
    new_n396_, new_n397_, new_n398_, new_n399_, new_n400_, new_n401_,
    new_n402_, new_n403_, new_n404_, new_n405_, new_n406_, new_n407_,
    new_n409_, new_n410_, new_n411_, new_n412_, new_n413_, new_n414_,
    new_n415_, new_n416_, new_n417_, new_n419_, new_n420_, new_n421_,
    new_n422_, new_n423_, new_n424_, new_n425_, new_n426_, new_n427_,
    new_n428_, new_n429_, new_n430_, new_n431_, new_n432_, new_n434_,
    new_n435_, new_n436_, new_n437_, new_n438_, new_n439_, new_n440_,
    new_n441_, new_n442_, new_n443_, new_n445_, new_n446_, new_n447_,
    new_n448_, new_n449_, new_n450_, new_n451_, new_n452_, new_n453_,
    new_n454_, new_n455_, new_n456_, new_n457_, new_n458_, new_n460_,
    new_n461_, new_n462_, new_n463_, new_n464_;
  INVx1_ASAP7_75t_R   g000(.A(G1), .Y(new_n59_));
  INVx1_ASAP7_75t_R   g001(.A(G10), .Y(new_n60_));
  INVx1_ASAP7_75t_R   g002(.A(G12), .Y(new_n61_));
  INVx1_ASAP7_75t_R   g003(.A(G13), .Y(new_n62_));
  INVx1_ASAP7_75t_R   g004(.A(G14), .Y(new_n63_));
  INVx1_ASAP7_75t_R   g005(.A(G15), .Y(new_n64_));
  INVx1_ASAP7_75t_R   g006(.A(G16), .Y(new_n65_));
  INVx1_ASAP7_75t_R   g007(.A(G17), .Y(new_n66_));
  INVx1_ASAP7_75t_R   g008(.A(G18), .Y(new_n67_));
  INVx1_ASAP7_75t_R   g009(.A(G19), .Y(new_n68_));
  INVx1_ASAP7_75t_R   g010(.A(G2), .Y(new_n69_));
  INVx1_ASAP7_75t_R   g011(.A(G20), .Y(new_n70_));
  INVx1_ASAP7_75t_R   g012(.A(G21), .Y(new_n71_));
  INVx1_ASAP7_75t_R   g013(.A(G22), .Y(new_n72_));
  INVx1_ASAP7_75t_R   g014(.A(G23), .Y(new_n73_));
  INVx1_ASAP7_75t_R   g015(.A(G24), .Y(new_n74_));
  INVx1_ASAP7_75t_R   g016(.A(G25), .Y(new_n75_));
  INVx1_ASAP7_75t_R   g017(.A(G26), .Y(new_n76_));
  INVx1_ASAP7_75t_R   g018(.A(G27), .Y(new_n77_));
  INVx1_ASAP7_75t_R   g019(.A(G28), .Y(new_n78_));
  INVx1_ASAP7_75t_R   g020(.A(G29), .Y(new_n79_));
  INVx1_ASAP7_75t_R   g021(.A(G3), .Y(new_n80_));
  INVx1_ASAP7_75t_R   g022(.A(G30), .Y(new_n81_));
  INVx1_ASAP7_75t_R   g023(.A(G31), .Y(new_n82_));
  INVx1_ASAP7_75t_R   g024(.A(G32), .Y(new_n83_));
  INVx1_ASAP7_75t_R   g025(.A(G33), .Y(new_n84_));
  INVx1_ASAP7_75t_R   g026(.A(G4), .Y(new_n85_));
  INVx1_ASAP7_75t_R   g027(.A(G6), .Y(new_n86_));
  XOR2x2_ASAP7_75t_R  g028(.A(G12), .B(new_n64_), .Y(new_n87_));
  NOR2x1_ASAP7_75t_R  g029(.A(new_n60_), .B(new_n87_), .Y(new_n88_));
  XNOR2x2_ASAP7_75t_R g030(.A(new_n61_), .B(new_n64_), .Y(new_n89_));
  AO21x1_ASAP7_75t_R  g031(.A1(new_n60_), .A2(new_n89_), .B(new_n88_), .Y(new_n90_));
  NOR2x1_ASAP7_75t_R  g032(.A(G10), .B(new_n87_), .Y(new_n91_));
  AO21x1_ASAP7_75t_R  g033(.A1(G10), .A2(new_n89_), .B(new_n91_), .Y(new_n92_));
  AND2x2_ASAP7_75t_R  g034(.A(new_n86_), .B(new_n92_), .Y(new_n93_));
  AO21x1_ASAP7_75t_R  g035(.A1(G6), .A2(new_n90_), .B(new_n93_), .Y(new_n94_));
  AND2x2_ASAP7_75t_R  g036(.A(new_n86_), .B(new_n90_), .Y(new_n95_));
  AO21x1_ASAP7_75t_R  g037(.A1(G6), .A2(new_n92_), .B(new_n95_), .Y(new_n96_));
  AND2x2_ASAP7_75t_R  g038(.A(new_n80_), .B(new_n96_), .Y(new_n97_));
  AO21x1_ASAP7_75t_R  g039(.A1(G3), .A2(new_n94_), .B(new_n97_), .Y(new_n98_));
  AND2x2_ASAP7_75t_R  g040(.A(new_n80_), .B(new_n94_), .Y(new_n99_));
  AOI21x1_ASAP7_75t_R g041(.A1(G3), .A2(new_n96_), .B(new_n99_), .Y(new_n100_));
  NOR2x1_ASAP7_75t_R  g042(.A(G8), .B(new_n100_), .Y(new_n101_));
  AO21x1_ASAP7_75t_R  g043(.A1(G8), .A2(new_n98_), .B(new_n101_), .Y(new_n102_));
  INVx1_ASAP7_75t_R   g044(.A(new_n102_), .Y(new_n103_));
  AO21x1_ASAP7_75t_R  g045(.A1(G23), .A2(new_n84_), .B(G33), .Y(new_n104_));
  AOI21x1_ASAP7_75t_R g046(.A1(G19), .A2(new_n104_), .B(new_n68_), .Y(new_n105_));
  OR3x1_ASAP7_75t_R   g047(.A(G31), .B(new_n105_), .C(new_n103_), .Y(new_n106_));
  NAND2x1_ASAP7_75t_R g048(.A(new_n73_), .B(new_n84_), .Y(new_n107_));
  OR3x1_ASAP7_75t_R   g049(.A(new_n68_), .B(new_n107_), .C(G31), .Y(new_n108_));
  OA21x2_ASAP7_75t_R  g050(.A1(new_n102_), .A2(new_n108_), .B(new_n106_), .Y(new_n109_));
  INVx1_ASAP7_75t_R   g051(.A(new_n109_), .Y(new_n110_));
  AO21x1_ASAP7_75t_R  g052(.A1(G24), .A2(new_n84_), .B(G33), .Y(new_n111_));
  AO21x1_ASAP7_75t_R  g053(.A1(G18), .A2(new_n111_), .B(new_n67_), .Y(new_n112_));
  INVx1_ASAP7_75t_R   g054(.A(new_n112_), .Y(new_n113_));
  NOR2x1_ASAP7_75t_R  g055(.A(G24), .B(G33), .Y(new_n114_));
  OR3x1_ASAP7_75t_R   g056(.A(G24), .B(G33), .C(new_n67_), .Y(new_n115_));
  NOR2x1_ASAP7_75t_R  g057(.A(G11), .B(new_n115_), .Y(new_n116_));
  AO21x1_ASAP7_75t_R  g058(.A1(G11), .A2(new_n112_), .B(new_n116_), .Y(new_n117_));
  AND3x1_ASAP7_75t_R  g059(.A(G18), .B(new_n114_), .C(G11), .Y(new_n118_));
  NOR2x1_ASAP7_75t_R  g060(.A(G11), .B(new_n113_), .Y(new_n119_));
  OA21x2_ASAP7_75t_R  g061(.A1(new_n118_), .A2(new_n119_), .B(new_n64_), .Y(new_n120_));
  AO21x1_ASAP7_75t_R  g062(.A1(G15), .A2(new_n117_), .B(new_n120_), .Y(new_n121_));
  INVx1_ASAP7_75t_R   g063(.A(new_n121_), .Y(new_n122_));
  XNOR2x2_ASAP7_75t_R g064(.A(new_n63_), .B(new_n65_), .Y(new_n123_));
  XOR2x2_ASAP7_75t_R  g065(.A(new_n63_), .B(G16), .Y(new_n124_));
  NOR2x1_ASAP7_75t_R  g066(.A(G9), .B(new_n124_), .Y(new_n125_));
  AO21x1_ASAP7_75t_R  g067(.A1(G9), .A2(new_n123_), .B(new_n125_), .Y(new_n126_));
  INVx1_ASAP7_75t_R   g068(.A(new_n126_), .Y(new_n127_));
  NOR2x1_ASAP7_75t_R  g069(.A(G31), .B(new_n126_), .Y(new_n128_));
  NOR2x1_ASAP7_75t_R  g070(.A(G31), .B(new_n127_), .Y(new_n129_));
  AND3x1_ASAP7_75t_R  g071(.A(new_n82_), .B(new_n126_), .C(new_n122_), .Y(new_n130_));
  AO21x1_ASAP7_75t_R  g072(.A1(new_n121_), .A2(new_n128_), .B(new_n130_), .Y(new_n131_));
  INVx1_ASAP7_75t_R   g073(.A(new_n131_), .Y(new_n132_));
  AND3x1_ASAP7_75t_R  g074(.A(new_n82_), .B(new_n127_), .C(new_n122_), .Y(new_n133_));
  AO21x1_ASAP7_75t_R  g075(.A1(new_n121_), .A2(new_n129_), .B(new_n133_), .Y(new_n134_));
  INVx1_ASAP7_75t_R   g076(.A(new_n134_), .Y(new_n135_));
  NOR2x1_ASAP7_75t_R  g077(.A(G5), .B(new_n135_), .Y(new_n136_));
  AO21x1_ASAP7_75t_R  g078(.A1(G5), .A2(new_n131_), .B(new_n136_), .Y(new_n137_));
  NOR2x1_ASAP7_75t_R  g079(.A(G5), .B(new_n132_), .Y(new_n138_));
  AO21x1_ASAP7_75t_R  g080(.A1(G5), .A2(new_n134_), .B(new_n138_), .Y(new_n139_));
  AND2x2_ASAP7_75t_R  g081(.A(new_n69_), .B(new_n139_), .Y(new_n140_));
  AO21x1_ASAP7_75t_R  g082(.A1(G2), .A2(new_n137_), .B(new_n140_), .Y(new_n141_));
  AND2x2_ASAP7_75t_R  g083(.A(new_n69_), .B(new_n137_), .Y(new_n142_));
  AOI21x1_ASAP7_75t_R g084(.A1(G2), .A2(new_n139_), .B(new_n142_), .Y(new_n143_));
  NOR2x1_ASAP7_75t_R  g085(.A(G8), .B(new_n143_), .Y(new_n144_));
  AO21x1_ASAP7_75t_R  g086(.A1(G8), .A2(new_n141_), .B(new_n144_), .Y(new_n145_));
  INVx1_ASAP7_75t_R   g087(.A(new_n145_), .Y(new_n146_));
  NOR2x1_ASAP7_75t_R  g088(.A(G23), .B(new_n74_), .Y(new_n147_));
  AO21x1_ASAP7_75t_R  g089(.A1(new_n82_), .A2(new_n147_), .B(G31), .Y(new_n148_));
  AO21x1_ASAP7_75t_R  g090(.A1(new_n79_), .A2(new_n148_), .B(G29), .Y(new_n149_));
  AO21x1_ASAP7_75t_R  g091(.A1(new_n84_), .A2(new_n149_), .B(G33), .Y(new_n150_));
  AO21x1_ASAP7_75t_R  g092(.A1(new_n84_), .A2(new_n147_), .B(G33), .Y(new_n151_));
  AND2x2_ASAP7_75t_R  g093(.A(new_n83_), .B(new_n151_), .Y(new_n152_));
  AO21x1_ASAP7_75t_R  g094(.A1(G32), .A2(new_n150_), .B(new_n152_), .Y(new_n153_));
  OR3x1_ASAP7_75t_R   g095(.A(new_n146_), .B(new_n153_), .C(new_n77_), .Y(new_n154_));
  OR3x1_ASAP7_75t_R   g096(.A(new_n145_), .B(new_n153_), .C(G27), .Y(new_n155_));
  AND2x2_ASAP7_75t_R  g097(.A(new_n154_), .B(new_n155_), .Y(new_n156_));
  OR3x1_ASAP7_75t_R   g098(.A(new_n109_), .B(new_n156_), .C(new_n78_), .Y(new_n157_));
  OR3x1_ASAP7_75t_R   g099(.A(new_n110_), .B(new_n156_), .C(G28), .Y(new_n158_));
  NAND2x1_ASAP7_75t_R g100(.A(new_n157_), .B(new_n158_), .Y(new_n159_));
  INVx1_ASAP7_75t_R   g101(.A(new_n159_), .Y(new_n160_));
  OA21x2_ASAP7_75t_R  g102(.A1(G23), .A2(new_n82_), .B(new_n73_), .Y(new_n161_));
  NOR2x1_ASAP7_75t_R  g103(.A(new_n68_), .B(new_n161_), .Y(new_n162_));
  OR3x1_ASAP7_75t_R   g104(.A(new_n70_), .B(new_n107_), .C(new_n62_), .Y(new_n163_));
  INVx1_ASAP7_75t_R   g105(.A(new_n163_), .Y(new_n164_));
  AO21x1_ASAP7_75t_R  g106(.A1(G20), .A2(new_n104_), .B(new_n70_), .Y(new_n165_));
  AO21x1_ASAP7_75t_R  g107(.A1(new_n62_), .A2(new_n165_), .B(new_n164_), .Y(new_n166_));
  INVx1_ASAP7_75t_R   g108(.A(new_n166_), .Y(new_n167_));
  AND3x1_ASAP7_75t_R  g109(.A(new_n82_), .B(new_n127_), .C(new_n167_), .Y(new_n168_));
  AO21x1_ASAP7_75t_R  g110(.A1(new_n129_), .A2(new_n166_), .B(new_n168_), .Y(new_n169_));
  AND3x1_ASAP7_75t_R  g111(.A(new_n82_), .B(new_n126_), .C(new_n167_), .Y(new_n170_));
  AO21x1_ASAP7_75t_R  g112(.A1(new_n128_), .A2(new_n166_), .B(new_n170_), .Y(new_n171_));
  AND2x2_ASAP7_75t_R  g113(.A(new_n85_), .B(new_n171_), .Y(new_n172_));
  AO21x1_ASAP7_75t_R  g114(.A1(G4), .A2(new_n169_), .B(new_n172_), .Y(new_n173_));
  AND2x2_ASAP7_75t_R  g115(.A(new_n85_), .B(new_n169_), .Y(new_n174_));
  AO21x1_ASAP7_75t_R  g116(.A1(G4), .A2(new_n171_), .B(new_n174_), .Y(new_n175_));
  AND2x2_ASAP7_75t_R  g117(.A(new_n60_), .B(new_n175_), .Y(new_n176_));
  AO21x1_ASAP7_75t_R  g118(.A1(G10), .A2(new_n173_), .B(new_n176_), .Y(new_n177_));
  AND2x2_ASAP7_75t_R  g119(.A(new_n60_), .B(new_n173_), .Y(new_n178_));
  AOI21x1_ASAP7_75t_R g120(.A1(G10), .A2(new_n175_), .B(new_n178_), .Y(new_n179_));
  NOR2x1_ASAP7_75t_R  g121(.A(G7), .B(new_n179_), .Y(new_n180_));
  AO21x1_ASAP7_75t_R  g122(.A1(G7), .A2(new_n177_), .B(new_n180_), .Y(new_n181_));
  INVx1_ASAP7_75t_R   g123(.A(new_n181_), .Y(new_n182_));
  AND3x1_ASAP7_75t_R  g124(.A(G17), .B(new_n114_), .C(G1), .Y(new_n183_));
  AO21x1_ASAP7_75t_R  g125(.A1(G17), .A2(new_n111_), .B(new_n66_), .Y(new_n184_));
  AO21x1_ASAP7_75t_R  g126(.A1(new_n59_), .A2(new_n184_), .B(new_n183_), .Y(new_n185_));
  XNOR2x2_ASAP7_75t_R g127(.A(G6), .B(G7), .Y(new_n186_));
  XOR2x2_ASAP7_75t_R  g128(.A(new_n86_), .B(G7), .Y(new_n187_));
  NOR2x1_ASAP7_75t_R  g129(.A(G5), .B(new_n187_), .Y(new_n188_));
  AO21x1_ASAP7_75t_R  g130(.A1(G5), .A2(new_n186_), .B(new_n188_), .Y(new_n189_));
  INVx1_ASAP7_75t_R   g131(.A(new_n189_), .Y(new_n190_));
  XOR2x2_ASAP7_75t_R  g132(.A(new_n61_), .B(new_n62_), .Y(new_n191_));
  INVx1_ASAP7_75t_R   g133(.A(new_n191_), .Y(new_n192_));
  XOR2x2_ASAP7_75t_R  g134(.A(new_n61_), .B(G13), .Y(new_n193_));
  INVx1_ASAP7_75t_R   g135(.A(new_n193_), .Y(new_n194_));
  NOR2x1_ASAP7_75t_R  g136(.A(G11), .B(new_n193_), .Y(new_n195_));
  AO21x1_ASAP7_75t_R  g137(.A1(G11), .A2(new_n192_), .B(new_n195_), .Y(new_n196_));
  NOR2x1_ASAP7_75t_R  g138(.A(G11), .B(new_n191_), .Y(new_n197_));
  AO21x1_ASAP7_75t_R  g139(.A1(G11), .A2(new_n194_), .B(new_n197_), .Y(new_n198_));
  AND2x2_ASAP7_75t_R  g140(.A(new_n65_), .B(new_n198_), .Y(new_n199_));
  AO21x1_ASAP7_75t_R  g141(.A1(G16), .A2(new_n196_), .B(new_n199_), .Y(new_n200_));
  AND2x2_ASAP7_75t_R  g142(.A(new_n65_), .B(new_n196_), .Y(new_n201_));
  AO21x1_ASAP7_75t_R  g143(.A1(G16), .A2(new_n198_), .B(new_n201_), .Y(new_n202_));
  AND2x2_ASAP7_75t_R  g144(.A(new_n64_), .B(new_n202_), .Y(new_n203_));
  AO21x1_ASAP7_75t_R  g145(.A1(G15), .A2(new_n200_), .B(new_n203_), .Y(new_n204_));
  AND2x2_ASAP7_75t_R  g146(.A(new_n64_), .B(new_n200_), .Y(new_n205_));
  AOI21x1_ASAP7_75t_R g147(.A1(G15), .A2(new_n202_), .B(new_n205_), .Y(new_n206_));
  NOR2x1_ASAP7_75t_R  g148(.A(G10), .B(new_n206_), .Y(new_n207_));
  AO21x1_ASAP7_75t_R  g149(.A1(G10), .A2(new_n204_), .B(new_n207_), .Y(new_n208_));
  INVx1_ASAP7_75t_R   g150(.A(new_n208_), .Y(new_n209_));
  NOR2x1_ASAP7_75t_R  g151(.A(G31), .B(new_n208_), .Y(new_n210_));
  AND3x1_ASAP7_75t_R  g152(.A(new_n82_), .B(new_n208_), .C(new_n190_), .Y(new_n211_));
  AO21x1_ASAP7_75t_R  g153(.A1(new_n189_), .A2(new_n210_), .B(new_n211_), .Y(new_n212_));
  OR3x1_ASAP7_75t_R   g154(.A(G31), .B(new_n209_), .C(new_n190_), .Y(new_n213_));
  OR3x1_ASAP7_75t_R   g155(.A(G31), .B(new_n208_), .C(new_n189_), .Y(new_n214_));
  AOI21x1_ASAP7_75t_R g156(.A1(new_n213_), .A2(new_n214_), .B(new_n185_), .Y(new_n215_));
  AO21x1_ASAP7_75t_R  g157(.A1(new_n185_), .A2(new_n212_), .B(new_n215_), .Y(new_n216_));
  INVx1_ASAP7_75t_R   g158(.A(new_n216_), .Y(new_n217_));
  AO21x1_ASAP7_75t_R  g159(.A1(new_n74_), .A2(G31), .B(G24), .Y(new_n218_));
  INVx1_ASAP7_75t_R   g160(.A(new_n218_), .Y(new_n219_));
  AO21x1_ASAP7_75t_R  g161(.A1(G21), .A2(G33), .B(new_n71_), .Y(new_n220_));
  AND3x1_ASAP7_75t_R  g162(.A(G21), .B(new_n84_), .C(new_n65_), .Y(new_n221_));
  AO21x1_ASAP7_75t_R  g163(.A1(G16), .A2(new_n220_), .B(new_n221_), .Y(new_n222_));
  AND3x1_ASAP7_75t_R  g164(.A(G21), .B(new_n84_), .C(G16), .Y(new_n223_));
  AO21x1_ASAP7_75t_R  g165(.A1(new_n65_), .A2(new_n220_), .B(new_n223_), .Y(new_n224_));
  AND2x2_ASAP7_75t_R  g166(.A(new_n64_), .B(new_n224_), .Y(new_n225_));
  AO21x1_ASAP7_75t_R  g167(.A1(G15), .A2(new_n222_), .B(new_n225_), .Y(new_n226_));
  AND2x2_ASAP7_75t_R  g168(.A(new_n64_), .B(new_n222_), .Y(new_n227_));
  AO21x1_ASAP7_75t_R  g169(.A1(G15), .A2(new_n224_), .B(new_n227_), .Y(new_n228_));
  AND2x2_ASAP7_75t_R  g170(.A(new_n60_), .B(new_n228_), .Y(new_n229_));
  AO21x1_ASAP7_75t_R  g171(.A1(G10), .A2(new_n226_), .B(new_n229_), .Y(new_n230_));
  AND2x2_ASAP7_75t_R  g172(.A(new_n60_), .B(new_n226_), .Y(new_n231_));
  AOI21x1_ASAP7_75t_R g173(.A1(G10), .A2(new_n228_), .B(new_n231_), .Y(new_n232_));
  NOR2x1_ASAP7_75t_R  g174(.A(G9), .B(new_n232_), .Y(new_n233_));
  AO21x1_ASAP7_75t_R  g175(.A1(G9), .A2(new_n230_), .B(new_n233_), .Y(new_n234_));
  XOR2x2_ASAP7_75t_R  g176(.A(new_n59_), .B(G4), .Y(new_n235_));
  NOR2x1_ASAP7_75t_R  g177(.A(new_n69_), .B(new_n235_), .Y(new_n236_));
  XNOR2x2_ASAP7_75t_R g178(.A(new_n59_), .B(new_n85_), .Y(new_n237_));
  AO21x1_ASAP7_75t_R  g179(.A1(new_n69_), .A2(new_n237_), .B(new_n236_), .Y(new_n238_));
  NOR2x1_ASAP7_75t_R  g180(.A(G2), .B(new_n235_), .Y(new_n239_));
  AO21x1_ASAP7_75t_R  g181(.A1(G2), .A2(new_n237_), .B(new_n239_), .Y(new_n240_));
  AND2x2_ASAP7_75t_R  g182(.A(new_n80_), .B(new_n240_), .Y(new_n241_));
  AO21x1_ASAP7_75t_R  g183(.A1(G3), .A2(new_n238_), .B(new_n241_), .Y(new_n242_));
  AND2x2_ASAP7_75t_R  g184(.A(new_n80_), .B(new_n238_), .Y(new_n243_));
  AOI21x1_ASAP7_75t_R g185(.A1(G3), .A2(new_n240_), .B(new_n243_), .Y(new_n244_));
  NOR2x1_ASAP7_75t_R  g186(.A(G8), .B(new_n244_), .Y(new_n245_));
  AO21x1_ASAP7_75t_R  g187(.A1(G8), .A2(new_n242_), .B(new_n245_), .Y(new_n246_));
  INVx1_ASAP7_75t_R   g188(.A(new_n246_), .Y(new_n247_));
  NOR2x1_ASAP7_75t_R  g189(.A(new_n66_), .B(new_n82_), .Y(new_n248_));
  AND3x1_ASAP7_75t_R  g190(.A(G17), .B(G24), .C(new_n82_), .Y(new_n249_));
  AO21x1_ASAP7_75t_R  g191(.A1(G17), .A2(G31), .B(new_n249_), .Y(new_n250_));
  AO21x1_ASAP7_75t_R  g192(.A1(G17), .A2(new_n74_), .B(new_n66_), .Y(new_n251_));
  AO21x1_ASAP7_75t_R  g193(.A1(new_n82_), .A2(new_n251_), .B(new_n248_), .Y(new_n252_));
  AND2x2_ASAP7_75t_R  g194(.A(new_n190_), .B(new_n252_), .Y(new_n253_));
  AO21x1_ASAP7_75t_R  g195(.A1(new_n189_), .A2(new_n250_), .B(new_n253_), .Y(new_n254_));
  AND2x2_ASAP7_75t_R  g196(.A(new_n190_), .B(new_n250_), .Y(new_n255_));
  AO21x1_ASAP7_75t_R  g197(.A1(new_n189_), .A2(new_n252_), .B(new_n255_), .Y(new_n256_));
  AND2x2_ASAP7_75t_R  g198(.A(new_n247_), .B(new_n256_), .Y(new_n257_));
  AO21x1_ASAP7_75t_R  g199(.A1(new_n246_), .A2(new_n254_), .B(new_n257_), .Y(new_n258_));
  AND2x2_ASAP7_75t_R  g200(.A(new_n247_), .B(new_n254_), .Y(new_n259_));
  AOI21x1_ASAP7_75t_R g201(.A1(new_n246_), .A2(new_n256_), .B(new_n259_), .Y(new_n260_));
  NOR2x1_ASAP7_75t_R  g202(.A(new_n234_), .B(new_n260_), .Y(new_n261_));
  AO21x1_ASAP7_75t_R  g203(.A1(new_n234_), .A2(new_n258_), .B(new_n261_), .Y(new_n262_));
  AND3x1_ASAP7_75t_R  g204(.A(G18), .B(new_n218_), .C(new_n262_), .Y(new_n263_));
  AO21x1_ASAP7_75t_R  g205(.A1(new_n216_), .A2(new_n263_), .B(new_n217_), .Y(new_n264_));
  AO21x1_ASAP7_75t_R  g206(.A1(new_n217_), .A2(new_n263_), .B(new_n216_), .Y(new_n265_));
  AND2x2_ASAP7_75t_R  g207(.A(new_n76_), .B(new_n265_), .Y(new_n266_));
  AO21x1_ASAP7_75t_R  g208(.A1(G26), .A2(new_n264_), .B(new_n266_), .Y(new_n267_));
  AO21x1_ASAP7_75t_R  g209(.A1(new_n181_), .A2(new_n267_), .B(new_n182_), .Y(new_n268_));
  AO21x1_ASAP7_75t_R  g210(.A1(new_n182_), .A2(new_n267_), .B(new_n181_), .Y(new_n269_));
  OA21x2_ASAP7_75t_R  g211(.A1(new_n68_), .A2(new_n161_), .B(new_n269_), .Y(new_n270_));
  AO21x1_ASAP7_75t_R  g212(.A1(new_n162_), .A2(new_n268_), .B(new_n270_), .Y(new_n271_));
  INVx1_ASAP7_75t_R   g213(.A(new_n271_), .Y(new_n272_));
  AO21x1_ASAP7_75t_R  g214(.A1(G22), .A2(G33), .B(new_n72_), .Y(new_n273_));
  AND3x1_ASAP7_75t_R  g215(.A(G22), .B(new_n84_), .C(new_n85_), .Y(new_n274_));
  AO21x1_ASAP7_75t_R  g216(.A1(G4), .A2(new_n273_), .B(new_n274_), .Y(new_n275_));
  NAND2x1_ASAP7_75t_R g217(.A(G14), .B(new_n275_), .Y(new_n276_));
  AND3x1_ASAP7_75t_R  g218(.A(G22), .B(new_n84_), .C(G4), .Y(new_n277_));
  AOI21x1_ASAP7_75t_R g219(.A1(new_n85_), .A2(new_n273_), .B(new_n277_), .Y(new_n278_));
  OA21x2_ASAP7_75t_R  g220(.A1(G14), .A2(new_n278_), .B(new_n276_), .Y(new_n279_));
  XOR2x2_ASAP7_75t_R  g221(.A(new_n209_), .B(new_n279_), .Y(new_n280_));
  NOR2x1_ASAP7_75t_R  g222(.A(new_n59_), .B(new_n280_), .Y(new_n281_));
  XNOR2x2_ASAP7_75t_R g223(.A(new_n208_), .B(new_n279_), .Y(new_n282_));
  AO21x1_ASAP7_75t_R  g224(.A1(new_n59_), .A2(new_n282_), .B(new_n281_), .Y(new_n283_));
  NOR2x1_ASAP7_75t_R  g225(.A(G1), .B(new_n280_), .Y(new_n284_));
  AO21x1_ASAP7_75t_R  g226(.A1(G1), .A2(new_n282_), .B(new_n284_), .Y(new_n285_));
  AND2x2_ASAP7_75t_R  g227(.A(new_n69_), .B(new_n285_), .Y(new_n286_));
  AO21x1_ASAP7_75t_R  g228(.A1(G2), .A2(new_n283_), .B(new_n286_), .Y(new_n287_));
  AND2x2_ASAP7_75t_R  g229(.A(new_n69_), .B(new_n283_), .Y(new_n288_));
  AOI21x1_ASAP7_75t_R g230(.A1(G2), .A2(new_n285_), .B(new_n288_), .Y(new_n289_));
  NOR2x1_ASAP7_75t_R  g231(.A(G3), .B(new_n289_), .Y(new_n290_));
  AO21x1_ASAP7_75t_R  g232(.A1(G3), .A2(new_n287_), .B(new_n290_), .Y(new_n291_));
  INVx1_ASAP7_75t_R   g233(.A(new_n291_), .Y(new_n292_));
  AO21x1_ASAP7_75t_R  g234(.A1(G31), .A2(new_n291_), .B(new_n292_), .Y(new_n293_));
  AND3x1_ASAP7_75t_R  g235(.A(new_n82_), .B(new_n291_), .C(new_n75_), .Y(new_n294_));
  AO21x1_ASAP7_75t_R  g236(.A1(G25), .A2(new_n293_), .B(new_n294_), .Y(new_n295_));
  INVx1_ASAP7_75t_R   g237(.A(new_n295_), .Y(new_n296_));
  NOR2x1_ASAP7_75t_R  g238(.A(new_n70_), .B(new_n161_), .Y(new_n297_));
  INVx1_ASAP7_75t_R   g239(.A(new_n297_), .Y(new_n298_));
  OA21x2_ASAP7_75t_R  g240(.A1(new_n296_), .A2(new_n297_), .B(new_n295_), .Y(new_n299_));
  OR3x1_ASAP7_75t_R   g241(.A(new_n271_), .B(new_n299_), .C(new_n160_), .Y(new_n300_));
  INVx1_ASAP7_75t_R   g242(.A(new_n300_), .Y(new_n301_));
  XNOR2x2_ASAP7_75t_R g243(.A(new_n59_), .B(new_n300_), .Y(G1884));
  XNOR2x2_ASAP7_75t_R g244(.A(new_n69_), .B(new_n300_), .Y(G1885));
  XNOR2x2_ASAP7_75t_R g245(.A(new_n80_), .B(new_n300_), .Y(G1886));
  XNOR2x2_ASAP7_75t_R g246(.A(new_n85_), .B(new_n300_), .Y(G1887));
  AO21x1_ASAP7_75t_R  g247(.A1(new_n81_), .A2(new_n148_), .B(G30), .Y(new_n306_));
  AO21x1_ASAP7_75t_R  g248(.A1(new_n84_), .A2(new_n306_), .B(G33), .Y(new_n307_));
  AO21x1_ASAP7_75t_R  g249(.A1(G32), .A2(new_n307_), .B(new_n152_), .Y(new_n308_));
  OR3x1_ASAP7_75t_R   g250(.A(new_n146_), .B(new_n308_), .C(new_n77_), .Y(new_n309_));
  OR3x1_ASAP7_75t_R   g251(.A(new_n145_), .B(new_n308_), .C(G27), .Y(new_n310_));
  AND2x2_ASAP7_75t_R  g252(.A(new_n309_), .B(new_n310_), .Y(new_n311_));
  OR3x1_ASAP7_75t_R   g253(.A(new_n109_), .B(new_n311_), .C(new_n78_), .Y(new_n312_));
  OR3x1_ASAP7_75t_R   g254(.A(new_n110_), .B(new_n311_), .C(G28), .Y(new_n313_));
  NAND2x1_ASAP7_75t_R g255(.A(new_n312_), .B(new_n313_), .Y(new_n314_));
  INVx1_ASAP7_75t_R   g256(.A(new_n314_), .Y(new_n315_));
  OR3x1_ASAP7_75t_R   g257(.A(new_n271_), .B(new_n299_), .C(new_n315_), .Y(new_n316_));
  XNOR2x2_ASAP7_75t_R g258(.A(new_n60_), .B(new_n316_), .Y(G1888));
  XNOR2x2_ASAP7_75t_R g259(.A(new_n64_), .B(new_n316_), .Y(G1889));
  XNOR2x2_ASAP7_75t_R g260(.A(new_n65_), .B(new_n316_), .Y(G1890));
  NAND2x1_ASAP7_75t_R g261(.A(new_n272_), .B(new_n296_), .Y(new_n320_));
  OR3x1_ASAP7_75t_R   g262(.A(new_n160_), .B(new_n320_), .C(new_n298_), .Y(new_n321_));
  INVx1_ASAP7_75t_R   g263(.A(new_n321_), .Y(new_n322_));
  AO21x1_ASAP7_75t_R  g264(.A1(new_n272_), .A2(new_n295_), .B(new_n271_), .Y(new_n323_));
  AO21x1_ASAP7_75t_R  g265(.A1(new_n159_), .A2(new_n323_), .B(new_n160_), .Y(new_n324_));
  AOI21x1_ASAP7_75t_R g266(.A1(new_n297_), .A2(new_n324_), .B(new_n298_), .Y(new_n325_));
  NOR2x1_ASAP7_75t_R  g267(.A(G5), .B(new_n325_), .Y(new_n326_));
  AO21x1_ASAP7_75t_R  g268(.A1(G5), .A2(new_n322_), .B(new_n326_), .Y(G1891));
  NOR2x1_ASAP7_75t_R  g269(.A(G6), .B(new_n325_), .Y(new_n328_));
  AO21x1_ASAP7_75t_R  g270(.A1(G6), .A2(new_n322_), .B(new_n328_), .Y(G1892));
  NOR2x1_ASAP7_75t_R  g271(.A(G7), .B(new_n325_), .Y(new_n330_));
  AO21x1_ASAP7_75t_R  g272(.A1(G7), .A2(new_n322_), .B(new_n330_), .Y(G1893));
  NOR2x1_ASAP7_75t_R  g273(.A(G8), .B(new_n325_), .Y(new_n332_));
  AO21x1_ASAP7_75t_R  g274(.A1(G8), .A2(new_n322_), .B(new_n332_), .Y(G1894));
  OR3x1_ASAP7_75t_R   g275(.A(new_n315_), .B(new_n320_), .C(new_n298_), .Y(new_n334_));
  INVx1_ASAP7_75t_R   g276(.A(new_n334_), .Y(new_n335_));
  NAND2x1_ASAP7_75t_R g277(.A(new_n314_), .B(new_n323_), .Y(new_n336_));
  AO21x1_ASAP7_75t_R  g278(.A1(new_n314_), .A2(new_n336_), .B(new_n298_), .Y(new_n337_));
  AOI21x1_ASAP7_75t_R g279(.A1(new_n297_), .A2(new_n337_), .B(G9), .Y(new_n338_));
  AO21x1_ASAP7_75t_R  g280(.A1(G9), .A2(new_n335_), .B(new_n338_), .Y(G1895));
  OR3x1_ASAP7_75t_R   g281(.A(new_n217_), .B(new_n262_), .C(new_n76_), .Y(new_n340_));
  OR3x1_ASAP7_75t_R   g282(.A(new_n216_), .B(new_n262_), .C(G26), .Y(new_n341_));
  AND2x2_ASAP7_75t_R  g283(.A(new_n340_), .B(new_n341_), .Y(new_n342_));
  OR3x1_ASAP7_75t_R   g284(.A(new_n68_), .B(new_n161_), .C(new_n342_), .Y(new_n343_));
  OR3x1_ASAP7_75t_R   g285(.A(new_n162_), .B(new_n342_), .C(new_n181_), .Y(new_n344_));
  OA21x2_ASAP7_75t_R  g286(.A1(new_n182_), .A2(new_n343_), .B(new_n344_), .Y(new_n345_));
  INVx1_ASAP7_75t_R   g287(.A(new_n345_), .Y(new_n346_));
  OR3x1_ASAP7_75t_R   g288(.A(new_n67_), .B(new_n219_), .C(new_n299_), .Y(new_n347_));
  OR3x1_ASAP7_75t_R   g289(.A(new_n345_), .B(new_n347_), .C(new_n315_), .Y(new_n348_));
  INVx1_ASAP7_75t_R   g290(.A(new_n348_), .Y(new_n349_));
  AO21x1_ASAP7_75t_R  g291(.A1(new_n346_), .A2(new_n347_), .B(new_n345_), .Y(new_n350_));
  AOI21x1_ASAP7_75t_R g292(.A1(new_n314_), .A2(new_n350_), .B(new_n315_), .Y(new_n351_));
  NOR2x1_ASAP7_75t_R  g293(.A(G11), .B(new_n351_), .Y(new_n352_));
  AO21x1_ASAP7_75t_R  g294(.A1(G11), .A2(new_n349_), .B(new_n352_), .Y(G1896));
  NOR2x1_ASAP7_75t_R  g295(.A(G12), .B(new_n351_), .Y(new_n354_));
  AO21x1_ASAP7_75t_R  g296(.A1(G12), .A2(new_n349_), .B(new_n354_), .Y(G1897));
  NOR2x1_ASAP7_75t_R  g297(.A(G13), .B(new_n351_), .Y(new_n356_));
  AO21x1_ASAP7_75t_R  g298(.A1(G13), .A2(new_n349_), .B(new_n356_), .Y(G1898));
  NOR2x1_ASAP7_75t_R  g299(.A(G14), .B(new_n351_), .Y(new_n358_));
  AO21x1_ASAP7_75t_R  g300(.A1(G14), .A2(new_n349_), .B(new_n358_), .Y(G1899));
  NOR2x1_ASAP7_75t_R  g301(.A(new_n296_), .B(new_n298_), .Y(new_n360_));
  AOI21x1_ASAP7_75t_R g302(.A1(new_n159_), .A2(new_n360_), .B(new_n160_), .Y(new_n361_));
  NOR2x1_ASAP7_75t_R  g303(.A(new_n314_), .B(new_n361_), .Y(new_n362_));
  AO21x1_ASAP7_75t_R  g304(.A1(new_n314_), .A2(new_n360_), .B(new_n362_), .Y(new_n363_));
  AO21x1_ASAP7_75t_R  g305(.A1(new_n272_), .A2(new_n363_), .B(new_n271_), .Y(new_n364_));
  INVx1_ASAP7_75t_R   g306(.A(new_n364_), .Y(new_n365_));
  AO21x1_ASAP7_75t_R  g307(.A1(G18), .A2(new_n218_), .B(new_n297_), .Y(new_n366_));
  OR3x1_ASAP7_75t_R   g308(.A(new_n146_), .B(new_n366_), .C(new_n77_), .Y(new_n367_));
  OR3x1_ASAP7_75t_R   g309(.A(new_n145_), .B(new_n366_), .C(G27), .Y(new_n368_));
  AND2x2_ASAP7_75t_R  g310(.A(new_n367_), .B(new_n368_), .Y(new_n369_));
  OR3x1_ASAP7_75t_R   g311(.A(new_n109_), .B(new_n369_), .C(new_n78_), .Y(new_n370_));
  OR3x1_ASAP7_75t_R   g312(.A(new_n110_), .B(new_n369_), .C(G28), .Y(new_n371_));
  AND2x2_ASAP7_75t_R  g313(.A(new_n370_), .B(new_n371_), .Y(new_n372_));
  OR3x1_ASAP7_75t_R   g314(.A(new_n295_), .B(new_n345_), .C(new_n372_), .Y(new_n373_));
  OAI21x1_ASAP7_75t_R g315(.A1(new_n365_), .A2(new_n373_), .B(new_n364_), .Y(new_n374_));
  NOR2x1_ASAP7_75t_R  g316(.A(G32), .B(new_n373_), .Y(new_n375_));
  AO21x1_ASAP7_75t_R  g317(.A1(G32), .A2(new_n374_), .B(new_n375_), .Y(new_n376_));
  AO21x1_ASAP7_75t_R  g318(.A1(new_n84_), .A2(new_n376_), .B(G33), .Y(G1900));
  XNOR2x2_ASAP7_75t_R g319(.A(new_n190_), .B(new_n247_), .Y(new_n378_));
  XOR2x2_ASAP7_75t_R  g320(.A(new_n234_), .B(new_n378_), .Y(new_n379_));
  NOR2x1_ASAP7_75t_R  g321(.A(G32), .B(G33), .Y(new_n380_));
  AO21x1_ASAP7_75t_R  g322(.A1(G17), .A2(new_n364_), .B(new_n66_), .Y(new_n381_));
  AO21x1_ASAP7_75t_R  g323(.A1(G24), .A2(new_n381_), .B(new_n74_), .Y(new_n382_));
  OA21x2_ASAP7_75t_R  g324(.A1(G32), .A2(G33), .B(new_n382_), .Y(new_n383_));
  OR3x1_ASAP7_75t_R   g325(.A(new_n66_), .B(new_n364_), .C(new_n74_), .Y(new_n384_));
  OR3x1_ASAP7_75t_R   g326(.A(new_n380_), .B(new_n384_), .C(new_n379_), .Y(new_n385_));
  INVx1_ASAP7_75t_R   g327(.A(new_n385_), .Y(new_n386_));
  AO21x1_ASAP7_75t_R  g328(.A1(new_n379_), .A2(new_n383_), .B(new_n386_), .Y(G1901));
  OA21x2_ASAP7_75t_R  g329(.A1(new_n75_), .A2(new_n365_), .B(G25), .Y(new_n388_));
  OR3x1_ASAP7_75t_R   g330(.A(new_n380_), .B(new_n388_), .C(new_n292_), .Y(new_n389_));
  OR3x1_ASAP7_75t_R   g331(.A(new_n75_), .B(new_n364_), .C(new_n380_), .Y(new_n390_));
  OAI21x1_ASAP7_75t_R g332(.A1(new_n291_), .A2(new_n390_), .B(new_n389_), .Y(G1902));
  XOR2x2_ASAP7_75t_R  g333(.A(new_n122_), .B(new_n127_), .Y(new_n392_));
  INVx1_ASAP7_75t_R   g334(.A(new_n392_), .Y(new_n393_));
  XOR2x2_ASAP7_75t_R  g335(.A(new_n122_), .B(new_n126_), .Y(new_n394_));
  INVx1_ASAP7_75t_R   g336(.A(new_n394_), .Y(new_n395_));
  NOR2x1_ASAP7_75t_R  g337(.A(G5), .B(new_n394_), .Y(new_n396_));
  AO21x1_ASAP7_75t_R  g338(.A1(G5), .A2(new_n393_), .B(new_n396_), .Y(new_n397_));
  NOR2x1_ASAP7_75t_R  g339(.A(G5), .B(new_n392_), .Y(new_n398_));
  AO21x1_ASAP7_75t_R  g340(.A1(G5), .A2(new_n395_), .B(new_n398_), .Y(new_n399_));
  AND2x2_ASAP7_75t_R  g341(.A(new_n69_), .B(new_n399_), .Y(new_n400_));
  AO21x1_ASAP7_75t_R  g342(.A1(G2), .A2(new_n397_), .B(new_n400_), .Y(new_n401_));
  AND2x2_ASAP7_75t_R  g343(.A(new_n69_), .B(new_n397_), .Y(new_n402_));
  AOI21x1_ASAP7_75t_R g344(.A1(G2), .A2(new_n399_), .B(new_n402_), .Y(new_n403_));
  NOR2x1_ASAP7_75t_R  g345(.A(G8), .B(new_n403_), .Y(new_n404_));
  AO21x1_ASAP7_75t_R  g346(.A1(G8), .A2(new_n401_), .B(new_n404_), .Y(new_n405_));
  INVx1_ASAP7_75t_R   g347(.A(new_n405_), .Y(new_n406_));
  OA21x2_ASAP7_75t_R  g348(.A1(new_n364_), .A2(new_n405_), .B(new_n406_), .Y(new_n407_));
  NOR2x1_ASAP7_75t_R  g349(.A(new_n380_), .B(new_n407_), .Y(G1903));
  OR3x1_ASAP7_75t_R   g350(.A(G23), .B(new_n83_), .C(new_n68_), .Y(new_n409_));
  OR3x1_ASAP7_75t_R   g351(.A(G33), .B(new_n409_), .C(new_n103_), .Y(new_n410_));
  INVx1_ASAP7_75t_R   g352(.A(new_n410_), .Y(new_n411_));
  AND3x1_ASAP7_75t_R  g353(.A(G23), .B(G32), .C(G19), .Y(new_n412_));
  AO21x1_ASAP7_75t_R  g354(.A1(new_n68_), .A2(G32), .B(new_n412_), .Y(new_n413_));
  AO21x1_ASAP7_75t_R  g355(.A1(new_n84_), .A2(new_n413_), .B(G33), .Y(new_n414_));
  AO21x1_ASAP7_75t_R  g356(.A1(new_n103_), .A2(new_n414_), .B(new_n411_), .Y(new_n415_));
  AO21x1_ASAP7_75t_R  g357(.A1(G32), .A2(new_n84_), .B(G33), .Y(new_n416_));
  AND2x2_ASAP7_75t_R  g358(.A(new_n365_), .B(new_n416_), .Y(new_n417_));
  AO21x1_ASAP7_75t_R  g359(.A1(new_n364_), .A2(new_n415_), .B(new_n417_), .Y(G1904));
  XOR2x2_ASAP7_75t_R  g360(.A(new_n127_), .B(new_n167_), .Y(new_n419_));
  NOR2x1_ASAP7_75t_R  g361(.A(new_n85_), .B(new_n419_), .Y(new_n420_));
  XNOR2x2_ASAP7_75t_R g362(.A(new_n126_), .B(new_n167_), .Y(new_n421_));
  AO21x1_ASAP7_75t_R  g363(.A1(new_n85_), .A2(new_n421_), .B(new_n420_), .Y(new_n422_));
  NOR2x1_ASAP7_75t_R  g364(.A(G4), .B(new_n419_), .Y(new_n423_));
  AO21x1_ASAP7_75t_R  g365(.A1(G4), .A2(new_n421_), .B(new_n423_), .Y(new_n424_));
  AND2x2_ASAP7_75t_R  g366(.A(new_n60_), .B(new_n424_), .Y(new_n425_));
  AO21x1_ASAP7_75t_R  g367(.A1(G10), .A2(new_n422_), .B(new_n425_), .Y(new_n426_));
  AND2x2_ASAP7_75t_R  g368(.A(new_n60_), .B(new_n422_), .Y(new_n427_));
  AOI21x1_ASAP7_75t_R g369(.A1(G10), .A2(new_n424_), .B(new_n427_), .Y(new_n428_));
  NOR2x1_ASAP7_75t_R  g370(.A(G7), .B(new_n428_), .Y(new_n429_));
  AO21x1_ASAP7_75t_R  g371(.A1(G7), .A2(new_n426_), .B(new_n429_), .Y(new_n430_));
  INVx1_ASAP7_75t_R   g372(.A(new_n430_), .Y(new_n431_));
  OA21x2_ASAP7_75t_R  g373(.A1(new_n364_), .A2(new_n431_), .B(new_n430_), .Y(new_n432_));
  NOR2x1_ASAP7_75t_R  g374(.A(new_n380_), .B(new_n432_), .Y(G1905));
  AND3x1_ASAP7_75t_R  g375(.A(new_n71_), .B(G29), .C(new_n84_), .Y(new_n434_));
  OR3x1_ASAP7_75t_R   g376(.A(new_n71_), .B(new_n79_), .C(G33), .Y(new_n435_));
  AOI21x1_ASAP7_75t_R g377(.A1(new_n84_), .A2(new_n435_), .B(new_n378_), .Y(new_n436_));
  AO21x1_ASAP7_75t_R  g378(.A1(new_n378_), .A2(new_n434_), .B(new_n436_), .Y(new_n437_));
  AO21x1_ASAP7_75t_R  g379(.A1(new_n71_), .A2(new_n79_), .B(G21), .Y(new_n438_));
  AO21x1_ASAP7_75t_R  g380(.A1(new_n84_), .A2(new_n438_), .B(G33), .Y(new_n439_));
  NAND2x1_ASAP7_75t_R g381(.A(new_n378_), .B(new_n439_), .Y(new_n440_));
  OA21x2_ASAP7_75t_R  g382(.A1(new_n71_), .A2(G29), .B(G21), .Y(new_n441_));
  OR3x1_ASAP7_75t_R   g383(.A(G33), .B(new_n441_), .C(new_n378_), .Y(new_n442_));
  AOI21x1_ASAP7_75t_R g384(.A1(new_n440_), .A2(new_n442_), .B(new_n301_), .Y(new_n443_));
  AO21x1_ASAP7_75t_R  g385(.A1(new_n301_), .A2(new_n437_), .B(new_n443_), .Y(G1906));
  AO21x1_ASAP7_75t_R  g386(.A1(new_n72_), .A2(G33), .B(G22), .Y(new_n445_));
  NOR2x1_ASAP7_75t_R  g387(.A(G30), .B(new_n84_), .Y(new_n446_));
  AO21x1_ASAP7_75t_R  g388(.A1(G30), .A2(new_n445_), .B(new_n446_), .Y(new_n447_));
  OR3x1_ASAP7_75t_R   g389(.A(G22), .B(G33), .C(new_n81_), .Y(new_n448_));
  NOR2x1_ASAP7_75t_R  g390(.A(new_n208_), .B(new_n448_), .Y(new_n449_));
  AO21x1_ASAP7_75t_R  g391(.A1(new_n208_), .A2(new_n447_), .B(new_n449_), .Y(new_n450_));
  NOR2x1_ASAP7_75t_R  g392(.A(new_n209_), .B(new_n448_), .Y(new_n451_));
  AO21x1_ASAP7_75t_R  g393(.A1(new_n209_), .A2(new_n447_), .B(new_n451_), .Y(new_n452_));
  AND2x2_ASAP7_75t_R  g394(.A(new_n63_), .B(new_n452_), .Y(new_n453_));
  AO21x1_ASAP7_75t_R  g395(.A1(G14), .A2(new_n450_), .B(new_n453_), .Y(new_n454_));
  NAND2x1_ASAP7_75t_R g396(.A(G9), .B(new_n454_), .Y(new_n455_));
  AND2x2_ASAP7_75t_R  g397(.A(new_n63_), .B(new_n450_), .Y(new_n456_));
  AOI21x1_ASAP7_75t_R g398(.A1(G14), .A2(new_n452_), .B(new_n456_), .Y(new_n457_));
  OA21x2_ASAP7_75t_R  g399(.A1(G9), .A2(new_n457_), .B(new_n455_), .Y(new_n458_));
  XNOR2x2_ASAP7_75t_R g400(.A(new_n316_), .B(new_n458_), .Y(G1907));
  XNOR2x2_ASAP7_75t_R g401(.A(new_n190_), .B(new_n208_), .Y(new_n460_));
  NAND2x1_ASAP7_75t_R g402(.A(new_n185_), .B(new_n460_), .Y(new_n461_));
  XOR2x2_ASAP7_75t_R  g403(.A(new_n190_), .B(new_n209_), .Y(new_n462_));
  OA21x2_ASAP7_75t_R  g404(.A1(new_n185_), .A2(new_n462_), .B(new_n461_), .Y(new_n463_));
  OR3x1_ASAP7_75t_R   g405(.A(new_n365_), .B(new_n380_), .C(new_n463_), .Y(new_n464_));
  INVx1_ASAP7_75t_R   g406(.A(new_n464_), .Y(G1908));
endmodule


