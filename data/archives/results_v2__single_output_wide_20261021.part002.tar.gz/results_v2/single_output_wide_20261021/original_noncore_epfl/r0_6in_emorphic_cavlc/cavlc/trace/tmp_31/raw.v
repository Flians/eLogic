// Benchmark "/tmp/" written by ABC on Wed Oct 21 14:26:18 2026

module \/tmp/  ( 
    p3, p6, p5, p7, p8, p9, p1, p4, p0, p2,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10  );
  input  p3, p6, p5, p7, p8, p9, p1, p4, p0, p2;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10;
  wire new_n22_, new_n23_, new_n24_, new_n25_, new_n26_, new_n27_, new_n28_,
    new_n29_, new_n30_, new_n31_, new_n32_, new_n33_, new_n34_, new_n35_,
    new_n36_, new_n37_, new_n38_, new_n39_, new_n40_, new_n41_, new_n42_,
    new_n43_, new_n44_, new_n45_, new_n46_, new_n47_, new_n48_, new_n49_,
    new_n50_, new_n51_, new_n52_, new_n53_, new_n54_, new_n55_, new_n56_,
    new_n57_, new_n58_, new_n59_, new_n60_, new_n61_, new_n62_, new_n63_,
    new_n64_, new_n65_, new_n66_, new_n67_, new_n68_, new_n69_, new_n70_,
    new_n71_, new_n72_, new_n73_, new_n74_, new_n75_, new_n76_, new_n77_,
    new_n78_, new_n79_, new_n80_, new_n81_, new_n82_, new_n83_, new_n84_,
    new_n85_, new_n86_, new_n87_, new_n88_, new_n89_, new_n90_, new_n91_,
    new_n92_, new_n93_, new_n94_, new_n95_, new_n96_, new_n97_, new_n98_,
    new_n99_, new_n100_, new_n101_, new_n102_, new_n103_, new_n104_,
    new_n105_, new_n106_, new_n107_, new_n108_, new_n109_, new_n110_,
    new_n111_, new_n112_, new_n113_, new_n114_, new_n116_, new_n117_,
    new_n118_, new_n119_, new_n120_, new_n121_, new_n122_, new_n123_,
    new_n124_, new_n125_, new_n126_, new_n127_, new_n128_, new_n129_,
    new_n130_, new_n131_, new_n132_, new_n133_, new_n134_, new_n135_,
    new_n136_, new_n137_, new_n138_, new_n139_, new_n140_, new_n141_,
    new_n142_, new_n143_, new_n144_, new_n145_, new_n146_, new_n147_,
    new_n148_, new_n149_, new_n150_, new_n151_, new_n152_, new_n153_,
    new_n154_, new_n155_, new_n156_, new_n157_, new_n158_, new_n159_,
    new_n160_, new_n161_, new_n162_, new_n163_, new_n164_, new_n165_,
    new_n166_, new_n167_, new_n168_, new_n169_, new_n170_, new_n171_,
    new_n172_, new_n173_, new_n174_, new_n175_, new_n176_, new_n177_,
    new_n178_, new_n179_, new_n180_, new_n181_, new_n182_, new_n183_,
    new_n184_, new_n185_, new_n186_, new_n187_, new_n188_, new_n189_,
    new_n191_, new_n192_, new_n193_, new_n194_, new_n195_, new_n196_,
    new_n197_, new_n198_, new_n199_, new_n200_, new_n201_, new_n202_,
    new_n203_, new_n204_, new_n205_, new_n206_, new_n207_, new_n208_,
    new_n209_, new_n210_, new_n211_, new_n212_, new_n213_, new_n214_,
    new_n215_, new_n216_, new_n217_, new_n218_, new_n219_, new_n220_,
    new_n221_, new_n222_, new_n223_, new_n224_, new_n225_, new_n226_,
    new_n227_, new_n228_, new_n229_, new_n230_, new_n231_, new_n232_,
    new_n233_, new_n234_, new_n235_, new_n236_, new_n237_, new_n238_,
    new_n239_, new_n240_, new_n242_, new_n243_, new_n244_, new_n245_,
    new_n246_, new_n247_, new_n248_, new_n249_, new_n250_, new_n251_,
    new_n252_, new_n253_, new_n254_, new_n255_, new_n256_, new_n257_,
    new_n258_, new_n259_, new_n260_, new_n261_, new_n262_, new_n263_,
    new_n264_, new_n265_, new_n266_, new_n267_, new_n268_, new_n269_,
    new_n270_, new_n271_, new_n272_, new_n273_, new_n274_, new_n275_,
    new_n276_, new_n277_, new_n279_, new_n280_, new_n281_, new_n282_,
    new_n283_, new_n285_, new_n286_, new_n288_, new_n289_, new_n290_,
    new_n291_, new_n292_, new_n293_, new_n294_, new_n295_, new_n296_,
    new_n297_, new_n298_, new_n299_, new_n300_, new_n301_, new_n302_,
    new_n303_, new_n304_, new_n305_, new_n306_, new_n307_, new_n308_,
    new_n309_, new_n310_, new_n311_, new_n312_, new_n313_, new_n314_,
    new_n315_, new_n316_, new_n317_, new_n318_, new_n319_, new_n320_,
    new_n321_, new_n322_, new_n323_, new_n325_, new_n326_, new_n327_,
    new_n328_, new_n329_, new_n330_, new_n331_, new_n332_, new_n333_,
    new_n334_, new_n335_, new_n336_, new_n337_, new_n338_, new_n339_,
    new_n340_, new_n341_, new_n342_, new_n343_, new_n344_, new_n345_,
    new_n346_, new_n347_, new_n348_, new_n349_, new_n350_, new_n351_,
    new_n352_, new_n353_, new_n354_, new_n355_, new_n356_, new_n357_,
    new_n358_, new_n359_, new_n360_, new_n361_, new_n362_, new_n363_,
    new_n364_, new_n365_, new_n367_, new_n368_, new_n369_, new_n370_,
    new_n371_, new_n372_, new_n373_, new_n374_, new_n375_, new_n376_,
    new_n377_, new_n378_, new_n379_, new_n380_, new_n381_, new_n382_,
    new_n383_, new_n384_, new_n385_, new_n386_, new_n387_, new_n388_,
    new_n389_, new_n390_, new_n391_, new_n392_, new_n393_, new_n394_,
    new_n395_, new_n396_, new_n397_, new_n399_, new_n400_, new_n401_,
    new_n402_, new_n403_, new_n404_, new_n405_, new_n406_, new_n407_,
    new_n408_, new_n409_, new_n410_, new_n411_, new_n412_, new_n413_,
    new_n414_, new_n415_, new_n416_, new_n418_, new_n419_, new_n420_;
  INVx1_ASAP7_75t_R    g000(.A(p0), .Y(new_n22_));
  INVx1_ASAP7_75t_R    g001(.A(p7), .Y(new_n23_));
  INVx1_ASAP7_75t_R    g002(.A(p9), .Y(new_n24_));
  NAND2x1_ASAP7_75t_R  g003(.A(new_n23_), .B(new_n24_), .Y(new_n25_));
  NAND2x1_ASAP7_75t_R  g004(.A(p8), .B(new_n24_), .Y(new_n26_));
  NAND2x1_ASAP7_75t_R  g005(.A(p2), .B(new_n23_), .Y(new_n27_));
  AO21x1_ASAP7_75t_R   g006(.A1(new_n22_), .A2(new_n26_), .B(new_n27_), .Y(new_n28_));
  OA21x2_ASAP7_75t_R   g007(.A1(new_n22_), .A2(new_n25_), .B(new_n28_), .Y(new_n29_));
  AND2x2_ASAP7_75t_R   g008(.A(p8), .B(p1), .Y(new_n30_));
  INVx1_ASAP7_75t_R    g009(.A(p5), .Y(new_n31_));
  NAND2x1_ASAP7_75t_R  g010(.A(p2), .B(new_n31_), .Y(new_n32_));
  NAND2x1_ASAP7_75t_R  g011(.A(p1), .B(p2), .Y(new_n33_));
  NOR2x1_ASAP7_75t_R   g012(.A(p8), .B(p0), .Y(new_n34_));
  AND3x1_ASAP7_75t_R   g013(.A(new_n32_), .B(new_n33_), .C(new_n34_), .Y(new_n35_));
  OAI21x1_ASAP7_75t_R  g014(.A1(new_n30_), .A2(new_n35_), .B(new_n23_), .Y(new_n36_));
  INVx1_ASAP7_75t_R    g015(.A(p8), .Y(new_n37_));
  AND4x2_ASAP7_75t_R   g016(.A(new_n37_), .B(new_n22_), .C(p9), .D(p1), .Y(new_n38_));
  NOR2x1_ASAP7_75t_R   g017(.A(p0), .B(new_n37_), .Y(new_n39_));
  INVx1_ASAP7_75t_R    g018(.A(p1), .Y(new_n40_));
  NOR2x1_ASAP7_75t_R   g019(.A(p2), .B(new_n40_), .Y(new_n41_));
  AND3x1_ASAP7_75t_R   g020(.A(new_n39_), .B(new_n41_), .C(new_n24_), .Y(new_n42_));
  AOI21x1_ASAP7_75t_R  g021(.A1(p2), .A2(new_n38_), .B(new_n42_), .Y(new_n43_));
  AO31x2_ASAP7_75t_R   g022(.A1(new_n29_), .A2(new_n36_), .A3(new_n43_), .B(p4), .Y(new_n44_));
  NOR2x1_ASAP7_75t_R   g023(.A(p2), .B(new_n22_), .Y(new_n45_));
  AO21x1_ASAP7_75t_R   g024(.A1(p9), .A2(new_n37_), .B(p1), .Y(new_n46_));
  AO21x1_ASAP7_75t_R   g025(.A1(new_n26_), .A2(new_n45_), .B(new_n46_), .Y(new_n47_));
  NAND2x1_ASAP7_75t_R  g026(.A(p7), .B(p4), .Y(new_n48_));
  AOI21x1_ASAP7_75t_R  g027(.A1(new_n31_), .A2(new_n46_), .B(new_n48_), .Y(new_n49_));
  AO21x1_ASAP7_75t_R   g028(.A1(p8), .A2(new_n22_), .B(p4), .Y(new_n50_));
  AO21x1_ASAP7_75t_R   g029(.A1(new_n24_), .A2(new_n40_), .B(p4), .Y(new_n51_));
  NOR2x1_ASAP7_75t_R   g030(.A(p9), .B(new_n37_), .Y(new_n52_));
  NOR2x1_ASAP7_75t_R   g031(.A(p8), .B(new_n24_), .Y(new_n53_));
  NOR2x1_ASAP7_75t_R   g032(.A(new_n52_), .B(new_n53_), .Y(new_n54_));
  AND3x1_ASAP7_75t_R   g033(.A(p1), .B(p4), .C(p0), .Y(new_n55_));
  AO32x1_ASAP7_75t_R   g034(.A1(p5), .A2(new_n50_), .A3(new_n51_), .B1(new_n54_), .B2(new_n55_), .Y(new_n56_));
  AND2x2_ASAP7_75t_R   g035(.A(p7), .B(p2), .Y(new_n57_));
  NOR2x1_ASAP7_75t_R   g036(.A(p8), .B(p1), .Y(new_n58_));
  AO21x1_ASAP7_75t_R   g037(.A1(p0), .A2(new_n58_), .B(new_n30_), .Y(new_n59_));
  INVx1_ASAP7_75t_R    g038(.A(p2), .Y(new_n60_));
  AND3x1_ASAP7_75t_R   g039(.A(new_n24_), .B(new_n60_), .C(p5), .Y(new_n61_));
  NOR2x1_ASAP7_75t_R   g040(.A(p7), .B(p8), .Y(new_n62_));
  NOR2x1_ASAP7_75t_R   g041(.A(p1), .B(p2), .Y(new_n63_));
  AND3x1_ASAP7_75t_R   g042(.A(new_n63_), .B(new_n24_), .C(new_n22_), .Y(new_n64_));
  AO32x1_ASAP7_75t_R   g043(.A1(new_n59_), .A2(p7), .A3(new_n61_), .B1(new_n62_), .B2(new_n64_), .Y(new_n65_));
  AOI221x1_ASAP7_75t_R g044(.A1(new_n47_), .A2(new_n49_), .B1(new_n56_), .B2(new_n57_), .C(new_n65_), .Y(new_n66_));
  NOR2x1_ASAP7_75t_R   g045(.A(p3), .B(p6), .Y(new_n67_));
  INVx1_ASAP7_75t_R    g046(.A(new_n67_), .Y(new_n68_));
  AO21x1_ASAP7_75t_R   g047(.A1(new_n44_), .A2(new_n66_), .B(new_n68_), .Y(new_n69_));
  NAND2x1_ASAP7_75t_R  g048(.A(p9), .B(p2), .Y(new_n70_));
  INVx1_ASAP7_75t_R    g049(.A(new_n45_), .Y(new_n71_));
  OA21x2_ASAP7_75t_R   g050(.A1(p0), .A2(new_n70_), .B(new_n71_), .Y(new_n72_));
  NOR2x1_ASAP7_75t_R   g051(.A(p1), .B(p4), .Y(new_n73_));
  NAND2x1_ASAP7_75t_R  g052(.A(p1), .B(p0), .Y(new_n74_));
  OA21x2_ASAP7_75t_R   g053(.A1(p9), .A2(new_n73_), .B(new_n74_), .Y(new_n75_));
  NAND2x1_ASAP7_75t_R  g054(.A(p8), .B(new_n22_), .Y(new_n76_));
  OA22x2_ASAP7_75t_R   g055(.A1(new_n75_), .A2(p8), .B1(new_n76_), .B2(new_n63_), .Y(new_n77_));
  AOI211x1_ASAP7_75t_R g056(.A1(new_n72_), .A2(new_n77_), .B(p6), .C(p7), .Y(new_n78_));
  INVx1_ASAP7_75t_R    g057(.A(p6), .Y(new_n79_));
  INVx1_ASAP7_75t_R    g058(.A(p4), .Y(new_n80_));
  NAND2x1_ASAP7_75t_R  g059(.A(new_n37_), .B(new_n80_), .Y(new_n81_));
  NAND2x1_ASAP7_75t_R  g060(.A(p9), .B(new_n40_), .Y(new_n82_));
  AO21x1_ASAP7_75t_R   g061(.A1(p6), .A2(new_n81_), .B(new_n82_), .Y(new_n83_));
  NAND2x1_ASAP7_75t_R  g062(.A(p7), .B(new_n80_), .Y(new_n84_));
  AO32x1_ASAP7_75t_R   g063(.A1(new_n79_), .A2(new_n37_), .A3(p0), .B1(new_n83_), .B2(new_n84_), .Y(new_n85_));
  AO21x1_ASAP7_75t_R   g064(.A1(new_n22_), .A2(new_n81_), .B(new_n82_), .Y(new_n86_));
  INVx1_ASAP7_75t_R    g065(.A(new_n34_), .Y(new_n87_));
  NAND2x1_ASAP7_75t_R  g066(.A(p1), .B(new_n24_), .Y(new_n88_));
  OR3x1_ASAP7_75t_R    g067(.A(new_n87_), .B(new_n88_), .C(new_n79_), .Y(new_n89_));
  AO21x1_ASAP7_75t_R   g068(.A1(new_n86_), .A2(new_n89_), .B(p2), .Y(new_n90_));
  AO21x1_ASAP7_75t_R   g069(.A1(p8), .A2(new_n24_), .B(new_n22_), .Y(new_n91_));
  NOR2x1_ASAP7_75t_R   g070(.A(p4), .B(p2), .Y(new_n92_));
  AND3x1_ASAP7_75t_R   g071(.A(new_n91_), .B(new_n76_), .C(new_n92_), .Y(new_n93_));
  NAND2x1_ASAP7_75t_R  g072(.A(p8), .B(p0), .Y(new_n94_));
  NAND2x1_ASAP7_75t_R  g073(.A(new_n94_), .B(new_n87_), .Y(new_n95_));
  NOR2x1_ASAP7_75t_R   g074(.A(p9), .B(p0), .Y(new_n96_));
  INVx1_ASAP7_75t_R    g075(.A(new_n96_), .Y(new_n97_));
  AND3x1_ASAP7_75t_R   g076(.A(new_n95_), .B(new_n79_), .C(new_n97_), .Y(new_n98_));
  NOR2x1_ASAP7_75t_R   g077(.A(p7), .B(p1), .Y(new_n99_));
  OAI21x1_ASAP7_75t_R  g078(.A1(new_n93_), .A2(new_n98_), .B(new_n99_), .Y(new_n100_));
  OAI21x1_ASAP7_75t_R  g079(.A1(new_n85_), .A2(new_n90_), .B(new_n100_), .Y(new_n101_));
  NOR2x1_ASAP7_75t_R   g080(.A(p3), .B(p5), .Y(new_n102_));
  OAI21x1_ASAP7_75t_R  g081(.A1(new_n78_), .A2(new_n101_), .B(new_n102_), .Y(new_n103_));
  NAND2x1_ASAP7_75t_R  g082(.A(p5), .B(p4), .Y(new_n104_));
  INVx1_ASAP7_75t_R    g083(.A(new_n104_), .Y(new_n105_));
  NOR2x1_ASAP7_75t_R   g084(.A(p7), .B(new_n80_), .Y(new_n106_));
  NOR2x1_ASAP7_75t_R   g085(.A(p5), .B(p8), .Y(new_n107_));
  AND2x2_ASAP7_75t_R   g086(.A(p3), .B(p7), .Y(new_n108_));
  OA22x2_ASAP7_75t_R   g087(.A1(new_n105_), .A2(new_n106_), .B1(new_n107_), .B2(new_n108_), .Y(new_n109_));
  AND2x2_ASAP7_75t_R   g088(.A(p3), .B(p8), .Y(new_n110_));
  AO21x1_ASAP7_75t_R   g089(.A1(p5), .A2(new_n37_), .B(new_n110_), .Y(new_n111_));
  AND3x1_ASAP7_75t_R   g090(.A(new_n111_), .B(new_n23_), .C(new_n104_), .Y(new_n112_));
  AND3x1_ASAP7_75t_R   g091(.A(new_n96_), .B(new_n63_), .C(new_n79_), .Y(new_n113_));
  OAI21x1_ASAP7_75t_R  g092(.A1(new_n109_), .A2(new_n112_), .B(new_n113_), .Y(new_n114_));
  NAND3x1_ASAP7_75t_R  g093(.A(new_n69_), .B(new_n103_), .C(new_n114_), .Y(o0));
  NAND2x1_ASAP7_75t_R  g094(.A(new_n79_), .B(new_n60_), .Y(new_n116_));
  AND2x2_ASAP7_75t_R   g095(.A(p7), .B(p1), .Y(new_n117_));
  NAND2x1_ASAP7_75t_R  g096(.A(p5), .B(p8), .Y(new_n118_));
  OA21x2_ASAP7_75t_R   g097(.A1(new_n23_), .A2(p4), .B(new_n118_), .Y(new_n119_));
  AND2x2_ASAP7_75t_R   g098(.A(p7), .B(p8), .Y(new_n120_));
  AOI22x1_ASAP7_75t_R  g099(.A1(new_n120_), .A2(p5), .B1(new_n80_), .B2(new_n62_), .Y(new_n121_));
  OAI21x1_ASAP7_75t_R  g100(.A1(p9), .A2(new_n119_), .B(new_n121_), .Y(new_n122_));
  NOR2x1_ASAP7_75t_R   g101(.A(p0), .B(new_n40_), .Y(new_n123_));
  NAND2x1_ASAP7_75t_R  g102(.A(p8), .B(p1), .Y(new_n124_));
  NAND2x1_ASAP7_75t_R  g103(.A(p7), .B(p9), .Y(new_n125_));
  OR3x1_ASAP7_75t_R    g104(.A(new_n124_), .B(new_n125_), .C(new_n80_), .Y(new_n126_));
  OR5x1_ASAP7_75t_R    g105(.A(p7), .B(new_n80_), .C(p8), .D(p9), .E(p1), .Y(new_n127_));
  AOI21x1_ASAP7_75t_R  g106(.A1(new_n126_), .A2(new_n127_), .B(p0), .Y(new_n128_));
  AOI221x1_ASAP7_75t_R g107(.A1(new_n107_), .A2(new_n117_), .B1(new_n122_), .B2(new_n123_), .C(new_n128_), .Y(new_n129_));
  NOR2x1_ASAP7_75t_R   g108(.A(p5), .B(p7), .Y(new_n130_));
  INVx1_ASAP7_75t_R    g109(.A(new_n130_), .Y(new_n131_));
  NAND2x1_ASAP7_75t_R  g110(.A(p5), .B(new_n24_), .Y(new_n132_));
  AO21x1_ASAP7_75t_R   g111(.A1(new_n40_), .A2(new_n132_), .B(new_n84_), .Y(new_n133_));
  NAND2x1_ASAP7_75t_R  g112(.A(new_n131_), .B(new_n133_), .Y(new_n134_));
  NOR2x1_ASAP7_75t_R   g113(.A(p8), .B(new_n22_), .Y(new_n135_));
  AND2x2_ASAP7_75t_R   g114(.A(p5), .B(p7), .Y(new_n136_));
  OR3x1_ASAP7_75t_R    g115(.A(new_n136_), .B(new_n24_), .C(p1), .Y(new_n137_));
  OR5x1_ASAP7_75t_R    g116(.A(p7), .B(new_n37_), .C(new_n80_), .D(p9), .E(p1), .Y(new_n138_));
  OAI21x1_ASAP7_75t_R  g117(.A1(new_n119_), .A2(new_n137_), .B(new_n138_), .Y(new_n139_));
  AOI22x1_ASAP7_75t_R  g118(.A1(new_n134_), .A2(new_n135_), .B1(p0), .B2(new_n139_), .Y(new_n140_));
  NAND2x1_ASAP7_75t_R  g119(.A(new_n129_), .B(new_n140_), .Y(new_n141_));
  INVx1_ASAP7_75t_R    g120(.A(p3), .Y(new_n142_));
  OA21x2_ASAP7_75t_R   g121(.A1(new_n108_), .A2(new_n106_), .B(new_n107_), .Y(new_n143_));
  AO21x1_ASAP7_75t_R   g122(.A1(p5), .A2(new_n110_), .B(new_n143_), .Y(new_n144_));
  AND3x1_ASAP7_75t_R   g123(.A(new_n24_), .B(new_n40_), .C(new_n22_), .Y(new_n145_));
  AOI22x1_ASAP7_75t_R  g124(.A1(new_n141_), .A2(new_n142_), .B1(new_n144_), .B2(new_n145_), .Y(new_n146_));
  NAND2x1_ASAP7_75t_R  g125(.A(new_n23_), .B(new_n22_), .Y(new_n147_));
  NOR2x1_ASAP7_75t_R   g126(.A(p0), .B(new_n60_), .Y(new_n148_));
  AO32x1_ASAP7_75t_R   g127(.A1(new_n147_), .A2(new_n40_), .A3(p2), .B1(new_n148_), .B2(new_n136_), .Y(new_n149_));
  NOR2x1_ASAP7_75t_R   g128(.A(p7), .B(p2), .Y(new_n150_));
  INVx1_ASAP7_75t_R    g129(.A(new_n150_), .Y(new_n151_));
  AND5x1_ASAP7_75t_R   g130(.A(new_n31_), .B(new_n151_), .C(new_n84_), .D(p9), .E(new_n22_), .Y(new_n152_));
  NAND2x1_ASAP7_75t_R  g131(.A(p7), .B(new_n24_), .Y(new_n153_));
  NAND2x1_ASAP7_75t_R  g132(.A(new_n73_), .B(new_n153_), .Y(new_n154_));
  AND2x2_ASAP7_75t_R   g133(.A(p9), .B(p0), .Y(new_n155_));
  AO21x1_ASAP7_75t_R   g134(.A1(new_n31_), .A2(new_n22_), .B(new_n155_), .Y(new_n156_));
  OAI21x1_ASAP7_75t_R  g135(.A1(new_n154_), .A2(new_n156_), .B(new_n37_), .Y(new_n157_));
  AOI211x1_ASAP7_75t_R g136(.A1(new_n80_), .A2(new_n149_), .B(new_n152_), .C(new_n157_), .Y(new_n158_));
  AO21x1_ASAP7_75t_R   g137(.A1(p7), .A2(p2), .B(p1), .Y(new_n159_));
  AND3x1_ASAP7_75t_R   g138(.A(new_n99_), .B(p4), .C(new_n22_), .Y(new_n160_));
  AO21x1_ASAP7_75t_R   g139(.A1(new_n24_), .A2(new_n159_), .B(new_n160_), .Y(new_n161_));
  NOR2x1_ASAP7_75t_R   g140(.A(p1), .B(new_n125_), .Y(new_n162_));
  NAND2x1_ASAP7_75t_R  g141(.A(p4), .B(new_n24_), .Y(new_n163_));
  NAND2x1_ASAP7_75t_R  g142(.A(p9), .B(new_n80_), .Y(new_n164_));
  NAND2x1_ASAP7_75t_R  g143(.A(new_n163_), .B(new_n164_), .Y(new_n165_));
  OA21x2_ASAP7_75t_R   g144(.A1(new_n162_), .A2(new_n165_), .B(p0), .Y(new_n166_));
  OAI21x1_ASAP7_75t_R  g145(.A1(new_n161_), .A2(new_n166_), .B(new_n31_), .Y(new_n167_));
  AND2x2_ASAP7_75t_R   g146(.A(p4), .B(p0), .Y(new_n168_));
  AO21x1_ASAP7_75t_R   g147(.A1(new_n99_), .A2(new_n148_), .B(new_n168_), .Y(new_n169_));
  AND2x2_ASAP7_75t_R   g148(.A(p5), .B(p9), .Y(new_n170_));
  AND2x2_ASAP7_75t_R   g149(.A(p1), .B(p0), .Y(new_n171_));
  INVx1_ASAP7_75t_R    g150(.A(new_n63_), .Y(new_n172_));
  INVx1_ASAP7_75t_R    g151(.A(new_n92_), .Y(new_n173_));
  OA211x2_ASAP7_75t_R  g152(.A1(p4), .A2(new_n171_), .B(new_n172_), .C(new_n173_), .Y(new_n174_));
  INVx1_ASAP7_75t_R    g153(.A(new_n27_), .Y(new_n175_));
  AO21x1_ASAP7_75t_R   g154(.A1(new_n55_), .A2(new_n175_), .B(new_n37_), .Y(new_n176_));
  AOI221x1_ASAP7_75t_R g155(.A1(new_n169_), .A2(new_n170_), .B1(new_n174_), .B2(p5), .C(new_n176_), .Y(new_n177_));
  AOI21x1_ASAP7_75t_R  g156(.A1(new_n158_), .A2(new_n167_), .B(new_n177_), .Y(new_n178_));
  NOR2x1_ASAP7_75t_R   g157(.A(p1), .B(new_n23_), .Y(new_n179_));
  NOR2x1_ASAP7_75t_R   g158(.A(p8), .B(new_n79_), .Y(new_n180_));
  NOR2x1_ASAP7_75t_R   g159(.A(p8), .B(new_n40_), .Y(new_n181_));
  AO32x1_ASAP7_75t_R   g160(.A1(new_n179_), .A2(new_n180_), .A3(p0), .B1(new_n181_), .B2(new_n96_), .Y(new_n182_));
  AO21x1_ASAP7_75t_R   g161(.A1(new_n24_), .A2(new_n22_), .B(new_n40_), .Y(new_n183_));
  AND3x1_ASAP7_75t_R   g162(.A(new_n183_), .B(p6), .C(new_n23_), .Y(new_n184_));
  OA21x2_ASAP7_75t_R   g163(.A1(new_n46_), .A2(new_n155_), .B(new_n184_), .Y(new_n185_));
  NAND2x1_ASAP7_75t_R  g164(.A(new_n92_), .B(new_n102_), .Y(new_n186_));
  INVx1_ASAP7_75t_R    g165(.A(new_n186_), .Y(new_n187_));
  OA21x2_ASAP7_75t_R   g166(.A1(new_n182_), .A2(new_n185_), .B(new_n187_), .Y(new_n188_));
  AOI21x1_ASAP7_75t_R  g167(.A1(new_n67_), .A2(new_n178_), .B(new_n188_), .Y(new_n189_));
  OAI21x1_ASAP7_75t_R  g168(.A1(new_n116_), .A2(new_n146_), .B(new_n189_), .Y(o1));
  AO21x1_ASAP7_75t_R   g169(.A1(p0), .A2(new_n62_), .B(new_n40_), .Y(new_n191_));
  AO21x1_ASAP7_75t_R   g170(.A1(p9), .A2(new_n120_), .B(new_n62_), .Y(new_n192_));
  AND3x1_ASAP7_75t_R   g171(.A(p8), .B(p1), .C(p0), .Y(new_n193_));
  OAI22x1_ASAP7_75t_R  g172(.A1(new_n192_), .A2(new_n80_), .B1(new_n168_), .B2(new_n193_), .Y(new_n194_));
  OAI21x1_ASAP7_75t_R  g173(.A1(new_n120_), .A2(new_n191_), .B(new_n194_), .Y(new_n195_));
  AND2x2_ASAP7_75t_R   g174(.A(p7), .B(p9), .Y(new_n196_));
  AND3x1_ASAP7_75t_R   g175(.A(new_n99_), .B(new_n37_), .C(p9), .Y(new_n197_));
  AO21x1_ASAP7_75t_R   g176(.A1(p2), .A2(new_n22_), .B(new_n80_), .Y(new_n198_));
  AO32x1_ASAP7_75t_R   g177(.A1(new_n39_), .A2(new_n172_), .A3(new_n196_), .B1(new_n197_), .B2(new_n198_), .Y(new_n199_));
  AO21x1_ASAP7_75t_R   g178(.A1(new_n60_), .A2(new_n195_), .B(new_n199_), .Y(new_n200_));
  NAND3x1_ASAP7_75t_R  g179(.A(new_n200_), .B(new_n79_), .C(new_n102_), .Y(new_n201_));
  NOR2x1_ASAP7_75t_R   g180(.A(p7), .B(new_n31_), .Y(new_n202_));
  NOR2x1_ASAP7_75t_R   g181(.A(p2), .B(new_n94_), .Y(new_n203_));
  AO21x1_ASAP7_75t_R   g182(.A1(new_n34_), .A2(new_n92_), .B(new_n203_), .Y(new_n204_));
  NAND2x1_ASAP7_75t_R  g183(.A(p2), .B(new_n40_), .Y(new_n205_));
  AO21x1_ASAP7_75t_R   g184(.A1(p7), .A2(new_n205_), .B(p4), .Y(new_n206_));
  NAND2x1_ASAP7_75t_R  g185(.A(p4), .B(p2), .Y(new_n207_));
  OA21x2_ASAP7_75t_R   g186(.A1(new_n207_), .A2(new_n179_), .B(new_n135_), .Y(new_n208_));
  AND2x2_ASAP7_75t_R   g187(.A(p5), .B(p1), .Y(new_n209_));
  AO21x1_ASAP7_75t_R   g188(.A1(p1), .A2(new_n23_), .B(new_n22_), .Y(new_n210_));
  OA211x2_ASAP7_75t_R  g189(.A1(new_n209_), .A2(new_n210_), .B(p4), .C(new_n159_), .Y(new_n211_));
  AOI221x1_ASAP7_75t_R g190(.A1(new_n202_), .A2(new_n204_), .B1(new_n206_), .B2(new_n208_), .C(new_n211_), .Y(new_n212_));
  OR4x2_ASAP7_75t_R    g191(.A(new_n37_), .B(new_n60_), .C(p7), .D(p0), .Y(new_n213_));
  AO221x2_ASAP7_75t_R  g192(.A1(p7), .A2(new_n135_), .B1(new_n213_), .B2(new_n205_), .C(new_n107_), .Y(new_n214_));
  INVx1_ASAP7_75t_R    g193(.A(new_n135_), .Y(new_n215_));
  AO21x1_ASAP7_75t_R   g194(.A1(p2), .A2(new_n37_), .B(p5), .Y(new_n216_));
  AO21x1_ASAP7_75t_R   g195(.A1(new_n27_), .A2(new_n215_), .B(new_n216_), .Y(new_n217_));
  AND3x1_ASAP7_75t_R   g196(.A(new_n214_), .B(new_n142_), .C(new_n217_), .Y(new_n218_));
  AO21x1_ASAP7_75t_R   g197(.A1(new_n22_), .A2(new_n63_), .B(new_n142_), .Y(new_n219_));
  NAND2x1_ASAP7_75t_R  g198(.A(new_n79_), .B(new_n24_), .Y(new_n220_));
  OA211x2_ASAP7_75t_R  g199(.A1(new_n120_), .A2(new_n202_), .B(p3), .C(new_n80_), .Y(new_n221_));
  NOR2x1_ASAP7_75t_R   g200(.A(new_n220_), .B(new_n221_), .Y(new_n222_));
  NAND2x1_ASAP7_75t_R  g201(.A(new_n219_), .B(new_n222_), .Y(new_n223_));
  AO21x1_ASAP7_75t_R   g202(.A1(new_n212_), .A2(new_n218_), .B(new_n223_), .Y(new_n224_));
  AND3x1_ASAP7_75t_R   g203(.A(new_n37_), .B(p7), .C(p0), .Y(new_n225_));
  AOI221x1_ASAP7_75t_R g204(.A1(new_n76_), .A2(new_n136_), .B1(new_n95_), .B2(new_n150_), .C(new_n225_), .Y(new_n226_));
  OR3x1_ASAP7_75t_R    g205(.A(new_n164_), .B(p3), .C(p6), .Y(new_n227_));
  INVx1_ASAP7_75t_R    g206(.A(new_n53_), .Y(new_n228_));
  NAND2x1_ASAP7_75t_R  g207(.A(p7), .B(p8), .Y(new_n229_));
  OA21x2_ASAP7_75t_R   g208(.A1(new_n79_), .A2(new_n229_), .B(p9), .Y(new_n230_));
  OA22x2_ASAP7_75t_R   g209(.A1(new_n228_), .A2(new_n147_), .B1(new_n91_), .B2(new_n230_), .Y(new_n231_));
  OAI22x1_ASAP7_75t_R  g210(.A1(new_n226_), .A2(new_n227_), .B1(new_n186_), .B2(new_n231_), .Y(new_n232_));
  AND3x1_ASAP7_75t_R   g211(.A(new_n23_), .B(new_n37_), .C(p1), .Y(new_n233_));
  NAND2x1_ASAP7_75t_R  g212(.A(p1), .B(new_n37_), .Y(new_n234_));
  NOR2x1_ASAP7_75t_R   g213(.A(p0), .B(new_n23_), .Y(new_n235_));
  OA21x2_ASAP7_75t_R   g214(.A1(new_n193_), .A2(new_n235_), .B(p5), .Y(new_n236_));
  AO21x1_ASAP7_75t_R   g215(.A1(p7), .A2(new_n234_), .B(new_n236_), .Y(new_n237_));
  NOR2x1_ASAP7_75t_R   g216(.A(new_n60_), .B(new_n227_), .Y(new_n238_));
  OA21x2_ASAP7_75t_R   g217(.A1(new_n233_), .A2(new_n237_), .B(new_n238_), .Y(new_n239_));
  AOI21x1_ASAP7_75t_R  g218(.A1(new_n40_), .A2(new_n232_), .B(new_n239_), .Y(new_n240_));
  NAND3x1_ASAP7_75t_R  g219(.A(new_n201_), .B(new_n224_), .C(new_n240_), .Y(o2));
  AND2x2_ASAP7_75t_R   g220(.A(p7), .B(p4), .Y(new_n242_));
  AND3x1_ASAP7_75t_R   g221(.A(new_n30_), .B(new_n242_), .C(new_n31_), .Y(new_n243_));
  NAND2x1_ASAP7_75t_R  g222(.A(p5), .B(new_n23_), .Y(new_n244_));
  AOI211x1_ASAP7_75t_R g223(.A1(new_n60_), .A2(new_n244_), .B(new_n105_), .C(new_n106_), .Y(new_n245_));
  AO21x1_ASAP7_75t_R   g224(.A1(new_n80_), .A2(new_n233_), .B(new_n245_), .Y(new_n246_));
  OA21x2_ASAP7_75t_R   g225(.A1(new_n243_), .A2(new_n246_), .B(p0), .Y(new_n247_));
  AO32x1_ASAP7_75t_R   g226(.A1(new_n216_), .A2(new_n22_), .A3(new_n172_), .B1(new_n80_), .B2(new_n209_), .Y(new_n248_));
  NOR2x1_ASAP7_75t_R   g227(.A(p5), .B(p4), .Y(new_n249_));
  NAND2x1_ASAP7_75t_R  g228(.A(p3), .B(new_n60_), .Y(new_n250_));
  NAND2x1_ASAP7_75t_R  g229(.A(new_n40_), .B(new_n22_), .Y(new_n251_));
  NOR2x1_ASAP7_75t_R   g230(.A(new_n250_), .B(new_n251_), .Y(new_n252_));
  AO21x1_ASAP7_75t_R   g231(.A1(p7), .A2(p8), .B(p4), .Y(new_n253_));
  OA211x2_ASAP7_75t_R  g232(.A1(new_n105_), .A2(new_n249_), .B(new_n252_), .C(new_n253_), .Y(new_n254_));
  AO21x1_ASAP7_75t_R   g233(.A1(new_n142_), .A2(new_n248_), .B(new_n254_), .Y(new_n255_));
  AOI21x1_ASAP7_75t_R  g234(.A1(new_n142_), .A2(new_n247_), .B(new_n255_), .Y(new_n256_));
  AO21x1_ASAP7_75t_R   g235(.A1(p8), .A2(new_n23_), .B(p2), .Y(new_n257_));
  AO21x1_ASAP7_75t_R   g236(.A1(p2), .A2(new_n23_), .B(p5), .Y(new_n258_));
  NAND2x1_ASAP7_75t_R  g237(.A(p2), .B(new_n80_), .Y(new_n259_));
  AO32x1_ASAP7_75t_R   g238(.A1(new_n257_), .A2(new_n40_), .A3(new_n173_), .B1(new_n258_), .B2(new_n259_), .Y(new_n260_));
  AO21x1_ASAP7_75t_R   g239(.A1(p1), .A2(new_n27_), .B(new_n242_), .Y(new_n261_));
  OA211x2_ASAP7_75t_R  g240(.A1(new_n40_), .A2(new_n48_), .B(new_n261_), .C(new_n37_), .Y(new_n262_));
  OAI21x1_ASAP7_75t_R  g241(.A1(new_n260_), .A2(new_n262_), .B(new_n155_), .Y(new_n263_));
  OR3x1_ASAP7_75t_R    g242(.A(new_n63_), .B(new_n118_), .C(p4), .Y(new_n264_));
  AO21x1_ASAP7_75t_R   g243(.A1(p7), .A2(new_n124_), .B(new_n32_), .Y(new_n265_));
  OA21x2_ASAP7_75t_R   g244(.A1(new_n81_), .A2(new_n244_), .B(new_n265_), .Y(new_n266_));
  AO21x1_ASAP7_75t_R   g245(.A1(new_n264_), .A2(new_n266_), .B(p0), .Y(new_n267_));
  OR3x1_ASAP7_75t_R    g246(.A(new_n31_), .B(new_n23_), .C(new_n22_), .Y(new_n268_));
  AO21x1_ASAP7_75t_R   g247(.A1(new_n81_), .A2(new_n131_), .B(new_n205_), .Y(new_n269_));
  OA21x2_ASAP7_75t_R   g248(.A1(new_n81_), .A2(new_n268_), .B(new_n269_), .Y(new_n270_));
  AND2x2_ASAP7_75t_R   g249(.A(new_n48_), .B(new_n94_), .Y(new_n271_));
  AO21x1_ASAP7_75t_R   g250(.A1(p8), .A2(p4), .B(p5), .Y(new_n272_));
  OR3x1_ASAP7_75t_R    g251(.A(new_n271_), .B(new_n60_), .C(new_n272_), .Y(new_n273_));
  OA21x2_ASAP7_75t_R   g252(.A1(new_n31_), .A2(new_n92_), .B(new_n53_), .Y(new_n274_));
  OAI21x1_ASAP7_75t_R  g253(.A1(p5), .A2(new_n160_), .B(new_n274_), .Y(new_n275_));
  AND3x1_ASAP7_75t_R   g254(.A(new_n270_), .B(new_n273_), .C(new_n275_), .Y(new_n276_));
  AO31x2_ASAP7_75t_R   g255(.A1(new_n263_), .A2(new_n267_), .A3(new_n276_), .B(new_n68_), .Y(new_n277_));
  OAI21x1_ASAP7_75t_R  g256(.A1(new_n220_), .A2(new_n256_), .B(new_n277_), .Y(o3));
  OR3x1_ASAP7_75t_R    g257(.A(new_n96_), .B(p3), .C(new_n40_), .Y(new_n279_));
  NAND2x1_ASAP7_75t_R  g258(.A(p2), .B(new_n142_), .Y(new_n280_));
  INVx1_ASAP7_75t_R    g259(.A(new_n145_), .Y(new_n281_));
  AO21x1_ASAP7_75t_R   g260(.A1(new_n250_), .A2(new_n280_), .B(new_n281_), .Y(new_n282_));
  OR3x1_ASAP7_75t_R    g261(.A(new_n31_), .B(new_n80_), .C(p6), .Y(new_n283_));
  AOI21x1_ASAP7_75t_R  g262(.A1(new_n279_), .A2(new_n282_), .B(new_n283_), .Y(o4));
  AO21x1_ASAP7_75t_R   g263(.A1(new_n40_), .A2(new_n96_), .B(new_n280_), .Y(new_n285_));
  OR3x1_ASAP7_75t_R    g264(.A(new_n251_), .B(new_n250_), .C(p9), .Y(new_n286_));
  AOI21x1_ASAP7_75t_R  g265(.A1(new_n285_), .A2(new_n286_), .B(new_n283_), .Y(o5));
  AO21x1_ASAP7_75t_R   g266(.A1(new_n23_), .A2(new_n37_), .B(p0), .Y(new_n288_));
  NAND2x1_ASAP7_75t_R  g267(.A(p9), .B(new_n288_), .Y(new_n289_));
  NOR2x1_ASAP7_75t_R   g268(.A(p5), .B(p9), .Y(new_n290_));
  OAI21x1_ASAP7_75t_R  g269(.A1(new_n171_), .A2(new_n290_), .B(new_n147_), .Y(new_n291_));
  OAI22x1_ASAP7_75t_R  g270(.A1(new_n289_), .A2(new_n135_), .B1(new_n95_), .B2(new_n291_), .Y(new_n292_));
  AO32x1_ASAP7_75t_R   g271(.A1(new_n88_), .A2(new_n23_), .A3(p0), .B1(new_n179_), .B2(new_n170_), .Y(new_n293_));
  AO32x1_ASAP7_75t_R   g272(.A1(new_n25_), .A2(new_n135_), .A3(new_n164_), .B1(new_n293_), .B2(p8), .Y(new_n294_));
  AOI21x1_ASAP7_75t_R  g273(.A1(new_n80_), .A2(new_n292_), .B(new_n294_), .Y(new_n295_));
  OA211x2_ASAP7_75t_R  g274(.A1(p9), .A2(new_n202_), .B(new_n48_), .C(new_n58_), .Y(new_n296_));
  AO21x1_ASAP7_75t_R   g275(.A1(p1), .A2(new_n80_), .B(p5), .Y(new_n297_));
  AO32x1_ASAP7_75t_R   g276(.A1(new_n54_), .A2(new_n40_), .A3(p4), .B1(new_n52_), .B2(new_n297_), .Y(new_n298_));
  NOR2x1_ASAP7_75t_R   g277(.A(p7), .B(new_n22_), .Y(new_n299_));
  OA21x2_ASAP7_75t_R   g278(.A1(p7), .A2(p8), .B(p1), .Y(new_n300_));
  AO21x1_ASAP7_75t_R   g279(.A1(p8), .A2(new_n196_), .B(new_n300_), .Y(new_n301_));
  AND2x2_ASAP7_75t_R   g280(.A(p5), .B(p0), .Y(new_n302_));
  AO32x1_ASAP7_75t_R   g281(.A1(p1), .A2(new_n52_), .A3(new_n235_), .B1(new_n301_), .B2(new_n302_), .Y(new_n303_));
  AOI221x1_ASAP7_75t_R g282(.A1(new_n22_), .A2(new_n296_), .B1(new_n298_), .B2(new_n299_), .C(new_n303_), .Y(new_n304_));
  OAI21x1_ASAP7_75t_R  g283(.A1(new_n60_), .A2(new_n295_), .B(new_n304_), .Y(new_n305_));
  NAND2x1_ASAP7_75t_R  g284(.A(p1), .B(p4), .Y(new_n306_));
  AO32x1_ASAP7_75t_R   g285(.A1(new_n306_), .A2(new_n74_), .A3(new_n107_), .B1(new_n168_), .B2(p8), .Y(new_n307_));
  AND3x1_ASAP7_75t_R   g286(.A(new_n81_), .B(new_n24_), .C(new_n117_), .Y(new_n308_));
  AO21x1_ASAP7_75t_R   g287(.A1(new_n196_), .A2(new_n307_), .B(new_n308_), .Y(new_n309_));
  OR2x4_ASAP7_75t_R    g288(.A(new_n99_), .B(new_n117_), .Y(new_n310_));
  INVx1_ASAP7_75t_R    g289(.A(new_n62_), .Y(new_n311_));
  NAND2x1_ASAP7_75t_R  g290(.A(new_n229_), .B(new_n311_), .Y(new_n312_));
  AO32x1_ASAP7_75t_R   g291(.A1(p8), .A2(new_n24_), .A3(p1), .B1(new_n62_), .B2(new_n22_), .Y(new_n313_));
  AO32x1_ASAP7_75t_R   g292(.A1(new_n310_), .A2(p5), .A3(new_n312_), .B1(p4), .B2(new_n313_), .Y(new_n314_));
  NOR2x1_ASAP7_75t_R   g293(.A(new_n309_), .B(new_n314_), .Y(new_n315_));
  OR3x1_ASAP7_75t_R    g294(.A(p3), .B(p6), .C(p2), .Y(new_n316_));
  AO21x1_ASAP7_75t_R   g295(.A1(p6), .A2(new_n37_), .B(new_n23_), .Y(new_n317_));
  AO21x1_ASAP7_75t_R   g296(.A1(new_n22_), .A2(new_n317_), .B(new_n58_), .Y(new_n318_));
  AND3x1_ASAP7_75t_R   g297(.A(new_n288_), .B(p6), .C(new_n40_), .Y(new_n319_));
  AO32x1_ASAP7_75t_R   g298(.A1(new_n318_), .A2(new_n24_), .A3(new_n251_), .B1(new_n319_), .B2(new_n192_), .Y(new_n320_));
  AO32x1_ASAP7_75t_R   g299(.A1(new_n79_), .A2(p5), .A3(p4), .B1(new_n113_), .B2(p3), .Y(new_n321_));
  AOI21x1_ASAP7_75t_R  g300(.A1(new_n187_), .A2(new_n320_), .B(new_n321_), .Y(new_n322_));
  OAI21x1_ASAP7_75t_R  g301(.A1(new_n315_), .A2(new_n316_), .B(new_n322_), .Y(new_n323_));
  AOI21x1_ASAP7_75t_R  g302(.A1(new_n67_), .A2(new_n305_), .B(new_n323_), .Y(o6));
  NOR2x1_ASAP7_75t_R   g303(.A(p9), .B(new_n40_), .Y(new_n325_));
  AO32x1_ASAP7_75t_R   g304(.A1(new_n311_), .A2(new_n325_), .A3(new_n229_), .B1(new_n162_), .B2(new_n180_), .Y(new_n326_));
  AND5x1_ASAP7_75t_R   g305(.A(new_n31_), .B(new_n326_), .C(new_n80_), .D(new_n22_), .E(new_n60_), .Y(new_n327_));
  OA21x2_ASAP7_75t_R   g306(.A1(new_n79_), .A2(new_n327_), .B(new_n142_), .Y(new_n328_));
  OAI21x1_ASAP7_75t_R  g307(.A1(new_n32_), .A2(new_n153_), .B(new_n244_), .Y(new_n329_));
  AOI21x1_ASAP7_75t_R  g308(.A1(p5), .A2(p8), .B(p7), .Y(new_n330_));
  AOI211x1_ASAP7_75t_R g309(.A1(p8), .A2(new_n24_), .B(new_n290_), .C(new_n330_), .Y(new_n331_));
  AOI22x1_ASAP7_75t_R  g310(.A1(new_n329_), .A2(p8), .B1(new_n32_), .B2(new_n331_), .Y(new_n332_));
  AO21x1_ASAP7_75t_R   g311(.A1(p2), .A2(new_n229_), .B(new_n196_), .Y(new_n333_));
  NOR2x1_ASAP7_75t_R   g312(.A(p5), .B(new_n40_), .Y(new_n334_));
  AND3x1_ASAP7_75t_R   g313(.A(new_n107_), .B(new_n23_), .C(new_n60_), .Y(new_n335_));
  AOI221x1_ASAP7_75t_R g314(.A1(new_n41_), .A2(new_n120_), .B1(new_n333_), .B2(new_n334_), .C(new_n335_), .Y(new_n336_));
  OAI21x1_ASAP7_75t_R  g315(.A1(p1), .A2(new_n332_), .B(new_n336_), .Y(new_n337_));
  AO21x1_ASAP7_75t_R   g316(.A1(p7), .A2(p8), .B(p5), .Y(new_n338_));
  NOR3x1_ASAP7_75t_R   g317(.A(new_n53_), .B(p1), .C(new_n338_), .Y(new_n339_));
  AOI21x1_ASAP7_75t_R  g318(.A1(new_n229_), .A2(new_n311_), .B(new_n132_), .Y(new_n340_));
  OAI21x1_ASAP7_75t_R  g319(.A1(new_n339_), .A2(new_n340_), .B(new_n148_), .Y(new_n341_));
  NOR3x1_ASAP7_75t_R   g320(.A(p7), .B(p9), .C(p1), .Y(new_n342_));
  AND3x1_ASAP7_75t_R   g321(.A(p5), .B(p7), .C(p9), .Y(new_n343_));
  OA21x2_ASAP7_75t_R   g322(.A1(new_n342_), .A2(new_n343_), .B(new_n37_), .Y(new_n344_));
  OA21x2_ASAP7_75t_R   g323(.A1(p5), .A2(new_n150_), .B(new_n300_), .Y(new_n345_));
  OAI21x1_ASAP7_75t_R  g324(.A1(new_n344_), .A2(new_n345_), .B(new_n22_), .Y(new_n346_));
  OR5x1_ASAP7_75t_R    g325(.A(new_n31_), .B(new_n60_), .C(p7), .D(p8), .E(p1), .Y(new_n347_));
  NAND3x1_ASAP7_75t_R  g326(.A(new_n341_), .B(new_n346_), .C(new_n347_), .Y(new_n348_));
  AOI21x1_ASAP7_75t_R  g327(.A1(p0), .A2(new_n337_), .B(new_n348_), .Y(new_n349_));
  OR3x1_ASAP7_75t_R    g328(.A(new_n30_), .B(new_n58_), .C(new_n125_), .Y(new_n350_));
  OR4x2_ASAP7_75t_R    g329(.A(new_n23_), .B(new_n80_), .C(p8), .D(p9), .Y(new_n351_));
  OR3x1_ASAP7_75t_R    g330(.A(new_n124_), .B(p7), .C(new_n80_), .Y(new_n352_));
  AO31x2_ASAP7_75t_R   g331(.A1(new_n350_), .A2(new_n351_), .A3(new_n352_), .B(new_n71_), .Y(new_n353_));
  AOI211x1_ASAP7_75t_R g332(.A1(p7), .A2(p8), .B(p1), .C(new_n207_), .Y(new_n354_));
  AOI21x1_ASAP7_75t_R  g333(.A1(new_n207_), .A2(new_n234_), .B(new_n25_), .Y(new_n355_));
  OAI21x1_ASAP7_75t_R  g334(.A1(new_n354_), .A2(new_n355_), .B(p0), .Y(new_n356_));
  AOI211x1_ASAP7_75t_R g335(.A1(new_n40_), .A2(new_n70_), .B(new_n80_), .C(p0), .Y(new_n357_));
  AOI22x1_ASAP7_75t_R  g336(.A1(p7), .A2(p8), .B1(p1), .B2(p2), .Y(new_n358_));
  OAI21x1_ASAP7_75t_R  g337(.A1(p7), .A2(p8), .B(new_n358_), .Y(new_n359_));
  AND3x1_ASAP7_75t_R   g338(.A(new_n30_), .B(new_n242_), .C(p2), .Y(new_n360_));
  AOI221x1_ASAP7_75t_R g339(.A1(new_n175_), .A2(new_n38_), .B1(new_n357_), .B2(new_n359_), .C(new_n360_), .Y(new_n361_));
  NAND3x1_ASAP7_75t_R  g340(.A(new_n353_), .B(new_n356_), .C(new_n361_), .Y(new_n362_));
  AOI21x1_ASAP7_75t_R  g341(.A1(new_n31_), .A2(new_n362_), .B(new_n327_), .Y(new_n363_));
  OAI21x1_ASAP7_75t_R  g342(.A1(p4), .A2(new_n349_), .B(new_n363_), .Y(new_n364_));
  AND3x1_ASAP7_75t_R   g343(.A(new_n113_), .B(p3), .C(new_n249_), .Y(new_n365_));
  AOI21x1_ASAP7_75t_R  g344(.A1(new_n328_), .A2(new_n364_), .B(new_n365_), .Y(o7));
  NAND2x1_ASAP7_75t_R  g345(.A(p2), .B(new_n48_), .Y(new_n367_));
  AND3x1_ASAP7_75t_R   g346(.A(new_n172_), .B(p0), .C(new_n306_), .Y(new_n368_));
  AND3x1_ASAP7_75t_R   g347(.A(new_n179_), .B(new_n148_), .C(new_n163_), .Y(new_n369_));
  AOI21x1_ASAP7_75t_R  g348(.A1(new_n367_), .A2(new_n368_), .B(new_n369_), .Y(new_n370_));
  AO21x1_ASAP7_75t_R   g349(.A1(new_n80_), .A2(p2), .B(new_n168_), .Y(new_n371_));
  OAI21x1_ASAP7_75t_R  g350(.A1(p9), .A2(p2), .B(new_n179_), .Y(new_n372_));
  OR3x1_ASAP7_75t_R    g351(.A(new_n173_), .B(p0), .C(new_n125_), .Y(new_n373_));
  OA21x2_ASAP7_75t_R   g352(.A1(new_n371_), .A2(new_n372_), .B(new_n373_), .Y(new_n374_));
  NOR2x1_ASAP7_75t_R   g353(.A(p9), .B(new_n23_), .Y(new_n375_));
  OA211x2_ASAP7_75t_R  g354(.A1(p4), .A2(new_n375_), .B(new_n171_), .C(new_n207_), .Y(new_n376_));
  NOR2x1_ASAP7_75t_R   g355(.A(p8), .B(new_n376_), .Y(new_n377_));
  AOI221x1_ASAP7_75t_R g356(.A1(p8), .A2(new_n370_), .B1(new_n374_), .B2(new_n377_), .C(p5), .Y(new_n378_));
  AND3x1_ASAP7_75t_R   g357(.A(new_n34_), .B(new_n40_), .C(p4), .Y(new_n379_));
  OA21x2_ASAP7_75t_R   g358(.A1(new_n203_), .A2(new_n379_), .B(new_n24_), .Y(new_n380_));
  AO21x1_ASAP7_75t_R   g359(.A1(p8), .A2(new_n60_), .B(p1), .Y(new_n381_));
  NOR3x1_ASAP7_75t_R   g360(.A(new_n371_), .B(new_n34_), .C(new_n381_), .Y(new_n382_));
  AO22x1_ASAP7_75t_R   g361(.A1(new_n123_), .A2(new_n92_), .B1(new_n41_), .B2(new_n95_), .Y(new_n383_));
  OA31x2_ASAP7_75t_R   g362(.A1(new_n380_), .A2(new_n382_), .A3(new_n383_), .B1(new_n130_), .Y(new_n384_));
  NOR2x1_ASAP7_75t_R   g363(.A(p5), .B(new_n299_), .Y(new_n385_));
  AO21x1_ASAP7_75t_R   g364(.A1(p8), .A2(new_n22_), .B(new_n31_), .Y(new_n386_));
  AO21x1_ASAP7_75t_R   g365(.A1(new_n375_), .A2(new_n215_), .B(new_n386_), .Y(new_n387_));
  AOI221x1_ASAP7_75t_R g366(.A1(new_n289_), .A2(new_n385_), .B1(new_n387_), .B2(new_n40_), .C(new_n259_), .Y(new_n388_));
  OR3x1_ASAP7_75t_R    g367(.A(new_n378_), .B(new_n384_), .C(new_n388_), .Y(new_n389_));
  OR3x1_ASAP7_75t_R    g368(.A(new_n286_), .B(p6), .C(p4), .Y(new_n390_));
  AND3x1_ASAP7_75t_R   g369(.A(new_n342_), .B(p8), .C(p0), .Y(new_n391_));
  OR3x1_ASAP7_75t_R    g370(.A(new_n125_), .B(p8), .C(p1), .Y(new_n392_));
  OA21x2_ASAP7_75t_R   g371(.A1(new_n124_), .A2(new_n25_), .B(new_n392_), .Y(new_n393_));
  NAND3x1_ASAP7_75t_R  g372(.A(new_n310_), .B(new_n37_), .C(new_n24_), .Y(new_n394_));
  AOI21x1_ASAP7_75t_R  g373(.A1(new_n393_), .A2(new_n394_), .B(p0), .Y(new_n395_));
  OAI21x1_ASAP7_75t_R  g374(.A1(new_n391_), .A2(new_n395_), .B(new_n187_), .Y(new_n396_));
  NAND2x1_ASAP7_75t_R  g375(.A(new_n390_), .B(new_n396_), .Y(new_n397_));
  AOI21x1_ASAP7_75t_R  g376(.A1(new_n67_), .A2(new_n389_), .B(new_n397_), .Y(o8));
  OR3x1_ASAP7_75t_R    g377(.A(new_n40_), .B(new_n60_), .C(p5), .Y(new_n399_));
  OA21x2_ASAP7_75t_R   g378(.A1(new_n164_), .A2(new_n399_), .B(new_n79_), .Y(new_n400_));
  AO21x1_ASAP7_75t_R   g379(.A1(new_n22_), .A2(new_n311_), .B(new_n400_), .Y(new_n401_));
  AOI21x1_ASAP7_75t_R  g380(.A1(new_n209_), .A2(new_n259_), .B(new_n105_), .Y(new_n402_));
  OR3x1_ASAP7_75t_R    g381(.A(new_n172_), .B(new_n24_), .C(p0), .Y(new_n403_));
  AO21x1_ASAP7_75t_R   g382(.A1(new_n24_), .A2(new_n41_), .B(new_n79_), .Y(new_n404_));
  AND5x1_ASAP7_75t_R   g383(.A(new_n401_), .B(new_n219_), .C(new_n402_), .D(new_n403_), .E(new_n404_), .Y(new_n405_));
  AOI21x1_ASAP7_75t_R  g384(.A1(new_n60_), .A2(new_n81_), .B(new_n375_), .Y(new_n406_));
  AND2x2_ASAP7_75t_R   g385(.A(p2), .B(new_n118_), .Y(new_n407_));
  OR3x1_ASAP7_75t_R    g386(.A(new_n406_), .B(p1), .C(new_n407_), .Y(new_n408_));
  INVx1_ASAP7_75t_R    g387(.A(new_n272_), .Y(new_n409_));
  OR3x1_ASAP7_75t_R    g388(.A(new_n409_), .B(p2), .C(new_n130_), .Y(new_n410_));
  OA21x2_ASAP7_75t_R   g389(.A1(new_n399_), .A2(new_n253_), .B(new_n410_), .Y(new_n411_));
  AO21x1_ASAP7_75t_R   g390(.A1(new_n408_), .A2(new_n411_), .B(new_n22_), .Y(new_n412_));
  OAI21x1_ASAP7_75t_R  g391(.A1(new_n153_), .A2(new_n409_), .B(new_n407_), .Y(new_n413_));
  OA21x2_ASAP7_75t_R   g392(.A1(new_n249_), .A2(new_n250_), .B(new_n40_), .Y(new_n414_));
  AO32x1_ASAP7_75t_R   g393(.A1(new_n41_), .A2(new_n311_), .A3(new_n253_), .B1(new_n413_), .B2(new_n414_), .Y(new_n415_));
  NAND2x1_ASAP7_75t_R  g394(.A(new_n22_), .B(new_n415_), .Y(new_n416_));
  AND3x1_ASAP7_75t_R   g395(.A(new_n405_), .B(new_n412_), .C(new_n416_), .Y(o9));
  OR3x1_ASAP7_75t_R    g396(.A(new_n183_), .B(new_n39_), .C(new_n280_), .Y(new_n418_));
  AO21x1_ASAP7_75t_R   g397(.A1(p7), .A2(new_n91_), .B(new_n418_), .Y(new_n419_));
  NAND2x1_ASAP7_75t_R  g398(.A(new_n286_), .B(new_n419_), .Y(new_n420_));
  AND3x1_ASAP7_75t_R   g399(.A(new_n420_), .B(new_n79_), .C(new_n249_), .Y(o10));
endmodule


