// Benchmark "/tmp/" written by ABC on Wed Oct 21 14:26:27 2026

module \/tmp/  ( 
    p2, p4, p0, p6, p9, p8, p5, p1, p7, p3,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10  );
  input  p2, p4, p0, p6, p9, p8, p5, p1, p7, p3;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10;
  wire new_n22_, new_n23_, new_n24_, new_n25_, new_n26_, new_n27_, new_n28_,
    new_n29_, new_n30_, new_n31_, new_n32_, new_n33_, new_n34_, new_n35_,
    new_n36_, new_n37_, new_n38_, new_n39_, new_n40_, new_n41_, new_n42_,
    new_n43_, new_n44_, new_n45_, new_n46_, new_n47_, new_n48_, new_n49_,
    new_n50_, new_n51_, new_n52_, new_n53_, new_n54_, new_n55_, new_n56_,
    new_n57_, new_n58_, new_n59_, new_n60_, new_n61_, new_n62_, new_n63_,
    new_n64_, new_n65_, new_n66_, new_n67_, new_n68_, new_n69_, new_n70_,
    new_n71_, new_n72_, new_n73_, new_n74_, new_n75_, new_n76_, new_n77_,
    new_n78_, new_n79_, new_n80_, new_n81_, new_n82_, new_n83_, new_n84_,
    new_n85_, new_n86_, new_n87_, new_n88_, new_n89_, new_n90_, new_n91_,
    new_n92_, new_n93_, new_n94_, new_n95_, new_n96_, new_n97_, new_n98_,
    new_n99_, new_n100_, new_n101_, new_n102_, new_n103_, new_n104_,
    new_n105_, new_n106_, new_n107_, new_n108_, new_n109_, new_n110_,
    new_n112_, new_n113_, new_n114_, new_n115_, new_n116_, new_n117_,
    new_n118_, new_n119_, new_n120_, new_n121_, new_n122_, new_n123_,
    new_n124_, new_n125_, new_n126_, new_n127_, new_n128_, new_n129_,
    new_n130_, new_n131_, new_n132_, new_n133_, new_n134_, new_n135_,
    new_n136_, new_n137_, new_n138_, new_n139_, new_n140_, new_n141_,
    new_n142_, new_n143_, new_n144_, new_n145_, new_n146_, new_n147_,
    new_n148_, new_n149_, new_n150_, new_n151_, new_n152_, new_n153_,
    new_n154_, new_n155_, new_n156_, new_n157_, new_n158_, new_n159_,
    new_n160_, new_n161_, new_n162_, new_n163_, new_n164_, new_n165_,
    new_n166_, new_n167_, new_n168_, new_n169_, new_n170_, new_n171_,
    new_n172_, new_n173_, new_n174_, new_n175_, new_n176_, new_n177_,
    new_n178_, new_n179_, new_n180_, new_n181_, new_n183_, new_n184_,
    new_n185_, new_n186_, new_n187_, new_n188_, new_n189_, new_n190_,
    new_n191_, new_n192_, new_n193_, new_n194_, new_n195_, new_n196_,
    new_n197_, new_n198_, new_n199_, new_n200_, new_n201_, new_n202_,
    new_n203_, new_n204_, new_n205_, new_n206_, new_n207_, new_n208_,
    new_n209_, new_n210_, new_n211_, new_n212_, new_n213_, new_n214_,
    new_n215_, new_n216_, new_n217_, new_n218_, new_n219_, new_n220_,
    new_n221_, new_n222_, new_n223_, new_n224_, new_n225_, new_n226_,
    new_n227_, new_n228_, new_n229_, new_n230_, new_n231_, new_n232_,
    new_n233_, new_n234_, new_n236_, new_n237_, new_n238_, new_n239_,
    new_n240_, new_n241_, new_n242_, new_n243_, new_n244_, new_n245_,
    new_n246_, new_n247_, new_n248_, new_n249_, new_n250_, new_n251_,
    new_n252_, new_n253_, new_n254_, new_n255_, new_n256_, new_n257_,
    new_n258_, new_n259_, new_n260_, new_n261_, new_n262_, new_n263_,
    new_n264_, new_n265_, new_n266_, new_n267_, new_n269_, new_n270_,
    new_n271_, new_n272_, new_n273_, new_n275_, new_n276_, new_n278_,
    new_n279_, new_n280_, new_n281_, new_n282_, new_n283_, new_n284_,
    new_n285_, new_n286_, new_n287_, new_n288_, new_n289_, new_n290_,
    new_n291_, new_n292_, new_n293_, new_n294_, new_n295_, new_n296_,
    new_n297_, new_n298_, new_n299_, new_n300_, new_n301_, new_n302_,
    new_n303_, new_n304_, new_n305_, new_n306_, new_n307_, new_n308_,
    new_n309_, new_n310_, new_n311_, new_n312_, new_n313_, new_n314_,
    new_n315_, new_n316_, new_n317_, new_n318_, new_n319_, new_n321_,
    new_n322_, new_n323_, new_n324_, new_n325_, new_n326_, new_n327_,
    new_n328_, new_n329_, new_n330_, new_n331_, new_n332_, new_n333_,
    new_n334_, new_n335_, new_n336_, new_n337_, new_n338_, new_n339_,
    new_n340_, new_n341_, new_n342_, new_n343_, new_n344_, new_n345_,
    new_n346_, new_n347_, new_n348_, new_n349_, new_n350_, new_n351_,
    new_n352_, new_n353_, new_n354_, new_n355_, new_n356_, new_n357_,
    new_n358_, new_n359_, new_n360_, new_n361_, new_n362_, new_n363_,
    new_n364_, new_n365_, new_n367_, new_n368_, new_n369_, new_n370_,
    new_n371_, new_n372_, new_n373_, new_n374_, new_n375_, new_n376_,
    new_n377_, new_n378_, new_n379_, new_n380_, new_n381_, new_n382_,
    new_n383_, new_n384_, new_n385_, new_n386_, new_n387_, new_n388_,
    new_n389_, new_n390_, new_n391_, new_n392_, new_n393_, new_n394_,
    new_n395_, new_n396_, new_n398_, new_n399_, new_n400_, new_n401_,
    new_n402_, new_n403_, new_n404_, new_n405_, new_n406_, new_n407_,
    new_n408_, new_n409_, new_n410_, new_n411_, new_n412_, new_n413_,
    new_n414_, new_n416_, new_n417_, new_n418_;
  NOR2x1_ASAP7_75t_R   g000(.A(p5), .B(p3), .Y(new_n22_));
  INVx1_ASAP7_75t_R    g001(.A(p0), .Y(new_n23_));
  INVx1_ASAP7_75t_R    g002(.A(p8), .Y(new_n24_));
  NOR2x1_ASAP7_75t_R   g003(.A(p9), .B(new_n24_), .Y(new_n25_));
  NAND2x1_ASAP7_75t_R  g004(.A(p8), .B(new_n23_), .Y(new_n26_));
  NOR2x1_ASAP7_75t_R   g005(.A(p2), .B(p4), .Y(new_n27_));
  OA211x2_ASAP7_75t_R  g006(.A1(new_n23_), .A2(new_n25_), .B(new_n26_), .C(new_n27_), .Y(new_n28_));
  XNOR2x2_ASAP7_75t_R  g007(.A(p0), .B(p8), .Y(new_n29_));
  INVx1_ASAP7_75t_R    g008(.A(p6), .Y(new_n30_));
  OA211x2_ASAP7_75t_R  g009(.A1(p0), .A2(p9), .B(new_n29_), .C(new_n30_), .Y(new_n31_));
  NOR2x1_ASAP7_75t_R   g010(.A(p1), .B(p7), .Y(new_n32_));
  OAI21x1_ASAP7_75t_R  g011(.A1(new_n28_), .A2(new_n31_), .B(new_n32_), .Y(new_n33_));
  NAND2x1_ASAP7_75t_R  g012(.A(p0), .B(p1), .Y(new_n34_));
  INVx1_ASAP7_75t_R    g013(.A(new_n34_), .Y(new_n35_));
  INVx1_ASAP7_75t_R    g014(.A(p9), .Y(new_n36_));
  OA21x2_ASAP7_75t_R   g015(.A1(p4), .A2(p1), .B(new_n36_), .Y(new_n37_));
  OAI21x1_ASAP7_75t_R  g016(.A1(new_n35_), .A2(new_n37_), .B(new_n24_), .Y(new_n38_));
  INVx1_ASAP7_75t_R    g017(.A(p2), .Y(new_n39_));
  INVx1_ASAP7_75t_R    g018(.A(p1), .Y(new_n40_));
  AO21x1_ASAP7_75t_R   g019(.A1(new_n39_), .A2(new_n40_), .B(new_n24_), .Y(new_n41_));
  NAND2x1_ASAP7_75t_R  g020(.A(p2), .B(p9), .Y(new_n42_));
  AND2x2_ASAP7_75t_R   g021(.A(new_n23_), .B(new_n42_), .Y(new_n43_));
  AO22x1_ASAP7_75t_R   g022(.A1(p2), .A2(p0), .B1(new_n41_), .B2(new_n43_), .Y(new_n44_));
  INVx1_ASAP7_75t_R    g023(.A(p7), .Y(new_n45_));
  NAND2x1_ASAP7_75t_R  g024(.A(new_n30_), .B(new_n45_), .Y(new_n46_));
  AO21x1_ASAP7_75t_R   g025(.A1(new_n38_), .A2(new_n44_), .B(new_n46_), .Y(new_n47_));
  NOR2x1_ASAP7_75t_R   g026(.A(p0), .B(p8), .Y(new_n48_));
  NOR2x1_ASAP7_75t_R   g027(.A(p9), .B(new_n40_), .Y(new_n49_));
  INVx1_ASAP7_75t_R    g028(.A(p4), .Y(new_n50_));
  AO21x1_ASAP7_75t_R   g029(.A1(new_n50_), .A2(new_n24_), .B(p0), .Y(new_n51_));
  NOR2x1_ASAP7_75t_R   g030(.A(p1), .B(new_n36_), .Y(new_n52_));
  AO32x1_ASAP7_75t_R   g031(.A1(p6), .A2(new_n48_), .A3(new_n49_), .B1(new_n51_), .B2(new_n52_), .Y(new_n53_));
  NOR2x1_ASAP7_75t_R   g032(.A(p4), .B(new_n45_), .Y(new_n54_));
  INVx1_ASAP7_75t_R    g033(.A(new_n54_), .Y(new_n55_));
  NOR2x1_ASAP7_75t_R   g034(.A(p4), .B(p8), .Y(new_n56_));
  OAI21x1_ASAP7_75t_R  g035(.A1(new_n30_), .A2(new_n56_), .B(new_n52_), .Y(new_n57_));
  NOR2x1_ASAP7_75t_R   g036(.A(p8), .B(new_n23_), .Y(new_n58_));
  AO21x1_ASAP7_75t_R   g037(.A1(new_n30_), .A2(new_n58_), .B(p2), .Y(new_n59_));
  AOI21x1_ASAP7_75t_R  g038(.A1(new_n55_), .A2(new_n57_), .B(new_n59_), .Y(new_n60_));
  NAND2x1_ASAP7_75t_R  g039(.A(new_n53_), .B(new_n60_), .Y(new_n61_));
  NAND3x1_ASAP7_75t_R  g040(.A(new_n33_), .B(new_n47_), .C(new_n61_), .Y(new_n62_));
  INVx1_ASAP7_75t_R    g041(.A(p3), .Y(new_n63_));
  AND2x2_ASAP7_75t_R   g042(.A(p4), .B(p5), .Y(new_n64_));
  AO21x1_ASAP7_75t_R   g043(.A1(p8), .A2(new_n63_), .B(new_n64_), .Y(new_n65_));
  NOR2x1_ASAP7_75t_R   g044(.A(p8), .B(p5), .Y(new_n66_));
  NOR3x1_ASAP7_75t_R   g045(.A(new_n65_), .B(p7), .C(new_n66_), .Y(new_n67_));
  AND2x2_ASAP7_75t_R   g046(.A(p7), .B(p3), .Y(new_n68_));
  AO21x1_ASAP7_75t_R   g047(.A1(p4), .A2(new_n45_), .B(new_n64_), .Y(new_n69_));
  OA21x2_ASAP7_75t_R   g048(.A1(new_n66_), .A2(new_n68_), .B(new_n69_), .Y(new_n70_));
  NOR2x1_ASAP7_75t_R   g049(.A(p2), .B(p1), .Y(new_n71_));
  AND3x1_ASAP7_75t_R   g050(.A(new_n71_), .B(new_n23_), .C(new_n36_), .Y(new_n72_));
  OA211x2_ASAP7_75t_R  g051(.A1(new_n67_), .A2(new_n70_), .B(new_n30_), .C(new_n72_), .Y(new_n73_));
  AOI21x1_ASAP7_75t_R  g052(.A1(new_n22_), .A2(new_n62_), .B(new_n73_), .Y(new_n74_));
  NOR2x1_ASAP7_75t_R   g053(.A(new_n23_), .B(new_n25_), .Y(new_n75_));
  AO21x1_ASAP7_75t_R   g054(.A1(p9), .A2(new_n24_), .B(p1), .Y(new_n76_));
  AO21x1_ASAP7_75t_R   g055(.A1(new_n39_), .A2(new_n75_), .B(new_n76_), .Y(new_n77_));
  INVx1_ASAP7_75t_R    g056(.A(p5), .Y(new_n78_));
  NAND2x1_ASAP7_75t_R  g057(.A(p4), .B(p7), .Y(new_n79_));
  AOI21x1_ASAP7_75t_R  g058(.A1(new_n78_), .A2(new_n76_), .B(new_n79_), .Y(new_n80_));
  AO21x1_ASAP7_75t_R   g059(.A1(p8), .A2(new_n23_), .B(p4), .Y(new_n81_));
  AO21x1_ASAP7_75t_R   g060(.A1(new_n36_), .A2(new_n40_), .B(p4), .Y(new_n82_));
  NOR2x1_ASAP7_75t_R   g061(.A(p8), .B(new_n36_), .Y(new_n83_));
  NOR2x1_ASAP7_75t_R   g062(.A(new_n83_), .B(new_n25_), .Y(new_n84_));
  AND3x1_ASAP7_75t_R   g063(.A(p4), .B(p0), .C(p1), .Y(new_n85_));
  AO32x1_ASAP7_75t_R   g064(.A1(p5), .A2(new_n81_), .A3(new_n82_), .B1(new_n84_), .B2(new_n85_), .Y(new_n86_));
  AND2x2_ASAP7_75t_R   g065(.A(p2), .B(p7), .Y(new_n87_));
  NOR2x1_ASAP7_75t_R   g066(.A(p8), .B(p1), .Y(new_n88_));
  AND2x2_ASAP7_75t_R   g067(.A(p8), .B(p1), .Y(new_n89_));
  AO21x1_ASAP7_75t_R   g068(.A1(p0), .A2(new_n88_), .B(new_n89_), .Y(new_n90_));
  AND3x1_ASAP7_75t_R   g069(.A(new_n39_), .B(new_n36_), .C(p5), .Y(new_n91_));
  NOR2x1_ASAP7_75t_R   g070(.A(p8), .B(p7), .Y(new_n92_));
  AO32x1_ASAP7_75t_R   g071(.A1(new_n90_), .A2(p7), .A3(new_n91_), .B1(new_n92_), .B2(new_n72_), .Y(new_n93_));
  AOI221x1_ASAP7_75t_R g072(.A1(new_n77_), .A2(new_n80_), .B1(new_n86_), .B2(new_n87_), .C(new_n93_), .Y(new_n94_));
  NAND2x1_ASAP7_75t_R  g073(.A(p8), .B(p1), .Y(new_n95_));
  NOR2x1_ASAP7_75t_R   g074(.A(p5), .B(new_n39_), .Y(new_n96_));
  AND2x2_ASAP7_75t_R   g075(.A(p2), .B(p1), .Y(new_n97_));
  OR4x2_ASAP7_75t_R    g076(.A(new_n96_), .B(p0), .C(p8), .D(new_n97_), .Y(new_n98_));
  AO21x1_ASAP7_75t_R   g077(.A1(new_n95_), .A2(new_n98_), .B(p7), .Y(new_n99_));
  NOR2x1_ASAP7_75t_R   g078(.A(p2), .B(p0), .Y(new_n100_));
  NOR2x1_ASAP7_75t_R   g079(.A(p7), .B(new_n23_), .Y(new_n101_));
  AO21x1_ASAP7_75t_R   g080(.A1(new_n89_), .A2(new_n100_), .B(new_n101_), .Y(new_n102_));
  NOR2x1_ASAP7_75t_R   g081(.A(p7), .B(new_n39_), .Y(new_n103_));
  OA21x2_ASAP7_75t_R   g082(.A1(p0), .A2(new_n25_), .B(new_n103_), .Y(new_n104_));
  AOI21x1_ASAP7_75t_R  g083(.A1(new_n36_), .A2(new_n102_), .B(new_n104_), .Y(new_n105_));
  OR5x1_ASAP7_75t_R    g084(.A(new_n39_), .B(new_n36_), .C(new_n40_), .D(p0), .E(p8), .Y(new_n106_));
  AO31x2_ASAP7_75t_R   g085(.A1(new_n99_), .A2(new_n105_), .A3(new_n106_), .B(p4), .Y(new_n107_));
  NOR2x1_ASAP7_75t_R   g086(.A(p6), .B(p3), .Y(new_n108_));
  INVx1_ASAP7_75t_R    g087(.A(new_n108_), .Y(new_n109_));
  AO21x1_ASAP7_75t_R   g088(.A1(new_n94_), .A2(new_n107_), .B(new_n109_), .Y(new_n110_));
  NAND2x1_ASAP7_75t_R  g089(.A(new_n74_), .B(new_n110_), .Y(o0));
  NAND2x1_ASAP7_75t_R  g090(.A(new_n39_), .B(new_n30_), .Y(new_n112_));
  NAND2x1_ASAP7_75t_R  g091(.A(p8), .B(p5), .Y(new_n113_));
  OAI21x1_ASAP7_75t_R  g092(.A1(p4), .A2(new_n45_), .B(new_n113_), .Y(new_n114_));
  NAND2x1_ASAP7_75t_R  g093(.A(p5), .B(p7), .Y(new_n115_));
  AND3x1_ASAP7_75t_R   g094(.A(new_n40_), .B(new_n45_), .C(p4), .Y(new_n116_));
  AO32x1_ASAP7_75t_R   g095(.A1(new_n52_), .A2(new_n114_), .A3(new_n115_), .B1(new_n116_), .B2(new_n25_), .Y(new_n117_));
  AND2x2_ASAP7_75t_R   g096(.A(p1), .B(p7), .Y(new_n118_));
  AOI22x1_ASAP7_75t_R  g097(.A1(new_n117_), .A2(p0), .B1(new_n66_), .B2(new_n118_), .Y(new_n119_));
  AND3x1_ASAP7_75t_R   g098(.A(p8), .B(p5), .C(p7), .Y(new_n120_));
  AND3x1_ASAP7_75t_R   g099(.A(new_n50_), .B(new_n24_), .C(new_n45_), .Y(new_n121_));
  OAI21x1_ASAP7_75t_R  g100(.A1(new_n120_), .A2(new_n121_), .B(p1), .Y(new_n122_));
  NAND2x1_ASAP7_75t_R  g101(.A(new_n24_), .B(new_n45_), .Y(new_n123_));
  NAND2x1_ASAP7_75t_R  g102(.A(p4), .B(new_n36_), .Y(new_n124_));
  OR3x1_ASAP7_75t_R    g103(.A(new_n123_), .B(new_n124_), .C(p1), .Y(new_n125_));
  AND2x2_ASAP7_75t_R   g104(.A(p4), .B(p1), .Y(new_n126_));
  AND3x1_ASAP7_75t_R   g105(.A(p9), .B(p8), .C(p7), .Y(new_n127_));
  AOI22x1_ASAP7_75t_R  g106(.A1(new_n114_), .A2(new_n49_), .B1(new_n126_), .B2(new_n127_), .Y(new_n128_));
  AO31x2_ASAP7_75t_R   g107(.A1(new_n122_), .A2(new_n125_), .A3(new_n128_), .B(p0), .Y(new_n129_));
  OR3x1_ASAP7_75t_R    g108(.A(new_n40_), .B(new_n45_), .C(p4), .Y(new_n130_));
  NAND2x1_ASAP7_75t_R  g109(.A(p7), .B(new_n36_), .Y(new_n131_));
  NAND2x1_ASAP7_75t_R  g110(.A(p5), .B(new_n50_), .Y(new_n132_));
  NAND2x1_ASAP7_75t_R  g111(.A(new_n78_), .B(new_n45_), .Y(new_n133_));
  OA21x2_ASAP7_75t_R   g112(.A1(new_n131_), .A2(new_n132_), .B(new_n133_), .Y(new_n134_));
  NAND2x1_ASAP7_75t_R  g113(.A(p0), .B(new_n24_), .Y(new_n135_));
  AO21x1_ASAP7_75t_R   g114(.A1(new_n130_), .A2(new_n134_), .B(new_n135_), .Y(new_n136_));
  NAND3x1_ASAP7_75t_R  g115(.A(new_n119_), .B(new_n129_), .C(new_n136_), .Y(new_n137_));
  OR3x1_ASAP7_75t_R    g116(.A(p0), .B(p9), .C(p1), .Y(new_n138_));
  INVx1_ASAP7_75t_R    g117(.A(new_n138_), .Y(new_n139_));
  AO21x1_ASAP7_75t_R   g118(.A1(p4), .A2(new_n45_), .B(new_n68_), .Y(new_n140_));
  AND3x1_ASAP7_75t_R   g119(.A(p8), .B(p5), .C(p3), .Y(new_n141_));
  AO21x1_ASAP7_75t_R   g120(.A1(new_n66_), .A2(new_n140_), .B(new_n141_), .Y(new_n142_));
  AOI22x1_ASAP7_75t_R  g121(.A1(new_n137_), .A2(new_n63_), .B1(new_n139_), .B2(new_n142_), .Y(new_n143_));
  OR3x1_ASAP7_75t_R    g122(.A(new_n115_), .B(new_n39_), .C(p0), .Y(new_n144_));
  NOR2x1_ASAP7_75t_R   g123(.A(p0), .B(p7), .Y(new_n145_));
  OR3x1_ASAP7_75t_R    g124(.A(new_n145_), .B(new_n39_), .C(p1), .Y(new_n146_));
  AO21x1_ASAP7_75t_R   g125(.A1(new_n144_), .A2(new_n146_), .B(p4), .Y(new_n147_));
  NOR2x1_ASAP7_75t_R   g126(.A(p9), .B(new_n45_), .Y(new_n148_));
  AND2x2_ASAP7_75t_R   g127(.A(p0), .B(p9), .Y(new_n149_));
  NOR2x1_ASAP7_75t_R   g128(.A(p0), .B(p5), .Y(new_n150_));
  OR5x1_ASAP7_75t_R    g129(.A(p4), .B(new_n148_), .C(p1), .D(new_n149_), .E(new_n150_), .Y(new_n151_));
  NOR2x1_ASAP7_75t_R   g130(.A(p2), .B(p7), .Y(new_n152_));
  OR5x1_ASAP7_75t_R    g131(.A(p0), .B(new_n54_), .C(new_n36_), .D(p5), .E(new_n152_), .Y(new_n153_));
  AND4x2_ASAP7_75t_R   g132(.A(new_n147_), .B(new_n151_), .C(new_n153_), .D(new_n24_), .Y(new_n154_));
  AO21x1_ASAP7_75t_R   g133(.A1(p2), .A2(p7), .B(p1), .Y(new_n155_));
  AO32x1_ASAP7_75t_R   g134(.A1(p4), .A2(new_n23_), .A3(new_n32_), .B1(new_n155_), .B2(new_n36_), .Y(new_n156_));
  NAND2x1_ASAP7_75t_R  g135(.A(p9), .B(p7), .Y(new_n157_));
  NOR2x1_ASAP7_75t_R   g136(.A(p1), .B(new_n157_), .Y(new_n158_));
  NAND2x1_ASAP7_75t_R  g137(.A(p9), .B(new_n50_), .Y(new_n159_));
  NAND2x1_ASAP7_75t_R  g138(.A(new_n124_), .B(new_n159_), .Y(new_n160_));
  OA21x2_ASAP7_75t_R   g139(.A1(new_n158_), .A2(new_n160_), .B(p0), .Y(new_n161_));
  OAI21x1_ASAP7_75t_R  g140(.A1(new_n156_), .A2(new_n161_), .B(new_n78_), .Y(new_n162_));
  NAND2x1_ASAP7_75t_R  g141(.A(p4), .B(p1), .Y(new_n163_));
  AOI22x1_ASAP7_75t_R  g142(.A1(new_n39_), .A2(new_n163_), .B1(new_n34_), .B2(new_n50_), .Y(new_n164_));
  NOR2x1_ASAP7_75t_R   g143(.A(p0), .B(new_n39_), .Y(new_n165_));
  AND2x2_ASAP7_75t_R   g144(.A(p4), .B(p0), .Y(new_n166_));
  AO21x1_ASAP7_75t_R   g145(.A1(new_n32_), .A2(new_n165_), .B(new_n166_), .Y(new_n167_));
  AND2x2_ASAP7_75t_R   g146(.A(p9), .B(p5), .Y(new_n168_));
  AO21x1_ASAP7_75t_R   g147(.A1(new_n85_), .A2(new_n103_), .B(new_n24_), .Y(new_n169_));
  AOI221x1_ASAP7_75t_R g148(.A1(p5), .A2(new_n164_), .B1(new_n167_), .B2(new_n168_), .C(new_n169_), .Y(new_n170_));
  AOI21x1_ASAP7_75t_R  g149(.A1(new_n154_), .A2(new_n162_), .B(new_n170_), .Y(new_n171_));
  NOR2x1_ASAP7_75t_R   g150(.A(p1), .B(new_n45_), .Y(new_n172_));
  AO32x1_ASAP7_75t_R   g151(.A1(new_n58_), .A2(new_n172_), .A3(p6), .B1(new_n48_), .B2(new_n49_), .Y(new_n173_));
  NOR2x1_ASAP7_75t_R   g152(.A(p0), .B(p9), .Y(new_n174_));
  NOR2x1_ASAP7_75t_R   g153(.A(new_n40_), .B(new_n174_), .Y(new_n175_));
  NOR2x1_ASAP7_75t_R   g154(.A(p7), .B(new_n175_), .Y(new_n176_));
  OA211x2_ASAP7_75t_R  g155(.A1(new_n76_), .A2(new_n149_), .B(new_n176_), .C(p6), .Y(new_n177_));
  NAND2x1_ASAP7_75t_R  g156(.A(new_n27_), .B(new_n22_), .Y(new_n178_));
  INVx1_ASAP7_75t_R    g157(.A(new_n178_), .Y(new_n179_));
  OA21x2_ASAP7_75t_R   g158(.A1(new_n173_), .A2(new_n177_), .B(new_n179_), .Y(new_n180_));
  AOI21x1_ASAP7_75t_R  g159(.A1(new_n108_), .A2(new_n171_), .B(new_n180_), .Y(new_n181_));
  OAI21x1_ASAP7_75t_R  g160(.A1(new_n112_), .A2(new_n143_), .B(new_n181_), .Y(o1));
  NAND2x1_ASAP7_75t_R  g161(.A(p8), .B(p7), .Y(new_n183_));
  OA21x2_ASAP7_75t_R   g162(.A1(p8), .A2(p7), .B(p1), .Y(new_n184_));
  AO21x1_ASAP7_75t_R   g163(.A1(new_n183_), .A2(new_n184_), .B(new_n32_), .Y(new_n185_));
  AND3x1_ASAP7_75t_R   g164(.A(p0), .B(p8), .C(p1), .Y(new_n186_));
  NOR2x1_ASAP7_75t_R   g165(.A(p0), .B(new_n45_), .Y(new_n187_));
  OAI21x1_ASAP7_75t_R  g166(.A1(new_n186_), .A2(new_n187_), .B(p5), .Y(new_n188_));
  AO21x1_ASAP7_75t_R   g167(.A1(new_n185_), .A2(new_n188_), .B(new_n39_), .Y(new_n189_));
  NAND2x1_ASAP7_75t_R  g168(.A(new_n152_), .B(new_n29_), .Y(new_n190_));
  AO21x1_ASAP7_75t_R   g169(.A1(p8), .A2(new_n23_), .B(new_n78_), .Y(new_n191_));
  AO21x1_ASAP7_75t_R   g170(.A1(new_n135_), .A2(new_n191_), .B(new_n45_), .Y(new_n192_));
  AO21x1_ASAP7_75t_R   g171(.A1(new_n190_), .A2(new_n192_), .B(p1), .Y(new_n193_));
  AOI21x1_ASAP7_75t_R  g172(.A1(new_n189_), .A2(new_n193_), .B(new_n159_), .Y(new_n194_));
  AO21x1_ASAP7_75t_R   g173(.A1(p2), .A2(new_n23_), .B(new_n50_), .Y(new_n195_));
  NOR2x1_ASAP7_75t_R   g174(.A(p0), .B(new_n71_), .Y(new_n196_));
  AO32x1_ASAP7_75t_R   g175(.A1(new_n195_), .A2(new_n92_), .A3(new_n52_), .B1(new_n127_), .B2(new_n196_), .Y(new_n197_));
  NOR2x1_ASAP7_75t_R   g176(.A(new_n92_), .B(new_n127_), .Y(new_n198_));
  NOR2x1_ASAP7_75t_R   g177(.A(new_n166_), .B(new_n186_), .Y(new_n199_));
  AOI211x1_ASAP7_75t_R g178(.A1(p4), .A2(new_n198_), .B(p2), .C(new_n199_), .Y(new_n200_));
  OA21x2_ASAP7_75t_R   g179(.A1(new_n48_), .A2(new_n123_), .B(p1), .Y(new_n201_));
  AND3x1_ASAP7_75t_R   g180(.A(new_n201_), .B(new_n39_), .C(new_n183_), .Y(new_n202_));
  OA31x2_ASAP7_75t_R   g181(.A1(new_n197_), .A2(new_n200_), .A3(new_n202_), .B1(new_n78_), .Y(new_n203_));
  OAI21x1_ASAP7_75t_R  g182(.A1(new_n194_), .A2(new_n203_), .B(new_n63_), .Y(new_n204_));
  AO21x1_ASAP7_75t_R   g183(.A1(new_n23_), .A2(new_n71_), .B(new_n63_), .Y(new_n205_));
  NAND2x1_ASAP7_75t_R  g184(.A(p5), .B(new_n45_), .Y(new_n206_));
  AO21x1_ASAP7_75t_R   g185(.A1(new_n183_), .A2(new_n206_), .B(p4), .Y(new_n207_));
  OA21x2_ASAP7_75t_R   g186(.A1(new_n63_), .A2(new_n207_), .B(new_n36_), .Y(new_n208_));
  NAND2x1_ASAP7_75t_R  g187(.A(new_n205_), .B(new_n208_), .Y(new_n209_));
  AO21x1_ASAP7_75t_R   g188(.A1(p7), .A2(new_n40_), .B(new_n39_), .Y(new_n210_));
  NAND2x1_ASAP7_75t_R  g189(.A(p4), .B(new_n210_), .Y(new_n211_));
  NOR2x1_ASAP7_75t_R   g190(.A(p1), .B(new_n39_), .Y(new_n212_));
  AND2x2_ASAP7_75t_R   g191(.A(p2), .B(p4), .Y(new_n213_));
  OR3x1_ASAP7_75t_R    g192(.A(new_n212_), .B(new_n45_), .C(new_n213_), .Y(new_n214_));
  AO21x1_ASAP7_75t_R   g193(.A1(new_n211_), .A2(new_n214_), .B(new_n135_), .Y(new_n215_));
  AO21x1_ASAP7_75t_R   g194(.A1(p2), .A2(new_n24_), .B(p5), .Y(new_n216_));
  NOR2x1_ASAP7_75t_R   g195(.A(new_n103_), .B(new_n58_), .Y(new_n217_));
  OA21x2_ASAP7_75t_R   g196(.A1(new_n216_), .A2(new_n217_), .B(new_n63_), .Y(new_n218_));
  AOI21x1_ASAP7_75t_R  g197(.A1(p8), .A2(new_n145_), .B(new_n40_), .Y(new_n219_));
  AND3x1_ASAP7_75t_R   g198(.A(new_n24_), .B(p0), .C(p7), .Y(new_n220_));
  OR4x2_ASAP7_75t_R    g199(.A(new_n219_), .B(new_n220_), .C(new_n39_), .D(new_n66_), .Y(new_n221_));
  AND2x2_ASAP7_75t_R   g200(.A(p5), .B(p1), .Y(new_n222_));
  AO21x1_ASAP7_75t_R   g201(.A1(p1), .A2(new_n45_), .B(new_n23_), .Y(new_n223_));
  AND2x2_ASAP7_75t_R   g202(.A(p4), .B(new_n155_), .Y(new_n224_));
  OAI21x1_ASAP7_75t_R  g203(.A1(new_n222_), .A2(new_n223_), .B(new_n224_), .Y(new_n225_));
  NAND2x1_ASAP7_75t_R  g204(.A(new_n48_), .B(new_n27_), .Y(new_n226_));
  OR3x1_ASAP7_75t_R    g205(.A(new_n23_), .B(new_n24_), .C(p2), .Y(new_n227_));
  AO21x1_ASAP7_75t_R   g206(.A1(new_n226_), .A2(new_n227_), .B(new_n206_), .Y(new_n228_));
  AND5x1_ASAP7_75t_R   g207(.A(new_n215_), .B(new_n218_), .C(new_n221_), .D(new_n225_), .E(new_n228_), .Y(new_n229_));
  AND2x2_ASAP7_75t_R   g208(.A(p8), .B(p7), .Y(new_n230_));
  AO21x1_ASAP7_75t_R   g209(.A1(p6), .A2(new_n230_), .B(new_n36_), .Y(new_n231_));
  AOI22x1_ASAP7_75t_R  g210(.A1(new_n231_), .A2(new_n75_), .B1(new_n83_), .B2(new_n145_), .Y(new_n232_));
  OR3x1_ASAP7_75t_R    g211(.A(new_n232_), .B(p1), .C(new_n178_), .Y(new_n233_));
  OA31x2_ASAP7_75t_R   g212(.A1(p6), .A2(new_n209_), .A3(new_n229_), .B1(new_n233_), .Y(new_n234_));
  OAI21x1_ASAP7_75t_R  g213(.A1(p6), .A2(new_n204_), .B(new_n234_), .Y(o2));
  AO32x1_ASAP7_75t_R   g214(.A1(new_n32_), .A2(new_n150_), .A3(p4), .B1(p5), .B2(new_n27_), .Y(new_n236_));
  NAND2x1_ASAP7_75t_R  g215(.A(p1), .B(new_n39_), .Y(new_n237_));
  AO21x1_ASAP7_75t_R   g216(.A1(new_n79_), .A2(new_n237_), .B(new_n118_), .Y(new_n238_));
  AOI21x1_ASAP7_75t_R  g217(.A1(new_n130_), .A2(new_n238_), .B(p8), .Y(new_n239_));
  AND3x1_ASAP7_75t_R   g218(.A(new_n32_), .B(p4), .C(p8), .Y(new_n240_));
  NAND2x1_ASAP7_75t_R  g219(.A(p2), .B(new_n50_), .Y(new_n241_));
  OA21x2_ASAP7_75t_R   g220(.A1(p5), .A2(new_n103_), .B(new_n241_), .Y(new_n242_));
  OR4x2_ASAP7_75t_R    g221(.A(new_n239_), .B(new_n240_), .C(new_n212_), .D(new_n242_), .Y(new_n243_));
  AND2x2_ASAP7_75t_R   g222(.A(p0), .B(p8), .Y(new_n244_));
  AO21x1_ASAP7_75t_R   g223(.A1(p4), .A2(p7), .B(new_n244_), .Y(new_n245_));
  OA211x2_ASAP7_75t_R  g224(.A1(new_n50_), .A2(new_n24_), .B(new_n245_), .C(new_n96_), .Y(new_n246_));
  NAND2x1_ASAP7_75t_R  g225(.A(p2), .B(new_n78_), .Y(new_n247_));
  AO21x1_ASAP7_75t_R   g226(.A1(p7), .A2(new_n95_), .B(new_n247_), .Y(new_n248_));
  AO21x1_ASAP7_75t_R   g227(.A1(new_n123_), .A2(new_n41_), .B(new_n132_), .Y(new_n249_));
  AOI21x1_ASAP7_75t_R  g228(.A1(new_n248_), .A2(new_n249_), .B(p0), .Y(new_n250_));
  AND2x2_ASAP7_75t_R   g229(.A(p0), .B(p5), .Y(new_n251_));
  AO21x1_ASAP7_75t_R   g230(.A1(new_n78_), .A2(new_n45_), .B(new_n56_), .Y(new_n252_));
  AO32x1_ASAP7_75t_R   g231(.A1(p7), .A2(new_n56_), .A3(new_n251_), .B1(new_n252_), .B2(new_n212_), .Y(new_n253_));
  OR3x1_ASAP7_75t_R    g232(.A(new_n246_), .B(new_n250_), .C(new_n253_), .Y(new_n254_));
  AOI221x1_ASAP7_75t_R g233(.A1(new_n83_), .A2(new_n236_), .B1(new_n243_), .B2(new_n149_), .C(new_n254_), .Y(new_n255_));
  AND3x1_ASAP7_75t_R   g234(.A(new_n30_), .B(new_n36_), .C(new_n63_), .Y(new_n256_));
  AO32x1_ASAP7_75t_R   g235(.A1(new_n50_), .A2(p5), .A3(p1), .B1(new_n216_), .B2(new_n196_), .Y(new_n257_));
  AOI21x1_ASAP7_75t_R  g236(.A1(new_n35_), .A2(new_n121_), .B(new_n257_), .Y(new_n258_));
  OR3x1_ASAP7_75t_R    g237(.A(new_n163_), .B(new_n183_), .C(p5), .Y(new_n259_));
  AO21x1_ASAP7_75t_R   g238(.A1(new_n39_), .A2(new_n206_), .B(new_n69_), .Y(new_n260_));
  AO21x1_ASAP7_75t_R   g239(.A1(new_n259_), .A2(new_n260_), .B(new_n23_), .Y(new_n261_));
  NAND2x1_ASAP7_75t_R  g240(.A(new_n258_), .B(new_n261_), .Y(new_n262_));
  NOR2x1_ASAP7_75t_R   g241(.A(p4), .B(p5), .Y(new_n263_));
  AO21x1_ASAP7_75t_R   g242(.A1(new_n263_), .A2(new_n230_), .B(new_n64_), .Y(new_n264_));
  AND3x1_ASAP7_75t_R   g243(.A(new_n174_), .B(new_n71_), .C(p3), .Y(new_n265_));
  AND3x1_ASAP7_75t_R   g244(.A(new_n264_), .B(new_n30_), .C(new_n265_), .Y(new_n266_));
  AOI21x1_ASAP7_75t_R  g245(.A1(new_n256_), .A2(new_n262_), .B(new_n266_), .Y(new_n267_));
  OAI21x1_ASAP7_75t_R  g246(.A1(new_n109_), .A2(new_n255_), .B(new_n267_), .Y(o3));
  OR3x1_ASAP7_75t_R    g247(.A(new_n174_), .B(new_n40_), .C(p3), .Y(new_n269_));
  NAND2x1_ASAP7_75t_R  g248(.A(p3), .B(new_n39_), .Y(new_n270_));
  NAND2x1_ASAP7_75t_R  g249(.A(p2), .B(new_n63_), .Y(new_n271_));
  AO21x1_ASAP7_75t_R   g250(.A1(new_n270_), .A2(new_n271_), .B(new_n138_), .Y(new_n272_));
  OR3x1_ASAP7_75t_R    g251(.A(new_n50_), .B(new_n78_), .C(p6), .Y(new_n273_));
  AOI21x1_ASAP7_75t_R  g252(.A1(new_n269_), .A2(new_n272_), .B(new_n273_), .Y(o4));
  AO21x1_ASAP7_75t_R   g253(.A1(new_n40_), .A2(new_n174_), .B(new_n271_), .Y(new_n275_));
  INVx1_ASAP7_75t_R    g254(.A(new_n265_), .Y(new_n276_));
  AOI21x1_ASAP7_75t_R  g255(.A1(new_n275_), .A2(new_n276_), .B(new_n273_), .Y(o5));
  NOR2x1_ASAP7_75t_R   g256(.A(p9), .B(p5), .Y(new_n278_));
  INVx1_ASAP7_75t_R    g257(.A(new_n278_), .Y(new_n279_));
  AO21x1_ASAP7_75t_R   g258(.A1(new_n34_), .A2(new_n279_), .B(new_n145_), .Y(new_n280_));
  AO21x1_ASAP7_75t_R   g259(.A1(new_n23_), .A2(new_n123_), .B(new_n36_), .Y(new_n281_));
  OAI22x1_ASAP7_75t_R  g260(.A1(new_n280_), .A2(new_n29_), .B1(new_n281_), .B2(new_n58_), .Y(new_n282_));
  OA21x2_ASAP7_75t_R   g261(.A1(p9), .A2(new_n40_), .B(new_n101_), .Y(new_n283_));
  NOR2x1_ASAP7_75t_R   g262(.A(p9), .B(p7), .Y(new_n284_));
  INVx1_ASAP7_75t_R    g263(.A(new_n284_), .Y(new_n285_));
  AND3x1_ASAP7_75t_R   g264(.A(new_n285_), .B(new_n58_), .C(new_n159_), .Y(new_n286_));
  AO221x2_ASAP7_75t_R  g265(.A1(new_n52_), .A2(new_n120_), .B1(new_n283_), .B2(p8), .C(new_n286_), .Y(new_n287_));
  AOI21x1_ASAP7_75t_R  g266(.A1(new_n50_), .A2(new_n282_), .B(new_n287_), .Y(new_n288_));
  AO21x1_ASAP7_75t_R   g267(.A1(p1), .A2(new_n50_), .B(p5), .Y(new_n289_));
  AO32x1_ASAP7_75t_R   g268(.A1(new_n84_), .A2(p4), .A3(new_n40_), .B1(new_n25_), .B2(new_n289_), .Y(new_n290_));
  NOR2x1_ASAP7_75t_R   g269(.A(p0), .B(p1), .Y(new_n291_));
  AND5x1_ASAP7_75t_R   g270(.A(new_n24_), .B(new_n279_), .C(new_n131_), .D(new_n79_), .E(new_n291_), .Y(new_n292_));
  OR3x1_ASAP7_75t_R    g271(.A(new_n127_), .B(new_n89_), .C(new_n118_), .Y(new_n293_));
  AO32x1_ASAP7_75t_R   g272(.A1(p1), .A2(new_n25_), .A3(new_n187_), .B1(new_n293_), .B2(new_n251_), .Y(new_n294_));
  AOI211x1_ASAP7_75t_R g273(.A1(new_n101_), .A2(new_n290_), .B(new_n292_), .C(new_n294_), .Y(new_n295_));
  OAI21x1_ASAP7_75t_R  g274(.A1(new_n39_), .A2(new_n288_), .B(new_n295_), .Y(new_n296_));
  OR3x1_ASAP7_75t_R    g275(.A(p0), .B(p8), .C(p7), .Y(new_n297_));
  OR3x1_ASAP7_75t_R    g276(.A(new_n24_), .B(new_n40_), .C(p9), .Y(new_n298_));
  AO21x1_ASAP7_75t_R   g277(.A1(new_n297_), .A2(new_n298_), .B(new_n50_), .Y(new_n299_));
  NOR2x1_ASAP7_75t_R   g278(.A(new_n92_), .B(new_n230_), .Y(new_n300_));
  NOR2x1_ASAP7_75t_R   g279(.A(new_n32_), .B(new_n118_), .Y(new_n301_));
  OR3x1_ASAP7_75t_R    g280(.A(new_n300_), .B(new_n301_), .C(new_n78_), .Y(new_n302_));
  NAND2x1_ASAP7_75t_R  g281(.A(new_n299_), .B(new_n302_), .Y(new_n303_));
  AO32x1_ASAP7_75t_R   g282(.A1(new_n163_), .A2(new_n34_), .A3(new_n66_), .B1(new_n244_), .B2(p4), .Y(new_n304_));
  INVx1_ASAP7_75t_R    g283(.A(new_n56_), .Y(new_n305_));
  AND2x2_ASAP7_75t_R   g284(.A(new_n49_), .B(new_n305_), .Y(new_n306_));
  AO21x1_ASAP7_75t_R   g285(.A1(p1), .A2(new_n305_), .B(p9), .Y(new_n307_));
  OA211x2_ASAP7_75t_R  g286(.A1(new_n304_), .A2(new_n306_), .B(new_n307_), .C(p7), .Y(new_n308_));
  AND3x1_ASAP7_75t_R   g287(.A(new_n39_), .B(new_n30_), .C(new_n63_), .Y(new_n309_));
  OAI21x1_ASAP7_75t_R  g288(.A1(new_n303_), .A2(new_n308_), .B(new_n309_), .Y(new_n310_));
  NOR2x1_ASAP7_75t_R   g289(.A(p0), .B(new_n92_), .Y(new_n311_));
  OR3x1_ASAP7_75t_R    g290(.A(new_n311_), .B(new_n30_), .C(p1), .Y(new_n312_));
  AO21x1_ASAP7_75t_R   g291(.A1(p6), .A2(new_n24_), .B(new_n45_), .Y(new_n313_));
  NOR2x1_ASAP7_75t_R   g292(.A(p0), .B(new_n40_), .Y(new_n314_));
  AOI22x1_ASAP7_75t_R  g293(.A1(new_n313_), .A2(new_n314_), .B1(p0), .B2(new_n88_), .Y(new_n315_));
  OA22x2_ASAP7_75t_R   g294(.A1(new_n312_), .A2(new_n198_), .B1(p9), .B2(new_n315_), .Y(new_n316_));
  OA21x2_ASAP7_75t_R   g295(.A1(p6), .A2(new_n276_), .B(new_n273_), .Y(new_n317_));
  OA21x2_ASAP7_75t_R   g296(.A1(new_n178_), .A2(new_n316_), .B(new_n317_), .Y(new_n318_));
  NAND2x1_ASAP7_75t_R  g297(.A(new_n310_), .B(new_n318_), .Y(new_n319_));
  AOI21x1_ASAP7_75t_R  g298(.A1(new_n108_), .A2(new_n296_), .B(new_n319_), .Y(o6));
  AO32x1_ASAP7_75t_R   g299(.A1(p6), .A2(new_n24_), .A3(new_n158_), .B1(new_n300_), .B2(new_n49_), .Y(new_n321_));
  AND3x1_ASAP7_75t_R   g300(.A(new_n321_), .B(new_n100_), .C(new_n263_), .Y(new_n322_));
  OA21x2_ASAP7_75t_R   g301(.A1(new_n30_), .A2(new_n322_), .B(new_n63_), .Y(new_n323_));
  OAI21x1_ASAP7_75t_R  g302(.A1(new_n247_), .A2(new_n131_), .B(new_n206_), .Y(new_n324_));
  AOI21x1_ASAP7_75t_R  g303(.A1(p8), .A2(p5), .B(p7), .Y(new_n325_));
  AOI211x1_ASAP7_75t_R g304(.A1(new_n36_), .A2(p8), .B(new_n278_), .C(new_n325_), .Y(new_n326_));
  AOI22x1_ASAP7_75t_R  g305(.A1(new_n324_), .A2(p8), .B1(new_n247_), .B2(new_n326_), .Y(new_n327_));
  OAI21x1_ASAP7_75t_R  g306(.A1(new_n39_), .A2(new_n230_), .B(new_n157_), .Y(new_n328_));
  NOR2x1_ASAP7_75t_R   g307(.A(p5), .B(new_n40_), .Y(new_n329_));
  NOR2x1_ASAP7_75t_R   g308(.A(new_n183_), .B(new_n237_), .Y(new_n330_));
  AOI221x1_ASAP7_75t_R g309(.A1(new_n66_), .A2(new_n152_), .B1(new_n328_), .B2(new_n329_), .C(new_n330_), .Y(new_n331_));
  OAI21x1_ASAP7_75t_R  g310(.A1(p1), .A2(new_n327_), .B(new_n331_), .Y(new_n332_));
  NAND2x1_ASAP7_75t_R  g311(.A(p5), .B(new_n36_), .Y(new_n333_));
  AOI21x1_ASAP7_75t_R  g312(.A1(new_n183_), .A2(new_n123_), .B(new_n333_), .Y(new_n334_));
  AO21x1_ASAP7_75t_R   g313(.A1(p8), .A2(p7), .B(p5), .Y(new_n335_));
  NOR3x1_ASAP7_75t_R   g314(.A(new_n83_), .B(p1), .C(new_n335_), .Y(new_n336_));
  OAI21x1_ASAP7_75t_R  g315(.A1(new_n334_), .A2(new_n336_), .B(new_n165_), .Y(new_n337_));
  NOR3x1_ASAP7_75t_R   g316(.A(p9), .B(p1), .C(p7), .Y(new_n338_));
  AND3x1_ASAP7_75t_R   g317(.A(p9), .B(p5), .C(p7), .Y(new_n339_));
  OA21x2_ASAP7_75t_R   g318(.A1(new_n338_), .A2(new_n339_), .B(new_n24_), .Y(new_n340_));
  OA21x2_ASAP7_75t_R   g319(.A1(p5), .A2(new_n152_), .B(new_n184_), .Y(new_n341_));
  OAI21x1_ASAP7_75t_R  g320(.A1(new_n340_), .A2(new_n341_), .B(new_n23_), .Y(new_n342_));
  OR5x1_ASAP7_75t_R    g321(.A(new_n39_), .B(new_n78_), .C(p8), .D(p1), .E(p7), .Y(new_n343_));
  NAND3x1_ASAP7_75t_R  g322(.A(new_n337_), .B(new_n342_), .C(new_n343_), .Y(new_n344_));
  AOI21x1_ASAP7_75t_R  g323(.A1(p0), .A2(new_n332_), .B(new_n344_), .Y(new_n345_));
  AND3x1_ASAP7_75t_R   g324(.A(new_n92_), .B(p2), .C(p9), .Y(new_n346_));
  AOI22x1_ASAP7_75t_R  g325(.A1(p2), .A2(p1), .B1(p8), .B2(p7), .Y(new_n347_));
  NAND2x1_ASAP7_75t_R  g326(.A(new_n347_), .B(new_n123_), .Y(new_n348_));
  AOI211x1_ASAP7_75t_R g327(.A1(new_n40_), .A2(new_n42_), .B(new_n50_), .C(p0), .Y(new_n349_));
  AND3x1_ASAP7_75t_R   g328(.A(new_n126_), .B(new_n230_), .C(p2), .Y(new_n350_));
  AOI221x1_ASAP7_75t_R g329(.A1(new_n314_), .A2(new_n346_), .B1(new_n348_), .B2(new_n349_), .C(new_n350_), .Y(new_n351_));
  AOI21x1_ASAP7_75t_R  g330(.A1(new_n23_), .A2(new_n351_), .B(p5), .Y(new_n352_));
  OR3x1_ASAP7_75t_R    g331(.A(new_n89_), .B(new_n88_), .C(new_n157_), .Y(new_n353_));
  OR4x2_ASAP7_75t_R    g332(.A(new_n50_), .B(new_n45_), .C(p9), .D(p8), .Y(new_n354_));
  OR3x1_ASAP7_75t_R    g333(.A(new_n95_), .B(new_n50_), .C(p7), .Y(new_n355_));
  AO31x2_ASAP7_75t_R   g334(.A1(new_n353_), .A2(new_n354_), .A3(new_n355_), .B(p2), .Y(new_n356_));
  AO21x1_ASAP7_75t_R   g335(.A1(new_n24_), .A2(p1), .B(new_n213_), .Y(new_n357_));
  NOR2x1_ASAP7_75t_R   g336(.A(p1), .B(new_n50_), .Y(new_n358_));
  AND3x1_ASAP7_75t_R   g337(.A(new_n358_), .B(p2), .C(new_n183_), .Y(new_n359_));
  AOI21x1_ASAP7_75t_R  g338(.A1(new_n284_), .A2(new_n357_), .B(new_n359_), .Y(new_n360_));
  NAND3x1_ASAP7_75t_R  g339(.A(new_n356_), .B(new_n351_), .C(new_n360_), .Y(new_n361_));
  AOI21x1_ASAP7_75t_R  g340(.A1(new_n352_), .A2(new_n361_), .B(new_n322_), .Y(new_n362_));
  OAI21x1_ASAP7_75t_R  g341(.A1(p4), .A2(new_n345_), .B(new_n362_), .Y(new_n363_));
  OR3x1_ASAP7_75t_R    g342(.A(new_n276_), .B(p4), .C(p6), .Y(new_n364_));
  NOR2x1_ASAP7_75t_R   g343(.A(p5), .B(new_n364_), .Y(new_n365_));
  AOI21x1_ASAP7_75t_R  g344(.A1(new_n323_), .A2(new_n363_), .B(new_n365_), .Y(o7));
  AO21x1_ASAP7_75t_R   g345(.A1(p4), .A2(new_n23_), .B(new_n27_), .Y(new_n367_));
  NAND2x1_ASAP7_75t_R  g346(.A(new_n39_), .B(new_n36_), .Y(new_n368_));
  AND3x1_ASAP7_75t_R   g347(.A(new_n367_), .B(new_n368_), .C(new_n172_), .Y(new_n369_));
  AOI211x1_ASAP7_75t_R g348(.A1(new_n50_), .A2(new_n131_), .B(new_n34_), .C(new_n213_), .Y(new_n370_));
  NOR2x1_ASAP7_75t_R   g349(.A(p0), .B(new_n36_), .Y(new_n371_));
  AND3x1_ASAP7_75t_R   g350(.A(new_n371_), .B(p7), .C(new_n27_), .Y(new_n372_));
  OR3x1_ASAP7_75t_R    g351(.A(new_n369_), .B(new_n370_), .C(new_n372_), .Y(new_n373_));
  AO21x1_ASAP7_75t_R   g352(.A1(new_n50_), .A2(p1), .B(new_n213_), .Y(new_n374_));
  AND3x1_ASAP7_75t_R   g353(.A(new_n291_), .B(p2), .C(p7), .Y(new_n375_));
  AO32x1_ASAP7_75t_R   g354(.A1(new_n374_), .A2(p0), .A3(new_n210_), .B1(new_n124_), .B2(new_n375_), .Y(new_n376_));
  NOR2x1_ASAP7_75t_R   g355(.A(p5), .B(new_n24_), .Y(new_n377_));
  AOI22x1_ASAP7_75t_R  g356(.A1(new_n373_), .A2(new_n66_), .B1(new_n376_), .B2(new_n377_), .Y(new_n378_));
  OAI21x1_ASAP7_75t_R  g357(.A1(new_n88_), .A2(new_n212_), .B(new_n367_), .Y(new_n379_));
  AO21x1_ASAP7_75t_R   g358(.A1(new_n23_), .A2(new_n24_), .B(new_n379_), .Y(new_n380_));
  NAND2x1_ASAP7_75t_R  g359(.A(new_n48_), .B(new_n358_), .Y(new_n381_));
  AO21x1_ASAP7_75t_R   g360(.A1(new_n227_), .A2(new_n381_), .B(p9), .Y(new_n382_));
  NOR2x1_ASAP7_75t_R   g361(.A(p4), .B(p0), .Y(new_n383_));
  INVx1_ASAP7_75t_R    g362(.A(new_n237_), .Y(new_n384_));
  OAI21x1_ASAP7_75t_R  g363(.A1(new_n383_), .A2(new_n29_), .B(new_n384_), .Y(new_n385_));
  AO31x2_ASAP7_75t_R   g364(.A1(new_n380_), .A2(new_n382_), .A3(new_n385_), .B(new_n133_), .Y(new_n386_));
  NOR2x1_ASAP7_75t_R   g365(.A(p5), .B(new_n101_), .Y(new_n387_));
  AO21x1_ASAP7_75t_R   g366(.A1(new_n135_), .A2(new_n148_), .B(new_n191_), .Y(new_n388_));
  AO221x2_ASAP7_75t_R  g367(.A1(new_n281_), .A2(new_n387_), .B1(new_n388_), .B2(new_n40_), .C(new_n241_), .Y(new_n389_));
  NAND3x1_ASAP7_75t_R  g368(.A(new_n378_), .B(new_n386_), .C(new_n389_), .Y(new_n390_));
  NAND2x1_ASAP7_75t_R  g369(.A(new_n244_), .B(new_n338_), .Y(new_n391_));
  AOI22x1_ASAP7_75t_R  g370(.A1(new_n158_), .A2(new_n24_), .B1(new_n89_), .B2(new_n284_), .Y(new_n392_));
  OR3x1_ASAP7_75t_R    g371(.A(new_n301_), .B(p9), .C(p8), .Y(new_n393_));
  AO21x1_ASAP7_75t_R   g372(.A1(new_n392_), .A2(new_n393_), .B(p0), .Y(new_n394_));
  AO21x1_ASAP7_75t_R   g373(.A1(new_n391_), .A2(new_n394_), .B(new_n178_), .Y(new_n395_));
  NAND2x1_ASAP7_75t_R  g374(.A(new_n364_), .B(new_n395_), .Y(new_n396_));
  AOI21x1_ASAP7_75t_R  g375(.A1(new_n108_), .A2(new_n390_), .B(new_n396_), .Y(o8));
  OR3x1_ASAP7_75t_R    g376(.A(new_n247_), .B(new_n159_), .C(new_n40_), .Y(new_n398_));
  AO21x1_ASAP7_75t_R   g377(.A1(new_n30_), .A2(new_n398_), .B(new_n311_), .Y(new_n399_));
  AO21x1_ASAP7_75t_R   g378(.A1(new_n36_), .A2(new_n384_), .B(new_n30_), .Y(new_n400_));
  OA211x2_ASAP7_75t_R  g379(.A1(new_n50_), .A2(new_n78_), .B(new_n399_), .C(new_n400_), .Y(new_n401_));
  NOR2x1_ASAP7_75t_R   g380(.A(p2), .B(new_n263_), .Y(new_n402_));
  AO32x1_ASAP7_75t_R   g381(.A1(new_n97_), .A2(new_n183_), .A3(new_n263_), .B1(new_n402_), .B2(new_n335_), .Y(new_n403_));
  AO21x1_ASAP7_75t_R   g382(.A1(new_n39_), .A2(new_n305_), .B(new_n148_), .Y(new_n404_));
  NAND2x1_ASAP7_75t_R  g383(.A(p2), .B(new_n113_), .Y(new_n405_));
  AND3x1_ASAP7_75t_R   g384(.A(new_n404_), .B(new_n40_), .C(new_n405_), .Y(new_n406_));
  OAI21x1_ASAP7_75t_R  g385(.A1(new_n403_), .A2(new_n406_), .B(p0), .Y(new_n407_));
  AOI22x1_ASAP7_75t_R  g386(.A1(new_n371_), .A2(new_n71_), .B1(new_n241_), .B2(new_n222_), .Y(new_n408_));
  AO21x1_ASAP7_75t_R   g387(.A1(p8), .A2(p7), .B(p4), .Y(new_n409_));
  AO21x1_ASAP7_75t_R   g388(.A1(p4), .A2(p8), .B(p5), .Y(new_n410_));
  AO21x1_ASAP7_75t_R   g389(.A1(new_n148_), .A2(new_n410_), .B(new_n405_), .Y(new_n411_));
  OA21x2_ASAP7_75t_R   g390(.A1(new_n263_), .A2(new_n270_), .B(new_n40_), .Y(new_n412_));
  AO32x1_ASAP7_75t_R   g391(.A1(new_n384_), .A2(new_n123_), .A3(new_n409_), .B1(new_n411_), .B2(new_n412_), .Y(new_n413_));
  NAND2x1_ASAP7_75t_R  g392(.A(new_n23_), .B(new_n413_), .Y(new_n414_));
  AND5x1_ASAP7_75t_R   g393(.A(new_n205_), .B(new_n401_), .C(new_n407_), .D(new_n408_), .E(new_n414_), .Y(o9));
  AND3x1_ASAP7_75t_R   g394(.A(new_n50_), .B(new_n30_), .C(new_n78_), .Y(new_n416_));
  OR3x1_ASAP7_75t_R    g395(.A(new_n58_), .B(new_n45_), .C(new_n149_), .Y(new_n417_));
  AND5x1_ASAP7_75t_R   g396(.A(p2), .B(new_n417_), .C(new_n63_), .D(new_n26_), .E(new_n175_), .Y(new_n418_));
  AO21x1_ASAP7_75t_R   g397(.A1(new_n416_), .A2(new_n418_), .B(new_n365_), .Y(o10));
endmodule


