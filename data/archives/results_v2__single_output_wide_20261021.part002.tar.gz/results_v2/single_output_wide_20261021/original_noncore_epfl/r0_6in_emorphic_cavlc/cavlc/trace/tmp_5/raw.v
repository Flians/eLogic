// Benchmark "/tmp/" written by ABC on Wed Oct 21 14:26:12 2026

module \/tmp/  ( 
    p2, p7, p4, p1, p8, p6, p9, p5, p3, p0,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10  );
  input  p2, p7, p4, p1, p8, p6, p9, p5, p3, p0;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10;
  wire new_n22_, new_n23_, new_n24_, new_n25_, new_n26_, new_n27_, new_n28_,
    new_n29_, new_n30_, new_n31_, new_n32_, new_n33_, new_n34_, new_n35_,
    new_n36_, new_n37_, new_n38_, new_n39_, new_n40_, new_n41_, new_n42_,
    new_n43_, new_n44_, new_n45_, new_n46_, new_n47_, new_n48_, new_n49_,
    new_n50_, new_n51_, new_n52_, new_n53_, new_n54_, new_n55_, new_n56_,
    new_n57_, new_n58_, new_n59_, new_n60_, new_n61_, new_n62_, new_n63_,
    new_n64_, new_n65_, new_n66_, new_n67_, new_n68_, new_n69_, new_n70_,
    new_n71_, new_n72_, new_n73_, new_n74_, new_n75_, new_n76_, new_n77_,
    new_n78_, new_n79_, new_n80_, new_n81_, new_n82_, new_n83_, new_n84_,
    new_n85_, new_n86_, new_n87_, new_n88_, new_n89_, new_n90_, new_n91_,
    new_n92_, new_n93_, new_n94_, new_n95_, new_n96_, new_n97_, new_n98_,
    new_n99_, new_n100_, new_n101_, new_n102_, new_n103_, new_n104_,
    new_n105_, new_n106_, new_n107_, new_n108_, new_n109_, new_n110_,
    new_n111_, new_n112_, new_n113_, new_n114_, new_n115_, new_n116_,
    new_n117_, new_n118_, new_n120_, new_n121_, new_n122_, new_n123_,
    new_n124_, new_n125_, new_n126_, new_n127_, new_n128_, new_n129_,
    new_n130_, new_n131_, new_n132_, new_n133_, new_n134_, new_n135_,
    new_n136_, new_n137_, new_n138_, new_n139_, new_n140_, new_n141_,
    new_n142_, new_n143_, new_n144_, new_n145_, new_n146_, new_n147_,
    new_n148_, new_n149_, new_n150_, new_n151_, new_n152_, new_n153_,
    new_n154_, new_n155_, new_n156_, new_n157_, new_n158_, new_n159_,
    new_n160_, new_n161_, new_n162_, new_n163_, new_n164_, new_n165_,
    new_n166_, new_n167_, new_n168_, new_n169_, new_n170_, new_n171_,
    new_n172_, new_n173_, new_n174_, new_n175_, new_n176_, new_n177_,
    new_n178_, new_n179_, new_n180_, new_n181_, new_n182_, new_n183_,
    new_n184_, new_n185_, new_n186_, new_n187_, new_n188_, new_n190_,
    new_n191_, new_n192_, new_n193_, new_n194_, new_n195_, new_n196_,
    new_n197_, new_n198_, new_n199_, new_n200_, new_n201_, new_n202_,
    new_n203_, new_n204_, new_n205_, new_n206_, new_n207_, new_n208_,
    new_n209_, new_n210_, new_n211_, new_n212_, new_n213_, new_n214_,
    new_n215_, new_n216_, new_n217_, new_n218_, new_n219_, new_n220_,
    new_n221_, new_n222_, new_n223_, new_n224_, new_n225_, new_n226_,
    new_n227_, new_n228_, new_n229_, new_n230_, new_n231_, new_n232_,
    new_n233_, new_n234_, new_n235_, new_n236_, new_n237_, new_n238_,
    new_n239_, new_n240_, new_n242_, new_n243_, new_n244_, new_n245_,
    new_n246_, new_n247_, new_n248_, new_n249_, new_n250_, new_n251_,
    new_n252_, new_n253_, new_n254_, new_n255_, new_n256_, new_n257_,
    new_n258_, new_n259_, new_n260_, new_n261_, new_n262_, new_n263_,
    new_n264_, new_n265_, new_n266_, new_n267_, new_n268_, new_n269_,
    new_n270_, new_n271_, new_n272_, new_n273_, new_n274_, new_n275_,
    new_n276_, new_n277_, new_n278_, new_n279_, new_n280_, new_n281_,
    new_n283_, new_n284_, new_n285_, new_n287_, new_n288_, new_n290_,
    new_n291_, new_n292_, new_n293_, new_n294_, new_n295_, new_n296_,
    new_n297_, new_n298_, new_n299_, new_n300_, new_n301_, new_n302_,
    new_n303_, new_n304_, new_n305_, new_n306_, new_n307_, new_n308_,
    new_n309_, new_n310_, new_n311_, new_n312_, new_n313_, new_n314_,
    new_n315_, new_n316_, new_n317_, new_n318_, new_n319_, new_n320_,
    new_n321_, new_n322_, new_n323_, new_n324_, new_n325_, new_n326_,
    new_n327_, new_n328_, new_n330_, new_n331_, new_n332_, new_n333_,
    new_n334_, new_n335_, new_n336_, new_n337_, new_n338_, new_n339_,
    new_n340_, new_n341_, new_n342_, new_n343_, new_n344_, new_n345_,
    new_n346_, new_n347_, new_n348_, new_n349_, new_n350_, new_n351_,
    new_n352_, new_n353_, new_n354_, new_n355_, new_n356_, new_n357_,
    new_n358_, new_n359_, new_n360_, new_n361_, new_n362_, new_n363_,
    new_n364_, new_n365_, new_n366_, new_n367_, new_n368_, new_n369_,
    new_n370_, new_n371_, new_n372_, new_n373_, new_n374_, new_n376_,
    new_n377_, new_n378_, new_n379_, new_n380_, new_n381_, new_n382_,
    new_n383_, new_n384_, new_n385_, new_n386_, new_n387_, new_n388_,
    new_n389_, new_n390_, new_n391_, new_n392_, new_n393_, new_n394_,
    new_n395_, new_n396_, new_n397_, new_n398_, new_n399_, new_n400_,
    new_n401_, new_n402_, new_n403_, new_n404_, new_n405_, new_n407_,
    new_n408_, new_n409_, new_n410_, new_n411_, new_n412_, new_n413_,
    new_n414_, new_n415_, new_n416_, new_n417_, new_n418_, new_n419_,
    new_n420_, new_n421_, new_n422_, new_n424_, new_n425_, new_n426_,
    new_n427_;
  INVx1_ASAP7_75t_R    g000(.A(p9), .Y(new_n22_));
  NOR2x1_ASAP7_75t_R   g001(.A(p0), .B(new_n22_), .Y(new_n23_));
  INVx1_ASAP7_75t_R    g002(.A(p1), .Y(new_n24_));
  NOR2x1_ASAP7_75t_R   g003(.A(p8), .B(new_n24_), .Y(new_n25_));
  NAND2x1_ASAP7_75t_R  g004(.A(new_n23_), .B(new_n25_), .Y(new_n26_));
  INVx1_ASAP7_75t_R    g005(.A(p0), .Y(new_n27_));
  NAND2x1_ASAP7_75t_R  g006(.A(p8), .B(new_n22_), .Y(new_n28_));
  AO21x1_ASAP7_75t_R   g007(.A1(new_n27_), .A2(new_n28_), .B(p7), .Y(new_n29_));
  INVx1_ASAP7_75t_R    g008(.A(p2), .Y(new_n30_));
  AO21x1_ASAP7_75t_R   g009(.A1(new_n26_), .A2(new_n29_), .B(new_n30_), .Y(new_n31_));
  NOR2x1_ASAP7_75t_R   g010(.A(p2), .B(p0), .Y(new_n32_));
  INVx1_ASAP7_75t_R    g011(.A(p7), .Y(new_n33_));
  AO32x1_ASAP7_75t_R   g012(.A1(new_n32_), .A2(p1), .A3(p8), .B1(new_n33_), .B2(p0), .Y(new_n34_));
  NAND2x1_ASAP7_75t_R  g013(.A(new_n22_), .B(new_n34_), .Y(new_n35_));
  AND2x2_ASAP7_75t_R   g014(.A(p1), .B(p8), .Y(new_n36_));
  INVx1_ASAP7_75t_R    g015(.A(p5), .Y(new_n37_));
  NAND2x1_ASAP7_75t_R  g016(.A(p2), .B(new_n37_), .Y(new_n38_));
  NOR2x1_ASAP7_75t_R   g017(.A(p8), .B(p0), .Y(new_n39_));
  NAND2x1_ASAP7_75t_R  g018(.A(p2), .B(p1), .Y(new_n40_));
  AND3x1_ASAP7_75t_R   g019(.A(new_n38_), .B(new_n39_), .C(new_n40_), .Y(new_n41_));
  OAI21x1_ASAP7_75t_R  g020(.A1(new_n36_), .A2(new_n41_), .B(new_n33_), .Y(new_n42_));
  AO31x2_ASAP7_75t_R   g021(.A1(new_n31_), .A2(new_n35_), .A3(new_n42_), .B(p4), .Y(new_n43_));
  INVx1_ASAP7_75t_R    g022(.A(p8), .Y(new_n44_));
  AO21x1_ASAP7_75t_R   g023(.A1(p9), .A2(new_n44_), .B(p1), .Y(new_n45_));
  INVx1_ASAP7_75t_R    g024(.A(p4), .Y(new_n46_));
  AO21x1_ASAP7_75t_R   g025(.A1(new_n37_), .A2(new_n45_), .B(new_n46_), .Y(new_n47_));
  NAND2x1_ASAP7_75t_R  g026(.A(p0), .B(new_n30_), .Y(new_n48_));
  NOR2x1_ASAP7_75t_R   g027(.A(p9), .B(new_n44_), .Y(new_n49_));
  NOR2x1_ASAP7_75t_R   g028(.A(new_n48_), .B(new_n49_), .Y(new_n50_));
  NOR2x1_ASAP7_75t_R   g029(.A(new_n45_), .B(new_n50_), .Y(new_n51_));
  NOR2x1_ASAP7_75t_R   g030(.A(new_n47_), .B(new_n51_), .Y(new_n52_));
  NAND2x1_ASAP7_75t_R  g031(.A(p8), .B(p5), .Y(new_n53_));
  OR3x1_ASAP7_75t_R    g032(.A(p1), .B(p9), .C(p0), .Y(new_n54_));
  NAND2x1_ASAP7_75t_R  g033(.A(p4), .B(p5), .Y(new_n55_));
  OA21x2_ASAP7_75t_R   g034(.A1(new_n53_), .A2(new_n54_), .B(new_n55_), .Y(new_n56_));
  NOR2x1_ASAP7_75t_R   g035(.A(p8), .B(new_n22_), .Y(new_n57_));
  NAND2x1_ASAP7_75t_R  g036(.A(p1), .B(p0), .Y(new_n58_));
  OR4x2_ASAP7_75t_R    g037(.A(new_n49_), .B(new_n57_), .C(new_n46_), .D(new_n58_), .Y(new_n59_));
  AOI21x1_ASAP7_75t_R  g038(.A1(new_n56_), .A2(new_n59_), .B(new_n30_), .Y(new_n60_));
  OAI21x1_ASAP7_75t_R  g039(.A1(new_n52_), .A2(new_n60_), .B(p7), .Y(new_n61_));
  NOR2x1_ASAP7_75t_R   g040(.A(p2), .B(p7), .Y(new_n62_));
  INVx1_ASAP7_75t_R    g041(.A(new_n62_), .Y(new_n63_));
  INVx1_ASAP7_75t_R    g042(.A(new_n39_), .Y(new_n64_));
  OR3x1_ASAP7_75t_R    g043(.A(new_n64_), .B(p1), .C(p9), .Y(new_n65_));
  NAND2x1_ASAP7_75t_R  g044(.A(p1), .B(p8), .Y(new_n66_));
  NOR2x1_ASAP7_75t_R   g045(.A(p1), .B(p8), .Y(new_n67_));
  INVx1_ASAP7_75t_R    g046(.A(new_n67_), .Y(new_n68_));
  NAND2x1_ASAP7_75t_R  g047(.A(new_n30_), .B(new_n22_), .Y(new_n69_));
  NAND2x1_ASAP7_75t_R  g048(.A(p7), .B(p5), .Y(new_n70_));
  OR3x1_ASAP7_75t_R    g049(.A(new_n69_), .B(new_n39_), .C(new_n70_), .Y(new_n71_));
  AO21x1_ASAP7_75t_R   g050(.A1(new_n66_), .A2(new_n68_), .B(new_n71_), .Y(new_n72_));
  OA21x2_ASAP7_75t_R   g051(.A1(new_n63_), .A2(new_n65_), .B(new_n72_), .Y(new_n73_));
  NOR2x1_ASAP7_75t_R   g052(.A(p6), .B(p3), .Y(new_n74_));
  INVx1_ASAP7_75t_R    g053(.A(new_n74_), .Y(new_n75_));
  AO31x2_ASAP7_75t_R   g054(.A1(new_n43_), .A2(new_n61_), .A3(new_n73_), .B(new_n75_), .Y(new_n76_));
  NOR2x1_ASAP7_75t_R   g055(.A(p9), .B(p0), .Y(new_n77_));
  AND2x2_ASAP7_75t_R   g056(.A(p9), .B(p0), .Y(new_n78_));
  OR3x1_ASAP7_75t_R    g057(.A(new_n78_), .B(p2), .C(p4), .Y(new_n79_));
  OA21x2_ASAP7_75t_R   g058(.A1(p6), .A2(new_n77_), .B(new_n79_), .Y(new_n80_));
  NOR2x1_ASAP7_75t_R   g059(.A(p7), .B(p1), .Y(new_n81_));
  INVx1_ASAP7_75t_R    g060(.A(new_n81_), .Y(new_n82_));
  AND2x2_ASAP7_75t_R   g061(.A(p8), .B(p0), .Y(new_n83_));
  NOR2x1_ASAP7_75t_R   g062(.A(new_n39_), .B(new_n83_), .Y(new_n84_));
  OR3x1_ASAP7_75t_R    g063(.A(new_n80_), .B(new_n82_), .C(new_n84_), .Y(new_n85_));
  NOR2x1_ASAP7_75t_R   g064(.A(p6), .B(new_n44_), .Y(new_n86_));
  AND3x1_ASAP7_75t_R   g065(.A(new_n46_), .B(p7), .C(p6), .Y(new_n87_));
  AND3x1_ASAP7_75t_R   g066(.A(new_n24_), .B(p9), .C(p0), .Y(new_n88_));
  OA21x2_ASAP7_75t_R   g067(.A1(new_n86_), .A2(new_n87_), .B(new_n88_), .Y(new_n89_));
  INVx1_ASAP7_75t_R    g068(.A(p6), .Y(new_n90_));
  NAND2x1_ASAP7_75t_R  g069(.A(p0), .B(new_n90_), .Y(new_n91_));
  NOR2x1_ASAP7_75t_R   g070(.A(p4), .B(new_n22_), .Y(new_n92_));
  AND3x1_ASAP7_75t_R   g071(.A(new_n77_), .B(p1), .C(new_n44_), .Y(new_n93_));
  AO32x1_ASAP7_75t_R   g072(.A1(new_n67_), .A2(new_n91_), .A3(new_n92_), .B1(new_n93_), .B2(new_n87_), .Y(new_n94_));
  OAI21x1_ASAP7_75t_R  g073(.A1(new_n89_), .A2(new_n94_), .B(new_n30_), .Y(new_n95_));
  AO21x1_ASAP7_75t_R   g074(.A1(new_n46_), .A2(new_n24_), .B(p9), .Y(new_n96_));
  AO21x1_ASAP7_75t_R   g075(.A1(new_n58_), .A2(new_n96_), .B(p8), .Y(new_n97_));
  NOR2x1_ASAP7_75t_R   g076(.A(p2), .B(p1), .Y(new_n98_));
  OR3x1_ASAP7_75t_R    g077(.A(new_n98_), .B(new_n44_), .C(p0), .Y(new_n99_));
  OR3x1_ASAP7_75t_R    g078(.A(new_n30_), .B(new_n22_), .C(p0), .Y(new_n100_));
  AND3x1_ASAP7_75t_R   g079(.A(new_n99_), .B(new_n48_), .C(new_n100_), .Y(new_n101_));
  NAND2x1_ASAP7_75t_R  g080(.A(new_n33_), .B(new_n90_), .Y(new_n102_));
  AO21x1_ASAP7_75t_R   g081(.A1(new_n97_), .A2(new_n101_), .B(new_n102_), .Y(new_n103_));
  INVx1_ASAP7_75t_R    g082(.A(p3), .Y(new_n104_));
  NAND2x1_ASAP7_75t_R  g083(.A(new_n37_), .B(new_n104_), .Y(new_n105_));
  AO31x2_ASAP7_75t_R   g084(.A1(new_n85_), .A2(new_n95_), .A3(new_n103_), .B(new_n105_), .Y(new_n106_));
  INVx1_ASAP7_75t_R    g085(.A(new_n55_), .Y(new_n107_));
  NOR2x1_ASAP7_75t_R   g086(.A(p7), .B(new_n46_), .Y(new_n108_));
  NOR2x1_ASAP7_75t_R   g087(.A(p8), .B(p5), .Y(new_n109_));
  AO21x1_ASAP7_75t_R   g088(.A1(p7), .A2(p3), .B(new_n109_), .Y(new_n110_));
  OAI21x1_ASAP7_75t_R  g089(.A1(new_n107_), .A2(new_n108_), .B(new_n110_), .Y(new_n111_));
  NAND2x1_ASAP7_75t_R  g090(.A(p8), .B(p3), .Y(new_n112_));
  OA21x2_ASAP7_75t_R   g091(.A1(p8), .A2(new_n37_), .B(new_n112_), .Y(new_n113_));
  OR3x1_ASAP7_75t_R    g092(.A(new_n113_), .B(p7), .C(new_n107_), .Y(new_n114_));
  NOR2x1_ASAP7_75t_R   g093(.A(p6), .B(p9), .Y(new_n115_));
  AND3x1_ASAP7_75t_R   g094(.A(new_n32_), .B(new_n115_), .C(new_n24_), .Y(new_n116_));
  INVx1_ASAP7_75t_R    g095(.A(new_n116_), .Y(new_n117_));
  AO21x1_ASAP7_75t_R   g096(.A1(new_n111_), .A2(new_n114_), .B(new_n117_), .Y(new_n118_));
  NAND3x1_ASAP7_75t_R  g097(.A(new_n76_), .B(new_n106_), .C(new_n118_), .Y(o0));
  NAND2x1_ASAP7_75t_R  g098(.A(p7), .B(new_n46_), .Y(new_n120_));
  NAND2x1_ASAP7_75t_R  g099(.A(new_n53_), .B(new_n120_), .Y(new_n121_));
  NOR2x1_ASAP7_75t_R   g100(.A(p7), .B(p8), .Y(new_n122_));
  AND3x1_ASAP7_75t_R   g101(.A(p7), .B(p8), .C(p5), .Y(new_n123_));
  AO21x1_ASAP7_75t_R   g102(.A1(new_n46_), .A2(new_n122_), .B(new_n123_), .Y(new_n124_));
  AOI21x1_ASAP7_75t_R  g103(.A1(new_n22_), .A2(new_n121_), .B(new_n124_), .Y(new_n125_));
  NAND2x1_ASAP7_75t_R  g104(.A(p1), .B(new_n27_), .Y(new_n126_));
  AND3x1_ASAP7_75t_R   g105(.A(new_n70_), .B(new_n24_), .C(p9), .Y(new_n127_));
  NOR2x1_ASAP7_75t_R   g106(.A(p1), .B(new_n46_), .Y(new_n128_));
  AND3x1_ASAP7_75t_R   g107(.A(new_n33_), .B(new_n22_), .C(p8), .Y(new_n129_));
  AOI22x1_ASAP7_75t_R  g108(.A1(new_n121_), .A2(new_n127_), .B1(new_n128_), .B2(new_n129_), .Y(new_n130_));
  OAI22x1_ASAP7_75t_R  g109(.A1(new_n125_), .A2(new_n126_), .B1(new_n130_), .B2(new_n27_), .Y(new_n131_));
  NAND2x1_ASAP7_75t_R  g110(.A(p7), .B(new_n22_), .Y(new_n132_));
  NAND2x1_ASAP7_75t_R  g111(.A(p5), .B(new_n46_), .Y(new_n133_));
  NOR2x1_ASAP7_75t_R   g112(.A(new_n132_), .B(new_n133_), .Y(new_n134_));
  NOR2x1_ASAP7_75t_R   g113(.A(p4), .B(new_n33_), .Y(new_n135_));
  NOR2x1_ASAP7_75t_R   g114(.A(p7), .B(p5), .Y(new_n136_));
  AO21x1_ASAP7_75t_R   g115(.A1(p1), .A2(new_n135_), .B(new_n136_), .Y(new_n137_));
  NAND2x1_ASAP7_75t_R  g116(.A(p0), .B(new_n44_), .Y(new_n138_));
  INVx1_ASAP7_75t_R    g117(.A(new_n138_), .Y(new_n139_));
  OA21x2_ASAP7_75t_R   g118(.A1(new_n134_), .A2(new_n137_), .B(new_n139_), .Y(new_n140_));
  AND5x1_ASAP7_75t_R   g119(.A(p4), .B(new_n122_), .C(new_n24_), .D(new_n22_), .E(new_n27_), .Y(new_n141_));
  AND3x1_ASAP7_75t_R   g120(.A(new_n109_), .B(p7), .C(p1), .Y(new_n142_));
  AND2x2_ASAP7_75t_R   g121(.A(p7), .B(p8), .Y(new_n143_));
  AND5x1_ASAP7_75t_R   g122(.A(p4), .B(new_n143_), .C(p1), .D(p9), .E(new_n27_), .Y(new_n144_));
  OR4x2_ASAP7_75t_R    g123(.A(new_n140_), .B(new_n141_), .C(new_n142_), .D(new_n144_), .Y(new_n145_));
  AND3x1_ASAP7_75t_R   g124(.A(new_n30_), .B(new_n90_), .C(new_n104_), .Y(new_n146_));
  OAI21x1_ASAP7_75t_R  g125(.A1(new_n131_), .A2(new_n145_), .B(new_n146_), .Y(new_n147_));
  AND2x2_ASAP7_75t_R   g126(.A(p2), .B(p5), .Y(new_n148_));
  NOR2x1_ASAP7_75t_R   g127(.A(p1), .B(new_n30_), .Y(new_n149_));
  AO21x1_ASAP7_75t_R   g128(.A1(new_n27_), .A2(new_n148_), .B(new_n149_), .Y(new_n150_));
  NAND2x1_ASAP7_75t_R  g129(.A(new_n33_), .B(new_n27_), .Y(new_n151_));
  NAND3x1_ASAP7_75t_R  g130(.A(new_n150_), .B(new_n46_), .C(new_n151_), .Y(new_n152_));
  NOR2x1_ASAP7_75t_R   g131(.A(p9), .B(new_n33_), .Y(new_n153_));
  NOR2x1_ASAP7_75t_R   g132(.A(p5), .B(p0), .Y(new_n154_));
  OR5x1_ASAP7_75t_R    g133(.A(p4), .B(new_n153_), .C(p1), .D(new_n78_), .E(new_n154_), .Y(new_n155_));
  AND3x1_ASAP7_75t_R   g134(.A(new_n152_), .B(new_n44_), .C(new_n155_), .Y(new_n156_));
  NAND2x1_ASAP7_75t_R  g135(.A(p7), .B(p9), .Y(new_n157_));
  NOR2x1_ASAP7_75t_R   g136(.A(p1), .B(new_n157_), .Y(new_n158_));
  NAND2x1_ASAP7_75t_R  g137(.A(p9), .B(new_n46_), .Y(new_n159_));
  NAND2x1_ASAP7_75t_R  g138(.A(p4), .B(new_n22_), .Y(new_n160_));
  NAND2x1_ASAP7_75t_R  g139(.A(new_n159_), .B(new_n160_), .Y(new_n161_));
  OA21x2_ASAP7_75t_R   g140(.A1(new_n158_), .A2(new_n161_), .B(p0), .Y(new_n162_));
  INVx1_ASAP7_75t_R    g141(.A(new_n98_), .Y(new_n163_));
  AND3x1_ASAP7_75t_R   g142(.A(new_n82_), .B(new_n163_), .C(new_n22_), .Y(new_n164_));
  AND3x1_ASAP7_75t_R   g143(.A(new_n63_), .B(new_n23_), .C(new_n120_), .Y(new_n165_));
  AND3x1_ASAP7_75t_R   g144(.A(new_n81_), .B(p4), .C(new_n27_), .Y(new_n166_));
  OR3x1_ASAP7_75t_R    g145(.A(new_n164_), .B(new_n165_), .C(new_n166_), .Y(new_n167_));
  OAI21x1_ASAP7_75t_R  g146(.A1(new_n162_), .A2(new_n167_), .B(new_n37_), .Y(new_n168_));
  NOR2x1_ASAP7_75t_R   g147(.A(p0), .B(new_n30_), .Y(new_n169_));
  AOI22x1_ASAP7_75t_R  g148(.A1(new_n169_), .A2(new_n81_), .B1(p4), .B2(p0), .Y(new_n170_));
  OR3x1_ASAP7_75t_R    g149(.A(new_n170_), .B(new_n22_), .C(new_n37_), .Y(new_n171_));
  NAND2x1_ASAP7_75t_R  g150(.A(p8), .B(new_n37_), .Y(new_n172_));
  OAI21x1_ASAP7_75t_R  g151(.A1(new_n30_), .A2(new_n58_), .B(p8), .Y(new_n173_));
  AO21x1_ASAP7_75t_R   g152(.A1(new_n107_), .A2(new_n163_), .B(new_n173_), .Y(new_n174_));
  OAI21x1_ASAP7_75t_R  g153(.A1(new_n108_), .A2(new_n172_), .B(new_n174_), .Y(new_n175_));
  AO21x1_ASAP7_75t_R   g154(.A1(new_n171_), .A2(new_n175_), .B(new_n75_), .Y(new_n176_));
  AO21x1_ASAP7_75t_R   g155(.A1(new_n156_), .A2(new_n168_), .B(new_n176_), .Y(new_n177_));
  AND3x1_ASAP7_75t_R   g156(.A(new_n44_), .B(p7), .C(p0), .Y(new_n178_));
  NOR2x1_ASAP7_75t_R   g157(.A(p1), .B(new_n90_), .Y(new_n179_));
  NOR2x1_ASAP7_75t_R   g158(.A(p7), .B(new_n90_), .Y(new_n180_));
  OA21x2_ASAP7_75t_R   g159(.A1(new_n78_), .A2(new_n45_), .B(new_n180_), .Y(new_n181_));
  AO21x1_ASAP7_75t_R   g160(.A1(new_n22_), .A2(new_n27_), .B(new_n24_), .Y(new_n182_));
  AO221x2_ASAP7_75t_R  g161(.A1(new_n178_), .A2(new_n179_), .B1(new_n181_), .B2(new_n182_), .C(new_n93_), .Y(new_n183_));
  NOR3x1_ASAP7_75t_R   g162(.A(new_n105_), .B(p2), .C(p4), .Y(new_n184_));
  AO21x1_ASAP7_75t_R   g163(.A1(p7), .A2(p3), .B(new_n108_), .Y(new_n185_));
  AND3x1_ASAP7_75t_R   g164(.A(p8), .B(p5), .C(p3), .Y(new_n186_));
  AO21x1_ASAP7_75t_R   g165(.A1(new_n109_), .A2(new_n185_), .B(new_n186_), .Y(new_n187_));
  AOI22x1_ASAP7_75t_R  g166(.A1(new_n183_), .A2(new_n184_), .B1(new_n116_), .B2(new_n187_), .Y(new_n188_));
  NAND3x1_ASAP7_75t_R  g167(.A(new_n147_), .B(new_n177_), .C(new_n188_), .Y(o1));
  OA21x2_ASAP7_75t_R   g168(.A1(p4), .A2(new_n36_), .B(p0), .Y(new_n190_));
  AND3x1_ASAP7_75t_R   g169(.A(p7), .B(p8), .C(p9), .Y(new_n191_));
  OR3x1_ASAP7_75t_R    g170(.A(new_n191_), .B(new_n46_), .C(new_n122_), .Y(new_n192_));
  XOR2x2_ASAP7_75t_R   g171(.A(p7), .B(p8), .Y(new_n193_));
  OA21x2_ASAP7_75t_R   g172(.A1(new_n39_), .A2(new_n193_), .B(p1), .Y(new_n194_));
  AO21x1_ASAP7_75t_R   g173(.A1(new_n190_), .A2(new_n192_), .B(new_n194_), .Y(new_n195_));
  OR3x1_ASAP7_75t_R    g174(.A(p7), .B(p1), .C(p8), .Y(new_n196_));
  AO21x1_ASAP7_75t_R   g175(.A1(new_n159_), .A2(new_n100_), .B(new_n196_), .Y(new_n197_));
  OAI21x1_ASAP7_75t_R  g176(.A1(new_n99_), .A2(new_n157_), .B(new_n197_), .Y(new_n198_));
  AO21x1_ASAP7_75t_R   g177(.A1(new_n30_), .A2(new_n195_), .B(new_n198_), .Y(new_n199_));
  AND3x1_ASAP7_75t_R   g178(.A(new_n90_), .B(new_n37_), .C(new_n104_), .Y(new_n200_));
  AO21x1_ASAP7_75t_R   g179(.A1(p6), .A2(new_n143_), .B(new_n22_), .Y(new_n201_));
  AO32x1_ASAP7_75t_R   g180(.A1(new_n201_), .A2(p0), .A3(new_n28_), .B1(new_n23_), .B2(new_n122_), .Y(new_n202_));
  NOR2x1_ASAP7_75t_R   g181(.A(p4), .B(p5), .Y(new_n203_));
  AND3x1_ASAP7_75t_R   g182(.A(new_n98_), .B(new_n203_), .C(new_n104_), .Y(new_n204_));
  AOI22x1_ASAP7_75t_R  g183(.A1(new_n199_), .A2(new_n200_), .B1(new_n202_), .B2(new_n204_), .Y(new_n205_));
  NAND2x1_ASAP7_75t_R  g184(.A(p1), .B(p5), .Y(new_n206_));
  OA211x2_ASAP7_75t_R  g185(.A1(p7), .A2(new_n24_), .B(new_n206_), .C(p0), .Y(new_n207_));
  OR3x1_ASAP7_75t_R    g186(.A(new_n81_), .B(new_n98_), .C(new_n46_), .Y(new_n208_));
  OA21x2_ASAP7_75t_R   g187(.A1(new_n33_), .A2(new_n149_), .B(new_n46_), .Y(new_n209_));
  AND2x2_ASAP7_75t_R   g188(.A(p2), .B(p4), .Y(new_n210_));
  OA21x2_ASAP7_75t_R   g189(.A1(new_n33_), .A2(p1), .B(new_n210_), .Y(new_n211_));
  OR3x1_ASAP7_75t_R    g190(.A(new_n209_), .B(new_n138_), .C(new_n211_), .Y(new_n212_));
  OAI21x1_ASAP7_75t_R  g191(.A1(new_n207_), .A2(new_n208_), .B(new_n212_), .Y(new_n213_));
  NAND2x1_ASAP7_75t_R  g192(.A(p2), .B(new_n33_), .Y(new_n214_));
  AO221x2_ASAP7_75t_R  g193(.A1(p2), .A2(new_n44_), .B1(new_n138_), .B2(new_n214_), .C(p5), .Y(new_n215_));
  AND3x1_ASAP7_75t_R   g194(.A(new_n122_), .B(new_n46_), .C(p5), .Y(new_n216_));
  AOI21x1_ASAP7_75t_R  g195(.A1(new_n32_), .A2(new_n216_), .B(p3), .Y(new_n217_));
  NAND2x1_ASAP7_75t_R  g196(.A(p5), .B(new_n33_), .Y(new_n218_));
  OR3x1_ASAP7_75t_R    g197(.A(new_n48_), .B(new_n218_), .C(new_n44_), .Y(new_n219_));
  AND3x1_ASAP7_75t_R   g198(.A(new_n215_), .B(new_n217_), .C(new_n219_), .Y(new_n220_));
  OA21x2_ASAP7_75t_R   g199(.A1(new_n44_), .A2(new_n151_), .B(p1), .Y(new_n221_));
  OR4x2_ASAP7_75t_R    g200(.A(new_n221_), .B(new_n30_), .C(new_n109_), .D(new_n178_), .Y(new_n222_));
  NAND2x1_ASAP7_75t_R  g201(.A(new_n220_), .B(new_n222_), .Y(new_n223_));
  AND3x1_ASAP7_75t_R   g202(.A(new_n30_), .B(new_n24_), .C(new_n27_), .Y(new_n224_));
  NAND2x1_ASAP7_75t_R  g203(.A(p7), .B(p8), .Y(new_n225_));
  AO21x1_ASAP7_75t_R   g204(.A1(new_n225_), .A2(new_n218_), .B(p4), .Y(new_n226_));
  OA21x2_ASAP7_75t_R   g205(.A1(new_n104_), .A2(new_n226_), .B(new_n115_), .Y(new_n227_));
  OA21x2_ASAP7_75t_R   g206(.A1(new_n104_), .A2(new_n224_), .B(new_n227_), .Y(new_n228_));
  OAI21x1_ASAP7_75t_R  g207(.A1(new_n213_), .A2(new_n223_), .B(new_n228_), .Y(new_n229_));
  OR3x1_ASAP7_75t_R    g208(.A(new_n33_), .B(new_n37_), .C(p0), .Y(new_n230_));
  OA21x2_ASAP7_75t_R   g209(.A1(p7), .A2(p8), .B(p1), .Y(new_n231_));
  AO21x1_ASAP7_75t_R   g210(.A1(new_n225_), .A2(new_n231_), .B(new_n81_), .Y(new_n232_));
  OA21x2_ASAP7_75t_R   g211(.A1(new_n58_), .A2(new_n53_), .B(new_n232_), .Y(new_n233_));
  AO21x1_ASAP7_75t_R   g212(.A1(new_n230_), .A2(new_n233_), .B(new_n30_), .Y(new_n234_));
  AO21x1_ASAP7_75t_R   g213(.A1(new_n37_), .A2(new_n138_), .B(new_n33_), .Y(new_n235_));
  OA21x2_ASAP7_75t_R   g214(.A1(new_n63_), .A2(new_n139_), .B(new_n235_), .Y(new_n236_));
  NOR2x1_ASAP7_75t_R   g215(.A(p0), .B(new_n44_), .Y(new_n237_));
  OR3x1_ASAP7_75t_R    g216(.A(new_n236_), .B(p1), .C(new_n237_), .Y(new_n238_));
  NAND2x1_ASAP7_75t_R  g217(.A(new_n74_), .B(new_n92_), .Y(new_n239_));
  AO21x1_ASAP7_75t_R   g218(.A1(new_n234_), .A2(new_n238_), .B(new_n239_), .Y(new_n240_));
  NAND3x1_ASAP7_75t_R  g219(.A(new_n205_), .B(new_n229_), .C(new_n240_), .Y(o2));
  NAND2x1_ASAP7_75t_R  g220(.A(p7), .B(p1), .Y(new_n242_));
  NAND2x1_ASAP7_75t_R  g221(.A(p7), .B(p4), .Y(new_n243_));
  NAND2x1_ASAP7_75t_R  g222(.A(p1), .B(new_n30_), .Y(new_n244_));
  NAND2x1_ASAP7_75t_R  g223(.A(new_n243_), .B(new_n244_), .Y(new_n245_));
  AO22x1_ASAP7_75t_R   g224(.A1(p1), .A2(new_n135_), .B1(new_n242_), .B2(new_n245_), .Y(new_n246_));
  NAND2x1_ASAP7_75t_R  g225(.A(p2), .B(new_n46_), .Y(new_n247_));
  AO21x1_ASAP7_75t_R   g226(.A1(p2), .A2(new_n33_), .B(p5), .Y(new_n248_));
  AO21x1_ASAP7_75t_R   g227(.A1(new_n247_), .A2(new_n248_), .B(new_n149_), .Y(new_n249_));
  AO21x1_ASAP7_75t_R   g228(.A1(new_n44_), .A2(new_n246_), .B(new_n249_), .Y(new_n250_));
  AO21x1_ASAP7_75t_R   g229(.A1(new_n30_), .A2(new_n46_), .B(new_n37_), .Y(new_n251_));
  OA211x2_ASAP7_75t_R  g230(.A1(p5), .A2(new_n166_), .B(new_n251_), .C(new_n57_), .Y(new_n252_));
  NAND2x1_ASAP7_75t_R  g231(.A(p8), .B(p0), .Y(new_n253_));
  AO21x1_ASAP7_75t_R   g232(.A1(p4), .A2(p8), .B(p5), .Y(new_n254_));
  AOI211x1_ASAP7_75t_R g233(.A1(new_n253_), .A2(new_n243_), .B(new_n30_), .C(new_n254_), .Y(new_n255_));
  AND2x2_ASAP7_75t_R   g234(.A(p7), .B(p0), .Y(new_n256_));
  NOR2x1_ASAP7_75t_R   g235(.A(p4), .B(p8), .Y(new_n257_));
  AND3x1_ASAP7_75t_R   g236(.A(new_n256_), .B(p5), .C(new_n257_), .Y(new_n258_));
  AND5x1_ASAP7_75t_R   g237(.A(p4), .B(new_n81_), .C(p8), .D(p9), .E(p0), .Y(new_n259_));
  OA21x2_ASAP7_75t_R   g238(.A1(new_n257_), .A2(new_n136_), .B(new_n149_), .Y(new_n260_));
  OR5x1_ASAP7_75t_R    g239(.A(new_n252_), .B(new_n255_), .C(new_n258_), .D(new_n259_), .E(new_n260_), .Y(new_n261_));
  NOR2x1_ASAP7_75t_R   g240(.A(p5), .B(new_n30_), .Y(new_n262_));
  AO21x1_ASAP7_75t_R   g241(.A1(new_n33_), .A2(new_n262_), .B(new_n216_), .Y(new_n263_));
  NOR2x1_ASAP7_75t_R   g242(.A(p5), .B(new_n40_), .Y(new_n264_));
  AO21x1_ASAP7_75t_R   g243(.A1(new_n46_), .A2(p5), .B(new_n264_), .Y(new_n265_));
  AND3x1_ASAP7_75t_R   g244(.A(new_n265_), .B(p8), .C(new_n163_), .Y(new_n266_));
  OA21x2_ASAP7_75t_R   g245(.A1(new_n263_), .A2(new_n266_), .B(new_n27_), .Y(new_n267_));
  AOI211x1_ASAP7_75t_R g246(.A1(new_n78_), .A2(new_n250_), .B(new_n261_), .C(new_n267_), .Y(new_n268_));
  INVx1_ASAP7_75t_R    g247(.A(new_n206_), .Y(new_n269_));
  NAND2x1_ASAP7_75t_R  g248(.A(p4), .B(p0), .Y(new_n270_));
  AOI22x1_ASAP7_75t_R  g249(.A1(new_n269_), .A2(new_n270_), .B1(new_n169_), .B2(new_n172_), .Y(new_n271_));
  NOR2x1_ASAP7_75t_R   g250(.A(new_n203_), .B(new_n107_), .Y(new_n272_));
  AND2x2_ASAP7_75t_R   g251(.A(new_n46_), .B(new_n225_), .Y(new_n273_));
  OR5x1_ASAP7_75t_R    g252(.A(new_n104_), .B(new_n272_), .C(new_n273_), .D(p0), .E(new_n163_), .Y(new_n274_));
  OAI21x1_ASAP7_75t_R  g253(.A1(p3), .A2(new_n271_), .B(new_n274_), .Y(new_n275_));
  AND5x1_ASAP7_75t_R   g254(.A(p7), .B(new_n37_), .C(p4), .D(p1), .E(p8), .Y(new_n276_));
  AO21x1_ASAP7_75t_R   g255(.A1(p7), .A2(new_n37_), .B(new_n46_), .Y(new_n277_));
  AO21x1_ASAP7_75t_R   g256(.A1(p5), .A2(new_n33_), .B(p2), .Y(new_n278_));
  AO32x1_ASAP7_75t_R   g257(.A1(new_n46_), .A2(p1), .A3(new_n122_), .B1(new_n277_), .B2(new_n278_), .Y(new_n279_));
  OA211x2_ASAP7_75t_R  g258(.A1(new_n276_), .A2(new_n279_), .B(new_n104_), .C(p0), .Y(new_n280_));
  OAI21x1_ASAP7_75t_R  g259(.A1(new_n275_), .A2(new_n280_), .B(new_n115_), .Y(new_n281_));
  OAI21x1_ASAP7_75t_R  g260(.A1(new_n75_), .A2(new_n268_), .B(new_n281_), .Y(o3));
  NOR2x1_ASAP7_75t_R   g261(.A(p6), .B(new_n55_), .Y(new_n283_));
  OA21x2_ASAP7_75t_R   g262(.A1(p3), .A2(new_n163_), .B(new_n283_), .Y(new_n284_));
  NAND2x1_ASAP7_75t_R  g263(.A(new_n54_), .B(new_n182_), .Y(new_n285_));
  OA211x2_ASAP7_75t_R  g264(.A1(new_n104_), .A2(new_n98_), .B(new_n284_), .C(new_n285_), .Y(o4));
  AND3x1_ASAP7_75t_R   g265(.A(new_n77_), .B(new_n98_), .C(p3), .Y(new_n287_));
  AND3x1_ASAP7_75t_R   g266(.A(new_n54_), .B(p2), .C(new_n104_), .Y(new_n288_));
  OA21x2_ASAP7_75t_R   g267(.A1(new_n287_), .A2(new_n288_), .B(new_n283_), .Y(o5));
  OA211x2_ASAP7_75t_R  g268(.A1(new_n78_), .A2(new_n256_), .B(new_n159_), .C(new_n44_), .Y(new_n290_));
  OA211x2_ASAP7_75t_R  g269(.A1(new_n24_), .A2(p9), .B(new_n83_), .C(new_n33_), .Y(new_n291_));
  AND3x1_ASAP7_75t_R   g270(.A(new_n123_), .B(new_n24_), .C(p9), .Y(new_n292_));
  OR3x1_ASAP7_75t_R    g271(.A(new_n290_), .B(new_n291_), .C(new_n292_), .Y(new_n293_));
  INVx1_ASAP7_75t_R    g272(.A(new_n247_), .Y(new_n294_));
  NOR2x1_ASAP7_75t_R   g273(.A(p9), .B(p5), .Y(new_n295_));
  AO21x1_ASAP7_75t_R   g274(.A1(p1), .A2(p0), .B(new_n295_), .Y(new_n296_));
  OA21x2_ASAP7_75t_R   g275(.A1(p0), .A2(new_n122_), .B(p9), .Y(new_n297_));
  AO32x1_ASAP7_75t_R   g276(.A1(new_n296_), .A2(new_n84_), .A3(new_n151_), .B1(new_n297_), .B2(new_n138_), .Y(new_n298_));
  AOI22x1_ASAP7_75t_R  g277(.A1(new_n293_), .A2(p2), .B1(new_n294_), .B2(new_n298_), .Y(new_n299_));
  OAI21x1_ASAP7_75t_R  g278(.A1(new_n191_), .A2(new_n231_), .B(p5), .Y(new_n300_));
  NOR2x1_ASAP7_75t_R   g279(.A(new_n49_), .B(new_n57_), .Y(new_n301_));
  AO21x1_ASAP7_75t_R   g280(.A1(p1), .A2(new_n46_), .B(p5), .Y(new_n302_));
  AOI22x1_ASAP7_75t_R  g281(.A1(new_n301_), .A2(new_n128_), .B1(new_n49_), .B2(new_n302_), .Y(new_n303_));
  NAND2x1_ASAP7_75t_R  g282(.A(new_n300_), .B(new_n303_), .Y(new_n304_));
  AOI21x1_ASAP7_75t_R  g283(.A1(p7), .A2(new_n300_), .B(new_n27_), .Y(new_n305_));
  AO21x1_ASAP7_75t_R   g284(.A1(p5), .A2(new_n33_), .B(p9), .Y(new_n306_));
  AO32x1_ASAP7_75t_R   g285(.A1(new_n306_), .A2(new_n67_), .A3(new_n243_), .B1(new_n36_), .B2(new_n153_), .Y(new_n307_));
  AOI22x1_ASAP7_75t_R  g286(.A1(new_n304_), .A2(new_n305_), .B1(new_n27_), .B2(new_n307_), .Y(new_n308_));
  INVx1_ASAP7_75t_R    g287(.A(new_n257_), .Y(new_n309_));
  AND3x1_ASAP7_75t_R   g288(.A(new_n309_), .B(new_n153_), .C(p1), .Y(new_n310_));
  AO32x1_ASAP7_75t_R   g289(.A1(p4), .A2(new_n22_), .A3(new_n36_), .B1(new_n108_), .B2(new_n39_), .Y(new_n311_));
  NOR2x1_ASAP7_75t_R   g290(.A(new_n310_), .B(new_n311_), .Y(new_n312_));
  AND3x1_ASAP7_75t_R   g291(.A(p4), .B(p8), .C(p0), .Y(new_n313_));
  NAND2x1_ASAP7_75t_R  g292(.A(p4), .B(p1), .Y(new_n314_));
  AND3x1_ASAP7_75t_R   g293(.A(new_n58_), .B(new_n109_), .C(new_n314_), .Y(new_n315_));
  AND2x2_ASAP7_75t_R   g294(.A(p7), .B(p9), .Y(new_n316_));
  OAI21x1_ASAP7_75t_R  g295(.A1(new_n313_), .A2(new_n315_), .B(new_n316_), .Y(new_n317_));
  INVx1_ASAP7_75t_R    g296(.A(new_n122_), .Y(new_n318_));
  NAND2x1_ASAP7_75t_R  g297(.A(new_n225_), .B(new_n318_), .Y(new_n319_));
  NAND2x1_ASAP7_75t_R  g298(.A(new_n242_), .B(new_n82_), .Y(new_n320_));
  NAND3x1_ASAP7_75t_R  g299(.A(new_n319_), .B(new_n320_), .C(p5), .Y(new_n321_));
  AO31x2_ASAP7_75t_R   g300(.A1(new_n312_), .A2(new_n317_), .A3(new_n321_), .B(p2), .Y(new_n322_));
  NAND3x1_ASAP7_75t_R  g301(.A(new_n299_), .B(new_n308_), .C(new_n322_), .Y(new_n323_));
  AO21x1_ASAP7_75t_R   g302(.A1(p9), .A2(p0), .B(new_n122_), .Y(new_n324_));
  AO21x1_ASAP7_75t_R   g303(.A1(p7), .A2(new_n90_), .B(new_n143_), .Y(new_n325_));
  OAI22x1_ASAP7_75t_R  g304(.A1(new_n325_), .A2(new_n126_), .B1(new_n27_), .B2(new_n68_), .Y(new_n326_));
  AO32x1_ASAP7_75t_R   g305(.A1(new_n179_), .A2(new_n319_), .A3(new_n324_), .B1(new_n326_), .B2(new_n22_), .Y(new_n327_));
  AO221x2_ASAP7_75t_R  g306(.A1(new_n90_), .A2(new_n287_), .B1(new_n327_), .B2(new_n184_), .C(new_n283_), .Y(new_n328_));
  AOI21x1_ASAP7_75t_R  g307(.A1(new_n74_), .A2(new_n323_), .B(new_n328_), .Y(o6));
  NOR2x1_ASAP7_75t_R   g308(.A(p9), .B(new_n24_), .Y(new_n330_));
  AO32x1_ASAP7_75t_R   g309(.A1(new_n158_), .A2(new_n44_), .A3(p6), .B1(new_n193_), .B2(new_n330_), .Y(new_n331_));
  AND3x1_ASAP7_75t_R   g310(.A(new_n331_), .B(new_n32_), .C(new_n203_), .Y(new_n332_));
  OA21x2_ASAP7_75t_R   g311(.A1(new_n90_), .A2(new_n332_), .B(new_n104_), .Y(new_n333_));
  OAI21x1_ASAP7_75t_R  g312(.A1(new_n38_), .A2(new_n132_), .B(new_n218_), .Y(new_n334_));
  NOR2x1_ASAP7_75t_R   g313(.A(new_n49_), .B(new_n262_), .Y(new_n335_));
  NOR3x1_ASAP7_75t_R   g314(.A(new_n122_), .B(new_n136_), .C(new_n295_), .Y(new_n336_));
  AOI22x1_ASAP7_75t_R  g315(.A1(new_n334_), .A2(p8), .B1(new_n335_), .B2(new_n336_), .Y(new_n337_));
  NAND3x1_ASAP7_75t_R  g316(.A(new_n30_), .B(p7), .C(p8), .Y(new_n338_));
  AOI21x1_ASAP7_75t_R  g317(.A1(p5), .A2(new_n338_), .B(new_n24_), .Y(new_n339_));
  NAND2x1_ASAP7_75t_R  g318(.A(p2), .B(new_n225_), .Y(new_n340_));
  NAND3x1_ASAP7_75t_R  g319(.A(new_n340_), .B(new_n338_), .C(new_n157_), .Y(new_n341_));
  AND3x1_ASAP7_75t_R   g320(.A(new_n109_), .B(new_n30_), .C(new_n33_), .Y(new_n342_));
  AOI21x1_ASAP7_75t_R  g321(.A1(new_n339_), .A2(new_n341_), .B(new_n342_), .Y(new_n343_));
  OAI21x1_ASAP7_75t_R  g322(.A1(p1), .A2(new_n337_), .B(new_n343_), .Y(new_n344_));
  AO21x1_ASAP7_75t_R   g323(.A1(p7), .A2(p8), .B(p5), .Y(new_n345_));
  NAND2x1_ASAP7_75t_R  g324(.A(p5), .B(new_n22_), .Y(new_n346_));
  OAI22x1_ASAP7_75t_R  g325(.A1(new_n45_), .A2(new_n345_), .B1(new_n193_), .B2(new_n346_), .Y(new_n347_));
  OA211x2_ASAP7_75t_R  g326(.A1(new_n77_), .A2(new_n148_), .B(new_n24_), .C(new_n122_), .Y(new_n348_));
  OR3x1_ASAP7_75t_R    g327(.A(new_n157_), .B(p8), .C(new_n37_), .Y(new_n349_));
  OAI21x1_ASAP7_75t_R  g328(.A1(p5), .A2(new_n62_), .B(new_n231_), .Y(new_n350_));
  AOI21x1_ASAP7_75t_R  g329(.A1(new_n349_), .A2(new_n350_), .B(p0), .Y(new_n351_));
  AO211x2_ASAP7_75t_R  g330(.A1(new_n347_), .A2(new_n169_), .B(new_n348_), .C(new_n351_), .Y(new_n352_));
  AOI21x1_ASAP7_75t_R  g331(.A1(p0), .A2(new_n344_), .B(new_n352_), .Y(new_n353_));
  OR3x1_ASAP7_75t_R    g332(.A(new_n36_), .B(new_n67_), .C(new_n157_), .Y(new_n354_));
  OR4x2_ASAP7_75t_R    g333(.A(new_n33_), .B(new_n46_), .C(p8), .D(p9), .Y(new_n355_));
  OR3x1_ASAP7_75t_R    g334(.A(new_n66_), .B(p7), .C(new_n46_), .Y(new_n356_));
  AO31x2_ASAP7_75t_R   g335(.A1(new_n354_), .A2(new_n355_), .A3(new_n356_), .B(new_n48_), .Y(new_n357_));
  OA21x2_ASAP7_75t_R   g336(.A1(new_n210_), .A2(new_n25_), .B(p0), .Y(new_n358_));
  AOI21x1_ASAP7_75t_R  g337(.A1(p2), .A2(new_n24_), .B(new_n22_), .Y(new_n359_));
  AO21x1_ASAP7_75t_R   g338(.A1(p9), .A2(new_n46_), .B(p7), .Y(new_n360_));
  OAI21x1_ASAP7_75t_R  g339(.A1(new_n359_), .A2(new_n360_), .B(new_n68_), .Y(new_n361_));
  NAND2x1_ASAP7_75t_R  g340(.A(new_n358_), .B(new_n361_), .Y(new_n362_));
  AND3x1_ASAP7_75t_R   g341(.A(new_n27_), .B(p2), .C(p9), .Y(new_n363_));
  AND3x1_ASAP7_75t_R   g342(.A(new_n33_), .B(new_n44_), .C(p1), .Y(new_n364_));
  AOI21x1_ASAP7_75t_R  g343(.A1(p2), .A2(p9), .B(p1), .Y(new_n365_));
  NOR3x1_ASAP7_75t_R   g344(.A(new_n365_), .B(new_n46_), .C(p0), .Y(new_n366_));
  AOI22x1_ASAP7_75t_R  g345(.A1(p2), .A2(p1), .B1(p7), .B2(p8), .Y(new_n367_));
  OAI21x1_ASAP7_75t_R  g346(.A1(p7), .A2(p8), .B(new_n367_), .Y(new_n368_));
  AND3x1_ASAP7_75t_R   g347(.A(new_n36_), .B(new_n210_), .C(p7), .Y(new_n369_));
  AOI221x1_ASAP7_75t_R g348(.A1(new_n363_), .A2(new_n364_), .B1(new_n366_), .B2(new_n368_), .C(new_n369_), .Y(new_n370_));
  NAND3x1_ASAP7_75t_R  g349(.A(new_n357_), .B(new_n362_), .C(new_n370_), .Y(new_n371_));
  AOI21x1_ASAP7_75t_R  g350(.A1(new_n37_), .A2(new_n371_), .B(new_n332_), .Y(new_n372_));
  OAI21x1_ASAP7_75t_R  g351(.A1(p4), .A2(new_n353_), .B(new_n372_), .Y(new_n373_));
  AND3x1_ASAP7_75t_R   g352(.A(new_n287_), .B(new_n90_), .C(new_n203_), .Y(new_n374_));
  AOI21x1_ASAP7_75t_R  g353(.A1(new_n333_), .A2(new_n373_), .B(new_n374_), .Y(o7));
  NOR2x1_ASAP7_75t_R   g354(.A(p8), .B(p9), .Y(new_n376_));
  AND3x1_ASAP7_75t_R   g355(.A(new_n330_), .B(new_n33_), .C(p8), .Y(new_n377_));
  AO221x2_ASAP7_75t_R  g356(.A1(new_n44_), .A2(new_n158_), .B1(new_n376_), .B2(new_n320_), .C(new_n377_), .Y(new_n378_));
  AO32x1_ASAP7_75t_R   g357(.A1(new_n22_), .A2(new_n81_), .A3(new_n83_), .B1(new_n378_), .B2(new_n27_), .Y(new_n379_));
  AND3x1_ASAP7_75t_R   g358(.A(new_n160_), .B(p7), .C(new_n24_), .Y(new_n380_));
  AND3x1_ASAP7_75t_R   g359(.A(new_n214_), .B(new_n40_), .C(new_n83_), .Y(new_n381_));
  AO21x1_ASAP7_75t_R   g360(.A1(new_n46_), .A2(p1), .B(new_n210_), .Y(new_n382_));
  AO32x1_ASAP7_75t_R   g361(.A1(new_n380_), .A2(p2), .A3(new_n237_), .B1(new_n381_), .B2(new_n382_), .Y(new_n383_));
  OAI21x1_ASAP7_75t_R  g362(.A1(new_n237_), .A2(new_n153_), .B(new_n138_), .Y(new_n384_));
  AO21x1_ASAP7_75t_R   g363(.A1(p5), .A2(new_n384_), .B(p1), .Y(new_n385_));
  AO21x1_ASAP7_75t_R   g364(.A1(p0), .A2(new_n33_), .B(p5), .Y(new_n386_));
  OA21x2_ASAP7_75t_R   g365(.A1(new_n386_), .A2(new_n297_), .B(new_n294_), .Y(new_n387_));
  AOI22x1_ASAP7_75t_R  g366(.A1(new_n383_), .A2(new_n37_), .B1(new_n385_), .B2(new_n387_), .Y(new_n388_));
  NAND2x1_ASAP7_75t_R  g367(.A(new_n270_), .B(new_n247_), .Y(new_n389_));
  AO21x1_ASAP7_75t_R   g368(.A1(p8), .A2(new_n30_), .B(p1), .Y(new_n390_));
  OR3x1_ASAP7_75t_R    g369(.A(new_n389_), .B(new_n39_), .C(new_n390_), .Y(new_n391_));
  OR3x1_ASAP7_75t_R    g370(.A(new_n44_), .B(new_n27_), .C(p2), .Y(new_n392_));
  NAND2x1_ASAP7_75t_R  g371(.A(new_n39_), .B(new_n128_), .Y(new_n393_));
  AO21x1_ASAP7_75t_R   g372(.A1(new_n392_), .A2(new_n393_), .B(p9), .Y(new_n394_));
  AO21x1_ASAP7_75t_R   g373(.A1(p4), .A2(p8), .B(p0), .Y(new_n395_));
  AO21x1_ASAP7_75t_R   g374(.A1(new_n253_), .A2(new_n395_), .B(new_n244_), .Y(new_n396_));
  INVx1_ASAP7_75t_R    g375(.A(new_n136_), .Y(new_n397_));
  AO31x2_ASAP7_75t_R   g376(.A1(new_n391_), .A2(new_n394_), .A3(new_n396_), .B(new_n397_), .Y(new_n398_));
  AND5x1_ASAP7_75t_R   g377(.A(p7), .B(new_n69_), .C(new_n247_), .D(new_n24_), .E(new_n270_), .Y(new_n399_));
  AOI211x1_ASAP7_75t_R g378(.A1(new_n46_), .A2(new_n132_), .B(new_n58_), .C(new_n210_), .Y(new_n400_));
  AND3x1_ASAP7_75t_R   g379(.A(new_n92_), .B(p7), .C(new_n32_), .Y(new_n401_));
  OR3x1_ASAP7_75t_R    g380(.A(new_n399_), .B(new_n400_), .C(new_n401_), .Y(new_n402_));
  NAND2x1_ASAP7_75t_R  g381(.A(new_n109_), .B(new_n402_), .Y(new_n403_));
  NAND3x1_ASAP7_75t_R  g382(.A(new_n388_), .B(new_n398_), .C(new_n403_), .Y(new_n404_));
  AND3x1_ASAP7_75t_R   g383(.A(new_n287_), .B(new_n46_), .C(new_n90_), .Y(new_n405_));
  AOI221x1_ASAP7_75t_R g384(.A1(new_n184_), .A2(new_n379_), .B1(new_n404_), .B2(new_n74_), .C(new_n405_), .Y(o8));
  AO21x1_ASAP7_75t_R   g385(.A1(new_n33_), .A2(new_n44_), .B(p0), .Y(new_n407_));
  AO21x1_ASAP7_75t_R   g386(.A1(new_n92_), .A2(new_n264_), .B(p6), .Y(new_n408_));
  OA21x2_ASAP7_75t_R   g387(.A1(p9), .A2(new_n244_), .B(p6), .Y(new_n409_));
  AO21x1_ASAP7_75t_R   g388(.A1(p9), .A2(new_n224_), .B(new_n409_), .Y(new_n410_));
  NOR2x1_ASAP7_75t_R   g389(.A(new_n104_), .B(new_n224_), .Y(new_n411_));
  AO21x1_ASAP7_75t_R   g390(.A1(new_n247_), .A2(new_n269_), .B(new_n107_), .Y(new_n412_));
  OR3x1_ASAP7_75t_R    g391(.A(new_n410_), .B(new_n411_), .C(new_n412_), .Y(new_n413_));
  NAND2x1_ASAP7_75t_R  g392(.A(p2), .B(new_n53_), .Y(new_n414_));
  AO21x1_ASAP7_75t_R   g393(.A1(new_n153_), .A2(new_n254_), .B(new_n414_), .Y(new_n415_));
  OR3x1_ASAP7_75t_R    g394(.A(new_n203_), .B(p2), .C(new_n104_), .Y(new_n416_));
  NOR2x1_ASAP7_75t_R   g395(.A(p2), .B(new_n273_), .Y(new_n417_));
  AO32x1_ASAP7_75t_R   g396(.A1(new_n415_), .A2(new_n24_), .A3(new_n416_), .B1(new_n231_), .B2(new_n417_), .Y(new_n418_));
  AO32x1_ASAP7_75t_R   g397(.A1(new_n414_), .A2(new_n24_), .A3(new_n153_), .B1(new_n309_), .B2(new_n98_), .Y(new_n419_));
  AO32x1_ASAP7_75t_R   g398(.A1(new_n30_), .A2(new_n397_), .A3(new_n254_), .B1(new_n273_), .B2(new_n264_), .Y(new_n420_));
  OA21x2_ASAP7_75t_R   g399(.A1(new_n419_), .A2(new_n420_), .B(p0), .Y(new_n421_));
  AO21x1_ASAP7_75t_R   g400(.A1(new_n27_), .A2(new_n418_), .B(new_n421_), .Y(new_n422_));
  AOI211x1_ASAP7_75t_R g401(.A1(new_n407_), .A2(new_n408_), .B(new_n413_), .C(new_n422_), .Y(o9));
  INVx1_ASAP7_75t_R    g402(.A(new_n237_), .Y(new_n424_));
  AND5x1_ASAP7_75t_R   g403(.A(p2), .B(new_n424_), .C(new_n90_), .D(new_n104_), .E(new_n203_), .Y(new_n425_));
  INVx1_ASAP7_75t_R    g404(.A(new_n182_), .Y(new_n426_));
  AO21x1_ASAP7_75t_R   g405(.A1(p0), .A2(new_n28_), .B(new_n33_), .Y(new_n427_));
  AO32x1_ASAP7_75t_R   g406(.A1(new_n425_), .A2(new_n426_), .A3(new_n427_), .B1(new_n37_), .B2(new_n405_), .Y(o10));
endmodule


