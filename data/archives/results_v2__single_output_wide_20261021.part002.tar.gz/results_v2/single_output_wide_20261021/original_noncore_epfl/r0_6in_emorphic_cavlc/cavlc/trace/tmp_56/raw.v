// Benchmark "/tmp/" written by ABC on Wed Oct 21 14:26:24 2026

module \/tmp/  ( 
    p8, p0, p9, p6, p4, p3, p7, p5, p2, p1,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10  );
  input  p8, p0, p9, p6, p4, p3, p7, p5, p2, p1;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10;
  wire new_n22_, new_n23_, new_n24_, new_n25_, new_n26_, new_n27_, new_n28_,
    new_n29_, new_n30_, new_n31_, new_n32_, new_n33_, new_n34_, new_n35_,
    new_n36_, new_n37_, new_n38_, new_n39_, new_n40_, new_n41_, new_n42_,
    new_n43_, new_n44_, new_n45_, new_n46_, new_n47_, new_n48_, new_n49_,
    new_n50_, new_n51_, new_n52_, new_n53_, new_n54_, new_n55_, new_n56_,
    new_n57_, new_n58_, new_n59_, new_n60_, new_n61_, new_n62_, new_n63_,
    new_n64_, new_n65_, new_n66_, new_n67_, new_n68_, new_n69_, new_n70_,
    new_n71_, new_n72_, new_n73_, new_n74_, new_n75_, new_n76_, new_n77_,
    new_n78_, new_n79_, new_n80_, new_n81_, new_n82_, new_n83_, new_n84_,
    new_n85_, new_n86_, new_n87_, new_n88_, new_n89_, new_n90_, new_n91_,
    new_n92_, new_n93_, new_n94_, new_n95_, new_n96_, new_n97_, new_n98_,
    new_n99_, new_n100_, new_n101_, new_n102_, new_n103_, new_n104_,
    new_n105_, new_n106_, new_n107_, new_n108_, new_n109_, new_n110_,
    new_n111_, new_n112_, new_n113_, new_n114_, new_n115_, new_n116_,
    new_n117_, new_n118_, new_n119_, new_n120_, new_n121_, new_n122_,
    new_n123_, new_n125_, new_n126_, new_n127_, new_n128_, new_n129_,
    new_n130_, new_n131_, new_n132_, new_n133_, new_n134_, new_n135_,
    new_n136_, new_n137_, new_n138_, new_n139_, new_n140_, new_n141_,
    new_n142_, new_n143_, new_n144_, new_n145_, new_n146_, new_n147_,
    new_n148_, new_n149_, new_n150_, new_n151_, new_n152_, new_n153_,
    new_n154_, new_n155_, new_n156_, new_n157_, new_n158_, new_n159_,
    new_n160_, new_n161_, new_n162_, new_n163_, new_n164_, new_n165_,
    new_n166_, new_n167_, new_n168_, new_n169_, new_n170_, new_n171_,
    new_n172_, new_n173_, new_n174_, new_n175_, new_n176_, new_n177_,
    new_n178_, new_n179_, new_n180_, new_n181_, new_n182_, new_n183_,
    new_n184_, new_n185_, new_n186_, new_n187_, new_n188_, new_n189_,
    new_n190_, new_n191_, new_n192_, new_n193_, new_n194_, new_n195_,
    new_n196_, new_n198_, new_n199_, new_n200_, new_n201_, new_n202_,
    new_n203_, new_n204_, new_n205_, new_n206_, new_n207_, new_n208_,
    new_n209_, new_n210_, new_n211_, new_n212_, new_n213_, new_n214_,
    new_n215_, new_n216_, new_n217_, new_n218_, new_n219_, new_n220_,
    new_n221_, new_n222_, new_n223_, new_n224_, new_n225_, new_n226_,
    new_n227_, new_n228_, new_n229_, new_n230_, new_n231_, new_n232_,
    new_n233_, new_n234_, new_n235_, new_n236_, new_n237_, new_n238_,
    new_n239_, new_n240_, new_n241_, new_n242_, new_n243_, new_n244_,
    new_n245_, new_n247_, new_n248_, new_n249_, new_n250_, new_n251_,
    new_n252_, new_n253_, new_n254_, new_n255_, new_n256_, new_n257_,
    new_n258_, new_n259_, new_n260_, new_n261_, new_n262_, new_n263_,
    new_n264_, new_n265_, new_n266_, new_n267_, new_n268_, new_n269_,
    new_n270_, new_n271_, new_n272_, new_n273_, new_n274_, new_n275_,
    new_n276_, new_n277_, new_n278_, new_n279_, new_n281_, new_n282_,
    new_n283_, new_n284_, new_n286_, new_n287_, new_n289_, new_n290_,
    new_n291_, new_n292_, new_n293_, new_n294_, new_n295_, new_n296_,
    new_n297_, new_n298_, new_n299_, new_n300_, new_n301_, new_n302_,
    new_n303_, new_n304_, new_n305_, new_n306_, new_n307_, new_n308_,
    new_n309_, new_n310_, new_n311_, new_n312_, new_n313_, new_n314_,
    new_n315_, new_n316_, new_n317_, new_n318_, new_n319_, new_n320_,
    new_n321_, new_n322_, new_n323_, new_n324_, new_n325_, new_n326_,
    new_n327_, new_n328_, new_n330_, new_n331_, new_n332_, new_n333_,
    new_n334_, new_n335_, new_n336_, new_n337_, new_n338_, new_n339_,
    new_n340_, new_n341_, new_n342_, new_n343_, new_n344_, new_n345_,
    new_n346_, new_n347_, new_n348_, new_n349_, new_n350_, new_n351_,
    new_n352_, new_n353_, new_n354_, new_n355_, new_n356_, new_n357_,
    new_n358_, new_n359_, new_n360_, new_n361_, new_n362_, new_n363_,
    new_n364_, new_n365_, new_n366_, new_n367_, new_n368_, new_n369_,
    new_n370_, new_n372_, new_n373_, new_n374_, new_n375_, new_n376_,
    new_n377_, new_n378_, new_n379_, new_n380_, new_n381_, new_n382_,
    new_n383_, new_n384_, new_n385_, new_n386_, new_n387_, new_n388_,
    new_n389_, new_n390_, new_n391_, new_n392_, new_n393_, new_n394_,
    new_n395_, new_n396_, new_n397_, new_n398_, new_n399_, new_n400_,
    new_n401_, new_n402_, new_n404_, new_n405_, new_n406_, new_n407_,
    new_n408_, new_n409_, new_n410_, new_n411_, new_n412_, new_n413_,
    new_n414_, new_n415_, new_n416_, new_n417_, new_n418_, new_n419_,
    new_n421_, new_n422_, new_n423_;
  XNOR2x2_ASAP7_75t_R  g000(.A(p8), .B(p0), .Y(new_n22_));
  INVx1_ASAP7_75t_R    g001(.A(p6), .Y(new_n23_));
  NOR2x1_ASAP7_75t_R   g002(.A(p0), .B(p9), .Y(new_n24_));
  INVx1_ASAP7_75t_R    g003(.A(new_n24_), .Y(new_n25_));
  AND3x1_ASAP7_75t_R   g004(.A(new_n22_), .B(new_n23_), .C(new_n25_), .Y(new_n26_));
  INVx1_ASAP7_75t_R    g005(.A(p8), .Y(new_n27_));
  NOR2x1_ASAP7_75t_R   g006(.A(p0), .B(new_n27_), .Y(new_n28_));
  INVx1_ASAP7_75t_R    g007(.A(new_n28_), .Y(new_n29_));
  INVx1_ASAP7_75t_R    g008(.A(p9), .Y(new_n30_));
  INVx1_ASAP7_75t_R    g009(.A(p0), .Y(new_n31_));
  AO21x1_ASAP7_75t_R   g010(.A1(p8), .A2(new_n30_), .B(new_n31_), .Y(new_n32_));
  NOR2x1_ASAP7_75t_R   g011(.A(p4), .B(p2), .Y(new_n33_));
  AND3x1_ASAP7_75t_R   g012(.A(new_n29_), .B(new_n32_), .C(new_n33_), .Y(new_n34_));
  NOR2x1_ASAP7_75t_R   g013(.A(p7), .B(p1), .Y(new_n35_));
  OAI21x1_ASAP7_75t_R  g014(.A1(new_n26_), .A2(new_n34_), .B(new_n35_), .Y(new_n36_));
  NOR2x1_ASAP7_75t_R   g015(.A(p8), .B(p4), .Y(new_n37_));
  INVx1_ASAP7_75t_R    g016(.A(new_n37_), .Y(new_n38_));
  INVx1_ASAP7_75t_R    g017(.A(p1), .Y(new_n39_));
  NAND2x1_ASAP7_75t_R  g018(.A(p9), .B(new_n39_), .Y(new_n40_));
  AO21x1_ASAP7_75t_R   g019(.A1(p6), .A2(new_n38_), .B(new_n40_), .Y(new_n41_));
  INVx1_ASAP7_75t_R    g020(.A(p4), .Y(new_n42_));
  NAND2x1_ASAP7_75t_R  g021(.A(p7), .B(new_n42_), .Y(new_n43_));
  AO21x1_ASAP7_75t_R   g022(.A1(new_n31_), .A2(new_n38_), .B(new_n40_), .Y(new_n44_));
  NOR2x1_ASAP7_75t_R   g023(.A(p8), .B(p0), .Y(new_n45_));
  INVx1_ASAP7_75t_R    g024(.A(new_n45_), .Y(new_n46_));
  NAND2x1_ASAP7_75t_R  g025(.A(p1), .B(new_n30_), .Y(new_n47_));
  OR3x1_ASAP7_75t_R    g026(.A(new_n46_), .B(new_n47_), .C(new_n23_), .Y(new_n48_));
  NOR2x1_ASAP7_75t_R   g027(.A(p8), .B(new_n31_), .Y(new_n49_));
  AO21x1_ASAP7_75t_R   g028(.A1(new_n23_), .A2(new_n49_), .B(p2), .Y(new_n50_));
  AO221x2_ASAP7_75t_R  g029(.A1(new_n41_), .A2(new_n43_), .B1(new_n44_), .B2(new_n48_), .C(new_n50_), .Y(new_n51_));
  NAND2x1_ASAP7_75t_R  g030(.A(new_n36_), .B(new_n51_), .Y(new_n52_));
  AND2x2_ASAP7_75t_R   g031(.A(p0), .B(p1), .Y(new_n53_));
  OA21x2_ASAP7_75t_R   g032(.A1(p4), .A2(p1), .B(new_n30_), .Y(new_n54_));
  OA21x2_ASAP7_75t_R   g033(.A1(new_n53_), .A2(new_n54_), .B(new_n27_), .Y(new_n55_));
  INVx1_ASAP7_75t_R    g034(.A(p2), .Y(new_n56_));
  NAND2x1_ASAP7_75t_R  g035(.A(p9), .B(p2), .Y(new_n57_));
  NOR2x1_ASAP7_75t_R   g036(.A(p0), .B(new_n57_), .Y(new_n58_));
  AO21x1_ASAP7_75t_R   g037(.A1(p0), .A2(new_n56_), .B(new_n58_), .Y(new_n59_));
  NOR2x1_ASAP7_75t_R   g038(.A(p2), .B(p1), .Y(new_n60_));
  INVx1_ASAP7_75t_R    g039(.A(new_n60_), .Y(new_n61_));
  AND2x2_ASAP7_75t_R   g040(.A(new_n28_), .B(new_n61_), .Y(new_n62_));
  OR3x1_ASAP7_75t_R    g041(.A(new_n55_), .B(new_n59_), .C(new_n62_), .Y(new_n63_));
  INVx1_ASAP7_75t_R    g042(.A(p7), .Y(new_n64_));
  AND3x1_ASAP7_75t_R   g043(.A(new_n63_), .B(new_n23_), .C(new_n64_), .Y(new_n65_));
  NOR2x1_ASAP7_75t_R   g044(.A(p3), .B(p5), .Y(new_n66_));
  OAI21x1_ASAP7_75t_R  g045(.A1(new_n52_), .A2(new_n65_), .B(new_n66_), .Y(new_n67_));
  NAND2x1_ASAP7_75t_R  g046(.A(p8), .B(p1), .Y(new_n68_));
  NOR2x1_ASAP7_75t_R   g047(.A(p5), .B(new_n56_), .Y(new_n69_));
  AND2x2_ASAP7_75t_R   g048(.A(p2), .B(p1), .Y(new_n70_));
  OR3x1_ASAP7_75t_R    g049(.A(new_n46_), .B(new_n69_), .C(new_n70_), .Y(new_n71_));
  AO21x1_ASAP7_75t_R   g050(.A1(new_n68_), .A2(new_n71_), .B(p7), .Y(new_n72_));
  NAND2x1_ASAP7_75t_R  g051(.A(p1), .B(new_n27_), .Y(new_n73_));
  OR3x1_ASAP7_75t_R    g052(.A(new_n73_), .B(p0), .C(new_n57_), .Y(new_n74_));
  AND2x2_ASAP7_75t_R   g053(.A(p8), .B(p1), .Y(new_n75_));
  NOR2x1_ASAP7_75t_R   g054(.A(p0), .B(p2), .Y(new_n76_));
  NOR2x1_ASAP7_75t_R   g055(.A(p7), .B(new_n31_), .Y(new_n77_));
  AO21x1_ASAP7_75t_R   g056(.A1(new_n75_), .A2(new_n76_), .B(new_n77_), .Y(new_n78_));
  NOR2x1_ASAP7_75t_R   g057(.A(p7), .B(new_n56_), .Y(new_n79_));
  NAND2x1_ASAP7_75t_R  g058(.A(p9), .B(new_n31_), .Y(new_n80_));
  AND3x1_ASAP7_75t_R   g059(.A(new_n46_), .B(new_n79_), .C(new_n80_), .Y(new_n81_));
  AOI21x1_ASAP7_75t_R  g060(.A1(new_n30_), .A2(new_n78_), .B(new_n81_), .Y(new_n82_));
  AO31x2_ASAP7_75t_R   g061(.A1(new_n72_), .A2(new_n74_), .A3(new_n82_), .B(p4), .Y(new_n83_));
  AND2x2_ASAP7_75t_R   g062(.A(p7), .B(p2), .Y(new_n84_));
  AO21x1_ASAP7_75t_R   g063(.A1(p8), .A2(new_n31_), .B(p4), .Y(new_n85_));
  AO21x1_ASAP7_75t_R   g064(.A1(new_n30_), .A2(new_n39_), .B(p4), .Y(new_n86_));
  NOR2x1_ASAP7_75t_R   g065(.A(p9), .B(new_n27_), .Y(new_n87_));
  NOR2x1_ASAP7_75t_R   g066(.A(p8), .B(new_n30_), .Y(new_n88_));
  NOR2x1_ASAP7_75t_R   g067(.A(new_n87_), .B(new_n88_), .Y(new_n89_));
  AND3x1_ASAP7_75t_R   g068(.A(p0), .B(p4), .C(p1), .Y(new_n90_));
  AO32x1_ASAP7_75t_R   g069(.A1(p5), .A2(new_n85_), .A3(new_n86_), .B1(new_n89_), .B2(new_n90_), .Y(new_n91_));
  INVx1_ASAP7_75t_R    g070(.A(p5), .Y(new_n92_));
  AO21x1_ASAP7_75t_R   g071(.A1(p9), .A2(new_n27_), .B(p1), .Y(new_n93_));
  NAND2x1_ASAP7_75t_R  g072(.A(p4), .B(p7), .Y(new_n94_));
  AO21x1_ASAP7_75t_R   g073(.A1(new_n92_), .A2(new_n93_), .B(new_n94_), .Y(new_n95_));
  NAND2x1_ASAP7_75t_R  g074(.A(p0), .B(new_n56_), .Y(new_n96_));
  NAND2x1_ASAP7_75t_R  g075(.A(p9), .B(new_n27_), .Y(new_n97_));
  OA211x2_ASAP7_75t_R  g076(.A1(new_n96_), .A2(new_n87_), .B(new_n97_), .C(new_n39_), .Y(new_n98_));
  NOR2x1_ASAP7_75t_R   g077(.A(new_n95_), .B(new_n98_), .Y(new_n99_));
  NOR2x1_ASAP7_75t_R   g078(.A(p8), .B(p1), .Y(new_n100_));
  NAND2x1_ASAP7_75t_R  g079(.A(p0), .B(new_n100_), .Y(new_n101_));
  NAND2x1_ASAP7_75t_R  g080(.A(new_n30_), .B(new_n56_), .Y(new_n102_));
  AOI211x1_ASAP7_75t_R g081(.A1(new_n68_), .A2(new_n101_), .B(new_n92_), .C(new_n102_), .Y(new_n103_));
  NOR2x1_ASAP7_75t_R   g082(.A(p8), .B(p7), .Y(new_n104_));
  AND3x1_ASAP7_75t_R   g083(.A(new_n60_), .B(new_n24_), .C(new_n104_), .Y(new_n105_));
  AO21x1_ASAP7_75t_R   g084(.A1(p7), .A2(new_n103_), .B(new_n105_), .Y(new_n106_));
  AOI211x1_ASAP7_75t_R g085(.A1(new_n84_), .A2(new_n91_), .B(new_n99_), .C(new_n106_), .Y(new_n107_));
  NOR2x1_ASAP7_75t_R   g086(.A(p6), .B(p3), .Y(new_n108_));
  INVx1_ASAP7_75t_R    g087(.A(new_n108_), .Y(new_n109_));
  AO21x1_ASAP7_75t_R   g088(.A1(new_n83_), .A2(new_n107_), .B(new_n109_), .Y(new_n110_));
  NAND2x1_ASAP7_75t_R  g089(.A(p4), .B(p5), .Y(new_n111_));
  INVx1_ASAP7_75t_R    g090(.A(new_n111_), .Y(new_n112_));
  NOR2x1_ASAP7_75t_R   g091(.A(p7), .B(new_n42_), .Y(new_n113_));
  NOR2x1_ASAP7_75t_R   g092(.A(p8), .B(p5), .Y(new_n114_));
  AND2x2_ASAP7_75t_R   g093(.A(p3), .B(p7), .Y(new_n115_));
  OA22x2_ASAP7_75t_R   g094(.A1(new_n112_), .A2(new_n113_), .B1(new_n114_), .B2(new_n115_), .Y(new_n116_));
  INVx1_ASAP7_75t_R    g095(.A(new_n114_), .Y(new_n117_));
  OA21x2_ASAP7_75t_R   g096(.A1(new_n27_), .A2(p3), .B(new_n117_), .Y(new_n118_));
  AND3x1_ASAP7_75t_R   g097(.A(new_n118_), .B(new_n64_), .C(new_n111_), .Y(new_n119_));
  NOR2x1_ASAP7_75t_R   g098(.A(new_n116_), .B(new_n119_), .Y(new_n120_));
  OR3x1_ASAP7_75t_R    g099(.A(p0), .B(p2), .C(p1), .Y(new_n121_));
  NAND2x1_ASAP7_75t_R  g100(.A(new_n30_), .B(new_n23_), .Y(new_n122_));
  OR3x1_ASAP7_75t_R    g101(.A(new_n120_), .B(new_n121_), .C(new_n122_), .Y(new_n123_));
  NAND3x1_ASAP7_75t_R  g102(.A(new_n67_), .B(new_n110_), .C(new_n123_), .Y(o0));
  NAND2x1_ASAP7_75t_R  g103(.A(new_n23_), .B(new_n56_), .Y(new_n125_));
  INVx1_ASAP7_75t_R    g104(.A(p3), .Y(new_n126_));
  AND2x2_ASAP7_75t_R   g105(.A(p7), .B(p5), .Y(new_n127_));
  OR3x1_ASAP7_75t_R    g106(.A(new_n127_), .B(new_n30_), .C(p1), .Y(new_n128_));
  NAND2x1_ASAP7_75t_R  g107(.A(p8), .B(p5), .Y(new_n129_));
  OA21x2_ASAP7_75t_R   g108(.A1(p4), .A2(new_n64_), .B(new_n129_), .Y(new_n130_));
  NOR2x1_ASAP7_75t_R   g109(.A(p1), .B(new_n42_), .Y(new_n131_));
  NOR2x1_ASAP7_75t_R   g110(.A(p7), .B(new_n27_), .Y(new_n132_));
  NAND2x1_ASAP7_75t_R  g111(.A(new_n131_), .B(new_n132_), .Y(new_n133_));
  OAI22x1_ASAP7_75t_R  g112(.A1(new_n128_), .A2(new_n130_), .B1(new_n133_), .B2(p9), .Y(new_n134_));
  AND3x1_ASAP7_75t_R   g113(.A(p8), .B(p9), .C(p7), .Y(new_n135_));
  AND2x2_ASAP7_75t_R   g114(.A(p4), .B(p1), .Y(new_n136_));
  AND3x1_ASAP7_75t_R   g115(.A(new_n45_), .B(p4), .C(new_n39_), .Y(new_n137_));
  NOR2x1_ASAP7_75t_R   g116(.A(p9), .B(p7), .Y(new_n138_));
  AO32x1_ASAP7_75t_R   g117(.A1(new_n31_), .A2(new_n135_), .A3(new_n136_), .B1(new_n137_), .B2(new_n138_), .Y(new_n139_));
  AOI21x1_ASAP7_75t_R  g118(.A1(p0), .A2(new_n134_), .B(new_n139_), .Y(new_n140_));
  NOR2x1_ASAP7_75t_R   g119(.A(p7), .B(p5), .Y(new_n141_));
  INVx1_ASAP7_75t_R    g120(.A(new_n141_), .Y(new_n142_));
  NAND2x1_ASAP7_75t_R  g121(.A(p5), .B(new_n30_), .Y(new_n143_));
  AO21x1_ASAP7_75t_R   g122(.A1(new_n39_), .A2(new_n143_), .B(new_n43_), .Y(new_n144_));
  INVx1_ASAP7_75t_R    g123(.A(new_n49_), .Y(new_n145_));
  AO21x1_ASAP7_75t_R   g124(.A1(new_n142_), .A2(new_n144_), .B(new_n145_), .Y(new_n146_));
  OA21x2_ASAP7_75t_R   g125(.A1(p4), .A2(p7), .B(new_n129_), .Y(new_n147_));
  OAI22x1_ASAP7_75t_R  g126(.A1(p9), .A2(new_n130_), .B1(new_n147_), .B2(new_n132_), .Y(new_n148_));
  NOR2x1_ASAP7_75t_R   g127(.A(p0), .B(new_n39_), .Y(new_n149_));
  AND2x2_ASAP7_75t_R   g128(.A(p7), .B(p1), .Y(new_n150_));
  AOI22x1_ASAP7_75t_R  g129(.A1(new_n148_), .A2(new_n149_), .B1(new_n114_), .B2(new_n150_), .Y(new_n151_));
  NAND3x1_ASAP7_75t_R  g130(.A(new_n140_), .B(new_n146_), .C(new_n151_), .Y(new_n152_));
  AND3x1_ASAP7_75t_R   g131(.A(p8), .B(p3), .C(p5), .Y(new_n153_));
  OA21x2_ASAP7_75t_R   g132(.A1(new_n115_), .A2(new_n113_), .B(new_n114_), .Y(new_n154_));
  AND3x1_ASAP7_75t_R   g133(.A(new_n31_), .B(new_n30_), .C(new_n39_), .Y(new_n155_));
  OA21x2_ASAP7_75t_R   g134(.A1(new_n153_), .A2(new_n154_), .B(new_n155_), .Y(new_n156_));
  AOI21x1_ASAP7_75t_R  g135(.A1(new_n126_), .A2(new_n152_), .B(new_n156_), .Y(new_n157_));
  NOR2x1_ASAP7_75t_R   g136(.A(p0), .B(new_n56_), .Y(new_n158_));
  AND2x2_ASAP7_75t_R   g137(.A(p0), .B(p4), .Y(new_n159_));
  AO21x1_ASAP7_75t_R   g138(.A1(new_n35_), .A2(new_n158_), .B(new_n159_), .Y(new_n160_));
  AND3x1_ASAP7_75t_R   g139(.A(new_n160_), .B(p9), .C(p5), .Y(new_n161_));
  AO21x1_ASAP7_75t_R   g140(.A1(p2), .A2(new_n53_), .B(p4), .Y(new_n162_));
  AND3x1_ASAP7_75t_R   g141(.A(new_n162_), .B(p5), .C(new_n61_), .Y(new_n163_));
  AO21x1_ASAP7_75t_R   g142(.A1(new_n90_), .A2(new_n79_), .B(new_n27_), .Y(new_n164_));
  OR3x1_ASAP7_75t_R    g143(.A(new_n161_), .B(new_n163_), .C(new_n164_), .Y(new_n165_));
  NOR2x1_ASAP7_75t_R   g144(.A(p0), .B(p5), .Y(new_n166_));
  NAND2x1_ASAP7_75t_R  g145(.A(p0), .B(p9), .Y(new_n167_));
  INVx1_ASAP7_75t_R    g146(.A(new_n167_), .Y(new_n168_));
  NOR2x1_ASAP7_75t_R   g147(.A(new_n166_), .B(new_n168_), .Y(new_n169_));
  NAND2x1_ASAP7_75t_R  g148(.A(p7), .B(new_n30_), .Y(new_n170_));
  AND3x1_ASAP7_75t_R   g149(.A(new_n170_), .B(new_n42_), .C(new_n39_), .Y(new_n171_));
  NAND2x1_ASAP7_75t_R  g150(.A(new_n31_), .B(new_n64_), .Y(new_n172_));
  AO32x1_ASAP7_75t_R   g151(.A1(new_n172_), .A2(p2), .A3(new_n39_), .B1(new_n158_), .B2(new_n127_), .Y(new_n173_));
  AND3x1_ASAP7_75t_R   g152(.A(new_n64_), .B(new_n39_), .C(p4), .Y(new_n174_));
  AO21x1_ASAP7_75t_R   g153(.A1(new_n166_), .A2(new_n174_), .B(p8), .Y(new_n175_));
  AOI221x1_ASAP7_75t_R g154(.A1(new_n169_), .A2(new_n171_), .B1(new_n173_), .B2(new_n42_), .C(new_n175_), .Y(new_n176_));
  NOR2x1_ASAP7_75t_R   g155(.A(p7), .B(p2), .Y(new_n177_));
  NOR2x1_ASAP7_75t_R   g156(.A(new_n30_), .B(new_n177_), .Y(new_n178_));
  AO21x1_ASAP7_75t_R   g157(.A1(p7), .A2(p2), .B(p1), .Y(new_n179_));
  AO32x1_ASAP7_75t_R   g158(.A1(new_n178_), .A2(new_n31_), .A3(new_n43_), .B1(new_n30_), .B2(new_n179_), .Y(new_n180_));
  NAND2x1_ASAP7_75t_R  g159(.A(p9), .B(p7), .Y(new_n181_));
  NOR2x1_ASAP7_75t_R   g160(.A(p1), .B(new_n181_), .Y(new_n182_));
  NAND2x1_ASAP7_75t_R  g161(.A(p4), .B(new_n30_), .Y(new_n183_));
  NAND2x1_ASAP7_75t_R  g162(.A(p9), .B(new_n42_), .Y(new_n184_));
  NAND2x1_ASAP7_75t_R  g163(.A(new_n183_), .B(new_n184_), .Y(new_n185_));
  OA21x2_ASAP7_75t_R   g164(.A1(new_n182_), .A2(new_n185_), .B(p0), .Y(new_n186_));
  OAI21x1_ASAP7_75t_R  g165(.A1(new_n180_), .A2(new_n186_), .B(new_n92_), .Y(new_n187_));
  AOI21x1_ASAP7_75t_R  g166(.A1(new_n176_), .A2(new_n187_), .B(new_n109_), .Y(new_n188_));
  INVx1_ASAP7_75t_R    g167(.A(new_n47_), .Y(new_n189_));
  AND5x1_ASAP7_75t_R   g168(.A(new_n27_), .B(new_n39_), .C(p0), .D(p6), .E(p7), .Y(new_n190_));
  AO21x1_ASAP7_75t_R   g169(.A1(new_n45_), .A2(new_n189_), .B(new_n190_), .Y(new_n191_));
  OA211x2_ASAP7_75t_R  g170(.A1(new_n39_), .A2(new_n24_), .B(new_n64_), .C(p6), .Y(new_n192_));
  OA21x2_ASAP7_75t_R   g171(.A1(new_n168_), .A2(new_n93_), .B(new_n192_), .Y(new_n193_));
  AND3x1_ASAP7_75t_R   g172(.A(new_n33_), .B(new_n126_), .C(new_n92_), .Y(new_n194_));
  OA21x2_ASAP7_75t_R   g173(.A1(new_n191_), .A2(new_n193_), .B(new_n194_), .Y(new_n195_));
  AOI21x1_ASAP7_75t_R  g174(.A1(new_n165_), .A2(new_n188_), .B(new_n195_), .Y(new_n196_));
  OAI21x1_ASAP7_75t_R  g175(.A1(new_n125_), .A2(new_n157_), .B(new_n196_), .Y(o1));
  AND2x2_ASAP7_75t_R   g176(.A(p9), .B(p7), .Y(new_n198_));
  OA211x2_ASAP7_75t_R  g177(.A1(new_n42_), .A2(new_n158_), .B(new_n88_), .C(new_n35_), .Y(new_n199_));
  AOI21x1_ASAP7_75t_R  g178(.A1(new_n62_), .A2(new_n198_), .B(new_n199_), .Y(new_n200_));
  NAND2x1_ASAP7_75t_R  g179(.A(p8), .B(p7), .Y(new_n201_));
  NAND2x1_ASAP7_75t_R  g180(.A(p1), .B(new_n201_), .Y(new_n202_));
  AO21x1_ASAP7_75t_R   g181(.A1(new_n46_), .A2(new_n104_), .B(new_n202_), .Y(new_n203_));
  NOR2x1_ASAP7_75t_R   g182(.A(new_n104_), .B(new_n135_), .Y(new_n204_));
  AO21x1_ASAP7_75t_R   g183(.A1(new_n42_), .A2(new_n68_), .B(new_n31_), .Y(new_n205_));
  AO21x1_ASAP7_75t_R   g184(.A1(p4), .A2(new_n204_), .B(new_n205_), .Y(new_n206_));
  AO21x1_ASAP7_75t_R   g185(.A1(new_n203_), .A2(new_n206_), .B(p2), .Y(new_n207_));
  AOI21x1_ASAP7_75t_R  g186(.A1(new_n200_), .A2(new_n207_), .B(p5), .Y(new_n208_));
  AND3x1_ASAP7_75t_R   g187(.A(new_n27_), .B(new_n64_), .C(p1), .Y(new_n209_));
  AO21x1_ASAP7_75t_R   g188(.A1(p7), .A2(new_n73_), .B(new_n209_), .Y(new_n210_));
  OA211x2_ASAP7_75t_R  g189(.A1(new_n31_), .A2(new_n75_), .B(new_n172_), .C(p5), .Y(new_n211_));
  OAI21x1_ASAP7_75t_R  g190(.A1(new_n210_), .A2(new_n211_), .B(p2), .Y(new_n212_));
  NAND2x1_ASAP7_75t_R  g191(.A(new_n177_), .B(new_n22_), .Y(new_n213_));
  AO21x1_ASAP7_75t_R   g192(.A1(p8), .A2(new_n31_), .B(new_n92_), .Y(new_n214_));
  AO21x1_ASAP7_75t_R   g193(.A1(new_n214_), .A2(new_n145_), .B(new_n64_), .Y(new_n215_));
  AO21x1_ASAP7_75t_R   g194(.A1(new_n213_), .A2(new_n215_), .B(p1), .Y(new_n216_));
  AOI21x1_ASAP7_75t_R  g195(.A1(new_n212_), .A2(new_n216_), .B(new_n184_), .Y(new_n217_));
  OAI21x1_ASAP7_75t_R  g196(.A1(new_n208_), .A2(new_n217_), .B(new_n126_), .Y(new_n218_));
  NAND2x1_ASAP7_75t_R  g197(.A(p2), .B(new_n39_), .Y(new_n219_));
  NAND2x1_ASAP7_75t_R  g198(.A(p4), .B(p2), .Y(new_n220_));
  AO21x1_ASAP7_75t_R   g199(.A1(p7), .A2(new_n39_), .B(new_n56_), .Y(new_n221_));
  AO32x1_ASAP7_75t_R   g200(.A1(p7), .A2(new_n219_), .A3(new_n220_), .B1(new_n221_), .B2(p4), .Y(new_n222_));
  NOR2x1_ASAP7_75t_R   g201(.A(p7), .B(new_n92_), .Y(new_n223_));
  AND2x2_ASAP7_75t_R   g202(.A(p8), .B(p0), .Y(new_n224_));
  AO32x1_ASAP7_75t_R   g203(.A1(new_n27_), .A2(new_n42_), .A3(new_n76_), .B1(new_n224_), .B2(new_n56_), .Y(new_n225_));
  AOI22x1_ASAP7_75t_R  g204(.A1(new_n222_), .A2(new_n49_), .B1(new_n223_), .B2(new_n225_), .Y(new_n226_));
  NAND2x1_ASAP7_75t_R  g205(.A(p0), .B(p7), .Y(new_n227_));
  AO21x1_ASAP7_75t_R   g206(.A1(p5), .A2(new_n227_), .B(p8), .Y(new_n228_));
  INVx1_ASAP7_75t_R    g207(.A(new_n219_), .Y(new_n229_));
  AO21x1_ASAP7_75t_R   g208(.A1(new_n28_), .A2(new_n79_), .B(new_n229_), .Y(new_n230_));
  AND2x2_ASAP7_75t_R   g209(.A(p5), .B(p1), .Y(new_n231_));
  OA211x2_ASAP7_75t_R  g210(.A1(new_n231_), .A2(new_n227_), .B(new_n179_), .C(p4), .Y(new_n232_));
  AO21x1_ASAP7_75t_R   g211(.A1(p2), .A2(new_n27_), .B(p5), .Y(new_n233_));
  NOR2x1_ASAP7_75t_R   g212(.A(new_n49_), .B(new_n79_), .Y(new_n234_));
  OAI21x1_ASAP7_75t_R  g213(.A1(new_n233_), .A2(new_n234_), .B(new_n126_), .Y(new_n235_));
  AOI211x1_ASAP7_75t_R g214(.A1(new_n228_), .A2(new_n230_), .B(new_n232_), .C(new_n235_), .Y(new_n236_));
  AND2x2_ASAP7_75t_R   g215(.A(p8), .B(p7), .Y(new_n237_));
  OA21x2_ASAP7_75t_R   g216(.A1(new_n237_), .A2(new_n223_), .B(new_n42_), .Y(new_n238_));
  AO21x1_ASAP7_75t_R   g217(.A1(p3), .A2(new_n121_), .B(p9), .Y(new_n239_));
  AO21x1_ASAP7_75t_R   g218(.A1(p3), .A2(new_n238_), .B(new_n239_), .Y(new_n240_));
  AOI21x1_ASAP7_75t_R  g219(.A1(new_n226_), .A2(new_n236_), .B(new_n240_), .Y(new_n241_));
  OA21x2_ASAP7_75t_R   g220(.A1(new_n23_), .A2(new_n201_), .B(p9), .Y(new_n242_));
  OAI22x1_ASAP7_75t_R  g221(.A1(new_n242_), .A2(new_n32_), .B1(new_n97_), .B2(new_n172_), .Y(new_n243_));
  AND3x1_ASAP7_75t_R   g222(.A(new_n243_), .B(new_n39_), .C(new_n194_), .Y(new_n244_));
  AOI21x1_ASAP7_75t_R  g223(.A1(new_n23_), .A2(new_n241_), .B(new_n244_), .Y(new_n245_));
  OAI21x1_ASAP7_75t_R  g224(.A1(p6), .A2(new_n218_), .B(new_n245_), .Y(o2));
  NAND2x1_ASAP7_75t_R  g225(.A(p1), .B(new_n56_), .Y(new_n247_));
  AO21x1_ASAP7_75t_R   g226(.A1(new_n94_), .A2(new_n247_), .B(new_n150_), .Y(new_n248_));
  OA21x2_ASAP7_75t_R   g227(.A1(new_n39_), .A2(new_n43_), .B(new_n248_), .Y(new_n249_));
  NOR2x1_ASAP7_75t_R   g228(.A(p4), .B(new_n56_), .Y(new_n250_));
  NOR2x1_ASAP7_75t_R   g229(.A(p5), .B(new_n79_), .Y(new_n251_));
  OA211x2_ASAP7_75t_R  g230(.A1(new_n250_), .A2(new_n251_), .B(new_n133_), .C(new_n219_), .Y(new_n252_));
  OAI21x1_ASAP7_75t_R  g231(.A1(p8), .A2(new_n249_), .B(new_n252_), .Y(new_n253_));
  AO32x1_ASAP7_75t_R   g232(.A1(new_n35_), .A2(new_n166_), .A3(p4), .B1(p5), .B2(new_n33_), .Y(new_n254_));
  OR3x1_ASAP7_75t_R    g233(.A(new_n60_), .B(new_n129_), .C(p4), .Y(new_n255_));
  AOI22x1_ASAP7_75t_R  g234(.A1(new_n64_), .A2(new_n69_), .B1(new_n223_), .B2(new_n37_), .Y(new_n256_));
  AOI21x1_ASAP7_75t_R  g235(.A1(new_n255_), .A2(new_n256_), .B(p0), .Y(new_n257_));
  AO21x1_ASAP7_75t_R   g236(.A1(new_n88_), .A2(new_n254_), .B(new_n257_), .Y(new_n258_));
  AO21x1_ASAP7_75t_R   g237(.A1(p4), .A2(p7), .B(new_n224_), .Y(new_n259_));
  NOR2x1_ASAP7_75t_R   g238(.A(p4), .B(p5), .Y(new_n260_));
  AO21x1_ASAP7_75t_R   g239(.A1(new_n27_), .A2(new_n92_), .B(new_n260_), .Y(new_n261_));
  AND3x1_ASAP7_75t_R   g240(.A(new_n259_), .B(p2), .C(new_n261_), .Y(new_n262_));
  OA21x2_ASAP7_75t_R   g241(.A1(new_n37_), .A2(new_n141_), .B(new_n229_), .Y(new_n263_));
  AND5x1_ASAP7_75t_R   g242(.A(new_n27_), .B(new_n42_), .C(p0), .D(p7), .E(p5), .Y(new_n264_));
  AND3x1_ASAP7_75t_R   g243(.A(new_n28_), .B(new_n92_), .C(new_n70_), .Y(new_n265_));
  OR4x2_ASAP7_75t_R    g244(.A(new_n262_), .B(new_n263_), .C(new_n264_), .D(new_n265_), .Y(new_n266_));
  AOI211x1_ASAP7_75t_R g245(.A1(new_n168_), .A2(new_n253_), .B(new_n258_), .C(new_n266_), .Y(new_n267_));
  AND3x1_ASAP7_75t_R   g246(.A(new_n136_), .B(new_n237_), .C(new_n92_), .Y(new_n268_));
  INVx1_ASAP7_75t_R    g247(.A(new_n113_), .Y(new_n269_));
  AO21x1_ASAP7_75t_R   g248(.A1(p5), .A2(new_n64_), .B(p2), .Y(new_n270_));
  AO32x1_ASAP7_75t_R   g249(.A1(new_n269_), .A2(new_n111_), .A3(new_n270_), .B1(new_n42_), .B2(new_n209_), .Y(new_n271_));
  OA21x2_ASAP7_75t_R   g250(.A1(new_n268_), .A2(new_n271_), .B(p0), .Y(new_n272_));
  AND3x1_ASAP7_75t_R   g251(.A(new_n60_), .B(new_n31_), .C(p3), .Y(new_n273_));
  INVx1_ASAP7_75t_R    g252(.A(new_n260_), .Y(new_n274_));
  NAND2x1_ASAP7_75t_R  g253(.A(new_n111_), .B(new_n274_), .Y(new_n275_));
  AO21x1_ASAP7_75t_R   g254(.A1(p8), .A2(p7), .B(p5), .Y(new_n276_));
  AO32x1_ASAP7_75t_R   g255(.A1(new_n233_), .A2(new_n31_), .A3(new_n61_), .B1(new_n42_), .B2(new_n231_), .Y(new_n277_));
  AO32x1_ASAP7_75t_R   g256(.A1(new_n273_), .A2(new_n275_), .A3(new_n276_), .B1(new_n277_), .B2(new_n126_), .Y(new_n278_));
  AOI21x1_ASAP7_75t_R  g257(.A1(new_n126_), .A2(new_n272_), .B(new_n278_), .Y(new_n279_));
  OAI22x1_ASAP7_75t_R  g258(.A1(new_n267_), .A2(new_n109_), .B1(new_n122_), .B2(new_n279_), .Y(o3));
  AND3x1_ASAP7_75t_R   g259(.A(new_n25_), .B(new_n126_), .C(p1), .Y(new_n281_));
  NOR2x1_ASAP7_75t_R   g260(.A(p2), .B(new_n126_), .Y(new_n282_));
  NOR2x1_ASAP7_75t_R   g261(.A(p3), .B(new_n56_), .Y(new_n283_));
  OA21x2_ASAP7_75t_R   g262(.A1(new_n282_), .A2(new_n283_), .B(new_n155_), .Y(new_n284_));
  OA211x2_ASAP7_75t_R  g263(.A1(new_n281_), .A2(new_n284_), .B(new_n23_), .C(new_n112_), .Y(o4));
  AND3x1_ASAP7_75t_R   g264(.A(new_n60_), .B(new_n24_), .C(p3), .Y(new_n286_));
  OA21x2_ASAP7_75t_R   g265(.A1(p1), .A2(new_n25_), .B(new_n283_), .Y(new_n287_));
  OA211x2_ASAP7_75t_R  g266(.A1(new_n286_), .A2(new_n287_), .B(new_n23_), .C(new_n112_), .Y(o5));
  AND3x1_ASAP7_75t_R   g267(.A(new_n182_), .B(p8), .C(p5), .Y(new_n289_));
  AND3x1_ASAP7_75t_R   g268(.A(new_n77_), .B(new_n47_), .C(p8), .Y(new_n290_));
  INVx1_ASAP7_75t_R    g269(.A(new_n138_), .Y(new_n291_));
  AND3x1_ASAP7_75t_R   g270(.A(new_n291_), .B(new_n49_), .C(new_n184_), .Y(new_n292_));
  OR3x1_ASAP7_75t_R    g271(.A(new_n289_), .B(new_n290_), .C(new_n292_), .Y(new_n293_));
  AO21x1_ASAP7_75t_R   g272(.A1(p5), .A2(new_n64_), .B(p9), .Y(new_n294_));
  NOR2x1_ASAP7_75t_R   g273(.A(p9), .B(new_n64_), .Y(new_n295_));
  AO32x1_ASAP7_75t_R   g274(.A1(new_n294_), .A2(new_n94_), .A3(new_n100_), .B1(new_n75_), .B2(new_n295_), .Y(new_n296_));
  AOI22x1_ASAP7_75t_R  g275(.A1(new_n293_), .A2(p2), .B1(new_n31_), .B2(new_n296_), .Y(new_n297_));
  AO21x1_ASAP7_75t_R   g276(.A1(p1), .A2(new_n42_), .B(p5), .Y(new_n298_));
  AO32x1_ASAP7_75t_R   g277(.A1(new_n89_), .A2(p4), .A3(new_n39_), .B1(new_n87_), .B2(new_n298_), .Y(new_n299_));
  OA21x2_ASAP7_75t_R   g278(.A1(p8), .A2(p7), .B(p1), .Y(new_n300_));
  OA211x2_ASAP7_75t_R  g279(.A1(new_n135_), .A2(new_n300_), .B(p0), .C(p5), .Y(new_n301_));
  AOI21x1_ASAP7_75t_R  g280(.A1(new_n77_), .A2(new_n299_), .B(new_n301_), .Y(new_n302_));
  NOR2x1_ASAP7_75t_R   g281(.A(p0), .B(new_n104_), .Y(new_n303_));
  OR3x1_ASAP7_75t_R    g282(.A(new_n303_), .B(new_n30_), .C(new_n49_), .Y(new_n304_));
  NOR2x1_ASAP7_75t_R   g283(.A(p9), .B(p5), .Y(new_n305_));
  NAND2x1_ASAP7_75t_R  g284(.A(new_n305_), .B(new_n172_), .Y(new_n306_));
  AO21x1_ASAP7_75t_R   g285(.A1(new_n73_), .A2(new_n306_), .B(new_n22_), .Y(new_n307_));
  INVx1_ASAP7_75t_R    g286(.A(new_n250_), .Y(new_n308_));
  AO21x1_ASAP7_75t_R   g287(.A1(new_n304_), .A2(new_n307_), .B(new_n308_), .Y(new_n309_));
  NAND3x1_ASAP7_75t_R  g288(.A(new_n297_), .B(new_n302_), .C(new_n309_), .Y(new_n310_));
  OA21x2_ASAP7_75t_R   g289(.A1(new_n112_), .A2(new_n286_), .B(new_n23_), .Y(new_n311_));
  OR4x2_ASAP7_75t_R    g290(.A(new_n204_), .B(new_n23_), .C(p1), .D(new_n303_), .Y(new_n312_));
  AO21x1_ASAP7_75t_R   g291(.A1(p6), .A2(new_n27_), .B(new_n64_), .Y(new_n313_));
  NAND2x1_ASAP7_75t_R  g292(.A(new_n149_), .B(new_n313_), .Y(new_n314_));
  AO21x1_ASAP7_75t_R   g293(.A1(new_n101_), .A2(new_n314_), .B(p9), .Y(new_n315_));
  AO21x1_ASAP7_75t_R   g294(.A1(new_n312_), .A2(new_n315_), .B(new_n274_), .Y(new_n316_));
  OR3x1_ASAP7_75t_R    g295(.A(new_n117_), .B(new_n53_), .C(new_n136_), .Y(new_n317_));
  NAND2x1_ASAP7_75t_R  g296(.A(new_n159_), .B(new_n135_), .Y(new_n318_));
  OA21x2_ASAP7_75t_R   g297(.A1(new_n181_), .A2(new_n317_), .B(new_n318_), .Y(new_n319_));
  NOR2x1_ASAP7_75t_R   g298(.A(new_n104_), .B(new_n237_), .Y(new_n320_));
  NOR2x1_ASAP7_75t_R   g299(.A(new_n35_), .B(new_n150_), .Y(new_n321_));
  OR3x1_ASAP7_75t_R    g300(.A(new_n320_), .B(new_n321_), .C(new_n92_), .Y(new_n322_));
  AND3x1_ASAP7_75t_R   g301(.A(new_n38_), .B(new_n30_), .C(new_n150_), .Y(new_n323_));
  AO32x1_ASAP7_75t_R   g302(.A1(new_n30_), .A2(p4), .A3(new_n75_), .B1(new_n113_), .B2(new_n45_), .Y(new_n324_));
  NOR2x1_ASAP7_75t_R   g303(.A(new_n323_), .B(new_n324_), .Y(new_n325_));
  AO31x2_ASAP7_75t_R   g304(.A1(new_n319_), .A2(new_n322_), .A3(new_n325_), .B(p6), .Y(new_n326_));
  NAND2x1_ASAP7_75t_R  g305(.A(new_n126_), .B(new_n56_), .Y(new_n327_));
  AOI21x1_ASAP7_75t_R  g306(.A1(new_n316_), .A2(new_n326_), .B(new_n327_), .Y(new_n328_));
  AOI211x1_ASAP7_75t_R g307(.A1(new_n108_), .A2(new_n310_), .B(new_n311_), .C(new_n328_), .Y(o6));
  AO32x1_ASAP7_75t_R   g308(.A1(new_n27_), .A2(p6), .A3(new_n182_), .B1(new_n189_), .B2(new_n320_), .Y(new_n330_));
  AND3x1_ASAP7_75t_R   g309(.A(new_n330_), .B(new_n76_), .C(new_n260_), .Y(new_n331_));
  OA21x2_ASAP7_75t_R   g310(.A1(new_n23_), .A2(new_n331_), .B(new_n126_), .Y(new_n332_));
  NAND2x1_ASAP7_75t_R  g311(.A(p2), .B(new_n92_), .Y(new_n333_));
  NAND2x1_ASAP7_75t_R  g312(.A(p5), .B(new_n64_), .Y(new_n334_));
  OAI21x1_ASAP7_75t_R  g313(.A1(new_n333_), .A2(new_n170_), .B(new_n334_), .Y(new_n335_));
  AOI221x1_ASAP7_75t_R g314(.A1(p8), .A2(new_n30_), .B1(new_n129_), .B2(new_n64_), .C(new_n305_), .Y(new_n336_));
  AOI22x1_ASAP7_75t_R  g315(.A1(new_n335_), .A2(p8), .B1(new_n333_), .B2(new_n336_), .Y(new_n337_));
  NOR2x1_ASAP7_75t_R   g316(.A(p5), .B(new_n39_), .Y(new_n338_));
  AO21x1_ASAP7_75t_R   g317(.A1(p2), .A2(new_n201_), .B(new_n198_), .Y(new_n339_));
  AO32x1_ASAP7_75t_R   g318(.A1(new_n237_), .A2(new_n56_), .A3(p1), .B1(new_n114_), .B2(new_n177_), .Y(new_n340_));
  AOI21x1_ASAP7_75t_R  g319(.A1(new_n338_), .A2(new_n339_), .B(new_n340_), .Y(new_n341_));
  OAI21x1_ASAP7_75t_R  g320(.A1(p1), .A2(new_n337_), .B(new_n341_), .Y(new_n342_));
  NOR3x1_ASAP7_75t_R   g321(.A(new_n88_), .B(p1), .C(new_n276_), .Y(new_n343_));
  INVx1_ASAP7_75t_R    g322(.A(new_n104_), .Y(new_n344_));
  AOI21x1_ASAP7_75t_R  g323(.A1(new_n201_), .A2(new_n344_), .B(new_n143_), .Y(new_n345_));
  OAI21x1_ASAP7_75t_R  g324(.A1(new_n343_), .A2(new_n345_), .B(new_n158_), .Y(new_n346_));
  NOR3x1_ASAP7_75t_R   g325(.A(p9), .B(p7), .C(p1), .Y(new_n347_));
  AND3x1_ASAP7_75t_R   g326(.A(p9), .B(p7), .C(p5), .Y(new_n348_));
  OA21x2_ASAP7_75t_R   g327(.A1(new_n347_), .A2(new_n348_), .B(new_n27_), .Y(new_n349_));
  OA21x2_ASAP7_75t_R   g328(.A1(p5), .A2(new_n177_), .B(new_n300_), .Y(new_n350_));
  OAI21x1_ASAP7_75t_R  g329(.A1(new_n349_), .A2(new_n350_), .B(new_n31_), .Y(new_n351_));
  OR5x1_ASAP7_75t_R    g330(.A(p8), .B(new_n92_), .C(new_n56_), .D(p7), .E(p1), .Y(new_n352_));
  NAND3x1_ASAP7_75t_R  g331(.A(new_n346_), .B(new_n351_), .C(new_n352_), .Y(new_n353_));
  AOI21x1_ASAP7_75t_R  g332(.A1(p0), .A2(new_n342_), .B(new_n353_), .Y(new_n354_));
  OR3x1_ASAP7_75t_R    g333(.A(new_n75_), .B(new_n100_), .C(new_n181_), .Y(new_n355_));
  OR4x2_ASAP7_75t_R    g334(.A(new_n42_), .B(new_n64_), .C(p8), .D(p9), .Y(new_n356_));
  OR3x1_ASAP7_75t_R    g335(.A(new_n68_), .B(new_n42_), .C(p7), .Y(new_n357_));
  AO31x2_ASAP7_75t_R   g336(.A1(new_n355_), .A2(new_n356_), .A3(new_n357_), .B(new_n96_), .Y(new_n358_));
  AOI21x1_ASAP7_75t_R  g337(.A1(new_n220_), .A2(new_n73_), .B(new_n291_), .Y(new_n359_));
  AND3x1_ASAP7_75t_R   g338(.A(new_n131_), .B(p2), .C(new_n201_), .Y(new_n360_));
  OAI21x1_ASAP7_75t_R  g339(.A1(new_n359_), .A2(new_n360_), .B(p0), .Y(new_n361_));
  AOI211x1_ASAP7_75t_R g340(.A1(new_n39_), .A2(new_n57_), .B(p0), .C(new_n42_), .Y(new_n362_));
  AOI22x1_ASAP7_75t_R  g341(.A1(p8), .A2(p7), .B1(p2), .B2(p1), .Y(new_n363_));
  OAI21x1_ASAP7_75t_R  g342(.A1(p8), .A2(p7), .B(new_n363_), .Y(new_n364_));
  AND3x1_ASAP7_75t_R   g343(.A(new_n136_), .B(new_n237_), .C(p2), .Y(new_n365_));
  AOI221x1_ASAP7_75t_R g344(.A1(new_n58_), .A2(new_n209_), .B1(new_n362_), .B2(new_n364_), .C(new_n365_), .Y(new_n366_));
  NAND3x1_ASAP7_75t_R  g345(.A(new_n358_), .B(new_n361_), .C(new_n366_), .Y(new_n367_));
  AOI21x1_ASAP7_75t_R  g346(.A1(new_n92_), .A2(new_n367_), .B(new_n331_), .Y(new_n368_));
  OAI21x1_ASAP7_75t_R  g347(.A1(p4), .A2(new_n354_), .B(new_n368_), .Y(new_n369_));
  AND3x1_ASAP7_75t_R   g348(.A(new_n286_), .B(new_n23_), .C(new_n260_), .Y(new_n370_));
  AOI21x1_ASAP7_75t_R  g349(.A1(new_n332_), .A2(new_n369_), .B(new_n370_), .Y(o7));
  NOR2x1_ASAP7_75t_R   g350(.A(new_n159_), .B(new_n250_), .Y(new_n372_));
  AO21x1_ASAP7_75t_R   g351(.A1(p2), .A2(new_n39_), .B(new_n100_), .Y(new_n373_));
  AND3x1_ASAP7_75t_R   g352(.A(new_n372_), .B(new_n46_), .C(new_n373_), .Y(new_n374_));
  AND3x1_ASAP7_75t_R   g353(.A(new_n56_), .B(p8), .C(p0), .Y(new_n375_));
  OA21x2_ASAP7_75t_R   g354(.A1(new_n375_), .A2(new_n137_), .B(new_n30_), .Y(new_n376_));
  NOR2x1_ASAP7_75t_R   g355(.A(p2), .B(new_n39_), .Y(new_n377_));
  AO32x1_ASAP7_75t_R   g356(.A1(new_n42_), .A2(p1), .A3(new_n76_), .B1(new_n22_), .B2(new_n377_), .Y(new_n378_));
  OR3x1_ASAP7_75t_R    g357(.A(new_n374_), .B(new_n376_), .C(new_n378_), .Y(new_n379_));
  NAND2x1_ASAP7_75t_R  g358(.A(new_n141_), .B(new_n379_), .Y(new_n380_));
  AND3x1_ASAP7_75t_R   g359(.A(new_n102_), .B(p7), .C(new_n39_), .Y(new_n381_));
  AND3x1_ASAP7_75t_R   g360(.A(new_n198_), .B(new_n42_), .C(new_n76_), .Y(new_n382_));
  OA211x2_ASAP7_75t_R  g361(.A1(p4), .A2(new_n295_), .B(new_n53_), .C(new_n220_), .Y(new_n383_));
  AOI211x1_ASAP7_75t_R g362(.A1(new_n372_), .A2(new_n381_), .B(new_n382_), .C(new_n383_), .Y(new_n384_));
  AND3x1_ASAP7_75t_R   g363(.A(new_n158_), .B(p7), .C(new_n39_), .Y(new_n385_));
  OAI21x1_ASAP7_75t_R  g364(.A1(p4), .A2(new_n39_), .B(new_n220_), .Y(new_n386_));
  AND3x1_ASAP7_75t_R   g365(.A(new_n221_), .B(p0), .C(new_n386_), .Y(new_n387_));
  AOI21x1_ASAP7_75t_R  g366(.A1(new_n183_), .A2(new_n385_), .B(new_n387_), .Y(new_n388_));
  NAND2x1_ASAP7_75t_R  g367(.A(p8), .B(new_n92_), .Y(new_n389_));
  OA22x2_ASAP7_75t_R   g368(.A1(new_n384_), .A2(new_n117_), .B1(new_n388_), .B2(new_n389_), .Y(new_n390_));
  AO21x1_ASAP7_75t_R   g369(.A1(new_n31_), .A2(new_n344_), .B(new_n30_), .Y(new_n391_));
  NOR2x1_ASAP7_75t_R   g370(.A(p5), .B(new_n77_), .Y(new_n392_));
  AO21x1_ASAP7_75t_R   g371(.A1(new_n295_), .A2(new_n145_), .B(new_n214_), .Y(new_n393_));
  AO221x2_ASAP7_75t_R  g372(.A1(new_n391_), .A2(new_n392_), .B1(new_n393_), .B2(new_n39_), .C(new_n308_), .Y(new_n394_));
  NAND3x1_ASAP7_75t_R  g373(.A(new_n380_), .B(new_n390_), .C(new_n394_), .Y(new_n395_));
  NAND2x1_ASAP7_75t_R  g374(.A(new_n224_), .B(new_n347_), .Y(new_n396_));
  AOI22x1_ASAP7_75t_R  g375(.A1(new_n182_), .A2(new_n27_), .B1(new_n75_), .B2(new_n138_), .Y(new_n397_));
  OR3x1_ASAP7_75t_R    g376(.A(new_n321_), .B(p8), .C(p9), .Y(new_n398_));
  AO21x1_ASAP7_75t_R   g377(.A1(new_n397_), .A2(new_n398_), .B(p0), .Y(new_n399_));
  NAND2x1_ASAP7_75t_R  g378(.A(new_n396_), .B(new_n399_), .Y(new_n400_));
  AND3x1_ASAP7_75t_R   g379(.A(new_n286_), .B(new_n23_), .C(new_n42_), .Y(new_n401_));
  AO21x1_ASAP7_75t_R   g380(.A1(new_n194_), .A2(new_n400_), .B(new_n401_), .Y(new_n402_));
  AOI21x1_ASAP7_75t_R  g381(.A1(new_n108_), .A2(new_n395_), .B(new_n402_), .Y(o8));
  AND3x1_ASAP7_75t_R   g382(.A(new_n70_), .B(new_n201_), .C(new_n260_), .Y(new_n404_));
  AND3x1_ASAP7_75t_R   g383(.A(new_n274_), .B(new_n56_), .C(new_n276_), .Y(new_n405_));
  NOR2x1_ASAP7_75t_R   g384(.A(new_n404_), .B(new_n405_), .Y(new_n406_));
  AO21x1_ASAP7_75t_R   g385(.A1(new_n27_), .A2(new_n42_), .B(p2), .Y(new_n407_));
  AO221x2_ASAP7_75t_R  g386(.A1(p2), .A2(new_n129_), .B1(new_n407_), .B2(new_n170_), .C(p1), .Y(new_n408_));
  AO21x1_ASAP7_75t_R   g387(.A1(new_n406_), .A2(new_n408_), .B(new_n31_), .Y(new_n409_));
  OA211x2_ASAP7_75t_R  g388(.A1(new_n170_), .A2(new_n261_), .B(p2), .C(new_n129_), .Y(new_n410_));
  AND2x2_ASAP7_75t_R   g389(.A(new_n282_), .B(new_n274_), .Y(new_n411_));
  OR4x2_ASAP7_75t_R    g390(.A(new_n410_), .B(p0), .C(p1), .D(new_n411_), .Y(new_n412_));
  AND2x2_ASAP7_75t_R   g391(.A(new_n42_), .B(new_n201_), .Y(new_n413_));
  OR4x2_ASAP7_75t_R    g392(.A(new_n413_), .B(p0), .C(new_n247_), .D(new_n104_), .Y(new_n414_));
  AO21x1_ASAP7_75t_R   g393(.A1(new_n30_), .A2(new_n377_), .B(new_n23_), .Y(new_n415_));
  AOI221x1_ASAP7_75t_R g394(.A1(new_n56_), .A2(new_n231_), .B1(new_n121_), .B2(p3), .C(new_n112_), .Y(new_n416_));
  OA211x2_ASAP7_75t_R  g395(.A1(new_n30_), .A2(new_n121_), .B(new_n415_), .C(new_n416_), .Y(new_n417_));
  OR3x1_ASAP7_75t_R    g396(.A(new_n333_), .B(new_n184_), .C(new_n39_), .Y(new_n418_));
  AO21x1_ASAP7_75t_R   g397(.A1(new_n23_), .A2(new_n418_), .B(new_n303_), .Y(new_n419_));
  AND5x1_ASAP7_75t_R   g398(.A(new_n409_), .B(new_n412_), .C(new_n414_), .D(new_n417_), .E(new_n419_), .Y(o9));
  AND3x1_ASAP7_75t_R   g399(.A(new_n29_), .B(p1), .C(new_n25_), .Y(new_n421_));
  NAND2x1_ASAP7_75t_R  g400(.A(p7), .B(new_n32_), .Y(new_n422_));
  AO32x1_ASAP7_75t_R   g401(.A1(new_n421_), .A2(new_n283_), .A3(new_n422_), .B1(new_n155_), .B2(new_n282_), .Y(new_n423_));
  AND3x1_ASAP7_75t_R   g402(.A(new_n423_), .B(new_n23_), .C(new_n260_), .Y(o10));
endmodule


