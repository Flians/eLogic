// Benchmark "/tmp/" written by ABC on Wed Oct 21 14:26:17 2026

module \/tmp/  ( 
    p5, p3, p4, p7, p1, p8, p0, p2, p9, p6,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10  );
  input  p5, p3, p4, p7, p1, p8, p0, p2, p9, p6;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10;
  wire new_n22_, new_n23_, new_n24_, new_n25_, new_n26_, new_n27_, new_n28_,
    new_n29_, new_n30_, new_n31_, new_n32_, new_n33_, new_n34_, new_n35_,
    new_n36_, new_n37_, new_n38_, new_n39_, new_n40_, new_n41_, new_n42_,
    new_n43_, new_n44_, new_n45_, new_n46_, new_n47_, new_n48_, new_n49_,
    new_n50_, new_n51_, new_n52_, new_n53_, new_n54_, new_n55_, new_n56_,
    new_n57_, new_n58_, new_n59_, new_n60_, new_n61_, new_n62_, new_n63_,
    new_n64_, new_n65_, new_n66_, new_n67_, new_n68_, new_n69_, new_n70_,
    new_n71_, new_n72_, new_n73_, new_n74_, new_n75_, new_n76_, new_n77_,
    new_n78_, new_n79_, new_n80_, new_n81_, new_n82_, new_n83_, new_n84_,
    new_n85_, new_n86_, new_n87_, new_n88_, new_n89_, new_n90_, new_n91_,
    new_n92_, new_n93_, new_n94_, new_n95_, new_n96_, new_n97_, new_n98_,
    new_n99_, new_n100_, new_n101_, new_n102_, new_n103_, new_n104_,
    new_n105_, new_n106_, new_n107_, new_n108_, new_n109_, new_n110_,
    new_n111_, new_n112_, new_n113_, new_n114_, new_n115_, new_n116_,
    new_n117_, new_n118_, new_n119_, new_n120_, new_n121_, new_n122_,
    new_n124_, new_n125_, new_n126_, new_n127_, new_n128_, new_n129_,
    new_n130_, new_n131_, new_n132_, new_n133_, new_n134_, new_n135_,
    new_n136_, new_n137_, new_n138_, new_n139_, new_n140_, new_n141_,
    new_n142_, new_n143_, new_n144_, new_n145_, new_n146_, new_n147_,
    new_n148_, new_n149_, new_n150_, new_n151_, new_n152_, new_n153_,
    new_n154_, new_n155_, new_n156_, new_n157_, new_n158_, new_n159_,
    new_n160_, new_n161_, new_n162_, new_n163_, new_n164_, new_n165_,
    new_n166_, new_n167_, new_n168_, new_n169_, new_n170_, new_n171_,
    new_n172_, new_n173_, new_n174_, new_n175_, new_n176_, new_n177_,
    new_n178_, new_n179_, new_n180_, new_n181_, new_n182_, new_n183_,
    new_n184_, new_n185_, new_n186_, new_n187_, new_n188_, new_n189_,
    new_n190_, new_n192_, new_n193_, new_n194_, new_n195_, new_n196_,
    new_n197_, new_n198_, new_n199_, new_n200_, new_n201_, new_n202_,
    new_n203_, new_n204_, new_n205_, new_n206_, new_n207_, new_n208_,
    new_n209_, new_n210_, new_n211_, new_n212_, new_n213_, new_n214_,
    new_n215_, new_n216_, new_n217_, new_n218_, new_n219_, new_n220_,
    new_n221_, new_n222_, new_n223_, new_n224_, new_n225_, new_n226_,
    new_n227_, new_n228_, new_n229_, new_n230_, new_n231_, new_n232_,
    new_n233_, new_n234_, new_n235_, new_n236_, new_n237_, new_n238_,
    new_n239_, new_n240_, new_n242_, new_n243_, new_n244_, new_n245_,
    new_n246_, new_n247_, new_n248_, new_n249_, new_n250_, new_n251_,
    new_n252_, new_n253_, new_n254_, new_n255_, new_n256_, new_n257_,
    new_n258_, new_n259_, new_n260_, new_n261_, new_n262_, new_n263_,
    new_n264_, new_n265_, new_n266_, new_n267_, new_n268_, new_n269_,
    new_n270_, new_n271_, new_n272_, new_n273_, new_n274_, new_n275_,
    new_n276_, new_n277_, new_n279_, new_n280_, new_n281_, new_n283_,
    new_n285_, new_n286_, new_n287_, new_n288_, new_n289_, new_n290_,
    new_n291_, new_n292_, new_n293_, new_n294_, new_n295_, new_n296_,
    new_n297_, new_n298_, new_n299_, new_n300_, new_n301_, new_n302_,
    new_n303_, new_n304_, new_n305_, new_n306_, new_n307_, new_n308_,
    new_n309_, new_n310_, new_n311_, new_n312_, new_n313_, new_n314_,
    new_n315_, new_n316_, new_n317_, new_n318_, new_n319_, new_n320_,
    new_n321_, new_n322_, new_n324_, new_n325_, new_n326_, new_n327_,
    new_n328_, new_n329_, new_n330_, new_n331_, new_n332_, new_n333_,
    new_n334_, new_n335_, new_n336_, new_n337_, new_n338_, new_n339_,
    new_n340_, new_n341_, new_n342_, new_n343_, new_n344_, new_n345_,
    new_n346_, new_n347_, new_n348_, new_n349_, new_n350_, new_n351_,
    new_n352_, new_n353_, new_n354_, new_n355_, new_n356_, new_n357_,
    new_n358_, new_n359_, new_n360_, new_n361_, new_n362_, new_n363_,
    new_n364_, new_n365_, new_n366_, new_n367_, new_n368_, new_n369_,
    new_n370_, new_n371_, new_n372_, new_n373_, new_n374_, new_n376_,
    new_n377_, new_n378_, new_n379_, new_n380_, new_n381_, new_n382_,
    new_n383_, new_n384_, new_n385_, new_n386_, new_n387_, new_n388_,
    new_n389_, new_n390_, new_n391_, new_n392_, new_n393_, new_n394_,
    new_n395_, new_n396_, new_n397_, new_n398_, new_n399_, new_n400_,
    new_n401_, new_n402_, new_n403_, new_n404_, new_n405_, new_n406_,
    new_n407_, new_n408_, new_n409_, new_n411_, new_n412_, new_n413_,
    new_n414_, new_n415_, new_n416_, new_n417_, new_n418_, new_n419_,
    new_n420_, new_n421_, new_n422_, new_n423_, new_n424_, new_n425_,
    new_n426_, new_n428_, new_n429_;
  NOR2x1_ASAP7_75t_R   g000(.A(p3), .B(p6), .Y(new_n22_));
  INVx1_ASAP7_75t_R    g001(.A(new_n22_), .Y(new_n23_));
  NAND2x1_ASAP7_75t_R  g002(.A(p1), .B(p8), .Y(new_n24_));
  NOR2x1_ASAP7_75t_R   g003(.A(p8), .B(p0), .Y(new_n25_));
  INVx1_ASAP7_75t_R    g004(.A(new_n25_), .Y(new_n26_));
  INVx1_ASAP7_75t_R    g005(.A(p2), .Y(new_n27_));
  NOR2x1_ASAP7_75t_R   g006(.A(p5), .B(new_n27_), .Y(new_n28_));
  AND2x2_ASAP7_75t_R   g007(.A(p1), .B(p2), .Y(new_n29_));
  OR3x1_ASAP7_75t_R    g008(.A(new_n26_), .B(new_n28_), .C(new_n29_), .Y(new_n30_));
  AO21x1_ASAP7_75t_R   g009(.A1(new_n24_), .A2(new_n30_), .B(p7), .Y(new_n31_));
  NOR2x1_ASAP7_75t_R   g010(.A(p7), .B(new_n27_), .Y(new_n32_));
  INVx1_ASAP7_75t_R    g011(.A(p0), .Y(new_n33_));
  NAND2x1_ASAP7_75t_R  g012(.A(p9), .B(new_n33_), .Y(new_n34_));
  INVx1_ASAP7_75t_R    g013(.A(p9), .Y(new_n35_));
  NOR2x1_ASAP7_75t_R   g014(.A(p7), .B(new_n33_), .Y(new_n36_));
  AO32x1_ASAP7_75t_R   g015(.A1(new_n26_), .A2(new_n32_), .A3(new_n34_), .B1(new_n35_), .B2(new_n36_), .Y(new_n37_));
  INVx1_ASAP7_75t_R    g016(.A(p8), .Y(new_n38_));
  NOR2x1_ASAP7_75t_R   g017(.A(p0), .B(new_n38_), .Y(new_n39_));
  INVx1_ASAP7_75t_R    g018(.A(p1), .Y(new_n40_));
  NOR2x1_ASAP7_75t_R   g019(.A(p2), .B(new_n40_), .Y(new_n41_));
  AND3x1_ASAP7_75t_R   g020(.A(new_n33_), .B(p2), .C(p9), .Y(new_n42_));
  NOR2x1_ASAP7_75t_R   g021(.A(p8), .B(new_n40_), .Y(new_n43_));
  AO32x1_ASAP7_75t_R   g022(.A1(new_n35_), .A2(new_n39_), .A3(new_n41_), .B1(new_n42_), .B2(new_n43_), .Y(new_n44_));
  NOR2x1_ASAP7_75t_R   g023(.A(new_n37_), .B(new_n44_), .Y(new_n45_));
  AOI21x1_ASAP7_75t_R  g024(.A1(new_n31_), .A2(new_n45_), .B(p4), .Y(new_n46_));
  NOR2x1_ASAP7_75t_R   g025(.A(p8), .B(new_n35_), .Y(new_n47_));
  NOR2x1_ASAP7_75t_R   g026(.A(p1), .B(new_n47_), .Y(new_n48_));
  NAND2x1_ASAP7_75t_R  g027(.A(p0), .B(new_n38_), .Y(new_n49_));
  AND2x2_ASAP7_75t_R   g028(.A(p0), .B(p9), .Y(new_n50_));
  INVx1_ASAP7_75t_R    g029(.A(new_n50_), .Y(new_n51_));
  AO21x1_ASAP7_75t_R   g030(.A1(new_n49_), .A2(new_n51_), .B(p2), .Y(new_n52_));
  AND2x2_ASAP7_75t_R   g031(.A(p4), .B(p7), .Y(new_n53_));
  OAI21x1_ASAP7_75t_R  g032(.A1(p5), .A2(new_n48_), .B(new_n53_), .Y(new_n54_));
  AO21x1_ASAP7_75t_R   g033(.A1(new_n48_), .A2(new_n52_), .B(new_n54_), .Y(new_n55_));
  NAND2x1_ASAP7_75t_R  g034(.A(p8), .B(new_n35_), .Y(new_n56_));
  NAND2x1_ASAP7_75t_R  g035(.A(p9), .B(new_n38_), .Y(new_n57_));
  AND3x1_ASAP7_75t_R   g036(.A(p4), .B(p1), .C(p0), .Y(new_n58_));
  AND3x1_ASAP7_75t_R   g037(.A(new_n56_), .B(new_n57_), .C(new_n58_), .Y(new_n59_));
  AO21x1_ASAP7_75t_R   g038(.A1(p8), .A2(new_n33_), .B(p4), .Y(new_n60_));
  INVx1_ASAP7_75t_R    g039(.A(p5), .Y(new_n61_));
  NOR2x1_ASAP7_75t_R   g040(.A(p9), .B(new_n61_), .Y(new_n62_));
  AO32x1_ASAP7_75t_R   g041(.A1(new_n60_), .A2(new_n40_), .A3(new_n62_), .B1(p5), .B2(p4), .Y(new_n63_));
  AND2x2_ASAP7_75t_R   g042(.A(p7), .B(p2), .Y(new_n64_));
  OAI21x1_ASAP7_75t_R  g043(.A1(new_n59_), .A2(new_n63_), .B(new_n64_), .Y(new_n65_));
  NOR2x1_ASAP7_75t_R   g044(.A(p1), .B(p8), .Y(new_n66_));
  AND2x2_ASAP7_75t_R   g045(.A(p1), .B(p8), .Y(new_n67_));
  NOR2x1_ASAP7_75t_R   g046(.A(new_n66_), .B(new_n67_), .Y(new_n68_));
  INVx1_ASAP7_75t_R    g047(.A(p7), .Y(new_n69_));
  OR5x1_ASAP7_75t_R    g048(.A(new_n61_), .B(new_n25_), .C(new_n69_), .D(p2), .E(p9), .Y(new_n70_));
  NAND2x1_ASAP7_75t_R  g049(.A(new_n69_), .B(new_n38_), .Y(new_n71_));
  OR3x1_ASAP7_75t_R    g050(.A(p1), .B(p0), .C(p9), .Y(new_n72_));
  OR3x1_ASAP7_75t_R    g051(.A(new_n71_), .B(p2), .C(new_n72_), .Y(new_n73_));
  OA21x2_ASAP7_75t_R   g052(.A1(new_n68_), .A2(new_n70_), .B(new_n73_), .Y(new_n74_));
  NAND3x1_ASAP7_75t_R  g053(.A(new_n55_), .B(new_n65_), .C(new_n74_), .Y(new_n75_));
  NOR2x1_ASAP7_75t_R   g054(.A(new_n46_), .B(new_n75_), .Y(new_n76_));
  INVx1_ASAP7_75t_R    g055(.A(p4), .Y(new_n77_));
  AO21x1_ASAP7_75t_R   g056(.A1(new_n77_), .A2(new_n38_), .B(p0), .Y(new_n78_));
  AND3x1_ASAP7_75t_R   g057(.A(new_n25_), .B(p1), .C(new_n35_), .Y(new_n79_));
  AO32x1_ASAP7_75t_R   g058(.A1(new_n40_), .A2(new_n78_), .A3(p9), .B1(new_n79_), .B2(p6), .Y(new_n80_));
  NAND2x1_ASAP7_75t_R  g059(.A(p7), .B(new_n77_), .Y(new_n81_));
  NOR2x1_ASAP7_75t_R   g060(.A(p4), .B(p8), .Y(new_n82_));
  INVx1_ASAP7_75t_R    g061(.A(new_n82_), .Y(new_n83_));
  NAND2x1_ASAP7_75t_R  g062(.A(p9), .B(new_n40_), .Y(new_n84_));
  AO21x1_ASAP7_75t_R   g063(.A1(p6), .A2(new_n83_), .B(new_n84_), .Y(new_n85_));
  INVx1_ASAP7_75t_R    g064(.A(p6), .Y(new_n86_));
  NOR2x1_ASAP7_75t_R   g065(.A(p8), .B(new_n33_), .Y(new_n87_));
  AO21x1_ASAP7_75t_R   g066(.A1(new_n86_), .A2(new_n87_), .B(p2), .Y(new_n88_));
  AOI21x1_ASAP7_75t_R  g067(.A1(new_n81_), .A2(new_n85_), .B(new_n88_), .Y(new_n89_));
  NAND2x1_ASAP7_75t_R  g068(.A(new_n80_), .B(new_n89_), .Y(new_n90_));
  NOR2x1_ASAP7_75t_R   g069(.A(p1), .B(p2), .Y(new_n91_));
  INVx1_ASAP7_75t_R    g070(.A(new_n91_), .Y(new_n92_));
  NOR2x1_ASAP7_75t_R   g071(.A(p2), .B(new_n33_), .Y(new_n93_));
  AOI211x1_ASAP7_75t_R g072(.A1(new_n39_), .A2(new_n92_), .B(new_n93_), .C(new_n42_), .Y(new_n94_));
  NAND2x1_ASAP7_75t_R  g073(.A(p1), .B(p0), .Y(new_n95_));
  AO21x1_ASAP7_75t_R   g074(.A1(new_n77_), .A2(new_n40_), .B(p9), .Y(new_n96_));
  AO21x1_ASAP7_75t_R   g075(.A1(new_n95_), .A2(new_n96_), .B(p8), .Y(new_n97_));
  NAND2x1_ASAP7_75t_R  g076(.A(new_n69_), .B(new_n86_), .Y(new_n98_));
  AO21x1_ASAP7_75t_R   g077(.A1(new_n94_), .A2(new_n97_), .B(new_n98_), .Y(new_n99_));
  XNOR2x2_ASAP7_75t_R  g078(.A(p8), .B(p0), .Y(new_n100_));
  NAND2x1_ASAP7_75t_R  g079(.A(new_n33_), .B(new_n35_), .Y(new_n101_));
  AND3x1_ASAP7_75t_R   g080(.A(new_n100_), .B(new_n86_), .C(new_n101_), .Y(new_n102_));
  AO21x1_ASAP7_75t_R   g081(.A1(p8), .A2(new_n35_), .B(new_n33_), .Y(new_n103_));
  NAND2x1_ASAP7_75t_R  g082(.A(p8), .B(new_n33_), .Y(new_n104_));
  NOR2x1_ASAP7_75t_R   g083(.A(p4), .B(p2), .Y(new_n105_));
  AND3x1_ASAP7_75t_R   g084(.A(new_n103_), .B(new_n104_), .C(new_n105_), .Y(new_n106_));
  NOR2x1_ASAP7_75t_R   g085(.A(p7), .B(p1), .Y(new_n107_));
  OAI21x1_ASAP7_75t_R  g086(.A1(new_n102_), .A2(new_n106_), .B(new_n107_), .Y(new_n108_));
  NAND3x1_ASAP7_75t_R  g087(.A(new_n90_), .B(new_n99_), .C(new_n108_), .Y(new_n109_));
  NOR2x1_ASAP7_75t_R   g088(.A(p5), .B(p3), .Y(new_n110_));
  AND2x2_ASAP7_75t_R   g089(.A(p5), .B(p4), .Y(new_n111_));
  NOR2x1_ASAP7_75t_R   g090(.A(p7), .B(new_n77_), .Y(new_n112_));
  NOR2x1_ASAP7_75t_R   g091(.A(p5), .B(p8), .Y(new_n113_));
  AO21x1_ASAP7_75t_R   g092(.A1(p3), .A2(p7), .B(new_n113_), .Y(new_n114_));
  OAI21x1_ASAP7_75t_R  g093(.A1(new_n111_), .A2(new_n112_), .B(new_n114_), .Y(new_n115_));
  INVx1_ASAP7_75t_R    g094(.A(p3), .Y(new_n116_));
  AO21x1_ASAP7_75t_R   g095(.A1(new_n116_), .A2(p8), .B(new_n113_), .Y(new_n117_));
  OR3x1_ASAP7_75t_R    g096(.A(new_n117_), .B(p7), .C(new_n111_), .Y(new_n118_));
  NAND2x1_ASAP7_75t_R  g097(.A(new_n115_), .B(new_n118_), .Y(new_n119_));
  OR3x1_ASAP7_75t_R    g098(.A(new_n72_), .B(p2), .C(p6), .Y(new_n120_));
  INVx1_ASAP7_75t_R    g099(.A(new_n120_), .Y(new_n121_));
  AOI22x1_ASAP7_75t_R  g100(.A1(new_n109_), .A2(new_n110_), .B1(new_n119_), .B2(new_n121_), .Y(new_n122_));
  OAI21x1_ASAP7_75t_R  g101(.A1(new_n23_), .A2(new_n76_), .B(new_n122_), .Y(o0));
  AND2x2_ASAP7_75t_R   g102(.A(p7), .B(p1), .Y(new_n124_));
  NOR2x1_ASAP7_75t_R   g103(.A(p4), .B(new_n69_), .Y(new_n125_));
  NOR2x1_ASAP7_75t_R   g104(.A(p5), .B(p7), .Y(new_n126_));
  AO221x2_ASAP7_75t_R  g105(.A1(new_n77_), .A2(new_n124_), .B1(new_n62_), .B2(new_n125_), .C(new_n126_), .Y(new_n127_));
  AO21x1_ASAP7_75t_R   g106(.A1(p5), .A2(p7), .B(new_n84_), .Y(new_n128_));
  OA21x2_ASAP7_75t_R   g107(.A1(new_n61_), .A2(new_n38_), .B(new_n81_), .Y(new_n129_));
  NOR2x1_ASAP7_75t_R   g108(.A(p1), .B(new_n38_), .Y(new_n130_));
  NAND2x1_ASAP7_75t_R  g109(.A(new_n112_), .B(new_n130_), .Y(new_n131_));
  OAI22x1_ASAP7_75t_R  g110(.A1(new_n128_), .A2(new_n129_), .B1(p9), .B2(new_n131_), .Y(new_n132_));
  AO22x1_ASAP7_75t_R   g111(.A1(new_n87_), .A2(new_n127_), .B1(p0), .B2(new_n132_), .Y(new_n133_));
  NOR2x1_ASAP7_75t_R   g112(.A(p8), .B(p9), .Y(new_n134_));
  NAND2x1_ASAP7_75t_R  g113(.A(p4), .B(p1), .Y(new_n135_));
  INVx1_ASAP7_75t_R    g114(.A(new_n135_), .Y(new_n136_));
  AND3x1_ASAP7_75t_R   g115(.A(p7), .B(p8), .C(p9), .Y(new_n137_));
  AO32x1_ASAP7_75t_R   g116(.A1(p4), .A2(new_n134_), .A3(new_n107_), .B1(new_n136_), .B2(new_n137_), .Y(new_n138_));
  NAND2x1_ASAP7_75t_R  g117(.A(p7), .B(p8), .Y(new_n139_));
  INVx1_ASAP7_75t_R    g118(.A(new_n139_), .Y(new_n140_));
  NOR2x1_ASAP7_75t_R   g119(.A(p7), .B(p8), .Y(new_n141_));
  AOI22x1_ASAP7_75t_R  g120(.A1(new_n140_), .A2(p5), .B1(new_n77_), .B2(new_n141_), .Y(new_n142_));
  OAI21x1_ASAP7_75t_R  g121(.A1(p9), .A2(new_n129_), .B(new_n142_), .Y(new_n143_));
  NOR2x1_ASAP7_75t_R   g122(.A(p0), .B(new_n40_), .Y(new_n144_));
  AND3x1_ASAP7_75t_R   g123(.A(new_n113_), .B(p7), .C(p1), .Y(new_n145_));
  AO221x2_ASAP7_75t_R  g124(.A1(new_n33_), .A2(new_n138_), .B1(new_n143_), .B2(new_n144_), .C(new_n145_), .Y(new_n146_));
  AND3x1_ASAP7_75t_R   g125(.A(new_n116_), .B(new_n27_), .C(new_n86_), .Y(new_n147_));
  OAI21x1_ASAP7_75t_R  g126(.A1(new_n133_), .A2(new_n146_), .B(new_n147_), .Y(new_n148_));
  AO21x1_ASAP7_75t_R   g127(.A1(p7), .A2(p2), .B(p1), .Y(new_n149_));
  AND3x1_ASAP7_75t_R   g128(.A(new_n107_), .B(p4), .C(new_n33_), .Y(new_n150_));
  AOI21x1_ASAP7_75t_R  g129(.A1(new_n35_), .A2(new_n149_), .B(new_n150_), .Y(new_n151_));
  OR3x1_ASAP7_75t_R    g130(.A(new_n69_), .B(new_n35_), .C(p1), .Y(new_n152_));
  NAND2x1_ASAP7_75t_R  g131(.A(p4), .B(new_n35_), .Y(new_n153_));
  NAND2x1_ASAP7_75t_R  g132(.A(p9), .B(new_n77_), .Y(new_n154_));
  AND2x2_ASAP7_75t_R   g133(.A(new_n153_), .B(new_n154_), .Y(new_n155_));
  AO21x1_ASAP7_75t_R   g134(.A1(new_n152_), .A2(new_n155_), .B(new_n33_), .Y(new_n156_));
  AO21x1_ASAP7_75t_R   g135(.A1(new_n151_), .A2(new_n156_), .B(p5), .Y(new_n157_));
  NOR2x1_ASAP7_75t_R   g136(.A(p0), .B(new_n27_), .Y(new_n158_));
  NOR2x1_ASAP7_75t_R   g137(.A(p7), .B(p0), .Y(new_n159_));
  INVx1_ASAP7_75t_R    g138(.A(new_n159_), .Y(new_n160_));
  NOR2x1_ASAP7_75t_R   g139(.A(p1), .B(new_n27_), .Y(new_n161_));
  AO32x1_ASAP7_75t_R   g140(.A1(new_n158_), .A2(p5), .A3(p7), .B1(new_n160_), .B2(new_n161_), .Y(new_n162_));
  NOR2x1_ASAP7_75t_R   g141(.A(p7), .B(p2), .Y(new_n163_));
  OR4x2_ASAP7_75t_R    g142(.A(new_n125_), .B(new_n34_), .C(p5), .D(new_n163_), .Y(new_n164_));
  NOR2x1_ASAP7_75t_R   g143(.A(p9), .B(new_n69_), .Y(new_n165_));
  NOR2x1_ASAP7_75t_R   g144(.A(p5), .B(p0), .Y(new_n166_));
  OR5x1_ASAP7_75t_R    g145(.A(p4), .B(new_n165_), .C(p1), .D(new_n50_), .E(new_n166_), .Y(new_n167_));
  NAND2x1_ASAP7_75t_R  g146(.A(new_n164_), .B(new_n167_), .Y(new_n168_));
  AOI211x1_ASAP7_75t_R g147(.A1(new_n77_), .A2(new_n162_), .B(p8), .C(new_n168_), .Y(new_n169_));
  NOR2x1_ASAP7_75t_R   g148(.A(p1), .B(p0), .Y(new_n170_));
  AO32x1_ASAP7_75t_R   g149(.A1(new_n170_), .A2(new_n69_), .A3(p2), .B1(p4), .B2(p0), .Y(new_n171_));
  AND2x2_ASAP7_75t_R   g150(.A(p5), .B(p9), .Y(new_n172_));
  AOI211x1_ASAP7_75t_R g151(.A1(new_n77_), .A2(new_n95_), .B(new_n91_), .C(new_n105_), .Y(new_n173_));
  AO21x1_ASAP7_75t_R   g152(.A1(new_n58_), .A2(new_n32_), .B(new_n38_), .Y(new_n174_));
  AO221x2_ASAP7_75t_R  g153(.A1(new_n171_), .A2(new_n172_), .B1(new_n173_), .B2(p5), .C(new_n174_), .Y(new_n175_));
  NAND2x1_ASAP7_75t_R  g154(.A(new_n22_), .B(new_n175_), .Y(new_n176_));
  AO21x1_ASAP7_75t_R   g155(.A1(new_n157_), .A2(new_n169_), .B(new_n176_), .Y(new_n177_));
  NOR2x1_ASAP7_75t_R   g156(.A(p0), .B(p9), .Y(new_n178_));
  NOR2x1_ASAP7_75t_R   g157(.A(new_n40_), .B(new_n178_), .Y(new_n179_));
  OR3x1_ASAP7_75t_R    g158(.A(new_n179_), .B(p7), .C(new_n86_), .Y(new_n180_));
  AOI21x1_ASAP7_75t_R  g159(.A1(new_n48_), .A2(new_n51_), .B(new_n180_), .Y(new_n181_));
  NOR2x1_ASAP7_75t_R   g160(.A(p1), .B(new_n69_), .Y(new_n182_));
  AND3x1_ASAP7_75t_R   g161(.A(new_n87_), .B(new_n182_), .C(p6), .Y(new_n183_));
  OR3x1_ASAP7_75t_R    g162(.A(new_n181_), .B(new_n79_), .C(new_n183_), .Y(new_n184_));
  NAND2x1_ASAP7_75t_R  g163(.A(new_n105_), .B(new_n110_), .Y(new_n185_));
  INVx1_ASAP7_75t_R    g164(.A(new_n185_), .Y(new_n186_));
  AO21x1_ASAP7_75t_R   g165(.A1(p3), .A2(p7), .B(new_n112_), .Y(new_n187_));
  AND3x1_ASAP7_75t_R   g166(.A(p5), .B(p3), .C(p8), .Y(new_n188_));
  AO21x1_ASAP7_75t_R   g167(.A1(new_n113_), .A2(new_n187_), .B(new_n188_), .Y(new_n189_));
  AOI22x1_ASAP7_75t_R  g168(.A1(new_n184_), .A2(new_n186_), .B1(new_n121_), .B2(new_n189_), .Y(new_n190_));
  NAND3x1_ASAP7_75t_R  g169(.A(new_n148_), .B(new_n177_), .C(new_n190_), .Y(o1));
  AND2x2_ASAP7_75t_R   g170(.A(p5), .B(p1), .Y(new_n192_));
  AO21x1_ASAP7_75t_R   g171(.A1(p1), .A2(new_n69_), .B(new_n33_), .Y(new_n193_));
  AND2x2_ASAP7_75t_R   g172(.A(p4), .B(new_n149_), .Y(new_n194_));
  OAI21x1_ASAP7_75t_R  g173(.A1(new_n192_), .A2(new_n193_), .B(new_n194_), .Y(new_n195_));
  NAND2x1_ASAP7_75t_R  g174(.A(p2), .B(new_n69_), .Y(new_n196_));
  AO21x1_ASAP7_75t_R   g175(.A1(p2), .A2(new_n38_), .B(p5), .Y(new_n197_));
  AO21x1_ASAP7_75t_R   g176(.A1(new_n196_), .A2(new_n49_), .B(new_n197_), .Y(new_n198_));
  AND3x1_ASAP7_75t_R   g177(.A(new_n195_), .B(new_n116_), .C(new_n198_), .Y(new_n199_));
  OR3x1_ASAP7_75t_R    g178(.A(new_n69_), .B(new_n33_), .C(p8), .Y(new_n200_));
  OA21x2_ASAP7_75t_R   g179(.A1(p5), .A2(p8), .B(new_n200_), .Y(new_n201_));
  AO21x1_ASAP7_75t_R   g180(.A1(new_n32_), .A2(new_n39_), .B(new_n161_), .Y(new_n202_));
  NAND2x1_ASAP7_75t_R  g181(.A(p5), .B(new_n69_), .Y(new_n203_));
  NOR3x1_ASAP7_75t_R   g182(.A(new_n87_), .B(new_n203_), .C(p2), .Y(new_n204_));
  AOI22x1_ASAP7_75t_R  g183(.A1(new_n201_), .A2(new_n202_), .B1(new_n78_), .B2(new_n204_), .Y(new_n205_));
  OR3x1_ASAP7_75t_R    g184(.A(new_n32_), .B(new_n77_), .C(new_n29_), .Y(new_n206_));
  AND2x2_ASAP7_75t_R   g185(.A(p4), .B(p2), .Y(new_n207_));
  OR3x1_ASAP7_75t_R    g186(.A(new_n161_), .B(new_n69_), .C(new_n207_), .Y(new_n208_));
  AO21x1_ASAP7_75t_R   g187(.A1(new_n206_), .A2(new_n208_), .B(new_n49_), .Y(new_n209_));
  NAND3x1_ASAP7_75t_R  g188(.A(new_n199_), .B(new_n205_), .C(new_n209_), .Y(new_n210_));
  OA21x2_ASAP7_75t_R   g189(.A1(p0), .A2(new_n92_), .B(p3), .Y(new_n211_));
  AO21x1_ASAP7_75t_R   g190(.A1(p5), .A2(new_n69_), .B(p9), .Y(new_n212_));
  AO21x1_ASAP7_75t_R   g191(.A1(p3), .A2(new_n77_), .B(p9), .Y(new_n213_));
  OA21x2_ASAP7_75t_R   g192(.A1(new_n140_), .A2(new_n212_), .B(new_n213_), .Y(new_n214_));
  NOR2x1_ASAP7_75t_R   g193(.A(new_n211_), .B(new_n214_), .Y(new_n215_));
  AND2x2_ASAP7_75t_R   g194(.A(p8), .B(p0), .Y(new_n216_));
  AND2x2_ASAP7_75t_R   g195(.A(p4), .B(p0), .Y(new_n217_));
  AO21x1_ASAP7_75t_R   g196(.A1(p1), .A2(new_n216_), .B(new_n217_), .Y(new_n218_));
  OR3x1_ASAP7_75t_R    g197(.A(new_n137_), .B(new_n77_), .C(new_n141_), .Y(new_n219_));
  OA211x2_ASAP7_75t_R  g198(.A1(p7), .A2(new_n49_), .B(p1), .C(new_n139_), .Y(new_n220_));
  AOI21x1_ASAP7_75t_R  g199(.A1(new_n218_), .A2(new_n219_), .B(new_n220_), .Y(new_n221_));
  AND3x1_ASAP7_75t_R   g200(.A(new_n92_), .B(new_n140_), .C(new_n33_), .Y(new_n222_));
  OA211x2_ASAP7_75t_R  g201(.A1(new_n77_), .A2(new_n158_), .B(new_n40_), .C(new_n141_), .Y(new_n223_));
  NOR2x1_ASAP7_75t_R   g202(.A(new_n222_), .B(new_n223_), .Y(new_n224_));
  OAI22x1_ASAP7_75t_R  g203(.A1(new_n221_), .A2(p2), .B1(new_n224_), .B2(new_n35_), .Y(new_n225_));
  AOI22x1_ASAP7_75t_R  g204(.A1(new_n210_), .A2(new_n215_), .B1(new_n110_), .B2(new_n225_), .Y(new_n226_));
  AO21x1_ASAP7_75t_R   g205(.A1(p8), .A2(new_n33_), .B(new_n61_), .Y(new_n227_));
  NAND2x1_ASAP7_75t_R  g206(.A(new_n163_), .B(new_n100_), .Y(new_n228_));
  OA211x2_ASAP7_75t_R  g207(.A1(new_n69_), .A2(new_n227_), .B(new_n228_), .C(new_n200_), .Y(new_n229_));
  OR3x1_ASAP7_75t_R    g208(.A(new_n154_), .B(p3), .C(p6), .Y(new_n230_));
  OA21x2_ASAP7_75t_R   g209(.A1(new_n86_), .A2(new_n139_), .B(p9), .Y(new_n231_));
  OA22x2_ASAP7_75t_R   g210(.A1(new_n231_), .A2(new_n103_), .B1(new_n57_), .B2(new_n160_), .Y(new_n232_));
  OAI22x1_ASAP7_75t_R  g211(.A1(new_n229_), .A2(new_n230_), .B1(new_n185_), .B2(new_n232_), .Y(new_n233_));
  AOI22x1_ASAP7_75t_R  g212(.A1(new_n216_), .A2(p1), .B1(p7), .B2(new_n33_), .Y(new_n234_));
  NOR2x1_ASAP7_75t_R   g213(.A(new_n141_), .B(new_n140_), .Y(new_n235_));
  AO21x1_ASAP7_75t_R   g214(.A1(p1), .A2(new_n235_), .B(new_n107_), .Y(new_n236_));
  OAI21x1_ASAP7_75t_R  g215(.A1(new_n61_), .A2(new_n234_), .B(new_n236_), .Y(new_n237_));
  INVx1_ASAP7_75t_R    g216(.A(new_n154_), .Y(new_n238_));
  AND3x1_ASAP7_75t_R   g217(.A(new_n238_), .B(p2), .C(new_n22_), .Y(new_n239_));
  AOI22x1_ASAP7_75t_R  g218(.A1(new_n233_), .A2(new_n40_), .B1(new_n237_), .B2(new_n239_), .Y(new_n240_));
  OAI21x1_ASAP7_75t_R  g219(.A1(p6), .A2(new_n226_), .B(new_n240_), .Y(o2));
  AOI211x1_ASAP7_75t_R g220(.A1(new_n27_), .A2(new_n203_), .B(new_n111_), .C(new_n112_), .Y(new_n242_));
  AND3x1_ASAP7_75t_R   g221(.A(new_n141_), .B(new_n77_), .C(p1), .Y(new_n243_));
  NOR2x1_ASAP7_75t_R   g222(.A(p5), .B(new_n40_), .Y(new_n244_));
  AND3x1_ASAP7_75t_R   g223(.A(new_n244_), .B(p8), .C(new_n53_), .Y(new_n245_));
  OR3x1_ASAP7_75t_R    g224(.A(new_n242_), .B(new_n243_), .C(new_n245_), .Y(new_n246_));
  AO32x1_ASAP7_75t_R   g225(.A1(new_n197_), .A2(new_n33_), .A3(new_n92_), .B1(new_n77_), .B2(new_n192_), .Y(new_n247_));
  AO21x1_ASAP7_75t_R   g226(.A1(p0), .A2(new_n246_), .B(new_n247_), .Y(new_n248_));
  NOR2x1_ASAP7_75t_R   g227(.A(p5), .B(p4), .Y(new_n249_));
  AND3x1_ASAP7_75t_R   g228(.A(new_n170_), .B(p3), .C(new_n27_), .Y(new_n250_));
  AO21x1_ASAP7_75t_R   g229(.A1(p7), .A2(p8), .B(p4), .Y(new_n251_));
  OA211x2_ASAP7_75t_R  g230(.A1(new_n111_), .A2(new_n249_), .B(new_n250_), .C(new_n251_), .Y(new_n252_));
  AOI21x1_ASAP7_75t_R  g231(.A1(new_n116_), .A2(new_n248_), .B(new_n252_), .Y(new_n253_));
  NAND2x1_ASAP7_75t_R  g232(.A(new_n35_), .B(new_n86_), .Y(new_n254_));
  NAND2x1_ASAP7_75t_R  g233(.A(p2), .B(new_n61_), .Y(new_n255_));
  AO21x1_ASAP7_75t_R   g234(.A1(p7), .A2(new_n24_), .B(new_n255_), .Y(new_n256_));
  AO21x1_ASAP7_75t_R   g235(.A1(new_n40_), .A2(new_n27_), .B(new_n38_), .Y(new_n257_));
  NAND2x1_ASAP7_75t_R  g236(.A(p5), .B(new_n77_), .Y(new_n258_));
  AO21x1_ASAP7_75t_R   g237(.A1(new_n71_), .A2(new_n257_), .B(new_n258_), .Y(new_n259_));
  NAND2x1_ASAP7_75t_R  g238(.A(new_n256_), .B(new_n259_), .Y(new_n260_));
  OR3x1_ASAP7_75t_R    g239(.A(new_n69_), .B(new_n40_), .C(p4), .Y(new_n261_));
  NAND2x1_ASAP7_75t_R  g240(.A(p4), .B(p7), .Y(new_n262_));
  NAND2x1_ASAP7_75t_R  g241(.A(p1), .B(new_n27_), .Y(new_n263_));
  AO21x1_ASAP7_75t_R   g242(.A1(new_n262_), .A2(new_n263_), .B(new_n124_), .Y(new_n264_));
  AOI21x1_ASAP7_75t_R  g243(.A1(new_n261_), .A2(new_n264_), .B(p8), .Y(new_n265_));
  NAND2x1_ASAP7_75t_R  g244(.A(p2), .B(new_n77_), .Y(new_n266_));
  OA21x2_ASAP7_75t_R   g245(.A1(p5), .A2(new_n32_), .B(new_n266_), .Y(new_n267_));
  AO21x1_ASAP7_75t_R   g246(.A1(new_n112_), .A2(new_n130_), .B(new_n161_), .Y(new_n268_));
  OR3x1_ASAP7_75t_R    g247(.A(new_n265_), .B(new_n267_), .C(new_n268_), .Y(new_n269_));
  AO21x1_ASAP7_75t_R   g248(.A1(new_n61_), .A2(new_n77_), .B(new_n113_), .Y(new_n270_));
  OA211x2_ASAP7_75t_R  g249(.A1(new_n53_), .A2(new_n216_), .B(new_n270_), .C(p2), .Y(new_n271_));
  AO21x1_ASAP7_75t_R   g250(.A1(new_n61_), .A2(new_n69_), .B(new_n82_), .Y(new_n272_));
  AO32x1_ASAP7_75t_R   g251(.A1(p5), .A2(new_n87_), .A3(new_n125_), .B1(new_n272_), .B2(new_n161_), .Y(new_n273_));
  AO21x1_ASAP7_75t_R   g252(.A1(new_n77_), .A2(new_n27_), .B(new_n61_), .Y(new_n274_));
  OA211x2_ASAP7_75t_R  g253(.A1(p5), .A2(new_n150_), .B(new_n274_), .C(new_n47_), .Y(new_n275_));
  OR3x1_ASAP7_75t_R    g254(.A(new_n271_), .B(new_n273_), .C(new_n275_), .Y(new_n276_));
  AOI221x1_ASAP7_75t_R g255(.A1(new_n33_), .A2(new_n260_), .B1(new_n269_), .B2(new_n50_), .C(new_n276_), .Y(new_n277_));
  OAI22x1_ASAP7_75t_R  g256(.A1(new_n253_), .A2(new_n254_), .B1(new_n277_), .B2(new_n23_), .Y(o3));
  AND3x1_ASAP7_75t_R   g257(.A(new_n178_), .B(new_n91_), .C(p3), .Y(new_n279_));
  AND3x1_ASAP7_75t_R   g258(.A(new_n178_), .B(new_n40_), .C(p2), .Y(new_n280_));
  OA21x2_ASAP7_75t_R   g259(.A1(new_n179_), .A2(new_n280_), .B(new_n116_), .Y(new_n281_));
  OA211x2_ASAP7_75t_R  g260(.A1(new_n279_), .A2(new_n281_), .B(new_n86_), .C(new_n111_), .Y(o4));
  AND3x1_ASAP7_75t_R   g261(.A(new_n72_), .B(new_n116_), .C(p2), .Y(new_n283_));
  OA211x2_ASAP7_75t_R  g262(.A1(new_n279_), .A2(new_n283_), .B(new_n86_), .C(new_n111_), .Y(o5));
  NOR2x1_ASAP7_75t_R   g263(.A(p3), .B(p2), .Y(new_n285_));
  INVx1_ASAP7_75t_R    g264(.A(new_n56_), .Y(new_n286_));
  AND3x1_ASAP7_75t_R   g265(.A(new_n83_), .B(new_n35_), .C(new_n124_), .Y(new_n287_));
  AOI221x1_ASAP7_75t_R g266(.A1(new_n25_), .A2(new_n112_), .B1(new_n286_), .B2(new_n136_), .C(new_n287_), .Y(new_n288_));
  NOR2x1_ASAP7_75t_R   g267(.A(new_n107_), .B(new_n124_), .Y(new_n289_));
  OR3x1_ASAP7_75t_R    g268(.A(new_n235_), .B(new_n289_), .C(new_n61_), .Y(new_n290_));
  AND2x2_ASAP7_75t_R   g269(.A(p7), .B(p9), .Y(new_n291_));
  AO32x1_ASAP7_75t_R   g270(.A1(new_n95_), .A2(new_n113_), .A3(new_n135_), .B1(new_n217_), .B2(p8), .Y(new_n292_));
  NAND2x1_ASAP7_75t_R  g271(.A(new_n291_), .B(new_n292_), .Y(new_n293_));
  AND3x1_ASAP7_75t_R   g272(.A(new_n288_), .B(new_n290_), .C(new_n293_), .Y(new_n294_));
  AO21x1_ASAP7_75t_R   g273(.A1(p6), .A2(new_n38_), .B(new_n69_), .Y(new_n295_));
  AOI22x1_ASAP7_75t_R  g274(.A1(new_n295_), .A2(new_n144_), .B1(p0), .B2(new_n66_), .Y(new_n296_));
  NOR2x1_ASAP7_75t_R   g275(.A(p9), .B(new_n296_), .Y(new_n297_));
  AO21x1_ASAP7_75t_R   g276(.A1(new_n69_), .A2(new_n38_), .B(p0), .Y(new_n298_));
  AND3x1_ASAP7_75t_R   g277(.A(new_n298_), .B(new_n40_), .C(p6), .Y(new_n299_));
  OA21x2_ASAP7_75t_R   g278(.A1(new_n141_), .A2(new_n137_), .B(new_n299_), .Y(new_n300_));
  OAI21x1_ASAP7_75t_R  g279(.A1(new_n297_), .A2(new_n300_), .B(new_n249_), .Y(new_n301_));
  OAI21x1_ASAP7_75t_R  g280(.A1(p6), .A2(new_n294_), .B(new_n301_), .Y(new_n302_));
  OA21x2_ASAP7_75t_R   g281(.A1(new_n111_), .A2(new_n279_), .B(new_n86_), .Y(new_n303_));
  AO32x1_ASAP7_75t_R   g282(.A1(new_n212_), .A2(new_n262_), .A3(new_n66_), .B1(new_n67_), .B2(new_n165_), .Y(new_n304_));
  AO21x1_ASAP7_75t_R   g283(.A1(p1), .A2(new_n77_), .B(p5), .Y(new_n305_));
  NOR2x1_ASAP7_75t_R   g284(.A(p1), .B(new_n77_), .Y(new_n306_));
  AND3x1_ASAP7_75t_R   g285(.A(new_n56_), .B(new_n306_), .C(new_n57_), .Y(new_n307_));
  AO21x1_ASAP7_75t_R   g286(.A1(new_n286_), .A2(new_n305_), .B(new_n307_), .Y(new_n308_));
  OA21x2_ASAP7_75t_R   g287(.A1(p7), .A2(p8), .B(p1), .Y(new_n309_));
  OA211x2_ASAP7_75t_R  g288(.A1(new_n137_), .A2(new_n309_), .B(p5), .C(p0), .Y(new_n310_));
  AOI221x1_ASAP7_75t_R g289(.A1(new_n33_), .A2(new_n304_), .B1(new_n308_), .B2(new_n36_), .C(new_n310_), .Y(new_n311_));
  NAND2x1_ASAP7_75t_R  g290(.A(p1), .B(new_n35_), .Y(new_n312_));
  AOI22x1_ASAP7_75t_R  g291(.A1(new_n36_), .A2(new_n312_), .B1(new_n182_), .B2(new_n172_), .Y(new_n313_));
  NOR2x1_ASAP7_75t_R   g292(.A(p7), .B(p9), .Y(new_n314_));
  OR3x1_ASAP7_75t_R    g293(.A(new_n238_), .B(new_n49_), .C(new_n314_), .Y(new_n315_));
  OAI21x1_ASAP7_75t_R  g294(.A1(new_n38_), .A2(new_n313_), .B(new_n315_), .Y(new_n316_));
  AND3x1_ASAP7_75t_R   g295(.A(new_n298_), .B(p9), .C(new_n49_), .Y(new_n317_));
  OA21x2_ASAP7_75t_R   g296(.A1(p5), .A2(p9), .B(new_n95_), .Y(new_n318_));
  NOR3x1_ASAP7_75t_R   g297(.A(new_n318_), .B(new_n159_), .C(new_n100_), .Y(new_n319_));
  OA21x2_ASAP7_75t_R   g298(.A1(new_n317_), .A2(new_n319_), .B(new_n77_), .Y(new_n320_));
  OAI21x1_ASAP7_75t_R  g299(.A1(new_n316_), .A2(new_n320_), .B(p2), .Y(new_n321_));
  AOI21x1_ASAP7_75t_R  g300(.A1(new_n311_), .A2(new_n321_), .B(new_n23_), .Y(new_n322_));
  AOI211x1_ASAP7_75t_R g301(.A1(new_n285_), .A2(new_n302_), .B(new_n303_), .C(new_n322_), .Y(o6));
  OR3x1_ASAP7_75t_R    g302(.A(new_n140_), .B(new_n312_), .C(new_n141_), .Y(new_n324_));
  OR3x1_ASAP7_75t_R    g303(.A(new_n152_), .B(p8), .C(new_n86_), .Y(new_n325_));
  OR4x2_ASAP7_75t_R    g304(.A(p5), .B(p4), .C(p0), .D(p2), .Y(new_n326_));
  AOI21x1_ASAP7_75t_R  g305(.A1(new_n324_), .A2(new_n325_), .B(new_n326_), .Y(new_n327_));
  OA21x2_ASAP7_75t_R   g306(.A1(new_n86_), .A2(new_n327_), .B(new_n116_), .Y(new_n328_));
  AO21x1_ASAP7_75t_R   g307(.A1(p7), .A2(p8), .B(p5), .Y(new_n329_));
  AOI211x1_ASAP7_75t_R g308(.A1(new_n38_), .A2(p9), .B(p1), .C(new_n329_), .Y(new_n330_));
  NAND2x1_ASAP7_75t_R  g309(.A(p5), .B(new_n35_), .Y(new_n331_));
  AOI21x1_ASAP7_75t_R  g310(.A1(new_n139_), .A2(new_n71_), .B(new_n331_), .Y(new_n332_));
  OAI21x1_ASAP7_75t_R  g311(.A1(new_n330_), .A2(new_n332_), .B(new_n158_), .Y(new_n333_));
  OAI21x1_ASAP7_75t_R  g312(.A1(p5), .A2(new_n163_), .B(new_n309_), .Y(new_n334_));
  NOR3x1_ASAP7_75t_R   g313(.A(p7), .B(p1), .C(p9), .Y(new_n335_));
  AND3x1_ASAP7_75t_R   g314(.A(p5), .B(p7), .C(p9), .Y(new_n336_));
  OAI21x1_ASAP7_75t_R  g315(.A1(new_n335_), .A2(new_n336_), .B(new_n38_), .Y(new_n337_));
  AO21x1_ASAP7_75t_R   g316(.A1(new_n334_), .A2(new_n337_), .B(p0), .Y(new_n338_));
  OR5x1_ASAP7_75t_R    g317(.A(new_n61_), .B(new_n27_), .C(p7), .D(p1), .E(p8), .Y(new_n339_));
  NAND3x1_ASAP7_75t_R  g318(.A(new_n333_), .B(new_n338_), .C(new_n339_), .Y(new_n340_));
  NAND2x1_ASAP7_75t_R  g319(.A(p7), .B(new_n35_), .Y(new_n341_));
  OAI21x1_ASAP7_75t_R  g320(.A1(new_n255_), .A2(new_n341_), .B(new_n203_), .Y(new_n342_));
  AO21x1_ASAP7_75t_R   g321(.A1(p2), .A2(new_n139_), .B(new_n291_), .Y(new_n343_));
  AOI22x1_ASAP7_75t_R  g322(.A1(new_n342_), .A2(new_n130_), .B1(new_n244_), .B2(new_n343_), .Y(new_n344_));
  AO21x1_ASAP7_75t_R   g323(.A1(p5), .A2(p8), .B(p7), .Y(new_n345_));
  AOI21x1_ASAP7_75t_R  g324(.A1(p9), .A2(new_n27_), .B(p5), .Y(new_n346_));
  OAI21x1_ASAP7_75t_R  g325(.A1(p9), .A2(new_n38_), .B(new_n40_), .Y(new_n347_));
  NOR2x1_ASAP7_75t_R   g326(.A(new_n346_), .B(new_n347_), .Y(new_n348_));
  NAND2x1_ASAP7_75t_R  g327(.A(new_n113_), .B(new_n163_), .Y(new_n349_));
  OAI21x1_ASAP7_75t_R  g328(.A1(new_n263_), .A2(new_n139_), .B(new_n349_), .Y(new_n350_));
  AOI21x1_ASAP7_75t_R  g329(.A1(new_n345_), .A2(new_n348_), .B(new_n350_), .Y(new_n351_));
  AOI21x1_ASAP7_75t_R  g330(.A1(new_n344_), .A2(new_n351_), .B(new_n33_), .Y(new_n352_));
  NOR2x1_ASAP7_75t_R   g331(.A(new_n340_), .B(new_n352_), .Y(new_n353_));
  AOI22x1_ASAP7_75t_R  g332(.A1(p7), .A2(p8), .B1(p1), .B2(p2), .Y(new_n354_));
  OAI21x1_ASAP7_75t_R  g333(.A1(p7), .A2(p8), .B(new_n354_), .Y(new_n355_));
  AOI21x1_ASAP7_75t_R  g334(.A1(p2), .A2(p9), .B(p1), .Y(new_n356_));
  NOR3x1_ASAP7_75t_R   g335(.A(new_n356_), .B(new_n77_), .C(p0), .Y(new_n357_));
  AND5x1_ASAP7_75t_R   g336(.A(p1), .B(new_n141_), .C(new_n33_), .D(p2), .E(p9), .Y(new_n358_));
  AND3x1_ASAP7_75t_R   g337(.A(new_n67_), .B(new_n53_), .C(p2), .Y(new_n359_));
  AOI211x1_ASAP7_75t_R g338(.A1(new_n355_), .A2(new_n357_), .B(new_n358_), .C(new_n359_), .Y(new_n360_));
  AOI21x1_ASAP7_75t_R  g339(.A1(new_n33_), .A2(new_n360_), .B(p5), .Y(new_n361_));
  OA21x2_ASAP7_75t_R   g340(.A1(p1), .A2(p8), .B(p9), .Y(new_n362_));
  NAND3x1_ASAP7_75t_R  g341(.A(new_n362_), .B(p7), .C(new_n24_), .Y(new_n363_));
  OR3x1_ASAP7_75t_R    g342(.A(new_n24_), .B(new_n77_), .C(p7), .Y(new_n364_));
  NAND3x1_ASAP7_75t_R  g343(.A(new_n134_), .B(p4), .C(p7), .Y(new_n365_));
  AO31x2_ASAP7_75t_R   g344(.A1(new_n363_), .A2(new_n364_), .A3(new_n365_), .B(p2), .Y(new_n366_));
  AO21x1_ASAP7_75t_R   g345(.A1(p1), .A2(new_n38_), .B(new_n207_), .Y(new_n367_));
  AND2x2_ASAP7_75t_R   g346(.A(p2), .B(new_n139_), .Y(new_n368_));
  AOI22x1_ASAP7_75t_R  g347(.A1(new_n367_), .A2(new_n314_), .B1(new_n306_), .B2(new_n368_), .Y(new_n369_));
  NAND3x1_ASAP7_75t_R  g348(.A(new_n366_), .B(new_n360_), .C(new_n369_), .Y(new_n370_));
  AOI21x1_ASAP7_75t_R  g349(.A1(new_n361_), .A2(new_n370_), .B(new_n327_), .Y(new_n371_));
  OAI21x1_ASAP7_75t_R  g350(.A1(p4), .A2(new_n353_), .B(new_n371_), .Y(new_n372_));
  AND3x1_ASAP7_75t_R   g351(.A(new_n61_), .B(new_n77_), .C(new_n86_), .Y(new_n373_));
  AND2x2_ASAP7_75t_R   g352(.A(new_n373_), .B(new_n279_), .Y(new_n374_));
  AOI21x1_ASAP7_75t_R  g353(.A1(new_n328_), .A2(new_n372_), .B(new_n374_), .Y(o7));
  AO21x1_ASAP7_75t_R   g354(.A1(p7), .A2(p9), .B(new_n64_), .Y(new_n376_));
  NAND2x1_ASAP7_75t_R  g355(.A(p4), .B(p0), .Y(new_n377_));
  AND3x1_ASAP7_75t_R   g356(.A(new_n266_), .B(new_n40_), .C(new_n377_), .Y(new_n378_));
  NOR2x1_ASAP7_75t_R   g357(.A(p0), .B(new_n35_), .Y(new_n379_));
  AND3x1_ASAP7_75t_R   g358(.A(new_n379_), .B(p7), .C(new_n105_), .Y(new_n380_));
  AOI21x1_ASAP7_75t_R  g359(.A1(new_n376_), .A2(new_n378_), .B(new_n380_), .Y(new_n381_));
  AO21x1_ASAP7_75t_R   g360(.A1(p4), .A2(p2), .B(new_n95_), .Y(new_n382_));
  NOR2x1_ASAP7_75t_R   g361(.A(p4), .B(new_n165_), .Y(new_n383_));
  OA21x2_ASAP7_75t_R   g362(.A1(new_n382_), .A2(new_n383_), .B(new_n38_), .Y(new_n384_));
  AO21x1_ASAP7_75t_R   g363(.A1(new_n77_), .A2(p1), .B(new_n207_), .Y(new_n385_));
  OA21x2_ASAP7_75t_R   g364(.A1(new_n27_), .A2(new_n182_), .B(p0), .Y(new_n386_));
  AND3x1_ASAP7_75t_R   g365(.A(new_n153_), .B(new_n170_), .C(new_n64_), .Y(new_n387_));
  AOI21x1_ASAP7_75t_R  g366(.A1(new_n385_), .A2(new_n386_), .B(new_n387_), .Y(new_n388_));
  AOI221x1_ASAP7_75t_R g367(.A1(new_n381_), .A2(new_n384_), .B1(new_n388_), .B2(p8), .C(p5), .Y(new_n389_));
  AO21x1_ASAP7_75t_R   g368(.A1(new_n33_), .A2(new_n71_), .B(new_n35_), .Y(new_n390_));
  NOR2x1_ASAP7_75t_R   g369(.A(p5), .B(new_n36_), .Y(new_n391_));
  AO21x1_ASAP7_75t_R   g370(.A1(new_n49_), .A2(new_n165_), .B(new_n227_), .Y(new_n392_));
  AOI221x1_ASAP7_75t_R g371(.A1(new_n390_), .A2(new_n391_), .B1(new_n392_), .B2(new_n40_), .C(new_n266_), .Y(new_n393_));
  NAND2x1_ASAP7_75t_R  g372(.A(p8), .B(new_n27_), .Y(new_n394_));
  AND5x1_ASAP7_75t_R   g373(.A(new_n40_), .B(new_n26_), .C(new_n266_), .D(new_n394_), .E(new_n377_), .Y(new_n395_));
  AND3x1_ASAP7_75t_R   g374(.A(new_n27_), .B(p8), .C(p0), .Y(new_n396_));
  AND3x1_ASAP7_75t_R   g375(.A(new_n25_), .B(p4), .C(new_n40_), .Y(new_n397_));
  OA21x2_ASAP7_75t_R   g376(.A1(new_n396_), .A2(new_n397_), .B(new_n35_), .Y(new_n398_));
  AO32x1_ASAP7_75t_R   g377(.A1(p1), .A2(new_n33_), .A3(new_n105_), .B1(new_n100_), .B2(new_n41_), .Y(new_n399_));
  OA31x2_ASAP7_75t_R   g378(.A1(new_n395_), .A2(new_n398_), .A3(new_n399_), .B1(new_n126_), .Y(new_n400_));
  OR3x1_ASAP7_75t_R    g379(.A(new_n389_), .B(new_n393_), .C(new_n400_), .Y(new_n401_));
  OR3x1_ASAP7_75t_R    g380(.A(new_n120_), .B(new_n116_), .C(p4), .Y(new_n402_));
  NAND2x1_ASAP7_75t_R  g381(.A(new_n216_), .B(new_n335_), .Y(new_n403_));
  NAND2x1_ASAP7_75t_R  g382(.A(new_n314_), .B(new_n67_), .Y(new_n404_));
  OA21x2_ASAP7_75t_R   g383(.A1(p8), .A2(new_n152_), .B(new_n404_), .Y(new_n405_));
  OR3x1_ASAP7_75t_R    g384(.A(new_n289_), .B(p8), .C(p9), .Y(new_n406_));
  AO21x1_ASAP7_75t_R   g385(.A1(new_n405_), .A2(new_n406_), .B(p0), .Y(new_n407_));
  AO21x1_ASAP7_75t_R   g386(.A1(new_n403_), .A2(new_n407_), .B(new_n185_), .Y(new_n408_));
  NAND2x1_ASAP7_75t_R  g387(.A(new_n402_), .B(new_n408_), .Y(new_n409_));
  AOI21x1_ASAP7_75t_R  g388(.A1(new_n22_), .A2(new_n401_), .B(new_n409_), .Y(o8));
  AO21x1_ASAP7_75t_R   g389(.A1(new_n38_), .A2(p2), .B(new_n28_), .Y(new_n411_));
  OAI21x1_ASAP7_75t_R  g390(.A1(new_n341_), .A2(new_n270_), .B(new_n411_), .Y(new_n412_));
  OR3x1_ASAP7_75t_R    g391(.A(new_n249_), .B(new_n116_), .C(p2), .Y(new_n413_));
  AO32x1_ASAP7_75t_R   g392(.A1(new_n27_), .A2(new_n251_), .A3(new_n309_), .B1(new_n413_), .B2(new_n40_), .Y(new_n414_));
  NAND2x1_ASAP7_75t_R  g393(.A(new_n412_), .B(new_n414_), .Y(new_n415_));
  OA21x2_ASAP7_75t_R   g394(.A1(p2), .A2(new_n82_), .B(new_n341_), .Y(new_n416_));
  OR3x1_ASAP7_75t_R    g395(.A(new_n411_), .B(new_n416_), .C(p1), .Y(new_n417_));
  OR3x1_ASAP7_75t_R    g396(.A(new_n40_), .B(new_n27_), .C(p5), .Y(new_n418_));
  OR3x1_ASAP7_75t_R    g397(.A(new_n270_), .B(p2), .C(new_n126_), .Y(new_n419_));
  OA21x2_ASAP7_75t_R   g398(.A1(new_n418_), .A2(new_n251_), .B(new_n419_), .Y(new_n420_));
  AO21x1_ASAP7_75t_R   g399(.A1(new_n417_), .A2(new_n420_), .B(new_n33_), .Y(new_n421_));
  OAI21x1_ASAP7_75t_R  g400(.A1(new_n154_), .A2(new_n418_), .B(new_n86_), .Y(new_n422_));
  AO221x2_ASAP7_75t_R  g401(.A1(new_n379_), .A2(new_n91_), .B1(p5), .B2(new_n41_), .C(new_n111_), .Y(new_n423_));
  OA21x2_ASAP7_75t_R   g402(.A1(p9), .A2(new_n263_), .B(p6), .Y(new_n424_));
  OR3x1_ASAP7_75t_R    g403(.A(new_n423_), .B(new_n211_), .C(new_n424_), .Y(new_n425_));
  AOI21x1_ASAP7_75t_R  g404(.A1(new_n298_), .A2(new_n422_), .B(new_n425_), .Y(new_n426_));
  OA211x2_ASAP7_75t_R  g405(.A1(p0), .A2(new_n415_), .B(new_n421_), .C(new_n426_), .Y(o9));
  AO21x1_ASAP7_75t_R   g406(.A1(p0), .A2(new_n56_), .B(new_n69_), .Y(new_n428_));
  AND5x1_ASAP7_75t_R   g407(.A(new_n116_), .B(new_n428_), .C(p2), .D(new_n104_), .E(new_n179_), .Y(new_n429_));
  AO21x1_ASAP7_75t_R   g408(.A1(new_n373_), .A2(new_n429_), .B(new_n374_), .Y(o10));
endmodule


