// Benchmark "/tmp/" written by ABC on Wed Oct 21 14:43:51 2026

module \/tmp/  ( 
    p1, p5, p7, p9, p6, p2, p3, p10, p4, p8, p0,
    o0, o1, o2, o3, o4, o5, o6  );
  input  p1, p5, p7, p9, p6, p2, p3, p10, p4, p8, p0;
  output o0, o1, o2, o3, o4, o5, o6;
  wire new_n19_, new_n20_, new_n21_, new_n22_, new_n23_, new_n24_, new_n25_,
    new_n26_, new_n27_, new_n28_, new_n29_, new_n30_, new_n31_, new_n32_,
    new_n33_, new_n34_, new_n35_, new_n36_, new_n37_, new_n38_, new_n39_,
    new_n40_, new_n41_, new_n42_, new_n43_, new_n44_, new_n45_, new_n46_,
    new_n47_, new_n48_, new_n49_, new_n50_, new_n51_, new_n52_, new_n53_,
    new_n54_, new_n55_, new_n56_, new_n57_, new_n58_, new_n59_, new_n60_,
    new_n61_, new_n62_, new_n63_, new_n64_, new_n66_, new_n67_, new_n68_,
    new_n69_, new_n70_, new_n71_, new_n72_, new_n73_, new_n74_, new_n75_,
    new_n76_, new_n77_, new_n78_, new_n79_, new_n80_, new_n81_, new_n82_,
    new_n83_, new_n84_, new_n85_, new_n86_, new_n87_, new_n88_, new_n89_,
    new_n90_, new_n91_, new_n92_, new_n93_, new_n94_, new_n95_, new_n96_,
    new_n97_, new_n98_, new_n99_, new_n100_, new_n101_, new_n102_,
    new_n103_, new_n104_, new_n105_, new_n106_, new_n108_, new_n109_,
    new_n110_, new_n111_, new_n112_, new_n113_, new_n114_, new_n115_,
    new_n116_, new_n117_, new_n118_, new_n119_, new_n120_, new_n121_,
    new_n122_, new_n123_, new_n124_, new_n125_, new_n126_, new_n127_,
    new_n128_, new_n129_, new_n130_, new_n131_, new_n132_, new_n133_,
    new_n134_, new_n135_, new_n136_, new_n137_, new_n138_, new_n140_,
    new_n141_, new_n143_, new_n144_, new_n145_, new_n146_, new_n147_,
    new_n148_, new_n149_, new_n150_, new_n151_, new_n152_, new_n153_,
    new_n154_, new_n156_, new_n157_, new_n158_, new_n159_, new_n160_;
  INVx1_ASAP7_75t_R    g000(.A(p3), .Y(new_n19_));
  INVx1_ASAP7_75t_R    g001(.A(p4), .Y(new_n20_));
  AO21x1_ASAP7_75t_R   g002(.A1(p7), .A2(new_n19_), .B(new_n20_), .Y(new_n21_));
  INVx1_ASAP7_75t_R    g003(.A(p10), .Y(new_n22_));
  NAND2x1_ASAP7_75t_R  g004(.A(p3), .B(p0), .Y(new_n23_));
  AOI211x1_ASAP7_75t_R g005(.A1(new_n22_), .A2(new_n23_), .B(p5), .C(p6), .Y(new_n24_));
  NAND2x1_ASAP7_75t_R  g006(.A(p7), .B(new_n19_), .Y(new_n25_));
  AO21x1_ASAP7_75t_R   g007(.A1(new_n23_), .A2(new_n25_), .B(new_n22_), .Y(new_n26_));
  AO21x1_ASAP7_75t_R   g008(.A1(p7), .A2(p3), .B(p4), .Y(new_n27_));
  AO21x1_ASAP7_75t_R   g009(.A1(new_n24_), .A2(new_n26_), .B(new_n27_), .Y(new_n28_));
  INVx1_ASAP7_75t_R    g010(.A(p6), .Y(new_n29_));
  NOR2x1_ASAP7_75t_R   g011(.A(p3), .B(new_n29_), .Y(new_n30_));
  NOR2x1_ASAP7_75t_R   g012(.A(p1), .B(p6), .Y(new_n31_));
  AND3x1_ASAP7_75t_R   g013(.A(new_n31_), .B(p4), .C(p0), .Y(new_n32_));
  NOR2x1_ASAP7_75t_R   g014(.A(new_n30_), .B(new_n32_), .Y(new_n33_));
  INVx1_ASAP7_75t_R    g015(.A(p7), .Y(new_n34_));
  NAND2x1_ASAP7_75t_R  g016(.A(p2), .B(new_n34_), .Y(new_n35_));
  OR3x1_ASAP7_75t_R    g017(.A(new_n29_), .B(new_n19_), .C(p2), .Y(new_n36_));
  OAI22x1_ASAP7_75t_R  g018(.A1(new_n33_), .A2(new_n35_), .B1(p7), .B2(new_n36_), .Y(new_n37_));
  AOI21x1_ASAP7_75t_R  g019(.A1(new_n21_), .A2(new_n28_), .B(new_n37_), .Y(new_n38_));
  NOR2x1_ASAP7_75t_R   g020(.A(p9), .B(p8), .Y(new_n39_));
  INVx1_ASAP7_75t_R    g021(.A(new_n39_), .Y(new_n40_));
  INVx1_ASAP7_75t_R    g022(.A(p9), .Y(new_n41_));
  NOR2x1_ASAP7_75t_R   g023(.A(p5), .B(new_n20_), .Y(new_n42_));
  INVx1_ASAP7_75t_R    g024(.A(new_n42_), .Y(new_n43_));
  INVx1_ASAP7_75t_R    g025(.A(p0), .Y(new_n44_));
  AND2x2_ASAP7_75t_R   g026(.A(p7), .B(p3), .Y(new_n45_));
  AND2x2_ASAP7_75t_R   g027(.A(p2), .B(p3), .Y(new_n46_));
  OR5x1_ASAP7_75t_R    g028(.A(p1), .B(new_n30_), .C(new_n44_), .D(new_n45_), .E(new_n46_), .Y(new_n47_));
  NOR2x1_ASAP7_75t_R   g029(.A(p7), .B(p6), .Y(new_n48_));
  AO31x2_ASAP7_75t_R   g030(.A1(new_n48_), .A2(p1), .A3(new_n44_), .B(p8), .Y(new_n49_));
  AND3x1_ASAP7_75t_R   g031(.A(new_n20_), .B(p5), .C(p8), .Y(new_n50_));
  AOI21x1_ASAP7_75t_R  g032(.A1(new_n42_), .A2(new_n49_), .B(new_n50_), .Y(new_n51_));
  OAI21x1_ASAP7_75t_R  g033(.A1(new_n43_), .A2(new_n47_), .B(new_n51_), .Y(new_n52_));
  NAND2x1_ASAP7_75t_R  g034(.A(p1), .B(p2), .Y(new_n53_));
  INVx1_ASAP7_75t_R    g035(.A(p1), .Y(new_n54_));
  INVx1_ASAP7_75t_R    g036(.A(p2), .Y(new_n55_));
  NAND2x1_ASAP7_75t_R  g037(.A(new_n54_), .B(new_n55_), .Y(new_n56_));
  AO21x1_ASAP7_75t_R   g038(.A1(new_n53_), .A2(new_n56_), .B(p9), .Y(new_n57_));
  NOR2x1_ASAP7_75t_R   g039(.A(p7), .B(p8), .Y(new_n58_));
  OA21x2_ASAP7_75t_R   g040(.A1(p9), .A2(new_n58_), .B(new_n29_), .Y(new_n59_));
  INVx1_ASAP7_75t_R    g041(.A(p5), .Y(new_n60_));
  AND3x1_ASAP7_75t_R   g042(.A(p5), .B(p7), .C(p8), .Y(new_n61_));
  AO21x1_ASAP7_75t_R   g043(.A1(new_n60_), .A2(p6), .B(new_n61_), .Y(new_n62_));
  AO32x1_ASAP7_75t_R   g044(.A1(new_n57_), .A2(p5), .A3(new_n59_), .B1(p9), .B2(new_n62_), .Y(new_n63_));
  AOI21x1_ASAP7_75t_R  g045(.A1(new_n41_), .A2(new_n52_), .B(new_n63_), .Y(new_n64_));
  OAI21x1_ASAP7_75t_R  g046(.A1(new_n38_), .A2(new_n40_), .B(new_n64_), .Y(o0));
  AO21x1_ASAP7_75t_R   g047(.A1(p5), .A2(p6), .B(p7), .Y(new_n66_));
  AO21x1_ASAP7_75t_R   g048(.A1(new_n41_), .A2(p6), .B(new_n66_), .Y(new_n67_));
  NOR3x1_ASAP7_75t_R   g049(.A(new_n60_), .B(p3), .C(p8), .Y(new_n68_));
  AND3x1_ASAP7_75t_R   g050(.A(new_n60_), .B(new_n55_), .C(p4), .Y(new_n69_));
  OAI21x1_ASAP7_75t_R  g051(.A1(new_n68_), .A2(new_n69_), .B(new_n54_), .Y(new_n70_));
  NOR3x1_ASAP7_75t_R   g052(.A(new_n20_), .B(p5), .C(p0), .Y(new_n71_));
  OAI21x1_ASAP7_75t_R  g053(.A1(new_n68_), .A2(new_n71_), .B(new_n55_), .Y(new_n72_));
  NAND2x1_ASAP7_75t_R  g054(.A(p2), .B(p3), .Y(new_n73_));
  NAND2x1_ASAP7_75t_R  g055(.A(p1), .B(p5), .Y(new_n74_));
  OR3x1_ASAP7_75t_R    g056(.A(new_n73_), .B(new_n74_), .C(p8), .Y(new_n75_));
  AND4x2_ASAP7_75t_R   g057(.A(new_n70_), .B(new_n72_), .C(new_n41_), .D(new_n75_), .Y(new_n76_));
  AND2x2_ASAP7_75t_R   g058(.A(p5), .B(p6), .Y(new_n77_));
  INVx1_ASAP7_75t_R    g059(.A(new_n77_), .Y(new_n78_));
  NAND2x1_ASAP7_75t_R  g060(.A(p7), .B(p9), .Y(new_n79_));
  OR3x1_ASAP7_75t_R    g061(.A(new_n78_), .B(new_n79_), .C(p8), .Y(new_n80_));
  OAI21x1_ASAP7_75t_R  g062(.A1(new_n67_), .A2(new_n76_), .B(new_n80_), .Y(new_n81_));
  NOR2x1_ASAP7_75t_R   g063(.A(p3), .B(p8), .Y(new_n82_));
  AO21x1_ASAP7_75t_R   g064(.A1(new_n29_), .A2(p8), .B(new_n82_), .Y(new_n83_));
  AND2x2_ASAP7_75t_R   g065(.A(p5), .B(p4), .Y(new_n84_));
  AOI211x1_ASAP7_75t_R g066(.A1(new_n29_), .A2(p8), .B(new_n82_), .C(new_n84_), .Y(new_n85_));
  AOI211x1_ASAP7_75t_R g067(.A1(p5), .A2(new_n83_), .B(new_n58_), .C(new_n85_), .Y(new_n86_));
  AOI21x1_ASAP7_75t_R  g068(.A1(p2), .A2(p3), .B(new_n29_), .Y(new_n87_));
  INVx1_ASAP7_75t_R    g069(.A(p8), .Y(new_n88_));
  NOR2x1_ASAP7_75t_R   g070(.A(p6), .B(new_n88_), .Y(new_n89_));
  AOI21x1_ASAP7_75t_R  g071(.A1(new_n58_), .A2(new_n87_), .B(new_n89_), .Y(new_n90_));
  NOR3x1_ASAP7_75t_R   g072(.A(p5), .B(p6), .C(p3), .Y(new_n91_));
  NOR3x1_ASAP7_75t_R   g073(.A(new_n19_), .B(p7), .C(p8), .Y(new_n92_));
  NAND2x1_ASAP7_75t_R  g074(.A(p1), .B(p0), .Y(new_n93_));
  NAND2x1_ASAP7_75t_R  g075(.A(p2), .B(p4), .Y(new_n94_));
  AOI21x1_ASAP7_75t_R  g076(.A1(new_n29_), .A2(new_n93_), .B(new_n94_), .Y(new_n95_));
  OAI21x1_ASAP7_75t_R  g077(.A1(new_n91_), .A2(new_n92_), .B(new_n95_), .Y(new_n96_));
  OAI21x1_ASAP7_75t_R  g078(.A1(p4), .A2(new_n90_), .B(new_n96_), .Y(new_n97_));
  OAI22x1_ASAP7_75t_R  g079(.A1(p1), .A2(p6), .B1(p3), .B2(p8), .Y(new_n98_));
  AOI22x1_ASAP7_75t_R  g080(.A1(new_n98_), .A2(new_n44_), .B1(p7), .B2(new_n88_), .Y(new_n99_));
  NAND2x1_ASAP7_75t_R  g081(.A(p10), .B(new_n93_), .Y(new_n100_));
  NAND2x1_ASAP7_75t_R  g082(.A(p1), .B(new_n22_), .Y(new_n101_));
  NOR2x1_ASAP7_75t_R   g083(.A(p6), .B(new_n19_), .Y(new_n102_));
  NAND3x1_ASAP7_75t_R  g084(.A(new_n100_), .B(new_n101_), .C(new_n102_), .Y(new_n103_));
  NAND2x1_ASAP7_75t_R  g085(.A(new_n60_), .B(new_n20_), .Y(new_n104_));
  AOI21x1_ASAP7_75t_R  g086(.A1(new_n99_), .A2(new_n103_), .B(new_n104_), .Y(new_n105_));
  OA31x2_ASAP7_75t_R   g087(.A1(new_n86_), .A2(new_n97_), .A3(new_n105_), .B1(new_n41_), .Y(new_n106_));
  NOR2x1_ASAP7_75t_R   g088(.A(new_n81_), .B(new_n106_), .Y(o1));
  OR3x1_ASAP7_75t_R    g089(.A(p7), .B(p9), .C(p8), .Y(new_n108_));
  NOR2x1_ASAP7_75t_R   g090(.A(p2), .B(new_n20_), .Y(new_n109_));
  AND3x1_ASAP7_75t_R   g091(.A(new_n54_), .B(new_n60_), .C(p2), .Y(new_n110_));
  OAI21x1_ASAP7_75t_R  g092(.A1(new_n109_), .A2(new_n110_), .B(p3), .Y(new_n111_));
  AOI21x1_ASAP7_75t_R  g093(.A1(new_n54_), .A2(new_n111_), .B(p6), .Y(new_n112_));
  NOR2x1_ASAP7_75t_R   g094(.A(p3), .B(new_n94_), .Y(new_n113_));
  AND4x2_ASAP7_75t_R   g095(.A(new_n60_), .B(new_n55_), .C(p3), .D(p10), .Y(new_n114_));
  OAI21x1_ASAP7_75t_R  g096(.A1(new_n113_), .A2(new_n114_), .B(p0), .Y(new_n115_));
  NAND2x1_ASAP7_75t_R  g097(.A(p10), .B(p0), .Y(new_n116_));
  NOR2x1_ASAP7_75t_R   g098(.A(p4), .B(new_n73_), .Y(new_n117_));
  AND3x1_ASAP7_75t_R   g099(.A(new_n60_), .B(new_n19_), .C(new_n20_), .Y(new_n118_));
  AOI21x1_ASAP7_75t_R  g100(.A1(new_n116_), .A2(new_n117_), .B(new_n118_), .Y(new_n119_));
  NAND3x1_ASAP7_75t_R  g101(.A(new_n115_), .B(new_n119_), .C(new_n111_), .Y(new_n120_));
  OAI21x1_ASAP7_75t_R  g102(.A1(new_n20_), .A2(p0), .B(new_n74_), .Y(new_n121_));
  NAND2x1_ASAP7_75t_R  g103(.A(p5), .B(p4), .Y(new_n122_));
  AND3x1_ASAP7_75t_R   g104(.A(new_n121_), .B(new_n46_), .C(new_n122_), .Y(new_n123_));
  AO21x1_ASAP7_75t_R   g105(.A1(new_n73_), .A2(new_n84_), .B(new_n123_), .Y(new_n124_));
  AOI21x1_ASAP7_75t_R  g106(.A1(new_n112_), .A2(new_n120_), .B(new_n124_), .Y(new_n125_));
  NOR2x1_ASAP7_75t_R   g107(.A(p5), .B(new_n29_), .Y(new_n126_));
  AO21x1_ASAP7_75t_R   g108(.A1(new_n84_), .A2(new_n102_), .B(new_n126_), .Y(new_n127_));
  NOR2x1_ASAP7_75t_R   g109(.A(p9), .B(new_n34_), .Y(new_n128_));
  AND2x2_ASAP7_75t_R   g110(.A(p3), .B(p4), .Y(new_n129_));
  AOI22x1_ASAP7_75t_R  g111(.A1(new_n126_), .A2(p2), .B1(p5), .B2(new_n31_), .Y(new_n130_));
  NOR2x1_ASAP7_75t_R   g112(.A(new_n77_), .B(new_n129_), .Y(new_n131_));
  AOI21x1_ASAP7_75t_R  g113(.A1(new_n129_), .A2(new_n130_), .B(new_n131_), .Y(new_n132_));
  NAND2x1_ASAP7_75t_R  g114(.A(p4), .B(p8), .Y(new_n133_));
  OA21x2_ASAP7_75t_R   g115(.A1(p7), .A2(new_n133_), .B(new_n79_), .Y(new_n134_));
  AO21x1_ASAP7_75t_R   g116(.A1(p6), .A2(p4), .B(new_n34_), .Y(new_n135_));
  AO21x1_ASAP7_75t_R   g117(.A1(new_n41_), .A2(new_n135_), .B(new_n88_), .Y(new_n136_));
  OAI21x1_ASAP7_75t_R  g118(.A1(new_n78_), .A2(new_n134_), .B(new_n136_), .Y(new_n137_));
  AOI221x1_ASAP7_75t_R g119(.A1(new_n127_), .A2(new_n128_), .B1(new_n39_), .B2(new_n132_), .C(new_n137_), .Y(new_n138_));
  OAI21x1_ASAP7_75t_R  g120(.A1(new_n108_), .A2(new_n125_), .B(new_n138_), .Y(o2));
  AND5x1_ASAP7_75t_R   g121(.A(new_n54_), .B(new_n84_), .C(p7), .D(p6), .E(p3), .Y(new_n140_));
  AOI21x1_ASAP7_75t_R  g122(.A1(new_n48_), .A2(new_n118_), .B(new_n140_), .Y(new_n141_));
  OR3x1_ASAP7_75t_R    g123(.A(new_n141_), .B(p2), .C(new_n40_), .Y(o3));
  OR3x1_ASAP7_75t_R    g124(.A(new_n122_), .B(p6), .C(new_n19_), .Y(new_n143_));
  OA21x2_ASAP7_75t_R   g125(.A1(new_n104_), .A2(new_n116_), .B(new_n143_), .Y(new_n144_));
  OR3x1_ASAP7_75t_R    g126(.A(new_n144_), .B(p7), .C(new_n53_), .Y(new_n145_));
  NOR2x1_ASAP7_75t_R   g127(.A(p6), .B(new_n93_), .Y(new_n146_));
  OA21x2_ASAP7_75t_R   g128(.A1(new_n84_), .A2(new_n146_), .B(new_n46_), .Y(new_n147_));
  AND3x1_ASAP7_75t_R   g129(.A(new_n29_), .B(new_n20_), .C(p3), .Y(new_n148_));
  AO21x1_ASAP7_75t_R   g130(.A1(p5), .A2(new_n29_), .B(p7), .Y(new_n149_));
  OR3x1_ASAP7_75t_R    g131(.A(new_n147_), .B(new_n148_), .C(new_n149_), .Y(new_n150_));
  AND5x1_ASAP7_75t_R   g132(.A(new_n88_), .B(new_n56_), .C(new_n35_), .D(new_n77_), .E(new_n129_), .Y(new_n151_));
  AND3x1_ASAP7_75t_R   g133(.A(new_n84_), .B(p7), .C(p6), .Y(new_n152_));
  NOR2x1_ASAP7_75t_R   g134(.A(new_n88_), .B(new_n152_), .Y(new_n153_));
  NOR2x1_ASAP7_75t_R   g135(.A(new_n151_), .B(new_n153_), .Y(new_n154_));
  AO31x2_ASAP7_75t_R   g136(.A1(new_n145_), .A2(new_n150_), .A3(new_n154_), .B(p9), .Y(o4));
  OR3x1_ASAP7_75t_R    g137(.A(new_n73_), .B(new_n122_), .C(new_n54_), .Y(new_n156_));
  AND2x2_ASAP7_75t_R   g138(.A(new_n48_), .B(new_n104_), .Y(new_n157_));
  OR3x1_ASAP7_75t_R    g139(.A(new_n53_), .B(p6), .C(p4), .Y(new_n158_));
  NOR2x1_ASAP7_75t_R   g140(.A(new_n116_), .B(new_n158_), .Y(new_n159_));
  AO22x1_ASAP7_75t_R   g141(.A1(new_n56_), .A2(new_n152_), .B1(new_n34_), .B2(new_n159_), .Y(new_n160_));
  AO221x2_ASAP7_75t_R  g142(.A1(new_n156_), .A2(new_n157_), .B1(new_n160_), .B2(p3), .C(new_n40_), .Y(o5));
  NAND3x1_ASAP7_75t_R  g143(.A(new_n156_), .B(new_n39_), .C(new_n48_), .Y(o6));
endmodule


