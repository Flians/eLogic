// Benchmark "/tmp/" written by ABC on Wed Oct 21 14:43:51 2026

module \/tmp/  ( 
    p10, p8, p3, p6, p2, p5, p9, p4, p1, p0, p7,
    o0, o1, o2, o3, o4, o5, o6  );
  input  p10, p8, p3, p6, p2, p5, p9, p4, p1, p0, p7;
  output o0, o1, o2, o3, o4, o5, o6;
  wire new_n19_, new_n20_, new_n21_, new_n22_, new_n23_, new_n24_, new_n25_,
    new_n26_, new_n27_, new_n28_, new_n29_, new_n30_, new_n31_, new_n32_,
    new_n33_, new_n34_, new_n35_, new_n36_, new_n37_, new_n38_, new_n39_,
    new_n40_, new_n41_, new_n42_, new_n43_, new_n44_, new_n45_, new_n46_,
    new_n47_, new_n48_, new_n49_, new_n50_, new_n51_, new_n52_, new_n53_,
    new_n54_, new_n55_, new_n56_, new_n57_, new_n58_, new_n59_, new_n60_,
    new_n61_, new_n62_, new_n63_, new_n64_, new_n65_, new_n67_, new_n68_,
    new_n69_, new_n70_, new_n71_, new_n72_, new_n73_, new_n74_, new_n75_,
    new_n76_, new_n77_, new_n78_, new_n79_, new_n80_, new_n81_, new_n82_,
    new_n83_, new_n84_, new_n85_, new_n86_, new_n87_, new_n88_, new_n89_,
    new_n90_, new_n91_, new_n92_, new_n93_, new_n94_, new_n95_, new_n96_,
    new_n97_, new_n98_, new_n99_, new_n100_, new_n101_, new_n102_,
    new_n103_, new_n104_, new_n105_, new_n106_, new_n108_, new_n109_,
    new_n110_, new_n111_, new_n112_, new_n113_, new_n114_, new_n115_,
    new_n116_, new_n117_, new_n118_, new_n119_, new_n120_, new_n121_,
    new_n122_, new_n123_, new_n124_, new_n125_, new_n126_, new_n127_,
    new_n128_, new_n129_, new_n130_, new_n131_, new_n132_, new_n133_,
    new_n134_, new_n136_, new_n137_, new_n138_, new_n140_, new_n141_,
    new_n142_, new_n143_, new_n144_, new_n145_, new_n146_, new_n147_,
    new_n148_, new_n149_, new_n151_, new_n152_, new_n153_, new_n154_,
    new_n155_, new_n156_, new_n157_;
  INVx1_ASAP7_75t_R    g000(.A(p10), .Y(new_n19_));
  NAND2x1_ASAP7_75t_R  g001(.A(p3), .B(p0), .Y(new_n20_));
  AOI211x1_ASAP7_75t_R g002(.A1(new_n19_), .A2(new_n20_), .B(p6), .C(p5), .Y(new_n21_));
  INVx1_ASAP7_75t_R    g003(.A(p3), .Y(new_n22_));
  NAND2x1_ASAP7_75t_R  g004(.A(p7), .B(new_n22_), .Y(new_n23_));
  AO21x1_ASAP7_75t_R   g005(.A1(new_n20_), .A2(new_n23_), .B(new_n19_), .Y(new_n24_));
  AND2x2_ASAP7_75t_R   g006(.A(p3), .B(p7), .Y(new_n25_));
  AO21x1_ASAP7_75t_R   g007(.A1(new_n21_), .A2(new_n24_), .B(new_n25_), .Y(new_n26_));
  INVx1_ASAP7_75t_R    g008(.A(p4), .Y(new_n27_));
  INVx1_ASAP7_75t_R    g009(.A(p6), .Y(new_n28_));
  INVx1_ASAP7_75t_R    g010(.A(p1), .Y(new_n29_));
  AND5x1_ASAP7_75t_R   g011(.A(new_n28_), .B(new_n29_), .C(p2), .D(p4), .E(p0), .Y(new_n30_));
  INVx1_ASAP7_75t_R    g012(.A(p2), .Y(new_n31_));
  AND3x1_ASAP7_75t_R   g013(.A(new_n31_), .B(p3), .C(p6), .Y(new_n32_));
  AND3x1_ASAP7_75t_R   g014(.A(new_n22_), .B(p6), .C(p2), .Y(new_n33_));
  OR4x2_ASAP7_75t_R    g015(.A(new_n30_), .B(p7), .C(new_n32_), .D(new_n33_), .Y(new_n34_));
  INVx1_ASAP7_75t_R    g016(.A(p7), .Y(new_n35_));
  AO21x1_ASAP7_75t_R   g017(.A1(p4), .A2(new_n22_), .B(new_n35_), .Y(new_n36_));
  AOI22x1_ASAP7_75t_R  g018(.A1(new_n26_), .A2(new_n27_), .B1(new_n34_), .B2(new_n36_), .Y(new_n37_));
  NOR2x1_ASAP7_75t_R   g019(.A(p8), .B(p9), .Y(new_n38_));
  INVx1_ASAP7_75t_R    g020(.A(new_n38_), .Y(new_n39_));
  INVx1_ASAP7_75t_R    g021(.A(p9), .Y(new_n40_));
  NOR2x1_ASAP7_75t_R   g022(.A(p5), .B(new_n27_), .Y(new_n41_));
  NOR2x1_ASAP7_75t_R   g023(.A(p6), .B(p7), .Y(new_n42_));
  INVx1_ASAP7_75t_R    g024(.A(p0), .Y(new_n43_));
  AO31x2_ASAP7_75t_R   g025(.A1(new_n42_), .A2(p1), .A3(new_n43_), .B(p8), .Y(new_n44_));
  AND3x1_ASAP7_75t_R   g026(.A(new_n27_), .B(p8), .C(p5), .Y(new_n45_));
  AOI21x1_ASAP7_75t_R  g027(.A1(new_n41_), .A2(new_n44_), .B(new_n45_), .Y(new_n46_));
  NOR2x1_ASAP7_75t_R   g028(.A(p3), .B(new_n28_), .Y(new_n47_));
  NAND2x1_ASAP7_75t_R  g029(.A(p0), .B(new_n29_), .Y(new_n48_));
  INVx1_ASAP7_75t_R    g030(.A(p5), .Y(new_n49_));
  NAND2x1_ASAP7_75t_R  g031(.A(p4), .B(new_n49_), .Y(new_n50_));
  AND2x2_ASAP7_75t_R   g032(.A(p3), .B(p2), .Y(new_n51_));
  OR5x1_ASAP7_75t_R    g033(.A(new_n25_), .B(new_n47_), .C(new_n48_), .D(new_n50_), .E(new_n51_), .Y(new_n52_));
  NAND2x1_ASAP7_75t_R  g034(.A(new_n46_), .B(new_n52_), .Y(new_n53_));
  NAND2x1_ASAP7_75t_R  g035(.A(p5), .B(new_n28_), .Y(new_n54_));
  NOR2x1_ASAP7_75t_R   g036(.A(p2), .B(p1), .Y(new_n55_));
  NAND2x1_ASAP7_75t_R  g037(.A(p2), .B(p1), .Y(new_n56_));
  NOR2x1_ASAP7_75t_R   g038(.A(p8), .B(p7), .Y(new_n57_));
  NAND2x1_ASAP7_75t_R  g039(.A(new_n56_), .B(new_n57_), .Y(new_n58_));
  OA21x2_ASAP7_75t_R   g040(.A1(new_n55_), .A2(new_n58_), .B(new_n40_), .Y(new_n59_));
  NAND2x1_ASAP7_75t_R  g041(.A(p6), .B(new_n49_), .Y(new_n60_));
  INVx1_ASAP7_75t_R    g042(.A(p8), .Y(new_n61_));
  OR3x1_ASAP7_75t_R    g043(.A(new_n61_), .B(new_n49_), .C(new_n35_), .Y(new_n62_));
  AO21x1_ASAP7_75t_R   g044(.A1(new_n60_), .A2(new_n62_), .B(new_n40_), .Y(new_n63_));
  OAI21x1_ASAP7_75t_R  g045(.A1(new_n54_), .A2(new_n59_), .B(new_n63_), .Y(new_n64_));
  AOI21x1_ASAP7_75t_R  g046(.A1(new_n40_), .A2(new_n53_), .B(new_n64_), .Y(new_n65_));
  OAI21x1_ASAP7_75t_R  g047(.A1(new_n37_), .A2(new_n39_), .B(new_n65_), .Y(o0));
  AO21x1_ASAP7_75t_R   g048(.A1(p6), .A2(p5), .B(p7), .Y(new_n67_));
  AO21x1_ASAP7_75t_R   g049(.A1(p6), .A2(new_n40_), .B(new_n67_), .Y(new_n68_));
  NOR3x1_ASAP7_75t_R   g050(.A(new_n49_), .B(p8), .C(p3), .Y(new_n69_));
  NOR3x1_ASAP7_75t_R   g051(.A(new_n27_), .B(p5), .C(p0), .Y(new_n70_));
  OAI21x1_ASAP7_75t_R  g052(.A1(new_n69_), .A2(new_n70_), .B(new_n31_), .Y(new_n71_));
  NAND2x1_ASAP7_75t_R  g053(.A(p3), .B(p2), .Y(new_n72_));
  OR4x2_ASAP7_75t_R    g054(.A(new_n72_), .B(p8), .C(new_n49_), .D(new_n29_), .Y(new_n73_));
  OR4x2_ASAP7_75t_R    g055(.A(new_n49_), .B(p8), .C(p3), .D(p1), .Y(new_n74_));
  NAND2x1_ASAP7_75t_R  g056(.A(new_n55_), .B(new_n41_), .Y(new_n75_));
  AND5x1_ASAP7_75t_R   g057(.A(new_n71_), .B(new_n40_), .C(new_n73_), .D(new_n74_), .E(new_n75_), .Y(new_n76_));
  NAND2x1_ASAP7_75t_R  g058(.A(p9), .B(p7), .Y(new_n77_));
  NAND2x1_ASAP7_75t_R  g059(.A(p6), .B(p5), .Y(new_n78_));
  OR3x1_ASAP7_75t_R    g060(.A(new_n77_), .B(new_n78_), .C(p8), .Y(new_n79_));
  OAI21x1_ASAP7_75t_R  g061(.A1(new_n68_), .A2(new_n76_), .B(new_n79_), .Y(new_n80_));
  NOR2x1_ASAP7_75t_R   g062(.A(p8), .B(p3), .Y(new_n81_));
  AO211x2_ASAP7_75t_R  g063(.A1(p8), .A2(new_n28_), .B(new_n57_), .C(new_n81_), .Y(new_n82_));
  NAND2x1_ASAP7_75t_R  g064(.A(p5), .B(p4), .Y(new_n83_));
  NOR2x1_ASAP7_75t_R   g065(.A(p3), .B(p5), .Y(new_n84_));
  AOI22x1_ASAP7_75t_R  g066(.A1(p3), .A2(new_n57_), .B1(new_n84_), .B2(new_n28_), .Y(new_n85_));
  AND2x2_ASAP7_75t_R   g067(.A(p1), .B(p0), .Y(new_n86_));
  AND2x2_ASAP7_75t_R   g068(.A(p2), .B(p4), .Y(new_n87_));
  OAI21x1_ASAP7_75t_R  g069(.A1(p6), .A2(new_n86_), .B(new_n87_), .Y(new_n88_));
  OAI22x1_ASAP7_75t_R  g070(.A1(new_n82_), .A2(new_n83_), .B1(new_n85_), .B2(new_n88_), .Y(new_n89_));
  AOI211x1_ASAP7_75t_R g071(.A1(p3), .A2(p2), .B(p8), .C(p7), .Y(new_n90_));
  NOR2x1_ASAP7_75t_R   g072(.A(p6), .B(new_n61_), .Y(new_n91_));
  AOI21x1_ASAP7_75t_R  g073(.A1(p6), .A2(new_n90_), .B(new_n91_), .Y(new_n92_));
  NOR3x1_ASAP7_75t_R   g074(.A(new_n35_), .B(p8), .C(p3), .Y(new_n93_));
  OAI21x1_ASAP7_75t_R  g075(.A1(new_n91_), .A2(new_n93_), .B(new_n49_), .Y(new_n94_));
  OAI21x1_ASAP7_75t_R  g076(.A1(p4), .A2(new_n92_), .B(new_n94_), .Y(new_n95_));
  OAI22x1_ASAP7_75t_R  g077(.A1(p8), .A2(p3), .B1(p6), .B2(p1), .Y(new_n96_));
  AOI22x1_ASAP7_75t_R  g078(.A1(new_n96_), .A2(new_n43_), .B1(new_n61_), .B2(p7), .Y(new_n97_));
  NAND2x1_ASAP7_75t_R  g079(.A(p10), .B(p0), .Y(new_n98_));
  NAND2x1_ASAP7_75t_R  g080(.A(p1), .B(new_n98_), .Y(new_n99_));
  NAND2x1_ASAP7_75t_R  g081(.A(p10), .B(new_n29_), .Y(new_n100_));
  NOR2x1_ASAP7_75t_R   g082(.A(p6), .B(new_n22_), .Y(new_n101_));
  NAND3x1_ASAP7_75t_R  g083(.A(new_n99_), .B(new_n100_), .C(new_n101_), .Y(new_n102_));
  NOR2x1_ASAP7_75t_R   g084(.A(p5), .B(p4), .Y(new_n103_));
  INVx1_ASAP7_75t_R    g085(.A(new_n103_), .Y(new_n104_));
  AOI21x1_ASAP7_75t_R  g086(.A1(new_n97_), .A2(new_n102_), .B(new_n104_), .Y(new_n105_));
  OA31x2_ASAP7_75t_R   g087(.A1(new_n89_), .A2(new_n95_), .A3(new_n105_), .B1(new_n40_), .Y(new_n106_));
  NOR2x1_ASAP7_75t_R   g088(.A(new_n80_), .B(new_n106_), .Y(o1));
  AND3x1_ASAP7_75t_R   g089(.A(new_n22_), .B(p2), .C(p4), .Y(new_n108_));
  NOR2x1_ASAP7_75t_R   g090(.A(p2), .B(new_n22_), .Y(new_n109_));
  AND3x1_ASAP7_75t_R   g091(.A(new_n109_), .B(p10), .C(new_n49_), .Y(new_n110_));
  OAI21x1_ASAP7_75t_R  g092(.A1(new_n108_), .A2(new_n110_), .B(new_n86_), .Y(new_n111_));
  NOR2x1_ASAP7_75t_R   g093(.A(p1), .B(new_n22_), .Y(new_n112_));
  AND3x1_ASAP7_75t_R   g094(.A(new_n112_), .B(p2), .C(new_n49_), .Y(new_n113_));
  AOI21x1_ASAP7_75t_R  g095(.A1(p4), .A2(new_n109_), .B(new_n113_), .Y(new_n114_));
  AOI21x1_ASAP7_75t_R  g096(.A1(new_n98_), .A2(new_n51_), .B(new_n84_), .Y(new_n115_));
  OR3x1_ASAP7_75t_R    g097(.A(new_n115_), .B(p4), .C(new_n29_), .Y(new_n116_));
  NAND2x1_ASAP7_75t_R  g098(.A(new_n38_), .B(new_n42_), .Y(new_n117_));
  AO31x2_ASAP7_75t_R   g099(.A1(new_n111_), .A2(new_n114_), .A3(new_n116_), .B(new_n117_), .Y(new_n118_));
  OR3x1_ASAP7_75t_R    g100(.A(new_n49_), .B(new_n29_), .C(p4), .Y(new_n119_));
  NOR2x1_ASAP7_75t_R   g101(.A(new_n72_), .B(new_n70_), .Y(new_n120_));
  AO21x1_ASAP7_75t_R   g102(.A1(new_n72_), .A2(new_n83_), .B(p7), .Y(new_n121_));
  AOI21x1_ASAP7_75t_R  g103(.A1(new_n119_), .A2(new_n120_), .B(new_n121_), .Y(new_n122_));
  INVx1_ASAP7_75t_R    g104(.A(new_n83_), .Y(new_n123_));
  AO21x1_ASAP7_75t_R   g105(.A1(p4), .A2(new_n51_), .B(p5), .Y(new_n124_));
  OA21x2_ASAP7_75t_R   g106(.A1(new_n22_), .A2(new_n83_), .B(p6), .Y(new_n125_));
  AO32x1_ASAP7_75t_R   g107(.A1(new_n29_), .A2(new_n123_), .A3(new_n101_), .B1(new_n124_), .B2(new_n125_), .Y(new_n126_));
  OAI21x1_ASAP7_75t_R  g108(.A1(new_n122_), .A2(new_n126_), .B(new_n38_), .Y(new_n127_));
  OR3x1_ASAP7_75t_R    g109(.A(new_n28_), .B(new_n27_), .C(p9), .Y(new_n128_));
  OA21x2_ASAP7_75t_R   g110(.A1(p9), .A2(p7), .B(p8), .Y(new_n129_));
  OR3x1_ASAP7_75t_R    g111(.A(new_n83_), .B(new_n22_), .C(p6), .Y(new_n130_));
  AOI21x1_ASAP7_75t_R  g112(.A1(new_n60_), .A2(new_n130_), .B(new_n35_), .Y(new_n131_));
  OR3x1_ASAP7_75t_R    g113(.A(new_n61_), .B(new_n27_), .C(p7), .Y(new_n132_));
  AOI21x1_ASAP7_75t_R  g114(.A1(new_n77_), .A2(new_n132_), .B(new_n78_), .Y(new_n133_));
  AOI221x1_ASAP7_75t_R g115(.A1(new_n128_), .A2(new_n129_), .B1(new_n131_), .B2(new_n40_), .C(new_n133_), .Y(new_n134_));
  NAND3x1_ASAP7_75t_R  g116(.A(new_n118_), .B(new_n127_), .C(new_n134_), .Y(o2));
  AND3x1_ASAP7_75t_R   g117(.A(new_n123_), .B(p6), .C(p7), .Y(new_n136_));
  AND3x1_ASAP7_75t_R   g118(.A(new_n42_), .B(new_n103_), .C(new_n22_), .Y(new_n137_));
  AOI21x1_ASAP7_75t_R  g119(.A1(new_n112_), .A2(new_n136_), .B(new_n137_), .Y(new_n138_));
  OR3x1_ASAP7_75t_R    g120(.A(new_n138_), .B(p2), .C(new_n39_), .Y(o3));
  AO21x1_ASAP7_75t_R   g121(.A1(p2), .A2(new_n35_), .B(new_n55_), .Y(new_n140_));
  OR4x2_ASAP7_75t_R    g122(.A(new_n78_), .B(p8), .C(new_n22_), .D(new_n27_), .Y(new_n141_));
  OAI22x1_ASAP7_75t_R  g123(.A1(new_n136_), .A2(new_n61_), .B1(new_n140_), .B2(new_n141_), .Y(new_n142_));
  OA21x2_ASAP7_75t_R   g124(.A1(new_n104_), .A2(new_n98_), .B(new_n130_), .Y(new_n143_));
  AO21x1_ASAP7_75t_R   g125(.A1(new_n28_), .A2(new_n86_), .B(new_n123_), .Y(new_n144_));
  OR3x1_ASAP7_75t_R    g126(.A(new_n22_), .B(p6), .C(p4), .Y(new_n145_));
  NAND2x1_ASAP7_75t_R  g127(.A(new_n54_), .B(new_n145_), .Y(new_n146_));
  AO21x1_ASAP7_75t_R   g128(.A1(new_n51_), .A2(new_n144_), .B(new_n146_), .Y(new_n147_));
  OAI21x1_ASAP7_75t_R  g129(.A1(new_n56_), .A2(new_n143_), .B(new_n147_), .Y(new_n148_));
  OA21x2_ASAP7_75t_R   g130(.A1(new_n35_), .A2(new_n142_), .B(new_n40_), .Y(new_n149_));
  OAI21x1_ASAP7_75t_R  g131(.A1(new_n142_), .A2(new_n148_), .B(new_n149_), .Y(o4));
  OR4x2_ASAP7_75t_R    g132(.A(new_n55_), .B(new_n83_), .C(new_n28_), .D(new_n35_), .Y(new_n151_));
  OR3x1_ASAP7_75t_R    g133(.A(p6), .B(p4), .C(p7), .Y(new_n152_));
  OR5x1_ASAP7_75t_R    g134(.A(new_n19_), .B(new_n152_), .C(new_n31_), .D(new_n29_), .E(new_n43_), .Y(new_n153_));
  AO21x1_ASAP7_75t_R   g135(.A1(new_n151_), .A2(new_n153_), .B(new_n22_), .Y(new_n154_));
  AND3x1_ASAP7_75t_R   g136(.A(new_n123_), .B(p1), .C(new_n51_), .Y(new_n155_));
  INVx1_ASAP7_75t_R    g137(.A(new_n42_), .Y(new_n156_));
  OR3x1_ASAP7_75t_R    g138(.A(new_n155_), .B(new_n156_), .C(new_n103_), .Y(new_n157_));
  NAND3x1_ASAP7_75t_R  g139(.A(new_n154_), .B(new_n38_), .C(new_n157_), .Y(o5));
  OR3x1_ASAP7_75t_R    g140(.A(new_n155_), .B(new_n39_), .C(new_n156_), .Y(o6));
endmodule


