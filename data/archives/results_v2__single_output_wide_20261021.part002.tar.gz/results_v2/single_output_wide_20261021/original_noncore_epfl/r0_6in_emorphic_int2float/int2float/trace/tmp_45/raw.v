// Benchmark "/tmp/" written by ABC on Wed Oct 21 14:43:59 2026

module \/tmp/  ( 
    p7, p5, p1, p8, p2, p6, p4, p0, p3, p9, p10,
    o0, o1, o2, o3, o4, o5, o6  );
  input  p7, p5, p1, p8, p2, p6, p4, p0, p3, p9, p10;
  output o0, o1, o2, o3, o4, o5, o6;
  wire new_n19_, new_n20_, new_n21_, new_n22_, new_n23_, new_n24_, new_n25_,
    new_n26_, new_n27_, new_n28_, new_n29_, new_n30_, new_n31_, new_n32_,
    new_n33_, new_n34_, new_n35_, new_n36_, new_n37_, new_n38_, new_n39_,
    new_n40_, new_n41_, new_n42_, new_n43_, new_n44_, new_n45_, new_n46_,
    new_n47_, new_n48_, new_n49_, new_n50_, new_n51_, new_n52_, new_n53_,
    new_n54_, new_n55_, new_n56_, new_n57_, new_n58_, new_n59_, new_n60_,
    new_n61_, new_n62_, new_n63_, new_n64_, new_n65_, new_n67_, new_n68_,
    new_n69_, new_n70_, new_n71_, new_n72_, new_n73_, new_n74_, new_n75_,
    new_n76_, new_n77_, new_n78_, new_n79_, new_n80_, new_n81_, new_n82_,
    new_n83_, new_n84_, new_n85_, new_n86_, new_n87_, new_n88_, new_n89_,
    new_n90_, new_n91_, new_n92_, new_n93_, new_n94_, new_n95_, new_n96_,
    new_n97_, new_n98_, new_n99_, new_n100_, new_n101_, new_n102_,
    new_n103_, new_n104_, new_n106_, new_n107_, new_n108_, new_n109_,
    new_n110_, new_n111_, new_n112_, new_n113_, new_n114_, new_n115_,
    new_n116_, new_n117_, new_n118_, new_n119_, new_n120_, new_n121_,
    new_n122_, new_n123_, new_n124_, new_n125_, new_n126_, new_n127_,
    new_n128_, new_n129_, new_n130_, new_n131_, new_n132_, new_n133_,
    new_n134_, new_n135_, new_n136_, new_n137_, new_n139_, new_n140_,
    new_n142_, new_n143_, new_n144_, new_n145_, new_n146_, new_n147_,
    new_n148_, new_n149_, new_n150_, new_n151_, new_n152_, new_n153_,
    new_n155_, new_n156_, new_n157_, new_n158_, new_n159_;
  INVx1_ASAP7_75t_R    g000(.A(p6), .Y(new_n19_));
  AOI21x1_ASAP7_75t_R  g001(.A1(p2), .A2(p3), .B(new_n19_), .Y(new_n20_));
  INVx1_ASAP7_75t_R    g002(.A(p2), .Y(new_n21_));
  INVx1_ASAP7_75t_R    g003(.A(p3), .Y(new_n22_));
  NAND2x1_ASAP7_75t_R  g004(.A(new_n21_), .B(new_n22_), .Y(new_n23_));
  NOR2x1_ASAP7_75t_R   g005(.A(p1), .B(p6), .Y(new_n24_));
  AND3x1_ASAP7_75t_R   g006(.A(p2), .B(p4), .C(p0), .Y(new_n25_));
  AOI22x1_ASAP7_75t_R  g007(.A1(new_n20_), .A2(new_n23_), .B1(new_n24_), .B2(new_n25_), .Y(new_n26_));
  INVx1_ASAP7_75t_R    g008(.A(p7), .Y(new_n27_));
  INVx1_ASAP7_75t_R    g009(.A(p4), .Y(new_n28_));
  OR3x1_ASAP7_75t_R    g010(.A(new_n27_), .B(new_n28_), .C(p3), .Y(new_n29_));
  OAI21x1_ASAP7_75t_R  g011(.A1(p7), .A2(new_n26_), .B(new_n29_), .Y(new_n30_));
  NAND2x1_ASAP7_75t_R  g012(.A(p7), .B(p3), .Y(new_n31_));
  NAND2x1_ASAP7_75t_R  g013(.A(p0), .B(p3), .Y(new_n32_));
  INVx1_ASAP7_75t_R    g014(.A(new_n32_), .Y(new_n33_));
  OA21x2_ASAP7_75t_R   g015(.A1(p3), .A2(new_n27_), .B(p10), .Y(new_n34_));
  INVx1_ASAP7_75t_R    g016(.A(p10), .Y(new_n35_));
  NOR2x1_ASAP7_75t_R   g017(.A(p5), .B(p6), .Y(new_n36_));
  OA21x2_ASAP7_75t_R   g018(.A1(new_n35_), .A2(new_n32_), .B(new_n36_), .Y(new_n37_));
  OAI21x1_ASAP7_75t_R  g019(.A1(new_n33_), .A2(new_n34_), .B(new_n37_), .Y(new_n38_));
  AOI21x1_ASAP7_75t_R  g020(.A1(new_n31_), .A2(new_n38_), .B(p4), .Y(new_n39_));
  NOR2x1_ASAP7_75t_R   g021(.A(p8), .B(p9), .Y(new_n40_));
  OAI21x1_ASAP7_75t_R  g022(.A1(new_n30_), .A2(new_n39_), .B(new_n40_), .Y(new_n41_));
  INVx1_ASAP7_75t_R    g023(.A(p9), .Y(new_n42_));
  INVx1_ASAP7_75t_R    g024(.A(p0), .Y(new_n43_));
  AOI211x1_ASAP7_75t_R g025(.A1(p6), .A2(new_n22_), .B(p1), .C(new_n43_), .Y(new_n44_));
  AO21x1_ASAP7_75t_R   g026(.A1(new_n27_), .A2(new_n21_), .B(new_n22_), .Y(new_n45_));
  NOR2x1_ASAP7_75t_R   g027(.A(p5), .B(new_n28_), .Y(new_n46_));
  NAND3x1_ASAP7_75t_R  g028(.A(new_n44_), .B(new_n45_), .C(new_n46_), .Y(new_n47_));
  NOR2x1_ASAP7_75t_R   g029(.A(p7), .B(p6), .Y(new_n48_));
  AO31x2_ASAP7_75t_R   g030(.A1(new_n48_), .A2(p1), .A3(new_n43_), .B(p8), .Y(new_n49_));
  AND3x1_ASAP7_75t_R   g031(.A(new_n28_), .B(p5), .C(p8), .Y(new_n50_));
  AOI21x1_ASAP7_75t_R  g032(.A1(new_n46_), .A2(new_n49_), .B(new_n50_), .Y(new_n51_));
  NAND2x1_ASAP7_75t_R  g033(.A(new_n47_), .B(new_n51_), .Y(new_n52_));
  NAND2x1_ASAP7_75t_R  g034(.A(p5), .B(new_n19_), .Y(new_n53_));
  NOR2x1_ASAP7_75t_R   g035(.A(p1), .B(p2), .Y(new_n54_));
  NAND2x1_ASAP7_75t_R  g036(.A(p1), .B(p2), .Y(new_n55_));
  NOR2x1_ASAP7_75t_R   g037(.A(p7), .B(p8), .Y(new_n56_));
  NAND2x1_ASAP7_75t_R  g038(.A(new_n55_), .B(new_n56_), .Y(new_n57_));
  OA21x2_ASAP7_75t_R   g039(.A1(new_n54_), .A2(new_n57_), .B(new_n42_), .Y(new_n58_));
  INVx1_ASAP7_75t_R    g040(.A(p5), .Y(new_n59_));
  NAND2x1_ASAP7_75t_R  g041(.A(p6), .B(new_n59_), .Y(new_n60_));
  INVx1_ASAP7_75t_R    g042(.A(p8), .Y(new_n61_));
  OR3x1_ASAP7_75t_R    g043(.A(new_n27_), .B(new_n59_), .C(new_n61_), .Y(new_n62_));
  AO21x1_ASAP7_75t_R   g044(.A1(new_n60_), .A2(new_n62_), .B(new_n42_), .Y(new_n63_));
  OAI21x1_ASAP7_75t_R  g045(.A1(new_n53_), .A2(new_n58_), .B(new_n63_), .Y(new_n64_));
  AOI21x1_ASAP7_75t_R  g046(.A1(new_n42_), .A2(new_n52_), .B(new_n64_), .Y(new_n65_));
  NAND2x1_ASAP7_75t_R  g047(.A(new_n41_), .B(new_n65_), .Y(o0));
  NOR2x1_ASAP7_75t_R   g048(.A(p6), .B(new_n61_), .Y(new_n67_));
  AO21x1_ASAP7_75t_R   g049(.A1(new_n56_), .A2(new_n20_), .B(new_n67_), .Y(new_n68_));
  OAI21x1_ASAP7_75t_R  g050(.A1(p5), .A2(p6), .B(new_n22_), .Y(new_n69_));
  AO21x1_ASAP7_75t_R   g051(.A1(p1), .A2(p0), .B(p6), .Y(new_n70_));
  OAI21x1_ASAP7_75t_R  g052(.A1(p7), .A2(p8), .B(p3), .Y(new_n71_));
  AND5x1_ASAP7_75t_R   g053(.A(p2), .B(new_n69_), .C(p4), .D(new_n70_), .E(new_n71_), .Y(new_n72_));
  AOI21x1_ASAP7_75t_R  g054(.A1(new_n28_), .A2(new_n68_), .B(new_n72_), .Y(new_n73_));
  NAND2x1_ASAP7_75t_R  g055(.A(new_n61_), .B(new_n22_), .Y(new_n74_));
  NAND2x1_ASAP7_75t_R  g056(.A(p8), .B(new_n19_), .Y(new_n75_));
  AND2x2_ASAP7_75t_R   g057(.A(p5), .B(p4), .Y(new_n76_));
  AND3x1_ASAP7_75t_R   g058(.A(new_n74_), .B(new_n75_), .C(new_n76_), .Y(new_n77_));
  AOI21x1_ASAP7_75t_R  g059(.A1(new_n75_), .A2(new_n74_), .B(p5), .Y(new_n78_));
  OAI22x1_ASAP7_75t_R  g060(.A1(new_n77_), .A2(new_n78_), .B1(p7), .B2(p8), .Y(new_n79_));
  OAI22x1_ASAP7_75t_R  g061(.A1(p1), .A2(p6), .B1(p8), .B2(p3), .Y(new_n80_));
  AO22x1_ASAP7_75t_R   g062(.A1(p7), .A2(new_n61_), .B1(new_n43_), .B2(new_n80_), .Y(new_n81_));
  NAND2x1_ASAP7_75t_R  g063(.A(p1), .B(p0), .Y(new_n82_));
  NAND2x1_ASAP7_75t_R  g064(.A(p3), .B(new_n19_), .Y(new_n83_));
  INVx1_ASAP7_75t_R    g065(.A(p1), .Y(new_n84_));
  NOR2x1_ASAP7_75t_R   g066(.A(p10), .B(new_n84_), .Y(new_n85_));
  AOI211x1_ASAP7_75t_R g067(.A1(p10), .A2(new_n82_), .B(new_n83_), .C(new_n85_), .Y(new_n86_));
  NOR2x1_ASAP7_75t_R   g068(.A(p5), .B(p4), .Y(new_n87_));
  OAI21x1_ASAP7_75t_R  g069(.A1(new_n81_), .A2(new_n86_), .B(new_n87_), .Y(new_n88_));
  NAND3x1_ASAP7_75t_R  g070(.A(new_n73_), .B(new_n79_), .C(new_n88_), .Y(new_n89_));
  INVx1_ASAP7_75t_R    g071(.A(new_n48_), .Y(new_n90_));
  NOR2x1_ASAP7_75t_R   g072(.A(p2), .B(new_n28_), .Y(new_n91_));
  NOR2x1_ASAP7_75t_R   g073(.A(p5), .B(p1), .Y(new_n92_));
  NOR2x1_ASAP7_75t_R   g074(.A(p0), .B(new_n28_), .Y(new_n93_));
  NOR2x1_ASAP7_75t_R   g075(.A(p5), .B(p2), .Y(new_n94_));
  AOI22x1_ASAP7_75t_R  g076(.A1(new_n91_), .A2(new_n92_), .B1(new_n93_), .B2(new_n94_), .Y(new_n95_));
  AO21x1_ASAP7_75t_R   g077(.A1(p1), .A2(p2), .B(p3), .Y(new_n96_));
  OR3x1_ASAP7_75t_R    g078(.A(new_n96_), .B(new_n59_), .C(p8), .Y(new_n97_));
  OR4x2_ASAP7_75t_R    g079(.A(new_n55_), .B(new_n59_), .C(p8), .D(new_n22_), .Y(new_n98_));
  AND3x1_ASAP7_75t_R   g080(.A(new_n95_), .B(new_n97_), .C(new_n98_), .Y(new_n99_));
  NAND2x1_ASAP7_75t_R  g081(.A(p5), .B(p6), .Y(new_n100_));
  NOR3x1_ASAP7_75t_R   g082(.A(new_n100_), .B(new_n27_), .C(new_n42_), .Y(new_n101_));
  AND3x1_ASAP7_75t_R   g083(.A(new_n100_), .B(new_n27_), .C(p9), .Y(new_n102_));
  AOI21x1_ASAP7_75t_R  g084(.A1(new_n61_), .A2(new_n101_), .B(new_n102_), .Y(new_n103_));
  OAI21x1_ASAP7_75t_R  g085(.A1(new_n90_), .A2(new_n99_), .B(new_n103_), .Y(new_n104_));
  AOI21x1_ASAP7_75t_R  g086(.A1(new_n42_), .A2(new_n89_), .B(new_n104_), .Y(o1));
  NAND2x1_ASAP7_75t_R  g087(.A(p2), .B(p4), .Y(new_n106_));
  AOI21x1_ASAP7_75t_R  g088(.A1(new_n22_), .A2(new_n106_), .B(new_n43_), .Y(new_n107_));
  AO21x1_ASAP7_75t_R   g089(.A1(p10), .A2(new_n94_), .B(new_n22_), .Y(new_n108_));
  AND3x1_ASAP7_75t_R   g090(.A(new_n59_), .B(new_n28_), .C(new_n22_), .Y(new_n109_));
  AOI21x1_ASAP7_75t_R  g091(.A1(new_n107_), .A2(new_n108_), .B(new_n109_), .Y(new_n110_));
  NAND2x1_ASAP7_75t_R  g092(.A(p0), .B(p10), .Y(new_n111_));
  AO31x2_ASAP7_75t_R   g093(.A1(new_n111_), .A2(p1), .A3(new_n28_), .B(new_n92_), .Y(new_n112_));
  AND2x2_ASAP7_75t_R   g094(.A(p2), .B(p3), .Y(new_n113_));
  AOI22x1_ASAP7_75t_R  g095(.A1(new_n112_), .A2(new_n113_), .B1(p3), .B2(new_n91_), .Y(new_n114_));
  OAI21x1_ASAP7_75t_R  g096(.A1(new_n84_), .A2(new_n110_), .B(new_n114_), .Y(new_n115_));
  AND3x1_ASAP7_75t_R   g097(.A(new_n40_), .B(new_n27_), .C(new_n19_), .Y(new_n116_));
  AND3x1_ASAP7_75t_R   g098(.A(p5), .B(p6), .C(p4), .Y(new_n117_));
  OR3x1_ASAP7_75t_R    g099(.A(new_n117_), .B(p7), .C(p9), .Y(new_n118_));
  NAND2x1_ASAP7_75t_R  g100(.A(p6), .B(p4), .Y(new_n119_));
  NAND2x1_ASAP7_75t_R  g101(.A(p7), .B(new_n42_), .Y(new_n120_));
  OA21x2_ASAP7_75t_R   g102(.A1(new_n119_), .A2(new_n120_), .B(p8), .Y(new_n121_));
  NAND2x1_ASAP7_75t_R  g103(.A(p5), .B(p4), .Y(new_n122_));
  OR3x1_ASAP7_75t_R    g104(.A(new_n122_), .B(p6), .C(new_n22_), .Y(new_n123_));
  AOI21x1_ASAP7_75t_R  g105(.A1(new_n60_), .A2(new_n123_), .B(new_n120_), .Y(new_n124_));
  AO211x2_ASAP7_75t_R  g106(.A1(new_n118_), .A2(new_n121_), .B(new_n101_), .C(new_n124_), .Y(new_n125_));
  AND2x2_ASAP7_75t_R   g107(.A(p4), .B(p3), .Y(new_n126_));
  AND3x1_ASAP7_75t_R   g108(.A(new_n59_), .B(p2), .C(p6), .Y(new_n127_));
  NOR2x1_ASAP7_75t_R   g109(.A(new_n100_), .B(new_n126_), .Y(new_n128_));
  AND3x1_ASAP7_75t_R   g110(.A(new_n126_), .B(p5), .C(new_n24_), .Y(new_n129_));
  AOI211x1_ASAP7_75t_R g111(.A1(new_n126_), .A2(new_n127_), .B(new_n128_), .C(new_n129_), .Y(new_n130_));
  AND3x1_ASAP7_75t_R   g112(.A(new_n28_), .B(p5), .C(p1), .Y(new_n131_));
  NAND2x1_ASAP7_75t_R  g113(.A(p4), .B(new_n43_), .Y(new_n132_));
  OAI21x1_ASAP7_75t_R  g114(.A1(p5), .A2(new_n132_), .B(new_n113_), .Y(new_n133_));
  OA21x2_ASAP7_75t_R   g115(.A1(new_n113_), .A2(new_n76_), .B(new_n27_), .Y(new_n134_));
  OAI21x1_ASAP7_75t_R  g116(.A1(new_n131_), .A2(new_n133_), .B(new_n134_), .Y(new_n135_));
  INVx1_ASAP7_75t_R    g117(.A(new_n40_), .Y(new_n136_));
  AOI21x1_ASAP7_75t_R  g118(.A1(new_n130_), .A2(new_n135_), .B(new_n136_), .Y(new_n137_));
  AO211x2_ASAP7_75t_R  g119(.A1(new_n115_), .A2(new_n116_), .B(new_n125_), .C(new_n137_), .Y(o2));
  NOR2x1_ASAP7_75t_R   g120(.A(p1), .B(new_n31_), .Y(new_n139_));
  AOI22x1_ASAP7_75t_R  g121(.A1(new_n109_), .A2(new_n48_), .B1(new_n117_), .B2(new_n139_), .Y(new_n140_));
  OR3x1_ASAP7_75t_R    g122(.A(new_n140_), .B(p2), .C(new_n136_), .Y(o3));
  AO21x1_ASAP7_75t_R   g123(.A1(new_n27_), .A2(p2), .B(new_n54_), .Y(new_n142_));
  OR5x1_ASAP7_75t_R    g124(.A(new_n59_), .B(new_n142_), .C(p8), .D(new_n22_), .E(new_n119_), .Y(new_n143_));
  AO21x1_ASAP7_75t_R   g125(.A1(p7), .A2(new_n117_), .B(new_n61_), .Y(new_n144_));
  OR3x1_ASAP7_75t_R    g126(.A(new_n111_), .B(p5), .C(p4), .Y(new_n145_));
  OR3x1_ASAP7_75t_R    g127(.A(new_n84_), .B(new_n21_), .C(p7), .Y(new_n146_));
  AO21x1_ASAP7_75t_R   g128(.A1(new_n145_), .A2(new_n123_), .B(new_n146_), .Y(new_n147_));
  NAND3x1_ASAP7_75t_R  g129(.A(new_n143_), .B(new_n144_), .C(new_n147_), .Y(new_n148_));
  NAND2x1_ASAP7_75t_R  g130(.A(new_n19_), .B(new_n28_), .Y(new_n149_));
  OR3x1_ASAP7_75t_R    g131(.A(new_n84_), .B(new_n43_), .C(p6), .Y(new_n150_));
  AO21x1_ASAP7_75t_R   g132(.A1(new_n122_), .A2(new_n150_), .B(new_n21_), .Y(new_n151_));
  AO21x1_ASAP7_75t_R   g133(.A1(new_n149_), .A2(new_n151_), .B(new_n22_), .Y(new_n152_));
  AND3x1_ASAP7_75t_R   g134(.A(new_n53_), .B(new_n27_), .C(new_n42_), .Y(new_n153_));
  AOI22x1_ASAP7_75t_R  g135(.A1(new_n148_), .A2(new_n42_), .B1(new_n152_), .B2(new_n153_), .Y(o4));
  OR4x2_ASAP7_75t_R    g136(.A(new_n54_), .B(new_n100_), .C(new_n27_), .D(new_n28_), .Y(new_n155_));
  OR3x1_ASAP7_75t_R    g137(.A(new_n146_), .B(new_n111_), .C(new_n149_), .Y(new_n156_));
  AO21x1_ASAP7_75t_R   g138(.A1(new_n155_), .A2(new_n156_), .B(new_n22_), .Y(new_n157_));
  AND5x1_ASAP7_75t_R   g139(.A(p5), .B(p1), .C(p2), .D(p4), .E(p3), .Y(new_n158_));
  OR3x1_ASAP7_75t_R    g140(.A(new_n158_), .B(new_n90_), .C(new_n87_), .Y(new_n159_));
  NAND3x1_ASAP7_75t_R  g141(.A(new_n157_), .B(new_n40_), .C(new_n159_), .Y(o5));
  OR3x1_ASAP7_75t_R    g142(.A(new_n158_), .B(new_n136_), .C(new_n90_), .Y(o6));
endmodule


