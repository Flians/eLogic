// Benchmark "/tmp/" written by ABC on Wed Oct 21 14:43:56 2026

module \/tmp/  ( 
    p6, p2, p1, p5, p8, p3, p10, p0, p4, p7, p9,
    o0, o1, o2, o3, o4, o5, o6  );
  input  p6, p2, p1, p5, p8, p3, p10, p0, p4, p7, p9;
  output o0, o1, o2, o3, o4, o5, o6;
  wire new_n19_, new_n20_, new_n21_, new_n22_, new_n23_, new_n24_, new_n25_,
    new_n26_, new_n27_, new_n28_, new_n29_, new_n30_, new_n31_, new_n32_,
    new_n33_, new_n34_, new_n35_, new_n36_, new_n37_, new_n38_, new_n39_,
    new_n40_, new_n41_, new_n42_, new_n43_, new_n44_, new_n45_, new_n46_,
    new_n47_, new_n48_, new_n49_, new_n50_, new_n51_, new_n52_, new_n53_,
    new_n54_, new_n55_, new_n56_, new_n57_, new_n58_, new_n59_, new_n60_,
    new_n61_, new_n62_, new_n63_, new_n64_, new_n66_, new_n67_, new_n68_,
    new_n69_, new_n70_, new_n71_, new_n72_, new_n73_, new_n74_, new_n75_,
    new_n76_, new_n77_, new_n78_, new_n79_, new_n80_, new_n81_, new_n82_,
    new_n83_, new_n84_, new_n85_, new_n86_, new_n87_, new_n88_, new_n89_,
    new_n90_, new_n91_, new_n92_, new_n93_, new_n94_, new_n95_, new_n96_,
    new_n97_, new_n98_, new_n99_, new_n100_, new_n101_, new_n102_,
    new_n103_, new_n105_, new_n106_, new_n107_, new_n108_, new_n109_,
    new_n110_, new_n111_, new_n112_, new_n113_, new_n114_, new_n115_,
    new_n116_, new_n117_, new_n118_, new_n119_, new_n120_, new_n121_,
    new_n122_, new_n123_, new_n124_, new_n125_, new_n126_, new_n127_,
    new_n128_, new_n129_, new_n130_, new_n131_, new_n132_, new_n133_,
    new_n134_, new_n135_, new_n137_, new_n138_, new_n139_, new_n141_,
    new_n142_, new_n143_, new_n144_, new_n145_, new_n146_, new_n147_,
    new_n148_, new_n149_, new_n150_, new_n151_, new_n152_, new_n153_,
    new_n155_, new_n156_, new_n157_, new_n158_;
  INVx1_ASAP7_75t_R    g000(.A(p4), .Y(new_n19_));
  INVx1_ASAP7_75t_R    g001(.A(p10), .Y(new_n20_));
  NAND2x1_ASAP7_75t_R  g002(.A(p3), .B(p0), .Y(new_n21_));
  INVx1_ASAP7_75t_R    g003(.A(p6), .Y(new_n22_));
  INVx1_ASAP7_75t_R    g004(.A(p5), .Y(new_n23_));
  NAND2x1_ASAP7_75t_R  g005(.A(new_n22_), .B(new_n23_), .Y(new_n24_));
  AO21x1_ASAP7_75t_R   g006(.A1(new_n20_), .A2(new_n21_), .B(new_n24_), .Y(new_n25_));
  INVx1_ASAP7_75t_R    g007(.A(p3), .Y(new_n26_));
  NAND2x1_ASAP7_75t_R  g008(.A(p7), .B(new_n26_), .Y(new_n27_));
  AOI21x1_ASAP7_75t_R  g009(.A1(new_n21_), .A2(new_n27_), .B(new_n20_), .Y(new_n28_));
  INVx1_ASAP7_75t_R    g010(.A(p7), .Y(new_n29_));
  OAI22x1_ASAP7_75t_R  g011(.A1(new_n25_), .A2(new_n28_), .B1(new_n26_), .B2(new_n29_), .Y(new_n30_));
  NAND2x1_ASAP7_75t_R  g012(.A(p2), .B(p4), .Y(new_n31_));
  NOR2x1_ASAP7_75t_R   g013(.A(p6), .B(new_n31_), .Y(new_n32_));
  INVx1_ASAP7_75t_R    g014(.A(p0), .Y(new_n33_));
  NOR2x1_ASAP7_75t_R   g015(.A(p1), .B(new_n33_), .Y(new_n34_));
  INVx1_ASAP7_75t_R    g016(.A(p2), .Y(new_n35_));
  NAND2x1_ASAP7_75t_R  g017(.A(new_n35_), .B(new_n26_), .Y(new_n36_));
  AOI21x1_ASAP7_75t_R  g018(.A1(p2), .A2(p3), .B(new_n22_), .Y(new_n37_));
  AOI22x1_ASAP7_75t_R  g019(.A1(new_n32_), .A2(new_n34_), .B1(new_n36_), .B2(new_n37_), .Y(new_n38_));
  OAI22x1_ASAP7_75t_R  g020(.A1(new_n38_), .A2(p7), .B1(new_n19_), .B2(new_n27_), .Y(new_n39_));
  AOI21x1_ASAP7_75t_R  g021(.A1(new_n19_), .A2(new_n30_), .B(new_n39_), .Y(new_n40_));
  NOR2x1_ASAP7_75t_R   g022(.A(p8), .B(p9), .Y(new_n41_));
  INVx1_ASAP7_75t_R    g023(.A(new_n41_), .Y(new_n42_));
  INVx1_ASAP7_75t_R    g024(.A(p9), .Y(new_n43_));
  AO21x1_ASAP7_75t_R   g025(.A1(new_n35_), .A2(new_n29_), .B(new_n26_), .Y(new_n44_));
  NAND2x1_ASAP7_75t_R  g026(.A(p6), .B(new_n26_), .Y(new_n45_));
  NAND3x1_ASAP7_75t_R  g027(.A(new_n44_), .B(new_n45_), .C(new_n34_), .Y(new_n46_));
  NOR2x1_ASAP7_75t_R   g028(.A(p5), .B(new_n19_), .Y(new_n47_));
  INVx1_ASAP7_75t_R    g029(.A(new_n47_), .Y(new_n48_));
  NOR2x1_ASAP7_75t_R   g030(.A(p6), .B(p7), .Y(new_n49_));
  AO31x2_ASAP7_75t_R   g031(.A1(new_n49_), .A2(p1), .A3(new_n33_), .B(p8), .Y(new_n50_));
  AND3x1_ASAP7_75t_R   g032(.A(new_n19_), .B(p5), .C(p8), .Y(new_n51_));
  AOI21x1_ASAP7_75t_R  g033(.A1(new_n47_), .A2(new_n50_), .B(new_n51_), .Y(new_n52_));
  OAI21x1_ASAP7_75t_R  g034(.A1(new_n46_), .A2(new_n48_), .B(new_n52_), .Y(new_n53_));
  NOR2x1_ASAP7_75t_R   g035(.A(p8), .B(p7), .Y(new_n54_));
  INVx1_ASAP7_75t_R    g036(.A(new_n54_), .Y(new_n55_));
  AND2x2_ASAP7_75t_R   g037(.A(p2), .B(p1), .Y(new_n56_));
  NOR2x1_ASAP7_75t_R   g038(.A(p2), .B(p1), .Y(new_n57_));
  OR3x1_ASAP7_75t_R    g039(.A(new_n55_), .B(new_n56_), .C(new_n57_), .Y(new_n58_));
  NAND2x1_ASAP7_75t_R  g040(.A(p5), .B(new_n22_), .Y(new_n59_));
  NAND2x1_ASAP7_75t_R  g041(.A(p8), .B(p7), .Y(new_n60_));
  NAND2x1_ASAP7_75t_R  g042(.A(p6), .B(p9), .Y(new_n61_));
  AO21x1_ASAP7_75t_R   g043(.A1(p5), .A2(new_n60_), .B(new_n61_), .Y(new_n62_));
  AOI22x1_ASAP7_75t_R  g044(.A1(new_n58_), .A2(new_n43_), .B1(new_n59_), .B2(new_n62_), .Y(new_n63_));
  AOI21x1_ASAP7_75t_R  g045(.A1(new_n43_), .A2(new_n53_), .B(new_n63_), .Y(new_n64_));
  OAI21x1_ASAP7_75t_R  g046(.A1(new_n40_), .A2(new_n42_), .B(new_n64_), .Y(o0));
  AO22x1_ASAP7_75t_R   g047(.A1(new_n22_), .A2(p8), .B1(new_n54_), .B2(new_n37_), .Y(new_n66_));
  NAND2x1_ASAP7_75t_R  g048(.A(p3), .B(new_n54_), .Y(new_n67_));
  OR3x1_ASAP7_75t_R    g049(.A(p6), .B(p5), .C(p3), .Y(new_n68_));
  NAND2x1_ASAP7_75t_R  g050(.A(p1), .B(p0), .Y(new_n69_));
  AO21x1_ASAP7_75t_R   g051(.A1(new_n22_), .A2(new_n69_), .B(new_n31_), .Y(new_n70_));
  AOI21x1_ASAP7_75t_R  g052(.A1(new_n67_), .A2(new_n68_), .B(new_n70_), .Y(new_n71_));
  AOI21x1_ASAP7_75t_R  g053(.A1(new_n19_), .A2(new_n66_), .B(new_n71_), .Y(new_n72_));
  NAND2x1_ASAP7_75t_R  g054(.A(p8), .B(new_n22_), .Y(new_n73_));
  INVx1_ASAP7_75t_R    g055(.A(p8), .Y(new_n74_));
  NAND2x1_ASAP7_75t_R  g056(.A(new_n74_), .B(new_n26_), .Y(new_n75_));
  AOI21x1_ASAP7_75t_R  g057(.A1(new_n73_), .A2(new_n75_), .B(p5), .Y(new_n76_));
  NAND2x1_ASAP7_75t_R  g058(.A(p5), .B(p4), .Y(new_n77_));
  INVx1_ASAP7_75t_R    g059(.A(new_n77_), .Y(new_n78_));
  AND3x1_ASAP7_75t_R   g060(.A(new_n78_), .B(new_n75_), .C(new_n73_), .Y(new_n79_));
  OAI21x1_ASAP7_75t_R  g061(.A1(new_n76_), .A2(new_n79_), .B(new_n55_), .Y(new_n80_));
  OAI22x1_ASAP7_75t_R  g062(.A1(p6), .A2(p1), .B1(p8), .B2(p3), .Y(new_n81_));
  AO22x1_ASAP7_75t_R   g063(.A1(new_n74_), .A2(p7), .B1(new_n33_), .B2(new_n81_), .Y(new_n82_));
  NAND2x1_ASAP7_75t_R  g064(.A(p3), .B(new_n22_), .Y(new_n83_));
  INVx1_ASAP7_75t_R    g065(.A(p1), .Y(new_n84_));
  NOR2x1_ASAP7_75t_R   g066(.A(p10), .B(new_n84_), .Y(new_n85_));
  AOI211x1_ASAP7_75t_R g067(.A1(p10), .A2(new_n69_), .B(new_n83_), .C(new_n85_), .Y(new_n86_));
  NOR2x1_ASAP7_75t_R   g068(.A(p5), .B(p4), .Y(new_n87_));
  OAI21x1_ASAP7_75t_R  g069(.A1(new_n82_), .A2(new_n86_), .B(new_n87_), .Y(new_n88_));
  NAND3x1_ASAP7_75t_R  g070(.A(new_n72_), .B(new_n80_), .C(new_n88_), .Y(new_n89_));
  AO21x1_ASAP7_75t_R   g071(.A1(p6), .A2(p5), .B(p7), .Y(new_n90_));
  AO21x1_ASAP7_75t_R   g072(.A1(p6), .A2(new_n43_), .B(new_n90_), .Y(new_n91_));
  NOR3x1_ASAP7_75t_R   g073(.A(new_n23_), .B(p8), .C(p3), .Y(new_n92_));
  NOR3x1_ASAP7_75t_R   g074(.A(new_n19_), .B(p5), .C(p0), .Y(new_n93_));
  OAI21x1_ASAP7_75t_R  g075(.A1(new_n92_), .A2(new_n93_), .B(new_n35_), .Y(new_n94_));
  NOR2x1_ASAP7_75t_R   g076(.A(p8), .B(new_n26_), .Y(new_n95_));
  AND3x1_ASAP7_75t_R   g077(.A(p2), .B(p1), .C(p5), .Y(new_n96_));
  AOI22x1_ASAP7_75t_R  g078(.A1(new_n47_), .A2(new_n57_), .B1(new_n95_), .B2(new_n96_), .Y(new_n97_));
  OR4x2_ASAP7_75t_R    g079(.A(new_n23_), .B(p1), .C(p8), .D(p3), .Y(new_n98_));
  AND4x2_ASAP7_75t_R   g080(.A(new_n94_), .B(new_n97_), .C(new_n43_), .D(new_n98_), .Y(new_n99_));
  AND2x2_ASAP7_75t_R   g081(.A(p6), .B(p5), .Y(new_n100_));
  AND3x1_ASAP7_75t_R   g082(.A(new_n100_), .B(p7), .C(p9), .Y(new_n101_));
  NAND2x1_ASAP7_75t_R  g083(.A(new_n74_), .B(new_n101_), .Y(new_n102_));
  OAI21x1_ASAP7_75t_R  g084(.A1(new_n91_), .A2(new_n99_), .B(new_n102_), .Y(new_n103_));
  AOI21x1_ASAP7_75t_R  g085(.A1(new_n43_), .A2(new_n89_), .B(new_n103_), .Y(o1));
  OR3x1_ASAP7_75t_R    g086(.A(p5), .B(p3), .C(p4), .Y(new_n105_));
  AND2x2_ASAP7_75t_R   g087(.A(p10), .B(p0), .Y(new_n106_));
  NAND2x1_ASAP7_75t_R  g088(.A(p2), .B(p3), .Y(new_n107_));
  OR3x1_ASAP7_75t_R    g089(.A(new_n106_), .B(p4), .C(new_n107_), .Y(new_n108_));
  AO21x1_ASAP7_75t_R   g090(.A1(new_n105_), .A2(new_n108_), .B(new_n84_), .Y(new_n109_));
  AND2x2_ASAP7_75t_R   g091(.A(p3), .B(p4), .Y(new_n110_));
  AND5x1_ASAP7_75t_R   g092(.A(new_n23_), .B(p1), .C(p3), .D(p10), .E(p0), .Y(new_n111_));
  OAI21x1_ASAP7_75t_R  g093(.A1(new_n110_), .A2(new_n111_), .B(new_n35_), .Y(new_n112_));
  OR3x1_ASAP7_75t_R    g094(.A(new_n107_), .B(p1), .C(p5), .Y(new_n113_));
  OR3x1_ASAP7_75t_R    g095(.A(new_n31_), .B(new_n69_), .C(p3), .Y(new_n114_));
  AND2x2_ASAP7_75t_R   g096(.A(new_n113_), .B(new_n114_), .Y(new_n115_));
  NAND2x1_ASAP7_75t_R  g097(.A(new_n41_), .B(new_n49_), .Y(new_n116_));
  AO31x2_ASAP7_75t_R   g098(.A1(new_n109_), .A2(new_n112_), .A3(new_n115_), .B(new_n116_), .Y(new_n117_));
  OR3x1_ASAP7_75t_R    g099(.A(new_n84_), .B(new_n23_), .C(p4), .Y(new_n118_));
  NOR2x1_ASAP7_75t_R   g100(.A(new_n107_), .B(new_n93_), .Y(new_n119_));
  AO21x1_ASAP7_75t_R   g101(.A1(new_n107_), .A2(new_n77_), .B(p7), .Y(new_n120_));
  AOI21x1_ASAP7_75t_R  g102(.A1(new_n118_), .A2(new_n119_), .B(new_n120_), .Y(new_n121_));
  OA21x2_ASAP7_75t_R   g103(.A1(new_n26_), .A2(new_n19_), .B(new_n100_), .Y(new_n122_));
  AND5x1_ASAP7_75t_R   g104(.A(new_n22_), .B(new_n84_), .C(p5), .D(p3), .E(p4), .Y(new_n123_));
  AND5x1_ASAP7_75t_R   g105(.A(p6), .B(new_n23_), .C(p2), .D(p3), .E(p4), .Y(new_n124_));
  OR3x1_ASAP7_75t_R    g106(.A(new_n122_), .B(new_n123_), .C(new_n124_), .Y(new_n125_));
  OAI21x1_ASAP7_75t_R  g107(.A1(new_n121_), .A2(new_n125_), .B(new_n41_), .Y(new_n126_));
  AND3x1_ASAP7_75t_R   g108(.A(p6), .B(p5), .C(p4), .Y(new_n127_));
  INVx1_ASAP7_75t_R    g109(.A(new_n127_), .Y(new_n128_));
  AND3x1_ASAP7_75t_R   g110(.A(new_n128_), .B(new_n29_), .C(new_n43_), .Y(new_n129_));
  AND2x2_ASAP7_75t_R   g111(.A(p6), .B(p4), .Y(new_n130_));
  NOR2x1_ASAP7_75t_R   g112(.A(p9), .B(new_n29_), .Y(new_n131_));
  AO21x1_ASAP7_75t_R   g113(.A1(new_n130_), .A2(new_n131_), .B(new_n74_), .Y(new_n132_));
  OAI22x1_ASAP7_75t_R  g114(.A1(new_n83_), .A2(new_n77_), .B1(new_n22_), .B2(p5), .Y(new_n133_));
  AOI21x1_ASAP7_75t_R  g115(.A1(new_n131_), .A2(new_n133_), .B(new_n101_), .Y(new_n134_));
  OA21x2_ASAP7_75t_R   g116(.A1(new_n129_), .A2(new_n132_), .B(new_n134_), .Y(new_n135_));
  NAND3x1_ASAP7_75t_R  g117(.A(new_n117_), .B(new_n126_), .C(new_n135_), .Y(o2));
  OR3x1_ASAP7_75t_R    g118(.A(new_n26_), .B(new_n29_), .C(p1), .Y(new_n137_));
  INVx1_ASAP7_75t_R    g119(.A(new_n49_), .Y(new_n138_));
  OA22x2_ASAP7_75t_R   g120(.A1(new_n137_), .A2(new_n128_), .B1(new_n138_), .B2(new_n105_), .Y(new_n139_));
  OR3x1_ASAP7_75t_R    g121(.A(new_n139_), .B(p2), .C(new_n42_), .Y(o3));
  NOR2x1_ASAP7_75t_R   g122(.A(p7), .B(new_n35_), .Y(new_n141_));
  OR5x1_ASAP7_75t_R    g123(.A(p8), .B(new_n128_), .C(new_n26_), .D(new_n57_), .E(new_n141_), .Y(new_n142_));
  AO21x1_ASAP7_75t_R   g124(.A1(p7), .A2(new_n127_), .B(new_n74_), .Y(new_n143_));
  NAND2x1_ASAP7_75t_R  g125(.A(new_n87_), .B(new_n106_), .Y(new_n144_));
  OR3x1_ASAP7_75t_R    g126(.A(new_n77_), .B(p6), .C(new_n26_), .Y(new_n145_));
  OR3x1_ASAP7_75t_R    g127(.A(new_n35_), .B(new_n84_), .C(p7), .Y(new_n146_));
  AO21x1_ASAP7_75t_R   g128(.A1(new_n144_), .A2(new_n145_), .B(new_n146_), .Y(new_n147_));
  NAND3x1_ASAP7_75t_R  g129(.A(new_n142_), .B(new_n143_), .C(new_n147_), .Y(new_n148_));
  OR3x1_ASAP7_75t_R    g130(.A(new_n84_), .B(new_n33_), .C(p6), .Y(new_n149_));
  AO21x1_ASAP7_75t_R   g131(.A1(new_n77_), .A2(new_n149_), .B(new_n107_), .Y(new_n150_));
  NOR2x1_ASAP7_75t_R   g132(.A(p6), .B(p4), .Y(new_n151_));
  NAND2x1_ASAP7_75t_R  g133(.A(p3), .B(new_n151_), .Y(new_n152_));
  AND5x1_ASAP7_75t_R   g134(.A(new_n29_), .B(new_n150_), .C(new_n43_), .D(new_n59_), .E(new_n152_), .Y(new_n153_));
  AOI21x1_ASAP7_75t_R  g135(.A1(new_n43_), .A2(new_n148_), .B(new_n153_), .Y(o4));
  OR5x1_ASAP7_75t_R    g136(.A(new_n22_), .B(new_n57_), .C(new_n77_), .D(new_n26_), .E(new_n29_), .Y(new_n155_));
  NAND2x1_ASAP7_75t_R  g137(.A(new_n41_), .B(new_n155_), .Y(new_n156_));
  AOI211x1_ASAP7_75t_R g138(.A1(new_n110_), .A2(new_n96_), .B(new_n87_), .C(new_n138_), .Y(new_n157_));
  AND5x1_ASAP7_75t_R   g139(.A(p1), .B(new_n141_), .C(p3), .D(new_n106_), .E(new_n151_), .Y(new_n158_));
  OR3x1_ASAP7_75t_R    g140(.A(new_n156_), .B(new_n157_), .C(new_n158_), .Y(o5));
  AO21x1_ASAP7_75t_R   g141(.A1(new_n96_), .A2(new_n110_), .B(new_n116_), .Y(o6));
endmodule


