// Benchmark "/tmp/" written by ABC on Wed Oct 21 14:43:57 2026

module \/tmp/  ( 
    p6, p10, p5, p3, p0, p2, p7, p9, p4, p8, p1,
    o0, o1, o2, o3, o4, o5, o6  );
  input  p6, p10, p5, p3, p0, p2, p7, p9, p4, p8, p1;
  output o0, o1, o2, o3, o4, o5, o6;
  wire new_n19_, new_n20_, new_n21_, new_n22_, new_n23_, new_n24_, new_n25_,
    new_n26_, new_n27_, new_n28_, new_n29_, new_n30_, new_n31_, new_n32_,
    new_n33_, new_n34_, new_n35_, new_n36_, new_n37_, new_n38_, new_n39_,
    new_n40_, new_n41_, new_n42_, new_n43_, new_n44_, new_n45_, new_n46_,
    new_n47_, new_n48_, new_n49_, new_n50_, new_n51_, new_n52_, new_n53_,
    new_n54_, new_n55_, new_n56_, new_n57_, new_n58_, new_n59_, new_n60_,
    new_n62_, new_n63_, new_n64_, new_n65_, new_n66_, new_n67_, new_n68_,
    new_n69_, new_n70_, new_n71_, new_n72_, new_n73_, new_n74_, new_n75_,
    new_n76_, new_n77_, new_n78_, new_n79_, new_n80_, new_n81_, new_n82_,
    new_n83_, new_n84_, new_n85_, new_n86_, new_n87_, new_n88_, new_n89_,
    new_n90_, new_n91_, new_n92_, new_n93_, new_n94_, new_n95_, new_n96_,
    new_n97_, new_n98_, new_n99_, new_n100_, new_n102_, new_n103_,
    new_n104_, new_n105_, new_n106_, new_n107_, new_n108_, new_n109_,
    new_n110_, new_n111_, new_n112_, new_n113_, new_n114_, new_n115_,
    new_n116_, new_n117_, new_n118_, new_n119_, new_n120_, new_n121_,
    new_n122_, new_n123_, new_n124_, new_n125_, new_n126_, new_n127_,
    new_n128_, new_n129_, new_n131_, new_n132_, new_n133_, new_n134_,
    new_n135_, new_n137_, new_n138_, new_n139_, new_n140_, new_n141_,
    new_n142_, new_n143_, new_n144_, new_n145_, new_n146_, new_n147_,
    new_n148_, new_n149_, new_n150_, new_n152_, new_n153_, new_n154_;
  INVx1_ASAP7_75t_R    g000(.A(p4), .Y(new_n19_));
  INVx1_ASAP7_75t_R    g001(.A(p10), .Y(new_n20_));
  NAND2x1_ASAP7_75t_R  g002(.A(p3), .B(p0), .Y(new_n21_));
  AOI211x1_ASAP7_75t_R g003(.A1(new_n20_), .A2(new_n21_), .B(p6), .C(p5), .Y(new_n22_));
  INVx1_ASAP7_75t_R    g004(.A(p3), .Y(new_n23_));
  NAND2x1_ASAP7_75t_R  g005(.A(p7), .B(new_n23_), .Y(new_n24_));
  AO21x1_ASAP7_75t_R   g006(.A1(new_n21_), .A2(new_n24_), .B(new_n20_), .Y(new_n25_));
  AND2x2_ASAP7_75t_R   g007(.A(p3), .B(p7), .Y(new_n26_));
  AO21x1_ASAP7_75t_R   g008(.A1(new_n22_), .A2(new_n25_), .B(new_n26_), .Y(new_n27_));
  INVx1_ASAP7_75t_R    g009(.A(p6), .Y(new_n28_));
  AOI21x1_ASAP7_75t_R  g010(.A1(p3), .A2(p2), .B(new_n28_), .Y(new_n29_));
  INVx1_ASAP7_75t_R    g011(.A(p2), .Y(new_n30_));
  NAND2x1_ASAP7_75t_R  g012(.A(new_n23_), .B(new_n30_), .Y(new_n31_));
  NOR2x1_ASAP7_75t_R   g013(.A(p6), .B(p1), .Y(new_n32_));
  AND3x1_ASAP7_75t_R   g014(.A(p0), .B(p2), .C(p4), .Y(new_n33_));
  AOI22x1_ASAP7_75t_R  g015(.A1(new_n29_), .A2(new_n31_), .B1(new_n32_), .B2(new_n33_), .Y(new_n34_));
  OAI22x1_ASAP7_75t_R  g016(.A1(new_n34_), .A2(p7), .B1(new_n19_), .B2(new_n24_), .Y(new_n35_));
  AOI21x1_ASAP7_75t_R  g017(.A1(new_n19_), .A2(new_n27_), .B(new_n35_), .Y(new_n36_));
  NOR2x1_ASAP7_75t_R   g018(.A(p9), .B(p8), .Y(new_n37_));
  INVx1_ASAP7_75t_R    g019(.A(new_n37_), .Y(new_n38_));
  INVx1_ASAP7_75t_R    g020(.A(p9), .Y(new_n39_));
  NOR2x1_ASAP7_75t_R   g021(.A(p5), .B(new_n19_), .Y(new_n40_));
  INVx1_ASAP7_75t_R    g022(.A(new_n40_), .Y(new_n41_));
  INVx1_ASAP7_75t_R    g023(.A(p0), .Y(new_n42_));
  NOR2x1_ASAP7_75t_R   g024(.A(p3), .B(new_n28_), .Y(new_n43_));
  AND2x2_ASAP7_75t_R   g025(.A(p3), .B(p2), .Y(new_n44_));
  OR5x1_ASAP7_75t_R    g026(.A(new_n42_), .B(new_n43_), .C(p1), .D(new_n26_), .E(new_n44_), .Y(new_n45_));
  NOR2x1_ASAP7_75t_R   g027(.A(p6), .B(p7), .Y(new_n46_));
  AO31x2_ASAP7_75t_R   g028(.A1(new_n46_), .A2(new_n42_), .A3(p1), .B(p8), .Y(new_n47_));
  AND3x1_ASAP7_75t_R   g029(.A(new_n19_), .B(p5), .C(p8), .Y(new_n48_));
  AOI21x1_ASAP7_75t_R  g030(.A1(new_n40_), .A2(new_n47_), .B(new_n48_), .Y(new_n49_));
  OAI21x1_ASAP7_75t_R  g031(.A1(new_n41_), .A2(new_n45_), .B(new_n49_), .Y(new_n50_));
  INVx1_ASAP7_75t_R    g032(.A(p5), .Y(new_n51_));
  NOR2x1_ASAP7_75t_R   g033(.A(p6), .B(new_n51_), .Y(new_n52_));
  AND3x1_ASAP7_75t_R   g034(.A(p5), .B(p7), .C(p8), .Y(new_n53_));
  NOR2x1_ASAP7_75t_R   g035(.A(p5), .B(new_n28_), .Y(new_n54_));
  OA21x2_ASAP7_75t_R   g036(.A1(new_n53_), .A2(new_n54_), .B(p9), .Y(new_n55_));
  NOR2x1_ASAP7_75t_R   g037(.A(p7), .B(p8), .Y(new_n56_));
  XOR2x2_ASAP7_75t_R   g038(.A(p2), .B(p1), .Y(new_n57_));
  AO21x1_ASAP7_75t_R   g039(.A1(new_n56_), .A2(new_n57_), .B(p9), .Y(new_n58_));
  OA21x2_ASAP7_75t_R   g040(.A1(new_n52_), .A2(new_n55_), .B(new_n58_), .Y(new_n59_));
  AOI21x1_ASAP7_75t_R  g041(.A1(new_n39_), .A2(new_n50_), .B(new_n59_), .Y(new_n60_));
  OAI21x1_ASAP7_75t_R  g042(.A1(new_n36_), .A2(new_n38_), .B(new_n60_), .Y(o0));
  AO21x1_ASAP7_75t_R   g043(.A1(p6), .A2(p5), .B(p7), .Y(new_n62_));
  AO21x1_ASAP7_75t_R   g044(.A1(p6), .A2(new_n39_), .B(new_n62_), .Y(new_n63_));
  NOR3x1_ASAP7_75t_R   g045(.A(new_n51_), .B(p3), .C(p8), .Y(new_n64_));
  NOR3x1_ASAP7_75t_R   g046(.A(new_n19_), .B(p5), .C(p2), .Y(new_n65_));
  INVx1_ASAP7_75t_R    g047(.A(p1), .Y(new_n66_));
  OAI21x1_ASAP7_75t_R  g048(.A1(new_n64_), .A2(new_n65_), .B(new_n66_), .Y(new_n67_));
  NOR3x1_ASAP7_75t_R   g049(.A(new_n19_), .B(p5), .C(p0), .Y(new_n68_));
  OAI21x1_ASAP7_75t_R  g050(.A1(new_n64_), .A2(new_n68_), .B(new_n30_), .Y(new_n69_));
  NAND2x1_ASAP7_75t_R  g051(.A(p3), .B(p2), .Y(new_n70_));
  OR4x2_ASAP7_75t_R    g052(.A(new_n70_), .B(new_n51_), .C(p8), .D(new_n66_), .Y(new_n71_));
  AND4x2_ASAP7_75t_R   g053(.A(new_n67_), .B(new_n69_), .C(new_n39_), .D(new_n71_), .Y(new_n72_));
  INVx1_ASAP7_75t_R    g054(.A(p8), .Y(new_n73_));
  AND4x2_ASAP7_75t_R   g055(.A(p6), .B(p5), .C(p7), .D(p9), .Y(new_n74_));
  NAND2x1_ASAP7_75t_R  g056(.A(new_n73_), .B(new_n74_), .Y(new_n75_));
  OAI21x1_ASAP7_75t_R  g057(.A1(new_n63_), .A2(new_n72_), .B(new_n75_), .Y(new_n76_));
  NOR2x1_ASAP7_75t_R   g058(.A(p3), .B(p8), .Y(new_n77_));
  AO21x1_ASAP7_75t_R   g059(.A1(new_n28_), .A2(p8), .B(new_n77_), .Y(new_n78_));
  AND2x2_ASAP7_75t_R   g060(.A(p5), .B(p4), .Y(new_n79_));
  AOI211x1_ASAP7_75t_R g061(.A1(new_n28_), .A2(p8), .B(new_n77_), .C(new_n79_), .Y(new_n80_));
  AOI211x1_ASAP7_75t_R g062(.A1(p5), .A2(new_n78_), .B(new_n56_), .C(new_n80_), .Y(new_n81_));
  NOR2x1_ASAP7_75t_R   g063(.A(p6), .B(new_n73_), .Y(new_n82_));
  AOI21x1_ASAP7_75t_R  g064(.A1(new_n56_), .A2(new_n29_), .B(new_n82_), .Y(new_n83_));
  NOR3x1_ASAP7_75t_R   g065(.A(p6), .B(p5), .C(p3), .Y(new_n84_));
  NOR3x1_ASAP7_75t_R   g066(.A(new_n23_), .B(p7), .C(p8), .Y(new_n85_));
  NAND2x1_ASAP7_75t_R  g067(.A(p2), .B(p4), .Y(new_n86_));
  AOI21x1_ASAP7_75t_R  g068(.A1(p0), .A2(p1), .B(p6), .Y(new_n87_));
  NOR2x1_ASAP7_75t_R   g069(.A(new_n86_), .B(new_n87_), .Y(new_n88_));
  OAI21x1_ASAP7_75t_R  g070(.A1(new_n84_), .A2(new_n85_), .B(new_n88_), .Y(new_n89_));
  OAI21x1_ASAP7_75t_R  g071(.A1(p4), .A2(new_n83_), .B(new_n89_), .Y(new_n90_));
  OAI22x1_ASAP7_75t_R  g072(.A1(p6), .A2(p1), .B1(p3), .B2(p8), .Y(new_n91_));
  AOI22x1_ASAP7_75t_R  g073(.A1(new_n91_), .A2(new_n42_), .B1(p7), .B2(new_n73_), .Y(new_n92_));
  OAI21x1_ASAP7_75t_R  g074(.A1(new_n42_), .A2(new_n66_), .B(p10), .Y(new_n93_));
  NAND2x1_ASAP7_75t_R  g075(.A(p1), .B(new_n20_), .Y(new_n94_));
  NOR2x1_ASAP7_75t_R   g076(.A(p6), .B(new_n23_), .Y(new_n95_));
  NAND3x1_ASAP7_75t_R  g077(.A(new_n93_), .B(new_n94_), .C(new_n95_), .Y(new_n96_));
  NOR2x1_ASAP7_75t_R   g078(.A(p5), .B(p4), .Y(new_n97_));
  INVx1_ASAP7_75t_R    g079(.A(new_n97_), .Y(new_n98_));
  AOI21x1_ASAP7_75t_R  g080(.A1(new_n92_), .A2(new_n96_), .B(new_n98_), .Y(new_n99_));
  OA31x2_ASAP7_75t_R   g081(.A1(new_n81_), .A2(new_n90_), .A3(new_n99_), .B1(new_n39_), .Y(new_n100_));
  NOR2x1_ASAP7_75t_R   g082(.A(new_n76_), .B(new_n100_), .Y(o1));
  OAI21x1_ASAP7_75t_R  g083(.A1(new_n97_), .A2(new_n33_), .B(new_n23_), .Y(new_n102_));
  AND2x2_ASAP7_75t_R   g084(.A(p10), .B(p0), .Y(new_n103_));
  OR3x1_ASAP7_75t_R    g085(.A(new_n103_), .B(p4), .C(new_n70_), .Y(new_n104_));
  AOI21x1_ASAP7_75t_R  g086(.A1(new_n102_), .A2(new_n104_), .B(new_n66_), .Y(new_n105_));
  NAND2x1_ASAP7_75t_R  g087(.A(p4), .B(new_n30_), .Y(new_n106_));
  AO22x1_ASAP7_75t_R   g088(.A1(p10), .A2(p0), .B1(p2), .B2(new_n66_), .Y(new_n107_));
  NAND3x1_ASAP7_75t_R  g089(.A(new_n107_), .B(new_n51_), .C(new_n57_), .Y(new_n108_));
  AOI21x1_ASAP7_75t_R  g090(.A1(new_n106_), .A2(new_n108_), .B(new_n23_), .Y(new_n109_));
  INVx1_ASAP7_75t_R    g091(.A(p7), .Y(new_n110_));
  AND3x1_ASAP7_75t_R   g092(.A(new_n37_), .B(new_n28_), .C(new_n110_), .Y(new_n111_));
  OAI21x1_ASAP7_75t_R  g093(.A1(new_n105_), .A2(new_n109_), .B(new_n111_), .Y(new_n112_));
  OAI21x1_ASAP7_75t_R  g094(.A1(new_n44_), .A2(new_n79_), .B(new_n110_), .Y(new_n113_));
  AND3x1_ASAP7_75t_R   g095(.A(new_n19_), .B(p5), .C(p1), .Y(new_n114_));
  NOR3x1_ASAP7_75t_R   g096(.A(new_n114_), .B(new_n68_), .C(new_n70_), .Y(new_n115_));
  AND3x1_ASAP7_75t_R   g097(.A(p3), .B(p2), .C(p4), .Y(new_n116_));
  AOI211x1_ASAP7_75t_R g098(.A1(p3), .A2(p4), .B(new_n28_), .C(new_n51_), .Y(new_n117_));
  AND5x1_ASAP7_75t_R   g099(.A(new_n28_), .B(new_n66_), .C(p5), .D(p3), .E(p4), .Y(new_n118_));
  AOI211x1_ASAP7_75t_R g100(.A1(new_n54_), .A2(new_n116_), .B(new_n117_), .C(new_n118_), .Y(new_n119_));
  OAI21x1_ASAP7_75t_R  g101(.A1(new_n113_), .A2(new_n115_), .B(new_n119_), .Y(new_n120_));
  OA21x2_ASAP7_75t_R   g102(.A1(p7), .A2(p9), .B(p8), .Y(new_n121_));
  OR3x1_ASAP7_75t_R    g103(.A(new_n28_), .B(new_n19_), .C(p9), .Y(new_n122_));
  AND5x1_ASAP7_75t_R   g104(.A(p6), .B(new_n110_), .C(p5), .D(p4), .E(p8), .Y(new_n123_));
  AOI211x1_ASAP7_75t_R g105(.A1(new_n121_), .A2(new_n122_), .B(new_n74_), .C(new_n123_), .Y(new_n124_));
  AND3x1_ASAP7_75t_R   g106(.A(new_n79_), .B(new_n28_), .C(p3), .Y(new_n125_));
  NOR2x1_ASAP7_75t_R   g107(.A(p9), .B(new_n110_), .Y(new_n126_));
  OAI21x1_ASAP7_75t_R  g108(.A1(new_n54_), .A2(new_n125_), .B(new_n126_), .Y(new_n127_));
  NAND2x1_ASAP7_75t_R  g109(.A(new_n124_), .B(new_n127_), .Y(new_n128_));
  AOI21x1_ASAP7_75t_R  g110(.A1(new_n37_), .A2(new_n120_), .B(new_n128_), .Y(new_n129_));
  NAND2x1_ASAP7_75t_R  g111(.A(new_n112_), .B(new_n129_), .Y(o2));
  NAND2x1_ASAP7_75t_R  g112(.A(p6), .B(new_n79_), .Y(new_n131_));
  OR3x1_ASAP7_75t_R    g113(.A(new_n23_), .B(new_n110_), .C(p1), .Y(new_n132_));
  INVx1_ASAP7_75t_R    g114(.A(new_n46_), .Y(new_n133_));
  OR3x1_ASAP7_75t_R    g115(.A(new_n133_), .B(new_n98_), .C(p3), .Y(new_n134_));
  OA21x2_ASAP7_75t_R   g116(.A1(new_n131_), .A2(new_n132_), .B(new_n134_), .Y(new_n135_));
  OR3x1_ASAP7_75t_R    g117(.A(new_n135_), .B(p2), .C(new_n38_), .Y(o3));
  AND3x1_ASAP7_75t_R   g118(.A(new_n110_), .B(p2), .C(p1), .Y(new_n137_));
  AO21x1_ASAP7_75t_R   g119(.A1(new_n97_), .A2(new_n103_), .B(new_n125_), .Y(new_n138_));
  AND3x1_ASAP7_75t_R   g120(.A(new_n79_), .B(p6), .C(p7), .Y(new_n139_));
  NOR2x1_ASAP7_75t_R   g121(.A(new_n73_), .B(new_n139_), .Y(new_n140_));
  AO21x1_ASAP7_75t_R   g122(.A1(new_n137_), .A2(new_n138_), .B(new_n140_), .Y(new_n141_));
  AND3x1_ASAP7_75t_R   g123(.A(new_n28_), .B(new_n19_), .C(p3), .Y(new_n142_));
  OR4x2_ASAP7_75t_R    g124(.A(new_n142_), .B(p7), .C(p9), .D(new_n52_), .Y(new_n143_));
  AND3x1_ASAP7_75t_R   g125(.A(new_n28_), .B(p0), .C(p1), .Y(new_n144_));
  OA21x2_ASAP7_75t_R   g126(.A1(new_n79_), .A2(new_n144_), .B(new_n44_), .Y(new_n145_));
  OA21x2_ASAP7_75t_R   g127(.A1(p2), .A2(p1), .B(p3), .Y(new_n146_));
  INVx1_ASAP7_75t_R    g128(.A(new_n146_), .Y(new_n147_));
  NOR2x1_ASAP7_75t_R   g129(.A(p7), .B(new_n30_), .Y(new_n148_));
  OR3x1_ASAP7_75t_R    g130(.A(new_n131_), .B(new_n38_), .C(new_n148_), .Y(new_n149_));
  OAI22x1_ASAP7_75t_R  g131(.A1(new_n143_), .A2(new_n145_), .B1(new_n147_), .B2(new_n149_), .Y(new_n150_));
  AOI21x1_ASAP7_75t_R  g132(.A1(new_n39_), .A2(new_n141_), .B(new_n150_), .Y(o4));
  AO32x1_ASAP7_75t_R   g133(.A1(new_n103_), .A2(new_n137_), .A3(new_n142_), .B1(new_n139_), .B2(new_n146_), .Y(new_n152_));
  AND3x1_ASAP7_75t_R   g134(.A(new_n116_), .B(p5), .C(p1), .Y(new_n153_));
  NOR3x1_ASAP7_75t_R   g135(.A(new_n153_), .B(new_n97_), .C(new_n133_), .Y(new_n154_));
  OR3x1_ASAP7_75t_R    g136(.A(new_n152_), .B(new_n38_), .C(new_n154_), .Y(o5));
  OR3x1_ASAP7_75t_R    g137(.A(new_n153_), .B(new_n38_), .C(new_n133_), .Y(o6));
endmodule


