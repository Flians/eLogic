// Benchmark "/tmp/" written by ABC on Wed Oct 21 14:43:59 2026

module \/tmp/  ( 
    p6, p4, p0, p5, p1, p2, p7, p10, p8, p3, p9,
    o0, o1, o2, o3, o4, o5, o6  );
  input  p6, p4, p0, p5, p1, p2, p7, p10, p8, p3, p9;
  output o0, o1, o2, o3, o4, o5, o6;
  wire new_n19_, new_n20_, new_n21_, new_n22_, new_n23_, new_n24_, new_n25_,
    new_n26_, new_n27_, new_n28_, new_n29_, new_n30_, new_n31_, new_n32_,
    new_n33_, new_n34_, new_n35_, new_n36_, new_n37_, new_n38_, new_n39_,
    new_n40_, new_n41_, new_n42_, new_n43_, new_n44_, new_n45_, new_n46_,
    new_n47_, new_n48_, new_n49_, new_n50_, new_n51_, new_n52_, new_n53_,
    new_n54_, new_n55_, new_n56_, new_n57_, new_n58_, new_n59_, new_n60_,
    new_n61_, new_n62_, new_n63_, new_n64_, new_n65_, new_n67_, new_n68_,
    new_n69_, new_n70_, new_n71_, new_n72_, new_n73_, new_n74_, new_n75_,
    new_n76_, new_n77_, new_n78_, new_n79_, new_n80_, new_n81_, new_n82_,
    new_n83_, new_n84_, new_n85_, new_n86_, new_n87_, new_n88_, new_n89_,
    new_n90_, new_n91_, new_n92_, new_n93_, new_n94_, new_n95_, new_n96_,
    new_n97_, new_n98_, new_n99_, new_n100_, new_n101_, new_n102_,
    new_n104_, new_n105_, new_n106_, new_n107_, new_n108_, new_n109_,
    new_n110_, new_n111_, new_n112_, new_n113_, new_n114_, new_n115_,
    new_n116_, new_n117_, new_n118_, new_n119_, new_n120_, new_n121_,
    new_n122_, new_n123_, new_n124_, new_n125_, new_n126_, new_n127_,
    new_n128_, new_n129_, new_n130_, new_n131_, new_n132_, new_n133_,
    new_n134_, new_n135_, new_n136_, new_n138_, new_n139_, new_n141_,
    new_n142_, new_n143_, new_n144_, new_n145_, new_n146_, new_n147_,
    new_n148_, new_n149_, new_n150_, new_n151_, new_n152_, new_n154_,
    new_n155_, new_n156_, new_n157_;
  INVx1_ASAP7_75t_R    g000(.A(p4), .Y(new_n19_));
  INVx1_ASAP7_75t_R    g001(.A(p10), .Y(new_n20_));
  NAND2x1_ASAP7_75t_R  g002(.A(p0), .B(p3), .Y(new_n21_));
  INVx1_ASAP7_75t_R    g003(.A(p6), .Y(new_n22_));
  INVx1_ASAP7_75t_R    g004(.A(p5), .Y(new_n23_));
  NAND2x1_ASAP7_75t_R  g005(.A(new_n22_), .B(new_n23_), .Y(new_n24_));
  AOI21x1_ASAP7_75t_R  g006(.A1(new_n20_), .A2(new_n21_), .B(new_n24_), .Y(new_n25_));
  INVx1_ASAP7_75t_R    g007(.A(p3), .Y(new_n26_));
  NAND2x1_ASAP7_75t_R  g008(.A(p7), .B(new_n26_), .Y(new_n27_));
  AO21x1_ASAP7_75t_R   g009(.A1(new_n21_), .A2(new_n27_), .B(new_n20_), .Y(new_n28_));
  AND2x2_ASAP7_75t_R   g010(.A(p7), .B(p3), .Y(new_n29_));
  AO21x1_ASAP7_75t_R   g011(.A1(new_n25_), .A2(new_n28_), .B(new_n29_), .Y(new_n30_));
  NAND2x1_ASAP7_75t_R  g012(.A(p4), .B(p2), .Y(new_n31_));
  NOR2x1_ASAP7_75t_R   g013(.A(p6), .B(new_n31_), .Y(new_n32_));
  INVx1_ASAP7_75t_R    g014(.A(p0), .Y(new_n33_));
  NOR2x1_ASAP7_75t_R   g015(.A(p1), .B(new_n33_), .Y(new_n34_));
  INVx1_ASAP7_75t_R    g016(.A(p2), .Y(new_n35_));
  NAND2x1_ASAP7_75t_R  g017(.A(new_n35_), .B(new_n26_), .Y(new_n36_));
  AOI21x1_ASAP7_75t_R  g018(.A1(p2), .A2(p3), .B(new_n22_), .Y(new_n37_));
  AOI22x1_ASAP7_75t_R  g019(.A1(new_n32_), .A2(new_n34_), .B1(new_n36_), .B2(new_n37_), .Y(new_n38_));
  OAI22x1_ASAP7_75t_R  g020(.A1(new_n38_), .A2(p7), .B1(new_n19_), .B2(new_n27_), .Y(new_n39_));
  AOI21x1_ASAP7_75t_R  g021(.A1(new_n19_), .A2(new_n30_), .B(new_n39_), .Y(new_n40_));
  INVx1_ASAP7_75t_R    g022(.A(p8), .Y(new_n41_));
  INVx1_ASAP7_75t_R    g023(.A(p9), .Y(new_n42_));
  NAND2x1_ASAP7_75t_R  g024(.A(new_n41_), .B(new_n42_), .Y(new_n43_));
  NOR2x1_ASAP7_75t_R   g025(.A(p5), .B(new_n19_), .Y(new_n44_));
  INVx1_ASAP7_75t_R    g026(.A(new_n44_), .Y(new_n45_));
  NOR2x1_ASAP7_75t_R   g027(.A(p3), .B(new_n22_), .Y(new_n46_));
  AND2x2_ASAP7_75t_R   g028(.A(p2), .B(p3), .Y(new_n47_));
  OR5x1_ASAP7_75t_R    g029(.A(new_n33_), .B(new_n46_), .C(p1), .D(new_n29_), .E(new_n47_), .Y(new_n48_));
  NOR2x1_ASAP7_75t_R   g030(.A(p6), .B(p7), .Y(new_n49_));
  AO31x2_ASAP7_75t_R   g031(.A1(new_n49_), .A2(new_n33_), .A3(p1), .B(p8), .Y(new_n50_));
  AND3x1_ASAP7_75t_R   g032(.A(new_n19_), .B(p5), .C(p8), .Y(new_n51_));
  AOI21x1_ASAP7_75t_R  g033(.A1(new_n44_), .A2(new_n50_), .B(new_n51_), .Y(new_n52_));
  OAI21x1_ASAP7_75t_R  g034(.A1(new_n45_), .A2(new_n48_), .B(new_n52_), .Y(new_n53_));
  NOR2x1_ASAP7_75t_R   g035(.A(p1), .B(p2), .Y(new_n54_));
  INVx1_ASAP7_75t_R    g036(.A(new_n54_), .Y(new_n55_));
  INVx1_ASAP7_75t_R    g037(.A(p1), .Y(new_n56_));
  NOR2x1_ASAP7_75t_R   g038(.A(p7), .B(p8), .Y(new_n57_));
  OA21x2_ASAP7_75t_R   g039(.A1(new_n56_), .A2(new_n35_), .B(new_n57_), .Y(new_n58_));
  NAND2x1_ASAP7_75t_R  g040(.A(new_n55_), .B(new_n58_), .Y(new_n59_));
  AND3x1_ASAP7_75t_R   g041(.A(p5), .B(p7), .C(p8), .Y(new_n60_));
  NOR2x1_ASAP7_75t_R   g042(.A(p5), .B(new_n22_), .Y(new_n61_));
  OAI21x1_ASAP7_75t_R  g043(.A1(new_n60_), .A2(new_n61_), .B(p9), .Y(new_n62_));
  NAND2x1_ASAP7_75t_R  g044(.A(p5), .B(new_n22_), .Y(new_n63_));
  AOI22x1_ASAP7_75t_R  g045(.A1(new_n59_), .A2(new_n42_), .B1(new_n62_), .B2(new_n63_), .Y(new_n64_));
  AOI21x1_ASAP7_75t_R  g046(.A1(new_n42_), .A2(new_n53_), .B(new_n64_), .Y(new_n65_));
  OAI21x1_ASAP7_75t_R  g047(.A1(new_n40_), .A2(new_n43_), .B(new_n65_), .Y(o0));
  AO21x1_ASAP7_75t_R   g048(.A1(p6), .A2(p5), .B(p7), .Y(new_n67_));
  AO21x1_ASAP7_75t_R   g049(.A1(p6), .A2(new_n42_), .B(new_n67_), .Y(new_n68_));
  NOR3x1_ASAP7_75t_R   g050(.A(new_n23_), .B(p8), .C(p3), .Y(new_n69_));
  NOR3x1_ASAP7_75t_R   g051(.A(new_n19_), .B(p0), .C(p5), .Y(new_n70_));
  OAI21x1_ASAP7_75t_R  g052(.A1(new_n69_), .A2(new_n70_), .B(new_n35_), .Y(new_n71_));
  NOR3x1_ASAP7_75t_R   g053(.A(new_n19_), .B(p5), .C(p2), .Y(new_n72_));
  OAI21x1_ASAP7_75t_R  g054(.A1(new_n69_), .A2(new_n72_), .B(new_n56_), .Y(new_n73_));
  NAND2x1_ASAP7_75t_R  g055(.A(p2), .B(p3), .Y(new_n74_));
  OR4x2_ASAP7_75t_R    g056(.A(new_n74_), .B(new_n23_), .C(new_n56_), .D(p8), .Y(new_n75_));
  AND4x2_ASAP7_75t_R   g057(.A(new_n71_), .B(new_n73_), .C(new_n42_), .D(new_n75_), .Y(new_n76_));
  INVx1_ASAP7_75t_R    g058(.A(p7), .Y(new_n77_));
  OR5x1_ASAP7_75t_R    g059(.A(new_n22_), .B(new_n23_), .C(new_n77_), .D(new_n42_), .E(p8), .Y(new_n78_));
  OAI21x1_ASAP7_75t_R  g060(.A1(new_n68_), .A2(new_n76_), .B(new_n78_), .Y(new_n79_));
  NOR2x1_ASAP7_75t_R   g061(.A(p8), .B(p3), .Y(new_n80_));
  AO21x1_ASAP7_75t_R   g062(.A1(new_n22_), .A2(p8), .B(new_n80_), .Y(new_n81_));
  AND2x2_ASAP7_75t_R   g063(.A(p4), .B(p5), .Y(new_n82_));
  AOI211x1_ASAP7_75t_R g064(.A1(new_n22_), .A2(p8), .B(new_n80_), .C(new_n82_), .Y(new_n83_));
  AOI211x1_ASAP7_75t_R g065(.A1(p5), .A2(new_n81_), .B(new_n57_), .C(new_n83_), .Y(new_n84_));
  NOR2x1_ASAP7_75t_R   g066(.A(p6), .B(new_n41_), .Y(new_n85_));
  AOI21x1_ASAP7_75t_R  g067(.A1(new_n57_), .A2(new_n37_), .B(new_n85_), .Y(new_n86_));
  NOR3x1_ASAP7_75t_R   g068(.A(p6), .B(p5), .C(p3), .Y(new_n87_));
  NOR3x1_ASAP7_75t_R   g069(.A(new_n26_), .B(p7), .C(p8), .Y(new_n88_));
  AOI21x1_ASAP7_75t_R  g070(.A1(p0), .A2(p1), .B(p6), .Y(new_n89_));
  NOR2x1_ASAP7_75t_R   g071(.A(new_n31_), .B(new_n89_), .Y(new_n90_));
  OAI21x1_ASAP7_75t_R  g072(.A1(new_n87_), .A2(new_n88_), .B(new_n90_), .Y(new_n91_));
  OAI21x1_ASAP7_75t_R  g073(.A1(p4), .A2(new_n86_), .B(new_n91_), .Y(new_n92_));
  OAI22x1_ASAP7_75t_R  g074(.A1(p6), .A2(p1), .B1(p8), .B2(p3), .Y(new_n93_));
  AOI22x1_ASAP7_75t_R  g075(.A1(new_n93_), .A2(new_n33_), .B1(p7), .B2(new_n41_), .Y(new_n94_));
  NAND2x1_ASAP7_75t_R  g076(.A(p0), .B(p10), .Y(new_n95_));
  NAND2x1_ASAP7_75t_R  g077(.A(p1), .B(new_n95_), .Y(new_n96_));
  NOR2x1_ASAP7_75t_R   g078(.A(p6), .B(new_n26_), .Y(new_n97_));
  NAND2x1_ASAP7_75t_R  g079(.A(p10), .B(new_n56_), .Y(new_n98_));
  NAND3x1_ASAP7_75t_R  g080(.A(new_n96_), .B(new_n97_), .C(new_n98_), .Y(new_n99_));
  NAND2x1_ASAP7_75t_R  g081(.A(new_n19_), .B(new_n23_), .Y(new_n100_));
  AOI21x1_ASAP7_75t_R  g082(.A1(new_n94_), .A2(new_n99_), .B(new_n100_), .Y(new_n101_));
  OA31x2_ASAP7_75t_R   g083(.A1(new_n84_), .A2(new_n92_), .A3(new_n101_), .B1(new_n42_), .Y(new_n102_));
  NOR2x1_ASAP7_75t_R   g084(.A(new_n79_), .B(new_n102_), .Y(o1));
  NOR2x1_ASAP7_75t_R   g085(.A(p2), .B(new_n19_), .Y(new_n104_));
  AND3x1_ASAP7_75t_R   g086(.A(new_n23_), .B(new_n56_), .C(p2), .Y(new_n105_));
  OAI21x1_ASAP7_75t_R  g087(.A1(new_n104_), .A2(new_n105_), .B(p3), .Y(new_n106_));
  NOR2x1_ASAP7_75t_R   g088(.A(p4), .B(new_n74_), .Y(new_n107_));
  AND3x1_ASAP7_75t_R   g089(.A(new_n19_), .B(new_n23_), .C(new_n26_), .Y(new_n108_));
  AOI21x1_ASAP7_75t_R  g090(.A1(new_n95_), .A2(new_n107_), .B(new_n108_), .Y(new_n109_));
  NOR3x1_ASAP7_75t_R   g091(.A(new_n20_), .B(p5), .C(p2), .Y(new_n110_));
  AOI21x1_ASAP7_75t_R  g092(.A1(new_n26_), .A2(new_n31_), .B(new_n33_), .Y(new_n111_));
  OAI21x1_ASAP7_75t_R  g093(.A1(new_n26_), .A2(new_n110_), .B(new_n111_), .Y(new_n112_));
  NAND3x1_ASAP7_75t_R  g094(.A(new_n106_), .B(new_n109_), .C(new_n112_), .Y(new_n113_));
  INVx1_ASAP7_75t_R    g095(.A(new_n49_), .Y(new_n114_));
  AOI21x1_ASAP7_75t_R  g096(.A1(new_n56_), .A2(new_n106_), .B(new_n114_), .Y(new_n115_));
  AND3x1_ASAP7_75t_R   g097(.A(new_n19_), .B(p5), .C(p1), .Y(new_n116_));
  NOR3x1_ASAP7_75t_R   g098(.A(new_n116_), .B(new_n70_), .C(new_n74_), .Y(new_n117_));
  INVx1_ASAP7_75t_R    g099(.A(new_n82_), .Y(new_n118_));
  AO21x1_ASAP7_75t_R   g100(.A1(new_n74_), .A2(new_n118_), .B(p7), .Y(new_n119_));
  AND3x1_ASAP7_75t_R   g101(.A(p4), .B(p2), .C(p3), .Y(new_n120_));
  NAND2x1_ASAP7_75t_R  g102(.A(p4), .B(p3), .Y(new_n121_));
  AND3x1_ASAP7_75t_R   g103(.A(new_n121_), .B(p6), .C(p5), .Y(new_n122_));
  AND5x1_ASAP7_75t_R   g104(.A(new_n22_), .B(new_n56_), .C(p4), .D(p5), .E(p3), .Y(new_n123_));
  AOI211x1_ASAP7_75t_R g105(.A1(new_n61_), .A2(new_n120_), .B(new_n122_), .C(new_n123_), .Y(new_n124_));
  OAI21x1_ASAP7_75t_R  g106(.A1(new_n117_), .A2(new_n119_), .B(new_n124_), .Y(new_n125_));
  AOI21x1_ASAP7_75t_R  g107(.A1(new_n113_), .A2(new_n115_), .B(new_n125_), .Y(new_n126_));
  NOR2x1_ASAP7_75t_R   g108(.A(p9), .B(new_n77_), .Y(new_n127_));
  AND2x2_ASAP7_75t_R   g109(.A(p6), .B(p4), .Y(new_n128_));
  AND3x1_ASAP7_75t_R   g110(.A(p6), .B(p4), .C(p5), .Y(new_n129_));
  INVx1_ASAP7_75t_R    g111(.A(new_n129_), .Y(new_n130_));
  NOR2x1_ASAP7_75t_R   g112(.A(p7), .B(p9), .Y(new_n131_));
  AO221x2_ASAP7_75t_R  g113(.A1(new_n127_), .A2(new_n128_), .B1(new_n130_), .B2(new_n131_), .C(new_n41_), .Y(new_n132_));
  OR4x2_ASAP7_75t_R    g114(.A(new_n22_), .B(new_n23_), .C(new_n77_), .D(new_n42_), .Y(new_n133_));
  NOR2x1_ASAP7_75t_R   g115(.A(new_n121_), .B(new_n63_), .Y(new_n134_));
  OAI21x1_ASAP7_75t_R  g116(.A1(new_n61_), .A2(new_n134_), .B(new_n127_), .Y(new_n135_));
  AND3x1_ASAP7_75t_R   g117(.A(new_n132_), .B(new_n133_), .C(new_n135_), .Y(new_n136_));
  OAI21x1_ASAP7_75t_R  g118(.A1(new_n43_), .A2(new_n126_), .B(new_n136_), .Y(o2));
  AND3x1_ASAP7_75t_R   g119(.A(new_n129_), .B(new_n29_), .C(new_n56_), .Y(new_n138_));
  AOI21x1_ASAP7_75t_R  g120(.A1(new_n49_), .A2(new_n108_), .B(new_n138_), .Y(new_n139_));
  OR3x1_ASAP7_75t_R    g121(.A(new_n139_), .B(p2), .C(new_n43_), .Y(o3));
  AND2x2_ASAP7_75t_R   g122(.A(p0), .B(p10), .Y(new_n141_));
  AND3x1_ASAP7_75t_R   g123(.A(new_n141_), .B(new_n19_), .C(new_n23_), .Y(new_n142_));
  AND3x1_ASAP7_75t_R   g124(.A(new_n77_), .B(p1), .C(p2), .Y(new_n143_));
  OA21x2_ASAP7_75t_R   g125(.A1(new_n134_), .A2(new_n142_), .B(new_n143_), .Y(new_n144_));
  NAND2x1_ASAP7_75t_R  g126(.A(p2), .B(new_n77_), .Y(new_n145_));
  AND5x1_ASAP7_75t_R   g127(.A(new_n41_), .B(new_n55_), .C(new_n145_), .D(p3), .E(new_n129_), .Y(new_n146_));
  OA21x2_ASAP7_75t_R   g128(.A1(new_n77_), .A2(new_n130_), .B(p8), .Y(new_n147_));
  OR3x1_ASAP7_75t_R    g129(.A(new_n144_), .B(new_n146_), .C(new_n147_), .Y(new_n148_));
  OR3x1_ASAP7_75t_R    g130(.A(new_n33_), .B(new_n56_), .C(p6), .Y(new_n149_));
  AO21x1_ASAP7_75t_R   g131(.A1(new_n118_), .A2(new_n149_), .B(new_n74_), .Y(new_n150_));
  OR3x1_ASAP7_75t_R    g132(.A(new_n26_), .B(p6), .C(p4), .Y(new_n151_));
  AND3x1_ASAP7_75t_R   g133(.A(new_n150_), .B(new_n63_), .C(new_n151_), .Y(new_n152_));
  AOI22x1_ASAP7_75t_R  g134(.A1(new_n148_), .A2(new_n42_), .B1(new_n131_), .B2(new_n152_), .Y(o4));
  AND3x1_ASAP7_75t_R   g135(.A(new_n120_), .B(p5), .C(p1), .Y(new_n154_));
  NOR2x1_ASAP7_75t_R   g136(.A(new_n114_), .B(new_n154_), .Y(new_n155_));
  AND3x1_ASAP7_75t_R   g137(.A(new_n141_), .B(new_n22_), .C(new_n19_), .Y(new_n156_));
  AO32x1_ASAP7_75t_R   g138(.A1(p7), .A2(new_n55_), .A3(new_n129_), .B1(new_n156_), .B2(new_n143_), .Y(new_n157_));
  AO221x2_ASAP7_75t_R  g139(.A1(new_n100_), .A2(new_n155_), .B1(new_n157_), .B2(p3), .C(new_n43_), .Y(o5));
  OR3x1_ASAP7_75t_R    g140(.A(new_n154_), .B(new_n43_), .C(new_n114_), .Y(o6));
endmodule


