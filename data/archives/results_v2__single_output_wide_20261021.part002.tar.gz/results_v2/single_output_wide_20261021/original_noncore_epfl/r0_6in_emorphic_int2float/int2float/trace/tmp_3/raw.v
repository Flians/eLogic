// Benchmark "/tmp/" written by ABC on Wed Oct 21 14:43:51 2026

module \/tmp/  ( 
    p9, p10, p4, p6, p1, p8, p2, p7, p0, p5, p3,
    o0, o1, o2, o3, o4, o5, o6  );
  input  p9, p10, p4, p6, p1, p8, p2, p7, p0, p5, p3;
  output o0, o1, o2, o3, o4, o5, o6;
  wire new_n19_, new_n20_, new_n21_, new_n22_, new_n23_, new_n24_, new_n25_,
    new_n26_, new_n27_, new_n28_, new_n29_, new_n30_, new_n31_, new_n32_,
    new_n33_, new_n34_, new_n35_, new_n36_, new_n37_, new_n38_, new_n39_,
    new_n40_, new_n41_, new_n42_, new_n43_, new_n44_, new_n45_, new_n46_,
    new_n47_, new_n48_, new_n49_, new_n50_, new_n51_, new_n52_, new_n53_,
    new_n54_, new_n55_, new_n56_, new_n57_, new_n58_, new_n59_, new_n60_,
    new_n61_, new_n62_, new_n63_, new_n64_, new_n65_, new_n67_, new_n68_,
    new_n69_, new_n70_, new_n71_, new_n72_, new_n73_, new_n74_, new_n75_,
    new_n76_, new_n77_, new_n78_, new_n79_, new_n80_, new_n81_, new_n82_,
    new_n83_, new_n84_, new_n85_, new_n86_, new_n87_, new_n88_, new_n89_,
    new_n90_, new_n91_, new_n92_, new_n93_, new_n94_, new_n95_, new_n96_,
    new_n97_, new_n98_, new_n99_, new_n100_, new_n101_, new_n102_,
    new_n103_, new_n104_, new_n106_, new_n107_, new_n108_, new_n109_,
    new_n110_, new_n111_, new_n112_, new_n113_, new_n114_, new_n115_,
    new_n116_, new_n117_, new_n118_, new_n119_, new_n120_, new_n121_,
    new_n122_, new_n123_, new_n124_, new_n125_, new_n126_, new_n127_,
    new_n128_, new_n129_, new_n130_, new_n131_, new_n132_, new_n133_,
    new_n134_, new_n135_, new_n137_, new_n138_, new_n139_, new_n141_,
    new_n142_, new_n143_, new_n144_, new_n145_, new_n146_, new_n147_,
    new_n148_, new_n149_, new_n150_, new_n151_, new_n153_, new_n154_,
    new_n155_, new_n156_, new_n157_;
  INVx1_ASAP7_75t_R    g000(.A(p4), .Y(new_n19_));
  INVx1_ASAP7_75t_R    g001(.A(p10), .Y(new_n20_));
  NAND2x1_ASAP7_75t_R  g002(.A(p0), .B(p3), .Y(new_n21_));
  AOI211x1_ASAP7_75t_R g003(.A1(new_n20_), .A2(new_n21_), .B(p6), .C(p5), .Y(new_n22_));
  INVx1_ASAP7_75t_R    g004(.A(p3), .Y(new_n23_));
  NAND2x1_ASAP7_75t_R  g005(.A(p7), .B(new_n23_), .Y(new_n24_));
  AO21x1_ASAP7_75t_R   g006(.A1(new_n21_), .A2(new_n24_), .B(new_n20_), .Y(new_n25_));
  NAND2x1_ASAP7_75t_R  g007(.A(p7), .B(p3), .Y(new_n26_));
  INVx1_ASAP7_75t_R    g008(.A(new_n26_), .Y(new_n27_));
  AO21x1_ASAP7_75t_R   g009(.A1(new_n22_), .A2(new_n25_), .B(new_n27_), .Y(new_n28_));
  INVx1_ASAP7_75t_R    g010(.A(p6), .Y(new_n29_));
  AOI21x1_ASAP7_75t_R  g011(.A1(p2), .A2(p3), .B(new_n29_), .Y(new_n30_));
  INVx1_ASAP7_75t_R    g012(.A(p2), .Y(new_n31_));
  NAND2x1_ASAP7_75t_R  g013(.A(new_n31_), .B(new_n23_), .Y(new_n32_));
  NOR2x1_ASAP7_75t_R   g014(.A(p6), .B(p1), .Y(new_n33_));
  AND3x1_ASAP7_75t_R   g015(.A(p4), .B(p2), .C(p0), .Y(new_n34_));
  AOI22x1_ASAP7_75t_R  g016(.A1(new_n30_), .A2(new_n32_), .B1(new_n33_), .B2(new_n34_), .Y(new_n35_));
  OAI22x1_ASAP7_75t_R  g017(.A1(new_n35_), .A2(p7), .B1(new_n19_), .B2(new_n24_), .Y(new_n36_));
  AOI21x1_ASAP7_75t_R  g018(.A1(new_n19_), .A2(new_n28_), .B(new_n36_), .Y(new_n37_));
  NOR2x1_ASAP7_75t_R   g019(.A(p9), .B(p8), .Y(new_n38_));
  INVx1_ASAP7_75t_R    g020(.A(new_n38_), .Y(new_n39_));
  INVx1_ASAP7_75t_R    g021(.A(p9), .Y(new_n40_));
  INVx1_ASAP7_75t_R    g022(.A(p0), .Y(new_n41_));
  AOI211x1_ASAP7_75t_R g023(.A1(p6), .A2(new_n23_), .B(p1), .C(new_n41_), .Y(new_n42_));
  NAND2x1_ASAP7_75t_R  g024(.A(p2), .B(p3), .Y(new_n43_));
  NAND3x1_ASAP7_75t_R  g025(.A(new_n42_), .B(new_n26_), .C(new_n43_), .Y(new_n44_));
  NOR2x1_ASAP7_75t_R   g026(.A(p5), .B(new_n19_), .Y(new_n45_));
  INVx1_ASAP7_75t_R    g027(.A(new_n45_), .Y(new_n46_));
  NOR2x1_ASAP7_75t_R   g028(.A(p6), .B(p7), .Y(new_n47_));
  AO31x2_ASAP7_75t_R   g029(.A1(new_n47_), .A2(p1), .A3(new_n41_), .B(p8), .Y(new_n48_));
  AND2x2_ASAP7_75t_R   g030(.A(p8), .B(p5), .Y(new_n49_));
  AOI22x1_ASAP7_75t_R  g031(.A1(new_n48_), .A2(new_n45_), .B1(new_n19_), .B2(new_n49_), .Y(new_n50_));
  OAI21x1_ASAP7_75t_R  g032(.A1(new_n44_), .A2(new_n46_), .B(new_n50_), .Y(new_n51_));
  INVx1_ASAP7_75t_R    g033(.A(p5), .Y(new_n52_));
  NOR2x1_ASAP7_75t_R   g034(.A(p6), .B(new_n52_), .Y(new_n53_));
  INVx1_ASAP7_75t_R    g035(.A(new_n53_), .Y(new_n54_));
  NOR2x1_ASAP7_75t_R   g036(.A(p1), .B(p2), .Y(new_n55_));
  INVx1_ASAP7_75t_R    g037(.A(new_n55_), .Y(new_n56_));
  INVx1_ASAP7_75t_R    g038(.A(p1), .Y(new_n57_));
  NOR2x1_ASAP7_75t_R   g039(.A(p8), .B(p7), .Y(new_n58_));
  OA21x2_ASAP7_75t_R   g040(.A1(new_n57_), .A2(new_n31_), .B(new_n58_), .Y(new_n59_));
  AOI21x1_ASAP7_75t_R  g041(.A1(new_n56_), .A2(new_n59_), .B(p9), .Y(new_n60_));
  NAND2x1_ASAP7_75t_R  g042(.A(p6), .B(new_n52_), .Y(new_n61_));
  NAND2x1_ASAP7_75t_R  g043(.A(p7), .B(new_n49_), .Y(new_n62_));
  AO21x1_ASAP7_75t_R   g044(.A1(new_n61_), .A2(new_n62_), .B(new_n40_), .Y(new_n63_));
  OAI21x1_ASAP7_75t_R  g045(.A1(new_n54_), .A2(new_n60_), .B(new_n63_), .Y(new_n64_));
  AOI21x1_ASAP7_75t_R  g046(.A1(new_n40_), .A2(new_n51_), .B(new_n64_), .Y(new_n65_));
  OAI21x1_ASAP7_75t_R  g047(.A1(new_n37_), .A2(new_n39_), .B(new_n65_), .Y(o0));
  INVx1_ASAP7_75t_R    g048(.A(p8), .Y(new_n67_));
  NOR2x1_ASAP7_75t_R   g049(.A(p6), .B(new_n67_), .Y(new_n68_));
  AO21x1_ASAP7_75t_R   g050(.A1(new_n58_), .A2(new_n30_), .B(new_n68_), .Y(new_n69_));
  AND2x2_ASAP7_75t_R   g051(.A(p1), .B(p0), .Y(new_n70_));
  OA211x2_ASAP7_75t_R  g052(.A1(p6), .A2(new_n70_), .B(p4), .C(p2), .Y(new_n71_));
  INVx1_ASAP7_75t_R    g053(.A(p7), .Y(new_n72_));
  NOR2x1_ASAP7_75t_R   g054(.A(p5), .B(p3), .Y(new_n73_));
  AO32x1_ASAP7_75t_R   g055(.A1(new_n67_), .A2(new_n72_), .A3(p3), .B1(new_n73_), .B2(new_n29_), .Y(new_n74_));
  AOI22x1_ASAP7_75t_R  g056(.A1(new_n69_), .A2(new_n19_), .B1(new_n71_), .B2(new_n74_), .Y(new_n75_));
  NAND2x1_ASAP7_75t_R  g057(.A(new_n67_), .B(new_n23_), .Y(new_n76_));
  NAND2x1_ASAP7_75t_R  g058(.A(p8), .B(new_n29_), .Y(new_n77_));
  AND2x2_ASAP7_75t_R   g059(.A(p4), .B(p5), .Y(new_n78_));
  AND3x1_ASAP7_75t_R   g060(.A(new_n76_), .B(new_n77_), .C(new_n78_), .Y(new_n79_));
  AOI21x1_ASAP7_75t_R  g061(.A1(new_n77_), .A2(new_n76_), .B(p5), .Y(new_n80_));
  OAI22x1_ASAP7_75t_R  g062(.A1(new_n79_), .A2(new_n80_), .B1(p8), .B2(p7), .Y(new_n81_));
  OAI22x1_ASAP7_75t_R  g063(.A1(p6), .A2(p1), .B1(p8), .B2(p3), .Y(new_n82_));
  AO22x1_ASAP7_75t_R   g064(.A1(new_n67_), .A2(p7), .B1(new_n41_), .B2(new_n82_), .Y(new_n83_));
  NAND2x1_ASAP7_75t_R  g065(.A(p1), .B(p0), .Y(new_n84_));
  NAND2x1_ASAP7_75t_R  g066(.A(p3), .B(new_n29_), .Y(new_n85_));
  NOR2x1_ASAP7_75t_R   g067(.A(p10), .B(new_n57_), .Y(new_n86_));
  AOI211x1_ASAP7_75t_R g068(.A1(p10), .A2(new_n84_), .B(new_n85_), .C(new_n86_), .Y(new_n87_));
  NOR2x1_ASAP7_75t_R   g069(.A(p4), .B(p5), .Y(new_n88_));
  OAI21x1_ASAP7_75t_R  g070(.A1(new_n83_), .A2(new_n87_), .B(new_n88_), .Y(new_n89_));
  NAND3x1_ASAP7_75t_R  g071(.A(new_n75_), .B(new_n81_), .C(new_n89_), .Y(new_n90_));
  AO21x1_ASAP7_75t_R   g072(.A1(p6), .A2(p5), .B(p7), .Y(new_n91_));
  AO21x1_ASAP7_75t_R   g073(.A1(new_n40_), .A2(p6), .B(new_n91_), .Y(new_n92_));
  NOR3x1_ASAP7_75t_R   g074(.A(new_n52_), .B(p8), .C(p3), .Y(new_n93_));
  NOR3x1_ASAP7_75t_R   g075(.A(new_n19_), .B(p0), .C(p5), .Y(new_n94_));
  OAI21x1_ASAP7_75t_R  g076(.A1(new_n93_), .A2(new_n94_), .B(new_n31_), .Y(new_n95_));
  NOR2x1_ASAP7_75t_R   g077(.A(p8), .B(new_n23_), .Y(new_n96_));
  AND3x1_ASAP7_75t_R   g078(.A(p1), .B(p2), .C(p5), .Y(new_n97_));
  AOI22x1_ASAP7_75t_R  g079(.A1(new_n55_), .A2(new_n45_), .B1(new_n96_), .B2(new_n97_), .Y(new_n98_));
  OR4x2_ASAP7_75t_R    g080(.A(new_n52_), .B(p1), .C(p8), .D(p3), .Y(new_n99_));
  AND4x2_ASAP7_75t_R   g081(.A(new_n95_), .B(new_n98_), .C(new_n40_), .D(new_n99_), .Y(new_n100_));
  AND2x2_ASAP7_75t_R   g082(.A(p6), .B(p5), .Y(new_n101_));
  AND3x1_ASAP7_75t_R   g083(.A(new_n101_), .B(p9), .C(p7), .Y(new_n102_));
  NAND2x1_ASAP7_75t_R  g084(.A(new_n67_), .B(new_n102_), .Y(new_n103_));
  OAI21x1_ASAP7_75t_R  g085(.A1(new_n92_), .A2(new_n100_), .B(new_n103_), .Y(new_n104_));
  AOI21x1_ASAP7_75t_R  g086(.A1(new_n40_), .A2(new_n90_), .B(new_n104_), .Y(o1));
  AND3x1_ASAP7_75t_R   g087(.A(new_n23_), .B(p4), .C(p2), .Y(new_n106_));
  NAND2x1_ASAP7_75t_R  g088(.A(p3), .B(new_n31_), .Y(new_n107_));
  NOR3x1_ASAP7_75t_R   g089(.A(new_n107_), .B(new_n20_), .C(p5), .Y(new_n108_));
  OAI21x1_ASAP7_75t_R  g090(.A1(new_n106_), .A2(new_n108_), .B(new_n70_), .Y(new_n109_));
  AND2x2_ASAP7_75t_R   g091(.A(p10), .B(p0), .Y(new_n110_));
  NOR2x1_ASAP7_75t_R   g092(.A(new_n43_), .B(new_n110_), .Y(new_n111_));
  NOR2x1_ASAP7_75t_R   g093(.A(p4), .B(new_n57_), .Y(new_n112_));
  OAI21x1_ASAP7_75t_R  g094(.A1(new_n73_), .A2(new_n111_), .B(new_n112_), .Y(new_n113_));
  OR3x1_ASAP7_75t_R    g095(.A(new_n43_), .B(p1), .C(p5), .Y(new_n114_));
  OA21x2_ASAP7_75t_R   g096(.A1(new_n19_), .A2(new_n107_), .B(new_n114_), .Y(new_n115_));
  NAND2x1_ASAP7_75t_R  g097(.A(new_n38_), .B(new_n47_), .Y(new_n116_));
  AO31x2_ASAP7_75t_R   g098(.A1(new_n109_), .A2(new_n113_), .A3(new_n115_), .B(new_n116_), .Y(new_n117_));
  OR3x1_ASAP7_75t_R    g099(.A(new_n57_), .B(new_n52_), .C(p4), .Y(new_n118_));
  NOR2x1_ASAP7_75t_R   g100(.A(new_n43_), .B(new_n94_), .Y(new_n119_));
  NAND2x1_ASAP7_75t_R  g101(.A(p4), .B(p5), .Y(new_n120_));
  AO21x1_ASAP7_75t_R   g102(.A1(new_n43_), .A2(new_n120_), .B(p7), .Y(new_n121_));
  AOI21x1_ASAP7_75t_R  g103(.A1(new_n118_), .A2(new_n119_), .B(new_n121_), .Y(new_n122_));
  OA21x2_ASAP7_75t_R   g104(.A1(new_n19_), .A2(new_n23_), .B(new_n101_), .Y(new_n123_));
  AND5x1_ASAP7_75t_R   g105(.A(p4), .B(new_n52_), .C(p6), .D(p2), .E(p3), .Y(new_n124_));
  AND5x1_ASAP7_75t_R   g106(.A(p4), .B(new_n29_), .C(new_n57_), .D(p5), .E(p3), .Y(new_n125_));
  OR3x1_ASAP7_75t_R    g107(.A(new_n123_), .B(new_n124_), .C(new_n125_), .Y(new_n126_));
  OAI21x1_ASAP7_75t_R  g108(.A1(new_n122_), .A2(new_n126_), .B(new_n38_), .Y(new_n127_));
  NAND2x1_ASAP7_75t_R  g109(.A(p6), .B(new_n78_), .Y(new_n128_));
  AND3x1_ASAP7_75t_R   g110(.A(new_n128_), .B(new_n40_), .C(new_n72_), .Y(new_n129_));
  AND2x2_ASAP7_75t_R   g111(.A(p4), .B(p6), .Y(new_n130_));
  NOR2x1_ASAP7_75t_R   g112(.A(p9), .B(new_n72_), .Y(new_n131_));
  AO21x1_ASAP7_75t_R   g113(.A1(new_n130_), .A2(new_n131_), .B(new_n67_), .Y(new_n132_));
  OAI21x1_ASAP7_75t_R  g114(.A1(new_n120_), .A2(new_n85_), .B(new_n61_), .Y(new_n133_));
  AOI21x1_ASAP7_75t_R  g115(.A1(new_n131_), .A2(new_n133_), .B(new_n102_), .Y(new_n134_));
  OA21x2_ASAP7_75t_R   g116(.A1(new_n129_), .A2(new_n132_), .B(new_n134_), .Y(new_n135_));
  NAND3x1_ASAP7_75t_R  g117(.A(new_n117_), .B(new_n127_), .C(new_n135_), .Y(o2));
  OR5x1_ASAP7_75t_R    g118(.A(p4), .B(p6), .C(p7), .D(p5), .E(p3), .Y(new_n137_));
  OR3x1_ASAP7_75t_R    g119(.A(new_n128_), .B(p1), .C(new_n26_), .Y(new_n138_));
  OR3x1_ASAP7_75t_R    g120(.A(p9), .B(p8), .C(p2), .Y(new_n139_));
  AO21x1_ASAP7_75t_R   g121(.A1(new_n137_), .A2(new_n138_), .B(new_n139_), .Y(o3));
  AND3x1_ASAP7_75t_R   g122(.A(new_n72_), .B(p1), .C(p2), .Y(new_n141_));
  AO32x1_ASAP7_75t_R   g123(.A1(new_n78_), .A2(new_n29_), .A3(p3), .B1(new_n110_), .B2(new_n88_), .Y(new_n142_));
  OA21x2_ASAP7_75t_R   g124(.A1(new_n72_), .A2(new_n128_), .B(p8), .Y(new_n143_));
  AO21x1_ASAP7_75t_R   g125(.A1(new_n141_), .A2(new_n142_), .B(new_n143_), .Y(new_n144_));
  AO21x1_ASAP7_75t_R   g126(.A1(new_n29_), .A2(new_n70_), .B(new_n78_), .Y(new_n145_));
  AND3x1_ASAP7_75t_R   g127(.A(new_n145_), .B(p2), .C(p3), .Y(new_n146_));
  AND3x1_ASAP7_75t_R   g128(.A(new_n19_), .B(new_n29_), .C(p3), .Y(new_n147_));
  OR4x2_ASAP7_75t_R    g129(.A(new_n147_), .B(p9), .C(p7), .D(new_n53_), .Y(new_n148_));
  AO21x1_ASAP7_75t_R   g130(.A1(new_n26_), .A2(new_n107_), .B(new_n39_), .Y(new_n149_));
  OR3x1_ASAP7_75t_R    g131(.A(new_n149_), .B(new_n55_), .C(new_n128_), .Y(new_n150_));
  OAI21x1_ASAP7_75t_R  g132(.A1(new_n146_), .A2(new_n148_), .B(new_n150_), .Y(new_n151_));
  AOI21x1_ASAP7_75t_R  g133(.A1(new_n40_), .A2(new_n144_), .B(new_n151_), .Y(o4));
  AND3x1_ASAP7_75t_R   g134(.A(new_n56_), .B(p6), .C(new_n78_), .Y(new_n153_));
  AO32x1_ASAP7_75t_R   g135(.A1(new_n110_), .A2(new_n141_), .A3(new_n147_), .B1(new_n153_), .B2(new_n27_), .Y(new_n154_));
  AND5x1_ASAP7_75t_R   g136(.A(p4), .B(p1), .C(p2), .D(p5), .E(p3), .Y(new_n155_));
  INVx1_ASAP7_75t_R    g137(.A(new_n47_), .Y(new_n156_));
  NOR3x1_ASAP7_75t_R   g138(.A(new_n155_), .B(new_n156_), .C(new_n88_), .Y(new_n157_));
  OR3x1_ASAP7_75t_R    g139(.A(new_n154_), .B(new_n39_), .C(new_n157_), .Y(o5));
  OR3x1_ASAP7_75t_R    g140(.A(new_n155_), .B(new_n156_), .C(new_n39_), .Y(o6));
endmodule


