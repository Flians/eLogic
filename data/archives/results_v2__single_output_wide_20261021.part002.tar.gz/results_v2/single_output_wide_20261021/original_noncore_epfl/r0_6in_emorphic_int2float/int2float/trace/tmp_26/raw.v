// Benchmark "/tmp/" written by ABC on Wed Oct 21 14:43:55 2026

module \/tmp/  ( 
    p2, p6, p1, p7, p9, p8, p0, p5, p3, p10, p4,
    o0, o1, o2, o3, o4, o5, o6  );
  input  p2, p6, p1, p7, p9, p8, p0, p5, p3, p10, p4;
  output o0, o1, o2, o3, o4, o5, o6;
  wire new_n19_, new_n20_, new_n21_, new_n22_, new_n23_, new_n24_, new_n25_,
    new_n26_, new_n27_, new_n28_, new_n29_, new_n30_, new_n31_, new_n32_,
    new_n33_, new_n34_, new_n35_, new_n36_, new_n37_, new_n38_, new_n39_,
    new_n40_, new_n41_, new_n42_, new_n43_, new_n44_, new_n45_, new_n46_,
    new_n47_, new_n48_, new_n49_, new_n50_, new_n51_, new_n52_, new_n53_,
    new_n54_, new_n55_, new_n56_, new_n57_, new_n58_, new_n59_, new_n60_,
    new_n61_, new_n62_, new_n63_, new_n64_, new_n66_, new_n67_, new_n68_,
    new_n69_, new_n70_, new_n71_, new_n72_, new_n73_, new_n74_, new_n75_,
    new_n76_, new_n77_, new_n78_, new_n79_, new_n80_, new_n81_, new_n82_,
    new_n83_, new_n84_, new_n85_, new_n86_, new_n87_, new_n88_, new_n89_,
    new_n90_, new_n91_, new_n92_, new_n93_, new_n94_, new_n95_, new_n97_,
    new_n98_, new_n99_, new_n100_, new_n101_, new_n102_, new_n103_,
    new_n104_, new_n105_, new_n106_, new_n107_, new_n108_, new_n109_,
    new_n110_, new_n111_, new_n112_, new_n113_, new_n114_, new_n115_,
    new_n116_, new_n117_, new_n118_, new_n119_, new_n120_, new_n121_,
    new_n122_, new_n123_, new_n124_, new_n125_, new_n126_, new_n127_,
    new_n128_, new_n130_, new_n131_, new_n132_, new_n134_, new_n135_,
    new_n136_, new_n137_, new_n138_, new_n139_, new_n140_, new_n141_,
    new_n142_, new_n143_, new_n144_, new_n146_, new_n147_, new_n148_,
    new_n149_, new_n150_, new_n151_;
  INVx1_ASAP7_75t_R    g000(.A(p4), .Y(new_n19_));
  INVx1_ASAP7_75t_R    g001(.A(p10), .Y(new_n20_));
  NAND2x1_ASAP7_75t_R  g002(.A(p0), .B(p3), .Y(new_n21_));
  AOI211x1_ASAP7_75t_R g003(.A1(new_n20_), .A2(new_n21_), .B(p6), .C(p5), .Y(new_n22_));
  INVx1_ASAP7_75t_R    g004(.A(p3), .Y(new_n23_));
  NAND2x1_ASAP7_75t_R  g005(.A(p7), .B(new_n23_), .Y(new_n24_));
  AO21x1_ASAP7_75t_R   g006(.A1(new_n21_), .A2(new_n24_), .B(new_n20_), .Y(new_n25_));
  AND2x2_ASAP7_75t_R   g007(.A(p7), .B(p3), .Y(new_n26_));
  AO21x1_ASAP7_75t_R   g008(.A1(new_n22_), .A2(new_n25_), .B(new_n26_), .Y(new_n27_));
  INVx1_ASAP7_75t_R    g009(.A(p6), .Y(new_n28_));
  AND3x1_ASAP7_75t_R   g010(.A(new_n28_), .B(p2), .C(p4), .Y(new_n29_));
  INVx1_ASAP7_75t_R    g011(.A(p0), .Y(new_n30_));
  NOR2x1_ASAP7_75t_R   g012(.A(p1), .B(new_n30_), .Y(new_n31_));
  INVx1_ASAP7_75t_R    g013(.A(p2), .Y(new_n32_));
  NAND2x1_ASAP7_75t_R  g014(.A(new_n32_), .B(new_n23_), .Y(new_n33_));
  AOI21x1_ASAP7_75t_R  g015(.A1(p2), .A2(p3), .B(new_n28_), .Y(new_n34_));
  AOI22x1_ASAP7_75t_R  g016(.A1(new_n29_), .A2(new_n31_), .B1(new_n33_), .B2(new_n34_), .Y(new_n35_));
  OAI22x1_ASAP7_75t_R  g017(.A1(new_n35_), .A2(p7), .B1(new_n19_), .B2(new_n24_), .Y(new_n36_));
  AOI21x1_ASAP7_75t_R  g018(.A1(new_n19_), .A2(new_n27_), .B(new_n36_), .Y(new_n37_));
  NOR2x1_ASAP7_75t_R   g019(.A(p9), .B(p8), .Y(new_n38_));
  INVx1_ASAP7_75t_R    g020(.A(new_n38_), .Y(new_n39_));
  INVx1_ASAP7_75t_R    g021(.A(p5), .Y(new_n40_));
  NAND2x1_ASAP7_75t_R  g022(.A(p4), .B(new_n40_), .Y(new_n41_));
  NOR2x1_ASAP7_75t_R   g023(.A(p3), .B(new_n28_), .Y(new_n42_));
  AND2x2_ASAP7_75t_R   g024(.A(p2), .B(p3), .Y(new_n43_));
  OR5x1_ASAP7_75t_R    g025(.A(p1), .B(new_n42_), .C(new_n30_), .D(new_n26_), .E(new_n43_), .Y(new_n44_));
  INVx1_ASAP7_75t_R    g026(.A(new_n41_), .Y(new_n45_));
  NOR2x1_ASAP7_75t_R   g027(.A(p6), .B(p7), .Y(new_n46_));
  AO31x2_ASAP7_75t_R   g028(.A1(new_n46_), .A2(p1), .A3(new_n30_), .B(p8), .Y(new_n47_));
  AND3x1_ASAP7_75t_R   g029(.A(new_n19_), .B(p8), .C(p5), .Y(new_n48_));
  AOI21x1_ASAP7_75t_R  g030(.A1(new_n45_), .A2(new_n47_), .B(new_n48_), .Y(new_n49_));
  OAI21x1_ASAP7_75t_R  g031(.A1(new_n41_), .A2(new_n44_), .B(new_n49_), .Y(new_n50_));
  INVx1_ASAP7_75t_R    g032(.A(p9), .Y(new_n51_));
  INVx1_ASAP7_75t_R    g033(.A(p1), .Y(new_n52_));
  NAND2x1_ASAP7_75t_R  g034(.A(new_n32_), .B(new_n52_), .Y(new_n53_));
  NAND2x1_ASAP7_75t_R  g035(.A(p2), .B(p1), .Y(new_n54_));
  INVx1_ASAP7_75t_R    g036(.A(p7), .Y(new_n55_));
  INVx1_ASAP7_75t_R    g037(.A(p8), .Y(new_n56_));
  AND3x1_ASAP7_75t_R   g038(.A(new_n54_), .B(new_n55_), .C(new_n56_), .Y(new_n57_));
  AO21x1_ASAP7_75t_R   g039(.A1(new_n53_), .A2(new_n57_), .B(p9), .Y(new_n58_));
  NAND2x1_ASAP7_75t_R  g040(.A(p5), .B(new_n28_), .Y(new_n59_));
  NAND2x1_ASAP7_75t_R  g041(.A(p6), .B(new_n40_), .Y(new_n60_));
  OR3x1_ASAP7_75t_R    g042(.A(new_n55_), .B(new_n56_), .C(new_n40_), .Y(new_n61_));
  AO21x1_ASAP7_75t_R   g043(.A1(new_n60_), .A2(new_n61_), .B(new_n51_), .Y(new_n62_));
  NAND2x1_ASAP7_75t_R  g044(.A(new_n59_), .B(new_n62_), .Y(new_n63_));
  AOI22x1_ASAP7_75t_R  g045(.A1(new_n50_), .A2(new_n51_), .B1(new_n58_), .B2(new_n63_), .Y(new_n64_));
  OAI21x1_ASAP7_75t_R  g046(.A1(new_n37_), .A2(new_n39_), .B(new_n64_), .Y(o0));
  NOR2x1_ASAP7_75t_R   g047(.A(p8), .B(p3), .Y(new_n66_));
  NOR2x1_ASAP7_75t_R   g048(.A(p6), .B(new_n56_), .Y(new_n67_));
  OAI21x1_ASAP7_75t_R  g049(.A1(new_n66_), .A2(new_n67_), .B(new_n40_), .Y(new_n68_));
  NAND2x1_ASAP7_75t_R  g050(.A(p5), .B(p4), .Y(new_n69_));
  OR3x1_ASAP7_75t_R    g051(.A(new_n67_), .B(new_n69_), .C(new_n66_), .Y(new_n70_));
  NOR2x1_ASAP7_75t_R   g052(.A(p7), .B(p8), .Y(new_n71_));
  AO21x1_ASAP7_75t_R   g053(.A1(new_n68_), .A2(new_n70_), .B(new_n71_), .Y(new_n72_));
  NAND2x1_ASAP7_75t_R  g054(.A(p0), .B(p10), .Y(new_n73_));
  NAND2x1_ASAP7_75t_R  g055(.A(p3), .B(new_n28_), .Y(new_n74_));
  NOR2x1_ASAP7_75t_R   g056(.A(p1), .B(new_n20_), .Y(new_n75_));
  AOI211x1_ASAP7_75t_R g057(.A1(p1), .A2(new_n73_), .B(new_n74_), .C(new_n75_), .Y(new_n76_));
  AOI21x1_ASAP7_75t_R  g058(.A1(new_n28_), .A2(new_n52_), .B(new_n66_), .Y(new_n77_));
  OAI22x1_ASAP7_75t_R  g059(.A1(new_n77_), .A2(p0), .B1(new_n55_), .B2(p8), .Y(new_n78_));
  NOR2x1_ASAP7_75t_R   g060(.A(p5), .B(p4), .Y(new_n79_));
  OAI21x1_ASAP7_75t_R  g061(.A1(new_n76_), .A2(new_n78_), .B(new_n79_), .Y(new_n80_));
  AO21x1_ASAP7_75t_R   g062(.A1(new_n71_), .A2(new_n34_), .B(new_n67_), .Y(new_n81_));
  AND2x2_ASAP7_75t_R   g063(.A(p1), .B(p0), .Y(new_n82_));
  OA211x2_ASAP7_75t_R  g064(.A1(p6), .A2(new_n82_), .B(p2), .C(p4), .Y(new_n83_));
  NOR2x1_ASAP7_75t_R   g065(.A(p5), .B(p3), .Y(new_n84_));
  AO32x1_ASAP7_75t_R   g066(.A1(new_n55_), .A2(new_n56_), .A3(p3), .B1(new_n84_), .B2(new_n28_), .Y(new_n85_));
  AOI22x1_ASAP7_75t_R  g067(.A1(new_n81_), .A2(new_n19_), .B1(new_n83_), .B2(new_n85_), .Y(new_n86_));
  NAND3x1_ASAP7_75t_R  g068(.A(new_n72_), .B(new_n80_), .C(new_n86_), .Y(new_n87_));
  OR3x1_ASAP7_75t_R    g069(.A(new_n41_), .B(p2), .C(new_n82_), .Y(new_n88_));
  OR4x2_ASAP7_75t_R    g070(.A(new_n54_), .B(p8), .C(new_n40_), .D(new_n23_), .Y(new_n89_));
  NAND3x1_ASAP7_75t_R  g071(.A(new_n66_), .B(new_n54_), .C(p5), .Y(new_n90_));
  AND4x2_ASAP7_75t_R   g072(.A(new_n88_), .B(new_n89_), .C(new_n51_), .D(new_n90_), .Y(new_n91_));
  AO21x1_ASAP7_75t_R   g073(.A1(p6), .A2(p5), .B(p7), .Y(new_n92_));
  AO21x1_ASAP7_75t_R   g074(.A1(p6), .A2(new_n51_), .B(new_n92_), .Y(new_n93_));
  OR4x2_ASAP7_75t_R    g075(.A(new_n28_), .B(new_n55_), .C(new_n51_), .D(new_n40_), .Y(new_n94_));
  OAI22x1_ASAP7_75t_R  g076(.A1(new_n91_), .A2(new_n93_), .B1(p8), .B2(new_n94_), .Y(new_n95_));
  AOI21x1_ASAP7_75t_R  g077(.A1(new_n51_), .A2(new_n87_), .B(new_n95_), .Y(o1));
  NAND2x1_ASAP7_75t_R  g078(.A(new_n52_), .B(new_n40_), .Y(new_n97_));
  NAND2x1_ASAP7_75t_R  g079(.A(p2), .B(p3), .Y(new_n98_));
  NAND2x1_ASAP7_75t_R  g080(.A(p3), .B(new_n32_), .Y(new_n99_));
  OAI22x1_ASAP7_75t_R  g081(.A1(new_n97_), .A2(new_n98_), .B1(new_n99_), .B2(new_n19_), .Y(new_n100_));
  OAI21x1_ASAP7_75t_R  g082(.A1(p1), .A2(new_n100_), .B(new_n46_), .Y(new_n101_));
  AO21x1_ASAP7_75t_R   g083(.A1(new_n73_), .A2(new_n43_), .B(new_n84_), .Y(new_n102_));
  NAND2x1_ASAP7_75t_R  g084(.A(p10), .B(new_n40_), .Y(new_n103_));
  NAND3x1_ASAP7_75t_R  g085(.A(new_n23_), .B(p2), .C(p4), .Y(new_n104_));
  OAI21x1_ASAP7_75t_R  g086(.A1(new_n99_), .A2(new_n103_), .B(new_n104_), .Y(new_n105_));
  AOI221x1_ASAP7_75t_R g087(.A1(new_n19_), .A2(new_n102_), .B1(new_n105_), .B2(p0), .C(new_n100_), .Y(new_n106_));
  AND2x2_ASAP7_75t_R   g088(.A(p6), .B(p5), .Y(new_n107_));
  NAND2x1_ASAP7_75t_R  g089(.A(p3), .B(p4), .Y(new_n108_));
  NAND3x1_ASAP7_75t_R  g090(.A(new_n30_), .B(new_n40_), .C(p4), .Y(new_n109_));
  NAND3x1_ASAP7_75t_R  g091(.A(new_n19_), .B(p1), .C(p5), .Y(new_n110_));
  NAND3x1_ASAP7_75t_R  g092(.A(new_n109_), .B(new_n110_), .C(new_n43_), .Y(new_n111_));
  AND2x2_ASAP7_75t_R   g093(.A(p5), .B(p4), .Y(new_n112_));
  OA21x2_ASAP7_75t_R   g094(.A1(new_n43_), .A2(new_n112_), .B(new_n55_), .Y(new_n113_));
  NAND3x1_ASAP7_75t_R  g095(.A(new_n40_), .B(p2), .C(p6), .Y(new_n114_));
  OR3x1_ASAP7_75t_R    g096(.A(new_n40_), .B(p6), .C(p1), .Y(new_n115_));
  AOI21x1_ASAP7_75t_R  g097(.A1(new_n114_), .A2(new_n115_), .B(new_n108_), .Y(new_n116_));
  AOI221x1_ASAP7_75t_R g098(.A1(new_n107_), .A2(new_n108_), .B1(new_n111_), .B2(new_n113_), .C(new_n116_), .Y(new_n117_));
  OAI21x1_ASAP7_75t_R  g099(.A1(new_n101_), .A2(new_n106_), .B(new_n117_), .Y(new_n118_));
  AND2x2_ASAP7_75t_R   g100(.A(p6), .B(p4), .Y(new_n119_));
  NOR2x1_ASAP7_75t_R   g101(.A(p9), .B(new_n55_), .Y(new_n120_));
  AND3x1_ASAP7_75t_R   g102(.A(p6), .B(p5), .C(p4), .Y(new_n121_));
  INVx1_ASAP7_75t_R    g103(.A(new_n121_), .Y(new_n122_));
  NOR2x1_ASAP7_75t_R   g104(.A(p7), .B(p9), .Y(new_n123_));
  AO221x2_ASAP7_75t_R  g105(.A1(new_n119_), .A2(new_n120_), .B1(new_n122_), .B2(new_n123_), .C(new_n56_), .Y(new_n124_));
  INVx1_ASAP7_75t_R    g106(.A(new_n60_), .Y(new_n125_));
  NOR2x1_ASAP7_75t_R   g107(.A(new_n69_), .B(new_n74_), .Y(new_n126_));
  OAI21x1_ASAP7_75t_R  g108(.A1(new_n125_), .A2(new_n126_), .B(new_n120_), .Y(new_n127_));
  NAND3x1_ASAP7_75t_R  g109(.A(new_n124_), .B(new_n94_), .C(new_n127_), .Y(new_n128_));
  AO21x1_ASAP7_75t_R   g110(.A1(new_n38_), .A2(new_n118_), .B(new_n128_), .Y(o2));
  AND3x1_ASAP7_75t_R   g111(.A(new_n79_), .B(new_n46_), .C(new_n23_), .Y(new_n130_));
  AND3x1_ASAP7_75t_R   g112(.A(new_n121_), .B(new_n26_), .C(new_n52_), .Y(new_n131_));
  NOR2x1_ASAP7_75t_R   g113(.A(new_n130_), .B(new_n131_), .Y(new_n132_));
  OR3x1_ASAP7_75t_R    g114(.A(new_n132_), .B(p2), .C(new_n39_), .Y(o3));
  OR3x1_ASAP7_75t_R    g115(.A(new_n52_), .B(new_n30_), .C(p6), .Y(new_n134_));
  AO21x1_ASAP7_75t_R   g116(.A1(new_n69_), .A2(new_n134_), .B(new_n98_), .Y(new_n135_));
  OA211x2_ASAP7_75t_R  g117(.A1(p4), .A2(new_n74_), .B(new_n135_), .C(new_n59_), .Y(new_n136_));
  AND3x1_ASAP7_75t_R   g118(.A(new_n79_), .B(p0), .C(p10), .Y(new_n137_));
  AND3x1_ASAP7_75t_R   g119(.A(new_n55_), .B(p2), .C(p1), .Y(new_n138_));
  OA21x2_ASAP7_75t_R   g120(.A1(new_n137_), .A2(new_n126_), .B(new_n138_), .Y(new_n139_));
  NAND2x1_ASAP7_75t_R  g121(.A(p2), .B(new_n55_), .Y(new_n140_));
  AND5x1_ASAP7_75t_R   g122(.A(new_n56_), .B(new_n53_), .C(new_n140_), .D(p3), .E(new_n121_), .Y(new_n141_));
  AND3x1_ASAP7_75t_R   g123(.A(new_n112_), .B(p6), .C(p7), .Y(new_n142_));
  NOR2x1_ASAP7_75t_R   g124(.A(new_n56_), .B(new_n142_), .Y(new_n143_));
  OR3x1_ASAP7_75t_R    g125(.A(new_n139_), .B(new_n141_), .C(new_n143_), .Y(new_n144_));
  AOI22x1_ASAP7_75t_R  g126(.A1(new_n136_), .A2(new_n123_), .B1(new_n144_), .B2(new_n51_), .Y(o4));
  AND3x1_ASAP7_75t_R   g127(.A(new_n138_), .B(p0), .C(p10), .Y(new_n146_));
  AO32x1_ASAP7_75t_R   g128(.A1(new_n146_), .A2(new_n28_), .A3(new_n19_), .B1(new_n53_), .B2(new_n142_), .Y(new_n147_));
  AND5x1_ASAP7_75t_R   g129(.A(p2), .B(p1), .C(p5), .D(p3), .E(p4), .Y(new_n148_));
  INVx1_ASAP7_75t_R    g130(.A(new_n46_), .Y(new_n149_));
  OR3x1_ASAP7_75t_R    g131(.A(new_n148_), .B(new_n149_), .C(new_n79_), .Y(new_n150_));
  NAND2x1_ASAP7_75t_R  g132(.A(new_n38_), .B(new_n150_), .Y(new_n151_));
  AO21x1_ASAP7_75t_R   g133(.A1(p3), .A2(new_n147_), .B(new_n151_), .Y(o5));
  OR3x1_ASAP7_75t_R    g134(.A(new_n148_), .B(new_n39_), .C(new_n149_), .Y(o6));
endmodule


