// Benchmark "/tmp/" written by ABC on Wed Oct 21 14:43:59 2026

module \/tmp/  ( 
    p3, p2, p6, p1, p5, p10, p7, p9, p8, p4, p0,
    o0, o1, o2, o3, o4, o5, o6  );
  input  p3, p2, p6, p1, p5, p10, p7, p9, p8, p4, p0;
  output o0, o1, o2, o3, o4, o5, o6;
  wire new_n19_, new_n20_, new_n21_, new_n22_, new_n23_, new_n24_, new_n25_,
    new_n26_, new_n27_, new_n28_, new_n29_, new_n30_, new_n31_, new_n32_,
    new_n33_, new_n34_, new_n35_, new_n36_, new_n37_, new_n38_, new_n39_,
    new_n40_, new_n41_, new_n42_, new_n43_, new_n44_, new_n45_, new_n46_,
    new_n47_, new_n48_, new_n49_, new_n50_, new_n51_, new_n52_, new_n53_,
    new_n54_, new_n55_, new_n56_, new_n57_, new_n58_, new_n59_, new_n60_,
    new_n61_, new_n62_, new_n64_, new_n65_, new_n66_, new_n67_, new_n68_,
    new_n69_, new_n70_, new_n71_, new_n72_, new_n73_, new_n74_, new_n75_,
    new_n76_, new_n77_, new_n78_, new_n79_, new_n80_, new_n81_, new_n82_,
    new_n83_, new_n84_, new_n85_, new_n86_, new_n87_, new_n88_, new_n89_,
    new_n90_, new_n91_, new_n92_, new_n93_, new_n94_, new_n95_, new_n96_,
    new_n97_, new_n98_, new_n99_, new_n100_, new_n101_, new_n103_,
    new_n104_, new_n105_, new_n106_, new_n107_, new_n108_, new_n109_,
    new_n110_, new_n111_, new_n112_, new_n113_, new_n114_, new_n115_,
    new_n116_, new_n117_, new_n118_, new_n119_, new_n120_, new_n121_,
    new_n122_, new_n123_, new_n124_, new_n125_, new_n126_, new_n127_,
    new_n128_, new_n129_, new_n130_, new_n131_, new_n132_, new_n133_,
    new_n135_, new_n136_, new_n137_, new_n139_, new_n140_, new_n141_,
    new_n142_, new_n143_, new_n144_, new_n145_, new_n146_, new_n147_,
    new_n148_, new_n149_, new_n150_, new_n151_, new_n152_, new_n154_,
    new_n155_, new_n156_, new_n157_;
  INVx1_ASAP7_75t_R    g000(.A(p4), .Y(new_n19_));
  INVx1_ASAP7_75t_R    g001(.A(p10), .Y(new_n20_));
  NAND2x1_ASAP7_75t_R  g002(.A(p3), .B(p0), .Y(new_n21_));
  INVx1_ASAP7_75t_R    g003(.A(p6), .Y(new_n22_));
  INVx1_ASAP7_75t_R    g004(.A(p5), .Y(new_n23_));
  NAND2x1_ASAP7_75t_R  g005(.A(new_n22_), .B(new_n23_), .Y(new_n24_));
  AO21x1_ASAP7_75t_R   g006(.A1(new_n20_), .A2(new_n21_), .B(new_n24_), .Y(new_n25_));
  INVx1_ASAP7_75t_R    g007(.A(p3), .Y(new_n26_));
  NAND2x1_ASAP7_75t_R  g008(.A(p7), .B(new_n26_), .Y(new_n27_));
  AOI21x1_ASAP7_75t_R  g009(.A1(new_n21_), .A2(new_n27_), .B(new_n20_), .Y(new_n28_));
  INVx1_ASAP7_75t_R    g010(.A(p7), .Y(new_n29_));
  OAI22x1_ASAP7_75t_R  g011(.A1(new_n25_), .A2(new_n28_), .B1(new_n26_), .B2(new_n29_), .Y(new_n30_));
  AOI21x1_ASAP7_75t_R  g012(.A1(p3), .A2(p2), .B(new_n22_), .Y(new_n31_));
  INVx1_ASAP7_75t_R    g013(.A(p2), .Y(new_n32_));
  NAND2x1_ASAP7_75t_R  g014(.A(new_n26_), .B(new_n32_), .Y(new_n33_));
  NOR2x1_ASAP7_75t_R   g015(.A(p6), .B(p1), .Y(new_n34_));
  AND3x1_ASAP7_75t_R   g016(.A(p2), .B(p4), .C(p0), .Y(new_n35_));
  AOI22x1_ASAP7_75t_R  g017(.A1(new_n31_), .A2(new_n33_), .B1(new_n34_), .B2(new_n35_), .Y(new_n36_));
  OAI22x1_ASAP7_75t_R  g018(.A1(new_n36_), .A2(p7), .B1(new_n19_), .B2(new_n27_), .Y(new_n37_));
  AOI21x1_ASAP7_75t_R  g019(.A1(new_n19_), .A2(new_n30_), .B(new_n37_), .Y(new_n38_));
  NOR2x1_ASAP7_75t_R   g020(.A(p9), .B(p8), .Y(new_n39_));
  INVx1_ASAP7_75t_R    g021(.A(new_n39_), .Y(new_n40_));
  INVx1_ASAP7_75t_R    g022(.A(p9), .Y(new_n41_));
  INVx1_ASAP7_75t_R    g023(.A(p0), .Y(new_n42_));
  AOI211x1_ASAP7_75t_R g024(.A1(p6), .A2(new_n26_), .B(p1), .C(new_n42_), .Y(new_n43_));
  AO21x1_ASAP7_75t_R   g025(.A1(new_n32_), .A2(new_n29_), .B(new_n26_), .Y(new_n44_));
  NOR2x1_ASAP7_75t_R   g026(.A(p5), .B(new_n19_), .Y(new_n45_));
  NAND3x1_ASAP7_75t_R  g027(.A(new_n43_), .B(new_n44_), .C(new_n45_), .Y(new_n46_));
  NOR2x1_ASAP7_75t_R   g028(.A(p6), .B(p7), .Y(new_n47_));
  AO31x2_ASAP7_75t_R   g029(.A1(new_n47_), .A2(p1), .A3(new_n42_), .B(p8), .Y(new_n48_));
  AND3x1_ASAP7_75t_R   g030(.A(new_n19_), .B(p5), .C(p8), .Y(new_n49_));
  AOI21x1_ASAP7_75t_R  g031(.A1(new_n45_), .A2(new_n48_), .B(new_n49_), .Y(new_n50_));
  NAND2x1_ASAP7_75t_R  g032(.A(new_n46_), .B(new_n50_), .Y(new_n51_));
  INVx1_ASAP7_75t_R    g033(.A(p8), .Y(new_n52_));
  NAND2x1_ASAP7_75t_R  g034(.A(new_n29_), .B(new_n52_), .Y(new_n53_));
  AND2x2_ASAP7_75t_R   g035(.A(p2), .B(p1), .Y(new_n54_));
  NOR2x1_ASAP7_75t_R   g036(.A(p2), .B(p1), .Y(new_n55_));
  OR3x1_ASAP7_75t_R    g037(.A(new_n53_), .B(new_n54_), .C(new_n55_), .Y(new_n56_));
  NAND2x1_ASAP7_75t_R  g038(.A(p5), .B(new_n22_), .Y(new_n57_));
  NAND2x1_ASAP7_75t_R  g039(.A(p7), .B(p8), .Y(new_n58_));
  NAND2x1_ASAP7_75t_R  g040(.A(p6), .B(p9), .Y(new_n59_));
  AO21x1_ASAP7_75t_R   g041(.A1(p5), .A2(new_n58_), .B(new_n59_), .Y(new_n60_));
  AOI22x1_ASAP7_75t_R  g042(.A1(new_n56_), .A2(new_n41_), .B1(new_n57_), .B2(new_n60_), .Y(new_n61_));
  AOI21x1_ASAP7_75t_R  g043(.A1(new_n41_), .A2(new_n51_), .B(new_n61_), .Y(new_n62_));
  OAI21x1_ASAP7_75t_R  g044(.A1(new_n38_), .A2(new_n40_), .B(new_n62_), .Y(o0));
  NAND2x1_ASAP7_75t_R  g045(.A(p3), .B(p2), .Y(new_n64_));
  NAND2x1_ASAP7_75t_R  g046(.A(p6), .B(new_n64_), .Y(new_n65_));
  NAND2x1_ASAP7_75t_R  g047(.A(p8), .B(new_n22_), .Y(new_n66_));
  OAI21x1_ASAP7_75t_R  g048(.A1(new_n53_), .A2(new_n65_), .B(new_n66_), .Y(new_n67_));
  NOR2x1_ASAP7_75t_R   g049(.A(p3), .B(p5), .Y(new_n68_));
  AO32x1_ASAP7_75t_R   g050(.A1(p3), .A2(new_n29_), .A3(new_n52_), .B1(new_n68_), .B2(new_n22_), .Y(new_n69_));
  AO21x1_ASAP7_75t_R   g051(.A1(p1), .A2(p0), .B(p6), .Y(new_n70_));
  AND3x1_ASAP7_75t_R   g052(.A(new_n70_), .B(p2), .C(p4), .Y(new_n71_));
  AOI22x1_ASAP7_75t_R  g053(.A1(new_n67_), .A2(new_n19_), .B1(new_n69_), .B2(new_n71_), .Y(new_n72_));
  NAND2x1_ASAP7_75t_R  g054(.A(new_n26_), .B(new_n52_), .Y(new_n73_));
  AOI21x1_ASAP7_75t_R  g055(.A1(new_n66_), .A2(new_n73_), .B(p5), .Y(new_n74_));
  AND2x2_ASAP7_75t_R   g056(.A(p5), .B(p4), .Y(new_n75_));
  AND3x1_ASAP7_75t_R   g057(.A(new_n73_), .B(new_n66_), .C(new_n75_), .Y(new_n76_));
  OAI21x1_ASAP7_75t_R  g058(.A1(new_n74_), .A2(new_n76_), .B(new_n53_), .Y(new_n77_));
  OAI22x1_ASAP7_75t_R  g059(.A1(p3), .A2(p8), .B1(p6), .B2(p1), .Y(new_n78_));
  AO22x1_ASAP7_75t_R   g060(.A1(p7), .A2(new_n52_), .B1(new_n42_), .B2(new_n78_), .Y(new_n79_));
  NAND2x1_ASAP7_75t_R  g061(.A(p1), .B(p0), .Y(new_n80_));
  NAND2x1_ASAP7_75t_R  g062(.A(p3), .B(new_n22_), .Y(new_n81_));
  INVx1_ASAP7_75t_R    g063(.A(p1), .Y(new_n82_));
  NOR2x1_ASAP7_75t_R   g064(.A(p10), .B(new_n82_), .Y(new_n83_));
  AOI211x1_ASAP7_75t_R g065(.A1(p10), .A2(new_n80_), .B(new_n81_), .C(new_n83_), .Y(new_n84_));
  NOR2x1_ASAP7_75t_R   g066(.A(p5), .B(p4), .Y(new_n85_));
  OAI21x1_ASAP7_75t_R  g067(.A1(new_n79_), .A2(new_n84_), .B(new_n85_), .Y(new_n86_));
  NAND3x1_ASAP7_75t_R  g068(.A(new_n72_), .B(new_n77_), .C(new_n86_), .Y(new_n87_));
  AO21x1_ASAP7_75t_R   g069(.A1(p6), .A2(p5), .B(p7), .Y(new_n88_));
  AO21x1_ASAP7_75t_R   g070(.A1(p6), .A2(new_n41_), .B(new_n88_), .Y(new_n89_));
  NOR3x1_ASAP7_75t_R   g071(.A(new_n23_), .B(p3), .C(p8), .Y(new_n90_));
  NOR3x1_ASAP7_75t_R   g072(.A(new_n19_), .B(p5), .C(p0), .Y(new_n91_));
  OAI21x1_ASAP7_75t_R  g073(.A1(new_n90_), .A2(new_n91_), .B(new_n32_), .Y(new_n92_));
  NOR2x1_ASAP7_75t_R   g074(.A(p8), .B(new_n26_), .Y(new_n93_));
  AND3x1_ASAP7_75t_R   g075(.A(p2), .B(p1), .C(p5), .Y(new_n94_));
  AOI22x1_ASAP7_75t_R  g076(.A1(new_n55_), .A2(new_n45_), .B1(new_n93_), .B2(new_n94_), .Y(new_n95_));
  OR4x2_ASAP7_75t_R    g077(.A(new_n23_), .B(p3), .C(p1), .D(p8), .Y(new_n96_));
  AND4x2_ASAP7_75t_R   g078(.A(new_n92_), .B(new_n95_), .C(new_n41_), .D(new_n96_), .Y(new_n97_));
  AND2x2_ASAP7_75t_R   g079(.A(p6), .B(p5), .Y(new_n98_));
  AND3x1_ASAP7_75t_R   g080(.A(new_n98_), .B(p7), .C(p9), .Y(new_n99_));
  NAND2x1_ASAP7_75t_R  g081(.A(new_n52_), .B(new_n99_), .Y(new_n100_));
  OAI21x1_ASAP7_75t_R  g082(.A1(new_n89_), .A2(new_n97_), .B(new_n100_), .Y(new_n101_));
  AOI21x1_ASAP7_75t_R  g083(.A1(new_n41_), .A2(new_n87_), .B(new_n101_), .Y(o1));
  OR3x1_ASAP7_75t_R    g084(.A(p3), .B(p5), .C(p4), .Y(new_n103_));
  AND2x2_ASAP7_75t_R   g085(.A(p10), .B(p0), .Y(new_n104_));
  OR3x1_ASAP7_75t_R    g086(.A(new_n104_), .B(p4), .C(new_n64_), .Y(new_n105_));
  AO21x1_ASAP7_75t_R   g087(.A1(new_n103_), .A2(new_n105_), .B(new_n82_), .Y(new_n106_));
  OR3x1_ASAP7_75t_R    g088(.A(new_n32_), .B(new_n19_), .C(p3), .Y(new_n107_));
  OR4x2_ASAP7_75t_R    g089(.A(new_n26_), .B(new_n20_), .C(p2), .D(p5), .Y(new_n108_));
  AO21x1_ASAP7_75t_R   g090(.A1(new_n107_), .A2(new_n108_), .B(new_n80_), .Y(new_n109_));
  AND2x2_ASAP7_75t_R   g091(.A(p3), .B(p4), .Y(new_n110_));
  AND2x2_ASAP7_75t_R   g092(.A(p3), .B(p2), .Y(new_n111_));
  NOR2x1_ASAP7_75t_R   g093(.A(p1), .B(p5), .Y(new_n112_));
  AOI22x1_ASAP7_75t_R  g094(.A1(new_n32_), .A2(new_n110_), .B1(new_n111_), .B2(new_n112_), .Y(new_n113_));
  NAND2x1_ASAP7_75t_R  g095(.A(new_n39_), .B(new_n47_), .Y(new_n114_));
  AO31x2_ASAP7_75t_R   g096(.A1(new_n106_), .A2(new_n109_), .A3(new_n113_), .B(new_n114_), .Y(new_n115_));
  AND3x1_ASAP7_75t_R   g097(.A(new_n110_), .B(p5), .C(new_n34_), .Y(new_n116_));
  NAND2x1_ASAP7_75t_R  g098(.A(p3), .B(p4), .Y(new_n117_));
  AND3x1_ASAP7_75t_R   g099(.A(new_n117_), .B(p6), .C(p5), .Y(new_n118_));
  AND5x1_ASAP7_75t_R   g100(.A(p3), .B(new_n23_), .C(p2), .D(p6), .E(p4), .Y(new_n119_));
  OR3x1_ASAP7_75t_R    g101(.A(new_n116_), .B(new_n118_), .C(new_n119_), .Y(new_n120_));
  AND2x2_ASAP7_75t_R   g102(.A(p1), .B(p5), .Y(new_n121_));
  AO21x1_ASAP7_75t_R   g103(.A1(new_n19_), .A2(new_n121_), .B(new_n64_), .Y(new_n122_));
  OA21x2_ASAP7_75t_R   g104(.A1(new_n111_), .A2(new_n75_), .B(new_n29_), .Y(new_n123_));
  OA21x2_ASAP7_75t_R   g105(.A1(new_n91_), .A2(new_n122_), .B(new_n123_), .Y(new_n124_));
  OAI21x1_ASAP7_75t_R  g106(.A1(new_n120_), .A2(new_n124_), .B(new_n39_), .Y(new_n125_));
  NAND2x1_ASAP7_75t_R  g107(.A(p5), .B(p4), .Y(new_n126_));
  OA211x2_ASAP7_75t_R  g108(.A1(new_n22_), .A2(new_n126_), .B(new_n29_), .C(new_n41_), .Y(new_n127_));
  AND2x2_ASAP7_75t_R   g109(.A(p6), .B(p4), .Y(new_n128_));
  NOR2x1_ASAP7_75t_R   g110(.A(p9), .B(new_n29_), .Y(new_n129_));
  AO21x1_ASAP7_75t_R   g111(.A1(new_n128_), .A2(new_n129_), .B(new_n52_), .Y(new_n130_));
  OAI22x1_ASAP7_75t_R  g112(.A1(new_n81_), .A2(new_n126_), .B1(new_n22_), .B2(p5), .Y(new_n131_));
  AOI21x1_ASAP7_75t_R  g113(.A1(new_n129_), .A2(new_n131_), .B(new_n99_), .Y(new_n132_));
  OA21x2_ASAP7_75t_R   g114(.A1(new_n127_), .A2(new_n130_), .B(new_n132_), .Y(new_n133_));
  NAND3x1_ASAP7_75t_R  g115(.A(new_n115_), .B(new_n125_), .C(new_n133_), .Y(o2));
  INVx1_ASAP7_75t_R    g116(.A(new_n47_), .Y(new_n135_));
  OR5x1_ASAP7_75t_R    g117(.A(new_n26_), .B(new_n126_), .C(new_n22_), .D(p1), .E(new_n29_), .Y(new_n136_));
  OA21x2_ASAP7_75t_R   g118(.A1(new_n135_), .A2(new_n103_), .B(new_n136_), .Y(new_n137_));
  OR3x1_ASAP7_75t_R    g119(.A(new_n137_), .B(p2), .C(new_n40_), .Y(o3));
  AND3x1_ASAP7_75t_R   g120(.A(new_n85_), .B(p10), .C(p0), .Y(new_n139_));
  NOR2x1_ASAP7_75t_R   g121(.A(new_n117_), .B(new_n57_), .Y(new_n140_));
  AND3x1_ASAP7_75t_R   g122(.A(new_n29_), .B(p2), .C(p1), .Y(new_n141_));
  OA21x2_ASAP7_75t_R   g123(.A1(new_n139_), .A2(new_n140_), .B(new_n141_), .Y(new_n142_));
  AND3x1_ASAP7_75t_R   g124(.A(new_n75_), .B(p6), .C(p7), .Y(new_n143_));
  NOR2x1_ASAP7_75t_R   g125(.A(new_n52_), .B(new_n143_), .Y(new_n144_));
  INVx1_ASAP7_75t_R    g126(.A(new_n55_), .Y(new_n145_));
  NAND2x1_ASAP7_75t_R  g127(.A(p2), .B(new_n29_), .Y(new_n146_));
  AND5x1_ASAP7_75t_R   g128(.A(p6), .B(new_n145_), .C(new_n93_), .D(new_n146_), .E(new_n75_), .Y(new_n147_));
  OR3x1_ASAP7_75t_R    g129(.A(new_n142_), .B(new_n144_), .C(new_n147_), .Y(new_n148_));
  OR3x1_ASAP7_75t_R    g130(.A(new_n82_), .B(new_n42_), .C(p6), .Y(new_n149_));
  AO21x1_ASAP7_75t_R   g131(.A1(new_n126_), .A2(new_n149_), .B(new_n64_), .Y(new_n150_));
  OR3x1_ASAP7_75t_R    g132(.A(new_n26_), .B(p6), .C(p4), .Y(new_n151_));
  AND5x1_ASAP7_75t_R   g133(.A(new_n29_), .B(new_n150_), .C(new_n41_), .D(new_n57_), .E(new_n151_), .Y(new_n152_));
  AOI21x1_ASAP7_75t_R  g134(.A1(new_n41_), .A2(new_n148_), .B(new_n152_), .Y(o4));
  NAND2x1_ASAP7_75t_R  g135(.A(new_n110_), .B(new_n94_), .Y(new_n154_));
  NOR2x1_ASAP7_75t_R   g136(.A(new_n85_), .B(new_n135_), .Y(new_n155_));
  NOR2x1_ASAP7_75t_R   g137(.A(p6), .B(p4), .Y(new_n156_));
  AO32x1_ASAP7_75t_R   g138(.A1(new_n104_), .A2(new_n141_), .A3(new_n156_), .B1(new_n143_), .B2(new_n145_), .Y(new_n157_));
  AO221x2_ASAP7_75t_R  g139(.A1(new_n154_), .A2(new_n155_), .B1(new_n157_), .B2(p3), .C(new_n40_), .Y(o5));
  AO21x1_ASAP7_75t_R   g140(.A1(new_n94_), .A2(new_n110_), .B(new_n114_), .Y(o6));
endmodule


