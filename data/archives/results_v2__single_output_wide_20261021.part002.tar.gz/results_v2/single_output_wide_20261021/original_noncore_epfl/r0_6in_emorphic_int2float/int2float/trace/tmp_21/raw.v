// Benchmark "/tmp/" written by ABC on Wed Oct 21 14:43:55 2026

module \/tmp/  ( 
    p4, p7, p10, p3, p5, p8, p1, p6, p2, p0, p9,
    o0, o1, o2, o3, o4, o5, o6  );
  input  p4, p7, p10, p3, p5, p8, p1, p6, p2, p0, p9;
  output o0, o1, o2, o3, o4, o5, o6;
  wire new_n19_, new_n20_, new_n21_, new_n22_, new_n23_, new_n24_, new_n25_,
    new_n26_, new_n27_, new_n28_, new_n29_, new_n30_, new_n31_, new_n32_,
    new_n33_, new_n34_, new_n35_, new_n36_, new_n37_, new_n38_, new_n39_,
    new_n40_, new_n41_, new_n42_, new_n43_, new_n44_, new_n45_, new_n46_,
    new_n47_, new_n48_, new_n49_, new_n50_, new_n51_, new_n52_, new_n53_,
    new_n54_, new_n55_, new_n56_, new_n57_, new_n58_, new_n59_, new_n60_,
    new_n61_, new_n62_, new_n64_, new_n65_, new_n66_, new_n67_, new_n68_,
    new_n69_, new_n70_, new_n71_, new_n72_, new_n73_, new_n74_, new_n75_,
    new_n76_, new_n77_, new_n78_, new_n79_, new_n80_, new_n81_, new_n82_,
    new_n83_, new_n84_, new_n85_, new_n86_, new_n87_, new_n88_, new_n89_,
    new_n90_, new_n91_, new_n92_, new_n93_, new_n94_, new_n95_, new_n96_,
    new_n97_, new_n98_, new_n99_, new_n100_, new_n101_, new_n103_,
    new_n104_, new_n105_, new_n106_, new_n107_, new_n108_, new_n109_,
    new_n110_, new_n111_, new_n112_, new_n113_, new_n114_, new_n115_,
    new_n116_, new_n117_, new_n118_, new_n119_, new_n120_, new_n121_,
    new_n122_, new_n123_, new_n124_, new_n125_, new_n126_, new_n127_,
    new_n128_, new_n129_, new_n130_, new_n131_, new_n132_, new_n133_,
    new_n135_, new_n136_, new_n137_, new_n139_, new_n140_, new_n141_,
    new_n142_, new_n143_, new_n144_, new_n145_, new_n146_, new_n147_,
    new_n148_, new_n149_, new_n150_, new_n151_, new_n153_, new_n154_,
    new_n155_, new_n156_;
  INVx1_ASAP7_75t_R    g000(.A(p4), .Y(new_n19_));
  INVx1_ASAP7_75t_R    g001(.A(p10), .Y(new_n20_));
  NAND2x1_ASAP7_75t_R  g002(.A(p3), .B(p0), .Y(new_n21_));
  AOI211x1_ASAP7_75t_R g003(.A1(new_n20_), .A2(new_n21_), .B(p5), .C(p6), .Y(new_n22_));
  INVx1_ASAP7_75t_R    g004(.A(p3), .Y(new_n23_));
  NAND2x1_ASAP7_75t_R  g005(.A(p7), .B(new_n23_), .Y(new_n24_));
  AO21x1_ASAP7_75t_R   g006(.A1(new_n21_), .A2(new_n24_), .B(new_n20_), .Y(new_n25_));
  AND2x2_ASAP7_75t_R   g007(.A(p7), .B(p3), .Y(new_n26_));
  AO21x1_ASAP7_75t_R   g008(.A1(new_n22_), .A2(new_n25_), .B(new_n26_), .Y(new_n27_));
  INVx1_ASAP7_75t_R    g009(.A(p1), .Y(new_n28_));
  INVx1_ASAP7_75t_R    g010(.A(p6), .Y(new_n29_));
  AND3x1_ASAP7_75t_R   g011(.A(new_n28_), .B(new_n29_), .C(p0), .Y(new_n30_));
  NAND2x1_ASAP7_75t_R  g012(.A(p4), .B(p2), .Y(new_n31_));
  INVx1_ASAP7_75t_R    g013(.A(new_n31_), .Y(new_n32_));
  INVx1_ASAP7_75t_R    g014(.A(p2), .Y(new_n33_));
  NAND2x1_ASAP7_75t_R  g015(.A(new_n23_), .B(new_n33_), .Y(new_n34_));
  AOI21x1_ASAP7_75t_R  g016(.A1(p3), .A2(p2), .B(new_n29_), .Y(new_n35_));
  AOI22x1_ASAP7_75t_R  g017(.A1(new_n30_), .A2(new_n32_), .B1(new_n34_), .B2(new_n35_), .Y(new_n36_));
  OAI22x1_ASAP7_75t_R  g018(.A1(new_n36_), .A2(p7), .B1(new_n19_), .B2(new_n24_), .Y(new_n37_));
  AOI21x1_ASAP7_75t_R  g019(.A1(new_n19_), .A2(new_n27_), .B(new_n37_), .Y(new_n38_));
  NOR2x1_ASAP7_75t_R   g020(.A(p8), .B(p9), .Y(new_n39_));
  INVx1_ASAP7_75t_R    g021(.A(new_n39_), .Y(new_n40_));
  INVx1_ASAP7_75t_R    g022(.A(p9), .Y(new_n41_));
  NOR2x1_ASAP7_75t_R   g023(.A(p5), .B(new_n19_), .Y(new_n42_));
  INVx1_ASAP7_75t_R    g024(.A(new_n42_), .Y(new_n43_));
  NOR2x1_ASAP7_75t_R   g025(.A(p3), .B(new_n29_), .Y(new_n44_));
  INVx1_ASAP7_75t_R    g026(.A(p0), .Y(new_n45_));
  AND2x2_ASAP7_75t_R   g027(.A(p3), .B(p2), .Y(new_n46_));
  OR5x1_ASAP7_75t_R    g028(.A(p1), .B(new_n44_), .C(new_n45_), .D(new_n26_), .E(new_n46_), .Y(new_n47_));
  NOR2x1_ASAP7_75t_R   g029(.A(p7), .B(p6), .Y(new_n48_));
  AO31x2_ASAP7_75t_R   g030(.A1(new_n48_), .A2(p1), .A3(new_n45_), .B(p8), .Y(new_n49_));
  AND3x1_ASAP7_75t_R   g031(.A(new_n19_), .B(p5), .C(p8), .Y(new_n50_));
  AOI21x1_ASAP7_75t_R  g032(.A1(new_n42_), .A2(new_n49_), .B(new_n50_), .Y(new_n51_));
  OAI21x1_ASAP7_75t_R  g033(.A1(new_n43_), .A2(new_n47_), .B(new_n51_), .Y(new_n52_));
  NAND2x1_ASAP7_75t_R  g034(.A(p5), .B(new_n29_), .Y(new_n53_));
  NAND2x1_ASAP7_75t_R  g035(.A(new_n28_), .B(new_n33_), .Y(new_n54_));
  NOR2x1_ASAP7_75t_R   g036(.A(p7), .B(p8), .Y(new_n55_));
  OA21x2_ASAP7_75t_R   g037(.A1(new_n28_), .A2(new_n33_), .B(new_n55_), .Y(new_n56_));
  AOI21x1_ASAP7_75t_R  g038(.A1(new_n54_), .A2(new_n56_), .B(p9), .Y(new_n57_));
  AND3x1_ASAP7_75t_R   g039(.A(p7), .B(p5), .C(p8), .Y(new_n58_));
  NOR2x1_ASAP7_75t_R   g040(.A(p5), .B(new_n29_), .Y(new_n59_));
  OAI21x1_ASAP7_75t_R  g041(.A1(new_n58_), .A2(new_n59_), .B(p9), .Y(new_n60_));
  OAI21x1_ASAP7_75t_R  g042(.A1(new_n53_), .A2(new_n57_), .B(new_n60_), .Y(new_n61_));
  AOI21x1_ASAP7_75t_R  g043(.A1(new_n41_), .A2(new_n52_), .B(new_n61_), .Y(new_n62_));
  OAI21x1_ASAP7_75t_R  g044(.A1(new_n38_), .A2(new_n40_), .B(new_n62_), .Y(o0));
  AO21x1_ASAP7_75t_R   g045(.A1(p5), .A2(p6), .B(p7), .Y(new_n64_));
  AO21x1_ASAP7_75t_R   g046(.A1(p6), .A2(new_n41_), .B(new_n64_), .Y(new_n65_));
  INVx1_ASAP7_75t_R    g047(.A(p5), .Y(new_n66_));
  NOR3x1_ASAP7_75t_R   g048(.A(new_n66_), .B(p3), .C(p8), .Y(new_n67_));
  NOR3x1_ASAP7_75t_R   g049(.A(new_n19_), .B(p5), .C(p2), .Y(new_n68_));
  OAI21x1_ASAP7_75t_R  g050(.A1(new_n67_), .A2(new_n68_), .B(new_n28_), .Y(new_n69_));
  NOR3x1_ASAP7_75t_R   g051(.A(new_n19_), .B(p5), .C(p0), .Y(new_n70_));
  OAI21x1_ASAP7_75t_R  g052(.A1(new_n67_), .A2(new_n70_), .B(new_n33_), .Y(new_n71_));
  OR5x1_ASAP7_75t_R    g053(.A(new_n23_), .B(new_n66_), .C(new_n28_), .D(new_n33_), .E(p8), .Y(new_n72_));
  AND4x2_ASAP7_75t_R   g054(.A(new_n69_), .B(new_n71_), .C(new_n41_), .D(new_n72_), .Y(new_n73_));
  INVx1_ASAP7_75t_R    g055(.A(p8), .Y(new_n74_));
  AND2x2_ASAP7_75t_R   g056(.A(p5), .B(p6), .Y(new_n75_));
  AND3x1_ASAP7_75t_R   g057(.A(new_n75_), .B(p7), .C(p9), .Y(new_n76_));
  NAND2x1_ASAP7_75t_R  g058(.A(new_n74_), .B(new_n76_), .Y(new_n77_));
  OAI21x1_ASAP7_75t_R  g059(.A1(new_n65_), .A2(new_n73_), .B(new_n77_), .Y(new_n78_));
  NOR2x1_ASAP7_75t_R   g060(.A(p3), .B(p8), .Y(new_n79_));
  AO21x1_ASAP7_75t_R   g061(.A1(p8), .A2(new_n29_), .B(new_n79_), .Y(new_n80_));
  AND2x2_ASAP7_75t_R   g062(.A(p4), .B(p5), .Y(new_n81_));
  AOI211x1_ASAP7_75t_R g063(.A1(p8), .A2(new_n29_), .B(new_n79_), .C(new_n81_), .Y(new_n82_));
  AOI211x1_ASAP7_75t_R g064(.A1(p5), .A2(new_n80_), .B(new_n55_), .C(new_n82_), .Y(new_n83_));
  NOR2x1_ASAP7_75t_R   g065(.A(p6), .B(new_n74_), .Y(new_n84_));
  AOI21x1_ASAP7_75t_R  g066(.A1(new_n55_), .A2(new_n35_), .B(new_n84_), .Y(new_n85_));
  NOR3x1_ASAP7_75t_R   g067(.A(p3), .B(p5), .C(p6), .Y(new_n86_));
  NOR3x1_ASAP7_75t_R   g068(.A(new_n23_), .B(p7), .C(p8), .Y(new_n87_));
  AOI21x1_ASAP7_75t_R  g069(.A1(p1), .A2(p0), .B(p6), .Y(new_n88_));
  NOR2x1_ASAP7_75t_R   g070(.A(new_n31_), .B(new_n88_), .Y(new_n89_));
  OAI21x1_ASAP7_75t_R  g071(.A1(new_n86_), .A2(new_n87_), .B(new_n89_), .Y(new_n90_));
  OAI21x1_ASAP7_75t_R  g072(.A1(p4), .A2(new_n85_), .B(new_n90_), .Y(new_n91_));
  OAI22x1_ASAP7_75t_R  g073(.A1(p3), .A2(p8), .B1(p1), .B2(p6), .Y(new_n92_));
  AOI22x1_ASAP7_75t_R  g074(.A1(new_n92_), .A2(new_n45_), .B1(p7), .B2(new_n74_), .Y(new_n93_));
  OAI21x1_ASAP7_75t_R  g075(.A1(new_n28_), .A2(new_n45_), .B(p10), .Y(new_n94_));
  NAND2x1_ASAP7_75t_R  g076(.A(p1), .B(new_n20_), .Y(new_n95_));
  NOR2x1_ASAP7_75t_R   g077(.A(p6), .B(new_n23_), .Y(new_n96_));
  NAND3x1_ASAP7_75t_R  g078(.A(new_n94_), .B(new_n95_), .C(new_n96_), .Y(new_n97_));
  NOR2x1_ASAP7_75t_R   g079(.A(p4), .B(p5), .Y(new_n98_));
  INVx1_ASAP7_75t_R    g080(.A(new_n98_), .Y(new_n99_));
  AOI21x1_ASAP7_75t_R  g081(.A1(new_n93_), .A2(new_n97_), .B(new_n99_), .Y(new_n100_));
  OA31x2_ASAP7_75t_R   g082(.A1(new_n83_), .A2(new_n91_), .A3(new_n100_), .B1(new_n41_), .Y(new_n101_));
  NOR2x1_ASAP7_75t_R   g083(.A(new_n78_), .B(new_n101_), .Y(o1));
  AND3x1_ASAP7_75t_R   g084(.A(new_n19_), .B(p5), .C(p1), .Y(new_n103_));
  NAND2x1_ASAP7_75t_R  g085(.A(p3), .B(p2), .Y(new_n104_));
  OR3x1_ASAP7_75t_R    g086(.A(new_n103_), .B(new_n70_), .C(new_n104_), .Y(new_n105_));
  INVx1_ASAP7_75t_R    g087(.A(p7), .Y(new_n106_));
  OA21x2_ASAP7_75t_R   g088(.A1(new_n46_), .A2(new_n81_), .B(new_n106_), .Y(new_n107_));
  AND3x1_ASAP7_75t_R   g089(.A(new_n106_), .B(new_n29_), .C(p1), .Y(new_n108_));
  NOR2x1_ASAP7_75t_R   g090(.A(p3), .B(new_n45_), .Y(new_n109_));
  AOI22x1_ASAP7_75t_R  g091(.A1(new_n32_), .A2(new_n109_), .B1(new_n23_), .B2(new_n98_), .Y(new_n110_));
  AND2x2_ASAP7_75t_R   g092(.A(p10), .B(p0), .Y(new_n111_));
  OR3x1_ASAP7_75t_R    g093(.A(new_n111_), .B(p4), .C(new_n104_), .Y(new_n112_));
  OR5x1_ASAP7_75t_R    g094(.A(new_n20_), .B(new_n23_), .C(new_n45_), .D(p5), .E(p2), .Y(new_n113_));
  NAND3x1_ASAP7_75t_R  g095(.A(new_n110_), .B(new_n112_), .C(new_n113_), .Y(new_n114_));
  NOR2x1_ASAP7_75t_R   g096(.A(p2), .B(new_n19_), .Y(new_n115_));
  AND3x1_ASAP7_75t_R   g097(.A(new_n66_), .B(new_n28_), .C(p2), .Y(new_n116_));
  AND3x1_ASAP7_75t_R   g098(.A(new_n106_), .B(new_n29_), .C(p3), .Y(new_n117_));
  OAI21x1_ASAP7_75t_R  g099(.A1(new_n115_), .A2(new_n116_), .B(new_n117_), .Y(new_n118_));
  NAND2x1_ASAP7_75t_R  g100(.A(p4), .B(p3), .Y(new_n119_));
  OR3x1_ASAP7_75t_R    g101(.A(new_n53_), .B(p1), .C(new_n119_), .Y(new_n120_));
  AND3x1_ASAP7_75t_R   g102(.A(p4), .B(p3), .C(p2), .Y(new_n121_));
  AOI22x1_ASAP7_75t_R  g103(.A1(new_n59_), .A2(new_n121_), .B1(new_n75_), .B2(new_n119_), .Y(new_n122_));
  NAND3x1_ASAP7_75t_R  g104(.A(new_n118_), .B(new_n120_), .C(new_n122_), .Y(new_n123_));
  AOI221x1_ASAP7_75t_R g105(.A1(new_n105_), .A2(new_n107_), .B1(new_n108_), .B2(new_n114_), .C(new_n123_), .Y(new_n124_));
  NOR2x1_ASAP7_75t_R   g106(.A(new_n119_), .B(new_n53_), .Y(new_n125_));
  NOR2x1_ASAP7_75t_R   g107(.A(p9), .B(new_n106_), .Y(new_n126_));
  OA21x2_ASAP7_75t_R   g108(.A1(new_n59_), .A2(new_n125_), .B(new_n126_), .Y(new_n127_));
  AND3x1_ASAP7_75t_R   g109(.A(p4), .B(p5), .C(p6), .Y(new_n128_));
  OR3x1_ASAP7_75t_R    g110(.A(new_n128_), .B(p7), .C(p9), .Y(new_n129_));
  AND2x2_ASAP7_75t_R   g111(.A(p4), .B(p6), .Y(new_n130_));
  AOI21x1_ASAP7_75t_R  g112(.A1(new_n130_), .A2(new_n126_), .B(new_n74_), .Y(new_n131_));
  AO21x1_ASAP7_75t_R   g113(.A1(new_n129_), .A2(new_n131_), .B(new_n76_), .Y(new_n132_));
  NOR2x1_ASAP7_75t_R   g114(.A(new_n127_), .B(new_n132_), .Y(new_n133_));
  OAI21x1_ASAP7_75t_R  g115(.A1(new_n40_), .A2(new_n124_), .B(new_n133_), .Y(o2));
  AND3x1_ASAP7_75t_R   g116(.A(new_n48_), .B(new_n98_), .C(new_n23_), .Y(new_n135_));
  AND3x1_ASAP7_75t_R   g117(.A(new_n128_), .B(new_n26_), .C(new_n28_), .Y(new_n136_));
  NOR2x1_ASAP7_75t_R   g118(.A(new_n135_), .B(new_n136_), .Y(new_n137_));
  OR3x1_ASAP7_75t_R    g119(.A(new_n137_), .B(p2), .C(new_n40_), .Y(o3));
  AND3x1_ASAP7_75t_R   g120(.A(new_n98_), .B(p10), .C(p0), .Y(new_n139_));
  AND3x1_ASAP7_75t_R   g121(.A(new_n106_), .B(p1), .C(p2), .Y(new_n140_));
  OA21x2_ASAP7_75t_R   g122(.A1(new_n139_), .A2(new_n125_), .B(new_n140_), .Y(new_n141_));
  NAND2x1_ASAP7_75t_R  g123(.A(p2), .B(new_n106_), .Y(new_n142_));
  AND5x1_ASAP7_75t_R   g124(.A(p3), .B(new_n54_), .C(new_n142_), .D(new_n74_), .E(new_n128_), .Y(new_n143_));
  AND3x1_ASAP7_75t_R   g125(.A(new_n81_), .B(p7), .C(p6), .Y(new_n144_));
  NOR2x1_ASAP7_75t_R   g126(.A(new_n74_), .B(new_n144_), .Y(new_n145_));
  OR3x1_ASAP7_75t_R    g127(.A(new_n141_), .B(new_n143_), .C(new_n145_), .Y(new_n146_));
  AND3x1_ASAP7_75t_R   g128(.A(new_n29_), .B(p1), .C(p0), .Y(new_n147_));
  OAI21x1_ASAP7_75t_R  g129(.A1(new_n81_), .A2(new_n147_), .B(new_n46_), .Y(new_n148_));
  NOR2x1_ASAP7_75t_R   g130(.A(p4), .B(p6), .Y(new_n149_));
  NAND2x1_ASAP7_75t_R  g131(.A(p3), .B(new_n149_), .Y(new_n150_));
  AND5x1_ASAP7_75t_R   g132(.A(new_n106_), .B(new_n148_), .C(new_n41_), .D(new_n53_), .E(new_n150_), .Y(new_n151_));
  AOI21x1_ASAP7_75t_R  g133(.A1(new_n41_), .A2(new_n146_), .B(new_n151_), .Y(o4));
  INVx1_ASAP7_75t_R    g134(.A(new_n48_), .Y(new_n153_));
  AND3x1_ASAP7_75t_R   g135(.A(new_n121_), .B(p5), .C(p1), .Y(new_n154_));
  NOR2x1_ASAP7_75t_R   g136(.A(new_n153_), .B(new_n154_), .Y(new_n155_));
  AO32x1_ASAP7_75t_R   g137(.A1(new_n111_), .A2(new_n140_), .A3(new_n149_), .B1(new_n144_), .B2(new_n54_), .Y(new_n156_));
  AO221x2_ASAP7_75t_R  g138(.A1(new_n99_), .A2(new_n155_), .B1(new_n156_), .B2(p3), .C(new_n40_), .Y(o5));
  OR3x1_ASAP7_75t_R    g139(.A(new_n154_), .B(new_n40_), .C(new_n153_), .Y(o6));
endmodule


