// Benchmark "/tmp/" written by ABC on Wed Oct 21 14:44:01 2026

module \/tmp/  ( 
    p2, p8, p5, p1, p4, p0, p10, p3, p7, p9, p6,
    o0, o1, o2, o3, o4, o5, o6  );
  input  p2, p8, p5, p1, p4, p0, p10, p3, p7, p9, p6;
  output o0, o1, o2, o3, o4, o5, o6;
  wire new_n19_, new_n20_, new_n21_, new_n22_, new_n23_, new_n24_, new_n25_,
    new_n26_, new_n27_, new_n28_, new_n29_, new_n30_, new_n31_, new_n32_,
    new_n33_, new_n34_, new_n35_, new_n36_, new_n37_, new_n38_, new_n39_,
    new_n40_, new_n41_, new_n42_, new_n43_, new_n44_, new_n45_, new_n46_,
    new_n47_, new_n48_, new_n49_, new_n50_, new_n51_, new_n52_, new_n53_,
    new_n54_, new_n55_, new_n56_, new_n57_, new_n58_, new_n59_, new_n60_,
    new_n61_, new_n62_, new_n64_, new_n65_, new_n66_, new_n67_, new_n68_,
    new_n69_, new_n70_, new_n71_, new_n72_, new_n73_, new_n74_, new_n75_,
    new_n76_, new_n77_, new_n78_, new_n79_, new_n80_, new_n81_, new_n82_,
    new_n83_, new_n84_, new_n85_, new_n86_, new_n87_, new_n88_, new_n89_,
    new_n90_, new_n91_, new_n92_, new_n93_, new_n94_, new_n95_, new_n96_,
    new_n97_, new_n98_, new_n99_, new_n100_, new_n102_, new_n103_,
    new_n104_, new_n105_, new_n106_, new_n107_, new_n108_, new_n109_,
    new_n110_, new_n111_, new_n112_, new_n113_, new_n114_, new_n115_,
    new_n116_, new_n117_, new_n118_, new_n119_, new_n120_, new_n121_,
    new_n122_, new_n123_, new_n124_, new_n125_, new_n126_, new_n127_,
    new_n128_, new_n129_, new_n130_, new_n131_, new_n133_, new_n134_,
    new_n136_, new_n137_, new_n138_, new_n139_, new_n140_, new_n141_,
    new_n142_, new_n143_, new_n144_, new_n145_, new_n146_, new_n147_,
    new_n148_, new_n149_, new_n151_, new_n152_, new_n153_, new_n154_,
    new_n155_;
  INVx1_ASAP7_75t_R    g000(.A(p4), .Y(new_n19_));
  INVx1_ASAP7_75t_R    g001(.A(p10), .Y(new_n20_));
  NAND2x1_ASAP7_75t_R  g002(.A(p0), .B(p3), .Y(new_n21_));
  INVx1_ASAP7_75t_R    g003(.A(p5), .Y(new_n22_));
  INVx1_ASAP7_75t_R    g004(.A(p6), .Y(new_n23_));
  NAND2x1_ASAP7_75t_R  g005(.A(new_n22_), .B(new_n23_), .Y(new_n24_));
  AO21x1_ASAP7_75t_R   g006(.A1(new_n20_), .A2(new_n21_), .B(new_n24_), .Y(new_n25_));
  INVx1_ASAP7_75t_R    g007(.A(p3), .Y(new_n26_));
  NAND2x1_ASAP7_75t_R  g008(.A(p7), .B(new_n26_), .Y(new_n27_));
  AOI21x1_ASAP7_75t_R  g009(.A1(new_n21_), .A2(new_n27_), .B(new_n20_), .Y(new_n28_));
  INVx1_ASAP7_75t_R    g010(.A(p7), .Y(new_n29_));
  OAI22x1_ASAP7_75t_R  g011(.A1(new_n25_), .A2(new_n28_), .B1(new_n26_), .B2(new_n29_), .Y(new_n30_));
  AOI21x1_ASAP7_75t_R  g012(.A1(p2), .A2(p3), .B(new_n23_), .Y(new_n31_));
  INVx1_ASAP7_75t_R    g013(.A(p2), .Y(new_n32_));
  NAND2x1_ASAP7_75t_R  g014(.A(new_n32_), .B(new_n26_), .Y(new_n33_));
  NOR2x1_ASAP7_75t_R   g015(.A(p1), .B(p6), .Y(new_n34_));
  AND3x1_ASAP7_75t_R   g016(.A(p2), .B(p4), .C(p0), .Y(new_n35_));
  AOI22x1_ASAP7_75t_R  g017(.A1(new_n31_), .A2(new_n33_), .B1(new_n34_), .B2(new_n35_), .Y(new_n36_));
  OAI22x1_ASAP7_75t_R  g018(.A1(new_n36_), .A2(p7), .B1(new_n19_), .B2(new_n27_), .Y(new_n37_));
  AOI21x1_ASAP7_75t_R  g019(.A1(new_n19_), .A2(new_n30_), .B(new_n37_), .Y(new_n38_));
  NOR2x1_ASAP7_75t_R   g020(.A(p8), .B(p9), .Y(new_n39_));
  INVx1_ASAP7_75t_R    g021(.A(new_n39_), .Y(new_n40_));
  INVx1_ASAP7_75t_R    g022(.A(p9), .Y(new_n41_));
  INVx1_ASAP7_75t_R    g023(.A(p0), .Y(new_n42_));
  AOI211x1_ASAP7_75t_R g024(.A1(p6), .A2(new_n26_), .B(p1), .C(new_n42_), .Y(new_n43_));
  AO21x1_ASAP7_75t_R   g025(.A1(new_n32_), .A2(new_n29_), .B(new_n26_), .Y(new_n44_));
  NOR2x1_ASAP7_75t_R   g026(.A(p5), .B(new_n19_), .Y(new_n45_));
  NAND3x1_ASAP7_75t_R  g027(.A(new_n43_), .B(new_n44_), .C(new_n45_), .Y(new_n46_));
  NOR2x1_ASAP7_75t_R   g028(.A(p7), .B(p6), .Y(new_n47_));
  AO31x2_ASAP7_75t_R   g029(.A1(new_n47_), .A2(p1), .A3(new_n42_), .B(p8), .Y(new_n48_));
  AND3x1_ASAP7_75t_R   g030(.A(new_n19_), .B(p8), .C(p5), .Y(new_n49_));
  AOI21x1_ASAP7_75t_R  g031(.A1(new_n45_), .A2(new_n48_), .B(new_n49_), .Y(new_n50_));
  NAND2x1_ASAP7_75t_R  g032(.A(new_n46_), .B(new_n50_), .Y(new_n51_));
  NAND2x1_ASAP7_75t_R  g033(.A(p5), .B(new_n23_), .Y(new_n52_));
  AND2x2_ASAP7_75t_R   g034(.A(p2), .B(p1), .Y(new_n53_));
  NOR2x1_ASAP7_75t_R   g035(.A(p2), .B(p1), .Y(new_n54_));
  INVx1_ASAP7_75t_R    g036(.A(p8), .Y(new_n55_));
  NAND2x1_ASAP7_75t_R  g037(.A(new_n55_), .B(new_n29_), .Y(new_n56_));
  OA31x2_ASAP7_75t_R   g038(.A1(new_n53_), .A2(new_n54_), .A3(new_n56_), .B1(new_n41_), .Y(new_n57_));
  NAND2x1_ASAP7_75t_R  g039(.A(p6), .B(new_n22_), .Y(new_n58_));
  OR3x1_ASAP7_75t_R    g040(.A(new_n55_), .B(new_n22_), .C(new_n29_), .Y(new_n59_));
  AO21x1_ASAP7_75t_R   g041(.A1(new_n58_), .A2(new_n59_), .B(new_n41_), .Y(new_n60_));
  OAI21x1_ASAP7_75t_R  g042(.A1(new_n52_), .A2(new_n57_), .B(new_n60_), .Y(new_n61_));
  AOI21x1_ASAP7_75t_R  g043(.A1(new_n41_), .A2(new_n51_), .B(new_n61_), .Y(new_n62_));
  OAI21x1_ASAP7_75t_R  g044(.A1(new_n38_), .A2(new_n40_), .B(new_n62_), .Y(o0));
  NAND2x1_ASAP7_75t_R  g045(.A(p2), .B(p3), .Y(new_n64_));
  NAND2x1_ASAP7_75t_R  g046(.A(p6), .B(new_n64_), .Y(new_n65_));
  NAND2x1_ASAP7_75t_R  g047(.A(p8), .B(new_n23_), .Y(new_n66_));
  OAI21x1_ASAP7_75t_R  g048(.A1(new_n56_), .A2(new_n65_), .B(new_n66_), .Y(new_n67_));
  OAI21x1_ASAP7_75t_R  g049(.A1(p5), .A2(p6), .B(new_n26_), .Y(new_n68_));
  OAI21x1_ASAP7_75t_R  g050(.A1(p8), .A2(p7), .B(p3), .Y(new_n69_));
  AO21x1_ASAP7_75t_R   g051(.A1(p1), .A2(p0), .B(p6), .Y(new_n70_));
  AND5x1_ASAP7_75t_R   g052(.A(p2), .B(new_n68_), .C(p4), .D(new_n69_), .E(new_n70_), .Y(new_n71_));
  AOI21x1_ASAP7_75t_R  g053(.A1(new_n19_), .A2(new_n67_), .B(new_n71_), .Y(new_n72_));
  NOR2x1_ASAP7_75t_R   g054(.A(p8), .B(p3), .Y(new_n73_));
  INVx1_ASAP7_75t_R    g055(.A(new_n73_), .Y(new_n74_));
  AOI21x1_ASAP7_75t_R  g056(.A1(new_n66_), .A2(new_n74_), .B(p5), .Y(new_n75_));
  AND2x2_ASAP7_75t_R   g057(.A(p5), .B(p4), .Y(new_n76_));
  AND3x1_ASAP7_75t_R   g058(.A(new_n74_), .B(new_n66_), .C(new_n76_), .Y(new_n77_));
  OAI21x1_ASAP7_75t_R  g059(.A1(new_n75_), .A2(new_n77_), .B(new_n56_), .Y(new_n78_));
  OAI22x1_ASAP7_75t_R  g060(.A1(p8), .A2(p3), .B1(p1), .B2(p6), .Y(new_n79_));
  AO22x1_ASAP7_75t_R   g061(.A1(new_n55_), .A2(p7), .B1(new_n42_), .B2(new_n79_), .Y(new_n80_));
  NAND2x1_ASAP7_75t_R  g062(.A(p1), .B(p0), .Y(new_n81_));
  NAND2x1_ASAP7_75t_R  g063(.A(p3), .B(new_n23_), .Y(new_n82_));
  INVx1_ASAP7_75t_R    g064(.A(p1), .Y(new_n83_));
  NOR2x1_ASAP7_75t_R   g065(.A(p10), .B(new_n83_), .Y(new_n84_));
  AOI211x1_ASAP7_75t_R g066(.A1(p10), .A2(new_n81_), .B(new_n82_), .C(new_n84_), .Y(new_n85_));
  NOR2x1_ASAP7_75t_R   g067(.A(p5), .B(p4), .Y(new_n86_));
  OAI21x1_ASAP7_75t_R  g068(.A1(new_n80_), .A2(new_n85_), .B(new_n86_), .Y(new_n87_));
  NAND3x1_ASAP7_75t_R  g069(.A(new_n72_), .B(new_n78_), .C(new_n87_), .Y(new_n88_));
  AO21x1_ASAP7_75t_R   g070(.A1(p5), .A2(p6), .B(p7), .Y(new_n89_));
  NAND3x1_ASAP7_75t_R  g071(.A(new_n55_), .B(p5), .C(p3), .Y(new_n90_));
  AOI21x1_ASAP7_75t_R  g072(.A1(new_n53_), .A2(new_n90_), .B(p6), .Y(new_n91_));
  NAND2x1_ASAP7_75t_R  g073(.A(p4), .B(new_n22_), .Y(new_n92_));
  AO21x1_ASAP7_75t_R   g074(.A1(p1), .A2(p0), .B(p2), .Y(new_n93_));
  AOI21x1_ASAP7_75t_R  g075(.A1(p5), .A2(new_n73_), .B(new_n53_), .Y(new_n94_));
  OAI21x1_ASAP7_75t_R  g076(.A1(new_n92_), .A2(new_n93_), .B(new_n94_), .Y(new_n95_));
  AOI21x1_ASAP7_75t_R  g077(.A1(new_n91_), .A2(new_n95_), .B(p9), .Y(new_n96_));
  NAND2x1_ASAP7_75t_R  g078(.A(p5), .B(p6), .Y(new_n97_));
  NAND2x1_ASAP7_75t_R  g079(.A(p7), .B(p9), .Y(new_n98_));
  OR3x1_ASAP7_75t_R    g080(.A(new_n97_), .B(new_n98_), .C(p8), .Y(new_n99_));
  OAI21x1_ASAP7_75t_R  g081(.A1(new_n89_), .A2(new_n96_), .B(new_n99_), .Y(new_n100_));
  AOI21x1_ASAP7_75t_R  g082(.A1(new_n41_), .A2(new_n88_), .B(new_n100_), .Y(o1));
  AND2x2_ASAP7_75t_R   g083(.A(p4), .B(p3), .Y(new_n102_));
  AND3x1_ASAP7_75t_R   g084(.A(new_n102_), .B(p5), .C(new_n34_), .Y(new_n103_));
  NOR2x1_ASAP7_75t_R   g085(.A(new_n97_), .B(new_n102_), .Y(new_n104_));
  AND5x1_ASAP7_75t_R   g086(.A(new_n22_), .B(p2), .C(p4), .D(p3), .E(p6), .Y(new_n105_));
  OR3x1_ASAP7_75t_R    g087(.A(new_n103_), .B(new_n104_), .C(new_n105_), .Y(new_n106_));
  OR3x1_ASAP7_75t_R    g088(.A(new_n22_), .B(new_n83_), .C(p4), .Y(new_n107_));
  INVx1_ASAP7_75t_R    g089(.A(new_n64_), .Y(new_n108_));
  OA21x2_ASAP7_75t_R   g090(.A1(p0), .A2(new_n92_), .B(new_n108_), .Y(new_n109_));
  NAND2x1_ASAP7_75t_R  g091(.A(p5), .B(p4), .Y(new_n110_));
  AO21x1_ASAP7_75t_R   g092(.A1(new_n64_), .A2(new_n110_), .B(p7), .Y(new_n111_));
  AOI21x1_ASAP7_75t_R  g093(.A1(new_n107_), .A2(new_n109_), .B(new_n111_), .Y(new_n112_));
  OAI21x1_ASAP7_75t_R  g094(.A1(new_n106_), .A2(new_n112_), .B(new_n39_), .Y(new_n113_));
  OR3x1_ASAP7_75t_R    g095(.A(new_n32_), .B(new_n19_), .C(p3), .Y(new_n114_));
  OR4x2_ASAP7_75t_R    g096(.A(new_n20_), .B(new_n26_), .C(p2), .D(p5), .Y(new_n115_));
  AO21x1_ASAP7_75t_R   g097(.A1(new_n114_), .A2(new_n115_), .B(new_n81_), .Y(new_n116_));
  AND3x1_ASAP7_75t_R   g098(.A(new_n22_), .B(new_n19_), .C(new_n26_), .Y(new_n117_));
  AND2x2_ASAP7_75t_R   g099(.A(p0), .B(p10), .Y(new_n118_));
  NOR3x1_ASAP7_75t_R   g100(.A(new_n118_), .B(p4), .C(new_n64_), .Y(new_n119_));
  OAI21x1_ASAP7_75t_R  g101(.A1(new_n117_), .A2(new_n119_), .B(p1), .Y(new_n120_));
  NOR2x1_ASAP7_75t_R   g102(.A(p5), .B(p1), .Y(new_n121_));
  AOI22x1_ASAP7_75t_R  g103(.A1(new_n108_), .A2(new_n121_), .B1(new_n32_), .B2(new_n102_), .Y(new_n122_));
  NAND2x1_ASAP7_75t_R  g104(.A(new_n39_), .B(new_n47_), .Y(new_n123_));
  AO31x2_ASAP7_75t_R   g105(.A1(new_n116_), .A2(new_n120_), .A3(new_n122_), .B(new_n123_), .Y(new_n124_));
  NAND2x1_ASAP7_75t_R  g106(.A(p4), .B(p6), .Y(new_n125_));
  OA211x2_ASAP7_75t_R  g107(.A1(new_n22_), .A2(new_n125_), .B(new_n29_), .C(new_n41_), .Y(new_n126_));
  NAND2x1_ASAP7_75t_R  g108(.A(p7), .B(new_n41_), .Y(new_n127_));
  OAI21x1_ASAP7_75t_R  g109(.A1(new_n125_), .A2(new_n127_), .B(p8), .Y(new_n128_));
  OA21x2_ASAP7_75t_R   g110(.A1(new_n110_), .A2(new_n82_), .B(new_n58_), .Y(new_n129_));
  OR3x1_ASAP7_75t_R    g111(.A(new_n97_), .B(new_n29_), .C(new_n41_), .Y(new_n130_));
  OA221x2_ASAP7_75t_R  g112(.A1(new_n126_), .A2(new_n128_), .B1(new_n127_), .B2(new_n129_), .C(new_n130_), .Y(new_n131_));
  NAND3x1_ASAP7_75t_R  g113(.A(new_n113_), .B(new_n124_), .C(new_n131_), .Y(o2));
  AND5x1_ASAP7_75t_R   g114(.A(new_n83_), .B(new_n76_), .C(p3), .D(p7), .E(p6), .Y(new_n133_));
  AOI21x1_ASAP7_75t_R  g115(.A1(new_n47_), .A2(new_n117_), .B(new_n133_), .Y(new_n134_));
  OR3x1_ASAP7_75t_R    g116(.A(new_n134_), .B(p2), .C(new_n40_), .Y(o3));
  AND3x1_ASAP7_75t_R   g117(.A(new_n86_), .B(p0), .C(p10), .Y(new_n136_));
  NOR2x1_ASAP7_75t_R   g118(.A(new_n110_), .B(new_n82_), .Y(new_n137_));
  AND3x1_ASAP7_75t_R   g119(.A(new_n29_), .B(p2), .C(p1), .Y(new_n138_));
  OAI21x1_ASAP7_75t_R  g120(.A1(new_n136_), .A2(new_n137_), .B(new_n138_), .Y(new_n139_));
  AO21x1_ASAP7_75t_R   g121(.A1(p2), .A2(new_n29_), .B(new_n54_), .Y(new_n140_));
  OR3x1_ASAP7_75t_R    g122(.A(new_n140_), .B(new_n90_), .C(new_n125_), .Y(new_n141_));
  AND2x2_ASAP7_75t_R   g123(.A(p7), .B(p6), .Y(new_n142_));
  AO21x1_ASAP7_75t_R   g124(.A1(new_n76_), .A2(new_n142_), .B(new_n55_), .Y(new_n143_));
  NAND3x1_ASAP7_75t_R  g125(.A(new_n139_), .B(new_n141_), .C(new_n143_), .Y(new_n144_));
  NAND2x1_ASAP7_75t_R  g126(.A(new_n19_), .B(new_n23_), .Y(new_n145_));
  OR3x1_ASAP7_75t_R    g127(.A(new_n83_), .B(new_n42_), .C(p6), .Y(new_n146_));
  AO21x1_ASAP7_75t_R   g128(.A1(new_n110_), .A2(new_n146_), .B(new_n32_), .Y(new_n147_));
  AO21x1_ASAP7_75t_R   g129(.A1(new_n145_), .A2(new_n147_), .B(new_n26_), .Y(new_n148_));
  AND3x1_ASAP7_75t_R   g130(.A(new_n52_), .B(new_n29_), .C(new_n41_), .Y(new_n149_));
  AOI22x1_ASAP7_75t_R  g131(.A1(new_n144_), .A2(new_n41_), .B1(new_n148_), .B2(new_n149_), .Y(o4));
  OR4x2_ASAP7_75t_R    g132(.A(new_n64_), .B(new_n22_), .C(new_n83_), .D(new_n19_), .Y(new_n151_));
  OA21x2_ASAP7_75t_R   g133(.A1(p5), .A2(p4), .B(new_n47_), .Y(new_n152_));
  INVx1_ASAP7_75t_R    g134(.A(new_n54_), .Y(new_n153_));
  AND3x1_ASAP7_75t_R   g135(.A(new_n118_), .B(new_n19_), .C(new_n23_), .Y(new_n154_));
  AO32x1_ASAP7_75t_R   g136(.A1(new_n153_), .A2(new_n76_), .A3(new_n142_), .B1(new_n154_), .B2(new_n138_), .Y(new_n155_));
  AO221x2_ASAP7_75t_R  g137(.A1(new_n151_), .A2(new_n152_), .B1(new_n155_), .B2(p3), .C(new_n40_), .Y(o5));
  NAND3x1_ASAP7_75t_R  g138(.A(new_n151_), .B(new_n39_), .C(new_n47_), .Y(o6));
endmodule


