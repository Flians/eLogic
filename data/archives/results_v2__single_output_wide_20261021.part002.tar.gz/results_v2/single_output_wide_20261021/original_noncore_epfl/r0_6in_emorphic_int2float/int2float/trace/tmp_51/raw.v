// Benchmark "/tmp/" written by ABC on Wed Oct 21 14:44:00 2026

module \/tmp/  ( 
    p1, p8, p10, p4, p7, p5, p9, p6, p3, p2, p0,
    o0, o1, o2, o3, o4, o5, o6  );
  input  p1, p8, p10, p4, p7, p5, p9, p6, p3, p2, p0;
  output o0, o1, o2, o3, o4, o5, o6;
  wire new_n19_, new_n20_, new_n21_, new_n22_, new_n23_, new_n24_, new_n25_,
    new_n26_, new_n27_, new_n28_, new_n29_, new_n30_, new_n31_, new_n32_,
    new_n33_, new_n34_, new_n35_, new_n36_, new_n37_, new_n38_, new_n39_,
    new_n40_, new_n41_, new_n42_, new_n43_, new_n44_, new_n45_, new_n46_,
    new_n47_, new_n48_, new_n49_, new_n50_, new_n51_, new_n52_, new_n53_,
    new_n54_, new_n55_, new_n56_, new_n57_, new_n58_, new_n59_, new_n60_,
    new_n61_, new_n62_, new_n64_, new_n65_, new_n66_, new_n67_, new_n68_,
    new_n69_, new_n70_, new_n71_, new_n72_, new_n73_, new_n74_, new_n75_,
    new_n76_, new_n77_, new_n78_, new_n79_, new_n80_, new_n81_, new_n82_,
    new_n83_, new_n84_, new_n85_, new_n86_, new_n87_, new_n88_, new_n89_,
    new_n90_, new_n91_, new_n92_, new_n93_, new_n94_, new_n95_, new_n96_,
    new_n97_, new_n98_, new_n99_, new_n100_, new_n102_, new_n103_,
    new_n104_, new_n105_, new_n106_, new_n107_, new_n108_, new_n109_,
    new_n110_, new_n111_, new_n112_, new_n113_, new_n114_, new_n115_,
    new_n116_, new_n117_, new_n118_, new_n119_, new_n120_, new_n121_,
    new_n122_, new_n123_, new_n124_, new_n125_, new_n126_, new_n127_,
    new_n128_, new_n129_, new_n130_, new_n131_, new_n133_, new_n134_,
    new_n135_, new_n136_, new_n138_, new_n139_, new_n140_, new_n141_,
    new_n142_, new_n143_, new_n144_, new_n145_, new_n146_, new_n147_,
    new_n148_, new_n149_, new_n150_, new_n152_, new_n153_, new_n154_,
    new_n155_, new_n156_;
  INVx1_ASAP7_75t_R    g000(.A(p4), .Y(new_n19_));
  INVx1_ASAP7_75t_R    g001(.A(p10), .Y(new_n20_));
  NAND2x1_ASAP7_75t_R  g002(.A(p3), .B(p0), .Y(new_n21_));
  AOI211x1_ASAP7_75t_R g003(.A1(new_n20_), .A2(new_n21_), .B(p5), .C(p6), .Y(new_n22_));
  INVx1_ASAP7_75t_R    g004(.A(p3), .Y(new_n23_));
  NAND2x1_ASAP7_75t_R  g005(.A(p7), .B(new_n23_), .Y(new_n24_));
  AO21x1_ASAP7_75t_R   g006(.A1(new_n21_), .A2(new_n24_), .B(new_n20_), .Y(new_n25_));
  AND2x2_ASAP7_75t_R   g007(.A(p7), .B(p3), .Y(new_n26_));
  AO21x1_ASAP7_75t_R   g008(.A1(new_n22_), .A2(new_n25_), .B(new_n26_), .Y(new_n27_));
  INVx1_ASAP7_75t_R    g009(.A(p6), .Y(new_n28_));
  AOI21x1_ASAP7_75t_R  g010(.A1(p3), .A2(p2), .B(new_n28_), .Y(new_n29_));
  INVx1_ASAP7_75t_R    g011(.A(p2), .Y(new_n30_));
  NAND2x1_ASAP7_75t_R  g012(.A(new_n23_), .B(new_n30_), .Y(new_n31_));
  NOR2x1_ASAP7_75t_R   g013(.A(p1), .B(p6), .Y(new_n32_));
  AND3x1_ASAP7_75t_R   g014(.A(p4), .B(p2), .C(p0), .Y(new_n33_));
  AOI22x1_ASAP7_75t_R  g015(.A1(new_n29_), .A2(new_n31_), .B1(new_n32_), .B2(new_n33_), .Y(new_n34_));
  OAI22x1_ASAP7_75t_R  g016(.A1(new_n34_), .A2(p7), .B1(new_n19_), .B2(new_n24_), .Y(new_n35_));
  AOI21x1_ASAP7_75t_R  g017(.A1(new_n19_), .A2(new_n27_), .B(new_n35_), .Y(new_n36_));
  NOR2x1_ASAP7_75t_R   g018(.A(p8), .B(p9), .Y(new_n37_));
  INVx1_ASAP7_75t_R    g019(.A(new_n37_), .Y(new_n38_));
  INVx1_ASAP7_75t_R    g020(.A(p9), .Y(new_n39_));
  NOR2x1_ASAP7_75t_R   g021(.A(p5), .B(new_n19_), .Y(new_n40_));
  INVx1_ASAP7_75t_R    g022(.A(new_n40_), .Y(new_n41_));
  NOR2x1_ASAP7_75t_R   g023(.A(p3), .B(new_n28_), .Y(new_n42_));
  INVx1_ASAP7_75t_R    g024(.A(p0), .Y(new_n43_));
  AND2x2_ASAP7_75t_R   g025(.A(p3), .B(p2), .Y(new_n44_));
  OR5x1_ASAP7_75t_R    g026(.A(p1), .B(new_n42_), .C(new_n43_), .D(new_n26_), .E(new_n44_), .Y(new_n45_));
  NOR2x1_ASAP7_75t_R   g027(.A(p7), .B(p6), .Y(new_n46_));
  AO31x2_ASAP7_75t_R   g028(.A1(new_n46_), .A2(p1), .A3(new_n43_), .B(p8), .Y(new_n47_));
  AND2x2_ASAP7_75t_R   g029(.A(p8), .B(p5), .Y(new_n48_));
  AOI22x1_ASAP7_75t_R  g030(.A1(new_n47_), .A2(new_n40_), .B1(new_n19_), .B2(new_n48_), .Y(new_n49_));
  OAI21x1_ASAP7_75t_R  g031(.A1(new_n41_), .A2(new_n45_), .B(new_n49_), .Y(new_n50_));
  NAND2x1_ASAP7_75t_R  g032(.A(p5), .B(new_n28_), .Y(new_n51_));
  NOR2x1_ASAP7_75t_R   g033(.A(p8), .B(p7), .Y(new_n52_));
  NOR2x1_ASAP7_75t_R   g034(.A(p1), .B(p2), .Y(new_n53_));
  AND2x2_ASAP7_75t_R   g035(.A(p1), .B(p2), .Y(new_n54_));
  NOR2x1_ASAP7_75t_R   g036(.A(new_n53_), .B(new_n54_), .Y(new_n55_));
  AOI21x1_ASAP7_75t_R  g037(.A1(new_n52_), .A2(new_n55_), .B(p9), .Y(new_n56_));
  INVx1_ASAP7_75t_R    g038(.A(p5), .Y(new_n57_));
  NAND2x1_ASAP7_75t_R  g039(.A(p6), .B(new_n57_), .Y(new_n58_));
  NAND2x1_ASAP7_75t_R  g040(.A(p7), .B(new_n48_), .Y(new_n59_));
  AO21x1_ASAP7_75t_R   g041(.A1(new_n58_), .A2(new_n59_), .B(new_n39_), .Y(new_n60_));
  OAI21x1_ASAP7_75t_R  g042(.A1(new_n51_), .A2(new_n56_), .B(new_n60_), .Y(new_n61_));
  AOI21x1_ASAP7_75t_R  g043(.A1(new_n39_), .A2(new_n50_), .B(new_n61_), .Y(new_n62_));
  OAI21x1_ASAP7_75t_R  g044(.A1(new_n36_), .A2(new_n38_), .B(new_n62_), .Y(o0));
  AO21x1_ASAP7_75t_R   g045(.A1(p5), .A2(p6), .B(p7), .Y(new_n64_));
  AO21x1_ASAP7_75t_R   g046(.A1(new_n39_), .A2(p6), .B(new_n64_), .Y(new_n65_));
  NOR3x1_ASAP7_75t_R   g047(.A(new_n57_), .B(p8), .C(p3), .Y(new_n66_));
  NOR3x1_ASAP7_75t_R   g048(.A(new_n19_), .B(p5), .C(p2), .Y(new_n67_));
  INVx1_ASAP7_75t_R    g049(.A(p1), .Y(new_n68_));
  OAI21x1_ASAP7_75t_R  g050(.A1(new_n66_), .A2(new_n67_), .B(new_n68_), .Y(new_n69_));
  NOR3x1_ASAP7_75t_R   g051(.A(new_n19_), .B(p5), .C(p0), .Y(new_n70_));
  OAI21x1_ASAP7_75t_R  g052(.A1(new_n66_), .A2(new_n70_), .B(new_n30_), .Y(new_n71_));
  OR5x1_ASAP7_75t_R    g053(.A(new_n68_), .B(new_n57_), .C(new_n23_), .D(new_n30_), .E(p8), .Y(new_n72_));
  AND4x2_ASAP7_75t_R   g054(.A(new_n69_), .B(new_n71_), .C(new_n39_), .D(new_n72_), .Y(new_n73_));
  INVx1_ASAP7_75t_R    g055(.A(p8), .Y(new_n74_));
  AND4x2_ASAP7_75t_R   g056(.A(p7), .B(p5), .C(p9), .D(p6), .Y(new_n75_));
  NAND2x1_ASAP7_75t_R  g057(.A(new_n74_), .B(new_n75_), .Y(new_n76_));
  OAI21x1_ASAP7_75t_R  g058(.A1(new_n65_), .A2(new_n73_), .B(new_n76_), .Y(new_n77_));
  NOR2x1_ASAP7_75t_R   g059(.A(p8), .B(p3), .Y(new_n78_));
  AO21x1_ASAP7_75t_R   g060(.A1(p8), .A2(new_n28_), .B(new_n78_), .Y(new_n79_));
  AOI221x1_ASAP7_75t_R g061(.A1(p4), .A2(p5), .B1(p8), .B2(new_n28_), .C(new_n78_), .Y(new_n80_));
  AOI211x1_ASAP7_75t_R g062(.A1(p5), .A2(new_n79_), .B(new_n52_), .C(new_n80_), .Y(new_n81_));
  NOR2x1_ASAP7_75t_R   g063(.A(p6), .B(new_n74_), .Y(new_n82_));
  AOI21x1_ASAP7_75t_R  g064(.A1(new_n52_), .A2(new_n29_), .B(new_n82_), .Y(new_n83_));
  NOR3x1_ASAP7_75t_R   g065(.A(p5), .B(p6), .C(p3), .Y(new_n84_));
  NOR3x1_ASAP7_75t_R   g066(.A(new_n23_), .B(p8), .C(p7), .Y(new_n85_));
  NAND2x1_ASAP7_75t_R  g067(.A(p4), .B(p2), .Y(new_n86_));
  AOI21x1_ASAP7_75t_R  g068(.A1(p1), .A2(p0), .B(p6), .Y(new_n87_));
  NOR2x1_ASAP7_75t_R   g069(.A(new_n86_), .B(new_n87_), .Y(new_n88_));
  OAI21x1_ASAP7_75t_R  g070(.A1(new_n84_), .A2(new_n85_), .B(new_n88_), .Y(new_n89_));
  OAI21x1_ASAP7_75t_R  g071(.A1(p4), .A2(new_n83_), .B(new_n89_), .Y(new_n90_));
  OAI22x1_ASAP7_75t_R  g072(.A1(p1), .A2(p6), .B1(p8), .B2(p3), .Y(new_n91_));
  AOI22x1_ASAP7_75t_R  g073(.A1(new_n91_), .A2(new_n43_), .B1(new_n74_), .B2(p7), .Y(new_n92_));
  OAI21x1_ASAP7_75t_R  g074(.A1(new_n68_), .A2(new_n43_), .B(p10), .Y(new_n93_));
  NAND2x1_ASAP7_75t_R  g075(.A(p1), .B(new_n20_), .Y(new_n94_));
  NOR2x1_ASAP7_75t_R   g076(.A(p6), .B(new_n23_), .Y(new_n95_));
  NAND3x1_ASAP7_75t_R  g077(.A(new_n93_), .B(new_n94_), .C(new_n95_), .Y(new_n96_));
  NOR2x1_ASAP7_75t_R   g078(.A(p4), .B(p5), .Y(new_n97_));
  INVx1_ASAP7_75t_R    g079(.A(new_n97_), .Y(new_n98_));
  AOI21x1_ASAP7_75t_R  g080(.A1(new_n92_), .A2(new_n96_), .B(new_n98_), .Y(new_n99_));
  OA31x2_ASAP7_75t_R   g081(.A1(new_n81_), .A2(new_n90_), .A3(new_n99_), .B1(new_n39_), .Y(new_n100_));
  NOR2x1_ASAP7_75t_R   g082(.A(new_n77_), .B(new_n100_), .Y(o1));
  NAND2x1_ASAP7_75t_R  g083(.A(p3), .B(p2), .Y(new_n102_));
  NAND2x1_ASAP7_75t_R  g084(.A(p4), .B(p5), .Y(new_n103_));
  AO21x1_ASAP7_75t_R   g085(.A1(new_n102_), .A2(new_n103_), .B(p7), .Y(new_n104_));
  AND3x1_ASAP7_75t_R   g086(.A(new_n19_), .B(p1), .C(p5), .Y(new_n105_));
  NOR3x1_ASAP7_75t_R   g087(.A(new_n105_), .B(new_n70_), .C(new_n102_), .Y(new_n106_));
  AND5x1_ASAP7_75t_R   g088(.A(new_n68_), .B(new_n28_), .C(p4), .D(p5), .E(p3), .Y(new_n107_));
  AND5x1_ASAP7_75t_R   g089(.A(new_n57_), .B(p4), .C(p6), .D(p3), .E(p2), .Y(new_n108_));
  AOI211x1_ASAP7_75t_R g090(.A1(p4), .A2(p3), .B(new_n57_), .C(new_n28_), .Y(new_n109_));
  NOR3x1_ASAP7_75t_R   g091(.A(new_n107_), .B(new_n108_), .C(new_n109_), .Y(new_n110_));
  OAI21x1_ASAP7_75t_R  g092(.A1(new_n104_), .A2(new_n106_), .B(new_n110_), .Y(new_n111_));
  OR3x1_ASAP7_75t_R    g093(.A(new_n103_), .B(p6), .C(new_n23_), .Y(new_n112_));
  NAND2x1_ASAP7_75t_R  g094(.A(p7), .B(new_n39_), .Y(new_n113_));
  AO21x1_ASAP7_75t_R   g095(.A1(new_n58_), .A2(new_n112_), .B(new_n113_), .Y(new_n114_));
  OA21x2_ASAP7_75t_R   g096(.A1(p7), .A2(p9), .B(p8), .Y(new_n115_));
  OR3x1_ASAP7_75t_R    g097(.A(new_n19_), .B(new_n28_), .C(p9), .Y(new_n116_));
  INVx1_ASAP7_75t_R    g098(.A(p7), .Y(new_n117_));
  AND5x1_ASAP7_75t_R   g099(.A(p8), .B(new_n117_), .C(p4), .D(p5), .E(p6), .Y(new_n118_));
  AOI211x1_ASAP7_75t_R g100(.A1(new_n115_), .A2(new_n116_), .B(new_n75_), .C(new_n118_), .Y(new_n119_));
  NAND2x1_ASAP7_75t_R  g101(.A(new_n114_), .B(new_n119_), .Y(new_n120_));
  AOI21x1_ASAP7_75t_R  g102(.A1(new_n37_), .A2(new_n111_), .B(new_n120_), .Y(new_n121_));
  OAI21x1_ASAP7_75t_R  g103(.A1(new_n97_), .A2(new_n33_), .B(new_n23_), .Y(new_n122_));
  AND2x2_ASAP7_75t_R   g104(.A(p10), .B(p0), .Y(new_n123_));
  OR3x1_ASAP7_75t_R    g105(.A(new_n123_), .B(p4), .C(new_n102_), .Y(new_n124_));
  AO21x1_ASAP7_75t_R   g106(.A1(new_n122_), .A2(new_n124_), .B(new_n68_), .Y(new_n125_));
  NAND2x1_ASAP7_75t_R  g107(.A(p4), .B(new_n30_), .Y(new_n126_));
  AOI21x1_ASAP7_75t_R  g108(.A1(p10), .A2(p0), .B(p2), .Y(new_n127_));
  OR4x2_ASAP7_75t_R    g109(.A(new_n54_), .B(new_n127_), .C(p5), .D(new_n53_), .Y(new_n128_));
  AO21x1_ASAP7_75t_R   g110(.A1(new_n126_), .A2(new_n128_), .B(new_n23_), .Y(new_n129_));
  NAND2x1_ASAP7_75t_R  g111(.A(new_n37_), .B(new_n46_), .Y(new_n130_));
  AO21x1_ASAP7_75t_R   g112(.A1(new_n125_), .A2(new_n129_), .B(new_n130_), .Y(new_n131_));
  NAND2x1_ASAP7_75t_R  g113(.A(new_n121_), .B(new_n131_), .Y(o2));
  OR5x1_ASAP7_75t_R    g114(.A(p1), .B(new_n103_), .C(new_n117_), .D(new_n28_), .E(new_n23_), .Y(new_n133_));
  INVx1_ASAP7_75t_R    g115(.A(new_n46_), .Y(new_n134_));
  OR3x1_ASAP7_75t_R    g116(.A(new_n134_), .B(new_n98_), .C(p3), .Y(new_n135_));
  OR3x1_ASAP7_75t_R    g117(.A(p8), .B(p9), .C(p2), .Y(new_n136_));
  AO21x1_ASAP7_75t_R   g118(.A1(new_n133_), .A2(new_n135_), .B(new_n136_), .Y(o3));
  OR3x1_ASAP7_75t_R    g119(.A(new_n103_), .B(new_n117_), .C(new_n28_), .Y(new_n138_));
  NOR2x1_ASAP7_75t_R   g120(.A(p7), .B(new_n30_), .Y(new_n139_));
  NOR2x1_ASAP7_75t_R   g121(.A(new_n53_), .B(new_n139_), .Y(new_n140_));
  AND5x1_ASAP7_75t_R   g122(.A(new_n74_), .B(p4), .C(p5), .D(p6), .E(p3), .Y(new_n141_));
  NAND2x1_ASAP7_75t_R  g123(.A(new_n97_), .B(new_n123_), .Y(new_n142_));
  OR3x1_ASAP7_75t_R    g124(.A(new_n68_), .B(new_n30_), .C(p7), .Y(new_n143_));
  AOI21x1_ASAP7_75t_R  g125(.A1(new_n142_), .A2(new_n112_), .B(new_n143_), .Y(new_n144_));
  AO221x2_ASAP7_75t_R  g126(.A1(p8), .A2(new_n138_), .B1(new_n140_), .B2(new_n141_), .C(new_n144_), .Y(new_n145_));
  NAND2x1_ASAP7_75t_R  g127(.A(new_n19_), .B(new_n28_), .Y(new_n146_));
  OR3x1_ASAP7_75t_R    g128(.A(new_n68_), .B(new_n43_), .C(p6), .Y(new_n147_));
  AO21x1_ASAP7_75t_R   g129(.A1(new_n103_), .A2(new_n147_), .B(new_n30_), .Y(new_n148_));
  AO21x1_ASAP7_75t_R   g130(.A1(new_n146_), .A2(new_n148_), .B(new_n23_), .Y(new_n149_));
  AND3x1_ASAP7_75t_R   g131(.A(new_n51_), .B(new_n117_), .C(new_n39_), .Y(new_n150_));
  AOI22x1_ASAP7_75t_R  g132(.A1(new_n145_), .A2(new_n39_), .B1(new_n149_), .B2(new_n150_), .Y(o4));
  NOR2x1_ASAP7_75t_R   g133(.A(new_n53_), .B(new_n138_), .Y(new_n152_));
  AND5x1_ASAP7_75t_R   g134(.A(p1), .B(new_n139_), .C(new_n19_), .D(new_n28_), .E(new_n123_), .Y(new_n153_));
  OA21x2_ASAP7_75t_R   g135(.A1(new_n152_), .A2(new_n153_), .B(p3), .Y(new_n154_));
  AND5x1_ASAP7_75t_R   g136(.A(p1), .B(p4), .C(p5), .D(p3), .E(p2), .Y(new_n155_));
  NOR3x1_ASAP7_75t_R   g137(.A(new_n155_), .B(new_n134_), .C(new_n97_), .Y(new_n156_));
  OR3x1_ASAP7_75t_R    g138(.A(new_n154_), .B(new_n38_), .C(new_n156_), .Y(o5));
  OR3x1_ASAP7_75t_R    g139(.A(new_n155_), .B(new_n38_), .C(new_n134_), .Y(o6));
endmodule


