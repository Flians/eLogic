// Benchmark "/tmp/" written by ABC on Wed Oct 21 14:43:51 2026

module \/tmp/  ( 
    p4, p1, p10, p3, p5, p7, p2, p6, p0, p8, p9,
    o0, o1, o2, o3, o4, o5, o6  );
  input  p4, p1, p10, p3, p5, p7, p2, p6, p0, p8, p9;
  output o0, o1, o2, o3, o4, o5, o6;
  wire new_n19_, new_n20_, new_n21_, new_n22_, new_n23_, new_n24_, new_n25_,
    new_n26_, new_n27_, new_n28_, new_n29_, new_n30_, new_n31_, new_n32_,
    new_n33_, new_n34_, new_n35_, new_n36_, new_n37_, new_n38_, new_n39_,
    new_n40_, new_n41_, new_n42_, new_n43_, new_n44_, new_n45_, new_n46_,
    new_n47_, new_n48_, new_n49_, new_n50_, new_n51_, new_n52_, new_n53_,
    new_n54_, new_n55_, new_n56_, new_n57_, new_n58_, new_n59_, new_n60_,
    new_n61_, new_n62_, new_n64_, new_n65_, new_n66_, new_n67_, new_n68_,
    new_n69_, new_n70_, new_n71_, new_n72_, new_n73_, new_n74_, new_n75_,
    new_n76_, new_n77_, new_n78_, new_n79_, new_n80_, new_n81_, new_n82_,
    new_n83_, new_n84_, new_n85_, new_n86_, new_n87_, new_n88_, new_n89_,
    new_n90_, new_n91_, new_n92_, new_n93_, new_n94_, new_n95_, new_n96_,
    new_n97_, new_n99_, new_n100_, new_n101_, new_n102_, new_n103_,
    new_n104_, new_n105_, new_n106_, new_n107_, new_n108_, new_n109_,
    new_n110_, new_n111_, new_n112_, new_n113_, new_n114_, new_n115_,
    new_n116_, new_n117_, new_n118_, new_n119_, new_n120_, new_n121_,
    new_n122_, new_n123_, new_n124_, new_n125_, new_n126_, new_n127_,
    new_n128_, new_n130_, new_n131_, new_n132_, new_n134_, new_n135_,
    new_n136_, new_n137_, new_n138_, new_n139_, new_n140_, new_n141_,
    new_n142_, new_n143_, new_n144_, new_n145_, new_n146_, new_n148_,
    new_n149_, new_n150_, new_n151_, new_n152_, new_n153_, new_n154_,
    new_n155_;
  INVx1_ASAP7_75t_R    g000(.A(p2), .Y(new_n19_));
  NOR2x1_ASAP7_75t_R   g001(.A(p7), .B(new_n19_), .Y(new_n20_));
  NOR2x1_ASAP7_75t_R   g002(.A(p1), .B(p6), .Y(new_n21_));
  INVx1_ASAP7_75t_R    g003(.A(p3), .Y(new_n22_));
  AO32x1_ASAP7_75t_R   g004(.A1(new_n21_), .A2(p4), .A3(p0), .B1(new_n22_), .B2(p6), .Y(new_n23_));
  INVx1_ASAP7_75t_R    g005(.A(p7), .Y(new_n24_));
  NAND2x1_ASAP7_75t_R  g006(.A(p6), .B(new_n24_), .Y(new_n25_));
  NAND2x1_ASAP7_75t_R  g007(.A(p3), .B(new_n19_), .Y(new_n26_));
  NAND3x1_ASAP7_75t_R  g008(.A(new_n22_), .B(p4), .C(p7), .Y(new_n27_));
  OAI21x1_ASAP7_75t_R  g009(.A1(new_n25_), .A2(new_n26_), .B(new_n27_), .Y(new_n28_));
  AOI21x1_ASAP7_75t_R  g010(.A1(new_n20_), .A2(new_n23_), .B(new_n28_), .Y(new_n29_));
  NAND2x1_ASAP7_75t_R  g011(.A(p3), .B(p0), .Y(new_n30_));
  OAI21x1_ASAP7_75t_R  g012(.A1(p3), .A2(new_n24_), .B(new_n30_), .Y(new_n31_));
  NOR2x1_ASAP7_75t_R   g013(.A(p5), .B(p6), .Y(new_n32_));
  AO21x1_ASAP7_75t_R   g014(.A1(p3), .A2(p0), .B(p10), .Y(new_n33_));
  NAND2x1_ASAP7_75t_R  g015(.A(new_n32_), .B(new_n33_), .Y(new_n34_));
  AO211x2_ASAP7_75t_R  g016(.A1(p10), .A2(new_n31_), .B(p4), .C(new_n34_), .Y(new_n35_));
  OR3x1_ASAP7_75t_R    g017(.A(new_n22_), .B(new_n24_), .C(p4), .Y(new_n36_));
  INVx1_ASAP7_75t_R    g018(.A(p8), .Y(new_n37_));
  INVx1_ASAP7_75t_R    g019(.A(p9), .Y(new_n38_));
  NAND2x1_ASAP7_75t_R  g020(.A(new_n37_), .B(new_n38_), .Y(new_n39_));
  AO31x2_ASAP7_75t_R   g021(.A1(new_n29_), .A2(new_n35_), .A3(new_n36_), .B(new_n39_), .Y(new_n40_));
  INVx1_ASAP7_75t_R    g022(.A(p5), .Y(new_n41_));
  OR4x2_ASAP7_75t_R    g023(.A(new_n41_), .B(new_n24_), .C(new_n37_), .D(new_n38_), .Y(new_n42_));
  INVx1_ASAP7_75t_R    g024(.A(p6), .Y(new_n43_));
  NAND2x1_ASAP7_75t_R  g025(.A(p5), .B(new_n43_), .Y(new_n44_));
  OR3x1_ASAP7_75t_R    g026(.A(new_n43_), .B(new_n38_), .C(p5), .Y(new_n45_));
  XNOR2x2_ASAP7_75t_R  g027(.A(p1), .B(p2), .Y(new_n46_));
  OR3x1_ASAP7_75t_R    g028(.A(new_n46_), .B(p7), .C(p8), .Y(new_n47_));
  AO32x1_ASAP7_75t_R   g029(.A1(new_n42_), .A2(new_n44_), .A3(new_n45_), .B1(new_n47_), .B2(new_n38_), .Y(new_n48_));
  AND2x2_ASAP7_75t_R   g030(.A(p3), .B(p7), .Y(new_n49_));
  NOR2x1_ASAP7_75t_R   g031(.A(p3), .B(new_n43_), .Y(new_n50_));
  INVx1_ASAP7_75t_R    g032(.A(p1), .Y(new_n51_));
  NAND2x1_ASAP7_75t_R  g033(.A(p0), .B(new_n51_), .Y(new_n52_));
  NAND2x1_ASAP7_75t_R  g034(.A(p4), .B(new_n41_), .Y(new_n53_));
  AND2x2_ASAP7_75t_R   g035(.A(p3), .B(p2), .Y(new_n54_));
  OR5x1_ASAP7_75t_R    g036(.A(new_n49_), .B(new_n50_), .C(new_n52_), .D(new_n53_), .E(new_n54_), .Y(new_n55_));
  OR3x1_ASAP7_75t_R    g037(.A(new_n41_), .B(new_n37_), .C(p4), .Y(new_n56_));
  NOR2x1_ASAP7_75t_R   g038(.A(p7), .B(p6), .Y(new_n57_));
  INVx1_ASAP7_75t_R    g039(.A(p0), .Y(new_n58_));
  AND3x1_ASAP7_75t_R   g040(.A(new_n57_), .B(p1), .C(new_n58_), .Y(new_n59_));
  INVx1_ASAP7_75t_R    g041(.A(new_n53_), .Y(new_n60_));
  OAI21x1_ASAP7_75t_R  g042(.A1(p8), .A2(new_n59_), .B(new_n60_), .Y(new_n61_));
  AO31x2_ASAP7_75t_R   g043(.A1(new_n55_), .A2(new_n56_), .A3(new_n61_), .B(p9), .Y(new_n62_));
  NAND3x1_ASAP7_75t_R  g044(.A(new_n40_), .B(new_n48_), .C(new_n62_), .Y(o0));
  NAND3x1_ASAP7_75t_R  g045(.A(new_n24_), .B(new_n37_), .C(p6), .Y(new_n64_));
  NAND2x1_ASAP7_75t_R  g046(.A(p8), .B(new_n43_), .Y(new_n65_));
  OAI21x1_ASAP7_75t_R  g047(.A1(new_n54_), .A2(new_n64_), .B(new_n65_), .Y(new_n66_));
  INVx1_ASAP7_75t_R    g048(.A(p4), .Y(new_n67_));
  NOR2x1_ASAP7_75t_R   g049(.A(p3), .B(p6), .Y(new_n68_));
  AO32x1_ASAP7_75t_R   g050(.A1(p3), .A2(new_n24_), .A3(new_n37_), .B1(new_n68_), .B2(new_n41_), .Y(new_n69_));
  NAND2x1_ASAP7_75t_R  g051(.A(p1), .B(p0), .Y(new_n70_));
  NAND2x1_ASAP7_75t_R  g052(.A(p4), .B(p2), .Y(new_n71_));
  AOI21x1_ASAP7_75t_R  g053(.A1(new_n43_), .A2(new_n70_), .B(new_n71_), .Y(new_n72_));
  AOI22x1_ASAP7_75t_R  g054(.A1(new_n66_), .A2(new_n67_), .B1(new_n69_), .B2(new_n72_), .Y(new_n73_));
  OAI22x1_ASAP7_75t_R  g055(.A1(p1), .A2(p6), .B1(p3), .B2(p8), .Y(new_n74_));
  AO22x1_ASAP7_75t_R   g056(.A1(p7), .A2(new_n37_), .B1(new_n58_), .B2(new_n74_), .Y(new_n75_));
  NAND2x1_ASAP7_75t_R  g057(.A(p3), .B(new_n43_), .Y(new_n76_));
  NOR2x1_ASAP7_75t_R   g058(.A(p10), .B(new_n51_), .Y(new_n77_));
  AOI211x1_ASAP7_75t_R g059(.A1(p10), .A2(new_n70_), .B(new_n76_), .C(new_n77_), .Y(new_n78_));
  NOR2x1_ASAP7_75t_R   g060(.A(p4), .B(p5), .Y(new_n79_));
  OAI21x1_ASAP7_75t_R  g061(.A1(new_n75_), .A2(new_n78_), .B(new_n79_), .Y(new_n80_));
  NOR2x1_ASAP7_75t_R   g062(.A(p3), .B(p8), .Y(new_n81_));
  INVx1_ASAP7_75t_R    g063(.A(new_n81_), .Y(new_n82_));
  AOI21x1_ASAP7_75t_R  g064(.A1(new_n65_), .A2(new_n82_), .B(p5), .Y(new_n83_));
  NAND2x1_ASAP7_75t_R  g065(.A(p4), .B(p5), .Y(new_n84_));
  AOI211x1_ASAP7_75t_R g066(.A1(p8), .A2(new_n43_), .B(new_n84_), .C(new_n81_), .Y(new_n85_));
  OAI22x1_ASAP7_75t_R  g067(.A1(new_n83_), .A2(new_n85_), .B1(p7), .B2(p8), .Y(new_n86_));
  NAND3x1_ASAP7_75t_R  g068(.A(new_n73_), .B(new_n80_), .C(new_n86_), .Y(new_n87_));
  AO21x1_ASAP7_75t_R   g069(.A1(p5), .A2(p6), .B(p7), .Y(new_n88_));
  NAND2x1_ASAP7_75t_R  g070(.A(p3), .B(p2), .Y(new_n89_));
  AO21x1_ASAP7_75t_R   g071(.A1(p1), .A2(p2), .B(p3), .Y(new_n90_));
  OAI21x1_ASAP7_75t_R  g072(.A1(new_n51_), .A2(new_n89_), .B(new_n90_), .Y(new_n91_));
  AND3x1_ASAP7_75t_R   g073(.A(new_n43_), .B(new_n37_), .C(p5), .Y(new_n92_));
  NOR2x1_ASAP7_75t_R   g074(.A(p2), .B(new_n67_), .Y(new_n93_));
  AND3x1_ASAP7_75t_R   g075(.A(new_n93_), .B(new_n32_), .C(new_n70_), .Y(new_n94_));
  AOI211x1_ASAP7_75t_R g076(.A1(new_n91_), .A2(new_n92_), .B(p9), .C(new_n94_), .Y(new_n95_));
  OR5x1_ASAP7_75t_R    g077(.A(new_n41_), .B(new_n24_), .C(new_n43_), .D(new_n38_), .E(p8), .Y(new_n96_));
  OAI21x1_ASAP7_75t_R  g078(.A1(new_n88_), .A2(new_n95_), .B(new_n96_), .Y(new_n97_));
  AOI21x1_ASAP7_75t_R  g079(.A1(new_n38_), .A2(new_n87_), .B(new_n97_), .Y(o1));
  AND3x1_ASAP7_75t_R   g080(.A(new_n24_), .B(new_n43_), .C(p1), .Y(new_n99_));
  NAND2x1_ASAP7_75t_R  g081(.A(p10), .B(p0), .Y(new_n100_));
  AOI22x1_ASAP7_75t_R  g082(.A1(new_n54_), .A2(new_n100_), .B1(new_n22_), .B2(new_n41_), .Y(new_n101_));
  NAND2x1_ASAP7_75t_R  g083(.A(p10), .B(p3), .Y(new_n102_));
  OA21x2_ASAP7_75t_R   g084(.A1(p5), .A2(new_n102_), .B(new_n71_), .Y(new_n103_));
  NAND2x1_ASAP7_75t_R  g085(.A(p0), .B(new_n89_), .Y(new_n104_));
  OAI22x1_ASAP7_75t_R  g086(.A1(new_n101_), .A2(p4), .B1(new_n103_), .B2(new_n104_), .Y(new_n105_));
  OAI22x1_ASAP7_75t_R  g087(.A1(new_n51_), .A2(new_n41_), .B1(new_n67_), .B2(p0), .Y(new_n106_));
  NAND2x1_ASAP7_75t_R  g088(.A(new_n54_), .B(new_n106_), .Y(new_n107_));
  AND2x2_ASAP7_75t_R   g089(.A(p4), .B(p5), .Y(new_n108_));
  AO21x1_ASAP7_75t_R   g090(.A1(new_n54_), .A2(new_n108_), .B(p7), .Y(new_n109_));
  AOI21x1_ASAP7_75t_R  g091(.A1(new_n84_), .A2(new_n107_), .B(new_n109_), .Y(new_n110_));
  NOR3x1_ASAP7_75t_R   g092(.A(new_n19_), .B(p1), .C(p5), .Y(new_n111_));
  AND3x1_ASAP7_75t_R   g093(.A(new_n24_), .B(new_n43_), .C(p3), .Y(new_n112_));
  OAI21x1_ASAP7_75t_R  g094(.A1(new_n93_), .A2(new_n111_), .B(new_n112_), .Y(new_n113_));
  OR5x1_ASAP7_75t_R    g095(.A(new_n67_), .B(new_n22_), .C(new_n41_), .D(p1), .E(p6), .Y(new_n114_));
  NOR2x1_ASAP7_75t_R   g096(.A(p5), .B(new_n43_), .Y(new_n115_));
  AND3x1_ASAP7_75t_R   g097(.A(p4), .B(p3), .C(p2), .Y(new_n116_));
  AND2x2_ASAP7_75t_R   g098(.A(p5), .B(p6), .Y(new_n117_));
  NAND2x1_ASAP7_75t_R  g099(.A(p4), .B(p3), .Y(new_n118_));
  AOI22x1_ASAP7_75t_R  g100(.A1(new_n115_), .A2(new_n116_), .B1(new_n117_), .B2(new_n118_), .Y(new_n119_));
  NAND3x1_ASAP7_75t_R  g101(.A(new_n113_), .B(new_n114_), .C(new_n119_), .Y(new_n120_));
  AOI211x1_ASAP7_75t_R g102(.A1(new_n99_), .A2(new_n105_), .B(new_n110_), .C(new_n120_), .Y(new_n121_));
  NAND2x1_ASAP7_75t_R  g103(.A(p4), .B(p6), .Y(new_n122_));
  OAI22x1_ASAP7_75t_R  g104(.A1(new_n76_), .A2(new_n84_), .B1(p5), .B2(new_n43_), .Y(new_n123_));
  AO22x1_ASAP7_75t_R   g105(.A1(p8), .A2(new_n122_), .B1(new_n38_), .B2(new_n123_), .Y(new_n124_));
  AND3x1_ASAP7_75t_R   g106(.A(p4), .B(p5), .C(p6), .Y(new_n125_));
  AO21x1_ASAP7_75t_R   g107(.A1(new_n24_), .A2(new_n125_), .B(p9), .Y(new_n126_));
  AO32x1_ASAP7_75t_R   g108(.A1(p7), .A2(p9), .A3(new_n117_), .B1(new_n126_), .B2(p8), .Y(new_n127_));
  AOI21x1_ASAP7_75t_R  g109(.A1(p7), .A2(new_n124_), .B(new_n127_), .Y(new_n128_));
  OAI21x1_ASAP7_75t_R  g110(.A1(new_n39_), .A2(new_n121_), .B(new_n128_), .Y(o2));
  AND3x1_ASAP7_75t_R   g111(.A(new_n79_), .B(new_n57_), .C(new_n22_), .Y(new_n130_));
  AND3x1_ASAP7_75t_R   g112(.A(new_n125_), .B(new_n49_), .C(new_n51_), .Y(new_n131_));
  NOR2x1_ASAP7_75t_R   g113(.A(new_n130_), .B(new_n131_), .Y(new_n132_));
  OR3x1_ASAP7_75t_R    g114(.A(new_n132_), .B(p2), .C(new_n39_), .Y(o3));
  AND5x1_ASAP7_75t_R   g115(.A(p4), .B(new_n37_), .C(p3), .D(p5), .E(p6), .Y(new_n134_));
  AND2x2_ASAP7_75t_R   g116(.A(p7), .B(p2), .Y(new_n135_));
  AO21x1_ASAP7_75t_R   g117(.A1(p1), .A2(new_n19_), .B(new_n135_), .Y(new_n136_));
  AOI21x1_ASAP7_75t_R  g118(.A1(p7), .A2(new_n125_), .B(new_n37_), .Y(new_n137_));
  AO21x1_ASAP7_75t_R   g119(.A1(new_n134_), .A2(new_n136_), .B(new_n137_), .Y(new_n138_));
  INVx1_ASAP7_75t_R    g120(.A(new_n100_), .Y(new_n139_));
  AO32x1_ASAP7_75t_R   g121(.A1(new_n108_), .A2(p3), .A3(new_n43_), .B1(new_n139_), .B2(new_n79_), .Y(new_n140_));
  OR3x1_ASAP7_75t_R    g122(.A(new_n51_), .B(new_n58_), .C(p6), .Y(new_n141_));
  AO21x1_ASAP7_75t_R   g123(.A1(new_n84_), .A2(new_n141_), .B(new_n89_), .Y(new_n142_));
  NOR2x1_ASAP7_75t_R   g124(.A(p4), .B(p6), .Y(new_n143_));
  AOI22x1_ASAP7_75t_R  g125(.A1(new_n143_), .A2(p3), .B1(p5), .B2(new_n43_), .Y(new_n144_));
  AO32x1_ASAP7_75t_R   g126(.A1(p1), .A2(new_n140_), .A3(p2), .B1(new_n142_), .B2(new_n144_), .Y(new_n145_));
  OA21x2_ASAP7_75t_R   g127(.A1(new_n24_), .A2(new_n138_), .B(new_n38_), .Y(new_n146_));
  OAI21x1_ASAP7_75t_R  g128(.A1(new_n138_), .A2(new_n145_), .B(new_n146_), .Y(o4));
  AND3x1_ASAP7_75t_R   g129(.A(new_n139_), .B(new_n20_), .C(new_n143_), .Y(new_n148_));
  AOI21x1_ASAP7_75t_R  g130(.A1(p7), .A2(new_n125_), .B(new_n148_), .Y(new_n149_));
  AO21x1_ASAP7_75t_R   g131(.A1(new_n135_), .A2(new_n125_), .B(p1), .Y(new_n150_));
  NAND2x1_ASAP7_75t_R  g132(.A(p3), .B(new_n150_), .Y(new_n151_));
  AND3x1_ASAP7_75t_R   g133(.A(new_n54_), .B(new_n108_), .C(p1), .Y(new_n152_));
  INVx1_ASAP7_75t_R    g134(.A(new_n57_), .Y(new_n153_));
  OR3x1_ASAP7_75t_R    g135(.A(new_n152_), .B(new_n79_), .C(new_n153_), .Y(new_n154_));
  AND3x1_ASAP7_75t_R   g136(.A(new_n154_), .B(new_n37_), .C(new_n38_), .Y(new_n155_));
  OAI21x1_ASAP7_75t_R  g137(.A1(new_n149_), .A2(new_n151_), .B(new_n155_), .Y(o5));
  OR3x1_ASAP7_75t_R    g138(.A(new_n152_), .B(new_n39_), .C(new_n153_), .Y(o6));
endmodule


