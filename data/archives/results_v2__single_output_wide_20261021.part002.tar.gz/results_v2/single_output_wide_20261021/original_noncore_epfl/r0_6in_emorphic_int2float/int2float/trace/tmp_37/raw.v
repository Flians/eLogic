// Benchmark "/tmp/" written by ABC on Wed Oct 21 14:43:57 2026

module \/tmp/  ( 
    p8, p0, p6, p4, p7, p9, p2, p1, p3, p5, p10,
    o0, o1, o2, o3, o4, o5, o6  );
  input  p8, p0, p6, p4, p7, p9, p2, p1, p3, p5, p10;
  output o0, o1, o2, o3, o4, o5, o6;
  wire new_n19_, new_n20_, new_n21_, new_n22_, new_n23_, new_n24_, new_n25_,
    new_n26_, new_n27_, new_n28_, new_n29_, new_n30_, new_n31_, new_n32_,
    new_n33_, new_n34_, new_n35_, new_n36_, new_n37_, new_n38_, new_n39_,
    new_n40_, new_n41_, new_n42_, new_n43_, new_n44_, new_n45_, new_n46_,
    new_n47_, new_n48_, new_n49_, new_n50_, new_n51_, new_n52_, new_n53_,
    new_n54_, new_n55_, new_n56_, new_n57_, new_n58_, new_n59_, new_n60_,
    new_n61_, new_n62_, new_n63_, new_n64_, new_n66_, new_n67_, new_n68_,
    new_n69_, new_n70_, new_n71_, new_n72_, new_n73_, new_n74_, new_n75_,
    new_n76_, new_n77_, new_n78_, new_n79_, new_n80_, new_n81_, new_n82_,
    new_n83_, new_n84_, new_n85_, new_n86_, new_n87_, new_n88_, new_n89_,
    new_n90_, new_n91_, new_n92_, new_n93_, new_n94_, new_n95_, new_n96_,
    new_n97_, new_n98_, new_n100_, new_n101_, new_n102_, new_n103_,
    new_n104_, new_n105_, new_n106_, new_n107_, new_n108_, new_n109_,
    new_n110_, new_n111_, new_n112_, new_n113_, new_n114_, new_n115_,
    new_n116_, new_n117_, new_n118_, new_n119_, new_n120_, new_n121_,
    new_n122_, new_n123_, new_n124_, new_n125_, new_n126_, new_n127_,
    new_n128_, new_n129_, new_n130_, new_n131_, new_n133_, new_n134_,
    new_n135_, new_n137_, new_n138_, new_n139_, new_n140_, new_n141_,
    new_n142_, new_n143_, new_n144_, new_n145_, new_n146_, new_n147_,
    new_n149_, new_n150_, new_n151_, new_n152_, new_n153_, new_n154_;
  INVx1_ASAP7_75t_R    g000(.A(p4), .Y(new_n19_));
  INVx1_ASAP7_75t_R    g001(.A(p10), .Y(new_n20_));
  NAND2x1_ASAP7_75t_R  g002(.A(p0), .B(p3), .Y(new_n21_));
  AOI211x1_ASAP7_75t_R g003(.A1(new_n20_), .A2(new_n21_), .B(p6), .C(p5), .Y(new_n22_));
  INVx1_ASAP7_75t_R    g004(.A(p3), .Y(new_n23_));
  NAND2x1_ASAP7_75t_R  g005(.A(p7), .B(new_n23_), .Y(new_n24_));
  AO21x1_ASAP7_75t_R   g006(.A1(new_n21_), .A2(new_n24_), .B(new_n20_), .Y(new_n25_));
  AND2x2_ASAP7_75t_R   g007(.A(p7), .B(p3), .Y(new_n26_));
  AO21x1_ASAP7_75t_R   g008(.A1(new_n22_), .A2(new_n25_), .B(new_n26_), .Y(new_n27_));
  INVx1_ASAP7_75t_R    g009(.A(p6), .Y(new_n28_));
  AND3x1_ASAP7_75t_R   g010(.A(new_n28_), .B(p4), .C(p2), .Y(new_n29_));
  INVx1_ASAP7_75t_R    g011(.A(p0), .Y(new_n30_));
  NOR2x1_ASAP7_75t_R   g012(.A(p1), .B(new_n30_), .Y(new_n31_));
  INVx1_ASAP7_75t_R    g013(.A(p2), .Y(new_n32_));
  NAND2x1_ASAP7_75t_R  g014(.A(new_n32_), .B(new_n23_), .Y(new_n33_));
  AOI21x1_ASAP7_75t_R  g015(.A1(p2), .A2(p3), .B(new_n28_), .Y(new_n34_));
  AOI22x1_ASAP7_75t_R  g016(.A1(new_n29_), .A2(new_n31_), .B1(new_n33_), .B2(new_n34_), .Y(new_n35_));
  OAI22x1_ASAP7_75t_R  g017(.A1(new_n35_), .A2(p7), .B1(new_n19_), .B2(new_n24_), .Y(new_n36_));
  AOI21x1_ASAP7_75t_R  g018(.A1(new_n19_), .A2(new_n27_), .B(new_n36_), .Y(new_n37_));
  NOR2x1_ASAP7_75t_R   g019(.A(p8), .B(p9), .Y(new_n38_));
  INVx1_ASAP7_75t_R    g020(.A(new_n38_), .Y(new_n39_));
  NOR2x1_ASAP7_75t_R   g021(.A(p5), .B(new_n19_), .Y(new_n40_));
  INVx1_ASAP7_75t_R    g022(.A(new_n40_), .Y(new_n41_));
  NOR2x1_ASAP7_75t_R   g023(.A(p3), .B(new_n28_), .Y(new_n42_));
  AND2x2_ASAP7_75t_R   g024(.A(p2), .B(p3), .Y(new_n43_));
  OR5x1_ASAP7_75t_R    g025(.A(new_n30_), .B(new_n42_), .C(p1), .D(new_n26_), .E(new_n43_), .Y(new_n44_));
  NOR2x1_ASAP7_75t_R   g026(.A(p6), .B(p7), .Y(new_n45_));
  AO31x2_ASAP7_75t_R   g027(.A1(new_n45_), .A2(new_n30_), .A3(p1), .B(p8), .Y(new_n46_));
  AND2x2_ASAP7_75t_R   g028(.A(p8), .B(p5), .Y(new_n47_));
  AOI22x1_ASAP7_75t_R  g029(.A1(new_n46_), .A2(new_n40_), .B1(new_n19_), .B2(new_n47_), .Y(new_n48_));
  OAI21x1_ASAP7_75t_R  g030(.A1(new_n41_), .A2(new_n44_), .B(new_n48_), .Y(new_n49_));
  INVx1_ASAP7_75t_R    g031(.A(p9), .Y(new_n50_));
  INVx1_ASAP7_75t_R    g032(.A(p1), .Y(new_n51_));
  NAND2x1_ASAP7_75t_R  g033(.A(new_n32_), .B(new_n51_), .Y(new_n52_));
  NAND2x1_ASAP7_75t_R  g034(.A(p2), .B(p1), .Y(new_n53_));
  INVx1_ASAP7_75t_R    g035(.A(p8), .Y(new_n54_));
  INVx1_ASAP7_75t_R    g036(.A(p7), .Y(new_n55_));
  AND3x1_ASAP7_75t_R   g037(.A(new_n53_), .B(new_n54_), .C(new_n55_), .Y(new_n56_));
  AO21x1_ASAP7_75t_R   g038(.A1(new_n52_), .A2(new_n56_), .B(p9), .Y(new_n57_));
  NAND2x1_ASAP7_75t_R  g039(.A(p5), .B(new_n28_), .Y(new_n58_));
  INVx1_ASAP7_75t_R    g040(.A(p5), .Y(new_n59_));
  NAND2x1_ASAP7_75t_R  g041(.A(p6), .B(new_n59_), .Y(new_n60_));
  NAND2x1_ASAP7_75t_R  g042(.A(p7), .B(new_n47_), .Y(new_n61_));
  AO21x1_ASAP7_75t_R   g043(.A1(new_n60_), .A2(new_n61_), .B(new_n50_), .Y(new_n62_));
  NAND2x1_ASAP7_75t_R  g044(.A(new_n58_), .B(new_n62_), .Y(new_n63_));
  AOI22x1_ASAP7_75t_R  g045(.A1(new_n49_), .A2(new_n50_), .B1(new_n57_), .B2(new_n63_), .Y(new_n64_));
  OAI21x1_ASAP7_75t_R  g046(.A1(new_n37_), .A2(new_n39_), .B(new_n64_), .Y(o0));
  NOR2x1_ASAP7_75t_R   g047(.A(p8), .B(p3), .Y(new_n66_));
  NOR2x1_ASAP7_75t_R   g048(.A(p6), .B(new_n54_), .Y(new_n67_));
  OAI21x1_ASAP7_75t_R  g049(.A1(new_n66_), .A2(new_n67_), .B(new_n59_), .Y(new_n68_));
  NAND2x1_ASAP7_75t_R  g050(.A(p4), .B(p5), .Y(new_n69_));
  OR3x1_ASAP7_75t_R    g051(.A(new_n67_), .B(new_n69_), .C(new_n66_), .Y(new_n70_));
  NOR2x1_ASAP7_75t_R   g052(.A(p8), .B(p7), .Y(new_n71_));
  AO21x1_ASAP7_75t_R   g053(.A1(new_n68_), .A2(new_n70_), .B(new_n71_), .Y(new_n72_));
  NAND2x1_ASAP7_75t_R  g054(.A(p0), .B(p10), .Y(new_n73_));
  NAND2x1_ASAP7_75t_R  g055(.A(p3), .B(new_n28_), .Y(new_n74_));
  NOR2x1_ASAP7_75t_R   g056(.A(p1), .B(new_n20_), .Y(new_n75_));
  AOI211x1_ASAP7_75t_R g057(.A1(p1), .A2(new_n73_), .B(new_n74_), .C(new_n75_), .Y(new_n76_));
  NOR2x1_ASAP7_75t_R   g058(.A(p6), .B(p1), .Y(new_n77_));
  NOR2x1_ASAP7_75t_R   g059(.A(new_n77_), .B(new_n66_), .Y(new_n78_));
  OAI22x1_ASAP7_75t_R  g060(.A1(new_n78_), .A2(p0), .B1(p8), .B2(new_n55_), .Y(new_n79_));
  NOR2x1_ASAP7_75t_R   g061(.A(p4), .B(p5), .Y(new_n80_));
  OAI21x1_ASAP7_75t_R  g062(.A1(new_n76_), .A2(new_n79_), .B(new_n80_), .Y(new_n81_));
  AO21x1_ASAP7_75t_R   g063(.A1(new_n71_), .A2(new_n34_), .B(new_n67_), .Y(new_n82_));
  NAND2x1_ASAP7_75t_R  g064(.A(p0), .B(p1), .Y(new_n83_));
  AOI211x1_ASAP7_75t_R g065(.A1(new_n28_), .A2(new_n83_), .B(new_n19_), .C(new_n32_), .Y(new_n84_));
  NOR2x1_ASAP7_75t_R   g066(.A(p3), .B(p5), .Y(new_n85_));
  AO32x1_ASAP7_75t_R   g067(.A1(new_n54_), .A2(new_n55_), .A3(p3), .B1(new_n85_), .B2(new_n28_), .Y(new_n86_));
  AOI22x1_ASAP7_75t_R  g068(.A1(new_n82_), .A2(new_n19_), .B1(new_n84_), .B2(new_n86_), .Y(new_n87_));
  NAND3x1_ASAP7_75t_R  g069(.A(new_n72_), .B(new_n81_), .C(new_n87_), .Y(new_n88_));
  NOR2x1_ASAP7_75t_R   g070(.A(p8), .B(new_n23_), .Y(new_n89_));
  NOR2x1_ASAP7_75t_R   g071(.A(new_n53_), .B(new_n58_), .Y(new_n90_));
  AND5x1_ASAP7_75t_R   g072(.A(new_n54_), .B(new_n53_), .C(new_n28_), .D(new_n23_), .E(p5), .Y(new_n91_));
  NOR2x1_ASAP7_75t_R   g073(.A(p2), .B(new_n19_), .Y(new_n92_));
  NOR2x1_ASAP7_75t_R   g074(.A(p6), .B(p5), .Y(new_n93_));
  AO31x2_ASAP7_75t_R   g075(.A1(new_n92_), .A2(new_n93_), .A3(new_n83_), .B(p9), .Y(new_n94_));
  AOI211x1_ASAP7_75t_R g076(.A1(new_n89_), .A2(new_n90_), .B(new_n91_), .C(new_n94_), .Y(new_n95_));
  AO21x1_ASAP7_75t_R   g077(.A1(p6), .A2(p5), .B(p7), .Y(new_n96_));
  OR4x2_ASAP7_75t_R    g078(.A(new_n28_), .B(new_n55_), .C(new_n50_), .D(new_n59_), .Y(new_n97_));
  OAI22x1_ASAP7_75t_R  g079(.A1(new_n95_), .A2(new_n96_), .B1(p8), .B2(new_n97_), .Y(new_n98_));
  AOI21x1_ASAP7_75t_R  g080(.A1(new_n50_), .A2(new_n88_), .B(new_n98_), .Y(o1));
  NAND2x1_ASAP7_75t_R  g081(.A(new_n51_), .B(new_n59_), .Y(new_n100_));
  NAND2x1_ASAP7_75t_R  g082(.A(p2), .B(p3), .Y(new_n101_));
  NAND2x1_ASAP7_75t_R  g083(.A(p3), .B(new_n32_), .Y(new_n102_));
  OAI22x1_ASAP7_75t_R  g084(.A1(new_n100_), .A2(new_n101_), .B1(new_n102_), .B2(new_n19_), .Y(new_n103_));
  OAI21x1_ASAP7_75t_R  g085(.A1(p1), .A2(new_n103_), .B(new_n45_), .Y(new_n104_));
  AO21x1_ASAP7_75t_R   g086(.A1(new_n73_), .A2(new_n43_), .B(new_n85_), .Y(new_n105_));
  NAND2x1_ASAP7_75t_R  g087(.A(p10), .B(new_n59_), .Y(new_n106_));
  NAND3x1_ASAP7_75t_R  g088(.A(new_n23_), .B(p4), .C(p2), .Y(new_n107_));
  OAI21x1_ASAP7_75t_R  g089(.A1(new_n102_), .A2(new_n106_), .B(new_n107_), .Y(new_n108_));
  AOI221x1_ASAP7_75t_R g090(.A1(new_n19_), .A2(new_n105_), .B1(new_n108_), .B2(p0), .C(new_n103_), .Y(new_n109_));
  INVx1_ASAP7_75t_R    g091(.A(new_n60_), .Y(new_n110_));
  AND3x1_ASAP7_75t_R   g092(.A(p4), .B(p2), .C(p3), .Y(new_n111_));
  NAND3x1_ASAP7_75t_R  g093(.A(new_n30_), .B(new_n59_), .C(p4), .Y(new_n112_));
  NAND3x1_ASAP7_75t_R  g094(.A(new_n19_), .B(p1), .C(p5), .Y(new_n113_));
  NAND3x1_ASAP7_75t_R  g095(.A(new_n112_), .B(new_n113_), .C(new_n43_), .Y(new_n114_));
  AND2x2_ASAP7_75t_R   g096(.A(p4), .B(p5), .Y(new_n115_));
  OA21x2_ASAP7_75t_R   g097(.A1(new_n43_), .A2(new_n115_), .B(new_n55_), .Y(new_n116_));
  NAND2x1_ASAP7_75t_R  g098(.A(p4), .B(p3), .Y(new_n117_));
  NAND2x1_ASAP7_75t_R  g099(.A(p5), .B(new_n77_), .Y(new_n118_));
  NAND3x1_ASAP7_75t_R  g100(.A(new_n117_), .B(p6), .C(p5), .Y(new_n119_));
  OAI21x1_ASAP7_75t_R  g101(.A1(new_n117_), .A2(new_n118_), .B(new_n119_), .Y(new_n120_));
  AOI221x1_ASAP7_75t_R g102(.A1(new_n110_), .A2(new_n111_), .B1(new_n114_), .B2(new_n116_), .C(new_n120_), .Y(new_n121_));
  OAI21x1_ASAP7_75t_R  g103(.A1(new_n104_), .A2(new_n109_), .B(new_n121_), .Y(new_n122_));
  AND2x2_ASAP7_75t_R   g104(.A(p6), .B(p4), .Y(new_n123_));
  NOR2x1_ASAP7_75t_R   g105(.A(p9), .B(new_n55_), .Y(new_n124_));
  AND3x1_ASAP7_75t_R   g106(.A(p6), .B(p4), .C(p5), .Y(new_n125_));
  INVx1_ASAP7_75t_R    g107(.A(new_n125_), .Y(new_n126_));
  NOR2x1_ASAP7_75t_R   g108(.A(p7), .B(p9), .Y(new_n127_));
  AO221x2_ASAP7_75t_R  g109(.A1(new_n123_), .A2(new_n124_), .B1(new_n126_), .B2(new_n127_), .C(new_n54_), .Y(new_n128_));
  NOR2x1_ASAP7_75t_R   g110(.A(new_n69_), .B(new_n74_), .Y(new_n129_));
  OAI21x1_ASAP7_75t_R  g111(.A1(new_n110_), .A2(new_n129_), .B(new_n124_), .Y(new_n130_));
  NAND3x1_ASAP7_75t_R  g112(.A(new_n128_), .B(new_n97_), .C(new_n130_), .Y(new_n131_));
  AO21x1_ASAP7_75t_R   g113(.A1(new_n38_), .A2(new_n122_), .B(new_n131_), .Y(o2));
  AND3x1_ASAP7_75t_R   g114(.A(new_n45_), .B(new_n80_), .C(new_n23_), .Y(new_n133_));
  AND3x1_ASAP7_75t_R   g115(.A(new_n125_), .B(new_n26_), .C(new_n51_), .Y(new_n134_));
  NOR2x1_ASAP7_75t_R   g116(.A(new_n133_), .B(new_n134_), .Y(new_n135_));
  OR3x1_ASAP7_75t_R    g117(.A(new_n135_), .B(p2), .C(new_n39_), .Y(o3));
  OA211x2_ASAP7_75t_R  g118(.A1(p7), .A2(new_n32_), .B(new_n52_), .C(new_n89_), .Y(new_n137_));
  OA21x2_ASAP7_75t_R   g119(.A1(new_n55_), .A2(new_n126_), .B(p8), .Y(new_n138_));
  AND3x1_ASAP7_75t_R   g120(.A(new_n80_), .B(p0), .C(p10), .Y(new_n139_));
  AND3x1_ASAP7_75t_R   g121(.A(new_n55_), .B(p2), .C(p1), .Y(new_n140_));
  OA21x2_ASAP7_75t_R   g122(.A1(new_n139_), .A2(new_n129_), .B(new_n140_), .Y(new_n141_));
  AOI211x1_ASAP7_75t_R g123(.A1(new_n125_), .A2(new_n137_), .B(new_n138_), .C(new_n141_), .Y(new_n142_));
  OR3x1_ASAP7_75t_R    g124(.A(new_n23_), .B(p6), .C(p4), .Y(new_n143_));
  AND3x1_ASAP7_75t_R   g125(.A(new_n143_), .B(new_n58_), .C(new_n127_), .Y(new_n144_));
  OR3x1_ASAP7_75t_R    g126(.A(new_n30_), .B(new_n51_), .C(p6), .Y(new_n145_));
  AO21x1_ASAP7_75t_R   g127(.A1(new_n69_), .A2(new_n145_), .B(new_n101_), .Y(new_n146_));
  NAND2x1_ASAP7_75t_R  g128(.A(new_n144_), .B(new_n146_), .Y(new_n147_));
  OA21x2_ASAP7_75t_R   g129(.A1(p9), .A2(new_n142_), .B(new_n147_), .Y(o4));
  AND3x1_ASAP7_75t_R   g130(.A(new_n111_), .B(p1), .C(p5), .Y(new_n149_));
  INVx1_ASAP7_75t_R    g131(.A(new_n45_), .Y(new_n150_));
  OR3x1_ASAP7_75t_R    g132(.A(new_n149_), .B(new_n150_), .C(new_n80_), .Y(new_n151_));
  AND3x1_ASAP7_75t_R   g133(.A(new_n52_), .B(new_n26_), .C(new_n125_), .Y(new_n152_));
  NOR2x1_ASAP7_75t_R   g134(.A(new_n39_), .B(new_n152_), .Y(new_n153_));
  OR5x1_ASAP7_75t_R    g135(.A(p7), .B(new_n143_), .C(new_n32_), .D(new_n51_), .E(new_n73_), .Y(new_n154_));
  NAND3x1_ASAP7_75t_R  g136(.A(new_n151_), .B(new_n153_), .C(new_n154_), .Y(o5));
  OR3x1_ASAP7_75t_R    g137(.A(new_n149_), .B(new_n39_), .C(new_n150_), .Y(o6));
endmodule


