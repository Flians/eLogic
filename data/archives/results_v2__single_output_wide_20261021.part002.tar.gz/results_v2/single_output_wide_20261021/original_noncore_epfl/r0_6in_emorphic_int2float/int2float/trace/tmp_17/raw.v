// Benchmark "/tmp/" written by ABC on Wed Oct 21 14:43:54 2026

module \/tmp/  ( 
    p2, p4, p9, p1, p6, p5, p10, p8, p7, p0, p3,
    o0, o1, o2, o3, o4, o5, o6  );
  input  p2, p4, p9, p1, p6, p5, p10, p8, p7, p0, p3;
  output o0, o1, o2, o3, o4, o5, o6;
  wire new_n19_, new_n20_, new_n21_, new_n22_, new_n23_, new_n24_, new_n25_,
    new_n26_, new_n27_, new_n28_, new_n29_, new_n30_, new_n31_, new_n32_,
    new_n33_, new_n34_, new_n35_, new_n36_, new_n37_, new_n38_, new_n39_,
    new_n40_, new_n41_, new_n42_, new_n43_, new_n44_, new_n45_, new_n46_,
    new_n47_, new_n48_, new_n49_, new_n50_, new_n51_, new_n52_, new_n53_,
    new_n54_, new_n55_, new_n56_, new_n57_, new_n58_, new_n59_, new_n60_,
    new_n61_, new_n62_, new_n63_, new_n64_, new_n66_, new_n67_, new_n68_,
    new_n69_, new_n70_, new_n71_, new_n72_, new_n73_, new_n74_, new_n75_,
    new_n76_, new_n77_, new_n78_, new_n79_, new_n80_, new_n81_, new_n82_,
    new_n83_, new_n84_, new_n85_, new_n86_, new_n87_, new_n88_, new_n89_,
    new_n90_, new_n91_, new_n92_, new_n93_, new_n94_, new_n95_, new_n96_,
    new_n97_, new_n98_, new_n99_, new_n100_, new_n101_, new_n102_,
    new_n103_, new_n105_, new_n106_, new_n107_, new_n108_, new_n109_,
    new_n110_, new_n111_, new_n112_, new_n113_, new_n114_, new_n115_,
    new_n116_, new_n117_, new_n118_, new_n119_, new_n120_, new_n121_,
    new_n122_, new_n123_, new_n124_, new_n125_, new_n126_, new_n127_,
    new_n128_, new_n129_, new_n130_, new_n131_, new_n132_, new_n133_,
    new_n134_, new_n136_, new_n137_, new_n138_, new_n139_, new_n140_,
    new_n142_, new_n143_, new_n144_, new_n145_, new_n146_, new_n147_,
    new_n148_, new_n149_, new_n150_, new_n151_, new_n152_, new_n153_,
    new_n155_, new_n156_, new_n157_, new_n158_;
  INVx1_ASAP7_75t_R    g000(.A(p4), .Y(new_n19_));
  INVx1_ASAP7_75t_R    g001(.A(p10), .Y(new_n20_));
  NAND2x1_ASAP7_75t_R  g002(.A(p0), .B(p3), .Y(new_n21_));
  INVx1_ASAP7_75t_R    g003(.A(p6), .Y(new_n22_));
  INVx1_ASAP7_75t_R    g004(.A(p5), .Y(new_n23_));
  NAND2x1_ASAP7_75t_R  g005(.A(new_n22_), .B(new_n23_), .Y(new_n24_));
  AO21x1_ASAP7_75t_R   g006(.A1(new_n20_), .A2(new_n21_), .B(new_n24_), .Y(new_n25_));
  INVx1_ASAP7_75t_R    g007(.A(p3), .Y(new_n26_));
  NAND2x1_ASAP7_75t_R  g008(.A(p7), .B(new_n26_), .Y(new_n27_));
  AOI21x1_ASAP7_75t_R  g009(.A1(new_n21_), .A2(new_n27_), .B(new_n20_), .Y(new_n28_));
  INVx1_ASAP7_75t_R    g010(.A(p7), .Y(new_n29_));
  OAI22x1_ASAP7_75t_R  g011(.A1(new_n25_), .A2(new_n28_), .B1(new_n29_), .B2(new_n26_), .Y(new_n30_));
  AOI21x1_ASAP7_75t_R  g012(.A1(p2), .A2(p3), .B(new_n22_), .Y(new_n31_));
  INVx1_ASAP7_75t_R    g013(.A(p2), .Y(new_n32_));
  NAND2x1_ASAP7_75t_R  g014(.A(new_n32_), .B(new_n26_), .Y(new_n33_));
  NOR2x1_ASAP7_75t_R   g015(.A(p1), .B(p6), .Y(new_n34_));
  AND3x1_ASAP7_75t_R   g016(.A(p2), .B(p4), .C(p0), .Y(new_n35_));
  AOI22x1_ASAP7_75t_R  g017(.A1(new_n31_), .A2(new_n33_), .B1(new_n34_), .B2(new_n35_), .Y(new_n36_));
  OAI22x1_ASAP7_75t_R  g018(.A1(new_n36_), .A2(p7), .B1(new_n19_), .B2(new_n27_), .Y(new_n37_));
  AOI21x1_ASAP7_75t_R  g019(.A1(new_n19_), .A2(new_n30_), .B(new_n37_), .Y(new_n38_));
  NOR2x1_ASAP7_75t_R   g020(.A(p9), .B(p8), .Y(new_n39_));
  INVx1_ASAP7_75t_R    g021(.A(new_n39_), .Y(new_n40_));
  INVx1_ASAP7_75t_R    g022(.A(p9), .Y(new_n41_));
  AO21x1_ASAP7_75t_R   g023(.A1(new_n32_), .A2(new_n29_), .B(new_n26_), .Y(new_n42_));
  INVx1_ASAP7_75t_R    g024(.A(p0), .Y(new_n43_));
  AOI211x1_ASAP7_75t_R g025(.A1(p6), .A2(new_n26_), .B(p1), .C(new_n43_), .Y(new_n44_));
  NAND2x1_ASAP7_75t_R  g026(.A(new_n42_), .B(new_n44_), .Y(new_n45_));
  NOR2x1_ASAP7_75t_R   g027(.A(p5), .B(new_n19_), .Y(new_n46_));
  INVx1_ASAP7_75t_R    g028(.A(new_n46_), .Y(new_n47_));
  NOR2x1_ASAP7_75t_R   g029(.A(p6), .B(p7), .Y(new_n48_));
  AO31x2_ASAP7_75t_R   g030(.A1(new_n48_), .A2(p1), .A3(new_n43_), .B(p8), .Y(new_n49_));
  AND2x2_ASAP7_75t_R   g031(.A(p5), .B(p8), .Y(new_n50_));
  AOI22x1_ASAP7_75t_R  g032(.A1(new_n49_), .A2(new_n46_), .B1(new_n19_), .B2(new_n50_), .Y(new_n51_));
  OAI21x1_ASAP7_75t_R  g033(.A1(new_n45_), .A2(new_n47_), .B(new_n51_), .Y(new_n52_));
  NAND2x1_ASAP7_75t_R  g034(.A(p5), .B(new_n22_), .Y(new_n53_));
  NOR2x1_ASAP7_75t_R   g035(.A(p2), .B(p1), .Y(new_n54_));
  INVx1_ASAP7_75t_R    g036(.A(new_n54_), .Y(new_n55_));
  INVx1_ASAP7_75t_R    g037(.A(p1), .Y(new_n56_));
  NOR2x1_ASAP7_75t_R   g038(.A(p8), .B(p7), .Y(new_n57_));
  OA21x2_ASAP7_75t_R   g039(.A1(new_n32_), .A2(new_n56_), .B(new_n57_), .Y(new_n58_));
  AOI21x1_ASAP7_75t_R  g040(.A1(new_n55_), .A2(new_n58_), .B(p9), .Y(new_n59_));
  NAND2x1_ASAP7_75t_R  g041(.A(p6), .B(new_n23_), .Y(new_n60_));
  NAND2x1_ASAP7_75t_R  g042(.A(p7), .B(new_n50_), .Y(new_n61_));
  AO21x1_ASAP7_75t_R   g043(.A1(new_n60_), .A2(new_n61_), .B(new_n41_), .Y(new_n62_));
  OAI21x1_ASAP7_75t_R  g044(.A1(new_n53_), .A2(new_n59_), .B(new_n62_), .Y(new_n63_));
  AOI21x1_ASAP7_75t_R  g045(.A1(new_n41_), .A2(new_n52_), .B(new_n63_), .Y(new_n64_));
  OAI21x1_ASAP7_75t_R  g046(.A1(new_n38_), .A2(new_n40_), .B(new_n64_), .Y(o0));
  INVx1_ASAP7_75t_R    g047(.A(p8), .Y(new_n66_));
  NOR2x1_ASAP7_75t_R   g048(.A(p6), .B(new_n66_), .Y(new_n67_));
  AO21x1_ASAP7_75t_R   g049(.A1(new_n57_), .A2(new_n31_), .B(new_n67_), .Y(new_n68_));
  AND2x2_ASAP7_75t_R   g050(.A(p1), .B(p0), .Y(new_n69_));
  OA211x2_ASAP7_75t_R  g051(.A1(p6), .A2(new_n69_), .B(p2), .C(p4), .Y(new_n70_));
  NOR2x1_ASAP7_75t_R   g052(.A(p5), .B(p3), .Y(new_n71_));
  AO32x1_ASAP7_75t_R   g053(.A1(new_n66_), .A2(new_n29_), .A3(p3), .B1(new_n71_), .B2(new_n22_), .Y(new_n72_));
  AOI22x1_ASAP7_75t_R  g054(.A1(new_n68_), .A2(new_n19_), .B1(new_n70_), .B2(new_n72_), .Y(new_n73_));
  NAND2x1_ASAP7_75t_R  g055(.A(p4), .B(p5), .Y(new_n74_));
  INVx1_ASAP7_75t_R    g056(.A(new_n74_), .Y(new_n75_));
  NAND2x1_ASAP7_75t_R  g057(.A(new_n66_), .B(new_n26_), .Y(new_n76_));
  NAND2x1_ASAP7_75t_R  g058(.A(p8), .B(new_n22_), .Y(new_n77_));
  AND3x1_ASAP7_75t_R   g059(.A(new_n75_), .B(new_n76_), .C(new_n77_), .Y(new_n78_));
  AOI21x1_ASAP7_75t_R  g060(.A1(new_n77_), .A2(new_n76_), .B(p5), .Y(new_n79_));
  OAI22x1_ASAP7_75t_R  g061(.A1(new_n78_), .A2(new_n79_), .B1(p8), .B2(p7), .Y(new_n80_));
  OAI22x1_ASAP7_75t_R  g062(.A1(p1), .A2(p6), .B1(p8), .B2(p3), .Y(new_n81_));
  AO22x1_ASAP7_75t_R   g063(.A1(new_n66_), .A2(p7), .B1(new_n43_), .B2(new_n81_), .Y(new_n82_));
  NAND2x1_ASAP7_75t_R  g064(.A(p1), .B(p0), .Y(new_n83_));
  NAND2x1_ASAP7_75t_R  g065(.A(p3), .B(new_n22_), .Y(new_n84_));
  NOR2x1_ASAP7_75t_R   g066(.A(p10), .B(new_n56_), .Y(new_n85_));
  AOI211x1_ASAP7_75t_R g067(.A1(p10), .A2(new_n83_), .B(new_n84_), .C(new_n85_), .Y(new_n86_));
  NOR2x1_ASAP7_75t_R   g068(.A(p4), .B(p5), .Y(new_n87_));
  OAI21x1_ASAP7_75t_R  g069(.A1(new_n82_), .A2(new_n86_), .B(new_n87_), .Y(new_n88_));
  NAND3x1_ASAP7_75t_R  g070(.A(new_n73_), .B(new_n80_), .C(new_n88_), .Y(new_n89_));
  AO21x1_ASAP7_75t_R   g071(.A1(p6), .A2(p5), .B(p7), .Y(new_n90_));
  AO21x1_ASAP7_75t_R   g072(.A1(new_n41_), .A2(p6), .B(new_n90_), .Y(new_n91_));
  NOR3x1_ASAP7_75t_R   g073(.A(new_n23_), .B(p8), .C(p3), .Y(new_n92_));
  NOR3x1_ASAP7_75t_R   g074(.A(new_n19_), .B(p5), .C(p0), .Y(new_n93_));
  OAI21x1_ASAP7_75t_R  g075(.A1(new_n92_), .A2(new_n93_), .B(new_n32_), .Y(new_n94_));
  NOR2x1_ASAP7_75t_R   g076(.A(p8), .B(new_n26_), .Y(new_n95_));
  AND3x1_ASAP7_75t_R   g077(.A(p2), .B(p1), .C(p5), .Y(new_n96_));
  AOI22x1_ASAP7_75t_R  g078(.A1(new_n54_), .A2(new_n46_), .B1(new_n95_), .B2(new_n96_), .Y(new_n97_));
  OR4x2_ASAP7_75t_R    g079(.A(new_n23_), .B(p1), .C(p8), .D(p3), .Y(new_n98_));
  AND4x2_ASAP7_75t_R   g080(.A(new_n94_), .B(new_n97_), .C(new_n41_), .D(new_n98_), .Y(new_n99_));
  AND2x2_ASAP7_75t_R   g081(.A(p6), .B(p5), .Y(new_n100_));
  AND3x1_ASAP7_75t_R   g082(.A(new_n100_), .B(p9), .C(p7), .Y(new_n101_));
  NAND2x1_ASAP7_75t_R  g083(.A(new_n66_), .B(new_n101_), .Y(new_n102_));
  OAI21x1_ASAP7_75t_R  g084(.A1(new_n91_), .A2(new_n99_), .B(new_n102_), .Y(new_n103_));
  AOI21x1_ASAP7_75t_R  g085(.A1(new_n41_), .A2(new_n89_), .B(new_n103_), .Y(o1));
  NAND2x1_ASAP7_75t_R  g086(.A(p2), .B(p3), .Y(new_n105_));
  AND2x2_ASAP7_75t_R   g087(.A(p10), .B(p0), .Y(new_n106_));
  NOR2x1_ASAP7_75t_R   g088(.A(new_n105_), .B(new_n106_), .Y(new_n107_));
  OA211x2_ASAP7_75t_R  g089(.A1(new_n71_), .A2(new_n107_), .B(new_n19_), .C(p1), .Y(new_n108_));
  AND3x1_ASAP7_75t_R   g090(.A(new_n56_), .B(new_n23_), .C(p2), .Y(new_n109_));
  AND2x2_ASAP7_75t_R   g091(.A(p4), .B(p3), .Y(new_n110_));
  AOI22x1_ASAP7_75t_R  g092(.A1(new_n109_), .A2(p3), .B1(new_n32_), .B2(new_n110_), .Y(new_n111_));
  AND3x1_ASAP7_75t_R   g093(.A(new_n26_), .B(p2), .C(p4), .Y(new_n112_));
  AND4x2_ASAP7_75t_R   g094(.A(new_n32_), .B(new_n23_), .C(p10), .D(p3), .Y(new_n113_));
  OAI21x1_ASAP7_75t_R  g095(.A1(new_n112_), .A2(new_n113_), .B(new_n69_), .Y(new_n114_));
  NAND2x1_ASAP7_75t_R  g096(.A(new_n111_), .B(new_n114_), .Y(new_n115_));
  AND3x1_ASAP7_75t_R   g097(.A(new_n39_), .B(new_n22_), .C(new_n29_), .Y(new_n116_));
  OAI21x1_ASAP7_75t_R  g098(.A1(new_n108_), .A2(new_n115_), .B(new_n116_), .Y(new_n117_));
  OR3x1_ASAP7_75t_R    g099(.A(new_n56_), .B(new_n23_), .C(p4), .Y(new_n118_));
  NOR2x1_ASAP7_75t_R   g100(.A(new_n105_), .B(new_n93_), .Y(new_n119_));
  AO21x1_ASAP7_75t_R   g101(.A1(new_n105_), .A2(new_n74_), .B(p7), .Y(new_n120_));
  AOI21x1_ASAP7_75t_R  g102(.A1(new_n118_), .A2(new_n119_), .B(new_n120_), .Y(new_n121_));
  AND3x1_ASAP7_75t_R   g103(.A(new_n110_), .B(p5), .C(new_n34_), .Y(new_n122_));
  AND5x1_ASAP7_75t_R   g104(.A(p2), .B(new_n23_), .C(p4), .D(p6), .E(p3), .Y(new_n123_));
  NAND2x1_ASAP7_75t_R  g105(.A(p4), .B(p3), .Y(new_n124_));
  AND3x1_ASAP7_75t_R   g106(.A(new_n124_), .B(p6), .C(p5), .Y(new_n125_));
  OR3x1_ASAP7_75t_R    g107(.A(new_n122_), .B(new_n123_), .C(new_n125_), .Y(new_n126_));
  OAI21x1_ASAP7_75t_R  g108(.A1(new_n121_), .A2(new_n126_), .B(new_n39_), .Y(new_n127_));
  OAI21x1_ASAP7_75t_R  g109(.A1(new_n74_), .A2(new_n84_), .B(new_n60_), .Y(new_n128_));
  NOR2x1_ASAP7_75t_R   g110(.A(p9), .B(new_n29_), .Y(new_n129_));
  AND3x1_ASAP7_75t_R   g111(.A(p4), .B(p6), .C(p5), .Y(new_n130_));
  OR3x1_ASAP7_75t_R    g112(.A(new_n130_), .B(p9), .C(p7), .Y(new_n131_));
  AND2x2_ASAP7_75t_R   g113(.A(p4), .B(p6), .Y(new_n132_));
  AOI21x1_ASAP7_75t_R  g114(.A1(new_n132_), .A2(new_n129_), .B(new_n66_), .Y(new_n133_));
  AOI221x1_ASAP7_75t_R g115(.A1(new_n128_), .A2(new_n129_), .B1(new_n131_), .B2(new_n133_), .C(new_n101_), .Y(new_n134_));
  NAND3x1_ASAP7_75t_R  g116(.A(new_n117_), .B(new_n127_), .C(new_n134_), .Y(o2));
  OR5x1_ASAP7_75t_R    g117(.A(p1), .B(new_n74_), .C(new_n22_), .D(new_n29_), .E(new_n26_), .Y(new_n136_));
  INVx1_ASAP7_75t_R    g118(.A(new_n48_), .Y(new_n137_));
  INVx1_ASAP7_75t_R    g119(.A(new_n87_), .Y(new_n138_));
  OR3x1_ASAP7_75t_R    g120(.A(new_n137_), .B(new_n138_), .C(p3), .Y(new_n139_));
  OR3x1_ASAP7_75t_R    g121(.A(p2), .B(p9), .C(p8), .Y(new_n140_));
  AO21x1_ASAP7_75t_R   g122(.A1(new_n136_), .A2(new_n139_), .B(new_n140_), .Y(o3));
  AND3x1_ASAP7_75t_R   g123(.A(new_n87_), .B(p10), .C(p0), .Y(new_n142_));
  NOR2x1_ASAP7_75t_R   g124(.A(new_n124_), .B(new_n53_), .Y(new_n143_));
  AND3x1_ASAP7_75t_R   g125(.A(new_n29_), .B(p2), .C(p1), .Y(new_n144_));
  OA21x2_ASAP7_75t_R   g126(.A1(new_n142_), .A2(new_n143_), .B(new_n144_), .Y(new_n145_));
  AOI21x1_ASAP7_75t_R  g127(.A1(p7), .A2(new_n130_), .B(new_n66_), .Y(new_n146_));
  NAND2x1_ASAP7_75t_R  g128(.A(p2), .B(new_n29_), .Y(new_n147_));
  AND5x1_ASAP7_75t_R   g129(.A(new_n66_), .B(new_n55_), .C(new_n147_), .D(new_n100_), .E(new_n110_), .Y(new_n148_));
  OR3x1_ASAP7_75t_R    g130(.A(new_n145_), .B(new_n146_), .C(new_n148_), .Y(new_n149_));
  OR3x1_ASAP7_75t_R    g131(.A(new_n56_), .B(new_n43_), .C(p6), .Y(new_n150_));
  AO21x1_ASAP7_75t_R   g132(.A1(new_n74_), .A2(new_n150_), .B(new_n105_), .Y(new_n151_));
  OR3x1_ASAP7_75t_R    g133(.A(new_n26_), .B(p4), .C(p6), .Y(new_n152_));
  AND5x1_ASAP7_75t_R   g134(.A(new_n41_), .B(new_n151_), .C(new_n29_), .D(new_n53_), .E(new_n152_), .Y(new_n153_));
  AOI21x1_ASAP7_75t_R  g135(.A1(new_n41_), .A2(new_n149_), .B(new_n153_), .Y(o4));
  AND5x1_ASAP7_75t_R   g136(.A(p2), .B(p4), .C(p1), .D(p5), .E(p3), .Y(new_n155_));
  NOR2x1_ASAP7_75t_R   g137(.A(new_n137_), .B(new_n155_), .Y(new_n156_));
  AND3x1_ASAP7_75t_R   g138(.A(new_n106_), .B(new_n19_), .C(new_n22_), .Y(new_n157_));
  AO32x1_ASAP7_75t_R   g139(.A1(p7), .A2(new_n55_), .A3(new_n130_), .B1(new_n157_), .B2(new_n144_), .Y(new_n158_));
  AO221x2_ASAP7_75t_R  g140(.A1(new_n138_), .A2(new_n156_), .B1(new_n158_), .B2(p3), .C(new_n40_), .Y(o5));
  OR3x1_ASAP7_75t_R    g141(.A(new_n155_), .B(new_n137_), .C(new_n40_), .Y(o6));
endmodule


