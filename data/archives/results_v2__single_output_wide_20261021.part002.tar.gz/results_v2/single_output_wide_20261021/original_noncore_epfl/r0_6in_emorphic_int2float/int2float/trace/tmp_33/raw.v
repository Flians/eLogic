// Benchmark "/tmp/" written by ABC on Wed Oct 21 14:43:57 2026

module \/tmp/  ( 
    p0, p6, p9, p8, p5, p2, p4, p1, p7, p10, p3,
    o0, o1, o2, o3, o4, o5, o6  );
  input  p0, p6, p9, p8, p5, p2, p4, p1, p7, p10, p3;
  output o0, o1, o2, o3, o4, o5, o6;
  wire new_n19_, new_n20_, new_n21_, new_n22_, new_n23_, new_n24_, new_n25_,
    new_n26_, new_n27_, new_n28_, new_n29_, new_n30_, new_n31_, new_n32_,
    new_n33_, new_n34_, new_n35_, new_n36_, new_n37_, new_n38_, new_n39_,
    new_n40_, new_n41_, new_n42_, new_n43_, new_n44_, new_n45_, new_n46_,
    new_n47_, new_n48_, new_n49_, new_n50_, new_n51_, new_n52_, new_n53_,
    new_n54_, new_n55_, new_n56_, new_n57_, new_n58_, new_n59_, new_n60_,
    new_n61_, new_n63_, new_n64_, new_n65_, new_n66_, new_n67_, new_n68_,
    new_n69_, new_n70_, new_n71_, new_n72_, new_n73_, new_n74_, new_n75_,
    new_n76_, new_n77_, new_n78_, new_n79_, new_n80_, new_n81_, new_n82_,
    new_n83_, new_n84_, new_n85_, new_n86_, new_n87_, new_n88_, new_n89_,
    new_n90_, new_n91_, new_n92_, new_n93_, new_n94_, new_n95_, new_n96_,
    new_n97_, new_n98_, new_n99_, new_n100_, new_n101_, new_n102_,
    new_n103_, new_n105_, new_n106_, new_n107_, new_n108_, new_n109_,
    new_n110_, new_n111_, new_n112_, new_n113_, new_n114_, new_n115_,
    new_n116_, new_n117_, new_n118_, new_n119_, new_n120_, new_n121_,
    new_n122_, new_n123_, new_n124_, new_n125_, new_n126_, new_n127_,
    new_n128_, new_n129_, new_n130_, new_n132_, new_n133_, new_n134_,
    new_n135_, new_n137_, new_n138_, new_n139_, new_n140_, new_n141_,
    new_n142_, new_n143_, new_n144_, new_n145_, new_n146_, new_n147_,
    new_n148_, new_n149_, new_n151_, new_n152_, new_n153_, new_n154_,
    new_n155_, new_n156_;
  NOR2x1_ASAP7_75t_R   g000(.A(p9), .B(p8), .Y(new_n19_));
  INVx1_ASAP7_75t_R    g001(.A(new_n19_), .Y(new_n20_));
  INVx1_ASAP7_75t_R    g002(.A(p4), .Y(new_n21_));
  INVx1_ASAP7_75t_R    g003(.A(p10), .Y(new_n22_));
  NAND2x1_ASAP7_75t_R  g004(.A(p0), .B(p3), .Y(new_n23_));
  AOI211x1_ASAP7_75t_R g005(.A1(new_n22_), .A2(new_n23_), .B(p6), .C(p5), .Y(new_n24_));
  INVx1_ASAP7_75t_R    g006(.A(p3), .Y(new_n25_));
  NAND2x1_ASAP7_75t_R  g007(.A(p7), .B(new_n25_), .Y(new_n26_));
  AO21x1_ASAP7_75t_R   g008(.A1(new_n23_), .A2(new_n26_), .B(new_n22_), .Y(new_n27_));
  AND2x2_ASAP7_75t_R   g009(.A(p7), .B(p3), .Y(new_n28_));
  AO21x1_ASAP7_75t_R   g010(.A1(new_n24_), .A2(new_n27_), .B(new_n28_), .Y(new_n29_));
  NOR2x1_ASAP7_75t_R   g011(.A(p6), .B(p1), .Y(new_n30_));
  AND3x1_ASAP7_75t_R   g012(.A(p0), .B(p2), .C(p4), .Y(new_n31_));
  INVx1_ASAP7_75t_R    g013(.A(p6), .Y(new_n32_));
  NOR2x1_ASAP7_75t_R   g014(.A(p3), .B(new_n32_), .Y(new_n33_));
  INVx1_ASAP7_75t_R    g015(.A(p2), .Y(new_n34_));
  AND3x1_ASAP7_75t_R   g016(.A(new_n34_), .B(p6), .C(p3), .Y(new_n35_));
  AOI221x1_ASAP7_75t_R g017(.A1(new_n30_), .A2(new_n31_), .B1(p2), .B2(new_n33_), .C(new_n35_), .Y(new_n36_));
  OAI22x1_ASAP7_75t_R  g018(.A1(new_n36_), .A2(p7), .B1(new_n21_), .B2(new_n26_), .Y(new_n37_));
  AOI21x1_ASAP7_75t_R  g019(.A1(new_n21_), .A2(new_n29_), .B(new_n37_), .Y(new_n38_));
  INVx1_ASAP7_75t_R    g020(.A(p9), .Y(new_n39_));
  NOR2x1_ASAP7_75t_R   g021(.A(p5), .B(new_n21_), .Y(new_n40_));
  INVx1_ASAP7_75t_R    g022(.A(new_n40_), .Y(new_n41_));
  INVx1_ASAP7_75t_R    g023(.A(p0), .Y(new_n42_));
  AND2x2_ASAP7_75t_R   g024(.A(p2), .B(p3), .Y(new_n43_));
  OR5x1_ASAP7_75t_R    g025(.A(new_n42_), .B(new_n33_), .C(p1), .D(new_n28_), .E(new_n43_), .Y(new_n44_));
  NOR2x1_ASAP7_75t_R   g026(.A(p6), .B(p7), .Y(new_n45_));
  AO31x2_ASAP7_75t_R   g027(.A1(new_n45_), .A2(new_n42_), .A3(p1), .B(p8), .Y(new_n46_));
  AND3x1_ASAP7_75t_R   g028(.A(new_n21_), .B(p8), .C(p5), .Y(new_n47_));
  AOI21x1_ASAP7_75t_R  g029(.A1(new_n40_), .A2(new_n46_), .B(new_n47_), .Y(new_n48_));
  OAI21x1_ASAP7_75t_R  g030(.A1(new_n41_), .A2(new_n44_), .B(new_n48_), .Y(new_n49_));
  INVx1_ASAP7_75t_R    g031(.A(p5), .Y(new_n50_));
  NOR2x1_ASAP7_75t_R   g032(.A(p6), .B(new_n50_), .Y(new_n51_));
  NOR2x1_ASAP7_75t_R   g033(.A(p8), .B(p7), .Y(new_n52_));
  XOR2x2_ASAP7_75t_R   g034(.A(p2), .B(p1), .Y(new_n53_));
  AO21x1_ASAP7_75t_R   g035(.A1(new_n52_), .A2(new_n53_), .B(p9), .Y(new_n54_));
  NAND2x1_ASAP7_75t_R  g036(.A(p6), .B(new_n50_), .Y(new_n55_));
  INVx1_ASAP7_75t_R    g037(.A(p8), .Y(new_n56_));
  INVx1_ASAP7_75t_R    g038(.A(p7), .Y(new_n57_));
  OR3x1_ASAP7_75t_R    g039(.A(new_n56_), .B(new_n50_), .C(new_n57_), .Y(new_n58_));
  AOI21x1_ASAP7_75t_R  g040(.A1(new_n55_), .A2(new_n58_), .B(new_n39_), .Y(new_n59_));
  AO21x1_ASAP7_75t_R   g041(.A1(new_n51_), .A2(new_n54_), .B(new_n59_), .Y(new_n60_));
  AOI21x1_ASAP7_75t_R  g042(.A1(new_n39_), .A2(new_n49_), .B(new_n60_), .Y(new_n61_));
  OAI21x1_ASAP7_75t_R  g043(.A1(new_n20_), .A2(new_n38_), .B(new_n61_), .Y(o0));
  NOR2x1_ASAP7_75t_R   g044(.A(p8), .B(p3), .Y(new_n63_));
  NOR2x1_ASAP7_75t_R   g045(.A(new_n30_), .B(new_n63_), .Y(new_n64_));
  OAI22x1_ASAP7_75t_R  g046(.A1(new_n64_), .A2(p0), .B1(p8), .B2(new_n57_), .Y(new_n65_));
  NAND2x1_ASAP7_75t_R  g047(.A(p0), .B(p10), .Y(new_n66_));
  NAND2x1_ASAP7_75t_R  g048(.A(p1), .B(new_n66_), .Y(new_n67_));
  NOR2x1_ASAP7_75t_R   g049(.A(p6), .B(new_n25_), .Y(new_n68_));
  INVx1_ASAP7_75t_R    g050(.A(p1), .Y(new_n69_));
  NAND2x1_ASAP7_75t_R  g051(.A(p10), .B(new_n69_), .Y(new_n70_));
  AND3x1_ASAP7_75t_R   g052(.A(new_n67_), .B(new_n68_), .C(new_n70_), .Y(new_n71_));
  NOR2x1_ASAP7_75t_R   g053(.A(p5), .B(p4), .Y(new_n72_));
  OAI21x1_ASAP7_75t_R  g054(.A1(new_n65_), .A2(new_n71_), .B(new_n72_), .Y(new_n73_));
  INVx1_ASAP7_75t_R    g055(.A(new_n52_), .Y(new_n74_));
  NAND2x1_ASAP7_75t_R  g056(.A(p2), .B(p3), .Y(new_n75_));
  NAND2x1_ASAP7_75t_R  g057(.A(p6), .B(new_n75_), .Y(new_n76_));
  NAND2x1_ASAP7_75t_R  g058(.A(p8), .B(new_n32_), .Y(new_n77_));
  OAI21x1_ASAP7_75t_R  g059(.A1(new_n74_), .A2(new_n76_), .B(new_n77_), .Y(new_n78_));
  OAI21x1_ASAP7_75t_R  g060(.A1(p6), .A2(p5), .B(new_n25_), .Y(new_n79_));
  OAI21x1_ASAP7_75t_R  g061(.A1(p8), .A2(p7), .B(p3), .Y(new_n80_));
  AO21x1_ASAP7_75t_R   g062(.A1(p0), .A2(p1), .B(p6), .Y(new_n81_));
  AND5x1_ASAP7_75t_R   g063(.A(p2), .B(new_n79_), .C(p4), .D(new_n80_), .E(new_n81_), .Y(new_n82_));
  AOI21x1_ASAP7_75t_R  g064(.A1(new_n21_), .A2(new_n78_), .B(new_n82_), .Y(new_n83_));
  INVx1_ASAP7_75t_R    g065(.A(new_n63_), .Y(new_n84_));
  AOI21x1_ASAP7_75t_R  g066(.A1(new_n77_), .A2(new_n84_), .B(p5), .Y(new_n85_));
  NAND2x1_ASAP7_75t_R  g067(.A(p5), .B(p4), .Y(new_n86_));
  INVx1_ASAP7_75t_R    g068(.A(new_n86_), .Y(new_n87_));
  AND3x1_ASAP7_75t_R   g069(.A(new_n84_), .B(new_n87_), .C(new_n77_), .Y(new_n88_));
  OAI21x1_ASAP7_75t_R  g070(.A1(new_n85_), .A2(new_n88_), .B(new_n74_), .Y(new_n89_));
  NAND3x1_ASAP7_75t_R  g071(.A(new_n73_), .B(new_n83_), .C(new_n89_), .Y(new_n90_));
  AO21x1_ASAP7_75t_R   g072(.A1(p6), .A2(p5), .B(p7), .Y(new_n91_));
  AO21x1_ASAP7_75t_R   g073(.A1(p6), .A2(new_n39_), .B(new_n91_), .Y(new_n92_));
  NOR3x1_ASAP7_75t_R   g074(.A(new_n50_), .B(p8), .C(p3), .Y(new_n93_));
  NOR3x1_ASAP7_75t_R   g075(.A(new_n21_), .B(p5), .C(p2), .Y(new_n94_));
  OAI21x1_ASAP7_75t_R  g076(.A1(new_n93_), .A2(new_n94_), .B(new_n69_), .Y(new_n95_));
  NOR3x1_ASAP7_75t_R   g077(.A(new_n21_), .B(p0), .C(p5), .Y(new_n96_));
  OAI21x1_ASAP7_75t_R  g078(.A1(new_n93_), .A2(new_n96_), .B(new_n34_), .Y(new_n97_));
  OR5x1_ASAP7_75t_R    g079(.A(p8), .B(new_n50_), .C(new_n34_), .D(new_n69_), .E(new_n25_), .Y(new_n98_));
  AND4x2_ASAP7_75t_R   g080(.A(new_n95_), .B(new_n97_), .C(new_n39_), .D(new_n98_), .Y(new_n99_));
  AND2x2_ASAP7_75t_R   g081(.A(p6), .B(p5), .Y(new_n100_));
  AND3x1_ASAP7_75t_R   g082(.A(new_n100_), .B(p9), .C(p7), .Y(new_n101_));
  NAND2x1_ASAP7_75t_R  g083(.A(new_n56_), .B(new_n101_), .Y(new_n102_));
  OAI21x1_ASAP7_75t_R  g084(.A1(new_n92_), .A2(new_n99_), .B(new_n102_), .Y(new_n103_));
  AOI21x1_ASAP7_75t_R  g085(.A1(new_n39_), .A2(new_n90_), .B(new_n103_), .Y(o1));
  AO21x1_ASAP7_75t_R   g086(.A1(new_n75_), .A2(new_n86_), .B(p7), .Y(new_n105_));
  AND3x1_ASAP7_75t_R   g087(.A(new_n21_), .B(p5), .C(p1), .Y(new_n106_));
  NOR3x1_ASAP7_75t_R   g088(.A(new_n106_), .B(new_n96_), .C(new_n75_), .Y(new_n107_));
  NAND2x1_ASAP7_75t_R  g089(.A(p4), .B(p3), .Y(new_n108_));
  AND5x1_ASAP7_75t_R   g090(.A(new_n50_), .B(p6), .C(p2), .D(p4), .E(p3), .Y(new_n109_));
  AND5x1_ASAP7_75t_R   g091(.A(new_n32_), .B(new_n69_), .C(p5), .D(p4), .E(p3), .Y(new_n110_));
  AOI211x1_ASAP7_75t_R g092(.A1(new_n100_), .A2(new_n108_), .B(new_n109_), .C(new_n110_), .Y(new_n111_));
  OAI21x1_ASAP7_75t_R  g093(.A1(new_n105_), .A2(new_n107_), .B(new_n111_), .Y(new_n112_));
  OR3x1_ASAP7_75t_R    g094(.A(new_n86_), .B(p6), .C(new_n25_), .Y(new_n113_));
  NAND2x1_ASAP7_75t_R  g095(.A(p7), .B(new_n39_), .Y(new_n114_));
  AO21x1_ASAP7_75t_R   g096(.A1(new_n55_), .A2(new_n113_), .B(new_n114_), .Y(new_n115_));
  OR3x1_ASAP7_75t_R    g097(.A(new_n32_), .B(new_n21_), .C(p9), .Y(new_n116_));
  OA21x2_ASAP7_75t_R   g098(.A1(p9), .A2(p7), .B(p8), .Y(new_n117_));
  AND5x1_ASAP7_75t_R   g099(.A(p6), .B(new_n57_), .C(p8), .D(p5), .E(p4), .Y(new_n118_));
  AOI211x1_ASAP7_75t_R g100(.A1(new_n116_), .A2(new_n117_), .B(new_n118_), .C(new_n101_), .Y(new_n119_));
  NAND2x1_ASAP7_75t_R  g101(.A(new_n115_), .B(new_n119_), .Y(new_n120_));
  AOI21x1_ASAP7_75t_R  g102(.A1(new_n19_), .A2(new_n112_), .B(new_n120_), .Y(new_n121_));
  OAI21x1_ASAP7_75t_R  g103(.A1(new_n72_), .A2(new_n31_), .B(new_n25_), .Y(new_n122_));
  INVx1_ASAP7_75t_R    g104(.A(new_n66_), .Y(new_n123_));
  OR3x1_ASAP7_75t_R    g105(.A(new_n123_), .B(p4), .C(new_n75_), .Y(new_n124_));
  AO21x1_ASAP7_75t_R   g106(.A1(new_n122_), .A2(new_n124_), .B(new_n69_), .Y(new_n125_));
  NOR2x1_ASAP7_75t_R   g107(.A(p2), .B(new_n21_), .Y(new_n126_));
  AND3x1_ASAP7_75t_R   g108(.A(new_n53_), .B(new_n50_), .C(new_n67_), .Y(new_n127_));
  OAI21x1_ASAP7_75t_R  g109(.A1(new_n126_), .A2(new_n127_), .B(p3), .Y(new_n128_));
  NAND2x1_ASAP7_75t_R  g110(.A(new_n19_), .B(new_n45_), .Y(new_n129_));
  AO21x1_ASAP7_75t_R   g111(.A1(new_n125_), .A2(new_n128_), .B(new_n129_), .Y(new_n130_));
  NAND2x1_ASAP7_75t_R  g112(.A(new_n121_), .B(new_n130_), .Y(o2));
  AND3x1_ASAP7_75t_R   g113(.A(new_n72_), .B(new_n45_), .C(new_n25_), .Y(new_n132_));
  AND3x1_ASAP7_75t_R   g114(.A(p6), .B(p5), .C(p4), .Y(new_n133_));
  AND3x1_ASAP7_75t_R   g115(.A(new_n133_), .B(new_n28_), .C(new_n69_), .Y(new_n134_));
  NOR2x1_ASAP7_75t_R   g116(.A(new_n132_), .B(new_n134_), .Y(new_n135_));
  OR3x1_ASAP7_75t_R    g117(.A(new_n135_), .B(p2), .C(new_n20_), .Y(o3));
  NAND2x1_ASAP7_75t_R  g118(.A(p7), .B(new_n133_), .Y(new_n137_));
  OR3x1_ASAP7_75t_R    g119(.A(new_n66_), .B(p5), .C(p4), .Y(new_n138_));
  NAND2x1_ASAP7_75t_R  g120(.A(new_n113_), .B(new_n138_), .Y(new_n139_));
  AND3x1_ASAP7_75t_R   g121(.A(new_n57_), .B(p2), .C(p1), .Y(new_n140_));
  NAND2x1_ASAP7_75t_R  g122(.A(new_n34_), .B(new_n69_), .Y(new_n141_));
  NAND2x1_ASAP7_75t_R  g123(.A(p2), .B(new_n57_), .Y(new_n142_));
  AND5x1_ASAP7_75t_R   g124(.A(new_n56_), .B(new_n141_), .C(new_n142_), .D(p3), .E(new_n133_), .Y(new_n143_));
  AO221x2_ASAP7_75t_R  g125(.A1(p8), .A2(new_n137_), .B1(new_n139_), .B2(new_n140_), .C(new_n143_), .Y(new_n144_));
  OR3x1_ASAP7_75t_R    g126(.A(new_n42_), .B(new_n69_), .C(p6), .Y(new_n145_));
  AO21x1_ASAP7_75t_R   g127(.A1(new_n86_), .A2(new_n145_), .B(new_n75_), .Y(new_n146_));
  INVx1_ASAP7_75t_R    g128(.A(new_n51_), .Y(new_n147_));
  OR3x1_ASAP7_75t_R    g129(.A(new_n25_), .B(p6), .C(p4), .Y(new_n148_));
  AND5x1_ASAP7_75t_R   g130(.A(new_n39_), .B(new_n146_), .C(new_n57_), .D(new_n147_), .E(new_n148_), .Y(new_n149_));
  AOI21x1_ASAP7_75t_R  g131(.A1(new_n39_), .A2(new_n144_), .B(new_n149_), .Y(o4));
  INVx1_ASAP7_75t_R    g132(.A(new_n45_), .Y(new_n151_));
  AND5x1_ASAP7_75t_R   g133(.A(p5), .B(p2), .C(p4), .D(p1), .E(p3), .Y(new_n152_));
  NOR2x1_ASAP7_75t_R   g134(.A(new_n151_), .B(new_n152_), .Y(new_n153_));
  INVx1_ASAP7_75t_R    g135(.A(new_n72_), .Y(new_n154_));
  AND3x1_ASAP7_75t_R   g136(.A(new_n123_), .B(new_n32_), .C(new_n21_), .Y(new_n155_));
  AO32x1_ASAP7_75t_R   g137(.A1(p7), .A2(new_n141_), .A3(new_n133_), .B1(new_n155_), .B2(new_n140_), .Y(new_n156_));
  AO221x2_ASAP7_75t_R  g138(.A1(new_n153_), .A2(new_n154_), .B1(new_n156_), .B2(p3), .C(new_n20_), .Y(o5));
  OR3x1_ASAP7_75t_R    g139(.A(new_n152_), .B(new_n20_), .C(new_n151_), .Y(o6));
endmodule


