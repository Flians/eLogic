// Benchmark "/tmp/" written by ABC on Wed Oct 21 14:44:00 2026

module \/tmp/  ( 
    p1, p6, p3, p8, p5, p7, p9, p0, p2, p10, p4,
    o0, o1, o2, o3, o4, o5, o6  );
  input  p1, p6, p3, p8, p5, p7, p9, p0, p2, p10, p4;
  output o0, o1, o2, o3, o4, o5, o6;
  wire new_n19_, new_n20_, new_n21_, new_n22_, new_n23_, new_n24_, new_n25_,
    new_n26_, new_n27_, new_n28_, new_n29_, new_n30_, new_n31_, new_n32_,
    new_n33_, new_n34_, new_n35_, new_n36_, new_n37_, new_n38_, new_n39_,
    new_n40_, new_n41_, new_n42_, new_n43_, new_n44_, new_n45_, new_n46_,
    new_n47_, new_n48_, new_n49_, new_n50_, new_n51_, new_n52_, new_n53_,
    new_n54_, new_n55_, new_n56_, new_n57_, new_n58_, new_n59_, new_n60_,
    new_n61_, new_n62_, new_n63_, new_n65_, new_n66_, new_n67_, new_n68_,
    new_n69_, new_n70_, new_n71_, new_n72_, new_n73_, new_n74_, new_n75_,
    new_n76_, new_n77_, new_n78_, new_n79_, new_n80_, new_n81_, new_n82_,
    new_n83_, new_n84_, new_n85_, new_n86_, new_n87_, new_n88_, new_n89_,
    new_n90_, new_n91_, new_n92_, new_n93_, new_n94_, new_n95_, new_n96_,
    new_n97_, new_n98_, new_n99_, new_n100_, new_n101_, new_n103_,
    new_n104_, new_n105_, new_n106_, new_n107_, new_n108_, new_n109_,
    new_n110_, new_n111_, new_n112_, new_n113_, new_n114_, new_n115_,
    new_n116_, new_n117_, new_n118_, new_n119_, new_n120_, new_n121_,
    new_n122_, new_n123_, new_n124_, new_n125_, new_n126_, new_n127_,
    new_n128_, new_n129_, new_n130_, new_n131_, new_n132_, new_n133_,
    new_n134_, new_n135_, new_n137_, new_n138_, new_n140_, new_n141_,
    new_n142_, new_n143_, new_n144_, new_n145_, new_n146_, new_n147_,
    new_n148_, new_n149_, new_n150_, new_n151_, new_n153_, new_n154_,
    new_n155_, new_n156_;
  INVx1_ASAP7_75t_R    g000(.A(p4), .Y(new_n19_));
  INVx1_ASAP7_75t_R    g001(.A(p10), .Y(new_n20_));
  NAND2x1_ASAP7_75t_R  g002(.A(p3), .B(p0), .Y(new_n21_));
  AOI211x1_ASAP7_75t_R g003(.A1(new_n20_), .A2(new_n21_), .B(p6), .C(p5), .Y(new_n22_));
  INVx1_ASAP7_75t_R    g004(.A(p3), .Y(new_n23_));
  NAND2x1_ASAP7_75t_R  g005(.A(p7), .B(new_n23_), .Y(new_n24_));
  AO21x1_ASAP7_75t_R   g006(.A1(new_n21_), .A2(new_n24_), .B(new_n20_), .Y(new_n25_));
  AND2x2_ASAP7_75t_R   g007(.A(p3), .B(p7), .Y(new_n26_));
  AO21x1_ASAP7_75t_R   g008(.A1(new_n22_), .A2(new_n25_), .B(new_n26_), .Y(new_n27_));
  NAND2x1_ASAP7_75t_R  g009(.A(p2), .B(p4), .Y(new_n28_));
  NOR2x1_ASAP7_75t_R   g010(.A(p6), .B(new_n28_), .Y(new_n29_));
  INVx1_ASAP7_75t_R    g011(.A(p0), .Y(new_n30_));
  NOR2x1_ASAP7_75t_R   g012(.A(p1), .B(new_n30_), .Y(new_n31_));
  INVx1_ASAP7_75t_R    g013(.A(p2), .Y(new_n32_));
  NAND2x1_ASAP7_75t_R  g014(.A(new_n23_), .B(new_n32_), .Y(new_n33_));
  INVx1_ASAP7_75t_R    g015(.A(p6), .Y(new_n34_));
  AOI21x1_ASAP7_75t_R  g016(.A1(p3), .A2(p2), .B(new_n34_), .Y(new_n35_));
  AOI22x1_ASAP7_75t_R  g017(.A1(new_n29_), .A2(new_n31_), .B1(new_n33_), .B2(new_n35_), .Y(new_n36_));
  OAI22x1_ASAP7_75t_R  g018(.A1(new_n36_), .A2(p7), .B1(new_n19_), .B2(new_n24_), .Y(new_n37_));
  AOI21x1_ASAP7_75t_R  g019(.A1(new_n19_), .A2(new_n27_), .B(new_n37_), .Y(new_n38_));
  INVx1_ASAP7_75t_R    g020(.A(p8), .Y(new_n39_));
  INVx1_ASAP7_75t_R    g021(.A(p9), .Y(new_n40_));
  NAND2x1_ASAP7_75t_R  g022(.A(new_n39_), .B(new_n40_), .Y(new_n41_));
  NOR2x1_ASAP7_75t_R   g023(.A(p5), .B(new_n19_), .Y(new_n42_));
  INVx1_ASAP7_75t_R    g024(.A(new_n42_), .Y(new_n43_));
  NOR2x1_ASAP7_75t_R   g025(.A(p3), .B(new_n34_), .Y(new_n44_));
  AND2x2_ASAP7_75t_R   g026(.A(p3), .B(p2), .Y(new_n45_));
  OR5x1_ASAP7_75t_R    g027(.A(p1), .B(new_n44_), .C(new_n30_), .D(new_n26_), .E(new_n45_), .Y(new_n46_));
  NOR2x1_ASAP7_75t_R   g028(.A(p6), .B(p7), .Y(new_n47_));
  AO31x2_ASAP7_75t_R   g029(.A1(new_n47_), .A2(p1), .A3(new_n30_), .B(p8), .Y(new_n48_));
  AND3x1_ASAP7_75t_R   g030(.A(new_n19_), .B(p8), .C(p5), .Y(new_n49_));
  AOI21x1_ASAP7_75t_R  g031(.A1(new_n42_), .A2(new_n48_), .B(new_n49_), .Y(new_n50_));
  OAI21x1_ASAP7_75t_R  g032(.A1(new_n43_), .A2(new_n46_), .B(new_n50_), .Y(new_n51_));
  NOR2x1_ASAP7_75t_R   g033(.A(p1), .B(p2), .Y(new_n52_));
  INVx1_ASAP7_75t_R    g034(.A(new_n52_), .Y(new_n53_));
  INVx1_ASAP7_75t_R    g035(.A(p1), .Y(new_n54_));
  NOR2x1_ASAP7_75t_R   g036(.A(p8), .B(p7), .Y(new_n55_));
  OA21x2_ASAP7_75t_R   g037(.A1(new_n54_), .A2(new_n32_), .B(new_n55_), .Y(new_n56_));
  NAND2x1_ASAP7_75t_R  g038(.A(new_n53_), .B(new_n56_), .Y(new_n57_));
  AND3x1_ASAP7_75t_R   g039(.A(p8), .B(p5), .C(p7), .Y(new_n58_));
  NOR2x1_ASAP7_75t_R   g040(.A(p5), .B(new_n34_), .Y(new_n59_));
  OAI21x1_ASAP7_75t_R  g041(.A1(new_n58_), .A2(new_n59_), .B(p9), .Y(new_n60_));
  NAND2x1_ASAP7_75t_R  g042(.A(p5), .B(new_n34_), .Y(new_n61_));
  AOI22x1_ASAP7_75t_R  g043(.A1(new_n57_), .A2(new_n40_), .B1(new_n60_), .B2(new_n61_), .Y(new_n62_));
  AOI21x1_ASAP7_75t_R  g044(.A1(new_n40_), .A2(new_n51_), .B(new_n62_), .Y(new_n63_));
  OAI21x1_ASAP7_75t_R  g045(.A1(new_n38_), .A2(new_n41_), .B(new_n63_), .Y(o0));
  AO21x1_ASAP7_75t_R   g046(.A1(p6), .A2(p5), .B(p7), .Y(new_n65_));
  AO21x1_ASAP7_75t_R   g047(.A1(p6), .A2(new_n40_), .B(new_n65_), .Y(new_n66_));
  INVx1_ASAP7_75t_R    g048(.A(p5), .Y(new_n67_));
  NOR3x1_ASAP7_75t_R   g049(.A(new_n67_), .B(p3), .C(p8), .Y(new_n68_));
  NOR3x1_ASAP7_75t_R   g050(.A(new_n19_), .B(p5), .C(p0), .Y(new_n69_));
  OAI21x1_ASAP7_75t_R  g051(.A1(new_n68_), .A2(new_n69_), .B(new_n32_), .Y(new_n70_));
  NOR3x1_ASAP7_75t_R   g052(.A(new_n19_), .B(p5), .C(p2), .Y(new_n71_));
  OAI21x1_ASAP7_75t_R  g053(.A1(new_n68_), .A2(new_n71_), .B(new_n54_), .Y(new_n72_));
  NAND2x1_ASAP7_75t_R  g054(.A(p3), .B(p2), .Y(new_n73_));
  OR4x2_ASAP7_75t_R    g055(.A(new_n73_), .B(new_n54_), .C(p8), .D(new_n67_), .Y(new_n74_));
  AND4x2_ASAP7_75t_R   g056(.A(new_n70_), .B(new_n72_), .C(new_n40_), .D(new_n74_), .Y(new_n75_));
  INVx1_ASAP7_75t_R    g057(.A(p7), .Y(new_n76_));
  OR5x1_ASAP7_75t_R    g058(.A(new_n34_), .B(new_n67_), .C(new_n76_), .D(new_n40_), .E(p8), .Y(new_n77_));
  OAI21x1_ASAP7_75t_R  g059(.A1(new_n66_), .A2(new_n75_), .B(new_n77_), .Y(new_n78_));
  NOR2x1_ASAP7_75t_R   g060(.A(p3), .B(p8), .Y(new_n79_));
  AO21x1_ASAP7_75t_R   g061(.A1(new_n34_), .A2(p8), .B(new_n79_), .Y(new_n80_));
  AND2x2_ASAP7_75t_R   g062(.A(p5), .B(p4), .Y(new_n81_));
  AOI211x1_ASAP7_75t_R g063(.A1(new_n34_), .A2(p8), .B(new_n79_), .C(new_n81_), .Y(new_n82_));
  AOI211x1_ASAP7_75t_R g064(.A1(p5), .A2(new_n80_), .B(new_n55_), .C(new_n82_), .Y(new_n83_));
  NOR2x1_ASAP7_75t_R   g065(.A(p6), .B(new_n39_), .Y(new_n84_));
  AOI21x1_ASAP7_75t_R  g066(.A1(new_n55_), .A2(new_n35_), .B(new_n84_), .Y(new_n85_));
  NOR3x1_ASAP7_75t_R   g067(.A(p6), .B(p3), .C(p5), .Y(new_n86_));
  NOR3x1_ASAP7_75t_R   g068(.A(new_n23_), .B(p8), .C(p7), .Y(new_n87_));
  AOI21x1_ASAP7_75t_R  g069(.A1(p1), .A2(p0), .B(p6), .Y(new_n88_));
  NOR2x1_ASAP7_75t_R   g070(.A(new_n28_), .B(new_n88_), .Y(new_n89_));
  OAI21x1_ASAP7_75t_R  g071(.A1(new_n86_), .A2(new_n87_), .B(new_n89_), .Y(new_n90_));
  OAI21x1_ASAP7_75t_R  g072(.A1(p4), .A2(new_n85_), .B(new_n90_), .Y(new_n91_));
  OAI22x1_ASAP7_75t_R  g073(.A1(p1), .A2(p6), .B1(p3), .B2(p8), .Y(new_n92_));
  AOI22x1_ASAP7_75t_R  g074(.A1(new_n92_), .A2(new_n30_), .B1(new_n39_), .B2(p7), .Y(new_n93_));
  NAND2x1_ASAP7_75t_R  g075(.A(p0), .B(p10), .Y(new_n94_));
  NAND2x1_ASAP7_75t_R  g076(.A(p1), .B(new_n94_), .Y(new_n95_));
  NOR2x1_ASAP7_75t_R   g077(.A(p6), .B(new_n23_), .Y(new_n96_));
  NAND2x1_ASAP7_75t_R  g078(.A(p10), .B(new_n54_), .Y(new_n97_));
  NAND3x1_ASAP7_75t_R  g079(.A(new_n95_), .B(new_n96_), .C(new_n97_), .Y(new_n98_));
  NAND2x1_ASAP7_75t_R  g080(.A(new_n67_), .B(new_n19_), .Y(new_n99_));
  AOI21x1_ASAP7_75t_R  g081(.A1(new_n93_), .A2(new_n98_), .B(new_n99_), .Y(new_n100_));
  OA31x2_ASAP7_75t_R   g082(.A1(new_n83_), .A2(new_n91_), .A3(new_n100_), .B1(new_n40_), .Y(new_n101_));
  NOR2x1_ASAP7_75t_R   g083(.A(new_n78_), .B(new_n101_), .Y(o1));
  NOR2x1_ASAP7_75t_R   g084(.A(p2), .B(new_n19_), .Y(new_n103_));
  NOR3x1_ASAP7_75t_R   g085(.A(new_n32_), .B(p1), .C(p5), .Y(new_n104_));
  OAI21x1_ASAP7_75t_R  g086(.A1(new_n103_), .A2(new_n104_), .B(p3), .Y(new_n105_));
  INVx1_ASAP7_75t_R    g087(.A(new_n47_), .Y(new_n106_));
  AOI21x1_ASAP7_75t_R  g088(.A1(new_n54_), .A2(new_n105_), .B(new_n106_), .Y(new_n107_));
  AND3x1_ASAP7_75t_R   g089(.A(new_n67_), .B(new_n32_), .C(p10), .Y(new_n108_));
  AOI21x1_ASAP7_75t_R  g090(.A1(new_n23_), .A2(new_n28_), .B(new_n30_), .Y(new_n109_));
  OAI21x1_ASAP7_75t_R  g091(.A1(new_n23_), .A2(new_n108_), .B(new_n109_), .Y(new_n110_));
  NOR2x1_ASAP7_75t_R   g092(.A(p4), .B(new_n73_), .Y(new_n111_));
  AND3x1_ASAP7_75t_R   g093(.A(new_n23_), .B(new_n67_), .C(new_n19_), .Y(new_n112_));
  AOI21x1_ASAP7_75t_R  g094(.A1(new_n94_), .A2(new_n111_), .B(new_n112_), .Y(new_n113_));
  NAND3x1_ASAP7_75t_R  g095(.A(new_n110_), .B(new_n113_), .C(new_n105_), .Y(new_n114_));
  AND3x1_ASAP7_75t_R   g096(.A(new_n19_), .B(p1), .C(p5), .Y(new_n115_));
  NOR3x1_ASAP7_75t_R   g097(.A(new_n115_), .B(new_n69_), .C(new_n73_), .Y(new_n116_));
  INVx1_ASAP7_75t_R    g098(.A(new_n81_), .Y(new_n117_));
  AO21x1_ASAP7_75t_R   g099(.A1(new_n73_), .A2(new_n117_), .B(p7), .Y(new_n118_));
  AND3x1_ASAP7_75t_R   g100(.A(p3), .B(p2), .C(p4), .Y(new_n119_));
  NAND2x1_ASAP7_75t_R  g101(.A(p3), .B(p4), .Y(new_n120_));
  AND3x1_ASAP7_75t_R   g102(.A(new_n120_), .B(p6), .C(p5), .Y(new_n121_));
  AND5x1_ASAP7_75t_R   g103(.A(new_n54_), .B(new_n34_), .C(p3), .D(p5), .E(p4), .Y(new_n122_));
  AOI211x1_ASAP7_75t_R g104(.A1(new_n59_), .A2(new_n119_), .B(new_n121_), .C(new_n122_), .Y(new_n123_));
  OAI21x1_ASAP7_75t_R  g105(.A1(new_n116_), .A2(new_n118_), .B(new_n123_), .Y(new_n124_));
  AOI21x1_ASAP7_75t_R  g106(.A1(new_n107_), .A2(new_n114_), .B(new_n124_), .Y(new_n125_));
  NOR2x1_ASAP7_75t_R   g107(.A(p9), .B(new_n76_), .Y(new_n126_));
  AND2x2_ASAP7_75t_R   g108(.A(p6), .B(p4), .Y(new_n127_));
  AND3x1_ASAP7_75t_R   g109(.A(p6), .B(p5), .C(p4), .Y(new_n128_));
  INVx1_ASAP7_75t_R    g110(.A(new_n128_), .Y(new_n129_));
  NOR2x1_ASAP7_75t_R   g111(.A(p7), .B(p9), .Y(new_n130_));
  AO221x2_ASAP7_75t_R  g112(.A1(new_n126_), .A2(new_n127_), .B1(new_n129_), .B2(new_n130_), .C(new_n39_), .Y(new_n131_));
  OR4x2_ASAP7_75t_R    g113(.A(new_n34_), .B(new_n67_), .C(new_n76_), .D(new_n40_), .Y(new_n132_));
  NOR2x1_ASAP7_75t_R   g114(.A(new_n120_), .B(new_n61_), .Y(new_n133_));
  OAI21x1_ASAP7_75t_R  g115(.A1(new_n59_), .A2(new_n133_), .B(new_n126_), .Y(new_n134_));
  AND3x1_ASAP7_75t_R   g116(.A(new_n131_), .B(new_n132_), .C(new_n134_), .Y(new_n135_));
  OAI21x1_ASAP7_75t_R  g117(.A1(new_n41_), .A2(new_n125_), .B(new_n135_), .Y(o2));
  AND3x1_ASAP7_75t_R   g118(.A(new_n128_), .B(new_n26_), .C(new_n54_), .Y(new_n137_));
  AOI21x1_ASAP7_75t_R  g119(.A1(new_n47_), .A2(new_n112_), .B(new_n137_), .Y(new_n138_));
  OR3x1_ASAP7_75t_R    g120(.A(new_n138_), .B(p2), .C(new_n41_), .Y(o3));
  AND2x2_ASAP7_75t_R   g121(.A(p0), .B(p10), .Y(new_n140_));
  AND3x1_ASAP7_75t_R   g122(.A(new_n140_), .B(new_n67_), .C(new_n19_), .Y(new_n141_));
  AND3x1_ASAP7_75t_R   g123(.A(new_n76_), .B(p1), .C(p2), .Y(new_n142_));
  OA21x2_ASAP7_75t_R   g124(.A1(new_n133_), .A2(new_n141_), .B(new_n142_), .Y(new_n143_));
  OA21x2_ASAP7_75t_R   g125(.A1(new_n76_), .A2(new_n129_), .B(p8), .Y(new_n144_));
  NAND2x1_ASAP7_75t_R  g126(.A(p2), .B(new_n76_), .Y(new_n145_));
  AND5x1_ASAP7_75t_R   g127(.A(p3), .B(new_n53_), .C(new_n145_), .D(new_n39_), .E(new_n128_), .Y(new_n146_));
  OR3x1_ASAP7_75t_R    g128(.A(new_n143_), .B(new_n144_), .C(new_n146_), .Y(new_n147_));
  OR3x1_ASAP7_75t_R    g129(.A(new_n54_), .B(new_n30_), .C(p6), .Y(new_n148_));
  AO21x1_ASAP7_75t_R   g130(.A1(new_n117_), .A2(new_n148_), .B(new_n73_), .Y(new_n149_));
  OR3x1_ASAP7_75t_R    g131(.A(new_n23_), .B(p6), .C(p4), .Y(new_n150_));
  AND3x1_ASAP7_75t_R   g132(.A(new_n149_), .B(new_n61_), .C(new_n150_), .Y(new_n151_));
  AOI22x1_ASAP7_75t_R  g133(.A1(new_n147_), .A2(new_n40_), .B1(new_n130_), .B2(new_n151_), .Y(o4));
  AND3x1_ASAP7_75t_R   g134(.A(new_n119_), .B(p1), .C(p5), .Y(new_n153_));
  NOR2x1_ASAP7_75t_R   g135(.A(new_n106_), .B(new_n153_), .Y(new_n154_));
  AND3x1_ASAP7_75t_R   g136(.A(new_n140_), .B(new_n34_), .C(new_n19_), .Y(new_n155_));
  AO32x1_ASAP7_75t_R   g137(.A1(p7), .A2(new_n53_), .A3(new_n128_), .B1(new_n155_), .B2(new_n142_), .Y(new_n156_));
  AO221x2_ASAP7_75t_R  g138(.A1(new_n99_), .A2(new_n154_), .B1(new_n156_), .B2(p3), .C(new_n41_), .Y(o5));
  OR3x1_ASAP7_75t_R    g139(.A(new_n153_), .B(new_n41_), .C(new_n106_), .Y(o6));
endmodule


