// Benchmark "/tmp/" written by ABC on Wed Oct 21 14:43:57 2026

module \/tmp/  ( 
    p9, p10, p8, p0, p1, p4, p3, p2, p7, p5, p6,
    o0, o1, o2, o3, o4, o5, o6  );
  input  p9, p10, p8, p0, p1, p4, p3, p2, p7, p5, p6;
  output o0, o1, o2, o3, o4, o5, o6;
  wire new_n19_, new_n20_, new_n21_, new_n22_, new_n23_, new_n24_, new_n25_,
    new_n26_, new_n27_, new_n28_, new_n29_, new_n30_, new_n31_, new_n32_,
    new_n33_, new_n34_, new_n35_, new_n36_, new_n37_, new_n38_, new_n39_,
    new_n40_, new_n41_, new_n42_, new_n43_, new_n44_, new_n45_, new_n46_,
    new_n47_, new_n48_, new_n49_, new_n50_, new_n51_, new_n52_, new_n53_,
    new_n54_, new_n55_, new_n56_, new_n57_, new_n58_, new_n59_, new_n60_,
    new_n61_, new_n62_, new_n63_, new_n64_, new_n66_, new_n67_, new_n68_,
    new_n69_, new_n70_, new_n71_, new_n72_, new_n73_, new_n74_, new_n75_,
    new_n76_, new_n77_, new_n78_, new_n79_, new_n80_, new_n81_, new_n82_,
    new_n83_, new_n84_, new_n85_, new_n86_, new_n87_, new_n88_, new_n89_,
    new_n90_, new_n91_, new_n92_, new_n93_, new_n94_, new_n95_, new_n96_,
    new_n97_, new_n98_, new_n99_, new_n100_, new_n101_, new_n102_,
    new_n104_, new_n105_, new_n106_, new_n107_, new_n108_, new_n109_,
    new_n110_, new_n111_, new_n112_, new_n113_, new_n114_, new_n115_,
    new_n116_, new_n117_, new_n118_, new_n119_, new_n120_, new_n121_,
    new_n122_, new_n123_, new_n124_, new_n125_, new_n126_, new_n127_,
    new_n128_, new_n129_, new_n130_, new_n131_, new_n132_, new_n133_,
    new_n134_, new_n136_, new_n137_, new_n139_, new_n140_, new_n141_,
    new_n142_, new_n143_, new_n144_, new_n145_, new_n146_, new_n147_,
    new_n148_, new_n149_, new_n150_, new_n151_, new_n153_, new_n154_,
    new_n155_, new_n156_, new_n157_, new_n158_, new_n159_;
  INVx1_ASAP7_75t_R    g000(.A(p4), .Y(new_n19_));
  INVx1_ASAP7_75t_R    g001(.A(p10), .Y(new_n20_));
  NAND2x1_ASAP7_75t_R  g002(.A(p0), .B(p3), .Y(new_n21_));
  INVx1_ASAP7_75t_R    g003(.A(p5), .Y(new_n22_));
  INVx1_ASAP7_75t_R    g004(.A(p6), .Y(new_n23_));
  NAND2x1_ASAP7_75t_R  g005(.A(new_n22_), .B(new_n23_), .Y(new_n24_));
  AO21x1_ASAP7_75t_R   g006(.A1(new_n20_), .A2(new_n21_), .B(new_n24_), .Y(new_n25_));
  INVx1_ASAP7_75t_R    g007(.A(p3), .Y(new_n26_));
  NAND2x1_ASAP7_75t_R  g008(.A(p7), .B(new_n26_), .Y(new_n27_));
  AOI21x1_ASAP7_75t_R  g009(.A1(new_n21_), .A2(new_n27_), .B(new_n20_), .Y(new_n28_));
  INVx1_ASAP7_75t_R    g010(.A(p7), .Y(new_n29_));
  OAI22x1_ASAP7_75t_R  g011(.A1(new_n25_), .A2(new_n28_), .B1(new_n26_), .B2(new_n29_), .Y(new_n30_));
  NAND2x1_ASAP7_75t_R  g012(.A(p4), .B(p2), .Y(new_n31_));
  NOR2x1_ASAP7_75t_R   g013(.A(p6), .B(new_n31_), .Y(new_n32_));
  INVx1_ASAP7_75t_R    g014(.A(p0), .Y(new_n33_));
  NOR2x1_ASAP7_75t_R   g015(.A(p1), .B(new_n33_), .Y(new_n34_));
  INVx1_ASAP7_75t_R    g016(.A(p2), .Y(new_n35_));
  NAND2x1_ASAP7_75t_R  g017(.A(new_n26_), .B(new_n35_), .Y(new_n36_));
  AOI21x1_ASAP7_75t_R  g018(.A1(p3), .A2(p2), .B(new_n23_), .Y(new_n37_));
  AOI22x1_ASAP7_75t_R  g019(.A1(new_n32_), .A2(new_n34_), .B1(new_n36_), .B2(new_n37_), .Y(new_n38_));
  OAI22x1_ASAP7_75t_R  g020(.A1(new_n38_), .A2(p7), .B1(new_n19_), .B2(new_n27_), .Y(new_n39_));
  AOI21x1_ASAP7_75t_R  g021(.A1(new_n19_), .A2(new_n30_), .B(new_n39_), .Y(new_n40_));
  NOR2x1_ASAP7_75t_R   g022(.A(p9), .B(p8), .Y(new_n41_));
  INVx1_ASAP7_75t_R    g023(.A(new_n41_), .Y(new_n42_));
  INVx1_ASAP7_75t_R    g024(.A(p9), .Y(new_n43_));
  AOI211x1_ASAP7_75t_R g025(.A1(p6), .A2(new_n26_), .B(new_n33_), .C(p1), .Y(new_n44_));
  AO21x1_ASAP7_75t_R   g026(.A1(new_n35_), .A2(new_n29_), .B(new_n26_), .Y(new_n45_));
  NOR2x1_ASAP7_75t_R   g027(.A(p5), .B(new_n19_), .Y(new_n46_));
  NAND3x1_ASAP7_75t_R  g028(.A(new_n44_), .B(new_n45_), .C(new_n46_), .Y(new_n47_));
  NOR2x1_ASAP7_75t_R   g029(.A(p7), .B(p6), .Y(new_n48_));
  AO31x2_ASAP7_75t_R   g030(.A1(new_n48_), .A2(new_n33_), .A3(p1), .B(p8), .Y(new_n49_));
  AND3x1_ASAP7_75t_R   g031(.A(new_n19_), .B(p8), .C(p5), .Y(new_n50_));
  AOI21x1_ASAP7_75t_R  g032(.A1(new_n46_), .A2(new_n49_), .B(new_n50_), .Y(new_n51_));
  NAND2x1_ASAP7_75t_R  g033(.A(new_n47_), .B(new_n51_), .Y(new_n52_));
  NAND2x1_ASAP7_75t_R  g034(.A(p5), .B(new_n23_), .Y(new_n53_));
  NOR2x1_ASAP7_75t_R   g035(.A(p8), .B(p7), .Y(new_n54_));
  NOR2x1_ASAP7_75t_R   g036(.A(p1), .B(p2), .Y(new_n55_));
  AND2x2_ASAP7_75t_R   g037(.A(p1), .B(p2), .Y(new_n56_));
  NOR2x1_ASAP7_75t_R   g038(.A(new_n55_), .B(new_n56_), .Y(new_n57_));
  AOI21x1_ASAP7_75t_R  g039(.A1(new_n54_), .A2(new_n57_), .B(p9), .Y(new_n58_));
  NAND2x1_ASAP7_75t_R  g040(.A(p6), .B(new_n22_), .Y(new_n59_));
  INVx1_ASAP7_75t_R    g041(.A(p8), .Y(new_n60_));
  OR3x1_ASAP7_75t_R    g042(.A(new_n60_), .B(new_n29_), .C(new_n22_), .Y(new_n61_));
  AO21x1_ASAP7_75t_R   g043(.A1(new_n59_), .A2(new_n61_), .B(new_n43_), .Y(new_n62_));
  OAI21x1_ASAP7_75t_R  g044(.A1(new_n53_), .A2(new_n58_), .B(new_n62_), .Y(new_n63_));
  AOI21x1_ASAP7_75t_R  g045(.A1(new_n43_), .A2(new_n52_), .B(new_n63_), .Y(new_n64_));
  OAI21x1_ASAP7_75t_R  g046(.A1(new_n40_), .A2(new_n42_), .B(new_n64_), .Y(o0));
  NOR2x1_ASAP7_75t_R   g047(.A(p6), .B(new_n60_), .Y(new_n66_));
  AO21x1_ASAP7_75t_R   g048(.A1(new_n54_), .A2(new_n37_), .B(new_n66_), .Y(new_n67_));
  OAI21x1_ASAP7_75t_R  g049(.A1(p5), .A2(p6), .B(new_n26_), .Y(new_n68_));
  OAI21x1_ASAP7_75t_R  g050(.A1(p8), .A2(p7), .B(p3), .Y(new_n69_));
  AO21x1_ASAP7_75t_R   g051(.A1(p0), .A2(p1), .B(p6), .Y(new_n70_));
  AND5x1_ASAP7_75t_R   g052(.A(p4), .B(new_n68_), .C(p2), .D(new_n69_), .E(new_n70_), .Y(new_n71_));
  AOI21x1_ASAP7_75t_R  g053(.A1(new_n19_), .A2(new_n67_), .B(new_n71_), .Y(new_n72_));
  NOR2x1_ASAP7_75t_R   g054(.A(p8), .B(p3), .Y(new_n73_));
  INVx1_ASAP7_75t_R    g055(.A(new_n73_), .Y(new_n74_));
  NAND2x1_ASAP7_75t_R  g056(.A(p4), .B(p5), .Y(new_n75_));
  INVx1_ASAP7_75t_R    g057(.A(new_n75_), .Y(new_n76_));
  NAND2x1_ASAP7_75t_R  g058(.A(p8), .B(new_n23_), .Y(new_n77_));
  AND3x1_ASAP7_75t_R   g059(.A(new_n74_), .B(new_n76_), .C(new_n77_), .Y(new_n78_));
  AOI21x1_ASAP7_75t_R  g060(.A1(new_n77_), .A2(new_n74_), .B(p5), .Y(new_n79_));
  OAI22x1_ASAP7_75t_R  g061(.A1(new_n78_), .A2(new_n79_), .B1(p8), .B2(p7), .Y(new_n80_));
  OAI22x1_ASAP7_75t_R  g062(.A1(p8), .A2(p3), .B1(p1), .B2(p6), .Y(new_n81_));
  AO22x1_ASAP7_75t_R   g063(.A1(new_n60_), .A2(p7), .B1(new_n33_), .B2(new_n81_), .Y(new_n82_));
  NAND2x1_ASAP7_75t_R  g064(.A(p0), .B(p1), .Y(new_n83_));
  NAND2x1_ASAP7_75t_R  g065(.A(p3), .B(new_n23_), .Y(new_n84_));
  INVx1_ASAP7_75t_R    g066(.A(p1), .Y(new_n85_));
  NOR2x1_ASAP7_75t_R   g067(.A(p10), .B(new_n85_), .Y(new_n86_));
  AOI211x1_ASAP7_75t_R g068(.A1(p10), .A2(new_n83_), .B(new_n84_), .C(new_n86_), .Y(new_n87_));
  NOR2x1_ASAP7_75t_R   g069(.A(p4), .B(p5), .Y(new_n88_));
  OAI21x1_ASAP7_75t_R  g070(.A1(new_n82_), .A2(new_n87_), .B(new_n88_), .Y(new_n89_));
  NAND3x1_ASAP7_75t_R  g071(.A(new_n72_), .B(new_n80_), .C(new_n89_), .Y(new_n90_));
  AO21x1_ASAP7_75t_R   g072(.A1(p5), .A2(p6), .B(p7), .Y(new_n91_));
  NAND3x1_ASAP7_75t_R  g073(.A(new_n60_), .B(p3), .C(p5), .Y(new_n92_));
  AOI21x1_ASAP7_75t_R  g074(.A1(new_n56_), .A2(new_n92_), .B(p6), .Y(new_n93_));
  INVx1_ASAP7_75t_R    g075(.A(new_n83_), .Y(new_n94_));
  OR3x1_ASAP7_75t_R    g076(.A(new_n19_), .B(p2), .C(p5), .Y(new_n95_));
  AOI21x1_ASAP7_75t_R  g077(.A1(p5), .A2(new_n73_), .B(new_n56_), .Y(new_n96_));
  OAI21x1_ASAP7_75t_R  g078(.A1(new_n94_), .A2(new_n95_), .B(new_n96_), .Y(new_n97_));
  AOI21x1_ASAP7_75t_R  g079(.A1(new_n93_), .A2(new_n97_), .B(p9), .Y(new_n98_));
  AND2x2_ASAP7_75t_R   g080(.A(p5), .B(p6), .Y(new_n99_));
  AND3x1_ASAP7_75t_R   g081(.A(new_n99_), .B(p9), .C(p7), .Y(new_n100_));
  NAND2x1_ASAP7_75t_R  g082(.A(new_n60_), .B(new_n100_), .Y(new_n101_));
  OAI21x1_ASAP7_75t_R  g083(.A1(new_n91_), .A2(new_n98_), .B(new_n101_), .Y(new_n102_));
  AOI21x1_ASAP7_75t_R  g084(.A1(new_n43_), .A2(new_n90_), .B(new_n102_), .Y(o1));
  AND2x2_ASAP7_75t_R   g085(.A(p10), .B(p0), .Y(new_n104_));
  NAND2x1_ASAP7_75t_R  g086(.A(p3), .B(p2), .Y(new_n105_));
  OAI22x1_ASAP7_75t_R  g087(.A1(new_n104_), .A2(new_n105_), .B1(p3), .B2(p5), .Y(new_n106_));
  AND3x1_ASAP7_75t_R   g088(.A(new_n106_), .B(p1), .C(new_n19_), .Y(new_n107_));
  NAND2x1_ASAP7_75t_R  g089(.A(p10), .B(p3), .Y(new_n108_));
  OA21x2_ASAP7_75t_R   g090(.A1(p5), .A2(new_n108_), .B(new_n31_), .Y(new_n109_));
  AO21x1_ASAP7_75t_R   g091(.A1(p3), .A2(p2), .B(new_n83_), .Y(new_n110_));
  NAND2x1_ASAP7_75t_R  g092(.A(new_n85_), .B(new_n22_), .Y(new_n111_));
  NAND2x1_ASAP7_75t_R  g093(.A(p4), .B(p3), .Y(new_n112_));
  OA22x2_ASAP7_75t_R   g094(.A1(new_n111_), .A2(new_n105_), .B1(p2), .B2(new_n112_), .Y(new_n113_));
  OAI21x1_ASAP7_75t_R  g095(.A1(new_n109_), .A2(new_n110_), .B(new_n113_), .Y(new_n114_));
  AND3x1_ASAP7_75t_R   g096(.A(new_n41_), .B(new_n29_), .C(new_n23_), .Y(new_n115_));
  OAI21x1_ASAP7_75t_R  g097(.A1(new_n107_), .A2(new_n114_), .B(new_n115_), .Y(new_n116_));
  AND3x1_ASAP7_75t_R   g098(.A(p4), .B(p5), .C(p6), .Y(new_n117_));
  OR3x1_ASAP7_75t_R    g099(.A(new_n117_), .B(p9), .C(p7), .Y(new_n118_));
  NAND2x1_ASAP7_75t_R  g100(.A(p4), .B(p6), .Y(new_n119_));
  OR3x1_ASAP7_75t_R    g101(.A(new_n119_), .B(p9), .C(new_n29_), .Y(new_n120_));
  AND3x1_ASAP7_75t_R   g102(.A(new_n118_), .B(p8), .C(new_n120_), .Y(new_n121_));
  NOR2x1_ASAP7_75t_R   g103(.A(p9), .B(new_n29_), .Y(new_n122_));
  OAI21x1_ASAP7_75t_R  g104(.A1(new_n75_), .A2(new_n84_), .B(new_n59_), .Y(new_n123_));
  AO21x1_ASAP7_75t_R   g105(.A1(new_n122_), .A2(new_n123_), .B(new_n100_), .Y(new_n124_));
  NOR2x1_ASAP7_75t_R   g106(.A(new_n121_), .B(new_n124_), .Y(new_n125_));
  AND5x1_ASAP7_75t_R   g107(.A(p4), .B(new_n22_), .C(p3), .D(p2), .E(p6), .Y(new_n126_));
  AND5x1_ASAP7_75t_R   g108(.A(new_n85_), .B(new_n23_), .C(p4), .D(p3), .E(p5), .Y(new_n127_));
  AND3x1_ASAP7_75t_R   g109(.A(new_n112_), .B(p5), .C(p6), .Y(new_n128_));
  OR3x1_ASAP7_75t_R    g110(.A(new_n126_), .B(new_n127_), .C(new_n128_), .Y(new_n129_));
  OR3x1_ASAP7_75t_R    g111(.A(new_n85_), .B(new_n22_), .C(p4), .Y(new_n130_));
  AOI21x1_ASAP7_75t_R  g112(.A1(new_n33_), .A2(new_n46_), .B(new_n105_), .Y(new_n131_));
  AO21x1_ASAP7_75t_R   g113(.A1(new_n105_), .A2(new_n75_), .B(p7), .Y(new_n132_));
  AOI21x1_ASAP7_75t_R  g114(.A1(new_n130_), .A2(new_n131_), .B(new_n132_), .Y(new_n133_));
  OAI21x1_ASAP7_75t_R  g115(.A1(new_n129_), .A2(new_n133_), .B(new_n41_), .Y(new_n134_));
  NAND3x1_ASAP7_75t_R  g116(.A(new_n116_), .B(new_n125_), .C(new_n134_), .Y(o2));
  AND5x1_ASAP7_75t_R   g117(.A(new_n85_), .B(new_n117_), .C(p3), .D(p7), .E(new_n41_), .Y(new_n136_));
  AND3x1_ASAP7_75t_R   g118(.A(new_n115_), .B(new_n26_), .C(new_n88_), .Y(new_n137_));
  OAI21x1_ASAP7_75t_R  g119(.A1(new_n136_), .A2(new_n137_), .B(new_n35_), .Y(o3));
  AND3x1_ASAP7_75t_R   g120(.A(new_n88_), .B(p10), .C(p0), .Y(new_n139_));
  NOR2x1_ASAP7_75t_R   g121(.A(new_n112_), .B(new_n53_), .Y(new_n140_));
  AND3x1_ASAP7_75t_R   g122(.A(new_n29_), .B(p1), .C(p2), .Y(new_n141_));
  OAI21x1_ASAP7_75t_R  g123(.A1(new_n139_), .A2(new_n140_), .B(new_n141_), .Y(new_n142_));
  AO21x1_ASAP7_75t_R   g124(.A1(p2), .A2(new_n29_), .B(new_n55_), .Y(new_n143_));
  OR3x1_ASAP7_75t_R    g125(.A(new_n143_), .B(new_n92_), .C(new_n119_), .Y(new_n144_));
  AO21x1_ASAP7_75t_R   g126(.A1(p7), .A2(new_n117_), .B(new_n60_), .Y(new_n145_));
  NAND3x1_ASAP7_75t_R  g127(.A(new_n142_), .B(new_n144_), .C(new_n145_), .Y(new_n146_));
  NAND2x1_ASAP7_75t_R  g128(.A(new_n19_), .B(new_n23_), .Y(new_n147_));
  OR3x1_ASAP7_75t_R    g129(.A(new_n33_), .B(new_n85_), .C(p6), .Y(new_n148_));
  AO21x1_ASAP7_75t_R   g130(.A1(new_n75_), .A2(new_n148_), .B(new_n35_), .Y(new_n149_));
  AO21x1_ASAP7_75t_R   g131(.A1(new_n147_), .A2(new_n149_), .B(new_n26_), .Y(new_n150_));
  AND3x1_ASAP7_75t_R   g132(.A(new_n53_), .B(new_n43_), .C(new_n29_), .Y(new_n151_));
  AOI22x1_ASAP7_75t_R  g133(.A1(new_n146_), .A2(new_n43_), .B1(new_n150_), .B2(new_n151_), .Y(o4));
  INVx1_ASAP7_75t_R    g134(.A(new_n48_), .Y(new_n153_));
  AND5x1_ASAP7_75t_R   g135(.A(p1), .B(p4), .C(p3), .D(p2), .E(p5), .Y(new_n154_));
  NOR2x1_ASAP7_75t_R   g136(.A(new_n153_), .B(new_n154_), .Y(new_n155_));
  INVx1_ASAP7_75t_R    g137(.A(new_n88_), .Y(new_n156_));
  INVx1_ASAP7_75t_R    g138(.A(new_n55_), .Y(new_n157_));
  AND3x1_ASAP7_75t_R   g139(.A(new_n104_), .B(new_n19_), .C(new_n23_), .Y(new_n158_));
  AO32x1_ASAP7_75t_R   g140(.A1(p7), .A2(new_n157_), .A3(new_n117_), .B1(new_n158_), .B2(new_n141_), .Y(new_n159_));
  AO221x2_ASAP7_75t_R  g141(.A1(new_n155_), .A2(new_n156_), .B1(new_n159_), .B2(p3), .C(new_n42_), .Y(o5));
  OR3x1_ASAP7_75t_R    g142(.A(new_n154_), .B(new_n42_), .C(new_n153_), .Y(o6));
endmodule


