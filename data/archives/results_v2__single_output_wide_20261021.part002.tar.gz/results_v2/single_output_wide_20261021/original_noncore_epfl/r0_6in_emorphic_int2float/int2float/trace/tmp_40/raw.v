// Benchmark "/tmp/" written by ABC on Wed Oct 21 14:43:58 2026

module \/tmp/  ( 
    p2, p0, p9, p3, p6, p10, p4, p5, p8, p7, p1,
    o0, o1, o2, o3, o4, o5, o6  );
  input  p2, p0, p9, p3, p6, p10, p4, p5, p8, p7, p1;
  output o0, o1, o2, o3, o4, o5, o6;
  wire new_n19_, new_n20_, new_n21_, new_n22_, new_n23_, new_n24_, new_n25_,
    new_n26_, new_n27_, new_n28_, new_n29_, new_n30_, new_n31_, new_n32_,
    new_n33_, new_n34_, new_n35_, new_n36_, new_n37_, new_n38_, new_n39_,
    new_n40_, new_n41_, new_n42_, new_n43_, new_n44_, new_n45_, new_n46_,
    new_n47_, new_n48_, new_n49_, new_n50_, new_n51_, new_n52_, new_n53_,
    new_n54_, new_n55_, new_n56_, new_n57_, new_n58_, new_n59_, new_n60_,
    new_n61_, new_n62_, new_n63_, new_n64_, new_n66_, new_n67_, new_n68_,
    new_n69_, new_n70_, new_n71_, new_n72_, new_n73_, new_n74_, new_n75_,
    new_n76_, new_n77_, new_n78_, new_n79_, new_n80_, new_n81_, new_n82_,
    new_n83_, new_n84_, new_n85_, new_n86_, new_n87_, new_n88_, new_n89_,
    new_n90_, new_n91_, new_n92_, new_n93_, new_n94_, new_n95_, new_n96_,
    new_n97_, new_n98_, new_n99_, new_n100_, new_n101_, new_n102_,
    new_n104_, new_n105_, new_n106_, new_n107_, new_n108_, new_n109_,
    new_n110_, new_n111_, new_n112_, new_n113_, new_n114_, new_n115_,
    new_n116_, new_n117_, new_n118_, new_n119_, new_n120_, new_n121_,
    new_n122_, new_n123_, new_n124_, new_n125_, new_n126_, new_n127_,
    new_n128_, new_n129_, new_n130_, new_n131_, new_n132_, new_n133_,
    new_n135_, new_n136_, new_n137_, new_n138_, new_n139_, new_n141_,
    new_n142_, new_n143_, new_n144_, new_n145_, new_n146_, new_n147_,
    new_n148_, new_n149_, new_n150_, new_n151_, new_n152_, new_n153_,
    new_n154_, new_n156_, new_n157_, new_n158_, new_n159_;
  NOR2x1_ASAP7_75t_R   g000(.A(p9), .B(p8), .Y(new_n19_));
  INVx1_ASAP7_75t_R    g001(.A(new_n19_), .Y(new_n20_));
  INVx1_ASAP7_75t_R    g002(.A(p4), .Y(new_n21_));
  INVx1_ASAP7_75t_R    g003(.A(p10), .Y(new_n22_));
  NAND2x1_ASAP7_75t_R  g004(.A(p0), .B(p3), .Y(new_n23_));
  INVx1_ASAP7_75t_R    g005(.A(p6), .Y(new_n24_));
  INVx1_ASAP7_75t_R    g006(.A(p5), .Y(new_n25_));
  NAND2x1_ASAP7_75t_R  g007(.A(new_n24_), .B(new_n25_), .Y(new_n26_));
  AO21x1_ASAP7_75t_R   g008(.A1(new_n22_), .A2(new_n23_), .B(new_n26_), .Y(new_n27_));
  INVx1_ASAP7_75t_R    g009(.A(p3), .Y(new_n28_));
  NAND2x1_ASAP7_75t_R  g010(.A(p7), .B(new_n28_), .Y(new_n29_));
  AOI21x1_ASAP7_75t_R  g011(.A1(new_n23_), .A2(new_n29_), .B(new_n22_), .Y(new_n30_));
  INVx1_ASAP7_75t_R    g012(.A(p7), .Y(new_n31_));
  OAI22x1_ASAP7_75t_R  g013(.A1(new_n27_), .A2(new_n30_), .B1(new_n28_), .B2(new_n31_), .Y(new_n32_));
  INVx1_ASAP7_75t_R    g014(.A(p1), .Y(new_n33_));
  AND3x1_ASAP7_75t_R   g015(.A(new_n24_), .B(new_n33_), .C(p0), .Y(new_n34_));
  AND2x2_ASAP7_75t_R   g016(.A(p2), .B(p4), .Y(new_n35_));
  INVx1_ASAP7_75t_R    g017(.A(p2), .Y(new_n36_));
  NAND2x1_ASAP7_75t_R  g018(.A(new_n36_), .B(new_n28_), .Y(new_n37_));
  AOI21x1_ASAP7_75t_R  g019(.A1(p2), .A2(p3), .B(new_n24_), .Y(new_n38_));
  AOI22x1_ASAP7_75t_R  g020(.A1(new_n34_), .A2(new_n35_), .B1(new_n37_), .B2(new_n38_), .Y(new_n39_));
  OAI22x1_ASAP7_75t_R  g021(.A1(new_n39_), .A2(p7), .B1(new_n21_), .B2(new_n29_), .Y(new_n40_));
  AOI21x1_ASAP7_75t_R  g022(.A1(new_n21_), .A2(new_n32_), .B(new_n40_), .Y(new_n41_));
  INVx1_ASAP7_75t_R    g023(.A(p9), .Y(new_n42_));
  AO21x1_ASAP7_75t_R   g024(.A1(new_n36_), .A2(new_n31_), .B(new_n28_), .Y(new_n43_));
  INVx1_ASAP7_75t_R    g025(.A(p0), .Y(new_n44_));
  AOI211x1_ASAP7_75t_R g026(.A1(p6), .A2(new_n28_), .B(new_n44_), .C(p1), .Y(new_n45_));
  NAND2x1_ASAP7_75t_R  g027(.A(new_n43_), .B(new_n45_), .Y(new_n46_));
  NOR2x1_ASAP7_75t_R   g028(.A(p5), .B(new_n21_), .Y(new_n47_));
  INVx1_ASAP7_75t_R    g029(.A(new_n47_), .Y(new_n48_));
  NOR2x1_ASAP7_75t_R   g030(.A(p6), .B(p7), .Y(new_n49_));
  AO31x2_ASAP7_75t_R   g031(.A1(new_n49_), .A2(new_n44_), .A3(p1), .B(p8), .Y(new_n50_));
  AND3x1_ASAP7_75t_R   g032(.A(new_n21_), .B(p5), .C(p8), .Y(new_n51_));
  AOI21x1_ASAP7_75t_R  g033(.A1(new_n47_), .A2(new_n50_), .B(new_n51_), .Y(new_n52_));
  OAI21x1_ASAP7_75t_R  g034(.A1(new_n46_), .A2(new_n48_), .B(new_n52_), .Y(new_n53_));
  NAND2x1_ASAP7_75t_R  g035(.A(p5), .B(new_n24_), .Y(new_n54_));
  NOR2x1_ASAP7_75t_R   g036(.A(p2), .B(p1), .Y(new_n55_));
  NOR2x1_ASAP7_75t_R   g037(.A(p8), .B(p7), .Y(new_n56_));
  OAI21x1_ASAP7_75t_R  g038(.A1(new_n36_), .A2(new_n33_), .B(new_n56_), .Y(new_n57_));
  OA21x2_ASAP7_75t_R   g039(.A1(new_n55_), .A2(new_n57_), .B(new_n42_), .Y(new_n58_));
  NAND2x1_ASAP7_75t_R  g040(.A(p6), .B(new_n25_), .Y(new_n59_));
  INVx1_ASAP7_75t_R    g041(.A(p8), .Y(new_n60_));
  OR3x1_ASAP7_75t_R    g042(.A(new_n25_), .B(new_n60_), .C(new_n31_), .Y(new_n61_));
  AO21x1_ASAP7_75t_R   g043(.A1(new_n59_), .A2(new_n61_), .B(new_n42_), .Y(new_n62_));
  OAI21x1_ASAP7_75t_R  g044(.A1(new_n54_), .A2(new_n58_), .B(new_n62_), .Y(new_n63_));
  AOI21x1_ASAP7_75t_R  g045(.A1(new_n42_), .A2(new_n53_), .B(new_n63_), .Y(new_n64_));
  OAI21x1_ASAP7_75t_R  g046(.A1(new_n20_), .A2(new_n41_), .B(new_n64_), .Y(o0));
  NAND2x1_ASAP7_75t_R  g047(.A(p0), .B(p1), .Y(new_n66_));
  INVx1_ASAP7_75t_R    g048(.A(new_n66_), .Y(new_n67_));
  OA21x2_ASAP7_75t_R   g049(.A1(p6), .A2(new_n67_), .B(new_n35_), .Y(new_n68_));
  NOR2x1_ASAP7_75t_R   g050(.A(p3), .B(p5), .Y(new_n69_));
  AO32x1_ASAP7_75t_R   g051(.A1(p3), .A2(new_n60_), .A3(new_n31_), .B1(new_n69_), .B2(new_n24_), .Y(new_n70_));
  NOR2x1_ASAP7_75t_R   g052(.A(p6), .B(new_n60_), .Y(new_n71_));
  AO21x1_ASAP7_75t_R   g053(.A1(new_n56_), .A2(new_n38_), .B(new_n71_), .Y(new_n72_));
  AOI22x1_ASAP7_75t_R  g054(.A1(new_n68_), .A2(new_n70_), .B1(new_n72_), .B2(new_n21_), .Y(new_n73_));
  NAND2x1_ASAP7_75t_R  g055(.A(p4), .B(p5), .Y(new_n74_));
  INVx1_ASAP7_75t_R    g056(.A(new_n74_), .Y(new_n75_));
  NAND2x1_ASAP7_75t_R  g057(.A(new_n28_), .B(new_n60_), .Y(new_n76_));
  NAND2x1_ASAP7_75t_R  g058(.A(p8), .B(new_n24_), .Y(new_n77_));
  AND3x1_ASAP7_75t_R   g059(.A(new_n75_), .B(new_n76_), .C(new_n77_), .Y(new_n78_));
  AOI21x1_ASAP7_75t_R  g060(.A1(new_n77_), .A2(new_n76_), .B(p5), .Y(new_n79_));
  OAI22x1_ASAP7_75t_R  g061(.A1(new_n78_), .A2(new_n79_), .B1(p8), .B2(p7), .Y(new_n80_));
  OAI22x1_ASAP7_75t_R  g062(.A1(p3), .A2(p8), .B1(p6), .B2(p1), .Y(new_n81_));
  AO22x1_ASAP7_75t_R   g063(.A1(new_n60_), .A2(p7), .B1(new_n44_), .B2(new_n81_), .Y(new_n82_));
  NAND2x1_ASAP7_75t_R  g064(.A(p3), .B(new_n24_), .Y(new_n83_));
  NOR2x1_ASAP7_75t_R   g065(.A(p10), .B(new_n33_), .Y(new_n84_));
  AOI211x1_ASAP7_75t_R g066(.A1(p10), .A2(new_n66_), .B(new_n83_), .C(new_n84_), .Y(new_n85_));
  NOR2x1_ASAP7_75t_R   g067(.A(p4), .B(p5), .Y(new_n86_));
  OAI21x1_ASAP7_75t_R  g068(.A1(new_n82_), .A2(new_n85_), .B(new_n86_), .Y(new_n87_));
  NAND3x1_ASAP7_75t_R  g069(.A(new_n73_), .B(new_n80_), .C(new_n87_), .Y(new_n88_));
  AO21x1_ASAP7_75t_R   g070(.A1(p6), .A2(p5), .B(p7), .Y(new_n89_));
  AO21x1_ASAP7_75t_R   g071(.A1(new_n42_), .A2(p6), .B(new_n89_), .Y(new_n90_));
  NOR3x1_ASAP7_75t_R   g072(.A(new_n25_), .B(p3), .C(p8), .Y(new_n91_));
  NOR3x1_ASAP7_75t_R   g073(.A(new_n21_), .B(p0), .C(p5), .Y(new_n92_));
  OAI21x1_ASAP7_75t_R  g074(.A1(new_n91_), .A2(new_n92_), .B(new_n36_), .Y(new_n93_));
  NOR2x1_ASAP7_75t_R   g075(.A(p8), .B(new_n28_), .Y(new_n94_));
  AND3x1_ASAP7_75t_R   g076(.A(p2), .B(p5), .C(p1), .Y(new_n95_));
  AOI22x1_ASAP7_75t_R  g077(.A1(new_n55_), .A2(new_n47_), .B1(new_n94_), .B2(new_n95_), .Y(new_n96_));
  OR4x2_ASAP7_75t_R    g078(.A(new_n25_), .B(p3), .C(p8), .D(p1), .Y(new_n97_));
  AND4x2_ASAP7_75t_R   g079(.A(new_n93_), .B(new_n96_), .C(new_n42_), .D(new_n97_), .Y(new_n98_));
  AND2x2_ASAP7_75t_R   g080(.A(p6), .B(p5), .Y(new_n99_));
  AND3x1_ASAP7_75t_R   g081(.A(new_n99_), .B(p9), .C(p7), .Y(new_n100_));
  NAND2x1_ASAP7_75t_R  g082(.A(new_n60_), .B(new_n100_), .Y(new_n101_));
  OAI21x1_ASAP7_75t_R  g083(.A1(new_n90_), .A2(new_n98_), .B(new_n101_), .Y(new_n102_));
  AOI21x1_ASAP7_75t_R  g084(.A1(new_n42_), .A2(new_n88_), .B(new_n102_), .Y(o1));
  AND2x2_ASAP7_75t_R   g085(.A(p0), .B(p10), .Y(new_n104_));
  NAND2x1_ASAP7_75t_R  g086(.A(p2), .B(p3), .Y(new_n105_));
  OAI22x1_ASAP7_75t_R  g087(.A1(new_n104_), .A2(new_n105_), .B1(p3), .B2(p5), .Y(new_n106_));
  NOR2x1_ASAP7_75t_R   g088(.A(p4), .B(new_n33_), .Y(new_n107_));
  NAND2x1_ASAP7_75t_R  g089(.A(new_n25_), .B(new_n33_), .Y(new_n108_));
  NAND2x1_ASAP7_75t_R  g090(.A(p3), .B(p4), .Y(new_n109_));
  OAI22x1_ASAP7_75t_R  g091(.A1(new_n108_), .A2(new_n105_), .B1(p2), .B2(new_n109_), .Y(new_n110_));
  AOI21x1_ASAP7_75t_R  g092(.A1(new_n106_), .A2(new_n107_), .B(new_n110_), .Y(new_n111_));
  OR3x1_ASAP7_75t_R    g093(.A(new_n22_), .B(p2), .C(p5), .Y(new_n112_));
  OAI21x1_ASAP7_75t_R  g094(.A1(p3), .A2(new_n35_), .B(new_n67_), .Y(new_n113_));
  AO21x1_ASAP7_75t_R   g095(.A1(p3), .A2(new_n112_), .B(new_n113_), .Y(new_n114_));
  NAND2x1_ASAP7_75t_R  g096(.A(new_n19_), .B(new_n49_), .Y(new_n115_));
  AO21x1_ASAP7_75t_R   g097(.A1(new_n111_), .A2(new_n114_), .B(new_n115_), .Y(new_n116_));
  NAND2x1_ASAP7_75t_R  g098(.A(p4), .B(new_n99_), .Y(new_n117_));
  AND3x1_ASAP7_75t_R   g099(.A(new_n117_), .B(new_n42_), .C(new_n31_), .Y(new_n118_));
  AND2x2_ASAP7_75t_R   g100(.A(p6), .B(p4), .Y(new_n119_));
  NOR2x1_ASAP7_75t_R   g101(.A(p9), .B(new_n31_), .Y(new_n120_));
  AO21x1_ASAP7_75t_R   g102(.A1(new_n119_), .A2(new_n120_), .B(new_n60_), .Y(new_n121_));
  OAI21x1_ASAP7_75t_R  g103(.A1(new_n74_), .A2(new_n83_), .B(new_n59_), .Y(new_n122_));
  AOI21x1_ASAP7_75t_R  g104(.A1(new_n120_), .A2(new_n122_), .B(new_n100_), .Y(new_n123_));
  OA21x2_ASAP7_75t_R   g105(.A1(new_n118_), .A2(new_n121_), .B(new_n123_), .Y(new_n124_));
  AND5x1_ASAP7_75t_R   g106(.A(p3), .B(new_n24_), .C(new_n33_), .D(p4), .E(p5), .Y(new_n125_));
  AND5x1_ASAP7_75t_R   g107(.A(p2), .B(new_n25_), .C(p3), .D(p6), .E(p4), .Y(new_n126_));
  AND3x1_ASAP7_75t_R   g108(.A(new_n109_), .B(p6), .C(p5), .Y(new_n127_));
  OR3x1_ASAP7_75t_R    g109(.A(new_n125_), .B(new_n126_), .C(new_n127_), .Y(new_n128_));
  OR3x1_ASAP7_75t_R    g110(.A(new_n25_), .B(new_n33_), .C(p4), .Y(new_n129_));
  NOR2x1_ASAP7_75t_R   g111(.A(new_n105_), .B(new_n92_), .Y(new_n130_));
  AO21x1_ASAP7_75t_R   g112(.A1(new_n105_), .A2(new_n74_), .B(p7), .Y(new_n131_));
  AOI21x1_ASAP7_75t_R  g113(.A1(new_n129_), .A2(new_n130_), .B(new_n131_), .Y(new_n132_));
  OAI21x1_ASAP7_75t_R  g114(.A1(new_n128_), .A2(new_n132_), .B(new_n19_), .Y(new_n133_));
  NAND3x1_ASAP7_75t_R  g115(.A(new_n116_), .B(new_n124_), .C(new_n133_), .Y(o2));
  OR3x1_ASAP7_75t_R    g116(.A(new_n28_), .B(new_n31_), .C(p1), .Y(new_n135_));
  INVx1_ASAP7_75t_R    g117(.A(new_n49_), .Y(new_n136_));
  INVx1_ASAP7_75t_R    g118(.A(new_n86_), .Y(new_n137_));
  OR3x1_ASAP7_75t_R    g119(.A(new_n136_), .B(new_n137_), .C(p3), .Y(new_n138_));
  OA21x2_ASAP7_75t_R   g120(.A1(new_n117_), .A2(new_n135_), .B(new_n138_), .Y(new_n139_));
  OR3x1_ASAP7_75t_R    g121(.A(new_n139_), .B(p2), .C(new_n20_), .Y(o3));
  AND3x1_ASAP7_75t_R   g122(.A(new_n86_), .B(p0), .C(p10), .Y(new_n141_));
  NOR2x1_ASAP7_75t_R   g123(.A(new_n109_), .B(new_n54_), .Y(new_n142_));
  AND3x1_ASAP7_75t_R   g124(.A(new_n31_), .B(p2), .C(p1), .Y(new_n143_));
  OA21x2_ASAP7_75t_R   g125(.A1(new_n141_), .A2(new_n142_), .B(new_n143_), .Y(new_n144_));
  AND3x1_ASAP7_75t_R   g126(.A(new_n119_), .B(p5), .C(p7), .Y(new_n145_));
  NOR2x1_ASAP7_75t_R   g127(.A(new_n60_), .B(new_n145_), .Y(new_n146_));
  INVx1_ASAP7_75t_R    g128(.A(new_n55_), .Y(new_n147_));
  NAND2x1_ASAP7_75t_R  g129(.A(p2), .B(new_n31_), .Y(new_n148_));
  AND5x1_ASAP7_75t_R   g130(.A(p4), .B(new_n147_), .C(new_n94_), .D(new_n148_), .E(new_n99_), .Y(new_n149_));
  OR3x1_ASAP7_75t_R    g131(.A(new_n144_), .B(new_n146_), .C(new_n149_), .Y(new_n150_));
  OR3x1_ASAP7_75t_R    g132(.A(new_n44_), .B(new_n33_), .C(p6), .Y(new_n151_));
  AO21x1_ASAP7_75t_R   g133(.A1(new_n74_), .A2(new_n151_), .B(new_n105_), .Y(new_n152_));
  OR3x1_ASAP7_75t_R    g134(.A(new_n28_), .B(p6), .C(p4), .Y(new_n153_));
  AND5x1_ASAP7_75t_R   g135(.A(new_n42_), .B(new_n152_), .C(new_n31_), .D(new_n54_), .E(new_n153_), .Y(new_n154_));
  AOI21x1_ASAP7_75t_R  g136(.A1(new_n42_), .A2(new_n150_), .B(new_n154_), .Y(o4));
  AND5x1_ASAP7_75t_R   g137(.A(p2), .B(p3), .C(p4), .D(p5), .E(p1), .Y(new_n156_));
  NOR2x1_ASAP7_75t_R   g138(.A(new_n136_), .B(new_n156_), .Y(new_n157_));
  NOR2x1_ASAP7_75t_R   g139(.A(p6), .B(p4), .Y(new_n158_));
  AO32x1_ASAP7_75t_R   g140(.A1(new_n104_), .A2(new_n143_), .A3(new_n158_), .B1(new_n145_), .B2(new_n147_), .Y(new_n159_));
  AO221x2_ASAP7_75t_R  g141(.A1(new_n137_), .A2(new_n157_), .B1(new_n159_), .B2(p3), .C(new_n20_), .Y(o5));
  OR3x1_ASAP7_75t_R    g142(.A(new_n156_), .B(new_n136_), .C(new_n20_), .Y(o6));
endmodule


