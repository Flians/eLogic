// Benchmark "/tmp/" written by ABC on Wed Oct 21 14:43:53 2026

module \/tmp/  ( 
    p10, p2, p3, p9, p1, p6, p7, p5, p8, p4, p0,
    o0, o1, o2, o3, o4, o5, o6  );
  input  p10, p2, p3, p9, p1, p6, p7, p5, p8, p4, p0;
  output o0, o1, o2, o3, o4, o5, o6;
  wire new_n19_, new_n20_, new_n21_, new_n22_, new_n23_, new_n24_, new_n25_,
    new_n26_, new_n27_, new_n28_, new_n29_, new_n30_, new_n31_, new_n32_,
    new_n33_, new_n34_, new_n35_, new_n36_, new_n37_, new_n38_, new_n39_,
    new_n40_, new_n41_, new_n42_, new_n43_, new_n44_, new_n45_, new_n46_,
    new_n47_, new_n48_, new_n49_, new_n50_, new_n51_, new_n52_, new_n53_,
    new_n54_, new_n55_, new_n56_, new_n57_, new_n58_, new_n59_, new_n60_,
    new_n61_, new_n62_, new_n63_, new_n65_, new_n66_, new_n67_, new_n68_,
    new_n69_, new_n70_, new_n71_, new_n72_, new_n73_, new_n74_, new_n75_,
    new_n76_, new_n77_, new_n78_, new_n79_, new_n80_, new_n81_, new_n82_,
    new_n83_, new_n84_, new_n85_, new_n86_, new_n87_, new_n88_, new_n89_,
    new_n90_, new_n91_, new_n92_, new_n93_, new_n94_, new_n95_, new_n96_,
    new_n98_, new_n99_, new_n100_, new_n101_, new_n102_, new_n103_,
    new_n104_, new_n105_, new_n106_, new_n107_, new_n108_, new_n109_,
    new_n110_, new_n111_, new_n112_, new_n113_, new_n114_, new_n115_,
    new_n116_, new_n117_, new_n118_, new_n119_, new_n120_, new_n121_,
    new_n122_, new_n123_, new_n124_, new_n125_, new_n126_, new_n127_,
    new_n129_, new_n130_, new_n131_, new_n133_, new_n134_, new_n135_,
    new_n136_, new_n137_, new_n138_, new_n139_, new_n140_, new_n141_,
    new_n142_, new_n143_, new_n145_, new_n146_, new_n147_, new_n148_,
    new_n149_, new_n151_;
  NOR2x1_ASAP7_75t_R   g000(.A(p9), .B(p8), .Y(new_n19_));
  INVx1_ASAP7_75t_R    g001(.A(new_n19_), .Y(new_n20_));
  INVx1_ASAP7_75t_R    g002(.A(p4), .Y(new_n21_));
  INVx1_ASAP7_75t_R    g003(.A(p10), .Y(new_n22_));
  NAND2x1_ASAP7_75t_R  g004(.A(p3), .B(p0), .Y(new_n23_));
  AOI211x1_ASAP7_75t_R g005(.A1(new_n22_), .A2(new_n23_), .B(p6), .C(p5), .Y(new_n24_));
  INVx1_ASAP7_75t_R    g006(.A(p3), .Y(new_n25_));
  NAND2x1_ASAP7_75t_R  g007(.A(p7), .B(new_n25_), .Y(new_n26_));
  AO21x1_ASAP7_75t_R   g008(.A1(new_n23_), .A2(new_n26_), .B(new_n22_), .Y(new_n27_));
  AND2x2_ASAP7_75t_R   g009(.A(p3), .B(p7), .Y(new_n28_));
  AO21x1_ASAP7_75t_R   g010(.A1(new_n24_), .A2(new_n27_), .B(new_n28_), .Y(new_n29_));
  NOR2x1_ASAP7_75t_R   g011(.A(p1), .B(p6), .Y(new_n30_));
  AND3x1_ASAP7_75t_R   g012(.A(p2), .B(p4), .C(p0), .Y(new_n31_));
  INVx1_ASAP7_75t_R    g013(.A(p6), .Y(new_n32_));
  NOR2x1_ASAP7_75t_R   g014(.A(p3), .B(new_n32_), .Y(new_n33_));
  INVx1_ASAP7_75t_R    g015(.A(p2), .Y(new_n34_));
  AND3x1_ASAP7_75t_R   g016(.A(new_n34_), .B(p3), .C(p6), .Y(new_n35_));
  AOI221x1_ASAP7_75t_R g017(.A1(new_n30_), .A2(new_n31_), .B1(p2), .B2(new_n33_), .C(new_n35_), .Y(new_n36_));
  OAI22x1_ASAP7_75t_R  g018(.A1(new_n36_), .A2(p7), .B1(new_n21_), .B2(new_n26_), .Y(new_n37_));
  AOI21x1_ASAP7_75t_R  g019(.A1(new_n21_), .A2(new_n29_), .B(new_n37_), .Y(new_n38_));
  NOR2x1_ASAP7_75t_R   g020(.A(p5), .B(new_n21_), .Y(new_n39_));
  INVx1_ASAP7_75t_R    g021(.A(new_n39_), .Y(new_n40_));
  INVx1_ASAP7_75t_R    g022(.A(p0), .Y(new_n41_));
  AND2x2_ASAP7_75t_R   g023(.A(p2), .B(p3), .Y(new_n42_));
  OR5x1_ASAP7_75t_R    g024(.A(p1), .B(new_n33_), .C(new_n41_), .D(new_n28_), .E(new_n42_), .Y(new_n43_));
  NOR2x1_ASAP7_75t_R   g025(.A(p6), .B(p7), .Y(new_n44_));
  AO31x2_ASAP7_75t_R   g026(.A1(new_n44_), .A2(p1), .A3(new_n41_), .B(p8), .Y(new_n45_));
  AND2x2_ASAP7_75t_R   g027(.A(p5), .B(p8), .Y(new_n46_));
  AOI22x1_ASAP7_75t_R  g028(.A1(new_n45_), .A2(new_n39_), .B1(new_n21_), .B2(new_n46_), .Y(new_n47_));
  OAI21x1_ASAP7_75t_R  g029(.A1(new_n40_), .A2(new_n43_), .B(new_n47_), .Y(new_n48_));
  INVx1_ASAP7_75t_R    g030(.A(p9), .Y(new_n49_));
  INVx1_ASAP7_75t_R    g031(.A(p1), .Y(new_n50_));
  NAND2x1_ASAP7_75t_R  g032(.A(new_n34_), .B(new_n50_), .Y(new_n51_));
  NAND2x1_ASAP7_75t_R  g033(.A(p2), .B(p1), .Y(new_n52_));
  INVx1_ASAP7_75t_R    g034(.A(p7), .Y(new_n53_));
  INVx1_ASAP7_75t_R    g035(.A(p8), .Y(new_n54_));
  AND3x1_ASAP7_75t_R   g036(.A(new_n52_), .B(new_n53_), .C(new_n54_), .Y(new_n55_));
  AO21x1_ASAP7_75t_R   g037(.A1(new_n51_), .A2(new_n55_), .B(p9), .Y(new_n56_));
  NAND2x1_ASAP7_75t_R  g038(.A(p5), .B(new_n32_), .Y(new_n57_));
  INVx1_ASAP7_75t_R    g039(.A(p5), .Y(new_n58_));
  NAND2x1_ASAP7_75t_R  g040(.A(p6), .B(new_n58_), .Y(new_n59_));
  NAND2x1_ASAP7_75t_R  g041(.A(p7), .B(new_n46_), .Y(new_n60_));
  AO21x1_ASAP7_75t_R   g042(.A1(new_n59_), .A2(new_n60_), .B(new_n49_), .Y(new_n61_));
  NAND2x1_ASAP7_75t_R  g043(.A(new_n57_), .B(new_n61_), .Y(new_n62_));
  AOI22x1_ASAP7_75t_R  g044(.A1(new_n48_), .A2(new_n49_), .B1(new_n56_), .B2(new_n62_), .Y(new_n63_));
  OAI21x1_ASAP7_75t_R  g045(.A1(new_n20_), .A2(new_n38_), .B(new_n63_), .Y(o0));
  NOR2x1_ASAP7_75t_R   g046(.A(p3), .B(p8), .Y(new_n65_));
  NOR2x1_ASAP7_75t_R   g047(.A(new_n30_), .B(new_n65_), .Y(new_n66_));
  OAI22x1_ASAP7_75t_R  g048(.A1(new_n66_), .A2(p0), .B1(new_n53_), .B2(p8), .Y(new_n67_));
  NAND2x1_ASAP7_75t_R  g049(.A(p1), .B(p0), .Y(new_n68_));
  AO21x1_ASAP7_75t_R   g050(.A1(p1), .A2(new_n22_), .B(p6), .Y(new_n69_));
  AOI211x1_ASAP7_75t_R g051(.A1(p10), .A2(new_n68_), .B(new_n25_), .C(new_n69_), .Y(new_n70_));
  NOR2x1_ASAP7_75t_R   g052(.A(p5), .B(p4), .Y(new_n71_));
  OAI21x1_ASAP7_75t_R  g053(.A1(new_n67_), .A2(new_n70_), .B(new_n71_), .Y(new_n72_));
  NAND2x1_ASAP7_75t_R  g054(.A(new_n53_), .B(new_n54_), .Y(new_n73_));
  NAND2x1_ASAP7_75t_R  g055(.A(p2), .B(p3), .Y(new_n74_));
  NAND2x1_ASAP7_75t_R  g056(.A(p6), .B(new_n74_), .Y(new_n75_));
  NAND2x1_ASAP7_75t_R  g057(.A(p8), .B(new_n32_), .Y(new_n76_));
  OAI21x1_ASAP7_75t_R  g058(.A1(new_n73_), .A2(new_n75_), .B(new_n76_), .Y(new_n77_));
  OAI21x1_ASAP7_75t_R  g059(.A1(p6), .A2(p5), .B(new_n25_), .Y(new_n78_));
  OAI21x1_ASAP7_75t_R  g060(.A1(p7), .A2(p8), .B(p3), .Y(new_n79_));
  AO21x1_ASAP7_75t_R   g061(.A1(p1), .A2(p0), .B(p6), .Y(new_n80_));
  AND5x1_ASAP7_75t_R   g062(.A(p2), .B(new_n78_), .C(p4), .D(new_n79_), .E(new_n80_), .Y(new_n81_));
  AOI21x1_ASAP7_75t_R  g063(.A1(new_n21_), .A2(new_n77_), .B(new_n81_), .Y(new_n82_));
  INVx1_ASAP7_75t_R    g064(.A(new_n65_), .Y(new_n83_));
  AOI21x1_ASAP7_75t_R  g065(.A1(new_n76_), .A2(new_n83_), .B(p5), .Y(new_n84_));
  AND2x2_ASAP7_75t_R   g066(.A(p5), .B(p4), .Y(new_n85_));
  AND3x1_ASAP7_75t_R   g067(.A(new_n83_), .B(new_n76_), .C(new_n85_), .Y(new_n86_));
  OAI21x1_ASAP7_75t_R  g068(.A1(new_n84_), .A2(new_n86_), .B(new_n73_), .Y(new_n87_));
  NAND3x1_ASAP7_75t_R  g069(.A(new_n72_), .B(new_n82_), .C(new_n87_), .Y(new_n88_));
  NAND3x1_ASAP7_75t_R  g070(.A(new_n39_), .B(new_n34_), .C(new_n68_), .Y(new_n89_));
  OR4x2_ASAP7_75t_R    g071(.A(new_n52_), .B(new_n25_), .C(new_n58_), .D(p8), .Y(new_n90_));
  NAND3x1_ASAP7_75t_R  g072(.A(new_n65_), .B(new_n52_), .C(p5), .Y(new_n91_));
  AND4x2_ASAP7_75t_R   g073(.A(new_n89_), .B(new_n90_), .C(new_n49_), .D(new_n91_), .Y(new_n92_));
  AO21x1_ASAP7_75t_R   g074(.A1(p6), .A2(p5), .B(p7), .Y(new_n93_));
  AO21x1_ASAP7_75t_R   g075(.A1(new_n49_), .A2(p6), .B(new_n93_), .Y(new_n94_));
  OR4x2_ASAP7_75t_R    g076(.A(new_n49_), .B(new_n32_), .C(new_n53_), .D(new_n58_), .Y(new_n95_));
  OAI22x1_ASAP7_75t_R  g077(.A1(new_n92_), .A2(new_n94_), .B1(p8), .B2(new_n95_), .Y(new_n96_));
  AOI21x1_ASAP7_75t_R  g078(.A1(new_n49_), .A2(new_n88_), .B(new_n96_), .Y(o1));
  AND2x2_ASAP7_75t_R   g079(.A(p3), .B(p4), .Y(new_n98_));
  AO32x1_ASAP7_75t_R   g080(.A1(new_n42_), .A2(new_n50_), .A3(new_n58_), .B1(new_n98_), .B2(new_n34_), .Y(new_n99_));
  OAI21x1_ASAP7_75t_R  g081(.A1(p1), .A2(new_n99_), .B(new_n44_), .Y(new_n100_));
  AND2x2_ASAP7_75t_R   g082(.A(p10), .B(p0), .Y(new_n101_));
  OAI22x1_ASAP7_75t_R  g083(.A1(new_n101_), .A2(new_n74_), .B1(p3), .B2(p5), .Y(new_n102_));
  NAND2x1_ASAP7_75t_R  g084(.A(p3), .B(new_n34_), .Y(new_n103_));
  NAND2x1_ASAP7_75t_R  g085(.A(p10), .B(new_n58_), .Y(new_n104_));
  NAND3x1_ASAP7_75t_R  g086(.A(new_n25_), .B(p2), .C(p4), .Y(new_n105_));
  OAI21x1_ASAP7_75t_R  g087(.A1(new_n103_), .A2(new_n104_), .B(new_n105_), .Y(new_n106_));
  AOI221x1_ASAP7_75t_R g088(.A1(new_n21_), .A2(new_n102_), .B1(new_n106_), .B2(p0), .C(new_n99_), .Y(new_n107_));
  AO21x1_ASAP7_75t_R   g089(.A1(p6), .A2(p5), .B(new_n98_), .Y(new_n108_));
  OAI21x1_ASAP7_75t_R  g090(.A1(new_n34_), .A2(new_n59_), .B(new_n98_), .Y(new_n109_));
  NAND3x1_ASAP7_75t_R  g091(.A(new_n58_), .B(new_n41_), .C(p4), .Y(new_n110_));
  NAND3x1_ASAP7_75t_R  g092(.A(new_n21_), .B(p1), .C(p5), .Y(new_n111_));
  NAND3x1_ASAP7_75t_R  g093(.A(new_n110_), .B(new_n111_), .C(new_n42_), .Y(new_n112_));
  OA21x2_ASAP7_75t_R   g094(.A1(new_n42_), .A2(new_n85_), .B(new_n53_), .Y(new_n113_));
  AND3x1_ASAP7_75t_R   g095(.A(new_n98_), .B(p5), .C(new_n30_), .Y(new_n114_));
  AOI221x1_ASAP7_75t_R g096(.A1(new_n108_), .A2(new_n109_), .B1(new_n112_), .B2(new_n113_), .C(new_n114_), .Y(new_n115_));
  OAI21x1_ASAP7_75t_R  g097(.A1(new_n100_), .A2(new_n107_), .B(new_n115_), .Y(new_n116_));
  AND2x2_ASAP7_75t_R   g098(.A(p6), .B(p4), .Y(new_n117_));
  NOR2x1_ASAP7_75t_R   g099(.A(p9), .B(new_n53_), .Y(new_n118_));
  AND3x1_ASAP7_75t_R   g100(.A(p6), .B(p5), .C(p4), .Y(new_n119_));
  INVx1_ASAP7_75t_R    g101(.A(new_n119_), .Y(new_n120_));
  NOR2x1_ASAP7_75t_R   g102(.A(p9), .B(p7), .Y(new_n121_));
  AO221x2_ASAP7_75t_R  g103(.A1(new_n117_), .A2(new_n118_), .B1(new_n120_), .B2(new_n121_), .C(new_n54_), .Y(new_n122_));
  INVx1_ASAP7_75t_R    g104(.A(new_n59_), .Y(new_n123_));
  NAND2x1_ASAP7_75t_R  g105(.A(p3), .B(p4), .Y(new_n124_));
  NOR2x1_ASAP7_75t_R   g106(.A(new_n124_), .B(new_n57_), .Y(new_n125_));
  OAI21x1_ASAP7_75t_R  g107(.A1(new_n123_), .A2(new_n125_), .B(new_n118_), .Y(new_n126_));
  NAND3x1_ASAP7_75t_R  g108(.A(new_n122_), .B(new_n95_), .C(new_n126_), .Y(new_n127_));
  AO21x1_ASAP7_75t_R   g109(.A1(new_n19_), .A2(new_n116_), .B(new_n127_), .Y(o2));
  AND3x1_ASAP7_75t_R   g110(.A(new_n44_), .B(new_n71_), .C(new_n25_), .Y(new_n129_));
  AND3x1_ASAP7_75t_R   g111(.A(new_n119_), .B(new_n28_), .C(new_n50_), .Y(new_n130_));
  NOR2x1_ASAP7_75t_R   g112(.A(new_n129_), .B(new_n130_), .Y(new_n131_));
  OR3x1_ASAP7_75t_R    g113(.A(new_n131_), .B(p2), .C(new_n20_), .Y(o3));
  AND3x1_ASAP7_75t_R   g114(.A(new_n71_), .B(p10), .C(p0), .Y(new_n133_));
  AND3x1_ASAP7_75t_R   g115(.A(new_n53_), .B(p2), .C(p1), .Y(new_n134_));
  OA21x2_ASAP7_75t_R   g116(.A1(new_n133_), .A2(new_n125_), .B(new_n134_), .Y(new_n135_));
  OA21x2_ASAP7_75t_R   g117(.A1(new_n53_), .A2(new_n120_), .B(p8), .Y(new_n136_));
  NAND2x1_ASAP7_75t_R  g118(.A(p2), .B(new_n53_), .Y(new_n137_));
  AND5x1_ASAP7_75t_R   g119(.A(p3), .B(new_n51_), .C(new_n137_), .D(new_n54_), .E(new_n119_), .Y(new_n138_));
  OR3x1_ASAP7_75t_R    g120(.A(new_n135_), .B(new_n136_), .C(new_n138_), .Y(new_n139_));
  NOR2x1_ASAP7_75t_R   g121(.A(p6), .B(new_n68_), .Y(new_n140_));
  OAI21x1_ASAP7_75t_R  g122(.A1(new_n85_), .A2(new_n140_), .B(new_n42_), .Y(new_n141_));
  OR3x1_ASAP7_75t_R    g123(.A(new_n25_), .B(p6), .C(p4), .Y(new_n142_));
  AND3x1_ASAP7_75t_R   g124(.A(new_n141_), .B(new_n57_), .C(new_n142_), .Y(new_n143_));
  AOI22x1_ASAP7_75t_R  g125(.A1(new_n139_), .A2(new_n49_), .B1(new_n121_), .B2(new_n143_), .Y(o4));
  OR3x1_ASAP7_75t_R    g126(.A(new_n52_), .B(new_n124_), .C(new_n58_), .Y(new_n145_));
  INVx1_ASAP7_75t_R    g127(.A(new_n44_), .Y(new_n146_));
  NOR2x1_ASAP7_75t_R   g128(.A(new_n71_), .B(new_n146_), .Y(new_n147_));
  AND3x1_ASAP7_75t_R   g129(.A(new_n101_), .B(new_n32_), .C(new_n21_), .Y(new_n148_));
  AO32x1_ASAP7_75t_R   g130(.A1(p7), .A2(new_n51_), .A3(new_n119_), .B1(new_n148_), .B2(new_n134_), .Y(new_n149_));
  AO221x2_ASAP7_75t_R  g131(.A1(new_n145_), .A2(new_n147_), .B1(new_n149_), .B2(p3), .C(new_n20_), .Y(o5));
  INVx1_ASAP7_75t_R    g132(.A(new_n145_), .Y(new_n151_));
  OR3x1_ASAP7_75t_R    g133(.A(new_n151_), .B(new_n20_), .C(new_n146_), .Y(o6));
endmodule


