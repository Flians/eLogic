// Benchmark "/tmp/" written by ABC on Wed Oct 21 14:30:11 2026

module \/tmp/  ( 
    p4, p3, p2, p6, p5, p0, p1,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25  );
  input  p4, p3, p2, p6, p5, p0, p1;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25;
  wire new_n34_, new_n35_, new_n36_, new_n37_, new_n38_, new_n39_, new_n41_,
    new_n43_, new_n44_, new_n45_, new_n46_, new_n47_, new_n48_, new_n49_,
    new_n51_, new_n52_, new_n53_, new_n54_, new_n56_, new_n57_, new_n59_,
    new_n60_, new_n61_, new_n62_, new_n63_, new_n64_, new_n65_, new_n66_,
    new_n67_, new_n68_, new_n70_, new_n71_, new_n73_, new_n74_, new_n75_,
    new_n77_, new_n78_, new_n79_, new_n81_, new_n84_, new_n85_, new_n86_,
    new_n89_, new_n90_, new_n91_, new_n99_, new_n100_, new_n101_,
    new_n102_, new_n104_, new_n105_, new_n106_;
  INVx1_ASAP7_75t_R    g00(.A(p6), .Y(new_n34_));
  NOR2x1_ASAP7_75t_R   g01(.A(p0), .B(p1), .Y(new_n35_));
  NAND2x1_ASAP7_75t_R  g02(.A(p3), .B(p2), .Y(new_n36_));
  AO21x1_ASAP7_75t_R   g03(.A1(new_n34_), .A2(new_n35_), .B(new_n36_), .Y(new_n37_));
  INVx1_ASAP7_75t_R    g04(.A(p3), .Y(new_n38_));
  INVx1_ASAP7_75t_R    g05(.A(p2), .Y(new_n39_));
  AND3x1_ASAP7_75t_R   g06(.A(new_n38_), .B(new_n39_), .C(p1), .Y(o19));
  NAND2x1_ASAP7_75t_R  g07(.A(p0), .B(o19), .Y(new_n41_));
  NAND2x1_ASAP7_75t_R  g08(.A(new_n37_), .B(new_n41_), .Y(o0));
  INVx1_ASAP7_75t_R    g09(.A(p0), .Y(new_n43_));
  NOR2x1_ASAP7_75t_R   g10(.A(p1), .B(new_n43_), .Y(new_n44_));
  NAND2x1_ASAP7_75t_R  g11(.A(p3), .B(new_n39_), .Y(new_n45_));
  AND2x2_ASAP7_75t_R   g12(.A(p3), .B(p2), .Y(new_n46_));
  INVx1_ASAP7_75t_R    g13(.A(p1), .Y(new_n47_));
  NOR2x1_ASAP7_75t_R   g14(.A(p3), .B(p2), .Y(new_n48_));
  OAI22x1_ASAP7_75t_R  g15(.A1(new_n46_), .A2(p0), .B1(new_n47_), .B2(new_n48_), .Y(new_n49_));
  AOI221x1_ASAP7_75t_R g16(.A1(p6), .A2(new_n35_), .B1(new_n44_), .B2(new_n45_), .C(new_n49_), .Y(o1));
  INVx1_ASAP7_75t_R    g17(.A(new_n44_), .Y(new_n51_));
  OR3x1_ASAP7_75t_R    g18(.A(new_n36_), .B(p6), .C(p1), .Y(new_n52_));
  OR3x1_ASAP7_75t_R    g19(.A(new_n38_), .B(p2), .C(p6), .Y(new_n53_));
  OA21x2_ASAP7_75t_R   g20(.A1(p3), .A2(new_n39_), .B(p0), .Y(new_n54_));
  AOI22x1_ASAP7_75t_R  g21(.A1(new_n51_), .A2(new_n52_), .B1(new_n53_), .B2(new_n54_), .Y(o2));
  AND2x2_ASAP7_75t_R   g22(.A(p2), .B(p6), .Y(new_n56_));
  NOR2x1_ASAP7_75t_R   g23(.A(new_n39_), .B(new_n35_), .Y(new_n57_));
  AOI211x1_ASAP7_75t_R g24(.A1(p3), .A2(new_n56_), .B(new_n48_), .C(new_n57_), .Y(o3));
  AND3x1_ASAP7_75t_R   g25(.A(p2), .B(p6), .C(p0), .Y(new_n59_));
  INVx1_ASAP7_75t_R    g26(.A(p4), .Y(new_n60_));
  INVx1_ASAP7_75t_R    g27(.A(p5), .Y(new_n61_));
  OAI21x1_ASAP7_75t_R  g28(.A1(new_n60_), .A2(new_n61_), .B(p3), .Y(new_n62_));
  NAND2x1_ASAP7_75t_R  g29(.A(new_n59_), .B(new_n62_), .Y(new_n63_));
  AND3x1_ASAP7_75t_R   g30(.A(p4), .B(p3), .C(p2), .Y(new_n64_));
  NOR2x1_ASAP7_75t_R   g31(.A(p6), .B(new_n43_), .Y(new_n65_));
  AOI21x1_ASAP7_75t_R  g32(.A1(new_n64_), .A2(new_n65_), .B(p1), .Y(new_n66_));
  NOR2x1_ASAP7_75t_R   g33(.A(p2), .B(new_n38_), .Y(new_n67_));
  AOI21x1_ASAP7_75t_R  g34(.A1(p6), .A2(new_n67_), .B(new_n47_), .Y(new_n68_));
  AOI21x1_ASAP7_75t_R  g35(.A1(new_n63_), .A2(new_n66_), .B(new_n68_), .Y(o4));
  OA21x2_ASAP7_75t_R   g36(.A1(new_n39_), .A2(new_n61_), .B(new_n47_), .Y(new_n70_));
  NAND2x1_ASAP7_75t_R  g37(.A(p2), .B(new_n38_), .Y(new_n71_));
  AOI221x1_ASAP7_75t_R g38(.A1(p1), .A2(new_n45_), .B1(new_n70_), .B2(new_n71_), .C(new_n43_), .Y(o5));
  NAND2x1_ASAP7_75t_R  g39(.A(p6), .B(p0), .Y(new_n73_));
  NAND2x1_ASAP7_75t_R  g40(.A(new_n73_), .B(new_n46_), .Y(new_n74_));
  NOR2x1_ASAP7_75t_R   g41(.A(p1), .B(new_n48_), .Y(new_n75_));
  OA22x2_ASAP7_75t_R   g42(.A1(new_n74_), .A2(p1), .B1(new_n46_), .B2(new_n75_), .Y(o6));
  NOR2x1_ASAP7_75t_R   g43(.A(p6), .B(p0), .Y(new_n77_));
  AND2x2_ASAP7_75t_R   g44(.A(p6), .B(p1), .Y(new_n78_));
  AOI21x1_ASAP7_75t_R  g45(.A1(new_n47_), .A2(new_n77_), .B(new_n78_), .Y(new_n79_));
  OAI21x1_ASAP7_75t_R  g46(.A1(new_n36_), .A2(new_n79_), .B(new_n41_), .Y(o7));
  NOR2x1_ASAP7_75t_R   g47(.A(new_n47_), .B(new_n48_), .Y(new_n81_));
  AOI221x1_ASAP7_75t_R g48(.A1(new_n36_), .A2(new_n81_), .B1(new_n53_), .B2(new_n47_), .C(new_n43_), .Y(o8));
  AOI21x1_ASAP7_75t_R  g49(.A1(new_n44_), .A2(new_n53_), .B(new_n49_), .Y(o9));
  NOR2x1_ASAP7_75t_R   g50(.A(new_n47_), .B(new_n67_), .Y(new_n84_));
  NOR2x1_ASAP7_75t_R   g51(.A(p2), .B(p1), .Y(new_n85_));
  AO21x1_ASAP7_75t_R   g52(.A1(p3), .A2(new_n35_), .B(new_n85_), .Y(new_n86_));
  OAI22x1_ASAP7_75t_R  g53(.A1(new_n84_), .A2(new_n86_), .B1(new_n45_), .B2(new_n65_), .Y(o10));
  AND3x1_ASAP7_75t_R   g54(.A(new_n77_), .B(new_n85_), .C(new_n38_), .Y(o11));
  NOR2x1_ASAP7_75t_R   g55(.A(p3), .B(p0), .Y(new_n89_));
  INVx1_ASAP7_75t_R    g56(.A(new_n89_), .Y(new_n90_));
  OR3x1_ASAP7_75t_R    g57(.A(p2), .B(p6), .C(p0), .Y(new_n91_));
  AO32x1_ASAP7_75t_R   g58(.A1(p1), .A2(new_n71_), .A3(new_n90_), .B1(new_n75_), .B2(new_n91_), .Y(o12));
  AND3x1_ASAP7_75t_R   g59(.A(new_n48_), .B(p6), .C(p1), .Y(o13));
  AND3x1_ASAP7_75t_R   g60(.A(new_n48_), .B(new_n34_), .C(p1), .Y(o14));
  AND5x1_ASAP7_75t_R   g61(.A(new_n38_), .B(new_n34_), .C(new_n43_), .D(p2), .E(p1), .Y(o15));
  AND3x1_ASAP7_75t_R   g62(.A(new_n78_), .B(p2), .C(new_n89_), .Y(o16));
  AND5x1_ASAP7_75t_R   g63(.A(new_n38_), .B(p2), .C(p6), .D(p0), .E(p1), .Y(o17));
  AND5x1_ASAP7_75t_R   g64(.A(new_n38_), .B(new_n34_), .C(p2), .D(p0), .E(p1), .Y(o18));
  OAI21x1_ASAP7_75t_R  g65(.A1(p4), .A2(new_n38_), .B(new_n59_), .Y(new_n99_));
  AOI21x1_ASAP7_75t_R  g66(.A1(new_n89_), .A2(new_n56_), .B(p1), .Y(new_n100_));
  AND2x2_ASAP7_75t_R   g67(.A(p6), .B(p0), .Y(new_n101_));
  OA21x2_ASAP7_75t_R   g68(.A1(new_n36_), .A2(new_n101_), .B(p1), .Y(new_n102_));
  AOI21x1_ASAP7_75t_R  g69(.A1(new_n99_), .A2(new_n100_), .B(new_n102_), .Y(o20));
  NAND2x1_ASAP7_75t_R  g70(.A(p2), .B(new_n89_), .Y(new_n104_));
  OR4x2_ASAP7_75t_R    g71(.A(new_n36_), .B(new_n60_), .C(p5), .D(new_n43_), .Y(new_n105_));
  NAND2x1_ASAP7_75t_R  g72(.A(p6), .B(new_n47_), .Y(new_n106_));
  AOI21x1_ASAP7_75t_R  g73(.A1(new_n104_), .A2(new_n105_), .B(new_n106_), .Y(o21));
  AOI21x1_ASAP7_75t_R  g74(.A1(new_n47_), .A2(new_n63_), .B(new_n102_), .Y(o22));
  assign               o23 = 1'b1;
  OA211x2_ASAP7_75t_R  g75(.A1(new_n77_), .A2(new_n101_), .B(p3), .C(new_n85_), .Y(o24));
  AND3x1_ASAP7_75t_R   g76(.A(new_n67_), .B(p6), .C(new_n35_), .Y(o25));
endmodule


