// Benchmark "/tmp/" written by ABC on Wed Oct 21 14:30:20 2026

module \/tmp/  ( 
    p3, p6, p0, p1, p5, p4, p2,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25  );
  input  p3, p6, p0, p1, p5, p4, p2;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25;
  wire new_n34_, new_n35_, new_n36_, new_n37_, new_n39_, new_n40_, new_n41_,
    new_n42_, new_n43_, new_n44_, new_n45_, new_n46_, new_n47_, new_n49_,
    new_n50_, new_n52_, new_n54_, new_n55_, new_n56_, new_n57_, new_n58_,
    new_n59_, new_n60_, new_n61_, new_n63_, new_n64_, new_n65_, new_n66_,
    new_n68_, new_n69_, new_n70_, new_n72_, new_n73_, new_n75_, new_n78_,
    new_n79_, new_n80_, new_n83_, new_n84_, new_n85_, new_n86_, new_n92_,
    new_n96_, new_n97_, new_n99_, new_n101_;
  OR3x1_ASAP7_75t_R    g00(.A(p6), .B(p0), .C(p1), .Y(new_n34_));
  AND2x2_ASAP7_75t_R   g01(.A(p3), .B(p2), .Y(new_n35_));
  NOR2x1_ASAP7_75t_R   g02(.A(p3), .B(p2), .Y(new_n36_));
  AND3x1_ASAP7_75t_R   g03(.A(new_n36_), .B(p0), .C(p1), .Y(new_n37_));
  AO21x1_ASAP7_75t_R   g04(.A1(new_n34_), .A2(new_n35_), .B(new_n37_), .Y(o0));
  INVx1_ASAP7_75t_R    g05(.A(p0), .Y(new_n39_));
  NOR2x1_ASAP7_75t_R   g06(.A(p1), .B(new_n39_), .Y(new_n40_));
  INVx1_ASAP7_75t_R    g07(.A(p2), .Y(new_n41_));
  NAND2x1_ASAP7_75t_R  g08(.A(p3), .B(new_n41_), .Y(new_n42_));
  INVx1_ASAP7_75t_R    g09(.A(p3), .Y(new_n43_));
  OR3x1_ASAP7_75t_R    g10(.A(new_n43_), .B(new_n41_), .C(p6), .Y(new_n44_));
  NOR2x1_ASAP7_75t_R   g11(.A(p0), .B(p1), .Y(new_n45_));
  INVx1_ASAP7_75t_R    g12(.A(p1), .Y(new_n46_));
  AOI21x1_ASAP7_75t_R  g13(.A1(p0), .A2(new_n36_), .B(new_n46_), .Y(new_n47_));
  AOI221x1_ASAP7_75t_R g14(.A1(new_n40_), .A2(new_n42_), .B1(new_n44_), .B2(new_n45_), .C(new_n47_), .Y(o1));
  OA21x2_ASAP7_75t_R   g15(.A1(p3), .A2(new_n41_), .B(p0), .Y(new_n49_));
  OR3x1_ASAP7_75t_R    g16(.A(new_n43_), .B(p6), .C(p2), .Y(new_n50_));
  AOI221x1_ASAP7_75t_R g17(.A1(new_n49_), .A2(new_n50_), .B1(new_n39_), .B2(new_n44_), .C(p1), .Y(o2));
  NAND2x1_ASAP7_75t_R  g18(.A(p2), .B(new_n45_), .Y(new_n52_));
  AOI22x1_ASAP7_75t_R  g19(.A1(new_n52_), .A2(new_n42_), .B1(p6), .B2(new_n35_), .Y(o3));
  AND2x2_ASAP7_75t_R   g20(.A(p5), .B(p4), .Y(new_n54_));
  AND3x1_ASAP7_75t_R   g21(.A(p6), .B(p0), .C(p2), .Y(new_n55_));
  OAI21x1_ASAP7_75t_R  g22(.A1(new_n43_), .A2(new_n54_), .B(new_n55_), .Y(new_n56_));
  NAND2x1_ASAP7_75t_R  g23(.A(p3), .B(p2), .Y(new_n57_));
  NAND2x1_ASAP7_75t_R  g24(.A(p0), .B(p4), .Y(new_n58_));
  OA31x2_ASAP7_75t_R   g25(.A1(p6), .A2(new_n57_), .A3(new_n58_), .B1(new_n46_), .Y(new_n59_));
  NAND2x1_ASAP7_75t_R  g26(.A(p3), .B(p6), .Y(new_n60_));
  OA21x2_ASAP7_75t_R   g27(.A1(p2), .A2(new_n60_), .B(p1), .Y(new_n61_));
  AOI21x1_ASAP7_75t_R  g28(.A1(new_n56_), .A2(new_n59_), .B(new_n61_), .Y(o4));
  INVx1_ASAP7_75t_R    g29(.A(p5), .Y(new_n63_));
  AO21x1_ASAP7_75t_R   g30(.A1(p3), .A2(new_n63_), .B(new_n41_), .Y(new_n64_));
  NOR2x1_ASAP7_75t_R   g31(.A(p2), .B(new_n43_), .Y(new_n65_));
  NOR2x1_ASAP7_75t_R   g32(.A(new_n46_), .B(new_n65_), .Y(new_n66_));
  AOI211x1_ASAP7_75t_R g33(.A1(new_n46_), .A2(new_n64_), .B(new_n39_), .C(new_n66_), .Y(o5));
  NAND2x1_ASAP7_75t_R  g34(.A(p6), .B(p0), .Y(new_n68_));
  AND3x1_ASAP7_75t_R   g35(.A(new_n35_), .B(new_n46_), .C(new_n68_), .Y(new_n69_));
  AOI21x1_ASAP7_75t_R  g36(.A1(p3), .A2(p2), .B(new_n46_), .Y(new_n70_));
  NOR3x1_ASAP7_75t_R   g37(.A(new_n69_), .B(new_n36_), .C(new_n70_), .Y(o6));
  INVx1_ASAP7_75t_R    g38(.A(p6), .Y(new_n72_));
  OAI21x1_ASAP7_75t_R  g39(.A1(new_n72_), .A2(new_n46_), .B(new_n34_), .Y(new_n73_));
  AO21x1_ASAP7_75t_R   g40(.A1(new_n35_), .A2(new_n73_), .B(new_n37_), .Y(o7));
  INVx1_ASAP7_75t_R    g41(.A(new_n36_), .Y(new_n75_));
  AOI221x1_ASAP7_75t_R g42(.A1(new_n75_), .A2(new_n70_), .B1(new_n50_), .B2(new_n46_), .C(new_n39_), .Y(o8));
  AOI221x1_ASAP7_75t_R g43(.A1(new_n39_), .A2(new_n57_), .B1(new_n50_), .B2(new_n40_), .C(new_n47_), .Y(o9));
  NOR2x1_ASAP7_75t_R   g44(.A(p1), .B(p2), .Y(new_n78_));
  AO21x1_ASAP7_75t_R   g45(.A1(p3), .A2(new_n45_), .B(new_n78_), .Y(new_n79_));
  NOR2x1_ASAP7_75t_R   g46(.A(p6), .B(new_n39_), .Y(new_n80_));
  OAI22x1_ASAP7_75t_R  g47(.A1(new_n66_), .A2(new_n79_), .B1(new_n42_), .B2(new_n80_), .Y(o10));
  AND3x1_ASAP7_75t_R   g48(.A(new_n36_), .B(new_n45_), .C(new_n72_), .Y(o11));
  NOR2x1_ASAP7_75t_R   g49(.A(p3), .B(p0), .Y(new_n83_));
  AND3x1_ASAP7_75t_R   g50(.A(new_n43_), .B(p1), .C(p2), .Y(new_n84_));
  NOR2x1_ASAP7_75t_R   g51(.A(p6), .B(p0), .Y(new_n85_));
  OA21x2_ASAP7_75t_R   g52(.A1(new_n43_), .A2(new_n85_), .B(new_n78_), .Y(new_n86_));
  AOI211x1_ASAP7_75t_R g53(.A1(p1), .A2(new_n83_), .B(new_n84_), .C(new_n86_), .Y(o12));
  AND3x1_ASAP7_75t_R   g54(.A(new_n36_), .B(p6), .C(p1), .Y(o13));
  AND3x1_ASAP7_75t_R   g55(.A(new_n36_), .B(new_n72_), .C(p1), .Y(o14));
  AND2x2_ASAP7_75t_R   g56(.A(new_n85_), .B(new_n84_), .Y(o15));
  AND3x1_ASAP7_75t_R   g57(.A(new_n84_), .B(p6), .C(new_n39_), .Y(o16));
  AND2x2_ASAP7_75t_R   g58(.A(p6), .B(p0), .Y(new_n92_));
  AND2x2_ASAP7_75t_R   g59(.A(new_n92_), .B(new_n84_), .Y(o17));
  AND2x2_ASAP7_75t_R   g60(.A(new_n80_), .B(new_n84_), .Y(o18));
  AND3x1_ASAP7_75t_R   g61(.A(new_n43_), .B(new_n41_), .C(p1), .Y(o19));
  AND3x1_ASAP7_75t_R   g62(.A(new_n46_), .B(p6), .C(p2), .Y(new_n96_));
  NAND2x1_ASAP7_75t_R  g63(.A(p3), .B(new_n58_), .Y(new_n97_));
  AO32x1_ASAP7_75t_R   g64(.A1(p1), .A2(new_n35_), .A3(new_n68_), .B1(new_n96_), .B2(new_n97_), .Y(o20));
  AO21x1_ASAP7_75t_R   g65(.A1(p3), .A2(new_n63_), .B(new_n83_), .Y(new_n99_));
  AND3x1_ASAP7_75t_R   g66(.A(new_n99_), .B(new_n97_), .C(new_n96_), .Y(o21));
  OR3x1_ASAP7_75t_R    g67(.A(new_n92_), .B(new_n46_), .C(new_n57_), .Y(new_n101_));
  OAI21x1_ASAP7_75t_R  g68(.A1(p1), .A2(new_n56_), .B(new_n101_), .Y(o22));
  assign               o23 = 1'b1;
  OA211x2_ASAP7_75t_R  g69(.A1(new_n85_), .A2(new_n92_), .B(p3), .C(new_n78_), .Y(o24));
  AND5x1_ASAP7_75t_R   g70(.A(p3), .B(new_n39_), .C(new_n46_), .D(new_n41_), .E(p6), .Y(o25));
endmodule


