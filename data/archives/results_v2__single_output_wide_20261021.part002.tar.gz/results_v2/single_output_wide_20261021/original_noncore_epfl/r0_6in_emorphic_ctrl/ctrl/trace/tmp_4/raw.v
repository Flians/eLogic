// Benchmark "/tmp/" written by ABC on Wed Oct 21 14:30:11 2026

module \/tmp/  ( 
    p4, p6, p1, p3, p2, p5, p0,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25  );
  input  p4, p6, p1, p3, p2, p5, p0;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25;
  wire new_n34_, new_n35_, new_n36_, new_n37_, new_n38_, new_n39_, new_n40_,
    new_n42_, new_n43_, new_n44_, new_n45_, new_n46_, new_n47_, new_n48_,
    new_n49_, new_n51_, new_n52_, new_n53_, new_n54_, new_n56_, new_n57_,
    new_n59_, new_n60_, new_n61_, new_n62_, new_n63_, new_n64_, new_n65_,
    new_n66_, new_n68_, new_n69_, new_n70_, new_n71_, new_n73_, new_n74_,
    new_n75_, new_n77_, new_n78_, new_n80_, new_n82_, new_n84_, new_n85_,
    new_n86_, new_n89_, new_n90_, new_n91_, new_n95_, new_n97_, new_n99_,
    new_n103_, new_n104_, new_n105_, new_n107_, new_n111_;
  INVx1_ASAP7_75t_R    g00(.A(p6), .Y(new_n34_));
  NOR2x1_ASAP7_75t_R   g01(.A(p1), .B(p0), .Y(new_n35_));
  NAND2x1_ASAP7_75t_R  g02(.A(p3), .B(p2), .Y(new_n36_));
  AO21x1_ASAP7_75t_R   g03(.A1(new_n34_), .A2(new_n35_), .B(new_n36_), .Y(new_n37_));
  INVx1_ASAP7_75t_R    g04(.A(p1), .Y(new_n38_));
  INVx1_ASAP7_75t_R    g05(.A(p0), .Y(new_n39_));
  OR4x2_ASAP7_75t_R    g06(.A(new_n38_), .B(new_n39_), .C(p3), .D(p2), .Y(new_n40_));
  NAND2x1_ASAP7_75t_R  g07(.A(new_n37_), .B(new_n40_), .Y(o0));
  INVx1_ASAP7_75t_R    g08(.A(p3), .Y(new_n42_));
  INVx1_ASAP7_75t_R    g09(.A(p2), .Y(new_n43_));
  OR3x1_ASAP7_75t_R    g10(.A(new_n42_), .B(new_n43_), .C(p6), .Y(new_n44_));
  NOR2x1_ASAP7_75t_R   g11(.A(p3), .B(p2), .Y(new_n45_));
  AOI21x1_ASAP7_75t_R  g12(.A1(p0), .A2(new_n45_), .B(new_n38_), .Y(new_n46_));
  NAND2x1_ASAP7_75t_R  g13(.A(p0), .B(new_n38_), .Y(new_n47_));
  NOR2x1_ASAP7_75t_R   g14(.A(p2), .B(new_n42_), .Y(new_n48_));
  NOR2x1_ASAP7_75t_R   g15(.A(new_n47_), .B(new_n48_), .Y(new_n49_));
  AOI211x1_ASAP7_75t_R g16(.A1(new_n35_), .A2(new_n44_), .B(new_n46_), .C(new_n49_), .Y(o1));
  NOR2x1_ASAP7_75t_R   g17(.A(p3), .B(new_n43_), .Y(new_n51_));
  NOR2x1_ASAP7_75t_R   g18(.A(new_n39_), .B(new_n51_), .Y(new_n52_));
  OR3x1_ASAP7_75t_R    g19(.A(new_n42_), .B(p6), .C(p2), .Y(new_n53_));
  OR3x1_ASAP7_75t_R    g20(.A(new_n36_), .B(p6), .C(p1), .Y(new_n54_));
  AOI22x1_ASAP7_75t_R  g21(.A1(new_n52_), .A2(new_n53_), .B1(new_n47_), .B2(new_n54_), .Y(o2));
  NAND2x1_ASAP7_75t_R  g22(.A(p6), .B(p3), .Y(new_n56_));
  AND3x1_ASAP7_75t_R   g23(.A(new_n56_), .B(new_n38_), .C(new_n39_), .Y(new_n57_));
  AO21x1_ASAP7_75t_R   g24(.A1(p2), .A2(new_n57_), .B(new_n48_), .Y(o3));
  NAND2x1_ASAP7_75t_R  g25(.A(p4), .B(p0), .Y(new_n59_));
  OA31x2_ASAP7_75t_R   g26(.A1(p6), .A2(new_n36_), .A3(new_n59_), .B1(new_n38_), .Y(new_n60_));
  AND3x1_ASAP7_75t_R   g27(.A(p6), .B(p2), .C(p0), .Y(new_n61_));
  INVx1_ASAP7_75t_R    g28(.A(p4), .Y(new_n62_));
  INVx1_ASAP7_75t_R    g29(.A(p5), .Y(new_n63_));
  OAI21x1_ASAP7_75t_R  g30(.A1(new_n62_), .A2(new_n63_), .B(p3), .Y(new_n64_));
  NAND2x1_ASAP7_75t_R  g31(.A(new_n61_), .B(new_n64_), .Y(new_n65_));
  OA21x2_ASAP7_75t_R   g32(.A1(p2), .A2(new_n56_), .B(p1), .Y(new_n66_));
  AOI21x1_ASAP7_75t_R  g33(.A1(new_n60_), .A2(new_n65_), .B(new_n66_), .Y(o4));
  AOI21x1_ASAP7_75t_R  g34(.A1(p2), .A2(p5), .B(p1), .Y(new_n68_));
  NAND2x1_ASAP7_75t_R  g35(.A(p2), .B(new_n42_), .Y(new_n69_));
  NAND2x1_ASAP7_75t_R  g36(.A(new_n68_), .B(new_n69_), .Y(new_n70_));
  AO21x1_ASAP7_75t_R   g37(.A1(p3), .A2(new_n43_), .B(new_n38_), .Y(new_n71_));
  AND3x1_ASAP7_75t_R   g38(.A(new_n70_), .B(p0), .C(new_n71_), .Y(o5));
  AO21x1_ASAP7_75t_R   g39(.A1(p6), .A2(p0), .B(p1), .Y(new_n73_));
  NAND2x1_ASAP7_75t_R  g40(.A(p1), .B(new_n36_), .Y(new_n74_));
  INVx1_ASAP7_75t_R    g41(.A(new_n45_), .Y(new_n75_));
  OA211x2_ASAP7_75t_R  g42(.A1(new_n36_), .A2(new_n73_), .B(new_n74_), .C(new_n75_), .Y(o6));
  OR5x1_ASAP7_75t_R    g43(.A(p6), .B(new_n42_), .C(new_n43_), .D(p1), .E(p0), .Y(new_n77_));
  OR3x1_ASAP7_75t_R    g44(.A(new_n36_), .B(new_n34_), .C(new_n38_), .Y(new_n78_));
  NAND3x1_ASAP7_75t_R  g45(.A(new_n77_), .B(new_n40_), .C(new_n78_), .Y(o7));
  AND2x2_ASAP7_75t_R   g46(.A(p1), .B(new_n36_), .Y(new_n80_));
  AOI221x1_ASAP7_75t_R g47(.A1(new_n53_), .A2(new_n38_), .B1(new_n80_), .B2(new_n75_), .C(new_n39_), .Y(o8));
  INVx1_ASAP7_75t_R    g48(.A(new_n47_), .Y(new_n82_));
  AOI221x1_ASAP7_75t_R g49(.A1(new_n39_), .A2(new_n36_), .B1(new_n82_), .B2(new_n53_), .C(new_n46_), .Y(o9));
  NAND2x1_ASAP7_75t_R  g50(.A(p3), .B(new_n35_), .Y(new_n84_));
  NAND2x1_ASAP7_75t_R  g51(.A(new_n38_), .B(new_n43_), .Y(new_n85_));
  NAND2x1_ASAP7_75t_R  g52(.A(p0), .B(new_n34_), .Y(new_n86_));
  AO32x1_ASAP7_75t_R   g53(.A1(new_n71_), .A2(new_n84_), .A3(new_n85_), .B1(new_n48_), .B2(new_n86_), .Y(o10));
  AND3x1_ASAP7_75t_R   g54(.A(new_n35_), .B(new_n45_), .C(new_n34_), .Y(o11));
  OR3x1_ASAP7_75t_R    g55(.A(p6), .B(p2), .C(p0), .Y(new_n89_));
  NOR2x1_ASAP7_75t_R   g56(.A(p3), .B(p0), .Y(new_n90_));
  NOR2x1_ASAP7_75t_R   g57(.A(new_n38_), .B(new_n90_), .Y(new_n91_));
  AO32x1_ASAP7_75t_R   g58(.A1(new_n38_), .A2(new_n75_), .A3(new_n89_), .B1(new_n91_), .B2(new_n69_), .Y(o12));
  AND3x1_ASAP7_75t_R   g59(.A(new_n45_), .B(p6), .C(p1), .Y(o13));
  AND3x1_ASAP7_75t_R   g60(.A(new_n45_), .B(new_n34_), .C(p1), .Y(o14));
  NOR2x1_ASAP7_75t_R   g61(.A(p6), .B(p0), .Y(new_n95_));
  AND3x1_ASAP7_75t_R   g62(.A(new_n51_), .B(p1), .C(new_n95_), .Y(o15));
  AND2x2_ASAP7_75t_R   g63(.A(p6), .B(p2), .Y(new_n97_));
  AND3x1_ASAP7_75t_R   g64(.A(new_n97_), .B(p1), .C(new_n90_), .Y(o16));
  AND2x2_ASAP7_75t_R   g65(.A(p6), .B(p0), .Y(new_n99_));
  AND3x1_ASAP7_75t_R   g66(.A(new_n51_), .B(p1), .C(new_n99_), .Y(o17));
  AND5x1_ASAP7_75t_R   g67(.A(new_n34_), .B(new_n42_), .C(p1), .D(p2), .E(p0), .Y(o18));
  AND3x1_ASAP7_75t_R   g68(.A(new_n42_), .B(new_n43_), .C(p1), .Y(o19));
  OAI21x1_ASAP7_75t_R  g69(.A1(p4), .A2(new_n42_), .B(new_n61_), .Y(new_n103_));
  AOI21x1_ASAP7_75t_R  g70(.A1(new_n90_), .A2(new_n97_), .B(p1), .Y(new_n104_));
  OA21x2_ASAP7_75t_R   g71(.A1(new_n36_), .A2(new_n99_), .B(p1), .Y(new_n105_));
  AOI21x1_ASAP7_75t_R  g72(.A1(new_n103_), .A2(new_n104_), .B(new_n105_), .Y(o20));
  NOR3x1_ASAP7_75t_R   g73(.A(new_n59_), .B(new_n42_), .C(p5), .Y(new_n107_));
  OA211x2_ASAP7_75t_R  g74(.A1(new_n90_), .A2(new_n107_), .B(new_n38_), .C(new_n97_), .Y(o21));
  AOI21x1_ASAP7_75t_R  g75(.A1(new_n38_), .A2(new_n65_), .B(new_n105_), .Y(o22));
  assign               o23 = 1'b1;
  AND3x1_ASAP7_75t_R   g76(.A(new_n38_), .B(new_n43_), .C(p3), .Y(new_n111_));
  OA21x2_ASAP7_75t_R   g77(.A1(new_n95_), .A2(new_n99_), .B(new_n111_), .Y(o24));
  AND3x1_ASAP7_75t_R   g78(.A(new_n48_), .B(p6), .C(new_n35_), .Y(o25));
endmodule


