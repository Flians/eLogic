// Benchmark "/tmp/" written by ABC on Wed Oct 21 14:30:11 2026

module \/tmp/  ( 
    p5, p2, p6, p3, p0, p1, p4,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25  );
  input  p5, p2, p6, p3, p0, p1, p4;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25;
  wire new_n34_, new_n35_, new_n36_, new_n37_, new_n38_, new_n39_, new_n41_,
    new_n42_, new_n43_, new_n44_, new_n45_, new_n46_, new_n47_, new_n48_,
    new_n49_, new_n51_, new_n52_, new_n54_, new_n55_, new_n57_, new_n58_,
    new_n59_, new_n60_, new_n61_, new_n62_, new_n63_, new_n64_, new_n66_,
    new_n67_, new_n69_, new_n70_, new_n71_, new_n73_, new_n74_, new_n77_,
    new_n79_, new_n80_, new_n81_, new_n84_, new_n85_, new_n86_, new_n87_,
    new_n91_, new_n93_, new_n98_, new_n99_, new_n100_, new_n102_,
    new_n103_;
  INVx1_ASAP7_75t_R    g00(.A(p1), .Y(new_n34_));
  NOR2x1_ASAP7_75t_R   g01(.A(p6), .B(p0), .Y(new_n35_));
  NAND2x1_ASAP7_75t_R  g02(.A(p2), .B(p3), .Y(new_n36_));
  AO21x1_ASAP7_75t_R   g03(.A1(new_n34_), .A2(new_n35_), .B(new_n36_), .Y(new_n37_));
  INVx1_ASAP7_75t_R    g04(.A(p0), .Y(new_n38_));
  OR4x2_ASAP7_75t_R    g05(.A(new_n38_), .B(new_n34_), .C(p2), .D(p3), .Y(new_n39_));
  NAND2x1_ASAP7_75t_R  g06(.A(new_n37_), .B(new_n39_), .Y(o0));
  NOR2x1_ASAP7_75t_R   g07(.A(p0), .B(p1), .Y(new_n41_));
  INVx1_ASAP7_75t_R    g08(.A(p2), .Y(new_n42_));
  INVx1_ASAP7_75t_R    g09(.A(p3), .Y(new_n43_));
  OR3x1_ASAP7_75t_R    g10(.A(new_n42_), .B(new_n43_), .C(p6), .Y(new_n44_));
  NOR2x1_ASAP7_75t_R   g11(.A(p2), .B(p3), .Y(new_n45_));
  AOI21x1_ASAP7_75t_R  g12(.A1(p0), .A2(new_n45_), .B(new_n34_), .Y(new_n46_));
  NAND2x1_ASAP7_75t_R  g13(.A(p0), .B(new_n34_), .Y(new_n47_));
  NOR2x1_ASAP7_75t_R   g14(.A(p2), .B(new_n43_), .Y(new_n48_));
  NOR2x1_ASAP7_75t_R   g15(.A(new_n47_), .B(new_n48_), .Y(new_n49_));
  AOI211x1_ASAP7_75t_R g16(.A1(new_n41_), .A2(new_n44_), .B(new_n46_), .C(new_n49_), .Y(o1));
  OA21x2_ASAP7_75t_R   g17(.A1(p3), .A2(new_n42_), .B(p0), .Y(new_n51_));
  OR3x1_ASAP7_75t_R    g18(.A(new_n43_), .B(p2), .C(p6), .Y(new_n52_));
  AOI221x1_ASAP7_75t_R g19(.A1(new_n51_), .A2(new_n52_), .B1(new_n38_), .B2(new_n44_), .C(p1), .Y(o2));
  INVx1_ASAP7_75t_R    g20(.A(p6), .Y(new_n54_));
  INVx1_ASAP7_75t_R    g21(.A(new_n45_), .Y(new_n55_));
  OA221x2_ASAP7_75t_R  g22(.A1(new_n42_), .A2(new_n41_), .B1(new_n54_), .B2(new_n36_), .C(new_n55_), .Y(o3));
  NAND2x1_ASAP7_75t_R  g23(.A(p0), .B(p4), .Y(new_n57_));
  OA31x2_ASAP7_75t_R   g24(.A1(p6), .A2(new_n36_), .A3(new_n57_), .B1(new_n34_), .Y(new_n58_));
  AND3x1_ASAP7_75t_R   g25(.A(p2), .B(p6), .C(p0), .Y(new_n59_));
  INVx1_ASAP7_75t_R    g26(.A(p5), .Y(new_n60_));
  INVx1_ASAP7_75t_R    g27(.A(p4), .Y(new_n61_));
  OAI21x1_ASAP7_75t_R  g28(.A1(new_n60_), .A2(new_n61_), .B(p3), .Y(new_n62_));
  NAND2x1_ASAP7_75t_R  g29(.A(new_n59_), .B(new_n62_), .Y(new_n63_));
  AOI21x1_ASAP7_75t_R  g30(.A1(p6), .A2(new_n48_), .B(new_n34_), .Y(new_n64_));
  AOI21x1_ASAP7_75t_R  g31(.A1(new_n58_), .A2(new_n63_), .B(new_n64_), .Y(o4));
  AO21x1_ASAP7_75t_R   g32(.A1(p3), .A2(new_n60_), .B(new_n42_), .Y(new_n66_));
  NOR2x1_ASAP7_75t_R   g33(.A(new_n34_), .B(new_n48_), .Y(new_n67_));
  AOI211x1_ASAP7_75t_R g34(.A1(new_n34_), .A2(new_n66_), .B(new_n38_), .C(new_n67_), .Y(o5));
  AND2x2_ASAP7_75t_R   g35(.A(p6), .B(p0), .Y(new_n69_));
  NOR2x1_ASAP7_75t_R   g36(.A(new_n36_), .B(new_n69_), .Y(new_n70_));
  AND2x2_ASAP7_75t_R   g37(.A(p1), .B(new_n36_), .Y(new_n71_));
  AOI211x1_ASAP7_75t_R g38(.A1(new_n34_), .A2(new_n70_), .B(new_n45_), .C(new_n71_), .Y(o6));
  OR5x1_ASAP7_75t_R    g39(.A(new_n42_), .B(new_n43_), .C(p6), .D(p0), .E(p1), .Y(new_n73_));
  OR3x1_ASAP7_75t_R    g40(.A(new_n36_), .B(new_n54_), .C(new_n34_), .Y(new_n74_));
  NAND3x1_ASAP7_75t_R  g41(.A(new_n39_), .B(new_n73_), .C(new_n74_), .Y(o7));
  AOI221x1_ASAP7_75t_R g42(.A1(new_n52_), .A2(new_n34_), .B1(new_n71_), .B2(new_n55_), .C(new_n38_), .Y(o8));
  INVx1_ASAP7_75t_R    g43(.A(new_n47_), .Y(new_n77_));
  AOI221x1_ASAP7_75t_R g44(.A1(new_n36_), .A2(new_n41_), .B1(new_n77_), .B2(new_n52_), .C(new_n46_), .Y(o9));
  NOR2x1_ASAP7_75t_R   g45(.A(p2), .B(p1), .Y(new_n79_));
  AO21x1_ASAP7_75t_R   g46(.A1(p3), .A2(new_n41_), .B(new_n79_), .Y(new_n80_));
  OAI21x1_ASAP7_75t_R  g47(.A1(p6), .A2(new_n38_), .B(new_n48_), .Y(new_n81_));
  OAI21x1_ASAP7_75t_R  g48(.A1(new_n80_), .A2(new_n67_), .B(new_n81_), .Y(o10));
  AND3x1_ASAP7_75t_R   g49(.A(new_n45_), .B(new_n35_), .C(new_n34_), .Y(o11));
  OR3x1_ASAP7_75t_R    g50(.A(p2), .B(p6), .C(p0), .Y(new_n84_));
  NOR2x1_ASAP7_75t_R   g51(.A(p3), .B(p0), .Y(new_n85_));
  NOR2x1_ASAP7_75t_R   g52(.A(new_n34_), .B(new_n85_), .Y(new_n86_));
  NAND2x1_ASAP7_75t_R  g53(.A(p2), .B(new_n43_), .Y(new_n87_));
  AO32x1_ASAP7_75t_R   g54(.A1(new_n34_), .A2(new_n55_), .A3(new_n84_), .B1(new_n86_), .B2(new_n87_), .Y(o12));
  AND3x1_ASAP7_75t_R   g55(.A(new_n45_), .B(p6), .C(p1), .Y(o13));
  AND3x1_ASAP7_75t_R   g56(.A(new_n45_), .B(new_n54_), .C(p1), .Y(o14));
  INVx1_ASAP7_75t_R    g57(.A(new_n87_), .Y(new_n91_));
  AND3x1_ASAP7_75t_R   g58(.A(new_n91_), .B(p1), .C(new_n35_), .Y(o15));
  AND2x2_ASAP7_75t_R   g59(.A(p2), .B(p6), .Y(new_n93_));
  AND3x1_ASAP7_75t_R   g60(.A(new_n93_), .B(p1), .C(new_n85_), .Y(o16));
  AND3x1_ASAP7_75t_R   g61(.A(new_n91_), .B(p1), .C(new_n69_), .Y(o17));
  AND5x1_ASAP7_75t_R   g62(.A(p2), .B(new_n54_), .C(new_n43_), .D(p0), .E(p1), .Y(o18));
  AND3x1_ASAP7_75t_R   g63(.A(new_n42_), .B(new_n43_), .C(p1), .Y(o19));
  OAI21x1_ASAP7_75t_R  g64(.A1(new_n43_), .A2(p4), .B(new_n59_), .Y(new_n98_));
  AOI21x1_ASAP7_75t_R  g65(.A1(new_n85_), .A2(new_n93_), .B(p1), .Y(new_n99_));
  OA21x2_ASAP7_75t_R   g66(.A1(new_n36_), .A2(new_n69_), .B(p1), .Y(new_n100_));
  AOI21x1_ASAP7_75t_R  g67(.A1(new_n98_), .A2(new_n99_), .B(new_n100_), .Y(o20));
  NAND2x1_ASAP7_75t_R  g68(.A(new_n85_), .B(new_n93_), .Y(new_n102_));
  OR5x1_ASAP7_75t_R    g69(.A(p5), .B(new_n57_), .C(new_n42_), .D(new_n54_), .E(new_n43_), .Y(new_n103_));
  AOI21x1_ASAP7_75t_R  g70(.A1(new_n102_), .A2(new_n103_), .B(p1), .Y(o21));
  AOI21x1_ASAP7_75t_R  g71(.A1(new_n34_), .A2(new_n63_), .B(new_n100_), .Y(o22));
  assign               o23 = 1'b1;
  OA211x2_ASAP7_75t_R  g72(.A1(new_n35_), .A2(new_n69_), .B(p3), .C(new_n79_), .Y(o24));
  AND3x1_ASAP7_75t_R   g73(.A(new_n48_), .B(p6), .C(new_n41_), .Y(o25));
endmodule


