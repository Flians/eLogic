// Benchmark "/tmp/" written by ABC on Wed Oct 21 14:30:19 2026

module \/tmp/  ( 
    p5, p2, p3, p0, p1, p4, p6,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25  );
  input  p5, p2, p3, p0, p1, p4, p6;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25;
  wire new_n34_, new_n35_, new_n36_, new_n39_, new_n40_, new_n41_, new_n42_,
    new_n43_, new_n44_, new_n45_, new_n46_, new_n48_, new_n49_, new_n51_,
    new_n52_, new_n53_, new_n55_, new_n56_, new_n57_, new_n58_, new_n59_,
    new_n60_, new_n61_, new_n63_, new_n64_, new_n65_, new_n67_, new_n68_,
    new_n69_, new_n71_, new_n72_, new_n73_, new_n75_, new_n78_, new_n79_,
    new_n80_, new_n82_, new_n84_, new_n85_, new_n86_, new_n90_, new_n92_,
    new_n96_, new_n97_, new_n99_, new_n100_, new_n102_;
  OR3x1_ASAP7_75t_R    g00(.A(p0), .B(p1), .C(p6), .Y(new_n34_));
  INVx1_ASAP7_75t_R    g01(.A(p2), .Y(new_n35_));
  INVx1_ASAP7_75t_R    g02(.A(p3), .Y(new_n36_));
  AND3x1_ASAP7_75t_R   g03(.A(new_n35_), .B(new_n36_), .C(p1), .Y(o19));
  AO32x1_ASAP7_75t_R   g04(.A1(p2), .A2(p3), .A3(new_n34_), .B1(o19), .B2(p0), .Y(o0));
  INVx1_ASAP7_75t_R    g05(.A(p0), .Y(new_n39_));
  NOR2x1_ASAP7_75t_R   g06(.A(p1), .B(new_n39_), .Y(new_n40_));
  NAND2x1_ASAP7_75t_R  g07(.A(p3), .B(new_n35_), .Y(new_n41_));
  OR3x1_ASAP7_75t_R    g08(.A(new_n35_), .B(new_n36_), .C(p6), .Y(new_n42_));
  NOR2x1_ASAP7_75t_R   g09(.A(p0), .B(p1), .Y(new_n43_));
  NOR2x1_ASAP7_75t_R   g10(.A(p2), .B(p3), .Y(new_n44_));
  INVx1_ASAP7_75t_R    g11(.A(p1), .Y(new_n45_));
  AOI21x1_ASAP7_75t_R  g12(.A1(p0), .A2(new_n44_), .B(new_n45_), .Y(new_n46_));
  AOI221x1_ASAP7_75t_R g13(.A1(new_n40_), .A2(new_n41_), .B1(new_n42_), .B2(new_n43_), .C(new_n46_), .Y(o1));
  OA21x2_ASAP7_75t_R   g14(.A1(p3), .A2(new_n35_), .B(p0), .Y(new_n48_));
  OR3x1_ASAP7_75t_R    g15(.A(new_n36_), .B(p2), .C(p6), .Y(new_n49_));
  AOI221x1_ASAP7_75t_R g16(.A1(new_n48_), .A2(new_n49_), .B1(new_n39_), .B2(new_n42_), .C(p1), .Y(o2));
  NAND2x1_ASAP7_75t_R  g17(.A(p3), .B(p6), .Y(new_n51_));
  AND3x1_ASAP7_75t_R   g18(.A(new_n39_), .B(new_n45_), .C(p2), .Y(new_n52_));
  NOR2x1_ASAP7_75t_R   g19(.A(p2), .B(new_n36_), .Y(new_n53_));
  AO21x1_ASAP7_75t_R   g20(.A1(new_n51_), .A2(new_n52_), .B(new_n53_), .Y(o3));
  AND2x2_ASAP7_75t_R   g21(.A(p5), .B(p4), .Y(new_n55_));
  AND3x1_ASAP7_75t_R   g22(.A(p2), .B(p0), .C(p6), .Y(new_n56_));
  OAI21x1_ASAP7_75t_R  g23(.A1(new_n36_), .A2(new_n55_), .B(new_n56_), .Y(new_n57_));
  NAND2x1_ASAP7_75t_R  g24(.A(p2), .B(p3), .Y(new_n58_));
  NAND2x1_ASAP7_75t_R  g25(.A(p0), .B(p4), .Y(new_n59_));
  OA31x2_ASAP7_75t_R   g26(.A1(p6), .A2(new_n58_), .A3(new_n59_), .B1(new_n45_), .Y(new_n60_));
  OA21x2_ASAP7_75t_R   g27(.A1(p2), .A2(new_n51_), .B(p1), .Y(new_n61_));
  AOI21x1_ASAP7_75t_R  g28(.A1(new_n57_), .A2(new_n60_), .B(new_n61_), .Y(o4));
  INVx1_ASAP7_75t_R    g29(.A(p5), .Y(new_n63_));
  AO21x1_ASAP7_75t_R   g30(.A1(p3), .A2(new_n63_), .B(new_n35_), .Y(new_n64_));
  NOR2x1_ASAP7_75t_R   g31(.A(new_n45_), .B(new_n53_), .Y(new_n65_));
  AOI211x1_ASAP7_75t_R g32(.A1(new_n45_), .A2(new_n64_), .B(new_n39_), .C(new_n65_), .Y(o5));
  AND2x2_ASAP7_75t_R   g33(.A(p0), .B(p6), .Y(new_n67_));
  NOR2x1_ASAP7_75t_R   g34(.A(new_n58_), .B(new_n67_), .Y(new_n68_));
  AOI21x1_ASAP7_75t_R  g35(.A1(p2), .A2(p3), .B(new_n45_), .Y(new_n69_));
  AOI211x1_ASAP7_75t_R g36(.A1(new_n45_), .A2(new_n68_), .B(new_n44_), .C(new_n69_), .Y(o6));
  OR4x2_ASAP7_75t_R    g37(.A(new_n39_), .B(new_n45_), .C(p2), .D(p3), .Y(new_n71_));
  NAND2x1_ASAP7_75t_R  g38(.A(p1), .B(p6), .Y(new_n72_));
  AO21x1_ASAP7_75t_R   g39(.A1(new_n72_), .A2(new_n34_), .B(new_n58_), .Y(new_n73_));
  NAND2x1_ASAP7_75t_R  g40(.A(new_n71_), .B(new_n73_), .Y(o7));
  INVx1_ASAP7_75t_R    g41(.A(new_n44_), .Y(new_n75_));
  AOI221x1_ASAP7_75t_R g42(.A1(new_n75_), .A2(new_n69_), .B1(new_n49_), .B2(new_n45_), .C(new_n39_), .Y(o8));
  AOI221x1_ASAP7_75t_R g43(.A1(new_n39_), .A2(new_n58_), .B1(new_n49_), .B2(new_n40_), .C(new_n46_), .Y(o9));
  NOR2x1_ASAP7_75t_R   g44(.A(p2), .B(p1), .Y(new_n78_));
  AO21x1_ASAP7_75t_R   g45(.A1(p3), .A2(new_n43_), .B(new_n78_), .Y(new_n79_));
  NOR2x1_ASAP7_75t_R   g46(.A(p6), .B(new_n39_), .Y(new_n80_));
  OAI22x1_ASAP7_75t_R  g47(.A1(new_n65_), .A2(new_n79_), .B1(new_n41_), .B2(new_n80_), .Y(o10));
  INVx1_ASAP7_75t_R    g48(.A(p6), .Y(new_n82_));
  AND3x1_ASAP7_75t_R   g49(.A(new_n44_), .B(new_n43_), .C(new_n82_), .Y(o11));
  OA211x2_ASAP7_75t_R  g50(.A1(p2), .A2(new_n39_), .B(new_n36_), .C(p1), .Y(new_n84_));
  NOR2x1_ASAP7_75t_R   g51(.A(p0), .B(p6), .Y(new_n85_));
  OA211x2_ASAP7_75t_R  g52(.A1(new_n36_), .A2(new_n85_), .B(new_n35_), .C(new_n45_), .Y(new_n86_));
  NOR2x1_ASAP7_75t_R   g53(.A(new_n84_), .B(new_n86_), .Y(o12));
  AND3x1_ASAP7_75t_R   g54(.A(new_n44_), .B(p1), .C(p6), .Y(o13));
  AND3x1_ASAP7_75t_R   g55(.A(new_n44_), .B(p1), .C(new_n82_), .Y(o14));
  NOR2x1_ASAP7_75t_R   g56(.A(p3), .B(new_n35_), .Y(new_n90_));
  AND3x1_ASAP7_75t_R   g57(.A(new_n90_), .B(p1), .C(new_n85_), .Y(o15));
  AND3x1_ASAP7_75t_R   g58(.A(new_n36_), .B(p2), .C(p1), .Y(new_n92_));
  AND3x1_ASAP7_75t_R   g59(.A(new_n92_), .B(new_n39_), .C(p6), .Y(o16));
  AND3x1_ASAP7_75t_R   g60(.A(new_n90_), .B(p1), .C(new_n67_), .Y(o17));
  AND3x1_ASAP7_75t_R   g61(.A(new_n90_), .B(new_n80_), .C(p1), .Y(o18));
  NOR2x1_ASAP7_75t_R   g62(.A(p1), .B(new_n82_), .Y(new_n96_));
  AOI21x1_ASAP7_75t_R  g63(.A1(p3), .A2(new_n59_), .B(new_n35_), .Y(new_n97_));
  AO22x1_ASAP7_75t_R   g64(.A1(new_n96_), .A2(new_n97_), .B1(p1), .B2(new_n68_), .Y(o20));
  AND3x1_ASAP7_75t_R   g65(.A(new_n36_), .B(new_n39_), .C(p2), .Y(new_n99_));
  AND5x1_ASAP7_75t_R   g66(.A(new_n63_), .B(p2), .C(p3), .D(p0), .E(p4), .Y(new_n100_));
  OA21x2_ASAP7_75t_R   g67(.A1(new_n99_), .A2(new_n100_), .B(new_n96_), .Y(o21));
  OR3x1_ASAP7_75t_R    g68(.A(new_n67_), .B(new_n45_), .C(new_n58_), .Y(new_n102_));
  OAI21x1_ASAP7_75t_R  g69(.A1(p1), .A2(new_n57_), .B(new_n102_), .Y(o22));
  assign               o23 = 1'b1;
  OA211x2_ASAP7_75t_R  g70(.A1(new_n85_), .A2(new_n67_), .B(p3), .C(new_n78_), .Y(o24));
  AND5x1_ASAP7_75t_R   g71(.A(new_n35_), .B(new_n39_), .C(new_n45_), .D(p3), .E(p6), .Y(o25));
endmodule


