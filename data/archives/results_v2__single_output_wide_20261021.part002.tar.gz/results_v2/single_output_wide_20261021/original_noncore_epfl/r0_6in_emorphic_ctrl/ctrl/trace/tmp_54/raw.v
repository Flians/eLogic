// Benchmark "/tmp/" written by ABC on Wed Oct 21 14:30:19 2026

module \/tmp/  ( 
    p3, p4, p0, p2, p6, p1, p5,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25  );
  input  p3, p4, p0, p2, p6, p1, p5;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25;
  wire new_n34_, new_n35_, new_n36_, new_n37_, new_n39_, new_n40_, new_n41_,
    new_n42_, new_n43_, new_n44_, new_n45_, new_n46_, new_n47_, new_n49_,
    new_n50_, new_n51_, new_n52_, new_n53_, new_n54_, new_n56_, new_n57_,
    new_n59_, new_n60_, new_n61_, new_n62_, new_n63_, new_n64_, new_n65_,
    new_n66_, new_n67_, new_n68_, new_n69_, new_n71_, new_n73_, new_n74_,
    new_n76_, new_n78_, new_n79_, new_n82_, new_n83_, new_n84_, new_n87_,
    new_n88_, new_n92_, new_n93_, new_n99_, new_n100_, new_n101_,
    new_n103_, new_n105_;
  AND2x2_ASAP7_75t_R   g00(.A(p3), .B(p2), .Y(new_n34_));
  OR3x1_ASAP7_75t_R    g01(.A(p0), .B(p6), .C(p1), .Y(new_n35_));
  NOR2x1_ASAP7_75t_R   g02(.A(p3), .B(p2), .Y(new_n36_));
  AND3x1_ASAP7_75t_R   g03(.A(new_n36_), .B(p0), .C(p1), .Y(new_n37_));
  AO21x1_ASAP7_75t_R   g04(.A1(new_n34_), .A2(new_n35_), .B(new_n37_), .Y(o0));
  INVx1_ASAP7_75t_R    g05(.A(p0), .Y(new_n39_));
  NOR2x1_ASAP7_75t_R   g06(.A(p1), .B(new_n39_), .Y(new_n40_));
  INVx1_ASAP7_75t_R    g07(.A(p2), .Y(new_n41_));
  NAND2x1_ASAP7_75t_R  g08(.A(p3), .B(new_n41_), .Y(new_n42_));
  INVx1_ASAP7_75t_R    g09(.A(p3), .Y(new_n43_));
  OR3x1_ASAP7_75t_R    g10(.A(new_n43_), .B(new_n41_), .C(p6), .Y(new_n44_));
  NOR2x1_ASAP7_75t_R   g11(.A(p0), .B(p1), .Y(new_n45_));
  INVx1_ASAP7_75t_R    g12(.A(p1), .Y(new_n46_));
  AOI21x1_ASAP7_75t_R  g13(.A1(p0), .A2(new_n36_), .B(new_n46_), .Y(new_n47_));
  AOI221x1_ASAP7_75t_R g14(.A1(new_n40_), .A2(new_n42_), .B1(new_n44_), .B2(new_n45_), .C(new_n47_), .Y(o1));
  NAND2x1_ASAP7_75t_R  g15(.A(p2), .B(new_n43_), .Y(new_n49_));
  AND2x2_ASAP7_75t_R   g16(.A(p0), .B(new_n49_), .Y(new_n50_));
  OR3x1_ASAP7_75t_R    g17(.A(new_n43_), .B(p2), .C(p6), .Y(new_n51_));
  INVx1_ASAP7_75t_R    g18(.A(new_n40_), .Y(new_n52_));
  NAND2x1_ASAP7_75t_R  g19(.A(p3), .B(p2), .Y(new_n53_));
  OR3x1_ASAP7_75t_R    g20(.A(new_n53_), .B(p6), .C(p1), .Y(new_n54_));
  AOI22x1_ASAP7_75t_R  g21(.A1(new_n50_), .A2(new_n51_), .B1(new_n52_), .B2(new_n54_), .Y(o2));
  NAND2x1_ASAP7_75t_R  g22(.A(p2), .B(new_n45_), .Y(new_n56_));
  AND3x1_ASAP7_75t_R   g23(.A(p3), .B(p2), .C(p6), .Y(new_n57_));
  AOI21x1_ASAP7_75t_R  g24(.A1(new_n42_), .A2(new_n56_), .B(new_n57_), .Y(o3));
  NAND2x1_ASAP7_75t_R  g25(.A(p4), .B(p0), .Y(new_n59_));
  OA31x2_ASAP7_75t_R   g26(.A1(p6), .A2(new_n53_), .A3(new_n59_), .B1(new_n46_), .Y(new_n60_));
  INVx1_ASAP7_75t_R    g27(.A(p5), .Y(new_n61_));
  AOI21x1_ASAP7_75t_R  g28(.A1(p3), .A2(new_n61_), .B(new_n41_), .Y(new_n62_));
  INVx1_ASAP7_75t_R    g29(.A(p4), .Y(new_n63_));
  NAND3x1_ASAP7_75t_R  g30(.A(new_n63_), .B(p3), .C(p5), .Y(new_n64_));
  NAND2x1_ASAP7_75t_R  g31(.A(p0), .B(p6), .Y(new_n65_));
  INVx1_ASAP7_75t_R    g32(.A(new_n65_), .Y(new_n66_));
  NAND3x1_ASAP7_75t_R  g33(.A(new_n62_), .B(new_n64_), .C(new_n66_), .Y(new_n67_));
  INVx1_ASAP7_75t_R    g34(.A(p6), .Y(new_n68_));
  OA21x2_ASAP7_75t_R   g35(.A1(new_n68_), .A2(new_n42_), .B(p1), .Y(new_n69_));
  AOI21x1_ASAP7_75t_R  g36(.A1(new_n60_), .A2(new_n67_), .B(new_n69_), .Y(o4));
  AO21x1_ASAP7_75t_R   g37(.A1(p3), .A2(new_n41_), .B(new_n46_), .Y(new_n71_));
  OA211x2_ASAP7_75t_R  g38(.A1(p1), .A2(new_n62_), .B(new_n71_), .C(p0), .Y(o5));
  NAND2x1_ASAP7_75t_R  g39(.A(new_n65_), .B(new_n34_), .Y(new_n73_));
  NOR2x1_ASAP7_75t_R   g40(.A(p1), .B(new_n36_), .Y(new_n74_));
  OA22x2_ASAP7_75t_R   g41(.A1(new_n73_), .A2(p1), .B1(new_n34_), .B2(new_n74_), .Y(o6));
  INVx1_ASAP7_75t_R    g42(.A(new_n35_), .Y(new_n76_));
  AO221x2_ASAP7_75t_R  g43(.A1(p1), .A2(new_n57_), .B1(new_n76_), .B2(new_n34_), .C(new_n37_), .Y(o7));
  AO21x1_ASAP7_75t_R   g44(.A1(p1), .A2(new_n53_), .B(new_n39_), .Y(new_n78_));
  NAND2x1_ASAP7_75t_R  g45(.A(p0), .B(new_n36_), .Y(new_n79_));
  AOI22x1_ASAP7_75t_R  g46(.A1(new_n78_), .A2(new_n79_), .B1(new_n40_), .B2(new_n51_), .Y(o8));
  AOI221x1_ASAP7_75t_R g47(.A1(new_n39_), .A2(new_n53_), .B1(new_n51_), .B2(new_n40_), .C(new_n47_), .Y(o9));
  NAND2x1_ASAP7_75t_R  g48(.A(p0), .B(new_n68_), .Y(new_n82_));
  NOR2x1_ASAP7_75t_R   g49(.A(p2), .B(p1), .Y(new_n83_));
  AOI21x1_ASAP7_75t_R  g50(.A1(p3), .A2(new_n45_), .B(new_n83_), .Y(new_n84_));
  AO32x1_ASAP7_75t_R   g51(.A1(p3), .A2(new_n41_), .A3(new_n82_), .B1(new_n84_), .B2(new_n71_), .Y(o10));
  AND3x1_ASAP7_75t_R   g52(.A(new_n36_), .B(new_n45_), .C(new_n68_), .Y(o11));
  NAND2x1_ASAP7_75t_R  g53(.A(new_n43_), .B(new_n39_), .Y(new_n87_));
  OR3x1_ASAP7_75t_R    g54(.A(p0), .B(p2), .C(p6), .Y(new_n88_));
  AO32x1_ASAP7_75t_R   g55(.A1(p1), .A2(new_n49_), .A3(new_n87_), .B1(new_n74_), .B2(new_n88_), .Y(o12));
  AND3x1_ASAP7_75t_R   g56(.A(new_n36_), .B(p6), .C(p1), .Y(o13));
  AND3x1_ASAP7_75t_R   g57(.A(new_n36_), .B(new_n68_), .C(p1), .Y(o14));
  NOR2x1_ASAP7_75t_R   g58(.A(p0), .B(p6), .Y(new_n92_));
  AND3x1_ASAP7_75t_R   g59(.A(new_n43_), .B(p2), .C(p1), .Y(new_n93_));
  AND2x2_ASAP7_75t_R   g60(.A(new_n92_), .B(new_n93_), .Y(o15));
  AND3x1_ASAP7_75t_R   g61(.A(new_n93_), .B(new_n39_), .C(p6), .Y(o16));
  AND2x2_ASAP7_75t_R   g62(.A(new_n66_), .B(new_n93_), .Y(o17));
  AND3x1_ASAP7_75t_R   g63(.A(new_n93_), .B(p0), .C(new_n68_), .Y(o18));
  AND3x1_ASAP7_75t_R   g64(.A(new_n43_), .B(new_n41_), .C(p1), .Y(o19));
  NAND2x1_ASAP7_75t_R  g65(.A(p3), .B(new_n59_), .Y(new_n99_));
  AND3x1_ASAP7_75t_R   g66(.A(new_n46_), .B(p2), .C(p6), .Y(new_n100_));
  AND3x1_ASAP7_75t_R   g67(.A(new_n34_), .B(p1), .C(new_n65_), .Y(new_n101_));
  AO21x1_ASAP7_75t_R   g68(.A1(new_n99_), .A2(new_n100_), .B(new_n101_), .Y(o20));
  OAI21x1_ASAP7_75t_R  g69(.A1(new_n43_), .A2(p5), .B(new_n87_), .Y(new_n103_));
  AND3x1_ASAP7_75t_R   g70(.A(new_n103_), .B(new_n99_), .C(new_n100_), .Y(o21));
  AOI211x1_ASAP7_75t_R g71(.A1(p3), .A2(new_n61_), .B(new_n41_), .C(new_n65_), .Y(new_n105_));
  AO31x2_ASAP7_75t_R   g72(.A1(new_n46_), .A2(new_n64_), .A3(new_n105_), .B(new_n101_), .Y(o22));
  assign               o23 = 1'b1;
  OA211x2_ASAP7_75t_R  g73(.A1(new_n92_), .A2(new_n66_), .B(p3), .C(new_n83_), .Y(o24));
  AND5x1_ASAP7_75t_R   g74(.A(p3), .B(new_n39_), .C(new_n41_), .D(new_n46_), .E(p6), .Y(o25));
endmodule


