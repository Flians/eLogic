// Benchmark "/tmp/" written by ABC on Wed Oct 21 14:30:14 2026

module \/tmp/  ( 
    p1, p5, p2, p4, p6, p3, p0,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25  );
  input  p1, p5, p2, p4, p6, p3, p0;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25;
  wire new_n34_, new_n35_, new_n36_, new_n37_, new_n38_, new_n40_, new_n41_,
    new_n42_, new_n43_, new_n44_, new_n45_, new_n46_, new_n47_, new_n49_,
    new_n50_, new_n53_, new_n54_, new_n55_, new_n56_, new_n57_, new_n58_,
    new_n59_, new_n60_, new_n61_, new_n62_, new_n63_, new_n65_, new_n66_,
    new_n68_, new_n69_, new_n71_, new_n72_, new_n74_, new_n75_, new_n78_,
    new_n79_, new_n80_, new_n83_, new_n84_, new_n85_, new_n89_, new_n95_,
    new_n96_, new_n98_, new_n99_, new_n101_;
  NOR2x1_ASAP7_75t_R   g00(.A(p2), .B(p3), .Y(new_n34_));
  AND3x1_ASAP7_75t_R   g01(.A(new_n34_), .B(p1), .C(p0), .Y(new_n35_));
  AND2x2_ASAP7_75t_R   g02(.A(p2), .B(p3), .Y(new_n36_));
  NOR2x1_ASAP7_75t_R   g03(.A(p1), .B(p0), .Y(new_n37_));
  INVx1_ASAP7_75t_R    g04(.A(new_n37_), .Y(new_n38_));
  OA22x2_ASAP7_75t_R   g05(.A1(new_n35_), .A2(new_n36_), .B1(p6), .B2(new_n38_), .Y(o0));
  INVx1_ASAP7_75t_R    g06(.A(p2), .Y(new_n40_));
  NAND2x1_ASAP7_75t_R  g07(.A(p3), .B(new_n40_), .Y(new_n41_));
  INVx1_ASAP7_75t_R    g08(.A(p0), .Y(new_n42_));
  NOR2x1_ASAP7_75t_R   g09(.A(p1), .B(new_n42_), .Y(new_n43_));
  INVx1_ASAP7_75t_R    g10(.A(p3), .Y(new_n44_));
  OR3x1_ASAP7_75t_R    g11(.A(new_n40_), .B(new_n44_), .C(p6), .Y(new_n45_));
  INVx1_ASAP7_75t_R    g12(.A(p1), .Y(new_n46_));
  AOI21x1_ASAP7_75t_R  g13(.A1(p0), .A2(new_n34_), .B(new_n46_), .Y(new_n47_));
  AOI221x1_ASAP7_75t_R g14(.A1(new_n41_), .A2(new_n43_), .B1(new_n45_), .B2(new_n37_), .C(new_n47_), .Y(o1));
  OA21x2_ASAP7_75t_R   g15(.A1(p3), .A2(new_n40_), .B(p0), .Y(new_n49_));
  OR3x1_ASAP7_75t_R    g16(.A(new_n44_), .B(p2), .C(p6), .Y(new_n50_));
  AOI221x1_ASAP7_75t_R g17(.A1(new_n49_), .A2(new_n50_), .B1(new_n42_), .B2(new_n45_), .C(p1), .Y(o2));
  AOI221x1_ASAP7_75t_R g18(.A1(p6), .A2(new_n36_), .B1(new_n38_), .B2(p2), .C(new_n34_), .Y(o3));
  NAND2x1_ASAP7_75t_R  g19(.A(p2), .B(p3), .Y(new_n53_));
  NAND2x1_ASAP7_75t_R  g20(.A(p4), .B(p0), .Y(new_n54_));
  OA31x2_ASAP7_75t_R   g21(.A1(p6), .A2(new_n53_), .A3(new_n54_), .B1(new_n46_), .Y(new_n55_));
  INVx1_ASAP7_75t_R    g22(.A(p5), .Y(new_n56_));
  AOI21x1_ASAP7_75t_R  g23(.A1(p3), .A2(new_n56_), .B(new_n40_), .Y(new_n57_));
  INVx1_ASAP7_75t_R    g24(.A(p4), .Y(new_n58_));
  NAND3x1_ASAP7_75t_R  g25(.A(new_n58_), .B(p5), .C(p3), .Y(new_n59_));
  AND2x2_ASAP7_75t_R   g26(.A(p6), .B(p0), .Y(new_n60_));
  NAND3x1_ASAP7_75t_R  g27(.A(new_n57_), .B(new_n59_), .C(new_n60_), .Y(new_n61_));
  INVx1_ASAP7_75t_R    g28(.A(p6), .Y(new_n62_));
  OA21x2_ASAP7_75t_R   g29(.A1(new_n62_), .A2(new_n41_), .B(p1), .Y(new_n63_));
  AOI21x1_ASAP7_75t_R  g30(.A1(new_n55_), .A2(new_n61_), .B(new_n63_), .Y(o4));
  AND2x2_ASAP7_75t_R   g31(.A(p1), .B(new_n41_), .Y(new_n65_));
  OAI21x1_ASAP7_75t_R  g32(.A1(p1), .A2(new_n57_), .B(p0), .Y(new_n66_));
  NOR2x1_ASAP7_75t_R   g33(.A(new_n65_), .B(new_n66_), .Y(o5));
  AO21x1_ASAP7_75t_R   g34(.A1(p6), .A2(p0), .B(new_n53_), .Y(new_n68_));
  NOR2x1_ASAP7_75t_R   g35(.A(p1), .B(new_n34_), .Y(new_n69_));
  OA22x2_ASAP7_75t_R   g36(.A1(new_n68_), .A2(p1), .B1(new_n36_), .B2(new_n69_), .Y(o6));
  AND3x1_ASAP7_75t_R   g37(.A(new_n36_), .B(new_n62_), .C(new_n37_), .Y(new_n71_));
  AND3x1_ASAP7_75t_R   g38(.A(new_n36_), .B(p1), .C(p6), .Y(new_n72_));
  OR3x1_ASAP7_75t_R    g39(.A(new_n71_), .B(new_n72_), .C(new_n35_), .Y(o7));
  AO21x1_ASAP7_75t_R   g40(.A1(p1), .A2(new_n53_), .B(new_n42_), .Y(new_n74_));
  NAND2x1_ASAP7_75t_R  g41(.A(p0), .B(new_n34_), .Y(new_n75_));
  AOI22x1_ASAP7_75t_R  g42(.A1(new_n74_), .A2(new_n75_), .B1(new_n43_), .B2(new_n50_), .Y(o8));
  AOI221x1_ASAP7_75t_R g43(.A1(new_n42_), .A2(new_n53_), .B1(new_n50_), .B2(new_n43_), .C(new_n47_), .Y(o9));
  NOR2x1_ASAP7_75t_R   g44(.A(p1), .B(p2), .Y(new_n78_));
  AO21x1_ASAP7_75t_R   g45(.A1(p3), .A2(new_n37_), .B(new_n78_), .Y(new_n79_));
  AO21x1_ASAP7_75t_R   g46(.A1(new_n62_), .A2(p0), .B(new_n41_), .Y(new_n80_));
  OAI21x1_ASAP7_75t_R  g47(.A1(new_n79_), .A2(new_n65_), .B(new_n80_), .Y(o10));
  AND3x1_ASAP7_75t_R   g48(.A(new_n37_), .B(new_n34_), .C(new_n62_), .Y(o11));
  NOR2x1_ASAP7_75t_R   g49(.A(p6), .B(p0), .Y(new_n83_));
  OA21x2_ASAP7_75t_R   g50(.A1(new_n44_), .A2(new_n83_), .B(new_n78_), .Y(new_n84_));
  OA211x2_ASAP7_75t_R  g51(.A1(p2), .A2(new_n42_), .B(new_n44_), .C(p1), .Y(new_n85_));
  NOR2x1_ASAP7_75t_R   g52(.A(new_n84_), .B(new_n85_), .Y(o12));
  AND3x1_ASAP7_75t_R   g53(.A(new_n34_), .B(p1), .C(p6), .Y(o13));
  AND3x1_ASAP7_75t_R   g54(.A(new_n34_), .B(p1), .C(new_n62_), .Y(o14));
  AND3x1_ASAP7_75t_R   g55(.A(new_n44_), .B(p1), .C(p2), .Y(new_n89_));
  AND2x2_ASAP7_75t_R   g56(.A(new_n83_), .B(new_n89_), .Y(o15));
  AND3x1_ASAP7_75t_R   g57(.A(new_n89_), .B(p6), .C(new_n42_), .Y(o16));
  AND2x2_ASAP7_75t_R   g58(.A(new_n60_), .B(new_n89_), .Y(o17));
  AND3x1_ASAP7_75t_R   g59(.A(new_n89_), .B(new_n62_), .C(p0), .Y(o18));
  AND3x1_ASAP7_75t_R   g60(.A(new_n40_), .B(new_n44_), .C(p1), .Y(o19));
  AND2x2_ASAP7_75t_R   g61(.A(p3), .B(new_n54_), .Y(new_n95_));
  OR3x1_ASAP7_75t_R    g62(.A(new_n40_), .B(new_n62_), .C(p1), .Y(new_n96_));
  OAI22x1_ASAP7_75t_R  g63(.A1(new_n68_), .A2(new_n46_), .B1(new_n95_), .B2(new_n96_), .Y(o20));
  AND3x1_ASAP7_75t_R   g64(.A(new_n44_), .B(new_n42_), .C(p2), .Y(new_n98_));
  AND5x1_ASAP7_75t_R   g65(.A(new_n56_), .B(p2), .C(p4), .D(p3), .E(p0), .Y(new_n99_));
  OA211x2_ASAP7_75t_R  g66(.A1(new_n98_), .A2(new_n99_), .B(new_n46_), .C(p6), .Y(o21));
  OA21x2_ASAP7_75t_R   g67(.A1(new_n53_), .A2(new_n60_), .B(p1), .Y(new_n101_));
  AOI21x1_ASAP7_75t_R  g68(.A1(new_n46_), .A2(new_n61_), .B(new_n101_), .Y(o22));
  assign               o23 = 1'b1;
  OA211x2_ASAP7_75t_R  g69(.A1(new_n83_), .A2(new_n60_), .B(p3), .C(new_n78_), .Y(o24));
  AND5x1_ASAP7_75t_R   g70(.A(new_n46_), .B(new_n40_), .C(new_n42_), .D(p6), .E(p3), .Y(o25));
endmodule


