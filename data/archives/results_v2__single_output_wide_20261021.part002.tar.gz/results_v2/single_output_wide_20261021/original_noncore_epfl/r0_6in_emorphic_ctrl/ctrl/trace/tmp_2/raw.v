// Benchmark "/tmp/" written by ABC on Wed Oct 21 14:30:11 2026

module \/tmp/  ( 
    p2, p3, p6, p4, p5, p1, p0,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25  );
  input  p2, p3, p6, p4, p5, p1, p0;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25;
  wire new_n34_, new_n35_, new_n36_, new_n37_, new_n38_, new_n39_, new_n41_,
    new_n42_, new_n43_, new_n44_, new_n45_, new_n46_, new_n47_, new_n48_,
    new_n50_, new_n51_, new_n52_, new_n53_, new_n54_, new_n56_, new_n57_,
    new_n59_, new_n60_, new_n61_, new_n62_, new_n63_, new_n64_, new_n65_,
    new_n66_, new_n67_, new_n68_, new_n71_, new_n72_, new_n73_, new_n75_,
    new_n77_, new_n80_, new_n81_, new_n82_, new_n83_, new_n84_, new_n87_,
    new_n88_, new_n93_, new_n94_, new_n99_, new_n100_, new_n101_,
    new_n103_, new_n104_;
  NOR2x1_ASAP7_75t_R   g00(.A(p2), .B(p3), .Y(new_n34_));
  AND2x2_ASAP7_75t_R   g01(.A(p1), .B(p0), .Y(new_n35_));
  INVx1_ASAP7_75t_R    g02(.A(p1), .Y(new_n36_));
  NOR2x1_ASAP7_75t_R   g03(.A(p6), .B(p0), .Y(new_n37_));
  NAND2x1_ASAP7_75t_R  g04(.A(p2), .B(p3), .Y(new_n38_));
  AOI21x1_ASAP7_75t_R  g05(.A1(new_n36_), .A2(new_n37_), .B(new_n38_), .Y(new_n39_));
  AO21x1_ASAP7_75t_R   g06(.A1(new_n34_), .A2(new_n35_), .B(new_n39_), .Y(o0));
  INVx1_ASAP7_75t_R    g07(.A(p2), .Y(new_n41_));
  NAND2x1_ASAP7_75t_R  g08(.A(p3), .B(new_n41_), .Y(new_n42_));
  INVx1_ASAP7_75t_R    g09(.A(p0), .Y(new_n43_));
  NOR2x1_ASAP7_75t_R   g10(.A(p1), .B(new_n43_), .Y(new_n44_));
  INVx1_ASAP7_75t_R    g11(.A(p3), .Y(new_n45_));
  OR3x1_ASAP7_75t_R    g12(.A(new_n41_), .B(new_n45_), .C(p6), .Y(new_n46_));
  NOR2x1_ASAP7_75t_R   g13(.A(p1), .B(p0), .Y(new_n47_));
  AOI21x1_ASAP7_75t_R  g14(.A1(p0), .A2(new_n34_), .B(new_n36_), .Y(new_n48_));
  AOI221x1_ASAP7_75t_R g15(.A1(new_n42_), .A2(new_n44_), .B1(new_n46_), .B2(new_n47_), .C(new_n48_), .Y(o1));
  NOR2x1_ASAP7_75t_R   g16(.A(p3), .B(new_n41_), .Y(new_n50_));
  NOR2x1_ASAP7_75t_R   g17(.A(new_n43_), .B(new_n50_), .Y(new_n51_));
  OR3x1_ASAP7_75t_R    g18(.A(new_n45_), .B(p2), .C(p6), .Y(new_n52_));
  INVx1_ASAP7_75t_R    g19(.A(new_n44_), .Y(new_n53_));
  OR3x1_ASAP7_75t_R    g20(.A(new_n38_), .B(p6), .C(p1), .Y(new_n54_));
  AOI22x1_ASAP7_75t_R  g21(.A1(new_n51_), .A2(new_n52_), .B1(new_n53_), .B2(new_n54_), .Y(o2));
  INVx1_ASAP7_75t_R    g22(.A(new_n47_), .Y(new_n56_));
  AND3x1_ASAP7_75t_R   g23(.A(p2), .B(p3), .C(p6), .Y(new_n57_));
  AOI211x1_ASAP7_75t_R g24(.A1(p2), .A2(new_n56_), .B(new_n34_), .C(new_n57_), .Y(o3));
  NAND2x1_ASAP7_75t_R  g25(.A(p4), .B(p0), .Y(new_n59_));
  OA31x2_ASAP7_75t_R   g26(.A1(p6), .A2(new_n38_), .A3(new_n59_), .B1(new_n36_), .Y(new_n60_));
  INVx1_ASAP7_75t_R    g27(.A(p5), .Y(new_n61_));
  NAND2x1_ASAP7_75t_R  g28(.A(p3), .B(new_n61_), .Y(new_n62_));
  INVx1_ASAP7_75t_R    g29(.A(p4), .Y(new_n63_));
  NAND2x1_ASAP7_75t_R  g30(.A(p3), .B(new_n63_), .Y(new_n64_));
  AND3x1_ASAP7_75t_R   g31(.A(p2), .B(p6), .C(p0), .Y(new_n65_));
  NAND3x1_ASAP7_75t_R  g32(.A(new_n62_), .B(new_n64_), .C(new_n65_), .Y(new_n66_));
  NOR2x1_ASAP7_75t_R   g33(.A(p2), .B(new_n45_), .Y(new_n67_));
  AOI21x1_ASAP7_75t_R  g34(.A1(p6), .A2(new_n67_), .B(new_n36_), .Y(new_n68_));
  AOI21x1_ASAP7_75t_R  g35(.A1(new_n60_), .A2(new_n66_), .B(new_n68_), .Y(o4));
  AO32x1_ASAP7_75t_R   g36(.A1(new_n44_), .A2(new_n62_), .A3(p2), .B1(new_n35_), .B2(new_n67_), .Y(o5));
  AND2x2_ASAP7_75t_R   g37(.A(p6), .B(p0), .Y(new_n71_));
  NOR2x1_ASAP7_75t_R   g38(.A(new_n38_), .B(new_n71_), .Y(new_n72_));
  AND2x2_ASAP7_75t_R   g39(.A(p1), .B(new_n38_), .Y(new_n73_));
  AOI211x1_ASAP7_75t_R g40(.A1(new_n36_), .A2(new_n72_), .B(new_n34_), .C(new_n73_), .Y(o6));
  AOI22x1_ASAP7_75t_R  g41(.A1(new_n57_), .A2(p1), .B1(new_n35_), .B2(new_n34_), .Y(new_n75_));
  OAI21x1_ASAP7_75t_R  g42(.A1(new_n56_), .A2(new_n46_), .B(new_n75_), .Y(o7));
  INVx1_ASAP7_75t_R    g43(.A(new_n34_), .Y(new_n77_));
  AOI221x1_ASAP7_75t_R g44(.A1(new_n52_), .A2(new_n36_), .B1(new_n73_), .B2(new_n77_), .C(new_n43_), .Y(o8));
  AOI221x1_ASAP7_75t_R g45(.A1(new_n43_), .A2(new_n38_), .B1(new_n52_), .B2(new_n44_), .C(new_n48_), .Y(o9));
  NOR2x1_ASAP7_75t_R   g46(.A(new_n36_), .B(new_n67_), .Y(new_n80_));
  NOR2x1_ASAP7_75t_R   g47(.A(p2), .B(p1), .Y(new_n81_));
  AO21x1_ASAP7_75t_R   g48(.A1(p3), .A2(new_n47_), .B(new_n81_), .Y(new_n82_));
  INVx1_ASAP7_75t_R    g49(.A(p6), .Y(new_n83_));
  AO21x1_ASAP7_75t_R   g50(.A1(new_n83_), .A2(p0), .B(new_n42_), .Y(new_n84_));
  OAI21x1_ASAP7_75t_R  g51(.A1(new_n80_), .A2(new_n82_), .B(new_n84_), .Y(o10));
  AND3x1_ASAP7_75t_R   g52(.A(new_n47_), .B(new_n34_), .C(new_n83_), .Y(o11));
  AND3x1_ASAP7_75t_R   g53(.A(new_n45_), .B(new_n43_), .C(p1), .Y(new_n87_));
  OA21x2_ASAP7_75t_R   g54(.A1(new_n45_), .A2(new_n37_), .B(new_n81_), .Y(new_n88_));
  AOI211x1_ASAP7_75t_R g55(.A1(p1), .A2(new_n50_), .B(new_n87_), .C(new_n88_), .Y(o12));
  AND3x1_ASAP7_75t_R   g56(.A(new_n34_), .B(p6), .C(p1), .Y(o13));
  AND3x1_ASAP7_75t_R   g57(.A(new_n34_), .B(new_n83_), .C(p1), .Y(o14));
  AND3x1_ASAP7_75t_R   g58(.A(new_n50_), .B(p1), .C(new_n37_), .Y(o15));
  AND2x2_ASAP7_75t_R   g59(.A(p2), .B(p6), .Y(new_n93_));
  NOR2x1_ASAP7_75t_R   g60(.A(p3), .B(p0), .Y(new_n94_));
  AND3x1_ASAP7_75t_R   g61(.A(new_n93_), .B(p1), .C(new_n94_), .Y(o16));
  AND3x1_ASAP7_75t_R   g62(.A(new_n35_), .B(new_n93_), .C(new_n45_), .Y(o17));
  AND3x1_ASAP7_75t_R   g63(.A(new_n50_), .B(new_n83_), .C(new_n35_), .Y(o18));
  AND3x1_ASAP7_75t_R   g64(.A(new_n41_), .B(new_n45_), .C(p1), .Y(o19));
  NAND2x1_ASAP7_75t_R  g65(.A(new_n65_), .B(new_n64_), .Y(new_n99_));
  AOI21x1_ASAP7_75t_R  g66(.A1(new_n94_), .A2(new_n93_), .B(p1), .Y(new_n100_));
  OA21x2_ASAP7_75t_R   g67(.A1(new_n38_), .A2(new_n71_), .B(p1), .Y(new_n101_));
  AOI21x1_ASAP7_75t_R  g68(.A1(new_n99_), .A2(new_n100_), .B(new_n101_), .Y(o20));
  NAND2x1_ASAP7_75t_R  g69(.A(new_n94_), .B(new_n93_), .Y(new_n103_));
  OR5x1_ASAP7_75t_R    g70(.A(new_n41_), .B(new_n59_), .C(new_n45_), .D(new_n83_), .E(p5), .Y(new_n104_));
  AOI21x1_ASAP7_75t_R  g71(.A1(new_n103_), .A2(new_n104_), .B(p1), .Y(o21));
  AOI21x1_ASAP7_75t_R  g72(.A1(new_n36_), .A2(new_n66_), .B(new_n101_), .Y(o22));
  assign               o23 = 1'b1;
  OA211x2_ASAP7_75t_R  g73(.A1(new_n37_), .A2(new_n71_), .B(p3), .C(new_n81_), .Y(o24));
  AND3x1_ASAP7_75t_R   g74(.A(new_n67_), .B(p6), .C(new_n47_), .Y(o25));
endmodule


