// Benchmark "/tmp/" written by ABC on Wed Oct 21 14:30:11 2026

module \/tmp/  ( 
    p6, p0, p1, p2, p3, p4, p5,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25  );
  input  p6, p0, p1, p2, p3, p4, p5;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25;
  wire new_n34_, new_n35_, new_n36_, new_n37_, new_n38_, new_n40_, new_n41_,
    new_n42_, new_n43_, new_n44_, new_n45_, new_n46_, new_n47_, new_n49_,
    new_n50_, new_n51_, new_n52_, new_n54_, new_n55_, new_n57_, new_n58_,
    new_n59_, new_n60_, new_n61_, new_n62_, new_n63_, new_n64_, new_n66_,
    new_n67_, new_n68_, new_n69_, new_n71_, new_n72_, new_n73_, new_n75_,
    new_n76_, new_n77_, new_n79_, new_n81_, new_n83_, new_n84_, new_n85_,
    new_n86_, new_n89_, new_n90_, new_n91_, new_n97_, new_n101_, new_n102_,
    new_n103_, new_n105_, new_n106_, new_n107_, new_n109_, new_n110_,
    new_n111_, new_n114_;
  INVx1_ASAP7_75t_R    g00(.A(p0), .Y(new_n34_));
  INVx1_ASAP7_75t_R    g01(.A(p1), .Y(new_n35_));
  OR4x2_ASAP7_75t_R    g02(.A(new_n34_), .B(new_n35_), .C(p2), .D(p3), .Y(new_n36_));
  NAND2x1_ASAP7_75t_R  g03(.A(p2), .B(p3), .Y(new_n37_));
  NOR2x1_ASAP7_75t_R   g04(.A(p6), .B(p0), .Y(new_n38_));
  AOI22x1_ASAP7_75t_R  g05(.A1(new_n36_), .A2(new_n37_), .B1(new_n35_), .B2(new_n38_), .Y(o0));
  NOR2x1_ASAP7_75t_R   g06(.A(p0), .B(p1), .Y(new_n40_));
  NOR2x1_ASAP7_75t_R   g07(.A(p2), .B(p3), .Y(new_n41_));
  AO21x1_ASAP7_75t_R   g08(.A1(p2), .A2(p3), .B(p0), .Y(new_n42_));
  OAI21x1_ASAP7_75t_R  g09(.A1(new_n35_), .A2(new_n41_), .B(new_n42_), .Y(new_n43_));
  NAND2x1_ASAP7_75t_R  g10(.A(p0), .B(new_n35_), .Y(new_n44_));
  INVx1_ASAP7_75t_R    g11(.A(p3), .Y(new_n45_));
  NOR2x1_ASAP7_75t_R   g12(.A(p2), .B(new_n45_), .Y(new_n46_));
  NOR2x1_ASAP7_75t_R   g13(.A(new_n44_), .B(new_n46_), .Y(new_n47_));
  AOI211x1_ASAP7_75t_R g14(.A1(p6), .A2(new_n40_), .B(new_n43_), .C(new_n47_), .Y(o1));
  OR3x1_ASAP7_75t_R    g15(.A(new_n37_), .B(p6), .C(p1), .Y(new_n49_));
  OR3x1_ASAP7_75t_R    g16(.A(new_n45_), .B(p6), .C(p2), .Y(new_n50_));
  INVx1_ASAP7_75t_R    g17(.A(p2), .Y(new_n51_));
  OA21x2_ASAP7_75t_R   g18(.A1(p3), .A2(new_n51_), .B(p0), .Y(new_n52_));
  AOI22x1_ASAP7_75t_R  g19(.A1(new_n49_), .A2(new_n44_), .B1(new_n50_), .B2(new_n52_), .Y(o2));
  AND2x2_ASAP7_75t_R   g20(.A(p6), .B(p2), .Y(new_n54_));
  NOR2x1_ASAP7_75t_R   g21(.A(new_n51_), .B(new_n40_), .Y(new_n55_));
  AOI211x1_ASAP7_75t_R g22(.A1(p3), .A2(new_n54_), .B(new_n41_), .C(new_n55_), .Y(o3));
  NAND2x1_ASAP7_75t_R  g23(.A(p0), .B(p4), .Y(new_n57_));
  OA31x2_ASAP7_75t_R   g24(.A1(p6), .A2(new_n37_), .A3(new_n57_), .B1(new_n35_), .Y(new_n58_));
  AND3x1_ASAP7_75t_R   g25(.A(p6), .B(p0), .C(p2), .Y(new_n59_));
  INVx1_ASAP7_75t_R    g26(.A(p4), .Y(new_n60_));
  INVx1_ASAP7_75t_R    g27(.A(p5), .Y(new_n61_));
  OAI21x1_ASAP7_75t_R  g28(.A1(new_n60_), .A2(new_n61_), .B(p3), .Y(new_n62_));
  NAND2x1_ASAP7_75t_R  g29(.A(new_n59_), .B(new_n62_), .Y(new_n63_));
  AOI21x1_ASAP7_75t_R  g30(.A1(p6), .A2(new_n46_), .B(new_n35_), .Y(new_n64_));
  AOI21x1_ASAP7_75t_R  g31(.A1(new_n58_), .A2(new_n63_), .B(new_n64_), .Y(o4));
  AOI21x1_ASAP7_75t_R  g32(.A1(p2), .A2(p5), .B(p1), .Y(new_n66_));
  NAND2x1_ASAP7_75t_R  g33(.A(p2), .B(new_n45_), .Y(new_n67_));
  NAND2x1_ASAP7_75t_R  g34(.A(new_n66_), .B(new_n67_), .Y(new_n68_));
  AO21x1_ASAP7_75t_R   g35(.A1(p3), .A2(new_n51_), .B(new_n35_), .Y(new_n69_));
  AND3x1_ASAP7_75t_R   g36(.A(new_n68_), .B(p0), .C(new_n69_), .Y(o5));
  NOR2x1_ASAP7_75t_R   g37(.A(p1), .B(new_n41_), .Y(new_n71_));
  AOI21x1_ASAP7_75t_R  g38(.A1(p6), .A2(p0), .B(p1), .Y(new_n72_));
  NOR2x1_ASAP7_75t_R   g39(.A(new_n37_), .B(new_n72_), .Y(new_n73_));
  AO21x1_ASAP7_75t_R   g40(.A1(new_n37_), .A2(new_n71_), .B(new_n73_), .Y(o6));
  OR5x1_ASAP7_75t_R    g41(.A(p6), .B(new_n51_), .C(new_n45_), .D(p0), .E(p1), .Y(new_n75_));
  INVx1_ASAP7_75t_R    g42(.A(p6), .Y(new_n76_));
  OR3x1_ASAP7_75t_R    g43(.A(new_n37_), .B(new_n76_), .C(new_n35_), .Y(new_n77_));
  NAND3x1_ASAP7_75t_R  g44(.A(new_n75_), .B(new_n36_), .C(new_n77_), .Y(o7));
  NOR2x1_ASAP7_75t_R   g45(.A(new_n35_), .B(new_n41_), .Y(new_n79_));
  AOI221x1_ASAP7_75t_R g46(.A1(new_n37_), .A2(new_n79_), .B1(new_n50_), .B2(new_n35_), .C(new_n34_), .Y(o8));
  INVx1_ASAP7_75t_R    g47(.A(new_n44_), .Y(new_n81_));
  AOI21x1_ASAP7_75t_R  g48(.A1(new_n50_), .A2(new_n81_), .B(new_n43_), .Y(o9));
  NAND2x1_ASAP7_75t_R  g49(.A(p3), .B(new_n40_), .Y(new_n83_));
  NOR2x1_ASAP7_75t_R   g50(.A(p1), .B(p2), .Y(new_n84_));
  INVx1_ASAP7_75t_R    g51(.A(new_n84_), .Y(new_n85_));
  NAND2x1_ASAP7_75t_R  g52(.A(p0), .B(new_n76_), .Y(new_n86_));
  AO32x1_ASAP7_75t_R   g53(.A1(new_n69_), .A2(new_n83_), .A3(new_n85_), .B1(new_n46_), .B2(new_n86_), .Y(o10));
  AND3x1_ASAP7_75t_R   g54(.A(new_n41_), .B(new_n40_), .C(new_n76_), .Y(o11));
  NOR2x1_ASAP7_75t_R   g55(.A(p0), .B(p3), .Y(new_n89_));
  INVx1_ASAP7_75t_R    g56(.A(new_n89_), .Y(new_n90_));
  OR3x1_ASAP7_75t_R    g57(.A(p6), .B(p0), .C(p2), .Y(new_n91_));
  AO32x1_ASAP7_75t_R   g58(.A1(p1), .A2(new_n67_), .A3(new_n90_), .B1(new_n71_), .B2(new_n91_), .Y(o12));
  AND3x1_ASAP7_75t_R   g59(.A(new_n41_), .B(p6), .C(p1), .Y(o13));
  AND3x1_ASAP7_75t_R   g60(.A(new_n41_), .B(new_n76_), .C(p1), .Y(o14));
  AND5x1_ASAP7_75t_R   g61(.A(new_n76_), .B(new_n34_), .C(new_n45_), .D(p1), .E(p2), .Y(o15));
  AND3x1_ASAP7_75t_R   g62(.A(new_n54_), .B(p1), .C(new_n89_), .Y(o16));
  AND3x1_ASAP7_75t_R   g63(.A(p6), .B(p0), .C(p1), .Y(new_n97_));
  AND3x1_ASAP7_75t_R   g64(.A(new_n97_), .B(p2), .C(new_n45_), .Y(o17));
  AND5x1_ASAP7_75t_R   g65(.A(new_n76_), .B(new_n45_), .C(p0), .D(p1), .E(p2), .Y(o18));
  AND3x1_ASAP7_75t_R   g66(.A(new_n51_), .B(new_n45_), .C(p1), .Y(o19));
  OAI21x1_ASAP7_75t_R  g67(.A1(new_n45_), .A2(p4), .B(new_n59_), .Y(new_n101_));
  AOI21x1_ASAP7_75t_R  g68(.A1(new_n89_), .A2(new_n54_), .B(p1), .Y(new_n102_));
  AO21x1_ASAP7_75t_R   g69(.A1(p1), .A2(new_n37_), .B(new_n97_), .Y(new_n103_));
  AOI21x1_ASAP7_75t_R  g70(.A1(new_n101_), .A2(new_n102_), .B(new_n103_), .Y(o20));
  NAND2x1_ASAP7_75t_R  g71(.A(p2), .B(new_n89_), .Y(new_n105_));
  OR3x1_ASAP7_75t_R    g72(.A(new_n37_), .B(new_n57_), .C(p5), .Y(new_n106_));
  NAND2x1_ASAP7_75t_R  g73(.A(p6), .B(new_n35_), .Y(new_n107_));
  AOI21x1_ASAP7_75t_R  g74(.A1(new_n105_), .A2(new_n106_), .B(new_n107_), .Y(o21));
  AOI211x1_ASAP7_75t_R g75(.A1(p1), .A2(new_n37_), .B(new_n72_), .C(new_n97_), .Y(new_n109_));
  NAND2x1_ASAP7_75t_R  g76(.A(p3), .B(p5), .Y(new_n110_));
  OR3x1_ASAP7_75t_R    g77(.A(new_n110_), .B(p1), .C(p4), .Y(new_n111_));
  AND3x1_ASAP7_75t_R   g78(.A(new_n68_), .B(new_n109_), .C(new_n111_), .Y(o22));
  assign               o23 = 1'b1;
  AND2x2_ASAP7_75t_R   g79(.A(p6), .B(p0), .Y(new_n114_));
  OA211x2_ASAP7_75t_R  g80(.A1(new_n38_), .A2(new_n114_), .B(p3), .C(new_n84_), .Y(o24));
  AND3x1_ASAP7_75t_R   g81(.A(new_n46_), .B(p6), .C(new_n40_), .Y(o25));
endmodule


