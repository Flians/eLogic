// Benchmark "/tmp/" written by ABC on Wed Oct 21 14:30:13 2026

module \/tmp/  ( 
    p1, p5, p4, p3, p6, p0, p2,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25  );
  input  p1, p5, p4, p3, p6, p0, p2;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25;
  wire new_n34_, new_n35_, new_n36_, new_n37_, new_n38_, new_n39_, new_n41_,
    new_n42_, new_n43_, new_n44_, new_n45_, new_n46_, new_n47_, new_n48_,
    new_n50_, new_n51_, new_n53_, new_n55_, new_n56_, new_n57_, new_n58_,
    new_n59_, new_n60_, new_n61_, new_n62_, new_n63_, new_n64_, new_n66_,
    new_n67_, new_n69_, new_n70_, new_n71_, new_n73_, new_n75_, new_n78_,
    new_n79_, new_n80_, new_n83_, new_n84_, new_n85_, new_n86_, new_n95_,
    new_n96_, new_n98_, new_n100_;
  NOR2x1_ASAP7_75t_R   g00(.A(p3), .B(p2), .Y(new_n34_));
  AND3x1_ASAP7_75t_R   g01(.A(new_n34_), .B(p1), .C(p0), .Y(new_n35_));
  NAND2x1_ASAP7_75t_R  g02(.A(p3), .B(p2), .Y(new_n36_));
  INVx1_ASAP7_75t_R    g03(.A(new_n36_), .Y(new_n37_));
  NOR2x1_ASAP7_75t_R   g04(.A(p1), .B(p0), .Y(new_n38_));
  INVx1_ASAP7_75t_R    g05(.A(new_n38_), .Y(new_n39_));
  OA22x2_ASAP7_75t_R   g06(.A1(new_n35_), .A2(new_n37_), .B1(p6), .B2(new_n39_), .Y(o0));
  INVx1_ASAP7_75t_R    g07(.A(p0), .Y(new_n41_));
  NOR2x1_ASAP7_75t_R   g08(.A(p1), .B(new_n41_), .Y(new_n42_));
  INVx1_ASAP7_75t_R    g09(.A(p2), .Y(new_n43_));
  NAND2x1_ASAP7_75t_R  g10(.A(p3), .B(new_n43_), .Y(new_n44_));
  INVx1_ASAP7_75t_R    g11(.A(p3), .Y(new_n45_));
  OR3x1_ASAP7_75t_R    g12(.A(new_n45_), .B(new_n43_), .C(p6), .Y(new_n46_));
  INVx1_ASAP7_75t_R    g13(.A(p1), .Y(new_n47_));
  AOI21x1_ASAP7_75t_R  g14(.A1(p0), .A2(new_n34_), .B(new_n47_), .Y(new_n48_));
  AOI221x1_ASAP7_75t_R g15(.A1(new_n42_), .A2(new_n44_), .B1(new_n46_), .B2(new_n38_), .C(new_n48_), .Y(o1));
  OA21x2_ASAP7_75t_R   g16(.A1(p3), .A2(new_n43_), .B(p0), .Y(new_n50_));
  OR3x1_ASAP7_75t_R    g17(.A(new_n45_), .B(p6), .C(p2), .Y(new_n51_));
  AOI221x1_ASAP7_75t_R g18(.A1(new_n41_), .A2(new_n46_), .B1(new_n50_), .B2(new_n51_), .C(p1), .Y(o2));
  AND3x1_ASAP7_75t_R   g19(.A(p3), .B(p6), .C(p2), .Y(new_n53_));
  AOI211x1_ASAP7_75t_R g20(.A1(p2), .A2(new_n39_), .B(new_n34_), .C(new_n53_), .Y(o3));
  NAND2x1_ASAP7_75t_R  g21(.A(p4), .B(p0), .Y(new_n55_));
  OA31x2_ASAP7_75t_R   g22(.A1(p6), .A2(new_n36_), .A3(new_n55_), .B1(new_n47_), .Y(new_n56_));
  INVx1_ASAP7_75t_R    g23(.A(p5), .Y(new_n57_));
  AOI21x1_ASAP7_75t_R  g24(.A1(p3), .A2(new_n57_), .B(new_n43_), .Y(new_n58_));
  INVx1_ASAP7_75t_R    g25(.A(p4), .Y(new_n59_));
  NAND3x1_ASAP7_75t_R  g26(.A(new_n59_), .B(p5), .C(p3), .Y(new_n60_));
  AND2x2_ASAP7_75t_R   g27(.A(p6), .B(p0), .Y(new_n61_));
  NAND3x1_ASAP7_75t_R  g28(.A(new_n58_), .B(new_n60_), .C(new_n61_), .Y(new_n62_));
  INVx1_ASAP7_75t_R    g29(.A(p6), .Y(new_n63_));
  OA21x2_ASAP7_75t_R   g30(.A1(new_n63_), .A2(new_n44_), .B(p1), .Y(new_n64_));
  AOI21x1_ASAP7_75t_R  g31(.A1(new_n56_), .A2(new_n62_), .B(new_n64_), .Y(o4));
  AND2x2_ASAP7_75t_R   g32(.A(p1), .B(new_n44_), .Y(new_n66_));
  OAI21x1_ASAP7_75t_R  g33(.A1(p1), .A2(new_n58_), .B(p0), .Y(new_n67_));
  NOR2x1_ASAP7_75t_R   g34(.A(new_n66_), .B(new_n67_), .Y(o5));
  NAND2x1_ASAP7_75t_R  g35(.A(p6), .B(p0), .Y(new_n69_));
  AND3x1_ASAP7_75t_R   g36(.A(new_n69_), .B(p3), .C(p2), .Y(new_n70_));
  AND2x2_ASAP7_75t_R   g37(.A(p1), .B(new_n36_), .Y(new_n71_));
  AOI211x1_ASAP7_75t_R g38(.A1(new_n47_), .A2(new_n70_), .B(new_n34_), .C(new_n71_), .Y(o6));
  AND3x1_ASAP7_75t_R   g39(.A(new_n47_), .B(new_n63_), .C(new_n41_), .Y(new_n73_));
  AO221x2_ASAP7_75t_R  g40(.A1(p1), .A2(new_n53_), .B1(new_n73_), .B2(new_n37_), .C(new_n35_), .Y(o7));
  INVx1_ASAP7_75t_R    g41(.A(new_n34_), .Y(new_n75_));
  AOI221x1_ASAP7_75t_R g42(.A1(new_n51_), .A2(new_n47_), .B1(new_n71_), .B2(new_n75_), .C(new_n41_), .Y(o8));
  AOI221x1_ASAP7_75t_R g43(.A1(new_n41_), .A2(new_n36_), .B1(new_n51_), .B2(new_n42_), .C(new_n48_), .Y(o9));
  NOR2x1_ASAP7_75t_R   g44(.A(p1), .B(p2), .Y(new_n78_));
  AO21x1_ASAP7_75t_R   g45(.A1(p3), .A2(new_n38_), .B(new_n78_), .Y(new_n79_));
  AO21x1_ASAP7_75t_R   g46(.A1(new_n63_), .A2(p0), .B(new_n44_), .Y(new_n80_));
  OAI21x1_ASAP7_75t_R  g47(.A1(new_n79_), .A2(new_n66_), .B(new_n80_), .Y(o10));
  AND3x1_ASAP7_75t_R   g48(.A(new_n38_), .B(new_n34_), .C(new_n63_), .Y(o11));
  NOR2x1_ASAP7_75t_R   g49(.A(p3), .B(p0), .Y(new_n83_));
  AND3x1_ASAP7_75t_R   g50(.A(new_n45_), .B(p1), .C(p2), .Y(new_n84_));
  NOR2x1_ASAP7_75t_R   g51(.A(p6), .B(p0), .Y(new_n85_));
  OA21x2_ASAP7_75t_R   g52(.A1(new_n45_), .A2(new_n85_), .B(new_n78_), .Y(new_n86_));
  AOI211x1_ASAP7_75t_R g53(.A1(p1), .A2(new_n83_), .B(new_n84_), .C(new_n86_), .Y(o12));
  AND3x1_ASAP7_75t_R   g54(.A(new_n34_), .B(p1), .C(p6), .Y(o13));
  AND3x1_ASAP7_75t_R   g55(.A(new_n34_), .B(p1), .C(new_n63_), .Y(o14));
  AND2x2_ASAP7_75t_R   g56(.A(new_n85_), .B(new_n84_), .Y(o15));
  AND3x1_ASAP7_75t_R   g57(.A(new_n84_), .B(p6), .C(new_n41_), .Y(o16));
  AND2x2_ASAP7_75t_R   g58(.A(new_n61_), .B(new_n84_), .Y(o17));
  AND3x1_ASAP7_75t_R   g59(.A(new_n84_), .B(new_n63_), .C(p0), .Y(o18));
  AND3x1_ASAP7_75t_R   g60(.A(new_n45_), .B(new_n43_), .C(p1), .Y(o19));
  AND3x1_ASAP7_75t_R   g61(.A(new_n47_), .B(p6), .C(p2), .Y(new_n95_));
  NAND2x1_ASAP7_75t_R  g62(.A(p3), .B(new_n55_), .Y(new_n96_));
  AO32x1_ASAP7_75t_R   g63(.A1(p1), .A2(new_n37_), .A3(new_n69_), .B1(new_n95_), .B2(new_n96_), .Y(o20));
  AO21x1_ASAP7_75t_R   g64(.A1(new_n57_), .A2(p3), .B(new_n83_), .Y(new_n98_));
  AND3x1_ASAP7_75t_R   g65(.A(new_n98_), .B(new_n96_), .C(new_n95_), .Y(o21));
  OA21x2_ASAP7_75t_R   g66(.A1(new_n36_), .A2(new_n61_), .B(p1), .Y(new_n100_));
  AOI21x1_ASAP7_75t_R  g67(.A1(new_n47_), .A2(new_n62_), .B(new_n100_), .Y(o22));
  assign               o23 = 1'b1;
  OA211x2_ASAP7_75t_R  g68(.A1(new_n85_), .A2(new_n61_), .B(p3), .C(new_n78_), .Y(o24));
  AND5x1_ASAP7_75t_R   g69(.A(new_n47_), .B(new_n41_), .C(new_n43_), .D(p3), .E(p6), .Y(o25));
endmodule


