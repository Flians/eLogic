// Benchmark "/tmp/" written by ABC on Wed Oct 21 14:30:11 2026

module \/tmp/  ( 
    p2, p0, p5, p6, p3, p1, p4,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25  );
  input  p2, p0, p5, p6, p3, p1, p4;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25;
  wire new_n34_, new_n35_, new_n36_, new_n37_, new_n38_, new_n39_, new_n41_,
    new_n43_, new_n44_, new_n45_, new_n46_, new_n47_, new_n48_, new_n49_,
    new_n51_, new_n52_, new_n53_, new_n55_, new_n57_, new_n58_, new_n59_,
    new_n60_, new_n61_, new_n62_, new_n63_, new_n64_, new_n65_, new_n67_,
    new_n68_, new_n69_, new_n71_, new_n72_, new_n73_, new_n75_, new_n76_,
    new_n77_, new_n80_, new_n82_, new_n83_, new_n84_, new_n85_, new_n88_,
    new_n89_, new_n90_, new_n95_, new_n99_, new_n100_, new_n101_,
    new_n103_, new_n104_;
  INVx1_ASAP7_75t_R    g00(.A(p6), .Y(new_n34_));
  NOR2x1_ASAP7_75t_R   g01(.A(p0), .B(p1), .Y(new_n35_));
  NAND2x1_ASAP7_75t_R  g02(.A(p2), .B(p3), .Y(new_n36_));
  AO21x1_ASAP7_75t_R   g03(.A1(new_n34_), .A2(new_n35_), .B(new_n36_), .Y(new_n37_));
  INVx1_ASAP7_75t_R    g04(.A(p2), .Y(new_n38_));
  INVx1_ASAP7_75t_R    g05(.A(p3), .Y(new_n39_));
  AND3x1_ASAP7_75t_R   g06(.A(new_n38_), .B(new_n39_), .C(p1), .Y(o19));
  NAND2x1_ASAP7_75t_R  g07(.A(p0), .B(o19), .Y(new_n41_));
  NAND2x1_ASAP7_75t_R  g08(.A(new_n37_), .B(new_n41_), .Y(o0));
  OR3x1_ASAP7_75t_R    g09(.A(new_n38_), .B(new_n39_), .C(p6), .Y(new_n43_));
  NOR2x1_ASAP7_75t_R   g10(.A(p2), .B(p3), .Y(new_n44_));
  INVx1_ASAP7_75t_R    g11(.A(p1), .Y(new_n45_));
  AOI21x1_ASAP7_75t_R  g12(.A1(p0), .A2(new_n44_), .B(new_n45_), .Y(new_n46_));
  NAND2x1_ASAP7_75t_R  g13(.A(p0), .B(new_n45_), .Y(new_n47_));
  NOR2x1_ASAP7_75t_R   g14(.A(p2), .B(new_n39_), .Y(new_n48_));
  NOR2x1_ASAP7_75t_R   g15(.A(new_n47_), .B(new_n48_), .Y(new_n49_));
  AOI211x1_ASAP7_75t_R g16(.A1(new_n35_), .A2(new_n43_), .B(new_n46_), .C(new_n49_), .Y(o1));
  OA21x2_ASAP7_75t_R   g17(.A1(p3), .A2(new_n38_), .B(p0), .Y(new_n51_));
  OR3x1_ASAP7_75t_R    g18(.A(new_n39_), .B(p2), .C(p6), .Y(new_n52_));
  INVx1_ASAP7_75t_R    g19(.A(p0), .Y(new_n53_));
  AOI221x1_ASAP7_75t_R g20(.A1(new_n51_), .A2(new_n52_), .B1(new_n53_), .B2(new_n43_), .C(p1), .Y(o2));
  INVx1_ASAP7_75t_R    g21(.A(new_n44_), .Y(new_n55_));
  OA221x2_ASAP7_75t_R  g22(.A1(new_n38_), .A2(new_n35_), .B1(new_n34_), .B2(new_n36_), .C(new_n55_), .Y(o3));
  NAND2x1_ASAP7_75t_R  g23(.A(p0), .B(p4), .Y(new_n57_));
  OA31x2_ASAP7_75t_R   g24(.A1(p6), .A2(new_n36_), .A3(new_n57_), .B1(new_n45_), .Y(new_n58_));
  INVx1_ASAP7_75t_R    g25(.A(p5), .Y(new_n59_));
  NAND2x1_ASAP7_75t_R  g26(.A(p3), .B(new_n59_), .Y(new_n60_));
  INVx1_ASAP7_75t_R    g27(.A(p4), .Y(new_n61_));
  NAND2x1_ASAP7_75t_R  g28(.A(p3), .B(new_n61_), .Y(new_n62_));
  AND3x1_ASAP7_75t_R   g29(.A(p2), .B(p0), .C(p6), .Y(new_n63_));
  NAND3x1_ASAP7_75t_R  g30(.A(new_n60_), .B(new_n62_), .C(new_n63_), .Y(new_n64_));
  AOI21x1_ASAP7_75t_R  g31(.A1(p6), .A2(new_n48_), .B(new_n45_), .Y(new_n65_));
  AOI21x1_ASAP7_75t_R  g32(.A1(new_n58_), .A2(new_n64_), .B(new_n65_), .Y(o4));
  AO21x1_ASAP7_75t_R   g33(.A1(p3), .A2(new_n38_), .B(new_n45_), .Y(new_n67_));
  AOI21x1_ASAP7_75t_R  g34(.A1(p2), .A2(p5), .B(p1), .Y(new_n68_));
  OAI21x1_ASAP7_75t_R  g35(.A1(new_n38_), .A2(p3), .B(new_n68_), .Y(new_n69_));
  AND3x1_ASAP7_75t_R   g36(.A(new_n67_), .B(new_n69_), .C(p0), .Y(o5));
  AND2x2_ASAP7_75t_R   g37(.A(p0), .B(p6), .Y(new_n71_));
  NOR2x1_ASAP7_75t_R   g38(.A(new_n36_), .B(new_n71_), .Y(new_n72_));
  AND2x2_ASAP7_75t_R   g39(.A(p1), .B(new_n36_), .Y(new_n73_));
  AOI211x1_ASAP7_75t_R g40(.A1(new_n45_), .A2(new_n72_), .B(new_n44_), .C(new_n73_), .Y(o6));
  NOR2x1_ASAP7_75t_R   g41(.A(p0), .B(p6), .Y(new_n75_));
  AND2x2_ASAP7_75t_R   g42(.A(p6), .B(p1), .Y(new_n76_));
  AOI21x1_ASAP7_75t_R  g43(.A1(new_n45_), .A2(new_n75_), .B(new_n76_), .Y(new_n77_));
  OAI21x1_ASAP7_75t_R  g44(.A1(new_n36_), .A2(new_n77_), .B(new_n41_), .Y(o7));
  AOI221x1_ASAP7_75t_R g45(.A1(new_n52_), .A2(new_n45_), .B1(new_n73_), .B2(new_n55_), .C(new_n53_), .Y(o8));
  INVx1_ASAP7_75t_R    g46(.A(new_n47_), .Y(new_n80_));
  AOI221x1_ASAP7_75t_R g47(.A1(new_n53_), .A2(new_n36_), .B1(new_n80_), .B2(new_n52_), .C(new_n46_), .Y(o9));
  NAND2x1_ASAP7_75t_R  g48(.A(p3), .B(new_n35_), .Y(new_n82_));
  NOR2x1_ASAP7_75t_R   g49(.A(p2), .B(p1), .Y(new_n83_));
  INVx1_ASAP7_75t_R    g50(.A(new_n83_), .Y(new_n84_));
  NAND2x1_ASAP7_75t_R  g51(.A(p0), .B(new_n34_), .Y(new_n85_));
  AO32x1_ASAP7_75t_R   g52(.A1(new_n67_), .A2(new_n82_), .A3(new_n84_), .B1(new_n48_), .B2(new_n85_), .Y(o10));
  AND3x1_ASAP7_75t_R   g53(.A(new_n35_), .B(new_n44_), .C(new_n34_), .Y(o11));
  NOR2x1_ASAP7_75t_R   g54(.A(p0), .B(p3), .Y(new_n88_));
  AND3x1_ASAP7_75t_R   g55(.A(new_n39_), .B(p2), .C(p1), .Y(new_n89_));
  OA21x2_ASAP7_75t_R   g56(.A1(new_n39_), .A2(new_n75_), .B(new_n83_), .Y(new_n90_));
  AOI211x1_ASAP7_75t_R g57(.A1(p1), .A2(new_n88_), .B(new_n89_), .C(new_n90_), .Y(o12));
  AND3x1_ASAP7_75t_R   g58(.A(new_n44_), .B(p6), .C(p1), .Y(o13));
  AND3x1_ASAP7_75t_R   g59(.A(new_n44_), .B(new_n34_), .C(p1), .Y(o14));
  AND2x2_ASAP7_75t_R   g60(.A(new_n75_), .B(new_n89_), .Y(o15));
  AND2x2_ASAP7_75t_R   g61(.A(p2), .B(p6), .Y(new_n95_));
  AND3x1_ASAP7_75t_R   g62(.A(new_n95_), .B(p1), .C(new_n88_), .Y(o16));
  AND2x2_ASAP7_75t_R   g63(.A(new_n71_), .B(new_n89_), .Y(o17));
  AND3x1_ASAP7_75t_R   g64(.A(new_n89_), .B(p0), .C(new_n34_), .Y(o18));
  NAND2x1_ASAP7_75t_R  g65(.A(new_n63_), .B(new_n62_), .Y(new_n99_));
  AOI21x1_ASAP7_75t_R  g66(.A1(new_n88_), .A2(new_n95_), .B(p1), .Y(new_n100_));
  OA21x2_ASAP7_75t_R   g67(.A1(new_n36_), .A2(new_n71_), .B(p1), .Y(new_n101_));
  AOI21x1_ASAP7_75t_R  g68(.A1(new_n99_), .A2(new_n100_), .B(new_n101_), .Y(o20));
  NAND2x1_ASAP7_75t_R  g69(.A(p2), .B(new_n88_), .Y(new_n103_));
  OR3x1_ASAP7_75t_R    g70(.A(new_n36_), .B(new_n57_), .C(p5), .Y(new_n104_));
  AOI211x1_ASAP7_75t_R g71(.A1(new_n103_), .A2(new_n104_), .B(new_n34_), .C(p1), .Y(o21));
  AOI21x1_ASAP7_75t_R  g72(.A1(new_n45_), .A2(new_n64_), .B(new_n101_), .Y(o22));
  assign               o23 = 1'b1;
  OA211x2_ASAP7_75t_R  g73(.A1(new_n75_), .A2(new_n71_), .B(p3), .C(new_n83_), .Y(o24));
  AND3x1_ASAP7_75t_R   g74(.A(new_n48_), .B(p6), .C(new_n35_), .Y(o25));
endmodule


