// Benchmark "/tmp/" written by ABC on Wed Oct 21 14:30:17 2026

module \/tmp/  ( 
    p4, p2, p5, p6, p0, p1, p3,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25  );
  input  p4, p2, p5, p6, p0, p1, p3;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25;
  wire new_n34_, new_n35_, new_n36_, new_n37_, new_n38_, new_n40_, new_n41_,
    new_n42_, new_n43_, new_n44_, new_n45_, new_n46_, new_n47_, new_n48_,
    new_n50_, new_n51_, new_n52_, new_n54_, new_n55_, new_n56_, new_n58_,
    new_n59_, new_n60_, new_n61_, new_n62_, new_n63_, new_n64_, new_n65_,
    new_n66_, new_n68_, new_n69_, new_n70_, new_n72_, new_n73_, new_n75_,
    new_n79_, new_n80_, new_n81_, new_n84_, new_n85_, new_n86_, new_n91_,
    new_n96_, new_n97_, new_n98_, new_n100_;
  OR3x1_ASAP7_75t_R    g00(.A(p6), .B(p0), .C(p1), .Y(new_n34_));
  NAND2x1_ASAP7_75t_R  g01(.A(p2), .B(p3), .Y(new_n35_));
  INVx1_ASAP7_75t_R    g02(.A(new_n35_), .Y(new_n36_));
  NOR2x1_ASAP7_75t_R   g03(.A(p2), .B(p3), .Y(new_n37_));
  AND3x1_ASAP7_75t_R   g04(.A(new_n37_), .B(p0), .C(p1), .Y(new_n38_));
  AO21x1_ASAP7_75t_R   g05(.A1(new_n34_), .A2(new_n36_), .B(new_n38_), .Y(o0));
  INVx1_ASAP7_75t_R    g06(.A(p2), .Y(new_n40_));
  NAND2x1_ASAP7_75t_R  g07(.A(p3), .B(new_n40_), .Y(new_n41_));
  INVx1_ASAP7_75t_R    g08(.A(p0), .Y(new_n42_));
  NOR2x1_ASAP7_75t_R   g09(.A(p1), .B(new_n42_), .Y(new_n43_));
  INVx1_ASAP7_75t_R    g10(.A(p3), .Y(new_n44_));
  OR3x1_ASAP7_75t_R    g11(.A(new_n40_), .B(new_n44_), .C(p6), .Y(new_n45_));
  NOR2x1_ASAP7_75t_R   g12(.A(p0), .B(p1), .Y(new_n46_));
  INVx1_ASAP7_75t_R    g13(.A(p1), .Y(new_n47_));
  AOI21x1_ASAP7_75t_R  g14(.A1(p0), .A2(new_n37_), .B(new_n47_), .Y(new_n48_));
  AOI221x1_ASAP7_75t_R g15(.A1(new_n41_), .A2(new_n43_), .B1(new_n45_), .B2(new_n46_), .C(new_n48_), .Y(o1));
  NOR2x1_ASAP7_75t_R   g16(.A(p3), .B(new_n40_), .Y(new_n50_));
  NOR2x1_ASAP7_75t_R   g17(.A(new_n42_), .B(new_n50_), .Y(new_n51_));
  OR3x1_ASAP7_75t_R    g18(.A(new_n44_), .B(p2), .C(p6), .Y(new_n52_));
  AOI221x1_ASAP7_75t_R g19(.A1(new_n42_), .A2(new_n45_), .B1(new_n51_), .B2(new_n52_), .C(p1), .Y(o2));
  INVx1_ASAP7_75t_R    g20(.A(p6), .Y(new_n54_));
  AO21x1_ASAP7_75t_R   g21(.A1(new_n42_), .A2(new_n47_), .B(new_n40_), .Y(new_n55_));
  INVx1_ASAP7_75t_R    g22(.A(new_n37_), .Y(new_n56_));
  OA211x2_ASAP7_75t_R  g23(.A1(new_n54_), .A2(new_n35_), .B(new_n55_), .C(new_n56_), .Y(o3));
  NAND2x1_ASAP7_75t_R  g24(.A(p4), .B(p0), .Y(new_n58_));
  OA31x2_ASAP7_75t_R   g25(.A1(p6), .A2(new_n35_), .A3(new_n58_), .B1(new_n47_), .Y(new_n59_));
  INVx1_ASAP7_75t_R    g26(.A(p5), .Y(new_n60_));
  AOI21x1_ASAP7_75t_R  g27(.A1(p3), .A2(new_n60_), .B(new_n40_), .Y(new_n61_));
  INVx1_ASAP7_75t_R    g28(.A(p4), .Y(new_n62_));
  NAND3x1_ASAP7_75t_R  g29(.A(new_n62_), .B(p5), .C(p3), .Y(new_n63_));
  AND2x2_ASAP7_75t_R   g30(.A(p6), .B(p0), .Y(new_n64_));
  NAND3x1_ASAP7_75t_R  g31(.A(new_n61_), .B(new_n63_), .C(new_n64_), .Y(new_n65_));
  OA21x2_ASAP7_75t_R   g32(.A1(new_n54_), .A2(new_n41_), .B(p1), .Y(new_n66_));
  AOI21x1_ASAP7_75t_R  g33(.A1(new_n59_), .A2(new_n65_), .B(new_n66_), .Y(o4));
  NOR2x1_ASAP7_75t_R   g34(.A(p2), .B(new_n44_), .Y(new_n68_));
  NOR2x1_ASAP7_75t_R   g35(.A(new_n47_), .B(new_n68_), .Y(new_n69_));
  OAI21x1_ASAP7_75t_R  g36(.A1(p1), .A2(new_n61_), .B(p0), .Y(new_n70_));
  NOR2x1_ASAP7_75t_R   g37(.A(new_n69_), .B(new_n70_), .Y(o5));
  NOR2x1_ASAP7_75t_R   g38(.A(new_n35_), .B(new_n64_), .Y(new_n72_));
  AND2x2_ASAP7_75t_R   g39(.A(p1), .B(new_n35_), .Y(new_n73_));
  AOI211x1_ASAP7_75t_R g40(.A1(new_n47_), .A2(new_n72_), .B(new_n37_), .C(new_n73_), .Y(o6));
  OAI21x1_ASAP7_75t_R  g41(.A1(new_n54_), .A2(new_n47_), .B(new_n34_), .Y(new_n75_));
  AO21x1_ASAP7_75t_R   g42(.A1(new_n36_), .A2(new_n75_), .B(new_n38_), .Y(o7));
  AOI221x1_ASAP7_75t_R g43(.A1(new_n52_), .A2(new_n47_), .B1(new_n73_), .B2(new_n56_), .C(new_n42_), .Y(o8));
  AOI221x1_ASAP7_75t_R g44(.A1(new_n42_), .A2(new_n35_), .B1(new_n52_), .B2(new_n43_), .C(new_n48_), .Y(o9));
  NOR2x1_ASAP7_75t_R   g45(.A(p2), .B(p1), .Y(new_n79_));
  AO21x1_ASAP7_75t_R   g46(.A1(p3), .A2(new_n46_), .B(new_n79_), .Y(new_n80_));
  AO21x1_ASAP7_75t_R   g47(.A1(new_n54_), .A2(p0), .B(new_n41_), .Y(new_n81_));
  OAI21x1_ASAP7_75t_R  g48(.A1(new_n69_), .A2(new_n80_), .B(new_n81_), .Y(o10));
  AND3x1_ASAP7_75t_R   g49(.A(new_n37_), .B(new_n46_), .C(new_n54_), .Y(o11));
  NOR2x1_ASAP7_75t_R   g50(.A(p6), .B(p0), .Y(new_n84_));
  OA21x2_ASAP7_75t_R   g51(.A1(new_n44_), .A2(new_n84_), .B(new_n79_), .Y(new_n85_));
  OA211x2_ASAP7_75t_R  g52(.A1(p2), .A2(new_n42_), .B(new_n44_), .C(p1), .Y(new_n86_));
  NOR2x1_ASAP7_75t_R   g53(.A(new_n85_), .B(new_n86_), .Y(o12));
  AND3x1_ASAP7_75t_R   g54(.A(new_n37_), .B(p6), .C(p1), .Y(o13));
  AND3x1_ASAP7_75t_R   g55(.A(new_n37_), .B(new_n54_), .C(p1), .Y(o14));
  AND3x1_ASAP7_75t_R   g56(.A(new_n50_), .B(p1), .C(new_n84_), .Y(o15));
  AND3x1_ASAP7_75t_R   g57(.A(new_n42_), .B(new_n44_), .C(p2), .Y(new_n91_));
  AND3x1_ASAP7_75t_R   g58(.A(new_n91_), .B(p6), .C(p1), .Y(o16));
  AND3x1_ASAP7_75t_R   g59(.A(new_n50_), .B(p1), .C(new_n64_), .Y(o17));
  AND5x1_ASAP7_75t_R   g60(.A(p2), .B(new_n54_), .C(new_n44_), .D(p0), .E(p1), .Y(o18));
  AND3x1_ASAP7_75t_R   g61(.A(new_n40_), .B(new_n44_), .C(p1), .Y(o19));
  NAND2x1_ASAP7_75t_R  g62(.A(p2), .B(p6), .Y(new_n96_));
  AO21x1_ASAP7_75t_R   g63(.A1(p3), .A2(new_n58_), .B(new_n96_), .Y(new_n97_));
  OA21x2_ASAP7_75t_R   g64(.A1(new_n35_), .A2(new_n64_), .B(p1), .Y(new_n98_));
  AOI21x1_ASAP7_75t_R  g65(.A1(new_n47_), .A2(new_n97_), .B(new_n98_), .Y(o20));
  AND5x1_ASAP7_75t_R   g66(.A(p4), .B(new_n60_), .C(p2), .D(p0), .E(p3), .Y(new_n100_));
  OA211x2_ASAP7_75t_R  g67(.A1(new_n91_), .A2(new_n100_), .B(p6), .C(new_n47_), .Y(o21));
  AOI21x1_ASAP7_75t_R  g68(.A1(new_n47_), .A2(new_n65_), .B(new_n98_), .Y(o22));
  assign               o23 = 1'b1;
  OA211x2_ASAP7_75t_R  g69(.A1(new_n84_), .A2(new_n64_), .B(p3), .C(new_n79_), .Y(o24));
  AND3x1_ASAP7_75t_R   g70(.A(new_n68_), .B(p6), .C(new_n46_), .Y(o25));
endmodule


