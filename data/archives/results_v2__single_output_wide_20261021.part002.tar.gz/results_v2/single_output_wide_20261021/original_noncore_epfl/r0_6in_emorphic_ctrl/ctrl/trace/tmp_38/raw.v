// Benchmark "/tmp/" written by ABC on Wed Oct 21 14:30:16 2026

module \/tmp/  ( 
    p1, p4, p6, p0, p2, p3, p5,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25  );
  input  p1, p4, p6, p0, p2, p3, p5;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25;
  wire new_n34_, new_n35_, new_n36_, new_n37_, new_n38_, new_n39_, new_n41_,
    new_n43_, new_n44_, new_n45_, new_n46_, new_n47_, new_n48_, new_n49_,
    new_n51_, new_n52_, new_n54_, new_n55_, new_n56_, new_n58_, new_n59_,
    new_n60_, new_n61_, new_n62_, new_n63_, new_n64_, new_n65_, new_n66_,
    new_n68_, new_n69_, new_n71_, new_n72_, new_n74_, new_n75_, new_n79_,
    new_n80_, new_n81_, new_n84_, new_n85_, new_n86_, new_n90_, new_n95_,
    new_n96_, new_n98_, new_n99_;
  INVx1_ASAP7_75t_R    g00(.A(p6), .Y(new_n34_));
  NOR2x1_ASAP7_75t_R   g01(.A(p1), .B(p0), .Y(new_n35_));
  NAND2x1_ASAP7_75t_R  g02(.A(p2), .B(p3), .Y(new_n36_));
  AO21x1_ASAP7_75t_R   g03(.A1(new_n34_), .A2(new_n35_), .B(new_n36_), .Y(new_n37_));
  INVx1_ASAP7_75t_R    g04(.A(p2), .Y(new_n38_));
  INVx1_ASAP7_75t_R    g05(.A(p3), .Y(new_n39_));
  AND3x1_ASAP7_75t_R   g06(.A(new_n38_), .B(new_n39_), .C(p1), .Y(o19));
  NAND2x1_ASAP7_75t_R  g07(.A(p0), .B(o19), .Y(new_n41_));
  NAND2x1_ASAP7_75t_R  g08(.A(new_n37_), .B(new_n41_), .Y(o0));
  NAND2x1_ASAP7_75t_R  g09(.A(p3), .B(new_n38_), .Y(new_n43_));
  INVx1_ASAP7_75t_R    g10(.A(p0), .Y(new_n44_));
  NOR2x1_ASAP7_75t_R   g11(.A(p1), .B(new_n44_), .Y(new_n45_));
  OR3x1_ASAP7_75t_R    g12(.A(new_n38_), .B(new_n39_), .C(p6), .Y(new_n46_));
  NOR2x1_ASAP7_75t_R   g13(.A(p2), .B(p3), .Y(new_n47_));
  INVx1_ASAP7_75t_R    g14(.A(p1), .Y(new_n48_));
  AOI21x1_ASAP7_75t_R  g15(.A1(p0), .A2(new_n47_), .B(new_n48_), .Y(new_n49_));
  AOI221x1_ASAP7_75t_R g16(.A1(new_n43_), .A2(new_n45_), .B1(new_n46_), .B2(new_n35_), .C(new_n49_), .Y(o1));
  OA21x2_ASAP7_75t_R   g17(.A1(p3), .A2(new_n38_), .B(p0), .Y(new_n51_));
  OR3x1_ASAP7_75t_R    g18(.A(new_n39_), .B(p6), .C(p2), .Y(new_n52_));
  AOI221x1_ASAP7_75t_R g19(.A1(new_n51_), .A2(new_n52_), .B1(new_n44_), .B2(new_n46_), .C(p1), .Y(o2));
  NAND2x1_ASAP7_75t_R  g20(.A(p6), .B(p2), .Y(new_n54_));
  AO21x1_ASAP7_75t_R   g21(.A1(new_n48_), .A2(new_n44_), .B(new_n38_), .Y(new_n55_));
  INVx1_ASAP7_75t_R    g22(.A(new_n47_), .Y(new_n56_));
  OA211x2_ASAP7_75t_R  g23(.A1(new_n39_), .A2(new_n54_), .B(new_n55_), .C(new_n56_), .Y(o3));
  NAND2x1_ASAP7_75t_R  g24(.A(p4), .B(p0), .Y(new_n58_));
  OA31x2_ASAP7_75t_R   g25(.A1(p6), .A2(new_n36_), .A3(new_n58_), .B1(new_n48_), .Y(new_n59_));
  INVx1_ASAP7_75t_R    g26(.A(p5), .Y(new_n60_));
  AOI21x1_ASAP7_75t_R  g27(.A1(p3), .A2(new_n60_), .B(new_n38_), .Y(new_n61_));
  INVx1_ASAP7_75t_R    g28(.A(p4), .Y(new_n62_));
  NAND3x1_ASAP7_75t_R  g29(.A(new_n62_), .B(p3), .C(p5), .Y(new_n63_));
  AND2x2_ASAP7_75t_R   g30(.A(p6), .B(p0), .Y(new_n64_));
  NAND3x1_ASAP7_75t_R  g31(.A(new_n61_), .B(new_n63_), .C(new_n64_), .Y(new_n65_));
  OA21x2_ASAP7_75t_R   g32(.A1(new_n34_), .A2(new_n43_), .B(p1), .Y(new_n66_));
  AOI21x1_ASAP7_75t_R  g33(.A1(new_n59_), .A2(new_n65_), .B(new_n66_), .Y(o4));
  AND2x2_ASAP7_75t_R   g34(.A(p1), .B(new_n43_), .Y(new_n68_));
  OAI21x1_ASAP7_75t_R  g35(.A1(p1), .A2(new_n61_), .B(p0), .Y(new_n69_));
  NOR2x1_ASAP7_75t_R   g36(.A(new_n68_), .B(new_n69_), .Y(o5));
  NOR2x1_ASAP7_75t_R   g37(.A(new_n36_), .B(new_n64_), .Y(new_n71_));
  AND2x2_ASAP7_75t_R   g38(.A(p1), .B(new_n36_), .Y(new_n72_));
  AOI211x1_ASAP7_75t_R g39(.A1(new_n48_), .A2(new_n71_), .B(new_n47_), .C(new_n72_), .Y(o6));
  OR3x1_ASAP7_75t_R    g40(.A(p1), .B(p6), .C(p0), .Y(new_n74_));
  OA21x2_ASAP7_75t_R   g41(.A1(new_n48_), .A2(new_n34_), .B(new_n74_), .Y(new_n75_));
  OAI21x1_ASAP7_75t_R  g42(.A1(new_n36_), .A2(new_n75_), .B(new_n41_), .Y(o7));
  AOI221x1_ASAP7_75t_R g43(.A1(new_n52_), .A2(new_n48_), .B1(new_n72_), .B2(new_n56_), .C(new_n44_), .Y(o8));
  AOI221x1_ASAP7_75t_R g44(.A1(new_n44_), .A2(new_n36_), .B1(new_n52_), .B2(new_n45_), .C(new_n49_), .Y(o9));
  NOR2x1_ASAP7_75t_R   g45(.A(p1), .B(p2), .Y(new_n79_));
  AO21x1_ASAP7_75t_R   g46(.A1(p3), .A2(new_n35_), .B(new_n79_), .Y(new_n80_));
  AO21x1_ASAP7_75t_R   g47(.A1(new_n34_), .A2(p0), .B(new_n43_), .Y(new_n81_));
  OAI21x1_ASAP7_75t_R  g48(.A1(new_n80_), .A2(new_n68_), .B(new_n81_), .Y(o10));
  AND3x1_ASAP7_75t_R   g49(.A(new_n35_), .B(new_n47_), .C(new_n34_), .Y(o11));
  NOR2x1_ASAP7_75t_R   g50(.A(p6), .B(p0), .Y(new_n84_));
  OA21x2_ASAP7_75t_R   g51(.A1(new_n39_), .A2(new_n84_), .B(new_n79_), .Y(new_n85_));
  OA211x2_ASAP7_75t_R  g52(.A1(new_n44_), .A2(p2), .B(new_n39_), .C(p1), .Y(new_n86_));
  NOR2x1_ASAP7_75t_R   g53(.A(new_n85_), .B(new_n86_), .Y(o12));
  AND3x1_ASAP7_75t_R   g54(.A(new_n47_), .B(p1), .C(p6), .Y(o13));
  AND3x1_ASAP7_75t_R   g55(.A(new_n47_), .B(p1), .C(new_n34_), .Y(o14));
  AND3x1_ASAP7_75t_R   g56(.A(new_n39_), .B(p1), .C(p2), .Y(new_n90_));
  AND2x2_ASAP7_75t_R   g57(.A(new_n84_), .B(new_n90_), .Y(o15));
  AND3x1_ASAP7_75t_R   g58(.A(new_n90_), .B(p6), .C(new_n44_), .Y(o16));
  AND2x2_ASAP7_75t_R   g59(.A(new_n64_), .B(new_n90_), .Y(o17));
  AND3x1_ASAP7_75t_R   g60(.A(new_n90_), .B(new_n34_), .C(p0), .Y(o18));
  AO21x1_ASAP7_75t_R   g61(.A1(p3), .A2(new_n58_), .B(new_n54_), .Y(new_n95_));
  OA21x2_ASAP7_75t_R   g62(.A1(new_n36_), .A2(new_n64_), .B(p1), .Y(new_n96_));
  AOI21x1_ASAP7_75t_R  g63(.A1(new_n48_), .A2(new_n95_), .B(new_n96_), .Y(o20));
  AND3x1_ASAP7_75t_R   g64(.A(new_n44_), .B(new_n39_), .C(p2), .Y(new_n98_));
  AND5x1_ASAP7_75t_R   g65(.A(p4), .B(new_n60_), .C(p0), .D(p2), .E(p3), .Y(new_n99_));
  OA211x2_ASAP7_75t_R  g66(.A1(new_n98_), .A2(new_n99_), .B(new_n48_), .C(p6), .Y(o21));
  AOI21x1_ASAP7_75t_R  g67(.A1(new_n48_), .A2(new_n65_), .B(new_n96_), .Y(o22));
  assign               o23 = 1'b1;
  OA211x2_ASAP7_75t_R  g68(.A1(new_n84_), .A2(new_n64_), .B(p3), .C(new_n79_), .Y(o24));
  AND5x1_ASAP7_75t_R   g69(.A(new_n48_), .B(new_n44_), .C(new_n38_), .D(p6), .E(p3), .Y(o25));
endmodule


