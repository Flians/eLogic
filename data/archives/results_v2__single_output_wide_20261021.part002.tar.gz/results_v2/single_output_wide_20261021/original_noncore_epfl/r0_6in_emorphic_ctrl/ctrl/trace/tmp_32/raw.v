// Benchmark "/tmp/" written by ABC on Wed Oct 21 14:30:15 2026

module \/tmp/  ( 
    p2, p5, p4, p0, p3, p1, p6,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25  );
  input  p2, p5, p4, p0, p3, p1, p6;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25;
  wire new_n34_, new_n35_, new_n36_, new_n37_, new_n39_, new_n40_, new_n41_,
    new_n42_, new_n43_, new_n44_, new_n45_, new_n46_, new_n47_, new_n49_,
    new_n50_, new_n51_, new_n53_, new_n54_, new_n55_, new_n56_, new_n58_,
    new_n59_, new_n60_, new_n61_, new_n62_, new_n63_, new_n64_, new_n65_,
    new_n66_, new_n67_, new_n69_, new_n71_, new_n72_, new_n74_, new_n76_,
    new_n79_, new_n80_, new_n83_, new_n84_, new_n88_, new_n94_, new_n95_,
    new_n96_, new_n97_, new_n99_, new_n100_, new_n102_, new_n105_;
  AND2x2_ASAP7_75t_R   g00(.A(p2), .B(p3), .Y(new_n34_));
  OR3x1_ASAP7_75t_R    g01(.A(p0), .B(p1), .C(p6), .Y(new_n35_));
  NOR2x1_ASAP7_75t_R   g02(.A(p2), .B(p3), .Y(new_n36_));
  AND3x1_ASAP7_75t_R   g03(.A(new_n36_), .B(p0), .C(p1), .Y(new_n37_));
  AO21x1_ASAP7_75t_R   g04(.A1(new_n34_), .A2(new_n35_), .B(new_n37_), .Y(o0));
  INVx1_ASAP7_75t_R    g05(.A(p0), .Y(new_n39_));
  NOR2x1_ASAP7_75t_R   g06(.A(p1), .B(new_n39_), .Y(new_n40_));
  INVx1_ASAP7_75t_R    g07(.A(p2), .Y(new_n41_));
  NAND2x1_ASAP7_75t_R  g08(.A(p3), .B(new_n41_), .Y(new_n42_));
  INVx1_ASAP7_75t_R    g09(.A(p3), .Y(new_n43_));
  OR3x1_ASAP7_75t_R    g10(.A(new_n41_), .B(new_n43_), .C(p6), .Y(new_n44_));
  NOR2x1_ASAP7_75t_R   g11(.A(p0), .B(p1), .Y(new_n45_));
  INVx1_ASAP7_75t_R    g12(.A(p1), .Y(new_n46_));
  AOI21x1_ASAP7_75t_R  g13(.A1(p0), .A2(new_n36_), .B(new_n46_), .Y(new_n47_));
  AOI221x1_ASAP7_75t_R g14(.A1(new_n40_), .A2(new_n42_), .B1(new_n44_), .B2(new_n45_), .C(new_n47_), .Y(o1));
  NOR2x1_ASAP7_75t_R   g15(.A(p3), .B(new_n41_), .Y(new_n49_));
  NOR2x1_ASAP7_75t_R   g16(.A(new_n39_), .B(new_n49_), .Y(new_n50_));
  OR3x1_ASAP7_75t_R    g17(.A(new_n43_), .B(p2), .C(p6), .Y(new_n51_));
  AOI221x1_ASAP7_75t_R g18(.A1(new_n39_), .A2(new_n44_), .B1(new_n50_), .B2(new_n51_), .C(p1), .Y(o2));
  INVx1_ASAP7_75t_R    g19(.A(p6), .Y(new_n53_));
  OR3x1_ASAP7_75t_R    g20(.A(new_n41_), .B(new_n43_), .C(new_n53_), .Y(new_n54_));
  INVx1_ASAP7_75t_R    g21(.A(new_n36_), .Y(new_n55_));
  AO21x1_ASAP7_75t_R   g22(.A1(new_n39_), .A2(new_n46_), .B(new_n41_), .Y(new_n56_));
  AND3x1_ASAP7_75t_R   g23(.A(new_n54_), .B(new_n55_), .C(new_n56_), .Y(o3));
  NAND2x1_ASAP7_75t_R  g24(.A(p2), .B(p3), .Y(new_n58_));
  NAND2x1_ASAP7_75t_R  g25(.A(p4), .B(p0), .Y(new_n59_));
  OA31x2_ASAP7_75t_R   g26(.A1(p6), .A2(new_n58_), .A3(new_n59_), .B1(new_n46_), .Y(new_n60_));
  INVx1_ASAP7_75t_R    g27(.A(p5), .Y(new_n61_));
  AOI21x1_ASAP7_75t_R  g28(.A1(p3), .A2(new_n61_), .B(new_n41_), .Y(new_n62_));
  INVx1_ASAP7_75t_R    g29(.A(p4), .Y(new_n63_));
  NAND3x1_ASAP7_75t_R  g30(.A(new_n63_), .B(p5), .C(p3), .Y(new_n64_));
  AND2x2_ASAP7_75t_R   g31(.A(p0), .B(p6), .Y(new_n65_));
  NAND3x1_ASAP7_75t_R  g32(.A(new_n62_), .B(new_n64_), .C(new_n65_), .Y(new_n66_));
  OA21x2_ASAP7_75t_R   g33(.A1(new_n53_), .A2(new_n42_), .B(p1), .Y(new_n67_));
  AOI21x1_ASAP7_75t_R  g34(.A1(new_n60_), .A2(new_n66_), .B(new_n67_), .Y(o4));
  AO21x1_ASAP7_75t_R   g35(.A1(p3), .A2(new_n41_), .B(new_n46_), .Y(new_n69_));
  OA211x2_ASAP7_75t_R  g36(.A1(p1), .A2(new_n62_), .B(new_n69_), .C(p0), .Y(o5));
  NOR2x1_ASAP7_75t_R   g37(.A(p1), .B(new_n36_), .Y(new_n71_));
  OR3x1_ASAP7_75t_R    g38(.A(new_n65_), .B(p1), .C(new_n58_), .Y(new_n72_));
  OA21x2_ASAP7_75t_R   g39(.A1(new_n34_), .A2(new_n71_), .B(new_n72_), .Y(o6));
  OAI21x1_ASAP7_75t_R  g40(.A1(new_n46_), .A2(new_n53_), .B(new_n35_), .Y(new_n74_));
  AO21x1_ASAP7_75t_R   g41(.A1(new_n34_), .A2(new_n74_), .B(new_n37_), .Y(o7));
  AND2x2_ASAP7_75t_R   g42(.A(p1), .B(new_n58_), .Y(new_n76_));
  AOI221x1_ASAP7_75t_R g43(.A1(new_n51_), .A2(new_n46_), .B1(new_n76_), .B2(new_n55_), .C(new_n39_), .Y(o8));
  AOI221x1_ASAP7_75t_R g44(.A1(new_n39_), .A2(new_n58_), .B1(new_n51_), .B2(new_n40_), .C(new_n47_), .Y(o9));
  AOI22x1_ASAP7_75t_R  g45(.A1(new_n45_), .A2(p3), .B1(new_n41_), .B2(new_n46_), .Y(new_n79_));
  OA211x2_ASAP7_75t_R  g46(.A1(new_n39_), .A2(p6), .B(new_n41_), .C(p3), .Y(new_n80_));
  AO21x1_ASAP7_75t_R   g47(.A1(new_n69_), .A2(new_n79_), .B(new_n80_), .Y(o10));
  AND3x1_ASAP7_75t_R   g48(.A(new_n36_), .B(new_n45_), .C(new_n53_), .Y(o11));
  OR3x1_ASAP7_75t_R    g49(.A(p2), .B(p0), .C(p6), .Y(new_n83_));
  AND3x1_ASAP7_75t_R   g50(.A(new_n41_), .B(p0), .C(p1), .Y(new_n84_));
  AO221x2_ASAP7_75t_R  g51(.A1(p3), .A2(p1), .B1(new_n71_), .B2(new_n83_), .C(new_n84_), .Y(o12));
  AND3x1_ASAP7_75t_R   g52(.A(new_n36_), .B(p1), .C(p6), .Y(o13));
  AND3x1_ASAP7_75t_R   g53(.A(new_n36_), .B(p1), .C(new_n53_), .Y(o14));
  AND3x1_ASAP7_75t_R   g54(.A(new_n43_), .B(p2), .C(p1), .Y(new_n88_));
  AND3x1_ASAP7_75t_R   g55(.A(new_n88_), .B(new_n39_), .C(new_n53_), .Y(o15));
  AND3x1_ASAP7_75t_R   g56(.A(new_n88_), .B(new_n39_), .C(p6), .Y(o16));
  AND3x1_ASAP7_75t_R   g57(.A(new_n49_), .B(p1), .C(new_n65_), .Y(o17));
  AND3x1_ASAP7_75t_R   g58(.A(new_n88_), .B(p0), .C(new_n53_), .Y(o18));
  AND3x1_ASAP7_75t_R   g59(.A(new_n41_), .B(new_n43_), .C(p1), .Y(o19));
  NOR2x1_ASAP7_75t_R   g60(.A(p1), .B(new_n53_), .Y(new_n94_));
  AOI21x1_ASAP7_75t_R  g61(.A1(p3), .A2(new_n59_), .B(new_n41_), .Y(new_n95_));
  NAND2x1_ASAP7_75t_R  g62(.A(p0), .B(p6), .Y(new_n96_));
  AND3x1_ASAP7_75t_R   g63(.A(new_n34_), .B(p1), .C(new_n96_), .Y(new_n97_));
  AO21x1_ASAP7_75t_R   g64(.A1(new_n94_), .A2(new_n95_), .B(new_n97_), .Y(o20));
  AND3x1_ASAP7_75t_R   g65(.A(new_n39_), .B(new_n43_), .C(p2), .Y(new_n99_));
  AND5x1_ASAP7_75t_R   g66(.A(new_n61_), .B(p2), .C(p4), .D(p0), .E(p3), .Y(new_n100_));
  OA21x2_ASAP7_75t_R   g67(.A1(new_n99_), .A2(new_n100_), .B(new_n94_), .Y(o21));
  AOI211x1_ASAP7_75t_R g68(.A1(p3), .A2(new_n61_), .B(new_n41_), .C(new_n96_), .Y(new_n102_));
  AO31x2_ASAP7_75t_R   g69(.A1(new_n46_), .A2(new_n64_), .A3(new_n102_), .B(new_n97_), .Y(o22));
  assign               o23 = 1'b1;
  NAND2x1_ASAP7_75t_R  g70(.A(p6), .B(new_n39_), .Y(new_n105_));
  AND3x1_ASAP7_75t_R   g71(.A(new_n80_), .B(new_n46_), .C(new_n105_), .Y(o24));
  AND5x1_ASAP7_75t_R   g72(.A(new_n41_), .B(new_n39_), .C(new_n46_), .D(p3), .E(p6), .Y(o25));
endmodule


