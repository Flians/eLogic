// Benchmark "/tmp/" written by ABC on Wed Oct 21 14:30:13 2026

module \/tmp/  ( 
    p2, p6, p5, p0, p1, p3, p4,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25  );
  input  p2, p6, p5, p0, p1, p3, p4;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25;
  wire new_n34_, new_n35_, new_n36_, new_n37_, new_n38_, new_n39_, new_n40_,
    new_n42_, new_n43_, new_n44_, new_n45_, new_n46_, new_n47_, new_n48_,
    new_n50_, new_n51_, new_n53_, new_n55_, new_n56_, new_n57_, new_n58_,
    new_n59_, new_n60_, new_n61_, new_n63_, new_n64_, new_n65_, new_n66_,
    new_n68_, new_n69_, new_n70_, new_n72_, new_n73_, new_n77_, new_n78_,
    new_n79_, new_n82_, new_n83_, new_n84_, new_n88_, new_n94_, new_n95_,
    new_n97_, new_n98_, new_n100_;
  INVx1_ASAP7_75t_R    g00(.A(p6), .Y(new_n34_));
  NOR2x1_ASAP7_75t_R   g01(.A(p0), .B(p1), .Y(new_n35_));
  NAND2x1_ASAP7_75t_R  g02(.A(p2), .B(p3), .Y(new_n36_));
  AO21x1_ASAP7_75t_R   g03(.A1(new_n34_), .A2(new_n35_), .B(new_n36_), .Y(new_n37_));
  INVx1_ASAP7_75t_R    g04(.A(p0), .Y(new_n38_));
  INVx1_ASAP7_75t_R    g05(.A(p1), .Y(new_n39_));
  OR4x2_ASAP7_75t_R    g06(.A(new_n38_), .B(new_n39_), .C(p2), .D(p3), .Y(new_n40_));
  NAND2x1_ASAP7_75t_R  g07(.A(new_n37_), .B(new_n40_), .Y(o0));
  NOR2x1_ASAP7_75t_R   g08(.A(p1), .B(new_n38_), .Y(new_n42_));
  INVx1_ASAP7_75t_R    g09(.A(p2), .Y(new_n43_));
  NAND2x1_ASAP7_75t_R  g10(.A(p3), .B(new_n43_), .Y(new_n44_));
  INVx1_ASAP7_75t_R    g11(.A(p3), .Y(new_n45_));
  OR3x1_ASAP7_75t_R    g12(.A(new_n43_), .B(new_n45_), .C(p6), .Y(new_n46_));
  NOR2x1_ASAP7_75t_R   g13(.A(p2), .B(p3), .Y(new_n47_));
  AOI21x1_ASAP7_75t_R  g14(.A1(p0), .A2(new_n47_), .B(new_n39_), .Y(new_n48_));
  AOI221x1_ASAP7_75t_R g15(.A1(new_n42_), .A2(new_n44_), .B1(new_n46_), .B2(new_n35_), .C(new_n48_), .Y(o1));
  OA21x2_ASAP7_75t_R   g16(.A1(p3), .A2(new_n43_), .B(p0), .Y(new_n50_));
  OR3x1_ASAP7_75t_R    g17(.A(new_n45_), .B(p2), .C(p6), .Y(new_n51_));
  AOI221x1_ASAP7_75t_R g18(.A1(new_n50_), .A2(new_n51_), .B1(new_n38_), .B2(new_n46_), .C(p1), .Y(o2));
  INVx1_ASAP7_75t_R    g19(.A(new_n47_), .Y(new_n53_));
  OA221x2_ASAP7_75t_R  g20(.A1(new_n43_), .A2(new_n35_), .B1(new_n34_), .B2(new_n36_), .C(new_n53_), .Y(o3));
  AND2x2_ASAP7_75t_R   g21(.A(p5), .B(p4), .Y(new_n55_));
  AND3x1_ASAP7_75t_R   g22(.A(p2), .B(p6), .C(p0), .Y(new_n56_));
  OAI21x1_ASAP7_75t_R  g23(.A1(new_n45_), .A2(new_n55_), .B(new_n56_), .Y(new_n57_));
  NAND2x1_ASAP7_75t_R  g24(.A(p0), .B(p4), .Y(new_n58_));
  OA31x2_ASAP7_75t_R   g25(.A1(p6), .A2(new_n36_), .A3(new_n58_), .B1(new_n39_), .Y(new_n59_));
  NAND2x1_ASAP7_75t_R  g26(.A(p6), .B(p3), .Y(new_n60_));
  OA21x2_ASAP7_75t_R   g27(.A1(p2), .A2(new_n60_), .B(p1), .Y(new_n61_));
  AOI21x1_ASAP7_75t_R  g28(.A1(new_n57_), .A2(new_n59_), .B(new_n61_), .Y(o4));
  INVx1_ASAP7_75t_R    g29(.A(p5), .Y(new_n63_));
  AO21x1_ASAP7_75t_R   g30(.A1(p3), .A2(new_n63_), .B(new_n43_), .Y(new_n64_));
  NOR2x1_ASAP7_75t_R   g31(.A(p2), .B(new_n45_), .Y(new_n65_));
  NOR2x1_ASAP7_75t_R   g32(.A(new_n39_), .B(new_n65_), .Y(new_n66_));
  AOI211x1_ASAP7_75t_R g33(.A1(new_n39_), .A2(new_n64_), .B(new_n38_), .C(new_n66_), .Y(o5));
  AND2x2_ASAP7_75t_R   g34(.A(p6), .B(p0), .Y(new_n68_));
  NOR2x1_ASAP7_75t_R   g35(.A(new_n36_), .B(new_n68_), .Y(new_n69_));
  AOI21x1_ASAP7_75t_R  g36(.A1(p2), .A2(p3), .B(new_n39_), .Y(new_n70_));
  AOI211x1_ASAP7_75t_R g37(.A1(new_n39_), .A2(new_n69_), .B(new_n47_), .C(new_n70_), .Y(o6));
  OR5x1_ASAP7_75t_R    g38(.A(new_n43_), .B(new_n45_), .C(p6), .D(p0), .E(p1), .Y(new_n72_));
  OR3x1_ASAP7_75t_R    g39(.A(new_n36_), .B(new_n34_), .C(new_n39_), .Y(new_n73_));
  NAND3x1_ASAP7_75t_R  g40(.A(new_n40_), .B(new_n72_), .C(new_n73_), .Y(o7));
  AOI221x1_ASAP7_75t_R g41(.A1(new_n53_), .A2(new_n70_), .B1(new_n51_), .B2(new_n39_), .C(new_n38_), .Y(o8));
  AOI221x1_ASAP7_75t_R g42(.A1(new_n38_), .A2(new_n36_), .B1(new_n51_), .B2(new_n42_), .C(new_n48_), .Y(o9));
  NOR2x1_ASAP7_75t_R   g43(.A(p2), .B(p1), .Y(new_n77_));
  AO21x1_ASAP7_75t_R   g44(.A1(p3), .A2(new_n35_), .B(new_n77_), .Y(new_n78_));
  NOR2x1_ASAP7_75t_R   g45(.A(p6), .B(new_n38_), .Y(new_n79_));
  OAI22x1_ASAP7_75t_R  g46(.A1(new_n66_), .A2(new_n78_), .B1(new_n44_), .B2(new_n79_), .Y(o10));
  AND3x1_ASAP7_75t_R   g47(.A(new_n47_), .B(new_n35_), .C(new_n34_), .Y(o11));
  NOR2x1_ASAP7_75t_R   g48(.A(p6), .B(p0), .Y(new_n82_));
  OA21x2_ASAP7_75t_R   g49(.A1(new_n45_), .A2(new_n82_), .B(new_n77_), .Y(new_n83_));
  OA211x2_ASAP7_75t_R  g50(.A1(p2), .A2(new_n38_), .B(new_n45_), .C(p1), .Y(new_n84_));
  NOR2x1_ASAP7_75t_R   g51(.A(new_n83_), .B(new_n84_), .Y(o12));
  AND3x1_ASAP7_75t_R   g52(.A(new_n47_), .B(p6), .C(p1), .Y(o13));
  AND3x1_ASAP7_75t_R   g53(.A(new_n47_), .B(new_n34_), .C(p1), .Y(o14));
  AND3x1_ASAP7_75t_R   g54(.A(new_n45_), .B(p2), .C(p1), .Y(new_n88_));
  AND2x2_ASAP7_75t_R   g55(.A(new_n82_), .B(new_n88_), .Y(o15));
  AND3x1_ASAP7_75t_R   g56(.A(new_n88_), .B(p6), .C(new_n38_), .Y(o16));
  AND2x2_ASAP7_75t_R   g57(.A(new_n68_), .B(new_n88_), .Y(o17));
  AND2x2_ASAP7_75t_R   g58(.A(new_n79_), .B(new_n88_), .Y(o18));
  AND3x1_ASAP7_75t_R   g59(.A(new_n43_), .B(new_n45_), .C(p1), .Y(o19));
  AOI21x1_ASAP7_75t_R  g60(.A1(p3), .A2(new_n58_), .B(new_n43_), .Y(new_n94_));
  NOR2x1_ASAP7_75t_R   g61(.A(p1), .B(new_n34_), .Y(new_n95_));
  AO22x1_ASAP7_75t_R   g62(.A1(new_n94_), .A2(new_n95_), .B1(p1), .B2(new_n69_), .Y(o20));
  AND3x1_ASAP7_75t_R   g63(.A(new_n38_), .B(new_n45_), .C(p2), .Y(new_n97_));
  AND5x1_ASAP7_75t_R   g64(.A(new_n63_), .B(p2), .C(p0), .D(p3), .E(p4), .Y(new_n98_));
  OA21x2_ASAP7_75t_R   g65(.A1(new_n97_), .A2(new_n98_), .B(new_n95_), .Y(o21));
  OR3x1_ASAP7_75t_R    g66(.A(new_n68_), .B(new_n39_), .C(new_n36_), .Y(new_n100_));
  OAI21x1_ASAP7_75t_R  g67(.A1(p1), .A2(new_n57_), .B(new_n100_), .Y(o22));
  assign               o23 = 1'b1;
  OA211x2_ASAP7_75t_R  g68(.A1(new_n82_), .A2(new_n68_), .B(p3), .C(new_n77_), .Y(o24));
  AND3x1_ASAP7_75t_R   g69(.A(new_n65_), .B(p6), .C(new_n35_), .Y(o25));
endmodule


