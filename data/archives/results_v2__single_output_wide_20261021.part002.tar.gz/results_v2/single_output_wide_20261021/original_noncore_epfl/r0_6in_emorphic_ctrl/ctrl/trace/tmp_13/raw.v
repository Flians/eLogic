// Benchmark "/tmp/" written by ABC on Wed Oct 21 14:30:12 2026

module \/tmp/  ( 
    p2, p4, p5, p3, p6, p0, p1,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25  );
  input  p2, p4, p5, p3, p6, p0, p1;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25;
  wire new_n34_, new_n35_, new_n36_, new_n37_, new_n38_, new_n39_, new_n41_,
    new_n43_, new_n44_, new_n45_, new_n46_, new_n47_, new_n48_, new_n49_,
    new_n51_, new_n52_, new_n53_, new_n55_, new_n56_, new_n57_, new_n59_,
    new_n60_, new_n61_, new_n62_, new_n63_, new_n64_, new_n65_, new_n66_,
    new_n67_, new_n69_, new_n71_, new_n72_, new_n73_, new_n74_, new_n76_,
    new_n77_, new_n81_, new_n82_, new_n83_, new_n86_, new_n87_, new_n88_,
    new_n93_, new_n97_, new_n98_, new_n99_, new_n101_, new_n102_,
    new_n104_;
  INVx1_ASAP7_75t_R    g00(.A(p6), .Y(new_n34_));
  NOR2x1_ASAP7_75t_R   g01(.A(p0), .B(p1), .Y(new_n35_));
  NAND2x1_ASAP7_75t_R  g02(.A(p2), .B(p3), .Y(new_n36_));
  AO21x1_ASAP7_75t_R   g03(.A1(new_n34_), .A2(new_n35_), .B(new_n36_), .Y(new_n37_));
  INVx1_ASAP7_75t_R    g04(.A(p2), .Y(new_n38_));
  INVx1_ASAP7_75t_R    g05(.A(p3), .Y(new_n39_));
  AND3x1_ASAP7_75t_R   g06(.A(new_n38_), .B(new_n39_), .C(p1), .Y(o19));
  NAND2x1_ASAP7_75t_R  g07(.A(p0), .B(o19), .Y(new_n41_));
  NAND2x1_ASAP7_75t_R  g08(.A(new_n37_), .B(new_n41_), .Y(o0));
  NAND2x1_ASAP7_75t_R  g09(.A(p3), .B(new_n38_), .Y(new_n43_));
  INVx1_ASAP7_75t_R    g10(.A(p0), .Y(new_n44_));
  NOR2x1_ASAP7_75t_R   g11(.A(p1), .B(new_n44_), .Y(new_n45_));
  OR3x1_ASAP7_75t_R    g12(.A(new_n38_), .B(new_n39_), .C(p6), .Y(new_n46_));
  NOR2x1_ASAP7_75t_R   g13(.A(p2), .B(p3), .Y(new_n47_));
  INVx1_ASAP7_75t_R    g14(.A(p1), .Y(new_n48_));
  AOI21x1_ASAP7_75t_R  g15(.A1(p0), .A2(new_n47_), .B(new_n48_), .Y(new_n49_));
  AOI221x1_ASAP7_75t_R g16(.A1(new_n43_), .A2(new_n45_), .B1(new_n46_), .B2(new_n35_), .C(new_n49_), .Y(o1));
  NOR2x1_ASAP7_75t_R   g17(.A(p3), .B(new_n38_), .Y(new_n51_));
  NOR2x1_ASAP7_75t_R   g18(.A(new_n44_), .B(new_n51_), .Y(new_n52_));
  OR3x1_ASAP7_75t_R    g19(.A(new_n39_), .B(p2), .C(p6), .Y(new_n53_));
  AOI221x1_ASAP7_75t_R g20(.A1(new_n44_), .A2(new_n46_), .B1(new_n52_), .B2(new_n53_), .C(p1), .Y(o2));
  OR3x1_ASAP7_75t_R    g21(.A(new_n38_), .B(new_n39_), .C(new_n34_), .Y(new_n55_));
  INVx1_ASAP7_75t_R    g22(.A(new_n47_), .Y(new_n56_));
  AO21x1_ASAP7_75t_R   g23(.A1(new_n44_), .A2(new_n48_), .B(new_n38_), .Y(new_n57_));
  AND3x1_ASAP7_75t_R   g24(.A(new_n55_), .B(new_n56_), .C(new_n57_), .Y(o3));
  NAND2x1_ASAP7_75t_R  g25(.A(p4), .B(p0), .Y(new_n59_));
  OA31x2_ASAP7_75t_R   g26(.A1(p6), .A2(new_n36_), .A3(new_n59_), .B1(new_n48_), .Y(new_n60_));
  INVx1_ASAP7_75t_R    g27(.A(p5), .Y(new_n61_));
  AOI21x1_ASAP7_75t_R  g28(.A1(p3), .A2(new_n61_), .B(new_n38_), .Y(new_n62_));
  INVx1_ASAP7_75t_R    g29(.A(p4), .Y(new_n63_));
  NAND3x1_ASAP7_75t_R  g30(.A(new_n63_), .B(p5), .C(p3), .Y(new_n64_));
  AND2x2_ASAP7_75t_R   g31(.A(p6), .B(p0), .Y(new_n65_));
  NAND3x1_ASAP7_75t_R  g32(.A(new_n62_), .B(new_n64_), .C(new_n65_), .Y(new_n66_));
  OA21x2_ASAP7_75t_R   g33(.A1(new_n34_), .A2(new_n43_), .B(p1), .Y(new_n67_));
  AOI21x1_ASAP7_75t_R  g34(.A1(new_n60_), .A2(new_n66_), .B(new_n67_), .Y(o4));
  AO21x1_ASAP7_75t_R   g35(.A1(p3), .A2(new_n38_), .B(new_n48_), .Y(new_n69_));
  OA211x2_ASAP7_75t_R  g36(.A1(p1), .A2(new_n62_), .B(new_n69_), .C(p0), .Y(o5));
  AND2x2_ASAP7_75t_R   g37(.A(p2), .B(p3), .Y(new_n71_));
  NAND2x1_ASAP7_75t_R  g38(.A(p6), .B(p0), .Y(new_n72_));
  AND3x1_ASAP7_75t_R   g39(.A(new_n71_), .B(new_n48_), .C(new_n72_), .Y(new_n73_));
  AND2x2_ASAP7_75t_R   g40(.A(p1), .B(new_n36_), .Y(new_n74_));
  NOR3x1_ASAP7_75t_R   g41(.A(new_n73_), .B(new_n47_), .C(new_n74_), .Y(o6));
  OR3x1_ASAP7_75t_R    g42(.A(p6), .B(p0), .C(p1), .Y(new_n76_));
  OA21x2_ASAP7_75t_R   g43(.A1(new_n34_), .A2(new_n48_), .B(new_n76_), .Y(new_n77_));
  OAI21x1_ASAP7_75t_R  g44(.A1(new_n36_), .A2(new_n77_), .B(new_n41_), .Y(o7));
  AOI221x1_ASAP7_75t_R g45(.A1(new_n53_), .A2(new_n48_), .B1(new_n74_), .B2(new_n56_), .C(new_n44_), .Y(o8));
  AOI221x1_ASAP7_75t_R g46(.A1(new_n44_), .A2(new_n36_), .B1(new_n53_), .B2(new_n45_), .C(new_n49_), .Y(o9));
  NAND2x1_ASAP7_75t_R  g47(.A(p0), .B(new_n34_), .Y(new_n81_));
  NOR2x1_ASAP7_75t_R   g48(.A(p2), .B(p1), .Y(new_n82_));
  AOI21x1_ASAP7_75t_R  g49(.A1(p3), .A2(new_n35_), .B(new_n82_), .Y(new_n83_));
  AO32x1_ASAP7_75t_R   g50(.A1(new_n38_), .A2(p3), .A3(new_n81_), .B1(new_n83_), .B2(new_n69_), .Y(o10));
  AND3x1_ASAP7_75t_R   g51(.A(new_n35_), .B(new_n47_), .C(new_n34_), .Y(o11));
  AO21x1_ASAP7_75t_R   g52(.A1(p0), .A2(new_n38_), .B(p3), .Y(new_n86_));
  NOR2x1_ASAP7_75t_R   g53(.A(p6), .B(p0), .Y(new_n87_));
  OAI21x1_ASAP7_75t_R  g54(.A1(new_n39_), .A2(new_n87_), .B(new_n82_), .Y(new_n88_));
  OA21x2_ASAP7_75t_R   g55(.A1(new_n48_), .A2(new_n86_), .B(new_n88_), .Y(o12));
  AND3x1_ASAP7_75t_R   g56(.A(new_n47_), .B(p6), .C(p1), .Y(o13));
  AND3x1_ASAP7_75t_R   g57(.A(new_n47_), .B(new_n34_), .C(p1), .Y(o14));
  AND3x1_ASAP7_75t_R   g58(.A(new_n51_), .B(p1), .C(new_n87_), .Y(o15));
  AND3x1_ASAP7_75t_R   g59(.A(new_n39_), .B(p2), .C(p1), .Y(new_n93_));
  AND3x1_ASAP7_75t_R   g60(.A(new_n93_), .B(p6), .C(new_n44_), .Y(o16));
  AND3x1_ASAP7_75t_R   g61(.A(new_n51_), .B(p1), .C(new_n65_), .Y(o17));
  AND3x1_ASAP7_75t_R   g62(.A(new_n93_), .B(new_n34_), .C(p0), .Y(o18));
  NOR2x1_ASAP7_75t_R   g63(.A(p1), .B(new_n34_), .Y(new_n97_));
  AOI21x1_ASAP7_75t_R  g64(.A1(p3), .A2(new_n59_), .B(new_n38_), .Y(new_n98_));
  AND3x1_ASAP7_75t_R   g65(.A(new_n71_), .B(p1), .C(new_n72_), .Y(new_n99_));
  AO21x1_ASAP7_75t_R   g66(.A1(new_n97_), .A2(new_n98_), .B(new_n99_), .Y(o20));
  AND3x1_ASAP7_75t_R   g67(.A(new_n39_), .B(new_n44_), .C(p2), .Y(new_n101_));
  AND5x1_ASAP7_75t_R   g68(.A(p2), .B(new_n61_), .C(p4), .D(p3), .E(p0), .Y(new_n102_));
  OA21x2_ASAP7_75t_R   g69(.A1(new_n101_), .A2(new_n102_), .B(new_n97_), .Y(o21));
  AOI211x1_ASAP7_75t_R g70(.A1(p3), .A2(new_n61_), .B(new_n38_), .C(new_n72_), .Y(new_n104_));
  AO31x2_ASAP7_75t_R   g71(.A1(new_n48_), .A2(new_n64_), .A3(new_n104_), .B(new_n99_), .Y(o22));
  assign               o23 = 1'b1;
  OA211x2_ASAP7_75t_R  g72(.A1(new_n87_), .A2(new_n65_), .B(p3), .C(new_n82_), .Y(o24));
  AND5x1_ASAP7_75t_R   g73(.A(new_n38_), .B(new_n44_), .C(new_n48_), .D(p3), .E(p6), .Y(o25));
endmodule


