// Benchmark "/tmp/" written by ABC on Wed Oct 21 14:30:10 2026

module \/tmp/  ( 
    p2, p4, p5, p6, p0, p1, p3,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25  );
  input  p2, p4, p5, p6, p0, p1, p3;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25;
  wire new_n34_, new_n35_, new_n36_, new_n37_, new_n38_, new_n39_, new_n41_,
    new_n42_, new_n43_, new_n44_, new_n45_, new_n46_, new_n47_, new_n49_,
    new_n50_, new_n52_, new_n53_, new_n55_, new_n56_, new_n57_, new_n58_,
    new_n59_, new_n60_, new_n61_, new_n62_, new_n63_, new_n64_, new_n66_,
    new_n67_, new_n68_, new_n69_, new_n71_, new_n72_, new_n73_, new_n75_,
    new_n76_, new_n78_, new_n79_, new_n80_, new_n83_, new_n84_, new_n87_,
    new_n88_, new_n89_, new_n93_, new_n99_, new_n100_, new_n102_,
    new_n103_, new_n107_, new_n108_;
  INVx1_ASAP7_75t_R    g00(.A(p0), .Y(new_n34_));
  INVx1_ASAP7_75t_R    g01(.A(p1), .Y(new_n35_));
  OR4x2_ASAP7_75t_R    g02(.A(new_n34_), .B(new_n35_), .C(p2), .D(p3), .Y(new_n36_));
  NAND2x1_ASAP7_75t_R  g03(.A(p2), .B(p3), .Y(new_n37_));
  INVx1_ASAP7_75t_R    g04(.A(p6), .Y(new_n38_));
  NOR2x1_ASAP7_75t_R   g05(.A(p0), .B(p1), .Y(new_n39_));
  AOI22x1_ASAP7_75t_R  g06(.A1(new_n36_), .A2(new_n37_), .B1(new_n38_), .B2(new_n39_), .Y(o0));
  NOR2x1_ASAP7_75t_R   g07(.A(p1), .B(new_n34_), .Y(new_n41_));
  INVx1_ASAP7_75t_R    g08(.A(p2), .Y(new_n42_));
  NAND2x1_ASAP7_75t_R  g09(.A(p3), .B(new_n42_), .Y(new_n43_));
  INVx1_ASAP7_75t_R    g10(.A(p3), .Y(new_n44_));
  OR3x1_ASAP7_75t_R    g11(.A(new_n42_), .B(new_n44_), .C(p6), .Y(new_n45_));
  NOR2x1_ASAP7_75t_R   g12(.A(p2), .B(p3), .Y(new_n46_));
  AOI21x1_ASAP7_75t_R  g13(.A1(p0), .A2(new_n46_), .B(new_n35_), .Y(new_n47_));
  AOI221x1_ASAP7_75t_R g14(.A1(new_n41_), .A2(new_n43_), .B1(new_n45_), .B2(new_n39_), .C(new_n47_), .Y(o1));
  OA21x2_ASAP7_75t_R   g15(.A1(p3), .A2(new_n42_), .B(p0), .Y(new_n49_));
  OR3x1_ASAP7_75t_R    g16(.A(new_n44_), .B(p2), .C(p6), .Y(new_n50_));
  AOI221x1_ASAP7_75t_R g17(.A1(new_n49_), .A2(new_n50_), .B1(new_n34_), .B2(new_n45_), .C(p1), .Y(o2));
  AND2x2_ASAP7_75t_R   g18(.A(p2), .B(p6), .Y(new_n52_));
  NOR2x1_ASAP7_75t_R   g19(.A(new_n42_), .B(new_n39_), .Y(new_n53_));
  AOI211x1_ASAP7_75t_R g20(.A1(p3), .A2(new_n52_), .B(new_n46_), .C(new_n53_), .Y(o3));
  NAND2x1_ASAP7_75t_R  g21(.A(p4), .B(p0), .Y(new_n55_));
  OA31x2_ASAP7_75t_R   g22(.A1(p6), .A2(new_n37_), .A3(new_n55_), .B1(new_n35_), .Y(new_n56_));
  INVx1_ASAP7_75t_R    g23(.A(p5), .Y(new_n57_));
  NAND2x1_ASAP7_75t_R  g24(.A(p3), .B(new_n57_), .Y(new_n58_));
  INVx1_ASAP7_75t_R    g25(.A(p4), .Y(new_n59_));
  NAND2x1_ASAP7_75t_R  g26(.A(p3), .B(new_n59_), .Y(new_n60_));
  AND3x1_ASAP7_75t_R   g27(.A(p2), .B(p6), .C(p0), .Y(new_n61_));
  NAND3x1_ASAP7_75t_R  g28(.A(new_n58_), .B(new_n60_), .C(new_n61_), .Y(new_n62_));
  NOR2x1_ASAP7_75t_R   g29(.A(p2), .B(new_n44_), .Y(new_n63_));
  AOI21x1_ASAP7_75t_R  g30(.A1(p6), .A2(new_n63_), .B(new_n35_), .Y(new_n64_));
  AOI21x1_ASAP7_75t_R  g31(.A1(new_n56_), .A2(new_n62_), .B(new_n64_), .Y(o4));
  OAI21x1_ASAP7_75t_R  g32(.A1(p1), .A2(new_n58_), .B(p0), .Y(new_n66_));
  NAND2x1_ASAP7_75t_R  g33(.A(new_n42_), .B(new_n35_), .Y(new_n67_));
  AO21x1_ASAP7_75t_R   g34(.A1(p3), .A2(new_n42_), .B(new_n35_), .Y(new_n68_));
  NAND2x1_ASAP7_75t_R  g35(.A(new_n67_), .B(new_n68_), .Y(new_n69_));
  NOR2x1_ASAP7_75t_R   g36(.A(new_n66_), .B(new_n69_), .Y(o5));
  AND2x2_ASAP7_75t_R   g37(.A(p6), .B(p0), .Y(new_n71_));
  NOR2x1_ASAP7_75t_R   g38(.A(new_n37_), .B(new_n71_), .Y(new_n72_));
  AO21x1_ASAP7_75t_R   g39(.A1(new_n42_), .A2(new_n44_), .B(p1), .Y(new_n73_));
  AOI22x1_ASAP7_75t_R  g40(.A1(new_n72_), .A2(new_n35_), .B1(new_n37_), .B2(new_n73_), .Y(o6));
  OR5x1_ASAP7_75t_R    g41(.A(new_n42_), .B(new_n44_), .C(p6), .D(p0), .E(p1), .Y(new_n75_));
  OR3x1_ASAP7_75t_R    g42(.A(new_n37_), .B(new_n38_), .C(new_n35_), .Y(new_n76_));
  NAND3x1_ASAP7_75t_R  g43(.A(new_n36_), .B(new_n75_), .C(new_n76_), .Y(o7));
  AND3x1_ASAP7_75t_R   g44(.A(p2), .B(p0), .C(p3), .Y(new_n78_));
  NOR2x1_ASAP7_75t_R   g45(.A(new_n78_), .B(new_n41_), .Y(new_n79_));
  NAND2x1_ASAP7_75t_R  g46(.A(p0), .B(new_n46_), .Y(new_n80_));
  AOI22x1_ASAP7_75t_R  g47(.A1(new_n79_), .A2(new_n80_), .B1(new_n41_), .B2(new_n50_), .Y(o8));
  AOI221x1_ASAP7_75t_R g48(.A1(new_n34_), .A2(new_n37_), .B1(new_n50_), .B2(new_n41_), .C(new_n47_), .Y(o9));
  NAND2x1_ASAP7_75t_R  g49(.A(p3), .B(new_n39_), .Y(new_n83_));
  NAND2x1_ASAP7_75t_R  g50(.A(p0), .B(new_n38_), .Y(new_n84_));
  AO32x1_ASAP7_75t_R   g51(.A1(new_n68_), .A2(new_n83_), .A3(new_n67_), .B1(new_n63_), .B2(new_n84_), .Y(o10));
  AND3x1_ASAP7_75t_R   g52(.A(new_n46_), .B(new_n39_), .C(new_n38_), .Y(o11));
  AND3x1_ASAP7_75t_R   g53(.A(new_n42_), .B(new_n38_), .C(new_n34_), .Y(new_n87_));
  AO21x1_ASAP7_75t_R   g54(.A1(p2), .A2(new_n44_), .B(new_n35_), .Y(new_n88_));
  NOR2x1_ASAP7_75t_R   g55(.A(p0), .B(p3), .Y(new_n89_));
  OAI22x1_ASAP7_75t_R  g56(.A1(new_n87_), .A2(new_n73_), .B1(new_n88_), .B2(new_n89_), .Y(o12));
  AND3x1_ASAP7_75t_R   g57(.A(new_n46_), .B(p6), .C(p1), .Y(o13));
  AND3x1_ASAP7_75t_R   g58(.A(new_n46_), .B(new_n38_), .C(p1), .Y(o14));
  AND3x1_ASAP7_75t_R   g59(.A(new_n34_), .B(new_n44_), .C(p2), .Y(new_n93_));
  AND3x1_ASAP7_75t_R   g60(.A(new_n93_), .B(new_n38_), .C(p1), .Y(o15));
  AND3x1_ASAP7_75t_R   g61(.A(new_n93_), .B(p6), .C(p1), .Y(o16));
  AND5x1_ASAP7_75t_R   g62(.A(p2), .B(new_n44_), .C(p6), .D(p0), .E(p1), .Y(o17));
  AND5x1_ASAP7_75t_R   g63(.A(p2), .B(new_n38_), .C(new_n44_), .D(p0), .E(p1), .Y(o18));
  AND3x1_ASAP7_75t_R   g64(.A(new_n42_), .B(new_n44_), .C(p1), .Y(o19));
  AOI22x1_ASAP7_75t_R  g65(.A1(new_n60_), .A2(new_n61_), .B1(new_n52_), .B2(new_n89_), .Y(new_n99_));
  OA21x2_ASAP7_75t_R   g66(.A1(new_n37_), .A2(new_n71_), .B(p1), .Y(new_n100_));
  AOI21x1_ASAP7_75t_R  g67(.A1(new_n35_), .A2(new_n99_), .B(new_n100_), .Y(o20));
  AND5x1_ASAP7_75t_R   g68(.A(p2), .B(new_n57_), .C(p4), .D(p0), .E(p3), .Y(new_n102_));
  NOR2x1_ASAP7_75t_R   g69(.A(p1), .B(new_n38_), .Y(new_n103_));
  OA21x2_ASAP7_75t_R   g70(.A1(new_n93_), .A2(new_n102_), .B(new_n103_), .Y(o21));
  AOI21x1_ASAP7_75t_R  g71(.A1(new_n35_), .A2(new_n62_), .B(new_n100_), .Y(o22));
  assign               o23 = 1'b1;
  NOR2x1_ASAP7_75t_R   g72(.A(p6), .B(p0), .Y(new_n107_));
  AND3x1_ASAP7_75t_R   g73(.A(new_n42_), .B(new_n35_), .C(p3), .Y(new_n108_));
  OA21x2_ASAP7_75t_R   g74(.A1(new_n71_), .A2(new_n107_), .B(new_n108_), .Y(o24));
  AND3x1_ASAP7_75t_R   g75(.A(new_n63_), .B(p6), .C(new_n39_), .Y(o25));
endmodule


