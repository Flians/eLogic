// Benchmark "/tmp/" written by ABC on Wed Oct 21 14:30:19 2026

module \/tmp/  ( 
    p0, p1, p4, p6, p3, p5, p2,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25  );
  input  p0, p1, p4, p6, p3, p5, p2;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25;
  wire new_n34_, new_n35_, new_n36_, new_n39_, new_n40_, new_n41_, new_n42_,
    new_n43_, new_n44_, new_n45_, new_n46_, new_n48_, new_n49_, new_n50_,
    new_n52_, new_n53_, new_n54_, new_n56_, new_n57_, new_n58_, new_n59_,
    new_n60_, new_n61_, new_n62_, new_n63_, new_n64_, new_n65_, new_n67_,
    new_n68_, new_n70_, new_n71_, new_n73_, new_n74_, new_n76_, new_n79_,
    new_n80_, new_n81_, new_n82_, new_n85_, new_n86_, new_n87_, new_n92_,
    new_n96_, new_n97_, new_n98_, new_n100_;
  OR3x1_ASAP7_75t_R    g00(.A(p0), .B(p1), .C(p6), .Y(new_n34_));
  INVx1_ASAP7_75t_R    g01(.A(p3), .Y(new_n35_));
  INVx1_ASAP7_75t_R    g02(.A(p2), .Y(new_n36_));
  AND3x1_ASAP7_75t_R   g03(.A(new_n35_), .B(new_n36_), .C(p1), .Y(o19));
  AO32x1_ASAP7_75t_R   g04(.A1(p3), .A2(p2), .A3(new_n34_), .B1(o19), .B2(p0), .Y(o0));
  INVx1_ASAP7_75t_R    g05(.A(p0), .Y(new_n39_));
  NOR2x1_ASAP7_75t_R   g06(.A(p1), .B(new_n39_), .Y(new_n40_));
  NAND2x1_ASAP7_75t_R  g07(.A(p3), .B(new_n36_), .Y(new_n41_));
  OR3x1_ASAP7_75t_R    g08(.A(new_n35_), .B(new_n36_), .C(p6), .Y(new_n42_));
  NOR2x1_ASAP7_75t_R   g09(.A(p0), .B(p1), .Y(new_n43_));
  NOR2x1_ASAP7_75t_R   g10(.A(p3), .B(p2), .Y(new_n44_));
  INVx1_ASAP7_75t_R    g11(.A(p1), .Y(new_n45_));
  AOI21x1_ASAP7_75t_R  g12(.A1(p0), .A2(new_n44_), .B(new_n45_), .Y(new_n46_));
  AOI221x1_ASAP7_75t_R g13(.A1(new_n40_), .A2(new_n41_), .B1(new_n42_), .B2(new_n43_), .C(new_n46_), .Y(o1));
  NOR2x1_ASAP7_75t_R   g14(.A(p3), .B(new_n36_), .Y(new_n48_));
  NOR2x1_ASAP7_75t_R   g15(.A(new_n39_), .B(new_n48_), .Y(new_n49_));
  OR3x1_ASAP7_75t_R    g16(.A(new_n35_), .B(p6), .C(p2), .Y(new_n50_));
  AOI221x1_ASAP7_75t_R g17(.A1(new_n39_), .A2(new_n42_), .B1(new_n49_), .B2(new_n50_), .C(p1), .Y(o2));
  NAND2x1_ASAP7_75t_R  g18(.A(p6), .B(p3), .Y(new_n52_));
  AND3x1_ASAP7_75t_R   g19(.A(new_n39_), .B(new_n45_), .C(p2), .Y(new_n53_));
  NOR2x1_ASAP7_75t_R   g20(.A(p2), .B(new_n35_), .Y(new_n54_));
  AO21x1_ASAP7_75t_R   g21(.A1(new_n52_), .A2(new_n53_), .B(new_n54_), .Y(o3));
  NAND2x1_ASAP7_75t_R  g22(.A(p3), .B(p2), .Y(new_n56_));
  NAND2x1_ASAP7_75t_R  g23(.A(p0), .B(p4), .Y(new_n57_));
  OA31x2_ASAP7_75t_R   g24(.A1(p6), .A2(new_n56_), .A3(new_n57_), .B1(new_n45_), .Y(new_n58_));
  INVx1_ASAP7_75t_R    g25(.A(p5), .Y(new_n59_));
  AOI21x1_ASAP7_75t_R  g26(.A1(p3), .A2(new_n59_), .B(new_n36_), .Y(new_n60_));
  INVx1_ASAP7_75t_R    g27(.A(p4), .Y(new_n61_));
  NAND3x1_ASAP7_75t_R  g28(.A(new_n61_), .B(p3), .C(p5), .Y(new_n62_));
  AND2x2_ASAP7_75t_R   g29(.A(p0), .B(p6), .Y(new_n63_));
  NAND3x1_ASAP7_75t_R  g30(.A(new_n60_), .B(new_n62_), .C(new_n63_), .Y(new_n64_));
  OA21x2_ASAP7_75t_R   g31(.A1(p2), .A2(new_n52_), .B(p1), .Y(new_n65_));
  AOI21x1_ASAP7_75t_R  g32(.A1(new_n58_), .A2(new_n64_), .B(new_n65_), .Y(o4));
  NOR2x1_ASAP7_75t_R   g33(.A(new_n45_), .B(new_n54_), .Y(new_n67_));
  OAI21x1_ASAP7_75t_R  g34(.A1(p1), .A2(new_n60_), .B(p0), .Y(new_n68_));
  NOR2x1_ASAP7_75t_R   g35(.A(new_n67_), .B(new_n68_), .Y(o5));
  NOR2x1_ASAP7_75t_R   g36(.A(new_n56_), .B(new_n63_), .Y(new_n70_));
  AND2x2_ASAP7_75t_R   g37(.A(p1), .B(new_n56_), .Y(new_n71_));
  AOI211x1_ASAP7_75t_R g38(.A1(new_n45_), .A2(new_n70_), .B(new_n44_), .C(new_n71_), .Y(o6));
  NAND2x1_ASAP7_75t_R  g39(.A(p1), .B(p6), .Y(new_n73_));
  AOI21x1_ASAP7_75t_R  g40(.A1(new_n73_), .A2(new_n34_), .B(new_n56_), .Y(new_n74_));
  AO21x1_ASAP7_75t_R   g41(.A1(p0), .A2(o19), .B(new_n74_), .Y(o7));
  INVx1_ASAP7_75t_R    g42(.A(new_n44_), .Y(new_n76_));
  AOI221x1_ASAP7_75t_R g43(.A1(new_n50_), .A2(new_n45_), .B1(new_n71_), .B2(new_n76_), .C(new_n39_), .Y(o8));
  AOI221x1_ASAP7_75t_R g44(.A1(new_n39_), .A2(new_n56_), .B1(new_n50_), .B2(new_n40_), .C(new_n46_), .Y(o9));
  NOR2x1_ASAP7_75t_R   g45(.A(p1), .B(p2), .Y(new_n79_));
  AO21x1_ASAP7_75t_R   g46(.A1(p3), .A2(new_n43_), .B(new_n79_), .Y(new_n80_));
  INVx1_ASAP7_75t_R    g47(.A(p6), .Y(new_n81_));
  AO21x1_ASAP7_75t_R   g48(.A1(p0), .A2(new_n81_), .B(new_n41_), .Y(new_n82_));
  OAI21x1_ASAP7_75t_R  g49(.A1(new_n67_), .A2(new_n80_), .B(new_n82_), .Y(o10));
  AND3x1_ASAP7_75t_R   g50(.A(new_n44_), .B(new_n43_), .C(new_n81_), .Y(o11));
  NOR2x1_ASAP7_75t_R   g51(.A(p0), .B(p6), .Y(new_n85_));
  OA21x2_ASAP7_75t_R   g52(.A1(new_n35_), .A2(new_n85_), .B(new_n79_), .Y(new_n86_));
  OA211x2_ASAP7_75t_R  g53(.A1(new_n39_), .A2(p2), .B(new_n35_), .C(p1), .Y(new_n87_));
  NOR2x1_ASAP7_75t_R   g54(.A(new_n86_), .B(new_n87_), .Y(o12));
  AND3x1_ASAP7_75t_R   g55(.A(new_n44_), .B(p1), .C(p6), .Y(o13));
  AND3x1_ASAP7_75t_R   g56(.A(new_n44_), .B(p1), .C(new_n81_), .Y(o14));
  AND3x1_ASAP7_75t_R   g57(.A(new_n48_), .B(p1), .C(new_n85_), .Y(o15));
  AND3x1_ASAP7_75t_R   g58(.A(new_n39_), .B(new_n35_), .C(p2), .Y(new_n92_));
  AND3x1_ASAP7_75t_R   g59(.A(new_n92_), .B(p1), .C(p6), .Y(o16));
  AND3x1_ASAP7_75t_R   g60(.A(new_n48_), .B(p1), .C(new_n63_), .Y(o17));
  AND5x1_ASAP7_75t_R   g61(.A(p0), .B(new_n81_), .C(new_n35_), .D(p1), .E(p2), .Y(o18));
  NAND2x1_ASAP7_75t_R  g62(.A(p6), .B(p2), .Y(new_n96_));
  AO21x1_ASAP7_75t_R   g63(.A1(p3), .A2(new_n57_), .B(new_n96_), .Y(new_n97_));
  OA21x2_ASAP7_75t_R   g64(.A1(new_n56_), .A2(new_n63_), .B(p1), .Y(new_n98_));
  AOI21x1_ASAP7_75t_R  g65(.A1(new_n45_), .A2(new_n97_), .B(new_n98_), .Y(o20));
  AND5x1_ASAP7_75t_R   g66(.A(p0), .B(new_n59_), .C(p4), .D(p3), .E(p2), .Y(new_n100_));
  OA211x2_ASAP7_75t_R  g67(.A1(new_n92_), .A2(new_n100_), .B(new_n45_), .C(p6), .Y(o21));
  AOI21x1_ASAP7_75t_R  g68(.A1(new_n45_), .A2(new_n64_), .B(new_n98_), .Y(o22));
  assign               o23 = 1'b1;
  OA211x2_ASAP7_75t_R  g69(.A1(new_n85_), .A2(new_n63_), .B(p3), .C(new_n79_), .Y(o24));
  AND3x1_ASAP7_75t_R   g70(.A(new_n54_), .B(p6), .C(new_n43_), .Y(o25));
endmodule


