// Benchmark "/tmp/" written by ABC on Wed Oct 21 14:30:13 2026

module \/tmp/  ( 
    p3, p5, p2, p4, p6, p0, p1,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25  );
  input  p3, p5, p2, p4, p6, p0, p1;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25;
  wire new_n34_, new_n35_, new_n36_, new_n37_, new_n38_, new_n40_, new_n41_,
    new_n42_, new_n43_, new_n44_, new_n45_, new_n46_, new_n47_, new_n48_,
    new_n50_, new_n51_, new_n53_, new_n54_, new_n55_, new_n57_, new_n58_,
    new_n59_, new_n60_, new_n61_, new_n62_, new_n63_, new_n64_, new_n65_,
    new_n67_, new_n68_, new_n70_, new_n71_, new_n73_, new_n75_, new_n78_,
    new_n79_, new_n80_, new_n83_, new_n84_, new_n85_, new_n89_, new_n95_,
    new_n96_, new_n98_, new_n99_, new_n101_;
  OR3x1_ASAP7_75t_R    g00(.A(p6), .B(p0), .C(p1), .Y(new_n34_));
  NAND2x1_ASAP7_75t_R  g01(.A(p3), .B(p2), .Y(new_n35_));
  INVx1_ASAP7_75t_R    g02(.A(new_n35_), .Y(new_n36_));
  NOR2x1_ASAP7_75t_R   g03(.A(p3), .B(p2), .Y(new_n37_));
  AND3x1_ASAP7_75t_R   g04(.A(new_n37_), .B(p0), .C(p1), .Y(new_n38_));
  AO21x1_ASAP7_75t_R   g05(.A1(new_n34_), .A2(new_n36_), .B(new_n38_), .Y(o0));
  INVx1_ASAP7_75t_R    g06(.A(p2), .Y(new_n40_));
  NAND2x1_ASAP7_75t_R  g07(.A(p3), .B(new_n40_), .Y(new_n41_));
  INVx1_ASAP7_75t_R    g08(.A(p0), .Y(new_n42_));
  NOR2x1_ASAP7_75t_R   g09(.A(p1), .B(new_n42_), .Y(new_n43_));
  INVx1_ASAP7_75t_R    g10(.A(p3), .Y(new_n44_));
  OR3x1_ASAP7_75t_R    g11(.A(new_n44_), .B(new_n40_), .C(p6), .Y(new_n45_));
  NOR2x1_ASAP7_75t_R   g12(.A(p0), .B(p1), .Y(new_n46_));
  INVx1_ASAP7_75t_R    g13(.A(p1), .Y(new_n47_));
  AOI21x1_ASAP7_75t_R  g14(.A1(p0), .A2(new_n37_), .B(new_n47_), .Y(new_n48_));
  AOI221x1_ASAP7_75t_R g15(.A1(new_n41_), .A2(new_n43_), .B1(new_n45_), .B2(new_n46_), .C(new_n48_), .Y(o1));
  OA21x2_ASAP7_75t_R   g16(.A1(p3), .A2(new_n40_), .B(p0), .Y(new_n50_));
  OR3x1_ASAP7_75t_R    g17(.A(new_n44_), .B(p2), .C(p6), .Y(new_n51_));
  AOI221x1_ASAP7_75t_R g18(.A1(new_n50_), .A2(new_n51_), .B1(new_n42_), .B2(new_n45_), .C(p1), .Y(o2));
  INVx1_ASAP7_75t_R    g19(.A(p6), .Y(new_n53_));
  AO21x1_ASAP7_75t_R   g20(.A1(new_n42_), .A2(new_n47_), .B(new_n40_), .Y(new_n54_));
  INVx1_ASAP7_75t_R    g21(.A(new_n37_), .Y(new_n55_));
  OA211x2_ASAP7_75t_R  g22(.A1(new_n53_), .A2(new_n35_), .B(new_n54_), .C(new_n55_), .Y(o3));
  NAND2x1_ASAP7_75t_R  g23(.A(p4), .B(p0), .Y(new_n57_));
  OA31x2_ASAP7_75t_R   g24(.A1(p6), .A2(new_n35_), .A3(new_n57_), .B1(new_n47_), .Y(new_n58_));
  INVx1_ASAP7_75t_R    g25(.A(p5), .Y(new_n59_));
  AOI21x1_ASAP7_75t_R  g26(.A1(p3), .A2(new_n59_), .B(new_n40_), .Y(new_n60_));
  INVx1_ASAP7_75t_R    g27(.A(p4), .Y(new_n61_));
  NAND3x1_ASAP7_75t_R  g28(.A(new_n61_), .B(p3), .C(p5), .Y(new_n62_));
  AND2x2_ASAP7_75t_R   g29(.A(p6), .B(p0), .Y(new_n63_));
  NAND3x1_ASAP7_75t_R  g30(.A(new_n60_), .B(new_n62_), .C(new_n63_), .Y(new_n64_));
  OA21x2_ASAP7_75t_R   g31(.A1(new_n53_), .A2(new_n41_), .B(p1), .Y(new_n65_));
  AOI21x1_ASAP7_75t_R  g32(.A1(new_n58_), .A2(new_n64_), .B(new_n65_), .Y(o4));
  AND2x2_ASAP7_75t_R   g33(.A(p1), .B(new_n41_), .Y(new_n67_));
  OAI21x1_ASAP7_75t_R  g34(.A1(p1), .A2(new_n60_), .B(p0), .Y(new_n68_));
  NOR2x1_ASAP7_75t_R   g35(.A(new_n67_), .B(new_n68_), .Y(o5));
  AO21x1_ASAP7_75t_R   g36(.A1(p6), .A2(p0), .B(new_n35_), .Y(new_n70_));
  NAND2x1_ASAP7_75t_R  g37(.A(p1), .B(new_n35_), .Y(new_n71_));
  OA211x2_ASAP7_75t_R  g38(.A1(p1), .A2(new_n70_), .B(new_n71_), .C(new_n55_), .Y(o6));
  OAI21x1_ASAP7_75t_R  g39(.A1(new_n53_), .A2(new_n47_), .B(new_n34_), .Y(new_n73_));
  AO21x1_ASAP7_75t_R   g40(.A1(new_n36_), .A2(new_n73_), .B(new_n38_), .Y(o7));
  NOR2x1_ASAP7_75t_R   g41(.A(new_n37_), .B(new_n71_), .Y(new_n75_));
  AOI211x1_ASAP7_75t_R g42(.A1(new_n47_), .A2(new_n51_), .B(new_n42_), .C(new_n75_), .Y(o8));
  AOI221x1_ASAP7_75t_R g43(.A1(new_n42_), .A2(new_n35_), .B1(new_n51_), .B2(new_n43_), .C(new_n48_), .Y(o9));
  NOR2x1_ASAP7_75t_R   g44(.A(p2), .B(p1), .Y(new_n78_));
  AO21x1_ASAP7_75t_R   g45(.A1(p3), .A2(new_n46_), .B(new_n78_), .Y(new_n79_));
  AO21x1_ASAP7_75t_R   g46(.A1(new_n53_), .A2(p0), .B(new_n41_), .Y(new_n80_));
  OAI21x1_ASAP7_75t_R  g47(.A1(new_n79_), .A2(new_n67_), .B(new_n80_), .Y(o10));
  AND3x1_ASAP7_75t_R   g48(.A(new_n37_), .B(new_n46_), .C(new_n53_), .Y(o11));
  NOR2x1_ASAP7_75t_R   g49(.A(p6), .B(p0), .Y(new_n83_));
  OA21x2_ASAP7_75t_R   g50(.A1(new_n44_), .A2(new_n83_), .B(new_n78_), .Y(new_n84_));
  OA211x2_ASAP7_75t_R  g51(.A1(p2), .A2(new_n42_), .B(new_n44_), .C(p1), .Y(new_n85_));
  NOR2x1_ASAP7_75t_R   g52(.A(new_n84_), .B(new_n85_), .Y(o12));
  AND3x1_ASAP7_75t_R   g53(.A(new_n37_), .B(p6), .C(p1), .Y(o13));
  AND3x1_ASAP7_75t_R   g54(.A(new_n37_), .B(new_n53_), .C(p1), .Y(o14));
  AND3x1_ASAP7_75t_R   g55(.A(new_n44_), .B(p2), .C(p1), .Y(new_n89_));
  AND2x2_ASAP7_75t_R   g56(.A(new_n83_), .B(new_n89_), .Y(o15));
  AND3x1_ASAP7_75t_R   g57(.A(new_n89_), .B(p6), .C(new_n42_), .Y(o16));
  AND2x2_ASAP7_75t_R   g58(.A(new_n63_), .B(new_n89_), .Y(o17));
  AND3x1_ASAP7_75t_R   g59(.A(new_n89_), .B(new_n53_), .C(p0), .Y(o18));
  AND3x1_ASAP7_75t_R   g60(.A(new_n44_), .B(new_n40_), .C(p1), .Y(o19));
  AND2x2_ASAP7_75t_R   g61(.A(p3), .B(new_n57_), .Y(new_n95_));
  OR3x1_ASAP7_75t_R    g62(.A(new_n40_), .B(new_n53_), .C(p1), .Y(new_n96_));
  OAI22x1_ASAP7_75t_R  g63(.A1(new_n70_), .A2(new_n47_), .B1(new_n95_), .B2(new_n96_), .Y(o20));
  AND3x1_ASAP7_75t_R   g64(.A(new_n44_), .B(new_n42_), .C(p2), .Y(new_n98_));
  AND5x1_ASAP7_75t_R   g65(.A(new_n59_), .B(p3), .C(p2), .D(p4), .E(p0), .Y(new_n99_));
  OA211x2_ASAP7_75t_R  g66(.A1(new_n98_), .A2(new_n99_), .B(p6), .C(new_n47_), .Y(o21));
  OA21x2_ASAP7_75t_R   g67(.A1(new_n35_), .A2(new_n63_), .B(p1), .Y(new_n101_));
  AOI21x1_ASAP7_75t_R  g68(.A1(new_n47_), .A2(new_n64_), .B(new_n101_), .Y(o22));
  assign               o23 = 1'b1;
  OA211x2_ASAP7_75t_R  g69(.A1(new_n83_), .A2(new_n63_), .B(p3), .C(new_n78_), .Y(o24));
  AND5x1_ASAP7_75t_R   g70(.A(p3), .B(new_n40_), .C(new_n42_), .D(new_n47_), .E(p6), .Y(o25));
endmodule


