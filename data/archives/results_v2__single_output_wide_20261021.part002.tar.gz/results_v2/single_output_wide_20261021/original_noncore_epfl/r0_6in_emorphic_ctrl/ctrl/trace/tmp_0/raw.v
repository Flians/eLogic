// Benchmark "/tmp/" written by ABC on Wed Oct 21 14:30:10 2026

module \/tmp/  ( 
    p2, p6, p4, p3, p0, p1, p5,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25  );
  input  p2, p6, p4, p3, p0, p1, p5;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25;
  wire new_n34_, new_n35_, new_n36_, new_n37_, new_n39_, new_n40_, new_n41_,
    new_n42_, new_n43_, new_n44_, new_n45_, new_n46_, new_n47_, new_n49_,
    new_n50_, new_n52_, new_n54_, new_n55_, new_n56_, new_n57_, new_n58_,
    new_n59_, new_n60_, new_n62_, new_n63_, new_n64_, new_n66_, new_n67_,
    new_n69_, new_n70_, new_n73_, new_n76_, new_n77_, new_n78_, new_n79_,
    new_n82_, new_n83_, new_n84_, new_n89_, new_n90_, new_n92_, new_n95_,
    new_n96_, new_n97_, new_n99_, new_n100_, new_n102_, new_n103_,
    new_n104_, new_n107_, new_n108_;
  NOR2x1_ASAP7_75t_R   g00(.A(p2), .B(p3), .Y(new_n34_));
  NAND2x1_ASAP7_75t_R  g01(.A(p2), .B(p3), .Y(new_n35_));
  INVx1_ASAP7_75t_R    g02(.A(new_n35_), .Y(new_n36_));
  OR3x1_ASAP7_75t_R    g03(.A(p6), .B(p0), .C(p1), .Y(new_n37_));
  AO32x1_ASAP7_75t_R   g04(.A1(p0), .A2(p1), .A3(new_n34_), .B1(new_n36_), .B2(new_n37_), .Y(o0));
  INVx1_ASAP7_75t_R    g05(.A(p0), .Y(new_n39_));
  NOR2x1_ASAP7_75t_R   g06(.A(p1), .B(new_n39_), .Y(new_n40_));
  INVx1_ASAP7_75t_R    g07(.A(p2), .Y(new_n41_));
  NAND2x1_ASAP7_75t_R  g08(.A(p3), .B(new_n41_), .Y(new_n42_));
  INVx1_ASAP7_75t_R    g09(.A(p3), .Y(new_n43_));
  OR3x1_ASAP7_75t_R    g10(.A(new_n41_), .B(new_n43_), .C(p6), .Y(new_n44_));
  NOR2x1_ASAP7_75t_R   g11(.A(p0), .B(p1), .Y(new_n45_));
  INVx1_ASAP7_75t_R    g12(.A(p1), .Y(new_n46_));
  AOI21x1_ASAP7_75t_R  g13(.A1(p0), .A2(new_n34_), .B(new_n46_), .Y(new_n47_));
  AOI221x1_ASAP7_75t_R g14(.A1(new_n40_), .A2(new_n42_), .B1(new_n44_), .B2(new_n45_), .C(new_n47_), .Y(o1));
  OA21x2_ASAP7_75t_R   g15(.A1(p3), .A2(new_n41_), .B(p0), .Y(new_n49_));
  OR3x1_ASAP7_75t_R    g16(.A(new_n43_), .B(p2), .C(p6), .Y(new_n50_));
  AOI221x1_ASAP7_75t_R g17(.A1(new_n49_), .A2(new_n50_), .B1(new_n39_), .B2(new_n44_), .C(p1), .Y(o2));
  NAND2x1_ASAP7_75t_R  g18(.A(p2), .B(new_n45_), .Y(new_n52_));
  AOI22x1_ASAP7_75t_R  g19(.A1(new_n52_), .A2(new_n42_), .B1(p6), .B2(new_n36_), .Y(o3));
  AND2x2_ASAP7_75t_R   g20(.A(p4), .B(p5), .Y(new_n54_));
  AND3x1_ASAP7_75t_R   g21(.A(p2), .B(p6), .C(p0), .Y(new_n55_));
  OAI21x1_ASAP7_75t_R  g22(.A1(new_n43_), .A2(new_n54_), .B(new_n55_), .Y(new_n56_));
  NAND2x1_ASAP7_75t_R  g23(.A(p4), .B(p0), .Y(new_n57_));
  OA31x2_ASAP7_75t_R   g24(.A1(p6), .A2(new_n35_), .A3(new_n57_), .B1(new_n46_), .Y(new_n58_));
  NOR2x1_ASAP7_75t_R   g25(.A(p2), .B(new_n43_), .Y(new_n59_));
  AOI21x1_ASAP7_75t_R  g26(.A1(p6), .A2(new_n59_), .B(new_n46_), .Y(new_n60_));
  AOI21x1_ASAP7_75t_R  g27(.A1(new_n56_), .A2(new_n58_), .B(new_n60_), .Y(o4));
  AO21x1_ASAP7_75t_R   g28(.A1(p3), .A2(new_n41_), .B(new_n46_), .Y(new_n62_));
  AOI21x1_ASAP7_75t_R  g29(.A1(p2), .A2(p5), .B(p1), .Y(new_n63_));
  OAI21x1_ASAP7_75t_R  g30(.A1(new_n41_), .A2(p3), .B(new_n63_), .Y(new_n64_));
  AND3x1_ASAP7_75t_R   g31(.A(new_n62_), .B(new_n64_), .C(p0), .Y(o5));
  AOI21x1_ASAP7_75t_R  g32(.A1(p6), .A2(p0), .B(p1), .Y(new_n66_));
  AOI21x1_ASAP7_75t_R  g33(.A1(p2), .A2(p3), .B(new_n46_), .Y(new_n67_));
  AOI211x1_ASAP7_75t_R g34(.A1(new_n66_), .A2(new_n36_), .B(new_n34_), .C(new_n67_), .Y(o6));
  AO21x1_ASAP7_75t_R   g35(.A1(new_n39_), .A2(new_n46_), .B(p6), .Y(new_n69_));
  NAND2x1_ASAP7_75t_R  g36(.A(p6), .B(new_n46_), .Y(new_n70_));
  AND3x1_ASAP7_75t_R   g37(.A(new_n41_), .B(new_n43_), .C(p1), .Y(o19));
  AO32x1_ASAP7_75t_R   g38(.A1(new_n69_), .A2(new_n36_), .A3(new_n70_), .B1(o19), .B2(p0), .Y(o7));
  INVx1_ASAP7_75t_R    g39(.A(new_n34_), .Y(new_n73_));
  AOI221x1_ASAP7_75t_R g40(.A1(new_n73_), .A2(new_n67_), .B1(new_n50_), .B2(new_n46_), .C(new_n39_), .Y(o8));
  AOI221x1_ASAP7_75t_R g41(.A1(new_n39_), .A2(new_n35_), .B1(new_n50_), .B2(new_n40_), .C(new_n47_), .Y(o9));
  INVx1_ASAP7_75t_R    g42(.A(p6), .Y(new_n76_));
  NAND2x1_ASAP7_75t_R  g43(.A(p0), .B(new_n76_), .Y(new_n77_));
  NOR2x1_ASAP7_75t_R   g44(.A(p2), .B(p1), .Y(new_n78_));
  AOI21x1_ASAP7_75t_R  g45(.A1(p3), .A2(new_n45_), .B(new_n78_), .Y(new_n79_));
  AO32x1_ASAP7_75t_R   g46(.A1(new_n41_), .A2(p3), .A3(new_n77_), .B1(new_n79_), .B2(new_n62_), .Y(o10));
  AND3x1_ASAP7_75t_R   g47(.A(new_n34_), .B(new_n45_), .C(new_n76_), .Y(o11));
  OR3x1_ASAP7_75t_R    g48(.A(p2), .B(p6), .C(p0), .Y(new_n82_));
  NOR2x1_ASAP7_75t_R   g49(.A(p1), .B(new_n34_), .Y(new_n83_));
  AO21x1_ASAP7_75t_R   g50(.A1(p0), .A2(new_n41_), .B(p3), .Y(new_n84_));
  AO22x1_ASAP7_75t_R   g51(.A1(new_n82_), .A2(new_n83_), .B1(p1), .B2(new_n84_), .Y(o12));
  AND3x1_ASAP7_75t_R   g52(.A(new_n34_), .B(p6), .C(p1), .Y(o13));
  AND3x1_ASAP7_75t_R   g53(.A(new_n34_), .B(new_n76_), .C(p1), .Y(o14));
  AND5x1_ASAP7_75t_R   g54(.A(p2), .B(new_n76_), .C(new_n43_), .D(new_n39_), .E(p1), .Y(o15));
  AND2x2_ASAP7_75t_R   g55(.A(p2), .B(p6), .Y(new_n89_));
  NOR2x1_ASAP7_75t_R   g56(.A(p3), .B(p0), .Y(new_n90_));
  AND3x1_ASAP7_75t_R   g57(.A(new_n89_), .B(p1), .C(new_n90_), .Y(o16));
  AND3x1_ASAP7_75t_R   g58(.A(p6), .B(p0), .C(p1), .Y(new_n92_));
  AND3x1_ASAP7_75t_R   g59(.A(new_n92_), .B(p2), .C(new_n43_), .Y(o17));
  AND5x1_ASAP7_75t_R   g60(.A(p2), .B(new_n76_), .C(new_n43_), .D(p0), .E(p1), .Y(o18));
  OAI21x1_ASAP7_75t_R  g61(.A1(p4), .A2(new_n43_), .B(new_n55_), .Y(new_n95_));
  AOI21x1_ASAP7_75t_R  g62(.A1(new_n90_), .A2(new_n89_), .B(p1), .Y(new_n96_));
  AO21x1_ASAP7_75t_R   g63(.A1(p1), .A2(new_n35_), .B(new_n92_), .Y(new_n97_));
  AOI21x1_ASAP7_75t_R  g64(.A1(new_n95_), .A2(new_n96_), .B(new_n97_), .Y(o20));
  NAND2x1_ASAP7_75t_R  g65(.A(p2), .B(new_n90_), .Y(new_n99_));
  OR3x1_ASAP7_75t_R    g66(.A(new_n35_), .B(new_n57_), .C(p5), .Y(new_n100_));
  AOI21x1_ASAP7_75t_R  g67(.A1(new_n99_), .A2(new_n100_), .B(new_n70_), .Y(o21));
  AOI211x1_ASAP7_75t_R g68(.A1(p1), .A2(new_n35_), .B(new_n66_), .C(new_n92_), .Y(new_n102_));
  NAND2x1_ASAP7_75t_R  g69(.A(p3), .B(p5), .Y(new_n103_));
  OR3x1_ASAP7_75t_R    g70(.A(new_n103_), .B(p4), .C(p1), .Y(new_n104_));
  AND3x1_ASAP7_75t_R   g71(.A(new_n102_), .B(new_n64_), .C(new_n104_), .Y(o22));
  assign               o23 = 1'b1;
  NOR2x1_ASAP7_75t_R   g72(.A(p6), .B(p0), .Y(new_n107_));
  AND2x2_ASAP7_75t_R   g73(.A(p6), .B(p0), .Y(new_n108_));
  OA211x2_ASAP7_75t_R  g74(.A1(new_n107_), .A2(new_n108_), .B(p3), .C(new_n78_), .Y(o24));
  AND3x1_ASAP7_75t_R   g75(.A(new_n59_), .B(p6), .C(new_n45_), .Y(o25));
endmodule


