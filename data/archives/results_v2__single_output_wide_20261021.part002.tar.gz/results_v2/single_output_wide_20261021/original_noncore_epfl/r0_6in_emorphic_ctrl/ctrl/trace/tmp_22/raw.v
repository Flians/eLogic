// Benchmark "/tmp/" written by ABC on Wed Oct 21 14:30:14 2026

module \/tmp/  ( 
    p1, p3, p5, p6, p4, p2, p0,
    o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25  );
  input  p1, p3, p5, p6, p4, p2, p0;
  output o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, o10, o11, o12, o13, o14, o15,
    o16, o17, o18, o19, o20, o21, o22, o23, o24, o25;
  wire new_n34_, new_n35_, new_n36_, new_n37_, new_n39_, new_n40_, new_n41_,
    new_n42_, new_n43_, new_n44_, new_n45_, new_n46_, new_n47_, new_n49_,
    new_n50_, new_n52_, new_n54_, new_n55_, new_n56_, new_n57_, new_n58_,
    new_n59_, new_n60_, new_n61_, new_n63_, new_n64_, new_n65_, new_n66_,
    new_n68_, new_n69_, new_n70_, new_n72_, new_n73_, new_n74_, new_n77_,
    new_n80_, new_n81_, new_n82_, new_n85_, new_n86_, new_n87_, new_n88_,
    new_n94_, new_n97_, new_n98_, new_n100_, new_n102_;
  AND2x2_ASAP7_75t_R   g00(.A(p3), .B(p2), .Y(new_n34_));
  NOR2x1_ASAP7_75t_R   g01(.A(p3), .B(p2), .Y(new_n35_));
  AND3x1_ASAP7_75t_R   g02(.A(new_n35_), .B(p1), .C(p0), .Y(new_n36_));
  OR3x1_ASAP7_75t_R    g03(.A(p1), .B(p6), .C(p0), .Y(new_n37_));
  OA21x2_ASAP7_75t_R   g04(.A1(new_n34_), .A2(new_n36_), .B(new_n37_), .Y(o0));
  INVx1_ASAP7_75t_R    g05(.A(p2), .Y(new_n39_));
  NAND2x1_ASAP7_75t_R  g06(.A(p3), .B(new_n39_), .Y(new_n40_));
  INVx1_ASAP7_75t_R    g07(.A(p0), .Y(new_n41_));
  NOR2x1_ASAP7_75t_R   g08(.A(p1), .B(new_n41_), .Y(new_n42_));
  INVx1_ASAP7_75t_R    g09(.A(p3), .Y(new_n43_));
  OR3x1_ASAP7_75t_R    g10(.A(new_n43_), .B(new_n39_), .C(p6), .Y(new_n44_));
  NOR2x1_ASAP7_75t_R   g11(.A(p1), .B(p0), .Y(new_n45_));
  INVx1_ASAP7_75t_R    g12(.A(p1), .Y(new_n46_));
  AOI21x1_ASAP7_75t_R  g13(.A1(p0), .A2(new_n35_), .B(new_n46_), .Y(new_n47_));
  AOI221x1_ASAP7_75t_R g14(.A1(new_n40_), .A2(new_n42_), .B1(new_n44_), .B2(new_n45_), .C(new_n47_), .Y(o1));
  OA21x2_ASAP7_75t_R   g15(.A1(p3), .A2(new_n39_), .B(p0), .Y(new_n49_));
  OR3x1_ASAP7_75t_R    g16(.A(new_n43_), .B(p6), .C(p2), .Y(new_n50_));
  AOI221x1_ASAP7_75t_R g17(.A1(new_n49_), .A2(new_n50_), .B1(new_n41_), .B2(new_n44_), .C(p1), .Y(o2));
  NAND2x1_ASAP7_75t_R  g18(.A(p2), .B(new_n45_), .Y(new_n52_));
  AOI22x1_ASAP7_75t_R  g19(.A1(new_n52_), .A2(new_n40_), .B1(p6), .B2(new_n34_), .Y(o3));
  AND2x2_ASAP7_75t_R   g20(.A(p5), .B(p4), .Y(new_n54_));
  AND3x1_ASAP7_75t_R   g21(.A(p6), .B(p2), .C(p0), .Y(new_n55_));
  OAI21x1_ASAP7_75t_R  g22(.A1(new_n43_), .A2(new_n54_), .B(new_n55_), .Y(new_n56_));
  NAND2x1_ASAP7_75t_R  g23(.A(p3), .B(p2), .Y(new_n57_));
  NAND2x1_ASAP7_75t_R  g24(.A(p4), .B(p0), .Y(new_n58_));
  OA31x2_ASAP7_75t_R   g25(.A1(p6), .A2(new_n57_), .A3(new_n58_), .B1(new_n46_), .Y(new_n59_));
  NAND2x1_ASAP7_75t_R  g26(.A(p3), .B(p6), .Y(new_n60_));
  OA21x2_ASAP7_75t_R   g27(.A1(p2), .A2(new_n60_), .B(p1), .Y(new_n61_));
  AOI21x1_ASAP7_75t_R  g28(.A1(new_n56_), .A2(new_n59_), .B(new_n61_), .Y(o4));
  INVx1_ASAP7_75t_R    g29(.A(p5), .Y(new_n63_));
  AO21x1_ASAP7_75t_R   g30(.A1(p3), .A2(new_n63_), .B(new_n39_), .Y(new_n64_));
  NOR2x1_ASAP7_75t_R   g31(.A(p2), .B(new_n43_), .Y(new_n65_));
  NOR2x1_ASAP7_75t_R   g32(.A(new_n46_), .B(new_n65_), .Y(new_n66_));
  AOI211x1_ASAP7_75t_R g33(.A1(new_n46_), .A2(new_n64_), .B(new_n41_), .C(new_n66_), .Y(o5));
  NAND2x1_ASAP7_75t_R  g34(.A(p6), .B(p0), .Y(new_n68_));
  AND3x1_ASAP7_75t_R   g35(.A(new_n34_), .B(new_n46_), .C(new_n68_), .Y(new_n69_));
  AOI21x1_ASAP7_75t_R  g36(.A1(p3), .A2(p2), .B(new_n46_), .Y(new_n70_));
  NOR3x1_ASAP7_75t_R   g37(.A(new_n69_), .B(new_n35_), .C(new_n70_), .Y(o6));
  INVx1_ASAP7_75t_R    g38(.A(p6), .Y(new_n72_));
  AO21x1_ASAP7_75t_R   g39(.A1(new_n72_), .A2(new_n41_), .B(p1), .Y(new_n73_));
  NAND2x1_ASAP7_75t_R  g40(.A(p1), .B(new_n72_), .Y(new_n74_));
  AND3x1_ASAP7_75t_R   g41(.A(new_n43_), .B(new_n39_), .C(p1), .Y(o19));
  AO32x1_ASAP7_75t_R   g42(.A1(new_n73_), .A2(new_n34_), .A3(new_n74_), .B1(o19), .B2(p0), .Y(o7));
  INVx1_ASAP7_75t_R    g43(.A(new_n35_), .Y(new_n77_));
  AOI221x1_ASAP7_75t_R g44(.A1(new_n77_), .A2(new_n70_), .B1(new_n50_), .B2(new_n46_), .C(new_n41_), .Y(o8));
  AOI221x1_ASAP7_75t_R g45(.A1(new_n41_), .A2(new_n57_), .B1(new_n50_), .B2(new_n42_), .C(new_n47_), .Y(o9));
  NOR2x1_ASAP7_75t_R   g46(.A(p1), .B(p2), .Y(new_n80_));
  AO21x1_ASAP7_75t_R   g47(.A1(p3), .A2(new_n45_), .B(new_n80_), .Y(new_n81_));
  NOR2x1_ASAP7_75t_R   g48(.A(p6), .B(new_n41_), .Y(new_n82_));
  OAI22x1_ASAP7_75t_R  g49(.A1(new_n66_), .A2(new_n81_), .B1(new_n40_), .B2(new_n82_), .Y(o10));
  AND3x1_ASAP7_75t_R   g50(.A(new_n45_), .B(new_n35_), .C(new_n72_), .Y(o11));
  NOR2x1_ASAP7_75t_R   g51(.A(p3), .B(p0), .Y(new_n85_));
  AND3x1_ASAP7_75t_R   g52(.A(new_n43_), .B(p1), .C(p2), .Y(new_n86_));
  NOR2x1_ASAP7_75t_R   g53(.A(p6), .B(p0), .Y(new_n87_));
  OA21x2_ASAP7_75t_R   g54(.A1(new_n43_), .A2(new_n87_), .B(new_n80_), .Y(new_n88_));
  AOI211x1_ASAP7_75t_R g55(.A1(p1), .A2(new_n85_), .B(new_n86_), .C(new_n88_), .Y(o12));
  AND3x1_ASAP7_75t_R   g56(.A(new_n35_), .B(p1), .C(p6), .Y(o13));
  AND3x1_ASAP7_75t_R   g57(.A(new_n35_), .B(p1), .C(new_n72_), .Y(o14));
  AND2x2_ASAP7_75t_R   g58(.A(new_n87_), .B(new_n86_), .Y(o15));
  AND3x1_ASAP7_75t_R   g59(.A(new_n86_), .B(p6), .C(new_n41_), .Y(o16));
  AND2x2_ASAP7_75t_R   g60(.A(p6), .B(p0), .Y(new_n94_));
  AND2x2_ASAP7_75t_R   g61(.A(new_n94_), .B(new_n86_), .Y(o17));
  AND2x2_ASAP7_75t_R   g62(.A(new_n82_), .B(new_n86_), .Y(o18));
  AND3x1_ASAP7_75t_R   g63(.A(new_n46_), .B(p6), .C(p2), .Y(new_n97_));
  NAND2x1_ASAP7_75t_R  g64(.A(p3), .B(new_n58_), .Y(new_n98_));
  AO32x1_ASAP7_75t_R   g65(.A1(p1), .A2(new_n34_), .A3(new_n68_), .B1(new_n97_), .B2(new_n98_), .Y(o20));
  AO21x1_ASAP7_75t_R   g66(.A1(p3), .A2(new_n63_), .B(new_n85_), .Y(new_n100_));
  AND3x1_ASAP7_75t_R   g67(.A(new_n100_), .B(new_n98_), .C(new_n97_), .Y(o21));
  OR3x1_ASAP7_75t_R    g68(.A(new_n94_), .B(new_n46_), .C(new_n57_), .Y(new_n102_));
  OAI21x1_ASAP7_75t_R  g69(.A1(p1), .A2(new_n56_), .B(new_n102_), .Y(o22));
  assign               o23 = 1'b1;
  OA211x2_ASAP7_75t_R  g70(.A1(new_n87_), .A2(new_n94_), .B(p3), .C(new_n80_), .Y(o24));
  AND5x1_ASAP7_75t_R   g71(.A(new_n46_), .B(new_n39_), .C(new_n41_), .D(p3), .E(p6), .Y(o25));
endmodule


