import json,csv
from pathlib import Path
R=Path('/home/flynn/workplace/MIGBalance');O=Path(__file__).parent;load=lambda p:json.loads(p.read_text())
old=load(R/'results_v2/scored_main_full_report_20261015/all_rows.json');new=load(R/'results_v2/helper_phase_full_report_20261016/all_rows.json');old={(r['k'],r['bench']):r for r in old if r['profile']=='protected_area'};pairs=[]
for x in new:
 if x['profile']!='protected_area':continue
 k=(x['k'],x['bench']);y=old[k];a=x['row'];b=y['row'];assert x['library_sha256']==y['library_sha256'] and a['input_sha256']==b['input_sha256'] and a['preprocessing']['sha256']==b['preprocessing']['sha256']
 if a['status']=='ok' and b['status']=='ok':
  da=a['measured']['area']-b['measured']['area'];dd=a['measured']['delay']-b['measured']['delay'];pairs.append(dict(k=k[0],bench=k[1],old_area=b['measured']['area'],new_area=a['measured']['area'],old_delay=b['measured']['delay'],new_delay=a['measured']['delay'],area_delta=da,delay_delta=dd,DA_nonregression=dd<-1e-6 or (abs(dd)<=1e-6 and da<=1e-6),old_report=y['report'],new_report=x['report']))
 else:assert a['status']==b['status']=='failed'
counts={m:[sum(p[m+'_delta']<-1e-6 for p in pairs),sum(abs(p[m+'_delta'])<=1e-6 for p in pairs),sum(p[m+'_delta']>1e-6 for p in pairs)] for m in ['delay','area']}
with (O/'canonical_main_pairs.csv').open('w') as f:
 w=csv.DictWriter(f,fieldnames=list(pairs[0]));w.writeheader();w.writerows(pairs)
q=O/'qualification.json';d=load(q);d['canonical_main_common_legal_better_equal_worse']=counts;d['canonical_main_common_legal_DA_nonregression']=all(p['DA_nonregression'] for p in pairs);d['conditional_common_legal_scope']='34same-input/library legal pairs;6shared failed design/library cases remain failures; not full20baseline dominance or universal whole-incumbent preservation.';q.write_text(json.dumps(d,indent=2)+'\n');print(counts,'commonlegal DA',d['canonical_main_common_legal_DA_nonregression'])
