#!/usr/bin/env python3
"""Freeze and rerun the three paper experiments under a common delay bound."""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
from concurrent.futures import ThreadPoolExecutor

PROJECT = Path(__file__).resolve().parents[2]
DESIGNS = 'aes_core arbiter div ethernet iwls05_i2c mem_ctrl RISC sasc simple_spi spi sqrt systemcaes systemcdes tv80 usb_funct usb_phy'.split()
ABLATION = 'aes_core arbiter div iwls05_i2c mem_ctrl sasc simple_spi spi systemcdes tv80 usb_phy'.split()
HEADER = 'stage design recipe rounds base_a base_d out_a out_d dA% dD% rnd cec secs rc'.split()
GOAL = dict(EPMAPPING_OBJECTIVE='area_delay_bound', EPMAPPING_AREA_UNDER_DELAY='1',
            EPMAPPING_WINDOW_SYN='0', EPMAPPING_WRITE_BASELINE='1',
            EPMAPPING_SAT_DC='0', EPMAPPING_DSE='0', EPMAPPING_EGG_REQ='1')
ARMS = {'full': {}, 'noSYN': {'EPMAPPING_SYN':'0'}, 'noEGG': {'EPMAPPING_EGG':'0'},
        'noDB': {'EPMAPPING_SUPER':'off'}, 'noCARE': {'EPMAPPING_DC':'0', 'EPMAPPING_SAT_DC':'0'}}

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--root', type=Path, required=True)
    ap.add_argument('--jobs', type=int, default=8)
    ap.add_argument('--timeout', type=int, default=3600)
    ap.add_argument('--abc-timeout', type=int, default=1000)
    ap.add_argument('--parts', default='mfs3,main,ablation')
    args = ap.parse_args()
    root = args.root.resolve(); root.mkdir(parents=True, exist_ok=True)
    frozen = root/'inputs'; manifest_path = root/'manifest.json'
    if not manifest_path.exists():
        frozen.mkdir(exist_ok=True)
        sources = ['build/epmapping/epmapping_check', 'epmapping/main.cpp', 'epmapping/epmapping.hpp',
                   'epmapping/objective.hpp', 'scripts/experiments/common.sh',
                   'scripts/experiments/run_three_parts.py', 'scripts/compare_with_aspdac25.sh']
        for rel in sources:
            shutil.copy2(PROJECT/rel, frozen/Path(rel).name)
        shutil.copy2(PROJECT/'tools/mockturtle/experiments/cell_libraries/asap7.genlib', frozen/'asap7.genlib')
        subprocess.run(['python3', str(PROJECT/'scripts/experiments/restrict_genlib.py'),
                        '--in', str(frozen/'asap7.genlib'), '--max-pins', '6',
                        '--out', str(frozen/'asap7_6in.genlib')], check=True)
        shutil.copy2(PROJECT/'epmapping/db/asap7_4in_3lvl_a050.super', frozen/'database.super')
        (frozen/'benchmarks').mkdir(exist_ok=True)
        for d in DESIGNS:
            shutil.copy2(PROJECT/f'tools/mockturtle/experiments/benchmarks/{d}.aig', frozen/'benchmarks'/f'{d}.aig')
        abc = Path(shutil.which('abc')).resolve()
        shutil.copy2(abc, frozen/'abc')
        manifest = dict(recorded_at=datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=8))).isoformat(),
                        objective='minimize area subject to initial worst-output delay', whole_window_synthesis=False,
                        goal=GOAL, arms=ARMS, designs=DESIGNS, ablation_designs=ABLATION,
                        jobs=args.jobs, timeout=args.timeout, abc_timeout=args.abc_timeout,
                        rounds=dict(mfs3=1, main=[1,6], ablation=6), archived_engine='inputs/epmapping_check',
                        engine_sha256=sha(frozen/'epmapping_check'),
                        frozen_sha256={str(p.relative_to(root)):sha(p) for p in frozen.rglob('*') if p.is_file()})
        manifest_path.write_text(json.dumps(manifest, indent=2)+'\n')
    manifest = json.loads(manifest_path.read_text())
    for name,h in manifest['frozen_sha256'].items():
        assert sha(root/name)==h, name
    assert (args.jobs,args.timeout,args.abc_timeout)==(manifest['jobs'],manifest['timeout'],manifest['abc_timeout']), 'different plan: use a new root'
    assert sha(PROJECT/'scripts/experiments/common.sh')==sha(frozen/'common.sh')
    environment = {k:v for k,v in os.environ.items() if not k.startswith(('EPMAPPING_', 'EPM_', 'MAP_EGG_'))}
    environment.update(EPM_BIN=str(frozen/'epmapping_check'), EPM_ROOT=str(root),
                       EPM_TIMEOUT=str(args.timeout), EPM_RETRIES='1', EPM_CAFFEINATE='0',
                       RAYON_NUM_THREADS='1', PATH=str(frozen)+os.pathsep+os.environ['PATH'])
    def engine(stage, arm, d, rounds, recipe, extras=None):
        wd=root/stage/f'{arm}.{d}'; rowfile=wd/'row.tsv'
        if rowfile.exists():
            return rowfile.read_text()
        options=dict(manifest['goal'], **(extras or {}))
        lib=frozen/('asap7_6in.genlib' if stage=='tab_mfs3' else 'asap7.genlib')
        options['EPMAPPING_SUPER']=str(frozen/'database.super') if options.get('EPMAPPING_SUPER')!='off' else 'off'
        flags=[f'{k}={v}' for k,v in options.items()]+[f'EPM_GENLIB={lib}']
        # Source the unchanged helper, then redirect benchmark lookup to frozen inputs.
        command=['bash','-c','source "$1"; BENCH="$2"; shift 2; run_engine "$@"','_',
                 str(PROJECT/'scripts/experiments/common.sh'),str(frozen/'benchmarks'),str(wd),d,str(rounds),recipe,*flags]
        completed=subprocess.run(command,env=environment,cwd=PROJECT,capture_output=True,text=True)
        if completed.returncode: raise RuntimeError(completed.stderr)
        row=completed.stdout.strip().splitlines()[-1]+'\n'
        assert len(row.strip().split('\t'))==14, completed.stdout
        rowfile.write_text(row)
        print(f'{stage}/{arm}.{d}: {row.strip()}',flush=True)
        return row
    def batch(stage, specs):
        with ThreadPoolExecutor(max_workers=args.jobs) as pool:
            rows=list(pool.map(lambda s:engine(stage,*s),specs))
        (root/stage/'summary.tsv').write_text('\t'.join(HEADER)+'\n'+''.join(rows))
    def abc_run(d):
        wd=root/'tab_mfs3'/f'abc.{d}'; wd.mkdir(exist_ok=True)
        result=wd/'result.json'
        if result.exists(): return json.loads(result.read_text())
        baseline=root/'tab_mfs3'/f'base.{d}'/'epmapping_mapped.v'
        ours=root/'tab_mfs3'/f'ours.{d}'/'epmapping_baseline.v'
        assert baseline.read_bytes()==ours.read_bytes(), f'different mapped starts: {d}'
        lib=frozen/'asap7_6in.genlib'; exe=frozen/'abc'
        def call(script, log, timeout):
            import time
            start=time.monotonic()
            with log.open('w') as stream:
                try: rc=subprocess.run([str(exe),'-c',script],stdout=stream,stderr=subprocess.STDOUT,env=environment,timeout=timeout).returncode
                except subprocess.TimeoutExpired: rc=124
            return rc,time.monotonic()-start
        def metrics(path):
            text=path.read_text()
            return {k:float(re.findall(r'\b'+k+r'\s*=\s*([0-9.]+)',text)[-1]) for k in ('area','delay')}
        rc,_=call(f'read_genlib {lib}; read -m {baseline}; print_stats',wd/'baseline.log',args.abc_timeout)
        assert rc==0; native=metrics(wd/'baseline.log')
        rc,secs=call(f'read_genlib {lib}; read -m {baseline}; mfs3 -a; print_stats; write_verilog {wd / "mapped.v"}',wd/'log',args.abc_timeout)
        data=dict(design=d,rc=rc,secs=secs,cec=0,validation_secs=0,baseline=native,baseline_sha256=sha(baseline))
        if rc==0:
            data.update(metrics(wd/'log'))
            crc,csecs=call(f'read_genlib {lib}; read -m {wd / "mapped.v"}; cec -n {frozen / "benchmarks" / (d+".aig")}',wd/'cec.log',args.timeout)
            data.update(cec=int(crc==0 and 'Networks are equivalent' in (wd/'cec.log').read_text()), validation_secs=csecs)
        result.write_text(json.dumps(data,indent=2)+'\n'); print('ABC '+json.dumps(data),flush=True)
        return data
    parts=args.parts.split(','); assert set(parts)<=set(['mfs3','main','ablation'])
    if 'mfs3' in parts:
        batch('tab_mfs3', [('base',d,0,'direct',dict(EPMAPPING_SKIP='1',EPMAPPING_BASELINE_CEC='1')) for d in DESIGNS]+
              [('ours',d,1,'direct',dict(EPM_TIMEOUT=str(args.abc_timeout))) for d in DESIGNS])
        with ThreadPoolExecutor(max_workers=args.jobs) as pool: abc_rows=list(pool.map(abc_run,DESIGNS))
        (root/'tab_mfs3'/'abc_results.json').write_text(json.dumps(abc_rows,indent=2)+'\n')
    if 'main' in parts:
        batch('tab_main',[(arm,d,r,'high_effort',{}) for arm,r in [('ae.r1',1),('ae',6)] for d in DESIGNS])
    if 'ablation' in parts:
        batch('ablation',[(arm,d,6,'high_effort',flags) for d in ABLATION for arm,flags in manifest['arms'].items()])

if __name__=='__main__': main()
