> Superseded during this run after the user required a 1000-second deadline for every post-mapping phase. Only the freshly rerun ABC batch is reused by results_v10_three_parts_1000 after byte-identical inputs, libraries, binaries and benchmarks are verified. Main and ablation were stopped before launch.

# Three-part constrained-area campaign

This archive reruns all three experimental parts from frozen inputs. No raw measurement is copied from an earlier campaign.

1. **Common mapped inputs:** 16 direct-mapped baselines, 16 one-round ePMapping runs and 16 ABC `mfs3 -a` runs on the same 40-cell ASAP7 subset. Both optimizers have a 1000-second optimization cap. ABC CEC is measured separately. The ePMapping process cap includes input mapping and CEC. ABC's raw area mode may increase delay; report raw outputs and a separate whole-output selection policy that returns the initial mapping when area or delay exceeds the native initial metric. This policy is not an internal timing-constrained variant of mfs3. Paired means exclude timeouts and use identical design subsets.
2. **Fully preprocessed inputs:** 16 one-round and 16 six-round-cap runs. Preprocessing repeats `fraig; resyn2rs; fraig; compress2rs`, keeping an iteration only when AND count falls, with a 20-iteration safety cap. Area-oriented mapping on the full ASAP7 genlib produces the initial netlist. This is a script-specific fixed point, not a global optimum. Own-input changes isolate post-mapping benefit; published ASPDAC'25 final numbers are an additional comparison with different starts.
3. **Ablation:** 11 designs × full/noSYN/noEGG/noDB/noCARE, all six-round-cap and identical fully preprocessed initial netlists. L1 remains the shared library fallback. Its measured runtime is reported, but no marginal-area attribution is claimed for it. Database removal is global, including internal cut mapping. Care removal supplies full masks and must record zero DC cuts. Marginal effects can be signed and are not additive.

All 103 optimization outputs use `area_delay_bound` / `AREA_UNDER_DELAY=1`: minimize area under the fixed initial worst-output delay, with physical-pin required times, net-area ranking and a rebuilt-round objective guard. Whole-window synthesis and unmap/remap DSE are off everywhere. Numerical timing tolerance is 0.001 ps. Six-round runs stop early on no progress; this is not a proof of convergence. Main and ablation runs have a 3600-second process cap, including preprocessing, mapping and CEC. Batches have at most 8 engine workers, each using one Rust worker, on a shared host; timings are observational.

Frozen executables, source, benchmarks, genlibs and database are in `inputs/`, with SHA256 provenance and the complete declared plan in `manifest.json`. Each engine run saves `log`, `experiment_env.txt`, `row.tsv`, an initial netlist and a final netlist. ABC saves native baseline statistics, raw optimization and CEC logs, result metadata and completed mapped outputs. Completed rows are resumable only under the same plan; failures require investigation, not silent inclusion.

Reproduce from the repository root:

```bash
python3 scripts/experiments/run_three_parts.py \
  --root results_v9_three_parts --jobs 8 --timeout 3600 --abc-timeout 1000
python3 scripts/experiments/report_three_parts.py --root results_v9_three_parts \
  --out epmapping_paper/DATE27-ePMapping-sub/doc/generated_results.tex
python3 scripts/experiments/plot_paper.py --root results_v9_three_parts \
  --out epmapping_paper/DATE27-ePMapping-sub/figs/results
make -C epmapping_paper/DATE27-ePMapping-sub all
```

The exporter requires all three parts, validates mode banners and hard bounds, checks raw CEC and metric consistency, verifies same initial netlist bytes across paired runs and ablations, and rejects a falsely disabled operator. The paper's Makefile uses this campaign exclusively; older archives remain available for historical analysis.
