"""Library-matched primitive region witness; no egraph saturation or optimization."""
import json
import re
import time
from pathlib import Path
from region_stitch import stitch, read_binary_aig, identifier


def physical_seed(data, library_json, local_node_limit=20000, global_node_limit=20000,
                  global_pool_limit=100000, recovery_seconds=2):
    start = time.perf_counter()

    def deadline():
        if time.perf_counter() - start > recovery_seconds:
            raise ValueError('global primitive witness construction deadline exceeded')

    if recovery_seconds <= 0:
        raise ValueError('global construction deadline exhausted')
    logic, stats = stitch(data, local_node_limit, global_node_limit, global_pool_limit)
    inputs, roots, gates = read_binary_aig(data)
    # Import the actual common evaluator's library functions, area and pins.
    cells = json.loads(Path(library_json).read_text())
    names = [c['name'] for c in cells]

    def choose(arity, tt):
        matches = [c for c in cells if len(c['vars']) == arity and c['tt'][0] == tt]
        matches = [c for c in matches if names.count(c['name']) == 1]
        if not matches:
            raise ValueError('library lacks unique single-output primitive')
        return min(matches, key=lambda c: (c['area'], max(c['pin_delay'].values(), default=0), c['name']))

    and2, inv = choose(2, 8), choose(1, 1)
    live = {int(v) for v in re.findall(r'^assign n(\d+) = .* & .*;$', logic, re.M)}
    negative = {x // 2 for x in roots if x > 1 and x & 1}
    negative.update(x // 2 for v in live for x in gates[v] if x > 1 and x & 1)
    count = 0

    def instance(cell, args, output, name):
        nonlocal count
        count += 1
        if count > global_pool_limit:
            raise ValueError('global physical primitive pool exceeded')
        deadline()
        pins = [f'.{identifier(p)}({x})' for p, x in zip(cell['vars'], args)]
        pins.append(f'.{identifier(cell["out_pin"])}({output})')
        return f'{identifier(cell["name"])} {name}(' + ', '.join(pins) + ');'

    def signed(text):
        return re.sub(r'~n(\d+)', lambda m: 'm' + m[1], text)

    lines, module = [], None
    output_neg, boundaries = set(), set()
    for line in logic.splitlines():
        deadline()
        if line.startswith('module region_'):
            module = line.split('(')[0].split()[1]
            outputs = {int(x) for x in re.findall(r'output n(\d+)', line)}
            boundaries = {int(x) for x in re.findall(r'input n(\d+)', line)}
            output_neg = outputs & negative
            extra = [f'input m{v}' for v in sorted(boundaries & negative)]
            extra += [f'output m{v}' for v in sorted(output_neg)]
            if extra:
                line = line[:-2] + ', ' + ', '.join(extra) + ');'
            lines.append(line)
            continue
        if line.startswith('module mapped('):
            module = 'mapped'
            lines.append(line)
            # One inverter per demanded PI phase globally, not per region.
            for v in sorted(negative & set(range(1, inputs + 1))):
                # Declarations may follow instances in generated Verilog.
                lines.append(instance(inv, [f'n{v}'], f'm{v}', f'pi_inv_{v}'))
            continue
        gate = re.fullmatch(r'assign n(\d+) = (.+) & (.+);', line)
        if gate:
            v = int(gate[1])
            if v in negative and v not in output_neg:
                lines.append(f'wire m{v};')
            lines.append(instance(and2, [signed(gate[2]), signed(gate[3])], f'n{v}', f'and_{v}'))
            if v in negative:
                lines.append(instance(inv, [f'n{v}'], f'm{v}', f'inv_{v}'))
            continue
        if module == 'mapped' and re.fullmatch(r'wire n\d+;', line):
            v = int(re.search(r'n(\d+)', line)[1])
            lines.append(line)
            if v in negative:
                lines.append(f'wire m{v};')
            continue
        if module == 'mapped' and line.startswith('region_'):
            connected = {int(x) for x in re.findall(r'\.n(\d+)\(', line)}
            extra = [f'.m{v}(m{v})' for v in sorted(connected & negative)]
            if extra:
                line = line[:-2] + ', ' + ', '.join(extra) + ');'
        if module == 'mapped' and line.startswith('assign '):
            line = signed(line)
        lines.append(line)
    # Verify the materialized global witness accounting before exporting it.
    if count != len(live) + len(negative):
        raise ValueError('global primitive instance accounting mismatch')
    deadline()
    stats.update(actual_primitive_instances=count, globally_shared_inverters=len(negative),
                 construction_seconds=time.perf_counter() - start,
                 primitive_library_cells=[and2['name'], inv['name']],
                 scope='library-matched primitive region seed; no egraph or regional cut optimization; node counts remain conservative import bounds')
    return '\n'.join(lines) + '\n', stats
