module region_0(input n1, input n2, output n5, input m1);
AND2x2_ASAP7_75t_R and_5(.A(n2), .B(m1), .Y(n5));
endmodule
module region_1(input n3, input n5, output n6);
AND2x2_ASAP7_75t_R and_6(.A(n5), .B(n3), .Y(n6));
endmodule
module region_2(input n1, input n4, output n7, input m1);
AND2x2_ASAP7_75t_R and_7(.A(n4), .B(m1), .Y(n7));
endmodule
module mapped(input p0, input p1, input p2, input p3, output o0, output o1);
INVx1_ASAP7_75t_R pi_inv_1(.A(n1), .Y(m1));
wire n1;
wire m1;
wire n2;
wire n3;
wire n4;
wire n5;
wire n6;
wire n7;
assign n1 = p0;
assign n2 = p1;
assign n3 = p2;
assign n4 = p3;
region_0 r0(.n1(n1), .n2(n2), .n5(n5), .m1(m1));
region_1 r1(.n3(n3), .n5(n5), .n6(n6));
region_2 r2(.n1(n1), .n4(n4), .n7(n7), .m1(m1));
assign o0 = n6;
assign o1 = n7;
endmodule
