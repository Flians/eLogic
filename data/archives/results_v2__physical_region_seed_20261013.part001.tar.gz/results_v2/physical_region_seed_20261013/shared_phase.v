module mapped(input p0,p1,p2,p3,output o0,o1);wire a=~p0&p1;wire b=a&p2;wire c=~p0&p3;assign o0=b;assign o1=c;endmodule
