module region_0(input n1, input n2, input n3, output n7, output n8);
AND2x2_ASAP7_75t_R and_7(.A(n2), .B(n1), .Y(n7));
AND2x2_ASAP7_75t_R and_8(.A(n7), .B(n3), .Y(n8));
endmodule
module region_1(input n4, input n5, input n8, output n9, output n10, input m5, output m9);
AND2x2_ASAP7_75t_R and_9(.A(n8), .B(n4), .Y(n9));
INVx1_ASAP7_75t_R inv_9(.A(n9), .Y(m9));
AND2x2_ASAP7_75t_R and_10(.A(n9), .B(m5), .Y(n10));
endmodule
module region_2(input n6, input n7, input n10, output n11, output n12);
AND2x2_ASAP7_75t_R and_11(.A(n10), .B(n6), .Y(n11));
AND2x2_ASAP7_75t_R and_12(.A(n10), .B(n7), .Y(n12));
endmodule
module mapped(input \a[0] , input p1, input p2, input p3, input p4, input p5, output o0, output o1, output o2);
INVx1_ASAP7_75t_R pi_inv_5(.A(n5), .Y(m5));
wire n1;
wire n2;
wire n3;
wire n4;
wire n5;
wire m5;
wire n6;
wire n7;
wire n8;
wire n9;
wire m9;
wire n10;
wire n11;
wire n12;
assign n1 = \a[0] ;
assign n2 = p1;
assign n3 = p2;
assign n4 = p3;
assign n5 = p4;
assign n6 = p5;
region_0 r0(.n1(n1), .n2(n2), .n3(n3), .n7(n7), .n8(n8));
region_1 r1(.n4(n4), .n5(n5), .n8(n8), .n9(n9), .n10(n10), .m5(m5), .m9(m9));
region_2 r2(.n6(n6), .n7(n7), .n10(n10), .n11(n11), .n12(n12));
assign o0 = n11;
assign o1 = n12;
assign o2 = m9;
endmodule
