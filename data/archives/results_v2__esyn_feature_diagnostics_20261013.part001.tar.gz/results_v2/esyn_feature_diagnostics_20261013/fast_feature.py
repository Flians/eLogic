import re
NODE = re.compile('^\\s*(\\d+\\.\\d+)\\s*\\[label\\s*=\\s*"[^"\\n]*"\\]\\s*;?\\s*$')
EDGE = re.compile('^\\s*(\\d+\\.\\d+)\\s*->\\s*(\\d+\\.\\d+)\\s*\\[lhead\\s*=\\s*cluster_\\d+,\\s*\\]\\s*;?\\s*$')

def fast(text):
    text = re.sub('\\s*subgraph.*{', '', text)
    text = re.sub('\\s*}\\s*', '', text)
    text = re.sub('\\s*style=.*', '', text)
    text = re.sub(':\\w+', '', text)
    text = re.sub('\\]\\s*(?=\\d+\\.\\d+\\s*(?:\\[|->))', ']\n', text)
    (nodes, edges) = (set(), set())
    for line in text.splitlines():
        if not line.strip() or line.strip() in ('digraph egraph {', 'compound=true', 'clusterrank=local'):
            continue
        m = NODE.fullmatch(line)
        if m:
            nodes.add(m[1])
            continue
        m = EDGE.fullmatch(line)
        if m:
            edges.add((m[1], m[2]))
            nodes.update((m[1], m[2]))
            continue
        raise ValueError('unsupported DOT line: ' + line[:120])
    n = len(nodes)
    e = len(edges)
    return {'nodes': n, 'edges': e, 'density': e / (n * (n - 1)) if n > 1 else 0}
