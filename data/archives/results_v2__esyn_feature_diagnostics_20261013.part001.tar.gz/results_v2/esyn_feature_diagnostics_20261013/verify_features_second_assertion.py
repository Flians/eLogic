"""Read-only E-Syn graph-feature diagnostic; no ranking, mapping or timing-budget change."""
import hashlib,json,random,re,time
from pathlib import Path
import networkx as nx
import pydot

NODE = re.compile(r'^\s*(\d+\.\d+)\s*\[label\s*=\s*"[^"\n]*"\]\s*;?\s*$')
EDGE = re.compile(r'^\s*(\d+\.\d+)\s*->\s*(\d+\.\d+)\s*\[lhead\s*=\s*cluster_\d+,\s*\]\s*;?\s*$')

def fast(text):
    # Same normalization as the archived upstream graph_info.py, without writing input files.
    text=re.sub(r'\s*subgraph.*{','',text)
    text=re.sub(r'\s*}\s*','',text)
    text=re.sub(r'\s*style=.*','',text)
    text=re.sub(r':\w+','',text)
    nodes,edges=set(),set()
    for line in text.splitlines():
        if not line.strip() or line.strip() in ('digraph egraph {','compound=true','clusterrank=local'):
            continue
        m=NODE.fullmatch(line)
        if m: nodes.add(m[1]);continue
        m=EDGE.fullmatch(line)
        if m: edges.add((m[1],m[2]));nodes.update((m[1],m[2]));continue
        raise ValueError('unsupported DOT line: '+line[:120])
    n=len(nodes);e=len(edges)
    return {'nodes':n,'edges':e,'density':e/(n*(n-1)) if n>1 else 0}

rng=random.Random(20261013)
fixtures=[]
for i in range(64):
    n=rng.randrange(1,18)
    declarations=[f'{j}.0[label = "&"]' for j in range(n)]
    # DiGraph semantics remove parallel edges and retain loops.
    links=[f'{rng.randrange(n)}.0 -> {rng.randrange(n)}.0 [lhead = cluster_0, ]' for _ in range(rng.randrange(0,40))]
    text='digraph egraph {\ncompound=true\nclusterrank=local\n'+'\n'.join(declarations+links)+'\n}'
    g=nx.DiGraph(nx.nx_pydot.from_pydot(pydot.graph_from_dot_data(text)[0]))
    expected={'nodes':g.number_of_nodes(),'edges':g.number_of_edges(),'density':nx.density(g)}
    assert fast(text)==expected,(i,fast(text),expected)
    fixtures.append(expected)
try: fast('digraph egraph {\n0.0 -> unknown [x=0]\n}')
except ValueError: pass
else: raise AssertionError('unsupported format accepted')
folder=Path('results_v2/epfl_baseline_checkpoint_20261013/3in_esyn_area-delay_adder/adder')
log=(folder/'native.log').read_text()
observed={int(a):int(b) for a,b in re.findall(r'count: (\d+), key: (\d+)',log)}
keys=sorted({int(x) for x in re.findall(r'Key: (\d+), Value:',log)})
assert keys==list(range(62))
# Archived main.rs uses BTreeMap, so enumeration order equals sorted keys.
ids=dict(enumerate(keys));assert all(ids[k]==v for k,v in observed.items())
start=time.perf_counter();rows=[]
for p in sorted((folder/'out_dot').glob('out_graph_dot*.dot')):
    index=int(re.search(r'out_graph_dot(\d+)',p.name)[1]);raw=p.read_bytes()
    rows.append({'file':str(p),'sha256':hashlib.sha256(raw).hexdigest(),'export_index':index,
        'native_candidate_key':ids[index],**fast(raw.decode())})
result={'fixture_count':64,'fixture_exact_networkx_matches':64,'unsupported_format_rejected':True,
    'networkx_version':nx.__version__,'pydot_version':pydot.__version__,'graphs':rows,
    'read_parse_wall_secs':time.perf_counter()-start,'index_identity_count':sum(k==v for k,v in ids.items()),
    'scope':'offline DOT count/density diagnostic only; not new baseline PPA or an end-to-end native success',
    'upstream_index_issues':['CSV index enumerates as_completed completion order, not DOT count'],
    'inputs_unchanged':all(hashlib.sha256(Path(r['file']).read_bytes()).hexdigest()==r['sha256'] for r in rows)}
Path('results_v2/esyn_feature_diagnostics_20261013/validation.json').write_text(json.dumps(result,indent=2)+'\n')
print('fixtures',64,'graphs',len(rows),'secs',result['read_parse_wall_secs'],'identity_indices',result['index_identity_count'])
