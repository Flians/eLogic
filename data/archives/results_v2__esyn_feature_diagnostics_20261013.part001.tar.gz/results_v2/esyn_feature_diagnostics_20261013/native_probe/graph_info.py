import csv,sys,time,json
from pathlib import Path
from fast_feature import fast
start=time.perf_counter()
rows=[]
for i in range(int(sys.argv[1])):
    stats=fast(Path(f"out_dot/out_graph_dot{i}.dot").read_text())
    rows.append([i,stats["density"],stats["edges"]])
with open("graph_info/out_graph_info.csv","w",newline="") as f:
    w=csv.writer(f);w.writerow(["Index","Graph Density","Graph Edge Count"]);w.writerows(rows)
Path("feature_timing.json").write_text(json.dumps({"graphs":len(rows),"seconds":time.perf_counter()-start}))
