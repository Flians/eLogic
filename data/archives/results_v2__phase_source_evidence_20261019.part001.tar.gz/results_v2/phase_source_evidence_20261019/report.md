# Phase screening, source recovery and complete-cover audit

2026-10-19. Main8f6 and defaults are unchanged; no promotion. Original baselines/algorithms/models/native parameters unchanged. This round consists of THREE INDEPENDENT isolated pilots; no source version is mixed into the cut-screen version.

New physical attempts: 58; public original named-port CEC passes: 28; failures: 30. All30 failures are independently confirmed incomplete actual cumulative imports at20000/20000. Priority accounts for ten source-pilot control CECs; those do not establish that large transformed sources have mapped successfully.

## Two-phase cut admission: rejected

The new opt-in screen requires both mandatory-label phase estimates to be nonworse than the pre-insertion per-phase frontier and one strictly better. The frontier may use different cuts for each phase. It is a proxy, not a timing bound or full shared-cover certificate. Original functional proof attempts and cut/node/pool/recovery budgets remain unchanged.

All18 runs passed CEC. Six legal pairs against functional-cuts-off: delay2better/4equal; area1better/2equal/3worse. Against functional-cuts-on: delay2better/3equal/1worse; area1better/1equal/4worse. The rule fixes the K4 adder regression and K4 sin delay, but overfilters sqrt area opportunities and loses most K3 sqrt delay improvement.

|Library|Design|Cuts off A/D|Functional cuts A/D|Two-phase screen A/D|
|---|---|---:|---:|---:|
|K3|sqrt|2153.57/60087.26|2021.89/55862.56|2153.85/60084.45|
|K3|sin|482.56/2051.62|481.59/2051.62|482.14/2051.62|
|K3|adder|90.37/2585.46|90.37/2585.46|90.37/2585.46|
|K4|sqrt|2250.29/47047.28|2216.02/47031.68|2258.91/47031.68|
|K4|sin|580.11/1793.92|567.46/1806.55|580.35/1793.92|
|K4|adder|90.31/2569.79|95.34/2571.81|90.31/2569.79|

These negative target results do not qualify for full20 or repeated improvement claims. New full-suite experiments/repetitions were NOT run or replaced with old winners. Previous V31 full80 and36 targeted-repeat data remain independent, unchanged and not promoted. Full20 records explicitly retain unmeasured designs; all12 new pilot-scope gates are false (two versions ×two inventories ×DA/ADposthoc/Pareto). AD is a posthoc gate, not a new AD optimization study. MtM remains unconnected.

## Complete old shared-cover risk

|Library|Design|Old exact bindings losing every old cut witness|On old critical path|
|---|---|---:|---:|
|K3|sin|16|0|
|K3|adder|0|0|
|K3|sqrt|0|0|
|K3|bar|0|0|
|K4|sin|161|3|
|K4|adder|1|0|
|K4|sqrt|0|0|
|K4|bar|0|0|

These are binding counts, not physical-cell counts or proof of physical-candidate absence. Omitted full pool and care-qualified SDC alternatives remain unaudited; some selected bindings lack reconstructed exact provenance. Offline analysis is not fed back as free candidates or incumbents. Terminal-area protection only preserves its own saved final cover; complete cross-pool legacy-cover protection is NOT implemented. See next_complete_cover_exchange.md for the required full dependency/provenance/pin/area/cycle checks and remaining original-budget constraints.

## Independent source pilots

|Library|Design|Original source plan|Unranked filter|Rank-pruned filter|Terminal on complete old plan|
|---|---|---:|---:|---:|---:|
|K3|div|20537|20537|20537|20537|
|K3|hyp|104047|111430|103973|103955|
|K3|mem_ctrl|27903|27904|27903|27901|
|K4|div|20366|20366|20366|20366|
|K4|hyp|99143|106344|98879|99143|
|K4|mem_ctrl|24860|24854|24848|24859|

All source numbers are representation estimates, not minimum lower bounds, complete imported egraphs or PPA. V33 verifies strict decrease on all original rank edges before pruning; invalid rank falls back to the original256-expansion unknown-reject walk. Rank/index are not conflated. V34 starts after the complete old selection, uses only remaining original16 combined group/pair transactions per root, and accepts only negative whole reference-count changes. Its own before_terminal→after count is nonincreasing in every recorded run. No old plan is recomputed for free. Original singleton scans are unchanged and not counted as group/pair transactions. All30 large cases still fail actual import; no resident reset, state retirement or input exemption.

## Validation and unchanged budget

Meaningful RED→GREEN regressions are preserved for truncated irrelevant cones, multiuser terminal reclamation and the min-over-phases ranking error. V33:23 source-selected tests and105 egraph-selected tests/4ignored; V34:25source and107egraph/4ignored; these selections overlap and are NOT summed. V35:131egraph-selected tests/5ignored. Releases and permanent frozen Rust/Cargo/fixture sources/binaries/manifests/patches/build logs are retained. Initial setup failures and rejected8-page paper builds are preserved.

Same once-resyn2 original20 EPFL inputs, same K3/K4 library inventories; public instance-once area and unloaded dependent-pin delay; independent original named-port CEC. Actual cumulative import20k, cuts16/class, retained physical pool100k, SAT16, cut rounds32, actual-area4rounds/2000 applications per round, post-admission recovery2s including setup/final validation/reserve, native60 and mapping-only300 seconds. Pre-admission finite/frontier5s guards remain outside2s but inside native/mapping guards. Generated temporary memory is not the retained-pool cap. CEC/metrics/preparation are outside mapping clock. No runtime improvement claim from these single pilots.

Original baseline240groups/520slots:372CEC,124reported failures,24unmeasured remain unchanged. Four small original binaries freshly match prior hashes; prior full13403-file source audit is referenced, NOT rerun. Root source changes are rejected by frozen fingerprints. No .git writes.

## Next fixed experiment

Reject the hard phase screen. Instrument retained physical bindings with originating cut/care/phase/pin provenance, preserve the entire validated old selected dependency closure during cut/pool exchanges, and use actual required-time slack plus shared references to rank admission. It must remain one16-cut bank/100k pool and use only remaining original rounds/trials/window; no second bank or second2s. For sources, inspect missing existing-helper exact factorizations within original query/composition limits; export compressed-source CEC separately before admission, while retaining a mapping failure if actual import still exceeds20k. Only then qualify fixed full20/two-library profiles and predeclared repeats before promotion.
