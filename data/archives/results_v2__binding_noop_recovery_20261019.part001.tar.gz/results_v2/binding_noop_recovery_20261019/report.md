# Binding provenance and protected recovery (V42)

The fixed single-output, delay-area profiles share one once-resyn2 AIG and the same library. All global admission, cut, pool, iteration, trial and time limits and original baseline algorithms remain unchanged. New features remain opt-in.

The complete 120-attempt, three-profile matrix has 102 independent named-port CEC passes and 18 cumulative-import rejections (div, hyp, mem_ctrl in each library/profile). Relative to the same-binary legacy control, protected recovery has lower/equal/higher delay in 8/25/1 legal pairs and area in 25/1/8. Relative to the functional-cut profile, delay is 1/33/0 and area 23/1/10. Every failed case remains in full scope; all 18 baseline dominance gates are false.

Three alternating sqrt/sin/adder repetitions add 54 CEC passes, but they do not establish stable delay gains: four-input sqrt in repetition 0 returns 85011.84, compared with functional control 47031.68, while the other repetitions retain 47031.68. Both values and the original trace are preserved. Four-input sin is consistently 12.63 slower than legacy control. Adder has improved delay but an area regression. No default promotion is justified.

Generator evidence carries cut, care, raw/canonical target phase, physical input/pin assignment and instance identity. Transactions protect all dependencies of an actually visited complete seed; this is not the historical final cover of a different full-budget pipeline. Required-time area flow and actual shared-area recovery obey one Dref and save eligible already-scored whole covers. Correct unique-instance accounting does not prove optimal area.

Read-only delay certificates show that the legacy/functional sin and adder delay difference already exists in the raw match pools; retention and recovery alone cannot create absent cuts or matches. A separate source-transfer defect discards an algorithmically necessary full timing frontier before recovery; a short recomputation may expire and retain a weak area seed. V43 investigates transfer of those necessary results, never reporting-only frontiers, without a second search or larger budget.

All eight raw pilot/full/repeat studies have permanent, member-SHA-verified archives listed in archives.json. Source snapshots, initial compilation failures, RED/GREEN regressions, maps, CEC logs and commands remain available. The original baseline campaign remains 240 attempted groups/520 slots, 372 CEC, 124 reported failures and 24 unmeasured failures. MtM is unconnected.
