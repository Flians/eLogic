# Source-budget probes: three inputs still fail, no promotion

The two isolated studies complete28fresh attempts in total, not one combined mapper matrix: V11signed-source factor16(4sqrt named-portCEC/12node failures), V12paired-source factor12(0CEC/12node failures). All failures remain failures. Every successful V11actual global node/cut/pool/SAT/recovery/mapping audit passes. Main source/defaults and binary8f6d45dc... remain unchanged. The original baseline campaign remains240groups/520slots:372CEC/124reportedfailures/24unmeasured; none is optimized or rerun here. Twelve new full20/two-library DA/AD-posthoc/Pareto gates explicitly retain missing cases and all fail. This references the prior13403-file baseline audit bySHA, not a fresh audit.

## V11 exact signed representation (rejected)

Per-source phase metadata absorbs phases into exact parent truth tables; only truly complementary functions share an actual normalized operator, never an incorrect conditional/complement union. Demanded PO inversions still count. Exhaustive256TTs/eightphases/permutations/duplicatearguments plus actual shared-output import tests;111debug+111release relevant tests pass,5ignored. All three big designs still admit only an incomplete20000-node prefix, with zero prefix alias savings. Four-input sqrt2251.58/47047.28 ->2284.18/48381.90; three-input2155.98/60087.26 ->2121.12/61924.15. Delay regresses2.84%/3.06%; the three-input area saving is a tradeoff, not a DA improvement. No full20/repeated qualification or main promotion. Raw reports, logs,commands, hashes, compile failure and REDfixture retained.

## V12 shared-source pair transactions (partial structural reduction only)

Baseline inspiration: emap's exact reference/dereference and phase-specific backward required propagation (`tools/mockturtle/include/mockturtle/algorithms/emap.hpp`, lines1699,1734,1806,3822,3902), read only. eGraphMap changes only: existing exact library-supported source boundaries are chosen by transactional references before graph admission. Bound16pair trials/live source root, original truth query/bank limits unchanged. Same-rank roots and lower-rank children make joint descendant accounting safe. Preserve old single-plan count unless a joint final count strictly decreases. No egraph retirement or regional/global counter reset. Intermediate reference states are planning metadata, not admitted graph nodes.

The minimized shared-reference RED6->6 becomes GREEN6->5; an additional three-leaf bank fixture8->7 and256layered DAG independent full-reachability comparisons pass. Native96debug/release relevant tests pass,4ignored. Initial mistaken test invocation of the disabled feature is archived and corrected explicitly. These structural tests are not physical Boolean-cover CEC or PPA evidence.

| Library | Design | Single source count | Joint source count | Joint accepted | Planned full import upper | Actual result |
|---|---|---:|---:|---:|---:|---|
| K4 | div |20440|20440|0|20528|20000prefix rejected|
| K4 | hyp |107990|107987|3|108114|20000prefix rejected|
| K4 | mem_ctrl |25061|24999|60|25564|20000prefix rejected|
| K3 | div |20613|20613|0|20701|20000prefix rejected|
| K3 | hyp |111494|111494|0|111621|20000prefix rejected|
| K3 | mem_ctrl |28038|28029|9|28594|20000prefix rejected|

Counts are source representation/planned upper estimates, not actual successful bounded imports, physical metrics, minimum lower bounds or impossibility proofs. The62source-function saving does not reduce the actual failed admitted prefix below20000 or solve mem_ctrl. No recovery PPA exists for the three designs. Do not rerun these unchanged failures or promote either prototype.

## Next independent experiment

The positive-first-cost/same-rank pair search is intentionally incomplete. Test zero-cost rank-worsening first moves and then exact virtual-parent accounting for cross-rank joint replacements, preserving the old whole-source incumbent, original16truth queries/cuts and all actual global budgets. First get actual complete import and a feasible physical witness; only then assess baseline-referenced delay and fixed-required-time unique-area recovery. For area recovery, phase-specific required times and live ref/deref must be refreshed after every accepted whole-cover change; stale sharing snapshots must never prune a valid candidate. Keep all original baseline algorithms/models/native parameters unchanged. Main adoption still requires fixed full20/two-library controls, direct named-portCEC, actual budgets, and independent repeats without per-design version selection.

Evidence:validation.json,signed_rows.json,joint_rows.json,baseline_audit_reference.json,final_integrity.json and both baseline_scope directories. Frozen source/patches/native binaries and negative tests are in signed_source_implementation_20261016 and joint_source_transaction_20261016. Industrial multioutput/ODC/independent regional saturation remain unfinished; MtM unconnected. No guaranteed delay superiority, global optimality or project-completion claim.
