"""Read-only original-baseline audit and isolated V4 compound profile comparison; no promotion."""
import copy
import csv
import hashlib
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path('/home/flynn/workplace/MIGBalance')
OUT = Path(__file__).resolve().parent
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
load = lambda p: json.loads(p.read_text())
write = lambda p, x: p.write_text(json.dumps(x, indent=2) + '\n')
canonical = ROOT/'results_v2/epfl_original_baselines_resumed_checkpoint_20261013/campaign.json'
baseline = load(canonical)
fp = baseline['fingerprint']
drift, excluded, checked = [], [], 0
for p, h in fp['files'].items():
    if '/emapper/src/' in p or p.endswith('/target/release/bench_rs_egraph_map') or p.endswith('/src/bin/bench_rs_egraph_map.rs'):
        excluded.append(p)
        continue
    checked += 1
    if not Path(p).is_file() or sha(Path(p)) != h:
        drift.append(p)
for repo, data in fp['native'].items():
    if subprocess.check_output(['git', '-C', repo, 'rev-parse', 'HEAD'], text=True).strip() != data['commit']:
        drift.append(repo + ':commit')
    for rel, h in data['tracked_sha256'].items():
        p = Path(repo)/rel
        checked += 1
        if not p.is_file() or sha(p) != h:
            drift.append(str(p))
write(OUT/'baseline_integrity.json', dict(checked_files=checked, drift=drift,
      explicitly_unexecuted_candidate_dependencies_excluded=excluded,
      baseline_algorithms_changed=False, canonical_campaign_sha256=sha(canonical)))
assert not drift, drift

flat = load(ROOT/'results_v2/epfl_original_baselines_complete_v2_20261013/all_baselines.json')
subjects = {r['bench']: r for r in load(ROOT/'results_v2/epfl_resyn2_subjects_20261012/report.json')['results']}
original_reports, all_baselines = {}, {3: [], 4: []}
jobs = {j['name']: j for j in baseline['jobs']}
time_bounds = []
for slot in flat:
    report = slot.get('report')
    if report:
        p = Path(report)
        if report not in original_reports:
            original_reports[report] = load(p)
        parent = original_reports[report]
        matches = [r for r in parent['results'] if r['bench'] == slot['bench'] and r['method'] == slot['method']]
        assert len(matches) == 1
        row = copy.deepcopy(matches[0])
        row['observation_report'] = report
        row['observation_report_sha256'] = sha(p)
        assert row['status'] == slot['status']
        if row['status'] == 'ok':
            assert row['measured']['cec'] == 1
            assert row['measured']['area'] == slot['area'] and row['measured']['delay'] == slot['delay']
    else:
        row = dict(bench=slot['bench'], method=slot['method'], status=slot['status'],
                   error=slot.get('error'), unmeasured=True,
                   input_sha256=subjects[slot['bench']]['input_sha256'])
    row['source_objective'] = slot['objective']
    row['source_job'] = slot['job']
    assert row['input_sha256'] == subjects[slot['bench']]['input_sha256']
    if row['method'] in ['eqmap_lut_amap', 'lut_stage_amap'] and row['status'] == 'ok':
        job = jobs[slot['job']]
        audit_path = Path(job['audit'])
        assert sha(audit_path) == job['audit_sha256']
        audit = load(audit_path)
        enclosing = [cmd['wall_secs'] for s in audit['states'].values() for cmd in s['commands']
                     if Path(cmd['argv'][0]).name == 'yosys' and 'abc -lut' in ' '.join(cmd['argv'])]
        direct = audit['states'].get(row['bench']+'/'+row['method'], {}).get('mapping_wall_secs', 0.)
        upper = direct + sum(enclosing)
        assert upper <= 300
        row.update(mapping_budget_upper_bound_secs=upper, mapping_time_exact=False)
        time_bounds.append(dict(job=slot['job'], method=row['method'], upper_secs=upper,
                                audit=str(audit_path), audit_sha256=sha(audit_path)))
    all_baselines[slot['k']].append(row)
assert len(flat) == 520
gate_dir = OUT/'baseline_scope'
gate_dir.mkdir(exist_ok=False)
main_rows = load(ROOT/'results_v2/joint_batch_full_report_20261016/all_rows.json')
primary = ['abc_map_area_resyn2', 'abc_map_delay_resyn2', 'mockturtle_emap_area_resyn2',
           'mockturtle_emap_delay_resyn2', 'eqmap_lut_amap', 'esyn_frozen_model_amap_bounded_dag', 'emorphic_final_sa']
gates = []
for k in [3, 4]:
    candidates = [r for r in main_rows if r['k'] == k and r['profile'] == 'protected_area']
    assert len(candidates) == 20
    assert all(s['library_sha256'] == candidates[0]['library_sha256'] for s in flat
               if s['k'] == k and s.get('library_sha256'))
    common = dict(library_sha256=candidates[0]['library_sha256'],
                  metric_model='all physical instances; max(rise,fall) block pin delay; no load or slew')
    bp, cp = gate_dir/f'baselines_{k}in.json', gate_dir/f'candidate_{k}in.json'
    write(bp, dict(**common, results=all_baselines[k]))
    cr = []
    for r in candidates:
        row = copy.deepcopy(r['row'])
        row['method'] = 'egraph_joint_witness_batch_proto'
        row['observation_report'] = r['report']
        cr.append(row)
    write(cp, dict(**common, results=cr, objective='delay-area', area_delay_check_is_posthoc=True))
    for objective in ['delay-area', 'area-delay', 'pareto']:
        gp = gate_dir/f'{k}in_{objective}.json'
        argv = [sys.executable, str(ROOT/'scripts/experiments/check_mapping_dominance.py'),
                '--candidate', str(cp), '--baselines', str(bp), '--required-baselines', *primary,
                '--candidate-methods', 'egraph_joint_witness_batch_proto', '--objective', objective, '--output', str(gp)]
        run = subprocess.run(argv, capture_output=True, text=True)
        gp.with_suffix('.log').write_text(run.stdout + run.stderr)
        gates.append(dict(argv=argv, exit_code=run.returncode, all_passed=load(gp)['all_passed']))
write(gate_dir/'validation.json', dict(gates=gates, baseline_status_slots=520,
      candidate_scope='One fixed isolated joint-witness/batch-area delay-area profile; not production main, 20 designs x two libraries; AD check is posthoc.',
      eqmap_mapping_upper_bounds=time_bounds,
      baseline_algorithms_changed=False, unconnected=['MtM']))

pairs = load(ROOT/'results_v2/joint_batch_full_report_20261016/paired.json')
with (OUT/'main_paired.csv').open('w') as f:
    fields = ['k', 'bench', 'profile', 'status', 'area', 'delay', 'cec', 'report', 'report_sha256']
    w = csv.DictWriter(f, fieldnames=fields)
    w.writeheader()
    for pair in pairs:
        for key in ['control', 'candidate']:
            item = pair[key]
            row = item['row']
            measured = row.get('measured', {})
            w.writerow(dict(k=item['k'], bench=item['bench'], profile=item['profile'], status=row['status'],
                area=measured.get('area'), delay=measured.get('delay'), cec=measured.get('cec'),
                report=item['report'], report_sha256=item['report_sha256']))
print('Baseline audit:', checked, 'files; gates:', [g['all_passed'] for g in gates])
