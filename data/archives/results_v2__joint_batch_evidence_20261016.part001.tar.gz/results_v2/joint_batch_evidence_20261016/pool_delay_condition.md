# Delay validation condition for one immutable physical pool

Let each free primary-input/constant signal have label zero. For every admitted output binding (instance m, pin p, target s), check

    label[s] <= max_j(label[input_m[j]] + dependent_pin_delay_m[p,j])

where the maximum uses only functionally dependent pins, exactly as in the common unloaded delay evaluator. Empty maxima are zero. The implementation checks every producer-target binding, not only selected or critical producers.

For any finite acyclic cover using this pool, induction in physical topological order gives label[s] <= actual_arrival[s]: it holds at free signals and follows by the checked inequality and monotonicity of max at every bound signal. Thus max(label[root]) is a lower bound on that cover's unloaded block delay. Infinite labels cannot appear in a finite cover rooted in free signals if all these inequalities hold.

A structurally validated witness attaining that bound establishes a minimum within this fixed structural candidate problem. For claims about a functionally correct mapped circuit, independent named-port CEC and common physical metrics remain required. When the final CEC-passed cover attains the checked bound, no other valid acyclic cover drawn from this same pool can have lower delay in this model.

This is neither an area nor a lexicographic optimality certificate. It says nothing about missing cuts, matches, discarded instances, source representations, rewrites, loaded timing, slew, wiring, or global technology-mapping optimality. A conservative readiness frontier alone is not a certificate: the negative nondependent-pin test deliberately produces a feasible but slower frontier and fails these inequalities. Exhaustive small-DAG enumeration checks the positive condition independently of the frontier implementation.

Pre-cap and post-cap pools are checked separately. A measured gap between their attained bounds diagnoses loss during physical candidate retention; equality does not prove that e-graph/cut/library matching is complete. Raw area-witness local producer estimates in older diagnostics are not these bounds and must not be relabeled as such.


## Numerical qualification

The native checker uses a local inequality tolerance of1e-6, not exact symbolic arithmetic. If every inequality holds up to epsilon, induction on any finite selected path of at most N signal nodes yields label[root] <= actual_delay[root]+N*epsilon. A conservative lower bound is therefore max(root labels)-N*epsilon, with N at most twice the e-class count (at most40000under the20k-node limit). An attaining cover brackets the minimum to this accumulated tolerance, rather than proving an exact real-valued optimum. The conservative0.04maximum error is negligible for the observed sqrt retention/residual gaps of thousands, but it must not be used to certify tiny differences such as0.02. Successful native/common metrics agree independently. Raw sidecar records and their code hashes remain immutable; the derived auditor annotates this numerical scope.
