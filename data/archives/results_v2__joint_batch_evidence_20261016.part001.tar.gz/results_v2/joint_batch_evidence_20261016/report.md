# Joint unselected-cone/phase recovery: fixed V4 study

Production main remains unchanged. The current isolated variant is not qualified for integration: full-suite delay gains coexist with area regressions and three unresolved input-budget failures. Original baseline algorithms, parameters, binaries and models are unchanged.

## Actual implementation and negative results

V1 attempts an atomic fallback that restores unselected dependencies from a cached all-signal physical witness while preserving already selected bindings and forced phase targets. Small cycle/truth/area fixtures pass, but the real sqrt/priority pilot shows no valid new repairs and no delay gains; priority area regresses. This is a negative result, not successful EPFL cone recovery. Its restrictive selected-binding policy is a remaining hypothesis, not a diagnosed universal cause.

V2 instead reserves complete area-ranked and fast physical input/phase witnesses before the existing retained-pool truncation. A five-instance red fixture exposes old delay10 versus attainable2 without increasing pool size. V3 adds validated deferred-reference activation and online actual-area application; a real expensive-sharing tie fixture still locks area9 versus2. V4 uses bounded scan batches and reserves late required-time/actual-area work in the same extraction window. No earlier pilot's best case is substituted into V4. Tests, failed initial builds, all source variants and pilot regressions remain separately archived.

The retained legacy incumbent belongs to the current pool, not necessarily the old pipeline's final cover. Priority's retained physical pool equals canonical main's, so changed pool membership does not explain its area regression. A complete old shared cover needs protection across recovery-trajectory changes; this remains unfinished. The DA comparator also accepts larger area for a strictly lower delay, which differs from the user's additional area-protection requirement.

## Full EPFL fixed profile

All20 circuits, both original inventories and both profiles are freshly attempted:80native runs,68direct original named-port CEC,12node-admission failures. Each profile maps34/40cases; div/hyp/mem_ctrl fail in both libraries. Among34common legal pairs D14better/20equal/0worse and A6better/16equal/12worse. The canonical-main comparison separately retains thirteen area regressions; a worse contemporary priority control cannot erase canonical52.15.

Full R0 sqrt3 changes area/delay1814.66/63951.92 to1867.26/63200.36; sqrt4 changes2188.56/57161.09 to1980.96/51470.40. These are fixed full observations, not pilot or best-repeat values. Three-input priority68.54->68.64 and four-input max221.30->222.85 retain equal delay and are direct regressions; four-input priority52.21 still exceeds canonical52.15. The changed pool also benefits log2/square/multiplier and other circuits, often with area costs; every row is retained.

## Diagnostic scope and budgets

Before/after pool inequalities cover every admitted producer under unloaded dependent-pin delays. Local tolerance1e-6 gives a conservative accumulated error no more than2*eclasses*1e-6 (at most0.04); this is not an exact symbolic or global library/cut optimum, nor an area/lex certificate. The sqrt4 pre-cap/new-pool bound near51470.40 versus old retained57161.09 exposes a large truncation loss. The residual versus same-library emap47047.28 exceeds this numerical margin: extraction over that supplied pool alone cannot close it. This does not prove which AO31 cut or match is absent.

Global actual nodes20000/cuts16/retained pool100000/SAT16/extraction2s and native60s/mapping300s are unchanged. Mandatory extraction witnesses/setup/finalvalidation remain inside2s. Pre-cap retention ranking is recorded candidate-generation work inside native/mapping clocks, not free computation or a second recovery window; total executed work is not identical. Generated transient instances are distinct from retained capacity; no RAM-cap claim. Admission rejects before a new20001st node, including PIs and demanded PO phases. Failed prefixes are not mapped coverage or an impossibility lower bound. No regional counter reset or residence/cumulative substitution.

## Baseline integrity

Original240groups/520slots remain372CEC/124reported failures/24unmeasured failures. This turn rechecks13403original dependencies with zero drift. Both libraries' full20 DA, AD-posthoc and Pareto dominance gates all remain false; MtM unconnected. Original E-Syn feature/index optimization probes remain historical and excluded. EqMap mapping-time evidence remains a conservative enclosing-Yosys upper bound, not precise conversion-free runtime.

## Next implementation

Keep the production version and primary main tables fixed. A future atomic trial should allow necessary already-selected dependency replacement while preserving the entire old cover as backup; add a real forced-root-cycle fixture before testing. Shared-user paired replacements must use the existing trial allowance, not extra search time. For residual sqrt delay, investigate actual critical cut/pin-aware retention within the same16-cut/100k limits. For div/hyp/mem_ctrl, exact pre-admission sharing/canonicalization remains research, not new mapped coverage. Re-run one explicitly frozen full configuration and alternating repetitions after any source change; retain every area/deadline/CEC regression and never select circuit-wise winners.

Additional read-only bracket audit: all34 successful fixed candidate covers attain their own raw pool root labels within metric rounding. The conservative accumulated-error interval remains explicit (`frozen_pool_delay_brackets.json`); for sqrt it is0.029206delay units, far below the residual baseline gap. This strengthens the fixed-pool extraction limitation, not a global/cut/library optimum claim.

## Completed repeated qualification

All64 declared fresh alternating-order target attempts finish with direct original named-port CEC; actual budgets and source/artifact hashes pass. The96-observation target view includes32full observations, not96new runs:48legal pairs D12better/36equal/0worse,A9better/24equal/15worse. Non-overlapping full+fresh-repeat accounting is144native attempts,132CEC/12node failures,66legal pairs D22better/44equal/0worse,A12better/32equal/22worse. There are16lower-delay/larger-area tradeoffs and6equal-delay/larger-area regressions across these unique pairs.

Sqrt4's three candidate observations all yield1980.96/51470.40; both delay and area improve versus each paired control. Sqrt3 delay63200.36 repeats all three times, but area1867.26/1867.38/1867.59 stays above old1814.66. Priority3's68.64 versus68.54 equal-delay regression and max4's222.85 versus221.30 repeat all three times. Priority4 candidate areas52.21/52.17/52.21 remain above canonical52.15. Bar4's290.78 area versus291.50 repeats without a delay change; bar3 ties. No best observation is chosen. These are small target repetitions, not full20 repeated statistical stability.

The explicit qualification is FALSE. Production main/source/defaults/binary and primary tables are unchanged. Original baseline six full20gates remain false, and no new design becomes legal. Final integrity checks cover both frozen source manifests and every report/audit/pool/trace/frontier reference. This round leaves no native campaign running.

## Publication and final integrity

Final audit verifies1064 source/artifact references without drift. All four source variants' tests/fixtures/small library tools, Cargo files, source and binaries are archived, with per-file hashes and patches relative to unchanged production main. Original manifests are retained before adding fixture archive hashes. Main and evaluator binaries retain their recorded hashes. Full/repeat/baseline locks are idle; no campaign is left active.

The updated draft records full/repeated gains and regressions, numerical pool-bound scope, unchanged original baselines, and unresolved large inputs. All four primary tables remain byte-identical canonical-main observations. The initial8page layout is retained; final standard-font/margin6+1PDF is compiled twice, all7pages visually inspected, and both delivery copies hash-match. QA/provenance are in joint_batch_paper_20261016/paper_qa.json. The compound V4method is not integrated.
