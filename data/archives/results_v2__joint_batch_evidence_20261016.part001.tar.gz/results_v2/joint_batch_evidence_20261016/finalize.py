"""Read-only qualification of frozen complete V4 studies; never promotes code."""
import csv,hashlib,json
from pathlib import Path
R=Path('/home/flynn/workplace/MIGBalance');O=Path(__file__).resolve().parent
load=lambda p:json.loads(Path(p).read_text());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
full=R/'results_v2/joint_batch_full_report_20261016';rep=R/'results_v2/joint_batch_repeats_report_20261016'
f=load(full/'validation.json');q=load(rep/'validation.json');fr=load(full/'all_rows.json');rr=load(rep/'all_rows.json');fp=load(full/'paired.json');rp=load(rep/'paired.json')
assert f['case_slots']==80 and q['case_slots']==96
fresh=[x for x in rr if x['observation']=='repeat'];unique=fr+fresh;pair=fp+[x for x in rp if x['observation']=='repeat']
assert len(unique)==144 and len({x['report'] for x in unique})==144
counts={m:[0,0,0] for m in ['delay','area']};tradeoffs=[];sameDarea=[]
for x in pair:
 a,b=x['control']['row'],x['candidate']['row']
 if a['status']!=b['status'] or a['status']!='ok':continue
 tags={}
 for m in counts:
  old,new=a['measured'][m],b['measured'][m];t=1e-6*max(1,abs(old),abs(new));i=0 if new<old-t else 2 if new>old+t else 1;counts[m][i]+=1;tags[m]=i
 if tags['delay']==0 and tags['area']==2:tradeoffs.append([x['k'],x['bench'],x['observation'],x['repetition']])
 if tags['delay']==1 and tags['area']==2:sameDarea.append([x['k'],x['bench'],x['observation'],x['repetition']])
for report in [full,rep]:
 v=load(report/'validation.json');assert not v['budget_errors'] and not v['artifact_hash_errors']
 g=load(report/'joint_budget_gate.json');assert g['qualifies_for_promotion'] is False
main=load(R/'results_v2/scored_main_full_report_20261015/all_rows.json');main={(x['k'],x['bench']):x for x in main if x['profile']=='protected_area'}
with (O/'repeated_paired.csv').open('w') as stream:
 w=csv.writer(stream);w.writerow(['k','bench','observation','repetition','control_status','candidate_status','control_area','candidate_area','control_delay','candidate_delay','canonical_main_area','canonical_main_delay'])
 for x in rp:
  a,b=x['control']['row'],x['candidate']['row'];m=main[x['k'],x['bench']]['row'];w.writerow([x['k'],x['bench'],x['observation'],x['repetition'],a['status'],b['status'],a.get('measured',{}).get('area'),b.get('measured',{}).get('area'),a.get('measured',{}).get('delay'),b.get('measured',{}).get('delay'),m.get('measured',{}).get('area'),m.get('measured',{}).get('delay')])
status=dict(unique_fresh_attempts=144,direct_cec=sum(x['row']['status']=='ok' for x in unique),failures=sum(x['row']['status']!='ok' for x in unique),unique_common_legal_pairs=sum(counts['delay']),better_equal_worse=counts,target_view_observations=96,target_view_includes_full_observations=32,lower_delay_higher_area=tradeoffs,equal_delay_higher_area=sameDarea)
qualification=dict(production_promoted=False,qualifies=False,baseline_algorithms_changed=False,reason='Area regressions against same-binary controls and canonical main remain; div/hyp/mem_ctrl still reject nodes. Fixed V4 delay gains do not meet the requested shared-area/nonregression qualification.',full=f,target_repeated_view=q,nonoverlapping_accounting=status,original_baseline_audit=load(O/'baseline_integrity.json'),baseline_gates=load(O/'baseline_scope/validation.json'),scope='DA fixed compound variant; AD only posthoc on DA covers. All failed attempts retained; no best-run or per-design configuration choice. MtM unconnected; no industrial multi-output/ODC completion claim.')
(O/'qualification.json').write_text(json.dumps(qualification,indent=2)+'\n')
# Fingerprint only actual frozen dependencies; do not infer stability from filenames.
checks=[]
for cp in [R/'results_v2/joint_batch_full_20261016/campaign.json',R/'results_v2/joint_batch_repeats_20261016/campaign.json']:
 c=load(cp);assert len(c['jobs'])==c['expected_jobs']
 for p,h in c['fingerprint'].items():assert sha(p)==h;checks.append(dict(source=p,sha256=h))
 for j in c['jobs']:
  for key in ['report','audit','pool','candidates','trace','pool_frontier','diagnostic_profile']:
   if key in j:assert sha(j[key])==j[key+'_sha256'];checks.append(dict(source=j[key],sha256=j[key+'_sha256']))
(O/'final_integrity.json').write_text(json.dumps(dict(checked_references=len(checks),errors=[],references=checks,main_binary_sha256=sha(R/'target/release/bench_rs_egraph_map'),evaluator_sha256=sha(R/'target/release/bench_rs_netlist_eval')),indent=2)+'\n')
print(json.dumps(status,indent=2))
