// Benchmark "/home/flynn/workplace/MIGBalance/tools/mockturtle/experiments/benchmarks/c432" written by ABC on Wed Oct  7 15:25:30 2026

module \/home/flynn/workplace/MIGBalance/tools/mockturtle/experiments/benchmarks/c432  ( 
    G32, G34, G28, G30, G24, G26, G20, G22, G16, G18, G12, G14, G8, G10,
    G4, G6, G1, G2, G35, G31, G27, G23, G19, G15, G11, G7, G3, G36, G33,
    G29, G25, G21, G17, G13, G9, G5,
    G426, G427, G428, G429, G430, G431, G432  );
  input  G32, G34, G28, G30, G24, G26, G20, G22, G16, G18, G12, G14, G8,
    G10, G4, G6, G1, G2, G35, G31, G27, G23, G19, G15, G11, G7, G3, G36,
    G33, G29, G25, G21, G17, G13, G9, G5;
  output G426, G427, G428, G429, G430, G431, G432;
  wire new_n44_, new_n45_, new_n46_, new_n47_, new_n48_, new_n49_, new_n50_,
    new_n51_, new_n52_, new_n53_, new_n54_, new_n55_, new_n56_, new_n57_,
    new_n58_, new_n59_, new_n60_, new_n61_, new_n62_, new_n63_, new_n64_,
    new_n65_, new_n66_, new_n67_, new_n69_, new_n70_, new_n71_, new_n72_,
    new_n73_, new_n74_, new_n75_, new_n76_, new_n77_, new_n78_, new_n79_,
    new_n80_, new_n81_, new_n82_, new_n83_, new_n84_, new_n85_, new_n86_,
    new_n87_, new_n88_, new_n89_, new_n90_, new_n91_, new_n92_, new_n93_,
    new_n94_, new_n95_, new_n96_, new_n97_, new_n98_, new_n99_, new_n100_,
    new_n102_, new_n103_, new_n104_, new_n105_, new_n106_, new_n107_,
    new_n108_, new_n109_, new_n110_, new_n111_, new_n112_, new_n113_,
    new_n114_, new_n115_, new_n116_, new_n117_, new_n118_, new_n119_,
    new_n120_, new_n121_, new_n122_, new_n123_, new_n124_, new_n125_,
    new_n126_, new_n127_, new_n128_, new_n129_, new_n130_, new_n131_,
    new_n132_, new_n133_, new_n134_, new_n135_, new_n137_, new_n138_,
    new_n139_, new_n140_, new_n141_, new_n142_, new_n143_, new_n144_,
    new_n145_, new_n146_, new_n147_, new_n148_, new_n149_, new_n150_,
    new_n151_, new_n152_, new_n153_, new_n154_, new_n155_, new_n156_,
    new_n157_, new_n158_, new_n159_, new_n160_, new_n161_, new_n162_,
    new_n163_, new_n164_, new_n165_, new_n166_, new_n167_, new_n168_,
    new_n169_, new_n170_, new_n171_, new_n172_, new_n173_, new_n174_,
    new_n175_, new_n176_, new_n177_, new_n178_, new_n179_, new_n181_,
    new_n182_, new_n184_, new_n185_, new_n186_, new_n187_, new_n189_,
    new_n190_;
  INVx1_ASAP7_75t_R   g000(.A(G32), .Y(new_n44_));
  NAND2x1_ASAP7_75t_R g001(.A(G34), .B(new_n44_), .Y(new_n45_));
  INVx1_ASAP7_75t_R   g002(.A(G28), .Y(new_n46_));
  AND2x2_ASAP7_75t_R  g003(.A(new_n46_), .B(G30), .Y(new_n47_));
  INVx1_ASAP7_75t_R   g004(.A(new_n47_), .Y(new_n48_));
  INVx1_ASAP7_75t_R   g005(.A(G24), .Y(new_n49_));
  NAND2x1_ASAP7_75t_R g006(.A(G26), .B(new_n49_), .Y(new_n50_));
  INVx1_ASAP7_75t_R   g007(.A(G20), .Y(new_n51_));
  NAND2x1_ASAP7_75t_R g008(.A(G22), .B(new_n51_), .Y(new_n52_));
  AND2x2_ASAP7_75t_R  g009(.A(new_n50_), .B(new_n52_), .Y(new_n53_));
  AND3x1_ASAP7_75t_R  g010(.A(new_n53_), .B(new_n45_), .C(new_n48_), .Y(new_n54_));
  INVx1_ASAP7_75t_R   g011(.A(G16), .Y(new_n55_));
  NAND2x1_ASAP7_75t_R g012(.A(G18), .B(new_n55_), .Y(new_n56_));
  INVx1_ASAP7_75t_R   g013(.A(G12), .Y(new_n57_));
  NAND2x1_ASAP7_75t_R g014(.A(G14), .B(new_n57_), .Y(new_n58_));
  INVx1_ASAP7_75t_R   g015(.A(G8), .Y(new_n59_));
  NAND2x1_ASAP7_75t_R g016(.A(G10), .B(new_n59_), .Y(new_n60_));
  INVx1_ASAP7_75t_R   g017(.A(G4), .Y(new_n61_));
  NAND2x1_ASAP7_75t_R g018(.A(G6), .B(new_n61_), .Y(new_n62_));
  INVx1_ASAP7_75t_R   g019(.A(G1), .Y(new_n63_));
  NAND2x1_ASAP7_75t_R g020(.A(G2), .B(new_n63_), .Y(new_n64_));
  AND3x1_ASAP7_75t_R  g021(.A(new_n60_), .B(new_n62_), .C(new_n64_), .Y(new_n65_));
  AND3x1_ASAP7_75t_R  g022(.A(new_n65_), .B(new_n56_), .C(new_n58_), .Y(new_n66_));
  AND2x2_ASAP7_75t_R  g023(.A(new_n66_), .B(new_n54_), .Y(new_n67_));
  INVx1_ASAP7_75t_R   g024(.A(new_n67_), .Y(G426));
  INVx1_ASAP7_75t_R   g025(.A(G34), .Y(new_n69_));
  XOR2x2_ASAP7_75t_R  g026(.A(new_n67_), .B(new_n45_), .Y(new_n70_));
  OR3x1_ASAP7_75t_R   g027(.A(new_n70_), .B(new_n69_), .C(G35), .Y(new_n71_));
  INVx1_ASAP7_75t_R   g028(.A(G30), .Y(new_n72_));
  XOR2x2_ASAP7_75t_R  g029(.A(new_n67_), .B(new_n48_), .Y(new_n73_));
  OR3x1_ASAP7_75t_R   g030(.A(new_n73_), .B(new_n72_), .C(G31), .Y(new_n74_));
  INVx1_ASAP7_75t_R   g031(.A(G26), .Y(new_n75_));
  XOR2x2_ASAP7_75t_R  g032(.A(new_n67_), .B(new_n50_), .Y(new_n76_));
  OR3x1_ASAP7_75t_R   g033(.A(new_n76_), .B(new_n75_), .C(G27), .Y(new_n77_));
  INVx1_ASAP7_75t_R   g034(.A(G22), .Y(new_n78_));
  XOR2x2_ASAP7_75t_R  g035(.A(new_n67_), .B(new_n52_), .Y(new_n79_));
  OR3x1_ASAP7_75t_R   g036(.A(new_n79_), .B(new_n78_), .C(G23), .Y(new_n80_));
  AND2x2_ASAP7_75t_R  g037(.A(new_n77_), .B(new_n80_), .Y(new_n81_));
  AND3x1_ASAP7_75t_R  g038(.A(new_n81_), .B(new_n71_), .C(new_n74_), .Y(new_n82_));
  INVx1_ASAP7_75t_R   g039(.A(G18), .Y(new_n83_));
  XOR2x2_ASAP7_75t_R  g040(.A(new_n67_), .B(new_n56_), .Y(new_n84_));
  OR3x1_ASAP7_75t_R   g041(.A(new_n84_), .B(new_n83_), .C(G19), .Y(new_n85_));
  INVx1_ASAP7_75t_R   g042(.A(G14), .Y(new_n86_));
  XOR2x2_ASAP7_75t_R  g043(.A(new_n67_), .B(new_n58_), .Y(new_n87_));
  OR3x1_ASAP7_75t_R   g044(.A(new_n87_), .B(new_n86_), .C(G15), .Y(new_n88_));
  INVx1_ASAP7_75t_R   g045(.A(G10), .Y(new_n89_));
  XOR2x2_ASAP7_75t_R  g046(.A(new_n67_), .B(new_n60_), .Y(new_n90_));
  OR3x1_ASAP7_75t_R   g047(.A(new_n90_), .B(new_n89_), .C(G11), .Y(new_n91_));
  INVx1_ASAP7_75t_R   g048(.A(G6), .Y(new_n92_));
  XOR2x2_ASAP7_75t_R  g049(.A(new_n67_), .B(new_n62_), .Y(new_n93_));
  OR3x1_ASAP7_75t_R   g050(.A(new_n93_), .B(new_n92_), .C(G7), .Y(new_n94_));
  INVx1_ASAP7_75t_R   g051(.A(G2), .Y(new_n95_));
  XOR2x2_ASAP7_75t_R  g052(.A(new_n67_), .B(new_n64_), .Y(new_n96_));
  OR3x1_ASAP7_75t_R   g053(.A(new_n96_), .B(new_n95_), .C(G3), .Y(new_n97_));
  AND3x1_ASAP7_75t_R  g054(.A(new_n91_), .B(new_n94_), .C(new_n97_), .Y(new_n98_));
  AND3x1_ASAP7_75t_R  g055(.A(new_n98_), .B(new_n85_), .C(new_n88_), .Y(new_n99_));
  AND2x2_ASAP7_75t_R  g056(.A(new_n99_), .B(new_n82_), .Y(new_n100_));
  INVx1_ASAP7_75t_R   g057(.A(new_n100_), .Y(G427));
  XOR2x2_ASAP7_75t_R  g058(.A(new_n100_), .B(new_n71_), .Y(new_n102_));
  OR3x1_ASAP7_75t_R   g059(.A(new_n70_), .B(new_n69_), .C(G36), .Y(new_n103_));
  NAND2x1_ASAP7_75t_R g060(.A(new_n74_), .B(new_n100_), .Y(new_n104_));
  AO21x1_ASAP7_75t_R  g061(.A1(new_n99_), .A2(new_n82_), .B(new_n74_), .Y(new_n105_));
  OR3x1_ASAP7_75t_R   g062(.A(new_n73_), .B(new_n72_), .C(G33), .Y(new_n106_));
  AO21x1_ASAP7_75t_R  g063(.A1(new_n104_), .A2(new_n105_), .B(new_n106_), .Y(new_n107_));
  OAI21x1_ASAP7_75t_R g064(.A1(new_n102_), .A2(new_n103_), .B(new_n107_), .Y(new_n108_));
  NAND2x1_ASAP7_75t_R g065(.A(new_n77_), .B(new_n100_), .Y(new_n109_));
  AO21x1_ASAP7_75t_R  g066(.A1(new_n99_), .A2(new_n82_), .B(new_n77_), .Y(new_n110_));
  OR3x1_ASAP7_75t_R   g067(.A(new_n76_), .B(new_n75_), .C(G29), .Y(new_n111_));
  AO21x1_ASAP7_75t_R  g068(.A1(new_n109_), .A2(new_n110_), .B(new_n111_), .Y(new_n112_));
  XOR2x2_ASAP7_75t_R  g069(.A(new_n100_), .B(new_n80_), .Y(new_n113_));
  OR3x1_ASAP7_75t_R   g070(.A(new_n79_), .B(new_n78_), .C(G25), .Y(new_n114_));
  OAI21x1_ASAP7_75t_R g071(.A1(new_n113_), .A2(new_n114_), .B(new_n112_), .Y(new_n115_));
  NAND2x1_ASAP7_75t_R g072(.A(new_n85_), .B(new_n100_), .Y(new_n116_));
  AO21x1_ASAP7_75t_R  g073(.A1(new_n99_), .A2(new_n82_), .B(new_n85_), .Y(new_n117_));
  OR3x1_ASAP7_75t_R   g074(.A(new_n84_), .B(new_n83_), .C(G21), .Y(new_n118_));
  AO21x1_ASAP7_75t_R  g075(.A1(new_n116_), .A2(new_n117_), .B(new_n118_), .Y(new_n119_));
  XOR2x2_ASAP7_75t_R  g076(.A(new_n100_), .B(new_n88_), .Y(new_n120_));
  OR3x1_ASAP7_75t_R   g077(.A(new_n87_), .B(new_n86_), .C(G17), .Y(new_n121_));
  OA21x2_ASAP7_75t_R  g078(.A1(new_n120_), .A2(new_n121_), .B(new_n119_), .Y(new_n122_));
  XOR2x2_ASAP7_75t_R  g079(.A(new_n100_), .B(new_n91_), .Y(new_n123_));
  OR3x1_ASAP7_75t_R   g080(.A(new_n90_), .B(new_n89_), .C(G13), .Y(new_n124_));
  NAND2x1_ASAP7_75t_R g081(.A(new_n94_), .B(new_n100_), .Y(new_n125_));
  AO21x1_ASAP7_75t_R  g082(.A1(new_n99_), .A2(new_n82_), .B(new_n94_), .Y(new_n126_));
  OR3x1_ASAP7_75t_R   g083(.A(new_n93_), .B(new_n92_), .C(G9), .Y(new_n127_));
  AO21x1_ASAP7_75t_R  g084(.A1(new_n125_), .A2(new_n126_), .B(new_n127_), .Y(new_n128_));
  NAND2x1_ASAP7_75t_R g085(.A(new_n97_), .B(new_n100_), .Y(new_n129_));
  AO21x1_ASAP7_75t_R  g086(.A1(new_n99_), .A2(new_n82_), .B(new_n97_), .Y(new_n130_));
  OR3x1_ASAP7_75t_R   g087(.A(new_n96_), .B(new_n95_), .C(G5), .Y(new_n131_));
  AO21x1_ASAP7_75t_R  g088(.A1(new_n129_), .A2(new_n130_), .B(new_n131_), .Y(new_n132_));
  AND2x2_ASAP7_75t_R  g089(.A(new_n128_), .B(new_n132_), .Y(new_n133_));
  OA21x2_ASAP7_75t_R  g090(.A1(new_n123_), .A2(new_n124_), .B(new_n133_), .Y(new_n134_));
  NAND2x1_ASAP7_75t_R g091(.A(new_n122_), .B(new_n134_), .Y(new_n135_));
  OR3x1_ASAP7_75t_R   g092(.A(new_n135_), .B(new_n108_), .C(new_n115_), .Y(G428));
  NAND2x1_ASAP7_75t_R g093(.A(G5), .B(G428), .Y(new_n137_));
  NAND2x1_ASAP7_75t_R g094(.A(G3), .B(G427), .Y(new_n138_));
  OA21x2_ASAP7_75t_R  g095(.A1(new_n67_), .A2(new_n63_), .B(G2), .Y(new_n139_));
  AND3x1_ASAP7_75t_R  g096(.A(new_n137_), .B(new_n138_), .C(new_n139_), .Y(new_n140_));
  AO21x1_ASAP7_75t_R  g097(.A1(G428), .A2(G36), .B(new_n69_), .Y(new_n141_));
  NOR2x1_ASAP7_75t_R  g098(.A(new_n44_), .B(new_n67_), .Y(new_n142_));
  AO21x1_ASAP7_75t_R  g099(.A1(G427), .A2(G35), .B(new_n142_), .Y(new_n143_));
  NAND2x1_ASAP7_75t_R g100(.A(G33), .B(G428), .Y(new_n144_));
  NAND2x1_ASAP7_75t_R g101(.A(G31), .B(G427), .Y(new_n145_));
  OA21x2_ASAP7_75t_R  g102(.A1(new_n46_), .A2(new_n67_), .B(new_n145_), .Y(new_n146_));
  AND3x1_ASAP7_75t_R  g103(.A(new_n144_), .B(G30), .C(new_n146_), .Y(new_n147_));
  INVx1_ASAP7_75t_R   g104(.A(new_n147_), .Y(new_n148_));
  OA21x2_ASAP7_75t_R  g105(.A1(new_n141_), .A2(new_n143_), .B(new_n148_), .Y(new_n149_));
  NAND2x1_ASAP7_75t_R g106(.A(G29), .B(G428), .Y(new_n150_));
  NAND2x1_ASAP7_75t_R g107(.A(G27), .B(G427), .Y(new_n151_));
  OA21x2_ASAP7_75t_R  g108(.A1(new_n49_), .A2(new_n67_), .B(new_n151_), .Y(new_n152_));
  AND3x1_ASAP7_75t_R  g109(.A(new_n150_), .B(G26), .C(new_n152_), .Y(new_n153_));
  INVx1_ASAP7_75t_R   g110(.A(new_n153_), .Y(new_n154_));
  NAND2x1_ASAP7_75t_R g111(.A(G25), .B(G428), .Y(new_n155_));
  NAND2x1_ASAP7_75t_R g112(.A(G23), .B(G427), .Y(new_n156_));
  OA21x2_ASAP7_75t_R  g113(.A1(new_n51_), .A2(new_n67_), .B(new_n156_), .Y(new_n157_));
  AND3x1_ASAP7_75t_R  g114(.A(new_n155_), .B(G22), .C(new_n157_), .Y(new_n158_));
  INVx1_ASAP7_75t_R   g115(.A(new_n158_), .Y(new_n159_));
  AND3x1_ASAP7_75t_R  g116(.A(new_n149_), .B(new_n154_), .C(new_n159_), .Y(new_n160_));
  NAND2x1_ASAP7_75t_R g117(.A(G21), .B(G428), .Y(new_n161_));
  NAND2x1_ASAP7_75t_R g118(.A(G19), .B(G427), .Y(new_n162_));
  OA21x2_ASAP7_75t_R  g119(.A1(new_n55_), .A2(new_n67_), .B(new_n162_), .Y(new_n163_));
  AND3x1_ASAP7_75t_R  g120(.A(new_n161_), .B(G18), .C(new_n163_), .Y(new_n164_));
  NAND2x1_ASAP7_75t_R g121(.A(G17), .B(G428), .Y(new_n165_));
  NAND2x1_ASAP7_75t_R g122(.A(G15), .B(G427), .Y(new_n166_));
  OA21x2_ASAP7_75t_R  g123(.A1(new_n57_), .A2(new_n67_), .B(new_n166_), .Y(new_n167_));
  AND3x1_ASAP7_75t_R  g124(.A(new_n165_), .B(G14), .C(new_n167_), .Y(new_n168_));
  NOR2x1_ASAP7_75t_R  g125(.A(new_n164_), .B(new_n168_), .Y(new_n169_));
  NAND2x1_ASAP7_75t_R g126(.A(G13), .B(G428), .Y(new_n170_));
  NAND2x1_ASAP7_75t_R g127(.A(G11), .B(G427), .Y(new_n171_));
  OA21x2_ASAP7_75t_R  g128(.A1(new_n59_), .A2(new_n67_), .B(new_n171_), .Y(new_n172_));
  AND3x1_ASAP7_75t_R  g129(.A(new_n170_), .B(G10), .C(new_n172_), .Y(new_n173_));
  NAND2x1_ASAP7_75t_R g130(.A(G9), .B(G428), .Y(new_n174_));
  NAND2x1_ASAP7_75t_R g131(.A(G7), .B(G427), .Y(new_n175_));
  OA21x2_ASAP7_75t_R  g132(.A1(new_n61_), .A2(new_n67_), .B(new_n175_), .Y(new_n176_));
  AND3x1_ASAP7_75t_R  g133(.A(new_n174_), .B(G6), .C(new_n176_), .Y(new_n177_));
  NOR2x1_ASAP7_75t_R  g134(.A(new_n173_), .B(new_n177_), .Y(new_n178_));
  AND2x2_ASAP7_75t_R  g135(.A(new_n169_), .B(new_n178_), .Y(new_n179_));
  AOI21x1_ASAP7_75t_R g136(.A1(new_n179_), .A2(new_n160_), .B(new_n140_), .Y(G429));
  INVx1_ASAP7_75t_R   g137(.A(new_n173_), .Y(new_n181_));
  AO21x1_ASAP7_75t_R  g138(.A1(new_n181_), .A2(new_n168_), .B(new_n164_), .Y(new_n182_));
  OR3x1_ASAP7_75t_R   g139(.A(new_n182_), .B(new_n173_), .C(new_n177_), .Y(G430));
  INVx1_ASAP7_75t_R   g140(.A(new_n164_), .Y(new_n184_));
  NOR2x1_ASAP7_75t_R  g141(.A(new_n168_), .B(new_n173_), .Y(new_n185_));
  AND3x1_ASAP7_75t_R  g142(.A(new_n185_), .B(new_n158_), .C(new_n184_), .Y(new_n186_));
  AO21x1_ASAP7_75t_R  g143(.A1(new_n153_), .A2(new_n169_), .B(new_n186_), .Y(new_n187_));
  OR3x1_ASAP7_75t_R   g144(.A(new_n187_), .B(new_n173_), .C(new_n177_), .Y(G431));
  AND3x1_ASAP7_75t_R  g145(.A(new_n185_), .B(new_n147_), .C(new_n154_), .Y(new_n189_));
  AO21x1_ASAP7_75t_R  g146(.A1(new_n181_), .A2(new_n168_), .B(new_n177_), .Y(new_n190_));
  OR3x1_ASAP7_75t_R   g147(.A(new_n186_), .B(new_n189_), .C(new_n190_), .Y(G432));
endmodule


