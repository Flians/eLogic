// Benchmark "/home/flynn/workplace/MIGBalance/tools/mockturtle/experiments/benchmarks/c432" written by ABC on Wed Oct  7 15:25:31 2026

module \/home/flynn/workplace/MIGBalance/tools/mockturtle/experiments/benchmarks/c432  ( 
    G32, G34, G28, G30, G24, G26, G20, G22, G16, G18, G12, G14, G8, G10,
    G4, G6, G1, G2, G35, G31, G27, G23, G19, G15, G11, G7, G3, G36, G33,
    G29, G25, G21, G17, G13, G9, G5,
    G426, G427, G428, G429, G430, G431, G432  );
  input  G32, G34, G28, G30, G24, G26, G20, G22, G16, G18, G12, G14, G8,
    G10, G4, G6, G1, G2, G35, G31, G27, G23, G19, G15, G11, G7, G3, G36,
    G33, G29, G25, G21, G17, G13, G9, G5;
  output G426, G427, G428, G429, G430, G431, G432;
  wire new_n54_, new_n55_, new_n57_, new_n58_, new_n59_, new_n60_, new_n61_,
    new_n62_, new_n63_, new_n64_, new_n65_, new_n66_, new_n69_, new_n70_,
    new_n71_, new_n72_, new_n73_, new_n74_, new_n75_, new_n76_, new_n77_,
    new_n78_, new_n79_, new_n80_, new_n81_, new_n82_, new_n83_, new_n84_,
    new_n85_, new_n86_, new_n87_, new_n88_, new_n89_, new_n90_, new_n91_,
    new_n92_, new_n93_, new_n94_, new_n95_, new_n96_, new_n97_, new_n100_,
    new_n101_, new_n102_, new_n103_, new_n104_, new_n105_, new_n106_,
    new_n107_, new_n108_, new_n109_, new_n110_, new_n111_, new_n112_,
    new_n113_, new_n114_, new_n115_, new_n116_, new_n117_, new_n118_,
    new_n119_, new_n120_, new_n121_, new_n122_, new_n123_, new_n124_,
    new_n125_, new_n126_, new_n127_, new_n128_, new_n129_, new_n130_,
    new_n131_, new_n132_, new_n135_, new_n136_, new_n137_, new_n146_,
    new_n147_, new_n149_, new_n150_, new_n156_, new_n157_, new_n159_,
    new_n160_, new_n161_, new_n163_, new_n164_, new_n165_, new_n166_,
    new_n168_, new_n169_, new_n174_, new_n175_, new_n177_, new_n179_,
    new_n180_, new_n181_, new_n182_, new_n184_, new_n188_, new_n189_,
    new_n190_, new_n191_, new_n192_, new_n193_, new_n194_, new_n195_,
    new_n196_, new_n197_, new_n201_, new_n202_, new_n203_, new_n204_,
    new_n205_, new_n206_, new_n207_, new_n208_, new_n209_, new_n210_,
    new_n212_, new_n213_;
  NOR2x1_ASAP7_75t_R  g000(.A(G32), .B(new_n188_), .Y(new_n54_));
  NOR2x1_ASAP7_75t_R  g001(.A(G28), .B(new_n189_), .Y(new_n55_));
  NOR2x1_ASAP7_75t_R  g002(.A(G20), .B(new_n192_), .Y(new_n57_));
  AO21x1_ASAP7_75t_R  g003(.A1(new_n190_), .A2(G26), .B(new_n57_), .Y(new_n58_));
  OR3x1_ASAP7_75t_R   g004(.A(new_n54_), .B(new_n55_), .C(new_n58_), .Y(new_n59_));
  NOR2x1_ASAP7_75t_R  g005(.A(G16), .B(new_n193_), .Y(new_n60_));
  NOR2x1_ASAP7_75t_R  g006(.A(G12), .B(new_n194_), .Y(new_n61_));
  NOR2x1_ASAP7_75t_R  g007(.A(G8), .B(new_n195_), .Y(new_n62_));
  NOR2x1_ASAP7_75t_R  g008(.A(G4), .B(new_n196_), .Y(new_n63_));
  NOR2x1_ASAP7_75t_R  g009(.A(G1), .B(new_n197_), .Y(new_n64_));
  OR3x1_ASAP7_75t_R   g010(.A(new_n63_), .B(new_n64_), .C(new_n62_), .Y(new_n65_));
  OR3x1_ASAP7_75t_R   g011(.A(new_n60_), .B(new_n61_), .C(new_n65_), .Y(new_n66_));
  OR2x4_ASAP7_75t_R   g012(.A(new_n59_), .B(new_n66_), .Y(G426));
  XOR2x2_ASAP7_75t_R  g013(.A(new_n54_), .B(G426), .Y(new_n69_));
  OR3x1_ASAP7_75t_R   g014(.A(new_n188_), .B(G35), .C(new_n69_), .Y(new_n70_));
  INVx1_ASAP7_75t_R   g015(.A(new_n70_), .Y(new_n71_));
  XOR2x2_ASAP7_75t_R  g016(.A(new_n55_), .B(G426), .Y(new_n72_));
  OR3x1_ASAP7_75t_R   g017(.A(new_n189_), .B(G31), .C(new_n72_), .Y(new_n73_));
  INVx1_ASAP7_75t_R   g018(.A(new_n73_), .Y(new_n74_));
  XNOR2x2_ASAP7_75t_R g019(.A(G24), .B(G426), .Y(new_n75_));
  OR3x1_ASAP7_75t_R   g020(.A(new_n191_), .B(G27), .C(new_n75_), .Y(new_n76_));
  XOR2x2_ASAP7_75t_R  g021(.A(new_n57_), .B(G426), .Y(new_n77_));
  OR3x1_ASAP7_75t_R   g022(.A(new_n192_), .B(G23), .C(new_n77_), .Y(new_n78_));
  NAND2x1_ASAP7_75t_R g023(.A(new_n76_), .B(new_n78_), .Y(new_n79_));
  OR3x1_ASAP7_75t_R   g024(.A(new_n71_), .B(new_n74_), .C(new_n79_), .Y(new_n80_));
  XOR2x2_ASAP7_75t_R  g025(.A(new_n60_), .B(G426), .Y(new_n81_));
  OR3x1_ASAP7_75t_R   g026(.A(new_n193_), .B(G19), .C(new_n81_), .Y(new_n82_));
  INVx1_ASAP7_75t_R   g027(.A(new_n82_), .Y(new_n83_));
  XOR2x2_ASAP7_75t_R  g028(.A(new_n61_), .B(G426), .Y(new_n84_));
  OR3x1_ASAP7_75t_R   g029(.A(new_n194_), .B(G15), .C(new_n84_), .Y(new_n85_));
  INVx1_ASAP7_75t_R   g030(.A(new_n85_), .Y(new_n86_));
  XOR2x2_ASAP7_75t_R  g031(.A(new_n62_), .B(G426), .Y(new_n87_));
  OR3x1_ASAP7_75t_R   g032(.A(new_n195_), .B(G11), .C(new_n87_), .Y(new_n88_));
  INVx1_ASAP7_75t_R   g033(.A(new_n88_), .Y(new_n89_));
  XOR2x2_ASAP7_75t_R  g034(.A(new_n63_), .B(G426), .Y(new_n90_));
  OR3x1_ASAP7_75t_R   g035(.A(new_n196_), .B(G7), .C(new_n90_), .Y(new_n91_));
  INVx1_ASAP7_75t_R   g036(.A(new_n91_), .Y(new_n92_));
  XOR2x2_ASAP7_75t_R  g037(.A(new_n64_), .B(G426), .Y(new_n93_));
  OR3x1_ASAP7_75t_R   g038(.A(new_n197_), .B(G3), .C(new_n93_), .Y(new_n94_));
  INVx1_ASAP7_75t_R   g039(.A(new_n94_), .Y(new_n95_));
  OR3x1_ASAP7_75t_R   g040(.A(new_n92_), .B(new_n95_), .C(new_n89_), .Y(new_n96_));
  OR3x1_ASAP7_75t_R   g041(.A(new_n83_), .B(new_n86_), .C(new_n96_), .Y(new_n97_));
  OR2x4_ASAP7_75t_R   g042(.A(new_n80_), .B(new_n97_), .Y(G427));
  XNOR2x2_ASAP7_75t_R g043(.A(new_n71_), .B(G427), .Y(new_n100_));
  OR3x1_ASAP7_75t_R   g044(.A(new_n188_), .B(G36), .C(new_n69_), .Y(new_n101_));
  INVx1_ASAP7_75t_R   g045(.A(new_n101_), .Y(new_n102_));
  XOR2x2_ASAP7_75t_R  g046(.A(new_n74_), .B(G427), .Y(new_n103_));
  OR3x1_ASAP7_75t_R   g047(.A(new_n189_), .B(G33), .C(new_n72_), .Y(new_n104_));
  NOR2x1_ASAP7_75t_R  g048(.A(new_n103_), .B(new_n104_), .Y(new_n105_));
  AO21x1_ASAP7_75t_R  g049(.A1(new_n100_), .A2(new_n102_), .B(new_n105_), .Y(new_n106_));
  XOR2x2_ASAP7_75t_R  g050(.A(new_n76_), .B(G427), .Y(new_n107_));
  OR3x1_ASAP7_75t_R   g051(.A(new_n191_), .B(G29), .C(new_n75_), .Y(new_n108_));
  INVx1_ASAP7_75t_R   g052(.A(new_n108_), .Y(new_n109_));
  XNOR2x2_ASAP7_75t_R g053(.A(new_n78_), .B(G427), .Y(new_n110_));
  OR3x1_ASAP7_75t_R   g054(.A(new_n192_), .B(G25), .C(new_n77_), .Y(new_n111_));
  NOR2x1_ASAP7_75t_R  g055(.A(new_n110_), .B(new_n111_), .Y(new_n112_));
  AO21x1_ASAP7_75t_R  g056(.A1(new_n107_), .A2(new_n109_), .B(new_n112_), .Y(new_n113_));
  XNOR2x2_ASAP7_75t_R g057(.A(new_n83_), .B(G427), .Y(new_n114_));
  OR3x1_ASAP7_75t_R   g058(.A(new_n193_), .B(G21), .C(new_n81_), .Y(new_n115_));
  INVx1_ASAP7_75t_R   g059(.A(new_n115_), .Y(new_n116_));
  XOR2x2_ASAP7_75t_R  g060(.A(new_n86_), .B(G427), .Y(new_n117_));
  OR3x1_ASAP7_75t_R   g061(.A(new_n194_), .B(G17), .C(new_n84_), .Y(new_n118_));
  NOR2x1_ASAP7_75t_R  g062(.A(new_n117_), .B(new_n118_), .Y(new_n119_));
  AO21x1_ASAP7_75t_R  g063(.A1(new_n114_), .A2(new_n116_), .B(new_n119_), .Y(new_n120_));
  XNOR2x2_ASAP7_75t_R g064(.A(new_n89_), .B(G427), .Y(new_n121_));
  OR3x1_ASAP7_75t_R   g065(.A(new_n195_), .B(G13), .C(new_n87_), .Y(new_n122_));
  INVx1_ASAP7_75t_R   g066(.A(new_n122_), .Y(new_n123_));
  XNOR2x2_ASAP7_75t_R g067(.A(new_n92_), .B(G427), .Y(new_n124_));
  OR3x1_ASAP7_75t_R   g068(.A(new_n196_), .B(G9), .C(new_n90_), .Y(new_n125_));
  INVx1_ASAP7_75t_R   g069(.A(new_n125_), .Y(new_n126_));
  XOR2x2_ASAP7_75t_R  g070(.A(new_n95_), .B(G427), .Y(new_n127_));
  OR3x1_ASAP7_75t_R   g071(.A(new_n197_), .B(G5), .C(new_n93_), .Y(new_n128_));
  NOR2x1_ASAP7_75t_R  g072(.A(new_n127_), .B(new_n128_), .Y(new_n129_));
  AO21x1_ASAP7_75t_R  g073(.A1(new_n124_), .A2(new_n126_), .B(new_n129_), .Y(new_n130_));
  AO21x1_ASAP7_75t_R  g074(.A1(new_n121_), .A2(new_n123_), .B(new_n130_), .Y(new_n131_));
  OR2x4_ASAP7_75t_R   g075(.A(new_n120_), .B(new_n131_), .Y(new_n132_));
  OR3x1_ASAP7_75t_R   g076(.A(new_n106_), .B(new_n113_), .C(new_n132_), .Y(G428));
  AOI21x1_ASAP7_75t_R g077(.A1(G5), .A2(G428), .B(new_n127_), .Y(new_n135_));
  AOI21x1_ASAP7_75t_R g078(.A1(G1), .A2(G426), .B(new_n197_), .Y(new_n136_));
  NAND2x1_ASAP7_75t_R g079(.A(new_n135_), .B(new_n136_), .Y(new_n137_));
  AO21x1_ASAP7_75t_R  g080(.A1(G34), .A2(new_n201_), .B(new_n203_), .Y(new_n146_));
  AO21x1_ASAP7_75t_R  g081(.A1(G29), .A2(G428), .B(new_n191_), .Y(new_n147_));
  AO21x1_ASAP7_75t_R  g082(.A1(G27), .A2(G427), .B(new_n75_), .Y(new_n149_));
  NOR2x1_ASAP7_75t_R  g083(.A(new_n147_), .B(new_n149_), .Y(new_n150_));
  OR3x1_ASAP7_75t_R   g084(.A(new_n150_), .B(new_n206_), .C(new_n146_), .Y(new_n156_));
  AO21x1_ASAP7_75t_R  g085(.A1(G21), .A2(G428), .B(new_n193_), .Y(new_n157_));
  AO21x1_ASAP7_75t_R  g086(.A1(G19), .A2(G427), .B(new_n81_), .Y(new_n159_));
  NOR2x1_ASAP7_75t_R  g087(.A(new_n157_), .B(new_n159_), .Y(new_n160_));
  AO21x1_ASAP7_75t_R  g088(.A1(G17), .A2(G428), .B(new_n194_), .Y(new_n161_));
  AO21x1_ASAP7_75t_R  g089(.A1(G15), .A2(G427), .B(new_n84_), .Y(new_n163_));
  NOR2x1_ASAP7_75t_R  g090(.A(new_n161_), .B(new_n163_), .Y(new_n164_));
  NOR2x1_ASAP7_75t_R  g091(.A(new_n160_), .B(new_n164_), .Y(new_n165_));
  AO21x1_ASAP7_75t_R  g092(.A1(G13), .A2(G428), .B(new_n195_), .Y(new_n166_));
  AO21x1_ASAP7_75t_R  g093(.A1(G11), .A2(G427), .B(new_n87_), .Y(new_n168_));
  NOR2x1_ASAP7_75t_R  g094(.A(new_n166_), .B(new_n168_), .Y(new_n169_));
  OR2x4_ASAP7_75t_R   g095(.A(new_n169_), .B(new_n209_), .Y(new_n174_));
  OR3x1_ASAP7_75t_R   g096(.A(new_n160_), .B(new_n164_), .C(new_n174_), .Y(new_n175_));
  OA21x2_ASAP7_75t_R  g097(.A1(new_n156_), .A2(new_n175_), .B(new_n137_), .Y(G429));
  OA21x2_ASAP7_75t_R  g098(.A1(new_n166_), .A2(new_n168_), .B(new_n164_), .Y(new_n177_));
  OR3x1_ASAP7_75t_R   g099(.A(new_n160_), .B(new_n177_), .C(new_n174_), .Y(G430));
  OR2x4_ASAP7_75t_R   g100(.A(new_n164_), .B(new_n169_), .Y(new_n179_));
  OR3x1_ASAP7_75t_R   g101(.A(new_n207_), .B(new_n160_), .C(new_n179_), .Y(new_n180_));
  INVx1_ASAP7_75t_R   g102(.A(new_n180_), .Y(new_n181_));
  AO21x1_ASAP7_75t_R  g103(.A1(new_n150_), .A2(new_n165_), .B(new_n181_), .Y(new_n182_));
  OR3x1_ASAP7_75t_R   g104(.A(new_n169_), .B(new_n209_), .C(new_n182_), .Y(G431));
  OR3x1_ASAP7_75t_R   g105(.A(new_n204_), .B(new_n150_), .C(new_n179_), .Y(new_n184_));
  INVx1_ASAP7_75t_R   g106(.A(G34), .Y(new_n188_));
  INVx1_ASAP7_75t_R   g107(.A(G30), .Y(new_n189_));
  INVx1_ASAP7_75t_R   g108(.A(G24), .Y(new_n190_));
  INVx1_ASAP7_75t_R   g109(.A(G26), .Y(new_n191_));
  INVx1_ASAP7_75t_R   g110(.A(G22), .Y(new_n192_));
  INVx1_ASAP7_75t_R   g111(.A(G18), .Y(new_n193_));
  INVx1_ASAP7_75t_R   g112(.A(G14), .Y(new_n194_));
  INVx1_ASAP7_75t_R   g113(.A(G10), .Y(new_n195_));
  INVx1_ASAP7_75t_R   g114(.A(G6), .Y(new_n196_));
  INVx1_ASAP7_75t_R   g115(.A(G2), .Y(new_n197_));
  assign              new_n201_ = 1'b1;
  OR3x1_ASAP7_75t_R   g116(.A(new_n72_), .B(new_n103_), .C(G428), .Y(new_n202_));
  AO21x1_ASAP7_75t_R  g117(.A1(new_n212_), .A2(G30), .B(new_n105_), .Y(new_n203_));
  INVx1_ASAP7_75t_R   g118(.A(new_n203_), .Y(new_n204_));
  OR3x1_ASAP7_75t_R   g119(.A(new_n77_), .B(new_n110_), .C(G428), .Y(new_n205_));
  AO21x1_ASAP7_75t_R  g120(.A1(new_n213_), .A2(G22), .B(new_n112_), .Y(new_n206_));
  INVx1_ASAP7_75t_R   g121(.A(new_n206_), .Y(new_n207_));
  AOI21x1_ASAP7_75t_R g122(.A1(G9), .A2(G428), .B(new_n90_), .Y(new_n208_));
  AND3x1_ASAP7_75t_R  g123(.A(new_n208_), .B(G6), .C(new_n124_), .Y(new_n209_));
  NAND2x1_ASAP7_75t_R g124(.A(new_n180_), .B(new_n184_), .Y(new_n210_));
  OR3x1_ASAP7_75t_R   g125(.A(new_n210_), .B(new_n209_), .C(new_n177_), .Y(G432));
  INVx1_ASAP7_75t_R   g126(.A(new_n202_), .Y(new_n212_));
  INVx1_ASAP7_75t_R   g127(.A(new_n205_), .Y(new_n213_));
endmodule


