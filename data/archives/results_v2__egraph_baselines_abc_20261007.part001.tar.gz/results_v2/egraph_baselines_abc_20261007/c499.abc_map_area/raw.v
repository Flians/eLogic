// Benchmark "/home/flynn/workplace/MIGBalance/tools/mockturtle/experiments/benchmarks/c499" written by ABC on Wed Oct  7 15:25:33 2026

module \/home/flynn/workplace/MIGBalance/tools/mockturtle/experiments/benchmarks/c499  ( 
    G14, G2, G6, G10, G34, G41, G25, G26, G27, G28, G29, G30, G31, G32, G4,
    G8, G12, G16, G36, G21, G22, G23, G24, G3, G7, G11, G15, G35, G17, G18,
    G19, G20, G1, G5, G9, G13, G33, G40, G39, G38, G37,
    G481, G482, G480, G468, G469, G470, G471, G472, G473, G474, G475, G476,
    G477, G478, G479, G483, G484, G485, G486, G487, G488, G489, G490, G491,
    G492, G493, G494, G495, G496, G497, G498, G499  );
  input  G14, G2, G6, G10, G34, G41, G25, G26, G27, G28, G29, G30, G31,
    G32, G4, G8, G12, G16, G36, G21, G22, G23, G24, G3, G7, G11, G15, G35,
    G17, G18, G19, G20, G1, G5, G9, G13, G33, G40, G39, G38, G37;
  output G481, G482, G480, G468, G469, G470, G471, G472, G473, G474, G475,
    G476, G477, G478, G479, G483, G484, G485, G486, G487, G488, G489, G490,
    G491, G492, G493, G494, G495, G496, G497, G498, G499;
  wire new_n74_, new_n75_, new_n76_, new_n77_, new_n78_, new_n79_, new_n80_,
    new_n81_, new_n82_, new_n83_, new_n84_, new_n85_, new_n86_, new_n87_,
    new_n88_, new_n89_, new_n90_, new_n91_, new_n92_, new_n93_, new_n94_,
    new_n95_, new_n96_, new_n97_, new_n98_, new_n99_, new_n100_, new_n101_,
    new_n102_, new_n103_, new_n104_, new_n105_, new_n106_, new_n107_,
    new_n108_, new_n109_, new_n110_, new_n111_, new_n112_, new_n113_,
    new_n114_, new_n115_, new_n116_, new_n117_, new_n118_, new_n119_,
    new_n120_, new_n121_, new_n122_, new_n123_, new_n124_, new_n125_,
    new_n126_, new_n127_, new_n128_, new_n129_, new_n130_, new_n131_,
    new_n132_, new_n133_, new_n134_, new_n135_, new_n136_, new_n137_,
    new_n138_, new_n139_, new_n140_, new_n141_, new_n142_, new_n143_,
    new_n144_, new_n145_, new_n146_, new_n147_, new_n148_, new_n149_,
    new_n150_, new_n151_, new_n152_, new_n153_, new_n154_, new_n155_,
    new_n156_, new_n157_, new_n158_, new_n159_, new_n160_, new_n161_,
    new_n162_, new_n163_, new_n164_, new_n165_, new_n166_, new_n167_,
    new_n168_, new_n169_, new_n170_, new_n171_, new_n173_, new_n175_,
    new_n177_, new_n178_, new_n179_, new_n180_, new_n181_, new_n182_,
    new_n184_, new_n186_, new_n188_, new_n190_, new_n191_, new_n193_,
    new_n195_, new_n197_, new_n199_, new_n200_, new_n202_, new_n204_,
    new_n206_, new_n208_, new_n210_, new_n211_, new_n212_, new_n213_,
    new_n214_, new_n215_, new_n216_, new_n217_, new_n218_, new_n219_,
    new_n221_, new_n223_, new_n225_, new_n227_, new_n228_, new_n229_,
    new_n230_, new_n232_, new_n234_, new_n236_, new_n238_, new_n239_,
    new_n241_, new_n243_, new_n245_, new_n247_, new_n248_, new_n250_,
    new_n252_, new_n254_;
  XNOR2x2_ASAP7_75t_R g000(.A(G2), .B(G6), .Y(new_n74_));
  XOR2x2_ASAP7_75t_R  g001(.A(G14), .B(G10), .Y(new_n75_));
  XOR2x2_ASAP7_75t_R  g002(.A(new_n74_), .B(new_n75_), .Y(new_n76_));
  NAND2x1_ASAP7_75t_R g003(.A(G34), .B(G41), .Y(new_n77_));
  XNOR2x2_ASAP7_75t_R g004(.A(G25), .B(G26), .Y(new_n78_));
  XOR2x2_ASAP7_75t_R  g005(.A(G27), .B(G28), .Y(new_n79_));
  XOR2x2_ASAP7_75t_R  g006(.A(new_n78_), .B(new_n79_), .Y(new_n80_));
  XNOR2x2_ASAP7_75t_R g007(.A(G29), .B(G30), .Y(new_n81_));
  XOR2x2_ASAP7_75t_R  g008(.A(G31), .B(G32), .Y(new_n82_));
  XOR2x2_ASAP7_75t_R  g009(.A(new_n81_), .B(new_n82_), .Y(new_n83_));
  XOR2x2_ASAP7_75t_R  g010(.A(new_n80_), .B(new_n83_), .Y(new_n84_));
  XOR2x2_ASAP7_75t_R  g011(.A(new_n84_), .B(new_n77_), .Y(new_n85_));
  XNOR2x2_ASAP7_75t_R g012(.A(new_n76_), .B(new_n85_), .Y(new_n86_));
  INVx1_ASAP7_75t_R   g013(.A(new_n86_), .Y(new_n87_));
  XNOR2x2_ASAP7_75t_R g014(.A(G4), .B(G8), .Y(new_n88_));
  XOR2x2_ASAP7_75t_R  g015(.A(G12), .B(G16), .Y(new_n89_));
  XOR2x2_ASAP7_75t_R  g016(.A(new_n88_), .B(new_n89_), .Y(new_n90_));
  NAND2x1_ASAP7_75t_R g017(.A(G41), .B(G36), .Y(new_n91_));
  XNOR2x2_ASAP7_75t_R g018(.A(G21), .B(G22), .Y(new_n92_));
  XOR2x2_ASAP7_75t_R  g019(.A(G23), .B(G24), .Y(new_n93_));
  XOR2x2_ASAP7_75t_R  g020(.A(new_n92_), .B(new_n93_), .Y(new_n94_));
  XOR2x2_ASAP7_75t_R  g021(.A(new_n83_), .B(new_n94_), .Y(new_n95_));
  XOR2x2_ASAP7_75t_R  g022(.A(new_n95_), .B(new_n91_), .Y(new_n96_));
  XOR2x2_ASAP7_75t_R  g023(.A(new_n96_), .B(new_n90_), .Y(new_n97_));
  XNOR2x2_ASAP7_75t_R g024(.A(G3), .B(G7), .Y(new_n98_));
  XOR2x2_ASAP7_75t_R  g025(.A(G11), .B(G15), .Y(new_n99_));
  XOR2x2_ASAP7_75t_R  g026(.A(new_n98_), .B(new_n99_), .Y(new_n100_));
  AND2x2_ASAP7_75t_R  g027(.A(G41), .B(G35), .Y(new_n101_));
  XOR2x2_ASAP7_75t_R  g028(.A(G17), .B(G18), .Y(new_n102_));
  XOR2x2_ASAP7_75t_R  g029(.A(G19), .B(G20), .Y(new_n103_));
  XOR2x2_ASAP7_75t_R  g030(.A(new_n102_), .B(new_n103_), .Y(new_n104_));
  XOR2x2_ASAP7_75t_R  g031(.A(new_n80_), .B(new_n104_), .Y(new_n105_));
  XOR2x2_ASAP7_75t_R  g032(.A(new_n105_), .B(new_n101_), .Y(new_n106_));
  XNOR2x2_ASAP7_75t_R g033(.A(new_n100_), .B(new_n106_), .Y(new_n107_));
  INVx1_ASAP7_75t_R   g034(.A(new_n107_), .Y(new_n108_));
  NOR2x1_ASAP7_75t_R  g035(.A(new_n97_), .B(new_n108_), .Y(new_n109_));
  XNOR2x2_ASAP7_75t_R g036(.A(G1), .B(G5), .Y(new_n110_));
  XOR2x2_ASAP7_75t_R  g037(.A(G9), .B(G13), .Y(new_n111_));
  XOR2x2_ASAP7_75t_R  g038(.A(new_n110_), .B(new_n111_), .Y(new_n112_));
  AND2x2_ASAP7_75t_R  g039(.A(G41), .B(G33), .Y(new_n113_));
  XOR2x2_ASAP7_75t_R  g040(.A(new_n94_), .B(new_n104_), .Y(new_n114_));
  XOR2x2_ASAP7_75t_R  g041(.A(new_n114_), .B(new_n113_), .Y(new_n115_));
  XNOR2x2_ASAP7_75t_R g042(.A(new_n112_), .B(new_n115_), .Y(new_n116_));
  INVx1_ASAP7_75t_R   g043(.A(new_n116_), .Y(new_n117_));
  AND2x2_ASAP7_75t_R  g044(.A(new_n117_), .B(new_n86_), .Y(new_n118_));
  AND2x2_ASAP7_75t_R  g045(.A(new_n87_), .B(new_n116_), .Y(new_n119_));
  OAI21x1_ASAP7_75t_R g046(.A1(new_n118_), .A2(new_n119_), .B(new_n109_), .Y(new_n120_));
  NOR2x1_ASAP7_75t_R  g047(.A(new_n97_), .B(new_n107_), .Y(new_n121_));
  AND2x2_ASAP7_75t_R  g048(.A(new_n86_), .B(new_n116_), .Y(new_n122_));
  AND2x2_ASAP7_75t_R  g049(.A(new_n107_), .B(new_n97_), .Y(new_n123_));
  OAI21x1_ASAP7_75t_R g050(.A1(new_n123_), .A2(new_n121_), .B(new_n122_), .Y(new_n124_));
  AND2x2_ASAP7_75t_R  g051(.A(new_n120_), .B(new_n124_), .Y(new_n125_));
  INVx1_ASAP7_75t_R   g052(.A(new_n125_), .Y(new_n126_));
  XNOR2x2_ASAP7_75t_R g053(.A(G24), .B(G20), .Y(new_n127_));
  XOR2x2_ASAP7_75t_R  g054(.A(G28), .B(G32), .Y(new_n128_));
  XOR2x2_ASAP7_75t_R  g055(.A(new_n127_), .B(new_n128_), .Y(new_n129_));
  NAND2x1_ASAP7_75t_R g056(.A(G41), .B(G40), .Y(new_n130_));
  XNOR2x2_ASAP7_75t_R g057(.A(G6), .B(G5), .Y(new_n131_));
  XOR2x2_ASAP7_75t_R  g058(.A(G8), .B(G7), .Y(new_n132_));
  XOR2x2_ASAP7_75t_R  g059(.A(new_n131_), .B(new_n132_), .Y(new_n133_));
  XNOR2x2_ASAP7_75t_R g060(.A(G14), .B(G13), .Y(new_n134_));
  XOR2x2_ASAP7_75t_R  g061(.A(G16), .B(G15), .Y(new_n135_));
  XOR2x2_ASAP7_75t_R  g062(.A(new_n134_), .B(new_n135_), .Y(new_n136_));
  XOR2x2_ASAP7_75t_R  g063(.A(new_n133_), .B(new_n136_), .Y(new_n137_));
  XOR2x2_ASAP7_75t_R  g064(.A(new_n137_), .B(new_n130_), .Y(new_n138_));
  XOR2x2_ASAP7_75t_R  g065(.A(new_n138_), .B(new_n129_), .Y(new_n139_));
  AND2x2_ASAP7_75t_R  g066(.A(new_n126_), .B(new_n139_), .Y(new_n140_));
  XNOR2x2_ASAP7_75t_R g067(.A(G23), .B(G19), .Y(new_n141_));
  XOR2x2_ASAP7_75t_R  g068(.A(G27), .B(G31), .Y(new_n142_));
  XOR2x2_ASAP7_75t_R  g069(.A(new_n141_), .B(new_n142_), .Y(new_n143_));
  AND2x2_ASAP7_75t_R  g070(.A(G41), .B(G39), .Y(new_n144_));
  XNOR2x2_ASAP7_75t_R g071(.A(G2), .B(G1), .Y(new_n145_));
  XOR2x2_ASAP7_75t_R  g072(.A(G4), .B(G3), .Y(new_n146_));
  XOR2x2_ASAP7_75t_R  g073(.A(new_n145_), .B(new_n146_), .Y(new_n147_));
  XOR2x2_ASAP7_75t_R  g074(.A(G10), .B(G9), .Y(new_n148_));
  XOR2x2_ASAP7_75t_R  g075(.A(G12), .B(G11), .Y(new_n149_));
  XOR2x2_ASAP7_75t_R  g076(.A(new_n148_), .B(new_n149_), .Y(new_n150_));
  XOR2x2_ASAP7_75t_R  g077(.A(new_n147_), .B(new_n150_), .Y(new_n151_));
  XOR2x2_ASAP7_75t_R  g078(.A(new_n151_), .B(new_n144_), .Y(new_n152_));
  XNOR2x2_ASAP7_75t_R g079(.A(new_n143_), .B(new_n152_), .Y(new_n153_));
  XNOR2x2_ASAP7_75t_R g080(.A(G22), .B(G18), .Y(new_n154_));
  XOR2x2_ASAP7_75t_R  g081(.A(G26), .B(G30), .Y(new_n155_));
  XOR2x2_ASAP7_75t_R  g082(.A(new_n154_), .B(new_n155_), .Y(new_n156_));
  AND2x2_ASAP7_75t_R  g083(.A(G41), .B(G38), .Y(new_n157_));
  XOR2x2_ASAP7_75t_R  g084(.A(new_n136_), .B(new_n150_), .Y(new_n158_));
  XOR2x2_ASAP7_75t_R  g085(.A(new_n158_), .B(new_n157_), .Y(new_n159_));
  XNOR2x2_ASAP7_75t_R g086(.A(new_n156_), .B(new_n159_), .Y(new_n160_));
  INVx1_ASAP7_75t_R   g087(.A(new_n160_), .Y(new_n161_));
  XNOR2x2_ASAP7_75t_R g088(.A(G21), .B(G17), .Y(new_n162_));
  XOR2x2_ASAP7_75t_R  g089(.A(G25), .B(G29), .Y(new_n163_));
  XOR2x2_ASAP7_75t_R  g090(.A(new_n162_), .B(new_n163_), .Y(new_n164_));
  NAND2x1_ASAP7_75t_R g091(.A(G41), .B(G37), .Y(new_n165_));
  XOR2x2_ASAP7_75t_R  g092(.A(new_n133_), .B(new_n147_), .Y(new_n166_));
  XOR2x2_ASAP7_75t_R  g093(.A(new_n166_), .B(new_n165_), .Y(new_n167_));
  XNOR2x2_ASAP7_75t_R g094(.A(new_n164_), .B(new_n167_), .Y(new_n168_));
  AND2x2_ASAP7_75t_R  g095(.A(new_n161_), .B(new_n168_), .Y(new_n169_));
  AND3x1_ASAP7_75t_R  g096(.A(new_n140_), .B(new_n153_), .C(new_n169_), .Y(new_n170_));
  AND2x2_ASAP7_75t_R  g097(.A(new_n170_), .B(new_n87_), .Y(new_n171_));
  XOR2x2_ASAP7_75t_R  g098(.A(new_n171_), .B(G14), .Y(G481));
  AND2x2_ASAP7_75t_R  g099(.A(new_n170_), .B(new_n108_), .Y(new_n173_));
  XOR2x2_ASAP7_75t_R  g100(.A(new_n173_), .B(G15), .Y(G482));
  AND2x2_ASAP7_75t_R  g101(.A(new_n170_), .B(new_n117_), .Y(new_n175_));
  XOR2x2_ASAP7_75t_R  g102(.A(new_n175_), .B(G13), .Y(G480));
  INVx1_ASAP7_75t_R   g103(.A(new_n153_), .Y(new_n177_));
  NOR2x1_ASAP7_75t_R  g104(.A(new_n139_), .B(new_n125_), .Y(new_n178_));
  INVx1_ASAP7_75t_R   g105(.A(new_n168_), .Y(new_n179_));
  AND2x2_ASAP7_75t_R  g106(.A(new_n179_), .B(new_n160_), .Y(new_n180_));
  AND3x1_ASAP7_75t_R  g107(.A(new_n178_), .B(new_n177_), .C(new_n180_), .Y(new_n181_));
  AND2x2_ASAP7_75t_R  g108(.A(new_n181_), .B(new_n117_), .Y(new_n182_));
  XOR2x2_ASAP7_75t_R  g109(.A(new_n182_), .B(G1), .Y(G468));
  AND2x2_ASAP7_75t_R  g110(.A(new_n181_), .B(new_n87_), .Y(new_n184_));
  XOR2x2_ASAP7_75t_R  g111(.A(new_n184_), .B(G2), .Y(G469));
  AND2x2_ASAP7_75t_R  g112(.A(new_n181_), .B(new_n108_), .Y(new_n186_));
  XOR2x2_ASAP7_75t_R  g113(.A(new_n186_), .B(G3), .Y(G470));
  AND2x2_ASAP7_75t_R  g114(.A(new_n181_), .B(new_n97_), .Y(new_n188_));
  XOR2x2_ASAP7_75t_R  g115(.A(new_n188_), .B(G4), .Y(G471));
  AND3x1_ASAP7_75t_R  g116(.A(new_n140_), .B(new_n153_), .C(new_n180_), .Y(new_n190_));
  AND2x2_ASAP7_75t_R  g117(.A(new_n190_), .B(new_n117_), .Y(new_n191_));
  XOR2x2_ASAP7_75t_R  g118(.A(new_n191_), .B(G5), .Y(G472));
  AND2x2_ASAP7_75t_R  g119(.A(new_n190_), .B(new_n87_), .Y(new_n193_));
  XOR2x2_ASAP7_75t_R  g120(.A(new_n193_), .B(G6), .Y(G473));
  AND2x2_ASAP7_75t_R  g121(.A(new_n190_), .B(new_n108_), .Y(new_n195_));
  XOR2x2_ASAP7_75t_R  g122(.A(new_n195_), .B(G7), .Y(G474));
  AND2x2_ASAP7_75t_R  g123(.A(new_n190_), .B(new_n97_), .Y(new_n197_));
  XOR2x2_ASAP7_75t_R  g124(.A(new_n197_), .B(G8), .Y(G475));
  AND3x1_ASAP7_75t_R  g125(.A(new_n178_), .B(new_n177_), .C(new_n169_), .Y(new_n199_));
  AND2x2_ASAP7_75t_R  g126(.A(new_n199_), .B(new_n117_), .Y(new_n200_));
  XOR2x2_ASAP7_75t_R  g127(.A(new_n200_), .B(G9), .Y(G476));
  AND2x2_ASAP7_75t_R  g128(.A(new_n199_), .B(new_n87_), .Y(new_n202_));
  XOR2x2_ASAP7_75t_R  g129(.A(new_n202_), .B(G10), .Y(G477));
  AND2x2_ASAP7_75t_R  g130(.A(new_n199_), .B(new_n108_), .Y(new_n204_));
  XOR2x2_ASAP7_75t_R  g131(.A(new_n204_), .B(G11), .Y(G478));
  AND2x2_ASAP7_75t_R  g132(.A(new_n199_), .B(new_n97_), .Y(new_n206_));
  XOR2x2_ASAP7_75t_R  g133(.A(new_n206_), .B(G12), .Y(G479));
  AND2x2_ASAP7_75t_R  g134(.A(new_n170_), .B(new_n97_), .Y(new_n208_));
  XOR2x2_ASAP7_75t_R  g135(.A(new_n208_), .B(G16), .Y(G483));
  NOR2x1_ASAP7_75t_R  g136(.A(new_n139_), .B(new_n177_), .Y(new_n210_));
  OAI21x1_ASAP7_75t_R g137(.A1(new_n169_), .A2(new_n180_), .B(new_n210_), .Y(new_n211_));
  NOR2x1_ASAP7_75t_R  g138(.A(new_n139_), .B(new_n153_), .Y(new_n212_));
  AND2x2_ASAP7_75t_R  g139(.A(new_n168_), .B(new_n160_), .Y(new_n213_));
  AND2x2_ASAP7_75t_R  g140(.A(new_n153_), .B(new_n139_), .Y(new_n214_));
  OAI21x1_ASAP7_75t_R g141(.A1(new_n214_), .A2(new_n212_), .B(new_n213_), .Y(new_n215_));
  AND2x2_ASAP7_75t_R  g142(.A(new_n211_), .B(new_n215_), .Y(new_n216_));
  NOR2x1_ASAP7_75t_R  g143(.A(new_n97_), .B(new_n216_), .Y(new_n217_));
  AND3x1_ASAP7_75t_R  g144(.A(new_n217_), .B(new_n108_), .C(new_n118_), .Y(new_n218_));
  AND2x2_ASAP7_75t_R  g145(.A(new_n218_), .B(new_n179_), .Y(new_n219_));
  XOR2x2_ASAP7_75t_R  g146(.A(new_n219_), .B(G17), .Y(G484));
  AND2x2_ASAP7_75t_R  g147(.A(new_n218_), .B(new_n161_), .Y(new_n221_));
  XOR2x2_ASAP7_75t_R  g148(.A(new_n221_), .B(G18), .Y(G485));
  AND2x2_ASAP7_75t_R  g149(.A(new_n218_), .B(new_n177_), .Y(new_n223_));
  XOR2x2_ASAP7_75t_R  g150(.A(new_n223_), .B(G19), .Y(G486));
  AND2x2_ASAP7_75t_R  g151(.A(new_n218_), .B(new_n139_), .Y(new_n225_));
  XOR2x2_ASAP7_75t_R  g152(.A(new_n225_), .B(G20), .Y(G487));
  INVx1_ASAP7_75t_R   g153(.A(new_n216_), .Y(new_n227_));
  AND2x2_ASAP7_75t_R  g154(.A(new_n227_), .B(new_n97_), .Y(new_n228_));
  AND3x1_ASAP7_75t_R  g155(.A(new_n228_), .B(new_n107_), .C(new_n118_), .Y(new_n229_));
  AND2x2_ASAP7_75t_R  g156(.A(new_n229_), .B(new_n179_), .Y(new_n230_));
  XOR2x2_ASAP7_75t_R  g157(.A(new_n230_), .B(G21), .Y(G488));
  AND2x2_ASAP7_75t_R  g158(.A(new_n229_), .B(new_n161_), .Y(new_n232_));
  XOR2x2_ASAP7_75t_R  g159(.A(new_n232_), .B(G22), .Y(G489));
  AND2x2_ASAP7_75t_R  g160(.A(new_n229_), .B(new_n177_), .Y(new_n234_));
  XOR2x2_ASAP7_75t_R  g161(.A(new_n234_), .B(G23), .Y(G490));
  AND2x2_ASAP7_75t_R  g162(.A(new_n229_), .B(new_n139_), .Y(new_n236_));
  XOR2x2_ASAP7_75t_R  g163(.A(new_n236_), .B(G24), .Y(G491));
  AND3x1_ASAP7_75t_R  g164(.A(new_n217_), .B(new_n108_), .C(new_n119_), .Y(new_n238_));
  AND2x2_ASAP7_75t_R  g165(.A(new_n238_), .B(new_n179_), .Y(new_n239_));
  XOR2x2_ASAP7_75t_R  g166(.A(new_n239_), .B(G25), .Y(G492));
  AND2x2_ASAP7_75t_R  g167(.A(new_n238_), .B(new_n161_), .Y(new_n241_));
  XOR2x2_ASAP7_75t_R  g168(.A(new_n241_), .B(G26), .Y(G493));
  AND2x2_ASAP7_75t_R  g169(.A(new_n238_), .B(new_n177_), .Y(new_n243_));
  XOR2x2_ASAP7_75t_R  g170(.A(new_n243_), .B(G27), .Y(G494));
  AND2x2_ASAP7_75t_R  g171(.A(new_n238_), .B(new_n139_), .Y(new_n245_));
  XOR2x2_ASAP7_75t_R  g172(.A(new_n245_), .B(G28), .Y(G495));
  AND3x1_ASAP7_75t_R  g173(.A(new_n228_), .B(new_n107_), .C(new_n119_), .Y(new_n247_));
  AND2x2_ASAP7_75t_R  g174(.A(new_n247_), .B(new_n179_), .Y(new_n248_));
  XOR2x2_ASAP7_75t_R  g175(.A(new_n248_), .B(G29), .Y(G496));
  AND2x2_ASAP7_75t_R  g176(.A(new_n247_), .B(new_n161_), .Y(new_n250_));
  XOR2x2_ASAP7_75t_R  g177(.A(new_n250_), .B(G30), .Y(G497));
  AND2x2_ASAP7_75t_R  g178(.A(new_n247_), .B(new_n177_), .Y(new_n252_));
  XOR2x2_ASAP7_75t_R  g179(.A(new_n252_), .B(G31), .Y(G498));
  AND2x2_ASAP7_75t_R  g180(.A(new_n247_), .B(new_n139_), .Y(new_n254_));
  XOR2x2_ASAP7_75t_R  g181(.A(new_n254_), .B(G32), .Y(G499));
endmodule


