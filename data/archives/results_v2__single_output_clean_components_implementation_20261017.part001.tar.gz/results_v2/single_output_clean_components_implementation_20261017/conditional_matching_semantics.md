# Scope of the SDC argument

The implemented policy keeps care-qualified physical matches outside the Boolean e-graph. This is a representation/budgeting choice, not a theorem that every guarded concrete union is unsound.

Let B(X) denote the concrete boundary functions of the original primary inputs X. If a certified mask C contains image(B), and f(b)=g(b) for every b in C, then f(B(X))=g(B(X)) for every X. A guarded union between these instantiated terms can therefore be sound under the same fixed design semantics. What is not justified is the unrestricted function identity f(b)=g(b) for arbitrary independent b, or reusing a care proof with a different unproved boundary.

Example: B=(x, x&y), f(b1,b2)=b1|b2 and g(b1,b2)=b1. The concrete terms are globally equal as primary-input functions, so their particular union can be sound; the generic identity b1|b2=b1 is false at (0,1).

The current external-instance design avoids materializing every cell term and retains physical phase/pin/cost/sharing decisions separately. Conditional matches never add generic Boolean equalities. This policy can be evaluated as part of a bounded mapper; it should not be claimed as the only sound SDC/e-graph integration or as a proven first. ODC does not generally establish equality of the internal functions and needs separate contextual validation; ODC is not implemented here.
