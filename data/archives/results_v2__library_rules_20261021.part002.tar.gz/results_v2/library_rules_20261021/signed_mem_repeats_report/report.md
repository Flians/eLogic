# One-way library-rule ablation
Attempted 6/6; final CEC 6; native completed 4; selected 4.
Paired DA summary: {'1': {'better': 2}, '2': {'worse': 2}}

Profiles are fixed across designs; no per-design winner selection. Source-only fallbacks are not native optimization successes. Failed and missing slots remain in the scope. Critical-path candidate descriptions do not prove cross-profile AIG boundary correspondence.

|Design|Profile|A|D|T (s)|Native selected|Status|
|---|---:|---:|---:|---:|---|---|
|mem_ctrl|2|4290.740158982575|2731.2299823760986|61.404066471004626|False|ok|
|mem_ctrl|1|3668.6999966725707|1056.510009765625|58.94747657100379|True|ok|
|mem_ctrl|0|3660.7199973762035|1059.6900081634521|51.49340269599634|True|ok|
|mem_ctrl|0|3660.7199973762035|1059.6900081634521|51.85668417099805|True|ok|
|mem_ctrl|1|3668.6999966725707|1056.510009765625|58.88314969500061|True|ok|
|mem_ctrl|2|4290.740158982575|2731.2299823760986|61.392238157000975|False|ok|
