module mapped(\x0[0] , \x1[0] , \x2[0] , \x3[0] , \x4[0] , \x5[0] , \x6[0] , \x7[0] , \x8[0] , \result[0] );
  input \x0[0] ;
  input \x1[0] ;
  input \x2[0] ;
  input \x3[0] ;
  input \x4[0] ;
  input \x5[0] ;
  input \x6[0] ;
  input \x7[0] ;
  input \x8[0] ;
  output \result[0] ;
  wire __egm_s25;
  AO333x1_ASAP7_75t_R __egm_g9 (.A1(\x0[0] ), .A2(\x1[0] ), .A3(\x2[0] ), .B1(\x3[0] ), .B2(\x4[0] ), .B3(\x5[0] ), .C1(\x6[0] ), .C2(\x7[0] ), .C3(\x8[0] ), .Y(__egm_s25));
  assign \result[0]  = __egm_s25;
endmodule
