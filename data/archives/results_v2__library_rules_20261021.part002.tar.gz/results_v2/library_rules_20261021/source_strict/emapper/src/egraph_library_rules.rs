//! Isolated second-stage one-way library equalities. Never run Boolean rules here.
//! Physical nodes use a reserved namespace and cannot become logical witnesses.
use super::*;
use egg::{Pattern, Searcher};
const PREFIX:&str="@egm_library_cell_";
pub(super) fn physical(node:&AigLang)->bool {matches!(node,AigLang::Cell(s,_)if s.as_str().starts_with(PREFIX))}
pub(super) fn mode()->u8 {let m=std::env::var("EGM_LIBRARY_RULE_MODE").unwrap_or_else(|_|"0".into()).parse::<u8>().expect("library rule mode integer");assert!(m<=2);m}
#[derive(Default,serde::Serialize)]
pub(super) struct Audit {pub cells:usize,pub patterns:usize,pub search_calls:usize,pub matches:usize,pub added_nodes:usize,pub budget_rejected:usize,pub rounds:usize,pub generated:usize,pub work_limit:usize,pub iteration_limit:usize,pub secs:f64,pub logical_rounds:usize,pub generated_by_cell:BTreeMap<String,usize>,pub matches_by_cell:BTreeMap<String,usize>,pub post_import_allowance:usize,pub post_import_used:usize,pub work_used:usize,pub exhausted:bool}
fn variables(p:&wide::Pattern,out:&mut BTreeSet<usize>){match p{wide::Pattern::Var(v)=>{out.insert(*v);},wide::Pattern::Not(x)=>variables(x,out),wide::Pattern::And(a,b)=>{variables(a,out);variables(b,out);},_=>{}}}
fn value(p:&wide::Pattern,a:usize)->bool {match p{wide::Pattern::Var(v)=>a&(1<<v)!=0,wide::Pattern::Const(v)=>*v,wide::Pattern::Not(x)=>!value(x,a),wide::Pattern::And(x,y)=>value(x,a)&&value(y,a)}}
#[cfg(test)]thread_local!{static VARIANT_CALLS:std::cell::Cell<usize>=const{std::cell::Cell::new(0)};}
fn variants(p:&wide::Pattern)->Vec<String>{
 #[cfg(test)]VARIANT_CALLS.with(|v|v.set(v.get()+1));
 use wide::Pattern::*;
 let mut out=BTreeSet::new();
 match p{
  Var(v)=>{out.insert(format!("?i{v}"));},Const(v)=>{out.insert(if *v{"1"}else{"0"}.into());},
  Not(x)=>{for x in variants(x){out.insert(format!("(~ {x})"));}},
  And(a,b)=>{let av=variants(a);let bv=variants(b);for a in av.iter().take(4){for b in bv.iter().take(4){out.insert(format!("(& {a} {b})"));out.insert(format!("(& {b} {a})"));}}
   // Explicit phase-AND is the counted compact AIG representation.
   let an=matches!(a.as_ref(),Not(_));let bn=matches!(b.as_ref(),Not(_));
   if an||bn {let sym=match(an,bn){(true,false)=>"@egm_and_np",(false,true)=>"@egm_and_pn",_=>"@egm_and_nn"};
    let unneg=|text:&String,negative:bool|if negative{text.strip_prefix("(~ ").and_then(|s|s.strip_suffix(')')).map(str::to_string)}else{Some(text.clone())};
    for x in av.iter().filter_map(|s|unneg(s,an)).take(2){for y in bv.iter().filter_map(|s|unneg(s,bn)).take(2){out.insert(format!("({sym} {x} {y})"));}}
   }
  }
 }
 // Match exact TT3/TT4 imported atoms without expanding them into uncharged Boolean nodes.
 let mut vars=BTreeSet::new();variables(p,&mut vars);let vars:Vec<_>=vars.into_iter().collect();
 if (3..=4).contains(&vars.len()) {let truth=(0..1usize<<vars.len()).fold(0u64,|t,a|{let raw=vars.iter().enumerate().fold(0,|x,(i,v)|x|(((a>>i)&1)<<v));t|((value(p,raw)as u64)<<a)});out.insert(format!("(@egm_tt{}_{} {})",vars.len(),format!("{truth:x}"),vars.iter().map(|v|format!("?i{v}")).collect::<Vec<_>>().join(" ")));}
 // Deterministic bounded variants, actual retained count exposed in the audit.
 let mut out:Vec<_>=out.into_iter().collect();out.sort_by_key(|s|(!s.starts_with("(@egm_tt"),s.len(),s.clone()));out.into_iter().take(32).collect()
}
fn normalize(p:wide::Pattern)->wide::Pattern {use wide::Pattern::*;match p{Not(x)=>match normalize(*x){Not(y)=>*y,x=>Not(Box::new(x))},And(a,b)=>And(Box::new(normalize(*a)),Box::new(normalize(*b))),x=>x}}
fn plain(p:&wide::Pattern)->String {match p{wide::Pattern::Var(v)=>format!("?i{v}"),wide::Pattern::Const(v)=>if *v{"1"}else{"0"}.into(),wide::Pattern::Not(x)=>format!("(~ {})",plain(x)),wide::Pattern::And(a,b)=>format!("(& {} {})",plain(a),plain(b))}}
pub(super) fn patterns(cell:&Cell)->Vec<Pattern<AigLang>> {
 let s=wide::support(cell);let truth:Vec<_>=(0..1usize<<s.positions.len()).map(|a|crate::tt9::tt9_bit_get(&s.truth,a)).collect();
 let mut trees=vec![wide::pattern(&cell.expr,cell,&s)];if let Some(p)=wide::decompose(&s.positions,&truth){trees.push(p);}
 let trees:Vec<_>=trees.into_iter().map(normalize).collect();let mut seen=BTreeSet::new();trees.iter().map(plain).chain(trees.iter().flat_map(variants)).filter(|p|seen.insert(p.clone())).filter_map(|p|p.parse().ok()).take(32).collect()
}
pub(super) fn saturate(graph:&mut egg::EGraph<AigLang,()>,admission:&crate::egraph_budget::SharedAdmission,tech:&TechLib,ps:&MapParams,logic_rounds:usize,imported:usize)->Audit{
 let start=Instant::now();let mut audit=Audit::default();audit.logical_rounds=logic_rounds;audit.iteration_limit=ps.saturation.iter_limit.saturating_sub(logic_rounds);audit.work_limit=ps.max_instances.saturating_mul(16)/if mode()==2{2}else{1};
 let rules:Vec<_>=tech.cells.iter().enumerate().filter(|(_,c)|!c.vars.is_empty()&&c.vars.len()<=9&&tech.cells.iter().filter(|x|x.name==c.name).count()==1).map(|(i,c)|(i,c,patterns(c))).collect();audit.cells=rules.len();audit.patterns=rules.iter().map(|(_,_,p)|p.len()).sum();
 audit.post_import_allowance=std::env::var("EGM_SEARCH_NODE_ALLOWANCE").ok().and_then(|v|v.parse::<usize>().ok()).unwrap_or(ps.saturation.node_limit);
 let mut remaining=audit.work_limit;
 for _ in 0..audit.iteration_limit {
  // Search only a clean graph; matches for this round are bounded before mutation.
  let mut pending=Vec::new();let n=rules.iter().map(|(_,_,p)|p.len()).sum::<usize>();let mut left=n;
  for (i,cell,patterns) in &rules {for p in patterns {
   if remaining==0{break}let quota=(remaining/left.max(1)).max(1).min(ps.max_instances.saturating_sub(pending.len()));if quota==0 {remaining=0;break}left=left.saturating_sub(1);audit.search_calls+=1;
   let found=p.search_with_limit(graph,quota);let got:usize=found.iter().map(|x|x.substs.len()).sum();audit.matches+=got;*audit.matches_by_cell.entry(cell.name.clone()).or_default()+=got;remaining=remaining.saturating_sub(got.max(1));
   for found in found {for subst in found.substs {let inputs:Option<Vec<_>>=(0..cell.vars.len()).map(|v|subst.get(format!("?i{v}").parse().unwrap()).copied().or_else(||graph.lookup(AigLang::Zero))).collect();if let Some(inputs)=inputs {pending.push((found.eclass,AigLang::Cell(format!("{PREFIX}{i}").into(),inputs)));}}}
  }}
  let before=admission.lock().unwrap().admitted();let mut changed=false;
  for (target,node) in pending {let mut ledger=admission.lock().unwrap();if ledger.admitted().saturating_sub(imported)>=audit.post_import_allowance && graph.lookup(node.clone()).is_none(){audit.budget_rejected+=1;continue}match ledger.add(graph,node){Some(id)=>{changed|=graph.union(target,id);},None=>audit.budget_rejected+=1}}
  graph.rebuild();let after=admission.lock().unwrap().admitted();audit.added_nodes+=after-before;audit.rounds+=1;
  if !changed||remaining==0{break}
 }
 audit.post_import_used=admission.lock().unwrap().admitted().saturating_sub(imported);audit.work_used=audit.work_limit-remaining;audit.exhausted=remaining==0;audit.secs=start.elapsed().as_secs_f64();audit
}
pub(super) fn generate(graph:&egg::EGraph<AigLang,()>,ids:&HashMap<Id,usize>,tech:&TechLib,ps:&MapParams,free:&[bool],aliases:Option<(&[usize],&[bool])>,pool:&mut Vec<Instance>,audit:&mut Audit){
 let mut index:HashMap<_,_>=pool.iter().enumerate().map(|(i,m)|(instance_key(m),i)).collect();let before=pool.len();
 for class in graph.classes(){for node in &class.nodes {let AigLang::Cell(sym,args)=node else{continue};let Some(i)=sym.as_str().strip_prefix(PREFIX).and_then(|s|s.parse::<usize>().ok())else{continue};let cell=&tech.cells[i];let target=ids[&graph.find(class.id)]*2;
  if free[target] {continue}let inputs:Vec<_>=args.iter().map(|id|ids[&graph.find(*id)]*2).collect();if inputs.iter().any(|s|s/2==target/2){continue}
  let s=wide::support(cell);let mut m=Instance{cell:cell.name.clone(),area:cell.area,inputs,input_pins:cell.vars.clone().into(),outputs:vec![OutputPin{wide_function:Some(Box::new(wide::PhysicalFunction{positions:s.positions,truth:s.truth})),sources:vec![],name:cell.out_pin.clone(),delays:cell.vars.iter().map(|p|cell.pin_delay.get(p).copied().unwrap_or(0.)).collect::<Vec<_>>().into(),function:cell.tt[0],targets:vec![target]}]};
  if ps.protected_exchange {exchange::record_wide(&mut m,aliases);}if let Some((a,f))=aliases {if !normalize_physical_instance(&mut m,a,f){continue}}
  let old=pool.len();insert_instance(pool,&mut index,m);if pool.len()>old{*audit.generated_by_cell.entry(cell.name.clone()).or_default()+=1;}
 }}audit.generated=pool.len()-before;
}
#[cfg(test)]mod tests{
 use super::*;
 #[test]fn library_nodes_have_reserved_namespace(){assert!(physical(&AigLang::Cell("@egm_library_cell_2".into(),vec![])));assert!(!physical(&AigLang::Cell("@egm_tt3_80".into(),vec![])));}
 #[test]fn compact_pattern_uses_exact_truth(){let p=wide::Pattern::And(Box::new(wide::Pattern::Var(0)),Box::new(wide::Pattern::And(Box::new(wide::Pattern::Var(1)),Box::new(wide::Pattern::Var(2)))));assert!(variants(&p).iter().any(|p|p=="(@egm_tt3_80 ?i0 ?i1 ?i2)"));}
 #[test]fn one_way_stage_counts_cells_and_never_selects_them_as_logic_witness(){let tech=TechLib::from_genlib(std::path::Path::new(env!("CARGO_MANIFEST_DIR")).join("tests/fixtures/egraph_map.genlib"),6).unwrap();let mut g=egg::EGraph::default();let mut ledger=crate::egraph_budget::NodeAdmission::new(100);let a=ledger.add(&mut g,AigLang::Pi(0)).unwrap();let b=ledger.add(&mut g,AigLang::Pi(1)).unwrap();let root=ledger.add(&mut g,AigLang::And([a,b])).unwrap();g.rebuild();
 let ledger=std::sync::Arc::new(std::sync::Mutex::new(ledger));let ps=MapParams::default();let audit=saturate(&mut g,&ledger,&tech,&ps,0,3);assert!(audit.added_nodes>0);assert!(g[root].nodes.iter().any(physical));let witnesses=cheapest_nodes_queued(&g);assert!(!physical(&witnesses[&g.find(root)]));assert_eq!(ledger.lock().unwrap().admitted(),3+audit.added_nodes);}
}

#[cfg(test)]mod semantic_tests{
 use super::*;
 fn eval(p:&egg::Pattern<AigLang>,a:usize)->bool {let mut v:Vec<bool>=Vec::new();for entry in p.ast.as_ref(){let x=match entry {egg::ENodeOrVar::Var(x)=>{let name=x.to_string();let i=name.strip_prefix("?i").unwrap().parse::<usize>().unwrap();a&(1<<i)!=0},egg::ENodeOrVar::ENode(n)=>match n {AigLang::Zero=>false,AigLang::One=>true,AigLang::Not(x)=>!v[usize::from(*x)],AigLang::And([x,y])=>v[usize::from(*x)]&&v[usize::from(*y)],_=>{if let Some((x,y,phase))=literal_inputs(n){(v[usize::from(x)]^(phase&1!=0))&&(v[usize::from(y)]^(phase&2!=0))}else{let(args,tt)=tt3_inputs(n).expect("supported pattern node");let x=args.iter().enumerate().fold(0,|a,(i,x)|a|((v[usize::from(*x)]as usize)<<i));tt&(1<<x)!=0}}}};v.push(x);}*v.last().unwrap()}
 #[test]fn all_generated_library_patterns_equal_the_full_cell_truth(){let path=std::path::Path::new(env!("CARGO_MANIFEST_DIR")).join("../../asap7_full.genlib");let tech=TechLib::from_genlib_directed(path).unwrap();assert_eq!(tech.cells.len(),47);let mut count=0;for cell in &tech.cells {for p in patterns(cell){for a in 0..1usize<<cell.vars.len(){assert_eq!(eval(&p,a),crate::tt9::tt9_bit_get(&cell.tt,a),"{} {} assignment {}",cell.name,p,a);}count+=1;}}assert!(count>=47);}
 #[test]fn exhausted_node_budget_cannot_add_a_library_cell(){let tech=TechLib::from_genlib(std::path::Path::new(env!("CARGO_MANIFEST_DIR")).join("tests/fixtures/egraph_map.genlib"),6).unwrap();let mut g=egg::EGraph::default();let mut b=crate::egraph_budget::NodeAdmission::new(3);let a=b.add(&mut g,AigLang::Pi(0)).unwrap();let c=b.add(&mut g,AigLang::Pi(1)).unwrap();b.add(&mut g,AigLang::And([a,c])).unwrap();g.rebuild();let b=std::sync::Arc::new(std::sync::Mutex::new(b));let audit=saturate(&mut g,&b,&tech,&MapParams::default(),0,3);assert_eq!(audit.added_nodes,0);assert!(audit.budget_rejected>0);assert_eq!(b.lock().unwrap().admitted(),3);}
 #[test]fn no_remaining_saturation_rounds_means_no_second_stage(){let mut g=egg::EGraph::default();let b=std::sync::Arc::new(std::sync::Mutex::new(crate::egraph_budget::NodeAdmission::new(10)));let ps=MapParams::default();let audit=saturate(&mut g,&b,&TechLib::default(),&ps,ps.saturation.iter_limit,0);assert_eq!(audit.rounds,0);assert_eq!(audit.added_nodes,0);}
}

#[cfg(test)]mod construction_cost_tests{use super::*;#[test]fn nested_demorgan_pattern_construction_is_linear_in_tree_visits(){use wide::Pattern::*;let mut p=Var(0);for i in 1..7 {p=Not(Box::new(And(Box::new(Not(Box::new(p))),Box::new(Not(Box::new(Var(i)))))));}VARIANT_CALLS.with(|v|v.set(0));let _=variants(&p);let calls=VARIANT_CALLS.with(|v|v.get());assert!(calls<=100,"repeated subtree reconstruction: {calls} calls for a 37-node tree");}}

#[cfg(test)]mod aig_phase_pattern_tests {use super::*;#[test]fn library_double_inversion_is_normalized_like_an_aig_edge(){use wide::Pattern::*;let p=Not(Box::new(Not(Box::new(And(Box::new(Var(0)),Box::new(Var(1)))))));assert_eq!(plain(&normalize(p)),"(& ?i0 ?i1)");}}

#[cfg(test)]mod strict_extra_budget_test {use super::*;#[test]#[ignore="run with EGM_SEARCH_NODE_ALLOWANCE=1"]fn independent_search_allowance_is_not_unused_input_capacity(){assert_eq!(std::env::var("EGM_SEARCH_NODE_ALLOWANCE").unwrap(),"1");let tech=TechLib::from_genlib(std::path::Path::new(env!("CARGO_MANIFEST_DIR")).join("tests/fixtures/egraph_map.genlib"),6).unwrap();let mut g=egg::EGraph::default();let mut b=crate::egraph_budget::NodeAdmission::new(100);let a=b.add(&mut g,AigLang::Pi(0)).unwrap();let c=b.add(&mut g,AigLang::Pi(1)).unwrap();b.add(&mut g,AigLang::And([a,c])).unwrap();g.rebuild();let b=std::sync::Arc::new(std::sync::Mutex::new(b));let audit=saturate(&mut g,&b,&tech,&MapParams::default(),0,3);assert_eq!(audit.added_nodes,1);assert!(audit.budget_rejected>0);assert_eq!(audit.post_import_used,1);assert_eq!(b.lock().unwrap().admitted(),4);}}
