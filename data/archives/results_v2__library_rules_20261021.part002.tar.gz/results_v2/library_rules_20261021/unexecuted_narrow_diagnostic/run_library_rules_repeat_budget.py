"""Four-way target repeats; profile3 is an explicit small-cuts-only diagnostic."""
import argparse,sys
import run_library_rules_strict_budget as primary
import run_library_rules_narrow_budget as narrow

def main():
 ap=argparse.ArgumentParser(add_help=False);ap.add_argument('--mode',choices=['library-rules'],required=True);ap.add_argument('--profile',type=int,choices=[0,1,2,3],required=True);a,rest=ap.parse_known_args()
 sys.argv=[__file__,'--mode',a.mode,'--profile',str(0 if a.profile==3 else a.profile),*rest]
 (narrow if a.profile==3 else primary).main()
if __name__=='__main__':main()
