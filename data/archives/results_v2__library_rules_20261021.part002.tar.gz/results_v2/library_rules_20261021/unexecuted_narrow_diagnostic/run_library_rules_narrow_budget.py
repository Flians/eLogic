"""Diagnostic small-cuts-only control: same frozen native, no directed wide and no library rules."""
import subprocess
from pathlib import Path
import run_library_rules_strict_budget as delegated

def main():
 original=subprocess.Popen.__init__
 def init(proc,argv,*args,**kwargs):
  if isinstance(argv,(list,tuple)) and argv and Path(str(argv[0])).name=='egraphmap_scaled.py':
   env=dict(kwargs['env']);env.update(EGM_WIDE_MATCH='0',EGM_LIBRARY_RULE_MODE='0');kwargs['env']=env
  return original(proc,argv,*args,**kwargs)
 # The delegated wrapper injects first, then calls this hook; the two disabled
 # matcher flags here are final. All other native configuration stays fixed.
 subprocess.Popen.__init__=init
 try:delegated.main()
 finally:subprocess.Popen.__init__=original
if __name__=='__main__':main()
