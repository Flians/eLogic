// Benchmark "/home/flynn/workplace/MIGBalance/results_v2/eqmap_adapter_3in_verified_20261007/c880/lut_stage_amap/stage" written by ABC on Wed Oct  7 16:32:05 2026

module \/home/flynn/workplace/MIGBalance/results_v2/eqmap_adapter_3in_verified_20261007/c880/lut_stage_amap/stage  ( 
    G1, G10, G11, G12, G13, G14, G15, G16, G17, G18, G19, G2, G20, G21,
    G22, G23, G24, G25, G26, G27, G28, G29, G3, G30, G31, G32, G33, G34,
    G35, G36, G37, G38, G39, G4, G40, G41, G42, G43, G44, G45, G46, G47,
    G48, G49, G5, G50, G51, G52, G53, G54, G55, G56, G57, G58, G59, G6,
    G60, G7, G8, G9,
    G855, G856, G857, G858, G859, G860, G861, G862, G863, G864, G865, G866,
    G867, G868, G869, G870, G871, G872, G873, G874, G875, G876, G877, G878,
    G879, G880  );
  input  G1, G10, G11, G12, G13, G14, G15, G16, G17, G18, G19, G2, G20,
    G21, G22, G23, G24, G25, G26, G27, G28, G29, G3, G30, G31, G32, G33,
    G34, G35, G36, G37, G38, G39, G4, G40, G41, G42, G43, G44, G45, G46,
    G47, G48, G49, G5, G50, G51, G52, G53, G54, G55, G56, G57, G58, G59,
    G6, G60, G7, G8, G9;
  output G855, G856, G857, G858, G859, G860, G861, G862, G863, G864, G865,
    G866, G867, G868, G869, G870, G871, G872, G873, G874, G875, G876, G877,
    G878, G879, G880;
  wire new_n87_, new_n88_, new_n89_, new_n90_, new_n91_, new_n92_, new_n93_,
    new_n94_, new_n95_, new_n96_, new_n97_, new_n98_, new_n99_, new_n100_,
    new_n101_, new_n102_, new_n103_, new_n104_, new_n105_, new_n106_,
    new_n107_, new_n108_, new_n109_, new_n110_, new_n111_, new_n112_,
    new_n113_, new_n114_, new_n115_, new_n116_, new_n117_, new_n118_,
    new_n119_, new_n120_, new_n122_, new_n125_, new_n127_, new_n128_,
    new_n129_, new_n131_, new_n135_, new_n137_, new_n140_, new_n142_,
    new_n143_, new_n145_, new_n146_, new_n147_, new_n150_, new_n151_,
    new_n152_, new_n153_, new_n154_, new_n155_, new_n156_, new_n157_,
    new_n158_, new_n159_, new_n160_, new_n161_, new_n162_, new_n163_,
    new_n164_, new_n165_, new_n167_, new_n168_, new_n169_, new_n170_,
    new_n171_, new_n172_, new_n173_, new_n174_, new_n175_, new_n176_,
    new_n177_, new_n178_, new_n179_, new_n180_, new_n181_, new_n182_,
    new_n184_, new_n185_, new_n186_, new_n187_, new_n188_, new_n189_,
    new_n190_, new_n191_, new_n192_, new_n193_, new_n194_, new_n195_,
    new_n196_, new_n197_, new_n198_, new_n199_, new_n200_, new_n201_,
    new_n202_, new_n203_, new_n204_, new_n205_, new_n206_, new_n207_,
    new_n208_, new_n209_, new_n210_, new_n211_, new_n212_, new_n213_,
    new_n214_, new_n215_, new_n216_, new_n217_, new_n218_, new_n219_,
    new_n221_, new_n222_, new_n223_, new_n224_, new_n225_, new_n226_,
    new_n227_, new_n228_, new_n229_, new_n230_, new_n231_, new_n232_,
    new_n233_, new_n234_, new_n235_, new_n236_, new_n237_, new_n238_,
    new_n239_, new_n240_, new_n241_, new_n242_, new_n243_, new_n244_,
    new_n245_, new_n246_, new_n247_, new_n248_, new_n249_, new_n250_,
    new_n251_, new_n252_, new_n253_, new_n254_, new_n255_, new_n256_,
    new_n257_, new_n259_, new_n260_, new_n261_, new_n262_, new_n263_,
    new_n264_, new_n265_, new_n266_, new_n267_, new_n268_, new_n269_,
    new_n270_, new_n271_, new_n273_, new_n274_, new_n275_, new_n276_,
    new_n277_, new_n278_, new_n279_, new_n280_, new_n281_, new_n282_,
    new_n284_, new_n285_, new_n286_, new_n287_, new_n288_, new_n289_,
    new_n290_, new_n291_, new_n292_, new_n293_, new_n294_, new_n295_,
    new_n296_, new_n297_, new_n298_, new_n299_, new_n300_, new_n301_,
    new_n302_, new_n303_, new_n304_, new_n305_, new_n306_, new_n307_,
    new_n308_, new_n309_, new_n310_, new_n311_, new_n312_, new_n313_,
    new_n314_, new_n315_, new_n316_, new_n317_, new_n318_, new_n319_,
    new_n320_, new_n322_, new_n323_, new_n324_, new_n325_, new_n326_,
    new_n327_, new_n328_, new_n329_, new_n330_, new_n331_, new_n332_,
    new_n334_, new_n335_, new_n336_, new_n337_, new_n338_, new_n339_,
    new_n340_, new_n341_, new_n342_, new_n343_, new_n345_, new_n346_,
    new_n347_, new_n348_, new_n349_, new_n350_, new_n351_, new_n352_,
    new_n353_, new_n354_, new_n356_, new_n357_, new_n358_, new_n359_,
    new_n360_, new_n361_, new_n362_, new_n363_, new_n364_, new_n365_;
  INVx1_ASAP7_75t_R   g000(.A(G1), .Y(new_n87_));
  INVx1_ASAP7_75t_R   g001(.A(G10), .Y(new_n88_));
  INVx1_ASAP7_75t_R   g002(.A(G11), .Y(new_n89_));
  INVx1_ASAP7_75t_R   g003(.A(G12), .Y(new_n90_));
  INVx1_ASAP7_75t_R   g004(.A(G15), .Y(new_n91_));
  INVx1_ASAP7_75t_R   g005(.A(G16), .Y(new_n92_));
  INVx1_ASAP7_75t_R   g006(.A(G17), .Y(new_n93_));
  INVx1_ASAP7_75t_R   g007(.A(G18), .Y(new_n94_));
  INVx1_ASAP7_75t_R   g008(.A(G22), .Y(new_n95_));
  INVx1_ASAP7_75t_R   g009(.A(G23), .Y(new_n96_));
  INVx1_ASAP7_75t_R   g010(.A(G26), .Y(new_n97_));
  INVx1_ASAP7_75t_R   g011(.A(G28), .Y(new_n98_));
  INVx1_ASAP7_75t_R   g012(.A(G3), .Y(new_n99_));
  INVx1_ASAP7_75t_R   g013(.A(G30), .Y(new_n100_));
  INVx1_ASAP7_75t_R   g014(.A(G34), .Y(new_n101_));
  INVx1_ASAP7_75t_R   g015(.A(G4), .Y(new_n102_));
  INVx1_ASAP7_75t_R   g016(.A(G41), .Y(new_n103_));
  INVx1_ASAP7_75t_R   g017(.A(G42), .Y(new_n104_));
  INVx1_ASAP7_75t_R   g018(.A(G43), .Y(new_n105_));
  INVx1_ASAP7_75t_R   g019(.A(G44), .Y(new_n106_));
  INVx1_ASAP7_75t_R   g020(.A(G45), .Y(new_n107_));
  INVx1_ASAP7_75t_R   g021(.A(G46), .Y(new_n108_));
  INVx1_ASAP7_75t_R   g022(.A(G48), .Y(new_n109_));
  INVx1_ASAP7_75t_R   g023(.A(G5), .Y(new_n110_));
  INVx1_ASAP7_75t_R   g024(.A(G50), .Y(new_n111_));
  INVx1_ASAP7_75t_R   g025(.A(G51), .Y(new_n112_));
  INVx1_ASAP7_75t_R   g026(.A(G53), .Y(new_n113_));
  INVx1_ASAP7_75t_R   g027(.A(G54), .Y(new_n114_));
  INVx1_ASAP7_75t_R   g028(.A(G55), .Y(new_n115_));
  INVx1_ASAP7_75t_R   g029(.A(G6), .Y(new_n116_));
  INVx1_ASAP7_75t_R   g030(.A(G7), .Y(new_n117_));
  INVx1_ASAP7_75t_R   g031(.A(G8), .Y(new_n118_));
  INVx1_ASAP7_75t_R   g032(.A(G9), .Y(new_n119_));
  AO21x1_ASAP7_75t_R  g033(.A1(G6), .A2(new_n118_), .B(new_n116_), .Y(new_n120_));
  AO21x1_ASAP7_75t_R  g034(.A1(G16), .A2(new_n120_), .B(new_n92_), .Y(G855));
  AO21x1_ASAP7_75t_R  g035(.A1(new_n93_), .A2(G6), .B(new_n116_), .Y(new_n122_));
  AO21x1_ASAP7_75t_R  g036(.A1(G7), .A2(new_n122_), .B(new_n117_), .Y(G856));
  AO21x1_ASAP7_75t_R  g037(.A1(G7), .A2(new_n120_), .B(new_n117_), .Y(G857));
  INVx1_ASAP7_75t_R   g038(.A(G857), .Y(new_n125_));
  OAI21x1_ASAP7_75t_R g039(.A1(new_n94_), .A2(G19), .B(G18), .Y(G858));
  NOR2x1_ASAP7_75t_R  g040(.A(new_n99_), .B(new_n102_), .Y(new_n127_));
  INVx1_ASAP7_75t_R   g041(.A(new_n127_), .Y(new_n128_));
  NAND2x1_ASAP7_75t_R g042(.A(G1), .B(G2), .Y(new_n129_));
  AO21x1_ASAP7_75t_R  g043(.A1(new_n127_), .A2(new_n129_), .B(new_n128_), .Y(G859));
  OR3x1_ASAP7_75t_R   g044(.A(new_n87_), .B(new_n128_), .C(new_n110_), .Y(new_n131_));
  NOR2x1_ASAP7_75t_R  g045(.A(new_n125_), .B(new_n131_), .Y(G860));
  AND3x1_ASAP7_75t_R  g046(.A(G11), .B(G17), .C(G16), .Y(G861));
  AND3x1_ASAP7_75t_R  g047(.A(G11), .B(G17), .C(G7), .Y(G862));
  NOR2x1_ASAP7_75t_R  g048(.A(new_n89_), .B(new_n118_), .Y(new_n135_));
  AND3x1_ASAP7_75t_R  g049(.A(G11), .B(G8), .C(G7), .Y(G863));
  NOR2x1_ASAP7_75t_R  g050(.A(G20), .B(G21), .Y(new_n137_));
  AO21x1_ASAP7_75t_R  g051(.A1(G23), .A2(new_n137_), .B(new_n96_), .Y(G864));
  NOR2x1_ASAP7_75t_R  g052(.A(G857), .B(new_n131_), .Y(G865));
  AO21x1_ASAP7_75t_R  g053(.A1(new_n87_), .A2(G9), .B(new_n119_), .Y(new_n140_));
  AO21x1_ASAP7_75t_R  g054(.A1(G5), .A2(new_n140_), .B(new_n110_), .Y(G866));
  OR3x1_ASAP7_75t_R   g055(.A(new_n88_), .B(new_n129_), .C(new_n99_), .Y(new_n142_));
  AO21x1_ASAP7_75t_R  g056(.A1(G12), .A2(new_n142_), .B(new_n90_), .Y(new_n143_));
  AO21x1_ASAP7_75t_R  g057(.A1(G6), .A2(new_n143_), .B(new_n116_), .Y(G867));
  NOR2x1_ASAP7_75t_R  g058(.A(new_n89_), .B(new_n90_), .Y(new_n145_));
  INVx1_ASAP7_75t_R   g059(.A(new_n145_), .Y(new_n146_));
  AO21x1_ASAP7_75t_R  g060(.A1(new_n142_), .A2(new_n145_), .B(new_n146_), .Y(new_n147_));
  AO21x1_ASAP7_75t_R  g061(.A1(G15), .A2(new_n147_), .B(new_n91_), .Y(G868));
  AO21x1_ASAP7_75t_R  g062(.A1(G22), .A2(new_n137_), .B(new_n95_), .Y(G869));
  XNOR2x2_ASAP7_75t_R g063(.A(new_n98_), .B(G29), .Y(new_n150_));
  XOR2x2_ASAP7_75t_R  g064(.A(G28), .B(G29), .Y(new_n151_));
  NOR2x1_ASAP7_75t_R  g065(.A(G33), .B(new_n151_), .Y(new_n152_));
  AO21x1_ASAP7_75t_R  g066(.A1(G33), .A2(new_n150_), .B(new_n152_), .Y(new_n153_));
  XNOR2x2_ASAP7_75t_R g067(.A(G26), .B(G32), .Y(new_n154_));
  NAND2x1_ASAP7_75t_R g068(.A(G25), .B(new_n154_), .Y(new_n155_));
  XOR2x2_ASAP7_75t_R  g069(.A(new_n97_), .B(G32), .Y(new_n156_));
  OA21x2_ASAP7_75t_R  g070(.A1(G25), .A2(new_n156_), .B(new_n155_), .Y(new_n157_));
  XNOR2x2_ASAP7_75t_R g071(.A(G24), .B(G27), .Y(new_n158_));
  XOR2x2_ASAP7_75t_R  g072(.A(G31), .B(new_n158_), .Y(new_n159_));
  XOR2x2_ASAP7_75t_R  g073(.A(G31), .B(new_n158_), .Y(new_n160_));
  NOR2x1_ASAP7_75t_R  g074(.A(G30), .B(new_n160_), .Y(new_n161_));
  AO21x1_ASAP7_75t_R  g075(.A1(G30), .A2(new_n159_), .B(new_n161_), .Y(new_n162_));
  XOR2x2_ASAP7_75t_R  g076(.A(new_n157_), .B(new_n162_), .Y(new_n163_));
  XOR2x2_ASAP7_75t_R  g077(.A(new_n157_), .B(new_n162_), .Y(new_n164_));
  NOR2x1_ASAP7_75t_R  g078(.A(new_n153_), .B(new_n164_), .Y(new_n165_));
  AO21x1_ASAP7_75t_R  g079(.A1(new_n153_), .A2(new_n163_), .B(new_n165_), .Y(G870));
  XNOR2x2_ASAP7_75t_R g080(.A(new_n103_), .B(G42), .Y(new_n167_));
  XOR2x2_ASAP7_75t_R  g081(.A(new_n103_), .B(new_n104_), .Y(new_n168_));
  NOR2x1_ASAP7_75t_R  g082(.A(G32), .B(new_n168_), .Y(new_n169_));
  AO21x1_ASAP7_75t_R  g083(.A1(G32), .A2(new_n167_), .B(new_n169_), .Y(new_n170_));
  XNOR2x2_ASAP7_75t_R g084(.A(new_n107_), .B(new_n108_), .Y(new_n171_));
  NAND2x1_ASAP7_75t_R g085(.A(G49), .B(new_n171_), .Y(new_n172_));
  XOR2x2_ASAP7_75t_R  g086(.A(new_n107_), .B(G46), .Y(new_n173_));
  OA21x2_ASAP7_75t_R  g087(.A1(G49), .A2(new_n173_), .B(new_n172_), .Y(new_n174_));
  XOR2x2_ASAP7_75t_R  g088(.A(G47), .B(new_n109_), .Y(new_n175_));
  XNOR2x2_ASAP7_75t_R g089(.A(new_n106_), .B(new_n175_), .Y(new_n176_));
  XOR2x2_ASAP7_75t_R  g090(.A(G44), .B(new_n175_), .Y(new_n177_));
  NOR2x1_ASAP7_75t_R  g091(.A(G43), .B(new_n177_), .Y(new_n178_));
  AO21x1_ASAP7_75t_R  g092(.A1(G43), .A2(new_n176_), .B(new_n178_), .Y(new_n179_));
  XOR2x2_ASAP7_75t_R  g093(.A(new_n174_), .B(new_n179_), .Y(new_n180_));
  XOR2x2_ASAP7_75t_R  g094(.A(new_n174_), .B(new_n179_), .Y(new_n181_));
  NOR2x1_ASAP7_75t_R  g095(.A(new_n170_), .B(new_n181_), .Y(new_n182_));
  AO21x1_ASAP7_75t_R  g096(.A1(new_n170_), .A2(new_n180_), .B(new_n182_), .Y(G871));
  OR3x1_ASAP7_75t_R   g097(.A(new_n93_), .B(new_n116_), .C(new_n92_), .Y(new_n184_));
  OR2x4_ASAP7_75t_R   g098(.A(G866), .B(new_n184_), .Y(new_n185_));
  OR3x1_ASAP7_75t_R   g099(.A(new_n88_), .B(G60), .C(new_n185_), .Y(new_n186_));
  INVx1_ASAP7_75t_R   g100(.A(new_n186_), .Y(new_n187_));
  AO21x1_ASAP7_75t_R  g101(.A1(G16), .A2(new_n135_), .B(new_n129_), .Y(new_n188_));
  OR3x1_ASAP7_75t_R   g102(.A(new_n102_), .B(new_n119_), .C(new_n188_), .Y(new_n189_));
  INVx1_ASAP7_75t_R   g103(.A(new_n189_), .Y(new_n190_));
  XNOR2x2_ASAP7_75t_R g104(.A(new_n102_), .B(new_n118_), .Y(new_n191_));
  NOR2x1_ASAP7_75t_R  g105(.A(G866), .B(new_n191_), .Y(new_n192_));
  AND3x1_ASAP7_75t_R  g106(.A(G11), .B(G40), .C(new_n192_), .Y(new_n193_));
  AO21x1_ASAP7_75t_R  g107(.A1(new_n189_), .A2(new_n193_), .B(new_n190_), .Y(new_n194_));
  AO21x1_ASAP7_75t_R  g108(.A1(G11), .A2(G40), .B(G866), .Y(new_n195_));
  NOR2x1_ASAP7_75t_R  g109(.A(new_n102_), .B(new_n195_), .Y(new_n196_));
  INVx1_ASAP7_75t_R   g110(.A(new_n196_), .Y(new_n197_));
  AO21x1_ASAP7_75t_R  g111(.A1(new_n87_), .A2(new_n197_), .B(new_n196_), .Y(new_n198_));
  AND2x2_ASAP7_75t_R  g112(.A(G39), .B(new_n198_), .Y(new_n199_));
  AO21x1_ASAP7_75t_R  g113(.A1(G31), .A2(new_n194_), .B(new_n199_), .Y(new_n200_));
  NOR2x1_ASAP7_75t_R  g114(.A(new_n187_), .B(new_n200_), .Y(new_n201_));
  INVx1_ASAP7_75t_R   g115(.A(new_n201_), .Y(new_n202_));
  XOR2x2_ASAP7_75t_R  g116(.A(G48), .B(new_n202_), .Y(new_n203_));
  INVx1_ASAP7_75t_R   g117(.A(new_n203_), .Y(new_n204_));
  XNOR2x2_ASAP7_75t_R g118(.A(G58), .B(new_n203_), .Y(new_n205_));
  AOI21x1_ASAP7_75t_R g119(.A1(G51), .A2(new_n205_), .B(new_n112_), .Y(new_n206_));
  OA21x2_ASAP7_75t_R  g120(.A1(G52), .A2(new_n204_), .B(new_n203_), .Y(new_n207_));
  OA21x2_ASAP7_75t_R  g121(.A1(new_n109_), .A2(G53), .B(G48), .Y(new_n208_));
  OR3x1_ASAP7_75t_R   g122(.A(G54), .B(new_n208_), .C(new_n201_), .Y(new_n209_));
  AND2x2_ASAP7_75t_R  g123(.A(new_n202_), .B(new_n209_), .Y(new_n210_));
  AO21x1_ASAP7_75t_R  g124(.A1(G55), .A2(G59), .B(new_n210_), .Y(new_n211_));
  OA21x2_ASAP7_75t_R  g125(.A1(new_n100_), .A2(G50), .B(G30), .Y(new_n212_));
  AND3x1_ASAP7_75t_R  g126(.A(G13), .B(G8), .C(G14), .Y(new_n213_));
  INVx1_ASAP7_75t_R   g127(.A(new_n213_), .Y(new_n214_));
  OR3x1_ASAP7_75t_R   g128(.A(new_n142_), .B(new_n146_), .C(new_n214_), .Y(new_n215_));
  INVx1_ASAP7_75t_R   g129(.A(new_n215_), .Y(new_n216_));
  OA21x2_ASAP7_75t_R  g130(.A1(new_n109_), .A2(new_n216_), .B(G48), .Y(new_n217_));
  OR3x1_ASAP7_75t_R   g131(.A(new_n211_), .B(new_n212_), .C(new_n217_), .Y(new_n218_));
  OR3x1_ASAP7_75t_R   g132(.A(new_n206_), .B(new_n207_), .C(new_n218_), .Y(new_n219_));
  INVx1_ASAP7_75t_R   g133(.A(new_n219_), .Y(G872));
  NOR2x1_ASAP7_75t_R  g134(.A(new_n87_), .B(new_n196_), .Y(new_n221_));
  INVx1_ASAP7_75t_R   g135(.A(new_n221_), .Y(new_n222_));
  OA21x2_ASAP7_75t_R  g136(.A1(G35), .A2(new_n221_), .B(new_n222_), .Y(new_n223_));
  NOR2x1_ASAP7_75t_R  g137(.A(new_n190_), .B(new_n193_), .Y(new_n224_));
  INVx1_ASAP7_75t_R   g138(.A(new_n224_), .Y(new_n225_));
  OA21x2_ASAP7_75t_R  g139(.A1(G28), .A2(new_n224_), .B(new_n225_), .Y(new_n226_));
  OR3x1_ASAP7_75t_R   g140(.A(new_n187_), .B(new_n223_), .C(new_n226_), .Y(new_n227_));
  INVx1_ASAP7_75t_R   g141(.A(new_n227_), .Y(new_n228_));
  OA21x2_ASAP7_75t_R  g142(.A1(new_n107_), .A2(G53), .B(G45), .Y(new_n229_));
  OR3x1_ASAP7_75t_R   g143(.A(G54), .B(new_n229_), .C(new_n228_), .Y(new_n230_));
  AND2x2_ASAP7_75t_R  g144(.A(new_n227_), .B(new_n230_), .Y(new_n231_));
  AO21x1_ASAP7_75t_R  g145(.A1(G27), .A2(G50), .B(new_n231_), .Y(new_n232_));
  OA21x2_ASAP7_75t_R  g146(.A1(G45), .A2(new_n215_), .B(new_n216_), .Y(new_n233_));
  XOR2x2_ASAP7_75t_R  g147(.A(new_n107_), .B(new_n227_), .Y(new_n234_));
  INVx1_ASAP7_75t_R   g148(.A(new_n234_), .Y(new_n235_));
  OA21x2_ASAP7_75t_R  g149(.A1(G52), .A2(new_n234_), .B(new_n235_), .Y(new_n236_));
  OR3x1_ASAP7_75t_R   g150(.A(new_n232_), .B(new_n233_), .C(new_n236_), .Y(new_n237_));
  OA21x2_ASAP7_75t_R  g151(.A1(G36), .A2(new_n221_), .B(new_n222_), .Y(new_n238_));
  OA21x2_ASAP7_75t_R  g152(.A1(G29), .A2(new_n224_), .B(new_n225_), .Y(new_n239_));
  OR3x1_ASAP7_75t_R   g153(.A(new_n187_), .B(new_n238_), .C(new_n239_), .Y(new_n240_));
  INVx1_ASAP7_75t_R   g154(.A(new_n240_), .Y(new_n241_));
  AO21x1_ASAP7_75t_R  g155(.A1(G37), .A2(new_n198_), .B(new_n187_), .Y(new_n242_));
  AO21x1_ASAP7_75t_R  g156(.A1(G30), .A2(new_n194_), .B(new_n242_), .Y(new_n243_));
  NAND2x1_ASAP7_75t_R g157(.A(G47), .B(new_n243_), .Y(new_n244_));
  INVx1_ASAP7_75t_R   g158(.A(new_n244_), .Y(new_n245_));
  OR2x4_ASAP7_75t_R   g159(.A(G47), .B(new_n243_), .Y(new_n246_));
  AO21x1_ASAP7_75t_R  g160(.A1(new_n109_), .A2(new_n202_), .B(G48), .Y(new_n247_));
  OR3x1_ASAP7_75t_R   g161(.A(new_n109_), .B(new_n201_), .C(G58), .Y(new_n248_));
  INVx1_ASAP7_75t_R   g162(.A(new_n248_), .Y(new_n249_));
  AOI21x1_ASAP7_75t_R g163(.A1(G58), .A2(new_n247_), .B(new_n249_), .Y(new_n250_));
  NAND2x1_ASAP7_75t_R g164(.A(new_n246_), .B(new_n250_), .Y(new_n251_));
  AO21x1_ASAP7_75t_R  g165(.A1(new_n246_), .A2(new_n251_), .B(new_n245_), .Y(new_n252_));
  OAI21x1_ASAP7_75t_R g166(.A1(new_n108_), .A2(new_n252_), .B(G46), .Y(new_n253_));
  OR3x1_ASAP7_75t_R   g167(.A(G46), .B(new_n252_), .C(new_n241_), .Y(new_n254_));
  INVx1_ASAP7_75t_R   g168(.A(new_n254_), .Y(new_n255_));
  AO21x1_ASAP7_75t_R  g169(.A1(new_n241_), .A2(new_n253_), .B(new_n255_), .Y(new_n256_));
  XNOR2x2_ASAP7_75t_R g170(.A(new_n235_), .B(new_n256_), .Y(new_n257_));
  AOI21x1_ASAP7_75t_R g171(.A1(G51), .A2(new_n257_), .B(new_n237_), .Y(G873));
  XOR2x2_ASAP7_75t_R  g172(.A(G46), .B(new_n240_), .Y(new_n259_));
  INVx1_ASAP7_75t_R   g173(.A(new_n259_), .Y(new_n260_));
  XNOR2x2_ASAP7_75t_R g174(.A(new_n252_), .B(new_n259_), .Y(new_n261_));
  AOI21x1_ASAP7_75t_R g175(.A1(G51), .A2(new_n261_), .B(new_n112_), .Y(new_n262_));
  OA21x2_ASAP7_75t_R  g176(.A1(G52), .A2(new_n260_), .B(new_n259_), .Y(new_n263_));
  OA21x2_ASAP7_75t_R  g177(.A1(new_n108_), .A2(G53), .B(G46), .Y(new_n264_));
  OR3x1_ASAP7_75t_R   g178(.A(G54), .B(new_n264_), .C(new_n241_), .Y(new_n265_));
  AND2x2_ASAP7_75t_R  g179(.A(new_n240_), .B(new_n265_), .Y(new_n266_));
  AO21x1_ASAP7_75t_R  g180(.A1(G55), .A2(G56), .B(new_n266_), .Y(new_n267_));
  OA21x2_ASAP7_75t_R  g181(.A1(new_n98_), .A2(G50), .B(G28), .Y(new_n268_));
  OA21x2_ASAP7_75t_R  g182(.A1(new_n108_), .A2(new_n216_), .B(G46), .Y(new_n269_));
  OR3x1_ASAP7_75t_R   g183(.A(new_n267_), .B(new_n268_), .C(new_n269_), .Y(new_n270_));
  OR3x1_ASAP7_75t_R   g184(.A(new_n262_), .B(new_n263_), .C(new_n270_), .Y(new_n271_));
  INVx1_ASAP7_75t_R   g185(.A(new_n271_), .Y(G874));
  OA21x2_ASAP7_75t_R  g186(.A1(G47), .A2(new_n215_), .B(new_n216_), .Y(new_n273_));
  AO21x1_ASAP7_75t_R  g187(.A1(G54), .A2(new_n243_), .B(new_n273_), .Y(new_n274_));
  OA21x2_ASAP7_75t_R  g188(.A1(G53), .A2(new_n244_), .B(new_n245_), .Y(new_n275_));
  AO21x1_ASAP7_75t_R  g189(.A1(G29), .A2(G50), .B(new_n275_), .Y(new_n276_));
  OA21x2_ASAP7_75t_R  g190(.A1(new_n115_), .A2(G57), .B(G55), .Y(new_n277_));
  NAND2x1_ASAP7_75t_R g191(.A(new_n244_), .B(new_n246_), .Y(new_n278_));
  AND3x1_ASAP7_75t_R  g192(.A(new_n244_), .B(new_n246_), .C(G52), .Y(new_n279_));
  OR3x1_ASAP7_75t_R   g193(.A(new_n276_), .B(new_n277_), .C(new_n279_), .Y(new_n280_));
  NOR2x1_ASAP7_75t_R  g194(.A(new_n274_), .B(new_n280_), .Y(new_n281_));
  XNOR2x2_ASAP7_75t_R g195(.A(new_n250_), .B(new_n278_), .Y(new_n282_));
  OA21x2_ASAP7_75t_R  g196(.A1(new_n112_), .A2(new_n282_), .B(new_n281_), .Y(G875));
  OR3x1_ASAP7_75t_R   g197(.A(new_n102_), .B(G60), .C(new_n185_), .Y(new_n284_));
  INVx1_ASAP7_75t_R   g198(.A(new_n284_), .Y(new_n285_));
  OA21x2_ASAP7_75t_R  g199(.A1(G24), .A2(new_n224_), .B(new_n225_), .Y(new_n286_));
  NOR2x1_ASAP7_75t_R  g200(.A(new_n88_), .B(new_n195_), .Y(new_n287_));
  OA21x2_ASAP7_75t_R  g201(.A1(G2), .A2(new_n101_), .B(G34), .Y(new_n288_));
  AO21x1_ASAP7_75t_R  g202(.A1(G35), .A2(new_n287_), .B(new_n288_), .Y(new_n289_));
  OR3x1_ASAP7_75t_R   g203(.A(new_n285_), .B(new_n286_), .C(new_n289_), .Y(new_n290_));
  INVx1_ASAP7_75t_R   g204(.A(new_n290_), .Y(new_n291_));
  AND2x2_ASAP7_75t_R  g205(.A(G25), .B(new_n225_), .Y(new_n292_));
  AO21x1_ASAP7_75t_R  g206(.A1(G36), .A2(new_n287_), .B(new_n292_), .Y(new_n293_));
  AO21x1_ASAP7_75t_R  g207(.A1(G34), .A2(G9), .B(new_n293_), .Y(new_n294_));
  NOR2x1_ASAP7_75t_R  g208(.A(new_n285_), .B(new_n294_), .Y(new_n295_));
  INVx1_ASAP7_75t_R   g209(.A(new_n295_), .Y(new_n296_));
  NOR2x1_ASAP7_75t_R  g210(.A(new_n97_), .B(new_n224_), .Y(new_n297_));
  AO21x1_ASAP7_75t_R  g211(.A1(G37), .A2(new_n287_), .B(new_n297_), .Y(new_n298_));
  AO21x1_ASAP7_75t_R  g212(.A1(G34), .A2(G4), .B(new_n298_), .Y(new_n299_));
  NOR2x1_ASAP7_75t_R  g213(.A(new_n285_), .B(new_n299_), .Y(new_n300_));
  INVx1_ASAP7_75t_R   g214(.A(new_n300_), .Y(new_n301_));
  AND2x2_ASAP7_75t_R  g215(.A(G27), .B(new_n225_), .Y(new_n302_));
  AO21x1_ASAP7_75t_R  g216(.A1(G39), .A2(new_n287_), .B(new_n302_), .Y(new_n303_));
  AO21x1_ASAP7_75t_R  g217(.A1(G34), .A2(G38), .B(new_n303_), .Y(new_n304_));
  NOR2x1_ASAP7_75t_R  g218(.A(new_n285_), .B(new_n304_), .Y(new_n305_));
  INVx1_ASAP7_75t_R   g219(.A(new_n305_), .Y(new_n306_));
  AO21x1_ASAP7_75t_R  g220(.A1(G45), .A2(new_n256_), .B(new_n107_), .Y(new_n307_));
  AND3x1_ASAP7_75t_R  g221(.A(new_n107_), .B(new_n256_), .C(new_n227_), .Y(new_n308_));
  AO21x1_ASAP7_75t_R  g222(.A1(new_n228_), .A2(new_n307_), .B(new_n308_), .Y(new_n309_));
  AO21x1_ASAP7_75t_R  g223(.A1(G44), .A2(new_n309_), .B(new_n106_), .Y(new_n310_));
  AND3x1_ASAP7_75t_R  g224(.A(new_n106_), .B(new_n309_), .C(new_n306_), .Y(new_n311_));
  AO21x1_ASAP7_75t_R  g225(.A1(new_n305_), .A2(new_n310_), .B(new_n311_), .Y(new_n312_));
  AO21x1_ASAP7_75t_R  g226(.A1(G43), .A2(new_n312_), .B(new_n105_), .Y(new_n313_));
  AND3x1_ASAP7_75t_R  g227(.A(new_n105_), .B(new_n312_), .C(new_n301_), .Y(new_n314_));
  AO21x1_ASAP7_75t_R  g228(.A1(new_n300_), .A2(new_n313_), .B(new_n314_), .Y(new_n315_));
  AO21x1_ASAP7_75t_R  g229(.A1(G42), .A2(new_n315_), .B(new_n104_), .Y(new_n316_));
  AND3x1_ASAP7_75t_R  g230(.A(new_n104_), .B(new_n315_), .C(new_n296_), .Y(new_n317_));
  AO21x1_ASAP7_75t_R  g231(.A1(new_n295_), .A2(new_n316_), .B(new_n317_), .Y(new_n318_));
  AO21x1_ASAP7_75t_R  g232(.A1(G41), .A2(new_n318_), .B(new_n103_), .Y(new_n319_));
  AND3x1_ASAP7_75t_R  g233(.A(new_n103_), .B(new_n318_), .C(new_n290_), .Y(new_n320_));
  AO21x1_ASAP7_75t_R  g234(.A1(new_n291_), .A2(new_n319_), .B(new_n320_), .Y(G876));
  XNOR2x2_ASAP7_75t_R g235(.A(new_n106_), .B(new_n306_), .Y(new_n322_));
  OA21x2_ASAP7_75t_R  g236(.A1(G26), .A2(new_n111_), .B(G50), .Y(new_n323_));
  AO21x1_ASAP7_75t_R  g237(.A1(G52), .A2(new_n322_), .B(new_n323_), .Y(new_n324_));
  XNOR2x2_ASAP7_75t_R g238(.A(new_n309_), .B(new_n322_), .Y(new_n325_));
  AO21x1_ASAP7_75t_R  g239(.A1(G51), .A2(new_n325_), .B(new_n324_), .Y(new_n326_));
  NOR2x1_ASAP7_75t_R  g240(.A(new_n106_), .B(new_n113_), .Y(new_n327_));
  AO21x1_ASAP7_75t_R  g241(.A1(new_n114_), .A2(new_n327_), .B(G54), .Y(new_n328_));
  INVx1_ASAP7_75t_R   g242(.A(new_n328_), .Y(new_n329_));
  OA21x2_ASAP7_75t_R  g243(.A1(new_n306_), .A2(new_n329_), .B(new_n328_), .Y(new_n330_));
  OA21x2_ASAP7_75t_R  g244(.A1(new_n106_), .A2(new_n216_), .B(G44), .Y(new_n331_));
  OR3x1_ASAP7_75t_R   g245(.A(new_n326_), .B(new_n330_), .C(new_n331_), .Y(new_n332_));
  INVx1_ASAP7_75t_R   g246(.A(new_n332_), .Y(G877));
  XNOR2x2_ASAP7_75t_R g247(.A(new_n103_), .B(new_n290_), .Y(new_n334_));
  OA21x2_ASAP7_75t_R  g248(.A1(new_n111_), .A2(G60), .B(G50), .Y(new_n335_));
  AO21x1_ASAP7_75t_R  g249(.A1(G52), .A2(new_n334_), .B(new_n335_), .Y(new_n336_));
  NOR2x1_ASAP7_75t_R  g250(.A(new_n103_), .B(new_n113_), .Y(new_n337_));
  AO21x1_ASAP7_75t_R  g251(.A1(new_n114_), .A2(new_n337_), .B(G54), .Y(new_n338_));
  INVx1_ASAP7_75t_R   g252(.A(new_n338_), .Y(new_n339_));
  OA21x2_ASAP7_75t_R  g253(.A1(new_n290_), .A2(new_n339_), .B(new_n338_), .Y(new_n340_));
  OA21x2_ASAP7_75t_R  g254(.A1(new_n103_), .A2(new_n216_), .B(G41), .Y(new_n341_));
  OR3x1_ASAP7_75t_R   g255(.A(new_n336_), .B(new_n340_), .C(new_n341_), .Y(new_n342_));
  XNOR2x2_ASAP7_75t_R g256(.A(new_n318_), .B(new_n334_), .Y(new_n343_));
  AOI21x1_ASAP7_75t_R g257(.A1(G51), .A2(new_n343_), .B(new_n342_), .Y(G878));
  XNOR2x2_ASAP7_75t_R g258(.A(new_n104_), .B(new_n296_), .Y(new_n345_));
  OA21x2_ASAP7_75t_R  g259(.A1(G24), .A2(new_n111_), .B(G50), .Y(new_n346_));
  AO21x1_ASAP7_75t_R  g260(.A1(G52), .A2(new_n345_), .B(new_n346_), .Y(new_n347_));
  OA21x2_ASAP7_75t_R  g261(.A1(G54), .A2(new_n295_), .B(new_n296_), .Y(new_n348_));
  OA21x2_ASAP7_75t_R  g262(.A1(G53), .A2(new_n295_), .B(new_n296_), .Y(new_n349_));
  NOR2x1_ASAP7_75t_R  g263(.A(new_n216_), .B(new_n349_), .Y(new_n350_));
  INVx1_ASAP7_75t_R   g264(.A(new_n350_), .Y(new_n351_));
  OA21x2_ASAP7_75t_R  g265(.A1(G42), .A2(new_n350_), .B(new_n351_), .Y(new_n352_));
  OR3x1_ASAP7_75t_R   g266(.A(new_n347_), .B(new_n348_), .C(new_n352_), .Y(new_n353_));
  XNOR2x2_ASAP7_75t_R g267(.A(new_n315_), .B(new_n345_), .Y(new_n354_));
  AOI21x1_ASAP7_75t_R g268(.A1(G51), .A2(new_n354_), .B(new_n353_), .Y(G879));
  OA21x2_ASAP7_75t_R  g269(.A1(new_n105_), .A2(G53), .B(G43), .Y(new_n356_));
  OR3x1_ASAP7_75t_R   g270(.A(G54), .B(new_n356_), .C(new_n300_), .Y(new_n357_));
  AND2x2_ASAP7_75t_R  g271(.A(new_n301_), .B(new_n357_), .Y(new_n358_));
  AO21x1_ASAP7_75t_R  g272(.A1(G25), .A2(G50), .B(new_n358_), .Y(new_n359_));
  OA21x2_ASAP7_75t_R  g273(.A1(G43), .A2(new_n215_), .B(new_n216_), .Y(new_n360_));
  XOR2x2_ASAP7_75t_R  g274(.A(new_n105_), .B(new_n301_), .Y(new_n361_));
  INVx1_ASAP7_75t_R   g275(.A(new_n361_), .Y(new_n362_));
  OA21x2_ASAP7_75t_R  g276(.A1(G52), .A2(new_n361_), .B(new_n362_), .Y(new_n363_));
  OR3x1_ASAP7_75t_R   g277(.A(new_n359_), .B(new_n360_), .C(new_n363_), .Y(new_n364_));
  XNOR2x2_ASAP7_75t_R g278(.A(new_n312_), .B(new_n362_), .Y(new_n365_));
  AOI21x1_ASAP7_75t_R g279(.A1(G51), .A2(new_n365_), .B(new_n364_), .Y(G880));
endmodule


