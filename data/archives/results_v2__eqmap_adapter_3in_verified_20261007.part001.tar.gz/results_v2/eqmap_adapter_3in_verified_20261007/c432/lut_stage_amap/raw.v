// Benchmark "/home/flynn/workplace/MIGBalance/results_v2/eqmap_adapter_3in_verified_20261007/c432/lut_stage_amap/stage" written by ABC on Wed Oct  7 16:31:55 2026

module \/home/flynn/workplace/MIGBalance/results_v2/eqmap_adapter_3in_verified_20261007/c432/lut_stage_amap/stage  ( 
    G1, G10, G11, G12, G13, G14, G15, G16, G17, G18, G19, G2, G20, G21,
    G22, G23, G24, G25, G26, G27, G28, G29, G3, G30, G31, G32, G33, G34,
    G35, G36, G4, G5, G6, G7, G8, G9,
    G426, G427, G428, G429, G430, G431, G432  );
  input  G1, G10, G11, G12, G13, G14, G15, G16, G17, G18, G19, G2, G20,
    G21, G22, G23, G24, G25, G26, G27, G28, G29, G3, G30, G31, G32, G33,
    G34, G35, G36, G4, G5, G6, G7, G8, G9;
  output G426, G427, G428, G429, G430, G431, G432;
  wire new_n44_, new_n45_, new_n46_, new_n47_, new_n48_, new_n49_, new_n50_,
    new_n51_, new_n52_, new_n53_, new_n54_, new_n55_, new_n56_, new_n57_,
    new_n58_, new_n59_, new_n60_, new_n61_, new_n62_, new_n63_, new_n64_,
    new_n65_, new_n66_, new_n67_, new_n68_, new_n69_, new_n70_, new_n71_,
    new_n72_, new_n73_, new_n74_, new_n75_, new_n77_, new_n78_, new_n79_,
    new_n80_, new_n81_, new_n82_, new_n83_, new_n84_, new_n85_, new_n86_,
    new_n87_, new_n88_, new_n89_, new_n90_, new_n91_, new_n92_, new_n93_,
    new_n94_, new_n95_, new_n96_, new_n97_, new_n98_, new_n99_, new_n100_,
    new_n101_, new_n102_, new_n103_, new_n104_, new_n105_, new_n106_,
    new_n107_, new_n108_, new_n109_, new_n110_, new_n111_, new_n113_,
    new_n114_, new_n115_, new_n116_, new_n117_, new_n118_, new_n119_,
    new_n120_, new_n121_, new_n122_, new_n123_, new_n124_, new_n125_,
    new_n126_, new_n127_, new_n128_, new_n129_, new_n130_, new_n131_,
    new_n132_, new_n133_, new_n134_, new_n135_, new_n136_, new_n137_,
    new_n138_, new_n139_, new_n140_, new_n141_, new_n142_, new_n143_,
    new_n144_, new_n145_, new_n146_, new_n147_, new_n148_, new_n149_,
    new_n151_, new_n152_, new_n153_, new_n154_, new_n155_, new_n156_,
    new_n157_, new_n158_, new_n159_, new_n160_, new_n161_, new_n162_,
    new_n163_, new_n164_, new_n165_, new_n166_, new_n168_, new_n169_,
    new_n170_, new_n171_, new_n172_, new_n173_, new_n174_, new_n175_,
    new_n176_, new_n177_, new_n179_, new_n180_, new_n181_, new_n182_,
    new_n184_, new_n185_, new_n186_, new_n187_;
  INVx1_ASAP7_75t_R   g000(.A(G1), .Y(new_n44_));
  INVx1_ASAP7_75t_R   g001(.A(G10), .Y(new_n45_));
  INVx1_ASAP7_75t_R   g002(.A(G11), .Y(new_n46_));
  INVx1_ASAP7_75t_R   g003(.A(G12), .Y(new_n47_));
  INVx1_ASAP7_75t_R   g004(.A(G14), .Y(new_n48_));
  INVx1_ASAP7_75t_R   g005(.A(G15), .Y(new_n49_));
  INVx1_ASAP7_75t_R   g006(.A(G18), .Y(new_n50_));
  INVx1_ASAP7_75t_R   g007(.A(G19), .Y(new_n51_));
  INVx1_ASAP7_75t_R   g008(.A(G20), .Y(new_n52_));
  INVx1_ASAP7_75t_R   g009(.A(G22), .Y(new_n53_));
  INVx1_ASAP7_75t_R   g010(.A(G24), .Y(new_n54_));
  INVx1_ASAP7_75t_R   g011(.A(G27), .Y(new_n55_));
  INVx1_ASAP7_75t_R   g012(.A(G3), .Y(new_n56_));
  INVx1_ASAP7_75t_R   g013(.A(G30), .Y(new_n57_));
  INVx1_ASAP7_75t_R   g014(.A(G32), .Y(new_n58_));
  INVx1_ASAP7_75t_R   g015(.A(G34), .Y(new_n59_));
  INVx1_ASAP7_75t_R   g016(.A(G4), .Y(new_n60_));
  INVx1_ASAP7_75t_R   g017(.A(G5), .Y(new_n61_));
  INVx1_ASAP7_75t_R   g018(.A(G6), .Y(new_n62_));
  INVx1_ASAP7_75t_R   g019(.A(G8), .Y(new_n63_));
  OA21x2_ASAP7_75t_R  g020(.A1(new_n60_), .A2(new_n62_), .B(G6), .Y(new_n64_));
  AO21x1_ASAP7_75t_R  g021(.A1(new_n44_), .A2(G2), .B(new_n64_), .Y(new_n65_));
  INVx1_ASAP7_75t_R   g022(.A(new_n65_), .Y(new_n66_));
  OA21x2_ASAP7_75t_R  g023(.A1(new_n47_), .A2(new_n48_), .B(G14), .Y(new_n67_));
  AO21x1_ASAP7_75t_R  g024(.A1(new_n52_), .A2(G22), .B(new_n67_), .Y(new_n68_));
  NOR2x1_ASAP7_75t_R  g025(.A(G28), .B(new_n57_), .Y(new_n69_));
  AO21x1_ASAP7_75t_R  g026(.A1(new_n58_), .A2(G34), .B(new_n69_), .Y(new_n70_));
  AO21x1_ASAP7_75t_R  g027(.A1(new_n54_), .A2(G26), .B(new_n70_), .Y(new_n71_));
  AOI21x1_ASAP7_75t_R g028(.A1(G16), .A2(G18), .B(new_n50_), .Y(new_n72_));
  AO21x1_ASAP7_75t_R  g029(.A1(G10), .A2(new_n63_), .B(new_n72_), .Y(new_n73_));
  OR3x1_ASAP7_75t_R   g030(.A(new_n71_), .B(new_n73_), .C(new_n68_), .Y(new_n74_));
  INVx1_ASAP7_75t_R   g031(.A(new_n74_), .Y(new_n75_));
  AO21x1_ASAP7_75t_R  g032(.A1(new_n66_), .A2(new_n74_), .B(new_n65_), .Y(G426));
  INVx1_ASAP7_75t_R   g033(.A(G426), .Y(new_n77_));
  OA21x2_ASAP7_75t_R  g034(.A1(new_n66_), .A2(new_n74_), .B(new_n75_), .Y(new_n78_));
  NOR2x1_ASAP7_75t_R  g035(.A(new_n58_), .B(new_n78_), .Y(new_n79_));
  OR3x1_ASAP7_75t_R   g036(.A(G35), .B(new_n79_), .C(new_n59_), .Y(new_n80_));
  INVx1_ASAP7_75t_R   g037(.A(new_n80_), .Y(new_n81_));
  NOR2x1_ASAP7_75t_R  g038(.A(G28), .B(new_n77_), .Y(new_n82_));
  OA21x2_ASAP7_75t_R  g039(.A1(new_n77_), .A2(new_n82_), .B(G30), .Y(new_n83_));
  INVx1_ASAP7_75t_R   g040(.A(new_n83_), .Y(new_n84_));
  AOI21x1_ASAP7_75t_R g041(.A1(G31), .A2(new_n83_), .B(new_n84_), .Y(new_n85_));
  NOR2x1_ASAP7_75t_R  g042(.A(new_n60_), .B(new_n78_), .Y(new_n86_));
  OR3x1_ASAP7_75t_R   g043(.A(G7), .B(new_n86_), .C(new_n62_), .Y(new_n87_));
  NOR2x1_ASAP7_75t_R  g044(.A(new_n47_), .B(new_n78_), .Y(new_n88_));
  OR3x1_ASAP7_75t_R   g045(.A(G15), .B(new_n88_), .C(new_n48_), .Y(new_n89_));
  NOR2x1_ASAP7_75t_R  g046(.A(new_n63_), .B(new_n78_), .Y(new_n90_));
  OR3x1_ASAP7_75t_R   g047(.A(G11), .B(new_n90_), .C(new_n45_), .Y(new_n91_));
  AND3x1_ASAP7_75t_R  g048(.A(new_n89_), .B(new_n91_), .C(new_n87_), .Y(new_n92_));
  INVx1_ASAP7_75t_R   g049(.A(new_n92_), .Y(new_n93_));
  NOR2x1_ASAP7_75t_R  g050(.A(new_n52_), .B(new_n78_), .Y(new_n94_));
  OR3x1_ASAP7_75t_R   g051(.A(G23), .B(new_n94_), .C(new_n53_), .Y(new_n95_));
  INVx1_ASAP7_75t_R   g052(.A(new_n95_), .Y(new_n96_));
  AO21x1_ASAP7_75t_R  g053(.A1(new_n54_), .A2(G426), .B(new_n77_), .Y(new_n97_));
  NAND2x1_ASAP7_75t_R g054(.A(G26), .B(new_n97_), .Y(new_n98_));
  INVx1_ASAP7_75t_R   g055(.A(new_n98_), .Y(new_n99_));
  OA21x2_ASAP7_75t_R  g056(.A1(new_n55_), .A2(new_n98_), .B(new_n99_), .Y(new_n100_));
  OR3x1_ASAP7_75t_R   g057(.A(new_n96_), .B(new_n100_), .C(new_n93_), .Y(new_n101_));
  OR3x1_ASAP7_75t_R   g058(.A(new_n81_), .B(new_n85_), .C(new_n101_), .Y(new_n102_));
  INVx1_ASAP7_75t_R   g059(.A(new_n102_), .Y(new_n103_));
  AO21x1_ASAP7_75t_R  g060(.A1(new_n44_), .A2(G426), .B(new_n77_), .Y(new_n104_));
  AND2x2_ASAP7_75t_R  g061(.A(G2), .B(new_n104_), .Y(new_n105_));
  NOR2x1_ASAP7_75t_R  g062(.A(G16), .B(new_n77_), .Y(new_n106_));
  OA21x2_ASAP7_75t_R  g063(.A1(new_n77_), .A2(new_n106_), .B(G18), .Y(new_n107_));
  INVx1_ASAP7_75t_R   g064(.A(new_n107_), .Y(new_n108_));
  OA21x2_ASAP7_75t_R  g065(.A1(new_n51_), .A2(new_n108_), .B(new_n107_), .Y(new_n109_));
  AO21x1_ASAP7_75t_R  g066(.A1(new_n56_), .A2(new_n105_), .B(new_n109_), .Y(new_n110_));
  INVx1_ASAP7_75t_R   g067(.A(new_n110_), .Y(new_n111_));
  AO21x1_ASAP7_75t_R  g068(.A1(new_n103_), .A2(new_n110_), .B(new_n102_), .Y(G427));
  INVx1_ASAP7_75t_R   g069(.A(G427), .Y(new_n113_));
  OA21x2_ASAP7_75t_R  g070(.A1(new_n103_), .A2(new_n110_), .B(new_n111_), .Y(new_n114_));
  NOR2x1_ASAP7_75t_R  g071(.A(new_n55_), .B(new_n114_), .Y(new_n115_));
  OR3x1_ASAP7_75t_R   g072(.A(G29), .B(new_n115_), .C(new_n98_), .Y(new_n116_));
  OA21x2_ASAP7_75t_R  g073(.A1(G35), .A2(new_n113_), .B(G427), .Y(new_n117_));
  OR3x1_ASAP7_75t_R   g074(.A(new_n59_), .B(new_n79_), .C(new_n117_), .Y(new_n118_));
  INVx1_ASAP7_75t_R   g075(.A(new_n118_), .Y(new_n119_));
  AO21x1_ASAP7_75t_R  g076(.A1(G36), .A2(new_n119_), .B(new_n118_), .Y(new_n120_));
  NOR2x1_ASAP7_75t_R  g077(.A(new_n51_), .B(new_n114_), .Y(new_n121_));
  OR3x1_ASAP7_75t_R   g078(.A(G21), .B(new_n121_), .C(new_n108_), .Y(new_n122_));
  OAI21x1_ASAP7_75t_R g079(.A1(new_n47_), .A2(new_n78_), .B(G14), .Y(new_n123_));
  NOR2x1_ASAP7_75t_R  g080(.A(new_n49_), .B(new_n114_), .Y(new_n124_));
  OR3x1_ASAP7_75t_R   g081(.A(G17), .B(new_n124_), .C(new_n123_), .Y(new_n125_));
  OAI21x1_ASAP7_75t_R g082(.A1(new_n63_), .A2(new_n78_), .B(G10), .Y(new_n126_));
  NOR2x1_ASAP7_75t_R  g083(.A(new_n46_), .B(new_n114_), .Y(new_n127_));
  OR3x1_ASAP7_75t_R   g084(.A(G13), .B(new_n127_), .C(new_n126_), .Y(new_n128_));
  AND3x1_ASAP7_75t_R  g085(.A(new_n125_), .B(new_n128_), .C(new_n122_), .Y(new_n129_));
  AND3x1_ASAP7_75t_R  g086(.A(new_n116_), .B(new_n120_), .C(new_n129_), .Y(new_n130_));
  INVx1_ASAP7_75t_R   g087(.A(new_n130_), .Y(new_n131_));
  OAI21x1_ASAP7_75t_R g088(.A1(new_n60_), .A2(new_n78_), .B(G6), .Y(new_n132_));
  AND2x2_ASAP7_75t_R  g089(.A(G7), .B(G427), .Y(new_n133_));
  OR3x1_ASAP7_75t_R   g090(.A(G9), .B(new_n133_), .C(new_n132_), .Y(new_n134_));
  INVx1_ASAP7_75t_R   g091(.A(new_n134_), .Y(new_n135_));
  NOR2x1_ASAP7_75t_R  g092(.A(G31), .B(new_n113_), .Y(new_n136_));
  OA21x2_ASAP7_75t_R  g093(.A1(new_n113_), .A2(new_n136_), .B(new_n83_), .Y(new_n137_));
  NAND2x1_ASAP7_75t_R g094(.A(G33), .B(new_n137_), .Y(new_n138_));
  AO21x1_ASAP7_75t_R  g095(.A1(new_n137_), .A2(new_n138_), .B(new_n135_), .Y(new_n139_));
  INVx1_ASAP7_75t_R   g096(.A(new_n139_), .Y(new_n140_));
  AO21x1_ASAP7_75t_R  g097(.A1(new_n56_), .A2(G427), .B(new_n113_), .Y(new_n141_));
  AND3x1_ASAP7_75t_R  g098(.A(G2), .B(new_n104_), .C(new_n141_), .Y(new_n142_));
  INVx1_ASAP7_75t_R   g099(.A(new_n142_), .Y(new_n143_));
  OA21x2_ASAP7_75t_R  g100(.A1(G23), .A2(new_n113_), .B(G427), .Y(new_n144_));
  OR3x1_ASAP7_75t_R   g101(.A(new_n53_), .B(new_n94_), .C(new_n144_), .Y(new_n145_));
  INVx1_ASAP7_75t_R   g102(.A(new_n145_), .Y(new_n146_));
  AOI21x1_ASAP7_75t_R g103(.A1(G25), .A2(new_n146_), .B(new_n145_), .Y(new_n147_));
  AO21x1_ASAP7_75t_R  g104(.A1(new_n61_), .A2(new_n142_), .B(new_n147_), .Y(new_n148_));
  AO21x1_ASAP7_75t_R  g105(.A1(new_n140_), .A2(new_n148_), .B(new_n139_), .Y(new_n149_));
  AO21x1_ASAP7_75t_R  g106(.A1(new_n130_), .A2(new_n149_), .B(new_n131_), .Y(G428));
  INVx1_ASAP7_75t_R   g107(.A(G428), .Y(new_n151_));
  OR3x1_ASAP7_75t_R   g108(.A(new_n61_), .B(new_n151_), .C(new_n143_), .Y(new_n152_));
  NOR2x1_ASAP7_75t_R  g109(.A(new_n108_), .B(new_n121_), .Y(new_n153_));
  INVx1_ASAP7_75t_R   g110(.A(new_n153_), .Y(new_n154_));
  AND3x1_ASAP7_75t_R  g111(.A(G21), .B(G428), .C(new_n153_), .Y(new_n155_));
  OA21x2_ASAP7_75t_R  g112(.A1(G17), .A2(new_n151_), .B(G428), .Y(new_n156_));
  OR3x1_ASAP7_75t_R   g113(.A(new_n123_), .B(new_n124_), .C(new_n156_), .Y(new_n157_));
  OA21x2_ASAP7_75t_R  g114(.A1(new_n154_), .A2(new_n155_), .B(new_n157_), .Y(new_n158_));
  INVx1_ASAP7_75t_R   g115(.A(new_n158_), .Y(new_n159_));
  OA21x2_ASAP7_75t_R  g116(.A1(G13), .A2(new_n151_), .B(G428), .Y(new_n160_));
  OR3x1_ASAP7_75t_R   g117(.A(new_n126_), .B(new_n127_), .C(new_n160_), .Y(new_n161_));
  INVx1_ASAP7_75t_R   g118(.A(new_n161_), .Y(new_n162_));
  OA21x2_ASAP7_75t_R  g119(.A1(G9), .A2(new_n151_), .B(G428), .Y(new_n163_));
  OR3x1_ASAP7_75t_R   g120(.A(new_n132_), .B(new_n133_), .C(new_n163_), .Y(new_n164_));
  INVx1_ASAP7_75t_R   g121(.A(new_n164_), .Y(new_n165_));
  NAND2x1_ASAP7_75t_R g122(.A(new_n161_), .B(new_n164_), .Y(new_n166_));
  AO21x1_ASAP7_75t_R  g123(.A1(new_n158_), .A2(new_n166_), .B(new_n159_), .Y(G430));
  INVx1_ASAP7_75t_R   g124(.A(G430), .Y(new_n168_));
  NOR2x1_ASAP7_75t_R  g125(.A(G25), .B(new_n151_), .Y(new_n169_));
  OA21x2_ASAP7_75t_R  g126(.A1(new_n151_), .A2(new_n169_), .B(new_n146_), .Y(new_n170_));
  OAI21x1_ASAP7_75t_R g127(.A1(G33), .A2(new_n151_), .B(G428), .Y(new_n171_));
  OA21x2_ASAP7_75t_R  g128(.A1(G29), .A2(new_n151_), .B(G428), .Y(new_n172_));
  OR3x1_ASAP7_75t_R   g129(.A(new_n98_), .B(new_n115_), .C(new_n172_), .Y(new_n173_));
  INVx1_ASAP7_75t_R   g130(.A(new_n173_), .Y(new_n174_));
  AO21x1_ASAP7_75t_R  g131(.A1(new_n137_), .A2(new_n171_), .B(new_n174_), .Y(new_n175_));
  OR3x1_ASAP7_75t_R   g132(.A(G34), .B(new_n170_), .C(new_n175_), .Y(new_n176_));
  AOI21x1_ASAP7_75t_R g133(.A1(new_n168_), .A2(new_n176_), .B(G430), .Y(new_n177_));
  AOI21x1_ASAP7_75t_R g134(.A1(new_n142_), .A2(new_n152_), .B(new_n177_), .Y(G429));
  OA21x2_ASAP7_75t_R  g135(.A1(new_n159_), .A2(new_n174_), .B(new_n158_), .Y(new_n179_));
  OR3x1_ASAP7_75t_R   g136(.A(new_n162_), .B(new_n165_), .C(new_n179_), .Y(new_n180_));
  INVx1_ASAP7_75t_R   g137(.A(new_n180_), .Y(new_n181_));
  AND3x1_ASAP7_75t_R  g138(.A(new_n158_), .B(new_n161_), .C(new_n170_), .Y(new_n182_));
  AO21x1_ASAP7_75t_R  g139(.A1(new_n181_), .A2(new_n182_), .B(new_n180_), .Y(G431));
  NAND2x1_ASAP7_75t_R g140(.A(new_n173_), .B(new_n175_), .Y(new_n184_));
  AO21x1_ASAP7_75t_R  g141(.A1(new_n157_), .A2(new_n184_), .B(new_n162_), .Y(new_n185_));
  INVx1_ASAP7_75t_R   g142(.A(new_n185_), .Y(new_n186_));
  AO21x1_ASAP7_75t_R  g143(.A1(new_n182_), .A2(new_n185_), .B(new_n186_), .Y(new_n187_));
  AO21x1_ASAP7_75t_R  g144(.A1(new_n164_), .A2(new_n187_), .B(new_n165_), .Y(G432));
endmodule


