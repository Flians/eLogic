// Benchmark "/home/flynn/workplace/MIGBalance/results_v2/eqmap_adapter_3in_verified_20261007/c1355/lut_stage_amap/stage" written by ABC on Wed Oct  7 16:32:11 2026

module \/home/flynn/workplace/MIGBalance/results_v2/eqmap_adapter_3in_verified_20261007/c1355/lut_stage_amap/stage  ( 
    G1, G10, G11, G12, G13, G14, G15, G16, G17, G18, G19, G2, G20, G21,
    G22, G23, G24, G25, G26, G27, G28, G29, G3, G30, G31, G32, G33, G34,
    G35, G36, G37, G38, G39, G4, G40, G41, G5, G6, G7, G8, G9,
    G1324, G1325, G1326, G1327, G1328, G1329, G1330, G1331, G1332, G1333,
    G1334, G1335, G1336, G1337, G1338, G1339, G1340, G1341, G1342, G1343,
    G1344, G1345, G1346, G1347, G1348, G1349, G1350, G1351, G1352, G1353,
    G1354, G1355  );
  input  G1, G10, G11, G12, G13, G14, G15, G16, G17, G18, G19, G2, G20,
    G21, G22, G23, G24, G25, G26, G27, G28, G29, G3, G30, G31, G32, G33,
    G34, G35, G36, G37, G38, G39, G4, G40, G41, G5, G6, G7, G8, G9;
  output G1324, G1325, G1326, G1327, G1328, G1329, G1330, G1331, G1332, G1333,
    G1334, G1335, G1336, G1337, G1338, G1339, G1340, G1341, G1342, G1343,
    G1344, G1345, G1346, G1347, G1348, G1349, G1350, G1351, G1352, G1353,
    G1354, G1355;
  wire new_n74_, new_n75_, new_n76_, new_n77_, new_n78_, new_n79_, new_n80_,
    new_n81_, new_n82_, new_n83_, new_n84_, new_n85_, new_n86_, new_n87_,
    new_n88_, new_n89_, new_n90_, new_n91_, new_n92_, new_n93_, new_n94_,
    new_n95_, new_n96_, new_n97_, new_n98_, new_n99_, new_n100_, new_n101_,
    new_n102_, new_n103_, new_n104_, new_n105_, new_n106_, new_n107_,
    new_n108_, new_n109_, new_n110_, new_n111_, new_n112_, new_n113_,
    new_n114_, new_n115_, new_n116_, new_n117_, new_n118_, new_n119_,
    new_n120_, new_n121_, new_n122_, new_n123_, new_n124_, new_n125_,
    new_n126_, new_n127_, new_n128_, new_n129_, new_n130_, new_n131_,
    new_n132_, new_n133_, new_n134_, new_n135_, new_n136_, new_n137_,
    new_n138_, new_n139_, new_n140_, new_n141_, new_n142_, new_n143_,
    new_n144_, new_n145_, new_n146_, new_n147_, new_n148_, new_n149_,
    new_n150_, new_n151_, new_n152_, new_n153_, new_n154_, new_n155_,
    new_n156_, new_n157_, new_n158_, new_n159_, new_n160_, new_n161_,
    new_n162_, new_n163_, new_n164_, new_n165_, new_n166_, new_n167_,
    new_n168_, new_n169_, new_n170_, new_n171_, new_n172_, new_n173_,
    new_n174_, new_n175_, new_n176_, new_n177_, new_n178_, new_n179_,
    new_n180_, new_n181_, new_n182_, new_n183_, new_n184_, new_n185_,
    new_n186_, new_n187_, new_n188_, new_n189_, new_n190_, new_n191_,
    new_n192_, new_n193_, new_n194_, new_n195_, new_n196_, new_n197_,
    new_n198_, new_n199_, new_n200_, new_n201_, new_n202_, new_n203_,
    new_n204_, new_n205_, new_n206_, new_n207_, new_n208_, new_n209_,
    new_n210_, new_n211_, new_n212_, new_n213_, new_n214_, new_n215_,
    new_n216_, new_n217_, new_n218_, new_n219_, new_n220_, new_n221_,
    new_n222_, new_n223_, new_n224_, new_n225_, new_n226_, new_n227_,
    new_n228_, new_n229_, new_n230_, new_n231_, new_n232_, new_n233_,
    new_n234_, new_n235_, new_n236_, new_n237_, new_n238_, new_n239_,
    new_n240_, new_n241_, new_n242_, new_n243_, new_n244_, new_n245_,
    new_n246_, new_n247_, new_n248_, new_n249_, new_n250_, new_n251_,
    new_n252_, new_n253_, new_n254_, new_n255_, new_n256_, new_n257_,
    new_n258_, new_n259_, new_n260_, new_n261_, new_n262_, new_n263_,
    new_n264_, new_n265_, new_n266_, new_n267_, new_n269_, new_n270_,
    new_n272_, new_n273_, new_n275_, new_n276_, new_n278_, new_n279_,
    new_n280_, new_n281_, new_n283_, new_n284_, new_n286_, new_n287_,
    new_n289_, new_n290_, new_n292_, new_n293_, new_n294_, new_n295_,
    new_n296_, new_n298_, new_n299_, new_n301_, new_n302_, new_n304_,
    new_n305_, new_n307_, new_n308_, new_n309_, new_n310_, new_n311_,
    new_n313_, new_n314_, new_n316_, new_n317_, new_n319_, new_n320_,
    new_n322_, new_n323_, new_n324_, new_n325_, new_n326_, new_n327_,
    new_n328_, new_n329_, new_n330_, new_n331_, new_n332_, new_n334_,
    new_n335_, new_n337_, new_n338_, new_n340_, new_n341_, new_n343_,
    new_n344_, new_n346_, new_n347_, new_n349_, new_n350_, new_n352_,
    new_n353_, new_n355_, new_n356_, new_n357_, new_n358_, new_n360_,
    new_n361_, new_n363_, new_n364_, new_n366_, new_n367_, new_n369_,
    new_n371_, new_n373_, new_n375_;
  INVx1_ASAP7_75t_R   g000(.A(G1), .Y(new_n74_));
  INVx1_ASAP7_75t_R   g001(.A(G10), .Y(new_n75_));
  INVx1_ASAP7_75t_R   g002(.A(G11), .Y(new_n76_));
  INVx1_ASAP7_75t_R   g003(.A(G12), .Y(new_n77_));
  INVx1_ASAP7_75t_R   g004(.A(G13), .Y(new_n78_));
  INVx1_ASAP7_75t_R   g005(.A(G14), .Y(new_n79_));
  INVx1_ASAP7_75t_R   g006(.A(G15), .Y(new_n80_));
  INVx1_ASAP7_75t_R   g007(.A(G16), .Y(new_n81_));
  INVx1_ASAP7_75t_R   g008(.A(G17), .Y(new_n82_));
  INVx1_ASAP7_75t_R   g009(.A(G18), .Y(new_n83_));
  INVx1_ASAP7_75t_R   g010(.A(G19), .Y(new_n84_));
  INVx1_ASAP7_75t_R   g011(.A(G2), .Y(new_n85_));
  INVx1_ASAP7_75t_R   g012(.A(G20), .Y(new_n86_));
  INVx1_ASAP7_75t_R   g013(.A(G21), .Y(new_n87_));
  INVx1_ASAP7_75t_R   g014(.A(G22), .Y(new_n88_));
  INVx1_ASAP7_75t_R   g015(.A(G23), .Y(new_n89_));
  INVx1_ASAP7_75t_R   g016(.A(G24), .Y(new_n90_));
  INVx1_ASAP7_75t_R   g017(.A(G25), .Y(new_n91_));
  INVx1_ASAP7_75t_R   g018(.A(G26), .Y(new_n92_));
  INVx1_ASAP7_75t_R   g019(.A(G27), .Y(new_n93_));
  INVx1_ASAP7_75t_R   g020(.A(G28), .Y(new_n94_));
  INVx1_ASAP7_75t_R   g021(.A(G29), .Y(new_n95_));
  INVx1_ASAP7_75t_R   g022(.A(G3), .Y(new_n96_));
  INVx1_ASAP7_75t_R   g023(.A(G30), .Y(new_n97_));
  INVx1_ASAP7_75t_R   g024(.A(G31), .Y(new_n98_));
  INVx1_ASAP7_75t_R   g025(.A(G32), .Y(new_n99_));
  INVx1_ASAP7_75t_R   g026(.A(G33), .Y(new_n100_));
  INVx1_ASAP7_75t_R   g027(.A(G34), .Y(new_n101_));
  INVx1_ASAP7_75t_R   g028(.A(G4), .Y(new_n102_));
  INVx1_ASAP7_75t_R   g029(.A(G41), .Y(new_n103_));
  INVx1_ASAP7_75t_R   g030(.A(G5), .Y(new_n104_));
  INVx1_ASAP7_75t_R   g031(.A(G6), .Y(new_n105_));
  INVx1_ASAP7_75t_R   g032(.A(G7), .Y(new_n106_));
  INVx1_ASAP7_75t_R   g033(.A(G8), .Y(new_n107_));
  INVx1_ASAP7_75t_R   g034(.A(G9), .Y(new_n108_));
  XOR2x2_ASAP7_75t_R  g035(.A(new_n84_), .B(new_n86_), .Y(new_n109_));
  XNOR2x2_ASAP7_75t_R g036(.A(new_n83_), .B(new_n109_), .Y(new_n110_));
  XOR2x2_ASAP7_75t_R  g037(.A(G18), .B(new_n109_), .Y(new_n111_));
  NOR2x1_ASAP7_75t_R  g038(.A(G17), .B(new_n111_), .Y(new_n112_));
  AO21x1_ASAP7_75t_R  g039(.A1(G17), .A2(new_n110_), .B(new_n112_), .Y(new_n113_));
  XOR2x2_ASAP7_75t_R  g040(.A(new_n89_), .B(new_n90_), .Y(new_n114_));
  XNOR2x2_ASAP7_75t_R g041(.A(new_n88_), .B(new_n114_), .Y(new_n115_));
  XOR2x2_ASAP7_75t_R  g042(.A(G22), .B(new_n114_), .Y(new_n116_));
  NOR2x1_ASAP7_75t_R  g043(.A(G21), .B(new_n116_), .Y(new_n117_));
  AO21x1_ASAP7_75t_R  g044(.A1(G21), .A2(new_n115_), .B(new_n117_), .Y(new_n118_));
  INVx1_ASAP7_75t_R   g045(.A(new_n118_), .Y(new_n119_));
  XNOR2x2_ASAP7_75t_R g046(.A(new_n78_), .B(new_n104_), .Y(new_n120_));
  AO21x1_ASAP7_75t_R  g047(.A1(G33), .A2(new_n103_), .B(new_n100_), .Y(new_n121_));
  OR3x1_ASAP7_75t_R   g048(.A(new_n100_), .B(new_n103_), .C(new_n120_), .Y(new_n122_));
  INVx1_ASAP7_75t_R   g049(.A(new_n122_), .Y(new_n123_));
  AO21x1_ASAP7_75t_R  g050(.A1(new_n120_), .A2(new_n121_), .B(new_n123_), .Y(new_n124_));
  XNOR2x2_ASAP7_75t_R g051(.A(new_n74_), .B(new_n124_), .Y(new_n125_));
  XOR2x2_ASAP7_75t_R  g052(.A(G1), .B(new_n124_), .Y(new_n126_));
  NOR2x1_ASAP7_75t_R  g053(.A(G9), .B(new_n126_), .Y(new_n127_));
  AO21x1_ASAP7_75t_R  g054(.A1(G9), .A2(new_n125_), .B(new_n127_), .Y(new_n128_));
  XNOR2x2_ASAP7_75t_R g055(.A(new_n119_), .B(new_n128_), .Y(new_n129_));
  XOR2x2_ASAP7_75t_R  g056(.A(new_n118_), .B(new_n128_), .Y(new_n130_));
  NOR2x1_ASAP7_75t_R  g057(.A(new_n113_), .B(new_n130_), .Y(new_n131_));
  AO21x1_ASAP7_75t_R  g058(.A1(new_n113_), .A2(new_n129_), .B(new_n131_), .Y(new_n132_));
  INVx1_ASAP7_75t_R   g059(.A(new_n132_), .Y(new_n133_));
  XNOR2x2_ASAP7_75t_R g060(.A(new_n86_), .B(new_n90_), .Y(new_n134_));
  XOR2x2_ASAP7_75t_R  g061(.A(new_n94_), .B(new_n99_), .Y(new_n135_));
  NAND2x1_ASAP7_75t_R g062(.A(G40), .B(G41), .Y(new_n136_));
  XNOR2x2_ASAP7_75t_R g063(.A(new_n135_), .B(new_n136_), .Y(new_n137_));
  XNOR2x2_ASAP7_75t_R g064(.A(new_n135_), .B(new_n136_), .Y(new_n138_));
  NOR2x1_ASAP7_75t_R  g065(.A(new_n134_), .B(new_n138_), .Y(new_n139_));
  AO21x1_ASAP7_75t_R  g066(.A1(new_n134_), .A2(new_n137_), .B(new_n139_), .Y(new_n140_));
  XOR2x2_ASAP7_75t_R  g067(.A(new_n79_), .B(new_n80_), .Y(new_n141_));
  XNOR2x2_ASAP7_75t_R g068(.A(new_n78_), .B(new_n141_), .Y(new_n142_));
  NAND2x1_ASAP7_75t_R g069(.A(G16), .B(new_n142_), .Y(new_n143_));
  XOR2x2_ASAP7_75t_R  g070(.A(G13), .B(new_n141_), .Y(new_n144_));
  OA21x2_ASAP7_75t_R  g071(.A1(G16), .A2(new_n144_), .B(new_n143_), .Y(new_n145_));
  XOR2x2_ASAP7_75t_R  g072(.A(new_n105_), .B(new_n106_), .Y(new_n146_));
  XNOR2x2_ASAP7_75t_R g073(.A(new_n104_), .B(new_n146_), .Y(new_n147_));
  XOR2x2_ASAP7_75t_R  g074(.A(G5), .B(new_n146_), .Y(new_n148_));
  NOR2x1_ASAP7_75t_R  g075(.A(G8), .B(new_n148_), .Y(new_n149_));
  AO21x1_ASAP7_75t_R  g076(.A1(G8), .A2(new_n147_), .B(new_n149_), .Y(new_n150_));
  INVx1_ASAP7_75t_R   g077(.A(new_n150_), .Y(new_n151_));
  XNOR2x2_ASAP7_75t_R g078(.A(new_n145_), .B(new_n150_), .Y(new_n152_));
  XOR2x2_ASAP7_75t_R  g079(.A(new_n145_), .B(new_n151_), .Y(new_n153_));
  NOR2x1_ASAP7_75t_R  g080(.A(new_n140_), .B(new_n153_), .Y(new_n154_));
  AO21x1_ASAP7_75t_R  g081(.A1(new_n140_), .A2(new_n152_), .B(new_n154_), .Y(new_n155_));
  INVx1_ASAP7_75t_R   g082(.A(new_n155_), .Y(new_n156_));
  XNOR2x2_ASAP7_75t_R g083(.A(new_n84_), .B(new_n89_), .Y(new_n157_));
  XOR2x2_ASAP7_75t_R  g084(.A(new_n93_), .B(new_n98_), .Y(new_n158_));
  NAND2x1_ASAP7_75t_R g085(.A(G39), .B(G41), .Y(new_n159_));
  XNOR2x2_ASAP7_75t_R g086(.A(new_n158_), .B(new_n159_), .Y(new_n160_));
  XNOR2x2_ASAP7_75t_R g087(.A(new_n158_), .B(new_n159_), .Y(new_n161_));
  NOR2x1_ASAP7_75t_R  g088(.A(new_n157_), .B(new_n161_), .Y(new_n162_));
  AO21x1_ASAP7_75t_R  g089(.A1(new_n157_), .A2(new_n160_), .B(new_n162_), .Y(new_n163_));
  XOR2x2_ASAP7_75t_R  g090(.A(new_n75_), .B(new_n76_), .Y(new_n164_));
  XNOR2x2_ASAP7_75t_R g091(.A(new_n108_), .B(new_n164_), .Y(new_n165_));
  XOR2x2_ASAP7_75t_R  g092(.A(G9), .B(new_n164_), .Y(new_n166_));
  NOR2x1_ASAP7_75t_R  g093(.A(G12), .B(new_n166_), .Y(new_n167_));
  AO21x1_ASAP7_75t_R  g094(.A1(G12), .A2(new_n165_), .B(new_n167_), .Y(new_n168_));
  XOR2x2_ASAP7_75t_R  g095(.A(new_n85_), .B(new_n96_), .Y(new_n169_));
  XNOR2x2_ASAP7_75t_R g096(.A(new_n74_), .B(new_n169_), .Y(new_n170_));
  XOR2x2_ASAP7_75t_R  g097(.A(G1), .B(new_n169_), .Y(new_n171_));
  NOR2x1_ASAP7_75t_R  g098(.A(G4), .B(new_n171_), .Y(new_n172_));
  AO21x1_ASAP7_75t_R  g099(.A1(G4), .A2(new_n170_), .B(new_n172_), .Y(new_n173_));
  XOR2x2_ASAP7_75t_R  g100(.A(new_n168_), .B(new_n173_), .Y(new_n174_));
  XOR2x2_ASAP7_75t_R  g101(.A(new_n168_), .B(new_n173_), .Y(new_n175_));
  NOR2x1_ASAP7_75t_R  g102(.A(new_n163_), .B(new_n175_), .Y(new_n176_));
  AO21x1_ASAP7_75t_R  g103(.A1(new_n163_), .A2(new_n174_), .B(new_n176_), .Y(new_n177_));
  INVx1_ASAP7_75t_R   g104(.A(new_n177_), .Y(new_n178_));
  NOR2x1_ASAP7_75t_R  g105(.A(new_n156_), .B(new_n177_), .Y(new_n179_));
  INVx1_ASAP7_75t_R   g106(.A(new_n179_), .Y(new_n180_));
  XNOR2x2_ASAP7_75t_R g107(.A(new_n83_), .B(new_n88_), .Y(new_n181_));
  XOR2x2_ASAP7_75t_R  g108(.A(new_n92_), .B(new_n97_), .Y(new_n182_));
  NAND2x1_ASAP7_75t_R g109(.A(G38), .B(G41), .Y(new_n183_));
  XNOR2x2_ASAP7_75t_R g110(.A(new_n182_), .B(new_n183_), .Y(new_n184_));
  XNOR2x2_ASAP7_75t_R g111(.A(new_n182_), .B(new_n183_), .Y(new_n185_));
  NOR2x1_ASAP7_75t_R  g112(.A(new_n181_), .B(new_n185_), .Y(new_n186_));
  AO21x1_ASAP7_75t_R  g113(.A1(new_n181_), .A2(new_n184_), .B(new_n186_), .Y(new_n187_));
  XNOR2x2_ASAP7_75t_R g114(.A(new_n145_), .B(new_n187_), .Y(new_n188_));
  XNOR2x2_ASAP7_75t_R g115(.A(new_n145_), .B(new_n187_), .Y(new_n189_));
  NOR2x1_ASAP7_75t_R  g116(.A(new_n168_), .B(new_n189_), .Y(new_n190_));
  AO21x1_ASAP7_75t_R  g117(.A1(new_n168_), .A2(new_n188_), .B(new_n190_), .Y(new_n191_));
  INVx1_ASAP7_75t_R   g118(.A(new_n191_), .Y(new_n192_));
  XNOR2x2_ASAP7_75t_R g119(.A(new_n82_), .B(new_n87_), .Y(new_n193_));
  XOR2x2_ASAP7_75t_R  g120(.A(new_n91_), .B(new_n95_), .Y(new_n194_));
  NAND2x1_ASAP7_75t_R g121(.A(G37), .B(G41), .Y(new_n195_));
  XNOR2x2_ASAP7_75t_R g122(.A(new_n194_), .B(new_n195_), .Y(new_n196_));
  XNOR2x2_ASAP7_75t_R g123(.A(new_n194_), .B(new_n195_), .Y(new_n197_));
  NOR2x1_ASAP7_75t_R  g124(.A(new_n193_), .B(new_n197_), .Y(new_n198_));
  AO21x1_ASAP7_75t_R  g125(.A1(new_n193_), .A2(new_n196_), .B(new_n198_), .Y(new_n199_));
  XNOR2x2_ASAP7_75t_R g126(.A(new_n151_), .B(new_n199_), .Y(new_n200_));
  XOR2x2_ASAP7_75t_R  g127(.A(new_n150_), .B(new_n199_), .Y(new_n201_));
  NOR2x1_ASAP7_75t_R  g128(.A(new_n173_), .B(new_n201_), .Y(new_n202_));
  AO21x1_ASAP7_75t_R  g129(.A1(new_n173_), .A2(new_n200_), .B(new_n202_), .Y(new_n203_));
  INVx1_ASAP7_75t_R   g130(.A(new_n203_), .Y(new_n204_));
  XOR2x2_ASAP7_75t_R  g131(.A(new_n91_), .B(new_n92_), .Y(new_n205_));
  XNOR2x2_ASAP7_75t_R g132(.A(new_n94_), .B(new_n205_), .Y(new_n206_));
  XOR2x2_ASAP7_75t_R  g133(.A(G28), .B(new_n205_), .Y(new_n207_));
  NOR2x1_ASAP7_75t_R  g134(.A(G27), .B(new_n207_), .Y(new_n208_));
  AO21x1_ASAP7_75t_R  g135(.A1(G27), .A2(new_n206_), .B(new_n208_), .Y(new_n209_));
  XNOR2x2_ASAP7_75t_R g136(.A(new_n76_), .B(new_n80_), .Y(new_n210_));
  XOR2x2_ASAP7_75t_R  g137(.A(new_n96_), .B(new_n106_), .Y(new_n211_));
  NAND2x1_ASAP7_75t_R g138(.A(G35), .B(G41), .Y(new_n212_));
  XNOR2x2_ASAP7_75t_R g139(.A(new_n211_), .B(new_n212_), .Y(new_n213_));
  NAND2x1_ASAP7_75t_R g140(.A(new_n210_), .B(new_n213_), .Y(new_n214_));
  XNOR2x2_ASAP7_75t_R g141(.A(new_n211_), .B(new_n212_), .Y(new_n215_));
  OA21x2_ASAP7_75t_R  g142(.A1(new_n210_), .A2(new_n215_), .B(new_n214_), .Y(new_n216_));
  XNOR2x2_ASAP7_75t_R g143(.A(new_n113_), .B(new_n216_), .Y(new_n217_));
  XNOR2x2_ASAP7_75t_R g144(.A(new_n113_), .B(new_n216_), .Y(new_n218_));
  NOR2x1_ASAP7_75t_R  g145(.A(new_n209_), .B(new_n218_), .Y(new_n219_));
  AO21x1_ASAP7_75t_R  g146(.A1(new_n209_), .A2(new_n217_), .B(new_n219_), .Y(new_n220_));
  INVx1_ASAP7_75t_R   g147(.A(new_n220_), .Y(new_n221_));
  XOR2x2_ASAP7_75t_R  g148(.A(new_n95_), .B(new_n97_), .Y(new_n222_));
  XNOR2x2_ASAP7_75t_R g149(.A(new_n99_), .B(new_n222_), .Y(new_n223_));
  XOR2x2_ASAP7_75t_R  g150(.A(G32), .B(new_n222_), .Y(new_n224_));
  NOR2x1_ASAP7_75t_R  g151(.A(G31), .B(new_n224_), .Y(new_n225_));
  AO21x1_ASAP7_75t_R  g152(.A1(G31), .A2(new_n223_), .B(new_n225_), .Y(new_n226_));
  XNOR2x2_ASAP7_75t_R g153(.A(new_n77_), .B(new_n102_), .Y(new_n227_));
  XOR2x2_ASAP7_75t_R  g154(.A(new_n81_), .B(new_n107_), .Y(new_n228_));
  NAND2x1_ASAP7_75t_R g155(.A(G36), .B(G41), .Y(new_n229_));
  XNOR2x2_ASAP7_75t_R g156(.A(new_n228_), .B(new_n229_), .Y(new_n230_));
  NAND2x1_ASAP7_75t_R g157(.A(new_n227_), .B(new_n230_), .Y(new_n231_));
  XNOR2x2_ASAP7_75t_R g158(.A(new_n228_), .B(new_n229_), .Y(new_n232_));
  OA21x2_ASAP7_75t_R  g159(.A1(new_n227_), .A2(new_n232_), .B(new_n231_), .Y(new_n233_));
  XNOR2x2_ASAP7_75t_R g160(.A(new_n118_), .B(new_n233_), .Y(new_n234_));
  XOR2x2_ASAP7_75t_R  g161(.A(new_n119_), .B(new_n233_), .Y(new_n235_));
  NOR2x1_ASAP7_75t_R  g162(.A(new_n226_), .B(new_n235_), .Y(new_n236_));
  AO21x1_ASAP7_75t_R  g163(.A1(new_n226_), .A2(new_n234_), .B(new_n236_), .Y(new_n237_));
  INVx1_ASAP7_75t_R   g164(.A(new_n237_), .Y(new_n238_));
  XNOR2x2_ASAP7_75t_R g165(.A(new_n85_), .B(new_n105_), .Y(new_n239_));
  AO21x1_ASAP7_75t_R  g166(.A1(G34), .A2(new_n103_), .B(new_n101_), .Y(new_n240_));
  OR3x1_ASAP7_75t_R   g167(.A(new_n101_), .B(new_n103_), .C(new_n239_), .Y(new_n241_));
  INVx1_ASAP7_75t_R   g168(.A(new_n241_), .Y(new_n242_));
  AO21x1_ASAP7_75t_R  g169(.A1(new_n239_), .A2(new_n240_), .B(new_n242_), .Y(new_n243_));
  XNOR2x2_ASAP7_75t_R g170(.A(new_n79_), .B(new_n243_), .Y(new_n244_));
  XOR2x2_ASAP7_75t_R  g171(.A(G14), .B(new_n243_), .Y(new_n245_));
  NOR2x1_ASAP7_75t_R  g172(.A(G10), .B(new_n245_), .Y(new_n246_));
  AO21x1_ASAP7_75t_R  g173(.A1(G10), .A2(new_n244_), .B(new_n246_), .Y(new_n247_));
  XOR2x2_ASAP7_75t_R  g174(.A(new_n226_), .B(new_n247_), .Y(new_n248_));
  XOR2x2_ASAP7_75t_R  g175(.A(new_n226_), .B(new_n247_), .Y(new_n249_));
  NOR2x1_ASAP7_75t_R  g176(.A(new_n209_), .B(new_n249_), .Y(new_n250_));
  AO21x1_ASAP7_75t_R  g177(.A1(new_n209_), .A2(new_n248_), .B(new_n250_), .Y(new_n251_));
  INVx1_ASAP7_75t_R   g178(.A(new_n251_), .Y(new_n252_));
  NOR2x1_ASAP7_75t_R  g179(.A(new_n132_), .B(new_n252_), .Y(new_n253_));
  INVx1_ASAP7_75t_R   g180(.A(new_n253_), .Y(new_n254_));
  NOR2x1_ASAP7_75t_R  g181(.A(new_n133_), .B(new_n251_), .Y(new_n255_));
  INVx1_ASAP7_75t_R   g182(.A(new_n255_), .Y(new_n256_));
  NOR2x1_ASAP7_75t_R  g183(.A(new_n253_), .B(new_n255_), .Y(new_n257_));
  OR3x1_ASAP7_75t_R   g184(.A(new_n221_), .B(new_n238_), .C(new_n257_), .Y(new_n258_));
  INVx1_ASAP7_75t_R   g185(.A(new_n258_), .Y(new_n259_));
  XOR2x2_ASAP7_75t_R  g186(.A(new_n221_), .B(new_n237_), .Y(new_n260_));
  OR3x1_ASAP7_75t_R   g187(.A(new_n252_), .B(new_n260_), .C(new_n133_), .Y(new_n261_));
  OA21x2_ASAP7_75t_R  g188(.A1(new_n259_), .A2(new_n261_), .B(new_n258_), .Y(new_n262_));
  OR3x1_ASAP7_75t_R   g189(.A(new_n192_), .B(new_n203_), .C(new_n262_), .Y(new_n263_));
  OR3x1_ASAP7_75t_R   g190(.A(new_n156_), .B(new_n177_), .C(new_n263_), .Y(new_n264_));
  INVx1_ASAP7_75t_R   g191(.A(new_n264_), .Y(new_n265_));
  AND3x1_ASAP7_75t_R  g192(.A(new_n133_), .B(new_n265_), .C(G1), .Y(new_n266_));
  AO21x1_ASAP7_75t_R  g193(.A1(new_n132_), .A2(new_n265_), .B(new_n264_), .Y(new_n267_));
  AO21x1_ASAP7_75t_R  g194(.A1(new_n74_), .A2(new_n267_), .B(new_n266_), .Y(G1324));
  AND3x1_ASAP7_75t_R  g195(.A(new_n252_), .B(new_n265_), .C(G2), .Y(new_n269_));
  AO21x1_ASAP7_75t_R  g196(.A1(new_n251_), .A2(new_n265_), .B(new_n264_), .Y(new_n270_));
  AO21x1_ASAP7_75t_R  g197(.A1(new_n85_), .A2(new_n270_), .B(new_n269_), .Y(G1325));
  AND3x1_ASAP7_75t_R  g198(.A(new_n221_), .B(new_n265_), .C(G3), .Y(new_n272_));
  AO21x1_ASAP7_75t_R  g199(.A1(new_n220_), .A2(new_n265_), .B(new_n264_), .Y(new_n273_));
  AO21x1_ASAP7_75t_R  g200(.A1(new_n96_), .A2(new_n273_), .B(new_n272_), .Y(G1326));
  AND3x1_ASAP7_75t_R  g201(.A(new_n238_), .B(new_n265_), .C(G4), .Y(new_n275_));
  AO21x1_ASAP7_75t_R  g202(.A1(new_n237_), .A2(new_n265_), .B(new_n264_), .Y(new_n276_));
  AO21x1_ASAP7_75t_R  g203(.A1(new_n102_), .A2(new_n276_), .B(new_n275_), .Y(G1327));
  OR3x1_ASAP7_75t_R   g204(.A(new_n155_), .B(new_n178_), .C(new_n263_), .Y(new_n278_));
  INVx1_ASAP7_75t_R   g205(.A(new_n278_), .Y(new_n279_));
  AND3x1_ASAP7_75t_R  g206(.A(new_n133_), .B(new_n279_), .C(G5), .Y(new_n280_));
  AO21x1_ASAP7_75t_R  g207(.A1(new_n132_), .A2(new_n279_), .B(new_n278_), .Y(new_n281_));
  AO21x1_ASAP7_75t_R  g208(.A1(new_n104_), .A2(new_n281_), .B(new_n280_), .Y(G1328));
  AND3x1_ASAP7_75t_R  g209(.A(new_n252_), .B(new_n279_), .C(G6), .Y(new_n283_));
  AO21x1_ASAP7_75t_R  g210(.A1(new_n251_), .A2(new_n279_), .B(new_n278_), .Y(new_n284_));
  AO21x1_ASAP7_75t_R  g211(.A1(new_n105_), .A2(new_n284_), .B(new_n283_), .Y(G1329));
  AND3x1_ASAP7_75t_R  g212(.A(new_n221_), .B(new_n279_), .C(G7), .Y(new_n286_));
  AO21x1_ASAP7_75t_R  g213(.A1(new_n220_), .A2(new_n279_), .B(new_n278_), .Y(new_n287_));
  AO21x1_ASAP7_75t_R  g214(.A1(new_n106_), .A2(new_n287_), .B(new_n286_), .Y(G1330));
  AND3x1_ASAP7_75t_R  g215(.A(new_n238_), .B(new_n279_), .C(G8), .Y(new_n289_));
  AO21x1_ASAP7_75t_R  g216(.A1(new_n237_), .A2(new_n279_), .B(new_n278_), .Y(new_n290_));
  AO21x1_ASAP7_75t_R  g217(.A1(new_n107_), .A2(new_n290_), .B(new_n289_), .Y(G1331));
  NAND2x1_ASAP7_75t_R g218(.A(new_n192_), .B(new_n203_), .Y(new_n292_));
  OR3x1_ASAP7_75t_R   g219(.A(new_n180_), .B(new_n262_), .C(new_n292_), .Y(new_n293_));
  INVx1_ASAP7_75t_R   g220(.A(new_n293_), .Y(new_n294_));
  AND3x1_ASAP7_75t_R  g221(.A(new_n133_), .B(new_n294_), .C(G9), .Y(new_n295_));
  AO21x1_ASAP7_75t_R  g222(.A1(new_n132_), .A2(new_n294_), .B(new_n293_), .Y(new_n296_));
  AO21x1_ASAP7_75t_R  g223(.A1(new_n108_), .A2(new_n296_), .B(new_n295_), .Y(G1332));
  AND3x1_ASAP7_75t_R  g224(.A(new_n252_), .B(new_n294_), .C(G10), .Y(new_n298_));
  AO21x1_ASAP7_75t_R  g225(.A1(new_n251_), .A2(new_n294_), .B(new_n293_), .Y(new_n299_));
  AO21x1_ASAP7_75t_R  g226(.A1(new_n75_), .A2(new_n299_), .B(new_n298_), .Y(G1333));
  AND3x1_ASAP7_75t_R  g227(.A(new_n221_), .B(new_n294_), .C(G11), .Y(new_n301_));
  AO21x1_ASAP7_75t_R  g228(.A1(new_n220_), .A2(new_n294_), .B(new_n293_), .Y(new_n302_));
  AO21x1_ASAP7_75t_R  g229(.A1(new_n76_), .A2(new_n302_), .B(new_n301_), .Y(G1334));
  AND3x1_ASAP7_75t_R  g230(.A(new_n238_), .B(new_n294_), .C(G12), .Y(new_n304_));
  AO21x1_ASAP7_75t_R  g231(.A1(new_n237_), .A2(new_n294_), .B(new_n293_), .Y(new_n305_));
  AO21x1_ASAP7_75t_R  g232(.A1(new_n77_), .A2(new_n305_), .B(new_n304_), .Y(G1335));
  OR3x1_ASAP7_75t_R   g233(.A(new_n191_), .B(new_n204_), .C(new_n262_), .Y(new_n307_));
  OR3x1_ASAP7_75t_R   g234(.A(new_n155_), .B(new_n178_), .C(new_n307_), .Y(new_n308_));
  INVx1_ASAP7_75t_R   g235(.A(new_n308_), .Y(new_n309_));
  AND3x1_ASAP7_75t_R  g236(.A(new_n133_), .B(new_n309_), .C(G13), .Y(new_n310_));
  AO21x1_ASAP7_75t_R  g237(.A1(new_n132_), .A2(new_n309_), .B(new_n308_), .Y(new_n311_));
  AO21x1_ASAP7_75t_R  g238(.A1(new_n78_), .A2(new_n311_), .B(new_n310_), .Y(G1336));
  AND3x1_ASAP7_75t_R  g239(.A(new_n252_), .B(new_n309_), .C(G14), .Y(new_n313_));
  AO21x1_ASAP7_75t_R  g240(.A1(new_n251_), .A2(new_n309_), .B(new_n308_), .Y(new_n314_));
  AO21x1_ASAP7_75t_R  g241(.A1(new_n79_), .A2(new_n314_), .B(new_n313_), .Y(G1337));
  AND3x1_ASAP7_75t_R  g242(.A(new_n221_), .B(new_n309_), .C(G15), .Y(new_n316_));
  AO21x1_ASAP7_75t_R  g243(.A1(new_n220_), .A2(new_n309_), .B(new_n308_), .Y(new_n317_));
  AO21x1_ASAP7_75t_R  g244(.A1(new_n80_), .A2(new_n317_), .B(new_n316_), .Y(G1338));
  AND3x1_ASAP7_75t_R  g245(.A(new_n238_), .B(new_n309_), .C(G16), .Y(new_n319_));
  AO21x1_ASAP7_75t_R  g246(.A1(new_n237_), .A2(new_n309_), .B(new_n308_), .Y(new_n320_));
  AO21x1_ASAP7_75t_R  g247(.A1(new_n81_), .A2(new_n320_), .B(new_n319_), .Y(G1339));
  OA21x2_ASAP7_75t_R  g248(.A1(new_n192_), .A2(new_n203_), .B(new_n292_), .Y(new_n322_));
  OR3x1_ASAP7_75t_R   g249(.A(new_n156_), .B(new_n178_), .C(new_n322_), .Y(new_n323_));
  INVx1_ASAP7_75t_R   g250(.A(new_n323_), .Y(new_n324_));
  AO21x1_ASAP7_75t_R  g251(.A1(new_n156_), .A2(new_n177_), .B(new_n179_), .Y(new_n325_));
  AND3x1_ASAP7_75t_R  g252(.A(new_n191_), .B(new_n203_), .C(new_n325_), .Y(new_n326_));
  AOI21x1_ASAP7_75t_R g253(.A1(new_n323_), .A2(new_n326_), .B(new_n324_), .Y(new_n327_));
  OR2x4_ASAP7_75t_R   g254(.A(new_n238_), .B(new_n327_), .Y(new_n328_));
  OR3x1_ASAP7_75t_R   g255(.A(new_n220_), .B(new_n254_), .C(new_n328_), .Y(new_n329_));
  INVx1_ASAP7_75t_R   g256(.A(new_n329_), .Y(new_n330_));
  AND3x1_ASAP7_75t_R  g257(.A(new_n204_), .B(new_n330_), .C(G17), .Y(new_n331_));
  AO21x1_ASAP7_75t_R  g258(.A1(new_n203_), .A2(new_n330_), .B(new_n329_), .Y(new_n332_));
  AO21x1_ASAP7_75t_R  g259(.A1(new_n82_), .A2(new_n332_), .B(new_n331_), .Y(G1340));
  AND3x1_ASAP7_75t_R  g260(.A(new_n192_), .B(new_n330_), .C(G18), .Y(new_n334_));
  AO21x1_ASAP7_75t_R  g261(.A1(new_n191_), .A2(new_n330_), .B(new_n329_), .Y(new_n335_));
  AO21x1_ASAP7_75t_R  g262(.A1(new_n83_), .A2(new_n335_), .B(new_n334_), .Y(G1341));
  AND3x1_ASAP7_75t_R  g263(.A(new_n178_), .B(new_n330_), .C(G19), .Y(new_n337_));
  AO21x1_ASAP7_75t_R  g264(.A1(new_n177_), .A2(new_n330_), .B(new_n329_), .Y(new_n338_));
  AO21x1_ASAP7_75t_R  g265(.A1(new_n84_), .A2(new_n338_), .B(new_n337_), .Y(G1342));
  AND3x1_ASAP7_75t_R  g266(.A(new_n156_), .B(new_n330_), .C(G20), .Y(new_n340_));
  AO21x1_ASAP7_75t_R  g267(.A1(new_n155_), .A2(new_n330_), .B(new_n329_), .Y(new_n341_));
  AO21x1_ASAP7_75t_R  g268(.A1(new_n86_), .A2(new_n341_), .B(new_n340_), .Y(G1343));
  OR3x1_ASAP7_75t_R   g269(.A(new_n237_), .B(new_n327_), .C(new_n203_), .Y(new_n343_));
  OR3x1_ASAP7_75t_R   g270(.A(new_n221_), .B(new_n254_), .C(new_n343_), .Y(new_n344_));
  XNOR2x2_ASAP7_75t_R g271(.A(new_n87_), .B(new_n344_), .Y(G1344));
  OR3x1_ASAP7_75t_R   g272(.A(new_n237_), .B(new_n327_), .C(new_n191_), .Y(new_n346_));
  OR3x1_ASAP7_75t_R   g273(.A(new_n221_), .B(new_n254_), .C(new_n346_), .Y(new_n347_));
  XNOR2x2_ASAP7_75t_R g274(.A(new_n88_), .B(new_n347_), .Y(G1345));
  OR3x1_ASAP7_75t_R   g275(.A(new_n237_), .B(new_n327_), .C(new_n177_), .Y(new_n349_));
  OR3x1_ASAP7_75t_R   g276(.A(new_n221_), .B(new_n254_), .C(new_n349_), .Y(new_n350_));
  XNOR2x2_ASAP7_75t_R g277(.A(new_n89_), .B(new_n350_), .Y(G1346));
  OR3x1_ASAP7_75t_R   g278(.A(new_n237_), .B(new_n327_), .C(new_n155_), .Y(new_n352_));
  OR3x1_ASAP7_75t_R   g279(.A(new_n221_), .B(new_n254_), .C(new_n352_), .Y(new_n353_));
  XNOR2x2_ASAP7_75t_R g280(.A(new_n90_), .B(new_n353_), .Y(G1347));
  OR3x1_ASAP7_75t_R   g281(.A(new_n220_), .B(new_n256_), .C(new_n328_), .Y(new_n355_));
  INVx1_ASAP7_75t_R   g282(.A(new_n355_), .Y(new_n356_));
  AND3x1_ASAP7_75t_R  g283(.A(new_n204_), .B(new_n356_), .C(G25), .Y(new_n357_));
  AO21x1_ASAP7_75t_R  g284(.A1(new_n203_), .A2(new_n356_), .B(new_n355_), .Y(new_n358_));
  AO21x1_ASAP7_75t_R  g285(.A1(new_n91_), .A2(new_n358_), .B(new_n357_), .Y(G1348));
  AND3x1_ASAP7_75t_R  g286(.A(new_n192_), .B(new_n356_), .C(G26), .Y(new_n360_));
  AO21x1_ASAP7_75t_R  g287(.A1(new_n191_), .A2(new_n356_), .B(new_n355_), .Y(new_n361_));
  AO21x1_ASAP7_75t_R  g288(.A1(new_n92_), .A2(new_n361_), .B(new_n360_), .Y(G1349));
  AND3x1_ASAP7_75t_R  g289(.A(new_n178_), .B(new_n356_), .C(G27), .Y(new_n363_));
  AO21x1_ASAP7_75t_R  g290(.A1(new_n177_), .A2(new_n356_), .B(new_n355_), .Y(new_n364_));
  AO21x1_ASAP7_75t_R  g291(.A1(new_n93_), .A2(new_n364_), .B(new_n363_), .Y(G1350));
  AND3x1_ASAP7_75t_R  g292(.A(new_n156_), .B(new_n356_), .C(G28), .Y(new_n366_));
  AO21x1_ASAP7_75t_R  g293(.A1(new_n155_), .A2(new_n356_), .B(new_n355_), .Y(new_n367_));
  AO21x1_ASAP7_75t_R  g294(.A1(new_n94_), .A2(new_n367_), .B(new_n366_), .Y(G1351));
  OR3x1_ASAP7_75t_R   g295(.A(new_n221_), .B(new_n256_), .C(new_n343_), .Y(new_n369_));
  XNOR2x2_ASAP7_75t_R g296(.A(new_n95_), .B(new_n369_), .Y(G1352));
  OR3x1_ASAP7_75t_R   g297(.A(new_n221_), .B(new_n256_), .C(new_n346_), .Y(new_n371_));
  XNOR2x2_ASAP7_75t_R g298(.A(new_n97_), .B(new_n371_), .Y(G1353));
  OR3x1_ASAP7_75t_R   g299(.A(new_n221_), .B(new_n256_), .C(new_n349_), .Y(new_n373_));
  XNOR2x2_ASAP7_75t_R g300(.A(new_n98_), .B(new_n373_), .Y(G1354));
  OR3x1_ASAP7_75t_R   g301(.A(new_n221_), .B(new_n256_), .C(new_n352_), .Y(new_n375_));
  XNOR2x2_ASAP7_75t_R g302(.A(new_n99_), .B(new_n375_), .Y(G1355));
endmodule


