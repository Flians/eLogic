// Benchmark "/home/flynn/workplace/MIGBalance/results_v2/eqmap_adapter_3in_verified_20261007/c1908/eqmap_lut_amap/stage" written by ABC on Wed Oct  7 16:32:20 2026

module \/home/flynn/workplace/MIGBalance/results_v2/eqmap_adapter_3in_verified_20261007/c1908/eqmap_lut_amap/stage  ( 
    G1, G10, G11, G12, G13, G14, G15, G16, G17, G18, G19, G2, G20, G21,
    G22, G23, G24, G25, G26, G27, G28, G29, G3, G30, G31, G32, G33, G4, G5,
    G6, G7, G8, G9,
    G1884, G1885, G1886, G1887, G1888, G1889, G1890, G1891, G1892, G1893,
    G1894, G1895, G1896, G1897, G1898, G1899, G1900, G1901, G1902, G1903,
    G1904, G1905, G1906, G1907, G1908  );
  input  G1, G10, G11, G12, G13, G14, G15, G16, G17, G18, G19, G2, G20,
    G21, G22, G23, G24, G25, G26, G27, G28, G29, G3, G30, G31, G32, G33,
    G4, G5, G6, G7, G8, G9;
  output G1884, G1885, G1886, G1887, G1888, G1889, G1890, G1891, G1892, G1893,
    G1894, G1895, G1896, G1897, G1898, G1899, G1900, G1901, G1902, G1903,
    G1904, G1905, G1906, G1907, G1908;
  wire new_n59_, new_n60_, new_n61_, new_n62_, new_n63_, new_n64_, new_n65_,
    new_n66_, new_n67_, new_n68_, new_n69_, new_n70_, new_n71_, new_n72_,
    new_n73_, new_n74_, new_n75_, new_n76_, new_n77_, new_n78_, new_n79_,
    new_n80_, new_n81_, new_n82_, new_n83_, new_n84_, new_n85_, new_n86_,
    new_n87_, new_n88_, new_n89_, new_n90_, new_n91_, new_n92_, new_n93_,
    new_n94_, new_n95_, new_n96_, new_n97_, new_n98_, new_n99_, new_n100_,
    new_n101_, new_n102_, new_n103_, new_n104_, new_n105_, new_n106_,
    new_n107_, new_n108_, new_n109_, new_n110_, new_n111_, new_n112_,
    new_n113_, new_n114_, new_n115_, new_n116_, new_n117_, new_n118_,
    new_n119_, new_n120_, new_n121_, new_n122_, new_n123_, new_n124_,
    new_n125_, new_n126_, new_n127_, new_n128_, new_n129_, new_n130_,
    new_n131_, new_n132_, new_n133_, new_n134_, new_n135_, new_n136_,
    new_n137_, new_n138_, new_n139_, new_n140_, new_n141_, new_n142_,
    new_n143_, new_n144_, new_n145_, new_n146_, new_n147_, new_n148_,
    new_n149_, new_n150_, new_n151_, new_n152_, new_n153_, new_n154_,
    new_n155_, new_n156_, new_n157_, new_n158_, new_n159_, new_n160_,
    new_n161_, new_n162_, new_n163_, new_n164_, new_n165_, new_n166_,
    new_n167_, new_n168_, new_n169_, new_n170_, new_n171_, new_n172_,
    new_n173_, new_n174_, new_n175_, new_n176_, new_n177_, new_n178_,
    new_n179_, new_n180_, new_n181_, new_n182_, new_n183_, new_n184_,
    new_n185_, new_n186_, new_n187_, new_n188_, new_n189_, new_n190_,
    new_n191_, new_n192_, new_n193_, new_n194_, new_n195_, new_n196_,
    new_n197_, new_n198_, new_n199_, new_n200_, new_n201_, new_n202_,
    new_n203_, new_n204_, new_n205_, new_n206_, new_n207_, new_n208_,
    new_n209_, new_n210_, new_n211_, new_n212_, new_n213_, new_n214_,
    new_n215_, new_n216_, new_n217_, new_n222_, new_n223_, new_n224_,
    new_n225_, new_n226_, new_n227_, new_n231_, new_n232_, new_n233_,
    new_n234_, new_n235_, new_n236_, new_n238_, new_n240_, new_n242_,
    new_n244_, new_n245_, new_n246_, new_n248_, new_n249_, new_n250_,
    new_n251_, new_n252_, new_n257_, new_n258_, new_n259_, new_n260_,
    new_n261_, new_n262_, new_n263_, new_n264_, new_n265_, new_n266_,
    new_n267_, new_n269_, new_n270_, new_n271_, new_n272_, new_n273_,
    new_n274_, new_n275_, new_n276_, new_n277_, new_n278_, new_n280_,
    new_n281_, new_n282_, new_n284_, new_n285_, new_n287_, new_n289_,
    new_n290_, new_n291_, new_n293_, new_n294_, new_n295_, new_n296_,
    new_n297_, new_n298_, new_n300_, new_n301_, new_n302_, new_n303_,
    new_n304_, new_n305_, new_n306_, new_n307_, new_n309_, new_n310_,
    new_n311_, new_n312_, new_n313_;
  INVx1_ASAP7_75t_R   g000(.A(G1), .Y(new_n59_));
  INVx1_ASAP7_75t_R   g001(.A(G11), .Y(new_n60_));
  INVx1_ASAP7_75t_R   g002(.A(G12), .Y(new_n61_));
  INVx1_ASAP7_75t_R   g003(.A(G13), .Y(new_n62_));
  INVx1_ASAP7_75t_R   g004(.A(G14), .Y(new_n63_));
  INVx1_ASAP7_75t_R   g005(.A(G15), .Y(new_n64_));
  INVx1_ASAP7_75t_R   g006(.A(G16), .Y(new_n65_));
  INVx1_ASAP7_75t_R   g007(.A(G17), .Y(new_n66_));
  INVx1_ASAP7_75t_R   g008(.A(G18), .Y(new_n67_));
  INVx1_ASAP7_75t_R   g009(.A(G2), .Y(new_n68_));
  INVx1_ASAP7_75t_R   g010(.A(G20), .Y(new_n69_));
  INVx1_ASAP7_75t_R   g011(.A(G21), .Y(new_n70_));
  INVx1_ASAP7_75t_R   g012(.A(G22), .Y(new_n71_));
  INVx1_ASAP7_75t_R   g013(.A(G23), .Y(new_n72_));
  INVx1_ASAP7_75t_R   g014(.A(G25), .Y(new_n73_));
  INVx1_ASAP7_75t_R   g015(.A(G28), .Y(new_n74_));
  INVx1_ASAP7_75t_R   g016(.A(G3), .Y(new_n75_));
  INVx1_ASAP7_75t_R   g017(.A(G30), .Y(new_n76_));
  INVx1_ASAP7_75t_R   g018(.A(G31), .Y(new_n77_));
  INVx1_ASAP7_75t_R   g019(.A(G32), .Y(new_n78_));
  INVx1_ASAP7_75t_R   g020(.A(G33), .Y(new_n79_));
  INVx1_ASAP7_75t_R   g021(.A(G4), .Y(new_n80_));
  INVx1_ASAP7_75t_R   g022(.A(G5), .Y(new_n81_));
  INVx1_ASAP7_75t_R   g023(.A(G7), .Y(new_n82_));
  INVx1_ASAP7_75t_R   g024(.A(G9), .Y(new_n83_));
  AND3x1_ASAP7_75t_R  g025(.A(new_n72_), .B(new_n79_), .C(G19), .Y(new_n84_));
  XNOR2x2_ASAP7_75t_R g026(.A(new_n61_), .B(new_n64_), .Y(new_n85_));
  NAND2x1_ASAP7_75t_R g027(.A(G10), .B(new_n85_), .Y(new_n86_));
  XOR2x2_ASAP7_75t_R  g028(.A(G12), .B(new_n64_), .Y(new_n87_));
  OA21x2_ASAP7_75t_R  g029(.A1(G10), .A2(new_n87_), .B(new_n86_), .Y(new_n88_));
  XNOR2x2_ASAP7_75t_R g030(.A(G3), .B(G6), .Y(new_n89_));
  XOR2x2_ASAP7_75t_R  g031(.A(new_n75_), .B(G6), .Y(new_n90_));
  NOR2x1_ASAP7_75t_R  g032(.A(G8), .B(new_n90_), .Y(new_n91_));
  AO21x1_ASAP7_75t_R  g033(.A1(G8), .A2(new_n89_), .B(new_n91_), .Y(new_n92_));
  XNOR2x2_ASAP7_75t_R g034(.A(new_n88_), .B(new_n92_), .Y(new_n93_));
  XNOR2x2_ASAP7_75t_R g035(.A(new_n88_), .B(new_n92_), .Y(new_n94_));
  NOR2x1_ASAP7_75t_R  g036(.A(new_n84_), .B(new_n94_), .Y(new_n95_));
  AO21x1_ASAP7_75t_R  g037(.A1(new_n84_), .A2(new_n93_), .B(new_n95_), .Y(new_n96_));
  OR3x1_ASAP7_75t_R   g038(.A(G31), .B(new_n96_), .C(new_n74_), .Y(new_n97_));
  NAND2x1_ASAP7_75t_R g039(.A(new_n77_), .B(new_n96_), .Y(new_n98_));
  AO21x1_ASAP7_75t_R  g040(.A1(new_n77_), .A2(new_n98_), .B(G28), .Y(new_n99_));
  XNOR2x2_ASAP7_75t_R g041(.A(new_n68_), .B(new_n81_), .Y(new_n100_));
  XOR2x2_ASAP7_75t_R  g042(.A(new_n68_), .B(G5), .Y(new_n101_));
  NOR2x1_ASAP7_75t_R  g043(.A(G8), .B(new_n101_), .Y(new_n102_));
  AO21x1_ASAP7_75t_R  g044(.A1(G8), .A2(new_n100_), .B(new_n102_), .Y(new_n103_));
  INVx1_ASAP7_75t_R   g045(.A(new_n103_), .Y(new_n104_));
  XNOR2x2_ASAP7_75t_R g046(.A(new_n60_), .B(new_n64_), .Y(new_n105_));
  OR3x1_ASAP7_75t_R   g047(.A(G24), .B(G33), .C(new_n67_), .Y(new_n106_));
  XNOR2x2_ASAP7_75t_R g048(.A(new_n63_), .B(new_n65_), .Y(new_n107_));
  XOR2x2_ASAP7_75t_R  g049(.A(new_n63_), .B(G16), .Y(new_n108_));
  NOR2x1_ASAP7_75t_R  g050(.A(G9), .B(new_n108_), .Y(new_n109_));
  AO21x1_ASAP7_75t_R  g051(.A1(G9), .A2(new_n107_), .B(new_n109_), .Y(new_n110_));
  XNOR2x2_ASAP7_75t_R g052(.A(new_n106_), .B(new_n110_), .Y(new_n111_));
  XNOR2x2_ASAP7_75t_R g053(.A(new_n106_), .B(new_n110_), .Y(new_n112_));
  NOR2x1_ASAP7_75t_R  g054(.A(new_n105_), .B(new_n112_), .Y(new_n113_));
  AO21x1_ASAP7_75t_R  g055(.A1(new_n105_), .A2(new_n111_), .B(new_n113_), .Y(new_n114_));
  INVx1_ASAP7_75t_R   g056(.A(new_n114_), .Y(new_n115_));
  AND3x1_ASAP7_75t_R  g057(.A(new_n77_), .B(new_n115_), .C(new_n103_), .Y(new_n116_));
  AND3x1_ASAP7_75t_R  g058(.A(new_n77_), .B(new_n114_), .C(new_n104_), .Y(new_n117_));
  NOR2x1_ASAP7_75t_R  g059(.A(new_n116_), .B(new_n117_), .Y(new_n118_));
  XNOR2x2_ASAP7_75t_R g060(.A(G27), .B(new_n118_), .Y(new_n119_));
  AO21x1_ASAP7_75t_R  g061(.A1(new_n97_), .A2(new_n99_), .B(new_n119_), .Y(new_n120_));
  AO21x1_ASAP7_75t_R  g062(.A1(new_n72_), .A2(G24), .B(G32), .Y(new_n121_));
  NOR2x1_ASAP7_75t_R  g063(.A(G33), .B(new_n121_), .Y(new_n122_));
  INVx1_ASAP7_75t_R   g064(.A(new_n122_), .Y(new_n123_));
  NOR2x1_ASAP7_75t_R  g065(.A(G29), .B(G33), .Y(new_n124_));
  INVx1_ASAP7_75t_R   g066(.A(new_n124_), .Y(new_n125_));
  AO21x1_ASAP7_75t_R  g067(.A1(new_n72_), .A2(G24), .B(G31), .Y(new_n126_));
  OR3x1_ASAP7_75t_R   g068(.A(new_n125_), .B(new_n126_), .C(new_n122_), .Y(new_n127_));
  AO21x1_ASAP7_75t_R  g069(.A1(new_n123_), .A2(new_n127_), .B(new_n120_), .Y(new_n128_));
  INVx1_ASAP7_75t_R   g070(.A(new_n128_), .Y(new_n129_));
  AO21x1_ASAP7_75t_R  g071(.A1(G23), .A2(new_n77_), .B(G31), .Y(new_n130_));
  NAND2x1_ASAP7_75t_R g072(.A(G19), .B(new_n130_), .Y(new_n131_));
  XNOR2x2_ASAP7_75t_R g073(.A(new_n80_), .B(new_n82_), .Y(new_n132_));
  XOR2x2_ASAP7_75t_R  g074(.A(G4), .B(new_n82_), .Y(new_n133_));
  NOR2x1_ASAP7_75t_R  g075(.A(G10), .B(new_n133_), .Y(new_n134_));
  AO21x1_ASAP7_75t_R  g076(.A1(G10), .A2(new_n132_), .B(new_n134_), .Y(new_n135_));
  INVx1_ASAP7_75t_R   g077(.A(new_n135_), .Y(new_n136_));
  OR3x1_ASAP7_75t_R   g078(.A(G23), .B(G33), .C(new_n69_), .Y(new_n137_));
  XNOR2x2_ASAP7_75t_R g079(.A(G13), .B(new_n137_), .Y(new_n138_));
  XOR2x2_ASAP7_75t_R  g080(.A(new_n62_), .B(new_n137_), .Y(new_n139_));
  NOR2x1_ASAP7_75t_R  g081(.A(new_n110_), .B(new_n139_), .Y(new_n140_));
  AO21x1_ASAP7_75t_R  g082(.A1(new_n110_), .A2(new_n138_), .B(new_n140_), .Y(new_n141_));
  OR3x1_ASAP7_75t_R   g083(.A(G31), .B(new_n141_), .C(new_n136_), .Y(new_n142_));
  NAND2x1_ASAP7_75t_R g084(.A(new_n77_), .B(new_n141_), .Y(new_n143_));
  OA21x2_ASAP7_75t_R  g085(.A1(new_n135_), .A2(new_n143_), .B(new_n142_), .Y(new_n144_));
  XOR2x2_ASAP7_75t_R  g086(.A(new_n131_), .B(new_n144_), .Y(new_n145_));
  INVx1_ASAP7_75t_R   g087(.A(new_n145_), .Y(new_n146_));
  AOI21x1_ASAP7_75t_R g088(.A1(G24), .A2(new_n77_), .B(G31), .Y(new_n147_));
  NOR2x1_ASAP7_75t_R  g089(.A(new_n67_), .B(new_n147_), .Y(new_n148_));
  INVx1_ASAP7_75t_R   g090(.A(new_n148_), .Y(new_n149_));
  OR2x4_ASAP7_75t_R   g091(.A(new_n66_), .B(new_n147_), .Y(new_n150_));
  AND3x1_ASAP7_75t_R  g092(.A(G21), .B(new_n79_), .C(G9), .Y(new_n151_));
  AO21x1_ASAP7_75t_R  g093(.A1(G21), .A2(G33), .B(new_n70_), .Y(new_n152_));
  AO21x1_ASAP7_75t_R  g094(.A1(new_n83_), .A2(new_n152_), .B(new_n151_), .Y(new_n153_));
  XNOR2x2_ASAP7_75t_R g095(.A(new_n64_), .B(G16), .Y(new_n154_));
  XOR2x2_ASAP7_75t_R  g096(.A(new_n64_), .B(new_n65_), .Y(new_n155_));
  NOR2x1_ASAP7_75t_R  g097(.A(G10), .B(new_n155_), .Y(new_n156_));
  AO21x1_ASAP7_75t_R  g098(.A1(G10), .A2(new_n154_), .B(new_n156_), .Y(new_n157_));
  INVx1_ASAP7_75t_R   g099(.A(new_n157_), .Y(new_n158_));
  XOR2x2_ASAP7_75t_R  g100(.A(new_n153_), .B(new_n157_), .Y(new_n159_));
  XNOR2x2_ASAP7_75t_R g101(.A(new_n80_), .B(G8), .Y(new_n160_));
  XNOR2x2_ASAP7_75t_R g102(.A(new_n81_), .B(new_n82_), .Y(new_n161_));
  XOR2x2_ASAP7_75t_R  g103(.A(new_n81_), .B(G7), .Y(new_n162_));
  NOR2x1_ASAP7_75t_R  g104(.A(G6), .B(new_n162_), .Y(new_n163_));
  AO21x1_ASAP7_75t_R  g105(.A1(G6), .A2(new_n161_), .B(new_n163_), .Y(new_n164_));
  XNOR2x2_ASAP7_75t_R g106(.A(new_n59_), .B(new_n68_), .Y(new_n165_));
  XOR2x2_ASAP7_75t_R  g107(.A(G1), .B(new_n68_), .Y(new_n166_));
  NOR2x1_ASAP7_75t_R  g108(.A(G3), .B(new_n166_), .Y(new_n167_));
  AO21x1_ASAP7_75t_R  g109(.A1(G3), .A2(new_n165_), .B(new_n167_), .Y(new_n168_));
  XNOR2x2_ASAP7_75t_R g110(.A(new_n164_), .B(new_n168_), .Y(new_n169_));
  XNOR2x2_ASAP7_75t_R g111(.A(new_n164_), .B(new_n168_), .Y(new_n170_));
  NOR2x1_ASAP7_75t_R  g112(.A(new_n160_), .B(new_n170_), .Y(new_n171_));
  AO21x1_ASAP7_75t_R  g113(.A1(new_n160_), .A2(new_n169_), .B(new_n171_), .Y(new_n172_));
  INVx1_ASAP7_75t_R   g114(.A(new_n172_), .Y(new_n173_));
  OR3x1_ASAP7_75t_R   g115(.A(G31), .B(new_n172_), .C(new_n159_), .Y(new_n174_));
  INVx1_ASAP7_75t_R   g116(.A(new_n174_), .Y(new_n175_));
  AND3x1_ASAP7_75t_R  g117(.A(new_n77_), .B(new_n172_), .C(new_n159_), .Y(new_n176_));
  NOR2x1_ASAP7_75t_R  g118(.A(new_n175_), .B(new_n176_), .Y(new_n177_));
  XNOR2x2_ASAP7_75t_R g119(.A(new_n150_), .B(new_n177_), .Y(new_n178_));
  OR3x1_ASAP7_75t_R   g120(.A(new_n67_), .B(new_n147_), .C(new_n178_), .Y(new_n179_));
  INVx1_ASAP7_75t_R   g121(.A(new_n179_), .Y(new_n180_));
  OR3x1_ASAP7_75t_R   g122(.A(G24), .B(G33), .C(new_n66_), .Y(new_n181_));
  XNOR2x2_ASAP7_75t_R g123(.A(new_n59_), .B(new_n181_), .Y(new_n182_));
  XOR2x2_ASAP7_75t_R  g124(.A(G1), .B(new_n181_), .Y(new_n183_));
  NOR2x1_ASAP7_75t_R  g125(.A(new_n164_), .B(new_n183_), .Y(new_n184_));
  AO21x1_ASAP7_75t_R  g126(.A1(new_n164_), .A2(new_n182_), .B(new_n184_), .Y(new_n185_));
  INVx1_ASAP7_75t_R   g127(.A(new_n185_), .Y(new_n186_));
  XNOR2x2_ASAP7_75t_R g128(.A(new_n60_), .B(G13), .Y(new_n187_));
  XOR2x2_ASAP7_75t_R  g129(.A(new_n60_), .B(new_n62_), .Y(new_n188_));
  NOR2x1_ASAP7_75t_R  g130(.A(G12), .B(new_n188_), .Y(new_n189_));
  AO21x1_ASAP7_75t_R  g131(.A1(G12), .A2(new_n187_), .B(new_n189_), .Y(new_n190_));
  INVx1_ASAP7_75t_R   g132(.A(new_n190_), .Y(new_n191_));
  XOR2x2_ASAP7_75t_R  g133(.A(new_n158_), .B(new_n191_), .Y(new_n192_));
  AND3x1_ASAP7_75t_R  g134(.A(new_n77_), .B(new_n192_), .C(new_n185_), .Y(new_n193_));
  NOR2x1_ASAP7_75t_R  g135(.A(G31), .B(new_n192_), .Y(new_n194_));
  AO21x1_ASAP7_75t_R  g136(.A1(new_n186_), .A2(new_n194_), .B(new_n193_), .Y(new_n195_));
  XOR2x2_ASAP7_75t_R  g137(.A(G26), .B(new_n195_), .Y(new_n196_));
  AO21x1_ASAP7_75t_R  g138(.A1(new_n179_), .A2(new_n196_), .B(new_n180_), .Y(new_n197_));
  AO21x1_ASAP7_75t_R  g139(.A1(new_n146_), .A2(new_n197_), .B(new_n145_), .Y(new_n198_));
  INVx1_ASAP7_75t_R   g140(.A(new_n198_), .Y(new_n199_));
  NAND2x1_ASAP7_75t_R g141(.A(G20), .B(new_n130_), .Y(new_n200_));
  INVx1_ASAP7_75t_R   g142(.A(new_n200_), .Y(new_n201_));
  XNOR2x2_ASAP7_75t_R g143(.A(new_n63_), .B(new_n80_), .Y(new_n202_));
  AO21x1_ASAP7_75t_R  g144(.A1(G22), .A2(G33), .B(new_n71_), .Y(new_n203_));
  OR3x1_ASAP7_75t_R   g145(.A(new_n71_), .B(G33), .C(new_n202_), .Y(new_n204_));
  INVx1_ASAP7_75t_R   g146(.A(new_n204_), .Y(new_n205_));
  AO21x1_ASAP7_75t_R  g147(.A1(new_n202_), .A2(new_n203_), .B(new_n205_), .Y(new_n206_));
  XOR2x2_ASAP7_75t_R  g148(.A(new_n192_), .B(new_n206_), .Y(new_n207_));
  XOR2x2_ASAP7_75t_R  g149(.A(new_n192_), .B(new_n206_), .Y(new_n208_));
  NOR2x1_ASAP7_75t_R  g150(.A(new_n168_), .B(new_n208_), .Y(new_n209_));
  AO21x1_ASAP7_75t_R  g151(.A1(new_n168_), .A2(new_n207_), .B(new_n209_), .Y(new_n210_));
  INVx1_ASAP7_75t_R   g152(.A(new_n210_), .Y(new_n211_));
  AO21x1_ASAP7_75t_R  g153(.A1(new_n77_), .A2(new_n210_), .B(new_n73_), .Y(new_n212_));
  OR3x1_ASAP7_75t_R   g154(.A(G31), .B(new_n211_), .C(G25), .Y(new_n213_));
  INVx1_ASAP7_75t_R   g155(.A(new_n213_), .Y(new_n214_));
  AO21x1_ASAP7_75t_R  g156(.A1(new_n212_), .A2(new_n213_), .B(new_n200_), .Y(new_n215_));
  INVx1_ASAP7_75t_R   g157(.A(new_n215_), .Y(new_n216_));
  OR3x1_ASAP7_75t_R   g158(.A(new_n198_), .B(new_n216_), .C(new_n128_), .Y(new_n217_));
  XNOR2x2_ASAP7_75t_R g159(.A(new_n59_), .B(new_n217_), .Y(G1884));
  XNOR2x2_ASAP7_75t_R g160(.A(new_n68_), .B(new_n217_), .Y(G1885));
  XNOR2x2_ASAP7_75t_R g161(.A(new_n75_), .B(new_n217_), .Y(G1886));
  XNOR2x2_ASAP7_75t_R g162(.A(new_n80_), .B(new_n217_), .Y(G1887));
  NAND2x1_ASAP7_75t_R g163(.A(new_n76_), .B(new_n79_), .Y(new_n222_));
  OR3x1_ASAP7_75t_R   g164(.A(new_n126_), .B(new_n222_), .C(new_n122_), .Y(new_n223_));
  AO21x1_ASAP7_75t_R  g165(.A1(new_n123_), .A2(new_n223_), .B(new_n120_), .Y(new_n224_));
  INVx1_ASAP7_75t_R   g166(.A(new_n224_), .Y(new_n225_));
  OR3x1_ASAP7_75t_R   g167(.A(new_n198_), .B(new_n216_), .C(new_n224_), .Y(new_n226_));
  INVx1_ASAP7_75t_R   g168(.A(new_n226_), .Y(new_n227_));
  XNOR2x2_ASAP7_75t_R g169(.A(G10), .B(new_n227_), .Y(G1888));
  XNOR2x2_ASAP7_75t_R g170(.A(new_n64_), .B(new_n226_), .Y(G1889));
  XNOR2x2_ASAP7_75t_R g171(.A(new_n65_), .B(new_n226_), .Y(G1890));
  AO21x1_ASAP7_75t_R  g172(.A1(G31), .A2(new_n210_), .B(new_n211_), .Y(new_n231_));
  AO21x1_ASAP7_75t_R  g173(.A1(G25), .A2(new_n231_), .B(new_n214_), .Y(new_n232_));
  OR3x1_ASAP7_75t_R   g174(.A(new_n198_), .B(new_n232_), .C(new_n200_), .Y(new_n233_));
  NOR2x1_ASAP7_75t_R  g175(.A(new_n128_), .B(new_n233_), .Y(new_n234_));
  AOI21x1_ASAP7_75t_R g176(.A1(new_n129_), .A2(new_n233_), .B(new_n128_), .Y(new_n235_));
  NOR2x1_ASAP7_75t_R  g177(.A(G5), .B(new_n235_), .Y(new_n236_));
  AO21x1_ASAP7_75t_R  g178(.A1(G5), .A2(new_n234_), .B(new_n236_), .Y(G1891));
  NOR2x1_ASAP7_75t_R  g179(.A(G6), .B(new_n235_), .Y(new_n238_));
  AO21x1_ASAP7_75t_R  g180(.A1(G6), .A2(new_n234_), .B(new_n238_), .Y(G1892));
  NOR2x1_ASAP7_75t_R  g181(.A(G7), .B(new_n235_), .Y(new_n240_));
  AO21x1_ASAP7_75t_R  g182(.A1(G7), .A2(new_n234_), .B(new_n240_), .Y(G1893));
  NOR2x1_ASAP7_75t_R  g183(.A(G8), .B(new_n235_), .Y(new_n242_));
  AO21x1_ASAP7_75t_R  g184(.A1(G8), .A2(new_n234_), .B(new_n242_), .Y(G1894));
  OR3x1_ASAP7_75t_R   g185(.A(new_n224_), .B(new_n233_), .C(new_n83_), .Y(new_n244_));
  INVx1_ASAP7_75t_R   g186(.A(new_n244_), .Y(new_n245_));
  AO21x1_ASAP7_75t_R  g187(.A1(new_n225_), .A2(new_n233_), .B(new_n224_), .Y(new_n246_));
  AO21x1_ASAP7_75t_R  g188(.A1(new_n83_), .A2(new_n246_), .B(new_n245_), .Y(G1895));
  XOR2x2_ASAP7_75t_R  g189(.A(G26), .B(new_n195_), .Y(new_n248_));
  XOR2x2_ASAP7_75t_R  g190(.A(new_n150_), .B(new_n177_), .Y(new_n249_));
  OR3x1_ASAP7_75t_R   g191(.A(new_n145_), .B(new_n248_), .C(new_n249_), .Y(new_n250_));
  OR3x1_ASAP7_75t_R   g192(.A(new_n149_), .B(new_n216_), .C(new_n250_), .Y(new_n251_));
  OR2x4_ASAP7_75t_R   g193(.A(new_n224_), .B(new_n251_), .Y(new_n252_));
  XNOR2x2_ASAP7_75t_R g194(.A(new_n60_), .B(new_n252_), .Y(G1896));
  XNOR2x2_ASAP7_75t_R g195(.A(new_n61_), .B(new_n252_), .Y(G1897));
  XNOR2x2_ASAP7_75t_R g196(.A(new_n62_), .B(new_n252_), .Y(G1898));
  XNOR2x2_ASAP7_75t_R g197(.A(new_n63_), .B(new_n252_), .Y(G1899));
  AO21x1_ASAP7_75t_R  g198(.A1(new_n199_), .A2(new_n216_), .B(new_n198_), .Y(new_n257_));
  AO21x1_ASAP7_75t_R  g199(.A1(new_n128_), .A2(new_n215_), .B(new_n216_), .Y(new_n258_));
  AO21x1_ASAP7_75t_R  g200(.A1(new_n199_), .A2(new_n258_), .B(new_n198_), .Y(new_n259_));
  AND2x2_ASAP7_75t_R  g201(.A(new_n224_), .B(new_n259_), .Y(new_n260_));
  AO21x1_ASAP7_75t_R  g202(.A1(new_n225_), .A2(new_n257_), .B(new_n260_), .Y(new_n261_));
  INVx1_ASAP7_75t_R   g203(.A(new_n261_), .Y(new_n262_));
  OA21x2_ASAP7_75t_R  g204(.A1(new_n78_), .A2(new_n262_), .B(G32), .Y(new_n263_));
  OR3x1_ASAP7_75t_R   g205(.A(new_n148_), .B(new_n201_), .C(new_n120_), .Y(new_n264_));
  OR3x1_ASAP7_75t_R   g206(.A(new_n232_), .B(new_n250_), .C(new_n264_), .Y(new_n265_));
  OR3x1_ASAP7_75t_R   g207(.A(G33), .B(new_n263_), .C(new_n265_), .Y(new_n266_));
  INVx1_ASAP7_75t_R   g208(.A(new_n266_), .Y(new_n267_));
  OR3x1_ASAP7_75t_R   g209(.A(G33), .B(new_n263_), .C(new_n267_), .Y(G1900));
  XNOR2x2_ASAP7_75t_R g210(.A(new_n158_), .B(new_n172_), .Y(new_n269_));
  XOR2x2_ASAP7_75t_R  g211(.A(new_n158_), .B(new_n173_), .Y(new_n270_));
  NOR2x1_ASAP7_75t_R  g212(.A(new_n153_), .B(new_n270_), .Y(new_n271_));
  AO21x1_ASAP7_75t_R  g213(.A1(new_n153_), .A2(new_n269_), .B(new_n271_), .Y(new_n272_));
  INVx1_ASAP7_75t_R   g214(.A(new_n272_), .Y(new_n273_));
  NOR2x1_ASAP7_75t_R  g215(.A(new_n150_), .B(new_n261_), .Y(new_n274_));
  NOR2x1_ASAP7_75t_R  g216(.A(G32), .B(G33), .Y(new_n275_));
  INVx1_ASAP7_75t_R   g217(.A(new_n275_), .Y(new_n276_));
  NOR2x1_ASAP7_75t_R  g218(.A(new_n274_), .B(new_n275_), .Y(new_n277_));
  AND3x1_ASAP7_75t_R  g219(.A(new_n274_), .B(new_n276_), .C(new_n273_), .Y(new_n278_));
  AO21x1_ASAP7_75t_R  g220(.A1(new_n272_), .A2(new_n277_), .B(new_n278_), .Y(G1901));
  NOR2x1_ASAP7_75t_R  g221(.A(new_n73_), .B(new_n261_), .Y(new_n280_));
  NOR2x1_ASAP7_75t_R  g222(.A(new_n275_), .B(new_n280_), .Y(new_n281_));
  AND3x1_ASAP7_75t_R  g223(.A(new_n276_), .B(new_n280_), .C(new_n211_), .Y(new_n282_));
  AO21x1_ASAP7_75t_R  g224(.A1(new_n210_), .A2(new_n281_), .B(new_n282_), .Y(G1902));
  XNOR2x2_ASAP7_75t_R g225(.A(new_n104_), .B(new_n115_), .Y(new_n284_));
  AO21x1_ASAP7_75t_R  g226(.A1(new_n261_), .A2(new_n284_), .B(new_n262_), .Y(new_n285_));
  AND2x2_ASAP7_75t_R  g227(.A(new_n276_), .B(new_n285_), .Y(G1903));
  AO21x1_ASAP7_75t_R  g228(.A1(new_n96_), .A2(new_n261_), .B(new_n262_), .Y(new_n287_));
  AND2x2_ASAP7_75t_R  g229(.A(new_n276_), .B(new_n287_), .Y(G1904));
  XOR2x2_ASAP7_75t_R  g230(.A(new_n136_), .B(new_n141_), .Y(new_n289_));
  OR2x4_ASAP7_75t_R   g231(.A(new_n262_), .B(new_n289_), .Y(new_n290_));
  AND3x1_ASAP7_75t_R  g232(.A(G32), .B(new_n290_), .C(new_n79_), .Y(new_n291_));
  AO21x1_ASAP7_75t_R  g233(.A1(G33), .A2(new_n290_), .B(new_n291_), .Y(G1905));
  AO21x1_ASAP7_75t_R  g234(.A1(G21), .A2(new_n79_), .B(G33), .Y(new_n293_));
  AND3x1_ASAP7_75t_R  g235(.A(new_n70_), .B(new_n79_), .C(new_n173_), .Y(new_n294_));
  AO21x1_ASAP7_75t_R  g236(.A1(new_n172_), .A2(new_n293_), .B(new_n294_), .Y(new_n295_));
  OR3x1_ASAP7_75t_R   g237(.A(new_n124_), .B(new_n295_), .C(new_n217_), .Y(new_n296_));
  INVx1_ASAP7_75t_R   g238(.A(new_n296_), .Y(new_n297_));
  AO21x1_ASAP7_75t_R  g239(.A1(new_n125_), .A2(new_n295_), .B(new_n124_), .Y(new_n298_));
  AO21x1_ASAP7_75t_R  g240(.A1(new_n217_), .A2(new_n298_), .B(new_n297_), .Y(G1906));
  AO21x1_ASAP7_75t_R  g241(.A1(new_n71_), .A2(G30), .B(new_n76_), .Y(new_n300_));
  NAND2x1_ASAP7_75t_R g242(.A(new_n79_), .B(new_n300_), .Y(new_n301_));
  XOR2x2_ASAP7_75t_R  g243(.A(G14), .B(new_n83_), .Y(new_n302_));
  XOR2x2_ASAP7_75t_R  g244(.A(new_n192_), .B(new_n302_), .Y(new_n303_));
  AO21x1_ASAP7_75t_R  g245(.A1(new_n76_), .A2(new_n79_), .B(new_n303_), .Y(new_n304_));
  XNOR2x2_ASAP7_75t_R g246(.A(new_n301_), .B(new_n304_), .Y(new_n305_));
  XNOR2x2_ASAP7_75t_R g247(.A(new_n301_), .B(new_n304_), .Y(new_n306_));
  NOR2x1_ASAP7_75t_R  g248(.A(new_n227_), .B(new_n306_), .Y(new_n307_));
  AO21x1_ASAP7_75t_R  g249(.A1(new_n227_), .A2(new_n305_), .B(new_n307_), .Y(G1907));
  XNOR2x2_ASAP7_75t_R g250(.A(new_n186_), .B(new_n190_), .Y(new_n309_));
  NAND2x1_ASAP7_75t_R g251(.A(new_n157_), .B(new_n309_), .Y(new_n310_));
  XOR2x2_ASAP7_75t_R  g252(.A(new_n186_), .B(new_n191_), .Y(new_n311_));
  OA21x2_ASAP7_75t_R  g253(.A1(new_n157_), .A2(new_n311_), .B(new_n310_), .Y(new_n312_));
  OR3x1_ASAP7_75t_R   g254(.A(new_n275_), .B(new_n312_), .C(new_n262_), .Y(new_n313_));
  INVx1_ASAP7_75t_R   g255(.A(new_n313_), .Y(G1908));
endmodule


