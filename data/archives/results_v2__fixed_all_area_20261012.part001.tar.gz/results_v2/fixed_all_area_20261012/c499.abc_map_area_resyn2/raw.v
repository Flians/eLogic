// Benchmark "/home/flynn/workplace/MIGBalance/results_v2/fixed_all_area_20261012/c499.resyn2" written by ABC on Mon Oct 12 14:59:09 2026

module \/home/flynn/workplace/MIGBalance/results_v2/fixed_all_area_20261012/c499.resyn2  ( 
    G14, G2, G6, G10, G34, G41, G25, G26, G27, G28, G29, G30, G31, G32, G4,
    G8, G12, G16, G36, G21, G22, G23, G24, G3, G7, G11, G15, G35, G17, G18,
    G19, G20, G1, G5, G9, G13, G33, G40, G39, G38, G37,
    G481, G482, G480, G468, G469, G470, G471, G472, G473, G474, G475, G476,
    G477, G478, G479, G483, G484, G485, G486, G487, G488, G489, G490, G491,
    G492, G493, G494, G495, G496, G497, G498, G499  );
  input  G14, G2, G6, G10, G34, G41, G25, G26, G27, G28, G29, G30, G31,
    G32, G4, G8, G12, G16, G36, G21, G22, G23, G24, G3, G7, G11, G15, G35,
    G17, G18, G19, G20, G1, G5, G9, G13, G33, G40, G39, G38, G37;
  output G481, G482, G480, G468, G469, G470, G471, G472, G473, G474, G475,
    G476, G477, G478, G479, G483, G484, G485, G486, G487, G488, G489, G490,
    G491, G492, G493, G494, G495, G496, G497, G498, G499;
  wire new_n74_, new_n75_, new_n76_, new_n77_, new_n78_, new_n79_, new_n80_,
    new_n81_, new_n82_, new_n83_, new_n84_, new_n85_, new_n86_, new_n87_,
    new_n88_, new_n89_, new_n90_, new_n91_, new_n92_, new_n93_, new_n94_,
    new_n95_, new_n96_, new_n97_, new_n98_, new_n99_, new_n100_, new_n101_,
    new_n102_, new_n103_, new_n104_, new_n105_, new_n106_, new_n107_,
    new_n108_, new_n109_, new_n110_, new_n111_, new_n112_, new_n113_,
    new_n114_, new_n115_, new_n116_, new_n117_, new_n118_, new_n119_,
    new_n120_, new_n121_, new_n122_, new_n123_, new_n124_, new_n125_,
    new_n126_, new_n127_, new_n128_, new_n129_, new_n130_, new_n131_,
    new_n132_, new_n133_, new_n134_, new_n135_, new_n136_, new_n137_,
    new_n138_, new_n139_, new_n140_, new_n141_, new_n142_, new_n143_,
    new_n144_, new_n145_, new_n146_, new_n147_, new_n148_, new_n149_,
    new_n150_, new_n151_, new_n152_, new_n153_, new_n154_, new_n155_,
    new_n156_, new_n157_, new_n158_, new_n159_, new_n160_, new_n161_,
    new_n162_, new_n163_, new_n164_, new_n165_, new_n166_, new_n167_,
    new_n168_, new_n170_, new_n172_, new_n174_, new_n175_, new_n176_,
    new_n177_, new_n178_, new_n179_, new_n181_, new_n183_, new_n185_,
    new_n187_, new_n188_, new_n190_, new_n192_, new_n194_, new_n196_,
    new_n197_, new_n199_, new_n201_, new_n203_, new_n205_, new_n207_,
    new_n208_, new_n209_, new_n210_, new_n211_, new_n212_, new_n213_,
    new_n215_, new_n217_, new_n219_, new_n221_, new_n222_, new_n223_,
    new_n225_, new_n227_, new_n229_, new_n231_, new_n232_, new_n234_,
    new_n236_, new_n238_, new_n240_, new_n241_, new_n243_, new_n245_,
    new_n247_;
  AND2x2_ASAP7_75t_R  g000(.A(G34), .B(G41), .Y(new_n74_));
  XOR2x2_ASAP7_75t_R  g001(.A(G25), .B(G26), .Y(new_n75_));
  XOR2x2_ASAP7_75t_R  g002(.A(G27), .B(G28), .Y(new_n76_));
  XOR2x2_ASAP7_75t_R  g003(.A(new_n75_), .B(new_n76_), .Y(new_n77_));
  XNOR2x2_ASAP7_75t_R g004(.A(new_n74_), .B(new_n77_), .Y(new_n78_));
  XOR2x2_ASAP7_75t_R  g005(.A(G2), .B(G6), .Y(new_n79_));
  XNOR2x2_ASAP7_75t_R g006(.A(G14), .B(G10), .Y(new_n80_));
  XOR2x2_ASAP7_75t_R  g007(.A(new_n80_), .B(new_n79_), .Y(new_n81_));
  XOR2x2_ASAP7_75t_R  g008(.A(G29), .B(G30), .Y(new_n82_));
  XOR2x2_ASAP7_75t_R  g009(.A(G31), .B(G32), .Y(new_n83_));
  XOR2x2_ASAP7_75t_R  g010(.A(new_n82_), .B(new_n83_), .Y(new_n84_));
  XOR2x2_ASAP7_75t_R  g011(.A(new_n81_), .B(new_n84_), .Y(new_n85_));
  XOR2x2_ASAP7_75t_R  g012(.A(new_n78_), .B(new_n85_), .Y(new_n86_));
  AND2x2_ASAP7_75t_R  g013(.A(G41), .B(G36), .Y(new_n87_));
  XOR2x2_ASAP7_75t_R  g014(.A(new_n84_), .B(new_n87_), .Y(new_n88_));
  XNOR2x2_ASAP7_75t_R g015(.A(G21), .B(G22), .Y(new_n89_));
  XOR2x2_ASAP7_75t_R  g016(.A(G23), .B(G24), .Y(new_n90_));
  XOR2x2_ASAP7_75t_R  g017(.A(new_n89_), .B(new_n90_), .Y(new_n91_));
  XOR2x2_ASAP7_75t_R  g018(.A(G4), .B(G8), .Y(new_n92_));
  XOR2x2_ASAP7_75t_R  g019(.A(G12), .B(G16), .Y(new_n93_));
  XOR2x2_ASAP7_75t_R  g020(.A(new_n92_), .B(new_n93_), .Y(new_n94_));
  XOR2x2_ASAP7_75t_R  g021(.A(new_n91_), .B(new_n94_), .Y(new_n95_));
  XNOR2x2_ASAP7_75t_R g022(.A(new_n88_), .B(new_n95_), .Y(new_n96_));
  AND2x2_ASAP7_75t_R  g023(.A(G41), .B(G35), .Y(new_n97_));
  XOR2x2_ASAP7_75t_R  g024(.A(new_n77_), .B(new_n97_), .Y(new_n98_));
  XOR2x2_ASAP7_75t_R  g025(.A(G17), .B(G18), .Y(new_n99_));
  XNOR2x2_ASAP7_75t_R g026(.A(G19), .B(G20), .Y(new_n100_));
  XOR2x2_ASAP7_75t_R  g027(.A(new_n100_), .B(new_n99_), .Y(new_n101_));
  XOR2x2_ASAP7_75t_R  g028(.A(G3), .B(G7), .Y(new_n102_));
  XOR2x2_ASAP7_75t_R  g029(.A(G11), .B(G15), .Y(new_n103_));
  XOR2x2_ASAP7_75t_R  g030(.A(new_n102_), .B(new_n103_), .Y(new_n104_));
  XOR2x2_ASAP7_75t_R  g031(.A(new_n101_), .B(new_n104_), .Y(new_n105_));
  XNOR2x2_ASAP7_75t_R g032(.A(new_n98_), .B(new_n105_), .Y(new_n106_));
  XOR2x2_ASAP7_75t_R  g033(.A(new_n96_), .B(new_n106_), .Y(new_n107_));
  NAND2x1_ASAP7_75t_R g034(.A(G41), .B(G33), .Y(new_n108_));
  XOR2x2_ASAP7_75t_R  g035(.A(new_n91_), .B(new_n108_), .Y(new_n109_));
  XOR2x2_ASAP7_75t_R  g036(.A(G1), .B(G5), .Y(new_n110_));
  XOR2x2_ASAP7_75t_R  g037(.A(G9), .B(G13), .Y(new_n111_));
  XNOR2x2_ASAP7_75t_R g038(.A(new_n110_), .B(new_n111_), .Y(new_n112_));
  XOR2x2_ASAP7_75t_R  g039(.A(new_n112_), .B(new_n101_), .Y(new_n113_));
  XNOR2x2_ASAP7_75t_R g040(.A(new_n109_), .B(new_n113_), .Y(new_n114_));
  NOR2x1_ASAP7_75t_R  g041(.A(new_n86_), .B(new_n114_), .Y(new_n115_));
  AND2x2_ASAP7_75t_R  g042(.A(new_n114_), .B(new_n86_), .Y(new_n116_));
  OR3x1_ASAP7_75t_R   g043(.A(new_n107_), .B(new_n115_), .C(new_n116_), .Y(new_n117_));
  INVx1_ASAP7_75t_R   g044(.A(new_n96_), .Y(new_n118_));
  INVx1_ASAP7_75t_R   g045(.A(new_n106_), .Y(new_n119_));
  INVx1_ASAP7_75t_R   g046(.A(new_n114_), .Y(new_n120_));
  NOR2x1_ASAP7_75t_R  g047(.A(new_n86_), .B(new_n120_), .Y(new_n121_));
  AO21x1_ASAP7_75t_R  g048(.A1(new_n118_), .A2(new_n119_), .B(new_n121_), .Y(new_n122_));
  AND2x2_ASAP7_75t_R  g049(.A(G41), .B(G40), .Y(new_n123_));
  XOR2x2_ASAP7_75t_R  g050(.A(G6), .B(G5), .Y(new_n124_));
  XOR2x2_ASAP7_75t_R  g051(.A(G8), .B(G7), .Y(new_n125_));
  XOR2x2_ASAP7_75t_R  g052(.A(new_n124_), .B(new_n125_), .Y(new_n126_));
  XOR2x2_ASAP7_75t_R  g053(.A(new_n126_), .B(new_n123_), .Y(new_n127_));
  XNOR2x2_ASAP7_75t_R g054(.A(G24), .B(G20), .Y(new_n128_));
  XOR2x2_ASAP7_75t_R  g055(.A(G28), .B(G32), .Y(new_n129_));
  XOR2x2_ASAP7_75t_R  g056(.A(new_n128_), .B(new_n129_), .Y(new_n130_));
  XOR2x2_ASAP7_75t_R  g057(.A(G14), .B(G13), .Y(new_n131_));
  XOR2x2_ASAP7_75t_R  g058(.A(G16), .B(G15), .Y(new_n132_));
  XOR2x2_ASAP7_75t_R  g059(.A(new_n131_), .B(new_n132_), .Y(new_n133_));
  XOR2x2_ASAP7_75t_R  g060(.A(new_n130_), .B(new_n133_), .Y(new_n134_));
  XNOR2x2_ASAP7_75t_R g061(.A(new_n127_), .B(new_n134_), .Y(new_n135_));
  AND3x1_ASAP7_75t_R  g062(.A(new_n117_), .B(new_n122_), .C(new_n135_), .Y(new_n136_));
  AND2x2_ASAP7_75t_R  g063(.A(G41), .B(G38), .Y(new_n137_));
  XOR2x2_ASAP7_75t_R  g064(.A(new_n133_), .B(new_n137_), .Y(new_n138_));
  XOR2x2_ASAP7_75t_R  g065(.A(G10), .B(G9), .Y(new_n139_));
  XNOR2x2_ASAP7_75t_R g066(.A(G12), .B(G11), .Y(new_n140_));
  XOR2x2_ASAP7_75t_R  g067(.A(new_n140_), .B(new_n139_), .Y(new_n141_));
  XOR2x2_ASAP7_75t_R  g068(.A(G22), .B(G18), .Y(new_n142_));
  XOR2x2_ASAP7_75t_R  g069(.A(G26), .B(G30), .Y(new_n143_));
  XNOR2x2_ASAP7_75t_R g070(.A(new_n142_), .B(new_n143_), .Y(new_n144_));
  XOR2x2_ASAP7_75t_R  g071(.A(new_n144_), .B(new_n141_), .Y(new_n145_));
  XNOR2x2_ASAP7_75t_R g072(.A(new_n138_), .B(new_n145_), .Y(new_n146_));
  INVx1_ASAP7_75t_R   g073(.A(new_n146_), .Y(new_n147_));
  AND2x2_ASAP7_75t_R  g074(.A(G41), .B(G37), .Y(new_n148_));
  XOR2x2_ASAP7_75t_R  g075(.A(new_n126_), .B(new_n148_), .Y(new_n149_));
  XOR2x2_ASAP7_75t_R  g076(.A(G2), .B(G1), .Y(new_n150_));
  XNOR2x2_ASAP7_75t_R g077(.A(G4), .B(G3), .Y(new_n151_));
  XOR2x2_ASAP7_75t_R  g078(.A(new_n151_), .B(new_n150_), .Y(new_n152_));
  XOR2x2_ASAP7_75t_R  g079(.A(G21), .B(G17), .Y(new_n153_));
  XOR2x2_ASAP7_75t_R  g080(.A(G25), .B(G29), .Y(new_n154_));
  XNOR2x2_ASAP7_75t_R g081(.A(new_n153_), .B(new_n154_), .Y(new_n155_));
  XOR2x2_ASAP7_75t_R  g082(.A(new_n155_), .B(new_n152_), .Y(new_n156_));
  XNOR2x2_ASAP7_75t_R g083(.A(new_n149_), .B(new_n156_), .Y(new_n157_));
  AND2x2_ASAP7_75t_R  g084(.A(new_n147_), .B(new_n157_), .Y(new_n158_));
  NAND2x1_ASAP7_75t_R g085(.A(G41), .B(G39), .Y(new_n159_));
  XOR2x2_ASAP7_75t_R  g086(.A(new_n152_), .B(new_n159_), .Y(new_n160_));
  XOR2x2_ASAP7_75t_R  g087(.A(G23), .B(G19), .Y(new_n161_));
  XOR2x2_ASAP7_75t_R  g088(.A(G27), .B(G31), .Y(new_n162_));
  XOR2x2_ASAP7_75t_R  g089(.A(new_n161_), .B(new_n162_), .Y(new_n163_));
  XOR2x2_ASAP7_75t_R  g090(.A(new_n141_), .B(new_n163_), .Y(new_n164_));
  XNOR2x2_ASAP7_75t_R g091(.A(new_n160_), .B(new_n164_), .Y(new_n165_));
  INVx1_ASAP7_75t_R   g092(.A(new_n165_), .Y(new_n166_));
  AND3x1_ASAP7_75t_R  g093(.A(new_n136_), .B(new_n158_), .C(new_n166_), .Y(new_n167_));
  AND2x2_ASAP7_75t_R  g094(.A(new_n167_), .B(new_n86_), .Y(new_n168_));
  XOR2x2_ASAP7_75t_R  g095(.A(new_n168_), .B(G14), .Y(G481));
  AND2x2_ASAP7_75t_R  g096(.A(new_n167_), .B(new_n106_), .Y(new_n170_));
  XOR2x2_ASAP7_75t_R  g097(.A(new_n170_), .B(G15), .Y(G482));
  AND2x2_ASAP7_75t_R  g098(.A(new_n167_), .B(new_n120_), .Y(new_n172_));
  XOR2x2_ASAP7_75t_R  g099(.A(new_n172_), .B(G13), .Y(G480));
  INVx1_ASAP7_75t_R   g100(.A(new_n135_), .Y(new_n174_));
  AND3x1_ASAP7_75t_R  g101(.A(new_n117_), .B(new_n122_), .C(new_n174_), .Y(new_n175_));
  INVx1_ASAP7_75t_R   g102(.A(new_n157_), .Y(new_n176_));
  AND2x2_ASAP7_75t_R  g103(.A(new_n176_), .B(new_n146_), .Y(new_n177_));
  AND3x1_ASAP7_75t_R  g104(.A(new_n175_), .B(new_n165_), .C(new_n177_), .Y(new_n178_));
  AND2x2_ASAP7_75t_R  g105(.A(new_n178_), .B(new_n120_), .Y(new_n179_));
  XOR2x2_ASAP7_75t_R  g106(.A(new_n179_), .B(G1), .Y(G468));
  AND2x2_ASAP7_75t_R  g107(.A(new_n178_), .B(new_n86_), .Y(new_n181_));
  XOR2x2_ASAP7_75t_R  g108(.A(new_n181_), .B(G2), .Y(G469));
  AND2x2_ASAP7_75t_R  g109(.A(new_n178_), .B(new_n106_), .Y(new_n183_));
  XOR2x2_ASAP7_75t_R  g110(.A(new_n183_), .B(G3), .Y(G470));
  AND2x2_ASAP7_75t_R  g111(.A(new_n178_), .B(new_n96_), .Y(new_n185_));
  XOR2x2_ASAP7_75t_R  g112(.A(new_n185_), .B(G4), .Y(G471));
  AND3x1_ASAP7_75t_R  g113(.A(new_n136_), .B(new_n166_), .C(new_n177_), .Y(new_n187_));
  AND2x2_ASAP7_75t_R  g114(.A(new_n187_), .B(new_n120_), .Y(new_n188_));
  XOR2x2_ASAP7_75t_R  g115(.A(new_n188_), .B(G5), .Y(G472));
  AND2x2_ASAP7_75t_R  g116(.A(new_n187_), .B(new_n86_), .Y(new_n190_));
  XOR2x2_ASAP7_75t_R  g117(.A(new_n190_), .B(G6), .Y(G473));
  AND2x2_ASAP7_75t_R  g118(.A(new_n187_), .B(new_n106_), .Y(new_n192_));
  XOR2x2_ASAP7_75t_R  g119(.A(new_n192_), .B(G7), .Y(G474));
  AND2x2_ASAP7_75t_R  g120(.A(new_n187_), .B(new_n96_), .Y(new_n194_));
  XOR2x2_ASAP7_75t_R  g121(.A(new_n194_), .B(G8), .Y(G475));
  AND3x1_ASAP7_75t_R  g122(.A(new_n175_), .B(new_n158_), .C(new_n165_), .Y(new_n196_));
  AND2x2_ASAP7_75t_R  g123(.A(new_n196_), .B(new_n120_), .Y(new_n197_));
  XOR2x2_ASAP7_75t_R  g124(.A(new_n197_), .B(G9), .Y(G476));
  AND2x2_ASAP7_75t_R  g125(.A(new_n196_), .B(new_n86_), .Y(new_n199_));
  XOR2x2_ASAP7_75t_R  g126(.A(new_n199_), .B(G10), .Y(G477));
  AND2x2_ASAP7_75t_R  g127(.A(new_n196_), .B(new_n106_), .Y(new_n201_));
  XOR2x2_ASAP7_75t_R  g128(.A(new_n201_), .B(G11), .Y(G478));
  AND2x2_ASAP7_75t_R  g129(.A(new_n196_), .B(new_n96_), .Y(new_n203_));
  XOR2x2_ASAP7_75t_R  g130(.A(new_n203_), .B(G12), .Y(G479));
  AND2x2_ASAP7_75t_R  g131(.A(new_n167_), .B(new_n96_), .Y(new_n205_));
  XOR2x2_ASAP7_75t_R  g132(.A(new_n205_), .B(G16), .Y(G483));
  XOR2x2_ASAP7_75t_R  g133(.A(new_n165_), .B(new_n135_), .Y(new_n207_));
  OR3x1_ASAP7_75t_R   g134(.A(new_n158_), .B(new_n177_), .C(new_n207_), .Y(new_n208_));
  AND2x2_ASAP7_75t_R  g135(.A(new_n146_), .B(new_n157_), .Y(new_n209_));
  AO21x1_ASAP7_75t_R  g136(.A1(new_n174_), .A2(new_n166_), .B(new_n209_), .Y(new_n210_));
  AND3x1_ASAP7_75t_R  g137(.A(new_n208_), .B(new_n118_), .C(new_n210_), .Y(new_n211_));
  AND3x1_ASAP7_75t_R  g138(.A(new_n211_), .B(new_n106_), .C(new_n115_), .Y(new_n212_));
  AND2x2_ASAP7_75t_R  g139(.A(new_n212_), .B(new_n176_), .Y(new_n213_));
  XOR2x2_ASAP7_75t_R  g140(.A(new_n213_), .B(G17), .Y(G484));
  AND2x2_ASAP7_75t_R  g141(.A(new_n212_), .B(new_n147_), .Y(new_n215_));
  XOR2x2_ASAP7_75t_R  g142(.A(new_n215_), .B(G18), .Y(G485));
  AND2x2_ASAP7_75t_R  g143(.A(new_n212_), .B(new_n165_), .Y(new_n217_));
  XOR2x2_ASAP7_75t_R  g144(.A(new_n217_), .B(G19), .Y(G486));
  AND2x2_ASAP7_75t_R  g145(.A(new_n212_), .B(new_n135_), .Y(new_n219_));
  XOR2x2_ASAP7_75t_R  g146(.A(new_n219_), .B(G20), .Y(G487));
  AND3x1_ASAP7_75t_R  g147(.A(new_n208_), .B(new_n96_), .C(new_n210_), .Y(new_n221_));
  AND3x1_ASAP7_75t_R  g148(.A(new_n221_), .B(new_n119_), .C(new_n115_), .Y(new_n222_));
  AND2x2_ASAP7_75t_R  g149(.A(new_n222_), .B(new_n176_), .Y(new_n223_));
  XOR2x2_ASAP7_75t_R  g150(.A(new_n223_), .B(G21), .Y(G488));
  AND2x2_ASAP7_75t_R  g151(.A(new_n222_), .B(new_n147_), .Y(new_n225_));
  XOR2x2_ASAP7_75t_R  g152(.A(new_n225_), .B(G22), .Y(G489));
  AND2x2_ASAP7_75t_R  g153(.A(new_n222_), .B(new_n165_), .Y(new_n227_));
  XOR2x2_ASAP7_75t_R  g154(.A(new_n227_), .B(G23), .Y(G490));
  AND2x2_ASAP7_75t_R  g155(.A(new_n222_), .B(new_n135_), .Y(new_n229_));
  XOR2x2_ASAP7_75t_R  g156(.A(new_n229_), .B(G24), .Y(G491));
  AND3x1_ASAP7_75t_R  g157(.A(new_n211_), .B(new_n106_), .C(new_n116_), .Y(new_n231_));
  AND2x2_ASAP7_75t_R  g158(.A(new_n231_), .B(new_n176_), .Y(new_n232_));
  XOR2x2_ASAP7_75t_R  g159(.A(new_n232_), .B(G25), .Y(G492));
  AND2x2_ASAP7_75t_R  g160(.A(new_n231_), .B(new_n147_), .Y(new_n234_));
  XOR2x2_ASAP7_75t_R  g161(.A(new_n234_), .B(G26), .Y(G493));
  AND2x2_ASAP7_75t_R  g162(.A(new_n231_), .B(new_n165_), .Y(new_n236_));
  XOR2x2_ASAP7_75t_R  g163(.A(new_n236_), .B(G27), .Y(G494));
  AND2x2_ASAP7_75t_R  g164(.A(new_n231_), .B(new_n135_), .Y(new_n238_));
  XOR2x2_ASAP7_75t_R  g165(.A(new_n238_), .B(G28), .Y(G495));
  AND3x1_ASAP7_75t_R  g166(.A(new_n221_), .B(new_n119_), .C(new_n116_), .Y(new_n240_));
  AND2x2_ASAP7_75t_R  g167(.A(new_n240_), .B(new_n176_), .Y(new_n241_));
  XOR2x2_ASAP7_75t_R  g168(.A(new_n241_), .B(G29), .Y(G496));
  AND2x2_ASAP7_75t_R  g169(.A(new_n240_), .B(new_n147_), .Y(new_n243_));
  XOR2x2_ASAP7_75t_R  g170(.A(new_n243_), .B(G30), .Y(G497));
  AND2x2_ASAP7_75t_R  g171(.A(new_n240_), .B(new_n165_), .Y(new_n245_));
  XOR2x2_ASAP7_75t_R  g172(.A(new_n245_), .B(G31), .Y(G498));
  AND2x2_ASAP7_75t_R  g173(.A(new_n240_), .B(new_n135_), .Y(new_n247_));
  XOR2x2_ASAP7_75t_R  g174(.A(new_n247_), .B(G32), .Y(G499));
endmodule


