// Benchmark "/home/flynn/workplace/MIGBalance/results_v2/fixed_all_area_20261012/c17.resyn2" written by ABC on Mon Oct 12 14:58:59 2026

module \/home/flynn/workplace/MIGBalance/results_v2/fixed_all_area_20261012/c17.resyn2  ( 
    G1, G3, G2, G4, G5,
    G16, G17  );
  input  G1, G3, G2, G4, G5;
  output G16, G17;
  wire new_n8_, new_n9_, new_n10_, new_n12_;
  INVx1_ASAP7_75t_R   g0(.A(G2), .Y(new_n8_));
  NAND2x1_ASAP7_75t_R g1(.A(G1), .B(G3), .Y(new_n9_));
  AND2x2_ASAP7_75t_R  g2(.A(G3), .B(G4), .Y(new_n10_));
  OAI21x1_ASAP7_75t_R g3(.A1(new_n8_), .A2(new_n10_), .B(new_n9_), .Y(G16));
  NAND2x1_ASAP7_75t_R g4(.A(G3), .B(G4), .Y(new_n12_));
  OA21x2_ASAP7_75t_R  g5(.A1(G2), .A2(G5), .B(new_n12_), .Y(G17));
endmodule


