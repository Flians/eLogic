// Benchmark "/home/flynn/workplace/MIGBalance/results_v2/fixed_all_area_20261012/c499.resyn2" written by ABC on Mon Oct 12 14:59:09 2026

module \/home/flynn/workplace/MIGBalance/results_v2/fixed_all_area_20261012/c499.resyn2  ( 
    G14, G2, G6, G10, G34, G41, G25, G26, G27, G28, G29, G30, G31, G32, G4,
    G8, G12, G16, G36, G21, G22, G23, G24, G3, G7, G11, G15, G35, G17, G18,
    G19, G20, G1, G5, G9, G13, G33, G40, G39, G38, G37,
    G481, G482, G480, G468, G469, G470, G471, G472, G473, G474, G475, G476,
    G477, G478, G479, G483, G484, G485, G486, G487, G488, G489, G490, G491,
    G492, G493, G494, G495, G496, G497, G498, G499  );
  input  G14, G2, G6, G10, G34, G41, G25, G26, G27, G28, G29, G30, G31,
    G32, G4, G8, G12, G16, G36, G21, G22, G23, G24, G3, G7, G11, G15, G35,
    G17, G18, G19, G20, G1, G5, G9, G13, G33, G40, G39, G38, G37;
  output G481, G482, G480, G468, G469, G470, G471, G472, G473, G474, G475,
    G476, G477, G478, G479, G483, G484, G485, G486, G487, G488, G489, G490,
    G491, G492, G493, G494, G495, G496, G497, G498, G499;
  wire new_n74_, new_n75_, new_n76_, new_n77_, new_n78_, new_n79_, new_n80_,
    new_n81_, new_n82_, new_n83_, new_n84_, new_n85_, new_n86_, new_n87_,
    new_n88_, new_n89_, new_n90_, new_n91_, new_n92_, new_n93_, new_n94_,
    new_n95_, new_n96_, new_n97_, new_n98_, new_n99_, new_n100_, new_n101_,
    new_n102_, new_n103_, new_n104_, new_n105_, new_n106_, new_n107_,
    new_n108_, new_n109_, new_n110_, new_n111_, new_n112_, new_n113_,
    new_n114_, new_n115_, new_n116_, new_n117_, new_n118_, new_n119_,
    new_n120_, new_n121_, new_n122_, new_n123_, new_n124_, new_n125_,
    new_n126_, new_n127_, new_n128_, new_n129_, new_n130_, new_n131_,
    new_n132_, new_n133_, new_n134_, new_n135_, new_n136_, new_n137_,
    new_n138_, new_n139_, new_n140_, new_n141_, new_n142_, new_n143_,
    new_n144_, new_n145_, new_n146_, new_n147_, new_n148_, new_n149_,
    new_n150_, new_n151_, new_n152_, new_n153_, new_n154_, new_n155_,
    new_n156_, new_n157_, new_n158_, new_n159_, new_n160_, new_n161_,
    new_n162_, new_n163_, new_n164_, new_n165_, new_n166_, new_n167_,
    new_n168_, new_n169_, new_n170_, new_n171_, new_n172_, new_n174_,
    new_n176_, new_n178_, new_n179_, new_n180_, new_n181_, new_n183_,
    new_n185_, new_n187_, new_n189_, new_n190_, new_n192_, new_n194_,
    new_n196_, new_n198_, new_n199_, new_n201_, new_n203_, new_n205_,
    new_n207_, new_n209_, new_n210_, new_n211_, new_n212_, new_n213_,
    new_n214_, new_n215_, new_n216_, new_n218_, new_n220_, new_n222_,
    new_n224_, new_n225_, new_n226_, new_n228_, new_n230_, new_n232_,
    new_n234_, new_n235_, new_n237_, new_n239_, new_n241_, new_n243_,
    new_n244_, new_n246_, new_n248_, new_n250_;
  INVx1_ASAP7_75t_R   g000(.A(G27), .Y(new_n74_));
  INVx1_ASAP7_75t_R   g001(.A(G12), .Y(new_n75_));
  NAND2x1_ASAP7_75t_R g002(.A(G34), .B(G41), .Y(new_n76_));
  XNOR2x2_ASAP7_75t_R g003(.A(G25), .B(G26), .Y(new_n77_));
  XNOR2x2_ASAP7_75t_R g004(.A(new_n74_), .B(G28), .Y(new_n78_));
  XNOR2x2_ASAP7_75t_R g005(.A(new_n77_), .B(new_n78_), .Y(new_n79_));
  XNOR2x2_ASAP7_75t_R g006(.A(new_n76_), .B(new_n79_), .Y(new_n80_));
  XNOR2x2_ASAP7_75t_R g007(.A(G2), .B(G6), .Y(new_n81_));
  XOR2x2_ASAP7_75t_R  g008(.A(G14), .B(G10), .Y(new_n82_));
  XNOR2x2_ASAP7_75t_R g009(.A(new_n81_), .B(new_n82_), .Y(new_n83_));
  XNOR2x2_ASAP7_75t_R g010(.A(G29), .B(G30), .Y(new_n84_));
  XOR2x2_ASAP7_75t_R  g011(.A(G31), .B(G32), .Y(new_n85_));
  XOR2x2_ASAP7_75t_R  g012(.A(new_n84_), .B(new_n85_), .Y(new_n86_));
  XNOR2x2_ASAP7_75t_R g013(.A(new_n83_), .B(new_n86_), .Y(new_n87_));
  XOR2x2_ASAP7_75t_R  g014(.A(new_n80_), .B(new_n87_), .Y(new_n88_));
  INVx1_ASAP7_75t_R   g015(.A(new_n88_), .Y(new_n89_));
  NAND2x1_ASAP7_75t_R g016(.A(G41), .B(G36), .Y(new_n90_));
  XOR2x2_ASAP7_75t_R  g017(.A(new_n86_), .B(new_n90_), .Y(new_n91_));
  XNOR2x2_ASAP7_75t_R g018(.A(G21), .B(G22), .Y(new_n92_));
  XOR2x2_ASAP7_75t_R  g019(.A(G23), .B(G24), .Y(new_n93_));
  XOR2x2_ASAP7_75t_R  g020(.A(new_n92_), .B(new_n93_), .Y(new_n94_));
  XNOR2x2_ASAP7_75t_R g021(.A(G4), .B(G8), .Y(new_n95_));
  XNOR2x2_ASAP7_75t_R g022(.A(new_n75_), .B(G16), .Y(new_n96_));
  XNOR2x2_ASAP7_75t_R g023(.A(new_n95_), .B(new_n96_), .Y(new_n97_));
  XNOR2x2_ASAP7_75t_R g024(.A(new_n94_), .B(new_n97_), .Y(new_n98_));
  XOR2x2_ASAP7_75t_R  g025(.A(new_n91_), .B(new_n98_), .Y(new_n99_));
  INVx1_ASAP7_75t_R   g026(.A(new_n99_), .Y(new_n100_));
  NAND2x1_ASAP7_75t_R g027(.A(G41), .B(G35), .Y(new_n101_));
  XNOR2x2_ASAP7_75t_R g028(.A(new_n79_), .B(new_n101_), .Y(new_n102_));
  XNOR2x2_ASAP7_75t_R g029(.A(G17), .B(G18), .Y(new_n103_));
  XOR2x2_ASAP7_75t_R  g030(.A(G19), .B(G20), .Y(new_n104_));
  XOR2x2_ASAP7_75t_R  g031(.A(new_n103_), .B(new_n104_), .Y(new_n105_));
  XNOR2x2_ASAP7_75t_R g032(.A(G3), .B(G7), .Y(new_n106_));
  XOR2x2_ASAP7_75t_R  g033(.A(G11), .B(G15), .Y(new_n107_));
  XNOR2x2_ASAP7_75t_R g034(.A(new_n106_), .B(new_n107_), .Y(new_n108_));
  XNOR2x2_ASAP7_75t_R g035(.A(new_n105_), .B(new_n108_), .Y(new_n109_));
  XOR2x2_ASAP7_75t_R  g036(.A(new_n102_), .B(new_n109_), .Y(new_n110_));
  INVx1_ASAP7_75t_R   g037(.A(new_n110_), .Y(new_n111_));
  NOR2x1_ASAP7_75t_R  g038(.A(new_n99_), .B(new_n110_), .Y(new_n112_));
  AO21x1_ASAP7_75t_R  g039(.A1(new_n99_), .A2(new_n110_), .B(new_n112_), .Y(new_n113_));
  NAND2x1_ASAP7_75t_R g040(.A(G41), .B(G33), .Y(new_n114_));
  XOR2x2_ASAP7_75t_R  g041(.A(new_n94_), .B(new_n114_), .Y(new_n115_));
  XNOR2x2_ASAP7_75t_R g042(.A(G1), .B(G5), .Y(new_n116_));
  XNOR2x2_ASAP7_75t_R g043(.A(G9), .B(G13), .Y(new_n117_));
  XOR2x2_ASAP7_75t_R  g044(.A(new_n116_), .B(new_n117_), .Y(new_n118_));
  XOR2x2_ASAP7_75t_R  g045(.A(new_n105_), .B(new_n118_), .Y(new_n119_));
  XOR2x2_ASAP7_75t_R  g046(.A(new_n115_), .B(new_n119_), .Y(new_n120_));
  OR2x4_ASAP7_75t_R   g047(.A(new_n88_), .B(new_n120_), .Y(new_n121_));
  NAND2x1_ASAP7_75t_R g048(.A(new_n88_), .B(new_n120_), .Y(new_n122_));
  AND2x2_ASAP7_75t_R  g049(.A(new_n121_), .B(new_n122_), .Y(new_n123_));
  AOI21x1_ASAP7_75t_R g050(.A1(new_n89_), .A2(new_n120_), .B(new_n112_), .Y(new_n124_));
  AO21x1_ASAP7_75t_R  g051(.A1(new_n113_), .A2(new_n123_), .B(new_n124_), .Y(new_n125_));
  NAND2x1_ASAP7_75t_R g052(.A(G41), .B(G40), .Y(new_n126_));
  XNOR2x2_ASAP7_75t_R g053(.A(G6), .B(G5), .Y(new_n127_));
  XOR2x2_ASAP7_75t_R  g054(.A(G8), .B(G7), .Y(new_n128_));
  XNOR2x2_ASAP7_75t_R g055(.A(new_n127_), .B(new_n128_), .Y(new_n129_));
  XNOR2x2_ASAP7_75t_R g056(.A(new_n126_), .B(new_n129_), .Y(new_n130_));
  XNOR2x2_ASAP7_75t_R g057(.A(G24), .B(G20), .Y(new_n131_));
  XOR2x2_ASAP7_75t_R  g058(.A(G28), .B(G32), .Y(new_n132_));
  XNOR2x2_ASAP7_75t_R g059(.A(new_n131_), .B(new_n132_), .Y(new_n133_));
  XNOR2x2_ASAP7_75t_R g060(.A(G14), .B(G13), .Y(new_n134_));
  XOR2x2_ASAP7_75t_R  g061(.A(G16), .B(G15), .Y(new_n135_));
  XOR2x2_ASAP7_75t_R  g062(.A(new_n134_), .B(new_n135_), .Y(new_n136_));
  XNOR2x2_ASAP7_75t_R g063(.A(new_n133_), .B(new_n136_), .Y(new_n137_));
  XOR2x2_ASAP7_75t_R  g064(.A(new_n130_), .B(new_n137_), .Y(new_n138_));
  INVx1_ASAP7_75t_R   g065(.A(new_n138_), .Y(new_n139_));
  OR2x4_ASAP7_75t_R   g066(.A(new_n125_), .B(new_n139_), .Y(new_n140_));
  NAND2x1_ASAP7_75t_R g067(.A(G41), .B(G38), .Y(new_n141_));
  XOR2x2_ASAP7_75t_R  g068(.A(new_n136_), .B(new_n141_), .Y(new_n142_));
  XNOR2x2_ASAP7_75t_R g069(.A(G10), .B(G9), .Y(new_n143_));
  XNOR2x2_ASAP7_75t_R g070(.A(new_n75_), .B(G11), .Y(new_n144_));
  XOR2x2_ASAP7_75t_R  g071(.A(new_n143_), .B(new_n144_), .Y(new_n145_));
  XNOR2x2_ASAP7_75t_R g072(.A(G22), .B(G18), .Y(new_n146_));
  XNOR2x2_ASAP7_75t_R g073(.A(G26), .B(G30), .Y(new_n147_));
  XOR2x2_ASAP7_75t_R  g074(.A(new_n146_), .B(new_n147_), .Y(new_n148_));
  XOR2x2_ASAP7_75t_R  g075(.A(new_n145_), .B(new_n148_), .Y(new_n149_));
  XOR2x2_ASAP7_75t_R  g076(.A(new_n142_), .B(new_n149_), .Y(new_n150_));
  NAND2x1_ASAP7_75t_R g077(.A(G41), .B(G37), .Y(new_n151_));
  XNOR2x2_ASAP7_75t_R g078(.A(new_n129_), .B(new_n151_), .Y(new_n152_));
  XNOR2x2_ASAP7_75t_R g079(.A(G2), .B(G1), .Y(new_n153_));
  XOR2x2_ASAP7_75t_R  g080(.A(G4), .B(G3), .Y(new_n154_));
  XNOR2x2_ASAP7_75t_R g081(.A(new_n153_), .B(new_n154_), .Y(new_n155_));
  XNOR2x2_ASAP7_75t_R g082(.A(G21), .B(G17), .Y(new_n156_));
  XNOR2x2_ASAP7_75t_R g083(.A(G25), .B(G29), .Y(new_n157_));
  XOR2x2_ASAP7_75t_R  g084(.A(new_n156_), .B(new_n157_), .Y(new_n158_));
  XNOR2x2_ASAP7_75t_R g085(.A(new_n155_), .B(new_n158_), .Y(new_n159_));
  XOR2x2_ASAP7_75t_R  g086(.A(new_n152_), .B(new_n159_), .Y(new_n160_));
  INVx1_ASAP7_75t_R   g087(.A(new_n160_), .Y(new_n161_));
  OR2x4_ASAP7_75t_R   g088(.A(new_n150_), .B(new_n161_), .Y(new_n162_));
  NAND2x1_ASAP7_75t_R g089(.A(G41), .B(G39), .Y(new_n163_));
  XNOR2x2_ASAP7_75t_R g090(.A(new_n155_), .B(new_n163_), .Y(new_n164_));
  XNOR2x2_ASAP7_75t_R g091(.A(G23), .B(G19), .Y(new_n165_));
  XNOR2x2_ASAP7_75t_R g092(.A(new_n74_), .B(G31), .Y(new_n166_));
  XNOR2x2_ASAP7_75t_R g093(.A(new_n165_), .B(new_n166_), .Y(new_n167_));
  XNOR2x2_ASAP7_75t_R g094(.A(new_n145_), .B(new_n167_), .Y(new_n168_));
  XOR2x2_ASAP7_75t_R  g095(.A(new_n164_), .B(new_n168_), .Y(new_n169_));
  INVx1_ASAP7_75t_R   g096(.A(new_n169_), .Y(new_n170_));
  OR3x1_ASAP7_75t_R   g097(.A(new_n162_), .B(new_n169_), .C(new_n140_), .Y(new_n171_));
  OR2x4_ASAP7_75t_R   g098(.A(new_n89_), .B(new_n171_), .Y(new_n172_));
  XNOR2x2_ASAP7_75t_R g099(.A(G14), .B(new_n172_), .Y(G481));
  OR2x4_ASAP7_75t_R   g100(.A(new_n111_), .B(new_n171_), .Y(new_n174_));
  XNOR2x2_ASAP7_75t_R g101(.A(G15), .B(new_n174_), .Y(G482));
  OR2x4_ASAP7_75t_R   g102(.A(new_n120_), .B(new_n171_), .Y(new_n176_));
  XNOR2x2_ASAP7_75t_R g103(.A(G13), .B(new_n176_), .Y(G480));
  OR2x4_ASAP7_75t_R   g104(.A(new_n125_), .B(new_n138_), .Y(new_n178_));
  NAND2x1_ASAP7_75t_R g105(.A(new_n150_), .B(new_n161_), .Y(new_n179_));
  OR3x1_ASAP7_75t_R   g106(.A(new_n170_), .B(new_n179_), .C(new_n178_), .Y(new_n180_));
  OR2x4_ASAP7_75t_R   g107(.A(new_n120_), .B(new_n180_), .Y(new_n181_));
  XNOR2x2_ASAP7_75t_R g108(.A(G1), .B(new_n181_), .Y(G468));
  OR2x4_ASAP7_75t_R   g109(.A(new_n89_), .B(new_n180_), .Y(new_n183_));
  XNOR2x2_ASAP7_75t_R g110(.A(G2), .B(new_n183_), .Y(G469));
  OR2x4_ASAP7_75t_R   g111(.A(new_n111_), .B(new_n180_), .Y(new_n185_));
  XNOR2x2_ASAP7_75t_R g112(.A(G3), .B(new_n185_), .Y(G470));
  OR2x4_ASAP7_75t_R   g113(.A(new_n100_), .B(new_n180_), .Y(new_n187_));
  XNOR2x2_ASAP7_75t_R g114(.A(G4), .B(new_n187_), .Y(G471));
  OR3x1_ASAP7_75t_R   g115(.A(new_n169_), .B(new_n179_), .C(new_n140_), .Y(new_n189_));
  OR2x4_ASAP7_75t_R   g116(.A(new_n120_), .B(new_n189_), .Y(new_n190_));
  XNOR2x2_ASAP7_75t_R g117(.A(G5), .B(new_n190_), .Y(G472));
  OR2x4_ASAP7_75t_R   g118(.A(new_n89_), .B(new_n189_), .Y(new_n192_));
  XNOR2x2_ASAP7_75t_R g119(.A(G6), .B(new_n192_), .Y(G473));
  OR2x4_ASAP7_75t_R   g120(.A(new_n111_), .B(new_n189_), .Y(new_n194_));
  XNOR2x2_ASAP7_75t_R g121(.A(G7), .B(new_n194_), .Y(G474));
  OR2x4_ASAP7_75t_R   g122(.A(new_n100_), .B(new_n189_), .Y(new_n196_));
  XNOR2x2_ASAP7_75t_R g123(.A(G8), .B(new_n196_), .Y(G475));
  OR3x1_ASAP7_75t_R   g124(.A(new_n162_), .B(new_n170_), .C(new_n178_), .Y(new_n198_));
  OR2x4_ASAP7_75t_R   g125(.A(new_n120_), .B(new_n198_), .Y(new_n199_));
  XNOR2x2_ASAP7_75t_R g126(.A(G9), .B(new_n199_), .Y(G476));
  OR2x4_ASAP7_75t_R   g127(.A(new_n89_), .B(new_n198_), .Y(new_n201_));
  XNOR2x2_ASAP7_75t_R g128(.A(G10), .B(new_n201_), .Y(G477));
  OR2x4_ASAP7_75t_R   g129(.A(new_n111_), .B(new_n198_), .Y(new_n203_));
  XNOR2x2_ASAP7_75t_R g130(.A(G11), .B(new_n203_), .Y(G478));
  OR2x4_ASAP7_75t_R   g131(.A(new_n100_), .B(new_n198_), .Y(new_n205_));
  XNOR2x2_ASAP7_75t_R g132(.A(G12), .B(new_n205_), .Y(G479));
  OR2x4_ASAP7_75t_R   g133(.A(new_n100_), .B(new_n171_), .Y(new_n207_));
  XNOR2x2_ASAP7_75t_R g134(.A(G16), .B(new_n207_), .Y(G483));
  NOR2x1_ASAP7_75t_R  g135(.A(new_n138_), .B(new_n169_), .Y(new_n209_));
  AO21x1_ASAP7_75t_R  g136(.A1(new_n138_), .A2(new_n169_), .B(new_n209_), .Y(new_n210_));
  AND2x2_ASAP7_75t_R  g137(.A(new_n162_), .B(new_n179_), .Y(new_n211_));
  AOI21x1_ASAP7_75t_R g138(.A1(new_n150_), .A2(new_n160_), .B(new_n209_), .Y(new_n212_));
  AO21x1_ASAP7_75t_R  g139(.A1(new_n210_), .A2(new_n211_), .B(new_n212_), .Y(new_n213_));
  OR2x4_ASAP7_75t_R   g140(.A(new_n99_), .B(new_n213_), .Y(new_n214_));
  OR3x1_ASAP7_75t_R   g141(.A(new_n111_), .B(new_n121_), .C(new_n214_), .Y(new_n215_));
  OR2x4_ASAP7_75t_R   g142(.A(new_n160_), .B(new_n215_), .Y(new_n216_));
  XNOR2x2_ASAP7_75t_R g143(.A(G17), .B(new_n216_), .Y(G484));
  OR2x4_ASAP7_75t_R   g144(.A(new_n150_), .B(new_n215_), .Y(new_n218_));
  XNOR2x2_ASAP7_75t_R g145(.A(G18), .B(new_n218_), .Y(G485));
  OR2x4_ASAP7_75t_R   g146(.A(new_n170_), .B(new_n215_), .Y(new_n220_));
  XNOR2x2_ASAP7_75t_R g147(.A(G19), .B(new_n220_), .Y(G486));
  OR2x4_ASAP7_75t_R   g148(.A(new_n139_), .B(new_n215_), .Y(new_n222_));
  XNOR2x2_ASAP7_75t_R g149(.A(G20), .B(new_n222_), .Y(G487));
  OR2x4_ASAP7_75t_R   g150(.A(new_n100_), .B(new_n213_), .Y(new_n224_));
  OR3x1_ASAP7_75t_R   g151(.A(new_n110_), .B(new_n121_), .C(new_n224_), .Y(new_n225_));
  OR2x4_ASAP7_75t_R   g152(.A(new_n160_), .B(new_n225_), .Y(new_n226_));
  XNOR2x2_ASAP7_75t_R g153(.A(G21), .B(new_n226_), .Y(G488));
  OR2x4_ASAP7_75t_R   g154(.A(new_n150_), .B(new_n225_), .Y(new_n228_));
  XNOR2x2_ASAP7_75t_R g155(.A(G22), .B(new_n228_), .Y(G489));
  OR2x4_ASAP7_75t_R   g156(.A(new_n170_), .B(new_n225_), .Y(new_n230_));
  XNOR2x2_ASAP7_75t_R g157(.A(G23), .B(new_n230_), .Y(G490));
  OR2x4_ASAP7_75t_R   g158(.A(new_n139_), .B(new_n225_), .Y(new_n232_));
  XNOR2x2_ASAP7_75t_R g159(.A(G24), .B(new_n232_), .Y(G491));
  OR3x1_ASAP7_75t_R   g160(.A(new_n111_), .B(new_n122_), .C(new_n214_), .Y(new_n234_));
  OR2x4_ASAP7_75t_R   g161(.A(new_n160_), .B(new_n234_), .Y(new_n235_));
  XNOR2x2_ASAP7_75t_R g162(.A(G25), .B(new_n235_), .Y(G492));
  OR2x4_ASAP7_75t_R   g163(.A(new_n150_), .B(new_n234_), .Y(new_n237_));
  XNOR2x2_ASAP7_75t_R g164(.A(G26), .B(new_n237_), .Y(G493));
  OR2x4_ASAP7_75t_R   g165(.A(new_n170_), .B(new_n234_), .Y(new_n239_));
  XNOR2x2_ASAP7_75t_R g166(.A(G27), .B(new_n239_), .Y(G494));
  OR2x4_ASAP7_75t_R   g167(.A(new_n139_), .B(new_n234_), .Y(new_n241_));
  XNOR2x2_ASAP7_75t_R g168(.A(G28), .B(new_n241_), .Y(G495));
  OR3x1_ASAP7_75t_R   g169(.A(new_n110_), .B(new_n122_), .C(new_n224_), .Y(new_n243_));
  OR2x4_ASAP7_75t_R   g170(.A(new_n160_), .B(new_n243_), .Y(new_n244_));
  XNOR2x2_ASAP7_75t_R g171(.A(G29), .B(new_n244_), .Y(G496));
  OR2x4_ASAP7_75t_R   g172(.A(new_n150_), .B(new_n243_), .Y(new_n246_));
  XNOR2x2_ASAP7_75t_R g173(.A(G30), .B(new_n246_), .Y(G497));
  OR2x4_ASAP7_75t_R   g174(.A(new_n170_), .B(new_n243_), .Y(new_n248_));
  XNOR2x2_ASAP7_75t_R g175(.A(G31), .B(new_n248_), .Y(G498));
  OR2x4_ASAP7_75t_R   g176(.A(new_n139_), .B(new_n243_), .Y(new_n250_));
  XNOR2x2_ASAP7_75t_R g177(.A(G32), .B(new_n250_), .Y(G499));
endmodule


