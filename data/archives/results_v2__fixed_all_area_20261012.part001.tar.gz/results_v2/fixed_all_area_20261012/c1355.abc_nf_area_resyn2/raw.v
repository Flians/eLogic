// Benchmark "/home/flynn/workplace/MIGBalance/results_v2/fixed_all_area_20261012/c1355.resyn2" written by ABC on Mon Oct 12 14:59:23 2026

module \/home/flynn/workplace/MIGBalance/results_v2/fixed_all_area_20261012/c1355.resyn2  ( 
    G1, G5, G9, G13, G33, G41, G17, G18, G19, G20, G21, G22, G23, G24, G4,
    G8, G12, G16, G36, G29, G30, G31, G32, G3, G7, G11, G15, G35, G25, G26,
    G27, G28, G2, G6, G10, G14, G34, G40, G39, G38, G37,
    G1324, G1344, G1325, G1326, G1327, G1328, G1329, G1330, G1343, G1331,
    G1332, G1333, G1334, G1335, G1336, G1337, G1338, G1339, G1340, G1341,
    G1342, G1345, G1346, G1347, G1348, G1349, G1350, G1351, G1352, G1353,
    G1354, G1355  );
  input  G1, G5, G9, G13, G33, G41, G17, G18, G19, G20, G21, G22, G23,
    G24, G4, G8, G12, G16, G36, G29, G30, G31, G32, G3, G7, G11, G15, G35,
    G25, G26, G27, G28, G2, G6, G10, G14, G34, G40, G39, G38, G37;
  output G1324, G1344, G1325, G1326, G1327, G1328, G1329, G1330, G1343, G1331,
    G1332, G1333, G1334, G1335, G1336, G1337, G1338, G1339, G1340, G1341,
    G1342, G1345, G1346, G1347, G1348, G1349, G1350, G1351, G1352, G1353,
    G1354, G1355;
  wire new_n74_, new_n75_, new_n76_, new_n77_, new_n78_, new_n79_, new_n80_,
    new_n81_, new_n82_, new_n83_, new_n84_, new_n85_, new_n86_, new_n87_,
    new_n88_, new_n89_, new_n90_, new_n91_, new_n92_, new_n93_, new_n94_,
    new_n95_, new_n96_, new_n97_, new_n98_, new_n99_, new_n100_, new_n101_,
    new_n102_, new_n103_, new_n104_, new_n105_, new_n106_, new_n107_,
    new_n108_, new_n109_, new_n110_, new_n111_, new_n112_, new_n113_,
    new_n114_, new_n115_, new_n116_, new_n117_, new_n118_, new_n119_,
    new_n120_, new_n121_, new_n122_, new_n123_, new_n124_, new_n125_,
    new_n126_, new_n127_, new_n128_, new_n129_, new_n130_, new_n131_,
    new_n132_, new_n133_, new_n134_, new_n135_, new_n136_, new_n137_,
    new_n138_, new_n139_, new_n140_, new_n141_, new_n142_, new_n143_,
    new_n144_, new_n145_, new_n146_, new_n147_, new_n148_, new_n149_,
    new_n150_, new_n151_, new_n152_, new_n153_, new_n154_, new_n155_,
    new_n156_, new_n157_, new_n158_, new_n159_, new_n160_, new_n161_,
    new_n162_, new_n163_, new_n164_, new_n165_, new_n166_, new_n167_,
    new_n168_, new_n169_, new_n170_, new_n171_, new_n172_, new_n173_,
    new_n174_, new_n175_, new_n176_, new_n177_, new_n178_, new_n179_,
    new_n180_, new_n181_, new_n182_, new_n183_, new_n184_, new_n185_,
    new_n186_, new_n187_, new_n188_, new_n189_, new_n190_, new_n191_,
    new_n192_, new_n193_, new_n194_, new_n195_, new_n196_, new_n197_,
    new_n198_, new_n199_, new_n200_, new_n201_, new_n202_, new_n203_,
    new_n205_, new_n206_, new_n207_, new_n208_, new_n209_, new_n210_,
    new_n211_, new_n212_, new_n213_, new_n215_, new_n216_, new_n218_,
    new_n219_, new_n221_, new_n222_, new_n224_, new_n225_, new_n226_,
    new_n227_, new_n229_, new_n230_, new_n232_, new_n233_, new_n235_,
    new_n236_, new_n237_, new_n238_, new_n239_, new_n241_, new_n242_,
    new_n244_, new_n245_, new_n246_, new_n247_, new_n249_, new_n250_,
    new_n252_, new_n253_, new_n255_, new_n256_, new_n258_, new_n259_,
    new_n260_, new_n261_, new_n263_, new_n264_, new_n266_, new_n267_,
    new_n269_, new_n270_, new_n272_, new_n273_, new_n275_, new_n276_,
    new_n278_, new_n279_, new_n281_, new_n282_, new_n284_, new_n285_,
    new_n287_, new_n288_, new_n290_, new_n291_, new_n292_, new_n293_,
    new_n295_, new_n296_, new_n298_, new_n299_, new_n301_, new_n302_,
    new_n304_, new_n305_, new_n306_, new_n307_, new_n309_, new_n310_,
    new_n312_, new_n313_, new_n315_, new_n316_;
  INVx1_ASAP7_75t_R   g000(.A(G1), .Y(new_n74_));
  INVx1_ASAP7_75t_R   g001(.A(G5), .Y(new_n75_));
  INVx1_ASAP7_75t_R   g002(.A(G9), .Y(new_n76_));
  INVx1_ASAP7_75t_R   g003(.A(G13), .Y(new_n77_));
  INVx1_ASAP7_75t_R   g004(.A(G17), .Y(new_n78_));
  INVx1_ASAP7_75t_R   g005(.A(G18), .Y(new_n79_));
  INVx1_ASAP7_75t_R   g006(.A(G19), .Y(new_n80_));
  INVx1_ASAP7_75t_R   g007(.A(G20), .Y(new_n81_));
  INVx1_ASAP7_75t_R   g008(.A(G21), .Y(new_n82_));
  INVx1_ASAP7_75t_R   g009(.A(G22), .Y(new_n83_));
  INVx1_ASAP7_75t_R   g010(.A(G23), .Y(new_n84_));
  INVx1_ASAP7_75t_R   g011(.A(G24), .Y(new_n85_));
  INVx1_ASAP7_75t_R   g012(.A(G4), .Y(new_n86_));
  INVx1_ASAP7_75t_R   g013(.A(G8), .Y(new_n87_));
  INVx1_ASAP7_75t_R   g014(.A(G12), .Y(new_n88_));
  INVx1_ASAP7_75t_R   g015(.A(G16), .Y(new_n89_));
  INVx1_ASAP7_75t_R   g016(.A(G29), .Y(new_n90_));
  INVx1_ASAP7_75t_R   g017(.A(G30), .Y(new_n91_));
  INVx1_ASAP7_75t_R   g018(.A(G31), .Y(new_n92_));
  INVx1_ASAP7_75t_R   g019(.A(G32), .Y(new_n93_));
  INVx1_ASAP7_75t_R   g020(.A(G3), .Y(new_n94_));
  INVx1_ASAP7_75t_R   g021(.A(G7), .Y(new_n95_));
  INVx1_ASAP7_75t_R   g022(.A(G11), .Y(new_n96_));
  INVx1_ASAP7_75t_R   g023(.A(G15), .Y(new_n97_));
  INVx1_ASAP7_75t_R   g024(.A(G25), .Y(new_n98_));
  INVx1_ASAP7_75t_R   g025(.A(G26), .Y(new_n99_));
  INVx1_ASAP7_75t_R   g026(.A(G27), .Y(new_n100_));
  INVx1_ASAP7_75t_R   g027(.A(G28), .Y(new_n101_));
  INVx1_ASAP7_75t_R   g028(.A(G2), .Y(new_n102_));
  INVx1_ASAP7_75t_R   g029(.A(G6), .Y(new_n103_));
  INVx1_ASAP7_75t_R   g030(.A(G10), .Y(new_n104_));
  INVx1_ASAP7_75t_R   g031(.A(G14), .Y(new_n105_));
  XOR2x2_ASAP7_75t_R  g032(.A(G19), .B(G20), .Y(new_n106_));
  XOR2x2_ASAP7_75t_R  g033(.A(G17), .B(G18), .Y(new_n107_));
  XOR2x2_ASAP7_75t_R  g034(.A(new_n106_), .B(new_n107_), .Y(new_n108_));
  AND2x2_ASAP7_75t_R  g035(.A(G33), .B(G41), .Y(new_n109_));
  XOR2x2_ASAP7_75t_R  g036(.A(new_n108_), .B(new_n109_), .Y(new_n110_));
  XOR2x2_ASAP7_75t_R  g037(.A(G23), .B(G24), .Y(new_n111_));
  XOR2x2_ASAP7_75t_R  g038(.A(G21), .B(G22), .Y(new_n112_));
  XOR2x2_ASAP7_75t_R  g039(.A(new_n111_), .B(new_n112_), .Y(new_n113_));
  XOR2x2_ASAP7_75t_R  g040(.A(G9), .B(G13), .Y(new_n114_));
  XOR2x2_ASAP7_75t_R  g041(.A(G1), .B(G5), .Y(new_n115_));
  XOR2x2_ASAP7_75t_R  g042(.A(new_n114_), .B(new_n115_), .Y(new_n116_));
  XOR2x2_ASAP7_75t_R  g043(.A(new_n113_), .B(new_n116_), .Y(new_n117_));
  XOR2x2_ASAP7_75t_R  g044(.A(new_n110_), .B(new_n117_), .Y(new_n118_));
  INVx1_ASAP7_75t_R   g045(.A(new_n118_), .Y(new_n119_));
  NAND2x1_ASAP7_75t_R g046(.A(G41), .B(G36), .Y(new_n120_));
  XOR2x2_ASAP7_75t_R  g047(.A(new_n113_), .B(new_n120_), .Y(new_n121_));
  XOR2x2_ASAP7_75t_R  g048(.A(G31), .B(G32), .Y(new_n122_));
  XOR2x2_ASAP7_75t_R  g049(.A(G29), .B(G30), .Y(new_n123_));
  XOR2x2_ASAP7_75t_R  g050(.A(new_n122_), .B(new_n123_), .Y(new_n124_));
  XOR2x2_ASAP7_75t_R  g051(.A(G12), .B(G16), .Y(new_n125_));
  XOR2x2_ASAP7_75t_R  g052(.A(G4), .B(G8), .Y(new_n126_));
  XOR2x2_ASAP7_75t_R  g053(.A(new_n125_), .B(new_n126_), .Y(new_n127_));
  XOR2x2_ASAP7_75t_R  g054(.A(new_n124_), .B(new_n127_), .Y(new_n128_));
  XOR2x2_ASAP7_75t_R  g055(.A(new_n121_), .B(new_n128_), .Y(new_n129_));
  XNOR2x2_ASAP7_75t_R g056(.A(new_n121_), .B(new_n128_), .Y(new_n130_));
  NAND2x1_ASAP7_75t_R g057(.A(G41), .B(G35), .Y(new_n131_));
  XOR2x2_ASAP7_75t_R  g058(.A(new_n108_), .B(new_n131_), .Y(new_n132_));
  XOR2x2_ASAP7_75t_R  g059(.A(G27), .B(G28), .Y(new_n133_));
  XOR2x2_ASAP7_75t_R  g060(.A(G25), .B(G26), .Y(new_n134_));
  XOR2x2_ASAP7_75t_R  g061(.A(new_n133_), .B(new_n134_), .Y(new_n135_));
  XOR2x2_ASAP7_75t_R  g062(.A(G11), .B(G15), .Y(new_n136_));
  XOR2x2_ASAP7_75t_R  g063(.A(G3), .B(G7), .Y(new_n137_));
  XOR2x2_ASAP7_75t_R  g064(.A(new_n136_), .B(new_n137_), .Y(new_n138_));
  XOR2x2_ASAP7_75t_R  g065(.A(new_n135_), .B(new_n138_), .Y(new_n139_));
  XOR2x2_ASAP7_75t_R  g066(.A(new_n132_), .B(new_n139_), .Y(new_n140_));
  XNOR2x2_ASAP7_75t_R g067(.A(new_n132_), .B(new_n139_), .Y(new_n141_));
  NAND2x1_ASAP7_75t_R g068(.A(new_n129_), .B(new_n140_), .Y(new_n142_));
  XOR2x2_ASAP7_75t_R  g069(.A(new_n129_), .B(new_n140_), .Y(new_n143_));
  AND2x2_ASAP7_75t_R  g070(.A(G41), .B(G34), .Y(new_n144_));
  XOR2x2_ASAP7_75t_R  g071(.A(new_n124_), .B(new_n144_), .Y(new_n145_));
  XOR2x2_ASAP7_75t_R  g072(.A(G10), .B(G14), .Y(new_n146_));
  XOR2x2_ASAP7_75t_R  g073(.A(G2), .B(G6), .Y(new_n147_));
  XOR2x2_ASAP7_75t_R  g074(.A(new_n146_), .B(new_n147_), .Y(new_n148_));
  XOR2x2_ASAP7_75t_R  g075(.A(new_n135_), .B(new_n148_), .Y(new_n149_));
  XOR2x2_ASAP7_75t_R  g076(.A(new_n145_), .B(new_n149_), .Y(new_n150_));
  XOR2x2_ASAP7_75t_R  g077(.A(new_n118_), .B(new_n150_), .Y(new_n151_));
  OAI21x1_ASAP7_75t_R g078(.A1(new_n118_), .A2(new_n150_), .B(new_n142_), .Y(new_n152_));
  OA21x2_ASAP7_75t_R  g079(.A1(new_n143_), .A2(new_n151_), .B(new_n152_), .Y(new_n153_));
  AND2x2_ASAP7_75t_R  g080(.A(G41), .B(G40), .Y(new_n154_));
  XOR2x2_ASAP7_75t_R  g081(.A(G8), .B(G7), .Y(new_n155_));
  XOR2x2_ASAP7_75t_R  g082(.A(G5), .B(G6), .Y(new_n156_));
  XOR2x2_ASAP7_75t_R  g083(.A(new_n155_), .B(new_n156_), .Y(new_n157_));
  XOR2x2_ASAP7_75t_R  g084(.A(new_n154_), .B(new_n157_), .Y(new_n158_));
  XNOR2x2_ASAP7_75t_R g085(.A(G32), .B(G28), .Y(new_n159_));
  XOR2x2_ASAP7_75t_R  g086(.A(G20), .B(G24), .Y(new_n160_));
  XOR2x2_ASAP7_75t_R  g087(.A(new_n159_), .B(new_n160_), .Y(new_n161_));
  XNOR2x2_ASAP7_75t_R g088(.A(G16), .B(G15), .Y(new_n162_));
  XOR2x2_ASAP7_75t_R  g089(.A(G13), .B(G14), .Y(new_n163_));
  XOR2x2_ASAP7_75t_R  g090(.A(new_n162_), .B(new_n163_), .Y(new_n164_));
  XOR2x2_ASAP7_75t_R  g091(.A(new_n161_), .B(new_n164_), .Y(new_n165_));
  NOR2x1_ASAP7_75t_R  g092(.A(new_n158_), .B(new_n165_), .Y(new_n166_));
  AND2x2_ASAP7_75t_R  g093(.A(new_n158_), .B(new_n165_), .Y(new_n167_));
  XOR2x2_ASAP7_75t_R  g094(.A(new_n158_), .B(new_n165_), .Y(new_n168_));
  INVx1_ASAP7_75t_R   g095(.A(new_n168_), .Y(new_n169_));
  NAND2x1_ASAP7_75t_R g096(.A(G41), .B(G38), .Y(new_n170_));
  XOR2x2_ASAP7_75t_R  g097(.A(new_n164_), .B(new_n170_), .Y(new_n171_));
  XNOR2x2_ASAP7_75t_R g098(.A(G12), .B(G11), .Y(new_n172_));
  XOR2x2_ASAP7_75t_R  g099(.A(G9), .B(G10), .Y(new_n173_));
  XOR2x2_ASAP7_75t_R  g100(.A(new_n172_), .B(new_n173_), .Y(new_n174_));
  XNOR2x2_ASAP7_75t_R g101(.A(G30), .B(G26), .Y(new_n175_));
  XOR2x2_ASAP7_75t_R  g102(.A(G18), .B(G22), .Y(new_n176_));
  XOR2x2_ASAP7_75t_R  g103(.A(new_n175_), .B(new_n176_), .Y(new_n177_));
  XOR2x2_ASAP7_75t_R  g104(.A(new_n174_), .B(new_n177_), .Y(new_n178_));
  XOR2x2_ASAP7_75t_R  g105(.A(new_n171_), .B(new_n178_), .Y(new_n179_));
  NAND2x1_ASAP7_75t_R g106(.A(G41), .B(G37), .Y(new_n180_));
  XOR2x2_ASAP7_75t_R  g107(.A(new_n157_), .B(new_n180_), .Y(new_n181_));
  XNOR2x2_ASAP7_75t_R g108(.A(G4), .B(G3), .Y(new_n182_));
  XOR2x2_ASAP7_75t_R  g109(.A(G1), .B(G2), .Y(new_n183_));
  XOR2x2_ASAP7_75t_R  g110(.A(new_n182_), .B(new_n183_), .Y(new_n184_));
  XNOR2x2_ASAP7_75t_R g111(.A(G29), .B(G25), .Y(new_n185_));
  XOR2x2_ASAP7_75t_R  g112(.A(G17), .B(G21), .Y(new_n186_));
  XOR2x2_ASAP7_75t_R  g113(.A(new_n185_), .B(new_n186_), .Y(new_n187_));
  XOR2x2_ASAP7_75t_R  g114(.A(new_n184_), .B(new_n187_), .Y(new_n188_));
  XOR2x2_ASAP7_75t_R  g115(.A(new_n181_), .B(new_n188_), .Y(new_n189_));
  XNOR2x2_ASAP7_75t_R g116(.A(new_n181_), .B(new_n188_), .Y(new_n190_));
  NOR2x1_ASAP7_75t_R  g117(.A(new_n179_), .B(new_n189_), .Y(new_n191_));
  AND2x2_ASAP7_75t_R  g118(.A(G41), .B(G39), .Y(new_n192_));
  XOR2x2_ASAP7_75t_R  g119(.A(new_n184_), .B(new_n192_), .Y(new_n193_));
  XNOR2x2_ASAP7_75t_R g120(.A(G31), .B(G27), .Y(new_n194_));
  XOR2x2_ASAP7_75t_R  g121(.A(G19), .B(G23), .Y(new_n195_));
  XOR2x2_ASAP7_75t_R  g122(.A(new_n194_), .B(new_n195_), .Y(new_n196_));
  XOR2x2_ASAP7_75t_R  g123(.A(new_n174_), .B(new_n196_), .Y(new_n197_));
  XOR2x2_ASAP7_75t_R  g124(.A(new_n193_), .B(new_n197_), .Y(new_n198_));
  XNOR2x2_ASAP7_75t_R g125(.A(new_n193_), .B(new_n197_), .Y(new_n199_));
  AND2x2_ASAP7_75t_R  g126(.A(new_n191_), .B(new_n199_), .Y(new_n200_));
  AND3x1_ASAP7_75t_R  g127(.A(new_n153_), .B(new_n169_), .C(new_n200_), .Y(new_n201_));
  AOI21x1_ASAP7_75t_R g128(.A1(new_n118_), .A2(new_n201_), .B(new_n74_), .Y(new_n202_));
  AND3x1_ASAP7_75t_R  g129(.A(new_n201_), .B(new_n118_), .C(new_n74_), .Y(new_n203_));
  NOR2x1_ASAP7_75t_R  g130(.A(new_n202_), .B(new_n203_), .Y(G1324));
  OAI21x1_ASAP7_75t_R g131(.A1(new_n166_), .A2(new_n167_), .B(new_n198_), .Y(new_n205_));
  XOR2x2_ASAP7_75t_R  g132(.A(new_n168_), .B(new_n199_), .Y(new_n206_));
  XOR2x2_ASAP7_75t_R  g133(.A(new_n179_), .B(new_n190_), .Y(new_n207_));
  OAI21x1_ASAP7_75t_R g134(.A1(new_n179_), .A2(new_n190_), .B(new_n205_), .Y(new_n208_));
  OA21x2_ASAP7_75t_R  g135(.A1(new_n206_), .A2(new_n207_), .B(new_n208_), .Y(new_n209_));
  NOR3x1_ASAP7_75t_R  g136(.A(new_n119_), .B(new_n141_), .C(new_n150_), .Y(new_n210_));
  AND3x1_ASAP7_75t_R  g137(.A(new_n209_), .B(new_n210_), .C(new_n130_), .Y(new_n211_));
  AOI21x1_ASAP7_75t_R g138(.A1(new_n190_), .A2(new_n211_), .B(new_n82_), .Y(new_n212_));
  AND3x1_ASAP7_75t_R  g139(.A(new_n211_), .B(new_n190_), .C(new_n82_), .Y(new_n213_));
  NOR2x1_ASAP7_75t_R  g140(.A(new_n212_), .B(new_n213_), .Y(G1344));
  AOI21x1_ASAP7_75t_R g141(.A1(new_n150_), .A2(new_n201_), .B(new_n102_), .Y(new_n215_));
  AND3x1_ASAP7_75t_R  g142(.A(new_n201_), .B(new_n150_), .C(new_n102_), .Y(new_n216_));
  NOR2x1_ASAP7_75t_R  g143(.A(new_n215_), .B(new_n216_), .Y(G1325));
  AOI21x1_ASAP7_75t_R g144(.A1(new_n141_), .A2(new_n201_), .B(new_n94_), .Y(new_n218_));
  AND3x1_ASAP7_75t_R  g145(.A(new_n201_), .B(new_n141_), .C(new_n94_), .Y(new_n219_));
  NOR2x1_ASAP7_75t_R  g146(.A(new_n218_), .B(new_n219_), .Y(G1326));
  AOI21x1_ASAP7_75t_R g147(.A1(new_n130_), .A2(new_n201_), .B(new_n86_), .Y(new_n221_));
  AND3x1_ASAP7_75t_R  g148(.A(new_n201_), .B(new_n130_), .C(new_n86_), .Y(new_n222_));
  NOR2x1_ASAP7_75t_R  g149(.A(new_n221_), .B(new_n222_), .Y(G1327));
  AND2x2_ASAP7_75t_R  g150(.A(new_n191_), .B(new_n198_), .Y(new_n224_));
  AND3x1_ASAP7_75t_R  g151(.A(new_n153_), .B(new_n168_), .C(new_n224_), .Y(new_n225_));
  AOI21x1_ASAP7_75t_R g152(.A1(new_n118_), .A2(new_n225_), .B(new_n75_), .Y(new_n226_));
  AND3x1_ASAP7_75t_R  g153(.A(new_n225_), .B(new_n118_), .C(new_n75_), .Y(new_n227_));
  NOR2x1_ASAP7_75t_R  g154(.A(new_n226_), .B(new_n227_), .Y(G1328));
  AOI21x1_ASAP7_75t_R g155(.A1(new_n150_), .A2(new_n225_), .B(new_n103_), .Y(new_n229_));
  AND3x1_ASAP7_75t_R  g156(.A(new_n225_), .B(new_n150_), .C(new_n103_), .Y(new_n230_));
  NOR2x1_ASAP7_75t_R  g157(.A(new_n229_), .B(new_n230_), .Y(G1329));
  AOI21x1_ASAP7_75t_R g158(.A1(new_n141_), .A2(new_n225_), .B(new_n95_), .Y(new_n232_));
  AND3x1_ASAP7_75t_R  g159(.A(new_n225_), .B(new_n141_), .C(new_n95_), .Y(new_n233_));
  NOR2x1_ASAP7_75t_R  g160(.A(new_n232_), .B(new_n233_), .Y(G1330));
  OR3x1_ASAP7_75t_R   g161(.A(new_n119_), .B(new_n140_), .C(new_n150_), .Y(new_n235_));
  INVx1_ASAP7_75t_R   g162(.A(new_n235_), .Y(new_n236_));
  AND3x1_ASAP7_75t_R  g163(.A(new_n129_), .B(new_n209_), .C(new_n236_), .Y(new_n237_));
  AOI21x1_ASAP7_75t_R g164(.A1(new_n168_), .A2(new_n237_), .B(new_n81_), .Y(new_n238_));
  AND3x1_ASAP7_75t_R  g165(.A(new_n237_), .B(new_n81_), .C(new_n168_), .Y(new_n239_));
  NOR2x1_ASAP7_75t_R  g166(.A(new_n238_), .B(new_n239_), .Y(G1343));
  AOI21x1_ASAP7_75t_R g167(.A1(new_n130_), .A2(new_n225_), .B(new_n87_), .Y(new_n241_));
  AND3x1_ASAP7_75t_R  g168(.A(new_n225_), .B(new_n130_), .C(new_n87_), .Y(new_n242_));
  NOR2x1_ASAP7_75t_R  g169(.A(new_n241_), .B(new_n242_), .Y(G1331));
  AND3x1_ASAP7_75t_R  g170(.A(new_n179_), .B(new_n199_), .C(new_n189_), .Y(new_n244_));
  AND3x1_ASAP7_75t_R  g171(.A(new_n153_), .B(new_n169_), .C(new_n244_), .Y(new_n245_));
  AOI21x1_ASAP7_75t_R g172(.A1(new_n118_), .A2(new_n245_), .B(new_n76_), .Y(new_n246_));
  AND3x1_ASAP7_75t_R  g173(.A(new_n245_), .B(new_n118_), .C(new_n76_), .Y(new_n247_));
  NOR2x1_ASAP7_75t_R  g174(.A(new_n246_), .B(new_n247_), .Y(G1332));
  AOI21x1_ASAP7_75t_R g175(.A1(new_n150_), .A2(new_n245_), .B(new_n104_), .Y(new_n249_));
  AND3x1_ASAP7_75t_R  g176(.A(new_n245_), .B(new_n150_), .C(new_n104_), .Y(new_n250_));
  NOR2x1_ASAP7_75t_R  g177(.A(new_n249_), .B(new_n250_), .Y(G1333));
  AOI21x1_ASAP7_75t_R g178(.A1(new_n141_), .A2(new_n245_), .B(new_n96_), .Y(new_n252_));
  AND3x1_ASAP7_75t_R  g179(.A(new_n245_), .B(new_n141_), .C(new_n96_), .Y(new_n253_));
  NOR2x1_ASAP7_75t_R  g180(.A(new_n252_), .B(new_n253_), .Y(G1334));
  AOI21x1_ASAP7_75t_R g181(.A1(new_n130_), .A2(new_n245_), .B(new_n88_), .Y(new_n255_));
  AND3x1_ASAP7_75t_R  g182(.A(new_n245_), .B(new_n130_), .C(new_n88_), .Y(new_n256_));
  NOR2x1_ASAP7_75t_R  g183(.A(new_n255_), .B(new_n256_), .Y(G1335));
  AND3x1_ASAP7_75t_R  g184(.A(new_n179_), .B(new_n189_), .C(new_n198_), .Y(new_n258_));
  AND3x1_ASAP7_75t_R  g185(.A(new_n153_), .B(new_n168_), .C(new_n258_), .Y(new_n259_));
  AOI21x1_ASAP7_75t_R g186(.A1(new_n118_), .A2(new_n259_), .B(new_n77_), .Y(new_n260_));
  AND3x1_ASAP7_75t_R  g187(.A(new_n259_), .B(new_n118_), .C(new_n77_), .Y(new_n261_));
  NOR2x1_ASAP7_75t_R  g188(.A(new_n260_), .B(new_n261_), .Y(G1336));
  AOI21x1_ASAP7_75t_R g189(.A1(new_n150_), .A2(new_n259_), .B(new_n105_), .Y(new_n263_));
  AND3x1_ASAP7_75t_R  g190(.A(new_n259_), .B(new_n150_), .C(new_n105_), .Y(new_n264_));
  NOR2x1_ASAP7_75t_R  g191(.A(new_n263_), .B(new_n264_), .Y(G1337));
  AOI21x1_ASAP7_75t_R g192(.A1(new_n141_), .A2(new_n259_), .B(new_n97_), .Y(new_n266_));
  AND3x1_ASAP7_75t_R  g193(.A(new_n259_), .B(new_n141_), .C(new_n97_), .Y(new_n267_));
  NOR2x1_ASAP7_75t_R  g194(.A(new_n266_), .B(new_n267_), .Y(G1338));
  AOI21x1_ASAP7_75t_R g195(.A1(new_n130_), .A2(new_n259_), .B(new_n89_), .Y(new_n269_));
  AND3x1_ASAP7_75t_R  g196(.A(new_n259_), .B(new_n130_), .C(new_n89_), .Y(new_n270_));
  NOR2x1_ASAP7_75t_R  g197(.A(new_n269_), .B(new_n270_), .Y(G1339));
  AOI21x1_ASAP7_75t_R g198(.A1(new_n190_), .A2(new_n237_), .B(new_n78_), .Y(new_n272_));
  AND3x1_ASAP7_75t_R  g199(.A(new_n237_), .B(new_n190_), .C(new_n78_), .Y(new_n273_));
  NOR2x1_ASAP7_75t_R  g200(.A(new_n272_), .B(new_n273_), .Y(G1340));
  AOI21x1_ASAP7_75t_R g201(.A1(new_n179_), .A2(new_n237_), .B(new_n79_), .Y(new_n275_));
  AND3x1_ASAP7_75t_R  g202(.A(new_n237_), .B(new_n179_), .C(new_n79_), .Y(new_n276_));
  NOR2x1_ASAP7_75t_R  g203(.A(new_n275_), .B(new_n276_), .Y(G1341));
  AOI21x1_ASAP7_75t_R g204(.A1(new_n199_), .A2(new_n237_), .B(new_n80_), .Y(new_n278_));
  AND3x1_ASAP7_75t_R  g205(.A(new_n237_), .B(new_n199_), .C(new_n80_), .Y(new_n279_));
  NOR2x1_ASAP7_75t_R  g206(.A(new_n278_), .B(new_n279_), .Y(G1342));
  AOI21x1_ASAP7_75t_R g207(.A1(new_n179_), .A2(new_n211_), .B(new_n83_), .Y(new_n281_));
  AND3x1_ASAP7_75t_R  g208(.A(new_n211_), .B(new_n179_), .C(new_n83_), .Y(new_n282_));
  NOR2x1_ASAP7_75t_R  g209(.A(new_n281_), .B(new_n282_), .Y(G1345));
  AOI21x1_ASAP7_75t_R g210(.A1(new_n199_), .A2(new_n211_), .B(new_n84_), .Y(new_n284_));
  AND3x1_ASAP7_75t_R  g211(.A(new_n211_), .B(new_n199_), .C(new_n84_), .Y(new_n285_));
  NOR2x1_ASAP7_75t_R  g212(.A(new_n284_), .B(new_n285_), .Y(G1346));
  AOI21x1_ASAP7_75t_R g213(.A1(new_n168_), .A2(new_n211_), .B(new_n85_), .Y(new_n287_));
  AND3x1_ASAP7_75t_R  g214(.A(new_n211_), .B(new_n85_), .C(new_n168_), .Y(new_n288_));
  NOR2x1_ASAP7_75t_R  g215(.A(new_n287_), .B(new_n288_), .Y(G1347));
  AND3x1_ASAP7_75t_R  g216(.A(new_n119_), .B(new_n141_), .C(new_n150_), .Y(new_n290_));
  AND3x1_ASAP7_75t_R  g217(.A(new_n129_), .B(new_n209_), .C(new_n290_), .Y(new_n291_));
  AOI21x1_ASAP7_75t_R g218(.A1(new_n190_), .A2(new_n291_), .B(new_n98_), .Y(new_n292_));
  AND3x1_ASAP7_75t_R  g219(.A(new_n291_), .B(new_n190_), .C(new_n98_), .Y(new_n293_));
  NOR2x1_ASAP7_75t_R  g220(.A(new_n292_), .B(new_n293_), .Y(G1348));
  AOI21x1_ASAP7_75t_R g221(.A1(new_n179_), .A2(new_n291_), .B(new_n99_), .Y(new_n295_));
  AND3x1_ASAP7_75t_R  g222(.A(new_n291_), .B(new_n179_), .C(new_n99_), .Y(new_n296_));
  NOR2x1_ASAP7_75t_R  g223(.A(new_n295_), .B(new_n296_), .Y(G1349));
  AOI21x1_ASAP7_75t_R g224(.A1(new_n199_), .A2(new_n291_), .B(new_n100_), .Y(new_n298_));
  AND3x1_ASAP7_75t_R  g225(.A(new_n291_), .B(new_n199_), .C(new_n100_), .Y(new_n299_));
  NOR2x1_ASAP7_75t_R  g226(.A(new_n298_), .B(new_n299_), .Y(G1350));
  AOI21x1_ASAP7_75t_R g227(.A1(new_n168_), .A2(new_n291_), .B(new_n101_), .Y(new_n301_));
  AND3x1_ASAP7_75t_R  g228(.A(new_n291_), .B(new_n101_), .C(new_n168_), .Y(new_n302_));
  NOR2x1_ASAP7_75t_R  g229(.A(new_n301_), .B(new_n302_), .Y(G1351));
  AND3x1_ASAP7_75t_R  g230(.A(new_n119_), .B(new_n140_), .C(new_n150_), .Y(new_n304_));
  AND3x1_ASAP7_75t_R  g231(.A(new_n209_), .B(new_n304_), .C(new_n130_), .Y(new_n305_));
  AOI21x1_ASAP7_75t_R g232(.A1(new_n190_), .A2(new_n305_), .B(new_n90_), .Y(new_n306_));
  AND3x1_ASAP7_75t_R  g233(.A(new_n305_), .B(new_n190_), .C(new_n90_), .Y(new_n307_));
  NOR2x1_ASAP7_75t_R  g234(.A(new_n306_), .B(new_n307_), .Y(G1352));
  AOI21x1_ASAP7_75t_R g235(.A1(new_n179_), .A2(new_n305_), .B(new_n91_), .Y(new_n309_));
  AND3x1_ASAP7_75t_R  g236(.A(new_n305_), .B(new_n179_), .C(new_n91_), .Y(new_n310_));
  NOR2x1_ASAP7_75t_R  g237(.A(new_n309_), .B(new_n310_), .Y(G1353));
  AOI21x1_ASAP7_75t_R g238(.A1(new_n199_), .A2(new_n305_), .B(new_n92_), .Y(new_n312_));
  AND3x1_ASAP7_75t_R  g239(.A(new_n305_), .B(new_n199_), .C(new_n92_), .Y(new_n313_));
  NOR2x1_ASAP7_75t_R  g240(.A(new_n312_), .B(new_n313_), .Y(G1354));
  AOI21x1_ASAP7_75t_R g241(.A1(new_n168_), .A2(new_n305_), .B(new_n93_), .Y(new_n315_));
  AND3x1_ASAP7_75t_R  g242(.A(new_n305_), .B(new_n93_), .C(new_n168_), .Y(new_n316_));
  NOR2x1_ASAP7_75t_R  g243(.A(new_n315_), .B(new_n316_), .Y(G1355));
endmodule


