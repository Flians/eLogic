// Benchmark "/home/flynn/workplace/MIGBalance/results_v2/fixed_all_area_20261012/c432.resyn2" written by ABC on Mon Oct 12 14:59:04 2026

module \/home/flynn/workplace/MIGBalance/results_v2/fixed_all_area_20261012/c432.resyn2  ( 
    G32, G34, G28, G30, G24, G26, G20, G22, G16, G18, G12, G14, G8, G10,
    G4, G6, G1, G2, G35, G31, G27, G23, G19, G15, G11, G7, G3, G36, G33,
    G29, G25, G21, G17, G13, G9, G5,
    G426, G427, G428, G429, G430, G431, G432  );
  input  G32, G34, G28, G30, G24, G26, G20, G22, G16, G18, G12, G14, G8,
    G10, G4, G6, G1, G2, G35, G31, G27, G23, G19, G15, G11, G7, G3, G36,
    G33, G29, G25, G21, G17, G13, G9, G5;
  output G426, G427, G428, G429, G430, G431, G432;
  wire new_n44_, new_n45_, new_n46_, new_n47_, new_n48_, new_n49_, new_n50_,
    new_n51_, new_n52_, new_n53_, new_n54_, new_n55_, new_n56_, new_n57_,
    new_n58_, new_n59_, new_n60_, new_n61_, new_n62_, new_n64_, new_n65_,
    new_n66_, new_n67_, new_n68_, new_n69_, new_n70_, new_n71_, new_n72_,
    new_n73_, new_n74_, new_n75_, new_n76_, new_n77_, new_n78_, new_n79_,
    new_n80_, new_n81_, new_n82_, new_n83_, new_n84_, new_n85_, new_n86_,
    new_n87_, new_n88_, new_n89_, new_n90_, new_n91_, new_n93_, new_n94_,
    new_n95_, new_n96_, new_n97_, new_n98_, new_n99_, new_n100_, new_n101_,
    new_n102_, new_n103_, new_n104_, new_n105_, new_n106_, new_n107_,
    new_n108_, new_n109_, new_n110_, new_n111_, new_n112_, new_n113_,
    new_n114_, new_n115_, new_n116_, new_n117_, new_n118_, new_n119_,
    new_n120_, new_n121_, new_n122_, new_n123_, new_n124_, new_n125_,
    new_n126_, new_n127_, new_n128_, new_n129_, new_n130_, new_n132_,
    new_n133_, new_n134_, new_n135_, new_n136_, new_n137_, new_n138_,
    new_n139_, new_n140_, new_n141_, new_n142_, new_n143_, new_n144_,
    new_n145_, new_n146_, new_n147_, new_n148_, new_n149_, new_n150_,
    new_n151_, new_n152_, new_n153_, new_n154_, new_n155_, new_n156_,
    new_n157_, new_n158_, new_n159_, new_n160_, new_n161_, new_n162_,
    new_n163_, new_n166_, new_n167_, new_n168_, new_n169_, new_n170_,
    new_n172_, new_n173_, new_n174_, new_n175_, new_n176_;
  INVx1_ASAP7_75t_R   g000(.A(G18), .Y(new_n44_));
  INVx1_ASAP7_75t_R   g001(.A(G14), .Y(new_n45_));
  INVx1_ASAP7_75t_R   g002(.A(G20), .Y(new_n46_));
  NAND2x1_ASAP7_75t_R g003(.A(G22), .B(new_n46_), .Y(new_n47_));
  OA21x2_ASAP7_75t_R  g004(.A1(G12), .A2(new_n45_), .B(new_n47_), .Y(new_n48_));
  OA21x2_ASAP7_75t_R  g005(.A1(G16), .A2(new_n44_), .B(new_n48_), .Y(new_n49_));
  INVx1_ASAP7_75t_R   g006(.A(G30), .Y(new_n50_));
  INVx1_ASAP7_75t_R   g007(.A(G32), .Y(new_n51_));
  NAND2x1_ASAP7_75t_R g008(.A(G34), .B(new_n51_), .Y(new_n52_));
  OA21x2_ASAP7_75t_R  g009(.A1(G28), .A2(new_n50_), .B(new_n52_), .Y(new_n53_));
  INVx1_ASAP7_75t_R   g010(.A(G10), .Y(new_n54_));
  INVx1_ASAP7_75t_R   g011(.A(G24), .Y(new_n55_));
  NAND2x1_ASAP7_75t_R g012(.A(G26), .B(new_n55_), .Y(new_n56_));
  OA21x2_ASAP7_75t_R  g013(.A1(G8), .A2(new_n54_), .B(new_n56_), .Y(new_n57_));
  INVx1_ASAP7_75t_R   g014(.A(G6), .Y(new_n58_));
  INVx1_ASAP7_75t_R   g015(.A(G1), .Y(new_n59_));
  NAND2x1_ASAP7_75t_R g016(.A(G2), .B(new_n59_), .Y(new_n60_));
  OA21x2_ASAP7_75t_R  g017(.A1(G4), .A2(new_n58_), .B(new_n60_), .Y(new_n61_));
  AND3x1_ASAP7_75t_R  g018(.A(new_n53_), .B(new_n57_), .C(new_n61_), .Y(new_n62_));
  NAND2x1_ASAP7_75t_R g019(.A(new_n49_), .B(new_n62_), .Y(G426));
  INVx1_ASAP7_75t_R   g020(.A(G31), .Y(new_n64_));
  AOI21x1_ASAP7_75t_R g021(.A1(G28), .A2(G426), .B(new_n50_), .Y(new_n65_));
  NAND2x1_ASAP7_75t_R g022(.A(new_n64_), .B(new_n65_), .Y(new_n66_));
  AND3x1_ASAP7_75t_R  g023(.A(new_n62_), .B(new_n49_), .C(new_n56_), .Y(new_n67_));
  AOI21x1_ASAP7_75t_R g024(.A1(new_n49_), .A2(new_n62_), .B(new_n56_), .Y(new_n68_));
  INVx1_ASAP7_75t_R   g025(.A(G27), .Y(new_n69_));
  AND2x2_ASAP7_75t_R  g026(.A(new_n69_), .B(G26), .Y(new_n70_));
  OAI21x1_ASAP7_75t_R g027(.A1(new_n68_), .A2(new_n67_), .B(new_n70_), .Y(new_n71_));
  INVx1_ASAP7_75t_R   g028(.A(G11), .Y(new_n72_));
  AOI21x1_ASAP7_75t_R g029(.A1(G8), .A2(G426), .B(new_n54_), .Y(new_n73_));
  NAND2x1_ASAP7_75t_R g030(.A(new_n72_), .B(new_n73_), .Y(new_n74_));
  AND3x1_ASAP7_75t_R  g031(.A(new_n66_), .B(new_n74_), .C(new_n71_), .Y(new_n75_));
  INVx1_ASAP7_75t_R   g032(.A(G22), .Y(new_n76_));
  AOI21x1_ASAP7_75t_R g033(.A1(new_n49_), .A2(new_n62_), .B(new_n46_), .Y(new_n77_));
  OR3x1_ASAP7_75t_R   g034(.A(new_n77_), .B(new_n76_), .C(G23), .Y(new_n78_));
  AO21x1_ASAP7_75t_R  g035(.A1(G426), .A2(G12), .B(new_n45_), .Y(new_n79_));
  OA21x2_ASAP7_75t_R  g036(.A1(G15), .A2(new_n79_), .B(new_n78_), .Y(new_n80_));
  AO21x1_ASAP7_75t_R  g037(.A1(G426), .A2(G16), .B(new_n44_), .Y(new_n81_));
  INVx1_ASAP7_75t_R   g038(.A(G2), .Y(new_n82_));
  AOI21x1_ASAP7_75t_R g039(.A1(new_n49_), .A2(new_n62_), .B(new_n59_), .Y(new_n83_));
  OR3x1_ASAP7_75t_R   g040(.A(new_n83_), .B(new_n82_), .C(G3), .Y(new_n84_));
  OA21x2_ASAP7_75t_R  g041(.A1(G19), .A2(new_n81_), .B(new_n84_), .Y(new_n85_));
  INVx1_ASAP7_75t_R   g042(.A(G34), .Y(new_n86_));
  AOI21x1_ASAP7_75t_R g043(.A1(new_n49_), .A2(new_n62_), .B(new_n51_), .Y(new_n87_));
  OR3x1_ASAP7_75t_R   g044(.A(new_n87_), .B(new_n86_), .C(G35), .Y(new_n88_));
  AO21x1_ASAP7_75t_R  g045(.A1(G426), .A2(G4), .B(new_n58_), .Y(new_n89_));
  OA21x2_ASAP7_75t_R  g046(.A1(G7), .A2(new_n89_), .B(new_n88_), .Y(new_n90_));
  AND3x1_ASAP7_75t_R  g047(.A(new_n80_), .B(new_n85_), .C(new_n90_), .Y(new_n91_));
  NAND2x1_ASAP7_75t_R g048(.A(new_n75_), .B(new_n91_), .Y(G427));
  INVx1_ASAP7_75t_R   g049(.A(G19), .Y(new_n93_));
  AOI21x1_ASAP7_75t_R g050(.A1(new_n75_), .A2(new_n91_), .B(new_n93_), .Y(new_n94_));
  OR3x1_ASAP7_75t_R   g051(.A(new_n94_), .B(G21), .C(new_n81_), .Y(new_n95_));
  NOR2x1_ASAP7_75t_R  g052(.A(new_n76_), .B(new_n77_), .Y(new_n96_));
  INVx1_ASAP7_75t_R   g053(.A(new_n96_), .Y(new_n97_));
  INVx1_ASAP7_75t_R   g054(.A(G23), .Y(new_n98_));
  AOI21x1_ASAP7_75t_R g055(.A1(new_n75_), .A2(new_n91_), .B(new_n98_), .Y(new_n99_));
  OR3x1_ASAP7_75t_R   g056(.A(new_n99_), .B(G25), .C(new_n97_), .Y(new_n100_));
  INVx1_ASAP7_75t_R   g057(.A(G15), .Y(new_n101_));
  AOI21x1_ASAP7_75t_R g058(.A1(new_n75_), .A2(new_n91_), .B(new_n101_), .Y(new_n102_));
  OR3x1_ASAP7_75t_R   g059(.A(new_n102_), .B(G17), .C(new_n79_), .Y(new_n103_));
  AND3x1_ASAP7_75t_R  g060(.A(new_n95_), .B(new_n100_), .C(new_n103_), .Y(new_n104_));
  INVx1_ASAP7_75t_R   g061(.A(G7), .Y(new_n105_));
  AOI21x1_ASAP7_75t_R g062(.A1(new_n75_), .A2(new_n91_), .B(new_n105_), .Y(new_n106_));
  OR3x1_ASAP7_75t_R   g063(.A(new_n106_), .B(G9), .C(new_n89_), .Y(new_n107_));
  AO21x1_ASAP7_75t_R  g064(.A1(G426), .A2(G1), .B(new_n82_), .Y(new_n108_));
  AO21x1_ASAP7_75t_R  g065(.A1(G427), .A2(G3), .B(new_n108_), .Y(new_n109_));
  OA21x2_ASAP7_75t_R  g066(.A1(G5), .A2(new_n109_), .B(new_n107_), .Y(new_n110_));
  AND2x2_ASAP7_75t_R  g067(.A(new_n91_), .B(new_n75_), .Y(new_n111_));
  OAI21x1_ASAP7_75t_R g068(.A1(new_n64_), .A2(new_n111_), .B(new_n65_), .Y(new_n112_));
  INVx1_ASAP7_75t_R   g069(.A(G33), .Y(new_n113_));
  OAI21x1_ASAP7_75t_R g070(.A1(new_n66_), .A2(G427), .B(new_n113_), .Y(new_n114_));
  AO21x1_ASAP7_75t_R  g071(.A1(G426), .A2(G32), .B(new_n86_), .Y(new_n115_));
  INVx1_ASAP7_75t_R   g072(.A(G35), .Y(new_n116_));
  AOI21x1_ASAP7_75t_R g073(.A1(new_n75_), .A2(new_n91_), .B(new_n116_), .Y(new_n117_));
  OR3x1_ASAP7_75t_R   g074(.A(new_n117_), .B(G36), .C(new_n115_), .Y(new_n118_));
  OA21x2_ASAP7_75t_R  g075(.A1(new_n112_), .A2(new_n114_), .B(new_n118_), .Y(new_n119_));
  INVx1_ASAP7_75t_R   g076(.A(new_n73_), .Y(new_n120_));
  AOI21x1_ASAP7_75t_R g077(.A1(new_n75_), .A2(new_n91_), .B(new_n72_), .Y(new_n121_));
  OR3x1_ASAP7_75t_R   g078(.A(new_n121_), .B(G13), .C(new_n120_), .Y(new_n122_));
  INVx1_ASAP7_75t_R   g079(.A(new_n71_), .Y(new_n123_));
  AND3x1_ASAP7_75t_R  g080(.A(new_n91_), .B(new_n123_), .C(new_n75_), .Y(new_n124_));
  INVx1_ASAP7_75t_R   g081(.A(G29), .Y(new_n125_));
  AND2x2_ASAP7_75t_R  g082(.A(new_n125_), .B(G26), .Y(new_n126_));
  OAI21x1_ASAP7_75t_R g083(.A1(new_n68_), .A2(new_n67_), .B(new_n126_), .Y(new_n127_));
  AO21x1_ASAP7_75t_R  g084(.A1(G427), .A2(new_n71_), .B(new_n127_), .Y(new_n128_));
  OA21x2_ASAP7_75t_R  g085(.A1(new_n124_), .A2(new_n128_), .B(new_n122_), .Y(new_n129_));
  AND3x1_ASAP7_75t_R  g086(.A(new_n110_), .B(new_n119_), .C(new_n129_), .Y(new_n130_));
  NAND2x1_ASAP7_75t_R g087(.A(new_n104_), .B(new_n130_), .Y(G428));
  AOI21x1_ASAP7_75t_R g088(.A1(G5), .A2(G428), .B(new_n109_), .Y(new_n132_));
  AO21x1_ASAP7_75t_R  g089(.A1(G427), .A2(G19), .B(new_n81_), .Y(new_n133_));
  INVx1_ASAP7_75t_R   g090(.A(G21), .Y(new_n134_));
  AOI21x1_ASAP7_75t_R g091(.A1(new_n104_), .A2(new_n130_), .B(new_n134_), .Y(new_n135_));
  INVx1_ASAP7_75t_R   g092(.A(G17), .Y(new_n136_));
  NOR2x1_ASAP7_75t_R  g093(.A(new_n79_), .B(new_n102_), .Y(new_n137_));
  AND2x2_ASAP7_75t_R  g094(.A(new_n119_), .B(new_n129_), .Y(new_n138_));
  AND3x1_ASAP7_75t_R  g095(.A(new_n138_), .B(new_n104_), .C(new_n110_), .Y(new_n139_));
  OAI21x1_ASAP7_75t_R g096(.A1(new_n136_), .A2(new_n139_), .B(new_n137_), .Y(new_n140_));
  OA21x2_ASAP7_75t_R  g097(.A1(new_n133_), .A2(new_n135_), .B(new_n140_), .Y(new_n141_));
  AO21x1_ASAP7_75t_R  g098(.A1(G427), .A2(G7), .B(new_n89_), .Y(new_n142_));
  INVx1_ASAP7_75t_R   g099(.A(G13), .Y(new_n143_));
  NOR2x1_ASAP7_75t_R  g100(.A(new_n120_), .B(new_n121_), .Y(new_n144_));
  OAI21x1_ASAP7_75t_R g101(.A1(new_n143_), .A2(new_n139_), .B(new_n144_), .Y(new_n145_));
  INVx1_ASAP7_75t_R   g102(.A(G9), .Y(new_n146_));
  AOI21x1_ASAP7_75t_R g103(.A1(new_n104_), .A2(new_n130_), .B(new_n146_), .Y(new_n147_));
  OA21x2_ASAP7_75t_R  g104(.A1(new_n142_), .A2(new_n147_), .B(new_n145_), .Y(new_n148_));
  AND2x2_ASAP7_75t_R  g105(.A(new_n141_), .B(new_n148_), .Y(new_n149_));
  AO21x1_ASAP7_75t_R  g106(.A1(G427), .A2(G35), .B(new_n115_), .Y(new_n150_));
  INVx1_ASAP7_75t_R   g107(.A(G36), .Y(new_n151_));
  AOI21x1_ASAP7_75t_R g108(.A1(new_n104_), .A2(new_n130_), .B(new_n151_), .Y(new_n152_));
  INVx1_ASAP7_75t_R   g109(.A(G26), .Y(new_n153_));
  AO21x1_ASAP7_75t_R  g110(.A1(G426), .A2(G24), .B(new_n153_), .Y(new_n154_));
  AOI21x1_ASAP7_75t_R g111(.A1(G27), .A2(G427), .B(new_n154_), .Y(new_n155_));
  OAI21x1_ASAP7_75t_R g112(.A1(new_n125_), .A2(new_n139_), .B(new_n155_), .Y(new_n156_));
  OA21x2_ASAP7_75t_R  g113(.A1(new_n150_), .A2(new_n152_), .B(new_n156_), .Y(new_n157_));
  INVx1_ASAP7_75t_R   g114(.A(G25), .Y(new_n158_));
  NOR2x1_ASAP7_75t_R  g115(.A(new_n97_), .B(new_n99_), .Y(new_n159_));
  OAI21x1_ASAP7_75t_R g116(.A1(new_n158_), .A2(new_n139_), .B(new_n159_), .Y(new_n160_));
  AOI21x1_ASAP7_75t_R g117(.A1(new_n104_), .A2(new_n130_), .B(new_n113_), .Y(new_n161_));
  OA21x2_ASAP7_75t_R  g118(.A1(new_n112_), .A2(new_n161_), .B(new_n160_), .Y(new_n162_));
  AND2x2_ASAP7_75t_R  g119(.A(new_n157_), .B(new_n162_), .Y(new_n163_));
  AOI21x1_ASAP7_75t_R g120(.A1(new_n149_), .A2(new_n163_), .B(new_n132_), .Y(G429));
  INVx1_ASAP7_75t_R   g121(.A(new_n149_), .Y(G430));
  INVx1_ASAP7_75t_R   g122(.A(new_n156_), .Y(new_n166_));
  NAND2x1_ASAP7_75t_R g123(.A(new_n140_), .B(new_n145_), .Y(new_n167_));
  OA21x2_ASAP7_75t_R  g124(.A1(new_n139_), .A2(new_n158_), .B(new_n159_), .Y(new_n168_));
  OAI21x1_ASAP7_75t_R g125(.A1(new_n133_), .A2(new_n135_), .B(new_n168_), .Y(new_n169_));
  OAI21x1_ASAP7_75t_R g126(.A1(new_n169_), .A2(new_n167_), .B(new_n148_), .Y(new_n170_));
  AO21x1_ASAP7_75t_R  g127(.A1(new_n141_), .A2(new_n166_), .B(new_n170_), .Y(G431));
  OR3x1_ASAP7_75t_R   g128(.A(new_n166_), .B(new_n112_), .C(new_n161_), .Y(new_n172_));
  OA21x2_ASAP7_75t_R  g129(.A1(new_n139_), .A2(new_n143_), .B(new_n144_), .Y(new_n173_));
  AO21x1_ASAP7_75t_R  g130(.A1(G428), .A2(G9), .B(new_n142_), .Y(new_n174_));
  OA21x2_ASAP7_75t_R  g131(.A1(new_n173_), .A2(new_n140_), .B(new_n174_), .Y(new_n175_));
  OA21x2_ASAP7_75t_R  g132(.A1(new_n167_), .A2(new_n169_), .B(new_n175_), .Y(new_n176_));
  OAI21x1_ASAP7_75t_R g133(.A1(new_n167_), .A2(new_n172_), .B(new_n176_), .Y(G432));
endmodule


