// Benchmark "/home/flynn/workplace/MIGBalance/results_v2/fixed_all_area_20261012/c1355.resyn2" written by ABC on Mon Oct 12 14:59:22 2026

module \/home/flynn/workplace/MIGBalance/results_v2/fixed_all_area_20261012/c1355.resyn2  ( 
    G1, G5, G9, G13, G33, G41, G17, G18, G19, G20, G21, G22, G23, G24, G4,
    G8, G12, G16, G36, G29, G30, G31, G32, G3, G7, G11, G15, G35, G25, G26,
    G27, G28, G2, G6, G10, G14, G34, G40, G39, G38, G37,
    G1324, G1344, G1325, G1326, G1327, G1328, G1329, G1330, G1343, G1331,
    G1332, G1333, G1334, G1335, G1336, G1337, G1338, G1339, G1340, G1341,
    G1342, G1345, G1346, G1347, G1348, G1349, G1350, G1351, G1352, G1353,
    G1354, G1355  );
  input  G1, G5, G9, G13, G33, G41, G17, G18, G19, G20, G21, G22, G23,
    G24, G4, G8, G12, G16, G36, G29, G30, G31, G32, G3, G7, G11, G15, G35,
    G25, G26, G27, G28, G2, G6, G10, G14, G34, G40, G39, G38, G37;
  output G1324, G1344, G1325, G1326, G1327, G1328, G1329, G1330, G1343, G1331,
    G1332, G1333, G1334, G1335, G1336, G1337, G1338, G1339, G1340, G1341,
    G1342, G1345, G1346, G1347, G1348, G1349, G1350, G1351, G1352, G1353,
    G1354, G1355;
  wire new_n74_, new_n75_, new_n76_, new_n77_, new_n78_, new_n79_, new_n80_,
    new_n81_, new_n82_, new_n83_, new_n84_, new_n85_, new_n86_, new_n87_,
    new_n88_, new_n89_, new_n90_, new_n91_, new_n92_, new_n93_, new_n94_,
    new_n95_, new_n96_, new_n97_, new_n98_, new_n99_, new_n100_, new_n101_,
    new_n102_, new_n103_, new_n104_, new_n105_, new_n106_, new_n107_,
    new_n108_, new_n109_, new_n110_, new_n111_, new_n112_, new_n113_,
    new_n114_, new_n115_, new_n116_, new_n117_, new_n118_, new_n119_,
    new_n120_, new_n121_, new_n122_, new_n123_, new_n124_, new_n125_,
    new_n126_, new_n127_, new_n128_, new_n129_, new_n130_, new_n131_,
    new_n132_, new_n133_, new_n134_, new_n135_, new_n136_, new_n137_,
    new_n138_, new_n139_, new_n140_, new_n141_, new_n142_, new_n143_,
    new_n144_, new_n145_, new_n146_, new_n147_, new_n148_, new_n149_,
    new_n150_, new_n151_, new_n152_, new_n153_, new_n154_, new_n155_,
    new_n156_, new_n157_, new_n158_, new_n159_, new_n160_, new_n161_,
    new_n162_, new_n163_, new_n164_, new_n165_, new_n166_, new_n167_,
    new_n168_, new_n170_, new_n171_, new_n172_, new_n173_, new_n174_,
    new_n175_, new_n176_, new_n177_, new_n178_, new_n179_, new_n181_,
    new_n183_, new_n184_, new_n186_, new_n188_, new_n189_, new_n190_,
    new_n192_, new_n194_, new_n196_, new_n197_, new_n198_, new_n200_,
    new_n202_, new_n203_, new_n205_, new_n207_, new_n209_, new_n211_,
    new_n212_, new_n214_, new_n216_, new_n218_, new_n220_, new_n222_,
    new_n224_, new_n226_, new_n228_, new_n230_, new_n232_, new_n233_,
    new_n235_, new_n237_, new_n239_, new_n241_, new_n242_, new_n244_,
    new_n246_, new_n248_;
  XOR2x2_ASAP7_75t_R  g000(.A(G19), .B(G20), .Y(new_n74_));
  XOR2x2_ASAP7_75t_R  g001(.A(G17), .B(G18), .Y(new_n75_));
  XOR2x2_ASAP7_75t_R  g002(.A(new_n74_), .B(new_n75_), .Y(new_n76_));
  AND2x2_ASAP7_75t_R  g003(.A(G33), .B(G41), .Y(new_n77_));
  XOR2x2_ASAP7_75t_R  g004(.A(new_n76_), .B(new_n77_), .Y(new_n78_));
  XOR2x2_ASAP7_75t_R  g005(.A(G23), .B(G24), .Y(new_n79_));
  XNOR2x2_ASAP7_75t_R g006(.A(G21), .B(G22), .Y(new_n80_));
  XOR2x2_ASAP7_75t_R  g007(.A(new_n80_), .B(new_n79_), .Y(new_n81_));
  XOR2x2_ASAP7_75t_R  g008(.A(G9), .B(G13), .Y(new_n82_));
  XOR2x2_ASAP7_75t_R  g009(.A(G1), .B(G5), .Y(new_n83_));
  XNOR2x2_ASAP7_75t_R g010(.A(new_n82_), .B(new_n83_), .Y(new_n84_));
  XOR2x2_ASAP7_75t_R  g011(.A(new_n84_), .B(new_n81_), .Y(new_n85_));
  XNOR2x2_ASAP7_75t_R g012(.A(new_n78_), .B(new_n85_), .Y(new_n86_));
  INVx1_ASAP7_75t_R   g013(.A(new_n86_), .Y(new_n87_));
  NAND2x1_ASAP7_75t_R g014(.A(G41), .B(G36), .Y(new_n88_));
  XOR2x2_ASAP7_75t_R  g015(.A(new_n81_), .B(new_n88_), .Y(new_n89_));
  XOR2x2_ASAP7_75t_R  g016(.A(G31), .B(G32), .Y(new_n90_));
  XNOR2x2_ASAP7_75t_R g017(.A(G29), .B(G30), .Y(new_n91_));
  XOR2x2_ASAP7_75t_R  g018(.A(new_n91_), .B(new_n90_), .Y(new_n92_));
  XOR2x2_ASAP7_75t_R  g019(.A(G12), .B(G16), .Y(new_n93_));
  XOR2x2_ASAP7_75t_R  g020(.A(G4), .B(G8), .Y(new_n94_));
  XNOR2x2_ASAP7_75t_R g021(.A(new_n93_), .B(new_n94_), .Y(new_n95_));
  XOR2x2_ASAP7_75t_R  g022(.A(new_n95_), .B(new_n92_), .Y(new_n96_));
  XNOR2x2_ASAP7_75t_R g023(.A(new_n89_), .B(new_n96_), .Y(new_n97_));
  AND2x2_ASAP7_75t_R  g024(.A(G41), .B(G35), .Y(new_n98_));
  XOR2x2_ASAP7_75t_R  g025(.A(new_n76_), .B(new_n98_), .Y(new_n99_));
  XOR2x2_ASAP7_75t_R  g026(.A(G27), .B(G28), .Y(new_n100_));
  XNOR2x2_ASAP7_75t_R g027(.A(G25), .B(G26), .Y(new_n101_));
  XOR2x2_ASAP7_75t_R  g028(.A(new_n101_), .B(new_n100_), .Y(new_n102_));
  XOR2x2_ASAP7_75t_R  g029(.A(G11), .B(G15), .Y(new_n103_));
  XOR2x2_ASAP7_75t_R  g030(.A(G3), .B(G7), .Y(new_n104_));
  XNOR2x2_ASAP7_75t_R g031(.A(new_n103_), .B(new_n104_), .Y(new_n105_));
  XOR2x2_ASAP7_75t_R  g032(.A(new_n105_), .B(new_n102_), .Y(new_n106_));
  XNOR2x2_ASAP7_75t_R g033(.A(new_n99_), .B(new_n106_), .Y(new_n107_));
  XOR2x2_ASAP7_75t_R  g034(.A(new_n97_), .B(new_n107_), .Y(new_n108_));
  NAND2x1_ASAP7_75t_R g035(.A(G41), .B(G34), .Y(new_n109_));
  XOR2x2_ASAP7_75t_R  g036(.A(new_n92_), .B(new_n109_), .Y(new_n110_));
  XOR2x2_ASAP7_75t_R  g037(.A(G10), .B(G14), .Y(new_n111_));
  XOR2x2_ASAP7_75t_R  g038(.A(G2), .B(G6), .Y(new_n112_));
  XNOR2x2_ASAP7_75t_R g039(.A(new_n111_), .B(new_n112_), .Y(new_n113_));
  XOR2x2_ASAP7_75t_R  g040(.A(new_n113_), .B(new_n102_), .Y(new_n114_));
  XNOR2x2_ASAP7_75t_R g041(.A(new_n110_), .B(new_n114_), .Y(new_n115_));
  AND2x2_ASAP7_75t_R  g042(.A(new_n87_), .B(new_n115_), .Y(new_n116_));
  INVx1_ASAP7_75t_R   g043(.A(new_n115_), .Y(new_n117_));
  AND2x2_ASAP7_75t_R  g044(.A(new_n117_), .B(new_n86_), .Y(new_n118_));
  OR3x1_ASAP7_75t_R   g045(.A(new_n116_), .B(new_n118_), .C(new_n108_), .Y(new_n119_));
  AND2x2_ASAP7_75t_R  g046(.A(new_n97_), .B(new_n107_), .Y(new_n120_));
  AO21x1_ASAP7_75t_R  g047(.A1(new_n86_), .A2(new_n115_), .B(new_n120_), .Y(new_n121_));
  AND2x2_ASAP7_75t_R  g048(.A(G41), .B(G40), .Y(new_n122_));
  XOR2x2_ASAP7_75t_R  g049(.A(G8), .B(G7), .Y(new_n123_));
  XOR2x2_ASAP7_75t_R  g050(.A(G5), .B(G6), .Y(new_n124_));
  XOR2x2_ASAP7_75t_R  g051(.A(new_n123_), .B(new_n124_), .Y(new_n125_));
  XOR2x2_ASAP7_75t_R  g052(.A(new_n125_), .B(new_n122_), .Y(new_n126_));
  XNOR2x2_ASAP7_75t_R g053(.A(G32), .B(G28), .Y(new_n127_));
  XOR2x2_ASAP7_75t_R  g054(.A(G20), .B(G24), .Y(new_n128_));
  XOR2x2_ASAP7_75t_R  g055(.A(new_n127_), .B(new_n128_), .Y(new_n129_));
  XOR2x2_ASAP7_75t_R  g056(.A(G16), .B(G15), .Y(new_n130_));
  XOR2x2_ASAP7_75t_R  g057(.A(G13), .B(G14), .Y(new_n131_));
  XOR2x2_ASAP7_75t_R  g058(.A(new_n130_), .B(new_n131_), .Y(new_n132_));
  XOR2x2_ASAP7_75t_R  g059(.A(new_n129_), .B(new_n132_), .Y(new_n133_));
  XNOR2x2_ASAP7_75t_R g060(.A(new_n126_), .B(new_n133_), .Y(new_n134_));
  INVx1_ASAP7_75t_R   g061(.A(new_n134_), .Y(new_n135_));
  AND3x1_ASAP7_75t_R  g062(.A(new_n119_), .B(new_n121_), .C(new_n135_), .Y(new_n136_));
  AND2x2_ASAP7_75t_R  g063(.A(G41), .B(G38), .Y(new_n137_));
  XOR2x2_ASAP7_75t_R  g064(.A(new_n132_), .B(new_n137_), .Y(new_n138_));
  XOR2x2_ASAP7_75t_R  g065(.A(G12), .B(G11), .Y(new_n139_));
  XNOR2x2_ASAP7_75t_R g066(.A(G9), .B(G10), .Y(new_n140_));
  XOR2x2_ASAP7_75t_R  g067(.A(new_n140_), .B(new_n139_), .Y(new_n141_));
  XOR2x2_ASAP7_75t_R  g068(.A(G30), .B(G26), .Y(new_n142_));
  XOR2x2_ASAP7_75t_R  g069(.A(G18), .B(G22), .Y(new_n143_));
  XNOR2x2_ASAP7_75t_R g070(.A(new_n142_), .B(new_n143_), .Y(new_n144_));
  XOR2x2_ASAP7_75t_R  g071(.A(new_n144_), .B(new_n141_), .Y(new_n145_));
  XNOR2x2_ASAP7_75t_R g072(.A(new_n138_), .B(new_n145_), .Y(new_n146_));
  AND2x2_ASAP7_75t_R  g073(.A(G41), .B(G37), .Y(new_n147_));
  XOR2x2_ASAP7_75t_R  g074(.A(new_n125_), .B(new_n147_), .Y(new_n148_));
  XOR2x2_ASAP7_75t_R  g075(.A(G4), .B(G3), .Y(new_n149_));
  XNOR2x2_ASAP7_75t_R g076(.A(G1), .B(G2), .Y(new_n150_));
  XOR2x2_ASAP7_75t_R  g077(.A(new_n150_), .B(new_n149_), .Y(new_n151_));
  XOR2x2_ASAP7_75t_R  g078(.A(G29), .B(G25), .Y(new_n152_));
  XOR2x2_ASAP7_75t_R  g079(.A(G17), .B(G21), .Y(new_n153_));
  XNOR2x2_ASAP7_75t_R g080(.A(new_n152_), .B(new_n153_), .Y(new_n154_));
  XOR2x2_ASAP7_75t_R  g081(.A(new_n154_), .B(new_n151_), .Y(new_n155_));
  XNOR2x2_ASAP7_75t_R g082(.A(new_n148_), .B(new_n155_), .Y(new_n156_));
  INVx1_ASAP7_75t_R   g083(.A(new_n156_), .Y(new_n157_));
  AND2x2_ASAP7_75t_R  g084(.A(new_n157_), .B(new_n146_), .Y(new_n158_));
  NAND2x1_ASAP7_75t_R g085(.A(G41), .B(G39), .Y(new_n159_));
  XOR2x2_ASAP7_75t_R  g086(.A(new_n151_), .B(new_n159_), .Y(new_n160_));
  XOR2x2_ASAP7_75t_R  g087(.A(G31), .B(G27), .Y(new_n161_));
  XOR2x2_ASAP7_75t_R  g088(.A(G19), .B(G23), .Y(new_n162_));
  XNOR2x2_ASAP7_75t_R g089(.A(new_n161_), .B(new_n162_), .Y(new_n163_));
  XOR2x2_ASAP7_75t_R  g090(.A(new_n163_), .B(new_n141_), .Y(new_n164_));
  XNOR2x2_ASAP7_75t_R g091(.A(new_n160_), .B(new_n164_), .Y(new_n165_));
  INVx1_ASAP7_75t_R   g092(.A(new_n165_), .Y(new_n166_));
  AND3x1_ASAP7_75t_R  g093(.A(new_n136_), .B(new_n158_), .C(new_n166_), .Y(new_n167_));
  NAND2x1_ASAP7_75t_R g094(.A(new_n87_), .B(new_n167_), .Y(new_n168_));
  XOR2x2_ASAP7_75t_R  g095(.A(new_n168_), .B(G1), .Y(G1324));
  INVx1_ASAP7_75t_R   g096(.A(new_n97_), .Y(new_n170_));
  XNOR2x2_ASAP7_75t_R g097(.A(new_n134_), .B(new_n165_), .Y(new_n171_));
  INVx1_ASAP7_75t_R   g098(.A(new_n146_), .Y(new_n172_));
  AND2x2_ASAP7_75t_R  g099(.A(new_n172_), .B(new_n156_), .Y(new_n173_));
  OR3x1_ASAP7_75t_R   g100(.A(new_n158_), .B(new_n173_), .C(new_n171_), .Y(new_n174_));
  AND2x2_ASAP7_75t_R  g101(.A(new_n146_), .B(new_n156_), .Y(new_n175_));
  AO21x1_ASAP7_75t_R  g102(.A1(new_n135_), .A2(new_n165_), .B(new_n175_), .Y(new_n176_));
  AND3x1_ASAP7_75t_R  g103(.A(new_n174_), .B(new_n170_), .C(new_n176_), .Y(new_n177_));
  AND3x1_ASAP7_75t_R  g104(.A(new_n177_), .B(new_n107_), .C(new_n116_), .Y(new_n178_));
  NAND2x1_ASAP7_75t_R g105(.A(new_n157_), .B(new_n178_), .Y(new_n179_));
  XOR2x2_ASAP7_75t_R  g106(.A(new_n179_), .B(G21), .Y(G1344));
  NAND2x1_ASAP7_75t_R g107(.A(new_n117_), .B(new_n167_), .Y(new_n181_));
  XOR2x2_ASAP7_75t_R  g108(.A(new_n181_), .B(G2), .Y(G1325));
  INVx1_ASAP7_75t_R   g109(.A(new_n107_), .Y(new_n183_));
  NAND2x1_ASAP7_75t_R g110(.A(new_n183_), .B(new_n167_), .Y(new_n184_));
  XOR2x2_ASAP7_75t_R  g111(.A(new_n184_), .B(G3), .Y(G1326));
  NAND2x1_ASAP7_75t_R g112(.A(new_n170_), .B(new_n167_), .Y(new_n186_));
  XOR2x2_ASAP7_75t_R  g113(.A(new_n186_), .B(G4), .Y(G1327));
  AND3x1_ASAP7_75t_R  g114(.A(new_n119_), .B(new_n121_), .C(new_n134_), .Y(new_n188_));
  AND3x1_ASAP7_75t_R  g115(.A(new_n188_), .B(new_n158_), .C(new_n165_), .Y(new_n189_));
  NAND2x1_ASAP7_75t_R g116(.A(new_n87_), .B(new_n189_), .Y(new_n190_));
  XOR2x2_ASAP7_75t_R  g117(.A(new_n190_), .B(G5), .Y(G1328));
  NAND2x1_ASAP7_75t_R g118(.A(new_n117_), .B(new_n189_), .Y(new_n192_));
  XOR2x2_ASAP7_75t_R  g119(.A(new_n192_), .B(G6), .Y(G1329));
  NAND2x1_ASAP7_75t_R g120(.A(new_n183_), .B(new_n189_), .Y(new_n194_));
  XOR2x2_ASAP7_75t_R  g121(.A(new_n194_), .B(G7), .Y(G1330));
  AND3x1_ASAP7_75t_R  g122(.A(new_n174_), .B(new_n97_), .C(new_n176_), .Y(new_n196_));
  AND3x1_ASAP7_75t_R  g123(.A(new_n196_), .B(new_n183_), .C(new_n116_), .Y(new_n197_));
  NAND2x1_ASAP7_75t_R g124(.A(new_n134_), .B(new_n197_), .Y(new_n198_));
  XOR2x2_ASAP7_75t_R  g125(.A(new_n198_), .B(G20), .Y(G1343));
  NAND2x1_ASAP7_75t_R g126(.A(new_n170_), .B(new_n189_), .Y(new_n200_));
  XOR2x2_ASAP7_75t_R  g127(.A(new_n200_), .B(G8), .Y(G1331));
  AND3x1_ASAP7_75t_R  g128(.A(new_n136_), .B(new_n166_), .C(new_n173_), .Y(new_n202_));
  NAND2x1_ASAP7_75t_R g129(.A(new_n87_), .B(new_n202_), .Y(new_n203_));
  XOR2x2_ASAP7_75t_R  g130(.A(new_n203_), .B(G9), .Y(G1332));
  NAND2x1_ASAP7_75t_R g131(.A(new_n117_), .B(new_n202_), .Y(new_n205_));
  XOR2x2_ASAP7_75t_R  g132(.A(new_n205_), .B(G10), .Y(G1333));
  NAND2x1_ASAP7_75t_R g133(.A(new_n183_), .B(new_n202_), .Y(new_n207_));
  XOR2x2_ASAP7_75t_R  g134(.A(new_n207_), .B(G11), .Y(G1334));
  NAND2x1_ASAP7_75t_R g135(.A(new_n170_), .B(new_n202_), .Y(new_n209_));
  XOR2x2_ASAP7_75t_R  g136(.A(new_n209_), .B(G12), .Y(G1335));
  AND3x1_ASAP7_75t_R  g137(.A(new_n188_), .B(new_n165_), .C(new_n173_), .Y(new_n211_));
  NAND2x1_ASAP7_75t_R g138(.A(new_n87_), .B(new_n211_), .Y(new_n212_));
  XOR2x2_ASAP7_75t_R  g139(.A(new_n212_), .B(G13), .Y(G1336));
  NAND2x1_ASAP7_75t_R g140(.A(new_n117_), .B(new_n211_), .Y(new_n214_));
  XOR2x2_ASAP7_75t_R  g141(.A(new_n214_), .B(G14), .Y(G1337));
  NAND2x1_ASAP7_75t_R g142(.A(new_n183_), .B(new_n211_), .Y(new_n216_));
  XOR2x2_ASAP7_75t_R  g143(.A(new_n216_), .B(G15), .Y(G1338));
  NAND2x1_ASAP7_75t_R g144(.A(new_n170_), .B(new_n211_), .Y(new_n218_));
  XOR2x2_ASAP7_75t_R  g145(.A(new_n218_), .B(G16), .Y(G1339));
  NAND2x1_ASAP7_75t_R g146(.A(new_n157_), .B(new_n197_), .Y(new_n220_));
  XOR2x2_ASAP7_75t_R  g147(.A(new_n220_), .B(G17), .Y(G1340));
  NAND2x1_ASAP7_75t_R g148(.A(new_n172_), .B(new_n197_), .Y(new_n222_));
  XOR2x2_ASAP7_75t_R  g149(.A(new_n222_), .B(G18), .Y(G1341));
  NAND2x1_ASAP7_75t_R g150(.A(new_n166_), .B(new_n197_), .Y(new_n224_));
  XOR2x2_ASAP7_75t_R  g151(.A(new_n224_), .B(G19), .Y(G1342));
  NAND2x1_ASAP7_75t_R g152(.A(new_n172_), .B(new_n178_), .Y(new_n226_));
  XOR2x2_ASAP7_75t_R  g153(.A(new_n226_), .B(G22), .Y(G1345));
  NAND2x1_ASAP7_75t_R g154(.A(new_n166_), .B(new_n178_), .Y(new_n228_));
  XOR2x2_ASAP7_75t_R  g155(.A(new_n228_), .B(G23), .Y(G1346));
  NAND2x1_ASAP7_75t_R g156(.A(new_n134_), .B(new_n178_), .Y(new_n230_));
  XOR2x2_ASAP7_75t_R  g157(.A(new_n230_), .B(G24), .Y(G1347));
  AND3x1_ASAP7_75t_R  g158(.A(new_n196_), .B(new_n183_), .C(new_n118_), .Y(new_n232_));
  NAND2x1_ASAP7_75t_R g159(.A(new_n157_), .B(new_n232_), .Y(new_n233_));
  XOR2x2_ASAP7_75t_R  g160(.A(new_n233_), .B(G25), .Y(G1348));
  NAND2x1_ASAP7_75t_R g161(.A(new_n172_), .B(new_n232_), .Y(new_n235_));
  XOR2x2_ASAP7_75t_R  g162(.A(new_n235_), .B(G26), .Y(G1349));
  NAND2x1_ASAP7_75t_R g163(.A(new_n166_), .B(new_n232_), .Y(new_n237_));
  XOR2x2_ASAP7_75t_R  g164(.A(new_n237_), .B(G27), .Y(G1350));
  NAND2x1_ASAP7_75t_R g165(.A(new_n134_), .B(new_n232_), .Y(new_n239_));
  XOR2x2_ASAP7_75t_R  g166(.A(new_n239_), .B(G28), .Y(G1351));
  AND3x1_ASAP7_75t_R  g167(.A(new_n177_), .B(new_n107_), .C(new_n118_), .Y(new_n241_));
  NAND2x1_ASAP7_75t_R g168(.A(new_n157_), .B(new_n241_), .Y(new_n242_));
  XOR2x2_ASAP7_75t_R  g169(.A(new_n242_), .B(G29), .Y(G1352));
  NAND2x1_ASAP7_75t_R g170(.A(new_n172_), .B(new_n241_), .Y(new_n244_));
  XOR2x2_ASAP7_75t_R  g171(.A(new_n244_), .B(G30), .Y(G1353));
  NAND2x1_ASAP7_75t_R g172(.A(new_n166_), .B(new_n241_), .Y(new_n246_));
  XOR2x2_ASAP7_75t_R  g173(.A(new_n246_), .B(G31), .Y(G1354));
  NAND2x1_ASAP7_75t_R g174(.A(new_n134_), .B(new_n241_), .Y(new_n248_));
  XOR2x2_ASAP7_75t_R  g175(.A(new_n248_), .B(G32), .Y(G1355));
endmodule


