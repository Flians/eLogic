// Benchmark "/home/flynn/workplace/MIGBalance/results_v2/fixed_all_area_20261012/c1908.resyn2" written by ABC on Mon Oct 12 14:59:30 2026

module \/home/flynn/workplace/MIGBalance/results_v2/fixed_all_area_20261012/c1908.resyn2  ( 
    G23, G24, G33, G31, G30, G32, G8, G6, G3, G15, G10, G12, G19, G28, G9,
    G14, G16, G18, G11, G5, G2, G27, G7, G4, G20, G13, G1, G17, G26, G22,
    G25, G21, G29,
    G1899, G1884, G1885, G1898, G1886, G1887, G1888, G1889, G1890, G1891,
    G1892, G1893, G1894, G1895, G1896, G1897, G1900, G1901, G1902, G1903,
    G1904, G1905, G1906, G1907, G1908  );
  input  G23, G24, G33, G31, G30, G32, G8, G6, G3, G15, G10, G12, G19,
    G28, G9, G14, G16, G18, G11, G5, G2, G27, G7, G4, G20, G13, G1, G17,
    G26, G22, G25, G21, G29;
  output G1899, G1884, G1885, G1898, G1886, G1887, G1888, G1889, G1890, G1891,
    G1892, G1893, G1894, G1895, G1896, G1897, G1900, G1901, G1902, G1903,
    G1904, G1905, G1906, G1907, G1908;
  wire new_n84_, new_n86_, new_n87_, new_n88_, new_n89_, new_n90_, new_n91_,
    new_n92_, new_n93_, new_n94_, new_n95_, new_n96_, new_n97_, new_n98_,
    new_n100_, new_n102_, new_n103_, new_n104_, new_n105_, new_n106_,
    new_n107_, new_n108_, new_n109_, new_n110_, new_n111_, new_n112_,
    new_n113_, new_n114_, new_n116_, new_n119_, new_n120_, new_n121_,
    new_n122_, new_n123_, new_n124_, new_n125_, new_n126_, new_n127_,
    new_n128_, new_n129_, new_n130_, new_n131_, new_n132_, new_n133_,
    new_n134_, new_n135_, new_n136_, new_n137_, new_n138_, new_n139_,
    new_n140_, new_n141_, new_n142_, new_n143_, new_n144_, new_n145_,
    new_n146_, new_n147_, new_n148_, new_n150_, new_n151_, new_n152_,
    new_n153_, new_n154_, new_n155_, new_n156_, new_n157_, new_n158_,
    new_n159_, new_n162_, new_n164_, new_n165_, new_n166_, new_n167_,
    new_n168_, new_n169_, new_n175_, new_n179_, new_n180_, new_n185_,
    new_n189_, new_n192_, new_n193_, new_n194_, new_n195_, new_n196_,
    new_n200_, new_n201_, new_n203_, new_n217_, new_n218_, new_n219_,
    new_n222_, new_n223_, new_n224_, new_n225_, new_n230_, new_n231_,
    new_n232_, new_n233_, new_n234_, new_n235_, new_n236_, new_n237_,
    new_n238_, new_n239_, new_n241_, new_n242_, new_n243_, new_n244_,
    new_n245_, new_n246_, new_n247_, new_n248_, new_n249_, new_n251_,
    new_n252_, new_n253_, new_n258_;
  NOR2x1_ASAP7_75t_R  g000(.A(G33), .B(G32), .Y(new_n84_));
  AO21x1_ASAP7_75t_R  g001(.A1(new_n230_), .A2(G24), .B(new_n243_), .Y(new_n86_));
  NOR2x1_ASAP7_75t_R  g002(.A(G33), .B(G30), .Y(new_n87_));
  AO21x1_ASAP7_75t_R  g003(.A1(new_n230_), .A2(G24), .B(G31), .Y(new_n88_));
  OR3x1_ASAP7_75t_R   g004(.A(G33), .B(G30), .C(new_n88_), .Y(new_n89_));
  XOR2x2_ASAP7_75t_R  g005(.A(G15), .B(G11), .Y(new_n90_));
  XNOR2x2_ASAP7_75t_R g006(.A(G8), .B(G5), .Y(new_n91_));
  XNOR2x2_ASAP7_75t_R g007(.A(G2), .B(new_n91_), .Y(new_n92_));
  OR3x1_ASAP7_75t_R   g008(.A(G24), .B(G33), .C(new_n236_), .Y(new_n93_));
  XOR2x2_ASAP7_75t_R  g009(.A(G9), .B(G14), .Y(new_n94_));
  XOR2x2_ASAP7_75t_R  g010(.A(G16), .B(new_n94_), .Y(new_n95_));
  XOR2x2_ASAP7_75t_R  g011(.A(new_n93_), .B(new_n95_), .Y(new_n96_));
  XNOR2x2_ASAP7_75t_R g012(.A(new_n92_), .B(new_n96_), .Y(new_n97_));
  XOR2x2_ASAP7_75t_R  g013(.A(new_n90_), .B(new_n97_), .Y(new_n98_));
  NOR2x1_ASAP7_75t_R  g014(.A(G31), .B(new_n244_), .Y(new_n100_));
  XNOR2x2_ASAP7_75t_R g015(.A(G15), .B(G10), .Y(new_n102_));
  OR3x1_ASAP7_75t_R   g016(.A(G23), .B(G33), .C(new_n235_), .Y(new_n103_));
  XNOR2x2_ASAP7_75t_R g017(.A(G8), .B(G6), .Y(new_n104_));
  XOR2x2_ASAP7_75t_R  g018(.A(G3), .B(G12), .Y(new_n105_));
  XOR2x2_ASAP7_75t_R  g019(.A(new_n104_), .B(new_n105_), .Y(new_n106_));
  XNOR2x2_ASAP7_75t_R g020(.A(new_n103_), .B(new_n106_), .Y(new_n107_));
  XOR2x2_ASAP7_75t_R  g021(.A(new_n102_), .B(new_n107_), .Y(new_n108_));
  NAND2x1_ASAP7_75t_R g022(.A(new_n233_), .B(new_n108_), .Y(new_n109_));
  XNOR2x2_ASAP7_75t_R g023(.A(G28), .B(new_n109_), .Y(new_n110_));
  AO21x1_ASAP7_75t_R  g024(.A1(G27), .A2(new_n245_), .B(new_n110_), .Y(new_n111_));
  AO21x1_ASAP7_75t_R  g025(.A1(new_n237_), .A2(new_n100_), .B(new_n111_), .Y(new_n112_));
  AO21x1_ASAP7_75t_R  g026(.A1(new_n86_), .A2(new_n89_), .B(new_n112_), .Y(new_n113_));
  AO21x1_ASAP7_75t_R  g027(.A1(new_n230_), .A2(new_n233_), .B(new_n238_), .Y(new_n114_));
  XOR2x2_ASAP7_75t_R  g028(.A(G12), .B(G13), .Y(new_n116_));
  XOR2x2_ASAP7_75t_R  g029(.A(G11), .B(new_n247_), .Y(new_n119_));
  XNOR2x2_ASAP7_75t_R g030(.A(new_n116_), .B(new_n119_), .Y(new_n120_));
  XOR2x2_ASAP7_75t_R  g031(.A(G14), .B(G4), .Y(new_n121_));
  XOR2x2_ASAP7_75t_R  g032(.A(G3), .B(G2), .Y(new_n122_));
  XOR2x2_ASAP7_75t_R  g033(.A(G1), .B(new_n122_), .Y(new_n123_));
  NOR2x1_ASAP7_75t_R  g034(.A(G33), .B(new_n241_), .Y(new_n124_));
  XOR2x2_ASAP7_75t_R  g035(.A(new_n123_), .B(new_n124_), .Y(new_n125_));
  XNOR2x2_ASAP7_75t_R g036(.A(new_n121_), .B(new_n125_), .Y(new_n126_));
  XNOR2x2_ASAP7_75t_R g037(.A(new_n120_), .B(new_n126_), .Y(new_n127_));
  NAND2x1_ASAP7_75t_R g038(.A(new_n233_), .B(new_n127_), .Y(new_n128_));
  XNOR2x2_ASAP7_75t_R g039(.A(G25), .B(new_n128_), .Y(new_n129_));
  OR3x1_ASAP7_75t_R   g040(.A(G24), .B(G33), .C(new_n239_), .Y(new_n130_));
  XOR2x2_ASAP7_75t_R  g041(.A(G6), .B(G7), .Y(new_n131_));
  XNOR2x2_ASAP7_75t_R g042(.A(G5), .B(new_n131_), .Y(new_n132_));
  XNOR2x2_ASAP7_75t_R g043(.A(G1), .B(new_n132_), .Y(new_n133_));
  XNOR2x2_ASAP7_75t_R g044(.A(new_n130_), .B(new_n133_), .Y(new_n134_));
  XOR2x2_ASAP7_75t_R  g045(.A(new_n120_), .B(new_n134_), .Y(new_n135_));
  NOR2x1_ASAP7_75t_R  g046(.A(G31), .B(new_n135_), .Y(new_n136_));
  XOR2x2_ASAP7_75t_R  g047(.A(G26), .B(new_n136_), .Y(new_n137_));
  XOR2x2_ASAP7_75t_R  g048(.A(G10), .B(G7), .Y(new_n138_));
  OR3x1_ASAP7_75t_R   g049(.A(G23), .B(G33), .C(new_n238_), .Y(new_n139_));
  XNOR2x2_ASAP7_75t_R g050(.A(G13), .B(new_n139_), .Y(new_n140_));
  XNOR2x2_ASAP7_75t_R g051(.A(G4), .B(new_n95_), .Y(new_n141_));
  XNOR2x2_ASAP7_75t_R g052(.A(new_n140_), .B(new_n141_), .Y(new_n142_));
  XNOR2x2_ASAP7_75t_R g053(.A(new_n138_), .B(new_n142_), .Y(new_n143_));
  NAND2x1_ASAP7_75t_R g054(.A(new_n233_), .B(new_n143_), .Y(new_n144_));
  AO21x1_ASAP7_75t_R  g055(.A1(new_n230_), .A2(new_n233_), .B(new_n235_), .Y(new_n145_));
  XOR2x2_ASAP7_75t_R  g056(.A(new_n144_), .B(new_n145_), .Y(new_n146_));
  OR2x4_ASAP7_75t_R   g057(.A(new_n137_), .B(new_n146_), .Y(new_n147_));
  AO21x1_ASAP7_75t_R  g058(.A1(new_n231_), .A2(new_n233_), .B(new_n236_), .Y(new_n148_));
  AO21x1_ASAP7_75t_R  g059(.A1(new_n231_), .A2(new_n233_), .B(new_n239_), .Y(new_n150_));
  XOR2x2_ASAP7_75t_R  g060(.A(G8), .B(G4), .Y(new_n151_));
  XNOR2x2_ASAP7_75t_R g061(.A(new_n123_), .B(new_n132_), .Y(new_n152_));
  XNOR2x2_ASAP7_75t_R g062(.A(new_n151_), .B(new_n152_), .Y(new_n153_));
  NOR2x1_ASAP7_75t_R  g063(.A(G33), .B(new_n242_), .Y(new_n154_));
  XNOR2x2_ASAP7_75t_R g064(.A(G9), .B(new_n154_), .Y(new_n155_));
  XOR2x2_ASAP7_75t_R  g065(.A(new_n247_), .B(new_n155_), .Y(new_n156_));
  XOR2x2_ASAP7_75t_R  g066(.A(new_n153_), .B(new_n156_), .Y(new_n157_));
  NAND2x1_ASAP7_75t_R g067(.A(new_n233_), .B(new_n157_), .Y(new_n158_));
  XOR2x2_ASAP7_75t_R  g068(.A(new_n150_), .B(new_n158_), .Y(new_n159_));
  NOR2x1_ASAP7_75t_R  g069(.A(new_n113_), .B(new_n249_), .Y(new_n162_));
  XNOR2x2_ASAP7_75t_R g070(.A(G14), .B(new_n162_), .Y(G1899));
  NOR2x1_ASAP7_75t_R  g071(.A(G33), .B(G29), .Y(new_n164_));
  OR3x1_ASAP7_75t_R   g072(.A(G33), .B(G29), .C(new_n88_), .Y(new_n165_));
  AO21x1_ASAP7_75t_R  g073(.A1(new_n86_), .A2(new_n165_), .B(new_n112_), .Y(new_n166_));
  AO21x1_ASAP7_75t_R  g074(.A1(new_n248_), .A2(new_n159_), .B(new_n147_), .Y(new_n167_));
  AO21x1_ASAP7_75t_R  g075(.A1(new_n246_), .A2(new_n129_), .B(new_n167_), .Y(new_n168_));
  NOR2x1_ASAP7_75t_R  g076(.A(new_n166_), .B(new_n168_), .Y(new_n169_));
  XNOR2x2_ASAP7_75t_R g077(.A(G1), .B(new_n169_), .Y(G1884));
  XNOR2x2_ASAP7_75t_R g078(.A(G2), .B(new_n169_), .Y(G1885));
  XNOR2x2_ASAP7_75t_R g079(.A(G13), .B(new_n162_), .Y(G1898));
  XNOR2x2_ASAP7_75t_R g080(.A(G3), .B(new_n169_), .Y(G1886));
  XNOR2x2_ASAP7_75t_R g081(.A(G4), .B(new_n169_), .Y(G1887));
  NOR2x1_ASAP7_75t_R  g082(.A(new_n113_), .B(new_n168_), .Y(new_n175_));
  XNOR2x2_ASAP7_75t_R g083(.A(G10), .B(new_n175_), .Y(G1888));
  XNOR2x2_ASAP7_75t_R g084(.A(G15), .B(new_n175_), .Y(G1889));
  XNOR2x2_ASAP7_75t_R g085(.A(G16), .B(new_n175_), .Y(G1890));
  OR3x1_ASAP7_75t_R   g086(.A(new_n114_), .B(new_n129_), .C(new_n167_), .Y(new_n179_));
  NOR2x1_ASAP7_75t_R  g087(.A(new_n166_), .B(new_n179_), .Y(new_n180_));
  XNOR2x2_ASAP7_75t_R g088(.A(G5), .B(new_n180_), .Y(G1891));
  XNOR2x2_ASAP7_75t_R g089(.A(G6), .B(new_n180_), .Y(G1892));
  XNOR2x2_ASAP7_75t_R g090(.A(G7), .B(new_n180_), .Y(G1893));
  XNOR2x2_ASAP7_75t_R g091(.A(G8), .B(new_n180_), .Y(G1894));
  NOR2x1_ASAP7_75t_R  g092(.A(new_n113_), .B(new_n179_), .Y(new_n185_));
  XNOR2x2_ASAP7_75t_R g093(.A(G9), .B(new_n185_), .Y(G1895));
  XNOR2x2_ASAP7_75t_R g094(.A(G11), .B(new_n162_), .Y(G1896));
  XNOR2x2_ASAP7_75t_R g095(.A(G12), .B(new_n162_), .Y(G1897));
  NOR2x1_ASAP7_75t_R  g096(.A(new_n169_), .B(new_n175_), .Y(new_n189_));
  AOI21x1_ASAP7_75t_R g097(.A1(new_n189_), .A2(new_n251_), .B(new_n234_), .Y(new_n192_));
  OR3x1_ASAP7_75t_R   g098(.A(new_n246_), .B(new_n248_), .C(new_n159_), .Y(new_n193_));
  OR3x1_ASAP7_75t_R   g099(.A(new_n137_), .B(new_n146_), .C(new_n112_), .Y(new_n194_));
  OR3x1_ASAP7_75t_R   g100(.A(new_n129_), .B(new_n193_), .C(new_n194_), .Y(new_n195_));
  INVx1_ASAP7_75t_R   g101(.A(new_n195_), .Y(new_n196_));
  OR3x1_ASAP7_75t_R   g102(.A(G33), .B(new_n196_), .C(new_n192_), .Y(G1900));
  NOR2x1_ASAP7_75t_R  g103(.A(new_n150_), .B(new_n189_), .Y(new_n200_));
  AOI21x1_ASAP7_75t_R g104(.A1(new_n157_), .A2(new_n200_), .B(new_n84_), .Y(new_n201_));
  OA21x2_ASAP7_75t_R  g105(.A1(new_n157_), .A2(new_n200_), .B(new_n201_), .Y(G1901));
  AO21x1_ASAP7_75t_R  g106(.A1(G25), .A2(new_n252_), .B(new_n127_), .Y(new_n203_));
  AND3x1_ASAP7_75t_R  g107(.A(new_n243_), .B(new_n253_), .C(new_n203_), .Y(G1902));
  NOR2x1_ASAP7_75t_R  g108(.A(new_n153_), .B(new_n164_), .Y(new_n217_));
  XOR2x2_ASAP7_75t_R  g109(.A(new_n169_), .B(new_n217_), .Y(new_n218_));
  AO21x1_ASAP7_75t_R  g110(.A1(new_n232_), .A2(new_n242_), .B(new_n164_), .Y(new_n219_));
  XOR2x2_ASAP7_75t_R  g111(.A(new_n218_), .B(new_n219_), .Y(G1906));
  AOI21x1_ASAP7_75t_R g112(.A1(new_n94_), .A2(new_n120_), .B(new_n87_), .Y(new_n222_));
  OA21x2_ASAP7_75t_R  g113(.A1(new_n94_), .A2(new_n120_), .B(new_n222_), .Y(new_n223_));
  XOR2x2_ASAP7_75t_R  g114(.A(new_n175_), .B(new_n223_), .Y(new_n224_));
  AO21x1_ASAP7_75t_R  g115(.A1(new_n232_), .A2(new_n241_), .B(new_n87_), .Y(new_n225_));
  XOR2x2_ASAP7_75t_R  g116(.A(new_n224_), .B(new_n225_), .Y(G1907));
  AND3x1_ASAP7_75t_R  g117(.A(new_n243_), .B(new_n189_), .C(new_n258_), .Y(G1908));
  INVx1_ASAP7_75t_R   g118(.A(G23), .Y(new_n230_));
  INVx1_ASAP7_75t_R   g119(.A(G24), .Y(new_n231_));
  INVx1_ASAP7_75t_R   g120(.A(G33), .Y(new_n232_));
  INVx1_ASAP7_75t_R   g121(.A(G31), .Y(new_n233_));
  INVx1_ASAP7_75t_R   g122(.A(G32), .Y(new_n234_));
  INVx1_ASAP7_75t_R   g123(.A(G19), .Y(new_n235_));
  INVx1_ASAP7_75t_R   g124(.A(G18), .Y(new_n236_));
  INVx1_ASAP7_75t_R   g125(.A(G27), .Y(new_n237_));
  INVx1_ASAP7_75t_R   g126(.A(G20), .Y(new_n238_));
  INVx1_ASAP7_75t_R   g127(.A(G17), .Y(new_n239_));
  INVx1_ASAP7_75t_R   g128(.A(G22), .Y(new_n241_));
  INVx1_ASAP7_75t_R   g129(.A(G21), .Y(new_n242_));
  INVx1_ASAP7_75t_R   g130(.A(new_n84_), .Y(new_n243_));
  INVx1_ASAP7_75t_R   g131(.A(new_n98_), .Y(new_n244_));
  INVx1_ASAP7_75t_R   g132(.A(new_n100_), .Y(new_n245_));
  INVx1_ASAP7_75t_R   g133(.A(new_n114_), .Y(new_n246_));
  XOR2x2_ASAP7_75t_R  g134(.A(G16), .B(new_n102_), .Y(new_n247_));
  INVx1_ASAP7_75t_R   g135(.A(new_n148_), .Y(new_n248_));
  OR2x4_ASAP7_75t_R   g136(.A(new_n148_), .B(new_n168_), .Y(new_n249_));
  assign              new_n251_ = 1'b1;
  INVx1_ASAP7_75t_R   g137(.A(new_n189_), .Y(new_n252_));
  OR2x4_ASAP7_75t_R   g138(.A(new_n129_), .B(new_n189_), .Y(new_n253_));
  AOI21x1_ASAP7_75t_R g139(.A1(new_n98_), .A2(new_n189_), .B(new_n84_), .Y(G1903));
  AOI21x1_ASAP7_75t_R g140(.A1(new_n108_), .A2(new_n189_), .B(new_n84_), .Y(G1904));
  AOI21x1_ASAP7_75t_R g141(.A1(new_n143_), .A2(new_n189_), .B(new_n84_), .Y(G1905));
  INVx1_ASAP7_75t_R   g142(.A(new_n135_), .Y(new_n258_));
endmodule


