// Benchmark "/home/flynn/workplace/MIGBalance/results_v2/fixed_all_area_20261012/c1908.resyn2" written by ABC on Mon Oct 12 14:59:29 2026

module \/home/flynn/workplace/MIGBalance/results_v2/fixed_all_area_20261012/c1908.resyn2  ( 
    G23, G24, G33, G31, G30, G32, G8, G6, G3, G15, G10, G12, G19, G28, G9,
    G14, G16, G18, G11, G5, G2, G27, G7, G4, G20, G13, G1, G17, G26, G22,
    G25, G21, G29,
    G1899, G1884, G1885, G1898, G1886, G1887, G1888, G1889, G1890, G1891,
    G1892, G1893, G1894, G1895, G1896, G1897, G1900, G1901, G1902, G1903,
    G1904, G1905, G1906, G1907, G1908  );
  input  G23, G24, G33, G31, G30, G32, G8, G6, G3, G15, G10, G12, G19,
    G28, G9, G14, G16, G18, G11, G5, G2, G27, G7, G4, G20, G13, G1, G17,
    G26, G22, G25, G21, G29;
  output G1899, G1884, G1885, G1898, G1886, G1887, G1888, G1889, G1890, G1891,
    G1892, G1893, G1894, G1895, G1896, G1897, G1900, G1901, G1902, G1903,
    G1904, G1905, G1906, G1907, G1908;
  wire new_n59_, new_n60_, new_n61_, new_n62_, new_n63_, new_n64_, new_n65_,
    new_n66_, new_n67_, new_n68_, new_n69_, new_n70_, new_n71_, new_n72_,
    new_n73_, new_n74_, new_n75_, new_n76_, new_n77_, new_n78_, new_n79_,
    new_n80_, new_n81_, new_n82_, new_n83_, new_n84_, new_n85_, new_n86_,
    new_n87_, new_n88_, new_n89_, new_n90_, new_n91_, new_n92_, new_n93_,
    new_n94_, new_n95_, new_n96_, new_n97_, new_n98_, new_n99_, new_n100_,
    new_n101_, new_n102_, new_n103_, new_n104_, new_n105_, new_n106_,
    new_n107_, new_n108_, new_n109_, new_n110_, new_n111_, new_n112_,
    new_n113_, new_n114_, new_n115_, new_n116_, new_n117_, new_n118_,
    new_n119_, new_n120_, new_n121_, new_n122_, new_n123_, new_n124_,
    new_n125_, new_n126_, new_n127_, new_n128_, new_n129_, new_n130_,
    new_n131_, new_n132_, new_n133_, new_n134_, new_n135_, new_n136_,
    new_n137_, new_n138_, new_n139_, new_n140_, new_n141_, new_n142_,
    new_n143_, new_n145_, new_n146_, new_n147_, new_n148_, new_n149_,
    new_n155_, new_n159_, new_n160_, new_n165_, new_n169_, new_n170_,
    new_n171_, new_n172_, new_n173_, new_n174_, new_n175_, new_n176_,
    new_n178_, new_n179_, new_n180_, new_n181_, new_n183_, new_n184_,
    new_n186_, new_n187_, new_n189_, new_n190_, new_n192_, new_n193_,
    new_n195_, new_n196_, new_n197_, new_n198_, new_n199_, new_n201_,
    new_n202_, new_n203_, new_n204_, new_n205_, new_n206_, new_n207_,
    new_n208_, new_n210_, new_n211_, new_n212_;
  INVx1_ASAP7_75t_R   g000(.A(G24), .Y(new_n59_));
  NOR2x1_ASAP7_75t_R  g001(.A(G33), .B(G32), .Y(new_n60_));
  OA21x2_ASAP7_75t_R  g002(.A1(G23), .A2(new_n59_), .B(new_n60_), .Y(new_n61_));
  INVx1_ASAP7_75t_R   g003(.A(new_n61_), .Y(new_n62_));
  INVx1_ASAP7_75t_R   g004(.A(G23), .Y(new_n63_));
  AO21x1_ASAP7_75t_R  g005(.A1(new_n63_), .A2(G24), .B(G31), .Y(new_n64_));
  OR3x1_ASAP7_75t_R   g006(.A(new_n64_), .B(G33), .C(G30), .Y(new_n65_));
  XOR2x2_ASAP7_75t_R  g007(.A(G15), .B(G11), .Y(new_n66_));
  XOR2x2_ASAP7_75t_R  g008(.A(G8), .B(G5), .Y(new_n67_));
  XOR2x2_ASAP7_75t_R  g009(.A(new_n67_), .B(G2), .Y(new_n68_));
  INVx1_ASAP7_75t_R   g010(.A(G18), .Y(new_n69_));
  OR3x1_ASAP7_75t_R   g011(.A(new_n69_), .B(G24), .C(G33), .Y(new_n70_));
  XOR2x2_ASAP7_75t_R  g012(.A(G9), .B(G14), .Y(new_n71_));
  XOR2x2_ASAP7_75t_R  g013(.A(new_n71_), .B(G16), .Y(new_n72_));
  XOR2x2_ASAP7_75t_R  g014(.A(new_n72_), .B(new_n70_), .Y(new_n73_));
  XOR2x2_ASAP7_75t_R  g015(.A(new_n73_), .B(new_n68_), .Y(new_n74_));
  XOR2x2_ASAP7_75t_R  g016(.A(new_n74_), .B(new_n66_), .Y(new_n75_));
  OR3x1_ASAP7_75t_R   g017(.A(new_n75_), .B(G31), .C(G27), .Y(new_n76_));
  OAI21x1_ASAP7_75t_R g018(.A1(G31), .A2(new_n75_), .B(G27), .Y(new_n77_));
  XOR2x2_ASAP7_75t_R  g019(.A(G15), .B(G10), .Y(new_n78_));
  INVx1_ASAP7_75t_R   g020(.A(G33), .Y(new_n79_));
  AND3x1_ASAP7_75t_R  g021(.A(new_n63_), .B(new_n79_), .C(G19), .Y(new_n80_));
  XNOR2x2_ASAP7_75t_R g022(.A(G8), .B(G6), .Y(new_n81_));
  XOR2x2_ASAP7_75t_R  g023(.A(G3), .B(G12), .Y(new_n82_));
  XOR2x2_ASAP7_75t_R  g024(.A(new_n81_), .B(new_n82_), .Y(new_n83_));
  XOR2x2_ASAP7_75t_R  g025(.A(new_n83_), .B(new_n80_), .Y(new_n84_));
  XOR2x2_ASAP7_75t_R  g026(.A(new_n84_), .B(new_n78_), .Y(new_n85_));
  OR3x1_ASAP7_75t_R   g027(.A(new_n85_), .B(G31), .C(G28), .Y(new_n86_));
  OAI21x1_ASAP7_75t_R g028(.A1(G31), .A2(new_n85_), .B(G28), .Y(new_n87_));
  AND3x1_ASAP7_75t_R  g029(.A(new_n77_), .B(new_n86_), .C(new_n87_), .Y(new_n88_));
  AND2x2_ASAP7_75t_R  g030(.A(new_n88_), .B(new_n76_), .Y(new_n89_));
  INVx1_ASAP7_75t_R   g031(.A(new_n89_), .Y(new_n90_));
  AOI21x1_ASAP7_75t_R g032(.A1(new_n62_), .A2(new_n65_), .B(new_n90_), .Y(new_n91_));
  OA21x2_ASAP7_75t_R  g033(.A1(G23), .A2(G31), .B(G20), .Y(new_n92_));
  INVx1_ASAP7_75t_R   g034(.A(new_n92_), .Y(new_n93_));
  INVx1_ASAP7_75t_R   g035(.A(G31), .Y(new_n94_));
  XOR2x2_ASAP7_75t_R  g036(.A(G12), .B(G13), .Y(new_n95_));
  XNOR2x2_ASAP7_75t_R g037(.A(G15), .B(G16), .Y(new_n96_));
  XOR2x2_ASAP7_75t_R  g038(.A(new_n96_), .B(G10), .Y(new_n97_));
  XOR2x2_ASAP7_75t_R  g039(.A(new_n97_), .B(G11), .Y(new_n98_));
  XOR2x2_ASAP7_75t_R  g040(.A(new_n98_), .B(new_n95_), .Y(new_n99_));
  XOR2x2_ASAP7_75t_R  g041(.A(G14), .B(G4), .Y(new_n100_));
  XNOR2x2_ASAP7_75t_R g042(.A(G3), .B(G2), .Y(new_n101_));
  XOR2x2_ASAP7_75t_R  g043(.A(new_n101_), .B(G1), .Y(new_n102_));
  AND2x2_ASAP7_75t_R  g044(.A(new_n79_), .B(G22), .Y(new_n103_));
  XOR2x2_ASAP7_75t_R  g045(.A(new_n102_), .B(new_n103_), .Y(new_n104_));
  XOR2x2_ASAP7_75t_R  g046(.A(new_n104_), .B(new_n100_), .Y(new_n105_));
  XOR2x2_ASAP7_75t_R  g047(.A(new_n105_), .B(new_n99_), .Y(new_n106_));
  NAND2x1_ASAP7_75t_R g048(.A(new_n94_), .B(new_n106_), .Y(new_n107_));
  XOR2x2_ASAP7_75t_R  g049(.A(new_n107_), .B(G25), .Y(new_n108_));
  OR2x4_ASAP7_75t_R   g050(.A(new_n93_), .B(new_n108_), .Y(new_n109_));
  INVx1_ASAP7_75t_R   g051(.A(G17), .Y(new_n110_));
  OR3x1_ASAP7_75t_R   g052(.A(new_n110_), .B(G24), .C(G33), .Y(new_n111_));
  XNOR2x2_ASAP7_75t_R g053(.A(G6), .B(G7), .Y(new_n112_));
  XOR2x2_ASAP7_75t_R  g054(.A(new_n112_), .B(G5), .Y(new_n113_));
  XOR2x2_ASAP7_75t_R  g055(.A(new_n113_), .B(G1), .Y(new_n114_));
  XOR2x2_ASAP7_75t_R  g056(.A(new_n114_), .B(new_n111_), .Y(new_n115_));
  XNOR2x2_ASAP7_75t_R g057(.A(new_n99_), .B(new_n115_), .Y(new_n116_));
  NOR2x1_ASAP7_75t_R  g058(.A(G31), .B(new_n116_), .Y(new_n117_));
  XNOR2x2_ASAP7_75t_R g059(.A(G26), .B(new_n117_), .Y(new_n118_));
  XNOR2x2_ASAP7_75t_R g060(.A(G10), .B(G7), .Y(new_n119_));
  AND3x1_ASAP7_75t_R  g061(.A(new_n63_), .B(new_n79_), .C(G20), .Y(new_n120_));
  XNOR2x2_ASAP7_75t_R g062(.A(G13), .B(new_n120_), .Y(new_n121_));
  XOR2x2_ASAP7_75t_R  g063(.A(new_n72_), .B(G4), .Y(new_n122_));
  XOR2x2_ASAP7_75t_R  g064(.A(new_n122_), .B(new_n121_), .Y(new_n123_));
  XOR2x2_ASAP7_75t_R  g065(.A(new_n123_), .B(new_n119_), .Y(new_n124_));
  NOR2x1_ASAP7_75t_R  g066(.A(G31), .B(new_n124_), .Y(new_n125_));
  OA21x2_ASAP7_75t_R  g067(.A1(G23), .A2(G31), .B(G19), .Y(new_n126_));
  XNOR2x2_ASAP7_75t_R g068(.A(new_n126_), .B(new_n125_), .Y(new_n127_));
  AND2x2_ASAP7_75t_R  g069(.A(new_n118_), .B(new_n127_), .Y(new_n128_));
  AO21x1_ASAP7_75t_R  g070(.A1(new_n59_), .A2(new_n94_), .B(new_n69_), .Y(new_n129_));
  INVx1_ASAP7_75t_R   g071(.A(new_n129_), .Y(new_n130_));
  AO21x1_ASAP7_75t_R  g072(.A1(new_n59_), .A2(new_n94_), .B(new_n110_), .Y(new_n131_));
  XNOR2x2_ASAP7_75t_R g073(.A(G8), .B(G4), .Y(new_n132_));
  XOR2x2_ASAP7_75t_R  g074(.A(new_n102_), .B(new_n113_), .Y(new_n133_));
  XOR2x2_ASAP7_75t_R  g075(.A(new_n133_), .B(new_n132_), .Y(new_n134_));
  NAND2x1_ASAP7_75t_R g076(.A(G21), .B(new_n79_), .Y(new_n135_));
  XOR2x2_ASAP7_75t_R  g077(.A(new_n135_), .B(G9), .Y(new_n136_));
  XOR2x2_ASAP7_75t_R  g078(.A(new_n136_), .B(new_n97_), .Y(new_n137_));
  XOR2x2_ASAP7_75t_R  g079(.A(new_n134_), .B(new_n137_), .Y(new_n138_));
  AND2x2_ASAP7_75t_R  g080(.A(new_n138_), .B(new_n94_), .Y(new_n139_));
  XOR2x2_ASAP7_75t_R  g081(.A(new_n139_), .B(new_n131_), .Y(new_n140_));
  AND2x2_ASAP7_75t_R  g082(.A(new_n140_), .B(new_n130_), .Y(new_n141_));
  AND3x1_ASAP7_75t_R  g083(.A(new_n109_), .B(new_n128_), .C(new_n141_), .Y(new_n142_));
  NAND2x1_ASAP7_75t_R g084(.A(new_n91_), .B(new_n142_), .Y(new_n143_));
  XOR2x2_ASAP7_75t_R  g085(.A(new_n143_), .B(G14), .Y(G1899));
  OR3x1_ASAP7_75t_R   g086(.A(new_n64_), .B(G33), .C(G29), .Y(new_n145_));
  AOI21x1_ASAP7_75t_R g087(.A1(new_n62_), .A2(new_n145_), .B(new_n90_), .Y(new_n146_));
  OA21x2_ASAP7_75t_R  g088(.A1(new_n129_), .A2(new_n140_), .B(new_n128_), .Y(new_n147_));
  AND2x2_ASAP7_75t_R  g089(.A(new_n147_), .B(new_n109_), .Y(new_n148_));
  NAND2x1_ASAP7_75t_R g090(.A(new_n146_), .B(new_n148_), .Y(new_n149_));
  XOR2x2_ASAP7_75t_R  g091(.A(new_n149_), .B(G1), .Y(G1884));
  XOR2x2_ASAP7_75t_R  g092(.A(new_n149_), .B(G2), .Y(G1885));
  XOR2x2_ASAP7_75t_R  g093(.A(new_n143_), .B(G13), .Y(G1898));
  XOR2x2_ASAP7_75t_R  g094(.A(new_n149_), .B(G3), .Y(G1886));
  XOR2x2_ASAP7_75t_R  g095(.A(new_n149_), .B(G4), .Y(G1887));
  NAND2x1_ASAP7_75t_R g096(.A(new_n91_), .B(new_n148_), .Y(new_n155_));
  XOR2x2_ASAP7_75t_R  g097(.A(new_n155_), .B(G10), .Y(G1888));
  XOR2x2_ASAP7_75t_R  g098(.A(new_n155_), .B(G15), .Y(G1889));
  XOR2x2_ASAP7_75t_R  g099(.A(new_n155_), .B(G16), .Y(G1890));
  AND3x1_ASAP7_75t_R  g100(.A(new_n147_), .B(new_n92_), .C(new_n108_), .Y(new_n159_));
  NAND2x1_ASAP7_75t_R g101(.A(new_n146_), .B(new_n159_), .Y(new_n160_));
  XOR2x2_ASAP7_75t_R  g102(.A(new_n160_), .B(G5), .Y(G1891));
  XOR2x2_ASAP7_75t_R  g103(.A(new_n160_), .B(G6), .Y(G1892));
  XOR2x2_ASAP7_75t_R  g104(.A(new_n160_), .B(G7), .Y(G1893));
  XOR2x2_ASAP7_75t_R  g105(.A(new_n160_), .B(G8), .Y(G1894));
  NAND2x1_ASAP7_75t_R g106(.A(new_n91_), .B(new_n159_), .Y(new_n165_));
  XOR2x2_ASAP7_75t_R  g107(.A(new_n165_), .B(G9), .Y(G1895));
  XOR2x2_ASAP7_75t_R  g108(.A(new_n143_), .B(G11), .Y(G1896));
  XOR2x2_ASAP7_75t_R  g109(.A(new_n143_), .B(G12), .Y(G1897));
  NAND2x1_ASAP7_75t_R g110(.A(new_n149_), .B(new_n155_), .Y(new_n169_));
  OR2x4_ASAP7_75t_R   g111(.A(new_n142_), .B(new_n159_), .Y(new_n170_));
  AND3x1_ASAP7_75t_R  g112(.A(new_n88_), .B(new_n61_), .C(new_n76_), .Y(new_n171_));
  AO21x1_ASAP7_75t_R  g113(.A1(new_n170_), .A2(new_n171_), .B(new_n169_), .Y(new_n172_));
  AND2x2_ASAP7_75t_R  g114(.A(new_n129_), .B(new_n93_), .Y(new_n173_));
  AND3x1_ASAP7_75t_R  g115(.A(new_n140_), .B(new_n108_), .C(new_n173_), .Y(new_n174_));
  AND3x1_ASAP7_75t_R  g116(.A(new_n89_), .B(new_n118_), .C(new_n127_), .Y(new_n175_));
  AO21x1_ASAP7_75t_R  g117(.A1(new_n175_), .A2(new_n174_), .B(G33), .Y(new_n176_));
  AO21x1_ASAP7_75t_R  g118(.A1(new_n172_), .A2(G32), .B(new_n176_), .Y(G1900));
  AND2x2_ASAP7_75t_R  g119(.A(new_n169_), .B(new_n94_), .Y(new_n178_));
  INVx1_ASAP7_75t_R   g120(.A(new_n178_), .Y(new_n179_));
  NOR2x1_ASAP7_75t_R  g121(.A(new_n131_), .B(new_n179_), .Y(new_n180_));
  AOI21x1_ASAP7_75t_R g122(.A1(new_n138_), .A2(new_n180_), .B(new_n60_), .Y(new_n181_));
  OA21x2_ASAP7_75t_R  g123(.A1(new_n138_), .A2(new_n180_), .B(new_n181_), .Y(G1901));
  AND3x1_ASAP7_75t_R  g124(.A(new_n169_), .B(new_n94_), .C(G25), .Y(new_n183_));
  AOI21x1_ASAP7_75t_R g125(.A1(new_n106_), .A2(new_n183_), .B(new_n60_), .Y(new_n184_));
  OA21x2_ASAP7_75t_R  g126(.A1(new_n106_), .A2(new_n183_), .B(new_n184_), .Y(G1902));
  AND3x1_ASAP7_75t_R  g127(.A(new_n169_), .B(new_n94_), .C(G27), .Y(new_n186_));
  AOI21x1_ASAP7_75t_R g128(.A1(new_n75_), .A2(new_n186_), .B(new_n60_), .Y(new_n187_));
  OA21x2_ASAP7_75t_R  g129(.A1(new_n75_), .A2(new_n186_), .B(new_n187_), .Y(G1903));
  AND3x1_ASAP7_75t_R  g130(.A(new_n169_), .B(new_n94_), .C(G28), .Y(new_n189_));
  AOI21x1_ASAP7_75t_R g131(.A1(new_n85_), .A2(new_n189_), .B(new_n60_), .Y(new_n190_));
  OA21x2_ASAP7_75t_R  g132(.A1(new_n85_), .A2(new_n189_), .B(new_n190_), .Y(G1904));
  AND3x1_ASAP7_75t_R  g133(.A(new_n169_), .B(new_n94_), .C(new_n126_), .Y(new_n192_));
  AOI21x1_ASAP7_75t_R g134(.A1(new_n124_), .A2(new_n192_), .B(new_n60_), .Y(new_n193_));
  OA21x2_ASAP7_75t_R  g135(.A1(new_n124_), .A2(new_n192_), .B(new_n193_), .Y(G1905));
  AND3x1_ASAP7_75t_R  g136(.A(new_n148_), .B(new_n79_), .C(new_n146_), .Y(new_n195_));
  INVx1_ASAP7_75t_R   g137(.A(G29), .Y(new_n196_));
  AO21x1_ASAP7_75t_R  g138(.A1(new_n79_), .A2(new_n196_), .B(new_n134_), .Y(new_n197_));
  XOR2x2_ASAP7_75t_R  g139(.A(new_n195_), .B(new_n197_), .Y(new_n198_));
  AO21x1_ASAP7_75t_R  g140(.A1(G21), .A2(G29), .B(G33), .Y(new_n199_));
  XOR2x2_ASAP7_75t_R  g141(.A(new_n198_), .B(new_n199_), .Y(G1906));
  AND3x1_ASAP7_75t_R  g142(.A(new_n148_), .B(new_n79_), .C(new_n91_), .Y(new_n201_));
  INVx1_ASAP7_75t_R   g143(.A(new_n71_), .Y(new_n202_));
  NOR2x1_ASAP7_75t_R  g144(.A(G33), .B(G30), .Y(new_n203_));
  INVx1_ASAP7_75t_R   g145(.A(new_n99_), .Y(new_n204_));
  AO21x1_ASAP7_75t_R  g146(.A1(new_n204_), .A2(new_n71_), .B(new_n203_), .Y(new_n205_));
  AO21x1_ASAP7_75t_R  g147(.A1(new_n202_), .A2(new_n99_), .B(new_n205_), .Y(new_n206_));
  XOR2x2_ASAP7_75t_R  g148(.A(new_n201_), .B(new_n206_), .Y(new_n207_));
  AO21x1_ASAP7_75t_R  g149(.A1(G30), .A2(G22), .B(G33), .Y(new_n208_));
  XOR2x2_ASAP7_75t_R  g150(.A(new_n207_), .B(new_n208_), .Y(G1907));
  NAND2x1_ASAP7_75t_R g151(.A(G26), .B(new_n178_), .Y(new_n210_));
  AND2x2_ASAP7_75t_R  g152(.A(new_n117_), .B(G26), .Y(new_n211_));
  AO21x1_ASAP7_75t_R  g153(.A1(new_n169_), .A2(new_n211_), .B(new_n60_), .Y(new_n212_));
  AOI21x1_ASAP7_75t_R g154(.A1(new_n116_), .A2(new_n210_), .B(new_n212_), .Y(G1908));
endmodule


