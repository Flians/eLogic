module mapped( G1 , G3 , G2 , G4 , G5 , G16 , G17 );
  input G1 , G3 , G2 , G4 , G5 ;
  output G16 , G17 ;
  wire n7 , n8 ;
  NAND2x1_ASAP7_75t_R g0( .A (G3), .B (G4), .Y (n8) );
  AND2x2_ASAP7_75t_R  g1( .A (G1), .B (G3), .Y (n7) );
  AO21x1_ASAP7_75t_R  g2( .A1 (n8), .A2 (G2), .B (n7), .Y (G16) );
  OA21x2_ASAP7_75t_R  g3( .A1 (G2), .A2 (G5), .B (n8), .Y (G17) );
endmodule
