// Benchmark "/home/flynn/workplace/MIGBalance/results_v2/fixed_all_area_20261012/c880.resyn2" written by ABC on Mon Oct 12 14:59:16 2026

module \/home/flynn/workplace/MIGBalance/results_v2/fixed_all_area_20261012/c880.resyn2  ( 
    G8, G16, G6, G17, G7, G18, G19, G4, G3, G2, G1, G5, G11, G23, G20, G21,
    G9, G10, G12, G15, G22, G32, G24, G25, G26, G27, G28, G29, G30, G31,
    G33, G41, G42, G43, G44, G45, G46, G47, G48, G49, G13, G14, G55, G59,
    G54, G60, G39, G40, G52, G53, G50, G51, G58, G35, G37, G36, G56, G57,
    G34, G38,
    G855, G856, G857, G858, G859, G860, G861, G862, G863, G864, G865, G866,
    G867, G868, G869, G870, G871, G872, G873, G874, G875, G876, G877, G878,
    G879, G880  );
  input  G8, G16, G6, G17, G7, G18, G19, G4, G3, G2, G1, G5, G11, G23,
    G20, G21, G9, G10, G12, G15, G22, G32, G24, G25, G26, G27, G28, G29,
    G30, G31, G33, G41, G42, G43, G44, G45, G46, G47, G48, G49, G13, G14,
    G55, G59, G54, G60, G39, G40, G52, G53, G50, G51, G58, G35, G37, G36,
    G56, G57, G34, G38;
  output G855, G856, G857, G858, G859, G860, G861, G862, G863, G864, G865,
    G866, G867, G868, G869, G870, G871, G872, G873, G874, G875, G876, G877,
    G878, G879, G880;
  wire new_n87_, new_n88_, new_n91_, new_n94_, new_n95_, new_n97_, new_n104_,
    new_n106_, new_n108_, new_n111_, new_n112_, new_n113_, new_n114_,
    new_n115_, new_n116_, new_n117_, new_n118_, new_n119_, new_n121_,
    new_n122_, new_n123_, new_n124_, new_n125_, new_n126_, new_n127_,
    new_n128_, new_n130_, new_n131_, new_n132_, new_n133_, new_n134_,
    new_n135_, new_n136_, new_n137_, new_n138_, new_n139_, new_n140_,
    new_n141_, new_n142_, new_n143_, new_n144_, new_n145_, new_n146_,
    new_n147_, new_n148_, new_n149_, new_n150_, new_n151_, new_n152_,
    new_n153_, new_n154_, new_n155_, new_n156_, new_n157_, new_n158_,
    new_n159_, new_n160_, new_n161_, new_n162_, new_n163_, new_n164_,
    new_n165_, new_n167_, new_n168_, new_n169_, new_n170_, new_n171_,
    new_n172_, new_n173_, new_n174_, new_n175_, new_n176_, new_n177_,
    new_n178_, new_n179_, new_n180_, new_n181_, new_n182_, new_n183_,
    new_n184_, new_n185_, new_n186_, new_n187_, new_n188_, new_n189_,
    new_n190_, new_n191_, new_n192_, new_n193_, new_n194_, new_n195_,
    new_n196_, new_n197_, new_n198_, new_n199_, new_n200_, new_n201_,
    new_n202_, new_n204_, new_n205_, new_n206_, new_n207_, new_n208_,
    new_n209_, new_n210_, new_n211_, new_n212_, new_n213_, new_n214_,
    new_n215_, new_n217_, new_n218_, new_n219_, new_n220_, new_n221_,
    new_n222_, new_n223_, new_n224_, new_n225_, new_n227_, new_n228_,
    new_n229_, new_n230_, new_n231_, new_n232_, new_n233_, new_n234_,
    new_n235_, new_n236_, new_n237_, new_n238_, new_n239_, new_n240_,
    new_n241_, new_n242_, new_n243_, new_n244_, new_n245_, new_n246_,
    new_n247_, new_n248_, new_n249_, new_n250_, new_n251_, new_n252_,
    new_n253_, new_n254_, new_n255_, new_n256_, new_n257_, new_n258_,
    new_n259_, new_n260_, new_n261_, new_n262_, new_n263_, new_n264_,
    new_n265_, new_n266_, new_n267_, new_n268_, new_n269_, new_n270_,
    new_n271_, new_n273_, new_n274_, new_n275_, new_n276_, new_n277_,
    new_n278_, new_n279_, new_n280_, new_n281_, new_n283_, new_n284_,
    new_n285_, new_n286_, new_n287_, new_n288_, new_n289_, new_n290_,
    new_n291_, new_n292_, new_n294_, new_n295_, new_n296_, new_n297_,
    new_n298_, new_n299_, new_n300_, new_n301_, new_n302_, new_n303_,
    new_n305_, new_n306_, new_n307_, new_n308_, new_n309_, new_n310_,
    new_n311_, new_n312_, new_n313_, new_n314_;
  INVx1_ASAP7_75t_R   g000(.A(G8), .Y(new_n87_));
  NAND2x1_ASAP7_75t_R g001(.A(G16), .B(G6), .Y(new_n88_));
  OR2x4_ASAP7_75t_R   g002(.A(new_n87_), .B(new_n88_), .Y(G855));
  NAND3x1_ASAP7_75t_R g003(.A(G6), .B(G7), .C(G17), .Y(G856));
  AND3x1_ASAP7_75t_R  g004(.A(G8), .B(G6), .C(G7), .Y(new_n91_));
  INVx1_ASAP7_75t_R   g005(.A(new_n91_), .Y(G857));
  NAND2x1_ASAP7_75t_R g006(.A(G18), .B(G19), .Y(G858));
  AND2x2_ASAP7_75t_R  g007(.A(G4), .B(G3), .Y(new_n94_));
  AND2x2_ASAP7_75t_R  g008(.A(G2), .B(G1), .Y(new_n95_));
  NAND2x1_ASAP7_75t_R g009(.A(new_n94_), .B(new_n95_), .Y(G859));
  AND2x2_ASAP7_75t_R  g010(.A(G1), .B(G5), .Y(new_n97_));
  AND3x1_ASAP7_75t_R  g011(.A(G857), .B(new_n94_), .C(new_n97_), .Y(G860));
  AND3x1_ASAP7_75t_R  g012(.A(G16), .B(G17), .C(G11), .Y(G861));
  AND3x1_ASAP7_75t_R  g013(.A(G17), .B(G7), .C(G11), .Y(G862));
  AND3x1_ASAP7_75t_R  g014(.A(G8), .B(G7), .C(G11), .Y(G863));
  OAI21x1_ASAP7_75t_R g015(.A1(G20), .A2(G21), .B(G23), .Y(G864));
  AND3x1_ASAP7_75t_R  g016(.A(new_n91_), .B(new_n94_), .C(new_n97_), .Y(G865));
  AND3x1_ASAP7_75t_R  g017(.A(G1), .B(G5), .C(G9), .Y(new_n104_));
  INVx1_ASAP7_75t_R   g018(.A(new_n104_), .Y(G866));
  AND3x1_ASAP7_75t_R  g019(.A(new_n95_), .B(G3), .C(G10), .Y(new_n106_));
  NAND3x1_ASAP7_75t_R g020(.A(new_n106_), .B(G12), .C(G6), .Y(G867));
  AND3x1_ASAP7_75t_R  g021(.A(new_n106_), .B(G11), .C(G12), .Y(new_n108_));
  NAND2x1_ASAP7_75t_R g022(.A(G15), .B(new_n108_), .Y(G868));
  OAI21x1_ASAP7_75t_R g023(.A1(G20), .A2(G21), .B(G22), .Y(G869));
  INVx1_ASAP7_75t_R   g024(.A(G32), .Y(new_n111_));
  XOR2x2_ASAP7_75t_R  g025(.A(G24), .B(G25), .Y(new_n112_));
  XOR2x2_ASAP7_75t_R  g026(.A(new_n112_), .B(new_n111_), .Y(new_n113_));
  XOR2x2_ASAP7_75t_R  g027(.A(G30), .B(G31), .Y(new_n114_));
  XOR2x2_ASAP7_75t_R  g028(.A(new_n113_), .B(new_n114_), .Y(new_n115_));
  XOR2x2_ASAP7_75t_R  g029(.A(G28), .B(G29), .Y(new_n116_));
  XOR2x2_ASAP7_75t_R  g030(.A(new_n116_), .B(G33), .Y(new_n117_));
  XOR2x2_ASAP7_75t_R  g031(.A(G26), .B(G27), .Y(new_n118_));
  XOR2x2_ASAP7_75t_R  g032(.A(new_n117_), .B(new_n118_), .Y(new_n119_));
  XOR2x2_ASAP7_75t_R  g033(.A(new_n115_), .B(new_n119_), .Y(G870));
  XOR2x2_ASAP7_75t_R  g034(.A(G41), .B(G42), .Y(new_n121_));
  XOR2x2_ASAP7_75t_R  g035(.A(new_n121_), .B(new_n111_), .Y(new_n122_));
  XOR2x2_ASAP7_75t_R  g036(.A(G47), .B(G48), .Y(new_n123_));
  XOR2x2_ASAP7_75t_R  g037(.A(new_n122_), .B(new_n123_), .Y(new_n124_));
  XOR2x2_ASAP7_75t_R  g038(.A(G45), .B(G46), .Y(new_n125_));
  XOR2x2_ASAP7_75t_R  g039(.A(new_n125_), .B(G49), .Y(new_n126_));
  XOR2x2_ASAP7_75t_R  g040(.A(G43), .B(G44), .Y(new_n127_));
  XOR2x2_ASAP7_75t_R  g041(.A(new_n126_), .B(new_n127_), .Y(new_n128_));
  XOR2x2_ASAP7_75t_R  g042(.A(new_n124_), .B(new_n128_), .Y(G871));
  INVx1_ASAP7_75t_R   g043(.A(G48), .Y(new_n130_));
  INVx1_ASAP7_75t_R   g044(.A(G39), .Y(new_n131_));
  INVx1_ASAP7_75t_R   g045(.A(G4), .Y(new_n132_));
  NAND2x1_ASAP7_75t_R g046(.A(G11), .B(G40), .Y(new_n133_));
  AND3x1_ASAP7_75t_R  g047(.A(new_n133_), .B(new_n97_), .C(G9), .Y(new_n134_));
  INVx1_ASAP7_75t_R   g048(.A(new_n134_), .Y(new_n135_));
  OA21x2_ASAP7_75t_R  g049(.A1(new_n135_), .A2(new_n132_), .B(G1), .Y(new_n136_));
  INVx1_ASAP7_75t_R   g050(.A(G31), .Y(new_n137_));
  AO21x1_ASAP7_75t_R  g051(.A1(G8), .A2(G4), .B(new_n133_), .Y(new_n138_));
  AO21x1_ASAP7_75t_R  g052(.A1(new_n87_), .A2(new_n132_), .B(new_n138_), .Y(new_n139_));
  NAND2x1_ASAP7_75t_R g053(.A(G16), .B(G11), .Y(new_n140_));
  AND3x1_ASAP7_75t_R  g054(.A(new_n95_), .B(G4), .C(G9), .Y(new_n141_));
  OAI21x1_ASAP7_75t_R g055(.A1(new_n87_), .A2(new_n140_), .B(new_n141_), .Y(new_n142_));
  OA21x2_ASAP7_75t_R  g056(.A1(new_n139_), .A2(G866), .B(new_n142_), .Y(new_n143_));
  INVx1_ASAP7_75t_R   g057(.A(G10), .Y(new_n144_));
  INVx1_ASAP7_75t_R   g058(.A(G17), .Y(new_n145_));
  OR3x1_ASAP7_75t_R   g059(.A(G866), .B(new_n145_), .C(new_n88_), .Y(new_n146_));
  OR3x1_ASAP7_75t_R   g060(.A(new_n146_), .B(new_n144_), .C(G60), .Y(new_n147_));
  OA21x2_ASAP7_75t_R  g061(.A1(new_n137_), .A2(new_n143_), .B(new_n147_), .Y(new_n148_));
  OA21x2_ASAP7_75t_R  g062(.A1(new_n131_), .A2(new_n136_), .B(new_n148_), .Y(new_n149_));
  NOR2x1_ASAP7_75t_R  g063(.A(new_n130_), .B(new_n149_), .Y(new_n150_));
  AND2x2_ASAP7_75t_R  g064(.A(new_n149_), .B(new_n130_), .Y(new_n151_));
  NOR2x1_ASAP7_75t_R  g065(.A(new_n151_), .B(new_n150_), .Y(new_n152_));
  NOR2x1_ASAP7_75t_R  g066(.A(G58), .B(new_n152_), .Y(new_n153_));
  INVx1_ASAP7_75t_R   g067(.A(G58), .Y(new_n154_));
  OR3x1_ASAP7_75t_R   g068(.A(new_n150_), .B(new_n151_), .C(new_n154_), .Y(new_n155_));
  NAND2x1_ASAP7_75t_R g069(.A(G51), .B(new_n155_), .Y(new_n156_));
  INVx1_ASAP7_75t_R   g070(.A(new_n149_), .Y(new_n157_));
  AO21x1_ASAP7_75t_R  g071(.A1(G48), .A2(G53), .B(G54), .Y(new_n158_));
  AND3x1_ASAP7_75t_R  g072(.A(G8), .B(G13), .C(G14), .Y(new_n159_));
  AND2x2_ASAP7_75t_R  g073(.A(new_n108_), .B(new_n159_), .Y(new_n160_));
  AND2x2_ASAP7_75t_R  g074(.A(G55), .B(G59), .Y(new_n161_));
  AO21x1_ASAP7_75t_R  g075(.A1(G30), .A2(G50), .B(new_n161_), .Y(new_n162_));
  AO21x1_ASAP7_75t_R  g076(.A1(new_n160_), .A2(G48), .B(new_n162_), .Y(new_n163_));
  AO21x1_ASAP7_75t_R  g077(.A1(new_n157_), .A2(new_n158_), .B(new_n163_), .Y(new_n164_));
  AOI21x1_ASAP7_75t_R g078(.A1(G52), .A2(new_n152_), .B(new_n164_), .Y(new_n165_));
  OA21x2_ASAP7_75t_R  g079(.A1(new_n156_), .A2(new_n153_), .B(new_n165_), .Y(G872));
  INVx1_ASAP7_75t_R   g080(.A(G45), .Y(new_n167_));
  INVx1_ASAP7_75t_R   g081(.A(G28), .Y(new_n168_));
  INVx1_ASAP7_75t_R   g082(.A(G35), .Y(new_n169_));
  OA21x2_ASAP7_75t_R  g083(.A1(new_n169_), .A2(new_n136_), .B(new_n147_), .Y(new_n170_));
  OA21x2_ASAP7_75t_R  g084(.A1(new_n168_), .A2(new_n143_), .B(new_n170_), .Y(new_n171_));
  AND2x2_ASAP7_75t_R  g085(.A(new_n171_), .B(new_n167_), .Y(new_n172_));
  NOR2x1_ASAP7_75t_R  g086(.A(new_n167_), .B(new_n171_), .Y(new_n173_));
  NOR2x1_ASAP7_75t_R  g087(.A(new_n172_), .B(new_n173_), .Y(new_n174_));
  INVx1_ASAP7_75t_R   g088(.A(new_n174_), .Y(new_n175_));
  MAJx2_ASAP7_75t_R   g089(.A(new_n149_), .B(new_n130_), .C(new_n154_), .Y(new_n176_));
  INVx1_ASAP7_75t_R   g090(.A(new_n176_), .Y(new_n177_));
  INVx1_ASAP7_75t_R   g091(.A(G46), .Y(new_n178_));
  INVx1_ASAP7_75t_R   g092(.A(G29), .Y(new_n179_));
  INVx1_ASAP7_75t_R   g093(.A(G36), .Y(new_n180_));
  OA21x2_ASAP7_75t_R  g094(.A1(new_n180_), .A2(new_n136_), .B(new_n147_), .Y(new_n181_));
  OA21x2_ASAP7_75t_R  g095(.A1(new_n179_), .A2(new_n143_), .B(new_n181_), .Y(new_n182_));
  AND2x2_ASAP7_75t_R  g096(.A(new_n182_), .B(new_n178_), .Y(new_n183_));
  INVx1_ASAP7_75t_R   g097(.A(G47), .Y(new_n184_));
  INVx1_ASAP7_75t_R   g098(.A(G30), .Y(new_n185_));
  INVx1_ASAP7_75t_R   g099(.A(G37), .Y(new_n186_));
  OA21x2_ASAP7_75t_R  g100(.A1(new_n186_), .A2(new_n136_), .B(new_n147_), .Y(new_n187_));
  OA21x2_ASAP7_75t_R  g101(.A1(new_n185_), .A2(new_n143_), .B(new_n187_), .Y(new_n188_));
  AND2x2_ASAP7_75t_R  g102(.A(new_n188_), .B(new_n184_), .Y(new_n189_));
  NOR2x1_ASAP7_75t_R  g103(.A(new_n183_), .B(new_n189_), .Y(new_n190_));
  INVx1_ASAP7_75t_R   g104(.A(new_n182_), .Y(new_n191_));
  NOR2x1_ASAP7_75t_R  g105(.A(new_n184_), .B(new_n188_), .Y(new_n192_));
  MAJx2_ASAP7_75t_R   g106(.A(new_n192_), .B(G46), .C(new_n191_), .Y(new_n193_));
  AOI21x1_ASAP7_75t_R g107(.A1(new_n177_), .A2(new_n190_), .B(new_n193_), .Y(new_n194_));
  NAND2x1_ASAP7_75t_R g108(.A(new_n175_), .B(new_n194_), .Y(new_n195_));
  OA21x2_ASAP7_75t_R  g109(.A1(new_n194_), .A2(new_n175_), .B(G51), .Y(new_n196_));
  INVx1_ASAP7_75t_R   g110(.A(new_n171_), .Y(new_n197_));
  AO21x1_ASAP7_75t_R  g111(.A1(G45), .A2(G53), .B(G54), .Y(new_n198_));
  AND2x2_ASAP7_75t_R  g112(.A(G27), .B(G50), .Y(new_n199_));
  AO21x1_ASAP7_75t_R  g113(.A1(new_n160_), .A2(G45), .B(new_n199_), .Y(new_n200_));
  AO21x1_ASAP7_75t_R  g114(.A1(new_n197_), .A2(new_n198_), .B(new_n200_), .Y(new_n201_));
  AO21x1_ASAP7_75t_R  g115(.A1(new_n174_), .A2(G52), .B(new_n201_), .Y(new_n202_));
  AOI21x1_ASAP7_75t_R g116(.A1(new_n196_), .A2(new_n195_), .B(new_n202_), .Y(G873));
  NOR2x1_ASAP7_75t_R  g117(.A(new_n178_), .B(new_n182_), .Y(new_n204_));
  NOR2x1_ASAP7_75t_R  g118(.A(new_n183_), .B(new_n204_), .Y(new_n205_));
  INVx1_ASAP7_75t_R   g119(.A(new_n205_), .Y(new_n206_));
  MAJx2_ASAP7_75t_R   g120(.A(new_n176_), .B(new_n184_), .C(new_n188_), .Y(new_n207_));
  NAND2x1_ASAP7_75t_R g121(.A(new_n207_), .B(new_n206_), .Y(new_n208_));
  OA21x2_ASAP7_75t_R  g122(.A1(new_n206_), .A2(new_n207_), .B(G51), .Y(new_n209_));
  AO21x1_ASAP7_75t_R  g123(.A1(G46), .A2(G53), .B(G54), .Y(new_n210_));
  AND2x2_ASAP7_75t_R  g124(.A(G55), .B(G56), .Y(new_n211_));
  AO21x1_ASAP7_75t_R  g125(.A1(G28), .A2(G50), .B(new_n211_), .Y(new_n212_));
  AO21x1_ASAP7_75t_R  g126(.A1(new_n160_), .A2(G46), .B(new_n212_), .Y(new_n213_));
  AO21x1_ASAP7_75t_R  g127(.A1(new_n191_), .A2(new_n210_), .B(new_n213_), .Y(new_n214_));
  AO21x1_ASAP7_75t_R  g128(.A1(new_n205_), .A2(G52), .B(new_n214_), .Y(new_n215_));
  AOI21x1_ASAP7_75t_R g129(.A1(new_n209_), .A2(new_n208_), .B(new_n215_), .Y(G874));
  NOR2x1_ASAP7_75t_R  g130(.A(new_n189_), .B(new_n192_), .Y(new_n217_));
  OAI21x1_ASAP7_75t_R g131(.A1(new_n177_), .A2(new_n217_), .B(G51), .Y(new_n218_));
  AO21x1_ASAP7_75t_R  g132(.A1(new_n177_), .A2(new_n217_), .B(new_n218_), .Y(new_n219_));
  NAND2x1_ASAP7_75t_R g133(.A(G52), .B(new_n217_), .Y(new_n220_));
  AOI21x1_ASAP7_75t_R g134(.A1(G47), .A2(G53), .B(G54), .Y(new_n221_));
  AND2x2_ASAP7_75t_R  g135(.A(G55), .B(G57), .Y(new_n222_));
  AO21x1_ASAP7_75t_R  g136(.A1(G29), .A2(G50), .B(new_n222_), .Y(new_n223_));
  AOI21x1_ASAP7_75t_R g137(.A1(G47), .A2(new_n160_), .B(new_n223_), .Y(new_n224_));
  OA21x2_ASAP7_75t_R  g138(.A1(new_n188_), .A2(new_n221_), .B(new_n224_), .Y(new_n225_));
  AND3x1_ASAP7_75t_R  g139(.A(new_n219_), .B(new_n220_), .C(new_n225_), .Y(G875));
  INVx1_ASAP7_75t_R   g140(.A(G41), .Y(new_n227_));
  INVx1_ASAP7_75t_R   g141(.A(G24), .Y(new_n228_));
  NAND2x1_ASAP7_75t_R g142(.A(G10), .B(new_n134_), .Y(new_n229_));
  INVx1_ASAP7_75t_R   g143(.A(G2), .Y(new_n230_));
  INVx1_ASAP7_75t_R   g144(.A(G34), .Y(new_n231_));
  OR3x1_ASAP7_75t_R   g145(.A(new_n146_), .B(new_n132_), .C(G60), .Y(new_n232_));
  OA21x2_ASAP7_75t_R  g146(.A1(new_n230_), .A2(new_n231_), .B(new_n232_), .Y(new_n233_));
  OA21x2_ASAP7_75t_R  g147(.A1(new_n169_), .A2(new_n229_), .B(new_n233_), .Y(new_n234_));
  OA21x2_ASAP7_75t_R  g148(.A1(new_n228_), .A2(new_n143_), .B(new_n234_), .Y(new_n235_));
  INVx1_ASAP7_75t_R   g149(.A(G27), .Y(new_n236_));
  INVx1_ASAP7_75t_R   g150(.A(G38), .Y(new_n237_));
  OA21x2_ASAP7_75t_R  g151(.A1(new_n231_), .A2(new_n237_), .B(new_n232_), .Y(new_n238_));
  OA21x2_ASAP7_75t_R  g152(.A1(new_n131_), .A2(new_n229_), .B(new_n238_), .Y(new_n239_));
  OA21x2_ASAP7_75t_R  g153(.A1(new_n236_), .A2(new_n143_), .B(new_n239_), .Y(new_n240_));
  INVx1_ASAP7_75t_R   g154(.A(new_n240_), .Y(new_n241_));
  OR2x4_ASAP7_75t_R   g155(.A(G44), .B(new_n241_), .Y(new_n242_));
  INVx1_ASAP7_75t_R   g156(.A(new_n173_), .Y(new_n243_));
  OA21x2_ASAP7_75t_R  g157(.A1(new_n194_), .A2(new_n172_), .B(new_n243_), .Y(new_n244_));
  INVx1_ASAP7_75t_R   g158(.A(new_n244_), .Y(new_n245_));
  AND2x2_ASAP7_75t_R  g159(.A(new_n245_), .B(new_n242_), .Y(new_n246_));
  INVx1_ASAP7_75t_R   g160(.A(new_n246_), .Y(new_n247_));
  INVx1_ASAP7_75t_R   g161(.A(G43), .Y(new_n248_));
  INVx1_ASAP7_75t_R   g162(.A(G26), .Y(new_n249_));
  OA21x2_ASAP7_75t_R  g163(.A1(new_n132_), .A2(new_n231_), .B(new_n232_), .Y(new_n250_));
  OA21x2_ASAP7_75t_R  g164(.A1(new_n186_), .A2(new_n229_), .B(new_n250_), .Y(new_n251_));
  OA21x2_ASAP7_75t_R  g165(.A1(new_n249_), .A2(new_n143_), .B(new_n251_), .Y(new_n252_));
  AND2x2_ASAP7_75t_R  g166(.A(new_n252_), .B(new_n248_), .Y(new_n253_));
  INVx1_ASAP7_75t_R   g167(.A(G42), .Y(new_n254_));
  INVx1_ASAP7_75t_R   g168(.A(G25), .Y(new_n255_));
  INVx1_ASAP7_75t_R   g169(.A(G9), .Y(new_n256_));
  OA21x2_ASAP7_75t_R  g170(.A1(new_n256_), .A2(new_n231_), .B(new_n232_), .Y(new_n257_));
  OA21x2_ASAP7_75t_R  g171(.A1(new_n180_), .A2(new_n229_), .B(new_n257_), .Y(new_n258_));
  OA21x2_ASAP7_75t_R  g172(.A1(new_n255_), .A2(new_n143_), .B(new_n258_), .Y(new_n259_));
  AND2x2_ASAP7_75t_R  g173(.A(new_n259_), .B(new_n254_), .Y(new_n260_));
  NOR2x1_ASAP7_75t_R  g174(.A(new_n260_), .B(new_n253_), .Y(new_n261_));
  INVx1_ASAP7_75t_R   g175(.A(new_n261_), .Y(new_n262_));
  INVx1_ASAP7_75t_R   g176(.A(new_n259_), .Y(new_n263_));
  NAND2x1_ASAP7_75t_R g177(.A(G42), .B(new_n263_), .Y(new_n264_));
  NOR2x1_ASAP7_75t_R  g178(.A(new_n248_), .B(new_n252_), .Y(new_n265_));
  INVx1_ASAP7_75t_R   g179(.A(new_n265_), .Y(new_n266_));
  AND2x2_ASAP7_75t_R  g180(.A(new_n241_), .B(G44), .Y(new_n267_));
  INVx1_ASAP7_75t_R   g181(.A(new_n267_), .Y(new_n268_));
  AO21x1_ASAP7_75t_R  g182(.A1(new_n268_), .A2(new_n266_), .B(new_n253_), .Y(new_n269_));
  OA21x2_ASAP7_75t_R  g183(.A1(new_n269_), .A2(new_n260_), .B(new_n264_), .Y(new_n270_));
  OA21x2_ASAP7_75t_R  g184(.A1(new_n247_), .A2(new_n262_), .B(new_n270_), .Y(new_n271_));
  MAJx2_ASAP7_75t_R   g185(.A(new_n271_), .B(new_n227_), .C(new_n235_), .Y(G876));
  AO21x1_ASAP7_75t_R  g186(.A1(new_n242_), .A2(new_n268_), .B(new_n245_), .Y(new_n273_));
  INVx1_ASAP7_75t_R   g187(.A(G51), .Y(new_n274_));
  AND2x2_ASAP7_75t_R  g188(.A(new_n268_), .B(new_n242_), .Y(new_n275_));
  AOI21x1_ASAP7_75t_R g189(.A1(new_n275_), .A2(new_n245_), .B(new_n274_), .Y(new_n276_));
  AO21x1_ASAP7_75t_R  g190(.A1(G44), .A2(G53), .B(G54), .Y(new_n277_));
  AND2x2_ASAP7_75t_R  g191(.A(G26), .B(G50), .Y(new_n278_));
  AO21x1_ASAP7_75t_R  g192(.A1(new_n160_), .A2(G44), .B(new_n278_), .Y(new_n279_));
  AO21x1_ASAP7_75t_R  g193(.A1(new_n241_), .A2(new_n277_), .B(new_n279_), .Y(new_n280_));
  AO21x1_ASAP7_75t_R  g194(.A1(new_n275_), .A2(G52), .B(new_n280_), .Y(new_n281_));
  AOI21x1_ASAP7_75t_R g195(.A1(new_n276_), .A2(new_n273_), .B(new_n281_), .Y(G877));
  XOR2x2_ASAP7_75t_R  g196(.A(new_n235_), .B(new_n227_), .Y(new_n283_));
  INVx1_ASAP7_75t_R   g197(.A(new_n283_), .Y(new_n284_));
  NAND2x1_ASAP7_75t_R g198(.A(new_n284_), .B(new_n271_), .Y(new_n285_));
  OA21x2_ASAP7_75t_R  g199(.A1(new_n271_), .A2(new_n284_), .B(G51), .Y(new_n286_));
  INVx1_ASAP7_75t_R   g200(.A(new_n235_), .Y(new_n287_));
  AO21x1_ASAP7_75t_R  g201(.A1(G41), .A2(G53), .B(G54), .Y(new_n288_));
  AND2x2_ASAP7_75t_R  g202(.A(G60), .B(G50), .Y(new_n289_));
  AO21x1_ASAP7_75t_R  g203(.A1(new_n160_), .A2(G41), .B(new_n289_), .Y(new_n290_));
  AO21x1_ASAP7_75t_R  g204(.A1(new_n287_), .A2(new_n288_), .B(new_n290_), .Y(new_n291_));
  AO21x1_ASAP7_75t_R  g205(.A1(new_n283_), .A2(G52), .B(new_n291_), .Y(new_n292_));
  AOI21x1_ASAP7_75t_R g206(.A1(new_n286_), .A2(new_n285_), .B(new_n292_), .Y(G878));
  INVx1_ASAP7_75t_R   g207(.A(new_n260_), .Y(new_n294_));
  AND2x2_ASAP7_75t_R  g208(.A(new_n294_), .B(new_n264_), .Y(new_n295_));
  OAI21x1_ASAP7_75t_R g209(.A1(new_n253_), .A2(new_n247_), .B(new_n269_), .Y(new_n296_));
  NOR2x1_ASAP7_75t_R  g210(.A(new_n295_), .B(new_n296_), .Y(new_n297_));
  AO21x1_ASAP7_75t_R  g211(.A1(new_n296_), .A2(new_n295_), .B(new_n274_), .Y(new_n298_));
  AO21x1_ASAP7_75t_R  g212(.A1(G42), .A2(G53), .B(G54), .Y(new_n299_));
  AND2x2_ASAP7_75t_R  g213(.A(G24), .B(G50), .Y(new_n300_));
  AO21x1_ASAP7_75t_R  g214(.A1(new_n160_), .A2(G42), .B(new_n300_), .Y(new_n301_));
  AO21x1_ASAP7_75t_R  g215(.A1(new_n263_), .A2(new_n299_), .B(new_n301_), .Y(new_n302_));
  AOI21x1_ASAP7_75t_R g216(.A1(G52), .A2(new_n295_), .B(new_n302_), .Y(new_n303_));
  OA21x2_ASAP7_75t_R  g217(.A1(new_n297_), .A2(new_n298_), .B(new_n303_), .Y(G879));
  NOR2x1_ASAP7_75t_R  g218(.A(new_n253_), .B(new_n265_), .Y(new_n305_));
  AO21x1_ASAP7_75t_R  g219(.A1(new_n245_), .A2(new_n242_), .B(new_n267_), .Y(new_n306_));
  NOR2x1_ASAP7_75t_R  g220(.A(new_n305_), .B(new_n306_), .Y(new_n307_));
  AO21x1_ASAP7_75t_R  g221(.A1(new_n306_), .A2(new_n305_), .B(new_n274_), .Y(new_n308_));
  INVx1_ASAP7_75t_R   g222(.A(new_n252_), .Y(new_n309_));
  AO21x1_ASAP7_75t_R  g223(.A1(G43), .A2(G53), .B(G54), .Y(new_n310_));
  AND2x2_ASAP7_75t_R  g224(.A(G25), .B(G50), .Y(new_n311_));
  AO21x1_ASAP7_75t_R  g225(.A1(new_n160_), .A2(G43), .B(new_n311_), .Y(new_n312_));
  AO21x1_ASAP7_75t_R  g226(.A1(new_n309_), .A2(new_n310_), .B(new_n312_), .Y(new_n313_));
  AOI21x1_ASAP7_75t_R g227(.A1(G52), .A2(new_n305_), .B(new_n313_), .Y(new_n314_));
  OA21x2_ASAP7_75t_R  g228(.A1(new_n307_), .A2(new_n308_), .B(new_n314_), .Y(G880));
endmodule


