module mapped( G1 , G3 , G2 , G4 , G5 , G16 , G17 );
  input G1 , G3 , G2 , G4 , G5 ;
  output G16 , G17 ;
  wire n7 , n8 , n9 , n10 ;
  INVx1_ASAP7_75t_R   g0( .A (G2), .Y (n7) );
  AND2x2_ASAP7_75t_R  g1( .A (G3), .B (G4), .Y (n9) );
  NAND2x1_ASAP7_75t_R g2( .A (G1), .B (G3), .Y (n8) );
  OAI21x1_ASAP7_75t_R g3( .A1 (n7), .A2 (n9), .B (n8), .Y (G16) );
  NAND2x1_ASAP7_75t_R g4( .A (G3), .B (G4), .Y (n10) );
  OA21x2_ASAP7_75t_R  g5( .A1 (G2), .A2 (G5), .B (n10), .Y (G17) );
endmodule
