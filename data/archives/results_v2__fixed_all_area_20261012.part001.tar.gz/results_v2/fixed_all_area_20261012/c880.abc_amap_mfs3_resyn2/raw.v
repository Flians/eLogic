// Benchmark "/home/flynn/workplace/MIGBalance/results_v2/fixed_all_area_20261012/c880.resyn2" written by ABC on Mon Oct 12 14:59:18 2026

module \/home/flynn/workplace/MIGBalance/results_v2/fixed_all_area_20261012/c880.resyn2  ( 
    G8, G16, G6, G17, G7, G18, G19, G4, G3, G2, G1, G5, G11, G23, G20, G21,
    G9, G10, G12, G15, G22, G32, G24, G25, G26, G27, G28, G29, G30, G31,
    G33, G41, G42, G43, G44, G45, G46, G47, G48, G49, G13, G14, G55, G59,
    G54, G60, G39, G40, G52, G53, G50, G51, G58, G35, G37, G36, G56, G57,
    G34, G38,
    G855, G856, G857, G858, G859, G860, G861, G862, G863, G864, G865, G866,
    G867, G868, G869, G870, G871, G872, G873, G874, G875, G876, G877, G878,
    G879, G880  );
  input  G8, G16, G6, G17, G7, G18, G19, G4, G3, G2, G1, G5, G11, G23,
    G20, G21, G9, G10, G12, G15, G22, G32, G24, G25, G26, G27, G28, G29,
    G30, G31, G33, G41, G42, G43, G44, G45, G46, G47, G48, G49, G13, G14,
    G55, G59, G54, G60, G39, G40, G52, G53, G50, G51, G58, G35, G37, G36,
    G56, G57, G34, G38;
  output G855, G856, G857, G858, G859, G860, G861, G862, G863, G864, G865,
    G866, G867, G868, G869, G870, G871, G872, G873, G874, G875, G876, G877,
    G878, G879, G880;
  wire new_n106_, new_n112_, new_n114_, new_n115_, new_n117_, new_n123_,
    new_n125_, new_n127_, new_n128_, new_n131_, new_n132_, new_n133_,
    new_n134_, new_n135_, new_n136_, new_n137_, new_n138_, new_n140_,
    new_n141_, new_n142_, new_n143_, new_n144_, new_n145_, new_n146_,
    new_n147_, new_n149_, new_n150_, new_n151_, new_n152_, new_n153_,
    new_n154_, new_n155_, new_n156_, new_n157_, new_n158_, new_n159_,
    new_n160_, new_n161_, new_n162_, new_n163_, new_n167_, new_n168_,
    new_n169_, new_n170_, new_n171_, new_n172_, new_n173_, new_n174_,
    new_n176_, new_n177_, new_n178_, new_n179_, new_n181_, new_n182_,
    new_n183_, new_n184_, new_n185_, new_n186_, new_n187_, new_n189_,
    new_n190_, new_n191_, new_n192_, new_n193_, new_n195_, new_n196_,
    new_n197_, new_n198_, new_n199_, new_n200_, new_n201_, new_n203_,
    new_n204_, new_n205_, new_n206_, new_n207_, new_n208_, new_n209_,
    new_n210_, new_n211_, new_n212_, new_n214_, new_n215_, new_n216_,
    new_n217_, new_n218_, new_n219_, new_n220_, new_n221_, new_n222_,
    new_n224_, new_n225_, new_n226_, new_n227_, new_n228_, new_n229_,
    new_n231_, new_n232_, new_n233_, new_n235_, new_n236_, new_n237_,
    new_n238_, new_n239_, new_n240_, new_n241_, new_n243_, new_n244_,
    new_n245_, new_n246_, new_n248_, new_n249_, new_n250_, new_n251_,
    new_n252_, new_n253_, new_n254_, new_n255_, new_n257_, new_n258_,
    new_n259_, new_n260_, new_n261_, new_n262_, new_n263_, new_n264_,
    new_n266_, new_n268_, new_n269_, new_n270_, new_n271_, new_n272_,
    new_n273_, new_n274_, new_n276_, new_n277_, new_n278_, new_n279_,
    new_n280_, new_n281_, new_n282_, new_n283_, new_n284_, new_n286_,
    new_n287_, new_n288_, new_n289_, new_n290_, new_n291_, new_n292_,
    new_n293_, new_n294_, new_n296_, new_n297_, new_n298_, new_n299_,
    new_n300_, new_n301_, new_n302_, new_n303_, new_n304_, new_n305_,
    new_n306_, new_n307_, new_n308_, new_n309_, new_n310_, new_n311_,
    new_n312_, new_n313_, new_n314_, new_n316_, new_n317_, new_n318_,
    new_n319_, new_n320_, new_n321_, new_n322_, new_n323_, new_n324_,
    new_n325_, new_n326_;
  NAND2x1_ASAP7_75t_R g000(.A(G16), .B(G6), .Y(new_n106_));
  OR3x1_ASAP7_75t_R   g001(.A(new_n297_), .B(new_n298_), .C(new_n296_), .Y(G855));
  OR3x1_ASAP7_75t_R   g002(.A(new_n298_), .B(new_n300_), .C(new_n299_), .Y(G856));
  OR3x1_ASAP7_75t_R   g003(.A(new_n298_), .B(new_n300_), .C(new_n296_), .Y(G857));
  NAND2x1_ASAP7_75t_R g004(.A(G18), .B(G19), .Y(G858));
  NAND2x1_ASAP7_75t_R g005(.A(G2), .B(G1), .Y(new_n112_));
  OR3x1_ASAP7_75t_R   g006(.A(new_n301_), .B(new_n302_), .C(new_n112_), .Y(G859));
  NAND2x1_ASAP7_75t_R g007(.A(G1), .B(G5), .Y(new_n114_));
  OR3x1_ASAP7_75t_R   g008(.A(new_n301_), .B(new_n302_), .C(new_n114_), .Y(new_n115_));
  NOR2x1_ASAP7_75t_R  g009(.A(new_n314_), .B(new_n115_), .Y(G860));
  NOR2x1_ASAP7_75t_R  g010(.A(new_n297_), .B(new_n303_), .Y(new_n117_));
  AND3x1_ASAP7_75t_R  g011(.A(G16), .B(G11), .C(G17), .Y(G861));
  AND3x1_ASAP7_75t_R  g012(.A(G7), .B(G11), .C(G17), .Y(G862));
  AND3x1_ASAP7_75t_R  g013(.A(G7), .B(G11), .C(G8), .Y(G863));
  OAI21x1_ASAP7_75t_R g014(.A1(G20), .A2(G21), .B(G23), .Y(G864));
  NOR2x1_ASAP7_75t_R  g015(.A(G857), .B(new_n115_), .Y(G865));
  AND3x1_ASAP7_75t_R  g016(.A(G1), .B(G5), .C(G9), .Y(new_n123_));
  OR3x1_ASAP7_75t_R   g017(.A(new_n302_), .B(new_n305_), .C(new_n112_), .Y(new_n125_));
  OR3x1_ASAP7_75t_R   g018(.A(new_n298_), .B(new_n306_), .C(new_n125_), .Y(G867));
  OR3x1_ASAP7_75t_R   g019(.A(new_n303_), .B(new_n306_), .C(new_n125_), .Y(new_n127_));
  INVx1_ASAP7_75t_R   g020(.A(new_n127_), .Y(new_n128_));
  NAND2x1_ASAP7_75t_R g021(.A(G15), .B(new_n128_), .Y(G868));
  OAI21x1_ASAP7_75t_R g022(.A1(G20), .A2(G21), .B(G22), .Y(G869));
  XNOR2x2_ASAP7_75t_R g023(.A(new_n307_), .B(G25), .Y(new_n131_));
  XOR2x2_ASAP7_75t_R  g024(.A(G32), .B(new_n131_), .Y(new_n132_));
  XOR2x2_ASAP7_75t_R  g025(.A(G30), .B(G31), .Y(new_n133_));
  XNOR2x2_ASAP7_75t_R g026(.A(new_n132_), .B(new_n133_), .Y(new_n134_));
  XNOR2x2_ASAP7_75t_R g027(.A(new_n309_), .B(G29), .Y(new_n135_));
  XOR2x2_ASAP7_75t_R  g028(.A(G33), .B(new_n135_), .Y(new_n136_));
  XOR2x2_ASAP7_75t_R  g029(.A(new_n308_), .B(G27), .Y(new_n137_));
  XNOR2x2_ASAP7_75t_R g030(.A(new_n136_), .B(new_n137_), .Y(new_n138_));
  XOR2x2_ASAP7_75t_R  g031(.A(new_n134_), .B(new_n138_), .Y(G870));
  XNOR2x2_ASAP7_75t_R g032(.A(new_n310_), .B(G42), .Y(new_n140_));
  XOR2x2_ASAP7_75t_R  g033(.A(G32), .B(new_n140_), .Y(new_n141_));
  XOR2x2_ASAP7_75t_R  g034(.A(G47), .B(G48), .Y(new_n142_));
  XNOR2x2_ASAP7_75t_R g035(.A(new_n141_), .B(new_n142_), .Y(new_n143_));
  XOR2x2_ASAP7_75t_R  g036(.A(G45), .B(G46), .Y(new_n144_));
  XOR2x2_ASAP7_75t_R  g037(.A(G49), .B(new_n144_), .Y(new_n145_));
  XOR2x2_ASAP7_75t_R  g038(.A(G43), .B(new_n311_), .Y(new_n146_));
  XNOR2x2_ASAP7_75t_R g039(.A(new_n145_), .B(new_n146_), .Y(new_n147_));
  XOR2x2_ASAP7_75t_R  g040(.A(new_n143_), .B(new_n147_), .Y(G871));
  NAND2x1_ASAP7_75t_R g041(.A(G11), .B(G40), .Y(new_n149_));
  AO21x1_ASAP7_75t_R  g042(.A1(G11), .A2(G40), .B(G866), .Y(new_n150_));
  OAI21x1_ASAP7_75t_R g043(.A1(new_n301_), .A2(new_n150_), .B(G1), .Y(new_n151_));
  AO21x1_ASAP7_75t_R  g044(.A1(G8), .A2(G4), .B(new_n149_), .Y(new_n152_));
  AOI21x1_ASAP7_75t_R g045(.A1(new_n296_), .A2(new_n301_), .B(new_n152_), .Y(new_n153_));
  OR3x1_ASAP7_75t_R   g046(.A(new_n301_), .B(new_n304_), .C(new_n112_), .Y(new_n154_));
  AOI21x1_ASAP7_75t_R g047(.A1(G8), .A2(new_n117_), .B(new_n154_), .Y(new_n155_));
  AO21x1_ASAP7_75t_R  g048(.A1(new_n123_), .A2(new_n153_), .B(new_n155_), .Y(new_n156_));
  OR3x1_ASAP7_75t_R   g049(.A(new_n299_), .B(new_n106_), .C(G866), .Y(new_n157_));
  OR3x1_ASAP7_75t_R   g050(.A(new_n305_), .B(G60), .C(new_n157_), .Y(new_n158_));
  INVx1_ASAP7_75t_R   g051(.A(new_n158_), .Y(new_n159_));
  AO21x1_ASAP7_75t_R  g052(.A1(G31), .A2(new_n156_), .B(new_n159_), .Y(new_n160_));
  AO21x1_ASAP7_75t_R  g053(.A1(G39), .A2(new_n151_), .B(new_n160_), .Y(new_n161_));
  NAND2x1_ASAP7_75t_R g054(.A(G48), .B(new_n161_), .Y(new_n162_));
  OA21x2_ASAP7_75t_R  g055(.A1(G48), .A2(new_n161_), .B(new_n162_), .Y(new_n163_));
  AO21x1_ASAP7_75t_R  g056(.A1(G48), .A2(G53), .B(G54), .Y(new_n167_));
  AND3x1_ASAP7_75t_R  g057(.A(G8), .B(G13), .C(G14), .Y(new_n168_));
  AND2x2_ASAP7_75t_R  g058(.A(new_n128_), .B(new_n168_), .Y(new_n169_));
  AND2x2_ASAP7_75t_R  g059(.A(G30), .B(G50), .Y(new_n170_));
  AO21x1_ASAP7_75t_R  g060(.A1(G55), .A2(G59), .B(new_n170_), .Y(new_n171_));
  AO21x1_ASAP7_75t_R  g061(.A1(G48), .A2(new_n169_), .B(new_n171_), .Y(new_n172_));
  AO21x1_ASAP7_75t_R  g062(.A1(new_n161_), .A2(new_n167_), .B(new_n172_), .Y(new_n173_));
  AO21x1_ASAP7_75t_R  g063(.A1(G52), .A2(new_n163_), .B(new_n173_), .Y(new_n174_));
  NOR2x1_ASAP7_75t_R  g064(.A(new_n318_), .B(new_n174_), .Y(G872));
  AO21x1_ASAP7_75t_R  g065(.A1(G35), .A2(new_n151_), .B(new_n159_), .Y(new_n176_));
  AO21x1_ASAP7_75t_R  g066(.A1(G28), .A2(new_n156_), .B(new_n176_), .Y(new_n177_));
  NOR2x1_ASAP7_75t_R  g067(.A(G45), .B(new_n177_), .Y(new_n178_));
  AO21x1_ASAP7_75t_R  g068(.A1(G45), .A2(new_n177_), .B(new_n178_), .Y(new_n179_));
  AO21x1_ASAP7_75t_R  g069(.A1(G48), .A2(new_n161_), .B(new_n316_), .Y(new_n181_));
  AO21x1_ASAP7_75t_R  g070(.A1(G36), .A2(new_n151_), .B(new_n159_), .Y(new_n182_));
  AO21x1_ASAP7_75t_R  g071(.A1(G29), .A2(new_n156_), .B(new_n182_), .Y(new_n183_));
  NOR2x1_ASAP7_75t_R  g072(.A(G46), .B(new_n183_), .Y(new_n184_));
  AO21x1_ASAP7_75t_R  g073(.A1(G37), .A2(new_n151_), .B(new_n159_), .Y(new_n185_));
  AO21x1_ASAP7_75t_R  g074(.A1(G30), .A2(new_n156_), .B(new_n185_), .Y(new_n186_));
  NOR2x1_ASAP7_75t_R  g075(.A(G47), .B(new_n186_), .Y(new_n187_));
  NOR2x1_ASAP7_75t_R  g076(.A(new_n184_), .B(new_n187_), .Y(new_n189_));
  AND2x2_ASAP7_75t_R  g077(.A(G47), .B(new_n186_), .Y(new_n190_));
  OA21x2_ASAP7_75t_R  g078(.A1(G46), .A2(new_n183_), .B(new_n190_), .Y(new_n191_));
  AO21x1_ASAP7_75t_R  g079(.A1(G46), .A2(new_n183_), .B(new_n191_), .Y(new_n192_));
  AO21x1_ASAP7_75t_R  g080(.A1(new_n181_), .A2(new_n189_), .B(new_n192_), .Y(new_n193_));
  AO21x1_ASAP7_75t_R  g081(.A1(new_n319_), .A2(new_n193_), .B(new_n313_), .Y(new_n195_));
  AOI21x1_ASAP7_75t_R g082(.A1(new_n179_), .A2(new_n321_), .B(new_n195_), .Y(new_n196_));
  AO21x1_ASAP7_75t_R  g083(.A1(G45), .A2(G53), .B(G54), .Y(new_n197_));
  AND2x2_ASAP7_75t_R  g084(.A(G27), .B(G50), .Y(new_n198_));
  AO21x1_ASAP7_75t_R  g085(.A1(G45), .A2(new_n169_), .B(new_n198_), .Y(new_n199_));
  AO21x1_ASAP7_75t_R  g086(.A1(new_n177_), .A2(new_n197_), .B(new_n199_), .Y(new_n200_));
  AO21x1_ASAP7_75t_R  g087(.A1(G52), .A2(new_n319_), .B(new_n200_), .Y(new_n201_));
  NOR2x1_ASAP7_75t_R  g088(.A(new_n196_), .B(new_n201_), .Y(G873));
  AOI21x1_ASAP7_75t_R g089(.A1(G46), .A2(new_n183_), .B(new_n184_), .Y(new_n203_));
  AO21x1_ASAP7_75t_R  g090(.A1(new_n181_), .A2(new_n320_), .B(new_n190_), .Y(new_n204_));
  AOI21x1_ASAP7_75t_R g091(.A1(new_n203_), .A2(new_n204_), .B(new_n313_), .Y(new_n205_));
  OA21x2_ASAP7_75t_R  g092(.A1(new_n203_), .A2(new_n204_), .B(new_n205_), .Y(new_n206_));
  AO21x1_ASAP7_75t_R  g093(.A1(G46), .A2(G53), .B(G54), .Y(new_n207_));
  NOR2x1_ASAP7_75t_R  g094(.A(new_n309_), .B(new_n312_), .Y(new_n208_));
  AO21x1_ASAP7_75t_R  g095(.A1(G55), .A2(G56), .B(new_n208_), .Y(new_n209_));
  AO21x1_ASAP7_75t_R  g096(.A1(G46), .A2(new_n169_), .B(new_n209_), .Y(new_n210_));
  AO21x1_ASAP7_75t_R  g097(.A1(new_n183_), .A2(new_n207_), .B(new_n210_), .Y(new_n211_));
  AO21x1_ASAP7_75t_R  g098(.A1(G52), .A2(new_n203_), .B(new_n211_), .Y(new_n212_));
  NOR2x1_ASAP7_75t_R  g099(.A(new_n206_), .B(new_n212_), .Y(G874));
  NOR2x1_ASAP7_75t_R  g100(.A(new_n187_), .B(new_n190_), .Y(new_n214_));
  OAI21x1_ASAP7_75t_R g101(.A1(new_n181_), .A2(new_n214_), .B(G51), .Y(new_n215_));
  AOI21x1_ASAP7_75t_R g102(.A1(new_n181_), .A2(new_n214_), .B(new_n215_), .Y(new_n216_));
  AO21x1_ASAP7_75t_R  g103(.A1(G47), .A2(G53), .B(G54), .Y(new_n217_));
  AND2x2_ASAP7_75t_R  g104(.A(G29), .B(G50), .Y(new_n218_));
  AO21x1_ASAP7_75t_R  g105(.A1(G55), .A2(G57), .B(new_n218_), .Y(new_n219_));
  AO21x1_ASAP7_75t_R  g106(.A1(G47), .A2(new_n169_), .B(new_n219_), .Y(new_n220_));
  AO21x1_ASAP7_75t_R  g107(.A1(new_n186_), .A2(new_n217_), .B(new_n220_), .Y(new_n221_));
  AO21x1_ASAP7_75t_R  g108(.A1(G52), .A2(new_n214_), .B(new_n221_), .Y(new_n222_));
  NOR2x1_ASAP7_75t_R  g109(.A(new_n216_), .B(new_n222_), .Y(G875));
  AND3x1_ASAP7_75t_R  g110(.A(new_n123_), .B(new_n149_), .C(G10), .Y(new_n224_));
  OR3x1_ASAP7_75t_R   g111(.A(new_n301_), .B(G60), .C(new_n157_), .Y(new_n225_));
  INVx1_ASAP7_75t_R   g112(.A(new_n225_), .Y(new_n226_));
  AO21x1_ASAP7_75t_R  g113(.A1(G2), .A2(G34), .B(new_n226_), .Y(new_n227_));
  AO21x1_ASAP7_75t_R  g114(.A1(G35), .A2(new_n224_), .B(new_n227_), .Y(new_n228_));
  AO21x1_ASAP7_75t_R  g115(.A1(G24), .A2(new_n156_), .B(new_n228_), .Y(new_n229_));
  AO21x1_ASAP7_75t_R  g116(.A1(G34), .A2(G38), .B(new_n226_), .Y(new_n231_));
  AO21x1_ASAP7_75t_R  g117(.A1(G39), .A2(new_n224_), .B(new_n231_), .Y(new_n232_));
  AO21x1_ASAP7_75t_R  g118(.A1(G27), .A2(new_n156_), .B(new_n232_), .Y(new_n233_));
  NOR2x1_ASAP7_75t_R  g119(.A(new_n178_), .B(new_n321_), .Y(new_n235_));
  AO21x1_ASAP7_75t_R  g120(.A1(G45), .A2(new_n177_), .B(new_n235_), .Y(new_n236_));
  OA21x2_ASAP7_75t_R  g121(.A1(G44), .A2(new_n233_), .B(new_n236_), .Y(new_n237_));
  AO21x1_ASAP7_75t_R  g122(.A1(G4), .A2(G34), .B(new_n226_), .Y(new_n238_));
  AO21x1_ASAP7_75t_R  g123(.A1(G37), .A2(new_n224_), .B(new_n238_), .Y(new_n239_));
  AO21x1_ASAP7_75t_R  g124(.A1(G26), .A2(new_n156_), .B(new_n239_), .Y(new_n240_));
  NOR2x1_ASAP7_75t_R  g125(.A(G43), .B(new_n240_), .Y(new_n241_));
  AO21x1_ASAP7_75t_R  g126(.A1(G9), .A2(G34), .B(new_n226_), .Y(new_n243_));
  AO21x1_ASAP7_75t_R  g127(.A1(G36), .A2(new_n224_), .B(new_n243_), .Y(new_n244_));
  AO21x1_ASAP7_75t_R  g128(.A1(G25), .A2(new_n156_), .B(new_n244_), .Y(new_n245_));
  NOR2x1_ASAP7_75t_R  g129(.A(G42), .B(new_n245_), .Y(new_n246_));
  AND3x1_ASAP7_75t_R  g130(.A(new_n324_), .B(new_n325_), .C(new_n237_), .Y(new_n248_));
  NOR2x1_ASAP7_75t_R  g131(.A(new_n311_), .B(new_n323_), .Y(new_n249_));
  AO21x1_ASAP7_75t_R  g132(.A1(G43), .A2(new_n240_), .B(new_n249_), .Y(new_n250_));
  AND2x2_ASAP7_75t_R  g133(.A(new_n324_), .B(new_n250_), .Y(new_n251_));
  AND3x1_ASAP7_75t_R  g134(.A(new_n324_), .B(new_n250_), .C(new_n325_), .Y(new_n252_));
  AO21x1_ASAP7_75t_R  g135(.A1(G42), .A2(new_n245_), .B(new_n252_), .Y(new_n253_));
  NOR2x1_ASAP7_75t_R  g136(.A(new_n248_), .B(new_n253_), .Y(new_n254_));
  AO21x1_ASAP7_75t_R  g137(.A1(new_n310_), .A2(new_n322_), .B(new_n254_), .Y(new_n255_));
  OA21x2_ASAP7_75t_R  g138(.A1(new_n310_), .A2(new_n322_), .B(new_n255_), .Y(G876));
  AOI21x1_ASAP7_75t_R g139(.A1(new_n311_), .A2(new_n323_), .B(new_n249_), .Y(new_n257_));
  AOI21x1_ASAP7_75t_R g140(.A1(new_n236_), .A2(new_n257_), .B(new_n313_), .Y(new_n258_));
  OA21x2_ASAP7_75t_R  g141(.A1(new_n236_), .A2(new_n257_), .B(new_n258_), .Y(new_n259_));
  AO21x1_ASAP7_75t_R  g142(.A1(G44), .A2(G53), .B(G54), .Y(new_n260_));
  NOR2x1_ASAP7_75t_R  g143(.A(new_n308_), .B(new_n312_), .Y(new_n261_));
  AO21x1_ASAP7_75t_R  g144(.A1(G44), .A2(new_n169_), .B(new_n261_), .Y(new_n262_));
  AO21x1_ASAP7_75t_R  g145(.A1(new_n233_), .A2(new_n260_), .B(new_n262_), .Y(new_n263_));
  AO21x1_ASAP7_75t_R  g146(.A1(G52), .A2(new_n257_), .B(new_n263_), .Y(new_n264_));
  NOR2x1_ASAP7_75t_R  g147(.A(new_n259_), .B(new_n264_), .Y(G877));
  XOR2x2_ASAP7_75t_R  g148(.A(new_n310_), .B(new_n322_), .Y(new_n266_));
  OAI21x1_ASAP7_75t_R g149(.A1(new_n254_), .A2(new_n326_), .B(G51), .Y(new_n268_));
  AOI21x1_ASAP7_75t_R g150(.A1(new_n254_), .A2(new_n326_), .B(new_n268_), .Y(new_n269_));
  AO21x1_ASAP7_75t_R  g151(.A1(G41), .A2(G53), .B(G54), .Y(new_n270_));
  AND2x2_ASAP7_75t_R  g152(.A(G60), .B(G50), .Y(new_n271_));
  AO21x1_ASAP7_75t_R  g153(.A1(G41), .A2(new_n169_), .B(new_n271_), .Y(new_n272_));
  AO21x1_ASAP7_75t_R  g154(.A1(new_n229_), .A2(new_n270_), .B(new_n272_), .Y(new_n273_));
  AO21x1_ASAP7_75t_R  g155(.A1(G52), .A2(new_n266_), .B(new_n273_), .Y(new_n274_));
  NOR2x1_ASAP7_75t_R  g156(.A(new_n269_), .B(new_n274_), .Y(G878));
  AOI21x1_ASAP7_75t_R g157(.A1(G42), .A2(new_n245_), .B(new_n246_), .Y(new_n276_));
  AO21x1_ASAP7_75t_R  g158(.A1(new_n237_), .A2(new_n324_), .B(new_n251_), .Y(new_n277_));
  AOI21x1_ASAP7_75t_R g159(.A1(new_n276_), .A2(new_n277_), .B(new_n313_), .Y(new_n278_));
  OA21x2_ASAP7_75t_R  g160(.A1(new_n276_), .A2(new_n277_), .B(new_n278_), .Y(new_n279_));
  AO21x1_ASAP7_75t_R  g161(.A1(G42), .A2(G53), .B(G54), .Y(new_n280_));
  NOR2x1_ASAP7_75t_R  g162(.A(new_n307_), .B(new_n312_), .Y(new_n281_));
  AO21x1_ASAP7_75t_R  g163(.A1(G42), .A2(new_n169_), .B(new_n281_), .Y(new_n282_));
  AO21x1_ASAP7_75t_R  g164(.A1(new_n245_), .A2(new_n280_), .B(new_n282_), .Y(new_n283_));
  AO21x1_ASAP7_75t_R  g165(.A1(G52), .A2(new_n276_), .B(new_n283_), .Y(new_n284_));
  NOR2x1_ASAP7_75t_R  g166(.A(new_n279_), .B(new_n284_), .Y(G879));
  AOI21x1_ASAP7_75t_R g167(.A1(G43), .A2(new_n240_), .B(new_n241_), .Y(new_n286_));
  AO21x1_ASAP7_75t_R  g168(.A1(G44), .A2(new_n233_), .B(new_n237_), .Y(new_n287_));
  AOI21x1_ASAP7_75t_R g169(.A1(new_n286_), .A2(new_n287_), .B(new_n313_), .Y(new_n288_));
  OA21x2_ASAP7_75t_R  g170(.A1(new_n286_), .A2(new_n287_), .B(new_n288_), .Y(new_n289_));
  AO21x1_ASAP7_75t_R  g171(.A1(G43), .A2(G53), .B(G54), .Y(new_n290_));
  AND2x2_ASAP7_75t_R  g172(.A(G25), .B(G50), .Y(new_n291_));
  AO21x1_ASAP7_75t_R  g173(.A1(G43), .A2(new_n169_), .B(new_n291_), .Y(new_n292_));
  AO21x1_ASAP7_75t_R  g174(.A1(new_n240_), .A2(new_n290_), .B(new_n292_), .Y(new_n293_));
  AO21x1_ASAP7_75t_R  g175(.A1(G52), .A2(new_n286_), .B(new_n293_), .Y(new_n294_));
  NOR2x1_ASAP7_75t_R  g176(.A(new_n289_), .B(new_n294_), .Y(G880));
  INVx1_ASAP7_75t_R   g177(.A(G8), .Y(new_n296_));
  INVx1_ASAP7_75t_R   g178(.A(G16), .Y(new_n297_));
  INVx1_ASAP7_75t_R   g179(.A(G6), .Y(new_n298_));
  INVx1_ASAP7_75t_R   g180(.A(G17), .Y(new_n299_));
  INVx1_ASAP7_75t_R   g181(.A(G7), .Y(new_n300_));
  INVx1_ASAP7_75t_R   g182(.A(G4), .Y(new_n301_));
  INVx1_ASAP7_75t_R   g183(.A(G3), .Y(new_n302_));
  INVx1_ASAP7_75t_R   g184(.A(G11), .Y(new_n303_));
  INVx1_ASAP7_75t_R   g185(.A(G9), .Y(new_n304_));
  INVx1_ASAP7_75t_R   g186(.A(G10), .Y(new_n305_));
  INVx1_ASAP7_75t_R   g187(.A(G12), .Y(new_n306_));
  INVx1_ASAP7_75t_R   g188(.A(G24), .Y(new_n307_));
  INVx1_ASAP7_75t_R   g189(.A(G26), .Y(new_n308_));
  INVx1_ASAP7_75t_R   g190(.A(G28), .Y(new_n309_));
  INVx1_ASAP7_75t_R   g191(.A(G41), .Y(new_n310_));
  INVx1_ASAP7_75t_R   g192(.A(G44), .Y(new_n311_));
  INVx1_ASAP7_75t_R   g193(.A(G50), .Y(new_n312_));
  INVx1_ASAP7_75t_R   g194(.A(G51), .Y(new_n313_));
  INVx1_ASAP7_75t_R   g195(.A(G857), .Y(new_n314_));
  INVx1_ASAP7_75t_R   g196(.A(new_n123_), .Y(G866));
  AND2x2_ASAP7_75t_R  g197(.A(G58), .B(new_n163_), .Y(new_n316_));
  OAI21x1_ASAP7_75t_R g198(.A1(G58), .A2(new_n163_), .B(G51), .Y(new_n317_));
  NOR2x1_ASAP7_75t_R  g199(.A(new_n317_), .B(new_n316_), .Y(new_n318_));
  INVx1_ASAP7_75t_R   g200(.A(new_n179_), .Y(new_n319_));
  INVx1_ASAP7_75t_R   g201(.A(new_n187_), .Y(new_n320_));
  INVx1_ASAP7_75t_R   g202(.A(new_n193_), .Y(new_n321_));
  INVx1_ASAP7_75t_R   g203(.A(new_n229_), .Y(new_n322_));
  INVx1_ASAP7_75t_R   g204(.A(new_n233_), .Y(new_n323_));
  INVx1_ASAP7_75t_R   g205(.A(new_n241_), .Y(new_n324_));
  INVx1_ASAP7_75t_R   g206(.A(new_n246_), .Y(new_n325_));
  INVx1_ASAP7_75t_R   g207(.A(new_n266_), .Y(new_n326_));
endmodule


