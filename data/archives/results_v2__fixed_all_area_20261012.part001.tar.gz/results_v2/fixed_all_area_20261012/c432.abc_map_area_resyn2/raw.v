// Benchmark "/home/flynn/workplace/MIGBalance/results_v2/fixed_all_area_20261012/c432.resyn2" written by ABC on Mon Oct 12 14:59:04 2026

module \/home/flynn/workplace/MIGBalance/results_v2/fixed_all_area_20261012/c432.resyn2  ( 
    G32, G34, G28, G30, G24, G26, G20, G22, G16, G18, G12, G14, G8, G10,
    G4, G6, G1, G2, G35, G31, G27, G23, G19, G15, G11, G7, G3, G36, G33,
    G29, G25, G21, G17, G13, G9, G5,
    G426, G427, G428, G429, G430, G431, G432  );
  input  G32, G34, G28, G30, G24, G26, G20, G22, G16, G18, G12, G14, G8,
    G10, G4, G6, G1, G2, G35, G31, G27, G23, G19, G15, G11, G7, G3, G36,
    G33, G29, G25, G21, G17, G13, G9, G5;
  output G426, G427, G428, G429, G430, G431, G432;
  wire new_n44_, new_n45_, new_n46_, new_n47_, new_n48_, new_n49_, new_n50_,
    new_n51_, new_n52_, new_n53_, new_n54_, new_n55_, new_n56_, new_n57_,
    new_n58_, new_n59_, new_n60_, new_n61_, new_n62_, new_n63_, new_n65_,
    new_n66_, new_n67_, new_n68_, new_n69_, new_n70_, new_n71_, new_n72_,
    new_n73_, new_n74_, new_n75_, new_n76_, new_n77_, new_n78_, new_n79_,
    new_n80_, new_n81_, new_n82_, new_n83_, new_n84_, new_n85_, new_n86_,
    new_n87_, new_n88_, new_n89_, new_n91_, new_n92_, new_n93_, new_n94_,
    new_n95_, new_n96_, new_n97_, new_n98_, new_n99_, new_n100_, new_n101_,
    new_n102_, new_n103_, new_n104_, new_n105_, new_n106_, new_n107_,
    new_n108_, new_n109_, new_n110_, new_n111_, new_n112_, new_n113_,
    new_n114_, new_n115_, new_n116_, new_n118_, new_n119_, new_n120_,
    new_n121_, new_n122_, new_n123_, new_n124_, new_n125_, new_n126_,
    new_n127_, new_n128_, new_n129_, new_n130_, new_n131_, new_n132_,
    new_n133_, new_n136_, new_n137_, new_n138_, new_n139_, new_n140_,
    new_n142_, new_n143_, new_n144_, new_n145_, new_n146_;
  INVx1_ASAP7_75t_R   g000(.A(G18), .Y(new_n44_));
  INVx1_ASAP7_75t_R   g001(.A(G14), .Y(new_n45_));
  INVx1_ASAP7_75t_R   g002(.A(G20), .Y(new_n46_));
  NAND2x1_ASAP7_75t_R g003(.A(G22), .B(new_n46_), .Y(new_n47_));
  OA21x2_ASAP7_75t_R  g004(.A1(G12), .A2(new_n45_), .B(new_n47_), .Y(new_n48_));
  OA21x2_ASAP7_75t_R  g005(.A1(G16), .A2(new_n44_), .B(new_n48_), .Y(new_n49_));
  INVx1_ASAP7_75t_R   g006(.A(G30), .Y(new_n50_));
  INVx1_ASAP7_75t_R   g007(.A(G32), .Y(new_n51_));
  NAND2x1_ASAP7_75t_R g008(.A(G34), .B(new_n51_), .Y(new_n52_));
  OA21x2_ASAP7_75t_R  g009(.A1(G28), .A2(new_n50_), .B(new_n52_), .Y(new_n53_));
  INVx1_ASAP7_75t_R   g010(.A(G10), .Y(new_n54_));
  INVx1_ASAP7_75t_R   g011(.A(G26), .Y(new_n55_));
  OR2x4_ASAP7_75t_R   g012(.A(G24), .B(new_n55_), .Y(new_n56_));
  OA21x2_ASAP7_75t_R  g013(.A1(G8), .A2(new_n54_), .B(new_n56_), .Y(new_n57_));
  INVx1_ASAP7_75t_R   g014(.A(G6), .Y(new_n58_));
  INVx1_ASAP7_75t_R   g015(.A(G1), .Y(new_n59_));
  NAND2x1_ASAP7_75t_R g016(.A(G2), .B(new_n59_), .Y(new_n60_));
  OA21x2_ASAP7_75t_R  g017(.A1(G4), .A2(new_n58_), .B(new_n60_), .Y(new_n61_));
  AND3x1_ASAP7_75t_R  g018(.A(new_n57_), .B(new_n53_), .C(new_n61_), .Y(new_n62_));
  AND2x2_ASAP7_75t_R  g019(.A(new_n62_), .B(new_n49_), .Y(new_n63_));
  INVx1_ASAP7_75t_R   g020(.A(new_n63_), .Y(G426));
  AO21x1_ASAP7_75t_R  g021(.A1(G426), .A2(G28), .B(new_n50_), .Y(new_n65_));
  NOR2x1_ASAP7_75t_R  g022(.A(G31), .B(new_n65_), .Y(new_n66_));
  INVx1_ASAP7_75t_R   g023(.A(new_n66_), .Y(new_n67_));
  XOR2x2_ASAP7_75t_R  g024(.A(new_n63_), .B(new_n56_), .Y(new_n68_));
  OR3x1_ASAP7_75t_R   g025(.A(new_n68_), .B(new_n55_), .C(G27), .Y(new_n69_));
  AO21x1_ASAP7_75t_R  g026(.A1(G426), .A2(G8), .B(new_n54_), .Y(new_n70_));
  OR2x4_ASAP7_75t_R   g027(.A(G11), .B(new_n70_), .Y(new_n71_));
  AND3x1_ASAP7_75t_R  g028(.A(new_n67_), .B(new_n69_), .C(new_n71_), .Y(new_n72_));
  INVx1_ASAP7_75t_R   g029(.A(G23), .Y(new_n73_));
  OA21x2_ASAP7_75t_R  g030(.A1(new_n63_), .A2(new_n46_), .B(G22), .Y(new_n74_));
  NAND2x1_ASAP7_75t_R g031(.A(new_n73_), .B(new_n74_), .Y(new_n75_));
  AO21x1_ASAP7_75t_R  g032(.A1(G426), .A2(G12), .B(new_n45_), .Y(new_n76_));
  OA21x2_ASAP7_75t_R  g033(.A1(G15), .A2(new_n76_), .B(new_n75_), .Y(new_n77_));
  AO21x1_ASAP7_75t_R  g034(.A1(G426), .A2(G16), .B(new_n44_), .Y(new_n78_));
  OA21x2_ASAP7_75t_R  g035(.A1(new_n63_), .A2(new_n59_), .B(G2), .Y(new_n79_));
  INVx1_ASAP7_75t_R   g036(.A(new_n79_), .Y(new_n80_));
  OR2x4_ASAP7_75t_R   g037(.A(G3), .B(new_n80_), .Y(new_n81_));
  OA21x2_ASAP7_75t_R  g038(.A1(G19), .A2(new_n78_), .B(new_n81_), .Y(new_n82_));
  INVx1_ASAP7_75t_R   g039(.A(G35), .Y(new_n83_));
  OA21x2_ASAP7_75t_R  g040(.A1(new_n63_), .A2(new_n51_), .B(G34), .Y(new_n84_));
  NAND2x1_ASAP7_75t_R g041(.A(new_n83_), .B(new_n84_), .Y(new_n85_));
  AO21x1_ASAP7_75t_R  g042(.A1(G426), .A2(G4), .B(new_n58_), .Y(new_n86_));
  OA21x2_ASAP7_75t_R  g043(.A1(G7), .A2(new_n86_), .B(new_n85_), .Y(new_n87_));
  AND3x1_ASAP7_75t_R  g044(.A(new_n82_), .B(new_n77_), .C(new_n87_), .Y(new_n88_));
  AND2x2_ASAP7_75t_R  g045(.A(new_n88_), .B(new_n72_), .Y(new_n89_));
  INVx1_ASAP7_75t_R   g046(.A(new_n89_), .Y(G427));
  AO21x1_ASAP7_75t_R  g047(.A1(G427), .A2(G19), .B(new_n78_), .Y(new_n91_));
  OA21x2_ASAP7_75t_R  g048(.A1(new_n89_), .A2(new_n73_), .B(new_n74_), .Y(new_n92_));
  INVx1_ASAP7_75t_R   g049(.A(new_n92_), .Y(new_n93_));
  NOR2x1_ASAP7_75t_R  g050(.A(G25), .B(new_n93_), .Y(new_n94_));
  AO21x1_ASAP7_75t_R  g051(.A1(G427), .A2(G15), .B(new_n76_), .Y(new_n95_));
  NOR2x1_ASAP7_75t_R  g052(.A(G17), .B(new_n95_), .Y(new_n96_));
  NOR2x1_ASAP7_75t_R  g053(.A(new_n94_), .B(new_n96_), .Y(new_n97_));
  OA21x2_ASAP7_75t_R  g054(.A1(G21), .A2(new_n91_), .B(new_n97_), .Y(new_n98_));
  AO21x1_ASAP7_75t_R  g055(.A1(G427), .A2(G7), .B(new_n86_), .Y(new_n99_));
  OR2x4_ASAP7_75t_R   g056(.A(G9), .B(new_n99_), .Y(new_n100_));
  AO21x1_ASAP7_75t_R  g057(.A1(G427), .A2(G3), .B(new_n80_), .Y(new_n101_));
  OA21x2_ASAP7_75t_R  g058(.A1(G5), .A2(new_n101_), .B(new_n100_), .Y(new_n102_));
  AO21x1_ASAP7_75t_R  g059(.A1(G427), .A2(G31), .B(new_n65_), .Y(new_n103_));
  AO21x1_ASAP7_75t_R  g060(.A1(new_n89_), .A2(new_n66_), .B(G33), .Y(new_n104_));
  OA21x2_ASAP7_75t_R  g061(.A1(new_n89_), .A2(new_n83_), .B(new_n84_), .Y(new_n105_));
  INVx1_ASAP7_75t_R   g062(.A(new_n105_), .Y(new_n106_));
  OR2x4_ASAP7_75t_R   g063(.A(G36), .B(new_n106_), .Y(new_n107_));
  OA21x2_ASAP7_75t_R  g064(.A1(new_n103_), .A2(new_n104_), .B(new_n107_), .Y(new_n108_));
  AO21x1_ASAP7_75t_R  g065(.A1(G427), .A2(G11), .B(new_n70_), .Y(new_n109_));
  INVx1_ASAP7_75t_R   g066(.A(new_n69_), .Y(new_n110_));
  OR3x1_ASAP7_75t_R   g067(.A(new_n68_), .B(new_n55_), .C(G29), .Y(new_n111_));
  AO21x1_ASAP7_75t_R  g068(.A1(G427), .A2(new_n69_), .B(new_n111_), .Y(new_n112_));
  AO21x1_ASAP7_75t_R  g069(.A1(new_n110_), .A2(new_n89_), .B(new_n112_), .Y(new_n113_));
  OA21x2_ASAP7_75t_R  g070(.A1(G13), .A2(new_n109_), .B(new_n113_), .Y(new_n114_));
  AND2x2_ASAP7_75t_R  g071(.A(new_n108_), .B(new_n114_), .Y(new_n115_));
  AND3x1_ASAP7_75t_R  g072(.A(new_n115_), .B(new_n98_), .C(new_n102_), .Y(new_n116_));
  INVx1_ASAP7_75t_R   g073(.A(new_n116_), .Y(G428));
  AOI21x1_ASAP7_75t_R g074(.A1(G5), .A2(G428), .B(new_n101_), .Y(new_n118_));
  AO21x1_ASAP7_75t_R  g075(.A1(G428), .A2(G21), .B(new_n91_), .Y(new_n119_));
  AO21x1_ASAP7_75t_R  g076(.A1(G428), .A2(G17), .B(new_n95_), .Y(new_n120_));
  AND2x2_ASAP7_75t_R  g077(.A(new_n119_), .B(new_n120_), .Y(new_n121_));
  AO21x1_ASAP7_75t_R  g078(.A1(G428), .A2(G13), .B(new_n109_), .Y(new_n122_));
  AO21x1_ASAP7_75t_R  g079(.A1(G428), .A2(G9), .B(new_n99_), .Y(new_n123_));
  AND2x2_ASAP7_75t_R  g080(.A(new_n122_), .B(new_n123_), .Y(new_n124_));
  AND2x2_ASAP7_75t_R  g081(.A(new_n121_), .B(new_n124_), .Y(new_n125_));
  AO21x1_ASAP7_75t_R  g082(.A1(G428), .A2(G36), .B(new_n106_), .Y(new_n126_));
  AO21x1_ASAP7_75t_R  g083(.A1(G426), .A2(G24), .B(new_n55_), .Y(new_n127_));
  AO21x1_ASAP7_75t_R  g084(.A1(G427), .A2(G27), .B(new_n127_), .Y(new_n128_));
  AO21x1_ASAP7_75t_R  g085(.A1(G428), .A2(G29), .B(new_n128_), .Y(new_n129_));
  AND2x2_ASAP7_75t_R  g086(.A(new_n126_), .B(new_n129_), .Y(new_n130_));
  AO21x1_ASAP7_75t_R  g087(.A1(G428), .A2(G25), .B(new_n93_), .Y(new_n131_));
  AO21x1_ASAP7_75t_R  g088(.A1(G428), .A2(G33), .B(new_n103_), .Y(new_n132_));
  AND3x1_ASAP7_75t_R  g089(.A(new_n130_), .B(new_n131_), .C(new_n132_), .Y(new_n133_));
  AOI21x1_ASAP7_75t_R g090(.A1(new_n125_), .A2(new_n133_), .B(new_n118_), .Y(G429));
  INVx1_ASAP7_75t_R   g091(.A(new_n125_), .Y(G430));
  INVx1_ASAP7_75t_R   g092(.A(new_n121_), .Y(new_n136_));
  INVx1_ASAP7_75t_R   g093(.A(new_n119_), .Y(new_n137_));
  NAND2x1_ASAP7_75t_R g094(.A(new_n120_), .B(new_n122_), .Y(new_n138_));
  OR3x1_ASAP7_75t_R   g095(.A(new_n138_), .B(new_n137_), .C(new_n131_), .Y(new_n139_));
  AND2x2_ASAP7_75t_R  g096(.A(new_n139_), .B(new_n124_), .Y(new_n140_));
  OAI21x1_ASAP7_75t_R g097(.A1(new_n136_), .A2(new_n129_), .B(new_n140_), .Y(G431));
  INVx1_ASAP7_75t_R   g098(.A(new_n132_), .Y(new_n142_));
  NAND2x1_ASAP7_75t_R g099(.A(new_n129_), .B(new_n142_), .Y(new_n143_));
  INVx1_ASAP7_75t_R   g100(.A(new_n122_), .Y(new_n144_));
  OA21x2_ASAP7_75t_R  g101(.A1(new_n144_), .A2(new_n120_), .B(new_n123_), .Y(new_n145_));
  AND2x2_ASAP7_75t_R  g102(.A(new_n139_), .B(new_n145_), .Y(new_n146_));
  OAI21x1_ASAP7_75t_R g103(.A1(new_n138_), .A2(new_n143_), .B(new_n146_), .Y(G432));
endmodule


