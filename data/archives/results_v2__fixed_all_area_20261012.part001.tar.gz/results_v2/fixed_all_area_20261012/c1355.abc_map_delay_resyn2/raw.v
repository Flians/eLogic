// Benchmark "/home/flynn/workplace/MIGBalance/results_v2/fixed_all_area_20261012/c1355.resyn2" written by ABC on Mon Oct 12 14:59:22 2026

module \/home/flynn/workplace/MIGBalance/results_v2/fixed_all_area_20261012/c1355.resyn2  ( 
    G1, G5, G9, G13, G33, G41, G17, G18, G19, G20, G21, G22, G23, G24, G4,
    G8, G12, G16, G36, G29, G30, G31, G32, G3, G7, G11, G15, G35, G25, G26,
    G27, G28, G2, G6, G10, G14, G34, G40, G39, G38, G37,
    G1324, G1344, G1325, G1326, G1327, G1328, G1329, G1330, G1343, G1331,
    G1332, G1333, G1334, G1335, G1336, G1337, G1338, G1339, G1340, G1341,
    G1342, G1345, G1346, G1347, G1348, G1349, G1350, G1351, G1352, G1353,
    G1354, G1355  );
  input  G1, G5, G9, G13, G33, G41, G17, G18, G19, G20, G21, G22, G23,
    G24, G4, G8, G12, G16, G36, G29, G30, G31, G32, G3, G7, G11, G15, G35,
    G25, G26, G27, G28, G2, G6, G10, G14, G34, G40, G39, G38, G37;
  output G1324, G1344, G1325, G1326, G1327, G1328, G1329, G1330, G1343, G1331,
    G1332, G1333, G1334, G1335, G1336, G1337, G1338, G1339, G1340, G1341,
    G1342, G1345, G1346, G1347, G1348, G1349, G1350, G1351, G1352, G1353,
    G1354, G1355;
  wire new_n74_, new_n75_, new_n76_, new_n77_, new_n78_, new_n79_, new_n80_,
    new_n81_, new_n82_, new_n83_, new_n84_, new_n85_, new_n86_, new_n87_,
    new_n88_, new_n89_, new_n90_, new_n91_, new_n92_, new_n93_, new_n94_,
    new_n95_, new_n96_, new_n97_, new_n98_, new_n99_, new_n100_, new_n101_,
    new_n102_, new_n103_, new_n104_, new_n105_, new_n106_, new_n107_,
    new_n108_, new_n109_, new_n110_, new_n111_, new_n112_, new_n113_,
    new_n114_, new_n115_, new_n116_, new_n117_, new_n118_, new_n119_,
    new_n120_, new_n121_, new_n122_, new_n123_, new_n124_, new_n125_,
    new_n126_, new_n127_, new_n128_, new_n129_, new_n130_, new_n131_,
    new_n132_, new_n133_, new_n134_, new_n135_, new_n136_, new_n137_,
    new_n138_, new_n139_, new_n140_, new_n141_, new_n142_, new_n143_,
    new_n144_, new_n145_, new_n146_, new_n147_, new_n148_, new_n149_,
    new_n150_, new_n151_, new_n152_, new_n153_, new_n154_, new_n155_,
    new_n156_, new_n157_, new_n158_, new_n159_, new_n160_, new_n161_,
    new_n162_, new_n163_, new_n164_, new_n165_, new_n166_, new_n167_,
    new_n169_, new_n170_, new_n171_, new_n172_, new_n173_, new_n174_,
    new_n175_, new_n176_, new_n177_, new_n178_, new_n179_, new_n181_,
    new_n182_, new_n183_, new_n185_, new_n186_, new_n187_, new_n188_,
    new_n190_, new_n191_, new_n192_, new_n194_, new_n195_, new_n196_,
    new_n197_, new_n198_, new_n199_, new_n201_, new_n202_, new_n203_,
    new_n205_, new_n206_, new_n207_, new_n209_, new_n210_, new_n211_,
    new_n212_, new_n213_, new_n215_, new_n216_, new_n217_, new_n219_,
    new_n220_, new_n221_, new_n222_, new_n223_, new_n225_, new_n226_,
    new_n227_, new_n229_, new_n230_, new_n231_, new_n233_, new_n234_,
    new_n235_, new_n237_, new_n238_, new_n239_, new_n240_, new_n241_,
    new_n243_, new_n244_, new_n245_, new_n247_, new_n248_, new_n249_,
    new_n251_, new_n252_, new_n253_, new_n255_, new_n256_, new_n257_,
    new_n259_, new_n260_, new_n261_, new_n263_, new_n264_, new_n265_,
    new_n267_, new_n268_, new_n269_, new_n271_, new_n272_, new_n273_,
    new_n275_, new_n276_, new_n277_, new_n279_, new_n280_, new_n281_,
    new_n282_, new_n283_, new_n285_, new_n286_, new_n287_, new_n289_,
    new_n290_, new_n291_, new_n293_, new_n294_, new_n295_, new_n297_,
    new_n298_, new_n299_, new_n300_, new_n301_, new_n303_, new_n304_,
    new_n305_, new_n307_, new_n308_, new_n309_, new_n311_, new_n312_,
    new_n313_;
  INVx1_ASAP7_75t_R   g000(.A(G1), .Y(new_n74_));
  XOR2x2_ASAP7_75t_R  g001(.A(G19), .B(G20), .Y(new_n75_));
  XOR2x2_ASAP7_75t_R  g002(.A(G17), .B(G18), .Y(new_n76_));
  XOR2x2_ASAP7_75t_R  g003(.A(new_n75_), .B(new_n76_), .Y(new_n77_));
  AND2x2_ASAP7_75t_R  g004(.A(G33), .B(G41), .Y(new_n78_));
  XOR2x2_ASAP7_75t_R  g005(.A(new_n77_), .B(new_n78_), .Y(new_n79_));
  XOR2x2_ASAP7_75t_R  g006(.A(G23), .B(G24), .Y(new_n80_));
  XOR2x2_ASAP7_75t_R  g007(.A(G21), .B(G22), .Y(new_n81_));
  XOR2x2_ASAP7_75t_R  g008(.A(new_n80_), .B(new_n81_), .Y(new_n82_));
  XOR2x2_ASAP7_75t_R  g009(.A(G9), .B(G13), .Y(new_n83_));
  XOR2x2_ASAP7_75t_R  g010(.A(G1), .B(G5), .Y(new_n84_));
  XNOR2x2_ASAP7_75t_R g011(.A(new_n83_), .B(new_n84_), .Y(new_n85_));
  XOR2x2_ASAP7_75t_R  g012(.A(new_n85_), .B(new_n82_), .Y(new_n86_));
  XOR2x2_ASAP7_75t_R  g013(.A(new_n86_), .B(new_n79_), .Y(new_n87_));
  INVx1_ASAP7_75t_R   g014(.A(new_n87_), .Y(new_n88_));
  AND2x2_ASAP7_75t_R  g015(.A(G41), .B(G36), .Y(new_n89_));
  XOR2x2_ASAP7_75t_R  g016(.A(new_n82_), .B(new_n89_), .Y(new_n90_));
  XNOR2x2_ASAP7_75t_R g017(.A(G31), .B(G32), .Y(new_n91_));
  XOR2x2_ASAP7_75t_R  g018(.A(G29), .B(G30), .Y(new_n92_));
  XOR2x2_ASAP7_75t_R  g019(.A(new_n91_), .B(new_n92_), .Y(new_n93_));
  XOR2x2_ASAP7_75t_R  g020(.A(G12), .B(G16), .Y(new_n94_));
  XOR2x2_ASAP7_75t_R  g021(.A(G4), .B(G8), .Y(new_n95_));
  XOR2x2_ASAP7_75t_R  g022(.A(new_n94_), .B(new_n95_), .Y(new_n96_));
  XOR2x2_ASAP7_75t_R  g023(.A(new_n93_), .B(new_n96_), .Y(new_n97_));
  XOR2x2_ASAP7_75t_R  g024(.A(new_n97_), .B(new_n90_), .Y(new_n98_));
  AND2x2_ASAP7_75t_R  g025(.A(G41), .B(G35), .Y(new_n99_));
  XOR2x2_ASAP7_75t_R  g026(.A(new_n77_), .B(new_n99_), .Y(new_n100_));
  XNOR2x2_ASAP7_75t_R g027(.A(G27), .B(G28), .Y(new_n101_));
  XOR2x2_ASAP7_75t_R  g028(.A(G25), .B(G26), .Y(new_n102_));
  XOR2x2_ASAP7_75t_R  g029(.A(new_n101_), .B(new_n102_), .Y(new_n103_));
  XOR2x2_ASAP7_75t_R  g030(.A(G11), .B(G15), .Y(new_n104_));
  XOR2x2_ASAP7_75t_R  g031(.A(G3), .B(G7), .Y(new_n105_));
  XOR2x2_ASAP7_75t_R  g032(.A(new_n104_), .B(new_n105_), .Y(new_n106_));
  XOR2x2_ASAP7_75t_R  g033(.A(new_n103_), .B(new_n106_), .Y(new_n107_));
  XOR2x2_ASAP7_75t_R  g034(.A(new_n107_), .B(new_n100_), .Y(new_n108_));
  XOR2x2_ASAP7_75t_R  g035(.A(new_n98_), .B(new_n108_), .Y(new_n109_));
  NAND2x1_ASAP7_75t_R g036(.A(G41), .B(G34), .Y(new_n110_));
  XOR2x2_ASAP7_75t_R  g037(.A(new_n93_), .B(new_n110_), .Y(new_n111_));
  XOR2x2_ASAP7_75t_R  g038(.A(G10), .B(G14), .Y(new_n112_));
  XOR2x2_ASAP7_75t_R  g039(.A(G2), .B(G6), .Y(new_n113_));
  XOR2x2_ASAP7_75t_R  g040(.A(new_n112_), .B(new_n113_), .Y(new_n114_));
  XOR2x2_ASAP7_75t_R  g041(.A(new_n103_), .B(new_n114_), .Y(new_n115_));
  XOR2x2_ASAP7_75t_R  g042(.A(new_n115_), .B(new_n111_), .Y(new_n116_));
  XOR2x2_ASAP7_75t_R  g043(.A(new_n87_), .B(new_n116_), .Y(new_n117_));
  NAND2x1_ASAP7_75t_R g044(.A(new_n98_), .B(new_n108_), .Y(new_n118_));
  INVx1_ASAP7_75t_R   g045(.A(new_n116_), .Y(new_n119_));
  OAI21x1_ASAP7_75t_R g046(.A1(new_n88_), .A2(new_n119_), .B(new_n118_), .Y(new_n120_));
  OA21x2_ASAP7_75t_R  g047(.A1(new_n109_), .A2(new_n117_), .B(new_n120_), .Y(new_n121_));
  AND2x2_ASAP7_75t_R  g048(.A(G41), .B(G40), .Y(new_n122_));
  XOR2x2_ASAP7_75t_R  g049(.A(G8), .B(G7), .Y(new_n123_));
  XOR2x2_ASAP7_75t_R  g050(.A(G5), .B(G6), .Y(new_n124_));
  XOR2x2_ASAP7_75t_R  g051(.A(new_n123_), .B(new_n124_), .Y(new_n125_));
  XOR2x2_ASAP7_75t_R  g052(.A(new_n125_), .B(new_n122_), .Y(new_n126_));
  XNOR2x2_ASAP7_75t_R g053(.A(G32), .B(G28), .Y(new_n127_));
  XOR2x2_ASAP7_75t_R  g054(.A(G20), .B(G24), .Y(new_n128_));
  XOR2x2_ASAP7_75t_R  g055(.A(new_n127_), .B(new_n128_), .Y(new_n129_));
  XOR2x2_ASAP7_75t_R  g056(.A(G16), .B(G15), .Y(new_n130_));
  XOR2x2_ASAP7_75t_R  g057(.A(G13), .B(G14), .Y(new_n131_));
  XOR2x2_ASAP7_75t_R  g058(.A(new_n130_), .B(new_n131_), .Y(new_n132_));
  XOR2x2_ASAP7_75t_R  g059(.A(new_n129_), .B(new_n132_), .Y(new_n133_));
  XNOR2x2_ASAP7_75t_R g060(.A(new_n126_), .B(new_n133_), .Y(new_n134_));
  INVx1_ASAP7_75t_R   g061(.A(new_n134_), .Y(new_n135_));
  AND2x2_ASAP7_75t_R  g062(.A(G41), .B(G38), .Y(new_n136_));
  XOR2x2_ASAP7_75t_R  g063(.A(new_n132_), .B(new_n136_), .Y(new_n137_));
  XNOR2x2_ASAP7_75t_R g064(.A(G12), .B(G11), .Y(new_n138_));
  XOR2x2_ASAP7_75t_R  g065(.A(G9), .B(G10), .Y(new_n139_));
  XOR2x2_ASAP7_75t_R  g066(.A(new_n138_), .B(new_n139_), .Y(new_n140_));
  XOR2x2_ASAP7_75t_R  g067(.A(G30), .B(G26), .Y(new_n141_));
  XOR2x2_ASAP7_75t_R  g068(.A(G18), .B(G22), .Y(new_n142_));
  XOR2x2_ASAP7_75t_R  g069(.A(new_n141_), .B(new_n142_), .Y(new_n143_));
  XOR2x2_ASAP7_75t_R  g070(.A(new_n140_), .B(new_n143_), .Y(new_n144_));
  XOR2x2_ASAP7_75t_R  g071(.A(new_n144_), .B(new_n137_), .Y(new_n145_));
  AND2x2_ASAP7_75t_R  g072(.A(G41), .B(G37), .Y(new_n146_));
  XOR2x2_ASAP7_75t_R  g073(.A(new_n125_), .B(new_n146_), .Y(new_n147_));
  XNOR2x2_ASAP7_75t_R g074(.A(G4), .B(G3), .Y(new_n148_));
  XOR2x2_ASAP7_75t_R  g075(.A(G1), .B(G2), .Y(new_n149_));
  XOR2x2_ASAP7_75t_R  g076(.A(new_n148_), .B(new_n149_), .Y(new_n150_));
  XOR2x2_ASAP7_75t_R  g077(.A(G29), .B(G25), .Y(new_n151_));
  XOR2x2_ASAP7_75t_R  g078(.A(G17), .B(G21), .Y(new_n152_));
  XOR2x2_ASAP7_75t_R  g079(.A(new_n151_), .B(new_n152_), .Y(new_n153_));
  XOR2x2_ASAP7_75t_R  g080(.A(new_n150_), .B(new_n153_), .Y(new_n154_));
  XOR2x2_ASAP7_75t_R  g081(.A(new_n154_), .B(new_n147_), .Y(new_n155_));
  INVx1_ASAP7_75t_R   g082(.A(new_n155_), .Y(new_n156_));
  NAND2x1_ASAP7_75t_R g083(.A(G41), .B(G39), .Y(new_n157_));
  XOR2x2_ASAP7_75t_R  g084(.A(new_n150_), .B(new_n157_), .Y(new_n158_));
  XNOR2x2_ASAP7_75t_R g085(.A(G31), .B(G27), .Y(new_n159_));
  XOR2x2_ASAP7_75t_R  g086(.A(G19), .B(G23), .Y(new_n160_));
  XOR2x2_ASAP7_75t_R  g087(.A(new_n159_), .B(new_n160_), .Y(new_n161_));
  XOR2x2_ASAP7_75t_R  g088(.A(new_n161_), .B(new_n140_), .Y(new_n162_));
  XOR2x2_ASAP7_75t_R  g089(.A(new_n162_), .B(new_n158_), .Y(new_n163_));
  AND3x1_ASAP7_75t_R  g090(.A(new_n156_), .B(new_n163_), .C(new_n145_), .Y(new_n164_));
  AND3x1_ASAP7_75t_R  g091(.A(new_n121_), .B(new_n135_), .C(new_n164_), .Y(new_n165_));
  AOI21x1_ASAP7_75t_R g092(.A1(new_n88_), .A2(new_n165_), .B(new_n74_), .Y(new_n166_));
  AND3x1_ASAP7_75t_R  g093(.A(new_n165_), .B(new_n74_), .C(new_n88_), .Y(new_n167_));
  NOR2x1_ASAP7_75t_R  g094(.A(new_n166_), .B(new_n167_), .Y(G1324));
  INVx1_ASAP7_75t_R   g095(.A(G21), .Y(new_n169_));
  INVx1_ASAP7_75t_R   g096(.A(new_n98_), .Y(new_n170_));
  XOR2x2_ASAP7_75t_R  g097(.A(new_n134_), .B(new_n163_), .Y(new_n171_));
  XOR2x2_ASAP7_75t_R  g098(.A(new_n145_), .B(new_n155_), .Y(new_n172_));
  NAND2x1_ASAP7_75t_R g099(.A(new_n145_), .B(new_n155_), .Y(new_n173_));
  OAI21x1_ASAP7_75t_R g100(.A1(new_n134_), .A2(new_n163_), .B(new_n173_), .Y(new_n174_));
  OA21x2_ASAP7_75t_R  g101(.A1(new_n171_), .A2(new_n172_), .B(new_n174_), .Y(new_n175_));
  AND3x1_ASAP7_75t_R  g102(.A(new_n88_), .B(new_n108_), .C(new_n116_), .Y(new_n176_));
  AND3x1_ASAP7_75t_R  g103(.A(new_n175_), .B(new_n170_), .C(new_n176_), .Y(new_n177_));
  AOI21x1_ASAP7_75t_R g104(.A1(new_n156_), .A2(new_n177_), .B(new_n169_), .Y(new_n178_));
  AND3x1_ASAP7_75t_R  g105(.A(new_n177_), .B(new_n169_), .C(new_n156_), .Y(new_n179_));
  NOR2x1_ASAP7_75t_R  g106(.A(new_n178_), .B(new_n179_), .Y(G1344));
  INVx1_ASAP7_75t_R   g107(.A(G2), .Y(new_n181_));
  AOI21x1_ASAP7_75t_R g108(.A1(new_n119_), .A2(new_n165_), .B(new_n181_), .Y(new_n182_));
  AND3x1_ASAP7_75t_R  g109(.A(new_n165_), .B(new_n181_), .C(new_n119_), .Y(new_n183_));
  NOR2x1_ASAP7_75t_R  g110(.A(new_n182_), .B(new_n183_), .Y(G1325));
  INVx1_ASAP7_75t_R   g111(.A(G3), .Y(new_n185_));
  INVx1_ASAP7_75t_R   g112(.A(new_n108_), .Y(new_n186_));
  AOI21x1_ASAP7_75t_R g113(.A1(new_n186_), .A2(new_n165_), .B(new_n185_), .Y(new_n187_));
  AND3x1_ASAP7_75t_R  g114(.A(new_n165_), .B(new_n185_), .C(new_n186_), .Y(new_n188_));
  NOR2x1_ASAP7_75t_R  g115(.A(new_n187_), .B(new_n188_), .Y(G1326));
  INVx1_ASAP7_75t_R   g116(.A(G4), .Y(new_n190_));
  AOI21x1_ASAP7_75t_R g117(.A1(new_n170_), .A2(new_n165_), .B(new_n190_), .Y(new_n191_));
  AND3x1_ASAP7_75t_R  g118(.A(new_n165_), .B(new_n190_), .C(new_n170_), .Y(new_n192_));
  NOR2x1_ASAP7_75t_R  g119(.A(new_n191_), .B(new_n192_), .Y(G1327));
  INVx1_ASAP7_75t_R   g120(.A(G5), .Y(new_n194_));
  INVx1_ASAP7_75t_R   g121(.A(new_n145_), .Y(new_n195_));
  NOR3x1_ASAP7_75t_R  g122(.A(new_n195_), .B(new_n163_), .C(new_n155_), .Y(new_n196_));
  AND3x1_ASAP7_75t_R  g123(.A(new_n121_), .B(new_n134_), .C(new_n196_), .Y(new_n197_));
  AOI21x1_ASAP7_75t_R g124(.A1(new_n88_), .A2(new_n197_), .B(new_n194_), .Y(new_n198_));
  AND3x1_ASAP7_75t_R  g125(.A(new_n197_), .B(new_n194_), .C(new_n88_), .Y(new_n199_));
  NOR2x1_ASAP7_75t_R  g126(.A(new_n198_), .B(new_n199_), .Y(G1328));
  INVx1_ASAP7_75t_R   g127(.A(G6), .Y(new_n201_));
  AOI21x1_ASAP7_75t_R g128(.A1(new_n119_), .A2(new_n197_), .B(new_n201_), .Y(new_n202_));
  AND3x1_ASAP7_75t_R  g129(.A(new_n197_), .B(new_n201_), .C(new_n119_), .Y(new_n203_));
  NOR2x1_ASAP7_75t_R  g130(.A(new_n202_), .B(new_n203_), .Y(G1329));
  INVx1_ASAP7_75t_R   g131(.A(G7), .Y(new_n205_));
  AOI21x1_ASAP7_75t_R g132(.A1(new_n186_), .A2(new_n197_), .B(new_n205_), .Y(new_n206_));
  AND3x1_ASAP7_75t_R  g133(.A(new_n197_), .B(new_n205_), .C(new_n186_), .Y(new_n207_));
  NOR2x1_ASAP7_75t_R  g134(.A(new_n206_), .B(new_n207_), .Y(G1330));
  INVx1_ASAP7_75t_R   g135(.A(G20), .Y(new_n209_));
  AND3x1_ASAP7_75t_R  g136(.A(new_n88_), .B(new_n186_), .C(new_n116_), .Y(new_n210_));
  AND3x1_ASAP7_75t_R  g137(.A(new_n175_), .B(new_n98_), .C(new_n210_), .Y(new_n211_));
  AOI21x1_ASAP7_75t_R g138(.A1(new_n134_), .A2(new_n211_), .B(new_n209_), .Y(new_n212_));
  AND3x1_ASAP7_75t_R  g139(.A(new_n211_), .B(new_n209_), .C(new_n134_), .Y(new_n213_));
  NOR2x1_ASAP7_75t_R  g140(.A(new_n212_), .B(new_n213_), .Y(G1343));
  INVx1_ASAP7_75t_R   g141(.A(G8), .Y(new_n215_));
  AOI21x1_ASAP7_75t_R g142(.A1(new_n170_), .A2(new_n197_), .B(new_n215_), .Y(new_n216_));
  AND3x1_ASAP7_75t_R  g143(.A(new_n197_), .B(new_n215_), .C(new_n170_), .Y(new_n217_));
  NOR2x1_ASAP7_75t_R  g144(.A(new_n216_), .B(new_n217_), .Y(G1331));
  INVx1_ASAP7_75t_R   g145(.A(G9), .Y(new_n219_));
  AND3x1_ASAP7_75t_R  g146(.A(new_n195_), .B(new_n163_), .C(new_n155_), .Y(new_n220_));
  AND3x1_ASAP7_75t_R  g147(.A(new_n121_), .B(new_n135_), .C(new_n220_), .Y(new_n221_));
  AOI21x1_ASAP7_75t_R g148(.A1(new_n88_), .A2(new_n221_), .B(new_n219_), .Y(new_n222_));
  AND3x1_ASAP7_75t_R  g149(.A(new_n221_), .B(new_n219_), .C(new_n88_), .Y(new_n223_));
  NOR2x1_ASAP7_75t_R  g150(.A(new_n222_), .B(new_n223_), .Y(G1332));
  INVx1_ASAP7_75t_R   g151(.A(G10), .Y(new_n225_));
  AOI21x1_ASAP7_75t_R g152(.A1(new_n119_), .A2(new_n221_), .B(new_n225_), .Y(new_n226_));
  AND3x1_ASAP7_75t_R  g153(.A(new_n221_), .B(new_n225_), .C(new_n119_), .Y(new_n227_));
  NOR2x1_ASAP7_75t_R  g154(.A(new_n226_), .B(new_n227_), .Y(G1333));
  INVx1_ASAP7_75t_R   g155(.A(G11), .Y(new_n229_));
  AOI21x1_ASAP7_75t_R g156(.A1(new_n186_), .A2(new_n221_), .B(new_n229_), .Y(new_n230_));
  AND3x1_ASAP7_75t_R  g157(.A(new_n221_), .B(new_n229_), .C(new_n186_), .Y(new_n231_));
  NOR2x1_ASAP7_75t_R  g158(.A(new_n230_), .B(new_n231_), .Y(G1334));
  INVx1_ASAP7_75t_R   g159(.A(G12), .Y(new_n233_));
  AOI21x1_ASAP7_75t_R g160(.A1(new_n170_), .A2(new_n221_), .B(new_n233_), .Y(new_n234_));
  AND3x1_ASAP7_75t_R  g161(.A(new_n221_), .B(new_n233_), .C(new_n170_), .Y(new_n235_));
  NOR2x1_ASAP7_75t_R  g162(.A(new_n234_), .B(new_n235_), .Y(G1335));
  INVx1_ASAP7_75t_R   g163(.A(G13), .Y(new_n237_));
  NOR3x1_ASAP7_75t_R  g164(.A(new_n156_), .B(new_n163_), .C(new_n145_), .Y(new_n238_));
  AND3x1_ASAP7_75t_R  g165(.A(new_n121_), .B(new_n134_), .C(new_n238_), .Y(new_n239_));
  AOI21x1_ASAP7_75t_R g166(.A1(new_n88_), .A2(new_n239_), .B(new_n237_), .Y(new_n240_));
  AND3x1_ASAP7_75t_R  g167(.A(new_n239_), .B(new_n237_), .C(new_n88_), .Y(new_n241_));
  NOR2x1_ASAP7_75t_R  g168(.A(new_n240_), .B(new_n241_), .Y(G1336));
  INVx1_ASAP7_75t_R   g169(.A(G14), .Y(new_n243_));
  AOI21x1_ASAP7_75t_R g170(.A1(new_n119_), .A2(new_n239_), .B(new_n243_), .Y(new_n244_));
  AND3x1_ASAP7_75t_R  g171(.A(new_n239_), .B(new_n243_), .C(new_n119_), .Y(new_n245_));
  NOR2x1_ASAP7_75t_R  g172(.A(new_n244_), .B(new_n245_), .Y(G1337));
  INVx1_ASAP7_75t_R   g173(.A(G15), .Y(new_n247_));
  AOI21x1_ASAP7_75t_R g174(.A1(new_n186_), .A2(new_n239_), .B(new_n247_), .Y(new_n248_));
  AND3x1_ASAP7_75t_R  g175(.A(new_n239_), .B(new_n247_), .C(new_n186_), .Y(new_n249_));
  NOR2x1_ASAP7_75t_R  g176(.A(new_n248_), .B(new_n249_), .Y(G1338));
  INVx1_ASAP7_75t_R   g177(.A(G16), .Y(new_n251_));
  AOI21x1_ASAP7_75t_R g178(.A1(new_n170_), .A2(new_n239_), .B(new_n251_), .Y(new_n252_));
  AND3x1_ASAP7_75t_R  g179(.A(new_n239_), .B(new_n251_), .C(new_n170_), .Y(new_n253_));
  NOR2x1_ASAP7_75t_R  g180(.A(new_n252_), .B(new_n253_), .Y(G1339));
  INVx1_ASAP7_75t_R   g181(.A(G17), .Y(new_n255_));
  AOI21x1_ASAP7_75t_R g182(.A1(new_n156_), .A2(new_n211_), .B(new_n255_), .Y(new_n256_));
  AND3x1_ASAP7_75t_R  g183(.A(new_n211_), .B(new_n255_), .C(new_n156_), .Y(new_n257_));
  NOR2x1_ASAP7_75t_R  g184(.A(new_n256_), .B(new_n257_), .Y(G1340));
  INVx1_ASAP7_75t_R   g185(.A(G18), .Y(new_n259_));
  AOI21x1_ASAP7_75t_R g186(.A1(new_n195_), .A2(new_n211_), .B(new_n259_), .Y(new_n260_));
  AND3x1_ASAP7_75t_R  g187(.A(new_n211_), .B(new_n259_), .C(new_n195_), .Y(new_n261_));
  NOR2x1_ASAP7_75t_R  g188(.A(new_n260_), .B(new_n261_), .Y(G1341));
  INVx1_ASAP7_75t_R   g189(.A(G19), .Y(new_n263_));
  AOI21x1_ASAP7_75t_R g190(.A1(new_n163_), .A2(new_n211_), .B(new_n263_), .Y(new_n264_));
  AND3x1_ASAP7_75t_R  g191(.A(new_n211_), .B(new_n263_), .C(new_n163_), .Y(new_n265_));
  NOR2x1_ASAP7_75t_R  g192(.A(new_n264_), .B(new_n265_), .Y(G1342));
  INVx1_ASAP7_75t_R   g193(.A(G22), .Y(new_n267_));
  AOI21x1_ASAP7_75t_R g194(.A1(new_n195_), .A2(new_n177_), .B(new_n267_), .Y(new_n268_));
  AND3x1_ASAP7_75t_R  g195(.A(new_n177_), .B(new_n267_), .C(new_n195_), .Y(new_n269_));
  NOR2x1_ASAP7_75t_R  g196(.A(new_n268_), .B(new_n269_), .Y(G1345));
  INVx1_ASAP7_75t_R   g197(.A(G23), .Y(new_n271_));
  AOI21x1_ASAP7_75t_R g198(.A1(new_n163_), .A2(new_n177_), .B(new_n271_), .Y(new_n272_));
  AND3x1_ASAP7_75t_R  g199(.A(new_n177_), .B(new_n271_), .C(new_n163_), .Y(new_n273_));
  NOR2x1_ASAP7_75t_R  g200(.A(new_n272_), .B(new_n273_), .Y(G1346));
  INVx1_ASAP7_75t_R   g201(.A(G24), .Y(new_n275_));
  AOI21x1_ASAP7_75t_R g202(.A1(new_n134_), .A2(new_n177_), .B(new_n275_), .Y(new_n276_));
  AND3x1_ASAP7_75t_R  g203(.A(new_n177_), .B(new_n275_), .C(new_n134_), .Y(new_n277_));
  NOR2x1_ASAP7_75t_R  g204(.A(new_n276_), .B(new_n277_), .Y(G1347));
  INVx1_ASAP7_75t_R   g205(.A(G25), .Y(new_n279_));
  AND3x1_ASAP7_75t_R  g206(.A(new_n119_), .B(new_n186_), .C(new_n87_), .Y(new_n280_));
  AND3x1_ASAP7_75t_R  g207(.A(new_n175_), .B(new_n98_), .C(new_n280_), .Y(new_n281_));
  AOI21x1_ASAP7_75t_R g208(.A1(new_n156_), .A2(new_n281_), .B(new_n279_), .Y(new_n282_));
  AND3x1_ASAP7_75t_R  g209(.A(new_n281_), .B(new_n279_), .C(new_n156_), .Y(new_n283_));
  NOR2x1_ASAP7_75t_R  g210(.A(new_n282_), .B(new_n283_), .Y(G1348));
  INVx1_ASAP7_75t_R   g211(.A(G26), .Y(new_n285_));
  AOI21x1_ASAP7_75t_R g212(.A1(new_n195_), .A2(new_n281_), .B(new_n285_), .Y(new_n286_));
  AND3x1_ASAP7_75t_R  g213(.A(new_n281_), .B(new_n285_), .C(new_n195_), .Y(new_n287_));
  NOR2x1_ASAP7_75t_R  g214(.A(new_n286_), .B(new_n287_), .Y(G1349));
  INVx1_ASAP7_75t_R   g215(.A(G27), .Y(new_n289_));
  AOI21x1_ASAP7_75t_R g216(.A1(new_n163_), .A2(new_n281_), .B(new_n289_), .Y(new_n290_));
  AND3x1_ASAP7_75t_R  g217(.A(new_n281_), .B(new_n289_), .C(new_n163_), .Y(new_n291_));
  NOR2x1_ASAP7_75t_R  g218(.A(new_n290_), .B(new_n291_), .Y(G1350));
  INVx1_ASAP7_75t_R   g219(.A(G28), .Y(new_n293_));
  AOI21x1_ASAP7_75t_R g220(.A1(new_n134_), .A2(new_n281_), .B(new_n293_), .Y(new_n294_));
  AND3x1_ASAP7_75t_R  g221(.A(new_n281_), .B(new_n293_), .C(new_n134_), .Y(new_n295_));
  NOR2x1_ASAP7_75t_R  g222(.A(new_n294_), .B(new_n295_), .Y(G1351));
  INVx1_ASAP7_75t_R   g223(.A(G29), .Y(new_n297_));
  AND3x1_ASAP7_75t_R  g224(.A(new_n119_), .B(new_n87_), .C(new_n108_), .Y(new_n298_));
  AND3x1_ASAP7_75t_R  g225(.A(new_n175_), .B(new_n170_), .C(new_n298_), .Y(new_n299_));
  AOI21x1_ASAP7_75t_R g226(.A1(new_n156_), .A2(new_n299_), .B(new_n297_), .Y(new_n300_));
  AND3x1_ASAP7_75t_R  g227(.A(new_n299_), .B(new_n297_), .C(new_n156_), .Y(new_n301_));
  NOR2x1_ASAP7_75t_R  g228(.A(new_n300_), .B(new_n301_), .Y(G1352));
  INVx1_ASAP7_75t_R   g229(.A(G30), .Y(new_n303_));
  AOI21x1_ASAP7_75t_R g230(.A1(new_n195_), .A2(new_n299_), .B(new_n303_), .Y(new_n304_));
  AND3x1_ASAP7_75t_R  g231(.A(new_n299_), .B(new_n303_), .C(new_n195_), .Y(new_n305_));
  NOR2x1_ASAP7_75t_R  g232(.A(new_n304_), .B(new_n305_), .Y(G1353));
  INVx1_ASAP7_75t_R   g233(.A(G31), .Y(new_n307_));
  AOI21x1_ASAP7_75t_R g234(.A1(new_n163_), .A2(new_n299_), .B(new_n307_), .Y(new_n308_));
  AND3x1_ASAP7_75t_R  g235(.A(new_n299_), .B(new_n307_), .C(new_n163_), .Y(new_n309_));
  NOR2x1_ASAP7_75t_R  g236(.A(new_n308_), .B(new_n309_), .Y(G1354));
  INVx1_ASAP7_75t_R   g237(.A(G32), .Y(new_n311_));
  AOI21x1_ASAP7_75t_R g238(.A1(new_n134_), .A2(new_n299_), .B(new_n311_), .Y(new_n312_));
  AND3x1_ASAP7_75t_R  g239(.A(new_n299_), .B(new_n311_), .C(new_n134_), .Y(new_n313_));
  NOR2x1_ASAP7_75t_R  g240(.A(new_n312_), .B(new_n313_), .Y(G1355));
endmodule


