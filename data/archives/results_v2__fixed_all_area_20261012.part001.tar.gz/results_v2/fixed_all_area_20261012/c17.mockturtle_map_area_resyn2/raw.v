module mapped( G1 , G3 , G2 , G4 , G5 , G16 , G17 );
  input G1 , G3 , G2 , G4 , G5 ;
  output G16 , G17 ;
  wire n7 , n8 , n9 ;
  AND2x2_ASAP7_75t_R  g0( .A (G3), .B (G4), .Y (n7) );
  INVx1_ASAP7_75t_R   g1( .A (n7), .Y (n8) );
  AND2x2_ASAP7_75t_R  g2( .A (n8), .B (G2), .Y (n9) );
  AO21x1_ASAP7_75t_R  g3( .A1 (G1), .A2 (G3), .B (n9), .Y (G16) );
  AO21x1_ASAP7_75t_R  g4( .A1 (n8), .A2 (G5), .B (n9), .Y (G17) );
endmodule
