// Benchmark "/home/flynn/workplace/MIGBalance/results_v2/fixed_all_area_20261012/c880.resyn2" written by ABC on Mon Oct 12 14:59:16 2026

module \/home/flynn/workplace/MIGBalance/results_v2/fixed_all_area_20261012/c880.resyn2  ( 
    G8, G16, G6, G17, G7, G18, G19, G4, G3, G2, G1, G5, G11, G23, G20, G21,
    G9, G10, G12, G15, G22, G32, G24, G25, G26, G27, G28, G29, G30, G31,
    G33, G41, G42, G43, G44, G45, G46, G47, G48, G49, G13, G14, G55, G59,
    G54, G60, G39, G40, G52, G53, G50, G51, G58, G35, G37, G36, G56, G57,
    G34, G38,
    G855, G856, G857, G858, G859, G860, G861, G862, G863, G864, G865, G866,
    G867, G868, G869, G870, G871, G872, G873, G874, G875, G876, G877, G878,
    G879, G880  );
  input  G8, G16, G6, G17, G7, G18, G19, G4, G3, G2, G1, G5, G11, G23,
    G20, G21, G9, G10, G12, G15, G22, G32, G24, G25, G26, G27, G28, G29,
    G30, G31, G33, G41, G42, G43, G44, G45, G46, G47, G48, G49, G13, G14,
    G55, G59, G54, G60, G39, G40, G52, G53, G50, G51, G58, G35, G37, G36,
    G56, G57, G34, G38;
  output G855, G856, G857, G858, G859, G860, G861, G862, G863, G864, G865,
    G866, G867, G868, G869, G870, G871, G872, G873, G874, G875, G876, G877,
    G878, G879, G880;
  wire new_n87_, new_n88_, new_n89_, new_n92_, new_n95_, new_n96_, new_n97_,
    new_n99_, new_n106_, new_n108_, new_n110_, new_n113_, new_n114_,
    new_n115_, new_n116_, new_n117_, new_n118_, new_n119_, new_n120_,
    new_n121_, new_n123_, new_n124_, new_n125_, new_n126_, new_n127_,
    new_n128_, new_n129_, new_n130_, new_n132_, new_n133_, new_n134_,
    new_n135_, new_n136_, new_n137_, new_n138_, new_n139_, new_n140_,
    new_n141_, new_n142_, new_n143_, new_n144_, new_n145_, new_n146_,
    new_n147_, new_n148_, new_n149_, new_n150_, new_n151_, new_n152_,
    new_n153_, new_n154_, new_n155_, new_n156_, new_n157_, new_n158_,
    new_n159_, new_n160_, new_n161_, new_n162_, new_n163_, new_n164_,
    new_n165_, new_n166_, new_n167_, new_n168_, new_n169_, new_n170_,
    new_n172_, new_n173_, new_n174_, new_n175_, new_n176_, new_n177_,
    new_n178_, new_n179_, new_n180_, new_n181_, new_n182_, new_n183_,
    new_n184_, new_n185_, new_n186_, new_n187_, new_n188_, new_n189_,
    new_n190_, new_n191_, new_n192_, new_n193_, new_n194_, new_n195_,
    new_n196_, new_n197_, new_n198_, new_n199_, new_n200_, new_n201_,
    new_n202_, new_n203_, new_n204_, new_n206_, new_n207_, new_n208_,
    new_n209_, new_n210_, new_n211_, new_n212_, new_n213_, new_n214_,
    new_n215_, new_n216_, new_n217_, new_n218_, new_n219_, new_n220_,
    new_n221_, new_n223_, new_n224_, new_n225_, new_n226_, new_n227_,
    new_n228_, new_n229_, new_n230_, new_n231_, new_n232_, new_n234_,
    new_n235_, new_n236_, new_n237_, new_n238_, new_n239_, new_n240_,
    new_n241_, new_n242_, new_n243_, new_n244_, new_n245_, new_n246_,
    new_n247_, new_n248_, new_n249_, new_n250_, new_n251_, new_n252_,
    new_n253_, new_n254_, new_n255_, new_n256_, new_n257_, new_n258_,
    new_n259_, new_n260_, new_n261_, new_n262_, new_n263_, new_n264_,
    new_n265_, new_n266_, new_n267_, new_n268_, new_n269_, new_n270_,
    new_n271_, new_n272_, new_n273_, new_n274_, new_n275_, new_n276_,
    new_n278_, new_n279_, new_n280_, new_n281_, new_n282_, new_n283_,
    new_n284_, new_n285_, new_n286_, new_n287_, new_n289_, new_n290_,
    new_n291_, new_n292_, new_n293_, new_n294_, new_n295_, new_n296_,
    new_n297_, new_n298_, new_n299_, new_n300_, new_n301_, new_n303_,
    new_n304_, new_n305_, new_n306_, new_n307_, new_n308_, new_n309_,
    new_n310_, new_n311_, new_n312_, new_n313_, new_n314_, new_n316_,
    new_n317_, new_n318_, new_n319_, new_n320_, new_n321_, new_n322_,
    new_n323_, new_n324_, new_n325_, new_n326_, new_n327_;
  INVx1_ASAP7_75t_R   g000(.A(G8), .Y(new_n87_));
  INVx1_ASAP7_75t_R   g001(.A(G16), .Y(new_n88_));
  INVx1_ASAP7_75t_R   g002(.A(G6), .Y(new_n89_));
  OR3x1_ASAP7_75t_R   g003(.A(new_n87_), .B(new_n88_), .C(new_n89_), .Y(G855));
  NAND3x1_ASAP7_75t_R g004(.A(G6), .B(G7), .C(G17), .Y(G856));
  AND3x1_ASAP7_75t_R  g005(.A(G8), .B(G6), .C(G7), .Y(new_n92_));
  INVx1_ASAP7_75t_R   g006(.A(new_n92_), .Y(G857));
  NAND2x1_ASAP7_75t_R g007(.A(G18), .B(G19), .Y(G858));
  AND2x2_ASAP7_75t_R  g008(.A(G4), .B(G3), .Y(new_n95_));
  NAND2x1_ASAP7_75t_R g009(.A(G2), .B(G1), .Y(new_n96_));
  INVx1_ASAP7_75t_R   g010(.A(new_n96_), .Y(new_n97_));
  NAND2x1_ASAP7_75t_R g011(.A(new_n95_), .B(new_n97_), .Y(G859));
  AND2x2_ASAP7_75t_R  g012(.A(G1), .B(G5), .Y(new_n99_));
  AND3x1_ASAP7_75t_R  g013(.A(G857), .B(new_n95_), .C(new_n99_), .Y(G860));
  AND3x1_ASAP7_75t_R  g014(.A(G16), .B(G17), .C(G11), .Y(G861));
  AND3x1_ASAP7_75t_R  g015(.A(G17), .B(G7), .C(G11), .Y(G862));
  AND3x1_ASAP7_75t_R  g016(.A(G8), .B(G7), .C(G11), .Y(G863));
  OAI21x1_ASAP7_75t_R g017(.A1(G20), .A2(G21), .B(G23), .Y(G864));
  AND3x1_ASAP7_75t_R  g018(.A(new_n92_), .B(new_n95_), .C(new_n99_), .Y(G865));
  AND3x1_ASAP7_75t_R  g019(.A(G1), .B(G5), .C(G9), .Y(new_n106_));
  INVx1_ASAP7_75t_R   g020(.A(new_n106_), .Y(G866));
  AND3x1_ASAP7_75t_R  g021(.A(new_n97_), .B(G3), .C(G10), .Y(new_n108_));
  NAND3x1_ASAP7_75t_R g022(.A(new_n108_), .B(G12), .C(G6), .Y(G867));
  AND3x1_ASAP7_75t_R  g023(.A(new_n108_), .B(G11), .C(G12), .Y(new_n110_));
  NAND2x1_ASAP7_75t_R g024(.A(G15), .B(new_n110_), .Y(G868));
  OAI21x1_ASAP7_75t_R g025(.A1(G20), .A2(G21), .B(G22), .Y(G869));
  INVx1_ASAP7_75t_R   g026(.A(G32), .Y(new_n113_));
  XOR2x2_ASAP7_75t_R  g027(.A(G24), .B(G25), .Y(new_n114_));
  XOR2x2_ASAP7_75t_R  g028(.A(new_n114_), .B(new_n113_), .Y(new_n115_));
  XOR2x2_ASAP7_75t_R  g029(.A(G30), .B(G31), .Y(new_n116_));
  XOR2x2_ASAP7_75t_R  g030(.A(new_n115_), .B(new_n116_), .Y(new_n117_));
  XOR2x2_ASAP7_75t_R  g031(.A(G28), .B(G29), .Y(new_n118_));
  XOR2x2_ASAP7_75t_R  g032(.A(new_n118_), .B(G33), .Y(new_n119_));
  XOR2x2_ASAP7_75t_R  g033(.A(G26), .B(G27), .Y(new_n120_));
  XOR2x2_ASAP7_75t_R  g034(.A(new_n119_), .B(new_n120_), .Y(new_n121_));
  XOR2x2_ASAP7_75t_R  g035(.A(new_n117_), .B(new_n121_), .Y(G870));
  XOR2x2_ASAP7_75t_R  g036(.A(G41), .B(G42), .Y(new_n123_));
  XOR2x2_ASAP7_75t_R  g037(.A(new_n123_), .B(new_n113_), .Y(new_n124_));
  XOR2x2_ASAP7_75t_R  g038(.A(G47), .B(G48), .Y(new_n125_));
  XOR2x2_ASAP7_75t_R  g039(.A(new_n124_), .B(new_n125_), .Y(new_n126_));
  XOR2x2_ASAP7_75t_R  g040(.A(G45), .B(G46), .Y(new_n127_));
  XOR2x2_ASAP7_75t_R  g041(.A(new_n127_), .B(G49), .Y(new_n128_));
  XOR2x2_ASAP7_75t_R  g042(.A(G43), .B(G44), .Y(new_n129_));
  XOR2x2_ASAP7_75t_R  g043(.A(new_n128_), .B(new_n129_), .Y(new_n130_));
  XOR2x2_ASAP7_75t_R  g044(.A(new_n126_), .B(new_n130_), .Y(G871));
  INVx1_ASAP7_75t_R   g045(.A(G48), .Y(new_n132_));
  INVx1_ASAP7_75t_R   g046(.A(G4), .Y(new_n133_));
  INVx1_ASAP7_75t_R   g047(.A(G11), .Y(new_n134_));
  INVx1_ASAP7_75t_R   g048(.A(G40), .Y(new_n135_));
  OAI21x1_ASAP7_75t_R g049(.A1(new_n134_), .A2(new_n135_), .B(new_n106_), .Y(new_n136_));
  OAI21x1_ASAP7_75t_R g050(.A1(new_n133_), .A2(new_n136_), .B(G1), .Y(new_n137_));
  NAND2x1_ASAP7_75t_R g051(.A(G39), .B(new_n137_), .Y(new_n138_));
  NAND2x1_ASAP7_75t_R g052(.A(G11), .B(G40), .Y(new_n139_));
  NOR2x1_ASAP7_75t_R  g053(.A(G8), .B(G4), .Y(new_n140_));
  AND2x2_ASAP7_75t_R  g054(.A(G8), .B(G4), .Y(new_n141_));
  OR3x1_ASAP7_75t_R   g055(.A(new_n140_), .B(new_n139_), .C(new_n141_), .Y(new_n142_));
  AND3x1_ASAP7_75t_R  g056(.A(G8), .B(G16), .C(G11), .Y(new_n143_));
  NAND2x1_ASAP7_75t_R g057(.A(G4), .B(G9), .Y(new_n144_));
  OR3x1_ASAP7_75t_R   g058(.A(new_n143_), .B(new_n96_), .C(new_n144_), .Y(new_n145_));
  OAI21x1_ASAP7_75t_R g059(.A1(G866), .A2(new_n142_), .B(new_n145_), .Y(new_n146_));
  AND3x1_ASAP7_75t_R  g060(.A(G16), .B(G6), .C(G17), .Y(new_n147_));
  INVx1_ASAP7_75t_R   g061(.A(G60), .Y(new_n148_));
  AND2x2_ASAP7_75t_R  g062(.A(new_n148_), .B(G10), .Y(new_n149_));
  AND3x1_ASAP7_75t_R  g063(.A(new_n149_), .B(new_n106_), .C(new_n147_), .Y(new_n150_));
  AOI21x1_ASAP7_75t_R g064(.A1(G31), .A2(new_n146_), .B(new_n150_), .Y(new_n151_));
  AO21x1_ASAP7_75t_R  g065(.A1(new_n151_), .A2(new_n138_), .B(new_n132_), .Y(new_n152_));
  INVx1_ASAP7_75t_R   g066(.A(new_n152_), .Y(new_n153_));
  AND3x1_ASAP7_75t_R  g067(.A(new_n151_), .B(new_n132_), .C(new_n138_), .Y(new_n154_));
  NOR2x1_ASAP7_75t_R  g068(.A(new_n154_), .B(new_n153_), .Y(new_n155_));
  NOR2x1_ASAP7_75t_R  g069(.A(G58), .B(new_n155_), .Y(new_n156_));
  INVx1_ASAP7_75t_R   g070(.A(G51), .Y(new_n157_));
  INVx1_ASAP7_75t_R   g071(.A(G39), .Y(new_n158_));
  INVx1_ASAP7_75t_R   g072(.A(new_n137_), .Y(new_n159_));
  OAI21x1_ASAP7_75t_R g073(.A1(new_n158_), .A2(new_n159_), .B(new_n151_), .Y(new_n160_));
  OA21x2_ASAP7_75t_R  g074(.A1(new_n160_), .A2(G48), .B(G58), .Y(new_n161_));
  AO21x1_ASAP7_75t_R  g075(.A1(new_n161_), .A2(new_n152_), .B(new_n157_), .Y(new_n162_));
  AO21x1_ASAP7_75t_R  g076(.A1(G48), .A2(G53), .B(G54), .Y(new_n163_));
  AND3x1_ASAP7_75t_R  g077(.A(G8), .B(G13), .C(G14), .Y(new_n164_));
  AND2x2_ASAP7_75t_R  g078(.A(new_n110_), .B(new_n164_), .Y(new_n165_));
  AND2x2_ASAP7_75t_R  g079(.A(G55), .B(G59), .Y(new_n166_));
  AO21x1_ASAP7_75t_R  g080(.A1(G30), .A2(G50), .B(new_n166_), .Y(new_n167_));
  AO21x1_ASAP7_75t_R  g081(.A1(new_n165_), .A2(G48), .B(new_n167_), .Y(new_n168_));
  AO21x1_ASAP7_75t_R  g082(.A1(new_n160_), .A2(new_n163_), .B(new_n168_), .Y(new_n169_));
  AOI21x1_ASAP7_75t_R g083(.A1(G52), .A2(new_n155_), .B(new_n169_), .Y(new_n170_));
  OA21x2_ASAP7_75t_R  g084(.A1(new_n156_), .A2(new_n162_), .B(new_n170_), .Y(G872));
  AO21x1_ASAP7_75t_R  g085(.A1(new_n137_), .A2(G35), .B(new_n150_), .Y(new_n172_));
  AO21x1_ASAP7_75t_R  g086(.A1(G28), .A2(new_n146_), .B(new_n172_), .Y(new_n173_));
  NOR2x1_ASAP7_75t_R  g087(.A(G45), .B(new_n173_), .Y(new_n174_));
  AND2x2_ASAP7_75t_R  g088(.A(new_n173_), .B(G45), .Y(new_n175_));
  OR2x4_ASAP7_75t_R   g089(.A(new_n175_), .B(new_n174_), .Y(new_n176_));
  INVx1_ASAP7_75t_R   g090(.A(G58), .Y(new_n177_));
  OAI21x1_ASAP7_75t_R g091(.A1(new_n177_), .A2(new_n154_), .B(new_n152_), .Y(new_n178_));
  INVx1_ASAP7_75t_R   g092(.A(G47), .Y(new_n179_));
  INVx1_ASAP7_75t_R   g093(.A(G46), .Y(new_n180_));
  INVx1_ASAP7_75t_R   g094(.A(new_n140_), .Y(new_n181_));
  AND2x2_ASAP7_75t_R  g095(.A(G11), .B(G40), .Y(new_n182_));
  OA21x2_ASAP7_75t_R  g096(.A1(new_n87_), .A2(new_n133_), .B(new_n182_), .Y(new_n183_));
  AND3x1_ASAP7_75t_R  g097(.A(new_n183_), .B(new_n106_), .C(new_n181_), .Y(new_n184_));
  NOR3x1_ASAP7_75t_R  g098(.A(new_n143_), .B(new_n96_), .C(new_n144_), .Y(new_n185_));
  OAI21x1_ASAP7_75t_R g099(.A1(new_n185_), .A2(new_n184_), .B(G29), .Y(new_n186_));
  AOI21x1_ASAP7_75t_R g100(.A1(G36), .A2(new_n137_), .B(new_n150_), .Y(new_n187_));
  AND3x1_ASAP7_75t_R  g101(.A(new_n186_), .B(new_n180_), .C(new_n187_), .Y(new_n188_));
  AO21x1_ASAP7_75t_R  g102(.A1(new_n137_), .A2(G37), .B(new_n150_), .Y(new_n189_));
  AOI21x1_ASAP7_75t_R g103(.A1(G30), .A2(new_n146_), .B(new_n189_), .Y(new_n190_));
  AOI21x1_ASAP7_75t_R g104(.A1(new_n179_), .A2(new_n190_), .B(new_n188_), .Y(new_n191_));
  AO21x1_ASAP7_75t_R  g105(.A1(new_n186_), .A2(new_n187_), .B(new_n180_), .Y(new_n192_));
  AND2x2_ASAP7_75t_R  g106(.A(new_n146_), .B(G30), .Y(new_n193_));
  OAI21x1_ASAP7_75t_R g107(.A1(new_n189_), .A2(new_n193_), .B(G47), .Y(new_n194_));
  OAI21x1_ASAP7_75t_R g108(.A1(new_n188_), .A2(new_n194_), .B(new_n192_), .Y(new_n195_));
  AOI21x1_ASAP7_75t_R g109(.A1(new_n191_), .A2(new_n178_), .B(new_n195_), .Y(new_n196_));
  OAI21x1_ASAP7_75t_R g110(.A1(new_n176_), .A2(new_n196_), .B(G51), .Y(new_n197_));
  AO21x1_ASAP7_75t_R  g111(.A1(new_n176_), .A2(new_n196_), .B(new_n197_), .Y(new_n198_));
  INVx1_ASAP7_75t_R   g112(.A(G52), .Y(new_n199_));
  OR3x1_ASAP7_75t_R   g113(.A(new_n174_), .B(new_n175_), .C(new_n199_), .Y(new_n200_));
  AO21x1_ASAP7_75t_R  g114(.A1(G45), .A2(G53), .B(G54), .Y(new_n201_));
  AND2x2_ASAP7_75t_R  g115(.A(G27), .B(G50), .Y(new_n202_));
  AO21x1_ASAP7_75t_R  g116(.A1(new_n165_), .A2(G45), .B(new_n202_), .Y(new_n203_));
  AOI21x1_ASAP7_75t_R g117(.A1(new_n173_), .A2(new_n201_), .B(new_n203_), .Y(new_n204_));
  AND3x1_ASAP7_75t_R  g118(.A(new_n198_), .B(new_n200_), .C(new_n204_), .Y(G873));
  AND2x2_ASAP7_75t_R  g119(.A(new_n186_), .B(new_n187_), .Y(new_n206_));
  XOR2x2_ASAP7_75t_R  g120(.A(new_n206_), .B(new_n180_), .Y(new_n207_));
  INVx1_ASAP7_75t_R   g121(.A(new_n207_), .Y(new_n208_));
  INVx1_ASAP7_75t_R   g122(.A(new_n178_), .Y(new_n209_));
  AND2x2_ASAP7_75t_R  g123(.A(new_n190_), .B(new_n179_), .Y(new_n210_));
  OA21x2_ASAP7_75t_R  g124(.A1(new_n209_), .A2(new_n210_), .B(new_n194_), .Y(new_n211_));
  OAI21x1_ASAP7_75t_R g125(.A1(new_n208_), .A2(new_n211_), .B(G51), .Y(new_n212_));
  AO21x1_ASAP7_75t_R  g126(.A1(new_n208_), .A2(new_n211_), .B(new_n212_), .Y(new_n213_));
  NAND2x1_ASAP7_75t_R g127(.A(G52), .B(new_n207_), .Y(new_n214_));
  INVx1_ASAP7_75t_R   g128(.A(G54), .Y(new_n215_));
  INVx1_ASAP7_75t_R   g129(.A(G53), .Y(new_n216_));
  OA21x2_ASAP7_75t_R  g130(.A1(new_n180_), .A2(new_n216_), .B(new_n215_), .Y(new_n217_));
  AND2x2_ASAP7_75t_R  g131(.A(G55), .B(G56), .Y(new_n218_));
  AO21x1_ASAP7_75t_R  g132(.A1(G28), .A2(G50), .B(new_n218_), .Y(new_n219_));
  AOI21x1_ASAP7_75t_R g133(.A1(G46), .A2(new_n165_), .B(new_n219_), .Y(new_n220_));
  OA21x2_ASAP7_75t_R  g134(.A1(new_n206_), .A2(new_n217_), .B(new_n220_), .Y(new_n221_));
  AND3x1_ASAP7_75t_R  g135(.A(new_n213_), .B(new_n214_), .C(new_n221_), .Y(G874));
  INVx1_ASAP7_75t_R   g136(.A(new_n194_), .Y(new_n223_));
  NOR2x1_ASAP7_75t_R  g137(.A(new_n223_), .B(new_n210_), .Y(new_n224_));
  OAI21x1_ASAP7_75t_R g138(.A1(new_n178_), .A2(new_n224_), .B(G51), .Y(new_n225_));
  AO21x1_ASAP7_75t_R  g139(.A1(new_n178_), .A2(new_n224_), .B(new_n225_), .Y(new_n226_));
  OR3x1_ASAP7_75t_R   g140(.A(new_n210_), .B(new_n223_), .C(new_n199_), .Y(new_n227_));
  OA21x2_ASAP7_75t_R  g141(.A1(new_n179_), .A2(new_n216_), .B(new_n215_), .Y(new_n228_));
  AND2x2_ASAP7_75t_R  g142(.A(G55), .B(G57), .Y(new_n229_));
  AO21x1_ASAP7_75t_R  g143(.A1(G29), .A2(G50), .B(new_n229_), .Y(new_n230_));
  AOI21x1_ASAP7_75t_R g144(.A1(G47), .A2(new_n165_), .B(new_n230_), .Y(new_n231_));
  OA21x2_ASAP7_75t_R  g145(.A1(new_n190_), .A2(new_n228_), .B(new_n231_), .Y(new_n232_));
  AND3x1_ASAP7_75t_R  g146(.A(new_n226_), .B(new_n227_), .C(new_n232_), .Y(G875));
  INVx1_ASAP7_75t_R   g147(.A(G41), .Y(new_n234_));
  INVx1_ASAP7_75t_R   g148(.A(G24), .Y(new_n235_));
  INVx1_ASAP7_75t_R   g149(.A(new_n146_), .Y(new_n236_));
  INVx1_ASAP7_75t_R   g150(.A(G35), .Y(new_n237_));
  INVx1_ASAP7_75t_R   g151(.A(G10), .Y(new_n238_));
  OR3x1_ASAP7_75t_R   g152(.A(G866), .B(new_n238_), .C(new_n182_), .Y(new_n239_));
  AND2x2_ASAP7_75t_R  g153(.A(new_n148_), .B(G4), .Y(new_n240_));
  AND3x1_ASAP7_75t_R  g154(.A(new_n240_), .B(new_n106_), .C(new_n147_), .Y(new_n241_));
  AOI21x1_ASAP7_75t_R g155(.A1(G2), .A2(G34), .B(new_n241_), .Y(new_n242_));
  OA21x2_ASAP7_75t_R  g156(.A1(new_n237_), .A2(new_n239_), .B(new_n242_), .Y(new_n243_));
  OAI21x1_ASAP7_75t_R g157(.A1(new_n235_), .A2(new_n236_), .B(new_n243_), .Y(new_n244_));
  INVx1_ASAP7_75t_R   g158(.A(new_n244_), .Y(new_n245_));
  NAND2x1_ASAP7_75t_R g159(.A(G27), .B(new_n146_), .Y(new_n246_));
  AOI21x1_ASAP7_75t_R g160(.A1(G34), .A2(G38), .B(new_n241_), .Y(new_n247_));
  OA21x2_ASAP7_75t_R  g161(.A1(new_n158_), .A2(new_n239_), .B(new_n247_), .Y(new_n248_));
  NAND2x1_ASAP7_75t_R g162(.A(new_n246_), .B(new_n248_), .Y(new_n249_));
  OR2x4_ASAP7_75t_R   g163(.A(G44), .B(new_n249_), .Y(new_n250_));
  OAI21x1_ASAP7_75t_R g164(.A1(new_n153_), .A2(new_n161_), .B(new_n191_), .Y(new_n251_));
  INVx1_ASAP7_75t_R   g165(.A(new_n195_), .Y(new_n252_));
  AOI21x1_ASAP7_75t_R g166(.A1(new_n252_), .A2(new_n251_), .B(new_n174_), .Y(new_n253_));
  OAI21x1_ASAP7_75t_R g167(.A1(new_n175_), .A2(new_n253_), .B(new_n250_), .Y(new_n254_));
  INVx1_ASAP7_75t_R   g168(.A(G43), .Y(new_n255_));
  NAND2x1_ASAP7_75t_R g169(.A(G26), .B(new_n146_), .Y(new_n256_));
  INVx1_ASAP7_75t_R   g170(.A(G37), .Y(new_n257_));
  AOI21x1_ASAP7_75t_R g171(.A1(G4), .A2(G34), .B(new_n241_), .Y(new_n258_));
  OA21x2_ASAP7_75t_R  g172(.A1(new_n257_), .A2(new_n239_), .B(new_n258_), .Y(new_n259_));
  AND3x1_ASAP7_75t_R  g173(.A(new_n259_), .B(new_n255_), .C(new_n256_), .Y(new_n260_));
  INVx1_ASAP7_75t_R   g174(.A(G42), .Y(new_n261_));
  INVx1_ASAP7_75t_R   g175(.A(G25), .Y(new_n262_));
  INVx1_ASAP7_75t_R   g176(.A(G36), .Y(new_n263_));
  AOI21x1_ASAP7_75t_R g177(.A1(G9), .A2(G34), .B(new_n241_), .Y(new_n264_));
  OA21x2_ASAP7_75t_R  g178(.A1(new_n263_), .A2(new_n239_), .B(new_n264_), .Y(new_n265_));
  OA21x2_ASAP7_75t_R  g179(.A1(new_n262_), .A2(new_n236_), .B(new_n265_), .Y(new_n266_));
  AND2x2_ASAP7_75t_R  g180(.A(new_n266_), .B(new_n261_), .Y(new_n267_));
  NOR2x1_ASAP7_75t_R  g181(.A(new_n260_), .B(new_n267_), .Y(new_n268_));
  INVx1_ASAP7_75t_R   g182(.A(new_n268_), .Y(new_n269_));
  NOR2x1_ASAP7_75t_R  g183(.A(new_n261_), .B(new_n266_), .Y(new_n270_));
  INVx1_ASAP7_75t_R   g184(.A(new_n270_), .Y(new_n271_));
  AO21x1_ASAP7_75t_R  g185(.A1(new_n259_), .A2(new_n256_), .B(new_n255_), .Y(new_n272_));
  NAND2x1_ASAP7_75t_R g186(.A(G44), .B(new_n249_), .Y(new_n273_));
  AO21x1_ASAP7_75t_R  g187(.A1(new_n273_), .A2(new_n272_), .B(new_n260_), .Y(new_n274_));
  OA21x2_ASAP7_75t_R  g188(.A1(new_n274_), .A2(new_n267_), .B(new_n271_), .Y(new_n275_));
  OA21x2_ASAP7_75t_R  g189(.A1(new_n254_), .A2(new_n269_), .B(new_n275_), .Y(new_n276_));
  MAJx2_ASAP7_75t_R   g190(.A(new_n276_), .B(new_n234_), .C(new_n245_), .Y(G876));
  INVx1_ASAP7_75t_R   g191(.A(new_n175_), .Y(new_n278_));
  OAI21x1_ASAP7_75t_R g192(.A1(new_n174_), .A2(new_n196_), .B(new_n278_), .Y(new_n279_));
  AND2x2_ASAP7_75t_R  g193(.A(new_n250_), .B(new_n273_), .Y(new_n280_));
  NOR2x1_ASAP7_75t_R  g194(.A(new_n280_), .B(new_n279_), .Y(new_n281_));
  AO21x1_ASAP7_75t_R  g195(.A1(new_n279_), .A2(new_n280_), .B(new_n157_), .Y(new_n282_));
  AO21x1_ASAP7_75t_R  g196(.A1(G44), .A2(G53), .B(G54), .Y(new_n283_));
  AND2x2_ASAP7_75t_R  g197(.A(G26), .B(G50), .Y(new_n284_));
  AO21x1_ASAP7_75t_R  g198(.A1(new_n165_), .A2(G44), .B(new_n284_), .Y(new_n285_));
  AO21x1_ASAP7_75t_R  g199(.A1(new_n249_), .A2(new_n283_), .B(new_n285_), .Y(new_n286_));
  AOI21x1_ASAP7_75t_R g200(.A1(G52), .A2(new_n280_), .B(new_n286_), .Y(new_n287_));
  OA21x2_ASAP7_75t_R  g201(.A1(new_n281_), .A2(new_n282_), .B(new_n287_), .Y(G877));
  AND3x1_ASAP7_75t_R  g202(.A(new_n279_), .B(new_n250_), .C(new_n268_), .Y(new_n289_));
  INVx1_ASAP7_75t_R   g203(.A(new_n267_), .Y(new_n290_));
  AOI21x1_ASAP7_75t_R g204(.A1(new_n272_), .A2(new_n273_), .B(new_n260_), .Y(new_n291_));
  AO21x1_ASAP7_75t_R  g205(.A1(new_n291_), .A2(new_n290_), .B(new_n270_), .Y(new_n292_));
  XOR2x2_ASAP7_75t_R  g206(.A(new_n244_), .B(G41), .Y(new_n293_));
  OR3x1_ASAP7_75t_R   g207(.A(new_n289_), .B(new_n292_), .C(new_n293_), .Y(new_n294_));
  OAI21x1_ASAP7_75t_R g208(.A1(new_n269_), .A2(new_n254_), .B(new_n275_), .Y(new_n295_));
  AOI21x1_ASAP7_75t_R g209(.A1(new_n293_), .A2(new_n295_), .B(new_n157_), .Y(new_n296_));
  AO21x1_ASAP7_75t_R  g210(.A1(G41), .A2(G53), .B(G54), .Y(new_n297_));
  AND2x2_ASAP7_75t_R  g211(.A(G60), .B(G50), .Y(new_n298_));
  AO21x1_ASAP7_75t_R  g212(.A1(new_n165_), .A2(G41), .B(new_n298_), .Y(new_n299_));
  AO21x1_ASAP7_75t_R  g213(.A1(new_n244_), .A2(new_n297_), .B(new_n299_), .Y(new_n300_));
  AO21x1_ASAP7_75t_R  g214(.A1(new_n293_), .A2(G52), .B(new_n300_), .Y(new_n301_));
  AOI21x1_ASAP7_75t_R g215(.A1(new_n294_), .A2(new_n296_), .B(new_n301_), .Y(G878));
  NOR2x1_ASAP7_75t_R  g216(.A(new_n267_), .B(new_n270_), .Y(new_n303_));
  INVx1_ASAP7_75t_R   g217(.A(new_n260_), .Y(new_n304_));
  AND3x1_ASAP7_75t_R  g218(.A(new_n279_), .B(new_n250_), .C(new_n304_), .Y(new_n305_));
  OR3x1_ASAP7_75t_R   g219(.A(new_n305_), .B(new_n291_), .C(new_n303_), .Y(new_n306_));
  OAI21x1_ASAP7_75t_R g220(.A1(new_n260_), .A2(new_n254_), .B(new_n274_), .Y(new_n307_));
  AOI21x1_ASAP7_75t_R g221(.A1(new_n303_), .A2(new_n307_), .B(new_n157_), .Y(new_n308_));
  INVx1_ASAP7_75t_R   g222(.A(new_n266_), .Y(new_n309_));
  AO21x1_ASAP7_75t_R  g223(.A1(G42), .A2(G53), .B(G54), .Y(new_n310_));
  AND2x2_ASAP7_75t_R  g224(.A(G24), .B(G50), .Y(new_n311_));
  AO21x1_ASAP7_75t_R  g225(.A1(new_n165_), .A2(G42), .B(new_n311_), .Y(new_n312_));
  AO21x1_ASAP7_75t_R  g226(.A1(new_n309_), .A2(new_n310_), .B(new_n312_), .Y(new_n313_));
  AO21x1_ASAP7_75t_R  g227(.A1(new_n303_), .A2(G52), .B(new_n313_), .Y(new_n314_));
  AOI21x1_ASAP7_75t_R g228(.A1(new_n306_), .A2(new_n308_), .B(new_n314_), .Y(G879));
  AND2x2_ASAP7_75t_R  g229(.A(new_n304_), .B(new_n272_), .Y(new_n316_));
  INVx1_ASAP7_75t_R   g230(.A(new_n316_), .Y(new_n317_));
  AND3x1_ASAP7_75t_R  g231(.A(new_n254_), .B(new_n273_), .C(new_n317_), .Y(new_n318_));
  INVx1_ASAP7_75t_R   g232(.A(new_n273_), .Y(new_n319_));
  AO21x1_ASAP7_75t_R  g233(.A1(new_n279_), .A2(new_n250_), .B(new_n319_), .Y(new_n320_));
  AO21x1_ASAP7_75t_R  g234(.A1(new_n320_), .A2(new_n316_), .B(new_n157_), .Y(new_n321_));
  NAND2x1_ASAP7_75t_R g235(.A(new_n256_), .B(new_n259_), .Y(new_n322_));
  AO21x1_ASAP7_75t_R  g236(.A1(G43), .A2(G53), .B(G54), .Y(new_n323_));
  AND2x2_ASAP7_75t_R  g237(.A(G25), .B(G50), .Y(new_n324_));
  AO21x1_ASAP7_75t_R  g238(.A1(new_n165_), .A2(G43), .B(new_n324_), .Y(new_n325_));
  AOI21x1_ASAP7_75t_R g239(.A1(new_n322_), .A2(new_n323_), .B(new_n325_), .Y(new_n326_));
  OA21x2_ASAP7_75t_R  g240(.A1(new_n317_), .A2(new_n199_), .B(new_n326_), .Y(new_n327_));
  OA21x2_ASAP7_75t_R  g241(.A1(new_n321_), .A2(new_n318_), .B(new_n327_), .Y(G880));
endmodule


