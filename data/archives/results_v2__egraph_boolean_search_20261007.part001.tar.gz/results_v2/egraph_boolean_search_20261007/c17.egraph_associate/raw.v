module mapped(G1, G3, G2, G4, G5, G16, G17);
  input G1;
  input G3;
  input G2;
  input G4;
  input G5;
  output G16;
  output G17;
  wire __egm_s17;
  wire __egm_s34;
  wire __egm_s40;
  wire __egm_s50;
  OA21x2_ASAP7_75t_R __egm_g24 (.A1(G5), .A2(G2), .B(__egm_s17), .Y(__egm_s50));
  NAND2x1_ASAP7_75t_R __egm_g139 (.A(G4), .B(G3), .Y(__egm_s17));
  AO21x1_ASAP7_75t_R __egm_g190 (.A2(G2), .A1(__egm_s17), .B(__egm_s34), .Y(__egm_s40));
  AND2x2_ASAP7_75t_R __egm_g258 (.A(G3), .B(G1), .Y(__egm_s34));
  assign G16 = __egm_s40;
  assign G17 = __egm_s50;
endmodule
