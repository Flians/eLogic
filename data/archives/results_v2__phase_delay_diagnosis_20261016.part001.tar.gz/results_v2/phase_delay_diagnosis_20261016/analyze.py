import importlib.util,json,hashlib
from pathlib import Path
root=Path('/home/flynn/workplace/MIGBalance');out=root/'results_v2/phase_delay_diagnosis_20261016'
p=root/'scripts/experiments/campaigns/analyze_sqrt_paths.py';spec=importlib.util.spec_from_file_location('paths',p);mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
c=json.loads((root/'results_v2/delta_area_full_20261016/campaign.json').read_text());b=json.loads((root/'results_v2/epfl_original_baselines_complete_v2_20261013/all_baselines.json').read_text());rows=[]
for bench in ['log2','sin','bar','sqrt','adder','priority']:
 j=next(j for j in c['jobs'] if j['name']==f'4in_{bench}_protected_area')
 candidate=mod.analyze(Path(j['report']).parent,bench,'egraph_staged_control_resyn2')
 baseline=next(r for r in b if r['k']==4 and r['bench']==bench and r['method']=='mockturtle_emap_delay_resyn2')
 reference=mod.analyze(Path(baseline['report']).parent,bench,baseline['method'])
 for key in ['input_sha256','prepared_sha256','library_sha256']:assert candidate[key]==reference[key],key
 frontier=json.loads(Path(j['pool_frontier']).read_text());diag=json.loads(Path(j['candidates']).read_text())
 selected={t for n in diag['selected_instances'] for q in n['outputs'] for t in q['selected_targets']}
 rows.append({'bench':bench,'candidate':candidate,'emap':reference,'frontier':frontier,'both_selected_phase_classes':len({s//2 for m in diag['selected_instances'] for p in m['outputs'] for s in p['selected_targets'] if (s^1) in selected}),'caution':'Signal parity alone does not identify a global original-source polarity across canonical aliases. Path shape is descriptive, not causal proof.'})
 print(bench,'ours',round(candidate['delay'],3),candidate['critical_path_cell_count'],candidate['critical_path_types'],'emap',round(reference['delay'],3),reference['critical_path_cell_count'],reference['critical_path_types'],flush=True)
(out/'paths.json').write_text(json.dumps({'scope':'Read-only fixed V16 protected_area K4 six designs vs original emap; no new mapping or PPA claim','records':rows},indent=2)+'\n')
