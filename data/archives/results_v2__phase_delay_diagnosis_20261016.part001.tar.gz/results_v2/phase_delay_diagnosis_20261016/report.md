# Phase and delay diagnosis — 2026-10-16

Read-only reconstruction of six fixed K4 V16 protected_area observations versus original emap delay mode. Every path's physical instance area and dependent-pin unloaded delay reproduced the existing public evaluator result to 1e-6 absolute. Original input/prepared-AIG/library hashes match each pair. No new mapping results, no baseline changes, no promotion.

| Design | eGraphMap D | emap D | eGraphMap / emap path cells |
|---|---:|---:|---:|
| log2 | 4600.49 | 3874.17 | 174 / 179 |
| sin | 1996.31 | 1788.13 | 83 / 80 |
| bar | 188.34 | 171.90 | 9 / 8 |
| sqrt | 47047.28 | 47047.28 | 2077 / 2077 |
| adder | 2585.23 | 2569.15 | 128 / 128 |
| priority | 2047.24 | 2045.58 | 102 / 102 |

Positive/negative output targets, input phase variants, and pin permutations already exist. For <=6 inputs the library index enumerates all input negation masks; output inversion in the index is not itself a free physical inverter. Physical target phases and explicit real INV cells determine legal implementation. Permutations carry physical pin delays/names. Deduplication preserves function and timing. Code presence is not proof every useful boundary/phase composition reaches the generated pool.

Phase recovery first tries selected INV producer/reverse-INV atomic substitutions. Additional unselected-INV proposals and input-cone restoration exist in V16, but operate on admitted bindings and remain limited by current cone completion and stage/trial budgets. This is not unrestricted multi-level producer-consumer phase optimization.

In log2 both critical paths contain one explicit INV. Ours uses 65 XOR2 cells on its critical path, versus none on emap's selected critical path; emap uses AO31 and more compound structures. This is a difference in selected paths/endpoints, NOT proof of local replaceability or that XOR alone causes the full gap. Bar paths also each have one INV; ours has nine cells versus eight. Sqrt path shapes are very close and delay ties under declared tolerance. Raw INV counts and logic depth alone do not explain the measured deficit.

Existing immutable pool certificates: generated-pool and retained-pool attainable minimum delay agree for these recorded cases; each certificate passes producer-target inequalities. Thus on these observations the retained 100000-cell cap does not explain the delay loss. The certificate excludes missing cuts, ungenerated decompositions, and source/library-global optimality. Increasing recovery time alone cannot improve the certified minimum of the same pool.

Ranked next causal tests:
1. Useful compound boundaries / phase compositions absent before physical-pool generation: align baseline critical cells to original-AIG leaves/functions, query candidate diagnostics and pre/post cut retention. Demonstrate a concrete missing feasible pattern before changing cut ranking.
2. Pin-sensitive alternatives absent/deduplicated incorrectly: for an aligned shared boundary compare all legal input permutations with actual arrival plus pin arc. Existing enumeration argues against a blanket no-permutation explanation; test actual tuples.
3. Joint cone/phase recovery incomplete: only after exhibiting an admitted faster valid combination, check whether pool delay certificate is violated or stale. For already certified minima this cannot explain the whole gap without expanding candidate coverage.
4. SDC optional scan termination drops existing-cell conditional targets: separately reproduced by a deterministic saturated generate fixture. Isolated default-off fix passes the fixture, but has NO EPFL PPA or full-budget qualification yet; not treated as established delay-gap cause.

Artifacts paths.json stores complete paths, source hashes, pool certificates and caveats. First analysis was interrupted due an inefficient repeated set construction; run.log retained, optimized run_v2.log completed. Original data and mapping source remain untouched.
