# Event-flow validation

{
  "event_vs_coupled_phase0": {
    "valid_pairs": 22,
    "both_failed": 18,
    "one_failed": 0,
    "delay_better": 6,
    "delay_equal": 16,
    "delay_worse": 0,
    "area_better": 7,
    "area_equal": 1,
    "area_worse": 14
  },
  "event_vs_coupled_quarter": {
    "valid_pairs": 22,
    "both_failed": 18,
    "one_failed": 0,
    "delay_better": 6,
    "delay_equal": 16,
    "delay_worse": 0,
    "area_better": 8,
    "area_equal": 1,
    "area_worse": 13
  },
  "coupled_queue_vs_coupled_quarter": {
    "valid_pairs": 22,
    "both_failed": 18,
    "one_failed": 0,
    "delay_better": 6,
    "delay_equal": 16,
    "delay_worse": 0,
    "area_better": 8,
    "area_equal": 10,
    "area_worse": 4
  }
}

Every profile/run retained; no selection of best results.
