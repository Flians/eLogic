//! Region-owned physical matching on one global egraph and joint phase recovery.
//! Region boundaries retain global class IDs. Neither nodes, candidates, saturation
//! iterations nor recovery time are reset at region boundaries.
use super::*;

/// Import only logically demanded inversion enodes, while retaining every PI
/// and the constant. Physical signal phases remain globally available through
/// library matches; unreferenced Not enodes need not consume the egraph budget.
/// All actually imported nodes and all rewrite nodes still count globally.
pub(super) fn import_demanded(aig: &Aig) -> Option<(egg::EGraph<AigLang, ()>, Vec<(u32, Id)>)> {
    let (expr, roots) = crate::egraph_sat::build_expr(aig)?;
    let nodes = expr.as_ref();
    let mut needed = vec![false; nodes.len()];
    let mut stack: Vec<_> = roots.iter().map(|(_, id)| *id).collect();
    for (i, node) in nodes.iter().enumerate() {
        if matches!(node, AigLang::Pi(_) | AigLang::Zero) {
            stack.push(Id::from(i));
        }
    }
    while let Some(id) = stack.pop() {
        let i = usize::from(id);
        if needed[i] {
            continue;
        }
        needed[i] = true;
        stack.extend(nodes[i].children().iter().copied());
    }
    let mut graph = egg::EGraph::default();
    let mut translated = vec![None; nodes.len()];
    for (i, node) in nodes.iter().enumerate() {
        if needed[i] {
            translated[i] = Some(
                graph.add(
                    node.clone()
                        .map_children(|child| translated[usize::from(child)].unwrap()),
                ),
            );
        }
    }
    graph.rebuild();
    let roots = roots
        .into_iter()
        .map(|(pos, id)| (pos, graph.find(translated[usize::from(id)].unwrap())))
        .collect();
    Some((graph, roots))
}

pub(super) fn ordered_boundaries<'a>(
    boundaries: &'a BTreeMap<Vec<usize>, Vec<Target>>,
    classes: usize,
    width: usize,
    stats: &mut MapStats,
) -> Vec<(&'a Vec<usize>, &'a Vec<Target>)> {
    let mut result: Vec<_> = boundaries.iter().collect();
    if width == 0 {
        return result;
    }
    stats.regions = classes.div_ceil(width);
    // One owner for a complete boundary, including targets in other regions:
    // multioutput sharing cannot be split into separately charged instances.
    result.sort_by_key(|(boundary, targets)| {
        let owner = targets
            .iter()
            .map(|t| t.signal / 2 / width)
            .min()
            .unwrap_or(0);
        (owner, *boundary)
    });
    stats.cross_region_boundaries = result
        .iter()
        .filter(|(boundary, targets)| {
            let owner = targets
                .iter()
                .map(|t| t.signal / 2 / width)
                .min()
                .unwrap_or(0);
            boundary.iter().any(|c| c / width != owner)
                || targets.iter().any(|t| t.signal / 2 / width != owner)
        })
        .count();
    result
}

/// Partition the remaining window without extending or resetting the global deadline.
/// Fraction one exactly preserves the previous scheduling policy.
pub(super) fn phase_deadline(start: Instant, global: Instant, fraction: f64) -> Instant {
    if fraction == 1.0 || global <= start {
        global
    } else {
        start + global.saturating_duration_since(start).mul_f64(fraction)
    }
}

pub(super) fn recover_phases(
    instances: &[Instance],
    chosen: &mut Vec<Option<Binding>>,
    witness: &[Option<Binding>],
    free: &[bool],
    roots: &[usize],
    ps: &MapParams,
    stats: &mut MapStats,
    deadline: Instant,
) -> Result<(), String> {
    let mut producers = vec![Vec::new(); free.len()];
    let mut reverse = HashMap::<(usize, usize), Binding>::new();
    // Recognize physical unary INV pins. Use only already admitted bindings;
    // this pass creates no logical equality and never unions SDC classes.
    for (i, m) in instances.iter().enumerate() {
        if Instant::now() >= deadline {
            return Ok(());
        }
        for (pin, o) in m.outputs.iter().enumerate() {
            for &s in &o.targets {
                producers[s].push(Binding { instance: i, pin });
                if m.inputs.len() == 1 && o.function == 1 {
                    reverse
                        .entry((m.inputs[0], s))
                        .or_insert(Binding { instance: i, pin });
                }
            }
        }
    }
    let mut best = metrics(instances, chosen, free, roots);
    stats.phase_initial_delay = best.1;
    stats.phase_final_delay = best.1;
    for t in 0..chosen.len() {
        if Instant::now() >= deadline || stats.phase_trials >= ps.refine_trials {
            break;
        }
        let Some(old) = chosen[t] else {
            continue;
        };
        let inv = &instances[old.instance];
        if inv.inputs.len() != 1 || inv.outputs[old.pin].function != 1 {
            continue;
        }
        let s = inv.inputs[0];
        if free[s] || chosen[s].is_none() {
            continue;
        }
        let Some(&back) = reverse.get(&(t, s)) else {
            continue;
        };
        for &alternative in &producers[t] {
            if Instant::now() >= deadline || stats.phase_trials >= ps.refine_trials {
                break;
            }
            let candidate = &instances[alternative.instance];
            if alternative.instance == old.instance
                || candidate.inputs.contains(&s)
                || candidate.inputs.contains(&t)
            {
                continue;
            }
            stats.phase_trials += 1;
            let mut trial = chosen.clone();
            trial[t] = Some(alternative);
            trial[s] = Some(back);
            // Atomic replacement prevents the temporary s->t->s inverse cycle.
            // Full DAG validation and global unique-instance metric handle
            // fanout sharing and all live pins, including multioutput cells.
            if fill_from_witness(instances, &mut trial, witness, free, roots).is_err() {
                continue;
            }
            let score = metrics(instances, &trial, free, roots);
            if better_cover(score, best, ps) {
                *chosen = trial;
                best = score;
                stats.phase_accepted += 1;
                stats.phase_final_delay = score.1;
            }
        }
    }
    prune(instances, chosen, free, roots)
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn phase_allocation_preserves_global_deadline() {
        let start = Instant::now();
        let global = start + std::time::Duration::from_secs(2);
        assert_eq!(phase_deadline(start, global, 1.0), global);
        assert_eq!(phase_deadline(start, global, 0.0), start);
        assert_eq!(phase_deadline(start, global, 0.25), start + std::time::Duration::from_millis(500));
        let expired = start - std::time::Duration::from_millis(1);
        assert_eq!(phase_deadline(start, expired, 1.0), expired);
        assert_eq!(phase_deadline(start, expired, 0.25), expired);
    }

    fn cell(name: &str, inputs: Vec<usize>, target: usize, function: u64, delay: f32) -> Instance {
        Instance {
            cell: name.into(),
            area: 1.,
            input_pins: inputs.iter().map(|_| "A".into()).collect(),
            outputs: vec![OutputPin {
                name: "Y".into(),
                delays: vec![delay; inputs.len()],
                function,
                targets: vec![target],
            }],
            inputs,
        }
    }
    #[test]
    fn atomic_phase_flip_preserves_shared_positive_root() {
        let m = vec![
            cell("AND", vec![0, 1], 2, 8, 10.),
            cell("INV", vec![2], 3, 1, 3.),
            cell("NAND", vec![0, 1], 3, 7, 4.),
            cell("INV", vec![3], 2, 1, 3.),
        ];
        let free = vec![true, true, false, false];
        let roots = vec![2, 3];
        for objective in [MapObjective::AreaDelay, MapObjective::DelayArea] {
            let mut chosen = vec![
                None,
                None,
                Some(Binding {
                    instance: 0,
                    pin: 0,
                }),
                Some(Binding {
                    instance: 1,
                    pin: 0,
                }),
            ];
            let witness = chosen.clone();
            let ps = MapParams {
                objective,
                phase_recovery: true,
                ..Default::default()
            };
            let mut stats = MapStats::default();
            recover_phases(
                &m,
                &mut chosen,
                &witness,
                &free,
                &roots,
                &ps,
                &mut stats,
                Instant::now() + std::time::Duration::from_secs(1),
            )
            .unwrap();
            assert_eq!(metrics(&m, &chosen, &free, &roots), (2., 7.));
            assert_eq!(stats.phase_accepted, 1);
        }
    }
    #[test]
    fn expired_phase_deadline_preserves_incumbent() {
        let m = vec![
            cell("AND", vec![0, 1], 2, 8, 10.),
            cell("INV", vec![2], 3, 1, 3.),
        ];
        let free = vec![true, true, false, false];
        let roots = vec![2, 3];
        let mut chosen = vec![
            None,
            None,
            Some(Binding {
                instance: 0,
                pin: 0,
            }),
            Some(Binding {
                instance: 1,
                pin: 0,
            }),
        ];
        let witness = chosen.clone();
        let mut stats = MapStats::default();
        recover_phases(
            &m,
            &mut chosen,
            &witness,
            &free,
            &roots,
            &MapParams::default(),
            &mut stats,
            Instant::now(),
        )
        .unwrap();
        assert_eq!(stats.phase_trials, 0);
        assert_eq!(metrics(&m, &chosen, &free, &roots), (2., 13.));
    }

    #[test]
    fn region_ownership_keeps_cross_region_joint_targets() {
        let b = BTreeMap::from([(
            vec![0, 3],
            vec![
                Target {
                    signal: 4,
                    function: 8,
                },
                Target {
                    signal: 12,
                    function: 7,
                },
            ],
        )]);
        let mut stats = MapStats::default();
        let owned = ordered_boundaries(&b, 8, 2, &mut stats);
        assert_eq!(owned.len(), 1);
        assert_eq!(owned[0].1.len(), 2);
        assert_eq!(stats.regions, 4);
        assert_eq!(stats.cross_region_boundaries, 1);
    }
}

/// Conservative reservation before each exact rewrite application. The RHS
/// pattern size bounds new enodes (variables add none). This prevents a full
/// iteration from first overshooting the global allowance and then rejecting
/// an otherwise usable input. It changes search coverage, never equivalence.
struct ReservedRewrite {
    inner: std::sync::Arc<dyn egg::Applier<AigLang, ()> + Send + Sync>,
    allowance: usize,
    reservation: usize,
    skipped: std::sync::Arc<std::sync::atomic::AtomicUsize>,
}
impl egg::Applier<AigLang, ()> for ReservedRewrite {
    fn apply_one(
        &self,
        graph: &mut egg::EGraph<AigLang, ()>,
        id: Id,
        subst: &egg::Subst,
        ast: Option<&egg::PatternAst<AigLang>>,
        name: egg::Symbol,
    ) -> Vec<Id> {
        if graph
            .total_number_of_nodes()
            .saturating_add(self.reservation)
            > self.allowance
        {
            self.skipped
                .fetch_add(1, std::sync::atomic::Ordering::Relaxed);
            return vec![];
        }
        self.inner.apply_one(graph, id, subst, ast, name)
    }
    fn vars(&self) -> Vec<egg::Var> {
        self.inner.vars()
    }
    fn get_pattern_ast(&self) -> Option<&egg::PatternAst<AigLang>> {
        self.inner.get_pattern_ast()
    }
}
pub(super) fn reserve_rewrites(
    rules: &mut [egg::Rewrite<AigLang, ()>],
    allowance: usize,
) -> std::sync::Arc<std::sync::atomic::AtomicUsize> {
    let skipped = std::sync::Arc::new(std::sync::atomic::AtomicUsize::new(0));
    for rule in rules {
        // Non-pattern appliers keep their own guard; no unproven size estimate.
        if let Some(ast) = rule.applier.get_pattern_ast() {
            let reservation = ast.as_ref().len();
            rule.applier = std::sync::Arc::new(ReservedRewrite {
                inner: rule.applier.clone(),
                allowance,
                reservation,
                skipped: skipped.clone(),
            });
        }
    }
    skipped
}
