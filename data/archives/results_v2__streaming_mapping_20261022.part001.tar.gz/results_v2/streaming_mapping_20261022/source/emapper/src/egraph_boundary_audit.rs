//! Opt-in offline evidence. Never a producer or a mapping decision input.
use super::*;
use serde::Deserialize;

pub(super) fn graph(cuts:&[BTreeSet<Cut>],nodes:&[Vec<AigLang>],ids:&HashMap<Id,usize>,g:&egg::EGraph<AigLang,()>,inputs:&[(usize,u32,String)],canonical:&[usize],outputs:&[(usize,String)])->Result<(),String>{
 let Some(path)=std::env::var_os("EGM_BOUNDARY_AUDIT_PATH")else{return Ok(())};
 let file=std::fs::File::create(path).map_err(|e|e.to_string())?;
 let mut w=std::io::BufWriter::new(file);
 let metadata=serde_json::json!({"schema":1,"offline_diagnostic_only":true,"inputs":inputs,"canonical":canonical,"outputs":outputs}).to_string();
 w.write_all(metadata[..metadata.len()-1].as_bytes()).map_err(|e|e.to_string())?;
 w.write_all(b",\"nodes\":[").map_err(|e|e.to_string())?;
 for (c,ns)in nodes.iter().enumerate(){
  if c>0{w.write_all(b",").map_err(|e|e.to_string())?;}
  let alternatives:Vec<_>=ns.iter().map(|n|{
   match n {
    AigLang::Pi(v)=>serde_json::json!({"op":"pi","var":v}),
    AigLang::Zero|AigLang::One=>serde_json::json!({"op":"const","value":matches!(n,AigLang::One)}),
    AigLang::Not(a)=>serde_json::json!({"op":"not","args":[ids[&g.find(*a)]]}),
    _=>{
     let (args,tt)=if let Some((a,b,p))=literal_inputs(n){(vec![a,b],match p{0=>8,1=>4,2=>2,_=>1})}
      else if let Some((a,b,p))=xor_inputs(n){(vec![a,b],if p==0{6}else{9})}
      else if let Some((a,tt))=tt3_inputs(n){(a.to_vec(),tt)}
      else{panic!("unsupported diagnostic node {n:?}")};
     serde_json::json!({"op":"tt","tt":tt,"args":args.iter().map(|a|ids[&g.find(*a)]).collect::<Vec<_>>()})
    }
   }
  }).collect();
  serde_json::to_writer(&mut w,&serde_json::json!({"class":c,"alternatives":alternatives})).map_err(|e|e.to_string())?;
 }
 w.write_all(b"],\"cuts\":[").map_err(|e|e.to_string())?;let mut first=true;
 for (c,bank)in cuts.iter().enumerate(){for cut in bank{
  if !first{w.write_all(b",").map_err(|e|e.to_string())?;}first=false;
  serde_json::to_writer(&mut w,&serde_json::json!({"class":c,"leaves":cut.leaves,"function":cut.function})).map_err(|e|e.to_string())?;
 }}
 w.write_all(b"]}").map_err(|e|e.to_string())?;w.flush().map_err(|e|e.to_string())?;
 if std::env::var("EGM_BOUNDARY_AUDIT_STOP").as_deref()==Ok("1"){return Err("offline boundary audit: intentional stop before physical generation".into())}
 Ok(())
}

#[derive(Deserialize)]struct Query{label:String,cell:String,output:String,targets:Vec<usize>,pins:BTreeMap<String,Vec<usize>>}
#[derive(Deserialize)]struct Queries{queries:Vec<Query>}
pub(super)fn pool(stage:&str,instances:&[Instance],chosen:Option<&[Option<Binding>]>)->Result<(),String>{
 let Some(path)=std::env::var_os("EGM_BOUNDARY_QUERY_PATH")else{return Ok(())};
 let q:Queries=serde_json::from_slice(&std::fs::read(&path).map_err(|e|e.to_string())?).map_err(|e|e.to_string())?;
 let rows:Vec<_>=q.queries.iter().map(|q|{
  let mut count=0usize;let mut same_target=0usize;let mut same_support=0usize;let mut examples=Vec::new();let mut selected=false;
  for(i,m)in instances.iter().enumerate(){
   if m.cell!=q.cell || m.inputs.len()!=q.pins.len(){continue}
   let target=m.outputs.iter().any(|o|o.name==q.output&&o.targets.iter().any(|s|q.targets.contains(s)));
   if target {same_target+=1;if m.inputs.iter().all(|s|q.pins.values().any(|v|v.contains(s))){same_support+=1;}}
   if !m.input_pins.iter().zip(&m.inputs).all(|(p,s)|q.pins.get(p).is_some_and(|values|values.contains(s))){continue}
   for(pin,o)in m.outputs.iter().enumerate(){
    if o.name!=q.output||!o.targets.iter().any(|s|q.targets.contains(s)){continue}
    count+=1;if examples.len()<8{examples.push(i);}
    selected|=chosen.is_some_and(|c|q.targets.iter().any(|&s|c.get(s).copied().flatten().is_some_and(|b|b.instance==i&&b.pin==pin)));
   }
  }
  serde_json::json!({"label":q.label,"matching_bindings":count,"same_cell_and_target":same_target,"same_input_support_subset":same_support,"example_instance_ids":examples,"selected":selected})
 }).collect();
 let output=std::path::Path::new(&path).with_extension(format!("{stage}.json"));
 std::fs::write(output,serde_json::to_vec(&serde_json::json!({"stage":stage,"offline_diagnostic_only":true,"instances":instances.len(),"rows":rows})).unwrap()).map_err(|e|e.to_string())
}
