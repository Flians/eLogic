//! Immutable library metadata; mutation of a selected cover is copy-on-write.
use std::{sync::Arc,ops::{Deref,DerefMut}};
#[derive(Clone,PartialEq,Eq)]
pub struct SharedVec<T>(Arc<Vec<T>>);
impl<T:std::fmt::Debug> std::fmt::Debug for SharedVec<T>{fn fmt(&self,f:&mut std::fmt::Formatter<'_>)->std::fmt::Result{self.0.fmt(f)}}
impl<T> Deref for SharedVec<T>{type Target=Vec<T>;fn deref(&self)->&Vec<T>{&self.0}}
impl<T:Clone> DerefMut for SharedVec<T>{fn deref_mut(&mut self)->&mut Vec<T>{Arc::make_mut(&mut self.0)}}
pub trait MetadataValue:Sized {fn intern(v:Vec<Self>)->Arc<Vec<Self>>;}
thread_local!{
 static PINS:std::cell::RefCell<std::collections::HashMap<Vec<String>,Arc<Vec<String>>>>=Default::default();
 static DELAYS:std::cell::RefCell<std::collections::HashMap<Vec<u32>,Arc<Vec<f32>>>>=Default::default();
}
impl MetadataValue for String{fn intern(v:Vec<Self>)->Arc<Vec<Self>>{PINS.with(|c|{let mut c=c.borrow_mut();if let Some(x)=c.get(&v){return x.clone();}let x=Arc::new(v);c.insert(x.as_ref().clone(),x.clone());x})}}
impl MetadataValue for f32{fn intern(v:Vec<Self>)->Arc<Vec<Self>>{let key:Vec<_>=v.iter().map(|v|v.to_bits()).collect();DELAYS.with(|c|{let mut c=c.borrow_mut();c.entry(key).or_insert_with(||Arc::new(v)).clone()})}}
pub struct Scope;
impl Scope{pub fn enter()->Self{PINS.with(|c|c.borrow_mut().clear());DELAYS.with(|c|c.borrow_mut().clear());Self}}
impl Drop for Scope{fn drop(&mut self){PINS.with(|c|c.borrow_mut().clear());DELAYS.with(|c|c.borrow_mut().clear());}}
impl<T:MetadataValue> From<Vec<T>> for SharedVec<T>{fn from(v:Vec<T>)->Self{Self(T::intern(v))}}
impl<T:MetadataValue> FromIterator<T> for SharedVec<T>{fn from_iter<I:IntoIterator<Item=T>>(v:I)->Self{v.into_iter().collect::<Vec<_>>().into()}}
impl<'a,T> IntoIterator for &'a SharedVec<T>{type Item=&'a T;type IntoIter=std::slice::Iter<'a,T>;fn into_iter(self)->Self::IntoIter{self.0.iter()}}
impl<T:serde::Serialize> serde::Serialize for SharedVec<T>{fn serialize<S:serde::Serializer>(&self,s:S)->Result<S::Ok,S::Error>{self.0.as_ref().serialize(s)}}
#[cfg(test)]mod tests{use super::*;
 #[test]fn physical_pin_metadata_shares_storage_without_sharing_mutations(){
 let a:SharedVec<String>=vec!["A".into(),"B".into()].into();let mut b:SharedVec<String>=vec!["A".into(),"B".into()].into();assert!(Arc::ptr_eq(&a.0,&b.0),"identical library pin lists duplicated in generated instances");b[0]="C".into();assert_eq!(a[0],"A");assert_eq!(b[0],"C");}
 #[test]fn delay_interning_keeps_exact_bits_and_pin_order(){let a:SharedVec<f32>=vec![1.,2.].into();let b:SharedVec<f32>=vec![1.,2.].into();assert!(Arc::ptr_eq(&a.0,&b.0));let c:SharedVec<f32>=vec![2.,1.].into();assert!(!Arc::ptr_eq(&a.0,&c.0));let p:SharedVec<f32>=vec![0.].into();let n:SharedVec<f32>=vec![-0.].into();assert_ne!(p[0].to_bits(),n[0].to_bits());}
}
