//! Opt-in execution policy: one non-renewable clock, no resource-count ceilings.
use std::{cell::Cell,time::{Duration,Instant}};
use crate::egraph_map::MapParams;
thread_local! {static END:Cell<Option<Instant>>=const{Cell::new(None)};}
pub struct Window(Option<Instant>);
impl Window {
    pub fn enter(seconds:f64)->Result<Self,String>{
        if !seconds.is_finite() || seconds<=0. || seconds>600. {return Err("time-only remaining window must be in (0,600]".into())}
        let requested=Instant::now()+Duration::from_secs_f64(seconds);
        let old=END.with(|x|{let old=x.get();x.set(Some(old.map_or(requested,|v|v.min(requested))));old});
        Ok(Self(old))
    }
    pub fn from_env()->Result<Option<Self>,String>{
        if std::env::var("EGM_TOTAL_TIME_ONLY").as_deref()!=Ok("1"){return Ok(None)}
        let seconds=std::env::var("EGM_TOTAL_REMAINING_SECS").map_err(|_|"missing shared remaining time")?.parse::<f64>().map_err(|_|"invalid shared remaining time")?;
        Self::enter(seconds).map(Some)
    }
}
impl Drop for Window {fn drop(&mut self){END.with(|v|v.set(self.0));}}
pub fn deadline()->Option<Instant>{END.with(Cell::get)}
pub fn enabled()->bool{deadline().is_some()}
pub fn stage_deadline(legacy:Instant)->Instant{deadline().unwrap_or(legacy)}
pub fn parameters(ps:&MapParams)->MapParams{
    let mut p=ps.clone();if let Some(end)=deadline(){
        p.saturation.node_limit=usize::MAX;p.saturation.iter_limit=usize::MAX;
        p.cuts_per_class=usize::MAX;p.cut_rounds=usize::MAX;
        p.max_instances=usize::MAX;p.refine_rounds=usize::MAX;p.refine_trials=usize::MAX;
        p.dc_cone=usize::MAX;p.return_reserve=0.;
        p.refine_time_secs=end.saturating_duration_since(Instant::now()).as_secs_f64();
    }p
}
#[cfg(test)]mod tests{
    use super::*;
    #[test]fn one_deadline_replaces_stage_caps_and_never_renews(){
        let legacy=Instant::now()+Duration::from_millis(1);assert_eq!(stage_deadline(legacy),legacy);
        let outer=Window::enter(1.).unwrap();let end=deadline().unwrap();
        assert_eq!(stage_deadline(legacy),end);
        {let _inner=Window::enter(2.).unwrap();assert_eq!(deadline(),Some(end));}
        assert_eq!(deadline(),Some(end));drop(outer);assert!(!enabled());
    }
    #[test]fn count_ceilings_are_removed_not_just_raised_to_another_dataset_budget(){
        let mut old=MapParams::default();old.saturation.node_limit=1;old.max_instances=1;old.cuts_per_class=1;
        assert_eq!(parameters(&old).max_instances,1);
        let _window=Window::enter(1.).unwrap();let p=parameters(&old);
        assert_eq!(p.saturation.node_limit,usize::MAX);assert_eq!(p.saturation.iter_limit,usize::MAX);
        assert_eq!(p.max_instances,usize::MAX);assert_eq!(p.cuts_per_class,usize::MAX);
        assert_eq!(p.cut_rounds,usize::MAX);assert_eq!(p.refine_trials,usize::MAX);
        assert_eq!(p.return_reserve,0.);assert_eq!(old.max_instances,1);
    }
    #[test]fn real_cover_can_exceed_the_previous_explicit_node_and_pool_caps(){
        use crate::{aig::Aig,techlib::TechLib,egraph_map::map};
        let d=std::env::temp_dir().join(format!("egm-time-only-test-{}",std::process::id()));std::fs::create_dir_all(&d).unwrap();
        let a=d.join("test.aag");std::fs::write(&a,"aag 3 2 0 1 1\n2\n4\n6\n6 2 4\ni0 a[0]\ni1 b[0]\no0 y[0]\nc\n").unwrap();
        let l=d.join("test.genlib");std::fs::write(&l,"GATE AND2 1 Y=A*B;\nPIN * NONINV 1 999 1 0 1 0\nGATE INV 1 Y=!A;\nPIN * INV 1 999 1 0 1 0\n").unwrap();
        let aig=Aig::from_aiger(a.to_str().unwrap());let lib=TechLib::from_genlib_directed(&l).unwrap();
        let mut p=MapParams::default();p.strict_budgets=true;p.multioutput=false;p.saturation.node_limit=1;p.max_instances=1;p.cuts_per_class=1;p.time_limit_secs=0.;
        assert!(map(&aig,&lib,&p).is_err());
        let _window=Window::enter(2.).unwrap();let m=map(&aig,&lib,&p).unwrap();
        assert!(m.stats.enodes>1);assert!(m.instances.len()>1);assert_eq!(m.area,1.);
        for a in 0..4{let values=m.inputs.iter().enumerate().map(|(i,(_,v,_))|(*v,a&(1<<i)!=0)).collect();assert_eq!(m.evaluate(&values).unwrap(),vec![a==3]);}
    }
}
