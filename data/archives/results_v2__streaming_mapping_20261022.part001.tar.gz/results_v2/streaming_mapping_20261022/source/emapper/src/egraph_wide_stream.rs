//! Resumable DFS of the existing exact wide patterns. Quantum exhaustion
//! preserves every unexplored branch; only the one global deadline stops work.
use super::*;
#[derive(Clone)]enum Op{Var(usize),Const(bool),Not(usize),And(usize,usize)}
fn flatten(p:&Pattern,out:&mut Vec<Op>)->usize{let op=match p{Pattern::Var(v)=>Op::Var(*v),Pattern::Const(v)=>Op::Const(*v),Pattern::Not(x)=>{let a=flatten(x,out);Op::Not(a)},Pattern::And(a,b)=>{let a=flatten(a,out);let b=flatten(b,out);Op::And(a,b)}};let id=out.len();out.push(op);id}
struct Template{cell:Cell,support:Support,ops:Vec<Op>,roots:Vec<usize>}
#[derive(Clone)]struct Frame{todo:Vec<(usize,MatchTerm)>,bind:Vec<Option<usize>>}
#[derive(Clone,Debug,PartialEq,Eq,PartialOrd,Ord)]pub(in super::super)struct Found{pub template:usize,pub inputs:Vec<usize>,pub target:usize}
pub(in super::super)struct Cursor{templates:Vec<Template>,cell:usize,pat:usize,target:usize,stack:Vec<Frame>,active:bool,done:bool,atoms:BTreeMap<(usize,u64),Pattern>,ands:HashMap<usize,Vec<(MatchTerm,MatchTerm)>>,pub steps:usize,pub visits:usize}
pub(in super::super)struct Batch{pub matches:Vec<Found>,pub done:bool,pub deadline:bool,pub steps:usize}
impl Cursor{
 pub fn new(tech:&TechLib,enabled:bool)->Self{let mut templates=Vec::new();if enabled{for cell in tech.cells.iter().filter(|c|c.vars.len()>6&&c.vars.len()<=9&&tech.cells.iter().filter(|v|v.name==c.name).count()==1){let support=support(cell);let truth:Vec<_>=(0..1usize<<support.positions.len()).map(|a|tt9_bit_get(&support.truth,a)).collect();let mut patterns=Vec::new();if let Some(p)=decompose(&support.positions,&truth){patterns.push(p)}patterns.push(pattern(&cell.expr,cell,&support));let mut ops=Vec::new();let roots=patterns.iter().map(|p|flatten(p,&mut ops)).collect();templates.push(Template{cell:cell.clone(),support,ops,roots});}}
  let done=templates.is_empty();Self{templates,cell:0,pat:0,target:0,stack:Vec::new(),active:false,done,atoms:BTreeMap::new(),ands:HashMap::new(),steps:0,visits:0}}
 pub fn done(&self)->bool{self.done}
 pub fn materialize(&self,m:&Found)->Instance{let t=&self.templates[m.template];let c=&t.cell;Instance{cell:c.name.clone(),area:c.area,inputs:m.inputs.clone(),input_pins:c.vars.clone().into(),outputs:vec![OutputPin{wide_function:Some(Box::new(PhysicalFunction{positions:t.support.positions.clone(),truth:t.support.truth})),sources:vec![],name:c.out_pin.clone(),delays:c.vars.iter().map(|p|c.pin_delay.get(p).copied().unwrap_or(0.)).collect::<Vec<_>>().into(),function:c.tt[0],targets:vec![m.target]}]}}
 fn advance(&mut self,n:usize){self.target+=1;if self.target>=n{self.target=0;self.pat+=1;if self.pat>=self.templates[self.cell].roots.len(){self.pat=0;self.cell+=1;if self.cell>=self.templates.len(){self.done=true;}}}}
 pub fn resume<F:Fn(Id)->usize>(&mut self,nodes:&[Vec<AigLang>],dense:&F,free:&[bool],constants:&[Option<bool>],quantum:usize,end:Instant)->Batch{
  let mut out=Vec::new();let before=self.steps;let zero=constants.iter().position(|c|*c==Some(false));
  for _ in 0..quantum{
   if self.done||Instant::now()>=end{break}self.steps+=1;
   if !self.active{if free[self.target]{self.advance(free.len());continue}let t=&self.templates[self.cell];self.stack.push(Frame{todo:vec![(t.roots[self.pat],MatchTerm::Wire(self.target))],bind:vec![None;t.cell.vars.len()]});self.active=true;}
   let Some(mut frame)=self.stack.pop()else{self.active=false;self.advance(free.len());continue};
   let Some((op,term))=frame.todo.pop()else{let t=&self.templates[self.cell];if let Some(inputs)=frame.bind.iter().enumerate().map(|(p,s)|if t.support.positions.contains(&p){*s}else{zero}).collect::<Option<Vec<_>>>(){if !inputs.iter().any(|s|s/2==self.target/2){out.push(Found{template:self.cell,inputs,target:self.target});}}continue};
   match self.templates[self.cell].ops[op]{
    Op::Var(i)=>{let signal=match term{MatchTerm::Wire(s)=>Some(s),MatchTerm::Const(v)=>constants.iter().position(|c|*c==Some(v)),_=>None};if let Some(s)=signal{if frame.bind[i].is_none_or(|old|old==s){frame.bind[i]=Some(s);self.stack.push(frame);}}},
    Op::Const(v)=>{let x=match term{MatchTerm::Const(x)=>Some(x),MatchTerm::Wire(s)=>constants[s],_=>None};if x==Some(v){self.stack.push(frame)}},
    Op::Not(a)=>{frame.todo.push((a,term.not()));self.stack.push(frame)},
    Op::And(a,b)=>{let pairs=match term{MatchTerm::Wire(s)=>{if !self.ands.contains_key(&s){let mut search=Search{nodes,dense,constants,work:usize::MAX,visits:0,atoms:std::mem::take(&mut self.atoms)};let mut pairs=Vec::new();search.ands(s,&mut BTreeSet::new(),&mut pairs);self.visits+=search.visits;self.atoms=search.atoms;self.ands.insert(s,pairs);}self.ands[&s].clone()},MatchTerm::And(a,b)=>vec![(*a,*b)],_=>Vec::new()};
     // Reverse insertion preserves the recursive matcher's original DFS order.
     for(x,y)in pairs.into_iter().rev(){for(x,y)in[(y.clone(),x.clone()),(x,y)]{let mut branch=frame.clone();branch.todo.push((b,y));branch.todo.push((a,x));self.stack.push(branch);}}
    }
   }
  }
  Batch{matches:out,done:self.done,deadline:Instant::now()>=end,steps:self.steps-before}
 }
}
#[cfg(test)]mod tests{use super::*;
 fn tech()->TechLib{let p=std::env::temp_dir().join(format!("stream-wide-{}-{}.genlib",std::process::id(),std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).unwrap().as_nanos()));std::fs::write(&p,"GATE AND7 1 Y=A*B*C*D*E*F*G;\nPIN * NONINV 1 99 1 0 1 0\nGATE NAND7 1 Y=!(A*B*C*D*E*F*G);\nPIN * INV 1 99 1 0 1 0\nGATE INV .1 Y=!A;\nPIN * INV 1 99 .1 0 .1 0\nGATE AND2 .2 Y=A*B;\nPIN * NONINV 1 99 1 0 1 0\n").unwrap();TechLib::from_genlib_directed(&p).unwrap()}
 fn graph()->(Vec<Vec<AigLang>>,Vec<bool>,Vec<Option<bool>>){let mut ns:Vec<_>=(0..7).map(|v|vec![AigLang::Pi(v)]).collect();let mut root=Id::from(0);for v in 1..7{let next=ns.len();ns.push(vec![AigLang::And([root,Id::from(v)])]);root=Id::from(next)}ns.push(vec![AigLang::Not(root)]);let mut free=vec![false;ns.len()*2];for v in 0..7{free[v*2]=true;}let constants=vec![None;free.len()];(ns,free,constants)}
 #[test]fn streamed_resume_has_identical_physical_matches_to_recursive_generator(){let t=tech();let(ns,free,c)=graph();let dense=|id:Id|usize::from(id);let ps=MapParams{wide_cells:true,max_instances:usize::MAX,..Default::default()};let mut old=Vec::new();generate(&ns,&dense,&t,&ps,&free,&c,None,&mut old,&mut MapStats::default());let signature=|pool:&[Instance]|{let mut out:BTreeMap<String,BTreeSet<(usize,usize)>>=BTreeMap::new();for m in pool{let targets=out.entry(format!("{:?}",instance_key(m))).or_default();for(pin,o)in m.outputs.iter().enumerate(){targets.extend(o.targets.iter().map(|&t|(pin,t)));}}out};let expected=signature(&old);assert!(!expected.is_empty());for quantum in [1,7,256,4096]{let mut cursor=Cursor::new(&t,true);let mut found=Vec::new();let mut calls=0;while !cursor.done(){let b=cursor.resume(&ns,&dense,&free,&c,quantum,Instant::now()+std::time::Duration::from_secs(3));assert!(!b.deadline);calls+=1;for m in b.matches{found.push(cursor.materialize(&m));}}if quantum==1{assert!(calls>1);}assert_eq!(signature(&found),expected,"quantum={quantum}");}}
 #[test]fn deadline_preserves_cursor_and_resumes_without_loss(){let t=tech();let(ns,free,c)=graph();let mut a=Cursor::new(&t,true);let b=a.resume(&ns,&|x|usize::from(x),&free,&c,256,Instant::now());assert!(b.deadline&&b.matches.is_empty()&&!b.done);assert_eq!(a.steps,0);let b=a.resume(&ns,&|x|usize::from(x),&free,&c,7,Instant::now()+std::time::Duration::from_secs(1));assert_eq!(b.steps,7);assert!(!b.done);}
 #[test]fn recursive_cross_product_yields_before_complete_target(){let t=tech();let(ns,free,c)=graph();let mut a=Cursor::new(&t,true);let mut yielded=false;while !a.done(){let b=a.resume(&ns,&|x|usize::from(x),&free,&c,1,Instant::now()+std::time::Duration::from_secs(3));if !b.matches.is_empty()&&!b.done{yielded=true;break}}assert!(yielded,"first valid match must not wait for whole library/root enumeration");}
 #[test]fn all_real_wide_templates_resume_with_exact_legacy_target_bindings(){
  let path=std::path::PathBuf::from(std::env::var_os("EGM_TEST_DATA_ROOT").expect("explicit full-library fixture root")).join("asap7_full.genlib");let tech=TechLib::from_genlib_directed(path).unwrap();
  fn lower(e:&Expr,vars:&[String],ns:&mut Vec<Vec<AigLang>>)->Id{let n=match e{Expr::Var(v)=>return Id::from(vars.iter().position(|p|p==v).unwrap()),Expr::Const(v)=>if *v{AigLang::One}else{AigLang::Zero},Expr::Not(x)=>{let a=lower(x,vars,ns);AigLang::Not(a)},Expr::And(x,y)=>{let a=lower(x,vars,ns);let b=lower(y,vars,ns);AigLang::And([a,b])},Expr::Or(x,y)=>{let a=lower(x,vars,ns);let b=lower(y,vars,ns);let ai=ns.len();ns.push(vec![AigLang::Not(a)]);let bi=ns.len();ns.push(vec![AigLang::Not(b)]);let ab=ns.len();ns.push(vec![AigLang::And([Id::from(ai),Id::from(bi)])]);AigLang::Not(Id::from(ab))}};let id=Id::from(ns.len());ns.push(vec![n]);id}
  let signature=|pool:&[Instance]|{let mut out:BTreeMap<String,BTreeSet<(usize,usize)>>=BTreeMap::new();for m in pool{let targets=out.entry(format!("{:?}",instance_key(m))).or_default();for(pin,o)in m.outputs.iter().enumerate(){targets.extend(o.targets.iter().map(|&t|(pin,t)));}}out};let mut count=0;
  for cell in tech.cells.iter().filter(|c|c.vars.len()>6){let mut ns:Vec<_>=(0..cell.vars.len()).map(|v|vec![AigLang::Pi(v as u32)]).collect();let root=lower(&cell.expr,&cell.vars,&mut ns);let mut free=vec![false;ns.len()*2];for v in 0..cell.vars.len(){free[v*2]=true;}let constants=vec![None;free.len()];let dense=|x:Id|usize::from(x);let ps=MapParams{wide_cells:true,max_instances:usize::MAX,..Default::default()};let mut old=Vec::new();generate(&ns,&dense,&tech,&ps,&free,&constants,None,&mut old,&mut MapStats::default());assert!(old.iter().any(|m|m.cell==cell.name&&m.outputs[0].targets.contains(&(usize::from(root)*2))));let mut cursor=Cursor::new(&tech,true);let mut all=Vec::new();while !cursor.done(){let b=cursor.resume(&ns,&dense,&free,&constants,17,Instant::now()+std::time::Duration::from_secs(3));assert!(!b.deadline);for found in b.matches{all.push(cursor.materialize(&found));}}assert_eq!(signature(&all),signature(&old),"cell={}",cell.name);count+=1;}
  assert_eq!(count,7);
 }

}
