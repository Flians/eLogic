# Streaming and complete-seed protection: limited-scope validation

One shared600-second mapping window, independent CEC excluded. Main/paper unchanged.

|Design|stream/recovery 0/0 A|1/0 A|0/1 A|1/1 A|Protected seed A|D (all first2)|
|---|---:|---:|---:|---:|---:|---:|
|adder|87.10|87.10|87.10|87.14|87.10|2569.15|
|bar|248.36|248.36|248.36|248.75|248.36|168.29|

The first four result columns use source/; the protection column uses source_protected/. These are two separately frozen versions. Within each version the toggles use the same binary; the full protection0/1 comparison is in CSV. Three combined repetitions reproduce A/D before and after protection; all shown outputs have independent named-port CEC. Protection restores the same-source pure-delay-seed area trajectory for adder/bar; it does not prove no regression for all designs. Historical adder87.06 remains below87.10.

Protected known scope: 3/20. Full EPFL ablation and large-design repeats remain incomplete. General deferred physical materialization and incremental timing are not implemented.

Protected log2 A=6100.60,D=3855.47,T=600.11,CEC=1,search_finished=False. Targeted dependency-equivalent result is shown separately, not silently adopted into canonical checkpoint.
