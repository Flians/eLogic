# Streaming wide matching and cooperative area recovery

Isolated2026-10-22 study. Main kernel/defaults and baseline original algorithms unchanged. A single600-second mapping-related search clock includes import, library initialization, matching, recovery and export. IndependentCEC, shared once-resyn2, pure conversion and external metrics excluded. No restored node/pool/cut/iteration/stage caps.

## Frozen source versions

`source/` + `integration.json`: resumable exact wide matcher (`egraph_wide_stream.rs`) with explicit DFS stack and immutable library templates; same physical match keys AND target sets as the recursive matcher. Checked on all7 current wide library cells and pause quanta1/7/256/4096.4096 DFS operations and16 actual-area candidate proposals are yielding granularity, not search quotas; pending work survives. The area cursor can fill unselected inputs from a feasible witness and checks the entire cover before acceptance.258related Rust tests pass,6ignored,16filtered;4real-process/receipt tests pass. Initial overstrong calls>1 assertion and parallel fixture filename race failures retained; fixture uniqueness repaired.

`source_protected/` + `protected-integration.json`: additionally keep an independently captured complete best pure-delay seed even if it loses against a locally area-recovered incumbent. At final recovery, try fixed-bound recovery from that complete seed and the current incumbent using the SAME global deadline.259related tests pass, including protection when a globally rejected higher-area seed must remain available. No archived netlist is used as an incumbent.

## Evidence

`red-replay.log`: old log2 trace fails fast replay: after wide start, no yield/recovery/cuts progress. `log2-progress-final.log`: streaming trace passes all four progress conditions. This resolves the whole-batch-wide blocking symptom, not the remaining600timeout.

`epfl_stream_recovery`, `epfl_control`, `epfl_stream_only`, `epfl_recovery_only`: first2 same-binary2x2 on stream/recovery toggles. All8 outputsCEC. Only both enabled produce small area regression: adder87.10->87.14, bar248.36->248.75, delay unchanged. Two extra combined repetitions reproduce these values (4additionalCEC).

`epfl_protected`/`epfl_protected_control` and two protected repetitions: protection restores adder87.10, bar248.36 without delay loss; all8outputsCEC. This removes THIS scheduling-interaction regression. Historical old adder87.06 is still lower; no blanket no-regression claim.

`log2_stream_recovery`:600search timeout with a committed optimized output; independentCEC passes, A6100.60/D3855.47. Previous online version A4793.55/D4059.30; original source-only A2919.34/D9710.57. Same-library emap-delay D3864.80/A1775.20; ABC-map-delay D3984.94. The new delay is slightly lower, with a large area cost. Final selected cover has zero>6-input cells (`log2-selected-cell-counts.json`); do not attribute delay gain to wide-cell selection. Work proceeds to cut round4; ordinary matching/merging and full-pool delay/validation remain costly. Protected-version log2 is separately recorded in `log2_protected`; consult its checkpoint for completion.

`progress_first2/`: hash-verified all20 scopeCSV with missing entries,2x2 results, protection results, per-runT, independentCEC and lex/Pareto gates. It is a progress report, not completed fullEPFL evidence.

## Remaining work and limits

General deferred physical materialization is not implemented: the wide cursor yields lightweight matches but admitted physical matches are still eagerly built into the pool. Delay frontier still scans the whole pool. Ordinary small matching and cut-round inner loops can still run long. Full area-flow/shared-cover scheduling has not been made entirely resumable; the cooperative path handles actual-area proposals and the final complete recovery remains an end-stage operation. Online legacy statistics generated_instances/maxcuts/bindings are incomplete; do not infer memory or generated totals from them. No RSS reduction has been measured.

Full20 uniform ablations and large-design repeated tests are incomplete; no main algorithm adoption or paper final-table update. Baselines remain their original methods under frozen total600 harness. All raw failures, source hashes, prior versions and negative area results retained. `continue_checkpoint.json` records finite active/finished batches and next commands; no detached process is assumed to survive turns.
