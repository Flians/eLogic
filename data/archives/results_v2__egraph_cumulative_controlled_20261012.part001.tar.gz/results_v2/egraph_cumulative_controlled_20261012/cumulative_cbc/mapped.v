module mapped(a, b, c, y, z, w);
  input a;
  input b;
  input c;
  output y;
  output z;
  output w;
  wire __egm_s10;
  wire __egm_s2;
  wire __egm_s6;
  TRIPLE __egm_g18 (.A(c), .B(b), .C(a), .Y(__egm_s2), .Z(__egm_s6), .W(__egm_s10));
  assign y = __egm_s10;
  assign z = __egm_s6;
  assign w = __egm_s2;
endmodule
