module AND(A, B, Y);
  input A;
  input B;
  output Y;
  assign Y = (A) & (B);
endmodule
module BUF(A, Y);
  input A;
  output Y;
  assign Y = A;
endmodule
module INV(A, Y);
  input A;
  output Y;
  assign Y = ~(A);
endmodule
module TRIPLE(A, B, C, Y, Z, W);
  input A;
  input B;
  input C;
  output Y;
  output Z;
  output W;
  assign Y = ~(A);
  assign Z = ~(B);
  assign W = ~(C);
endmodule
