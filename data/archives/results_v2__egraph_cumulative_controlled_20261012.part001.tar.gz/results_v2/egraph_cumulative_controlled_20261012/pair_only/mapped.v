module mapped(a, b, c, y, z, w);
  input a;
  input b;
  input c;
  output y;
  output z;
  output w;
  wire __egm_s10;
  wire __egm_s2;
  wire __egm_s6;
  INV __egm_g0 (.A(c), .Y(__egm_s2));
  INV __egm_g4 (.A(b), .Y(__egm_s6));
  INV __egm_g8 (.A(a), .Y(__egm_s10));
  assign y = __egm_s10;
  assign z = __egm_s6;
  assign w = __egm_s2;
endmodule
