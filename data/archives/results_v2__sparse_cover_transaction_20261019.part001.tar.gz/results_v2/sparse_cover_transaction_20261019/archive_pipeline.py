import subprocess,json,sys
from pathlib import Path
R=Path('/home/flynn/workplace/MIGBalance');D=R/'scripts/experiments/campaigns';E=R/'results_v2/sparse_cover_transaction_20261019'
items=[('emapper-generation-frontier-probe-20261019','frontier_V43_diagnostic_probe_20261019'),('emapper-generation-frontier-mapping-probe-20261019','frontier_V43_mapping_probe_20261019'),('emapper-streamed-provenance-probe-20261019','frontier_V44_streamed_probe_20261019'),('emapper-streamed-provenance-full-20261019','frontier_V44_full_20261019')]+[('emapper-streamed-provenance-repeat-r%d-20261019'%i,'frontier_V44_repeat_r%d_20261019'%i)for i in range(3)]+[('emapper-bounded-exchange-probe-20261019','exchange_V45_setup_probe_20261019'),('emapper-sparse-cover-probe-20261019','exchange_V46_sparse_probe_20261019'),('emapper-sparse-cover-full-20261019','exchange_V46_sparse_full_20261019')]+[('emapper-sparse-cover-repeat-r%d-20261019'%i,'exchange_V46_sparse_repeat_r%d_20261019'%i)for i in range(3)]
records=[]
for folder,label in items:
 subprocess.run([sys.executable,str(D/'archive_component_artifacts.py'),'/tmp/'+folder,'--label',label],cwd=R,check=True);q=R/'results_v2/archives'/ (label+'.verified.json');records.append(json.loads(q.read_text()))
 (E/'archives.json').write_text(json.dumps(records,indent=2)+'\n')
print('ALL',len(records),'archives complete and member-SHA verified',flush=True)
