import subprocess,sys,json
from pathlib import Path
R=Path('/home/flynn/workplace/MIGBalance');D=R/'scripts/experiments/campaigns';E=R/'results_v2/sparse_cover_transaction_20261019';full=Path('/tmp/emapper-sparse-cover-full-20261019');reps=[]
def run(argv):
 print('RUN',*[str(x)for x in argv],flush=True);subprocess.run([sys.executable,*map(str,argv)],cwd=R,check=True)
def check(p):
 run([D/'check_sparse_cover_transaction.py',p/'campaign.json']);run([D/'audit_generation_stages.py',p/'campaign.json'])
run([D/'run_sparse_cover_transaction.py','--output',full,'--profiles','reuse','--max-jobs','40']);check(full)
for i in range(3):
 p=Path('/tmp/emapper-sparse-cover-repeat-r%d-20261019'%i);reps.append(p/'campaign.json');designs=['sqrt','sin','adder'] if i%2==0 else ['adder','sin','sqrt'];args=[D/'run_sparse_cover_repeats.py','--output',p,'--profiles','reuse','--designs',*designs,'--max-jobs','6']
 if i%2:args+=['--reverse-inventories']
 run(args);check(p)
run([D/'finalize_sparse_cover_transaction.py',full/'campaign.json','--repeats',*reps,'--output',E/'evidence'])
(E/'finite_finished.json').write_text(json.dumps({'full':str(full),'repeats':list(map(str,reps)),'status':'finished'},indent=2))
