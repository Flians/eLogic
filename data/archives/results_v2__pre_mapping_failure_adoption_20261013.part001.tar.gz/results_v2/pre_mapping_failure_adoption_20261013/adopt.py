"""Adopt only audited stock E-Syn failures before any technology mapping call."""
import fcntl,hashlib,json,sys
from pathlib import Path
ROOT=Path.cwd();sys.path.insert(0,str(ROOT/'scripts/experiments/campaigns'))
from run_epfl_mapping_campaign import jobs
from run_with_mapping_budget import mapping
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
oldroot=ROOT/'results_v2/epfl_baseline_checkpoint_20261013';newroot=ROOT/'results_v2/epfl_mapping_policy_checkpoint_20261013';proofroot=ROOT/'results_v2/pre_mapping_failure_adoption_20261013'
locks=[]
for path in [oldroot/'runner.lock',ROOT/'results_v2/epfl_strict_main_checkpoint_20261013/runner.lock',newroot/'runner.lock']:
 f=path.open('a');fcntl.flock(f,fcntl.LOCK_EX|fcntl.LOCK_NB);locks.append(f)
old=json.loads((oldroot/'campaign.json').read_text());new=json.loads((newroot/'campaign.json').read_text());assert not new.get('current_job')
assert old['fingerprint']['native']==new['fingerprint']['native']
assert all(new['fingerprint']['files'].get(k)==v and sha(Path(k))==v for k,v in old['fingerprint']['files'].items())
assert all(sha(Path(k))==v for k,v in new['fingerprint']['files'].items())
meta={r['bench']:r for r in json.loads((ROOT/'results_v2/epfl_resyn2_subjects_20261012/report.json').read_text())['results']}
proofs=[]
for objective in ['area-delay','delay-area']:
 name=f'3in_esyn_{objective}_adder'
 if any(j['name']==name for j in new['jobs']):continue
 name2,bench,options=next(x for x in jobs() if x[0]==name)
 entry=next(j for j in old['jobs'] if j['name']==name);path=Path(entry['report']);assert sha(path)==entry['report_sha256'];report=json.loads(path.read_text());assert len(report['results'])==1
 row=report['results'][0];assert row['status']=='failed' and row['error']=='process-group timeout' and not report['candidates']
 assert row['method']=='esyn_frozen_model_amap_bounded_dag' and row['input_sha256']==meta[bench]['input_sha256']
 assert row['preprocessing']['sha256']==meta[bench]['preprocessing']['sha256'] and report['objective']==objective
 assert report['native_limits']=={'seconds':2,'nodes':20000,'iterations':16} and report['representation']=='dag' and report['timeout_secs']==60
 assert report['harness_sha256']==sha(ROOT/'scripts/experiments/bench_esyn_baseline.py')
 assert report['binary_sha256']==sha(Path('/tmp/emapper-esyn-baseline/e-rewriter/target/release/e-rewriter'))
 assert report['model_sha256']=={n:sha(Path('/tmp/emapper-esyn-baseline/e-rewriter/src/model')/n) for n in ['xgb_delay.model','xgb.model']}
 assert all(not mapping(argv) for argv in report['commands'])
 assert any(Path(str(argv[0])).name=='e-rewriter' for argv in report['commands'])
 core=json.loads((newroot/'3in_core_adder/report.json').read_text());assert report['library_sha256']==core['library_sha256']
 folder=newroot/name;assert not folder.exists();folder.mkdir()
 report['wall_budget_policy']={'mapping_seconds':300,'mapping_wall_secs':0,'adoption':'stock native failure before mapping; no new trial or success'}
 report['adopted_failure_source']={'report':str(path),'sha256':sha(path),'original_argv':entry['argv']}
 rp=folder/'report.json';rp.write_text(json.dumps(report,indent=2)+'\n')
 audit=newroot/f'{name}.audit.json';e={'policy':'adopted failed observation: mapping never reached','mapping_seconds':300,'mapping_wall_secs':0,'no_mapping_commands_proven':True,'source':str(path),'source_sha256':sha(path),'source_fingerprints_equal':True,'native_parameters_unchanged':True,'status':'failed','exit_code':entry['exit_code'],'adoption_script_sha256':sha(Path(__file__))};audit.write_text(json.dumps(e,indent=2)+'\n')
 new['jobs'].append({'name':name,'bench':bench,'adopted_from':str(path),'original_argv':entry['argv'],'exit_code':entry['exit_code'],'report':str(rp),'report_sha256':sha(rp),'audit':str(audit),'audit_sha256':sha(audit),'ok':0,'failed':1,'missing_benches':[]})
 proofs.append(e)
 new['status']='checkpointed';tmp=newroot/'campaign.json.tmp';tmp.write_text(json.dumps(new,indent=2)+'\n');tmp.replace(newroot/'campaign.json')
(proofroot/'validation.json').write_text(json.dumps({'adopted_failures':proofs,'no_success_relabeling':True,'new_policy_jobs':len(new['jobs'])},indent=2)+'\n');print('adopted',len(proofs),'original failures; mapping=0; canonical jobs',len(new['jobs']))
