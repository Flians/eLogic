//! Library-directed exact structural matches. No wide-cut Cartesian products or pin permutations.
//! Incomplete under both structure and work limits; no conditional equality is unioned into egg.
use super::*;
use crate::tt9::{tt9_bit_get,tt9_bit_set,Tt9};

#[derive(Clone,Debug)]
pub(super) struct PhysicalFunction { pub(super) positions:Vec<usize>, truth:Tt9 }
impl PhysicalFunction {
 pub(super) fn value(&self, assignment:usize)->bool {let a=self.positions.iter().enumerate().fold(0,|v,(i,p)|v|(((assignment>>p)&1)<<i));tt9_bit_get(&self.truth,a)}
}
#[derive(Clone,Debug)]
struct Support { positions:Vec<usize>, truth:Tt9 }
fn support(cell:&Cell)->Support {
 let n=cell.vars.len();
 let positions:Vec<_>=(0..n).filter(|&p|(0..1usize<<n).filter(|a|a&(1<<p)==0).any(|a|tt9_bit_get(&cell.tt,a)!=tt9_bit_get(&cell.tt,a|(1<<p)))).collect();
 let mut truth=[0;8];
 for a in 0..1usize<<positions.len(){let raw=positions.iter().enumerate().fold(0,|v,(i,p)|v|(((a>>i)&1)<<p));if tt9_bit_get(&cell.tt,raw){tt9_bit_set(&mut truth,a);}}
 Support{positions,truth}
}
#[derive(Clone)] enum Pattern {Var(usize),Const(bool),Not(Box<Pattern>),And(Box<Pattern>,Box<Pattern>)}
fn pattern(e:&Expr,cell:&Cell,s:&Support)->Pattern {
 match e {
  Expr::Const(v)=>Pattern::Const(*v),
  Expr::Var(v)=>{let p=cell.vars.iter().position(|n|n==v).unwrap();if s.positions.contains(&p){Pattern::Var(p)}else{Pattern::Const(false)}},
  Expr::Not(a)=>Pattern::Not(Box::new(pattern(a,cell,s))),
  Expr::And(a,b)=>Pattern::And(Box::new(pattern(a,cell,s)),Box::new(pattern(b,cell,s))),
  Expr::Or(a,b)=>Pattern::Not(Box::new(Pattern::And(Box::new(Pattern::Not(Box::new(pattern(a,cell,s)))),Box::new(Pattern::Not(Box::new(pattern(b,cell,s))))))),
 }
}
// Exact disjoint AND/OR decomposition of the actual-support function. This
// avoids requiring a library's expanded SOP text to occur literally in the AIG.
fn decompose(vars:&[usize],truth:&[bool])->Option<Pattern>{
 if truth.iter().all(|v|!*v){return Some(Pattern::Const(false))}
 if truth.iter().all(|v|*v){return Some(Pattern::Const(true))}
 if vars.len()==1 {let v=Pattern::Var(vars[0]);return Some(if truth[0]{Pattern::Not(Box::new(v))}else{v})}
 for bits in 1..1usize<<vars.len(){
  if bits&1==0||bits.count_ones()as usize==vars.len(){continue}
  let left:Vec<_>=(0..vars.len()).filter(|p|bits&(1<<p)!=0).collect();let right:Vec<_>=(0..vars.len()).filter(|p|bits&(1<<p)==0).collect();
  let project=|a:usize,p:&[usize]|p.iter().enumerate().fold(0,|v,(i,k)|v|(((a>>k)&1)<<i));
  for or in [false,true]{let mut a=vec![or;1<<left.len()];let mut b=vec![or;1<<right.len()];
   for (x,&v)in truth.iter().enumerate(){let i=project(x,&left);let j=project(x,&right);if or {a[i]&=v;b[j]&=v;}else{a[i]|=v;b[j]|=v;}}
   if !truth.iter().enumerate().all(|(x,&v)|v==if or{a[project(x,&left)]|b[project(x,&right)]}else{a[project(x,&left)]&b[project(x,&right)]}){continue}
   if let (Some(a),Some(b))=(decompose(&left.iter().map(|i|vars[*i]).collect::<Vec<_>>(),&a),decompose(&right.iter().map(|i|vars[*i]).collect::<Vec<_>>(),&b)){
    return Some(if or{Pattern::Not(Box::new(Pattern::And(Box::new(Pattern::Not(Box::new(a))),Box::new(Pattern::Not(Box::new(b))))))}else{Pattern::And(Box::new(a),Box::new(b))});
   }
  }
 }
 None
}
// Match-only decomposition of an already-counted functional node. A variable
// may bind only an existing eclass signal (or a named constant), never an unnamed
// internal term. These terms are not imported, unioned, or physical producers.
#[derive(Clone)] enum MatchTerm {Wire(usize),Const(bool),Not(Box<MatchTerm>),And(Box<MatchTerm>,Box<MatchTerm>)}
impl MatchTerm {
 fn not(self)->Self{match self{Self::Wire(s)=>Self::Wire(s^1),Self::Const(v)=>Self::Const(!v),Self::Not(t)=>*t,t=>Self::Not(Box::new(t))}}
 fn compile(p:&Pattern,inputs:&[usize])->Self{match p{Pattern::Var(v)=>Self::Wire(inputs[*v]),Pattern::Const(v)=>Self::Const(*v),Pattern::Not(p)=>Self::compile(p,inputs).not(),Pattern::And(a,b)=>Self::And(Box::new(Self::compile(a,inputs)),Box::new(Self::compile(b,inputs)))}}
}
fn shannon(vars:&[usize],truth:&[bool])->Pattern{
 if truth.iter().all(|v|!*v){return Pattern::Const(false)}if truth.iter().all(|v|*v){return Pattern::Const(true)}
 let a:Vec<_>=truth.iter().step_by(2).copied().collect();let b:Vec<_>=truth.iter().skip(1).step_by(2).copied().collect();
 if a==b{return shannon(&vars[1..],&a)}
 let low=Pattern::And(Box::new(Pattern::Not(Box::new(Pattern::Var(vars[0])))),Box::new(shannon(&vars[1..],&a)));
 let high=Pattern::And(Box::new(Pattern::Var(vars[0])),Box::new(shannon(&vars[1..],&b)));
 Pattern::Not(Box::new(Pattern::And(Box::new(Pattern::Not(Box::new(low))),Box::new(Pattern::Not(Box::new(high))))))
}
struct Search<'a,F:Fn(Id)->usize> {nodes:&'a [Vec<AigLang>],dense:&'a F,constants:&'a [Option<bool>],work:usize,visits:usize,atoms:BTreeMap<(usize,u64),Pattern>}
impl<F:Fn(Id)->usize> Search<'_,F> {
 fn ands(&mut self,s:usize,seen:&mut BTreeSet<usize>,out:&mut Vec<(MatchTerm,MatchTerm)>){
  if self.work==0||!seen.insert(s){return}self.work-=1;self.visits+=1;
  for node in &self.nodes[s/2] {
   if let AigLang::Not(a)=node {self.ands((self.dense)(*a)*2+(s%2^1),seen,out);}
   if s%2==0 {if let Some((a,b,phase))=literal_inputs(node){out.push((MatchTerm::Wire((self.dense)(a)*2+usize::from(phase&1)),MatchTerm::Wire((self.dense)(b)*2+usize::from((phase>>1)&1))));}}
   let atom=tt3_inputs(node).map(|(args,tt)|(args.to_vec(),tt)).or_else(||xor_inputs(node).map(|(a,b,p)|(vec![a,b],if p==0{6}else{9})));
   if let Some((args,tt))=atom {
    let p=self.atoms.entry((args.len(),tt)).or_insert_with(||{let vars:Vec<_>=(0..args.len()).collect();let truth:Vec<_>=(0..1usize<<args.len()).map(|a|tt&(1<<a)!=0).collect();decompose(&vars,&truth).unwrap_or_else(||shannon(&vars,&truth))});
    let inputs:Vec<_>=args.iter().map(|a|(self.dense)(*a)*2).collect();let term=MatchTerm::compile(p,&inputs);let term=if s%2==1{term.not()}else{term};
    if let MatchTerm::And(a,b)=term {out.push((*a,*b));}
   }
  }
 }
 fn matches(&mut self,p:&Pattern,s:usize,bind:&[Option<usize>])->Vec<Vec<Option<usize>>>{self.match_term(p,MatchTerm::Wire(s),bind)}
 fn match_term(&mut self,p:&Pattern,term:MatchTerm,bind:&[Option<usize>])->Vec<Vec<Option<usize>>> {
  if self.work==0{return vec![]}self.work-=1;self.visits+=1;
  match p {
   Pattern::Var(i)=>{let signal=match term{MatchTerm::Wire(s)=>Some(s),MatchTerm::Const(v)=>self.constants.iter().position(|c|*c==Some(v)),_=>None};let Some(s)=signal else{return vec![]};if bind[*i].is_some_and(|v|v!=s){vec![]}else{let mut b=bind.to_vec();b[*i]=Some(s);vec![b]}},
   Pattern::Const(v)=>{let value=match term{MatchTerm::Const(c)=>Some(c),MatchTerm::Wire(s)=>self.constants[s],_=>None};if value==Some(*v){vec![bind.to_vec()]}else{vec![]}},
   Pattern::Not(p)=>self.match_term(p,term.not(),bind),
   Pattern::And(a,b)=>{let mut pairs=vec![];match term{MatchTerm::Wire(s)=>self.ands(s,&mut BTreeSet::new(),&mut pairs),MatchTerm::And(a,b)=>pairs.push((*a,*b)),_=>{}}let mut result=vec![];
    for (x,y) in pairs {for (x,y) in [(x.clone(),y.clone()),(y,x)]{for state in self.match_term(a,x.clone(),bind){result.extend(self.match_term(b,y.clone(),&state));if self.work==0{return result}}}}
    result
   }
  }
 }
}
fn seed_index(pool:&[Instance],names:&HashSet<&str>,filter:bool)->(HashMap<InstanceKey,usize>,usize){
 let mut keys=0;
 let index=pool.iter().enumerate().filter(|(_,m)|!filter||names.contains(m.cell.as_str())).map(|(i,m)|{keys+=1;(instance_key(m),i)}).collect();
 (index,keys)
}
pub(super) fn generate<F:Fn(Id)->usize>(nodes:&[Vec<AigLang>],dense:&F,tech:&TechLib,ps:&MapParams,free:&[bool],constants:&[Option<bool>],aliases:Option<(&[usize],&[bool])>,pool:&mut Vec<Instance>,stats:&mut MapStats){
 // Isolated experimental source: loader explicitly opts in to this module.
 let wide:Vec<_>=tech.cells.iter().filter(|c|c.vars.len()>6 && c.vars.len()<=9 && tech.cells.iter().filter(|v|v.name==c.name).count()==1).collect();
 if !ps.wide_cells || wide.is_empty(){return}
 let zero=constants.iter().position(|v|*v==Some(false));
 let mut search=Search{nodes,dense,constants,work:ps.max_instances.saturating_mul(16),visits:0,atoms:BTreeMap::new()};
 let wide_names:HashSet<_>=wide.iter().map(|c|c.name.as_str()).collect();
 let (mut index,index_keys)=seed_index(pool,&wide_names,ps.wide_index_filter);
 let mut admitted=0;let mut audit=vec![];
 let mut remaining=search.work;let count=wide.len();
 for (ordinal,cell) in wide.into_iter().enumerate() {
  // Fair work allocation shares one total allowance; no cell gets a new budget.
  let quota=remaining/(count-ordinal);search.work=quota;let before=admitted;
  let support=support(cell);let truth:Vec<_>=(0..1usize<<support.positions.len()).map(|a|tt9_bit_get(&support.truth,a)).collect();
  let mut patterns=vec![];if let Some(p)=decompose(&support.positions,&truth){patterns.push(p)}patterns.push(pattern(&cell.expr,cell,&support));
  for pat in &patterns {
  for target in 0..free.len(){
   if free[target]{continue}
   for bind in search.matches(pat,target,&vec![None;cell.vars.len()]) {
    if admitted>=ps.max_instances {stats.wide_work_limit_hit=true;break}
    // Inessential physical pins are tied off, not silently omitted from exported instances.
    let Some(inputs)=bind.iter().enumerate().map(|(p,s)|if support.positions.contains(&p){*s}else{zero}).collect::<Option<Vec<_>>>()else{continue};
    if inputs.iter().any(|s|s/2==target/2){continue}
    let mut m=Instance{cell:cell.name.clone(),area:cell.area,inputs,input_pins:cell.vars.clone(),outputs:vec![OutputPin{wide_function:Some(Box::new(PhysicalFunction{positions:support.positions.clone(),truth:support.truth})),sources:vec![],name:cell.out_pin.clone(),delays:cell.vars.iter().map(|p|cell.pin_delay.get(p).copied().unwrap_or(0.)).collect(),function:cell.tt[0],targets:vec![target]}]};
    if ps.protected_exchange {exchange::record_wide(&mut m,aliases);}
    if let Some((a,f))=aliases {if !normalize_physical_instance(&mut m,a,f){continue}}
    let count=pool.len();insert_instance(&mut *pool,&mut index,m);admitted+=usize::from(pool.len()>count);
   }
   if search.work==0||admitted>=ps.max_instances{break}
  }
  if search.work==0||admitted>=ps.max_instances{break}
  }
  audit.push(serde_json::json!({"cell":cell.name,"physical_inputs":cell.vars.len(),"actual_support":support.positions.len(),"candidates":admitted-before,"work_quota":quota,"work_used":quota-search.work,"work_exhausted":search.work==0}));
  remaining-=quota-search.work;stats.wide_work_limit_hit|=search.work==0;
  if admitted>=ps.max_instances{break}
 }
 if let Some(path)=std::env::var_os("EGM_POOL_DIAG_PATH"){let _=std::fs::write(std::path::Path::new(&path).with_extension("wide-generation.json"),serde_json::json!({"small_cut_limit":ps.max_inputs,"library_wide_cells":count,"cells":audit,"global_work_allowance":ps.max_instances.saturating_mul(16),"work_used":search.visits,"global_new_candidates":admitted,"seed_index_keys":index_keys,"index_filter":ps.wide_index_filter,"new_enodes":0,"all_physical_candidates_enter_common_cap":true,"structurally_complete":false}).to_string());}
 stats.wide_trials=search.visits;stats.wide_candidates=admitted;stats.wide_work_limit_hit|=search.work==0;
}
#[cfg(test)]mod tests {
 use super::*;
 #[test]fn actual_support_reconstructs_all_assignments(){
  let mut c=Cell{name:"redundant".into(),out_pin:"Y".into(),area:1.,vars:(0..9).map(|i|format!("X{i}")).collect(),expr:Expr::Const(false),pin_delay:BTreeMap::new(),tt:[0;8]};
  for a in 0..512 {if (a&1!=0)^(a&256!=0){tt9_bit_set(&mut c.tt,a);}}
  let s=support(&c);assert_eq!(s.positions,vec![0,8]);assert_eq!(s.truth[0],6);assert!(s.truth[1..].iter().all(|v|*v==0));
  for a in 0..512{let b=(a&1)|((a>>7)&2);assert_eq!(tt9_bit_get(&s.truth,b),tt9_bit_get(&c.tt,a));}
 }
 #[test]fn empty_work_never_returns_unverified_binding(){let nodes=vec![vec![AigLang::Pi(1)]];let mut s=Search{nodes:&nodes,dense:&|_|0,constants:&[None,None],work:0,visits:0,atoms:BTreeMap::new()};assert!(s.matches(&Pattern::Var(0),0,&[None]).is_empty());}
}
#[cfg(test)]mod decomposition_tests {
 use super::*;
 fn eval(p:&Pattern,a:usize)->bool{match p{Pattern::Var(v)=>a&(1<<v)!=0,Pattern::Const(v)=>*v,Pattern::Not(p)=>!eval(p,a),Pattern::And(x,y)=>eval(x,a)&eval(y,a)}}
 #[test]fn disjoint_decomposition_never_changes_truth(){for tt in 0..256{let truth:Vec<_>=(0..8).map(|a|tt&(1<<a)!=0).collect();if let Some(p)=decompose(&[0,1,2],&truth){for a in 0..8{assert_eq!(eval(&p,a),truth[a],"truth {tt} assignment {a}");}}}}
 #[test]fn wide_physical_arcs_use_only_actual_support(){let f=PhysicalFunction{positions:vec![0,8],truth:{let mut t=[0;8];t[0]=6;t}};let o=OutputPin{wide_function:Some(Box::new(f)),sources:vec![],name:"Y".into(),delays:vec![1.;9],function:0,targets:vec![]};for i in 0..9{assert_eq!(o.has_arc(i),i==0||i==8);}for a in 0..512{assert_eq!(o.value(a),(a&1!=0)^(a&256!=0));}}
}
#[cfg(test)]mod compact_tests {
 use super::*;
 #[test] fn nine_input_match_crosses_compact_function_nodes(){
  let vars:Vec<_>=(0..9).map(|i|format!("X{i}")).collect();
  fn group(v:&[String])->Expr {Expr::And(Box::new(Expr::And(Box::new(Expr::Var(v[0].clone())),Box::new(Expr::Var(v[1].clone())))),Box::new(Expr::Var(v[2].clone())))}
  let expr=Expr::Or(Box::new(Expr::Or(Box::new(group(&vars[0..3])),Box::new(group(&vars[3..6])))),Box::new(group(&vars[6..9])));
  let mut tt=[0;8];for a in 0..512{if a&7==7||a&56==56||a&448==448{tt9_bit_set(&mut tt,a);}}
  let c=Cell{name:"AO333".into(),area:1.,out_pin:"Y".into(),pin_delay:vars.iter().map(|v|(v.clone(),1.)).collect(),vars,expr,tt};let mut tech=TechLib::default();tech.cells.push(c);
  let mut nodes:Vec<Vec<_>>=(0..9).map(|i|vec![AigLang::Pi(i+1)]).collect();
  for i in 0..3{nodes.push(vec![AigLang::Cell("@egm_tt3_80".into(),(i*3..i*3+3).map(Id::from).collect())]);}
  nodes.push(vec![AigLang::Cell("@egm_tt3_fe".into(),(9..12).map(Id::from).collect())]);
  let free:Vec<_>=(0..26).map(|s|s/2<9&&s%2==0).collect();let mut pool=vec![];let mut stats=MapStats::default();
  generate(&nodes,&usize::from,&tech,&MapParams{wide_cells:true,max_instances:10000,..Default::default()},&free,&vec![None;26],None,&mut pool,&mut stats);
  let m=pool.iter().find(|m|m.outputs[0].targets.contains(&24)).expect("wide candidate cannot cross TT3 nodes");
  assert_eq!(m.inputs.len(),9);for a in 0..512{let tuple=m.inputs.iter().enumerate().fold(0,|v,(p,s)|v|(((((a>>(s/2))&1)^(s%2)))<<p));assert_eq!(m.outputs[0].value(tuple),tt9_bit_get(&tt,a));}
 }
}
#[cfg(test)]mod atom_oracles {
 use super::*;
 fn eval(t:&MatchTerm,a:usize)->bool{match t{MatchTerm::Wire(s)=>((a>>(s/2))&1)^(s%2)!=0,MatchTerm::Const(v)=>*v,MatchTerm::Not(t)=>!eval(t,a),MatchTerm::And(x,y)=>eval(x,a)&eval(y,a)}}
 #[test]fn function_node_expansions_preserve_truth_and_phase(){for n in [2,3,4]{let mut state=17u64;for sample in 0..4096{state=state.wrapping_mul(6364136223846793005).wrapping_add(1);let tt=if n<4{sample as u64&mask(n)}else{state&65535};let vars:Vec<_>=(0..n).collect();let truth:Vec<_>=(0..1usize<<n).map(|a|tt&(1<<a)!=0).collect();let p=decompose(&vars,&truth).unwrap_or_else(||shannon(&vars,&truth));let term=MatchTerm::compile(&p,&(0..n).map(|i|i*2).collect::<Vec<_>>());for a in 0..1usize<<n{assert_eq!(eval(&term,a),truth[a]);assert_eq!(eval(&term.clone().not(),a),!truth[a]);}}}}
 #[test]fn unnamed_atom_internals_cannot_become_physical_inputs(){let nodes=vec![vec![AigLang::Pi(1)],vec![AigLang::Pi(2)]];let mut s=Search{nodes:&nodes,dense:&usize::from,constants:&[None;4],work:100,visits:0,atoms:BTreeMap::new()};assert!(s.match_term(&Pattern::Var(0),MatchTerm::And(Box::new(MatchTerm::Wire(0)),Box::new(MatchTerm::Wire(2))),&[None]).is_empty());}
}

#[cfg(test)]mod index_filter_tests {
 use super::*;
 fn instance(name:&str,width:usize)->Instance{Instance{cell:name.into(),area:1.,inputs:(0..width).map(|i|i*2).collect(),input_pins:(0..width).map(|i|format!("I{i}")).collect(),outputs:vec![OutputPin{wide_function:None,sources:vec![],name:"Y".into(),function:8,delays:vec![1.;width],targets:vec![100]}]}}
 #[test]fn wide_index_does_not_rebuild_unrelated_small_cell_keys(){let mut pool=vec![instance("SMALL",2);1000];pool.push(instance("WIDE",2));let names=HashSet::from(["WIDE"]);let(old,oldkeys)=seed_index(&pool,&names,false);let(new,newkeys)=seed_index(&pool,&names,true);assert_eq!(oldkeys,1001);assert_eq!(newkeys,1,"unrelated cell names still rebuild physical keys");for(k,i)in new{assert_eq!(old.get(&k),Some(&i));}}
}

#[cfg(test)]mod filtered_pool_oracle {
 use super::*;
 #[test]fn complete_candidate_pool_and_evidence_match_unfiltered_reference(){
  let vars:Vec<_>=(0..7).map(|i|format!("X{i}")).collect();let mut expr=Expr::Var(vars[0].clone());for v in &vars[1..]{expr=Expr::And(Box::new(expr),Box::new(Expr::Var(v.clone())));}
  let mut tt=[0;8];tt9_bit_set(&mut tt,127);let mut tech=TechLib::default();tech.cells.push(Cell{name:"WIDE".into(),out_pin:"Y".into(),area:1.,vars:vars.clone(),expr,tt,pin_delay:vars.iter().map(|v|(v.clone(),1.)).collect()});
  let mut nodes:Vec<Vec<_>>=(0..7).map(|i|vec![AigLang::Pi(i+1)]).collect();let mut r=Id::from(0);for i in 1..7{nodes.push(vec![AigLang::And([r,Id::from(i)])]);r=Id::from(nodes.len()-1);}
  let free:Vec<_>=(0..nodes.len()*2).map(|s|s/2<7&&s%2==0).collect();let constants=vec![None;free.len()];
  let prefix=Instance{cell:"SMALL".into(),area:1.,inputs:vec![0,2],input_pins:vec!["A".into(),"B".into()],outputs:vec![OutputPin{wide_function:None,sources:vec![],name:"Y".into(),function:8,delays:vec![1.;2],targets:vec![14]}]};
  let mut pool=vec![prefix;1000];let ps=MapParams{wide_cells:true,protected_exchange:true,max_instances:10000,..Default::default()};
  generate(&nodes,&usize::from,&tech,&ps,&free,&constants,None,&mut pool,&mut MapStats::default());assert!(pool.len()>1000);
  // Existing wide rows, including a duplicate key, must still seed the index.
  pool.push(pool.last().unwrap().clone());
  let mut a=pool.clone();let mut b=pool.clone();let mut old=ps.clone();old.wide_index_filter=false;let mut new=ps;new.wide_index_filter=true;
  generate(&nodes,&usize::from,&tech,&old,&free,&constants,None,&mut a,&mut MapStats::default());
  generate(&nodes,&usize::from,&tech,&new,&free,&constants,None,&mut b,&mut MapStats::default());
  assert_eq!(format!("{a:?}"),format!("{b:?}"),"filter changed physical order, functions, pins, timings, targets, or binding evidence");
 }
}
