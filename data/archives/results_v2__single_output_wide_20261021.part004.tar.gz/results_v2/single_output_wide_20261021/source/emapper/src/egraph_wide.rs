//! Library-directed exact structural matches. No wide-cut Cartesian products or pin permutations.
//! Incomplete under both structure and work limits; no conditional equality is unioned into egg.
use super::*;
use crate::tt9::{tt9_bit_get,tt9_bit_set,Tt9};

#[derive(Clone,Debug)]
pub(super) struct PhysicalFunction { pub(super) positions:Vec<usize>, truth:Tt9 }
impl PhysicalFunction {
 pub(super) fn value(&self, assignment:usize)->bool {let a=self.positions.iter().enumerate().fold(0,|v,(i,p)|v|(((assignment>>p)&1)<<i));tt9_bit_get(&self.truth,a)}
}
#[derive(Clone,Debug)]
struct Support { positions:Vec<usize>, truth:Tt9 }
fn support(cell:&Cell)->Support {
 let n=cell.vars.len();
 let positions:Vec<_>=(0..n).filter(|&p|(0..1usize<<n).filter(|a|a&(1<<p)==0).any(|a|tt9_bit_get(&cell.tt,a)!=tt9_bit_get(&cell.tt,a|(1<<p)))).collect();
 let mut truth=[0;8];
 for a in 0..1usize<<positions.len(){let raw=positions.iter().enumerate().fold(0,|v,(i,p)|v|(((a>>i)&1)<<p));if tt9_bit_get(&cell.tt,raw){tt9_bit_set(&mut truth,a);}}
 Support{positions,truth}
}
#[derive(Clone)] enum Pattern {Var(usize),Const(bool),Not(Box<Pattern>),And(Box<Pattern>,Box<Pattern>)}
fn pattern(e:&Expr,cell:&Cell,s:&Support)->Pattern {
 match e {
  Expr::Const(v)=>Pattern::Const(*v),
  Expr::Var(v)=>{let p=cell.vars.iter().position(|n|n==v).unwrap();if s.positions.contains(&p){Pattern::Var(p)}else{Pattern::Const(false)}},
  Expr::Not(a)=>Pattern::Not(Box::new(pattern(a,cell,s))),
  Expr::And(a,b)=>Pattern::And(Box::new(pattern(a,cell,s)),Box::new(pattern(b,cell,s))),
  Expr::Or(a,b)=>Pattern::Not(Box::new(Pattern::And(Box::new(Pattern::Not(Box::new(pattern(a,cell,s)))),Box::new(Pattern::Not(Box::new(pattern(b,cell,s))))))),
 }
}
// Exact disjoint AND/OR decomposition of the actual-support function. This
// avoids requiring a library's expanded SOP text to occur literally in the AIG.
fn decompose(vars:&[usize],truth:&[bool])->Option<Pattern>{
 if truth.iter().all(|v|!*v){return Some(Pattern::Const(false))}
 if truth.iter().all(|v|*v){return Some(Pattern::Const(true))}
 if vars.len()==1 {let v=Pattern::Var(vars[0]);return Some(if truth[0]{Pattern::Not(Box::new(v))}else{v})}
 for bits in 1..1usize<<vars.len(){
  if bits&1==0||bits.count_ones()as usize==vars.len(){continue}
  let left:Vec<_>=(0..vars.len()).filter(|p|bits&(1<<p)!=0).collect();let right:Vec<_>=(0..vars.len()).filter(|p|bits&(1<<p)==0).collect();
  let project=|a:usize,p:&[usize]|p.iter().enumerate().fold(0,|v,(i,k)|v|(((a>>k)&1)<<i));
  for or in [false,true]{let mut a=vec![or;1<<left.len()];let mut b=vec![or;1<<right.len()];
   for (x,&v)in truth.iter().enumerate(){let i=project(x,&left);let j=project(x,&right);if or {a[i]&=v;b[j]&=v;}else{a[i]|=v;b[j]|=v;}}
   if !truth.iter().enumerate().all(|(x,&v)|v==if or{a[project(x,&left)]|b[project(x,&right)]}else{a[project(x,&left)]&b[project(x,&right)]}){continue}
   if let (Some(a),Some(b))=(decompose(&left.iter().map(|i|vars[*i]).collect::<Vec<_>>(),&a),decompose(&right.iter().map(|i|vars[*i]).collect::<Vec<_>>(),&b)){
    return Some(if or{Pattern::Not(Box::new(Pattern::And(Box::new(Pattern::Not(Box::new(a))),Box::new(Pattern::Not(Box::new(b))))))}else{Pattern::And(Box::new(a),Box::new(b))});
   }
  }
 }
 None
}
struct Search<'a,F:Fn(Id)->usize> {nodes:&'a [Vec<AigLang>],dense:&'a F,constants:&'a [Option<bool>],work:usize,visits:usize}
impl<F:Fn(Id)->usize> Search<'_,F> {
 fn ands(&mut self,s:usize,seen:&mut BTreeSet<usize>,out:&mut Vec<(usize,usize)>){
  if self.work==0||!seen.insert(s){return}self.work-=1;self.visits+=1;
  for node in &self.nodes[s/2] {
   if let AigLang::Not(a)=node {self.ands((self.dense)(*a)*2+(s%2^1),seen,out);}
   if s%2==0 {if let Some((a,b,phase))=literal_inputs(node){out.push(((self.dense)(a)*2+usize::from(phase&1),(self.dense)(b)*2+usize::from((phase>>1)&1)));}}
  }
 }
 fn matches(&mut self,p:&Pattern,s:usize,bind:&[Option<usize>])->Vec<Vec<Option<usize>>> {
  if self.work==0{return vec![]}self.work-=1;self.visits+=1;
  match p {
   Pattern::Var(i)=>{if bind[*i].is_some_and(|v|v!=s){vec![]}else{let mut b=bind.to_vec();b[*i]=Some(s);vec![b]}},
   Pattern::Const(v)=>if self.constants[s]==Some(*v){vec![bind.to_vec()]}else{vec![]},
   Pattern::Not(p)=>self.matches(p,s^1,bind),
   Pattern::And(a,b)=>{let mut pairs=vec![];self.ands(s,&mut BTreeSet::new(),&mut pairs);let mut result=vec![];
    for (x,y) in pairs {for (x,y) in [(x,y),(y,x)]{for state in self.matches(a,x,bind){result.extend(self.matches(b,y,&state));if self.work==0{return result}}}}
    result
   }
  }
 }
}
pub(super) fn generate<F:Fn(Id)->usize>(nodes:&[Vec<AigLang>],dense:&F,tech:&TechLib,ps:&MapParams,free:&[bool],constants:&[Option<bool>],aliases:Option<(&[usize],&[bool])>,pool:&mut Vec<Instance>,stats:&mut MapStats){
 // Isolated experimental source: loader explicitly opts in to this module.
 let wide:Vec<_>=tech.cells.iter().filter(|c|c.vars.len()>6 && c.vars.len()<=9 && tech.cells.iter().filter(|v|v.name==c.name).count()==1).collect();
 if !ps.wide_cells || wide.is_empty(){return}
 let zero=constants.iter().position(|v|*v==Some(false));
 let mut search=Search{nodes,dense,constants,work:ps.max_instances.saturating_mul(16),visits:0};
 let mut index:HashMap<_,_>=pool.iter().enumerate().map(|(i,m)|(instance_key(m),i)).collect();
 let mut admitted=0;let mut audit=vec![];
 let mut remaining=search.work;let count=wide.len();
 for (ordinal,cell) in wide.into_iter().enumerate() {
  // Fair work allocation shares one total allowance; no cell gets a new budget.
  let quota=remaining/(count-ordinal);search.work=quota;let before=admitted;
  let support=support(cell);let truth:Vec<_>=(0..1usize<<support.positions.len()).map(|a|tt9_bit_get(&support.truth,a)).collect();
  let mut patterns=vec![];if let Some(p)=decompose(&support.positions,&truth){patterns.push(p)}patterns.push(pattern(&cell.expr,cell,&support));
  for pat in &patterns {
  for target in 0..free.len(){
   if free[target]{continue}
   for bind in search.matches(pat,target,&vec![None;cell.vars.len()]) {
    if admitted>=ps.max_instances {stats.wide_work_limit_hit=true;break}
    // Inessential physical pins are tied off, not silently omitted from exported instances.
    let Some(inputs)=bind.iter().enumerate().map(|(p,s)|if support.positions.contains(&p){*s}else{zero}).collect::<Option<Vec<_>>>()else{continue};
    if inputs.iter().any(|s|s/2==target/2){continue}
    let mut m=Instance{cell:cell.name.clone(),area:cell.area,inputs,input_pins:cell.vars.clone(),outputs:vec![OutputPin{wide_function:Some(Box::new(PhysicalFunction{positions:support.positions.clone(),truth:support.truth})),sources:vec![],name:cell.out_pin.clone(),delays:cell.vars.iter().map(|p|cell.pin_delay.get(p).copied().unwrap_or(0.)).collect(),function:cell.tt[0],targets:vec![target]}]};
    if ps.protected_exchange {exchange::record_wide(&mut m,aliases);}
    if let Some((a,f))=aliases {if !normalize_physical_instance(&mut m,a,f){continue}}
    let count=pool.len();insert_instance(&mut *pool,&mut index,m);admitted+=usize::from(pool.len()>count);
   }
   if search.work==0||admitted>=ps.max_instances{break}
  }
  if search.work==0||admitted>=ps.max_instances{break}
  }
  audit.push(serde_json::json!({"cell":cell.name,"physical_inputs":cell.vars.len(),"actual_support":support.positions.len(),"candidates":admitted-before,"work_quota":quota,"work_used":quota-search.work,"work_exhausted":search.work==0}));
  remaining-=quota-search.work;stats.wide_work_limit_hit|=search.work==0;
  if admitted>=ps.max_instances{break}
 }
 if let Some(path)=std::env::var_os("EGM_POOL_DIAG_PATH"){let _=std::fs::write(std::path::Path::new(&path).with_extension("wide-generation.json"),serde_json::json!({"small_cut_limit":ps.max_inputs,"library_wide_cells":count,"cells":audit,"global_work_allowance":ps.max_instances.saturating_mul(16),"work_used":search.visits,"global_new_candidates":admitted,"new_enodes":0,"all_physical_candidates_enter_common_cap":true,"structurally_complete":false}).to_string());}
 stats.wide_trials=search.visits;stats.wide_candidates=admitted;stats.wide_work_limit_hit|=search.work==0;
}
#[cfg(test)]mod tests {
 use super::*;
 #[test]fn actual_support_reconstructs_all_assignments(){
  let mut c=Cell{name:"redundant".into(),out_pin:"Y".into(),area:1.,vars:(0..9).map(|i|format!("X{i}")).collect(),expr:Expr::Const(false),pin_delay:BTreeMap::new(),tt:[0;8]};
  for a in 0..512 {if (a&1!=0)^(a&256!=0){tt9_bit_set(&mut c.tt,a);}}
  let s=support(&c);assert_eq!(s.positions,vec![0,8]);assert_eq!(s.truth[0],6);assert!(s.truth[1..].iter().all(|v|*v==0));
  for a in 0..512{let b=(a&1)|((a>>7)&2);assert_eq!(tt9_bit_get(&s.truth,b),tt9_bit_get(&c.tt,a));}
 }
 #[test]fn empty_work_never_returns_unverified_binding(){let nodes=vec![vec![AigLang::Pi(1)]];let mut s=Search{nodes:&nodes,dense:&|_|0,constants:&[None,None],work:0,visits:0};assert!(s.matches(&Pattern::Var(0),0,&[None]).is_empty());}
}
#[cfg(test)]mod decomposition_tests {
 use super::*;
 fn eval(p:&Pattern,a:usize)->bool{match p{Pattern::Var(v)=>a&(1<<v)!=0,Pattern::Const(v)=>*v,Pattern::Not(p)=>!eval(p,a),Pattern::And(x,y)=>eval(x,a)&eval(y,a)}}
 #[test]fn disjoint_decomposition_never_changes_truth(){for tt in 0..256{let truth:Vec<_>=(0..8).map(|a|tt&(1<<a)!=0).collect();if let Some(p)=decompose(&[0,1,2],&truth){for a in 0..8{assert_eq!(eval(&p,a),truth[a],"truth {tt} assignment {a}");}}}}
 #[test]fn wide_physical_arcs_use_only_actual_support(){let f=PhysicalFunction{positions:vec![0,8],truth:{let mut t=[0;8];t[0]=6;t}};let o=OutputPin{wide_function:Some(Box::new(f)),sources:vec![],name:"Y".into(),delays:vec![1.;9],function:0,targets:vec![]};for i in 0..9{assert_eq!(o.has_arc(i),i==0||i==8);}for a in 0..512{assert_eq!(o.value(a),(a&1!=0)^(a&256!=0));}}
}
