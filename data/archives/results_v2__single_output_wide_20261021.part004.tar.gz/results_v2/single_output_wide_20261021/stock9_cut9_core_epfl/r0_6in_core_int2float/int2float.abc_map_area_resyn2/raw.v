// Benchmark "/home/flynn/workplace/MIGBalance/results_v2/single_output_wide_20261021/stock9_cut9_core_epfl/r0_6in_core_int2float/int2float.resyn2" written by ABC on Wed Oct 21 12:10:34 2026

module \/home/flynn/workplace/MIGBalance/results_v2/single_output_wide_20261021/stock9_cut9_core_epfl/r0_6in_core_int2float/int2float.resyn2  ( 
    \B[0] , \B[1] , \B[2] , \B[3] , \B[4] , \B[5] , \B[6] , \B[7] , \B[8] ,
    \B[9] , \B[10] ,
    \M[0] , \M[1] , \M[2] , \M[3] , \E[0] , \E[1] , \E[2]   );
  input  \B[0] , \B[1] , \B[2] , \B[3] , \B[4] , \B[5] , \B[6] , \B[7] ,
    \B[8] , \B[9] , \B[10] ;
  output \M[0] , \M[1] , \M[2] , \M[3] , \E[0] , \E[1] , \E[2] ;
  wire new_n19_, new_n20_, new_n21_, new_n22_, new_n23_, new_n24_, new_n25_,
    new_n26_, new_n27_, new_n28_, new_n29_, new_n30_, new_n31_, new_n32_,
    new_n33_, new_n34_, new_n35_, new_n36_, new_n37_, new_n38_, new_n39_,
    new_n40_, new_n41_, new_n42_, new_n43_, new_n44_, new_n45_, new_n46_,
    new_n47_, new_n48_, new_n49_, new_n50_, new_n51_, new_n52_, new_n53_,
    new_n54_, new_n55_, new_n56_, new_n57_, new_n59_, new_n60_, new_n61_,
    new_n62_, new_n63_, new_n64_, new_n65_, new_n66_, new_n67_, new_n68_,
    new_n69_, new_n70_, new_n71_, new_n72_, new_n73_, new_n74_, new_n75_,
    new_n76_, new_n77_, new_n78_, new_n79_, new_n80_, new_n81_, new_n82_,
    new_n83_, new_n84_, new_n85_, new_n86_, new_n87_, new_n88_, new_n89_,
    new_n90_, new_n92_, new_n93_, new_n94_, new_n95_, new_n96_, new_n97_,
    new_n98_, new_n99_, new_n100_, new_n101_, new_n102_, new_n103_,
    new_n104_, new_n105_, new_n106_, new_n107_, new_n108_, new_n109_,
    new_n110_, new_n111_, new_n112_, new_n113_, new_n114_, new_n115_,
    new_n116_, new_n118_, new_n119_, new_n120_, new_n121_, new_n123_,
    new_n124_, new_n125_, new_n126_, new_n127_, new_n128_, new_n129_,
    new_n130_, new_n131_, new_n132_, new_n133_, new_n135_, new_n136_,
    new_n137_, new_n138_, new_n139_, new_n140_;
  INVx1_ASAP7_75t_R    g000(.A(\B[10] ), .Y(new_n19_));
  INVx1_ASAP7_75t_R    g001(.A(\B[9] ), .Y(new_n20_));
  INVx1_ASAP7_75t_R    g002(.A(\B[5] ), .Y(new_n21_));
  INVx1_ASAP7_75t_R    g003(.A(\B[8] ), .Y(new_n22_));
  INVx1_ASAP7_75t_R    g004(.A(\B[0] ), .Y(new_n23_));
  NAND2x1_ASAP7_75t_R  g005(.A(\B[1] ), .B(\B[4] ), .Y(new_n24_));
  INVx1_ASAP7_75t_R    g006(.A(\B[4] ), .Y(new_n25_));
  NAND2x1_ASAP7_75t_R  g007(.A(\B[8] ), .B(new_n25_), .Y(new_n26_));
  AO21x1_ASAP7_75t_R   g008(.A1(new_n26_), .A2(new_n24_), .B(new_n23_), .Y(new_n27_));
  AO21x1_ASAP7_75t_R   g009(.A1(\B[1] ), .A2(\B[4] ), .B(\B[0] ), .Y(new_n28_));
  NOR2x1_ASAP7_75t_R   g010(.A(\B[6] ), .B(\B[7] ), .Y(new_n29_));
  AO32x1_ASAP7_75t_R   g011(.A1(new_n28_), .A2(new_n27_), .A3(new_n29_), .B1(\B[4] ), .B2(\B[8] ), .Y(new_n30_));
  NOR2x1_ASAP7_75t_R   g012(.A(\B[2] ), .B(\B[7] ), .Y(new_n31_));
  AO32x1_ASAP7_75t_R   g013(.A1(\B[1] ), .A2(new_n31_), .A3(\B[5] ), .B1(new_n25_), .B2(\B[7] ), .Y(new_n32_));
  INVx1_ASAP7_75t_R    g014(.A(\B[3] ), .Y(new_n33_));
  AND2x2_ASAP7_75t_R   g015(.A(new_n33_), .B(\B[4] ), .Y(new_n34_));
  AO22x1_ASAP7_75t_R   g016(.A1(new_n32_), .A2(\B[3] ), .B1(\B[7] ), .B2(new_n34_), .Y(new_n35_));
  AND3x1_ASAP7_75t_R   g017(.A(new_n25_), .B(\B[5] ), .C(\B[8] ), .Y(new_n36_));
  AO221x2_ASAP7_75t_R  g018(.A1(new_n22_), .A2(new_n35_), .B1(new_n21_), .B2(new_n30_), .C(new_n36_), .Y(new_n37_));
  INVx1_ASAP7_75t_R    g019(.A(\B[6] ), .Y(new_n38_));
  OR3x1_ASAP7_75t_R    g020(.A(new_n38_), .B(new_n20_), .C(\B[5] ), .Y(new_n39_));
  INVx1_ASAP7_75t_R    g021(.A(\B[2] ), .Y(new_n40_));
  NAND2x1_ASAP7_75t_R  g022(.A(\B[1] ), .B(new_n40_), .Y(new_n41_));
  AO21x1_ASAP7_75t_R   g023(.A1(new_n25_), .A2(\B[7] ), .B(new_n41_), .Y(new_n42_));
  AND2x2_ASAP7_75t_R   g024(.A(\B[3] ), .B(\B[4] ), .Y(new_n43_));
  AO21x1_ASAP7_75t_R   g025(.A1(\B[4] ), .A2(\B[8] ), .B(new_n43_), .Y(new_n44_));
  INVx1_ASAP7_75t_R    g026(.A(\B[7] ), .Y(new_n45_));
  NAND2x1_ASAP7_75t_R  g027(.A(new_n45_), .B(new_n22_), .Y(new_n46_));
  OR3x1_ASAP7_75t_R    g028(.A(new_n46_), .B(\B[1] ), .C(new_n40_), .Y(new_n47_));
  OA211x2_ASAP7_75t_R  g029(.A1(new_n42_), .A2(new_n44_), .B(new_n47_), .C(new_n20_), .Y(new_n48_));
  OR3x1_ASAP7_75t_R    g030(.A(new_n48_), .B(new_n21_), .C(\B[6] ), .Y(new_n49_));
  NAND2x1_ASAP7_75t_R  g031(.A(new_n39_), .B(new_n49_), .Y(new_n50_));
  AO21x1_ASAP7_75t_R   g032(.A1(new_n37_), .A2(new_n20_), .B(new_n50_), .Y(new_n51_));
  AND2x2_ASAP7_75t_R   g033(.A(new_n38_), .B(\B[7] ), .Y(new_n52_));
  XOR2x2_ASAP7_75t_R   g034(.A(\B[2] ), .B(\B[3] ), .Y(new_n53_));
  NOR2x1_ASAP7_75t_R   g035(.A(\B[8] ), .B(\B[9] ), .Y(new_n54_));
  AO21x1_ASAP7_75t_R   g036(.A1(new_n53_), .A2(new_n54_), .B(\B[10] ), .Y(new_n55_));
  AO32x1_ASAP7_75t_R   g037(.A1(\B[8] ), .A2(\B[9] ), .A3(\B[10] ), .B1(new_n45_), .B2(new_n55_), .Y(new_n56_));
  AO22x1_ASAP7_75t_R   g038(.A1(new_n56_), .A2(\B[6] ), .B1(\B[10] ), .B2(new_n52_), .Y(new_n57_));
  AO21x1_ASAP7_75t_R   g039(.A1(new_n51_), .A2(new_n19_), .B(new_n57_), .Y(\M[0] ));
  AO21x1_ASAP7_75t_R   g040(.A1(\B[1] ), .A2(\B[2] ), .B(new_n23_), .Y(new_n59_));
  OA211x2_ASAP7_75t_R  g041(.A1(\B[0] ), .A2(new_n40_), .B(new_n45_), .C(\B[4] ), .Y(new_n60_));
  INVx1_ASAP7_75t_R    g042(.A(\B[1] ), .Y(new_n61_));
  NOR2x1_ASAP7_75t_R   g043(.A(\B[4] ), .B(\B[9] ), .Y(new_n62_));
  OA21x2_ASAP7_75t_R   g044(.A1(new_n31_), .A2(new_n62_), .B(new_n61_), .Y(new_n63_));
  AOI221x1_ASAP7_75t_R g045(.A1(\B[8] ), .A2(new_n20_), .B1(new_n59_), .B2(new_n60_), .C(new_n63_), .Y(new_n64_));
  NOR2x1_ASAP7_75t_R   g046(.A(\B[6] ), .B(new_n64_), .Y(new_n65_));
  AND2x2_ASAP7_75t_R   g047(.A(new_n45_), .B(\B[9] ), .Y(new_n66_));
  INVx1_ASAP7_75t_R    g048(.A(new_n43_), .Y(new_n67_));
  AND3x1_ASAP7_75t_R   g049(.A(new_n67_), .B(\B[7] ), .C(new_n54_), .Y(new_n68_));
  OR3x1_ASAP7_75t_R    g050(.A(new_n65_), .B(new_n66_), .C(new_n68_), .Y(new_n69_));
  NAND2x1_ASAP7_75t_R  g051(.A(\B[1] ), .B(\B[2] ), .Y(new_n70_));
  NAND2x1_ASAP7_75t_R  g052(.A(new_n25_), .B(new_n38_), .Y(new_n71_));
  OR3x1_ASAP7_75t_R    g053(.A(new_n71_), .B(\B[7] ), .C(new_n70_), .Y(new_n72_));
  OR3x1_ASAP7_75t_R    g054(.A(new_n25_), .B(\B[8] ), .C(\B[9] ), .Y(new_n73_));
  AO21x1_ASAP7_75t_R   g055(.A1(new_n45_), .A2(new_n70_), .B(new_n73_), .Y(new_n74_));
  AO21x1_ASAP7_75t_R   g056(.A1(new_n72_), .A2(new_n74_), .B(new_n33_), .Y(new_n75_));
  OR4x2_ASAP7_75t_R    g057(.A(new_n66_), .B(new_n38_), .C(new_n54_), .D(new_n62_), .Y(new_n76_));
  AOI21x1_ASAP7_75t_R  g058(.A1(new_n76_), .A2(new_n75_), .B(new_n21_), .Y(new_n77_));
  AND3x1_ASAP7_75t_R   g059(.A(new_n25_), .B(new_n20_), .C(\B[8] ), .Y(new_n78_));
  OA21x2_ASAP7_75t_R   g060(.A1(new_n78_), .A2(new_n66_), .B(new_n38_), .Y(new_n79_));
  AOI211x1_ASAP7_75t_R g061(.A1(new_n69_), .A2(new_n21_), .B(new_n77_), .C(new_n79_), .Y(new_n80_));
  OR5x1_ASAP7_75t_R    g062(.A(new_n38_), .B(new_n45_), .C(new_n22_), .D(new_n19_), .E(\B[9] ), .Y(new_n81_));
  AND3x1_ASAP7_75t_R   g063(.A(new_n25_), .B(new_n20_), .C(\B[6] ), .Y(new_n82_));
  AND3x1_ASAP7_75t_R   g064(.A(new_n61_), .B(new_n38_), .C(\B[5] ), .Y(new_n83_));
  OAI21x1_ASAP7_75t_R  g065(.A1(new_n82_), .A2(new_n83_), .B(new_n33_), .Y(new_n84_));
  AND2x2_ASAP7_75t_R   g066(.A(new_n33_), .B(\B[5] ), .Y(new_n85_));
  AO21x1_ASAP7_75t_R   g067(.A1(new_n38_), .A2(new_n85_), .B(new_n82_), .Y(new_n86_));
  AND5x1_ASAP7_75t_R   g068(.A(\B[2] ), .B(new_n20_), .C(\B[3] ), .D(\B[4] ), .E(\B[6] ), .Y(new_n87_));
  AOI21x1_ASAP7_75t_R  g069(.A1(new_n40_), .A2(new_n86_), .B(new_n87_), .Y(new_n88_));
  AO21x1_ASAP7_75t_R   g070(.A1(new_n88_), .A2(new_n84_), .B(\B[7] ), .Y(new_n89_));
  AO221x2_ASAP7_75t_R  g071(.A1(\B[6] ), .A2(\B[7] ), .B1(new_n19_), .B2(new_n89_), .C(\B[8] ), .Y(new_n90_));
  OA211x2_ASAP7_75t_R  g072(.A1(new_n80_), .A2(\B[10] ), .B(new_n81_), .C(new_n90_), .Y(\M[1] ));
  AND2x2_ASAP7_75t_R   g073(.A(new_n25_), .B(\B[5] ), .Y(new_n92_));
  AO32x1_ASAP7_75t_R   g074(.A1(\B[0] ), .A2(new_n34_), .A3(new_n38_), .B1(\B[3] ), .B2(new_n92_), .Y(new_n93_));
  AO21x1_ASAP7_75t_R   g075(.A1(\B[0] ), .A2(\B[1] ), .B(new_n67_), .Y(new_n94_));
  AOI21x1_ASAP7_75t_R  g076(.A1(new_n71_), .A2(new_n94_), .B(\B[5] ), .Y(new_n95_));
  AO21x1_ASAP7_75t_R   g077(.A1(new_n93_), .A2(\B[1] ), .B(new_n95_), .Y(new_n96_));
  AND3x1_ASAP7_75t_R   g078(.A(new_n40_), .B(new_n38_), .C(\B[3] ), .Y(new_n97_));
  OA21x2_ASAP7_75t_R   g079(.A1(new_n97_), .A2(new_n85_), .B(\B[4] ), .Y(new_n98_));
  AO21x1_ASAP7_75t_R   g080(.A1(new_n96_), .A2(\B[2] ), .B(new_n98_), .Y(new_n99_));
  AND2x2_ASAP7_75t_R   g081(.A(\B[5] ), .B(\B[6] ), .Y(new_n100_));
  AND3x1_ASAP7_75t_R   g082(.A(new_n21_), .B(\B[2] ), .C(\B[6] ), .Y(new_n101_));
  OA21x2_ASAP7_75t_R   g083(.A1(new_n83_), .A2(new_n101_), .B(new_n43_), .Y(new_n102_));
  AO221x2_ASAP7_75t_R  g084(.A1(new_n67_), .A2(new_n100_), .B1(new_n45_), .B2(new_n99_), .C(new_n102_), .Y(new_n103_));
  AND2x2_ASAP7_75t_R   g085(.A(\B[4] ), .B(\B[5] ), .Y(new_n104_));
  OA211x2_ASAP7_75t_R  g086(.A1(new_n25_), .A2(new_n21_), .B(\B[6] ), .C(\B[7] ), .Y(new_n105_));
  AND3x1_ASAP7_75t_R   g087(.A(new_n40_), .B(new_n45_), .C(\B[6] ), .Y(new_n106_));
  AO21x1_ASAP7_75t_R   g088(.A1(\B[3] ), .A2(new_n52_), .B(new_n106_), .Y(new_n107_));
  AO221x2_ASAP7_75t_R  g089(.A1(new_n104_), .A2(new_n107_), .B1(new_n22_), .B2(new_n103_), .C(new_n105_), .Y(new_n108_));
  AND3x1_ASAP7_75t_R   g090(.A(new_n104_), .B(\B[6] ), .C(new_n45_), .Y(new_n109_));
  OA21x2_ASAP7_75t_R   g091(.A1(new_n109_), .A2(new_n52_), .B(\B[8] ), .Y(new_n110_));
  AO21x1_ASAP7_75t_R   g092(.A1(new_n108_), .A2(new_n20_), .B(new_n110_), .Y(new_n111_));
  AND3x1_ASAP7_75t_R   g093(.A(new_n22_), .B(\B[5] ), .C(\B[9] ), .Y(new_n112_));
  AO21x1_ASAP7_75t_R   g094(.A1(\B[8] ), .A2(\B[10] ), .B(new_n112_), .Y(new_n113_));
  NAND2x1_ASAP7_75t_R  g095(.A(\B[5] ), .B(\B[7] ), .Y(new_n114_));
  AO21x1_ASAP7_75t_R   g096(.A1(new_n114_), .A2(\B[8] ), .B(\B[10] ), .Y(new_n115_));
  AO32x1_ASAP7_75t_R   g097(.A1(\B[6] ), .A2(new_n113_), .A3(\B[7] ), .B1(\B[9] ), .B2(new_n115_), .Y(new_n116_));
  AO21x1_ASAP7_75t_R   g098(.A1(new_n111_), .A2(new_n19_), .B(new_n116_), .Y(\M[2] ));
  AND3x1_ASAP7_75t_R   g099(.A(\B[5] ), .B(\B[6] ), .C(\B[7] ), .Y(new_n118_));
  AND4x2_ASAP7_75t_R   g100(.A(new_n118_), .B(new_n40_), .C(\B[4] ), .D(\B[8] ), .Y(new_n119_));
  AND5x1_ASAP7_75t_R   g101(.A(new_n25_), .B(new_n21_), .C(new_n38_), .D(new_n45_), .E(new_n22_), .Y(new_n120_));
  AND3x1_ASAP7_75t_R   g102(.A(new_n33_), .B(new_n20_), .C(new_n19_), .Y(new_n121_));
  OAI21x1_ASAP7_75t_R  g103(.A1(new_n120_), .A2(new_n119_), .B(new_n121_), .Y(\M[3] ));
  AO32x1_ASAP7_75t_R   g104(.A1(\B[1] ), .A2(new_n45_), .A3(\B[2] ), .B1(\B[5] ), .B2(\B[6] ), .Y(new_n123_));
  AO22x1_ASAP7_75t_R   g105(.A1(new_n123_), .A2(\B[3] ), .B1(new_n21_), .B2(new_n45_), .Y(new_n124_));
  AOI22x1_ASAP7_75t_R  g106(.A1(\B[6] ), .A2(new_n45_), .B1(new_n124_), .B2(\B[4] ), .Y(new_n125_));
  AND4x2_ASAP7_75t_R   g107(.A(new_n21_), .B(new_n38_), .C(\B[0] ), .D(\B[1] ), .Y(new_n126_));
  OA211x2_ASAP7_75t_R  g108(.A1(new_n109_), .A2(new_n126_), .B(\B[2] ), .C(\B[3] ), .Y(new_n127_));
  OA21x2_ASAP7_75t_R   g109(.A1(new_n125_), .A2(new_n127_), .B(new_n22_), .Y(new_n128_));
  AND3x1_ASAP7_75t_R   g110(.A(new_n20_), .B(\B[6] ), .C(\B[7] ), .Y(new_n129_));
  NAND2x1_ASAP7_75t_R  g111(.A(\B[8] ), .B(new_n118_), .Y(new_n130_));
  AND2x2_ASAP7_75t_R   g112(.A(\B[3] ), .B(\B[8] ), .Y(new_n131_));
  AO21x1_ASAP7_75t_R   g113(.A1(\B[2] ), .A2(new_n33_), .B(new_n131_), .Y(new_n132_));
  AO32x1_ASAP7_75t_R   g114(.A1(new_n129_), .A2(new_n104_), .A3(new_n132_), .B1(\B[9] ), .B2(new_n130_), .Y(new_n133_));
  OAI21x1_ASAP7_75t_R  g115(.A1(new_n133_), .A2(new_n128_), .B(new_n19_), .Y(\E[0] ));
  AND4x2_ASAP7_75t_R   g116(.A(new_n22_), .B(\B[0] ), .C(\B[1] ), .D(\B[3] ), .Y(new_n135_));
  AO32x1_ASAP7_75t_R   g117(.A1(new_n21_), .A2(new_n135_), .A3(new_n45_), .B1(\B[8] ), .B2(new_n118_), .Y(new_n136_));
  AOI22x1_ASAP7_75t_R  g118(.A1(new_n118_), .A2(new_n131_), .B1(new_n136_), .B2(\B[2] ), .Y(new_n137_));
  AND3x1_ASAP7_75t_R   g119(.A(new_n43_), .B(new_n100_), .C(\B[2] ), .Y(new_n138_));
  AO21x1_ASAP7_75t_R   g120(.A1(new_n21_), .A2(new_n38_), .B(new_n46_), .Y(new_n139_));
  OA211x2_ASAP7_75t_R  g121(.A1(new_n139_), .A2(new_n138_), .B(new_n20_), .C(new_n19_), .Y(new_n140_));
  OAI21x1_ASAP7_75t_R  g122(.A1(new_n25_), .A2(new_n137_), .B(new_n140_), .Y(\E[1] ));
  OR4x2_ASAP7_75t_R    g123(.A(new_n138_), .B(\B[9] ), .C(\B[10] ), .D(new_n46_), .Y(\E[2] ));
endmodule


