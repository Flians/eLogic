// Benchmark "/home/flynn/workplace/MIGBalance/results_v2/single_output_wide_20261021/stock9_cut9_core_epfl/r0_6in_core_cavlc/cavlc.resyn2" written by ABC on Wed Oct 21 12:10:04 2026

module \/home/flynn/workplace/MIGBalance/results_v2/single_output_wide_20261021/stock9_cut9_core_epfl/r0_6in_core_cavlc/cavlc.resyn2  ( 
    \totalcoeffs[0] , \totalcoeffs[1] , \totalcoeffs[2] , \totalcoeffs[3] ,
    \totalcoeffs[4] , \ctable[0] , \ctable[1] , \ctable[2] ,
    \trailingones[0] , \trailingones[1] ,
    \coeff_token[0] , \coeff_token[1] , \coeff_token[2] , \coeff_token[3] ,
    \coeff_token[4] , \coeff_token[5] , \ctoken_len[0] , \ctoken_len[1] ,
    \ctoken_len[2] , \ctoken_len[3] , \ctoken_len[4]   );
  input  \totalcoeffs[0] , \totalcoeffs[1] , \totalcoeffs[2] ,
    \totalcoeffs[3] , \totalcoeffs[4] , \ctable[0] , \ctable[1] ,
    \ctable[2] , \trailingones[0] , \trailingones[1] ;
  output \coeff_token[0] , \coeff_token[1] , \coeff_token[2] ,
    \coeff_token[3] , \coeff_token[4] , \coeff_token[5] , \ctoken_len[0] ,
    \ctoken_len[1] , \ctoken_len[2] , \ctoken_len[3] , \ctoken_len[4] ;
  wire new_n22_, new_n23_, new_n24_, new_n25_, new_n26_, new_n27_, new_n28_,
    new_n29_, new_n30_, new_n31_, new_n32_, new_n33_, new_n34_, new_n35_,
    new_n36_, new_n37_, new_n38_, new_n39_, new_n40_, new_n41_, new_n42_,
    new_n43_, new_n44_, new_n45_, new_n46_, new_n47_, new_n48_, new_n49_,
    new_n50_, new_n51_, new_n52_, new_n53_, new_n54_, new_n55_, new_n56_,
    new_n57_, new_n58_, new_n59_, new_n60_, new_n61_, new_n62_, new_n63_,
    new_n64_, new_n65_, new_n66_, new_n67_, new_n68_, new_n69_, new_n70_,
    new_n71_, new_n72_, new_n73_, new_n74_, new_n75_, new_n76_, new_n77_,
    new_n78_, new_n79_, new_n80_, new_n81_, new_n82_, new_n83_, new_n84_,
    new_n85_, new_n86_, new_n87_, new_n88_, new_n89_, new_n90_, new_n91_,
    new_n92_, new_n93_, new_n94_, new_n95_, new_n96_, new_n97_, new_n98_,
    new_n100_, new_n101_, new_n102_, new_n103_, new_n104_, new_n105_,
    new_n106_, new_n107_, new_n108_, new_n109_, new_n110_, new_n111_,
    new_n112_, new_n113_, new_n114_, new_n115_, new_n116_, new_n117_,
    new_n118_, new_n119_, new_n120_, new_n121_, new_n122_, new_n123_,
    new_n124_, new_n125_, new_n126_, new_n127_, new_n128_, new_n129_,
    new_n130_, new_n131_, new_n132_, new_n133_, new_n134_, new_n135_,
    new_n136_, new_n137_, new_n138_, new_n139_, new_n140_, new_n141_,
    new_n142_, new_n143_, new_n144_, new_n145_, new_n146_, new_n147_,
    new_n148_, new_n149_, new_n150_, new_n151_, new_n152_, new_n153_,
    new_n154_, new_n155_, new_n156_, new_n157_, new_n158_, new_n159_,
    new_n160_, new_n161_, new_n162_, new_n163_, new_n164_, new_n166_,
    new_n167_, new_n168_, new_n169_, new_n170_, new_n171_, new_n172_,
    new_n173_, new_n174_, new_n175_, new_n176_, new_n177_, new_n178_,
    new_n179_, new_n180_, new_n181_, new_n182_, new_n183_, new_n184_,
    new_n185_, new_n186_, new_n187_, new_n188_, new_n189_, new_n190_,
    new_n191_, new_n192_, new_n193_, new_n194_, new_n195_, new_n196_,
    new_n197_, new_n198_, new_n199_, new_n200_, new_n201_, new_n202_,
    new_n203_, new_n204_, new_n205_, new_n206_, new_n207_, new_n208_,
    new_n209_, new_n210_, new_n211_, new_n212_, new_n213_, new_n214_,
    new_n215_, new_n217_, new_n218_, new_n219_, new_n220_, new_n221_,
    new_n222_, new_n223_, new_n224_, new_n225_, new_n226_, new_n227_,
    new_n228_, new_n229_, new_n230_, new_n231_, new_n232_, new_n233_,
    new_n234_, new_n235_, new_n236_, new_n237_, new_n238_, new_n239_,
    new_n240_, new_n241_, new_n242_, new_n243_, new_n244_, new_n245_,
    new_n246_, new_n247_, new_n248_, new_n249_, new_n250_, new_n251_,
    new_n252_, new_n253_, new_n254_, new_n255_, new_n256_, new_n257_,
    new_n258_, new_n259_, new_n260_, new_n262_, new_n263_, new_n264_,
    new_n265_, new_n267_, new_n268_, new_n269_, new_n271_, new_n272_,
    new_n273_, new_n274_, new_n275_, new_n276_, new_n277_, new_n278_,
    new_n279_, new_n280_, new_n281_, new_n282_, new_n283_, new_n284_,
    new_n285_, new_n286_, new_n287_, new_n288_, new_n289_, new_n290_,
    new_n291_, new_n292_, new_n293_, new_n294_, new_n295_, new_n296_,
    new_n297_, new_n298_, new_n299_, new_n300_, new_n301_, new_n302_,
    new_n303_, new_n304_, new_n305_, new_n306_, new_n307_, new_n308_,
    new_n309_, new_n310_, new_n312_, new_n313_, new_n314_, new_n315_,
    new_n316_, new_n317_, new_n318_, new_n319_, new_n320_, new_n321_,
    new_n322_, new_n323_, new_n324_, new_n325_, new_n326_, new_n327_,
    new_n328_, new_n329_, new_n330_, new_n331_, new_n332_, new_n333_,
    new_n334_, new_n335_, new_n336_, new_n337_, new_n338_, new_n339_,
    new_n340_, new_n341_, new_n342_, new_n343_, new_n344_, new_n345_,
    new_n346_, new_n347_, new_n348_, new_n349_, new_n350_, new_n351_,
    new_n352_, new_n353_, new_n354_, new_n355_, new_n356_, new_n357_,
    new_n358_, new_n359_, new_n361_, new_n362_, new_n363_, new_n364_,
    new_n365_, new_n366_, new_n367_, new_n368_, new_n369_, new_n370_,
    new_n371_, new_n372_, new_n373_, new_n374_, new_n375_, new_n376_,
    new_n377_, new_n378_, new_n379_, new_n380_, new_n381_, new_n382_,
    new_n383_, new_n384_, new_n385_, new_n386_, new_n387_, new_n388_,
    new_n389_, new_n390_, new_n391_, new_n393_, new_n394_, new_n395_,
    new_n396_, new_n397_, new_n398_, new_n399_, new_n400_, new_n401_,
    new_n402_, new_n403_, new_n404_, new_n405_, new_n406_, new_n407_,
    new_n408_, new_n409_, new_n411_, new_n412_, new_n413_;
  INVx1_ASAP7_75t_R    g000(.A(\totalcoeffs[4] ), .Y(new_n22_));
  INVx1_ASAP7_75t_R    g001(.A(\ctable[2] ), .Y(new_n23_));
  INVx1_ASAP7_75t_R    g002(.A(\ctable[1] ), .Y(new_n24_));
  INVx1_ASAP7_75t_R    g003(.A(\totalcoeffs[3] ), .Y(new_n25_));
  INVx1_ASAP7_75t_R    g004(.A(\totalcoeffs[2] ), .Y(new_n26_));
  INVx1_ASAP7_75t_R    g005(.A(\ctable[0] ), .Y(new_n27_));
  AND3x1_ASAP7_75t_R   g006(.A(new_n27_), .B(\ctable[2] ), .C(\trailingones[0] ), .Y(new_n28_));
  AND2x2_ASAP7_75t_R   g007(.A(new_n23_), .B(\trailingones[1] ), .Y(new_n29_));
  OA21x2_ASAP7_75t_R   g008(.A1(new_n28_), .A2(new_n29_), .B(\totalcoeffs[1] ), .Y(new_n30_));
  INVx1_ASAP7_75t_R    g009(.A(\totalcoeffs[1] ), .Y(new_n31_));
  NOR2x1_ASAP7_75t_R   g010(.A(\ctable[0] ), .B(\trailingones[1] ), .Y(new_n32_));
  OA21x2_ASAP7_75t_R   g011(.A1(new_n31_), .A2(\ctable[2] ), .B(new_n32_), .Y(new_n33_));
  OA211x2_ASAP7_75t_R  g012(.A1(new_n30_), .A2(new_n33_), .B(\totalcoeffs[0] ), .C(new_n26_), .Y(new_n34_));
  INVx1_ASAP7_75t_R    g013(.A(\trailingones[1] ), .Y(new_n35_));
  NOR2x1_ASAP7_75t_R   g014(.A(\totalcoeffs[0] ), .B(\totalcoeffs[1] ), .Y(new_n36_));
  AND3x1_ASAP7_75t_R   g015(.A(new_n36_), .B(\totalcoeffs[2] ), .C(new_n35_), .Y(new_n37_));
  AND2x2_ASAP7_75t_R   g016(.A(new_n37_), .B(new_n28_), .Y(new_n38_));
  OA21x2_ASAP7_75t_R   g017(.A1(new_n34_), .A2(new_n38_), .B(new_n25_), .Y(new_n39_));
  OA21x2_ASAP7_75t_R   g018(.A1(new_n35_), .A2(\totalcoeffs[0] ), .B(\totalcoeffs[1] ), .Y(new_n40_));
  AND2x2_ASAP7_75t_R   g019(.A(new_n31_), .B(\trailingones[1] ), .Y(new_n41_));
  OR4x2_ASAP7_75t_R    g020(.A(new_n41_), .B(new_n40_), .C(\totalcoeffs[3] ), .D(\ctable[0] ), .Y(new_n42_));
  NAND2x1_ASAP7_75t_R  g021(.A(\totalcoeffs[0] ), .B(new_n35_), .Y(new_n43_));
  AO21x1_ASAP7_75t_R   g022(.A1(new_n35_), .A2(\totalcoeffs[1] ), .B(\ctable[2] ), .Y(new_n44_));
  AO21x1_ASAP7_75t_R   g023(.A1(new_n43_), .A2(new_n31_), .B(new_n44_), .Y(new_n45_));
  AO21x1_ASAP7_75t_R   g024(.A1(new_n42_), .A2(new_n45_), .B(\totalcoeffs[2] ), .Y(new_n46_));
  AND2x2_ASAP7_75t_R   g025(.A(\totalcoeffs[1] ), .B(\totalcoeffs[2] ), .Y(new_n47_));
  INVx1_ASAP7_75t_R    g026(.A(\totalcoeffs[0] ), .Y(new_n48_));
  OA21x2_ASAP7_75t_R   g027(.A1(\totalcoeffs[2] ), .A2(\ctable[0] ), .B(new_n48_), .Y(new_n49_));
  OAI21x1_ASAP7_75t_R  g028(.A1(new_n47_), .A2(new_n49_), .B(new_n35_), .Y(new_n50_));
  AO21x1_ASAP7_75t_R   g029(.A1(new_n26_), .A2(new_n25_), .B(new_n35_), .Y(new_n51_));
  NAND2x1_ASAP7_75t_R  g030(.A(\totalcoeffs[0] ), .B(\totalcoeffs[3] ), .Y(new_n52_));
  AO21x1_ASAP7_75t_R   g031(.A1(new_n51_), .A2(new_n52_), .B(\totalcoeffs[1] ), .Y(new_n53_));
  OA21x2_ASAP7_75t_R   g032(.A1(new_n31_), .A2(\totalcoeffs[3] ), .B(new_n53_), .Y(new_n54_));
  AO21x1_ASAP7_75t_R   g033(.A1(new_n54_), .A2(new_n50_), .B(\ctable[2] ), .Y(new_n55_));
  AOI21x1_ASAP7_75t_R  g034(.A1(new_n46_), .A2(new_n55_), .B(\trailingones[0] ), .Y(new_n56_));
  OA21x2_ASAP7_75t_R   g035(.A1(new_n56_), .A2(new_n39_), .B(new_n24_), .Y(new_n57_));
  NAND2x1_ASAP7_75t_R  g036(.A(\trailingones[1] ), .B(new_n48_), .Y(new_n58_));
  NOR2x1_ASAP7_75t_R   g037(.A(\totalcoeffs[0] ), .B(\totalcoeffs[2] ), .Y(new_n59_));
  AO21x1_ASAP7_75t_R   g038(.A1(new_n41_), .A2(new_n59_), .B(\ctable[0] ), .Y(new_n60_));
  AND3x1_ASAP7_75t_R   g039(.A(\totalcoeffs[1] ), .B(\totalcoeffs[2] ), .C(\ctable[0] ), .Y(new_n61_));
  AO32x1_ASAP7_75t_R   g040(.A1(new_n58_), .A2(new_n43_), .A3(new_n61_), .B1(\ctable[1] ), .B2(new_n60_), .Y(new_n62_));
  AO21x1_ASAP7_75t_R   g041(.A1(new_n58_), .A2(new_n31_), .B(\trailingones[0] ), .Y(new_n63_));
  NAND2x1_ASAP7_75t_R  g042(.A(\totalcoeffs[2] ), .B(new_n31_), .Y(new_n64_));
  OAI21x1_ASAP7_75t_R  g043(.A1(new_n43_), .A2(new_n64_), .B(new_n63_), .Y(new_n65_));
  AO22x1_ASAP7_75t_R   g044(.A1(new_n62_), .A2(\trailingones[0] ), .B1(new_n27_), .B2(new_n65_), .Y(new_n66_));
  AO21x1_ASAP7_75t_R   g045(.A1(new_n35_), .A2(\totalcoeffs[0] ), .B(\totalcoeffs[2] ), .Y(new_n67_));
  AO21x1_ASAP7_75t_R   g046(.A1(new_n40_), .A2(new_n25_), .B(new_n67_), .Y(new_n68_));
  NAND2x1_ASAP7_75t_R  g047(.A(new_n24_), .B(new_n67_), .Y(new_n69_));
  AND2x2_ASAP7_75t_R   g048(.A(new_n35_), .B(\totalcoeffs[1] ), .Y(new_n70_));
  AND2x2_ASAP7_75t_R   g049(.A(\totalcoeffs[2] ), .B(\trailingones[1] ), .Y(new_n71_));
  AO21x1_ASAP7_75t_R   g050(.A1(new_n70_), .A2(new_n26_), .B(new_n71_), .Y(new_n72_));
  AND3x1_ASAP7_75t_R   g051(.A(new_n48_), .B(new_n25_), .C(\ctable[1] ), .Y(new_n73_));
  AO32x1_ASAP7_75t_R   g052(.A1(\ctable[0] ), .A2(new_n69_), .A3(new_n68_), .B1(new_n73_), .B2(new_n72_), .Y(new_n74_));
  INVx1_ASAP7_75t_R    g053(.A(\trailingones[0] ), .Y(new_n75_));
  NOR2x1_ASAP7_75t_R   g054(.A(\totalcoeffs[2] ), .B(\totalcoeffs[3] ), .Y(new_n76_));
  NOR2x1_ASAP7_75t_R   g055(.A(\totalcoeffs[1] ), .B(\trailingones[1] ), .Y(new_n77_));
  AND4x2_ASAP7_75t_R   g056(.A(new_n76_), .B(new_n77_), .C(new_n48_), .D(new_n75_), .Y(new_n78_));
  AO32x1_ASAP7_75t_R   g057(.A1(\totalcoeffs[2] ), .A2(new_n41_), .A3(new_n25_), .B1(\totalcoeffs[1] ), .B2(new_n75_), .Y(new_n79_));
  AO21x1_ASAP7_75t_R   g058(.A1(new_n26_), .A2(\ctable[1] ), .B(new_n25_), .Y(new_n80_));
  AO21x1_ASAP7_75t_R   g059(.A1(new_n80_), .A2(new_n77_), .B(new_n71_), .Y(new_n81_));
  AO22x1_ASAP7_75t_R   g060(.A1(new_n79_), .A2(new_n48_), .B1(new_n75_), .B2(new_n81_), .Y(new_n82_));
  AO21x1_ASAP7_75t_R   g061(.A1(new_n82_), .A2(new_n27_), .B(new_n78_), .Y(new_n83_));
  AO221x2_ASAP7_75t_R  g062(.A1(\trailingones[0] ), .A2(new_n74_), .B1(\totalcoeffs[3] ), .B2(new_n66_), .C(new_n83_), .Y(new_n84_));
  AO21x1_ASAP7_75t_R   g063(.A1(new_n23_), .A2(new_n84_), .B(new_n57_), .Y(new_n85_));
  AND2x2_ASAP7_75t_R   g064(.A(new_n24_), .B(\trailingones[0] ), .Y(new_n86_));
  NOR2x1_ASAP7_75t_R   g065(.A(new_n27_), .B(new_n86_), .Y(new_n87_));
  AND2x2_ASAP7_75t_R   g066(.A(\totalcoeffs[4] ), .B(\trailingones[0] ), .Y(new_n88_));
  NAND2x1_ASAP7_75t_R  g067(.A(new_n24_), .B(new_n35_), .Y(new_n89_));
  INVx1_ASAP7_75t_R    g068(.A(new_n89_), .Y(new_n90_));
  OA21x2_ASAP7_75t_R   g069(.A1(new_n88_), .A2(new_n90_), .B(new_n87_), .Y(new_n91_));
  NAND2x1_ASAP7_75t_R  g070(.A(\ctable[1] ), .B(new_n35_), .Y(new_n92_));
  OAI21x1_ASAP7_75t_R  g071(.A1(new_n22_), .A2(new_n35_), .B(new_n92_), .Y(new_n93_));
  NAND2x1_ASAP7_75t_R  g072(.A(\ctable[0] ), .B(\ctable[1] ), .Y(new_n94_));
  AND3x1_ASAP7_75t_R   g073(.A(new_n93_), .B(new_n75_), .C(new_n94_), .Y(new_n95_));
  NOR2x1_ASAP7_75t_R   g074(.A(\totalcoeffs[1] ), .B(\totalcoeffs[3] ), .Y(new_n96_));
  AND3x1_ASAP7_75t_R   g075(.A(new_n59_), .B(new_n96_), .C(new_n23_), .Y(new_n97_));
  OA21x2_ASAP7_75t_R   g076(.A1(new_n95_), .A2(new_n91_), .B(new_n97_), .Y(new_n98_));
  AO21x1_ASAP7_75t_R   g077(.A1(new_n85_), .A2(new_n22_), .B(new_n98_), .Y(\coeff_token[0] ));
  NAND2x1_ASAP7_75t_R  g078(.A(\totalcoeffs[2] ), .B(new_n35_), .Y(new_n100_));
  INVx1_ASAP7_75t_R    g079(.A(new_n86_), .Y(new_n101_));
  AND2x2_ASAP7_75t_R   g080(.A(new_n75_), .B(\trailingones[1] ), .Y(new_n102_));
  AND2x2_ASAP7_75t_R   g081(.A(\ctable[1] ), .B(\trailingones[1] ), .Y(new_n103_));
  AO21x1_ASAP7_75t_R   g082(.A1(new_n27_), .A2(\trailingones[0] ), .B(new_n103_), .Y(new_n104_));
  AND2x2_ASAP7_75t_R   g083(.A(\ctable[1] ), .B(\trailingones[0] ), .Y(new_n105_));
  NOR2x1_ASAP7_75t_R   g084(.A(new_n48_), .B(new_n105_), .Y(new_n106_));
  AO32x1_ASAP7_75t_R   g085(.A1(new_n48_), .A2(\ctable[0] ), .A3(new_n102_), .B1(new_n104_), .B2(new_n106_), .Y(new_n107_));
  AND2x2_ASAP7_75t_R   g086(.A(new_n27_), .B(\trailingones[0] ), .Y(new_n108_));
  AO21x1_ASAP7_75t_R   g087(.A1(new_n48_), .A2(\ctable[1] ), .B(\totalcoeffs[2] ), .Y(new_n109_));
  AO22x1_ASAP7_75t_R   g088(.A1(new_n108_), .A2(new_n109_), .B1(new_n24_), .B2(new_n75_), .Y(new_n110_));
  AOI22x1_ASAP7_75t_R  g089(.A1(new_n35_), .A2(new_n110_), .B1(new_n107_), .B2(new_n26_), .Y(new_n111_));
  NOR2x1_ASAP7_75t_R   g090(.A(\totalcoeffs[2] ), .B(\trailingones[0] ), .Y(new_n112_));
  AND3x1_ASAP7_75t_R   g091(.A(\totalcoeffs[0] ), .B(\trailingones[0] ), .C(\trailingones[1] ), .Y(new_n113_));
  AO32x1_ASAP7_75t_R   g092(.A1(new_n48_), .A2(new_n35_), .A3(new_n112_), .B1(\totalcoeffs[2] ), .B2(new_n113_), .Y(new_n114_));
  NAND2x1_ASAP7_75t_R  g093(.A(\ctable[0] ), .B(new_n114_), .Y(new_n115_));
  OA21x2_ASAP7_75t_R   g094(.A1(new_n108_), .A2(new_n103_), .B(new_n48_), .Y(new_n116_));
  AO22x1_ASAP7_75t_R   g095(.A1(new_n32_), .A2(new_n75_), .B1(\trailingones[1] ), .B2(new_n105_), .Y(new_n117_));
  OAI21x1_ASAP7_75t_R  g096(.A1(new_n117_), .A2(new_n116_), .B(\totalcoeffs[2] ), .Y(new_n118_));
  AO21x1_ASAP7_75t_R   g097(.A1(new_n118_), .A2(new_n115_), .B(\totalcoeffs[1] ), .Y(new_n119_));
  OA221x2_ASAP7_75t_R  g098(.A1(new_n31_), .A2(new_n111_), .B1(new_n100_), .B2(new_n101_), .C(new_n119_), .Y(new_n120_));
  AND3x1_ASAP7_75t_R   g099(.A(new_n48_), .B(new_n31_), .C(new_n26_), .Y(new_n121_));
  AO21x1_ASAP7_75t_R   g100(.A1(\ctable[0] ), .A2(new_n75_), .B(new_n88_), .Y(new_n122_));
  AO22x1_ASAP7_75t_R   g101(.A1(new_n90_), .A2(new_n122_), .B1(\totalcoeffs[4] ), .B2(new_n103_), .Y(new_n123_));
  NAND2x1_ASAP7_75t_R  g102(.A(new_n121_), .B(new_n123_), .Y(new_n124_));
  OAI21x1_ASAP7_75t_R  g103(.A1(\totalcoeffs[4] ), .A2(new_n120_), .B(new_n124_), .Y(new_n125_));
  AND3x1_ASAP7_75t_R   g104(.A(new_n26_), .B(new_n75_), .C(\ctable[0] ), .Y(new_n126_));
  NAND2x1_ASAP7_75t_R  g105(.A(\trailingones[0] ), .B(new_n27_), .Y(new_n127_));
  NAND2x1_ASAP7_75t_R  g106(.A(new_n25_), .B(new_n75_), .Y(new_n128_));
  AND3x1_ASAP7_75t_R   g107(.A(new_n128_), .B(\totalcoeffs[0] ), .C(new_n127_), .Y(new_n129_));
  OA21x2_ASAP7_75t_R   g108(.A1(new_n129_), .A2(new_n126_), .B(new_n31_), .Y(new_n130_));
  AO21x1_ASAP7_75t_R   g109(.A1(\totalcoeffs[3] ), .A2(\trailingones[0] ), .B(\totalcoeffs[2] ), .Y(new_n131_));
  AND2x2_ASAP7_75t_R   g110(.A(new_n48_), .B(\ctable[0] ), .Y(new_n132_));
  AND3x1_ASAP7_75t_R   g111(.A(new_n26_), .B(\totalcoeffs[0] ), .C(\trailingones[0] ), .Y(new_n133_));
  AND2x2_ASAP7_75t_R   g112(.A(new_n27_), .B(\totalcoeffs[0] ), .Y(new_n134_));
  OR3x1_ASAP7_75t_R    g113(.A(new_n133_), .B(new_n132_), .C(new_n134_), .Y(new_n135_));
  AO22x1_ASAP7_75t_R   g114(.A1(new_n135_), .A2(\totalcoeffs[1] ), .B1(new_n48_), .B2(new_n131_), .Y(new_n136_));
  OA21x2_ASAP7_75t_R   g115(.A1(new_n136_), .A2(new_n130_), .B(new_n24_), .Y(new_n137_));
  NAND2x1_ASAP7_75t_R  g116(.A(new_n31_), .B(new_n75_), .Y(new_n138_));
  AND3x1_ASAP7_75t_R   g117(.A(new_n31_), .B(\ctable[1] ), .C(\trailingones[0] ), .Y(new_n139_));
  AO21x1_ASAP7_75t_R   g118(.A1(new_n26_), .A2(new_n138_), .B(new_n139_), .Y(new_n140_));
  NAND2x1_ASAP7_75t_R  g119(.A(\trailingones[0] ), .B(new_n48_), .Y(new_n141_));
  NAND2x1_ASAP7_75t_R  g120(.A(\totalcoeffs[0] ), .B(\totalcoeffs[1] ), .Y(new_n142_));
  OA21x2_ASAP7_75t_R   g121(.A1(\totalcoeffs[1] ), .A2(\ctable[1] ), .B(new_n142_), .Y(new_n143_));
  AO32x1_ASAP7_75t_R   g122(.A1(new_n26_), .A2(new_n141_), .A3(new_n143_), .B1(\totalcoeffs[3] ), .B2(new_n140_), .Y(new_n144_));
  AO21x1_ASAP7_75t_R   g123(.A1(new_n144_), .A2(new_n27_), .B(\trailingones[1] ), .Y(new_n145_));
  NAND2x1_ASAP7_75t_R  g124(.A(\totalcoeffs[1] ), .B(\ctable[0] ), .Y(new_n146_));
  OR4x2_ASAP7_75t_R    g125(.A(new_n25_), .B(\totalcoeffs[1] ), .C(\totalcoeffs[2] ), .D(\trailingones[0] ), .Y(new_n147_));
  AO21x1_ASAP7_75t_R   g126(.A1(new_n147_), .A2(new_n146_), .B(new_n48_), .Y(new_n148_));
  OR3x1_ASAP7_75t_R    g127(.A(new_n31_), .B(new_n26_), .C(new_n25_), .Y(new_n149_));
  AO21x1_ASAP7_75t_R   g128(.A1(new_n149_), .A2(new_n27_), .B(new_n76_), .Y(new_n150_));
  AO21x1_ASAP7_75t_R   g129(.A1(new_n148_), .A2(new_n150_), .B(new_n24_), .Y(new_n151_));
  OR3x1_ASAP7_75t_R    g130(.A(new_n149_), .B(new_n27_), .C(\trailingones[0] ), .Y(new_n152_));
  NAND3x1_ASAP7_75t_R  g131(.A(new_n151_), .B(new_n152_), .C(\trailingones[1] ), .Y(new_n153_));
  OA211x2_ASAP7_75t_R  g132(.A1(new_n137_), .A2(new_n145_), .B(new_n153_), .C(new_n22_), .Y(new_n154_));
  AOI21x1_ASAP7_75t_R  g133(.A1(new_n25_), .A2(new_n125_), .B(new_n154_), .Y(new_n155_));
  NAND2x1_ASAP7_75t_R  g134(.A(\totalcoeffs[1] ), .B(new_n35_), .Y(new_n156_));
  OR3x1_ASAP7_75t_R    g135(.A(new_n156_), .B(\totalcoeffs[2] ), .C(new_n75_), .Y(new_n157_));
  INVx1_ASAP7_75t_R    g136(.A(new_n36_), .Y(new_n158_));
  INVx1_ASAP7_75t_R    g137(.A(new_n67_), .Y(new_n159_));
  AO221x2_ASAP7_75t_R  g138(.A1(\totalcoeffs[2] ), .A2(new_n158_), .B1(new_n142_), .B2(new_n159_), .C(\trailingones[0] ), .Y(new_n160_));
  AOI21x1_ASAP7_75t_R  g139(.A1(new_n157_), .A2(new_n160_), .B(new_n23_), .Y(new_n161_));
  AND3x1_ASAP7_75t_R   g140(.A(new_n25_), .B(new_n27_), .C(new_n24_), .Y(new_n162_));
  AND2x2_ASAP7_75t_R   g141(.A(new_n162_), .B(new_n22_), .Y(new_n163_));
  OAI21x1_ASAP7_75t_R  g142(.A1(new_n37_), .A2(new_n161_), .B(new_n163_), .Y(new_n164_));
  OAI21x1_ASAP7_75t_R  g143(.A1(\ctable[2] ), .A2(new_n155_), .B(new_n164_), .Y(\coeff_token[1] ));
  XOR2x2_ASAP7_75t_R   g144(.A(\trailingones[0] ), .B(\trailingones[1] ), .Y(new_n166_));
  AO21x1_ASAP7_75t_R   g145(.A1(new_n31_), .A2(new_n35_), .B(new_n166_), .Y(new_n167_));
  NOR2x1_ASAP7_75t_R   g146(.A(\trailingones[0] ), .B(\trailingones[1] ), .Y(new_n168_));
  OR3x1_ASAP7_75t_R    g147(.A(new_n113_), .B(new_n27_), .C(new_n168_), .Y(new_n169_));
  OA21x2_ASAP7_75t_R   g148(.A1(new_n71_), .A2(\ctable[0] ), .B(\totalcoeffs[1] ), .Y(new_n170_));
  AO22x1_ASAP7_75t_R   g149(.A1(new_n167_), .A2(\totalcoeffs[2] ), .B1(new_n169_), .B2(new_n170_), .Y(new_n171_));
  OR3x1_ASAP7_75t_R    g150(.A(new_n51_), .B(\totalcoeffs[1] ), .C(new_n75_), .Y(new_n172_));
  INVx1_ASAP7_75t_R    g151(.A(new_n168_), .Y(new_n173_));
  OA21x2_ASAP7_75t_R   g152(.A1(new_n25_), .A2(\totalcoeffs[1] ), .B(\ctable[0] ), .Y(new_n174_));
  OR3x1_ASAP7_75t_R    g153(.A(new_n173_), .B(\totalcoeffs[2] ), .C(new_n174_), .Y(new_n175_));
  NAND2x1_ASAP7_75t_R  g154(.A(new_n172_), .B(new_n175_), .Y(new_n176_));
  AO22x1_ASAP7_75t_R   g155(.A1(new_n176_), .A2(\totalcoeffs[0] ), .B1(new_n25_), .B2(new_n171_), .Y(new_n177_));
  AO21x1_ASAP7_75t_R   g156(.A1(new_n31_), .A2(\trailingones[1] ), .B(new_n24_), .Y(new_n178_));
  AO21x1_ASAP7_75t_R   g157(.A1(new_n156_), .A2(new_n178_), .B(new_n75_), .Y(new_n179_));
  AND2x2_ASAP7_75t_R   g158(.A(\totalcoeffs[1] ), .B(\trailingones[1] ), .Y(new_n180_));
  NOR2x1_ASAP7_75t_R   g159(.A(new_n180_), .B(new_n77_), .Y(new_n181_));
  OAI21x1_ASAP7_75t_R  g160(.A1(new_n128_), .A2(new_n181_), .B(new_n179_), .Y(new_n182_));
  AO22x1_ASAP7_75t_R   g161(.A1(new_n180_), .A2(\totalcoeffs[2] ), .B1(new_n31_), .B2(\trailingones[0] ), .Y(new_n183_));
  AND3x1_ASAP7_75t_R   g162(.A(new_n75_), .B(new_n35_), .C(\totalcoeffs[2] ), .Y(new_n184_));
  AO221x2_ASAP7_75t_R  g163(.A1(\trailingones[0] ), .A2(new_n100_), .B1(\ctable[1] ), .B2(new_n183_), .C(new_n184_), .Y(new_n185_));
  AO22x1_ASAP7_75t_R   g164(.A1(new_n182_), .A2(new_n26_), .B1(\totalcoeffs[3] ), .B2(new_n185_), .Y(new_n186_));
  AO32x1_ASAP7_75t_R   g165(.A1(\totalcoeffs[0] ), .A2(new_n27_), .A3(new_n186_), .B1(new_n24_), .B2(new_n177_), .Y(new_n187_));
  AO21x1_ASAP7_75t_R   g166(.A1(new_n26_), .A2(\trailingones[0] ), .B(new_n25_), .Y(new_n188_));
  AO21x1_ASAP7_75t_R   g167(.A1(new_n27_), .A2(\totalcoeffs[2] ), .B(new_n25_), .Y(new_n189_));
  AOI22x1_ASAP7_75t_R  g168(.A1(new_n188_), .A2(\ctable[0] ), .B1(new_n189_), .B2(\trailingones[0] ), .Y(new_n190_));
  OR3x1_ASAP7_75t_R    g169(.A(new_n24_), .B(\totalcoeffs[3] ), .C(\ctable[0] ), .Y(new_n191_));
  OAI22x1_ASAP7_75t_R  g170(.A1(new_n138_), .A2(new_n191_), .B1(new_n190_), .B2(new_n31_), .Y(new_n192_));
  NAND2x1_ASAP7_75t_R  g171(.A(\totalcoeffs[1] ), .B(\trailingones[0] ), .Y(new_n193_));
  AO21x1_ASAP7_75t_R   g172(.A1(new_n193_), .A2(\ctable[1] ), .B(\trailingones[1] ), .Y(new_n194_));
  AO32x1_ASAP7_75t_R   g173(.A1(new_n31_), .A2(new_n75_), .A3(\trailingones[1] ), .B1(new_n26_), .B2(new_n194_), .Y(new_n195_));
  NOR2x1_ASAP7_75t_R   g174(.A(new_n26_), .B(new_n86_), .Y(new_n196_));
  OA211x2_ASAP7_75t_R  g175(.A1(new_n196_), .A2(new_n31_), .B(\ctable[0] ), .C(new_n131_), .Y(new_n197_));
  AO21x1_ASAP7_75t_R   g176(.A1(\totalcoeffs[3] ), .A2(new_n75_), .B(new_n70_), .Y(new_n198_));
  OA211x2_ASAP7_75t_R  g177(.A1(new_n25_), .A2(\trailingones[1] ), .B(new_n198_), .C(new_n24_), .Y(new_n199_));
  AND2x2_ASAP7_75t_R   g178(.A(new_n75_), .B(\ctable[1] ), .Y(new_n200_));
  AND3x1_ASAP7_75t_R   g179(.A(new_n25_), .B(\totalcoeffs[1] ), .C(\trailingones[1] ), .Y(new_n201_));
  AO21x1_ASAP7_75t_R   g180(.A1(new_n201_), .A2(new_n200_), .B(\totalcoeffs[4] ), .Y(new_n202_));
  OR3x1_ASAP7_75t_R    g181(.A(new_n197_), .B(new_n199_), .C(new_n202_), .Y(new_n203_));
  AO221x2_ASAP7_75t_R  g182(.A1(\totalcoeffs[3] ), .A2(new_n195_), .B1(new_n35_), .B2(new_n192_), .C(new_n203_), .Y(new_n204_));
  AND2x2_ASAP7_75t_R   g183(.A(\trailingones[0] ), .B(\trailingones[1] ), .Y(new_n205_));
  AO21x1_ASAP7_75t_R   g184(.A1(\ctable[1] ), .A2(new_n75_), .B(new_n205_), .Y(new_n206_));
  OR3x1_ASAP7_75t_R    g185(.A(\totalcoeffs[1] ), .B(\totalcoeffs[2] ), .C(\totalcoeffs[3] ), .Y(new_n207_));
  AO21x1_ASAP7_75t_R   g186(.A1(new_n206_), .A2(new_n27_), .B(new_n207_), .Y(new_n208_));
  AOI21x1_ASAP7_75t_R  g187(.A1(\totalcoeffs[4] ), .A2(new_n208_), .B(\totalcoeffs[0] ), .Y(new_n209_));
  AO22x1_ASAP7_75t_R   g188(.A1(new_n204_), .A2(new_n209_), .B1(new_n22_), .B2(new_n187_), .Y(new_n210_));
  INVx1_ASAP7_75t_R    g189(.A(new_n43_), .Y(new_n211_));
  AO21x1_ASAP7_75t_R   g190(.A1(new_n205_), .A2(\ctable[2] ), .B(new_n48_), .Y(new_n212_));
  AO32x1_ASAP7_75t_R   g191(.A1(new_n31_), .A2(new_n211_), .A3(new_n75_), .B1(new_n40_), .B2(new_n212_), .Y(new_n213_));
  NOR2x1_ASAP7_75t_R   g192(.A(\ctable[0] ), .B(\ctable[1] ), .Y(new_n214_));
  AND3x1_ASAP7_75t_R   g193(.A(new_n76_), .B(new_n214_), .C(new_n22_), .Y(new_n215_));
  AO22x1_ASAP7_75t_R   g194(.A1(new_n210_), .A2(new_n23_), .B1(new_n213_), .B2(new_n215_), .Y(\coeff_token[2] ));
  OR3x1_ASAP7_75t_R    g195(.A(\ctable[0] ), .B(\trailingones[0] ), .C(\trailingones[1] ), .Y(new_n217_));
  OR4x2_ASAP7_75t_R    g196(.A(new_n27_), .B(new_n75_), .C(new_n35_), .D(\ctable[1] ), .Y(new_n218_));
  AO21x1_ASAP7_75t_R   g197(.A1(new_n218_), .A2(new_n217_), .B(new_n26_), .Y(new_n219_));
  NAND2x1_ASAP7_75t_R  g198(.A(\ctable[1] ), .B(new_n75_), .Y(new_n220_));
  AO21x1_ASAP7_75t_R   g199(.A1(new_n220_), .A2(new_n25_), .B(new_n87_), .Y(new_n221_));
  AOI21x1_ASAP7_75t_R  g200(.A1(new_n219_), .A2(new_n221_), .B(new_n31_), .Y(new_n222_));
  OAI22x1_ASAP7_75t_R  g201(.A1(new_n25_), .A2(\trailingones[1] ), .B1(new_n76_), .B2(new_n24_), .Y(new_n223_));
  AO32x1_ASAP7_75t_R   g202(.A1(\totalcoeffs[2] ), .A2(new_n27_), .A3(\ctable[1] ), .B1(new_n31_), .B2(new_n223_), .Y(new_n224_));
  OAI21x1_ASAP7_75t_R  g203(.A1(new_n224_), .A2(new_n222_), .B(new_n22_), .Y(new_n225_));
  INVx1_ASAP7_75t_R    g204(.A(new_n214_), .Y(new_n226_));
  AND2x2_ASAP7_75t_R   g205(.A(new_n226_), .B(new_n94_), .Y(new_n227_));
  NOR2x1_ASAP7_75t_R   g206(.A(\ctable[0] ), .B(new_n205_), .Y(new_n228_));
  AND2x2_ASAP7_75t_R   g207(.A(new_n25_), .B(\totalcoeffs[4] ), .Y(new_n229_));
  INVx1_ASAP7_75t_R    g208(.A(new_n229_), .Y(new_n230_));
  OR5x1_ASAP7_75t_R    g209(.A(\totalcoeffs[1] ), .B(new_n227_), .C(\totalcoeffs[2] ), .D(new_n228_), .E(new_n230_), .Y(new_n231_));
  AO21x1_ASAP7_75t_R   g210(.A1(new_n225_), .A2(new_n231_), .B(\totalcoeffs[0] ), .Y(new_n232_));
  AO21x1_ASAP7_75t_R   g211(.A1(new_n128_), .A2(new_n127_), .B(new_n26_), .Y(new_n233_));
  OR3x1_ASAP7_75t_R    g212(.A(new_n27_), .B(new_n75_), .C(\totalcoeffs[2] ), .Y(new_n234_));
  AO21x1_ASAP7_75t_R   g213(.A1(new_n233_), .A2(new_n234_), .B(\trailingones[1] ), .Y(new_n235_));
  AO21x1_ASAP7_75t_R   g214(.A1(new_n102_), .A2(\ctable[0] ), .B(\totalcoeffs[3] ), .Y(new_n236_));
  AO21x1_ASAP7_75t_R   g215(.A1(new_n75_), .A2(\totalcoeffs[3] ), .B(\ctable[1] ), .Y(new_n237_));
  NAND2x1_ASAP7_75t_R  g216(.A(\totalcoeffs[3] ), .B(new_n27_), .Y(new_n238_));
  AOI22x1_ASAP7_75t_R  g217(.A1(new_n237_), .A2(new_n238_), .B1(new_n236_), .B2(new_n26_), .Y(new_n239_));
  AO21x1_ASAP7_75t_R   g218(.A1(new_n235_), .A2(new_n239_), .B(new_n31_), .Y(new_n240_));
  OR5x1_ASAP7_75t_R    g219(.A(\totalcoeffs[1] ), .B(new_n27_), .C(\totalcoeffs[2] ), .D(\ctable[1] ), .E(\trailingones[0] ), .Y(new_n241_));
  AO21x1_ASAP7_75t_R   g220(.A1(new_n241_), .A2(new_n191_), .B(\trailingones[1] ), .Y(new_n242_));
  AO21x1_ASAP7_75t_R   g221(.A1(new_n240_), .A2(new_n242_), .B(new_n48_), .Y(new_n243_));
  AND3x1_ASAP7_75t_R   g222(.A(new_n27_), .B(new_n35_), .C(\ctable[1] ), .Y(new_n244_));
  INVx1_ASAP7_75t_R    g223(.A(new_n244_), .Y(new_n245_));
  OR3x1_ASAP7_75t_R    g224(.A(new_n26_), .B(new_n25_), .C(\ctable[1] ), .Y(new_n246_));
  OR3x1_ASAP7_75t_R    g225(.A(new_n76_), .B(\ctable[0] ), .C(new_n24_), .Y(new_n247_));
  AO21x1_ASAP7_75t_R   g226(.A1(new_n247_), .A2(new_n246_), .B(new_n35_), .Y(new_n248_));
  NAND2x1_ASAP7_75t_R  g227(.A(\totalcoeffs[3] ), .B(new_n24_), .Y(new_n249_));
  AO21x1_ASAP7_75t_R   g228(.A1(new_n245_), .A2(new_n249_), .B(\trailingones[0] ), .Y(new_n250_));
  AO21x1_ASAP7_75t_R   g229(.A1(new_n250_), .A2(new_n248_), .B(\totalcoeffs[1] ), .Y(new_n251_));
  INVx1_ASAP7_75t_R    g230(.A(new_n32_), .Y(new_n252_));
  OA21x2_ASAP7_75t_R   g231(.A1(\ctable[1] ), .A2(\trailingones[0] ), .B(new_n252_), .Y(new_n253_));
  AO21x1_ASAP7_75t_R   g232(.A1(\ctable[0] ), .A2(\trailingones[1] ), .B(\ctable[1] ), .Y(new_n254_));
  NAND2x1_ASAP7_75t_R  g233(.A(\ctable[0] ), .B(\trailingones[0] ), .Y(new_n255_));
  OA21x2_ASAP7_75t_R   g234(.A1(new_n31_), .A2(new_n35_), .B(new_n255_), .Y(new_n256_));
  OAI22x1_ASAP7_75t_R  g235(.A1(new_n254_), .A2(new_n256_), .B1(new_n253_), .B2(\totalcoeffs[2] ), .Y(new_n257_));
  NAND2x1_ASAP7_75t_R  g236(.A(\totalcoeffs[3] ), .B(new_n257_), .Y(new_n258_));
  OA211x2_ASAP7_75t_R  g237(.A1(new_n193_), .A2(new_n245_), .B(new_n251_), .C(new_n258_), .Y(new_n259_));
  AO21x1_ASAP7_75t_R   g238(.A1(new_n259_), .A2(new_n243_), .B(\totalcoeffs[4] ), .Y(new_n260_));
  AOI21x1_ASAP7_75t_R  g239(.A1(new_n232_), .A2(new_n260_), .B(\ctable[2] ), .Y(\coeff_token[3] ));
  OR3x1_ASAP7_75t_R    g240(.A(new_n36_), .B(new_n26_), .C(\totalcoeffs[4] ), .Y(new_n262_));
  AND2x2_ASAP7_75t_R   g241(.A(new_n22_), .B(\totalcoeffs[3] ), .Y(new_n263_));
  OAI21x1_ASAP7_75t_R  g242(.A1(new_n229_), .A2(new_n263_), .B(new_n121_), .Y(new_n264_));
  OR3x1_ASAP7_75t_R    g243(.A(new_n27_), .B(new_n24_), .C(\ctable[2] ), .Y(new_n265_));
  AOI21x1_ASAP7_75t_R  g244(.A1(new_n262_), .A2(new_n264_), .B(new_n265_), .Y(\coeff_token[4] ));
  OR3x1_ASAP7_75t_R    g245(.A(new_n121_), .B(new_n25_), .C(\totalcoeffs[4] ), .Y(new_n267_));
  AND3x1_ASAP7_75t_R   g246(.A(new_n229_), .B(new_n26_), .C(new_n36_), .Y(new_n268_));
  INVx1_ASAP7_75t_R    g247(.A(new_n268_), .Y(new_n269_));
  AOI21x1_ASAP7_75t_R  g248(.A1(new_n267_), .A2(new_n269_), .B(new_n265_), .Y(\coeff_token[5] ));
  AO32x1_ASAP7_75t_R   g249(.A1(new_n36_), .A2(new_n76_), .A3(\totalcoeffs[4] ), .B1(\ctable[0] ), .B2(\ctable[1] ), .Y(new_n271_));
  OA21x2_ASAP7_75t_R   g250(.A1(new_n23_), .A2(\trailingones[1] ), .B(\trailingones[0] ), .Y(new_n272_));
  OAI22x1_ASAP7_75t_R  g251(.A1(new_n156_), .A2(\totalcoeffs[2] ), .B1(new_n64_), .B2(new_n272_), .Y(new_n273_));
  AO21x1_ASAP7_75t_R   g252(.A1(new_n113_), .A2(\totalcoeffs[1] ), .B(new_n168_), .Y(new_n274_));
  AO32x1_ASAP7_75t_R   g253(.A1(new_n26_), .A2(\ctable[2] ), .A3(new_n274_), .B1(new_n48_), .B2(new_n273_), .Y(new_n275_));
  AO21x1_ASAP7_75t_R   g254(.A1(new_n31_), .A2(new_n27_), .B(new_n26_), .Y(new_n276_));
  AO32x1_ASAP7_75t_R   g255(.A1(new_n24_), .A2(new_n276_), .A3(new_n35_), .B1(\ctable[0] ), .B2(new_n180_), .Y(new_n277_));
  AND2x2_ASAP7_75t_R   g256(.A(new_n48_), .B(\totalcoeffs[2] ), .Y(new_n278_));
  AO22x1_ASAP7_75t_R   g257(.A1(new_n277_), .A2(\totalcoeffs[0] ), .B1(new_n252_), .B2(new_n278_), .Y(new_n279_));
  AND2x2_ASAP7_75t_R   g258(.A(\totalcoeffs[2] ), .B(\trailingones[0] ), .Y(new_n280_));
  OR2x4_ASAP7_75t_R    g259(.A(new_n280_), .B(new_n112_), .Y(new_n281_));
  NOR2x1_ASAP7_75t_R   g260(.A(new_n24_), .B(new_n166_), .Y(new_n282_));
  AO32x1_ASAP7_75t_R   g261(.A1(new_n48_), .A2(\totalcoeffs[2] ), .A3(\trailingones[1] ), .B1(new_n75_), .B2(new_n77_), .Y(new_n283_));
  AO22x1_ASAP7_75t_R   g262(.A1(new_n282_), .A2(new_n281_), .B1(\ctable[0] ), .B2(new_n283_), .Y(new_n284_));
  AO21x1_ASAP7_75t_R   g263(.A1(new_n279_), .A2(\trailingones[0] ), .B(new_n284_), .Y(new_n285_));
  AOI22x1_ASAP7_75t_R  g264(.A1(new_n214_), .A2(new_n275_), .B1(new_n285_), .B2(new_n23_), .Y(new_n286_));
  AO32x1_ASAP7_75t_R   g265(.A1(new_n48_), .A2(new_n138_), .A3(new_n24_), .B1(\totalcoeffs[1] ), .B2(\totalcoeffs[2] ), .Y(new_n287_));
  AO21x1_ASAP7_75t_R   g266(.A1(new_n75_), .A2(new_n35_), .B(\totalcoeffs[1] ), .Y(new_n288_));
  AND3x1_ASAP7_75t_R   g267(.A(new_n156_), .B(new_n288_), .C(\totalcoeffs[0] ), .Y(new_n289_));
  AOI21x1_ASAP7_75t_R  g268(.A1(new_n181_), .A2(new_n287_), .B(new_n289_), .Y(new_n290_));
  OR3x1_ASAP7_75t_R    g269(.A(new_n278_), .B(new_n31_), .C(\trailingones[0] ), .Y(new_n291_));
  OR4x2_ASAP7_75t_R    g270(.A(new_n48_), .B(new_n24_), .C(new_n75_), .D(\totalcoeffs[2] ), .Y(new_n292_));
  AO21x1_ASAP7_75t_R   g271(.A1(new_n291_), .A2(new_n292_), .B(new_n35_), .Y(new_n293_));
  NOR2x1_ASAP7_75t_R   g272(.A(\totalcoeffs[0] ), .B(\trailingones[0] ), .Y(new_n294_));
  OR3x1_ASAP7_75t_R    g273(.A(new_n134_), .B(new_n156_), .C(new_n294_), .Y(new_n295_));
  OA211x2_ASAP7_75t_R  g274(.A1(new_n290_), .A2(\ctable[0] ), .B(new_n293_), .C(new_n295_), .Y(new_n296_));
  INVx1_ASAP7_75t_R    g275(.A(new_n58_), .Y(new_n297_));
  AO21x1_ASAP7_75t_R   g276(.A1(new_n75_), .A2(\ctable[1] ), .B(\totalcoeffs[0] ), .Y(new_n298_));
  NOR2x1_ASAP7_75t_R   g277(.A(\totalcoeffs[2] ), .B(\trailingones[1] ), .Y(new_n299_));
  AO32x1_ASAP7_75t_R   g278(.A1(new_n255_), .A2(new_n298_), .A3(new_n299_), .B1(new_n280_), .B2(new_n297_), .Y(new_n300_));
  NAND2x1_ASAP7_75t_R  g279(.A(new_n31_), .B(new_n300_), .Y(new_n301_));
  AND2x2_ASAP7_75t_R   g280(.A(new_n26_), .B(\ctable[0] ), .Y(new_n302_));
  AND3x1_ASAP7_75t_R   g281(.A(new_n302_), .B(new_n58_), .C(new_n43_), .Y(new_n303_));
  AO21x1_ASAP7_75t_R   g282(.A1(new_n27_), .A2(\totalcoeffs[2] ), .B(\ctable[1] ), .Y(new_n304_));
  AO21x1_ASAP7_75t_R   g283(.A1(new_n297_), .A2(new_n304_), .B(new_n303_), .Y(new_n305_));
  OA21x2_ASAP7_75t_R   g284(.A1(\trailingones[0] ), .A2(\trailingones[1] ), .B(\totalcoeffs[2] ), .Y(new_n306_));
  OA21x2_ASAP7_75t_R   g285(.A1(new_n113_), .A2(new_n306_), .B(\ctable[1] ), .Y(new_n307_));
  AOI21x1_ASAP7_75t_R  g286(.A1(new_n75_), .A2(new_n305_), .B(new_n307_), .Y(new_n308_));
  OA221x2_ASAP7_75t_R  g287(.A1(new_n31_), .A2(new_n308_), .B1(new_n296_), .B2(new_n25_), .C(new_n301_), .Y(new_n309_));
  OAI22x1_ASAP7_75t_R  g288(.A1(\totalcoeffs[3] ), .A2(new_n286_), .B1(new_n309_), .B2(\ctable[2] ), .Y(new_n310_));
  AOI22x1_ASAP7_75t_R  g289(.A1(new_n23_), .A2(new_n271_), .B1(new_n310_), .B2(new_n22_), .Y(\ctoken_len[0] ));
  NAND2x1_ASAP7_75t_R  g290(.A(\totalcoeffs[0] ), .B(\trailingones[0] ), .Y(new_n312_));
  AO21x1_ASAP7_75t_R   g291(.A1(\trailingones[0] ), .A2(\trailingones[1] ), .B(new_n25_), .Y(new_n313_));
  AOI21x1_ASAP7_75t_R  g292(.A1(new_n312_), .A2(new_n313_), .B(\ctable[1] ), .Y(new_n314_));
  AND3x1_ASAP7_75t_R   g293(.A(new_n25_), .B(\trailingones[0] ), .C(\trailingones[1] ), .Y(new_n315_));
  OAI21x1_ASAP7_75t_R  g294(.A1(new_n315_), .A2(new_n314_), .B(\totalcoeffs[2] ), .Y(new_n316_));
  OR3x1_ASAP7_75t_R    g295(.A(new_n89_), .B(\totalcoeffs[3] ), .C(\trailingones[0] ), .Y(new_n317_));
  OAI21x1_ASAP7_75t_R  g296(.A1(new_n141_), .A2(new_n249_), .B(new_n220_), .Y(new_n318_));
  AOI21x1_ASAP7_75t_R  g297(.A1(\ctable[1] ), .A2(\trailingones[1] ), .B(\trailingones[0] ), .Y(new_n319_));
  OAI21x1_ASAP7_75t_R  g298(.A1(\ctable[1] ), .A2(new_n25_), .B(\totalcoeffs[0] ), .Y(new_n320_));
  AOI21x1_ASAP7_75t_R  g299(.A1(new_n320_), .A2(new_n92_), .B(new_n319_), .Y(new_n321_));
  AOI21x1_ASAP7_75t_R  g300(.A1(\trailingones[1] ), .A2(new_n318_), .B(new_n321_), .Y(new_n322_));
  OA211x2_ASAP7_75t_R  g301(.A1(new_n322_), .A2(\totalcoeffs[2] ), .B(new_n316_), .C(new_n317_), .Y(new_n323_));
  NAND2x1_ASAP7_75t_R  g302(.A(\ctable[1] ), .B(new_n48_), .Y(new_n324_));
  AO21x1_ASAP7_75t_R   g303(.A1(\trailingones[0] ), .A2(\trailingones[1] ), .B(\ctable[1] ), .Y(new_n325_));
  OAI22x1_ASAP7_75t_R  g304(.A1(new_n67_), .A2(new_n325_), .B1(new_n324_), .B2(new_n166_), .Y(new_n326_));
  NAND3x1_ASAP7_75t_R  g305(.A(\totalcoeffs[0] ), .B(\trailingones[0] ), .C(\ctable[1] ), .Y(new_n327_));
  OR3x1_ASAP7_75t_R    g306(.A(\totalcoeffs[0] ), .B(\totalcoeffs[2] ), .C(\trailingones[0] ), .Y(new_n328_));
  AOI21x1_ASAP7_75t_R  g307(.A1(new_n327_), .A2(new_n328_), .B(\trailingones[1] ), .Y(new_n329_));
  AO21x1_ASAP7_75t_R   g308(.A1(new_n25_), .A2(new_n75_), .B(\ctable[1] ), .Y(new_n330_));
  AND2x2_ASAP7_75t_R   g309(.A(new_n330_), .B(new_n306_), .Y(new_n331_));
  AO211x2_ASAP7_75t_R  g310(.A1(\totalcoeffs[3] ), .A2(new_n326_), .B(new_n329_), .C(new_n331_), .Y(new_n332_));
  AND5x1_ASAP7_75t_R   g311(.A(new_n26_), .B(new_n75_), .C(new_n35_), .D(\totalcoeffs[3] ), .E(\ctable[1] ), .Y(new_n333_));
  AOI21x1_ASAP7_75t_R  g312(.A1(new_n31_), .A2(new_n332_), .B(new_n333_), .Y(new_n334_));
  OAI21x1_ASAP7_75t_R  g313(.A1(new_n31_), .A2(new_n323_), .B(new_n334_), .Y(new_n335_));
  NAND2x1_ASAP7_75t_R  g314(.A(\ctable[0] ), .B(new_n48_), .Y(new_n336_));
  AO21x1_ASAP7_75t_R   g315(.A1(\totalcoeffs[2] ), .A2(\trailingones[1] ), .B(new_n48_), .Y(new_n337_));
  OAI22x1_ASAP7_75t_R  g316(.A1(new_n337_), .A2(new_n299_), .B1(new_n336_), .B2(\trailingones[1] ), .Y(new_n338_));
  AND3x1_ASAP7_75t_R   g317(.A(new_n71_), .B(\ctable[0] ), .C(new_n75_), .Y(new_n339_));
  AOI21x1_ASAP7_75t_R  g318(.A1(\trailingones[0] ), .A2(new_n338_), .B(new_n339_), .Y(new_n340_));
  AND2x2_ASAP7_75t_R   g319(.A(\totalcoeffs[3] ), .B(\ctable[0] ), .Y(new_n341_));
  NAND2x1_ASAP7_75t_R  g320(.A(\ctable[0] ), .B(new_n26_), .Y(new_n342_));
  AOI22x1_ASAP7_75t_R  g321(.A1(\totalcoeffs[3] ), .A2(\ctable[0] ), .B1(new_n35_), .B2(\totalcoeffs[2] ), .Y(new_n343_));
  OAI22x1_ASAP7_75t_R  g322(.A1(new_n343_), .A2(\totalcoeffs[0] ), .B1(new_n342_), .B2(new_n25_), .Y(new_n344_));
  AOI22x1_ASAP7_75t_R  g323(.A1(new_n299_), .A2(new_n341_), .B1(new_n344_), .B2(new_n75_), .Y(new_n345_));
  OA21x2_ASAP7_75t_R   g324(.A1(new_n340_), .A2(\totalcoeffs[3] ), .B(new_n345_), .Y(new_n346_));
  OAI21x1_ASAP7_75t_R  g325(.A1(new_n26_), .A2(new_n25_), .B(new_n166_), .Y(new_n347_));
  AOI21x1_ASAP7_75t_R  g326(.A1(new_n26_), .A2(new_n52_), .B(new_n27_), .Y(new_n348_));
  AO32x1_ASAP7_75t_R   g327(.A1(\totalcoeffs[0] ), .A2(\totalcoeffs[3] ), .A3(new_n184_), .B1(new_n348_), .B2(new_n347_), .Y(new_n349_));
  AND5x1_ASAP7_75t_R   g328(.A(\totalcoeffs[2] ), .B(\totalcoeffs[3] ), .C(\ctable[0] ), .D(\trailingones[0] ), .E(\trailingones[1] ), .Y(new_n350_));
  AOI21x1_ASAP7_75t_R  g329(.A1(new_n31_), .A2(new_n349_), .B(new_n350_), .Y(new_n351_));
  OAI21x1_ASAP7_75t_R  g330(.A1(new_n31_), .A2(new_n346_), .B(new_n351_), .Y(new_n352_));
  AOI22x1_ASAP7_75t_R  g331(.A1(new_n24_), .A2(new_n352_), .B1(new_n335_), .B2(new_n27_), .Y(new_n353_));
  AND3x1_ASAP7_75t_R   g332(.A(new_n26_), .B(\totalcoeffs[0] ), .C(\trailingones[0] ), .Y(new_n354_));
  AO32x1_ASAP7_75t_R   g333(.A1(\ctable[2] ), .A2(new_n354_), .A3(new_n35_), .B1(new_n166_), .B2(new_n278_), .Y(new_n355_));
  NAND3x1_ASAP7_75t_R  g334(.A(new_n355_), .B(new_n214_), .C(new_n96_), .Y(new_n356_));
  OAI21x1_ASAP7_75t_R  g335(.A1(\ctable[2] ), .A2(new_n353_), .B(new_n356_), .Y(new_n357_));
  AND3x1_ASAP7_75t_R   g336(.A(new_n268_), .B(new_n27_), .C(new_n23_), .Y(new_n358_));
  AND2x2_ASAP7_75t_R   g337(.A(new_n358_), .B(new_n24_), .Y(new_n359_));
  AOI21x1_ASAP7_75t_R  g338(.A1(new_n22_), .A2(new_n357_), .B(new_n359_), .Y(\ctoken_len[1] ));
  OA21x2_ASAP7_75t_R   g339(.A1(new_n25_), .A2(\ctable[0] ), .B(new_n146_), .Y(new_n361_));
  AOI211x1_ASAP7_75t_R g340(.A1(new_n25_), .A2(\trailingones[1] ), .B(new_n77_), .C(\totalcoeffs[2] ), .Y(new_n362_));
  AO21x1_ASAP7_75t_R   g341(.A1(new_n77_), .A2(new_n302_), .B(new_n201_), .Y(new_n363_));
  AND2x2_ASAP7_75t_R   g342(.A(new_n25_), .B(\totalcoeffs[2] ), .Y(new_n364_));
  INVx1_ASAP7_75t_R    g343(.A(new_n364_), .Y(new_n365_));
  NAND2x1_ASAP7_75t_R  g344(.A(new_n31_), .B(new_n27_), .Y(new_n366_));
  AOI21x1_ASAP7_75t_R  g345(.A1(new_n181_), .A2(new_n366_), .B(new_n365_), .Y(new_n367_));
  AO221x2_ASAP7_75t_R  g346(.A1(new_n48_), .A2(new_n363_), .B1(new_n361_), .B2(new_n362_), .C(new_n367_), .Y(new_n368_));
  INVx1_ASAP7_75t_R    g347(.A(new_n341_), .Y(new_n369_));
  NAND2x1_ASAP7_75t_R  g348(.A(new_n48_), .B(new_n25_), .Y(new_n370_));
  AO32x1_ASAP7_75t_R   g349(.A1(new_n26_), .A2(new_n361_), .A3(new_n370_), .B1(new_n96_), .B2(new_n134_), .Y(new_n371_));
  AO21x1_ASAP7_75t_R   g350(.A1(new_n48_), .A2(\trailingones[0] ), .B(\ctable[0] ), .Y(new_n372_));
  AO32x1_ASAP7_75t_R   g351(.A1(new_n47_), .A2(new_n369_), .A3(new_n372_), .B1(\trailingones[0] ), .B2(new_n371_), .Y(new_n373_));
  AO21x1_ASAP7_75t_R   g352(.A1(\totalcoeffs[2] ), .A2(new_n27_), .B(new_n341_), .Y(new_n374_));
  AND3x1_ASAP7_75t_R   g353(.A(new_n374_), .B(\totalcoeffs[1] ), .C(new_n188_), .Y(new_n375_));
  AND5x1_ASAP7_75t_R   g354(.A(new_n31_), .B(new_n336_), .C(new_n26_), .D(\totalcoeffs[3] ), .E(\trailingones[0] ), .Y(new_n376_));
  OA21x2_ASAP7_75t_R   g355(.A1(new_n376_), .A2(new_n375_), .B(\trailingones[1] ), .Y(new_n377_));
  AO221x2_ASAP7_75t_R  g356(.A1(new_n35_), .A2(new_n373_), .B1(new_n75_), .B2(new_n368_), .C(new_n377_), .Y(new_n378_));
  NAND2x1_ASAP7_75t_R  g357(.A(\totalcoeffs[0] ), .B(new_n288_), .Y(new_n379_));
  OA21x2_ASAP7_75t_R   g358(.A1(new_n31_), .A2(\trailingones[0] ), .B(new_n24_), .Y(new_n380_));
  INVx1_ASAP7_75t_R    g359(.A(new_n141_), .Y(new_n381_));
  AO21x1_ASAP7_75t_R   g360(.A1(new_n381_), .A2(new_n156_), .B(new_n178_), .Y(new_n382_));
  AOI221x1_ASAP7_75t_R g361(.A1(new_n380_), .A2(new_n379_), .B1(new_n26_), .B2(new_n382_), .C(new_n238_), .Y(new_n383_));
  AOI21x1_ASAP7_75t_R  g362(.A1(new_n24_), .A2(new_n378_), .B(new_n383_), .Y(new_n384_));
  AO21x1_ASAP7_75t_R   g363(.A1(new_n281_), .A2(new_n48_), .B(new_n133_), .Y(new_n385_));
  AND3x1_ASAP7_75t_R   g364(.A(new_n278_), .B(new_n75_), .C(\trailingones[1] ), .Y(new_n386_));
  AO21x1_ASAP7_75t_R   g365(.A1(new_n385_), .A2(new_n35_), .B(new_n386_), .Y(new_n387_));
  AND3x1_ASAP7_75t_R   g366(.A(new_n112_), .B(new_n48_), .C(new_n180_), .Y(new_n388_));
  AO21x1_ASAP7_75t_R   g367(.A1(new_n387_), .A2(new_n31_), .B(new_n388_), .Y(new_n389_));
  NAND2x1_ASAP7_75t_R  g368(.A(new_n162_), .B(new_n389_), .Y(new_n390_));
  OAI21x1_ASAP7_75t_R  g369(.A1(\ctable[2] ), .A2(new_n384_), .B(new_n390_), .Y(new_n391_));
  AOI21x1_ASAP7_75t_R  g370(.A1(new_n22_), .A2(new_n391_), .B(new_n358_), .Y(\ctoken_len[2] ));
  INVx1_ASAP7_75t_R    g371(.A(new_n228_), .Y(new_n393_));
  AO21x1_ASAP7_75t_R   g372(.A1(\ctable[1] ), .A2(\trailingones[1] ), .B(new_n25_), .Y(new_n394_));
  AO21x1_ASAP7_75t_R   g373(.A1(new_n381_), .A2(new_n254_), .B(new_n394_), .Y(new_n395_));
  OA21x2_ASAP7_75t_R   g374(.A1(new_n230_), .A2(new_n214_), .B(new_n26_), .Y(new_n396_));
  AO32x1_ASAP7_75t_R   g375(.A1(new_n364_), .A2(new_n173_), .A3(new_n393_), .B1(new_n395_), .B2(new_n396_), .Y(new_n397_));
  NAND2x1_ASAP7_75t_R  g376(.A(new_n31_), .B(new_n397_), .Y(new_n398_));
  AO32x1_ASAP7_75t_R   g377(.A1(new_n48_), .A2(\trailingones[0] ), .A3(new_n394_), .B1(new_n25_), .B2(new_n252_), .Y(new_n399_));
  NAND2x1_ASAP7_75t_R  g378(.A(new_n26_), .B(new_n399_), .Y(new_n400_));
  OR3x1_ASAP7_75t_R    g379(.A(new_n27_), .B(new_n75_), .C(new_n35_), .Y(new_n401_));
  AO21x1_ASAP7_75t_R   g380(.A1(new_n401_), .A2(new_n24_), .B(\totalcoeffs[3] ), .Y(new_n402_));
  OA21x2_ASAP7_75t_R   g381(.A1(new_n393_), .A2(new_n246_), .B(new_n402_), .Y(new_n403_));
  AO21x1_ASAP7_75t_R   g382(.A1(new_n400_), .A2(new_n403_), .B(new_n31_), .Y(new_n404_));
  OR3x1_ASAP7_75t_R    g383(.A(new_n246_), .B(new_n48_), .C(\ctable[0] ), .Y(new_n405_));
  AO22x1_ASAP7_75t_R   g384(.A1(new_n405_), .A2(new_n23_), .B1(new_n31_), .B2(new_n173_), .Y(new_n406_));
  AO21x1_ASAP7_75t_R   g385(.A1(new_n207_), .A2(new_n23_), .B(new_n48_), .Y(new_n407_));
  OA21x2_ASAP7_75t_R   g386(.A1(new_n364_), .A2(\ctable[0] ), .B(\ctable[1] ), .Y(new_n408_));
  AOI221x1_ASAP7_75t_R g387(.A1(\totalcoeffs[4] ), .A2(new_n207_), .B1(\ctable[2] ), .B2(new_n365_), .C(new_n408_), .Y(new_n409_));
  AND5x1_ASAP7_75t_R   g388(.A(new_n398_), .B(new_n404_), .C(new_n406_), .D(new_n407_), .E(new_n409_), .Y(\ctoken_len[3] ));
  AO21x1_ASAP7_75t_R   g389(.A1(new_n35_), .A2(\totalcoeffs[0] ), .B(\totalcoeffs[1] ), .Y(new_n411_));
  AO21x1_ASAP7_75t_R   g390(.A1(new_n58_), .A2(\totalcoeffs[1] ), .B(new_n75_), .Y(new_n412_));
  AND4x2_ASAP7_75t_R   g391(.A(new_n412_), .B(\totalcoeffs[2] ), .C(new_n411_), .D(new_n263_), .Y(new_n413_));
  OA211x2_ASAP7_75t_R  g392(.A1(new_n413_), .A2(new_n268_), .B(new_n23_), .C(new_n214_), .Y(\ctoken_len[4] ));
endmodule


