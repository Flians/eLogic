module mapped( A2[0] , A3[0] , B1[0] , B2[0] , C1[0] , C2[0] , A1[0] , result[0] );
  input A2[0] , A3[0] , B1[0] , B2[0] , C1[0] , C2[0] , A1[0] ;
  output result[0] ;
  wire n9 ;
  AO32x1_ASAP7_75t_R   g0( .A1 (A2[0]), .A2 (A3[0]), .A3 (A1[0]), .B1 (B2[0]), .B2 (B1[0]), .Y (n9) );
  AO21x1_ASAP7_75t_R   g1( .A1 (C1[0]), .A2 (C2[0]), .B (n9), .Y (result[0]) );
endmodule
