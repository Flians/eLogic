module mapped( \A2[0]  , \A3[0]  , \B1[0]  , \B2[0]  , \B3[0]  , \C[0]  , \A1[0]  , \result[0]  );
  input \A2[0]  , \A3[0]  , \B1[0]  , \B2[0]  , \B3[0]  , \C[0]  , \A1[0]  ;
  output \result[0]  ;
  AO331x2_ASAP7_75t_R  g0( .A1 (\A2[0] ), .A2 (\A1[0] ), .A3 (\A3[0] ), .B1 (\B3[0] ), .B2 (\B1[0] ), .B3 (\B2[0] ), .C (\C[0] ), .Y (\result[0] ) );
endmodule
