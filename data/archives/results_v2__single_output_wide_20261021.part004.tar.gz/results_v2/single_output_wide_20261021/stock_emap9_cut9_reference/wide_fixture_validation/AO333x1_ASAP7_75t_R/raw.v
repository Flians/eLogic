module mapped( A2[0] , A3[0] , B1[0] , B2[0] , B3[0] , C1[0] , C2[0] , C3[0] , A1[0] , result[0] );
  input A2[0] , A3[0] , B1[0] , B2[0] , B3[0] , C1[0] , C2[0] , C3[0] , A1[0] ;
  output result[0] ;
  AO333x1_ASAP7_75t_R  g0( .A1 (C1[0]), .A2 (C2[0]), .A3 (C3[0]), .B1 (A2[0]), .B2 (A1[0]), .B3 (A3[0]), .C1 (B3[0]), .C2 (B1[0]), .C3 (B2[0]), .Y (result[0]) );
endmodule
