module mapped( A2[0] , A3[0] , B1[0] , B2[0] , B3[0] , C1[0] , C2[0] , A1[0] , result[0] );
  input A2[0] , A3[0] , B1[0] , B2[0] , B3[0] , C1[0] , C2[0] , A1[0] ;
  output result[0] ;
  wire n10 ;
  AO33x2_ASAP7_75t_R   g0( .A1 (B1[0]), .A2 (B2[0]), .A3 (B3[0]), .B1 (A1[0]), .B2 (A2[0]), .B3 (A3[0]), .Y (n10) );
  AO21x1_ASAP7_75t_R   g1( .A1 (C1[0]), .A2 (C2[0]), .B (n10), .Y (result[0]) );
endmodule
