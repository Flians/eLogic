# Phase recovery allocation audit

Phase recovery precedes local/cone recovery under one global deadline. Zero subsequent local trials and nonzero control local trials are observed; the phase pass improving its incoming cover does not prove improvement over the separately recovered control. This is evidence of a scheduling bottleneck, not a causal ablation: demanded import and region ordering also differ.

Across 44 valid pairs, 7 phase-enabled cases perform zero subsequent local trials, while their controls perform local recovery. Of these, 5 have worse delay and 7 have worse area.

|Library|Objective|Design|Phase trials|Control local trials|Area change|Delay change|
|---|---|---|---:|---:|---:|---:|
|3|area-delay|sin|479|669|44.96|-133.03|
|3|delay-area|sin|405|512|49.90|-29.82|
|4|area-delay|bar|1391|1679|41.24|19.63|
|4|area-delay|max|1201|1500|52.80|47.55|
|4|area-delay|sin|369|445|40.87|30.88|
|4|delay-area|max|1189|1108|53.91|11.82|
|4|delay-area|sin|315|330|29.82|49.12|

Use an isolated explicit mapper version to reserve a fraction of the SAME global two-second recovery deadline for local/cone recovery, then run a complete paired scope including failures. Do not raise time/node/pool budgets or select a setting separately for each design.

This audit does not alter any mapper, baseline, or recorded result.
