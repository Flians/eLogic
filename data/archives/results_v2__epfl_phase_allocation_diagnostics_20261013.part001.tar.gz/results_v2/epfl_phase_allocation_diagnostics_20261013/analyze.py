#!/usr/bin/env python3
"""Read-only audit of completed native phase recovery and local recovery counters."""
import csv
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
CAMPAIGN = ROOT / 'results_v2/epfl_region_phase_checkpoint_20261013/campaign.json'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
d = json.loads(CAMPAIGN.read_text())
rows = {}
sources = {str(CAMPAIGN): sha(CAMPAIGN)}
for job in d['jobs']:
    path = Path(job['report'])
    assert sha(path) == job['report_sha256'], path
    sources[str(path)] = sha(path)
    for result in json.loads(path.read_text())['results']:
        rows[(job['k'], job['objective'], job['bench'], job['profile'])] = result

pairs = []
for (k, goal, bench, profile), r in sorted(rows.items()):
    if profile != 'region_phase':
        continue
    c = rows[(k, goal, bench, 'control')]
    item = dict(library=k, objective=goal, bench=bench,
                candidate_status=r['status'], control_status=c['status'])
    if r['status'] == c['status'] == 'ok':
        n, cn = r['native'], c['native']
        item.update(
            area_delta=r['measured']['area'] - c['measured']['area'],
            delay_delta=r['measured']['delay'] - c['measured']['delay'],
            phase_trials=n['phase_trials'], phase_accepted=n['phase_accepted'],
            local_trials=n['refinement_trials'], control_local_trials=cn['refinement_trials'],
            phase_initial_delay=n['phase_initial_delay'], phase_final_delay=n['phase_final_delay'],
            recovery_secs=n['heuristic_secs'], control_recovery_secs=cn['heuristic_secs'],
        )
    pairs.append(item)

valid = [r for r in pairs if r['candidate_status'] == r['control_status'] == 'ok']
starved = [r for r in valid if r['phase_trials'] > 0 and r['local_trials'] == 0
           and r['control_local_trials'] > 0]
report = dict(
    scope='Both libraries and objectives; all 20 EPFL designs, failed pairs retained',
    input_recipe='The same single resyn2 prepared AIG as the completed study',
    successful_pairs=len(valid), local_recovery_zero_after_phase=len(starved),
    delay_worse_in_zero_local_pairs=sum(r['delay_delta'] > 1e-6 for r in starved),
    area_worse_in_zero_local_pairs=sum(r['area_delta'] > 1e-6 for r in starved),
    interpretation='Phase recovery precedes local/cone recovery under one global deadline. '
                   'Zero subsequent local trials and nonzero control local trials are observed; '
                   'the phase pass improving its incoming cover does not prove improvement '
                   'over the separately recovered control. This is evidence of a scheduling '
                   'bottleneck, not a causal ablation: demanded import and region ordering also differ.',
    next_experiment='Use an isolated explicit mapper version to reserve a fraction of the SAME '
                    'global two-second recovery deadline for local/cone recovery, then run a '
                    'complete paired scope including failures. Do not raise time/node/pool budgets '
                    'or select a setting separately for each design.',
    sources=sources, pairs=pairs,
)
(OUT / 'validation.json').write_text(json.dumps(report, indent=2) + '\n')
fields = list(dict.fromkeys(k for r in pairs for k in r))
with (OUT / 'paired.csv').open('w') as f:
    w = csv.DictWriter(f, fieldnames=fields); w.writeheader(); w.writerows(pairs)
lines = ['# Phase recovery allocation audit', '', report['interpretation'], '',
         f"Across {len(valid)} valid pairs, {len(starved)} phase-enabled cases perform zero subsequent local trials, "
         f"while their controls perform local recovery. Of these, {report['delay_worse_in_zero_local_pairs']} "
         f"have worse delay and {report['area_worse_in_zero_local_pairs']} have worse area.", '',
         '|Library|Objective|Design|Phase trials|Control local trials|Area change|Delay change|',
         '|---|---|---|---:|---:|---:|---:|']
for r in starved:
    lines.append(f"|{r['library']}|{r['objective']}|{r['bench']}|{r['phase_trials']}|"
                 f"{r['control_local_trials']}|{r['area_delta']:.2f}|{r['delay_delta']:.2f}|")
lines += ['', report['next_experiment'], '', 'This audit does not alter any mapper, baseline, or recorded result.']
(OUT / 'report.md').write_text('\n'.join(lines) + '\n')
print(json.dumps({k: report[k] for k in ['successful_pairs', 'local_recovery_zero_after_phase',
                                       'delay_worse_in_zero_local_pairs', 'area_worse_in_zero_local_pairs']}))
