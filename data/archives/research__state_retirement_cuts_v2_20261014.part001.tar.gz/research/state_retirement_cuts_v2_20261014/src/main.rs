//! Bounded regional exact cuts, physical sharing and safe retirement. Isolated, no main changes.
use std::{collections::{BTreeSet,HashMap},time::Instant};
use egg::{EGraph,Id};
use emapper::{egraph_sat::AigLang,techlib::TechLib,egraph_map::{Instance,OutputPin,Binding,MappedGraph,MapStats}};
use serde::Deserialize;
#[derive(Deserialize)] struct Subject {inputs:Vec<String>,outputs:Vec<(usize,String)>,gates:Vec<(usize,usize,usize)>}
#[derive(Clone,Eq,PartialEq,Ord,PartialOrd)] struct Cut {leaves:Vec<usize>,tt:u64}
fn mask(n:usize)->u64 {(1u64<<(1usize<<n))-1}
fn expand(c:&Cut,leaves:&[usize])->u64 {
    let pos:Vec<_>=c.leaves.iter().map(|x|leaves.binary_search(x).unwrap()).collect();
    (0..1usize<<leaves.len()).fold(0,|t,a|{let b=pos.iter().enumerate().fold(0,|b,(i,p)|b|((a>>p&1)<<i));t|((c.tt>>b&1)<<a)})
}
fn combine(x:&Cut,y:&Cut,ph:usize,k:usize)->Option<Cut>{
    let leaves:Vec<_>=x.leaves.iter().chain(&y.leaves).copied().collect::<BTreeSet<_>>().into_iter().collect();
    if leaves.len()>k{return None}let m=mask(leaves.len());let a=expand(x,&leaves)^if ph&1!=0{m}else{0};let b=expand(y,&leaves)^if ph&2!=0{m}else{0};
    Some(Cut{leaves,tt:a&b})
}
#[derive(Clone)] struct Plan {m:Instance,delay:f64,flow:f64}
fn better(a:&Plan,b:&Plan)->bool {a.delay.total_cmp(&b.delay).then(a.flow.total_cmp(&b.flow)).then(a.m.cell.cmp(&b.m.cell)).then(a.m.inputs.cmp(&b.m.inputs)).then(a.m.input_pins.cmp(&b.m.input_pins)).is_lt()}
type Key=(String,Vec<usize>,Vec<String>);
fn key(m:&Instance)->Key{(m.cell.clone(),m.inputs.clone(),m.input_pins.clone())}
fn commit(s:usize,plans:&HashMap<usize,Plan>,chosen:&mut[Option<Binding>],free:&[bool],instances:&mut Vec<Instance>,index:&mut HashMap<Key,usize>,active:&mut BTreeSet<usize>)->Result<(),String>{
    if free[s] || chosen[s].is_some(){return Ok(())}if !active.insert(s){return Err("regional selected phase cycle".into())}
    let p=plans.get(&s).ok_or("uncertified physical crossing")?;
    for &x in &p.m.inputs {commit(x,plans,chosen,free,instances,index,active)?;}
    let i=if let Some(&i)=index.get(&key(&p.m)){if !instances[i].outputs[0].targets.contains(&s){instances[i].outputs[0].targets.push(s);}i}else{
        if instances.len()+plans.len()+1>100000{return Err("global prefix plus outstanding plans exceeded pool before commit".into())}
        let i=instances.len();let mut m=p.m.clone();m.outputs[0].targets=vec![s];index.insert(key(&m),i);instances.push(m);i
    };chosen[s]=Some(Binding{instance:i,pin:0});active.remove(&s);Ok(())
}
fn build(s:&Subject,tech:&TechLib,seconds:f64)->Result<(MappedGraph,serde_json::Value),String>{
    let start=Instant::now();let check=||if start.elapsed().as_secs_f64()>seconds{Err("global two-second construction/recovery deadline exceeded".to_string())}else{Ok(())};
    let max=s.gates.iter().map(|x|x.0).chain(s.outputs.iter().map(|x|x.0/2)).chain(std::iter::once(s.inputs.len())).max().unwrap();
    let retain_original_graph=s.inputs.len()+s.gates.len()+1<=20000;
    let k=tech.cells.iter().map(|c|c.vars.len()).max().unwrap().min(4);let mut unique=HashMap::new();for c in &tech.cells{*unique.entry(&c.name).or_insert(0)+=1;}
    let inv=tech.cells.iter().filter(|c|c.vars.len()==1 && c.tt[0]==1 && unique[&c.name]==1).min_by(|a,b|(a.pin_delay[&a.vars[0]],a.area).partial_cmp(&(b.pin_delay[&b.vars[0]],b.area)).unwrap()).ok_or("no inverter")?;
    let mut uses=vec![0usize;max+1];let mut original_refs=vec![1usize;max+1];
    for &(v,a,b) in &s.gates {if v<=s.inputs.len() || a/2>=v || b/2>=v{return Err("invalid topological AND".into())}for x in [a,b]{uses[x/2]+=1;original_refs[x/2]+=1;}}
    for &(x,_) in &s.outputs{uses[x/2]+=1;original_refs[x/2]+=1;}
    let mut chosen=vec![None;2*(max+1)];let mut constants=vec![None;chosen.len()];constants[0]=Some(false);constants[1]=Some(true);
    let mut free=vec![false;chosen.len()];free[0]=true;free[1]=true;let mut arrival=vec![f64::INFINITY;chosen.len()];arrival[0]=0.;arrival[1]=0.;let mut flows=vec![0.;chosen.len()];
    let mut instances=Vec::new();let mut instance_index=HashMap::new();
    let mut graph=EGraph::<AigLang,()>::default();let mut ids=HashMap::<usize,Id>::new();let mut cuts=HashMap::new();let mut frontier=BTreeSet::new();let mut plans=HashMap::<usize,Plan>::new();
    let mut cache_entries_peak=0;let mut cumulative=0;let mut peak=0;let mut semantic_peak=0;let mut pool_peak=0;let mut generated=0;let mut maxcuts=0;let mut regions=Vec::new();let mut retired=0;
    let boundary=|g:&mut EGraph<AigLang,()>,ids:&mut HashMap<usize,Id>,cuts:&mut HashMap<usize,Vec<Cut>>,frontier:&BTreeSet<usize>|{
        ids.insert(0,g.add(AigLang::Zero));cuts.insert(0,vec![Cut{leaves:vec![],tt:0}]);
        for v in (1..=s.inputs.len()).chain(frontier.iter().copied()){ids.entry(v).or_insert_with(||g.add(AigLang::Pi(v as u32)));cuts.insert(v,vec![Cut{leaves:vec![v],tt:2}]);}
    };
    boundary(&mut graph,&mut ids,&mut cuts,&frontier);cumulative+=graph.total_size();peak=peak.max(graph.total_size());cache_entries_peak=cache_entries_peak.max(cuts.values().map(Vec::len).sum::<usize>());semantic_peak=semantic_peak.max(graph.total_size()+if retain_original_graph {0}else{cuts.values().map(Vec::len).sum::<usize>()});if semantic_peak>20000{return Err("initial global graph plus cut cache exceeds allowance".into())}
    for v in 1..=s.inputs.len(){free[2*v]=true;arrival[2*v]=0.;let m=Instance{cell:inv.name.clone(),area:inv.area,inputs:vec![2*v],input_pins:inv.vars.clone(),outputs:vec![OutputPin{name:inv.out_pin.clone(),delays:vec![inv.pin_delay[&inv.vars[0]]],function:1,targets:vec![2*v+1]}]};
        plans.insert(2*v+1,Plan{m,delay:f64::from(inv.pin_delay[&inv.vars[0]]),flow:f64::from(inv.area)});arrival[2*v+1]=f64::from(inv.pin_delay[&inv.vars[0]]);
    }
    // PI phase producers are shared globally; no region gets a private copy.
    pool_peak=pool_peak.max(instances.len()+plans.len());if pool_peak>100000{return Err("PI phase plans exceed global pool".into())}
    for v in 1..=s.inputs.len(){commit(2*v+1,&plans,&mut chosen,&free,&mut instances,&mut instance_index,&mut BTreeSet::new())?;}plans.clear();
    for (i,&(v,a,b)) in s.gates.iter().enumerate(){
        check()?;let x=*ids.get(&(a/2)).ok_or("missing retired input")?;let y=*ids.get(&(b/2)).ok_or("missing retired input")?;let ph=(a&1)|((b&1)<<1);
        let before=graph.total_size();let n=if ph==0{AigLang::And([x,y])}else{AigLang::Cell(match ph{1=>"@egm_and_np",2=>"@egm_and_pn",_=>"@egm_and_nn"}.into(),vec![x,y])};ids.insert(v,graph.add(n));cumulative+=graph.total_size()-before;
        let mut bank=BTreeSet::new();for x in &cuts[&(a/2)]{for y in &cuts[&(b/2)]{if let Some(c)=combine(x,y,ph,k){bank.insert(c);}}}
        cache_entries_peak=cache_entries_peak.max(cuts.values().map(Vec::len).sum::<usize>()+bank.len()+2);semantic_peak=semantic_peak.max(graph.total_size()+if retain_original_graph{0}else{cuts.values().map(Vec::len).sum::<usize>()+bank.len()+2});if semantic_peak>20000{return Err("global graph plus pending cut-bank cache exceeded allowance".into())}
        if bank.iter().flat_map(|c|&c.leaves).any(|v|!ids.contains_key(v)){return Err("cached cut references an uncharged logical interface".into())}
        let mut bank:Vec<_>=bank.into_iter().collect();bank.sort_by_key(|c|(c.leaves.len(),c.leaves.clone(),c.tt));bank.truncate(15);bank.push(Cut{leaves:vec![v],tt:2});maxcuts=maxcuts.max(bank.len());cuts.insert(v,bank);
        for phase in 0..2 {
            let target=2*v+phase;let mut best:Option<Plan>=None;
            for c in &cuts[&v]{if c.leaves.contains(&v){continue}let tt=c.tt^if phase!=0{mask(c.leaves.len())}else{0};let mut table=[0u64;8];table[0]=tt;
                if let Some(variants)=tech.candidates(c.leaves.len() as u8,table){for var in variants {
                    if var.out_neg || unique[&var.cell_name]!=1{continue}generated+=1;let inputs:Vec<_>=c.leaves.iter().enumerate().map(|(j,x)|2*x+((var.neg_mask as usize>>j)&1)).collect();
                    if inputs.iter().any(|x|!arrival[*x].is_finite()){continue}
                    let delay=inputs.iter().zip(&var.pin_delay).map(|(x,d)|arrival[*x]+f64::from(*d)).fold(0.,f64::max);
                    let sum: f64=inputs.iter().copied().collect::<BTreeSet<_>>().iter().map(|x|flows[*x]).sum();let flow=(f64::from(var.area)+sum).min(f64::MAX)/original_refs[v] as f64;
                    let physical=(0..1usize<<c.leaves.len()).fold(0,|t,a|t|((tt>>(a^var.neg_mask as usize)&1)<<a));
                    let candidate=Plan{m:Instance{cell:var.cell_name.clone(),area:var.area,inputs,input_pins:var.pin_names.clone(),outputs:vec![OutputPin{name:var.out_pin.clone(),delays:var.pin_delay.clone(),function:physical,targets:vec![target]}]},delay,flow};
                    pool_peak=pool_peak.max(instances.len()+plans.len()+3);if pool_peak>100000{return Err("global retained prefix+regional plan+proposal pool exceeded".into())}
                    if best.as_ref().is_none_or(|old|better(&candidate,old)){best=Some(candidate)}
                }}
            }
            let p=best.ok_or("bounded regional cuts lack an exact physical phase witness")?;arrival[target]=p.delay;flows[target]=p.flow;plans.insert(target,p);
        }
        // Complementary producer bridges share the already selected cell; strict arrival prevents cycles.
        for phase in 0..2 {let target=2*v+phase;let other=2*v+1-phase;let delay=arrival[other]+f64::from(inv.pin_delay[&inv.vars[0]]);
            if delay<arrival[target]{let m=Instance{cell:inv.name.clone(),area:inv.area,inputs:vec![other],input_pins:inv.vars.clone(),outputs:vec![OutputPin{name:inv.out_pin.clone(),delays:vec![inv.pin_delay[&inv.vars[0]]],function:1,targets:vec![target]}]};plans.insert(target,Plan{m,delay,flow:flows[other]+f64::from(inv.area)});arrival[target]=delay;flows[target]=flows[other]+f64::from(inv.area);}
        }
        for lit in [a,b]{uses[lit/2]-=1;if uses[lit/2]==0{frontier.remove(&(lit/2));}}if uses[v]>0{frontier.insert(v);}
        peak=peak.max(graph.total_size());let cutstate:usize=cuts.values().map(Vec::len).sum();cache_entries_peak=cache_entries_peak.max(cutstate);semantic_peak=semantic_peak.max(graph.total_size()+if retain_original_graph{0}else{cutstate});
        if semantic_peak>20000{return Err("global resident graph plus cached cut state exceeds allowance".into())}
        if (i+1)%256==0 || i+1==s.gates.len(){
            for &root in &frontier {if plans.contains_key(&(2*root)){for phase in 0..2{commit(2*root+phase,&plans,&mut chosen,&free,&mut instances,&mut instance_index,&mut BTreeSet::new())?;}}}
            pool_peak=pool_peak.max(instances.len()+plans.len());if pool_peak>100000{return Err("global commit plus outstanding regional proposals exceeded pool".into())}
            regions.push(serde_json::json!({"processed_ANDs":i+1,"frontier":frontier.len(),"committed_pool":instances.len(),"regional_plans":plans.len(),"cut_entries":cutstate}));
            cuts.clear();plans.clear();
            if retain_original_graph {
                // Every raw AND and interface still has its original global egg ID.
                // Cached cuts refer to these existing classes; no new interface Pi is imported.
                cuts.insert(0,vec![Cut{leaves:vec![],tt:0}]);
                for v in (1..=s.inputs.len()).chain(frontier.iter().copied()) {
                    if !ids.contains_key(&v){return Err("global retained interface is missing its original class".into())}
                    cuts.insert(v,vec![Cut{leaves:vec![v],tt:2}]);
                }
            } else {
                retired+=graph.total_size();drop(graph);ids.clear();graph=EGraph::default();boundary(&mut graph,&mut ids,&mut cuts,&frontier);cumulative+=graph.total_size();
            }peak=peak.max(graph.total_size());cache_entries_peak=cache_entries_peak.max(cuts.values().map(Vec::len).sum::<usize>());semantic_peak=semantic_peak.max(graph.total_size()+if retain_original_graph {0}else{cuts.values().map(Vec::len).sum::<usize>()});if semantic_peak>20000{return Err("initial global graph plus cut cache exceeds allowance".into())}
        }
    }
    check()?;
    // Shared whole-design cover: traverse bindings once and reclaim unused prefix cells from emission.
    let mut live=BTreeSet::new();let mut signals=BTreeSet::new();let mut todo:Vec<_>=s.outputs.iter().map(|x|x.0).collect();
    while let Some(x)=todo.pop(){if !signals.insert(x)||free[x]{continue}let b=chosen[x].ok_or("global stitched output undriven")?;if live.insert(b.instance){todo.extend(instances[b.instance].inputs.iter().copied());}}
    for (x,b) in chosen.iter_mut().enumerate(){if !signals.contains(&x){*b=None;}}
    // Check actual global emitted dependencies and recompute arrival rather than trusting flow proxies.
    let mut actual=vec![None;chosen.len()];for (x,&f) in free.iter().enumerate(){if f{actual[x]=Some(0.);}}
    let mut area=0.;for &i in &live{let m=&instances[i];let d=m.inputs.iter().zip(&m.outputs[0].delays).map(|(x,p)|actual[*x].map(|a|a+f64::from(*p)).ok_or("non-topological stitched cover")) .collect::<Result<Vec<_>,_>>()?.into_iter().fold(0.,f64::max);area+=f64::from(m.area);for &x in &m.outputs[0].targets{if signals.contains(&x){actual[x]=Some(d);}}}
    let delay=s.outputs.iter().map(|x|actual[x.0].ok_or("missing global output phase")).collect::<Result<Vec<_>,_>>()?.into_iter().fold(0.,f64::max);check()?;
    let audit=serde_json::json!({"resident_peak_enodes":peak,"all_original_classes_retained":retain_original_graph,"cut_cache_entry_peak":cache_entries_peak,"budget_note":"In full-retention mode, cut headers refer only to original globally represented classes; no extra logical interface class or new Pi is allocated. Retirement mode counts rebuilt interfaces and reports cumulative work separately.","global_resident_charged_state_peak":semantic_peak,"cumulative_materialized_enodes_including_rebuilt_boundaries":cumulative,"old_cumulative_import_budget_compliant":cumulative<=20000,"original_ANDs_materialized":s.gates.len(),"retired_enodes":retired,"regions":regions,"global_pool_committed":instances.len(),"global_pool_prefix_plus_plans_and_proposals_peak":pool_peak,"generated_variants":generated,"emitted_unique_instances":live.len(),"global_recovery_seconds":start.elapsed().as_secs_f64(),"cuts_per_original_class":maxcuts,"saturation_iterations":0,"scope":"fixed structural policy: keep every original class when the complete import bound fits 20k; otherwise retire with separately reported cumulative import ineligible for old scope; exact cuts and shared physical cover"});
    Ok((MappedGraph{instances,chosen,inputs:s.inputs.iter().enumerate().map(|(i,n)|(2*(i+1),(i+1)as u32,n.clone())).collect(),outputs:s.outputs.clone(),constants,area,delay,stats:MapStats::default()},audit))
}
fn main()->Result<(),Box<dyn std::error::Error>>{let args:Vec<_>=std::env::args().skip(1).collect();if args.len()!=4{return Err("genlib subject.json mapped.v audit.json".into())}let s:Subject=serde_json::from_slice(&std::fs::read(&args[1])?)?;let tech=TechLib::from_genlib(&args[0],4)?;let(g,a)=build(&s,&tech,2.)?;g.write_verilog(std::fs::File::create(&args[2])?,"mapped")?;std::fs::write(&args[3],serde_json::to_vec_pretty(&a)?)?;println!("{}",serde_json::json!({"area":g.area,"delay":g.delay,"audit":a}));Ok(())}

#[cfg(test)]mod tests{use super::*;
fn lib()->TechLib{TechLib::from_genlib(std::path::Path::new(env!("CARGO_MANIFEST_DIR")).parent().unwrap().parent().unwrap().join("results_v2/flow_saturation_main_checkpoint_20261014/4in_sqrt_flow_sat/asap7_4in.genlib"),4).unwrap()}
#[test]fn cuts_exact_phases_sharing_and_indexed_ports(){let s=Subject{inputs:vec!["a[0]".into(),"b".into(),"c".into()],outputs:vec![(10,"p".into()),(11,"q".into()),(9,"r".into())],gates:vec![(4,2,5),(5,8,7)]};let(g,a)=build(&s,&lib(),2.).unwrap();assert!(a["cuts_per_original_class"].as_u64().unwrap()<=16);assert_eq!(a["all_original_classes_retained"],true);assert_eq!(a["cumulative_materialized_enodes_including_rebuilt_boundaries"],6);for x in 0..8 {let p:HashMap<_,_>=(1..=3).map(|i|(i,x>>(i-1)&1!=0)).collect();let z=p[&1]&!p[&2];let y=z&!p[&3];assert_eq!(g.evaluate(&p).unwrap(),vec![y,!y,!z]);}}
#[test]fn cuts_combine_every_truth_assignment(){let x=Cut{leaves:vec![1,2],tt:8};let y=Cut{leaves:vec![2,3],tt:14};for ph in 0..4{let c=combine(&x,&y,ph,3).unwrap();for a in 0..8{let p=(a&1!=0)&(a&2!=0);let q=(a&2!=0)|(a&4!=0);assert_eq!(c.tt>>a&1!=0,(p^(ph&1!=0))&(q^(ph&2!=0)));}}}
#[test]fn complete_graph_is_retained_across_region_boundaries(){let s=Subject{inputs:vec!["a[0]".into(),"b".into()],outputs:vec![(542,"z".into()),(543,"nz".into())],gates:(3..=271).map(|v|(v,2*(v-1),2)).collect()};let(g,a)=build(&s,&lib(),2.).unwrap();assert_eq!(a["all_original_classes_retained"],true);assert_eq!(a["retired_enodes"],0);assert!(a["cumulative_materialized_enodes_including_rebuilt_boundaries"].as_u64().unwrap()<=272);for b in 0..4{let p=[(1,b&1!=0),(2,b&2!=0)].into_iter().collect();let v=b==3;assert_eq!(g.evaluate(&p).unwrap(),vec![v,!v]);}}
#[test]fn constants_are_counted_and_exact(){let s=Subject{inputs:vec![],outputs:vec![(0,"zero".into()),(1,"one".into())],gates:vec![]};let(g,a)=build(&s,&lib(),2.).unwrap();assert_eq!(a["cumulative_materialized_enodes_including_rebuilt_boundaries"],1);assert_eq!(g.evaluate(&HashMap::new()).unwrap(),vec![false,true]);}
#[test]fn pi_only_and_global_deadline(){let s=Subject{inputs:vec!["a".into(),"unused".into()],outputs:vec![(3,"q".into())],gates:vec![]};let(g,_)=build(&s,&lib(),2.).unwrap();assert_eq!(g.evaluate(&[(1,true),(2,false)].into_iter().collect()).unwrap(),vec![false]);assert!(build(&s,&lib(),0.).is_err());}
}
