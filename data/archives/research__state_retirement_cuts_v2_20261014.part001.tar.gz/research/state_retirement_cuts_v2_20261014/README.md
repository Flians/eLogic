# Regional exact cuts and shared cover, fixed structural policy

This isolated mapper leaves production and baseline algorithms unchanged.
It uses the same once-resyn2 input and restricted library. No further logic
optimization or equality-saturation iterations are run.

Every original live AND is materialized in real egg with explicit input phases.
Each original class retains at most sixteen cuts, including its trivial cut.
Cuts are matched by exact library truth tables, pin permutations and input/output
phases. Delay labels choose physical phase producers, with a fanout-based area
proxy for ties. Complementary inverter bridges require a strict arrival gain.
This is constructive heuristic selection, not global exact-area optimization.

Regions contain 256 original ANDs. Crossing phases are committed to global
physical bindings. The cover shares identical cell/input/pin tuples across
regions, then traverses all primary outputs to emit only live unique instances.
Committed instances, outstanding regional plans and temporary proposals use
one global 100000-instance ledger. No region resets this ledger or the single
2-second deadline, which includes setup, selection and final verification.
The native process guard is still 60 seconds; independent CEC is outside the
300-second mapping-only policy.

The representation policy is fixed by structure, never by measured QoR:

* If the entire original import upper bound fits 20000, retain **every** original
  egg class throughout mapping. Regional cut planning does not rebuild logical
  interfaces. Cached cuts reference already charged original classes; all leaf
  IDs are checked. Cut-header counts are separately reported. Cumulative import,
  resident nodes and original materialization are recorded, with zero retirements.
* Otherwise retire regions and rebuild certified interfaces, with conservative
  cached-cut state charging. Cumulative original/interface work remains recorded.
  A resident-only cover is never declared compliant with the old cumulative
  import budget. No opaque formula replaces original node materialization.

The complete profile is evaluated on all twenty EPFL designs in both inventories.
Failures, timeouts and regressions remain in the reports. Baseline results come
from the unchanged complete canonical campaign. This is not a casewise mixture
of profiles or repeated-run winners. Production promotion requires more than
a target-only timing gain: current full-scope timing and area regressions must
be addressed under the same budgets.
