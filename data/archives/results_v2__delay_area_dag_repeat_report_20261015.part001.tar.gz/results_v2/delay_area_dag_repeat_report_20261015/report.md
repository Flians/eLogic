# Targeted repetitions of delay seed and required-time area flow

Eight designs, both inventories, first full-suite observation plus two fresh alternating-order repetitions. One operator-induced 4in sin evaluator-log failure is retained; an independent paired recovery is additional evidence, not a silent replacement. 98 observed slots, 97 independent CEC successes, 1 unmeasured failure; 49 declared pairs, 48 legal pairs.

Delay: 6 better / 42 equal / 0 worse. Area: 36 better / 0 equal / 12 worse. Candidate pools agree and successful actual budget checks pass. No best-repeat selection; no production promotion.

| Inventory | Design | Control area range | Candidate area range | Control delay range | Candidate delay range |
|---|---|---|---|---|---|
| 3in | adder | 72.55–72.55 | 76.27–76.27 | 2585.48–2585.48 | 2585.48–2585.48 |
| 3in | bar | 289.64–294.09 | 263.25–263.25 | 190.87–190.87 | 190.87–190.87 |
| 3in | ctrl | 7.33–7.33 | 7.20–7.20 | 108.06–108.06 | 108.06–108.06 |
| 3in | int2float | 14.40–14.40 | 13.62–13.62 | 183.34–183.34 | 183.34–183.34 |
| 3in | max | 284.64–285.22 | 242.40–242.40 | 2111.03–2111.03 | 2111.03–2111.03 |
| 3in | priority | 68.54–68.54 | 69.39–69.39 | 2062.18–2062.18 | 2062.18–2062.18 |
| 3in | sin | 614.45–625.85 | 441.77–441.95 | 2095.27–2095.27 | 2095.27–2095.27 |
| 3in | sqrt | 2920.13–2921.85 | 2154.29–2155.42 | 72496.92–72605.07 | 68523.99–68523.99 |
| 4in | adder | 83.75–84.43 | 83.19–83.19 | 2585.23–2585.23 | 2585.23–2585.23 |
| 4in | bar | 304.64–304.71 | 282.77–282.77 | 188.34–188.34 | 188.34–188.34 |
| 4in | ctrl | 7.19–7.19 | 6.96–6.96 | 103.17–103.17 | 103.17–103.17 |
| 4in | int2float | 13.22–13.22 | 13.29–13.29 | 181.28–181.28 | 181.28–181.28 |
| 4in | max | 278.12–284.64 | 212.14–212.20 | 2098.34–2098.34 | 2098.34–2098.34 |
| 4in | priority | 52.55–52.55 | 53.47–55.73 | 2047.24–2047.24 | 2047.24–2047.24 |
| 4in | sin | 712.58–718.11 | 456.37–457.68 | 2029.35–2029.35 | 2029.35–2029.35 |
| 4in | sqrt | 3811.52–3819.37 | 2735.82–2736.81 | 68806.91–70464.12 | 66924.64–66924.64 |

Sqrt improves jointly in all six legal paired repetitions, but its delays remain above conventional mapping. Bar candidate area is identical in three observations per inventory; this is a small repetition study, not a guarantee of deterministic wall-budget behavior. Sin and max retain small candidate-area variability. Three-input adder, both priority inventories, and four-input int2float regress in all three pairs; priority4 candidate area ranges 53.47–55.73. The required-time sweep protects its own valid incumbent, but does not preserve the legacy flow sharing result.

Next fixed-source experiment must preserve or recover legacy sharing within one global deadline and pool. It must keep existing delay incumbents, retain all failures, and rerun all20/two inventories rather than choosing design-specific profiles. Five original input-node failures remain unresolved.
