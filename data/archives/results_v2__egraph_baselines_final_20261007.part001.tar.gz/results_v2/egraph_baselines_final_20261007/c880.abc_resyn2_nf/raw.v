// Benchmark "/home/flynn/workplace/MIGBalance/tools/mockturtle/experiments/benchmarks/c880" written by ABC on Wed Oct  7 15:30:34 2026

module \/home/flynn/workplace/MIGBalance/tools/mockturtle/experiments/benchmarks/c880  ( 
    G8, G16, G6, G17, G7, G18, G19, G4, G3, G2, G1, G5, G11, G23, G20, G21,
    G9, G10, G12, G15, G22, G32, G24, G25, G26, G27, G28, G29, G30, G31,
    G33, G41, G42, G43, G44, G45, G46, G47, G48, G49, G13, G14, G55, G59,
    G54, G60, G39, G40, G52, G53, G50, G51, G58, G35, G37, G36, G56, G57,
    G34, G38,
    G855, G856, G857, G858, G859, G860, G861, G862, G863, G864, G865, G866,
    G867, G868, G869, G870, G871, G872, G873, G874, G875, G876, G877, G878,
    G879, G880  );
  input  G8, G16, G6, G17, G7, G18, G19, G4, G3, G2, G1, G5, G11, G23,
    G20, G21, G9, G10, G12, G15, G22, G32, G24, G25, G26, G27, G28, G29,
    G30, G31, G33, G41, G42, G43, G44, G45, G46, G47, G48, G49, G13, G14,
    G55, G59, G54, G60, G39, G40, G52, G53, G50, G51, G58, G35, G37, G36,
    G56, G57, G34, G38;
  output G855, G856, G857, G858, G859, G860, G861, G862, G863, G864, G865,
    G866, G867, G868, G869, G870, G871, G872, G873, G874, G875, G876, G877,
    G878, G879, G880;
  wire new_n87_, new_n88_, new_n89_, new_n90_, new_n91_, new_n92_, new_n93_,
    new_n94_, new_n95_, new_n96_, new_n97_, new_n98_, new_n100_, new_n102_,
    new_n105_, new_n106_, new_n107_, new_n109_, new_n116_, new_n118_,
    new_n119_, new_n120_, new_n122_, new_n125_, new_n126_, new_n127_,
    new_n128_, new_n129_, new_n130_, new_n131_, new_n132_, new_n134_,
    new_n135_, new_n136_, new_n137_, new_n138_, new_n139_, new_n140_,
    new_n141_, new_n143_, new_n144_, new_n145_, new_n146_, new_n147_,
    new_n148_, new_n149_, new_n150_, new_n151_, new_n152_, new_n153_,
    new_n154_, new_n155_, new_n156_, new_n157_, new_n158_, new_n159_,
    new_n160_, new_n161_, new_n162_, new_n163_, new_n164_, new_n165_,
    new_n166_, new_n167_, new_n168_, new_n169_, new_n170_, new_n171_,
    new_n172_, new_n173_, new_n174_, new_n175_, new_n176_, new_n178_,
    new_n179_, new_n180_, new_n181_, new_n182_, new_n183_, new_n184_,
    new_n185_, new_n186_, new_n187_, new_n188_, new_n189_, new_n190_,
    new_n191_, new_n192_, new_n193_, new_n194_, new_n195_, new_n196_,
    new_n197_, new_n198_, new_n199_, new_n200_, new_n201_, new_n202_,
    new_n203_, new_n204_, new_n205_, new_n206_, new_n207_, new_n209_,
    new_n210_, new_n211_, new_n212_, new_n213_, new_n214_, new_n215_,
    new_n216_, new_n217_, new_n218_, new_n220_, new_n221_, new_n222_,
    new_n223_, new_n224_, new_n225_, new_n226_, new_n227_, new_n228_,
    new_n230_, new_n231_, new_n232_, new_n233_, new_n234_, new_n235_,
    new_n236_, new_n237_, new_n238_, new_n239_, new_n240_, new_n241_,
    new_n242_, new_n243_, new_n244_, new_n245_, new_n246_, new_n247_,
    new_n248_, new_n249_, new_n250_, new_n251_, new_n252_, new_n253_,
    new_n254_, new_n255_, new_n256_, new_n257_, new_n258_, new_n259_,
    new_n260_, new_n261_, new_n262_, new_n263_, new_n264_, new_n265_,
    new_n266_, new_n267_, new_n268_, new_n270_, new_n271_, new_n272_,
    new_n273_, new_n274_, new_n275_, new_n276_, new_n277_, new_n278_,
    new_n280_, new_n281_, new_n282_, new_n283_, new_n284_, new_n285_,
    new_n286_, new_n287_, new_n289_, new_n290_, new_n291_, new_n292_,
    new_n293_, new_n294_, new_n295_, new_n296_, new_n297_, new_n298_,
    new_n300_, new_n301_, new_n302_, new_n303_, new_n304_, new_n305_,
    new_n306_, new_n307_, new_n308_, new_n309_;
  INVx1_ASAP7_75t_R   g000(.A(G8), .Y(new_n87_));
  INVx1_ASAP7_75t_R   g001(.A(G4), .Y(new_n88_));
  INVx1_ASAP7_75t_R   g002(.A(G41), .Y(new_n89_));
  INVx1_ASAP7_75t_R   g003(.A(G42), .Y(new_n90_));
  INVx1_ASAP7_75t_R   g004(.A(G43), .Y(new_n91_));
  INVx1_ASAP7_75t_R   g005(.A(G46), .Y(new_n92_));
  INVx1_ASAP7_75t_R   g006(.A(G47), .Y(new_n93_));
  INVx1_ASAP7_75t_R   g007(.A(G60), .Y(new_n94_));
  INVx1_ASAP7_75t_R   g008(.A(G39), .Y(new_n95_));
  INVx1_ASAP7_75t_R   g009(.A(G52), .Y(new_n96_));
  INVx1_ASAP7_75t_R   g010(.A(G51), .Y(new_n97_));
  AND3x1_ASAP7_75t_R  g011(.A(G8), .B(G16), .C(G6), .Y(new_n98_));
  INVx1_ASAP7_75t_R   g012(.A(new_n98_), .Y(G855));
  AND3x1_ASAP7_75t_R  g013(.A(G6), .B(G17), .C(G7), .Y(new_n100_));
  INVx1_ASAP7_75t_R   g014(.A(new_n100_), .Y(G856));
  AND3x1_ASAP7_75t_R  g015(.A(G8), .B(G6), .C(G7), .Y(new_n102_));
  INVx1_ASAP7_75t_R   g016(.A(new_n102_), .Y(G857));
  NAND2x1_ASAP7_75t_R g017(.A(G18), .B(G19), .Y(G858));
  AND2x2_ASAP7_75t_R  g018(.A(G4), .B(G3), .Y(new_n105_));
  NAND2x1_ASAP7_75t_R g019(.A(G2), .B(G1), .Y(new_n106_));
  AND3x1_ASAP7_75t_R  g020(.A(G2), .B(G1), .C(new_n105_), .Y(new_n107_));
  INVx1_ASAP7_75t_R   g021(.A(new_n107_), .Y(G859));
  AND2x2_ASAP7_75t_R  g022(.A(G1), .B(G5), .Y(new_n109_));
  AND3x1_ASAP7_75t_R  g023(.A(G857), .B(new_n105_), .C(new_n109_), .Y(G860));
  AND3x1_ASAP7_75t_R  g024(.A(G16), .B(G17), .C(G11), .Y(G861));
  AND3x1_ASAP7_75t_R  g025(.A(G17), .B(G7), .C(G11), .Y(G862));
  AND3x1_ASAP7_75t_R  g026(.A(G8), .B(G7), .C(G11), .Y(G863));
  OAI21x1_ASAP7_75t_R g027(.A1(G20), .A2(G21), .B(G23), .Y(G864));
  AND3x1_ASAP7_75t_R  g028(.A(new_n102_), .B(new_n105_), .C(new_n109_), .Y(G865));
  AND3x1_ASAP7_75t_R  g029(.A(G1), .B(G5), .C(G9), .Y(new_n116_));
  INVx1_ASAP7_75t_R   g030(.A(new_n116_), .Y(G866));
  NAND2x1_ASAP7_75t_R g031(.A(G3), .B(G10), .Y(new_n118_));
  NOR2x1_ASAP7_75t_R  g032(.A(new_n106_), .B(new_n118_), .Y(new_n119_));
  AND3x1_ASAP7_75t_R  g033(.A(G6), .B(G12), .C(new_n119_), .Y(new_n120_));
  INVx1_ASAP7_75t_R   g034(.A(new_n120_), .Y(G867));
  AND3x1_ASAP7_75t_R  g035(.A(G11), .B(G12), .C(new_n119_), .Y(new_n122_));
  NAND2x1_ASAP7_75t_R g036(.A(G15), .B(new_n122_), .Y(G868));
  OAI21x1_ASAP7_75t_R g037(.A1(G20), .A2(G21), .B(G22), .Y(G869));
  XOR2x2_ASAP7_75t_R  g038(.A(G24), .B(G25), .Y(new_n125_));
  XOR2x2_ASAP7_75t_R  g039(.A(G32), .B(new_n125_), .Y(new_n126_));
  XNOR2x2_ASAP7_75t_R g040(.A(G30), .B(G31), .Y(new_n127_));
  XOR2x2_ASAP7_75t_R  g041(.A(new_n126_), .B(new_n127_), .Y(new_n128_));
  XOR2x2_ASAP7_75t_R  g042(.A(G28), .B(G29), .Y(new_n129_));
  XOR2x2_ASAP7_75t_R  g043(.A(G33), .B(new_n129_), .Y(new_n130_));
  XOR2x2_ASAP7_75t_R  g044(.A(G26), .B(G27), .Y(new_n131_));
  XOR2x2_ASAP7_75t_R  g045(.A(new_n130_), .B(new_n131_), .Y(new_n132_));
  XOR2x2_ASAP7_75t_R  g046(.A(new_n128_), .B(new_n132_), .Y(G870));
  XOR2x2_ASAP7_75t_R  g047(.A(G41), .B(G42), .Y(new_n134_));
  XOR2x2_ASAP7_75t_R  g048(.A(G32), .B(new_n134_), .Y(new_n135_));
  XNOR2x2_ASAP7_75t_R g049(.A(G47), .B(G48), .Y(new_n136_));
  XOR2x2_ASAP7_75t_R  g050(.A(new_n135_), .B(new_n136_), .Y(new_n137_));
  XOR2x2_ASAP7_75t_R  g051(.A(G45), .B(G46), .Y(new_n138_));
  XOR2x2_ASAP7_75t_R  g052(.A(G49), .B(new_n138_), .Y(new_n139_));
  XOR2x2_ASAP7_75t_R  g053(.A(G43), .B(G44), .Y(new_n140_));
  XOR2x2_ASAP7_75t_R  g054(.A(new_n139_), .B(new_n140_), .Y(new_n141_));
  XOR2x2_ASAP7_75t_R  g055(.A(new_n137_), .B(new_n141_), .Y(G871));
  AND2x2_ASAP7_75t_R  g056(.A(G11), .B(G40), .Y(new_n143_));
  NAND2x1_ASAP7_75t_R g057(.A(G11), .B(G40), .Y(new_n144_));
  NAND2x1_ASAP7_75t_R g058(.A(new_n144_), .B(new_n116_), .Y(new_n145_));
  OAI21x1_ASAP7_75t_R g059(.A1(new_n88_), .A2(new_n145_), .B(G1), .Y(new_n146_));
  INVx1_ASAP7_75t_R   g060(.A(new_n146_), .Y(new_n147_));
  OR2x4_ASAP7_75t_R   g061(.A(G8), .B(G4), .Y(new_n148_));
  NAND2x1_ASAP7_75t_R g062(.A(G8), .B(G4), .Y(new_n149_));
  OA21x2_ASAP7_75t_R  g063(.A1(new_n87_), .A2(new_n88_), .B(new_n143_), .Y(new_n150_));
  NAND3x1_ASAP7_75t_R g064(.A(new_n148_), .B(new_n149_), .C(new_n143_), .Y(new_n151_));
  AND3x1_ASAP7_75t_R  g065(.A(new_n116_), .B(new_n150_), .C(new_n148_), .Y(new_n152_));
  AND3x1_ASAP7_75t_R  g066(.A(G8), .B(G16), .C(G11), .Y(new_n153_));
  NAND2x1_ASAP7_75t_R g067(.A(G4), .B(G9), .Y(new_n154_));
  OR3x1_ASAP7_75t_R   g068(.A(new_n153_), .B(new_n154_), .C(new_n106_), .Y(new_n155_));
  INVx1_ASAP7_75t_R   g069(.A(new_n155_), .Y(new_n156_));
  OAI21x1_ASAP7_75t_R g070(.A1(G866), .A2(new_n151_), .B(new_n155_), .Y(new_n157_));
  AND3x1_ASAP7_75t_R  g071(.A(G16), .B(G6), .C(G17), .Y(new_n158_));
  AND2x2_ASAP7_75t_R  g072(.A(new_n94_), .B(G10), .Y(new_n159_));
  AND3x1_ASAP7_75t_R  g073(.A(new_n116_), .B(new_n158_), .C(new_n159_), .Y(new_n160_));
  AOI21x1_ASAP7_75t_R g074(.A1(G31), .A2(new_n157_), .B(new_n160_), .Y(new_n161_));
  OAI21x1_ASAP7_75t_R g075(.A1(new_n95_), .A2(new_n147_), .B(new_n161_), .Y(new_n162_));
  AND2x2_ASAP7_75t_R  g076(.A(new_n162_), .B(G48), .Y(new_n163_));
  XOR2x2_ASAP7_75t_R  g077(.A(G48), .B(new_n162_), .Y(new_n164_));
  OA21x2_ASAP7_75t_R  g078(.A1(new_n162_), .A2(G48), .B(G58), .Y(new_n165_));
  OAI21x1_ASAP7_75t_R g079(.A1(G48), .A2(new_n162_), .B(G58), .Y(new_n166_));
  OA21x2_ASAP7_75t_R  g080(.A1(new_n163_), .A2(new_n166_), .B(G51), .Y(new_n167_));
  OA21x2_ASAP7_75t_R  g081(.A1(G58), .A2(new_n164_), .B(new_n167_), .Y(new_n168_));
  AO21x1_ASAP7_75t_R  g082(.A1(G48), .A2(G53), .B(G54), .Y(new_n169_));
  AND3x1_ASAP7_75t_R  g083(.A(G8), .B(G13), .C(G14), .Y(new_n170_));
  AND2x2_ASAP7_75t_R  g084(.A(new_n122_), .B(new_n170_), .Y(new_n171_));
  AND2x2_ASAP7_75t_R  g085(.A(G55), .B(G59), .Y(new_n172_));
  AO21x1_ASAP7_75t_R  g086(.A1(G30), .A2(G50), .B(new_n172_), .Y(new_n173_));
  AO21x1_ASAP7_75t_R  g087(.A1(G48), .A2(new_n171_), .B(new_n173_), .Y(new_n174_));
  AO21x1_ASAP7_75t_R  g088(.A1(new_n162_), .A2(new_n169_), .B(new_n174_), .Y(new_n175_));
  AO21x1_ASAP7_75t_R  g089(.A1(G52), .A2(new_n164_), .B(new_n175_), .Y(new_n176_));
  NOR2x1_ASAP7_75t_R  g090(.A(new_n176_), .B(new_n168_), .Y(G872));
  AO21x1_ASAP7_75t_R  g091(.A1(new_n146_), .A2(G35), .B(new_n160_), .Y(new_n178_));
  AO21x1_ASAP7_75t_R  g092(.A1(G28), .A2(new_n157_), .B(new_n178_), .Y(new_n179_));
  NOR2x1_ASAP7_75t_R  g093(.A(G45), .B(new_n179_), .Y(new_n180_));
  NAND2x1_ASAP7_75t_R g094(.A(G45), .B(new_n179_), .Y(new_n181_));
  INVx1_ASAP7_75t_R   g095(.A(new_n181_), .Y(new_n182_));
  OR2x4_ASAP7_75t_R   g096(.A(new_n180_), .B(new_n182_), .Y(new_n183_));
  INVx1_ASAP7_75t_R   g097(.A(new_n183_), .Y(new_n184_));
  NOR2x1_ASAP7_75t_R  g098(.A(new_n163_), .B(new_n165_), .Y(new_n185_));
  MAJx2_ASAP7_75t_R   g099(.A(new_n162_), .B(G58), .C(G48), .Y(new_n186_));
  OAI21x1_ASAP7_75t_R g100(.A1(new_n152_), .A2(new_n156_), .B(G29), .Y(new_n187_));
  AOI21x1_ASAP7_75t_R g101(.A1(G36), .A2(new_n146_), .B(new_n160_), .Y(new_n188_));
  AND2x2_ASAP7_75t_R  g102(.A(new_n187_), .B(new_n188_), .Y(new_n189_));
  AND3x1_ASAP7_75t_R  g103(.A(new_n92_), .B(new_n187_), .C(new_n188_), .Y(new_n190_));
  AND2x2_ASAP7_75t_R  g104(.A(new_n157_), .B(G30), .Y(new_n191_));
  AO21x1_ASAP7_75t_R  g105(.A1(new_n146_), .A2(G37), .B(new_n160_), .Y(new_n192_));
  AOI21x1_ASAP7_75t_R g106(.A1(G30), .A2(new_n157_), .B(new_n192_), .Y(new_n193_));
  AOI21x1_ASAP7_75t_R g107(.A1(new_n93_), .A2(new_n193_), .B(new_n190_), .Y(new_n194_));
  OAI21x1_ASAP7_75t_R g108(.A1(new_n163_), .A2(new_n165_), .B(new_n194_), .Y(new_n195_));
  AO21x1_ASAP7_75t_R  g109(.A1(new_n187_), .A2(new_n188_), .B(new_n92_), .Y(new_n196_));
  OAI21x1_ASAP7_75t_R g110(.A1(new_n192_), .A2(new_n191_), .B(G47), .Y(new_n197_));
  OA21x2_ASAP7_75t_R  g111(.A1(new_n190_), .A2(new_n197_), .B(new_n196_), .Y(new_n198_));
  OAI21x1_ASAP7_75t_R g112(.A1(new_n197_), .A2(new_n190_), .B(new_n196_), .Y(new_n199_));
  AOI21x1_ASAP7_75t_R g113(.A1(new_n194_), .A2(new_n186_), .B(new_n199_), .Y(new_n200_));
  NAND2x1_ASAP7_75t_R g114(.A(new_n200_), .B(new_n183_), .Y(new_n201_));
  OA21x2_ASAP7_75t_R  g115(.A1(new_n183_), .A2(new_n200_), .B(G51), .Y(new_n202_));
  AO21x1_ASAP7_75t_R  g116(.A1(G45), .A2(G53), .B(G54), .Y(new_n203_));
  AND2x2_ASAP7_75t_R  g117(.A(G27), .B(G50), .Y(new_n204_));
  AO21x1_ASAP7_75t_R  g118(.A1(G45), .A2(new_n171_), .B(new_n204_), .Y(new_n205_));
  AO21x1_ASAP7_75t_R  g119(.A1(new_n179_), .A2(new_n203_), .B(new_n205_), .Y(new_n206_));
  AO21x1_ASAP7_75t_R  g120(.A1(G52), .A2(new_n184_), .B(new_n206_), .Y(new_n207_));
  AOI21x1_ASAP7_75t_R g121(.A1(new_n201_), .A2(new_n202_), .B(new_n207_), .Y(G873));
  XOR2x2_ASAP7_75t_R  g122(.A(G46), .B(new_n189_), .Y(new_n209_));
  MAJx2_ASAP7_75t_R   g123(.A(new_n185_), .B(new_n193_), .C(new_n93_), .Y(new_n210_));
  OAI21x1_ASAP7_75t_R g124(.A1(new_n209_), .A2(new_n210_), .B(G51), .Y(new_n211_));
  AO21x1_ASAP7_75t_R  g125(.A1(new_n209_), .A2(new_n210_), .B(new_n211_), .Y(new_n212_));
  AOI21x1_ASAP7_75t_R g126(.A1(G46), .A2(G53), .B(G54), .Y(new_n213_));
  AND2x2_ASAP7_75t_R  g127(.A(G55), .B(G56), .Y(new_n214_));
  AO21x1_ASAP7_75t_R  g128(.A1(G28), .A2(G50), .B(new_n214_), .Y(new_n215_));
  AOI21x1_ASAP7_75t_R g129(.A1(G46), .A2(new_n171_), .B(new_n215_), .Y(new_n216_));
  OA21x2_ASAP7_75t_R  g130(.A1(new_n189_), .A2(new_n213_), .B(new_n216_), .Y(new_n217_));
  OA21x2_ASAP7_75t_R  g131(.A1(new_n96_), .A2(new_n209_), .B(new_n217_), .Y(new_n218_));
  AND2x2_ASAP7_75t_R  g132(.A(new_n212_), .B(new_n218_), .Y(G874));
  XOR2x2_ASAP7_75t_R  g133(.A(G47), .B(new_n193_), .Y(new_n220_));
  NOR2x1_ASAP7_75t_R  g134(.A(new_n220_), .B(new_n185_), .Y(new_n221_));
  AO21x1_ASAP7_75t_R  g135(.A1(new_n185_), .A2(new_n220_), .B(new_n97_), .Y(new_n222_));
  AOI21x1_ASAP7_75t_R g136(.A1(G47), .A2(G53), .B(G54), .Y(new_n223_));
  AND2x2_ASAP7_75t_R  g137(.A(G55), .B(G57), .Y(new_n224_));
  AO21x1_ASAP7_75t_R  g138(.A1(G29), .A2(G50), .B(new_n224_), .Y(new_n225_));
  AOI21x1_ASAP7_75t_R g139(.A1(G47), .A2(new_n171_), .B(new_n225_), .Y(new_n226_));
  OA21x2_ASAP7_75t_R  g140(.A1(new_n193_), .A2(new_n223_), .B(new_n226_), .Y(new_n227_));
  OA21x2_ASAP7_75t_R  g141(.A1(new_n96_), .A2(new_n220_), .B(new_n227_), .Y(new_n228_));
  OA21x2_ASAP7_75t_R  g142(.A1(new_n221_), .A2(new_n222_), .B(new_n228_), .Y(G875));
  AND3x1_ASAP7_75t_R  g143(.A(G10), .B(new_n116_), .C(new_n144_), .Y(new_n230_));
  AND2x2_ASAP7_75t_R  g144(.A(new_n94_), .B(G4), .Y(new_n231_));
  AND3x1_ASAP7_75t_R  g145(.A(new_n116_), .B(new_n158_), .C(new_n231_), .Y(new_n232_));
  AO21x1_ASAP7_75t_R  g146(.A1(G2), .A2(G34), .B(new_n232_), .Y(new_n233_));
  AO21x1_ASAP7_75t_R  g147(.A1(G35), .A2(new_n230_), .B(new_n233_), .Y(new_n234_));
  AOI21x1_ASAP7_75t_R g148(.A1(G24), .A2(new_n157_), .B(new_n234_), .Y(new_n235_));
  INVx1_ASAP7_75t_R   g149(.A(new_n235_), .Y(new_n236_));
  AND2x2_ASAP7_75t_R  g150(.A(new_n157_), .B(G27), .Y(new_n237_));
  AND2x2_ASAP7_75t_R  g151(.A(G39), .B(new_n230_), .Y(new_n238_));
  AND2x2_ASAP7_75t_R  g152(.A(G34), .B(G38), .Y(new_n239_));
  OR3x1_ASAP7_75t_R   g153(.A(new_n232_), .B(new_n238_), .C(new_n239_), .Y(new_n240_));
  NOR2x1_ASAP7_75t_R  g154(.A(new_n240_), .B(new_n237_), .Y(new_n241_));
  INVx1_ASAP7_75t_R   g155(.A(new_n241_), .Y(new_n242_));
  OR3x1_ASAP7_75t_R   g156(.A(G44), .B(new_n237_), .C(new_n240_), .Y(new_n243_));
  AOI21x1_ASAP7_75t_R g157(.A1(new_n198_), .A2(new_n195_), .B(new_n180_), .Y(new_n244_));
  OAI21x1_ASAP7_75t_R g158(.A1(new_n180_), .A2(new_n200_), .B(new_n181_), .Y(new_n245_));
  OAI21x1_ASAP7_75t_R g159(.A1(new_n182_), .A2(new_n244_), .B(new_n243_), .Y(new_n246_));
  AND2x2_ASAP7_75t_R  g160(.A(new_n157_), .B(G26), .Y(new_n247_));
  AO21x1_ASAP7_75t_R  g161(.A1(G4), .A2(G34), .B(new_n232_), .Y(new_n248_));
  AO21x1_ASAP7_75t_R  g162(.A1(G37), .A2(new_n230_), .B(new_n248_), .Y(new_n249_));
  NOR2x1_ASAP7_75t_R  g163(.A(new_n247_), .B(new_n249_), .Y(new_n250_));
  AO21x1_ASAP7_75t_R  g164(.A1(G26), .A2(new_n157_), .B(new_n249_), .Y(new_n251_));
  NOR2x1_ASAP7_75t_R  g165(.A(G43), .B(new_n251_), .Y(new_n252_));
  OR3x1_ASAP7_75t_R   g166(.A(new_n249_), .B(new_n247_), .C(G43), .Y(new_n253_));
  AO21x1_ASAP7_75t_R  g167(.A1(G9), .A2(G34), .B(new_n232_), .Y(new_n254_));
  AO21x1_ASAP7_75t_R  g168(.A1(G36), .A2(new_n230_), .B(new_n254_), .Y(new_n255_));
  AO21x1_ASAP7_75t_R  g169(.A1(G25), .A2(new_n157_), .B(new_n255_), .Y(new_n256_));
  INVx1_ASAP7_75t_R   g170(.A(new_n256_), .Y(new_n257_));
  OA21x2_ASAP7_75t_R  g171(.A1(G42), .A2(new_n256_), .B(new_n253_), .Y(new_n258_));
  AO21x1_ASAP7_75t_R  g172(.A1(new_n90_), .A2(new_n257_), .B(new_n252_), .Y(new_n259_));
  AND3x1_ASAP7_75t_R  g173(.A(new_n243_), .B(new_n245_), .C(new_n258_), .Y(new_n260_));
  OA21x2_ASAP7_75t_R  g174(.A1(new_n237_), .A2(new_n240_), .B(G44), .Y(new_n261_));
  OAI21x1_ASAP7_75t_R g175(.A1(new_n240_), .A2(new_n237_), .B(G44), .Y(new_n262_));
  MAJx2_ASAP7_75t_R   g176(.A(G43), .B(new_n251_), .C(new_n261_), .Y(new_n263_));
  MAJx2_ASAP7_75t_R   g177(.A(new_n250_), .B(new_n262_), .C(new_n91_), .Y(new_n264_));
  MAJx2_ASAP7_75t_R   g178(.A(new_n90_), .B(new_n257_), .C(new_n264_), .Y(new_n265_));
  MAJx2_ASAP7_75t_R   g179(.A(G42), .B(new_n256_), .C(new_n263_), .Y(new_n266_));
  NOR2x1_ASAP7_75t_R  g180(.A(new_n266_), .B(new_n260_), .Y(new_n267_));
  OAI21x1_ASAP7_75t_R g181(.A1(new_n246_), .A2(new_n259_), .B(new_n265_), .Y(new_n268_));
  MAJx2_ASAP7_75t_R   g182(.A(new_n267_), .B(new_n89_), .C(new_n235_), .Y(G876));
  NAND2x1_ASAP7_75t_R g183(.A(new_n243_), .B(new_n262_), .Y(new_n270_));
  INVx1_ASAP7_75t_R   g184(.A(new_n270_), .Y(new_n271_));
  AOI21x1_ASAP7_75t_R g185(.A1(new_n271_), .A2(new_n245_), .B(new_n97_), .Y(new_n272_));
  OA21x2_ASAP7_75t_R  g186(.A1(new_n245_), .A2(new_n271_), .B(new_n272_), .Y(new_n273_));
  AO21x1_ASAP7_75t_R  g187(.A1(G44), .A2(G53), .B(G54), .Y(new_n274_));
  AND2x2_ASAP7_75t_R  g188(.A(G26), .B(G50), .Y(new_n275_));
  AO21x1_ASAP7_75t_R  g189(.A1(G44), .A2(new_n171_), .B(new_n275_), .Y(new_n276_));
  AO21x1_ASAP7_75t_R  g190(.A1(new_n242_), .A2(new_n274_), .B(new_n276_), .Y(new_n277_));
  AO21x1_ASAP7_75t_R  g191(.A1(G52), .A2(new_n271_), .B(new_n277_), .Y(new_n278_));
  NOR2x1_ASAP7_75t_R  g192(.A(new_n278_), .B(new_n273_), .Y(G877));
  XOR2x2_ASAP7_75t_R  g193(.A(new_n89_), .B(new_n235_), .Y(new_n280_));
  OR3x1_ASAP7_75t_R   g194(.A(new_n260_), .B(new_n266_), .C(new_n280_), .Y(new_n281_));
  AOI21x1_ASAP7_75t_R g195(.A1(new_n280_), .A2(new_n268_), .B(new_n97_), .Y(new_n282_));
  AO21x1_ASAP7_75t_R  g196(.A1(G41), .A2(G53), .B(G54), .Y(new_n283_));
  AND2x2_ASAP7_75t_R  g197(.A(G60), .B(G50), .Y(new_n284_));
  AO21x1_ASAP7_75t_R  g198(.A1(G41), .A2(new_n171_), .B(new_n284_), .Y(new_n285_));
  AO21x1_ASAP7_75t_R  g199(.A1(new_n236_), .A2(new_n283_), .B(new_n285_), .Y(new_n286_));
  AO21x1_ASAP7_75t_R  g200(.A1(G52), .A2(new_n280_), .B(new_n286_), .Y(new_n287_));
  AOI21x1_ASAP7_75t_R g201(.A1(new_n281_), .A2(new_n282_), .B(new_n287_), .Y(G878));
  XOR2x2_ASAP7_75t_R  g202(.A(G42), .B(new_n256_), .Y(new_n289_));
  AND3x1_ASAP7_75t_R  g203(.A(new_n243_), .B(new_n245_), .C(new_n253_), .Y(new_n290_));
  OAI21x1_ASAP7_75t_R g204(.A1(new_n252_), .A2(new_n246_), .B(new_n264_), .Y(new_n291_));
  OR3x1_ASAP7_75t_R   g205(.A(new_n263_), .B(new_n289_), .C(new_n290_), .Y(new_n292_));
  AOI21x1_ASAP7_75t_R g206(.A1(new_n289_), .A2(new_n291_), .B(new_n97_), .Y(new_n293_));
  AO21x1_ASAP7_75t_R  g207(.A1(G42), .A2(G53), .B(G54), .Y(new_n294_));
  AND2x2_ASAP7_75t_R  g208(.A(G24), .B(G50), .Y(new_n295_));
  AO21x1_ASAP7_75t_R  g209(.A1(G42), .A2(new_n171_), .B(new_n295_), .Y(new_n296_));
  AO21x1_ASAP7_75t_R  g210(.A1(new_n256_), .A2(new_n294_), .B(new_n296_), .Y(new_n297_));
  AO21x1_ASAP7_75t_R  g211(.A1(G52), .A2(new_n289_), .B(new_n297_), .Y(new_n298_));
  AOI21x1_ASAP7_75t_R g212(.A1(new_n292_), .A2(new_n293_), .B(new_n298_), .Y(G879));
  XOR2x2_ASAP7_75t_R  g213(.A(new_n91_), .B(new_n251_), .Y(new_n300_));
  INVx1_ASAP7_75t_R   g214(.A(new_n300_), .Y(new_n301_));
  AOI21x1_ASAP7_75t_R g215(.A1(new_n243_), .A2(new_n245_), .B(new_n261_), .Y(new_n302_));
  NAND2x1_ASAP7_75t_R g216(.A(new_n300_), .B(new_n302_), .Y(new_n303_));
  OA21x2_ASAP7_75t_R  g217(.A1(new_n302_), .A2(new_n300_), .B(G51), .Y(new_n304_));
  AO21x1_ASAP7_75t_R  g218(.A1(G43), .A2(G53), .B(G54), .Y(new_n305_));
  AND2x2_ASAP7_75t_R  g219(.A(G25), .B(G50), .Y(new_n306_));
  AO21x1_ASAP7_75t_R  g220(.A1(G43), .A2(new_n171_), .B(new_n306_), .Y(new_n307_));
  AO21x1_ASAP7_75t_R  g221(.A1(new_n251_), .A2(new_n305_), .B(new_n307_), .Y(new_n308_));
  AO21x1_ASAP7_75t_R  g222(.A1(G52), .A2(new_n301_), .B(new_n308_), .Y(new_n309_));
  AOI21x1_ASAP7_75t_R g223(.A1(new_n304_), .A2(new_n303_), .B(new_n309_), .Y(G880));
endmodule


