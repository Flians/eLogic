// Benchmark "/home/flynn/workplace/MIGBalance/tools/mockturtle/experiments/benchmarks/c432" written by ABC on Wed Oct  7 15:30:25 2026

module \/home/flynn/workplace/MIGBalance/tools/mockturtle/experiments/benchmarks/c432  ( 
    G32, G34, G28, G30, G24, G26, G20, G22, G16, G18, G12, G14, G8, G10,
    G4, G6, G1, G2, G35, G31, G27, G23, G19, G15, G11, G7, G3, G36, G33,
    G29, G25, G21, G17, G13, G9, G5,
    G426, G427, G428, G429, G430, G431, G432  );
  input  G32, G34, G28, G30, G24, G26, G20, G22, G16, G18, G12, G14, G8,
    G10, G4, G6, G1, G2, G35, G31, G27, G23, G19, G15, G11, G7, G3, G36,
    G33, G29, G25, G21, G17, G13, G9, G5;
  output G426, G427, G428, G429, G430, G431, G432;
  wire new_n44_, new_n45_, new_n46_, new_n47_, new_n48_, new_n49_, new_n50_,
    new_n51_, new_n52_, new_n53_, new_n54_, new_n55_, new_n56_, new_n57_,
    new_n58_, new_n59_, new_n60_, new_n61_, new_n62_, new_n63_, new_n64_,
    new_n65_, new_n66_, new_n67_, new_n68_, new_n69_, new_n70_, new_n71_,
    new_n72_, new_n73_, new_n74_, new_n75_, new_n76_, new_n77_, new_n79_,
    new_n80_, new_n81_, new_n82_, new_n83_, new_n84_, new_n85_, new_n86_,
    new_n87_, new_n88_, new_n89_, new_n90_, new_n91_, new_n92_, new_n93_,
    new_n94_, new_n95_, new_n96_, new_n97_, new_n98_, new_n99_, new_n100_,
    new_n101_, new_n102_, new_n104_, new_n105_, new_n106_, new_n107_,
    new_n108_, new_n109_, new_n110_, new_n111_, new_n112_, new_n113_,
    new_n114_, new_n115_, new_n116_, new_n117_, new_n118_, new_n119_,
    new_n120_, new_n121_, new_n122_, new_n123_, new_n124_, new_n125_,
    new_n126_, new_n127_, new_n128_, new_n129_, new_n130_, new_n131_,
    new_n132_, new_n134_, new_n135_, new_n136_, new_n137_, new_n138_,
    new_n139_, new_n140_, new_n141_, new_n142_, new_n143_, new_n144_,
    new_n146_, new_n147_, new_n148_, new_n149_, new_n150_, new_n151_,
    new_n152_, new_n153_, new_n154_, new_n156_, new_n157_, new_n158_,
    new_n160_, new_n161_, new_n162_;
  INVx1_ASAP7_75t_R   g000(.A(G32), .Y(new_n44_));
  INVx1_ASAP7_75t_R   g001(.A(G34), .Y(new_n45_));
  INVx1_ASAP7_75t_R   g002(.A(G30), .Y(new_n46_));
  INVx1_ASAP7_75t_R   g003(.A(G24), .Y(new_n47_));
  INVx1_ASAP7_75t_R   g004(.A(G26), .Y(new_n48_));
  INVx1_ASAP7_75t_R   g005(.A(G20), .Y(new_n49_));
  INVx1_ASAP7_75t_R   g006(.A(G22), .Y(new_n50_));
  INVx1_ASAP7_75t_R   g007(.A(G16), .Y(new_n51_));
  INVx1_ASAP7_75t_R   g008(.A(G18), .Y(new_n52_));
  INVx1_ASAP7_75t_R   g009(.A(G14), .Y(new_n53_));
  INVx1_ASAP7_75t_R   g010(.A(G10), .Y(new_n54_));
  INVx1_ASAP7_75t_R   g011(.A(G6), .Y(new_n55_));
  INVx1_ASAP7_75t_R   g012(.A(G1), .Y(new_n56_));
  INVx1_ASAP7_75t_R   g013(.A(G2), .Y(new_n57_));
  INVx1_ASAP7_75t_R   g014(.A(G31), .Y(new_n58_));
  INVx1_ASAP7_75t_R   g015(.A(G11), .Y(new_n59_));
  INVx1_ASAP7_75t_R   g016(.A(G7), .Y(new_n60_));
  INVx1_ASAP7_75t_R   g017(.A(G36), .Y(new_n61_));
  INVx1_ASAP7_75t_R   g018(.A(G33), .Y(new_n62_));
  INVx1_ASAP7_75t_R   g019(.A(G25), .Y(new_n63_));
  INVx1_ASAP7_75t_R   g020(.A(G21), .Y(new_n64_));
  INVx1_ASAP7_75t_R   g021(.A(G17), .Y(new_n65_));
  INVx1_ASAP7_75t_R   g022(.A(G13), .Y(new_n66_));
  INVx1_ASAP7_75t_R   g023(.A(G9), .Y(new_n67_));
  NAND2x1_ASAP7_75t_R g024(.A(G22), .B(new_n49_), .Y(new_n68_));
  OA21x2_ASAP7_75t_R  g025(.A1(G12), .A2(new_n53_), .B(new_n68_), .Y(new_n69_));
  OA21x2_ASAP7_75t_R  g026(.A1(G16), .A2(new_n52_), .B(new_n69_), .Y(new_n70_));
  NAND2x1_ASAP7_75t_R g027(.A(G34), .B(new_n44_), .Y(new_n71_));
  OA21x2_ASAP7_75t_R  g028(.A1(G28), .A2(new_n46_), .B(new_n71_), .Y(new_n72_));
  NAND2x1_ASAP7_75t_R g029(.A(G26), .B(new_n47_), .Y(new_n73_));
  OA21x2_ASAP7_75t_R  g030(.A1(G8), .A2(new_n54_), .B(new_n73_), .Y(new_n74_));
  NAND2x1_ASAP7_75t_R g031(.A(G2), .B(new_n56_), .Y(new_n75_));
  OA21x2_ASAP7_75t_R  g032(.A1(G4), .A2(new_n55_), .B(new_n75_), .Y(new_n76_));
  AND3x1_ASAP7_75t_R  g033(.A(new_n72_), .B(new_n74_), .C(new_n76_), .Y(new_n77_));
  NAND2x1_ASAP7_75t_R g034(.A(new_n70_), .B(new_n77_), .Y(G426));
  AO21x1_ASAP7_75t_R  g035(.A1(G426), .A2(G28), .B(new_n46_), .Y(new_n79_));
  AND3x1_ASAP7_75t_R  g036(.A(new_n70_), .B(new_n77_), .C(new_n73_), .Y(new_n80_));
  AOI21x1_ASAP7_75t_R g037(.A1(new_n70_), .A2(new_n77_), .B(new_n73_), .Y(new_n81_));
  NOR2x1_ASAP7_75t_R  g038(.A(G27), .B(new_n48_), .Y(new_n82_));
  OAI21x1_ASAP7_75t_R g039(.A1(new_n80_), .A2(new_n81_), .B(new_n82_), .Y(new_n83_));
  AO21x1_ASAP7_75t_R  g040(.A1(G426), .A2(G8), .B(new_n54_), .Y(new_n84_));
  OA21x2_ASAP7_75t_R  g041(.A1(G11), .A2(new_n84_), .B(new_n83_), .Y(new_n85_));
  OA21x2_ASAP7_75t_R  g042(.A1(G31), .A2(new_n79_), .B(new_n85_), .Y(new_n86_));
  AOI21x1_ASAP7_75t_R g043(.A1(new_n70_), .A2(new_n77_), .B(new_n49_), .Y(new_n87_));
  AO21x1_ASAP7_75t_R  g044(.A1(G426), .A2(G20), .B(new_n50_), .Y(new_n88_));
  OR3x1_ASAP7_75t_R   g045(.A(new_n87_), .B(new_n50_), .C(G23), .Y(new_n89_));
  AO21x1_ASAP7_75t_R  g046(.A1(G426), .A2(G12), .B(new_n53_), .Y(new_n90_));
  OA21x2_ASAP7_75t_R  g047(.A1(G15), .A2(new_n90_), .B(new_n89_), .Y(new_n91_));
  AOI21x1_ASAP7_75t_R g048(.A1(new_n70_), .A2(new_n77_), .B(new_n51_), .Y(new_n92_));
  AO21x1_ASAP7_75t_R  g049(.A1(G426), .A2(G16), .B(new_n52_), .Y(new_n93_));
  OR3x1_ASAP7_75t_R   g050(.A(new_n92_), .B(new_n52_), .C(G19), .Y(new_n94_));
  AO21x1_ASAP7_75t_R  g051(.A1(G426), .A2(G1), .B(new_n57_), .Y(new_n95_));
  OA21x2_ASAP7_75t_R  g052(.A1(G3), .A2(new_n95_), .B(new_n94_), .Y(new_n96_));
  AOI21x1_ASAP7_75t_R g053(.A1(new_n70_), .A2(new_n77_), .B(new_n44_), .Y(new_n97_));
  AO21x1_ASAP7_75t_R  g054(.A1(G426), .A2(G32), .B(new_n45_), .Y(new_n98_));
  OR3x1_ASAP7_75t_R   g055(.A(new_n97_), .B(new_n45_), .C(G35), .Y(new_n99_));
  AO21x1_ASAP7_75t_R  g056(.A1(G426), .A2(G4), .B(new_n55_), .Y(new_n100_));
  OA21x2_ASAP7_75t_R  g057(.A1(G7), .A2(new_n100_), .B(new_n99_), .Y(new_n101_));
  AND3x1_ASAP7_75t_R  g058(.A(new_n91_), .B(new_n96_), .C(new_n101_), .Y(new_n102_));
  NAND2x1_ASAP7_75t_R g059(.A(new_n86_), .B(new_n102_), .Y(G427));
  AOI21x1_ASAP7_75t_R g060(.A1(G19), .A2(G427), .B(new_n93_), .Y(new_n104_));
  INVx1_ASAP7_75t_R   g061(.A(new_n104_), .Y(new_n105_));
  NAND2x1_ASAP7_75t_R g062(.A(new_n64_), .B(new_n104_), .Y(new_n106_));
  AOI21x1_ASAP7_75t_R g063(.A1(G23), .A2(G427), .B(new_n88_), .Y(new_n107_));
  INVx1_ASAP7_75t_R   g064(.A(new_n107_), .Y(new_n108_));
  NAND2x1_ASAP7_75t_R g065(.A(new_n63_), .B(new_n107_), .Y(new_n109_));
  AOI21x1_ASAP7_75t_R g066(.A1(G15), .A2(G427), .B(new_n90_), .Y(new_n110_));
  NAND2x1_ASAP7_75t_R g067(.A(new_n65_), .B(new_n110_), .Y(new_n111_));
  AND3x1_ASAP7_75t_R  g068(.A(new_n106_), .B(new_n109_), .C(new_n111_), .Y(new_n112_));
  AOI21x1_ASAP7_75t_R g069(.A1(new_n86_), .A2(new_n102_), .B(new_n60_), .Y(new_n113_));
  AO21x1_ASAP7_75t_R  g070(.A1(G427), .A2(G7), .B(new_n100_), .Y(new_n114_));
  OR3x1_ASAP7_75t_R   g071(.A(G9), .B(new_n113_), .C(new_n100_), .Y(new_n115_));
  AO21x1_ASAP7_75t_R  g072(.A1(G427), .A2(G3), .B(new_n95_), .Y(new_n116_));
  OA21x2_ASAP7_75t_R  g073(.A1(G5), .A2(new_n116_), .B(new_n115_), .Y(new_n117_));
  AOI21x1_ASAP7_75t_R g074(.A1(new_n86_), .A2(new_n102_), .B(new_n58_), .Y(new_n118_));
  NOR2x1_ASAP7_75t_R  g075(.A(new_n79_), .B(new_n118_), .Y(new_n119_));
  OR3x1_ASAP7_75t_R   g076(.A(G33), .B(new_n118_), .C(new_n79_), .Y(new_n120_));
  AO21x1_ASAP7_75t_R  g077(.A1(G427), .A2(G35), .B(new_n98_), .Y(new_n121_));
  OA21x2_ASAP7_75t_R  g078(.A1(G36), .A2(new_n121_), .B(new_n120_), .Y(new_n122_));
  AOI21x1_ASAP7_75t_R g079(.A1(new_n86_), .A2(new_n102_), .B(new_n59_), .Y(new_n123_));
  NOR2x1_ASAP7_75t_R  g080(.A(new_n84_), .B(new_n123_), .Y(new_n124_));
  OR3x1_ASAP7_75t_R   g081(.A(G13), .B(new_n123_), .C(new_n84_), .Y(new_n125_));
  NOR2x1_ASAP7_75t_R  g082(.A(new_n83_), .B(G427), .Y(new_n126_));
  NOR2x1_ASAP7_75t_R  g083(.A(G29), .B(new_n48_), .Y(new_n127_));
  OAI21x1_ASAP7_75t_R g084(.A1(new_n80_), .A2(new_n81_), .B(new_n127_), .Y(new_n128_));
  AO21x1_ASAP7_75t_R  g085(.A1(new_n83_), .A2(G427), .B(new_n128_), .Y(new_n129_));
  OA21x2_ASAP7_75t_R  g086(.A1(new_n126_), .A2(new_n129_), .B(new_n125_), .Y(new_n130_));
  AND3x1_ASAP7_75t_R  g087(.A(new_n117_), .B(new_n122_), .C(new_n130_), .Y(new_n131_));
  AND2x2_ASAP7_75t_R  g088(.A(new_n112_), .B(new_n131_), .Y(new_n132_));
  INVx1_ASAP7_75t_R   g089(.A(new_n132_), .Y(G428));
  AOI21x1_ASAP7_75t_R g090(.A1(G5), .A2(G428), .B(new_n116_), .Y(new_n134_));
  AOI21x1_ASAP7_75t_R g091(.A1(new_n112_), .A2(new_n131_), .B(new_n64_), .Y(new_n135_));
  OAI21x1_ASAP7_75t_R g092(.A1(new_n65_), .A2(new_n132_), .B(new_n110_), .Y(new_n136_));
  OA21x2_ASAP7_75t_R  g093(.A1(new_n105_), .A2(new_n135_), .B(new_n136_), .Y(new_n137_));
  INVx1_ASAP7_75t_R   g094(.A(new_n137_), .Y(new_n138_));
  OA21x2_ASAP7_75t_R  g095(.A1(new_n132_), .A2(new_n66_), .B(new_n124_), .Y(new_n139_));
  OAI21x1_ASAP7_75t_R g096(.A1(new_n66_), .A2(new_n132_), .B(new_n124_), .Y(new_n140_));
  AOI21x1_ASAP7_75t_R g097(.A1(new_n112_), .A2(new_n131_), .B(new_n67_), .Y(new_n141_));
  AO21x1_ASAP7_75t_R  g098(.A1(G428), .A2(G9), .B(new_n114_), .Y(new_n142_));
  OA21x2_ASAP7_75t_R  g099(.A1(new_n114_), .A2(new_n141_), .B(new_n140_), .Y(new_n143_));
  AND2x2_ASAP7_75t_R  g100(.A(new_n137_), .B(new_n143_), .Y(new_n144_));
  INVx1_ASAP7_75t_R   g101(.A(new_n144_), .Y(G430));
  AOI21x1_ASAP7_75t_R g102(.A1(new_n112_), .A2(new_n131_), .B(new_n61_), .Y(new_n146_));
  AO21x1_ASAP7_75t_R  g103(.A1(G426), .A2(G24), .B(new_n48_), .Y(new_n147_));
  AO21x1_ASAP7_75t_R  g104(.A1(G427), .A2(G27), .B(new_n147_), .Y(new_n148_));
  AO21x1_ASAP7_75t_R  g105(.A1(G428), .A2(G29), .B(new_n148_), .Y(new_n149_));
  OA21x2_ASAP7_75t_R  g106(.A1(new_n121_), .A2(new_n146_), .B(new_n149_), .Y(new_n150_));
  AOI21x1_ASAP7_75t_R g107(.A1(G25), .A2(G428), .B(new_n108_), .Y(new_n151_));
  AO21x1_ASAP7_75t_R  g108(.A1(new_n112_), .A2(new_n131_), .B(new_n62_), .Y(new_n152_));
  AOI21x1_ASAP7_75t_R g109(.A1(new_n119_), .A2(new_n152_), .B(new_n151_), .Y(new_n153_));
  AND2x2_ASAP7_75t_R  g110(.A(new_n150_), .B(new_n153_), .Y(new_n154_));
  AOI21x1_ASAP7_75t_R g111(.A1(new_n144_), .A2(new_n154_), .B(new_n134_), .Y(G429));
  NAND2x1_ASAP7_75t_R g112(.A(new_n136_), .B(new_n140_), .Y(new_n156_));
  OAI21x1_ASAP7_75t_R g113(.A1(new_n105_), .A2(new_n135_), .B(new_n151_), .Y(new_n157_));
  OA21x2_ASAP7_75t_R  g114(.A1(new_n156_), .A2(new_n157_), .B(new_n143_), .Y(new_n158_));
  OAI21x1_ASAP7_75t_R g115(.A1(new_n138_), .A2(new_n149_), .B(new_n158_), .Y(G431));
  NAND3x1_ASAP7_75t_R g116(.A(new_n149_), .B(new_n152_), .C(new_n119_), .Y(new_n160_));
  OA21x2_ASAP7_75t_R  g117(.A1(new_n139_), .A2(new_n136_), .B(new_n142_), .Y(new_n161_));
  OA21x2_ASAP7_75t_R  g118(.A1(new_n156_), .A2(new_n157_), .B(new_n161_), .Y(new_n162_));
  OAI21x1_ASAP7_75t_R g119(.A1(new_n156_), .A2(new_n160_), .B(new_n162_), .Y(G432));
endmodule


