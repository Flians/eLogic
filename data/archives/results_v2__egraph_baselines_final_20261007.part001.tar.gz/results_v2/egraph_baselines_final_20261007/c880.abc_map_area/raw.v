// Benchmark "/home/flynn/workplace/MIGBalance/tools/mockturtle/experiments/benchmarks/c880" written by ABC on Wed Oct  7 15:30:31 2026

module \/home/flynn/workplace/MIGBalance/tools/mockturtle/experiments/benchmarks/c880  ( 
    G8, G16, G6, G17, G7, G18, G19, G4, G3, G2, G1, G5, G11, G23, G20, G21,
    G9, G10, G12, G15, G22, G32, G24, G25, G26, G27, G28, G29, G30, G31,
    G33, G41, G42, G43, G44, G45, G46, G47, G48, G49, G13, G14, G55, G59,
    G54, G60, G39, G40, G52, G53, G50, G51, G58, G35, G37, G36, G56, G57,
    G34, G38,
    G855, G856, G857, G858, G859, G860, G861, G862, G863, G864, G865, G866,
    G867, G868, G869, G870, G871, G872, G873, G874, G875, G876, G877, G878,
    G879, G880  );
  input  G8, G16, G6, G17, G7, G18, G19, G4, G3, G2, G1, G5, G11, G23,
    G20, G21, G9, G10, G12, G15, G22, G32, G24, G25, G26, G27, G28, G29,
    G30, G31, G33, G41, G42, G43, G44, G45, G46, G47, G48, G49, G13, G14,
    G55, G59, G54, G60, G39, G40, G52, G53, G50, G51, G58, G35, G37, G36,
    G56, G57, G34, G38;
  output G855, G856, G857, G858, G859, G860, G861, G862, G863, G864, G865,
    G866, G867, G868, G869, G870, G871, G872, G873, G874, G875, G876, G877,
    G878, G879, G880;
  wire new_n87_, new_n88_, new_n89_, new_n92_, new_n95_, new_n96_, new_n98_,
    new_n105_, new_n107_, new_n109_, new_n112_, new_n113_, new_n114_,
    new_n115_, new_n116_, new_n117_, new_n118_, new_n119_, new_n120_,
    new_n122_, new_n123_, new_n124_, new_n125_, new_n126_, new_n127_,
    new_n128_, new_n129_, new_n131_, new_n132_, new_n133_, new_n134_,
    new_n135_, new_n136_, new_n137_, new_n138_, new_n139_, new_n140_,
    new_n141_, new_n142_, new_n143_, new_n144_, new_n145_, new_n146_,
    new_n147_, new_n148_, new_n149_, new_n150_, new_n151_, new_n152_,
    new_n153_, new_n154_, new_n155_, new_n156_, new_n157_, new_n158_,
    new_n159_, new_n160_, new_n161_, new_n162_, new_n163_, new_n164_,
    new_n165_, new_n166_, new_n167_, new_n168_, new_n169_, new_n170_,
    new_n172_, new_n173_, new_n174_, new_n175_, new_n176_, new_n177_,
    new_n178_, new_n179_, new_n180_, new_n181_, new_n182_, new_n183_,
    new_n184_, new_n185_, new_n186_, new_n187_, new_n188_, new_n189_,
    new_n190_, new_n191_, new_n192_, new_n193_, new_n194_, new_n195_,
    new_n196_, new_n197_, new_n198_, new_n199_, new_n200_, new_n201_,
    new_n203_, new_n204_, new_n205_, new_n206_, new_n207_, new_n208_,
    new_n209_, new_n210_, new_n211_, new_n212_, new_n213_, new_n214_,
    new_n215_, new_n216_, new_n217_, new_n218_, new_n220_, new_n221_,
    new_n222_, new_n223_, new_n224_, new_n225_, new_n226_, new_n227_,
    new_n228_, new_n229_, new_n230_, new_n232_, new_n233_, new_n234_,
    new_n235_, new_n236_, new_n237_, new_n238_, new_n239_, new_n240_,
    new_n241_, new_n242_, new_n243_, new_n244_, new_n245_, new_n246_,
    new_n247_, new_n248_, new_n249_, new_n250_, new_n251_, new_n252_,
    new_n253_, new_n254_, new_n255_, new_n256_, new_n257_, new_n258_,
    new_n259_, new_n260_, new_n261_, new_n262_, new_n263_, new_n264_,
    new_n265_, new_n266_, new_n267_, new_n268_, new_n269_, new_n271_,
    new_n272_, new_n273_, new_n274_, new_n275_, new_n276_, new_n277_,
    new_n278_, new_n279_, new_n280_, new_n281_, new_n283_, new_n284_,
    new_n285_, new_n286_, new_n287_, new_n288_, new_n289_, new_n290_,
    new_n291_, new_n293_, new_n294_, new_n295_, new_n296_, new_n297_,
    new_n298_, new_n299_, new_n300_, new_n301_, new_n302_, new_n303_,
    new_n304_, new_n305_, new_n307_, new_n308_, new_n309_, new_n310_,
    new_n311_, new_n312_, new_n313_, new_n314_, new_n315_;
  INVx1_ASAP7_75t_R   g000(.A(G8), .Y(new_n87_));
  INVx1_ASAP7_75t_R   g001(.A(G16), .Y(new_n88_));
  INVx1_ASAP7_75t_R   g002(.A(G6), .Y(new_n89_));
  OR3x1_ASAP7_75t_R   g003(.A(new_n87_), .B(new_n88_), .C(new_n89_), .Y(G855));
  NAND3x1_ASAP7_75t_R g004(.A(G6), .B(G7), .C(G17), .Y(G856));
  AND3x1_ASAP7_75t_R  g005(.A(G8), .B(G6), .C(G7), .Y(new_n92_));
  INVx1_ASAP7_75t_R   g006(.A(new_n92_), .Y(G857));
  NAND2x1_ASAP7_75t_R g007(.A(G18), .B(G19), .Y(G858));
  AND2x2_ASAP7_75t_R  g008(.A(G4), .B(G3), .Y(new_n95_));
  AND2x2_ASAP7_75t_R  g009(.A(G2), .B(G1), .Y(new_n96_));
  NAND2x1_ASAP7_75t_R g010(.A(new_n95_), .B(new_n96_), .Y(G859));
  AND2x2_ASAP7_75t_R  g011(.A(G1), .B(G5), .Y(new_n98_));
  AND3x1_ASAP7_75t_R  g012(.A(G857), .B(new_n95_), .C(new_n98_), .Y(G860));
  AND3x1_ASAP7_75t_R  g013(.A(G16), .B(G17), .C(G11), .Y(G861));
  AND3x1_ASAP7_75t_R  g014(.A(G17), .B(G7), .C(G11), .Y(G862));
  AND3x1_ASAP7_75t_R  g015(.A(G8), .B(G7), .C(G11), .Y(G863));
  OAI21x1_ASAP7_75t_R g016(.A1(G20), .A2(G21), .B(G23), .Y(G864));
  AND3x1_ASAP7_75t_R  g017(.A(new_n92_), .B(new_n95_), .C(new_n98_), .Y(G865));
  AND3x1_ASAP7_75t_R  g018(.A(G1), .B(G5), .C(G9), .Y(new_n105_));
  INVx1_ASAP7_75t_R   g019(.A(new_n105_), .Y(G866));
  AND3x1_ASAP7_75t_R  g020(.A(new_n96_), .B(G3), .C(G10), .Y(new_n107_));
  NAND3x1_ASAP7_75t_R g021(.A(new_n107_), .B(G12), .C(G6), .Y(G867));
  AND3x1_ASAP7_75t_R  g022(.A(G11), .B(G12), .C(G15), .Y(new_n109_));
  NAND2x1_ASAP7_75t_R g023(.A(new_n109_), .B(new_n107_), .Y(G868));
  OAI21x1_ASAP7_75t_R g024(.A1(G20), .A2(G21), .B(G22), .Y(G869));
  INVx1_ASAP7_75t_R   g025(.A(G32), .Y(new_n112_));
  XOR2x2_ASAP7_75t_R  g026(.A(G24), .B(G25), .Y(new_n113_));
  XOR2x2_ASAP7_75t_R  g027(.A(G26), .B(G27), .Y(new_n114_));
  XOR2x2_ASAP7_75t_R  g028(.A(new_n113_), .B(new_n114_), .Y(new_n115_));
  XOR2x2_ASAP7_75t_R  g029(.A(new_n115_), .B(new_n112_), .Y(new_n116_));
  XOR2x2_ASAP7_75t_R  g030(.A(G28), .B(G29), .Y(new_n117_));
  XOR2x2_ASAP7_75t_R  g031(.A(G30), .B(G31), .Y(new_n118_));
  XOR2x2_ASAP7_75t_R  g032(.A(new_n117_), .B(new_n118_), .Y(new_n119_));
  XOR2x2_ASAP7_75t_R  g033(.A(new_n119_), .B(G33), .Y(new_n120_));
  XOR2x2_ASAP7_75t_R  g034(.A(new_n116_), .B(new_n120_), .Y(G870));
  XOR2x2_ASAP7_75t_R  g035(.A(G41), .B(G42), .Y(new_n122_));
  XOR2x2_ASAP7_75t_R  g036(.A(G43), .B(G44), .Y(new_n123_));
  XOR2x2_ASAP7_75t_R  g037(.A(new_n122_), .B(new_n123_), .Y(new_n124_));
  XOR2x2_ASAP7_75t_R  g038(.A(new_n124_), .B(new_n112_), .Y(new_n125_));
  XOR2x2_ASAP7_75t_R  g039(.A(G45), .B(G46), .Y(new_n126_));
  XOR2x2_ASAP7_75t_R  g040(.A(G47), .B(G48), .Y(new_n127_));
  XOR2x2_ASAP7_75t_R  g041(.A(new_n126_), .B(new_n127_), .Y(new_n128_));
  XOR2x2_ASAP7_75t_R  g042(.A(new_n128_), .B(G49), .Y(new_n129_));
  XOR2x2_ASAP7_75t_R  g043(.A(new_n125_), .B(new_n129_), .Y(G871));
  AND2x2_ASAP7_75t_R  g044(.A(G12), .B(G13), .Y(new_n131_));
  AND3x1_ASAP7_75t_R  g045(.A(new_n131_), .B(G8), .C(G11), .Y(new_n132_));
  AND3x1_ASAP7_75t_R  g046(.A(new_n107_), .B(new_n132_), .C(G14), .Y(new_n133_));
  NAND2x1_ASAP7_75t_R g047(.A(G48), .B(new_n133_), .Y(new_n134_));
  NAND2x1_ASAP7_75t_R g048(.A(G55), .B(G59), .Y(new_n135_));
  INVx1_ASAP7_75t_R   g049(.A(G60), .Y(new_n136_));
  AND3x1_ASAP7_75t_R  g050(.A(G16), .B(G6), .C(G17), .Y(new_n137_));
  AND3x1_ASAP7_75t_R  g051(.A(new_n105_), .B(new_n137_), .C(G10), .Y(new_n138_));
  AND2x2_ASAP7_75t_R  g052(.A(new_n138_), .B(new_n136_), .Y(new_n139_));
  INVx1_ASAP7_75t_R   g053(.A(new_n139_), .Y(new_n140_));
  INVx1_ASAP7_75t_R   g054(.A(G1), .Y(new_n141_));
  AO21x1_ASAP7_75t_R  g055(.A1(G11), .A2(G40), .B(G866), .Y(new_n142_));
  INVx1_ASAP7_75t_R   g056(.A(new_n142_), .Y(new_n143_));
  AO21x1_ASAP7_75t_R  g057(.A1(new_n143_), .A2(G4), .B(new_n141_), .Y(new_n144_));
  NAND2x1_ASAP7_75t_R g058(.A(G39), .B(new_n144_), .Y(new_n145_));
  NAND2x1_ASAP7_75t_R g059(.A(G40), .B(new_n105_), .Y(new_n146_));
  INVx1_ASAP7_75t_R   g060(.A(G11), .Y(new_n147_));
  NOR2x1_ASAP7_75t_R  g061(.A(G8), .B(G4), .Y(new_n148_));
  AND2x2_ASAP7_75t_R  g062(.A(G8), .B(G4), .Y(new_n149_));
  OR3x1_ASAP7_75t_R   g063(.A(new_n148_), .B(new_n147_), .C(new_n149_), .Y(new_n150_));
  AND3x1_ASAP7_75t_R  g064(.A(new_n96_), .B(G4), .C(G9), .Y(new_n151_));
  OR3x1_ASAP7_75t_R   g065(.A(new_n87_), .B(new_n88_), .C(new_n147_), .Y(new_n152_));
  NAND2x1_ASAP7_75t_R g066(.A(new_n152_), .B(new_n151_), .Y(new_n153_));
  OA21x2_ASAP7_75t_R  g067(.A1(new_n146_), .A2(new_n150_), .B(new_n153_), .Y(new_n154_));
  INVx1_ASAP7_75t_R   g068(.A(new_n154_), .Y(new_n155_));
  NAND2x1_ASAP7_75t_R g069(.A(G31), .B(new_n155_), .Y(new_n156_));
  AND3x1_ASAP7_75t_R  g070(.A(new_n156_), .B(new_n140_), .C(new_n145_), .Y(new_n157_));
  INVx1_ASAP7_75t_R   g071(.A(new_n157_), .Y(new_n158_));
  NAND2x1_ASAP7_75t_R g072(.A(G54), .B(new_n158_), .Y(new_n159_));
  AND3x1_ASAP7_75t_R  g073(.A(new_n159_), .B(new_n134_), .C(new_n135_), .Y(new_n160_));
  INVx1_ASAP7_75t_R   g074(.A(G53), .Y(new_n161_));
  AND2x2_ASAP7_75t_R  g075(.A(new_n158_), .B(G48), .Y(new_n162_));
  INVx1_ASAP7_75t_R   g076(.A(new_n162_), .Y(new_n163_));
  OR2x4_ASAP7_75t_R   g077(.A(G48), .B(new_n158_), .Y(new_n164_));
  AND2x2_ASAP7_75t_R  g078(.A(new_n163_), .B(new_n164_), .Y(new_n165_));
  NAND2x1_ASAP7_75t_R g079(.A(G52), .B(new_n165_), .Y(new_n166_));
  OA21x2_ASAP7_75t_R  g080(.A1(new_n161_), .A2(new_n163_), .B(new_n166_), .Y(new_n167_));
  AND2x2_ASAP7_75t_R  g081(.A(G30), .B(G50), .Y(new_n168_));
  XOR2x2_ASAP7_75t_R  g082(.A(new_n165_), .B(G58), .Y(new_n169_));
  AOI21x1_ASAP7_75t_R g083(.A1(G51), .A2(new_n169_), .B(new_n168_), .Y(new_n170_));
  AND3x1_ASAP7_75t_R  g084(.A(new_n170_), .B(new_n160_), .C(new_n167_), .Y(G872));
  INVx1_ASAP7_75t_R   g085(.A(G54), .Y(new_n172_));
  AND2x2_ASAP7_75t_R  g086(.A(new_n144_), .B(G35), .Y(new_n173_));
  AO21x1_ASAP7_75t_R  g087(.A1(G28), .A2(new_n155_), .B(new_n173_), .Y(new_n174_));
  NOR2x1_ASAP7_75t_R  g088(.A(new_n139_), .B(new_n174_), .Y(new_n175_));
  NAND2x1_ASAP7_75t_R g089(.A(G45), .B(new_n133_), .Y(new_n176_));
  OA21x2_ASAP7_75t_R  g090(.A1(new_n175_), .A2(new_n172_), .B(new_n176_), .Y(new_n177_));
  OAI21x1_ASAP7_75t_R g091(.A1(new_n139_), .A2(new_n174_), .B(G45), .Y(new_n178_));
  INVx1_ASAP7_75t_R   g092(.A(G45), .Y(new_n179_));
  XOR2x2_ASAP7_75t_R  g093(.A(new_n175_), .B(new_n179_), .Y(new_n180_));
  NAND2x1_ASAP7_75t_R g094(.A(G52), .B(new_n180_), .Y(new_n181_));
  OA21x2_ASAP7_75t_R  g095(.A1(new_n161_), .A2(new_n178_), .B(new_n181_), .Y(new_n182_));
  AND2x2_ASAP7_75t_R  g096(.A(G27), .B(G50), .Y(new_n183_));
  NAND2x1_ASAP7_75t_R g097(.A(G58), .B(new_n164_), .Y(new_n184_));
  INVx1_ASAP7_75t_R   g098(.A(G47), .Y(new_n185_));
  AND2x2_ASAP7_75t_R  g099(.A(new_n144_), .B(G37), .Y(new_n186_));
  AO21x1_ASAP7_75t_R  g100(.A1(G30), .A2(new_n155_), .B(new_n186_), .Y(new_n187_));
  NOR2x1_ASAP7_75t_R  g101(.A(new_n139_), .B(new_n187_), .Y(new_n188_));
  AND2x2_ASAP7_75t_R  g102(.A(new_n144_), .B(G36), .Y(new_n189_));
  AO21x1_ASAP7_75t_R  g103(.A1(G29), .A2(new_n155_), .B(new_n189_), .Y(new_n190_));
  NOR2x1_ASAP7_75t_R  g104(.A(new_n139_), .B(new_n190_), .Y(new_n191_));
  INVx1_ASAP7_75t_R   g105(.A(new_n191_), .Y(new_n192_));
  NOR2x1_ASAP7_75t_R  g106(.A(G46), .B(new_n192_), .Y(new_n193_));
  AO21x1_ASAP7_75t_R  g107(.A1(new_n185_), .A2(new_n188_), .B(new_n193_), .Y(new_n194_));
  AO21x1_ASAP7_75t_R  g108(.A1(new_n184_), .A2(new_n163_), .B(new_n194_), .Y(new_n195_));
  OR3x1_ASAP7_75t_R   g109(.A(new_n193_), .B(new_n185_), .C(new_n188_), .Y(new_n196_));
  AND2x2_ASAP7_75t_R  g110(.A(new_n192_), .B(G46), .Y(new_n197_));
  INVx1_ASAP7_75t_R   g111(.A(new_n197_), .Y(new_n198_));
  AND3x1_ASAP7_75t_R  g112(.A(new_n195_), .B(new_n196_), .C(new_n198_), .Y(new_n199_));
  XNOR2x2_ASAP7_75t_R g113(.A(new_n180_), .B(new_n199_), .Y(new_n200_));
  AOI21x1_ASAP7_75t_R g114(.A1(G51), .A2(new_n200_), .B(new_n183_), .Y(new_n201_));
  AND3x1_ASAP7_75t_R  g115(.A(new_n201_), .B(new_n177_), .C(new_n182_), .Y(G873));
  NAND2x1_ASAP7_75t_R g116(.A(G46), .B(new_n133_), .Y(new_n203_));
  NAND2x1_ASAP7_75t_R g117(.A(G55), .B(G56), .Y(new_n204_));
  NAND2x1_ASAP7_75t_R g118(.A(G54), .B(new_n192_), .Y(new_n205_));
  AND3x1_ASAP7_75t_R  g119(.A(new_n205_), .B(new_n203_), .C(new_n204_), .Y(new_n206_));
  NOR2x1_ASAP7_75t_R  g120(.A(new_n197_), .B(new_n193_), .Y(new_n207_));
  NAND2x1_ASAP7_75t_R g121(.A(G52), .B(new_n207_), .Y(new_n208_));
  OA21x2_ASAP7_75t_R  g122(.A1(new_n161_), .A2(new_n198_), .B(new_n208_), .Y(new_n209_));
  AND2x2_ASAP7_75t_R  g123(.A(G28), .B(G50), .Y(new_n210_));
  AND2x2_ASAP7_75t_R  g124(.A(new_n188_), .B(new_n185_), .Y(new_n211_));
  INVx1_ASAP7_75t_R   g125(.A(new_n211_), .Y(new_n212_));
  AND2x2_ASAP7_75t_R  g126(.A(new_n212_), .B(new_n164_), .Y(new_n213_));
  NOR2x1_ASAP7_75t_R  g127(.A(new_n185_), .B(new_n188_), .Y(new_n214_));
  AO21x1_ASAP7_75t_R  g128(.A1(new_n212_), .A2(new_n162_), .B(new_n214_), .Y(new_n215_));
  AO21x1_ASAP7_75t_R  g129(.A1(new_n213_), .A2(G58), .B(new_n215_), .Y(new_n216_));
  XOR2x2_ASAP7_75t_R  g130(.A(new_n216_), .B(new_n207_), .Y(new_n217_));
  AOI21x1_ASAP7_75t_R g131(.A1(G51), .A2(new_n217_), .B(new_n210_), .Y(new_n218_));
  AND3x1_ASAP7_75t_R  g132(.A(new_n218_), .B(new_n206_), .C(new_n209_), .Y(G874));
  NAND2x1_ASAP7_75t_R g133(.A(G47), .B(new_n133_), .Y(new_n220_));
  NAND2x1_ASAP7_75t_R g134(.A(G55), .B(G57), .Y(new_n221_));
  OAI21x1_ASAP7_75t_R g135(.A1(new_n139_), .A2(new_n187_), .B(G54), .Y(new_n222_));
  AND3x1_ASAP7_75t_R  g136(.A(new_n222_), .B(new_n220_), .C(new_n221_), .Y(new_n223_));
  NOR2x1_ASAP7_75t_R  g137(.A(new_n211_), .B(new_n214_), .Y(new_n224_));
  AND2x2_ASAP7_75t_R  g138(.A(new_n214_), .B(G53), .Y(new_n225_));
  AOI21x1_ASAP7_75t_R g139(.A1(G52), .A2(new_n224_), .B(new_n225_), .Y(new_n226_));
  AND2x2_ASAP7_75t_R  g140(.A(G29), .B(G50), .Y(new_n227_));
  AO21x1_ASAP7_75t_R  g141(.A1(new_n164_), .A2(G58), .B(new_n162_), .Y(new_n228_));
  XOR2x2_ASAP7_75t_R  g142(.A(new_n228_), .B(new_n224_), .Y(new_n229_));
  AOI21x1_ASAP7_75t_R g143(.A1(G51), .A2(new_n229_), .B(new_n227_), .Y(new_n230_));
  AND3x1_ASAP7_75t_R  g144(.A(new_n230_), .B(new_n223_), .C(new_n226_), .Y(G875));
  INVx1_ASAP7_75t_R   g145(.A(G41), .Y(new_n232_));
  AND2x2_ASAP7_75t_R  g146(.A(G2), .B(G34), .Y(new_n233_));
  AOI21x1_ASAP7_75t_R g147(.A1(G24), .A2(new_n155_), .B(new_n233_), .Y(new_n234_));
  INVx1_ASAP7_75t_R   g148(.A(G35), .Y(new_n235_));
  NAND2x1_ASAP7_75t_R g149(.A(G10), .B(new_n143_), .Y(new_n236_));
  AND3x1_ASAP7_75t_R  g150(.A(new_n105_), .B(new_n137_), .C(G4), .Y(new_n237_));
  NAND2x1_ASAP7_75t_R g151(.A(new_n136_), .B(new_n237_), .Y(new_n238_));
  OA21x2_ASAP7_75t_R  g152(.A1(new_n236_), .A2(new_n235_), .B(new_n238_), .Y(new_n239_));
  AND2x2_ASAP7_75t_R  g153(.A(new_n234_), .B(new_n239_), .Y(new_n240_));
  AO21x1_ASAP7_75t_R  g154(.A1(new_n179_), .A2(new_n175_), .B(new_n199_), .Y(new_n241_));
  INVx1_ASAP7_75t_R   g155(.A(G44), .Y(new_n242_));
  AND2x2_ASAP7_75t_R  g156(.A(G34), .B(G38), .Y(new_n243_));
  AOI21x1_ASAP7_75t_R g157(.A1(G27), .A2(new_n155_), .B(new_n243_), .Y(new_n244_));
  INVx1_ASAP7_75t_R   g158(.A(G39), .Y(new_n245_));
  OA21x2_ASAP7_75t_R  g159(.A1(new_n236_), .A2(new_n245_), .B(new_n238_), .Y(new_n246_));
  AND3x1_ASAP7_75t_R  g160(.A(new_n244_), .B(new_n242_), .C(new_n246_), .Y(new_n247_));
  AO21x1_ASAP7_75t_R  g161(.A1(new_n241_), .A2(new_n178_), .B(new_n247_), .Y(new_n248_));
  INVx1_ASAP7_75t_R   g162(.A(G42), .Y(new_n249_));
  INVx1_ASAP7_75t_R   g163(.A(G43), .Y(new_n250_));
  AND2x2_ASAP7_75t_R  g164(.A(G4), .B(G34), .Y(new_n251_));
  AOI21x1_ASAP7_75t_R g165(.A1(G26), .A2(new_n155_), .B(new_n251_), .Y(new_n252_));
  INVx1_ASAP7_75t_R   g166(.A(G37), .Y(new_n253_));
  OA21x2_ASAP7_75t_R  g167(.A1(new_n236_), .A2(new_n253_), .B(new_n238_), .Y(new_n254_));
  AND3x1_ASAP7_75t_R  g168(.A(new_n252_), .B(new_n250_), .C(new_n254_), .Y(new_n255_));
  AND2x2_ASAP7_75t_R  g169(.A(G9), .B(G34), .Y(new_n256_));
  AOI21x1_ASAP7_75t_R g170(.A1(G25), .A2(new_n155_), .B(new_n256_), .Y(new_n257_));
  INVx1_ASAP7_75t_R   g171(.A(G36), .Y(new_n258_));
  OA21x2_ASAP7_75t_R  g172(.A1(new_n236_), .A2(new_n258_), .B(new_n238_), .Y(new_n259_));
  AND2x2_ASAP7_75t_R  g173(.A(new_n257_), .B(new_n259_), .Y(new_n260_));
  AO21x1_ASAP7_75t_R  g174(.A1(new_n249_), .A2(new_n260_), .B(new_n255_), .Y(new_n261_));
  AO21x1_ASAP7_75t_R  g175(.A1(new_n244_), .A2(new_n246_), .B(new_n242_), .Y(new_n262_));
  AO21x1_ASAP7_75t_R  g176(.A1(new_n248_), .A2(new_n262_), .B(new_n261_), .Y(new_n263_));
  AND2x2_ASAP7_75t_R  g177(.A(new_n252_), .B(new_n254_), .Y(new_n264_));
  AND3x1_ASAP7_75t_R  g178(.A(new_n257_), .B(new_n249_), .C(new_n259_), .Y(new_n265_));
  OR3x1_ASAP7_75t_R   g179(.A(new_n265_), .B(new_n250_), .C(new_n264_), .Y(new_n266_));
  NOR2x1_ASAP7_75t_R  g180(.A(new_n249_), .B(new_n260_), .Y(new_n267_));
  INVx1_ASAP7_75t_R   g181(.A(new_n267_), .Y(new_n268_));
  AND3x1_ASAP7_75t_R  g182(.A(new_n263_), .B(new_n266_), .C(new_n268_), .Y(new_n269_));
  MAJx2_ASAP7_75t_R   g183(.A(new_n269_), .B(new_n232_), .C(new_n240_), .Y(G876));
  INVx1_ASAP7_75t_R   g184(.A(new_n133_), .Y(new_n271_));
  AO21x1_ASAP7_75t_R  g185(.A1(new_n244_), .A2(new_n246_), .B(new_n172_), .Y(new_n272_));
  OA21x2_ASAP7_75t_R  g186(.A1(new_n242_), .A2(new_n271_), .B(new_n272_), .Y(new_n273_));
  INVx1_ASAP7_75t_R   g187(.A(new_n247_), .Y(new_n274_));
  AND2x2_ASAP7_75t_R  g188(.A(new_n274_), .B(new_n262_), .Y(new_n275_));
  NAND2x1_ASAP7_75t_R g189(.A(G52), .B(new_n275_), .Y(new_n276_));
  OA21x2_ASAP7_75t_R  g190(.A1(new_n161_), .A2(new_n262_), .B(new_n276_), .Y(new_n277_));
  AND2x2_ASAP7_75t_R  g191(.A(G26), .B(G50), .Y(new_n278_));
  AND2x2_ASAP7_75t_R  g192(.A(new_n241_), .B(new_n178_), .Y(new_n279_));
  XNOR2x2_ASAP7_75t_R g193(.A(new_n275_), .B(new_n279_), .Y(new_n280_));
  AOI21x1_ASAP7_75t_R g194(.A1(G51), .A2(new_n280_), .B(new_n278_), .Y(new_n281_));
  AND3x1_ASAP7_75t_R  g195(.A(new_n281_), .B(new_n273_), .C(new_n277_), .Y(G877));
  AO21x1_ASAP7_75t_R  g196(.A1(new_n234_), .A2(new_n239_), .B(new_n172_), .Y(new_n283_));
  OA21x2_ASAP7_75t_R  g197(.A1(new_n232_), .A2(new_n271_), .B(new_n283_), .Y(new_n284_));
  AO21x1_ASAP7_75t_R  g198(.A1(new_n234_), .A2(new_n239_), .B(new_n232_), .Y(new_n285_));
  XOR2x2_ASAP7_75t_R  g199(.A(new_n240_), .B(new_n232_), .Y(new_n286_));
  NAND2x1_ASAP7_75t_R g200(.A(G52), .B(new_n286_), .Y(new_n287_));
  OA21x2_ASAP7_75t_R  g201(.A1(new_n161_), .A2(new_n285_), .B(new_n287_), .Y(new_n288_));
  AND2x2_ASAP7_75t_R  g202(.A(G60), .B(G50), .Y(new_n289_));
  XNOR2x2_ASAP7_75t_R g203(.A(new_n286_), .B(new_n269_), .Y(new_n290_));
  AOI21x1_ASAP7_75t_R g204(.A1(G51), .A2(new_n290_), .B(new_n289_), .Y(new_n291_));
  AND3x1_ASAP7_75t_R  g205(.A(new_n291_), .B(new_n284_), .C(new_n288_), .Y(G878));
  AO21x1_ASAP7_75t_R  g206(.A1(new_n257_), .A2(new_n259_), .B(new_n172_), .Y(new_n293_));
  OA21x2_ASAP7_75t_R  g207(.A1(new_n249_), .A2(new_n271_), .B(new_n293_), .Y(new_n294_));
  NOR2x1_ASAP7_75t_R  g208(.A(new_n265_), .B(new_n267_), .Y(new_n295_));
  NAND2x1_ASAP7_75t_R g209(.A(G52), .B(new_n295_), .Y(new_n296_));
  OA21x2_ASAP7_75t_R  g210(.A1(new_n161_), .A2(new_n268_), .B(new_n296_), .Y(new_n297_));
  AND2x2_ASAP7_75t_R  g211(.A(G24), .B(G50), .Y(new_n298_));
  NOR2x1_ASAP7_75t_R  g212(.A(new_n250_), .B(new_n264_), .Y(new_n299_));
  INVx1_ASAP7_75t_R   g213(.A(new_n299_), .Y(new_n300_));
  OR3x1_ASAP7_75t_R   g214(.A(new_n279_), .B(new_n247_), .C(new_n255_), .Y(new_n301_));
  AO21x1_ASAP7_75t_R  g215(.A1(new_n264_), .A2(new_n250_), .B(new_n262_), .Y(new_n302_));
  AND3x1_ASAP7_75t_R  g216(.A(new_n301_), .B(new_n300_), .C(new_n302_), .Y(new_n303_));
  XNOR2x2_ASAP7_75t_R g217(.A(new_n295_), .B(new_n303_), .Y(new_n304_));
  AOI21x1_ASAP7_75t_R g218(.A1(G51), .A2(new_n304_), .B(new_n298_), .Y(new_n305_));
  AND3x1_ASAP7_75t_R  g219(.A(new_n305_), .B(new_n294_), .C(new_n297_), .Y(G879));
  AO21x1_ASAP7_75t_R  g220(.A1(new_n252_), .A2(new_n254_), .B(new_n172_), .Y(new_n307_));
  OA21x2_ASAP7_75t_R  g221(.A1(new_n250_), .A2(new_n271_), .B(new_n307_), .Y(new_n308_));
  NOR2x1_ASAP7_75t_R  g222(.A(new_n255_), .B(new_n299_), .Y(new_n309_));
  NAND2x1_ASAP7_75t_R g223(.A(G52), .B(new_n309_), .Y(new_n310_));
  OA21x2_ASAP7_75t_R  g224(.A1(new_n161_), .A2(new_n300_), .B(new_n310_), .Y(new_n311_));
  AND2x2_ASAP7_75t_R  g225(.A(G25), .B(G50), .Y(new_n312_));
  NAND2x1_ASAP7_75t_R g226(.A(new_n262_), .B(new_n248_), .Y(new_n313_));
  XOR2x2_ASAP7_75t_R  g227(.A(new_n313_), .B(new_n309_), .Y(new_n314_));
  AOI21x1_ASAP7_75t_R g228(.A1(G51), .A2(new_n314_), .B(new_n312_), .Y(new_n315_));
  AND3x1_ASAP7_75t_R  g229(.A(new_n315_), .B(new_n308_), .C(new_n311_), .Y(G880));
endmodule


