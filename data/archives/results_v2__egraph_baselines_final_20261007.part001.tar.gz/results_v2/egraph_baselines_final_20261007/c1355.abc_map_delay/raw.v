// Benchmark "/home/flynn/workplace/MIGBalance/tools/mockturtle/experiments/benchmarks/c1355" written by ABC on Wed Oct  7 15:30:36 2026

module \/home/flynn/workplace/MIGBalance/tools/mockturtle/experiments/benchmarks/c1355  ( 
    G1, G5, G9, G13, G33, G41, G17, G18, G19, G20, G21, G22, G23, G24, G4,
    G8, G12, G16, G36, G29, G30, G31, G32, G3, G7, G11, G15, G35, G25, G26,
    G27, G28, G2, G6, G10, G14, G34, G40, G39, G38, G37,
    G1324, G1344, G1325, G1326, G1327, G1328, G1329, G1330, G1343, G1331,
    G1332, G1333, G1334, G1335, G1336, G1337, G1338, G1339, G1340, G1341,
    G1342, G1345, G1346, G1347, G1348, G1349, G1350, G1351, G1352, G1353,
    G1354, G1355  );
  input  G1, G5, G9, G13, G33, G41, G17, G18, G19, G20, G21, G22, G23,
    G24, G4, G8, G12, G16, G36, G29, G30, G31, G32, G3, G7, G11, G15, G35,
    G25, G26, G27, G28, G2, G6, G10, G14, G34, G40, G39, G38, G37;
  output G1324, G1344, G1325, G1326, G1327, G1328, G1329, G1330, G1343, G1331,
    G1332, G1333, G1334, G1335, G1336, G1337, G1338, G1339, G1340, G1341,
    G1342, G1345, G1346, G1347, G1348, G1349, G1350, G1351, G1352, G1353,
    G1354, G1355;
  wire new_n74_, new_n75_, new_n76_, new_n77_, new_n78_, new_n79_, new_n80_,
    new_n81_, new_n82_, new_n83_, new_n84_, new_n85_, new_n86_, new_n87_,
    new_n88_, new_n89_, new_n90_, new_n91_, new_n92_, new_n93_, new_n94_,
    new_n95_, new_n96_, new_n97_, new_n98_, new_n99_, new_n100_, new_n101_,
    new_n102_, new_n103_, new_n104_, new_n105_, new_n106_, new_n107_,
    new_n108_, new_n109_, new_n110_, new_n111_, new_n112_, new_n113_,
    new_n114_, new_n115_, new_n116_, new_n117_, new_n118_, new_n119_,
    new_n120_, new_n121_, new_n122_, new_n123_, new_n124_, new_n125_,
    new_n126_, new_n127_, new_n128_, new_n129_, new_n130_, new_n131_,
    new_n132_, new_n133_, new_n134_, new_n135_, new_n136_, new_n137_,
    new_n138_, new_n139_, new_n140_, new_n141_, new_n142_, new_n143_,
    new_n144_, new_n145_, new_n146_, new_n147_, new_n148_, new_n149_,
    new_n150_, new_n151_, new_n152_, new_n153_, new_n154_, new_n155_,
    new_n156_, new_n157_, new_n158_, new_n159_, new_n160_, new_n161_,
    new_n162_, new_n163_, new_n164_, new_n165_, new_n166_, new_n167_,
    new_n168_, new_n169_, new_n170_, new_n171_, new_n172_, new_n173_,
    new_n174_, new_n175_, new_n176_, new_n177_, new_n178_, new_n179_,
    new_n180_, new_n181_, new_n182_, new_n183_, new_n184_, new_n185_,
    new_n186_, new_n187_, new_n188_, new_n189_, new_n190_, new_n191_,
    new_n192_, new_n193_, new_n194_, new_n195_, new_n196_, new_n197_,
    new_n198_, new_n199_, new_n200_, new_n201_, new_n202_, new_n203_,
    new_n204_, new_n205_, new_n206_, new_n207_, new_n208_, new_n209_,
    new_n210_, new_n211_, new_n212_, new_n213_, new_n214_, new_n215_,
    new_n216_, new_n217_, new_n218_, new_n219_, new_n220_, new_n221_,
    new_n222_, new_n223_, new_n224_, new_n225_, new_n226_, new_n227_,
    new_n228_, new_n229_, new_n230_, new_n231_, new_n232_, new_n233_,
    new_n235_, new_n236_, new_n237_, new_n238_, new_n239_, new_n240_,
    new_n241_, new_n242_, new_n243_, new_n244_, new_n245_, new_n246_,
    new_n247_, new_n248_, new_n249_, new_n250_, new_n251_, new_n252_,
    new_n253_, new_n254_, new_n255_, new_n257_, new_n258_, new_n260_,
    new_n261_, new_n263_, new_n264_, new_n266_, new_n267_, new_n268_,
    new_n269_, new_n270_, new_n272_, new_n273_, new_n275_, new_n276_,
    new_n278_, new_n279_, new_n280_, new_n281_, new_n283_, new_n284_,
    new_n286_, new_n287_, new_n288_, new_n290_, new_n291_, new_n293_,
    new_n294_, new_n296_, new_n297_, new_n299_, new_n300_, new_n301_,
    new_n303_, new_n304_, new_n306_, new_n307_, new_n309_, new_n310_,
    new_n312_, new_n313_, new_n315_, new_n316_, new_n318_, new_n319_,
    new_n321_, new_n322_, new_n324_, new_n325_, new_n327_, new_n328_,
    new_n330_, new_n331_, new_n332_, new_n334_, new_n335_, new_n337_,
    new_n338_, new_n340_, new_n341_, new_n343_, new_n344_, new_n345_,
    new_n347_, new_n348_, new_n350_, new_n351_, new_n353_, new_n354_;
  INVx1_ASAP7_75t_R   g000(.A(G1), .Y(new_n74_));
  XNOR2x2_ASAP7_75t_R g001(.A(G1), .B(G5), .Y(new_n75_));
  XOR2x2_ASAP7_75t_R  g002(.A(G9), .B(G13), .Y(new_n76_));
  XOR2x2_ASAP7_75t_R  g003(.A(new_n75_), .B(new_n76_), .Y(new_n77_));
  INVx1_ASAP7_75t_R   g004(.A(new_n77_), .Y(new_n78_));
  AND2x2_ASAP7_75t_R  g005(.A(G33), .B(G41), .Y(new_n79_));
  XNOR2x2_ASAP7_75t_R g006(.A(G17), .B(G18), .Y(new_n80_));
  XOR2x2_ASAP7_75t_R  g007(.A(G19), .B(G20), .Y(new_n81_));
  NOR2x1_ASAP7_75t_R  g008(.A(new_n81_), .B(new_n80_), .Y(new_n82_));
  AND2x2_ASAP7_75t_R  g009(.A(new_n80_), .B(new_n81_), .Y(new_n83_));
  XNOR2x2_ASAP7_75t_R g010(.A(G21), .B(G22), .Y(new_n84_));
  XOR2x2_ASAP7_75t_R  g011(.A(G23), .B(G24), .Y(new_n85_));
  XOR2x2_ASAP7_75t_R  g012(.A(new_n84_), .B(new_n85_), .Y(new_n86_));
  OAI21x1_ASAP7_75t_R g013(.A1(new_n82_), .A2(new_n83_), .B(new_n86_), .Y(new_n87_));
  XOR2x2_ASAP7_75t_R  g014(.A(new_n80_), .B(new_n81_), .Y(new_n88_));
  NOR2x1_ASAP7_75t_R  g015(.A(new_n85_), .B(new_n84_), .Y(new_n89_));
  AND2x2_ASAP7_75t_R  g016(.A(new_n84_), .B(new_n85_), .Y(new_n90_));
  OAI21x1_ASAP7_75t_R g017(.A1(new_n89_), .A2(new_n90_), .B(new_n88_), .Y(new_n91_));
  AND3x1_ASAP7_75t_R  g018(.A(new_n87_), .B(new_n91_), .C(new_n79_), .Y(new_n92_));
  AOI21x1_ASAP7_75t_R g019(.A1(new_n87_), .A2(new_n91_), .B(new_n79_), .Y(new_n93_));
  OA21x2_ASAP7_75t_R  g020(.A1(new_n92_), .A2(new_n93_), .B(new_n78_), .Y(new_n94_));
  NAND3x1_ASAP7_75t_R g021(.A(new_n79_), .B(new_n91_), .C(new_n87_), .Y(new_n95_));
  AO21x1_ASAP7_75t_R  g022(.A1(new_n87_), .A2(new_n91_), .B(new_n79_), .Y(new_n96_));
  AO21x1_ASAP7_75t_R  g023(.A1(new_n95_), .A2(new_n96_), .B(new_n78_), .Y(new_n97_));
  OAI21x1_ASAP7_75t_R g024(.A1(new_n77_), .A2(new_n94_), .B(new_n97_), .Y(new_n98_));
  XNOR2x2_ASAP7_75t_R g025(.A(G4), .B(G8), .Y(new_n99_));
  XOR2x2_ASAP7_75t_R  g026(.A(G12), .B(G16), .Y(new_n100_));
  XOR2x2_ASAP7_75t_R  g027(.A(new_n99_), .B(new_n100_), .Y(new_n101_));
  INVx1_ASAP7_75t_R   g028(.A(new_n101_), .Y(new_n102_));
  AND2x2_ASAP7_75t_R  g029(.A(G41), .B(G36), .Y(new_n103_));
  XNOR2x2_ASAP7_75t_R g030(.A(G29), .B(G30), .Y(new_n104_));
  XOR2x2_ASAP7_75t_R  g031(.A(G31), .B(G32), .Y(new_n105_));
  XOR2x2_ASAP7_75t_R  g032(.A(new_n104_), .B(new_n105_), .Y(new_n106_));
  OAI21x1_ASAP7_75t_R g033(.A1(new_n89_), .A2(new_n90_), .B(new_n106_), .Y(new_n107_));
  NOR2x1_ASAP7_75t_R  g034(.A(new_n105_), .B(new_n104_), .Y(new_n108_));
  AND2x2_ASAP7_75t_R  g035(.A(new_n104_), .B(new_n105_), .Y(new_n109_));
  OAI21x1_ASAP7_75t_R g036(.A1(new_n108_), .A2(new_n109_), .B(new_n86_), .Y(new_n110_));
  AND3x1_ASAP7_75t_R  g037(.A(new_n107_), .B(new_n110_), .C(new_n103_), .Y(new_n111_));
  AOI21x1_ASAP7_75t_R g038(.A1(new_n107_), .A2(new_n110_), .B(new_n103_), .Y(new_n112_));
  OA21x2_ASAP7_75t_R  g039(.A1(new_n111_), .A2(new_n112_), .B(new_n102_), .Y(new_n113_));
  OAI21x1_ASAP7_75t_R g040(.A1(new_n112_), .A2(new_n111_), .B(new_n101_), .Y(new_n114_));
  OAI21x1_ASAP7_75t_R g041(.A1(new_n101_), .A2(new_n113_), .B(new_n114_), .Y(new_n115_));
  XNOR2x2_ASAP7_75t_R g042(.A(G3), .B(G7), .Y(new_n116_));
  XOR2x2_ASAP7_75t_R  g043(.A(G11), .B(G15), .Y(new_n117_));
  XOR2x2_ASAP7_75t_R  g044(.A(new_n116_), .B(new_n117_), .Y(new_n118_));
  INVx1_ASAP7_75t_R   g045(.A(new_n118_), .Y(new_n119_));
  AND2x2_ASAP7_75t_R  g046(.A(G41), .B(G35), .Y(new_n120_));
  XNOR2x2_ASAP7_75t_R g047(.A(G25), .B(G26), .Y(new_n121_));
  XOR2x2_ASAP7_75t_R  g048(.A(G27), .B(G28), .Y(new_n122_));
  XOR2x2_ASAP7_75t_R  g049(.A(new_n121_), .B(new_n122_), .Y(new_n123_));
  OAI21x1_ASAP7_75t_R g050(.A1(new_n82_), .A2(new_n83_), .B(new_n123_), .Y(new_n124_));
  NOR2x1_ASAP7_75t_R  g051(.A(new_n122_), .B(new_n121_), .Y(new_n125_));
  AND2x2_ASAP7_75t_R  g052(.A(new_n121_), .B(new_n122_), .Y(new_n126_));
  OAI21x1_ASAP7_75t_R g053(.A1(new_n125_), .A2(new_n126_), .B(new_n88_), .Y(new_n127_));
  AND3x1_ASAP7_75t_R  g054(.A(new_n124_), .B(new_n127_), .C(new_n120_), .Y(new_n128_));
  AOI21x1_ASAP7_75t_R g055(.A1(new_n124_), .A2(new_n127_), .B(new_n120_), .Y(new_n129_));
  OA21x2_ASAP7_75t_R  g056(.A1(new_n128_), .A2(new_n129_), .B(new_n119_), .Y(new_n130_));
  OAI21x1_ASAP7_75t_R g057(.A1(new_n129_), .A2(new_n128_), .B(new_n118_), .Y(new_n131_));
  OAI21x1_ASAP7_75t_R g058(.A1(new_n118_), .A2(new_n130_), .B(new_n131_), .Y(new_n132_));
  NOR2x1_ASAP7_75t_R  g059(.A(new_n115_), .B(new_n132_), .Y(new_n133_));
  AND3x1_ASAP7_75t_R  g060(.A(new_n95_), .B(new_n78_), .C(new_n96_), .Y(new_n134_));
  INVx1_ASAP7_75t_R   g061(.A(new_n97_), .Y(new_n135_));
  XNOR2x2_ASAP7_75t_R g062(.A(G2), .B(G6), .Y(new_n136_));
  XOR2x2_ASAP7_75t_R  g063(.A(G10), .B(G14), .Y(new_n137_));
  XOR2x2_ASAP7_75t_R  g064(.A(new_n136_), .B(new_n137_), .Y(new_n138_));
  INVx1_ASAP7_75t_R   g065(.A(new_n138_), .Y(new_n139_));
  AND2x2_ASAP7_75t_R  g066(.A(G41), .B(G34), .Y(new_n140_));
  OAI21x1_ASAP7_75t_R g067(.A1(new_n125_), .A2(new_n126_), .B(new_n106_), .Y(new_n141_));
  OAI21x1_ASAP7_75t_R g068(.A1(new_n108_), .A2(new_n109_), .B(new_n123_), .Y(new_n142_));
  AND3x1_ASAP7_75t_R  g069(.A(new_n141_), .B(new_n142_), .C(new_n140_), .Y(new_n143_));
  AOI21x1_ASAP7_75t_R g070(.A1(new_n141_), .A2(new_n142_), .B(new_n140_), .Y(new_n144_));
  OA21x2_ASAP7_75t_R  g071(.A1(new_n143_), .A2(new_n144_), .B(new_n139_), .Y(new_n145_));
  OAI21x1_ASAP7_75t_R g072(.A1(new_n144_), .A2(new_n143_), .B(new_n138_), .Y(new_n146_));
  OA21x2_ASAP7_75t_R  g073(.A1(new_n145_), .A2(new_n138_), .B(new_n146_), .Y(new_n147_));
  OA21x2_ASAP7_75t_R  g074(.A1(new_n134_), .A2(new_n135_), .B(new_n147_), .Y(new_n148_));
  OA21x2_ASAP7_75t_R  g075(.A1(new_n94_), .A2(new_n77_), .B(new_n97_), .Y(new_n149_));
  NOR3x1_ASAP7_75t_R  g076(.A(new_n143_), .B(new_n138_), .C(new_n144_), .Y(new_n150_));
  INVx1_ASAP7_75t_R   g077(.A(new_n146_), .Y(new_n151_));
  OA21x2_ASAP7_75t_R  g078(.A1(new_n150_), .A2(new_n151_), .B(new_n149_), .Y(new_n152_));
  OAI21x1_ASAP7_75t_R g079(.A1(new_n148_), .A2(new_n152_), .B(new_n133_), .Y(new_n153_));
  OR3x1_ASAP7_75t_R   g080(.A(new_n128_), .B(new_n118_), .C(new_n129_), .Y(new_n154_));
  AOI21x1_ASAP7_75t_R g081(.A1(new_n154_), .A2(new_n131_), .B(new_n115_), .Y(new_n155_));
  OAI21x1_ASAP7_75t_R g082(.A1(new_n138_), .A2(new_n145_), .B(new_n146_), .Y(new_n156_));
  NOR2x1_ASAP7_75t_R  g083(.A(new_n156_), .B(new_n98_), .Y(new_n157_));
  OA21x2_ASAP7_75t_R  g084(.A1(new_n130_), .A2(new_n118_), .B(new_n131_), .Y(new_n158_));
  AND2x2_ASAP7_75t_R  g085(.A(new_n158_), .B(new_n115_), .Y(new_n159_));
  OAI21x1_ASAP7_75t_R g086(.A1(new_n155_), .A2(new_n159_), .B(new_n157_), .Y(new_n160_));
  XNOR2x2_ASAP7_75t_R g087(.A(G20), .B(G24), .Y(new_n161_));
  XOR2x2_ASAP7_75t_R  g088(.A(G32), .B(G28), .Y(new_n162_));
  XOR2x2_ASAP7_75t_R  g089(.A(new_n161_), .B(new_n162_), .Y(new_n163_));
  INVx1_ASAP7_75t_R   g090(.A(new_n163_), .Y(new_n164_));
  AND2x2_ASAP7_75t_R  g091(.A(G41), .B(G40), .Y(new_n165_));
  XNOR2x2_ASAP7_75t_R g092(.A(G5), .B(G6), .Y(new_n166_));
  XOR2x2_ASAP7_75t_R  g093(.A(G8), .B(G7), .Y(new_n167_));
  NOR2x1_ASAP7_75t_R  g094(.A(new_n167_), .B(new_n166_), .Y(new_n168_));
  AND2x2_ASAP7_75t_R  g095(.A(new_n166_), .B(new_n167_), .Y(new_n169_));
  XNOR2x2_ASAP7_75t_R g096(.A(G13), .B(G14), .Y(new_n170_));
  XOR2x2_ASAP7_75t_R  g097(.A(G16), .B(G15), .Y(new_n171_));
  XOR2x2_ASAP7_75t_R  g098(.A(new_n170_), .B(new_n171_), .Y(new_n172_));
  OAI21x1_ASAP7_75t_R g099(.A1(new_n168_), .A2(new_n169_), .B(new_n172_), .Y(new_n173_));
  XOR2x2_ASAP7_75t_R  g100(.A(new_n166_), .B(new_n167_), .Y(new_n174_));
  NOR2x1_ASAP7_75t_R  g101(.A(new_n171_), .B(new_n170_), .Y(new_n175_));
  AND2x2_ASAP7_75t_R  g102(.A(new_n170_), .B(new_n171_), .Y(new_n176_));
  OAI21x1_ASAP7_75t_R g103(.A1(new_n175_), .A2(new_n176_), .B(new_n174_), .Y(new_n177_));
  AND3x1_ASAP7_75t_R  g104(.A(new_n173_), .B(new_n177_), .C(new_n165_), .Y(new_n178_));
  AOI21x1_ASAP7_75t_R g105(.A1(new_n173_), .A2(new_n177_), .B(new_n165_), .Y(new_n179_));
  OA21x2_ASAP7_75t_R  g106(.A1(new_n178_), .A2(new_n179_), .B(new_n164_), .Y(new_n180_));
  OAI21x1_ASAP7_75t_R g107(.A1(new_n179_), .A2(new_n178_), .B(new_n163_), .Y(new_n181_));
  OAI21x1_ASAP7_75t_R g108(.A1(new_n163_), .A2(new_n180_), .B(new_n181_), .Y(new_n182_));
  AOI21x1_ASAP7_75t_R g109(.A1(new_n153_), .A2(new_n160_), .B(new_n182_), .Y(new_n183_));
  XNOR2x2_ASAP7_75t_R g110(.A(G19), .B(G23), .Y(new_n184_));
  XOR2x2_ASAP7_75t_R  g111(.A(G31), .B(G27), .Y(new_n185_));
  XOR2x2_ASAP7_75t_R  g112(.A(new_n184_), .B(new_n185_), .Y(new_n186_));
  INVx1_ASAP7_75t_R   g113(.A(new_n186_), .Y(new_n187_));
  AND2x2_ASAP7_75t_R  g114(.A(G41), .B(G39), .Y(new_n188_));
  XNOR2x2_ASAP7_75t_R g115(.A(G1), .B(G2), .Y(new_n189_));
  XOR2x2_ASAP7_75t_R  g116(.A(G4), .B(G3), .Y(new_n190_));
  NOR2x1_ASAP7_75t_R  g117(.A(new_n190_), .B(new_n189_), .Y(new_n191_));
  AND2x2_ASAP7_75t_R  g118(.A(new_n189_), .B(new_n190_), .Y(new_n192_));
  XNOR2x2_ASAP7_75t_R g119(.A(G9), .B(G10), .Y(new_n193_));
  XOR2x2_ASAP7_75t_R  g120(.A(G12), .B(G11), .Y(new_n194_));
  XOR2x2_ASAP7_75t_R  g121(.A(new_n193_), .B(new_n194_), .Y(new_n195_));
  OAI21x1_ASAP7_75t_R g122(.A1(new_n191_), .A2(new_n192_), .B(new_n195_), .Y(new_n196_));
  XOR2x2_ASAP7_75t_R  g123(.A(new_n189_), .B(new_n190_), .Y(new_n197_));
  NOR2x1_ASAP7_75t_R  g124(.A(new_n194_), .B(new_n193_), .Y(new_n198_));
  AND2x2_ASAP7_75t_R  g125(.A(new_n193_), .B(new_n194_), .Y(new_n199_));
  OAI21x1_ASAP7_75t_R g126(.A1(new_n198_), .A2(new_n199_), .B(new_n197_), .Y(new_n200_));
  AND3x1_ASAP7_75t_R  g127(.A(new_n196_), .B(new_n200_), .C(new_n188_), .Y(new_n201_));
  AOI21x1_ASAP7_75t_R g128(.A1(new_n196_), .A2(new_n200_), .B(new_n188_), .Y(new_n202_));
  OA21x2_ASAP7_75t_R  g129(.A1(new_n201_), .A2(new_n202_), .B(new_n187_), .Y(new_n203_));
  OAI21x1_ASAP7_75t_R g130(.A1(new_n202_), .A2(new_n201_), .B(new_n186_), .Y(new_n204_));
  OAI21x1_ASAP7_75t_R g131(.A1(new_n186_), .A2(new_n203_), .B(new_n204_), .Y(new_n205_));
  XNOR2x2_ASAP7_75t_R g132(.A(G18), .B(G22), .Y(new_n206_));
  XOR2x2_ASAP7_75t_R  g133(.A(G30), .B(G26), .Y(new_n207_));
  XOR2x2_ASAP7_75t_R  g134(.A(new_n206_), .B(new_n207_), .Y(new_n208_));
  INVx1_ASAP7_75t_R   g135(.A(new_n208_), .Y(new_n209_));
  AND2x2_ASAP7_75t_R  g136(.A(G41), .B(G38), .Y(new_n210_));
  OAI21x1_ASAP7_75t_R g137(.A1(new_n198_), .A2(new_n199_), .B(new_n172_), .Y(new_n211_));
  OAI21x1_ASAP7_75t_R g138(.A1(new_n175_), .A2(new_n176_), .B(new_n195_), .Y(new_n212_));
  AND3x1_ASAP7_75t_R  g139(.A(new_n211_), .B(new_n212_), .C(new_n210_), .Y(new_n213_));
  AOI21x1_ASAP7_75t_R g140(.A1(new_n211_), .A2(new_n212_), .B(new_n210_), .Y(new_n214_));
  OA21x2_ASAP7_75t_R  g141(.A1(new_n213_), .A2(new_n214_), .B(new_n209_), .Y(new_n215_));
  OAI21x1_ASAP7_75t_R g142(.A1(new_n214_), .A2(new_n213_), .B(new_n208_), .Y(new_n216_));
  OA21x2_ASAP7_75t_R  g143(.A1(new_n215_), .A2(new_n208_), .B(new_n216_), .Y(new_n217_));
  XNOR2x2_ASAP7_75t_R g144(.A(G17), .B(G21), .Y(new_n218_));
  XOR2x2_ASAP7_75t_R  g145(.A(G29), .B(G25), .Y(new_n219_));
  XOR2x2_ASAP7_75t_R  g146(.A(new_n218_), .B(new_n219_), .Y(new_n220_));
  INVx1_ASAP7_75t_R   g147(.A(new_n220_), .Y(new_n221_));
  AND2x2_ASAP7_75t_R  g148(.A(G41), .B(G37), .Y(new_n222_));
  OAI21x1_ASAP7_75t_R g149(.A1(new_n191_), .A2(new_n192_), .B(new_n174_), .Y(new_n223_));
  OAI21x1_ASAP7_75t_R g150(.A1(new_n168_), .A2(new_n169_), .B(new_n197_), .Y(new_n224_));
  AND3x1_ASAP7_75t_R  g151(.A(new_n223_), .B(new_n224_), .C(new_n222_), .Y(new_n225_));
  AOI21x1_ASAP7_75t_R g152(.A1(new_n223_), .A2(new_n224_), .B(new_n222_), .Y(new_n226_));
  OA21x2_ASAP7_75t_R  g153(.A1(new_n225_), .A2(new_n226_), .B(new_n221_), .Y(new_n227_));
  NAND3x1_ASAP7_75t_R g154(.A(new_n222_), .B(new_n224_), .C(new_n223_), .Y(new_n228_));
  AO21x1_ASAP7_75t_R  g155(.A1(new_n223_), .A2(new_n224_), .B(new_n222_), .Y(new_n229_));
  AO21x1_ASAP7_75t_R  g156(.A1(new_n228_), .A2(new_n229_), .B(new_n221_), .Y(new_n230_));
  OAI21x1_ASAP7_75t_R g157(.A1(new_n220_), .A2(new_n227_), .B(new_n230_), .Y(new_n231_));
  AND3x1_ASAP7_75t_R  g158(.A(new_n231_), .B(new_n217_), .C(new_n205_), .Y(new_n232_));
  AND3x1_ASAP7_75t_R  g159(.A(new_n183_), .B(new_n98_), .C(new_n232_), .Y(new_n233_));
  XOR2x2_ASAP7_75t_R  g160(.A(new_n233_), .B(new_n74_), .Y(G1324));
  INVx1_ASAP7_75t_R   g161(.A(G21), .Y(new_n235_));
  INVx1_ASAP7_75t_R   g162(.A(new_n115_), .Y(new_n236_));
  AND3x1_ASAP7_75t_R  g163(.A(new_n228_), .B(new_n221_), .C(new_n229_), .Y(new_n237_));
  INVx1_ASAP7_75t_R   g164(.A(new_n230_), .Y(new_n238_));
  OA21x2_ASAP7_75t_R  g165(.A1(new_n237_), .A2(new_n238_), .B(new_n217_), .Y(new_n239_));
  NOR2x1_ASAP7_75t_R  g166(.A(new_n182_), .B(new_n205_), .Y(new_n240_));
  NOR3x1_ASAP7_75t_R  g167(.A(new_n213_), .B(new_n208_), .C(new_n214_), .Y(new_n241_));
  INVx1_ASAP7_75t_R   g168(.A(new_n216_), .Y(new_n242_));
  OA21x2_ASAP7_75t_R  g169(.A1(new_n227_), .A2(new_n220_), .B(new_n230_), .Y(new_n243_));
  OA21x2_ASAP7_75t_R  g170(.A1(new_n241_), .A2(new_n242_), .B(new_n243_), .Y(new_n244_));
  OAI21x1_ASAP7_75t_R g171(.A1(new_n239_), .A2(new_n244_), .B(new_n240_), .Y(new_n245_));
  OR3x1_ASAP7_75t_R   g172(.A(new_n201_), .B(new_n186_), .C(new_n202_), .Y(new_n246_));
  AOI21x1_ASAP7_75t_R g173(.A1(new_n246_), .A2(new_n204_), .B(new_n182_), .Y(new_n247_));
  OAI21x1_ASAP7_75t_R g174(.A1(new_n208_), .A2(new_n215_), .B(new_n216_), .Y(new_n248_));
  NOR2x1_ASAP7_75t_R  g175(.A(new_n248_), .B(new_n231_), .Y(new_n249_));
  OA21x2_ASAP7_75t_R  g176(.A1(new_n203_), .A2(new_n186_), .B(new_n204_), .Y(new_n250_));
  AND2x2_ASAP7_75t_R  g177(.A(new_n250_), .B(new_n182_), .Y(new_n251_));
  OAI21x1_ASAP7_75t_R g178(.A1(new_n247_), .A2(new_n251_), .B(new_n249_), .Y(new_n252_));
  AOI21x1_ASAP7_75t_R g179(.A1(new_n245_), .A2(new_n252_), .B(new_n236_), .Y(new_n253_));
  AND3x1_ASAP7_75t_R  g180(.A(new_n98_), .B(new_n158_), .C(new_n147_), .Y(new_n254_));
  AND3x1_ASAP7_75t_R  g181(.A(new_n253_), .B(new_n231_), .C(new_n254_), .Y(new_n255_));
  XOR2x2_ASAP7_75t_R  g182(.A(new_n255_), .B(new_n235_), .Y(G1344));
  INVx1_ASAP7_75t_R   g183(.A(G2), .Y(new_n257_));
  AND3x1_ASAP7_75t_R  g184(.A(new_n183_), .B(new_n156_), .C(new_n232_), .Y(new_n258_));
  XOR2x2_ASAP7_75t_R  g185(.A(new_n258_), .B(new_n257_), .Y(G1325));
  INVx1_ASAP7_75t_R   g186(.A(G3), .Y(new_n260_));
  AND3x1_ASAP7_75t_R  g187(.A(new_n183_), .B(new_n132_), .C(new_n232_), .Y(new_n261_));
  XOR2x2_ASAP7_75t_R  g188(.A(new_n261_), .B(new_n260_), .Y(G1326));
  INVx1_ASAP7_75t_R   g189(.A(G4), .Y(new_n263_));
  AND3x1_ASAP7_75t_R  g190(.A(new_n183_), .B(new_n115_), .C(new_n232_), .Y(new_n264_));
  XOR2x2_ASAP7_75t_R  g191(.A(new_n264_), .B(new_n263_), .Y(G1327));
  INVx1_ASAP7_75t_R   g192(.A(G5), .Y(new_n266_));
  INVx1_ASAP7_75t_R   g193(.A(new_n182_), .Y(new_n267_));
  AOI21x1_ASAP7_75t_R g194(.A1(new_n153_), .A2(new_n160_), .B(new_n267_), .Y(new_n268_));
  AND3x1_ASAP7_75t_R  g195(.A(new_n250_), .B(new_n231_), .C(new_n217_), .Y(new_n269_));
  AND3x1_ASAP7_75t_R  g196(.A(new_n268_), .B(new_n98_), .C(new_n269_), .Y(new_n270_));
  XOR2x2_ASAP7_75t_R  g197(.A(new_n270_), .B(new_n266_), .Y(G1328));
  INVx1_ASAP7_75t_R   g198(.A(G6), .Y(new_n272_));
  AND3x1_ASAP7_75t_R  g199(.A(new_n268_), .B(new_n156_), .C(new_n269_), .Y(new_n273_));
  XOR2x2_ASAP7_75t_R  g200(.A(new_n273_), .B(new_n272_), .Y(G1329));
  INVx1_ASAP7_75t_R   g201(.A(G7), .Y(new_n275_));
  AND3x1_ASAP7_75t_R  g202(.A(new_n268_), .B(new_n132_), .C(new_n269_), .Y(new_n276_));
  XOR2x2_ASAP7_75t_R  g203(.A(new_n276_), .B(new_n275_), .Y(G1330));
  INVx1_ASAP7_75t_R   g204(.A(G20), .Y(new_n278_));
  AOI21x1_ASAP7_75t_R g205(.A1(new_n245_), .A2(new_n252_), .B(new_n115_), .Y(new_n279_));
  AND3x1_ASAP7_75t_R  g206(.A(new_n98_), .B(new_n147_), .C(new_n132_), .Y(new_n280_));
  AND3x1_ASAP7_75t_R  g207(.A(new_n279_), .B(new_n182_), .C(new_n280_), .Y(new_n281_));
  XOR2x2_ASAP7_75t_R  g208(.A(new_n281_), .B(new_n278_), .Y(G1343));
  INVx1_ASAP7_75t_R   g209(.A(G8), .Y(new_n283_));
  AND3x1_ASAP7_75t_R  g210(.A(new_n268_), .B(new_n115_), .C(new_n269_), .Y(new_n284_));
  XOR2x2_ASAP7_75t_R  g211(.A(new_n284_), .B(new_n283_), .Y(G1331));
  INVx1_ASAP7_75t_R   g212(.A(G9), .Y(new_n286_));
  AND3x1_ASAP7_75t_R  g213(.A(new_n243_), .B(new_n205_), .C(new_n248_), .Y(new_n287_));
  AND3x1_ASAP7_75t_R  g214(.A(new_n183_), .B(new_n98_), .C(new_n287_), .Y(new_n288_));
  XOR2x2_ASAP7_75t_R  g215(.A(new_n288_), .B(new_n286_), .Y(G1332));
  INVx1_ASAP7_75t_R   g216(.A(G10), .Y(new_n290_));
  AND3x1_ASAP7_75t_R  g217(.A(new_n183_), .B(new_n156_), .C(new_n287_), .Y(new_n291_));
  XOR2x2_ASAP7_75t_R  g218(.A(new_n291_), .B(new_n290_), .Y(G1333));
  INVx1_ASAP7_75t_R   g219(.A(G11), .Y(new_n293_));
  AND3x1_ASAP7_75t_R  g220(.A(new_n183_), .B(new_n132_), .C(new_n287_), .Y(new_n294_));
  XOR2x2_ASAP7_75t_R  g221(.A(new_n294_), .B(new_n293_), .Y(G1334));
  INVx1_ASAP7_75t_R   g222(.A(G12), .Y(new_n296_));
  AND3x1_ASAP7_75t_R  g223(.A(new_n183_), .B(new_n115_), .C(new_n287_), .Y(new_n297_));
  XOR2x2_ASAP7_75t_R  g224(.A(new_n297_), .B(new_n296_), .Y(G1335));
  INVx1_ASAP7_75t_R   g225(.A(G13), .Y(new_n299_));
  AND3x1_ASAP7_75t_R  g226(.A(new_n243_), .B(new_n250_), .C(new_n248_), .Y(new_n300_));
  AND3x1_ASAP7_75t_R  g227(.A(new_n268_), .B(new_n98_), .C(new_n300_), .Y(new_n301_));
  XOR2x2_ASAP7_75t_R  g228(.A(new_n301_), .B(new_n299_), .Y(G1336));
  INVx1_ASAP7_75t_R   g229(.A(G14), .Y(new_n303_));
  AND3x1_ASAP7_75t_R  g230(.A(new_n268_), .B(new_n156_), .C(new_n300_), .Y(new_n304_));
  XOR2x2_ASAP7_75t_R  g231(.A(new_n304_), .B(new_n303_), .Y(G1337));
  INVx1_ASAP7_75t_R   g232(.A(G15), .Y(new_n306_));
  AND3x1_ASAP7_75t_R  g233(.A(new_n268_), .B(new_n132_), .C(new_n300_), .Y(new_n307_));
  XOR2x2_ASAP7_75t_R  g234(.A(new_n307_), .B(new_n306_), .Y(G1338));
  INVx1_ASAP7_75t_R   g235(.A(G16), .Y(new_n309_));
  AND3x1_ASAP7_75t_R  g236(.A(new_n268_), .B(new_n115_), .C(new_n300_), .Y(new_n310_));
  XOR2x2_ASAP7_75t_R  g237(.A(new_n310_), .B(new_n309_), .Y(G1339));
  INVx1_ASAP7_75t_R   g238(.A(G17), .Y(new_n312_));
  AND3x1_ASAP7_75t_R  g239(.A(new_n279_), .B(new_n231_), .C(new_n280_), .Y(new_n313_));
  XOR2x2_ASAP7_75t_R  g240(.A(new_n313_), .B(new_n312_), .Y(G1340));
  INVx1_ASAP7_75t_R   g241(.A(G18), .Y(new_n315_));
  AND3x1_ASAP7_75t_R  g242(.A(new_n279_), .B(new_n248_), .C(new_n280_), .Y(new_n316_));
  XOR2x2_ASAP7_75t_R  g243(.A(new_n316_), .B(new_n315_), .Y(G1341));
  INVx1_ASAP7_75t_R   g244(.A(G19), .Y(new_n318_));
  AND3x1_ASAP7_75t_R  g245(.A(new_n279_), .B(new_n205_), .C(new_n280_), .Y(new_n319_));
  XOR2x2_ASAP7_75t_R  g246(.A(new_n319_), .B(new_n318_), .Y(G1342));
  INVx1_ASAP7_75t_R   g247(.A(G22), .Y(new_n321_));
  AND3x1_ASAP7_75t_R  g248(.A(new_n253_), .B(new_n248_), .C(new_n254_), .Y(new_n322_));
  XOR2x2_ASAP7_75t_R  g249(.A(new_n322_), .B(new_n321_), .Y(G1345));
  INVx1_ASAP7_75t_R   g250(.A(G23), .Y(new_n324_));
  AND3x1_ASAP7_75t_R  g251(.A(new_n253_), .B(new_n205_), .C(new_n254_), .Y(new_n325_));
  XOR2x2_ASAP7_75t_R  g252(.A(new_n325_), .B(new_n324_), .Y(G1346));
  INVx1_ASAP7_75t_R   g253(.A(G24), .Y(new_n327_));
  AND3x1_ASAP7_75t_R  g254(.A(new_n253_), .B(new_n182_), .C(new_n254_), .Y(new_n328_));
  XOR2x2_ASAP7_75t_R  g255(.A(new_n328_), .B(new_n327_), .Y(G1347));
  INVx1_ASAP7_75t_R   g256(.A(G25), .Y(new_n330_));
  AND3x1_ASAP7_75t_R  g257(.A(new_n149_), .B(new_n132_), .C(new_n156_), .Y(new_n331_));
  AND3x1_ASAP7_75t_R  g258(.A(new_n279_), .B(new_n231_), .C(new_n331_), .Y(new_n332_));
  XOR2x2_ASAP7_75t_R  g259(.A(new_n332_), .B(new_n330_), .Y(G1348));
  INVx1_ASAP7_75t_R   g260(.A(G26), .Y(new_n334_));
  AND3x1_ASAP7_75t_R  g261(.A(new_n279_), .B(new_n248_), .C(new_n331_), .Y(new_n335_));
  XOR2x2_ASAP7_75t_R  g262(.A(new_n335_), .B(new_n334_), .Y(G1349));
  INVx1_ASAP7_75t_R   g263(.A(G27), .Y(new_n337_));
  AND3x1_ASAP7_75t_R  g264(.A(new_n279_), .B(new_n205_), .C(new_n331_), .Y(new_n338_));
  XOR2x2_ASAP7_75t_R  g265(.A(new_n338_), .B(new_n337_), .Y(G1350));
  INVx1_ASAP7_75t_R   g266(.A(G28), .Y(new_n340_));
  AND3x1_ASAP7_75t_R  g267(.A(new_n279_), .B(new_n182_), .C(new_n331_), .Y(new_n341_));
  XOR2x2_ASAP7_75t_R  g268(.A(new_n341_), .B(new_n340_), .Y(G1351));
  INVx1_ASAP7_75t_R   g269(.A(G29), .Y(new_n343_));
  AND3x1_ASAP7_75t_R  g270(.A(new_n149_), .B(new_n158_), .C(new_n156_), .Y(new_n344_));
  AND3x1_ASAP7_75t_R  g271(.A(new_n253_), .B(new_n231_), .C(new_n344_), .Y(new_n345_));
  XOR2x2_ASAP7_75t_R  g272(.A(new_n345_), .B(new_n343_), .Y(G1352));
  INVx1_ASAP7_75t_R   g273(.A(G30), .Y(new_n347_));
  AND3x1_ASAP7_75t_R  g274(.A(new_n253_), .B(new_n248_), .C(new_n344_), .Y(new_n348_));
  XOR2x2_ASAP7_75t_R  g275(.A(new_n348_), .B(new_n347_), .Y(G1353));
  INVx1_ASAP7_75t_R   g276(.A(G31), .Y(new_n350_));
  AND3x1_ASAP7_75t_R  g277(.A(new_n253_), .B(new_n205_), .C(new_n344_), .Y(new_n351_));
  XOR2x2_ASAP7_75t_R  g278(.A(new_n351_), .B(new_n350_), .Y(G1354));
  INVx1_ASAP7_75t_R   g279(.A(G32), .Y(new_n353_));
  AND3x1_ASAP7_75t_R  g280(.A(new_n253_), .B(new_n182_), .C(new_n344_), .Y(new_n354_));
  XOR2x2_ASAP7_75t_R  g281(.A(new_n354_), .B(new_n353_), .Y(G1355));
endmodule


