# V8 full-certificate scheduling ablation

One frozen binary; only certificate cadence differs. Missing/failure rows remain in full20 scope.600s mapping-related search, independentCEC excluded.

|Design|Period1 A/D/T|Period16 A/D/T|
|---|---|---|
|adder|87.10/2569.15/32.35|87.10/2569.15/32.36|
|bar|248.25/168.29/211.37|248.25/168.29/214.43|
|div|9596.88/43058.72/600.11|9598.65/43058.72/600.11|
|log2|6324.35/3989.77/600.11|6094.36/3857.75/600.05|

Physical bindings and already validated complete incumbents are retained; unvalidated intermediate Flow assignments can be coalesced. First ready cover is not delayed, and dirty states are forcibly checked at delta closure and before final recovery while original time remains. Less frequent certification can miss an intermediate better assignment, so this is a quality/performance experiment, not a guarantee against other historical runs. Certificate counts alone are not runtime improvement. Source/pin/care proofs remain mandatory before any publication.

The older V2 online log2 control D3852.82 remains a separate stronger reference; this report must not hide a regression by comparing only against source fallback. V6 results, including div/hyp, are a distinct frozen version, not merged into the V8 candidate. All raw600 timeouts and predeadline receipts remain. Full20 independent factors and repeats are unfinished.
