# Online metric workspace and full-extractor tail: limited-scope verification

One frozen V6 configuration for every candidate design; no winner mixing. Same binary 2x2 metric/tail switch for first2 controls. All mapping search shares600s; independentCEC excluded.

|Design|Metric/tail off A/D/T|Metric/tail on A/D/T|Search finished (on)|
|---|---|---|---|
|adder|87.10/2569.15/20.09|87.10/2569.15/33.18|True|
|bar|248.36/168.29/22.04|248.25/168.29/215.27|True|
|log2|missing|6386.77/4010.95/600.11|False|
|max|missing|224.75/2074.58/515.82|True|
|arbiter|missing|767.22/898.75/600.11|False|
|cavlc|missing|36.83/185.87/61.81|True|
|ctrl|missing|6.57/103.17/2.93|True|
|dec|missing|30.32/65.72/27.91|True|
|i2c|missing|66.40/165.79/149.30|True|
|int2float|missing|12.26/181.00/3.26|True|
|priority|missing|64.33/2045.58/38.09|True|
|router|missing|11.68/187.47/5.94|True|

Unique designs: 12; candidate optimized: 12. Repeats: {'adder': {'runs': 3, 'identical_AD': True}, 'bar': {'runs': 3, 'identical_AD': True}}.

## Log2 version history (all failures retained)

|Version/config|A|D|T|CEC|Search finished|
|---|---:|---:|---:|---|---|
|v2_epfl_control|6103.21|3852.82|600.11|1|False|
|v2_epfl_combined|4726.97|4059.30|600.11|1|False|
|v3_epfl_combined|4756.94|4059.30|600.10|1|False|
|v3_p0|6389.84|4027.23|600.10|1|False|
|v4_epfl|6386.77|4010.95|600.11|1|False|
|v5_epfl|6386.77|4010.95|600.05|1|False|
|v6_epfl|6386.77|4010.95|600.11|1|False|

History rows are different named versions/configurations, not a single mapper selected per design. Same-binary full20 metric/tail ablations and log2 repeats are unfinished. Every missing/failure row remains in all_scope.csv; all baseline gates use the full required scope. Old full-flow adder area87.06 remains below the online87.10 when that current result persists; preserving batch delay seeds is not full legacy shared-area recovery.

The scoped metric workspace is enabled at the actual online entry point and restores its state on exit. The optional full legacy shared extractor runs only at the tail after matching closure, within the original global deadline; its proposal must satisfy both current D and A bounds. It is nonpreemptive and does not guarantee recovery of the old full-flow trajectory. The proof memo belongs to one frozen logical/library epoch and append-only physical identities. Targets/evidence may grow. Every newly used binding needs full source proof; cached cut witnesses are checked for retention. Driver/cycle, full physical A/D and final independentCEC remain checked. Retention pins are materialized only on demand. This is not general deferred physical Instance materialization; resumable whole area-flow/shared-cover recovery is unfinished. No main/paper adoption.
