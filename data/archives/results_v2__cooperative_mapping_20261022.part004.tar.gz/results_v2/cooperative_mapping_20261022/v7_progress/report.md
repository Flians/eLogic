# V7 negative-certificate-cache ablation

One frozen binary; only cache flag differs. Missing/failure rows remain in full20 scope.600s mapping-related search, independentCEC excluded.

|Design|Cache off A/D/T|Cache on A/D/T|
|---|---|---|
|adder|87.10/2569.15/31.53|87.10/2569.15/32.05|
|log2|6386.77/4010.95/600.11|6386.77/4010.95/600.11|

A certificate attempt is not a failed proof. Consult certificate_diagnostics.json: absent rejected_* and rejected_unchanged_skip events mean the negative-cache performance hypothesis was not supported by this workload, even though constructed rejection/invalidation regressions pass. Valid, globally nonimproving selected covers need scoring/scheduling improvements. No speedup or main adoption follows from unit tests.

The older V2 online log2 control D3852.82 remains a separate stronger reference; this report must not hide a regression by comparing only against source fallback. V6 results, including div/hyp, are a distinct frozen version, not merged into the V7 candidate. All raw600 timeouts and predeadline receipts remain. Full20 independent factors and repeats are unfinished.
