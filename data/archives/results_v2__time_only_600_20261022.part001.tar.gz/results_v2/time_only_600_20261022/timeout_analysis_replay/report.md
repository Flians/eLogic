# EPFL600：九个超时的阶段审计

该报告重放已经完成的同版20设计实验；没有重跑mapper、提高预算、修改baseline或把基础覆盖算作优化成功。20个最终网表均有独立CEC，但优化覆盖只有11个。

## 可重复检查

`python3 scripts/experiments/campaigns/analyze_time600_timeouts.py --output NEW_DIRECTORY --require-complete`

2026-10-22已执行，0.03秒量级，退出1：11优化、9超时；7个cuts未完成、2个已进入恢复。核验所用report/trace/import/retention/index原始SHA，完整数据见analysis.json。这个红色检查重放真实600秒失败记录；不是新的性能运行，也不能证明未来补丁已修复。

诊断范围限定为阶段归因。本轮跳过重新执行九个600秒复现和CPU最小化：冻结原版已有真实失败证据；没有改源码或宣布修复。精确热点、峰值内存和任何补丁的因果收益仍须单独测量。

## 观测

|设计|实际导入e-nodes|饱和秒数|最后进入阶段|物理保留实例|
|---|---:|---:|---|---:|
|div|40,989|0.067|recover_start|10,588,394|
|hyp|211,714|1.249|cut_round_3_start|0|
|log2|29,404|0.067|cut_round_5_start|0|
|multiplier|24,685|0.056|cut_round_6_start|0|
|sin|5,085|0.006|cut_round_6_start|0|
|sqrt|19,630|0.013|cut_round_8_start|0|
|square|16,713|0.024|cut_round_5_start|0|
|mem_ctrl|47,384|0.068|recover_start|16,312,958|
|voter|10,759|0.008|cut_round_6_start|0|

表中0仅表示尚未进入原生物理候选生成阶段（外层源覆盖仍存在），不是没有可行库匹配。所有9例都完成输入导入，失败不是节点准入拒绝。sin只导入5,085个e-nodes仍超时；因此不能把九例全部归结为输入图太大。九例的饱和均在1.25秒内结束，失败发生在之后。

### 七个cuts未完成

hyp完整轮次的相邻start间隔为5.49/34.57/135.81秒，第4轮尚未结束就被终止。log2为0.74/4.30/14.53/53.38/181.93秒，第6轮未结束。multiplier、sin、sqrt、square、voter也表现为后续轮次逐渐变慢。完整序列见analysis.json。

阶段日志未记录每轮cuts数量，不能把时间增长直接量化成候选数量增长，也不能证明某个具体子循环独占时间。源码显示每轮clone整张cuts表，重建functional support index，并对两个子cut银行做笛卡尔组合、集合合并、真值表展开和排序。在cuts/class=usizeMAX时，原先的配额不再淘汰optional cuts；规模放大也会放大这些全表与组合操作。这是明确的待验证热点集合。

### div：恢复开始得太晚

- **div**：cuts阶段464.79秒、小cut物理生成123.47秒；其后到recover_start还有8.66秒（含宽匹配/归一化/锥裁剪等，不能全算宽匹配）。保留10,588,394实例。以import_done为较晚锚点，恢复时剩余预算的保守上界只有2.96秒；这不是恢复实际耗时。
- **mem_ctrl**：cuts阶段54.99秒、小cut物理生成231.64秒；其后到recover_start还有24.26秒（含宽匹配/归一化/锥裁剪等，不能全算宽匹配）。保留16,312,958实例。以import_done为较晚锚点，恢复时剩余预算的保守上界只有288.98秒；这不是恢复实际耗时。

div的前处理已基本耗尽600秒，哪怕恢复器本身很快，也没有足够的结束与导出机会。mem_ctrl剩余时间上界约289秒，不能用同一个“只剩几秒”解释；需要进一步拆分其恢复初始化、seed、交换与实际面积恢复。

### mem_ctrl：巨大物理池与不可观察的恢复内部位置

time-only路径在cap_instances_with_frontier_mode中直接保留全部实例并返回frontier=None。恢复随后重新构造finite_choices_queued：对所有实例按area排序，分配order/rank/remaining和signal→users索引，再沿依赖队列推进。该初始化没有deadline参数，也没有循环内取消检查。它对1631万实例具有显著的全池排序和邻接表构建工作，但当前trace不能证明它就是289秒的主要消耗。

共享generator-index记录div为10,575,954项、mem_ctrl为16,269,998项；按记录的16字节桶项只计这部分载荷约161/248MiB，远不包含Instance、输入vector、输出targets、树索引及分配器开销，不能当作RSS或峰值内存。没有RSS/major-fault/OOM记录，不能说九例因内存耗尽被杀；timeout标志来自600秒外层看门狗。

## 跨阶段时钟与incumbent交接

1. egraph_time_policy::parameters在map入口把当时remaining写入refine_time_secs；recover稍后以新的Instant::now()+这个旧remaining重新构造deadline。若前置阶段耗时P，这个局部deadline将晚于外层deadline约P。phase_deadline在time-only时会返回外层绝对deadline，但recover中的直接search参数及未检查deadline的初始化不因此全部安全。外层600秒仍有效，不能据此说实验增加了预算；风险是内层不能及时交接/返回。
2. return_reserve=0，且完整原生物理网表要等recover返回并完成validate/export后才发布。进程被kill时，即使内存中曾访问有效cover，也不能当作已导出、已CEC的优化结果。
3. recovery_event先缓存在thread-local Vec，RecoveryTrace::drop才写trace；SIGKILL不运行Drop。两例恢复没有最终trace不等于没有做任何恢复，也不证明没有合法seed。现有可观察性不足，下一诊断版应采用可追加的少量里程碑。

## 优先级及可证伪实验（全部只改eGraphMap）

1. **先形成可导出的优化incumbent，再扩大搜索**：增量cuts→match→cover，按工作队列交替推进，而非先求完全部cut闭包才首次恢复。保持一个绝对600秒时钟，不引入新节点/池硬限额。预测：hyp/log2可在深轮次结束前访问并导出经过验证的优化cover；若没有，则需查早期物理匹配/可达性，而不是继续盲目减轮次。
2. **delta cuts与去重**：借用只读bank、增量functional index、仅组合新cut与依赖者；精确重复合并须保留生成证明、输入相位/引脚和共享目标。预测：同一完整输入上，前几轮的语义cut集合/可用binding等价，组合访问和复制字节减少。不能凭area-flow分数丢弃可能共享的候选后声称无损。
3. **全池恢复初始化改为可取消、可复用的依赖索引**：记录witness_sort/users_build/seed_validated/phase/local/export里程碑；将绝对deadline传入setup，复用生成时已经建立的必要依赖。预测：mem_ctrl不再在不可取消setup内耗尽预算；相同输入绑定与合法性检查须与旧实现对照。
4. **绝对deadline与原子incumbent发布**：去除旧remaining重新起算，按已完成合法cover检查点原子导出，外层终止只能拒绝未完成事务。预测：div不会把一个晚于外层deadline的内部window误当成可用恢复时间；不把原始源fallback改名为优化。

这些是下一版eGraphMap实验建议，尚未实现或证明改善；baseline源码、模型、参数选择逻辑及原生赢家均不得为此调优。新版本须独立完整scope/CEC/A-D-T/重复验证，保留本版9个失败。
