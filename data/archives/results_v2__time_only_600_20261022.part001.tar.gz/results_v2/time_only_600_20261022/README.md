# Active experiment policy:600 seconds of mapping only

User instruction2026-10-22 supersedes the earlier300/60/5/20/2-second and
proportional-node/100000-candidate resource policies for new eGraphMap experiments.
The active entry is `scripts/experiments/campaigns/run_time_only600.py` and the
machine-readable policy is `emapper/EXPERIMENT_POLICY.json`.

One outer600-second monotonic deadline covers source cover construction, native
library loading/import/saturation/cuts/matching/recovery and export. The native
receives only the remaining window; recursive scopes cannot renew it. No
independent native/stage deadlines or configured node, retained-candidate, cut,
iteration, helper, recovery-trial or address-space ceilings are imposed.
`usize::MAX` is the native unbounded-count representation, not a larger dataset
budget. Actual admission, counts and memory measurements are still recorded.
The library, rewrite families, correctness restrictions, K6 small-truth
representation and directed7–9-input cell matching remain algorithm choices;
this is not a claim of exhaustive functional/structural search.

Independent named-port CEC and physical measurement are outside the mapping
clock. The same original input and once-resyn2 subject are reused. Baseline
author algorithms/models/parameters are unchanged. Old baseline observations
retain their old timeout policy and cannot be relabeled as600-second comparisons.

At expiry the outer process group is killed. Complete source coverage is
published before native search; partial native output cannot become a success.
Native stdout/stderr stream directly to files so they survive group termination.
Timeouts and source-only coverage remain explicitly distinct from native
optimization success. No process is expected to survive between chat turns.

Validation:

*245 related tests passed,6 ignored,16 filtered. Three include deadline
 nonrenewal, no count ceilings, and a real cover exceeding deliberately tiny old
 node/pool limits. Existing ordinary profiles are unchanged when this opt-in is off.
*Three real-process clock tests passed: process-group cleanup, propagated outer
 deadline/CEC exclusion, and real frontend source/log survival at expiry. The
 earlier missing timeout-metadata field failure is preserved and fixed.
*`policy_validation`: actual EPFL dec,446760 native retained candidates,
 cuts/class21,605 e-nodes; original named-port CEC passed. This exceeds the old
100000/16 limits and validates that cancellation actually takes effect. See
`validation.json` for A/D/T. This is one-design policy validation, not full EPFL
 quality evidence or a600-second baseline victory.

The `dec_validation`, `dec_validation_v2` and `dec_validation_final` runs are development harness versions,
not additional designs or a best-of-repeats selection. Their inputs/source are
preserved; `frontend_before_timeout_metadata_fix.py` preserves the old frontend
bytes. The final/native algorithm snapshot has no main-library merge or paper
result substitution implied by this execution-policy change.

Example finite checkpoint batch:

```sh
python3 scripts/experiments/campaigns/run_time_only600.py \
  --output results_v2/time_only_600_20261022/epfl_checkpoint \
  --max-jobs 1
```

Do not continue the old300-second matrices under this policy. Actual source,
binary, harness, input and library fingerprints are frozen in each new campaign.
