//! Exact, bounded non-injective pin bindings: two complementary pin pairs.
//! Existing logical signals only; no nodes, cuts or conditional unions are added.
use super::*;
use itertools::Itertools;

#[derive(Clone,Debug)]struct Folded{cell:usize,function:u64,pins:Vec<usize>}
type Bank=BTreeMap<(usize,u64),Vec<Folded>>;
fn cofactor(cell:&crate::techlib::Cell,pins:&[usize],k:usize)->u64{
 let mut f=0;for a in 0..1usize<<k{let raw=pins.iter().enumerate().fold(0,|v,(p,&s)|v|(((((a>>(s/2))&1)^(s&1)))<<p));f|=((cell.tt[raw/64]>>(raw%64))&1)<<a;}f
}
fn compile(tech:&TechLib)->Bank{
 let mut bank=Bank::new();let mut seen=HashSet::new();
 for(ci,c)in tech.cells.iter().enumerate(){
  let n=c.vars.len();if !(4..=5).contains(&n)||tech.cells.iter().filter(|v|v.name==c.name).count()!=1{continue}
  let k=n-2;
  for a in 0..n{for b in a+1..n{for d in 0..n{for e in d+1..n{
   if [a,b].contains(&d)||[a,b].contains(&e)||(a,b)>=(d,e){continue}
   let mut base=vec![usize::MAX;n];base[a]=0;base[b]=1;base[d]=2;base[e]=3;
   let mut v=2;for pin in 0..n{if base[pin]==usize::MAX{base[pin]=v*2;v+=1;}}
   for permutation in (0..k).permutations(k){for phase in 0..1usize<<k{
    let pins:Vec<_>=base.iter().map(|s|{let v=permutation[s/2];v*2+((s&1)^((phase>>v)&1))}).collect();
    let f=cofactor(c,&pins,k);
    if !(0..k).all(|p|(0..1usize<<k).filter(|a|a&(1<<p)==0).any(|a|((f>>a)^(f>>(a|(1<<p))))&1!=0)){continue}
    // Equal function, same signed fanins and identical maximum pin arcs for every
    // physical signal give identical A/D for all arrivals in the unloaded model.
    // Keep one deterministic named-pin realization of that exact projection.
    let mut arcs=vec![None::<f32>;2*k];let mut presence=0u16;
    for(p,&s)in pins.iter().enumerate(){presence|=1<<s;let d=*c.pin_delay.get(&c.vars[p]).unwrap_or(&0.);arcs[s]=Some(arcs[s].map_or(d,|old|old.max(d)));}
    let key=(ci,k,f,presence,arcs.iter().map(|x|x.map(f32::to_bits)).collect::<Vec<_>>());
    if seen.insert(key){bank.entry((k,f)).or_default().push(Folded{cell:ci,function:f,pins});}
   }}
  }}}}
 }
 bank
}

pub(super)fn generate(boundaries:&[(&Vec<usize>,&Vec<Target>)],tech:&TechLib,ps:&MapParams,aliases:Option<(&[usize],&[bool])>,instances:&mut Vec<Instance>,index:&mut GeneratedInstanceIndex,stream:bool,enabled:bool){
 if !enabled{return}
 let start=Instant::now();let bank=compile(tech);let before=instances.len();let mut offered=0;
 for &(boundary,targets)in boundaries{
  let k=boundary.len();if !(2..=3).contains(&k){continue}
  let functions:BTreeSet<_>=targets.iter().map(|t|t.function).collect();
  for f in functions{let Some(patterns)=bank.get(&(k,f))else{continue};
   for p in patterns{
    let c=&tech.cells[p.cell];let inputs:Vec<_>=p.pins.iter().map(|s|boundary[s/2]*2+(s&1)).collect();
    let matched:Vec<_>=targets.iter().filter(|t|t.function==p.function&&!inputs.contains(&t.signal)).map(|t|t.signal).collect::<BTreeSet<_>>().into_iter().collect();
    if matched.is_empty(){continue}
    let mut m=Instance{cell:c.name.clone(),area:c.area,inputs,input_pins:c.vars.clone().into(),outputs:vec![OutputPin{wide_function:None,name:c.out_pin.clone(),delays:c.vars.iter().map(|n|*c.pin_delay.get(n).unwrap_or(&0.)).collect(),function:c.tt[0],targets:matched,sources:Vec::new()}]};
    if ps.protected_exchange{exchange::record_matches(&mut m,boundary,targets,mask(k),aliases);}
    if let Some((a,free))=aliases{if !normalize_physical_instance(&mut m,a,free){continue}}
    if stream {index.insert(instances,m,ps.protected_exchange);}else{instances.push(m);}offered+=1;
   }
  }
 }
 if let Some(path)=std::env::var_os("EGM_POOL_DIAG_PATH"){
  let patterns:usize=bank.values().map(Vec::len).sum();let _=std::fs::write(std::path::Path::new(&path).with_extension("folded-pins.json"),serde_json::json!({"enabled":true,"patterns":patterns,"offered":offered,"new_instance_entries":instances.len()-before,"new_enodes":0,"new_cut_slots":0,"physical_pin_scope":[4,5],"actual_support_scope":[2,3],"conditional_unions":0,"secs":start.elapsed().as_secs_f64(),"common_retained_cap":ps.max_instances}).to_string());
 }
}

#[cfg(test)]mod tests{
 use super::*;
 #[test]fn compiled_patterns_have_exact_full_support_truth(){
  let root=std::path::Path::new(env!("CARGO_MANIFEST_DIR")).parent().unwrap().parent().unwrap();let lib=TechLib::from_genlib_directed(root.join("asap7_full.genlib")).unwrap();let bank=compile(&lib);assert!(!bank.is_empty());
  for((k,f),ps)in bank{for p in ps{assert_eq!(cofactor(&lib.cells[p.cell],&p.pins,k),f);assert_eq!(p.function,f);assert!(p.pins.iter().all(|&s|s<2*k));}}
 }
 #[test]#[ignore="explicit EGM_FOLDED_PIN_MATCH=1 named-port correctness"]fn folded_pins_are_real_proven_bindings_and_cec(){
  assert_eq!(std::env::var("EGM_FOLDED_PIN_MATCH").as_deref(),Ok("1"));
  let root=std::path::Path::new(env!("CARGO_MANIFEST_DIR")).parent().unwrap().parent().unwrap();let lib=TechLib::from_genlib_directed(root.join("asap7_full.genlib")).unwrap();let out=root.join("folded_unit_cec");std::fs::create_dir_all(&out).unwrap();
  let fixtures=[("xor",2,"aag 5 2 0 1 3\n2\n4\n11\n6 2 5\n8 3 4\n10 7 9\ni0 a[0]\ni1 b[0]\no0 result[0]\nc\n","OA22x2_ASAP7_75t_R"),("xnor",2,"aag 5 2 0 1 3\n2\n4\n10\n6 2 5\n8 3 4\n10 7 9\ni0 a[0]\ni1 b[0]\no0 result[0]\nc\n","AO22x1_ASAP7_75t_R"),("xor_and",3,"aag 7 3 0 1 4\n2\n4\n6\n14\n8 2 5\n10 3 4\n12 9 11\n14 13 6\ni0 a[0]\ni1 b[0]\ni2 c[0]\no0 result[0]\nc\n","OA221x2_ASAP7_75t_R")];
  for(name,n,aag,cell)in fixtures{
   let golden=out.join(format!("{name}.aag"));std::fs::write(&golden,aag).unwrap();let aig=Aig::from_aiger(golden.to_str().unwrap());let ps=MapParams{wide_cells:true,strict_budgets:true,protected_exchange:true,functional_cuts:true,canonical_wire_only:true,canonical_phases:true,multioutput:false,objective:MapObjective::DelayArea,time_limit_secs:0.,..Default::default()};let mut m=map(&aig,&lib,&ps).unwrap();let root_signal=m.outputs[0].0;
   let i=m.instances.iter().position(|v|v.cell==cell&&v.outputs[0].targets.contains(&root_signal)&&v.inputs.iter().map(|s|s/2).collect::<BTreeSet<_>>().len()<v.inputs.len()).expect("non-injective physical binding missing");
   assert!(!m.instances[i].outputs[0].sources.is_empty());let mut free=vec![false;m.chosen.len()];for(s,_,_)in &m.inputs{free[*s]=true;}for(s,c)in m.constants.iter().enumerate(){if c.is_some(){free[s]=true;}}
   m.chosen=finite_choices_queued(&m.instances,&free);m.chosen[root_signal]=Some(Binding{instance:i,pin:0});prune(&m.instances,&mut m.chosen,&free,&[root_signal]).unwrap();let(a,d)=metrics(&m.instances,&m.chosen,&free,&[root_signal]);m.area=a;m.delay=d;
   for assignment in 0..1usize<<n{let values=m.inputs.iter().enumerate().map(|(p,(_,v,_))|(*v,(assignment>>p)&1!=0)).collect();let expected=if name=="xnor"{(assignment&1)==((assignment>>1)&1)}else{((assignment&1)!=((assignment>>1)&1))&&(n==2||(assignment>>2)&1!=0)};assert_eq!(m.evaluate(&values).unwrap(),vec![expected]);}
   let mapped=out.join(format!("{name}.v"));m.write_verilog(std::fs::File::create(&mapped).unwrap(),"mapped").unwrap();assert!(verify_with_models(&lib,&golden,&mapped).unwrap());
  }
 }
}
