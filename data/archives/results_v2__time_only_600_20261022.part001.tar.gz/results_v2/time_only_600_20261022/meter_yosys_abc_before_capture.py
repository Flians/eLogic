#!/usr/bin/env python3
"""Transparent executable shim: unchanged Yosys-selected ABC argv, shared clock."""
import os,signal,subprocess,sys
from nested_mapping_clock import Clock
def main():
    clock=Clock(os.environ['MAPPING_CLOCK_PATH'],os.environ['MAPPING_CLOCK_SECONDS'])
    key=os.environ['MAPPING_CLOCK_CASE'];argv=[os.environ['METER_REAL_YOSYS_ABC'],*sys.argv[1:]]
    token,remaining=clock.begin(key,argv)
    if remaining<=0:return 124
    try:
        p=subprocess.Popen(argv,start_new_session=True)
        try:return p.wait(timeout=remaining)
        except subprocess.TimeoutExpired:
            os.killpg(p.pid,signal.SIGKILL);p.wait();return 124
    finally:clock.end(key,token)
if __name__=='__main__':raise SystemExit(main())
