# eGraphMap 当前比较协议与实验索引

> **当前新实验策略（2026-10-22，用户最新指定）**：仅每设计/方法600秒总映射时间，CEC另计；取消节点/额外搜索比例、候选池/cut数量、迭代和阶段时钟的硬限制。入口 `scripts/experiments/campaigns/run_time_only600.py`，配置 `emapper/EXPERIMENT_POLICY.json`。基线原算法不改。下方300/60/5/20/2秒及rho/100000等均为保留的历史协议，不能静默套用到新策略，也不能把旧baseline数据改称600秒结果。


本文件保留当前可操作信息。完整历史见 [原始实验流水](docs/history/BASELINES-through-20261021.md)；原文与SHA存档，未删掉失败或负结果。

## 评价协议

- EPFL arithmetic/control 全20设计，复用 `results_v2/epfl_resyn2_subjects_20261012/report.json` 的一次 `resyn2` 输入。
- 当前提供的47个单输出单元全部可加载；小 cuts 常规匹配，七个7–9输入单元走定向匹配。不是完整 foundry 库，也不保证穷尽全部宽匹配。
- 同输入、同库、公共物理实例面积与 unloaded block pin delay，独立 named-port CEC。
- 主目标为 `(D,A)` 字典序；`(A,D)` 与 Pareto 检查分开。面积增加不能否定严格延迟改善。
- 映射最多300秒，CEC/适配/预处理/指标排除；原生60秒（EqMap90秒）及作者原搜索参数分别保留，不称端到端 equal compute。
- 本轮统一ρ=1/2，`B=2*(PI+AND)+2`、`G=B+ceil(B/2)`，累计准入不退款；native retained≤100000、完整源覆盖加搜索的全局保留上界B+100000、cut/class≤16、SAT≤16、全局恢复≤2秒。原生地址空间上限16 GiB。
- 定向宽边界不冒充物化 cuts≤16；共用总匹配访问额度、全局保留池和时间。保留上限不等于生成暂存内存上限。

## Baseline 范围

ABC map/map-a、原版独立 emap、EqMap LUT+同库amap及staging controls、E-Syn冻结模型有界适配、E-morphic最终原生SA。原算法/模型/搜索参数不变；未接入MtM。
完整47库集合为120个已尝试任务、260条方法观测：189合格、71失败/未证明/未测。EqMap的T包含明确标注的 enclosing LUT 保守上界；不与精确mapping计时混称。失败不被其他版本或优化探针替换。

| 证据 | 仓库根目录下的位置 |
|---|---|
| Baseline来源、任务与原始失败 | `results_v2/single_output_wide_20261021/primary_baseline120_checkpoint.json` |
| Baseline A/D/T、CEC状态和来源 | `results_v2/single_output_wide_20261021/full_library_baseline_A_D_T/` |
| 原版emap清洁源码及宽度适配 | `results_v2/single_output_wide_20261021/stock_emap9_cut9_reference/` |
| 元数据共享全20首轮 | `results_v2/search_resources_20261021/metadata_epfl/campaign.json` |
| 元数据共享预算核验 | `results_v2/search_resources_20261021/metadata_full20_runtime_audit/validation.json` |
| 排序复用/阶段调度全20首轮 | `results_v2/search_resources_20261021/ranked_epfl/campaign.json` |
| 该版本预算核验与baseline对照 | `results_v2/search_resources_20261021/ranked_full20_runtime_audit/`、`ranked_vs_baseline120_scope/` |
| 最新物理键复用全20（18原生优化覆盖） | `results_v2/search_resources_20261021/small_key_epfl/campaign.json` |

元数据共享版完成20/20，17原生优化覆盖；调度版完成20/20，18原生优化覆盖，div/mem_ctrl正常返回并CEC通过。两版相对上一统一配置的首轮 `(D,A)` 均为9好/11平/0差；不是全套baseline胜出或重复稳定性证明。log2/hyp在调度版仍失败并回退。最新物理键复用版也已完成20/20、18原生优化覆盖、20独立CEC及预算核验；log2/hyp仍为基础覆盖。清理期间未再启动实验，后续从 `cleanup_resume_checkpoint.json` 恢复对照与重复验证。主版本尚未采用这些隔离源码；完整旧版本、负结果、全部指纹保留。

## 整理约定

当前输入、数据、失败、CEC、论文及源码快照不按好坏删除。编译依赖/增量目录属于可再生成缓存；删除或去重须记录清单，并保留被manifest引用的文件及运行中依赖。清理说明见 [WORKSPACE.md](../WORKSPACE.md)。

## 单向库规则独立对照（2026-10-21起，未接入主版本）

研究入口为 `results_v2/library_rules_20261021/README.md`。最新冻结版本 `source_signed` 在有界AIG饱和后执行单向库规则，覆盖恢复/提取代码与当前对照源码相同；支持补出的负相位逻辑类，并修正TT算子补零编码。Cell与Not helper共同预检和计入累计G、独立S；与Boolean阶段共享16轮。三组同二进制、47库、rho=1/2、300秒映射/60秒原生/2秒恢复。小cut算法和16槽上限相同，新增逻辑类仍可能改变实际cut银行；组合组将固定匹配额度分给两条路线，内部计数单位不等同机器操作数。

全20三组60次与五设计30次额外重复均已完成，90最终CEC通过，81次选用原生优化覆盖；其余明确为失败后的基础覆盖，不算原生优化成功。全套实际预算审计通过，所有失败和回退保留。

|相对同二进制控制组|原生覆盖/20|全20 (D,A) 好/平/差|仅D 好/平/差|
|---|---:|---:|---:|
|控制：小cuts＋原定向宽匹配|18|—|—|
|替换：小cuts＋库规则|17|5/3/12|1/14/5|
|组合：小cuts＋两种匹配|16|7/4/9|0/16/4|

五个预定设计sin/sqrt/adder/bar/multiplier的两次额外重复中，替换组10个配对全部差，组合4好/6差。Sqrt、Bar组合组同延迟面积收益可重复，Sin/Multiplier回退也可重复；Adder首轮面积收益在额外重复中翻转。Mem_ctrl首轮唯一严格D改善来自替换组，后验定向重复单独保留于 `signed_mem_ctrl_repeats/`，不冒充全20重复。

- A/D/T、CEC与原生/基础覆盖区分：`signed_full_report/`、`signed_repeats_report/`。
- 实际预算、原生配置及新节点联合计费：`signed_full_budget_audit/`、`signed_repeats_budget_audit/`。
- 全20及未成功baseline的范围保留：`signed_baseline_scope/`，九个lex/Pareto gate均false，baseline算法/模型/参数未改。
- 关键路径和候选覆盖：`signed_coverage/coverage.json`、`signed_key_path_summary.json`。全部60个输出网表的物理关键路径与公共测量复算一致；七个7–9输入单元在40个库阶段均记录0匹配/0新增独立条目。生成计数位于公共截断之前，门型统计不证明同一个原AIG边界或绑定来源。
- 恢复器复用证明：`recovery_reuse_proof.json`；新源码/二进制：`signed-source-freeze.json`、`signed-vs-control.patch`。

以上相对目录均在 `results_v2/library_rules_20261021/`。本次尚无可采用的统一优势，**未合入主版本**，不能按设计混选配置或重复中的最好值。V2严格正相位版与V3复合模式版、最初G-only超S试运行均独立保留；旧编码/相位覆盖限制和负结果不被删除，也不能与V4拼接宣称胜出。

Mem_ctrl后验额外6次现已完成：替换组两次均复现1059.69→1056.51（D约-0.30%），A代价约+0.22%（首轮约+2.41%）；组合两次继续原生超时。该研究当前共96最终CEC、85原生优化覆盖，所有预算和来源核验通过，三个campaign及全局锁均空闲，未接入主版本。最终完整报告为 `results_v2/library_rules_20261021/signed_final_report.md`。


## 紧凑表示与互补引脚匹配审计（2026-10-22，研究版未合入）

证据目录 `results_v2/critical_compact_20261022/`。sqrt/voter/multiplier 的基线关键路径抽样通过 SAT 证明边界对应，再区分生成、保留和选中阶段。sqrt 55个抽样中14个尚无完整已证class边界；voter27和multiplier40均有完整对应。发现非一一引脚匹配缺口：4/5个物理引脚使用2/3个逻辑变量及其互补相位。

同二进制全EPFL三组60/60完成、60最终独立CEC、全部实际预算核验通过。profile0为旧控制；1仅抑制不可能获胜的同目标已就绪队列事件；3在1上增加精确互补引脚匹配。三组原生优化覆盖17/18/16，其余均为基础覆盖。所有baseline原算法保持，主源码未改。相关242测试通过/6跳过/16过滤；另有2个显式匹配测试及3个独立CEC。

profile3相对1首轮：sqrt D50815.83→50399.33、voter738.17→623.21、multiplier2726.51→2625.62，均有面积代价；sin1736.24→1707.86且面积下降。Bar同D面积+2.49；Div、Mem_ctrl新增匹配组原生超时，log2/hyp三组仍基础覆盖。不能按design混选，不能据正例合入。重复计划尚未执行：完整配置已出现合入否决项，且用户随后要求重新评估方法探索阶段的硬限制；不把首轮改善说成重复稳定收益。

新匹配不增加enodes/cut槽，但sqrt生成暂存新增约110万实例，100000 retained cap不代表生成内存上限。Log2旧队列在5秒frontier子限额失败，新队列已越过该步骤但仍触及60秒native限时；Hyp停在原有生成阶段，新增匹配尚未执行。后续宽松诊断与此冻结同预算证据分开，先区分资源截断与结构/匹配缺失，不能把人为窗口当成理论限制。

全套数据和原生/基础覆盖：`full_validation/`；baseline全范围与失败：`baseline_scope/`，各gate仍false；实际来源和说明：`source_freeze.json`、`configuration_erratum.json`、`README.md`。原版本BASELINES原字节已存`BASELINES.before.md`并记录旧manifest哈希。文稿与主版本不据这一轮未重复且有回退的配置更新为最终方案。

## 仅600秒资源策略接入验证

证据 `results_v2/time_only_600_20261022/validation.json`。245相关测试通过、6跳过、16过滤；三个真实进程测试覆盖总时钟传播、子进程组清理、超时源覆盖及日志保护。最终EPFL dec验证原生优化/独立named-port CEC成功，实际保留446760候选、cuts/class21，超过旧100000/16上限，证明非仅文档改名。600秒包括源覆盖构造、导入/饱和/匹配/恢复/导出，各阶段不能重新领取600秒；不再设置16GiB地址空间限制。数量与实际内存仍记录。

当前为新资源执行入口，不冒充主算法PPA合入。小cuts K6、库驱动7–9输入定向匹配、原有规则/匹配族和正确性检查仍是算法选择，不代表穷尽搜索。新600秒全EPFL与baseline对照尚未完成；旧结果完整保留。文稿不能用此单设计策略验证替换主表。

600秒正式新矩阵 `results_v2/time_only_600_20261022/epfl_checkpoint/campaign.json` 已完成首个有限批次1/20（adder原生优化及独立CEC成功），源/库/输入/计时harness均冻结。实际候选108208、cuts/class297、恢复约3.36秒，均已超过旧限制；A87.06/D2569.15、映射约9.20秒。仍未完成全20或重复验证，无后台活跃进程。进度证据 `epfl_progress.json`，不得将单例改善称整体优势。
