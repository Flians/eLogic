#600秒完整范围检查

{
  "candidate_completed": 10,
  "candidate_expected": 20,
  "candidate_optimized": 3,
  "candidate_verified_outputs": 10,
  "candidate_statuses": {
    "mapping_timeout": 7,
    "ok": 3,
    "pending600": 10
  },
  "baseline_completed_groups": 69,
  "baseline_expected_groups": 120,
  "baseline_qualified_observations": 182,
  "baseline_statuses": {
    "ok": 182,
    "pending600": 78
  },
  "gates": {
    "delay-area": false,
    "area-delay": false,
    "pareto": false
  },
  "unconnected_tools": [
    "MtM"
  ],
  "all_failures_retained": true,
  "interpretation": "600s is a changed resource protocol. Adopted completed observations retain their original stricter policy and time/upper-bound labels. Source-only CEC is not optimized coverage. Lexicographic wins are not Pareto dominance."
}

|设计|状态|优化覆盖返回|面积|延迟|映射秒|CEC|
|---|---|---|---:|---:|---:|---:|
|adder|ok|True|87.06000077724457|2569.1499977111816|9.2044287440076|1|
|bar|ok|True|262.7700018361211|168.2899990081787|12.657033625990152|1|
|div|mapping_timeout|False|4154.880134962499|99097.35843467712|600.1059006899886|1|
|hyp|mapping_timeout|False|22414.780679889023|667115.2042598724|600.0292925280228|1|
|log2|mapping_timeout|False|2919.34009886533|9710.569911956787|600.104309938004|1|
|max|ok|True|209.68000053614378|2074.5800037384033|60.9915932790027|1|
|multiplier|mapping_timeout|False|2502.8000812754035|5925.149908065796|600.104644549021|1|
|sin|mapping_timeout|False|503.5900169014931|4772.1899700164795|600.1036523859948|1|
|sqrt|mapping_timeout|False|1955.33006490767|126168.74898910522|600.104332406976|1|
|square|mapping_timeout|False|1785.3900529816747|5582.399908065796|600.0287740270142|1|
|arbiter|pending600||||||
|cavlc|pending600||||||
|ctrl|pending600||||||
|dec|pending600||||||
|i2c|pending600||||||
|int2float|pending600||||||
|mem_ctrl|pending600||||||
|priority|pending600||||||
|router|pending600||||||
|voter|pending600||||||
