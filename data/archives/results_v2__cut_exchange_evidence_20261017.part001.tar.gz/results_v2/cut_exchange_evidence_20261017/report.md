# Guarded cut exchange and source propagation

The new guard is **not promoted**. It removes the observed equal-delay area loss against the archived main reference in all34 common valid library/design combinations, but fails to preserve V19 timing. Complete physical-cover preservation is still not implemented by this local guard.

| Independent study | Physical attempts | Public named-port CEC | Delay better / tie / worse | Area better / tie / worse |
|---|---:|---:|---:|---:|
| V21 scalar guard pilot |12|12|0 /4 /2|3 /2 /1|
| V23 two-phase guard, full EPFL20×2 inventories×2 profiles |80|68|1 /26 /7|8 /17 /9|
| V23 fresh reverse-order i2c/bar/sin/sqrt repetition |16|16|0 /6 /2|4 /3 /1|
| V22 independent source propagation |16|4|Two priority pairs unchanged; twelve node rejections|Not a coverage gain|

V23 full80 explicitly adopts12 identical-source pilot observations, counted once. Total124 unique physical attempts,100 CEC passes,24 actual node-budget failures across independent sources. The targeted repetition is not full-suite replication or statistical proof. No per-design source/configuration winners or combined-version mapper are reported.

## Area protection versus delay preservation

V23 versus V19 control: K4i2c77.42→74.55 at fixed165.79 delay; K4bar195.42→193.24 at fixed159.37. However K4sin580.11/1793.92→592.86/1815.58. Both sin inventory delay losses repeat. Full scope also retains six equal-delay area increases versus V19: K4cavlc/ctrl/int2float/router and K3sqrt/arbiter. Against canonical main8f6 protected_area, the34 common valid cases give22 delay improvements and12 ties; area7better10ties17worse, all17 costs occurring with lower delay. This empirical main comparison does not prove a complete incumbent-preservation invariant or preserve the stronger V19 delay results.

Read-only boundary audit reconstructs55 old i2c selected-output cut keys present in the old banks but absent in V19 new banks. V23 restores53, not all55; cut membership is not proof of retained physical-instance availability. All old sqrt selected cut keys were already represented in both original banks. V23sin generated and retained pool minimum-delay certificates both pass, with loss already before100k truncation. The guard can override prior cut-diversity selection by returning a raw legacy prefix, so this study does not isolate phase-only causality. Local per-phase labels are ranking heuristics, not whole-cover timing/area certificates.

## Exact source propagation

V22 from V17 is independent of V23. An exact topological signed structural pass after bounded ROBDD aliases removes16 additional div raw ANDs,40651→40635. The existing selected-source estimate changes20373→20366(K4),20545→20537(K3). Actual imports still stop at20000; hyp and mem_ctrl unchanged. Counts are representation estimates, not minimum bounds, complete imported covers or mapped PPA. Three prepared-input source CEC checks and four positive/negative calibrations pass, matching both libraries' native proof counters. These7source checks are separate from the100physical CEC passes and are never supplied back to the mapper as cached advice.

## Scope and limits

Same original once-resyn2 EPFL20 inputs, same two restricted ASAP7 inventories, public unique physical-instance area and unloaded dependent-pin delay. Actual cumulative20keNodes/cuts16/retained physical100k/SAT16/inclusive recovery2s(including mandatory setup/final validation/.05reserve)/native60/mapping300 unchanged. Generated transient ranking/proof state is not a RAM-cap or free hidden-function claim. Baselines retain original algorithms/models/native parameters and old process guards. The original240groups/520slots/372CEC/124reported failures/24unmeasured remain; fresh4common-binary hashes match the old frozen checkpoint, while the prior13403-file full audit is referenced, not rerun. All6 full20 DA/AD-posthoc/Pareto gates false; AD is posthoc, not an AD-optimized result. MtM not connected.

## Next implementation

Protect all physical bindings, shared inputs, output phases and joint pins of a complete validated incumbent before live cut/instance eviction. Preserve the complete diversity policy and reject conflicting exchanges within the same16cut/100kpool cap and single inclusive2s deadline. Do not run two independent2s recoveries or cache a free second full admitted bank. Source selection next needs bounded existing-choice dependency-closure proposals within the existing16trial allowance; no increased proof/native/node budgets. Both proposals remain unimplemented and require CEC/fullscope/repetition before adoption.

Machine-readable rows, paired outcomes, command/provenance audits, gates and reference hashes: qualification.json, all_rows.json, main_pairs.json, full_validation.json, repeat_validation.json and source_validation.json. Frozen Rust/Cargo/binaries/patches/RED/GREEN commands under *_implementation_20261017. Main/defaults/native8f6 and primary paper tables unchanged; failed and adverse cases preserved.
