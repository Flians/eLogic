from pathlib import Path
import shutil
r=Path('/home/flynn/workplace/MIGBalance');o=r/'results_v2/epoch_main_paper_20261015';p=r/'epmapping_paper/DAC-eGraphMap-draft/main.tex';shutil.copy2(p,o/'rejected_eight_pages.tex');shutil.copy2(o/'main.pdf',o/'rejected_eight_pages.pdf');s=p.read_text()
a=s.index('Solving a large candidate formulation');b=s.index('\\section{',a)
print('Recovery old',len(s[a:b].split()))
s=s[:a]+r'''A validated finite witness initializes recovery. A dependency frontier
releases producers with available inputs, retaining dependent-pin arcs
and an acyclic cover. Required-time DAG area flow supplies a sharing
proxy under the validated delay bound. Complete-cover physical metrics,
not proxy costs, govern acceptance.

New seeds can abandon shared-area choices. We therefore preserve the
old cold seeds, ties, witness and structural-reference trajectory while
saving frontier/DAG covers separately until final comparison. Seed work
uses a quarter of the remaining window with nonpreemptive checks;
phase/local/cone recovery shares the global deadline. Per-cover epochs
invalidate reusable arrival labels, preserving instance-ID area summation
and pin-delay arithmetic without increasing trial limits.

References track selected pins, aliases and unique physical inputs.
A shared instance becomes reclaimable only after all users die; replacing
one full-adder output cannot reclaim the entire cell. Pin and joint-pin
trials are supported. Invalid or expired alternatives retain a validated
incumbent. Solver timeout returns a checked heuristic cover only when it
satisfies any requested hard delay bound; no unrestricted optimum is
claimed.

'''+s[b:]
a=s.index('\\section{Discussion and Conclusion}');b=s.index('\\clearpage',a)
print('Discussion old',len(s[a:b].split()))
s=s[:a]+r'''\section{Discussion and Conclusion}
Deferring new seeds alone did not eliminate regressions; preserved
legacy seeds still regressed on four-input adder in two repetitions.
Metric epochs recovered work within the same deadline. Read-only
cut-name memoization and producer indexing preserve ordered diagnostics
and avoid observed diagnostic timeouts, without a runtime superiority
claim.

Thirty-two additional main-binary runs alternate profile order. Including
sixteen full-study observations yields 48 direct CEC passes and 24 pairs:
six lower delays, eighteen ties, twelve area gains and twelve ties.
Adder, priority and int2float retain area; all six sqrt pairs improve
delay. Sqrt delays 68523.99/66924.64 remain above conventional mapping.
Four-input adder area ranges 83.75--83.88; no best repeat is selected.
Few repeats establish neither statistical confidence nor independence
from system load. A protected discovered cover cannot guarantee a
separate legacy run's result under every deadline schedule.

All six full-scope baseline gates remain false. Original baseline
algorithms/models/parameters are unchanged; 13,403 dependency files show
zero drift. Separating assignments distinguish over 20,000 original
functions up to complementation in remaining large designs, excluding
retention of every scalar function, not smaller covers or representations.
Resident retirement does not repair cumulative imports; multiplier's
55,628 nodes remain ineligible. Industrial multi-output, ODC and regional
saturation remain unassessed; timing omits load, slew and interconnect.

'''+s[b:]
s=s.replace('AIG. An additional composed proof through the fixed resyn2 network was\naudited for resource-only verification timeouts; all eight eligible\nbaseline supplements failed, preserving their original failure status.\nNeither fresh main matrix required this supplementary policy.', 'AIG. Composed verification through fixed resyn2 was audited for resource\ntimeouts: eight baseline supplements failed, preserving their original\nstatus. Both fresh main matrices use direct CEC throughout.')
p.write_text(s)
