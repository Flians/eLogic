import json,hashlib,shutil,csv,re
from pathlib import Path
r=Path('/home/flynn/workplace/MIGBalance');o=r/'results_v2/epoch_main_paper_20261015';o.mkdir(exist_ok=False);p=r/'epmapping_paper/DAC-eGraphMap-draft/main.tex';shutil.copy2(p,o/'before.tex');shutil.copy2(r/'output/pdf/DAC-eGraphMap-draft.pdf',o/'before.pdf');s=p.read_text()
s=s.replace('The bounded capacity profile produces 30 verified covers across 40\ncircuit/library cases; five designs still exceed its node allowance.\nCompared with the preceding capacity profile, two of 30 legal pairs\nimprove delay and 28 tie; area improves in seven, ties in twenty and\nincreases in three.', 'The protected-incumbent profile produces 30 verified covers across 40\ncircuit/library cases; five designs still exceed its node allowance.\nAgainst same-binary legacy recovery, two of 30 legal pairs improve\ndelay and 28 tie; area improves in twenty and ties in ten. Targeted\nalternating-order repetitions retain these nonregression results.')
s=s.replace('A validated finite\nwitness supplies an initial implementation; tree and area-flow seeds offer\nalternative starting points.', 'A validated finite\nwitness supplies an initial implementation; tree and area-flow seeds offer\nalternative starting points. A dependency frontier releases a physical\nproducer when all unique inputs are available, retaining dependent-pin\narcs and an acyclic witness. Required-time DAG area flow derives a\nsharing-aware alternative under the validated delay bound. Neither proxy\ncost nor frontier order establishes a global optimum.')
s=s.replace('A later seed can use fanouts of\nthe current physical graph rather than the original graph. In the present\nsmall experiments that extra seed alone gave no measurable benefit.', 'The old cold seeds, tie choices and shared-area working cover remain\nseparate from the frontier/DAG alternatives. Their commitment is deferred\nuntil final complete-cover comparison, leaving phase/local/cone recovery\na legacy trajectory. Seed setup uses at most a quarter of the remaining\nwindow, with nonpreemptive checks. Per-cover epochs invalidate reusable\narrival labels while preserving physical-ID area summation. This reduces\nmetric overhead without enlarging configured trial or time limits.')
s=s.replace('CBC is disabled. Tables use all 40 fresh root-release candidate runs\nwith structural capacity selection enabled. Controls are the archived\npreceding capacity version, verified against original source and binary\nhashes; no per-design profile selection is made.', 'CBC is disabled. Tables use one fixed protected-incumbent main-release\nprofile for all 40 cases. A fresh 80-attempt matrix pairs it with legacy\nrecovery under the same binary, candidate pool and budget. Frontier/DAG\nincumbents, legacy seeds and epoch metrics are explicit options; defaults\nremain unchanged. No per-design profile selection is made.')
s=s.replace('Every numeric record passes named-port CEC against the original AIG.', 'Every tabulated numeric record passes named-port CEC against the original\nAIG. An additional composed proof through the fixed resyn2 network was\naudited for resource-only verification timeouts; all eight eligible\nbaseline supplements failed, preserving their original failure status.\nNeither fresh main matrix required this supplementary policy.')
# Replace only the final eGraphMap table cell; baseline columns must remain byte-identical.
rows=json.load(open(r/'results_v2/epoch_report_main_full_certified_20261015/all_rows.json'));cand={(z['k'],z['bench']):z for z in rows if z['profile']=='protected_area'}
start=s.index('% BEGIN EPFL COMPLETE TABLES');end=s.index('% END EPFL COMPLETE TABLES');block=s[start:end];before=block;table=0;new=[];provenance=[]
for line in block.splitlines(True):
 if line.startswith('\\caption{EPFL '):table+=1
 if re.match(r'^[a-z][a-z0-9\\_]* & ',line):
  cells=line.rstrip().removesuffix('\\\\').rstrip().split(' & ');bench=cells[0].replace('\\_','_');k=3 if table<=2 else 4;metric='area' if table in [1,3] else 'delay';item=cand[(k,bench)];row=item['row'];value=f"{row['measured'][metric]:.2f}" if row['status']=='ok' else 'N';old=cells[:-1];cells[-1]=value;line=' & '.join(cells)+' \\\\\n';assert cells[:-1]==old;provenance.append(dict(k=k,bench=bench,metric=metric,value=value,report=item['report'],report_sha256=item['report_sha256']))
 new.append(line)
assert table==4 and len(provenance)==80
updated=''.join(new)
# Check old baseline content after removing only eGraphMap cells.
def baseline_columns(t):
 return [x.rsplit(' & ',1)[0] for x in t.splitlines() if re.match(r'^[a-z][a-z0-9\\_]* & ',x)]
assert baseline_columns(before)==baseline_columns(updated)
s=s[:start]+updated+s[end:]
a=s.index('The main full comparison yields');b=s.index('Four-input sqrt cut replay',a)
s=s[:a]+'''The protected-incumbent full matrix has 60 direct CEC passes and twenty
node rejections. Thirty legal pairs have two lower delays, 28 ties,
twenty area gains and ten ties, with no regressions. Actual node, cut,
pool and recovery limits pass; paired pool fingerprints agree.
Deadline checks cannot preempt individual trials.
'''+s[b:]
a=s.index('\\section{Discussion and Conclusion}');b=s.index('\\clearpage',a)
s=s[:a]+r'''\section{Discussion and Conclusion}
Early commitment to a new seed can abandon useful shared-area choices.
Deferring commitment alone did not remove all regressions; restoring
legacy seeds still regressed on four-input adder in two repetitions.
Per-cover metric epochs recovered work within the same deadline.
Post-extraction cut-name memoization and producer indexing preserve
ordered diagnostics and avoid observed diagnostic timeouts; they are
not a mapping-runtime superiority claim.

A separate main-binary study adds 32 fresh targeted runs, alternating
profile order. Including sixteen full-study observations gives 48 direct
CEC passes and 24 legal pairs: six lower delays, eighteen ties, twelve
area gains and twelve ties. Adder, priority and int2float have no area
regression; all six sqrt pairs improve delay. Sqrt candidate delays are
68523.99/66924.64 in the two inventories, still above conventional
mapping. Four-input adder area ranges 83.75--83.88; no best repeat is
selected. Few repeats do not establish statistical confidence or
independence from system load.

Protecting a discovered cover does not guarantee the result of an
independent legacy run under every deadline schedule. All six full-scope
baseline gates remain false. Original baseline algorithms, models and
parameters are unchanged; 13,403 dependency files show zero drift.
Exact separating assignments distinguish over 20,000 original functions
up to complementation in remaining large designs. This excludes keeping
every original scalar function, not smaller covers or other
representations. Regional retirement cannot substitute resident peak for
cumulative imports: multiplier's 55,628 nodes remain ineligible.
Industrial multi-output, ODC and independent regional saturation remain
unassessed; timing excludes load, slew and interconnect.

'''+s[b:]
p.write_text(s);shutil.copy2(p,o/'final.tex')
sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest()
(o/'table_provenance.json').write_text(json.dumps(dict(source_campaign='results_v2/epoch_report_main_full_20261015/campaign.json',source_campaign_sha256=sha(r/'results_v2/epoch_report_main_full_20261015/campaign.json'),baseline_columns_unchanged=True,fixed_profile='protected_area',no_repeat_best=True,cells=provenance),indent=2)+'\n')
with (o/'epfl_candidate_table.csv').open('w') as f:
 w=csv.DictWriter(f,fieldnames=provenance[0]);w.writeheader();w.writerows(provenance)
print('Updated 80 metric/status cells; baseline table columns unchanged')
