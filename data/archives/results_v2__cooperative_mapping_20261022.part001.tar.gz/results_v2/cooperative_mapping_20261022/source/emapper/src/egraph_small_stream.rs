//! Persistent ordinary-match traversal. One operation is one variant or phase
//! assignment, including rejected assignments. Quantum exhaustion never drops work.
use super::*;
type Seen = HashSet<(String,Vec<String>,u16)>;
pub(super) struct Cursor {
 boundaries:Vec<(Vec<usize>,Vec<Target>)>, cells:Vec<usize>, multi:HashSet<String>,
 b:usize,t:usize,v:usize,seen:Seen,stage:u8,inv:usize,constant:usize,
 dc_b:usize,dc_c:usize,sel:usize,perm:usize,phase:usize,
 selections:Vec<Vec<usize>>,perms:Vec<Vec<usize>>,care:Option<u64>,
 physical:HashMap<(String,String,Vec<String>),u64>,
 pub operations:usize,pub yields:usize,
}
pub(super) struct Batch {pub matches:Vec<Instance>,pub done:bool,pub operations:usize}
impl Cursor {
 pub fn new(cuts:&[BTreeSet<Cut>],free:&[bool],tech:&TechLib,ps:&MapParams,stats:&mut MapStats)->Self{
  assert!(!ps.multioutput,"ordinary cursor currently has single-output semantics");
  let mut bank:BTreeMap<Vec<usize>,Vec<Target>>=BTreeMap::new();
  for(c,cs)in cuts.iter().enumerate(){for cut in cs {if cut.leaves==[c]{continue}for p in 0..2 {if !free[c*2+p]{bank.entry(cut.leaves.clone()).or_default().push(Target{signal:c*2+p,function:cut.function^if p==1{mask(cut.leaves.len())}else{0}})}}}}
  let boundaries=regions::ordered_boundaries(&bank,cuts.len(),ps.region_classes,stats).iter().map(|(b,t)|((*b).clone(),(*t).clone())).collect();
  let mut count:BTreeMap<String,usize>=BTreeMap::new();for c in &tech.cells{*count.entry(c.name.clone()).or_default()+=1;}
  let multi=count.into_iter().filter(|(_,n)|*n>1).map(|(s,_)|s).collect::<HashSet<_>>();
  let mut cells=(0..tech.cells.len()).filter(|&i|!multi.contains(&tech.cells[i].name)).collect::<Vec<_>>();cells.sort_by(|&a,&b|tech.cells[a].name.cmp(&tech.cells[b].name));
  Self{boundaries,cells,multi,b:0,t:0,v:0,seen:Default::default(),stage:0,inv:0,constant:0,dc_b:0,dc_c:0,sel:0,perm:0,phase:0,selections:vec![],perms:vec![],care:None,physical:HashMap::new(),operations:0,yields:0}
 }
 fn record(mut m:Instance,boundary:&[usize],targets:&[Target],care:u64,aliases:Option<(&[usize],&[bool])>,ps:&MapParams)->Option<Instance>{
  if ps.protected_exchange{exchange::record_matches(&mut m,boundary,targets,care,aliases);}
  if let Some((a,f))=aliases{if !normalize_physical_instance(&mut m,a,f){return None}}Some(m)
 }
 pub fn done(&self)->bool{self.stage==4}
 pub fn resume(&mut self,cuts:&[BTreeSet<Cut>],free:&[bool],constants:&[Option<bool>],tech:&TechLib,ps:&MapParams,reach:&mut Reachability,stats:&mut MapStats,aliases:Option<(&[usize],&[bool])>,quantum:usize,end:Instant)->Batch{
  let mut out=Vec::new();let initial=self.operations;
  while self.operations-initial<quantum && !self.done() && Instant::now()<end {
   self.operations+=1;
   match self.stage {
    0=>{
     if self.b==self.boundaries.len(){self.stage=1;continue}
     let(b,ts)=&self.boundaries[self.b];let k=b.len();
     if k==0||self.t==ts.len(){self.b+=1;self.t=0;self.v=0;self.seen.clear();continue}
     let vs=tech.candidates(k as u8,tt9_from_u64(ts[self.t].function)).unwrap_or(&[]);
     if self.v==vs.len(){self.t+=1;self.v=0;continue}
     let v=&vs[self.v];self.v+=1;
     if v.out_neg||self.multi.contains(&v.cell_name){continue}
     if !self.seen.insert((v.cell_name.clone(),v.pin_names.clone(),v.neg_mask)){continue}
     let cell=tech.cells.iter().find(|c|c.name==v.cell_name&&c.out_pin==v.out_pin).unwrap();
     if !admit_input_assignment(v.neg_mask as usize,&v.pin_names,&cell.vars,ps){continue}
     let physical=*self.physical.entry((cell.name.clone(),cell.out_pin.clone(),v.pin_names.clone())).or_insert_with(||physical_function(cell,&v.pin_names));let actual=input_phase(physical,k,v.neg_mask as usize);
     let inputs=b.iter().enumerate().map(|(i,c)|c*2+usize::from((v.neg_mask>>i)&1)).collect::<Vec<_>>();
     let matched=ts.iter().filter(|t|t.function==actual&&!inputs.contains(&t.signal)).map(|t|t.signal).collect::<BTreeSet<_>>().into_iter().collect::<Vec<_>>();
     if matched.is_empty(){continue}
     let m=Instance{cell:v.cell_name.clone(),area:v.area,inputs,input_pins:v.pin_names.clone().into(),outputs:vec![OutputPin{wide_function:None,sources:vec![],name:v.out_pin.clone(),delays:v.pin_delay.clone().into(),function:physical,targets:matched}]};
     if let Some(m)=Self::record(m,b,ts,mask(k),aliases,ps){out.push(m)}
    },
    1=>{
     if self.inv==cuts.len()*2{self.stage=2;continue}
     let s=self.inv;self.inv+=1;if free[s]||cuts[s/2].is_empty(){continue}
     let Some(v)=&tech.inv_variant else{continue};
     let mut m=Instance{cell:v.cell_name.clone(),area:v.area,inputs:vec![s^1],input_pins:v.pin_names.clone().into(),outputs:vec![OutputPin{wide_function:None,sources:vec![],name:v.out_pin.clone(),delays:v.pin_delay.clone().into(),function:1,targets:vec![s]}]};
     if ps.protected_exchange{exchange::record_inverter(&mut m,aliases);}
     if let Some((a,f))=aliases{if !normalize_physical_instance(&mut m,a,f){continue}}out.push(m);
    },
    2=>{
     if self.constant==tech.cells.len(){self.stage=3;continue}
     let c=&tech.cells[self.constant];self.constant+=1;if !c.vars.is_empty()||self.multi.contains(&c.name){continue}
     let value=c.tt[0]&1!=0;let targets=cuts.iter().enumerate().flat_map(|(i,cs)|(0..2).filter_map(move|p|if !free[i*2+p]&&constants[i*2+p].is_none()&&cs.iter().any(|x|x.leaves.is_empty()&&((x.function&1!=0)^(p==1))==value){Some(i*2+p)}else{None})).collect::<Vec<_>>();
     let ts=targets.iter().map(|&signal|Target{signal,function:u64::from(value)}).collect::<Vec<_>>();
     let m=Instance{cell:c.name.clone(),area:c.area,inputs:vec![],input_pins:vec![].into(),outputs:vec![OutputPin{wide_function:None,sources:vec![],name:c.out_pin.clone(),delays:vec![].into(),function:u64::from(value),targets}]};
     if let Some(m)=Self::record(m,&[],&ts,1,aliases,ps){out.push(m)}
    },
    3=>{
     if self.dc_b==self.boundaries.len(){self.stage=4;continue}
     let(b,ts)=&self.boundaries[self.dc_b];let k=b.len();
     if k==0{self.dc_b+=1;continue}
     let care=*self.care.get_or_insert_with(||reach.care(b,ps,stats));
     if care==mask(k)||self.dc_c==self.cells.len(){self.dc_b+=1;self.dc_c=0;self.care=None;self.selections.clear();self.perms.clear();continue}
     let c=&tech.cells[self.cells[self.dc_c]];let n=c.vars.len();
     if n>k{self.dc_c+=1;continue}
     if self.selections.is_empty(){self.selections=subsets(k,n);self.perms=permutations(n);self.sel=0;self.perm=0;self.phase=0;}
     if self.sel==self.selections.len(){self.dc_c+=1;self.selections.clear();continue}
     if self.perm==self.perms.len(){self.sel+=1;self.perm=0;self.phase=0;continue}
     if self.phase==1usize<<n{self.perm+=1;self.phase=0;continue}
     let phase=self.phase;self.phase+=1;let selected=self.selections[self.sel].iter().map(|&i|b[i]).collect::<Vec<_>>();
     let pins=self.perms[self.perm].iter().map(|&i|c.vars[i].clone()).collect::<Vec<_>>();
     if !admit_input_assignment(phase,&pins,&c.vars,ps){continue}
     let physical=*self.physical.entry((c.name.clone(),c.out_pin.clone(),pins.clone())).or_insert_with(||physical_function(c,&pins));let actual=expand(input_phase(physical,n,phase),&selected,b);
     let inputs=selected.iter().enumerate().map(|(i,c)|c*2+((phase>>i)&1)).collect::<Vec<_>>();let mut matched=targets_for(actual,ts,care,stats);matched.retain(|s|!inputs.contains(s));if matched.is_empty(){continue}
     let m=Instance{cell:c.name.clone(),area:c.area,inputs,input_pins:pins.clone().into(),outputs:vec![OutputPin{wide_function:None,sources:vec![],name:c.out_pin.clone(),delays:pins.iter().map(|p|c.pin_delay.get(p).copied().unwrap_or(0.)).collect::<Vec<_>>().into(),function:physical,targets:matched}]};
     if let Some(m)=Self::record(m,b,ts,care,aliases,ps){out.push(m)}
    },_=>unreachable!(),
   }
  }
  if !self.done(){self.yields+=1;}
  Batch{matches:out,done:self.done(),operations:self.operations-initial}
 }
}
