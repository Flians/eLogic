# Cooperative v2 with independent batch predecessor: limited-scope evidence

Same binary and library, one600s mapping clock; independent CEC outside clock. No baseline algorithm changes.

|Design|Control A/D/T|Small cursor A/D/T|Dirty delay A/D/T|Combined A/D/T|
|---|---|---|---|---|
|adder|87.10/2569.15/14.88|87.10/2569.15/30.98|87.10/2569.15/15.37|87.10/2569.15/25.92|
|bar|248.36/168.29/29.96|248.21/168.29/75.91|247.27/168.29/18.70|248.36/168.29/27.27|

Unique designs: 2; independentCEC outputs: 14. Repeats: {'adder': {'runs': 3, 'identical_AD': True}, 'bar': {'runs': 3, 'identical_AD': True}}.

Cursor setup/care/individual target collection and whole-cover validation remain nonpreemptive operations. Delay labels use conservative readiness including all physical inputs; a finite acyclic witness is checked before a cover can be committed. The batch frontier predecessor runs once per delta; this is not a completely scan-free mapper. Physical matches remain eager; general lazy materialization and full area-flow scheduling are unfinished. All failed, timed-out, regressed and missing cases remain in all_scope.csv. No main adoption or full-suite advantage claim.

|Design|Batch archive off A/D|Batch archive on A/D|
|---|---|---|
|adder|87.10/2569.15|87.10/2569.15|
|bar|248.73/168.29|248.36/168.29|
