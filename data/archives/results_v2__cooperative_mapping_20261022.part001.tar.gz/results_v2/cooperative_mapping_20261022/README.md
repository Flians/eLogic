# Cooperative ordinary matching and incremental delay (isolated)

Parent: streaming_mapping_20261022/source_protected. No main native or baseline algorithm modification.

`source/` is frozen; `source-freeze.json` preserves native, Rust and runner hashes. Editable precursor lives in `/tmp/emapper-cooperative600-20261022`; changes there require a new version/matrix, never an in-place cohort mutation.

One600-second total mapping-related search window, independentCEC excluded. No node/cut/pool/iteration/stage caps. Cursor operations and delay queue quanta only yield; remaining work survives. Small cursor handles exact variants, phases, physical pin permutations, inverters, constants, conditional SDC matches. Single-output scope; existing folded-pin path is inactive under the same inherited deadline-bearing generator policy. No new optional matching family is silently added.

The dirty delay worklist indexes append-only instances and merged target bindings, propagates to affected consumers and explicitly rejects zero-delay selected cycles. It retains an independent complete batch frontier path once per delta. Conservative readiness follows all physical input signals. Labels alone are not a complete-cover proof. All committed outputs pass driver/cycle/cut-care-phase-pin checks and independent final named-portCEC.

Status: implementation/test phase complete; full20, factorial ablations, repeats and original baseline completion in progress. No general deferred physical materialization or fully resumable area-flow yet. Main/paper adoption requires full evidence, not positive first2 results.


Latest verified generation: V6 (`source_v6`, `source-v6-freeze.json`, `run_cooperative_metric600.py`). Results before the current finite continuation: `v6_progress/`, canonical12/20, full gates false. V1–V5 are frozen historical experiments, including negative results; do not select their best individual designs as one mapper.

V6 includes scoped online metric workspace and an optional nonpreemptive full legacy shared-extractor tail. First2 binary2x2 controls plus candidate3-run repetitions are complete. Bar improves equal-delay area248.36→248.25 at a large runtime cost. Log2 remains a600-second search timeout with a CEC-passing optimized incumbent, D4010.95, worse than the independent old online D3852.82. Max/arbiter remain equal-delay area regressions against the old full-flow reference. No main/paper adoption.

The canonical remaining eight designs are div, hyp, multiplier, sin, sqrt, square, mem_ctrl and voter. Consult live campaign.json and runner.lock before continuing; a finite --max-jobs batch may be running. Never overwrite partial directories. All matching-related search shares600seconds; CEC is excluded. Resource count caps remain absent. Fully resumable whole-area flow and general deferred physical materialization are unfinished.


Latest completed finite study: V9 `v9_progress/`, control/candidate3/20 each,6CEC outputs across3 designs. Adder A/D equal; div equal-D area+0.20; log2 improves pairedD4009.14→3989.77 but remains below stronger historical references. No full-suite/repeat/main-adoption claim. Original baseline snapshot43/120 groups:106qualified,11failed,143pending observations. Guard-triggered E-Syn/div is an input-adapter rejection, not native timeout.

User source policy now forbids any sourced baseline code changes. Tools repositories and final naming are in `tools/BASELINES.md` and `tools/baselines.lock.json`; reuse existing tools/mockturtle, do not recreate a duplicate. Old patched E-Syn evidence remains historical. Input-capacity modification was not implemented. All finite sessions have ended.
