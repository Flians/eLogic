//! Explicit anytime prototype: match newly admitted cuts and commit complete covers.
//! No archived netlists, count caps, per-round time renewals, or conditional unions.
use super::*;
use std::path::PathBuf;
#[cfg(test)] thread_local!{static TEST_ENABLED:std::cell::Cell<bool>=const{std::cell::Cell::new(false)};static TEST_STREAM:std::cell::Cell<bool>=const{std::cell::Cell::new(false)};static TEST_SCHEDULE:std::cell::Cell<bool>=const{std::cell::Cell::new(false)};static TEST_SMALL:std::cell::Cell<bool>=const{std::cell::Cell::new(false)};static TEST_FLOW:std::cell::Cell<bool>=const{std::cell::Cell::new(false)};}
pub(super) fn enabled()->bool {
 #[cfg(test)] if TEST_ENABLED.with(|x|x.get()){return true}
 std::env::var("EGM_ONLINE_MAPPING").as_deref()==Ok("1")
}
pub(super) struct State {
    flow:incremental_delay::Flow,pool:Vec<Instance>,index:HashMap<InstanceKey,usize>,free:Vec<bool>,
    inputs:Vec<(usize,u32,String)>,outputs:Vec<(usize,String)>,constants:Vec<Option<bool>>,
    recovery_attempts:Vec<serde_json::Value>,batch_seed_backup:Option<(Vec<Option<Binding>>,(f64,f64))>,tracking_batch:bool,seed_backup:Option<(Vec<Option<Binding>>,(f64,f64))>,tracking_seed:bool,
    wide_cursor:Option<wide::stream::Cursor>,witness:Option<Vec<Option<Binding>>>,recovery_next:usize,recovery_pass_changed:bool,recovery_stable:bool,recovery_cache:Option<(usize,Vec<usize>,Vec<usize>,Vec<f64>,Vec<Option<f64>>)>,
    best:Option<MappedGraph>,best_global:Option<Vec<Option<Binding>>>,batches:usize,matched_cuts:usize,commits:usize,wide_done:bool,
}
impl State {
 pub(super) fn new(free:&[bool],inputs:&[(usize,u32,String)],outputs:&[(usize,String)],constants:&[Option<bool>])->Self {
  Self{recovery_attempts:vec![],batch_seed_backup:None,tracking_batch:false,flow:incremental_delay::Flow::new(free),seed_backup:None,tracking_seed:false,wide_cursor:None,witness:None,recovery_next:0,recovery_pass_changed:false,recovery_stable:false,recovery_cache:None,pool:Vec::new(),index:HashMap::new(),free:free.to_vec(),inputs:inputs.to_vec(),outputs:outputs.to_vec(),constants:constants.to_vec(),best:None,best_global:None,batches:0,matched_cuts:0,commits:0,wide_done:false}
 }
 pub(super) fn consume(&mut self,bank:&[BTreeSet<Cut>],delta:&[BTreeSet<Cut>],interface_free:&[bool],interface_constants:&[Option<bool>],aliases:Option<(&[usize],&[bool])>,tech:&TechLib,ps:&MapParams,reach:&mut Reachability,stats:&mut MapStats){
  let end=crate::egraph_time_policy::deadline().expect("shared time-only window");
  if Instant::now()>=end{return}
  let added:usize=delta.iter().map(BTreeSet::len).sum();if added==0{return}
  self.batches+=1;self.matched_cuts+=added;stage_trace("online_delta_match_start");
  let mut small=std::env::var("EGM_STREAM_SMALL").as_deref()==Ok("1");#[cfg(test)]{small|=TEST_SMALL.with(|x|x.get());}
  if small {
   let mut cursor=small_stream::Cursor::new(delta,interface_free,tech,ps,stats);
   while !cursor.done()&&Instant::now()<end {
    let batch=cursor.resume(delta,interface_free,interface_constants,tech,ps,reach,stats,aliases,2048,end);
    let changed=self.ingest(batch.matches,aliases,ps);if changed||Self::incremental_enabled()&&self.flow.pending(){self.update_delay(bank,stats,end);}
    if !batch.done {stage_trace("online_small_yield");self.recovery_slice(bank,ps,stats);}
   }
  }else{
   let batch=generate(delta,interface_free,interface_constants,tech,ps,reach,stats,aliases,Some(end));
   let changed=self.ingest(batch,aliases,ps);if changed||Self::incremental_enabled()&&self.flow.pending(){self.update_delay(bank,stats,end);}
  }
  self.recovery_stable=false;stage_trace("online_delta_match_done");
  // Preserve the batch finite-frontier seed once per completed delta, as a
  // separately validated path. Incremental labels are not a replacement proof.
  if Self::incremental_enabled(){let roots:Vec<_>=self.outputs.iter().map(|v|v.0).collect();if let Some((chosen,_))=delay_frontier_seed(&self.pool,&self.free,end){self.witness=Some(chosen.clone());self.consider_batch_seed(bank,&roots,chosen,stats,end);}}
 }
 fn incremental_enabled()->bool{let mut enabled=std::env::var("EGM_INCREMENTAL_DELAY").as_deref()==Ok("1");#[cfg(test)]{enabled|=TEST_FLOW.with(|x|x.get());}enabled}
 fn ingest(&mut self,batch:Vec<Instance>,aliases:Option<(&[usize],&[bool])>,ps:&MapParams)->bool{
  let mut changed=Vec::new();
  for mut m in batch {if let Some((a,f))=aliases{if !normalize_physical_instance(&mut m,a,f){continue}}
   let key=exchange::recorded_key(&m).unwrap_or_else(||instance_key(&m));
   let before=self.index.get(&key).map(|&i|self.pool[i].outputs.iter().map(|o|o.targets.len()).sum::<usize>());
   let i=insert_instance_key(&mut self.pool,&mut self.index,m,key);
   if before.is_none_or(|n|n!=self.pool[i].outputs.iter().map(|o|o.targets.len()).sum::<usize>()){changed.push(i);}
  }
  let _=ps;if !changed.is_empty(){self.recovery_stable=false;if Self::incremental_enabled(){self.flow.admit(&self.pool,&changed);}}!changed.is_empty()
 }
 fn update_delay(&mut self,bank:&[BTreeSet<Cut>],stats:&MapStats,end:Instant){
  let roots:Vec<_>=self.outputs.iter().map(|v|v.0).collect();
  if Self::incremental_enabled(){
   stage_trace("online_incremental_delay_start");let changed=self.flow.resume(&self.pool,&self.free,4096,end);stage_trace("online_incremental_delay_yield");
   if changed{let chosen=self.flow.chosen.clone();self.witness=Some(chosen.clone());self.consider_seed(bank,&roots,chosen,stats,end);}
  }else if let Some((chosen,_))=delay_frontier_seed(&self.pool,&self.free,end){self.witness=Some(chosen.clone());self.consider_batch_seed(bank,&roots,chosen,stats,end);}
 }

 pub(super) fn consume_wide(&mut self,bank:&[BTreeSet<Cut>],nodes:&[Vec<AigLang>],dense:&impl Fn(Id)->usize,aliases:Option<(&[usize],&[bool])>,tech:&TechLib,ps:&MapParams,stats:&mut MapStats){
  if self.wide_done{return}let end=crate::egraph_time_policy::deadline().unwrap();if Instant::now()>=end{return}self.wide_done=true;
  stage_trace("online_wide_start");let mut batch=Vec::new();wide::generate(nodes,dense,tech,ps,&self.free,&self.constants,aliases,&mut batch,stats);
  for m in batch {let key=exchange::recorded_key(&m).unwrap_or_else(||instance_key(&m));insert_instance_key(&mut self.pool,&mut self.index,m,key);}
  stage_trace("online_wide_done");let roots:Vec<_>=self.outputs.iter().map(|v|v.0).collect();
  if let Some((chosen,_))=delay_frontier_seed(&self.pool,&self.free,end){self.consider_seed(bank,&roots,chosen,stats,end);}
 }
 pub(super) fn stream_wide_enabled()->bool{#[cfg(test)]if TEST_STREAM.with(|x|x.get()){return true}std::env::var("EGM_STREAM_WIDE").as_deref()==Ok("1")}
 pub(super) fn wide_pending(&self)->bool{self.wide_cursor.as_ref().is_none_or(|c|!c.done())}
 pub(super) fn stream_wide(&mut self,bank:&[BTreeSet<Cut>],nodes:&[Vec<AigLang>],dense:&impl Fn(Id)->usize,aliases:Option<(&[usize],&[bool])>,tech:&TechLib,ps:&MapParams,stats:&mut MapStats){
  let end=crate::egraph_time_policy::deadline().unwrap();if Instant::now()>=end{return}
  if self.wide_cursor.is_none(){stage_trace("online_stream_wide_start");self.wide_cursor=Some(wide::stream::Cursor::new(tech,ps.wide_cells));}
  let cursor=self.wide_cursor.as_mut().unwrap();let batch=cursor.resume(nodes,dense,&self.free,&self.constants,4096,end);
  let matches=batch.matches.iter().map(|found|{let mut m=cursor.materialize(found);if ps.protected_exchange{exchange::record_wide(&mut m,aliases);}m}).collect::<Vec<_>>();
  stats.wide_trials=cursor.steps+cursor.visits;self.wide_done=batch.done;stage_trace(if batch.done{"online_stream_wide_done"}else{"online_stream_wide_yield"});
  let before=self.pool.len();let changed=self.ingest(matches,aliases,ps);stats.wide_candidates+=self.pool.len()-before;
  if changed||Self::incremental_enabled()&&self.flow.pending(){self.update_delay(bank,stats,end);}

 }
 // Cooperative actual-area proposals: persistent cursor, fixed incumbent delay,
 // no fresh time allowance and no discarded pending candidates on a yield.
 pub(super) fn recovery_slice(&mut self,bank:&[BTreeSet<Cut>],ps:&MapParams,stats:&mut MapStats){
  let mut scheduled=std::env::var("EGM_SCHEDULE_RECOVERY").as_deref()==Ok("1");#[cfg(test)]{scheduled|=TEST_SCHEDULE.with(|x|x.get());}if !scheduled{return}let Some(end)=crate::egraph_time_policy::deadline()else{return};if self.best.is_none()||self.recovery_stable||Instant::now()>=end{return}
  stage_trace("online_recovery_slice");let roots:Vec<_>=self.outputs.iter().map(|x|x.0).collect();
  for _ in 0..16{
   if Instant::now()>=end||self.pool.is_empty(){break}
   if self.recovery_next>=self.pool.len(){self.recovery_next=0;if !self.recovery_pass_changed{self.recovery_stable=true;break}self.recovery_pass_changed=false;}
   let i=self.recovery_next;self.recovery_next+=1;let chosen=self.best_global.as_ref().unwrap();let old=self.best.as_ref().map(|g|(g.area,g.delay)).unwrap();
   if self.recovery_cache.as_ref().is_none_or(|(rev,_,users,_,_)|*rev!=self.commits||users.len()!=self.pool.len()){
    let(refs,users)=shared_area_counters(&self.pool,chosen,&roots);let required=required_times(&self.pool,chosen,&self.free,&roots,old.1);let mut arrival=critical_arrivals(&self.pool,chosen,&self.free,&roots).0;
    if let Some(w)=&self.witness{let wr:Vec<_>=w.iter().enumerate().filter_map(|(s,b)|b.map(|_|s)).collect();let wa=critical_arrivals(&self.pool,w,&self.free,&wr).0;for s in 0..arrival.len(){if arrival[s].is_none(){arrival[s]=wa[s];}}}
    self.recovery_cache=Some((self.commits,refs,users,required,arrival));
   }
   let(_,refs,users,required,arrival)=self.recovery_cache.as_ref().unwrap();let m=&self.pool[i];
   if m.inputs.iter().any(|&s|arrival[s].is_none()){continue}
   if selected_input_area(&self.pool,chosen,&self.free,i,old.0,refs,users).is_some_and(|a|a>=old.0-1e-6){continue}
   if !m.outputs.iter().any(|o|{let time=m.inputs.iter().enumerate().filter(|(p,_)|o.has_arc(*p)).map(|(p,&s)|arrival[s].unwrap()+f64::from(o.delays[p])).fold(0.,f64::max);o.targets.iter().any(|&s|chosen[s].is_some_and(|b|b.instance!=i)&&time<=required[s]+1e-7)}){continue}
   let mut trial=chosen.clone();for(pin,o)in m.outputs.iter().enumerate(){for &s in &o.targets{if trial[s].is_some(){trial[s]=Some(Binding{instance:i,pin});}}}
   let Some(witness)=self.witness.as_ref()else{continue};stats.slack_local_trials+=1;
   if let Ok(value)=validate_score_trial(&self.pool,&mut trial,witness,&self.free,&roots,ps.fused_cover_scoring){if value.0<old.0-1e-6&&value.1<=old.1{self.consider(bank,&roots,trial,stats,end);}}
  }
 }
 pub(super) fn ready_for_wide(&self)->bool{self.batches>=2}
 fn consider_batch_seed(&mut self,bank:&[BTreeSet<Cut>],roots:&[usize],chosen:Vec<Option<Binding>>,stats:&MapStats,end:Instant){
  self.tracking_batch=std::env::var("EGM_PROTECT_BATCH_SEED").as_deref()==Ok("1");self.consider_seed(bank,roots,chosen,stats,end);self.tracking_batch=false;
 }
 fn consider_seed(&mut self,bank:&[BTreeSet<Cut>],roots:&[usize],chosen:Vec<Option<Binding>>,stats:&MapStats,end:Instant){
  self.tracking_seed=std::env::var("EGM_PROTECT_DELAY_SEED").as_deref()==Ok("1");self.consider(bank,roots,chosen,stats,end);self.tracking_seed=false;
 }
 fn consider(&mut self,bank:&[BTreeSet<Cut>],roots:&[usize],chosen:Vec<Option<Binding>>,stats:&MapStats,end:Instant){
  if Instant::now()>=end{return}
  let Ok(cert)=exchange::ProtectedCover::capture(&self.pool,&chosen,&self.free,roots,bank)else{return};
  if self.tracking_batch && self.batch_seed_backup.as_ref().is_none_or(|(_,old)|better_cover(cert.value,*old,&MapParams{objective:MapObjective::DelayArea,..Default::default()})){self.batch_seed_backup=Some((cert.chosen.clone(),cert.value));}
  if self.tracking_seed && self.seed_backup.as_ref().is_none_or(|(_,old)|better_cover(cert.value,*old,&MapParams{objective:MapObjective::DelayArea,..Default::default()})){self.seed_backup=Some((cert.chosen.clone(),cert.value));}
  if self.best.as_ref().is_some_and(|old|!better_cover(cert.value,(old.area,old.delay),&MapParams{objective:MapObjective::DelayArea,..Default::default()})){return}
  let mut ids=HashMap::new();let mut instances=Vec::new();
  for &i in &cert.live {ids.insert(i,instances.len());instances.push(self.pool[i].clone());}
  let global_chosen=cert.chosen.clone();
  let chosen=cert.chosen.into_iter().map(|b|b.map(|b|Binding{instance:ids[&b.instance],pin:b.pin})).collect();
  let graph=MappedGraph{instances,chosen,inputs:self.inputs.clone(),outputs:self.outputs.clone(),constants:self.constants.clone(),area:cert.value.0,delay:cert.value.1,stats:stats.clone()};
  // Validate the compact index space before any disk publication.
  let mut check=graph.chosen.clone();if prune(&graph.instances,&mut check,&self.free,roots).is_err(){return}
  if metrics(&graph.instances,&check,&self.free,roots)!=(graph.area,graph.delay){return}
  if Instant::now()>=end{return}
  self.commits+=1;
  if let Err(error)=publish(&graph,self.commits,self.batches,self.matched_cuts,end){eprintln!("online publication failed: {error}");}
  self.recovery_stable=false;self.recovery_pass_changed=true;self.best=Some(graph);self.best_global=Some(global_chosen);stage_trace("online_incumbent_validated");
 }
 // One exact selected-input shared-area sweep after cut closure. No extra clock.
 // Rejected proposals leave the complete prior incumbent unchanged.
 fn area_recover(&mut self,bank:&[BTreeSet<Cut>],stats:&MapStats){
  let Some(end)=crate::egraph_time_policy::deadline()else{return};
  let roots:Vec<_>=self.outputs.iter().map(|x|x.0).collect();stage_trace("online_actual_area_start");
  let mut cached=None;let mut i=0;while i<self.pool.len(){
   if Instant::now()>=end{break}
   let Some(chosen)=self.best_global.as_ref()else{break};let value=self.best.as_ref().map(|x|(x.area,x.delay)).unwrap();
   if cached.is_none(){let(refs,users)=shared_area_counters(&self.pool,chosen,&roots);let required=required_times(&self.pool,chosen,&self.free,&roots,value.1);let arrival=critical_arrivals(&self.pool,chosen,&self.free,&roots).0;cached=Some((refs,users,required,arrival));}
   let(refs,users,required,arrival)=cached.as_ref().unwrap();
   if selected_input_area(&self.pool,chosen,&self.free,i,value.0,refs,users).is_some_and(|a|a<value.0-1e-6){
    let m=&self.pool[i];let mut trial=chosen.clone();let mut feasible=true;let mut replaced=false;
    for(pin,o)in m.outputs.iter().enumerate(){let time=m.inputs.iter().enumerate().filter(|(p,_)|o.has_arc(*p)).map(|(p,&x)|arrival[x].unwrap_or(f64::INFINITY)+f64::from(o.delays[p])).fold(0.,f64::max);
     for &target in &o.targets {if trial[target].is_some(){if time>required[target]+1e-7{feasible=false;break}trial[target]=Some(Binding{instance:i,pin});replaced=true;}}
    }
    if feasible && replaced && prune(&self.pool,&mut trial,&self.free,&roots).is_ok(){let next=metrics(&self.pool,&trial,&self.free,&roots);
     if next.0<value.0-1e-6 && next.1<=value.1 {self.consider(bank,&roots,trial,stats,end);cached=None;}
    }
   }
   i+=1;
  }
  stage_trace("online_actual_area_done");
 }
 // Reuse the existing whole-cover recovery oracle, warm-started from the
 // saved complete online incumbent. The original delay/area cap is immutable.
 fn recover_from(&mut self,kind:&str,bank:&[BTreeSet<Cut>],ps:&MapParams,stats:&mut MapStats,chosen:Vec<Option<Binding>>,old:(f64,f64),witness:&[Option<Binding>],end:Instant){
  if Instant::now()>=end{return}let roots:Vec<_>=self.outputs.iter().map(|x|x.0).collect();let mut p=ps.clone();p.objective=MapObjective::AreaDelay;p.max_delay=Some(old.1);p.fixed_area_bound=true;p.protected_area_limit=Some(old.0);p.online_area=true;p.refresh_area_timing=true;p.delta_area_filter=true;p.fast_area_scan=true;
  let(trial,value)=slack_area_pass(&self.pool,&self.free,&roots,witness,chosen,old,&p,stats,end,true);let accepted=value.1<=old.1&&value.0<=old.0;if accepted{self.consider(bank,&roots,trial,stats,end);}self.recovery_attempts.push(serde_json::json!({"seed_kind":kind,"seed_AD":old,"recovered_AD":value,"within_seed_bound":accepted,"current_best_AD":self.best.as_ref().map(|x|(x.area,x.delay))}));
 }
 fn cone_area_recover(&mut self,bank:&[BTreeSet<Cut>],ps:&MapParams,stats:&mut MapStats){
  let roots:Vec<_>=self.outputs.iter().map(|v|v.0).collect();
  let Some(end)=crate::egraph_time_policy::deadline()else{return};if Instant::now()>=end||self.best_global.is_none(){return}let Some((witness,_))=delay_frontier_seed(&self.pool,&self.free,end)else{return};
  if std::env::var("EGM_PROTECT_BATCH_SEED").as_deref()==Ok("1"){self.consider_batch_seed(bank,&roots,witness.clone(),stats,end);}
  let batch_seed=self.batch_seed_backup.clone();
  if let Some((seed,value))=batch_seed.as_ref(){if value.1<=self.best.as_ref().unwrap().delay{stage_trace("online_batch_seed_area_start");self.recover_from("batch",bank,ps,stats,seed.clone(),*value,&witness,end);stage_trace("online_batch_seed_area_done");}}
  if Instant::now()>=end{return}
  if let Some((seed,value))=self.seed_backup.clone(){if batch_seed.as_ref().is_none_or(|(b,_)|b.len()!=seed.len()||b.iter().zip(&seed).any(|(a,b)|a.map(|x|(x.instance,x.pin))!=b.map(|x|(x.instance,x.pin))))&&value.1<=self.best.as_ref().unwrap().delay{stage_trace("online_protected_seed_area_start");self.recover_from("delay",bank,ps,stats,seed,value,&witness,end);stage_trace("online_protected_seed_area_done");}}
  if Instant::now()>=end{return}let chosen=self.best_global.clone().unwrap();let old=self.best.as_ref().map(|g|(g.area,g.delay)).unwrap();stage_trace("online_cone_area_start");self.recover_from("current",bank,ps,stats,chosen,old,&witness,end);stage_trace("online_cone_area_done");
 }
 pub(super) fn finish(mut self,bank:&[BTreeSet<Cut>],ps:&MapParams,mut stats:MapStats)->Result<MappedGraph,String>{
  if Self::incremental_enabled(){if let Some(end)=crate::egraph_time_policy::deadline(){while self.flow.pending()&&Instant::now()<end{self.update_delay(bank,&stats,end);self.recovery_slice(bank,ps,&mut stats);}}}
  match std::env::var("EGM_ONLINE_AREA_RECOVERY").as_deref(){Ok("1")=>self.area_recover(bank,&stats),Ok("2")=>self.cone_area_recover(bank,ps,&mut stats),_=>{}}
  if let Some(root)=std::env::var_os("EGM_INCUMBENT_DIR").map(PathBuf::from){
   let report=serde_json::json!({"batch_seed_AD":self.batch_seed_backup.as_ref().map(|x|x.1),"pure_delay_seed_AD":self.seed_backup.as_ref().map(|x|x.1),"attempts":self.recovery_attempts,"same_saved_bindings":self.batch_seed_backup.as_ref().zip(self.seed_backup.as_ref()).map(|(a,b)|a.0.len()==b.0.len()&&a.0.iter().zip(&b.0).all(|(a,b)|a.map(|x|(x.instance,x.pin))==b.map(|x|(x.instance,x.pin)))),"scope":"actual complete covers; scalar equality does not establish same trajectory"});let _=std::fs::write(root.join("seed-recovery.json"),report.to_string());
  }
  let mut graph=self.best.take().ok_or("online search has no complete validated generated cover")?;
  graph.stats=stats;graph.stats.instances=self.pool.len();graph.stats.generated_instances=self.pool.len();Ok(graph)
 }
}
fn fnv(bytes:&[u8])->u64 {bytes.iter().fold(0xcbf29ce484222325u64,|v,&b|(v^u64::from(b)).wrapping_mul(0x100000001b3))}
fn publish(graph:&MappedGraph,sequence:usize,batches:usize,matched_cuts:usize,end:Instant)->Result<(),String>{
 let Some(root)=std::env::var_os("EGM_INCUMBENT_DIR").map(PathBuf::from)else{return Ok(())};
 publish_at(graph,sequence,batches,matched_cuts,end,&root)
}
fn publish_at(graph:&MappedGraph,sequence:usize,batches:usize,matched_cuts:usize,end:Instant,root:&std::path::Path)->Result<(),String>{
 std::fs::create_dir_all(root).map_err(|e|e.to_string())?;
 let pending=root.join(format!("{sequence:08}.pending"));let committed=root.join(format!("{sequence:08}"));
 std::fs::create_dir(&pending).map_err(|e|e.to_string())?;
 let mut text=Vec::new();graph.write_verilog(&mut text,"mapped").map_err(|e|e.to_string())?;
 std::fs::write(pending.join("mapped.v"),&text).map_err(|e|e.to_string())?;
 let manifest=serde_json::json!({"kind":"complete-generated-cover","area":graph.area,"delay":graph.delay,"instances":graph.instances.len(),"sequence":sequence,"batches":batches,"matched_cuts":matched_cuts,"bytes":text.len(),"fnv64":format!("{:016x}",fnv(&text)),"legality":"complete driver/cycle/cut-care-phase-pin proof and whole-cover metrics","CEC":false,"search_exhaustive":false});
 std::fs::write(pending.join("manifest.json"),manifest.to_string()).map_err(|e|e.to_string())?;
 if Instant::now()>=end{return Err("deadline before atomic incumbent commit".into())}
 std::fs::rename(pending,committed).map_err(|e|e.to_string())
}

#[cfg(test)]mod tests {
 use super::*;
 fn fixture()->(Aig,TechLib){
  let dir=std::env::temp_dir().join(format!("online-fixture-{}-{}",std::process::id(),std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).unwrap().as_nanos()));std::fs::create_dir(&dir).unwrap();
  let a=dir.join("test.aag");std::fs::write(&a,"aag 5 3 0 2 2\n2\n4\n6\n10\n11\n8 2 4\n10 8 6\ni0 a[0]\ni1 b[0]\ni2 c[0]\no0 y[0]\no1 y[1]\nc\n").unwrap();
  let l=dir.join("test.genlib");std::fs::write(&l,"GATE AND2 1 Y=A*B;\nPIN * NONINV 1 999 1 0 1 0\nGATE AND3 1.5 Y=A*B*C;\nPIN * NONINV 1 999 1 0 1 0\nGATE NAND2 1 Y=!(A*B);\nPIN * INV 1 999 1 0 1 0\nGATE INV .2 Y=!A;\nPIN * INV 1 999 .1 0 .1 0\n").unwrap();
  (Aig::from_aiger(a.to_str().unwrap()),TechLib::from_genlib_directed(&l).unwrap())
 }
 #[test]fn complete_online_cover_matches_exhaustive_function_and_index_space(){
  let(a,t)=fixture();let _window=crate::egraph_time_policy::Window::enter(3.).unwrap();TEST_ENABLED.with(|x|x.set(true));
  let p=MapParams{strict_budgets:true,protected_exchange:true,functional_cuts:true,canonical_phases:true,canonical_wire_only:true,time_limit_secs:0.,multioutput:false,objective:MapObjective::DelayArea,..Default::default()};
  let m=map(&a,&t,&p).unwrap();TEST_ENABLED.with(|x|x.set(false));
  assert!(m.area>0. &&m.delay.is_finite());assert_eq!(m.outputs[0].1,"y[0]");assert_eq!(m.inputs[0].2,"a[0]");
  for assignment in 0..8 {let v=m.inputs.iter().enumerate().map(|(i,(_,id,_))|(*id,assignment&(1<<i)!=0)).collect();assert_eq!(m.evaluate(&v).unwrap(),vec![assignment==7,assignment!=7]);}
 }
 #[test]fn streaming_and_scheduled_recovery_preserve_complete_phase_cover(){
  let(a,t)=fixture();let _window=crate::egraph_time_policy::Window::enter(3.).unwrap();TEST_ENABLED.with(|x|x.set(true));TEST_STREAM.with(|x|x.set(true));TEST_SCHEDULE.with(|x|x.set(true));
  let p=MapParams{strict_budgets:true,protected_exchange:true,functional_cuts:true,canonical_phases:true,canonical_wire_only:true,time_limit_secs:0.,multioutput:false,objective:MapObjective::DelayArea,..Default::default()};let m=map(&a,&t,&p).unwrap();TEST_ENABLED.with(|x|x.set(false));TEST_STREAM.with(|x|x.set(false));TEST_SCHEDULE.with(|x|x.set(false));for a in 0..8{let v=m.inputs.iter().enumerate().map(|(i,(_,id,_))|(*id,a&(1<<i)!=0)).collect();assert_eq!(m.evaluate(&v).unwrap(),vec![a==7,a!=7]);}
 }
 #[test]fn round_delta_reconstructs_uncapped_bank_and_matches_control(){
  let(a,t)=fixture();let(mut e,_)=import_aig(&a).unwrap();e.rebuild();
  let mut classes:Vec<_>=e.classes().map(|c|c.id).collect();classes.sort();let ids:HashMap<_,_>=classes.iter().enumerate().map(|(i,&c)|(c,i)).collect();let nodes:Vec<_>=classes.iter().map(|&c|e[c].nodes.clone()).collect();
  let p=MapParams{cuts_per_class:usize::MAX,cut_rounds:32,..Default::default()};let mut stats=MapStats::default();
  let control=enumerate_with_source_mode(&nodes,&ids,&e,&t,&p,&mut stats,&[],true);let mut seen=vec![BTreeSet::new();nodes.len()];let mut calls=0;
  let mut notify=|bank:&[BTreeSet<Cut>],delta:&[BTreeSet<Cut>],_:&mut MapStats|{calls+=1;for c in 0..bank.len(){assert!(seen[c].is_disjoint(&delta[c]));seen[c].extend(delta[c].iter().cloned());assert_eq!(seen[c],bank[c]);}};
  let online=enumerate_with_source_notify(&nodes,&ids,&e,&t,&p,&mut stats,&[],true,Some(&mut notify));drop(notify);assert!(calls>=2);assert_eq!(online,control);
 }
 #[test]fn seminaive_cuts_equal_full_pair_closure_on_reconvergent_compact_graphs(){
  let(_,t)=fixture();
  for seed in 0..64usize {
   let mut g=egg::EGraph::<AigLang,()>::default();let mut all=vec![g.add(AigLang::Zero),g.add(AigLang::One)];for p in 0..4{all.push(g.add(AigLang::Pi(p)));}
   for i in 0..9 {let a=all[(i+seed)%all.len()];let b=all[(i*3+seed+1)%all.len()];if i%3==1{let c=all[(i*5+seed+2)%all.len()];all.push(g.add(AigLang::Cell(format!("@egm_tt3_{:02x}",[0x80,0xfe,0x96,0xe8][seed%4]).into(),vec![a,b,c])));}else{all.push(g.add(AigLang::And([a,b])));}if i%3==0{all.push(g.add(AigLang::Not(a)));}}
   g.rebuild();let mut classes:Vec<_>=g.classes().map(|c|c.id).collect();classes.sort();let ids:HashMap<_,_>=classes.iter().enumerate().map(|(i,&id)|(id,i)).collect();let nodes:Vec<_>=classes.iter().map(|&id|g[id].nodes.clone()).collect();
   let p=MapParams{max_inputs:4,cuts_per_class:usize::MAX,cut_rounds:32,..Default::default()};let mut stats=MapStats::default();let control=enumerate_with_source_mode(&nodes,&ids,&g,&t,&p,&mut stats,&[],true);let mut seen=vec![BTreeSet::new();nodes.len()];
   let mut notify=|bank:&[BTreeSet<Cut>],delta:&[BTreeSet<Cut>],_:&mut MapStats|{for c in 0..bank.len(){assert!(seen[c].is_disjoint(&delta[c]));seen[c].extend(delta[c].iter().cloned());assert_eq!(seen[c],bank[c]);}};
   let online=enumerate_with_source_notify(&nodes,&ids,&g,&t,&p,&mut stats,&[],true,Some(&mut notify));assert_eq!(online,control,"seed={seed}");
  }
 }
 #[test]fn incremental_matching_has_same_physical_keys_and_targets_as_batch_matching(){
  let(a,t)=fixture();let(mut e,roots)=import_aig(&a).unwrap();e.rebuild();
  let mut classes:Vec<_>=e.classes().map(|c|c.id).collect();classes.sort();let ids:HashMap<_,_>=classes.iter().enumerate().map(|(i,&c)|(c,i)).collect();let nodes:Vec<_>=classes.iter().map(|&c|e[c].nodes.clone()).collect();
  let mut free=vec![false;classes.len()*2];let mut constants=vec![None;free.len()];let mut inputs=Vec::new();
  for(c,bank)in nodes.iter().enumerate(){for n in bank{match n{AigLang::Pi(v)=>{free[c*2]=true;inputs.push((c*2,*v,format!("i{v}")));},AigLang::Zero|AigLang::One=>{for p in 0..2{free[c*2+p]=true;constants[c*2+p]=Some(matches!(n,AigLang::One)^(p==1));}},_=>{}}}}
  let outputs:Vec<_>=roots.iter().map(|(p,id)|(ids[&e.find(*id)]*2,format!("o{p}"))).collect();
  let p=MapParams{protected_exchange:true,multioutput:false,objective:MapObjective::DelayArea,cuts_per_class:usize::MAX,cut_rounds:32,..Default::default()};
  let witness=cheapest_nodes_queued(&e);let mut reach=Reachability{nodes:classes.iter().map(|c|witness[c].clone()).collect(),ids:ids.clone(),cache:HashMap::new()};
  let _w=crate::egraph_time_policy::Window::enter(5.).unwrap();let mut state=State::new(&free,&inputs,&outputs,&constants);let mut stats=MapStats::default();
  let mut f=|bank:&[BTreeSet<Cut>],delta:&[BTreeSet<Cut>],stats:&mut MapStats|state.consume(bank,delta,&free,&constants,None,&t,&p,&mut reach,stats);
  let bank=enumerate_with_source_notify(&nodes,&ids,&e,&t,&p,&mut stats,&[],true,Some(&mut f));drop(f);
  let batch=generate(&bank,&free,&constants,&t,&p,&mut reach,&mut stats,None,None);
  let signature=|pool:&[Instance]|pool.iter().map(|m|(format!("{:?}",instance_key(m)),m.outputs.iter().map(|o|o.targets.clone()).collect::<Vec<_>>())).collect::<BTreeMap<_,_>>();
  assert_eq!(signature(&state.pool),signature(&batch));assert!(state.best.is_some());
 }
 #[test]fn selected_input_shared_area_recovery_preserves_complete_cover_and_delay(){
  let(a,_)=fixture();let dir=std::env::temp_dir().join(format!("online-area-{}-{}",std::process::id(),std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).unwrap().as_nanos()));std::fs::create_dir_all(&dir).unwrap();let lib=dir.join("test.genlib");std::fs::write(&lib,"GATE AND3 1.5 Y=A*B*C;\nPIN * NONINV 1 999 1 0 1 0\nGATE AND3_EXPENSIVE 10 Y=A*B*C;\nPIN * NONINV 1 999 1 0 1 0\nGATE AND2 1 Y=A*B;\nPIN * NONINV 1 999 1 0 1 0\nGATE INV .2 Y=!A;\nPIN * INV 1 999 .1 0 .1 0\n").unwrap();let t=TechLib::from_genlib_directed(&lib).unwrap();
  let(mut e,roots)=import_aig(&a).unwrap();e.rebuild();let mut classes:Vec<_>=e.classes().map(|c|c.id).collect();classes.sort();let ids:HashMap<_,_>=classes.iter().enumerate().map(|(i,&c)|(c,i)).collect();let nodes:Vec<_>=classes.iter().map(|&c|e[c].nodes.clone()).collect();let mut free=vec![false;nodes.len()*2];let mut constants=vec![None;free.len()];let mut inputs=Vec::new();for(c,ns)in nodes.iter().enumerate(){for n in ns{match n{AigLang::Pi(v)=>{free[c*2]=true;inputs.push((c*2,*v,format!("i{v}")));},AigLang::Zero|AigLang::One=>{for p in 0..2{free[c*2+p]=true;constants[c*2+p]=Some(matches!(n,AigLang::One)^(p==1));}},_=>{}}}}
  let outputs:Vec<_>=roots.iter().map(|(p,id)|(ids[&e.find(*id)]*2,format!("o{p}"))).collect();let p=MapParams{protected_exchange:true,multioutput:false,objective:MapObjective::DelayArea,cuts_per_class:usize::MAX,cut_rounds:32,..Default::default()};let witness=cheapest_nodes_queued(&e);let mut reach=Reachability{nodes:classes.iter().map(|c|witness[c].clone()).collect(),ids:ids.clone(),cache:HashMap::new()};let mut stats=MapStats::default();let bank=enumerate_with_source_mode(&nodes,&ids,&e,&t,&p,&mut stats,&[],true);let _window=crate::egraph_time_policy::Window::enter(5.).unwrap();let mut state=State::new(&free,&inputs,&outputs,&constants);state.consume(&bank,&bank,&free,&constants,None,&t,&p,&mut reach,&mut stats);
  let expensive=state.pool.iter().position(|m|m.cell=="AND3_EXPENSIVE").unwrap();let mut chosen=state.best_global.clone().unwrap();for(pin,o)in state.pool[expensive].outputs.iter().enumerate(){for &target in &o.targets{if chosen[target].is_some(){chosen[target]=Some(Binding{instance:expensive,pin});}}}let roots:Vec<_>=outputs.iter().map(|x|x.0).collect();state.best=None;state.best_global=None;state.consider(&bank,&roots,chosen,&stats,crate::egraph_time_policy::deadline().unwrap());let old=state.best.as_ref().map(|g|(g.area,g.delay)).unwrap();assert!(old.0>=10.);state.area_recover(&bank,&stats);let m=state.best.unwrap();assert!(m.area<old.0);assert!(m.delay<=old.1);for assignment in 0..8{let v=m.inputs.iter().enumerate().map(|(i,(_,id,_))|(*id,assignment&(1<<i)!=0)).collect();assert_eq!(m.evaluate(&v).unwrap(),vec![assignment==7,assignment!=7]);}
 }
 #[test]fn complete_delay_seed_survives_better_local_area_cover_and_global_rejection(){
  let(a,_)=fixture();let dir=std::env::temp_dir().join(format!("online-area-{}-{}",std::process::id(),std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).unwrap().as_nanos()));std::fs::create_dir_all(&dir).unwrap();let lib=dir.join("test.genlib");std::fs::write(&lib,"GATE AND3 1.5 Y=A*B*C;\nPIN * NONINV 1 999 1 0 1 0\nGATE AND3_EXPENSIVE 10 Y=A*B*C;\nPIN * NONINV 1 999 1 0 1 0\nGATE AND2 1 Y=A*B;\nPIN * NONINV 1 999 1 0 1 0\nGATE INV .2 Y=!A;\nPIN * INV 1 999 .1 0 .1 0\n").unwrap();let t=TechLib::from_genlib_directed(&lib).unwrap();
  let(mut e,roots)=import_aig(&a).unwrap();e.rebuild();let mut classes:Vec<_>=e.classes().map(|c|c.id).collect();classes.sort();let ids:HashMap<_,_>=classes.iter().enumerate().map(|(i,&c)|(c,i)).collect();let nodes:Vec<_>=classes.iter().map(|&c|e[c].nodes.clone()).collect();let mut free=vec![false;nodes.len()*2];let mut constants=vec![None;free.len()];let mut inputs=Vec::new();for(c,ns)in nodes.iter().enumerate(){for n in ns{match n{AigLang::Pi(v)=>{free[c*2]=true;inputs.push((c*2,*v,format!("i{v}")));},AigLang::Zero|AigLang::One=>{for p in 0..2{free[c*2+p]=true;constants[c*2+p]=Some(matches!(n,AigLang::One)^(p==1));}},_=>{}}}}
  let outputs:Vec<_>=roots.iter().map(|(p,id)|(ids[&e.find(*id)]*2,format!("o{p}"))).collect();let p=MapParams{protected_exchange:true,multioutput:false,objective:MapObjective::DelayArea,cuts_per_class:usize::MAX,cut_rounds:32,..Default::default()};let witness=cheapest_nodes_queued(&e);let mut reach=Reachability{nodes:classes.iter().map(|c|witness[c].clone()).collect(),ids:ids.clone(),cache:HashMap::new()};let mut stats=MapStats::default();let bank=enumerate_with_source_mode(&nodes,&ids,&e,&t,&p,&mut stats,&[],true);let _window=crate::egraph_time_policy::Window::enter(5.).unwrap();let mut state=State::new(&free,&inputs,&outputs,&constants);state.consume(&bank,&bank,&free,&constants,None,&t,&p,&mut reach,&mut stats);
  let expensive=state.pool.iter().position(|m|m.cell=="AND3_EXPENSIVE").unwrap();let mut chosen=state.best_global.clone().unwrap();for(pin,o)in state.pool[expensive].outputs.iter().enumerate(){for &target in &o.targets{if chosen[target].is_some(){chosen[target]=Some(Binding{instance:expensive,pin});}}}let roots:Vec<_>=outputs.iter().map(|x|x.0).collect();state.best=None;state.best_global=None;state.tracking_seed=true;state.consider(&bank,&roots,chosen,&stats,crate::egraph_time_policy::deadline().unwrap());state.tracking_seed=false;let old=state.best.as_ref().map(|g|(g.area,g.delay)).unwrap();assert!(old.0>=10.);state.area_recover(&bank,&stats);let cheap=state.best.as_ref().unwrap().area;let(seed,value)=state.seed_backup.take().unwrap();assert!(value.0>cheap);state.tracking_seed=true;state.consider(&bank,&roots,seed,&stats,crate::egraph_time_policy::deadline().unwrap());state.tracking_seed=false;assert_eq!(state.best.as_ref().unwrap().area,cheap);assert_eq!(state.seed_backup.as_ref().unwrap().1,value);state.cone_area_recover(&bank,&p,&mut stats);let m=state.best.unwrap();assert!(m.area<=cheap);assert!(m.area<old.0);assert!(m.delay<=old.1);for assignment in 0..8{let v=m.inputs.iter().enumerate().map(|(i,(_,id,_))|(*id,assignment&(1<<i)!=0)).collect();assert_eq!(m.evaluate(&v).unwrap(),vec![assignment==7,assignment!=7]);}
 }
 #[test]fn warm_started_cone_area_recovery_preserves_complete_cover_and_delay(){
  let(a,_)=fixture();let dir=std::env::temp_dir().join(format!("online-area-{}-{}",std::process::id(),std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).unwrap().as_nanos()));std::fs::create_dir_all(&dir).unwrap();let lib=dir.join("test.genlib");std::fs::write(&lib,"GATE AND3 1.5 Y=A*B*C;\nPIN * NONINV 1 999 1 0 1 0\nGATE AND3_EXPENSIVE 10 Y=A*B*C;\nPIN * NONINV 1 999 1 0 1 0\nGATE AND2 1 Y=A*B;\nPIN * NONINV 1 999 1 0 1 0\nGATE INV .2 Y=!A;\nPIN * INV 1 999 .1 0 .1 0\n").unwrap();let t=TechLib::from_genlib_directed(&lib).unwrap();
  let(mut e,roots)=import_aig(&a).unwrap();e.rebuild();let mut classes:Vec<_>=e.classes().map(|c|c.id).collect();classes.sort();let ids:HashMap<_,_>=classes.iter().enumerate().map(|(i,&c)|(c,i)).collect();let nodes:Vec<_>=classes.iter().map(|&c|e[c].nodes.clone()).collect();let mut free=vec![false;nodes.len()*2];let mut constants=vec![None;free.len()];let mut inputs=Vec::new();for(c,ns)in nodes.iter().enumerate(){for n in ns{match n{AigLang::Pi(v)=>{free[c*2]=true;inputs.push((c*2,*v,format!("i{v}")));},AigLang::Zero|AigLang::One=>{for p in 0..2{free[c*2+p]=true;constants[c*2+p]=Some(matches!(n,AigLang::One)^(p==1));}},_=>{}}}}
  let outputs:Vec<_>=roots.iter().map(|(p,id)|(ids[&e.find(*id)]*2,format!("o{p}"))).collect();let p=MapParams{protected_exchange:true,multioutput:false,objective:MapObjective::DelayArea,cuts_per_class:usize::MAX,cut_rounds:32,..Default::default()};let witness=cheapest_nodes_queued(&e);let mut reach=Reachability{nodes:classes.iter().map(|c|witness[c].clone()).collect(),ids:ids.clone(),cache:HashMap::new()};let mut stats=MapStats::default();let bank=enumerate_with_source_mode(&nodes,&ids,&e,&t,&p,&mut stats,&[],true);let _window=crate::egraph_time_policy::Window::enter(5.).unwrap();let mut state=State::new(&free,&inputs,&outputs,&constants);state.consume(&bank,&bank,&free,&constants,None,&t,&p,&mut reach,&mut stats);
  let expensive=state.pool.iter().position(|m|m.cell=="AND3_EXPENSIVE").unwrap();let mut chosen=state.best_global.clone().unwrap();for(pin,o)in state.pool[expensive].outputs.iter().enumerate(){for &target in &o.targets{if chosen[target].is_some(){chosen[target]=Some(Binding{instance:expensive,pin});}}}let roots:Vec<_>=outputs.iter().map(|x|x.0).collect();state.best=None;state.best_global=None;state.consider(&bank,&roots,chosen,&stats,crate::egraph_time_policy::deadline().unwrap());let old=state.best.as_ref().map(|g|(g.area,g.delay)).unwrap();assert!(old.0>=10.);state.cone_area_recover(&bank,&p,&mut stats);let m=state.best.unwrap();assert!(m.area<old.0);assert!(m.delay<=old.1);for assignment in 0..8{let v=m.inputs.iter().enumerate().map(|(i,(_,id,_))|(*id,assignment&(1<<i)!=0)).collect();assert_eq!(m.evaluate(&v).unwrap(),vec![assignment==7,assignment!=7]);}
 }
 #[test]fn incomplete_or_unproved_binding_is_never_an_incumbent(){
  let mut s=State::new(&[true,false,false],&[(0,1,"x".into())],&[(2,"y".into())],&[None;3]);
  let bank=vec![BTreeSet::new();2];s.consider(&bank,&[2],vec![None;3],&MapStats::default(),Instant::now()+std::time::Duration::from_secs(1));assert!(s.best.is_none());
 }
 #[test]fn deadline_during_publication_cannot_leave_committed_directory(){
  let(a,t)=fixture();let p=MapParams{multioutput:false,..Default::default()};let m=map(&a,&t,&p).unwrap();
  let dir=std::env::temp_dir().join(format!("online-atomic-{}",std::process::id()));let _=std::fs::remove_dir_all(&dir);
  assert!(publish_at(&m,1,1,1,Instant::now(),&dir).is_err());assert!(!dir.join("00000001").exists());assert!(dir.join("00000001.pending").exists());
  publish_at(&m,2,1,1,Instant::now()+std::time::Duration::from_secs(2),&dir).unwrap();let bytes=std::fs::read(dir.join("00000002/mapped.v")).unwrap();let j:serde_json::Value=serde_json::from_slice(&std::fs::read(dir.join("00000002/manifest.json")).unwrap()).unwrap();assert_eq!(j["fnv64"],format!("{:016x}",fnv(&bytes)));
 }
 #[test]fn ordinary_cursor_yields_and_preserves_all_physical_keys_targets_and_sources(){
  let(a,t)=fixture();let(mut e,_)=import_aig(&a).unwrap();e.rebuild();let mut classes:Vec<_>=e.classes().map(|c|c.id).collect();classes.sort();let ids:HashMap<_,_>=classes.iter().enumerate().map(|(i,&c)|(c,i)).collect();let nodes:Vec<_>=classes.iter().map(|&c|e[c].nodes.clone()).collect();
  let mut free=vec![false;classes.len()*2];let constants=vec![None;free.len()];for(c,ns)in nodes.iter().enumerate(){for n in ns{if matches!(n,AigLang::Pi(_)){free[c*2]=true;}}}
  let ps=MapParams{protected_exchange:true,multioutput:false,max_instances:usize::MAX,cuts_per_class:usize::MAX,cut_rounds:32,..Default::default()};let mut stats=MapStats::default();let bank=enumerate_with_source_mode(&nodes,&ids,&e,&t,&ps,&mut stats,&[],true);
  let make_reach=||{let w=cheapest_nodes_queued(&e);Reachability{nodes:classes.iter().map(|c|w[c].clone()).collect(),ids:ids.clone(),cache:HashMap::new()}};
  let end=Instant::now()+std::time::Duration::from_secs(15);let batch=generate_mode(&bank,&free,&constants,&t,&ps,&mut make_reach(),&mut stats,None,Some(end),true);
  let signature=|mut pool:Vec<Instance>|{let mut merged=Vec::new();let mut ix=HashMap::new();for m in pool.drain(..){insert_instance(&mut merged,&mut ix,m)}merged.iter().map(|m|(format!("{:?}",instance_key(m)),m.outputs.iter().map(|o|(o.targets.clone(),format!("{:?}",o.sources))).collect::<Vec<_>>())).collect::<BTreeMap<_,_>>()};let expected=signature(batch);
  for q in [1,7,256,4096]{let mut cur=small_stream::Cursor::new(&bank,&free,&t,&ps,&mut stats);let mut reach=make_reach();let mut got=Vec::new();let before=cur.operations;let expired=cur.resume(&bank,&free,&constants,&t,&ps,&mut reach,&mut stats,None,q,Instant::now());assert_eq!(cur.operations,before);assert!(expired.matches.is_empty());
   while !cur.done(){let b=cur.resume(&bank,&free,&constants,&t,&ps,&mut reach,&mut stats,None,q,end);assert!(b.operations<=q);got.extend(b.matches);}assert_eq!(signature(got),expected,"quantum={q}");if q==1{assert!(cur.yields>1)}
  }
 }

 #[test]fn cooperative_ordinary_and_incremental_flow_real_mapping_call_path(){
  let(a,t)=fixture();let _window=crate::egraph_time_policy::Window::enter(5.).unwrap();TEST_ENABLED.with(|x|x.set(true));TEST_SMALL.with(|x|x.set(true));TEST_FLOW.with(|x|x.set(true));TEST_STREAM.with(|x|x.set(true));TEST_SCHEDULE.with(|x|x.set(true));
  let p=MapParams{strict_budgets:true,protected_exchange:true,functional_cuts:true,canonical_phases:true,canonical_wire_only:true,time_limit_secs:0.,multioutput:false,objective:MapObjective::DelayArea,..Default::default()};let result=map(&a,&t,&p);
  TEST_ENABLED.with(|x|x.set(false));TEST_SMALL.with(|x|x.set(false));TEST_FLOW.with(|x|x.set(false));TEST_STREAM.with(|x|x.set(false));TEST_SCHEDULE.with(|x|x.set(false));let m=result.unwrap();for a in 0..8{let v=m.inputs.iter().enumerate().map(|(i,(_,id,_))|(*id,a&(1<<i)!=0)).collect();assert_eq!(m.evaluate(&v).unwrap(),vec![a==7,a!=7]);}
 }

 #[test]fn ordinary_cursor_preserves_conditional_sdc_bindings_across_yields(){
  let(_,tech)=fixture();let ids:HashMap<_,_>=(0..4).map(|i|(Id::from(i),i)).collect();let make=||Reachability{nodes:vec![AigLang::Pi(0),AigLang::Pi(1),AigLang::And([Id::from(0),Id::from(1)]),AigLang::And([Id::from(0),Id::from(2)])],ids:ids.clone(),cache:HashMap::new()};let mut cuts=vec![BTreeSet::new();4];cuts[3].insert(Cut{leaves:vec![0,2],function:8});let free=[true,false,true,false,false,false,false,false];let constants=[None;8];let ps=MapParams{protected_exchange:true,multioutput:false,max_instances:usize::MAX,dc_support:4,dc_cone:1024,..Default::default()};let end=Instant::now()+std::time::Duration::from_secs(5);let mut old_stats=MapStats::default();let old=generate_mode(&cuts,&free,&constants,&tech,&ps,&mut make(),&mut old_stats,None,Some(end),true);assert!(old_stats.dc_bindings>0);
  let mut stats=MapStats::default();let mut cursor=small_stream::Cursor::new(&cuts,&free,&tech,&ps,&mut stats);let mut reach=make();let mut out=vec![];while !cursor.done(){out.extend(cursor.resume(&cuts,&free,&constants,&tech,&ps,&mut reach,&mut stats,None,1,end).matches);}assert_eq!(old_stats.dc_bindings,stats.dc_bindings);
  let sig=|xs:Vec<Instance>|{let mut merged=vec![];let mut ix=HashMap::new();for m in xs{insert_instance(&mut merged,&mut ix,m)}merged.iter().map(|m|(format!("{:?}",instance_key(m)),m.outputs.iter().map(|o|(o.targets.clone(),format!("{:?}",o.sources))).collect::<Vec<_>>())).collect::<BTreeMap<_,_>>()};assert_eq!(sig(old),sig(out));
 }

 #[test]fn batch_frontier_seed_and_incremental_seed_are_independent_complete_archives(){
  let(a,t)=fixture();let(mut e,_)=import_aig(&a).unwrap();e.rebuild();let mut classes:Vec<_>=e.classes().map(|c|c.id).collect();classes.sort();let ids:HashMap<_,_>=classes.iter().enumerate().map(|(i,&c)|(c,i)).collect();let nodes:Vec<_>=classes.iter().map(|&c|e[c].nodes.clone()).collect();let mut free=vec![false;classes.len()*2];let constants=vec![None;free.len()];for(c,ns)in nodes.iter().enumerate(){for n in ns{if matches!(n,AigLang::Pi(_)){free[c*2]=true}}}let ps=MapParams{protected_exchange:true,multioutput:false,cuts_per_class:usize::MAX,cut_rounds:32,..Default::default()};let mut stats=MapStats::default();let bank=enumerate_with_source_mode(&nodes,&ids,&e,&t,&ps,&mut stats,&[],true);let witness=cheapest_nodes_queued(&e);let mut reach=Reachability{nodes:classes.iter().map(|c|witness[c].clone()).collect(),ids,cache:HashMap::new()};let pool=generate(&bank,&free,&constants,&t,&ps,&mut reach,&mut stats,None,None);let end=Instant::now()+std::time::Duration::from_secs(3);let(chosen,_)=delay_frontier_seed(&pool,&free,end).unwrap();let roots=chosen.iter().enumerate().filter_map(|(s,b)|b.map(|_|s)).collect::<Vec<_>>();let outputs=roots.iter().map(|&s|(s,format!("o{s}"))).collect::<Vec<_>>();let mut state=State::new(&free,&[],&outputs,&constants);state.pool=pool;state.tracking_seed=true;state.tracking_batch=true;state.consider(&bank,&roots,chosen.clone(),&stats,end);let saved=state.batch_seed_backup.clone().unwrap();state.tracking_batch=false;state.seed_backup=None;state.consider(&bank,&roots,chosen,&stats,end);assert_eq!(format!("{:?}",state.batch_seed_backup.unwrap()),format!("{:?}",saved));assert!(state.seed_backup.is_some());
 }

 #[test]fn ordinary_cursor_all_real_small_cells_preserve_complete_binding_evidence(){
  let root=std::env::var_os("EGM_TEST_DATA_ROOT").map(PathBuf::from).unwrap();let tech=TechLib::from_genlib_directed(root.join("asap7_full.genlib")).unwrap();let mut count=0;
  for cell in tech.cells.iter().filter(|c|c.vars.len()<=6){let k=cell.vars.len();let mut cuts=vec![BTreeSet::new();k+1];cuts[k].insert(Cut{leaves:(0..k).collect(),function:cell.tt[0]});let mut free=vec![false;(k+1)*2];for i in 0..k{free[i*2]=true;}let constants=vec![None;free.len()];let ids=(0..k).map(|i|(Id::from(i),i)).collect::<HashMap<_,_>>();let make=||Reachability{nodes:(0..k).map(|i|AigLang::Pi(i as u32)).collect(),ids:ids.clone(),cache:HashMap::new()};let ps=MapParams{protected_exchange:true,multioutput:false,max_instances:usize::MAX,dc_support:4,..Default::default()};let end=Instant::now()+std::time::Duration::from_secs(5);let mut stats=MapStats::default();let old=generate_mode(&cuts,&free,&constants,&tech,&ps,&mut make(),&mut stats,None,Some(end),true);
   let mut cursor=small_stream::Cursor::new(&cuts,&free,&tech,&ps,&mut stats);let mut reach=make();let mut out=vec![];while !cursor.done(){assert!(Instant::now()<end);out.extend(cursor.resume(&cuts,&free,&constants,&tech,&ps,&mut reach,&mut stats,None,7,end).matches);}let sig=|xs:Vec<Instance>|{let mut merged=vec![];let mut ix=HashMap::new();for m in xs{insert_instance(&mut merged,&mut ix,m)}merged.iter().map(|m|(format!("{:?}",instance_key(m)),m.outputs.iter().map(|o|(o.targets.clone(),format!("{:?}",o.sources))).collect::<Vec<_>>())).collect::<BTreeMap<_,_>>()};assert_eq!(sig(old),sig(out),"{}",cell.name);count+=1;
  }assert_eq!(count,40);
 }

}
