//! Append-only dirty delay labels with an explicit finite selected witness.
//! Candidate output-target merges enqueue existing IDs, not only new instances.
use super::*;
use std::collections::VecDeque;
pub(super) struct Flow {
 pub chosen:Vec<Option<Binding>>,known:Vec<bool>,time:Vec<f64>,cost:Vec<f64>,
 users:Vec<Vec<usize>>,registered:usize,target_counts:Vec<usize>,
 queue:VecDeque<usize>,queued:Vec<bool>,pub visits:usize,pub updates:usize,
}
impl Flow {
 pub fn new(free:&[bool])->Self{Self{chosen:vec![None;free.len()],known:free.to_vec(),time:vec![0.;free.len()],cost:vec![0.;free.len()],users:vec![vec![];free.len()],registered:0,target_counts:vec![],queue:VecDeque::new(),queued:vec![],visits:0,updates:0}}
 fn enqueue(&mut self,i:usize){if !self.queued[i]{self.queue.push_back(i);self.queued[i]=true}}
 pub fn admit(&mut self,pool:&[Instance],changed:&[usize]){
  while self.registered<pool.len(){let i=self.registered;self.registered+=1;self.queued.push(false);self.target_counts.push(0);let mut input=pool[i].inputs.clone();input.sort_unstable();input.dedup();for s in input{self.users[s].push(i)}self.enqueue(i);}
  for &i in changed{let n=pool[i].outputs.iter().map(|o|o.targets.len()).sum();if n!=self.target_counts[i]{self.target_counts[i]=n;self.enqueue(i)}}
 }
 fn cycle(&self,target:usize,inputs:&[usize],pool:&[Instance])->bool{
  let mut stack=inputs.to_vec();let mut seen=HashSet::new();while let Some(s)=stack.pop(){if s==target{return true}if !seen.insert(s){continue}if let Some(b)=self.chosen[s]{stack.extend_from_slice(&pool[b.instance].inputs)}}false
 }
 pub fn pending(&self)->bool{!self.queue.is_empty()}
 pub fn resume(&mut self,pool:&[Instance],free:&[bool],quantum:usize,end:Instant)->bool{
  let start=self.updates;
  for _ in 0..quantum{if Instant::now()>=end{break}let Some(i)=self.queue.pop_front()else{break};self.queued[i]=false;self.visits+=1;let m=&pool[i];if !m.inputs.iter().all(|&s|self.known[s]){continue}
   let area=(f64::from(m.area)+unique_input_cost(&m.inputs,&self.cost)).min(f64::MAX);
   for(pin,o)in m.outputs.iter().enumerate(){
    // Same conservative readiness convention as delay_frontier_seed, including
    // physical nondependent inputs; true pin timing is checked on whole cover.
    let time=m.inputs.iter().enumerate().map(|(p,&s)|self.time[s]+if o.has_arc(p){f64::from(o.delays[p])}else{0.}).fold(0.,f64::max);
    for &t in &o.targets{if free[t]{continue}let improves=!self.known[t]||time.total_cmp(&self.time[t]).then(area.total_cmp(&self.cost[t])).then_with(||{let old=self.chosen[t].unwrap();i.cmp(&old.instance).then(pin.cmp(&old.pin))}).is_lt();
     // A strictly increasing arrival along every input edge is an acyclic
     // certificate. Equal-arrival/zero-delay edges still need an exact walk.
     if !improves||m.inputs.iter().any(|&s|self.time[s]>=time)&&self.cycle(t,&m.inputs,pool){continue}
     self.known[t]=true;self.time[t]=time;self.cost[t]=area;self.chosen[t]=Some(Binding{instance:i,pin});self.updates+=1;
     // Enqueue after cloning just the affected adjacency, never a whole-pool scan.
     for u in self.users[t].clone(){self.enqueue(u)}
    }
   }
  }self.updates>start
 }
}
#[cfg(test)]mod tests{
 use super::*;
 fn cell(input:Vec<usize>,target:usize,d:f32,a:f32)->Instance{let n=input.len();Instance{cell:"test".into(),area:a,inputs:input,input_pins:(0..n).map(|i|format!("p{i}")).collect(),outputs:vec![OutputPin{wide_function:None,sources:vec![],name:"Y".into(),delays:vec![d;n].into(),function:if n==1{2}else{8},targets:vec![target]}]}}
 #[test]fn incremental_delay_dag_matches_batch_frontier_and_resumes(){
  for seed in 0..64{let mut p=vec![cell(vec![0],1,1.,1.)];for t in 2..16{p.push(cell(vec![t-1],t,1.+((t+seed)%3)as f32,1.));p.push(cell(vec![0],t,2.+((t*7+seed)%13)as f32,2.));}let free=(0..16).map(|s|s==0).collect::<Vec<_>>();let end=Instant::now()+std::time::Duration::from_secs(5);let mut f=Flow::new(&free);
   for len in 1..=p.len(){f.admit(&p[..len],&[]);f.resume(&p[..len],&free,1,end);}
   while f.pending(){f.resume(&p,&free,1,end);}let(old,_)=delay_frontier_seed_mode(&p,&free,end,true).unwrap();for t in 1..16{let mut c=f.chosen.clone();prune(&p,&mut c,&free,&[t]).unwrap();let mut b=old.clone();prune(&p,&mut b,&free,&[t]).unwrap();assert_eq!(metrics(&p,&c,&free,&[t]).1,metrics(&p,&b,&free,&[t]).1,"seed={seed},root={t}");}
   let visits=f.visits;f.admit(&p,&[]);assert!(!f.pending());assert_eq!(visits,f.visits);
   let mut m=p.clone();m[0].outputs[0].targets.push(15);f.admit(&m,&[0]);while f.pending(){f.resume(&m,&free,1,end);}assert_eq!(metrics(&m,&f.chosen,&free,&[15]).1,1.);
  }
 }
 #[test]fn zero_delay_cycle_and_late_improvements_keep_a_finite_witness(){
  let mut p=vec![cell(vec![0],1,5.,5.),cell(vec![1],2,0.,0.),cell(vec![2],1,0.,0.)];let free=[true,false,false];let end=Instant::now()+std::time::Duration::from_secs(2);let mut f=Flow::new(&free);f.admit(&p,&[]);while f.pending(){f.resume(&p,&free,1,end);}let mut c=f.chosen.clone();prune(&p,&mut c,&free,&[1,2]).unwrap();
  p.push(cell(vec![0],2,1.,1.));f.admit(&p,&[]);while f.pending(){f.resume(&p,&free,1,end);}let mut c=f.chosen.clone();prune(&p,&mut c,&free,&[1,2]).unwrap();assert_eq!(metrics(&p,&c,&free,&[1,2]).1,1.);
 }
 #[test]fn incremental_delay_on_small_dags_matches_independent_cover_enumeration(){
  for seed in 0..16{let mut pool=vec![];for t in 2..8{let input=vec![t-1,(t+seed)%t];pool.push(cell(input.clone(),t,1.+((t+seed)%7)as f32,1.));pool.push(cell(input,t,1.+((3*t+seed)%5)as f32,2.));}let free=[true,true,false,false,false,false,false,false];let end=Instant::now()+std::time::Duration::from_secs(2);let mut f=Flow::new(&free);for len in 1..=pool.len(){f.admit(&pool[..len],&[]);f.resume(&pool[..len],&free,1,end);}while f.pending(){assert!(Instant::now()<end);f.resume(&pool,&free,1,end);}let mut chosen=f.chosen.clone();prune(&pool,&mut chosen,&free,&[7]).unwrap();let mut minimum=f64::INFINITY;
   for bits in 0..64{let mut c=vec![None;8];for t in 2..8{c[t]=Some(Binding{instance:2*(t-2)+((bits>>(t-2))&1),pin:0});}prune(&pool,&mut c,&free,&[7]).unwrap();minimum=minimum.min(metrics(&pool,&c,&free,&[7]).1);}assert_eq!(metrics(&pool,&chosen,&free,&[7]).1,minimum);
  }
 }

}
