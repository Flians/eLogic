module mapped( b , c , a , y , z , w );
  input b , c , a ;
  output y , z , w ;
  INV    g0( .A (a), .Y (y) );
  INV    g1( .A (b), .Y (z) );
  INV    g2( .A (c), .Y (w) );
endmodule
