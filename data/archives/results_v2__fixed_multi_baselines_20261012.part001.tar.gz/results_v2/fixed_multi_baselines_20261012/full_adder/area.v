module mapped( b , c , a , sum , carry );
  input b , c , a ;
  output sum , carry ;
  FA  g0( .A (b), .B (c), .C (a), .S (sum), .CO (carry) );
endmodule
