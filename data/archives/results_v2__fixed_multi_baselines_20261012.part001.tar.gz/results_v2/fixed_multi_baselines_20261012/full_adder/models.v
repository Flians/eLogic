module AND(A, B, Y);
  input A;
  input B;
  output Y;
  assign Y = (A) & (B);
endmodule
module BUF(A, Y);
  input A;
  output Y;
  assign Y = A;
endmodule
module FA(A, B, C, S, CO);
  input A;
  input B;
  input C;
  output S;
  output CO;
  assign S = (((((A) & (~(B))) & (~(C))) | (((~(A)) & (B)) & (~(C)))) | (((~(A)) & (~(B))) & (C))) | (((A) & (B)) & (C));
  assign CO = (((A) & (B)) | ((A) & (C))) | ((B) & (C));
endmodule
module INV(A, Y);
  input A;
  output Y;
  assign Y = ~(A);
endmodule
